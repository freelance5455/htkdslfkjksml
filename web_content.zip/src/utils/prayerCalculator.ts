import { DailySchedule, NightTimings, PrayerName, PrayerSettings, NextPrayerInfo } from '../types/prayer';
import { OCTOBER_2026_TIMETABLE } from '../data/october2026Timetable';

/**
 * Astronomical calculation algorithm for dates outside the supplied October 2026 timetable.
 * Karachi method: Fajr angle 18°, Isha angle 18°, Dhaka coordinates (23.8103° N, 90.4125° E).
 */
export function calculatePrayerTimesAstronomical(date: Date, lat = 23.8103, lng = 90.4125, tz = 6): DailySchedule {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = d.getMonth() + 1;
  const day = d.getDate();

  // Day of year
  const startOfYear = new Date(year, 0, 0);
  const diff = d.getTime() - startOfYear.getTime();
  const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));

  // Sun declination & Equation of Time approximation
  const B = (360 / 365) * (dayOfYear - 81) * (Math.PI / 180);
  const EoT = 9.87 * Math.sin(2 * B) - 7.53 * Math.cos(B) - 1.5 * Math.sin(B); // in minutes
  const declination = 23.45 * Math.sin(B) * (Math.PI / 180); // in radians

  const latRad = lat * (Math.PI / 180);

  // Solar noon
  const solarNoonMinutes = 12 * 60 - (lng - tz * 15) * 4 - EoT;

  const hourAngle = (angle: number) => {
    const angleRad = angle * (Math.PI / 180);
    const cosHA = (Math.sin(angleRad) - Math.sin(latRad) * Math.sin(declination)) / (Math.cos(latRad) * Math.cos(declination));
    if (cosHA > 1) return 0;
    if (cosHA < -1) return Math.PI;
    return Math.acos(cosHA);
  };

  // Sun depression angles
  // Fajr: -18 deg
  // Sunrise/Sunset: -0.833 deg
  // Isha: -18 deg
  const haSunrise = hourAngle(-0.833);
  const sunriseMin = solarNoonMinutes - (haSunrise * 180 / Math.PI) * 4;
  const sunsetMin = solarNoonMinutes + (haSunrise * 180 / Math.PI) * 4;

  const haFajr = hourAngle(-18.0);
  const fajrMin = solarNoonMinutes - (haFajr * 180 / Math.PI) * 4;

  const haIsha = hourAngle(-18.0);
  const ishaMin = solarNoonMinutes + (haIsha * 180 / Math.PI) * 4;

  // Asr (Shafi'i: shadow factor 1; Hanafi: shadow factor 2. For Bangladesh standard, Hanafi factor ~2 or standard)
  const asrAltRad = Math.atan(1 / (1 + Math.tan(Math.abs(latRad - declination))));
  const haAsr = Math.acos((Math.sin(asrAltRad) - Math.sin(latRad) * Math.sin(declination)) / (Math.cos(latRad) * Math.cos(declination)));
  const asrMin = solarNoonMinutes + (haAsr * 180 / Math.PI) * 4;

  const dhuhrMin = solarNoonMinutes + 4; // 4 min buffer after zenith

  const formatMin = (m: number): string => {
    let tot = Math.round(m);
    while (tot < 0) tot += 1440;
    tot = tot % 1440;
    const hh = Math.floor(tot / 60).toString().padStart(2, '0');
    const mm = (tot % 60).toString().padStart(2, '0');
    return `${hh}:${mm}`;
  };

  const pad = (n: number) => n.toString().padStart(2, '0');
  const dateStr = `${year}-${pad(month)}-${pad(day)}`;

  return {
    date: dateStr,
    day,
    month,
    year,
    fajr: formatMin(fajrMin),
    sunrise: formatMin(sunriseMin),
    dhuhr: formatMin(dhuhrMin),
    asr: formatMin(asrMin),
    maghrib: formatMin(sunsetMin + 2), // Maghrib 2-3 mins after sunset
    isha: formatMin(ishaMin),
  };
}

/**
 * Gets the daily prayer schedule for a given Date.
 * Prioritizes the exact October 2026 timetable if the date falls in Oct 2026.
 */
export function getScheduleForDate(date: Date): DailySchedule {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();

  if (year === 2026 && month === 10 && day >= 1 && day <= 31) {
    const entry = OCTOBER_2026_TIMETABLE.find(t => t.day === day);
    if (entry) return entry;
  }

  return calculatePrayerTimesAstronomical(date);
}

/**
 * Parse 'HH:MM' into total minutes of the day (0 - 1439).
 */
export function timeStringToMinutes(timeStr: string): number {
  const [h, m] = timeStr.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

/**
 * Convert minutes from midnight into 'HH:MM'.
 */
export function minutesToTimeString(minutes: number): string {
  let normalized = Math.round(minutes);
  while (normalized < 0) normalized += 1440;
  normalized = normalized % 1440;
  const h = Math.floor(normalized / 60).toString().padStart(2, '0');
  const m = (normalized % 60).toString().padStart(2, '0');
  return `${h}:${m}`;
}

/**
 * Dynamically calculate Salah alarm time: Adhan time + delay minutes.
 */
export function calculateAlarmTime(adhanTime: string, delayMinutes: number): string {
  const adhanMin = timeStringToMinutes(adhanTime);
  return minutesToTimeString(adhanMin + delayMinutes);
}

/**
 * Format time to 12-hour (e.g., '04:35 AM') or 24-hour (e.g., '04:35').
 */
export function formatPrayerTime(timeStr: string, format: '12h' | '24h' = '12h'): string {
  if (!timeStr) return '--:--';
  const [hStr, mStr] = timeStr.split(':');
  const h = parseInt(hStr, 10);
  const m = mStr || '00';

  if (format === '24h') {
    return `${h.toString().padStart(2, '0')}:${m}`;
  }

  const period = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12.toString().padStart(2, '0')}:${m} ${period}`;
}

/**
 * Calculate Islamic Night Timings (Midnight, First Third, Last Third / Tahajjud).
 * Defined in Islamic jurisprudence as the period between Maghrib (sunset) and the next day's Fajr.
 */
export function calculateNightTimings(currentSchedule: DailySchedule, nextDaySchedule?: DailySchedule): NightTimings {
  const maghribMin = timeStringToMinutes(currentSchedule.maghrib);
  const nextFajrMin = nextDaySchedule 
    ? timeStringToMinutes(nextDaySchedule.fajr) 
    : timeStringToMinutes(currentSchedule.fajr);

  // Total night duration in minutes across midnight
  // Maghrib -> 24:00 + 00:00 -> Fajr
  const nightDurationMinutes = (1440 - maghribMin) + nextFajrMin;

  // First Third: Maghrib + D/3
  const firstThirdMin = maghribMin + nightDurationMinutes / 3;

  // Islamic Midnight: Maghrib + D/2
  const midnightMin = maghribMin + nightDurationMinutes / 2;

  // Last Third (Tahajjud start): Maghrib + 2*D/3 (or nextFajr - D/3)
  const lastThirdMin = maghribMin + (2 * nightDurationMinutes) / 3;

  return {
    firstThird: minutesToTimeString(firstThirdMin),
    midnight: minutesToTimeString(midnightMin),
    lastThird: minutesToTimeString(lastThirdMin),
    maghrib: currentSchedule.maghrib,
    fajr: nextDaySchedule ? nextDaySchedule.fajr : currentSchedule.fajr,
    nightDurationMinutes,
  };
}

/**
 * Determines current and next prayer info along with progress and countdown.
 */
export function getNextPrayerInfo(
  now: Date,
  settings: PrayerSettings,
  todaySchedule: DailySchedule,
  tomorrowSchedule: DailySchedule
): NextPrayerInfo {
  // Current time in Dhaka or local
  const currentMinutes = now.getHours() * 60 + now.getMinutes() + now.getSeconds() / 60;

  const prayerOrder: { key: PrayerName | 'sunrise'; name: string; time: string; isSunrise?: boolean }[] = [
    { key: 'fajr', name: 'Fajr', time: todaySchedule.fajr },
    { key: 'sunrise', name: 'Sunrise', time: todaySchedule.sunrise, isSunrise: true },
    { key: 'dhuhr', name: 'Dhuhr', time: todaySchedule.dhuhr },
    { key: 'asr', name: 'Asr', time: todaySchedule.asr },
    { key: 'maghrib', name: 'Maghrib', time: todaySchedule.maghrib },
    { key: 'isha', name: 'Isha', time: todaySchedule.isha },
  ];

  // Build timeline for today and tomorrow to find immediate next event
  interface EventSlot {
    key: PrayerName | 'sunrise';
    label: string;
    timeStr: string;
    minutesFromNow: number;
    targetDate: Date;
    isAlarm: boolean;
    referencePrayerName: PrayerName | 'sunrise';
  }

  const events: EventSlot[] = [];

  const addSlots = (schedule: DailySchedule, dayOffset: number) => {
    const baseDate = new Date(now);
    baseDate.setDate(baseDate.getDate() + dayOffset);

    const prayers: { key: PrayerName | 'sunrise'; label: string; time: string }[] = [
      { key: 'fajr', label: 'Fajr', time: schedule.fajr },
      { key: 'sunrise', label: 'Sunrise (Shuruk)', time: schedule.sunrise },
      { key: 'dhuhr', label: 'Dhuhr', time: schedule.dhuhr },
      { key: 'asr', label: 'Asr', time: schedule.asr },
      { key: 'maghrib', label: 'Maghrib', time: schedule.maghrib },
      { key: 'isha', label: 'Isha', time: schedule.isha },
    ];

    for (const p of prayers) {
      const pMin = timeStringToMinutes(p.time);
      const totalMin = dayOffset * 1440 + pMin;
      const [h, m] = p.time.split(':').map(Number);
      const slotDate = new Date(baseDate);
      slotDate.setHours(h, m, 0, 0);

      // 1. Adhan event (except sunrise which never triggers Adhan)
      if (p.key !== 'sunrise') {
        const prayerKey = p.key as PrayerName;
        // Check if Adhan is enabled or if it's the nominal prayer time
        events.push({
          key: prayerKey,
          label: `${p.label} Adhan`,
          timeStr: p.time,
          minutesFromNow: totalMin - currentMinutes,
          targetDate: slotDate,
          isAlarm: false,
          referencePrayerName: prayerKey,
        });

        // 2. Salah Alarm event (if delay > 0 and alarm is enabled)
        if (settings.alarmDelayMinutes > 0 && settings.alarmEnabled[prayerKey]) {
          const alarmTime = calculateAlarmTime(p.time, settings.alarmDelayMinutes);
          const alarmMin = timeStringToMinutes(alarmTime);
          const totalAlarmMin = dayOffset * 1440 + alarmMin;
          const [ah, am] = alarmTime.split(':').map(Number);
          const alarmDate = new Date(baseDate);
          alarmDate.setHours(ah, am, 0, 0);

          events.push({
            key: prayerKey,
            label: `${p.label} Salah Alarm`,
            timeStr: alarmTime,
            minutesFromNow: totalAlarmMin - currentMinutes,
            targetDate: alarmDate,
            isAlarm: true,
            referencePrayerName: prayerKey,
          });
        }
      } else {
        // Sunrise informational
        events.push({
          key: 'sunrise',
          label: 'Sunrise',
          timeStr: p.time,
          minutesFromNow: totalMin - currentMinutes,
          targetDate: slotDate,
          isAlarm: false,
          referencePrayerName: 'sunrise',
        });
      }
    }
  };

  addSlots(todaySchedule, 0);
  addSlots(tomorrowSchedule, 1);

  // Filter future events
  const futureEvents = events
    .filter(e => e.minutesFromNow > 0)
    .sort((a, b) => a.minutesFromNow - b.minutesFromNow);

  const nextEvent = futureEvents[0] || {
    key: 'fajr',
    label: 'Fajr Adhan',
    timeStr: tomorrowSchedule.fajr,
    minutesFromNow: 300,
    targetDate: new Date(now.getTime() + 5 * 3600 * 1000),
    isAlarm: false,
    referencePrayerName: 'fajr' as PrayerName,
  };

  const timeRemainingMs = Math.max(0, nextEvent.targetDate.getTime() - now.getTime());
  const hours = Math.floor(timeRemainingMs / (1000 * 60 * 60));
  const minutes = Math.floor((timeRemainingMs % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((timeRemainingMs % (1000 * 60)) / 1000);

  const formattedCountdown = `${hours.toString().padStart(2, '0')}:${minutes
    .toString()
    .padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  // Approximate progress towards next prayer (assume 3 to 6 hours between prayers)
  const windowMs = 4 * 60 * 60 * 1000;
  const progressPercent = Math.min(100, Math.max(0, 100 - (timeRemainingMs / windowMs) * 100));

  return {
    prayerName: nextEvent.referencePrayerName,
    label: nextEvent.label,
    targetTime: nextEvent.timeStr,
    targetDate: nextEvent.targetDate,
    isAlarm: nextEvent.isAlarm,
    timeRemainingMs,
    formattedCountdown,
    progressPercent,
  };
}

/**
 * Format Hijri date for display (e.g., '27 Rabi al-Thani 1448 AH').
 */
export function getHijriDate(date: Date): string {
  try {
    const formatter = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
    return formatter.format(date) + ' AH';
  } catch {
    // Fallback approximation for Oct 2026
    const day = date.getDate();
    return `${day + 18} Rabi' al-Thani 1448 AH`;
  }
}
