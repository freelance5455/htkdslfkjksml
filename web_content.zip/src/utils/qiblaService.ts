// Qibla Direction & Distance Calculation Engine (100% Offline & Exact)

export const KAABA_COORDINATES = {
  latitude: 21.422487,
  longitude: 39.826206,
};

export interface QiblaResult {
  bearing: number; // In degrees (0 - 359)
  distanceKm: number;
  directionArabic: string;
}

export interface CityPreset {
  name: string;
  country: string;
  latitude: number;
  longitude: number;
}

export const POPULAR_CITIES: CityPreset[] = [
  { name: 'مكة المكرمة', country: 'السعودية', latitude: 21.4225, longitude: 39.8262 },
  { name: 'المدينة المنورة', country: 'السعودية', latitude: 24.4672, longitude: 39.6111 },
  { name: 'الرياض', country: 'السعودية', latitude: 24.7136, longitude: 46.6753 },
  { name: 'جدة', country: 'السعودية', latitude: 21.5433, longitude: 39.1728 },
  { name: 'القاهرة', country: 'مصر', latitude: 30.0444, longitude: 31.2357 },
  { name: 'الإسكندرية', country: 'مصر', latitude: 31.2001, longitude: 29.9187 },
  { name: 'القدس الشريف', country: 'فلسطين', latitude: 31.7683, longitude: 35.2137 },
  { name: 'عمّان', country: 'الأردن', latitude: 31.9454, longitude: 35.9284 },
  { name: 'دمشق', country: 'سوريا', latitude: 33.5138, longitude: 36.2765 },
  { name: 'بيروت', country: 'لبنان', latitude: 33.8938, longitude: 35.5018 },
  { name: 'بغداد', country: 'العراق', latitude: 33.3152, longitude: 44.3661 },
  { name: 'الكويت', country: 'الكويت', latitude: 29.3759, longitude: 47.9774 },
  { name: 'الدوحة', country: 'قطر', latitude: 25.2854, longitude: 51.5310 },
  { name: 'أبوظبي', country: 'الإمارات', latitude: 24.4539, longitude: 54.3773 },
  { name: 'دبي', country: 'الإمارات', latitude: 25.2048, longitude: 55.2708 },
  { name: 'مسقط', country: 'عُمان', latitude: 23.5880, longitude: 58.3829 },
  { name: 'المنامة', country: 'البحرين', latitude: 26.2285, longitude: 50.5860 },
  { name: 'صنعاء', country: 'اليمن', latitude: 15.3694, longitude: 44.1910 },
  { name: 'طرابلس', country: 'ليبيا', latitude: 32.8872, longitude: 13.1913 },
  { name: 'تونس', country: 'تونس', latitude: 36.8065, longitude: 10.1815 },
  { name: 'الجزائر', country: 'الجزائر', latitude: 36.7538, longitude: 3.0588 },
  { name: 'الرباط', country: 'المغرب', latitude: 34.0209, longitude: -6.8416 },
  { name: 'الدار البيضاء', country: 'المغرب', latitude: 33.5731, longitude: -7.5898 },
  { name: 'الخرطوم', country: 'السودان', latitude: 15.5007, longitude: 32.5599 },
  { name: 'إسطنبول', country: 'تركيا', latitude: 41.0082, longitude: 28.9784 },
  { name: 'أنقرة', country: 'تركيا', latitude: 39.9334, longitude: 32.8597 },
  { name: 'جاكرتا', country: 'إندونيسيا', latitude: -6.2088, longitude: 106.8456 },
  { name: 'كوالالمبور', country: 'ماليزيا', latitude: 3.1390, longitude: 101.6869 },
  { name: 'إسلام آباد', country: 'باكستان', latitude: 33.6844, longitude: 73.0479 },
  { name: 'لندن', country: 'بريطانيا', latitude: 51.5074, longitude: -0.1278 },
  { name: 'باريس', country: 'فرنسا', latitude: 48.8566, longitude: 2.3522 },
  { name: 'برلين', country: 'ألمانيا', latitude: 52.5200, longitude: 13.4050 },
  { name: 'نيويورك', country: 'أمريكا', latitude: 40.7128, longitude: -74.0060 },
];

/**
 * Calculates Great-Circle Qibla azimuth from user coordinates to Kaaba
 */
export function calculateQiblaDirection(userLat: number, userLng: number): QiblaResult {
  const phiK = (KAABA_COORDINATES.latitude * Math.PI) / 180;
  const lambdaK = (KAABA_COORDINATES.longitude * Math.PI) / 180;
  const phi = (userLat * Math.PI) / 180;
  const lambda = (userLng * Math.PI) / 180;

  const deltaLambda = lambdaK - lambda;

  const y = Math.sin(deltaLambda);
  const x = Math.cos(phi) * Math.tan(phiK) - Math.sin(phi) * Math.cos(deltaLambda);

  let qiblaRad = Math.atan2(y, x);
  let qiblaDeg = (qiblaRad * 180) / Math.PI;
  qiblaDeg = (qiblaDeg + 360) % 360;

  // Haversine distance formula
  const earthRadiusKm = 6371;
  const dLat = phiK - phi;
  const dLng = deltaLambda;

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(phi) * Math.cos(phiK) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distanceKm = Math.round(earthRadiusKm * c);

  // Direction in Arabic
  const directionArabic = getDirectionArabic(qiblaDeg);

  return {
    bearing: Math.round(qiblaDeg * 10) / 10,
    distanceKm,
    directionArabic,
  };
}

function getDirectionArabic(deg: number): string {
  if (deg >= 337.5 || deg < 22.5) return 'الشمال';
  if (deg >= 22.5 && deg < 67.5) return 'الشمال الشرقي';
  if (deg >= 67.5 && deg < 112.5) return 'الشرق';
  if (deg >= 112.5 && deg < 157.5) return 'الجنوب الشرقي';
  if (deg >= 157.5 && deg < 202.5) return 'الجنوب';
  if (deg >= 202.5 && deg < 247.5) return 'الجنوب الغربي';
  if (deg >= 247.5 && deg < 292.5) return 'الغرب';
  return 'الشمال الغربي';
}
