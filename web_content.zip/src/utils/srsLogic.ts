export type LanguageCode = 'ja' | 'ko';
export type ItemCategory = 'grammar' | 'vocab' | 'kanji';

export const APP_GATE_PASSWORD = 'YtY.0YinToYou.1YtY';
export const GATE_STORAGE_KEY = 'YTY_SRS_GATE_UNLOCKED_V1';

export function verifyGatePassword(input: string): boolean {
  return String(input ?? '') === APP_GATE_PASSWORD;
}

export interface ExampleSentence {
  jp: string;
  de: string;
}

export interface StudyItem {
  id: string;
  order: number;
  level: string;
  type: ItemCategory;
  jp: string; // Target language script (Japanese or Korean)
  reading: string; // Hiragana/Katakana for JA, Hangul pronunciation/phonetic for KO
  meaning: string; // German meaning
  structure: string; // Always in German!
  explanation: string; // German explanation
  clozeJp: string; // Sentence with [____]
  clozeDe: string; // Complete, gap-free German sentence translation
  answers: string[];
  examples: ExampleSentence[];
}

export interface SrsEntry {
  stage: number;
  nextReview: number;
}

export type TtsVoiceName = 'Kore' | 'Aoede' | 'Puck' | 'Zephyr' | 'Charon' | 'Fenrir';

export interface LangSettings {
  autoKana: boolean; // Auto-Kana for JA, Auto-Hangul for KO
  showRomaji: boolean; // Romaji for JA, Romaja for KO
  autoAudio: boolean;
  ttsVoice?: TtsVoiceName;
  sentenceLength: 'kurz' | 'mittel' | 'lang';
  sentenceDifficulty: 'leicht' | 'mittel' | 'schwer';
  sentenceFormality: 'sehr formell' | 'formell' | 'informell' | 'sehr informell';
}

export interface ReadingPassage {
  title: string;
  jp: string;
  de: string;
  question: string;
  expectedAnswer: string;
  usedItems: string[];
}

export interface WriteTask {
  desc: string;
  targets: string;
}

export interface WriteAttempt {
  task: string;
  userText: string;
  corrected: string;
}

export interface LanguageDeckState {
  items: StudyItem[];
  srs: Record<string, SrsEntry>;
  settings: LangSettings;
  lastWorkingTab: string;
  levelFilter: string;
  catFilter: string;
  reviewCatFilter: string;
  aiGenLevel: string;
  aiGenCat: ItemCategory;
  learnIndex: number;
  currentReading: ReadingPassage | null;
  currentWriteTask: WriteTask | null;
  lastWriteAttempt: WriteAttempt | null;
  homeAiBriefing: string;
  homeEstimatedLevel: string;
  updatedAt: number;
  isExplicitReset: boolean;
}

export interface MultiLangStoragePayload {
  activeLang: LanguageCode;
  googleApiKey?: string;
  decks: {
    ja: LanguageDeckState;
    ko: LanguageDeckState;
  };
  updatedAt: number;
}

export const LEVELS_BY_LANG: Record<LanguageCode, string[]> = {
  ja: ['N5', 'N4', 'N3', 'N2'],
  ko: ['T1', 'T2', 'T3', 'T4'],
};

export const PREMADE_SEED_IDS = new Set([
  'ja-g-temiru',
  'ja-g-tai',
  'ja-v-yakusoku',
  'ja-k-shin',
  'ko-g-aboda',
  'ko-g-gosipda',
  'ko-v-yaksok',
  'ko-k-sin',
]);

export const ANKI_SRS_INTERVALS_MS = [
  0,
  4 * 3600 * 1000, // Stage 1: 4 hours
  12 * 3600 * 1000, // Stage 2: 12 hours
  24 * 3600 * 1000, // Stage 3: 1 day
  3 * 86400 * 1000, // Stage 4: 3 days
  7 * 86400 * 1000, // Stage 5: 7 days (1 week)
  14 * 86400 * 1000, // Stage 6: 14 days (2 weeks)
  30 * 86400 * 1000, // Stage 7: 30 days (1 month)
  90 * 86400 * 1000, // Stage 8: 90 days (3 months)
  180 * 86400 * 1000, // Stage 9+: 180 days (6 months)
];

export const ROMAJI_MAP: Record<string, string> = {
  kya: 'きゃ', kyu: 'きゅ', kyo: 'きょ', sha: 'しゃ', shu: 'しゅ', sho: 'しょ',
  cha: 'ちゃ', chu: 'ちゅ', cho: 'ちょ', nya: 'にゃ', nyu: 'にゅ', nyo: 'にょ',
  hya: 'ひゃ', hyu: 'ひゅ', hyo: 'ひょ', mya: 'みゃ', myu: 'みゅ', myo: 'みょ',
  rya: 'りゃ', ryu: 'りゅ', ryo: 'りょ', gya: 'ぎゃ', gyu: 'ぎゅ', gyo: 'ぎょ',
  ja: 'じゃ', ju: 'じゅ', jo: 'じょ', bya: 'びゃ', byu: 'びゅ', byo: 'びょ',
  pya: 'ぴゃ', pyu: 'ぴゅ', pyo: 'ぴょ',
  shi: 'し', chi: 'ち', tsu: 'つ', fu: 'ふ',
  ka: 'か', ki: 'き', ku: 'く', ke: 'け', ko: 'こ',
  sa: 'さ', su: 'す', se: 'せ', so: 'そ',
  ta: 'た', te: 'て', to: 'と',
  na: 'な', ni: 'に', nu: 'ぬ', ne: 'ね', no: 'の',
  ha: 'は', hi: 'ひ', he: 'へ', ho: 'ほ',
  ma: 'ま', mi: 'み', mu: 'む', me: 'め', mo: 'も',
  ya: 'や', yu: 'ゆ', yo: 'よ',
  ra: 'ら', ri: 'り', ru: 'る', re: 'れ', ro: 'ろ',
  wa: 'わ', wo: 'を', nn: 'ん',
  ga: 'が', gi: 'ぎ', gu: 'ぐ', ge: 'げ', go: 'ご',
  za: 'ざ', ji: 'じ', zu: 'ず', ze: 'ぜ', zo: 'ぞ',
  da: 'だ', di: 'ぢ', du: 'づ', de: 'で', do: 'ど',
  ba: 'ば', bi: 'び', bu: 'ぶ', be: 'べ', bo: 'ぼ',
  pa: 'ぱ', pi: 'ぴ', pu: 'ぷ', pe: 'ぺ', po: 'ぽ',
  a: 'あ', i: 'い', u: 'う', e: 'え', o: 'お',
  '-': 'ー',
};

export function convertRomajiToHiragana(text: string): string {
  if (!text) return '';
  let s = text.toLowerCase();
  s = s.replace(/([bcdfghjklmnpqrstvwxyz])\1/g, (_m, c) => (c === 'n' ? 'ん' : 'っ' + c));
  const keys = Object.keys(ROMAJI_MAP).sort((a, b) => b.length - a.length);
  for (const k of keys) {
    s = s.split(k).join(ROMAJI_MAP[k]);
  }
  return s;
}

const KANA_TO_ROMAJI_MAP: Record<string, string> = (() => {
  const inv: Record<string, string> = {};
  Object.entries(ROMAJI_MAP).forEach(([rom, kana]) => {
    if (!inv[kana] || rom.length < inv[kana].length) inv[kana] = rom;
  });
  inv['ん'] = 'n';
  return inv;
})();

export function convertKanaToRomaji(text: string): string {
  if (!text) return '';
  let res = String(text);
  const kanaKeys = Object.keys(KANA_TO_ROMAJI_MAP).sort((a, b) => b.length - a.length);
  for (const k of kanaKeys) {
    res = res.split(k).join(KANA_TO_ROMAJI_MAP[k]);
  }
  res = res.replace(/っ([bcdfghjklmnpqrstvwxyz])/g, '$1$1');
  return res;
}

// Korean Hangul <-> Revised Romanization utilities
const CHO_ROMAN = ['g', 'kk', 'n', 'd', 'tt', 'r', 'm', 'b', 'pp', 's', 'ss', '', 'j', 'jj', 'ch', 'k', 't', 'p', 'h'];
const JUNG_ROMAN = ['a', 'ae', 'ya', 'yae', 'eo', 'e', 'yeo', 'ye', 'o', 'wa', 'wae', 'oe', 'yo', 'u', 'wo', 'we', 'wi', 'yu', 'eu', 'ui', 'i'];
const JONG_ROMAN = ['', 'k', 'k', 'ks', 'n', 'nj', 'nh', 't', 'l', 'lk', 'lm', 'lb', 'ls', 'lt', 'lp', 'lh', 'm', 'p', 'ps', 't', 't', 'ng', 't', 't', 'k', 't', 'p', 't'];

export function convertHangulToRoman(text: string): string {
  if (!text) return '';
  let out = '';
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    if (code >= 0xac00 && code <= 0xd7a3) {
      const offset = code - 0xac00;
      const cho = Math.floor(offset / (21 * 28));
      const jung = Math.floor((offset % (21 * 28)) / 28);
      const jong = offset % 28;
      out += (CHO_ROMAN[cho] || '') + (JUNG_ROMAN[jung] || '') + (JONG_ROMAN[jong] || '');
    } else {
      out += text[i];
    }
  }
  return out;
}

const SYLLABLE_ROMAN_MAP: Record<string, string> = (() => {
  const map: Record<string, string> = {};
  for (let cho = 0; cho < 19; cho++) {
    for (let jung = 0; jung < 21; jung++) {
      for (let jong = 0; jong < 28; jong++) {
        const rom = (CHO_ROMAN[cho] || '') + (JUNG_ROMAN[jung] || '') + (JONG_ROMAN[jong] || '');
        if (rom && !map[rom]) {
          map[rom] = String.fromCharCode(0xac00 + cho * 21 * 28 + jung * 28 + jong);
        }
      }
    }
  }
  map['ha'] = '하';
  map['hae'] = '해';
  map['yo'] = '요';
  map['yeo'] = '여';
  map['ga'] = '가';
  map['na'] = '나';
  map['da'] = '다';
  map['ra'] = '라';
  map['ma'] = '마';
  map['ba'] = '바';
  map['sa'] = '사';
  map['ja'] = '자';
  map['cha'] = '차';
  map['ka'] = '카';
  map['ta'] = '타';
  map['pa'] = '파';
  map['seo'] = '서';
  map['meo'] = '머';
  map['geo'] = '거';
  map['deu'] = '드';
  map['seu'] = '스';
  map['an'] = '안';
  map['nyeong'] = '녕';
  map['se'] = '세';
  return map;
})();

export function convertRomanToHangul(text: string): string {
  if (!text) return '';
  if (!/[a-zA-Z]/.test(text)) return text;
  const lower = text.toLowerCase();
  if (SYLLABLE_ROMAN_MAP[lower]) {
    return SYLLABLE_ROMAN_MAP[lower];
  }
  return text;
}

export function convertScriptToRoman(text: string, lang: LanguageCode): string {
  return lang === 'ko' ? convertHangulToRoman(text) : convertKanaToRomaji(text);
}

export function stripRomajiFromText(text: string, showRomaji = false): string {
  if (!text || showRomaji) return text || '';
  return String(text)
    .replace(/\s*\([a-zA-ZāēīōūĀĒĪŌŪ\s\-'/]+\)/g, '')
    .replace(/\s*\[[a-zA-ZāēīōūĀĒĪŌŪ\s\-'/]+\]/g, '')
    .trim();
}

/**
 * Ensures the grammar/vocabulary structure ("Struktur") is written in German,
 * replacing Japanese or Korean grammatical metalanguage with German equivalents.
 */
export function ensureGermanStructure(
  structure: string,
  type: ItemCategory = 'grammar',
  meaning = '',
  jp = ''
): string {
  const raw = String(structure || '').trim();
  if (!raw) {
    if (type === 'vocab') return `Wort (${jp || meaning || 'Vokabel'})`;
    if (type === 'kanji') return `Zeichen (${jp || meaning || 'Schriftzeichen'})`;
    return `Satzmuster mit ${jp}`;
  }

  const s = raw
    .replace(/動詞ます形/g, 'Verb (Masu-Stamm)')
    .replace(/動詞て形/g, 'Verb (Te-Form)')
    .replace(/動詞ない形/g, 'Verb (Nai-Form)')
    .replace(/動詞た形/g, 'Verb (Ta-Form)')
    .replace(/動詞辞書形/g, 'Verb (Wörterbuchform)')
    .replace(/動詞普通形/g, 'Verb (Grundform)')
    .replace(/動詞可能形/g, 'Verb (Potenzialform)')
    .replace(/動詞意志形/g, 'Verb (Volitionalform)')
    .replace(/い形容詞/g, 'I-Adjektiv')
    .replace(/な形容詞/g, 'Na-Adjektiv')
    .replace(/形容詞/g, 'Adjektiv')
    .replace(/名詞/g, 'Substantiv')
    .replace(/動詞/g, 'Verb')
    .replace(/副詞/g, 'Adverb')
    .replace(/普通形/g, 'Grundform (Plain Form)')
    .replace(/辞書形/g, 'Wörterbuchform')
    .replace(/ます形/g, 'Masu-Stamm')
    .replace(/て形/g, 'Te-Form')
    .replace(/ない形/g, 'Nai-Form')
    .replace(/た形/g, 'Ta-Form')
    .replace(/語幹/g, 'Wortstamm')
    .replace(/동사/g, 'Verb')
    .replace(/형용사/g, 'Adjektiv')
    .replace(/명사/g, 'Substantiv')
    .replace(/어간/g, 'Verbstamm')
    .replace(/받침/g, 'Batchim (Endkonsonant)')
    .replace(/＋/g, ' + ');

  if (!/[a-zA-ZäöüÄÖÜß]/.test(s)) {
    if (type === 'vocab') {
      return `Vokabel im Satz: ${s}`;
    }
    if (type === 'kanji') {
      return `Schriftzeichen-Verbindung: ${s}`;
    }
    return `Verbindung: Wortstamm + ${s}`;
  }

  return s;
}

/**
 * Ensures the German translation (clozeDe) is a complete, natural German sentence
 * with NO blanks ([____] or ___) and NO missing trailing verbs (such as "Ich werde ihn mal.").
 */
export function ensureCompleteGermanTranslation(
  clozeDe: string,
  meaning = '',
  showRomaji = false
): string {
  let clean = stripRomajiFromText(clozeDe || '', showRomaji).trim();
  const cleanMeaning = stripRomajiFromText(meaning || '', showRomaji)
    .split(/[,;/]/)[0]
    .replace(/^(etw\.|jmdn\.|jmdm\.|zu)\s+/i, '')
    .trim();

  if (!clean) {
    return cleanMeaning ? `Bedeutung im Satz: ${cleanMeaning}.` : '';
  }

  if (/\[____\]|_{2,}|\(\s*\)|\[\s*\]/.test(clean)) {
    clean = clean
      .replace(/\[____\]|_{2,}|\(\s*\)|\[\s*\]/g, cleanMeaning || 'es')
      .replace(/\s+/g, ' ')
      .trim();
  }

  const incompleteModalPattern =
    /\b(werde|wirst|wird|werden|werdet|möchte|möchtest|möchten|will|willst|wollen|kann|kannst|können|muss|musst|müssen|soll|sollst|sollen)(?:\s+(?:ihn|sie|es|dich|mich|uns|euch|dir|mir|ihm|ihr|heute|morgen|jetzt|gleich|später|mal|noch|schon|gern|gerne))+\s*[.!?]?$/i;

  if (incompleteModalPattern.test(clean) && cleanMeaning) {
    const withoutPunct = clean.replace(/[.!?]+$/, '').trim();
    const punct = (clean.match(/[.!?]+$/) || ['.'])[0];
    const fallbackVerb =
      /^[a-zA-ZäöüÄÖÜß\s]+$/.test(cleanMeaning) && !/^mal\b/i.test(cleanMeaning)
        ? cleanMeaning.toLowerCase()
        : 'ansprechen (versuchen)';
    clean = `${withoutPunct} ${fallbackVerb}${punct}`;
  }

  return clean;
}

export function normalizeTargetKey(str: string): string {
  if (!str) return '';
  return String(str)
    .trim()
    .replace(/^[～〜~\-\s]+|[～〜~\-\s]+$/g, '')
    .replace(/\s+/g, '')
    .toLowerCase();
}

export function isLocalMatch(item: StudyItem, rawVal: string, convertedVal: string): boolean {
  const cleanRaw = rawVal.replace(/[。、！？.!?\s]/g, '').toLowerCase();
  const cleanConv = convertedVal.replace(/[。、！？.!?\s]/g, '').toLowerCase();
  if (!cleanRaw) return false;

  for (const ans of item.answers || []) {
    const cleanAns = ans.replace(/[。、！？.!?\s]/g, '').toLowerCase();
    if (!cleanAns) continue;
    if (cleanRaw === cleanAns || cleanConv === cleanAns) return true;
    if (item.clozeJp) {
      const fullSentence = item.clozeJp
        .replace('[____]', ans)
        .replace(/[。、！？.!?\s]/g, '')
        .toLowerCase();
      if (cleanRaw === fullSentence || cleanConv === fullSentence) return true;
    }
  }
  return false;
}

export function calculateNextSrs(
  current: SrsEntry | undefined,
  isCorrect: boolean,
  now = Date.now()
): SrsEntry {
  const baseStage = current?.stage || 1;
  if (isCorrect) {
    const nextStage = Math.min(9, baseStage + 1);
    const interval = ANKI_SRS_INTERVALS_MS[Math.min(nextStage, ANKI_SRS_INTERVALS_MS.length - 1)];
    return {
      stage: nextStage,
      nextReview: now + interval,
    };
  } else {
    const nextStage = Math.max(1, baseStage - 1);
    return {
      stage: nextStage,
      nextReview: now + 60 * 1000,
    };
  }
}

export function buildExpressiveTtsStyle(text: string, lang: LanguageCode): string {
  const clean = String(text || '').trim();
  const isQuestion = /[？?]$/.test(clean) || (lang === 'ja' ? /か[。.]?$/.test(clean) : /까[요.]?$/.test(clean));
  const isExclamation = /[！!]$/.test(clean);

  if (lang === 'ko') {
    if (isQuestion) {
      return 'Natural, expressive native Korean speaker asking a genuine conversational question with authentic rising intonation, clear syllable stress, and warm human cadence';
    }
    if (isExclamation) {
      return 'Lively, expressive native Korean speaker with warm emotional emphasis, natural conversational rhythm, and dynamic prosody';
    }
    return 'Warm, natural, expressive native Korean speaker with authentic prosody, clear phrase-level emphasis, and lifelike conversational flow';
  }

  if (isQuestion) {
    return 'Natural, expressive native Japanese speaker asking a genuine conversational question with authentic Tokyo pitch accent, natural rising intonation at the end, and warm human cadence';
  }
  if (isExclamation) {
    return 'Lively, expressive native Japanese speaker with authentic Tokyo pitch accent, warm emotional emphasis, and dynamic conversational energy';
  }
  return 'Warm, natural, expressive native Japanese speaker with authentic Tokyo pitch accent, clear sentence-level emphasis on key words, and lifelike conversational flow';
}

export function createDefaultLangDeck(lang: LanguageCode, emptyReset = false): LanguageDeckState {
  const defaultLevel = lang === 'ko' ? 'T1' : 'N5';
  const now = Date.now();

  return {
    items: [],
    srs: {},
    settings: {
      autoKana: true,
      showRomaji: false,
      autoAudio: true,
      ttsVoice: 'Kore',
      sentenceLength: 'mittel',
      sentenceDifficulty: 'mittel',
      sentenceFormality: 'informell',
    },
    lastWorkingTab: 'learn',
    levelFilter: 'ALL',
    catFilter: 'ALL',
    reviewCatFilter: 'ALL',
    aiGenLevel: defaultLevel,
    aiGenCat: 'grammar',
    learnIndex: 0,
    currentReading: null,
    currentWriteTask: null,
    lastWriteAttempt: null,
    homeAiBriefing: '',
    homeEstimatedLevel: '',
    updatedAt: now,
    isExplicitReset: emptyReset,
  };
}
