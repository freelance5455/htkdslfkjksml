import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseAndNormalizeBarcode,
  parseGs1ExpiryDate,
  findMatchingBarcodeKey,
} from './barcodeUtils.ts';

test('parseAndNormalizeBarcode handles standard EAN-13 and UPC-A leading zeros', () => {
  const res13 = parseAndNormalizeBarcode(' 6291100123456 ');
  assert.equal(res13.normalizedBarcode, '6291100123456');

  const resUpc = parseAndNormalizeBarcode('012345678905');
  assert.ok(resUpc.alternateBarcodes.includes('012345678905'));
  assert.ok(resUpc.alternateBarcodes.includes('0012345678905'));
});

test('parseAndNormalizeBarcode extracts EAN-13 and Expiry Date from GS1 DataMatrix', () => {
  const gs1Raw = ']d201062911001234561727060010BATCH99';
  const parsed = parseAndNormalizeBarcode(gs1Raw);
  assert.equal(parsed.normalizedBarcode, '6291100123456');
  assert.equal(parsed.expiryDate, '2027-06-30');
  assert.equal(parsed.batchNumber, 'BATCH99');
});

test('parseGs1ExpiryDate converts YYMMDD and handles DD=00 end of month', () => {
  assert.equal(parseGs1ExpiryDate('261215'), '2026-12-15');
  assert.equal(parseGs1ExpiryDate('270200'), '2027-02-28');
});

test('findMatchingBarcodeKey matches across leading zero and GS1 variations', () => {
  const medicines = [
    {
      id: 'm1',
      barcode: '6291100123456',
      name: 'Panadol Extra',
      unit: 'باكيت',
      minStockAlert: 10,
    },
  ];
  const stocks = {};

  assert.equal(
    findMatchingBarcodeKey('010629110012345617271231', medicines, stocks),
    '6291100123456'
  );
  assert.equal(
    findMatchingBarcodeKey('06291100123456', medicines, stocks),
    '6291100123456'
  );
});
