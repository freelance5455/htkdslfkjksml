// Advanced Context, Relative Time, and Priority Reasoning Engine for Habivio AI Assistant
// Capable of deducing intent from Bengali commands like "দুপুরে খাবার তিরিশ মিনিট আগে আমাকে ওষুধ খেতে হবে"

export interface UserRoutineMemory {
  breakfastTime: string; // "08:00"
  lunchTime: string;     // "13:30"
  dinnerTime: string;    // "20:30"
  bedtime: string;       // "23:00"
  jummahTime: string;    // "13:15"
  learnedItems: Array<{ key: string; time: string; note: string; updatedAt: string }>;
}

const STORAGE_KEY_ROUTINES = 'habivio_ai_learned_routines';

export function getLearnedRoutines(): UserRoutineMemory {
  if (typeof window === 'undefined') {
    return {
      breakfastTime: '08:00',
      lunchTime: '13:30',
      dinnerTime: '20:30',
      bedtime: '23:00',
      jummahTime: '13:15',
      learnedItems: [],
    };
  }

  try {
    const data = localStorage.getItem(STORAGE_KEY_ROUTINES);
    if (data) {
      return JSON.parse(data);
    }
  } catch {
    // ignore
  }

  return {
    breakfastTime: '08:00',
    lunchTime: '13:30',
    dinnerTime: '20:30',
    bedtime: '23:00',
    jummahTime: '13:15',
    learnedItems: [],
  };
}

export function saveLearnedRoutines(memory: UserRoutineMemory): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_ROUTINES, JSON.stringify(memory));
  } catch {
    // ignore
  }
}

// Convert "HH:MM" to minutes from 00:00
function timeToMinutes(t: string): number {
  const [h, m] = t.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

// Convert minutes from 00:00 back to "HH:MM"
function minutesToTime(totalMins: number): string {
  let normalized = totalMins % 1440;
  if (normalized < 0) normalized += 1440;
  const h = Math.floor(normalized / 60);
  const m = normalized % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

// Bengali word numerals to integer minutes
function extractOffsetMinutes(text: string): number {
  const t = text.toLowerCase();
  if (t.includes('এক ঘণ্টা') || t.includes('১ ঘণ্টা') || t.includes('1 hour') || t.includes('60 min')) return 60;
  if (t.includes('আধা ঘণ্টা') || t.includes('আধ ঘণ্টা') || t.includes('30 min')) return 30;
  if (t.includes('পঁয়তাল্লিশ') || t.includes('পয়তাল্লিশ') || t.includes('৪৫') || t.includes('45')) return 45;
  if (t.includes('তিরিশ') || t.includes('ত্রিশ') || t.includes('৩০') || t.includes('30')) return 30;
  if (t.includes('পঁচিশ') || t.includes('২৫') || t.includes('25')) return 25;
  if (t.includes('বিশ') || t.includes('বিস') || t.includes('২০') || t.includes('20')) return 20;
  if (t.includes('পনেরো') || t.includes('১৫') || t.includes('15')) return 15;
  if (t.includes('দশ') || t.includes('১০') || t.includes('10')) return 10;
  if (t.includes('পাঁচ') || t.includes('৫') || t.includes('5')) return 5;

  const match = t.match(/(\d+)\s*(মিনিট|min)/);
  if (match) {
    return parseInt(match[1], 10);
  }
  return 30; // default 30 minutes if relative but not specified
}

export interface ParsedAIReasoningResult {
  isMatch: boolean;
  intent: 'relative_alarm' | 'prayer_action' | 'task_action' | 'habit_action' | 'goal_action' | 'security_action' | 'weather_advice' | 'general';
  replyBn: string;
  replyEn: string;
  proposedAction?: {
    id: string;
    type: 'create_task' | 'create_habit' | 'create_goal' | 'log_prayer' | 'complete_task' | 'reschedule_task';
    title: string;
    description: string;
    payload: any;
  };
}

export function parseNaturalLanguageIntent(
  text: string,
  isBn: boolean
): ParsedAIReasoningResult {
  const raw = text.trim();
  const lower = raw.toLowerCase();
  const routines = getLearnedRoutines();

  // Action 1: "কাজ যুক্ত করুন" / "Organize today or plan an upcoming milestone"
  if (
    lower.includes('কাজ যুক্ত করুন') ||
    lower.includes('কাজ যুক্ত করো') ||
    lower.includes('নতুন কাজ') ||
    lower.includes('organize today') ||
    lower.includes('plan an upcoming milestone') ||
    lower.includes('plan milestone') ||
    (lower.includes('task') && (lower.includes('add') || lower.includes('create')))
  ) {
    const taskTitle = isBn
      ? 'আজকের গুরুত্বপূর্ণ মাইলস্টোন ও কাজের পরিকল্পনা'
      : 'Organize Today & Milestone Execution';
    const dueTime = '11:00';
    return {
      isMatch: true,
      intent: 'task_action',
      replyBn: `আমি এক কথায় আপনার জন্য নতুন কাজ ও মাইলস্টোন প্রস্তুত করেছি:
• শিরোনাম: ${taskTitle}
• সময়: সকাল ১১:০০ টা (11:00 AM)
• অগ্রাধিকার: 🔴 High Priority
• অ্যালার্ম: উচ্চ সাইরেন সহ পূর্ণাঙ্গ নোটিফিকেশন প্রস্তুত।
নিচের বাটনে এক ট্যাপে অনুমোদন দিন:`,
      replyEn: `Prepared new task & milestone from your single-sentence command:
• Title: ${taskTitle}
• Time: 11:00 AM
• Priority: High Urgency
• Alarm: Loud siren scheduled with screen wake.
Approve with one tap below:`,
      proposedAction: {
        id: `act-task-${Date.now()}`,
        type: 'create_task',
        title: taskTitle,
        description: isBn
          ? 'আজকের দিনের মাইলস্টোন ও নির্ধারিত কাজের কর্মপরিকল্পনা।'
          : 'Organize today or plan an upcoming milestone with alert.',
        payload: {
          title: taskTitle,
          dueTime,
          priority: 'high',
          category: 'work',
          alarmEnabled: true,
          alarmMinutesBefore: 5,
          ringtone: 'emergency_siren',
        },
      },
    };
  }

  // Action 2: "নতুন অভ্যাস" / "Track daily disciplines & streak momentum"
  if (
    lower.includes('নতুন অভ্যাস') ||
    lower.includes('অভ্যাস যুক্ত') ||
    lower.includes('অভ্যাস গড়ুন') ||
    lower.includes('track daily disciplines') ||
    lower.includes('streak momentum') ||
    (lower.includes('habit') && (lower.includes('new') || lower.includes('create') || lower.includes('track')))
  ) {
    const habitTitle = isBn
      ? 'প্রতিদিনের বিশেষ আত্ম-উন্নয়ন ও শারীরিক শৃঙ্খলা'
      : 'Daily Discipline & Streak Momentum';
    return {
      isMatch: true,
      intent: 'habit_action',
      replyBn: `আপনার এক কথায় নতুন অভ্যাস ট্র্যাকিং প্রস্তুত করা হয়েছে:
• শিরোনাম: ${habitTitle}
• ক্যাটাগরি: 🧘‍♂️ আত্ম-উন্নয়ন ও ওয়েলনেস (Wellness)
• রিমাইন্ডার: সকাল ০৬:৩০ AM
• লক্ষ্য: প্রতিদিন স্ট্রিক মোমেন্টাম বৃদ্ধি
অনুমোদন দিলে এটি আপনার অভ্যাসের ড্যাশবোর্ডে যুক্ত হবে:`,
      replyEn: `Prepared new daily habit discipline from your command:
• Title: ${habitTitle}
• Category: Wellness & Focus
• Frequency: Daily at 06:30 AM
• Target: Consistent streak momentum
Approve below to activate:`,
      proposedAction: {
        id: `act-habit-${Date.now()}`,
        type: 'create_habit',
        title: habitTitle,
        description: isBn
          ? 'দৈনন্দিন শৃঙ্খলা ও স্ট্রিক মোমেন্টাম ট্র্যাকিং।'
          : 'Track daily disciplines & streak momentum.',
        payload: {
          title: habitTitle,
          category: 'wellness',
          frequency: 'daily',
          targetCount: 1,
          reminderTime: '06:30',
        },
      },
    };
  }

  // Action 3: "নতুন লক্ষ্য" / "Set ambitious targets with actionable milestones"
  if (
    lower.includes('নতুন লক্ষ্য') ||
    lower.includes('লক্ষ্য যুক্ত') ||
    lower.includes('লক্ষ্য নির্ধারণ') ||
    lower.includes('set ambitious targets') ||
    lower.includes('actionable milestones') ||
    (lower.includes('goal') && (lower.includes('new') || lower.includes('create') || lower.includes('ambitious')))
  ) {
    const goalTitle = isBn
      ? '৯০ দিনের ব্যক্তিগত উৎকর্ষতা ও মাইলস্টোন লক্ষ্য'
      : '90-Day Ambitious Target & Milestone';
    const targetDate = new Date(Date.now() + 90 * 86400000).toISOString().split('T')[0];
    return {
      isMatch: true,
      intent: 'goal_action',
      replyBn: `আপনার নির্দেশ অনুযায়ী মাইলস্টোন সহ উচ্চাভিলাষী নতুন লক্ষ্য প্রস্তুত করা হয়েছে:
• লক্ষ্য: ${goalTitle}
• সময়সীমা: পরবর্তী ৯০ দিন (${targetDate})
• মাইলস্টোনসমূহ:
  ১. সুস্পষ্ট লক্ষ্য ও রোডম্যাপ প্রণয়ন (সম্পন্ন)
  ২. নিয়মিত ৫০% বাস্তবায়ন ও অগ্রগতি
  ৩. চূড়ান্ত ফলাফল ও লক্ষ্য অর্জন
অনুমোদন দিলে এটি লক্ষ্য তালিকায় কার্যকর হবে:`,
      replyEn: `Prepared ambitious goal with actionable milestones:
• Goal: ${goalTitle}
• Timeline: 90 Days (${targetDate})
• Actionable Milestones:
  1. Roadmap and strategy drafted (Done)
  2. 50% milestone execution in progress
  3. Final mastery & goal completion
Approve below to activate:`,
      proposedAction: {
        id: `act-goal-${Date.now()}`,
        type: 'create_goal',
        title: goalTitle,
        description: isBn
          ? 'পরবর্তী ৯০ দিনের মাইলস্টোন সহ লক্ষ্য নির্ধারণ।'
          : 'Set ambitious targets with actionable milestones.',
        payload: {
          title: goalTitle,
          category: 'growth',
          targetDate,
          milestones: [
            { id: `m1-${Date.now()}`, title: isBn ? '১. কৌশল ও স্পষ্ট রূপরেখা তৈরি' : '1. Roadmap & Strategy', completed: true },
            { id: `m2-${Date.now()}`, title: isBn ? '২. নিয়মিত বাস্তবায়ন ও অগ্রগতি' : '2. Execution & Consistency', completed: false },
            { id: `m3-${Date.now()}`, title: isBn ? '৩. চূড়ান্ত মূল্যায়ন ও লক্ষ্য জয়' : '3. Final Mastery & Target', completed: false },
          ],
          progress: 33,
        },
      },
    };
  }

  // Action 4: "নামাজ আদায় রেকর্ড করুন" / "Track 5 daily prayers, Quran & Dhikr"
  if (
    lower.includes('নামাজ আদায় রেকর্ড') ||
    lower.includes('নামাজ রেকর্ড') ||
    lower.includes('track 5 daily prayers') ||
    lower.includes('quran & dhikr') ||
    lower.includes('নামাজ পড়েছি') ||
    lower.includes('নামাজ আদায় করেছি') ||
    lower.includes('নামাজ মার্ক') ||
    lower.includes('ফজর আদায়') ||
    lower.includes('যোহর আদায়') ||
    lower.includes('জুম্মা আদায়') ||
    lower.includes('আসর আদায়') ||
    lower.includes('মাগরিব আদায়') ||
    lower.includes('এশা আদায়')
  ) {
    // Detect specific waqt mentioned or pick current time waqt
    const currentHour = new Date().getHours();
    let prayerKey: 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha' = 'dhuhr';
    let prayerLabelBn = 'যোহর / জুম্মা';
    let prayerLabelEn = 'Dhuhr / Jummah';

    if (lower.includes('ফজর')) {
      prayerKey = 'fajr';
      prayerLabelBn = 'ফজর';
      prayerLabelEn = 'Fajr';
    } else if (lower.includes('যোহর') || lower.includes('জুম্মা')) {
      prayerKey = 'dhuhr';
      prayerLabelBn = 'যোহর / জুম্মা';
      prayerLabelEn = 'Dhuhr / Jummah';
    } else if (lower.includes('আসর')) {
      prayerKey = 'asr';
      prayerLabelBn = 'আসর';
      prayerLabelEn = 'Asr';
    } else if (lower.includes('মাগরিব')) {
      prayerKey = 'maghrib';
      prayerLabelBn = 'মাগরিব';
      prayerLabelEn = 'Maghrib';
    } else if (lower.includes('এশা')) {
      prayerKey = 'isha';
      prayerLabelBn = 'এশা';
      prayerLabelEn = 'Isha';
    } else {
      // Pick according to hour
      if (currentHour < 6) {
        prayerKey = 'fajr';
        prayerLabelBn = 'ফজর';
        prayerLabelEn = 'Fajr';
      } else if (currentHour < 15) {
        prayerKey = 'dhuhr';
        prayerLabelBn = 'যোহর / জুম্মা';
        prayerLabelEn = 'Dhuhr / Jummah';
      } else if (currentHour < 18) {
        prayerKey = 'asr';
        prayerLabelBn = 'আসর';
        prayerLabelEn = 'Asr';
      } else if (currentHour < 20) {
        prayerKey = 'maghrib';
        prayerLabelBn = 'মাগরিব';
        prayerLabelEn = 'Maghrib';
      } else {
        prayerKey = 'isha';
        prayerLabelBn = 'এশা';
        prayerLabelEn = 'Isha';
      }
    }

    return {
      isMatch: true,
      intent: 'prayer_action',
      replyBn: `আলহামদুলিল্লাহ! আপনার নির্দেশ অনুযায়ী আজকের ${prayerLabelBn} নামাজের আদায় ও ইবাদত রেকর্ড প্রস্তুত করা হয়েছে।
• সালাত: ${prayerLabelBn} নামাজ আদায় সম্পন্ন
• ইবাদত মোমেন্টাম: ৫ ওয়াক্ত নামাজের ধারাবাহিকতা ও তাসবীহ
অনুমোদন দিলে রেকর্ডটি তাৎক্ষণিকভাবে ড্যাশবোর্ডে মার্ক হয়ে যাবে:`,
      replyEn: `Alhamdulillah! Prepared ${prayerLabelEn} prayer & worship completion log from your instruction:
• Prayer: ${prayerLabelEn} Salaah marked
• Momentum: 5 daily prayers & Dhikr tracker updated
Approve below to log:`,
      proposedAction: {
        id: `act-prayer-${Date.now()}`,
        type: 'log_prayer',
        title: isBn ? `${prayerLabelBn} নামাজ আদায় রেকর্ড` : `Log ${prayerLabelEn} Prayer & Dhikr`,
        description: isBn
          ? `আজকের ${prayerLabelBn} নামাজ ও ইবাদত সফলভাবে সম্পন্ন হিসেবে চিহ্নিত করা হবে।`
          : `Marks ${prayerLabelEn} prayer as fulfilled in today's 5 daily prayers.`,
        payload: {
          prayerKey,
        },
      },
    };
  }

  // Pattern 1: Relative Timing with High Priority (e.g. "দুপুরে খাবার তিরিশ মিনিট আগে আমাকে ওষুধ খেতে হবে")
  const isMedicine =
    lower.includes('ওষুধ') ||
    lower.includes('ঔষধ') ||
    lower.includes('মেডিসিন') ||
    lower.includes('ট্যাবলেট') ||
    lower.includes('ক্যাপসুল') ||
    lower.includes('medicine') ||
    lower.includes('pill');

  const isLunch = lower.includes('দুপুর') || lower.includes('খাবার') || lower.includes('লাঞ্চ') || lower.includes('lunch');
  const isDinner = lower.includes('রাত') || lower.includes('ডিনার') || lower.includes('dinner');
  const isBreakfast = lower.includes('সকাল') || lower.includes('নাস্তা') || lower.includes('ব্রেকফাস্ট') || lower.includes('breakfast');
  const isBedtime = lower.includes('ঘুমানো') || lower.includes('ঘুমানোর') || lower.includes('ঘুম') || lower.includes('bedtime');
  const isJummah = lower.includes('জুম্মা') || lower.includes('জুম্মার') || lower.includes('jummah');

  const isRelative = lower.includes('আগে') || lower.includes('পূর্বে') || lower.includes('before') || lower.includes('পূর্বে');

  if ((isLunch || isDinner || isBreakfast || isBedtime || isJummah) && (isRelative || isMedicine)) {
    let anchorTime = routines.lunchTime;
    let anchorLabelBn = 'দুপুরের খাবার (১:৩০ PM)';
    let anchorLabelEn = 'Lunch (1:30 PM)';

    if (isBreakfast) {
      anchorTime = routines.breakfastTime;
      anchorLabelBn = 'সকালের নাস্তা (০৮:০০ AM)';
      anchorLabelEn = 'Breakfast (08:00 AM)';
    } else if (isDinner) {
      anchorTime = routines.dinnerTime;
      anchorLabelBn = 'রাতের খাবার (০৮:৩০ PM)';
      anchorLabelEn = 'Dinner (08:30 PM)';
    } else if (isBedtime) {
      anchorTime = routines.bedtime;
      anchorLabelBn = 'ঘুমানোর সময় (১১:০০ PM)';
      anchorLabelEn = 'Bedtime (11:00 PM)';
    } else if (isJummah) {
      anchorTime = routines.jummahTime;
      anchorLabelBn = 'জুম্মার নামাজ (০১:১৫ PM)';
      anchorLabelEn = 'Jummah Prayer (01:15 PM)';
    }

    const offsetMinutes = extractOffsetMinutes(lower);
    const anchorMins = timeToMinutes(anchorTime);
    const calculatedMins = anchorMins - offsetMinutes;
    const dueTime = minutesToTime(calculatedMins);

    // Determine category & priority
    const category = isMedicine ? 'health' : isJummah ? 'worship' : 'routine';
    const priority = isMedicine ? 'high' : 'high';
    const taskTitle = isMedicine
      ? (isLunch ? 'দুপুরের খাবার পূর্বে ওষুধ গ্রহণ' : isDinner ? 'রাতের খাবার পূর্বে ওষুধ গ্রহণ' : 'ঔষধ গ্রহণ')
      : isJummah ? 'জুম্মার প্রস্তুতি ও গোসল' : raw;

    const ringtone = isMedicine ? 'emergency_siren' : isJummah ? 'adhan_spiritual' : 'classic_beep';

    // Save/update learned routine memory
    const updatedMemory: UserRoutineMemory = {
      ...routines,
      learnedItems: [
        {
          key: isMedicine ? 'medicine_schedule' : 'relative_schedule',
          time: dueTime,
          note: `${offsetMinutes} mins before ${anchorTime}`,
          updatedAt: new Date().toISOString(),
        },
        ...routines.learnedItems.filter((i) => i.key !== (isMedicine ? 'medicine_schedule' : 'relative_schedule')),
      ],
    };
    saveLearnedRoutines(updatedMemory);

    const [dueH, dueM] = dueTime.split(':').map(Number);
    const period = dueH >= 12 ? 'পিএম' : 'এএম';
    const periodEn = dueH >= 12 ? 'PM' : 'AM';
    const h12 = dueH % 12 === 0 ? 12 : dueH % 12;

    const replyBn = `আমি আপনার নির্দেশের প্রেক্ষাপট ও গুরুত্ব বুদ্ধিমত্তার সাথে বিশ্লেষণ করেছি:
• কাজের ধরন: ${isMedicine ? '💊 জরুরি স্বাস্থ্য ও ঔষধ সেবন' : '📋 গুরুত্বপূর্ণ নির্ধারিত রুটিন'}
• অগ্রাধিকার স্তর: 🔴 সর্বোচ্চ জরুরি (High Priority)
• স্বয়ংক্রিয় সময় নির্ধারণ: আপনার ${anchorLabelBn} হতে ${offsetMinutes} মিনিট পূর্বে — ঠিক ${dueH}:${dueM < 10 ? '0' + dueM : dueM} (${h12}:${dueM < 10 ? '0' + dueM : dueM} ${period})
• অ্যালার্ম ব্যবস্থা: লক স্ক্রিন সহ উচ্চ সুরের "${isMedicine ? 'জরুরি সাইরেন' : 'অ্যালার্ম'}" প্রস্তুত করা হয়েছে।
• ভবিষ্যৎ আপডেট: এই রুটিনটি ভবিষ্যতে আপনার অগ্রাধিকার হিসেবে এআই মেমোরিতে সংরক্ষণ করা হয়েছে।

নিচের বাটনে ট্যাপ করে অনুমোদন দিন:`;

    const replyEn = `I have analyzed your instruction:
• Category: ${isMedicine ? '💊 Critical Health & Medicine' : '📋 High Priority Routine'}
• Priority Level: 🔴 High Urgency
• Calculated Time: ${offsetMinutes} mins prior to ${anchorLabelEn} — exactly at ${dueTime} (${h12}:${dueM < 10 ? '0' + dueM : dueM} ${periodEn})
• Alarm Action: Lock-screen loud alarm scheduled.
• Future Adaptation: Routine saved to AI memory for adaptive updates.

Please approve below to activate:`;

    return {
      isMatch: true,
      intent: 'relative_alarm',
      replyBn,
      replyEn,
      proposedAction: {
        id: `act-smart-${Date.now()}`,
        type: 'create_task',
        title: taskTitle,
        description: isBn
          ? `${anchorLabelBn} হতে ${offsetMinutes} মিনিট পূর্বে (${dueTime} এ) নির্ধারিত অ্যালার্ম সহ কাজ।`
          : `Scheduled task with loud alarm at ${dueTime} (${offsetMinutes} mins prior to ${anchorLabelEn}).`,
        payload: {
          title: taskTitle,
          dueTime,
          priority,
          category,
          alarmEnabled: true,
          alarmMinutesBefore: 0,
          ringtone,
        },
      },
    };
  }

  // Pattern 2: Explicit Time Alarm (e.g. "কাল সকাল ৬টায় অ্যালার্ম দাও", "দুপুর ২টায় মিটিং")
  const timeRegex = /(সকাল|দুপুর|বিকাল|সন্ধ্যা|রাত)?\s*(\d{1,2})(:(\d{2}))?\s*(টায়|টা|am|pm)?/i;
  const timeMatch = lower.match(timeRegex);
  if (timeMatch && (lower.includes('অ্যালার্ম') || lower.includes('alarm') || lower.includes('শিডিউল') || lower.includes('কাজ'))) {
    let hours = parseInt(timeMatch[2], 10);
    const mins = timeMatch[4] ? parseInt(timeMatch[4], 10) : 0;
    const periodWord = timeMatch[1] || '';

    if ((periodWord.includes('দুপুর') && hours < 12) || periodWord.includes('বিকাল') || periodWord.includes('সন্ধ্যা') || periodWord.includes('রাত')) {
      if (hours < 12) hours += 12;
    }
    const formattedDue = `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
    const cleanTitle = raw.replace(timeRegex, '').replace(/অ্যালার্ম দাও|অ্যালার্ম সেট করো|কাজ যোগ করো|সেট করো/gi, '').trim() || 'নির্ধারিত কাজ ও অ্যালার্ম';

    return {
      isMatch: true,
      intent: 'task_action',
      replyBn: `আপনার নির্দেশ অনুযায়ী ${formattedDue} এ "${cleanTitle}" এর জন্য অ্যালার্ম সহ কাজ প্রস্তুত করা হয়েছে। আপনি অনুমোদন দিলে মূল তালিকায় যুক্ত হবে।`,
      replyEn: `Prepared task "${cleanTitle}" at ${formattedDue} with alarm. Approve to schedule.`,
      proposedAction: {
        id: `act-time-${Date.now()}`,
        type: 'create_task',
        title: cleanTitle,
        description: `সময়: ${formattedDue} • অগ্রাধিকার: High`,
        payload: {
          title: cleanTitle,
          dueTime: formattedDue,
          priority: 'high',
          category: 'work',
          alarmEnabled: true,
          ringtone: 'emergency_siren',
        },
      },
    };
  }

  // Not specifically handled by smart parser
  return {
    isMatch: false,
    intent: 'general',
    replyBn: '',
    replyEn: '',
  };
}
