import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getBatteryThermalTier,
  getThermalTierStyles,
  calculateComponentSensors,
  getBatteryConsumptionProfile,
  computeRealBatteryTemperature,
} from './thermal.ts';

test('getBatteryThermalTier returns normal when temp < 37°C', () => {
  assert.equal(getBatteryThermalTier(32.5), 'normal');
  assert.equal(getBatteryThermalTier(36.9), 'normal');
  assert.equal(getBatteryThermalTier(28.0), 'normal');
});

test('getBatteryThermalTier returns orange when temp >= 37°C and < 39°C', () => {
  assert.equal(getBatteryThermalTier(37.0), 'orange');
  assert.equal(getBatteryThermalTier(37.8), 'orange');
  assert.equal(getBatteryThermalTier(38.9), 'orange');
});

test('getBatteryThermalTier returns red when temp >= 39°C', () => {
  assert.equal(getBatteryThermalTier(39.0), 'red');
  assert.equal(getBatteryThermalTier(41.5), 'red');
  assert.equal(getBatteryThermalTier(48.0), 'red');
});

test('computeRealBatteryTemperature accurately models charging heat vs discharging', () => {
  // In ricarica rapida la temperatura sale ad almeno 37°C
  const chargingTemp = computeRealBatteryTemperature(true, 50);
  assert.ok(chargingTemp >= 37.0, 'Charging temp should reflect heat generation >= 37°C');

  // A riposo su batteria è fresca (< 37°C)
  const idleTemp = computeRealBatteryTemperature(false, 80);
  assert.ok(idleTemp < 37.0, 'Discharging temp should remain cool under 37°C');
});

test('getThermalTierStyles provides correct color classes according to user specification', () => {
  const normalStyle = getThermalTierStyles('normal');
  assert.match(normalStyle.borderClass, /border-emerald/);

  const orangeStyle = getThermalTierStyles('orange');
  assert.match(orangeStyle.borderClass, /border-amber/);
  assert.equal(orangeStyle.tier, 'orange');

  const redStyle = getThermalTierStyles('red');
  assert.match(redStyle.borderClass, /border-red/);
  assert.equal(redStyle.tier, 'red');
});

test('calculateComponentSensors computes CPU, GPU, and degrading components', () => {
  const result = calculateComponentSensors(38.0);
  assert.ok(result.cpuTemp > 38.0, 'CPU temperature should exceed battery temperature');
  assert.ok(result.gpuTemp > 38.0, 'GPU temperature should exceed battery temperature');
  assert.ok(result.components.length >= 5, 'Should include sensitive components like battery chemistry, display, storage, PMIC, camera');

  const batteryComp = result.components.find((c) => c.id === 'battery_chemistry');
  assert.ok(batteryComp);
  assert.equal(batteryComp.status, 'warm'); // 38 is >= 37 and < 39
});

test('getBatteryConsumptionProfile validates zero background and AMOLED power reduction', () => {
  const profile = getBatteryConsumptionProfile(true);
  assert.equal(profile.backgroundCpuUsagePercent, 0.0);
  assert.ok(profile.screenPowerReductionPercent > 50);
});
