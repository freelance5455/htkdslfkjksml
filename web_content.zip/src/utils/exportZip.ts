import JSZip from 'jszip';
import { Product, SaleTransaction, StoreSettings } from '../types';

export async function generateAndDownloadZip(
  inventory: Product[],
  sales: SaleTransaction[],
  settings: StoreSettings
): Promise<void> {
  const zip = new JSZip();

  // Export current store data backup
  const backupData = {
    exportDate: new Date().toISOString(),
    storeName: settings.storeName,
    settings,
    inventory,
    sales
  };
  zip.file('store-backup.json', JSON.stringify(backupData, null, 2));

  // Standalone offline single-file POS app
  const standaloneHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>${settings.storeName} - POS & Inventory</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/html5-qrcode"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    .glass-card { background: rgba(15, 23, 42, 0.85); backdrop-filter: blur(16px); border: 1px solid rgba(255, 255, 255, 0.1); }
    @media print { body * { visibility: hidden; } #printableArea, #printableArea * { visibility: visible; } #printableArea { position: absolute; left: 0; top: 0; width: 100%; color: #000 !important; background: #fff !important; } }
  </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen pb-20 font-sans">
  <header class="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md px-4 py-3 border-b border-slate-800 flex items-center justify-between">
    <div class="flex items-center space-x-3">
      <div class="w-9 h-9 rounded-xl bg-cyan-500 flex items-center justify-center font-bold text-slate-950">T</div>
      <div>
        <h1 class="text-base font-bold text-white tracking-tight">${settings.storeName}</h1>
        <p class="text-[10px] text-cyan-400">Offline Standalone POS</p>
      </div>
    </div>
    <span class="text-xs px-2 py-1 rounded bg-slate-800 text-slate-300 font-mono">${settings.currency} Currency</span>
  </header>

  <main class="max-w-xl mx-auto p-4 space-y-4">
    <div class="glass-card rounded-2xl p-4">
      <div class="flex justify-between items-center mb-3">
        <h2 class="font-bold text-sm text-slate-200">Camera Barcode Scanner</h2>
        <span id="scanStatus" class="text-xs text-slate-400">Standby</span>
      </div>
      <div id="reader" class="rounded-xl overflow-hidden bg-slate-900 min-h-[220px]"></div>
      <div class="flex gap-2 mt-3">
        <button onclick="startScanner()" class="flex-1 py-2 bg-cyan-600 hover:bg-cyan-500 font-semibold rounded-xl text-xs text-white">Start Camera</button>
        <button onclick="stopScanner()" class="px-4 py-2 bg-slate-800 hover:bg-slate-700 font-semibold rounded-xl text-xs text-slate-300">Stop</button>
      </div>
    </div>

    <!-- Manual code entry -->
    <div class="glass-card rounded-2xl p-3 flex gap-2">
      <input id="manualCode" type="text" placeholder="Type or scan barcode..." class="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500" onkeydown="if(event.key==='Enter') addByManualCode()">
      <button onclick="addByManualCode()" class="px-4 py-2 bg-cyan-600 text-white rounded-xl text-xs font-semibold">Add</button>
    </div>

    <!-- Cart -->
    <div class="glass-card rounded-2xl p-4 space-y-3">
      <div class="flex justify-between items-center border-b border-slate-800 pb-2">
        <h3 class="font-bold text-sm text-slate-200">Current Cart</h3>
        <button onclick="clearCart()" class="text-xs text-rose-400">Clear</button>
      </div>
      <div id="cartList" class="space-y-2 min-h-[80px]"></div>
      <div class="pt-3 border-t border-slate-800 flex justify-between font-bold">
        <span>Total:</span>
        <span id="cartTotal" class="text-cyan-400 text-lg">${settings.currency}0.00</span>
      </div>
      <button onclick="checkout()" class="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold rounded-xl shadow-lg">Checkout & Print Receipt</button>
    </div>

    <!-- Quick Inventory Summary -->
    <div class="glass-card rounded-2xl p-4">
      <h3 class="font-bold text-sm text-slate-200 mb-2">Available Products</h3>
      <div id="catalogList" class="space-y-2 max-h-48 overflow-y-auto"></div>
    </div>
  </main>

  <div id="printableArea" class="hidden p-6 font-mono text-sm"></div>

  <script>
    let inventory = ${JSON.stringify(inventory)};
    let currency = "${settings.currency}";
    let cart = [];
    let scanner = null;

    function renderCatalog() {
      const el = document.getElementById('catalogList');
      el.innerHTML = inventory.map(item => \`
        <div class="flex justify-between items-center p-2 rounded bg-slate-900/60 border border-slate-800 text-xs">
          <div>
            <span class="font-semibold text-white">\${item.name}</span>
            <span class="text-slate-400 ml-2 font-mono">\${item.code}</span>
          </div>
          <div class="flex items-center gap-2">
            <span class="text-cyan-400 font-bold">\${currency}\${Number(item.price).toFixed(2)}</span>
            <button onclick="addToCartByCode('\${item.code}')" class="px-2 py-1 bg-cyan-500/20 text-cyan-300 rounded font-bold hover:bg-cyan-500/30">+ Add</button>
          </div>
        </div>
      \`).join('');
    }

    function addToCartByCode(code) {
      const item = inventory.find(i => String(i.code).trim() === String(code).trim());
      if (!item) {
        alert("Barcode " + code + " not found!");
        return;
      }
      if (item.stock <= 0) {
        alert(item.name + " is out of stock!");
        return;
      }
      const existing = cart.find(c => c.code === item.code);
      if (existing) {
        if (existing.qty + 1 > item.stock) {
          alert("Maximum stock reached!");
          return;
        }
        existing.qty += 1;
      } else {
        cart.push({ ...item, qty: 1 });
      }
      renderCart();
    }

    function addByManualCode() {
      const val = document.getElementById('manualCode').value.trim();
      if (!val) return;
      addToCartByCode(val);
      document.getElementById('manualCode').value = '';
    }

    function renderCart() {
      const el = document.getElementById('cartList');
      if (cart.length === 0) {
        el.innerHTML = '<p class="text-center text-xs text-slate-500 py-3">Cart is empty.</p>';
        document.getElementById('cartTotal').innerText = currency + '0.00';
        return;
      }
      let total = 0;
      el.innerHTML = cart.map(item => {
        total += item.price * item.qty;
        return \`
          <div class="flex justify-between items-center text-xs py-1.5 border-b border-slate-800/50">
            <div>
              <span class="font-medium text-slate-200">\${item.name}</span>
              <div class="text-[11px] text-slate-400">\${currency}\${Number(item.price).toFixed(2)} x \${item.qty}</div>
            </div>
            <span class="font-bold text-cyan-300">\${currency}\${(item.price * item.qty).toFixed(2)}</span>
          </div>
        \`;
      }).join('');
      document.getElementById('cartTotal').innerText = currency + total.toFixed(2);
    }

    function clearCart() { cart = []; renderCart(); }

    function checkout() {
      if (cart.length === 0) { alert('Cart is empty'); return; }
      const total = cart.reduce((s, i) => s + (i.price * i.qty), 0);
      const printEl = document.getElementById('printableArea');
      printEl.innerHTML = \`
        <div style="text-align:center; margin-bottom: 12px;">
          <h2 style="font-size: 16px; font-weight: bold; margin:0;">\${"${settings.storeName}"}</h2>
          <p style="font-size: 11px; margin: 2px 0;">\${"${settings.address}"}</p>
          <p style="font-size: 11px; margin: 2px 0;">Date: \${new Date().toLocaleString()}</p>
        </div>
        <hr style="margin: 8px 0; border: none; border-top: 1px dashed #000;" />
        \${cart.map(i => \`
          <div style="display: flex; justify-content: space-between; font-size: 12px; margin: 4px 0;">
            <span>\${i.qty}x \${i.name}</span>
            <span>\${currency}\${(i.price * i.qty).toFixed(2)}</span>
          </div>
        \`).join('')}
        <hr style="margin: 8px 0; border: none; border-top: 1px dashed #000;" />
        <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 14px;">
          <span>TOTAL</span>
          <span>\${currency}\${total.toFixed(2)}</span>
        </div>
        <div style="text-align: center; margin-top: 16px; font-size: 10px;">
          <p>\${"${settings.receiptFooter}"}</p>
        </div>
      \`;
      printEl.classList.remove('hidden');
      window.print();
      printEl.classList.add('hidden');
      cart = [];
      renderCart();
    }

    function startScanner() {
      if (!scanner) scanner = new Html5Qrcode("reader");
      scanner.start({ facingMode: "environment" }, { fps: 10, qrbox: 200 }, (code) => {
        addToCartByCode(code);
      }).catch(err => alert("Camera permission error: " + err));
    }

    function stopScanner() {
      if (scanner) {
        scanner.stop().then(() => { scanner.clear(); scanner = null; }).catch(()=>{});
      }
    }

    renderCatalog();
    renderCart();
  </script>
</body>
</html>`;

  zip.file('index.html', standaloneHtml);

  const readmeContent = `# ${settings.storeName} - Standalone POS & Inventory Bundle

This archive contains the standalone offline point-of-sale and inventory system.

## Files Included
1. **index.html**: Self-contained, single-file HTML/JS Point of Sale application. Double-click to open in Google Chrome, Microsoft Edge, Safari, or mobile browsers.
2. **store-backup.json**: Full JSON export of current store settings, registered products, and sales logs.

## Features
- Camera Barcode & QR Scanner support
- Keyboard / USB Handheld scanner input
- Thermal & Standard receipt generation with window.print()
- Works completely offline without needing a server

Generated via Tally POS & Inventory Register.
`;
  zip.file('README.md', readmeContent);

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `Tally-POS-${new Date().toISOString().split('T')[0]}.zip`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
