import { CustomFont } from '../types/pdf';

export interface StudioFontOption {
  id: string;
  label: string;
  labelBn: string;
  cssFamily: string;
  category:
    | 'bangla-sans'
    | 'bangla-serif'
    | 'arabic-sans'
    | 'arabic-serif'
    | 'urdu-nastaliq'
    | 'persian-sans'
    | 'english-sans'
    | 'english-serif'
    | 'mono'
    | 'custom';
  sampleText: string;
  regularUrl?: string;
  boldUrl?: string;
}

export const BUNDLED_FONTS: StudioFontOption[] = [
  {
    id: 'noto-sans-bengali',
    label: 'Noto Sans Bengali',
    labelBn: 'নোটো স্যান্স বাংলা (আধুনিক)',
    cssFamily: '"Noto Sans Bengali Local", "Noto Sans Local", "Noto Naskh Arabic", "Vazirmatn", "Noto Nastaliq Urdu", sans-serif',
    category: 'bangla-sans',
    sampleText: 'বাংলা ও English যুক্তাক্ষর (ক্ষ্ম)',
    regularUrl: '/fonts/NotoSansBengali-Regular.ttf',
    boldUrl: '/fonts/NotoSansBengali-Bold.ttf',
  },
  {
    id: 'noto-serif-bengali',
    label: 'Noto Serif Bengali',
    labelBn: 'নোটো সেরিফ বাংলা (বই ও দলিল)',
    cssFamily: '"Noto Serif Bengali Local", "Noto Serif Local", "Noto Naskh Arabic", "Amiri", serif',
    category: 'bangla-serif',
    sampleText: 'বাংলা ও English দলিল ফন্ট',
    regularUrl: '/fonts/NotoSerifBengali-Regular.ttf',
    boldUrl: '/fonts/NotoSerifBengali-Bold.ttf',
  },
  {
    id: 'hind-siliguri',
    label: 'Hind Siliguri',
    labelBn: 'হিন্দ শিলিগুড়ি (সুষম স্যান্স)',
    cssFamily: '"Hind Siliguri", "Noto Sans Bengali Local", "Plus Jakarta Sans", "Noto Naskh Arabic", sans-serif',
    category: 'bangla-sans',
    sampleText: 'হিন্দ শিলিগুড়ি ও English',
    regularUrl: '/fonts/NotoSansBengali-Regular.ttf',
    boldUrl: '/fonts/NotoSansBengali-Bold.ttf',
  },
  {
    id: 'tiro-bangla',
    label: 'Tiro Bangla',
    labelBn: 'তিরো বাংলা (ঐতিহ্যবাহী সেরিফ)',
    cssFamily: '"Tiro Bangla", "Noto Serif Bengali Local", "Source Serif 4", "Noto Naskh Arabic", serif',
    category: 'bangla-serif',
    sampleText: 'তিরো বাংলা ও English ক্লাসিক',
    regularUrl: '/fonts/NotoSerifBengali-Regular.ttf',
    boldUrl: '/fonts/NotoSerifBengali-Bold.ttf',
  },
  {
    id: 'noto-naskh-arabic',
    label: 'Noto Naskh Arabic',
    labelBn: 'নোটো নাসখ আরবি (বই ও দলিল)',
    cssFamily: '"Noto Naskh Arabic", "Amiri", "Cairo", "Noto Sans Bengali Local", serif',
    category: 'arabic-serif',
    sampleText: 'بسم الله الرحمن الرحيم · العربية',
  },
  {
    id: 'amiri-arabic',
    label: 'Amiri (Arabic Naskh)',
    labelBn: 'আমিরি আরবি (ক্লাসিক ক্যালিগ্রাফি)',
    cssFamily: '"Amiri", "Noto Naskh Arabic", "Noto Sans Bengali Local", serif',
    category: 'arabic-serif',
    sampleText: 'السلام عليكم ورحمة الله',
  },
  {
    id: 'cairo-arabic',
    label: 'Cairo (Modern Arabic)',
    labelBn: 'কায়রো আরবি (আধুনিক স্যান্স)',
    cssFamily: '"Cairo", "Noto Naskh Arabic", "Noto Sans Bengali Local", sans-serif',
    category: 'arabic-sans',
    sampleText: 'الخط العربي الحديث · 2026',
  },
  {
    id: 'noto-nastaliq-urdu',
    label: 'Noto Nastaliq Urdu',
    labelBn: 'নোটো নাস্তালিক উর্দু (Urdu)',
    cssFamily: '"Noto Nastaliq Urdu", "Noto Naskh Arabic", "Amiri", "Noto Sans Bengali Local", serif',
    category: 'urdu-nastaliq',
    sampleText: 'اُردو تحریر · خوبصورت نستعلیق',
  },
  {
    id: 'vazirmatn-persian',
    label: 'Vazirmatn (Persian / Farsi)',
    labelBn: 'ভাজিরমাতন ফার্সি (Persian / فارسی)',
    cssFamily: '"Vazirmatn", "Noto Naskh Arabic", "Cairo", "Noto Sans Bengali Local", sans-serif',
    category: 'persian-sans',
    sampleText: 'زبان فارسی · ویرایش اسناد',
  },
  {
    id: 'plus-jakarta-sans',
    label: 'Plus Jakarta Sans',
    labelBn: 'প্লাস জাকার্তা স্যান্স (English)',
    cssFamily: '"Plus Jakarta Sans", "Noto Sans Local", "Noto Sans Bengali Local", "Noto Naskh Arabic", "Vazirmatn", sans-serif',
    category: 'english-sans',
    sampleText: 'Modern Clean English & বাংলা',
    regularUrl: '/fonts/NotoSans-Regular.ttf',
    boldUrl: '/fonts/NotoSans-Bold.ttf',
  },
  {
    id: 'source-serif-4',
    label: 'Source Serif 4',
    labelBn: 'সোর্স সেরিফ (English Editorial)',
    cssFamily: '"Source Serif 4", "Noto Serif Local", "Noto Serif Bengali Local", "Noto Naskh Arabic", serif',
    category: 'english-serif',
    sampleText: 'Editorial Serif & বাংলা',
    regularUrl: '/fonts/NotoSerif-Regular.ttf',
    boldUrl: '/fonts/NotoSerif-Bold.ttf',
  },
  {
    id: 'jetbrains-mono',
    label: 'JetBrains Mono',
    labelBn: 'জেটব্রেইনস মনো (কোড ও হিসাব)',
    cssFamily: '"JetBrains Mono Local", "Noto Sans Bengali Local", "Noto Naskh Arabic", monospace',
    category: 'mono',
    sampleText: 'INV-2026-048 · 1,250.00',
    regularUrl: '/fonts/JetBrainsMono-Regular.ttf',
  },
];

export interface GoogleFontCatalogEntry {
  family: string;
  script: 'bangla' | 'arabic' | 'urdu' | 'persian' | 'english';
}

export const GOOGLE_FONTS_CATALOG: GoogleFontCatalogEntry[] = [
  // Bangla
  { family: 'Baloo Da 2', script: 'bangla' },
  { family: 'Anek Bangla', script: 'bangla' },
  { family: 'Mina', script: 'bangla' },
  { family: 'Galada', script: 'bangla' },
  { family: 'Atma', script: 'bangla' },
  { family: 'Alkatra', script: 'bangla' },
  { family: 'Noto Sans Bengali', script: 'bangla' },
  { family: 'Noto Serif Bengali', script: 'bangla' },
  { family: 'Hind Siliguri', script: 'bangla' },
  { family: 'Tiro Bangla', script: 'bangla' },
  // Arabic, Urdu & Persian
  { family: 'Noto Nastaliq Urdu', script: 'urdu' },
  { family: 'Gulzar', script: 'urdu' },
  { family: 'Vazirmatn', script: 'persian' },
  { family: 'Lalezar', script: 'persian' },
  { family: 'Tajawal', script: 'arabic' },
  { family: 'Almarai', script: 'arabic' },
  { family: 'IBM Plex Sans Arabic', script: 'arabic' },
  { family: 'Readex Pro', script: 'arabic' },
  { family: 'Scheherazade New', script: 'arabic' },
  { family: 'Reem Kufi', script: 'arabic' },
  { family: 'Lateef', script: 'arabic' },
  { family: 'Cairo', script: 'arabic' },
  { family: 'Amiri', script: 'arabic' },
  { family: 'Noto Naskh Arabic', script: 'arabic' },
  { family: 'Noto Sans Arabic', script: 'arabic' },
  // English & Multilingual
  { family: 'Inter', script: 'english' },
  { family: 'Poppins', script: 'english' },
  { family: 'Roboto', script: 'english' },
  { family: 'Open Sans', script: 'english' },
  { family: 'Lato', script: 'english' },
  { family: 'Montserrat', script: 'english' },
  { family: 'Playfair Display', script: 'english' },
  { family: 'Merriweather', script: 'english' },
  { family: 'Lora', script: 'english' },
  { family: 'EB Garamond', script: 'english' },
  { family: 'Nunito', script: 'english' },
  { family: 'Oswald', script: 'english' },
  { family: 'Raleway', script: 'english' },
  { family: 'Fira Code', script: 'english' },
];

interface SystemFontCandidate {
  name: string;
  script: 'bangla' | 'arabic' | 'latin';
}

const KNOWN_SYSTEM_FONTS: SystemFontCandidate[] = [
  // Mobile & Desktop Bangla System Fonts
  { name: 'Noto Sans Bengali', script: 'bangla' },
  { name: 'Noto Serif Bengali', script: 'bangla' },
  { name: 'SolaimanLipi', script: 'bangla' },
  { name: 'Kalpurush', script: 'bangla' },
  { name: 'Nikosh', script: 'bangla' },
  { name: 'NikoshBAN', script: 'bangla' },
  { name: 'Siyam Rupali', script: 'bangla' },
  { name: 'AdorshoLipi', script: 'bangla' },
  { name: 'Amar Bangla', script: 'bangla' },
  { name: 'Vrinda', script: 'bangla' },
  { name: 'Shonar Bangla', script: 'bangla' },
  { name: 'Mukti', script: 'bangla' },
  { name: 'Lohit Bengali', script: 'bangla' },
  { name: 'Ruposhi Bangla', script: 'bangla' },
  { name: 'Akaash', script: 'bangla' },
  { name: 'Bangla Sangam MN', script: 'bangla' },
  { name: 'Bangla MN', script: 'bangla' },
  { name: 'Kohinoor Bangla', script: 'bangla' },
  // Mobile & Desktop Arabic, Urdu & Persian System Fonts
  { name: 'Noto Naskh Arabic', script: 'arabic' },
  { name: 'Noto Sans Arabic', script: 'arabic' },
  { name: 'Noto Nastaliq Urdu', script: 'arabic' },
  { name: 'Vazirmatn', script: 'arabic' },
  { name: 'Jameel Noori Nastaleeq', script: 'arabic' },
  { name: 'Nafees Web Naskh', script: 'arabic' },
  { name: 'Urdu Typesetting', script: 'arabic' },
  { name: 'B Nazanin', script: 'arabic' },
  { name: 'IRANSans', script: 'arabic' },
  { name: 'Droid Arabic Naskh', script: 'arabic' },
  { name: 'Droid Arabic Kufi', script: 'arabic' },
  { name: 'Traditional Arabic', script: 'arabic' },
  { name: 'Simplified Arabic', script: 'arabic' },
  { name: 'Arabic Typesetting', script: 'arabic' },
  { name: 'Geeza Pro', script: 'arabic' },
  { name: 'Al Bayan', script: 'arabic' },
  { name: 'Al Nile', script: 'arabic' },
  { name: 'Damascus', script: 'arabic' },
  { name: 'Baghdad', script: 'arabic' },
  { name: 'Tahoma', script: 'arabic' },
  // Android, iOS, Windows & macOS Core Fonts
  { name: 'Roboto', script: 'latin' },
  { name: 'Roboto Condensed', script: 'latin' },
  { name: 'Roboto Slab', script: 'latin' },
  { name: 'Roboto Mono', script: 'latin' },
  { name: 'Droid Sans', script: 'latin' },
  { name: 'Droid Serif', script: 'latin' },
  { name: 'Droid Sans Mono', script: 'latin' },
  { name: 'Times New Roman', script: 'latin' },
  { name: 'Calibri', script: 'latin' },
  { name: 'Cambria', script: 'latin' },
  { name: 'Georgia', script: 'latin' },
  { name: 'Arial', script: 'latin' },
  { name: 'Helvetica', script: 'latin' },
  { name: 'Helvetica Neue', script: 'latin' },
  { name: 'Verdana', script: 'latin' },
  { name: 'Trebuchet MS', script: 'latin' },
  { name: 'Segoe UI', script: 'latin' },
  { name: 'Courier New', script: 'latin' },
];

const FONTS_IDB_NAME = 'lipipdf_fonts_v1';
const FONTS_IDB_STORE = 'uploaded_fonts';
const GOOGLE_FONTS_STORAGE_KEY = 'lipipdf_google_fonts_v1';

interface StoredFontRecord {
  id: string;
  name: string;
  familyName: string;
  fileName: string;
  bytes: ArrayBuffer;
}

function openFontDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const req = indexedDB.open(FONTS_IDB_NAME, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(FONTS_IDB_STORE)) {
        req.result.createObjectStore(FONTS_IDB_STORE, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function persistUploadedFont(font: CustomFont): Promise<void> {
  if (!font.bytes || font.bytes.length === 0) return;
  try {
    const db = await openFontDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(FONTS_IDB_STORE, 'readwrite');
      const rec: StoredFontRecord = {
        id: font.id,
        name: font.name,
        familyName: font.familyName,
        fileName: font.fileName,
        bytes: font.bytes.slice().buffer,
      };
      tx.objectStore(FONTS_IDB_STORE).put(rec);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    // Non-fatal
  }
}

export async function loadPersistedCustomFonts(): Promise<CustomFont[]> {
  try {
    const db = await openFontDb();
    const records = await new Promise<StoredFontRecord[]>((resolve, reject) => {
      const tx = db.transaction(FONTS_IDB_STORE, 'readonly');
      const req = tx.objectStore(FONTS_IDB_STORE).getAll();
      req.onsuccess = () => resolve((req.result as StoredFontRecord[]) || []);
      req.onerror = () => reject(req.error);
    });
    db.close();

    const loaded: CustomFont[] = [];
    for (const rec of records) {
      try {
        const fontFace = new FontFace(rec.familyName, rec.bytes.slice(0));
        const face = await fontFace.load();
        document.fonts.add(face);
        loaded.push({
          id: rec.id,
          name: rec.name,
          familyName: rec.familyName,
          fileName: rec.fileName,
          bytes: new Uint8Array(rec.bytes),
          loaded: true,
          source: 'uploaded',
        });
      } catch {
        // Ignore broken cached font
      }
    }
    return loaded;
  } catch {
    return [];
  }
}

function saveGoogleFontNames(names: string[]) {
  try {
    localStorage.setItem(GOOGLE_FONTS_STORAGE_KEY, JSON.stringify(Array.from(new Set(names))));
  } catch {
    // Ignore storage error
  }
}

function getSavedGoogleFontNames(): string[] {
  try {
    const raw = localStorage.getItem(GOOGLE_FONTS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((x): x is string => typeof x === 'string') : [];
  } catch {
    return [];
  }
}

function normalizeGoogleFontQuery(rawName: string): string {
  const cleaned = rawName.trim().replace(/\s+/g, ' ');
  const exactCatalog = GOOGLE_FONTS_CATALOG.find(
    (g) => g.family.toLowerCase() === cleaned.toLowerCase()
  );
  if (exactCatalog) return exactCatalog.family;
  // Title-case words automatically so "baloo da 2" -> "Baloo Da 2"
  return cleaned
    .split(' ')
    .map((w) => (w.length > 0 ? w[0].toUpperCase() + w.slice(1) : w))
    .join(' ');
}

export async function loadGoogleFontByName(
  rawName: string,
  persist = true
): Promise<CustomFont> {
  const familyName = normalizeGoogleFontQuery(rawName);
  if (!familyName) {
    throw new Error('Empty font name');
  }

  const fontId = `google-${familyName.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
  const slug = encodeURIComponent(familyName).replace(/%20/g, '+');
  const href = `https://fonts.googleapis.com/css2?family=${slug}:wght@400;500;600;700&display=swap`;

  // Inject CSS2 stylesheet if not already present
  let linkEl = document.querySelector<HTMLLinkElement>(`link[data-lipi-gfont="${fontId}"]`);
  if (!linkEl) {
    linkEl = document.createElement('link');
    linkEl.rel = 'stylesheet';
    linkEl.href = href;
    linkEl.setAttribute('data-lipi-gfont', fontId);

    const cssLoaded = await new Promise<boolean>((resolve) => {
      const timer = window.setTimeout(() => resolve(true), 4500);
      linkEl!.onload = () => {
        window.clearTimeout(timer);
        resolve(true);
      };
      linkEl!.onerror = () => {
        window.clearTimeout(timer);
        resolve(false);
      };
      document.head.appendChild(linkEl!);
    });

    if (!cssLoaded) {
      linkEl.remove();
      throw new Error(`Google Font "${familyName}" not found`);
    }
  }

  try {
    await Promise.race([
      document.fonts.load(`400 16px "${familyName}"`),
      new Promise((r) => setTimeout(r, 3500)),
    ]);
  } catch {
    // Non-fatal
  }

  if (persist) {
    const existing = getSavedGoogleFontNames();
    if (!existing.some((n) => n.toLowerCase() === familyName.toLowerCase())) {
      saveGoogleFontNames([...existing, familyName]);
    }
  }

  return {
    id: fontId,
    name: familyName,
    familyName,
    fileName: 'Google Fonts',
    bytes: new Uint8Array(0),
    loaded: true,
    source: 'google',
  };
}

export async function loadPersistedGoogleFonts(): Promise<CustomFont[]> {
  const names = getSavedGoogleFontNames();
  if (names.length === 0) return [];
  const results = await Promise.allSettled(
    names.map((name) => loadGoogleFontByName(name, false))
  );
  return results
    .filter((r): r is PromiseFulfilledResult<CustomFont> => r.status === 'fulfilled')
    .map((r) => r.value);
}

export function detectInstalledSystemFonts(): CustomFont[] {
  if (typeof document === 'undefined') return [];
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) return [];

  const probes: Record<SystemFontCandidate['script'], string> = {
    bangla: 'আমার সোনার বাংলা ক্ষ্ম প্রকৃতি ক্ত্র',
    arabic: 'السلام عليكم ورحمة الله وبركاته',
    latin: 'The quick brown fox MWi0123456789',
  };

  const baselines = ['monospace', 'sans-serif', 'serif'] as const;
  const baseWidths: Record<string, Record<string, number>> = {
    bangla: {},
    arabic: {},
    latin: {},
  };

  for (const script of ['bangla', 'arabic', 'latin'] as const) {
    for (const base of baselines) {
      ctx.font = `44px ${base}`;
      baseWidths[script][base] = ctx.measureText(probes[script]).width;
    }
  }

  const detected: CustomFont[] = [];
  for (const candidate of KNOWN_SYSTEM_FONTS) {
    const probeText = probes[candidate.script];
    const isInstalled = baselines.some((base) => {
      ctx.font = `44px "${candidate.name}", ${base}`;
      return (
        Math.abs(ctx.measureText(probeText).width - baseWidths[candidate.script][base]) > 0.4
      );
    });

    if (isInstalled) {
      detected.push({
        id: `sys-${candidate.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
        name: candidate.name,
        familyName: candidate.name,
        fileName: 'Device / System Font',
        bytes: new Uint8Array(0),
        loaded: true,
        source: 'system-probe',
      });
    }
  }
  return detected;
}

interface LocalFontDataHandle {
  family: string;
  fullName: string;
  postscriptName: string;
  style: string;
  blob: () => Promise<Blob>;
}

export async function loadLocalDeviceFontsViaApi(): Promise<{
  supported: boolean;
  fonts: CustomFont[];
}> {
  const w = window as unknown as {
    queryLocalFonts?: () => Promise<LocalFontDataHandle[]>;
  };
  if (typeof w.queryLocalFonts !== 'function') {
    return { supported: false, fonts: [] };
  }

  try {
    const handles = await w.queryLocalFonts();
    const byFamily = new Map<string, LocalFontDataHandle>();
    for (const h of handles) {
      if (!byFamily.has(h.family)) {
        byFamily.set(h.family, h);
      } else if (/regular|normal/i.test(h.style)) {
        byFamily.set(h.family, h);
      }
    }

    const deviceFonts: CustomFont[] = [];
    for (const [family, handle] of byFamily.entries()) {
      deviceFonts.push({
        id: `device-${family.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
        name: family,
        familyName: family,
        fileName: `${handle.fullName || family} (Device)`,
        bytes: new Uint8Array(0),
        loaded: true,
        source: 'device',
      });
    }

    return { supported: true, fonts: deviceFonts };
  } catch {
    return { supported: false, fonts: [] };
  }
}

export function hasBanglaChars(text: string): boolean {
  return /[\u0980-\u09FF]/.test(text);
}

export function hasArabicChars(text: string): boolean {
  return /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(text);
}

export function hasUrduChars(text: string): boolean {
  return /[\u0679\u0688\u0691\u06BA\u06D2\u06C1\u06BE\u06C3]/.test(text);
}

export function hasPersianChars(text: string): boolean {
  return /[\u067E\u0686\u0698\u06AF\u06A9\u06CC]/.test(text);
}

export function detectTextScript(
  text: string
): 'bn' | 'ur' | 'fa' | 'ar' | 'en' {
  if (hasBanglaChars(text)) return 'bn';
  if (hasArabicChars(text)) {
    if (hasUrduChars(text)) return 'ur';
    if (hasPersianChars(text)) return 'fa';
    return 'ar';
  }
  return 'en';
}

export function isRtlText(text: string): boolean {
  if (!text) return false;
  const arabicMatches = text.match(/[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/g);
  const ltrMatches = text.match(/[A-Za-z\u0980-\u09FF]/g);
  return (arabicMatches?.length ?? 0) > 0 && (arabicMatches?.length ?? 0) >= (ltrMatches?.length ?? 0) * 0.4;
}

export function inferStudioFontFromPdf(
  rawFontName: string,
  pdfCssFontFamily: string,
  text: string,
  customFonts: CustomFont[] = []
): {
  matchedFontId: string;
  fontWeight: 'normal' | 'bold';
  fontStyle: 'normal' | 'italic';
  cleanDisplayName: string;
} {
  const cleanName = rawFontName.replace(/^[A-Z]{6}\+/, '');
  const combined = `${cleanName} ${pdfCssFontFamily}`.toLowerCase();

  const isBold = /bold|black|heavy|semibold|demi|700|800/i.test(combined);
  const isItalic = /italic|oblique|slant/i.test(combined);
  const bangla =
    hasBanglaChars(text) ||
    /beng|bangla|solaiman|kalpurush|nikosh|sutonny|siyam|vrinda|tiro|hind/i.test(combined);
  const arabic =
    hasArabicChars(text) ||
    /arab|naskh|amiri|cairo|kufi|traditional|simplified|tahoma|geeza|scheherazade|urdu|nastaliq|jameel|nafees|persian|farsi|vazir|nazanin|iran/i.test(
      combined
    );
  const urdu =
    hasUrduChars(text) || /urdu|nastaliq|jameel|nafees|gulzar/i.test(combined);
  const persian =
    hasPersianChars(text) || /persian|farsi|vazir|nazanin|iran|sahel|yekan/i.test(combined);

  // Match against uploaded, device, Google, or detected system fonts first
  const customMatch = customFonts.find((cf) => {
    const cfKey = cf.name.toLowerCase().replace(/[^a-z0-9]/g, '');
    const rawKey = cleanName.toLowerCase().replace(/[^a-z0-9]/g, '');
    return cfKey && rawKey && (rawKey.includes(cfKey) || cfKey.includes(rawKey));
  });

  if (customMatch) {
    return {
      matchedFontId: customMatch.id,
      fontWeight: isBold ? 'bold' : 'normal',
      fontStyle: isItalic ? 'italic' : 'normal',
      cleanDisplayName: cleanName || customMatch.name,
    };
  }

  let matchedFontId = 'plus-jakarta-sans';

  if (/mono|courier|consolas|code|jetbrains|fira/i.test(combined)) {
    matchedFontId = 'jetbrains-mono';
  } else if (arabic && !bangla) {
    if (urdu) {
      matchedFontId = 'noto-nastaliq-urdu';
    } else if (persian) {
      matchedFontId = 'vazirmatn-persian';
    } else if (/cairo|sans|tajawal|almarai|tahoma/i.test(combined)) {
      matchedFontId = 'cairo-arabic';
    } else if (/amiri|callig/i.test(combined)) {
      matchedFontId = 'amiri-arabic';
    } else {
      matchedFontId = 'noto-naskh-arabic';
    }
  } else if (bangla) {
    if (
      /serif|tiro|solaiman|kalpurush|nikosh|vrinda|times|georgia|garamond|cambria/i.test(
        combined
      )
    ) {
      matchedFontId = /tiro/i.test(combined) ? 'tiro-bangla' : 'noto-serif-bengali';
    } else if (/hind|siliguri/i.test(combined)) {
      matchedFontId = 'hind-siliguri';
    } else {
      matchedFontId = 'noto-sans-bengali';
    }
  } else if (
    /serif|times|georgia|garamond|cambria|palatino|baskerville|book/i.test(combined)
  ) {
    matchedFontId = 'source-serif-4';
  } else {
    matchedFontId = 'plus-jakarta-sans';
  }

  return {
    matchedFontId,
    fontWeight: isBold ? 'bold' : 'normal',
    fontStyle: isItalic ? 'italic' : 'normal',
    cleanDisplayName: cleanName || 'Standard PDF Font',
  };
}

export function resolveCssFontFamily(
  fontId: string,
  customFonts: CustomFont[]
): string {
  const custom = customFonts.find((f) => f.id === fontId);
  if (custom) {
    return `"${custom.familyName}", "Noto Sans Bengali Local", "Noto Naskh Arabic", "Vazirmatn", "Noto Nastaliq Urdu", "Cairo", "Noto Sans Local", sans-serif`;
  }
  const bundled = BUNDLED_FONTS.find((f) => f.id === fontId);
  return bundled ? bundled.cssFamily : BUNDLED_FONTS[0].cssFamily;
}

export async function registerCustomFontFace(file: File): Promise<CustomFont> {
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  const baseName = file.name.replace(/\.(ttf|otf|woff2?)$/i, '');
  const familyName = `LipiCustom_${baseName.replace(/[^a-zA-Z0-9_-]/g, '_')}_${Date.now()}`;

  const fontFace = new FontFace(familyName, buffer);
  const loadedFace = await fontFace.load();
  document.fonts.add(loadedFace);

  const font: CustomFont = {
    id: `custom-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    name: baseName,
    familyName,
    fileName: file.name,
    bytes,
    loaded: true,
    source: 'uploaded',
  };

  await persistUploadedFont(font);
  return font;
}

export async function ensureStudioFontsLoaded(): Promise<void> {
  try {
    await document.fonts.ready;
    const checks = [
      '16px "Noto Sans Bengali Local"',
      '700 16px "Noto Sans Bengali Local"',
      '16px "Noto Serif Bengali Local"',
      '700 16px "Noto Serif Bengali Local"',
      '16px "Noto Naskh Arabic"',
      '16px "Cairo"',
      '16px "Amiri"',
      '16px "Noto Nastaliq Urdu"',
      '16px "Vazirmatn"',
      '16px "Noto Sans Local"',
      '700 16px "Noto Sans Local"',
      '16px "Noto Serif Local"',
      '700 16px "Noto Serif Local"',
      '16px "JetBrains Mono Local"',
    ];
    await Promise.all(checks.map((spec) => document.fonts.load(spec).catch(() => [])));
  } catch {
    // Ignore font pre-warm errors
  }
}
