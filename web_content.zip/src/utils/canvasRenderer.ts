import { BannerFormat, AdCreativeData } from '../types';

export interface RenderOptions {
  pixelRatio?: number;
  layoutStyle?: 'split' | 'overlay' | 'focus';
  fontFamily?: 'sans' | 'serif' | 'display' | 'mono';
  bgTheme?: 'dark' | 'light' | 'brand';
}

/**
 * Renders a banner ad onto an off-screen HTML5 Canvas and returns a PNG Data URL or Blob
 */
export async function renderBannerToCanvas(
  format: BannerFormat,
  creative: AdCreativeData,
  options: RenderOptions = {}
): Promise<HTMLCanvasElement> {
  const pixelRatio = options.pixelRatio || 2; // 2x for crisp retina download
  const width = format.width * pixelRatio;
  const height = format.height * pixelRatio;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Canvas 2D context not available');
  }

  // Determine copy for this shape
  const copyGroup = creative.copyVariations[format.shape] || {
    headline: creative.primaryHeadline,
    subhead: creative.subheadline,
    cta: creative.ctaText,
  };

  const bgTheme = options.bgTheme || 'dark';
  const fontFamily =
    options.fontFamily === 'serif'
      ? 'Georgia, serif'
      : options.fontFamily === 'mono'
      ? 'ui-monospace, Menlo, monospace'
      : options.fontFamily === 'display'
      ? 'Impact, Arial Black, sans-serif'
      : 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';

  // Base background
  let bgColor = '#0F172A';
  let textColor = '#F8FAFC';
  let subtextColor = '#94A3B8';

  if (bgTheme === 'light') {
    bgColor = '#FFFFFF';
    textColor = '#0F172A';
    subtextColor = '#475569';
  } else if (bgTheme === 'brand') {
    bgColor = creative.primaryColor || '#1E293B';
    textColor = '#FFFFFF';
    subtextColor = 'rgba(255, 255, 255, 0.85)';
  }

  ctx.fillStyle = bgColor;
  ctx.fillRect(0, 0, width, height);

  // If there is an image, load and render it
  if (creative.imageUrl) {
    try {
      const img = await loadImage(creative.imageUrl);
      renderImageAndComposition(ctx, img, format, creative, width, height, copyGroup, textColor, subtextColor, fontFamily, pixelRatio);
    } catch (e) {
      console.warn('Could not load image for canvas export, rendering graphic fallback:', e);
      renderGraphicFallback(ctx, format, creative, width, height, copyGroup, textColor, subtextColor, fontFamily, pixelRatio);
    }
  } else {
    renderGraphicFallback(ctx, format, creative, width, height, copyGroup, textColor, subtextColor, fontFamily, pixelRatio);
  }

  // Subtle border
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
  ctx.lineWidth = 1 * pixelRatio;
  ctx.strokeRect(0, 0, width, height);

  return canvas;
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.referrerPolicy = 'no-referrer';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

function renderImageAndComposition(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  format: BannerFormat,
  creative: AdCreativeData,
  w: number,
  h: number,
  copy: { headline: string; subhead: string; cta: string },
  textColor: string,
  subtextColor: string,
  fontFamily: string,
  scale: number
) {
  const p = 14 * scale;

  if (format.shape === 'leaderboard') {
    // Horizontal Banner (e.g. 728x90, 970x250, 320x50)
    // Left: Product Image square/rect, Middle: Headline & Sub, Right: Badge & CTA
    const imgWidth = Math.min(h * 1.3, w * 0.28);

    // Draw image on the right or left
    drawImageCover(ctx, img, 0, 0, imgWidth, h);

    // Dark gradient overlay over image edge
    const grad = ctx.createLinearGradient(imgWidth * 0.7, 0, imgWidth + p, 0);
    grad.addColorStop(0, 'rgba(15, 23, 42, 0)');
    grad.addColorStop(1, 'rgba(15, 23, 42, 1)');
    ctx.fillStyle = grad;
    ctx.fillRect(imgWidth * 0.5, 0, imgWidth * 0.6, h);

    // Text area in the center
    const textX = imgWidth + p * 1.2;
    const ctaWidth = Math.min(130 * scale, w * 0.25);
    const ctaHeight = Math.min(36 * scale, h * 0.6);
    const ctaX = w - ctaWidth - p * 1.2;
    const ctaY = (h - ctaHeight) / 2;

    const maxTextW = ctaX - textX - p;

    // Brand Name / Badge
    const badgeH = Math.min(18 * scale, h * 0.28);
    drawBadge(ctx, creative.offerBadge || creative.brandName, textX, p * 0.7, badgeH, creative.primaryColor, scale);

    // Headline
    const fontSize = Math.max(11 * scale, Math.min(20 * scale, h * 0.26));
    ctx.font = `bold ${fontSize}px ${fontFamily}`;
    ctx.fillStyle = textColor;
    ctx.fillText(truncateText(ctx, copy.headline, maxTextW), textX, h * 0.58);

    // Subhead
    if (h > 65 * scale) {
      const subSize = Math.max(9 * scale, fontSize * 0.65);
      ctx.font = `500 ${subSize}px ${fontFamily}`;
      ctx.fillStyle = subtextColor;
      ctx.fillText(truncateText(ctx, copy.subhead, maxTextW), textX, h * 0.82);
    }

    // CTA Button
    drawButton(ctx, copy.cta, ctaX, ctaY, ctaWidth, ctaHeight, creative.primaryColor, fontFamily, scale);
  } else if (format.shape === 'skyscraper') {
    // Vertical Banner (e.g. 160x600, 300x600)
    // Top: Brand & Badge, Upper Middle: Image, Lower Middle: Copy, Bottom: CTA
    const topPadding = p * 1.2;

    // Brand & Badge
    drawBadge(ctx, creative.offerBadge || 'SPECIAL OFFER', p, topPadding, 22 * scale, creative.primaryColor, scale);

    // Headline
    const headlineFontSize = format.width < 200 ? 15 * scale : 22 * scale;
    ctx.font = `bold ${headlineFontSize}px ${fontFamily}`;
    ctx.fillStyle = textColor;
    drawWrappedText(ctx, copy.headline, p, topPadding + 34 * scale, w - p * 2, headlineFontSize * 1.25, 3);

    // Image section
    const imgY = h * 0.32;
    const imgH = h * 0.38;
    drawImageCover(ctx, img, 0, imgY, w, imgH);

    // Subtle gradient fades on top and bottom of image
    const gradTop = ctx.createLinearGradient(0, imgY, 0, imgY + 40 * scale);
    gradTop.addColorStop(0, '#0F172A');
    gradTop.addColorStop(1, 'rgba(15, 23, 42, 0)');
    ctx.fillStyle = gradTop;
    ctx.fillRect(0, imgY, w, 40 * scale);

    const gradBottom = ctx.createLinearGradient(0, imgY + imgH - 40 * scale, 0, imgY + imgH);
    gradBottom.addColorStop(0, 'rgba(15, 23, 42, 0)');
    gradBottom.addColorStop(1, '#0F172A');
    ctx.fillStyle = gradBottom;
    ctx.fillRect(0, imgY + imgH - 40 * scale, w, 40 * scale);

    // Subhead
    const subY = imgY + imgH + 20 * scale;
    const subSize = format.width < 200 ? 11 * scale : 13 * scale;
    ctx.font = `normal ${subSize}px ${fontFamily}`;
    ctx.fillStyle = subtextColor;
    drawWrappedText(ctx, copy.subhead, p, subY, w - p * 2, subSize * 1.35, 3);

    // CTA Button at bottom
    const ctaH = 44 * scale;
    const ctaY = h - ctaH - p * 1.5;
    drawButton(ctx, copy.cta, p, ctaY, w - p * 2, ctaH, creative.primaryColor, fontFamily, scale);
  } else if (format.shape === 'story') {
    // 1080x1920 Vertical Mobile Story
    // Full background image with dark vignette, hero copy at top-middle, CTA at bottom
    drawImageCover(ctx, img, 0, 0, w, h);

    // Cinematic vignette
    const vig = ctx.createLinearGradient(0, 0, 0, h);
    vig.addColorStop(0, 'rgba(15, 23, 42, 0.85)');
    vig.addColorStop(0.35, 'rgba(15, 23, 42, 0.2)');
    vig.addColorStop(0.65, 'rgba(15, 23, 42, 0.4)');
    vig.addColorStop(1, 'rgba(15, 23, 42, 0.95)');
    ctx.fillStyle = vig;
    ctx.fillRect(0, 0, w, h);

    // Brand Header
    const brandY = 80 * scale;
    ctx.font = `600 ${24 * scale}px ${fontFamily}`;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.textAlign = 'center';
    ctx.fillText(creative.brandName.toUpperCase(), w / 2, brandY);

    // Offer Badge
    drawBadgeCentered(ctx, creative.offerBadge, w / 2, brandY + 40 * scale, 32 * scale, creative.primaryColor, scale);

    // Big Headline
    const headSize = 48 * scale;
    ctx.font = `bold ${headSize}px ${fontFamily}`;
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    drawWrappedTextCentered(ctx, copy.headline, w / 2, h * 0.68, w - 80 * scale, headSize * 1.25, 3);

    // Subhead
    const subSize = 22 * scale;
    ctx.font = `normal ${subSize}px ${fontFamily}`;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    drawWrappedTextCentered(ctx, copy.subhead, w / 2, h * 0.8, w - 120 * scale, subSize * 1.4, 2);

    // Swipe up / Tap CTA
    const btnW = w - 140 * scale;
    const btnH = 68 * scale;
    const btnY = h - btnH - 120 * scale;
    drawButton(ctx, copy.cta + ' →', (w - btnW) / 2, btnY, btnW, btnH, creative.primaryColor, fontFamily, scale, 24 * scale);

    // Reset align
    ctx.textAlign = 'start';
  } else {
    // Square / Medium Rect / Large Rect / Social Landscape
    // Top or Background: Image, Bottom: Content Card
    const isSocialLandscape = format.shape === 'socialLandscape';

    if (isSocialLandscape) {
      // 1200x628 - Left half text, Right half image OR Full bg with left overlay
      drawImageCover(ctx, img, w * 0.42, 0, w * 0.58, h);

      const grad = ctx.createLinearGradient(w * 0.35, 0, w * 0.55, 0);
      grad.addColorStop(0, '#0F172A');
      grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(w * 0.35, 0, w * 0.25, h);

      // Left panel
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(0, 0, w * 0.4, h);

      const leftW = w * 0.38 - p * 2;
      drawBadge(ctx, creative.offerBadge, p * 2, p * 2, 28 * scale, creative.primaryColor, scale);

      const headSize = 34 * scale;
      ctx.font = `bold ${headSize}px ${fontFamily}`;
      ctx.fillStyle = textColor;
      drawWrappedText(ctx, copy.headline, p * 2, p * 2 + 56 * scale, leftW, headSize * 1.25, 3);

      const subSize = 18 * scale;
      ctx.font = `normal ${subSize}px ${fontFamily}`;
      ctx.fillStyle = subtextColor;
      drawWrappedText(ctx, copy.subhead, p * 2, p * 2 + 180 * scale, leftW, subSize * 1.4, 3);

      const btnW = 200 * scale;
      const btnH = 48 * scale;
      drawButton(ctx, copy.cta, p * 2, h - btnH - p * 2, btnW, btnH, creative.primaryColor, fontFamily, scale);
    } else {
      // Standard 300x250 or 336x280 or 250x250
      const imgH = h * 0.52;
      drawImageCover(ctx, img, 0, 0, w, imgH);

      // Dark card fade
      const grad = ctx.createLinearGradient(0, imgH - 30 * scale, 0, imgH);
      grad.addColorStop(0, 'rgba(15, 23, 42, 0)');
      grad.addColorStop(1, '#0F172A');
      ctx.fillStyle = grad;
      ctx.fillRect(0, imgH - 30 * scale, w, 30 * scale);

      // Offer badge top right
      drawBadge(ctx, creative.offerBadge, p, p * 0.8, 20 * scale, creative.primaryColor, scale);

      // Bottom half
      const textY = imgH + 16 * scale;
      const headSize = Math.min(17 * scale, w * 0.055);
      ctx.font = `bold ${headSize}px ${fontFamily}`;
      ctx.fillStyle = textColor;
      drawWrappedText(ctx, copy.headline, p, textY, w - p * 2, headSize * 1.2, 2);

      const subSize = Math.max(10 * scale, headSize * 0.65);
      ctx.font = `normal ${subSize}px ${fontFamily}`;
      ctx.fillStyle = subtextColor;
      drawWrappedText(ctx, copy.subhead, p, textY + headSize * 2.2, w - p * 2, subSize * 1.3, 2);

      const btnH = Math.min(36 * scale, h * 0.16);
      const btnY = h - btnH - p * 0.9;
      drawButton(ctx, copy.cta, p, btnY, w - p * 2, btnH, creative.primaryColor, fontFamily, scale);
    }
  }
}

function renderGraphicFallback(
  ctx: CanvasRenderingContext2D,
  format: BannerFormat,
  creative: AdCreativeData,
  w: number,
  h: number,
  copy: { headline: string; subhead: string; cta: string },
  textColor: string,
  subtextColor: string,
  fontFamily: string,
  scale: number
) {
  // Vibrant abstract aesthetic background
  const grad = ctx.createLinearGradient(0, 0, w, h);
  grad.addColorStop(0, '#0F172A');
  grad.addColorStop(0.5, creative.primaryColor || '#1E3A8A');
  grad.addColorStop(1, '#020617');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  const p = 16 * scale;
  drawBadge(ctx, creative.offerBadge, p, p, 24 * scale, creative.primaryColor, scale);

  const headSize = Math.max(14 * scale, Math.min(32 * scale, h * 0.15));
  ctx.font = `bold ${headSize}px ${fontFamily}`;
  ctx.fillStyle = textColor;
  drawWrappedText(ctx, copy.headline, p, p + 40 * scale, w - p * 2, headSize * 1.25, 3);

  const btnH = 40 * scale;
  drawButton(ctx, copy.cta, p, h - btnH - p, Math.min(w - p * 2, 200 * scale), btnH, '#FFFFFF', fontFamily, scale, 14 * scale, '#0F172A');
}

function drawImageCover(ctx: CanvasRenderingContext2D, img: HTMLImageElement, x: number, y: number, w: number, h: number) {
  const imgRatio = img.width / img.height;
  const targetRatio = w / h;
  let sx = 0;
  let sy = 0;
  let sw = img.width;
  let sh = img.height;

  if (imgRatio > targetRatio) {
    sw = img.height * targetRatio;
    sx = (img.width - sw) / 2;
  } else {
    sh = img.width / targetRatio;
    sy = (img.height - sh) / 2;
  }

  ctx.drawImage(img, sx, sy, sw, sh, x, y, w, h);
}

function drawBadge(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, height: number, color: string, scale: number) {
  if (!text) return;
  const fontSize = height * 0.55;
  ctx.font = `bold ${fontSize}px sans-serif`;
  const textWidth = ctx.measureText(text.toUpperCase()).width;
  const padX = 8 * scale;
  const badgeW = textWidth + padX * 2;
  const radius = height / 2;

  ctx.fillStyle = color || '#D97706';
  roundRect(ctx, x, y, badgeW, height, radius);
  ctx.fill();

  ctx.fillStyle = '#FFFFFF';
  ctx.fillText(text.toUpperCase(), x + padX, y + height * 0.7);
}

function drawBadgeCentered(ctx: CanvasRenderingContext2D, text: string, centerX: number, y: number, height: number, color: string, scale: number) {
  if (!text) return;
  const fontSize = height * 0.55;
  ctx.font = `bold ${fontSize}px sans-serif`;
  const textWidth = ctx.measureText(text.toUpperCase()).width;
  const padX = 14 * scale;
  const badgeW = textWidth + padX * 2;
  const x = centerX - badgeW / 2;
  const radius = height / 2;

  ctx.fillStyle = color || '#D97706';
  roundRect(ctx, x, y, badgeW, height, radius);
  ctx.fill();

  ctx.fillStyle = '#FFFFFF';
  ctx.textAlign = 'center';
  ctx.fillText(text.toUpperCase(), centerX, y + height * 0.7);
}

function drawButton(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  w: number,
  h: number,
  bgColor: string,
  fontFamily: string,
  scale: number,
  customFontSize?: number,
  customTextColor?: string
) {
  const radius = Math.min(8 * scale, h / 3);

  // Shadow
  ctx.save();
  ctx.shadowColor = 'rgba(0,0,0,0.35)';
  ctx.shadowBlur = 8 * scale;
  ctx.shadowOffsetY = 3 * scale;

  ctx.fillStyle = bgColor || '#2563EB';
  roundRect(ctx, x, y, w, h, radius);
  ctx.fill();
  ctx.restore();

  // Text
  const fontSize = customFontSize || Math.max(10 * scale, Math.min(16 * scale, h * 0.42));
  ctx.font = `bold ${fontSize}px ${fontFamily}`;
  ctx.fillStyle = customTextColor || '#FFFFFF';
  ctx.textAlign = 'center';
  ctx.fillText(text, x + w / 2, y + h * 0.64);
  ctx.textAlign = 'start';
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function truncateText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string {
  if (ctx.measureText(text).width <= maxWidth) return text;
  let t = text;
  while (t.length > 3 && ctx.measureText(t + '...').width > maxWidth) {
    t = t.slice(0, -1);
  }
  return t + '...';
}

function drawWrappedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
  maxLines: number = 3
) {
  const words = text.split(' ');
  let line = '';
  let lineCount = 0;

  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const metrics = ctx.measureText(testLine);
    const testWidth = metrics.width;

    if (testWidth > maxWidth && n > 0) {
      if (lineCount === maxLines - 1) {
        ctx.fillText(truncateText(ctx, line.trim(), maxWidth), x, y + lineCount * lineHeight);
        return;
      }
      ctx.fillText(line.trim(), x, y + lineCount * lineHeight);
      line = words[n] + ' ';
      lineCount++;
    } else {
      line = testLine;
    }
  }
  if (lineCount < maxLines) {
    ctx.fillText(line.trim(), x, y + lineCount * lineHeight);
  }
}

function drawWrappedTextCentered(
  ctx: CanvasRenderingContext2D,
  text: string,
  centerX: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
  maxLines: number = 3
) {
  const words = text.split(' ');
  let line = '';
  let lineCount = 0;

  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const testWidth = ctx.measureText(testLine).width;

    if (testWidth > maxWidth && n > 0) {
      if (lineCount === maxLines - 1) {
        ctx.fillText(truncateText(ctx, line.trim(), maxWidth), centerX, y + lineCount * lineHeight);
        return;
      }
      ctx.fillText(line.trim(), centerX, y + lineCount * lineHeight);
      line = words[n] + ' ';
      lineCount++;
    } else {
      line = testLine;
    }
  }
  if (lineCount < maxLines) {
    ctx.fillText(line.trim(), centerX, y + lineCount * lineHeight);
  }
}

export function downloadCanvasAsPng(canvas: HTMLCanvasElement, filename: string) {
  const dataUrl = canvas.toDataURL('image/png');
  const a = document.createElement('a');
  a.href = dataUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}
