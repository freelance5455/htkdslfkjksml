import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calcInvoice,
  calculateDistanceMeters,
  allocatePaymentToInvoices,
  getArabicDayName,
  getEffectiveThreshold,
  isStockBelowSafetyThreshold,
  getStockSafetyPercentage,
  getSafetyStockDeficit,
  calcVisitStatusDistribution,
  calcInventoryTotals,
} from './calc.ts';

test('calcInvoice calculates subtotal, line discounts and monthly discount accurately', () => {
  const cart = [
    { productId: 'P1', name: 'زيت طعام', price: 65, qty: 2, itemDiscount: 10 }, // 130 - 10 = 120
    { productId: 'P2', name: 'أرز فاخر', price: 180, qty: 1, itemDiscount: 0 },  // 180
  ];
  const result = calcInvoice(cart, 5); // 5% discount on 300 = 15
  assert.equal(result.subtotal, 300);
  assert.equal(result.monthlyDiscountRate, 5);
  assert.equal(result.monthlyDiscountValue, 15);
  assert.equal(result.grandTotal, 285);
});

test('calcInvoice prevents negative numbers and caps item discount to gross line total', () => {
  const cart = [
    { productId: 'P1', name: 'سكر', price: 35, qty: 1, itemDiscount: 100 }, // gross 35, capped disc 35 = 0
  ];
  const result = calcInvoice(cart, 10);
  assert.equal(result.lines[0].lineTotal, 0);
  assert.equal(result.subtotal, 0);
  assert.equal(result.grandTotal, 0);
});

test('calculateDistanceMeters calculates accurate distance between two nearby coordinates', () => {
  // Distance between Tahrir square (approx 30.0444, 31.2357) and nearby point (~110 meters)
  const d = calculateDistanceMeters(30.0444, 31.2357, 30.0454, 31.2357);
  assert.ok(d > 90 && d < 130, `Distance ${d} should be approx 111 meters`);
});

test('allocatePaymentToInvoices satisfies debts FIFO across multiple invoices', () => {
  const invoices = [
    { id: 'INV-1', remainingAmount: 100, paidAmount: 0 },
    { id: 'INV-2', remainingAmount: 150, paidAmount: 50 },
  ];
  const { updatedInvoices, unallocatedAmount } = allocatePaymentToInvoices(invoices, 150);
  
  assert.equal(updatedInvoices[0].remainingAmount, 0);
  assert.equal(updatedInvoices[0].paidAmount, 100);
  assert.equal(updatedInvoices[1].remainingAmount, 100);
  assert.equal(updatedInvoices[1].paidAmount, 100);
  assert.equal(unallocatedAmount, 0);
});

test('getArabicDayName returns accurate Arabic day of week', () => {
  assert.equal(getArabicDayName('2026-10-18'), 'الأحد'); // Sunday Oct 18 2026
});

test('getEffectiveThreshold uses global threshold when configured or product minQty', () => {
  assert.equal(getEffectiveThreshold(10, 20), 20); // Global 20 overrides product 10
  assert.equal(getEffectiveThreshold(15, 0), 15);  // Fallback to product minQty 15
  assert.equal(getEffectiveThreshold(0, 0), 0);
});

test('isStockBelowSafetyThreshold triggers warning when stock is less than or equal to threshold', () => {
  assert.equal(isStockBelowSafetyThreshold(10, 20, 15), true);  // 10 <= 15
  assert.equal(isStockBelowSafetyThreshold(15, 20, 15), true);  // 15 <= 15 (boundary)
  assert.equal(isStockBelowSafetyThreshold(25, 20, 15), false); // 25 > 15
});

test('getStockSafetyPercentage computes scale accurately', () => {
  assert.equal(getStockSafetyPercentage(10, 20, 20), 25); // 10 / (20*2) = 25%
  assert.equal(getStockSafetyPercentage(40, 20, 20), 100); // 40 / 40 = 100%
});

test('getSafetyStockDeficit accurately calculates replenishment needed to reach threshold', () => {
  // If van has 5 pieces and threshold is 15, deficit is 10
  assert.equal(getSafetyStockDeficit(5, 20, 15), 10);
  // If van has 0 pieces (completely empty) and threshold is 15, deficit is 15
  assert.equal(getSafetyStockDeficit(0, 20, 15), 15);
  // If van has 20 pieces (exceeds threshold 15), deficit is 0
  assert.equal(getSafetyStockDeficit(20, 20, 15), 0);
  // Boundary: van has exactly 15 pieces, deficit is 0
  assert.equal(getSafetyStockDeficit(15, 20, 15), 0);
});

test('calcVisitStatusDistribution categorizes completed, cancelled, and postponed visits correctly', () => {
  const visits = [
    { status: 'تمت الزيارة' },
    { status: 'تمت' },
    { status: 'لم تتم - المحل مغلق' },
    { status: 'ملغاة' },
    { status: 'مؤجلة' },
    { status: 'زيارة مؤجلة' },
  ];
  const dist = calcVisitStatusDistribution(visits);
  assert.equal(dist.completed, 2);
  assert.equal(dist.cancelled, 2);
  assert.equal(dist.postponed, 2);
  assert.equal(dist.total, 6);
});

test('calcInventoryTotals calculates quantities, cost valuation, and sale valuation', () => {
  const products = [
    { id: 'p1', cost: 50, price: 65 },
    { id: 'p2', cost: 100, price: 130 },
  ];
  const stockMap = new Map([
    ['p1', 10], // cost: 500, sale: 650
    ['p2', 5],  // cost: 500, sale: 650
  ]);
  const totals = calcInventoryTotals(products, stockMap);
  assert.equal(totals.totalQty, 15);
  assert.equal(totals.totalCostValue, 1000);
  assert.equal(totals.totalSaleValue, 1300);
});



