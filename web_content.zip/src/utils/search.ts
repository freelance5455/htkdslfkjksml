/**
 * Turkish-aware text normalization and flexible search engine.
 * Solves keyboard differences (e.g. typing English 'c' for 'ç', 's' for 'ş',
 * 'g' for 'ğ', 'i' for 'ı', 'o' for 'ö', 'u' for 'ü' and vice-versa)
 * as well as multi-word queries, HTML content stripping, checklist tasks, and attachments.
 */

import { Note } from "../types";

/**
 * Normalizes text for search comparison by folding Turkish special letters,
 * converting to lowercase, stripping diacritics and collapsing extra whitespace.
 */
export function normalizeTurkishText(str: string): string {
  if (!str) return "";

  return str
    .replace(/İ/g, "i")
    .replace(/I/g, "i")
    .replace(/ı/g, "i")
    .replace(/Ğ/g, "g")
    .replace(/ğ/g, "g")
    .replace(/Ü/g, "u")
    .replace(/ü/g, "u")
    .replace(/Ş/g, "s")
    .replace(/ş/g, "s")
    .replace(/Ö/g, "o")
    .replace(/ö/g, "o")
    .replace(/Ç/g, "c")
    .replace(/ç/g, "c")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Strips HTML tags and decoded entities from raw rich-text HTML
 */
export function stripHtmlToPlainText(html: string): string {
  if (!html) return "";
  return html
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Checks if a search query matches the given note across all its fields:
 * - Title
 * - Markdown / Plain Content
 * - Rich HTML Content (stripped)
 * - Tags
 * - Task Checklist Items
 * - Attachment Names
 */
export function matchNoteWithSearch(note: Note, query: string): boolean {
  if (!query || !query.trim()) return true;

  const normalizedQuery = normalizeTurkishText(query);
  if (!normalizedQuery) return true;

  // Split multi-word query (e.g. "toplantı cuma" -> must match both tokens)
  const tokens = normalizedQuery.split(" ").filter((t) => t.length > 0);

  // Compile searchable text corpus for the note
  const rawFields: string[] = [
    note.title || "",
    note.content || "",
    note.htmlContent ? stripHtmlToPlainText(note.htmlContent) : "",
    note.category || "",
    ...(note.tags || []),
    ...(note.tasks || []).map((t) => t.text || ""),
    ...(note.attachments || []).map((a) => a.name || ""),
  ];

  const searchableCorpus = normalizeTurkishText(rawFields.join(" "));

  // Every token must appear in the note corpus
  return tokens.every((token) => searchableCorpus.includes(token));
}
