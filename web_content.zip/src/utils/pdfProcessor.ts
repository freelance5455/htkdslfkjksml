import { PDFDocument } from 'pdf-lib';
import * as pdfjsLib from 'pdfjs-dist';

// Configure pdfjs worker if in browser
if (typeof window !== 'undefined') {
  pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;
}

export interface RenderedPdfPage {
  pageNumber: number;
  dataUrl: string;
  width: number;
  height: number;
  blob?: Blob;
}

export interface PdfConversionOptions {
  scale: number; // 1.0 (72 dpi), 2.0 (150 dpi), 3.0 (300 dpi)
  imageFormat: 'image/png' | 'image/jpeg';
  quality: number; // 0.1 to 1.0
  pageRange?: string; // "all", "1-3", "2,4,6", etc.
  onProgress?: (progress: number, current: number, total: number) => void;
}

// Parse page range string into array of 1-based page numbers
export function parsePageRange(rangeStr: string, totalPages: number): number[] {
  if (!rangeStr || rangeStr.toLowerCase() === 'all') {
    return Array.from({ length: totalPages }, (_, i) => i + 1);
  }
  if (rangeStr.toLowerCase() === 'odd') {
    return Array.from({ length: totalPages }, (_, i) => i + 1).filter(p => p % 2 !== 0);
  }
  if (rangeStr.toLowerCase() === 'even') {
    return Array.from({ length: totalPages }, (_, i) => i + 1).filter(p => p % 2 === 0);
  }

  const pages = new Set<number>();
  const parts = rangeStr.split(/[,;\s]+/).map(p => p.trim()).filter(Boolean);

  for (const part of parts) {
    if (part.includes('-')) {
      const [startStr, endStr] = part.split('-');
      const start = Math.max(1, parseInt(startStr, 10) || 1);
      const end = Math.min(totalPages, parseInt(endStr, 10) || totalPages);
      for (let p = start; p <= end; p++) {
        pages.add(p);
      }
    } else {
      const p = parseInt(part, 10);
      if (p >= 1 && p <= totalPages) {
        pages.add(p);
      }
    }
  }

  const result = Array.from(pages).sort((a, b) => a - b);
  return result.length > 0 ? result : Array.from({ length: totalPages }, (_, i) => i + 1);
}

// Convert PDF file or ArrayBuffer to an array of high-res image pages
export async function convertPdfToImages(
  pdfSource: ArrayBuffer | Uint8Array | File,
  options: PdfConversionOptions
): Promise<RenderedPdfPage[]> {
  let arrayBuffer: ArrayBuffer;
  if (pdfSource instanceof File) {
    arrayBuffer = await pdfSource.arrayBuffer();
  } else if (pdfSource instanceof Uint8Array) {
    arrayBuffer = pdfSource.buffer.slice(pdfSource.byteOffset, pdfSource.byteOffset + pdfSource.byteLength) as ArrayBuffer;
  } else {
    arrayBuffer = pdfSource;
  }

  const loadingTask = pdfjsLib.getDocument({
    data: new Uint8Array(arrayBuffer),
    cMapUrl: `https://unpkg.com/pdfjs-dist@${pdfjsLib.version}/cmaps/`,
    cMapPacked: true
  });

  const pdf = await loadingTask.promise;
  const totalPages = pdf.numPages;
  const targetPages = parsePageRange(options.pageRange || 'all', totalPages);
  const renderedPages: RenderedPdfPage[] = [];

  for (let i = 0; i < targetPages.length; i++) {
    const pageNum = targetPages[i];
    options.onProgress?.(i / targetPages.length, pageNum, targetPages.length);

    const page = await pdf.getPage(pageNum);
    const viewport = page.getViewport({ scale: options.scale || 2.0 });

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    if (!context) continue;

    canvas.width = viewport.width;
    canvas.height = viewport.height;

    // Fill white background for JPEG exports or opaque rendering
    context.fillStyle = '#FFFFFF';
    context.fillRect(0, 0, canvas.width, canvas.height);

    const renderContext = {
      canvasContext: context,
      viewport: viewport
    };

    // Cast to any to bypass pdfjs internal RenderParameters typing
    await (page.render(renderContext as any)).promise;

    const dataUrl = canvas.toDataURL(options.imageFormat, options.quality);

    // Also create blob for efficient saving
    const blob = await new Promise<Blob>((resolve) => {
      canvas.toBlob(
        (b) => resolve(b || new Blob()),
        options.imageFormat,
        options.quality
      );
    });

    renderedPages.push({
      pageNumber: pageNum,
      dataUrl,
      width: viewport.width,
      height: viewport.height,
      blob
    });
  }

  options.onProgress?.(1.0, totalPages, totalPages);
  return renderedPages;
}

// Extract full text content from PDF pages
export async function extractTextFromPdf(pdfSource: ArrayBuffer | File): Promise<string> {
  const arrayBuffer = pdfSource instanceof File ? await pdfSource.arrayBuffer() : pdfSource;
  const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(arrayBuffer) });
  const pdf = await loadingTask.promise;

  let fullText = '';
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const pageStrings = textContent.items
      .map((item: any) => ('str' in item ? item.str : ''))
      .filter(Boolean);
    fullText += pageStrings.join(' ') + '\n\n';
  }

  return fullText.trim();
}

// Merge multiple PDF files into one combined PDF
export async function mergePdfFiles(pdfFiles: Array<File | ArrayBuffer>): Promise<Blob> {
  const mergedPdf = await PDFDocument.create();

  for (const file of pdfFiles) {
    const buffer = file instanceof File ? await file.arrayBuffer() : file;
    const doc = await PDFDocument.load(buffer, { ignoreEncryption: true });
    const copiedPages = await mergedPdf.copyPages(doc, doc.getPageIndices());
    copiedPages.forEach((page) => mergedPdf.addPage(page));
  }

  const mergedPdfBytes = await mergedPdf.save();
  return new Blob([mergedPdfBytes as any], { type: 'application/pdf' });
}

// Convert image files into a multi-page PDF (Original-image mode)
export async function convertImagesToPdf(
  images: Array<{ file?: File; dataUrl?: string }>,
  pageSize: 'A4' | 'Letter' = 'A4',
  marginsInches: number = 0.5
): Promise<Blob> {
  const pdfDoc = await PDFDocument.create();
  const pageDims = pageSize === 'A4' ? { width: 595.28, height: 841.89 } : { width: 612.0, height: 792.0 };
  const marginPt = marginsInches * 72;
  const maxContentW = pageDims.width - (marginPt * 2);
  const maxContentH = pageDims.height - (marginPt * 2);

  for (const item of images) {
    let imgBytes: Uint8Array;
    let isPng = true;

    if (item.dataUrl) {
      isPng = item.dataUrl.startsWith('data:image/png');
      const base64Data = item.dataUrl.split(',')[1];
      const binaryString = atob(base64Data);
      imgBytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        imgBytes[i] = binaryString.charCodeAt(i);
      }
    } else if (item.file) {
      isPng = item.file.type.includes('png');
      const ab = await item.file.arrayBuffer();
      imgBytes = new Uint8Array(ab);
    } else {
      continue;
    }

    let embeddedImg;
    try {
      embeddedImg = isPng ? await pdfDoc.embedPng(imgBytes) : await pdfDoc.embedJpg(imgBytes);
    } catch (e) {
      // Try opposite embedder if header mismatch
      try {
        embeddedImg = isPng ? await pdfDoc.embedJpg(imgBytes) : await pdfDoc.embedPng(imgBytes);
      } catch (err) {
        console.error('Failed to embed image into PDF:', err);
        continue;
      }
    }

    const imgWidth = embeddedImg.width;
    const imgHeight = embeddedImg.height;

    // Calculate aspect fit within page margins
    const scale = Math.min(maxContentW / imgWidth, maxContentH / imgHeight, 1.0);
    const renderW = imgWidth * scale;
    const renderH = imgHeight * scale;

    const page = pdfDoc.addPage([pageDims.width, pageDims.height]);
    const xPos = marginPt + (maxContentW - renderW) / 2;
    const yPos = marginPt + (maxContentH - renderH) / 2;

    page.drawImage(embeddedImg, {
      x: xPos,
      y: yPos,
      width: renderW,
      height: renderH
    });
  }

  const pdfBytes = await pdfDoc.save();
  return new Blob([pdfBytes as any], { type: 'application/pdf' });
}
