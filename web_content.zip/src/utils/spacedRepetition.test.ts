import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateNextReviewDate,
  calculateRetention,
  calculateMasteryScore,
  getMasteryTier,
  processTopicReview,
  isDueForReview,
  getDaysUntilReview,
  FORGETTING_INTERVALS,
} from './spacedRepetition';
import { Topic } from '../types';

test('Forgetting curve intervals correspond to Day 1, 3, 7, 21, 30 milestones', () => {
  assert.equal(FORGETTING_INTERVALS[0], 1);
  assert.equal(FORGETTING_INTERVALS[1], 3);
  assert.equal(FORGETTING_INTERVALS[2], 7);
  assert.equal(FORGETTING_INTERVALS[3], 21);
  assert.equal(FORGETTING_INTERVALS[4], 30);
  assert.equal(FORGETTING_INTERVALS[5], 60);
});

test('calculateNextReviewDate with "good" advances to next stage and schedules correct milestone', () => {
  const base = new Date('2026-05-01T12:00:00Z');
  const res = calculateNextReviewDate(0, 'good', base);
  assert.equal(res.nextStage, 1);
  assert.equal(res.nextReviewDate, '2026-05-02'); // +1 day

  // From stage 1 to stage 2 (Day 1 -> Day 3, +2 days)
  const res2 = calculateNextReviewDate(1, 'good', base);
  assert.equal(res2.nextStage, 2);
  assert.equal(res2.nextReviewDate, '2026-05-03'); // +2 days
});

test('calculateNextReviewDate with "again" resets stage to 0 and schedules review for next day', () => {
  const base = new Date('2026-05-01T12:00:00Z');
  const res = calculateNextReviewDate(4, 'again', base);
  assert.equal(res.nextStage, 0);
  assert.equal(res.nextReviewDate, '2026-05-02');
});

test('calculateRetention decays over time based on memory stability', () => {
  const t0 = new Date('2026-05-01T10:00:00Z');
  // At t=0, retention should be 100%
  const ret0 = calculateRetention('2026-05-01T10:00:00Z', '2026-05-01T10:00:00Z', 5, t0);
  assert.equal(ret0, 100);

  // 5 days later with stability=5, retention = e^(-1) * 100 ≈ 37%
  const t5 = new Date('2026-05-06T10:00:00Z');
  const ret5 = calculateRetention('2026-05-01T10:00:00Z', '2026-05-01T10:00:00Z', 5, t5);
  assert.ok(ret5 >= 35 && ret5 <= 38, `Expected ~37%, got ${ret5}`);
});

test('getMasteryTier maps mastery scores to color-coded bands correctly', () => {
  assert.equal(getMasteryTier(5).label, 'Initial Learning');
  assert.equal(getMasteryTier(20).label, 'Initial Recall (Day 1)');
  assert.equal(getMasteryTier(40).label, 'Consolidating (Day 3)');
  assert.equal(getMasteryTier(60).label, 'Consolidated (Day 7)');
  assert.equal(getMasteryTier(75).label, 'Long-Term Transfer (Day 21)');
  assert.equal(getMasteryTier(90).label, 'Deep Retention (Day 30)');
  assert.equal(getMasteryTier(98).label, 'Mastered (Day 60+)');
});

test('processTopicReview produces a consistent updated Topic with history', () => {
  const sampleTopic: Topic = {
    id: 't-1',
    title: 'Cellular Respiration',
    categoryId: 'med',
    notes: 'Glycolysis, Krebs cycle, oxidative phosphorylation.',
    keyConcepts: ['ATP', 'Mitochondria'],
    createdAt: '2026-05-01T00:00:00Z',
    nextReviewDate: '2026-05-02',
    stage: 0,
    masteryScore: 10,
    stability: 2,
    consecutiveSuccesses: 0,
    history: [],
    flashcards: [],
  };

  const updated = processTopicReview(sampleTopic, 'good', new Date('2026-05-02T10:00:00Z'));
  assert.equal(updated.stage, 1);
  assert.equal(updated.consecutiveSuccesses, 1);
  assert.ok(updated.masteryScore > sampleTopic.masteryScore);
  assert.equal(updated.history.length, 1);
  assert.equal(updated.history[0].rating, 'good');
});

test('isDueForReview detects overdue or due topics correctly', () => {
  const today = new Date('2026-05-10T12:00:00Z');
  assert.equal(isDueForReview('2026-05-09', today), true);
  assert.equal(isDueForReview('2026-05-10', today), true);
  assert.equal(isDueForReview('2026-05-11', today), false);
  assert.equal(getDaysUntilReview('2026-05-13', today), 3);
  assert.equal(getDaysUntilReview('2026-05-08', today), -2);
});
