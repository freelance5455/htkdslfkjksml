import type { ComicInfoMetadata, ComicPageInfo, TocBookmark } from '../types/comic';

function getText(parent: Element, tagName: string): string | undefined {
  const els = parent.getElementsByTagName(tagName);
  if (!els || els.length === 0) return undefined;
  const val = els[0].textContent?.trim();
  return val && val.length > 0 ? val : undefined;
}

function getNumber(parent: Element, tagName: string): number | undefined {
  const txt = getText(parent, tagName);
  if (!txt) return undefined;
  const parsed = Number(txt);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function getIntAttr(el: Element, names: string[]): number | undefined {
  for (const name of names) {
    const raw = el.getAttribute(name);
    if (raw !== null && raw.trim() !== '') {
      const n = parseInt(raw.trim(), 10);
      if (Number.isFinite(n)) return n;
    }
  }
  return undefined;
}

function getStrAttr(el: Element, names: string[]): string | undefined {
  for (const name of names) {
    const raw = el.getAttribute(name);
    if (raw !== null && raw.trim() !== '') {
      return raw.trim();
    }
  }
  return undefined;
}

/**
 * Parses a ComicInfo.xml document (Anansi / ComicRack / Kavita / Komga / Kuro Reader compatible).
 * Builds a unified Table of Contents from both:
 * 1) <Pages><Page Image="N" Bookmark="..." Type="..." /></Pages>
 * 2) <Bookmarks> tags (supports <Bookmark Page="..." Title="..." /> elements or structured text).
 */
export function parseComicInfoXml(xmlString: string): ComicInfoMetadata | undefined {
  const cleaned = xmlString.replace(/^\uFEFF/, '').trim();
  if (!cleaned) return undefined;

  const parser = new DOMParser();
  const doc = parser.parseFromString(cleaned, 'application/xml');
  const parserError = doc.querySelector('parsererror');
  if (parserError) {
    return undefined;
  }

  const root = doc.documentElement;
  if (!root || root.tagName.toLowerCase() !== 'comicinfo') {
    return undefined;
  }

  const pages: ComicPageInfo[] = [];
  const toc: TocBookmark[] = [];
  const seenKey = new Set<string>();

  const pushToc = (entry: TocBookmark) => {
    const normTitle = entry.title.trim();
    if (!normTitle || entry.pageIndex < 0) return;
    const dedupeKey = `${entry.pageIndex}::${normTitle.toLowerCase()}`;
    if (seenKey.has(dedupeKey)) return;
    seenKey.add(dedupeKey);
    toc.push({
      pageIndex: entry.pageIndex,
      title: normTitle,
      type: entry.type,
      source: entry.source,
    });
  };

  // 1) Parse <Pages><Page ... /></Pages>
  const pagesContainer = root.getElementsByTagName('Pages')[0];
  if (pagesContainer) {
    const pageEls = pagesContainer.getElementsByTagName('Page');
    for (let i = 0; i < pageEls.length; i++) {
      const el = pageEls[i];
      const imageIndex = getIntAttr(el, ['Image', 'image', 'Page', 'page']) ?? i;
      const type = getStrAttr(el, ['Type', 'type']);
      const bookmark = getStrAttr(el, ['Bookmark', 'bookmark', 'Title', 'title']);
      const imageWidth = getIntAttr(el, ['ImageWidth', 'imageWidth']);
      const imageHeight = getIntAttr(el, ['ImageHeight', 'imageHeight']);
      const imageSize = getIntAttr(el, ['ImageSize', 'imageSize']);
      const key = getStrAttr(el, ['Key', 'key']);

      pages.push({
        imageIndex,
        type,
        bookmark,
        imageWidth,
        imageHeight,
        imageSize,
        key,
      });

      if (bookmark) {
        pushToc({
          pageIndex: imageIndex,
          title: bookmark,
          type,
          source: 'pages-bookmark',
        });
      }
    }
  }

  // 2) Parse explicit <Bookmarks> tags (both child <Bookmark> elements and text formats)
  const bookmarksNodes = root.getElementsByTagName('Bookmarks');
  for (let b = 0; b < bookmarksNodes.length; b++) {
    const bNode = bookmarksNodes[b];
    const children = bNode.getElementsByTagName('Bookmark');
    if (children.length > 0) {
      for (let c = 0; c < children.length; c++) {
        const el = children[c];
        const pageIdx = getIntAttr(el, ['Page', 'page', 'Image', 'image', 'PageIndex', 'Index']);
        const attrTitle = getStrAttr(el, ['Title', 'title', 'Name', 'name', 'Label', 'label', 'Bookmark']);
        const textTitle = el.textContent?.trim();
        const title = attrTitle || textTitle;
        if (pageIdx !== undefined && title) {
          pushToc({
            pageIndex: pageIdx,
            title,
            source: 'bookmarks-tag',
          });
        }
      }
    } else {
      // Fallback: text inside <Bookmarks> e.g. "0: Prologue\n5: Chapter 1" or "0, 12, 24"
      const rawText = bNode.textContent?.trim();
      if (rawText) {
        const parts = rawText.split(/\r?\n|;/).map((s) => s.trim()).filter(Boolean);
        for (const part of parts) {
          const match = part.match(/^(\d+)\s*[:=\-]\s*(.+)$/);
          if (match) {
            pushToc({
              pageIndex: parseInt(match[1], 10),
              title: match[2].trim(),
              source: 'bookmarks-tag',
            });
          } else {
            // Comma-separated page indices
            const nums = part.split(',').map((s) => s.trim()).filter(Boolean);
            for (const item of nums) {
              if (/^\d+$/.test(item)) {
                const idx = parseInt(item, 10);
                pushToc({
                  pageIndex: idx,
                  title: `Bookmark · Page ${idx + 1}`,
                  source: 'bookmarks-tag',
                });
              }
            }
          }
        }
      }
    }
  }

  // Sort pages & TOC cleanly
  pages.sort((a, b) => a.imageIndex - b.imageIndex);
  toc.sort((a, b) => a.pageIndex - b.pageIndex);

  return {
    title: getText(root, 'Title'),
    series: getText(root, 'Series'),
    number: getText(root, 'Number'),
    count: getNumber(root, 'Count'),
    volume: getNumber(root, 'Volume'),
    alternateSeries: getText(root, 'AlternateSeries'),
    summary: getText(root, 'Summary'),
    notes: getText(root, 'Notes'),
    year: getNumber(root, 'Year'),
    month: getNumber(root, 'Month'),
    day: getNumber(root, 'Day'),
    writer: getText(root, 'Writer'),
    penciller: getText(root, 'Penciller'),
    inker: getText(root, 'Inker'),
    colorist: getText(root, 'Colorist'),
    letterer: getText(root, 'Letterer'),
    coverArtist: getText(root, 'CoverArtist'),
    editor: getText(root, 'Editor'),
    publisher: getText(root, 'Publisher'),
    imprint: getText(root, 'Imprint'),
    genre: getText(root, 'Genre'),
    tags: getText(root, 'Tags'),
    web: getText(root, 'Web'),
    pageCount: getNumber(root, 'PageCount'),
    languageISO: getText(root, 'LanguageISO'),
    format: getText(root, 'Format'),
    blackAndWhite: getText(root, 'BlackAndWhite'),
    manga: getText(root, 'Manga'),
    ageRating: getText(root, 'AgeRating'),
    communityRating: getNumber(root, 'CommunityRating'),
    storyArc: getText(root, 'StoryArc'),
    seriesGroup: getText(root, 'SeriesGroup'),
    pages,
    toc,
    rawXml: cleaned,
  };
}
