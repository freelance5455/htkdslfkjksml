export interface AndroidCapabilities {
  nativeScreenShare: boolean;
  nativeCameraX?: boolean;
  overlayPermission: boolean;
  sdkInt: number;
  status: string;
}

export interface AndroidScreenStatePayload {
  status: 'idle' | 'requesting' | 'active' | 'paused' | 'stopped' | 'error';
  message: string | null;
  width: number;
  height: number;
  source: string;
  timestamp: number;
}

export interface AndroidCameraStatePayload {
  status: 'idle' | 'starting' | 'active' | 'stopped' | 'error';
  facing: 'back' | 'front';
  message: string | null;
  width: number;
  height: number;
  timestamp: number;
}

export interface AndroidScreenShareInterface {
  isAvailable: () => boolean;
  getCapabilities: () => string;
  startScreenShare: (intervalMs: number) => void;
  pauseScreenShare: () => void;
  resumeScreenShare: () => void;
  stopScreenShare: () => void;
  requestFrameNow: () => void;
  requestOverlayPermission: () => void;
  // Optional CameraX methods attached when running inside upgraded NEXCODE Android APK
  isCameraAvailable?: () => boolean;
  startCamera?: (facingBack: boolean) => void;
  stopCamera?: () => void;
  switchCameraLens?: () => void;
  requestCameraFrameNow?: () => void;
}

declare global {
  interface Window {
    AndroidScreenShare?: AndroidScreenShareInterface;
    __onAndroidScreenFrame?: (
      base64Jpeg: string,
      width: number,
      height: number,
      timestampMs: number
    ) => void;
    __onAndroidScreenState?: (payload: AndroidScreenStatePayload) => void;
    __onAndroidScreenError?: (message: string) => void;
    __onAndroidCapabilities?: (caps: { overlayPermission: boolean }) => void;
    __onAndroidCameraFrame?: (
      base64Jpeg: string,
      width: number,
      height: number,
      timestampMs: number,
      forAiVision?: boolean
    ) => void;
    __onAndroidCameraState?: (payload: AndroidCameraStatePayload) => void;
    __onAndroidCameraError?: (message: string) => void;
  }
}

export function isNativeAndroidScreenShareAvailable(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    return Boolean(window.AndroidScreenShare?.isAvailable?.());
  } catch {
    return false;
  }
}

export function isNativeAndroidCameraAvailable(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    return Boolean(window.AndroidScreenShare?.isCameraAvailable?.());
  } catch {
    return false;
  }
}

export function getNativeAndroidCapabilities(): AndroidCapabilities | null {
  if (!isNativeAndroidScreenShareAvailable()) return null;
  try {
    const raw = window.AndroidScreenShare!.getCapabilities();
    return JSON.parse(raw) as AndroidCapabilities;
  } catch {
    return null;
  }
}

export function startNativeAndroidScreenShare(intervalMs = 950): boolean {
  if (!isNativeAndroidScreenShareAvailable()) return false;
  window.AndroidScreenShare!.startScreenShare(intervalMs);
  return true;
}

export function pauseNativeAndroidScreenShare(): void {
  if (isNativeAndroidScreenShareAvailable()) {
    window.AndroidScreenShare!.pauseScreenShare();
  }
}

export function resumeNativeAndroidScreenShare(): void {
  if (isNativeAndroidScreenShareAvailable()) {
    window.AndroidScreenShare!.resumeScreenShare();
  }
}

export function stopNativeAndroidScreenShare(): void {
  if (isNativeAndroidScreenShareAvailable()) {
    window.AndroidScreenShare!.stopScreenShare();
  }
}

export function requestNativeAndroidFrameNow(): void {
  if (isNativeAndroidScreenShareAvailable()) {
    window.AndroidScreenShare!.requestFrameNow();
  }
}

export function requestNativeOverlayPermission(): void {
  if (isNativeAndroidScreenShareAvailable()) {
    window.AndroidScreenShare!.requestOverlayPermission();
  }
}

export function startNativeAndroidCamera(facingBack = true): boolean {
  if (!isNativeAndroidCameraAvailable()) return false;
  window.AndroidScreenShare!.startCamera?.(facingBack);
  return true;
}

export function stopNativeAndroidCamera(): void {
  if (isNativeAndroidCameraAvailable()) {
    window.AndroidScreenShare!.stopCamera?.();
  }
}

export function switchNativeAndroidCameraLens(): void {
  if (isNativeAndroidCameraAvailable()) {
    window.AndroidScreenShare!.switchCameraLens?.();
  }
}

export function requestNativeAndroidCameraFrameNow(): void {
  if (isNativeAndroidCameraAvailable()) {
    window.AndroidScreenShare!.requestCameraFrameNow?.();
  }
}
