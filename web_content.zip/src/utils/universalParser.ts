// Universal Ingestion & Extraction Engine (BIN & Universal File Parser)
// Magic Bytes / MIME Detection, Carving, Hex Parsing, String/URL Extraction, OCR & Audio Transcript Integration

export interface MagicBytesResult {
  mimeType: string;
  category: "binary" | "office" | "table" | "presentation" | "media" | "audio_video" | "archive" | "code_web";
  formatName: string;
  isEmbeddedContainer: boolean;
}

export interface ExtractedLink {
  url: string;
  type: "http" | "https" | "email" | "ip" | "ftp";
  domain: string;
}

export interface CarvedAsset {
  id: string;
  type: "image" | "audio" | "pdf" | "zip";
  mime: string;
  offset: number;
  size: number;
  dataUrl: string;
  name: string;
}

export interface HexRow {
  offset: string;
  hex: string;
  ascii: string;
}

export interface UniversalParseResult {
  fileName: string;
  fileSize: number;
  magicInfo: MagicBytesResult;
  extractedStrings: string[];
  extractedLinks: ExtractedLink[];
  carvedAssets: CarvedAsset[];
  hexRows: HexRow[];
  ocrText?: string;
  transcriptText?: string;
  formattedText: string;
  htmlCanvasBlock: string;
  blocks: {
    textBlocks: string[];
    imageBlocks: CarvedAsset[];
    mediaBlocks: { name: string; mime: string; dataUrl: string; isAudio: boolean }[];
    linkBlocks: ExtractedLink[];
    hexBlock: HexRow[];
  };
}

// -------------------------------------------------------------
// 1. MAGIC BYTES & MIME DETECTION
// -------------------------------------------------------------
export function detectMagicBytes(buffer: Uint8Array, fileName: string): MagicBytesResult {
  const ext = fileName.split(".").pop()?.toLowerCase() || "";

  if (buffer.length >= 8) {
    // PNG: 89 50 4E 47 0D 0A 1A 0A
    if (buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47) {
      return { mimeType: "image/png", category: "media", formatName: "PNG Görseli", isEmbeddedContainer: false };
    }
    // JPEG: FF D8 FF
    if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
      return { mimeType: "image/jpeg", category: "media", formatName: "JPEG Fotoğrafı", isEmbeddedContainer: false };
    }
    // GIF: 47 49 46 38
    if (buffer[0] === 0x47 && buffer[1] === 0x49 && buffer[2] === 0x46 && buffer[3] === 0x38) {
      return { mimeType: "image/gif", category: "media", formatName: "GIF Animasyonu", isEmbeddedContainer: false };
    }
    // PDF: %PDF (25 50 44 46)
    if (buffer[0] === 0x25 && buffer[1] === 0x50 && buffer[2] === 0x44 && buffer[3] === 0x46) {
      return { mimeType: "application/pdf", category: "office", formatName: "PDF Dokümanı", isEmbeddedContainer: false };
    }
    // ZIP / PKZIP / Office OpenXML (DOCX, XLSX, PPTX, EPUB): PK (50 4B 03 04)
    if (buffer[0] === 0x50 && buffer[1] === 0x4b && buffer[2] === 0x03 && buffer[3] === 0x04) {
      if (ext === "docx" || ext === "doc") {
        return { mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", category: "office", formatName: "Word Dokümanı", isEmbeddedContainer: true };
      }
      if (ext === "xlsx" || ext === "xls") {
        return { mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", category: "table", formatName: "Excel Tablosu", isEmbeddedContainer: true };
      }
      if (ext === "pptx" || ext === "ppt") {
        return { mimeType: "application/vnd.openxmlformats-officedocument.presentationml.presentation", category: "presentation", formatName: "PowerPoint Sunumu", isEmbeddedContainer: true };
      }
      return { mimeType: "application/zip", category: "archive", formatName: "ZIP Arşivi", isEmbeddedContainer: true };
    }
    // ELF Executable: 7F 45 4C 46
    if (buffer[0] === 0x7f && buffer[1] === 0x45 && buffer[2] === 0x4c && buffer[3] === 0x46) {
      return { mimeType: "application/x-executable", category: "binary", formatName: "ELF İkili Çalıştırılabilir Dosya", isEmbeddedContainer: true };
    }
    // Windows Executable / DLL: MZ (4D 5A)
    if (buffer[0] === 0x4d && buffer[1] === 0x5a) {
      return { mimeType: "application/x-msdownload", category: "binary", formatName: "Windows Executable (EXE/DLL)", isEmbeddedContainer: true };
    }
    // MP3 ID3 Tag: ID3 (49 44 33)
    if (buffer[0] === 0x49 && buffer[1] === 0x44 && buffer[2] === 0x33) {
      return { mimeType: "audio/mpeg", category: "audio_video", formatName: "MP3 Ses Kaydı", isEmbeddedContainer: false };
    }
    // MP3 Raw Frame Sync: FF FB or FF F3
    if (buffer[0] === 0xff && (buffer[1] === 0xfb || buffer[1] === 0xf3)) {
      return { mimeType: "audio/mpeg", category: "audio_video", formatName: "MP3 Ses Kaydı", isEmbeddedContainer: false };
    }
    // RIFF Container (WAV/AVI/WEBP): RIFF (52 49 46 46)
    if (buffer[0] === 0x52 && buffer[1] === 0x49 && buffer[2] === 0x46 && buffer[3] === 0x46) {
      if (ext === "webp") return { mimeType: "image/webp", category: "media", formatName: "WEBP Görseli", isEmbeddedContainer: false };
      if (ext === "avi") return { mimeType: "video/x-msvideo", category: "audio_video", formatName: "AVI Video", isEmbeddedContainer: false };
      return { mimeType: "audio/wav", category: "audio_video", formatName: "WAV Ses Kaydı", isEmbeddedContainer: false };
    }
    // MP4 / M4A / MOV Container: ftyp (66 74 79 70) at offset 4
    if (buffer[4] === 0x66 && buffer[5] === 0x74 && buffer[6] === 0x79 && buffer[7] === 0x70) {
      if (ext === "m4a") return { mimeType: "audio/m4a", category: "audio_video", formatName: "M4A Ses Kaydı", isEmbeddedContainer: false };
      return { mimeType: "video/mp4", category: "audio_video", formatName: "MP4 Video Kaydı", isEmbeddedContainer: false };
    }
    // OGG Container: OggS (4F 67 67 53)
    if (buffer[0] === 0x4f && buffer[1] === 0x67 && buffer[2] === 0x67 && buffer[3] === 0x53) {
      return { mimeType: "audio/ogg", category: "audio_video", formatName: "OGG Ses Kaydı", isEmbeddedContainer: false };
    }
    // FLAC Audio: fLaC (66 4C 61 43)
    if (buffer[0] === 0x66 && buffer[1] === 0x4c && buffer[2] === 0x61 && buffer[3] === 0x43) {
      return { mimeType: "audio/flac", category: "audio_video", formatName: "FLAC Kayıpsız Ses", isEmbeddedContainer: false };
    }
    // SQLite Database: SQLite format 3 (53 51 4C 69 74 65)
    if (buffer[0] === 0x53 && buffer[1] === 0x51 && buffer[2] === 0x4c && buffer[3] === 0x69) {
      return { mimeType: "application/x-sqlite3", category: "binary", formatName: "SQLite Veritabanı", isEmbeddedContainer: true };
    }
    // NoteFlow Custom Binary Container: NFLW_BIN (4E 46 4C 57 5F 42 49 4E)
    if (
      buffer[0] === 0x4e && buffer[1] === 0x46 && buffer[2] === 0x4c && buffer[3] === 0x57 &&
      buffer[4] === 0x5f && buffer[5] === 0x42 && buffer[6] === 0x49 && buffer[7] === 0x4e
    ) {
      return { mimeType: "application/x-noteflow-bin", category: "binary", formatName: "NoteFlow İkili Konteyner (.BIN)", isEmbeddedContainer: true };
    }
    // ColorNote Encrypted Backup: NOTE signature (4E 4F 54 45) or colornote in file name
    if (
      (buffer[0] === 0x4e && buffer[1] === 0x4f && buffer[2] === 0x54 && buffer[3] === 0x45) ||
      fileName.toLowerCase().includes("colornote")
    ) {
      return { mimeType: "application/x-colornote-backup", category: "binary", formatName: "ColorNote Şifreli Yedek (.BIN / AES-128)", isEmbeddedContainer: true };
    }
  }

  // Fallbacks based on file extension
  if (["bin", "dat", "hex", "rom", "iso", "img", "raw", "buf", "mem", "so", "exe", "elf"].includes(ext)) {
    return { mimeType: "application/octet-stream", category: "binary", formatName: `İkili Veri / Sistem Dosyası (.${ext.toUpperCase()})`, isEmbeddedContainer: true };
  }
  if (["jpg", "jpeg", "png", "webp", "gif", "svg", "bmp", "tiff", "heic", "raw"].includes(ext)) {
    return { mimeType: `image/${ext}`, category: "media", formatName: `${ext.toUpperCase()} Görseli`, isEmbeddedContainer: false };
  }
  if (["mp3", "wav", "m4a", "flac", "ogg", "aac", "midi"].includes(ext)) {
    return { mimeType: `audio/${ext}`, category: "audio_video", formatName: `${ext.toUpperCase()} Ses`, isEmbeddedContainer: false };
  }
  if (["mp4", "mkv", "avi", "mov", "webm", "flv"].includes(ext)) {
    return { mimeType: `video/${ext}`, category: "audio_video", formatName: `${ext.toUpperCase()} Video`, isEmbeddedContainer: false };
  }
  if (["pdf", "docx", "doc", "txt", "rtf", "epub", "md"].includes(ext)) {
    return { mimeType: "application/text", category: "office", formatName: `${ext.toUpperCase()} Dokümanı`, isEmbeddedContainer: false };
  }
  if (["xlsx", "xls", "csv", "tsv", "ods"].includes(ext)) {
    return { mimeType: "text/csv", category: "table", formatName: `${ext.toUpperCase()} Tablosu`, isEmbeddedContainer: false };
  }
  if (["pptx", "ppt", "odp"].includes(ext)) {
    return { mimeType: "application/vnd.ms-powerpoint", category: "presentation", formatName: `${ext.toUpperCase()} Sunumu`, isEmbeddedContainer: false };
  }
  if (["zip", "rar", "7z", "tar", "gz"].includes(ext)) {
    return { mimeType: "application/zip", category: "archive", formatName: `${ext.toUpperCase()} Arşivi`, isEmbeddedContainer: true };
  }

  return { mimeType: "application/octet-stream", category: "binary", formatName: "Ham Veri / İkili Dosya", isEmbeddedContainer: true };
}

// Helper: Uint8Array to Base64
function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

// -------------------------------------------------------------
// 2. CARVING EMBEDDED DATA FROM BINARY FILES
// -------------------------------------------------------------
export function carveEmbeddedData(buffer: Uint8Array): CarvedAsset[] {
  const carved: CarvedAsset[] = [];
  const maxScan = Math.min(buffer.length, 5000000); // 5MB scan limit for quick carving

  let carvedCount = 0;

  for (let i = 0; i < maxScan - 1000; i++) {
    if (carvedCount >= 8) break;

    // Check embedded JPEG (FF D8 FF)
    if (buffer[i] === 0xff && buffer[i + 1] === 0xd8 && buffer[i + 2] === 0xff) {
      // Find JPEG End of Image (FF D9)
      for (let j = i + 100; j < Math.min(i + 1000000, maxScan - 2); j++) {
        if (buffer[j] === 0xff && buffer[j + 1] === 0xd9) {
          const slice = buffer.slice(i, j + 2);
          if (slice.length > 500) {
            const b64 = bytesToBase64(slice);
            carvedCount++;
            carved.push({
              id: `carved-jpg-${Date.now()}-${carvedCount}`,
              type: "image",
              mime: "image/jpeg",
              offset: i,
              size: slice.length,
              dataUrl: `data:image/jpeg;base64,${b64}`,
              name: `Gömülü_Görsel_${carvedCount}.jpg`,
            });
            i = j + 2;
            break;
          }
        }
      }
    }

    // Check embedded PNG (89 50 4E 47)
    else if (buffer[i] === 0x89 && buffer[i + 1] === 0x50 && buffer[i + 2] === 0x4e && buffer[i + 3] === 0x47) {
      // Find PNG IEND chunk
      for (let j = i + 100; j < Math.min(i + 1000000, maxScan - 8); j++) {
        if (
          buffer[j] === 0x49 && buffer[j + 1] === 0x45 && buffer[j + 2] === 0x4e && buffer[j + 3] === 0x44
        ) {
          const slice = buffer.slice(i, j + 8);
          if (slice.length > 500) {
            const b64 = bytesToBase64(slice);
            carvedCount++;
            carved.push({
              id: `carved-png-${Date.now()}-${carvedCount}`,
              type: "image",
              mime: "image/png",
              offset: i,
              size: slice.length,
              dataUrl: `data:image/png;base64,${b64}`,
              name: `Gömülü_Görsel_${carvedCount}.png`,
            });
            i = j + 8;
            break;
          }
        }
      }
    }
  }

  return carved;
}

// -------------------------------------------------------------
// 3. ASCII & UTF-8 STRINGS + URL/IP HYPERLINK EXTRACTION
// -------------------------------------------------------------
export function extractStringsAndLinks(buffer: Uint8Array): {
  strings: string[];
  links: ExtractedLink[];
} {
  const extractedStrings: string[] = [];
  const extractedLinks: ExtractedLink[] = [];

  let currentStr = "";
  const maxBytes = Math.min(buffer.length, 100000); // 100KB string scan limit

  for (let i = 0; i < maxBytes; i++) {
    const b = buffer[i];
    if (b >= 32 && b <= 126) {
      currentStr += String.fromCharCode(b);
    } else {
      if (currentStr.length >= 4) {
        extractedStrings.push(currentStr);
        if (extractedStrings.length >= 100) break;
      }
      currentStr = "";
    }
  }
  if (currentStr.length >= 4 && extractedStrings.length < 100) {
    extractedStrings.push(currentStr);
  }

  // Extract Links, URLs, IP Addresses, and Emails
  const urlRegex = /(https?:\/\/[^\s<>"'()]+|ftp:\/\/[^\s<>"'()]+|www\.[^\s<>"'()]+)/gi;
  const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/gi;
  const ipRegex = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/g;

  const foundUrls = new Set<string>();

  extractedStrings.forEach((line) => {
    // Check URLs
    const urls = line.match(urlRegex);
    if (urls) {
      urls.forEach((u) => {
        const cleanUrl = u.replace(/[.,;)]$/, "");
        if (!foundUrls.has(cleanUrl)) {
          foundUrls.add(cleanUrl);
          let domain = cleanUrl;
          try {
            const parsed = new URL(cleanUrl.startsWith("http") ? cleanUrl : `http://${cleanUrl}`);
            domain = parsed.hostname;
          } catch {
            // fallback domain
          }
          extractedLinks.push({
            url: cleanUrl.startsWith("http") ? cleanUrl : `https://${cleanUrl}`,
            type: cleanUrl.startsWith("ftp") ? "ftp" : cleanUrl.startsWith("https") ? "https" : "http",
            domain,
          });
        }
      });
    }

    // Check Emails
    const emails = line.match(emailRegex);
    if (emails) {
      emails.forEach((e) => {
        if (!foundUrls.has(e)) {
          foundUrls.add(e);
          extractedLinks.push({
            url: `mailto:${e}`,
            type: "email",
            domain: e.split("@")[1] || "E-posta",
          });
        }
      });
    }

    // Check IPs
    const ips = line.match(ipRegex);
    if (ips) {
      ips.forEach((ip) => {
        if (!foundUrls.has(ip) && ip !== "0.0.0.0" && ip !== "255.255.255.255") {
          foundUrls.add(ip);
          extractedLinks.push({
            url: `http://${ip}`,
            type: "ip",
            domain: `IP: ${ip}`,
          });
        }
      });
    }
  });

  return {
    strings: extractedStrings,
    links: extractedLinks,
  };
}

// -------------------------------------------------------------
// 4. STRUCTURED HEX DUMP GENERATOR
// -------------------------------------------------------------
export function generateHexDumpRows(buffer: Uint8Array, maxLimitBytes = 2048): HexRow[] {
  const rows: HexRow[] = [];
  const limit = Math.min(buffer.length, maxLimitBytes);

  for (let offset = 0; offset < limit; offset += 16) {
    const chunk = buffer.slice(offset, offset + 16);
    const hexArr: string[] = [];
    let asciiStr = "";

    for (let j = 0; j < chunk.length; j++) {
      const code = chunk[j];
      hexArr.push(code.toString(16).padStart(2, "0").toUpperCase());
      asciiStr += code >= 32 && code <= 126 ? String.fromCharCode(code) : ".";
    }

    const offsetHex = offset.toString(16).padStart(8, "0").toUpperCase();
    rows.push({
      offset: offsetHex,
      hex: hexArr.join(" ").padEnd(47, " "),
      ascii: asciiStr,
    });
  }

  return rows;
}

// -------------------------------------------------------------
// 5. MASTER PARSE & BLOCK-BASED CANVAS GENERATOR
// -------------------------------------------------------------
export async function parseUniversalFile(file: File): Promise<UniversalParseResult> {
  const fileName = file.name;
  const fileSize = file.size;

  const arrayBuffer = await file.arrayBuffer();
  const bytes = new Uint8Array(arrayBuffer);

  // 1. Detect Magic Bytes
  const magicInfo = detectMagicBytes(bytes, fileName);

  // 2. Carve embedded images/documents
  const carvedAssets = carveEmbeddedData(bytes);

  // 3. Extract Strings & Links
  const { strings, links } = extractStringsAndLinks(bytes);

  // 4. Generate Hex Rows
  const hexRows = generateHexDumpRows(bytes, 2048);

  // Base64 Representation
  const b64Data = bytesToBase64(bytes);
  const dataUrl = `data:${magicInfo.mimeType};base64,${b64Data}`;

  // 5. Perform OCR if image
  let ocrText = "";
  if (magicInfo.category === "media") {
    try {
      const res = await fetch("/api/gemini/ocr", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: dataUrl,
          mimeType: magicInfo.mimeType,
        }),
      });
      const ocrData = await res.json();
      if (ocrData.text) ocrText = ocrData.text.trim();
    } catch {
      // OCR optional fallback
    }
  }

  // 6. Build Formatted Text Summary
  const dumpText = hexRows.map((r) => `${r.offset}  ${r.hex}  |${r.ascii}|`).join("\n");
  const stringsSummary = strings.length > 0 ? strings.slice(0, 40).join("\n") : "(Doğrudan metin bloğu bulunamadı)";

  const formattedText = `[EVRENSEL DOSYA İŞLEYİCİ: ${fileName}]
Format / MIME: ${magicInfo.formatName} (${magicInfo.mimeType})
Kategori: ${magicInfo.category.toUpperCase()} | Dosya Boyutu: ${(fileSize / 1024).toFixed(2)} KB (${fileSize} bayt)

${ocrText ? `=== 📷 GÖRSELDEN DÖNÜŞTÜRÜLEN METİN (OCR) ===\n${ocrText}\n\n` : ""}
${links.length > 0 ? `=== 🔗 TESPİT EDİLEN BAĞLANTILAR (${links.length} Adet) ===\n${links.map((l) => `• ${l.url} (${l.domain})`).join("\n")}\n\n` : ""}
${carvedAssets.length > 0 ? `=== 🖼️ GÖMÜLÜ OLAN AYRIŞTIRILMIŞ MEDYALAR (${carvedAssets.length} Adet) ===\n${carvedAssets.map((c) => `• ${c.name} (${(c.size / 1024).toFixed(1)} KB)`).join("\n")}\n\n` : ""}
=== 📝 İÇERİKTEN AYRIŞTIRILAN OKUNABİLİR METİNLER (STRINGS) ===
${stringsSummary}

=== 🔍 HEX DÖKÜMÜ (İLK 2 KB) ===
${dumpText}`;

  // 7. HTML Block Canvas for Rich Note Editor
  const htmlCanvasBlock = `
    <div class="noteflow-universal-block p-4 my-2 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
      <div class="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
        <div class="flex items-center gap-2">
          <span class="px-2.5 py-0.5 rounded-lg text-xs font-bold bg-teal-600 text-white">${magicInfo.formatName}</span>
          <span class="text-xs text-slate-500 font-mono">${fileName} (${(fileSize / 1024).toFixed(1)} KB)</span>
        </div>
        <span class="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded-full">✓ İçerik Ayrıştırıldı</span>
      </div>

      ${
        ocrText
          ? `<div class="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs text-emerald-900 dark:text-emerald-200">
              <strong>📷 Görsel OCR Metni:</strong><br/>
              <p class="mt-1 whitespace-pre-wrap font-sans leading-relaxed">${ocrText}</p>
            </div>`
          : ""
      }

      ${
        links.length > 0
          ? `<div class="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-xl text-xs">
              <strong class="text-blue-900 dark:text-blue-200">🔗 Dosya İçindeki Bağlantı Kartları:</strong>
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                ${links
                  .map(
                    (l) => `<a href="${l.url}" target="_blank" rel="noopener noreferrer" class="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between text-blue-600 dark:text-blue-400 hover:underline">
                    <span class="truncate font-semibold">${l.domain}</span>
                    <span class="text-[10px] text-slate-400 font-mono">Aç ↗</span>
                  </a>`
                  )
                  .join("")}
              </div>
            </div>`
          : ""
      }

      ${
        carvedAssets.length > 0
          ? `<div class="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-xs">
              <strong class="text-amber-900 dark:text-amber-200">🖼️ Ayrıştırılan Gömülü Medyalar:</strong>
              <div class="flex flex-wrap gap-2 mt-2">
                ${carvedAssets
                  .map(
                    (c) => `<div class="p-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center">
                    <img src="${c.dataUrl}" alt="${c.name}" class="h-20 w-auto object-cover rounded-lg mx-auto" />
                    <span class="block text-[10px] text-slate-500 mt-1">${c.name}</span>
                  </div>`
                  )
                  .join("")}
              </div>
            </div>`
          : ""
      }

      <div class="p-3 bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl font-mono text-xs overflow-x-auto max-h-48 text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
        <strong class="text-slate-900 dark:text-slate-100 block mb-1">📝 Okunabilir Metin Dizileri (Strings):</strong>
        ${stringsSummary}
      </div>

      <details class="text-xs">
        <summary class="font-bold text-slate-600 dark:text-slate-400 cursor-pointer hover:text-teal-600">
          🔍 Hex / Byte Tablosunu Göster
        </summary>
        <pre class="mt-2 p-3 bg-slate-950 text-emerald-400 rounded-xl font-mono text-[11px] overflow-x-auto max-h-48 leading-snug">${dumpText}</pre>
      </details>
    </div>
  `;

  return {
    fileName,
    fileSize,
    magicInfo,
    extractedStrings: strings,
    extractedLinks: links,
    carvedAssets,
    hexRows,
    ocrText,
    formattedText,
    htmlCanvasBlock,
    blocks: {
      textBlocks: strings,
      imageBlocks: carvedAssets,
      mediaBlocks:
        magicInfo.category === "media"
          ? [{ name: fileName, mime: magicInfo.mimeType, dataUrl, isAudio: false }]
          : magicInfo.category === "audio_video"
          ? [{ name: fileName, mime: magicInfo.mimeType, dataUrl, isAudio: true }]
          : [],
      linkBlocks: links,
      hexBlock: hexRows,
    },
  };
}
