// @ts-expect-error - lamejs lacks full ESM typings
import * as lamejsModule from 'lamejs';

// Handle both default and named export variations of lamejs
const lamejs = (lamejsModule as any).default || lamejsModule;

/**
 * Converts an AudioBuffer to a standard 16-bit PCM WAV Blob
 */
export function audioBufferToWavBlob(audioBuffer: AudioBuffer): Blob {
  const numChannels = audioBuffer.numberOfChannels;
  const sampleRate = audioBuffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;
  
  const numSamples = audioBuffer.length * numChannels;
  const blockAlign = (numChannels * bitDepth) / 8;
  const byteRate = sampleRate * blockAlign;
  const dataSize = numSamples * (bitDepth / 8);
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  // Helper write string
  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  /* RIFF identifier */
  writeString(0, 'RIFF');
  /* file length */
  view.setUint32(4, 36 + dataSize, true);
  /* RIFF type */
  writeString(8, 'WAVE');
  /* format chunk identifier */
  writeString(12, 'fmt ');
  /* format chunk length */
  view.setUint32(16, 16, true);
  /* sample format (raw) */
  view.setUint16(20, format, true);
  /* channel count */
  view.setUint16(22, numChannels, true);
  /* sample rate */
  view.setUint32(24, sampleRate, true);
  /* byte rate (sample rate * block align) */
  view.setUint32(28, byteRate, true);
  /* block align (channel count * bytes per sample) */
  view.setUint16(32, blockAlign, true);
  /* bits per sample */
  view.setUint16(34, bitDepth, true);
  /* data chunk identifier */
  writeString(36, 'data');
  /* data chunk length */
  view.setUint32(40, dataSize, true);

  // Interleave and write 16-bit PCM samples
  const channels: Float32Array[] = [];
  for (let c = 0; c < numChannels; c++) {
    channels.push(audioBuffer.getChannelData(c));
  }

  let offset = 44;
  for (let i = 0; i < audioBuffer.length; i++) {
    for (let c = 0; c < numChannels; c++) {
      const sample = Math.max(-1, Math.min(1, channels[c][i]));
      // Convert to 16-bit signed integer (-32768 to 32767)
      const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      view.setInt16(offset, intSample, true);
      offset += 2;
    }
  }

  return new Blob([view], { type: 'audio/wav' });
}

/**
 * Encodes an AudioBuffer into an MP3 Blob using LAME.js
 */
export async function audioBufferToMp3Blob(audioBuffer: AudioBuffer, kbps = 128): Promise<Blob> {
  try {
    const channels = audioBuffer.numberOfChannels;
    const sampleRate = audioBuffer.sampleRate;
    const Mp3EncoderClass = lamejs.Mp3Encoder || (window as any).lamejs?.Mp3Encoder;

    if (!Mp3EncoderClass) {
      // Fallback to WAV blob if lamejs is unavailable
      return audioBufferToWavBlob(audioBuffer);
    }

    const mp3encoder = new Mp3EncoderClass(channels, sampleRate, kbps);
    const mp3Data: Uint8Array[] = [];

    // Convert Float32 samples to Int16
    const leftFloat = audioBuffer.getChannelData(0);
    const rightFloat = channels > 1 ? audioBuffer.getChannelData(1) : leftFloat;

    const left = new Int16Array(leftFloat.length);
    const right = new Int16Array(rightFloat.length);

    for (let i = 0; i < leftFloat.length; i++) {
      const l = Math.max(-1, Math.min(1, leftFloat[i]));
      left[i] = l < 0 ? l * 0x8000 : l * 0x7fff;
      if (channels > 1) {
        const r = Math.max(-1, Math.min(1, rightFloat[i]));
        right[i] = r < 0 ? r * 0x8000 : r * 0x7fff;
      }
    }

    const sampleBlockSize = 1152;
    for (let i = 0; i < left.length; i += sampleBlockSize) {
      const leftChunk = left.subarray(i, i + sampleBlockSize);
      let mp3buf: Int8Array;
      if (channels === 1) {
        mp3buf = mp3encoder.encodeBuffer(leftChunk);
      } else {
        const rightChunk = right.subarray(i, i + sampleBlockSize);
        mp3buf = mp3encoder.encodeBuffer(leftChunk, rightChunk);
      }
      if (mp3buf.length > 0) {
        mp3Data.push(new Uint8Array(mp3buf));
      }
    }

    const mp3End = mp3encoder.flush();
    if (mp3End.length > 0) {
      mp3Data.push(new Uint8Array(mp3End));
    }

    return new Blob(mp3Data as unknown as BlobPart[], { type: 'audio/mp3' });
  } catch (err) {
    console.warn('MP3 encoding failed, returning WAV fallback:', err);
    return audioBufferToWavBlob(audioBuffer);
  }
}

/**
 * Converts a base64-encoded WAV string into an AudioBuffer using Web Audio API
 */
export async function base64WavToAudioBuffer(base64Wav: string, audioContext: AudioContext): Promise<AudioBuffer> {
  const binary = atob(base64Wav);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return await audioContext.decodeAudioData(bytes.buffer.slice(0));
}

/**
 * Converts a base64-encoded WAV directly into an MP3 Blob
 */
export async function base64WavToMp3Blob(base64Wav: string, kbps = 128): Promise<Blob> {
  const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
  try {
    const audioBuffer = await base64WavToAudioBuffer(base64Wav, ctx);
    return await audioBufferToMp3Blob(audioBuffer, kbps);
  } finally {
    if (ctx.state !== 'closed') {
      ctx.close().catch(() => {});
    }
  }
}

/**
 * Helper to download any Blob in the browser
 */
export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.style.display = 'none';
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 2000);
}
