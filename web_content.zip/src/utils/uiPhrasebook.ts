import type { UiLanguageCode as AppLang } from '../types';

type NonArLang = Exclude<AppLang, 'ar'>;

const LANG_MAP: Record<NonArLang, number> = {
  hi: 0,
  zh: 1,
  ru: 2,
  de: 3,
  fr: 4,
  es: 5,
  it: 6,
  pt: 7,
  sv: 8,
};

// Order: [hi, zh, ru, de, fr, es, it, pt, sv]
const PHRASE_TABLE: Record<string, [string, string, string, string, string, string, string, string, string]> = {
  // SentencesView headers, buttons, tabs, pagination
  'مكتبة الجمل الإنجليزية (': ['अंग्रेज़ी वाक्य लाइब्रेरी (', '英语句子库 (', 'Библиотека английских фраз (', 'Englische Satzbibliothek (', 'Bibliothèque de phrases anglaises (', 'Biblioteca de frases en inglés (', 'Libreria di frasi inglesi (', 'Biblioteca de frases em inglês (', 'Engelskt meningsbibliotek ('],
  'جملة)': ['वाक्य)', '句)', 'фраз)', 'Sätze)', 'phrases)', 'frases)', 'frasi)', 'frases)', 'meningar)'],
  'استمع للنطق الصحيح، اقرأ الترجمة العربية، وسجّل صوتك للتدريب الفوري على كل جملة.': [
    'सही उच्चारण सुनें, अनुवाद पढ़ें और हर वाक्य के तुरंत अभ्यास के लिए अपनी आवाज़ रिकॉर्ड करें।',
    '聆听标准发音，阅读翻译，并录制您的声音即时练习每个句子。',
    'Слушайте правильное произношение, читайте перевод и записывайте свой голос для мгновенной практики.',
    'Höre die richtige Aussprache, lies die Übersetzung und nimm deine Stimme für sofortiges Üben auf.',
    'Écoutez la prononciation correcte, lisez la traduction et enregistrez votre voix pour pratiquer.',
    'Escucha la pronunciación correcta, lee la traducción y graba tu voz para practicar al instante.',
    'Ascolta la pronuncia corretta, leggi la traduzione e registra la tua voce per esercitarti subito.',
    'Ouça a pronúncia correta, leia a tradução e grave sua voz para praticar instantaneamente.',
    'Lyssna på korrekt uttal, läs översättningen och spela in din röst för direkt övning.',
  ],
  'تدرّبت على': ['अभ्यास किया', '已练习', 'Изучено', 'Geübt', 'Pratiquées', 'Practicadas', 'Praticate', 'Praticadas', 'Övade'],
  'المفضلة': ['पसंदीदा', '收藏', 'Избранное', 'Favoriten', 'Favoris', 'Favoritos', 'Preferiti', 'Favoritos', 'Favoriter'],
  'الكل': ['सभी', '全部', 'Все', 'Alle', 'Tout', 'Todos', 'Tutti', 'Todos', 'Alla'],
  'الكل (': ['सभी (', '全部 (', 'Все (', 'Alle (', 'Tout (', 'Todos (', 'Tutti (', 'Todos (', 'Alla ('],
  'تدرّبت عليها': ['अभ्यास किए गए', '已练习', 'Пройденные', 'Geübt', 'Pratiquées', 'Practicadas', 'Praticate', 'Praticadas', 'Övade'],
  'تصنيفات الجمل (': ['वाक्य श्रेणियाँ (', '句子分类 (', 'Категории фраз (', 'Satzkategorien (', 'Catégories de phrases (', 'Categorías de frases (', 'Categorie di frasi (', 'Categorias de frases (', 'Meningskategorier ('],
  'تصنيفاً):': ['श्रेणियाँ):', '个分类):', 'категорий):', 'Kategorien):', 'catégories):', 'categorías):', 'categorie):', 'categorias):', 'kategorier):'],
  'تصنيفاً إضافياً': ['अतिरिक्त श्रेणियाँ', '更多分类', 'ещё категорий', 'weitere Kategorien', 'catégories en plus', 'categorías más', 'altre categorie', 'mais categorias', 'fler kategorier'],
  'إخفاء التصنيفات الإضافية': ['अतिरिक्त श्रेणियाँ छिपाएँ', '隐藏更多分类', 'Скрыть доп. категории', 'Weitere Kategorien ausblenden', 'Masquer les catégories', 'Ocultar categorías', 'Nascondi categorie', 'Ocultar categorias', 'Dölj kategorier'],
  'السابق': ['पिछला', '上一页', 'Назад', 'Zurück', 'Précédent', 'Anterior', 'Precedente', 'Anterior', 'Föregående'],
  'التالي': ['अगला', '下一页', 'Далее', 'Weiter', 'Suivant', 'Siguiente', 'Successivo', 'Próximo', 'Nästa'],
  'الصفحة السابقة': ['पिछला पृष्ठ', '上一页', 'Предыдущая', 'Vorherige Seite', 'Page précédente', 'Página anterior', 'Pagina precedente', 'Página anterior', 'Föregående sida'],
  'الصفحة التالية': ['अगला पृष्ठ', '下一页', 'Следующая', 'Nächste Seite', 'Page suivante', 'Página siguiente', 'Pagina successiva', 'Próxima página', 'Nästa sida'],
  'استمع للنطق': ['उच्चारण सुनें', '听发音', 'Слушать', 'Anhören', 'Écouter', 'Escuchar', 'Ascolta', 'Ouvir', 'Lyssna'],
  'نطق بطيء': ['धीमा उच्चारण', '慢速朗读', 'Медленно', 'Langsam', 'Lentement', 'Lento', 'Lento', 'Devagar', 'Långsamt'],
  'سجّل صوتك للتدريب': ['अभ्यास के लिए आवाज़ रिकॉर्ड करें', '录音练习', 'Записать голос', 'Stimme aufnehmen', 'Enregistrer sa voix', 'Grabar tu voz', 'Registra la voce', 'Gravar sua voz', 'Spela in röst'],
  'إيقاف وتقييم النطق': ['रोकें और मूल्यांकन करें', '停止并评分', 'Стоп и оценка', 'Stoppen & bewerten', 'Arrêter et évaluer', 'Detener y evaluar', 'Ferma e valuta', 'Parar e avaliar', 'Stoppa och bedöm'],
  'فيديوهات للجملة': ['वाक्य वीडियो', '句子视频', 'Видео к фразе', 'Satz-Videos', 'Vidéos de phrase', 'Videos de frase', 'Video della frase', 'Vídeos da frase', 'Meningsvideor'],
  'إخفاء الفيديوهات': ['वीडियो छिपाएँ', '隐藏视频', 'Скрыть видео', 'Videos ausblenden', 'Masquer les vidéos', 'Ocultar videos', 'Nascondi video', 'Ocultar vídeos', 'Dölj videor'],
  'الصفحة الرئيسية': ['होम पेज', '主页', 'Главная', 'Startseite', 'Accueil', 'Inicio', 'Home', 'Início', 'Startsida'],
  'تصنيفات الجمل': ['वाक्य श्रेणियाँ', '句子分类', 'Категории фраз', 'Satzkategorien', 'Catégories de phrases', 'Categorías de frases', 'Categorie di frasi', 'Categorias de frases', 'Meningskategorier'],
  'استمع للنطق الصحيح، اقرأ الترجمة العربية، وتدرّب بالنطق الحي عبر تدريب الظل ومقاطع الفيديو الواقعية.': [
    'सही उच्चारण सुनें, अनुवाद पढ़ें और शैडोइंग व असली वीडियो क्लिप्स के साथ अभ्यास करें।',
    '聆听标准发音，阅读翻译，并通过跟读训练和真实视频片段练习口语。',
    'Слушайте правильное произношение, читайте перевод и тренируйтесь с помощью шэдоуинга и реальных видеоклипов.',
    'Höre die richtige Aussprache, lies die Übersetzung und übe live mit Shadowing und echten Videoclips.',
    'Écoutez la prononciation, lisez la traduction et entraînez-vous avec le shadowing et de vrais clips vidéo.',
    'Escucha la pronunciación correcta, lee la traducción y practica en vivo con shadowing y videos reales.',
    'Ascolta la pronuncia corretta, leggi la traduzione ed esercitati con lo shadowing e video reali.',
    'Ouça a pronúncia correta, leia a tradução e pratique ao vivo com shadowing e vídeos reais.',
    'Lyssna på korrekt uttal, läs översättningen och öva med shadowing och riktiga videoklipp.',
  ],
  'مقاطع فيديو حقيقية للجملة كاملة:': ['पूरे वाक्य के असली वीडियो क्लिप:', '完整句子的真实视频片段：', 'Реальные видеоклипы для всей фразы:', 'Echte Videoclips für den ganzen Satz:', 'Vrais clips vidéo pour toute la phrase :', 'Videos reales de la frase completa:', 'Video reali per l’intera frase:', 'Vídeos reais para a frase completa:', 'Riktiga videoklipp för hela meningen:'],
  'اختر كلمة من الجملة لمقاطع الفيديو:': ['वीडियो क्लिप के लिए वाक्य से शब्द चुनें:', '选择句子中的单词查看视频片段：', 'Выберите слово для видеоклипов:', 'Wähle ein Wort für Videoclips:', 'Choisissez un mot pour les clips vidéo :', 'Elige una palabra para ver clips:', 'Scegli una parola per i video:', 'Escolha uma palavra para os vídeos:', 'Välj ett ord för videoklipp:'],
  '• جاري تجهيز الترجمة العربية...': ['• अनुवाद तैयार हो रहा है...', '• 正在加载翻译...', '• Загрузка перевода...', '• Übersetzung wird geladen...', '• Chargement de la traduction...', '• Cargando traducción...', '• Caricamento traduzione...', '• Carregando tradução...', '• Laddar översättning...'],
  'جاري تحميل جميع الجمل...': ['सभी वाक्य लोड हो रहे हैं...', '正在加载所有句子...', 'Загрузка всех фраз...', 'Alle Sätze werden geladen...', 'Chargement des phrases...', 'Cargando todas las frases...', 'Caricamento frasi...', 'Carregando frases...', 'Laddar alla meningar...'],
  'اضغط لعرض الترجمة العربية': ['अनुवाद देखने के लिए टैप करें', '点击查看翻译', 'Нажмите для перевода', 'Tippen für Übersetzung', 'Appuyez pour traduire', 'Pulsa para ver traducción', 'Tocca per la traduzione', 'Toque para ver tradução', 'Tryck för översättning'],
  'إعادة الترجمة': ['पुनः अनुवाद करें', '重新翻译', 'Перевести снова', 'Erneut übersetzen', 'Retraduire', 'Retraducir', 'Ritraduci', 'Retraduzir', 'Översätt igen'],
  'تم التدريب': ['अभ्यास पूर्ण', '已练习', 'Пройдено', 'Geübt', 'Pratiqué', 'Practicado', 'Praticato', 'Praticado', 'Övad'],
  'اسمع تسجيلك': ['अपनी रिकॉर्डिंग सुनें', '听你的录音', 'Послушать запись', 'Aufnahme anhören', 'Écouter votre voix', 'Escuchar grabación', 'Ascolta registrazione', 'Ouvir gravação', 'Lyssna på inspelning'],
  'تقييم دقيق بـ AI': ['AI सटीक मूल्यांकन', 'AI 精准评分', 'Точная ИИ-оценка', 'KI-Bewertung', 'Évaluation IA', 'Evaluación IA', 'Valutazione IA', 'Avaliação IA', 'AI-bedömning'],
  'مسح البحث': ['खोज साफ़ करें', '清除搜索', 'Очистить поиск', 'Suche löschen', 'Effacer la recherche', 'Borrar búsqueda', 'Cancella ricerca', 'Limpar pesquisa', 'Rensa sökning'],
  'لا توجد جمل مطابقة للبحث أو الفلتر الحالي.': ['वर्तमान खोज या फ़िल्टर से कोई वाक्य नहीं मिला।', '没有匹配的句子。', 'Подходящих фраз не найдено.', 'Keine passenden Sätze gefunden.', 'Aucune phrase correspondante.', 'No se encontraron frases.', 'Nessuna frase trovata.', 'Nenhuma frase encontrada.', 'Inga matchande meningar.'],
  'عرض جميع الجمل': ['सभी वाक्य दिखाएँ', '显示全部句子', 'Показать все фразы', 'Alle Sätze anzeigen', 'Afficher toutes les phrases', 'Ver todas las frases', 'Mostra tutte le frasi', 'Ver todas as frases', 'Visa alla meningar'],
  'ابحث بالإنجليزية أو برقم الجملة (مثلاً: airport أو 4484)...': ['अंग्रेज़ी या वाक्य संख्या से खोजें (जैसे: airport या 4484)...', '按英文或句子编号搜索（如 airport 或 4484）...', 'Поиск на английском или по номеру (напр. airport)...', 'Auf Englisch oder nach Nummer suchen (z. B. airport)...', 'Rechercher en anglais ou par numéro (ex: airport)...', 'Buscar en inglés o por número (ej. airport)...', 'Cerca in inglese o per numero (es. airport)...', 'Pesquisar em inglês ou número (ex: airport)...', 'Sök på engelska eller nummer (t.ex. airport)...'],

  // 36 Sentence Section Categories
  'الضمائر والأفعال المساعدة': ['सर्वनाम और सहायक क्रियाएँ', '代词与助动词', 'Местоимения и вспомогательные глаголы', 'Pronomen & Hilfsverben', 'Pronoms et auxiliaires', 'Pronombres y auxiliares', 'Pronomi e ausiliari', 'Pronomes e auxiliares', 'Pronomen & hjälpverb'],
  'الأفعال الناقصة (Can/Should)': ['मॉडल क्रियाएँ (Can/Should)', '情态动词 (Can/Should)', 'Модальные глаголы (Can/Should)', 'Modalverben (Can/Should)', 'Verbes modaux (Can/Should)', 'Verbos modales (Can/Should)', 'Verbi modali (Can/Should)', 'Verbos modais (Can/Should)', 'Modala verb (Can/Should)'],
  'أسئلة What و Which': ['What और Which प्रश्न', 'What 与 Which 疑问句', 'Вопросы с What и Which', 'What- & Which-Fragen', 'Questions What et Which', 'Preguntas con What y Which', 'Domande con What e Which', 'Perguntas com What e Which', 'Frågor med What & Which'],
  'أسئلة المكان Where': ['स्थान प्रश्न (Where)', '地点疑问句 (Where)', 'Вопросы о месте (Where)', 'Ortsfragen (Where)', 'Questions de lieu (Where)', 'Preguntas de lugar (Where)', 'Domande di luogo (Where)', 'Perguntas de lugar (Where)', 'Platsfrågor (Where)'],
  'أسئلة الأشخاص Who': ['व्यक्ति प्रश्न (Who)', '人物疑问句 (Who)', 'Вопросы о людях (Who)', 'Personenfragen (Who)', 'Questions sur les personnes (Who)', 'Preguntas de personas (Who)', 'Domande sulle persone (Who)', 'Perguntas sobre pessoas (Who)', 'Personfrågor (Who)'],
  'أسئلة الوقت When': ['समय प्रश्न (When)', '时间疑问句 (When)', 'Вопросы о времени (When)', 'Zeitfragen (When)', 'Questions de temps (When)', 'Preguntas de tiempo (When)', 'Domande di tempo (When)', 'Perguntas de tempo (When)', 'Tidsfrågor (When)'],
  'أسئلة السبب Why': ['कारण प्रश्न (Why)', '原因疑问句 (Why)', 'Вопросы причины (Why)', 'Warum-Fragen (Why)', 'Questions de cause (Why)', 'Preguntas de causa (Why)', 'Domande sul perché (Why)', 'Perguntas de motivo (Why)', 'Orsaksfrågor (Why)'],
  'أسئلة الكيفية How': ['कैसे प्रश्न (How)', '方式疑问句 (How)', 'Вопросы способа (How)', 'Wie-Fragen (How)', 'Questions de manière (How)', 'Preguntas de modo (How)', 'Domande sul come (How)', 'Perguntas de modo (How)', 'Hur-frågor (How)'],
  'الأزمنة التامة والمستقبل': ['पूर्ण और भविष्य काल', '完成时与将来时', 'Перфект и будущее время', 'Perfekt & Zukunft', 'Temps parfaits et futur', 'Tiempos perfectos y futuro', 'Tempi perfetti e futuro', 'Tempos perfeitos e futuro', 'Perfekt & framtid'],
  'تراكيب There is و It is': ['There is और It is संरचनाएँ', 'There is 与 It is 句型', 'Конструкции There is и It is', 'There is & It is Strukturen', 'Structures There is et It is', 'Estructuras There is e It is', 'Strutture There is e It is', 'Estruturas There is e It is', 'There is & It is-strukturer'],
  'تعبيرات ومصطلحات يومية': ['दैनिक अभिव्यक्तियाँ और मुहावरे', '日常表达与习语', 'Повседневные выражения и идиомы', 'Alltagsausdrücke & Redewendungen', 'Expressions quotidiennes', 'Expresiones cotidianas', 'Espressioni quotidiane', 'Expressões cotidianas', 'Vardagsuttryck & idiom'],
  'المبني للمجهول (Passive)': ['कर्मवाच्य (Passive)', '被动语态 (Passive)', 'Пассивный залог (Passive)', 'Passiv (Passive)', 'Voix passive (Passive)', 'Voz pasiva (Passive)', 'Forma passiva (Passive)', 'Voz passiva (Passive)', 'Passiv form (Passive)'],
  'الجمل الشرطية (If)': ['शर्त वाक्य (If)', '条件句 (If)', 'Условные предложения (If)', 'Bedingungssätze (If)', 'Phrases conditionnelles (If)', 'Oraciones condicionales (If)', 'Frasi condizionali (If)', 'Frases condicionais (If)', 'Villkorssatser (If)'],
  'الوقت والتاريخ والمواعيد': ['समय, तिथि और अपॉइंटमेंट', '时间、日期与预约', 'Время, даты и встречи', 'Zeit, Datum & Termine', 'Temps, dates et rendez-vous', 'Tiempo, fechas y citas', 'Ora, date e appuntamenti', 'Hora, datas e compromissos', 'Tid, datum & möten'],
  'المقارنات والصفات': ['तुलना और विशेषण', '比较级与形容词', 'Сравнения и прилагательные', 'Vergleiche & Adjektive', 'Comparaisons et adjectifs', 'Comparaciones y adjetivos', 'Comparativi e aggettivi', 'Comparações e adjetivos', 'Jämförelser & adjektiv'],
  'الحياة اليومية والمنزل': ['दैनिक जीवन और घर', '日常生活与家庭', 'Быт и дом', 'Alltag & Zuhause', 'Vie quotidienne et maison', 'Vida diaria y hogar', 'Vita quotidiana e casa', 'Vida diária e casa', 'Vardagsliv & hem'],
  'المطعم والطعام': ['रेस्तरां और भोजन', '餐厅与美食', 'Ресторан и еда', 'Restaurant & Essen', 'Restaurant et cuisine', 'Restaurante y comida', 'Ristorante e cibo', 'Restaurante e comida', 'Restaurang & mat'],
  'السفر والمواصلات': ['यात्रा और परिवहन', '旅行与交通', 'Путешествия и транспорт', 'Reisen & Verkehr', 'Voyages et transports', 'Viajes y transporte', 'Viaggi e trasporti', 'Viagens e transporte', 'Resor & transport'],
  'العمل والمهنة': ['काम और करियर', '工作与职业', 'Работа и карьера', 'Arbeit & Beruf', 'Travail et carrière', 'Trabajo y carrera', 'Lavoro e carriera', 'Trabalho e carreira', 'Arbete & karriär'],
  'الصحة والطبيب': ['स्वास्थ्य और डॉक्टर', '健康与就医', 'Здоровье и врач', 'Gesundheit & Arzt', 'Santé et médecin', 'Salud y médico', 'Salute e medico', 'Saúde e médico', 'Hälsa & läkare'],
  'التسوق والمال': ['खरीदारी और पैसा', '购物与理财', 'Покупки и деньги', 'Einkaufen & Geld', 'Shopping et argent', 'Compras y dinero', 'Shopping e denaro', 'Compras e dinheiro', 'Shopping & pengar'],
  'التعليم والدراسة': ['शिक्षा और अध्ययन', '教育与学习', 'Образование и учёба', 'Bildung & Studium', 'Éducation et études', 'Educación y estudio', 'Istruzione e studio', 'Educação e estudo', 'Utbildning & studier'],
  'الطقس والطبيعة': ['मौसम और प्रकृति', '天气与自然', 'Погода и природа', 'Wetter & Natur', 'Météo et nature', 'Clima y naturaleza', 'Meteo e natura', 'Clima e natureza', 'Väder & natur'],
  'المشاعر والآراء': ['भावनाएँ और विचार', '情感与观点', 'Чувства и мнения', 'Gefühle & Meinungen', 'Sentiments et opinions', 'Sentimientos y opiniones', 'Sentimenti e opinioni', 'Sentimentos e opiniões', 'Känslor & åsikter'],
  'الاجتماعات والأعمال': ['बैठकें और व्यवसाय', '会议与商务', 'Встречи и бизнес', 'Meetings & Business', 'Réunions et affaires', 'Reuniones y negocios', 'Riunioni e affari', 'Reuniões e negócios', 'Möten & affärer'],
  'التكنولوجيا والإنترنت': ['प्रौद्योगिकी और इंटरनेट', '科技与互联网', 'Технологии и интернет', 'Technik & Internet', 'Technologie et Internet', 'Tecnología e Internet', 'Tecnologia e Internet', 'Tecnologia e Internet', 'Teknik & internet'],
  'الهاتف والتواصل': ['फ़ोन और संचार', '电话与沟通', 'Телефон и общение', 'Telefon & Kommunikation', 'Téléphone et communication', 'Teléfono y comunicación', 'Telefono e comunicazione', 'Telefone e comunicação', 'Telefon & kommunikation'],
  'الطوارئ والمساعدة': ['आपातकाल और सहायता', '紧急求助', 'Экстренная помощь', 'Notfälle & Hilfe', 'Urgences et aide', 'Emergencias y ayuda', 'Emergenze e aiuto', 'Emergências e ajuda', 'Nödsituationer & hjälp'],
  'التعارف والتحيات': ['परिचय और अभिवादन', '问候与介绍', 'Знакомство и приветствия', 'Begrüßungen & Vorstellung', 'Salutations et présentations', 'Saludos y presentaciones', 'Saluti e presentazioni', 'Cumprimentos e apresentações', 'Hälsningar & presentation'],
  'العائلة والأصدقاء': ['परिवार और दोस्त', '家人与朋友', 'Семья и друзья', 'Familie & Freunde', 'Famille et amis', 'Familia y amigos', 'Famiglia e amici', 'Família e amigos', 'Familj & vänner'],
  'الرياضة والهوايات': ['खेल और शौक', '运动与爱好', 'Спорт и хобби', 'Sport & Hobbys', 'Sports et loisirs', 'Deportes y pasatiempos', 'Sport e hobby', 'Esportes e hobbies', 'Sport & fritid'],
  'الفندق والإقامة': ['होटल और ठहरना', '酒店与住宿', 'Отель и проживание', 'Hotel & Unterkunft', 'Hôtel et hébergement', 'Hotel y alojamiento', 'Hotel e alloggio', 'Hotel e hospedagem', 'Hotell & boende'],
  'المطار والرحلات': ['हवाई अड्डा और उड़ानें', '机场与航班', 'Аэропорт и рейсы', 'Flughafen & Flüge', 'Aéroport et vols', 'Aeropuerto y vuelos', 'Aeroporto e voli', 'Aeroporto e voos', 'Flygplats & flyg'],
  'الاتجاهات والأماكن': ['दिशाएँ और स्थान', '问路与地点', 'Направления и места', 'Wegbeschreibungen & Orte', 'Directions et lieux', 'Direcciones y lugares', 'Indicazioni e luoghi', 'Direções e lugares', 'Vägbeskrivningar & platser'],
  'المحادثات المتقدمة': ['उन्नत बातचीत', '高级对话', 'Продвинутые диалоги', 'Fortgeschrittene Gespräche', 'Conversations avancées', 'Conversaciones avanzadas', 'Conversazioni avanzate', 'Conversas avançadas', 'Avancerade samtal'],
  'الحكم والأمثال': ['कहावतें और ज्ञान', '谚语与名言', 'Пословицы и мудрость', 'Sprichwörter & Weisheiten', 'Proverbes et sagesse', 'Proverbios y sabiduría', 'Proverbi e saggezza', 'Provérbios e sabedoria', 'Ordspråk & visdom'],

  // LevelsView, WordRow, WordDetailView, GameArena, StudyArena
  'الكلمات حسب المستوى (CEFR A0–C2)': ['स्तर के अनुसार शब्द (CEFR A0–C2)', '按级别分类的词汇 (CEFR A0–C2)', 'Слова по уровням (CEFR A0–C2)', 'Wörter nach Niveau (CEFR A0–C2)', 'Mots par niveau (CEFR A0–C2)', 'Palabras por nivel (CEFR A0–C2)', 'Parole per livello (CEFR A0–C2)', 'Palavras por nível (CEFR A0–C2)', 'Ord efter nivå (CEFR A0–C2)'],
  'اختر مستوى لتصفح الكلمات مع الصورة والمعنى والنطق والجمل وتدريب نطقك': ['अर्थ, उच्चारण, उदाहरण और अभ्यास के साथ शब्दों को देखने के लिए स्तर चुनें', '选择一个级别浏览词汇、释义、发音和例句练习', 'Выберите уровень для изучения слов, произношения и примеров', 'Wähle ein Niveau zum Lernen von Wörtern, Aussprache und Beispielen', 'Choisissez un niveau pour explorer les mots, la prononciation et les exemples', 'Elige un nivel para explorar palabras, pronunciación y ejemplos', 'Scegli un livello per esplorare parole, pronuncia ed esempi', 'Escolha um nível para explorar palavras, pronúncia e exemplos', 'Välj en nivå för att utforska ord, uttal och exempel'],
  'متقنة': ['महारत हासिल', '已掌握', 'Изучено', 'Gemeistert', 'Maîtrisé', 'Dominado', 'Padroneggiato', 'Dominado', 'Behärskad'],
  'في بنك الأخطاء': ['गलती बैंक में', '错题本中', 'В ошибках', 'In Fehlerbank', 'Dans les erreurs', 'En errores', 'Negli errori', 'Nos erros', 'I felbanken'],
  'غير مكتمل': ['अपूर्ण', '未完成', 'В процессе', 'Offen', 'En cours', 'Pendiente', 'In corso', 'Pendente', 'Pågående'],
  'مكتمل': ['पूर्ण', '已完成', 'Завершено', 'Fertig', 'Terminé', 'Completado', 'Completato', 'Concluído', 'Klar'],
  'انتقال': ['जाएँ', '跳转', 'Перейти', 'Los', 'Aller', 'Ir', 'Vai', 'Ir', 'Gå'],
  'جديد': ['नया', '新', 'Новый', 'Neu', 'Nouveau', 'Nuevo', 'Nuovo', 'Novo', 'Ny'],
  'تدرّب بالألعاب': ['खेलों से अभ्यास करें', '游戏练习', 'Практика в играх', 'Mit Spielen üben', 'Pratiquer en jouant', 'Practicar jugando', 'Pratica con i giochi', 'Praticar jogando', 'Öva med spel'],
  'نظرة عامة': ['अवलोकन', '概览', 'Обзор', 'Übersicht', 'Aperçu', 'Resumen', 'Panoramica', 'Visão geral', 'Översikt'],
  'العلاقات': ['संबंध', '词义关系', 'Связи', 'Beziehungen', 'Relations', 'Relaciones', 'Relazioni', 'Relações', 'Relationer'],
  'الاستخدام': ['उपयोग', '用法', 'Использование', 'Verwendung', 'Utilisation', 'Uso', 'Uso', 'Uso', 'Användning'],
  'الفيديوهات': ['वीडियो', '视频', 'Видео', 'Videos', 'Vidéos', 'Videos', 'Video', 'Vídeos', 'Videor'],
  'تدريب وألعاب': ['अभ्यास और खेल', '练习与游戏', 'Практика и игры', 'Übungen & Spiele', 'Pratique et jeux', 'Práctica y juegos', 'Pratica e giochi', 'Prática e jogos', 'Övning & spel'],
  'إخفاء الترجمة': ['अनुवाद छिपाएँ', '隐藏翻译', 'Скрыть перевод', 'Übersetzung ausblenden', 'Masquer la traduction', 'Ocultar traducción', 'Nascondi traduzione', 'Ocultar tradução', 'Dölj översättning'],
  'إظهار الترجمة': ['अनुवाद दिखाएँ', '显示翻译', 'Показать перевод', 'Übersetzung anzeigen', 'Afficher la traduction', 'Mostrar traducción', 'Mostra traduzione', 'Mostrar tradução', 'Visa översättning'],
  'الترجمة مخفية لاختبار نفسك': ['स्वयं की जाँच के लिए अनुवाद छिपा है', '已隐藏翻译供自测', 'Перевод скрыт для самопроверки', 'Übersetzung zum Selbsttest ausgeblendet', 'Traduction masquée pour vous tester', 'Traducción oculta para autoevaluación', 'Traduzione nascosta per metterti alla prova', 'Tradução oculta para autoteste', 'Översättning dold för självtest'],
  'وصّل كل كلمة إنجليزية بمعناها العربي': ['प्रत्येक अंग्रेज़ी शब्द को उसके अर्थ से मिलाएँ', '将每个英文单词与其释义配对', 'Соедините каждое английское слово с его значением', 'Ordne jedes englische Wort seiner Bedeutung zu', 'Associez chaque mot anglais à sa signification', 'Une cada palabra en inglés con su significado', 'Abbina ogni parola inglese al suo significato', 'Associe cada palavra em inglês ao seu significado', 'Para ihop varje engelskt ord med dess betydelse'],
  'اختر الترجمة العربية الصحيحة': ['सही अनुवाद चुनें', '选择正确的翻译', 'Выберите правильный перевод', 'Wähle die richtige Übersetzung', 'Choisissez la bonne traduction', 'Elige la traducción correcta', 'Scegli la traduzione corretta', 'Escolha a tradução correta', 'Välj rätt översättning'],
  'اختر الكلمة الإنجليزية الصحيحة': ['सही अंग्रेज़ी शब्द चुनें', '选择正确的英文单词', 'Выберите правильное английское слово', 'Wähle das richtige englische Wort', 'Choisissez le bon mot anglais', 'Elige la palabra en inglés correcta', 'Scegli la parola inglese corretta', 'Escolha a palavra em inglês correta', 'Välj rätt engelskt ord'],
  'تخطي للكلمة التالية': ['अगले शब्द पर जाएँ', '跳过到下一个词', 'Пропустить к следующему слову', 'Zum nächsten Wort springen', 'Passer au mot suivant', 'Saltar a la siguiente palabra', 'Salta alla parola successiva', 'Pular para a próxima palavra', 'Hoppa till nästa ord'],
  'نطق': ['उच्चारण', '发音', 'Озвучить', 'Aussprechen', 'Prononcer', 'Pronunciar', 'Pronuncia', 'Pronunciar', 'Uttala'],
  'مفضلة': ['पसंदीदा', '收藏', 'В избранное', 'Favorit', 'Favori', 'Favorito', 'Preferito', 'Favorito', 'Favorit'],
  'تذكّر المعنى ثم اضغط لإظهار الإجابة': ['अर्थ याद करें, फिर उत्तर देखने के लिए टैप करें', '先回忆意思，再点击显示答案', 'Вспомните значение и нажмите, чтобы увидеть ответ', 'Erinnere dich an die Bedeutung und tippe für die Antwort', 'Rappelez-vous le sens puis appuyez pour voir la réponse', 'Recuerda el significado y pulsa para ver la respuesta', 'Ricorda il significato e tocca per vedere la risposta', 'Lembre o significado e toque para ver a resposta', 'Kom ihåg betydelsen och tryck för att visa svaret'],
  'المعنى بالعربية — قيّم مدى تذكرك أدناه': ['अर्थ — नीचे अपनी याददाश्त का मूल्यांकन करें', '释义 — 请在下方评价记忆程度', 'Значение — оцените, как хорошо вы помните слово', 'Bedeutung — bewerte unten deine Erinnerung', 'Signification — évaluez votre mémorisation ci-dessous', 'Significado — evalúa tu recuerdo abajo', 'Significato — valuta il tuo ricordo qui sotto', 'Significado — avalie sua memória abaixo', 'Betydelse — betygsätt ditt minne nedan'],
  'نظام أنكي للتكرار المتباعد (SM-2)': ['Anki स्पेस्ड रिपीटिशन (SM-2)', 'Anki 间隔重复系统 (SM-2)', 'Система интервального повторения Anki (SM-2)', 'Anki Spaced Repetition (SM-2)', 'Répétition espacée Anki (SM-2)', 'Repetición espaciada Anki (SM-2)', 'Ripetizione spaziata Anki (SM-2)', 'Repetição espaçada Anki (SM-2)', 'Anki Spaced Repetition (SM-2)'],
  'بطاقة جديدة': ['नया कार्ड', '新卡片', 'Новая карточка', 'Neue Karte', 'Nouvelle carte', 'Tarjeta nueva', 'Nuova scheda', 'Novo cartão', 'Nytt kort'],
  'مستحقة للمراجعة': ['समीक्षा के लिए देय', '待复习', 'Пора повторить', 'Fällig zur Wiederholung', 'À réviser', 'Pendiente de repaso', 'Da ripassare', 'Pendente de revisão', 'Dags att repetera'],
  'العودة': ['वापस', '返回', 'Назад', 'Zurück', 'Retour', 'Volver', 'Indietro', 'Voltar', 'Tillbaka'],
  // Arcade, Sentence Pro & Pattern Swap game titles
  'ألعاب التحدي والمتعة': ['आर्केड और चुनौती खेल', '趣味挑战游戏', 'Аркадные игры и челленджи', 'Arcade & Herausforderungen', 'Jeux Arcade & Défis', 'Juegos Arcade y Desafíos', 'Giochi Arcade e Sfide', 'Jogos Arcade e Desafios', 'Arkad & Utmaningar'],
  '15 لعبة وتحدي للمفردات': ['15 शब्दावली खेल और चुनौतियाँ', '15款词汇游戏与挑战', '15 игр и челленджей для слов', '15 Wortschatzspiele & Challenges', '15 jeux et défis de vocabulaire', '15 juegos y retos de vocabulario', '15 giochi e sfide di vocabolario', '15 jogos e desafios de vocabulário', '15 ordspel och utmaningar'],
  '5 ألعاب · تعمل أوفلاين 100%': ['5 खेल · 100% ऑफ़लाइन', '5款游戏 · 100%离线可用', '5 игр · 100% офлайн', '5 Spiele · 100% offline', '5 jeux · 100% hors ligne', '5 juegos · 100% sin conexión', '5 giochi · 100% offline', '5 jogos · 100% offline', '5 spel · 100% offline'],
  'تحدي الكلمة': ['शब्द चुनौती', '单词挑战', 'Слово дня', 'Wort-Challenge', 'Défi du mot', 'Reto de palabra', 'Sfida parola', 'Desafio da palavra', 'Ordutmaning'],
  'تحدي الكلمة — Wordle': ['शब्द चुनौती', '单词挑战', 'Слово дня', 'Wort-Challenge', 'Défi du mot', 'Reto de palabra', 'Sfida parola', 'Desafio da palavra', 'Ordutmaning'],
  'سباق 60 ثانية': ['60-सेकंड गति दौड़', '60秒极速挑战', 'Блиц за 60 секунд', '60-Sekunden-Sprint', 'Course 60 secondes', 'Carrera de 60 segundos', 'Corsa 60 secondi', 'Corrida de 60 segundos', '60-sekunders lopp'],
  'بطاقات الذاكرة': ['स्मृति कार्ड', '记忆翻牌', 'Карточки памяти', 'Gedächtniskarten', 'Cartes de mémoire', 'Tarjetas de memoria', 'Carte della memoria', 'Cartões de memória', 'Minneskort'],
  'مطر الكلمات': ['शब्द वर्षा', '单词雨', 'Дождь слов', 'Wortregen', 'Pluie de mots', 'Lluvia de palabras', 'Pioggia di parole', 'Chuva de palavras', 'Ordregn'],
  'أنقذ الصاروخ': ['रॉकेट बचाएँ', '拯救火箭', 'Спаси ракету', 'Rette die Rakete', 'Sauve la fusée', 'Salva el cohete', 'Salva il razzo', 'Salve o foguete', 'Rädda raketen'],
  '9 ألعاب تفاعلية للطلاقة': ['धाराप्रवाह के 9 इंटरैक्टिव खेल', '9款互动流利度游戏', '9 игр для беглой речи', '9 interaktive Sprachspiele', '9 jeux interactifs de fluidité', '9 juegos interactivos de fluidez', '9 giochi interattivi di fluidità', '9 jogos interativos de fluência', '9 interaktiva flytspel'],
  'تحدي تبديل الأنماط (Sentence Pattern Swap)': ['वाक्य पैटर्न अदला-बदली', '句型替换挑战', 'Замена шаблона фразы', 'Satzmuster-Tausch', 'Échange de structure', 'Cambio de patrón', 'Scambio modello frase', 'Troca de padrões', 'Meningsmönsterbyte'],
  'تحدي تبديل الأنماط': ['वाक्य पैटर्न अदला-बदली', '句型替换挑战', 'Замена шаблона фразы', 'Satzmuster-Tausch', 'Échange de structure', 'Cambio de patrón', 'Scambio modello frase', 'Troca de padrões', 'Meningsmönsterbyte'],
  'تدريب الطلاقة الأهم': ['प्रमुख धाराप्रवाह अभ्यास', '核心流利度训练', 'Главный тренажёр беглости', 'Top-Flüssigkeitstraining', 'Entraînement clé de fluidité', 'Entrenamiento clave de fluidez', 'Allenamento chiave', 'Treino principal de fluência', 'Viktigaste flytträningen'],
  'ابدأ التحدي': ['चुनौती शुरू करें', '开始挑战', 'Начать челлендж', 'Herausforderung starten', 'Lancer le défi', 'Iniciar reto', 'Inizia sfida', 'Iniciar desafio', 'Starta utmaning'],
  'الجملة المتلاشية': ['लुप्त होता वाक्य', '渐隐句子记忆', 'Исчезающая фраза', 'Verblassender Satz', 'Phrase qui s’efface', 'Frase desvanecida', 'Frase a scomparsa', 'Frase que desaparece', 'Försvinnande mening'],
  'أكمل الفراغ الذكي': ['स्मार्ट रिक्त स्थान भरें', '智能句子填空', 'Умный пропуск', 'Smarter Lückentext', 'Texte à trous intelligent', 'Rellenar hueco inteligente', 'Completamento intelligente', 'Preencher lacuna', 'Smart lucktext'],
  'الرد السريع في المحادثة': ['चैट में त्वरित उत्तर', '情景对话快答', 'Быстрый ответ в чате', 'Schnelle Antwort im Gespräch', 'Réponse rapide en discussion', 'Respuesta rápida en charla', 'Risposta rapida in chat', 'Resposta rápida na conversa', 'Snabbt svar i samtal'],
  'الرد السريع': ['त्वरित उत्तर', '快答对话', 'Быстрый ответ', 'Schnelle Antwort', 'Réponse rapide', 'Respuesta rápida', 'Risposta rapida', 'Resposta rápida', 'Snabbsvar'],
  'تحدي النطق المباشر': ['सीधा उच्चारण चुनौती', '开口解锁挑战', 'Голосовой вызов', 'Direkte Sprech-Aufgabe', 'Défi de prononciation', 'Reto de pronunciación', 'Sfida di pronuncia', 'Desafio de pronúncia', 'Uttalsutmaning'],
  'تحدي النطق': ['उच्चारण चुनौती', '开口挑战', 'Голосовой тест', 'Sprech-Aufgabe', 'Défi oral', 'Reto de habla', 'Sfida vocale', 'Desafio de fala', 'Uttalsutmaning'],
  'سباق الجمل — 60 ثانية': ['वाक्य दौड़ — 60 सेकंड', '60秒句子极速赛', 'Блиц фраз — 60 сек', 'Satz-Sprint — 60 Sek.', 'Course de phrases — 60s', 'Carrera de frases — 60s', 'Corsa frasi — 60s', 'Corrida de frases — 60s', 'Meningslopp — 60s'],
  'سباق الجمل': ['वाक्य दौड़', '句子极速赛', 'Блиц фраз', 'Satz-Sprint', 'Course de phrases', 'Carrera de frases', 'Corsa frasi', 'Corrida de frases', 'Meningslopp'],
  '✓ اليوم': ['✓ आज', '✓ 今日完成', '✓ Сегодня', '✓ Heute', '✓ Aujourd’hui', '✓ Hoy', '✓ Oggi', '✓ Hoje', '✓ Idag'],
  'حركة': ['चाल', '步', 'ходов', 'Züge', 'coups', 'mov.', 'mosse', 'jogadas', 'drag'],
  'سلسلة': ['श्रृंखला', '连胜', 'серия', 'Serie', 'série', 'racha', 'serie', 'sequência', 'svit'],
  // CEFR band names & subtitles
  'تمهيدي': ['प्रारंभिक', '入门', 'Начальный', 'Einstieg', 'Initiation', 'Inicial', 'Iniziale', 'Inicial', 'Grund'],
  'مبتدئ': ['शुरुआती', '初级', 'Базовый', 'Anfänger', 'Débutant', 'Principiante', 'Principiante', 'Iniciante', 'Nybörjare'],
  'أساسي': ['बुनियादी', '基础', 'Элементарный', 'Grundlagen', 'Élémentaire', 'Elemental', 'Elementare', 'Elementar', 'Bas'],
  'متوسط': ['मध्यम', '中级', 'Средний', 'Mittelstufe', 'Intermédiaire', 'Intermedio', 'Intermedio', 'Intermediário', 'Medel'],
  'فوق المتوسط': ['उच्च मध्यम', '中高级', 'Выше среднего', 'Gehoben', 'Intermédiaire+', 'Intermedio alto', 'Intermedio alto', 'Intermediário alto', 'Övre medel'],
  'متقدم': ['उन्नत', '高级', 'Продвинутый', 'Fortgeschritten', 'Avancé', 'Avanzado', 'Avanzato', 'Avançado', 'Avancerad'],
  'إتقان': ['निपुणता', '精通', 'Профессиональный', 'Meisterschaft', 'Maîtrise', 'Maestría', 'Padronanza', 'Maestria', 'Mästerskap'],
  'تأسيسي': ['बुनियादी नींव', '基础入门', 'Базовый старт', 'Grundstufe', 'Fondamental', 'Fundacional', 'Fondamentale', 'Fundamental', 'Grundläggande'],
  'احترافي': ['व्यावसायिक निपुणता', '专业精通', 'Профессиональный', 'Professionell', 'Professionnel', 'Profesional', 'Professionale', 'Profissional', 'Professionell'],
  'أهم الكلمات الأساسية جداً': ['सबसे आवश्यक बुनियादी शब्द', '最核心的基础词汇', 'Самые важные базовые слова', 'Die wichtigsten Grundwörter', 'Les mots de base essentiels', 'Las palabras básicas esenciales', 'Le parole di base essenziali', 'As palavras básicas essenciais', 'De viktigaste grundorden'],
  'مستوى المبتدئ الأول': ['प्रारंभिक स्तर', '初级入门词汇', 'Первый начальный уровень', 'Erste Anfängerstufe', 'Premier niveau débutant', 'Primer nivel principiante', 'Primo livello principiante', 'Primeiro nível iniciante', 'Första nybörjarnivån'],
  'المحادثة والحياة اليومية': ['बातचीत और दैनिक जीवन', '日常交流与生活', 'Общение и повседневная жизнь', 'Gespräche & Alltag', 'Conversation et vie quotidienne', 'Conversación y vida diaria', 'Conversazione e vita quotidiana', 'Conversação e vida diária', 'Samtal och vardagsliv'],
  'الطلاقة اليومية والدراسية': ['दैनिक और शैक्षणिक प्रवाह', '日常与学习流利表达', 'Свободная речь в учёбе и быту', 'Flüssig im Alltag & Studium', 'Aisance quotidienne et scolaire', 'Fluidez diaria y académica', 'Fluidità quotidiana e di studio', 'Fluência diária e acadêmica', 'Vardagligt och akademiskt flyt'],
  'مستوى العمل والجامعة': ['कार्य और विश्वविद्यालय स्तर', '职场与大学水平', 'Уровень работы и вуза', 'Berufs- & Universitätsniveau', 'Niveau travail et université', 'Nivel laboral y universitario', 'Livello lavoro e università', 'Nível profissional e universitário', 'Arbets- och universitetsnivå'],
  'إتقان أكاديمي ومهني': ['शैक्षणिक और पेशेवर दक्षता', '学术与专业精通', 'Академическое и деловое владение', 'Akademische & berufliche Reife', 'Maîtrise académique et pro', 'Dominio académico y profesional', 'Padronanza accademica e prof.', 'Domínio acadêmico e profissional', 'Akademisk och professionell nivå'],
  'حصيلة لغوية شاملة': ['व्यापक और समृद्ध शब्दावली', '全面丰富的词汇量', 'Полный словарный запас', 'Umfassender Wortschatz', 'Vocabulaire complet', 'Vocabulario integral', 'Vocabolario completo', 'Vocabulário abrangente', 'Omfattande ordförråd'],

  // ListeningView level titles, descriptions & badges
  'التأسيس السمعي': ['श्रवण आधार', '听力入门', 'Основы аудирования', 'Hör-Grundlagen', 'Bases de l’écoute', 'Fundamentos de escucha', 'Basi dell’ascolto', 'Bases da escuta', 'Hörförståelse grund'],
  'فيديوهات قصيرة وواضحة جداً لتدريب الأذن على الأصوات والكلمات اليومية الأساسية.': ['ध्वनियों और दैनिक शब्दों के अभ्यास हेतु छोटे व स्पष्ट वीडियो।', '简短清晰的视频，帮助训练耳朵熟悉基础发音和日常词汇。', 'Короткие и чёткие видео для тренировки слуха на базовых словах.', 'Kurze, sehr klare Videos für Grundlaute und Alltagswörter.', 'Vidéos courtes et très claires pour entraîner l’oreille aux sons de base.', 'Videos cortos y claros para entrenar el oído en sonidos básicos.', 'Video brevi e chiari per allenare l’orecchio ai suoni di base.', 'Vídeos curtos e claros para treinar o ouvido em sons básicos.', 'Korta, tydliga videor för grundläggande ljud och vardagsord.'],
  '11 لغة كابشن + اختبار': ['11 उपशीर्षक भाषाएँ + क्विज़', '11种字幕 + 测验', '11 языков субтитров + тест', '11 Untertitelsprachen + Quiz', '11 langues de sous-titres + quiz', '11 idiomas de subtítulos + test', '11 lingue sottotitoli + quiz', '11 idiomas de legenda + quiz', '11 textningsspråk + quiz'],
  'المبتدئ': ['शुरुआती', '初级', 'Начальный', 'Anfänger', 'Débutant', 'Principiante', 'Principiante', 'Iniciante', 'Nybörjare'],
  'قصص يومية وموضوعات مألوفة عن السفر، الدراسة، الصحة، والحياة اليومية بإيقاع هادئ.': ['यात्रा, पढ़ाई, स्वास्थ्य और दैनिक जीवन की शांत गति वाली कहानियाँ।', '语速平和的日常故事，涵盖旅行、学习、健康与日常生活。', 'Спокойные истории о путешествиях, учёбе, здоровье и быте.', 'Ruhige Alltagsgeschichten über Reisen, Lernen, Gesundheit und Leben.', 'Histoires calmes sur les voyages, les études, la santé et le quotidien.', 'Historias cotidianas pausadas sobre viajes, estudio, salud y rutina.', 'Storie quotidiane calme su viaggi, studio, salute e vita di ogni giorno.', 'Histórias calmas sobre viagens, estudos, saúde e cotidiano.', 'Lugna berättelser om resor, studier, hälsa och vardag.'],
  'ما قبل المتوسط': ['पूर्व-मध्यम', '初中级', 'Ниже среднего', 'Untere Mittelstufe', 'Pré-intermédiaire', 'Preintermedio', 'Pre-intermedio', 'Pré-intermediário', 'För-medel'],
  'محادثات وقصص ملهمة عن العادات، العمل، الثقافات، والتجارب الإنسانية بلغة واضحة.': ['आदतों, काम, संस्कृतियों और मानवीय अनुभवों पर स्पष्ट व प्रेरक वार्तालाप।', '清晰易懂的启发式对话，涵盖习惯、工作、文化与人生经历。', 'Вдохновляющие беседы о привычках, работе, культуре и опыте.', 'Klare Gespräche über Gewohnheiten, Arbeit, Kultur und Erfahrungen.', 'Discussions inspirantes sur les habitudes, le travail et les cultures.', 'Charlas inspiradoras sobre hábitos, trabajo, culturas y experiencias.', 'Conversazioni chiare su abitudini, lavoro, culture ed esperienze.', 'Conversas claras sobre hábitos, trabalho, culturas e vivências.', 'Tydliga samtal om vanor, arbete, kultur och erfarenheter.'],
  'المتوسط': ['मध्यम', '中级', 'Средний', 'Mittelstufe', 'Intermédiaire', 'Intermedio', 'Intermedio', 'Intermediário', 'Medel'],
  'محاضرات وعروض ممتعة في علم النفس، التصميم، التعليم، والتكنولوجيا بمتحدثين متنوعين.': ['मनोविज्ञान, डिज़ाइन, शिक्षा और तकनीक पर विविध वक्ताओं के रोचक व्याख्यान।', '涵盖心理学、设计、教育与科技的精彩演讲，讲者风格多样。', 'Увлекательные лекции по психологии, дизайну, образованию и технологиям.', 'Spannende Vorträge zu Psychologie, Design, Bildung und Technik.', 'Conférences captivantes sur la psychologie, le design et la tech.', 'Charlas amenas sobre psicología, diseño, educación y tecnología.', 'Conferenze avvincenti su psicologia, design, istruzione e tecnologia.', 'Palestras envolventes sobre psicologia, design, educação e tecnologia.', 'Engagerande föredrag om psykologi, design, utbildning och teknik.'],
  'مناقشات معمّقة حول الابتكار، المجتمع، القيادة، والعلوم بسرعة حديث طبيعية.': ['नवाचार, समाज, नेतृत्व और विज्ञान पर स्वाभाविक गति में गहन चर्चाएँ।', '自然语速下关于创新、社会、领导力与科学的深度讨论。', 'Глубокие дискуссии об инновациях, обществе, лидерстве и науке.', 'Tiefgehende Gespräche über Innovation, Gesellschaft, Führung und Wissenschaft.', 'Débats approfondis sur l’innovation, la société, le leadership et la science.', 'Debates profundos sobre innovación, sociedad, liderazgo y ciencia.', 'Discussioni approfondite su innovazione, società, leadership e scienza.', 'Discussões aprofundadas sobre inovação, sociedade, liderança e ciência.', 'Fördjupade samtal om innovation, samhälle, ledarskap och vetenskap.'],
  'المتقدم': ['उन्नत', '高级', 'Продвинутый', 'Fortgeschritten', 'Avancé', 'Avanzado', 'Avanzato', 'Avançado', 'Avancerad'],
  'محاضرات فكرية وأكاديمية في الاقتصاد، الطب، الذكاء الاصطناعي، والفلسفة بمفردات غنية.': ['अर्थशास्त्र, चिकित्सा, AI और दर्शन पर समृद्ध शब्दावली वाले अकादमिक व्याख्यान।', '词汇丰富的学术演讲，涵盖经济、医学、人工智能与哲学。', 'Академические лекции по экономике, медицине, ИИ и философии.', 'Akademische Vorträge zu Wirtschaft, Medizin, KI und Philosophie.', 'Conférences académiques en économie, médecine, IA et philosophie.', 'Conferencias académicas de economía, medicina, IA y filosofía.', 'Lezioni accademiche su economia, medicina, IA e filosofia.', 'Palestras acadêmicas sobre economia, medicina, IA e filosofia.', 'Akademiska föreläsningar inom ekonomi, medicin, AI och filosofi.'],
  'الإتقان الكامل': ['पूर्ण निपुणता', '完全精通', 'Полное владение', 'Vollständige Beherrschung', 'Maîtrise complète', 'Dominio total', 'Padronanza completa', 'Domínio completo', 'Full behärskning'],
  'خطابات رئيسية ومناظرات عالية المستوى بلهجات طبيعية سريعة وتراكيب بلاغية دقيقة.': ['तेज़ स्वाभाविक लहजे और सटीक शैली में उच्च-स्तरीय मुख्य भाषण व वाद-विवाद।', '高水平主旨演讲与辩论，语速自然流畅、修辞精准。', 'Ключевые речи и дебаты высокого уровня с живыми акцентами.', 'Anspruchsvolle Keynotes und Debatten mit natürlichem Sprechtempo.', 'Discours et débats de haut niveau avec accents naturels rapides.', 'Discursos y debates de alto nivel con acentos naturales rápidos.', 'Discorsi e dibattiti di alto livello con accenti naturali rapidi.', 'Discursos e debates de alto nível com sotaques naturais rápidos.', 'Avancerade tal och debatter med naturliga, snabba accenter.'],

  // GrammarView labels & all 36 grammar lesson titles
  'قاعدة ·': ['नियम ·', '条语法 ·', 'правил ·', 'Regeln ·', 'règles ·', 'reglas ·', 'regole ·', 'regras ·', 'regler ·'],
  'تمرين تفاعلي': ['इंटरैक्टिव अभ्यास', '道互动练习', 'интерактивных упражнений', 'interaktive Übungen', 'exercices interactifs', 'ejercicios interactivos', 'esercizi interattivi', 'exercícios interativos', 'interaktiva övningar'],
  'أمثلة ·': ['उदाहरण ·', '个例句 ·', 'примеров ·', 'Beispiele ·', 'exemples ·', 'ejemplos ·', 'esempi ·', 'exemplos ·', 'exempel ·'],
  'فعل الكون (am / is / are)': ['क्रिया "to be" (am / is / are)', 'be动词 (am / is / are)', 'Глагол to be (am / is / are)', 'Das Verb „to be“ (am / is / are)', 'Le verbe « to be » (am / is / are)', 'El verbo "to be" (am / is / are)', 'Il verbo "to be" (am / is / are)', 'O verbo "to be" (am / is / are)', 'Verbet "to be" (am / is / are)'],
  'أدوات التعريف والتنكير (a / an / the)': ['आर्टिकल्स (a / an / the)', '冠词 (a / an / the)', 'Артикли (a / an / the)', 'Artikel (a / an / the)', 'Les articles (a / an / the)', 'Artículos (a / an / the)', 'Articoli (a / an / the)', 'Artigos (a / an / the)', 'Artiklar (a / an / the)'],
  'الأسماء المعدودة وغير المعدودة والجمع': ['गणनीय, अगणनीय संज्ञा और बहुवचन', '可数名词、不可数名词与复数', 'Исчисляемые/неисчисляемые и множ. число', 'Zählbare, unzählbare Nomen & Plural', 'Noms dénombrables, indénombrables et pluriel', 'Sustantivos contables, incontables y plural', 'Nomi numerabili, non numerabili e plurale', 'Substantivos contáveis, incontáveis e plural', 'Räknebara, oräknebara substantiv & plural'],
  'الضمائر (الفاعل والمفعول والملكية والانعكاسية)': ['सर्वनाम (कर्ता, कर्म, अधिकार व निजवाचक)', '代词（主格、宾格、所有格、反身代词）', 'Местоимения (личные, притяжательные, возвратные)', 'Pronomen (Subjekt, Objekt, Possessiv, Reflexiv)', 'Pronoms (sujet, objet, possessifs, réfléchis)', 'Pronombres (sujeto, objeto, posesivos, reflexivos)', 'Pronomi (soggetto, oggetto, possessivi, riflessivi)', 'Pronomes (sujeito, objeto, possessivos, reflexivos)', 'Pronomen (subjekt, objekt, possessiva, reflexiva)'],
  'أسماء الإشارة و (There is / There are)': ['संकेतवाचक और (There is / There are)', '指示代词与 There is / There are', 'Указательные местоимения и There is / There are', 'Demonstrativpronomen & There is / There are', 'Démonstratifs et There is / There are', 'Demostrativos y There is / There are', 'Dimostrativi e There is / There are', 'Demonstrativos e There is / There are', 'Demonstrativa pronomen & There is / There are'],
  'زمن الحاضر البسيط (Present Simple)': ['सामान्य वर्तमान काल (Present Simple)', '一般现在时 (Present Simple)', 'Настоящее простое время (Present Simple)', 'Gegenwart – Present Simple', 'Présent simple (Present Simple)', 'Presente simple (Present Simple)', 'Presente semplice (Present Simple)', 'Presente simples (Present Simple)', 'Presens enkel (Present Simple)'],
  'زمن الحاضر المستمر (Present Continuous)': ['अपूर्ण वर्तमान काल (Present Continuous)', '现在进行时 (Present Continuous)', 'Настоящее длительное (Present Continuous)', 'Verlaufsform Gegenwart (Present Continuous)', 'Présent continu (Present Continuous)', 'Presente continuo (Present Continuous)', 'Presente continuo (Present Continuous)', 'Presente contínuo (Present Continuous)', 'Pågående presens (Present Continuous)'],
  'زمن الماضي البسيط (Past Simple)': ['सामान्य भूतकाल (Past Simple)', '一般过去时 (Past Simple)', 'Прошедшее простое (Past Simple)', 'Vergangenheit – Past Simple', 'Passé simple (Past Simple)', 'Pasado simple (Past Simple)', 'Passato semplice (Past Simple)', 'Passado simples (Past Simple)', 'Preteritum (Past Simple)'],
  'زمن الماضي المستمر (Past Continuous)': ['अपूर्ण भूतकाल (Past Continuous)', '过去进行时 (Past Continuous)', 'Прошедшее длительное (Past Continuous)', 'Verlaufsform Vergangenheit (Past Continuous)', 'Passé continu (Past Continuous)', 'Pasado continuo (Past Continuous)', 'Passato continuo (Past Continuous)', 'Passado contínuo (Past Continuous)', 'Pågående preteritum (Past Continuous)'],
  'صيغ المستقبل (will / going to / الحاضر المستمر)': ['भविष्य काल के रूप (will / going to / Present Continuous)', '将来时表达 (will / going to / 现在进行时)', 'Формы будущего (will / going to / Present Continuous)', 'Zukunftsformen (will / going to / Present Continuous)', 'Formes du futur (will / going to / Présent continu)', 'Formas de futuro (will / going to / Present Continuous)', 'Forme del futuro (will / going to / Present Continuous)', 'Formas do futuro (will / going to / Present Continuous)', 'Futurumformer (will / going to / Present Continuous)'],
  'الحاضر التام (Present Perfect)': ['पूर्ण वर्तमान काल (Present Perfect)', '现在完成时 (Present Perfect)', 'Настоящее совершённое (Present Perfect)', 'Perfekt – Present Perfect', 'Present Perfect', 'Presente perfecto (Present Perfect)', 'Present Perfect', 'Presente perfeito (Present Perfect)', 'Perfekt (Present Perfect)'],
  'الحاضر التام المستمر (Present Perfect Continuous)': ['पूर्ण अपूर्ण वर्तमान (Present Perfect Continuous)', '现在完成进行时 (Present Perfect Continuous)', 'Present Perfect Continuous', 'Present Perfect Continuous', 'Present Perfect Continuous', 'Presente perfecto continuo (Present Perfect Continuous)', 'Present Perfect Continuous', 'Presente perfeito contínuo (Present Perfect Continuous)', 'Pågående perfekt (Present Perfect Continuous)'],
  'الماضي التام والماضي التام المستمر': ['पूर्ण भूतकाल व पूर्ण अपूर्ण भूतकाल (Past Perfect)', '过去完成时与过去完成进行时', 'Past Perfect и Past Perfect Continuous', 'Plusquamperfekt (Past Perfect & Continuous)', 'Past Perfect et Past Perfect Continuous', 'Pasado perfecto y pasado perfecto continuo', 'Past Perfect e Past Perfect Continuous', 'Passado perfeito e passado perfeito contínuo', 'Pluskvamperfekt (Past Perfect & Continuous)'],
  'المستقبل المستمر والمستقبل التام': ['अपूर्ण भविष्य और पूर्ण भविष्य काल', '将来进行时与将来完成时', 'Future Continuous и Future Perfect', 'Future Continuous & Future Perfect', 'Futur continu et futur antérieur', 'Futuro continuo y futuro perfecto', 'Futuro continuo e futuro anteriore', 'Futuro contínuo e futuro perfeito', 'Pågående futurum & futurum exakt'],
  'أفعال القدرة والاستئذان (can / could / be able to)': ['क्षमता व अनुमति क्रियाएँ (can / could / be able to)', '能力与许可情态动词 (can / could / be able to)', 'Способность и разрешение (can / could / be able to)', 'Fähigkeit & Erlaubnis (can / could / be able to)', 'Capacité et permission (can / could / be able to)', 'Habilidad y permiso (can / could / be able to)', 'Abilità e permesso (can / could / be able to)', 'Habilidade e permissão (can / could / be able to)', 'Förmåga & tillåtelse (can / could / be able to)'],
  'الإلزام والنصيحة (must / have to / should)': ['बाध्यता व सलाह (must / have to / should)', '义务与建议 (must / have to / should)', 'Обязанность и совет (must / have to / should)', 'Pflicht & Ratschlag (must / have to / should)', 'Obligation et conseil (must / have to / should)', 'Obligación y consejo (must / have to / should)', 'Obbligo e consiglio (must / have to / should)', 'Obrigação e conselho (must / have to / should)', 'Tvång & råd (must / have to / should)'],
  'أفعال الاستنتاج والاحتمال (must / might / can’t)': ['निष्कर्ष व संभावना (must / might / can’t)', '推测与可能性 (must / might / can’t)', 'Вывод и вероятность (must / might / can’t)', 'Vermutung & Möglichkeit (must / might / can’t)', 'Déduction et probabilité (must / might / can’t)', 'Deducción y probabilidad (must / might / can’t)', 'Deduzione e probabilità (must / might / can’t)', 'Dedução e probabilidade (must / might / can’t)', 'Slutsats & sannolikhet (must / might / can’t)'],
  'العادات الماضية والتفضيل (used to / would rather / had better)': ['पिछली आदतें व प्राथमिकता (used to / would rather / had better)', '过去习惯与偏好 (used to / would rather / had better)', 'Прошлые привычки и предпочтения (used to / would rather)', 'Gewohnheiten & Vorlieben (used to / would rather / had better)', 'Habitudes passées et préférences (used to / would rather)', 'Hábitos pasados y preferencias (used to / would rather)', 'Abitudini passate e preferenze (used to / would rather)', 'Hábitos passados e preferências (used to / would rather)', 'Tidigare vanor & preferenser (used to / would rather)'],
  'الصفات والظروف (-ed و -ing وترتيب الصفات)': ['विशेषण व क्रिया-विशेषण (-ed / -ing व क्रम)', '形容词与副词 (-ed/-ing 及词序)', 'Прилагательные и наречия (-ed / -ing и порядок)', 'Adjektive & Adverbien (-ed/-ing & Reihenfolge)', 'Adjectifs et adverbes (-ed / -ing et ordre)', 'Adjetivos y adverbios (-ed / -ing y orden)', 'Aggettivi e avverbi (-ed / -ing e ordine)', 'Adjetivos e advérbios (-ed / -ing e ordem)', 'Adjektiv & adverb (-ed / -ing & ordföljd)'],
  'صيغ المقارنة والتفضيل (-er / more / the most)': ['तुलनात्मक और उत्तम अवस्था (-er / more / the most)', '比较级与最高级 (-er / more / the most)', 'Сравнительная и превосходная степени (-er / more / most)', 'Komparativ & Superlativ (-er / more / the most)', 'Comparatif et superlatif (-er / more / the most)', 'Comparativos y superlativos (-er / more / the most)', 'Comparativi e superlativi (-er / more / the most)', 'Comparativos e superlativos (-er / more / the most)', 'Komparativ & superlativ (-er / more / the most)'],
  'محددات الكمية (some / any / much / many / few / enough)': ['मात्रा सूचक (some / any / much / many / few / enough)', '量词 (some / any / much / many / few / enough)', 'Квантификаторы (some / any / much / many / few / enough)', 'Mengenangaben (some / any / much / many / few / enough)', 'Quantifieurs (some / any / much / many / few / enough)', 'Cuantificadores (some / any / much / many / few / enough)', 'Quantificatori (some / any / much / many / few / enough)', 'Quantificadores (some / any / much / many / few / enough)', 'Mängdord (some / any / much / many / few / enough)'],
  'حروف الجر للزمان والمكان (in / on / at / by / until)': ['समय व स्थान के पूर्वसर्ग (in / on / at / by / until)', '时间与地点介词 (in / on / at / by / until)', 'Предлоги времени и места (in / on / at / by / until)', 'Präpositionen für Zeit & Ort (in / on / at / by / until)', 'Prépositions de temps et lieu (in / on / at / by / until)', 'Preposiciones de tiempo y lugar (in / on / at / by / until)', 'Preposizioni di tempo e luogo (in / on / at / by / until)', 'Preposições de tempo e lugar (in / on / at / by / until)', 'Prepositioner för tid & plats (in / on / at / by / until)'],
  'الروابط وأدوات التناقض والسبب (although / despite / however)': ['संयोजक व विरोध शब्द (although / despite / however)', '连词与转折因果词 (although / despite / however)', 'Союзы причины и уступки (although / despite / however)', 'Bindewörter & Gegensatz (although / despite / however)', 'Connecteurs d’opposition et cause (although / despite / however)', 'Conectores de contraste y causa (although / despite / however)', 'Connettivi di contrasto e causa (although / despite / however)', 'Conectivos de contraste e causa (although / despite / however)', 'Konjunktioner & motsatsord (although / despite / however)'],
  'تكوين الأسئلة والأسئلة الذيلية وغير المباشرة': ['प्रश्न निर्माण, क्वेश्चन टैग और अप्रत्यक्ष प्रश्न', '疑问句、反意疑问句与间接疑问句', 'Вопросы, разделительные и косвенные вопросы', 'Fragebildung, Question Tags & indirekte Fragen', 'Formation des questions, tags et questions indirectes', 'Formación de preguntas, tags e indirectas', 'Formazione di domande, question tag e indirette', 'Formação de perguntas, tags e indiretas', 'Frågebildning, påhängsfrågor & indirekta frågor'],
  'المبني للمجهول في جميع الأزمنة (Passive Voice)': ['सभी कालों में कर्मवाच्य (Passive Voice)', '全时态被动语态 (Passive Voice)', 'Пассивный залог во всех временах (Passive Voice)', 'Passiv in allen Zeitformen (Passive Voice)', 'Voix passive à tous les temps (Passive Voice)', 'Voz pasiva en todos los tiempos (Passive Voice)', 'Forma passiva in tutti i tempi (Passive Voice)', 'Voz passiva em todos os tempos (Passive Voice)', 'Passiv form i alla tempus (Passive Voice)'],
  'الكلام المنقول (Reported Speech)': ['अप्रत्यक्ष कथन (Reported Speech)', '间接引语 (Reported Speech)', 'Косвенная речь (Reported Speech)', 'Indirekte Rede (Reported Speech)', 'Discours indirect (Reported Speech)', 'Estilo indirecto (Reported Speech)', 'Discorso indiretto (Reported Speech)', 'Discurso indireto (Reported Speech)', 'Indirekt tal (Reported Speech)'],
  'الأفعال السببية (have/get something done · make · let)': ['प्रेरणार्थक क्रियाएँ (have/get something done · make · let)', '使役动词 (have/get something done · make · let)', 'Каузативные глаголы (have/get done · make · let)', 'Kausative Verben (have/get done · make · let)', 'Verbes causatifs (have/get something done · make · let)', 'Verbos causativos (have/get something done · make · let)', 'Verbi causativi (have/get something done · make · let)', 'Verbos causativos (have/get something done · make · let)', 'Kausativa verb (have/get something done · make · let)'],
  'الجمل الشرطية بجميع أنواعها (0، 1، 2، 3 والمختلطة)': ['सभी प्रकार के शर्त वाक्य (0, 1, 2, 3 और मिश्रित)', '全部条件句（0、1、2、3型及混合条件句）', 'Все типы условных предложений (0, 1, 2, 3 и смешанные)', 'Alle Bedingungssätze (0, 1, 2, 3 & gemischt)', 'Toutes les propositions conditionnelles (0, 1, 2, 3, mixtes)', 'Oraciones condicionales (0, 1, 2, 3 y mixtas)', 'Frasi condizionali di tutti i tipi (0, 1, 2, 3 e miste)', 'Orações condicionais (0, 1, 2, 3 e mistas)', 'Villkorssatser av alla typer (0, 1, 2, 3 & blandade)'],
  'جمل الوصل (who / which / that / whose / where)': ['संबंधवाचक उपवाक्य (who / which / that / whose / where)', '定语从句 (who / which / that / whose / where)', 'Определительные придаточные (who / which / that / whose / where)', 'Relativsätze (who / which / that / whose / where)', 'Propositions relatives (who / which / that / whose / where)', 'Cláusulas relativas (who / which / that / whose / where)', 'Frasi relative (who / which / that / whose / where)', 'Orações relativas (who / which / that / whose / where)', 'Relativsatser (who / which / that / whose / where)'],
  'المصدر الصريح والمؤول (Gerund -ing مقابل to + V1)': ['जेरंड (-ing) बनाम इन्फिनिटिव (to + V1)', '动名词 (-ing) 与不定式 (to + V1)', 'Герундий (-ing) и инфинитив (to + V1)', 'Gerund (-ing) vs. Infinitiv (to + V1)', 'Gérondif (-ing) vs Infinitif (to + V1)', 'Gerundio (-ing) frente a infinitivo (to + V1)', 'Gerundio (-ing) vs Infinito (to + V1)', 'Gerúndio (-ing) vs Infinitivo (to + V1)', 'Gerundium (-ing) vs Infinitiv (to + V1)'],
  'التمني والندم (Wish & If only)': ['इच्छा और पछतावा (Wish & If only)', '愿望与遗憾 (Wish & If only)', 'Пожелания и сожаления (Wish & If only)', 'Wünsche & Bedauern (Wish & If only)', 'Souhaits et regrets (Wish & If only)', 'Deseos y arrepentimiento (Wish & If only)', 'Desideri e rimpianti (Wish & If only)', 'Desejos e arrependimentos (Wish & If only)', 'Önskningar & ånger (Wish & If only)'],
  'القلب للتوكيد والجمل المنقسمة (Inversion & Cleft Sentences)': ['बल हेतु व्युत्क्रम व विभक्त वाक्य (Inversion & Cleft)', '倒装与强调句 (Inversion & Cleft Sentences)', 'Инверсия и расщеплённые предложения (Inversion & Cleft)', 'Inversion & Spaltsätze (Inversion & Cleft Sentences)', 'Inversion et phrases clivées (Inversion & Cleft)', 'Inversión y oraciones hendidas (Inversion & Cleft)', 'Inversione e frasi scisse (Inversion & Cleft Sentences)', 'Inversão e frases clivadas (Inversion & Cleft)', 'Inversion & utbrytning (Inversion & Cleft Sentences)'],
  'صيغة الالتزام والرسميات (Subjunctive Mood)': ['संभावनार्थक व औपचारिक शैली (Subjunctive Mood)', '虚拟语气与正式表达 (Subjunctive Mood)', 'Сослагательное наклонение (Subjunctive Mood)', 'Konjunktiv & formelle Sprache (Subjunctive Mood)', 'Mode subjonctif (Subjunctive Mood)', 'Modo subjuntivo (Subjunctive Mood)', 'Modo congiuntivo (Subjunctive Mood)', 'Modo subjuntivo (Subjunctive Mood)', 'Konjunktiv & formellt språk (Subjunctive Mood)'],
  'جمل اسم الفاعل والمفعول المختصرة (Participle Clauses)': ['कृदंत उपवाक्य (Participle Clauses)', '分词从句 (Participle Clauses)', 'Причастные обороты (Participle Clauses)', 'Partizipialsätze (Participle Clauses)', 'Propositions participiales (Participle Clauses)', 'Cláusulas de participio (Participle Clauses)', 'Frasi participiali (Participle Clauses)', 'Orações participiais (Participle Clauses)', 'Participfraser (Participle Clauses)'],
  'الأفعال المركّبة (Phrasal Verbs)': ['वाक्यांश क्रियाएँ (Phrasal Verbs)', '短语动词 (Phrasal Verbs)', 'Фразовые глаголы (Phrasal Verbs)', 'Phrasal Verbs (Mehrwortverben)', 'Verbes à particule (Phrasal Verbs)', 'Verbos compuestos (Phrasal Verbs)', 'Verbi frasali (Phrasal Verbs)', 'Verbos frasais (Phrasal Verbs)', 'Partikelverb (Phrasal Verbs)'],
  'الحذف والاستبدال وأدوات الترابط المتقدمة (C2)': ['उन्नत लोप, प्रतिस्थापन और संयोजन (C2)', '省略、替代与高级语篇衔接 (C2)', 'Эллипсис, замещение и связность речи (C2)', 'Ellipse, Substitution & Textkohäsion (C2)', 'Ellipse, substitution et cohésion avancée (C2)', 'Elipsis, sustitución y cohesión avanzada (C2)', 'Ellissi, sostituzione e coesione avanzata (C2)', 'Elipse, substituição e coesão avançada (C2)', 'Ellips, substitution & avancerad kohesion (C2)'],

  // 7 Flagship Learning Features + Updated Navigation
  'مهمتك اليوم': ['आपका आज का मिशन', '今日学习任务', 'Ваш план на сегодня', 'Dein Tagesplan', 'Votre mission du jour', 'Tu misión de hoy', 'La tua missione di oggi', 'Sua missão de hoje', 'Dagens studieplan'],
  'دفتري الشخصي': ['मेरी अध्ययन नोटबुक', '我的学习笔记本', 'Личная тетрадь', 'Mein Lernheft', 'Mon carnet', 'Mi cuaderno', 'Il mio quaderno', 'Meu caderno', 'Min anteckningsbok'],
  'دفتري الشخصي والتصدير': ['मेरी नोटबुक और निर्यात', '我的学习笔记本与导出', 'Личная тетрадь и экспорт', 'Mein Lernheft & Export', 'Mon carnet & export', 'Mi cuaderno y exportación', 'Il mio quaderno ed esportazione', 'Meu caderno e exportação', 'Min anteckningsbok & export'],
  'تدريب الظل (Shadowing)': ['शैडोइंग उच्चारण अभ्यास', '影子跟读训练', 'Тренировка Shadowing', 'Shadowing-Aussprache', 'Pratique Shadowing', 'Práctica Shadowing', 'Pratica Shadowing', 'Prática Shadowing', 'Shadowing-träning'],
  'تدريب الظل': ['शैडोइंग', '影子跟读', 'Shadowing', 'Shadowing', 'Shadowing', 'Shadowing', 'Shadowing', 'Shadowing', 'Shadowing'],
  'جلسة إصلاح سريعة (دقيقتان)': ['2-मिनट त्वरित त्रुटि सुधार', '2分钟快速纠错训练', 'Быстрое исправление (2 мин)', '2-Minuten-Fehlertraining', 'Correction rapide (2 min)', 'Corrección rápida (2 min)', 'Correzione rapida (2 min)', 'Correção rápida (2 min)', 'Snabb felträning (2 min)'],
  'إصلاح أخطائي السريع': ['त्वरित त्रुटि सुधार', '快速纠错', 'Исправление ошибок', 'Fehler korrigieren', 'Corriger mes erreurs', 'Corregir mis errores', 'Correggi i miei errori', 'Corrigir meus erros', 'Rätta mina fel'],
  'خريطة نشاط آخر 30 يوماً': ['पिछले 30 दिनों की गतिविधि', '近30天学习热力图', 'Активность за 30 дней', 'Aktivität der letzten 30 Tage', 'Activité sur 30 jours', 'Actividad de 30 días', 'Attività degli ultimi 30 giorni', 'Atividade dos últimos 30 dias', 'Aktivitet senaste 30 dagarna'],
  'شارات الإنجاز': ['उपलब्धि बैज', '成就徽章', 'Значки достижений', 'Erfolgsabzeichen', 'Badges de réussite', 'Insignias de logro', 'Badge di risultato', 'Distintivos de conquista', 'Prestationsmärken'],
  'شهادات الإنجاز (CEFR)': ['CEFR प्रमाणपत्र', 'CEFR 成就证书', 'Сертификаты CEFR', 'CEFR-Zertifikate', 'Certificats CEFR', 'Certificados CEFR', 'Certificati CEFR', 'Certificados CEFR', 'CEFR-certifikat'],
  'تعديل خطة التعلم': ['अध्ययन योजना संपादित करें', '修改学习计划', 'Изменить план обучения', 'Lernplan anpassen', 'Modifier le plan d’étude', 'Editar plan de estudio', 'Modifica piano di studio', 'Editar plano de estudos', 'Ändra studieplan'],
  'أقسام المهارات': ['कौशल अनुभाग', '技能模块', 'Разделы навыков', 'Fähigkeiten', 'Compétences', 'Secciones de habilidades', 'Sezioni abilità', 'Seções de habilidades', 'Färdigheter'],
  'الأدوات والبيانات': ['उपकरण और डेटा', '工具与数据', 'Инструменты и данные', 'Werkzeuge & Daten', 'Outils & données', 'Herramientas y datos', 'Strumenti e dati', 'Ferramentas e dados', 'Verktyg & data'],
  'بحث سريع': ['त्वरित खोज', '快速搜索', 'Быстрый поиск', 'Schnellsuche', 'Recherche rapide', 'Búsqueda rápida', 'Ricerca rapida', 'Busca rápida', 'Snabbsök'],
  'تصدير لـ Anki (CSV)': ['Anki (CSV) निर्यात', '导出到 Anki (CSV)', 'Экспорт в Anki (CSV)', 'Anki-Export (CSV)', 'Exporter vers Anki (CSV)', 'Exportar a Anki (CSV)', 'Esporta in Anki (CSV)', 'Exportar para Anki (CSV)', 'Exportera till Anki (CSV)'],
  'طباعة ورقة الدراسة': ['अध्ययन शीट प्रिंट करें', '打印学习单', 'Печать листа обучения', 'Lernblatt drucken', 'Imprimer la fiche', 'Imprimir hoja de estudio', 'Stampa scheda di studio', 'Imprimir folha de estudo', 'Skriv ut studieblad'],
  'المحادثة والكتابة': ['बातचीत और लेखन', '口语与写作', 'Разговор и письмо', 'Sprechen & Schreiben', 'Parler & Écrire', 'Conversación y escritura', 'Conversazione e scrittura', 'Conversação e escrita', 'Samtal & skrivande'],
};

const UNIT_WORDS: Record<string, [string, string, string, string, string, string, string, string, string]> = {
  sentences: ['वाक्य', '句', 'фраз', 'Sätze', 'phrases', 'frases', 'frasi', 'frases', 'meningar'],
  showing: ['दिखाया जा रहा है', '显示', 'Показано', 'Zeige', 'Affichage', 'Mostrando', 'Mostrando', 'Mostrando', 'Visar'],
  of: ['में से', '/', 'из', 'von', 'sur', 'de', 'di', 'de', 'av'],
  categories: ['श्रेणियाँ', '分类', 'категорий', 'Kategorien', 'catégories', 'categorías', 'categorie', 'categorias', 'kategorier'],
  showAllCats: ['सभी श्रेणियाँ दिखाएँ', '显示全部分类', 'Показать все категории', 'Alle Kategorien anzeigen', 'Toutes les catégories', 'Ver todas las categorías', 'Mostra tutte le categorie', 'Ver todas as categorias', 'Visa alla kategorier'],
  words: ['शब्द', '词', 'слов', 'Wörter', 'mots', 'palabras', 'parole', 'palavras', 'ord'],
  level: ['स्तर', '关卡', 'Уровень', 'Level', 'Niveau', 'Nivel', 'Livello', 'Nível', 'Nivå'],
  levelWords: ['स्तर के शब्द', '本关单词', 'Слова уровня', 'Level-Wörter', 'Mots du niveau', 'Palabras del nivel', 'Parole del livello', 'Palavras do nível', 'Nivåord'],
  bestScore: ['सर्वश्रेष्ठ स्कोर', '最高分', 'Лучший результат', 'Bestwert', 'Meilleur score', 'Mejor puntuación', 'Miglior punteggio', 'Melhor pontuação', 'Bästa resultat'],
  completed: ['पूर्ण', '已完成', 'Завершено', 'Abgeschlossen', 'Terminé', 'Completado', 'Completato', 'Concluído', 'Klart'],
  moreCats: ['अतिरिक्त श्रेणियाँ', '个更多分类', 'ещё категорий', 'weitere Kategorien', 'catégories en plus', 'categorías más', 'altre categorie', 'mais categorias', 'fler kategorier'],
  videosFor: ['वीडियो क्लिप', '视频片段', 'Видеоклипы', 'Videoclips', 'Clips vidéo', 'Clips de video', 'Clip video', 'Clipes de vídeo', 'Videoklipp'],
};

/**
 * Synchronous 0ms local phrasebook + dynamic template translator for all 9 non-Arabic languages.
 * Eliminates Arabic UI leakage even offline or when external free translators rate-limit.
 */
export function lookupLocalUiTranslation(lang: AppLang, rawText: string): string | null {
  if (lang === 'ar' || !rawText) return null;
  const idx = LANG_MAP[lang as NonArLang];
  if (idx === undefined) return null;

  const trimmed = rawText.trim();
  const exact = PHRASE_TABLE[trimmed];
  if (exact) return exact[idx];

  // Pattern: عرض 1–15 من 21,708 جملة
  const mRange = trimmed.match(/^عرض\s+([\d,–-]+)\s+من\s+([\d,]+)\s+جملة$/);
  if (mRange) {
    return `${UNIT_WORDS.showing[idx]} ${mRange[1]} ${UNIT_WORDS.of[idx]} ${mRange[2]} ${UNIT_WORDS.sentences[idx]}`;
  }

  // Pattern: عرض كل التصنيفات (36)
  const mCats = trimmed.match(/^عرض كل التصنيفات\s*\((\d+)\)$/);
  if (mCats) {
    return `${UNIT_WORDS.showAllCats[idx]} (${mCats[1]})`;
  }

  // Pattern: + 24 تصنيفاً إضافياً
  const mMoreCats = trimmed.match(/^\+\s*(\d+)\s+تصنيفاً إضافياً$/);
  if (mMoreCats) {
    return `+ ${mMoreCats[1]} ${UNIT_WORDS.moreCats[idx]}`;
  }

  // Pattern: الكل (21,708)
  const mAllCount = trimmed.match(/^الكل\s*\(([\d,]+)\)$/);
  if (mAllCount) {
    return `${PHRASE_TABLE['الكل'][idx]} (${mAllCount[1]})`;
  }

  // Pattern: كلمات المستوى (20)
  const mLvlWords = trimmed.match(/^كلمات المستوى\s*\((\d+)\)$/);
  if (mLvlWords) {
    return `${UNIT_WORDS.levelWords[idx]} (${mLvlWords[1]})`;
  }

  // Pattern: المستوى 1
  const mLvl = trimmed.match(/^المستوى\s+(\d+)$/);
  if (mLvl) {
    return `${UNIT_WORDS.level[idx]} ${mLvl[1]}`;
  }

  // Pattern: 1,234 كلمة
  const mWords = trimmed.match(/^([\d,]+)\s+كلمة$/);
  if (mWords) {
    return `${mWords[1]} ${UNIT_WORDS.words[idx]}`;
  }

  // Pattern: كلمة · أفضل نتيجة:
  if (trimmed.includes('أفضل نتيجة')) {
    return trimmed
      .replace(/كلمة/g, UNIT_WORDS.words[idx])
      .replace(/أفضل نتيجة/g, UNIT_WORDS.bestScore[idx]);
  }

  // Pattern: مكتمل ...
  if (trimmed.includes('مكتمل')) {
    const cleaned = trimmed.replace(/مكتمل/g, UNIT_WORDS.completed[idx]);
    if (!/[\u0600-\u06FF]/.test(cleaned)) return cleaned;
  }

  // Pattern: mixed partial prefix/suffix inside compound React text nodes
  const mTrailingUnit = trimmed.match(/^([\d,\s()·:+/-]+)?(جملة|كلمة|تصنيفاً)(\)|:|)\s*$/);
  if (mTrailingUnit) {
    const num = mTrailingUnit[1] || '';
    const unit =
      mTrailingUnit[2] === 'جملة'
        ? UNIT_WORDS.sentences[idx]
        : mTrailingUnit[2] === 'كلمة'
          ? UNIT_WORDS.words[idx]
          : UNIT_WORDS.categories[idx];
    return `${num}${unit}${mTrailingUnit[3] || ''}`;
  }

  return null;
}
