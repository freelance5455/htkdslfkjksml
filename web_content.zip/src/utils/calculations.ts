import {
  AttaRecord,
  CplLot,
  LeaveRecord,
  LeaveSummary,
  LoanRecord,
  CommitteeRecord,
} from '../types';

/**
 * 1. Atta Calculations
 * 1 Maund = 40 KG.
 * User enters quantity in Maund.
 * Rate unit: 'Per Maund' | 'Per KG'
 */
export function calculateAttaAmount(
  quantityMaund: number,
  rate: number,
  rateUnit: 'Per Maund' | 'Per KG'
): { totalAmount: number; equivalentKg: number } {
  const qty = Number(quantityMaund) || 0;
  const r = Number(rate) || 0;
  const equivalentKg = qty * 40;

  let totalAmount = 0;
  if (rateUnit === 'Per Maund') {
    totalAmount = r * qty;
  } else if (rateUnit === 'Per KG') {
    totalAmount = r * qty * 40;
  }

  return {
    totalAmount: Math.round(totalAmount * 100) / 100,
    equivalentKg: Math.round(equivalentKg * 100) / 100,
  };
}

export function summarizeAttaPurchases(records: AttaRecord[]) {
  const activeRecords = records.filter((r) => !r.isDeleted);
  const totalPurchases = activeRecords.length;
  const totalQuantityMaund = activeRecords.reduce((sum, r) => sum + (Number(r.quantityMaund) || 0), 0);
  const totalQuantityKg = activeRecords.reduce((sum, r) => sum + (Number(r.equivalentKg) || 0), 0);
  const totalAmount = activeRecords.reduce((sum, r) => sum + (Number(r.totalAmount) || 0), 0);

  const averageRatePerMaund = totalQuantityMaund > 0 ? totalAmount / totalQuantityMaund : 0;
  const averageRatePerKg = totalQuantityKg > 0 ? totalAmount / totalQuantityKg : 0;

  // Supplier summary
  const supplierSummary: Record<string, { count: number; maund: number; amount: number }> = {};
  for (const r of activeRecords) {
    const s = r.supplier?.trim() || 'Unknown';
    if (!supplierSummary[s]) {
      supplierSummary[s] = { count: 0, maund: 0, amount: 0 };
    }
    supplierSummary[s].count += 1;
    supplierSummary[s].maund += Number(r.quantityMaund) || 0;
    supplierSummary[s].amount += Number(r.totalAmount) || 0;
  }

  return {
    totalPurchases,
    totalQuantityMaund,
    totalQuantityKg,
    totalAmount,
    averageRatePerMaund,
    averageRatePerKg,
    supplierSummary,
  };
}

/**
 * 2. Loan Calculations (Loan Payable)
 * Loan Payable = Money that I have borrowed and still have to return.
 * Loan Received increases payable balance.
 * Loan Repaid decreases payable balance.
 * Remaining Loan Payable = Total Loan Received - Total Loan Repaid
 */
export function calculateLoanPayable(records: LoanRecord[], personFilter?: string) {
  const active = records.filter((r) => !r.isDeleted && !r.isReceivable);
  const filtered = personFilter ? active.filter((r) => r.person === personFilter) : active;

  let totalReceived = 0;
  let totalRepaid = 0;

  for (const r of filtered) {
    const amt = Number(r.amount) || 0;
    if (r.transactionType === 'Loan Received') {
      totalReceived += amt;
    } else if (r.transactionType === 'Loan Repaid') {
      totalRepaid += amt;
    }
  }

  const remainingPayable = totalReceived - totalRepaid;

  // Person-wise breakdown
  const personWise: Record<string, { received: number; repaid: number; payable: number }> = {};
  for (const r of active) {
    const p = r.person?.trim() || 'General';
    if (!personWise[p]) {
      personWise[p] = { received: 0, repaid: 0, payable: 0 };
    }
    const amt = Number(r.amount) || 0;
    if (r.transactionType === 'Loan Received') {
      personWise[p].received += amt;
    } else if (r.transactionType === 'Loan Repaid') {
      personWise[p].repaid += amt;
    }
    personWise[p].payable = personWise[p].received - personWise[p].repaid;
  }

  return {
    totalReceived,
    totalRepaid,
    remainingPayable,
    personWise,
  };
}

/**
 * Loan Receivable (Money given to others)
 */
export function calculateLoanReceivable(records: LoanRecord[]) {
  const active = records.filter((r) => !r.isDeleted && r.isReceivable);
  let totalGiven = 0;
  let totalRecovered = 0;

  for (const r of active) {
    const amt = Number(r.amount) || 0;
    if (r.transactionType === 'Loan Received') {
      // For receivable: Loan Given
      totalGiven += amt;
    } else if (r.transactionType === 'Loan Repaid') {
      // For receivable: Loan Recovered
      totalRecovered += amt;
    }
  }

  return {
    totalGiven,
    totalRecovered,
    remainingReceivable: totalGiven - totalRecovered,
  };
}

/**
 * 3. Committee Calculations (Completely separate from loans)
 */
export function calculateCommitteePosition(records: CommitteeRecord[], committeeNameFilter?: string) {
  const active = records.filter((r) => !r.isDeleted);
  const filtered = committeeNameFilter ? active.filter((r) => r.committeeName === committeeNameFilter) : active;

  let totalInstallments = 0;
  let totalPayouts = 0;

  for (const r of filtered) {
    const amt = Number(r.amount) || 0;
    if (r.transactionType === 'Installment') {
      totalInstallments += amt;
    } else if (r.transactionType === 'Payout') {
      totalPayouts += amt;
    }
  }

  // Net position: Payouts received minus Installments deposited
  const netPosition = totalPayouts - totalInstallments;

  // Committee-wise breakdown
  const committeeWise: Record<string, { installments: number; payouts: number; net: number; members: Set<string> }> = {};
  for (const r of active) {
    const c = r.committeeName?.trim() || 'General';
    if (!committeeWise[c]) {
      committeeWise[c] = { installments: 0, payouts: 0, net: 0, members: new Set() };
    }
    if (r.memberName) committeeWise[c].members.add(r.memberName);
    const amt = Number(r.amount) || 0;
    if (r.transactionType === 'Installment') {
      committeeWise[c].installments += amt;
    } else if (r.transactionType === 'Payout') {
      committeeWise[c].payouts += amt;
    }
    committeeWise[c].net = committeeWise[c].payouts - committeeWise[c].installments;
  }

  return {
    totalInstallments,
    totalPayouts,
    netPosition,
    committeeWise,
  };
}

/**
 * 4. Factory: Leave & CPL Management (FIFO lot allocation)
 * Leave year: starts July 1st (configurable).
 * CPL: Expiry in N days (default 40 days).
 * FIFO allocation: Oldest valid earning lots are consumed first.
 */
export function isDateInCurrentLeaveYear(
  dateStr: string,
  startMonth: number = 7, // 7 for July
  startDay: number = 1,
  asOfDate: Date = new Date()
): boolean {
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return false;

  const currentYear = asOfDate.getFullYear();
  const currentMonth = asOfDate.getMonth() + 1; // 1-12

  // Determine the start date of the current leave year
  let leaveYearStart: Date;
  if (currentMonth >= startMonth) {
    leaveYearStart = new Date(currentYear, startMonth - 1, startDay, 0, 0, 0);
  } else {
    leaveYearStart = new Date(currentYear - 1, startMonth - 1, startDay, 0, 0, 0);
  }

  // End date is exactly 1 year later minus 1 ms
  const leaveYearEnd = new Date(leaveYearStart.getFullYear() + 1, startMonth - 1, startDay, 23, 59, 59, 999);
  leaveYearEnd.setDate(leaveYearEnd.getDate() - 1);

  return d >= leaveYearStart && d <= leaveYearEnd;
}

export function calculateLeaveBalances(
  records: LeaveRecord[],
  options: {
    clLimit?: number;
    slLimit?: number;
    cplExpiryDays?: number;
    leaveYearStartMonth?: number;
    leaveYearStartDay?: number;
    asOfDate?: Date;
  } = {}
): LeaveSummary {
  const clLimit = options.clLimit ?? 10;
  const slLimit = options.slLimit ?? 8;
  const cplExpiryDays = options.cplExpiryDays ?? 40;
  const startMonth = options.leaveYearStartMonth ?? 7;
  const startDay = options.leaveYearStartDay ?? 1;
  const asOf = options.asOfDate ?? new Date();
  const asOfTime = asOf.getTime();

  const active = records.filter((r) => !r.isDeleted);

  // CL & SL calculated for current leave year
  let clUsed = 0;
  let slUsed = 0;

  for (const r of active) {
    if (isDateInCurrentLeaveYear(r.date, startMonth, startDay, asOf)) {
      if (r.leaveType === 'CL') {
        clUsed += Number(r.numberOfDays) || 0;
      } else if (r.leaveType === 'SL') {
        slUsed += Number(r.numberOfDays) || 0;
      }
    }
  }

  const clRemaining = Math.max(0, clLimit - clUsed);
  const slRemaining = Math.max(0, slLimit - slUsed);

  // CPL FIFO Lots calculation:
  // Step 1: Collect all 'CPL Earn' records sorted chronologically by date
  const earnRecords = active
    .filter((r) => r.leaveType === 'CPL Earn')
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Step 2: Collect all 'CPL Used' records sorted chronologically
  const useRecords = active
    .filter((r) => r.leaveType === 'CPL Used')
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Build CPL lots
  const lots: CplLot[] = earnRecords.map((r) => {
    const earnD = new Date(r.date);
    const expiryD = new Date(earnD);
    expiryD.setDate(expiryD.getDate() + cplExpiryDays);
    const isExpired = expiryD.getTime() < asOfTime;

    return {
      id: r.id,
      earnDate: r.date,
      daysEarned: Number(r.numberOfDays) || 0,
      daysUsed: 0,
      daysExpired: 0,
      daysRemaining: Number(r.numberOfDays) || 0,
      expiryDate: expiryD.toISOString().slice(0, 10),
      isFullyConsumed: false,
      isExpired,
    };
  });

  // Step 3: Allocate CPL Used against lots using FIFO
  // Each usage record is allocated to the oldest available valid lot that hadn't expired as of that usage date!
  for (const u of useRecords) {
    let daysToAllocate = Number(u.numberOfDays) || 0;
    const useTime = new Date(u.date).getTime();

    for (const lot of lots) {
      if (daysToAllocate <= 0) break;
      if (lot.isFullyConsumed) continue;

      const lotEarnTime = new Date(lot.earnDate).getTime();
      const lotExpiryTime = new Date(lot.expiryDate).getTime();

      // Check if this lot was valid when used:
      // Must be earned on or before use date, and not expired before use date
      if (lotEarnTime <= useTime && useTime <= lotExpiryTime) {
        const availableInLot = lot.daysEarned - lot.daysUsed;
        if (availableInLot > 0) {
          const allocate = Math.min(daysToAllocate, availableInLot);
          lot.daysUsed += allocate;
          lot.daysRemaining -= allocate;
          daysToAllocate -= allocate;
          if (lot.daysRemaining <= 0) {
            lot.isFullyConsumed = true;
          }
        }
      }
    }
  }

  // Step 4: For any lot whose expiry date has passed today, mark the remaining days as expired!
  let cplEarned = 0;
  let cplUsed = 0;
  let cplExpired = 0;
  let cplAvailable = 0;
  const upcomingExpirations: CplLot[] = [];

  const sevenDaysFromNow = asOfTime + 7 * 24 * 60 * 60 * 1000;

  for (const lot of lots) {
    cplEarned += lot.daysEarned;
    cplUsed += lot.daysUsed;

    const lotExpiryTime = new Date(lot.expiryDate).getTime();
    if (lotExpiryTime < asOfTime) {
      // Expired!
      lot.isExpired = true;
      lot.daysExpired = lot.daysRemaining;
      lot.daysRemaining = 0;
      cplExpired += lot.daysExpired;
    } else {
      // Still valid!
      lot.isExpired = false;
      cplAvailable += lot.daysRemaining;
      if (lot.daysRemaining > 0 && lotExpiryTime <= sevenDaysFromNow) {
        upcomingExpirations.push(lot);
      }
    }
  }

  return {
    clOpening: clLimit,
    clUsed,
    clRemaining,
    slOpening: slLimit,
    slUsed,
    slRemaining,
    cplEarned,
    cplUsed,
    cplExpired,
    cplAvailable,
    cplLots: lots,
    upcomingExpirations,
  };
}

/**
 * 5. Safe Formula Engine
 * Safe recursive descent parser supporting arithmetic, comparisons, logic, and functions.
 * Does NOT use eval or Function constructor.
 */
export function evaluateSafeFormula(
  formula: string,
  context: Record<string, any> = {}
): number | string | boolean | null {
  if (!formula || !formula.trim()) return null;

  // Substitute bracketed variable names e.g. [Rate] or [Quantity] or field IDs
  let expression = formula.trim();

  // Replace [Field Name] or field ID with values
  // We can scan for identifiers
  const normalizeIdentifier = (id: string) => id.replace(/[\[\]]/g, '').trim();

  // Tokenizer
  type TokenType = 'NUMBER' | 'STRING' | 'IDENT' | 'OPERATOR' | 'PUNCT' | 'EOF';
  interface Token {
    type: TokenType;
    value: string | number;
  }

  const tokens: Token[] = [];
  let i = 0;
  const len = expression.length;

  while (i < len) {
    const ch = expression[i];

    if (/\s/.test(ch)) {
      i++;
      continue;
    }

    // Number
    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(expression[i + 1] || ''))) {
      let numStr = '';
      while (i < len && /[0-9.]/.test(expression[i])) {
        numStr += expression[i++];
      }
      tokens.push({ type: 'NUMBER', value: parseFloat(numStr) });
      continue;
    }

    // String literal in quotes
    if (ch === '"' || ch === "'") {
      const quote = ch;
      i++;
      let str = '';
      while (i < len && expression[i] !== quote) {
        str += expression[i++];
      }
      i++; // skip quote
      tokens.push({ type: 'STRING', value: str });
      continue;
    }

    // Bracketed identifier [Field Name]
    if (ch === '[') {
      i++;
      let ident = '';
      while (i < len && expression[i] !== ']') {
        ident += expression[i++];
      }
      i++; // skip ']'
      tokens.push({ type: 'IDENT', value: ident.trim() });
      continue;
    }

    // Word identifier or function name
    if (/[a-zA-Z_]/.test(ch)) {
      let ident = '';
      while (i < len && /[a-zA-Z0-9_]/.test(expression[i])) {
        ident += expression[i++];
      }
      tokens.push({ type: 'IDENT', value: ident });
      continue;
    }

    // Operators and Punctuation
    if (expression.slice(i, i + 2) === '<=' || expression.slice(i, i + 2) === '>=' || expression.slice(i, i + 2) === '==') {
      tokens.push({ type: 'OPERATOR', value: expression.slice(i, i + 2) });
      i += 2;
      continue;
    }
    if (expression.slice(i, i + 2) === '!=') {
      tokens.push({ type: 'OPERATOR', value: '!=' });
      i += 2;
      continue;
    }

    if ('+-*/%<>=!'.includes(ch)) {
      tokens.push({ type: 'OPERATOR', value: ch });
      i++;
      continue;
    }

    if ('(),'.includes(ch)) {
      tokens.push({ type: 'PUNCT', value: ch });
      i++;
      continue;
    }

    i++; // unknown char skipped
  }
  tokens.push({ type: 'EOF', value: '' });

  // Parser
  let cur = 0;
  function peek(): Token {
    return tokens[cur] || { type: 'EOF', value: '' };
  }
  function consume(): Token {
    return tokens[cur++] || { type: 'EOF', value: '' };
  }

  function resolveValue(name: string): any {
    const key = normalizeIdentifier(name);
    // Direct match in context
    if (key in context) return context[key];
    // Case-insensitive match
    const lower = key.toLowerCase();
    for (const k of Object.keys(context)) {
      if (k.toLowerCase() === lower) return context[k];
    }
    return 0;
  }

  // Parse expression: comparison -> add/sub -> mul/div -> unary -> primary
  function parseExpression(): any {
    return parseComparison();
  }

  function parseComparison(): any {
    let left = parseAddSub();
    while (peek().type === 'OPERATOR' && ['<', '>', '<=', '>=', '==', '=', '!='].includes(String(peek().value))) {
      const op = consume().value;
      const right = parseAddSub();
      if (op === '<') left = left < right;
      else if (op === '>') left = left > right;
      else if (op === '<=') left = left <= right;
      else if (op === '>=') left = left >= right;
      else if (op === '==' || op === '=') left = left == right;
      else if (op === '!=') left = left != right;
    }
    return left;
  }

  function parseAddSub(): any {
    let left = parseMulDiv();
    while (peek().type === 'OPERATOR' && (peek().value === '+' || peek().value === '-')) {
      const op = consume().value;
      const right = parseMulDiv();
      if (op === '+') {
        left = typeof left === 'string' || typeof right === 'string' ? `${left}${right}` : Number(left) + Number(right);
      } else {
        left = Number(left) - Number(right);
      }
    }
    return left;
  }

  function parseMulDiv(): any {
    let left = parseUnary();
    while (peek().type === 'OPERATOR' && (peek().value === '*' || peek().value === '/' || peek().value === '%')) {
      const op = consume().value;
      const right = parseUnary();
      if (op === '*') left = Number(left) * Number(right);
      else if (op === '/') left = Number(right) === 0 ? 0 : Number(left) / Number(right);
      else if (op === '%') left = Number(left) % Number(right);
    }
    return left;
  }

  function parseUnary(): any {
    if (peek().type === 'OPERATOR' && peek().value === '-') {
      consume();
      return -Number(parseUnary());
    }
    if (peek().type === 'OPERATOR' && peek().value === '+') {
      consume();
      return Number(parseUnary());
    }
    return parsePrimary();
  }

  function parsePrimary(): any {
    const t = peek();

    if (t.type === 'NUMBER') {
      consume();
      return Number(t.value);
    }

    if (t.type === 'STRING') {
      consume();
      return String(t.value);
    }

    if (t.type === 'PUNCT' && t.value === '(') {
      consume(); // '('
      const val = parseExpression();
      if (peek().type === 'PUNCT' && peek().value === ')') {
        consume(); // ')'
      }
      return val;
    }

    if (t.type === 'IDENT') {
      const identToken = consume();
      const identName = String(identToken.value);

      // Function call?
      if (peek().type === 'PUNCT' && peek().value === '(') {
        consume(); // '('
        const args: any[] = [];
        if (!(peek().type === 'PUNCT' && peek().value === ')')) {
          while (true) {
            args.push(parseExpression());
            if (peek().type === 'PUNCT' && peek().value === ',') {
              consume();
            } else {
              break;
            }
          }
        }
        if (peek().type === 'PUNCT' && peek().value === ')') {
          consume();
        }

        const fn = identName.toUpperCase();
        if (fn === 'IF') {
          return args[0] ? args[1] : (args[2] ?? 0);
        }
        if (fn === 'SUM') {
          return args.reduce((acc, curr) => acc + (Number(curr) || 0), 0);
        }
        if (fn === 'COUNT') {
          return args.filter((a) => a !== null && a !== undefined && a !== '').length;
        }
        if (fn === 'MIN') {
          return Math.min(...args.map((a) => Number(a) || 0));
        }
        if (fn === 'MAX') {
          return Math.max(...args.map((a) => Number(a) || 0));
        }
        if (fn === 'ROUND') {
          const n = Number(args[0]) || 0;
          const dec = Number(args[1]) || 0;
          const f = Math.pow(10, dec);
          return Math.round(n * f) / f;
        }
        if (fn === 'IFERROR') {
          try {
            return isNaN(args[0]) ? (args[1] ?? 0) : args[0];
          } catch {
            return args[1] ?? 0;
          }
        }
        return 0;
      }

      // Variable name
      return resolveValue(identName);
    }

    // Default fallback
    consume();
    return 0;
  }

  try {
    const res = parseExpression();
    if (typeof res === 'number') {
      return isNaN(res) ? 0 : Math.round(res * 10000) / 10000;
    }
    return res;
  } catch (err) {
    return 0;
  }
}
