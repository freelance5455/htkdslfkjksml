/**
 * Pure calculation logic for "دفتر الجرد والأرباح"
 * Decoupled and unit-tested for accuracy.
 */

import type {
  PurchaseItem,
  SaleItem,
  ExpenseItem,
  DebtPayment,
  MedicineStock,
  BatchInfo,
  ProfitReportResult,
  MedicineProfitItem,
  PartyDebtSummary,
} from '../types/pharmacy.ts';

/**
 * Format currency in Iraqi Dinar (IQD د.ع) with thousand separators
 */
export function formatIQD(amount: number): string {
  const rounded = Math.round(amount || 0);
  const formatted = new Intl.NumberFormat('en-US').format(rounded);
  return `${formatted} د.ع`;
}

/**
 * Format date in clean Arabic or standard ISO format
 */
export function formatDateArabic(dateStr: string): string {
  if (!dateStr) return '-';
  try {
    const [year, month, day] = dateStr.split('-');
    if (year && month && day) {
      return `${day}/${month}/${year}`;
    }
    return dateStr;
  } catch {
    return dateStr;
  }
}

/**
 * Calculate difference in days between today and expiry date.
 * If negative, product is expired.
 */
export function getDaysUntilExpiry(expiryDateStr: string, currentDate: Date = new Date()): number | null {
  if (!expiryDateStr) return null;
  const exp = new Date(expiryDateStr + 'T00:00:00');
  if (isNaN(exp.getTime())) return null;

  const today = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());
  const diffTime = exp.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Calculate stock per medicine, including:
 * - total bought
 * - total sold
 * - remaining quantity
 * - weighted average cost (COGS basis)
 * - stock value (remaining * average cost)
 * - FIFO/FEFO batches
 * - nearest expiry date and alert flags
 */
export function calculateMedicineStocks(
  purchases: PurchaseItem[],
  sales: SaleItem[],
  minStockOverrides: Record<string, number> = {},
  todayDate: Date = new Date()
): Record<string, MedicineStock> {
  const stocks: Record<string, MedicineStock> = {};

  // 1. Process all purchases to build batch history and calculate total cost & bought
  // Sort purchases chronologically
  const sortedPurchases = [...purchases].sort((a, b) => {
    return new Date(a.date).getTime() - new Date(b.date).getTime() || a.createdAt - b.createdAt;
  });

  // Track purchased totals for average cost:
  // Weighted Average Cost = Total Purchase Expenditure / Total Purchased Units
  const costTotals: Record<string, { totalSpend: number; totalUnits: number; name: string }> = {};

  for (const p of sortedPurchases) {
    const barcode = p.barcode.trim();
    if (!barcode) continue;

    if (!costTotals[barcode]) {
      costTotals[barcode] = {
        totalSpend: 0,
        totalUnits: 0,
        name: p.medicineName,
      };
    }
    costTotals[barcode].totalSpend += Number(p.totalAmount) || 0;
    costTotals[barcode].totalUnits += Number(p.qty) || 0;
    if (p.medicineName) costTotals[barcode].name = p.medicineName;
  }

  // 2. Track sold quantities per barcode
  const soldMap: Record<string, { totalSold: number; name?: string }> = {};
  for (const s of sales) {
    const barcode = s.barcode.trim();
    if (!barcode) continue;
    if (!soldMap[barcode]) {
      soldMap[barcode] = { totalSold: 0, name: s.medicineName };
    }
    soldMap[barcode].totalSold += Number(s.qty) || 0;
  }

  // Gather all unique barcodes
  const allBarcodes = Array.from(new Set([...Object.keys(costTotals), ...Object.keys(soldMap)]));

  for (const barcode of allBarcodes) {
    const purchasedData = costTotals[barcode] || { totalSpend: 0, totalUnits: 0, name: barcode };
    const soldData = soldMap[barcode] || { totalSold: 0 };

    const totalBought = purchasedData.totalUnits;
    const totalSold = soldData.totalSold;
    const remaining = Math.max(0, totalBought - totalSold);

    // Weighted average cost per unit
    const averageCost = totalBought > 0 ? purchasedData.totalSpend / totalBought : 0;
    const stockValue = Math.max(0, remaining * averageCost);

    // Batch allocation (FEFO: allocate sales against earliest expiring batches)
    const itemPurchases = sortedPurchases
      .filter((p) => p.barcode.trim() === barcode)
      .sort((a, b) => new Date(a.expiryDate || '9999-12-31').getTime() - new Date(b.expiryDate || '9999-12-31').getTime());

    let soldToDeduct = totalSold;
    const batches: BatchInfo[] = [];

    for (const p of itemPurchases) {
      const orig = Number(p.qty) || 0;
      let batchRemaining = orig;

      if (soldToDeduct > 0) {
        if (soldToDeduct >= batchRemaining) {
          soldToDeduct -= batchRemaining;
          batchRemaining = 0;
        } else {
          batchRemaining -= soldToDeduct;
          soldToDeduct = 0;
        }
      }

      if (batchRemaining > 0) {
        batches.push({
          purchaseId: p.id,
          expiryDate: p.expiryDate,
          originalQty: orig,
          remainingQty: batchRemaining,
          unitPrice: p.unitPrice,
          supplier: p.supplier,
        });
      }
    }

    // Find nearest active expiry date from remaining batches
    let nearestExpiry: string | null = null;
    let daysToExpiry: number | null = null;

    if (batches.length > 0) {
      const sortedActiveBatches = [...batches].sort(
        (a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime()
      );
      nearestExpiry = sortedActiveBatches[0].expiryDate;
      daysToExpiry = getDaysUntilExpiry(nearestExpiry, todayDate);
    }

    const minAlert = minStockOverrides[barcode] ?? 10;
    const isLowStock = remaining > 0 && remaining <= minAlert;
    const isExpired = daysToExpiry !== null && daysToExpiry <= 0;
    const isNearExpiry = daysToExpiry !== null && daysToExpiry > 0 && daysToExpiry <= 90;

    stocks[barcode] = {
      barcode,
      name: purchasedData.name || soldData.name || barcode,
      unit: 'باكيت',
      totalBought,
      totalSold,
      remaining,
      averageCost,
      stockValue,
      minStockAlert: minAlert,
      batches,
      nearestExpiry,
      daysToExpiry,
      isLowStock,
      isExpired,
      isNearExpiry,
    };
  }

  return stocks;
}

/**
 * Get nearest expiry batch info for a medicine (for the sales screen alert)
 */
export function getNearestExpiryForSale(
  barcode: string,
  stocks: Record<string, MedicineStock>
): { nearestExpiry: string | null; daysToExpiry: number | null; availableQty: number; avgCost: number } {
  const stock = stocks[barcode.trim()];
  if (!stock) {
    return { nearestExpiry: null, daysToExpiry: null, availableQty: 0, avgCost: 0 };
  }
  return {
    nearestExpiry: stock.nearestExpiry,
    daysToExpiry: stock.daysToExpiry,
    availableQty: stock.remaining,
    avgCost: stock.averageCost,
  };
}

/**
 * Calculate Debts for Buyers (what customers owe us) and Suppliers (what we owe suppliers)
 * Includes invoices (remaining unpaid) and direct payments/receipts.
 */
export function calculateDebts(
  purchases: PurchaseItem[],
  sales: SaleItem[],
  payments: DebtPayment[]
): {
  buyersDebts: PartyDebtSummary[];
  suppliersDebts: PartyDebtSummary[];
  totalOwedToUs: number; // ديون لنا على الزبائن
  totalWeOwe: number; // ديون علينا للموردين
  netDebtPosition: number; // totalOwedToUs - totalWeOwe
} {
  // 1. Calculate buyers debts:
  // For each buyer, they owe us: Sum(Sale Total) - Sum(Sale Amount Paid) - Sum(Receipt Payments)
  const buyerMap: Record<string, { totalInvoiced: number; totalPaid: number; lastDate: string }> = {};

  for (const s of sales) {
    const buyer = (s.buyer || 'زبون عام').trim();
    if (!buyerMap[buyer]) {
      buyerMap[buyer] = { totalInvoiced: 0, totalPaid: 0, lastDate: s.date };
    }
    buyerMap[buyer].totalInvoiced += Number(s.totalAmount) || 0;
    buyerMap[buyer].totalPaid += Number(s.amountPaid) || 0;
    if (s.date > buyerMap[buyer].lastDate) {
      buyerMap[buyer].lastDate = s.date;
    }
  }

  // Account for separate debt receipts from buyers
  for (const p of payments) {
    if (p.partyType === 'buyer') {
      const buyer = p.partyName.trim();
      if (!buyerMap[buyer]) {
        buyerMap[buyer] = { totalInvoiced: 0, totalPaid: 0, lastDate: p.date };
      }
      buyerMap[buyer].totalPaid += Number(p.amount) || 0;
      if (p.date > buyerMap[buyer].lastDate) {
        buyerMap[buyer].lastDate = p.date;
      }
    }
  }

  const buyersDebts: PartyDebtSummary[] = Object.entries(buyerMap)
    .map(([partyName, data]) => ({
      partyName,
      partyType: 'buyer' as const,
      totalInvoiced: data.totalInvoiced,
      totalPaid: data.totalPaid,
      balanceRemaining: Math.max(0, data.totalInvoiced - data.totalPaid),
      lastTransactionDate: data.lastDate,
    }))
    .filter((b) => b.balanceRemaining > 0)
    .sort((a, b) => b.balanceRemaining - a.balanceRemaining);

  // 2. Calculate suppliers debts:
  // For each supplier, we owe them: Sum(Purchase Total) - Sum(Purchase Amount Paid) - Sum(Payments to Supplier)
  const supplierMap: Record<string, { totalInvoiced: number; totalPaid: number; lastDate: string }> = {};

  for (const p of purchases) {
    const supplier = (p.supplier || 'مورد عام').trim();
    if (!supplierMap[supplier]) {
      supplierMap[supplier] = { totalInvoiced: 0, totalPaid: 0, lastDate: p.date };
    }
    supplierMap[supplier].totalInvoiced += Number(p.totalAmount) || 0;
    supplierMap[supplier].totalPaid += Number(p.amountPaid) || 0;
    if (p.date > supplierMap[supplier].lastDate) {
      supplierMap[supplier].lastDate = p.date;
    }
  }

  for (const pay of payments) {
    if (pay.partyType === 'supplier') {
      const supplier = pay.partyName.trim();
      if (!supplierMap[supplier]) {
        supplierMap[supplier] = { totalInvoiced: 0, totalPaid: 0, lastDate: pay.date };
      }
      supplierMap[supplier].totalPaid += Number(pay.amount) || 0;
      if (pay.date > supplierMap[supplier].lastDate) {
        supplierMap[supplier].lastDate = pay.date;
      }
    }
  }

  const suppliersDebts: PartyDebtSummary[] = Object.entries(supplierMap)
    .map(([partyName, data]) => ({
      partyName,
      partyType: 'supplier' as const,
      totalInvoiced: data.totalInvoiced,
      totalPaid: data.totalPaid,
      balanceRemaining: Math.max(0, data.totalInvoiced - data.totalPaid),
      lastTransactionDate: data.lastDate,
    }))
    .filter((s) => s.balanceRemaining > 0)
    .sort((a, b) => b.balanceRemaining - a.balanceRemaining);

  const totalOwedToUs = buyersDebts.reduce((sum, b) => sum + b.balanceRemaining, 0);
  const totalWeOwe = suppliersDebts.reduce((sum, s) => sum + s.balanceRemaining, 0);
  const netDebtPosition = totalOwedToUs - totalWeOwe;

  return {
    buyersDebts,
    suppliersDebts,
    totalOwedToUs,
    totalWeOwe,
    netDebtPosition,
  };
}

/**
 * Calculate Profit Report for a given date range:
 * - Sales Revenue
 * - COGS (Cost of goods sold using average cost per item at sale or current weighted average)
 * - Gross Profit (Sales - COGS)
 * - Expenses
 * - Net Profit (Gross Profit - Expenses)
 * - Margin %
 * - Profit per medicine breakdown
 */
export function calculateProfitReport(
  purchases: PurchaseItem[],
  sales: SaleItem[],
  expenses: ExpenseItem[],
  startDate: string,
  endDate: string,
  periodLabel: string = 'تقرير مخصص'
): ProfitReportResult {
  // Filter sales and expenses within the date interval [startDate, endDate] inclusive
  const periodSales = sales.filter((s) => {
    return (!startDate || s.date >= startDate) && (!endDate || s.date <= endDate);
  });

  const periodExpenses = expenses.filter((e) => {
    return (!startDate || e.date >= startDate) && (!endDate || e.date <= endDate);
  });

  // Calculate current stock and weighted average cost for each medicine
  const stocks = calculateMedicineStocks(purchases, sales);

  let totalSales = 0;
  let totalCogs = 0;

  const medicineProfitMap: Record<
    string,
    {
      medicineName: string;
      barcode: string;
      qtySold: number;
      revenue: number;
      cogs: number;
    }
  > = {};

  for (const s of periodSales) {
    const revenue = Number(s.totalAmount) || (Number(s.qty) || 0) * (Number(s.unitPrice) || 0);
    const qty = Number(s.qty) || 0;
    const barcode = s.barcode.trim();

    // Use avgCostAtSale if recorded, or fall back to current weighted average cost from purchases
    const unitCost = s.avgCostAtSale > 0 ? s.avgCostAtSale : (stocks[barcode]?.averageCost ?? 0);
    const cogs = qty * unitCost;

    totalSales += revenue;
    totalCogs += cogs;

    const key = barcode || s.medicineName;
    if (!medicineProfitMap[key]) {
      medicineProfitMap[key] = {
        medicineName: s.medicineName || 'دواء بدون اسم',
        barcode: barcode,
        qtySold: 0,
        revenue: 0,
        cogs: 0,
      };
    }
    medicineProfitMap[key].qtySold += qty;
    medicineProfitMap[key].revenue += revenue;
    medicineProfitMap[key].cogs += cogs;
  }

  const medicineProfits: MedicineProfitItem[] = Object.values(medicineProfitMap)
    .map((item) => {
      const grossProfit = item.revenue - item.cogs;
      const marginPercent = item.revenue > 0 ? (grossProfit / item.revenue) * 100 : 0;
      return {
        ...item,
        grossProfit,
        marginPercent,
      };
    })
    .sort((a, b) => b.grossProfit - a.grossProfit);

  const totalExpenses = periodExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const grossProfit = totalSales - totalCogs;
  const netProfit = grossProfit - totalExpenses;
  const profitMarginPercent = totalSales > 0 ? (netProfit / totalSales) * 100 : 0;

  return {
    periodLabel,
    startDate,
    endDate,
    totalSales,
    cogs: totalCogs,
    grossProfit,
    totalExpenses,
    netProfit,
    profitMarginPercent,
    medicineProfits,
  };
}

/**
 * Filter items by Arabic/English query across names, barcodes, suppliers, buyers
 */
export function searchMatches(target: string | undefined, query: string): boolean {
  if (!query) return true;
  if (!target) return false;
  return target.toLowerCase().includes(query.trim().toLowerCase());
}
