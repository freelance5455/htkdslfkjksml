import { 
  Site, 
  Labour, 
  SiteAttendanceRecord, 
  LabourAdvancePayment, 
  EngineerPayment, 
  MessExpense, 
  MessCollection, 
  RoomOwnerConfig, 
  LandlordPayment, 
  ProRataLabourRentCalculation 
} from '../types';

/**
 * মাসের মোট দিন সংখ্যা বের করার ফাংশন (যেমন: 2025-03 -> 31 দিন, 2025-02 -> 28 দিন)
 */
export function getDaysInMonthString(monthStr: string): number {
  if (!monthStr || !monthStr.includes('-')) return 30;
  const [yearStr, monthNumStr] = monthStr.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthNumStr, 10); // 1-12
  return new Date(year, month, 0).getDate();
}

/**
 * বাড়িওয়ালার জন্য প্রতিটি মেস লেবারের জন-প্রতি প্রোরোটা (Pro-rata) ভাড়ার হিসাব
 */
export function calculateProRataRentForMonth(
  labours: Labour[],
  roomOwnerConfig: RoomOwnerConfig,
  collections: MessCollection[]
): {
  list: ProRataLabourRentCalculation[];
  totalActiveMessLabours: number;
  totalCalculatedRent: number;
  totalCollectedRoomRent: number;
  totalPendingRentFromLabours: number;
} {
  const monthStr = roomOwnerConfig.billingMonth;
  const daysInMonth = getDaysInMonthString(monthStr);
  const monthStartDate = `${monthStr}-01`;
  const monthEndDate = `${monthStr}-${String(daysInMonth).padStart(2, '0')}`;
  const dailyRate = roomOwnerConfig.perHeadMonthlyRate / daysInMonth;

  // শুধুমাত্র যারা মেসে থাকে (mess_and_site এবং mess_only)
  const messLabours = labours.filter(
    l => l.roleType === 'mess_and_site' || l.roleType === 'mess_only'
  );

  const list: ProRataLabourRentCalculation[] = messLabours.map(labour => {
    const stayStart = labour.messStayStartDate || monthStartDate;
    const stayEnd = labour.messStayEndDate || null;

    let activeDays = 0;

    // শুরু ও শেষের তারিখ যাচাই
    const effectiveStart = stayStart > monthStartDate ? stayStart : monthStartDate;
    const effectiveEnd = (stayEnd && stayEnd < monthEndDate) ? stayEnd : monthEndDate;

    if (stayStart > monthEndDate || (stayEnd && stayEnd < monthStartDate)) {
      activeDays = 0;
    } else {
      const dStart = new Date(effectiveStart + 'T00:00:00');
      const dEnd = new Date(effectiveEnd + 'T00:00:00');
      const diffTime = dEnd.getTime() - dStart.getTime();
      const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24)) + 1;
      activeDays = Math.max(0, Math.min(daysInMonth, diffDays));
    }

    const calculatedRent = Math.round(activeDays * dailyRate);

    // লেবারের থেকে আদায়কৃত রুম ভাড়া
    const labourCollections = collections.filter(
      c => c.labourId === labour.id && c.type === 'room_rent'
    );
    const collectedRent = labourCollections.reduce((sum, c) => sum + c.amount, 0);
    const dueRent = Math.max(0, calculatedRent - collectedRent);

    return {
      labourId: labour.id,
      labourName: labour.name,
      roleType: labour.roleType,
      phone: labour.phone,
      stayStartDate: stayStart,
      stayEndDate: stayEnd,
      activeDaysInMonth: activeDays,
      totalDaysInMonth: daysInMonth,
      dailyRate: Math.round(dailyRate * 100) / 100,
      calculatedRent,
      collectedRent,
      dueRent
    };
  });

  const totalCalculatedRent = list.reduce((sum, item) => sum + item.calculatedRent, 0);
  const totalCollectedRoomRent = list.reduce((sum, item) => sum + item.collectedRent, 0);
  const totalPendingRentFromLabours = list.reduce((sum, item) => sum + item.dueRent, 0);
  const totalActiveMessLabours = list.filter(l => l.activeDaysInMonth > 0).length;

  return {
    list,
    totalActiveMessLabours,
    totalCalculatedRent,
    totalCollectedRoomRent,
    totalPendingRentFromLabours
  };
}

/**
 * মেস সংক্রান্ত আর্থিক সামারি
 */
export function getMessFinancialSummary(
  expenses: MessExpense[],
  collections: MessCollection[]
) {
  const totalMessExpense = expenses.reduce((sum, e) => sum + e.amount, 0);

  const mealCollections = collections.filter(c => c.type === 'meal_cost');
  const roomRentCollections = collections.filter(c => c.type === 'room_rent');

  const totalMealCollection = mealCollections.reduce((sum, c) => sum + c.amount, 0);
  const totalRoomRentCollection = roomRentCollections.reduce((sum, c) => sum + c.amount, 0);

  // মেস উদ্বৃত্ত বা ঘাটতি (খাবার সংগ্রহ - মোট মেস খরচ)
  const messSurplus = totalMealCollection - totalMessExpense;

  const categoryWiseExpense = expenses.reduce((acc, curr) => {
    acc[curr.category] = (acc[curr.category] || 0) + curr.amount;
    return acc;
  }, {} as Record<string, number>);

  return {
    totalMessExpense,
    totalMealCollection,
    totalRoomRentCollection,
    messSurplus,
    categoryWiseExpense
  };
}

/**
 * বাড়িওয়ালার ভাড়ার পেমেন্ট ও বকেয়ার সামারি
 */
export function getLandlordFinancialSummary(
  totalCalculatedRent: number,
  landlordPayments: LandlordPayment[],
  billingMonth: string
) {
  // নির্দিষ্ট মাসের পেমেন্ট
  const paymentsForMonth = landlordPayments.filter(p => p.forMonth.includes(billingMonth));
  const totalPaidToLandlord = paymentsForMonth.reduce((sum, p) => sum + p.amount, 0);
  const allTimePaidToLandlord = landlordPayments.reduce((sum, p) => sum + p.amount, 0);

  const pendingLandlordRent = Math.max(0, totalCalculatedRent - totalPaidToLandlord);

  return {
    totalCalculatedRent,
    totalPaidToLandlord,
    allTimePaidToLandlord,
    pendingLandlordRent
  };
}

/**
 * সাইট ভিত্তিক মজুরি, কমিশন ও পেমেন্ট সামারি
 */
export function getSitesFinancialSummary(
  sites: Site[],
  attendance: SiteAttendanceRecord[],
  advances: LabourAdvancePayment[],
  engineerPayments: EngineerPayment[]
) {
  let totalFlatCommission = 0;
  let totalActiveSites = 0;

  sites.forEach(site => {
    if (site.status === 'active') {
      totalFlatCommission += site.flatCommission;
      totalActiveSites++;
    }
  });

  // প্রতি সাইটের বিস্তারিত হিসাব
  const siteDetails = sites.map(site => {
    const siteAtt = attendance.filter(a => a.siteId === site.id);
    const siteAdvances = advances.filter(adv => adv.siteId === site.id);
    const siteEngPayments = engineerPayments.filter(ep => ep.siteId === site.id);

    const totalWagesEarned = siteAtt.reduce((sum, a) => sum + (a.daysWorked * a.wageRate), 0);
    const totalAdvancePaid = siteAdvances.reduce((sum, a) => sum + a.amount, 0);
    const pendingLabourWages = Math.max(0, totalWagesEarned - totalAdvancePaid);

    const totalReceivedFromEngineer = siteEngPayments.reduce((sum, p) => sum + p.amount, 0);
    
    // ইঞ্জিনিয়ার থেকে পাওনা = সাইটের লেবার মজুরি + ফ্ল্যাট কমিশন - প্রাপ্ত পেমেন্ট
    const totalSiteBilled = totalWagesEarned + site.flatCommission;
    const pendingFromEngineer = Math.max(0, totalSiteBilled - totalReceivedFromEngineer);

    return {
      site,
      totalWagesEarned,
      totalAdvancePaid,
      pendingLabourWages,
      totalReceivedFromEngineer,
      totalSiteBilled,
      pendingFromEngineer
    };
  });

  const totalAllSitesWages = siteDetails.reduce((sum, s) => sum + s.totalWagesEarned, 0);
  const totalAllSitesAdvances = siteDetails.reduce((sum, s) => sum + s.totalAdvancePaid, 0);
  const totalPendingLabourWages = siteDetails.reduce((sum, s) => sum + s.pendingLabourWages, 0);
  const totalReceivedFromEngineers = siteDetails.reduce((sum, s) => sum + s.totalReceivedFromEngineer, 0);
  const totalPendingFromEngineers = siteDetails.reduce((sum, s) => sum + s.pendingFromEngineer, 0);

  return {
    totalFlatCommission,
    totalActiveSites,
    siteDetails,
    totalAllSitesWages,
    totalAllSitesAdvances,
    totalPendingLabourWages,
    totalReceivedFromEngineers,
    totalPendingFromEngineers
  };
}
