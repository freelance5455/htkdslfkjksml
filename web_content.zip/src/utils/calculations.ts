import type {
  AppDataState,
  CommitteeAccount,
  CommitteeTransaction,
  DateFormatOption,
  LeaveRecord,
  LeaveYearOpening,
  LoanPerson,
  LoanTransaction,
  MetricKey,
  PurchaseRecord,
  RateUnit,
} from '../types';

export function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

// ==========================================
// 1. ATTA / PURCHASE CALCULATIONS
// ==========================================
export function calculatePurchaseAmounts(
  rate: number,
  rateUnit: RateUnit,
  quantityMaund: number,
  maundToKg = 40
): { equivalentKg: number; totalAmount: number } {
  const safeRate = Number.isFinite(rate) ? rate : 0;
  const safeQty = Number.isFinite(quantityMaund) ? quantityMaund : 0;
  const safeConv = maundToKg > 0 ? maundToKg : 40;
  const equivalentKg = round2(safeQty * safeConv);
  const totalAmount =
    rateUnit === 'per_maund'
      ? round2(safeRate * safeQty)
      : round2(safeRate * safeQty * safeConv);
  return { equivalentKg, totalAmount };
}

export function summarizePurchases(purchases: PurchaseRecord[], maundToKg = 40) {
  let totalMaund = 0;
  let totalKg = 0;
  let totalAmount = 0;
  for (const p of purchases) {
    totalMaund += p.quantityMaund;
    totalKg += p.quantityMaund * maundToKg;
    totalAmount += p.totalAmount;
  }
  const avgRatePerMaund = totalMaund > 0 ? round2(totalAmount / totalMaund) : 0;
  const avgRatePerKg = totalKg > 0 ? round2(totalAmount / totalKg) : 0;
  return {
    count: purchases.length,
    totalMaund: round2(totalMaund),
    totalKg: round2(totalKg),
    totalAmount: round2(totalAmount),
    avgRatePerMaund,
    avgRatePerKg,
  };
}

// ==========================================
// 2. FACTORY LEAVE MANAGEMENT (JULY–JUNE + 40-DAY FIFO CPL)
// ==========================================
export function getLeaveYearForDate(dateStr: string): string {
  const parts = dateStr.split('-').map(Number);
  if (parts.length < 2 || Number.isNaN(parts[0]) || Number.isNaN(parts[1])) {
    const now = new Date();
    const y = now.getFullYear();
    const m = now.getMonth() + 1;
    return m >= 7 ? `${y}-${y + 1}` : `${y - 1}-${y}`;
  }
  const [year, month] = parts;
  return month >= 7 ? `${year}-${year + 1}` : `${year - 1}-${year}`;
}

export function getLeaveYearBounds(leaveYear: string): { start: string; end: string } {
  const [startYearStr, endYearStr] = leaveYear.split('-');
  const startYear = Number(startYearStr) || new Date().getFullYear();
  const endYear = Number(endYearStr) || startYear + 1;
  return {
    start: `${startYear}-07-01`,
    end: `${endYear}-06-30`,
  };
}

export function addDaysToDate(dateStr: string, days: number): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, (m || 1) - 1, d || 1));
  dt.setUTCDate(dt.getUTCDate() + days);
  return dt.toISOString().slice(0, 10);
}

export interface CplLotStatus {
  id: string;
  dueDate: string;
  expiryDate: string;
  originalDays: number;
  usedDays: number;
  remainingDays: number;
  expiredDays: number;
  isExpired: boolean;
  reason: string;
}

export interface LeaveBalanceSummary {
  leaveYear: string;
  clOpening: number;
  clEntitlement: number;
  clUsed: number;
  clRemaining: number;
  slOpening: number;
  slEntitlement: number;
  slUsed: number;
  slRemaining: number;
  cplOpening: number;
  cplDueTotal: number;
  cplUsedTotal: number;
  cplExpiredTotal: number;
  cplAvail: number;
  totalRemaining: number; // CL + SL + CPL Avail
  cplLots: CplLotStatus[];
}

export function calculateLeaveBalances(
  leaves: LeaveRecord[],
  leaveYear: string,
  openingConfig: LeaveYearOpening | undefined,
  defaultCL = 10,
  defaultSL = 8,
  cplExpiryDays = 40,
  asOfDate?: string
): LeaveBalanceSummary {
  const refDate = asOfDate || new Date().toISOString().slice(0, 10);
  const activeLeaves = leaves.filter(
    (l) => l.leaveYear === leaveYear && l.status !== 'Cancelled'
  );

  const clEntitlement = openingConfig ? openingConfig.clEntitlement : defaultCL;
  const slEntitlement = openingConfig ? openingConfig.slEntitlement : defaultSL;
  const clOpening = openingConfig ? openingConfig.clOpening : 0;
  const slOpening = openingConfig ? openingConfig.slOpening : 0;
  const cplOpening = openingConfig ? openingConfig.cplOpening : 0;

  let clUsed = 0;
  let slUsed = 0;

  const cplDueRecords: LeaveRecord[] = [];
  const cplUsedRecords: LeaveRecord[] = [];

  for (const l of activeLeaves) {
    if (l.type === 'CL') clUsed += l.days;
    else if (l.type === 'SL') slUsed += l.days;
    else if (l.type === 'CPL_DUE') cplDueRecords.push(l);
    else if (l.type === 'CPL_USED') cplUsedRecords.push(l);
  }

  // Build FIFO lots sorted oldest first
  const lots: CplLotStatus[] = [];

  if (cplOpening > 0) {
    const bounds = getLeaveYearBounds(leaveYear);
    lots.push({
      id: `opening-${leaveYear}`,
      dueDate: bounds.start,
      expiryDate: bounds.end,
      originalDays: cplOpening,
      usedDays: 0,
      remainingDays: cplOpening,
      expiredDays: 0,
      isExpired: refDate > bounds.end,
      reason: 'Opening CPL Balance',
    });
  }

  const sortedDue = [...cplDueRecords].sort((a, b) => a.date.localeCompare(b.date));
  for (const d of sortedDue) {
    const exp = d.expiryDate || addDaysToDate(d.date, cplExpiryDays);
    lots.push({
      id: d.id,
      dueDate: d.date,
      expiryDate: exp,
      originalDays: d.days,
      usedDays: 0,
      remainingDays: d.days,
      expiredDays: 0,
      isExpired: false,
      reason: d.reason,
    });
  }

  // Consume CPL_USED chronologically using FIFO on lots valid on usage date
  const sortedUsed = [...cplUsedRecords].sort((a, b) => a.date.localeCompare(b.date));
  let unallocatedUsed = 0;

  for (const usage of sortedUsed) {
    let toConsume = usage.days;
    for (const lot of lots) {
      if (toConsume <= 0) break;
      // Lot must exist on or before usage date (or opening) and not be expired on usage date
      const validOnDate = lot.dueDate <= usage.date && usage.date <= lot.expiryDate;
      if (validOnDate && lot.remainingDays > 0) {
        const take = Math.min(lot.remainingDays, toConsume);
        lot.usedDays = round2(lot.usedDays + take);
        lot.remainingDays = round2(lot.remainingDays - take);
        toConsume = round2(toConsume - take);
      }
    }
    if (toConsume > 0) {
      // Fallback: if admin override allowed usage without matching dated lot, deduct from remaining unexpired lots
      for (const lot of lots) {
        if (toConsume <= 0) break;
        if (lot.remainingDays > 0) {
          const take = Math.min(lot.remainingDays, toConsume);
          lot.usedDays = round2(lot.usedDays + take);
          lot.remainingDays = round2(lot.remainingDays - take);
          toConsume = round2(toConsume - take);
        }
      }
      unallocatedUsed = round2(unallocatedUsed + toConsume);
    }
  }

  // Evaluate expiry as of refDate
  let cplExpiredTotal = 0;
  let cplAvail = 0;
  for (const lot of lots) {
    if (refDate > lot.expiryDate) {
      lot.isExpired = true;
      lot.expiredDays = lot.remainingDays;
      cplExpiredTotal = round2(cplExpiredTotal + lot.expiredDays);
      lot.remainingDays = 0;
    } else {
      lot.isExpired = false;
      cplAvail = round2(cplAvail + lot.remainingDays);
    }
  }

  if (unallocatedUsed > 0) {
    cplAvail = round2(cplAvail - unallocatedUsed);
  }

  const cplDueTotal = round2(cplDueRecords.reduce((s, r) => s + r.days, 0));
  const cplUsedTotal = round2(cplUsedRecords.reduce((s, r) => s + r.days, 0));

  const clRemaining = round2(clOpening + clEntitlement - clUsed);
  const slRemaining = round2(slOpening + slEntitlement - slUsed);
  const totalRemaining = round2(clRemaining + slRemaining + Math.max(0, cplAvail));

  return {
    leaveYear,
    clOpening,
    clEntitlement,
    clUsed: round2(clUsed),
    clRemaining,
    slOpening,
    slEntitlement,
    slUsed: round2(slUsed),
    slRemaining,
    cplOpening,
    cplDueTotal,
    cplUsedTotal,
    cplExpiredTotal,
    cplAvail: round2(cplAvail),
    totalRemaining,
    cplLots: lots,
  };
}

// ==========================================
// 3. PERSONAL LOAN MANAGER (STRICTLY SEPARATE FROM COMMITTEE)
// ==========================================
export interface PersonLoanSummary {
  personId: string;
  personName: string;
  openingBalance: number;
  totalReceived: number;
  totalRepaid: number;
  closingPayable: number; // opening + received - repaid
  txCount: number;
}

export function calculateLoanSummaries(
  persons: LoanPerson[],
  transactions: LoanTransaction[]
): {
  perPerson: PersonLoanSummary[];
  totalOpening: number;
  totalReceived: number;
  totalRepaid: number;
  totalLoanPayable: number;
} {
  const map = new Map<string, PersonLoanSummary>();

  for (const p of persons) {
    map.set(p.id, {
      personId: p.id,
      personName: p.name,
      openingBalance: round2(p.openingBalance || 0),
      totalReceived: 0,
      totalRepaid: 0,
      closingPayable: round2(p.openingBalance || 0),
      txCount: 0,
    });
  }

  for (const tx of transactions) {
    let entry = map.get(tx.personId);
    if (!entry) {
      entry = {
        personId: tx.personId,
        personName: tx.personName,
        openingBalance: 0,
        totalReceived: 0,
        totalRepaid: 0,
        closingPayable: 0,
        txCount: 0,
      };
      map.set(tx.personId, entry);
    }
    if (tx.type === 'received') {
      entry.totalReceived = round2(entry.totalReceived + tx.amount);
    } else {
      entry.totalRepaid = round2(entry.totalRepaid + tx.amount);
    }
    entry.txCount += 1;
    entry.closingPayable = round2(
      entry.openingBalance + entry.totalReceived - entry.totalRepaid
    );
  }

  const perPerson = Array.from(map.values()).sort((a, b) =>
    a.personName.localeCompare(b.personName)
  );

  const totalOpening = round2(perPerson.reduce((s, p) => s + p.openingBalance, 0));
  const totalReceived = round2(perPerson.reduce((s, p) => s + p.totalReceived, 0));
  const totalRepaid = round2(perPerson.reduce((s, p) => s + p.totalRepaid, 0));
  const totalLoanPayable = round2(totalOpening + totalReceived - totalRepaid);

  return {
    perPerson,
    totalOpening,
    totalReceived,
    totalRepaid,
    totalLoanPayable,
  };
}

// ==========================================
// 4. PERSONAL COMMITTEE MANAGER (SEPARATE LEDGER)
// ==========================================
export interface CommitteeSummary {
  committeeId: string;
  title: string;
  personOrGroup: string;
  totalAmount: number;
  installmentAmount: number;
  totalInstallments: number;
  installmentsPaidCount: number;
  installmentsRemainingCount: number;
  totalInstallmentsPaid: number;
  totalPayouts: number;
  remainingBalance: number;
  statusLabel: 'To Pay' | 'Due to Receive' | 'Settled';
  direction: 'payable' | 'receivable';
}

export function calculateCommitteeSummaries(
  committees: CommitteeAccount[],
  transactions: CommitteeTransaction[]
): {
  perCommittee: CommitteeSummary[];
  totalInstallmentsPaid: number;
  totalPayouts: number;
  totalRemainingToPay: number;
  totalDueToReceive: number;
  netBalance: number;
} {
  const perCommittee: CommitteeSummary[] = committees.map((c) => {
    const txs = transactions.filter((t) => t.committeeId === c.id);
    const installmentTxs = txs.filter((t) => t.type === 'Installment');
    const payoutTxs = txs.filter((t) => t.type === 'Payout');

    const totalInstallmentsPaid = round2(
      installmentTxs.reduce((s, t) => s + t.amount, 0)
    );
    const totalPayouts = round2(payoutTxs.reduce((s, t) => s + t.amount, 0));
    const installmentsPaidCount =
      c.installmentAmount > 0
        ? Math.floor((totalInstallmentsPaid + 0.001) / c.installmentAmount)
        : installmentTxs.length;
    const installmentsRemainingCount = Math.max(
      0,
      c.totalInstallments - installmentsPaidCount
    );

    // Remaining commitment = totalAmount - (opening + installments paid)
    const remainingToPay = round2(
      Math.max(0, c.totalAmount - (c.openingBalance + totalInstallmentsPaid))
    );

    // If payout has not been received yet and user has paid installments:
    // For payable direction: user still owes remainingToPay; if user paid more than payout received and all installments done, due to receive.
    let statusLabel: 'To Pay' | 'Due to Receive' | 'Settled' = 'To Pay';
    let remainingBalance = remainingToPay;

    if (c.direction === 'receivable') {
      const due = round2(Math.max(0, c.totalAmount - totalPayouts));
      remainingBalance = due;
      statusLabel = due > 0 ? 'Due to Receive' : 'Settled';
    } else {
      if (remainingToPay > 0) {
        statusLabel = 'To Pay';
        remainingBalance = remainingToPay;
      } else if (totalPayouts < c.totalAmount) {
        statusLabel = 'Due to Receive';
        remainingBalance = round2(c.totalAmount - totalPayouts);
      } else {
        statusLabel = 'Settled';
        remainingBalance = 0;
      }
    }

    return {
      committeeId: c.id,
      title: c.title,
      personOrGroup: c.personOrGroup,
      totalAmount: c.totalAmount,
      installmentAmount: c.installmentAmount,
      totalInstallments: c.totalInstallments,
      installmentsPaidCount,
      installmentsRemainingCount,
      totalInstallmentsPaid,
      totalPayouts,
      remainingBalance,
      statusLabel,
      direction: c.direction,
    };
  });

  const totalInstallmentsPaid = round2(
    perCommittee.reduce((s, c) => s + c.totalInstallmentsPaid, 0)
  );
  const totalPayouts = round2(perCommittee.reduce((s, c) => s + c.totalPayouts, 0));
  const totalRemainingToPay = round2(
    perCommittee
      .filter((c) => c.statusLabel === 'To Pay')
      .reduce((s, c) => s + c.remainingBalance, 0)
  );
  const totalDueToReceive = round2(
    perCommittee
      .filter((c) => c.statusLabel === 'Due to Receive')
      .reduce((s, c) => s + c.remainingBalance, 0)
  );
  const netBalance = round2(totalDueToReceive - totalRemainingToPay);

  return {
    perCommittee,
    totalInstallmentsPaid,
    totalPayouts,
    totalRemainingToPay,
    totalDueToReceive,
    netBalance,
  };
}

// ==========================================
// 5. SAFE FORMULA EVALUATOR (DYNAMIC SETTINGS)
// ==========================================
export function evaluateFormula(
  formula: string,
  values: Record<string, string | number | boolean | string[]>
): number {
  if (!formula || !formula.trim()) return 0;

  // Replace {fieldKey} tokens with numeric values
  const substituted = formula.replace(/\{([a-zA-Z0-9_]+)\}/g, (_, key: string) => {
    const raw = values[key];
    const num = typeof raw === 'number' ? raw : parseFloat(String(raw ?? '0'));
    return Number.isFinite(num) ? String(num) : '0';
  });

  // Tokenize safely (numbers, operators, parentheses)
  const tokens = substituted.match(/(\d+\.?\d*|\.\d+|[+\-*/()])/g);
  if (!tokens || tokens.length === 0) return 0;

  let pos = 0;
  const peek = () => tokens[pos];
  const consume = () => tokens[pos++];

  function parseExpression(): number {
    let left = parseTerm();
    while (peek() === '+' || peek() === '-') {
      const op = consume();
      const right = parseTerm();
      left = op === '+' ? left + right : left - right;
    }
    return left;
  }

  function parseTerm(): number {
    let left = parseFactor();
    while (peek() === '*' || peek() === '/') {
      const op = consume();
      const right = parseFactor();
      if (op === '*') left *= right;
      else left = right === 0 ? 0 : left / right;
    }
    return left;
  }

  function parseFactor(): number {
    const tok = peek();
    if (tok === '+') {
      consume();
      return parseFactor();
    }
    if (tok === '-') {
      consume();
      return -parseFactor();
    }
    if (tok === '(') {
      consume();
      const val = parseExpression();
      if (peek() === ')') consume();
      return val;
    }
    const num = parseFloat(consume() || '0');
    return Number.isFinite(num) ? num : 0;
  }

  try {
    const result = parseExpression();
    return Number.isFinite(result) ? round2(result) : 0;
  } catch {
    return 0;
  }
}

// ==========================================
// 6. FORMATTING & DASHBOARD METRICS
// ==========================================
export function formatCurrency(amount: number, currencyLabel = 'PKR'): string {
  const safe = Number.isFinite(amount) ? amount : 0;
  const formatted = new Intl.NumberFormat('en-PK', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(safe);
  return `${currencyLabel} ${formatted}`;
}

export function formatNumber(n: number): string {
  const safe = Number.isFinite(n) ? n : 0;
  return new Intl.NumberFormat('en-PK', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(safe);
}

const MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function formatDate(dateStr: string, fmt: DateFormatOption = 'DD-MMM-YYYY'): string {
  if (!dateStr) return '—';
  const clean = dateStr.slice(0, 10);
  const parts = clean.split('-');
  if (parts.length !== 3) return dateStr;
  const [y, m, d] = parts;
  if (fmt === 'YYYY-MM-DD') return `${y}-${m}-${d}`;
  if (fmt === 'DD/MM/YYYY') return `${d}/${m}/${y}`;
  const mIdx = Math.max(0, Math.min(11, parseInt(m, 10) - 1));
  return `${d}-${MONTHS_SHORT[mIdx]}-${y}`;
}

export function formatDateTime(isoStr: string, fmt: DateFormatOption = 'DD-MMM-YYYY'): string {
  if (!isoStr) return '—';
  const datePart = formatDate(isoStr.slice(0, 10), fmt);
  const timePart = isoStr.length >= 16 ? isoStr.slice(11, 16) : '';
  return timePart ? `${datePart} ${timePart}` : datePart;
}

export interface ComputedMetricValue {
  label: string;
  formattedValue: string;
  rawValue: number;
  subtext?: string;
}

export function computeDashboardMetric(
  state: AppDataState,
  metricKey: MetricKey
): ComputedMetricValue {
  const { settings } = state;
  const cur = settings.currencyLabel || 'PKR';

  if (metricKey === 'home_expenses') {
    const total = round2(state.expenses.reduce((s, e) => s + e.amount, 0));
    return {
      label: 'Home Expenses',
      formattedValue: formatCurrency(total, cur),
      rawValue: total,
      subtext: `${state.expenses.length} entries`,
    };
  }
  if (metricKey === 'purchase_total_amount') {
    const sum = summarizePurchases(state.purchases, settings.maundToKg);
    return {
      label: 'Atta / Purchase',
      formattedValue: formatCurrency(sum.totalAmount, cur),
      rawValue: sum.totalAmount,
      subtext: `${formatNumber(sum.totalMaund)} Maund (${formatNumber(sum.totalKg)} KG)`,
    };
  }
  if (metricKey === 'purchase_total_maund') {
    const sum = summarizePurchases(state.purchases, settings.maundToKg);
    return {
      label: 'Purchased Maund',
      formattedValue: `${formatNumber(sum.totalMaund)} Maund`,
      rawValue: sum.totalMaund,
      subtext: `Avg ${formatCurrency(sum.avgRatePerMaund, cur)}/Maund`,
    };
  }
  if (metricKey === 'purchase_avg_rate') {
    const sum = summarizePurchases(state.purchases, settings.maundToKg);
    return {
      label: 'Avg Rate / Maund',
      formattedValue: formatCurrency(sum.avgRatePerMaund, cur),
      rawValue: sum.avgRatePerMaund,
      subtext: `${formatNumber(sum.totalMaund)} Maund total`,
    };
  }
  if (metricKey === 'factory_leave_total') {
    const opening = state.leaveYearOpenings.find(
      (o) => o.leaveYear === settings.activeLeaveYear
    );
    const bal = calculateLeaveBalances(
      state.leaves,
      settings.activeLeaveYear,
      opening,
      settings.defaultCL,
      settings.defaultSL,
      settings.cplExpiryDays
    );
    return {
      label: 'Factory Leave Balance',
      formattedValue: formatNumber(bal.totalRemaining),
      rawValue: bal.totalRemaining,
      subtext: `CL ${formatNumber(bal.clRemaining)} · SL ${formatNumber(bal.slRemaining)} · CPL ${formatNumber(bal.cplAvail)}`,
    };
  }
  if (metricKey === 'factory_cpl_avail') {
    const opening = state.leaveYearOpenings.find(
      (o) => o.leaveYear === settings.activeLeaveYear
    );
    const bal = calculateLeaveBalances(
      state.leaves,
      settings.activeLeaveYear,
      opening,
      settings.defaultCL,
      settings.defaultSL,
      settings.cplExpiryDays
    );
    return {
      label: 'CPL Avail',
      formattedValue: formatNumber(bal.cplAvail),
      rawValue: bal.cplAvail,
      subtext: `CPL Due: ${formatNumber(bal.cplDueTotal)}`,
    };
  }
  if (metricKey === 'factory_cpl_due') {
    const opening = state.leaveYearOpenings.find(
      (o) => o.leaveYear === settings.activeLeaveYear
    );
    const bal = calculateLeaveBalances(
      state.leaves,
      settings.activeLeaveYear,
      opening,
      settings.defaultCL,
      settings.defaultSL,
      settings.cplExpiryDays
    );
    return {
      label: 'CPL Due',
      formattedValue: formatNumber(bal.cplDueTotal),
      rawValue: bal.cplDueTotal,
      subtext: `CPL Avail: ${formatNumber(bal.cplAvail)}`,
    };
  }
  if (metricKey === 'office_tasks_open') {
    const open = state.tasks.filter(
      (t) => t.status === 'Pending' || t.status === 'In Progress'
    ).length;
    return {
      label: 'Open Office Tasks',
      formattedValue: formatNumber(open),
      rawValue: open,
      subtext: `${state.tasks.length} total tasks`,
    };
  }
  if (metricKey === 'personal_loan_payable') {
    const loan = calculateLoanSummaries(state.loanPersons, state.loanTransactions);
    return {
      label: 'Personal Loan Payable',
      formattedValue: formatCurrency(loan.totalLoanPayable, cur),
      rawValue: loan.totalLoanPayable,
      subtext: `Rec ${formatCurrency(loan.totalReceived, cur)} · Rep ${formatCurrency(loan.totalRepaid, cur)}`,
    };
  }
  if (metricKey === 'committee_balance') {
    const com = calculateCommitteeSummaries(state.committees, state.committeeTransactions);
    return {
      label: 'Committee Remaining',
      formattedValue: formatCurrency(com.totalRemainingToPay, cur),
      rawValue: com.totalRemainingToPay,
      subtext: `Paid ${formatCurrency(com.totalInstallmentsPaid, cur)} · Due Rec ${formatCurrency(com.totalDueToReceive, cur)}`,
    };
  }
  if (metricKey === 'total_records') {
    const count =
      state.purchases.length +
      state.expenses.length +
      state.leaves.length +
      state.tasks.length +
      state.loanTransactions.length +
      state.committeeTransactions.length +
      state.customRecords.length;
    return {
      label: 'Total Records',
      formattedValue: formatNumber(count),
      rawValue: count,
      subtext: `Across all active ledgers`,
    };
  }
  if (metricKey.startsWith('custom:')) {
    const modId = metricKey.slice(7);
    const mod = state.customModules.find((m) => m.id === modId);
    const recs = state.customRecords.filter((r) => r.moduleId === modId);
    if (!mod) {
      return { label: 'Custom Metric', formattedValue: '0', rawValue: 0 };
    }
    if (mod.summaryFieldKey && mod.summaryAggregation !== 'count') {
      const nums = recs.map((r) => Number(r.values[mod.summaryFieldKey!] || 0));
      const sum = round2(nums.reduce((a, b) => a + b, 0));
      const val =
        mod.summaryAggregation === 'avg' && nums.length > 0
          ? round2(sum / nums.length)
          : sum;
      return {
        label: mod.name,
        formattedValue: formatNumber(val),
        rawValue: val,
        subtext: `${recs.length} records`,
      };
    }
    return {
      label: mod.name,
      formattedValue: formatNumber(recs.length),
      rawValue: recs.length,
      subtext: 'Custom module records',
    };
  }

  return { label: 'Metric', formattedValue: '0', rawValue: 0 };
}
