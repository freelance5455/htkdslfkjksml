import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import type { VocabStore } from '../types';
import {
  buildBlitzQuestion,
  buildMemoryDeck,
  computeWordRainSpeed,
  evaluateRocketState,
  evaluateWordleGuess,
  getBlitzMultiplier,
  mergeWordleKeyStates,
  pickDailyWordleWord,
  pickRocketHintLetter,
} from './arcadeGamesLogic';

const MOCK_STORE: VocabStore = {
  words: [
    { id: 0, band: 'A1', en: 'apple', ar: 'تفاحة' },
    { id: 1, band: 'A1', en: 'water', ar: 'ماء' },
    { id: 2, band: 'A1', en: 'house', ar: 'منزل' },
    { id: 3, band: 'A1', en: 'music', ar: 'موسيقى' },
    { id: 4, band: 'A1', en: 'happy', ar: 'سعيد' },
    { id: 5, band: 'A1', en: 'table', ar: 'طاولة' },
    { id: 6, band: 'A1', en: 'bread', ar: 'خبز' },
    { id: 7, band: 'A1', en: 'smile', ar: 'ابتسامة' },
    { id: 8, band: 'A2', en: 'train', ar: 'قطار' },
    { id: 9, band: 'A2', en: 'airport', ar: 'مطار' },
    { id: 10, band: 'B1', en: 'journey', ar: 'رحلة' },
    { id: 11, band: 'B1', en: 'freedom', ar: 'حرية' },
  ],
  byBand: {
    A0: [],
    A1: [0, 1, 2, 3, 4, 5, 6, 7],
    A2: [8, 9],
    B1: [10, 11],
    B2: [],
    C1: [],
    C2: [],
  },
  normEn: ['apple', 'water', 'house', 'music', 'happy', 'table', 'bread', 'smile', 'train', 'airport', 'journey', 'freedom'],
  normAr: ['تفاحة', 'ماء', 'منزل', 'موسيقى', 'سعيد', 'طاولة', 'خبز', 'ابتسامة', 'قطار', 'مطار', 'رحلة', 'حرية'],
};

describe('arcadeGamesLogic', () => {
  it('evaluates Wordle guesses accurately including duplicate letters', () => {
    // Target: "apple" (two p's). Guess: "paper" -> p(present), a(present), p(correct), e(present), r(absent)
    assert.deepEqual(evaluateWordleGuess('paper', 'apple'), [
      'present',
      'present',
      'correct',
      'present',
      'absent',
    ]);
    // Guess with 3 p's against target "apple" (2 p's): only 2 p's can be green/yellow
    assert.deepEqual(evaluateWordleGuess('ppppp', 'apple'), [
      'absent',
      'correct',
      'correct',
      'absent',
      'absent',
    ]);
    assert.deepEqual(evaluateWordleGuess('apple', 'apple'), [
      'correct',
      'correct',
      'correct',
      'correct',
      'correct',
    ]);
  });

  it('picks deterministic Daily Wordle words and merges keyboard letter states by priority', () => {
    const w1 = pickDailyWordleWord(MOCK_STORE, '2026-11-26');
    const w2 = pickDailyWordleWord(MOCK_STORE, '2026-11-26');
    assert.equal(w1.en, w2.en);
    assert.equal(w1.en.length, 5);

    const k1 = mergeWordleKeyStates({}, 'plane', ['present', 'absent', 'present', 'absent', 'correct']);
    const k2 = mergeWordleKeyStates(k1, 'apple', ['correct', 'correct', 'correct', 'present', 'correct']);
    assert.equal(k2.p, 'correct');
    assert.equal(k2.e, 'correct');
    assert.equal(k2.l, 'present');
  });

  it('scales Speed Blitz multiplier and generates 4 unique options', () => {
    assert.equal(getBlitzMultiplier(0), 1);
    assert.equal(getBlitzMultiplier(3), 2);
    assert.equal(getBlitzMultiplier(6), 3);
    assert.equal(getBlitzMultiplier(10), 5);

    const q = buildBlitzQuestion(MOCK_STORE, 'A1', 99, new Set(), 0);
    assert.equal(q.options.length, 4);
    assert.equal(q.options.filter((o) => o.isCorrect).length, 1);
    assert.equal(new Set(q.options.map((o) => o.label)).size, 4);
  });

  it('builds balanced Memory Flip decks for 6 and 8 pairs', () => {
    const deck12 = buildMemoryDeck(MOCK_STORE, 'ALL', 6, 42);
    assert.equal(deck12.length, 12);
    assert.equal(deck12.filter((c) => c.side === 'en').length, 6);
    assert.equal(deck12.filter((c) => c.side === 'ar').length, 6);

    const deck16 = buildMemoryDeck(MOCK_STORE, 'ALL', 8, 77);
    assert.equal(deck16.length, 16);
  });

  it('tracks Save the Rocket attempts, win/loss state, hints, and Word Rain speed scaling', () => {
    const mid = evaluateRocketState('train', ['t', 'r', 'z', 'x']);
    assert.equal(mid.status, 'playing');
    assert.equal(mid.wrongCount, 2);
    assert.equal(mid.remainingAttempts, 4);
    assert.equal(pickRocketHintLetter('train', ['t', 'r']), 'a');

    const won = evaluateRocketState('train', ['t', 'r', 'a', 'i', 'n']);
    assert.equal(won.status, 'won');

    const lost = evaluateRocketState('train', ['z', 'x', 'q', 'w', 'v', 'b']);
    assert.equal(lost.status, 'lost');

    assert.ok(computeWordRainSpeed(200) > computeWordRainSpeed(0));
    assert.ok(computeWordRainSpeed(9999) <= 23);
  });
});
