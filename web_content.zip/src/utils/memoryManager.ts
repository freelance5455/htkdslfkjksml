import { MemoryItem, JarvisAction, JarvisResponse } from '../types/jarvis';

const STORAGE_KEY = 'JARVIS_SMART_MEMORY_V1';

// Initial default memory seed
export const DEFAULT_MEMORIES: MemoryItem[] = [
  {
    key: 'name',
    label: 'Aapka Naam',
    value: 'Hafiz',
    updatedAt: new Date().toISOString(),
  },
  {
    key: 'location',
    label: 'Shehar / Mulk',
    value: 'Pakistan',
    updatedAt: new Date().toISOString(),
  },
  {
    key: 'assistant_role',
    label: 'Jarvis Ka Kirdaar',
    value: 'Personal Pakistani Android AI Assistant',
    updatedAt: new Date().toISOString(),
  },
];

/**
 * Load memories from persistent storage (localStorage)
 */
export function loadMemoriesFromStorage(): MemoryItem[] {
  if (typeof window === 'undefined') return DEFAULT_MEMORIES;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_MEMORIES));
      return DEFAULT_MEMORIES;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return DEFAULT_MEMORIES;
  } catch (err) {
    console.warn('Could not read memory from storage:', err);
    return DEFAULT_MEMORIES;
  }
}

/**
 * Save memories to persistent storage
 */
export function persistMemoriesToStorage(memories: MemoryItem[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(memories));
  } catch (err) {
    console.warn('Could not save memory to storage:', err);
  }
}

/**
 * Save or insert memory (key-value pair)
 */
export function saveMemory(
  memories: MemoryItem[],
  key: string,
  value: string,
  label?: string
): { updatedMemories: MemoryItem[]; item: MemoryItem } {
  const normalizedKey = key.trim().toLowerCase().replace(/\s+/g, '_');
  const now = new Date().toISOString();

  const friendlyLabel =
    label ||
    (normalizedKey === 'name'
      ? 'Aapka Naam'
      : normalizedKey === 'city' || normalizedKey === 'location'
      ? 'Shehar / Rihaish'
      : normalizedKey === 'preference' || normalizedKey === 'color'
      ? 'Pasandida Cheez'
      : normalizedKey === 'phone'
      ? 'Phone Number'
      : normalizedKey.replace(/_/g, ' '));

  const existingIndex = memories.findIndex((m) => m.key === normalizedKey);
  let updatedMemories: MemoryItem[];
  let item: MemoryItem;

  if (existingIndex >= 0) {
    item = {
      ...memories[existingIndex],
      value: value.trim(),
      updatedAt: now,
    };
    updatedMemories = [...memories];
    updatedMemories[existingIndex] = item;
  } else {
    item = {
      key: normalizedKey,
      label: friendlyLabel,
      value: value.trim(),
      updatedAt: now,
    };
    updatedMemories = [...memories, item];
  }

  persistMemoriesToStorage(updatedMemories);
  return { updatedMemories, item };
}

/**
 * Get memory value by key
 */
export function getMemory(memories: MemoryItem[], key: string): string | null {
  const normalizedKey = key.trim().toLowerCase().replace(/\s+/g, '_');
  const found = memories.find(
    (m) =>
      m.key === normalizedKey ||
      m.key.includes(normalizedKey) ||
      normalizedKey.includes(m.key)
  );
  return found ? found.value : null;
}

/**
 * Update memory
 */
export function updateMemory(
  memories: MemoryItem[],
  key: string,
  value: string
): { updatedMemories: MemoryItem[]; item: MemoryItem | null } {
  const normalizedKey = key.trim().toLowerCase().replace(/\s+/g, '_');
  const existing = memories.find(
    (m) => m.key === normalizedKey || m.key.includes(normalizedKey)
  );

  if (!existing) {
    return { updatedMemories: memories, item: null };
  }

  return saveMemory(memories, existing.key, value, existing.label);
}

/**
 * Delete memory by key
 */
export function deleteMemory(
  memories: MemoryItem[],
  key: string
): { updatedMemories: MemoryItem[]; deleted: MemoryItem | null } {
  const normalizedKey = key.trim().toLowerCase().replace(/\s+/g, '_');
  const target =
    memories.find(
      (m) =>
        m.key === normalizedKey ||
        m.key.includes(normalizedKey) ||
        normalizedKey.includes(m.key)
    ) || null;

  const updatedMemories = memories.filter((m) => m !== target);
  persistMemoriesToStorage(updatedMemories);
  return { updatedMemories, deleted: target };
}

/**
 * Clear all memories
 */
export function clearAllMemories(): MemoryItem[] {
  persistMemoriesToStorage([]);
  return [];
}

/**
 * Convert memories array to key-value record for quick lookups & AI prompt injection
 */
export function getMemoriesRecord(memories: MemoryItem[]): Record<string, string> {
  const record: Record<string, string> = {};
  memories.forEach((m) => {
    record[m.key] = m.value;
  });
  return record;
}

/**
 * Create a context string for prompt injection
 */
export function getMemoryContextString(memories: MemoryItem[]): string {
  if (!memories.length) return 'No personal user memories stored yet.';
  return memories.map((m) => `${m.label} (${m.key}): ${m.value}`).join(' | ');
}

/**
 * Generate human-like, polite Pakistani Urdu greeting using stored memory
 */
export function generateUrduGreeting(memories: MemoryItem[]): string {
  const name = getMemory(memories, 'name');
  if (name) {
    return `Assalam-o-Alaikum ${name}! Mai aapka Jarvis hu. Farmayein, mai aapki kya khidmat kar sakta hu?`;
  }
  return `Assalam-o-Alaikum Sir! Mai aapka Jarvis hu. Farmayein, mai aapki kya madad kar sakta hu?`;
}

/**
 * Parse memory-related natural language commands (Urdu & English)
 * Strictly adheres to Pakistani Urdu phrasing without Hindi words.
 */
export function parseMemoryCommand(
  rawInput: string,
  memories: MemoryItem[]
): JarvisResponse | null {
  const text = rawInput.trim();
  const lower = text.toLowerCase();

  // 1. RECALL: "What is my name?" / "Mera naam kya hai?" / "Do you remember my name?"
  if (
    lower.includes('what is my name') ||
    lower.includes("what's my name") ||
    lower.includes('mera naam kya hai') ||
    lower.includes('mera name kya hai') ||
    lower.includes('kya mera naam yaad hai') ||
    lower.includes('do you remember my name') ||
    lower.includes('tell me my name')
  ) {
    const name = getMemory(memories, 'name');
    if (name) {
      return {
        speechText: `Ji bilkul, aapka naam ${name} hai. Mujhe achi tarah yaad hai.`,
        action: {
          type: 'RECALL_MEMORY',
          payload: { key: 'name', value: name },
        },
      };
    }
    return {
      speechText: `Aap ne abhi tak apna naam mujhe nahi bataya. Aap keh sakte hain: "Mera naam Hafiz hai, yaad rakhna".`,
      action: {
        type: 'RECALL_MEMORY',
        payload: { key: 'name', value: null },
      },
    };
  }

  // 2. RECALL ALL MEMORIES: "What do you remember about me?" / "Mujhe mere bare me kya yaad hai?"
  if (
    lower.includes('what do you remember') ||
    lower.includes('kya yaad hai') ||
    lower.includes('meri memory dikhao') ||
    lower.includes('show memory') ||
    lower.includes('tumhe kya yaad hai')
  ) {
    if (!memories.length) {
      return {
        speechText: `Meri memory me abhi koi maloomat mehfooz nahi hai. Aap mujhe koi bhi cheez yaad rakhne ko keh sakte hain.`,
        action: { type: 'RECALL_MEMORY', payload: { all: true, count: 0 } },
      };
    }

    const itemsSummary = memories
      .map((m) => `${m.label}: ${m.value}`)
      .join(', ');

    return {
      speechText: `Ji, mujhe aapke barey me yeh maloomat yaad hain: ${itemsSummary}.`,
      action: { type: 'RECALL_MEMORY', payload: { all: true, count: memories.length } },
    };
  }

  // 3. STORE NAME: "My name is X, remember this" / "Mera naam X hai, yaad rakhna" / "Remember my name is X"
  const nameStoreMatch =
    text.match(/(?:my name is|mera naam|mera name)\s+([A-Za-z0-9_\-\s]+?)(?:,?\s*(?:remember this|yaad rakhna|save this|store this|yaad rakho|hai yaad rakhna))?$/i) ||
    text.match(/(?:remember that my name is|yaad rakho ke mera naam)\s+([A-Za-z0-9_\-\s]+)/i);

  if (
    (lower.includes('name') || lower.includes('naam')) &&
    (lower.includes('remember') || lower.includes('yaad') || lower.includes('save') || lower.includes('store')) &&
    nameStoreMatch &&
    nameStoreMatch[1]
  ) {
    let extractedName = nameStoreMatch[1]
      .replace(/(?:hai|hai yaad rakhna|please|sir|bhai)/gi, '')
      .trim();

    if (extractedName) {
      return {
        speechText: `Theek hai, mai ne yaad rakh liya hai ke aapka naam ${extractedName} hai.`,
        action: {
          type: 'STORE_MEMORY',
          payload: {
            key: 'name',
            value: extractedName,
            label: 'Aapka Naam',
          },
        },
      };
    }
  }

  // 4. UPDATE NAME: "My new name is X, update it" / "Mera naya naam X hai, update karo"
  const nameUpdateMatch =
    text.match(/(?:my new name is|mera naya naam|mera new name)\s+([A-Za-z0-9_\-\s]+?)(?:,?\s*(?:update it|change it|tabdeel karo|update karo))?$/i);

  if (nameUpdateMatch && nameUpdateMatch[1]) {
    const newName = nameUpdateMatch[1]
      .replace(/(?:hai|please|sir|update it|update karo)/gi, '')
      .trim();

    return {
      speechText: `Ji behtar! Aapka record update kar diya gaya hai. Ab se mai aapko ${newName} pukarunga.`,
      action: {
        type: 'UPDATE_MEMORY',
        payload: {
          key: 'name',
          value: newName,
        },
      },
    };
  }

  // 5. GENERIC REMEMBER: "Remember this: X" / "Save this in your memory: X" / "Yeh yaad rakho: X"
  if (
    lower.startsWith('remember this') ||
    lower.startsWith('save this') ||
    lower.startsWith('store this') ||
    lower.startsWith('yeh yaad rakho') ||
    lower.startsWith('yaad rakhna') ||
    lower.startsWith('memory me save karo')
  ) {
    const content = text
      .replace(/^(?:jarvis\s+)?(?:please\s+)?(?:remember this|save this in your memory|save this|store this information|store this|yeh yaad rakho|yaad rakhna ke|yaad rakho ke|memory me save karo)\s*(?::|that|ke)?\s*/i, '')
      .trim();

    // Try to determine key and value
    let key = 'note';
    let value = content;
    let label = 'Aapki Hidayat / Note';

    if (content.toLowerCase().startsWith('i live in') || content.toLowerCase().includes('shehar')) {
      key = 'location';
      value = content.replace(/^(?:i live in|mera shehar|mai rehta hu)\s*/i, '').trim();
      label = 'Shehar / Rihaish';
    } else if (content.toLowerCase().includes('favorite') || content.toLowerCase().includes('pasand')) {
      key = 'preference';
      label = 'Pasandida Cheez';
    }

    return {
      speechText: `Bohot khoob, mai ne yeh maloomat apni memory me mehfooz kar li hai: "${value}".`,
      action: {
        type: 'STORE_MEMORY',
        payload: { key, value, label },
      },
    };
  }

  // 6. FORGET SPECIFIC MEMORY: "Forget my name" / "Mera naam bhool jao"
  if (
    lower.includes('forget my name') ||
    lower.includes('mera naam bhool jao') ||
    lower.includes('delete my name') ||
    lower.includes('mera naam mita do')
  ) {
    return {
      speechText: `Theek hai, mai ne aapka naam apni memory se mita diya hai.`,
      action: {
        type: 'DELETE_MEMORY',
        payload: { key: 'name' },
      },
    };
  }

  // 7. CLEAR ALL MEMORIES: "Clear memory" / "Forget everything" / "Saari memory saaf kardo"
  if (
    lower === 'clear memory' ||
    lower === 'forget everything' ||
    lower.includes('clear all memory') ||
    lower.includes('saari memory saaf kardo') ||
    lower.includes('sab bhool jao') ||
    lower.includes('reset memory')
  ) {
    return {
      speechText: `Ji behtar! Mai ne saari stored memory clear kar di hai. Ab memory bilkul saaf hai.`,
      action: {
        type: 'CLEAR_MEMORY',
        payload: {},
      },
    };
  }

  return null;
}
