import { PronunciationRule } from '../types/tts';

export const DEFAULT_PRONUNCIATION_RULES: PronunciationRule[] = [
  { id: '1', original: 'AI', replacement: 'ఏ ఐ', enabled: true },
  { id: '2', original: 'technology', replacement: 'టెక్నాలజీ', enabled: true },
  { id: '3', original: 'studio', replacement: 'స్టూడియో', enabled: true },
  { id: '4', original: 'online', replacement: 'ఆన్‌లైన్', enabled: true },
  { id: '5', original: 'mobile', replacement: 'మొబైల్', enabled: true },
  { id: '6', original: 'internet', replacement: 'ఇంటర్నెట్', enabled: true },
  { id: '7', original: 'computer', replacement: 'కంప్యూటర్', enabled: true },
  { id: '8', original: 'app', replacement: 'యాప్', enabled: true },
  { id: '9', original: 'software', replacement: 'సాఫ్ట్‌వేర్', enabled: true },
  { id: '10', original: 'YouTube', replacement: 'యూట్యూబ్', enabled: true },
  { id: '11', original: 'Google', replacement: 'గూగుల్', enabled: true },
  { id: '12', original: 'video', replacement: 'వీడియో', enabled: true },
  { id: '13', original: 'audio', replacement: 'ఆడియో', enabled: true },
  { id: '14', original: 'podcast', replacement: 'పాడ్‌కాస్ట్', enabled: true },
  { id: '15', original: 'CM', replacement: 'ముఖ్యమంత్రి', enabled: true },
  { id: '16', original: 'PM', replacement: 'ప్రధానమంత్రి', enabled: true },
  { id: '17', original: 'CEO', replacement: 'సి ఈ ఓ', enabled: true },
  { id: '18', original: 'doctor', replacement: 'డాక్టర్', enabled: true },
  { id: '19', original: '5G', replacement: 'ఫైవ్ జీ', enabled: true },
  { id: '20', original: 'COVID', replacement: 'కోవిడ్', enabled: true },
];

export function applyPronunciationRules(text: string, rules: PronunciationRule[]): string {
  let result = text;
  const activeRules = rules.filter((r) => r.enabled && r.original.trim() && r.replacement.trim());

  for (const rule of activeRules) {
    if (rule.isRegex) {
      try {
        const regex = new RegExp(rule.original, 'gi');
        result = result.replace(regex, rule.replacement);
      } catch {
        // Fallback to simple replace
        result = result.split(rule.original).join(rule.replacement);
      }
    } else {
      // Escape special chars for safe word-boundary matching
      const escaped = rule.original.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(`\\b${escaped}\\b`, 'gi');
      result = result.replace(regex, rule.replacement);
    }
  }

  return result;
}
