const SENTENCE_STOP_WORDS = new Set([
  'a', 'an', 'the', 'i', 'you', 'he', 'she', 'it', 'we', 'they',
  'me', 'him', 'her', 'us', 'them', 'my', 'your', 'his', 'its', 'our', 'their',
  'mine', 'yours', 'hers', 'ours', 'theirs', 'myself', 'yourself', 'himself', 'herself',
  'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
  'do', 'does', 'did', 'done', 'doing',
  'have', 'has', 'had', 'having',
  'will', 'would', 'shall', 'should', 'can', 'could', 'may', 'might', 'must',
  'to', 'of', 'in', 'on', 'at', 'by', 'for', 'with', 'about', 'against', 'between',
  'into', 'through', 'during', 'before', 'after', 'above', 'below', 'from', 'up', 'down',
  'out', 'off', 'over', 'under', 'again', 'further', 'then', 'once',
  'and', 'but', 'or', 'nor', 'so', 'yet', 'if', 'because', 'as', 'until', 'while', 'than',
  'this', 'that', 'these', 'those', 'here', 'there', 'where', 'when', 'why', 'how',
  'what', 'which', 'who', 'whom', 'whose',
  'not', 'no', 'yes', 'very', 'just', 'only', 'also', 'too', 'really', 'quite', 'much', 'many',
  'some', 'any', 'all', 'both', 'each', 'few', 'more', 'most', 'other', 'such', 'own', 'same',
  'now', 'well', 'please', 'okay', 'ok', 'oh', 'hey', 'hi', 'let', 'lets', 'got', 'get',
  'im', 'ive', 'ill', 'id', 'youre', 'youve', 'youll', 'hes', 'shes', 'its', 'were', 'theyre',
  'dont', 'doesnt', 'didnt', 'isnt', 'arent', 'wasnt', 'werent', 'wont', 'cant', 'couldnt',
  'shouldnt', 'wouldnt', 'havent', 'hasnt', 'hadnt', 'thats', 'theres', 'whats',
]);

const CONTRACTION_EXPANSIONS: Record<string, string> = {
  "i'm": 'i am',
  "i've": 'i have',
  "i'll": 'i will',
  "i'd": 'i would',
  "you're": 'you are',
  "you've": 'you have',
  "you'll": 'you will',
  "you'd": 'you would',
  "he's": 'he is',
  "he'll": 'he will',
  "he'd": 'he would',
  "she's": 'she is',
  "she'll": 'she will',
  "she'd": 'she would',
  "it's": 'it is',
  "it'll": 'it will',
  "we're": 'we are',
  "we've": 'we have',
  "we'll": 'we will',
  "we'd": 'we would',
  "they're": 'they are',
  "they've": 'they have',
  "they'll": 'they will',
  "they'd": 'they would',
  "aren't": 'are not',
  "isn't": 'is not',
  "wasn't": 'was not',
  "weren't": 'were not',
  "don't": 'do not',
  "doesn't": 'does not',
  "didn't": 'did not',
  "can't": 'cannot',
  "cannot": 'can not',
  "won't": 'will not',
  "wouldn't": 'would not',
  "shouldn't": 'should not',
  "couldn't": 'could not',
  "mustn't": 'must not',
  "haven't": 'have not',
  "hasn't": 'has not',
  "hadn't": 'had not',
  "that's": 'that is',
  "there's": 'there is',
  "here's": 'here is',
  "what's": 'what is',
  "who's": 'who is',
  "where's": 'where is',
  "when's": 'when is',
  "why's": 'why is',
  "how's": 'how is',
  "let's": 'let us',
  "ain't": 'am not',
};

export function expandContractions(text: string): string {
  const normalized = (text || '').replace(/[’`]/g, "'");
  return normalized.replace(/\b[A-Za-z]+'[A-Za-z]+\b/g, (match) => {
    const expanded = CONTRACTION_EXPANSIONS[match.toLowerCase()];
    return expanded || match;
  });
}

export interface SentenceVideoTargets {
  primaryQuery: string;
  keywords: string[];
  cleanSentence: string;
}

/**
 * Extracts ranked, real-speech video search targets from an English sentence.
 * Expands contractions first and filters weak function/stop words so `/api/word-clips`
 * always receives clean searchable English words even for short contraction phrases.
 */
export function extractSentenceVideoTargets(rawSentence: string): SentenceVideoTargets {
  const cleanSentence = (rawSentence || '').split('=')[0].replace(/\s+/g, ' ').trim();
  if (!cleanSentence) {
    return { primaryQuery: '', keywords: [], cleanSentence: '' };
  }

  const expandedSentence = expandContractions(cleanSentence);

  const rawTokens = expandedSentence
    .replace(/[“”"()[\]{}.,!?;:/\\]/g, ' ')
    .split(/\s+/)
    .map((t) => t.replace(/^'+|'+$/g, '').trim())
    .filter(Boolean);

  const seen = new Set<string>();
  const contentWords: Array<{ word: string; score: number; index: number }> = [];

  rawTokens.forEach((token, idx) => {
    const lower = token.toLowerCase();
    const alphaOnly = lower.replace(/[^a-z-]/g, '');
    if (alphaOnly.length < 3) return;
    if (SENTENCE_STOP_WORDS.has(alphaOnly)) return;
    if (seen.has(alphaOnly)) return;
    seen.add(alphaOnly);

    // Prefer rich content words (4–11 letters are ideal for real-speech TED corpus matches)
    let score = Math.min(alphaOnly.length, 10);
    if (alphaOnly.length >= 5 && alphaOnly.length <= 10) score += 3;
    if (alphaOnly.length > 13) score -= 2; // ultra-rare long words have fewer clips
    contentWords.push({ word: alphaOnly, score, index: idx });
  });

  // Sort by informativeness descending, keeping sentence order for ties
  contentWords.sort((a, b) => b.score - a.score || a.index - b.index);

  let keywords = contentWords.slice(0, 5).map((item) => item.word);

  // Fallback for very short sentences made mostly of common/expanded contraction words
  // (e.g. "I'm fine" -> ["fine"], "Aren't you?" -> ["are", "you", "not"], "I'm here" -> ["here", "am"])
  if (keywords.length === 0) {
    const fallbackSeen = new Set<string>();
    const preferredAux = ['are', 'am', 'is', 'do', 'can', 'will', 'have', 'not', 'here', 'there', 'how', 'what', 'who', 'why', 'when', 'where'];
    keywords = rawTokens
      .map((t) => t.toLowerCase().replace(/[^a-z]/g, ''))
      .filter((w) => {
        if (w.length < 2 || fallbackSeen.has(w)) return false;
        fallbackSeen.add(w);
        return true;
      })
      .sort((a, b) => {
        const aPref = preferredAux.includes(a) ? 2 : 0;
        const bPref = preferredAux.includes(b) ? 2 : 0;
        return (b.length + bPref) - (a.length + aPref);
      })
      .slice(0, 3);
  }

  const primaryQuery = keywords[0] || '';
  return {
    primaryQuery,
    keywords,
    cleanSentence,
  };
}
