export interface ParsedCsvResult {
  headers: string[];
  rows: Record<string, string>[];
  rawRows: string[][];
  totalCount: number;
}

export interface ValidationError {
  rowNumber: number;
  field: string;
  value: string;
  reason: string;
}

export function parseCsv(content: string): ParsedCsvResult {
  const lines: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < content.length; i++) {
    const char = content[i];
    if (char === '"') {
      if (inQuotes && content[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if ((char === '\r' || char === '\n') && !inQuotes) {
      if (char === '\r' && content[i + 1] === '\n') {
        i++;
      }
      if (current.trim().length > 0) {
        lines.push(current);
      }
      current = '';
    } else {
      current += char;
    }
  }
  if (current.trim().length > 0) {
    lines.push(current);
  }

  if (lines.length === 0) {
    return { headers: [], rows: [], rawRows: [], totalCount: 0 };
  }

  const parseLine = (line: string): string[] => {
    const fields: string[] = [];
    let field = '';
    let inQ = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"') {
        if (inQ && line[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQ = !inQ;
        }
      } else if (c === ',' && !inQ) {
        fields.push(field.trim());
        field = '';
      } else {
        field += c;
      }
    }
    fields.push(field.trim());
    return fields;
  };

  const headers = parseLine(lines[0]);
  const rawRows: string[][] = [];
  const rows: Record<string, string>[] = [];

  for (let idx = 1; idx < lines.length; idx++) {
    const rowFields = parseLine(lines[idx]);
    if (rowFields.length === 0 || (rowFields.length === 1 && rowFields[0] === '')) continue;
    rawRows.push(rowFields);
    const rowObj: Record<string, string> = {};
    headers.forEach((h, hIdx) => {
      rowObj[h] = rowFields[hIdx] ?? '';
    });
    rows.push(rowObj);
  }

  return {
    headers,
    rows,
    rawRows,
    totalCount: rows.length,
  };
}

export function generateEmployeeCsvTemplate(): string {
  const headers = [
    'EmployeeCode',
    'FullName',
    'Email',
    'Phone',
    'Department',
    'Designation',
    'Territory',
    'ManagerName',
    'EmergencyContact',
    'JoiningDate',
  ];
  const sampleRow1 = [
    'EMP-1001',
    'Alex Rivers',
    'alex.rivers@example.com',
    '+1 555-0199',
    'Field Operations',
    'Senior Technician',
    'North Metro',
    'Operations Lead',
    '+1 555-0100',
    '2024-01-15',
  ];
  const sampleRow2 = [
    'EMP-1002',
    'Sara Chen',
    'sara.chen@example.com',
    '+1 555-0211',
    'Installation',
    'Field Engineer',
    'Downtown East',
    'Operations Lead',
    '+1 555-0200',
    '2024-03-01',
  ];

  return [headers.join(','), sampleRow1.join(','), sampleRow2.join(',')].join('\n');
}

export function exportToCsv(filename: string, headers: string[], dataRows: string[][]) {
  const escapeCell = (cell: string) => {
    if (cell.includes(',') || cell.includes('"') || cell.includes('\n')) {
      return `"${cell.replace(/"/g, '""')}"`;
    }
    return cell;
  };

  const lines = [
    headers.map(escapeCell).join(','),
    ...dataRows.map((r) => r.map((c) => escapeCell(c ?? '')).join(',')),
  ];
  const csvContent = lines.join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
