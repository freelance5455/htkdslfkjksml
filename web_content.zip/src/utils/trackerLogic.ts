import {
  BacklogItem,
  MaterialStatus,
  StartedChaptersStore,
  StatusStore,
  StreakData,
  SubItemStore,
  TestResult,
  TestSeries,
  TestStore,
  SubjectKey,
} from '../types';
import {
  ALL_TEST_SERIES,
  CHAPTER_MIGRATION_MAP,
  INORGANIC_CHEM_CHAPTERS,
  INORGANIC_CHEM_MATERIALS,
  SEED_TEST_RESULTS,
  SUBJECT_CONFIGS,
  SUBJECT_KEYS,
} from '../data/batchData';

export function makeStatusKey(subject: string, chapter: string, material: string): string {
  return `${subject}|${chapter}|${material}`;
}

export function parseStatusKey(key: string): { subject: string; chapter: string; material: string } | null {
  const parts = key.split('|');
  if (parts.length < 3) return null;
  return {
    subject: parts[0],
    chapter: parts.slice(1, -1).join('|'),
    material: parts[parts.length - 1],
  };
}

export function isChapterStarted(
  startedStore: StartedChaptersStore,
  subject: string,
  chapter: string
): boolean {
  return !!(startedStore[subject] && startedStore[subject].includes(chapter));
}

export function getChapterBaseMaterials(subject: SubjectKey | string, chapter?: string): string[] {
  const config = SUBJECT_CONFIGS[subject as SubjectKey];
  if (!config) return [];
  if (subject === 'chem' && chapter && INORGANIC_CHEM_CHAPTERS.includes(chapter)) {
    return INORGANIC_CHEM_MATERIALS;
  }
  return config.materials;
}

export function getChapterMaterials(subject: SubjectKey | string, chapter?: string): string[] {
  const base = getChapterBaseMaterials(subject, chapter);
  if (base.length === 0) return [];
  return ['Lectures', ...base];
}

export function getAllSubjectMaterials(subject: SubjectKey | string): string[] {
  const config = SUBJECT_CONFIGS[subject as SubjectKey];
  if (!config) return [];
  const unique = new Set<string>(['Lectures', ...config.materials]);
  if (subject === 'chem') {
    INORGANIC_CHEM_MATERIALS.forEach((m) => unique.add(m));
  }
  return Array.from(unique);
}

export function getMaterialProgress(
  subject: string,
  chapter: string,
  material: string,
  statusStore: StatusStore,
  subItemStore: SubItemStore = {}
): {
  status: MaterialStatus;
  fraction: number;
  doneSubCount: number;
  totalSubCount: number;
} {
  const rawStatus = statusStore[makeStatusKey(subject, chapter, material)] || 'pending';
  const subItems = subItemStore?.[subject]?.[chapter]?.[material] || [];

  if (subItems.length > 0) {
    const doneSubCount = subItems.filter((x) => x.done).length;
    const totalSubCount = subItems.length;
    if (doneSubCount === totalSubCount || rawStatus === 'done') {
      return {
        status: 'done',
        fraction: 1,
        doneSubCount: totalSubCount,
        totalSubCount,
      };
    }
    if (doneSubCount > 0) {
      return {
        status: 'partial',
        fraction: doneSubCount / totalSubCount,
        doneSubCount,
        totalSubCount,
      };
    }
    if (rawStatus === 'partial') {
      return {
        status: 'partial',
        fraction: 0.5,
        doneSubCount: 0,
        totalSubCount,
      };
    }
    return {
      status: 'pending',
      fraction: 0,
      doneSubCount: 0,
      totalSubCount,
    };
  }

  if (rawStatus === 'done') {
    return { status: 'done', fraction: 1, doneSubCount: 0, totalSubCount: 0 };
  }
  if (rawStatus === 'partial') {
    return { status: 'partial', fraction: 0.5, doneSubCount: 0, totalSubCount: 0 };
  }
  return { status: 'pending', fraction: 0, doneSubCount: 0, totalSubCount: 0 };
}

export function calculateSubjectStats(
  subject: string,
  statusStore: StatusStore,
  startedStore: StartedChaptersStore,
  subItemStore: SubItemStore = {}
): {
  done: number;
  partial: number;
  pending: number;
  total: number;
  percent: number;
  progressUnits: number;
} {
  const config = SUBJECT_CONFIGS[subject as keyof typeof SUBJECT_CONFIGS];
  if (!config) {
    return { done: 0, partial: 0, pending: 0, total: 0, percent: 0, progressUnits: 0 };
  }

  let done = 0;
  let partial = 0;
  let pending = 0;
  let total = 0;
  let progressUnits = 0;

  config.chapters.forEach((chapter) => {
    if (!isChapterStarted(startedStore, subject, chapter)) return;
    const chapterMaterials = getChapterMaterials(subject, chapter);
    chapterMaterials.forEach((material) => {
      total++;
      const mp = getMaterialProgress(subject, chapter, material, statusStore, subItemStore);
      progressUnits += mp.fraction;
      if (mp.status === 'done') done++;
      else if (mp.status === 'partial') partial++;
      else pending++;
    });
  });

  const rawPercent = total > 0 ? (progressUnits / total) * 100 : 0;
  const percent =
    rawPercent > 0 && rawPercent < 1 ? 1 : Math.min(100, Math.round(rawPercent));
  return { done, partial, pending, total, percent, progressUnits };
}

export function getSubjectChapterProgress(
  subjKey: SubjectKey,
  startedStore: StartedChaptersStore,
  statusStore: StatusStore,
  subItemStore: SubItemStore = {}
): { percent: number; completedChapters: number; totalChapters: number; activeChapters: number } {
  const cfg = SUBJECT_CONFIGS[subjKey];
  if (!cfg) {
    return { percent: 0, completedChapters: 0, totalChapters: 0, activeChapters: 0 };
  }
  const totalChapters = cfg.chapters.length;
  let completedChapters = 0;
  let activeChapters = 0;
  let totalProgressUnits = 0;

  cfg.chapters.forEach((ch) => {
    if (isChapterStarted(startedStore, subjKey, ch)) {
      const chapterMaterials = getChapterMaterials(subjKey, ch);
      let chUnits = 0;
      let doneMats = 0;
      chapterMaterials.forEach((m) => {
        const mp = getMaterialProgress(subjKey, ch, m, statusStore, subItemStore);
        chUnits += mp.fraction;
        if (mp.status === 'done') doneMats++;
      });

      const chRatio = chUnits / (chapterMaterials.length || 1);
      totalProgressUnits += chRatio;

      if (doneMats === chapterMaterials.length) {
        completedChapters += 1;
      } else {
        activeChapters += 1;
      }
    }
  });

  const rawPercent = totalChapters > 0 ? (totalProgressUnits / totalChapters) * 100 : 0;
  const percent =
    rawPercent > 0 && rawPercent < 1 ? 1 : Math.min(100, Math.round(rawPercent));
  return { percent, completedChapters, totalChapters, activeChapters };
}

export function calculateOverallStats(
  statusStore: StatusStore,
  startedStore: StartedChaptersStore,
  subItemStore: SubItemStore = {}
): {
  done: number;
  partial: number;
  total: number;
  percent: number;
  progressUnits: number;
  startedChapters: number;
  totalChapters: number;
} {
  let done = 0;
  let partial = 0;
  let total = 0;
  let progressUnits = 0;
  let startedChapters = 0;
  let totalChapters = 0;

  SUBJECT_KEYS.forEach((subj) => {
    const config = SUBJECT_CONFIGS[subj];
    totalChapters += config.chapters.length;

    config.chapters.forEach((chapter) => {
      if (isChapterStarted(startedStore, subj, chapter)) {
        startedChapters++;
        const chapterMaterials = getChapterMaterials(subj, chapter);
        chapterMaterials.forEach((material) => {
          total++;
          const mp = getMaterialProgress(subj, chapter, material, statusStore, subItemStore);
          progressUnits += mp.fraction;
          if (mp.status === 'done') done++;
          else if (mp.status === 'partial') partial++;
        });
      }
    });
  });

  const rawPercent = total > 0 ? (progressUnits / total) * 100 : 0;
  const percent =
    rawPercent > 0 && rawPercent < 1 ? 1 : Math.min(100, Math.round(rawPercent));
  return { done, partial, total, percent, progressUnits, startedChapters, totalChapters };
}

export function getCompletedChaptersCount(
  statusStore: StatusStore,
  startedStore: StartedChaptersStore,
  subItemStore: SubItemStore = {}
): { done: number; started: number } {
  let done = 0;
  let started = 0;

  SUBJECT_KEYS.forEach((subj) => {
    const config = SUBJECT_CONFIGS[subj];
    config.chapters.forEach((chapter) => {
      if (!isChapterStarted(startedStore, subj, chapter)) return;
      started++;
      const chapterMaterials = getChapterMaterials(subj, chapter);
      const allDone = chapterMaterials.every(
        (mat) => getMaterialProgress(subj, chapter, mat, statusStore, subItemStore).status === 'done'
      );
      if (allDone) done++;
    });
  });

  return { done, started };
}

export function calculateDaysLeft(targetDateStr: string = '2027-05-04', today: Date = new Date()): number {
  const target = new Date(targetDateStr + 'T00:00:00');
  const now = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const diff = Math.ceil((target.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  return Math.max(0, diff);
}

export function getTodayDateString(d: Date = new Date()): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getYesterdayDateString(d: Date = new Date()): string {
  const y = new Date(d.getTime() - 24 * 60 * 60 * 1000);
  return getTodayDateString(y);
}

export function updateStreak(currentStreak: StreakData | null, today: Date = new Date()): StreakData {
  const t = getTodayDateString(today);
  const y = getYesterdayDateString(today);

  if (!currentStreak || !currentStreak.d) {
    return { d: t, n: 1 };
  }

  if (currentStreak.d === t) {
    return currentStreak;
  }

  if (currentStreak.d === y) {
    return { d: t, n: (currentStreak.n || 0) + 1 };
  }

  return { d: t, n: 1 };
}

export function getActiveStreakCount(currentStreak: StreakData | null, today: Date = new Date()): number {
  if (!currentStreak || !currentStreak.d) return 0;
  const t = getTodayDateString(today);
  const y = getYesterdayDateString(today);
  if (currentStreak.d === t || currentStreak.d === y) {
    return currentStreak.n || 0;
  }
  return 0;
}

export function calculateDaysDifference(testDateStr: string, todayDateStr: string = getTodayDateString()): number {
  const testDate = new Date(testDateStr + 'T00:00:00');
  const today = new Date(todayDateStr + 'T00:00:00');
  return Math.round((testDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

export function formatRelativeDate(testDateStr: string, todayDateStr: string = getTodayDateString()): string {
  const diff = calculateDaysDifference(testDateStr, todayDateStr);
  if (diff === 0) return 'today';
  if (diff > 0) return `in ${diff}d`;
  return `${Math.abs(diff)}d ago`;
}

export function formatDisplayDate(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: '2-digit' });
}

export function getTestDetails(testKey: string, userStore: TestStore): TestResult {
  return Object.assign({}, SEED_TEST_RESULTS[testKey] || {}, userStore[testKey] || {});
}

export function calculateSeriesStats(
  series: TestSeries,
  userStore: TestStore,
  todayStr: string = getTodayDateString()
): { attempted: number; missed: number; total: number; avg: number | '—'; best: number | '—' } {
  let attempted = 0;
  let missed = 0;
  let sum = 0;
  let scoreCount = 0;
  let best = -Infinity;

  series.list.forEach((test) => {
    const res = getTestDetails(test.k, userStore);
    if (!res.s) {
      if (calculateDaysDifference(test.d, todayStr) < 0) {
        missed++;
      }
      return;
    }

    attempted++;
    const totalScore = parseFloat(String(res.t));
    if (!isNaN(totalScore)) {
      sum += totalScore;
      scoreCount++;
      if (totalScore > best) best = totalScore;
    }
  });

  return {
    attempted,
    missed,
    total: series.list.length,
    avg: scoreCount > 0 ? Math.round(sum / scoreCount) : '—',
    best: scoreCount > 0 ? best : '—',
  };
}

export function getMaterialPriority(material: string): {
  tier: 1 | 2 | 3;
  rank: number;
  label: string;
} {
  // Tier 1: Lectures -> DPP -> KPP Practice Sheet (Physics)
  if (material === 'Lectures') {
    return { tier: 1, rank: 1, label: 'Tier 1' };
  }
  if (material === 'DPP') {
    return { tier: 1, rank: 2, label: 'Tier 1' };
  }
  if (material === 'KPP Practice Sheet') {
    return { tier: 1, rank: 3, label: 'Tier 1' };
  }

  // Tier 2: Class Questions -> Red Sheet / Goat Sheet -> Question Practice Lecture -> NEET PYQs / Most Expected Questions -> Missed Tests
  if (material === 'Class Questions') {
    return { tier: 2, rank: 4, label: 'Tier 2' };
  }
  if (material === 'Red Sheet (Tulki Mam)' || material === 'Goat Sheet by Om Pandey') {
    return { tier: 2, rank: 5, label: 'Tier 2' };
  }
  if (material === 'Question Practice Lecture') {
    return { tier: 2, rank: 6, label: 'Tier 2' };
  }
  if (
    material === 'KPP NEET PYQ' ||
    material === 'PYQ Practice Sheet' ||
    material === 'Motikitab NEET' ||
    material === 'Most Expected Questions by Om Pandey'
  ) {
    return { tier: 2, rank: 7, label: 'Tier 2' };
  }
  if (material === 'Test') {
    return { tier: 2, rank: 8, label: 'Tier 2' };
  }

  // Tier 3: Kattar -> Module -> NBT -> JEE Mains
  if (material === 'Kattar Practice Sheet' || material === 'Kattar') {
    return { tier: 3, rank: 9, label: 'Tier 3' };
  }
  if (material === 'Module') {
    return { tier: 3, rank: 10, label: 'Tier 3' };
  }
  if (material === 'NBT') {
    return { tier: 3, rank: 11, label: 'Tier 3' };
  }
  if (material === 'KPP JEE Mains' || material === 'Motikitab JEE Mains') {
    return { tier: 3, rank: 12, label: 'Tier 3' };
  }

  return { tier: 3, rank: 13, label: 'Tier 3' };
}

export function formatSubItemDisplayName(
  material: string,
  subName: string | undefined,
  idx: number
): string {
  const trimmed = (subName || '').trim();
  if (material === 'Lectures') {
    if (!trimmed) return `Lecture ${idx + 1}`;
    if (/^\d+$/.test(trimmed)) return `Lecture ${trimmed}`;
    // Strip any accidental "of N" or "out of N" suffix
    return trimmed.replace(/\s+(?:out\s+)?of\s+\d+.*$/i, '').trim();
  }

  if (!trimmed) return `${material} ${idx + 1}`;
  if (/^\d+$/.test(trimmed)) return `${material} ${trimmed}`;
  if (
    trimmed.toLowerCase().startsWith(material.toLowerCase()) ||
    trimmed.toLowerCase().includes(material.toLowerCase())
  ) {
    return trimmed;
  }
  return `${material} · ${trimmed}`;
}

export function getBacklogItems(
  statusStore: StatusStore,
  subItemStore: SubItemStore,
  startedStore: StartedChaptersStore,
  testStore: TestStore,
  todayStr: string = getTodayDateString()
): BacklogItem[] {
  const items: Array<BacklogItem & { _isPartial?: boolean; _order: number }> = [];
  let orderCounter = 0;

  // 1. Chapters & Materials
  SUBJECT_KEYS.forEach((subj) => {
    const config = SUBJECT_CONFIGS[subj];
    config.chapters.forEach((chapter) => {
      if (!isChapterStarted(startedStore, subj, chapter)) return;

      // Check Lectures
      const lecturePrio = getMaterialPriority('Lectures');
      const lectures = subItemStore[subj]?.[chapter]?.['Lectures'] || [];
      if (lectures.length > 0) {
        const someWatched = lectures.some((l) => l.done);
        lectures.forEach((lec, idx) => {
          if (!lec.done) {
            items.push({
              id: `${subj}|${chapter}|L|${idx}`,
              g: 'L',
              t: 'L',
              s: subj,
              c: chapter,
              m: 'Lectures',
              i: idx,
              ic: '🎬',
              kd: 'Lecture',
              d: formatSubItemDisplayName('Lectures', lec.name, idx),
              priorityTier: lecturePrio.tier,
              priorityRank: lecturePrio.rank,
              priorityLabel: lecturePrio.label,
              _isPartial: someWatched,
              _order: orderCounter++,
            });
          }
        });
      } else {
        const val = statusStore[makeStatusKey(subj, chapter, 'Lectures')] || 'pending';
        if (val !== 'done') {
          items.push({
            id: `${subj}|${chapter}|L0`,
            g: 'L',
            t: 'L0',
            s: subj,
            c: chapter,
            m: 'Lectures',
            ic: '🎬',
            kd: 'Lecture',
            d: 'Lectures',
            priorityTier: lecturePrio.tier,
            priorityRank: lecturePrio.rank,
            priorityLabel: lecturePrio.label,
            _isPartial: val === 'partial',
            _order: orderCounter++,
          });
        }
      }

      // Check Materials
      const chapterBaseMaterials = getChapterBaseMaterials(subj, chapter);
      chapterBaseMaterials.forEach((mat) => {
        const matPrio = getMaterialPriority(mat);
        const subItems = subItemStore[subj]?.[chapter]?.[mat] || [];
        const val = statusStore[makeStatusKey(subj, chapter, mat)] || 'pending';

        if (subItems.length > 0) {
          const someDone = subItems.some((s) => s.done);
          subItems.forEach((sub, idx) => {
            if (!sub.done) {
              items.push({
                id: `${subj}|${chapter}|${mat}|${idx}`,
                g: 'M',
                t: 'C',
                s: subj,
                c: chapter,
                m: mat,
                i: idx,
                ic: '📚',
                kd: 'Material',
                d: formatSubItemDisplayName(mat, sub.name, idx),
                priorityTier: matPrio.tier,
                priorityRank: matPrio.rank,
                priorityLabel: matPrio.label,
                _isPartial: someDone,
                _order: orderCounter++,
              });
            }
          });
        } else if (val !== 'done') {
          items.push({
            id: `${subj}|${chapter}|${mat}`,
            g: 'M',
            t: 'M',
            s: subj,
            c: chapter,
            m: mat,
            ic: '📚',
            kd: 'Material',
            d: mat,
            priorityTier: matPrio.tier,
            priorityRank: matPrio.rank,
            priorityLabel: matPrio.label,
            _isPartial: val === 'partial',
            _order: orderCounter++,
          });
        }
      });
    });
  });

  // 2. Tests
  const testPrio = getMaterialPriority('Test');
  ALL_TEST_SERIES.forEach((series) => {
    series.list.forEach((test) => {
      const isPast = calculateDaysDifference(test.d, todayStr) < 0;
      const res = getTestDetails(test.k, testStore);
      if (isPast && !res.s) {
        const daysAgo = Math.abs(calculateDaysDifference(test.d, todayStr));
        items.push({
          id: `T|${test.k}`,
          g: 'T',
          t: 'T',
          s: series.name,
          c: test.n,
          k: test.k,
          ic: '📝',
          kd: 'Test',
          d: `Missed ${daysAgo}d ago (${formatDisplayDate(test.d)})`,
          priorityTier: testPrio.tier,
          priorityRank: testPrio.rank,
          priorityLabel: testPrio.label,
          _isPartial: false,
          _order: orderCounter++,
        });
      }
    });
  });

  // Sort by priorityRank ascending, then partial (in-progress) before pending, then insertion order
  items.sort((a, b) => {
    if (a.priorityRank !== b.priorityRank) {
      return a.priorityRank - b.priorityRank;
    }
    if (Boolean(a._isPartial) !== Boolean(b._isPartial)) {
      return a._isPartial ? -1 : 1;
    }
    return a._order - b._order;
  });

  return items.map(({ _isPartial, _order, ...clean }) => clean);
}

export function migrateChapterData(
  statusStore: StatusStore,
  subItemStore: SubItemStore,
  startedStore: StartedChaptersStore
): { statusStore: StatusStore; subItemStore: SubItemStore; startedStore: StartedChaptersStore } {
  const newStatus: StatusStore = {};
  const newSubItems: SubItemStore = {};
  const newStarted: StartedChaptersStore = {};

  const mapName = (s: string, c: string): string => {
    const mapped = CHAPTER_MIGRATION_MAP[s]?.[c] || c;
    const config = SUBJECT_CONFIGS[s as SubjectKey];
    return config && config.chapters.includes(mapped) ? mapped : c;
  };

  const mapMaterial = (s: string, c: string, m: string): string => {
    if (s === 'chem' && INORGANIC_CHEM_CHAPTERS.includes(c)) {
      if (m === 'Motikitab NEET') return 'Goat Sheet by Om Pandey';
      if (m === 'Motikitab JEE Mains') return 'Most Expected Questions by Om Pandey';
    }
    return m;
  };

  // Migrate status store
  Object.keys(statusStore).forEach((k) => {
    const parsed = parseStatusKey(k);
    if (!parsed) return;
    const targetChapter = mapName(parsed.subject, parsed.chapter);
    const targetMaterial = mapMaterial(parsed.subject, targetChapter, parsed.material);
    const newKey = makeStatusKey(parsed.subject, targetChapter, targetMaterial);
    newStatus[newKey] = statusStore[k];
  });

  // Migrate subitems store
  Object.keys(subItemStore).forEach((s) => {
    newSubItems[s] = newSubItems[s] || {};
    Object.keys(subItemStore[s] || {}).forEach((c) => {
      const targetChapter = mapName(s, c);
      newSubItems[s][targetChapter] = newSubItems[s][targetChapter] || {};
      Object.keys(subItemStore[s][c] || {}).forEach((m) => {
        newSubItems[s][targetChapter][m] = subItemStore[s][c][m];
      });
    });
  });

  // Migrate started chapters
  Object.keys(startedStore).forEach((s) => {
    newStarted[s] = [];
    (startedStore[s] || []).forEach((c) => {
      const target = mapName(s, c);
      if (!newStarted[s].includes(target)) {
        newStarted[s].push(target);
      }
    });
  });

  return {
    statusStore: newStatus,
    subItemStore: newSubItems,
    startedStore: newStarted,
  };
}

export interface TrackerDataSnapshot {
  statusStore: StatusStore;
  subItemStore: SubItemStore;
  startedStore: StartedChaptersStore;
  streak: StreakData | null;
  testStore: TestStore;
  targetDate: string;
}

const STATUS_RANK: Record<MaterialStatus, number> = {
  pending: 0,
  partial: 1,
  done: 2,
};

/**
 * Safely merges local and cloud tracker data so that signing in on a new device,
 * after an app update, or after clearing local cache never loses progress.
 */
export function mergeTrackerData(
  local: TrackerDataSnapshot,
  cloud: TrackerDataSnapshot
): TrackerDataSnapshot {
  const migLocal = migrateChapterData(local.statusStore, local.subItemStore, local.startedStore);
  const migCloud = migrateChapterData(cloud.statusStore, cloud.subItemStore, cloud.startedStore);

  // 1. Merge statusStore (keep higher status rank: done > partial > pending)
  const mergedStatus: StatusStore = { ...migCloud.statusStore };
  Object.entries(migLocal.statusStore).forEach(([k, localVal]) => {
    const cloudVal = mergedStatus[k] || 'pending';
    if ((STATUS_RANK[localVal] || 0) >= (STATUS_RANK[cloudVal] || 0)) {
      if (localVal !== 'pending') {
        mergedStatus[k] = localVal;
      }
    }
  });

  // 2. Merge subItemStore (union subjects, chapters, materials, and sub-item ticks)
  const mergedSubItems: SubItemStore = {};
  const allSubjects = new Set([
    ...Object.keys(migLocal.subItemStore),
    ...Object.keys(migCloud.subItemStore),
  ]);

  allSubjects.forEach((subj) => {
    mergedSubItems[subj] = {};
    const localChaps = migLocal.subItemStore[subj] || {};
    const cloudChaps = migCloud.subItemStore[subj] || {};
    const allChapters = new Set([...Object.keys(localChaps), ...Object.keys(cloudChaps)]);

    allChapters.forEach((chap) => {
      mergedSubItems[subj][chap] = {};
      const localMats = localChaps[chap] || {};
      const cloudMats = cloudChaps[chap] || {};
      const allMats = new Set([...Object.keys(localMats), ...Object.keys(cloudMats)]);

      allMats.forEach((mat) => {
        const lList = Array.isArray(localMats[mat]) ? localMats[mat] : [];
        const cList = Array.isArray(cloudMats[mat]) ? cloudMats[mat] : [];
        const maxLen = Math.max(lList.length, cList.length);
        const mergedList = [];
        for (let i = 0; i < maxLen; i++) {
          const lItem = lList[i];
          const cItem = cList[i];
          const done = Boolean(lItem?.done || cItem?.done);
          const name = lItem?.name || cItem?.name || `${mat === 'Lectures' ? 'Lecture' : mat} ${i + 1}`;
          mergedList.push({ name, done });
        }
        mergedSubItems[subj][chap][mat] = mergedList;

        // Ensure statusStore reflects merged sub-items
        if (mergedList.length > 0) {
          const allDone = mergedList.every((x) => x.done);
          const anyDone = mergedList.some((x) => x.done);
          const sKey = makeStatusKey(subj, chap, mat);
          const derivedStatus: MaterialStatus = allDone ? 'done' : anyDone ? 'partial' : 'pending';
          const existingRank = STATUS_RANK[mergedStatus[sKey] || 'pending'] || 0;
          if (STATUS_RANK[derivedStatus] > existingRank) {
            mergedStatus[sKey] = derivedStatus;
          }
        }
      });
    });
  });

  // 3. Merge startedStore (union started chapters per subject)
  const mergedStarted: StartedChaptersStore = {};
  const startedSubjects = new Set([
    ...Object.keys(migLocal.startedStore),
    ...Object.keys(migCloud.startedStore),
  ]);
  startedSubjects.forEach((subj) => {
    const lArr = Array.isArray(migLocal.startedStore[subj]) ? migLocal.startedStore[subj] : [];
    const cArr = Array.isArray(migCloud.startedStore[subj]) ? migCloud.startedStore[subj] : [];
    mergedStarted[subj] = Array.from(new Set([...cArr, ...lArr]));
  });

  // 4. Merge streak (prefer valid streak with newer date or higher count)
  let mergedStreak: StreakData | null = null;
  const lStreak = local.streak && local.streak.n > 0 ? local.streak : null;
  const cStreak = cloud.streak && cloud.streak.n > 0 ? cloud.streak : null;
  if (lStreak && cStreak) {
    if (lStreak.d > cStreak.d) {
      mergedStreak = lStreak;
    } else if (cStreak.d > lStreak.d) {
      mergedStreak = cStreak;
    } else {
      mergedStreak = lStreak.n >= cStreak.n ? lStreak : cStreak;
    }
  } else {
    mergedStreak = lStreak || cStreak;
  }

  // 5. Merge testStore
  const mergedTests: TestStore = { ...SEED_TEST_RESULTS };
  const allTestKeys = new Set([
    ...Object.keys(cloud.testStore || {}),
    ...Object.keys(local.testStore || {}),
  ]);
  allTestKeys.forEach((k) => {
    const cTest = cloud.testStore?.[k] || {};
    const lTest = local.testStore?.[k] || {};
    // Prefer entry that has attempted status s === 1 or non-empty total score
    const lHasScore = Boolean(lTest.s || (lTest.t !== undefined && lTest.t !== ''));
    const cHasScore = Boolean(cTest.s || (cTest.t !== undefined && cTest.t !== ''));
    if (lHasScore && !cHasScore) {
      mergedTests[k] = { ...cTest, ...lTest };
    } else if (cHasScore && !lHasScore) {
      mergedTests[k] = { ...lTest, ...cTest };
    } else {
      mergedTests[k] = { ...cTest, ...lTest };
    }
  });

  // 6. Merge targetDate (prefer custom date over default '2027-05-04')
  const DEFAULT_DATE = '2027-05-04';
  let mergedDate = DEFAULT_DATE;
  if (local.targetDate && local.targetDate !== DEFAULT_DATE) {
    mergedDate = local.targetDate;
  } else if (cloud.targetDate && cloud.targetDate !== DEFAULT_DATE) {
    mergedDate = cloud.targetDate;
  } else {
    mergedDate = local.targetDate || cloud.targetDate || DEFAULT_DATE;
  }

  return {
    statusStore: mergedStatus,
    subItemStore: mergedSubItems,
    startedStore: mergedStarted,
    streak: mergedStreak,
    testStore: mergedTests,
    targetDate: mergedDate,
  };
}

