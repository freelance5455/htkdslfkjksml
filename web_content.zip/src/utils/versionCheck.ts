export interface VersionInfo {
  latestVersion: string;
  currentVersion: string;
  minRequiredVersion: string;
  releaseDate: string;
  releaseNotes: string[];
  apkDownloadUrl: string;
  isForceUpdate: boolean;
}

export const CURRENT_APP_VERSION = '2.0.0';

export async function fetchLatestVersion(): Promise<VersionInfo | null> {
  try {
    const res = await fetch('/version.json?t=' + Date.now(), { cache: 'no-store' });
    if (!res.ok) return null;
    const data = await res.json();
    return data;
  } catch (err) {
    console.error('Failed to check app version:', err);
    return null;
  }
}

export function isVersionNewer(remoteVersion: string, localVersion: string): boolean {
  const parse = (v: string) => v.split('.').map(num => parseInt(num, 10) || 0);
  const r = parse(remoteVersion);
  const l = parse(localVersion);

  for (let i = 0; i < Math.max(r.length, l.length); i++) {
    const rNum = r[i] || 0;
    const lNum = l[i] || 0;
    if (rNum > lNum) return true;
    if (rNum < lNum) return false;
  }
  return false;
}
