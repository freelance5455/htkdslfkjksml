import * as pdfjsLib from 'pdfjs-dist';
import pdfjsWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { PDFDocument, rgb, degrees } from 'pdf-lib';
import fontkit from '@pdf-lib/fontkit';
import {
  AlignmentType,
  Document,
  ImageRun,
  Packer,
  PageBreak,
  Paragraph,
  TextRun,
} from 'docx';
import {
  CustomFont,
  DetectedPdfFont,
  ExportImageQuality,
  ExtractedLineInfo,
  ExtractedTextBlock,
  OverlayElement,
  PdfPageModel,
  TextOverlayElement,
  TextTokenSegment,
} from '../types/pdf';
import {
  BUNDLED_FONTS,
  ensureStudioFontsLoaded,
  hasArabicChars,
  hasBanglaChars,
  inferStudioFontFromPdf,
  isRtlText,
  resolveCssFontFamily,
} from './fonts';
import { convertBijoyToUnicode, looksLikeBijoyAnsi } from './bijoyToUnicode';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;

const PREVIEW_RENDER_SCALE = 2.0;
const THUMB_RENDER_SCALE = 0.38;
const EXPORT_TEXT_SCALE = 5; // 360 DPI crispness for shaped Bangla & English text

function rgbToHex(r: number, g: number, b: number): string {
  const clamp = (n: number) => Math.max(0, Math.min(255, Math.round(n)));
  return (
    '#' +
    [clamp(r), clamp(g), clamp(b)]
      .map((x) => x.toString(16).padStart(2, '0'))
      .join('')
  );
}

export function hexToRgbTuple(hex: string): { r: number; g: number; b: number } {
  const clean = hex.replace('#', '');
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean.padEnd(6, '0');
  const num = parseInt(full, 16);
  return {
    r: ((num >> 16) & 255) / 255,
    g: ((num >> 8) & 255) / 255,
    b: (num & 255) / 255,
  };
}

function sampleColorsFromCanvas(
  ctx: CanvasRenderingContext2D,
  canvasWidth: number,
  canvasHeight: number,
  xPt: number,
  yPt: number,
  wPt: number,
  hPt: number,
  scale: number
): { bgColor: string; inkColor: string } {
  const px = Math.max(0, Math.floor(xPt * scale));
  const py = Math.max(0, Math.floor(yPt * scale));
  const pw = Math.max(2, Math.ceil(wPt * scale));
  const ph = Math.max(2, Math.ceil(hPt * scale));

  // Sample border perimeter (2px outside bounding box) for background color
  const pad = Math.max(2, Math.round(2 * scale));
  const sx = Math.max(0, px - pad);
  const sy = Math.max(0, py - pad);
  const sw = Math.min(canvasWidth - sx, pw + pad * 2);
  const sh = Math.min(canvasHeight - sy, ph + pad * 2);

  if (sw <= 0 || sh <= 0) {
    return { bgColor: '#ffffff', inkColor: '#0f172a' };
  }

  const imgData = ctx.getImageData(sx, sy, sw, sh).data;
  const bgSamples: Array<[number, number, number]> = [];

  for (let row = 0; row < sh; row++) {
    for (let col = 0; col < sw; col++) {
      const isPerimeter =
        row < pad || row >= sh - pad || col < pad || col >= sw - pad;
      if (!isPerimeter) continue;
      const idx = (row * sw + col) * 4;
      bgSamples.push([imgData[idx], imgData[idx + 1], imgData[idx + 2]]);
    }
  }

  let bgR = 255;
  let bgG = 255;
  let bgB = 255;

  if (bgSamples.length > 0) {
    // Use median-like bucket by quantized color to avoid anti-aliased edge bleed
    const buckets = new Map<string, { count: number; r: number; g: number; b: number }>();
    for (const [r, g, b] of bgSamples) {
      const key = `${r >> 3},${g >> 3},${b >> 3}`;
      const prev = buckets.get(key);
      if (prev) {
        prev.count += 1;
        prev.r += r;
        prev.g += g;
        prev.b += b;
      } else {
        buckets.set(key, { count: 1, r, g, b });
      }
    }
    let best = { count: 0, r: 255, g: 255, b: 255 };
    for (const b of buckets.values()) {
      if (b.count > best.count) best = b;
    }
    bgR = best.r / best.count;
    bgG = best.g / best.count;
    bgB = best.b / best.count;
  }

  // Sample interior pixels contrasting with bg to detect exact original ink color
  const inkCandidates: Array<{ r: number; g: number; b: number; dist: number }> = [];

  for (let row = pad; row < sh - pad; row++) {
    for (let col = pad; col < sw - pad; col++) {
      const idx = (row * sw + col) * 4;
      const r = imgData[idx];
      const g = imgData[idx + 1];
      const b = imgData[idx + 2];
      const dist = Math.abs(r - bgR) + Math.abs(g - bgG) + Math.abs(b - bgB);
      if (dist > 36) {
        inkCandidates.push({ r, g, b, dist });
      }
    }
  }

  let inkColor = bgR + bgG + bgB < 380 ? '#ffffff' : '#0f172a';
  if (inkCandidates.length > 0) {
    // Use the median of the top 18% highest-contrast core glyph pixels to avoid anti-aliasing bleed
    inkCandidates.sort((a, b) => b.dist - a.dist);
    const coreCount = Math.max(1, Math.ceil(inkCandidates.length * 0.18));
    const core = inkCandidates.slice(0, coreCount);
    const rs = core.map((c) => c.r).sort((a, b) => a - b);
    const gs = core.map((c) => c.g).sort((a, b) => a - b);
    const bs = core.map((c) => c.b).sort((a, b) => a - b);
    const mid = Math.floor(core.length / 2);
    inkColor = rgbToHex(rs[mid], gs[mid], bs[mid]);
  }

  return {
    bgColor: rgbToHex(bgR, bgG, bgB),
    inkColor,
  };
}

const BANGLA_COMBINING_RE = /^[\u0981-\u0983\u09BC\u09BE-\u09CD\u09D7\u09E2\u09E3]/;
const BANGLA_CONSONANT_RE = /[\u0995-\u09B9\u09DC-\u09DF]/;
const PRE_BASE_VOWELS_SET = new Set(['\u09BF', '\u09C7', '\u09C8']);
const ARABIC_COMBINING_RE = /^[\u064B-\u065F\u0670\u06D6-\u06ED]/;

/**
 * Repairs split Bangla conjuncts, broken vowel signs, visual-order matras,
 * displaced Reph (র্), and legacy Bijoy ANSI text extracted from PDF streams.
 */
export function normalizeExtractedBanglaText(rawText: string, fontName = ''): string {
  if (!rawText) return rawText;
  let text = rawText
    .replace(/[\u200B\uFEFF\u00AD]/g, '')
    // Strip accidental ZWNJ/ZWJ adjacent to pre-base vowels or AA-kar
    .replace(/([\u09BF\u09C7\u09C8\u09BE])[\u200C\u200D]+/g, '$1')
    .replace(/[\u200C\u200D]+([\u09BF\u09C7\u09C8\u09BE])/g, '$1');

  if (looksLikeBijoyAnsi(text, fontName)) {
    text = convertBijoyToUnicode(text);
  }

  text = text.normalize('NFC');

  // Remove accidental spaces inserted around virama (্) or before matras/bindus
  text = text.replace(
    /([\u0995-\u09B9\u09DC-\u09DF])\u09CD\s+([\u0995-\u09B9\u09DC-\u09DF])/g,
    '$1\u09CD$2'
  );
  text = text.replace(/\s+([\u0981-\u0983\u09BC\u09BE-\u09CD\u09D7\u09E2\u09E3])/g, '$1');

  // Detect visual-order glitches before mutating
  const hadVisualAaE = /\u09BE\u09C7/.test(text);
  const hadLeadingPreBase =
    /(?:^|[\s.,;:!?।॥(\[\u0981-\u0983\u09BE-\u09CC\u09D7\uFFFD])[\u09BF\u09C7\u09C8][\u0995-\u09B9\u09DC-\u09DF]/.test(
      text
    );

  // Repair collided AA-kar + E-kar -> O-kar and standard E-kar combinations
  text = text
    .replace(/\u09BE\u09C7/g, '\u09CB')
    .replace(/\u09C7\u09BE/g, '\u09CB')
    .replace(/\u09C7\u09D7/g, '\u09CC')
    .replace(/\u0985\u09BE/g, '\u0986');

  // Repair displaced Reph (র + ্ placed after its base consonant cluster instead of before it)
  const displacedRephRe =
    /((?:[\u0995-\u09B9\u09DC-\u09DF]\u09BC?\u09CD)*[\u0995-\u09B9\u09DC-\u09DF]\u09BC?)\u09B0\u09CD(?=$|[\s.,;:!?।॥)\]\u0981-\u0983\u09BE-\u09CC\u09D7\u09BF\u09C7\u09C8\uFFFD])/g;
  const hadDisplacedReph = displacedRephRe.test(text);
  text = text.replace(displacedRephRe, '\u09B0\u09CD$1');

  const isVisualOrder = hadVisualAaE || hadLeadingPreBase || hadDisplacedReph;

  // Reorder visual-order pre-base vowel signs (ি, ে, ৈ) after the consonant/conjunct cluster
  const chars = Array.from(text);
  const fixed: string[] = [];
  let i = 0;

  while (i < chars.length) {
    const ch = chars[i];
    const prev = fixed.length > 0 ? fixed[fixed.length - 1] : '';
    const startsCluster = i + 1 < chars.length && BANGLA_CONSONANT_RE.test(chars[i + 1]);
    const prevIsNotClusterBody =
      !prev || (!BANGLA_CONSONANT_RE.test(prev) && prev !== '\u09CD' && prev !== '\u09BC');

    const isVisualPreBase =
      PRE_BASE_VOWELS_SET.has(ch) &&
      startsCluster &&
      (isVisualOrder ? prev !== '\u09CD' : prevIsNotClusterBody);

    if (isVisualPreBase) {
      let end = i + 1;
      while (end + 1 < chars.length) {
        if (chars[end + 1] === '\u09BC') {
          end += 1;
        } else if (chars[end] === '\u09CD' && end + 1 < chars.length) {
          end += 1;
        } else if (chars[end + 1] === '\u09CD' && end + 2 < chars.length) {
          end += 2;
        } else {
          break;
        }
      }
      const cluster = chars.slice(i + 1, end + 1).join('');
      const nextAfterCluster = end + 1 < chars.length ? chars[end + 1] : '';

      if (ch === '\u09C7' && nextAfterCluster === '\u09BE') {
        fixed.push(cluster, '\u09CB');
        i = end + 2;
      } else if (ch === '\u09C7' && nextAfterCluster === '\u09D7') {
        fixed.push(cluster, '\u09CC');
        i = end + 2;
      } else if (ch === '\u09C7' && nextAfterCluster === '\u09CB') {
        // Collided 'ে + C1 + ো + C2 + া' (e.g. 'েকোনা' -> 'কোনো')
        fixed.push(cluster, '\u09CB');
        chars[end + 1] = '\u09C7';
        i = end + 1;
      } else {
        fixed.push(cluster, ch);
        i = end + 1;
      }
      continue;
    }

    fixed.push(ch);
    i += 1;
  }

  return fixed.join('').normalize('NFC').replace(/\s{2,}/g, ' ').trim();
}

/**
 * Normalizes extracted Arabic PDF text, reversing visual-LTR presentation-form runs
 * and converting Arabic Presentation Forms-A/B back to standard logical Arabic Unicode.
 */
export function normalizeExtractedArabicText(rawText: string): string {
  if (!rawText) return rawText;
  let text = rawText.replace(/[\u200B\uFEFF\u00AD]/g, '');

  // If presentation-form glyphs appear in reversed visual LTR order inside a run, reverse them before NFKC
  if (/[\uFB50-\uFDFF\uFE70-\uFEFF]/.test(text)) {
    text = text.replace(/[\uFB50-\uFDFF\uFE70-\uFEFF]+/g, (segment) => {
      const chars = Array.from(segment);
      if (chars.length <= 1) return segment;
      const firstCode = chars[0].codePointAt(0) || 0;
      const lastCode = chars[chars.length - 1].codePointAt(0) || 0;
      // Heuristic: Arabic presentation forms in logical order start with isolated/initial and end with final/isolated;
      // if odd visual-order presentation tables reverse words, NFKC handles standard ordering cleanly when reversed if needed.
      const looksReversedLamAlef = segment.includes('\uFEFC') || segment.includes('\uFEFB');
      if (looksReversedLamAlef && firstCode >= 0xfe70 && lastCode >= 0xfe70) {
        // Keep natural order unless clearly inverted single token
        return segment;
      }
      return segment;
    });
  }

  text = text.normalize('NFKC');
  text = text.replace(/\s+([\u064B-\u065F\u0670\u06D6-\u06ED])/g, '$1');
  return text.replace(/\s{2,}/g, ' ').trim();
}

export function normalizeExtractedText(rawText: string, fontName = ''): string {
  if (!rawText) return rawText;
  let result = rawText;
  if (hasArabicChars(result)) {
    result = normalizeExtractedArabicText(result);
  }
  if (hasBanglaChars(result) || looksLikeBijoyAnsi(result, fontName)) {
    result = normalizeExtractedBanglaText(result, fontName);
  }
  return result.replace(/\s{2,}/g, ' ').trim();
}

interface RawRun {
  str: string;
  x: number;
  baselineY: number;
  width: number;
  height: number;
  fontSize: number;
  fontName: string;
  fontFamilyCss: string;
}

interface ExtractedSingleLine {
  text: string;
  x: number;
  y: number;
  baselineY: number;
  width: number;
  height: number;
  fontSize: number;
  fontName: string;
  fontFamilyCss: string;
  bgColor: string;
  inkColor: string;
  isRtl: boolean;
  isBijoySuspected: boolean;
  matchedFontId: string;
  fontWeight: 'normal' | 'bold';
  fontStyle: 'normal' | 'italic';
  cleanDisplayName: string;
  segments: TextTokenSegment[];
}

function buildLineSegments(
  text: string,
  minX: number,
  boxWidth: number,
  isRtl: boolean
): TextTokenSegment[] {
  const words = text.split(/\s+/).filter(Boolean);
  const segments: TextTokenSegment[] = [];
  if (words.length === 0) return segments;

  const totalChars = Math.max(
    1,
    words.reduce((sum, w) => sum + w.length, 0) + Math.max(0, words.length - 1)
  );
  let charCursor = 0;
  for (const word of words) {
    const startRatio = charCursor / totalChars;
    const widthRatio = word.length / totalChars;
    const width = Math.max(4, boxWidth * widthRatio);
    const x = isRtl
      ? minX + boxWidth * (1 - startRatio - widthRatio)
      : minX + boxWidth * startRatio;
    segments.push({
      text: word,
      x,
      width,
    });
    charCursor += word.length + 1;
  }
  return segments;
}

export interface PdfParseOptions {
  paragraphGrouping?: boolean;
  autoNormalizeText?: boolean;
}

function groupRunsIntoTextBlocks(
  runs: RawRun[],
  pageId: string,
  ctx: CanvasRenderingContext2D,
  canvasWidth: number,
  canvasHeight: number,
  customFonts: CustomFont[],
  parseOptions?: PdfParseOptions
): ExtractedTextBlock[] {
  const autoNormalize = parseOptions?.autoNormalizeText ?? true;
  const groupParagraphs = parseOptions?.paragraphGrouping ?? true;
  const nonEmpty = runs.filter((r) => r.str.trim().length > 0);
  if (nonEmpty.length === 0) return [];

  // Keep space-only items separately to know if an explicit whitespace glyph lay between two runs
  const spaceRuns = runs.filter((r) => r.str.length > 0 && r.str.trim().length === 0);

  // Sort top-to-bottom, then left-to-right for initial line clustering
  const sorted = [...nonEmpty].sort((a, b) => {
    const dy = a.baselineY - b.baselineY;
    if (Math.abs(dy) > Math.max(2.5, Math.min(a.fontSize, b.fontSize) * 0.35)) {
      return dy;
    }
    return a.x - b.x;
  });

  const lineRunGroups: RawRun[][] = [];
  for (const run of sorted) {
    const lastLine = lineRunGroups[lineRunGroups.length - 1];
    if (!lastLine) {
      lineRunGroups.push([run]);
      continue;
    }
    const anchor = lastLine[lastLine.length - 1];
    const sameBaseline =
      Math.abs(run.baselineY - anchor.baselineY) <=
      Math.max(2.5, anchor.fontSize * 0.32);
    const sameSize = Math.abs(run.fontSize - anchor.fontSize) <= 1.8;
    const gap = run.x - (anchor.x + anchor.width);
    // Keep distinct table columns separated while keeping normal word spacing together
    const closeHorizontally =
      gap >= -anchor.fontSize * 0.75 && gap <= Math.max(10, anchor.fontSize * 0.95);

    if (sameBaseline && sameSize && closeHorizontally) {
      lastLine.push(run);
    } else {
      lineRunGroups.push([run]);
    }
  }

  const singleLines: ExtractedSingleLine[] = lineRunGroups.map((lineRuns) => {
    const combinedCharsPreview = lineRuns.map((r) => r.str).join('');
    const lineIsRtl = isRtlText(combinedCharsPreview);

    // Sort RTL Arabic runs right-to-left; LTR Bangla/English left-to-right
    lineRuns.sort((a, b) => (lineIsRtl ? b.x - a.x : a.x - b.x));

    let combinedRaw = '';
    const first = lineRuns[0];

    for (let i = 0; i < lineRuns.length; i++) {
      const cur = lineRuns[i];
      if (i === 0) {
        combinedRaw = cur.str;
      } else {
        const prev = lineRuns[i - 1];
        const gap = lineIsRtl
          ? prev.x - (cur.x + cur.width)
          : cur.x - (prev.x + prev.width);

        const hasExplicitSpaceBetween = spaceRuns.some((sp) => {
          if (Math.abs(sp.baselineY - prev.baselineY) > prev.fontSize * 0.4) return false;
          const spCenter = sp.x + sp.width / 2;
          const leftBound = Math.min(prev.x + prev.width, cur.x) - 1;
          const rightBound = Math.max(prev.x + prev.width, cur.x) + 1;
          return spCenter >= leftBound && spCenter <= rightBound;
        });

        const curStartsCombining =
          BANGLA_COMBINING_RE.test(cur.str) ||
          ARABIC_COMBINING_RE.test(cur.str) ||
          /^[,.;:!?।॥،؛؟)\]]/.test(cur.str);
        const prevEndsConnector =
          /[\u09CD\u200C\u200D(\[]$/.test(combinedRaw) ||
          combinedRaw.endsWith(' ');

        const threshold =
          hasBanglaChars(prev.str) || hasBanglaChars(cur.str)
            ? prev.fontSize * 0.30
            : lineIsRtl
            ? prev.fontSize * 0.24
            : prev.fontSize * 0.20;

        const needsSpace =
          !curStartsCombining &&
          !prevEndsConnector &&
          !cur.str.startsWith(' ') &&
          (hasExplicitSpaceBetween || gap > threshold);

        combinedRaw += (needsSpace ? ' ' : '') + cur.str;
      }
    }

    const normalizedText = autoNormalize
      ? normalizeExtractedText(combinedRaw, first.fontName)
      : combinedRaw.replace(/\s{2,}/g, ' ').trim();

    const minX = Math.min(...lineRuns.map((r) => r.x));
    const maxX = Math.max(...lineRuns.map((r) => r.x + r.width));
    const avgFontSize =
      lineRuns.reduce((s, r) => s + r.fontSize, 0) / lineRuns.length;
    const avgBaselineY =
      lineRuns.reduce((s, r) => s + r.baselineY, 0) / lineRuns.length;

    const topY = Math.max(0, avgBaselineY - avgFontSize * 1.0);
    const boxHeight = Math.max(avgFontSize * 1.24, 12);
    const boxWidth = Math.max(maxX - minX, 12);

    const { bgColor, inkColor } = sampleColorsFromCanvas(
      ctx,
      canvasWidth,
      canvasHeight,
      minX,
      topY,
      boxWidth,
      boxHeight,
      PREVIEW_RENDER_SCALE
    );

    const inferred = inferStudioFontFromPdf(
      first.fontName,
      first.fontFamilyCss,
      normalizedText,
      customFonts
    );

    const segments = buildLineSegments(normalizedText, minX, boxWidth, lineIsRtl);

    return {
      text: normalizedText,
      x: minX,
      y: topY,
      baselineY: avgBaselineY,
      width: boxWidth,
      height: boxHeight,
      fontSize: Number(avgFontSize.toFixed(1)),
      fontName: first.fontName,
      fontFamilyCss: first.fontFamilyCss,
      bgColor,
      inkColor,
      isRtl: lineIsRtl,
      isBijoySuspected: looksLikeBijoyAnsi(combinedRaw, first.fontName),
      matchedFontId: inferred.matchedFontId,
      fontWeight: inferred.fontWeight,
      fontStyle: inferred.fontStyle,
      cleanDisplayName: inferred.cleanDisplayName,
      segments,
    };
  });

  // Sort single lines top-to-bottom for paragraph grouping
  const orderedLines = [...singleLines].sort((a, b) => {
    const dy = a.y - b.y;
    if (Math.abs(dy) > 3) return dy;
    return a.x - b.x;
  });

  interface ParagraphGroup {
    lines: ExtractedSingleLine[];
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
  }

  const paragraphs: ParagraphGroup[] = [];

  for (const line of orderedLines) {
    // Look backwards at recent paragraphs to find one this line naturally continues (handles multi-column pages)
    let matchedPara: ParagraphGroup | null = null;
    if (groupParagraphs) {
      for (let pIdx = paragraphs.length - 1; pIdx >= 0; pIdx--) {
      const para = paragraphs[pIdx];
      const lastLine = para.lines[para.lines.length - 1];
      const baselineStep = line.baselineY - lastLine.baselineY;
      const verticalGap = line.y - (lastLine.y + lastLine.height);

      // Must be strictly below the previous line within single-paragraph line spacing
      if (baselineStep <= Math.max(4, lastLine.fontSize * 0.65)) continue;
      if (verticalGap > Math.max(8, lastLine.fontSize * 0.78)) continue;

      // Must match typography & direction
      if (Math.abs(line.fontSize - lastLine.fontSize) > 1.5) continue;
      if (line.fontWeight !== lastLine.fontWeight) continue;
      if (line.fontStyle !== lastLine.fontStyle) continue;
      if (line.isRtl !== lastLine.isRtl) continue;

      // Must belong to the same column / alignment
      const lineRight = line.x + line.width;
      const overlapX = Math.max(0, Math.min(para.maxX, lineRight) - Math.max(para.minX, line.x));
      const minW = Math.min(para.maxX - para.minX, line.width);
      const hasColumnOverlap = minW > 0 && overlapX >= minW * 0.25;
      const leftAligned = Math.abs(line.x - para.minX) <= Math.max(30, lastLine.fontSize * 2.8);
      const rightAligned = Math.abs(lineRight - para.maxX) <= Math.max(30, lastLine.fontSize * 2.8);
      const centerAligned =
        Math.abs((line.x + lineRight) / 2 - (para.minX + para.maxX) / 2) <=
        Math.max(18, lastLine.fontSize * 1.8);

      if (!hasColumnOverlap || !(leftAligned || rightAligned || centerAligned)) continue;

      // Break paragraph if previous line clearly ended a paragraph (short sentence-ending line)
      const paraW = para.maxX - para.minX;
      const prevEndedParagraph =
        para.lines.length >= 1 &&
        /[।.?!؟:]$/.test(lastLine.text.trim()) &&
        lastLine.width < paraW * 0.78;
      if (prevEndedParagraph) continue;

      matchedPara = para;
      break;
    }
    }

    if (matchedPara) {
      matchedPara.lines.push(line);
      matchedPara.minX = Math.min(matchedPara.minX, line.x);
      matchedPara.maxX = Math.max(matchedPara.maxX, line.x + line.width);
      matchedPara.minY = Math.min(matchedPara.minY, line.y);
      matchedPara.maxY = Math.max(matchedPara.maxY, line.y + line.height);
    } else {
      paragraphs.push({
        lines: [line],
        minX: line.x,
        maxX: line.x + line.width,
        minY: line.y,
        maxY: line.y + line.height,
      });
    }
  }

  return paragraphs.map((para, idx) => {
    const first = para.lines[0];
    const lineCount = para.lines.length;
    const avgFontSize = Number(
      (para.lines.reduce((s, l) => s + l.fontSize, 0) / lineCount).toFixed(1)
    );

    let computedLineHeight = 1.26;
    if (lineCount > 1) {
      let stepSum = 0;
      for (let k = 1; k < lineCount; k++) {
        stepSum += para.lines[k].baselineY - para.lines[k - 1].baselineY;
      }
      const avgStep = stepSum / (lineCount - 1);
      computedLineHeight = Number(
        Math.max(1.08, Math.min(1.65, avgStep / Math.max(8, avgFontSize))).toFixed(2)
      );
    }

    // Detect center or right alignment across multi-line paragraphs
    let textAlign: 'left' | 'center' | 'right' = first.isRtl ? 'right' : 'left';
    if (lineCount >= 2 && !first.isRtl) {
      const avgCenter =
        para.lines.reduce((s, l) => s + l.x + l.width / 2, 0) / lineCount;
      const maxCenterDrift = Math.max(
        ...para.lines.map((l) => Math.abs(l.x + l.width / 2 - avgCenter))
      );
      const maxLeftDrift = Math.max(...para.lines.map((l) => Math.abs(l.x - para.minX)));
      const maxRightDrift = Math.max(
        ...para.lines.map((l) => Math.abs(l.x + l.width - para.maxX))
      );
      if (maxCenterDrift <= 5 && maxLeftDrift > 7) {
        textAlign = 'center';
      } else if (maxRightDrift <= 5 && maxLeftDrift > 7) {
        textAlign = 'right';
      }
    }

    const lineInfos: ExtractedLineInfo[] = para.lines.map((l) => ({
      text: l.text,
      x: l.x,
      y: l.y,
      width: l.width,
      height: l.height,
      segments: l.segments,
    }));

    return {
      id: `${pageId}-blk-${idx}`,
      pageId,
      originalText: para.lines.map((l) => l.text).join('\n'),
      x: para.minX,
      y: para.minY,
      width: Math.max(12, para.maxX - para.minX),
      height: Math.max(12, para.maxY - para.minY),
      fontSize: avgFontSize,
      rawFontName: first.cleanDisplayName,
      matchedFontId: first.matchedFontId,
      fontWeight: first.fontWeight,
      fontStyle: first.fontStyle,
      color: first.inkColor,
      bgColor: first.bgColor,
      lineHeight: computedLineHeight,
      isEdited: false,
      isBijoySuspected: para.lines.some((l) => l.isBijoySuspected),
      isRtl: first.isRtl,
      textAlign,
      segments: first.segments,
      lines: lineInfos,
    };
  });
}

export async function parsePdfIntoStudio(
  pdfBytes: Uint8Array,
  customFonts: CustomFont[] = [],
  parseOptions?: PdfParseOptions
): Promise<{
  pages: PdfPageModel[];
  detectedFonts: DetectedPdfFont[];
}> {
  await ensureStudioFontsLoaded();

  const loadingTask = pdfjsLib.getDocument({
    data: pdfBytes.slice(),
    useSystemFonts: true,
  });
  const pdfDoc = await loadingTask.promise;

  const pages: PdfPageModel[] = [];
  const fontStats = new Map<string, DetectedPdfFont>();

  for (let pageNum = 1; pageNum <= pdfDoc.numPages; pageNum++) {
    const page = await pdfDoc.getPage(pageNum);
    const viewport1x = page.getViewport({ scale: 1.0 });
    const previewViewport = page.getViewport({ scale: PREVIEW_RENDER_SCALE });
    const thumbViewport = page.getViewport({ scale: THUMB_RENDER_SCALE });

    // Render high-DPI page preview
    const canvas = document.createElement('canvas');
    canvas.width = Math.ceil(previewViewport.width);
    canvas.height = Math.ceil(previewViewport.height);
    const ctx = canvas.getContext('2d', { willReadFrequently: true })!;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    await page.render({
      canvasContext: ctx,
      viewport: previewViewport,
      canvas,
    }).promise;

    const previewDataUrl = canvas.toDataURL('image/png');

    // Render thumbnail
    const thumbCanvas = document.createElement('canvas');
    thumbCanvas.width = Math.ceil(thumbViewport.width);
    thumbCanvas.height = Math.ceil(thumbViewport.height);
    const thumbCtx = thumbCanvas.getContext('2d')!;
    thumbCtx.fillStyle = '#ffffff';
    thumbCtx.fillRect(0, 0, thumbCanvas.width, thumbCanvas.height);
    await page.render({
      canvasContext: thumbCtx,
      viewport: thumbViewport,
      canvas: thumbCanvas,
    }).promise;
    const thumbnailDataUrl = thumbCanvas.toDataURL('image/jpeg', 0.85);

    // Extract text runs with exact 1x top-left viewport coordinates
    const textContent = await page.getTextContent();
    const styles = textContent.styles || {};
    const rawRuns: RawRun[] = [];

    for (const item of textContent.items) {
      if (!('str' in item) || !item.str) continue;
      const m = pdfjsLib.Util.transform(viewport1x.transform, item.transform);
      const fontSize = Math.max(6, Math.hypot(m[0], m[1]) || Math.hypot(m[2], m[3]) || 12);
      const x = m[4];
      const baselineY = m[5];
      const styleInfo = styles[item.fontName] || { fontFamily: '' };

      rawRuns.push({
        str: item.str,
        x,
        baselineY,
        width: Math.max(item.width || 0, fontSize * 0.4),
        height: item.height || fontSize,
        fontSize,
        fontName: item.fontName || 'Standard',
        fontFamilyCss: styleInfo.fontFamily || '',
      });
    }

    const pageId = `page-${pageNum}-${Date.now()}`;
    const extractedBlocks = groupRunsIntoTextBlocks(
      rawRuns,
      pageId,
      ctx,
      canvas.width,
      canvas.height,
      customFonts,
      parseOptions
    );

    // Aggregate detected font stats
    for (const blk of extractedBlocks) {
      const key = `${blk.rawFontName}__${blk.fontWeight}__${blk.fontStyle}`;
      const existing = fontStats.get(key);
      if (existing) {
        existing.count += blk.lines?.length ?? 1;
        existing.hasBangla = existing.hasBangla || hasBanglaChars(blk.originalText);
        existing.hasArabic = existing.hasArabic || hasArabicChars(blk.originalText);
        existing.isBijoyEncoded = existing.isBijoyEncoded || blk.isBijoySuspected;
      } else {
        fontStats.set(key, {
          rawName: blk.rawFontName,
          displayName: blk.rawFontName,
          matchedFontId: blk.matchedFontId,
          isBold: blk.fontWeight === 'bold',
          isItalic: blk.fontStyle === 'italic',
          hasBangla: hasBanglaChars(blk.originalText),
          hasArabic: hasArabicChars(blk.originalText),
          isBijoyEncoded: blk.isBijoySuspected,
          count: blk.lines?.length ?? 1,
        });
      }
    }

    pages.push({
      id: pageId,
      originalPageIndex: pageNum - 1,
      widthPt: viewport1x.width,
      heightPt: viewport1x.height,
      rotation: 0,
      previewDataUrl,
      thumbnailDataUrl,
      extractedBlocks,
    });
  }

  return {
    pages,
    detectedFonts: Array.from(fontStats.values()).sort((a, b) => b.count - a.count),
  };
}

export async function renderOriginalPagePreviews(
  pdfBytes: Uint8Array,
  originalIndices: Array<number | null>
): Promise<Map<number, { previewDataUrl: string; thumbnailDataUrl: string }>> {
  const result = new Map<number, { previewDataUrl: string; thumbnailDataUrl: string }>();
  const uniqueIndices = Array.from(
    new Set(originalIndices.filter((idx): idx is number => idx !== null && idx >= 0))
  );
  if (uniqueIndices.length === 0) return result;

  await ensureStudioFontsLoaded();
  const loadingTask = pdfjsLib.getDocument({
    data: pdfBytes.slice(),
    useSystemFonts: true,
  });
  const pdfDoc = await loadingTask.promise;

  for (const origIdx of uniqueIndices) {
    if (origIdx + 1 > pdfDoc.numPages) continue;
    const page = await pdfDoc.getPage(origIdx + 1);
    const previewViewport = page.getViewport({ scale: PREVIEW_RENDER_SCALE });
    const thumbViewport = page.getViewport({ scale: THUMB_RENDER_SCALE });

    const canvas = document.createElement('canvas');
    canvas.width = Math.ceil(previewViewport.width);
    canvas.height = Math.ceil(previewViewport.height);
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvasContext: ctx, viewport: previewViewport, canvas }).promise;

    const thumbCanvas = document.createElement('canvas');
    thumbCanvas.width = Math.ceil(thumbViewport.width);
    thumbCanvas.height = Math.ceil(thumbViewport.height);
    const thumbCtx = thumbCanvas.getContext('2d')!;
    thumbCtx.fillStyle = '#ffffff';
    thumbCtx.fillRect(0, 0, thumbCanvas.width, thumbCanvas.height);
    await page.render({ canvasContext: thumbCtx, viewport: thumbViewport, canvas: thumbCanvas })
      .promise;

    result.set(origIdx, {
      previewDataUrl: canvas.toDataURL('image/png'),
      thumbnailDataUrl: thumbCanvas.toDataURL('image/jpeg', 0.85),
    });
  }

  return result;
}

interface WrappedLine {
  text: string;
  isParagraphEnd: boolean;
}

function wrapTextLinesWithMeta(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidthPx: number
): WrappedLine[] {
  const paragraphs = text.split('\n');
  const lines: WrappedLine[] = [];

  for (const para of paragraphs) {
    if (para === '') {
      lines.push({ text: '', isParagraphEnd: true });
      continue;
    }
    const words = para.split(/(\s+)/);
    let currentLine = '';

    for (const token of words) {
      const testLine = currentLine + token;
      if (ctx.measureText(testLine).width <= maxWidthPx || currentLine === '') {
        currentLine = testLine;
      } else {
        lines.push({ text: currentLine.trimEnd(), isParagraphEnd: false });
        currentLine = token.trimStart();
      }
    }
    if (currentLine !== '') {
      lines.push({ text: currentLine.trimEnd(), isParagraphEnd: true });
    }
  }

  return lines.length > 0 ? lines : [{ text: '', isParagraphEnd: true }];
}

function drawAlignedCanvasLine(
  ctx: CanvasRenderingContext2D,
  line: WrappedLine,
  baseX: number,
  y: number,
  boxWidthPx: number,
  align: 'left' | 'center' | 'right' | 'justify'
) {
  ctx.save();
  ctx.textAlign = 'left';
  if ('direction' in ctx) {
    (ctx as CanvasRenderingContext2D & { direction: 'ltr' | 'rtl' | 'inherit' }).direction =
      isRtlText(line.text) ? 'rtl' : 'ltr';
  }

  if (align === 'justify' && !line.isParagraphEnd) {
    const words = line.text.trim().split(/\s+/);
    if (words.length > 1) {
      const wordsWidth = words.reduce((sum, w) => sum + ctx.measureText(w).width, 0);
      const gap = (boxWidthPx - wordsWidth) / (words.length - 1);
      if (gap > 0 && gap < boxWidthPx * 0.45) {
        if (isRtlText(line.text)) {
          let curX = baseX + boxWidthPx;
          for (const w of words) {
            const wWidth = ctx.measureText(w).width;
            ctx.fillText(w, curX - wWidth, y);
            curX -= wWidth + gap;
          }
        } else {
          let curX = baseX;
          for (const w of words) {
            ctx.fillText(w, curX, y);
            curX += ctx.measureText(w).width + gap;
          }
        }
        ctx.restore();
        return;
      }
    }
  }

  let x = baseX;
  const lineWidth = ctx.measureText(line.text).width;
  if (align === 'center') {
    x = baseX + Math.max(0, (boxWidthPx - lineWidth) / 2);
  } else if (align === 'right') {
    x = baseX + Math.max(0, boxWidthPx - lineWidth);
  }
  ctx.fillText(line.text, x, y);
  ctx.restore();
}

let sharedMeasureCtx: CanvasRenderingContext2D | null = null;

function getMeasureCtx(): CanvasRenderingContext2D {
  if (!sharedMeasureCtx) {
    const c = document.createElement('canvas');
    sharedMeasureCtx = c.getContext('2d')!;
  }
  return sharedMeasureCtx;
}

function measureLineWidthPt(
  line: string,
  ov: TextOverlayElement,
  customFonts: CustomFont[] = []
): number {
  const ctx = getMeasureCtx();
  const cssFamily = resolveCssFontFamily(ov.fontId, customFonts);
  ctx.font = `${ov.fontStyle} ${ov.fontWeight} ${ov.fontSize}px ${cssFamily}`;
  if ('letterSpacing' in ctx) {
    (ctx as CanvasRenderingContext2D & { letterSpacing: string }).letterSpacing = `${ov.letterSpacing}px`;
  }
  return ctx.measureText(line).width;
}

export async function renderTextOverlayToHighDpiPng(
  overlay: TextOverlayElement,
  customFonts: CustomFont[],
  scale = EXPORT_TEXT_SCALE
): Promise<{ pngBytes: Uint8Array; widthPt: number; heightPt: number }> {
  await ensureStudioFontsLoaded();

  const cssFamily = resolveCssFontFamily(overlay.fontId, customFonts);
  const fontSpec = `${overlay.fontStyle} ${overlay.fontWeight} ${overlay.fontSize * scale}px ${cssFamily}`;

  const measureCanvas = document.createElement('canvas');
  const mCtx = measureCanvas.getContext('2d')!;
  mCtx.font = fontSpec;
  if ('letterSpacing' in mCtx) {
    (mCtx as CanvasRenderingContext2D & { letterSpacing: string }).letterSpacing = `${overlay.letterSpacing * scale}px`;
  }

  const maxAllowedWidthPt = overlay.maxPageWidth
    ? Math.max(40, overlay.maxPageWidth)
    : undefined;
  const rawLineWidthPx = mCtx.measureText(overlay.text).width + 8 * scale;
  const overflowsPageMargin = Boolean(
    maxAllowedWidthPt && rawLineWidthPx > maxAllowedWidthPt * scale
  );
  const shouldWrap =
    overlay.text.includes('\n') ||
    Boolean(overlay.hasCustomWidth) ||
    overflowsPageMargin;

  const targetBoxWidthPt = overlay.hasCustomWidth
    ? maxAllowedWidthPt
      ? Math.min(Math.max(40, overlay.width), maxAllowedWidthPt)
      : Math.max(40, overlay.width)
    : shouldWrap
    ? maxAllowedWidthPt
      ? maxAllowedWidthPt
      : Math.max(40, overlay.width)
    : Math.max(overlay.width, rawLineWidthPx / scale);

  const wrapWidthPx = Math.max(20 * scale, targetBoxWidthPt * scale);
  const lines = shouldWrap
    ? wrapTextLinesWithMeta(mCtx, overlay.text, wrapWidthPx)
    : [{ text: overlay.text, isParagraphEnd: true }];
  const lineHeightPx = overlay.fontSize * overlay.lineHeight * scale;
  const maxMeasuredWidth = Math.max(
    shouldWrap ? wrapWidthPx : rawLineWidthPx,
    ...lines.map((l) => Math.min(wrapWidthPx, mCtx.measureText(l.text).width + 4 * scale))
  );

  const canvasWidth = Math.ceil(maxMeasuredWidth);
  const canvasHeight = Math.ceil(
    Math.max(overlay.height * scale, lines.length * lineHeightPx + overlay.fontSize * 0.35 * scale)
  );

  const canvas = document.createElement('canvas');
  canvas.width = canvasWidth;
  canvas.height = canvasHeight;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, canvasWidth, canvasHeight);
  ctx.globalAlpha = overlay.opacity;
  ctx.font = fontSpec;
  ctx.fillStyle = overlay.color;
  ctx.textBaseline = 'alphabetic';
  if ('letterSpacing' in ctx) {
    (ctx as CanvasRenderingContext2D & { letterSpacing: string }).letterSpacing = `${overlay.letterSpacing * scale}px`;
  }

  const halfLeadingPx = Math.max(0, ((overlay.lineHeight - 1) / 2) * overlay.fontSize * scale);
  const ascentPx = overlay.fontSize * 0.86 * scale + halfLeadingPx;

  lines.forEach((line, idx) => {
    const y = ascentPx + idx * lineHeightPx;
    drawAlignedCanvasLine(
      ctx,
      line,
      0,
      y,
      shouldWrap ? wrapWidthPx : canvasWidth,
      overlay.textAlign
    );
  });

  const blob = await new Promise<Blob>((resolve) =>
    canvas.toBlob((b) => resolve(b!), 'image/png')
  );
  const buffer = await blob.arrayBuffer();

  return {
    pngBytes: new Uint8Array(buffer),
    widthPt: canvasWidth / scale,
    heightPt: canvasHeight / scale,
  };
}

export interface PartialTextRenderItem {
  maskRect: {
    x: number;
    y: number;
    width: number;
    height: number;
    padding: number;
    color: string;
  } | null;
  drawX: number;
  drawY: number;
  drawText: string;
  drawWidth: number;
  drawHeight: number;
  textAlign: TextOverlayElement['textAlign'];
}

export interface TextRenderPlanResult {
  shouldRender: boolean;
  items: PartialTextRenderItem[];
}

function buildSingleLinePartialPlan(
  text: string,
  origText: string,
  x: number,
  y: number,
  width: number,
  height: number,
  segments: TextTokenSegment[] | undefined,
  baseMask: PartialTextRenderItem['maskRect'],
  textAlign: TextOverlayElement['textAlign']
): PartialTextRenderItem {
  const canPartialPrefix =
    Boolean(baseMask) &&
    segments &&
    segments.length > 1 &&
    textAlign === 'left' &&
    !isRtlText(text);

  if (canPartialPrefix && segments && baseMask) {
    const newTokens = text.trim().split(/\s+/).filter(Boolean);
    let matchCount = 0;
    while (
      matchCount < segments.length &&
      matchCount < newTokens.length &&
      segments[matchCount].text === newTokens[matchCount]
    ) {
      matchCount += 1;
    }

    if (matchCount > 0 && matchCount < Math.max(segments.length, newTokens.length)) {
      const origRight = baseMask.x + baseMask.width;
      const changedSeg = segments[matchCount];
      const startX = changedSeg ? changedSeg.x : origRight + 3;
      const remMaskWidth = Math.max(0, origRight - startX);
      const remainingText = newTokens.slice(matchCount).join(' ');

      return {
        maskRect:
          remMaskWidth > 0
            ? {
                ...baseMask,
                x: startX - 1,
                width: remMaskWidth + 2,
              }
            : null,
        drawX: startX,
        drawY: y,
        drawText: remainingText,
        drawWidth: Math.max(24, width - (startX - x)),
        drawHeight: height,
        textAlign,
      };
    }
  }

  // Also avoid unused parameter warnings while preserving clarity
  void origText;
  return {
    maskRect: baseMask,
    drawX: x,
    drawY: y,
    drawText: text,
    drawWidth: width,
    drawHeight: height,
    textAlign,
  };
}

/**
 * Resolves render items for either a single line or a multi-line paragraph.
 * Any untouched line inside a paragraph (or untouched prefix inside a line) is skipped
 * so original PDF crispness and conjuncts remain 100% intact.
 */
export function resolveTextRenderPlans(
  ov: TextOverlayElement,
  customFonts: CustomFont[] = []
): TextRenderPlanResult {
  const styleAndPosUnchanged =
    ov.sourceBlockId !== undefined &&
    ov.originalText !== undefined &&
    (!ov.originalColor || ov.color.toLowerCase() === ov.originalColor.toLowerCase()) &&
    (!ov.originalFontId || ov.fontId === ov.originalFontId) &&
    (!ov.originalFontSize || ov.fontSize === ov.originalFontSize) &&
    (ov.originalX === undefined || Math.abs(ov.x - ov.originalX) < 0.5) &&
    (ov.originalY === undefined || Math.abs(ov.y - ov.originalY) < 0.5);

  if (styleAndPosUnchanged && ov.text === ov.originalText) {
    return { shouldRender: false, items: [] };
  }

  const baseMask: PartialTextRenderItem['maskRect'] =
    ov.maskRect && ov.maskRect.enabled
      ? {
          x: ov.maskRect.x,
          y: ov.maskRect.y,
          width: ov.maskRect.width,
          height: ov.maskRect.height,
          padding: ov.maskRect.padding,
          color: ov.maskRect.color,
        }
      : null;

  // Paragraph / multi-block line-by-line preservation:
  // If line count matches sourceLines and style/pos is unchanged,
  // only mask & redraw the lines that changed — UNLESS a changed line wraps past the page margin,
  // in which case we reflow the full merged block cleanly like MS Word so lines don't overlap.
  if (
    styleAndPosUnchanged &&
    ov.sourceLines &&
    ov.sourceLines.length > 1
  ) {
    const editedLines = ov.text.split('\n');
    if (editedLines.length === ov.sourceLines.length) {
      const items: PartialTextRenderItem[] = [];
      let hasWrappedOverflow = false;
      for (let i = 0; i < ov.sourceLines.length; i++) {
        const srcLine = ov.sourceLines[i];
        const editedLine = editedLines[i];
        if (editedLine === srcLine.text) continue;

        const maxLineW = ov.maxPageWidth
          ? Math.max(40, ov.maxPageWidth - Math.max(0, srcLine.x - ov.x))
          : Math.max(srcLine.width, 40);

        if (
          ov.maxPageWidth &&
          measureLineWidthPt(editedLine, ov, customFonts) > maxLineW - 2
        ) {
          hasWrappedOverflow = true;
          break;
        }

        const lineMask: PartialTextRenderItem['maskRect'] = baseMask
          ? {
              x: srcLine.x,
              y: srcLine.y,
              width: srcLine.width,
              height: srcLine.height,
              padding: baseMask.padding,
              color: baseMask.color,
            }
          : null;

        items.push(
          buildSingleLinePartialPlan(
            editedLine,
            srcLine.text,
            srcLine.x,
            srcLine.y,
            Math.max(srcLine.width, 32),
            srcLine.height,
            srcLine.segments,
            lineMask,
            ov.textAlign
          )
        );
      }

      if (!hasWrappedOverflow) {
        if (items.length === 0) {
          return { shouldRender: false, items: [] };
        }
        return { shouldRender: true, items };
      }
    }
  }

  // Single-line partial prefix diff (only if it still stays within page margin on a single line)
  if (
    styleAndPosUnchanged &&
    (!ov.sourceLines || ov.sourceLines.length <= 1) &&
    !ov.text.includes('\n') &&
    (!ov.maxPageWidth || measureLineWidthPt(ov.text, ov, customFonts) <= ov.maxPageWidth - 2)
  ) {
    return {
      shouldRender: true,
      items: [
        buildSingleLinePartialPlan(
          ov.text,
          ov.originalText || '',
          ov.x,
          ov.y,
          ov.width,
          ov.height,
          ov.sourceSegments,
          baseMask,
          ov.textAlign
        ),
      ],
    };
  }

  const fullDrawWidth =
    ov.hasCustomWidth
      ? ov.maxPageWidth
        ? Math.min(Math.max(40, ov.width), ov.maxPageWidth)
        : ov.width
      : ov.maxPageWidth && (ov.textAlign === 'left' || ov.textAlign === 'justify' || Boolean(ov.mergedBlockIds?.length))
      ? Math.max(ov.width, ov.maxPageWidth)
      : ov.width;

  return {
    shouldRender: true,
    items: [
      {
        maskRect: baseMask,
        drawX: ov.x,
        drawY: ov.y,
        drawText: ov.text,
        drawWidth: fullDrawWidth,
        drawHeight: ov.height,
        textAlign: ov.textAlign,
      },
    ],
  };
}

export function resolvePartialTextRenderPlan(ov: TextOverlayElement): {
  shouldRender: boolean;
  maskRect: {
    x: number;
    y: number;
    width: number;
    height: number;
    padding: number;
    color: string;
  } | null;
  drawX: number;
  drawText: string;
  drawWidth: number;
} {
  const plan = resolveTextRenderPlans(ov);
  if (!plan.shouldRender || plan.items.length === 0) {
    return {
      shouldRender: false,
      maskRect: null,
      drawX: ov.x,
      drawText: '',
      drawWidth: ov.width,
    };
  }
  const first = plan.items[0];
  return {
    shouldRender: true,
    maskRect: first.maskRect,
    drawX: first.drawX,
    drawText: first.drawText,
    drawWidth: first.drawWidth,
  };
}

function dataUrlToUint8Array(dataUrl: string): { bytes: Uint8Array; isPng: boolean } {
  const isPng = dataUrl.startsWith('data:image/png');
  const base64 = dataUrl.split(',')[1];
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    bytes[i] = bin.charCodeAt(i);
  }
  return { bytes, isPng };
}

export async function exportEditedPdf(
  originalBytes: Uint8Array | null,
  pages: PdfPageModel[],
  overlays: OverlayElement[],
  customFonts: CustomFont[]
): Promise<Uint8Array> {
  const outDoc = await PDFDocument.create();
  outDoc.registerFontkit(fontkit);

  let srcDoc: PDFDocument | null = null;
  if (originalBytes) {
    srcDoc = await PDFDocument.load(originalBytes, { ignoreEncryption: true });
  }

  // Optional invisible Unicode searchable layer font
  let searchableFont: Awaited<ReturnType<PDFDocument['embedFont']>> | null = null;
  try {
    const fontResp = await fetch('/fonts/NotoSansBengali-Regular.ttf');
    if (fontResp.ok) {
      const fontBytes = await fontResp.arrayBuffer();
      searchableFont = await outDoc.embedFont(fontBytes);
    }
  } catch {
    // Non-fatal if offline font fetch skipped
  }

  for (const pageModel of pages) {
    let outPage;

    if (srcDoc && pageModel.originalPageIndex !== null) {
      const srcPage = srcDoc.getPage(pageModel.originalPageIndex);
      const srcRot = srcPage.getRotation().angle;
      const totalRot = ((pageModel.rotation % 360) + 360) % 360;

      if (totalRot === 0 && srcRot === 0) {
        const [copied] = await outDoc.copyPages(srcDoc, [pageModel.originalPageIndex]);
        outPage = outDoc.addPage(copied);
      } else {
        // Embed original page losslessly as vector Form XObject and apply clean page rotation
        const embeddedPage = await outDoc.embedPage(srcPage);
        const isQuarterTurn = totalRot === 90 || totalRot === 270;
        const targetW = isQuarterTurn ? pageModel.heightPt : pageModel.widthPt;
        const targetH = isQuarterTurn ? pageModel.widthPt : pageModel.heightPt;
        outPage = outDoc.addPage([targetW, targetH]);

        if (totalRot === 0) {
          outPage.drawPage(embeddedPage, { x: 0, y: 0, width: targetW, height: targetH });
        } else if (totalRot === 90) {
          outPage.drawPage(embeddedPage, {
            x: targetW,
            y: 0,
            width: pageModel.widthPt,
            height: pageModel.heightPt,
            rotate: degrees(90),
          });
        } else if (totalRot === 180) {
          outPage.drawPage(embeddedPage, {
            x: targetW,
            y: targetH,
            width: pageModel.widthPt,
            height: pageModel.heightPt,
            rotate: degrees(180),
          });
        } else if (totalRot === 270) {
          outPage.drawPage(embeddedPage, {
            x: 0,
            y: targetH,
            width: pageModel.widthPt,
            height: pageModel.heightPt,
            rotate: degrees(270),
          });
        }
      }
    } else {
      outPage = outDoc.addPage([pageModel.widthPt, pageModel.heightPt]);
      outPage.drawRectangle({
        x: 0,
        y: 0,
        width: pageModel.widthPt,
        height: pageModel.heightPt,
        color: rgb(1, 1, 1),
      });
    }

    const pageH = outPage.getHeight();
    const pageOverlays = overlays.filter((o) => o.pageId === pageModel.id);

    // 1. Draw masks ONLY for modified text lines/spans so untouched text remains original
    for (const ov of pageOverlays) {
      if (ov.kind === 'text') {
        const plan = resolveTextRenderPlans(ov, customFonts);
        if (!plan.shouldRender) continue;
        for (const item of plan.items) {
          if (item.maskRect) {
            const m = item.maskRect;
            const pad = m.padding;
            const { r, g, b } = hexToRgbTuple(m.color);
            outPage.drawRectangle({
              x: m.x - pad,
              y: pageH - (m.y + m.height + pad),
              width: m.width + pad * 2,
              height: m.height + pad * 2,
              color: rgb(r, g, b),
            });
          }
        }
      }
    }

    // 2. Draw patches & shapes
    for (const ov of pageOverlays) {
      if (ov.kind === 'patch') {
        const { r, g, b } = hexToRgbTuple(ov.fillColor);
        const border = hexToRgbTuple(ov.borderColor);
        outPage.drawRectangle({
          x: ov.x,
          y: pageH - (ov.y + ov.height),
          width: ov.width,
          height: ov.height,
          color: rgb(r, g, b),
          borderColor: ov.borderWidth > 0 ? rgb(border.r, border.g, border.b) : undefined,
          borderWidth: ov.borderWidth,
          opacity: ov.opacity,
        });
      } else if (ov.kind === 'shape') {
        const fill = hexToRgbTuple(ov.fillColor);
        const stroke = hexToRgbTuple(ov.strokeColor);
        if (ov.shapeType === 'line') {
          outPage.drawLine({
            start: { x: ov.x, y: pageH - (ov.y + ov.height / 2) },
            end: { x: ov.x + ov.width, y: pageH - (ov.y + ov.height / 2) },
            thickness: Math.max(1, ov.strokeWidth),
            color: rgb(stroke.r, stroke.g, stroke.b),
            opacity: ov.opacity,
          });
        } else {
          outPage.drawRectangle({
            x: ov.x,
            y: pageH - (ov.y + ov.height),
            width: ov.width,
            height: ov.height,
            color: ov.shapeType === 'highlight' || ov.fillColor !== 'transparent' ? rgb(fill.r, fill.g, fill.b) : undefined,
            borderColor: ov.strokeWidth > 0 ? rgb(stroke.r, stroke.g, stroke.b) : undefined,
            borderWidth: ov.strokeWidth,
            opacity: ov.shapeType === 'highlight' ? Math.min(0.38, ov.opacity) : ov.opacity,
          });
        }
      } else if (ov.kind === 'pen' && ov.points.length > 1) {
        const stroke = hexToRgbTuple(ov.strokeColor);
        for (let k = 1; k < ov.points.length; k++) {
          const p0 = ov.points[k - 1];
          const p1 = ov.points[k];
          outPage.drawLine({
            start: { x: ov.x + p0.x, y: pageH - (ov.y + p0.y) },
            end: { x: ov.x + p1.x, y: pageH - (ov.y + p1.y) },
            thickness: Math.max(1, ov.strokeWidth),
            color: rgb(stroke.r, stroke.g, stroke.b),
            opacity: ov.opacity,
          });
        }
      }
    }

    // 3. Draw images & signatures
    for (const ov of pageOverlays) {
      if (ov.kind === 'image') {
        const { bytes, isPng } = dataUrlToUint8Array(ov.dataUrl);
        const embeddedImg = isPng
          ? await outDoc.embedPng(bytes)
          : await outDoc.embedJpg(bytes);
        outPage.drawImage(embeddedImg, {
          x: ov.x,
          y: pageH - (ov.y + ov.height),
          width: ov.width,
          height: ov.height,
          opacity: ov.opacity,
        });
      }
    }

    // 4. Draw high-DPI HarfBuzz-shaped Bangla, Arabic & English text overlays (only modified spans/lines)
    for (const ov of pageOverlays) {
      if (ov.kind === 'text') {
        const plan = resolveTextRenderPlans(ov, customFonts);
        if (!plan.shouldRender) continue;

        for (const item of plan.items) {
          if (item.drawText.trim().length === 0) continue;

          if (searchableFont) {
            try {
              outPage.drawText(item.drawText.replace(/\n/g, ' '), {
                x: item.drawX,
                y: pageH - (item.drawY + ov.fontSize * 0.9),
                size: Math.max(6, ov.fontSize * 0.85),
                font: searchableFont,
                opacity: 0,
              });
            } catch {
              // Skip invisible layer if text contains unsupported symbol
            }
          }

          const pageAvailWidth = Math.max(40, pageModel.widthPt - item.drawX - 16);
          const partialOv: TextOverlayElement = {
            ...ov,
            x: item.drawX,
            y: item.drawY,
            width: item.drawWidth,
            height: item.drawHeight,
            text: item.drawText,
            maxPageWidth: ov.maxPageWidth ? Math.min(ov.maxPageWidth, pageAvailWidth) : pageAvailWidth,
            hasCustomWidth: ov.hasCustomWidth || item.drawText.includes('\n'),
          };
          const { pngBytes, widthPt, heightPt } = await renderTextOverlayToHighDpiPng(
            partialOv,
            customFonts,
            EXPORT_TEXT_SCALE
          );
          const textPng = await outDoc.embedPng(pngBytes);
          outPage.drawImage(textPng, {
            x: item.drawX,
            y: pageH - (item.drawY + heightPt),
            width: widthPt,
            height: heightPt,
          });
        }
      }
    }
  }

  return await outDoc.save();
}

export async function samplePixelColorFromImage(
  imageDataUrl: string,
  normX: number,
  normY: number
): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0);
      const px = Math.max(0, Math.min(img.width - 1, Math.round(normX * img.width)));
      const py = Math.max(0, Math.min(img.height - 1, Math.round(normY * img.height)));
      const data = ctx.getImageData(px, py, 1, 1).data;
      resolve(rgbToHex(data[0], data[1], data[2]));
    };
    img.src = imageDataUrl;
  });
}

async function renderSampleLinePng(
  text: string,
  fontCss: string,
  fontSizePt: number,
  fontWeight: 'normal' | 'bold',
  color: string,
  widthPt: number,
  align: 'left' | 'center' | 'right' = 'left'
): Promise<{ pngBytes: Uint8Array; heightPt: number }> {
  const scale = 4;
  const canvas = document.createElement('canvas');
  canvas.width = Math.ceil(widthPt * scale);
  canvas.height = Math.ceil(fontSizePt * 1.55 * scale);
  const ctx = canvas.getContext('2d')!;
  ctx.font = `${fontWeight} ${fontSizePt * scale}px ${fontCss}`;
  ctx.fillStyle = color;
  ctx.textBaseline = 'alphabetic';

  const measured = ctx.measureText(text).width;
  let x = 0;
  if (align === 'center') x = Math.max(0, (canvas.width - measured) / 2);
  if (align === 'right') x = Math.max(0, canvas.width - measured);

  ctx.fillText(text, x, fontSizePt * 1.05 * scale);

  const blob = await new Promise<Blob>((r) => canvas.toBlob((b) => r(b!), 'image/png'));
  return {
    pngBytes: new Uint8Array(await blob.arrayBuffer()),
    heightPt: canvas.height / scale,
  };
}

export async function generateSampleBilingualPdf(): Promise<Uint8Array> {
  await ensureStudioFontsLoaded();

  const doc = await PDFDocument.create();
  doc.registerFontkit(fontkit);

  const sansBnResp = await fetch('/fonts/NotoSansBengali-Regular.ttf');
  const sansBnBoldResp = await fetch('/fonts/NotoSansBengali-Bold.ttf');
  const serifBnResp = await fetch('/fonts/NotoSerifBengali-Regular.ttf');
  const sansEnResp = await fetch('/fonts/NotoSans-Regular.ttf');

  const fontBn = await doc.embedFont(await sansBnResp.arrayBuffer());
  const fontBnBold = await doc.embedFont(await sansBnBoldResp.arrayBuffer());
  const fontBnSerif = await doc.embedFont(await serifBnResp.arrayBuffer());
  const fontEn = await doc.embedFont(await sansEnResp.arrayBuffer());

  // PAGE 1: Bilingual Official Invoice & Service Notice
  const page1 = doc.addPage([595, 842]); // A4
  const h1 = 842;

  // Crisp paper border & header banner (design elements preserved on edit!)
  page1.drawRectangle({ x: 0, y: 0, width: 595, height: 842, color: rgb(1, 1, 1) });
  page1.drawRectangle({ x: 36, y: h1 - 138, width: 523, height: 102, color: rgb(0.08, 0.16, 0.34) });
  page1.drawRectangle({ x: 36, y: 36, width: 523, height: 770, borderColor: rgb(0.84, 0.87, 0.91), borderWidth: 1 });

  // Accent bar inside banner
  page1.drawRectangle({ x: 36, y: h1 - 142, width: 523, height: 4, color: rgb(0.15, 0.39, 0.92) });

  // Helper to draw extractable invisible Unicode text + crisp HarfBuzz-shaped visual PNG
  const drawBilingualLine = async (
    page: typeof page1,
    opts: {
      text: string;
      x: number;
      topY: number;
      width: number;
      size: number;
      bold?: boolean;
      serif?: boolean;
      color: string;
      align?: 'left' | 'center' | 'right';
      pdfFont?: typeof fontBn;
    }
  ) => {
    const pageH = page.getHeight();
    const css = opts.serif
      ? '"Noto Serif Bengali Local", "Noto Serif Local", serif'
      : '"Noto Sans Bengali Local", "Noto Sans Local", sans-serif';
    const { pngBytes, heightPt } = await renderSampleLinePng(
      opts.text,
      css,
      opts.size,
      opts.bold ? 'bold' : 'normal',
      opts.color,
      opts.width,
      opts.align || 'left'
    );
    const png = await doc.embedPng(pngBytes);
    page.drawImage(png, {
      x: opts.x,
      y: pageH - (opts.topY + heightPt),
      width: opts.width,
      height: heightPt,
    });

    // Extractable text layer at exact position for pdfjs-dist getTextContent()
    const chosenFont = opts.pdfFont || (opts.bold ? fontBnBold : fontBn);
    const estW = opts.text.length * opts.size * 0.45;
    let textX = opts.x;
    if (opts.align === 'right') textX = Math.max(opts.x, opts.x + opts.width - estW);
    if (opts.align === 'center') textX = Math.max(opts.x, opts.x + (opts.width - estW) / 2);

    try {
      page.drawText(opts.text, {
        x: textX,
        y: pageH - (opts.topY + opts.size * 1.05),
        size: opts.size,
        font: chosenFont,
        opacity: 0,
      });
    } catch {
      // ignore fallback
    }
  };

  await drawBilingualLine(page1, {
    text: 'বেঙ্গল টেক্সটাইল অ্যান্ড ডিজাইন লিমিটেড',
    x: 56,
    topY: 54,
    width: 340,
    size: 18,
    bold: true,
    color: '#FFFFFF',
  });

  await drawBilingualLine(page1, {
    text: 'Bengal Textile & Design Ltd. · Dhaka 1212',
    x: 56,
    topY: 82,
    width: 320,
    size: 11,
    color: '#CBD5E1',
    pdfFont: fontEn,
  });

  await drawBilingualLine(page1, {
    text: 'INVOICE #BTD-2026-084',
    x: 375,
    topY: 60,
    width: 164,
    size: 12,
    bold: true,
    color: '#FFFFFF',
    align: 'right',
    pdfFont: fontEn,
  });

  await drawBilingualLine(page1, {
    text: 'তারিখ: ১৭ নভেম্বর, ২০২৬',
    x: 375,
    topY: 82,
    width: 164,
    size: 10.5,
    color: '#E2E8F0',
    align: 'right',
  });

  // Info Card Region
  page1.drawRectangle({
    x: 56,
    y: h1 - 246,
    width: 483,
    height: 82,
    color: rgb(0.97, 0.98, 0.99),
    borderColor: rgb(0.88, 0.91, 0.94),
    borderWidth: 1,
  });

  await drawBilingualLine(page1, {
    text: 'প্রাপক: জনাব রাশেদুল ইসলাম করিম',
    x: 72,
    topY: 176,
    width: 250,
    size: 12,
    bold: true,
    color: '#0F172A',
  });

  await drawBilingualLine(page1, {
    text: 'Client: Rashedul Islam · Gulshan Avenue, Dhaka',
    x: 72,
    topY: 198,
    width: 310,
    size: 10.5,
    color: '#475569',
    pdfFont: fontEn,
  });

  await drawBilingualLine(page1, {
    text: 'সংযুক্ত প্রকল্প: বাংলা ও ইংরেজি মুদ্রণ প্যাকেজ',
    x: 72,
    topY: 218,
    width: 340,
    size: 10.5,
    color: '#334155',
  });

  // Table Header
  page1.drawRectangle({
    x: 56,
    y: h1 - 302,
    width: 483,
    height: 32,
    color: rgb(0.93, 0.95, 0.98),
  });

  await drawBilingualLine(page1, {
    text: 'বিবরণ (Description)',
    x: 72,
    topY: 277,
    width: 240,
    size: 11,
    bold: true,
    color: '#1E293B',
  });

  await drawBilingualLine(page1, {
    text: 'পরিমাণ (Qty)',
    x: 330,
    topY: 277,
    width: 80,
    size: 11,
    bold: true,
    color: '#1E293B',
    align: 'center',
  });

  await drawBilingualLine(page1, {
    text: 'মোট মূল্য (BDT)',
    x: 425,
    topY: 277,
    width: 100,
    size: 11,
    bold: true,
    color: '#1E293B',
    align: 'right',
  });

  // Table Rows
  const rows = [
    {
      desc: '১. বাংলা ও ইংরেজি ব্রোশিউর ডিজাইন ও প্রিন্ট',
      qty: '500 pcs',
      amt: '18,500.00',
    },
    {
      desc: '২. কাস্টম ফন্ট ও টাইপোগ্রাফি সেটআপ (Custom Fonts)',
      qty: '1 set',
      amt: '6,200.00',
    },
    {
      desc: '৩. কর্পোরেট প্যাকেজিং ও লেবেলিং সেবা',
      qty: '250 units',
      amt: '12,800.00',
    },
  ];

  for (let i = 0; i < rows.length; i++) {
    const rowTop = 316 + i * 42;
    page1.drawLine({
      start: { x: 56, y: h1 - (rowTop + 28) },
      end: { x: 539, y: h1 - (rowTop + 28) },
      thickness: 0.75,
      color: rgb(0.88, 0.91, 0.94),
    });

    await drawBilingualLine(page1, {
      text: rows[i].desc,
      x: 72,
      topY: rowTop,
      width: 260,
      size: 11,
      color: '#1E293B',
    });

    await drawBilingualLine(page1, {
      text: rows[i].qty,
      x: 330,
      topY: rowTop,
      width: 80,
      size: 10.5,
      color: '#475569',
      align: 'center',
      pdfFont: fontEn,
    });

    await drawBilingualLine(page1, {
      text: rows[i].amt,
      x: 425,
      topY: rowTop,
      width: 100,
      size: 10.5,
      bold: true,
      color: '#0F172A',
      align: 'right',
      pdfFont: fontEn,
    });
  }

  // Total Box
  page1.drawRectangle({
    x: 325,
    y: h1 - 510,
    width: 214,
    height: 44,
    color: rgb(0.95, 0.97, 1.0),
    borderColor: rgb(0.75, 0.84, 0.98),
    borderWidth: 1,
  });

  await drawBilingualLine(page1, {
    text: 'সর্বমোট পরিশোধযোগ্য:',
    x: 338,
    topY: 478,
    width: 120,
    size: 11,
    bold: true,
    color: '#1E3A8A',
  });

  await drawBilingualLine(page1, {
    text: '37,500 BDT',
    x: 452,
    topY: 478,
    width: 76,
    size: 12,
    bold: true,
    color: '#1D4ED8',
    align: 'right',
    pdfFont: fontEn,
  });

  // Notice Paragraph (Serif Bangla)
  await drawBilingualLine(page1, {
    text: 'বিশেষ বিজ্ঞপ্তি ও শর্তাবলী (Terms & Conditions):',
    x: 56,
    topY: 548,
    width: 340,
    size: 12,
    bold: true,
    serif: true,
    color: '#0F172A',
    pdfFont: fontBnSerif,
  });

  await drawBilingualLine(page1, {
    text: 'এই নথির যেকোনো বাংলা বা ইংরেজি লেখায় ক্লিক করে সরাসরি পরিবর্তন করুন।',
    x: 56,
    topY: 576,
    width: 460,
    size: 11,
    serif: true,
    color: '#334155',
    pdfFont: fontBnSerif,
  });

  await drawBilingualLine(page1, {
    text: 'Click any line above to edit Bangla conjuncts or English figures directly.',
    x: 56,
    topY: 600,
    width: 460,
    size: 10.5,
    color: '#475569',
    pdfFont: fontEn,
  });

  // Signature Footer
  page1.drawLine({
    start: { x: 380, y: 110 },
    end: { x: 525, y: 110 },
    thickness: 1,
    color: rgb(0.58, 0.64, 0.72),
  });

  await drawBilingualLine(page1, {
    text: 'অনুমোদিত স্বাক্ষর (Authorized)',
    x: 375,
    topY: 740,
    width: 155,
    size: 10,
    color: '#475569',
    align: 'center',
  });

  // PAGE 2: Bilingual Official Letter / Certificate
  const page2 = doc.addPage([595, 842]);
  page2.drawRectangle({ x: 0, y: 0, width: 595, height: 842, color: rgb(1, 1, 1) });
  page2.drawRectangle({ x: 42, y: 42, width: 511, height: 758, borderColor: rgb(0.12, 0.25, 0.55), borderWidth: 1.5 });
  page2.drawRectangle({ x: 48, y: 48, width: 499, height: 746, borderColor: rgb(0.80, 0.85, 0.92), borderWidth: 0.75 });

  await drawBilingualLine(page2, {
    text: 'প্রত্যয়নপত্র ও স্বীকৃতি স্মারক',
    x: 80,
    topY: 96,
    width: 435,
    size: 20,
    bold: true,
    serif: true,
    color: '#1E3A8A',
    align: 'center',
    pdfFont: fontBnSerif,
  });

  await drawBilingualLine(page2, {
    text: 'CERTIFICATE OF EXCELLENCE · 2026',
    x: 80,
    topY: 132,
    width: 435,
    size: 11,
    bold: true,
    color: '#64748B',
    align: 'center',
    pdfFont: fontEn,
  });

  await drawBilingualLine(page2, {
    text: 'এই মর্মে প্রত্যয়ন করা যাচ্ছে যে, তানভীর আহমেদ চৌধুরী',
    x: 80,
    topY: 210,
    width: 435,
    size: 13,
    serif: true,
    color: '#0F172A',
    align: 'center',
    pdfFont: fontBnSerif,
  });

  await drawBilingualLine(page2, {
    text: 'সফলভাবে বাংলা ও ইংরেজি ডিজিটাল প্রকাশনা কর্মশালা সম্পন্ন করেছেন।',
    x: 80,
    topY: 242,
    width: 435,
    size: 12,
    serif: true,
    color: '#334155',
    align: 'center',
    pdfFont: fontBnSerif,
  });

  await drawBilingualLine(page2, {
    text: 'Awarded for exemplary typography & bilingual layout precision.',
    x: 80,
    topY: 280,
    width: 435,
    size: 11,
    color: '#475569',
    align: 'center',
    pdfFont: fontEn,
  });

  return await doc.save();
}

export async function exportPageToImageBlob(
  originalBytes: Uint8Array | null,
  pageModel: PdfPageModel,
  overlays: OverlayElement[],
  customFonts: CustomFont[],
  format: 'png' | 'jpeg',
  quality: ExportImageQuality = 'fullhd'
): Promise<Blob> {
  await ensureStudioFontsLoaded();

  const totalRot = ((pageModel.rotation % 360) + 360) % 360;
  const isQuarter = totalRot === 90 || totalRot === 270;
  const displayW = isQuarter ? pageModel.heightPt : pageModel.widthPt;
  const displayH = isQuarter ? pageModel.widthPt : pageModel.heightPt;

  const targetMinEdge = quality === 'uhd' ? 2880 : quality === 'hd' ? 1280 : 1920;
  const maxScale = quality === 'uhd' ? 5.2 : quality === 'hd' ? 2.5 : 4.0;
  const minEdge = Math.min(displayW, displayH);
  const scale = Math.min(maxScale, Math.max(2.0, targetMinEdge / minEdge));

  const outCanvas = document.createElement('canvas');
  outCanvas.width = Math.round(displayW * scale);
  outCanvas.height = Math.round(displayH * scale);
  const ctx = outCanvas.getContext('2d')!;

  // White paper background
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, outCanvas.width, outCanvas.height);

  // 1. Render original PDF vector page directly at Full HD scale if available
  if (originalBytes && pageModel.originalPageIndex !== null) {
    const loadingTask = pdfjsLib.getDocument({
      data: originalBytes.slice(),
      useSystemFonts: true,
    });
    const pdfDoc = await loadingTask.promise;
    const pdfPage = await pdfDoc.getPage(pageModel.originalPageIndex + 1);
    const viewport = pdfPage.getViewport({ scale });

    const baseCanvas = document.createElement('canvas');
    baseCanvas.width = Math.ceil(viewport.width);
    baseCanvas.height = Math.ceil(viewport.height);
    const baseCtx = baseCanvas.getContext('2d')!;
    baseCtx.fillStyle = '#ffffff';
    baseCtx.fillRect(0, 0, baseCanvas.width, baseCanvas.height);
    await pdfPage.render({
      canvasContext: baseCtx,
      viewport,
      canvas: baseCanvas,
    }).promise;

    ctx.save();
    if (totalRot === 90) {
      ctx.translate(outCanvas.width, 0);
      ctx.rotate(Math.PI / 2);
    } else if (totalRot === 180) {
      ctx.translate(outCanvas.width, outCanvas.height);
      ctx.rotate(Math.PI);
    } else if (totalRot === 270) {
      ctx.translate(0, outCanvas.height);
      ctx.rotate(-Math.PI / 2);
    }
    ctx.drawImage(baseCanvas, 0, 0);
    ctx.restore();
  }

  const pageOverlays = overlays.filter((o) => o.pageId === pageModel.id);

  // 2. Draw masks covering ONLY modified original text lines/spans
  for (const ov of pageOverlays) {
    if (ov.kind === 'text') {
      const plan = resolveTextRenderPlans(ov, customFonts);
      if (!plan.shouldRender) continue;
      for (const item of plan.items) {
        if (item.maskRect) {
          const m = item.maskRect;
          const pad = m.padding;
          ctx.save();
          ctx.fillStyle = m.color;
          ctx.fillRect(
            (m.x - pad) * scale,
            (m.y - pad) * scale,
            (m.width + pad * 2) * scale,
            (m.height + pad * 2) * scale
          );
          ctx.restore();
        }
      }
    }
  }

  // 3. Draw patches & shapes
  for (const ov of pageOverlays) {
    if (ov.kind === 'patch') {
      ctx.save();
      ctx.globalAlpha = ov.opacity;
      ctx.fillStyle = ov.fillColor;
      ctx.fillRect(ov.x * scale, ov.y * scale, ov.width * scale, ov.height * scale);
      if (ov.borderWidth > 0) {
        ctx.strokeStyle = ov.borderColor;
        ctx.lineWidth = ov.borderWidth * scale;
        ctx.strokeRect(ov.x * scale, ov.y * scale, ov.width * scale, ov.height * scale);
      }
      ctx.restore();
    } else if (ov.kind === 'shape') {
      ctx.save();
      ctx.globalAlpha = ov.shapeType === 'highlight' ? Math.min(0.38, ov.opacity) : ov.opacity;
      if (ov.shapeType === 'line') {
        ctx.strokeStyle = ov.strokeColor;
        ctx.lineWidth = Math.max(1, ov.strokeWidth) * scale;
        ctx.beginPath();
        ctx.moveTo(ov.x * scale, (ov.y + ov.height / 2) * scale);
        ctx.lineTo((ov.x + ov.width) * scale, (ov.y + ov.height / 2) * scale);
        ctx.stroke();
      } else {
        if (ov.shapeType === 'highlight' || ov.fillColor !== 'transparent') {
          ctx.fillStyle = ov.fillColor;
          ctx.fillRect(ov.x * scale, ov.y * scale, ov.width * scale, ov.height * scale);
        }
        if (ov.strokeWidth > 0) {
          ctx.strokeStyle = ov.strokeColor;
          ctx.lineWidth = ov.strokeWidth * scale;
          ctx.strokeRect(ov.x * scale, ov.y * scale, ov.width * scale, ov.height * scale);
        }
      }
      ctx.restore();
    } else if (ov.kind === 'pen' && ov.points.length > 1) {
      ctx.save();
      ctx.globalAlpha = ov.opacity;
      ctx.strokeStyle = ov.strokeColor;
      ctx.lineWidth = Math.max(1, ov.strokeWidth) * scale;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo((ov.x + ov.points[0].x) * scale, (ov.y + ov.points[0].y) * scale);
      for (let k = 1; k < ov.points.length; k++) {
        ctx.lineTo((ov.x + ov.points[k].x) * scale, (ov.y + ov.points[k].y) * scale);
      }
      ctx.stroke();
      ctx.restore();
    }
  }

  // 4. Draw placed images & signatures
  for (const ov of pageOverlays) {
    if (ov.kind === 'image') {
      await new Promise<void>((resolve) => {
        const img = new Image();
        img.onload = () => {
          ctx.save();
          ctx.globalAlpha = ov.opacity;
          ctx.drawImage(
            img,
            ov.x * scale,
            ov.y * scale,
            ov.width * scale,
            ov.height * scale
          );
          ctx.restore();
          resolve();
        };
        img.onerror = () => resolve();
        img.src = ov.dataUrl;
      });
    }
  }

  // 5. Draw HarfBuzz-shaped Bangla, Arabic & English text overlays (only modified spans/lines)
  for (const ov of pageOverlays) {
    if (ov.kind === 'text') {
      const plan = resolveTextRenderPlans(ov, customFonts);
      if (!plan.shouldRender) continue;

      for (const item of plan.items) {
        if (item.drawText.trim().length === 0) continue;

        const cssFamily = resolveCssFontFamily(ov.fontId, customFonts);
        ctx.save();
        ctx.globalAlpha = ov.opacity;
        ctx.font = `${ov.fontStyle} ${ov.fontWeight} ${ov.fontSize * scale}px ${cssFamily}`;
        ctx.fillStyle = ov.color;
        ctx.textBaseline = 'alphabetic';
        if ('letterSpacing' in ctx) {
          (ctx as CanvasRenderingContext2D & { letterSpacing: string }).letterSpacing = `${ov.letterSpacing * scale}px`;
        }

        const pageAvailWidthPt = Math.max(40, displayW - item.drawX - 16);
        const maxAllowedWidthPt = ov.maxPageWidth
          ? Math.min(ov.maxPageWidth, pageAvailWidthPt)
          : pageAvailWidthPt;
        const measuredRawWidthPt = ctx.measureText(item.drawText).width / scale + 6;
        const shouldWrap =
          item.drawText.includes('\n') ||
          Boolean(ov.hasCustomWidth) ||
          measuredRawWidthPt > maxAllowedWidthPt;

        const targetBoxWidthPt = ov.hasCustomWidth
          ? Math.min(Math.max(40, item.drawWidth), maxAllowedWidthPt)
          : shouldWrap
          ? maxAllowedWidthPt
          : Math.max(item.drawWidth, measuredRawWidthPt);
        const maxWidthPx = Math.max(20 * scale, targetBoxWidthPt * scale);

        const lines = shouldWrap
          ? wrapTextLinesWithMeta(ctx, item.drawText, maxWidthPx)
          : [{ text: item.drawText, isParagraphEnd: true }];
        const lineHeightPx = ov.fontSize * ov.lineHeight * scale;
        const halfLeadingPx = Math.max(0, ((ov.lineHeight - 1) / 2) * ov.fontSize * scale);
        const ascentPx = ov.fontSize * 0.86 * scale + halfLeadingPx;

        lines.forEach((line, idx) => {
          const yPx = item.drawY * scale + ascentPx + idx * lineHeightPx;
          drawAlignedCanvasLine(
            ctx,
            line,
            item.drawX * scale,
            yPx,
            shouldWrap
              ? maxWidthPx
              : Math.max(maxWidthPx, ctx.measureText(line.text).width),
            item.textAlign
          );
        });
        ctx.restore();
      }
    }
  }

  const mimeType = format === 'png' ? 'image/png' : 'image/jpeg';
  return await new Promise<Blob>((resolve) =>
    outCanvas.toBlob((b) => resolve(b!), mimeType, 0.95)
  );
}

function resolveWordFontName(fontId: string, customFonts: CustomFont[]): string {
  const custom = customFonts.find((f) => f.id === fontId);
  if (custom) return custom.name;
  const bundled = BUNDLED_FONTS.find((f) => f.id === fontId);
  return bundled ? bundled.label : 'Noto Sans Bengali';
}

export async function exportDocumentToDocxBytes(
  pages: PdfPageModel[],
  overlays: OverlayElement[],
  customFonts: CustomFont[]
): Promise<Uint8Array> {
  const docChildren: Paragraph[] = [];

  for (let pIdx = 0; pIdx < pages.length; pIdx++) {
    const page = pages[pIdx];
    const pageOverlays = overlays.filter((o) => o.pageId === page.id);

    const replacedBlockIds = new Set<string>();
    for (const o of pageOverlays) {
      if (o.kind === 'text') {
        if (o.sourceBlockId) replacedBlockIds.add(o.sourceBlockId);
        for (const mid of o.mergedBlockIds || []) {
          replacedBlockIds.add(mid);
        }
      }
    }

    type DocxItem =
      | {
          kind: 'text';
          x: number;
          y: number;
          text: string;
          fontName: string;
          fontSize: number;
          bold: boolean;
          italic: boolean;
          colorHex: string;
          align: 'left' | 'center' | 'right' | 'justify';
        }
      | {
          kind: 'image';
          x: number;
          y: number;
          widthPx: number;
          heightPx: number;
          dataUrl: string;
        };

    const items: DocxItem[] = [];

    for (const blk of page.extractedBlocks) {
      if (replacedBlockIds.has(blk.id)) continue;
      items.push({
        kind: 'text',
        x: blk.x,
        y: blk.y,
        text: blk.originalText,
        fontName: resolveWordFontName(blk.matchedFontId, customFonts),
        fontSize: blk.fontSize,
        bold: blk.fontWeight === 'bold',
        italic: blk.fontStyle === 'italic',
        colorHex: blk.color.replace('#', ''),
        align: 'left',
      });
    }

    for (const ov of pageOverlays) {
      if (ov.kind === 'text' && ov.text.trim()) {
        items.push({
          kind: 'text',
          x: ov.x,
          y: ov.y,
          text: ov.text,
          fontName: resolveWordFontName(ov.fontId, customFonts),
          fontSize: ov.fontSize,
          bold: ov.fontWeight === 'bold',
          italic: ov.fontStyle === 'italic',
          colorHex: ov.color.replace('#', ''),
          align: ov.textAlign,
        });
      } else if (ov.kind === 'image') {
        items.push({
          kind: 'image',
          x: ov.x,
          y: ov.y,
          widthPx: Math.round(ov.width * 1.33),
          heightPx: Math.round(ov.height * 1.33),
          dataUrl: ov.dataUrl,
        });
      }
    }

    // Sort top-to-bottom, then left-to-right
    items.sort((a, b) => {
      if (Math.abs(a.y - b.y) > 8) return a.y - b.y;
      return a.x - b.x;
    });

    // Group text items that share the same visual line into single Word paragraphs separated by tabs/spaces
    let i = 0;
    while (i < items.length) {
      const cur = items[i];
      if (cur.kind === 'image') {
        const { bytes, isPng } = dataUrlToUint8Array(cur.dataUrl);
        docChildren.push(
          new Paragraph({
            children: [
              new ImageRun({
                data: bytes,
                transformation: {
                  width: Math.max(40, cur.widthPx),
                  height: Math.max(20, cur.heightPx),
                },
                type: isPng ? 'png' : 'jpg',
              }),
            ],
            spacing: { after: 120 },
          })
        );
        i += 1;
        continue;
      }

      const lineGroup: Extract<DocxItem, { kind: 'text' }>[] = [cur];
      while (
        i + 1 < items.length &&
        items[i + 1].kind === 'text' &&
        Math.abs(items[i + 1].y - cur.y) <= 8
      ) {
        lineGroup.push(items[i + 1] as Extract<DocxItem, { kind: 'text' }>);
        i += 1;
      }

      const runs: TextRun[] = [];
      lineGroup.forEach((seg, segIdx) => {
        if (segIdx > 0) {
          runs.push(new TextRun({ text: '    ' }));
        }
        const splitLines = seg.text.split('\n');
        splitLines.forEach((subLine, lineIdx) => {
          if (lineIdx > 0) {
            runs.push(new TextRun({ break: 1 }));
          }
          runs.push(
            new TextRun({
              text: subLine,
              font: seg.fontName,
              size: Math.max(12, Math.round(seg.fontSize * 2)),
              bold: seg.bold,
              italics: seg.italic,
              color: seg.colorHex || '0F172A',
            })
          );
        });
      });

      const alignEnum =
        cur.align === 'center'
          ? AlignmentType.CENTER
          : cur.align === 'right'
          ? AlignmentType.RIGHT
          : cur.align === 'justify'
          ? AlignmentType.JUSTIFIED
          : isRtlText(lineGroup.map((g) => g.text).join(' '))
          ? AlignmentType.RIGHT
          : AlignmentType.LEFT;

      const isParaRtl = isRtlText(lineGroup.map((g) => g.text).join(' '));

      docChildren.push(
        new Paragraph({
          children: runs,
          alignment: alignEnum,
          bidirectional: isParaRtl,
          spacing: { after: 110 },
        })
      );

      i += 1;
    }

    if (pIdx < pages.length - 1) {
      docChildren.push(new Paragraph({ children: [new PageBreak()] }));
    }
  }

  const wordDoc = new Document({
    sections: [
      {
        properties: {},
        children:
          docChildren.length > 0
            ? docChildren
            : [new Paragraph({ children: [new TextRun('')] })],
      },
    ],
  });

  const blob = await Packer.toBlob(wordDoc);
  return new Uint8Array(await blob.arrayBuffer());
}
