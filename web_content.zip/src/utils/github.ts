import { FileItem } from '../types';
import { getFileLanguage } from './files';

export interface GitHubRepoInfo {
  owner: string;
  repo: string;
}

export function parseRepoString(input: string): GitHubRepoInfo | null {
  const trimmed = input.trim();
  // Support https://github.com/owner/repo or owner/repo
  const urlMatch = trimmed.match(/github\.com\/([^/]+)\/([^/#?]+)/);
  if (urlMatch) {
    return { owner: urlMatch[1], repo: urlMatch[2].replace(/\.git$/, '') };
  }
  const parts = trimmed.split('/');
  if (parts.length === 2 && parts[0] && parts[1]) {
    return { owner: parts[0], repo: parts[1].replace(/\.git$/, '') };
  }
  return null;
}

/**
 * Fetch all files from a GitHub repository using Git Trees API
 */
export async function importFromGitHub(
  repoInput: string,
  token?: string,
  branch?: string
): Promise<{ projectName: string; files: FileItem[] }> {
  const parsed = parseRepoString(repoInput);
  if (!parsed) {
    throw new Error('Invalid repository format. Please use "owner/repo" or full GitHub URL.');
  }

  const { owner, repo } = parsed;
  const headers: Record<string, string> = {
    Accept: 'application/vnd.github.v3+json',
  };
  if (token && token.trim()) {
    headers['Authorization'] = `token ${token.trim()}`;
  }

  // 1. Get repo details to know default branch if not provided
  let targetBranch = branch?.trim();
  if (!targetBranch) {
    const repoRes = await fetch(`https://api.github.com/repos/${owner}/${repo}`, { headers });
    if (!repoRes.ok) {
      if (repoRes.status === 404) {
        throw new Error(`Repository "${owner}/${repo}" not found or is private (Personal Access Token required).`);
      }
      const errJson = await repoRes.json().catch(() => ({}));
      throw new Error(errJson.message || `Failed to fetch repository info (Status ${repoRes.status})`);
    }
    const repoData = await repoRes.json();
    targetBranch = repoData.default_branch || 'main';
  }

  // 2. Fetch the git tree recursively
  const treeRes = await fetch(
    `https://api.github.com/repos/${owner}/${repo}/git/trees/${targetBranch}?recursive=1`,
    { headers }
  );
  if (!treeRes.ok) {
    const errJson = await treeRes.json().catch(() => ({}));
    throw new Error(errJson.message || `Failed to fetch branch tree (Status ${treeRes.status})`);
  }

  const treeData = await treeRes.json();
  const treeItems: Array<{ path: string; mode: string; type: 'blob' | 'tree'; sha: string; size?: number }> =
    treeData.tree || [];

  // Filter out git internals or heavy binaries
  const filtered = treeItems.filter((item) => {
    const p = item.path;
    if (p.startsWith('.git/') || p === '.gitignore' || p.includes('node_modules/') || p.startsWith('dist/')) {
      return false;
    }
    return true;
  });

  const filesMap: Record<string, FileItem> = {};
  const folderPathsToId: Record<string, string> = {};

  // First pass: create all directory nodes
  const dirPaths = filtered
    .filter((item) => item.type === 'tree')
    .map((item) => item.path)
    .sort((a, b) => a.split('/').length - b.split('/').length);

  for (const dirPath of dirPaths) {
    const parts = dirPath.split('/');
    const name = parts[parts.length - 1];
    const parentPath = parts.slice(0, -1).join('/');
    const id = `f_folder_${Math.random().toString(36).substring(2, 8)}`;
    folderPathsToId[dirPath] = id;

    filesMap[id] = {
      id,
      name,
      path: dirPath,
      content: '',
      language: 'plaintext',
      isFolder: true,
      parentId: parentPath ? folderPathsToId[parentPath] || null : null,
    };
  }

  // Second pass: fetch blobs for files
  const fileBlobs = filtered.filter((item) => item.type === 'blob');

  // Limit maximum files to avoid API rate limit (up to 40 files)
  const filesToFetch = fileBlobs.slice(0, 45);

  for (const item of filesToFetch) {
    const parts = item.path.split('/');
    const name = parts[parts.length - 1];
    const parentPath = parts.slice(0, -1).join('/');
    const lang = getFileLanguage(name);

    // Fetch raw content or blob
    let content = '';
    try {
      const blobRes = await fetch(
        `https://api.github.com/repos/${owner}/${repo}/git/blobs/${item.sha}`,
        { headers }
      );
      if (blobRes.ok) {
        const blobData = await blobRes.json();
        if (blobData.encoding === 'base64') {
          if (lang === 'image') {
            const ext = name.split('.').pop()?.toLowerCase() || 'png';
            content = `data:image/${ext === 'svg' ? 'svg+xml' : ext};base64,${blobData.content.replace(/\n/g, '')}`;
          } else {
            content = decodeURIComponent(
              atob(blobData.content.replace(/\n/g, ''))
                .split('')
                .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
                .join('')
            );
          }
        } else {
          content = blobData.content || '';
        }
      }
    } catch (err) {
      console.warn(`Failed to read blob for ${item.path}:`, err);
    }

    const id = `f_${Math.random().toString(36).substring(2, 8)}`;
    filesMap[id] = {
      id,
      name,
      path: item.path,
      content,
      language: lang,
      isFolder: false,
      parentId: parentPath ? folderPathsToId[parentPath] || null : null,
    };
  }

  return {
    projectName: repo,
    files: Object.values(filesMap),
  };
}

/**
 * Push current project files to a GitHub repository using Git Database API
 */
export async function pushToGitHub(params: {
  token: string;
  repoInput: string;
  files: FileItem[];
  commitMessage?: string;
  branch?: string;
}): Promise<{ commitUrl: string; branch: string }> {
  const { token, repoInput, files, commitMessage = 'Update from NEXORA Studio', branch = 'main' } = params;

  if (!token || !token.trim()) {
    throw new Error('GitHub Personal Access Token is required to push code.');
  }

  const parsed = parseRepoString(repoInput);
  if (!parsed) {
    throw new Error('Invalid repository format. Please enter "owner/repo" (e.g. amaan/my-project).');
  }

  const { owner, repo } = parsed;
  const headers = {
    Accept: 'application/vnd.github.v3+json',
    Authorization: `token ${token.trim()}`,
    'Content-Type': 'application/json',
  };

  // 1. Verify repo exists and token has access
  const repoRes = await fetch(`https://api.github.com/repos/${owner}/${repo}`, { headers });
  if (!repoRes.ok) {
    if (repoRes.status === 404) {
      throw new Error(
        `Repository "${owner}/${repo}" was not found. Please ensure the repository exists on your GitHub account and your token has the "repo" scope.`
      );
    }
    const err = await repoRes.json().catch(() => ({}));
    throw new Error(err.message || `Failed to access repository (${repoRes.status})`);
  }

  // 2. Get reference to current branch head
  let branchSha = '';
  const refRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/ref/heads/${branch}`, {
    headers,
  });

  if (refRes.ok) {
    const refData = await refRes.json();
    branchSha = refData.object.sha;
  } else {
    // If branch doesn't exist, check default branch or create reference
    const defaultRef = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/git/refs/heads`,
      { headers }
    );
    if (defaultRef.ok) {
      const allRefs = await defaultRef.json();
      if (allRefs.length > 0) {
        branchSha = allRefs[0].object.sha;
      }
    }
    if (!branchSha) {
      throw new Error(`Branch "${branch}" not found in repository "${owner}/${repo}". Please initialize repository with at least one commit.`);
    }
  }

  // 3. Build full path for every file
  function getFullPath(f: FileItem): string {
    const parts = [f.name];
    let curr = f.parentId;
    while (curr) {
      const p = files.find((item) => item.id === curr);
      if (!p) break;
      parts.unshift(p.name);
      curr = p.parentId;
    }
    return parts.join('/');
  }

  const nonFolderFiles = files.filter((f) => !f.isFolder);

  // 4. Create blobs for each file
  const treeNodes: Array<{ path: string; mode: string; type: 'blob'; sha: string }> = [];

  for (const file of nonFolderFiles) {
    const fullPath = getFullPath(file);
    let blobPayload: any;

    if (file.content?.startsWith('data:image/')) {
      const base64Content = file.content.split(',')[1];
      blobPayload = {
        content: base64Content || '',
        encoding: 'base64',
      };
    } else {
      blobPayload = {
        content: file.content || '',
        encoding: 'utf-8',
      };
    }

    const blobRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/blobs`, {
      method: 'POST',
      headers,
      body: JSON.stringify(blobPayload),
    });

    if (!blobRes.ok) {
      const err = await blobRes.json().catch(() => ({}));
      throw new Error(`Failed to create blob for "${fullPath}": ${err.message || blobRes.statusText}`);
    }

    const blobData = await blobRes.json();
    treeNodes.push({
      path: fullPath,
      mode: '100644',
      type: 'blob',
      sha: blobData.sha,
    });
  }

  // 5. Create git tree
  const treePayload = {
    base_tree: branchSha,
    tree: treeNodes,
  };

  const treeRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/trees`, {
    method: 'POST',
    headers,
    body: JSON.stringify(treePayload),
  });

  if (!treeRes.ok) {
    const err = await treeRes.json().catch(() => ({}));
    throw new Error(`Failed to create Git tree: ${err.message || treeRes.statusText}`);
  }
  const treeData = await treeRes.json();

  // 6. Create commit
  const commitPayload = {
    message: commitMessage,
    tree: treeData.sha,
    parents: [branchSha],
  };

  const commitRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/commits`, {
    method: 'POST',
    headers,
    body: JSON.stringify(commitPayload),
  });

  if (!commitRes.ok) {
    const err = await commitRes.json().catch(() => ({}));
    throw new Error(`Failed to create Git commit: ${err.message || commitRes.statusText}`);
  }
  const commitData = await commitRes.json();

  // 7. Update branch ref
  const updateRefRes = await fetch(
    `https://api.github.com/repos/${owner}/${repo}/git/refs/heads/${branch}`,
    {
      method: 'PATCH',
      headers,
      body: JSON.stringify({
        sha: commitData.sha,
        force: false,
      }),
    }
  );

  if (!updateRefRes.ok) {
    const err = await updateRefRes.json().catch(() => ({}));
    throw new Error(`Failed to update branch ${branch}: ${err.message || updateRefRes.statusText}`);
  }

  return {
    commitUrl: `https://github.com/${owner}/${repo}/commit/${commitData.sha}`,
    branch,
  };
}
