import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

export interface ParsedSpreadsheetResult {
  fileName: string;
  fileSizeBytes: number;
  fileSizeStr: string;
  fileType: 'xlsx' | 'xls' | 'csv';
  sheetNames: string[];
  selectedSheet: string;
  headers: string[];
  rows: Record<string, string>[];
  totalRows: number;
  workbook?: XLSX.WorkBook;
}

export interface SpreadsheetRowError {
  rowNumber: number;
  employeeCode?: string;
  name?: string;
  field?: string;
  value?: string;
  reason: string;
  suggestedAction?: string;
}

/**
 * Formats byte size into human readable string (KB, MB).
 */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Normalizes Excel date representations (serial numbers, Date objects, or formatted date strings)
 * into standard YYYY-MM-DD format.
 */
export function normalizeExcelDate(value: any): string {
  if (value === undefined || value === null || value === '') return '';

  // 1. If it's already a JS Date object
  if (value instanceof Date && !isNaN(value.getTime())) {
    return value.toISOString().split('T')[0];
  }

  // 2. If it's an Excel numeric serial number (e.g. 45291)
  if (typeof value === 'number' && !isNaN(value)) {
    // Excel serial dates: days since Jan 1 1900, with leap year bug offset
    if (value > 1000 && value < 100000) {
      try {
        const utcDays = Math.floor(value - 25569);
        const utcValue = utcDays * 86400;
        const dateInfo = new Date(utcValue * 1000);
        if (!isNaN(dateInfo.getTime())) {
          return dateInfo.toISOString().split('T')[0];
        }
      } catch {
        // Fallback
      }
    }
    return String(value);
  }

  const str = String(value).trim();
  if (!str) return '';

  // 3. If string is purely numeric serial (e.g. "45291")
  const numSerial = Number(str);
  if (!isNaN(numSerial) && numSerial > 1000 && numSerial < 100000 && !str.includes('-') && !str.includes('/')) {
    try {
      const utcDays = Math.floor(numSerial - 25569);
      const utcValue = utcDays * 86400;
      const dateInfo = new Date(utcValue * 1000);
      if (!isNaN(dateInfo.getTime())) {
        return dateInfo.toISOString().split('T')[0];
      }
    } catch {
      // Fallback
    }
  }

  // 4. ISO format: YYYY-MM-DD
  if (/^\d{4}-\d{1,2}-\d{1,2}/.test(str)) {
    const parts = str.split('T')[0].split('-');
    const year = parts[0];
    const month = parts[1].padStart(2, '0');
    const day = parts[2].padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  // 5. Slash or dash format: DD/MM/YYYY or MM/DD/YYYY
  const slashMatch = str.match(/^(\d{1,2})[\/\.-](\d{1,2})[\/\.-](\d{2,4})$/);
  if (slashMatch) {
    let p1 = parseInt(slashMatch[1], 10);
    let p2 = parseInt(slashMatch[2], 10);
    let year = parseInt(slashMatch[3], 10);
    if (year < 100) year += 2000;

    // Disambiguate day vs month
    let month = p2;
    let day = p1;
    if (p1 > 12 && p2 <= 12) {
      // Definitely DD/MM/YYYY
      day = p1;
      month = p2;
    } else if (p2 > 12 && p1 <= 12) {
      // Definitely MM/DD/YYYY
      month = p1;
      day = p2;
    }

    return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  }

  return str;
}

/**
 * Extracts headers and records from a specific worksheet in a workbook.
 */
export function extractWorksheetData(
  workbook: XLSX.WorkBook,
  sheetName: string
): { headers: string[]; rows: Record<string, string>[]; totalRows: number } {
  const worksheet = workbook.Sheets[sheetName];
  if (!worksheet) {
    return { headers: [], rows: [], totalRows: 0 };
  }

  // Convert worksheet to raw array-of-arrays
  const aoa: any[][] = XLSX.utils.sheet_to_json(worksheet, {
    header: 1,
    defval: '',
    raw: false,
    blankrows: false,
    dateNF: 'yyyy-mm-dd',
  });

  if (!aoa || aoa.length === 0) {
    return { headers: [], rows: [], totalRows: 0 };
  }

  // First non-empty row as headers
  let headerRowIndex = 0;
  while (headerRowIndex < aoa.length && (!aoa[headerRowIndex] || aoa[headerRowIndex].filter((c: any) => String(c).trim()).length === 0)) {
    headerRowIndex++;
  }

  if (headerRowIndex >= aoa.length) {
    return { headers: [], rows: [], totalRows: 0 };
  }

  const rawHeaderRow = aoa[headerRowIndex] || [];
  const headers: string[] = [];
  const usedHeadersCount: Record<string, number> = {};

  rawHeaderRow.forEach((col: any, idx: number) => {
    let title = String(col || '').trim();
    if (!title) {
      title = `Column_${idx + 1}`;
    }
    // Deduplicate identical header names
    if (usedHeadersCount[title]) {
      usedHeadersCount[title]++;
      title = `${title}_${usedHeadersCount[title]}`;
    } else {
      usedHeadersCount[title] = 1;
    }
    headers.push(title);
  });

  // Extract data rows
  const rows: Record<string, string>[] = [];
  for (let r = headerRowIndex + 1; r < aoa.length; r++) {
    const rowValues = aoa[r] || [];
    // Skip completely empty rows
    const hasValues = rowValues.some((val: any) => val !== undefined && val !== null && String(val).trim() !== '');
    if (!hasValues) continue;

    const rowObj: Record<string, string> = {};
    headers.forEach((h, hIdx) => {
      let val = rowValues[hIdx];
      if (val === undefined || val === null) {
        val = '';
      } else {
        val = String(val).trim();
      }
      rowObj[h] = val;
    });

    rows.push(rowObj);
  }

  return {
    headers,
    rows,
    totalRows: rows.length,
  };
}

/**
 * Universal file parser for .xlsx, .xls, and .csv files.
 * Handles multi-sheet workbooks, encoding, and Excel formatting.
 */
export async function parseSpreadsheetFile(file: File, maxSizeBytes: number = 25 * 1024 * 1024): Promise<ParsedSpreadsheetResult> {
  const fileName = file.name;
  const fileSizeBytes = file.size;
  const fileSizeStr = formatFileSize(fileSizeBytes);

  if (fileSizeBytes > maxSizeBytes) {
    throw new Error(`File is too large (${fileSizeStr}). Maximum supported size is ${formatFileSize(maxSizeBytes)}.`);
  }

  const ext = fileName.split('.').pop()?.toLowerCase();
  if (ext !== 'xlsx' && ext !== 'xls' && ext !== 'csv') {
    throw new Error('Unsupported file type. Please upload an Excel (.xlsx / .xls) or CSV file.');
  }

  const buffer = await file.arrayBuffer();

  // Parse workbook using SheetJS with codepage support and raw cell preservation
  let workbook: XLSX.WorkBook;
  try {
    workbook = XLSX.read(new Uint8Array(buffer), {
      type: 'array',
      cellDates: true,
      cellNF: true,
      raw: false,
    });
  } catch (err: any) {
    console.error('SheetJS parse error:', err);
    throw new Error(`Failed to parse file: ${err?.message || 'Corrupted or unreadable spreadsheet.'}`);
  }

  const sheetNames = workbook.SheetNames || [];
  if (sheetNames.length === 0) {
    throw new Error('No worksheets found in uploaded file.');
  }

  // By default select the first non-empty sheet or sheet named "Employees" / "Staff"
  let selectedSheet = sheetNames[0];
  const preferredSheet = sheetNames.find(
    (name) => /employee|staff|personnel|workforce/i.test(name)
  );
  if (preferredSheet) {
    selectedSheet = preferredSheet;
  }

  const { headers, rows, totalRows } = extractWorksheetData(workbook, selectedSheet);

  return {
    fileName,
    fileSizeBytes,
    fileSizeStr,
    fileType: ext as 'xlsx' | 'xls' | 'csv',
    sheetNames,
    selectedSheet,
    headers,
    rows,
    totalRows,
    workbook,
  };
}

/**
 * Generates and downloads a genuine .xlsx template for employee import.
 */
export function downloadExcelTemplate(): void {
  const templateData = [
    {
      'Employee ID': 'EMP-1001',
      'Full Name': 'Ali Raza',
      'Phone': '+1 555-0101',
      'Email': 'ali.raza@example.com',
      'Department': 'Field Operations',
      'Designation': 'Senior HVAC Technician',
      'Territory': 'North Metro Area',
      'Manager Name': 'Operations Lead',
      'Emergency Contact': '+1 555-0911',
      'Joining Date': '2024-01-15',
      'Status': 'active',
    },
    {
      'Employee ID': 'EMP-1002',
      'Full Name': 'Maryam Ahmed',
      'Phone': '+1 555-0102',
      'Email': 'maryam.ahmed@example.com',
      'Department': 'Installation & Dispatch',
      'Designation': 'Electrical Systems Specialist',
      'Territory': 'Downtown Business District',
      'Manager Name': 'Operations Lead',
      'Emergency Contact': '+1 555-0912',
      'Joining Date': '2024-03-01',
      'Status': 'active',
    },
    {
      'Employee ID': 'EMP-1003',
      'Full Name': 'Zain Malik',
      'Phone': '+1 555-0103',
      'Email': 'zain.malik@example.com',
      'Department': 'Maintenance Services',
      'Designation': 'Preventive Maintenance Lead',
      'Territory': 'South Harbor Logistics',
      'Manager Name': 'Sarah Jenkins',
      'Emergency Contact': '+1 555-0913',
      'Joining Date': '2024-05-10',
      'Status': 'active',
    },
  ];

  const worksheet = XLSX.utils.json_to_sheet(templateData);

  // Set column widths for comfortable reading
  worksheet['!cols'] = [
    { wch: 15 }, // Employee ID
    { wch: 22 }, // Full Name
    { wch: 18 }, // Phone
    { wch: 26 }, // Email
    { wch: 22 }, // Department
    { wch: 26 }, // Designation
    { wch: 24 }, // Territory
    { wch: 18 }, // Manager Name
    { wch: 20 }, // Emergency Contact
    { wch: 14 }, // Joining Date
    { wch: 12 }, // Status
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Employees');

  // Trigger download as .xlsx
  XLSX.writeFile(workbook, 'FieldFlow_Employee_Import_Template.xlsx');
}

/**
 * Generates and downloads an Excel/CSV error report for rows that failed validation.
 */
export function downloadErrorReport(
  fileName: string,
  errors: SpreadsheetRowError[]
): void {
  const reportRows = errors.map((err) => ({
    'Original Row': err.rowNumber,
    'Employee ID': err.employeeCode || '--',
    'Full Name': err.name || '--',
    'Problem Field': err.field || '--',
    'Value Found': err.value || '--',
    'Error Description': err.reason,
    'Suggested Correction': err.suggestedAction || 'Check value and format according to requirements.',
  }));

  const worksheet = XLSX.utils.json_to_sheet(reportRows);
  worksheet['!cols'] = [
    { wch: 14 }, // Row
    { wch: 16 }, // Employee ID
    { wch: 20 }, // Name
    { wch: 18 }, // Problem Field
    { wch: 20 }, // Value Found
    { wch: 36 }, // Error Description
    { wch: 45 }, // Suggested Correction
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Import_Errors');

  const baseName = fileName.replace(/\.[^/.]+$/, '');
  XLSX.writeFile(workbook, `${baseName}_Import_Errors.xlsx`);
}

/**
 * Exports arbitrary tabular data to an Excel (.xlsx) file using SheetJS.
 */
export function exportDatasetToExcel(
  fileName: string,
  sheetName: string,
  headers: string[],
  rows: (string | number | boolean)[][]
): void {
  const data = [headers, ...rows];
  const worksheet = XLSX.utils.aoa_to_sheet(data);

  // Auto-fit column widths based on content
  const colWidths = headers.map((h, colIdx) => {
    let maxLen = h.length;
    for (let r = 0; r < Math.min(rows.length, 100); r++) {
      const val = rows[r][colIdx];
      if (val !== undefined && val !== null) {
        maxLen = Math.max(maxLen, String(val).length);
      }
    }
    return { wch: Math.min(Math.max(maxLen + 3, 12), 40) };
  });
  worksheet['!cols'] = colWidths;

  const workbook = XLSX.utils.book_new();
  const safeSheetName = (sheetName || 'Report').replace(/[:\\/?*[\]]/g, '').substring(0, 31);
  XLSX.utils.book_append_sheet(workbook, worksheet, safeSheetName);

  const finalFileName = fileName.endsWith('.xlsx') ? fileName : `${fileName}.xlsx`;
  XLSX.writeFile(workbook, finalFileName);
}

/**
 * Generates and downloads an audit-ready, high-resolution vector PDF document using jsPDF and autoTable.
 */
export function exportDatasetToPdf(
  title: string,
  subtitle: string,
  headers: string[],
  rows: (string | number | boolean)[][],
  orgName?: string
): void {
  try {
    const doc = new jsPDF({
      orientation: headers.length > 6 ? 'landscape' : 'portrait',
      unit: 'pt',
      format: 'a4',
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const dateStr = new Date().toLocaleString();

    // Brand accent bar
    doc.setFillColor(2, 132, 199); // Sky-600
    doc.rect(0, 0, pageWidth, 6, 'F');

    // Header Title
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.setTextColor(15, 23, 42); // slate-900
    const fullTitle = orgName ? `${orgName} — ${title}` : title;
    doc.text(fullTitle, 36, 36);

    // Subtitle & Filter description
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139); // slate-500
    doc.text(subtitle, 36, 52);

    // Metadata Right-Aligned
    doc.setFontSize(8);
    doc.text(`Generated: ${dateStr}`, pageWidth - 36, 36, { align: 'right' });
    doc.text(`Total Records: ${rows.length}`, pageWidth - 36, 50, { align: 'right' });

    // Table formatting
    const formattedRows = rows.map((r) =>
      r.map((c) => (c !== undefined && c !== null && String(c).trim() !== '' ? String(c) : '--'))
    );

    autoTable(doc, {
      head: [headers],
      body: formattedRows,
      startY: 68,
      margin: { left: 36, right: 36, top: 40, bottom: 40 },
      styles: {
        fontSize: headers.length > 7 ? 7 : 8,
        cellPadding: 5,
        textColor: [30, 41, 59],
        overflow: 'linebreak',
      },
      headStyles: {
        fillColor: [241, 245, 249],
        textColor: [51, 65, 85],
        fontStyle: 'bold',
        fontSize: headers.length > 7 ? 7.5 : 8.5,
      },
      alternateRowStyles: {
        fillColor: [248, 250, 252],
      },
      didDrawPage: (data) => {
        // Footer
        const str = `Page ${data.pageNumber}`;
        doc.setFontSize(8);
        doc.setTextColor(148, 163, 184);
        doc.text(
          'FieldFlow Workforce Operations Platform — Audit-Ready Compliance Document',
          36,
          doc.internal.pageSize.getHeight() - 20
        );
        doc.text(str, pageWidth - 36, doc.internal.pageSize.getHeight() - 20, { align: 'right' });
      },
    });

    const safeFileName = `${(orgName || 'FieldFlow').replace(/\s+/g, '_')}_${title.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`;
    doc.save(safeFileName);
  } catch (err) {
    console.error('Failed to generate PDF via jsPDF:', err);
    throw err;
  }
}
