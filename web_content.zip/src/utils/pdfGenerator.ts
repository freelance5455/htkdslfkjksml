import { jsPDF } from 'jspdf';
import { ChapterNote } from '../types/edutoon';

function wrapCanvasText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let current = '';

  for (const word of words) {
    const test = current ? `${current} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && current) {
      lines.push(current);
      current = word;
    } else {
      current = test;
    }
  }
  if (current) lines.push(current);
  return lines;
}

function loadLogoImage(): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = '/assets/aistudio/EduToon_Education__Learn_with_Joy-removebg-preview_fc41e68e.png';
  });
}

export async function generateChapterPdf(
  note: ChapterNote,
  subjectTitle: string
): Promise<string> {
  const safeFileBase = `EduToon_Class${note.classLevel}_${note.subjectId}_Ch${note.chapterNumber}_${note.language}`.replace(
    /[^a-zA-Z0-9_-]/g,
    '_'
  );
  const fileName = `${safeFileBase}.pdf`;

  // Render at crisp A4 150 DPI equivalent (1240 x 1754) so both Hindi Devanagari & English look razor sharp
  const width = 1240;
  const height = 1754;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');

  if (!ctx) {
    const fallbackDoc = new jsPDF();
    fallbackDoc.text(`${note.title}\n\n${note.summary}`, 16, 20);
    fallbackDoc.save(fileName);
    return fileName;
  }

  // White page background
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, width, height);

  // Top header band
  ctx.fillStyle = '#0B1836';
  ctx.fillRect(0, 0, width, 210);

  const logo = await loadLogoImage();
  if (logo) {
    ctx.drawImage(logo, 64, 24, 162, 162);
  }

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '700 44px "Outfit", "Noto Sans Devanagari", sans-serif';
  ctx.fillText('EduToon Education', 250, 96);

  ctx.fillStyle = '#7DD3FC';
  ctx.font = '600 22px "Plus Jakarta Sans", "Noto Sans Devanagari", sans-serif';
  ctx.fillText('ANIMATION SE AASAAN PADHAI  •  CHAPTER STUDY MATERIAL', 250, 144);

  // Metadata bar
  let y = 276;
  ctx.fillStyle = '#475569';
  ctx.font = '600 24px "Plus Jakarta Sans", "Noto Sans Devanagari", sans-serif';
  const mediumLabel = note.language === 'hi' ? 'हिंदी माध्यम' : 'English Medium';
  ctx.fillText(
    `Class ${note.classLevel}  •  ${subjectTitle}  •  Chapter ${note.chapterNumber}  •  ${mediumLabel}`,
    72,
    y
  );

  // Title
  y += 58;
  ctx.fillStyle = '#0284C7';
  ctx.font = '700 42px "Outfit", "Noto Sans Devanagari", sans-serif';
  const titleLines = wrapCanvasText(ctx, note.title, width - 144);
  for (const line of titleLines) {
    ctx.fillText(line, 72, y);
    y += 54;
  }

  // Summary
  y += 10;
  ctx.fillStyle = '#334155';
  ctx.font = '400 26px "Plus Jakarta Sans", "Noto Sans Devanagari", sans-serif';
  const summaryLines = wrapCanvasText(ctx, note.summary, width - 144);
  for (const line of summaryLines) {
    ctx.fillText(line, 72, y);
    y += 38;
  }

  y += 24;
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(72, y);
  ctx.lineTo(width - 72, y);
  ctx.stroke();
  y += 52;

  // Sections
  for (const sec of note.sections) {
    ctx.fillStyle = '#0F172A';
    ctx.font = '700 30px "Outfit", "Noto Sans Devanagari", sans-serif';
    const hLines = wrapCanvasText(ctx, sec.heading, width - 144);
    for (const line of hLines) {
      ctx.fillText(line, 72, y);
      y += 42;
    }

    y += 8;
    ctx.fillStyle = '#334155';
    ctx.font = '400 25px "Plus Jakarta Sans", "Noto Sans Devanagari", sans-serif';
    const bLines = wrapCanvasText(ctx, sec.body, width - 144);
    for (const line of bLines) {
      ctx.fillText(line, 72, y);
      y += 37;
    }

    if (sec.keyFormulaOrPoint) {
      y += 16;
      ctx.font = '600 24px "Plus Jakarta Sans", "Noto Sans Devanagari", sans-serif';
      const kLines = wrapCanvasText(ctx, `Key Point: ${sec.keyFormulaOrPoint}`, width - 200);
      const boxH = kLines.length * 36 + 36;
      ctx.fillStyle = '#F0F9FF';
      ctx.strokeStyle = '#BAE6FD';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(72, y, width - 144, boxH, 16);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#0369A1';
      let ky = y + 42;
      for (const line of kLines) {
        ctx.fillText(line, 100, ky);
        ky += 36;
      }
      y += boxH + 34;
    } else {
      y += 28;
    }
  }

  // Practice Q&A box
  ctx.font = '600 25px "Plus Jakarta Sans", "Noto Sans Devanagari", sans-serif';
  const qLines = wrapCanvasText(ctx, `Q: ${note.practiceQuestion.question}`, width - 200);
  ctx.font = '500 24px "Plus Jakarta Sans", "Noto Sans Devanagari", sans-serif';
  const aLines = wrapCanvasText(ctx, `Ans: ${note.practiceQuestion.answer}`, width - 200);
  const qaHeight = (qLines.length + aLines.length) * 36 + 64;

  if (y + qaHeight < height - 120) {
    ctx.fillStyle = '#F8FAFC';
    ctx.strokeStyle = '#CBD5E1';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(72, y, width - 144, qaHeight, 16);
    ctx.fill();
    ctx.stroke();

    let qy = y + 48;
    ctx.fillStyle = '#0F172A';
    ctx.font = '700 25px "Plus Jakarta Sans", "Noto Sans Devanagari", sans-serif';
    for (const line of qLines) {
      ctx.fillText(line, 100, qy);
      qy += 36;
    }
    qy += 10;
    ctx.fillStyle = '#047857';
    ctx.font = '600 24px "Plus Jakarta Sans", "Noto Sans Devanagari", sans-serif';
    for (const line of aLines) {
      ctx.fillText(line, 100, qy);
      qy += 36;
    }
  }

  // Footer
  ctx.fillStyle = '#94A3B8';
  ctx.font = '500 20px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('EduToon Education Official Study Material  •  Animation Se Aasaan Padhai', 72, height - 56);

  const imgData = canvas.toDataURL('image/jpeg', 0.94);
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });
  doc.addImage(imgData, 'JPEG', 0, 0, 210, 297);
  doc.save(fileName);

  return fileName;
}
