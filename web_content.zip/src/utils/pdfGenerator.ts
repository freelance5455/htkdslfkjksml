import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

/**
 * Genera l'oggetto Blob del PDF ad alta risoluzione a partire da un elemento del DOM.
 */
export async function generateElementPdfBlob(element: HTMLElement): Promise<Blob> {
  const originalBackground = element.style.background;
  element.style.background = '#ffffff';

  try {
    const canvas = await html2canvas(element, {
      scale: 2, // 2x per nitidezza a 300 DPI per stampa
      useCORS: true,
      allowTaint: true,
      logging: false,
      backgroundColor: '#ffffff'
    });

    const imgData = canvas.toDataURL('image/jpeg', 0.95);

    // Dimensioni A4 in mm
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pdfWidth = pdf.internal.pageSize.getWidth(); // 210 mm
    const pdfHeight = pdf.internal.pageSize.getHeight(); // 297 mm

    const imgWidth = pdfWidth - 16; // 8mm margine per lato
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 8; // margine top

    // Prima pagina
    pdf.addImage(imgData, 'JPEG', 8, position, imgWidth, imgHeight);
    heightLeft -= pdfHeight;

    // Se l'elemento è più lungo di una pagina A4 (es. tabelle + foto) aggiungi pagine
    while (heightLeft > 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 8, position + 8, imgWidth, imgHeight);
      heightLeft -= pdfHeight;
    }

    return pdf.output('blob');
  } catch (error) {
    console.error('Errore durante la creazione del blob PDF:', error);
    throw error;
  } finally {
    element.style.background = originalBackground;
  }
}

/**
 * Genera e scarica un file PDF ad alta risoluzione a partire da un elemento del DOM.
 * Utilizza html2canvas e jsPDF senza dipendere dal blocco di window.print() degli iframe.
 */
export async function downloadElementAsPdf(
  element: HTMLElement,
  filename: string
): Promise<void> {
  const blob = await generateElementPdfBlob(element);
  const safeName = filename.endsWith('.pdf') ? filename : `${filename}.pdf`;
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = safeName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Fallback per la stampa via iframe isolato per evitare il blocco di window.print()
 */
export function printHtmlSafely(htmlContent: string, title: string): void {
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (!doc) {
    window.print();
    return;
  }

  doc.open();
  doc.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>${title}</title>
        <style>
          @page { size: A4 portrait; margin: 8mm; }
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: #000; margin: 0; padding: 0; }
          table { width: 100%; border-collapse: collapse; }
          th, td { border: 1px solid #000; padding: 4px 6px; font-size: 10px; }
          .no-print { display: none !important; }
        </style>
      </head>
      <body>
        ${htmlContent}
        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 300);
          };
        </script>
      </body>
    </html>
  `);
  doc.close();

  setTimeout(() => {
    try {
      document.body.removeChild(iframe);
    } catch (e) {
      // Ignore
    }
  }, 10000);
}
