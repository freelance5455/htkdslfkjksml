import test from 'node:test';
import assert from 'node:assert/strict';
import { buildSystemInstruction, TUTOR_PERSONAS } from './tutor-prompts.ts';

test('buildSystemInstruction includes persona base and Socratic mode guidance', () => {
  const instruction = buildSystemInstruction({
    personaId: 'math',
    teachingMode: 'socratic',
    level: 'high_school',
  });

  assert.ok(instruction.includes('Mathematics and Formal Logic Tutor'));
  assert.ok(instruction.includes('TEACHING STYLE: SOCRATIC GUIDANCE'));
  assert.ok(instruction.includes('High School'));
  assert.ok(instruction.includes('LaTeX syntax'));
});

test('buildSystemInstruction falls back to general if invalid persona is passed', () => {
  const instruction = buildSystemInstruction({
    // @ts-expect-error testing fallback
    personaId: 'unknown_persona',
    teachingMode: 'direct',
    level: 'undergrad',
  });

  assert.ok(instruction.includes(TUTOR_PERSONAS.general.systemBase));
  assert.ok(instruction.includes('TEACHING STYLE: DIRECT'));
  assert.ok(instruction.includes('Undergraduate'));
});

test('TUTOR_PERSONAS contains all core personas with default prompts', () => {
  const keys = ['general', 'math', 'code', 'science', 'language', 'history'];
  for (const k of keys) {
    const p = TUTOR_PERSONAS[k as keyof typeof TUTOR_PERSONAS];
    assert.ok(p, `Persona ${k} exists`);
    assert.ok(p.name.length > 0);
    assert.ok(p.defaultPrompts.length > 0);
  }
});
