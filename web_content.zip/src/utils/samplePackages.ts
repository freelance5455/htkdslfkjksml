import JSZip from 'jszip';

export interface SamplePackDef {
  id: string;
  name: string;
  description: string;
  type: 'apk' | 'xapk';
  sizeLabel: string;
  badge: string;
  icon: string;
  generate: () => Promise<{ blob: Blob; fileName: string; meta: any }>;
}

export const SAMPLE_PACKAGES: SamplePackDef[] = [
  {
    id: 'crystal_quest_apk',
    name: 'CrystalQuest_RPG_v1.4.2.apk',
    description: 'Fantasy RPG with XML resources, Lua scripts & JSON economy configuration.',
    type: 'apk',
    sizeLabel: '14.8 MB',
    badge: 'Popular RPG',
    icon: '🎮',
    generate: async () => {
      const zip = new JSZip();

      // AndroidManifest.xml
      zip.file(
        'AndroidManifest.xml',
        `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.pixelquest.rpg.adventure"
    android:versionCode="10402"
    android:versionName="1.4.2">
    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="34" />
    <application android:label="Crystal Quest: Kingdom RPG" android:icon="@drawable/ic_launcher">
        <activity android:name=".MainActivity" android:exported="true" />
    </application>
</manifest>`
      );

      // res/values/game_balances.xml
      zip.file(
        'res/values/game_balances.xml',
        `<?xml version="1.0" encoding="utf-8"?>
<!-- Crystal Quest Global Resource Configuration -->
<resources>
    <integer name="player_initial_coins">3500</integer>
    <integer name="player_starting_gems">120</integer>
    <integer name="welcome_diamonds">45</integer>
    <integer name="dungeon_bonus_gold">8000</integer>
    <integer name="daily_stamina_energy">100</integer>
</resources>`
      );

      // assets/data/economy_config.json
      zip.file(
        'assets/data/economy_config.json',
        JSON.stringify(
          {
            app_id: 'com.pixelquest.rpg.adventure',
            version: '1.4.2',
            player_defaults: {
              wallet: {
                starting_coins: 5000,
                premium_gems: 250,
                legendary_diamonds: 50,
                vault_gold: 15000,
                mystic_rubies: 20
              },
              caps: {
                max_energy: 150,
                stamina_recharge_seconds: 60
              }
            },
            shop_bundles: {
              starter_pack: {
                included_coins: 10000,
                included_gems: 300,
                included_diamonds: 100
              }
            }
          },
          null,
          2
        )
      );

      // assets/scripts/player_stats.lua
      zip.file(
        'assets/scripts/player_stats.lua',
        `-- Crystal Quest Lua Core Inventory Script
local PlayerStats = {
    account_level = 1,
    base_coins = 4200,
    base_gems = 180,
    sacred_diamonds = 35,
    infinite_energy = 0
}

function PlayerStats:GetStartingBalance()
    return {
        coins = self.base_coins,
        gems = self.base_gems,
        diamonds = self.sacred_diamonds
    }
end

return PlayerStats`
      );

      // assets/settings/game_profile.ini
      zip.file(
        'assets/settings/game_profile.ini',
        `[GameProfile]
save_version=4
profile_id=100293
coins=6000
gems=210
diamonds=75
gold=12500
energy=90
sync_cloud=true`
      );

      // META-INF/MANIFEST.MF
      zip.file(
        'META-INF/MANIFEST.MF',
        `Manifest-Version: 1.0\r\nBuilt-By: Android Gradle 8.4.1\r\nCreated-By: PixelQuest Studio\r\n`
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      return {
        blob,
        fileName: 'CrystalQuest_RPG_v1.4.2.apk',
        meta: {
          packageName: 'com.pixelquest.rpg.adventure',
          appName: 'Crystal Quest: Kingdom RPG',
          version: '1.4.2'
        }
      };
    }
  },
  {
    id: 'dungeon_clash_xapk',
    name: 'DungeonClash_Battle_v2.2.0.xapk',
    description: 'Full XAPK bundle with Split APKs, OBB game data and balance files.',
    type: 'xapk',
    sizeLabel: '38.2 MB',
    badge: 'XAPK Bundle',
    icon: '⚔️',
    generate: async () => {
      const zip = new JSZip();

      // XAPK manifest.json
      zip.file(
        'manifest.json',
        JSON.stringify(
          {
            xapk_version: 2,
            package_name: 'com.dungeonclash.battle.arena',
            name: 'Dungeon Clash: Arena Heroes',
            version_code: 220,
            version_name: '2.2.0',
            min_sdk_version: 26,
            target_sdk_version: 34,
            split_apks: [
              { file: 'com.dungeonclash.battle.arena.apk', id: 'base' },
              { file: 'config.arm64_v8a.apk', id: 'config.arm64_v8a' }
            ],
            expansions: [
              {
                file: 'main.220.com.dungeonclash.battle.arena.obb',
                install_location: 'EXTERNAL_STORAGE',
                install_path: 'Android/obb/com.dungeonclash.battle.arena/'
              }
            ]
          },
          null,
          2
        )
      );

      // Base APK inside XAPK
      const baseApk = new JSZip();
      baseApk.file(
        'AndroidManifest.xml',
        `<manifest package="com.dungeonclash.battle.arena" android:versionName="2.2.0"></manifest>`
      );
      baseApk.file(
        'res/values/economy.xml',
        `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <integer name="default_coins">7500</integer>
    <integer name="default_gems">350</integer>
    <integer name="starter_diamonds">150</integer>
    <integer name="bonus_crystals">60</integer>
</resources>`
      );
      baseApk.file(
        'assets/economy_settings.json',
        JSON.stringify(
          {
            player_economy: {
              starting_coins: 8200,
              starting_gems: 400,
              hero_diamonds: 95,
              arena_gold: 24000
            }
          },
          null,
          2
        )
      );

      const baseApkBlob = await baseApk.generateAsync({ type: 'uint8array' });
      zip.file('com.dungeonclash.battle.arena.apk', baseApkBlob);

      // Also root level balance files often found in unpacked XAPK
      zip.file(
        'assets/data/balances.json',
        JSON.stringify(
          {
            hero_pool: {
              coins: 9000,
              gems: 500,
              diamonds: 120,
              rubies: 45
            }
          },
          null,
          2
        )
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      return {
        blob,
        fileName: 'DungeonClash_Battle_v2.2.0.xapk',
        meta: {
          packageName: 'com.dungeonclash.battle.arena',
          appName: 'Dungeon Clash: Arena Heroes',
          version: '2.2.0'
        }
      };
    }
  },
  {
    id: 'cyber_racer_apk',
    name: 'CyberRacer_Turbo_v3.1.0.apk',
    description: 'Futuristic racing game with Unity-style text balance and XML configs.',
    type: 'apk',
    sizeLabel: '22.5 MB',
    badge: 'Fast Arcade',
    icon: '🏎️',
    generate: async () => {
      const zip = new JSZip();

      zip.file(
        'AndroidManifest.xml',
        `<manifest package="com.speedneon.cyberracer" android:versionName="3.1.0"></manifest>`
      );

      zip.file(
        'assets/bin/Data/global_economy.json',
        JSON.stringify(
          {
            garage: {
              nitro_coins: 12500,
              tuning_gems: 280,
              neon_diamonds: 88,
              championship_gold: 35000,
              fuel_energy: 100
            }
          },
          null,
          2
        )
      );

      zip.file(
        'res/values/racing_rewards.xml',
        `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <integer name="racer_coins">10000</integer>
    <integer name="nitro_gems">250</integer>
    <integer name="prestige_diamonds">65</integer>
</resources>`
      );

      zip.file(
        'assets/config/garage.cfg',
        `# CyberRacer Config
coins = 15000
gems = 320
diamonds = 110
gold = 50000
`
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      return {
        blob,
        fileName: 'CyberRacer_Turbo_v3.1.0.apk',
        meta: {
          packageName: 'com.speedneon.cyberracer',
          appName: 'Cyber Racer: Turbo Velocity',
          version: '3.1.0'
        }
      };
    }
  }
];
