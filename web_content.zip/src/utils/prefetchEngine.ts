import type { UiLanguageCode, VocabEntry } from '../types';
import { fetchSentenceVideoClips, fetchWordInfo, fetchWordPhoto, fetchWordVideoClips } from './mediaApi';
import { translateSentencesBatch } from './aiApi';
import { idbGetSentenceTranslations, idbSetSentenceTranslations } from './storage';
import { prefetchWordHub } from './wordHubApi';

interface PrefetchOptions {
  backendUrl: string;
  pixabayKey: string;
  unsplashKey: string;
  uiLang?: UiLanguageCode;
}

const queuedWords = new Set<string>();
const queuedVideoWords = new Set<string>();
const predecodedUrls = new Set<string>();
const warmedVideoUrls = new Set<string>();
const warmedOrigins = new Set<string>();
const warmedLinkNodes: HTMLLinkElement[] = [];
const MAX_WARMED_VIDEOS = 60;
const pendingTasks: Array<() => Promise<void>> = [];
let activeWorkers = 0;
const MAX_CONCURRENT = 6;
const MAX_QUEUE_CAP = 160;
let chunksWarmed = false;

function scheduleIdle(fn: () => void): void {
  if (typeof window === 'undefined') return;
  const w = window as unknown as {
    requestIdleCallback?: (cb: () => void, opts?: { timeout?: number }) => number;
  };
  if (typeof w.requestIdleCallback === 'function') {
    w.requestIdleCallback(fn, { timeout: 150 });
  } else {
    window.setTimeout(fn, 32);
  }
}

function drainQueue(): void {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
  while (activeWorkers < MAX_CONCURRENT && pendingTasks.length > 0) {
    const task = pendingTasks.shift();
    if (!task) break;
    activeWorkers += 1;
    void task()
      .catch(() => {})
      .finally(() => {
        activeWorkers -= 1;
        if (pendingTasks.length > 0) {
          scheduleIdle(drainQueue);
        }
      });
  }
}

export function enqueueIdleTask(task: () => Promise<void>): void {
  if (pendingTasks.length >= MAX_QUEUE_CAP) return;
  pendingTasks.push(task);
  scheduleIdle(drainQueue);
}

export function warmImageUrl(url?: string): void {
  if (!url || typeof window === 'undefined' || predecodedUrls.has(url)) return;
  if (url.startsWith('data:')) return;
  predecodedUrls.add(url);
  try {
    const img = new Image();
    img.decoding = 'async';
    img.referrerPolicy = 'no-referrer';
    img.src = url;
  } catch {
    // Ignore
  }
}

/**
 * Warms an upcoming video MP4 URL using <link rel="prefetch" as="video">
 * so pressing Play or swiping to the next clip starts nearly instantaneously.
 */
export function warmVideoUrl(url?: string): void {
  if (!url || typeof document === 'undefined' || warmedVideoUrls.has(url)) return;
  if (!/^https?:\/\//i.test(url) && !url.startsWith('/api/video-proxy')) return;
  const conn =
    typeof navigator !== 'undefined'
      ? (navigator as unknown as { connection?: { saveData?: boolean } }).connection
      : undefined;
  if (conn?.saveData) return;

  if (warmedVideoUrls.size >= MAX_WARMED_VIDEOS) {
    const oldest = warmedVideoUrls.values().next().value;
    if (oldest) warmedVideoUrls.delete(oldest);
    const oldNode = warmedLinkNodes.shift();
    if (oldNode?.parentNode) oldNode.parentNode.removeChild(oldNode);
  }
  warmedVideoUrls.add(url);

  try {
    if (!url.startsWith('/api/video-proxy')) {
      const origin = new URL(url).origin;
      if (!warmedOrigins.has(origin)) {
        warmedOrigins.add(origin);
        const pc = document.createElement('link');
        pc.rel = 'preconnect';
        pc.crossOrigin = 'anonymous';
        pc.href = origin;
        document.head.appendChild(pc);
      }
    }
    const link = document.createElement('link');
    link.rel = 'prefetch';
    link.as = 'video';
    link.href = url;
    document.head.appendChild(link);
    warmedLinkNodes.push(link);
  } catch {
    // Ignore DOM / URL errors
  }
}

/**
 * Speculatively prefetches photo + Word Hub + dictionary info + video clips & posters
 * for a single word so opening WordDetailView feels instantaneous (0ms).
 */
export function prefetchWordBundle(
  word: Pick<VocabEntry, 'en' | 'ar' | 'band'>,
  options: PrefetchOptions,
  includeInfo = true
): void {
  if (typeof window === 'undefined') return;
  const key = `${word.en.toLowerCase()}::${options.uiLang || 'ar'}::${includeInfo ? 'full' : 'photo'}`;
  if (queuedWords.has(key)) return;
  queuedWords.add(key);

  enqueueIdleTask(async () => {
    const photoRes = await fetchWordPhoto(word.en, 1, options, false, {
      ar: word.ar,
      band: word.band,
    });
    if (photoRes.data?.imageUrl) {
      warmImageUrl(photoRes.data.thumbUrl || photoRes.data.imageUrl);
    }
    if (includeInfo) {
      prefetchWordHub(word.en, word.ar, word.band, options.uiLang || 'ar');
      await fetchWordInfo(word.en, options.backendUrl, false);
    }
  });

  if (includeInfo) {
    prefetchWordVideoClips(word.en);
  }
}

/**
 * Prefetches up to 12 upcoming words in idle priority (e.g. next words in active level).
 */
export function prefetchWordsBatch(
  words: Array<Pick<VocabEntry, 'en' | 'ar' | 'band'>>,
  options: PrefetchOptions,
  limit = 12,
  includeInfo = true
): void {
  if (typeof window === 'undefined' || !words.length) return;
  const slice = words.slice(0, Math.max(1, Math.min(limit, 14)));
  for (const w of slice) {
    prefetchWordBundle(w, options, includeInfo);
  }
}

/**
 * Speculatively prefetches the first page of ±3s spoken video clips, poster frames,
 * and warms the first clip's video URL so tapping Play feels instant.
 */
export function prefetchWordVideoClips(word: string): void {
  if (typeof window === 'undefined') return;
  if (typeof navigator !== 'undefined' && !navigator.onLine) return;
  const clean = (word || '').trim().toLowerCase();
  if (!clean || queuedVideoWords.has(clean)) return;
  queuedVideoWords.add(clean);

  enqueueIdleTask(async () => {
    const res = await fetchWordVideoClips(clean, 0, false);
    const clips = res.clips || [];
    for (const clip of clips.slice(0, 3)) {
      if (clip.posterUrl) warmImageUrl(clip.posterUrl);
    }
    for (const clip of clips.slice(0, 2)) {
      if (clip.videoUrl) warmVideoUrl(clip.videoUrl);
    }
  });
}

/**
 * Speculatively prefetches translations for up to 30 upcoming sentences (2 pages)
 * in the active UI language and persists them in hot cache + IndexedDB.
 */
export function prefetchSentenceTranslations(
  sentences: string[],
  targetLang = 'ar'
): void {
  if (typeof window === 'undefined' || !sentences.length) return;
  if (typeof navigator !== 'undefined' && !navigator.onLine) return;
  const clean = sentences.map((s) => s.trim()).filter(Boolean).slice(0, 30);
  if (!clean.length) return;

  const keyPrefix = targetLang === 'ar' ? '' : `${targetLang}::`;

  enqueueIdleTask(async () => {
    const storageKeys = clean.map((s) => `${keyPrefix}${s}`);
    const cached = await idbGetSentenceTranslations(storageKeys);
    const missing = clean.filter((s) => !cached[`${keyPrefix}${s}`]);
    if (!missing.length) return;
    const translated = await translateSentencesBatch(missing, undefined, targetLang);
    const toStore: Record<string, string> = {};
    for (const [en, tr] of Object.entries(translated)) {
      if (tr) toStore[`${keyPrefix}${en}`] = tr;
    }
    if (Object.keys(toStore).length > 0) {
      await idbSetSentenceTranslations(toStore);
    }
  });
}

/**
 * Speculatively prefetches full-sentence video clip lists for upcoming sentences.
 */
export function prefetchSentenceVideos(sentences: string[], limit = 6): void {
  if (typeof window === 'undefined' || !sentences.length) return;
  if (typeof navigator !== 'undefined' && !navigator.onLine) return;
  const seen = new Set<string>();
  let count = 0;
  for (const s of sentences) {
    if (count >= limit) break;
    const clean = (s || '').split('=')[0].trim();
    const key = `sent::${clean.toLowerCase()}`;
    if (clean && !seen.has(key) && !queuedVideoWords.has(key)) {
      seen.add(key);
      queuedVideoWords.add(key);
      count++;
      enqueueIdleTask(async () => {
        const res = await fetchSentenceVideoClips(clean, 0, false);
        const clips = res.clips || [];
        for (const clip of clips.slice(0, 2)) {
          if (clip.posterUrl) warmImageUrl(clip.posterUrl);
        }
        if (clips[0]?.videoUrl) {
          warmVideoUrl(clips[0].videoUrl);
        }
      });
    }
  }
}

/**
 * Speculatively preloads all lazy-loaded secondary route chunks right after first paint
 * so switching tabs feels instantaneous with zero lag.
 */
export function prefetchSecondaryChunks(loaders: Array<() => Promise<unknown>>): void {
  if (typeof window === 'undefined' || chunksWarmed) return;
  chunksWarmed = true;
  loaders.forEach((loader, idx) => {
    window.setTimeout(() => {
      scheduleIdle(() => {
        void loader().catch(() => {});
      });
    }, 120 + idx * 80);
  });
}

export function getPrefetchStats(): { queuedWordsCount: number; pendingTasksCount: number } {
  return {
    queuedWordsCount: queuedWords.size,
    pendingTasksCount: pendingTasks.length,
  };
}
