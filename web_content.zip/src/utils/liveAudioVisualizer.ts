// Web Audio API Real-time Microphone Frequency & Amplitude Analyser

export class LiveAudioAnalyser {
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private dataArray: Uint8Array<ArrayBuffer> | null = null;
  private isRunning: boolean = false;

  public async start(): Promise<AnalyserNode | null> {
    if (this.isRunning && this.analyserNode) {
      return this.analyserNode;
    }

    try {
      const AudioContextClass =
        window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) {
        console.warn('Web Audio API is not supported in this browser.');
        return null;
      }

      if (!this.audioContext || this.audioContext.state === 'closed') {
        this.audioContext = new AudioContextClass();
      }

      if (this.audioContext.state === 'suspended') {
        await this.audioContext.resume();
      }

      // Request live microphone access
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      this.sourceNode = this.audioContext.createMediaStreamSource(this.mediaStream);
      this.analyserNode = this.audioContext.createAnalyser();

      // Configure FFT
      this.analyserNode.fftSize = 128; // 64 frequency bins
      this.analyserNode.smoothingTimeConstant = 0.75;
      this.analyserNode.minDecibels = -85;
      this.analyserNode.maxDecibels = -10;

      // Connect source to analyser ONLY (do NOT connect to audioContext.destination to avoid mic feedback loop)
      this.sourceNode.connect(this.analyserNode);

      this.dataArray = new Uint8Array(new ArrayBuffer(this.analyserNode.frequencyBinCount));
      this.isRunning = true;

      return this.analyserNode;
    } catch (err) {
      console.warn('LiveAudioAnalyser start error (e.g. mic permission):', err);
      this.stop();
      return null;
    }
  }

  public getFrequencyData(): Uint8Array<ArrayBuffer> | null {
    if (!this.isRunning || !this.analyserNode || !this.dataArray) {
      return null;
    }
    this.analyserNode.getByteFrequencyData(this.dataArray);
    return this.dataArray;
  }

  public getAverageVolume(): number {
    const data = this.getFrequencyData();
    if (!data || data.length === 0) return 0;

    let sum = 0;
    for (let i = 0; i < data.length; i++) {
      sum += data[i];
    }
    const avg = sum / data.length;
    // Normalize to 0 - 1 range
    return Math.min(1, avg / 128);
  }

  public stop() {
    this.isRunning = false;

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch (e) {}
      });
      this.mediaStream = null;
    }

    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch (e) {}
      this.sourceNode = null;
    }

    if (this.analyserNode) {
      try {
        this.analyserNode.disconnect();
      } catch (e) {}
      this.analyserNode = null;
    }

    this.dataArray = null;
  }

  public getAnalyser(): AnalyserNode | null {
    return this.analyserNode;
  }

  public isActive(): boolean {
    return this.isRunning;
  }
}

export const liveAudioAnalyser = new LiveAudioAnalyser();
