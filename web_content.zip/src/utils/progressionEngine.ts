import {
  AscendState,
  CharacterAttribute,
  GoalItem,
  HabitItem,
  PlannerBlock,
  ProjectItem,
  TaskItem,
  XPSettingsConfig,
} from '../types/ascend';
import { getPastDateStr } from '../data/initialAscendState';

export interface LevelStatus {
  level: number;
  totalXp: number;
  xpIntoLevel: number;
  xpNeededForLevel: number;
  progressPercent: number;
}

export function calculateLevelStatus(
  xpTransactions: { xpAmount: number }[],
  settings: XPSettingsConfig
): LevelStatus {
  if (!settings.xpEnabled) {
    return {
      level: settings.startingLevel,
      totalXp: 0,
      xpIntoLevel: 0,
      xpNeededForLevel: settings.xpPerLevelBase,
      progressPercent: 0,
    };
  }

  const earnedXp = xpTransactions.reduce((sum, tx) => sum + tx.xpAmount, 0);
  const totalXp = Math.max(0, settings.startingXp + earnedXp);

  let level = settings.startingLevel;
  let remainingXp = totalXp;
  const base = Math.max(50, settings.xpPerLevelBase);

  const getReqForLevel = (lvl: number) => {
    if (settings.levelFormula === 'linear') {
      return base;
    }
    return Math.round(base * Math.pow(1.12, lvl - settings.startingLevel));
  };

  while (level < settings.maxLevel) {
    const req = getReqForLevel(level);
    if (remainingXp >= req) {
      remainingXp -= req;
      level += 1;
    } else {
      break;
    }
  }

  const xpNeededForLevel = getReqForLevel(level);
  const progressPercent = Math.min(100, Math.round((remainingXp / xpNeededForLevel) * 100));

  return {
    level,
    totalXp,
    xpIntoLevel: remainingXp,
    xpNeededForLevel,
    progressPercent,
  };
}

export function calculateAttributeMetrics(attr: CharacterAttribute) {
  const xpPerPoint = Math.max(10, attr.xpPerPoint || 100);
  const bonusPoints = Math.floor(Math.max(0, attr.xpEarned) / xpPerPoint);
  const totalScore = attr.baseScore + bonusPoints;
  const remainderXp = Math.max(0, attr.xpEarned) % xpPerPoint;
  const progressPercent = Math.min(100, Math.round((remainderXp / xpPerPoint) * 100));

  return {
    totalScore,
    bonusPoints,
    remainderXp,
    xpPerPoint,
    progressPercent,
  };
}

export function calculateGoalProgress(goal: GoalItem, linkedTasks: TaskItem[] = []): number {
  if (goal.status === 'Completed') return 100;
  const totalItems = goal.milestones.length + linkedTasks.length;
  if (totalItems === 0) {
    return goal.manualProgress ?? 0;
  }
  const completedMilestones = goal.milestones.filter((m) => m.completed).length;
  const completedTasks = linkedTasks.filter((t) => t.status === 'Completed').length;
  return Math.round(((completedMilestones + completedTasks) / totalItems) * 100);
}

export function calculateProjectProgress(project: ProjectItem, linkedTasks: TaskItem[] = []): number {
  if (project.status === 'Completed') return 100;
  const totalItems = project.milestones.length + linkedTasks.length;
  if (totalItems === 0) return 0;
  const doneMilestones = project.milestones.filter((m) => m.completed).length;
  const doneTasks = linkedTasks.filter((t) => t.status === 'Completed').length;
  return Math.round(((doneMilestones + doneTasks) / totalItems) * 100);
}

export function isHabitCompletedOnDate(habit: HabitItem, dateStr: string): boolean {
  const val = habit.history[dateStr] ?? 0;
  return val >= habit.targetValue;
}

export function calculateHabitStreak(habit: HabitItem): number {
  let streak = 0;
  for (let i = 0; i < 60; i++) {
    const dStr = getPastDateStr(i);
    if (isHabitCompletedOnDate(habit, dStr)) {
      streak++;
    } else if (i === 0) {
      // If today isn't completed yet, check if yesterday had an active streak
      continue;
    } else {
      break;
    }
  }
  return streak;
}

export function calculateHabitConsistency(habit: HabitItem, days = 7): number {
  let completed = 0;
  for (let i = 0; i < days; i++) {
    const dStr = getPastDateStr(i);
    if (isHabitCompletedOnDate(habit, dStr)) {
      completed++;
    }
  }
  return Math.round((completed / days) * 100);
}

export function detectPlannerConflicts(blocks: PlannerBlock[]): Set<string> {
  const conflictIds = new Set<string>();
  const toMinutes = (timeStr: string) => {
    const [h, m] = timeStr.split(':').map(Number);
    return (h || 0) * 60 + (m || 0);
  };

  for (let i = 0; i < blocks.length; i++) {
    for (let j = i + 1; j < blocks.length; j++) {
      const a = blocks[i];
      const b = blocks[j];
      if (a.date !== b.date) continue;
      const aStart = toMinutes(a.startTime);
      const aEnd = toMinutes(a.endTime);
      const bStart = toMinutes(b.startTime);
      const bEnd = toMinutes(b.endTime);
      if (aStart < bEnd && bStart < aEnd) {
        conflictIds.add(a.id);
        conflictIds.add(b.id);
      }
    }
  }
  return conflictIds;
}

export function playAscendChime(type: 'complete' | 'levelup' | 'timer' = 'complete') {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    const notes =
      type === 'levelup'
        ? [523.25, 659.25, 783.99, 1046.5]
        : type === 'timer'
        ? [440, 554.37, 659.25]
        : [587.33, 880];

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.09);
      gain.gain.setValueAtTime(0.08, now + idx * 0.09);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.09 + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.09);
      osc.stop(now + idx * 0.09 + 0.36);
    });
  } catch {
    // Ignore audio context policy restrictions if not user-triggered
  }
}

export function getActiveTitle(state: AscendState, currentLevel: number): string {
  const chosen = state.titles.find((t) => t.id === state.character.activeTitleId);
  if (chosen) return chosen.name;
  const highestUnlocked = [...state.titles]
    .filter((t) => t.unlocked || currentLevel >= t.requiredLevel)
    .sort((a, b) => b.requiredLevel - a.requiredLevel)[0];
  return highestUnlocked ? highestUnlocked.name : 'Initiate';
}
