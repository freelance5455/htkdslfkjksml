import { UILanguage } from '../types/pdf';

export const UI_COPY: Record<
  UILanguage,
  {
    brand: string;
    openPdf: string;
    openAnotherPdf: string;
    closeDocument: string;
    pageLabel: string;
    samplePdf: string;
    fonts: string;
    settings: string;
    exportMenuBtn: string;
    exporting: string;
    exportSectionPdf: string;
    exportPdfTitle: string;
    exportPdfDesc: string;
    exportSectionImage: string;
    exportPngPage: string;
    exportJpgPage: string;
    exportPngAll: string;
    exportJpgAll: string;
    exportImageDesc: string;
    exportSectionDocx: string;
    exportDocxTitle: string;
    exportDocxDesc: string;
    langToggle: string;
    pages: string;
    addBlankPage: string;
    addPageShort: string;
    rotatePage: string;
    duplicatePage: string;
    deletePage: string;
    deletePageShort: string;
    moveUp: string;
    moveDown: string;
    detectedFonts: string;
    toolEditText: string;
    toolSelectRegion: string;
    toolAddText: string;
    toolHighlight: string;
    toolPen: string;
    toolPatch: string;
    toolSignature: string;
    toolImage: string;
    toolShape: string;
    dragToSelectRegion: string;
    undo: string;
    redo: string;
    fitWidth: string;
    zoomIn: string;
    zoomOut: string;
    fullscreen: string;
    exitFullscreen: string;
    togglePagesPanel: string;
    toggleInspectorPanel: string;
    prevPage: string;
    nextPage: string;
    done: string;
    penSettings: string;
    strokeColor: string;
    strokeWidth: string;
    dragToDrawHighlight: string;
    dragToDrawPen: string;
    inspectorEmptyTitle: string;
    inspectorEmptyDesc: string;
    pageInfo: string;
    shortcuts: string;
    shortcutEdit: string;
    shortcutMove: string;
    shortcutUndo: string;
    shortcutDelete: string;
    textContent: string;
    inputMethod: string;
    inputSystem: string;
    inputPhonetic: string;
    phoneticHint: string;
    convertBijoy: string;
    bijoyNotice: string;
    fontPreservation: string;
    originalFont: string;
    fontFamily: string;
    fontSize: string;
    style: string;
    bold: string;
    italic: string;
    alignment: string;
    alignLeft: string;
    alignCenter: string;
    alignRight: string;
    alignJustify: string;
    lineHeight: string;
    letterSpacing: string;
    textColor: string;
    backgroundMask: string;
    maskEnabled: string;
    maskColor: string;
    maskPadding: string;
    pickFromPage: string;
    resetToOriginal: string;
    duplicateBlock: string;
    deleteBlock: string;
    patchSettings: string;
    fillColor: string;
    borderColor: string;
    borderWidth: string;
    opacity: string;
    shapeSettings: string;
    shapeType: string;
    rectangle: string;
    highlight: string;
    line: string;
    imageSettings: string;
    fontManagerTitle: string;
    fontManagerDesc: string;
    uploadCustomFont: string;
    loadDeviceFonts: string;
    loadingDeviceFonts: string;
    deviceFontsResult: string;
    originalColorBtn: string;
    googleFontSearchHeading: string;
    googleFontSearchPlaceholder: string;
    googleFontAddBtn: string;
    googleFontLoading: string;
    googleFontAdded: string;
    googleFontNotFound: string;
    googleFontsQuickList: string;
    decreaseFontSize: string;
    increaseFontSize: string;
    editParagraphBtn: string;
    fontGroupBanglaEnglish: string;
    fontGroupArabic: string;
    fontGroupUrduPersian: string;
    fontGroupDeviceGoogle: string;
    customFontsHeading: string;
    bundledFontsHeading: string;
    detectedInDocHeading: string;
    noCustomFonts: string;
    applyToAllDetected: string;
    signatureTitle: string;
    signatureDesc: string;
    inkColor: string;
    clearSignature: string;
    insertSignature: string;
    close: string;
    dropPdfPrompt: string;
    dropPdfSub: string;
    emptyOpenBtn: string;
    emptyOpenSub: string;
    loadingPdf: string;
    clickToPlaceText: string;
    dragToDrawPatch: string;
    dragToDrawShape: string;
    clickTextToEdit: string;
    editedBadge: string;
    scriptSelectorLabel: string;
    scriptBangla: string;
    scriptEnglish: string;
    scriptArabic: string;
    scriptUrdu: string;
    scriptPersian: string;
    settingsTitle: string;
    settingsDesc: string;
    tabGeneral: string;
    tabTroubleshoot: string;
    tabExport: string;
    uiLanguageLabel: string;
    defaultScriptLabel: string;
    defaultScriptDesc: string;
    defaultPageSizeLabel: string;
    autosaveLabel: string;
    autosaveDesc: string;
    saveSnapshotNow: string;
    snapshotSaved: string;
    paragraphGroupingLabel: string;
    paragraphGroupingDesc: string;
    autoNormalizeLabel: string;
    autoNormalizeDesc: string;
    reparseCurrentPdf: string;
    reparseDone: string;
    reloadAllFontsBtn: string;
    fontsReloaded: string;
    unlockSelectionBtn: string;
    unlockDone: string;
    clearCacheBtn: string;
    clearCacheDone: string;
    exportQualityLabel: string;
    qualityHd: string;
    qualityFullHd: string;
    qualityUhd: string;
    defaultMaskPaddingLabel: string;
  }
> = {
  bn: {
    brand: 'LipiPDF',
    openPdf: 'পিডিএফ খুলুন',
    openAnotherPdf: 'আরেকটি পিডিএফ',
    closeDocument: 'ট্যাব বন্ধ করুন',
    pageLabel: 'পৃষ্ঠা',
    samplePdf: 'নমুনা পিডিএফ',
    fonts: 'ফন্ট',
    settings: 'সেটিংস',
    exportMenuBtn: 'সেভ',
    exporting: 'সেভ হচ্ছে...',
    exportSectionPdf: 'পিডিএফ ডকুমেন্ট',
    exportPdfTitle: 'পিডিএফ হিসেবে সেভ (.pdf)',
    exportPdfDesc: 'মূল ফন্ট ও ডিজাইন অক্ষুণ্ণ রেখে সম্পূর্ণ পিডিএফ',
    exportSectionImage: 'ফুল এইচডি ছবি (Full HD+)',
    exportPngPage: 'বর্তমান পৃষ্ঠা — PNG',
    exportJpgPage: 'বর্তমান পৃষ্ঠা — JPEG',
    exportPngAll: 'সবগুলো পৃষ্ঠা — PNG',
    exportJpgAll: 'সবগুলো পৃষ্ঠা — JPEG',
    exportImageDesc: 'হাই-রেজোলিউশন (১৯২০px+ Full HD)',
    exportSectionDocx: 'ওয়ার্ড ডকুমেন্ট',
    exportDocxTitle: 'ডক্স ফাইল হিসেবে সেভ (.docx)',
    exportDocxDesc: 'বাংলা, ইংরেজি, আরবি, উর্দু ও ফার্সি ওয়ার্ড ফাইল',
    langToggle: 'EN',
    pages: 'পৃষ্ঠা',
    addBlankPage: 'নতুন পৃষ্ঠা বাড়ান',
    addPageShort: 'পৃষ্ঠা',
    rotatePage: 'ঘোরান ৯০°',
    duplicatePage: 'কপি করুন',
    deletePage: 'মুছুন',
    deletePageShort: 'মুছুন',
    moveUp: 'উপরে নিন',
    moveDown: 'নিচে নিন',
    detectedFonts: 'শনাক্তকৃত ফন্ট',
    toolEditText: 'এডিট',
    toolSelectRegion: 'বহু সিলেক্ট',
    toolAddText: 'লেখা',
    toolHighlight: 'হাইলাইট',
    toolPen: 'পেন',
    toolPatch: 'মাস্ক',
    toolSignature: 'স্বাক্ষর',
    toolImage: 'ছবি',
    toolShape: 'বক্স',
    dragToSelectRegion:
      'মাউস বা আঙুল টেনে একসাথে অনেকগুলো লেখা সিলেক্ট করে এমএস ওয়ার্ডের মতো এডিট করুন',
    undo: 'আন্ডু',
    redo: 'রিডু',
    fitWidth: 'ফিট',
    zoomIn: 'জুম ইন',
    zoomOut: 'জুম আউট',
    fullscreen: 'ফুল স্ক্রিন',
    exitFullscreen: 'সাধারণ স্ক্রিন',
    togglePagesPanel: 'পৃষ্ঠা',
    toggleInspectorPanel: 'এডিট প্যানেল',
    prevPage: 'আগের পৃষ্ঠা',
    nextPage: 'পরের পৃষ্ঠা',
    done: 'সম্পন্ন',
    penSettings: 'পেন ও আঁকা',
    strokeColor: 'কালির রঙ',
    strokeWidth: 'পুরুত্ব',
    dragToDrawHighlight: 'লেখার ওপর মাউস বা আঙুল টেনে হাইলাইট করুন',
    dragToDrawPen: 'পৃষ্ঠার ওপর যেকোনো কিছু আঁকুন বা দাগ দিন',
    inspectorEmptyTitle: 'টেক্সট বা ডিজাইন নির্বাচন করুন',
    inspectorEmptyDesc:
      'পিডিএফ-এর যেকোনো বাংলা বা ইংরেজি লেখার ওপর ক্লিক করে সরাসরি এডিট করুন। মূল ফন্ট ও ডিজাইন স্বয়ংক্রিয়ভাবে অক্ষুণ্ণ থাকবে।',
    pageInfo: 'পৃষ্ঠার মাপ',
    shortcuts: 'দ্রুত নির্দেশিকা',
    shortcutEdit: 'লেখায় ক্লিক করে এডিট করুন',
    shortcutMove: 'টেনে অবস্থান পরিবর্তন করুন',
    shortcutUndo: 'Ctrl+Z দিয়ে পূর্বাবস্থায় ফিরুন',
    shortcutDelete: 'Delete চেপে এলিমেন্ট মুছুন',
    textContent: 'টেক্সট এডিট',
    inputMethod: 'কীবোর্ড',
    inputSystem: 'সিস্টেম',
    inputPhonetic: 'ফোনেটিক',
    phoneticHint: 'ইংরেজি অক্ষরে লিখুন (যেমন: amar bangla → আমার বাংলা)',
    convertBijoy: 'বিজয় → ইউনিকোড রূপান্তর',
    bijoyNotice: 'পুরনো বিজয়/SutonnyMJ ফন্ট শনাক্ত হয়েছে। এডিট করতে ইউনিকোডে রূপান্তর করুন।',
    fontPreservation: 'ফন্ট ও টাইপোগ্রাফি',
    originalFont: 'মূল পিডিএফ ফন্ট',
    fontFamily: 'ফন্ট নির্বাচন',
    fontSize: 'ফন্ট সাইজ',
    style: 'স্টাইল',
    bold: 'বোল্ড',
    italic: 'ইটালিক',
    alignment: 'অ্যালাইনমেন্ট',
    alignLeft: 'বামে সাজান',
    alignCenter: 'মাঝে সাজান',
    alignRight: 'ডানে সাজান',
    alignJustify: 'দুপাশে সমান (Justify)',
    lineHeight: 'লাইন স্পেসিং',
    letterSpacing: 'অক্ষর দূরত্ব',
    textColor: 'লেখার রঙ',
    backgroundMask: 'পেছনের ডিজাইন মাস্ক',
    maskEnabled: 'পুরনো লেখা ঢেকে রাখুন',
    maskColor: 'ব্যাকগ্রাউন্ড রঙ',
    maskPadding: 'মাস্ক প্যাডিং',
    pickFromPage: 'পৃষ্ঠা থেকে রঙ নিন',
    resetToOriginal: 'মূল লেখায় ফিরুন',
    duplicateBlock: 'ডুপ্লিকেট',
    deleteBlock: 'মুছে ফেলুন',
    patchSettings: 'ব্যাকগ্রাউন্ড প্যাচ',
    fillColor: 'ভেতরের রঙ',
    borderColor: 'বর্ডার রঙ',
    borderWidth: 'বর্ডার পুরুত্ব',
    opacity: 'স্বচ্ছতা',
    shapeSettings: 'বক্স ও হাইলাইট',
    shapeType: 'ধরন',
    rectangle: 'আয়তক্ষেত্র',
    highlight: 'হাইলাইটার',
    line: 'লাইন',
    imageSettings: 'ছবি ও স্বাক্ষর',
    fontManagerTitle: 'ফন্ট, ডিভাইস ও গুগল ফন্ট ম্যানেজার',
    fontManagerDesc:
      'এক ক্লিকে মোবাইলের/ডিভাইসের সব ফন্ট আনুন অথবা গুগল ফন্টের নাম লিখে সরাসরি অ্যাপে যুক্ত করুন।',
    uploadCustomFont: 'ফাইল থেকে ফন্ট আনুন (.ttf / .otf)',
    loadDeviceFonts: 'ডিভাইসের সব ফন্ট এক ক্লিকে আনুন',
    loadingDeviceFonts: 'ডিভাইসের ফন্ট আনা হচ্ছে...',
    deviceFontsResult: 'টি ডিভাইস ফন্ট অ্যাপে যুক্ত হয়েছে',
    originalColorBtn: 'মূল রঙ',
    googleFontSearchHeading: 'গুগল থেকে ফন্ট সার্চ করে যুক্ত করুন',
    googleFontSearchPlaceholder: 'ফন্টের নাম লিখুন (যেমন: Baloo Da 2, Amiri, Cairo, Inter)',
    googleFontAddBtn: 'এড করুন',
    googleFontLoading: 'যুক্ত হচ্ছে...',
    googleFontAdded: 'ফন্টটি অ্যাপে যুক্ত হয়েছে!',
    googleFontNotFound: 'এই নামে গুগল ফন্ট পাওয়া যায়নি। সঠিক নাম দিন।',
    googleFontsQuickList: 'জনপ্রিয় বাংলা, আরবি, উর্দু, ফার্সি ও ইংরেজি ফন্ট',
    decreaseFontSize: 'ফন্ট ছোট করুন',
    increaseFontSize: 'ফন্ট বড় করুন',
    editParagraphBtn: 'প্যারাগ্রাফ এডিট',
    fontGroupBanglaEnglish: 'বাংলা ও ইংরেজি ফন্ট',
    fontGroupArabic: 'আরবি ফন্ট (Arabic)',
    fontGroupUrduPersian: 'উর্দু ও ফার্সি ফন্ট (Urdu / Persian)',
    fontGroupDeviceGoogle: 'ডিভাইস, গুগল ও কাস্টম ফন্ট',
    customFontsHeading: 'ডিভাইস, গুগল ও কাস্টম ফন্টসমূহ',
    bundledFontsHeading: 'বিল্ট-ইন বাংলা, আরবি, উর্দু, ফার্সি ও ইংরেজি ফন্ট',
    detectedInDocHeading: 'বর্তমান পিডিএফ-এর ফন্টসমূহ',
    noCustomFonts: 'উপরের বাটনে ক্লিক করে ডিভাইস বা গুগল ফন্ট যুক্ত করুন।',
    applyToAllDetected: 'সংশ্লিষ্ট লেখায় প্রয়োগ করুন',
    signatureTitle: 'ডিজিটাল স্বাক্ষর তৈরি করুন',
    signatureDesc: 'নিচের প্যাডে আপনার বাংলা বা ইংরেজি স্বাক্ষর আঁকুন।',
    inkColor: 'কালির রঙ',
    clearSignature: 'মুছে ফেলুন',
    insertSignature: 'পিডিএফ-এ বসান',
    close: 'বন্ধ করুন',
    dropPdfPrompt: 'এখানে পিডিএফ ফাইল ছেড়ে দিন',
    dropPdfSub: 'স্বয়ংক্রিয়ভাবে ভাষা ও ফন্ট শনাক্ত করে এডিটযোগ্য করা হবে',
    emptyOpenBtn: 'নতুন পিডিএফ ফাইল আনুন',
    emptyOpenSub: 'কম্পিউটার বা মোবাইল থেকে পিডিএফ নির্বাচন করুন অথবা এখানে ছেড়ে দিন',
    loadingPdf: 'পিডিএফ পড়া হচ্ছে ও ভাষা শনাক্ত করা হচ্ছে...',
    clickToPlaceText: 'যেকোনো স্থানে ক্লিক করে নতুন লেখা যোগ করুন',
    dragToDrawPatch: 'মাউস বা আঙুল টেনে অপ্রয়োজনীয় অংশ ঢেকে দিন',
    dragToDrawShape: 'মাউস বা আঙুল টেনে বক্স, লাইন বা হাইলাইট আঁকুন',
    clickTextToEdit: 'যেকোনো প্যারাগ্রাফ বা লেখার ওপর ট্যাপ বা ডাবল ক্লিক করে এডিট করুন',
    editedBadge: 'এডিটেড',
    scriptSelectorLabel: 'ভাষা ও লেখার দিক',
    scriptBangla: 'বাংলা',
    scriptEnglish: 'English',
    scriptArabic: 'العربية',
    scriptUrdu: 'اردو',
    scriptPersian: 'فارسی',
    settingsTitle: 'সেটিংস ও সমস্যা সমাধান',
    settingsDesc: 'সাধারণ সেটিংস, অটো ভাষা শনাক্তকরণ ও পিডিএফ সমস্যার দ্রুত সমাধান।',
    tabGeneral: 'সাধারণ সেটিংস',
    tabTroubleshoot: 'সমস্যা সমাধান',
    tabExport: 'সেভ ও কোয়ালিটি',
    uiLanguageLabel: 'অ্যাপের ভাষা (App Language)',
    defaultScriptLabel: 'নতুন লেখার ডিফল্ট ভাষা',
    defaultScriptDesc: 'নতুন টেক্সট বক্স যোগ করার সময় স্বয়ংক্রিয়ভাবে এই ভাষা, ফন্ট ও দিক (RTL/LTR) সেট হবে।',
    defaultPageSizeLabel: 'নতুন পৃষ্ঠার মাপ (New Page Size)',
    autosaveLabel: 'স্বয়ংক্রিয় সেভ (Auto-save প্রতি ৩০ সেকেন্ড)',
    autosaveDesc: 'কাজ হারানো রোধ করতে ব্রাউজারে স্বয়ংক্রিয়ভাবে সংরক্ষণ করে।',
    saveSnapshotNow: 'এখনই সেভ করুন',
    snapshotSaved: 'সেভ হয়েছে',
    paragraphGroupingLabel: 'প্যারাগ্রাফ গ্রুপিং মোড',
    paragraphGroupingDesc: 'চালু থাকলে একই প্যারাগ্রাফের সব লাইন একসাথে এডিট হয়; টেবিল বা ফর্মে সমস্যা হলে বন্ধ করে পুনরায় স্ক্যান করুন।',
    autoNormalizeLabel: 'যুক্তাক্ষর ও RTL অটো-মেরামত',
    autoNormalizeDesc: 'বাংলা কার-চিহ্ন/রেফ এবং আরবি/উর্দু/ফার্সি অক্ষরগুলো স্বয়ংক্রিয়ভাবে ঠিক করে।',
    reparseCurrentPdf: 'বর্তমান পিডিএফ পুনরায় স্ক্যান ও মেরামত করুন',
    reparseDone: 'পিডিএফ পুনরায় স্ক্যান ও মেরামত সম্পন্ন হয়েছে!',
    reloadAllFontsBtn: 'সব ডিভাইস, বাংলা, আরবি, উর্দু ও ফার্সি ফন্ট রি-লোড করুন',
    fontsReloaded: 'টি ফন্ট রি-লোড হয়েছে!',
    unlockSelectionBtn: 'আটকে যাওয়া টুল/সিলেকশন ঠিক করুন',
    unlockDone: 'এডিটর ও সিলেকশন রিসেট হয়েছে।',
    clearCacheBtn: 'পুরনো ক্যাশ ও অটো-সেভ পরিষ্কার করুন',
    clearCacheDone: 'ক্যাশ পরিষ্কার করা হয়েছে।',
    exportQualityLabel: 'ছবি (PNG / JPEG) সেভ করার মান',
    qualityHd: 'HD (1280px)',
    qualityFullHd: 'Full HD (1920px+)',
    qualityUhd: 'Ultra HD (4K)',
    defaultMaskPaddingLabel: 'ডিফল্ট ব্যাকগ্রাউন্ড মাস্ক প্যাডিং',
  },
  en: {
    brand: 'LipiPDF',
    openPdf: 'Open PDF',
    openAnotherPdf: 'Add PDF',
    closeDocument: 'Close document',
    pageLabel: 'Page',
    samplePdf: 'Sample PDF',
    fonts: 'Fonts',
    settings: 'Settings',
    exportMenuBtn: 'Save',
    exporting: 'Saving...',
    exportSectionPdf: 'PDF Document',
    exportPdfTitle: 'Save as PDF (.pdf)',
    exportPdfDesc: 'Full document with fonts & layout preserved',
    exportSectionImage: 'Full HD Page Images',
    exportPngPage: 'Current Page — PNG',
    exportJpgPage: 'Current Page — JPEG',
    exportPngAll: 'All Pages — PNG',
    exportJpgAll: 'All Pages — JPEG',
    exportImageDesc: 'High-resolution Full HD+ (1920px+)',
    exportSectionDocx: 'Word Document',
    exportDocxTitle: 'Save as Word (.docx)',
    exportDocxDesc: 'Editable Bangla, English, Arabic, Urdu & Persian DOCX',
    langToggle: 'বাংলা',
    pages: 'Pages',
    addBlankPage: 'Add Page',
    addPageShort: 'Page',
    rotatePage: 'Rotate 90°',
    duplicatePage: 'Duplicate',
    deletePage: 'Delete',
    deletePageShort: 'Delete',
    moveUp: 'Move Up',
    moveDown: 'Move Down',
    detectedFonts: 'Detected Fonts',
    toolEditText: 'Edit',
    toolSelectRegion: 'Multi-Select',
    toolAddText: 'Text',
    toolHighlight: 'Highlight',
    toolPen: 'Draw',
    toolPatch: 'Mask',
    toolSignature: 'Sign',
    toolImage: 'Image',
    toolShape: 'Shape',
    dragToSelectRegion:
      'Drag with mouse or finger across multiple lines to edit and reflow together like MS Word',
    undo: 'Undo',
    redo: 'Redo',
    fitWidth: 'Fit',
    zoomIn: 'Zoom In',
    zoomOut: 'Zoom Out',
    fullscreen: 'Fullscreen',
    exitFullscreen: 'Exit Fullscreen',
    togglePagesPanel: 'Pages',
    toggleInspectorPanel: 'Inspector',
    prevPage: 'Previous Page',
    nextPage: 'Next Page',
    done: 'Done',
    penSettings: 'Freehand Pen',
    strokeColor: 'Stroke Color',
    strokeWidth: 'Stroke Width',
    dragToDrawHighlight: 'Drag across text to highlight',
    dragToDrawPen: 'Draw freely anywhere on the page',
    inspectorEmptyTitle: 'Select Text or Design Element',
    inspectorEmptyDesc:
      'Click any Bangla or English text line on the page to edit it directly. Matched fonts and surrounding layout stay intact.',
    pageInfo: 'Page Size',
    shortcuts: 'Quick Guide',
    shortcutEdit: 'Click any text block to edit',
    shortcutMove: 'Drag blocks to reposition',
    shortcutUndo: 'Ctrl+Z to undo changes',
    shortcutDelete: 'Delete key removes selected item',
    textContent: 'Edit Text',
    inputMethod: 'Input',
    inputSystem: 'System',
    inputPhonetic: 'Phonetic',
    phoneticHint: 'Type phonetically (e.g. amar bangla → আমার বাংলা)',
    convertBijoy: 'Convert Bijoy → Unicode',
    bijoyNotice: 'Legacy Bijoy/SutonnyMJ encoding detected. Convert to Unicode before editing.',
    fontPreservation: 'Font & Typography',
    originalFont: 'Original PDF Font',
    fontFamily: 'Font Family',
    fontSize: 'Font Size',
    style: 'Style',
    bold: 'Bold',
    italic: 'Italic',
    alignment: 'Alignment',
    alignLeft: 'Align Left',
    alignCenter: 'Align Center',
    alignRight: 'Align Right',
    alignJustify: 'Justify',
    lineHeight: 'Line Height',
    letterSpacing: 'Letter Spacing',
    textColor: 'Text Color',
    backgroundMask: 'Background Mask',
    maskEnabled: 'Cover original text behind edit',
    maskColor: 'Mask Color',
    maskPadding: 'Mask Padding',
    pickFromPage: 'Pick from page',
    resetToOriginal: 'Reset to Original',
    duplicateBlock: 'Duplicate',
    deleteBlock: 'Delete',
    patchSettings: 'Background Patch',
    fillColor: 'Fill Color',
    borderColor: 'Border Color',
    borderWidth: 'Border Width',
    opacity: 'Opacity',
    shapeSettings: 'Shape & Highlight',
    shapeType: 'Type',
    rectangle: 'Rectangle',
    highlight: 'Highlight',
    line: 'Line',
    imageSettings: 'Image & Signature',
    fontManagerTitle: 'Device, Google & Custom Fonts',
    fontManagerDesc:
      'Import all fonts from your device in one click, or search and add any font directly from Google Fonts.',
    uploadCustomFont: 'Import Font Files (.ttf / .otf)',
    loadDeviceFonts: 'Load All Device Fonts (1-Click)',
    loadingDeviceFonts: 'Loading device fonts...',
    deviceFontsResult: 'device fonts loaded',
    originalColorBtn: 'Original',
    googleFontSearchHeading: 'Search & Add from Google Fonts',
    googleFontSearchPlaceholder: 'Type font name (e.g. Baloo Da 2, Amiri, Cairo, Inter)',
    googleFontAddBtn: 'Add Font',
    googleFontLoading: 'Adding...',
    googleFontAdded: 'font added to app!',
    googleFontNotFound: 'Font not found on Google Fonts. Check spelling.',
    googleFontsQuickList: 'Popular Bangla, Arabic, Urdu, Persian & English Fonts',
    decreaseFontSize: 'Decrease font size',
    increaseFontSize: 'Increase font size',
    editParagraphBtn: 'Edit Paragraph',
    fontGroupBanglaEnglish: 'Bangla & English Fonts',
    fontGroupArabic: 'Arabic Fonts',
    fontGroupUrduPersian: 'Urdu & Persian Fonts',
    fontGroupDeviceGoogle: 'Device, Google & Custom Fonts',
    customFontsHeading: 'Device, Google & Custom Fonts',
    bundledFontsHeading: 'Bundled Bangla, Arabic, Urdu, Persian & English Fonts',
    detectedInDocHeading: 'Fonts Detected in Current PDF',
    noCustomFonts: 'Click above to load device fonts or add a Google Font.',
    applyToAllDetected: 'Apply to matching blocks',
    signatureTitle: 'Draw Signature',
    signatureDesc: 'Sign in Bangla, Arabic, or English on the pad below.',
    inkColor: 'Ink Color',
    clearSignature: 'Clear',
    insertSignature: 'Place on Page',
    close: 'Close',
    dropPdfPrompt: 'Drop your PDF file here',
    dropPdfSub: 'Automatically detects script, font, and text direction',
    emptyOpenBtn: 'Open PDF File',
    emptyOpenSub: 'Select a PDF from your device or drag and drop it here',
    loadingPdf: 'Parsing PDF layout & detecting scripts...',
    clickToPlaceText: 'Click anywhere on the page to add text',
    dragToDrawPatch: 'Drag to cover unwanted marks with matching background',
    dragToDrawShape: 'Drag to draw a box, line, or highlight',
    clickTextToEdit: 'Tap or double-click any paragraph on the page to edit',
    editedBadge: 'Edited',
    scriptSelectorLabel: 'Language & Script Direction',
    scriptBangla: 'বাংলা',
    scriptEnglish: 'English',
    scriptArabic: 'العربية',
    scriptUrdu: 'اردو',
    scriptPersian: 'فارسی',
    settingsTitle: 'Settings & Troubleshooting',
    settingsDesc: 'General preferences, automatic script detection, and quick PDF/font fixes.',
    tabGeneral: 'General',
    tabTroubleshoot: 'Troubleshoot',
    tabExport: 'Save & Quality',
    uiLanguageLabel: 'Interface Language',
    defaultScriptLabel: 'Default Language for New Text',
    defaultScriptDesc: 'Automatically selects font and RTL/LTR direction when adding new text.',
    defaultPageSizeLabel: 'Default New Page Size',
    autosaveLabel: 'Auto-save (every 30 seconds)',
    autosaveDesc: 'Saves document progress in browser storage to prevent data loss.',
    saveSnapshotNow: 'Save Now',
    snapshotSaved: 'Saved',
    paragraphGroupingLabel: 'Paragraph Grouping Mode',
    paragraphGroupingDesc: 'Group paragraph lines together; disable and re-scan if a table or form splits awkwardly.',
    autoNormalizeLabel: 'Auto-Repair Conjuncts & RTL Text',
    autoNormalizeDesc: 'Repairs Bangla vowel signs/reph and Arabic, Urdu & Persian ligature forms.',
    reparseCurrentPdf: 'Re-scan & Repair Current PDF',
    reparseDone: 'Current PDF re-scanned and repaired!',
    reloadAllFontsBtn: 'Reload All Device & 5-Script Fonts',
    fontsReloaded: 'fonts reloaded!',
    unlockSelectionBtn: 'Reset Stuck Tool / Selection',
    unlockDone: 'Active tool and selection reset.',
    clearCacheBtn: 'Clear Autosave & Temp Cache',
    clearCacheDone: 'Cache cleared.',
    exportQualityLabel: 'Image Export Resolution (PNG / JPEG)',
    qualityHd: 'HD (1280px)',
    qualityFullHd: 'Full HD (1920px+)',
    qualityUhd: 'Ultra HD (4K)',
    defaultMaskPaddingLabel: 'Default Mask Padding',
  },
};
