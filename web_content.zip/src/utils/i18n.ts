// Comprehensive internationalization (i18n) for JARVIS AI
// Supports English and Bengali (বাংলা) across all HUD, voice, settings, and modal components

export type SupportedLanguage = 'en' | 'bn' | 'auto';

export interface UIStrings {
  // HUD Header
  appTitle: string;
  appSubtitle: string;
  stateSleeping: string;
  stateListening: string;
  stateThinking: string;
  stateSpeaking: string;
  stateError: string;
  muteTooltip: string;
  unmuteTooltip: string;
  guideTooltip: string;

  // Arc Reactor
  standbyWakeText: string;
  standbyTapText: string;
  listeningText: string;
  thinkingText: string;
  speakingText: string;
  speakingBargeInText: string;
  alertText: string;
  wakeStopSubtext: string;
  continuousSubtext: string;
  thinkingSubtext: string;
  speakingSubtext: string;
  errorSubtext: string;
  handsFreeActiveBadge: string;
  pushToTalkBadge: string;
  micUnsupported: string;

  // Control Bar
  voiceModeOn: string;
  startVoiceMode: string;
  haltStop: string;
  voiceOn: string;
  voiceMuted: string;
  inputPlaceholder: string;
  wakeStopStrip: string;
  toggleKeyboard: string;
  switchLanguage: string;
  tacticalLog: string;
  settingsTitle: string;

  // Console Drawer
  consoleTitle: string;
  entriesLabel: string;
  clearHistory: string;
  closeConsole: string;
  quickOrders: string;
  noCommands: string;
  noCommandsSubtext: string;
  userCommand: string;
  vocalizeAgain: string;
  copyText: string;

  // Settings Modal
  settingsHeader: string;
  tabVoice: string;
  tabLanguage: string;
  tabSystem: string;
  tabGuide: string;

  voiceResponseTitle: string;
  voiceResponseDesc: string;
  autoSpeakTitle: string;
  autoSpeakDesc: string;
  voiceSelectorLabel: string;
  defaultVoiceLabel: string;
  testVoiceBtn: string;
  speechRateLabel: string;
  speechPitchLabel: string;
  resetVoiceParams: string;

  languageModeTitle: string;
  languageDesc: string;
  userSalutationLabel: string;

  apiStatusOnlineTitle: string;
  apiStatusRequiredTitle: string;
  apiStatusOnlineDesc: string;
  apiStatusRequiredDesc: string;
  micSensorTitle: string;
  micSensorStatus: string;
  testSensorBtn: string;
  soundEffectsTitle: string;
  soundEffectsDesc: string;
  hapticTitle: string;
  hapticDesc: string;

  dismissSettings: string;

  // Quick Prompts
  promptDate: string;
  promptStatus: string;
  promptQuote: string;
  promptCapabilities: string;
}

const en: UIStrings = {
  appTitle: 'J.A.R.V.I.S.',
  appSubtitle: 'AI PERSONAL ASSISTANT',
  stateSleeping: 'SLEEPING',
  stateListening: 'LISTENING',
  stateThinking: 'THINKING',
  stateSpeaking: 'SPEAKING',
  stateError: 'ERROR',
  muteTooltip: 'Mute vocal responses',
  unmuteTooltip: 'Enable vocal responses',
  guideTooltip: 'Setup instructions & Help',

  standbyWakeText: "STANDBY • SAY 'JARVIS' TO WAKE",
  standbyTapText: 'STANDBY • TAP TO WAKE',
  listeningText: 'LISTENING FOR COMMAND...',
  thinkingText: 'PROCESSING WITH GEMINI...',
  speakingText: 'SPEAKING • TAP OR TALK TO INTERRUPT',
  speakingBargeInText: 'INTERRUPTED • LISTENING TO YOU',
  alertText: 'SYSTEM ALERT',
  wakeStopSubtext: "WAKE: 'JARVIS' • STOP: 'STOP NOW'",
  continuousSubtext: 'CONTINUOUS VOICE MODE ACTIVE',
  thinkingSubtext: 'NEURAL MATRIX COMPUTING',
  speakingSubtext: 'SPEAK OR TAP TO BARGE IN',
  errorSubtext: 'CHECK PERMISSIONS / SENSORS',
  handsFreeActiveBadge: 'HANDS-FREE: ACTIVE',
  pushToTalkBadge: 'PUSH-TO-TALK MODE',
  micUnsupported: 'Speech recognition requires Chrome on Android or compatible browser',

  voiceModeOn: 'VOICE MODE: ON',
  startVoiceMode: 'START VOICE MODE',
  haltStop: 'HALT / STOP',
  voiceOn: 'VOICE ON',
  voiceMuted: 'MUTED',
  inputPlaceholder: 'Enter your command to JARVIS...',
  wakeStopStrip: 'WAKE: "JARVIS" • STOP: "STOP NOW"',
  toggleKeyboard: 'Toggle text input keyboard',
  switchLanguage: 'Switch Language (AUTO / EN / বাংলা)',
  tacticalLog: 'Tactical Message Log',
  settingsTitle: 'Settings & Browser Permissions',

  consoleTitle: 'TACTICAL LOG CONSOLE',
  entriesLabel: 'ENTRIES',
  clearHistory: 'Clear conversation',
  closeConsole: 'RETURN TO CORE HUD',
  quickOrders: 'QUICK ORDERS:',
  noCommands: 'NO COMMANDS LOGGED',
  noCommandsSubtext: 'Speak directly or select a quick order prompt above.',
  userCommand: 'USER COMMAND',
  vocalizeAgain: 'Vocalize',
  copyText: 'Copy text',

  settingsHeader: 'JARVIS PROTOCOLS & CONFIG',
  tabVoice: 'VOICE & TTS',
  tabLanguage: 'LANGUAGE',
  tabSystem: 'API & SENSORS',
  tabGuide: 'SETUP GUIDE',

  voiceResponseTitle: 'Vocal Response (TTS)',
  voiceResponseDesc: 'Speak JARVIS replies aloud',
  autoSpeakTitle: 'Auto-Speak on Response',
  autoSpeakDesc: 'Immediately vocalize once reply arrives',
  voiceSelectorLabel: 'Synthesized Voice Selection (Female preferred)',
  defaultVoiceLabel: 'Default Recommended (Auto Natural Female)',
  testVoiceBtn: 'Test',
  speechRateLabel: 'Speech Rate',
  speechPitchLabel: 'Speech Pitch',
  resetVoiceParams: 'Reset Speech Parameters',

  languageModeTitle: 'Assistant Language Mode',
  languageDesc: 'Choose whether JARVIS responds in English, Bengali, or auto-detects.',
  userSalutationLabel: 'How should JARVIS address you?',

  apiStatusOnlineTitle: 'Gemini Intelligence Online',
  apiStatusRequiredTitle: 'Gemini API Key Required',
  apiStatusOnlineDesc: 'Operational on gemini-3.1-flash-lite via secure server-side endpoint.',
  apiStatusRequiredDesc: 'Please configure GEMINI_API_KEY in your AI Studio Secrets.',
  micSensorTitle: 'Speech Recognition Sensor',
  micSensorStatus: 'Status:',
  testSensorBtn: 'Test Sensor',
  soundEffectsTitle: 'Futuristic Sound Effects',
  soundEffectsDesc: 'Tactical HUD chime on speech and boot',
  hapticTitle: 'Haptic Feedback',
  hapticDesc: 'Vibrate on microphone activation (Android)',

  dismissSettings: 'DISMISS CONFIG',

  promptDate: "What is today's date?",
  promptStatus: 'JARVIS, status report',
  promptQuote: 'Give me a productive quote for today',
  promptCapabilities: 'What can you do as my personal AI?',
};

const bn: UIStrings = {
  appTitle: 'জার্ভিস',
  appSubtitle: 'এআই পার্সোনাল অ্যাসিস্ট্যান্ট',
  stateSleeping: 'স্লিপ মোড',
  stateListening: 'শুনছি',
  stateThinking: 'ভাবছি',
  stateSpeaking: 'বলছি',
  stateError: 'ত্রুটি',
  muteTooltip: 'কণ্ঠস্বর নিঃশব্দ করুন',
  unmuteTooltip: 'কণ্ঠস্বর চালু করুন',
  guideTooltip: 'নির্দেশিকা ও সাহায্য',

  standbyWakeText: "স্ট্যান্ডবাই • জাগাতে 'জার্ভিস' বলুন",
  standbyTapText: 'স্ট্যান্ডবাই • স্পর্শ করে জাগান',
  listeningText: 'আপনার নির্দেশের অপেক্ষায়...',
  thinkingText: 'জেমিনির মাধ্যমে প্রসেস হচ্ছে...',
  speakingText: 'কথা বলছি • থামাতে স্পর্শ করুন বা কথা বলুন',
  speakingBargeInText: 'থেমেছি • আপনার কথা শুনছি',
  alertText: 'সিস্টেম অ্যালার্ট',
  wakeStopSubtext: "জাগাতে: 'জার্ভিস' • থামাতে: 'এখন থামো'",
  continuousSubtext: 'কন্টিনিউয়াস ভয়েস মোড চালু',
  thinkingSubtext: 'নিউরাল প্রসেসিং চলছে',
  speakingSubtext: 'থামাতে স্পর্শ করুন বা কথা বলুন',
  errorSubtext: 'মাইক্রোফোন অনুমতি পরীক্ষা করুন',
  handsFreeActiveBadge: 'হ্যান্ডস-ফ্রি: চালু',
  pushToTalkBadge: 'পুশ-টু-টক মোড',
  micUnsupported: 'স্পিচ রেকগনিশনের জন্য অ্যান্ড্রয়েড ক্রোম বা উপযুক্ত ব্রাউজার প্রয়োজন',

  voiceModeOn: 'ভয়েস মোড: চালু',
  startVoiceMode: 'ভয়েস মোড চালু করুন',
  haltStop: 'থামো / বন্ধ',
  voiceOn: 'ভয়েস চালু',
  voiceMuted: 'মিউট',
  inputPlaceholder: 'জার্ভিসকে আপনার নির্দেশনা বলুন বা টাইপ করুন...',
  wakeStopStrip: 'জাগাতে: "জার্ভিস" • থামাতে: "এখন থামো"',
  toggleKeyboard: 'কীবোর্ড ইনপুট খুলুন/বন্ধ করুন',
  switchLanguage: 'ভাষা পরিবর্তন (AUTO / EN / বাংলা)',
  tacticalLog: 'কমান্ড হিস্ট্রি লগ',
  settingsTitle: 'সেটিংস ও ব্রাউজার পারমিশন',

  consoleTitle: 'কমান্ড হিস্ট্রি কনসোল',
  entriesLabel: 'টি এন্ট্রি',
  clearHistory: 'কথোপকথন মুছুন',
  closeConsole: 'মূল স্ক্রিনে ফিরুন',
  quickOrders: 'দ্রুত নির্দেশাবলী:',
  noCommands: 'কোনো কমান্ড হিস্ট্রি নেই',
  noCommandsSubtext: 'সরাসরি মুখে কথা বলুন অথবা উপরের দ্রুত নির্দেশনায় ট্যাপ করুন।',
  userCommand: 'ব্যবহারকারীর নির্দেশ',
  vocalizeAgain: 'শুনুন',
  copyText: 'কপি করুন',

  settingsHeader: 'জার্ভিস প্রোটোকল ও কনফিগ',
  tabVoice: 'ভয়েস ও স্পিচ',
  tabLanguage: 'ভাষা নির্বাচন',
  tabSystem: 'এপিআই ও সেন্সর',
  tabGuide: 'ব্যবহার নির্দেশিকা',

  voiceResponseTitle: 'কণ্ঠে উত্তর দিন (TTS)',
  voiceResponseDesc: 'জার্ভিসের উত্তর মুখে পড়ে শোনানো হবে',
  autoSpeakTitle: 'স্বয়ংক্রিয় উচ্চারণ',
  autoSpeakDesc: 'উত্তর আসার সাথে সাথে মুখে বলবে',
  voiceSelectorLabel: 'কণ্ঠস্বর নির্বাচন (নারী কণ্ঠ অগ্রাধিকার)',
  defaultVoiceLabel: 'ডিফল্ট প্রস্তাবিত (স্বয়ংক্রিয় প্রাকৃতিক নারী কণ্ঠ)',
  testVoiceBtn: 'পরীক্ষা',
  speechRateLabel: 'কথা বলার গতি',
  speechPitchLabel: 'কথা বলার সুর (পিচ)',
  resetVoiceParams: 'ডিফল্ট সেটিংসে ফিরুন',

  languageModeTitle: 'অ্যাসিস্ট্যান্টের ভাষা মোড',
  languageDesc: 'বাংলা, ইংরেজি অথবা স্বয়ংক্রিয় ভাষা নির্ধারণ করুন।',
  userSalutationLabel: 'জার্ভিস আপনাকে কীভাবে সম্বোধন করবে?',

  apiStatusOnlineTitle: 'জেমিনি এআই অনলাইন',
  apiStatusRequiredTitle: 'জেমিনি এপিআই কি প্রয়োজন',
  apiStatusOnlineDesc: 'gemini-3.1-flash-lite সার্ভার-সাইড এপিআই সক্রিয়।',
  apiStatusRequiredDesc: 'অনুগ্রহ করে AI Studio Secrets-এ GEMINI_API_KEY যুক্ত করুন।',
  micSensorTitle: 'স্পিচ রেকগনিশন সেন্সর',
  micSensorStatus: 'অবস্থা:',
  testSensorBtn: 'সেন্সর পরীক্ষা',
  soundEffectsTitle: 'ফিউচারিস্টিক সাউন্ড ইফেক্ট',
  soundEffectsDesc: 'কথা বলা ও অ্যাক্টিভেশনের সাউন্ড',
  hapticTitle: 'হ্যাপটিক কম্পন',
  hapticDesc: 'মাইক্রোফোন চালুর সময় মোবাইল ভাইব্রেশন',

  dismissSettings: 'সেটিংস বন্ধ করুন',

  promptDate: 'আজকের তারিখ কত?',
  promptStatus: 'জার্ভিস, সিস্টেমের অবস্থা জানাও',
  promptQuote: 'আমাকে একটি অনুপ্রেরণামূলক উক্তি শোনান',
  promptCapabilities: 'তুমি আমার জন্য কী কী করতে পারো?',
};

export function getUIStrings(lang: string): UIStrings {
  if (lang === 'bn') return bn;
  return en;
}
