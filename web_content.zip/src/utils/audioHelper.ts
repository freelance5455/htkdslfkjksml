/**
 * Audio helper for voice message playback and synthesis in Phoenix Project Manager
 */

// Generate a valid base64-encoded WAV audio clip using browser Web Audio API
export function createSynthesizedVoiceNote(
  frequency = 320,
  durationSec = 5,
  pattern: 'engineer' | 'client' | 'urgent' = 'engineer'
): string {
  try {
    const sampleRate = 22050;
    const numSamples = Math.floor(sampleRate * durationSec);
    const buffer = new ArrayBuffer(44 + numSamples * 2);
    const view = new DataView(buffer);

    // Write WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    writeString(0, 'RIFF');
    view.setUint32(4, 36 + numSamples * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true); // PCM chunk size
    view.setUint16(20, 1, true); // Format 1 = PCM
    view.setUint16(22, 1, true); // 1 channel (mono)
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true); // byte rate
    view.setUint16(32, 2, true); // block align
    view.setUint16(34, 16, true); // bits per sample
    writeString(36, 'data');
    view.setUint32(40, numSamples * 2, true);

    // Generate voice-like modulated audio waveform
    let offset = 44;
    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;
      let sample = 0;

      if (pattern === 'engineer') {
        // Human voice fundamental frequencies with natural cadence pauses
        const syllableCadence = Math.sin(2 * Math.PI * 3.5 * t);
        const pitchMod = Math.sin(2 * Math.PI * 180 * t) * 0.6 + Math.sin(2 * Math.PI * 360 * t) * 0.3;
        sample = pitchMod * Math.max(0, syllableCadence);
      } else if (pattern === 'client') {
        const syllableCadence = Math.sin(2 * Math.PI * 4 * t);
        const pitchMod = Math.sin(2 * Math.PI * 220 * t) * 0.5 + Math.sin(2 * Math.PI * 440 * t) * 0.35;
        sample = pitchMod * Math.max(0, syllableCadence);
      } else {
        const syllableCadence = Math.sin(2 * Math.PI * 5 * t);
        const pitchMod = Math.sin(2 * Math.PI * 280 * t) * 0.7;
        sample = pitchMod * Math.max(0, syllableCadence);
      }

      // Soft envelope at start and end
      const envelope = Math.min(1, Math.min(t * 10, (durationSec - t) * 5));
      sample = sample * envelope * 0.45;

      const intSample = Math.max(-1, Math.min(1, sample)) * 0x7fff;
      view.setInt16(offset, intSample, true);
      offset += 2;
    }

    // Convert buffer to base64
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return `data:audio/wav;base64,${btoa(binary)}`;
  } catch (err) {
    console.error('Audio synthesis error:', err);
    return '';
  }
}

// Format seconds into MM:SS
export function formatAudioDuration(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '00:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}
