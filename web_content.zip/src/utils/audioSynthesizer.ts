// Web Audio API sound generator for JARVIS futuristic audio feedback

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

/**
 * Play a futuristic sci-fi JARVIS activation chime
 */
export function playJarvisChime() {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(440, now);
  osc.frequency.exponentialRampToValueAtTime(880, now + 0.1);
  osc.frequency.exponentialRampToValueAtTime(1320, now + 0.22);

  gain.gain.setValueAtTime(0.12, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + 0.35);
}

/**
 * Play futuristic diagnostic test sweep sound
 */
export function playDiagnosticSweep() {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const osc1 = ctx.createOscillator();
  const osc2 = ctx.createOscillator();
  const gain = ctx.createGain();

  osc1.type = 'triangle';
  osc1.frequency.setValueAtTime(523.25, now); // C5
  osc1.frequency.linearRampToValueAtTime(1046.5, now + 0.2); // C6

  osc2.type = 'sine';
  osc2.frequency.setValueAtTime(659.25, now); // E5
  osc2.frequency.linearRampToValueAtTime(1318.5, now + 0.25); // E6

  gain.gain.setValueAtTime(0.15, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

  osc1.connect(gain);
  osc2.connect(gain);
  gain.connect(ctx.destination);

  osc1.start(now);
  osc2.start(now);
  osc1.stop(now + 0.4);
  osc2.stop(now + 0.4);
}

/**
 * Play sci-fi incoming call ring tone
 */
let ringtoneInterval: number | null = null;

export function startCallRingtone(): () => void {
  const playPulse = () => {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(784, now); // G5
    osc.frequency.setValueAtTime(987.77, now + 0.15); // B5

    gain.gain.setValueAtTime(0.12, now);
    gain.gain.linearRampToValueAtTime(0.12, now + 0.3);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.45);
  };

  playPulse();
  ringtoneInterval = window.setInterval(playPulse, 1800);

  return () => {
    if (ringtoneInterval) {
      clearInterval(ringtoneInterval);
      ringtoneInterval = null;
    }
  };
}

/**
 * Play futuristic call connected confirmation tone
 */
export function playCallConnectedTone(): void {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const osc1 = ctx.createOscillator();
  const osc2 = ctx.createOscillator();
  const gain = ctx.createGain();

  osc1.type = 'sine';
  osc1.frequency.setValueAtTime(587.33, now); // D5
  osc1.frequency.setValueAtTime(880, now + 0.12); // A5

  gain.gain.setValueAtTime(0.12, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

  osc1.connect(gain);
  gain.connect(ctx.destination);

  osc1.start(now);
  osc1.stop(now + 0.3);
}

/**
 * Play futuristic call ended tone
 */
export function playCallEndedTone(): void {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(880, now); // A5
  osc.frequency.setValueAtTime(440, now + 0.15); // A4

  gain.gain.setValueAtTime(0.12, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + 0.35);
}

/**
 * Play simple customizable tone for mute/unmute UI feedback
 */
export function playTone(freq: number = 440, duration: number = 0.12, type: OscillatorType = 'sine'): void {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(freq, now);

  gain.gain.setValueAtTime(0.08, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + duration);
}

import {
  VoiceProfileId,
  VOICE_PROFILES,
  normalizeVoiceProfile,
  selectBestVoiceForProfile,
} from './voiceProfiles';

let cachedVoices: SpeechSynthesisVoice[] = [];
if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  cachedVoices = window.speechSynthesis.getVoices();
  window.speechSynthesis.onvoiceschanged = () => {
    cachedVoices = window.speechSynthesis.getVoices();
  };
}

export function isSpeechSynthesisSupported(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}

export function getAvailableVoices(): SpeechSynthesisVoice[] {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return [];
  const voices = window.speechSynthesis.getVoices();
  return voices.length > 0 ? voices : cachedVoices;
}

/**
 * Text to Speech with cinematic voice profile tuning, dynamic voice inspection,
 * pitch shaping, and smooth pacing.
 */
let activeUtterance: SpeechSynthesisUtterance | null = null;
let speechTimeout: number | null = null;

export function speakJarvis(
  text: string,
  pitch = 1.0,
  rate = 1.0,
  personality: string = 'JARVIS',
  onEnd?: () => void
): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    onEnd?.();
    return;
  }

  // Clear previous speech & timer
  stopSpeaking();

  const profileId = normalizeVoiceProfile(personality);
  const profile = VOICE_PROFILES[profileId];

  const utterance = new SpeechSynthesisUtterance(text);
  activeUtterance = utterance;

  // Calculate target pitch and rate based on profile characteristics
  const calculatedPitch = Math.max(0.5, Math.min(2.0, pitch * profile.recommendedPitch));
  const calculatedRate = Math.max(0.5, Math.min(2.0, rate * profile.recommendedSpeed));

  utterance.pitch = calculatedPitch;
  utterance.rate = calculatedRate;

  const voices = getAvailableVoices();
  const selectedVoice = selectBestVoiceForProfile(profileId, voices);
  if (selectedVoice) {
    utterance.voice = selectedVoice;
  }

  let hasEnded = false;
  const finish = () => {
    if (hasEnded) return;
    hasEnded = true;
    if (speechTimeout) {
      clearTimeout(speechTimeout);
      speechTimeout = null;
    }
    activeUtterance = null;
    onEnd?.();
  };

  utterance.onend = finish;
  utterance.onerror = finish;

  // Safety fallback timer based on word count (~130 words/min) with generous cushion
  const wordCount = text.split(/\s+/).filter(Boolean).length;
  const approxDurationMs = Math.max(2500, (wordCount / (2.2 * calculatedRate)) * 1000 + 2500);
  speechTimeout = window.setTimeout(finish, approxDurationMs);

  window.speechSynthesis.speak(utterance);
}

/**
 * Play a short voice sample for a specific voice profile
 */
export function playTestVoice(
  profileId: VoiceProfileId,
  pitch = 1.0,
  speed = 1.0,
  onEnd?: () => void
): void {
  const profile = VOICE_PROFILES[profileId];
  speakJarvis(profile.testPhrase, pitch, speed, profileId, onEnd);
}

export function stopSpeaking(): void {
  if (speechTimeout) {
    clearTimeout(speechTimeout);
    speechTimeout = null;
  }
  activeUtterance = null;
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}
