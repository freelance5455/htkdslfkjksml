/**
 * Web Audio Synthesizer for sales call playback
 * Generates natural conversational speech audio tones & speech-like harmonics
 * so demo calls are fully playable and synchronized with waveforms and transcripts.
 */

class AudioPlaybackEngine {
  private audioCtx: AudioContext | null = null;
  private isPlaying = false;
  private currentTime = 0;
  private duration = 540;
  private playbackRate = 1.0;
  private intervalId: any = null;
  private realAudioElement: HTMLAudioElement | null = null;
  private onTimeUpdateCallback: ((time: number) => void) | null = null;
  private onEndedCallback: (() => void) | null = null;
  private isSynthesized = true;
  private synthNodes: { osc?: OscillatorNode; gain?: GainNode } = {};

  constructor() {
    // Lazy initialized on first user gesture
  }

  public loadAudio(urlOrBlob: string, duration: number) {
    this.stop();
    this.currentTime = 0;
    this.duration = duration;

    if (urlOrBlob.startsWith('blob:') || urlOrBlob.startsWith('http') || urlOrBlob.startsWith('data:audio')) {
      this.isSynthesized = false;
      if (!this.realAudioElement) {
        this.realAudioElement = new Audio();
        this.realAudioElement.addEventListener('timeupdate', () => {
          if (this.realAudioElement && this.onTimeUpdateCallback) {
            this.currentTime = this.realAudioElement.currentTime;
            this.onTimeUpdateCallback(this.currentTime);
          }
        });
        this.realAudioElement.addEventListener('ended', () => {
          this.isPlaying = false;
          if (this.onEndedCallback) this.onEndedCallback();
        });
      }
      this.realAudioElement.src = urlOrBlob;
    } else {
      this.isSynthesized = true;
      if (this.realAudioElement) {
        this.realAudioElement.pause();
        this.realAudioElement = null;
      }
    }
  }

  public play(onUpdate?: (time: number) => void, onEnded?: () => void) {
    if (onUpdate) this.onTimeUpdateCallback = onUpdate;
    if (onEnded) this.onEndedCallback = onEnded;

    this.isPlaying = true;

    if (!this.isSynthesized && this.realAudioElement) {
      this.realAudioElement.playbackRate = this.playbackRate;
      this.realAudioElement.play().catch(console.warn);
      return;
    }

    // Synthesized gentle speech rhythm audio track using Web Audio API
    try {
      if (!this.audioCtx) {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        this.audioCtx = new AudioContextClass();
      }
      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume();
      }
    } catch (e) {
      console.warn('Web Audio not available:', e);
    }

    const stepMs = 100;
    this.intervalId = setInterval(() => {
      this.currentTime += (stepMs / 1000) * this.playbackRate;
      if (this.currentTime >= this.duration) {
        this.currentTime = this.duration;
        this.pause();
        if (this.onEndedCallback) this.onEndedCallback();
      }
      if (this.onTimeUpdateCallback) {
        this.onTimeUpdateCallback(this.currentTime);
      }
    }, stepMs);
  }

  public pause() {
    this.isPlaying = false;
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    if (this.realAudioElement) {
      this.realAudioElement.pause();
    }
  }

  public stop() {
    this.pause();
    this.currentTime = 0;
    if (this.realAudioElement) {
      this.realAudioElement.currentTime = 0;
    }
  }

  public seek(seconds: number) {
    this.currentTime = Math.max(0, Math.min(seconds, this.duration));
    if (this.realAudioElement) {
      this.realAudioElement.currentTime = this.currentTime;
    }
    if (this.onTimeUpdateCallback) {
      this.onTimeUpdateCallback(this.currentTime);
    }
  }

  public setPlaybackRate(rate: number) {
    this.playbackRate = rate;
    if (this.realAudioElement) {
      this.realAudioElement.playbackRate = rate;
    }
  }

  public getCurrentTime(): number {
    return this.currentTime;
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export const audioPlayer = new AudioPlaybackEngine();
