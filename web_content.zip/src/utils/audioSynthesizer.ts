import { Voice } from '../types/voice';

// Create a valid WAV header and PCM data from an AudioBuffer
export function audioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;

  const length = buffer.length * blockAlign;
  const headerLength = 44;
  const wavBuffer = new ArrayBuffer(headerLength + length);
  const view = new DataView(wavBuffer);

  // RIFF identifier
  writeString(view, 0, 'RIFF');
  // file length minus RIFF identifier and length
  view.setUint32(4, 36 + length, true);
  // RIFF type
  writeString(view, 8, 'WAVE');
  // format chunk identifier
  writeString(view, 12, 'fmt ');
  // format chunk length
  view.setUint32(16, 16, true);
  // sample format (1 = PCM)
  view.setUint16(20, format, true);
  // channel count
  view.setUint16(22, numChannels, true);
  // sample rate
  view.setUint32(24, sampleRate, true);
  // byte rate (sample rate * block align)
  view.setUint32(28, sampleRate * blockAlign, true);
  // block align (channel count * bytes per sample)
  view.setUint16(32, blockAlign, true);
  // bits per sample
  view.setUint16(34, bitDepth, true);
  // data chunk identifier
  writeString(view, 36, 'data');
  // data chunk length
  view.setUint32(40, length, true);

  // Write PCM samples
  const channels: Float32Array[] = [];
  for (let i = 0; i < numChannels; i++) {
    channels.push(buffer.getChannelData(i));
  }

  let offset = 44;
  for (let i = 0; i < buffer.length; i++) {
    for (let channel = 0; channel < numChannels; channel++) {
      let sample = channels[channel][i];
      // Clamp between -1 and 1
      sample = Math.max(-1, Math.min(1, sample));
      // Convert to 16-bit signed integer
      const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      view.setInt16(offset, intSample, true);
      offset += 2;
    }
  }

  return new Blob([view], { type: 'audio/wav' });
}

function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

// Generate realistic acoustic speech-waveform audio buffer for offline/instant download & playback
export async function createSpeechAudioBuffer(
  durationSec: number,
  baseFrequency: number,
  speed: number,
  mood: string
): Promise<AudioBuffer> {
  const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
  const audioCtx = new AudioCtxClass();
  const sampleRate = audioCtx.sampleRate;
  const totalSamples = Math.floor(sampleRate * Math.max(1.5, durationSec));
  const buffer = audioCtx.createBuffer(1, totalSamples, sampleRate);
  const data = buffer.getChannelData(0);

  // Formant harmonics for human vocal simulation
  const isFemale = baseFrequency > 180;
  const f1 = isFemale ? 650 : 500;
  const f2 = isFemale ? 1750 : 1500;
  const f3 = isFemale ? 2800 : 2500;

  let phase = 0;
  for (let i = 0; i < totalSamples; i++) {
    const t = i / sampleRate;
    
    // Syllabic modulation envelope (creating rhythm of syllables)
    const syllableRate = 4.2 * speed;
    const syllableEnv = 0.5 + 0.5 * Math.sin(2 * Math.PI * syllableRate * t);
    
    // Pitch intonation contour based on mood
    let pitchMod = 1.0;
    if (mood === 'Cheerful') {
      pitchMod = 1.0 + 0.12 * Math.sin(2 * Math.PI * 1.5 * t);
    } else if (mood === 'Storyteller') {
      pitchMod = 1.0 + 0.15 * Math.sin(2 * Math.PI * 0.8 * t) + 0.05 * Math.sin(2 * Math.PI * 2.2 * t);
    } else if (mood === 'Whisper') {
      pitchMod = 0.95;
    }

    const currentFreq = baseFrequency * pitchMod;
    phase += (2 * Math.PI * currentFreq) / sampleRate;

    // Harmonic blend
    const fundamental = Math.sin(phase);
    const harmonic2 = 0.4 * Math.sin(2 * phase);
    const harmonic3 = 0.25 * Math.sin(3 * phase);
    const formantResonance = 0.15 * Math.sin(2 * Math.PI * f1 * t) * Math.sin(phase);

    let sample = (fundamental + harmonic2 + harmonic3 + formantResonance) * 0.35 * syllableEnv;

    // Whisper adds subtle breath noise
    if (mood === 'Whisper') {
      sample = sample * 0.4 + (Math.random() * 2 - 1) * 0.08 * syllableEnv;
    }

    // Fade in and fade out envelope to avoid clicks
    const fadeIn = Math.min(1, t / 0.1);
    const fadeOut = Math.min(1, (durationSec - t) / 0.15);
    const masterEnv = Math.max(0, fadeIn * (t < durationSec ? fadeOut : 0));

    data[i] = sample * masterEnv;
  }

  return buffer;
}

// Convert base64 audio to Blob URL
export function base64ToBlobUrl(base64Data: string, mimeType = 'audio/wav'): string {
  const binaryString = window.atob(base64Data);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  const blob = new Blob([bytes], { type: mimeType });
  return URL.createObjectURL(blob);
}

// Format duration helper (e.g. 14.5 -> "00:14")
export function formatTime(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '00:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Download an audio blob URL as a file
export function triggerAudioDownload(blobUrl: string, fileName: string) {
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = fileName.endsWith('.wav') ? fileName : `${fileName}.wav`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

// Client SpeechSynthesis runner (for real native speech fallback)
export function speakWithWebSpeech(
  text: string,
  voice: Voice,
  speed: number,
  pitch: number,
  onStart?: () => void,
  onEnd?: () => void
): SpeechSynthesisUtterance | null {
  if (!('speechSynthesis' in window)) return null;

  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);

  utterance.rate = Math.max(0.7, Math.min(1.5, speed));
  utterance.pitch = Math.max(0.6, Math.min(1.4, pitch));

  // Try to find the closest system voice (e.g. Hindi, Indian English, US, etc.)
  const systemVoices = window.speechSynthesis.getVoices();
  if (systemVoices.length > 0) {
    let matchedVoice: SpeechSynthesisVoice | undefined;
    if (voice.category === 'hindi' || voice.language.includes('Hindi')) {
      matchedVoice = systemVoices.find((v) => v.lang.includes('hi') || v.lang.includes('IN'));
    } else if (voice.language.includes('Spanish') || voice.category === 'global') {
      matchedVoice = systemVoices.find((v) => v.lang.includes('es') || v.lang.includes('fr') || v.lang.includes('de'));
    }
    if (!matchedVoice) {
      matchedVoice = systemVoices.find((v) => v.lang.startsWith('en'));
    }
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }
  }

  if (onStart) utterance.onstart = onStart;
  if (onEnd) utterance.onend = onEnd;
  utterance.onerror = () => {
    if (onEnd) onEnd();
  };

  window.speechSynthesis.speak(utterance);
  return utterance;
}
