// Centralized Multi-Channel Audio Manager for Habivio
// Provides independent alarm sound channels, procedural nature sounds, task completion chimes,
// and ensures ringtones NEVER play simultaneously unless on separate channels.

import { requestScreenWakeLock, releaseScreenWakeLock, startBackgroundAudioKeepAlive } from './wakeLockManager';

export interface SoundOption {
  id: string;
  nameBn: string;
  nameEn: string;
  descriptionBn: string;
  descriptionEn: string;
  icon: string;
  category: 'nature' | 'spiritual' | 'gentle' | 'classic' | 'urgent' | 'custom' | 'silent';
}

export const SOUND_LIBRARY: SoundOption[] = [
  {
    id: 'morning_birds',
    nameBn: 'ভোরের স্নিগ্ধ পাখির গান',
    nameEn: 'Gentle Dawn Birdsong',
    descriptionBn: 'ভোরের শান্ত প্রকৃতি ও মিষ্টি পাখির ডাকের মেলোডি',
    descriptionEn: 'Soft morning breeze and melodic sweet chirping',
    icon: '🐦',
    category: 'nature',
  },
  {
    id: 'forest_birds',
    nameBn: 'অরণ্যের পাখির কলতান',
    nameEn: 'Forest Birds Melody',
    descriptionBn: 'গভীর বনের বহুস্তর মিষ্টি পাখির সুমধুর ডাক',
    descriptionEn: 'Multi-layer woodland bird harmony in peaceful nature',
    icon: '🌲',
    category: 'nature',
  },
  {
    id: 'flowing_water',
    nameBn: 'ঝর্ণার বহমান পানির শব্দ',
    nameEn: 'Flowing Mountain Stream',
    descriptionBn: 'প্রশান্তিময় পাহাড়ি ঝর্ণা ও বহমান স্নিগ্ধ জলধারা',
    descriptionEn: 'Peaceful soothing mountain brook and bubbling stream',
    icon: '💧',
    category: 'nature',
  },
  {
    id: 'soft_rain',
    nameBn: 'শান্তিময় বৃষ্টির শব্দ',
    nameEn: 'Gentle Soft Rain',
    descriptionBn: 'মাটির মিষ্টি গন্ধ ও হালকা বৃষ্টির প্রশান্তিদায়ক সুর',
    descriptionEn: 'Mindful gentle raindrops falling on leaves',
    icon: '🌧️',
    category: 'nature',
  },
  {
    id: 'gentle_wind',
    nameBn: 'স্নিগ্ধ পাহাড়ি বাতাস',
    nameEn: 'Gentle Mountain Breeze',
    descriptionBn: 'মনোরম শান্ত বাতাস ও পাতার শনশন মৃদু ধ্বনি',
    descriptionEn: 'Subtle ambient breeze for mindful waking',
    icon: '🍃',
    category: 'nature',
  },
  {
    id: 'zen_bell',
    nameBn: 'প্রশান্ত জেন হারমোনি (৫২৮Hz)',
    nameEn: 'Peaceful Zen Bell (528Hz)',
    descriptionBn: '৫২৮ হার্টজের নিরাময়কারী সুরেলা রেজোন্যান্স বেল',
    descriptionEn: 'Harmonic resonant Solfeggio bell for mindful focus',
    icon: '🔔',
    category: 'gentle',
  },
  {
    id: 'soft_chime',
    nameBn: 'মৃদু সুরের ঘণ্টা',
    nameEn: 'Soft Gentle Chime',
    descriptionBn: 'ঔষধ ও রিমাইন্ডারের জন্য চমৎকার দ্বি-সুর ঘণ্টা',
    descriptionEn: 'Two-tone pleasant acoustic chime',
    icon: '✨',
    category: 'gentle',
  },
  {
    id: 'adhan_spiritual',
    nameBn: 'আধ্যাত্মিক আজান ও ঘণ্টা',
    nameEn: 'Spiritual Adhan Chime',
    descriptionBn: 'পবিত্র সুমধুর ঘণ্টা ও আজানের শান্তিময় সুরধ্বনি',
    descriptionEn: 'Soothing prayer bell and spiritual harmonic chime',
    icon: '🕌',
    category: 'spiritual',
  },
  {
    id: 'classic_beep',
    nameBn: 'ক্লাসিক্যাল ডিজিটাল বিপ',
    nameEn: 'Classic Digital Beep',
    descriptionBn: 'চিরচেনা ইলেকট্রনিক অ্যালার্ম ঘড়ির বিপ-বিপ শব্দ',
    descriptionEn: 'Traditional digital alarm clock cadence',
    icon: '⏰',
    category: 'classic',
  },
  {
    id: 'emergency_siren',
    nameBn: 'জরুরি উচ্চ সাইরেন',
    nameEn: 'Loud Emergency Siren',
    descriptionBn: 'সর্বাধিক শক্তিশালী শব্দ, ঘুম ভাঙানোর সর্বোচ্চ নিশ্চয়তা',
    descriptionEn: 'Piercing multi-tone emergency siren',
    icon: '🚨',
    category: 'urgent',
  },
  {
    id: 'custom_audio',
    nameBn: 'নিজস্ব পছন্দের অডিও',
    nameEn: 'Custom Uploaded Audio',
    descriptionBn: 'আপনার ডিভাইস থেকে আপলোড করা পছন্দের অডিও',
    descriptionEn: 'Upload any adhan, recitation, or sound file',
    icon: '📁',
    category: 'custom',
  },
  {
    id: 'silent',
    nameBn: '🔕 নীরব (শুধু ভাইব্রেশন ও স্ক্রিন)',
    nameEn: '🔕 Silent (Vibration & Screen Only)',
    descriptionBn: 'কোনো শব্দ বাজবে না, কেবল স্ক্রিন ও ভাইব্রেশন হবে',
    descriptionEn: 'Muted; alerts via screen wake & tactile vibration only',
    icon: '🔕',
    category: 'silent',
  },
];

// Compatibility export
export const ALARM_TONE_OPTIONS = SOUND_LIBRARY;

// Storage keys
const STORAGE_KEYS = {
  SELECTED_TONE: 'habivio_selected_alarm_tone',
  CUSTOM_AUDIO: 'habivio_custom_alarm_audio_data',
  CUSTOM_NAME: 'habivio_custom_alarm_audio_name',
  COMPLETION_SOUND_ENABLED: 'habivio_completion_sound_enabled',
  COMPLETION_SOUND_TONE: 'habivio_completion_sound_tone',
  ALARM_VOLUME: 'habivio_alarm_volume',
};

// Procedural audio context singleton
let audioCtx: AudioContext | null = null;
function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

// Write WAV headers
function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

// Generate Siren WAV only when explicitly needed
function generateEmergencySirenBlob(): Blob {
  const sampleRate = 22050;
  const durationSec = 2.0;
  const numSamples = Math.floor(sampleRate * durationSec);
  const buffer = new ArrayBuffer(44 + numSamples * 2);
  const view = new DataView(buffer);

  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + numSamples * 2, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(view, 36, 'data');
  view.setUint32(40, numSamples * 2, true);

  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    const cycle = (t * 3.0) % 1;
    let sample = 0;
    if (cycle < 0.6) {
      const f = cycle < 0.3 ? 987.77 : 1318.51;
      const w1 = Math.sin(2 * Math.PI * f * t);
      const w2 = Math.sin(2 * Math.PI * f * 2 * t) * 0.3;
      const env = Math.sin((cycle / 0.6) * Math.PI);
      sample = (w1 + w2) * env * 0.9;
    }
    sample = Math.max(-1, Math.min(1, sample));
    const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
    view.setInt16(offset, intSample, true);
    offset += 2;
  }
  return new Blob([buffer], { type: 'audio/wav' });
}

interface ActiveAlarmChannel {
  channelId: string;
  tone: string;
  title: string;
  volume: number;
  intervalId: number | null;
  audioElement: HTMLAudioElement | null;
  gainNode?: GainNode | null;
  startTime: number;
}

const activeChannels = new Map<string, ActiveAlarmChannel>();
let activeVibrationIntervalId: number | null = null;
let previewTimeoutId: number | null = null;
let previewIntervalId: number | null = null;
let previewGainNode: GainNode | null = null;
let currentPreviewTone: string | null = null;
let currentPreviewAudioEl: HTMLAudioElement | null = null;

// ================= Procedural Nature & Instrument Sound Engines =================

// 1. Gentle Dawn Birdsong: realistic melodic chirps & sweet sweeps
function synthesizeBirdSong(ctx: AudioContext, time: number, gainNode: GainNode) {
  const birds = [
    { start: 0, f1: 2200, f2: 3400, f3: 2600, duration: 0.12 },
    { start: 0.14, f1: 2600, f2: 3800, f3: 2900, duration: 0.14 },
    { start: 0.32, f1: 2400, f2: 3200, f3: 2200, duration: 0.10 },
  ];

  birds.forEach((b) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const t = time + b.start;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(b.f1, t);
    osc.frequency.linearRampToValueAtTime(b.f2, t + b.duration * 0.4);
    osc.frequency.exponentialRampToValueAtTime(b.f3, t + b.duration);

    g.gain.setValueAtTime(0.001, t);
    g.gain.linearRampToValueAtTime(0.35, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t + b.duration);

    osc.connect(g);
    g.connect(gainNode);

    osc.start(t);
    osc.stop(t + b.duration + 0.02);
  });
}

// 2. Forest Birds Melody: multi-tone melodic woodland warbler
function synthesizeForestBirds(ctx: AudioContext, time: number, gainNode: GainNode) {
  const notes = [1760, 2093, 2637, 3135, 2637];
  notes.forEach((freq, idx) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const t = time + idx * 0.11;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, t);
    osc.frequency.linearRampToValueAtTime(freq * 1.15, t + 0.04);
    osc.frequency.exponentialRampToValueAtTime(freq * 0.95, t + 0.12);

    g.gain.setValueAtTime(0.001, t);
    g.gain.linearRampToValueAtTime(0.3, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

    osc.connect(g);
    g.connect(gainNode);

    osc.start(t);
    osc.stop(t + 0.13);
  });
}

// 3. Flowing Water / Mountain Stream: filtered white/pink noise droplets & babbling stream
function synthesizeFlowingWater(ctx: AudioContext, time: number, gainNode: GainNode) {
  // Bubbling tone drops
  const bubbleFreqs = [420, 560, 680, 820, 510];
  bubbleFreqs.forEach((freq, idx) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const t = time + idx * 0.18;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq * 0.8, t);
    osc.frequency.exponentialRampToValueAtTime(freq * 1.5, t + 0.06);
    osc.frequency.exponentialRampToValueAtTime(freq, t + 0.16);

    g.gain.setValueAtTime(0.001, t);
    g.gain.linearRampToValueAtTime(0.25, t + 0.03);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.16);

    osc.connect(g);
    g.connect(gainNode);

    osc.start(t);
    osc.stop(t + 0.18);
  });
}

// 4. Soft Rain Shower: gentle rhythmic droplet cascade
function synthesizeSoftRain(ctx: AudioContext, time: number, gainNode: GainNode) {
  for (let i = 0; i < 7; i++) {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const t = time + i * 0.12;
    const f = 1200 + Math.random() * 800;

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(f, t);
    osc.frequency.exponentialRampToValueAtTime(f * 0.7, t + 0.08);

    g.gain.setValueAtTime(0.001, t);
    g.gain.linearRampToValueAtTime(0.18, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.08);

    osc.connect(g);
    g.connect(gainNode);

    osc.start(t);
    osc.stop(t + 0.09);
  }
}

// 5. Gentle Mountain Breeze: soft low-pass swell
function synthesizeGentleWind(ctx: AudioContext, time: number, gainNode: GainNode) {
  const osc1 = ctx.createOscillator();
  const osc2 = ctx.createOscillator();
  const g = ctx.createGain();

  osc1.type = 'sine';
  osc2.type = 'triangle';

  osc1.frequency.setValueAtTime(120, time);
  osc1.frequency.linearRampToValueAtTime(180, time + 0.8);
  osc1.frequency.linearRampToValueAtTime(110, time + 1.8);

  osc2.frequency.setValueAtTime(240, time);
  osc2.frequency.linearRampToValueAtTime(320, time + 0.8);
  osc2.frequency.linearRampToValueAtTime(200, time + 1.8);

  g.gain.setValueAtTime(0.001, time);
  g.gain.linearRampToValueAtTime(0.22, time + 0.6);
  g.gain.linearRampToValueAtTime(0.001, time + 1.9);

  osc1.connect(g);
  osc2.connect(g);
  g.connect(gainNode);

  osc1.start(time);
  osc2.start(time);
  osc1.stop(time + 2.0);
  osc2.stop(time + 2.0);
}

// 6. Zen Bell: 528Hz Solfeggio pure acoustic bell
function synthesizeZenBell(ctx: AudioContext, time: number, gainNode: GainNode) {
  const freqs = [528, 1056, 1584];
  freqs.forEach((freq, idx) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = idx === 0 ? 'sine' : 'triangle';
    osc.frequency.setValueAtTime(freq, time);

    const amp = 0.45 / (idx + 1);
    g.gain.setValueAtTime(0.001, time);
    g.gain.linearRampToValueAtTime(amp, time + 0.03);
    g.gain.exponentialRampToValueAtTime(0.0005, time + 1.6);

    osc.connect(g);
    g.connect(gainNode);

    osc.start(time);
    osc.stop(time + 1.65);
  });
}

// 7. Soft Chime: clean double harmonic chime
function synthesizeSoftChime(ctx: AudioContext, time: number, gainNode: GainNode) {
  [
    { f: 659.25, offset: 0 },
    { f: 880, offset: 0.16 },
  ].forEach((n) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const t = time + n.offset;
    osc.type = 'sine';
    osc.frequency.setValueAtTime(n.f, t);

    g.gain.setValueAtTime(0.001, t);
    g.gain.linearRampToValueAtTime(0.35, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.8);

    osc.connect(g);
    g.connect(gainNode);

    osc.start(t);
    osc.stop(t + 0.85);
  });
}

// 8. Spiritual Adhan Chime: modal prayer bells
function synthesizeSpiritualChime(ctx: AudioContext, time: number, gainNode: GainNode) {
  const notes = [440, 554.37, 659.25, 880];
  notes.forEach((freq, idx) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const t = time + idx * 0.15;
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, t);

    g.gain.setValueAtTime(0.001, t);
    g.gain.linearRampToValueAtTime(0.35, t + 0.03);
    g.gain.exponentialRampToValueAtTime(0.001, t + 1.1);

    osc.connect(g);
    g.connect(gainNode);

    osc.start(t);
    osc.stop(t + 1.15);
  });
}

// 9. Classic Digital Beep: double beep cadence
function synthesizeClassicBeep(ctx: AudioContext, time: number, gainNode: GainNode) {
  [0, 0.14].forEach((offset) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const t = time + offset;
    osc.type = 'square';
    osc.frequency.setValueAtTime(987.77, t);

    g.gain.setValueAtTime(0.001, t);
    g.gain.linearRampToValueAtTime(0.35, t + 0.01);
    g.gain.setValueAtTime(0.35, t + 0.08);
    g.gain.linearRampToValueAtTime(0.001, t + 0.1);

    osc.connect(g);
    g.connect(gainNode);

    osc.start(t);
    osc.stop(t + 0.11);
  });
}

// 10. Emergency Siren: Web Audio synthesis ONLY for emergency_siren
function synthesizeEmergencySiren(ctx: AudioContext, time: number, gainNode: GainNode) {
  const osc1 = ctx.createOscillator();
  const osc2 = ctx.createOscillator();
  const g = ctx.createGain();

  osc1.type = 'sawtooth';
  osc2.type = 'sine';

  osc1.frequency.setValueAtTime(900, time);
  osc1.frequency.linearRampToValueAtTime(1400, time + 0.2);
  osc1.frequency.linearRampToValueAtTime(900, time + 0.4);

  osc2.frequency.setValueAtTime(1800, time);
  osc2.frequency.linearRampToValueAtTime(2800, time + 0.2);
  osc2.frequency.linearRampToValueAtTime(1800, time + 0.4);

  g.gain.setValueAtTime(0.01, time);
  g.gain.linearRampToValueAtTime(0.8, time + 0.04);
  g.gain.exponentialRampToValueAtTime(0.01, time + 0.45);

  osc1.connect(g);
  osc2.connect(g);
  g.connect(gainNode);

  osc1.start(time);
  osc2.start(time);
  osc1.stop(time + 0.48);
  osc2.stop(time + 0.48);
}

// Router to synthesize any tone safely onto its own gain node
function dispatchToneSynthesis(ctx: AudioContext, time: number, tone: string, gainNode: GainNode) {
  switch (tone) {
    case 'morning_birds':
      synthesizeBirdSong(ctx, time, gainNode);
      break;
    case 'forest_birds':
      synthesizeForestBirds(ctx, time, gainNode);
      break;
    case 'flowing_water':
      synthesizeFlowingWater(ctx, time, gainNode);
      break;
    case 'soft_rain':
      synthesizeSoftRain(ctx, time, gainNode);
      break;
    case 'gentle_wind':
      synthesizeGentleWind(ctx, time, gainNode);
      break;
    case 'zen_bell':
    case 'zen_harmony':
      synthesizeZenBell(ctx, time, gainNode);
      break;
    case 'soft_chime':
      synthesizeSoftChime(ctx, time, gainNode);
      break;
    case 'adhan_spiritual':
      synthesizeSpiritualChime(ctx, time, gainNode);
      break;
    case 'classic_beep':
      synthesizeClassicBeep(ctx, time, gainNode);
      break;
    case 'emergency_siren':
      synthesizeEmergencySiren(ctx, time, gainNode);
      break;
    default:
      synthesizeBirdSong(ctx, time, gainNode);
      break;
  }
}

// ================= Task Completion Sounds (Delightful & Non-Jarring) =================

export type CompletionToneType = 'subtle_chime' | 'soft_bell' | 'positive_tone';

export function isCompletionSoundEnabled(): boolean {
  if (typeof window === 'undefined') return true;
  const val = localStorage.getItem(STORAGE_KEYS.COMPLETION_SOUND_ENABLED);
  return val === null ? true : val === 'true';
}

export function setCompletionSoundEnabled(enabled: boolean): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.COMPLETION_SOUND_ENABLED, String(enabled));
}

export function getCompletionSoundTone(): CompletionToneType {
  if (typeof window === 'undefined') return 'subtle_chime';
  return (localStorage.getItem(STORAGE_KEYS.COMPLETION_SOUND_TONE) as CompletionToneType) || 'subtle_chime';
}

export function setCompletionSoundTone(tone: CompletionToneType): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.COMPLETION_SOUND_TONE, tone);
}

export function playTaskCompletionSound(forceTone?: CompletionToneType): void {
  if (!isCompletionSoundEnabled() && !forceTone) return;

  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const tone = forceTone || getCompletionSoundTone();

    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.4, now);
    masterGain.connect(ctx.destination);

    if (tone === 'soft_bell') {
      // Pleasant single meditation ding
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, now);
      g.gain.setValueAtTime(0.001, now);
      g.gain.linearRampToValueAtTime(0.4, now + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.7);

      osc.connect(g);
      g.connect(masterGain);
      osc.start(now);
      osc.stop(now + 0.75);
    } else if (tone === 'positive_tone') {
      // Upward arpeggio C5 -> E5 -> G5 -> C6
      const chord = [523.25, 659.25, 783.99, 1046.5];
      chord.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        const t = now + i * 0.08;
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t);

        g.gain.setValueAtTime(0.001, t);
        g.gain.linearRampToValueAtTime(0.3, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.4);

        osc.connect(g);
        g.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.45);
      });
    } else {
      // subtle_chime (default): gentle 2-note chime G5 -> C6
      const notes = [783.99, 1046.5];
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        const t = now + i * 0.12;
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t);

        g.gain.setValueAtTime(0.001, t);
        g.gain.linearRampToValueAtTime(0.35, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.5);

        osc.connect(g);
        g.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.55);
      });
    }

    // Light subtle haptic confirmation
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(35);
      } catch {
        // ignore
      }
    }
  } catch (e) {
    console.warn('Completion sound error:', e);
  }
}

// ================= Independent Alarm Channel Management =================

export interface StartAlarmOptions {
  channelId?: string;
  title?: string;
  tone?: string;
  toneId?: string;
  volume?: number;
  onSnooze?: () => void;
  onDismiss?: () => void;
}

export function startAlarmSound(
  title?: string,
  onSnooze?: () => void,
  onDismiss?: () => void,
  toneKey?: string,
  channelId: string = 'default'
) {
  startAlarmChannel({
    channelId,
    title,
    tone: toneKey,
    onSnooze,
    onDismiss,
  });
}

export function startAlarmChannel(options: StartAlarmOptions): void {
  const channelId = options.channelId || 'default';
  const tone = options.tone || options.toneId || getSelectedTone();
  const title = options.title || 'Habivio Alarm';
  const volume = options.volume ?? getAlarmVolume();

  // If already ringing on this exact channel, do not restart
  if (activeChannels.has(channelId)) {
    return;
  }

  // Stop preview if running
  stopRingtonePreview();

  // Request WakeLock & Background Keep-Alive
  requestScreenWakeLock();
  startBackgroundAudioKeepAlive();

  // Setup MediaSession
  setupMediaSession(title, options.onSnooze, options.onDismiss);

  // If Silent mode chosen: NO AUDIO AT ALL, only vibration
  if (tone === 'silent') {
    activeChannels.set(channelId, {
      channelId,
      tone,
      title,
      volume: 0,
      intervalId: null,
      audioElement: null,
      startTime: Date.now(),
    });
    startContinuousVibration();
    return;
  }

  // If Custom Audio uploaded
  if (tone === 'custom_audio') {
    const customData = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.CUSTOM_AUDIO) : null;
    if (customData) {
      try {
        const audio = new Audio(customData);
        audio.loop = true;
        audio.volume = volume;
        audio.play().catch((err) => console.warn('Custom audio playback:', err));

        activeChannels.set(channelId, {
          channelId,
          tone,
          title,
          volume,
          intervalId: null,
          audioElement: audio,
          startTime: Date.now(),
        });
        startContinuousVibration();
        return;
      } catch (e) {
        console.warn('Custom audio load error:', e);
      }
    }
  }

  // If Emergency Siren is selected: create separate audio element solely for siren
  let sirenAudio: HTMLAudioElement | null = null;
  if (tone === 'emergency_siren') {
    try {
      const blob = generateEmergencySirenBlob();
      const url = URL.createObjectURL(blob);
      sirenAudio = new Audio(url);
      sirenAudio.loop = true;
      sirenAudio.volume = volume;
      sirenAudio.play().catch(() => {});
    } catch {
      // fallback to Web Audio
    }
  }

  // Web Audio Synthesizer for tone
  try {
    const ctx = getAudioContext();
    const channelGain = ctx.createGain();
    channelGain.gain.setValueAtTime(volume, ctx.currentTime);
    channelGain.connect(ctx.destination);

    const intervalMs =
      tone === 'morning_birds'
        ? 900
        : tone === 'forest_birds'
        ? 1100
        : tone === 'flowing_water'
        ? 1400
        : tone === 'soft_rain'
        ? 1000
        : tone === 'zen_bell' || tone === 'zen_harmony'
        ? 1700
        : 1200;

    const playCycle = () => {
      if (!activeChannels.has(channelId)) return;
      const now = ctx.currentTime;
      dispatchToneSynthesis(ctx, now, tone, channelGain);
    };

    playCycle();
    const intervalId = window.setInterval(playCycle, intervalMs);

    activeChannels.set(channelId, {
      channelId,
      tone,
      title,
      volume,
      intervalId,
      audioElement: sirenAudio,
      gainNode: channelGain,
      startTime: Date.now(),
    });

    startContinuousVibration();
  } catch (err) {
    console.warn('Alarm audio error:', err);
  }
}

// Stop a specific alarm channel without stopping other alarms
export function stopAlarmChannel(channelId: string): void {
  const channel = activeChannels.get(channelId);
  if (!channel) return;

  if (channel.intervalId !== null) {
    clearInterval(channel.intervalId);
    channel.intervalId = null;
  }

  if (channel.gainNode) {
    try {
      channel.gainNode.gain.cancelScheduledValues(0);
      channel.gainNode.gain.setValueAtTime(0, 0);
      channel.gainNode.disconnect();
    } catch {
      // ignore
    }
  }

  if (channel.audioElement) {
    try {
      channel.audioElement.pause();
      channel.audioElement.currentTime = 0;
      channel.audioElement.src = '';
    } catch {
      // ignore
    }
    channel.audioElement = null;
  }

  activeChannels.delete(channelId);

  // If no other channels are ringing, release wake lock & stop vibration
  if (activeChannels.size === 0) {
    stopContinuousVibration();
    releaseScreenWakeLock();
  }
}

// Global stop alarm for compatibility
export function stopAlarmSound(channelId?: string): void {
  if (channelId && channelId !== 'default') {
    stopAlarmChannel(channelId);
    return;
  }
  // Stop all channels
  stopAllAlarms();
}

export function stopAllAlarms(): void {
  // Always stop active ringtone previews as well
  stopRingtonePreview();

  activeChannels.forEach((channel) => {
    if (channel.intervalId !== null) {
      clearInterval(channel.intervalId);
      channel.intervalId = null;
    }
    if (channel.gainNode) {
      try {
        channel.gainNode.gain.cancelScheduledValues(0);
        channel.gainNode.gain.setValueAtTime(0, 0);
        channel.gainNode.disconnect();
      } catch {
        // ignore
      }
    }
    if (channel.audioElement) {
      try {
        channel.audioElement.pause();
        channel.audioElement.currentTime = 0;
        channel.audioElement.src = '';
      } catch {
        // ignore
      }
    }
  });

  activeChannels.clear();
  stopContinuousVibration();
  releaseScreenWakeLock();
}

export function isAlarmPlaying(channelId?: string): boolean {
  if (channelId) {
    return activeChannels.has(channelId);
  }
  return activeChannels.size > 0;
}

// Continuous vibration
function startContinuousVibration() {
  if (activeVibrationIntervalId !== null) return;
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    const vibrate = () => {
      try {
        navigator.vibrate([1000, 400, 1000, 400, 1500]);
      } catch {
        // ignore
      }
    };
    vibrate();
    activeVibrationIntervalId = window.setInterval(vibrate, 3300);
  }
}

function stopContinuousVibration() {
  if (activeVibrationIntervalId !== null) {
    clearInterval(activeVibrationIntervalId);
    activeVibrationIntervalId = null;
  }
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(0);
    } catch {
      // ignore
    }
  }
}

// ================= Ringtone Audition & Preview =================

export function previewRingtone(toneId?: string, volume: number = 0.8): void {
  // Always stop and teardown any existing ringtone preview first
  stopRingtonePreview();

  const tone = toneId || getSelectedTone();
  currentPreviewTone = tone;

  if (tone === 'silent') {
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate([120, 80, 120]);
      } catch {
        // ignore
      }
    }
    previewTimeoutId = window.setTimeout(stopRingtonePreview, 1200);
    return;
  }

  if (tone === 'custom_audio') {
    const customData = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.CUSTOM_AUDIO) : null;
    if (customData) {
      try {
        const audio = new Audio(customData);
        audio.volume = volume;
        currentPreviewAudioEl = audio;
        audio.play().catch(() => {});
        previewTimeoutId = window.setTimeout(stopRingtonePreview, 7000);
        return;
      } catch {
        // ignore
      }
    }
  }

  try {
    const ctx = getAudioContext();
    const previewGain = ctx.createGain();
    previewGain.gain.setValueAtTime(volume, ctx.currentTime);
    previewGain.connect(ctx.destination);
    previewGainNode = previewGain;

    const intervalMs =
      tone === 'morning_birds'
        ? 850
        : tone === 'forest_birds'
        ? 1000
        : tone === 'flowing_water'
        ? 1300
        : tone === 'soft_rain'
        ? 950
        : tone === 'zen_bell' || tone === 'zen_harmony'
        ? 1500
        : 1100;

    const play = () => {
      // Guard strictly against playback if preview was stopped or switched
      if (currentPreviewTone !== tone) return;
      dispatchToneSynthesis(ctx, ctx.currentTime, tone, previewGain);
    };

    play();
    previewIntervalId = window.setInterval(play, intervalMs);

    previewTimeoutId = window.setTimeout(() => {
      stopRingtonePreview();
    }, 6000);
  } catch (e) {
    console.warn('Preview error:', e);
  }
}

export function stopRingtonePreview(): void {
  currentPreviewTone = null;

  if (previewTimeoutId !== null) {
    clearTimeout(previewTimeoutId);
    previewTimeoutId = null;
  }

  if (previewIntervalId !== null) {
    clearInterval(previewIntervalId);
    previewIntervalId = null;
  }

  if (previewGainNode) {
    try {
      previewGainNode.gain.cancelScheduledValues(0);
      previewGainNode.gain.setValueAtTime(0, 0);
      previewGainNode.disconnect();
    } catch {
      // ignore
    }
    previewGainNode = null;
  }

  if (currentPreviewAudioEl) {
    try {
      currentPreviewAudioEl.pause();
      currentPreviewAudioEl.currentTime = 0;
      currentPreviewAudioEl.src = '';
    } catch {
      // ignore
    }
    currentPreviewAudioEl = null;
  }

  if (typeof window !== 'undefined') {
    if ('vibrate' in navigator) {
      try {
        navigator.vibrate(0);
      } catch {
        // ignore
      }
    }
    window.dispatchEvent(new CustomEvent('habivio:preview-stopped'));
  }
}

export function isRingtonePreviewing(toneId?: string): boolean {
  if (toneId) {
    return currentPreviewTone === toneId;
  }
  return currentPreviewTone !== null;
}

// MediaSession setup
function setupMediaSession(title?: string, onSnooze?: () => void, onDismiss?: () => void) {
  if (typeof navigator !== 'undefined' && 'mediaSession' in navigator) {
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: title ? `🔔 ${title}` : '🔔 Habivio Alarm',
        artist: 'Habivio Personal AI Assistant',
        album: 'Tap Pause/Stop to dismiss alarm',
        artwork: [
          { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png' },
          { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png' },
        ],
      });
      navigator.mediaSession.playbackState = 'playing';

      const handleDismiss = () => {
        stopAllAlarms();
        if (onDismiss) onDismiss();
      };

      const handleSnooze = () => {
        stopAllAlarms();
        if (onSnooze) onSnooze();
      };

      navigator.mediaSession.setActionHandler('pause', handleDismiss);
      navigator.mediaSession.setActionHandler('stop', handleDismiss);
      navigator.mediaSession.setActionHandler('nexttrack', handleSnooze);
      navigator.mediaSession.setActionHandler('previoustrack', handleSnooze);
    } catch {
      // ignore
    }
  }
}

// Audio Priming
export function primeAudioForBackground(): void {
  try {
    getAudioContext();
    startBackgroundAudioKeepAlive();
  } catch {
    // ignore
  }
}

// User Settings Persistence
export function getSelectedTone(): string {
  if (typeof window === 'undefined') return 'morning_birds';
  return localStorage.getItem(STORAGE_KEYS.SELECTED_TONE) || 'morning_birds';
}

export function setSelectedTone(toneId: string): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.SELECTED_TONE, toneId);
}

export function getAlarmVolume(): number {
  if (typeof window === 'undefined') return 1.0;
  const val = localStorage.getItem(STORAGE_KEYS.ALARM_VOLUME);
  return val ? parseFloat(val) : 1.0;
}

export function setAlarmVolume(volume: number): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.ALARM_VOLUME, String(Math.max(0.1, Math.min(1.0, volume))));
}

export function getCustomAudioInfo(): { name: string; hasAudio: boolean } {
  if (typeof window === 'undefined') return { name: '', hasAudio: false };
  const data = localStorage.getItem(STORAGE_KEYS.CUSTOM_AUDIO);
  const name = localStorage.getItem(STORAGE_KEYS.CUSTOM_NAME) || 'Custom Tone';
  return { name, hasAudio: Boolean(data) };
}

export function setCustomAudioData(dataUrl: string, fileName: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.CUSTOM_AUDIO, dataUrl);
    localStorage.setItem(STORAGE_KEYS.CUSTOM_NAME, fileName);
    localStorage.setItem(STORAGE_KEYS.SELECTED_TONE, 'custom_audio');
  } catch (e) {
    console.warn('Could not store custom audio:', e);
  }
}

export type CompletionSoundStyle = CompletionToneType;

export function isAlarmChannelActive(channelId?: string): boolean {
  return isAlarmPlaying(channelId);
}

export function getCompletionSoundSetting(): {
  enabled: boolean;
  style: CompletionToneType;
  volume: number;
} {
  return {
    enabled: isCompletionSoundEnabled(),
    style: getCompletionSoundTone(),
    volume: 0.8,
  };
}

export function setCompletionSoundSetting(
  enabled: boolean,
  style?: CompletionToneType,
  _volume?: number
): void {
  setCompletionSoundEnabled(enabled);
  if (style) {
    setCompletionSoundTone(style);
  }
}

