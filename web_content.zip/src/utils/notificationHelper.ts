import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase.ts';
import { NotificationItem } from '../types/index.ts';
import { removeUndefinedFields } from './firestoreHelper.ts';

export interface SendNotificationParams {
  orgId: string;
  userId: string;
  targetRole?: NotificationItem['targetRole'];
  title: string;
  message: string;
  type: NotificationItem['type'];
  linkTab?: string;
}

/**
 * Creates an in-app notification record in Firestore scoped by orgId and recipient userId / targetRole.
 */
export async function sendNotification({
  orgId,
  userId,
  targetRole,
  title,
  message,
  type,
  linkTab,
}: SendNotificationParams): Promise<NotificationItem | null> {
  if (!orgId || (!userId && !targetRole)) return null;
  try {
    const notifId = `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const notif: NotificationItem = {
      id: notifId,
      orgId,
      userId: userId || 'role_broadcast',
      targetRole,
      title,
      message,
      type,
      read: false,
      linkTab,
      createdAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'notifications', notifId), removeUndefinedFields(notif));
    return notif;
  } catch (e) {
    console.error('Error sending notification:', e);
    return null;
  }
}
