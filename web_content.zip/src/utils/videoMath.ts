export interface VideoSegment {
  index: number;
  startTime: number;
  endTime: number;
  duration: number;
  title: string;
}

export type SplitMode = 'duration' | 'count' | 'custom';

/**
 * Calculates exact video segments based on duration or parts count.
 * Handles remainder clips smoothly as required (e.g., 3m 25s with 50s splits).
 */
export function calculateVideoSegments(
  totalDuration: number,
  mode: SplitMode,
  value: number
): VideoSegment[] {
  if (totalDuration <= 0) return [];

  const segments: VideoSegment[] = [];

  if (mode === 'duration') {
    const chunkSeconds = Math.max(1, Math.round(value));
    if (chunkSeconds <= 0) return [];

    let currentStart = 0;
    let clipIndex = 1;

    while (currentStart < totalDuration) {
      const currentEnd = Math.min(totalDuration, currentStart + chunkSeconds);
      const clipDuration = Math.round((currentEnd - currentStart) * 100) / 100;

      // Only add if duration is positive
      if (clipDuration > 0.05) {
        segments.push({
          index: clipIndex,
          startTime: Math.round(currentStart * 100) / 100,
          endTime: Math.round(currentEnd * 100) / 100,
          duration: clipDuration,
          title: `المقطع ${clipIndex} (${formatTime(currentStart)} - ${formatTime(currentEnd)})`
        });
      }

      currentStart = currentEnd;
      clipIndex++;
    }
  } else if (mode === 'count') {
    const partsCount = Math.max(1, Math.min(50, Math.round(value)));
    const partDuration = totalDuration / partsCount;

    for (let i = 0; i < partsCount; i++) {
      const startTime = Math.round((i * partDuration) * 100) / 100;
      const endTime = i === partsCount - 1 ? totalDuration : Math.round(((i + 1) * partDuration) * 100) / 100;
      const clipDuration = Math.round((endTime - startTime) * 100) / 100;

      segments.push({
        index: i + 1,
        startTime,
        endTime,
        duration: clipDuration,
        title: `الجزء ${i + 1}/${partsCount} (${formatTime(startTime)} - ${formatTime(endTime)})`
      });
    }
  }

  return segments;
}

/**
 * Format seconds to MM:SS or HH:MM:SS
 */
export function formatTime(seconds: number): string {
  if (isNaN(seconds) || !isFinite(seconds) || seconds <= 0) return '00:00';
  const totalSecs = Math.floor(seconds);
  const hrs = Math.floor(totalSecs / 3600);
  const mins = Math.floor((totalSecs % 3600) / 60);
  const secs = totalSecs % 60;

  const pad = (n: number) => n.toString().padStart(2, '0');

  if (hrs > 0) {
    return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
  }
  return `${pad(mins)}:${pad(secs)}`;
}

/**
 * Estimate video file size in Megabytes based on duration, resolution and quality
 */
export function estimateFileSizeMB(
  durationSeconds: number,
  resolution: '480p' | '720p' | '1080p',
  quality: 'low' | 'medium' | 'high'
): number {
  // Approximate bitrates in kbps
  const bitrateMap: Record<string, Record<string, number>> = {
    '480p': { low: 800, medium: 1200, high: 2000 },
    '720p': { low: 1800, medium: 2800, high: 4500 },
    '1080p': { low: 3500, medium: 5500, high: 8000 }
  };

  const kbps = bitrateMap[resolution]?.[quality] || 2500;
  // bytes = (kbps * 1000 / 8) * duration
  const totalBytes = (kbps * 1000 / 8) * durationSeconds;
  return Math.round((totalBytes / (1024 * 1024)) * 10) / 10;
}
