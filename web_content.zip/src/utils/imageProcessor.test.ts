import test from 'node:test';
import assert from 'node:assert/strict';
import { hexToRgb, COMMON_COLOR_PRESETS } from './imageProcessor';

test('hexToRgb parses standard hex colors correctly', () => {
  const white = hexToRgb('#FFFFFF');
  assert.deepEqual(white, { r: 255, g: 255, b: 255 });

  const black = hexToRgb('#000000');
  assert.deepEqual(black, { r: 0, g: 0, b: 0 });

  const blue = hexToRgb('#1E40AF');
  assert.deepEqual(blue, { r: 30, g: 64, b: 175 });

  const shortHex = hexToRgb('#FFF');
  assert.deepEqual(shortHex, { r: 255, g: 255, b: 255 });

  const transparent = hexToRgb('transparent');
  assert.equal(transparent, null);
});

test('COMMON_COLOR_PRESETS contains transparent, white, black, red, and blue presets', () => {
  const hexValues = COMMON_COLOR_PRESETS.map(p => p.hex);
  assert.ok(hexValues.includes('transparent'));
  assert.ok(hexValues.includes('#FFFFFF'));
  assert.ok(hexValues.includes('#000000'));
  assert.ok(hexValues.includes('#DC2626'));
  assert.ok(hexValues.includes('#1E40AF'));
});
