// Lightweight Avro-style Bangla phonetic transliterator for users typing without an OS Bangla IME.

const VOWELS: Record<string, string> = {
  o: 'অ',
  a: 'আ',
  i: 'ই',
  I: 'ঈ',
  ee: 'ঈ',
  u: 'উ',
  U: 'ঊ',
  oo: 'ঊ',
  rri: 'ঋ',
  e: 'এ',
  oi: 'ঐ',
  O: 'ও',
  ou: 'ঔ',
};

const KAR: Record<string, string> = {
  o: '',
  a: 'া',
  i: 'ি',
  I: 'ী',
  ee: 'ী',
  u: 'ু',
  U: 'ূ',
  oo: 'ূ',
  rri: 'ৃ',
  e: 'ে',
  oi: 'ৈ',
  O: 'ো',
  ou: 'ৌ',
};

const CONSONANTS: Record<string, string> = {
  k: 'ক',
  kh: 'খ',
  g: 'গ',
  gh: 'ঘ',
  Ng: 'ঙ',
  c: 'চ',
  ch: 'ছ',
  j: 'জ',
  jh: 'ঝ',
  NG: 'ঞ',
  T: 'ট',
  Th: 'ঠ',
  D: 'ড',
  Dh: 'ঢ',
  N: 'ণ',
  t: 'ত',
  th: 'থ',
  d: 'দ',
  dh: 'ধ',
  n: 'ন',
  p: 'প',
  ph: 'ফ',
  f: 'ফ',
  b: 'ব',
  bh: 'ভ',
  v: 'ভ',
  m: 'ম',
  z: 'য',
  r: 'র',
  l: 'ল',
  sh: 'শ',
  S: 'ষ',
  Sh: 'ষ',
  s: 'স',
  h: 'হ',
  R: 'ড়',
  Rh: 'ঢ়',
  y: 'য়',
  Y: 'য়',
  't``': 'ৎ',
  ng: 'ং',
  ':': 'ঃ',
  '^': 'ঁ',
  kSh: 'ক্ষ',
  kkh: 'ক্ষ',
  jNG: 'জ্ঞ',
};

const DIGITS: Record<string, string> = {
  '0': '০',
  '1': '১',
  '2': '২',
  '3': '৩',
  '4': '৪',
  '5': '৫',
  '6': '৬',
  '7': '৭',
  '8': '৮',
  '9': '৯',
};

const CONSONANT_KEYS = Object.keys(CONSONANTS).sort((a, b) => b.length - a.length);
const VOWEL_KEYS = Object.keys(VOWELS).sort((a, b) => b.length - a.length);

export function transliteratePhoneticBangla(input: string): string {
  let out = '';
  let i = 0;
  let lastWasConsonant = false;

  while (i < input.length) {
    const rest = input.slice(i);

    if (rest.startsWith('.')) {
      out += '।';
      i += 1;
      lastWasConsonant = false;
      continue;
    }

    if (DIGITS[input[i]]) {
      out += DIGITS[input[i]];
      i += 1;
      lastWasConsonant = false;
      continue;
    }

    // Explicit hasant using '`' or double consonant joiner
    if (input[i] === '`') {
      i += 1;
      continue;
    }

    const matchedCons = CONSONANT_KEYS.find((k) => rest.startsWith(k));
    if (matchedCons) {
      if (lastWasConsonant && matchedCons !== 'ng' && matchedCons !== '^' && matchedCons !== ':') {
        // Handle ya-phala (y) or ra-phala (r) or normal conjunct? Keep explicit or natural:
        // If user types 'bangla' -> 'n'+'g' matched 'ng', 'l' follows 'ng' (not consonant cluster)
        // If user types 'kotha', 'k' then 'o' (vowel), 'th' then 'a' (vowel).
        // If user types 'pr' -> প্‌র -> প্র!
        out += '্';
      }
      out += CONSONANTS[matchedCons];
      i += matchedCons.length;
      lastWasConsonant = matchedCons !== 'ng' && matchedCons !== '^' && matchedCons !== ':';
      continue;
    }

    const matchedVowel = VOWEL_KEYS.find((k) => rest.startsWith(k));
    if (matchedVowel) {
      if (lastWasConsonant) {
        out += KAR[matchedVowel] ?? '';
      } else {
        out += VOWELS[matchedVowel];
      }
      i += matchedVowel.length;
      lastWasConsonant = false;
      continue;
    }

    out += input[i];
    i += 1;
    lastWasConsonant = false;
  }

  return out;
}
