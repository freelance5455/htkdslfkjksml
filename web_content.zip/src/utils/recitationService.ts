// Audio Recitation & Tajweed Voice Service for Hisn Al-Muslim
import { DhikrItem, ReciterId } from '../types';

export interface ReciterInfo {
  id: ReciterId;
  name: string;
  title: string;
  description: string;
  badge: string;
}

export const RECITERS_LIST: ReciterInfo[] = [
  {
    id: 'alafasy',
    name: 'مشاري راشد العفاسي',
    title: 'الشيخ مشاري العفاسي',
    description: 'تلاوة ندية خاشعة ومتقنة ومعروفة لأذكار الصباح والمساء',
    badge: 'مستحسن ⭐',
  },
  {
    id: 'ghamdi',
    name: 'سعد الغامدي',
    title: 'الشيخ سعد الغامدي',
    description: 'صوت هادئ رخيم يبعث الطمأنينة والسكينة في القلب',
    badge: 'هادئ 🌿',
  },
  {
    id: 'muaiqly',
    name: 'ماهر المعيقلي',
    title: 'الشيخ ماهر المعيقلي',
    description: 'إمام المسجد الحرام بترتيل رصين وأسلوب مميز',
    badge: 'الحرم 🕋',
  },
  {
    id: 'abdulbasit',
    name: 'عبد الباسط عبد الصمد',
    title: 'الشيخ عبد الباسط عبد الصمد',
    description: 'المدرسة الكلاسيكية العريقة والتجويد القرآني الخالد',
    badge: 'تجويد 📖',
  },
];

// Reciter-specific audio stream mappings for Quranic Adhkar
const RECITER_AUDIO_MAP: Record<ReciterId, Record<string, string>> = {
  alafasy: {
    'morning-1': 'https://everyayah.com/data/Alafasy_128kbps/002255.mp3',
    'evening-1': 'https://everyayah.com/data/Alafasy_128kbps/002255.mp3',
    'morning-2': 'https://server8.mp3quran.net/afs/112.mp3',
    'evening-2': 'https://server8.mp3quran.net/afs/112.mp3',
    'morning-3': 'https://server8.mp3quran.net/afs/113.mp3',
    'evening-3': 'https://server8.mp3quran.net/afs/113.mp3',
    'morning-4': 'https://server8.mp3quran.net/afs/114.mp3',
    'evening-4': 'https://server8.mp3quran.net/afs/114.mp3',
  },
  ghamdi: {
    'morning-1': 'https://everyayah.com/data/Ghamadi_40kbps/002255.mp3',
    'evening-1': 'https://everyayah.com/data/Ghamadi_40kbps/002255.mp3',
    'morning-2': 'https://server7.mp3quran.net/s_gmd/112.mp3',
    'evening-2': 'https://server7.mp3quran.net/s_gmd/112.mp3',
    'morning-3': 'https://server7.mp3quran.net/s_gmd/113.mp3',
    'evening-3': 'https://server7.mp3quran.net/s_gmd/113.mp3',
    'morning-4': 'https://server7.mp3quran.net/s_gmd/114.mp3',
    'evening-4': 'https://server7.mp3quran.net/s_gmd/114.mp3',
  },
  muaiqly: {
    'morning-1': 'https://everyayah.com/data/MaherAlMuaiqly128kbps/002255.mp3',
    'evening-1': 'https://everyayah.com/data/MaherAlMuaiqly128kbps/002255.mp3',
    'morning-2': 'https://server12.mp3quran.net/maher/112.mp3',
    'evening-2': 'https://server12.mp3quran.net/maher/112.mp3',
    'morning-3': 'https://server12.mp3quran.net/maher/113.mp3',
    'evening-3': 'https://server12.mp3quran.net/maher/113.mp3',
    'morning-4': 'https://server12.mp3quran.net/maher/114.mp3',
    'evening-4': 'https://server12.mp3quran.net/maher/114.mp3',
  },
  abdulbasit: {
    'morning-1': 'https://everyayah.com/data/Abdul_Basit_Murattal_192kbps/002255.mp3',
    'evening-1': 'https://everyayah.com/data/Abdul_Basit_Murattal_192kbps/002255.mp3',
    'morning-2': 'https://server7.mp3quran.net/basit/112.mp3',
    'evening-2': 'https://server7.mp3quran.net/basit/112.mp3',
    'morning-3': 'https://server7.mp3quran.net/basit/113.mp3',
    'evening-3': 'https://server7.mp3quran.net/basit/113.mp3',
    'morning-4': 'https://server7.mp3quran.net/basit/114.mp3',
    'evening-4': 'https://server7.mp3quran.net/basit/114.mp3',
  },
};

class RecitationEngine {
  private audioElement: HTMLAudioElement | null = null;
  private isAudioPlaying: boolean = false;
  private isSpeechPlaying: boolean = false;
  private speechUtterance: SpeechSynthesisUtterance | null = null;
  private currentProgress: number = 0;
  private currentTime: number = 0;
  private duration: number = 0;
  private playbackSpeed: number = 0.85; // Default slow and clear for Tajweed
  private repeatCount: number = 1;
  private currentRepetition: number = 1;
  private currentReciterId: ReciterId = 'alafasy';
  private currentDhikrItem: DhikrItem | null = null;
  private onStateChangeCallback: (() => void) | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.audioElement = new Audio();
      this.audioElement.preload = 'metadata';

      this.audioElement.onloadedmetadata = () => {
        if (this.audioElement) {
          this.duration = this.audioElement.duration || 0;
          this.notifyState();
        }
      };

      this.audioElement.onended = () => {
        if (this.currentRepetition < this.repeatCount) {
          this.currentRepetition += 1;
          if (this.audioElement) {
            this.audioElement.currentTime = 0;
            this.audioElement.play().catch(() => {});
          }
          this.notifyState();
        } else {
          this.isAudioPlaying = false;
          this.currentProgress = 1;
          this.notifyState();
        }
      };

      this.audioElement.ontimeupdate = () => {
        if (this.audioElement && this.audioElement.duration > 0) {
          this.currentTime = this.audioElement.currentTime;
          this.duration = this.audioElement.duration;
          this.currentProgress = this.audioElement.currentTime / this.audioElement.duration;
          this.notifyState();
        }
      };

      this.audioElement.onerror = () => {
        // Fallback to speech synthesis if audio stream is unavailable
        this.isAudioPlaying = false;
        if (this.currentDhikrItem) {
          this.playWithSpeechSynthesis(this.currentDhikrItem.text);
        } else {
          this.notifyState();
        }
      };
    }
  }

  public setOnStateChange(cb: () => void) {
    this.onStateChangeCallback = cb;
  }

  private notifyState() {
    if (this.onStateChangeCallback) {
      this.onStateChangeCallback();
    }
  }

  public isPlaying(): boolean {
    return this.isAudioPlaying || this.isSpeechPlaying;
  }

  public getProgress(): number {
    return this.currentProgress;
  }

  public getCurrentTime(): number {
    return this.currentTime;
  }

  public getDuration(): number {
    return this.duration;
  }

  public getRepetition(): { current: number; total: number } {
    return { current: this.currentRepetition, total: this.repeatCount };
  }

  public getReciter(): ReciterId {
    return this.currentReciterId;
  }

  public setReciter(reciterId: ReciterId) {
    const changed = this.currentReciterId !== reciterId;
    this.currentReciterId = reciterId;
    if (changed && this.isPlaying() && this.currentDhikrItem) {
      this.playDhikr(this.currentDhikrItem, false);
    } else {
      this.notifyState();
    }
  }

  public setSpeed(speed: number) {
    this.playbackSpeed = speed;
    if (this.audioElement) {
      this.audioElement.playbackRate = speed;
    }
    this.notifyState();
  }

  public getSpeed(): number {
    return this.playbackSpeed;
  }

  public setRepeat(repeat: number) {
    this.repeatCount = repeat;
    this.notifyState();
  }

  public getRepeat(): number {
    return this.repeatCount;
  }

  public seek(progressRatio: number) {
    const clamped = Math.max(0, Math.min(1, progressRatio));
    this.currentProgress = clamped;
    if (this.audioElement && this.duration > 0) {
      this.audioElement.currentTime = clamped * this.duration;
      this.currentTime = this.audioElement.currentTime;
    }
    this.notifyState();
  }

  /**
   * Cleans punctuation and brackets from Arabic Dhikr text for smooth natural speech synthesis
   */
  private cleanTextForSpeech(text: string): string {
    return text
      .replace(/[«»﴿﴾]/g, '')
      .replace(/﴿\d+﴾/g, '') // remove verse markers like ﴿1﴾
      .replace(/\(\d+\)/g, '')
      .replace(/[\n\r]+/g, ' ')
      .trim();
  }

  /**
   * Plays the recitation for a specific Dhikr item with the chosen reciter
   */
  public playDhikr(dhikr: DhikrItem, startFromBeginning: boolean = true) {
    this.stop();
    this.currentDhikrItem = dhikr;

    if (startFromBeginning) {
      this.currentRepetition = 1;
      this.currentProgress = 0;
      this.currentTime = 0;
    }

    const reciterMap = RECITER_AUDIO_MAP[this.currentReciterId] || RECITER_AUDIO_MAP.alafasy;
    const quranAudioUrl = reciterMap[dhikr.id];

    // 1. If it's a Quranic Surah/Ayah with an authentic recitation URL, stream the high-definition audio
    if (quranAudioUrl && this.audioElement) {
      this.audioElement.src = quranAudioUrl;
      this.audioElement.playbackRate = this.playbackSpeed;
      this.isAudioPlaying = true;
      this.notifyState();

      const playPromise = this.audioElement.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {
          // If network audio stream fails, gracefully fallback to procedural voice
          this.isAudioPlaying = false;
          this.playWithSpeechSynthesis(dhikr.text);
        });
      }
      return;
    }

    // 2. Otherwise, use procedural Arabic voice modulated according to the chosen reciter's tone
    this.playWithSpeechSynthesis(dhikr.text);
  }

  private playWithSpeechSynthesis(text: string) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      this.isSpeechPlaying = false;
      this.notifyState();
      return;
    }

    window.speechSynthesis.cancel();

    const cleanText = this.cleanTextForSpeech(text);
    const utterance = new SpeechSynthesisUtterance(cleanText);

    // Look for Arabic voices
    const voices = window.speechSynthesis.getVoices();
    const arabicVoice = voices.find(v => v.lang.startsWith('ar') || v.lang.includes('AR'));
    if (arabicVoice) {
      utterance.voice = arabicVoice;
    }

    utterance.lang = 'ar-SA';

    // Tone modulation according to selected reciter style
    let reciterPitch = 1.0;
    let reciterRate = this.playbackSpeed;

    if (this.currentReciterId === 'alafasy') {
      reciterPitch = 1.02;
      reciterRate = this.playbackSpeed * 0.95;
    } else if (this.currentReciterId === 'ghamdi') {
      reciterPitch = 0.92;
      reciterRate = this.playbackSpeed * 0.90;
    } else if (this.currentReciterId === 'muaiqly') {
      reciterPitch = 1.08;
      reciterRate = this.playbackSpeed * 0.98;
    } else if (this.currentReciterId === 'abdulbasit') {
      reciterPitch = 1.12;
      reciterRate = this.playbackSpeed * 0.85; // slower deliberate classical Tajweed cadence
    }

    utterance.rate = Math.max(0.60, Math.min(reciterRate, 1.25));
    utterance.pitch = reciterPitch;

    const charCount = cleanText.length;
    // Estimate estimated duration based on text length
    this.duration = Math.max(5, Math.round(charCount / 12 / utterance.rate));

    utterance.onboundary = (event) => {
      if (charCount > 0 && event.charIndex !== undefined) {
        this.currentProgress = Math.min(event.charIndex / charCount, 0.98);
        this.currentTime = Math.round(this.currentProgress * this.duration);
        this.notifyState();
      }
    };

    utterance.onstart = () => {
      this.isSpeechPlaying = true;
      this.notifyState();
    };

    utterance.onend = () => {
      if (this.currentRepetition < this.repeatCount) {
        this.currentRepetition += 1;
        this.notifyState();
        setTimeout(() => {
          this.playWithSpeechSynthesis(text);
        }, 350);
      } else {
        this.isSpeechPlaying = false;
        this.currentProgress = 1;
        this.currentTime = this.duration;
        this.notifyState();
      }
    };

    utterance.onerror = () => {
      this.isSpeechPlaying = false;
      this.notifyState();
    };

    this.speechUtterance = utterance;
    window.speechSynthesis.speak(utterance);
  }

  public pause() {
    if (this.isAudioPlaying && this.audioElement) {
      this.audioElement.pause();
      this.isAudioPlaying = false;
      this.notifyState();
    } else if (this.isSpeechPlaying && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.pause();
      this.isSpeechPlaying = false;
      this.notifyState();
    }
  }

  public resume(dhikr: DhikrItem) {
    if (this.audioElement && this.audioElement.src && this.audioElement.paused) {
      this.audioElement.play().catch(() => {});
      this.isAudioPlaying = true;
      this.notifyState();
    } else if (typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      this.isSpeechPlaying = true;
      this.notifyState();
    } else {
      this.playDhikr(dhikr, false);
    }
  }

  public stop() {
    if (this.audioElement) {
      this.audioElement.pause();
      this.audioElement.currentTime = 0;
      this.isAudioPlaying = false;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      this.isSpeechPlaying = false;
    }
    this.currentProgress = 0;
    this.currentTime = 0;
    this.notifyState();
  }
}

// Global Singleton Recitation Instance
export const recitationEngine = new RecitationEngine();
