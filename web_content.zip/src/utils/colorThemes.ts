import { ColorId, NodeSkinConfig, ThemeConfig } from '../types/game';

export const COLOR_THEMES: Record<string, ThemeConfig> = {
  cyber_neon: {
    id: 'cyber_neon',
    name: 'Cyber Neon',
    description: 'Electric lasers on obsidian grid with ultra-vivid radiance.',
    price: 0,
    bgGradient: 'radial-gradient(ellipse at 50% 20%, #0d122b 0%, #060814 100%)',
    boardBg: '#090d20',
    gridLineColor: 'rgba(56, 189, 248, 0.12)',
    cellBg: 'rgba(15, 23, 42, 0.75)',
    cellHoverBg: 'rgba(30, 41, 59, 0.95)',
    colors: {
      red: {
        hex: '#ff2d55',
        rgb: '255, 45, 85',
        glow: 'rgba(255, 45, 85, 0.65)',
        symbol: '▲',
        label: 'Red'
      },
      blue: {
        hex: '#007aff',
        rgb: '0, 122, 255',
        glow: 'rgba(0, 122, 255, 0.65)',
        symbol: '●',
        label: 'Blue'
      },
      green: {
        hex: '#30d158',
        rgb: '48, 209, 88',
        glow: 'rgba(48, 209, 88, 0.65)',
        symbol: '■',
        label: 'Green'
      },
      yellow: {
        hex: '#ffd60a',
        rgb: '255, 214, 10',
        glow: 'rgba(255, 214, 10, 0.65)',
        symbol: '★',
        label: 'Yellow'
      },
      purple: {
        hex: '#bf5af2',
        rgb: '191, 90, 242',
        glow: 'rgba(191, 90, 242, 0.65)',
        symbol: '◆',
        label: 'Purple'
      },
      orange: {
        hex: '#ff9f0a',
        rgb: '255, 159, 10',
        glow: 'rgba(255, 159, 10, 0.65)',
        symbol: '⬡',
        label: 'Orange'
      },
      cyan: {
        hex: '#64d2ff',
        rgb: '100, 210, 255',
        glow: 'rgba(100, 210, 255, 0.65)',
        symbol: '✚',
        label: 'Cyan'
      },
      pink: {
        hex: '#ff375f',
        rgb: '255, 55, 95',
        glow: 'rgba(255, 55, 95, 0.65)',
        symbol: '♥',
        label: 'Pink'
      }
    }
  },
  synthwave_84: {
    id: 'synthwave_84',
    name: 'Synthwave 84',
    description: 'Retro arcade sunset neon with magenta and electric twilight.',
    price: 350,
    bgGradient: 'radial-gradient(ellipse at 50% 25%, #240b36 0%, #0d0417 100%)',
    boardBg: '#180728',
    gridLineColor: 'rgba(244, 63, 94, 0.15)',
    cellBg: 'rgba(38, 14, 62, 0.65)',
    cellHoverBg: 'rgba(64, 21, 105, 0.85)',
    colors: {
      red: {
        hex: '#f43f5e',
        rgb: '244, 63, 94',
        glow: 'rgba(244, 63, 94, 0.65)',
        symbol: '▲',
        label: 'Red'
      },
      blue: {
        hex: '#3b82f6',
        rgb: '59, 130, 246',
        glow: 'rgba(59, 130, 246, 0.65)',
        symbol: '●',
        label: 'Blue'
      },
      green: {
        hex: '#10b981',
        rgb: '16, 185, 129',
        glow: 'rgba(16, 185, 129, 0.65)',
        symbol: '■',
        label: 'Green'
      },
      yellow: {
        hex: '#fbbf24',
        rgb: '251, 191, 36',
        glow: 'rgba(251, 191, 36, 0.65)',
        symbol: '★',
        label: 'Yellow'
      },
      purple: {
        hex: '#d946ef',
        rgb: '217, 70, 239',
        glow: 'rgba(217, 70, 239, 0.65)',
        symbol: '◆',
        label: 'Purple'
      },
      orange: {
        hex: '#f97316',
        rgb: '249, 115, 22',
        glow: 'rgba(249, 115, 22, 0.65)',
        symbol: '⬡',
        label: 'Orange'
      },
      cyan: {
        hex: '#06b6d4',
        rgb: '6, 182, 212',
        glow: 'rgba(6, 182, 212, 0.65)',
        symbol: '✚',
        label: 'Cyan'
      },
      pink: {
        hex: '#ec4899',
        rgb: '236, 72, 153',
        glow: 'rgba(236, 72, 153, 0.65)',
        symbol: '♥',
        label: 'Pink'
      }
    }
  },
  solar_flare: {
    id: 'solar_flare',
    name: 'Solar Flare',
    description: 'Blazing coronal golds, molten amber, and crimson heat.',
    price: 500,
    bgGradient: 'radial-gradient(ellipse at 50% 20%, #2e1305 0%, #0e0501 100%)',
    boardBg: '#1c0c04',
    gridLineColor: 'rgba(245, 158, 11, 0.15)',
    cellBg: 'rgba(48, 20, 8, 0.65)',
    cellHoverBg: 'rgba(74, 32, 12, 0.85)',
    colors: {
      red: {
        hex: '#ef4444',
        rgb: '239, 68, 68',
        glow: 'rgba(239, 68, 68, 0.65)',
        symbol: '▲',
        label: 'Red'
      },
      blue: {
        hex: '#0284c7',
        rgb: '2, 132, 199',
        glow: 'rgba(2, 132, 199, 0.65)',
        symbol: '●',
        label: 'Blue'
      },
      green: {
        hex: '#22c55e',
        rgb: '34, 197, 94',
        glow: 'rgba(34, 197, 94, 0.65)',
        symbol: '■',
        label: 'Green'
      },
      yellow: {
        hex: '#f59e0b',
        rgb: '245, 158, 11',
        glow: 'rgba(245, 158, 11, 0.65)',
        symbol: '★',
        label: 'Yellow'
      },
      purple: {
        hex: '#a855f7',
        rgb: '168, 85, 247',
        glow: 'rgba(168, 85, 247, 0.65)',
        symbol: '◆',
        label: 'Purple'
      },
      orange: {
        hex: '#ea580c',
        rgb: '234, 88, 12',
        glow: 'rgba(234, 88, 12, 0.65)',
        symbol: '⬡',
        label: 'Orange'
      },
      cyan: {
        hex: '#14b8a6',
        rgb: '20, 184, 166',
        glow: 'rgba(20, 184, 166, 0.65)',
        symbol: '✚',
        label: 'Cyan'
      },
      pink: {
        hex: '#f43f5e',
        rgb: '244, 63, 94',
        glow: 'rgba(244, 63, 94, 0.65)',
        symbol: '♥',
        label: 'Pink'
      }
    }
  },
  midnight_emerald: {
    id: 'midnight_emerald',
    name: 'Midnight Emerald',
    description: 'Deep abyss jade, hyper-luminescent radioactive chartreuse.',
    price: 650,
    bgGradient: 'radial-gradient(ellipse at 50% 20%, #03231a 0%, #02110c 100%)',
    boardBg: '#051912',
    gridLineColor: 'rgba(16, 185, 129, 0.16)',
    cellBg: 'rgba(7, 39, 28, 0.65)',
    cellHoverBg: 'rgba(12, 59, 43, 0.85)',
    colors: {
      red: {
        hex: '#f87171',
        rgb: '248, 113, 113',
        glow: 'rgba(248, 113, 113, 0.65)',
        symbol: '▲',
        label: 'Red'
      },
      blue: {
        hex: '#38bdf8',
        rgb: '56, 189, 248',
        glow: 'rgba(56, 189, 248, 0.65)',
        symbol: '●',
        label: 'Blue'
      },
      green: {
        hex: '#10b981',
        rgb: '16, 185, 129',
        glow: 'rgba(16, 185, 129, 0.7)',
        symbol: '■',
        label: 'Green'
      },
      yellow: {
        hex: '#a3e635',
        rgb: '163, 230, 53',
        glow: 'rgba(163, 230, 53, 0.7)',
        symbol: '★',
        label: 'Lime'
      },
      purple: {
        hex: '#c084fc',
        rgb: '192, 132, 252',
        glow: 'rgba(192, 132, 252, 0.65)',
        symbol: '◆',
        label: 'Purple'
      },
      orange: {
        hex: '#fb923c',
        rgb: '251, 146, 60',
        glow: 'rgba(251, 146, 60, 0.65)',
        symbol: '⬡',
        label: 'Orange'
      },
      cyan: {
        hex: '#2dd4bf',
        rgb: '45, 212, 191',
        glow: 'rgba(45, 212, 191, 0.7)',
        symbol: '✚',
        label: 'Teal'
      },
      pink: {
        hex: '#fb7185',
        rgb: '251, 113, 133',
        glow: 'rgba(251, 113, 133, 0.65)',
        symbol: '♥',
        label: 'Pink'
      }
    }
  },
  cosmic_void: {
    id: 'cosmic_void',
    name: 'Cosmic Void',
    description: 'Dark matter nebula, supernova purples and starlight beams.',
    price: 800,
    bgGradient: 'radial-gradient(ellipse at 50% 25%, #18092e 0%, #06020c 100%)',
    boardBg: '#100520',
    gridLineColor: 'rgba(168, 85, 247, 0.16)',
    cellBg: 'rgba(29, 12, 54, 0.65)',
    cellHoverBg: 'rgba(48, 20, 89, 0.85)',
    colors: {
      red: {
        hex: '#fb7185',
        rgb: '251, 113, 133',
        glow: 'rgba(251, 113, 133, 0.65)',
        symbol: '▲',
        label: 'Red'
      },
      blue: {
        hex: '#818cf8',
        rgb: '129, 140, 248',
        glow: 'rgba(129, 140, 248, 0.65)',
        symbol: '●',
        label: 'Blue'
      },
      green: {
        hex: '#34d399',
        rgb: '52, 211, 153',
        glow: 'rgba(52, 211, 153, 0.65)',
        symbol: '■',
        label: 'Green'
      },
      yellow: {
        hex: '#fde047',
        rgb: '253, 224, 71',
        glow: 'rgba(253, 224, 71, 0.65)',
        symbol: '★',
        label: 'Yellow'
      },
      purple: {
        hex: '#c084fc',
        rgb: '192, 132, 252',
        glow: 'rgba(192, 132, 252, 0.75)',
        symbol: '◆',
        label: 'Purple'
      },
      orange: {
        hex: '#fdba74',
        rgb: '253, 186, 116',
        glow: 'rgba(253, 186, 116, 0.65)',
        symbol: '⬡',
        label: 'Orange'
      },
      cyan: {
        hex: '#38bdf8',
        rgb: '56, 189, 248',
        glow: 'rgba(56, 189, 248, 0.65)',
        symbol: '✚',
        label: 'Cyan'
      },
      pink: {
        hex: '#f472b6',
        rgb: '244, 114, 182',
        glow: 'rgba(244, 114, 182, 0.75)',
        symbol: '♥',
        label: 'Pink'
      }
    }
  },
  pastel_glow: {
    id: 'pastel_glow',
    name: 'Pastel Glow',
    description: 'Silky marshmallow illumination with soft high-contrast accents.',
    price: 450,
    bgGradient: 'radial-gradient(ellipse at 50% 20%, #151a2d 0%, #090c17 100%)',
    boardBg: '#101424',
    gridLineColor: 'rgba(148, 163, 184, 0.14)',
    cellBg: 'rgba(30, 41, 59, 0.55)',
    cellHoverBg: 'rgba(51, 65, 85, 0.8)',
    colors: {
      red: {
        hex: '#fda4af',
        rgb: '253, 164, 175',
        glow: 'rgba(253, 164, 175, 0.65)',
        symbol: '▲',
        label: 'Rose'
      },
      blue: {
        hex: '#93c5fd',
        rgb: '147, 197, 253',
        glow: 'rgba(147, 197, 253, 0.65)',
        symbol: '●',
        label: 'Sky'
      },
      green: {
        hex: '#86efac',
        rgb: '134, 239, 172',
        glow: 'rgba(134, 239, 172, 0.65)',
        symbol: '■',
        label: 'Mint'
      },
      yellow: {
        hex: '#fde047',
        rgb: '253, 224, 71',
        glow: 'rgba(253, 224, 71, 0.65)',
        symbol: '★',
        label: 'Butter'
      },
      purple: {
        hex: '#d8b4fe',
        rgb: '216, 180, 254',
        glow: 'rgba(216, 180, 254, 0.65)',
        symbol: '◆',
        label: 'Lilac'
      },
      orange: {
        hex: '#fed7aa',
        rgb: '254, 215, 170',
        glow: 'rgba(254, 215, 170, 0.65)',
        symbol: '⬡',
        label: 'Peach'
      },
      cyan: {
        hex: '#a5f3fc',
        rgb: '165, 243, 252',
        glow: 'rgba(165, 243, 252, 0.65)',
        symbol: '✚',
        label: 'Ice'
      },
      pink: {
        hex: '#fbcfe8',
        rgb: '251, 207, 232',
        glow: 'rgba(251, 207, 232, 0.65)',
        symbol: '♥',
        label: 'Blush'
      }
    }
  }
};

export const NODE_SKINS: Record<string, NodeSkinConfig> = {
  neon_orb: {
    id: 'neon_orb',
    name: 'Neon Orb',
    description: 'Pulsing dual-layer luminescent core with radial light halo.',
    price: 0,
    style: 'orb'
  },
  gemstone: {
    id: 'gemstone',
    name: 'Gemstone Crystal',
    description: 'Faceted geometric cuts that catch grid light refraction.',
    price: 250,
    style: 'gem'
  },
  cyber_glyph: {
    id: 'cyber_glyph',
    name: 'Cyber Glyph',
    description: 'Holographic matrix insignia with crisp colorblind iconography.',
    price: 400,
    style: 'glyph'
  },
  minimal_dot: {
    id: 'minimal_dot',
    name: 'Minimal Dot',
    description: 'Clean Scandinavian modernist circular aesthetic with ultra-sharp ring.',
    price: 150,
    style: 'minimal'
  }
};
