import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import {
  BACKUP_FORMAT_VERSION,
  DRIVE_BACKUP_FILENAME,
} from './cryptoBackup';

export const SCOPES = ['https://www.googleapis.com/auth/drive.appdata'];

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
// Request ONLY the minimum required Drive OAuth scope: appDataFolder
SCOPES.forEach((scope) => provider.addScope(scope));
provider.setCustomParameters({
  prompt: 'select_account',
});

// Flag to indicate if we are in the middle of a sign-in flow.
let isSigningIn = false;
// Cache the OAuth access token strictly in memory (never in localStorage/sessionStorage).
let cachedAccessToken: string | null = null;

export interface DriveBackupFileMetadata {
  id: string;
  name: string;
  sizeBytes: number;
  modifiedTime: string;
  backupVersion: string;
  sha256: string;
}

export const initDriveAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: (user: User | null) => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure(user);
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure(null);
    }
  });
};

export const googleSignInForDrive = async (): Promise<{
  user: User;
  accessToken: string;
}> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error(
        'গুগল ড্রাইভ অ্যাক্সেস টোকেন পাওয়া যায়নি। অনুগ্রহ করে আবার সাইন ইন করুন।'
      );
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const disconnectGoogleAccount = async (): Promise<void> => {
  await auth.signOut();
  cachedAccessToken = null;
};

/**
 * Lists encrypted backup files stored inside the private Google Drive `appDataFolder`.
 */
export async function listAppDataBackups(
  accessToken: string
): Promise<DriveBackupFileMetadata[]> {
  const query = encodeURIComponent(
    `name = '${DRIVE_BACKUP_FILENAME}' and trashed = false`
  );
  const fields = encodeURIComponent(
    'files(id,name,size,modifiedTime,appProperties)'
  );
  const url = `https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=${query}&fields=${fields}&orderBy=modifiedTime desc&pageSize=10`;

  const res = await fetch(url, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (res.status === 401 || res.status === 403) {
    cachedAccessToken = null;
    throw new Error('AUTH_EXPIRED');
  }

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`ড্রাইভ ব্যাকআপ তালিকা লোড ব্যর্থ হয়েছে (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const files = Array.isArray(data.files) ? data.files : [];

  return files.map((f: Record<string, any>) => ({
    id: String(f.id),
    name: String(f.name || DRIVE_BACKUP_FILENAME),
    sizeBytes: Number(f.size || 0),
    modifiedTime: String(f.modifiedTime || new Date().toISOString()),
    backupVersion: String(
      f.appProperties?.backupVersion || `v${BACKUP_FORMAT_VERSION}`
    ),
    sha256: String(f.appProperties?.sha256 || ''),
  }));
}

/**
 * Uploads or updates the AES-256-GCM encrypted backup file inside Google Drive `appDataFolder`.
 */
export async function uploadEncryptedBackupToDrive(params: {
  accessToken: string;
  serializedEncryptedJson: string;
  sha256Hex: string;
  existingFileId?: string;
}): Promise<DriveBackupFileMetadata> {
  const { accessToken, serializedEncryptedJson, sha256Hex, existingFileId } =
    params;

  const metadata: Record<string, any> = {
    name: DRIVE_BACKUP_FILENAME,
    mimeType: 'application/json',
    appProperties: {
      appName: 'HisabKhata',
      backupVersion: `v${BACKUP_FORMAT_VERSION}`,
      encryption: 'AES-256-GCM',
      sha256: sha256Hex,
    },
  };

  if (!existingFileId) {
    metadata.parents = ['appDataFolder'];
  }

  const boundary = 'hisab_khata_drive_multipart_' + Date.now();
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const multipartBody =
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    serializedEncryptedJson +
    closeDelimiter;

  const uploadUrl = existingFileId
    ? `https://www.googleapis.com/upload/drive/v3/files/${encodeURIComponent(
        existingFileId
      )}?uploadType=multipart&fields=id,name,size,modifiedTime,appProperties`
    : 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size,modifiedTime,appProperties';

  const res = await fetch(uploadUrl, {
    method: existingFileId ? 'PATCH' : 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': `multipart/related; boundary=${boundary}`,
    },
    body: multipartBody,
  });

  if (res.status === 401 || res.status === 403) {
    cachedAccessToken = null;
    throw new Error('AUTH_EXPIRED');
  }

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`ড্রাইভে ব্যাকআপ আপলোড ব্যর্থ হয়েছে (${res.status}): ${errText}`);
  }

  const f = await res.json();
  return {
    id: String(f.id),
    name: String(f.name || DRIVE_BACKUP_FILENAME),
    sizeBytes:
      Number(f.size) || new Blob([serializedEncryptedJson]).size,
    modifiedTime: String(f.modifiedTime || new Date().toISOString()),
    backupVersion: String(
      f.appProperties?.backupVersion || `v${BACKUP_FORMAT_VERSION}`
    ),
    sha256: String(f.appProperties?.sha256 || sha256Hex),
  };
}

/**
 * Downloads the encrypted backup file content from Google Drive `appDataFolder`.
 */
export async function downloadEncryptedBackupFromDrive(
  accessToken: string,
  fileId: string
): Promise<string> {
  const url = `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(
    fileId
  )}?alt=media`;

  const res = await fetch(url, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (res.status === 401 || res.status === 403) {
    cachedAccessToken = null;
    throw new Error('AUTH_EXPIRED');
  }

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`ব্যাকআপ ডাউনলোড ব্যর্থ হয়েছে (${res.status}): ${errText}`);
  }

  return await res.text();
}
