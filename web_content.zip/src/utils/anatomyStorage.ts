// Comprehensive Local Storage, Cache, and IndexedDB utility for 3D Anatomical GLB/glTF models
// Guarantees 100% offline viewing without internet connectivity

const DB_NAME = 'ShadowRadiology3D_DB';
const STORE_NAME = 'anatomical_models';
const DB_VERSION = 1;
const LOCAL_STORAGE_MANIFEST_KEY = 'shadow_radiology_cached_models_manifest';
const CACHE_NAME = 'shadow-radiology-models-cache-v1';

export interface CachedModelRecord {
  id: string;
  name: string;
  size: number;
  format: 'glb' | 'gltf';
  buffer: ArrayBuffer;
  savedAt: string;
  source: string;
}

export interface CachedModelSummary {
  id: string;
  name: string;
  size: number;
  format: 'glb' | 'gltf';
  savedAt: string;
  source: string;
  isCurrentActive?: boolean;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB غير مدعوم في هذا المتصفح'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// Update Local Storage Manifest for instant offline status without waiting for DB queries
function updateLocalStorageManifest(summary: CachedModelSummary, action: 'add' | 'delete') {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_MANIFEST_KEY);
    let list: CachedModelSummary[] = raw ? JSON.parse(raw) : [];

    if (action === 'delete') {
      list = list.filter((item) => item.id !== summary.id && item.id !== 'active_anatomy_model');
    } else {
      list = list.filter((item) => item.id !== summary.id);
      list.unshift(summary);
    }

    localStorage.setItem(LOCAL_STORAGE_MANIFEST_KEY, JSON.stringify(list));
    localStorage.setItem('shadow_radiology_active_model_name', summary.name);
    localStorage.setItem('shadow_radiology_active_model_size', String(summary.size));
    localStorage.setItem('shadow_radiology_active_model_date', summary.savedAt);
  } catch (err) {
    console.warn('Could not sync with localStorage manifest:', err);
  }
}

// Save model binary to IndexedDB, Cache API, and localStorage metadata
export async function saveModelToStorage(record: CachedModelRecord): Promise<boolean> {
  try {
    const db = await openDB();

    // 1. Save specific model record in IndexedDB
    await new Promise<boolean>((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.put(record);

      request.onsuccess = () => resolve(true);
      request.onerror = () => reject(request.error);
    });

    // 2. Also save as the active model pointer if it's not already
    if (record.id !== 'active_anatomy_model') {
      const activeCopy: CachedModelRecord = {
        ...record,
        id: 'active_anatomy_model'
      };
      await new Promise<boolean>((resolve, reject) => {
        const transaction = db.transaction([STORE_NAME], 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const req = store.put(activeCopy);
        req.onsuccess = () => resolve(true);
        req.onerror = () => reject(req.error);
      });
    }

    // 3. Mirror into Cache Storage API if supported
    if ('caches' in window) {
      try {
        const cache = await caches.open(CACHE_NAME);
        const cacheResponse = new Response(record.buffer, {
          headers: {
            'Content-Type': record.format === 'glb' ? 'model/gltf-binary' : 'model/gltf+json',
            'Content-Length': String(record.size),
            'X-Model-Name': encodeURIComponent(record.name),
            'X-Saved-At': record.savedAt
          }
        });
        await cache.put(`/offline-models/${record.id}.glb`, cacheResponse);
      } catch (cacheErr) {
        console.warn('Cache Storage write skipped:', cacheErr);
      }
    }

    // 4. Update localStorage manifest
    updateLocalStorageManifest(
      {
        id: record.id,
        name: record.name,
        size: record.size,
        format: record.format,
        savedAt: record.savedAt,
        source: record.source,
        isCurrentActive: true
      },
      'add'
    );

    return true;
  } catch (err) {
    console.warn('Failed to save 3D model to offline storage:', err);
    return false;
  }
}

// Load model from IndexedDB
export async function loadModelFromStorage(id: string = 'active_anatomy_model'): Promise<CachedModelRecord | null> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.get(id);

      request.onsuccess = () => {
        resolve(request.result || null);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('Failed to load 3D model from IndexedDB:', err);
    return null;
  }
}

// Get all stored models metadata (for the offline library / saved models switcher)
export async function getAllStoredModels(): Promise<CachedModelSummary[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll();

      request.onsuccess = () => {
        const records: CachedModelRecord[] = request.result || [];
        // Filter out the 'active_anatomy_model' alias to avoid duplicates in the UI list
        const activeRecord = records.find((r) => r.id === 'active_anatomy_model');
        const activeName = activeRecord ? activeRecord.name : '';

        const summaries: CachedModelSummary[] = records
          .filter((r) => r.id !== 'active_anatomy_model')
          .map((r) => ({
            id: r.id,
            name: r.name,
            size: r.size,
            format: r.format,
            savedAt: r.savedAt,
            source: r.source,
            isCurrentActive: r.name === activeName
          }));

        resolve(summaries);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('Failed to get all models from IndexedDB:', err);
    // Fallback to localStorage manifest
    try {
      const raw = localStorage.getItem(LOCAL_STORAGE_MANIFEST_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }
}

// Set a previously saved model as the current active model
export async function switchActiveModel(id: string): Promise<CachedModelRecord | null> {
  const model = await loadModelFromStorage(id);
  if (!model) return null;

  await saveModelToStorage({
    ...model,
    id: 'active_anatomy_model'
  });

  return model;
}

// Delete model from storage
export async function deleteModelFromStorage(id: string = 'active_anatomy_model'): Promise<boolean> {
  try {
    const db = await openDB();
    await new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.delete(id);

      request.onsuccess = () => resolve(true);
      request.onerror = () => reject(request.error);
    });

    if ('caches' in window) {
      try {
        const cache = await caches.open(CACHE_NAME);
        await cache.delete(`/offline-models/${id}.glb`);
      } catch {}
    }

    updateLocalStorageManifest(
      {
        id,
        name: '',
        size: 0,
        format: 'glb',
        savedAt: '',
        source: ''
      },
      'delete'
    );

    return true;
  } catch (err) {
    console.warn('Failed to delete 3D model from IndexedDB:', err);
    return false;
  }
}

// Storage usage estimation (Quota & usage)
export async function getStorageUsageEstimate(): Promise<{
  usageMb: string;
  quotaMb: string;
  percentUsed: number;
}> {
  if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.estimate) {
    try {
      const estimate = await navigator.storage.estimate();
      const usage = estimate.usage || 0;
      const quota = estimate.quota || 0;
      return {
        usageMb: (usage / (1024 * 1024)).toFixed(1),
        quotaMb: (quota / (1024 * 1024)).toFixed(0),
        percentUsed: quota > 0 ? Math.min(100, Math.round((usage / quota) * 100)) : 0
      };
    } catch {}
  }

  return {
    usageMb: '0.0',
    quotaMb: 'غير محدد',
    percentUsed: 0
  };
}
