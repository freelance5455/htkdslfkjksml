/**
 * Utility to generate an instant synthetic sample video on client side.
 * This ensures that users can immediately test splitting, filters, templates,
 * and real video exports even if they haven't uploaded their own file yet!
 */

export async function generateSyntheticSampleVideo(
  durationSeconds: number = 65,
  width: number = 1280,
  height: number = 720,
  onProgress?: (pct: number) => void
): Promise<{ blob: Blob; url: string; duration: number }> {
  return new Promise((resolve, reject) => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        throw new Error('Canvas 2D context not available');
      }

      // Audio setup using Web Audio API
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioCtxClass();
      const dest = audioCtx.createMediaStreamDestination();

      // Create a gentle rhythmic pulse / ambient background synth
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(220, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
      osc.connect(gain);
      gain.connect(dest);
      osc.start();

      const canvasStream = canvas.captureStream(30); // 30 fps
      // Merge audio track
      const audioTrack = dest.stream.getAudioTracks()[0];
      if (audioTrack) {
        canvasStream.addTrack(audioTrack);
      }

      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
        ? 'video/webm;codecs=vp9,opus'
        : MediaRecorder.isTypeSupported('video/webm')
        ? 'video/webm'
        : 'video/mp4';

      const recorder = new MediaRecorder(canvasStream, {
        mimeType,
        videoBitsPerSecond: 2500000
      });

      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunks.push(e.data);
        }
      };

      recorder.onstop = () => {
        osc.stop();
        audioCtx.close().catch(() => {});
        const finalBlob = new Blob(chunks, { type: mimeType });
        const url = URL.createObjectURL(finalBlob);
        resolve({ blob: finalBlob, url, duration: durationSeconds });
      };

      recorder.start(100);

      // Fast recording: 60 frames (2 seconds real recording) representing high-def demo
      const fps = 30;
      const totalFrames = 60;
      let frame = 0;

      const interval = setInterval(() => {
        const timeSec = (frame / totalFrames) * durationSeconds;
        const progress = frame / totalFrames;

        // Render dynamic frame
        renderSampleFrame(ctx, width, height, timeSec, durationSeconds, progress);

        if (onProgress && frame % 10 === 0) {
          onProgress(Math.round(progress * 100));
        }

        frame++;
        if (frame >= totalFrames) {
          clearInterval(interval);
          setTimeout(() => {
            recorder.stop();
          }, 150);
        }
      }, 1000 / fps);
    } catch (err) {
      reject(err);
    }
  });
}

function renderSampleFrame(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  time: number,
  duration: number,
  progress: number
) {
  // Rich background with animated gradient
  const grad = ctx.createLinearGradient(0, 0, w, h);
  const hue1 = (time * 12 + 250) % 360;
  const hue2 = (time * 12 + 310) % 360;
  grad.addColorStop(0, `hsl(${hue1}, 70%, 15%)`);
  grad.addColorStop(0.5, `hsl(${(hue1 + hue2) / 2}, 60%, 10%)`);
  grad.addColorStop(1, `hsl(${hue2}, 75%, 12%)`);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Animated background glowing geometric circles
  const cx = w / 2;
  const cy = h / 2;
  const pulse = Math.sin(time * 3) * 30;

  ctx.beginPath();
  ctx.arc(cx + Math.cos(time) * 100, cy + Math.sin(time) * 40, 180 + pulse, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(168, 85, 247, 0.12)';
  ctx.fill();

  ctx.beginPath();
  ctx.arc(cx - Math.sin(time * 0.8) * 120, cy + Math.cos(time * 0.8) * 60, 220 + pulse * 0.5, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(59, 130, 246, 0.12)';
  ctx.fill();

  // Foreground video badge
  ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
  ctx.beginPath();
  ctx.roundRect(cx - 320, cy - 140, 640, 280, 24);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
  ctx.lineWidth = 2;
  ctx.stroke();

  // App Brand Logo & Title
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 44px Cairo, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('Designo Studio ⚡', cx, cy - 50);

  // Arabic Subtitle
  ctx.font = '24px Cairo, sans-serif';
  ctx.fillStyle = '#cbd5e1';
  ctx.fillText('فيديو تجريبي عالي الدقة لمحرر الفيديو والتقسيم', cx, cy - 5);

  // Digital Timer / Timecode
  const mins = Math.floor(time / 60).toString().padStart(2, '0');
  const secs = Math.floor(time % 60).toString().padStart(2, '0');
  const ms = Math.floor((time % 1) * 100).toString().padStart(2, '0');
  const totalMins = Math.floor(duration / 60).toString().padStart(2, '0');
  const totalSecs = Math.floor(duration % 60).toString().padStart(2, '0');

  ctx.font = 'bold 36px monospace';
  ctx.fillStyle = '#38bdf8';
  ctx.fillText(`${mins}:${secs}.${ms} / ${totalMins}:${totalSecs}`, cx, cy + 55);

  // Progress Bar
  const barWidth = 500;
  const barHeight = 10;
  const barX = cx - barWidth / 2;
  const barY = cy + 90;

  ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
  ctx.beginPath();
  ctx.roundRect(barX, barY, barWidth, barHeight, 5);
  ctx.fill();

  ctx.fillStyle = '#a855f7';
  ctx.beginPath();
  ctx.roundRect(barX, barY, Math.max(5, barWidth * progress), barHeight, 5);
  ctx.fill();

  // Top Watermark
  ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
  ctx.font = '16px Cairo, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('Designo • Video Montage AI', 30, 45);

  ctx.textAlign = 'right';
  ctx.fillText(`${w} × ${h} | 30 FPS`, w - 30, 45);
}
