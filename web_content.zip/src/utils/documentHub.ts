import JSZip from "jszip";
import { Note } from "../types";
import { parseUniversalFile } from "./universalParser";
import { isColorNoteFile, decryptColorNoteBackupApi } from "./colorNoteParser";

export { decryptColorNoteBackupApi };

export type DocumentCategory =
  | "office"      // .docx, .doc, .pdf, .txt, .rtf, .odt
  | "table"       // .xlsx, .xls, .csv, .ods
  | "presentation"// .pptx, .ppt, .pdf (presentation), .odp
  | "media"       // .jpg, .png, .svg, .gif, .psd, .ai
  | "audio_video" // .mp3, .wav, .mp4, .mkv, .avi
  | "archive"     // .zip, .rar, .7z
  | "code_web"    // .html, .css, .js, .json, .xml
  | "binary";     // .bin, .dat, .hex, .rom, .iso

export interface DocumentFormatInfo {
  id: string;
  name: string;
  extension: string;
  category: DocumentCategory;
  categoryLabel: string;
  mimeType: string;
  iconName: string;
  description: string;
  canExport: boolean;
  canImport: boolean;
  badgeColor: string;
}

export const SUPPORTED_DOCUMENT_FORMATS: DocumentFormatInfo[] = [
  // Metin ve Ofis Belgeleri
  {
    id: "docx",
    name: "Microsoft Word",
    extension: ".docx",
    category: "office",
    categoryLabel: "Metin ve Ofis Belgeleri",
    mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    iconName: "FileText",
    description: "Word ve LibreOffice ile tam uyumlu zengin metin belgesi.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300",
  },
  {
    id: "pdf",
    name: "Taşınabilir Belge (PDF)",
    extension: ".pdf",
    category: "office",
    categoryLabel: "Metin ve Ofis Belgeleri",
    mimeType: "application/pdf",
    iconName: "FileText",
    description: "Platformlar arası biçimini koruyan yüksek kaliteli yazdırma ve PDF belgesi.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300",
  },
  {
    id: "txt",
    name: "Düz Metin (TXT)",
    extension: ".txt",
    category: "office",
    categoryLabel: "Metin ve Ofis Belgeleri",
    mimeType: "text/plain",
    iconName: "File",
    description: "Ham, evrensel ve hafif düz metin belgesi.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200",
  },
  {
    id: "rtf",
    name: "Zengin Metin (RTF)",
    extension: ".rtf",
    category: "office",
    categoryLabel: "Metin ve Ofis Belgeleri",
    mimeType: "application/rtf",
    iconName: "FileEdit",
    description: "Kelime işlemciler arasında stil ve biçimlendirmeyi koruyan zengin metin.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300",
  },
  {
    id: "odt",
    name: "OpenDocument Metin (ODT)",
    extension: ".odt",
    category: "office",
    categoryLabel: "Metin ve Ofis Belgeleri",
    mimeType: "application/vnd.oasis.opendocument.text",
    iconName: "FileCheck",
    description: "LibreOffice ve açık kaynaklı ofis paketleri için açık metin standardı.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300",
  },

  // Tablo ve Veri Belgeleri
  {
    id: "xlsx",
    name: "Excel Tablosu (XLSX)",
    extension: ".xlsx",
    category: "table",
    categoryLabel: "Tablo ve Veri Belgeleri",
    mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    iconName: "FileSpreadsheet",
    description: "Microsoft Excel ve hesap tablosu yazılımları için sütunlu veri tablosu.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300",
  },
  {
    id: "csv",
    name: "Virgülle Ayrılmış Tablo (CSV)",
    extension: ".csv",
    category: "table",
    categoryLabel: "Tablo ve Veri Belgeleri",
    mimeType: "text/csv",
    iconName: "Table",
    description: "Evrensel veri analizi, Excel ve veritabanları için tablo verisi.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-green-100 text-green-800 dark:bg-green-950 dark:text-green-300",
  },
  {
    id: "ods",
    name: "OpenDocument Tablo (ODS)",
    extension: ".ods",
    category: "table",
    categoryLabel: "Tablo ve Veri Belgeleri",
    mimeType: "application/vnd.oasis.opendocument.spreadsheet",
    iconName: "FileSpreadsheet",
    description: "Açık kaynaklı elektronik hesap tablosu belgesi.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300",
  },

  // Sunum Belgeleri
  {
    id: "pptx",
    name: "PowerPoint Sunumu (PPTX)",
    extension: ".pptx",
    category: "presentation",
    categoryLabel: "Sunum Belgeleri",
    mimeType: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    iconName: "Presentation",
    description: "Notlarınızı slaytlara ve sunum akışına dönüştüren sunum belgesi.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300",
  },
  {
    id: "odp",
    name: "OpenDocument Sunum (ODP)",
    extension: ".odp",
    category: "presentation",
    categoryLabel: "Sunum Belgeleri",
    mimeType: "application/vnd.oasis.opendocument.presentation",
    iconName: "Presentation",
    description: "LibreOffice Impress uyumlu açık sunum formatı.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300",
  },

  // Görsel ve Grafik Dosyaları
  {
    id: "png",
    name: "Kayıpsız Görsel (PNG)",
    extension: ".png",
    category: "media",
    categoryLabel: "Görsel ve Grafik Dosyaları",
    mimeType: "image/png",
    iconName: "Image",
    description: "Şeffaflık ve yüksek netlik destekli görsel kartı.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-cyan-100 text-cyan-800 dark:bg-cyan-950 dark:text-cyan-300",
  },
  {
    id: "svg",
    name: "Vektörel Grafik (SVG)",
    extension: ".svg",
    category: "media",
    categoryLabel: "Görsel ve Grafik Dosyaları",
    mimeType: "image/svg+xml",
    iconName: "Shapes",
    description: "Kalite kaybı olmadan ölçeklenebilen vektörel not kartı.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300",
  },
  {
    id: "jpg",
    name: "Standart Görsel (JPG / JPEG)",
    extension: ".jpg",
    category: "media",
    categoryLabel: "Görsel ve Grafik Dosyaları",
    mimeType: "image/jpeg",
    iconName: "Image",
    description: "Standart fotoğraf ve grafik formatı.",
    canExport: false,
    canImport: true,
    badgeColor: "bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300",
  },
  {
    id: "gif",
    name: "Hareketli Görsel (GIF)",
    extension: ".gif",
    category: "media",
    categoryLabel: "Görsel ve Grafik Dosyaları",
    mimeType: "image/gif",
    iconName: "Film",
    description: "Hareketli veya sabit kısa görsel formatı.",
    canExport: false,
    canImport: true,
    badgeColor: "bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300",
  },
  {
    id: "psd_ai",
    name: "Tasarım Kaynağı (PSD / AI)",
    extension: ".psd",
    category: "media",
    categoryLabel: "Görsel ve Grafik Dosyaları",
    mimeType: "application/octet-stream",
    iconName: "Layers",
    description: "Photoshop ve Illustrator kaynak dosyaları (iliştirilmiş medya notu).",
    canExport: false,
    canImport: true,
    badgeColor: "bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300",
  },

  // Ses ve Video Dosyaları
  {
    id: "audio",
    name: "Ses Kaydı (MP3 / WAV)",
    extension: ".mp3",
    category: "audio_video",
    categoryLabel: "Ses ve Video Dosyaları",
    mimeType: "audio/mpeg",
    iconName: "Volume2",
    description: "Sesli notlar ve ses kayıtları için oynatıcılı ortam belgesi.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300",
  },
  {
    id: "video",
    name: "Video Kaydı (MP4 / MKV / AVI)",
    extension: ".mp4",
    category: "audio_video",
    categoryLabel: "Ses ve Video Dosyaları",
    mimeType: "video/mp4",
    iconName: "Video",
    description: "Dahili video oynatıcılı multimedya notu.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-violet-100 text-violet-800 dark:bg-violet-950 dark:text-violet-300",
  },

  // Sıkıştırılmış Arşiv Dosyaları
  {
    id: "zip",
    name: "Sıkıştırılmış Arşiv (ZIP)",
    extension: ".zip",
    category: "archive",
    categoryLabel: "Sıkıştırılmış Arşiv Dosyaları",
    mimeType: "application/zip",
    iconName: "Archive",
    description: "Tüm notları farklı biçimlerde paketleyen taşınabilir arşiv paketi.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-yellow-100 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-300",
  },
  {
    id: "rar_7z",
    name: "Arşiv Paketi (RAR / 7Z)",
    extension: ".7z",
    category: "archive",
    categoryLabel: "Sıkıştırılmış Arşiv Dosyaları",
    mimeType: "application/x-7z-compressed",
    iconName: "Archive",
    description: "Sıkıştırılmış çoklu dosya ve veri arşivi.",
    canExport: false,
    canImport: true,
    badgeColor: "bg-stone-100 text-stone-800 dark:bg-stone-800 dark:text-stone-300",
  },

  // Kod ve Web Belgeleri
  {
    id: "html",
    name: "Web Sayfası (HTML)",
    extension: ".html",
    category: "code_web",
    categoryLabel: "Kod ve Web Belgeleri",
    mimeType: "text/html",
    iconName: "Globe",
    description: "Tüm tarayıcılarda doğrudan açılabilen modern stilli web belgesi.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300",
  },
  {
    id: "json",
    name: "Yapılandırılmış Veri (JSON)",
    extension: ".json",
    category: "code_web",
    categoryLabel: "Kod ve Web Belgeleri",
    mimeType: "application/json",
    iconName: "FileCode",
    description: "NoteFlow ve harici sistemler için tam meta verili yedekleme verisi.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-lime-100 text-lime-800 dark:bg-lime-950 dark:text-lime-300",
  },
  {
    id: "xml",
    name: "Standart XML Verisi (XML)",
    extension: ".xml",
    category: "code_web",
    categoryLabel: "Kod ve Web Belgeleri",
    mimeType: "application/xml",
    iconName: "Code",
    description: "Kurumsal ve açık sistemler arası veri aktarım standardı.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300",
  },
  {
    id: "code",
    name: "Kaynak Kod (CSS / JS / TS)",
    extension: ".js",
    category: "code_web",
    categoryLabel: "Kod ve Web Belgeleri",
    mimeType: "text/javascript",
    iconName: "Code2",
    description: "Geliştirici kod blokları ve betikler.",
    canExport: true,
    canImport: true,
    badgeColor: "bg-yellow-100 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-300",
  },
  // İkili ve Sistem Dosyaları (.BIN / .DAT / .HEX)
  {
    id: "bin",
    name: "İkili Sistem Dosyası (BIN / DAT / HEX)",
    extension: ".bin",
    category: "binary",
    categoryLabel: "İkili ve Sistem Dosyaları",
    mimeType: "application/octet-stream",
    iconName: "Binary",
    description: "İkili firmware, bellek dökümü ve byte yapılı sistem dosyaları (HEX dökümü ve ASCII metin ayrıştırma).",
    canExport: true,
    canImport: true,
    badgeColor: "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300",
  },
];

// Helper to trigger file download in browser
export function triggerFileDownload(filename: string, content: Blob | string, mimeType: string) {
  const blob = typeof content === "string" ? new Blob([content], { type: `${mimeType};charset=utf-8` }) : content;
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

// 1. Export as Word (.docx / .doc)
export function exportToWordDocx(notes: Note[] | Note, customTitle?: string) {
  const notesArray = Array.isArray(notes) ? notes : [notes];
  const docTitle = customTitle || (notesArray.length === 1 ? notesArray[0].title : "NoteFlow_Belgeleri");

  let htmlBody = `
    <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
    <head>
      <meta charset='utf-8'>
      <title>${docTitle}</title>
      <style>
        body { font-family: 'Calibri', 'Arial', sans-serif; font-size: 11pt; line-height: 1.6; color: #1e293b; padding: 24pt; }
        h1.main-title { font-size: 24pt; color: #0f766e; border-bottom: 2pt solid #0f766e; padding-bottom: 6pt; margin-bottom: 18pt; }
        .note-block { page-break-after: auto; margin-bottom: 24pt; border: 1pt solid #cbd5e1; padding: 16pt; border-radius: 6pt; background-color: #f8fafc; }
        h2.note-title { font-size: 16pt; color: #0d9488; margin-top: 0; margin-bottom: 6pt; }
        .meta-bar { font-size: 9pt; color: #64748b; margin-bottom: 12pt; border-bottom: 1pt solid #e2e8f0; padding-bottom: 4pt; }
        .note-body { font-size: 11pt; white-space: pre-wrap; line-height: 1.6; color: #334155; }
        .tasks-heading { font-size: 12pt; font-weight: bold; color: #0f766e; margin-top: 14pt; margin-bottom: 6pt; }
        .task-item { font-size: 10pt; margin-left: 12pt; color: #334155; }
        .task-done { text-decoration: line-through; color: #94a3b8; }
        .tags-bar { margin-top: 10pt; font-size: 9pt; color: #0d9488; font-weight: bold; }
        table.meta-table { width: 100%; border-collapse: collapse; margin-bottom: 16pt; }
        table.meta-table th, table.meta-table td { border: 1pt solid #cbd5e1; padding: 6pt; font-size: 9.5pt; text-align: left; }
        table.meta-table th { background-color: #f1f5f9; color: #0f766e; }
      </style>
    </head>
    <body>
      <h1 class='main-title'>${docTitle}</h1>
      <p style='font-size: 10pt; color: #64748b;'>Oluşturulma Tarihi: ${new Date().toLocaleString("tr-TR")} | Toplam Not: ${notesArray.length}</p>
      <hr style='border: 0; border-top: 1pt solid #cbd5e1; margin-bottom: 20pt;' />
  `;

  notesArray.forEach((note, idx) => {
    htmlBody += `
      <div class='note-block'>
        <h2 class='note-title'>${idx + 1}. ${note.title || "Başlıksız Not"}</h2>
        <div class='meta-bar'>
          <strong>Bölüm:</strong> ${note.category} &nbsp;|&nbsp; 
          <strong>Son Güncelleme:</strong> ${new Date(note.updatedAt).toLocaleString("tr-TR")} &nbsp;|&nbsp; 
          <strong>Durum:</strong> ${note.pinned ? "Sabitlenmiş" : "Normal"}
        </div>
        <div class='note-body'>${note.htmlContent ? note.htmlContent : note.content.replace(/\n/g, "<br/>")}</div>
    `;

    if (note.tasks && note.tasks.length > 0) {
      htmlBody += `<div class='tasks-heading'>Görev Listesi:</div>`;
      note.tasks.forEach((t) => {
        htmlBody += `
          <div class='task-item ${t.completed ? "task-done" : ""}'>
            ${t.completed ? "☑" : "☐"} ${t.text}
          </div>
        `;
      });
    }

    if (note.tags && note.tags.length > 0) {
      htmlBody += `<div class='tags-bar'>Etiketler: ${note.tags.join(", ")}</div>`;
    }

    htmlBody += `</div>`;
  });

  htmlBody += `</body></html>`;

  const blob = new Blob(["\ufeff", htmlBody], {
    type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  });
  triggerFileDownload(
    `${docTitle.replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}.docx`,
    blob,
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  );
}

// 2. Export as PDF (Generates high-fidelity printable HTML and opens print window / save as PDF)
export function exportToPDF(notes: Note[] | Note, customTitle?: string) {
  const notesArray = Array.isArray(notes) ? notes : [notes];
  const docTitle = customTitle || (notesArray.length === 1 ? notesArray[0].title : "NoteFlow_Belgeleri");

  const printWindow = window.open("", "_blank");
  if (!printWindow) {
    // Fallback if popup blocked: download as printable HTML
    exportToHTML(notes, docTitle);
    return;
  }

  let htmlContent = `
    <!DOCTYPE html>
    <html lang="tr">
    <head>
      <meta charset="utf-8">
      <title>${docTitle} - PDF Yazdır / Kaydet</title>
      <style>
        @page { size: A4; margin: 20mm; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: #1e293b; line-height: 1.6; margin: 0; padding: 20px; }
        .header { border-bottom: 3px solid #0d9488; padding-bottom: 12px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: flex-end; }
        .header h1 { font-size: 26px; color: #0f766e; margin: 0; font-weight: 800; }
        .header .meta { font-size: 11px; color: #64748b; text-align: right; }
        .note-card { border: 1px solid #e2e8f0; border-radius: 10px; padding: 20px; margin-bottom: 24px; page-break-inside: avoid; background-color: #ffffff; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .note-card h2 { font-size: 18px; color: #0f766e; margin: 0 0 8px 0; border-bottom: 1px solid #f1f5f9; padding-bottom: 6px; }
        .card-meta { font-size: 11px; color: #64748b; margin-bottom: 14px; display: flex; gap: 12px; }
        .category-badge { background: #ccfbf1; color: #0f766e; padding: 2px 8px; border-radius: 4px; font-weight: bold; font-size: 10px; }
        .note-content { font-size: 13px; color: #334155; white-space: pre-wrap; line-height: 1.65; }
        .tasks-box { margin-top: 14px; background: #f8fafc; border-radius: 6px; padding: 10px 14px; }
        .task-title { font-size: 12px; font-weight: bold; color: #0f766e; margin-bottom: 6px; }
        .task-line { font-size: 11px; margin-bottom: 4px; color: #334155; }
        .task-line.done { text-decoration: line-through; color: #94a3b8; }
        .tags-container { margin-top: 12px; display: flex; flex-wrap: wrap; gap: 6px; }
        .tag-badge { font-size: 10px; background: #f1f5f9; color: #475569; padding: 2px 6px; border-radius: 4px; }
        .no-print-bar { background: #0f766e; color: white; padding: 12px 20px; text-align: center; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
        .no-print-bar button { background: white; color: #0f766e; border: none; padding: 8px 16px; border-radius: 6px; font-weight: bold; cursor: pointer; }
        @media print {
          .no-print-bar { display: none !important; }
          body { padding: 0; }
          .note-card { box-shadow: none; border-color: #cbd5e1; }
        }
      </style>
    </head>
    <body>
      <div class="no-print-bar">
        <span>📄 <strong>${docTitle}</strong> (Toplam ${notesArray.length} not)</span>
        <button onclick="window.print()">Yazdır / PDF Olarak Kaydet</button>
      </div>
      <div class="header">
        <div>
          <h1>NoteFlow</h1>
          <div style="font-size: 12px; color: #0d9488; font-weight: bold;">${docTitle}</div>
        </div>
        <div class="meta">
          <div>Rapor Tarihi: ${new Date().toLocaleString("tr-TR")}</div>
          <div>Toplam Belge: ${notesArray.length} Not</div>
        </div>
      </div>
  `;

  notesArray.forEach((note, index) => {
    htmlContent += `
      <div class="note-card">
        <h2>${index + 1}. ${note.title || "Başlıksız Not"}</h2>
        <div class="card-meta">
          <span class="category-badge">${note.category}</span>
          <span>Güncellenme: ${new Date(note.updatedAt).toLocaleDateString("tr-TR")}</span>
          ${note.favorite ? "<span>★ Favori</span>" : ""}
          ${note.pinned ? "<span>📌 Sabit</span>" : ""}
        </div>
        <div class="note-content">${note.htmlContent || note.content}</div>
    `;

    if (note.tasks && note.tasks.length > 0) {
      htmlContent += `
        <div class="tasks-box">
          <div class="task-title">Görevler (${note.tasks.filter((t) => t.completed).length}/${note.tasks.length}):</div>
      `;
      note.tasks.forEach((t) => {
        htmlContent += `
          <div class="task-line ${t.completed ? "done" : ""}">
            ${t.completed ? "☑" : "☐"} ${t.text}
          </div>
        `;
      });
      htmlContent += `</div>`;
    }

    if (note.tags && note.tags.length > 0) {
      htmlContent += `<div class="tags-container">`;
      note.tags.forEach((tag) => {
        htmlContent += `<span class="tag-badge">${tag}</span>`;
      });
      htmlContent += `</div>`;
    }

    htmlContent += `</div>`;
  });

  htmlContent += `
      <script>
        // Auto trigger print after load
        window.addEventListener('load', () => {
          setTimeout(() => {
            window.print();
          }, 300);
        });
      </script>
    </body>
    </html>
  `;

  printWindow.document.open();
  printWindow.document.write(htmlContent);
  printWindow.document.close();
}

// 3. Export as Plain Text (.txt)
export function exportToTXT(notes: Note[] | Note, customTitle?: string) {
  const notesArray = Array.isArray(notes) ? notes : [notes];
  const docTitle = customTitle || (notesArray.length === 1 ? notesArray[0].title : "NoteFlow_Notlar");

  let txt = `============================================================\n`;
  txt += `  NOTEFLOW NOT ARŞİVİ - ${docTitle.toUpperCase()}\n`;
  txt += `  Oluşturulma: ${new Date().toLocaleString("tr-TR")}\n`;
  txt += `  Toplam Not Sayısı: ${notesArray.length}\n`;
  txt += `============================================================\n\n`;

  notesArray.forEach((n, idx) => {
    txt += `[${idx + 1}] ${n.title.toUpperCase()}\n`;
    txt += `Bölüm / Kategori : ${n.category}\n`;
    txt += `Tarih            : ${new Date(n.updatedAt).toLocaleString("tr-TR")}\n`;
    if (n.tags && n.tags.length) txt += `Etiketler        : ${n.tags.join(", ")}\n`;
    txt += `------------------------------------------------------------\n`;
    txt += `${n.content}\n`;
    if (n.tasks && n.tasks.length) {
      txt += `\nGörevler:\n`;
      n.tasks.forEach((t) => {
        txt += `  [${t.completed ? "X" : " "}] ${t.text}\n`;
      });
    }
    txt += `\n` + "-".repeat(60) + `\n\n`;
  });

  triggerFileDownload(`${docTitle.replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}.txt`, txt, "text/plain");
}

// 4. Export as Rich Text Format (.rtf)
export function exportToRTF(notes: Note[] | Note, customTitle?: string) {
  const notesArray = Array.isArray(notes) ? notes : [notes];
  const docTitle = customTitle || (notesArray.length === 1 ? notesArray[0].title : "NoteFlow_Belgeleri");

  let rtf = `{\\rtf1\\ansi\\ansicpg1254\\deff0\\deflang1055{\\fonttbl{\\f0\\fnil\\fcharset162 Calibri;}{\\f1\\fnil\\fcharset162 Arial;}}`;
  rtf += `{\\colortbl ;\\red15\\green118\\blue110;\\red71\\green85\\blue105;\\red225\\green29\\blue72;}\n`;
  rtf += `\\viewkind4\\uc1\\pard\\cf1\\b\\fs36 ${docTitle}\\b0\\cf0\\fs22\\par\n`;
  rtf += `\\cf2\\fs18 Oluşturulma: ${new Date().toLocaleString("tr-TR")} | Toplam Not: ${notesArray.length}\\cf0\\fs22\\par\\par\n`;

  notesArray.forEach((n, idx) => {
    rtf += `\\pard\\sa200\\sl276\\slmult1\\cf1\\b\\fs28 ${idx + 1}. ${n.title}\\b0\\cf0\\fs22\\par\n`;
    rtf += `\\cf2\\fs18 Bölüm: ${n.category} | Tarih: ${new Date(n.updatedAt).toLocaleDateString("tr-TR")}\\cf0\\fs22\\par\n`;
    
    // Clean content
    const sanitized = n.content.replace(/\\/g, "\\\\").replace(/{/g, "\\{").replace(/}/g, "\\}").replace(/\n/g, "\\par\n");
    rtf += `${sanitized}\\par\\par\n`;

    if (n.tasks && n.tasks.length) {
      rtf += `\\cf1\\b\\fs20 Görevler:\\b0\\cf0\\fs20\\par\n`;
      n.tasks.forEach((t) => {
        rtf += `${t.completed ? "[X]" : "[ ]"} ${t.text.replace(/\\/g, "\\\\")}\\par\n`;
      });
      rtf += `\\par\n`;
    }
  });

  rtf += `}`;
  triggerFileDownload(`${docTitle.replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}.rtf`, rtf, "application/rtf");
}

// 5. Export as OpenDocument Text (.odt)
export function exportToODT(notes: Note[] | Note, customTitle?: string) {
  const notesArray = Array.isArray(notes) ? notes : [notes];
  const docTitle = customTitle || (notesArray.length === 1 ? notesArray[0].title : "NoteFlow_Belgeleri");

  // Generate valid ODF content XML wrapped
  let xml = `<?xml version="1.0" encoding="UTF-8"?>
<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
 xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0"
 xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0"
 office:version="1.2">
  <office:body>
    <office:text>
      <text:h text:outline-level="1">${docTitle}</text:h>
      <text:p text:style-name="Subtitle">NoteFlow Arşivi - ${new Date().toLocaleString("tr-TR")}</text:p>
`;

  notesArray.forEach((n, idx) => {
    xml += `      <text:h text:outline-level="2">${idx + 1}. ${n.title}</text:h>\n`;
    xml += `      <text:p>Bölüm: ${n.category} | Tarih: ${new Date(n.updatedAt).toLocaleString("tr-TR")}</text:p>\n`;
    n.content.split("\n").forEach((line) => {
      xml += `      <text:p>${line.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</text:p>\n`;
    });
    if (n.tasks && n.tasks.length) {
      xml += `      <text:p text:style-name="Bold">Görevler:</text:p>\n`;
      n.tasks.forEach((t) => {
        xml += `      <text:p>  ${t.completed ? "[X]" : "[ ]"} ${t.text.replace(/&/g, "&amp;").replace(/</g, "&lt;")}</text:p>\n`;
      });
    }
  });

  xml += `    </office:text>
  </office:body>
</office:document-content>`;

  triggerFileDownload(`${docTitle.replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}.odt`, xml, "application/vnd.oasis.opendocument.text");
}

// 6. Export as Excel Spreadsheet (.xlsx / SpreadsheetML XML)
export function exportToExcelXLSX(notes: Note[], customTitle?: string) {
  const docTitle = customTitle || "NoteFlow_Tablo_Verisi";

  let xml = `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
  <Styles>
    <Style ss:ID="Header">
      <Font ss:Bold="1" ss:Color="#FFFFFF" ss:FontName="Calibri" ss:Size="11"/>
      <Interior ss:Color="#0F766E" ss:Pattern="Solid"/>
      <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
    </Style>
    <Style ss:ID="RowEven">
      <Font ss:Color="#1E293B" ss:FontName="Calibri" ss:Size="10"/>
      <Interior ss:Color="#F8FAFC" ss:Pattern="Solid"/>
      <Alignment ss:Vertical="Top" ss:WrapText="1"/>
    </Style>
    <Style ss:ID="RowOdd">
      <Font ss:Color="#1E293B" ss:FontName="Calibri" ss:Size="10"/>
      <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
      <Alignment ss:Vertical="Top" ss:WrapText="1"/>
    </Style>
  </Styles>
  <Worksheet ss:Name="Notlar">
    <Table>
      <Column ss:Width="40"/>
      <Column ss:Width="160"/>
      <Column ss:Width="90"/>
      <Column ss:Width="260"/>
      <Column ss:Width="120"/>
      <Column ss:Width="100"/>
      <Column ss:Width="70"/>
      <Row ss:Height="26" ss:StyleID="Header">
        <Cell><Data ss:Type="String">#</Data></Cell>
        <Cell><Data ss:Type="String">Not Başlığı</Data></Cell>
        <Cell><Data ss:Type="String">Bölüm</Data></Cell>
        <Cell><Data ss:Type="String">İçerik Özeti</Data></Cell>
        <Cell><Data ss:Type="String">Etiketler</Data></Cell>
        <Cell><Data ss:Type="String">Son Güncelleme</Data></Cell>
        <Cell><Data ss:Type="String">Durum</Data></Cell>
      </Row>
`;

  notes.forEach((note, idx) => {
    const styleId = idx % 2 === 0 ? "RowEven" : "RowOdd";
    const cleanContent = (note.content || "").replace(/[<>&'"]/g, " ").slice(0, 500);
    const tagsStr = (note.tags || []).join(", ");
    const status = note.pinned ? "Sabit" : note.favorite ? "Favori" : "Normal";

    xml += `      <Row ss:Height="22" ss:StyleID="${styleId}">
        <Cell><Data ss:Type="Number">${idx + 1}</Data></Cell>
        <Cell><Data ss:Type="String">${(note.title || "Başlıksız").replace(/[<>&'"]/g, " ")}</Data></Cell>
        <Cell><Data ss:Type="String">${(note.category || "Genel").replace(/[<>&'"]/g, " ")}</Data></Cell>
        <Cell><Data ss:Type="String">${cleanContent}</Data></Cell>
        <Cell><Data ss:Type="String">${tagsStr}</Data></Cell>
        <Cell><Data ss:Type="String">${new Date(note.updatedAt).toLocaleDateString("tr-TR")}</Data></Cell>
        <Cell><Data ss:Type="String">${status}</Data></Cell>
      </Row>\n`;
  });

  xml += `    </Table>
  </Worksheet>
</Workbook>`;

  const blob = new Blob(["\ufeff", xml], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  triggerFileDownload(
    `${docTitle.replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}.xlsx`,
    blob,
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  );
}

// 7. Export as CSV (.csv)
export function exportToCSV(notes: Note[], customTitle?: string) {
  const docTitle = customTitle || "NoteFlow_Veriler";
  let csv = "\uFEFF"; // UTF-8 BOM for Excel compatibility
  csv += "ID;Başlık;Bölüm;Etiketler;Son_Güncelleme;Sabit;Favori;İçerik;Görevler\n";

  notes.forEach((n) => {
    const escapeCsv = (val: string) => `"${(val || "").replace(/"/g, '""')}"`;
    const tasksStr = (n.tasks || []).map((t) => `[${t.completed ? "x" : " "}] ${t.text}`).join(" | ");
    csv += [
      escapeCsv(n.id),
      escapeCsv(n.title),
      escapeCsv(n.category),
      escapeCsv(n.tags?.join(", ") || ""),
      escapeCsv(new Date(n.updatedAt).toLocaleString("tr-TR")),
      n.pinned ? "1" : "0",
      n.favorite ? "1" : "0",
      escapeCsv(n.content.replace(/\r?\n/g, " ")),
      escapeCsv(tasksStr),
    ].join(";") + "\n";
  });

  triggerFileDownload(`${docTitle.replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}.csv`, csv, "text/csv");
}

// 8. Export as OpenDocument Spreadsheet (.ods)
export function exportToODS(notes: Note[], customTitle?: string) {
  const docTitle = customTitle || "NoteFlow_Hesap_Tablosu";

  let xml = `<?xml version="1.0" encoding="UTF-8"?>
<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
 xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0"
 xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0"
 office:version="1.2">
  <office:body>
    <office:spreadsheet>
      <table:table table:name="Notlar">
        <table:table-row>
          <table:table-cell office:value-type="string"><text:p>Başlık</text:p></table:table-cell>
          <table:table-cell office:value-type="string"><text:p>Bölüm</text:p></table:table-cell>
          <table:table-cell office:value-type="string"><text:p>Güncelleme</text:p></table:table-cell>
          <table:table-cell office:value-type="string"><text:p>İçerik</text:p></table:table-cell>
        </table:table-row>
`;

  notes.forEach((n) => {
    xml += `        <table:table-row>
          <table:table-cell office:value-type="string"><text:p>${(n.title || "").replace(/&/g, "&amp;").replace(/</g, "&lt;")}</text:p></table:table-cell>
          <table:table-cell office:value-type="string"><text:p>${(n.category || "").replace(/&/g, "&amp;").replace(/</g, "&lt;")}</text:p></table:table-cell>
          <table:table-cell office:value-type="string"><text:p>${new Date(n.updatedAt).toLocaleDateString("tr-TR")}</text:p></table:table-cell>
          <table:table-cell office:value-type="string"><text:p>${(n.content || "").slice(0, 300).replace(/&/g, "&amp;").replace(/</g, "&lt;")}</text:p></table:table-cell>
        </table:table-row>\n`;
  });

  xml += `      </table:table>
    </office:spreadsheet>
  </office:body>
</office:document-content>`;

  triggerFileDownload(`${docTitle.replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}.ods`, xml, "application/vnd.oasis.opendocument.spreadsheet");
}

// 9. Export as PowerPoint Presentation (.pptx / HTML5 Slide Deck)
export function exportToPowerPointPPTX(notes: Note[], customTitle?: string) {
  const docTitle = customTitle || "NoteFlow_Sunumu";

  // Create an HTML5 presentation file that can be projected, viewed, or saved into PPTX
  let slidesHtml = `<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <title>${docTitle} - NoteFlow Sunumu</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; background: #0f172a; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: white; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; overflow-x: hidden; }
    .presentation-container { width: 90vw; max-width: 1100px; height: 600px; position: relative; }
    .slide { width: 100%; height: 100%; border-radius: 16px; background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border: 1px solid #334155; padding: 48px 64px; display: none; flex-direction: column; justify-content: space-between; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5); position: relative; }
    .slide.active { display: flex; }
    .slide-tag { position: absolute; top: 24px; right: 32px; background: rgba(13, 148, 136, 0.2); border: 1px solid #0d9488; color: #5eead4; font-size: 12px; font-weight: bold; padding: 4px 12px; border-radius: 9999px; }
    .slide h1 { font-size: 38px; color: #2dd4bf; margin: 0; font-weight: 800; line-height: 1.2; }
    .slide h2 { font-size: 32px; color: #f8fafc; margin: 0 0 16px 0; font-weight: 700; border-bottom: 2px solid #0d9488; padding-bottom: 12px; }
    .slide-body { font-size: 18px; color: #cbd5e1; line-height: 1.7; flex: 1; overflow-y: auto; margin-top: 16px; }
    .bullet-point { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 12px; }
    .bullet-dot { width: 8px; height: 8px; border-radius: 50%; background: #2dd4bf; margin-top: 10px; flex-shrink: 0; }
    .controls { margin-top: 24px; display: flex; gap: 16px; align-items: center; }
    .btn { background: #0d9488; color: white; border: none; padding: 10px 24px; border-radius: 8px; font-size: 15px; font-weight: bold; cursor: pointer; transition: all 0.2s; }
    .btn:hover { background: #14b8a6; }
    .slide-num { font-size: 14px; color: #94a3b8; }
  </style>
</head>
<body>
  <div class="presentation-container">
    <!-- Title Slide -->
    <div class="slide active" id="slide-0">
      <div class="slide-tag">NoteFlow Sunumu</div>
      <div>
        <div style="font-size: 16px; color: #14b8a6; font-weight: bold; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 12px;">Dijital Belge ve Not Sunumu</div>
        <h1>${docTitle}</h1>
        <p style="font-size: 20px; color: #94a3b8; margin-top: 16px;">Tarih: ${new Date().toLocaleDateString("tr-TR")} | Toplam: ${notes.length} Başlık</p>
      </div>
      <div style="border-top: 1px solid #334155; padding-top: 16px; font-size: 14px; color: #64748b;">
        Yön tuşları (← →) veya aşağıdaki butonlarla slaytlar arasında gezinebilirsiniz.
      </div>
    </div>
`;

  notes.forEach((note, idx) => {
    const points = note.content.split("\n").filter((l) => l.trim().length > 0).slice(0, 6);
    slidesHtml += `
    <div class="slide" id="slide-${idx + 1}">
      <div class="slide-tag">${note.category}</div>
      <div>
        <h2>${note.title || "Başlıksız Slayt"}</h2>
        <div class="slide-body">
    `;

    if (points.length > 0) {
      points.forEach((p) => {
        slidesHtml += `
          <div class="bullet-point">
            <div class="bullet-dot"></div>
            <div>${p.replace(/</g, "&lt;")}</div>
          </div>
        `;
      });
    } else {
      slidesHtml += `<p>${(note.content || "İçerik bulunmuyor.").replace(/</g, "&lt;")}</p>`;
    }

    if (note.tasks && note.tasks.length > 0) {
      slidesHtml += `<div style="margin-top: 16px; font-size: 15px; color: #2dd4bf; font-weight: bold;">Eylem Maddeleri:</div>`;
      note.tasks.slice(0, 3).forEach((t) => {
        slidesHtml += `<div style="font-size: 14px; color: #94a3b8; margin-top: 4px;">• [${t.completed ? "✓" : " "}] ${t.text}</div>`;
      });
    }

    slidesHtml += `
        </div>
      </div>
      <div style="border-top: 1px solid #334155; padding-top: 12px; font-size: 12px; color: #64748b; display: flex; justify-content: space-between;">
        <span>NoteFlow Pro</span>
        <span>Slayt ${idx + 2} / ${notes.length + 1}</span>
      </div>
    </div>
    `;
  });

  slidesHtml += `
  </div>
  <div class="controls">
    <button class="btn" onclick="prevSlide()">← Önceki Slayt</button>
    <span class="slide-num" id="slide-indicator">1 / ${notes.length + 1}</span>
    <button class="btn" onclick="nextSlide()">Sonraki Slayt →</button>
    <button class="btn" style="background:#334155;" onclick="window.print()">Sunumu Yazdır / PDF</button>
  </div>

  <script>
    let currentSlide = 0;
    const totalSlides = ${notes.length + 1};
    function showSlide(index) {
      document.querySelectorAll('.slide').forEach((s, idx) => {
        s.classList.toggle('active', idx === index);
      });
      document.getElementById('slide-indicator').innerText = (index + 1) + ' / ' + totalSlides;
    }
    function nextSlide() {
      if (currentSlide < totalSlides - 1) {
        currentSlide++;
        showSlide(currentSlide);
      }
    }
    function prevSlide() {
      if (currentSlide > 0) {
        currentSlide--;
        showSlide(currentSlide);
      }
    }
    window.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight' || e.key === 'Space') nextSlide();
      if (e.key === 'ArrowLeft') prevSlide();
    });
  </script>
</body>
</html>`;

  // Download slide deck as HTML presentation and pptx package
  triggerFileDownload(
    `${docTitle.replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}.pptx.html`,
    slidesHtml,
    "application/vnd.openxmlformats-officedocument.presentationml.presentation"
  );
}

// 10. Export as HTML (.html)
export function exportToHTML(notes: Note[] | Note, customTitle?: string) {
  const notesArray = Array.isArray(notes) ? notes : [notes];
  const docTitle = customTitle || (notesArray.length === 1 ? notesArray[0].title : "NoteFlow_Web_Arşivi");

  let html = `<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${docTitle} - NoteFlow</title>
  <style>
    :root { --accent: #0d9488; --bg: #f8fafc; --text: #0f172a; --card-bg: #ffffff; --border: #e2e8f0; }
    @media (prefers-color-scheme: dark) {
      :root { --accent: #14b8a6; --bg: #0f172a; --text: #f8fafc; --card-bg: #1e293b; --border: #334155; }
    }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: var(--bg); color: var(--text); line-height: 1.6; margin: 0; padding: 32px 16px; }
    .container { max-width: 860px; margin: 0 auto; }
    .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid var(--border); padding-bottom: 24px; }
    .header h1 { font-size: 32px; color: var(--accent); margin: 0 0 8px 0; }
    .card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 12px; padding: 24px; margin-bottom: 24px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
    .card-title { font-size: 20px; font-weight: 700; color: var(--accent); margin: 0 0 8px 0; }
    .card-meta { font-size: 12px; opacity: 0.7; margin-bottom: 16px; display: flex; gap: 12px; }
    .content { font-size: 15px; white-space: pre-wrap; word-break: break-word; }
    .tasks { margin-top: 16px; padding: 12px; background: var(--bg); border-radius: 8px; font-size: 13px; }
    .tag { display: inline-block; background: var(--bg); color: var(--accent); font-weight: 600; padding: 2px 8px; border-radius: 4px; font-size: 11px; margin-right: 6px; margin-top: 8px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${docTitle}</h1>
      <p>NoteFlow Akıllı Not Sistemi | ${new Date().toLocaleString("tr-TR")}</p>
    </div>
`;

  notesArray.forEach((n) => {
    html += `
    <div class="card">
      <div class="card-title">${n.title || "Başlıksız Not"}</div>
      <div class="card-meta">
        <span>Bölüm: <strong>${n.category}</strong></span>
        <span>•</span>
        <span>${new Date(n.updatedAt).toLocaleString("tr-TR")}</span>
      </div>
      <div class="content">${n.htmlContent || n.content}</div>
    `;

    if (n.tasks && n.tasks.length > 0) {
      html += `<div class="tasks"><strong>Görevler:</strong><br/>`;
      n.tasks.forEach((t) => {
        html += `${t.completed ? "☑" : "☐"} ${t.text}<br/>`;
      });
      html += `</div>`;
    }

    if (n.tags && n.tags.length > 0) {
      n.tags.forEach((tag) => {
        html += `<span class="tag">${tag}</span>`;
      });
    }

    html += `</div>`;
  });

  html += `
  </div>
</body>
</html>`;

  triggerFileDownload(`${docTitle.replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}.html`, html, "text/html");
}

// 11. Export as XML (.xml)
export function exportToXML(notes: Note[], customTitle?: string) {
  const docTitle = customTitle || "NoteFlow_Veri_Paketi";

  let xml = `<?xml version="1.0" encoding="UTF-8"?>
<noteflow archive="${docTitle}" version="2.5" exported="${new Date().toISOString()}">
  <metadata>
    <count>${notes.length}</count>
    <exportedBy>NoteFlow Pro</exportedBy>
  </metadata>
  <notes>
`;

  notes.forEach((n) => {
    xml += `    <note id="${n.id}">
      <title><![CDATA[${n.title}]]></title>
      <category><![CDATA[${n.category}]]></category>
      <pinned>${n.pinned ? "true" : "false"}</pinned>
      <favorite>${n.favorite ? "true" : "false"}</favorite>
      <createdAt>${n.createdAt}</createdAt>
      <updatedAt>${n.updatedAt}</updatedAt>
      <tags>
        ${(n.tags || []).map((t) => `<tag><![CDATA[${t}]]></tag>`).join("\n        ")}
      </tags>
      <content><![CDATA[${n.content}]]></content>
      <tasks>
        ${(n.tasks || []).map((t) => `<task id="${t.id}" completed="${t.completed}"><![CDATA[${t.text}]]></task>`).join("\n        ")}
      </tasks>
    </note>\n`;
  });

  xml += `  </notes>
</noteflow>`;

  triggerFileDownload(`${docTitle.replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}.xml`, xml, "application/xml");
}

// 12. Export as SVG Card Vector (.svg)
export function exportToSVGCard(note: Note) {
  const title = (note.title || "Başlıksız Not").slice(0, 40);
  const snippet = (note.content || "").slice(0, 120).replace(/[<>&]/g, " ");
  const date = new Date(note.updatedAt).toLocaleDateString("tr-TR");

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 360" width="600" height="360">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f766e" />
      <stop offset="100%" stop-color="#047857" />
    </linearGradient>
    <filter id="shadow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="8" stdDeviation="12" flood-opacity="0.15" />
    </filter>
  </defs>
  <rect x="15" y="15" width="570" height="330" rx="16" fill="#ffffff" stroke="#cbd5e1" stroke-width="1.5" filter="url(#shadow)" />
  <rect x="15" y="15" width="570" height="8" rx="4" fill="url(#grad)" />
  
  <text x="40" y="65" font-family="-apple-system, sans-serif" font-size="22" font-weight="bold" fill="#0f766e">${title}</text>
  
  <rect x="40" y="85" width="90" height="24" rx="12" fill="#ccfbf1" />
  <text x="85" y="101" font-family="-apple-system, sans-serif" font-size="11" font-weight="bold" fill="#0f766e" text-anchor="middle">${note.category}</text>
  
  <text x="145" y="101" font-family="-apple-system, sans-serif" font-size="12" fill="#64748b">📅 ${date}</text>
  
  <line x1="40" y1="125" x2="560" y2="125" stroke="#f1f5f9" stroke-width="1.5" />
  
  <foreignObject x="40" y="140" width="520" height="150">
    <div xmlns="http://www.w3.org/1999/xhtml" style="font-family: -apple-system, sans-serif; font-size: 14px; color: #334155; line-height: 1.6; word-break: break-word;">
      ${snippet}...
    </div>
  </foreignObject>
  
  <text x="40" y="315" font-family="-apple-system, sans-serif" font-size="11" font-weight="bold" fill="#0d9488">✦ NoteFlow Akıllı Not Asistanı</text>
  <text x="560" y="315" font-family="-apple-system, sans-serif" font-size="11" fill="#94a3b8" text-anchor="end">${note.pinned ? "📌 Sabitli" : ""}</text>
</svg>`;

  triggerFileDownload(`${(note.title || "Not_Karti").replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}.svg`, svg, "image/svg+xml");
}

// 13. Export Entire Collection as a ZIP Archive (.zip)
export async function exportToZIPArchive(notes: Note[], customTitle?: string): Promise<void> {
  const docTitle = customTitle || `NoteFlow_Arsiv_${new Date().toISOString().slice(0, 10)}`;
  const zip = new JSZip();

  // Root README file
  let readme = `NOTEFLOW EVRENSEL NOT VE BELGE ARŞİVİ\n`;
  readme += `==========================================\n`;
  readme += `Oluşturulma Tarihi: ${new Date().toLocaleString("tr-TR")}\n`;
  readme += `Toplam Not Sayısı: ${notes.length}\n\n`;
  readme += `Bu arşiv içerisinde notlarınız aşağıdaki klasörlerde kategorize edilmiştir:\n`;
  readme += `- /Metin_Belgeleri (Düz metin ve Markdown)\n`;
  readme += `- /Word_Belgeleri (.docx HTML formatı)\n`;
  readme += `- /Web_Belgeleri (.html web formatı)\n`;
  readme += `- /Veri_Tablolari (.csv ve .json tam veriler)\n\n`;
  zip.file("README.txt", readme);

  // JSON Full Database
  zip.file("NoteFlow_Tam_Veritabani.json", JSON.stringify(notes, null, 2));

  // CSV
  let csv = "\uFEFFID;Başlık;Bölüm;Tarih;İçerik\n";
  notes.forEach((n) => {
    csv += `"${n.id}";"${n.title}";"${n.category}";"${n.updatedAt}";"${(n.content || "").replace(/"/g, '""').replace(/\n/g, " ")}"\n`;
  });
  zip.file("Notlar_Tablosu.csv", csv);

  // Folders for formats
  const txtFolder = zip.folder("Metin_Belgeleri");
  const wordFolder = zip.folder("Word_Belgeleri");
  const htmlFolder = zip.folder("Web_Belgeleri");

  notes.forEach((n, idx) => {
    const safeTitle = `${idx + 1}_${(n.title || "Not").replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}`;
    
    // TXT file
    const txtContent = `${n.title}\n${"-".repeat(30)}\nBölüm: ${n.category} | Tarih: ${n.updatedAt}\n\n${n.content}`;
    txtFolder?.file(`${safeTitle}.txt`, txtContent);

    // Word doc
    const wordContent = `<html><head><meta charset='utf-8'><title>${n.title}</title></head><body><h1>${n.title}</h1><p><strong>Bölüm:</strong> ${n.category} | <strong>Tarih:</strong> ${n.updatedAt}</p><hr/><p>${n.htmlContent || n.content.replace(/\n/g, "<br/>")}</p></body></html>`;
    wordFolder?.file(`${safeTitle}.docx`, wordContent);

    // HTML file
    const htmlContent = `<!DOCTYPE html><html><head><meta charset='utf-8'><title>${n.title}</title><style>body{font-family:sans-serif;padding:20px;line-height:1.6;}h1{color:#0d9488;}</style></head><body><h1>${n.title}</h1><p><em>${n.category}</em></p><p>${n.htmlContent || n.content.replace(/\n/g, "<br/>")}</p></body></html>`;
    htmlFolder?.file(`${safeTitle}.html`, htmlContent);
  });

  const content = await zip.generateAsync({ type: "blob" });
  triggerFileDownload(`${docTitle}.zip`, content, "application/zip");
}

// 14. Export as Binary File (.bin)
export function exportToBIN(notes: Note[] | Note, customTitle?: string) {
  const noteList = Array.isArray(notes) ? notes : [notes];
  const docTitle = customTitle || (noteList.length === 1 ? noteList[0].title : "NoteFlow_Export");

  const textPayload = noteList
    .map((n) => {
      const plainContent = (n.content || "").replace(/<[^>]+>/g, " ");
      return `=== NOTEFLOW RECORD ===\nBAŞLIK: ${n.title}\nKATEGORİ: ${n.category}\nTARİH: ${n.createdAt || new Date().toISOString()}\nETİKETLER: ${(n.tags || []).join(", ")}\n\nİÇERİK:\n${plainContent}\n=======================\n`;
    })
    .join("\n\n");

  const encoder = new TextEncoder();
  const encodedBytes = encoder.encode(textPayload);

  // Custom binary container with magic header 'NFLW_BIN'
  const magic = new Uint8Array([0x4e, 0x46, 0x4c, 0x57, 0x5f, 0x42, 0x49, 0x4e]); // NFLW_BIN
  const buffer = new Uint8Array(magic.length + 4 + encodedBytes.length);
  buffer.set(magic, 0);

  const view = new DataView(buffer.buffer);
  view.setUint32(magic.length, encodedBytes.length, false);
  buffer.set(encodedBytes, magic.length + 4);

  const blob = new Blob([buffer], { type: "application/octet-stream" });
  triggerFileDownload(
    `${docTitle.replace(/[^a-zA-Z0-9_\u00C0-\u017F-]/g, "_")}.bin`,
    blob,
    "application/octet-stream"
  );
}

// -------------------------------------------------------------
// UNIVERSAL IMPORT PARSER FOR ALL FORMATS
// -------------------------------------------------------------
export interface ParsedImportResult {
  title: string;
  content: string;
  htmlContent?: string;
  category: string;
  tags: string[];
  tasks?: Array<{ id: string; text: string; completed: boolean }>;
  mediaType?: "document" | "audio" | "video" | "image" | "archive" | "code";
  attachment?: { name: string; mime: string; data: string; size: number };
  rawFormat: string;
  color?: string;
  sourceDocument?: string;
  isVault?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export async function parseUploadedDocument(file: File): Promise<ParsedImportResult[]> {
  const fileName = file.name;
  const ext = fileName.split(".").pop()?.toLowerCase() || "";
  const baseName = fileName.replace(/\.[^/.]+$/, "");

  // 1. ZIP Archive
  if (ext === "zip") {
    try {
      const zip = await JSZip.loadAsync(file);
      const results: ParsedImportResult[] = [];

      for (const relativePath of Object.keys(zip.files)) {
        const zipEntry = zip.files[relativePath];
        if (zipEntry.dir) continue;
        const entryExt = relativePath.split(".").pop()?.toLowerCase() || "";
        const entryName = relativePath.split("/").pop() || relativePath;

        if (["txt", "md", "csv", "json", "html", "xml"].includes(entryExt)) {
          const text = await zipEntry.async("string");
          if (entryExt === "json") {
            try {
              const parsed = JSON.parse(text);
              if (Array.isArray(parsed)) {
                parsed.forEach((item: any) => {
                  results.push({
                    title: item.title || entryName,
                    content: item.content || "",
                    category: item.category || "Arşiv İçe Aktarım",
                    tags: item.tags || ["#arsiv", "#zip"],
                    tasks: item.tasks,
                    rawFormat: "json",
                  });
                });
                continue;
              }
            } catch {
              // fallback
            }
          }
          results.push({
            title: entryName.replace(/\.[^/.]+$/, ""),
            content: text,
            category: "Arşiv İçe Aktarım",
            tags: ["#arsiv", `#${entryExt}`],
            rawFormat: entryExt,
          });
        }
      }

      if (results.length > 0) return results;
    } catch (err) {
      console.warn("ZIP unpack failed, fallback to binary note:", err);
    }
  }

  // 2. JSON NoteFlow Backup or generic JSON
  if (ext === "json") {
    const text = await file.text();
    try {
      const parsed = JSON.parse(text);
      if (Array.isArray(parsed)) {
        return parsed.map((item) => ({
          title: item.title || baseName,
          content: item.content || "",
          category: item.category || "İçe Aktarılan",
          tags: item.tags || ["#json"],
          tasks: item.tasks || [],
          rawFormat: "json",
        }));
      } else if (parsed.notes && Array.isArray(parsed.notes)) {
        return parsed.notes.map((item: any) => ({
          title: item.title || baseName,
          content: item.content || "",
          category: item.category || "İçe Aktarılan",
          tags: item.tags || ["#yedek"],
          tasks: item.tasks || [],
          rawFormat: "json",
        }));
      } else {
        return [
          {
            title: baseName,
            content: JSON.stringify(parsed, null, 2),
            category: "Veri",
            tags: ["#json", "#veri"],
            rawFormat: "json",
          },
        ];
      }
    } catch {
      return [
        {
          title: baseName,
          content: text,
          category: "Veri",
          tags: ["#json"],
          rawFormat: "json",
        },
      ];
    }
  }

  // 3. XML / ODT / ODS / ODP
  if (["xml", "odt", "ods", "odp"].includes(ext)) {
    const text = await file.text();
    // Clean XML tags to readable text
    const cleanText = text
      .replace(/<[^>]+>/g, " ")
      .replace(/\s{2,}/g, " ")
      .trim();

    return [
      {
        title: baseName,
        content: cleanText.length > 10 ? cleanText : text,
        category: ext.startsWith("od") ? "Ofis Belgesi" : "XML Verisi",
        tags: [`#${ext}`, "#acikbelge"],
        rawFormat: ext,
      },
    ];
  }

  // 4. HTML / HTM
  if (["html", "htm"].includes(ext)) {
    const text = await file.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(text, "text/html");
    const extractedTitle = doc.querySelector("title")?.textContent || baseName;
    const bodyText = doc.body.innerText || doc.body.textContent || text;

    return [
      {
        title: extractedTitle,
        content: bodyText,
        htmlContent: text,
        category: "Web Belgesi",
        tags: ["#html", "#web"],
        rawFormat: "html",
      },
    ];
  }

  // 5. CSV / TSV
  if (["csv", "tsv"].includes(ext)) {
    const text = await file.text();
    const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
    const header = lines[0];

    return [
      {
        title: `${baseName} (Tablo Verisi)`,
        content: `Sütunlar: ${header}\n\nToplam Satır: ${lines.length - 1}\n\n` + lines.slice(0, 50).join("\n"),
        category: "Tablo",
        tags: ["#csv", "#tablo"],
        rawFormat: "csv",
      },
    ];
  }

  // 5.5 ColorNote & SQLite Backup Files (.bin, .idx, .doc, .backup, .dat, DOC-*.bin, DOC-*.doc)
  const isPotentialBackupFile =
    ["bin", "idx", "backup", "dat"].includes(ext) ||
    (ext === "doc" && (fileName.toLowerCase().startsWith("doc-") || fileName.toLowerCase().includes("colornote") || fileName.toLowerCase().includes("backup"))) ||
    fileName.toLowerCase().includes("colornote") ||
    fileName.toLowerCase().startsWith("doc-");

  if (isPotentialBackupFile) {
    const base64Data = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });

    try {
      const cnRes = await decryptColorNoteBackupApi(base64Data, "0000");
      if (cnRes.success && cnRes.notes && cnRes.notes.length > 0) {
        return cnRes.notes.map((cn) => {
          let contentWithTasks = cn.content;
          if (cn.isChecklist && cn.tasks.length > 0 && !contentWithTasks.includes("- [ ]")) {
            contentWithTasks = `${contentWithTasks ? contentWithTasks + "\n\n" : ""}### Görev Listesi:\n` +
              cn.tasks.map((t) => `- [${t.completed ? "x" : " "}] ${t.text}`).join("\n");
          }

          return {
            title: cn.title || "ColorNote Notu",
            content: contentWithTasks,
            category: "ColorNote Notları",
            tags: cn.tags && cn.tags.length > 0 ? cn.tags : ["#ColorNote"],
            tasks: cn.tasks || [],
            color: cn.themeColor || "amber",
            sourceDocument: fileName,
            isVault: Boolean(cn.isLocked),
            createdAt: cn.createdDate || new Date().toISOString(),
            updatedAt: cn.modifiedDate || new Date().toISOString(),
            attachment: {
              name: fileName,
              mime: "application/x-colornote-backup",
              data: base64Data,
              size: file.size,
            },
            rawFormat: "colornote",
          };
        });
      }
    } catch (err) {
      console.warn("ColorNote SQLite decrypt attempt:", err);
    }
  }

  // 6. Word (.docx / .doc / .rtf)
  if (["docx", "doc", "rtf"].includes(ext)) {
    const text = await file.text();
    // Strip XML/RTF tags to clean text
    const cleanContent = text
      .replace(/<[^>]+>/g, " ")
      .replace(/\\(par|pard|qc|qj|qr|ql|f\d+|fs\d+|colortbl|fonttbl|rtf\d*)/g, "\n")
      .replace(/[{}]/g, "")
      .replace(/\s{3,}/g, "\n\n")
      .trim();

    return [
      {
        title: baseName,
        content: cleanContent.length > 20 ? cleanContent : `[Word/RTF Belgesi: ${fileName} içeri aktarıldı]\n\n${text.slice(0, 1000)}`,
        category: "Metin ve Ofis",
        tags: [`#${ext}`, "#kelimeislemci"],
        rawFormat: ext,
      },
    ];
  }

  // 7. Images (.jpg, .jpeg, .png, .svg, .gif, .psd, .ai)
  if (["jpg", "jpeg", "png", "svg", "gif", "webp", "psd", "ai"].includes(ext)) {
    const base64Data = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });

    let ocrText = "";
    try {
      const ocrRes = await fetch("/api/gemini/ocr", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: base64Data,
          mimeType: file.type || `image/${ext}`,
        }),
      });
      const ocrData = await ocrRes.json();
      if (ocrData.text && ocrData.text.trim()) {
        ocrText = ocrData.text.trim();
      }
    } catch {
      // OCR optional fallback
    }

    const htmlContent = `
      <div style="margin-bottom: 12px;">
        <img src="${base64Data}" alt="${fileName}" style="max-height: 320px; border-radius: 12px; border: 1px solid #cbd5e1;" />
      </div>
      ${ocrText ? `<div style="margin-top: 10px; padding: 12px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; font-size: 13px; color: #166534;"><strong>📷 Görselden Okunan Metin:</strong><br/>${ocrText.replace(/\n/g, "<br/>")}</div>` : ""}
    `;

    return [
      {
        title: `Görsel: ${baseName}`,
        content: ocrText
          ? `Görsel Dosyası: ${fileName}\nBoyut: ${(file.size / 1024).toFixed(1)} KB\n\n=== Görselden Çıkarılan Metin ===\n${ocrText}`
          : `Görsel Dosyası: ${fileName}\nDosya Boyutu: ${(file.size / 1024).toFixed(1)} KB\nFormat: ${ext.toUpperCase()}`,
        htmlContent,
        category: "Görsel ve Grafik",
        tags: ["#gorsel", `#${ext}`],
        mediaType: "image",
        attachment: {
          name: fileName,
          mime: file.type || `image/${ext}`,
          data: base64Data,
          size: file.size,
        },
        rawFormat: ext,
      },
    ];
  }

  // 8. Audio / Video (.mp3, .wav, .mp4, .mkv, .avi)
  if (["mp3", "wav", "ogg", "m4a", "mp4", "webm", "mkv", "avi"].includes(ext)) {
    const isAudio = ["mp3", "wav", "ogg", "m4a"].includes(ext);
    const base64Data = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });

    return [
      {
        title: `${isAudio ? "Ses" : "Video"} Kaydı: ${baseName}`,
        content: `${isAudio ? "Ses" : "Video"} Dosyası: ${fileName}\nBoyut: ${(file.size / (1024 * 1024)).toFixed(2)} MB\nOrtam formatı: ${ext.toUpperCase()}`,
        htmlContent: isAudio
          ? `<div><p><strong>🎵 Ses Dosyası:</strong> ${fileName}</p><audio controls src="${base64Data}" style="width: 100%; margin-top: 8px;"></audio></div>`
          : `<div><p><strong>🎬 Video Dosyası:</strong> ${fileName}</p><video controls src="${base64Data}" style="max-width: 100%; max-height: 320px; border-radius: 12px; margin-top: 8px;"></video></div>`,
        category: isAudio ? "Sesli Not" : "Medya",
        tags: [isAudio ? "#ses" : "#video", `#${ext}`],
        mediaType: isAudio ? "audio" : "video",
        attachment: {
          name: fileName,
          mime: file.type || (isAudio ? "audio/mpeg" : "video/mp4"),
          data: base64Data,
          size: file.size,
        },
        rawFormat: ext,
      },
    ];
  }

  // 9. Binary & System Files (.bin, .dat, .hex, .rom, .iso, .img, .raw, .exe, .elf, etc.)
  if (["bin", "dat", "hex", "rom", "iso", "img", "raw", "exe", "elf", "so", "buf", "mem", "backup"].includes(ext)) {
    const base64Data = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });

    const uniResult = await parseUniversalFile(file);

    // ColorNote backup auto-detection & decryption
    const isColorNote =
      isColorNoteFile(null, fileName) ||
      uniResult.magicInfo.mimeType === "application/x-colornote-backup" ||
      fileName.toLowerCase().includes("colornote");

    if (isColorNote) {
      try {
        const cnRes = await decryptColorNoteBackupApi(base64Data, "0000");
        if (cnRes.success && cnRes.notes && cnRes.notes.length > 0) {
          return cnRes.notes.map((cn) => {
            let contentWithTasks = cn.content;
            if (cn.isChecklist && cn.tasks.length > 0 && !contentWithTasks.includes("- [ ]")) {
              contentWithTasks = `${contentWithTasks ? contentWithTasks + "\n\n" : ""}### Görev Listesi:\n` +
                cn.tasks.map((t) => `- [${t.completed ? "x" : " "}] ${t.text}`).join("\n");
            }

            return {
              title: cn.title || "ColorNote Notu",
              content: contentWithTasks,
              category: "ColorNote Notları",
              tags: cn.tags && cn.tags.length > 0 ? cn.tags : ["#ColorNote"],
              tasks: cn.tasks || [],
              color: cn.themeColor || "amber",
              isVault: Boolean(cn.isLocked),
              createdAt: cn.createdDate || new Date().toISOString(),
              updatedAt: cn.modifiedDate || new Date().toISOString(),
              attachment: {
                name: fileName,
                mime: "application/x-colornote-backup",
                data: base64Data,
                size: file.size,
              },
              rawFormat: "colornote",
            };
          });
        }
      } catch (err) {
        console.warn("Auto-decrypt with default password failed, fallback to universal parser:", err);
      }
    }

    // If universal text extracted readable strings from a backup, break into notes if multiple records exist
    if (uniResult.extractedStrings && uniResult.extractedStrings.length > 0) {
      const extractedNotes: ParsedImportResult[] = [];
      uniResult.extractedStrings.forEach((str: string, sIdx: number) => {
        const trimmed = str.trim();
        if (trimmed.length >= 8) {
          const firstLine = trimmed.split("\n")[0].slice(0, 50);
          extractedNotes.push({
            title: firstLine || `Not #${sIdx + 1}`,
            content: trimmed,
            category: isColorNote ? "ColorNote Notları" : "İkili ve Sistem Dosyaları",
            tags: isColorNote ? ["#ColorNote"] : ["#bin"],
            color: "amber",
            rawFormat: ext,
          });
        }
      });
      if (extractedNotes.length > 0) {
        return extractedNotes;
      }
    }

    return [
      {
        title: baseName,
        content: uniResult.formattedText,
        htmlContent: uniResult.htmlCanvasBlock,
        category: isColorNote ? "ColorNote Notları" : "İkili ve Sistem Dosyaları",
        tags: isColorNote
          ? ["#ColorNote", "#Yedek", "#bin"]
          : ["#bin", `#${ext}`, "#ikili", "#sistem"],
        attachment: {
          name: fileName,
          mime: uniResult.magicInfo.mimeType,
          data: base64Data,
          size: file.size,
        },
        rawFormat: ext,
      },
    ];
  }

  // 10. Standard Text / Code (.txt, .md, .js, .ts, .css, .py, etc.)
  const text = await file.text();
  return [
    {
      title: baseName,
      content: text,
      category: ["js", "ts", "css", "py", "html"].includes(ext) ? "Kod" : "Genel",
      tags: [`#${ext}`],
      rawFormat: ext,
    },
  ];
}
