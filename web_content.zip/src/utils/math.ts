/**
 * Math utilities for the simple arithmetic calculator
 */

export const urduDigitsMap: Record<string, string> = {
  '0': '۰',
  '1': '۱',
  '2': '۲',
  '3': '۳',
  '4': '۴',
  '5': '۵',
  '6': '۶',
  '7': '۷',
  '8': '۸',
  '9': '۹',
  '.': '٫',
  ',': '٬',
};

export const reverseUrduDigitsMap: Record<string, string> = {
  '۰': '0',
  '۱': '1',
  '۲': '2',
  '۳': '3',
  '۴': '4',
  '۵': '5',
  '۶': '6',
  '۷': '7',
  '۸': '8',
  '۹': '9',
  '٫': '.',
  '٬': ',',
};

export function toUrduNumerals(input: string | number): string {
  const str = String(input);
  return str.replace(/[0-9.,]/g, (match) => urduDigitsMap[match] || match);
}

export function formatNumberWithCommas(numStr: string): string {
  if (!numStr || numStr === 'Error' || numStr === 'خرابی') return numStr;
  
  // Split integer and decimal parts
  const parts = numStr.split('.');
  const integerPart = parts[0];
  const decimalPart = parts.length > 1 ? '.' + parts[1] : '';
  
  // Format integer part
  const formattedInteger = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return formattedInteger + decimalPart;
}

export function formatDisplayValue(val: string, system: 'western' | 'eastern'): string {
  if (!val) return '0';
  if (val === 'Error' || val === 'Infinity' || val === '-Infinity' || val === 'NaN') {
    return system === 'eastern' ? 'حسابی خرابی' : 'Error';
  }

  // Format numbers within expressions
  const formatted = val.replace(/(\d+(?:\.\d+)?)/g, (match) => {
    return formatNumberWithCommas(match);
  });

  if (system === 'eastern') {
    return toUrduNumerals(formatted);
  }
  return formatted;
}

/**
 * Clean floating point inaccuracies (e.g., 0.1 + 0.2 = 0.30000000000000004 -> 0.3)
 */
export function sanitizeFloat(num: number): number {
  if (isNaN(num) || !isFinite(num)) return num;
  return Number(Math.round(Number(num + 'e+12')) + 'e-12');
}

/**
 * Format calculation result to human-readable string
 */
export function formatResult(num: number): string {
  if (isNaN(num)) return 'Error';
  if (!isFinite(num)) return 'Error';
  const clean = sanitizeFloat(num);
  // Cap scientific notation for very large / small numbers, otherwise plain string
  if (Math.abs(clean) > 1e14 || (Math.abs(clean) < 1e-6 && clean !== 0)) {
    return clean.toExponential(6).replace(/\.?0+e/, 'e');
  }
  // Trim trailing floating artifacts
  const str = clean.toString();
  if (str.includes('.')) {
    return parseFloat(clean.toFixed(10)).toString();
  }
  return str;
}

/**
 * Safe tokenized evaluator for basic arithmetic expressions
 * Supports: +, -, × (*), ÷ (/), %, parentheses ( )
 */
export function evaluateExpression(expression: string): { success: boolean; result: string; error?: string } {
  try {
    if (!expression || expression.trim() === '') {
      return { success: true, result: '0' };
    }

    // Replace visual symbols with standard arithmetic operators
    let sanitized = expression
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/−/g, '-')
      .replace(/٫/g, '.')
      .replace(/\s+/g, '');

    // Convert any Eastern digits to Western digits
    for (const [urdu, west] of Object.entries(reverseUrduDigitsMap)) {
      sanitized = sanitized.replaceAll(urdu, west);
    }

    // Handle trailing operators: if user ended with an operator, evaluate up to preceding part
    sanitized = sanitized.replace(/[+\-*/%]+$/, '');

    if (!sanitized) {
      return { success: true, result: '0' };
    }

    // Balance unclosed parentheses
    const openParens = (sanitized.match(/\(/g) || []).length;
    const closeParens = (sanitized.match(/\)/g) || []).length;
    if (openParens > closeParens) {
      sanitized += ')'.repeat(openParens - closeParens);
    }

    // Process percentage: e.g. "200 + 10%" -> "200 + (200 * 0.10)"
    // Or "500 * 20%" -> "500 * 0.20"
    // Regex to match "([number])([+ -])([number])%"
    sanitized = sanitized.replace(/(\d+(?:\.\d+)?)\s*([+\-])\s*(\d+(?:\.\d+)?)%/g, '($1 $2 ($1 * $3 / 100))');
    // Regex for other percentages: "(\d+)%" -> "($1 / 100)"
    sanitized = sanitized.replace(/(\d+(?:\.\d+)?)%/g, '($1 / 100)');

    // Tokenize
    const tokens = tokenize(sanitized);
    if (!tokens || tokens.length === 0) {
      return { success: true, result: '0' };
    }

    const val = parseExpression(tokens);
    if (isNaN(val) || !isFinite(val)) {
      return { success: false, result: 'Error', error: 'Division by zero or invalid input' };
    }

    return { success: true, result: formatResult(val) };
  } catch (err) {
    return { success: false, result: 'Error', error: String(err) };
  }
}

// Simple recursive descent parser for basic math (+, -, *, /, parens)
function tokenize(str: string): string[] {
  const regex = /\d+(?:\.\d+)?|[+\-*/()]|%/g;
  const matches = str.match(regex);
  return matches || [];
}

function parseExpression(tokens: string[]): number {
  let index = 0;

  function peek(): string | undefined {
    return tokens[index];
  }

  function consume(): string {
    return tokens[index++];
  }

  // Expression = Term (('+' | '-') Term)*
  function parseAdditionSubtraction(): number {
    let result = parseMultiplicationDivision();
    while (peek() === '+' || peek() === '-') {
      const op = consume();
      const right = parseMultiplicationDivision();
      if (op === '+') result += right;
      else result -= right;
    }
    return result;
  }

  // Term = Factor (('*' | '/') Factor)*
  function parseMultiplicationDivision(): number {
    let result = parseFactor();
    while (peek() === '*' || peek() === '/') {
      const op = consume();
      const right = parseFactor();
      if (op === '*') {
        result *= right;
      } else {
        if (right === 0) {
          throw new Error('Division by zero');
        }
        result /= right;
      }
    }
    return result;
  }

  // Factor = Primary | '-' Factor | '+' Factor
  function parseFactor(): number {
    if (peek() === '-') {
      consume();
      return -parseFactor();
    }
    if (peek() === '+') {
      consume();
      return parseFactor();
    }
    return parsePrimary();
  }

  // Primary = Number | '(' Expression ')'
  function parsePrimary(): number {
    const token = peek();
    if (!token) throw new Error('Unexpected end of expression');

    if (token === '(') {
      consume(); // consume '('
      const val = parseAdditionSubtraction();
      if (peek() === ')') {
        consume(); // consume ')'
      }
      return val;
    }

    // Number
    const num = parseFloat(consume());
    if (isNaN(num)) throw new Error('Invalid number: ' + token);
    return num;
  }

  return parseAdditionSubtraction();
}
