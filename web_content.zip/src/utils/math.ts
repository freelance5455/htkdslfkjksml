/** تفكيك النص إلى مقاطع نصية ومقاطع رياضية لعرضها بـ KaTeX */
export interface MathToken {
  type: 'text' | 'inline' | 'block';
  value: string;
}

const DELIMITERS: Array<{ open: string; close: string; type: MathToken['type'] }> = [
  { open: '$$', close: '$$', type: 'block' },
  { open: '\\[', close: '\\]', type: 'block' },
  { open: '\\(', close: '\\)', type: 'inline' },
  { open: '$', close: '$', type: 'inline' },
];

/**
 * يقسّم نصاً قد يحتوي معادلات إلى مقاطع.
 * يُجرّب الفواصل الأطول أولاً حتى لا تُفسَّر $$ كـ $.
 */
export function tokenizeMath(text: string): MathToken[] {
  const tokens: MathToken[] = [];
  let rest = text;

  while (rest.length > 0) {
    let earliest: { index: number; open: string; close: string; type: MathToken['type'] } | null = null;

    for (const d of DELIMITERS) {
      // نتجاهل $ المفردة إذا كانت جزءاً من $$
      const index = rest.indexOf(d.open);
      if (index < 0) continue;
      if (d.open === '$' && rest[index + 1] === '$') continue;
      if (earliest === null || index < earliest.index) {
        earliest = { index, open: d.open, close: d.close, type: d.type };
      }
    }

    if (!earliest) {
      tokens.push({ type: 'text', value: rest });
      break;
    }

    const before = rest.slice(0, earliest.index);
    if (before) tokens.push({ type: 'text', value: before });

    const afterOpen = rest.slice(earliest.index + earliest.open.length);
    const closeIndex = afterOpen.indexOf(earliest.close);
    if (closeIndex < 0) {
      tokens.push({ type: 'text', value: rest.slice(earliest.index) });
      break;
    }
    tokens.push({ type: earliest.type, value: afterOpen.slice(0, closeIndex) });
    rest = afterOpen.slice(closeIndex + earliest.close.length);
  }

  return tokens;
}
