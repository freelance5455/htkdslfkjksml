/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  detectClimate,
  generatePackingList,
  calculatePackingProgress,
  toggleItemPacked,
  filterPackingItems,
  addCustomPackingItem,
  deletePackingItem,
  savePackingPlan,
  loadSavedPackingPlan,
  PackingPlan,
} from './packing.ts';

class MockStorage implements Storage {
  private store: Map<string, string> = new Map();

  get length(): number {
    return this.store.size;
  }
  clear(): void {
    this.store.clear();
  }
  getItem(key: string): string | null {
    return this.store.get(key) ?? null;
  }
  key(index: number): string | null {
    const keys = Array.from(this.store.keys());
    return keys[index] ?? null;
  }
  removeItem(key: string): void {
    this.store.delete(key);
  }
  setItem(key: string, value: string): void {
    this.store.set(key, String(value));
  }
}

describe('Smart Packing Utility', () => {
  it('detects climates based on destination name keywords', () => {
    assert.equal(detectClimate('Dubai UAE'), 'hot');
    assert.equal(detectClimate('الرياض'), 'hot');
    assert.equal(detectClimate('Istanbul Turkey'), 'temperate');
    assert.equal(detectClimate('باريس'), 'temperate');
    assert.equal(detectClimate('Moscow Russia'), 'cold');
    assert.equal(detectClimate('سويسرا'), 'cold');
    assert.equal(detectClimate('Kuala Lumpur'), 'tropical');
    assert.equal(detectClimate('المالديف'), 'tropical');
  });

  it('generates customized items categorized into clothing, electronics, documents, etc.', () => {
    const items = generatePackingList('Istanbul', 7, 'leisure');
    assert.ok(items.length >= 10);

    const categories = new Set(items.map((i) => i.category));
    assert.ok(categories.has('clothing'));
    assert.ok(categories.has('electronics'));
    assert.ok(categories.has('documents'));
    assert.ok(categories.has('toiletries'));
    assert.ok(categories.has('essentials'));

    // Check that passport and flight documents are in carry-on
    const passportItem = items.find((i) => i.name.includes('جواز السفر'));
    assert.ok(passportItem);
    assert.equal(passportItem?.category, 'documents');
    assert.equal(passportItem?.baggageType, 'carry_on');
    assert.equal(passportItem?.isEssential, true);

    // Check power bank is strictly carry-on
    const powerBank = items.find((i) => i.category === 'electronics' && i.name.includes('طاقة'));
    assert.ok(powerBank);
    assert.equal(powerBank?.baggageType, 'carry_on');
  });

  it('adapts quantities according to trip duration', () => {
    const shortTrip = generatePackingList('Paris', 3);
    const longTrip = generatePackingList('Paris', 14);

    const shortTshirts = shortTrip.find((i) => i.name.includes('قمصان'));
    const longTshirts = longTrip.find((i) => i.name.includes('قمصان'));

    assert.ok(shortTshirts && longTshirts);
    assert.ok(longTshirts.quantity > shortTshirts.quantity);
  });

  it('includes specialized gear for religious/Umrah trips', () => {
    const umrahItems = generatePackingList('Makkah', 10, 'religious');
    const ihram = umrahItems.find((i) => i.name.includes('الإحرام'));
    const permit = umrahItems.find((i) => i.name.includes('نسك'));

    assert.ok(ihram);
    assert.ok(permit);
    assert.equal(permit?.category, 'documents');
    assert.equal(ihram?.category, 'clothing');
  });

  it('calculates packing progress accurately', () => {
    const items = generatePackingList('Algiers', 4);
    const initialProgress = calculatePackingProgress(items);
    assert.equal(initialProgress.total, items.length);
    assert.equal(initialProgress.packed, 0);
    assert.equal(initialProgress.percentage, 0);
    assert.equal(initialProgress.isComplete, false);

    // Toggle first 2 items
    const toggledOnce = toggleItemPacked(items, items[0].id);
    const toggledTwice = toggleItemPacked(toggledOnce, items[1].id);

    const progress = calculatePackingProgress(toggledTwice);
    assert.equal(progress.packed, 2);
    assert.equal(progress.percentage, Math.round((2 / items.length) * 100));
    assert.equal(progress.isComplete, false);
  });

  it('filters items correctly by category, status, and baggage type', () => {
    const items = generatePackingList('Istanbul', 5);
    const clothingOnly = filterPackingItems(items, { category: 'clothing' });
    assert.ok(clothingOnly.every((i) => i.category === 'clothing'));

    const carryOnOnly = filterPackingItems(items, { baggageType: 'carry_on' });
    assert.ok(carryOnOnly.every((i) => i.baggageType === 'carry_on'));
  });

  it('allows adding and removing custom items', () => {
    const items = generatePackingList('Dubai', 5);
    const withCustom = addCustomPackingItem(items, {
      name: 'كتاب القراءة المفضل',
      category: 'essentials',
      quantity: 1,
      baggageType: 'carry_on',
    });

    assert.equal(withCustom.length, items.length + 1);
    assert.equal(withCustom[0].name, 'كتاب القراءة المفضل');
    assert.equal(withCustom[0].category, 'essentials');

    const removed = deletePackingItem(withCustom, withCustom[0].id);
    assert.equal(removed.length, items.length);
  });

  it('persists and loads packing plans from storage', () => {
    const mockStorage = new MockStorage();
    const plan: PackingPlan = {
      id: 'plan-123',
      destination: 'Istanbul',
      durationDays: 7,
      purpose: 'leisure',
      climate: 'temperate',
      items: generatePackingList('Istanbul', 7),
      updatedAt: new Date().toISOString(),
    };

    savePackingPlan(plan, mockStorage);
    const loaded = loadSavedPackingPlan('Istanbul', mockStorage);
    assert.ok(loaded);
    assert.equal(loaded?.destination, 'Istanbul');
    assert.equal(loaded?.durationDays, 7);
    assert.equal(loaded?.items.length, plan.items.length);
  });
});
