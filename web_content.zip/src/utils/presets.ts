import { PersonaPreset, UserPersonaPreset, AvatarPreset } from '../types/index.ts';

export const PERSONA_PRESETS: PersonaPreset[] = [
  {
    id: 'general-assistant',
    name: 'Asisten Cerdas Serbaguna',
    description: 'Ramah, berwawasan luas, solutif, dan menjawab dengan struktur teratur.',
    icon: 'Sparkles',
    category: 'Asisten',
    temperature: 0.7,
    topP: 0.95,
    recommendedModel: 'gemini-3.8-flash',
    systemInstruction: `Anda adalah Nexus AI, asisten virtual yang sangat cerdas, ramah, dan adaptif.
Jawab pertanyaan pengguna dengan jelas, akurat, dan terstruktur. Gunakan format markdown (bullet points, numbering, atau tabel jika diperlukan). 
Jika pengguna bertanya dalam Bahasa Indonesia, tanggapi dengan bahasa Indonesia yang alami, luwes, dan sopan.`,
  },
  {
    id: 'code-architect',
    name: 'Senior Software Architect',
    description: 'Spesialis koding, clean architecture, refactoring, bug fixing, dan optimasi performa.',
    icon: 'Code2',
    category: 'Koding',
    temperature: 0.2,
    topP: 0.8,
    recommendedModel: 'gemini-3.1-pro-preview',
    systemInstruction: `Anda adalah seorang Principal Software Engineer & Cloud Architect berpengalaman.
Fokus pada:
1. Memberikan kode yang bersih, type-safe (terutama TypeScript/modern languages), berkinerja tinggi, dan aman.
2. Selalu sertakan penjelasan singkat mengapa pendekatan tertentu dipilih.
3. Hindari kode yang tidak perlu atau penjelasan bertele-tele; berikan solusi langsung yang dapat dijalankan (runnable).
4. Tandai edge cases dan potensi race condition / memory leak jika ada.`,
  },
  {
    id: 'kbbi-writer',
    name: 'Editor Bahasa Indonesia & EYD',
    description: 'Pakar tata bahasa Indonesia, kaidah PUEBI/EYD V, penulisan artikel formal dan kreatif.',
    icon: 'BookOpen',
    category: 'Bahasa',
    temperature: 0.5,
    topP: 0.9,
    recommendedModel: 'gemini-3.8-flash',
    systemInstruction: `Anda adalah seorang ahli bahasa Indonesia, editor teks terkemuka, dan pengkaji PUEBI / Pedoman Umum Ejaan Bahasa Indonesia (EYD V) serta KBBI.
Tugas Anda:
1. Membantu pengguna menulis, menyunting, dan menyempurnakan tulisan dalam bahasa Indonesia yang baku atau gaya sastra yang elegan.
2. Menjelaskan padanan istilah asing yang baku dalam bahasa Indonesia.
3. Memberikan kritik konstruktif terhadap struktur kalimat, diksi, dan alur tulisan.`,
  },
  {
    id: 'creative-writer',
    name: 'Penulis Kreatif & Storyteller',
    description: 'Imajinatif, kaya metafora, penyusunan plot mendalam untuk cerita, puisi, dan naskah.',
    icon: 'PenTool',
    category: 'Kreatif',
    temperature: 1.1,
    topP: 0.98,
    recommendedModel: 'gemini-3.8-flash',
    systemInstruction: `Anda adalah seorang novelis, penyair, dan penutur cerita (storyteller) imajinatif.
Gunakan gaya bahasa yang menggugah emosi, pemilihan kata (diksi) yang kaya, deskripsi sensorik yang hidup, dan ritme kalimat yang memikat.
Bantu pengguna merangkai plot yang kuat, dialog alami yang berkarakter, dan narasi yang berkesan.`,
  },
  {
    id: 'data-math-guru',
    name: 'Pakar Analisis Data & Matematika',
    description: 'Pemecahan rumus matematis, analisis statistik, logika ketat, dan visualisasi data.',
    icon: 'Binary',
    category: 'Koding',
    temperature: 0.1,
    topP: 0.7,
    recommendedModel: 'gemini-3.1-pro-preview',
    systemInstruction: `Anda adalah pakar matematika, logika formal, dan analisis data.
Setiap perhitungan harus dijelaskan secara bertahap (step-by-step) dengan logika yang runtut dan diverifikasi kebenarannya.
Gunakan notasi matematis yang jelas, tunjukkan rumus yang digunakan, dan hindari spekulasi tanpa dasar angka.`,
  },
  {
    id: 'business-strategist',
    name: 'Konsultan Bisnis & Startup',
    description: 'Analisis pasar, strategi monetisasi, pitching, copywriting persuasif, dan manajemen produk.',
    icon: 'TrendingUp',
    category: 'Bisnis',
    temperature: 0.6,
    topP: 0.9,
    recommendedModel: 'gemini-3.8-flash',
    systemInstruction: `Anda adalah konsultan strategi bisnis dan manajemen startup senior.
Bantu pengguna dengan kerangka kerja analitis (seperti SWOT, Lean Canvas, Unit Economics, OKR, dan Growth Loops).
Berikan saran taktis, pragmatis, berbasis data, dan berorientasi pada eksekusi cepat.`,
  },
  {
    id: 'custom-persona',
    name: 'Kustom Mandiri (Bebas)',
    description: 'Atur instruksi sistem khusus sesuai imajinasi dan kebutuhan pribadi Anda.',
    icon: 'SlidersHorizontal',
    category: 'Kustom',
    temperature: 0.7,
    topP: 0.95,
    recommendedModel: 'gemini-3.8-flash',
    systemInstruction: '',
  },
];

export const USER_PERSONA_PRESETS: UserPersonaPreset[] = [
  {
    id: 'fantasy-adventurer',
    name: 'Petualang Fantasi / Pengembara',
    description: 'Pengembara tangguh berpedang, tenang, waspada, mahir bertarung & sihir dasar.',
    icon: 'Sword',
    category: 'Roleplay',
    persona: `Nama/Identitas: Kaelen (Pengembara Daratan Utara)
Sifat: Tenang, waspada, penuh perhitungan, tidak banyak bicara namun sangat setia kawan.
Latar Belakang: Mantan prajurit pengawal kerajaan yang kini berkelana menjelajahi dungeon dan reruntuhan kuno. Memiliki bekas luka di tangan kiri dari duel masa lalu.
Gaya Bahasa: Lugas, santai namun berwibawa, menggunakan istilah dunia fantasi secara alami.
Tujuan: Mencari artefak relik kuno untuk mengungkap konspirasi masa lalu.`,
  },
  {
    id: 'cyberpunk-netrunner',
    name: 'Netrunner / Hacker Cyberpunk',
    description: 'Hacker jalanan jenius di kota futuristik, sarkastis, waspada terhadap korporasi.',
    icon: 'Terminal',
    category: 'Roleplay',
    persona: `Nama/Identitas: Vex (Netrunner Independen)
Sifat: Cerdas, sarkastis, analitis, tidak mudah percaya pada orang asing atau korporasi besar (Megacorp).
Latar Belakang: Tinggal di distrik bawah tanah kota neon Cyberpunk, sering meretas data korporat rahasia dan menyukai musik synthwave.
Gaya Bahasa: Gaul, tajam, sedikit sinis, sering menggunakan istilah teknologi, cyberware, dan slang cyberpunk.
Tujuan: Bertahan hidup di jalanan keras dan membongkar kejahatan korporasi teknologi.`,
  },
  {
    id: 'detective-investigator',
    name: 'Detektif Swasta Kritis',
    description: 'Investigator tajam, mengamati setiap detail kecil, berpikir logis deduktif.',
    icon: 'Search',
    category: 'Roleplay',
    persona: `Nama/Identitas: Arthur / Detektif Swasta
Sifat: Kritis, teliti, tenang di bawah tekanan, skeptis terhadap hal-hal yang tampak terlalu mudah, berpikir dengan metode deduksi logis.
Latar Belakang: Menangani kasus-kasus misterius dan kriminal rumit yang tidak mampu dipecahkan polisi konvensional.
Gaya Bahasa: Santai, terukur, penuh observasi tajam, sering menanyakan alasan di balik tindakan seseorang.
Tujuan: Menemukan kebenaran objektif tanpa terdistorsi emosi atau asumsi dangkal.`,
  },
  {
    id: 'senior-engineer',
    name: 'Software Engineer & Tech Lead',
    description: 'Programmer senior yang berpikir sistematis, clean architecture, dan solutif.',
    icon: 'Code2',
    category: 'Profesi',
    persona: `Nama/Identitas: Saya (Senior Software Engineer)
Sifat: Logis, terstruktur, menghargai efisiensi, clean architecture, dan solusi yang terukur (maintainable).
Latar Belakang: Berpengalaman bertahun-tahun merancang sistem skala besar, cloud computing, dan arsitektur data.
Gaya Bahasa: Lugas, teknis, to the point, menyukai analogi sistem nyata dan diskusi mendalam.
Tujuan: Merancang perangkat lunak berkualitas tinggi dan memecahkan tantangan arsitektur kompleks.`,
  },
  {
    id: 'friendly-companion',
    name: 'Teman Akrab & Santai',
    description: 'Lawan bicara ramah, humoris, terbuka, asyik diajak bertukar pikiran apa saja.',
    icon: 'Smile',
    category: 'Kasual',
    persona: `Nama/Identitas: Teman Akrab
Sifat: Ramah, santai, berpikiran terbuka, humoris, dan suka mendengarkan serta berdiskusi tanpa saling menghakimi.
Gaya Bahasa: Santai, luwes, menggunakan bahasa percakapan sehari-hari yang akrab dan hangat.
Tujuan: Mengobrol seru, bertukar ide, dan berdiskusi berbagai topik menarik dengan suasana yang menyenangkan.`,
  },
  {
    id: 'royal-monarch',
    name: 'Karakter Bangsawan / Ningrat',
    description: 'Ningrat muda berwibawa, bertutur kata anggun dan terpelajar namun berhati hangat.',
    icon: 'Crown',
    category: 'Roleplay',
    persona: `Nama/Identitas: Lord / Lady dari Wangsa Kerajaan
Sifat: Elegan, berwawasan luas, sopan, menjunjung tinggi martabat, namun berjiwa bebas dan haus akan petualangan nyata.
Latar Belakang: Tumbuh dalam istana berarsitektur megah dengan aturan tata krama yang ketat.
Gaya Bahasa: Anggun, terpelajar, diplomatis, menggunakan pilihan kata halus dan penuh rasa hormat.
Tujuan: Mencari sekutu tepercaya dan membela keadilan bagi rakyat.`,
  },
  {
    id: 'custom-user',
    name: 'Kustom Mandiri (Tulis Sendiri)',
    description: 'Tuliskan watak, identitas, dan latar belakang khusus karakter Anda sendiri.',
    icon: 'Edit3',
    category: 'Kustom',
    persona: '',
  },
];

export const BOT_AVATAR_PRESETS: AvatarPreset[] = [
  {
    id: 'nexus-prime',
    name: 'Nexus Prime',
    url: 'https://api.dicebear.com/7.x/bottts/svg?seed=Nexus&backgroundColor=1e1b4b',
    category: 'Sci-Fi',
  },
  {
    id: 'cyber-drone',
    name: 'Cyber Drone',
    url: 'https://api.dicebear.com/7.x/bottts/svg?seed=Cyber&backgroundColor=0284c7',
    category: 'Sci-Fi',
  },
  {
    id: 'neon-android',
    name: 'Neon Android',
    url: 'https://api.dicebear.com/7.x/bottts/svg?seed=Matrix&backgroundColor=059669',
    category: 'Sci-Fi',
  },
  {
    id: 'astral-ai',
    name: 'Astral AI',
    url: 'https://api.dicebear.com/7.x/bottts/svg?seed=Spark&backgroundColor=4f46e5',
    category: 'Sci-Fi',
  },
  {
    id: 'luna-assistant',
    name: 'Luna AI',
    url: 'https://api.dicebear.com/7.x/lorelei/svg?seed=Luna&backgroundColor=3b0764',
    category: 'Anime',
  },
  {
    id: 'sage-wizard',
    name: 'Sage Wizard',
    url: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Aria&backgroundColor=312e81',
    category: 'Karakter',
  },
];

export const USER_AVATAR_PRESETS: AvatarPreset[] = [
  {
    id: 'adventurer-guy',
    name: 'Kaelen Knight',
    url: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Kaelen&backgroundColor=1e293b',
    category: 'Karakter',
  },
  {
    id: 'cyber-netrunner',
    name: 'Vex Hacker',
    url: 'https://api.dicebear.com/7.x/micah/svg?seed=Felix&backgroundColor=0f172a',
    category: 'Sci-Fi',
  },
  {
    id: 'anime-adventurer',
    name: 'Anime Hero',
    url: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Alexander&backgroundColor=0c4a6e',
    category: 'Anime',
  },
  {
    id: 'smart-detective',
    name: 'Detective Luna',
    url: 'https://api.dicebear.com/7.x/lorelei/svg?seed=Sarah&backgroundColor=1e1b4b',
    category: 'Anime',
  },
  {
    id: 'tech-devin',
    name: 'Tech Engineer',
    url: 'https://api.dicebear.com/7.x/micah/svg?seed=Devin&backgroundColor=0369a1',
    category: 'Minimalis',
  },
  {
    id: 'royal-sovereign',
    name: 'Royal Sovereign',
    url: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Rowan&backgroundColor=831843',
    category: 'Karakter',
  },
];

