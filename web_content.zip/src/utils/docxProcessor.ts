import mammoth from 'mammoth';
import { parseRawTextToSections, generateDocxBlob, generatePdfBlob, DEFAULT_STYLE_SETTINGS } from './documentEngine';
import { DocumentSection } from '../types';

export interface DocxRenderedPage {
  pageNumber: number;
  dataUrl: string;
  width: number;
  height: number;
  blob?: Blob;
}

// Extract raw text and HTML from a DOCX file
export async function parseDocxFile(file: File | ArrayBuffer): Promise<{
  text: string;
  html: string;
  sections: DocumentSection[];
}> {
  const arrayBuffer = file instanceof File ? await file.arrayBuffer() : file;

  const textResult = await mammoth.extractRawText({ arrayBuffer });
  const htmlResult = await mammoth.convertToHtml({ arrayBuffer });

  const rawText = textResult.value.trim();
  const html = htmlResult.value;

  const sections = parseRawTextToSections(rawText);

  return {
    text: rawText,
    html,
    sections
  };
}

// Convert DOCX into rendered page images by layout rendering on Canvas
export async function convertDocxToImages(
  file: File | ArrayBuffer,
  options: {
    scale?: number; // 1.0 (72 dpi), 2.0 (150 dpi), 3.0 (300 dpi)
    format?: 'image/png' | 'image/jpeg';
    quality?: number;
    pageSize?: 'A4' | 'Letter';
  } = {}
): Promise<DocxRenderedPage[]> {
  const { text, sections } = await parseDocxFile(file);
  const scale = options.scale || 2.0;
  const format = options.format || 'image/png';
  const quality = options.quality || 0.95;

  // A4 dimensions at 72dpi: 595 x 842. Scaled:
  const baseW = options.pageSize === 'Letter' ? 612 : 595;
  const baseH = options.pageSize === 'Letter' ? 792 : 842;
  const width = Math.round(baseW * scale);
  const height = Math.round(baseH * scale);

  // Pagination simulation across canvas pages
  const pages: DocxRenderedPage[] = [];
  const marginX = 54 * scale;
  const marginY = 54 * scale;
  const contentW = width - (marginX * 2);

  let currentPageCanvas = document.createElement('canvas');
  currentPageCanvas.width = width;
  currentPageCanvas.height = height;
  let ctx = currentPageCanvas.getContext('2d')!;

  const initPage = (canvas: HTMLCanvasElement, context: CanvasRenderingContext2D) => {
    context.fillStyle = '#FFFFFF';
    context.fillRect(0, 0, width, height);
  };

  initPage(currentPageCanvas, ctx);

  let curY = marginY + (20 * scale);

  const checkOverflow = (blockH: number) => {
    if (curY + blockH > height - marginY) {
      // Finalize current page
      pages.push({
        pageNumber: pages.length + 1,
        dataUrl: currentPageCanvas.toDataURL(format, quality),
        width,
        height
      });

      // Start new page
      currentPageCanvas = document.createElement('canvas');
      currentPageCanvas.width = width;
      currentPageCanvas.height = height;
      ctx = currentPageCanvas.getContext('2d')!;
      initPage(currentPageCanvas, ctx);
      curY = marginY + (20 * scale);
      return true;
    }
    return false;
  };

  // Helper text wrap for Canvas
  const renderWrappedText = (
    textLine: string,
    fontStr: string,
    fontSizePt: number,
    color: string,
    lineHeightMult: number = 1.25,
    indentX: number = 0
  ) => {
    ctx.font = fontStr;
    ctx.fillStyle = color;
    const words = textLine.split(' ');
    let line = '';
    const lineHeightPx = fontSizePt * scale * lineHeightMult;

    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = ctx.measureText(testLine);
      if (metrics.width > contentW - indentX && n > 0) {
        checkOverflow(lineHeightPx);
        ctx.font = fontStr;
        ctx.fillStyle = color;
        ctx.fillText(line, marginX + indentX, curY);
        line = words[n] + ' ';
        curY += lineHeightPx;
      } else {
        line = testLine;
      }
    }
    if (line.trim()) {
      checkOverflow(lineHeightPx);
      ctx.font = fontStr;
      ctx.fillStyle = color;
      ctx.fillText(line, marginX + indentX, curY);
      curY += lineHeightPx;
    }
  };

  for (const section of sections) {
    switch (section.type) {
      case 'heading': {
        curY += 12 * scale;
        renderWrappedText(
          section.content,
          `bold ${Math.round(18 * scale)}px 'Arial', sans-serif`,
          18,
          '#1E293B',
          1.2
        );
        curY += 8 * scale;
        break;
      }

      case 'subheading': {
        curY += 8 * scale;
        renderWrappedText(
          section.content,
          `bold ${Math.round(14 * scale)}px 'Arial', sans-serif`,
          14,
          '#334155',
          1.2
        );
        curY += 6 * scale;
        break;
      }

      case 'bullet_list': {
        const items = section.content.split('\n').filter(Boolean);
        for (const item of items) {
          const clean = item.replace(/^[-*•]\s*/, '');
          ctx.fillStyle = '#2563EB';
          ctx.beginPath();
          ctx.arc(marginX + (6 * scale), curY - (4 * scale), 2.5 * scale, 0, Math.PI * 2);
          ctx.fill();

          renderWrappedText(
            clean,
            `${Math.round(11 * scale)}px 'Arial', sans-serif`,
            11,
            '#1F2937',
            1.3,
            16 * scale
          );
          curY += 4 * scale;
        }
        break;
      }

      case 'table': {
        const rows = section.content.split('\n').filter(Boolean);
        const colCount = Math.max(...rows.map(r => r.split('|').length));
        const colW = contentW / Math.max(1, colCount);
        const rowH = 26 * scale;

        for (let r = 0; r < rows.length; r++) {
          checkOverflow(rowH);
          const isHeader = r === 0;
          const cells = rows[r].split('|').map(c => c.trim());

          if (isHeader) {
            ctx.fillStyle = '#F1F5F9';
            ctx.fillRect(marginX, curY - (14 * scale), contentW, rowH);
          }

          ctx.strokeStyle = '#E2E8F0';
          ctx.lineWidth = 1 * scale;
          ctx.strokeRect(marginX, curY - (14 * scale), contentW, rowH);

          cells.forEach((cell, cIdx) => {
            ctx.font = isHeader ? `bold ${Math.round(10.5 * scale)}px Arial` : `${Math.round(10.5 * scale)}px Arial`;
            ctx.fillStyle = isHeader ? '#0F172A' : '#334155';
            ctx.fillText(cell.slice(0, 32), marginX + (cIdx * colW) + (8 * scale), curY + (3 * scale));
          });
          curY += rowH;
        }
        curY += 10 * scale;
        break;
      }

      case 'paragraph':
      default: {
        const pLines = section.content.split('\n').filter(Boolean);
        for (const pl of pLines) {
          renderWrappedText(
            pl,
            `${Math.round(11 * scale)}px 'Arial', sans-serif`,
            11,
            '#1F2937',
            1.35
          );
          curY += 8 * scale;
        }
        break;
      }
    }
  }

  // Final page flush
  pages.push({
    pageNumber: pages.length + 1,
    dataUrl: currentPageCanvas.toDataURL(format, quality),
    width,
    height
  });

  return pages;
}

// Merge multiple DOCX files into a unified DOCX or PDF blob
export async function mergeDocxFiles(
  files: File[],
  outputFormat: 'docx' | 'pdf' = 'docx'
): Promise<Blob> {
  const mergedSections: DocumentSection[] = [];

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const parsed = await parseDocxFile(file);

    // Add separator or header
    if (i > 0) {
      mergedSections.push({
        id: 'break-' + i,
        type: 'page_break',
        content: ''
      });
    }

    mergedSections.push({
      id: 'heading-' + i,
      type: 'heading',
      content: file.name.replace(/\.[^/.]+$/, ''),
      level: 1
    });

    mergedSections.push(...parsed.sections);
  }

  if (outputFormat === 'docx') {
    return generateDocxBlob('Merged Document', mergedSections, DEFAULT_STYLE_SETTINGS);
  } else {
    return generatePdfBlob('Merged Document', mergedSections, DEFAULT_STYLE_SETTINGS);
  }
}
