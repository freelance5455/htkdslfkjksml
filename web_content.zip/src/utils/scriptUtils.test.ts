import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateEstimatedDuration,
  formatTime,
  extractKeyTerms,
  generatePromptForMusic,
  calculateSkillMatchScore,
  generateStudyPlan,
} from './scriptUtils.js';

test('calculateEstimatedDuration accurately computes seconds based on word count', () => {
  // Empty or whitespace
  assert.equal(calculateEstimatedDuration(''), 0);
  assert.equal(calculateEstimatedDuration('   '), 0);

  // 130 words at 130 WPM should take exactly 60 seconds
  const words130 = Array(130).fill('টেক').join(' ');
  assert.equal(calculateEstimatedDuration(words130, 130), 60);

  // 65 words at 130 WPM should take ~30 seconds
  const words65 = Array(65).fill('শব্দ').join(' ');
  assert.equal(calculateEstimatedDuration(words65, 130), 30);
});

test('formatTime correctly formats seconds to MM:SS', () => {
  assert.equal(formatTime(0), '00:00');
  assert.equal(formatTime(9), '00:09');
  assert.equal(formatTime(65), '01:05');
  assert.equal(formatTime(360), '06:00');
});

test('extractKeyTerms finds relevant tech terms from Bengali text', () => {
  const sample = 'Zapier বা Make-এর মতো টুল ব্যবহার করে ChatGPT প্রম্পট দিন।';
  const terms = extractKeyTerms(sample);
  assert.ok(terms.includes('Zapier'));
  assert.ok(terms.includes('Make'));
  assert.ok(terms.includes('ChatGPT'));
  assert.ok(!terms.includes('Figma'));
});

test('generatePromptForMusic generates structured prompt for Lyria', () => {
  const prompt = generatePromptForMusic('tech', 'Inspiring & Modern', '30s');
  assert.ok(prompt.includes('30s'));
  assert.ok(prompt.includes('Modern electronic synthwave'));
  assert.ok(prompt.includes('Inspiring & Modern'));
});

test('calculateSkillMatchScore ranks skills based on user preferences', () => {
  const creativeResult = calculateSkillMatchScore({
    background: 'creative',
    interest: 'visual',
    creativityPreference: 'visual',
    mathComfort: 'low',
  });

  assert.ok(creativeResult.length === 5);
  // Highest match should be video editing or UI/UX
  assert.ok(
    creativeResult[0].skillId === 'video-editing' || creativeResult[0].skillId === 'ui-ux'
  );

  const techResult = calculateSkillMatchScore({
    background: 'tech',
    interest: 'automation',
    mathComfort: 'high',
    creativityPreference: 'logical',
  });
  assert.equal(techResult[0].skillId, 'ai-automation');
});

test('generateStudyPlan creates a structured 8-week routine', () => {
  const plan = generateStudyPlan('ai-automation', 2, 'beginner');
  assert.equal(plan.dailyHours, 2);
  assert.equal(plan.totalWeeks, 8);
  assert.ok(plan.phases.length >= 3);
  assert.ok(plan.dailySchedule.length === 3);
});
