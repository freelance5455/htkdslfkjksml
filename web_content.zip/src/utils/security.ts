/**
 * Security & Moderation Utilities for Secret Gossip
 * Enforces zero-identity leakage, client-side profanity filtering,
 * and cryptographic pseudonym hashing.
 */

// Banned offensive / toxic terms (multi-lingual common swear & harassment tokens)
const BANNED_PATTERNS = [
  /\b(chutiya|bhenchod|madarchod|gaand|bhosdike|harami|saala|randi|mc|bc)\b/gi,
  /\b(kill\s+yourself|die\s+bitch|slut|whore|nigger|faggot|rape|kys)\b/gi,
  /\b(phone\s*number\s*:\s*\d{10}|\+91\d{10}|\d{10})\b/gi, // Prevent accidental doxxing of real phone numbers
];

export interface ModerationResult {
  isClean: boolean;
  censoredText: string;
  flaggedKeywords: string[];
  severity: 'none' | 'warning' | 'severe';
}

export function filterProfanity(text: string): ModerationResult {
  let censored = text;
  const flagged: string[] = [];

  for (const pattern of BANNED_PATTERNS) {
    const matches = text.match(pattern);
    if (matches) {
      matches.forEach(m => flagged.push(m.toLowerCase()));
      censored = censored.replace(pattern, (match) => '•'.repeat(match.length));
    }
  }

  const isSevere = flagged.some(w => /kill|rape|slut|kys/i.test(w));

  return {
    isClean: flagged.length === 0,
    censoredText: censored,
    flaggedKeywords: [...new Set(flagged)],
    severity: flagged.length === 0 ? 'none' : isSevere ? 'severe' : 'warning',
  };
}

/**
 * Generates an irreversible anonymous hash for internal database reference.
 * Even server administrators cannot decipher the real identity from this hash.
 */
export function generateSecretHash(seed: string): string {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    const char = seed.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  const hex = Math.abs(hash).toString(16).toUpperCase().padStart(6, '0');
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  return `#SS-${hex.slice(0, 4)}-${randomSuffix}`;
}

const AVATAR_EMOJIS = ['🦊', '🦉', '🐱', '🐺', '🦝', '🦇', '🐯', '🐼', '🦅', '🦄', '🐲', '🐙', '👾', '🎭', '🔮', '⚡', '🌙', '🪐'];
const AVATAR_ADJECTIVES = ['Midnight', 'Neon', 'Shadow', 'Cyber', 'Velvet', 'Quantum', 'Phantom', 'Cosmic', 'Stealth', 'Hyper', 'Aurora', 'Vortex', 'Solar', 'Lunar', 'Echo'];
const AVATAR_NOUNS = ['Fox', 'Owl', 'Raven', 'Lynx', 'Panther', 'Specter', 'Whisperer', 'Ghost', 'Falcon', 'Wolf', 'Oracle', 'Seeker', 'Ninja', 'Rogue', 'Enigma'];

export function generateRandomPersona(): { emoji: string; name: string } {
  const emoji = AVATAR_EMOJIS[Math.floor(Math.random() * AVATAR_EMOJIS.length)];
  const adj = AVATAR_ADJECTIVES[Math.floor(Math.random() * AVATAR_ADJECTIVES.length)];
  const noun = AVATAR_NOUNS[Math.floor(Math.random() * AVATAR_NOUNS.length)];
  return {
    emoji,
    name: `${adj} ${noun}`,
  };
}

/**
 * Generates a one-time college student access code for verified groups
 */
export function generateOneTimeCode(collegePrefix: string): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let token = '';
  for (let i = 0; i < 4; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `${collegePrefix.toUpperCase().slice(0, 4)}-${token}`;
}

/**
 * Format relative time (e.g. "5m ago", "2h ago")
 */
export function formatTimeAgo(dateString: string): string {
  const now = new Date();
  const past = new Date(dateString);
  const diffInSeconds = Math.floor((now.getTime() - past.getTime()) / 1000);

  if (diffInSeconds < 60) return 'Just now';
  if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
  if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
  return `${Math.floor(diffInSeconds / 86400)}d ago`;
}
