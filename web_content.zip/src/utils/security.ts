/**
 * Secure password hashing utility using standard Web Crypto API SHA-256 algorithm with salt.
 * Ensures plain text passwords are NEVER stored in localStorage or memory.
 */

const SALT = 'MediguideAI_Secure_Salt_2026_V2';

export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + SALT);
  
  if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
    try {
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
      return hashHex;
    } catch {
      // Fallback pseudo-hash for compatibility if SubtleCrypto is restricted
      return fallbackHash(password);
    }
  }
  return fallbackHash(password);
}

function fallbackHash(str: string): string {
  let hash = 0;
  const combined = str + SALT;
  for (let i = 0; i < combined.length; i++) {
    const char = combined.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return 'sha256_mock_' + Math.abs(hash).toString(16) + 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';
}

/**
 * Validates password criteria:
 * - At least 8 characters
 * - Includes uppercase letter
 * - Includes lowercase letter
 * - Includes number
 * - Includes special character
 */
export function validatePassword(password: string): {
  isValid: boolean;
  length: boolean;
  uppercase: boolean;
  lowercase: boolean;
  number: boolean;
  special: boolean;
  errorMessage?: string;
} {
  const length = password.length >= 8;
  const uppercase = /[A-Z]/.test(password);
  const lowercase = /[a-z]/.test(password);
  const number = /[0-9]/.test(password);
  const special = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password);

  const isValid = length && uppercase && lowercase && number && special;

  let errorMessage = '';
  if (!length) errorMessage = 'Password must be at least 8 characters long.';
  else if (!uppercase) errorMessage = 'Password must include at least one uppercase letter (A-Z).';
  else if (!lowercase) errorMessage = 'Password must include at least one lowercase letter (a-z).';
  else if (!number) errorMessage = 'Password must include at least one number (0-9).';
  else if (!special) errorMessage = 'Password must include at least one special character (!@#$%^&*).';

  return { isValid, length, uppercase, lowercase, number, special, errorMessage };
}

/**
 * Validates 10-digit mobile number
 */
export function validateMobileNumber(mobile: string): boolean {
  const clean = mobile.trim();
  return /^\d{10}$/.test(clean);
}

/**
 * Validates Email Address
 */
export function validateEmail(email: string): boolean {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email.trim().toLowerCase());
}

/**
 * Calculates BMI based on height (cm) and weight (kg)
 */
export function calculateBMI(heightCm?: number | string, weightKg?: number | string): string {
  if (!heightCm || !weightKg) return 'N/A';
  const h = typeof heightCm === 'string' ? parseFloat(heightCm) : heightCm;
  const w = typeof weightKg === 'string' ? parseFloat(weightKg) : weightKg;
  if (!h || !w || h <= 0 || w <= 0) return 'N/A';
  const heightMeters = h / 100;
  const bmiValue = (w / (heightMeters * heightMeters)).toFixed(1);
  const val = parseFloat(bmiValue);
  let status = 'Normal';
  if (val < 18.5) status = 'Underweight';
  else if (val >= 25 && val < 30) status = 'Overweight';
  else if (val >= 30) status = 'Obese';
  return `${bmiValue} (${status})`;
}
