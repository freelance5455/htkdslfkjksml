export interface CopyResult {
  ok: boolean;
  method: 'navigator' | 'execCommand' | 'blocked';
}

/**
 * Reliable cross-browser/iframe clipboard copy.
 * Tries navigator.clipboard.writeText first, then falls back to execCommand('copy')
 * for environments where Permissions Policy or async focus rules block Clipboard API.
 */
export async function robustCopyToClipboard(text: string): Promise<CopyResult> {
  if (!text) return { ok: false, method: 'blocked' };

  // 1. Modern Clipboard API
  if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
    try {
      await navigator.clipboard.writeText(text);
      return { ok: true, method: 'navigator' };
    } catch {
      // Fall through to execCommand fallback
    }
  }

  // 2. Synchronous textarea + execCommand fallback
  try {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.top = '-9999px';
    textarea.style.left = '-9999px';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);

    const selection = document.getSelection();
    const savedRange =
      selection && selection.rangeCount > 0 ? selection.getRangeAt(0) : null;

    textarea.focus();
    textarea.select();
    textarea.setSelectionRange(0, textarea.value.length);

    const copied = document.execCommand('copy');
    document.body.removeChild(textarea);

    if (savedRange && selection) {
      selection.removeAllRanges();
      selection.addRange(savedRange);
    }

    if (copied) {
      return { ok: true, method: 'execCommand' };
    }
  } catch {
    // Blocked completely
  }

  return { ok: false, method: 'blocked' };
}
