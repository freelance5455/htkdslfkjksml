import { findLanguageByCode } from '../constants/languages';

export function containsRtlCharacters(text: string): boolean {
  // Arabic, Urdu/Nastaliq, Hebrew, Syriac Unicode blocks
  return /[\u0590-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(text);
}

export function getTextDirection(languageCode: string, text?: string): 'rtl' | 'ltr' {
  const lang = findLanguageByCode(languageCode);
  if (lang.isRtl) {
    return 'rtl';
  }
  if ((languageCode === 'auto' || languageCode === 'same') && text && containsRtlCharacters(text)) {
    return 'rtl';
  }
  return 'ltr';
}

export function getTranscriptFontClass(languageCode: string, text?: string): string {
  const lang = findLanguageByCode(languageCode);
  if (
    lang.scriptFamily === 'nastaliq' ||
    lang.code.startsWith('ur') ||
    lang.code.startsWith('pa-PK')
  ) {
    return 'font-urdu';
  }
  if (
    lang.isRtl ||
    ((languageCode === 'auto' || languageCode === 'same') &&
      text &&
      containsRtlCharacters(text))
  ) {
    return 'font-arabic';
  }
  return 'font-sans';
}

/**
 * Cleanly appends an incoming live speech chunk to existing text while removing
 * overlapping boundary words (e.g. from overlapping PCM buffers) so words
 * never repeat or get cut off.
 */
export function stitchTranscriptChunk(existing: string, incoming: string): string {
  const base = existing.trim();
  const next = incoming.trim();
  if (!next) return base;
  if (!base) return next;

  const baseWords = base.split(/\s+/);
  const nextWords = next.split(/\s+/);
  const maxOverlap = Math.min(6, baseWords.length, nextWords.length);

  let overlapCount = 0;
  for (let len = maxOverlap; len >= 1; len -= 1) {
    const tail = baseWords
      .slice(baseWords.length - len)
      .join(' ')
      .toLowerCase();
    const head = nextWords.slice(0, len).join(' ').toLowerCase();
    if (tail === head) {
      overlapCount = len;
      break;
    }
  }

  const remaining = nextWords.slice(overlapCount).join(' ');
  if (!remaining) return base;
  return `${base} ${remaining}`.trim();
}

export function countWords(text: string): number {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  return trimmed.split(/\s+/).length;
}

/**
 * Lightweight local formatting fallback used when running standalone inside an
 * offline APK / WebView without an active backend server.
 * Cleans extra spaces, punctuation spacing, sentence capitalization (LTR),
 * and ensures proper sentence-ending punctuation.
 */
export function formatLocalFallbackText(
  rawText: string,
  languageCode: string
): string {
  const normalized = rawText
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .replace(/ *\n */g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  if (!normalized) return '';

  const hasRtl = containsRtlCharacters(normalized);
  const hasLatin = /[A-Za-z]/.test(normalized);
  const isRtl = hasRtl || (!hasLatin && getTextDirection(languageCode, normalized) === 'rtl');

  const paragraphs = normalized.split(/\n\n+/).map((para) => {
    let cleaned = para
      .replace(/\s+([,.;:!?،۔؟])/g, '$1')
      .replace(/([,.;:!?،۔؟])([^\s\n,.;:!?،۔؟])/g, '$1 $2')
      .trim();

    if (!cleaned) return '';

    if (isRtl) {
      if (!/[۔؟!.?]$/.test(cleaned)) {
        const isUrdu =
          languageCode.startsWith('ur') ||
          languageCode.startsWith('pa-PK') ||
          /[ٹڈڑںےہ]/.test(cleaned);
        cleaned = `${cleaned}${isUrdu ? '۔' : '.'}`;
      }
      return cleaned;
    }

    // Capitalize first letter and letters after sentence-ending punctuation for LTR text
    cleaned = cleaned.replace(/(^|[.!?]\s+)([a-z])/g, (_, prefix: string, ch: string) => {
      return `${prefix}${ch.toUpperCase()}`;
    });
    cleaned = cleaned.replace(/\bi\b/g, 'I');

    if (!/[.!?]$/.test(cleaned)) {
      cleaned = `${cleaned}.`;
    }
    return cleaned;
  });

  return paragraphs.filter(Boolean).join('\n\n');
}

/**
 * Produces spotless, clean plain text for clipboard copy and .txt file download:
 * merges committed text with any active live text, normalizes line endings,
 * trims stray spaces on each line, and collapses excessive blank lines.
 */
export function buildCleanPlainText(
  writtenText: string,
  livePreviewText = ''
): string {
  const combined = [writtenText.trim(), livePreviewText.trim()]
    .filter(Boolean)
    .join('\n\n');

  if (!combined) return '';

  return combined
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map((line) => line.replace(/[ \t]+/g, ' ').trim())
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}


