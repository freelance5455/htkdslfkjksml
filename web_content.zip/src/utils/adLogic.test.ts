import test from 'node:test';
import assert from 'node:assert/strict';
import { getActiveSegment, validate16sPacing, formatTimeClock } from './adLogic.ts';

test('getActiveSegment correctly identifies 0-3s as hook', () => {
  assert.equal(getActiveSegment(0), 'hook');
  assert.equal(getActiveSegment(1.5), 'hook');
  assert.equal(getActiveSegment(2.99), 'hook');
});

test('getActiveSegment correctly identifies 3-12s as demo', () => {
  assert.equal(getActiveSegment(3.0), 'demo');
  assert.equal(getActiveSegment(7.5), 'demo');
  assert.equal(getActiveSegment(11.9), 'demo');
});

test('getActiveSegment correctly identifies 12-16s as cta', () => {
  assert.equal(getActiveSegment(12.0), 'cta');
  assert.equal(getActiveSegment(15.5), 'cta');
  assert.equal(getActiveSegment(16.0), 'cta');
});

test('validate16sPacing checks caption bounds within 16 seconds', () => {
  const validCaptions = [
    { start: 0, end: 3, text: 'Hook' },
    { start: 3, end: 12, text: 'Demo' },
    { start: 12, end: 16, text: 'CTA' },
  ];
  assert.equal(validate16sPacing(validCaptions), true);

  const invalidCaptions = [
    { start: 0, end: 20, text: 'Too long' },
  ];
  assert.equal(validate16sPacing(invalidCaptions), false);
});

test('formatTimeClock formats clock string accurately', () => {
  assert.equal(formatTimeClock(4.2), '04.2s / 16.0s');
  assert.equal(formatTimeClock(15.9), '15.9s / 16.0s');
});
