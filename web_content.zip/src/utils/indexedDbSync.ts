import { OfflineAction } from '../types/index.ts';

const DB_NAME = 'fieldflow_offline_sync_db';
const DB_VERSION = 1;
const STORE_NAME = 'offline_queue';

/**
 * Opens or initializes the shared IndexedDB database accessible
 * by both the Window/React application and the Service Worker.
 */
export function openSyncDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      return reject(new Error('IndexedDB is not supported in this environment.'));
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('type', 'type', { unique: false });
        store.createIndex('status', 'status', { unique: false });
        store.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

/**
 * Saves or updates an offline action record in IndexedDB.
 */
export async function saveRecordToIndexedDB(action: OfflineAction): Promise<void> {
  try {
    const db = await openSyncDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.put(action);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('Failed to save record to IndexedDB:', err);
  }
}

/**
 * Retrieves all pending or failed records that need to be uploaded.
 */
export async function getPendingRecordsFromIndexedDB(): Promise<OfflineAction[]> {
  try {
    const db = await openSyncDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll();

      request.onsuccess = () => {
        const all: OfflineAction[] = request.result || [];
        const pending = all.filter(
          (item) => item.status === 'pending' || item.status === 'failed' || item.status === 'syncing'
        );
        resolve(pending);
      };

      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('Failed to read pending records from IndexedDB:', err);
    return [];
  }
}

/**
 * Updates status of a record in IndexedDB (e.g. 'synced', 'failed', 'syncing').
 */
export async function updateRecordStatusInIndexedDB(
  id: string,
  status: OfflineAction['status'],
  error?: string
): Promise<void> {
  try {
    const db = await openSyncDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const getReq = store.get(id);

      getReq.onsuccess = () => {
        const record = getReq.result as OfflineAction | undefined;
        if (record) {
          record.status = status;
          if (error) record.error = error;
          const putReq = store.put(record);
          putReq.onsuccess = () => resolve();
          putReq.onerror = () => reject(putReq.error);
        } else {
          resolve();
        }
      };

      getReq.onerror = () => reject(getReq.error);
    });
  } catch (err) {
    console.warn('Failed to update record status in IndexedDB:', err);
  }
}

/**
 * Removes an uploaded record from IndexedDB once uploaded.
 */
export async function removeRecordFromIndexedDB(id: string): Promise<void> {
  try {
    const db = await openSyncDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.delete(id);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('Failed to delete record from IndexedDB:', err);
  }
}

/**
 * Clears all records that are marked as 'synced'.
 */
export async function clearSyncedRecordsFromIndexedDB(): Promise<void> {
  try {
    const db = await openSyncDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll();

      request.onsuccess = () => {
        const all: OfflineAction[] = request.result || [];
        all.forEach((item) => {
          if (item.status === 'synced') {
            store.delete(item.id);
          }
        });
        resolve();
      };

      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('Failed to clear synced records from IndexedDB:', err);
  }
}
