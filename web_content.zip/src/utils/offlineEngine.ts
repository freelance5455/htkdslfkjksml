// Offline Engine for Ranabir AI Assistant
// Provides intelligent on-device responses even when internet is disconnected.

interface OfflineRule {
  keywords: string[];
  response: string;
}

const OFFLINE_RULES: OfflineRule[] = [
  {
    keywords: ["who are you", "তুমি কে", "কে তুমি", "tum kaun ho", "identity", "about yourself"],
    response: "আমি Ranabir, তোমাকে সাহায্য করার জন্যই তৈরি।",
  },
  {
    keywords: ["who made you", "কে বানিয়েছে", "কার তৈরি", "developer", "team", "creator"],
    response: "Ranabir AI, Ranabir Team দ্বারা তৈরি। আমরা ব্যবহারকারীর সম্পূর্ণ গোপনীয়তা ও সর্বোচ্চ পারফরম্যান্স নিশ্চিত করি।",
  },
  {
    keywords: ["tagline", "ট্যাগলাইন", "উদ্দেশ্য"],
    response: "রণবীর (Ranabir) এর মূল ট্যাগলাইন: 'সর্বদা সাহায্য করার জন্য প্রস্তুত'।",
  },
  {
    keywords: ["hello", "hi", "নমস্কার", "হ্যালো", "কেমন আছো", "hey"],
    response: "নমস্কার! আমি Ranabir। আজ আপনাকে কীভাবে সাহায্য করতে পারি? পড়াশোনা, কোডিং, ছবি তৈরি বা অন্য যেকোনো বিষয়ে প্রশ্ন করতে পারেন।",
  },
  {
    keywords: ["code", "coding", "কোডিং", "javascript", "python", "flutter", "react"],
    response: `কোডিং সহায়তা (Offline Mode):
- **ওয়েব ডেভেলপমেন্ট**: React, TypeScript, Tailwind CSS
- **মোবাইল অ্যাপ**: Flutter, Dart
- **স্ক্রিপ্টিং ও ডেটা**: Python, Node.js

টিপ: কোড লেখার সময় সবসময় ছোট ছোট ফাংশনে বিভক্ত করুন এবং রিডেবিলিটির দিকে লক্ষ্য রাখুন। আপনি কোনো নির্দিষ্ট কোড স্নিপেট বা বাগ সম্পর্কে জিজ্ঞাসা করতে পারেন!`,
  },
  {
    keywords: ["গল্প", "story", "গল্প বলো", "ছোট গল্প"],
    response: `একটি ছোট্ট অনুপ্রেরণামূলক গল্প:
একদা এক গ্রামে এক তরুণ স্বপ্ন দেখত সে আকাশে উড়বে। সবাই তাকে উপহাস করত। কিন্তু সে প্রতিদিন পাখির ডানা পর্যবেক্ষণ করত, বাতাসের গতি মাপত। বহু বছর সাধনার পর সে প্রথম গ্লাইডার বানিয়ে পাহাড়ের ওপর থেকে আকাশে ডানা মেলল।
শিক্ষা: মানুষের ইচ্ছা এবং অবিরাম পরিশ্রম অসম্ভবকেও সম্ভব করে তোলে।`,
  },
  {
    keywords: ["কবিতা", "poem", "রবীন্দ্রনাথ"],
    response: `চিত্ত যেথা ভয়শূন্য, উচ্চ যেথা শির,
জ্ঞান যেথা মুক্ত, যেথা গৃহের প্রাচীর
আপন প্রাঙ্গণতলে দিবসশর্বরী
বসুধারে রাখে নাই খণ্ড ক্ষুদ্র করি...
— রবীন্দ্রনাথ ঠাকুর`,
  },
  {
    keywords: ["পড়াশোনা", "study", "exam", "টিপস", "মনোযোগ"],
    response: `পড়াশোনায় ভালো করার ৪টি স্মার্ট টিপস:
1. **Pomodoro Technique**: ২৫ মিনিট গভীর মনোযোগ দিয়ে পড়ুন, তারপর ৫ মিনিট বিরতি নিন।
2. **Active Recall**: পড়ার পর বই বন্ধ করে মনে করার চেষ্টা করুন কী শিখলেন।
3. **Feynman Technique**: বিষয়টি এমনভাবে কাউকে বোঝান যেন সে প্রথমবার শুনছে।
4. পর্যাপ্ত ঘুম ও জলপান করুন।`,
  },
  {
    keywords: ["কলকাতা", "kolkata", "শহর"],
    response: "কলকাতা — আনন্দনগরী (City of Joy)। হাওড়া ব্রিজ, ভিক্টোরিয়া মেমোরিয়াল, ট্রাম এবং মিষ্টি দই-রসগোল্লার জন্য বিখ্যাত এই ঐতিহ্যবাহী সংস্কৃতি-প্রধান শহর।",
  },
];

export function getOfflineAnswer(prompt: string, addressingMode: "tumi" | "apni" = "tumi"): string {
  const query = prompt.toLowerCase().trim();

  const isApni = addressingMode === "apni";

  // Check identity
  if (query.includes("who are you") || query.includes("তুমি কে") || query.includes("কে তুমি") || query.includes("কে আপনি")) {
    return isApni
      ? "আমি Ranabir, আপনাকে সাহায্য করার জন্যই তৈরি।"
      : "আমি Ranabir, তোমাকে সাহায্য করার জন্যই তৈরি।";
  }

  // Check team
  if (query.includes("who made") || query.includes("কে তৈরি") || query.includes("কে বানিয়েছে")) {
    return "Ranabir AI, Ranabir Team দ্বারা তৈরি।";
  }

  for (const rule of OFFLINE_RULES) {
    if (rule.keywords.some((k) => query.includes(k))) {
      return rule.response;
    }
  }

  // Generic fast offline fallback
  const pronoun = isApni ? "আপনি" : "তুমি";
  const pronounObjective = isApni ? "আপনাকে" : "তোমাকে";
  const pronounPossessive = isApni ? "আপনার" : "তোমার";
  const verbForm = isApni ? "পারবেন" : "পারবে";

  return `নমস্কার! আমি Ranabir (অফলাইন মোড)।
${pronounPossessive} প্রশ্ন: "${prompt}"

${pronounObjective} সাহায্য করার জন্যই আমি তৈরি। ইন্টারনেট ছাড়াও আমার কোর অফলাইন ইঞ্জিন সক্রিয় রয়েছে। যেকোনো পড়াশোনা, কোডিং ধারণা, গল্প লেখা বা ফটো এডিটিং টুলস ${pronoun} পুরোপুরি অফলাইনে ব্যবহার করতে ${verbForm}!
"সর্বদা সাহায্য করার জন্য প্রস্তুত" — Ranabir AI।`;
}
