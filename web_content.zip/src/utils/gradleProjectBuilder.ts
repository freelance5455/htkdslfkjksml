import JSZip from 'jszip';
import { AppConfig, WebFile } from '../types/apk';
import { generateAllMipmaps } from './iconGenerator';
import { generateManifestXml } from './manifestBuilder';
import { AppIconConfig } from '../types/apk';

/**
 * Generate a complete, ready-to-open Android Studio Gradle Project (.zip)
 */
export async function buildGradleProjectZip(
  config: AppConfig,
  iconConfig: AppIconConfig,
  webFiles: WebFile[]
): Promise<Blob> {
  const zip = new JSZip();

  // 1. Root build.gradle
  zip.file(
    'build.gradle',
    `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id 'com.android.application' version '8.2.2' apply false
}
`
  );

  // 2. settings.gradle
  const projectNameSafe = config.appName.replace(/[^a-zA-Z0-9]/g, '');
  zip.file(
    'settings.gradle',
    `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "${projectNameSafe}"
include ':app'
`
  );

  // 3. gradle.properties
  zip.file(
    'gradle.properties',
    `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
`
  );

  // 4. gradle/wrapper/gradle-wrapper.properties
  zip.file(
    'gradle/wrapper/gradle-wrapper.properties',
    `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.5-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
  );

  // 5. gradlew & gradlew.bat
  zip.file(
    'gradlew',
    `#!/bin/sh
exec gradle "$@"
`
  );
  zip.file(
    'gradlew.bat',
    `@rem Execute Gradle command
@gradle %*
`
  );

  // 6. app/build.gradle
  zip.file(
    'app/build.gradle',
    `plugins {
    id 'com.android.application'
}

android {
    namespace '${config.packageName}'
    compileSdk 34

    defaultConfig {
        applicationId "${config.packageName}"
        minSdk 21
        targetSdk 34
        versionCode ${config.versionCode}
        versionName "${config.versionName}"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.webkit:webkit:1.10.0'
    implementation 'androidx.swiperefreshlayout:swiperefreshlayout:1.1.0'
}
`
  );

  // 7. app/proguard-rules.pro
  zip.file(
    'app/proguard-rules.pro',
    `# Add project specific ProGuard rules here.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
`
  );

  // 8. app/src/main/AndroidManifest.xml
  const manifestContent = generateManifestXml(config);
  zip.file('app/src/main/AndroidManifest.xml', manifestContent);

  // 9. Java Package Directory & MainActivity.java
  const packagePath = config.packageName.replace(/\./g, '/');
  const mainActivityJava = generateMainActivityCode(config);
  zip.file(`app/src/main/java/${packagePath}/MainActivity.java`, mainActivityJava);

  // 10. Res values (colors.xml, strings.xml, styles.xml)
  zip.file(
    'app/src/main/res/values/colors.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primaryColor">${config.themeColor || '#2563EB'}</color>
    <color name="primaryDarkColor">#1E40AF</color>
    <color name="accentColor">#3B82F6</color>
    <color name="windowBackground">${config.backgroundColor || '#FFFFFF'}</color>
</resources>
`
  );

  zip.file(
    'app/src/main/res/values/strings.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${escapeXml(config.appName)}</string>
</resources>
`
  );

  zip.file(
    'app/src/main/res/values/styles.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.APKForgeApp" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="colorPrimary">@color/primaryColor</item>
        <item name="colorPrimaryDark">@color/primaryDarkColor</item>
        <item name="colorAccent">@color/accentColor</item>
        <item name="android:windowBackground">@color/windowBackground</item>
    </style>
</resources>
`
  );

  // 11. Activity Layout XML
  zip.file(
    'app/src/main/res/layout/activity_main.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<androidx.swiperefreshlayout.widget.SwipeRefreshLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/swipeRefreshLayout"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <FrameLayout
        android:layout_width="match_parent"
        android:layout_height="match_parent">

        <WebView
            android:id="@+id/webView"
            android:layout_width="match_parent"
            android:layout_height="match_parent" />

        <ProgressBar
            android:id="@+id/progressBar"
            style="?android:attr/progressBarStyleHorizontal"
            android:layout_width="match_parent"
            android:layout_height="4dp"
            android:visibility="gone" />

    </FrameLayout>
</androidx.swiperefreshlayout.widget.SwipeRefreshLayout>
`
  );

  // 12. App Icons in Mipmap Folders
  const mipmaps = await generateAllMipmaps(iconConfig);
  for (const m of mipmaps) {
    if (m.density.startsWith('mipmap-')) {
      zip.file(`app/src/main/res/${m.density}/ic_launcher.png`, m.uint8Array);
      zip.file(`app/src/main/res/${m.density}/ic_launcher_round.png`, m.uint8Array);
    }
  }

  // 13. Assets folder (assets/www/...)
  const assetsFolder = zip.folder('app/src/main/assets/www');
  if (assetsFolder) {
    for (const f of webFiles) {
      const cleanPath = f.path.replace(/^\/+/, '');
      if (typeof f.content === 'string') {
        assetsFolder.file(cleanPath, f.content);
      } else {
        assetsFolder.file(cleanPath, f.content);
      }
    }
  }

  // 14. Project README.md with instructions
  zip.file(
    'README.md',
    `# ${config.appName} — Android Studio Project
Generated by **APKForge Studio**

## Project Details
- **Package ID:** \`${config.packageName}\`
- **Version:** \`${config.versionName}\` (Code: \`${config.versionCode}\`)
- **Author / Company:** ${config.companyName || 'APKForge Developer'}
- **Build Target:** Android 14 (API 34) — Minimum SDK: Android 5.0 (API 21)

## How to Build & Run
1. Open **Android Studio** (Hedgehog, Iguana, Jellyfish, or newer).
2. Select **Open** and choose this root folder.
3. Wait for Gradle sync to complete.
4. Click **Run > Run 'app'** or connect an Android device via USB/ADB.
5. To generate a signed release APK or Google Play App Bundle (AAB):
   - Go to **Build > Generate Signed Bundle / APK**
   - Select **APK** or **Android App Bundle**
   - Choose your Keystore and click **Release**.
`
  );

  return await zip.generateAsync({ type: 'blob' });
}

function generateMainActivityCode(config: AppConfig): string {
  const fullscreenCode = config.fullscreen
    ? `
        // Immersive Fullscreen Mode
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );`
    : '';

  const pullToRefreshCode = config.enablePullToRefresh
    ? `
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                webView.reload();
            }
        });`
    : `
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setEnabled(false);`;

  return `package ${config.packageName};

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ValueCallback<Uri[]> filePathCallback;
    private final static int FILE_CHOOSER_RESULT_CODE = 1001;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ${fullscreenCode}
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        ${pullToRefreshCode}

        webView = findViewById(R.id.webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(${config.enableZoomControls});
        settings.setBuiltInZoomControls(${config.enableZoomControls});
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (progressBar != null) progressBar.setVisibility(View.GONE);
                if (swipeRefreshLayout != null) swipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("whatsapp:") || url.startsWith("geo:")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (progressBar != null) {
                    progressBar.setProgress(newProgress);
                    if (newProgress == 100) progressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_RESULT_CODE);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        // Load asset bundle
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_RESULT_CODE) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == Activity.RESULT_OK && data != null) {
                    String dataString = data.getDataString();
                    if (dataString != null) {
                        results = new Uri[]{Uri.parse(dataString)};
                    }
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}
`;
}

function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
