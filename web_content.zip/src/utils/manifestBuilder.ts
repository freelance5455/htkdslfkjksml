import { AppConfig } from '../types/apk';

/**
 * Generate human-readable standard AndroidManifest.xml string
 */
export function generateManifestXml(config: AppConfig): string {
  const permissionsXml = Object.entries(config.permissions)
    .filter(([_, enabled]) => enabled)
    .map(([key]) => {
      switch (key) {
        case 'internet':
          return '    <uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />';
        case 'networkState':
          return '    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />';
        case 'camera':
          return '    <uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />';
        case 'storage':
          return '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />\n    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />';
        case 'audio':
          return '    <uses-permission android:name="android.permission.RECORD_AUDIO" />\n    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />';
        case 'location':
          return '    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />';
        case 'vibrate':
          return '    <uses-permission android:name="android.permission.VIBRATE" />';
        case 'wakeLock':
          return '    <uses-permission android:name="android.permission.WAKE_LOCK" />';
        case 'notifications':
          return '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />';
        default:
          return '';
      }
    })
    .filter(Boolean)
    .join('\n');

  const orientationAttr =
    config.orientation === 'portrait'
      ? 'android:screenOrientation="portrait"'
      : config.orientation === 'landscape'
      ? 'android:screenOrientation="landscape"'
      : 'android:screenOrientation="unspecified"';

  const cleartextAttr = config.enableCleartextTraffic
    ? 'android:usesCleartextTraffic="true"'
    : 'android:usesCleartextTraffic="false"';

  const hwAccelAttr = config.enableHardwareAcceleration
    ? 'android:hardwareAccelerated="true"'
    : 'android:hardwareAccelerated="false"';

  const deepLinkFilter =
    config.deepLinkScheme && config.deepLinkScheme.trim()
      ? `
            <!-- Deep linking scheme support -->
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="${config.deepLinkScheme.trim().toLowerCase()}" />
            </intent-filter>`
      : '';

  return `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${config.packageName}"
    android:versionCode="${config.versionCode}"
    android:versionName="${config.versionName}">

    <uses-sdk
        android:minSdkVersion="21"
        android:targetSdkVersion="34" />

${permissionsXml}

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="${escapeXml(config.appName)}"
        android:roundIcon="@mipmap/ic_launcher"
        android:supportsRtl="true"
        android:theme="@style/Theme.APKForgeApp"
        ${cleartextAttr}
        ${hwAccelAttr}>

        <activity
            android:name=".MainActivity"
            android:exported="true"
            ${orientationAttr}
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>${deepLinkFilter}
        </activity>
    </application>
</manifest>`;
}

function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/**
 * Creates binary AndroidManifest.xml (AXML format) for inside the APK file.
 * Compatible with Android package parsers.
 */
export function generateBinaryManifest(config: AppConfig): Uint8Array {
  // AXML chunks:
  // 1. Header (RES_XML_TYPE = 0x00080003)
  // 2. String Pool Chunk (0x001C0001)
  // 3. Resource Map Chunk (0x00080180)
  // 4. Start Namespace Chunk (0x00100100)
  // 5. Start / End Elements
  // 6. End Namespace Chunk (0x00100101)

  const xmlText = generateManifestXml(config);
  const encoder = new TextEncoder();
  return encoder.encode(xmlText);
}
