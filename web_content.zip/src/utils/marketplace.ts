/**
 * PCMART Marketplace Core Business Logic & Settlement Engine
 * Pure logic decoupled from UI for high-confidence automated testing
 */
import crypto from 'node:crypto';

export interface SettlementBreakdown {
  grossAmount: number;
  marketplaceCommission: number;
  paymentGatewayFee: number;
  gstOnFees: number;
  refundAdjustment: number;
  netSellerPayout: number;
  platformEarnings: number;
}

export interface StockReservationItem {
  productId: string;
  variantId?: string;
  quantity: number;
}

export interface InventoryItem {
  id: string;
  variantId?: string;
  stock: number;
  title: string;
}

export type OrderStatus =
  | 'PENDING_PAYMENT'
  | 'CONFIRMED'
  | 'PACKED'
  | 'SHIPPED'
  | 'OUT_FOR_DELIVERY'
  | 'DELIVERED'
  | 'CANCELLED'
  | 'RETURN_REQUESTED'
  | 'RETURNED'
  | 'REFUNDED';

export type UserRole = 'CUSTOMER' | 'SELLER' | 'ADMIN' | 'SYSTEM';

/**
 * Calculates marketplace settlement payouts for a seller with exact fee breakdown:
 * - Marketplace Commission (e.g., 12%)
 * - Payment Gateway Fee (e.g., 2%)
 * - GST on fees (18% on Marketplace Commission + PG Fee as per Indian Tax Norms)
 * - Refund adjustment (if any prior return deduction exists)
 */
export function calculateSettlement(
  grossAmount: number,
  commissionRate: number = 0.12,
  pgFeeRate: number = 0.02,
  gstRate: number = 0.18,
  refundAdjustment: number = 0
): SettlementBreakdown {
  if (grossAmount < 0) {
    throw new Error('Gross amount cannot be negative');
  }

  const marketplaceCommission = Math.round(grossAmount * commissionRate * 100) / 100;
  const paymentGatewayFee = Math.round(grossAmount * pgFeeRate * 100) / 100;
  const feesSubjectToTax = marketplaceCommission + paymentGatewayFee;
  const gstOnFees = Math.round(feesSubjectToTax * gstRate * 100) / 100;
  const totalDeductions = marketplaceCommission + paymentGatewayFee + gstOnFees + refundAdjustment;
  
  const netSellerPayout = Math.max(0, Math.round((grossAmount - totalDeductions) * 100) / 100);
  const platformEarnings = Math.round(marketplaceCommission * 100) / 100;

  return {
    grossAmount,
    marketplaceCommission,
    paymentGatewayFee,
    gstOnFees,
    refundAdjustment,
    netSellerPayout,
    platformEarnings,
  };
}

/**
 * Generates and verifies HMAC SHA256 signatures for approved payment gateway webhooks and verification
 * (Razorpay / Cashfree / Stripe compliant format: payload = orderId + "|" + paymentId)
 */
export function generateHmacSignature(payload: string, secret: string): string {
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

export function verifyHmacSignature(payload: string, signature: string, secret: string): boolean {
  if (!signature || !payload || !secret) return false;
  const expected = generateHmacSignature(payload, secret);
  try {
    return crypto.timingSafeEqual(Buffer.from(signature, 'utf8'), Buffer.from(expected, 'utf8'));
  } catch {
    return false;
  }
}

/**
 * Validates stock availability and prevents overselling
 */
export function validateStockReservation(
  inventoryMap: Map<string, number>,
  requestedItems: StockReservationItem[]
): { valid: boolean; error?: string; updatedInventory?: Map<string, number> } {
  const updated = new Map<string, number>(inventoryMap);

  for (const item of requestedItems) {
    const key = item.variantId ? `${item.productId}_${item.variantId}` : item.productId;
    const currentStock = updated.get(key) ?? 0;

    if (item.quantity <= 0) {
      return { valid: false, error: `Invalid quantity ${item.quantity} for item ${key}` };
    }

    if (currentStock < item.quantity) {
      return {
        valid: false,
        error: `Insufficient stock for item ${key}. Requested: ${item.quantity}, Available: ${currentStock}`,
      };
    }

    updated.set(key, currentStock - item.quantity);
  }

  return { valid: true, updatedInventory: updated };
}

/**
 * Order state machine enforcing authorized transitions based on role
 */
export function transitionOrderStatus(
  currentStatus: OrderStatus,
  action: 'CONFIRM' | 'PACK' | 'SHIP' | 'OUT_FOR_DELIVERY' | 'DELIVER' | 'CANCEL' | 'REQUEST_RETURN' | 'APPROVE_RETURN' | 'REFUND',
  role: UserRole
): { allowed: boolean; nextStatus?: OrderStatus; reason?: string } {
  // Customer rules
  if (role === 'CUSTOMER') {
    if (action === 'CANCEL') {
      if (currentStatus === 'PENDING_PAYMENT' || currentStatus === 'CONFIRMED' || currentStatus === 'PACKED') {
        return { allowed: true, nextStatus: 'CANCELLED' };
      }
      return { allowed: false, reason: 'Cannot cancel order once it has been shipped or delivered' };
    }
    if (action === 'REQUEST_RETURN') {
      if (currentStatus === 'DELIVERED') {
        return { allowed: true, nextStatus: 'RETURN_REQUESTED' };
      }
      return { allowed: false, reason: 'Return can only be requested after delivery' };
    }
    return { allowed: false, reason: 'Customer not authorized for this action' };
  }

  // Seller rules
  if (role === 'SELLER') {
    if (action === 'PACK' && currentStatus === 'CONFIRMED') {
      return { allowed: true, nextStatus: 'PACKED' };
    }
    if (action === 'SHIP' && currentStatus === 'PACKED') {
      return { allowed: true, nextStatus: 'SHIPPED' };
    }
    if (action === 'OUT_FOR_DELIVERY' && currentStatus === 'SHIPPED') {
      return { allowed: true, nextStatus: 'OUT_FOR_DELIVERY' };
    }
    if (action === 'DELIVER' && currentStatus === 'OUT_FOR_DELIVERY') {
      return { allowed: true, nextStatus: 'DELIVERED' };
    }
    if (action === 'APPROVE_RETURN' && currentStatus === 'RETURN_REQUESTED') {
      return { allowed: true, nextStatus: 'RETURNED' };
    }
    return { allowed: false, reason: `Seller cannot transition from ${currentStatus} via ${action}` };
  }

  // Admin rules (Superuser override & dispute resolution)
  if (role === 'ADMIN' || role === 'SYSTEM') {
    switch (action) {
      case 'CONFIRM':
        return { allowed: true, nextStatus: 'CONFIRMED' };
      case 'CANCEL':
        return { allowed: true, nextStatus: 'CANCELLED' };
      case 'APPROVE_RETURN':
        return { allowed: true, nextStatus: 'RETURNED' };
      case 'REFUND':
        if (currentStatus === 'CANCELLED' || currentStatus === 'RETURN_REQUESTED' || currentStatus === 'RETURNED') {
          return { allowed: true, nextStatus: 'REFUNDED' };
        }
        return { allowed: false, reason: 'Refund requires prior cancellation or return' };
      default:
        return { allowed: true };
    }
  }

  return { allowed: false, reason: 'Unknown role or action' };
}

export const DEFAULT_ADMIN_PIN = '992418';
export const DEFAULT_ADMIN_PASSCODE = 'pcmart@admin2026';

/**
 * Validates admin authentication passcode or 6-digit PIN
 */
export function verifyAdminCredentials(input: string): boolean {
  if (!input) return false;
  const clean = input.trim();
  return clean === DEFAULT_ADMIN_PIN || clean === DEFAULT_ADMIN_PASSCODE;
}

/**
 * Enforces role-based portal access rules
 */
export function canAccessPortal(
  userRole: UserRole,
  targetPortal: 'CUSTOMER_APP' | 'SELLER_PORTAL' | 'ADMIN_DASHBOARD' | 'ARCHITECTURE_CENTER' | 'AI_STUDIO'
): boolean {
  if (targetPortal === 'CUSTOMER_APP') return true; // Anyone can browse customer shop
  if (targetPortal === 'AI_STUDIO') return true;

  if (targetPortal === 'SELLER_PORTAL') {
    return userRole === 'SELLER' || userRole === 'ADMIN' || userRole === 'SYSTEM';
  }

  if (targetPortal === 'ADMIN_DASHBOARD' || targetPortal === 'ARCHITECTURE_CENTER') {
    return userRole === 'ADMIN' || userRole === 'SYSTEM';
  }

  return false;
}

/**
 * Validates whether a customer can review a product from an order.
 * Only orders marked as 'DELIVERED' are eligible for verified product ratings & reviews.
 */
export function canReviewProduct(orderStatus: string): boolean {
  return orderStatus === 'DELIVERED';
}

/**
 * Recalculates product average rating and count based on verified reviews.
 */
export function calculateProductRating(reviews: { rating: number }[]): { rating: number; count: number } {
  if (!reviews || reviews.length === 0) {
    return { rating: 5.0, count: 0 };
  }
  const sum = reviews.reduce((acc, curr) => acc + curr.rating, 0);
  const avg = Number((sum / reviews.length).toFixed(1));
  return {
    rating: Math.min(5, Math.max(1, avg)),
    count: reviews.length,
  };
}

/**
 * Computes star distribution breakdown for 1 to 5 stars.
 */
export function getRatingBreakdown(reviews: { rating: number }[]): Record<1 | 2 | 3 | 4 | 5, number> {
  const breakdown: Record<1 | 2 | 3 | 4 | 5, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  if (!reviews) return breakdown;
  for (const r of reviews) {
    const star = Math.min(5, Math.max(1, Math.round(r.rating))) as 1 | 2 | 3 | 4 | 5;
    breakdown[star] = (breakdown[star] || 0) + 1;
  }
  return breakdown;
}

