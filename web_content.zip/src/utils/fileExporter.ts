import { Quiz, Question, SUBJECTS_DATA } from '../types';

/**
 * Trigger browser file download via Blob
 */
export function downloadFile(content: string, filename: string, mimeType: string = 'text/plain;charset=utf-8') {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/**
 * 1. Download Quiz as Clean Text (.txt) format
 */
export function downloadQuizAsText(quiz: Quiz, includeAnswers: boolean = true) {
  const subj = SUBJECTS_DATA.find((s) => s.id === quiz.subjectId);
  const subCat = subj?.subcategories.find((sc) => sc.id === quiz.subCategoryId);

  let output = `========================================================\n`;
  output += `               ${quiz.title.toUpperCase()}\n`;
  output += `========================================================\n`;
  output += `विषय (Subject): ${subj ? subj.name : 'General'}\n`;
  output += `सब-ब्लॉक (Sub-Category): ${subCat ? subCat.name : 'All'}\n`;
  output += `कुल प्रश्न: ${quiz.questions.length} | दिनांक: ${new Date(quiz.createdAt).toLocaleDateString('hi-IN')}\n`;
  if (quiz.description) {
    output += `विवरण: ${quiz.description}\n`;
  }
  output += `--------------------------------------------------------\n\n`;

  quiz.questions.forEach((q, idx) => {
    output += `प्रश्न ${idx + 1}. ${q.text}\n`;
    q.options.forEach((opt, oIdx) => {
      output += `   (${String.fromCharCode(65 + oIdx)}) ${opt}\n`;
    });

    if (includeAnswers) {
      output += `   >> सही उत्तर: (${String.fromCharCode(65 + q.correctIndex)}) ${q.options[q.correctIndex]}\n`;
      if (q.explanation) {
        output += `   >> विस्तृत व्याख्या: ${q.explanation}\n`;
      }
    }
    output += `\n`;
  });

  if (includeAnswers) {
    output += `========================================================\n`;
    output += `                 उत्तर कुंजी (ANSWER KEY)\n`;
    output += `========================================================\n`;
    quiz.questions.forEach((q, idx) => {
      output += `Q${idx + 1}: (${String.fromCharCode(65 + q.correctIndex)})  `;
      if ((idx + 1) % 5 === 0) output += `\n`;
    });
    output += `\n\n========================================================\n`;
    output += `Generated via ProQuiz App\n`;
  }

  const safeTitle = quiz.title.replace(/[^a-zA-Z0-9_\u0900-\u097F]/g, '_').substring(0, 40);
  downloadFile(output, `${safeTitle || 'Quiz'}_Question_Paper.txt`, 'text/plain;charset=utf-8');
}

/**
 * 2. Download Quiz as JSON data (.json)
 */
export function downloadQuizAsJson(quiz: Quiz) {
  const jsonContent = JSON.stringify(quiz, null, 2);
  const safeTitle = quiz.title.replace(/[^a-zA-Z0-9_\u0900-\u097F]/g, '_').substring(0, 40);
  downloadFile(jsonContent, `${safeTitle || 'Quiz'}_data.json`, 'application/json;charset=utf-8');
}

/**
 * 3. Download All Quizzes as Complete Backup (.json)
 */
export function downloadAllQuizzesAsJson(quizzes: Quiz[]) {
  const backupData = {
    appName: 'ProQuiz',
    exportedAt: new Date().toISOString(),
    totalQuizzes: quizzes.length,
    quizzes: quizzes,
  };
  const jsonContent = JSON.stringify(backupData, null, 2);
  const dateStr = new Date().toISOString().split('T')[0];
  downloadFile(jsonContent, `ProQuiz_All_Tests_Backup_${dateStr}.json`, 'application/json;charset=utf-8');
}

/**
 * 4. Generate & Download Printable Question Paper / PDF-ready HTML Document
 */
export function downloadQuizAsPrintableHtml(
  quiz: Quiz,
  options: { includeAnswers: boolean; includeExplanations: boolean; autoPrint?: boolean } = {
    includeAnswers: true,
    includeExplanations: true,
    autoPrint: false,
  }
) {
  const subj = SUBJECTS_DATA.find((s) => s.id === quiz.subjectId);
  const subCat = subj?.subcategories.find((sc) => sc.id === quiz.subCategoryId);

  const html = `<!DOCTYPE html>
<html lang="hi">
<head>
  <meta charset="UTF-8">
  <title>${quiz.title} - Question Paper</title>
  <style>
    @page {
      size: A4;
      margin: 15mm 15mm 20mm 15mm;
    }
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, 'Noto Sans Devanagari', sans-serif;
      color: #1e293b;
      line-height: 1.5;
      padding: 20px;
      max-width: 850px;
      margin: 0 auto;
      background: #fff;
    }
    .header {
      text-align: center;
      border-bottom: 2px solid #0f172a;
      padding-bottom: 12px;
      margin-bottom: 20px;
    }
    .header h1 {
      margin: 0 0 6px 0;
      font-size: 24px;
      color: #0f172a;
    }
    .header .meta {
      font-size: 13px;
      color: #475569;
      display: flex;
      justify-content: space-between;
      border-top: 1px solid #e2e8f0;
      padding-top: 8px;
      margin-top: 8px;
    }
    .instructions {
      background: #f8fafc;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      padding: 10px 14px;
      font-size: 12px;
      margin-bottom: 24px;
      color: #334155;
    }
    .question-block {
      margin-bottom: 18px;
      padding-bottom: 14px;
      border-bottom: 1px dashed #cbd5e1;
      page-break-inside: avoid;
    }
    .q-title {
      font-weight: 700;
      font-size: 15px;
      margin-bottom: 8px;
      color: #0f172a;
    }
    .options-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 6px 14px;
      margin-left: 12px;
      font-size: 13.5px;
    }
    .opt {
      padding: 4px 6px;
      border-radius: 4px;
    }
    .correct-opt {
      background: #dcfce7;
      color: #14532d;
      font-weight: 600;
    }
    .explanation-box {
      margin-top: 8px;
      margin-left: 12px;
      background: #fef3c7;
      border-left: 4px solid #f59e0b;
      padding: 6px 10px;
      font-size: 12.5px;
      color: #78350f;
      border-radius: 0 6px 6px 0;
    }
    .answer-key-section {
      page-break-before: always;
      margin-top: 30px;
      border-top: 2px solid #0f172a;
      padding-top: 16px;
    }
    .key-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
      font-size: 13px;
    }
    .key-table th, .key-table td {
      border: 1px solid #cbd5e1;
      padding: 6px 10px;
      text-align: center;
    }
    .key-table th {
      background: #f1f5f9;
      font-weight: bold;
    }
    .no-print-bar {
      background: #2563eb;
      color: #fff;
      padding: 12px 20px;
      border-radius: 10px;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .btn {
      background: #fff;
      color: #1d4ed8;
      border: none;
      padding: 8px 16px;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      font-size: 13px;
    }
    .btn:hover { background: #eff6ff; }
    @media print {
      .no-print-bar { display: none !important; }
      body { padding: 0; }
    }
  </style>
</head>
<body>
  <div class="no-print-bar">
    <div>
      <strong>ProQuiz प्रश्न-पत्र (Print / Save as PDF)</strong>
      <div style="font-size: 11px; opacity: 0.9;">ब्राउज़र के 'Save as PDF' विकल्प से PDF फाइल में सुरक्षित करें।</div>
    </div>
    <button class="btn" onclick="window.print()">🖨️ Print / Save as PDF</button>
  </div>

  <div class="header">
    <h1>${quiz.title}</h1>
    <div style="font-size: 14px; color: #475569; margin-bottom: 4px;">
      विषय: <strong>${subj ? subj.name : 'General'}</strong> | <strong>${subCat ? subCat.name : ''}</strong>
    </div>
    <div class="meta">
      <span>कुल प्रश्न: <strong>${quiz.questions.length}</strong></span>
      <span>पूर्णांक: <strong>${quiz.questions.length} अंक</strong></span>
      <span>समय: <strong>${Math.max(15, quiz.questions.length * 2)} मिनट</strong></span>
    </div>
  </div>

  <div class="instructions">
    <strong>निर्देश (Instructions):</strong> प्रत्येक प्रश्न के चार विकल्प दिए गए हैं। सभी प्रश्न अनिवार्य हैं। प्रत्येक सही उत्तर के लिए 1 अंक निर्धारित है।
  </div>

  <div class="questions-list">
    ${quiz.questions
      .map(
        (q, idx) => `
      <div class="question-block">
        <div class="q-title">प्र. ${idx + 1}. ${q.text}</div>
        <div class="options-grid">
          ${q.options
            .map(
              (opt, oIdx) => `
            <div class="opt ${options.includeAnswers && oIdx === q.correctIndex ? 'correct-opt' : ''}">
              (${String.fromCharCode(65 + oIdx)}) ${opt}
              ${options.includeAnswers && oIdx === q.correctIndex ? ' ✔' : ''}
            </div>
          `
            )
            .join('')}
        </div>
        ${
          options.includeExplanations && q.explanation
            ? `<div class="explanation-box"><strong>व्याख्या:</strong> ${q.explanation}</div>`
            : ''
        }
      </div>
    `
      )
      .join('')}
  </div>

  ${
    options.includeAnswers
      ? `
  <div class="answer-key-section">
    <h3 style="margin-top:0;">उत्तर कुंजी (Official Answer Key)</h3>
    <table class="key-table">
      <thead>
        <tr>
          <th>प्रश्न</th><th>उत्तर</th><th>प्रश्न</th><th>उत्तर</th><th>प्रश्न</th><th>उत्तर</th><th>प्रश्न</th><th>उत्तर</th>
        </tr>
      </thead>
      <tbody>
        ${Array.from({ length: Math.ceil(quiz.questions.length / 4) })
          .map((_, rIdx) => {
            let rowHtml = '<tr>';
            for (let c = 0; c < 4; c++) {
              const qIndex = rIdx * 4 + c;
              if (qIndex < quiz.questions.length) {
                rowHtml += `<td><strong>Q${qIndex + 1}</strong></td><td><strong>(${String.fromCharCode(
                  65 + quiz.questions[qIndex].correctIndex
                )})</strong></td>`;
              } else {
                rowHtml += `<td>-</td><td>-</td>`;
              }
            }
            rowHtml += '</tr>';
            return rowHtml;
          })
          .join('')}
      </tbody>
    </table>
  </div>
  `
      : ''
  }

  ${options.autoPrint ? '<script>window.onload = function() { window.print(); };</script>' : ''}
</body>
</html>`;

  const safeTitle = quiz.title.replace(/[^a-zA-Z0-9_\u0900-\u097F]/g, '_').substring(0, 40);
  downloadFile(html, `${safeTitle || 'Quiz'}_Printable_Paper.html`, 'text/html;charset=utf-8');
}

/**
 * 5. Download Standalone Offline App (.html)
 * An all-in-one HTML file containing current quizzes that runs completely offline on any browser!
 */
export function downloadOfflineAppHtml(quizzes: Quiz[]) {
  const jsonQuizzes = JSON.stringify(quizzes).replace(/<\/script>/gi, '<\\/script>');

  const html = `<!DOCTYPE html>
<html lang="hi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ProQuiz - Offline Test Series</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f8fafc; }
  </style>
</head>
<body class="min-h-screen text-slate-800 flex flex-col">
  <header class="bg-blue-700 text-white p-4 shadow-md sticky top-0 z-20">
    <div class="max-w-4xl mx-auto flex justify-between items-center">
      <h1 class="font-extrabold text-xl flex items-center gap-2 cursor-pointer" onclick="showHome()">
        <span>🧠</span> ProQuiz <span class="text-xs bg-amber-400 text-blue-950 font-bold px-2 py-0.5 rounded">OFFLINE FILE</span>
      </h1>
      <span class="text-xs text-blue-100 bg-blue-800/80 px-3 py-1 rounded-full">बिना इंटरनेट चलने योग्य</span>
    </div>
  </header>

  <main class="max-w-4xl mx-auto p-4 sm:p-6 flex-1 w-full">
    <!-- Home List -->
    <div id="screen-home" class="space-y-4">
      <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm text-center space-y-2">
        <h2 class="text-2xl font-bold text-slate-900">ऑफलाइन टेस्ट पेपर्स</h2>
        <p class="text-xs text-slate-500">यह फाइल आपके डिवाइस पर बिना किसी इंटरनेट कनेक्शन के पूरी तरह काम करती है।</p>
      </div>

      <div id="quiz-cards" class="grid grid-cols-1 md:grid-cols-2 gap-4"></div>
    </div>

    <!-- Quiz Player -->
    <div id="screen-play" class="hidden space-y-4">
      <div class="bg-white p-4 rounded-xl border border-slate-200 flex justify-between items-center shadow-xs">
        <div>
          <h3 id="play-title" class="font-bold text-slate-900">Quiz Title</h3>
          <span id="play-counter" class="text-xs text-blue-600 font-semibold">1 / 5</span>
        </div>
        <button onclick="showHome()" class="text-xs px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg font-medium">वापस जाएं</button>
      </div>

      <div id="play-card" class="bg-white p-6 rounded-2xl border border-slate-200 shadow-md space-y-5">
        <h4 id="q-text" class="text-lg font-bold text-slate-900">Question goes here</h4>
        <div id="q-options" class="space-y-2.5"></div>
        <div class="pt-4 border-t flex justify-end">
          <button id="btn-next" onclick="nextQuestion()" class="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm transition">अगला प्रश्न</button>
        </div>
      </div>

      <!-- Result Area -->
      <div id="play-result" class="hidden bg-white p-6 rounded-2xl border border-slate-200 shadow-lg space-y-6">
        <div class="text-center space-y-2">
          <div class="text-5xl">🏆</div>
          <h3 class="text-2xl font-bold text-slate-900">टेस्ट पूरा हुआ!</h3>
          <p class="text-lg font-bold text-blue-600">स्कोर: <span id="score-display">0 / 0</span></p>
          <button onclick="showHome()" class="px-5 py-2 bg-blue-600 text-white rounded-xl font-bold text-sm">मुख्य पृष्ठ</button>
        </div>
        <div id="review-area" class="space-y-4 pt-4 border-t"></div>
      </div>
    </div>
  </main>

  <footer class="bg-white border-t border-slate-200 p-4 text-center text-xs text-slate-400">
    ProQuiz Offline Export File • Powered by Gemini AI
  </footer>

  <script>
    const QUIZZES = ${jsonQuizzes};
    let currentQuiz = null;
    let currentIdx = 0;
    let userAnswers = [];

    function showHome() {
      document.getElementById('screen-home').classList.remove('hidden');
      document.getElementById('screen-play').classList.add('hidden');
      renderCards();
    }

    function renderCards() {
      const container = document.getElementById('quiz-cards');
      container.innerHTML = '';
      if (QUIZZES.length === 0) {
        container.innerHTML = '<p class="col-span-2 text-center text-slate-400 py-8">कोई टेस्ट उपलब्ध नहीं है।</p>';
        return;
      }
      QUIZZES.forEach(q => {
        const div = document.createElement('div');
        div.className = 'bg-white p-5 rounded-2xl border border-slate-200 hover:shadow-md transition space-y-3';
        div.innerHTML = \`
          <h4 class="font-bold text-slate-900 text-base">\${q.title}</h4>
          <p class="text-xs text-slate-500">\${q.description || 'अभ्यास मॉक टेस्ट'}</p>
          <div class="flex justify-between items-center pt-2 border-t">
            <span class="text-xs bg-blue-50 text-blue-700 px-2.5 py-1 rounded-full font-bold">\${q.questions.length} प्रश्न</span>
            <button onclick="startQuiz('\${q.id}')" class="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl">टेस्ट शुरू करें</button>
          </div>
        \`;
        container.appendChild(div);
      });
    }

    function startQuiz(id) {
      currentQuiz = QUIZZES.find(q => q.id === id);
      if (!currentQuiz) return;
      currentIdx = 0;
      userAnswers = new Array(currentQuiz.questions.length).fill(null);
      document.getElementById('screen-home').classList.add('hidden');
      document.getElementById('screen-play').classList.remove('hidden');
      document.getElementById('play-card').classList.remove('hidden');
      document.getElementById('play-result').classList.add('hidden');
      document.getElementById('play-title').innerText = currentQuiz.title;
      renderQuestion();
    }

    function renderQuestion() {
      const q = currentQuiz.questions[currentIdx];
      document.getElementById('play-counter').innerText = \`\${currentIdx + 1} / \${currentQuiz.questions.length}\`;
      document.getElementById('q-text').innerText = \`Q\${currentIdx + 1}. \${q.text}\`;
      const optsContainer = document.getElementById('q-options');
      optsContainer.innerHTML = '';

      const btnNext = document.getElementById('btn-next');
      btnNext.innerText = (currentIdx === currentQuiz.questions.length - 1) ? 'सबमिट करें' : 'अगला प्रश्न';

      q.options.forEach((opt, idx) => {
        const btn = document.createElement('button');
        const isSelected = userAnswers[currentIdx] === idx;
        btn.className = \`w-full text-left p-3.5 rounded-xl border text-sm font-medium transition \${
          isSelected ? 'border-blue-600 bg-blue-50 text-blue-900 font-bold' : 'border-slate-200 hover:bg-slate-50'
        }\`;
        btn.onclick = () => {
          userAnswers[currentIdx] = idx;
          renderQuestion();
        };
        btn.innerHTML = \`<span class="w-6 font-bold inline-block">\${String.fromCharCode(65 + idx)}.</span> \${opt}\`;
        optsContainer.appendChild(btn);
      });
    }

    function nextQuestion() {
      if (currentIdx < currentQuiz.questions.length - 1) {
        currentIdx++;
        renderQuestion();
      } else {
        finishQuiz();
      }
    }

    function finishQuiz() {
      document.getElementById('play-card').classList.add('hidden');
      const res = document.getElementById('play-result');
      res.classList.remove('hidden');

      let score = 0;
      currentQuiz.questions.forEach((q, idx) => {
        if (userAnswers[idx] === q.correctIndex) score++;
      });
      document.getElementById('score-display').innerText = \`\${score} / \${currentQuiz.questions.length}\`;

      const rev = document.getElementById('review-area');
      rev.innerHTML = '<h4 class="font-bold text-slate-800">विस्तृत व्याख्या:</h4>';
      currentQuiz.questions.forEach((q, idx) => {
        const isCorrect = userAnswers[idx] === q.correctIndex;
        const box = document.createElement('div');
        box.className = \`p-4 rounded-xl border text-xs sm:text-sm \${isCorrect ? 'border-green-300 bg-green-50' : 'border-red-300 bg-red-50'}\`;
        box.innerHTML = \`
          <div class="font-bold text-slate-900 mb-1">Q\${idx + 1}. \${q.text}</div>
          <div class="text-xs text-green-800 font-bold">सही उत्तर: (\${String.fromCharCode(65 + q.correctIndex)}) \${q.options[q.correctIndex]}</div>
          <div class="mt-2 bg-amber-50 p-2.5 rounded border border-amber-200 text-amber-900 text-xs">
            <strong>व्याख्या:</strong> \${q.explanation || 'प्रामाणिक उत्तर।'}
          </div>
        \`;
        rev.appendChild(box);
      });
    }

    window.onload = renderCards;
  </script>
</body>
</html>`;

  downloadFile(html, `ProQuiz_Offline_App_${new Date().toISOString().split('T')[0]}.html`, 'text/html;charset=utf-8');
}
