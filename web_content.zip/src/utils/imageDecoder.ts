import type { DecodedPageAsset, DecodedTile } from '../types/comic';

const MIME_BY_EXT: Record<string, string> = {
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  png: 'image/png',
  webp: 'image/webp',
  avif: 'image/avif',
  jxl: 'image/jxl',
  gif: 'image/gif',
  bmp: 'image/bmp',
  svg: 'image/svg+xml',
};

export function getImageExtension(fileName: string): string {
  const parts = fileName.toLowerCase().split('.');
  return parts.length > 1 ? parts[parts.length - 1] : '';
}

export function isSupportedImageFile(fileName: string): boolean {
  const base = fileName.split('/').pop() || fileName;
  if (!base || base.startsWith('.') || base.startsWith('__MACOSX')) return false;
  if (fileName.includes('__MACOSX/')) return false;
  const ext = getImageExtension(base);
  return ext in MIME_BY_EXT;
}

export function getMimeType(ext: string): string {
  return MIME_BY_EXT[ext.toLowerCase()] || 'application/octet-stream';
}

let jxlInitPromise: Promise<(buf: ArrayBuffer) => Promise<ImageData>> | null = null;

async function getJxlDecoder(): Promise<(buf: ArrayBuffer) => Promise<ImageData>> {
  if (!jxlInitPromise) {
    jxlInitPromise = (async () => {
      const mod = await import('@jsquash/jxl/decode');
      const wasmResponse = await fetch('/wasm/jxl_dec.wasm');
      if (wasmResponse.ok) {
        try {
          const wasmBytes = await wasmResponse.arrayBuffer();
          const wasmModule = await WebAssembly.compile(wasmBytes);
          await mod.init(wasmModule);
        } catch {
          await mod.init();
        }
      } else {
        await mod.init();
      }
      return mod.default;
    })();
  }
  return jxlInitPromise;
}

let nativeJxlSupported: boolean | null = null;

async function checkNativeJxl(bytes: Uint8Array): Promise<boolean> {
  if (nativeJxlSupported !== null) return nativeJxlSupported;
  try {
    const blob = new Blob([bytes as BlobPart], { type: 'image/jxl' });
    const bmp = await createImageBitmap(blob);
    bmp.close();
    nativeJxlSupported = true;
  } catch {
    nativeJxlSupported = false;
  }
  return nativeJxlSupported;
}

async function imageDataToBlob(imageData: ImageData): Promise<Blob> {
  if (typeof OffscreenCanvas !== 'undefined') {
    const canvas = new OffscreenCanvas(imageData.width, imageData.height);
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.putImageData(imageData, 0, 0);
      return await canvas.convertToBlob({ type: 'image/webp', quality: 0.92 });
    }
  }
  const canvas = document.createElement('canvas');
  canvas.width = imageData.width;
  canvas.height = imageData.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('2D context unavailable');
  ctx.putImageData(imageData, 0, 0);
  return await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error('Canvas encoding failed'))),
      'image/webp',
      0.92,
    );
  });
}

/**
 * Converts raw archive entry bytes into a browser-decodable Blob (handling JXL via WASM if needed).
 */
export async function toRenderableBlob(bytes: Uint8Array, ext: string): Promise<Blob> {
  const lower = ext.toLowerCase();
  if (lower === 'jxl') {
    const canNative = await checkNativeJxl(bytes);
    if (canNative) {
      return new Blob([bytes as BlobPart], { type: 'image/jxl' });
    }
    const decodeJxl = await getJxlDecoder();
    const copy = bytes.slice().buffer;
    const imageData = await decodeJxl(copy);
    return await imageDataToBlob(imageData);
  }
  return new Blob([bytes as BlobPart], { type: getMimeType(lower) });
}

async function renderTileFromBitmap(
  bitmap: ImageBitmap,
  sy: number,
  sh: number,
): Promise<Blob> {
  const w = bitmap.width;
  if (typeof OffscreenCanvas !== 'undefined') {
    const canvas = new OffscreenCanvas(w, sh);
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(bitmap, 0, sy, w, sh, 0, 0, w, sh);
      return await canvas.convertToBlob({ type: 'image/webp', quality: 0.92 });
    }
  }
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = sh;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('2D context unavailable');
  ctx.drawImage(bitmap, 0, sy, w, sh, 0, 0, w, sh);
  return await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error('Tile encode failed'))),
      'image/webp',
      0.92,
    );
  });
}

const MAX_GPU_SLICE_HEIGHT = 2048;
const SLICE_TRIGGER_HEIGHT = 3000;

/**
 * Decodes a comic page with optional hardware-accelerated ImageBitmap pre-decode
 * and automatic vertical strip slicing for ultra-long webtoon images so Android
 * GPUs never exceed max texture dimensions or drop frames while scrolling.
 */
export async function decodeComicPage(
  bytes: Uint8Array,
  index: number,
  name: string,
  ext: string,
  options: { hardwareAccel: boolean; sliceLongStrips: boolean },
): Promise<DecodedPageAsset> {
  const blob = await toRenderableBlob(bytes, ext);
  const createdUrls: string[] = [];

  const cleanup = () => {
    for (const u of createdUrls) {
      URL.revokeObjectURL(u);
    }
  };

  // Try ImageBitmap decode off the layout path for exact dimensions & GPU readiness
  if (typeof createImageBitmap === 'function' && ext.toLowerCase() !== 'svg') {
    try {
      const bitmap = await createImageBitmap(blob, {
        premultiplyAlpha: 'default',
        colorSpaceConversion: 'default',
      });
      const width = bitmap.width;
      const height = bitmap.height;

      const needsSlice =
        options.sliceLongStrips &&
        (height > SLICE_TRIGGER_HEIGHT || height / Math.max(1, width) > 3.2);

      if (needsSlice) {
        const tiles: DecodedTile[] = [];
        for (let sy = 0; sy < height; sy += MAX_GPU_SLICE_HEIGHT) {
          const sh = Math.min(MAX_GPU_SLICE_HEIGHT, height - sy);
          const tileBlob = await renderTileFromBitmap(bitmap, sy, sh);
          const url = URL.createObjectURL(tileBlob);
          createdUrls.push(url);
          tiles.push({ url, width, height: sh });
        }
        bitmap.close();
        return {
          index,
          name,
          ext,
          width,
          height,
          wasSliced: true,
          tiles,
          revoke: cleanup,
        };
      }

      bitmap.close();
      const url = URL.createObjectURL(blob);
      createdUrls.push(url);
      return {
        index,
        name,
        ext,
        width,
        height,
        wasSliced: false,
        tiles: [{ url, width, height }],
        revoke: cleanup,
      };
    } catch {
      // Fallback to standard ObjectURL if ImageBitmap fails (e.g. animated GIF edge case)
    }
  }

  const url = URL.createObjectURL(blob);
  createdUrls.push(url);
  const dims = await measureImageUrl(url).catch(() => ({ width: 800, height: 1200 }));
  return {
    index,
    name,
    ext,
    width: dims.width,
    height: dims.height,
    wasSliced: false,
    tiles: [{ url, width: dims.width, height: dims.height }],
    revoke: cleanup,
  };
}

function measureImageUrl(url: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve({ width: img.naturalWidth || 800, height: img.naturalHeight || 1200 });
    img.onerror = () => reject(new Error('Failed to measure image'));
    img.src = url;
  });
}

/**
 * Creates a compact WebP/JPEG cover thumbnail (~360px wide) for instant library grid rendering.
 */
export async function createCoverThumbnailBlob(
  bytes: Uint8Array,
  ext: string,
): Promise<Blob | undefined> {
  try {
    const blob = await toRenderableBlob(bytes, ext);
    if (typeof createImageBitmap !== 'function') return blob;

    const bmp = await createImageBitmap(blob);
    const targetW = Math.min(360, bmp.width);
    const ratio = targetW / Math.max(1, bmp.width);
    const targetH = Math.max(1, Math.round(bmp.height * ratio));

    if (typeof OffscreenCanvas !== 'undefined') {
      const canvas = new OffscreenCanvas(targetW, targetH);
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(bmp, 0, 0, targetW, targetH);
        bmp.close();
        return await canvas.convertToBlob({ type: 'image/webp', quality: 0.82 });
      }
    }

    const canvas = document.createElement('canvas');
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(bmp, 0, 0, targetW, targetH);
      bmp.close();
      return await new Promise<Blob | undefined>((resolve) => {
        canvas.toBlob((b) => resolve(b ?? blob), 'image/webp', 0.82);
      });
    }
    bmp.close();
    return blob;
  } catch {
    return undefined;
  }
}
