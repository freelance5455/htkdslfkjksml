import { DateTime } from 'luxon';
import { KillZoneInfo } from '../types';

export const NY_ZONE = 'America/New_York';
export const INDIA_ZONE = 'Asia/Kolkata';

/**
 * Get current DateTime in New York timezone
 */
export function getCurrentNYDateTime(): DateTime {
  return DateTime.now().setZone(NY_ZONE);
}

/**
 * Get current DateTime in India (IST) timezone
 */
export function getCurrentIndiaDateTime(): DateTime {
  return DateTime.now().setZone(INDIA_ZONE);
}

/**
 * Create a DateTime in New York timezone from day, month, year, hour, minute, second
 */
export function createNYDateTime(
  year: number,
  month: number,
  day: number,
  hour: number,
  minute: number,
  second: number
): DateTime {
  return DateTime.fromObject(
    { year, month, day, hour, minute, second, millisecond: 0 },
    { zone: NY_ZONE }
  );
}

/**
 * Parse input strings (date: DD/MM/YYYY or YYYY-MM-DD, time: HH:mm:ss) into New York DateTime
 */
export function parseNYInput(dateStr: string, timeStr: string): DateTime {
  let year = 2025;
  let month = 5;
  let day = 16;

  // Handle DD/MM/YYYY or YYYY-MM-DD
  if (dateStr.includes('/')) {
    const parts = dateStr.split('/');
    if (parts.length === 3) {
      day = parseInt(parts[0], 10) || 1;
      month = parseInt(parts[1], 10) || 1;
      year = parseInt(parts[2], 10) || 2025;
    }
  } else if (dateStr.includes('-')) {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      year = parseInt(parts[0], 10) || 2025;
      month = parseInt(parts[1], 10) || 1;
      day = parseInt(parts[2], 10) || 1;
    }
  }

  let hour = 8;
  let minute = 46;
  let second = 0;

  if (timeStr) {
    const timeParts = timeStr.split(':');
    hour = parseInt(timeParts[0], 10) || 0;
    minute = parseInt(timeParts[1], 10) || 0;
    second = parseInt(timeParts[2], 10) || 0;
  }

  // Constrain bounds
  hour = Math.min(23, Math.max(0, hour));
  minute = Math.min(59, Math.max(0, minute));
  second = Math.min(59, Math.max(0, second));

  return createNYDateTime(year, month, day, hour, minute, second);
}

/**
 * Format date for display: "Fri, May 16, 2025"
 */
export function formatDisplayDate(dt: DateTime): string {
  if (!dt.isValid) return '--';
  return dt.toFormat('ccc, LLL d, yyyy');
}

/**
 * Format time for display: "08:46:15 AM" or "20:46:15"
 */
export function formatDisplayTime(dt: DateTime, use24Hour: boolean = false): string {
  if (!dt.isValid) return '--:--:--';
  if (use24Hour) {
    return dt.toFormat('HH:mm:ss');
  }
  return dt.toFormat('hh:mm:ss a');
}

/**
 * Format input date as "DD/MM/YYYY" (matching screenshot)
 */
export function formatInputDate(dt: DateTime): string {
  if (!dt.isValid) return '16/05/2025';
  return dt.toFormat('dd/MM/yyyy');
}

/**
 * Format input time as "HH:mm:ss" (matching screenshot)
 */
export function formatInputTime(dt: DateTime): string {
  if (!dt.isValid) return '08:46:00';
  return dt.toFormat('HH:mm:ss');
}

/**
 * Convert DateTime to HTML input[type="date"] format: "YYYY-MM-DD"
 */
export function toHtmlDateValue(dt: DateTime): string {
  if (!dt.isValid) return '2025-05-16';
  return dt.toFormat('yyyy-MM-dd');
}

/**
 * Get New York timezone abbreviation (EDT or EST)
 */
export function getNYTzAbbr(dt: DateTime): string {
  if (!dt.isValid) return 'EST';
  return dt.isInDST ? 'EDT' : 'EST';
}

/**
 * Calculate difference in hours & minutes between India and New York
 * IST is UTC+5:30. EDT is UTC-4 (9h 30m diff). EST is UTC-5 (10h 30m diff).
 */
export function getOffsetDiffDescription(nyDt: DateTime): {
  diffFormatted: string;
  nyOffsetLabel: string;
  isDST: boolean;
} {
  const isDST = nyDt.isInDST;
  const diffMinutes = 330 - nyDt.offset; // IST is +330 min
  const hours = Math.floor(diffMinutes / 60);
  const minutes = diffMinutes % 60;
  
  const diffFormatted = minutes > 0 ? `+${hours}h ${minutes}m` : `+${hours}h`;
  const nyOffsetLabel = isDST ? 'EDT (UTC-4)' : 'EST (UTC-5)';

  return {
    diffFormatted,
    nyOffsetLabel,
    isDST,
  };
}

/**
 * Identify the 4 Jaswanth Kill Zones and check if active based on New York time:
 * A. Asian Kill Zone: 7:00 PM – 10:00 PM NY
 * B. London Kill Zone: 2:00 AM – 5:00 AM NY
 * C. New York AM Kill Zone: 7:00 AM – 10:00 AM NY
 * D. London Close Kill Zone: 10:00 AM – 12:00 PM NY
 */
export function getJaswanthKillZones(nyDt: DateTime): KillZoneInfo[] {
  const hour = nyDt.hour;
  const minute = nyDt.minute;
  const totalMinutes = hour * 60 + minute;

  return [
    {
      id: 'asian',
      name: 'Asian Kill Zone',
      nyTimeRange: '7:00 PM – 10:00 PM',
      summerIstRange: '4:30 AM – 7:30 AM (next day)',
      winterIstRange: '5:30 AM – 8:30 AM (next day)',
      isActive: totalMinutes >= 19 * 60 && totalMinutes < 22 * 60,
    },
    {
      id: 'london',
      name: 'London Kill Zone',
      nyTimeRange: '2:00 AM – 5:00 AM',
      summerIstRange: '11:30 AM – 2:30 PM',
      winterIstRange: '12:30 PM – 3:30 PM',
      isActive: totalMinutes >= 2 * 60 && totalMinutes < 5 * 60,
    },
    {
      id: 'ny_am',
      name: 'New York AM Kill Zone',
      nyTimeRange: '7:00 AM – 10:00 AM',
      summerIstRange: '4:30 PM – 7:30 PM',
      winterIstRange: '5:30 PM – 8:30 PM',
      isActive: totalMinutes >= 7 * 60 && totalMinutes < 10 * 60,
    },
    {
      id: 'london_close',
      name: 'London Close Kill Zone',
      nyTimeRange: '10:00 AM – 12:00 PM',
      summerIstRange: '7:30 PM – 9:30 PM',
      winterIstRange: '8:30 PM – 10:30 PM',
      isActive: totalMinutes >= 10 * 60 && totalMinutes < 12 * 60,
    },
  ];
}
