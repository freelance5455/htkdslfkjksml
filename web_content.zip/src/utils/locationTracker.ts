import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase.ts';
import { TechnicianLocation, LocationHistoryPoint, LocationStatusCategory } from '../types/index.ts';
import { removeUndefinedFields } from './firestoreHelper.ts';

// Calculate relative time string e.g. "12s ago", "2m ago", "45m ago"
export function formatRelativeTime(isoDate: string): string {
  if (!isoDate) return 'Unknown';
  const diffSec = Math.max(0, Math.floor((Date.now() - new Date(isoDate).getTime()) / 1000));
  if (diffSec < 10) return 'Just now';
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays}d ago`;
}

// Categorize status based on timestamp freshness:
// Live: < 3 mins
// Recent: 3 - 15 mins
// Offline / Stale: > 15 mins
export function getLocationStatusCategory(updatedAt: string): LocationStatusCategory {
  if (!updatedAt) return 'offline';
  const ageMs = Date.now() - new Date(updatedAt).getTime();
  if (ageMs < 3 * 60 * 1000) return 'live';
  if (ageMs < 15 * 60 * 1000) return 'recent';
  return 'offline';
}

// Haversine distance in meters
export function calculateDistanceMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371e3; // Earth radius in meters
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round(R * c);
}

// Global active tracking tracker
let watchId: number | null = null;
let lastPublishTime = 0;
let lastHistoryTime = 0;
const PUBLISH_THROTTLE_MS = 25000; // 25 seconds between live updates to save battery and network
const HISTORY_THROTTLE_MS = 3 * 60 * 1000; // 3 minutes between breadcrumbs

export interface TrackerState {
  isTracking: boolean;
  permissionStatus: 'granted' | 'denied' | 'prompt' | 'unsupported';
  lastCoords: { lat: number; lng: number; accuracy?: number } | null;
  lastUpdate: string | null;
  errorMessage: string | null;
}

type TrackerListener = (state: TrackerState) => void;
const listeners = new Set<TrackerListener>();

let currentState: TrackerState = {
  isTracking: false,
  permissionStatus: 'prompt',
  lastCoords: null,
  lastUpdate: null,
  errorMessage: null,
};

function notifyListeners() {
  listeners.forEach((fn) => fn(currentState));
}

export function subscribeTrackerState(listener: TrackerListener): () => void {
  listeners.add(listener);
  listener(currentState);
  return () => {
    listeners.delete(listener);
  };
}

// Check permission status
export async function checkGeolocationPermission(): Promise<TrackerState['permissionStatus']> {
  if (!navigator.geolocation) {
    currentState.permissionStatus = 'unsupported';
    notifyListeners();
    return 'unsupported';
  }

  try {
    if (navigator.permissions && navigator.permissions.query) {
      const result = await navigator.permissions.query({ name: 'geolocation' as PermissionName });
      currentState.permissionStatus = result.state as 'granted' | 'denied' | 'prompt';
      result.onchange = () => {
        currentState.permissionStatus = result.state as 'granted' | 'denied' | 'prompt';
        notifyListeners();
      };
    }
  } catch (e) {
    // Permission API might not support geolocation in some webviews
  }
  notifyListeners();
  return currentState.permissionStatus;
}

// Start active tracking for an employee while on shift
export function startTechnicianLiveTracking(params: {
  orgId: string;
  employeeId: string;
  employeeName: string;
  employeeCode?: string;
  department?: string;
  phone?: string;
  currentVisitTitle?: string;
  currentCustomerName?: string;
}) {
  if (watchId !== null) return; // Already watching

  if (!navigator.geolocation) {
    currentState.errorMessage = 'Geolocation is not supported by your mobile browser.';
    currentState.permissionStatus = 'unsupported';
    notifyListeners();
    return;
  }

  currentState.isTracking = true;
  currentState.errorMessage = null;
  notifyListeners();

  const handlePosition = async (pos: GeolocationPosition) => {
    const lat = Number(pos.coords.latitude.toFixed(6));
    const lng = Number(pos.coords.longitude.toFixed(6));
    const accuracy = Math.round(pos.coords.accuracy);
    const speed = pos.coords.speed !== null ? Number(pos.coords.speed.toFixed(1)) : undefined;
    const heading = pos.coords.heading !== null ? Math.round(pos.coords.heading) : undefined;
    const nowIso = new Date().toISOString();

    currentState.lastCoords = { lat, lng, accuracy };
    currentState.lastUpdate = nowIso;
    currentState.permissionStatus = 'granted';
    currentState.errorMessage = null;
    notifyListeners();

    // Check battery level if Web Battery API supported
    let batteryLevel: number | undefined = undefined;
    try {
      if ('getBattery' in navigator) {
        const battery = await (navigator as any).getBattery();
        batteryLevel = Math.round(battery.level * 100);
      }
    } catch {
      // ignore
    }

    const nowTime = Date.now();

    // 1. Throttle live location write to Firestore
    if (nowTime - lastPublishTime >= PUBLISH_THROTTLE_MS) {
      lastPublishTime = nowTime;

      const liveDoc: TechnicianLocation = {
        id: params.employeeId,
        orgId: params.orgId,
        employeeId: params.employeeId,
        employeeName: params.employeeName,
        employeeCode: params.employeeCode,
        department: params.department,
        phone: params.phone,
        lat,
        lng,
        accuracy,
        speed,
        heading,
        status: params.currentCustomerName ? 'at_customer' : 'active',
        currentVisitTitle: params.currentVisitTitle,
        currentCustomerName: params.currentCustomerName,
        batteryLevel,
        updatedAt: nowIso,
      };

      try {
        await setDoc(doc(db, 'technician_locations', params.employeeId), removeUndefinedFields(liveDoc), {
          merge: true,
        });
      } catch (err) {
        console.warn('Live location publish error:', err);
      }
    }

    // 2. Throttle location history trail recording
    if (nowTime - lastHistoryTime >= HISTORY_THROTTLE_MS) {
      lastHistoryTime = nowTime;
      const historyPoint: LocationHistoryPoint = {
        id: `loc_${params.employeeId}_${nowTime}`,
        orgId: params.orgId,
        employeeId: params.employeeId,
        employeeName: params.employeeName,
        lat,
        lng,
        accuracy,
        eventType: 'shift_active',
        timestamp: nowIso,
      };

      try {
        await setDoc(doc(db, 'location_history', historyPoint.id), removeUndefinedFields(historyPoint));
      } catch (err) {
        console.warn('Location history save error:', err);
      }
    }
  };

  const handleError = (err: GeolocationPositionError) => {
    let msg = 'Unable to retrieve location.';
    if (err.code === err.PERMISSION_DENIED) {
      msg = 'Location permission was denied. Please allow location access in your browser settings to verify field operations.';
      currentState.permissionStatus = 'denied';
    } else if (err.code === err.POSITION_UNAVAILABLE) {
      msg = 'GPS location is temporarily unavailable on your device.';
    } else if (err.code === err.TIMEOUT) {
      msg = 'Location request timed out. Retrying...';
    }
    currentState.errorMessage = msg;
    notifyListeners();
  };

  watchId = navigator.geolocation.watchPosition(handlePosition, handleError, {
    enableHighAccuracy: true,
    timeout: 15000,
    maximumAge: 10000,
  });
}

// Stop tracking (e.g. when punching out or logging out)
export async function stopTechnicianLiveTracking(employeeId?: string) {
  if (watchId !== null) {
    navigator.geolocation.clearWatch(watchId);
    watchId = null;
  }
  currentState.isTracking = false;
  notifyListeners();

  // If employee ID provided, set status to offline
  if (employeeId) {
    try {
      await setDoc(
        doc(db, 'technician_locations', employeeId),
        {
          status: 'offline',
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    } catch {
      // ignore
    }
  }
}

// Log a single milestone point (e.g. check in, check out, visit start, visit complete)
export async function logMilestoneLocation(params: {
  orgId: string;
  employeeId: string;
  employeeName: string;
  eventType: LocationHistoryPoint['eventType'];
  notes?: string;
  lat?: number;
  lng?: number;
  accuracy?: number;
}): Promise<void> {
  let { lat, lng, accuracy } = params;

  if (lat === undefined || lng === undefined) {
    if (currentState.lastCoords) {
      lat = currentState.lastCoords.lat;
      lng = currentState.lastCoords.lng;
      accuracy = currentState.lastCoords.accuracy;
    }
  }

  if (lat === undefined || lng === undefined) return;

  const nowIso = new Date().toISOString();
  const point: LocationHistoryPoint = {
    id: `loc_${params.employeeId}_${Date.now()}`,
    orgId: params.orgId,
    employeeId: params.employeeId,
    employeeName: params.employeeName,
    lat,
    lng,
    accuracy,
    eventType: params.eventType,
    notes: params.notes,
    timestamp: nowIso,
  };

  try {
    await setDoc(doc(db, 'location_history', point.id), removeUndefinedFields(point));
  } catch (err) {
    console.warn('Milestone location save error:', err);
  }
}
