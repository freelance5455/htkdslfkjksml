// Web Audio API synthesizer for DJ EVAN PRO UG Cue Effects
// No external assets required - runs instantly on any phone or desktop browser

class AudioCueEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private beatLoopInterval: number | null = null;
  private isBeatPlaying: boolean = false;

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  // Classic Dancehall Reggae Air Horn (Bwa-Bwa-Bwaaaaa)
  playAirHorn() {
    const ctx = this.initCtx();
    if (!ctx || this.isMuted) return;

    const blasts = [
      { start: 0, dur: 0.16 },
      { start: 0.20, dur: 0.16 },
      { start: 0.40, dur: 0.16 },
      { start: 0.60, dur: 0.45 },
    ];

    blasts.forEach(({ start, dur }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      osc.type = 'sawtooth';
      const baseFreq = 466.16; // Bb4
      osc.frequency.setValueAtTime(baseFreq, ctx.currentTime + start);
      osc.frequency.linearRampToValueAtTime(baseFreq * 1.05, ctx.currentTime + start + dur * 0.4);
      osc.frequency.linearRampToValueAtTime(baseFreq * 0.98, ctx.currentTime + start + dur);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(3200, ctx.currentTime + start);

      gain.gain.setValueAtTime(0, ctx.currentTime + start);
      gain.gain.linearRampToValueAtTime(0.4, ctx.currentTime + start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + dur);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + dur + 0.05);
    });
  }

  // DJ Scratch (Cross DJ Pro Stutter)
  playScratch() {
    const ctx = this.initCtx();
    if (!ctx || this.isMuted) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    osc.type = 'triangle';
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1400, ctx.currentTime);
    filter.Q.setValueAtTime(4, ctx.currentTime);

    const t = ctx.currentTime;
    // Fast back and forth pitch sweeps
    osc.frequency.setValueAtTime(300, t);
    osc.frequency.linearRampToValueAtTime(1800, t + 0.06);
    osc.frequency.linearRampToValueAtTime(400, t + 0.12);
    osc.frequency.linearRampToValueAtTime(2100, t + 0.18);
    osc.frequency.linearRampToValueAtTime(200, t + 0.28);

    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.45, t + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.32);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc.start(t);
    osc.stop(t + 0.35);
  }

  // Deep 808 Sub Drop
  play808Drop() {
    const ctx = this.initCtx();
    if (!ctx || this.isMuted) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    const t = ctx.currentTime;
    osc.frequency.setValueAtTime(140, t);
    osc.frequency.exponentialRampToValueAtTime(35, t + 0.7);

    gain.gain.setValueAtTime(0.6, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.8);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(t);
    osc.stop(t + 0.85);
  }

  // Club Laser Drop
  playLaser() {
    const ctx = this.initCtx();
    if (!ctx || this.isMuted) return;

    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(2400, t);
    osc.frequency.exponentialRampToValueAtTime(120, t + 0.25);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.26);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(t);
    osc.stop(t + 0.28);
  }

  // Kampala Reggae Siren Sweep
  playSiren() {
    const ctx = this.initCtx();
    if (!ctx || this.isMuted) return;

    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    // Siren wail up and down
    osc.frequency.setValueAtTime(500, t);
    osc.frequency.linearRampToValueAtTime(1200, t + 0.2);
    osc.frequency.linearRampToValueAtTime(500, t + 0.4);
    osc.frequency.linearRampToValueAtTime(1200, t + 0.6);
    osc.frequency.linearRampToValueAtTime(300, t + 0.85);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.linearRampToValueAtTime(0.35, t + 0.7);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.9);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(t);
    osc.stop(t + 0.95);
  }

  // Turntable Backspin / Rewind Wheel Up
  playRewind() {
    const ctx = this.initCtx();
    if (!ctx || this.isMuted) return;

    const t = ctx.currentTime;
    // White noise combined with fast descending tone
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(2000, t);
    osc.frequency.exponentialRampToValueAtTime(60, t + 0.6);

    gain.gain.setValueAtTime(0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.65);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(t);
    osc.stop(t + 0.7);
  }

  // Afrobeat/Amapiano Beat Demo Loop for the player
  toggleAfrobeatLoop(onStateChange?: (isPlaying: boolean) => void) {
    if (this.isBeatPlaying) {
      this.stopAfrobeatLoop();
      onStateChange?.(false);
      return false;
    } else {
      this.startAfrobeatLoop();
      onStateChange?.(true);
      return true;
    }
  }

  startAfrobeatLoop() {
    const ctx = this.initCtx();
    if (!ctx) return;
    this.isBeatPlaying = true;

    let step = 0;
    const bpm = 114;
    const intervalMs = (60 / bpm / 4) * 1000; // 16th notes

    this.beatLoopInterval = window.setInterval(() => {
      if (!this.isBeatPlaying || !this.ctx) return;
      const t = this.ctx.currentTime;

      // Kick drum on 0, 4, 8, 12 (four on floor)
      if (step % 4 === 0) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.frequency.setValueAtTime(120, t);
        osc.frequency.exponentialRampToValueAtTime(45, t + 0.12);
        gain.gain.setValueAtTime(0.5, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(t);
        osc.stop(t + 0.16);
      }

      // Shaker / Hi-hat on every odd 16th
      if (step % 2 === 1) {
        const bufferSize = this.ctx.sampleRate * 0.04;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = (Math.random() * 2 - 1) * 0.15;
        }
        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.value = 7000;
        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.2, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.04);
        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        noise.start(t);
      }

      // Amapiano Log Drum on steps 3, 6, 11, 14
      if (step === 3 || step === 6 || step === 11 || step === 14) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(80, t);
        osc.frequency.exponentialRampToValueAtTime(40, t + 0.18);
        gain.gain.setValueAtTime(0.4, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(t);
        osc.stop(t + 0.22);
      }

      step = (step + 1) % 16;
    }, intervalMs);
  }

  stopAfrobeatLoop() {
    this.isBeatPlaying = false;
    if (this.beatLoopInterval) {
      window.clearInterval(this.beatLoopInterval);
      this.beatLoopInterval = null;
    }
  }

  isLooping() {
    return this.isBeatPlaying;
  }
}

export const audioCues = new AudioCueEngine();
