import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeDepartmentSummary,
  computeGlobalOverview,
  computeMonthlyTrend,
  createInitialState,
  filterWorkers,
  generateAttendanceCsv,
  getMonthlyCycleRange,
  getRecordForDate,
  getTodayDateString,
  mergeWorkers,
  parseBulkWorkersText,
  removeWorkerFromDepartment,
  submitDepartmentAttendance,
  toggleWorkerAttendance,
} from './attendanceLogic';
import { buildAttendancePdfDocument } from './pdfExport';
import {
  formatExtractionError,
  formatWorkersAsBulkText,
  isTransientExtractionError,
  normalizeExtractedWorkers,
  resolveImportMimeType,
} from './workerExtraction';

test('createInitialState includes Samir Eng with Ramesh Marandi and sample workers', () => {
  const state = createInitialState();
  assert.equal(state.departments.length, 1);
  const primary = state.departments[0];
  assert.equal(primary.name, 'Samir Eng');
  assert.equal(primary.supervisor, 'Ramesh Marandi');
  assert.equal(primary.isPrimary, true);
  assert.ok(primary.workers.length >= 6);
  assert.equal(primary.workers[0].id, 'WRK-101');
});

test('getTodayDateString formats local YYYY-MM-DD', () => {
  const sampleDate = new Date(2026, 10, 20, 9, 30, 0);
  assert.equal(getTodayDateString(sampleDate), '2026-11-20');
});

test('toggleWorkerAttendance marks, switches, and clears marks per date', () => {
  const state = createInitialState();
  let dept = state.departments[0];
  const date = '2026-11-20';

  dept = toggleWorkerAttendance(dept, date, 'WRK-101', 'present');
  dept = toggleWorkerAttendance(dept, date, 'WRK-102', 'absent');
  let summary = computeDepartmentSummary(dept, date);
  assert.equal(summary.present, 1);
  assert.equal(summary.absent, 1);
  assert.equal(summary.unmarked, dept.workers.length - 2);

  // Switch WRK-102 from absent to present
  dept = toggleWorkerAttendance(dept, date, 'WRK-102', 'present');
  summary = computeDepartmentSummary(dept, date);
  assert.equal(summary.present, 2);
  assert.equal(summary.absent, 0);

  // Toggle WRK-101 off
  dept = toggleWorkerAttendance(dept, date, 'WRK-101', 'present');
  summary = computeDepartmentSummary(dept, date);
  assert.equal(summary.present, 1);

  // Different date remains independent
  const otherSummary = computeDepartmentSummary(dept, '2026-11-21');
  assert.equal(otherSummary.present, 0);
  assert.equal(otherSummary.absent, 0);
});

test('submitDepartmentAttendance marks session submitted and resets on subsequent edit', () => {
  const state = createInitialState();
  const date = '2026-11-20';
  let dept = toggleWorkerAttendance(state.departments[0], date, 'WRK-101', 'present');
  dept = submitDepartmentAttendance(dept, date, '2026-11-20T10:00:00.000Z');
  assert.equal(computeDepartmentSummary(dept, date).submitted, true);

  dept = toggleWorkerAttendance(dept, date, 'WRK-102', 'absent');
  assert.equal(computeDepartmentSummary(dept, date).submitted, false);
});

test('computeGlobalOverview aggregates across all departments for a date', () => {
  const state = createInitialState();
  const date = '2026-11-20';
  state.departments[0] = toggleWorkerAttendance(state.departments[0], date, 'WRK-101', 'present');
  state.departments.push({
    id: 'dept-2',
    name: 'Electrical Unit',
    supervisor: 'Kiran Das',
    workers: [
      { id: 'ELC-201', name: 'Ravi Murmu', role: 'Electrician' },
      { id: 'ELC-202', name: 'Amit Besra', role: 'Helper' },
    ],
    attendanceByDate: {
      [date]: {
        marks: { 'ELC-201': 'absent', 'ELC-202': 'present' },
        submitted: true,
      },
    },
  });

  const overview = computeGlobalOverview(state, date);
  assert.equal(overview.totalDepartments, 2);
  assert.equal(overview.totalWorkers, state.departments[0].workers.length + 2);
  assert.equal(overview.presentToday, 2);
  assert.equal(overview.absentToday, 1);
});

test('filterWorkers matches by name, id, and role case-insensitively', () => {
  const workers = createInitialState().departments[0].workers;
  assert.equal(filterWorkers(workers, 'WRK-103').length, 1);
  assert.equal(filterWorkers(workers, 'rajesh').length, 1);
  assert.equal(filterWorkers(workers, 'welder').length, 2);
  assert.equal(filterWorkers(workers, '   ').length, workers.length);
});

test('parseBulkWorkersText parses valid lines, skips header, and reports malformed lines', () => {
  const input = [
    'ID, Name, Role',
    'WRK-201, Arjun Mandi, Welder',
    'WRK-202, Gopal Hansda, Fitter',
    'BAD_LINE_ONLY_TWO, Parts',
    'WRK-201, Duplicate ID, Helper',
  ].join('\n');

  const parsed = parseBulkWorkersText(input);
  assert.equal(parsed.workers.length, 2);
  assert.equal(parsed.workers[0].id, 'WRK-201');
  assert.equal(parsed.workers[1].role, 'Fitter');
  assert.equal(parsed.errors.length, 2);
});

test('mergeWorkers appends without duplicate IDs and replaces cleanly', () => {
  const existing = [
    { id: 'WRK-101', name: 'Rajesh Kumar', role: 'Welder' },
    { id: 'WRK-102', name: 'Suresh Hembram', role: 'Fitter' },
  ];
  const incoming = [
    { id: 'WRK-102', name: 'Suresh Hembram', role: 'Senior Fitter' },
    { id: 'WRK-103', name: 'Vikram Soren', role: 'Mason' },
  ];

  const appended = mergeWorkers(existing, incoming, 'append');
  assert.equal(appended.length, 3);
  assert.equal(appended[1].role, 'Senior Fitter');

  const replaced = mergeWorkers(existing, incoming, 'replace');
  assert.equal(replaced.length, 2);
  assert.equal(replaced[0].id, 'WRK-102');
});

test('generateAttendanceCsv includes department metadata, summary counts, and escaped rows', () => {
  const state = createInitialState();
  const date = '2026-11-20';
  let dept = {
    ...state.departments[0],
    workers: [
      { id: 'WRK-101', name: 'Kumar, Rajesh', role: 'Welder' },
      { id: 'WRK-102', name: 'Suresh Hembram', role: 'Fitter' },
    ],
  };
  dept = toggleWorkerAttendance(dept, date, 'WRK-101', 'present');
  dept = submitDepartmentAttendance(dept, date);

  const csv = generateAttendanceCsv(dept, date);
  assert.ok(csv.includes('Department Name,Samir Eng'));
  assert.ok(csv.includes('Supervisor Name,Ramesh Marandi'));
  assert.ok(csv.includes('Date,2026-11-20'));
  assert.ok(csv.includes('Present (P),1'));
  assert.ok(csv.includes('WRK-101,"Kumar, Rajesh",Welder,Present'));
  assert.ok(csv.includes('WRK-102,Suresh Hembram,Fitter,Unmarked'));
});

test('removeWorkerFromDepartment removes worker and cleans up attendance marks across dates', () => {
  const state = createInitialState();
  const date1 = '2026-11-20';
  const date2 = '2026-11-21';
  let dept = toggleWorkerAttendance(state.departments[0], date1, 'WRK-101', 'present');
  dept = toggleWorkerAttendance(dept, date2, 'WRK-101', 'absent');
  dept = toggleWorkerAttendance(dept, date1, 'WRK-102', 'present');

  const initialTotal = dept.workers.length;
  dept = removeWorkerFromDepartment(dept, 'WRK-101');

  assert.equal(dept.workers.length, initialTotal - 1);
  assert.equal(dept.workers.some((w) => w.id === 'WRK-101'), false);
  assert.equal(getRecordForDate(dept, date1).marks['WRK-101'], undefined);
  assert.equal(getRecordForDate(dept, date2).marks['WRK-101'], undefined);
  assert.equal(getRecordForDate(dept, date1).marks['WRK-102'], 'present');

  const summary = computeDepartmentSummary(dept, date1);
  assert.equal(summary.total, initialTotal - 1);
  assert.equal(summary.present, 1);
});

test('buildAttendancePdfDocument creates a valid PDF document and filename', () => {
  const state = createInitialState();
  const date = '2026-11-20';
  let dept = toggleWorkerAttendance(state.departments[0], date, 'WRK-101', 'present');
  dept = toggleWorkerAttendance(dept, date, 'WRK-102', 'absent');
  dept = submitDepartmentAttendance(dept, date);

  const { doc, filename } = buildAttendancePdfDocument(dept, date, 'day');
  assert.equal(filename, 'samir-eng-day-shift-attendance-2026-11-20.pdf');
  const pdfText = doc.output();
  assert.ok(pdfText.startsWith('%PDF-'));
});

test('getMonthlyCycleRange computes October 26 to November 25 cycle for 2026-11-20', () => {
  const cycle = getMonthlyCycleRange('2026-11-20');
  assert.equal(cycle.startDate, '2026-10-26');
  assert.equal(cycle.endDate, '2026-11-25');
  assert.equal(cycle.dates.length, 31);
  assert.equal(cycle.dates[0], '2026-10-26');
  assert.equal(cycle.dates[30], '2026-11-25');
});

test('computeMonthlyTrend aggregates daily and per-department totals over the cycle', () => {
  const state = createInitialState();
  const cycle = getMonthlyCycleRange('2026-11-20');
  state.departments[0] = toggleWorkerAttendance(state.departments[0], '2026-11-20', 'WRK-101', 'present');
  state.departments.push({
    id: 'dept-2',
    name: 'Electrical Unit',
    supervisor: 'Kiran Das',
    workers: [{ id: 'ELC-1', name: 'Ravi', role: 'Electrician' }],
    attendanceByDate: {
      '2026-11-20': { marks: { 'ELC-1': 'absent' }, submitted: true },
    },
  });

  const allTrend = computeMonthlyTrend(state.departments, cycle.dates, 'all');
  assert.equal(allTrend.days.length, 31);
  const nov20 = allTrend.days.find((d) => d.date === '2026-11-20');
  assert.ok(nov20);
  assert.equal(nov20.present, 1);
  assert.equal(nov20.absent, 1);
  assert.equal(allTrend.byDepartment.length, 2);
  assert.equal(allTrend.byDepartment[1].absent, 1);

  const dept2Trend = computeMonthlyTrend(state.departments, cycle.dates, 'dept-2');
  assert.equal(dept2Trend.totalPresent, 0);
  assert.equal(dept2Trend.totalAbsent, 1);
});

test('Day Shift and Night Shift attendance records are tracked independently', () => {
  const state = createInitialState();
  const date = '2026-11-20';
  let dept = toggleWorkerAttendance(state.departments[0], date, 'WRK-101', 'present', 'day');
  dept = toggleWorkerAttendance(dept, date, 'WRK-102', 'absent', 'night');
  dept = submitDepartmentAttendance(dept, date, '2026-11-20T22:00:00.000Z', 'night');

  const daySummary = computeDepartmentSummary(dept, date, 'day');
  const nightSummary = computeDepartmentSummary(dept, date, 'night');

  assert.equal(daySummary.present, 1);
  assert.equal(daySummary.absent, 0);
  assert.equal(daySummary.submitted, false);

  assert.equal(nightSummary.present, 0);
  assert.equal(nightSummary.absent, 1);
  assert.equal(nightSummary.submitted, true);

  const nightCsv = generateAttendanceCsv(dept, date, 'night');
  assert.ok(nightCsv.includes('Shift,Night Shift'));
  const { filename: nightPdfFilename } = buildAttendancePdfDocument(dept, date, 'night');
  assert.equal(nightPdfFilename, 'samir-eng-night-shift-attendance-2026-11-20.pdf');
});

test('workerExtraction resolves PDF, JPG, screenshot PNG, and CSV MIME types and normalizes rows', () => {
  assert.equal(resolveImportMimeType('roster.pdf', ''), 'application/pdf');
  assert.equal(resolveImportMimeType('photo.jpg', 'image/jpg'), 'image/jpeg');
  assert.equal(resolveImportMimeType('Screenshot.png', 'image/png'), 'image/png');
  assert.equal(resolveImportMimeType('workers.csv', 'text/csv'), 'text/csv');
  assert.equal(resolveImportMimeType('archive.zip', 'application/zip'), null);

  const normalized = normalizeExtractedWorkers([
    { id: 'WRK-101', name: 'Rajesh Kumar', role: 'Welder' },
    { id: 'wrk-101', name: 'Duplicate ID', role: 'Helper' },
    { id: '', name: 'Anil, Murmu', role: '' },
    { id: 'WRK-001', name: 'Existing 001', role: 'Fitter' },
    { id: '', name: '   ', role: 'Mason' },
  ]);

  assert.equal(normalized.length, 3);
  assert.deepEqual(normalized[0], { id: 'WRK-101', name: 'Rajesh Kumar', role: 'Welder' });
  assert.deepEqual(normalized[1], { id: 'WRK-002', name: 'Anil Murmu', role: 'Worker' });
  assert.deepEqual(normalized[2], { id: 'WRK-001', name: 'Existing 001', role: 'Fitter' });

  const bulkText = formatWorkersAsBulkText(normalized);
  const reparsed = parseBulkWorkersText(bulkText);
  assert.equal(reparsed.errors.length, 0);
  assert.equal(reparsed.workers.length, 3);
});

test('workerExtraction detects 503 UNAVAILABLE JSON errors as transient and formats user-friendly message', () => {
  const raw503 = new Error(
    '{"error":{"code":503,"message":"This model is currently experiencing high demand. Spikes in demand are usually temporary. Please try again later.","status":"UNAVAILABLE"}}',
  );
  assert.equal(isTransientExtractionError(raw503), true);
  const formatted = formatExtractionError(raw503);
  assert.equal(formatted.status, 503);
  assert.ok(!formatted.message.includes('{'));
  assert.ok(formatted.message.toLowerCase().includes('retry'));
});
