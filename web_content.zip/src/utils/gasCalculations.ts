import {
  CopperPipeDimension,
  GasAppliance,
  GasFittings,
  GasMeterModel,
  GasParameters,
  PipeCalculationResult,
  CalculationSummary,
} from '../types/gas';

// الأقطار النحاسية التجارية القياسية وفق المواصفة الأوروبية EN 1057
export const COPPER_PIPES: CopperPipeDimension[] = [
  { nominal: '10/12', internalDiameterMm: 10, externalDiameterMm: 12, thicknessMm: 1.0, standard: 'EN 1057' },
  { nominal: '12/14', internalDiameterMm: 12, externalDiameterMm: 14, thicknessMm: 1.0, standard: 'EN 1057' },
  { nominal: '14/16', internalDiameterMm: 14, externalDiameterMm: 16, thicknessMm: 1.0, standard: 'EN 1057' },
  { nominal: '16/18', internalDiameterMm: 16, externalDiameterMm: 18, thicknessMm: 1.0, standard: 'EN 1057' },
  { nominal: '20/22', internalDiameterMm: 20, externalDiameterMm: 22, thicknessMm: 1.0, standard: 'EN 1057' },
  { nominal: '26/28', internalDiameterMm: 26, externalDiameterMm: 28, thicknessMm: 1.0, standard: 'EN 1057' },
  { nominal: '30/32', internalDiameterMm: 30, externalDiameterMm: 32, thicknessMm: 1.0, standard: 'EN 1057' },
  { nominal: '34/36', internalDiameterMm: 34, externalDiameterMm: 36, thicknessMm: 1.0, standard: 'EN 1057' },
  { nominal: '40/42', internalDiameterMm: 40, externalDiameterMm: 42, thicknessMm: 1.0, standard: 'EN 1057' },
  { nominal: '50/54', internalDiameterMm: 50, externalDiameterMm: 54, thicknessMm: 2.0, standard: 'EN 1057' },
  { nominal: '64/67', internalDiameterMm: 64, externalDiameterMm: 67, thicknessMm: 1.5, standard: 'EN 1057' },
];

// مواصفات عدادات الغاز الطبيعي القياسية وفق المواصفة EN 1359
export const GAS_METERS_SPECS: Omit<GasMeterModel, 'isSuitable' | 'loadPercentage'>[] = [
  {
    code: 'G1.6',
    qNom: 1.6,
    qMax: 2.5,
    qMin: 0.016,
    maxPowerKwApprox: 26,
    connectionSize: 'DN20 (3/4")',
    centerDistanceMm: 110,
    typicalApplicationAr: 'استوديوهات وشقق صغيرة جدًا بجهاز واحد فقط (طباخ أو سخان صغير)',
  },
  {
    code: 'G2.5',
    qNom: 2.5,
    qMax: 4.0,
    qMin: 0.025,
    maxPowerKwApprox: 42,
    connectionSize: 'DN20 (3/4")',
    centerDistanceMm: 110,
    typicalApplicationAr: 'شقق سكنية عادية (طباخ غاز + سخان مياه فوري)',
  },
  {
    code: 'G4',
    qNom: 4.0,
    qMax: 6.0,
    qMin: 0.040,
    maxPowerKwApprox: 63,
    connectionSize: 'DN20 (3/4") / DN25 (1")',
    centerDistanceMm: 110,
    typicalApplicationAr: 'العداد المنزلي القياسي المعتمد لأغلب المنازل والفلل (شوفاج وتدفئة مركزية + طباخ + سخان)',
  },
  {
    code: 'G6',
    qNom: 6.0,
    qMax: 10.0,
    qMin: 0.060,
    maxPowerKwApprox: 105,
    connectionSize: 'DN25 (1") / DN32 (1"1/4)',
    centerDistanceMm: 250,
    typicalApplicationAr: 'فلل كبيرة، عمارات صغيرة، مخابز حلويات، مقاهي ومطاعم سريعة صغيرة',
  },
  {
    code: 'G10',
    qNom: 10.0,
    qMax: 16.0,
    qMin: 0.100,
    maxPowerKwApprox: 168,
    connectionSize: 'DN32 (1"1/4) / DN40 (1"1/2)',
    centerDistanceMm: 280,
    typicalApplicationAr: 'مطاعم تجارية ومطابخ فنادق ومخابز متوسطة ومغاسل ومحلات تجارية',
  },
  {
    code: 'G16',
    qNom: 16.0,
    qMax: 25.0,
    qMin: 0.160,
    maxPowerKwApprox: 260,
    connectionSize: 'DN40 (1"1/2) / DN50 (2")',
    centerDistanceMm: 335,
    typicalApplicationAr: 'مطاعم كبرى، مخابز آلية، ورش صناعية صغرى ومطابخ مركزية',
  },
  {
    code: 'G25',
    qNom: 25.0,
    qMax: 40.0,
    qMin: 0.250,
    maxPowerKwApprox: 420,
    connectionSize: 'DN50 (2") فلنجة/قلاووظ',
    centerDistanceMm: 335,
    typicalApplicationAr: 'مجمعات تجارية كبرى، مصانع ومعامل صناعية متوسطة',
  },
  {
    code: 'G40',
    qNom: 40.0,
    qMax: 65.0,
    qMin: 0.400,
    maxPowerKwApprox: 680,
    connectionSize: 'DN65 فلنجة',
    centerDistanceMm: 430,
    typicalApplicationAr: 'منشآت صناعية ومراجل مركزية ضخمة',
  },
  {
    code: 'G65',
    qNom: 65.0,
    qMax: 100.0,
    qMin: 0.650,
    maxPowerKwApprox: 1050,
    connectionSize: 'DN80 فلنجة',
    centerDistanceMm: 500,
    typicalApplicationAr: 'شبكات توزيع ومصانع بتروكيماوية وغازية كبرى',
  },
];

/**
 * حساب الطول المكافئ للأكواع والتجهيزات بالاعتماد على القطر الداخلي للأنبوب النحاسي
 * وفق المواصفات الفنية ATG B 105 و DTU 61.1
 */
export function calculateFittingsEquivalentLength(
  fittings: GasFittings,
  internalDiameterMm: number
): number {
  const dInMeters = internalDiameterMm / 1000;
  // أطوال مكافئة هيدروليكية دقيقة:
  // كوع 90°: Leq = 30 * D
  const eq90 = (fittings.elbows90 || 0) * (30 * dInMeters);
  // كوع 45°: Leq = 15 * D
  const eq45 = (fittings.elbows45 || 0) * (15 * dInMeters);
  // تفرع تي 90° (Té): Leq = 60 * D
  const eqTee = (fittings.tees || 0) * (60 * dInMeters);
  // صمام غاز كامل المقطع: Leq = 20 * D
  const eqValve = (fittings.valves || 0) * (20 * dInMeters);
  // أطوال إضافية يدخلها المستخدم
  const custom = fittings.customEquivalentLength || 0;

  return Math.round((eq90 + eq45 + eqTee + eqValve + custom) * 100) / 100;
}

/**
 * حساب معامل التزامن (Foisonnement / Diversity Factor)
 */
export function calculateDiversityFactor(
  appliances: GasAppliance[],
  params: GasParameters
): number {
  if (params.diversityFactorMode === 'manual') {
    return Math.max(0.1, Math.min(1.0, (params.manualDiversityPercent || 100) / 100));
  }

  // الوضع التلقائي بناء على طبيعة المبنى والأجهزة
  const activeAppliances = appliances.filter((a) => a.enabled && a.quantity > 0);
  const totalCount = activeAppliances.reduce((acc, a) => acc + a.quantity, 0);

  if (totalCount <= 1) {
    return 1.0;
  }

  if (params.buildingType === 'residential') {
    // في المباني السكنية وفق DTU 61.1:
    // إذا كان هناك طباخ وسخان/مرجل: التزامن الكامل بين المرجل والطباخ نادر
    // Q_sim = Q_max + 0.6 * sum(بقية الأجهزة)
    // حساب النسبة الرياضية:
    const flows: number[] = [];
    activeAppliances.forEach((a) => {
      for (let i = 0; i < a.quantity; i++) {
        flows.push(a.flowRateM3h);
      }
    });

    if (flows.length === 0) return 1.0;

    flows.sort((a, b) => b - a);
    const sumTotal = flows.reduce((acc, v) => acc + v, 0);
    if (sumTotal <= 0) return 1.0;

    let simFlow = flows[0];
    for (let i = 1; i < flows.length; i++) {
      simFlow += 0.55 * flows[i];
    }
    const factor = simFlow / sumTotal;
    return Math.round(Math.max(0.5, Math.min(1.0, factor)) * 100) / 100;
  } else {
    // في المحلات التجارية والمطاعم: التزامن أعلى لأن الطباخين يشغلون عدة أفران وشوايات في نفس وقت الذروة
    if (totalCount === 2) return 0.90;
    if (totalCount === 3) return 0.85;
    if (totalCount <= 5) return 0.80;
    return 0.75;
  }
}

/**
 * صيغة رينوار للضغط المنخفض (Renouard Low Pressure Formula)
 * لحساب هبوط الضغط في شبكات الغاز الطبيعي (الضغط أقل من 50 ميلي بار)
 * ΔP (mbar) = 23.2 * d * L * (Q^1.82) / (D^4.82)
 *
 * حيث:
 * ΔP = هبوط الضغط بالميلي بار (mbar)
 * d = الكثافة النسبية للغاز بالنسبة للهواء (0.60 للغاز الطبيعي)
 * L = الطول المكافئ الكلي بالمتر (الطول الحقيقي + الأكواع)
 * Q = معدل تدفق الغاز المتزامن بـ (متر مكعب/ساعة m³/h)
 * D = القطر الداخلي للأنبوب بالميليمتر (mm)
 */
export function calculateRenouardPressureDrop(
  flowM3h: number,
  equivalentLengthM: number,
  internalDiameterMm: number,
  relativeDensity: number = 0.60
): number {
  if (flowM3h <= 0 || equivalentLengthM <= 0 || internalDiameterMm <= 0) {
    return 0;
  }

  const Q_term = Math.pow(flowM3h, 1.82);
  const D_term = Math.pow(internalDiameterMm, 4.82);
  const deltaP = (23.2 * relativeDensity * equivalentLengthM * Q_term) / D_term;

  return Math.round(deltaP * 1000) / 1000;
}

/**
 * حساب سرعة تدفق الغاز داخل الأنبوب بالمتر/ثانية
 * V = Q / (3600 * S) = (4 * Q) / (3600 * π * (D/1000)^2)
 */
export function calculateGasVelocity(
  flowM3h: number,
  internalDiameterMm: number
): number {
  if (flowM3h <= 0 || internalDiameterMm <= 0) {
    return 0;
  }

  const dMeters = internalDiameterMm / 1000;
  const areaM2 = (Math.PI * Math.pow(dMeters, 2)) / 4;
  const flowM3s = flowM3h / 3600;
  const velocity = flowM3s / areaM2;

  return Math.round(velocity * 100) / 100;
}

/**
 * الحساب الكامل للشبكة وتقييم جميع أقطار النحاس واختيار العداد
 */
export function performFullGasCalculation(
  appliances: GasAppliance[],
  params: GasParameters
): CalculationSummary {
  const activeAppliances = appliances.filter((a) => a.enabled && a.quantity > 0);

  // إجمالي القدرة الحرارية والتدفق الاسمي
  let totalInstalledPowerKw = 0;
  let totalNominalFlowM3h = 0;

  activeAppliances.forEach((app) => {
    const power = app.powerKw * app.quantity;
    totalInstalledPowerKw += power;
    const flow = app.flowRateM3h > 0 
      ? app.flowRateM3h * app.quantity 
      : (power / params.calorificValueKwh);
    totalNominalFlowM3h += flow;
  });

  totalInstalledPowerKw = Math.round(totalInstalledPowerKw * 10) / 10;
  totalNominalFlowM3h = Math.round(totalNominalFlowM3h * 100) / 100;

  // معامل التزامن والتدفق المتزامن الفعلي
  const diversityFactor = calculateDiversityFactor(appliances, params);
  const simultaneousFlowM3h = Math.round(totalNominalFlowM3h * diversityFactor * 100) / 100;

  // أطوال الشبكة
  const straightLengthM = params.pipeLengthM;

  // تقييم كل قطر نحاسي قياسي
  const allPipeResults: PipeCalculationResult[] = COPPER_PIPES.map((pipe) => {
    const fittingsEqLengthM = calculateFittingsEquivalentLength(
      params.fittings,
      pipe.internalDiameterMm
    );
    const totalEqLengthM = Math.round((straightLengthM + fittingsEqLengthM) * 100) / 100;

    const pressureDropMbar = calculateRenouardPressureDrop(
      simultaneousFlowM3h,
      totalEqLengthM,
      pipe.internalDiameterMm,
      params.relativeDensity
    );

    const velocityMps = calculateGasVelocity(
      simultaneousFlowM3h,
      pipe.internalDiameterMm
    );

    const isPressureDropValid = pressureDropMbar <= params.maxAllowablePressureDropMbar;
    const isVelocityValid = velocityMps <= params.maxVelocityMps;

    const pressureDropRatioPercent = Math.round(
      (pressureDropMbar / params.maxAllowablePressureDropMbar) * 100
    );

    let status: PipeCalculationResult['status'] = 'valid';
    let statusTextAr = 'مطابق للمواصفات';
    let statusColor = 'text-emerald-400 bg-emerald-950/40 border-emerald-500/30';

    if (!isPressureDropValid && !isVelocityValid) {
      status = 'rejected_both';
      statusTextAr = 'مرفوض: هبوط ضغط وسرعة عالية';
      statusColor = 'text-rose-400 bg-rose-950/40 border-rose-500/30';
    } else if (!isPressureDropValid) {
      status = 'rejected_dp';
      statusTextAr = `مرفوض: هبوط الضغط يتجاوز ${params.maxAllowablePressureDropMbar} م.بار`;
      statusColor = 'text-rose-400 bg-rose-950/40 border-rose-500/30';
    } else if (!isVelocityValid) {
      status = 'warning_velocity';
      statusTextAr = `تحذير: سرعة الغاز تتجاوز ${params.maxVelocityMps} م/ث`;
      statusColor = 'text-amber-400 bg-amber-950/40 border-amber-500/30';
    }

    return {
      pipe,
      fittingsEqLengthM,
      totalEqLengthM,
      pressureDropMbar,
      pressureDropRatioPercent,
      velocityMps,
      isPressureDropValid,
      isVelocityValid,
      status,
      statusTextAr,
      statusColor,
      isOptimal: false,
    };
  });

  // العثور على القطر الأمثل (أصغر قطر يحقق هبوط الضغط المسموح به والسرعة الآمنة)
  const validCandidates = allPipeResults.filter(
    (r) => r.isPressureDropValid && r.isVelocityValid
  );

  let optimalResult: PipeCalculationResult | null = null;
  let recommendedPipe: CopperPipeDimension | null = null;

  if (validCandidates.length > 0) {
    // الأصغر قطراً من بين الصالحين هو الأكثر اقتصادية
    optimalResult = validCandidates[0];
    optimalResult.isOptimal = true;
    optimalResult.status = 'recommended';
    optimalResult.statusTextAr = 'القطر الأمثل الموصى به';
    optimalResult.statusColor = 'text-cyan-400 bg-cyan-950/50 border-cyan-500/50';
    recommendedPipe = optimalResult.pipe;
  } else {
    // إذا لم يحقق أي قطر، نأخذ أكبر قطر متاح
    optimalResult = allPipeResults[allPipeResults.length - 1];
  }

  // حساب أطوال الأكواع التقديرية للعرض العام
  const fittingsEquivalentLengthM = optimalResult ? optimalResult.fittingsEqLengthM : 0;
  const totalEquivalentLengthM = optimalResult ? optimalResult.totalEqLengthM : straightLengthM;

  // تقييم عدادات الغاز واختيار الأنسب
  const allMeterModels: GasMeterModel[] = GAS_METERS_SPECS.map((m) => {
    const isSuitable = simultaneousFlowM3h <= m.qMax;
    const loadPercentage = m.qMax > 0 
      ? Math.round((simultaneousFlowM3h / m.qMax) * 100) 
      : 0;
    return {
      ...m,
      isSuitable,
      loadPercentage,
    };
  });

  // العداد الموصى به هو أصغر عداد يستوعب التدفق المتزامن بأمان
  let recommendedMeter: GasMeterModel | null = null;
  const suitableMeters = allMeterModels.filter((m) => m.isSuitable);
  if (suitableMeters.length > 0) {
    recommendedMeter = suitableMeters[0];
  } else {
    recommendedMeter = allMeterModels[allMeterModels.length - 1];
  }

  return {
    totalInstalledPowerKw,
    totalNominalFlowM3h,
    diversityFactor,
    simultaneousFlowM3h,
    straightLengthM,
    fittingsEquivalentLengthM,
    totalEquivalentLengthM,
    recommendedPipe,
    recommendedMeter,
    optimalResult,
    allPipeResults,
    allMeterModels,
  };
}
