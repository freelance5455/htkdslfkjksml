export interface VoicePersona {
  id: string;
  name: string;
  gender: 'female' | 'male' | 'cyber';
  tone: string;
  pitch: number;
  rate: number;
  description: string;
  avatar: string;
}

export const VOICE_PERSONAS: VoicePersona[] = [
  {
    id: 'priya_female',
    name: 'Priya / Meera (प्रिया - मधुर महिला आवाज़)',
    gender: 'female',
    tone: 'Sweet, gentle, warm & caring',
    pitch: 1.15,
    rate: 0.98,
    description: 'Sweet, emotional and loving Indian female voice with natural warmth',
    avatar: '👩',
  },
  {
    id: 'aanya_charming',
    name: 'Aanya / Zara (आन्या - चार्मिंग व रोमांटिक)',
    gender: 'female',
    tone: 'Charming, playful, cheerful & romantic',
    pitch: 1.28,
    rate: 1.05,
    description: 'Playful, lively and attractive voice with expressive high-EQ inflection',
    avatar: '🌸',
  },
  {
    id: 'aryan_male',
    name: 'Aryan / Rohit (आर्यन - दमदार पुरुष आवाज़)',
    gender: 'male',
    tone: 'Deep, confident, charismatic & protective',
    pitch: 0.88,
    rate: 1.0,
    description: 'Strong, clear, and trustworthy Indian male voice with natural authority',
    avatar: '👑',
  },
  {
    id: 'kabir_radio',
    name: 'Kabir / Vikram (कबीर - गहरा पॉडकास्टर आवाज़)',
    gender: 'male',
    tone: 'Extra deep, calming, mature & wise',
    pitch: 0.75,
    rate: 0.95,
    description: 'Late-night radio host / deep storytelling voice with soothing bass resonance',
    avatar: '🎙️',
  },
  {
    id: 'cyber_nova',
    name: 'CyberNova (साइबर नोवा - भविष्यवादी AI)',
    gender: 'cyber',
    tone: 'High-tech, sharp, energetic & algorithmic',
    pitch: 1.05,
    rate: 1.15,
    description: 'Futuristic AI trend forecaster with crisp rhythm and high-energy dynamics',
    avatar: '⚡',
  },
];

export interface UserVoiceConfig {
  personaId: string;
  customPitch: number;
  customRate: number;
}

export function getStoredVoiceConfig(): UserVoiceConfig {
  try {
    const personaId = localStorage.getItem('viralpulse_voice_persona') || 'priya_female';
    const pitchStr = localStorage.getItem('viralpulse_voice_pitch');
    const rateStr = localStorage.getItem('viralpulse_voice_rate');

    const persona = VOICE_PERSONAS.find(p => p.id === personaId) || VOICE_PERSONAS[0];

    return {
      personaId: persona.id,
      customPitch: pitchStr ? parseFloat(pitchStr) : persona.pitch,
      customRate: rateStr ? parseFloat(rateStr) : persona.rate,
    };
  } catch {
    return {
      personaId: 'priya_female',
      customPitch: 1.15,
      customRate: 0.98,
    };
  }
}

export function saveVoiceConfig(config: UserVoiceConfig): void {
  try {
    localStorage.setItem('viralpulse_voice_persona', config.personaId);
    localStorage.setItem('viralpulse_voice_pitch', String(config.customPitch));
    localStorage.setItem('viralpulse_voice_rate', String(config.customRate));
  } catch (err) {
    console.error('Failed to save voice config:', err);
  }
}

export function applyVoiceToUtterance(
  utterance: SpeechSynthesisUtterance,
  language: string,
  config?: UserVoiceConfig
): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

  const currentConfig = config || getStoredVoiceConfig();
  const persona = VOICE_PERSONAS.find(p => p.id === currentConfig.personaId) || VOICE_PERSONAS[0];

  utterance.pitch = currentConfig.customPitch;
  utterance.rate = currentConfig.customRate;

  const voices = window.speechSynthesis.getVoices();
  if (!voices || voices.length === 0) return;

  let bestVoice: SpeechSynthesisVoice | null = null;

  // Filter by gender preference
  const isFemale = persona.gender === 'female';

  if (language === 'hi') {
    // Look for Hindi voice
    const hindiVoices = voices.filter(v => v.lang.startsWith('hi'));
    if (hindiVoices.length > 0) {
      if (isFemale) {
        bestVoice = hindiVoices.find(v => /female|swara|kalpana|zira|neerja/i.test(v.name)) || hindiVoices[0];
      } else {
        bestVoice = hindiVoices.find(v => /male|hemant|madhav/i.test(v.name)) || hindiVoices[0];
      }
    }
  } else if (language === 'bn') {
    // Bengali voice
    const bengaliVoices = voices.filter(v => v.lang.startsWith('bn'));
    if (bengaliVoices.length > 0) {
      bestVoice = bengaliVoices[0];
    }
  }

  // Fallback to Indian English or English with gender preference
  if (!bestVoice) {
    const indianVoices = voices.filter(v => v.lang.includes('IN'));
    if (indianVoices.length > 0) {
      if (isFemale) {
        bestVoice = indianVoices.find(v => /female|swara|kalpana|priya|zira|sangeeta/i.test(v.name)) || indianVoices[0];
      } else {
        bestVoice = indianVoices.find(v => /male|hemant|prabhat|ravi/i.test(v.name)) || indianVoices[0];
      }
    }
  }

  if (!bestVoice) {
    const engVoices = voices.filter(v => v.lang.startsWith('en'));
    if (isFemale) {
      bestVoice = engVoices.find(v => /female|zira|samantha|karen|victoria|moira/i.test(v.name)) || engVoices[0];
    } else {
      bestVoice = engVoices.find(v => /male|david|daniel|alex|george/i.test(v.name)) || engVoices[0];
    }
  }

  if (bestVoice) {
    utterance.voice = bestVoice;
  }
}
