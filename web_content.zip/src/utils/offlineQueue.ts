import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase.ts';
import { OfflineAction } from '../types/index.ts';
import { removeUndefinedFields } from './firestoreHelper.ts';
import {
  saveRecordToIndexedDB,
  updateRecordStatusInIndexedDB,
  removeRecordFromIndexedDB,
} from './indexedDbSync.ts';

const QUEUE_STORAGE_KEY = 'fieldflow_offline_queue_v1';

export function getOfflineQueue(): OfflineAction[] {
  try {
    const raw = localStorage.getItem(QUEUE_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error('Error reading offline queue:', e);
    return [];
  }
}

export function saveOfflineQueue(queue: OfflineAction[]) {
  try {
    localStorage.setItem(QUEUE_STORAGE_KEY, JSON.stringify(queue));
    notifyQueueChange();
  } catch (e) {
    console.error('Error saving offline queue:', e);
  }
}

export function enqueueOfflineAction(type: OfflineAction['type'], payload: any): OfflineAction {
  const queue = getOfflineQueue();
  const cleanPayload = removeUndefinedFields(payload);
  const newAction: OfflineAction = {
    id: `off_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    type,
    payload: cleanPayload,
    timestamp: new Date().toISOString(),
    status: 'pending',
  };
  queue.push(newAction);
  saveOfflineQueue(queue);

  // Also persist to IndexedDB for Service Worker background sync
  saveRecordToIndexedDB(newAction).catch((err) => {
    console.warn('Could not save to IndexedDB:', err);
  });

  // Signal Service Worker background sync if supported
  if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
    navigator.serviceWorker.ready.then((reg) => {
      if ('sync' in reg) {
        (reg as any).sync.register('fieldflow-offline-sync').catch(() => {});
      }
      reg.active?.postMessage({ type: 'TRIGGER_SYNC' });
    }).catch(() => {});
  }

  return newAction;
}

export function removeOfflineAction(id: string) {
  const queue = getOfflineQueue().filter((item) => item.id !== id);
  saveOfflineQueue(queue);
  removeRecordFromIndexedDB(id).catch(() => {});
}

export function updateOfflineActionStatus(id: string, status: OfflineAction['status'], error?: string) {
  const queue = getOfflineQueue().map((item) => {
    if (item.id === id) {
      return { ...item, status, error };
    }
    return item;
  });
  saveOfflineQueue(queue);
  updateRecordStatusInIndexedDB(id, status, error).catch(() => {});
}

export function isItemPendingSync(targetId: string): boolean {
  const queue = getOfflineQueue();
  return queue.some(
    (item) =>
      item.payload?.id === targetId &&
      (item.status === 'pending' || item.status === 'syncing' || item.status === 'failed')
  );
}

let isProcessingQueue = false;

export async function processOfflineQueue(): Promise<{ synced: number; failed: number }> {
  if (isProcessingQueue) return { synced: 0, failed: 0 };
  if (!navigator.onLine) return { synced: 0, failed: 0 };

  const queue = getOfflineQueue();
  const pendingOrFailed = queue.filter((i) => i.status === 'pending' || i.status === 'failed');
  if (pendingOrFailed.length === 0) return { synced: 0, failed: 0 };

  isProcessingQueue = true;
  let synced = 0;
  let failed = 0;

  try {
    for (const item of pendingOrFailed) {
      updateOfflineActionStatus(item.id, 'syncing');
      try {
        const payload = removeUndefinedFields(item.payload);
        if (!payload || !payload.id) {
          throw new Error('Invalid payload: Missing ID');
        }

        const cleanPayload = removeUndefinedFields(payload);

        switch (item.type) {
          case 'check_in':
          case 'check_out':
            await setDoc(doc(db, 'attendance', payload.id), cleanPayload, { merge: true });
            break;
          case 'start_visit':
          case 'complete_visit':
            await setDoc(doc(db, 'visits', payload.id), cleanPayload, { merge: true });
            break;
          case 'update_task':
            await setDoc(doc(db, 'tasks', payload.id), cleanPayload, { merge: true });
            break;
          case 'apply_leave':
            await setDoc(doc(db, 'leave_requests', payload.id), cleanPayload, { merge: true });
            break;
          case 'send_message':
            await setDoc(doc(db, 'messages', payload.id), cleanPayload, { merge: true });
            break;
          default:
            console.warn('Unknown offline action type:', item.type);
        }

        // Successfully synced with server!
        updateOfflineActionStatus(item.id, 'synced');
        synced++;

        // Remove synced action after 3 seconds
        setTimeout(() => {
          removeOfflineAction(item.id);
        }, 3000);
      } catch (err: any) {
        console.error(`Error syncing offline action ${item.id}:`, err);
        updateOfflineActionStatus(item.id, 'failed', err?.message || 'Synchronization failed');
        failed++;
      }
    }
  } finally {
    isProcessingQueue = false;
  }

  return { synced, failed };
}

type QueueListener = (queue: OfflineAction[]) => void;
const listeners: Set<QueueListener> = new Set();

export function subscribeOfflineQueue(listener: QueueListener): () => void {
  listeners.add(listener);
  listener(getOfflineQueue());
  return () => {
    listeners.delete(listener);
  };
}

function notifyQueueChange() {
  const queue = getOfflineQueue();
  listeners.forEach((fn) => fn(queue));
}
