import { OfflineActionItem, Note } from "../types";

const QUEUE_KEY = "noteflow_offline_queue_v1";

export function getOfflineQueue(): OfflineActionItem[] {
  try {
    const raw = localStorage.getItem(QUEUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveOfflineQueue(queue: OfflineActionItem[]): void {
  try {
    localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
  } catch (err) {
    console.warn("Failed to save offline queue:", err);
  }
}

export function enqueueOfflineAction(
  type: OfflineActionItem["type"],
  noteId?: string,
  payload?: any
): OfflineActionItem {
  const queue = getOfflineQueue();
  const newItem: OfflineActionItem = {
    id: "action_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
    type,
    noteId,
    payload,
    createdAt: new Date().toISOString(),
    status: "pending",
  };
  queue.push(newItem);
  saveOfflineQueue(queue);
  return newItem;
}

export function dequeueOfflineAction(id: string): void {
  const queue = getOfflineQueue().filter((item) => item.id !== id);
  saveOfflineQueue(queue);
}

export function clearOfflineQueue(): void {
  localStorage.removeItem(QUEUE_KEY);
}

export async function processOfflineQueue(
  handler: (item: OfflineActionItem) => Promise<void>
): Promise<void> {
  const queue = getOfflineQueue();
  if (queue.length === 0) return;

  const remaining: OfflineActionItem[] = [];

  for (const item of queue) {
    try {
      await handler(item);
    } catch (err) {
      console.warn("Failed to process queue item", item.id, err);
      remaining.push(item);
    }
  }

  saveOfflineQueue(remaining);
}

/**
 * Local Rule-based Categorizer for Offline Mode
 */
export function categorizeNoteLocally(title: string, content: string): { category: string; tags: string[] } {
  const text = (title + " " + content).toLowerCase();

  let category = "Genel";
  const tags: string[] = [];

  if (/(yapılacak|todo|görev|ödev|proje|tamamla|alınacak|liste)/i.test(text)) {
    category = "Yapılacak";
    tags.push("görev");
  } else if (/(iş|toplantı|müşteri|mail|rapor|proje|şirket|ofis|bütçe)/i.test(text)) {
    category = "İş";
    tags.push("iş");
  } else if (/(fikir|proje|tasarım|buluş|düşünce|öneri|ilham)/i.test(text)) {
    category = "Fikirler";
    tags.push("fikir");
  } else if (/(ders|sınav|üniversite|okul|fizik|matematik|tarih|kitap|öğrenme)/i.test(text)) {
    category = "Ders";
    tags.push("eğitim");
  } else if (/(sağlık|spor|diyet|doktor|ilaç|koşu|beslenme)/i.test(text)) {
    category = "Kişisel";
    tags.push("sağlık");
  } else if (/(alışveriş|market|fatura|para|banka|sipariş)/i.test(text)) {
    category = "Kişisel";
    tags.push("harcama");
  }

  return { category, tags };
}
