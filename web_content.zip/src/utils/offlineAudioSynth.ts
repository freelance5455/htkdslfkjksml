import { PersonaId, VoiceSettings } from '../types/tts';
import { audioBufferToWavBlob, audioBufferToMp3Blob } from './audioEncoder';

/**
 * Manages native SpeechSynthesis and Web Audio API DSP synthesis
 */
class OfflineAudioEngine {
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isSpeaking = false;
  private visualizerInterval: number | null = null;
  private voices: SpeechSynthesisVoice[] = [];
  private onVoicesLoadedCallbacks: Array<() => void> = [];

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.loadVoices();
      window.speechSynthesis.onvoiceschanged = () => {
        this.loadVoices();
      };
    }
  }

  private loadVoices() {
    this.voices = window.speechSynthesis.getVoices();
    this.onVoicesLoadedCallbacks.forEach((cb) => cb());
  }

  public onVoicesLoaded(cb: () => void) {
    if (this.voices.length > 0) {
      cb();
    } else {
      this.onVoicesLoadedCallbacks.push(cb);
    }
  }

  public getVoices(): SpeechSynthesisVoice[] {
    return this.voices;
  }

  public getAudioContext(): AudioContext {
    if (!this.audioCtx || this.audioCtx.state === 'closed') {
      this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  public getAnalyser(): AnalyserNode {
    const ctx = this.getAudioContext();
    if (!this.analyser) {
      this.analyser = ctx.createAnalyser();
      this.analyser.fftSize = 256;
      this.analyser.smoothingTimeConstant = 0.8;
    }
    return this.analyser;
  }

  /**
   * Find the best matching voice for a language code
   */
  public findBestVoice(langCode: string, persona: PersonaId): SpeechSynthesisVoice | null {
    if (this.voices.length === 0) {
      this.voices = window.speechSynthesis.getVoices();
    }

    const exactMatches = this.voices.filter((v) =>
      v.lang.toLowerCase().replace('_', '-').startsWith(langCode.toLowerCase().replace('_', '-'))
    );

    const langPrefix = langCode.split('-')[0].toLowerCase();
    const prefixMatches = exactMatches.length > 0 ? exactMatches : this.voices.filter((v) =>
      v.lang.toLowerCase().startsWith(langPrefix)
    );

    const candidateList = prefixMatches.length > 0 ? prefixMatches : this.voices;

    // Filter by gender preference if possible
    if (persona === 'female' || persona === 'soda') {
      const female = candidateList.find((v) => /female|zira|samantha|victoria|karen|veena|lekha/i.test(v.name));
      if (female) return female;
    } else if (persona === 'male') {
      const male = candidateList.find((v) => /male|david|george|alex|daniel|rishi/i.test(v.name));
      if (male) return male;
    }

    return candidateList[0] || null;
  }

  /**
   * Real-time playback using native SpeechSynthesis
   */
  public speak(
    text: string,
    langCode: string,
    persona: PersonaId,
    settings: VoiceSettings,
    onStart?: () => void,
    onEnd?: () => void,
    onError?: (err: any) => void
  ): void {
    if (!('speechSynthesis' in window)) {
      if (onError) onError(new Error('Speech Synthesis not supported in this browser.'));
      return;
    }

    this.stop();

    const utterance = new SpeechSynthesisUtterance(text);
    this.currentUtterance = utterance;
    utterance.lang = langCode;

    const matchedVoice = this.findBestVoice(langCode, persona);
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    // Persona pitch & speed offsets
    let basePitch = 1.0;
    let baseRate = settings.speed;

    switch (persona) {
      case 'female':
        basePitch = 1.25;
        break;
      case 'male':
        basePitch = 0.85;
        break;
      case 'child':
        basePitch = 1.7;
        baseRate *= 1.1;
        break;
      case 'alien':
        basePitch = 1.35;
        baseRate *= 0.95;
        break;
      case 'monster':
        basePitch = 0.45;
        baseRate *= 0.85;
        break;
      case 'whisper':
        basePitch = 0.95;
        baseRate *= 0.9;
        break;
      case 'host':
        basePitch = 1.05;
        baseRate *= 1.05;
        break;
      case 'soda':
        basePitch = 1.35;
        baseRate *= 1.15;
        break;
    }

    // Apply pitch slider (-12 to 12 semitones converted to 0.5 - 2.0 range)
    const pitchSliderFactor = Math.pow(2, settings.pitch / 12);
    utterance.pitch = Math.max(0.1, Math.min(2.0, basePitch * pitchSliderFactor));
    utterance.rate = Math.max(0.2, Math.min(3.0, baseRate));

    // Connect visualizer simulation while speech synthesis is active
    this.startVisualizerSimulation();

    utterance.onstart = () => {
      this.isSpeaking = true;
      if (onStart) onStart();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      this.stopVisualizerSimulation();
      this.currentUtterance = null;
      if (onEnd) onEnd();
    };

    utterance.onerror = (e) => {
      this.isSpeaking = false;
      this.stopVisualizerSimulation();
      this.currentUtterance = null;
      if (onError) onError(e);
    };

    window.speechSynthesis.speak(utterance);
  }

  public pause(): void {
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
    }
  }

  public resume(): void {
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }
  }

  public stop(): void {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    this.isSpeaking = false;
    this.stopVisualizerSimulation();
    this.currentUtterance = null;
  }

  public getIsSpeaking(): boolean {
    return this.isSpeaking || (typeof window !== 'undefined' && window.speechSynthesis.speaking);
  }

  /**
   * Generates synthetic audio offline via Web Audio API DSP synthesis
   * for 100% offline WAV and MP3 export!
   */
  public async synthesizeOfflineAudioBuffer(
    text: string,
    persona: PersonaId,
    settings: VoiceSettings
  ): Promise<AudioBuffer> {
    const sampleRate = 44100;
    // Estimate word duration: ~3 words per second at speed 1.0
    const words = text.trim().split(/\s+/).filter(Boolean);
    const wordCount = Math.max(1, words.length);
    const durationPerWord = (0.35 / Math.max(0.3, settings.speed));
    const totalDuration = Math.max(1.2, wordCount * durationPerWord + 0.6);
    const numSamples = Math.floor(sampleRate * totalDuration);

    const offlineCtx = new OfflineAudioContext(1, numSamples, sampleRate);

    // Fundamental frequencies by persona
    let baseF0 = 130; // Hz
    let harmonicCount = 8;

    switch (persona) {
      case 'male':
        baseF0 = 105;
        harmonicCount = 10;
        break;
      case 'female':
        baseF0 = 220;
        harmonicCount = 7;
        break;
      case 'child':
        baseF0 = 310;
        harmonicCount = 6;
        break;
      case 'alien':
        baseF0 = 175;
        harmonicCount = 12;
        break;
      case 'monster':
        baseF0 = 68;
        harmonicCount = 14;
        break;
      case 'whisper':
        baseF0 = 150;
        harmonicCount = 4;
        break;
      case 'host':
        baseF0 = 140;
        harmonicCount = 9;
        break;
      case 'soda':
        baseF0 = 260;
        harmonicCount = 9;
        break;
    }

    // Apply user pitch offset
    baseF0 *= Math.pow(2, settings.pitch / 12);

    // Master bus
    const masterGain = offlineCtx.createGain();
    masterGain.gain.setValueAtTime(0.7, 0);

    // Formant vocal tract filters (F1, F2, F3) simulating human speech vowel formants
    const f1 = offlineCtx.createBiquadFilter();
    f1.type = 'bandpass';
    f1.frequency.setValueAtTime(persona === 'female' ? 750 : (persona === 'child' || persona === 'soda') ? 920 : 500, 0);
    f1.Q.setValueAtTime(3.5, 0);

    const f2 = offlineCtx.createBiquadFilter();
    f2.type = 'bandpass';
    f2.frequency.setValueAtTime(persona === 'female' ? 1800 : (persona === 'child' || persona === 'soda') ? 2300 : 1500, 0);
    f2.Q.setValueAtTime(4.0, 0);

    // Persona-specific DSP chain
    if (persona === 'soda' || settings.effects.sodaSparkle) {
      // Sparkling effervescent soda treble boost & high air
      const sodaAirFilter = offlineCtx.createBiquadFilter();
      sodaAirFilter.type = 'highshelf';
      sodaAirFilter.frequency.setValueAtTime(4000, 0);
      sodaAirFilter.gain.setValueAtTime(6.5, 0);
      f2.connect(sodaAirFilter);
      sodaAirFilter.connect(masterGain);
    }

    if (persona === 'alien' || settings.effects.alienModulation) {
      // Ring modulation
      const modOsc = offlineCtx.createOscillator();
      modOsc.type = 'sine';
      modOsc.frequency.setValueAtTime(52, 0);
      const modGain = offlineCtx.createGain();
      modGain.gain.setValueAtTime(0.5, 0);
      modOsc.connect(modGain.gain);
      modOsc.start();
    }

    if (persona === 'monster' || settings.effects.subBassPunch) {
      const subFilter = offlineCtx.createBiquadFilter();
      subFilter.type = 'lowshelf';
      subFilter.frequency.setValueAtTime(120, 0);
      subFilter.gain.setValueAtTime(8, 0);
      f1.connect(subFilter);
      subFilter.connect(masterGain);
    }

    // Word rhythmic envelopes to model natural speaking cadence
    const syllableCount = Math.max(2, Math.floor(text.length / 3));
    const syllableDur = (totalDuration - 0.4) / syllableCount;

    for (let s = 0; s < syllableCount; s++) {
      const startTime = 0.15 + s * syllableDur;
      const attack = 0.04;
      const release = syllableDur * 0.85;

      // Pulse oscillator
      const osc = offlineCtx.createOscillator();
      // Alternate vowel intonation
      const intonation = 1 + 0.08 * Math.sin((s / syllableCount) * Math.PI);
      osc.frequency.setValueAtTime(baseF0 * intonation, startTime);
      osc.type = persona === 'whisper' ? 'triangle' : 'sawtooth';

      const env = offlineCtx.createGain();
      env.gain.setValueAtTime(0.0001, startTime);
      env.gain.exponentialRampToValueAtTime(0.3, startTime + attack);
      env.gain.exponentialRampToValueAtTime(0.0001, startTime + release);

      osc.connect(env);
      env.connect(f1);
      env.connect(f2);
      f1.connect(masterGain);
      f2.connect(masterGain);

      osc.start(startTime);
      osc.stop(startTime + release + 0.05);

      // Add soft white noise burst for consonants
      if (s % 2 === 0 || persona === 'whisper') {
        const noiseLen = Math.floor(sampleRate * 0.08);
        const noiseBuf = offlineCtx.createBuffer(1, noiseLen, sampleRate);
        const out = noiseBuf.getChannelData(0);
        for (let i = 0; i < noiseLen; i++) {
          out[i] = (Math.random() * 2 - 1) * 0.15;
        }
        const noiseSrc = offlineCtx.createBufferSource();
        noiseSrc.buffer = noiseBuf;
        const noiseGain = offlineCtx.createGain();
        noiseGain.gain.setValueAtTime(persona === 'whisper' ? 0.35 : 0.08, startTime);
        noiseSrc.connect(noiseGain);
        noiseGain.connect(masterGain);
        noiseSrc.start(startTime);
        noiseSrc.stop(startTime + 0.08);
      }
    }

    masterGain.connect(offlineCtx.destination);
    return await offlineCtx.startRendering();
  }

  /**
   * Synthesize offline and return WAV and MP3 blobs
   */
  public async exportOfflineAudio(
    text: string,
    persona: PersonaId,
    settings: VoiceSettings
  ): Promise<{ wavBlob: Blob; mp3Blob: Blob; duration: number }> {
    const audioBuffer = await this.synthesizeOfflineAudioBuffer(text, persona, settings);
    const wavBlob = audioBufferToWavBlob(audioBuffer);
    const mp3Blob = await audioBufferToMp3Blob(audioBuffer, 192);
    return {
      wavBlob,
      mp3Blob,
      duration: audioBuffer.duration,
    };
  }

  // Visualizer simulation helpers for real-time speech canvas
  private startVisualizerSimulation() {
    const analyser = this.getAnalyser();
    const ctx = this.getAudioContext();
    if (this.visualizerInterval) clearInterval(this.visualizerInterval);

    // Create an internal oscillator node feeding analyser for waveform animation
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      osc.frequency.setValueAtTime(140, ctx.currentTime);
      osc.connect(gain);
      gain.connect(analyser);
      osc.start();

      let t = 0;
      this.visualizerInterval = window.setInterval(() => {
        t += 0.1;
        osc.frequency.setValueAtTime(140 + 70 * Math.sin(t * 3), ctx.currentTime);
      }, 50);

      // Auto-cleanup on end
      (this as any)._activeOsc = osc;
    } catch (e) {
      // Ignored
    }
  }

  private stopVisualizerSimulation() {
    if (this.visualizerInterval) {
      clearInterval(this.visualizerInterval);
      this.visualizerInterval = null;
    }
    try {
      if ((this as any)._activeOsc) {
        (this as any)._activeOsc.stop();
        (this as any)._activeOsc = null;
      }
    } catch (e) {
      // Ignored
    }
  }
}

export const offlineAudioEngine = new OfflineAudioEngine();
