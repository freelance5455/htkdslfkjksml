import { MeterRecord, TourneeStats } from '../types/meter';

export const INITIAL_METER_DATA: MeterRecord[] = [
  {
    id: 'rec-1',
    gda: 'G6272884',
    ref: '921132540',
    ctr: '00166341/2019',
    index: 920,
    compt: 'GM190400166341',
    saisie: true,
    nonSaisie: false,
    bloque: false,
    nouvIndex: 948,
    hublotTaps: true,
    clientAbsent: false,
    necessiteVerification: false,
    sansPlombage: false,
    numFI: 'FI-2024-019',
    observation: 'زجاج العداد به خدوش ولكن الرقم واضح',
    latitude: 36.8188,
    longitude: 10.1658,
    address: 'نهج فلسطين، المنزه 1',
    clientName: 'السيد محمد الطرابلسي',
    phone: '+216 98 123 456',
    dateReleve: '2026-09-18 09:15'
  },
  {
    id: 'rec-2',
    gda: 'G6251692',
    ref: '921132950',
    ctr: '00163868/2019',
    index: 412,
    compt: 'GM190400163868',
    saisie: true,
    nonSaisie: false,
    bloque: false,
    nouvIndex: 435,
    hublotTaps: false,
    clientAbsent: false,
    necessiteVerification: false,
    sansPlombage: false,
    numFI: '',
    observation: '',
    latitude: 36.8245,
    longitude: 10.1712,
    address: 'شارع الحرية، المنزه 5',
    clientName: 'السيدة فايزة بن علي',
    phone: '+216 22 456 789',
    dateReleve: '2026-09-18 09:40'
  },
  {
    id: 'rec-3',
    gda: 'G6785764',
    ref: '921154850',
    ctr: '0001147/2020',
    index: 0,
    compt: 'IT001006785764',
    saisie: false,
    nonSaisie: true,
    bloque: false,
    nouvIndex: null,
    hublotTaps: false,
    clientAbsent: true,
    necessiteVerification: false,
    sansPlombage: false,
    numFI: '',
    observation: 'الباب الخارجي مقفل - الزبون غير موجود',
    latitude: 36.8312,
    longitude: 10.1804,
    address: 'نهج قرطاج، أريانة الجديدة',
    clientName: 'السيد كمال العياري',
    phone: '+216 55 789 012',
    dateReleve: null
  },
  {
    id: 'rec-4',
    gda: 'G6530450',
    ref: '921169000',
    ctr: '00163872/2019',
    index: 0,
    compt: 'GM190400163872',
    saisie: true,
    nonSaisie: false,
    bloque: false,
    nouvIndex: 12,
    hublotTaps: false,
    clientAbsent: false,
    necessiteVerification: false,
    sansPlombage: false,
    numFI: '',
    observation: 'RAS',
    latitude: 36.8390,
    longitude: 10.1920,
    address: 'نهج الهادي نويرة، النصر 2',
    clientName: 'السيد رشيد البكوش',
    phone: '+216 94 333 444',
    dateReleve: '2026-09-18 10:25'
  },
  {
    id: 'rec-5',
    gda: 'G6399425',
    ref: '921181201',
    ctr: '00164876/2019',
    index: 393,
    compt: 'GM190400164876',
    saisie: true,
    nonSaisie: false,
    bloque: false,
    nouvIndex: 410,
    hublotTaps: false,
    clientAbsent: false,
    necessiteVerification: false,
    sansPlombage: false,
    numFI: '',
    observation: '',
    latitude: 36.8450,
    longitude: 10.1985,
    address: 'شارع البيئة، برج البكوش',
    clientName: 'السيد أنيس الجلاصي',
    phone: '+216 29 555 666',
    dateReleve: '2026-09-18 11:00'
  }
];

const STORAGE_KEY = 'gas_meter_records_v1';

export function getStoredMeters(): MeterRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveStoredMeters(INITIAL_METER_DATA);
      return INITIAL_METER_DATA;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return INITIAL_METER_DATA;
  } catch (e) {
    console.error('Failed to load meters from localStorage:', e);
    return INITIAL_METER_DATA;
  }
}

export function saveStoredMeters(records: MeterRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  } catch (e) {
    console.error('Failed to save meters to localStorage:', e);
  }
}

export function calculateStats(records: MeterRecord[]): TourneeStats {
  const total = records.length;
  let saisis = 0;
  let nonSaisis = 0;
  let bloques = 0;
  let absents = 0;
  let anomalies = 0;
  let withGps = 0;

  for (const r of records) {
    if (r.saisie) saisis++;
    else nonSaisis++;

    if (r.bloque) bloques++;
    if (r.clientAbsent) absents++;
    if (r.hublotTaps || r.sansPlombage || r.necessiteVerification) anomalies++;
    if (r.latitude != null && r.longitude != null && !isNaN(r.latitude) && !isNaN(r.longitude)) withGps++;
  }

  const progressPercent = total > 0 ? Math.round((saisis / total) * 100) : 0;

  return {
    total,
    saisis,
    nonSaisis,
    bloques,
    absents,
    anomalies,
    withGps,
    progressPercent
  };
}
