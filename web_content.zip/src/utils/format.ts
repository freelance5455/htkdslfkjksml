export function round(value: number, decimals = 2): number {
  if (!isFinite(value)) return 0;
  const factor = Math.pow(10, decimals);
  return Math.round((value + Number.EPSILON) * factor) / factor;
}

export function fmt(value: number, decimals = 2): string {
  const r = round(value, decimals);
  // Drop trailing .00
  if (Number.isInteger(r)) return r.toString();
  return r.toFixed(decimals).replace(/0+$/, "").replace(/\.$/, "");
}

export function fmtUnit(value: number, unit?: string, decimals = 2): string {
  const v = fmt(value, decimals);
  return unit ? `${v} ${unit}` : v;
}
