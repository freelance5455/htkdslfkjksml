export function formatInr(paise: number | undefined | null): string {
  const safePaise = typeof paise === 'number' && Number.isFinite(paise) ? paise : 0;
  const rupees = safePaise / 100;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: rupees % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(rupees);
}

export function formatInrExact(paise: number | undefined | null): string {
  const safePaise = typeof paise === 'number' && Number.isFinite(paise) ? paise : 0;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(safePaise / 100);
}

export function formatNumber(num: number | undefined | null): string {
  const safe = typeof num === 'number' && Number.isFinite(num) ? num : 0;
  return new Intl.NumberFormat('en-IN').format(safe);
}

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  const normalized = iso.includes('T') ? iso : `${iso.replace(' ', 'T')}Z`;
  const d = new Date(normalized);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function calculatePreviewPaise(quantity: number, referenceQty: number, referencePricePaise: number): number {
  if (!Number.isFinite(quantity) || quantity <= 0 || !referenceQty) return 0;
  return Math.max(100, Math.round((quantity / referenceQty) * referencePricePaise));
}

export function formatPaymentMethodLabel(method: string | null | undefined): string {
  switch (method) {
    case 'upi':
      return 'UPI';
    case 'gpay':
      return 'Google Pay';
    case 'phonepe':
      return 'PhonePe';
    case 'paytm':
      return 'Paytm';
    case 'card_netbanking':
      return 'Card / NetBanking';
    case 'wallet':
      return 'Account Wallet';
    default:
      return method ? method.toUpperCase() : 'Gateway';
  }
}

export function getOrderStatusMeta(status: string): {
  label: string;
  textClass: string;
} {
  switch (status) {
    case 'completed':
      return { label: 'Completed', textClass: 'text-emerald-400' };
    case 'in_progress':
      return { label: 'In Progress', textClass: 'text-blue-400' };
    case 'queued':
      return { label: 'Verified & Queued', textClass: 'text-violet-400' };
    case 'awaiting_payment':
      return { label: 'Awaiting Payment', textClass: 'text-amber-400' };
    case 'payment_failed':
      return { label: 'Payment Failed', textClass: 'text-rose-400' };
    case 'refunded':
      return { label: 'Refunded', textClass: 'text-slate-300' };
    case 'cancelled':
      return { label: 'Cancelled', textClass: 'text-slate-400' };
    default:
      return { label: status, textClass: 'text-slate-300' };
  }
}
