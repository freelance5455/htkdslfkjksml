export interface CodeSnippet {
  language: string;
  code: string;
}

export function generateApiSnippets(
  apiKey: string,
  text: string,
  languageCode: string,
  persona: string,
  speed: number
): Record<string, string> {
  const safeText = JSON.stringify(text || 'Hello world from SK text to speech');
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://api.sk-tts.studio';

  const curl = `curl -X POST "${baseUrl}/api/v1/tts/synthesize" \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: ${apiKey}" \\
  -d '{
    "text": ${safeText},
    "language": "${languageCode}",
    "persona": "${persona}",
    "speed": ${speed}
  }'`;

  const javascript = `// Node.js or Browser Fetch
const response = await fetch("${baseUrl}/api/v1/tts/synthesize", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "x-api-key": "${apiKey}",
  },
  body: JSON.stringify({
    text: ${safeText},
    language: "${languageCode}",
    persona: "${persona}",
    speed: ${speed},
  }),
});

const result = await response.json();
console.log("Synthesized in", result.data.latencyMs, "ms");

// Play audio from base64
const audio = new Audio("data:audio/wav;base64," + result.data.audioBase64);
audio.play();`;

  const python = `import requests
import base64

url = "${baseUrl}/api/v1/tts/synthesize"
headers = {
    "Content-Type": "application/json",
    "x-api-key": "${apiKey}"
}
payload = {
    "text": ${safeText},
    "language": "${languageCode}",
    "persona": "${persona}",
    "speed": ${speed}
}

response = requests.post(url, json=payload, headers=headers)
data = response.json()

if data.get("success"):
    audio_bytes = base64.b64decode(data["data"]["audioBase64"])
    with open("output.wav", "wb") as f:
        f.write(audio_bytes)
    print(f"Audio saved! Generated in {data['data']['latencyMs']}ms")
else:
    print("Error:", data.get("error"))`;

  const php = `<?php
$url = "${baseUrl}/api/v1/tts/synthesize";
$apiKey = "${apiKey}";

$data = [
    "text" => ${safeText},
    "language" => "${languageCode}",
    "persona" => "${persona}",
    "speed" => ${speed}
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "x-api-key: " . $apiKey
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
$audioData = base64_decode($result['data']['audioBase64']);
file_put_contents('output.wav', $audioData);
echo "Audio saved successfully!";
?>`;

  return {
    curl,
    javascript,
    python,
    php,
  };
}
