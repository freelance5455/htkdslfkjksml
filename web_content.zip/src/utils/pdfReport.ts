import { jsPDF } from 'jspdf';
import { COMPANY_LOGO_DATA_URI } from '../data/brandAssets';
import { TANKS, type TankId } from '../data/tankCharts';
import {
  TOTAL_VESSEL_CAPACITY_LITERS,
  formatCubicMeters,
  formatNumber,
  getTankBounds,
} from './tankMath';

export interface SoundingPdfPayload {
  dipInputs: Record<TankId, string>;
  dipResults: Record<TankId, { liters: number | null; error?: string; pct: number }>;
  summary: {
    portTotal: number;
    stbdTotal: number;
    slopTotal: number;
    grandTotal: number;
    totalPct: number;
    balanceDiff: number;
    enteredCount: number;
  };
  balanceLabel: string;
}

export type PdfShareOutcome = 'shared' | 'downloaded' | 'cancelled';

function buildSoundingPdfBlob(payload: SoundingPdfPayload): {
  blob: Blob;
  fileName: string;
  stamp: string;
} {
  const { dipInputs, dipResults, summary, balanceLabel } = payload;

  const now = new Date();
  const stamp = now.toLocaleString('en-GB', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
  const pad = (n: number) => String(n).padStart(2, '0');
  const fileName = `MT_Doreen14_Sounding_Report_${now.getFullYear()}-${pad(
    now.getMonth() + 1
  )}-${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}.pdf`;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageW = 210;
  const margin = 14;
  const contentW = pageW - margin * 2;

  // Top dark navy header banner
  doc.setFillColor(12, 22, 36);
  doc.rect(0, 0, pageW, 34, 'F');

  // Champagne gold accent stripe under header
  doc.setFillColor(212, 164, 70);
  doc.rect(0, 34, pageW, 1.4, 'F');

  // White logo card
  doc.setFillColor(255, 255, 255);
  doc.roundedRect(margin, 8, 36, 17, 2, 2, 'F');
  try {
    doc.addImage(COMPANY_LOGO_DATA_URI, 'JPEG', margin + 1.5, 9.2, 33, 14.6);
  } catch {
    // Fallback text if logo image cannot be embedded
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(12, 22, 36);
    doc.text('DOREEN POWER', margin + 18, 17.5, { align: 'center' });
  }

  // Header titles
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(180, 198, 218);
  doc.text('DOREEN POWER AND SYSTEM GENERATIONS LIMITED', margin + 41, 13);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(255, 255, 255);
  doc.text('MT DOREEN-14  |  CARGO TANK SOUNDING REPORT', margin + 41, 20.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(243, 214, 138);
  doc.text(`Report Date & Time: ${stamp}`, margin + 41, 26.5);

  // Meta strip below header
  let y = 43;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(
    `Active Tanks: ${summary.enteredCount} / ${TANKS.length}    |    Vessel Capacity: ${formatNumber(
      TOTAL_VESSEL_CAPACITY_LITERS
    )} Liters`,
    margin,
    y
  );
  doc.text('Calibration Step: 10 mm Linear Interpolation', pageW - margin, y, {
    align: 'right',
  });

  // Table Header
  y += 5;
  const rowH = 9.5;
  const colX = {
    tank: margin + 3,
    side: margin + 32,
    range: margin + 62,
    dip: margin + 114,
    liters: margin + 154,
    pct: pageW - margin - 3,
  };

  doc.setFillColor(18, 34, 54);
  doc.roundedRect(margin, y, contentW, 9, 1.5, 1.5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(243, 214, 138);
  doc.text('TANK', colX.tank, y + 6);
  doc.text('SECTION', colX.side, y + 6);
  doc.text('CALIBRATION', colX.range, y + 6);
  doc.text('DIP (mm)', colX.dip, y + 6, { align: 'right' });
  doc.text('VOLUME (Liters)', colX.liters, y + 6, { align: 'right' });
  doc.text('FILL (%)', colX.pct, y + 6, { align: 'right' });

  y += 9;

  // Table Rows
  TANKS.forEach((tank, idx) => {
    const bounds = getTankBounds(tank);
    const raw = dipInputs[tank].trim();
    const res = dipResults[tank];

    if (idx % 2 === 1) {
      doc.setFillColor(246, 248, 251);
      doc.rect(margin, y, contentW, rowH, 'F');
    }

    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.2);
    doc.line(margin, y + rowH, pageW - margin, y + rowH);

    // Side metadata & color
    let sideLabel = 'Slop Tank';
    let sideColor: [number, number, number] = [180, 83, 9];
    if (tank.startsWith('P-')) {
      sideLabel = 'Port Side';
      sideColor = [190, 18, 60];
    } else if (tank.startsWith('S-')) {
      sideLabel = 'Starboard';
      sideColor = [15, 118, 110];
    }

    const textY = y + 6.3;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(15, 23, 42);
    doc.text(tank, colX.tank, textY);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(...sideColor);
    doc.text(sideLabel, colX.side, textY);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(100, 116, 139);
    doc.text(`0-${bounds.maxMm} mm`, colX.range, textY);

    if (raw === '') {
      doc.setTextColor(148, 163, 184);
      doc.text('-', colX.dip, textY, { align: 'right' });
      doc.text('-', colX.liters, textY, { align: 'right' });
      doc.text('-', colX.pct, textY, { align: 'right' });
    } else if (res.error) {
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(15, 23, 42);
      doc.text(`${raw} mm`, colX.dip, textY, { align: 'right' });
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(220, 38, 38);
      doc.text(res.error, colX.pct, textY, { align: 'right' });
    } else {
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(15, 23, 42);
      doc.text(`${raw} mm`, colX.dip, textY, { align: 'right' });
      doc.text(`${formatNumber(res.liters ?? 0)} L`, colX.liters, textY, {
        align: 'right',
      });
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(51, 65, 85);
      doc.text(`${res.pct.toFixed(1)}%`, colX.pct, textY, { align: 'right' });
    }

    y += rowH;
  });

  // Summary Breakdown Cards (3 Columns)
  y += 8;
  const gap = 4;
  const cardW = (contentW - gap * 2) / 3;
  const cardH = 22;

  // Port Card
  doc.setFillColor(255, 245, 247);
  doc.setDrawColor(251, 113, 133);
  doc.setLineWidth(0.35);
  doc.roundedRect(margin, y, cardW, cardH, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(190, 18, 60);
  doc.text('PORT TOTAL (P-1..P-4)', margin + 4, y + 7);
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text(`${formatNumber(summary.portTotal)} L`, margin + 4, y + 16);

  // Starboard Card
  const card2X = margin + cardW + gap;
  doc.setFillColor(240, 253, 250);
  doc.setDrawColor(45, 212, 191);
  doc.roundedRect(card2X, y, cardW, cardH, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(15, 118, 110);
  doc.text('STARBOARD (S-1..S-4)', card2X + 4, y + 7);
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text(`${formatNumber(summary.stbdTotal)} L`, card2X + 4, y + 16);

  // Slop & Balance Card
  const card3X = margin + (cardW + gap) * 2;
  doc.setFillColor(255, 251, 235);
  doc.setDrawColor(212, 164, 70);
  doc.roundedRect(card3X, y, cardW, cardH, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(180, 83, 9);
  doc.text('SLOP TANK & BALANCE', card3X + 4, y + 7);
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text(`${formatNumber(summary.slopTotal)} L`, card3X + 4, y + 14.5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Trim Balance: ${balanceLabel}`, card3X + 4, y + 19.5);

  // Grand Total Hero Box
  y += cardH + 6;
  doc.setFillColor(12, 22, 36);
  doc.setDrawColor(212, 164, 70);
  doc.setLineWidth(0.5);
  doc.roundedRect(margin, y, contentW, 24, 2.5, 2.5, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(180, 198, 218);
  doc.text('GRAND TOTAL CARGO ONBOARD', margin + 6, y + 8);

  doc.setFontSize(18);
  doc.setTextColor(243, 214, 138);
  doc.text(`${formatNumber(summary.grandTotal)} Liters`, margin + 6, y + 18);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(255, 255, 255);
  doc.text(
    `${formatCubicMeters(summary.grandTotal)} m\u00B3`,
    pageW - margin - 6,
    y + 11.5,
    { align: 'right' }
  );

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(94, 234, 212);
  doc.text(
    `${summary.totalPct.toFixed(2)}% of vessel capacity`,
    pageW - margin - 6,
    y + 18,
    { align: 'right' }
  );

  // Sign-off Block
  y += 42;
  doc.setDrawColor(148, 163, 184);
  doc.setLineWidth(0.3);
  doc.line(margin, y, margin + 62, y);
  doc.line(pageW - margin - 62, y, pageW - margin, y);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text('Chief Officer / Cargo Officer', margin, y + 5);
  doc.text('Master / Vessel Stamp', pageW - margin - 62, y + 5);

  // Footer
  doc.setDrawColor(226, 232, 240);
  doc.line(margin, 280, pageW - margin, 280);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.text(
    'MT Doreen-14 Tank Dip Calculator  |  Made by Abu Hanif, Merchant Mariner & Sub Assistant Engineer',
    pageW / 2,
    286,
    { align: 'center' }
  );

  const blob = doc.output('blob');
  return { blob, fileName, stamp };
}

function triggerBlobDownload(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

export async function shareOrDownloadSoundingPdf(
  payload: SoundingPdfPayload
): Promise<PdfShareOutcome> {
  const { blob, fileName, stamp } = buildSoundingPdfBlob(payload);
  const file = new File([blob], fileName, { type: 'application/pdf' });

  const shareText = `MT Doreen-14 Tank Sounding Report (${stamp}) - Grand Total: ${formatNumber(
    payload.summary.grandTotal
  )} L (${formatCubicMeters(payload.summary.grandTotal)} m³)`;

  if (
    typeof navigator !== 'undefined' &&
    typeof navigator.share === 'function' &&
    typeof navigator.canShare === 'function'
  ) {
    try {
      if (navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: 'MT Doreen-14 Tank Sounding Report',
          text: shareText,
          files: [file],
        });
        return 'shared';
      }
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        return 'cancelled';
      }
      // Fall through to direct PDF file download when Web Share is blocked (e.g. iframe)
    }
  }

  triggerBlobDownload(blob, fileName);
  return 'downloaded';
}
