export type AppTab = 'dashboard' | 'tasks' | 'wallet' | 'membership' | 'games' | 'referrals' | 'profile' | 'vip_tasks' | 'admin';

interface IntentResult {
  tab: AppTab | null;
  action: 'navigate' | 'none';
  spokenFeedback: string;
}

export function handleVoiceIntent(transcript: string): IntentResult {
  const query = transcript.toLowerCase().trim();

  // Wallet intents
  if (query.includes('wallet') || query.includes('balance') || query.includes('cashout') || query.includes('withdraw') || query.includes('coins')) {
    return {
      tab: 'wallet',
      action: 'navigate',
      spokenFeedback: 'Opening your wallet and cashout section now.'
    };
  }

  // Tasks intents
  if (query.includes('task') || query.includes('earn') || query.includes('watch') || query.includes('app download')) {
    if (query.includes('vip')) {
      return {
        tab: 'vip_tasks',
        action: 'navigate',
        spokenFeedback: 'Opening your VIP exclusive tasks.'
      };
    }
    return {
      tab: 'tasks',
      action: 'navigate',
      spokenFeedback: 'Opening the task earnings center.'
    };
  }

  // VIP intents
  if (query.includes('vip') || query.includes('tier') || query.includes('membership') || query.includes('upgrade')) {
    if (query.includes('task')) {
      return {
        tab: 'vip_tasks',
        action: 'navigate',
        spokenFeedback: 'Opening VIP tasks.'
      };
    }
    return {
      tab: 'membership',
      action: 'navigate',
      spokenFeedback: 'Opening VIP membership tiers.'
    };
  }

  // Games intents
  if (query.includes('game') || query.includes('collector') || query.includes('spin') || query.includes('play')) {
    return {
      tab: 'games',
      action: 'navigate',
      spokenFeedback: 'Launching the Game Zone.'
    };
  }

  // Referrals intents
  if (query.includes('refer') || query.includes('invite') || query.includes('friend')) {
    return {
      tab: 'referrals',
      action: 'navigate',
      spokenFeedback: 'Opening your referral rewards.'
    };
  }

  // Profile intents
  if (query.includes('profile') || query.includes('account') || query.includes('settings')) {
    return {
      tab: 'profile',
      action: 'navigate',
      spokenFeedback: 'Opening your user profile.'
    };
  }

  // Dashboard intents
  if (query.includes('home') || query.includes('dashboard') || query.includes('main')) {
    return {
      tab: 'dashboard',
      action: 'navigate',
      spokenFeedback: 'Taking you back to the main dashboard.'
    };
  }

  return {
    tab: null,
    action: 'none',
    spokenFeedback: ''
  };
}
