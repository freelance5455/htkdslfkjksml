import { SavedGasProject, GasAppliance, GasParameters } from '../types/gas';
import { GAS_PRESETS } from '../data/gasPresets';

const SAVED_PROJECTS_KEY = 'gas_calc_saved_projects_v1';
const CURRENT_PROJECT_KEY = 'gas_calc_current_session_v1';

export const DEFAULT_PARAMETERS: GasParameters = {
  buildingType: 'residential',
  gasType: 'natural_gas_h',
  relativeDensity: 0.60,
  calorificValueKwh: 10.5,
  supplyPressureMbar: 20,
  maxAllowablePressureDropMbar: 1.0,
  pipeLengthM: 15,
  fittings: {
    elbows90: 6,
    elbows45: 2,
    tees: 2,
    valves: 3,
    customEquivalentLength: 0,
  },
  diversityFactorMode: 'auto',
  manualDiversityPercent: 100,
  maxVelocityMps: 5.0,
};

export const DEFAULT_APPLIANCES: GasAppliance[] = [
  {
    id: 'app-1',
    name: 'مرجل تدفئة مركزية (شوفاج جداري)',
    category: 'heating',
    powerKw: 24.0,
    flowRateM3h: 2.28,
    quantity: 1,
    enabled: true,
    notes: 'تدفئة المنزل والمياه الساخنة',
  },
  {
    id: 'app-2',
    name: 'طباخ منزلي 4 شعلات مع فرن',
    category: 'cooking',
    powerKw: 9.5,
    flowRateM3h: 0.90,
    quantity: 1,
    enabled: true,
    notes: 'مطبخ الشقة',
  },
];

export function getStoredSavedProjects(): SavedGasProject[] {
  try {
    const raw = localStorage.getItem(SAVED_PROJECTS_KEY);
    if (!raw) {
      // مشروع تجريبي أولي
      const initial: SavedGasProject = {
        id: 'proj-demo-1',
        title: 'مشروع فيلا سكنية - حي النور',
        clientName: 'السيد أحمد',
        buildingType: 'residential',
        date: new Date().toISOString().split('T')[0],
        appliances: DEFAULT_APPLIANCES,
        parameters: DEFAULT_PARAMETERS,
        notes: 'حساب خط الغاز الرئيسي من العداد إلى مجمع التوزيع الداخلي',
      };
      saveProjectsList([initial]);
      return [initial];
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load saved projects', e);
    return [];
  }
}

export function saveProjectsList(projects: SavedGasProject[]): void {
  try {
    localStorage.setItem(SAVED_PROJECTS_KEY, JSON.stringify(projects));
  } catch (e) {
    console.error('Failed to save projects', e);
  }
}

export function getStoredCurrentSession(): {
  projectTitle: string;
  clientName: string;
  appliances: GasAppliance[];
  parameters: GasParameters;
} {
  try {
    const raw = localStorage.getItem(CURRENT_PROJECT_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed to load current session', e);
  }

  return {
    projectTitle: 'مشروع حساب شبكة غاز طبيعي',
    clientName: '',
    appliances: DEFAULT_APPLIANCES,
    parameters: DEFAULT_PARAMETERS,
  };
}

export function saveCurrentSession(data: {
  projectTitle: string;
  clientName: string;
  appliances: GasAppliance[];
  parameters: GasParameters;
}): void {
  try {
    localStorage.setItem(CURRENT_PROJECT_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('Failed to save current session', e);
  }
}
