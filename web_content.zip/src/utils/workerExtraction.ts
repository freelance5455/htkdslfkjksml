export interface ExtractedWorker {
  id: string;
  name: string;
  role: string;
}

export const MAX_IMPORT_FILE_BYTES = 15 * 1024 * 1024; // 15 MB

const IMAGE_MIME_TYPES = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/gif',
  'image/heic',
  'image/heif',
]);

const TEXT_MIME_TYPES = new Set([
  'text/csv',
  'text/plain',
  'application/csv',
]);

const EXTENSION_TO_MIME: Record<string, string> = {
  '.pdf': 'application/pdf',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.heic': 'image/heic',
  '.heif': 'image/heif',
  '.csv': 'text/csv',
  '.txt': 'text/plain',
};

export function resolveImportMimeType(fileName: string, rawMimeType: string): string | null {
  const normalizedMime = rawMimeType.trim().toLowerCase().split(';')[0] ?? '';
  if (normalizedMime === 'image/jpg') {
    return 'image/jpeg';
  }
  if (normalizedMime === 'application/pdf' || IMAGE_MIME_TYPES.has(normalizedMime) || TEXT_MIME_TYPES.has(normalizedMime)) {
    return normalizedMime;
  }

  const lowerName = fileName.trim().toLowerCase();
  const dotIdx = lowerName.lastIndexOf('.');
  if (dotIdx !== -1) {
    const ext = lowerName.slice(dotIdx);
    if (EXTENSION_TO_MIME[ext]) {
      return EXTENSION_TO_MIME[ext];
    }
  }

  return null;
}

export function isTextImportMimeType(mimeType: string): boolean {
  return TEXT_MIME_TYPES.has(mimeType);
}

export function isImageImportMimeType(mimeType: string): boolean {
  return IMAGE_MIME_TYPES.has(mimeType);
}

function sanitizeBulkField(value: unknown): string {
  if (typeof value !== 'string' && typeof value !== 'number') {
    return '';
  }
  return String(value)
    .replace(/[\r\n\t|]+/g, ' ')
    .replace(/,/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function normalizeExtractedWorkers(rawItems: unknown): ExtractedWorker[] {
  if (!Array.isArray(rawItems)) {
    return [];
  }

  const usedIds = new Set<string>();
  const prelim: { id: string; name: string; role: string }[] = [];

  for (const item of rawItems) {
    if (!item || typeof item !== 'object') {
      continue;
    }
    const record = item as Record<string, unknown>;
    const rawId = sanitizeBulkField(record.id);
    const name = sanitizeBulkField(record.name);
    const rawRole = sanitizeBulkField(record.role);

    if (!name) {
      continue;
    }

    const role = rawRole || 'Worker';
    if (rawId) {
      const key = rawId.toLowerCase();
      if (usedIds.has(key)) {
        continue;
      }
      usedIds.add(key);
      prelim.push({ id: rawId, name, role });
    } else {
      prelim.push({ id: '', name, role });
    }
  }

  let autoCounter = 1;
  return prelim.map((entry) => {
    if (entry.id) {
      return entry;
    }
    let candidate = '';
    do {
      candidate = `WRK-${String(autoCounter).padStart(3, '0')}`;
      autoCounter += 1;
    } while (usedIds.has(candidate.toLowerCase()));
    usedIds.add(candidate.toLowerCase());
    return {
      id: candidate,
      name: entry.name,
      role: entry.role,
    };
  });
}

export function formatWorkersAsBulkText(workers: ExtractedWorker[]): string {
  return workers.map((w) => `${w.id}, ${w.name}, ${w.role}`).join('\n');
}

export function formatFileSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) {
    return '0 KB';
  }
  if (bytes < 1024 * 1024) {
    return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  }
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export interface ParsedApiErrorDetails {
  code: number;
  statusText: string;
  message: string;
}

export function parseGeminiErrorDetails(error: unknown): ParsedApiErrorDetails {
  let code = 0;
  let statusText = '';
  let rawMessage = '';

  if (typeof error === 'string') {
    rawMessage = error;
  } else if (error && typeof error === 'object') {
    const errObj = error as { status?: unknown; code?: unknown; message?: unknown };
    if (typeof errObj.code === 'number') {
      code = errObj.code;
    } else if (typeof errObj.status === 'number') {
      code = errObj.status;
    } else if (typeof errObj.status === 'string') {
      statusText = errObj.status;
    }
    if (typeof errObj.message === 'string') {
      rawMessage = errObj.message;
    }
  }

  const trimmed = rawMessage.trim();
  if (trimmed.startsWith('{')) {
    try {
      const parsed = JSON.parse(trimmed) as {
        error?: { code?: unknown; message?: unknown; status?: unknown };
        code?: unknown;
        message?: unknown;
        status?: unknown;
      };
      const inner = parsed.error ?? parsed;
      if (typeof inner.code === 'number') {
        code = inner.code;
      }
      if (typeof inner.status === 'string') {
        statusText = inner.status;
      }
      if (typeof inner.message === 'string' && inner.message.trim()) {
        rawMessage = inner.message.trim();
      }
    } catch {
      // Keep rawMessage when not valid JSON
    }
  }

  return {
    code,
    statusText: statusText.toUpperCase(),
    message: rawMessage || 'Failed to read workers from the uploaded file.',
  };
}

export function isTransientExtractionError(error: unknown): boolean {
  const details = parseGeminiErrorDetails(error);
  if (
    details.code === 429 ||
    details.code === 500 ||
    details.code === 502 ||
    details.code === 503 ||
    details.code === 504
  ) {
    return true;
  }
  if (details.statusText === 'UNAVAILABLE' || details.statusText === 'RESOURCE_EXHAUSTED') {
    return true;
  }
  const lower = details.message.toLowerCase();
  return (
    lower.includes('429') ||
    lower.includes('503') ||
    lower.includes('unavailable') ||
    lower.includes('high demand') ||
    lower.includes('overloaded') ||
    lower.includes('try again later') ||
    lower.includes('resource_exhausted')
  );
}

export function formatExtractionError(error: unknown): { status: number; message: string } {
  const details = parseGeminiErrorDetails(error);
  const lower = details.message.toLowerCase();

  if (
    details.code === 401 ||
    details.code === 403 ||
    lower.includes('api_key_invalid') ||
    lower.includes('permission_denied') ||
    lower.includes('gemini_api_key')
  ) {
    return {
      status: 500,
      message: 'AI extraction service could not authenticate. Check GEMINI_API_KEY in Settings > Secrets.',
    };
  }

  if (
    details.code === 503 ||
    details.statusText === 'UNAVAILABLE' ||
    lower.includes('high demand') ||
    lower.includes('unavailable') ||
    lower.includes('overloaded')
  ) {
    return {
      status: 503,
      message:
        'AI reader is temporarily busy due to high demand. Please click Retry in a few seconds, or paste/upload a CSV file.',
    };
  }

  if (details.code === 429 || details.statusText === 'RESOURCE_EXHAUSTED' || lower.includes('429')) {
    return {
      status: 429,
      message: 'Too many requests right now. Please wait a few seconds and click Retry.',
    };
  }

  return {
    status: details.code >= 400 && details.code < 600 ? details.code : 500,
    message: details.message,
  };
}

