import { CnicRecord, CnicBatchStats, CnicStatusType } from '../types/cnic';

export const PROVINCE_MAP: Record<string, string> = {
  '1': 'Khyber Pakhtunkhwa (KPK)',
  '2': 'FATA / Merged Tribal Districts',
  '3': 'Punjab',
  '4': 'Sindh',
  '5': 'Balochistan',
  '6': 'Islamabad Capital Territory (ICT)',
  '7': 'Gilgit-Baltistan (GB)',
  '8': 'Azad Jammu & Kashmir (AJK)',
};

/**
 * Formats a 13-digit raw CNIC string into NADRA standard XXXXX-XXXXXXX-X format
 */
export function formatCnic(raw: string): string {
  const digits = raw.replace(/\D/g, '');
  if (digits.length !== 13) return raw;
  return `${digits.slice(0, 5)}-${digits.slice(5, 12)}-${digits.slice(12, 13)}`;
}

/**
 * Parses a single CNIC string and returns NADRA breakdown
 */
export function parseCnicRecord(
  rawInput: string,
  index: number,
  seenMap: Map<string, number[]>
): CnicRecord {
  const cleaned = rawInput.trim();
  const digitsOnly = cleaned.replace(/\D/g, '');
  const timestamp = new Date().toISOString();

  let status = 'Awaiting official verification';
  let statusType: CnicStatusType = 'valid';
  let isValid = true;
  let provinceCode: string | null = null;
  let provinceName = 'Unknown';
  let divisionCode: string | null = null;
  let districtCode: string | null = null;
  let tehsilCode: string | null = null;
  let unionCouncilCode: string | null = null;
  let familySerial: string | null = null;
  let genderDigit: number | null = null;
  let gender: 'Male' | 'Female' | 'Unknown' = 'Unknown';

  if (!digitsOnly || digitsOnly.length === 0) {
    return {
      id: `cnic-${index}-${Date.now()}`,
      originalInput: rawInput,
      cnicRaw: digitsOnly,
      cnicFormatted: '',
      isValid: false,
      status: 'Empty or Non-numeric Input',
      statusType: 'invalid_characters',
      provinceCode: null,
      provinceName: 'N/A',
      divisionCode: null,
      districtCode: null,
      tehsilCode: null,
      unionCouncilCode: null,
      familySerial: null,
      genderDigit: null,
      gender: 'Unknown',
      timestamp,
    };
  }

  if (digitsOnly.length !== 13) {
    status = `Invalid CNIC format (${digitsOnly.length}/13 digits)`;
    statusType = 'invalid_length';
    isValid = false;
  } else {
    // Validate province code
    provinceCode = digitsOnly[0];
    if (PROVINCE_MAP[provinceCode]) {
      provinceName = PROVINCE_MAP[provinceCode];
    } else {
      status = `Invalid Region Code (${provinceCode})`;
      statusType = 'invalid_region';
      isValid = false;
    }

    divisionCode = digitsOnly[1];
    districtCode = digitsOnly[2];
    tehsilCode = digitsOnly[3];
    unionCouncilCode = digitsOnly[4];
    familySerial = digitsOnly.slice(5, 12);
    
    const lastNum = parseInt(digitsOnly[12], 10);
    genderDigit = lastNum;
    gender = lastNum % 2 !== 0 ? 'Male' : 'Female';

    // Duplicate detection
    const existing = seenMap.get(digitsOnly);
    if (existing && existing.length > 0) {
      status = 'Duplicate CNIC';
      statusType = 'duplicate';
      isValid = false;
      existing.push(index);
    } else {
      seenMap.set(digitsOnly, [index]);
    }
  }

  return {
    id: `cnic-${index}-${digitsOnly}-${Math.random().toString(36).slice(2, 7)}`,
    originalInput: rawInput,
    cnicRaw: digitsOnly,
    cnicFormatted: digitsOnly.length === 13 ? formatCnic(digitsOnly) : digitsOnly,
    isValid,
    status,
    statusType,
    provinceCode,
    provinceName,
    divisionCode,
    districtCode,
    tehsilCode,
    unionCouncilCode,
    familySerial,
    genderDigit,
    gender,
    timestamp,
    duplicateIndices: seenMap.get(digitsOnly),
  };
}

/**
 * Parses raw input text (lines, commas, tabs) into an array of CnicRecords
 */
export function parseBatchCnics(inputText: string): {
  records: CnicRecord[];
  stats: CnicBatchStats;
} {
  const lines = inputText
    .split(/[\r\n,;]+/)
    .map((line) => line.trim())
    .filter((line) => line.length > 0);

  const seenMap = new Map<string, number[]>();
  const records: CnicRecord[] = [];

  for (let i = 0; i < lines.length; i++) {
    const record = parseCnicRecord(lines[i], i, seenMap);
    records.push(record);
  }

  // Calculate statistics
  let valid = 0;
  let duplicate = 0;
  let invalid = 0;
  let maleCount = 0;
  let femaleCount = 0;
  const provinceDistribution: Record<string, number> = {};

  records.forEach((r) => {
    if (r.statusType === 'valid') {
      valid++;
      if (r.gender === 'Male') maleCount++;
      if (r.gender === 'Female') femaleCount++;
      if (r.provinceName && r.provinceName !== 'Unknown') {
        provinceDistribution[r.provinceName] = (provinceDistribution[r.provinceName] || 0) + 1;
      }
    } else if (r.statusType === 'duplicate') {
      duplicate++;
    } else {
      invalid++;
    }
  });

  return {
    records,
    stats: {
      total: records.length,
      valid,
      duplicate,
      invalid,
      maleCount,
      femaleCount,
      provinceDistribution,
    },
  };
}

/**
 * Generates Excel-compatible CSV report with UTF-8 BOM
 */
export function generateCsvReport(records: CnicRecord[]): string {
  const headers = [
    'Sr No',
    'CNIC Raw (13 Digits)',
    'CNIC Formatted',
    'Verification Status',
    'Status Category',
    'Province / Region',
    'Family Serial Code',
    'Gender',
    'Check Digit',
    'Verification Timestamp',
  ];

  const rows = records.map((r, idx) => {
    return [
      idx + 1,
      `="${r.cnicRaw}"`, // force Excel to treat as text preserving leading zeros
      r.cnicFormatted,
      r.status,
      r.statusType.toUpperCase(),
      r.provinceName || 'N/A',
      r.familySerial ? `="${r.familySerial}"` : 'N/A',
      r.gender,
      r.genderDigit !== null ? r.genderDigit : 'N/A',
      r.timestamp,
    ]
      .map((val) => {
        const str = String(val ?? '');
        if (str.includes(',') || str.includes('"') || str.includes('\n')) {
          return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
      })
      .join(',');
  });

  return [headers.join(','), ...rows].join('\r\n');
}

/**
 * Sample CNIC dataset for instant 1-click testing
 */
export const SAMPLE_CNICS = [
  '3520212345671', // Punjab, Male
  '3520212345672', // Punjab, Female
  '35202-1234567-3', // Punjab with dashes
  '4210198765431', // Sindh, Male
  '4210198765432', // Sindh, Female
  '1730155443321', // KPK, Male
  '5440012345679', // Balochistan, Male
  '6110188990011', // Islamabad ICT, Male
  '3520212345671', // Duplicate of 1st
  '8220199887762', // AJK, Female
  '7150111223341', // Gilgit-Baltistan, Male
  '35202123456',   // Invalid length (11 digits)
  '9999912345671', // Invalid region code (starts with 9)
  '3520212345672', // Duplicate of 2nd
  '42201-7654321-5', // Sindh, formatted
];
