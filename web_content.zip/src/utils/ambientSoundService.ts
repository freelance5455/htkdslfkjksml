// Ambient Soundscape Synthesizer for Hisn Al-Muslim (100% Offline Procedural Web Audio API)
import { AmbientSoundType } from '../types';

export interface AmbientTrackInfo {
  id: AmbientSoundType;
  title: string;
  description: string;
  icon: string;
}

export const AMBIENT_TRACKS: AmbientTrackInfo[] = [
  {
    id: 'rain',
    title: 'مطر هادئ 🌧️',
    description: 'صبيب مطر خفيف وقطرات ماء تعزز السكينة والطمأنينة',
    icon: 'CloudRain',
  },
  {
    id: 'birds',
    title: 'تغريد الطيور 🕊️',
    description: 'أصوات عصافير الصباح ونسيم عليل يُنشط الروح والتركيز',
    icon: 'Feather',
  },
  {
    id: 'nature',
    title: 'نسيم الطبيعة 🍃',
    description: 'حفيف أوراق الشجر والرياح الهادئة بين بساتين النخيل',
    icon: 'Wind',
  },
  {
    id: 'water',
    title: 'خرير الماء 🌊',
    description: 'جريان جدول ماء عذب وصوت انسياب هادئ ومريح',
    icon: 'Droplets',
  },
  {
    id: 'night',
    title: 'سكون الليل 🌙',
    description: 'هدوء ليلي دافئ مع أصوات الطبيعة الخافتة لتهجد خاشع',
    icon: 'Moon',
  },
];

class AmbientAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private currentType: AmbientSoundType = 'none';
  private isRunning: boolean = false;
  private stopTimer: NodeJS.Timeout | null = null;

  // Active audio nodes for cleanup
  private activeNodes: { disconnect: () => void; stop?: () => void }[] = [];
  private activeIntervals: number[] = [];

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private createNoiseBuffer(duration: number = 4): AudioBuffer | null {
    const ctx = this.getContext();
    if (!ctx) return null;
    const bufferSize = ctx.sampleRate * duration;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    
    // Generate pink-ish noise for natural feel
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
      b6 = white * 0.115926;
    }
    return buffer;
  }

  public play(type: AmbientSoundType, volume: number = 0.5) {
    if (type === 'none') {
      this.stop();
      return;
    }

    const ctx = this.getContext();
    if (!ctx) return;

    // Stop currently running ambient sounds
    this.cleanupNodes();

    this.currentType = type;
    this.isRunning = true;

    // Master volume gain
    if (!this.masterGain) {
      this.masterGain = ctx.createGain();
      this.masterGain.connect(ctx.destination);
    }
    this.masterGain.gain.setValueAtTime(0, ctx.currentTime);
    this.masterGain.gain.setTargetAtTime(Math.max(0.01, Math.min(volume, 1)), ctx.currentTime, 0.25);

    switch (type) {
      case 'rain':
        this.buildRain(ctx, this.masterGain);
        break;
      case 'birds':
        this.buildBirds(ctx, this.masterGain);
        break;
      case 'nature':
        this.buildNature(ctx, this.masterGain);
        break;
      case 'water':
        this.buildWater(ctx, this.masterGain);
        break;
      case 'night':
        this.buildNight(ctx, this.masterGain);
        break;
    }
  }

  public setVolume(volume: number) {
    if (!this.masterGain || !this.ctx) return;
    const vol = Math.max(0, Math.min(volume, 1));
    this.masterGain.gain.setTargetAtTime(vol, this.ctx.currentTime, 0.05);
  }

  public setTimer(minutes: number, onTimerEnd?: () => void) {
    if (this.stopTimer) {
      clearTimeout(this.stopTimer);
      this.stopTimer = null;
    }
    if (minutes > 0) {
      this.stopTimer = setTimeout(() => {
        this.stop();
        if (onTimerEnd) onTimerEnd();
      }, minutes * 60 * 1000);
    }
  }

  public stop() {
    if (!this.isRunning) return;
    if (this.ctx && this.masterGain) {
      this.masterGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.3);
      setTimeout(() => {
        this.cleanupNodes();
        this.isRunning = false;
        this.currentType = 'none';
      }, 350);
    } else {
      this.cleanupNodes();
      this.isRunning = false;
      this.currentType = 'none';
    }

    if (this.stopTimer) {
      clearTimeout(this.stopTimer);
      this.stopTimer = null;
    }
  }

  public getCurrentType(): AmbientSoundType {
    return this.currentType;
  }

  public getIsRunning(): boolean {
    return this.isRunning;
  }

  private cleanupNodes() {
    this.activeNodes.forEach(n => {
      try {
        if (n.stop) n.stop();
        n.disconnect();
      } catch {}
    });
    this.activeNodes = [];

    this.activeIntervals.forEach(id => clearInterval(id));
    this.activeIntervals = [];
  }

  // 1. Rain Synthesizer (صوت المطر والقطرات)
  private buildRain(ctx: AudioContext, destination: GainNode) {
    const noiseBuffer = this.createNoiseBuffer(5);
    if (!noiseBuffer) return;

    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    // Filters for rainfall frequency bed
    const lowPass = ctx.createBiquadFilter();
    lowPass.type = 'lowpass';
    lowPass.frequency.value = 1100;

    const highPass = ctx.createBiquadFilter();
    highPass.type = 'highpass';
    highPass.frequency.value = 180;

    const rainGain = ctx.createGain();
    rainGain.gain.value = 0.55;

    noiseSource.connect(lowPass);
    lowPass.connect(highPass);
    highPass.connect(rainGain);
    rainGain.connect(destination);

    noiseSource.start();
    this.activeNodes.push(noiseSource, lowPass, highPass, rainGain);

    // Droplet simulator
    const dropInterval = window.setInterval(() => {
      if (!this.isRunning || this.currentType !== 'rain') return;
      if (Math.random() > 0.45) return;

      const osc = ctx.createOscillator();
      const dropGain = ctx.createGain();
      const freq = 1200 + Math.random() * 1200;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.4, ctx.currentTime + 0.05);

      dropGain.gain.setValueAtTime(0.04 + Math.random() * 0.04, ctx.currentTime);
      dropGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.06);

      osc.connect(dropGain);
      dropGain.connect(destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.07);
    }, 180);

    this.activeIntervals.push(dropInterval);
  }

  // 2. Birds & Morning (تغريد طيور الصباح)
  private buildBirds(ctx: AudioContext, destination: GainNode) {
    // Gentle morning breeze bed
    const noiseBuffer = this.createNoiseBuffer(4);
    if (noiseBuffer) {
      const breeze = ctx.createBufferSource();
      breeze.buffer = noiseBuffer;
      breeze.loop = true;

      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 450;

      const breezeGain = ctx.createGain();
      breezeGain.gain.value = 0.12;

      breeze.connect(lp);
      lp.connect(breezeGain);
      breezeGain.connect(destination);

      breeze.start();
      this.activeNodes.push(breeze, lp, breezeGain);
    }

    // Melodious procedural sparrow chirps
    const playChirp = () => {
      if (!this.isRunning || this.currentType !== 'birds') return;

      const baseFreq = 2400 + Math.random() * 800;
      const notesCount = 2 + Math.floor(Math.random() * 3);
      let startTime = ctx.currentTime;

      for (let i = 0; i < notesCount; i++) {
        const osc = ctx.createOscillator();
        const chirpGain = ctx.createGain();

        osc.type = 'sine';
        const startPitch = baseFreq + (i % 2 === 0 ? 300 : -200);
        const endPitch = baseFreq + (i % 2 === 0 ? -150 : 400);

        osc.frequency.setValueAtTime(startPitch, startTime);
        osc.frequency.exponentialRampToValueAtTime(endPitch, startTime + 0.08);

        chirpGain.gain.setValueAtTime(0.001, startTime);
        chirpGain.gain.linearRampToValueAtTime(0.12, startTime + 0.02);
        chirpGain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.10);

        osc.connect(chirpGain);
        chirpGain.connect(destination);

        osc.start(startTime);
        osc.stop(startTime + 0.11);

        startTime += 0.10 + Math.random() * 0.05;
      }
    };

    // First chirp shortly after starting
    setTimeout(playChirp, 400);

    const birdInterval = window.setInterval(() => {
      if (Math.random() > 0.3) {
        playChirp();
      }
    }, 2200);

    this.activeIntervals.push(birdInterval);
  }

  // 3. Nature & Forest Leaves (نسيم الطبيعة وأوراق الشجر)
  private buildNature(ctx: AudioContext, destination: GainNode) {
    const noiseBuffer = this.createNoiseBuffer(5);
    if (!noiseBuffer) return;

    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuffer;
    noise.loop = true;

    // Resonant bandpass filter with slow sweeping LFO
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 600;
    filter.Q.value = 1.8;

    const lfo = ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.value = 0.20; // 0.2 Hz slow breeze modulation

    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 280; // Modulate frequency by +/- 280 Hz

    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);

    const gain = ctx.createGain();
    gain.gain.value = 0.45;

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(destination);

    noise.start();
    lfo.start();

    this.activeNodes.push(noise, filter, lfo, lfoGain, gain);
  }

  // 4. Water Stream (خرير النهر الهادئ)
  private buildWater(ctx: AudioContext, destination: GainNode) {
    const noiseBuffer = this.createNoiseBuffer(4);
    if (!noiseBuffer) return;

    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuffer;
    noise.loop = true;

    // Dual bandpass filters for bubbling resonance
    const filter1 = ctx.createBiquadFilter();
    filter1.type = 'bandpass';
    filter1.frequency.value = 850;
    filter1.Q.value = 3.5;

    const filter2 = ctx.createBiquadFilter();
    filter2.type = 'bandpass';
    filter2.frequency.value = 450;
    filter2.Q.value = 2.0;

    const waterGain = ctx.createGain();
    waterGain.gain.value = 0.50;

    noise.connect(filter1);
    noise.connect(filter2);
    filter1.connect(waterGain);
    filter2.connect(waterGain);
    waterGain.connect(destination);

    noise.start();
    this.activeNodes.push(noise, filter1, filter2, waterGain);
  }

  // 5. Night Serenity (سكون وهدوء الليل)
  private buildNight(ctx: AudioContext, destination: GainNode) {
    // Deep harmonic soothing chord
    const frequencies = [110, 164.81, 220, 329.63]; // A-minor celestial drone
    const droneGain = ctx.createGain();
    droneGain.gain.value = 0.08;
    droneGain.connect(destination);
    this.activeNodes.push(droneGain);

    frequencies.forEach(f => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = f;
      osc.connect(droneGain);
      osc.start();
      this.activeNodes.push(osc);
    });

    // Soft gentle crickets
    const playCricket = () => {
      if (!this.isRunning || this.currentType !== 'night') return;
      const cricketOsc = ctx.createOscillator();
      const cricketGain = ctx.createGain();

      cricketOsc.type = 'sine';
      cricketOsc.frequency.value = 4600 + Math.random() * 200;

      cricketGain.gain.setValueAtTime(0.001, ctx.currentTime);
      cricketGain.gain.linearRampToValueAtTime(0.02, ctx.currentTime + 0.02);
      cricketGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.06);

      cricketOsc.connect(cricketGain);
      cricketGain.connect(destination);

      cricketOsc.start();
      cricketOsc.stop(ctx.currentTime + 0.07);
    };

    const nightInterval = window.setInterval(() => {
      if (Math.random() > 0.4) {
        playCricket();
      }
    }, 600);

    this.activeIntervals.push(nightInterval);
  }
}

// Global Singleton Instance
export const ambientEngine = new AmbientAudioEngine();
