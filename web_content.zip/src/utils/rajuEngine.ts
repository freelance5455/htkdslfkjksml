import type {
  MemoryCategory,
  PersonalMemory,
  PracticeAttempt,
  SmartQuestion,
  SupportedLanguage,
  TaskCategory,
  TaskPriority,
  VoiceProfileInfo,
} from '../types';

export const VOICE_PROFILES: VoiceProfileInfo[] = [
  {
    id: 'Natural Male',
    name: 'Natural Male',
    subtitle: 'Charon • Articulate & Calm',
    geminiVoice: 'Charon',
    styleDescription: 'Warm, articulate, calm, and natural male conversational tone',
    sampleGreeting: {
      English: 'Hello! I am RAJU AI in Natural Male voice. Ready to explore ideas together.',
      Hindi: 'नमस्ते! मैं राजू एआई हूँ। आइए आज कुछ नया सीखते और बनाते हैं।',
      Hinglish: 'Namaste! Main RAJU AI hoon. Aaj hum kis topic par baat karenge?',
      Japanese: 'こんにちは！私はRAJU AIです。一緒に楽しく学びましょう。',
    },
  },
  {
    id: 'Natural Female',
    name: 'Natural Female',
    subtitle: 'Kore • Poised & Empathetic',
    geminiVoice: 'Kore',
    styleDescription: 'Clear, empathetic, natural, and poised female conversational tone',
    sampleGreeting: {
      English: 'Welcome to RAJU AI! How can I assist you with your studies or projects today?',
      Hindi: 'राजू एआई में आपका स्वागत है! आज मैं आपकी पढ़ाई या प्रोजेक्ट में कैसे मदद करूँ?',
      Hinglish: 'Welcome to RAJU AI! Aaj main aapki study ya coding mein kaise help karun?',
      Japanese: 'RAJU AIへようこそ！今日はどのようなお手伝いをしましょうか？',
    },
  },
  {
    id: 'Anime Hero',
    name: 'Anime Hero',
    subtitle: 'Fenrir • Bold & Inspiring',
    geminiVoice: 'Fenrir',
    styleDescription: 'Energetic, determined, courageous anime protagonist tone with inspiring conviction',
    sampleGreeting: {
      English: 'Never give up on your goals! Let us conquer every exam and coding challenge together!',
      Hindi: 'अपने लक्ष्य से कभी पीछे मत हटो! चलो मिलकर हर चुनौती को पार करते हैं!',
      Hinglish: 'Apne goal se kabhi peeche mat hato! Chalo milkar har exam aur challenge crack karte hain!',
      Japanese: '絶対に諦めるな！一緒にすべての試練を乗り越えていこう！',
    },
  },
  {
    id: 'Anime Girl',
    name: 'Anime Girl',
    subtitle: 'Zephyr • Bright & Expressive',
    geminiVoice: 'Zephyr',
    styleDescription: 'Bright, cheerful, expressive, and friendly anime companion tone',
    sampleGreeting: {
      English: 'Yay! Good to see you! Let us learn Japanese, solve quizzes, and create something amazing!',
      Hindi: 'नमस्ते दोस्त! चलो आज जापानी भाषा और विज्ञान को मजेदार तरीके से सीखते हैं!',
      Hinglish: 'Yay! Aaj hum Japanese aur science bahut fun tarike se seekhenge!',
      Japanese: 'ヤッホー！今日も一緒に日本語や勉強を楽しく頑張ろうね！',
    },
  },
  {
    id: 'Japanese Teacher',
    name: 'Japanese Teacher',
    subtitle: 'Puck • Patient Sensei (EN/HI/JP)',
    geminiVoice: 'Puck',
    styleDescription: 'Patient, encouraging, crystal-clear Japanese language Sensei teaching in English, Hindi, Hinglish, and Japanese',
    sampleGreeting: {
      English: 'Konnichiwa! I am your RAJU AI Japanese Sensei. Let us master Hiragana, Kanji, and natural conversation step by step!',
      Hindi: 'कोन्निचिवा! मैं आपका जापानी शिक्षक हूँ। आइए धीरे-धीरे हिरागाना, कांजी और जापानी बोलना सीखते हैं।',
      Hinglish: 'Konnichiwa! Main aapka Japanese Sensei hoon. Chalo easy Hinglish examples ke saath Japanese seekhte hain!',
      Japanese: 'こんにちは！日本語の先生です。ひらがなから漢字まで、楽しく丁寧に練習しましょう！',
    },
  },
  {
    id: 'My Voice',
    name: 'My Voice',
    subtitle: 'Consent-Gated Custom Voice',
    geminiVoice: 'Puck',
    styleDescription: 'Optional future custom voice integration requiring verified voice-owner consent',
    isFutureFeature: true,
    sampleGreeting: {
      English: 'My Voice is reserved for authorized custom voice cloning with explicit voice-owner consent.',
      Hindi: 'माई वॉइस भविष्य के अधिकृत वॉइस क्लोनिंग फीचर के लिए सुरक्षित है जिसमें स्पष्ट सहमति आवश्यक है।',
      Hinglish: 'My Voice future authorized voice cloning ke liye hai jismein explicit consent zaroori hai.',
      Japanese: 'マイボイスは、明示的な同意を伴う将来の認定音声クローン機能向けに予約されています。',
    },
  },
];

export function extractReadableError(err: unknown, fallback = 'An unexpected error occurred.'): string {
  if (!err) return fallback;
  if (typeof err === 'string') {
    const trimmed = err.trim();
    return trimmed && trimmed !== '[object Object]' ? trimmed : fallback;
  }
  if (err instanceof Error) {
    const msg = (err.message || '').trim();
    if (msg && msg !== '[object Object]') return msg;
  }
  if (typeof err === 'object') {
    const record = err as Record<string, unknown>;
    for (const key of ['message', 'error', 'reason', 'detail', 'statusText']) {
      const val = record[key];
      if (typeof val === 'string' && val.trim() && val !== '[object Object]') {
        return val.trim();
      }
      if (val && typeof val === 'object') {
        const nested = extractReadableError(val, '');
        if (nested) return nested;
      }
    }
    try {
      const serialized = JSON.stringify(record);
      if (serialized && serialized !== '{}' && serialized.length < 400) {
        return serialized;
      }
    } catch {
      // ignore circular JSON
    }
  }
  return fallback;
}

export function normalizeAnswerText(val: string): string {
  return (val || '')
    .toLowerCase()
    .trim()
    .replace(/[。、.,!?！？"'`~〜()（）[\]]/g, '')
    .replace(/\s+/g, ' ');
}

export function evaluateSmartAnswer(
  question: SmartQuestion,
  userAnswer: string,
  selectedOptionIndex?: number
): { isCorrect: boolean; feedback: string } {
  if (question.type === 'mcq') {
    const correctIdx = typeof question.correctIndex === 'number' ? question.correctIndex : 0;
    const isCorrect = selectedOptionIndex === correctIdx;
    const correctLabel = question.options?.[correctIdx] ?? question.expectedAnswer;
    return {
      isCorrect,
      feedback: isCorrect
        ? `Correct! ${question.explanation}`
        : `Incorrect. Correct answer: "${correctLabel}". ${question.explanation}`,
    };
  }

  const normalizedUser = normalizeAnswerText(userAnswer);
  if (!normalizedUser) {
    return { isCorrect: false, feedback: 'Please enter an answer before submitting.' };
  }

  const accepted = [question.expectedAnswer, ...(question.acceptableAnswers || [])]
    .map(normalizeAnswerText)
    .filter(Boolean);

  if (question.type === 'descriptive') {
    const expectedTokens = normalizeAnswerText(question.expectedAnswer)
      .split(' ')
      .filter((w) => w.length > 3);
    const hits = expectedTokens.filter((tok) => normalizedUser.includes(tok));
    const ratio = expectedTokens.length > 0 ? hits.length / expectedTokens.length : 0;
    const isCorrect = ratio >= 0.45 || accepted.some((a) => normalizedUser.includes(a));
    return {
      isCorrect,
      feedback: isCorrect
        ? `Great explanation! Key concept matched. ${question.explanation}`
        : `Needs review. Key points expected: "${question.expectedAnswer}". ${question.explanation}`,
    };
  }

  const isCorrect = accepted.some(
    (ans) => normalizedUser === ans || (ans.length >= 4 && normalizedUser.includes(ans) && normalizedUser.length <= ans.length + 12)
  );
  return {
    isCorrect,
    feedback: isCorrect
      ? `Correct! ${question.explanation}`
      : `Not quite. Expected answer: "${question.expectedAnswer}". ${question.explanation}`,
  };
}

export interface WeakTopicSummary {
  topic: string;
  totalAttempts: number;
  correctCount: number;
  incorrectCount: number;
  accuracyPercent: number;
  isWeak: boolean;
}

export function computeWeakTopics(attempts: PracticeAttempt[]): WeakTopicSummary[] {
  const map = new Map<string, { total: number; correct: number }>();
  for (const att of attempts) {
    const key = (att.topic || 'General').trim();
    const cur = map.get(key) || { total: 0, correct: 0 };
    cur.total += 1;
    if (att.isCorrect) cur.correct += 1;
    map.set(key, cur);
  }
  const results: WeakTopicSummary[] = [];
  for (const [topic, stats] of map.entries()) {
    const accuracyPercent = Math.round((stats.correct / stats.total) * 100);
    results.push({
      topic,
      totalAttempts: stats.total,
      correctCount: stats.correct,
      incorrectCount: stats.total - stats.correct,
      accuracyPercent,
      isWeak: accuracyPercent < 70,
    });
  }
  return results.sort((a, b) => a.accuracyPercent - b.accuracyPercent);
}

export function buildAntiRepetitionList(attempts: PracticeAttempt[], maxItems = 15): string[] {
  const seen = new Set<string>();
  const list: string[] = [];
  for (const att of attempts) {
    const stem = (att.questionText || '').trim().slice(0, 140);
    if (stem && !seen.has(stem)) {
      seen.add(stem);
      list.push(stem);
      if (list.length >= maxItems) break;
    }
  }
  return list;
}

export function isValidFirestoreId(id: string): boolean {
  return typeof id === 'string' && id.length >= 1 && id.length <= 128 && /^[a-zA-Z0-9_-]+$/.test(id);
}

export function calculateLevelFromXP(xp: number): {
  level: number;
  currentLevelXp: number;
  nextLevelXp: number;
  progressPercent: number;
} {
  const safeXp = Math.max(0, Math.floor(xp));
  const xpPerLevel = 250;
  const level = Math.min(1000, Math.floor(safeXp / xpPerLevel) + 1);
  const currentLevelXp = safeXp % xpPerLevel;
  const progressPercent = Math.min(100, Math.round((currentLevelXp / xpPerLevel) * 100));
  return {
    level,
    currentLevelXp,
    nextLevelXp: xpPerLevel,
    progressPercent,
  };
}

export function computeMasteryLevel(
  score: number,
  totalQuestions: number
): 'Beginner' | 'Intermediate' | 'Advanced' | 'Mastered' {
  if (totalQuestions <= 0) return 'Beginner';
  const ratio = score / totalQuestions;
  if (ratio >= 0.9) return 'Mastered';
  if (ratio >= 0.75) return 'Advanced';
  if (ratio >= 0.5) return 'Intermediate';
  return 'Beginner';
}

export function validateMemoryInput(input: {
  title: string;
  content: string;
  category: string;
  userConsented: boolean;
}): { valid: boolean; error?: string; sanitized?: { title: string; content: string; category: MemoryCategory; userConsented: true } } {
  const allowedCategories: MemoryCategory[] = ['Preference', 'Study Goal', 'Language', 'Project', 'Personal'];
  if (!input.userConsented) {
    return { valid: false, error: 'Explicit consent is required before saving personal memory.' };
  }
  const trimmedTitle = (input.title || '').trim();
  const trimmedContent = (input.content || '').trim();
  if (!trimmedTitle) {
    return { valid: false, error: 'Memory title cannot be empty.' };
  }
  if (trimmedTitle.length > 150) {
    return { valid: false, error: 'Memory title must be 150 characters or fewer.' };
  }
  if (!trimmedContent) {
    return { valid: false, error: 'Memory content cannot be empty.' };
  }
  if (trimmedContent.length > 2000) {
    return { valid: false, error: 'Memory content must be 2,000 characters or fewer.' };
  }
  if (!allowedCategories.includes(input.category as MemoryCategory)) {
    return { valid: false, error: 'Invalid memory category selected.' };
  }
  return {
    valid: true,
    sanitized: {
      title: trimmedTitle,
      content: trimmedContent,
      category: input.category as MemoryCategory,
      userConsented: true,
    },
  };
}

export function validateTaskInput(input: {
  title: string;
  category: string;
  priority: string;
  dueDate: string;
}): {
  valid: boolean;
  error?: string;
  sanitized?: { title: string; category: TaskCategory; priority: TaskPriority; dueDate: string };
} {
  const allowedCategories: TaskCategory[] = ['Study', 'Japanese', 'Coding', 'Daily', 'Research'];
  const allowedPriorities: TaskPriority[] = ['High', 'Medium', 'Low'];
  const trimmedTitle = (input.title || '').trim();
  const trimmedDue = (input.dueDate || '').trim() || new Date().toISOString().slice(0, 10);

  if (!trimmedTitle) {
    return { valid: false, error: 'Task title is required.' };
  }
  if (trimmedTitle.length > 200) {
    return { valid: false, error: 'Task title must be 200 characters or fewer.' };
  }
  if (!allowedCategories.includes(input.category as TaskCategory)) {
    return { valid: false, error: 'Invalid task category.' };
  }
  if (!allowedPriorities.includes(input.priority as TaskPriority)) {
    return { valid: false, error: 'Invalid task priority.' };
  }
  if (trimmedDue.length > 40) {
    return { valid: false, error: 'Due date string is too long.' };
  }
  return {
    valid: true,
    sanitized: {
      title: trimmedTitle,
      category: input.category as TaskCategory,
      priority: input.priority as TaskPriority,
      dueDate: trimmedDue,
    },
  };
}

export function sanitizeChatMessage(raw: string): string {
  return (raw || '').trim().slice(0, 20000);
}

export function getRelevantMemories(memories: PersonalMemory[], query: string, maxCount = 8): PersonalMemory[] {
  const consented = memories.filter((m) => m.userConsented);
  if (!query.trim()) return consented.slice(0, maxCount);
  const terms = query
    .toLowerCase()
    .split(/\s+/)
    .filter((w) => w.length > 2);

  return [...consented]
    .sort((a, b) => {
      const aText = `${a.title} ${a.content} ${a.category}`.toLowerCase();
      const bText = `${b.title} ${b.content} ${b.category}`.toLowerCase();
      const aScore = terms.reduce((acc, term) => acc + (aText.includes(term) ? 1 : 0), 0);
      const bScore = terms.reduce((acc, term) => acc + (bText.includes(term) ? 1 : 0), 0);
      return bScore - aScore;
    })
    .slice(0, maxCount);
}

export function float32ToBase64Pcm16(float32Array: Float32Array): string {
  const int16 = new Int16Array(float32Array.length);
  for (let i = 0; i < float32Array.length; i++) {
    const s = Math.max(-1, Math.min(1, float32Array[i]));
    int16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  const bytes = new Uint8Array(int16.buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  if (typeof btoa === 'function') {
    return btoa(binary);
  }
  return Buffer.from(bytes).toString('base64');
}

export function base64Pcm16ToFloat32(base64: string): Float32Array {
  let bytes: Uint8Array;
  if (typeof atob === 'function') {
    const binary = atob(base64);
    bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
  } else {
    bytes = new Uint8Array(Buffer.from(base64, 'base64'));
  }
  const int16 = new Int16Array(bytes.buffer, bytes.byteOffset, Math.floor(bytes.byteLength / 2));
  const float32 = new Float32Array(int16.length);
  for (let i = 0; i < int16.length; i++) {
    float32[i] = int16[i] / 32768.0;
  }
  return float32;
}
