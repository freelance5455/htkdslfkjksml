import { Visitor } from '../types';

export function formatPhoneNumber(value: string): string {
  const digits = value.replace(/\D/g, '');
  if (digits.length <= 2) return digits;
  if (digits.length <= 6) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  if (digits.length <= 10) return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7, 11)}`;
}

export function generateWhatsAppMessage(visitor: Visitor, churchName: string = 'Nossa Igreja'): string {
  const cleanPhone = (visitor.phone || '').replace(/\D/g, '');
  if (!cleanPhone) return '';

  const firstName = visitor.name.split(' ')[0];
  const message = `A Paz do Senhor, ${firstName}! 🙏\n\nFoi uma alegria imensa ter você e sua família conosco no culto na ${churchName}! Esperamos de coração que tenha se sentido acolhido(a) na presença de Deus.\n\nNossos cultos acontecem regularmente e as portas estão sempre abertas para você voltar. Se precisar de oração ou quiser conversar, estamos aqui à disposição!\n\n"Alegrei-me quando me disseram: Vamos à casa do SENHOR." (Salmos 122:1)\n\nQue Deus abençoe grandemente sua semana! ✨`;

  const encoded = encodeURIComponent(message);
  // Add 55 Brazilian country code if missing
  const targetPhone = cleanPhone.length <= 11 ? `55${cleanPhone}` : cleanPhone;
  return `https://wa.me/${targetPhone}?text=${encoded}`;
}
