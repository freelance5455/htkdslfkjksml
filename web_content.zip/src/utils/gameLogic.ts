/**
 * Pure Game Rules & Math Engine for Pixel Farm RPG
 * Fully unit-testable via node:test without DOM dependencies.
 */

import type { Tier, TimeOfDay } from '../types/game.ts';

/**
 * Required EXP to reach the next level
 * L1->2: 100
 * L2->3: 220
 * L3->4: 400
 * L4->5: 650
 * L6+: Math.floor(100 * Math.pow(level, 1.65))
 */
export function getRequiredExp(level: number): number {
  if (level <= 1) return 100;
  if (level === 2) return 220;
  if (level === 3) return 400;
  if (level === 4) return 650;
  return Math.floor(100 * Math.pow(level, 1.65));
}

/**
 * Adds experience with strict anti-level-skip & overflow caps:
 * 1. Single harvest EXP cannot exceed 25% of current level's required EXP (at Level >= 5)
 * 2. Only +1 Level allowed at any single update
 * 3. Excess EXP over current level is capped at 25% of the *new* level's requirement
 */
export function addExperience(
  currentLevel: number,
  currentExp: number,
  rawGainedExp: number,
  isSingleHarvest = false
): {
  newLevel: number;
  newExp: number;
  leveledUp: boolean;
  actualGainedExp: number;
  excessExp: number;
} {
  const reqExp = getRequiredExp(currentLevel);

  let effectiveGained = Math.max(0, rawGainedExp);
  if (isSingleHarvest && currentLevel >= 5) {
    const singleHarvestCap = Math.floor(reqExp * 0.25);
    if (effectiveGained > singleHarvestCap) {
      effectiveGained = singleHarvestCap;
    }
  }

  const potentialExp = currentExp + effectiveGained;

  if (potentialExp >= reqExp) {
    // Level up by exactly 1 level
    const newLevel = currentLevel + 1;
    const rawExcess = potentialExp - reqExp;
    const nextReqExp = getRequiredExp(newLevel);
    // Cap excess exp at 25% of next level to avoid skipping or immediate fill
    const maxAllowedExcess = Math.floor(nextReqExp * 0.25);
    const newExp = Math.min(rawExcess, maxAllowedExcess);

    return {
      newLevel,
      newExp,
      leveledUp: true,
      actualGainedExp: effectiveGained,
      excessExp: rawExcess,
    };
  }

  return {
    newLevel: currentLevel,
    newExp: potentialExp,
    leveledUp: false,
    actualGainedExp: effectiveGained,
    excessExp: 0,
  };
}

/**
 * Calculates animal harvest yield and exp based on animal count and satisfaction
 */
export function calculateAnimalHarvest(
  count: number,
  satisfaction: number,
  baseYield: number,
  baseExp: number,
  isRainbow = false
) {
  const safeCount = Math.max(1, Math.min(10, count));
  let yieldMultiplier = 1.0;
  let expBonus = 0;
  let isGoldenStar = false;

  if (satisfaction >= 100) {
    yieldMultiplier = 1.35; // +35%
    expBonus = 0.1; // +10% EXP
    isGoldenStar = true;
  } else if (satisfaction >= 75) {
    yieldMultiplier = 1.2; // +20%
  } else if (satisfaction >= 50) {
    yieldMultiplier = 1.1; // +10%
  }

  if (isRainbow) {
    yieldMultiplier *= 2;
  }

  const totalYield = Math.max(1, Math.round(baseYield * safeCount * yieldMultiplier));
  const totalExp = Math.round(baseExp * safeCount * (1 + expBonus));

  return {
    totalYield,
    totalExp,
    isGoldenStar,
  };
}

/**
 * Calculates aquatic harvest based on fish count and favorite food milestone
 */
export function calculateAquaticHarvest(
  count: number,
  favoriteFoodLevel: number,
  baseYield: number,
  baseExp: number,
  isRainbow = false
) {
  const safeCount = Math.max(1, Math.min(10, count));
  let bonusRatio = 0;
  if (favoriteFoodLevel >= 100) bonusRatio = 0.2; // +20%
  else if (favoriteFoodLevel >= 75) bonusRatio = 0.15; // +15%
  else if (favoriteFoodLevel >= 50) bonusRatio = 0.1; // +10%
  else if (favoriteFoodLevel >= 25) bonusRatio = 0.05; // +5%

  let multiplier = 1 + bonusRatio;
  if (isRainbow) multiplier *= 2;

  const totalYield = Math.max(1, Math.round(baseYield * safeCount * multiplier));
  const totalExp = Math.round(baseExp * safeCount);

  return {
    totalYield,
    totalExp,
  };
}

/**
 * Converts hour (0-23) to 6 time of day periods
 */
export function getTimeOfDayFromHour(hour: number): TimeOfDay {
  if (hour >= 5 && hour < 8) return 'dawn';
  if (hour >= 8 && hour < 16) return 'day';
  if (hour >= 16 && hour < 18) return 'golden';
  if (hour >= 18 && hour < 20) return 'dusk';
  if (hour >= 20 && hour < 23) return 'night';
  return 'midnight';
}

/**
 * Returns Gacha success rate for Bee breeding based on pity count (0-5)
 * Pity count: 0 (1st) = 15%, 1 (2nd) = 30%, 2 (3rd) = 50%, 3 (4th) = 70%, 4 (5th) = 85%, 5 (6th) = 100%
 */
export function getBeeGachaRate(pityCount: number): number {
  switch (pityCount) {
    case 0:
      return 0.15;
    case 1:
      return 0.3;
    case 2:
      return 0.5;
    case 3:
      return 0.7;
    case 4:
      return 0.85;
    default:
      return 1.0; // 6th attempt guaranteed!
  }
}

/**
 * Calculates batch craft time with -10% bonus for batches >= 10 units
 */
export function getBatchCraftWaitTime(unitSeconds: number, count: number): number {
  if (count <= 0) return 0;
  const baseTime = unitSeconds * count;
  if (count >= 10) {
    return Math.max(1, Math.round(baseTime * 0.9));
  }
  return baseTime;
}

/**
 * Calculates sell price for animal or fish:
 * Store species (T1-3): 75% buy price
 * Bred species (T4): 1.5x baseValuation
 * Bred species (T5): 2.0x baseValuation
 */
export function getAnimalSellPrice(tier: Tier, buyPrice: number, baseValuation: number): number {
  if (tier <= 3) {
    return Math.max(10, Math.floor(buyPrice * 0.75));
  }
  if (tier === 4) {
    return Math.floor(baseValuation * 1.5);
  }
  return Math.floor(baseValuation * 2.0);
}

/**
 * Butler pet config
 */
export function getButlerPerks(tier: Tier) {
  switch (tier) {
    case 1:
      return {
        intervalSeconds: 60,
        missChance: 0.35,
        yieldBonus: 0,
        goldBonus: 0,
        timeReduction: 0,
        gemDropChance: 0,
        label: 'Phổ Thông (Chậm, mải chơi 35%)',
      };
    case 2:
      return {
        intervalSeconds: 40,
        missChance: 0.2,
        yieldBonus: 0,
        goldBonus: 0,
        timeReduction: 0,
        gemDropChance: 0,
        label: 'Chọn Lọc (Vừa phải, bỏ sót 20%)',
      };
    case 3:
      return {
        intervalSeconds: 25,
        missChance: 0.08,
        yieldBonus: 0,
        goldBonus: 0.05,
        timeReduction: 0,
        gemDropChance: 0,
        label: 'Quý Hiếm (Nhanh nhẹn, +5% Vàng)',
      };
    case 4:
      return {
        intervalSeconds: 10,
        missChance: 0,
        yieldBonus: 0.15,
        goldBonus: 0.1,
        timeReduction: 0.1,
        gemDropChance: 0.02,
        label: 'Thần Thoại (Chăm chỉ 100%, +15% sản lượng, -10% thời gian)',
      };
    case 5:
    default:
      return {
        intervalSeconds: 3,
        missChance: 0,
        yieldBonus: 0.3,
        goldBonus: 0.25,
        timeReduction: 0.2,
        gemDropChance: 0.1,
        label: 'Vũ Trụ (Tức thì, +30% sản lượng, -20% thời gian, 10% rơi Ngọc Bích)',
      };
  }
}
