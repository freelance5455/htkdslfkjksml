import React from 'react';

interface Token {
  type: 'plain' | 'keyword' | 'string' | 'comment' | 'number' | 'tag' | 'attr' | 'type';
  value: string;
}

const KEYWORDS = new Set([
  'import',
  'export',
  'from',
  'default',
  'const',
  'let',
  'var',
  'function',
  'return',
  'if',
  'else',
  'for',
  'while',
  'switch',
  'case',
  'break',
  'continue',
  'try',
  'catch',
  'finally',
  'throw',
  'new',
  'async',
  'await',
  'class',
  'extends',
  'implements',
  'interface',
  'type',
  'enum',
  'public',
  'private',
  'protected',
  'readonly',
  'true',
  'false',
  'null',
  'undefined',
  'def',
  'elif',
  'pass',
  'with',
  'as',
  'in',
  'not',
  'and',
  'or',
  'is',
  'lambda',
  'yield',
  'None',
  'True',
  'False',
  'fn',
  'pub',
  'struct',
  'impl',
  'use',
  'mod',
  'match',
  'mut',
  'func',
  'package',
  'SELECT',
  'FROM',
  'WHERE',
  'INSERT',
  'UPDATE',
  'DELETE',
  'CREATE',
  'TABLE',
]);

const TOKEN_CLASSES: Record<Token['type'], string> = {
  plain: 'text-[#111827]',
  keyword: 'text-[#7C3AED] font-medium',
  string: 'text-[#047857]',
  comment: 'text-[#6B7280] italic',
  number: 'text-[#B45309]',
  tag: 'text-[#1D4ED8]',
  attr: 'text-[#0F766E]',
  type: 'text-[#0369A1]',
};

function tokenizeLine(line: string, language: string): Token[] {
  const tokens: Token[] = [];
  const isHtmlOrXml = language === 'html' || language === 'xml' || language === 'svg';
  const isPythonOrBash =
    language === 'python' || language === 'bash' || language === 'yaml' || language === 'sh';

  let i = 0;
  const len = line.length;

  while (i < len) {
    // Line comments
    if (!isPythonOrBash && line[i] === '/' && line[i + 1] === '/') {
      tokens.push({ type: 'comment', value: line.slice(i) });
      break;
    }
    if (isPythonOrBash && line[i] === '#') {
      tokens.push({ type: 'comment', value: line.slice(i) });
      break;
    }
    if (isHtmlOrXml && line.slice(i, i + 4) === '<!--') {
      const end = line.indexOf('-->', i + 4);
      const sliceEnd = end === -1 ? len : end + 3;
      tokens.push({ type: 'comment', value: line.slice(i, sliceEnd) });
      i = sliceEnd;
      continue;
    }

    // Strings
    const ch = line[i];
    if (ch === '"' || ch === "'" || ch === '`') {
      let j = i + 1;
      while (j < len) {
        if (line[j] === '\\') {
          j += 2;
          continue;
        }
        if (line[j] === ch) {
          j++;
          break;
        }
        j++;
      }
      tokens.push({ type: 'string', value: line.slice(i, j) });
      i = j;
      continue;
    }

    // HTML/JSX tags
    if (ch === '<' && /[a-zA-Z/]/.test(line[i + 1] || '')) {
      const tagMatch = line.slice(i).match(/^<\/?[a-zA-Z0-9_.-]+/);
      if (tagMatch) {
        tokens.push({ type: 'tag', value: tagMatch[0] });
        i += tagMatch[0].length;
        continue;
      }
    }

    // Numbers
    if (/[0-9]/.test(ch) && (i === 0 || !/[a-zA-Z0-9_$]/.test(line[i - 1]))) {
      const numMatch = line.slice(i).match(/^(?:0x[0-9a-fA-F]+|[0-9]+(?:\.[0-9]+)?)/);
      if (numMatch) {
        tokens.push({ type: 'number', value: numMatch[0] });
        i += numMatch[0].length;
        continue;
      }
    }

    // Identifiers & keywords
    if (/[a-zA-Z_$]/.test(ch)) {
      const idMatch = line.slice(i).match(/^[a-zA-Z0-9_$]+/);
      if (idMatch) {
        const word = idMatch[0];
        if (KEYWORDS.has(word)) {
          tokens.push({ type: 'keyword', value: word });
        } else if (/^[A-Z][a-zA-Z0-9_]*$/.test(word)) {
          tokens.push({ type: 'type', value: word });
        } else {
          tokens.push({ type: 'plain', value: word });
        }
        i += word.length;
        continue;
      }
    }

    // Consume plain punctuation/whitespace in batches
    let j = i + 1;
    while (
      j < len &&
      !/[a-zA-Z0-9_$"'`</#]/.test(line[j])
    ) {
      j++;
    }
    tokens.push({ type: 'plain', value: line.slice(i, j) });
    i = j;
  }

  return tokens;
}

export function HighlightedCode({
  code,
  language,
  showLineNumbers = false,
  compact = false,
}: {
  code: string;
  language: string;
  showLineNumbers?: boolean;
  compact?: boolean;
}) {
  const lines = code.split('\n');

  return (
    <pre
      className={`overflow-x-auto font-mono leading-relaxed text-[#111827] ${
        compact ? 'text-[12px] p-3' : 'text-[13px] p-4'
      }`}
    >
      <code>
        {lines.map((line, lineIdx) => {
          const tokens = tokenizeLine(line, language);
          return (
            <div key={lineIdx} className="table-row">
              {showLineNumbers && (
                <span className="table-cell select-none pr-4 text-right text-[11px] text-[#9CA3AF] tabular-nums">
                  {lineIdx + 1}
                </span>
              )}
              <span className="table-cell whitespace-pre">
                {tokens.length === 0 ? (
                  '\u00A0'
                ) : (
                  tokens.map((tok, tIdx) => (
                    <span key={tIdx} className={TOKEN_CLASSES[tok.type]}>
                      {tok.value}
                    </span>
                  ))
                )}
              </span>
            </div>
          );
        })}
      </code>
    </pre>
  );
}
