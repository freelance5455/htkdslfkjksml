// Helper to synthesize authentic retro/gaming sound effects into audio Blobs
// so users can test immediately if they don't have local MP3s at hand.

function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;
  
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;
  
  const samples = buffer.length;
  const dataSize = samples * blockAlign;
  const bufferLength = 44 + dataSize;
  const arrayBuffer = new ArrayBuffer(bufferLength);
  const view = new DataView(arrayBuffer);
  
  function writeString(offset: number, string: string) {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  }
  
  writeString(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, format, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);
  writeString(36, 'data');
  view.setUint32(40, dataSize, true);
  
  let offset = 44;
  const channelData: Float32Array[] = [];
  for (let c = 0; c < numChannels; c++) {
    channelData.push(buffer.getChannelData(c));
  }
  
  for (let i = 0; i < samples; i++) {
    for (let c = 0; c < numChannels; c++) {
      let sample = Math.max(-1, Math.min(1, channelData[c][i]));
      sample = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
      view.setInt16(offset, sample, true);
      offset += 2;
    }
  }
  
  return new Blob([view], { type: 'audio/wav' });
}

export async function createGamingSound(type: 'headshot' | 'victory' | 'airhorn' | 'cyber_alarm' | 'laser'): Promise<{ name: string; blob: Blob; duration: number }> {
  const sampleRate = 44100;
  
  if (type === 'headshot') {
    const duration = 1.2;
    const ctx = new OfflineAudioContext(1, sampleRate * duration, sampleRate);
    
    // Low frequency punch + noise transient
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(150, 0);
    osc.frequency.exponentialRampToValueAtTime(30, 0.4);
    
    gain.gain.setValueAtTime(1, 0);
    gain.gain.exponentialRampToValueAtTime(0.001, 1.1);
    
    // Noise buffer for snap
    const bufferSize = sampleRate * 0.15;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }
    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.8, 0);
    noiseGain.gain.exponentialRampToValueAtTime(0.01, 0.12);
    
    osc.connect(gain).connect(ctx.destination);
    whiteNoise.connect(noiseGain).connect(ctx.destination);
    
    osc.start(0);
    whiteNoise.start(0);
    osc.stop(duration);
    whiteNoise.stop(0.15);
    
    const rendered = await ctx.startRendering();
    const blob = audioBufferToWav(rendered);
    return { name: 'REX Headshot Impact', blob, duration };
  }
  
  if (type === 'airhorn') {
    const duration = 1.0;
    const ctx = new OfflineAudioContext(1, sampleRate * duration, sampleRate);
    
    const freqs = [466.16, 466.16 * 1.5, 466.16 * 2]; // Bb tone triad
    freqs.forEach((f) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, 0);
      osc.frequency.linearRampToValueAtTime(f * 1.02, 0.6);
      
      gain.gain.setValueAtTime(0.3, 0);
      gain.gain.exponentialRampToValueAtTime(0.001, 0.95);
      
      osc.connect(gain).connect(ctx.destination);
      osc.start(0);
      osc.stop(0.95);
    });
    
    const rendered = await ctx.startRendering();
    const blob = audioBufferToWav(rendered);
    return { name: 'REX Airhorn Blast', blob, duration };
  }

  if (type === 'victory') {
    const duration = 2.4;
    const ctx = new OfflineAudioContext(1, sampleRate * duration, sampleRate);
    
    const notes = [
      { f: 523.25, time: 0, dur: 0.2 },      // C5
      { f: 659.25, time: 0.22, dur: 0.2 },   // E5
      { f: 783.99, time: 0.44, dur: 0.2 },   // G5
      { f: 1046.50, time: 0.68, dur: 1.5 },  // C6
    ];
    
    notes.forEach((n) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(n.f, n.time);
      
      gain.gain.setValueAtTime(0.0001, n.time);
      gain.gain.linearRampToValueAtTime(0.4, n.time + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, n.time + n.dur);
      
      osc.connect(gain).connect(ctx.destination);
      osc.start(n.time);
      osc.stop(n.time + n.dur);
    });
    
    const rendered = await ctx.startRendering();
    const blob = audioBufferToWav(rendered);
    return { name: 'REX Victory Fanfare', blob, duration };
  }

  if (type === 'cyber_alarm') {
    const duration = 1.6;
    const ctx = new OfflineAudioContext(1, sampleRate * duration, sampleRate);
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = 'sawtooth';
    // Modulate frequency
    for (let i = 0; i < 4; i++) {
      const t = i * 0.38;
      osc.frequency.setValueAtTime(880, t);
      osc.frequency.linearRampToValueAtTime(440, t + 0.35);
    }
    
    gain.gain.setValueAtTime(0.35, 0);
    gain.gain.setValueAtTime(0.35, 1.4);
    gain.gain.exponentialRampToValueAtTime(0.001, 1.55);
    
    osc.connect(gain).connect(ctx.destination);
    osc.start(0);
    osc.stop(duration);
    
    const rendered = await ctx.startRendering();
    const blob = audioBufferToWav(rendered);
    return { name: 'REX Cyber Alarm', blob, duration };
  }

  // Laser
  const duration = 0.8;
  const ctx = new OfflineAudioContext(1, sampleRate * duration, sampleRate);
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  
  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(1800, 0);
  osc.frequency.exponentialRampToValueAtTime(120, 0.4);
  
  gain.gain.setValueAtTime(0.5, 0);
  gain.gain.exponentialRampToValueAtTime(0.001, 0.7);
  
  osc.connect(gain).connect(ctx.destination);
  osc.start(0);
  osc.stop(duration);
  
  const rendered = await ctx.startRendering();
  const blob = audioBufferToWav(rendered);
  return { name: 'REX Laser Shot', blob, duration };
}
