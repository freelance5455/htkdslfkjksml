import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { Department, ShiftType } from '../types/attendance';
import {
  computeDepartmentSummary,
  formatDisplayDate,
  formatShiftLabel,
  getRecordForDate,
  slugifyFilename,
} from './attendanceLogic';

export function buildAttendancePdfDocument(
  department: Department,
  date: string,
  shift: ShiftType = 'day',
): {
  doc: jsPDF;
  filename: string;
} {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4',
  });

  const record = getRecordForDate(department, date, shift);
  const summary = computeDepartmentSummary(department, date, shift);
  const shiftLabel = formatShiftLabel(shift);
  const filename = `${slugifyFilename(department.name)}-${shift}-shift-attendance-${date}.pdf`;

  const marginLeft = 40;
  let cursorY = 48;

  // Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(15, 23, 42);
  doc.text('Daily Attendance Register', marginLeft, cursorY);

  cursorY += 22;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10.5);
  doc.setTextColor(71, 85, 105);
  doc.text(
    `Department: ${department.name}   |   Supervisor: ${department.supervisor}`,
    marginLeft,
    cursorY,
  );

  cursorY += 16;
  doc.text(
    `Date: ${formatDisplayDate(date)} (${date})   |   ${shiftLabel}   |   Status: ${summary.submitted ? 'Submitted' : 'Draft'}`,
    marginLeft,
    cursorY,
  );

  cursorY += 18;

  // Summary Table
  autoTable(doc, {
    startY: cursorY,
    margin: { left: marginLeft, right: marginLeft },
    head: [['Total Workers', 'Present (P)', 'Absent (Ab)', 'Unmarked']],
    body: [[String(summary.total), String(summary.present), String(summary.absent), String(summary.unmarked)]],
    theme: 'grid',
    headStyles: {
      fillColor: [241, 245, 249],
      textColor: [51, 65, 85],
      fontStyle: 'bold',
      fontSize: 9.5,
      halign: 'center',
    },
    bodyStyles: {
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      fontSize: 12,
      halign: 'center',
      cellPadding: 8,
    },
    didParseCell(data) {
      if (data.section === 'body') {
        if (data.column.index === 1) {
          data.cell.styles.textColor = [5, 150, 105];
        } else if (data.column.index === 2) {
          data.cell.styles.textColor = [225, 29, 72];
        }
      }
    },
  });

  const lastY = (doc as jsPDF & { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY ?? cursorY + 60;

  // Worker Roster Table
  const tableRows = department.workers.map((worker) => {
    const mark = record.marks[worker.id];
    const statusLabel = mark === 'present' ? 'Present' : mark === 'absent' ? 'Absent' : 'Unmarked';
    return [worker.id, worker.name, worker.role, statusLabel];
  });

  autoTable(doc, {
    startY: lastY + 18,
    margin: { left: marginLeft, right: marginLeft },
    head: [['Worker ID', 'Full Name', 'Role / Designation', 'Status']],
    body: tableRows.length > 0 ? tableRows : [['—', 'No workers in department', '—', '—']],
    theme: 'striped',
    headStyles: {
      fillColor: [37, 99, 235],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 10,
    },
    bodyStyles: {
      textColor: [15, 23, 42],
      fontSize: 10,
      cellPadding: 7,
    },
    columnStyles: {
      0: { cellWidth: 85, font: 'courier' },
      3: { cellWidth: 80, halign: 'right', fontStyle: 'bold' },
    },
    didParseCell(data) {
      if (data.section === 'body' && data.column.index === 3) {
        const value = String(data.cell.raw ?? '');
        if (value === 'Present') {
          data.cell.styles.textColor = [5, 150, 105];
        } else if (value === 'Absent') {
          data.cell.styles.textColor = [225, 29, 72];
        } else {
          data.cell.styles.textColor = [100, 116, 139];
        }
      }
    },
  });

  return { doc, filename };
}

export function downloadAttendancePdf(
  department: Department,
  date: string,
  shift: ShiftType = 'day',
): void {
  const { doc, filename } = buildAttendancePdfDocument(department, date, shift);
  doc.save(filename);
}
