import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatDate,
  parseDate,
  calculateDayNumber,
  isActivityScheduledForDate,
  calculateDailyProgress,
  calculateDailyNutrition,
  calculateSleepDuration
} from './tracker';
import { Activity, DayRecord } from '../types';

test('formatDate and parseDate roundtrip accurately', () => {
  const date = new Date(2026, 9, 30); // 2026-10-30
  const formatted = formatDate(date);
  assert.equal(formatted, '2026-10-30');

  const parsed = parseDate('2026-10-30');
  assert.equal(parsed.getFullYear(), 2026);
  assert.equal(parsed.getMonth(), 9);
  assert.equal(parsed.getDate(), 30);
});

test('calculateDayNumber accurately computes 1 to 90 range', () => {
  // Day 1 on start date
  assert.equal(calculateDayNumber('2026-10-01', '2026-10-01'), 1);
  // Day 14
  assert.equal(calculateDayNumber('2026-10-01', '2026-10-14'), 14);
  // Clamped at 90
  assert.equal(calculateDayNumber('2026-01-01', '2026-12-31'), 90);
  // Clamped at 1 for dates prior to start
  assert.equal(calculateDayNumber('2026-10-10', '2026-10-01'), 1);
});

test('isActivityScheduledForDate respects daily and specific days', () => {
  const dailyAct: Activity = {
    id: 'a1',
    name: 'Sunscreen',
    category: 'skincare',
    scheduledTime: '08:00',
    scheduleType: 'daily',
    selectedDays: [],
    reminderEnabled: true,
  };
  assert.equal(isActivityScheduledForDate(dailyAct, '2026-10-30'), true);

  // Friday is day 5 (2026-10-30 is a Friday)
  const fridayAct: Activity = {
    id: 'a2',
    name: 'Hair Oil Treatment',
    category: 'grooming',
    scheduledTime: '20:00',
    scheduleType: 'custom_days',
    selectedDays: [5], // Friday only
    reminderEnabled: true,
  };
  assert.equal(isActivityScheduledForDate(fridayAct, '2026-10-30'), true); // Friday
  assert.equal(isActivityScheduledForDate(fridayAct, '2026-10-31'), false); // Saturday
});

test('calculateDailyProgress computes correct counts and percentage', () => {
  const activities: Activity[] = [
    { id: '1', name: 'Face wash', category: 'skincare', scheduledTime: '08:00', scheduleType: 'daily', selectedDays: [], reminderEnabled: true },
    { id: '2', name: 'Push-ups', category: 'workout', scheduledTime: '16:00', scheduleType: 'daily', selectedDays: [], reminderEnabled: true },
    { id: '3', name: 'Dinner', category: 'nutrition', scheduledTime: '19:00', scheduleType: 'daily', selectedDays: [], reminderEnabled: true },
    { id: '4', name: 'Sleep', category: 'sleep', scheduledTime: '23:00', scheduleType: 'daily', selectedDays: [], reminderEnabled: true },
  ];

  const dayRecord: DayRecord = {
    date: '2026-10-30',
    tasks: {
      '1': { activityId: '1', completed: true },
      '2': { activityId: '2', completed: true },
      '3': { activityId: '3', completed: false },
    },
    waterConsumedMl: 1500,
    waterGoalMl: 3000,
  };

  const progress = calculateDailyProgress(activities, dayRecord, '2026-10-30');
  assert.equal(progress.total, 4);
  assert.equal(progress.completed, 2);
  assert.equal(progress.percentage, 50);
  assert.equal(progress.remaining, 2);
});

test('calculateDailyNutrition tallies completed meal calories and protein', () => {
  const activities: Activity[] = [
    {
      id: 'm1',
      name: 'High Protein Breakfast',
      category: 'nutrition',
      mealType: 'breakfast',
      calories: 550,
      protein: 42,
      scheduledTime: '08:00',
      scheduleType: 'daily',
      selectedDays: [],
      reminderEnabled: true,
    },
    {
      id: 'm2',
      name: 'Chicken Rice Lunch',
      category: 'nutrition',
      mealType: 'lunch',
      calories: 700,
      protein: 50,
      scheduledTime: '13:00',
      scheduleType: 'daily',
      selectedDays: [],
      reminderEnabled: true,
    },
    {
      id: 'm3',
      name: 'Evening Snack',
      category: 'nutrition',
      mealType: 'evening_snack',
      calories: 250,
      protein: 20,
      scheduledTime: '17:00',
      scheduleType: 'daily',
      selectedDays: [],
      reminderEnabled: true,
    },
  ];

  const dayRecord: DayRecord = {
    date: '2026-10-30',
    tasks: {
      'm1': { activityId: 'm1', completed: true },
      'm2': { activityId: 'm2', completed: true },
      'm3': { activityId: 'm3', completed: false }, // Not eaten yet
    },
    waterConsumedMl: 1000,
    waterGoalMl: 3000,
  };

  const totals = calculateDailyNutrition(activities, dayRecord, '2026-10-30');
  assert.equal(totals.calories, 1250);
  assert.equal(totals.protein, 92);
});

test('calculateSleepDuration handles same-day and midnight crossings', () => {
  // 23:00 to 07:00 next day = 8 hours = 480 minutes
  assert.equal(calculateSleepDuration('23:00', '07:00'), 480);
  // 22:30 to 06:45 = 8h 15m = 495 minutes
  assert.equal(calculateSleepDuration('22:30', '06:45'), 495);
});
