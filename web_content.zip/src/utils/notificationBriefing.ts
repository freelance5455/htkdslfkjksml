import { CapturedNotification, JarvisSettings, CalendarEvent } from '../types';

export interface NotificationGroupSummary {
  app: string;
  count: number;
  label: string;
  items: CapturedNotification[];
}

export interface BriefingReport {
  isAccessGranted: boolean;
  isCalendarGranted: boolean;
  totalFilteredCount: number;
  groups: NotificationGroupSummary[];
  calendarEventsIncluded: CalendarEvent[];
  speechScript: string;
  displayPreview: string;
  ignoredCount: number;
}

/**
 * Filter out unallowed apps, noise, and duplicates.
 */
export function filterAndDeduplicateNotifications(
  rawList: CapturedNotification[],
  settings: JarvisSettings,
  filterSinceLastBriefing = false
): { allowed: CapturedNotification[]; ignored: CapturedNotification[] } {
  if (!settings.isNotificationAccessGranted) {
    return { allowed: [], ignored: rawList };
  }

  const seenKeys = new Set<string>();
  const allowed: CapturedNotification[] = [];
  const ignored: CapturedNotification[] = [];

  const minTimestamp = filterSinceLastBriefing && settings.lastBriefingCompletedTimestamp
    ? settings.lastBriefingCompletedTimestamp
    : 0;

  for (const item of rawList) {
    // 1. Check if received since last briefing
    if (filterSinceLastBriefing && item.timestamp <= minTimestamp) {
      ignored.push(item);
      continue;
    }

    // 2. App allowed check
    const isAppAllowed = settings.allowedApps.some(
      a => a.toLowerCase() === item.app.toLowerCase()
    );

    if (!isAppAllowed) {
      ignored.push(item);
      continue;
    }

    // 3. Filter important only: Ignore low priority or ongoing system syncs
    if (settings.filterImportantOnly) {
      if (item.importance === 'low' || item.isOngoing || item.category === 'System') {
        ignored.push(item);
        continue;
      }
    }

    // 4. Deduplication check (app + title + text)
    const dedupKey = `${item.app.trim().toLowerCase()}|${item.title.trim().toLowerCase()}|${item.text.trim().toLowerCase()}`;
    if (seenKeys.has(dedupKey)) {
      ignored.push(item);
      continue;
    }
    seenKeys.add(dedupKey);

    allowed.push(item);
  }

  return { allowed, ignored };
}

/**
 * Groups notifications by app name and creates natural phrase labels.
 */
export function groupNotifications(items: CapturedNotification[]): NotificationGroupSummary[] {
  const map = new Map<string, CapturedNotification[]>();

  for (const item of items) {
    const list = map.get(item.app) || [];
    list.push(item);
    map.set(item.app, list);
  }

  const summaries: NotificationGroupSummary[] = [];

  map.forEach((notifs, app) => {
    const count = notifs.length;
    let label = `${count} ${count === 1 ? 'notification' : 'notifications'}`;

    const appLower = app.toLowerCase();
    if (appLower.includes('whatsapp') || appLower.includes('message') || appLower.includes('slack')) {
      label = `${count} ${count === 1 ? 'message' : 'messages'}`;
    } else if (appLower.includes('gmail') || appLower.includes('email') || appLower.includes('mail')) {
      label = `${count} ${count === 1 ? 'new email' : 'new emails'}`;
    } else if (appLower.includes('calendar')) {
      label = `${count} ${count === 1 ? 'upcoming event' : 'upcoming events'}`;
    } else if (appLower.includes('youtube')) {
      label = `${count} ${count === 1 ? 'notification' : 'notifications'}`;
    }

    summaries.push({
      app,
      count,
      label,
      items: notifs,
    });
  });

  return summaries;
}

/**
 * Synthesizes the natural-language morning briefing script.
 * Includes:
 * - Greeting
 * - Important notifications grouped by app
 * - Important upcoming calendar events if calendar permission is granted
 * - Zero invented info when data is missing
 * - Concludes with ready-for-questions prompt
 */
export function generateNotificationBriefing(
  rawList: CapturedNotification[],
  settings: JarvisSettings,
  isScheduledSession = false
): BriefingReport {
  // Check if we should filter by last briefing timestamp
  let { allowed, ignored } = filterAndDeduplicateNotifications(
    rawList,
    settings,
    isScheduledSession && settings.lastBriefingCompletedTimestamp !== null
  );

  // If running a manual test or scheduled briefing with 0 unbriefed items, fallback to current allowed batch
  if (allowed.length === 0 && rawList.length > 0 && settings.isNotificationAccessGranted) {
    const fallback = filterAndDeduplicateNotifications(rawList, settings, false);
    if (fallback.allowed.length > 0) {
      allowed = fallback.allowed;
      ignored = fallback.ignored;
    }
  }

  const groups = groupNotifications(allowed);
  const totalNotifCount = allowed.length;

  // Calendar integration: only include if permission is explicitly granted and events exist
  const calendarEventsIncluded: CalendarEvent[] =
    settings.isCalendarPermissionGranted && settings.calendarEvents
      ? settings.calendarEvents.filter(e => e.isImportant)
      : [];

  // Seed variation based on current day and hour to ensure natural, dynamic variety
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24)
  );
  const variantIndex = (dayOfYear + new Date().getHours() + Math.floor(Math.random() * 3)) % 4;

  let greetingPrefix = '';
  let notificationSection = '';

  if (!settings.isNotificationAccessGranted) {
    greetingPrefix = 'Good morning sir.';
    notificationSection =
      'Notification Access is currently disabled in Android Settings. I am unable to read your alerts until access is authorized in device settings.';
  } else if (totalNotifCount === 0) {
    const noNotifGreetings = [
      'Good morning sir. You have no important notifications at the moment.',
      'Hello sir. Good morning. You have no important notifications right now.',
      'Good morning sir. Your notification feeds are clear with zero unread alerts.',
      'Good morning sir. All incoming feeds are quiet with no priority items pending.',
    ];
    greetingPrefix = noNotifGreetings[variantIndex % noNotifGreetings.length];
    notificationSection = '';
  } else {
    const activeGreetings = [
      "Hello sir. Good morning. Today's important notifications are: ",
      "Good morning, sir. Starting your morning summary. Today's important notifications are: ",
      "Hello sir. Good morning. Here is your priority update. Today's important notifications are: ",
      "Good morning, sir. Telemetry is nominal. Today's important notifications are: ",
    ];
    greetingPrefix = activeGreetings[variantIndex % activeGreetings.length];
    const appLines = groups.map(g => `${g.app}: ${g.label}.`).join(' ');
    notificationSection = appLines;
  }

  // Calendar section - only populated if permission is granted and events exist (do not invent data)
  let calendarSection = '';
  if (settings.isCalendarPermissionGranted) {
    if (calendarEventsIncluded.length > 0) {
      const eventDetails = calendarEventsIncluded
        .map(e => `${e.title} at ${e.time}`)
        .join(', and ');
      calendarSection = `On your calendar today: ${eventDetails}.`;
    } else if (totalNotifCount > 0) {
      calendarSection = 'Your calendar has no scheduled events today.';
    }
  }

  // Natural closing prompt
  const closingPrompts = [
    "I'm ready, sir. What can I help you with?",
    "I am ready, sir. What can I help you with?",
    "I'm standing by, sir. What can I help you with?",
    "All systems are standing by, sir. What can I help you with?",
  ];
  const promptReady = closingPrompts[variantIndex % closingPrompts.length];

  // Build spoken and preview text
  const speechParts = [greetingPrefix, notificationSection, calendarSection, promptReady].filter(Boolean);
  const speechScript = speechParts.join(' ');

  const previewLines: string[] = [greetingPrefix];
  if (notificationSection) {
    previewLines.push(notificationSection);
  }
  if (calendarSection) {
    previewLines.push(`• ${calendarSection}`);
  }
  previewLines.push(`\n${promptReady}`);
  const displayPreview = previewLines.join('\n');

  return {
    isAccessGranted: settings.isNotificationAccessGranted,
    isCalendarGranted: settings.isCalendarPermissionGranted,
    totalFilteredCount: totalNotifCount,
    groups,
    calendarEventsIncluded,
    speechScript,
    displayPreview,
    ignoredCount: ignored.length,
  };
}

/**
 * Handle follow-up questions about notifications or calendar naturally.
 */
export function answerNotificationQuery(
  query: string,
  notifications: CapturedNotification[],
  settings?: JarvisSettings
): string | null {
  const q = query.toLowerCase();

  // 1. Questions about WhatsApp or messaging
  if (q.includes('whatsapp') || q.includes('message') || q.includes('chat') || q.includes('text')) {
    const whatsAppItems = notifications.filter(
      n => n.app.toLowerCase().includes('whatsapp') || n.category === 'Messaging'
    );
    if (whatsAppItems.length > 0) {
      const details = whatsAppItems
        .map((n, i) => `${i + 1}. From ${n.title}: "${n.text}" (${n.timeReceived})`)
        .join('. ');
      return `Here are your messages: ${details}. Would you like me to take any action?`;
    }
    return 'You have no unread WhatsApp messages.';
  }

  // 2. Questions about Gmail or emails
  if (q.includes('gmail') || q.includes('email') || q.includes('mail')) {
    const gmailItems = notifications.filter(
      n => n.app.toLowerCase().includes('gmail') || n.category === 'Email'
    );
    if (gmailItems.length > 0) {
      const details = gmailItems
        .map(n => `From ${n.title}: "${n.text}" received at ${n.timeReceived}`)
        .join('. ');
      return `Regarding your emails: ${details}.`;
    }
    return 'You have no new VIP emails.';
  }

  // 3. Questions about Calendar or schedule
  if (q.includes('calendar') || q.includes('event') || q.includes('meeting') || q.includes('schedule')) {
    if (settings && !settings.isCalendarPermissionGranted) {
      return 'Calendar access has not been granted. You can enable Calendar permission in the JARVIS Settings screen.';
    }

    if (settings && settings.calendarEvents && settings.calendarEvents.length > 0) {
      const events = settings.calendarEvents
        .map(e => `${e.title} at ${e.time}${e.location ? ` (${e.location})` : ''}`)
        .join('. ');
      return `Here is your schedule for today: ${events}.`;
    }

    const calNotifs = notifications.filter(
      n => n.app.toLowerCase().includes('calendar') || n.category === 'Calendar'
    );
    if (calNotifs.length > 0) {
      const details = calNotifs.map(n => `${n.title}: "${n.text}"`).join('. ');
      return `On your calendar: ${details}.`;
    }
    return 'You have no upcoming events on your schedule today.';
  }

  // 4. Questions about YouTube or videos
  if (q.includes('youtube') || q.includes('video')) {
    const ytItems = notifications.filter(
      n => n.app.toLowerCase().includes('youtube') || n.category === 'Video'
    );
    if (ytItems.length > 0) {
      const details = ytItems.map(n => `${n.title} - ${n.text}`).join('. ');
      return `YouTube update: ${details}.`;
    }
  }

  // 5. General inquiry about notifications or summary
  if (q.includes('what are the notifications') || q.includes('tell me more') || q.includes('all alerts')) {
    if (notifications.length === 0) {
      return 'There are no active notifications to report.';
    }
    const allText = notifications
      .slice(0, 4)
      .map(n => `${n.app}: ${n.title} - "${n.text}"`)
      .join('. ');
    return `Here are the top alerts: ${allText}.`;
  }

  return null;
}

/**
 * Dynamic incoming call greeting when user answers a normal (non-briefing) call
 */
export function generateNormalIncomingGreeting(settings: JarvisSettings): string {
  const greetings = [
    'Hello sir. What can I help you with?',
    'Good day, sir. Systems are online. What can I help you with?',
    `Hello ${settings.userName || 'sir'}. Voice connection established. How can I assist you?`,
    'Greetings, sir. JARVIS is at your service. What can I help you with?',
    'Online and standing by, sir. What can I do for you today?',
  ];
  const idx = Math.floor(Math.random() * greetings.length);
  return greetings[idx];
}

