import { VideoProject } from '../types/project';

const STORAGE_KEY = 'designo_projects_v1';
const CURRENT_PROJECT_KEY = 'designo_active_project_id';

export function getSavedProjects(): VideoProject[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load projects from storage', e);
    return [];
  }
}

export function saveProject(project: VideoProject): void {
  try {
    const list = getSavedProjects();
    const idx = list.findIndex((p) => p.id === project.id);
    const updated = { ...project, updatedAt: Date.now() };

    if (idx >= 0) {
      list[idx] = updated;
    } else {
      list.unshift(updated);
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
    localStorage.setItem(CURRENT_PROJECT_KEY, project.id);
  } catch (e) {
    console.error('Failed to save project', e);
  }
}

export function deleteProject(id: string): void {
  try {
    const list = getSavedProjects().filter((p) => p.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch (e) {
    console.error('Failed to delete project', e);
  }
}

export function duplicateProject(id: string): VideoProject | null {
  const list = getSavedProjects();
  const source = list.find((p) => p.id === id);
  if (!source) return null;

  const copy: VideoProject = {
    ...source,
    id: 'proj_' + Math.random().toString(36).substring(2, 9),
    name: `${source.name} (نسخة)`,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };

  saveProject(copy);
  return copy;
}

export function createDefaultProject(): VideoProject {
  return {
    id: 'proj_' + Math.random().toString(36).substring(2, 9),
    name: 'مشروع مونتاج جديد',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    videoUrl: '',
    videoFileName: '',
    duration: 65,
    width: 1280,
    height: 720,
    aspectRatio: '9:16',
    blurBackground: true,
    filter: 'normal',
    brightness: 1,
    contrast: 1,
    saturation: 1,
    speed: 1,
    volume: 1,
    isMuted: false,
    watermarkText: 'Designo',
    textOverlays: [
      {
        id: 'title_1',
        text: 'اصنع فيديوك بطريقتك 🚀',
        position: 'top',
        fontSize: 32,
        color: '#ffffff',
        bgColor: 'rgba(124, 58, 237, 0.85)',
        hasBackground: true
      }
    ],
    templateId: 'tiktok-9-16',
    splitSettings: {
      mode: 'duration',
      value: 40
    }
  };
}
