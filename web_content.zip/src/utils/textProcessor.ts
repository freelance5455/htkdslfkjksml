import { PronunciationRule, SentenceItem, TextProcessingSettings } from '../types/tts';
import { replaceNumbersInTeluguText } from './numberToTelugu';
import { applyPronunciationRules } from './pronunciation';

/**
 * Splits Telugu text into discrete sentences honoring standard and Indic punctuation
 */
export function splitIntoTeluguSentences(text: string): SentenceItem[] {
  if (!text || !text.trim()) return [];

  // Match endings: . ! ? । ॥ or newlines
  const rawSentences = text
    .split(/(?<=[.!?।॥\n])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  return rawSentences.map((s, idx) => ({
    id: `sentence-${idx + 1}-${Date.now().toString(36)}`,
    text: s,
    pauseAfter: 0.4,
    emphasis: 'normal',
  }));
}

/**
 * Normalizes punctuation and special characters for natural speech synthesis
 */
export function normalizeTeluguPunctuation(text: string): string {
  let res = text;
  // Replace multiple punctuation marks with a single clean one
  res = res.replace(/[.]{2,}/g, '...');
  res = res.replace(/[!]{2,}/g, '!');
  res = res.replace(/[?]{2,}/g, '?');

  // Replace curly quotes
  res = res.replace(/[“”]/g, '"').replace(/[‘’]/g, "'");

  // Replace long dashes with commas for natural speech pauses
  res = res.replace(/\s*[-—–]\s*/g, ', ');

  // Normalize spaces around punctuation
  res = res.replace(/\s+([,.!?:;।॥])/g, '$1');

  return res;
}

/**
 * Processes raw Telugu text according to active settings and dictionary
 */
export function processTeluguText(
  rawText: string,
  settings: TextProcessingSettings,
  pronunciationRules?: PronunciationRule[]
): string {
  if (!rawText) return '';
  let processed = rawText;

  // 1. Pronunciation / custom dictionary replacements
  if (pronunciationRules && pronunciationRules.length > 0) {
    processed = applyPronunciationRules(processed, pronunciationRules);
  }

  // 2. Number & currency normalization
  if (settings.numberPronunciation || settings.currencyPronunciation) {
    processed = replaceNumbersInTeluguText(processed);
  }

  // 3. Punctuation normalization
  if (settings.autoPunctuation) {
    processed = normalizeTeluguPunctuation(processed);
  }

  return processed.trim();
}

/**
 * Counts Telugu words and characters accurately
 */
export function getTeluguTextStats(text: string) {
  if (!text) {
    return { chars: 0, words: 0, sentences: 0 };
  }
  const clean = text.trim();
  const chars = clean.length;
  const words = clean ? clean.split(/\s+/).filter(Boolean).length : 0;
  const sentences = clean ? clean.split(/[.!?।॥\n]+/).filter((s) => s.trim().length > 0).length : 0;
  return { chars, words, sentences };
}
