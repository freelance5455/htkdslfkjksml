import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateDevisTotals, generateDevisNumber } from './devis';
import { DevisItem } from '../types';

test('calculateDevisTotals computes subtotal, agency fee and VAT correctly', () => {
  const items: DevisItem[] = [
    { id: '1', description: 'Flight ALG-IST', category: 'flight', unitPriceDZD: 65000, quantity: 2 },
    { id: '2', description: 'Hotel 5 Stars (7 nights)', category: 'hotel', unitPriceDZD: 14000, quantity: 7 },
  ];
  // Subtotal = 130000 + 98000 = 228000 DZD
  // Agency Fee = 12000 DZD
  // Taxable Base = 240000 DZD
  // 9% VAT = 21600 DZD
  // Total = 261600 DZD
  const result = calculateDevisTotals(items, 12000, 9);

  assert.equal(result.subtotalDZD, 228000);
  assert.equal(result.agencyFeeDZD, 12000);
  assert.equal(result.taxAmountDZD, 21600);
  assert.equal(result.totalDZD, 261600);
});

test('generateDevisNumber formats correctly', () => {
  assert.equal(generateDevisNumber(42, 2026), 'DEV-2026-0042');
  assert.equal(generateDevisNumber(1, 2026), 'DEV-2026-0001');
});
