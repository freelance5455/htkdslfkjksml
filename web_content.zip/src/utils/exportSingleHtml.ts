/**
 * Generates a standalone single-file HTML version containing HTML, CSS, and JS
 * matching the user's explicit request:
 * "التطبيق بملف واحد html لاتستخدم اي لغه اخرى غير لغه الويب الثلاث html css js"
 */
export function generateStandaloneSingleHtml(): string {
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>أداة دمج ملفات PDF للهواتف (ملف مستقل)</title>
  <script src="https://cdn.jsdelivr.net/npm/pdf-lib@1.17.9/dist/pdf-lib.min.js"><\/script>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Cairo', system-ui, sans-serif; }
    body { background: #f8fafc; color: #0f172a; padding: 16px; min-height: 100vh; display: flex; flex-direction: column; align-items: center; }
    .app-container { width: 100%; max-width: 440px; margin: 0 auto; display: flex; flex-direction: column; gap: 16px; padding-bottom: 90px; }
    .header { background: #ffffff; padding: 16px; border-radius: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); text-align: center; border: 1px solid #e2e8f0; }
    .header h1 { font-size: 1.25rem; font-weight: 800; color: #1e293b; margin-bottom: 4px; }
    .header p { font-size: 0.85rem; color: #64748b; }
    .upload-box { background: #ffffff; border: 2px dashed #cbd5e1; border-radius: 16px; padding: 24px 16px; text-align: center; cursor: pointer; transition: all 0.2s; }
    .upload-box:active { background: #f1f5f9; border-color: #6366f1; }
    .upload-btn { display: inline-block; background: #4f46e5; color: white; padding: 10px 20px; border-radius: 12px; font-weight: 600; font-size: 0.95rem; margin-top: 10px; cursor: pointer; }
    .files-header { display: flex; justify-content: space-between; align-items: center; font-size: 0.9rem; font-weight: 700; color: #334155; }
    .file-list { display: flex; flex-direction: column; gap: 10px; }
    .file-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 12px; display: flex; align-items: center; gap: 10px; box-shadow: 0 1px 2px rgba(0,0,0,0.03); }
    .file-badge { background: #f1f5f9; color: #475569; font-size: 0.8rem; font-weight: 700; width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; shrink: 0; }
    .file-info { flex: 1; min-width: 0; }
    .file-name { font-size: 0.88rem; font-weight: 600; color: #1e293b; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .file-meta { font-size: 0.75rem; color: #64748b; }
    .btn-group { display: flex; gap: 4px; }
    .action-btn { background: #f8fafc; border: 1px solid #cbd5e1; width: 34px; height: 34px; border-radius: 8px; display: flex; align-items: center; justify-content: center; cursor: pointer; font-weight: bold; font-size: 1rem; color: #334155; }
    .action-btn:active { background: #e2e8f0; }
    .btn-del { color: #ef4444; border-color: #fecaca; }
    .rename-box { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 16px; padding: 16px; display: flex; flex-direction: column; gap: 8px; }
    .rename-box label { font-size: 0.85rem; font-weight: 700; color: #334155; }
    .input-wrapper { display: flex; direction: ltr; border: 1px solid #cbd5e1; border-radius: 10px; overflow: hidden; }
    .input-wrapper input { flex: 1; padding: 10px 12px; border: none; outline: none; font-size: 0.95rem; text-align: left; }
    .input-suffix { background: #f1f5f9; padding: 10px 12px; font-size: 0.9rem; color: #64748b; font-weight: 600; border-left: 1px solid #cbd5e1; }
    .bottom-bar { position: fixed; bottom: 0; left: 0; right: 0; background: rgba(255,255,255,0.95); backdrop-filter: blur(8px); border-top: 1px solid #e2e8f0; padding: 12px 16px; display: flex; justify-content: center; z-index: 50; }
    .merge-btn { width: 100%; max-width: 440px; background: #4f46e5; color: white; border: none; padding: 14px; border-radius: 14px; font-size: 1rem; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(79,70,229,0.25); }
    .merge-btn:disabled { background: #94a3b8; cursor: not-allowed; box-shadow: none; }
    .alert-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; padding: 14px; border-radius: 14px; text-align: center; }
  </style>
</head>
<body>
  <div class="app-container">
    <div class="header">
      <h1>📄 دمج ملفات PDF للهواتف</h1>
      <p>رتّب الملفات، أعد التسمية، ثم ادمج بضغطة واحدة</p>
    </div>

    <div class="upload-box" onclick="document.getElementById('fileInput').click()">
      <div style="font-size: 2rem; margin-bottom: 6px;">📥</div>
      <div style="font-weight: 700; font-size: 0.95rem;">اختر ملفات PDF من هاتفك</div>
      <div style="font-size: 0.8rem; color: #64748b; margin-top: 4px;">يمكنك اختيار عدة ملفات دفعة واحدة</div>
      <div class="upload-btn">تصفح الملفات</div>
      <input type="file" id="fileInput" multiple accept="application/pdf" style="display:none" onchange="handleFiles(this.files)">
    </div>

    <div id="controlsSection" style="display:none;">
      <div class="files-header">
        <span id="filesCountLabel">الملفات المحددة</span>
        <div style="display:flex; gap:6px;">
          <button onclick="reverseOrder()" style="font-size:0.75rem; background:#fff; border:1px solid #cbd5e1; padding:4px 8px; border-radius:6px; cursor:pointer;">عكس الترتيب</button>
          <button onclick="clearFiles()" style="font-size:0.75rem; background:#fee2e2; border:1px solid #fca5a5; color:#b91c1c; padding:4px 8px; border-radius:6px; cursor:pointer;">مسح الكل</button>
        </div>
      </div>

      <div class="file-list" id="fileList"></div>

      <div class="rename-box">
        <label>اسم الملف المدمج الناتج:</label>
        <div class="input-wrapper">
          <input type="text" id="outputName" value="Merged_Document" placeholder="اسم الملف">
          <div class="input-suffix">.pdf</div>
        </div>
      </div>

      <div id="resultBox" style="display:none;" class="alert-success">
        <div style="font-weight:700; margin-bottom:6px;">✅ تم دمج الملفات بنجاح!</div>
        <a id="downloadLink" href="#" download="" style="display:inline-block; background:#059669; color:#fff; text-decoration:none; padding:10px 18px; border-radius:10px; font-weight:700; font-size:0.9rem; margin-top:6px;">تحميل الملف الآن</a>
      </div>
    </div>
  </div>

  <div class="bottom-bar" id="bottomBar" style="display:none;">
    <button class="merge-btn" id="mergeBtn" onclick="mergeFiles()">⚡ دمج وتحميل الملف الآن</button>
  </div>

  <script>
    let filesState = [];

    async function handleFiles(files) {
      if (!files || files.length === 0) return;
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        filesState.push({ id: Math.random().toString(36).substr(2, 9), file: f, name: f.name, size: f.size });
      }
      render();
    }

    function moveUp(index) {
      if (index === 0) return;
      const tmp = filesState[index];
      filesState[index] = filesState[index - 1];
      filesState[index - 1] = tmp;
      render();
    }

    function moveDown(index) {
      if (index === filesState.length - 1) return;
      const tmp = filesState[index];
      filesState[index] = filesState[index + 1];
      filesState[index + 1] = tmp;
      render();
    }

    function removeFile(index) {
      filesState.splice(index, 1);
      render();
    }

    function reverseOrder() {
      filesState.reverse();
      render();
    }

    function clearFiles() {
      filesState = [];
      render();
    }

    function formatSize(bytes) {
      if (bytes < 1024) return bytes + ' B';
      if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
      return (bytes / 1048576).toFixed(1) + ' MB';
    }

    function render() {
      const controls = document.getElementById('controlsSection');
      const bottomBar = document.getElementById('bottomBar');
      const list = document.getElementById('fileList');
      const countLabel = document.getElementById('filesCountLabel');

      if (filesState.length === 0) {
        controls.style.display = 'none';
        bottomBar.style.display = 'none';
        return;
      }

      controls.style.display = 'flex';
      controls.style.flexDirection = 'column';
      controls.style.gap = '14px';
      bottomBar.style.display = 'flex';
      countLabel.textContent = 'الملفات (' + filesState.length + ') - انقر الأسهم لتغيير التسلسل';

      list.innerHTML = '';
      filesState.forEach((item, idx) => {
        const card = document.createElement('div');
        card.className = 'file-card';
        card.innerHTML = \`
          <div class="file-badge">#\${idx + 1}</div>
          <div class="file-info">
            <div class="file-name" title="\${item.name}">\${item.name}</div>
            <div class="file-meta">\${formatSize(item.size)}</div>
          </div>
          <div class="btn-group">
            <button class="action-btn" onclick="moveUp(\${idx})" \${idx === 0 ? 'disabled style="opacity:0.3"' : ''} title="تحريك لأعلى">▲</button>
            <button class="action-btn" onclick="moveDown(\${idx})" \${idx === filesState.length - 1 ? 'disabled style="opacity:0.3"' : ''} title="تحريك لأسفل">▼</button>
            <button class="action-btn btn-del" onclick="removeFile(\${idx})" title="حذف">✕</button>
          </div>
        \`;
        list.appendChild(card);
      });
    }

    async function mergeFiles() {
      if (filesState.length === 0) return;
      const btn = document.getElementById('mergeBtn');
      btn.disabled = true;
      btn.textContent = '⏳ جاري دمج الصفحات...';

      try {
        const { PDFDocument } = PDFLib;
        const mergedPdf = await PDFDocument.create();

        for (let i = 0; i < filesState.length; i++) {
          const buffer = await filesState[i].file.arrayBuffer();
          const pdf = await PDFDocument.load(buffer, { ignoreEncryption: true });
          const pages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
          pages.forEach(p => mergedPdf.addPage(p));
        }

        const mergedBytes = await mergedPdf.save();
        const blob = new Blob([mergedBytes], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);

        let finalName = document.getElementById('outputName').value.trim() || 'Merged_Document';
        if (!finalName.endsWith('.pdf')) finalName += '.pdf';

        const downloadLink = document.getElementById('downloadLink');
        downloadLink.href = url;
        downloadLink.download = finalName;

        document.getElementById('resultBox').style.display = 'block';

        // Auto trigger download
        const a = document.createElement('a');
        a.href = url;
        a.download = finalName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        btn.disabled = false;
        btn.textContent = '⚡ دمج وتحميل الملف الآن';
      } catch (err) {
        alert('حدث خطأ أثناء الدمج: ' + err.message);
        btn.disabled = false;
        btn.textContent = '⚡ دمج وتحميل الملف الآن';
      }
    }
  <\/script>
</body>
</html>`;
}
