import JSZip from 'jszip';
import { Project } from '../types';

export async function exportProjectAsZip(project: Project): Promise<void> {
  const zip = new JSZip();

  // Add files to zip
  project.files.forEach(file => {
    // Strip leading slashes
    const cleanPath = file.path.startsWith('/') ? file.path.slice(1) : file.path;
    zip.file(cleanPath, file.content);
  });

  // Add a README.md if not present
  if (!project.files.some(f => f.name.toLowerCase().startsWith('readme'))) {
    zip.file(
      'README.md',
      `# ${project.name}\n\n${project.description}\n\n*Generated with CODEVERSE: The All-in-One Coding Studio*\n\n## Running the Project\n- Open \`index.html\` in any modern web browser.\n`
    );
  }

  // Generate zip blob and trigger download
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${project.name.toLowerCase().replace(/[^a-z0-9_-]/g, '_')}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
