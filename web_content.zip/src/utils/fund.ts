import { FundData, HistoryEntry, PARTNER_NAMES, STORAGE_KEY, TAX_RATE } from '../types/fund';

export function createInitialFundData(): FundData {
  return {
    balances: [0, 0, 0],
    totalProfit: 0,
    totalTax: 0,
    history: [],
  };
}

export function loadFundData(): FundData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createInitialFundData();
    const parsed = JSON.parse(raw) as Partial<FundData>;
    const balances: [number, number, number] = [
      Number(parsed?.balances?.[0]) || 0,
      Number(parsed?.balances?.[1]) || 0,
      Number(parsed?.balances?.[2]) || 0,
    ];
    const history: HistoryEntry[] = Array.isArray(parsed?.history)
      ? parsed.history.map((item) => ({
          date: String(item?.date ?? ''),
          title: String(item?.title ?? ''),
          detail: String(item?.detail ?? ''),
          amount: Number(item?.amount) || 0,
        }))
      : [];
    return {
      balances,
      totalProfit: Number(parsed?.totalProfit) || 0,
      totalTax: Number(parsed?.totalTax) || 0,
      history,
    };
  } catch {
    return createInitialFundData();
  }
}

export function saveFundData(data: FundData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // Ignore storage quota errors in private browsing modes
  }
}

export function formatMoney(n: number): string {
  return (
    'Rs ' +
    Number(n || 0).toLocaleString('en-PK', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  );
}

export function calculateDistribution(amount: number): {
  totalAmount: number;
  shares: [number, number, number];
} {
  const cents = Math.round(amount * 100);
  const base = Math.floor(cents / PARTNER_NAMES.length);
  const rem = cents - base * PARTNER_NAMES.length;
  const shares: [number, number, number] = [
    (base + (0 < rem ? 1 : 0)) / 100,
    (base + (1 < rem ? 1 : 0)) / 100,
    (base + (2 < rem ? 1 : 0)) / 100,
  ];
  return {
    totalAmount: cents / 100,
    shares,
  };
}

export function calculateWithdrawalPreview(amount: number): {
  gross: number;
  tax: number;
  net: number;
} {
  const v = Math.max(0, Number.isFinite(amount) ? amount : 0);
  const tax = Math.round(v * TAX_RATE * 100) / 100;
  const net = Math.round((v - tax) * 100) / 100;
  return { gross: v, tax, net };
}

export function calculateWithdrawalSubmit(amount: number): {
  gross: number;
  tax: number;
  net: number;
} {
  const cents = Math.round(amount * 100);
  const gross = cents / 100;
  const taxCents = Math.round(cents * TAX_RATE);
  const tax = taxCents / 100;
  const net = (cents - taxCents) / 100;
  return { gross, tax, net };
}

export function exportHistoryCSV(history: HistoryEntry[]): void {
  const rows: Array<Array<string | number>> = [
    ['Date', 'Transaction', 'Details', 'Amount (PKR)'],
    ...history.map((x) => [x.date, x.title, x.detail, x.amount]),
  ];
  const csv =
    '\ufeff' +
    rows
      .map((r) => r.map((v) => '"' + String(v).replace(/"/g, '""') + '"').join(','))
      .join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'ubl-islamic-fund-history.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
