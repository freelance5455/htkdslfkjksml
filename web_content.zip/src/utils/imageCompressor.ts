/**
 * Lightweight Client-Side Image Resizer & Compressor for Profile Photos (DP), Site Photos, and Logos.
 * Ensures images are crisp, optimized thumbnails (< 50KB for logos/DP, < 150KB for site photos) that do not bloat storage or Firestore.
 */

export interface CompressionResult {
  dataUrl: string;
  width: number;
  height: number;
  sizeBytes: number;
  compressedSize: number;
}

export function validateImageFile(file: File, maxSizeBytes: number = 10 * 1024 * 1024): void {
  const validMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
  if (!validMimes.includes(file.type.toLowerCase())) {
    throw new Error('Unsupported image format. Please upload a JPG, PNG, or WebP picture.');
  }

  if (file.size > maxSizeBytes) {
    throw new Error(`Image is too large (${(file.size / (1024 * 1024)).toFixed(1)} MB). Maximum allowed size is ${(maxSizeBytes / (1024 * 1024)).toFixed(0)} MB.`);
  }
}

/**
 * Universal image compressor supporting custom maxWidth, maxHeight, and quality.
 */
export async function compressImage(
  file: File,
  options: { maxWidth?: number; maxHeight?: number; quality?: number } = {}
): Promise<CompressionResult> {
  validateImageFile(file);

  const maxWidth = options.maxWidth || 1024;
  const maxHeight = options.maxHeight || 1024;
  const quality = options.quality !== undefined ? options.quality : 0.8;

  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onerror = () => reject(new Error('Failed to read image file.'));

    reader.onload = (event) => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image data.'));

      img.onload = () => {
        try {
          let targetW = img.width;
          let targetH = img.height;

          // Scale down proportionally if larger than maximums
          if (targetW > maxWidth || targetH > maxHeight) {
            const ratio = Math.min(maxWidth / targetW, maxHeight / targetH);
            targetW = Math.round(targetW * ratio);
            targetH = Math.round(targetH * ratio);
          }

          const canvas = document.createElement('canvas');
          canvas.width = targetW;
          canvas.height = targetH;
          const ctx = canvas.getContext('2d');

          if (!ctx) {
            reject(new Error('Canvas context unavailable.'));
            return;
          }

          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.drawImage(img, 0, 0, targetW, targetH);

          const dataUrl = canvas.toDataURL('image/jpeg', quality);
          const sizeBytes = Math.round((dataUrl.length * 3) / 4);

          resolve({
            dataUrl,
            width: targetW,
            height: targetH,
            sizeBytes,
            compressedSize: sizeBytes,
          });
        } catch (e: any) {
          reject(e);
        }
      };

      img.src = event.target?.result as string;
    };

    reader.readAsDataURL(file);
  });
}

/**
 * Specifically crops and centers to a square for Profile Photos (DP).
 */
export async function compressAndCropProfileImage(
  file: File,
  targetSize: number = 256,
  quality: number = 0.82
): Promise<CompressionResult> {
  validateImageFile(file);

  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onerror = () => reject(new Error('Failed to read image file.'));

    reader.onload = (event) => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image data.'));

      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = targetSize;
          canvas.height = targetSize;
          const ctx = canvas.getContext('2d');

          if (!ctx) {
            reject(new Error('Canvas context unavailable.'));
            return;
          }

          // Center crop: find center square of the original image
          const minDim = Math.min(img.width, img.height);
          const startX = (img.width - minDim) / 2;
          const startY = (img.height - minDim) / 2;

          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';

          // Draw cropped & resized square image
          ctx.drawImage(
            img,
            startX,
            startY,
            minDim,
            minDim,
            0,
            0,
            targetSize,
            targetSize
          );

          // Export as JPEG with controlled quality
          const dataUrl = canvas.toDataURL('image/jpeg', quality);
          const sizeBytes = Math.round((dataUrl.length * 3) / 4);

          resolve({
            dataUrl,
            width: targetSize,
            height: targetSize,
            sizeBytes,
            compressedSize: sizeBytes,
          });
        } catch (e: any) {
          reject(e);
        }
      };

      img.src = event.target?.result as string;
    };

    reader.readAsDataURL(file);
  });
}
