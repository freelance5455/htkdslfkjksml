import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { PdfFileItem } from '../types';

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 بايت';
  const k = 1024;
  const sizes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

export async function getPdfPageCount(file: File): Promise<number> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
    return pdf.getPageCount();
  } catch (error) {
    console.error('Error reading PDF page count:', error);
    return 1; // fallback
  }
}

export async function mergePdfFiles(
  files: PdfFileItem[],
  onProgress?: (progress: number, statusText: string) => void
): Promise<{ blob: Blob; url: string; totalPages: number }> {
  if (files.length === 0) {
    throw new Error('لا توجد ملفات للدمج');
  }

  onProgress?.(5, 'بدء إنشاء مستند PDF المدمج...');
  const mergedPdf = await PDFDocument.create();

  const total = files.length;
  let processedPagesCount = 0;

  for (let i = 0; i < total; i++) {
    const item = files[i];
    const progressPercent = Math.round(10 + ((i + 1) / total) * 75);
    onProgress?.(progressPercent, `معالجة الملف ${i + 1} من ${total}: ${item.name}`);

    try {
      const arrayBuffer = await item.file.arrayBuffer();
      const pdf = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
      const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
      
      for (const page of copiedPages) {
        mergedPdf.addPage(page);
        processedPagesCount++;
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      throw new Error(`فشل دمج الملف "${item.name}": ${msg}`);
    }
  }

  onProgress?.(90, 'تجميع وحفظ صفحات المستند...');
  const mergedPdfBytes = await mergedPdf.save();
  
  onProgress?.(100, 'اكتمل الدمج بنجاح!');
  const blob = new Blob([mergedPdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);

  return {
    blob,
    url,
    totalPages: processedPagesCount,
  };
}

/**
 * Creates lightweight sample PDF files for instant interactive testing
 */
export async function createSamplePdf(
  title: string,
  pageColor: { r: number; g: number; b: number },
  pageCount: number = 2
): Promise<File> {
  const pdfDoc = await PDFDocument.create();
  const helveticaFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const helveticaRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);

  for (let p = 1; p <= pageCount; p++) {
    const page = pdfDoc.addPage([595.28, 841.89]); // A4
    const { width, height } = page.getSize();

    // Background header bar
    page.drawRectangle({
      x: 0,
      y: height - 120,
      width: width,
      height: 120,
      color: rgb(pageColor.r, pageColor.g, pageColor.b),
    });

    page.drawText(title, {
      x: 50,
      y: height - 70,
      size: 24,
      font: helveticaFont,
      color: rgb(1, 1, 1),
    });

    page.drawText(`Page ${p} of ${pageCount}`, {
      x: 50,
      y: height - 100,
      size: 14,
      font: helveticaRegular,
      color: rgb(0.9, 0.9, 0.9),
    });

    // Content body
    page.drawText(`Sample Document: ${title}`, {
      x: 50,
      y: height - 180,
      size: 18,
      font: helveticaFont,
      color: rgb(0.2, 0.2, 0.2),
    });

    page.drawText('This sample PDF was generated inside your browser for mobile testing.', {
      x: 50,
      y: height - 220,
      size: 13,
      font: helveticaRegular,
      color: rgb(0.4, 0.4, 0.4),
    });

    page.drawText('You can rearrange, rename, merge and download it seamlessly.', {
      x: 50,
      y: height - 250,
      size: 13,
      font: helveticaRegular,
      color: rgb(0.4, 0.4, 0.4),
    });

    // Footer
    page.drawLine({
      start: { x: 50, y: 70 },
      end: { x: width - 50, y: 70 },
      thickness: 1,
      color: rgb(0.85, 0.85, 0.85),
    });

    page.drawText(`Mobile PDF Merger - Generated for testing`, {
      x: 50,
      y: 45,
      size: 10,
      font: helveticaRegular,
      color: rgb(0.6, 0.6, 0.6),
    });
  }

  const pdfBytes = await pdfDoc.save();
  return new File([pdfBytes.buffer as ArrayBuffer], `${title.replace(/\s+/g, '_')}.pdf`, {
    type: 'application/pdf',
  });
}
