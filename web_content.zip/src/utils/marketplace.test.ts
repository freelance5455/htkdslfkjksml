import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateSettlement,
  generateHmacSignature,
  verifyHmacSignature,
  validateStockReservation,
  transitionOrderStatus,
  verifyAdminCredentials,
  canAccessPortal,
  canReviewProduct,
  calculateProductRating,
  getRatingBreakdown,
} from './marketplace.ts';

test('settlement calculation computes accurate seller payout and marketplace commissions', () => {
  // Gross: ₹10,000, Commission: 12% = ₹1,200, PG fee: 2% = ₹200. Fees = ₹1,400.
  // GST on fees: 18% of ₹1,400 = ₹252.
  // Net payout = ₹10,000 - (1200 + 200 + 252) = ₹8,348.
  const result = calculateSettlement(10000, 0.12, 0.02, 0.18, 0);

  assert.equal(result.grossAmount, 10000);
  assert.equal(result.marketplaceCommission, 1200);
  assert.equal(result.paymentGatewayFee, 200);
  assert.equal(result.gstOnFees, 252);
  assert.equal(result.netSellerPayout, 8348);
  assert.equal(result.platformEarnings, 1200);
});

test('settlement calculation handles refund adjustments correctly', () => {
  const result = calculateSettlement(5000, 0.12, 0.02, 0.18, 500);
  // Fees = 600 + 100 = 700. GST = 126. Total deductions = 700 + 126 + 500 = 1326.
  // Net = 5000 - 1326 = 3674.
  assert.equal(result.netSellerPayout, 3674);
});

test('settlement throws on negative gross amount', () => {
  assert.throws(() => calculateSettlement(-100));
});

test('HMAC SHA256 signature verification accepts valid signatures and rejects invalid ones', () => {
  const secret = 'sec_pcmart_test_key_9988';
  const orderId = 'order_987654';
  const paymentId = 'pay_123456';
  const payload = `${orderId}|${paymentId}`;

  const validSignature = generateHmacSignature(payload, secret);
  assert.equal(verifyHmacSignature(payload, validSignature, secret), true);
  assert.equal(verifyHmacSignature(payload, 'tampered_signature_xyz', secret), false);
  assert.equal(verifyHmacSignature('different_order|pay_123456', validSignature, secret), false);
});

test('stock reservation detects insufficient inventory and prevents overselling', () => {
  const inventory = new Map<string, number>([
    ['prod_earbuds', 5],
    ['prod_watch_black', 2],
    ['prod_watch_silver', 0],
  ]);

  // Valid order
  const validRes = validateStockReservation(inventory, [
    { productId: 'prod_earbuds', quantity: 2 },
    { productId: 'prod_watch', variantId: 'black', quantity: 1 },
  ]);
  assert.equal(validRes.valid, true);
  assert.equal(validRes.updatedInventory?.get('prod_earbuds'), 3);
  assert.equal(validRes.updatedInventory?.get('prod_watch_black'), 1);

  // Overselling attempt
  const overRes = validateStockReservation(inventory, [
    { productId: 'prod_earbuds', quantity: 6 },
  ]);
  assert.equal(overRes.valid, false);
  assert.match(overRes.error ?? '', /Insufficient stock/);

  // Out of stock item
  const oosRes = validateStockReservation(inventory, [
    { productId: 'prod_watch', variantId: 'silver', quantity: 1 },
  ]);
  assert.equal(oosRes.valid, false);
});

test('order state machine enforces valid role transitions', () => {
  // Customer can cancel before shipping
  const custCancelBeforeShip = transitionOrderStatus('CONFIRMED', 'CANCEL', 'CUSTOMER');
  assert.equal(custCancelBeforeShip.allowed, true);
  assert.equal(custCancelBeforeShip.nextStatus, 'CANCELLED');

  // Customer cannot cancel after shipping
  const custCancelAfterShip = transitionOrderStatus('SHIPPED', 'CANCEL', 'CUSTOMER');
  assert.equal(custCancelAfterShip.allowed, false);

  // Customer can request return once delivered
  const custReturn = transitionOrderStatus('DELIVERED', 'REQUEST_RETURN', 'CUSTOMER');
  assert.equal(custReturn.allowed, true);
  assert.equal(custReturn.nextStatus, 'RETURN_REQUESTED');

  // Seller can pack, ship, and deliver
  assert.equal(transitionOrderStatus('CONFIRMED', 'PACK', 'SELLER').nextStatus, 'PACKED');
  assert.equal(transitionOrderStatus('PACKED', 'SHIP', 'SELLER').nextStatus, 'SHIPPED');
  assert.equal(transitionOrderStatus('SHIPPED', 'OUT_FOR_DELIVERY', 'SELLER').nextStatus, 'OUT_FOR_DELIVERY');
  assert.equal(transitionOrderStatus('OUT_FOR_DELIVERY', 'DELIVER', 'SELLER').nextStatus, 'DELIVERED');

  // Seller cannot cancel customer order arbitrarily
  assert.equal(transitionOrderStatus('CONFIRMED', 'CANCEL', 'SELLER').allowed, false);
});

test('RBAC role gating prevents customers from accessing Admin and Seller portals', () => {
  // Customer permissions
  assert.equal(canAccessPortal('CUSTOMER', 'CUSTOMER_APP'), true);
  assert.equal(canAccessPortal('CUSTOMER', 'SELLER_PORTAL'), false);
  assert.equal(canAccessPortal('CUSTOMER', 'ADMIN_DASHBOARD'), false);
  assert.equal(canAccessPortal('CUSTOMER', 'ARCHITECTURE_CENTER'), false);

  // Seller permissions
  assert.equal(canAccessPortal('SELLER', 'CUSTOMER_APP'), true);
  assert.equal(canAccessPortal('SELLER', 'SELLER_PORTAL'), true);
  assert.equal(canAccessPortal('SELLER', 'ADMIN_DASHBOARD'), false);

  // Admin permissions
  assert.equal(canAccessPortal('ADMIN', 'ADMIN_DASHBOARD'), true);
  assert.equal(canAccessPortal('ADMIN', 'SELLER_PORTAL'), true);
  assert.equal(canAccessPortal('ADMIN', 'CUSTOMER_APP'), true);

  // Admin credentials verification
  assert.equal(verifyAdminCredentials('992418'), true);
  assert.equal(verifyAdminCredentials('pcmart@admin2026'), true);
  assert.equal(verifyAdminCredentials('wrong_pin_123'), false);
  assert.equal(verifyAdminCredentials(''), false);
});

test('canReviewProduct only allows reviews after order is marked DELIVERED', () => {
  assert.equal(canReviewProduct('DELIVERED'), true);
  assert.equal(canReviewProduct('CONFIRMED'), false);
  assert.equal(canReviewProduct('PACKED'), false);
  assert.equal(canReviewProduct('SHIPPED'), false);
  assert.equal(canReviewProduct('OUT_FOR_DELIVERY'), false);
  assert.equal(canReviewProduct('CANCELLED'), false);
  assert.equal(canReviewProduct('RETURNED'), false);
});

test('calculateProductRating computes accurate rating average and counts', () => {
  // Empty reviews
  assert.deepEqual(calculateProductRating([]), { rating: 5.0, count: 0 });

  // Single review
  assert.deepEqual(calculateProductRating([{ rating: 4 }]), { rating: 4.0, count: 1 });

  // Multiple reviews: 5, 5, 4 -> 14 / 3 = 4.67 -> 4.7
  const res = calculateProductRating([{ rating: 5 }, { rating: 5 }, { rating: 4 }]);
  assert.equal(res.rating, 4.7);
  assert.equal(res.count, 3);
});

test('getRatingBreakdown correctly groups 1-5 star distributions', () => {
  const reviews = [
    { rating: 5 },
    { rating: 5 },
    { rating: 4 },
    { rating: 3 },
    { rating: 1 },
  ];
  const breakdown = getRatingBreakdown(reviews);
  assert.equal(breakdown[5], 2);
  assert.equal(breakdown[4], 1);
  assert.equal(breakdown[3], 1);
  assert.equal(breakdown[2], 0);
  assert.equal(breakdown[1], 1);
});

