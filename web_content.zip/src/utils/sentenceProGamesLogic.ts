import type { SentenceEntry } from '../types';
import { createSeededRng, shuffleWithRng } from './arcadeGamesLogic';
import { SENTENCE_SECTIONS, STARTER_AR_TRANSLATIONS } from './sentenceLogic';

export interface VanishToken {
  index: number;
  raw: string;
  cleanWord: string;
  leadingPunct: string;
  trailingPunct: string;
  isBlank: boolean;
}

export interface VanishStageData {
  stage: 1 | 2 | 3;
  tokens: VanishToken[];
  blankIndices: number[];
  chips: Array<{ id: string; word: string }>;
}

export interface ClozeQuestion {
  sentence: SentenceEntry;
  ar: string;
  beforeBlank: string;
  afterBlank: string;
  targetWord: string;
  options: string[];
}

export interface ChatDialogueItem {
  id: string;
  sectionId: string;
  incomingEn: string;
  incomingAr: string;
  replyEn: string;
  replyAr: string;
  speakerName: string;
}

export interface ChatReplyQuestion {
  dialogue: ChatDialogueItem;
  options: Array<{ text: string; ar: string; isCorrect: boolean }>;
}

export interface SentenceBlitzQuestion {
  sentence: SentenceEntry;
  ar: string;
  direction: 'en2ar' | 'ar2en';
  prompt: string;
  options: Array<{ id: number; label: string; isCorrect: boolean }>;
}

const STOP_WORDS = new Set([
  'a',
  'an',
  'the',
  'i',
  'am',
  'is',
  'are',
  'to',
  'of',
  'it',
  'in',
  'on',
  'at',
  'and',
  'or',
  'but',
  'be',
  'by',
  'as',
]);

const FALLBACK_CLOZE_DISTRACTORS = [
  'always',
  'never',
  'before',
  'after',
  'between',
  'during',
  'should',
  'could',
  'would',
  'might',
  'better',
  'ready',
  'different',
  'important',
  'together',
  'morning',
  'evening',
  'tomorrow',
  'yesterday',
  'station',
  'airport',
  'office',
  'meeting',
  'message',
  'question',
  'answer',
  'problem',
  'reason',
  'finish',
  'decide',
  'explain',
  'remember',
  'prefer',
  'choose',
  'change',
  'check',
];

export const CURATED_CHAT_DIALOGUES: ChatDialogueItem[] = [
  // daily_chat
  { id: 'c1', sectionId: 'daily_chat', speakerName: 'Sarah', incomingEn: 'How has your week been so far?', incomingAr: 'كيف كان أسبوعك حتى الآن؟', replyEn: 'Pretty busy, but things are going well.', replyAr: 'مزدحم قليلاً، لكن الأمور تسير بشكل جيد.' },
  { id: 'c2', sectionId: 'daily_chat', speakerName: 'Alex', incomingEn: 'Would you like to grab a coffee after work?', incomingAr: 'هل تود أن نحتسي قهوة بعد العمل؟', replyEn: 'Sure, that sounds like a great idea!', replyAr: 'بالتأكيد، تبدو فكرة رائعة!' },
  { id: 'c3', sectionId: 'daily_chat', speakerName: 'Maya', incomingEn: 'What are you planning to do this weekend?', incomingAr: 'ماذا تخطط أن تفعل في عطلة نهاية الأسبوع؟', replyEn: 'I might visit my family and get some rest.', replyAr: 'ربما أزور عائلتي وأحصل على بعض الراحة.' },
  { id: 'c4', sectionId: 'daily_chat', speakerName: 'Liam', incomingEn: 'Long time no see! How have you been?', incomingAr: 'مرّ وقت طويل! كيف حالك؟', replyEn: 'I have been great, thanks for asking!', replyAr: 'أنا بخير والحمد لله، شكراً لسؤالك!' },
  { id: 'c5', sectionId: 'daily_chat', speakerName: 'Nora', incomingEn: 'Did you get a chance to watch that movie?', incomingAr: 'هل أتيحت لك الفرصة لمشاهدة ذلك الفيلم؟', replyEn: 'Not yet, I plan to watch it tonight.', replyAr: 'ليس بعد، أخطط لمشاهدته الليلة.' },
  { id: 'c6', sectionId: 'daily_chat', speakerName: 'Omar', incomingEn: 'Do you usually wake up early on weekdays?', incomingAr: 'هل تستيقظ باكراً عادةً في أيام العمل؟', replyEn: 'Yes, I normally get up around seven.', replyAr: 'نعم، أستيقظ عادةً قرابة الساعة السابعة.' },
  { id: 'c7', sectionId: 'daily_chat', speakerName: 'Emma', incomingEn: 'It looks like it is going to rain soon.', incomingAr: 'يبدو أنها ستمطر قريباً.', replyEn: 'Good thing I brought my umbrella today.', replyAr: 'جيد أنني أحضرت مظلتي اليوم.' },
  { id: 'c8', sectionId: 'daily_chat', speakerName: 'Adam', incomingEn: 'Have you had lunch yet?', incomingAr: 'هل تناولت الغداء بعد؟', replyEn: 'Not yet, I am actually getting hungry.', replyAr: 'ليس بعد، في الحقيقة بدأت أشعر بالجوع.' },

  // travel
  { id: 'c9', sectionId: 'travel', speakerName: 'Agent', incomingEn: 'May I see your passport and boarding pass, please?', incomingAr: 'هل يمكنني رؤية جواز سفرك وبطاقة الصعود من فضلك؟', replyEn: 'Of course, here they are.', replyAr: 'بالطبع، تفضل ها هما.' },
  { id: 'c10', sectionId: 'travel', speakerName: 'Clerk', incomingEn: 'Would you prefer a window seat or an aisle seat?', incomingAr: 'هل تفضل مقعداً بجانب النافذة أم الممر؟', replyEn: 'A window seat, please, if one is available.', replyAr: 'مقعداً بجانب النافذة من فضلك إن كان متاحاً.' },
  { id: 'c11', sectionId: 'travel', speakerName: 'Driver', incomingEn: 'Where can I drop you off today?', incomingAr: 'أين يمكنني أن أوصلك اليوم؟', replyEn: 'To the central train station, please.', replyAr: 'إلى محطة القطار المركزية من فضلك.' },
  { id: 'c12', sectionId: 'travel', speakerName: 'Reception', incomingEn: 'Do you have a reservation under your name?', incomingAr: 'هل لديك حجز باسمك؟', replyEn: 'Yes, I booked a single room for three nights.', replyAr: 'نعم، حجزت غرفة فردية لثلاث ليالٍ.' },
  { id: 'c13', sectionId: 'travel', speakerName: 'Guide', incomingEn: 'Is this your first time visiting London?', incomingAr: 'هل هذه أول مرة تزور فيها لندن؟', replyEn: 'Yes, and I am really excited to explore it.', replyAr: 'نعم، وأنا متحمس جداً لاستكشافها.' },
  { id: 'c14', sectionId: 'travel', speakerName: 'Passenger', incomingEn: 'Excuse me, does this bus go to the airport?', incomingAr: 'عفواً، هل هذه الحافلة تذهب إلى المطار؟', replyEn: 'Yes, it stops right outside Terminal Two.', replyAr: 'نعم، تتوقف مباشرة أمام الصالة الثانية.' },
  { id: 'c15', sectionId: 'travel', speakerName: 'Staff', incomingEn: 'How many bags are you checking in today?', incomingAr: 'كم حقيبة ستقوم بتسجيلها اليوم؟', replyEn: 'Just one suitcase and this small backpack.', replyAr: 'حقيبة سفر واحدة فقط وهذه الحقيبة الصغيرة.' },
  { id: 'c16', sectionId: 'travel', speakerName: 'Reception', incomingEn: 'What time is checkout tomorrow morning?', incomingAr: 'في أي ساعة يكون تسجيل المغادرة صباح الغد؟', replyEn: 'Checkout is before eleven in the morning.', replyAr: 'تسجيل المغادرة قبل الساعة الحادية عشرة صباحاً.' },

  // shopping
  { id: 'c17', sectionId: 'shopping', speakerName: 'Cashier', incomingEn: 'How would you like to pay for these items?', incomingAr: 'كيف تود الدفع مقابل هذه المشتريات؟', replyEn: 'I will pay by card, please.', replyAr: 'سأدفع بالبطاقة من فضلك.' },
  { id: 'c18', sectionId: 'shopping', speakerName: 'Assistant', incomingEn: 'Can I help you find a specific size?', incomingAr: 'هل يمكنني مساعدتك في إيجاد مقاس معين؟', replyEn: 'Yes, do you have this jacket in medium?', replyAr: 'نعم، هل لديكم هذه السترة بمقاس متوسط؟' },
  { id: 'c19', sectionId: 'shopping', speakerName: 'Seller', incomingEn: 'Would you like a receipt in the bag?', incomingAr: 'هل تريد الإيصال داخل الكيس؟', replyEn: 'Yes, please, just in case I need to return it.', replyAr: 'نعم من فضلك، تحسباً لاحتياجي لإرجاعه.' },
  { id: 'c20', sectionId: 'shopping', speakerName: 'Shopper', incomingEn: 'How much does this leather wallet cost?', incomingAr: 'كم يكلف ثمن هذه المحفظة الجلدية؟', replyEn: 'It is thirty dollars, and it is on sale today.', replyAr: 'سعرها ثلاثون دولاراً، وعليها تخفيض اليوم.' },
  { id: 'c21', sectionId: 'shopping', speakerName: 'Assistant', incomingEn: 'How does that shirt fit you?', incomingAr: 'كيف يناسبك ذلك القميص؟', replyEn: 'It feels a bit tight around the shoulders.', replyAr: 'أشعر أنه ضيق قليلاً عند الكتفين.' },
  { id: 'c22', sectionId: 'shopping', speakerName: 'Cashier', incomingEn: 'Do you need a shopping bag for your groceries?', incomingAr: 'هل تحتاج كيس تسوق لمشترياتك؟', replyEn: 'No thanks, I brought my own reusable bag.', replyAr: 'لا شكراً، أحضرت كيسي الخاص القابل لإعادة الاستخدام.' },

  // short_qa
  { id: 'c23', sectionId: 'short_qa', speakerName: 'Sam', incomingEn: 'What time does the meeting start?', incomingAr: 'متى يبدأ الاجتماع؟', replyEn: 'It starts at ten thirty sharp.', replyAr: 'يبدأ في العاشرة والنصف تماماً.' },
  { id: 'c24', sectionId: 'short_qa', speakerName: 'Clara', incomingEn: 'Where did you leave the car keys?', incomingAr: 'أين تركت مفاتيح السيارة؟', replyEn: 'I put them on the kitchen table.', replyAr: 'وضعتها على طاولة المطبخ.' },
  { id: 'c25', sectionId: 'short_qa', speakerName: 'Daniel', incomingEn: 'How long does it take to get there by train?', incomingAr: 'كم يستغرق الوصول إلى هناك بالقطار؟', replyEn: 'It usually takes about forty minutes.', replyAr: 'يستغرق عادةً حوالي أربعين دقيقة.' },
  { id: 'c26', sectionId: 'short_qa', speakerName: 'Hana', incomingEn: 'Whose laptop is on the desk?', incomingAr: 'لمن هذا الحاسوب المحمول على المكتب؟', replyEn: 'That belongs to my colleague David.', replyAr: 'إنه يخص زميلي ديفيد.' },
  { id: 'c27', sectionId: 'short_qa', speakerName: 'Tariq', incomingEn: 'Why is the store closed today?', incomingAr: 'لماذا المتجر مغلق اليوم؟', replyEn: 'Because today is a national holiday.', replyAr: 'لأن اليوم عطلة وطنية رسمية.' },
  { id: 'c28', sectionId: 'short_qa', speakerName: 'Lina', incomingEn: 'Can you speak any other languages?', incomingAr: 'هل يمكنك التحدث بأي لغات أخرى؟', replyEn: 'Yes, I speak Arabic and a little French.', replyAr: 'نعم، أتحدث العربية والقليل من الفرنسية.' },
  { id: 'c29', sectionId: 'short_qa', speakerName: 'Ben', incomingEn: 'What is the Wi-Fi password here?', incomingAr: 'ما هي كلمة مرور الواي فاي هنا؟', replyEn: 'It is written on the card near the counter.', replyAr: 'إنها مكتوبة على البطاقة بالقرب من الكاونتر.' },
  { id: 'c30', sectionId: 'short_qa', speakerName: 'Mia', incomingEn: 'Are you ready to order now?', incomingAr: 'هل أنت مستعد للطلب الآن؟', replyEn: 'Yes, I would like the grilled chicken salad.', replyAr: 'نعم، أود طلب سلطة الدجاج المشوي.' },

  // apology
  { id: 'c31', sectionId: 'apology', speakerName: 'Noah', incomingEn: 'I am so sorry I am late! Traffic was terrible.', incomingAr: 'أنا آسف جداً على التأخير! كان الزحام شديداً.', replyEn: 'No worries at all, I just got here myself.', replyAr: 'لا تقلق أبداً، لقد وصلت للتو أنا أيضاً.' },
  { id: 'c32', sectionId: 'apology', speakerName: 'Layla', incomingEn: 'Excuse me, I think I accidentally took your umbrella.', incomingAr: 'عفواً، أعتقد أنني أخذت مظلتك بالخطأ.', replyEn: 'That is completely fine, they look identical!', replyAr: 'لا بأس أبداً، إنهما متطابقتان تماماً!' },
  { id: 'c33', sectionId: 'apology', speakerName: 'Zaid', incomingEn: 'Thank you so much for helping me move these boxes.', incomingAr: 'شكراً جزيلاً لمساعدتي في نقل هذه الصناديق.', replyEn: 'You are very welcome, happy to help anytime.', replyAr: 'على الرحب والسعة، يسعدني المساعدة في أي وقت.' },
  { id: 'c34', sectionId: 'apology', speakerName: 'Sophie', incomingEn: 'Could you please remind me about the deadline?', incomingAr: 'هل يمكنك تذكيري بالموعد النهائي من فضلك؟', replyEn: 'Sure, it needs to be submitted by Friday evening.', replyAr: 'بالتأكيد، يجب تسليمه قبل مساء الجمعة.' },
  { id: 'c35', sectionId: 'apology', speakerName: 'Karim', incomingEn: 'I forgot to bring the notes you asked for.', incomingAr: 'نسيت أن أحضر الملاحظات التي طلبتها.', replyEn: 'No problem, you can just email them to me later.', replyAr: 'لا مشكلة، يمكنك فقط إرسالها لي بالبريد لاحقاً.' },

  // opinions
  { id: 'c36', sectionId: 'opinions', speakerName: 'Rami', incomingEn: 'What do you think about working from home?', incomingAr: 'ما رأيك في العمل من المنزل؟', replyEn: 'I think it saves a lot of commuting time.', replyAr: 'أعتقد أنه يوفر الكثير من وقت التنقل.' },
  { id: 'c37', sectionId: 'opinions', speakerName: 'Julia', incomingEn: 'Do you think learning English takes a long time?', incomingAr: 'هل تعتقد أن تعلم الإنجليزية يستغرق وقتاً طويلاً؟', replyEn: 'With daily practice, you improve much faster than you expect.', replyAr: 'مع الممارسة اليومية، تتحسن أسرع بكثير مما تتوقع.' },
  { id: 'c38', sectionId: 'opinions', speakerName: 'Fadi', incomingEn: 'Should we take the highway or the local road?', incomingAr: 'هل يجب أن نسلك الطريق السريع أم الطريق المحلي؟', replyEn: 'Let us take the local road to avoid traffic.', replyAr: 'دعنا نسلك الطريق المحلي لتجنب الازدحام.' },
  { id: 'c39', sectionId: 'opinions', speakerName: 'Elena', incomingEn: 'Did you enjoy the presentation this morning?', incomingAr: 'هل استمتعت بالعرض التقديمي هذا الصباح؟', replyEn: 'Yes, the examples were super clear and practical.', replyAr: 'نعم، كانت الأمثلة واضحة وعملية جداً.' },
  { id: 'c40', sectionId: 'opinions', speakerName: 'Yousef', incomingEn: 'I believe reading every day builds strong vocabulary.', incomingAr: 'أؤمن أن القراءة يومياً تبني حصيلة لغوية قوية.', replyEn: 'I completely agree with you on that point.', replyAr: 'أتفق معك تماماً في هذه النقطة.' },

  // basics / everyday work & life
  { id: 'c41', sectionId: 'basics', speakerName: 'Teacher', incomingEn: 'Could you repeat that sentence a bit more slowly?', incomingAr: 'هل يمكنك إعادة تلك الجملة ببطء أكثر قليلاً؟', replyEn: 'Sure, let me say it again clearly.', replyAr: 'بالتأكيد، دعني أقولها مجدداً بوضوح.' },
  { id: 'c42', sectionId: 'basics', speakerName: 'Doctor', incomingEn: 'How long have you had this headache?', incomingAr: 'منذ متى وأنت تعاني من هذا الصداع؟', replyEn: 'It started yesterday evening after work.', replyAr: 'بدأ مساء أمس بعد العمل.' },
  { id: 'c43', sectionId: 'basics', speakerName: 'Manager', incomingEn: 'Can you finish the report before noon?', incomingAr: 'هل يمكنك إنهاء التقرير قبل الظهر؟', replyEn: 'Yes, I am almost done with the final section.', replyAr: 'نعم، لقد أوشكت على الانتهاء من القسم الأخير.' },
  { id: 'c44', sectionId: 'basics', speakerName: 'Friend', incomingEn: 'Would you like me to call you when I arrive?', incomingAr: 'هل تريدني أن أتصل بك عندما أصل؟', replyEn: 'Yes, send me a quick text or give me a call.', replyAr: 'نعم، أرسل لي رسالة سريعة أو اتصل بي.' },
  { id: 'c45', sectionId: 'basics', speakerName: 'Host', incomingEn: 'Make yourself at home! Would you like some tea?', incomingAr: 'البيت بيتك! هل تود بعض الشاي؟', replyEn: 'Thank you, a cup of mint tea would be lovely.', replyAr: 'شكراً لك، كوب من الشاي بالنعناع سيكون رائعاً.' },
];

export const CURATED_PRACTICE_SENTENCES: Array<{ num: number; en: string; ar: string }> = [
  { num: 1001, en: 'I usually drink a cup of coffee before work.', ar: 'عادةً أشرب كوباً من القهوة قبل العمل.' },
  { num: 1002, en: 'She is learning English to advance her career.', ar: 'هي تتعلم الإنجليزية لتطوير مسيرتها المهنية.' },
  { num: 1003, en: 'Could you tell me where the nearest pharmacy is?', ar: 'هل يمكنك إخباري أين تقع أقرب صيدلية؟' },
  { num: 1004, en: 'We should leave early to avoid the morning traffic.', ar: 'ينبغي أن نغادر باكراً لتجنب زحام الصباح.' },
  { num: 1005, en: 'They have lived in this quiet neighborhood for five years.', ar: 'لقد عاشوا في هذا الحي الهادئ لمدة خمس سنوات.' },
  { num: 1006, en: 'Please send me a message as soon as you arrive.', ar: 'من فضلك أرسل لي رسالة فور وصولك.' },
  { num: 1007, en: 'I forgot my umbrella on the train yesterday evening.', ar: 'نسيت مظلتي في القطار مساء أمس.' },
  { num: 1008, en: 'Learning a new language takes patience and daily practice.', ar: 'تعلم لغة جديدة يتطلب الصبر والممارسة اليومية.' },
  { num: 1009, en: 'He promised to help us finish the project on time.', ar: 'لقد وعد بمساعدتنا في إنهاء المشروع في الوقت المحدد.' },
  { num: 1010, en: 'Would you like to sit near the window or outside?', ar: 'هل تود الجلوس قرب النافذة أم في الخارج؟' },
  { num: 1011, en: 'The flight to London was delayed because of heavy fog.', ar: 'تأخرت الرحلة إلى لندن بسبب الضباب الكثيف.' },
  { num: 1012, en: 'I am looking forward to meeting your team next Monday.', ar: 'أتطلع بشوق للقاء فريقك يوم الإثنين القادم.' },
  { num: 1013, en: 'You can pay by credit card or cash at the counter.', ar: 'يمكنك الدفع ببطاقة الائتمان أو نقداً عند الكاونتر.' },
  { num: 1014, en: 'She always checks her calendar before scheduling a meeting.', ar: 'تتحقق دائماً من تقويمها قبل جدولة أي اجتماع.' },
  { num: 1015, en: 'Remember to save your work before closing the laptop.', ar: 'تذكر أن تحفظ عملك قبل إغلاق الحاسوب المحمول.' },
  { num: 1016, en: 'The weather gets much cooler after sunset in autumn.', ar: 'يصبح الطقس أبرد بكثير بعد غروب الشمس في الخريف.' },
];

export function filterSentencesBySection(
  sentences: SentenceEntry[],
  sectionId: string
): SentenceEntry[] {
  if (!sectionId || sectionId === 'all') return sentences;
  const sec = SENTENCE_SECTIONS.find((s) => s.id === sectionId);
  if (!sec) return sentences;
  const filtered = sentences.filter((s) => s.num >= sec.startNum && s.num <= sec.endNum);
  return filtered.length >= 6 ? filtered : sentences;
}

/**
 * Splits an English sentence into word tokens while keeping leading/trailing punctuation intact.
 */
export function splitSentenceTokens(sentenceEn: string): Array<{
  raw: string;
  cleanWord: string;
  leadingPunct: string;
  trailingPunct: string;
}> {
  return sentenceEn
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .map((raw) => {
      const m = raw.match(/^([^A-Za-z0-9']*)([A-Za-z0-9']+)([^A-Za-z0-9']*)$/);
      if (!m) {
        return { raw, cleanWord: raw, leadingPunct: '', trailingPunct: '' };
      }
      return {
        raw,
        leadingPunct: m[1] || '',
        cleanWord: m[2] || raw,
        trailingPunct: m[3] || '',
      };
    });
}

/**
 * Vanishing Sentence 3-stage mask generator:
 * Stage 1 = 0% hidden (Memorize), Stage 2 = ~35% hidden, Stage 3 = ~70% hidden.
 */
export function buildVanishStage(
  sentenceEn: string,
  stage: 1 | 2 | 3,
  seed: number = 42
): VanishStageData {
  const parts = splitSentenceTokens(sentenceEn);
  const wordIndices = parts
    .map((p, idx) => ({ p, idx }))
    .filter(({ p }) => /[A-Za-z]/.test(p.cleanWord));

  if (stage === 1 || wordIndices.length === 0) {
    return {
      stage,
      tokens: parts.map((p, index) => ({ ...p, index, isBlank: false })),
      blankIndices: [],
      chips: [],
    };
  }

  const ratio = stage === 2 ? 0.35 : 0.7;
  const targetBlanks = Math.max(
    stage === 2 ? 1 : Math.min(2, wordIndices.length),
    Math.min(wordIndices.length, Math.round(wordIndices.length * ratio))
  );

  // Prefer content words first, then remaining words deterministically
  const rng = createSeededRng(seed + stage * 997);
  const contentFirst = wordIndices.filter(
    ({ p }) => !STOP_WORDS.has(p.cleanWord.toLowerCase()) && p.cleanWord.length >= 3
  );
  const others = wordIndices.filter(
    ({ p }) => STOP_WORDS.has(p.cleanWord.toLowerCase()) || p.cleanWord.length < 3
  );
  const orderedCandidates = [
    ...shuffleWithRng(contentFirst, rng),
    ...shuffleWithRng(others, rng),
  ];

  const chosenSet = new Set(orderedCandidates.slice(0, targetBlanks).map((x) => x.idx));
  const blankIndices = Array.from(chosenSet).sort((a, b) => a - b);

  const tokens: VanishToken[] = parts.map((p, index) => ({
    ...p,
    index,
    isBlank: chosenSet.has(index),
  }));

  const chips = shuffleWithRng(
    blankIndices.map((idx, cIdx) => ({
      id: `chip-${stage}-${idx}-${cIdx}`,
      word: parts[idx].cleanWord,
    })),
    rng
  );

  return { stage, tokens, blankIndices, chips };
}

/**
 * Intelligently blanks a meaningful word in a sentence and generates 3 corpus distractors.
 */
export function buildClozeQuestion(
  sentence: SentenceEntry,
  corpusPool: SentenceEntry[],
  arMap: Record<string, string>,
  seed: number = Date.now()
): ClozeQuestion | null {
  const parts = splitSentenceTokens(sentence.en);
  if (parts.length < 3) return null;

  const rng = createSeededRng(seed);
  const candidateIndices = parts
    .map((p, idx) => ({ p, idx }))
    .filter(({ p }) => /^[A-Za-z']{3,}$/.test(p.cleanWord) && !STOP_WORDS.has(p.cleanWord.toLowerCase()));

  const fallbackIndices = parts
    .map((p, idx) => ({ p, idx }))
    .filter(({ p }) => /^[A-Za-z']{2,}$/.test(p.cleanWord));

  const pool = candidateIndices.length > 0 ? candidateIndices : fallbackIndices;
  if (pool.length === 0) return null;

  const picked = pool[Math.floor(rng() * pool.length)];
  const targetWord = picked.p.cleanWord;
  const targetLower = targetWord.toLowerCase();

  const beforeTokens = parts.slice(0, picked.idx).map((p) => p.raw);
  const afterTokens = parts.slice(picked.idx + 1).map((p) => p.raw);
  const beforeBlank =
    beforeTokens.join(' ') +
    (beforeTokens.length > 0 ? ' ' : '') +
    picked.p.leadingPunct;
  const afterBlank =
    picked.p.trailingPunct +
    (afterTokens.length > 0 ? ' ' : '') +
    afterTokens.join(' ');

  // Collect plausible distractors from same corpus/section
  const distractors: string[] = [];
  const used = new Set<string>([targetLower]);
  const samplePool = shuffleWithRng(corpusPool.slice(0, 120), rng);

  for (const s of samplePool) {
    if (s.num === sentence.num) continue;
    const words = splitSentenceTokens(s.en);
    for (const w of words) {
      const cw = w.cleanWord;
      const lower = cw.toLowerCase();
      if (
        /^[A-Za-z']{3,12}$/.test(cw) &&
        !used.has(lower) &&
        !STOP_WORDS.has(lower) &&
        Math.abs(cw.length - targetWord.length) <= 4
      ) {
        used.add(lower);
        // Match capitalization style of target
        const formatted =
          targetWord[0] === targetWord[0].toUpperCase() && picked.idx === 0
            ? cw[0].toUpperCase() + cw.slice(1).toLowerCase()
            : cw.toLowerCase();
        distractors.push(formatted);
        break;
      }
    }
    if (distractors.length >= 3) break;
  }

  for (const fb of shuffleWithRng(FALLBACK_CLOZE_DISTRACTORS, rng)) {
    if (distractors.length >= 3) break;
    if (!used.has(fb.toLowerCase())) {
      used.add(fb.toLowerCase());
      distractors.push(fb);
    }
  }

  const options = shuffleWithRng([targetWord, ...distractors.slice(0, 3)], rng);
  const ar =
    arMap[sentence.en] ||
    STARTER_AR_TRANSLATIONS[sentence.en] ||
    CURATED_PRACTICE_SENTENCES.find((c) => c.en === sentence.en)?.ar ||
    '';

  return {
    sentence,
    ar,
    beforeBlank,
    afterBlank,
    targetWord,
    options,
  };
}

/**
 * Builds a Quick Chat Reply round filtered by topic section (with rich 45+ curated dialogues).
 */
export function buildChatReplyRound(
  sectionId: string,
  count = 10,
  seed: number = Date.now()
): ChatReplyQuestion[] {
  const rng = createSeededRng(seed);
  const matched =
    sectionId && sectionId !== 'all'
      ? CURATED_CHAT_DIALOGUES.filter((d) => d.sectionId === sectionId)
      : CURATED_CHAT_DIALOGUES;
  const primaryPool = matched.length >= 4 ? matched : CURATED_CHAT_DIALOGUES;
  const selected = shuffleWithRng(primaryPool, rng).slice(0, Math.min(count, primaryPool.length));

  return selected.map((dialogue) => {
    const others = shuffleWithRng(
      CURATED_CHAT_DIALOGUES.filter((d) => d.id !== dialogue.id && d.replyEn !== dialogue.replyEn),
      rng
    ).slice(0, 3);

    const options = shuffleWithRng(
      [
        { text: dialogue.replyEn, ar: dialogue.replyAr, isCorrect: true },
        ...others.map((o) => ({ text: o.replyEn, ar: o.replyAr, isCorrect: false })),
      ],
      rng
    );

    return { dialogue, options };
  });
}

/**
 * Generates first-letter memory hints for Speak to Unlock:
 * "How are you?" -> "H__ a__ y__?"
 */
export function buildFirstLetterHint(sentenceEn: string): string {
  const parts = splitSentenceTokens(sentenceEn);
  return parts
    .map((p) => {
      if (!p.cleanWord || !/[A-Za-z]/.test(p.cleanWord)) return p.raw;
      if (p.cleanWord.length <= 1) return p.raw;
      const masked = p.cleanWord[0] + '_'.repeat(Math.min(6, p.cleanWord.length - 1));
      return `${p.leadingPunct}${masked}${p.trailingPunct}`;
    })
    .join(' ');
}

/**
 * Builds a 4-option question for 60-Second Sentence Speed Blitz.
 * Switches direction (EN->AR vs AR->EN) every 5 rounds.
 */
export function buildSentenceBlitzQuestion(
  pool: Array<{ sentence: SentenceEntry; ar: string }>,
  roundIndex: number,
  seed: number,
  recentNums: Set<number> = new Set()
): SentenceBlitzQuestion | null {
  if (pool.length < 4) return null;
  const rng = createSeededRng(seed);
  const fresh = pool.filter((item) => !recentNums.has(item.sentence.num));
  const pickPool = fresh.length >= 4 ? fresh : pool;
  const target = pickPool[Math.floor(rng() * pickPool.length)];
  const direction: 'en2ar' | 'ar2en' = Math.floor(roundIndex / 5) % 2 === 0 ? 'en2ar' : 'ar2en';

  const distractors: Array<{ sentence: SentenceEntry; ar: string }> = [];
  const usedLabels = new Set<string>([
    direction === 'en2ar' ? target.ar.trim().toLowerCase() : target.sentence.en.trim().toLowerCase(),
  ]);

  let guard = 0;
  while (distractors.length < 3 && guard < 120) {
    guard++;
    const cand = pool[Math.floor(rng() * pool.length)];
    if (!cand || cand.sentence.num === target.sentence.num) continue;
    const labelKey =
      direction === 'en2ar' ? cand.ar.trim().toLowerCase() : cand.sentence.en.trim().toLowerCase();
    if (usedLabels.has(labelKey)) continue;
    usedLabels.add(labelKey);
    distractors.push(cand);
  }

  const options = shuffleWithRng(
    [
      {
        id: target.sentence.num,
        label: direction === 'en2ar' ? target.ar : target.sentence.en,
        isCorrect: true,
      },
      ...distractors.map((d) => ({
        id: d.sentence.num,
        label: direction === 'en2ar' ? d.ar : d.sentence.en,
        isCorrect: false,
      })),
    ],
    rng
  );

  return {
    sentence: target.sentence,
    ar: target.ar,
    direction,
    prompt: direction === 'en2ar' ? target.sentence.en : target.ar,
    options,
  };
}
