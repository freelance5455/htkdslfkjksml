import * as THREE from 'three';

/**
 * Creates an intricate procedural 3D anime companion avatar for 002.
 * Adheres strictly to the Three.js directives:
 * - 3-12 composite parts with varied roughness and metalness
 * - Three silhouette levels: primary body/head, secondary hair/armor, accent horns/core/rings
 * - Bottom-center pivot so it rests perfectly on the pedestal
 * - Returns an update hook for idle breathing, floating, and subtle eye blink/horn glow pulsation
 */

export interface ProceduralAnimationControls {
  idleEnabled?: boolean;
  blinkEnabled?: boolean;
  headMovementEnabled?: boolean;
}

export interface ProceduralCompanion {
  group: THREE.Group;
  update: (time: number, delta: number, controls?: ProceduralAnimationControls) => void;
  resetPose: () => void;
  setWireframe: (wireframe: boolean) => void;
}

export function createProcedural002(): ProceduralCompanion {
  const root = new THREE.Group();
  root.name = 'Procedural002_Companion';

  const materials: THREE.Material[] = [];

  // PBR Materials with high contrast roughness/metalness
  const skinMaterial = new THREE.MeshStandardMaterial({
    color: 0xffebd9, // porcelain anime complexion
    roughness: 0.65,
    metalness: 0.05,
  });
  materials.push(skinMaterial);

  const hairMaterial = new THREE.MeshStandardMaterial({
    color: 0xff4f9a, // vibrant 002 pink hair
    roughness: 0.35,
    metalness: 0.2,
  });
  materials.push(hairMaterial);

  const darkHairShadowMaterial = new THREE.MeshStandardMaterial({
    color: 0xdb2777,
    roughness: 0.45,
    metalness: 0.15,
  });
  materials.push(darkHairShadowMaterial);

  // Iconic red pilot uniform chassis
  const crimsonSuitMaterial = new THREE.MeshStandardMaterial({
    color: 0xd90429, // Franxx cockpit crimson
    roughness: 0.2,
    metalness: 0.7,
  });
  materials.push(crimsonSuitMaterial);

  const whiteSuitAccentMaterial = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    roughness: 0.3,
    metalness: 0.4,
  });
  materials.push(whiteSuitAccentMaterial);

  // Glowing Horns & Core
  const hornEmissiveMaterial = new THREE.MeshStandardMaterial({
    color: 0xff0055,
    emissive: 0xff0044,
    emissiveIntensity: 1.8,
    roughness: 0.1,
    metalness: 0.9,
  });
  materials.push(hornEmissiveMaterial);

  const cyanCoreMaterial = new THREE.MeshStandardMaterial({
    color: 0x00f0ff,
    emissive: 0x00e1d9,
    emissiveIntensity: 1.5,
    roughness: 0.1,
    metalness: 0.8,
  });
  materials.push(cyanCoreMaterial);

  const goldTrimMaterial = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    roughness: 0.25,
    metalness: 0.85,
  });
  materials.push(goldTrimMaterial);

  const darkJointMaterial = new THREE.MeshStandardMaterial({
    color: 0x181824,
    roughness: 0.5,
    metalness: 0.6,
  });
  materials.push(darkJointMaterial);

  // 1. Pedestal Base / Docking Ring (At Ground Level Y = 0)
  const pedestalGroup = new THREE.Group();
  pedestalGroup.position.set(0, 0, 0);

  const baseDiskGeo = new THREE.CylinderGeometry(1.4, 1.6, 0.15, 32);
  const baseDiskMat = new THREE.MeshStandardMaterial({
    color: 0x0d0d18,
    roughness: 0.4,
    metalness: 0.8,
  });
  materials.push(baseDiskMat);
  const baseDisk = new THREE.Mesh(baseDiskGeo, baseDiskMat);
  baseDisk.position.y = 0.075;
  baseDisk.receiveShadow = true;
  pedestalGroup.add(baseDisk);

  // Concentric holographic rings
  const ringGeo1 = new THREE.TorusGeometry(1.2, 0.02, 16, 64);
  const ringMat1 = new THREE.MeshStandardMaterial({
    color: 0xff2d78,
    emissive: 0xff2d78,
    emissiveIntensity: 1.2,
    roughness: 0.2,
  });
  materials.push(ringMat1);
  const haloRing1 = new THREE.Mesh(ringGeo1, ringMat1);
  haloRing1.rotation.x = Math.PI / 2;
  haloRing1.position.y = 0.16;
  pedestalGroup.add(haloRing1);

  const ringGeo2 = new THREE.TorusGeometry(0.85, 0.015, 16, 48);
  const haloRing2 = new THREE.Mesh(ringGeo2, cyanCoreMaterial);
  haloRing2.rotation.x = Math.PI / 2;
  haloRing2.position.y = 0.17;
  pedestalGroup.add(haloRing2);

  root.add(pedestalGroup);

  // 2. Character Body Container (Pivoted cleanly)
  const characterBody = new THREE.Group();
  characterBody.position.set(0, 0.35, 0);
  root.add(characterBody);

  // Legs / Cyber Boots
  const legGeo = new THREE.CylinderGeometry(0.12, 0.09, 1.1, 16);
  
  const leftLeg = new THREE.Mesh(legGeo, crimsonSuitMaterial);
  leftLeg.position.set(-0.24, 0.65, 0);
  leftLeg.castShadow = true;
  characterBody.add(leftLeg);

  const rightLeg = new THREE.Mesh(legGeo, crimsonSuitMaterial);
  rightLeg.position.set(0.24, 0.65, 0);
  rightLeg.castShadow = true;
  characterBody.add(rightLeg);

  // Thigh & Knee Armor Accents
  const kneeGeo = new THREE.SphereGeometry(0.12, 16, 16);
  const leftKnee = new THREE.Mesh(kneeGeo, whiteSuitAccentMaterial);
  leftKnee.position.set(-0.24, 0.72, 0.04);
  characterBody.add(leftKnee);

  const rightKnee = new THREE.Mesh(kneeGeo, whiteSuitAccentMaterial);
  rightKnee.position.set(0.24, 0.72, 0.04);
  characterBody.add(rightKnee);

  // Boots
  const bootGeo = new THREE.BoxGeometry(0.2, 0.25, 0.32);
  const leftBoot = new THREE.Mesh(bootGeo, darkJointMaterial);
  leftBoot.position.set(-0.24, 0.13, 0.04);
  characterBody.add(leftBoot);

  const rightBoot = new THREE.Mesh(bootGeo, darkJointMaterial);
  rightBoot.position.set(0.24, 0.13, 0.04);
  characterBody.add(rightBoot);

  // Pelvis & Slender Torso
  const pelvisGeo = new THREE.CylinderGeometry(0.3, 0.24, 0.35, 16);
  const pelvis = new THREE.Mesh(pelvisGeo, whiteSuitAccentMaterial);
  pelvis.position.set(0, 1.25, 0);
  characterBody.add(pelvis);

  // Torso / Pilot Suit Cockpit Vest
  const torsoGeo = new THREE.CylinderGeometry(0.34, 0.28, 0.75, 16);
  const torso = new THREE.Mesh(torsoGeo, crimsonSuitMaterial);
  torso.position.set(0, 1.7, 0);
  torso.castShadow = true;
  characterBody.add(torso);

  // Pilot Suit Chest Chevron & Core
  const chestPlateGeo = new THREE.BoxGeometry(0.38, 0.22, 0.16);
  const chestPlate = new THREE.Mesh(chestPlateGeo, whiteSuitAccentMaterial);
  chestPlate.position.set(0, 1.82, 0.16);
  characterBody.add(chestPlate);

  const chestCoreGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.06, 16);
  chestCoreGeo.rotateX(Math.PI / 2);
  const chestCore = new THREE.Mesh(chestCoreGeo, cyanCoreMaterial);
  chestCore.position.set(0, 1.82, 0.24);
  characterBody.add(chestCore);

  // Neck & Golden Collar
  const neckGeo = new THREE.CylinderGeometry(0.12, 0.14, 0.22, 16);
  const neck = new THREE.Mesh(neckGeo, skinMaterial);
  neck.position.set(0, 2.12, 0);
  characterBody.add(neck);

  const collarGeo = new THREE.TorusGeometry(0.18, 0.04, 12, 24);
  collarGeo.rotateX(Math.PI / 2);
  const collar = new THREE.Mesh(collarGeo, goldTrimMaterial);
  collar.position.set(0, 2.08, 0);
  characterBody.add(collar);

  // Arms & Shoulder Pauldrons
  const armGeo = new THREE.CylinderGeometry(0.08, 0.07, 0.9, 16);

  const leftArm = new THREE.Mesh(armGeo, crimsonSuitMaterial);
  leftArm.position.set(-0.48, 1.62, 0);
  leftArm.rotation.z = 0.18;
  characterBody.add(leftArm);

  const rightArm = new THREE.Mesh(armGeo, crimsonSuitMaterial);
  rightArm.position.set(0.48, 1.62, 0);
  rightArm.rotation.z = -0.18;
  characterBody.add(rightArm);

  const pauldronGeo = new THREE.SphereGeometry(0.16, 16, 16);
  pauldronGeo.scale(1.2, 0.8, 1.0);

  const leftPauldron = new THREE.Mesh(pauldronGeo, whiteSuitAccentMaterial);
  leftPauldron.position.set(-0.44, 1.95, 0);
  characterBody.add(leftPauldron);

  const rightPauldron = new THREE.Mesh(pauldronGeo, whiteSuitAccentMaterial);
  rightPauldron.position.set(0.44, 1.95, 0);
  characterBody.add(rightPauldron);

  // Hands (stylized delicate gloves)
  const handGeo = new THREE.SphereGeometry(0.07, 12, 12);
  const leftHand = new THREE.Mesh(handGeo, skinMaterial);
  leftHand.position.set(-0.56, 1.15, 0);
  characterBody.add(leftHand);

  const rightHand = new THREE.Mesh(handGeo, skinMaterial);
  rightHand.position.set(0.56, 1.15, 0);
  rightHand.castShadow = true;
  characterBody.add(rightHand);

  // 3. Head & Anime Face Group
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 2.4, 0);
  characterBody.add(headGroup);

  // Anime Face Silhouette (smooth chin taper)
  const faceGeo = new THREE.SphereGeometry(0.32, 24, 24);
  faceGeo.scale(0.85, 1.05, 0.95);
  const face = new THREE.Mesh(faceGeo, skinMaterial);
  headGroup.add(face);

  // Stylized Anime Eyes (Cyber Cyan & Eyeliner Red Accents)
  const eyeLinerGeo = new THREE.CapsuleGeometry(0.025, 0.08, 8, 8);
  eyeLinerGeo.rotateZ(Math.PI / 2);

  const redEyelinerMat = new THREE.MeshStandardMaterial({
    color: 0xff0044,
    roughness: 0.3,
  });
  materials.push(redEyelinerMat);

  const leftEyeliner = new THREE.Mesh(eyeLinerGeo, redEyelinerMat);
  leftEyeliner.position.set(-0.14, 0.05, 0.28);
  leftEyeliner.rotation.y = 0.25;
  headGroup.add(leftEyeliner);

  const rightEyeliner = new THREE.Mesh(eyeLinerGeo, redEyelinerMat);
  rightEyeliner.position.set(0.14, 0.05, 0.28);
  rightEyeliner.rotation.y = -0.25;
  headGroup.add(rightEyeliner);

  // Eye Iris (Glowing Turquoise-Cyan)
  const eyeIrisGeo = new THREE.SphereGeometry(0.05, 16, 16);
  eyeIrisGeo.scale(1, 1.4, 0.4);

  const leftEye = new THREE.Mesh(eyeIrisGeo, cyanCoreMaterial);
  leftEye.position.set(-0.13, 0.03, 0.29);
  headGroup.add(leftEye);

  const rightEye = new THREE.Mesh(eyeIrisGeo, cyanCoreMaterial);
  rightEye.position.set(0.13, 0.03, 0.29);
  headGroup.add(rightEye);

  // 4. Iconic Hair (002 Signature Long Pink Strands & Bangs)
  const hairGroup = new THREE.Group();
  headGroup.add(hairGroup);

  // Hair Base Cap
  const hairCapGeo = new THREE.SphereGeometry(0.35, 24, 24);
  hairCapGeo.scale(0.9, 1.08, 0.98);
  const hairCap = new THREE.Mesh(hairCapGeo, hairMaterial);
  hairCap.position.set(0, 0.04, -0.04);
  hairGroup.add(hairCap);

  // Front Bangs
  const bangGeo = new THREE.ConeGeometry(0.12, 0.45, 12);
  bangGeo.rotateX(-Math.PI * 0.9);

  const centerBang = new THREE.Mesh(bangGeo, hairMaterial);
  centerBang.position.set(0, 0.16, 0.26);
  centerBang.rotation.y = 0.1;
  hairGroup.add(centerBang);

  const leftBang = new THREE.Mesh(bangGeo, darkHairShadowMaterial);
  leftBang.position.set(-0.18, 0.14, 0.24);
  leftBang.rotation.z = -0.25;
  hairGroup.add(leftBang);

  const rightBang = new THREE.Mesh(bangGeo, darkHairShadowMaterial);
  rightBang.position.set(0.18, 0.14, 0.24);
  rightBang.rotation.z = 0.25;
  hairGroup.add(rightBang);

  // Long flowing back hair locks (extending down the spine)
  const longHairGeo = new THREE.CylinderGeometry(0.28, 0.42, 1.6, 16);
  longHairGeo.scale(1.2, 1.0, 0.45);
  const backHair = new THREE.Mesh(longHairGeo, hairMaterial);
  backHair.position.set(0, -0.65, -0.28);
  backHair.rotation.x = -0.12;
  hairGroup.add(backHair);

  // Side hair strands framing the face
  const sideHairGeo = new THREE.CylinderGeometry(0.06, 0.03, 1.2, 12);
  const leftSideHair = new THREE.Mesh(sideHairGeo, hairMaterial);
  leftSideHair.position.set(-0.32, -0.35, 0.08);
  leftSideHair.rotation.z = -0.08;
  hairGroup.add(leftSideHair);

  const rightSideHair = new THREE.Mesh(sideHairGeo, hairMaterial);
  rightSideHair.position.set(0.32, -0.35, 0.08);
  rightSideHair.rotation.z = 0.08;
  hairGroup.add(rightSideHair);

  // 5. SIGNATURE CRIMSON HORNS & NEURAL HEADBAND
  const headbandGeo = new THREE.TorusGeometry(0.34, 0.025, 12, 32, Math.PI);
  headbandGeo.rotateX(Math.PI / 2.3);
  const headband = new THREE.Mesh(headbandGeo, whiteSuitAccentMaterial);
  headband.position.set(0, 0.26, 0.06);
  headGroup.add(headband);

  // Horns (Curved Cones pointing upward and slightly back)
  const hornGeo = new THREE.ConeGeometry(0.045, 0.28, 16);
  hornGeo.translate(0, 0.14, 0); // pivot at base

  const leftHorn = new THREE.Mesh(hornGeo, hornEmissiveMaterial);
  leftHorn.position.set(-0.15, 0.28, 0.16);
  leftHorn.rotation.x = -0.35;
  leftHorn.rotation.z = -0.22;
  headGroup.add(leftHorn);

  const rightHorn = new THREE.Mesh(hornGeo, hornEmissiveMaterial);
  rightHorn.position.set(0.15, 0.28, 0.16);
  rightHorn.rotation.x = -0.35;
  rightHorn.rotation.z = 0.22;
  headGroup.add(rightHorn);

  // Floating companion bits / Cyber Halo Orbs
  const orbGroup = new THREE.Group();
  orbGroup.position.set(0, 2.0, 0);
  root.add(orbGroup);

  const orbGeo = new THREE.OctahedronGeometry(0.08, 0);
  const orbMat = new THREE.MeshStandardMaterial({
    color: 0xff2d78,
    emissive: 0xff0066,
    emissiveIntensity: 1.5,
    roughness: 0.1,
    metalness: 0.9,
  });
  materials.push(orbMat);

  const orb1 = new THREE.Mesh(orbGeo, orbMat);
  orb1.position.set(0.9, 0, 0);
  orbGroup.add(orb1);

  const orb2 = new THREE.Mesh(orbGeo, orbMat);
  orb2.position.set(-0.9, 0, 0);
  orbGroup.add(orb2);

  // Blinking State Machine
  let nextBlinkTime = 2.5;
  let blinkPhase: 'open' | 'closing' | 'opening' = 'open';
  let blinkProgress = 0;
  const BLINK_SPEED = 14; // Completes blink in ~0.14 seconds

  // Animation Update Function (Zero GC per frame)
  const update = (
    time: number, 
    delta: number, 
    controls: ProceduralAnimationControls = { idleEnabled: true, blinkEnabled: true, headMovementEnabled: true }
  ) => {
    const idleOn = controls.idleEnabled ?? true;
    const blinkOn = controls.blinkEnabled ?? true;
    const headOn = controls.headMovementEnabled ?? true;

    // 1. Idle Floating & Breathing
    if (idleOn) {
      const breath = Math.sin(time * 2.2) * 0.015;
      characterBody.position.y = 0.35 + Math.sin(time * 1.5) * 0.04;
      torso.scale.set(1 + breath * 0.5, 1 + breath, 1 + breath * 0.5);

      // Flowing hair wave
      backHair.rotation.x = -0.12 + Math.sin(time * 2.0) * 0.05;
      leftSideHair.rotation.z = -0.08 + Math.sin(time * 2.1) * 0.03;
      rightSideHair.rotation.z = 0.08 - Math.sin(time * 2.1) * 0.03;

      // Horns subtle energy pulse
      const hornPulse = 1.6 + Math.sin(time * 3.5) * 0.4;
      hornEmissiveMaterial.emissiveIntensity = hornPulse;
      cyanCoreMaterial.emissiveIntensity = 1.3 + Math.cos(time * 3.0) * 0.3;

      // Pedestal rings rotating
      haloRing1.rotation.z = time * 0.3;
      haloRing2.rotation.z = -time * 0.5;

      // Floating orbs revolving around 002
      orbGroup.rotation.y = time * 0.8;
      orb1.position.y = Math.sin(time * 2.5) * 0.15;
      orb2.position.y = -Math.sin(time * 2.5) * 0.15;
      orb1.rotation.x = time * 2.0;
      orb2.rotation.x = -time * 2.0;
    } else {
      // Damped return to neutral rest pose
      characterBody.position.y += (0.35 - characterBody.position.y) * 0.1;
      torso.scale.set(1, 1, 1);
      backHair.rotation.x += (-0.12 - backHair.rotation.x) * 0.1;
      leftSideHair.rotation.z += (-0.08 - leftSideHair.rotation.z) * 0.1;
      rightSideHair.rotation.z += (0.08 - rightSideHair.rotation.z) * 0.1;
    }

    // 2. Natural Head Movement (Tilted gaze and micro-turns)
    if (headOn) {
      const targetRotY = Math.sin(time * 0.8) * 0.08;
      const targetRotZ = Math.sin(time * 0.6) * 0.04;
      const targetRotX = Math.sin(time * 1.1) * 0.03;
      headGroup.rotation.y += (targetRotY - headGroup.rotation.y) * 0.08;
      headGroup.rotation.z += (targetRotZ - headGroup.rotation.z) * 0.08;
      headGroup.rotation.x += (targetRotX - headGroup.rotation.x) * 0.08;
    } else {
      headGroup.rotation.y += (0 - headGroup.rotation.y) * 0.1;
      headGroup.rotation.z += (0 - headGroup.rotation.z) * 0.1;
      headGroup.rotation.x += (0 - headGroup.rotation.x) * 0.1;
    }

    // 3. Natural Eye Blinking
    if (blinkOn) {
      if (time > nextBlinkTime && blinkPhase === 'open') {
        blinkPhase = 'closing';
        blinkProgress = 0;
      }

      if (blinkPhase === 'closing') {
        blinkProgress += delta * BLINK_SPEED;
        if (blinkProgress >= 1) {
          blinkProgress = 1;
          blinkPhase = 'opening';
        }
      } else if (blinkPhase === 'opening') {
        blinkProgress -= delta * BLINK_SPEED;
        if (blinkProgress <= 0) {
          blinkProgress = 0;
          blinkPhase = 'open';
          // Next blink between 2.8s and 4.8s, with 25% chance of quick double blink (0.25s)
          const isDoubleBlink = Math.random() < 0.25;
          nextBlinkTime = time + (isDoubleBlink ? 0.25 : 2.8 + Math.random() * 2.0);
        }
      }

      // Scale Y from 1.4 (fully open) down to 0.08 (closed slit)
      const openScale = 1.4;
      const closedScale = 0.08;
      const currentScaleY = openScale - blinkProgress * (openScale - closedScale);
      leftEye.scale.y = currentScaleY;
      rightEye.scale.y = currentScaleY;
    } else {
      leftEye.scale.y = 1.4;
      rightEye.scale.y = 1.4;
      blinkPhase = 'open';
      blinkProgress = 0;
    }
  };

  const resetPose = () => {
    characterBody.position.set(0, 0.35, 0);
    characterBody.rotation.set(0, 0, 0);
    torso.scale.set(1, 1, 1);
    headGroup.rotation.set(0, 0, 0);
    backHair.rotation.set(-0.12, 0, 0);
    leftSideHair.rotation.set(0, 0, -0.08);
    rightSideHair.rotation.set(0, 0, 0.08);
    leftEye.scale.set(1, 1.4, 0.4);
    rightEye.scale.set(1, 1.4, 0.4);
    haloRing1.rotation.set(Math.PI / 2, 0, 0);
    haloRing2.rotation.set(Math.PI / 2, 0, 0);
    orbGroup.rotation.set(0, 0, 0);
    nextBlinkTime = 2.0;
    blinkPhase = 'open';
    blinkProgress = 0;
  };

  const setWireframe = (wireframe: boolean) => {
    materials.forEach(mat => {
      if ('wireframe' in mat) {
        (mat as any).wireframe = wireframe;
      }
    });
  };

  return {
    group: root,
    update,
    resetPose,
    setWireframe,
  };
}
