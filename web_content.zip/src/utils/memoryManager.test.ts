import test from 'node:test';
import assert from 'node:assert/strict';
import {
  saveMemory,
  getMemory,
  updateMemory,
  deleteMemory,
  clearAllMemories,
  generateUrduGreeting,
  parseMemoryCommand,
} from './memoryManager.ts';
import { MemoryItem } from '../types/jarvis.ts';

test('Memory CRUD: save, get, update, and delete', () => {
  const initialMemories: MemoryItem[] = [];

  // 1. Save Memory
  const { updatedMemories, item } = saveMemory(initialMemories, 'name', 'Hafiz', 'Aapka Naam');
  assert.equal(updatedMemories.length, 1);
  assert.equal(item.key, 'name');
  assert.equal(item.value, 'Hafiz');

  // 2. Get Memory
  const retrieved = getMemory(updatedMemories, 'name');
  assert.equal(retrieved, 'Hafiz');

  // 3. Update Memory
  const { updatedMemories: modifiedList, item: updatedItem } = updateMemory(
    updatedMemories,
    'name',
    'Saib'
  );
  assert.equal(modifiedList.length, 1);
  assert.equal(updatedItem?.value, 'Saib');
  assert.equal(getMemory(modifiedList, 'name'), 'Saib');

  // 4. Delete Memory
  const { updatedMemories: afterDelete, deleted } = deleteMemory(modifiedList, 'name');
  assert.equal(afterDelete.length, 0);
  assert.equal(deleted?.key, 'name');
  assert.equal(getMemory(afterDelete, 'name'), null);

  // 5. Clear All
  const cleared = clearAllMemories();
  assert.equal(cleared.length, 0);
});

test('Context Awareness & Pakistani Urdu Greeting', () => {
  const memoriesWithName: MemoryItem[] = [
    { key: 'name', label: 'Aapka Naam', value: 'Hafiz', updatedAt: new Date().toISOString() },
  ];

  const greetingWithName = generateUrduGreeting(memoriesWithName);
  assert.ok(greetingWithName.includes('Assalam-o-Alaikum Hafiz'));
  assert.ok(!greetingWithName.includes('Namaste')); // Strictly no Hindi

  const memoriesWithoutName: MemoryItem[] = [];
  const greetingGeneric = generateUrduGreeting(memoriesWithoutName);
  assert.ok(greetingGeneric.includes('Assalam-o-Alaikum'));
});

test('Natural Language Memory Intent Parsing (Urdu & English)', () => {
  const memories: MemoryItem[] = [
    { key: 'name', label: 'Aapka Naam', value: 'Hafiz', updatedAt: new Date().toISOString() },
  ];

  // 1. Recall name
  const recallRes = parseMemoryCommand('What is my name?', memories);
  assert.ok(recallRes !== null);
  assert.equal(recallRes?.action.type, 'RECALL_MEMORY');
  assert.ok(recallRes?.speechText.includes('Hafiz'));

  // Urdu query for name
  const urduRecallRes = parseMemoryCommand('Mera naam kya hai?', memories);
  assert.ok(urduRecallRes !== null);
  assert.equal(urduRecallRes?.action.type, 'RECALL_MEMORY');
  assert.ok(urduRecallRes?.speechText.includes('Hafiz'));

  // 2. Store name
  const storeRes = parseMemoryCommand('My name is Hafiz, remember this', []);
  assert.ok(storeRes !== null);
  assert.equal(storeRes?.action.type, 'STORE_MEMORY');
  assert.equal(storeRes?.action.payload.key, 'name');
  assert.equal(storeRes?.action.payload.value, 'Hafiz');

  // 3. Update name
  const updateRes = parseMemoryCommand('My new name is Saib, update it', memories);
  assert.ok(updateRes !== null);
  assert.equal(updateRes?.action.type, 'UPDATE_MEMORY');
  assert.equal(updateRes?.action.payload.key, 'name');
  assert.equal(updateRes?.action.payload.value, 'Saib');

  // 4. Forget name
  const forgetRes = parseMemoryCommand('Forget my name', memories);
  assert.ok(forgetRes !== null);
  assert.equal(forgetRes?.action.type, 'DELETE_MEMORY');
  assert.equal(forgetRes?.action.payload.key, 'name');

  // 5. Clear all memory
  const clearRes = parseMemoryCommand('Clear memory', memories);
  assert.ok(clearRes !== null);
  assert.equal(clearRes?.action.type, 'CLEAR_MEMORY');
});
