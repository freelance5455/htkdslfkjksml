import { jsPDF } from 'jspdf';
import { Client, ExpenseItem, Invoice, StudioSettings } from '../types';
import { formatDateShort, formatINR } from './formatters';

function formatINRForPDF(amount: number): string {
  const isNegative = amount < 0;
  const abs = Math.round(Math.abs(amount));
  const formatted = new Intl.NumberFormat('en-IN').format(abs);
  return `${isNegative ? '-' : ''}Rs. ${formatted}`;
}

export function downloadInvoicePDF(
  invoice: Invoice,
  client: Client | undefined,
  settings: StudioSettings
): void {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const balance = Math.max(0, invoice.totalAmount - invoice.advancePaid);

  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageWidth, 128, 'F');

  doc.setFillColor(30, 41, 59);
  doc.roundedRect(48, 40, 40, 40, 8, 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  const initials = settings.companyName.slice(0, 2).toUpperCase();
  doc.text(initials, 68, 65, { align: 'center' });

  doc.setFontSize(20);
  doc.text(settings.companyName, 102, 56);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(203, 213, 225);
  doc.text(settings.companyAddress, 102, 74);
  doc.text(settings.adminEmail, 102, 90);

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.text('INVOICE', pageWidth - 48, 56, { align: 'right' });
  doc.setFontSize(10.5);
  doc.setTextColor(203, 213, 225);
  doc.text(`#${invoice.invoiceNumber}`, pageWidth - 48, 76, { align: 'right' });
  doc.text(`Date: ${formatDateShort(invoice.date)}`, pageWidth - 48, 94, { align: 'right' });

  // Bill To & Payment Status
  doc.setTextColor(100, 116, 139);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('BILL TO', 48, 170);
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(14);
  doc.text(client?.name ?? 'Client', 48, 190);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10.5);
  doc.setTextColor(71, 85, 105);
  if (client) {
    doc.text(`${client.city} · ${client.projectType}`, 48, 208);
    doc.text(`Phone: ${client.phone}`, 48, 224);
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(100, 116, 139);
  doc.text('PAYMENT STATUS', pageWidth - 48, 170, { align: 'right' });
  doc.setFontSize(13);
  if (balance === 0 || invoice.status === 'Paid') {
    doc.setTextColor(21, 128, 61);
    doc.text('PAID IN FULL', pageWidth - 48, 190, { align: 'right' });
  } else {
    doc.setTextColor(185, 28, 28);
    doc.text(`BALANCE DUE: ${formatINRForPDF(balance)}`, pageWidth - 48, 190, { align: 'right' });
  }
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(71, 85, 105);
  doc.text(`UPI ID: ${settings.upiId}`, pageWidth - 48, 208, { align: 'right' });

  // Table Header
  const tableTop = 265;
  doc.setFillColor(244, 245, 248);
  doc.roundedRect(48, tableTop, pageWidth - 96, 34, 6, 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(51, 65, 85);
  doc.text('DESCRIPTION', 64, tableTop + 21);
  doc.text('SERVICE TYPE', 300, tableTop + 21);
  doc.text('AMOUNT', pageWidth - 64, tableTop + 21, { align: 'right' });

  // Table Row
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text(invoice.projectName, 64, tableTop + 62);
  doc.setTextColor(71, 85, 105);
  doc.text(client?.projectType ?? 'Digital Services', 300, tableTop + 62);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(formatINRForPDF(invoice.totalAmount), pageWidth - 64, tableTop + 62, { align: 'right' });

  doc.setDrawColor(229, 231, 235);
  doc.line(48, tableTop + 84, pageWidth - 48, tableTop + 84);

  // Totals Summary
  const summaryX = pageWidth - 250;
  let y = tableTop + 118;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.setTextColor(71, 85, 105);
  doc.text('Subtotal', summaryX, y);
  doc.text(formatINRForPDF(invoice.totalAmount), pageWidth - 64, y, { align: 'right' });

  y += 24;
  doc.text('Advance / Paid', summaryX, y);
  doc.setTextColor(21, 128, 61);
  doc.text(`- ${formatINRForPDF(invoice.advancePaid)}`, pageWidth - 64, y, { align: 'right' });

  y += 18;
  doc.setDrawColor(203, 213, 225);
  doc.line(summaryX, y, pageWidth - 48, y);

  y += 26;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);
  doc.text('Balance Payable', summaryX, y);
  doc.setTextColor(balance === 0 ? 21 : 15, balance === 0 ? 128 : 23, balance === 0 ? 61 : 42);
  doc.text(formatINRForPDF(balance), pageWidth - 64, y, { align: 'right' });

  // Payment Instructions Box
  doc.setFillColor(244, 245, 248);
  doc.roundedRect(48, 520, pageWidth - 96, 56, 8, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42);
  doc.text('PAYMENT INSTRUCTIONS', 64, 542);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text(`${settings.invoiceNote} · UPI: ${settings.upiId}`, 64, 560);

  // Signature
  doc.setDrawColor(148, 163, 184);
  doc.line(pageWidth - 210, 665, pageWidth - 48, 665);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text(`${settings.adminName}, ${settings.companyName}`, pageWidth - 48, 684, {
    align: 'right',
  });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(100, 116, 139);
  doc.text(settings.adminTitle, pageWidth - 48, 700, { align: 'right' });

  doc.save(`${invoice.invoiceNumber}-${(client?.name ?? 'Client').replace(/\s+/g, '-')}.pdf`);
}

export function downloadInvoiceImage(
  invoice: Invoice,
  client: Client | undefined,
  settings: StudioSettings
): void {
  const canvas = document.createElement('canvas');
  const scale = 2;
  const w = 800;
  const h = 1040;
  canvas.width = w * scale;
  canvas.height = h * scale;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.scale(scale, scale);

  const balance = Math.max(0, invoice.totalAmount - invoice.advancePaid);

  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, w, h);

  ctx.fillStyle = '#0F172A';
  ctx.fillRect(0, 0, w, 190);

  ctx.fillStyle = '#1E293B';
  ctx.beginPath();
  ctx.roundRect(48, 48, 56, 56, 12);
  ctx.fill();

  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 20px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(settings.companyName.slice(0, 2).toUpperCase(), 76, 83);

  ctx.textAlign = 'left';
  ctx.font = 'bold 28px sans-serif';
  ctx.fillText(settings.companyName, 122, 72);
  ctx.fillStyle = '#CBD5E1';
  ctx.font = '14px sans-serif';
  ctx.fillText(settings.companyAddress, 122, 98);
  ctx.fillText(settings.adminEmail, 122, 120);

  ctx.textAlign = 'right';
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 28px sans-serif';
  ctx.fillText('INVOICE', w - 48, 76);
  ctx.fillStyle = '#CBD5E1';
  ctx.font = 'bold 16px sans-serif';
  ctx.fillText(`#${invoice.invoiceNumber}`, w - 48, 104);
  ctx.font = '14px sans-serif';
  ctx.fillText(`Date: ${formatDateShort(invoice.date)}`, w - 48, 128);

  ctx.textAlign = 'left';
  ctx.fillStyle = '#64748B';
  ctx.font = 'bold 12px sans-serif';
  ctx.fillText('BILL TO', 48, 245);
  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 22px sans-serif';
  ctx.fillText(client?.name ?? 'Client', 48, 276);
  ctx.fillStyle = '#475569';
  ctx.font = '15px sans-serif';
  if (client) {
    ctx.fillText(`${client.city} · ${client.projectType}`, 48, 302);
    ctx.fillText(client.phone, 48, 326);
  }

  ctx.textAlign = 'right';
  ctx.fillStyle = '#64748B';
  ctx.font = 'bold 12px sans-serif';
  ctx.fillText('STATUS', w - 48, 245);
  ctx.fillStyle = balance === 0 || invoice.status === 'Paid' ? '#15803D' : '#B91C1C';
  ctx.font = 'bold 20px sans-serif';
  ctx.fillText(balance === 0 || invoice.status === 'Paid' ? 'PAID IN FULL' : 'PAYMENT DUE', w - 48, 276);
  ctx.fillStyle = '#475569';
  ctx.font = '14px sans-serif';
  ctx.fillText(`UPI: ${settings.upiId}`, w - 48, 302);

  ctx.fillStyle = '#F4F5F8';
  ctx.fillRect(48, 375, w - 96, 48);
  ctx.textAlign = 'left';
  ctx.fillStyle = '#334155';
  ctx.font = 'bold 13px sans-serif';
  ctx.fillText('PROJECT / DELIVERABLE', 68, 404);
  ctx.textAlign = 'right';
  ctx.fillText('AMOUNT', w - 68, 404);

  ctx.textAlign = 'left';
  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 17px sans-serif';
  ctx.fillText(invoice.projectName, 68, 468);
  ctx.fillStyle = '#64748B';
  ctx.font = '14px sans-serif';
  ctx.fillText(`${client?.projectType ?? 'Agency'} Deliverable`, 68, 492);
  ctx.textAlign = 'right';
  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 18px sans-serif';
  ctx.fillText(formatINR(invoice.totalAmount), w - 68, 472);

  ctx.strokeStyle = '#E5E7EB';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(48, 526);
  ctx.lineTo(w - 48, 526);
  ctx.stroke();

  const sumX = w - 320;
  ctx.textAlign = 'left';
  ctx.fillStyle = '#475569';
  ctx.font = '16px sans-serif';
  ctx.fillText('Total Amount', sumX, 580);
  ctx.textAlign = 'right';
  ctx.fillText(formatINR(invoice.totalAmount), w - 68, 580);

  ctx.textAlign = 'left';
  ctx.fillText('Advance Paid', sumX, 616);
  ctx.textAlign = 'right';
  ctx.fillStyle = '#15803D';
  ctx.fillText(`- ${formatINR(invoice.advancePaid)}`, w - 68, 616);

  ctx.strokeStyle = '#CBD5E1';
  ctx.beginPath();
  ctx.moveTo(sumX, 640);
  ctx.lineTo(w - 48, 640);
  ctx.stroke();

  ctx.textAlign = 'left';
  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 20px sans-serif';
  ctx.fillText('Balance Due', sumX, 678);
  ctx.textAlign = 'right';
  ctx.fillStyle = balance === 0 ? '#15803D' : '#0F172A';
  ctx.fillText(formatINR(balance), w - 68, 678);

  ctx.fillStyle = '#F4F5F8';
  ctx.fillRect(48, 760, w - 96, 86);
  ctx.textAlign = 'left';
  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 13px sans-serif';
  ctx.fillText('PAYMENT INSTRUCTIONS', 68, 792);
  ctx.fillStyle = '#475569';
  ctx.font = '14px sans-serif';
  ctx.fillText(`${settings.invoiceNote} · UPI: ${settings.upiId}`, 68, 820);

  ctx.strokeStyle = '#94A3B8';
  ctx.beginPath();
  ctx.moveTo(w - 280, 935);
  ctx.lineTo(w - 48, 935);
  ctx.stroke();
  ctx.textAlign = 'right';
  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 16px sans-serif';
  ctx.fillText(`${settings.adminName}, ${settings.companyName}`, w - 48, 962);
  ctx.fillStyle = '#64748B';
  ctx.font = '13px sans-serif';
  ctx.fillText(settings.adminTitle, w - 48, 984);

  const link = document.createElement('a');
  link.download = `${invoice.invoiceNumber}.png`;
  link.href = canvas.toDataURL('image/png');
  link.click();
}

export function downloadFinancialReportPDF(params: {
  settings: StudioSettings;
  totalBilled: number;
  collectedAmount: number;
  pendingAmount: number;
  totalExpenses: number;
  netProfit: number;
  clients: Client[];
  expenses: ExpenseItem[];
}): void {
  const {
    settings,
    totalBilled,
    collectedAmount,
    pendingAmount,
    totalExpenses,
    netProfit,
    clients,
    expenses,
  } = params;

  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();

  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageWidth, 110, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(20);
  doc.text(`${settings.companyName} — Financial Report`, 44, 52);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(203, 213, 225);
  doc.text(
    `Prepared for ${settings.adminName} · ${new Date().toLocaleDateString('en-IN')} · ${settings.companyAddress}`,
    44,
    76
  );

  let y = 148;
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text('Revenue & Profit Summary', 44, y);

  const rows: [string, string][] = [
    ['Total Contract Revenue (Billed)', formatINRForPDF(totalBilled)],
    ['Amount Collected', formatINRForPDF(collectedAmount)],
    ['Pending Receivables', formatINRForPDF(pendingAmount)],
    ['Total Business Expenses', `- ${formatINRForPDF(totalExpenses)}`],
    ['Net Profit (Collected - Expenses)', formatINRForPDF(netProfit)],
  ];

  y += 18;
  rows.forEach(([label, val], idx) => {
    const rowY = y + idx * 26;
    if (idx === 4) {
      doc.setFillColor(244, 245, 248);
      doc.rect(44, rowY - 15, pageWidth - 88, 24, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(15, 23, 42);
    } else {
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(51, 65, 85);
    }
    doc.setFontSize(11);
    doc.text(label, 52, rowY);
    doc.text(val, pageWidth - 52, rowY, { align: 'right' });
  });

  y += rows.length * 26 + 30;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);
  doc.text('Client Ledger', 44, y);
  y += 20;

  if (clients.length === 0) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text('No clients recorded yet.', 52, y);
    y += 22;
  } else {
    clients.slice(0, 10).forEach((c, idx) => {
      const rowY = y + idx * 22;
      const pending = Math.max(0, c.totalAmount - c.paidAmount);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(30, 41, 59);
      doc.text(`${c.name} (${c.city} · ${c.projectType})`, 52, rowY);
      doc.text(
        `Total: ${formatINRForPDF(c.totalAmount)} | Paid: ${formatINRForPDF(c.paidAmount)} | Pending: ${formatINRForPDF(pending)}`,
        pageWidth - 52,
        rowY,
        { align: 'right' }
      );
    });
    y += Math.min(clients.length, 10) * 22;
  }

  y += 30;
  if (y < 720) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text('Expenses', 44, y);
    y += 20;
    if (expenses.length === 0) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(100, 116, 139);
      doc.text('No expenses recorded yet.', 52, y);
    } else {
      expenses.slice(0, 6).forEach((e, idx) => {
        const rowY = y + idx * 20;
        if (rowY > 780) return;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        doc.setTextColor(51, 65, 85);
        doc.text(`${e.title} (${e.category})`, 52, rowY);
        doc.text(formatINRForPDF(e.amount), pageWidth - 52, rowY, { align: 'right' });
      });
    }
  }

  doc.save(`${settings.companyName}-Financial-Report-${new Date().toISOString().split('T')[0]}.pdf`);
}
