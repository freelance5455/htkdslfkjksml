import type { Achievement } from '../types/achievements.ts';
import type { AppState } from '../types/index.ts';

export function calculatePlayerAchievements(
  playerId: string,
  state: AppState
): Achievement[] {
  // 1. Personal records across all categories
  const playerRecords = state.dailyRecords.filter((r) => r.playerId === playerId && r.trained);
  const maxStreakAllTime = playerRecords.length > 0 ? Math.max(...playerRecords.map((r) => r.bestStreak)) : 0;
  
  // 2. Weekly streaks & consistency
  // Count training days per week
  const daysPerSeason: Record<string, number> = {};
  for (const season of state.seasons) {
    const trainedDaysInSeason = new Set(
      state.dailyRecords
        .filter(
          (r) =>
            r.playerId === playerId &&
            r.trained &&
            r.localDate >= season.startDate &&
            r.localDate <= season.endDate
        )
        .map((r) => r.localDate)
    ).size;
    daysPerSeason[season.id] = trainedDaysInSeason;
  }

  const maxDaysInAWeek = Object.values(daysPerSeason).length > 0 ? Math.max(...Object.values(daysPerSeason)) : 0;

  // 3. Weekly titles & podiums
  let titles200g = 0;
  let titles500g = 0;
  let totalTitles = 0;
  let podiumCount = 0;

  for (const season of state.seasons) {
    if (season.snapshots) {
      for (const [catId, results] of Object.entries(season.snapshots)) {
        const pRes = results.find((r) => r.playerId === playerId);
        if (pRes) {
          if (pRes.isChampion) {
            totalTitles++;
            if (catId === 'cat-200g') titles200g++;
            if (catId === 'cat-500g') titles500g++;
          }
          if (pRes.rank <= 3) {
            podiumCount++;
          }
        }
      }
    }
  }

  // 4. Tricks created & validated
  const authoredTricks = state.tricks.filter((t) => t.authorId === playerId);
  let maxTrickExecutions = 0;
  for (const trick of state.tricks) {
    const execs = trick.executionsByPlayer[playerId] || 0;
    if (execs > maxTrickExecutions) {
      maxTrickExecutions = execs;
    }
  }

  const totalAttempts = state.attempts.filter((a) => a.playerId === playerId).length + playerRecords.length;
  const participatedSeasonsCount = Object.values(daysPerSeason).filter((days) => days > 0).length;

  const achievements: Achievement[] = [
    // --- RECORDES PESSOAIS ---
    {
      id: 'rec-5',
      title: 'Primeira Fagulha',
      description: 'Alcance uma sequência de 5 acertos consecutivos em qualquer categoria.',
      category: 'recorde',
      iconName: 'Zap',
      rarity: 'comum',
      isUnlocked: maxStreakAllTime >= 5,
      progress: {
        current: Math.min(5, maxStreakAllTime),
        max: 5,
        unit: 'acertos',
      },
    },
    {
      id: 'rec-10',
      title: 'Mira Cirúrgica',
      description: 'Alcance a marca de dois dígitos: 10 acertos consecutivos.',
      category: 'recorde',
      iconName: 'Target',
      rarity: 'raro',
      isUnlocked: maxStreakAllTime >= 10,
      progress: {
        current: Math.min(10, maxStreakAllTime),
        max: 10,
        unit: 'acertos',
      },
    },
    {
      id: 'rec-15',
      title: 'Mão de Ouro',
      description: 'Crave 15 acertos em linha reta sem falhar a base.',
      category: 'recorde',
      iconName: 'Award',
      rarity: 'epico',
      isUnlocked: maxStreakAllTime >= 15,
      progress: {
        current: Math.min(15, maxStreakAllTime),
        max: 15,
        unit: 'acertos',
      },
    },
    {
      id: 'rec-20',
      title: 'Lenda do Giro',
      description: 'Consiga uma sequência lendária de 20 ou mais acertos.',
      category: 'recorde',
      iconName: 'Crown',
      rarity: 'lendario',
      isUnlocked: maxStreakAllTime >= 20,
      progress: {
        current: Math.min(20, maxStreakAllTime),
        max: 20,
        unit: 'acertos',
      },
    },

    // --- CONSISTÊNCIA DE TREINO ---
    {
      id: 'con-triplo',
      title: 'Semana Ativa',
      description: 'Treine pelo menos 3 dias diferentes durante a mesma semana.',
      category: 'consistencia',
      iconName: 'Flame',
      rarity: 'comum',
      isUnlocked: maxDaysInAWeek >= 3,
      progress: {
        current: Math.min(3, maxDaysInAWeek),
        max: 3,
        unit: 'dias',
      },
    },
    {
      id: 'con-cinco',
      title: 'Guerreiro de Ferro',
      description: 'Mostre disciplina registrando treinos em 5 dias na mesma semana.',
      category: 'consistencia',
      iconName: 'Shield',
      rarity: 'raro',
      isUnlocked: maxDaysInAWeek >= 5,
      progress: {
        current: Math.min(5, maxDaysInAWeek),
        max: 5,
        unit: 'dias',
      },
    },
    {
      id: 'con-perfeita',
      title: 'Semana Perfeita',
      description: 'Complete treinos em todos os 7 dias de uma única temporada.',
      category: 'consistencia',
      iconName: 'Sparkles',
      rarity: 'lendario',
      isUnlocked: maxDaysInAWeek >= 7,
      progress: {
        current: Math.min(7, maxDaysInAWeek),
        max: 7,
        unit: 'dias',
      },
    },

    // --- VITÓRIAS E TÍTULOS ---
    {
      id: 'vit-200g',
      title: 'Mestre dos 200 g',
      description: 'Conquiste o troféu oficial de campeão da semana na categoria de 200 g.',
      category: 'vitorias',
      iconName: 'Trophy',
      rarity: 'raro',
      isUnlocked: titles200g >= 1,
      progress: {
        current: Math.min(1, titles200g),
        max: 1,
        unit: 'título',
      },
    },
    {
      id: 'vit-500g',
      title: 'Titã dos 500 g',
      description: 'Conquiste o título semanal na categoria pesada oficial de 500 g.',
      category: 'vitorias',
      iconName: 'Dumbbell',
      rarity: 'epico',
      isUnlocked: titles500g >= 1,
      progress: {
        current: Math.min(1, titles500g),
        max: 1,
        unit: 'título',
      },
    },
    {
      id: 'vit-bicampeao',
      title: 'Dinastia Garrafões',
      description: 'Acumule 2 ou mais títulos de campeão semanal ao longo da história.',
      category: 'vitorias',
      iconName: 'Medal',
      rarity: 'epico',
      isUnlocked: totalTitles >= 2,
      progress: {
        current: Math.min(2, totalTitles),
        max: 2,
        unit: 'títulos',
      },
    },
    {
      id: 'vit-podio',
      title: 'Lugar no Pódio',
      description: 'Termine uma semana entre os 3 melhores colocados de uma categoria.',
      category: 'vitorias',
      iconName: 'TrendingUp',
      rarity: 'comum',
      isUnlocked: podiumCount >= 1,
      progress: {
        current: Math.min(1, podiumCount),
        max: 1,
        unit: 'pódio',
      },
    },

    // --- PARTICIPAÇÃO E MANOBRAS ---
    {
      id: 'ger-estreia',
      title: 'Primeiro Arremesso',
      description: 'Registre seu primeiro lançamento ou treino no aplicativo.',
      category: 'geral',
      iconName: 'CheckCircle',
      rarity: 'comum',
      isUnlocked: totalAttempts >= 1,
      progress: {
        current: Math.min(1, totalAttempts),
        max: 1,
        unit: 'treino',
      },
    },
    {
      id: 'ger-criador',
      title: 'Arquiteto de Manobras',
      description: 'Crie e proponha uma nova manobra para o catálogo do grupo.',
      category: 'geral',
      iconName: 'BookOpen',
      rarity: 'raro',
      isUnlocked: authoredTricks.length >= 1,
      progress: {
        current: Math.min(1, authoredTricks.length),
        max: 1,
        unit: 'manobra',
      },
    },
    {
      id: 'ger-execucoes-5',
      title: 'Maestria Prática',
      description: 'Valide 5 acertos bem-sucedidos em uma mesma manobra.',
      category: 'geral',
      iconName: 'Star',
      rarity: 'raro',
      isUnlocked: maxTrickExecutions >= 5,
      progress: {
        current: Math.min(5, maxTrickExecutions),
        max: 5,
        unit: 'acertos',
      },
    },
    {
      id: 'ger-veterano',
      title: 'Veterano da Roda',
      description: 'Participe com treinos válidos em 2 ou mais temporadas diferentes.',
      category: 'geral',
      iconName: 'CalendarCheck',
      rarity: 'epico',
      isUnlocked: participatedSeasonsCount >= 2,
      progress: {
        current: Math.min(2, participatedSeasonsCount),
        max: 2,
        unit: 'temporadas',
      },
    },
  ];

  return achievements;
}
