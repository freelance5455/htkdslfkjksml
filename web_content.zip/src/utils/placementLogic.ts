import type { CefrBand, PlacementResult, PlacementSkillId } from '../types';

export interface PlacementMcqItem {
  id: string;
  skill: 'vocabulary' | 'sentences' | 'reading' | 'listening';
  band: CefrBand;
  promptEn: string;
  passageEn?: string;
  audioEn?: string;
  options: string[];
  correctIndex: number;
}

export interface PlacementWritingPrompt {
  id: string;
  promptEn: string;
  minWords: number;
  targetKeywords: string[];
}

export interface PlacementSpeakingPrompt {
  id: string;
  band: CefrBand;
  sentenceEn: string;
}

export const PLACEMENT_VOCAB_ITEMS: PlacementMcqItem[] = [
  {
    id: 'v1',
    skill: 'vocabulary',
    band: 'A1',
    promptEn: 'Choose the best word: "I usually drink a cup of ___ in the morning."',
    options: ['coffee', 'window', 'bicycle', 'mountain'],
    correctIndex: 0,
  },
  {
    id: 'v2',
    skill: 'vocabulary',
    band: 'B1',
    promptEn: 'What does "reliable" mean?',
    options: [
      'Very loud and noisy',
      'Can be trusted to work well or keep promises',
      'Easy to break',
      'Happening only once a year',
    ],
    correctIndex: 1,
  },
  {
    id: 'v3',
    skill: 'vocabulary',
    band: 'C1',
    promptEn: 'Choose the closest synonym for "mitigate":',
    options: ['exaggerate', 'alleviate', 'complicate', 'abandon'],
    correctIndex: 1,
  },
];

export const PLACEMENT_SENTENCE_ITEMS: PlacementMcqItem[] = [
  {
    id: 's1',
    skill: 'sentences',
    band: 'A2',
    promptEn: 'Complete the sentence: "She ___ to London last summer."',
    options: ['go', 'goes', 'went', 'going'],
    correctIndex: 2,
  },
  {
    id: 's2',
    skill: 'sentences',
    band: 'B1',
    promptEn: 'Choose the grammatically correct sentence:',
    options: [
      'I have lived here since five years.',
      'I have lived here for five years.',
      'I am live here for five years.',
      'I lived here since five years ago.',
    ],
    correctIndex: 1,
  },
  {
    id: 's3',
    skill: 'sentences',
    band: 'B2',
    promptEn: 'Complete: "Had I known about the traffic, I ___ earlier."',
    options: ['will leave', 'would leave', 'would have left', 'left'],
    correctIndex: 2,
  },
];

export const PLACEMENT_READING_ITEMS: PlacementMcqItem[] = [
  {
    id: 'r1',
    skill: 'reading',
    band: 'A2',
    passageEn:
      'Every Saturday morning, Maya rides her bike to the local market. She buys fresh vegetables and talks with the farmers before cooking lunch for her family.',
    promptEn: 'Why does Maya go to the local market on Saturday?',
    options: [
      'To sell bicycles',
      'To buy fresh vegetables for family lunch',
      'To attend a school class',
      'To meet her boss',
    ],
    correctIndex: 1,
  },
  {
    id: 'r2',
    skill: 'reading',
    band: 'B2',
    passageEn:
      'Remote work has reshaped modern cities. While commuters save hours each week and gain flexibility, small downtown cafés have had to adapt to quieter weekdays and busier neighborhood streets.',
    promptEn: 'What challenge did downtown cafés face due to remote work?',
    options: [
      'Coffee beans became unavailable',
      'Fewer customers visited downtown during weekdays',
      'Employees stopped drinking coffee',
      'Rent prices dropped to zero',
    ],
    correctIndex: 1,
  },
];

export const PLACEMENT_LISTENING_ITEMS: PlacementMcqItem[] = [
  {
    id: 'l1',
    skill: 'listening',
    band: 'A2',
    audioEn: 'The train to Manchester leaves from platform four at nine thirty.',
    promptEn: 'Listen carefully. When and where does the train leave?',
    options: [
      'Platform 4 at 9:30',
      'Platform 5 at 9:15',
      'Platform 4 at 8:30',
      'Platform 2 at 9:30',
    ],
    correctIndex: 0,
  },
  {
    id: 'l2',
    skill: 'listening',
    band: 'B2',
    audioEn:
      'Although the conference was postponed because of the storm, all workshops will still take place online tomorrow afternoon.',
    promptEn: 'What happened to the workshops?',
    options: [
      'They were permanently canceled',
      'They moved to next month in person',
      'They will happen online tomorrow afternoon',
      'Only morning workshops remain',
    ],
    correctIndex: 2,
  },
];

export const PLACEMENT_WRITING_PROMPT: PlacementWritingPrompt = {
  id: 'w1',
  promptEn:
    'Write 2–4 sentences in English about your daily routine or why you want to improve your English.',
  minWords: 12,
  targetKeywords: ['english', 'learn', 'practice', 'day', 'work', 'study', 'morning', 'because', 'improve', 'future', 'travel', 'goal'],
};

export const PLACEMENT_SPEAKING_PROMPTS: PlacementSpeakingPrompt[] = [
  {
    id: 'sp1',
    band: 'A2',
    sentenceEn: 'I enjoy learning English every day because it opens new opportunities.',
  },
  {
    id: 'sp2',
    band: 'B2',
    sentenceEn: 'Consistent daily practice helps learners speak clearly and confidently.',
  },
];

const BAND_THRESHOLDS: Array<{ band: CefrBand; min: number; max: number }> = [
  { band: 'A0', min: 0, max: 19 },
  { band: 'A1', min: 20, max: 34 },
  { band: 'A2', min: 35, max: 49 },
  { band: 'B1', min: 50, max: 64 },
  { band: 'B2', min: 65, max: 79 },
  { band: 'C1', min: 80, max: 91 },
  { band: 'C2', min: 92, max: 100 },
];

/**
 * Deterministic offline-ready rubric for scoring a short English writing sample (0–100).
 */
export function scoreWritingResponse(rawText: string): number {
  const clean = rawText.trim();
  if (!clean) return 0;

  const words = clean.match(/[A-Za-z]+(?:'[A-Za-z]+)?/g) || [];
  if (words.length < 3) return 15;

  const uniqueRatio = new Set(words.map((w) => w.toLowerCase())).size / words.length;
  const sentences = clean
    .split(/[.!?]+/)
    .map((s) => s.trim())
    .filter((s) => s.length >= 4);

  let score = 20;
  // Word length & richness
  score += Math.min(30, words.length * 1.4);
  // Multi-sentence structure
  score += Math.min(18, sentences.length * 6);
  // Lexical variety
  score += Math.min(14, Math.round(uniqueRatio * 18));
  // Punctuation & capitalization polish
  if (/^[A-Z]/.test(clean)) score += 6;
  if (/[.!?]$/.test(clean)) score += 5;
  // Connector bonus (because, although, however, and, while, when, so)
  if (/\b(because|although|however|while|when|therefore|since|which|that)\b/i.test(clean)) {
    score += 7;
  }

  return Math.max(0, Math.min(100, Math.round(score)));
}

/**
 * Computes exact CEFR level, progress inside current band, points needed to reach next band,
 * and weakest skills to focus on next.
 */
export function computePlacementResult(
  skillScores: Record<PlacementSkillId, number>,
  now = Date.now()
): PlacementResult {
  const skills: PlacementSkillId[] = [
    'vocabulary',
    'sentences',
    'reading',
    'writing',
    'listening',
    'speaking',
  ];

  const clamped: Record<PlacementSkillId, number> = {
    vocabulary: Math.max(0, Math.min(100, Math.round(skillScores.vocabulary || 0))),
    sentences: Math.max(0, Math.min(100, Math.round(skillScores.sentences || 0))),
    reading: Math.max(0, Math.min(100, Math.round(skillScores.reading || 0))),
    writing: Math.max(0, Math.min(100, Math.round(skillScores.writing || 0))),
    listening: Math.max(0, Math.min(100, Math.round(skillScores.listening || 0))),
    speaking: Math.max(0, Math.min(100, Math.round(skillScores.speaking || 0))),
  };

  const avg = Math.round(skills.reduce((acc, k) => acc + clamped[k], 0) / skills.length);

  const idx = BAND_THRESHOLDS.findIndex((b) => avg >= b.min && avg <= b.max);
  const currentBandInfo = BAND_THRESHOLDS[idx >= 0 ? idx : 0];
  const nextBandInfo = idx >= 0 && idx < BAND_THRESHOLDS.length - 1 ? BAND_THRESHOLDS[idx + 1] : null;

  const span = Math.max(1, currentBandInfo.max - currentBandInfo.min + 1);
  const progressInBandPct = nextBandInfo
    ? Math.max(0, Math.min(99, Math.round(((avg - currentBandInfo.min) / span) * 100)))
    : 100;

  const pointsToNext = nextBandInfo ? Math.max(1, nextBandInfo.min - avg) : 0;

  const weakestSkills = [...skills]
    .sort((a, b) => clamped[a] - clamped[b])
    .slice(0, 2);

  return {
    cefrBand: currentBandInfo.band,
    overallScore: avg,
    nextBand: nextBandInfo ? nextBandInfo.band : null,
    pointsToNext,
    progressInBandPct,
    skillScores: clamped,
    weakestSkills,
    completedAt: now,
  };
}
