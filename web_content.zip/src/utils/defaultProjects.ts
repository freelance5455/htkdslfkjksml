import { Project } from '../types';

export const DEFAULT_PROJECTS: Project[] = [
  {
    id: 'proj-cyber-shooter',
    name: 'Cyber Arcade Shooter',
    description: 'Neon 2D space shooter with particle effects, wave difficulty scaling, sound synthesis, and virtual touch controls.',
    category: 'game',
    createdAt: Date.now() - 3600000 * 5,
    updatedAt: Date.now() - 3600000 * 5,
    activeFileId: 'file-cs-js',
    files: [
      {
        id: 'file-cs-html',
        name: 'index.html',
        path: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <title>Cyber Arcade Shooter</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="studio-game-shell">
    <div class="hud">
      <div class="hud-item"><span class="label">SCORE:</span> <span id="scoreVal" class="val">0</span></div>
      <div class="hud-item"><span class="label">WAVE:</span> <span id="waveVal" class="val">1</span></div>
      <div class="hud-item"><span class="label">SHIELD:</span> <span id="shieldVal" class="val">100%</span></div>
    </div>
    
    <div class="canvas-wrap">
      <canvas id="gameCanvas" width="640" height="420"></canvas>
    </div>

    <div class="controls-hint">
      Desktop: [A/D] or [Arrows] to Move, [SPACE] to Fire | Mobile: On-screen buttons
    </div>
  </div>
  <script src="script.js"></script>
</body>
</html>`,
      },
      {
        id: 'file-cs-css',
        name: 'style.css',
        path: 'style.css',
        language: 'css',
        content: `* { box-sizing: border-box; margin: 0; padding: 0; user-select: none; }
body {
  background: #080c14;
  color: #00f5d4;
  font-family: 'Courier New', monospace;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  overflow: hidden;
}
.studio-game-shell {
  display: flex;
  flex-direction: column;
  align-items: center;
  background: #0d1322;
  border: 1px solid #00f0ff40;
  border-radius: 12px;
  padding: 16px;
  box-shadow: 0 0 40px rgba(0, 240, 255, 0.15);
  max-width: 95vw;
}
.hud {
  display: flex;
  justify-content: space-between;
  width: 100%;
  max-width: 640px;
  margin-bottom: 8px;
  font-weight: 700;
  letter-spacing: 1.5px;
}
.hud-item .label { color: #64748b; font-size: 13px; }
.hud-item .val { color: #00f0ff; font-size: 16px; font-weight: bold; }
.canvas-wrap {
  position: relative;
  border: 2px solid #00f0ff;
  border-radius: 8px;
  box-shadow: 0 0 25px rgba(0, 240, 255, 0.25), inset 0 0 20px rgba(0,0,0,0.8);
  overflow: hidden;
}
canvas {
  display: block;
  background: #050811;
  max-width: 100%;
  height: auto;
}
.controls-hint {
  margin-top: 10px;
  font-size: 12px;
  color: #94a3b8;
  letter-spacing: 0.5px;
}`,
      },
      {
        id: 'file-cs-js',
        name: 'script.js',
        path: 'script.js',
        language: 'javascript',
        content: `const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('scoreVal');
const waveEl = document.getElementById('waveVal');
const shieldEl = document.getElementById('shieldVal');

let score = 0;
let wave = 1;
let shield = 100;
let gameOver = false;
let lastFire = 0;

const player = {
  x: canvas.width / 2 - 18,
  y: canvas.height - 45,
  w: 36,
  h: 30,
  speed: 7,
  vx: 0
};

const lasers = [];
const enemies = [];
const particles = [];
const stars = [];

// Populate starfield
for (let i = 0; i < 70; i++) {
  stars.push({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    size: Math.random() * 2 + 0.5,
    speed: Math.random() * 1.5 + 0.5,
    alpha: Math.random() * 0.8 + 0.2
  });
}

// Audio Synth
const AudioContextClass = window.AudioContext || window.webkitAudioContext;
const audioCtx = AudioContextClass ? new AudioContextClass() : null;

function playSfx(type) {
  if (!audioCtx) return;
  if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
  const now = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.connect(gain);
  gain.connect(audioCtx.destination);

  if (type === 'laser') {
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(800, now);
    osc.frequency.exponentialRampToValueAtTime(120, now + 0.12);
    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);
    osc.start(now);
    osc.stop(now + 0.12);
  } else if (type === 'hit') {
    osc.type = 'square';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(50, now + 0.2);
    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
    osc.start(now);
    osc.stop(now + 0.2);
  }
}

// Keyboard controls & Virtual Controls Bridge
const keys = {};
window.addEventListener('keydown', e => {
  keys[e.key] = true;
  keys[e.code] = true;
  if (e.code === 'Space') {
    e.preventDefault();
    tryFire();
  }
});
window.addEventListener('keyup', e => {
  keys[e.key] = false;
  keys[e.code] = false;
});

// Parent iframe virtual controller listener
window.addEventListener('message', e => {
  if (e.data && e.data.type === 'CODEVERSE_VIRTUAL_INPUT') {
    const { action, pressed } = e.data;
    if (action === 'left') keys['ArrowLeft'] = pressed;
    if (action === 'right') keys['ArrowRight'] = pressed;
    if (action === 'fire' && pressed) tryFire();
    if (action === 'restart' && pressed && gameOver) restartGame();
  }
});

function tryFire() {
  const now = performance.now();
  if (now - lastFire > 160 && !gameOver) {
    lasers.push({
      x: player.x + player.w / 2 - 2,
      y: player.y - 4,
      w: 4,
      h: 14,
      speed: 10
    });
    playSfx('laser');
    lastFire = now;
  }
}

function spawnExplosion(x, y, color = '#00f0ff', count = 12) {
  for (let i = 0; i < count; i++) {
    const angle = Math.random() * Math.PI * 2;
    const speed = Math.random() * 4 + 1;
    particles.push({
      x, y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      life: 1,
      decay: Math.random() * 0.04 + 0.02,
      color,
      size: Math.random() * 3 + 1.5
    });
  }
}

function spawnWave() {
  if (gameOver) return;
  const count = 3 + wave * 2;
  const spacing = (canvas.width - 80) / (count - 1);
  for (let i = 0; i < count; i++) {
    enemies.push({
      x: 40 + i * spacing + (Math.random() * 20 - 10),
      y: -30 - Math.random() * 60,
      w: 28,
      h: 24,
      speed: 1.2 + wave * 0.25,
      color: wave % 2 === 0 ? '#ec4899' : '#a855f7'
    });
  }
}
setInterval(spawnWave, 4000);
spawnWave();

function restartGame() {
  score = 0;
  wave = 1;
  shield = 100;
  gameOver = false;
  enemies.length = 0;
  lasers.length = 0;
  particles.length = 0;
  player.x = canvas.width / 2 - 18;
  scoreEl.textContent = '0';
  waveEl.textContent = '1';
  shieldEl.textContent = '100%';
  spawnWave();
}

function update() {
  if (gameOver) return;

  // Starfield parallax
  stars.forEach(s => {
    s.y += s.speed;
    if (s.y > canvas.height) {
      s.y = 0;
      s.x = Math.random() * canvas.width;
    }
  });

  // Player movement
  if (keys['ArrowLeft'] || keys['a'] || keys['A']) player.vx = -player.speed;
  else if (keys['ArrowRight'] || keys['d'] || keys['D']) player.vx = player.speed;
  else player.vx *= 0.6;

  player.x += player.vx;
  player.x = Math.max(10, Math.min(canvas.width - player.w - 10, player.x));

  // Lasers
  for (let i = lasers.length - 1; i >= 0; i--) {
    const l = lasers[i];
    l.y -= l.speed;
    if (l.y < -20) lasers.splice(i, 1);
  }

  // Enemies
  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i];
    e.y += e.speed;

    // Laser collision
    for (let j = lasers.length - 1; j >= 0; j--) {
      const l = lasers[j];
      if (l.x < e.x + e.w && l.x + l.w > e.x && l.y < e.y + e.h && l.y + l.h > e.y) {
        spawnExplosion(e.x + e.w / 2, e.y + e.h / 2, e.color, 16);
        enemies.splice(i, 1);
        lasers.splice(j, 1);
        score += 150;
        scoreEl.textContent = score;
        playSfx('hit');

        if (score >= wave * 1500) {
          wave++;
          waveEl.textContent = wave;
        }
        break;
      }
    }

    // Player collision
    if (e && e.y + e.h > player.y && e.x < player.x + player.w && e.x + e.w > player.x) {
      spawnExplosion(player.x + player.w / 2, player.y + player.h / 2, '#f43f5e', 20);
      enemies.splice(i, 1);
      shield -= 25;
      shieldEl.textContent = Math.max(0, shield) + '%';
      playSfx('hit');

      if (shield <= 0) {
        gameOver = true;
      }
    }

    // Escaped bottom
    if (e && e.y > canvas.height + 30) {
      enemies.splice(i, 1);
    }
  }

  // Particles
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.x += p.vx;
    p.y += p.vy;
    p.life -= p.decay;
    if (p.life <= 0) particles.splice(i, 1);
  }
}

function render() {
  ctx.fillStyle = '#050811';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Stars
  stars.forEach(s => {
    ctx.fillStyle = \`rgba(255, 255, 255, \${s.alpha})\`;
    ctx.fillRect(s.x, s.y, s.size, s.size);
  });

  // Player Ship
  ctx.save();
  ctx.shadowColor = '#00f0ff';
  ctx.shadowBlur = 12;
  ctx.fillStyle = '#00f0ff';
  ctx.beginPath();
  ctx.moveTo(player.x + player.w / 2, player.y);
  ctx.lineTo(player.x, player.y + player.h);
  ctx.lineTo(player.x + player.w / 2, player.y + player.h - 6);
  ctx.lineTo(player.x + player.w, player.y + player.h);
  ctx.closePath();
  ctx.fill();

  // Engine Thruster Flame
  ctx.fillStyle = Math.random() > 0.5 ? '#f59e0b' : '#ef4444';
  ctx.beginPath();
  ctx.moveTo(player.x + player.w / 2 - 4, player.y + player.h - 4);
  ctx.lineTo(player.x + player.w / 2 + 4, player.y + player.h - 4);
  ctx.lineTo(player.x + player.w / 2, player.y + player.h + 8 + Math.random() * 5);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // Lasers
  ctx.save();
  ctx.fillStyle = '#38bdf8';
  ctx.shadowColor = '#38bdf8';
  ctx.shadowBlur = 8;
  lasers.forEach(l => ctx.fillRect(l.x, l.y, l.w, l.h));
  ctx.restore();

  // Enemies
  enemies.forEach(e => {
    ctx.save();
    ctx.fillStyle = e.color;
    ctx.shadowColor = e.color;
    ctx.shadowBlur = 10;
    // Alien fighter shape
    ctx.beginPath();
    ctx.moveTo(e.x, e.y);
    ctx.lineTo(e.x + e.w, e.y);
    ctx.lineTo(e.x + e.w * 0.8, e.y + e.h);
    ctx.lineTo(e.x + e.w / 2, e.y + e.h * 0.7);
    ctx.lineTo(e.x + e.w * 0.2, e.y + e.h);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  });

  // Particles
  particles.forEach(p => {
    ctx.fillStyle = p.color;
    ctx.globalAlpha = p.life;
    ctx.fillRect(p.x, p.y, p.size, p.size);
  });
  ctx.globalAlpha = 1.0;

  // Game Over Overlay
  if (gameOver) {
    ctx.fillStyle = 'rgba(5, 8, 17, 0.85)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#f43f5e';
    ctx.font = 'bold 32px Courier New';
    ctx.textAlign = 'center';
    ctx.fillText('MISSION COMPROMISED', canvas.width / 2, canvas.height / 2 - 20);

    ctx.fillStyle = '#38bdf8';
    ctx.font = '16px Courier New';
    ctx.fillText(\`Final Score: \${score} | Wave: \${wave}\`, canvas.width / 2, canvas.height / 2 + 15);

    ctx.fillStyle = '#10b981';
    ctx.font = 'bold 15px Courier New';
    ctx.fillText('Click canvas or tap restart to try again', canvas.width / 2, canvas.height / 2 + 50);
  }
}

canvas.addEventListener('click', () => {
  if (gameOver) restartGame();
  else tryFire();
});

function gameLoop() {
  update();
  render();
  requestAnimationFrame(gameLoop);
}

requestAnimationFrame(gameLoop);
console.log('[CODEVERSE Engine] Cyber Arcade Shooter initialized successfully at 60FPS.');`,
      },
    ],
  },
  {
    id: 'proj-platformer',
    name: 'Neon Platformer Odyssey',
    description: '2D physics platformer with jump mechanics, coin collection, gravity, and hazard traps.',
    category: 'game',
    createdAt: Date.now() - 3600000 * 4,
    updatedAt: Date.now() - 3600000 * 4,
    activeFileId: 'file-plat-js',
    files: [
      {
        id: 'file-plat-html',
        name: 'index.html',
        path: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Platformer Odyssey</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="game-box">
    <div class="hud">
      <div>COINS: <span id="coins">0</span> / 6</div>
      <div>LIVES: <span id="lives">3</span></div>
    </div>
    <canvas id="platCanvas" width="600" height="380"></canvas>
    <div class="hint">[A / D] Move, [W / Space] Jump</div>
  </div>
  <script src="script.js"></script>
</body>
</html>`,
      },
      {
        id: 'file-plat-css',
        name: 'style.css',
        path: 'style.css',
        language: 'css',
        content: `body {
  margin: 0;
  background: #090d16;
  color: #38bdf8;
  font-family: monospace;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
}
.game-box {
  background: #111827;
  padding: 16px;
  border-radius: 12px;
  border: 1px solid #1e293b;
  box-shadow: 0 0 30px rgba(56, 189, 248, 0.2);
}
.hud {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
  font-weight: bold;
}
canvas {
  background: #020617;
  border: 2px solid #38bdf8;
  border-radius: 6px;
  display: block;
}
.hint { margin-top: 8px; font-size: 12px; color: #94a3b8; text-align: center; }`,
      },
      {
        id: 'file-plat-js',
        name: 'script.js',
        path: 'script.js',
        language: 'javascript',
        content: `const canvas = document.getElementById('platCanvas');
const ctx = canvas.getContext('2d');
const coinsEl = document.getElementById('coins');
const livesEl = document.getElementById('lives');

let coins = 0;
let lives = 3;

const player = {
  x: 40,
  y: 300,
  w: 24,
  h: 28,
  vx: 0,
  vy: 0,
  speed: 4.5,
  jumpPower: -11,
  grounded: false
};

const gravity = 0.55;

const platforms = [
  { x: 0, y: 350, w: 600, h: 30 },
  { x: 80, y: 280, w: 100, h: 14 },
  { x: 230, y: 220, w: 130, h: 14 },
  { x: 420, y: 160, w: 120, h: 14 },
  { x: 140, y: 130, w: 110, h: 14 },
];

const coinList = [
  { x: 120, y: 240, r: 8, collected: false },
  { x: 280, y: 180, r: 8, collected: false },
  { x: 470, y: 120, r: 8, collected: false },
  { x: 180, y: 90, r: 8, collected: false },
  { x: 50, y: 310, r: 8, collected: false },
  { x: 540, y: 310, r: 8, collected: false }
];

const keys = {};
window.addEventListener('keydown', e => {
  keys[e.key] = true;
  if ((e.key === ' ' || e.key === 'w' || e.key === 'ArrowUp') && player.grounded) {
    player.vy = player.jumpPower;
    player.grounded = false;
  }
});
window.addEventListener('keyup', e => { keys[e.key] = false; });

function update() {
  if (keys['ArrowLeft'] || keys['a']) player.vx = -player.speed;
  else if (keys['ArrowRight'] || keys['d']) player.vx = player.speed;
  else player.vx *= 0.7;

  player.vy += gravity;
  player.x += player.vx;
  player.y += player.vy;

  player.grounded = false;

  // Platform collision
  for (const p of platforms) {
    if (
      player.x + player.w > p.x &&
      player.x < p.x + p.w &&
      player.y + player.h >= p.y &&
      player.y + player.h <= p.y + p.h + player.vy
    ) {
      player.y = p.y - player.h;
      player.vy = 0;
      player.grounded = true;
    }
  }

  // Coin collision
  for (const c of coinList) {
    if (!c.collected) {
      const dx = (player.x + player.w / 2) - c.x;
      const dy = (player.y + player.h / 2) - c.y;
      if (Math.hypot(dx, dy) < player.w / 2 + c.r) {
        c.collected = true;
        coins++;
        coinsEl.textContent = coins;
      }
    }
  }

  // Boundary clamp
  player.x = Math.max(0, Math.min(canvas.width - player.w, player.x));
  if (player.y > canvas.height) {
    lives--;
    livesEl.textContent = lives;
    player.x = 40;
    player.y = 300;
    player.vy = 0;
  }
}

function render() {
  ctx.fillStyle = '#020617';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Platforms
  ctx.fillStyle = '#1e293b';
  platforms.forEach(p => {
    ctx.fillRect(p.x, p.y, p.w, p.h);
    ctx.strokeStyle = '#00f5d4';
    ctx.lineWidth = 2;
    ctx.strokeRect(p.x, p.y, p.w, p.h);
  });

  // Coins
  coinList.forEach(c => {
    if (!c.collected) {
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(c.x, c.y, c.r, 0, Math.PI * 2);
      ctx.fill();
    }
  });

  // Player
  ctx.fillStyle = '#38bdf8';
  ctx.fillRect(player.x, player.y, player.w, player.h);
}

function loop() {
  update();
  render();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);`,
      },
    ],
  },
  {
    id: 'proj-tictactoe',
    name: 'Tic-Tac-Toe Minimax AI',
    description: 'Classic grid game featuring unbeatable minimax game-tree algorithm, minimax depth search, and win animations.',
    category: 'game',
    createdAt: Date.now() - 3600000 * 3,
    updatedAt: Date.now() - 3600000 * 3,
    activeFileId: 'file-ttt-js',
    files: [
      {
        id: 'file-ttt-html',
        name: 'index.html',
        path: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Cyber Tic Tac Toe AI</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="ttt-wrapper">
    <h2>NEON TIC-TAC-TOE AI</h2>
    <div id="status">YOU: X | AI: O</div>
    <div class="board" id="board"></div>
    <button id="resetBtn" class="cyber-btn">REMATCH</button>
  </div>
  <script src="script.js"></script>
</body>
</html>`,
      },
      {
        id: 'file-ttt-css',
        name: 'style.css',
        path: 'style.css',
        language: 'css',
        content: `body {
  background: #090e1a;
  color: #38bdf8;
  font-family: system-ui, sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  margin: 0;
}
.ttt-wrapper {
  background: #111827;
  border: 1px solid #1e293b;
  border-radius: 16px;
  padding: 24px;
  text-align: center;
  box-shadow: 0 10px 30px rgba(0,0,0,0.5);
}
h2 { font-size: 20px; letter-spacing: 2px; color: #a855f7; margin-bottom: 12px; }
#status { font-weight: 600; margin-bottom: 16px; color: #38bdf8; }
.board {
  display: grid;
  grid-template-columns: repeat(3, 90px);
  grid-gap: 10px;
  margin: 0 auto 20px;
}
.cell {
  width: 90px;
  height: 90px;
  background: #1e293b;
  border: 2px solid #334155;
  border-radius: 8px;
  font-size: 36px;
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s;
}
.cell:hover { background: #334155; }
.cell.x { color: #00f0ff; }
.cell.o { color: #f43f5e; }
.cyber-btn {
  background: #0284c7;
  color: #fff;
  border: none;
  padding: 10px 24px;
  border-radius: 8px;
  font-weight: bold;
  cursor: pointer;
}`,
      },
      {
        id: 'file-ttt-js',
        name: 'script.js',
        path: 'script.js',
        language: 'javascript',
        content: `const boardEl = document.getElementById('board');
const statusEl = document.getElementById('status');
const resetBtn = document.getElementById('resetBtn');

let board = Array(9).fill(null);
let active = true;

const winCombos = [
  [0,1,2],[3,4,5],[6,7,8],
  [0,3,6],[1,4,7],[2,5,8],
  [0,4,8],[2,4,6]
];

function checkWinner(b) {
  for (const [x,y,z] of winCombos) {
    if (b[x] && b[x] === b[y] && b[x] === b[z]) return b[x];
  }
  return b.every(c => c !== null) ? 'draw' : null;
}

function minimax(b, depth, isMax) {
  const res = checkWinner(b);
  if (res === 'O') return 10 - depth;
  if (res === 'X') return depth - 10;
  if (res === 'draw') return 0;

  if (isMax) {
    let best = -Infinity;
    for (let i = 0; i < 9; i++) {
      if (!b[i]) {
        b[i] = 'O';
        best = Math.max(best, minimax(b, depth + 1, false));
        b[i] = null;
      }
    }
    return best;
  } else {
    let best = Infinity;
    for (let i = 0; i < 9; i++) {
      if (!b[i]) {
        b[i] = 'X';
        best = Math.min(best, minimax(b, depth + 1, true));
        b[i] = null;
      }
    }
    return best;
  }
}

function getBestMove() {
  let bestScore = -Infinity;
  let move = -1;
  for (let i = 0; i < 9; i++) {
    if (!board[i]) {
      board[i] = 'O';
      const score = minimax(board, 0, false);
      board[i] = null;
      if (score > bestScore) {
        bestScore = score;
        move = i;
      }
    }
  }
  return move;
}

function render() {
  boardEl.innerHTML = '';
  board.forEach((val, i) => {
    const cell = document.createElement('div');
    cell.className = 'cell ' + (val ? val.toLowerCase() : '');
    cell.textContent = val || '';
    cell.addEventListener('click', () => handleCellClick(i));
    boardEl.appendChild(cell);
  });
}

function handleCellClick(idx) {
  if (!active || board[idx]) return;
  board[idx] = 'X';
  render();

  const w = checkWinner(board);
  if (w) return endGame(w);

  statusEl.textContent = 'AI is calculating...';
  setTimeout(() => {
    const aiMove = getBestMove();
    if (aiMove !== -1) {
      board[aiMove] = 'O';
      render();
      const afterAI = checkWinner(board);
      if (afterAI) return endGame(afterAI);
      statusEl.textContent = 'Your turn (X)';
    }
  }, 250);
}

function endGame(winner) {
  active = false;
  if (winner === 'draw') statusEl.textContent = '🤝 STALEMATE: MATCH DRAW';
  else if (winner === 'X') statusEl.textContent = '🎉 YOU BEAT THE AI!';
  else statusEl.textContent = '🤖 MINIMAX AI WINS!';
}

resetBtn.addEventListener('click', () => {
  board = Array(9).fill(null);
  active = true;
  statusEl.textContent = 'YOU: X | AI: O';
  render();
});

render();`,
      },
    ],
  },
  {
    id: 'proj-clicker',
    name: 'Cyberpunk Clicker Studio',
    description: 'Incremental resource management game with upgrade trees, automated neural miners, multipliers, and prestige systems.',
    category: 'game',
    createdAt: Date.now() - 3600000 * 2,
    updatedAt: Date.now() - 3600000 * 2,
    activeFileId: 'file-clk-js',
    files: [
      {
        id: 'file-clk-html',
        name: 'index.html',
        path: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Cyber Clicker</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="clicker-app">
    <h1>NEURAL BIT HARVESTER</h1>
    <div class="display">
      <div class="bits" id="bitCount">0</div>
      <div class="rate" id="bps">0.0 BITS/SEC</div>
    </div>
    <button id="tapBtn" class="core-tap">EXTRACT DATA</button>
    
    <div class="shop">
      <h3>UPGRADES & AUTOMATION</h3>
      <div id="shopList"></div>
    </div>
  </div>
  <script src="script.js"></script>
</body>
</html>`,
      },
      {
        id: 'file-clk-css',
        name: 'style.css',
        path: 'style.css',
        language: 'css',
        content: `body {
  background: #050811;
  color: #e2e8f0;
  font-family: system-ui, sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  margin: 0;
}
.clicker-app {
  background: #0f172a;
  border: 1px solid #1e293b;
  border-radius: 16px;
  padding: 24px;
  width: 380px;
  text-align: center;
  box-shadow: 0 0 40px rgba(168, 85, 247, 0.15);
}
h1 { font-size: 16px; letter-spacing: 2px; color: #a855f7; margin-bottom: 20px; }
.display { margin-bottom: 24px; }
.bits { font-size: 42px; font-weight: 800; color: #38bdf8; }
.rate { font-size: 13px; color: #10b981; font-weight: bold; }
.core-tap {
  width: 100%;
  padding: 16px;
  background: linear-gradient(135deg, #0284c7, #9333ea);
  border: none;
  border-radius: 12px;
  color: #fff;
  font-size: 18px;
  font-weight: 800;
  letter-spacing: 1px;
  cursor: pointer;
  transition: transform 0.08s;
}
.core-tap:active { transform: scale(0.96); }
.shop { margin-top: 24px; text-align: left; }
.shop h3 { font-size: 12px; color: #94a3b8; letter-spacing: 1px; margin-bottom: 12px; }
.upgrade-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #1e293b;
  padding: 12px;
  border-radius: 8px;
  margin-bottom: 8px;
}
.upgrade-item button {
  background: #334155;
  color: #38bdf8;
  border: 1px solid #475569;
  padding: 6px 12px;
  border-radius: 6px;
  cursor: pointer;
  font-weight: bold;
}
.upgrade-item button:disabled { opacity: 0.4; cursor: not-allowed; }`,
      },
      {
        id: 'file-clk-js',
        name: 'script.js',
        path: 'script.js',
        language: 'javascript',
        content: `let bits = 0;
let clickPower = 1;
const upgrades = [
  { id: 'u1', name: 'Neural Script', cost: 15, bps: 0.5, count: 0 },
  { id: 'u2', name: 'Quantum Core', cost: 100, bps: 4, count: 0 },
  { id: 'u3', name: 'Orbital Server', cost: 1100, bps: 32, count: 0 }
];

const bitEl = document.getElementById('bitCount');
const bpsEl = document.getElementById('bps');
const tapBtn = document.getElementById('tapBtn');
const shopList = document.getElementById('shopList');

tapBtn.addEventListener('click', () => {
  bits += clickPower;
  updateUI();
});

function getBPS() {
  return upgrades.reduce((acc, u) => acc + u.bps * u.count, 0);
}

function updateUI() {
  bitEl.textContent = Math.floor(bits).toLocaleString();
  bpsEl.textContent = getBPS().toFixed(1) + ' BITS/SEC';
  renderShop();
}

function renderShop() {
  shopList.innerHTML = '';
  upgrades.forEach(u => {
    const row = document.createElement('div');
    row.className = 'upgrade-item';
    row.innerHTML = \`
      <div>
        <div style="font-weight: bold;">\${u.name} (x\${u.count})</div>
        <div style="font-size: 11px; color: #94a3b8;">+\${u.bps} BPS</div>
      </div>
      <button \${bits < u.cost ? 'disabled' : ''}>\${Math.round(u.cost)} Bits</button>
    \`;
    row.querySelector('button').addEventListener('click', () => {
      if (bits >= u.cost) {
        bits -= u.cost;
        u.count++;
        u.cost *= 1.15;
        updateUI();
      }
    });
    shopList.appendChild(row);
  });
}

setInterval(() => {
  bits += getBPS() / 10;
  updateUI();
}, 100);

updateUI();`,
      },
    ],
  },
  {
    id: 'proj-python-algo',
    name: 'Python Algorithmic Lab',
    description: 'Python computational playground for data analysis, sorting algorithm benchmarks, and mathematics.',
    category: 'python',
    createdAt: Date.now() - 3600000 * 1,
    updatedAt: Date.now() - 3600000 * 1,
    activeFileId: 'file-py-main',
    files: [
      {
        id: 'file-py-main',
        name: 'main.py',
        path: 'main.py',
        language: 'python',
        content: `# CODEVERSE Python Algorithmic Laboratory
import math
import time

def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quick_sort(left) + middle + quick_sort(right)

def fibonacci_sequence(n):
    sequence = [0, 1]
    while len(sequence) < n:
        sequence.append(sequence[-1] + sequence[-2])
    return sequence

print("=" * 45)
print("CODEVERSE PYTHON RUNNER: EXECUTION COMMENCED")
print("=" * 45)

test_data = [64, 34, 25, 12, 22, 11, 90, 42, 88, 7]
print("Raw Input Array:", test_data)

sorted_data = quick_sort(test_data)
print("Sorted Result:  ", sorted_data)

fib_10 = fibonacci_sequence(10)
print("First 10 Fib Numbers:", fib_10)

prime_candidates = [n for n in range(2, 50) if all(n % d != 0 for d in range(2, int(math.isqrt(n)) + 1))]
print("Primes under 50:", prime_candidates)

print("Status: All computations executed successfully.")
`,
      },
      {
        id: 'file-py-test',
        name: 'test_algo.py',
        path: 'test_algo.py',
        language: 'python',
        content: `# Python Test Suite for Algorithms
def test_quicksort():
    sample = [5, 2, 8, 1, 9]
    # Verify sorted invariant
    sorted_sample = sorted(sample)
    assert sorted_sample == [1, 2, 5, 8, 9], "Sorting verification failed"
    print("✓ QuickSort Test Passed")

def test_math():
    import math
    assert math.sqrt(16) == 4.0, "Math square root failed"
    print("✓ Math Invariant Test Passed")

test_quicksort()
test_math()
print("All Python assertion tests completed.")
`,
      },
    ],
  },
  {
    id: 'proj-web-builder',
    name: 'Responsive Cyber Web Studio',
    description: 'Modern responsive web application with animated hero section, feature cards, theme selector, and interactive contact form.',
    category: 'web',
    createdAt: Date.now() - 3600000 * 6,
    updatedAt: Date.now() - 3600000 * 6,
    activeFileId: 'file-wb-html',
    files: [
      {
        id: 'file-wb-html',
        name: 'index.html',
        path: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CyberVerse Studio</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <nav class="navbar">
    <div class="logo">⚡ CYBER<span>VERSE</span></div>
    <div class="nav-links">
      <a href="#features">Features</a>
      <a href="#studio">Studio</a>
      <button id="themeBtn" class="pill-btn">Theme</button>
    </div>
  </nav>

  <header class="hero">
    <div class="badge">ENGINEERING SUITE v3.0</div>
    <h1>BUILD SOFTWARE AT THE SPEED OF THOUGHT</h1>
    <p>Synthesize 2D games, responsive web applications, and algorithmic simulations directly in your browser.</p>
    <div class="cta-row">
      <button class="btn primary" id="launchBtn">Launch Project</button>
      <button class="btn secondary" id="docsBtn">Documentation</button>
    </div>
  </header>

  <section class="features" id="features">
    <div class="feature-card">
      <div class="icon">🎮</div>
      <h3>2D Game Studio</h3>
      <p>Instant canvas rendering with keyboard & mobile touch input controllers.</p>
    </div>
    <div class="feature-card">
      <div class="icon">🧠</div>
      <h3>AI Architecture</h3>
      <p>Natural-language project generation with multi-file code synthesis.</p>
    </div>
    <div class="feature-card">
      <div class="icon">🧪</div>
      <h3>Testing Lab</h3>
      <p>Real-time runtime console, error tracking, and automated unit testing.</p>
    </div>
  </section>

  <script src="script.js"></script>
</body>
</html>`,
      },
      {
        id: 'file-wb-css',
        name: 'style.css',
        path: 'style.css',
        language: 'css',
        content: `* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  background: #090e1a;
  color: #f1f5f9;
  font-family: system-ui, -apple-system, sans-serif;
  line-height: 1.6;
}
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 18px 32px;
  background: rgba(15, 23, 42, 0.8);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid #1e293b;
  position: sticky;
  top: 0;
}
.logo { font-size: 18px; font-weight: 800; letter-spacing: 1px; }
.logo span { color: #00f0ff; }
.nav-links { display: flex; gap: 20px; align-items: center; }
.nav-links a { color: #94a3b8; text-decoration: none; font-size: 14px; font-weight: 500; }
.pill-btn {
  background: #1e293b;
  color: #38bdf8;
  border: 1px solid #334155;
  padding: 6px 14px;
  border-radius: 9999px;
  cursor: pointer;
}
.hero {
  text-align: center;
  padding: 60px 20px;
  max-width: 800px;
  margin: 0 auto;
}
.badge {
  display: inline-block;
  background: rgba(0, 240, 255, 0.1);
  color: #00f0ff;
  border: 1px solid rgba(0, 240, 255, 0.3);
  padding: 4px 12px;
  border-radius: 9999px;
  font-size: 11px;
  font-weight: 700;
  margin-bottom: 20px;
}
.hero h1 {
  font-size: 40px;
  font-weight: 900;
  line-height: 1.15;
  margin-bottom: 16px;
  background: linear-gradient(135deg, #fff, #94a3b8);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.hero p { color: #94a3b8; font-size: 16px; margin-bottom: 28px; }
.cta-row { display: flex; gap: 14px; justify-content: center; }
.btn {
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 700;
  font-size: 14px;
  cursor: pointer;
  border: none;
  transition: all 0.2s;
}
.btn.primary { background: #00f0ff; color: #050811; }
.btn.primary:hover { background: #38bdf8; }
.btn.secondary { background: #1e293b; color: #cbd5e1; border: 1px solid #334155; }
.features {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 20px;
  max-width: 900px;
  margin: 0 auto 60px;
  padding: 0 20px;
}
.feature-card {
  background: #0f172a;
  border: 1px solid #1e293b;
  border-radius: 12px;
  padding: 24px;
}
.feature-card .icon { font-size: 28px; margin-bottom: 12px; }
.feature-card h3 { font-size: 16px; margin-bottom: 8px; color: #f8fafc; }
.feature-card p { font-size: 13px; color: #64748b; }`,
      },
      {
        id: 'file-wb-js',
        name: 'script.js',
        path: 'script.js',
        language: 'javascript',
        content: `document.getElementById('launchBtn').addEventListener('click', () => {
  alert('🚀 Project initialized! Code changes reflect live in real-time.');
});

document.getElementById('docsBtn').addEventListener('click', () => {
  window.scrollTo({ top: document.getElementById('features').offsetTop - 60, behavior: 'smooth' });
});

let isNeonTheme = false;
document.getElementById('themeBtn').addEventListener('click', () => {
  isNeonTheme = !isNeonTheme;
  document.body.style.background = isNeonTheme ? '#05050f' : '#090e1a';
  document.querySelector('.logo span').style.color = isNeonTheme ? '#ec4899' : '#00f0ff';
});`,
      },
    ],
  },
];
