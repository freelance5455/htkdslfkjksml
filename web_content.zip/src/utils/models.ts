import { ModelInfo } from '../types/index.ts';

export const SUPPORTED_MODELS: ModelInfo[] = [
  // Gemini 3 Series
  {
    id: 'gemini-3.1-flash-lite',
    name: 'Gemini 3.1 Flash Lite',
    description: 'Model ultra kilat dengan latensi paling rendah & ketersediaan tinggi (Bebas antrean 503 & sangat patuh pada mode tanpa sensor).',
    category: 'Gemini 3 Series',
    badge: 'Rekomendasi Utama',
    contextWindowTokens: 1048576,
    recommended: true,
  },
  {
    id: 'gemini-3.8-flash',
    name: 'Gemini 3.8 Flash',
    description: 'Model flagship multimodal & reasoning tinggi Google AI Studio (Dapat mengalami lonjakan trafik saat server padat).',
    category: 'Gemini 3 Series',
    badge: 'Flagship',
    contextWindowTokens: 1048576,
    recommended: false,
  },
  {
    id: 'gemini-3.1-pro-preview',
    name: 'Gemini 3.1 Pro Preview',
    description: 'Penalaran kompleks, matematika rumit, analisis data mendalam, dan penulisan kode tingkat lanjut.',
    category: 'Gemini 3 Series',
    badge: 'Penalaran Pro',
    contextWindowTokens: 1048576,
    recommended: false,
  },

  // Google Gemma Models (Open Weights DeepMind - Minim Filter)
  {
    id: 'gemma-4-26b-a4b-it',
    name: 'Google Gemma 4 (26B-IT)',
    description: 'Model open-weights generasi terbaru dari Google DeepMind. Transparan, efisien, dan tanpa sensor ketat bawaan.',
    category: 'Google Gemma (Open Weights)',
    badge: 'Gemma 4 DeepMind',
    contextWindowTokens: 131072, // 128k
    recommended: false,
  },
  {
    id: 'gemma-4-31b-it',
    name: 'Google Gemma 4 (31B-IT)',
    description: 'Versi 31B parameter dari Google Gemma untuk penalaran bahasa alami tanpa sensor ketat.',
    category: 'Google Gemma (Open Weights)',
    badge: 'Gemma 31B',
    contextWindowTokens: 131072,
    recommended: false,
  },

  // Gemini 3.5 Generation
  {
    id: 'gemini-3.5-flash-lite',
    name: 'Gemini 3.5 Flash Lite',
    description: 'Generasi 3.5 Flash Lite dengan efisiensi tinggi dan latensi cepat.',
    category: 'Gemini 3.5 Series',
    badge: 'Gen 3.5 Lite',
    contextWindowTokens: 1048576,
    recommended: false,
  },
  {
    id: 'gemini-3.5-flash',
    name: 'Gemini 3.5 Flash',
    description: 'Generasi 3.5 Flash dengan pemahaman instruksi luas.',
    category: 'Gemini 3.5 Series',
    badge: 'Gen 3.5 Flash',
    contextWindowTokens: 1048576,
    recommended: false,
  },

  // Stable Production Aliases
  {
    id: 'gemini-flash-latest',
    name: 'Gemini Flash Latest',
    description: 'Versi produksi Flash paling mutakhir dan stabil yang selalu diperbarui otomatis oleh Google.',
    category: 'Versi Stabil Produksi',
    badge: 'Flash Latest',
    contextWindowTokens: 1048576,
    recommended: false,
  },
  {
    id: 'gemini-flash-lite-latest',
    name: 'Gemini Flash Lite Latest',
    description: 'Versi produksi Flash Lite paling mutakhir dan stabil untuk throughput tinggi.',
    category: 'Versi Stabil Produksi',
    badge: 'Lite Latest',
    contextWindowTokens: 1048576,
    recommended: false,
  },
  {
    id: 'gemini-pro-latest',
    name: 'Gemini Pro Latest',
    description: 'Versi produksi Pro paling mutakhir untuk tugas-tugas penalaran mendalam.',
    category: 'Versi Stabil Produksi',
    badge: 'Pro Latest',
    contextWindowTokens: 1048576,
    recommended: false,
  },
];

export const OPENROUTER_PRESET_MODELS = [
  {
    id: 'google/gemini-2.0-flash-exp:free',
    name: 'Google Gemini 2.0 Flash (OpenRouter Free)',
    description: 'Model Gemini gratis tanpa sensor melalui gateway OpenRouter.',
  },
  {
    id: 'meta-llama/llama-3.3-70b-instruct:free',
    name: 'Meta Llama 3.3 70B (OpenRouter Free)',
    description: 'Model Llama 3.3 70B open-source tanpa moderasi konten.',
  },
  {
    id: 'mistralai/mistral-nemo:free',
    name: 'Mistral Nemo (OpenRouter Free)',
    description: 'Model Mistral 12B yang sangat minim penyensoran.',
  },
  {
    id: 'deepseek/deepseek-r1:free',
    name: 'DeepSeek R1 (OpenRouter Free)',
    description: 'Model reasoning penalaran mendalam gratis via OpenRouter.',
  },
  {
    id: 'nousresearch/hermes-3-llama-3.1-405b',
    name: 'Hermes 3 Llama 405B (Uncensored Flagship)',
    description: 'Model raksasa 405B yang dilatih khusus tanpa penolakan (Zero-refusal).',
  },
];

export function getModelDisplayName(modelId: string): string {
  const found = SUPPORTED_MODELS.find((m) => m.id === modelId);
  if (found) return found.name;
  const orFound = OPENROUTER_PRESET_MODELS.find((m) => m.id === modelId);
  if (orFound) return orFound.name;
  if (modelId.startsWith('gemma')) return `Gemma (${modelId})`;
  if (modelId.includes('/')) return modelId.split('/')[1] || modelId;
  return modelId;
}

export function getModelContextLimit(modelId: string): number {
  const found = SUPPORTED_MODELS.find((m) => m.id === modelId);
  return found?.contextWindowTokens || 1048576;
}
