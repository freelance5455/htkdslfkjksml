import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getInitialEvents,
  getInitialReminders,
  addCalendarEvent,
  modifyCalendarEvent,
  deleteCalendarEvent,
  addReminderItem,
  modifyReminderItem,
  deleteReminderItem,
  checkUpcomingNotifications,
  parseLocalJarvisCommand,
  DEFAULT_CONTACTS,
  DEFAULT_APPS,
} from './jarvisEngine.ts';

test('Calendar CRUD: adding, modifying, and deleting events', () => {
  const initial = getInitialEvents();
  assert.equal(initial.length, 3);

  // 1. Add Event
  const { updatedEvents, newEvent } = addCalendarEvent(initial, {
    title: 'Avengers Tactical Briefing',
    startTime: '2026-10-22T17:00:00',
    location: 'Upstate Compound',
    priority: 'high',
    category: 'ops',
  });

  assert.equal(updatedEvents.length, 4);
  assert.equal(newEvent.title, 'Avengers Tactical Briefing');
  assert.ok(updatedEvents.some((e) => e.title === 'Avengers Tactical Briefing'));

  // 2. Modify Event
  const { updatedEvents: modifiedList, modifiedEvent } = modifyCalendarEvent(
    updatedEvents,
    'Avengers Tactical Briefing',
    { location: 'Wakanda Embassy' }
  );
  assert.ok(modifiedEvent !== null);
  assert.equal(modifiedEvent?.location, 'Wakanda Embassy');

  // 3. Delete Event
  const { updatedEvents: finalList, deletedEvent } = deleteCalendarEvent(
    modifiedList,
    'Avengers Tactical Briefing'
  );
  assert.equal(finalList.length, 3);
  assert.ok(deletedEvent !== null);
  assert.equal(deletedEvent?.title, 'Avengers Tactical Briefing');
});

test('Reminders CRUD: adding, completing, and deleting reminders', () => {
  const initial = getInitialReminders();
  assert.equal(initial.length, 3);

  // 1. Add Reminder
  const { updatedReminders, newReminder } = addReminderItem(initial, {
    title: 'Recalibrate repulsor gauntlets',
    dueTime: '2026-10-22T18:00:00',
    priority: 'urgent',
    category: 'Armor',
  });
  assert.equal(updatedReminders.length, 4);
  assert.equal(newReminder.title, 'Recalibrate repulsor gauntlets');
  assert.equal(newReminder.completed, false);

  // 2. Complete Reminder
  const { updatedReminders: completedList, modifiedReminder } = modifyReminderItem(
    updatedReminders,
    'repulsor gauntlets',
    { completed: true }
  );
  assert.ok(modifiedReminder !== null);
  assert.equal(modifiedReminder?.completed, true);

  // 3. Delete Reminder
  const { updatedReminders: finalList, deletedReminder } = deleteReminderItem(
    completedList,
    'repulsor gauntlets'
  );
  assert.equal(finalList.length, 3);
  assert.ok(deletedReminder !== null);
});

test('Notifications: identifies upcoming events and reminders due in window', () => {
  const base = new Date('2026-10-22T12:00:00Z');

  const events = [
    {
      id: 'e-due',
      title: 'Imminent Launch',
      startTime: '2026-10-22T12:10:00Z', // 10 mins away -> inside 15m window
      endTime: '2026-10-22T13:00:00Z',
      category: 'ops' as const,
      priority: 'high' as const,
      notified: false,
    },
    {
      id: 'e-far',
      title: 'Next Week Meeting',
      startTime: '2026-10-29T12:00:00Z',
      endTime: '2026-10-29T13:00:00Z',
      category: 'work' as const,
      priority: 'normal' as const,
      notified: false,
    },
  ];

  const reminders = [
    {
      id: 'r-due',
      title: 'Due soon',
      dueTime: '2026-10-22T12:05:00Z', // 5 mins away
      completed: false,
      priority: 'urgent' as const,
      category: 'General',
      notified: false,
    },
    {
      id: 'r-done',
      title: 'Already done',
      dueTime: '2026-10-22T12:05:00Z',
      completed: true,
      priority: 'urgent' as const,
      category: 'General',
      notified: false,
    },
  ];

  const { dueEvents, dueReminders } = checkUpcomingNotifications(events, reminders, base, 15);
  assert.equal(dueEvents.length, 1);
  assert.equal(dueEvents[0].id, 'e-due');
  assert.equal(dueReminders.length, 1);
  assert.equal(dueReminders[0].id, 'r-due');
});

test('Voice Command Intent Parser: handles calendar, calls, messages, and settings', () => {
  const context = {
    now: new Date('2026-10-22T12:00:00'),
    events: getInitialEvents(),
    reminders: getInitialReminders(),
    contacts: DEFAULT_CONTACTS,
    apps: DEFAULT_APPS,
  };

  // Schedule event
  const scheduleRes = parseLocalJarvisCommand('Schedule meeting with Wakanda Council tomorrow at 3 PM', context);
  assert.equal(scheduleRes.action.type, 'ADD_EVENT');
  assert.ok(scheduleRes.action.payload.title.toLowerCase().includes('wakanda'));

  // Reschedule
  const rescheduleRes = parseLocalJarvisCommand('Reschedule Stark Industries Board Review to 4 PM', context);
  assert.equal(rescheduleRes.action.type, 'MODIFY_EVENT');

  // Cancel event
  const cancelRes = parseLocalJarvisCommand('Cancel meeting with Pepper', context);
  assert.equal(cancelRes.action.type, 'DELETE_EVENT');

  // Add reminder
  const reminderRes = parseLocalJarvisCommand('Remind me to update firewalls in 30 minutes', context);
  assert.equal(reminderRes.action.type, 'ADD_REMINDER');

  // Phone Call
  const callRes = parseLocalJarvisCommand('Call Happy Hogan', context);
  assert.equal(callRes.action.type, 'MAKE_CALL');
  assert.equal(callRes.action.payload.contactName, 'Happy Hogan');
  assert.equal(callRes.action.payload.phoneNumber, '+1-310-555-0142');

  // Send Message
  const msgRes = parseLocalJarvisCommand('Text Pepper Potts saying I am en route', context);
  assert.equal(msgRes.action.type, 'SEND_MESSAGE');
  assert.equal(msgRes.action.payload.contactName, 'Pepper Potts');
  assert.equal(msgRes.action.payload.message, 'I am en route');

  // App launch
  const appRes = parseLocalJarvisCommand('Open Spotify', context);
  assert.equal(appRes.action.type, 'OPEN_APP');
  assert.equal(appRes.action.payload.app.name, 'Spotify');

  // Settings
  const torchRes = parseLocalJarvisCommand('Turn on flashlight', context);
  assert.equal(torchRes.action.type, 'TOGGLE_SETTING');
  assert.equal(torchRes.action.payload.setting, 'flashlight');
  assert.equal(torchRes.action.payload.value, true);

  // Briefing
  const briefRes = parseLocalJarvisCommand('Give me a daily briefing', context);
  assert.equal(briefRes.action.type, 'BRIEFING');
});
