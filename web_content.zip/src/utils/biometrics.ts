/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type BiometricMethod = 'faceid' | 'touchid' | 'pin';
export type ProtectedSection = 'wallet' | 'profile';

export interface BiometricSettings {
  enabled: boolean;
  method: BiometricMethod;
  pin: string;
  requireForWallet: boolean;
  requireForProfile: boolean;
  autoLockMinutes: number; // 0 means lock immediately upon leaving, >0 means lock after idle time
  lastUnlockedAt: Record<ProtectedSection, number | null>;
}

export const BIOMETRIC_STORAGE_KEY = 'taki_biometrics_settings_v1';
export const DEFAULT_PIN = '1234';

export const DEFAULT_BIOMETRIC_SETTINGS: BiometricSettings = {
  enabled: true,
  method: 'faceid',
  pin: DEFAULT_PIN,
  requireForWallet: true,
  requireForProfile: true,
  autoLockMinutes: 10,
  lastUnlockedAt: {
    wallet: null,
    profile: null,
  },
};

/**
 * Retrieve stored biometric settings or default fallback.
 */
export function getBiometricSettings(storage: Storage = localStorage): BiometricSettings {
  try {
    const raw = storage.getItem(BIOMETRIC_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_BIOMETRIC_SETTINGS };
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_BIOMETRIC_SETTINGS,
      ...parsed,
      lastUnlockedAt: {
        wallet: parsed.lastUnlockedAt?.wallet ?? null,
        profile: parsed.lastUnlockedAt?.profile ?? null,
      },
    };
  } catch {
    return { ...DEFAULT_BIOMETRIC_SETTINGS };
  }
}

/**
 * Persist biometric settings.
 */
export function saveBiometricSettings(
  settings: Partial<BiometricSettings>,
  storage: Storage = localStorage
): BiometricSettings {
  const current = getBiometricSettings(storage);
  const updated: BiometricSettings = {
    ...current,
    ...settings,
    lastUnlockedAt: {
      ...current.lastUnlockedAt,
      ...(settings.lastUnlockedAt || {}),
    },
  };
  try {
    storage.setItem(BIOMETRIC_STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to save biometric settings to storage:', e);
  }
  return updated;
}

/**
 * Check if a section requires authentication right now.
 */
export function isSectionLocked(
  section: ProtectedSection,
  settings: BiometricSettings = getBiometricSettings(),
  currentTime: number = Date.now()
): boolean {
  if (!settings.enabled) return false;

  const isRequired =
    section === 'wallet' ? settings.requireForWallet : settings.requireForProfile;
  if (!isRequired) return false;

  const lastUnlock = settings.lastUnlockedAt[section];
  if (!lastUnlock) return true;

  if (settings.autoLockMinutes <= 0) {
    return false; // manual lock only when autoLockMinutes is 0 or handled on navigate
  }

  const elapsedMs = currentTime - lastUnlock;
  const timeoutMs = settings.autoLockMinutes * 60 * 1000;
  return elapsedMs > timeoutMs;
}

/**
 * Mark a section as unlocked at the current timestamp.
 */
export function unlockSection(
  section: ProtectedSection,
  storage: Storage = localStorage,
  time: number = Date.now()
): BiometricSettings {
  const current = getBiometricSettings(storage);
  return saveBiometricSettings(
    {
      lastUnlockedAt: {
        ...current.lastUnlockedAt,
        [section]: time,
      },
    },
    storage
  );
}

/**
 * Explicitly lock one or all protected sections.
 */
export function lockSection(
  section?: ProtectedSection,
  storage: Storage = localStorage
): BiometricSettings {
  const current = getBiometricSettings(storage);
  if (section) {
    return saveBiometricSettings(
      {
        lastUnlockedAt: {
          ...current.lastUnlockedAt,
          [section]: null,
        },
      },
      storage
    );
  }

  return saveBiometricSettings(
    {
      lastUnlockedAt: {
        wallet: null,
        profile: null,
      },
    },
    storage
  );
}

/**
 * Pure PIN validation helper.
 */
export function verifyPin(inputPin: string, storedPin: string = DEFAULT_PIN): boolean {
  if (!inputPin || typeof inputPin !== 'string') return false;
  return inputPin.trim() === storedPin.trim();
}

/**
 * Test or simulate WebAuthn / biometric scan challenge.
 */
export async function performBiometricScan(method: BiometricMethod = 'faceid'): Promise<{
  success: boolean;
  methodUsed: BiometricMethod;
  error?: string;
}> {
  // Check if WebAuthn / platform authenticator is available in navigator
  if (
    typeof window !== 'undefined' &&
    window.PublicKeyCredential &&
    typeof window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === 'function'
  ) {
    try {
      const isAvailable = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      if (isAvailable && navigator.credentials) {
        // Platform authenticator is present (TouchID/FaceID/Windows Hello/Android Biometrics)
        // Simulate swift sensory scan verification
        await new Promise((res) => setTimeout(res, 600));
        return { success: true, methodUsed: method };
      }
    } catch {
      // Graceful fallback to software biometric scanner simulation
    }
  }

  // Fallback scanner simulation for environments without native WebAuthn hardware
  await new Promise((res) => setTimeout(res, 750));
  return { success: true, methodUsed: method };
}
