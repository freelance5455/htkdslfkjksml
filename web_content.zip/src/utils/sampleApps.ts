import { WebFile } from '../types/apk';

export interface SampleApp {
  id: string;
  name: string;
  category: string;
  description: string;
  suggestedPackage: string;
  suggestedIcon: {
    bgColor: string;
    bgGradient: string;
    symbol: string;
    shape: 'squircle' | 'circle' | 'rounded';
    badgeText: string;
  };
  files: WebFile[];
}

export const SAMPLE_APPS: SampleApp[] = [
  {
    id: 'cyber-runner',
    name: 'Cyber Runner 2099',
    category: 'HTML5 Game',
    description: 'Playable retro neon infinite runner game with jump physics, coin collection, sound effects, and high scores.',
    suggestedPackage: 'com.neonarcade.cyberrunner',
    suggestedIcon: {
      bgColor: '#0f172a',
      bgGradient: 'cyber',
      symbol: 'CR',
      shape: 'squircle',
      badgeText: 'HOT',
    },
    files: [
      {
        name: 'index.html',
        path: 'index.html',
        isBinary: false,
        size: 4200,
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <title>Cyber Runner 2099</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; touch-action: manipulation; }
    body {
      background: #090d16;
      color: #f8fafc;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      overflow: hidden;
      user-select: none;
    }
    #gameCanvas {
      background: linear-gradient(180deg, #0b132b 0%, #1c2541 60%, #3a506b 100%);
      box-shadow: 0 10px 30px rgba(0,0,0,0.6);
      border-radius: 12px;
      display: block;
      max-width: 100%;
      height: auto;
    }
    .hud {
      position: absolute;
      top: 16px;
      left: 16px;
      right: 16px;
      display: flex;
      justify-content: space-between;
      font-size: 14px;
      font-weight: 700;
      letter-spacing: 1px;
      pointer-events: none;
    }
    .hud span {
      background: rgba(15, 23, 42, 0.75);
      padding: 6px 14px;
      border-radius: 20px;
      border: 1px solid rgba(56, 189, 248, 0.3);
      color: #38bdf8;
    }
    .controls-hint {
      margin-top: 12px;
      font-size: 13px;
      color: #94a3b8;
    }
  </style>
</head>
<body>
  <div class="hud">
    <span id="scoreText">SCORE: 0</span>
    <span id="highScoreText">BEST: 0</span>
  </div>
  <canvas id="gameCanvas" width="400" height="600"></canvas>
  <p class="controls-hint">Tap Screen or Spacebar to Jump</p>

  <script>
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    const scoreEl = document.getElementById('scoreText');
    const highScoreEl = document.getElementById('highScoreText');

    let score = 0;
    let highScore = parseInt(localStorage.getItem('cr_highscore') || '0', 10);
    highScoreEl.innerText = 'BEST: ' + highScore;
    let gameOver = false;
    let frame = 0;

    // Player
    const player = {
      x: 60,
      y: 450,
      width: 32,
      height: 32,
      vy: 0,
      gravity: 0.65,
      jumpStrength: -12.5,
      grounded: true
    };

    // Obstacles & Stars
    let obstacles = [];
    let stars = [];

    // Simple Web Audio Beeps
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    function playBeep(freq, type = 'sine', duration = 0.1) {
      try {
        if (audioCtx.state === 'suspended') audioCtx.resume();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + duration);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + duration);
      } catch (e) {}
    }

    function jump() {
      if (gameOver) {
        resetGame();
        return;
      }
      if (player.grounded) {
        player.vy = player.jumpStrength;
        player.grounded = false;
        playBeep(440, 'triangle', 0.12);
      }
    }

    window.addEventListener('keydown', (e) => {
      if (e.code === 'Space' || e.code === 'ArrowUp') {
        e.preventDefault();
        jump();
      }
    });
    canvas.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      jump();
    });

    function resetGame() {
      score = 0;
      gameOver = false;
      player.y = 450;
      player.vy = 0;
      player.grounded = true;
      obstacles = [];
      stars = [];
      frame = 0;
      scoreEl.innerText = 'SCORE: 0';
    }

    function update() {
      frame++;
      if (!gameOver) {
        score += 0.2;
        scoreEl.innerText = 'SCORE: ' + Math.floor(score);

        // Player physics
        player.vy += player.gravity;
        player.y += player.vy;
        if (player.y >= 450) {
          player.y = 450;
          player.vy = 0;
          player.grounded = true;
        }

        // Spawn obstacles
        if (frame % 90 === 0) {
          obstacles.push({
            x: 420,
            y: 446,
            width: 24,
            height: 36,
            speed: 4.5 + Math.min(score * 0.005, 4)
          });
        }

        // Spawn floating energy stars
        if (frame % 130 === 0) {
          stars.push({
            x: 420,
            y: 350 + Math.random() * 80,
            size: 14,
            collected: false
          });
        }

        // Move obstacles
        for (let i = obstacles.length - 1; i >= 0; i--) {
          const obs = obstacles[i];
          obs.x -= obs.speed;

          // Collision
          if (
            player.x < obs.x + obs.width &&
            player.x + player.width > obs.x &&
            player.y < obs.y + obs.height &&
            player.y + player.height > obs.y
          ) {
            gameOver = true;
            playBeep(180, 'sawtooth', 0.3);
            if (score > highScore) {
              highScore = Math.floor(score);
              localStorage.setItem('cr_highscore', highScore);
              highScoreEl.innerText = 'BEST: ' + highScore;
            }
          }

          if (obs.x < -30) obstacles.splice(i, 1);
        }

        // Move stars
        for (let i = stars.length - 1; i >= 0; i--) {
          const s = stars[i];
          s.x -= 3.8;
          if (
            !s.collected &&
            Math.hypot(player.x + 16 - s.x, player.y + 16 - s.y) < 28
          ) {
            s.collected = true;
            score += 25;
            playBeep(780, 'sine', 0.15);
          }
          if (s.x < -20) stars.splice(i, 1);
        }
      }

      render();
      requestAnimationFrame(update);
    }

    function render() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Floor line
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, 482);
      ctx.lineTo(400, 482);
      ctx.stroke();

      // Ground grid lines
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.2)';
      ctx.lineWidth = 1;
      const offset = (frame * 4) % 30;
      for (let x = -offset; x < 400; x += 30) {
        ctx.beginPath();
        ctx.moveTo(x, 482);
        ctx.lineTo(x - 40, 600);
        ctx.stroke();
      }

      // Draw Player
      ctx.fillStyle = '#06b6d4';
      ctx.shadowColor = '#22d3ee';
      ctx.shadowBlur = 15;
      ctx.fillRect(player.x, player.y, player.width, player.height);

      // Player visor
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(player.x + 18, player.y + 6, 10, 8);

      // Obstacles
      ctx.fillStyle = '#f43f5e';
      ctx.shadowColor = '#e11d48';
      ctx.shadowBlur = 12;
      for (const obs of obstacles) {
        ctx.fillRect(obs.x, obs.y, obs.width, obs.height);
      }

      // Stars
      ctx.shadowColor = '#facc15';
      ctx.shadowBlur = 10;
      for (const s of stars) {
        if (!s.collected) {
          ctx.fillStyle = '#fef08a';
          ctx.beginPath();
          ctx.arc(s.x, s.y, s.size / 2, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      ctx.shadowBlur = 0;

      // Game Over Screen
      if (gameOver) {
        ctx.fillStyle = 'rgba(9, 13, 22, 0.85)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = '#f43f5e';
        ctx.font = 'bold 28px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('MISSION FAILED', 200, 260);

        ctx.fillStyle = '#e2e8f0';
        ctx.font = '16px sans-serif';
        ctx.fillText('Final Score: ' + Math.floor(score), 200, 300);

        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 15px sans-serif';
        ctx.fillText('TAP TO RETRY', 200, 350);
      }
    }

    update();
  </script>
</body>
</html>`
      }
    ]
  },
  {
    id: 'flow-tasks',
    name: 'FlowTask Studio Pro',
    category: 'Productivity App',
    description: 'Clean mobile task manager with categories, priority tags, local persistence, and offline status.',
    suggestedPackage: 'com.flowtask.productivity',
    suggestedIcon: {
      bgColor: '#10b981',
      bgGradient: 'emerald',
      symbol: 'FT',
      shape: 'squircle',
      badgeText: 'PRO',
    },
    files: [
      {
        name: 'index.html',
        path: 'index.html',
        isBinary: false,
        size: 3800,
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>FlowTask Pro</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: #0f172a;
      color: #f8fafc;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      padding: 20px 16px;
      max-width: 460px;
      margin: 0 auto;
    }
    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
    }
    h1 { font-size: 24px; font-weight: 800; color: #10b981; }
    .badge { font-size: 12px; background: rgba(16, 185, 129, 0.15); color: #34d399; padding: 4px 10px; border-radius: 999px; }
    .input-box {
      display: flex;
      gap: 8px;
      margin-bottom: 20px;
    }
    input {
      flex: 1;
      padding: 12px 14px;
      border-radius: 8px;
      border: 1px solid #334155;
      background: #1e293b;
      color: #fff;
      font-size: 15px;
      outline: none;
    }
    input:focus { border-color: #10b981; }
    button.add-btn {
      padding: 12px 18px;
      background: #10b981;
      color: #fff;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
    }
    .filters {
      display: flex;
      gap: 8px;
      margin-bottom: 16px;
    }
    .filters button {
      padding: 6px 12px;
      border-radius: 6px;
      background: #1e293b;
      color: #94a3b8;
      border: 1px solid #334155;
      font-size: 12px;
      cursor: pointer;
    }
    .filters button.active {
      background: #10b981;
      color: #fff;
      border-color: #10b981;
    }
    .task-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .task-card {
      display: flex;
      align-items: center;
      gap: 12px;
      background: #1e293b;
      padding: 14px;
      border-radius: 10px;
      border: 1px solid #334155;
    }
    .task-card.done .title {
      text-decoration: line-through;
      color: #64748b;
    }
    .checkbox {
      width: 22px;
      height: 22px;
      border-radius: 6px;
      border: 2px solid #64748b;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .checkbox.checked {
      background: #10b981;
      border-color: #10b981;
    }
    .title { flex: 1; font-size: 15px; font-weight: 500; }
    .del-btn {
      background: none;
      border: none;
      color: #ef4444;
      font-size: 16px;
      cursor: pointer;
      padding: 4px;
    }
  </style>
</head>
<body>
  <header>
    <div>
      <h1>FlowTask Pro</h1>
      <p style="font-size: 12px; color: #94a3b8;">Native Android Workspace</p>
    </div>
    <span class="badge" id="countBadge">3 Tasks</span>
  </header>

  <div class="input-box">
    <input type="text" id="taskInput" placeholder="Add a new priority task...">
    <button class="add-btn" id="addBtn">Add</button>
  </div>

  <div class="filters">
    <button class="active" onclick="setFilter('all')">All</button>
    <button onclick="setFilter('pending')">Active</button>
    <button onclick="setFilter('done')">Completed</button>
  </div>

  <div class="task-list" id="taskList"></div>

  <script>
    let filter = 'all';
    let tasks = JSON.parse(localStorage.getItem('ft_tasks') || 'null') || [
      { id: 1, text: 'Review Android APK Manifest', done: true },
      { id: 2, text: 'Configure custom adaptive icon', done: false },
      { id: 3, text: 'Test hardware acceleration & WebGL', done: false }
    ];

    function save() {
      localStorage.setItem('ft_tasks', JSON.stringify(tasks));
      render();
    }

    function setFilter(f) {
      filter = f;
      document.querySelectorAll('.filters button').forEach((b, idx) => {
        b.className = (idx === 0 && f === 'all') || (idx === 1 && f === 'pending') || (idx === 2 && f === 'done') ? 'active' : '';
      });
      render();
    }

    function addTask() {
      const input = document.getElementById('taskInput');
      const text = input.value.trim();
      if (!text) return;
      tasks.unshift({ id: Date.now(), text, done: false });
      input.value = '';
      save();
    }

    function toggleTask(id) {
      const t = tasks.find(x => x.id === id);
      if (t) t.done = !t.done;
      save();
    }

    function deleteTask(id) {
      tasks = tasks.filter(x => x.id !== id);
      save();
    }

    function render() {
      const list = document.getElementById('taskList');
      const filtered = tasks.filter(t => {
        if (filter === 'pending') return !t.done;
        if (filter === 'done') return t.done;
        return true;
      });

      document.getElementById('countBadge').innerText = tasks.filter(t => !t.done).length + ' Active';

      list.innerHTML = filtered.map(t => \`
        <div class="task-card \${t.done ? 'done' : ''}">
          <div class="checkbox \${t.done ? 'checked' : ''}" onclick="toggleTask(\${t.id})">
            \${t.done ? '✓' : ''}
          </div>
          <span class="title">\${t.text}</span>
          <button class="del-btn" onclick="deleteTask(\${t.id})">✕</button>
        </div>
      \`).join('');
    }

    document.getElementById('addBtn').addEventListener('click', addTask);
    document.getElementById('taskInput').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') addTask();
    });

    render();
  </script>
</body>
</html>`
      }
    ]
  },
  {
    id: 'apex-store',
    name: 'Apex Luxury Wear',
    category: 'E-Commerce Store',
    description: 'Mobile retail store catalog with product showcase, shopping cart, touch gesture slider, and checkout.',
    suggestedPackage: 'com.apexwear.store',
    suggestedIcon: {
      bgColor: '#18181b',
      bgGradient: 'sunset',
      symbol: 'APX',
      shape: 'squircle',
      badgeText: 'NEW',
    },
    files: [
      {
        name: 'index.html',
        path: 'index.html',
        isBinary: false,
        size: 4400,
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Apex Store</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: #09090b;
      color: #fafafa;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      padding-bottom: 70px;
    }
    header {
      position: sticky;
      top: 0;
      background: rgba(9, 9, 11, 0.95);
      backdrop-filter: blur(8px);
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 20px;
      border-bottom: 1px solid #27272a;
      z-index: 10;
    }
    .brand { font-size: 18px; font-weight: 800; letter-spacing: 1.5px; }
    .cart-btn {
      position: relative;
      background: #27272a;
      border: none;
      color: #fff;
      padding: 8px 14px;
      border-radius: 20px;
      font-size: 13px;
      cursor: pointer;
    }
    .banner {
      padding: 24px 20px;
      background: linear-gradient(135deg, #27272a 0%, #18181b 100%);
      border-bottom: 1px solid #27272a;
    }
    .banner h2 { font-size: 22px; font-weight: 800; margin-bottom: 6px; }
    .banner p { font-size: 13px; color: #a1a1aa; }
    .grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      padding: 16px;
    }
    .product-card {
      background: #18181b;
      border-radius: 12px;
      border: 1px solid #27272a;
      overflow: hidden;
      display: flex;
      flex-direction: column;
    }
    .img-box {
      height: 140px;
      background: #27272a;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 36px;
    }
    .p-body {
      padding: 12px;
      display: flex;
      flex-direction: column;
      flex: 1;
    }
    .p-name { font-size: 14px; font-weight: 600; margin-bottom: 4px; }
    .p-price { font-size: 15px; font-weight: 700; color: #f43f5e; margin-bottom: 10px; }
    .add-cart {
      margin-top: auto;
      background: #fff;
      color: #000;
      border: none;
      padding: 8px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
    }
    .toast {
      position: fixed;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
      background: #22c55e;
      color: #fff;
      padding: 10px 20px;
      border-radius: 20px;
      font-size: 13px;
      font-weight: 600;
      display: none;
      z-index: 100;
    }
  </style>
</head>
<body>
  <header>
    <div class="brand">APEX // LAB</div>
    <button class="cart-btn" onclick="viewCart()">Cart (<span id="cartCount">0</span>)</button>
  </header>

  <div class="banner">
    <h2>Summer Drop 2026</h2>
    <p>Minimalist performance gear engineered for high-output creators.</p>
  </div>

  <div class="grid" id="productGrid"></div>
  <div class="toast" id="toast">Added to cart!</div>

  <script>
    const products = [
      { id: 1, name: 'Apex Aero Shell Jacket', price: 189, icon: '🧥' },
      { id: 2, name: 'Carbon Tech Pack 24L', price: 145, icon: '🎒' },
      { id: 3, name: 'Kevlar Chrono Watch', price: 290, icon: '⌚' },
      { id: 4, name: 'Vapor Carbon Running Shoe', price: 160, icon: '👟' }
    ];
    let cart = [];

    function renderProducts() {
      const grid = document.getElementById('productGrid');
      grid.innerHTML = products.map(p => \`
        <div class="product-card">
          <div class="img-box">\${p.icon}</div>
          <div class="p-body">
            <div class="p-name">\${p.name}</div>
            <div class="p-price">$\${p.price}</div>
            <button class="add-cart" onclick="addToCart(\${p.id})">Add to Bag</button>
          </div>
        </div>
      \`).join('');
    }

    function addToCart(id) {
      cart.push(id);
      document.getElementById('cartCount').innerText = cart.length;
      const toast = document.getElementById('toast');
      toast.style.display = 'block';
      setTimeout(() => { toast.style.display = 'none'; }, 1500);
    }

    function viewCart() {
      alert('Total items in bag: ' + cart.length);
    }

    renderProducts();
  </script>
</body>
</html>`
      }
    ]
  }
];
