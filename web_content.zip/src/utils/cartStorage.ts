import { CartItem, Product } from '../types';
import { PRODUCTS, getProductById } from '../data/products';

export const CART_STORAGE_KEY_V2 = 'ntix_cart_v2';
export const CART_STORAGE_KEY_LEGACY = 'ntix_user_cart';
export const CURRENT_CART_VERSION = 2;

export interface StoredCartEnvelope {
  version: number;
  items: Array<{
    productId?: string;
    product?: Partial<Product>;
    quantity: number;
    selectedSize?: string;
    selectedColor?: string;
  }>;
  updatedAt?: string;
}

export function validateCartItem(rawItem: any): CartItem | null {
  if (!rawItem || typeof rawItem !== 'object') return null;
  const rawId =
    (typeof rawItem.product === 'object' && rawItem.product?.id) ||
    rawItem.productId ||
    rawItem.id;
  if (!rawId || typeof rawId !== 'string') return null;

  const authoritativeProduct = getProductById(rawId);
  if (!authoritativeProduct) {
    return null;
  }

  const quantity = Math.max(1, Math.floor(Number(rawItem.quantity) || 1));
  let selectedSize = rawItem.selectedSize;
  if (!selectedSize && authoritativeProduct.sizes && authoritativeProduct.sizes.length > 0) {
    selectedSize = authoritativeProduct.sizes[0];
  }
  let selectedColor = rawItem.selectedColor;
  if (!selectedColor && authoritativeProduct.colors && authoritativeProduct.colors.length > 0) {
    selectedColor = authoritativeProduct.colors[0]?.name;
  }

  return {
    product: authoritativeProduct,
    quantity,
    selectedSize,
    selectedColor,
  };
}

export function loadAndMigrateCart(): { items: CartItem[]; removedCount: number } {
  let rawData: string | null = null;
  try {
    rawData = localStorage.getItem(CART_STORAGE_KEY_V2);
    if (!rawData) {
      rawData = localStorage.getItem(CART_STORAGE_KEY_LEGACY);
    }
  } catch {
    // Storage access restricted or disabled
  }

  if (!rawData) {
    const defaultItems: CartItem[] = [
      { product: PRODUCTS[0], quantity: 1, selectedSize: 'UK 9', selectedColor: 'Dusty Rose' },
      { product: PRODUCTS[3], quantity: 1, selectedSize: 'Free Size (42mm)', selectedColor: 'Black' },
      { product: PRODUCTS[5], quantity: 1, selectedSize: '22 Liters', selectedColor: 'Carbon Black' },
    ];
    persistCart(defaultItems);
    return { items: defaultItems, removedCount: 0 };
  }

  try {
    const parsed = JSON.parse(rawData);
    let candidateList: any[] = [];
    if (Array.isArray(parsed)) {
      candidateList = parsed;
    } else if (parsed && typeof parsed === 'object' && Array.isArray(parsed.items)) {
      candidateList = parsed.items;
    }

    const validatedItems: CartItem[] = [];
    let removedCount = 0;

    for (const rawItem of candidateList) {
      const validItem = validateCartItem(rawItem);
      if (validItem) {
        const existingIdx = validatedItems.findIndex(
          (it) =>
            it.product.id === validItem.product.id &&
            it.selectedSize === validItem.selectedSize &&
            it.selectedColor === validItem.selectedColor
        );
        if (existingIdx >= 0) {
          validatedItems[existingIdx].quantity += validItem.quantity;
        } else {
          validatedItems.push(validItem);
        }
      } else {
        removedCount++;
      }
    }

    if (validatedItems.length === 0 && candidateList.length > 0) {
      const defaultItems: CartItem[] = [
        { product: PRODUCTS[0], quantity: 1, selectedSize: 'UK 9', selectedColor: 'Dusty Rose' },
        { product: PRODUCTS[3], quantity: 1, selectedSize: 'Free Size (42mm)', selectedColor: 'Black' },
      ];
      persistCart(defaultItems);
      return { items: defaultItems, removedCount };
    }

    persistCart(validatedItems);
    return { items: validatedItems, removedCount };
  } catch {
    const defaultItems: CartItem[] = [
      { product: PRODUCTS[0], quantity: 1, selectedSize: 'UK 9', selectedColor: 'Dusty Rose' },
      { product: PRODUCTS[3], quantity: 1, selectedSize: 'Free Size (42mm)', selectedColor: 'Black' },
    ];
    persistCart(defaultItems);
    return { items: defaultItems, removedCount: 0 };
  }
}

export function persistCart(items: CartItem[]): void {
  try {
    const v2Envelope: StoredCartEnvelope = {
      version: CURRENT_CART_VERSION,
      updatedAt: new Date().toISOString(),
      items: items.map((it) => ({
        productId: it.product.id,
        quantity: it.quantity,
        selectedSize: it.selectedSize,
        selectedColor: it.selectedColor,
        product: {
          id: it.product.id,
          name: it.product.name,
          price: it.product.price,
          images: it.product.images,
          category: it.product.category,
        },
      })),
    };
    localStorage.setItem(CART_STORAGE_KEY_V2, JSON.stringify(v2Envelope));
    localStorage.setItem(CART_STORAGE_KEY_LEGACY, JSON.stringify(items));
  } catch {
    // Ignore quota errors
  }
}
