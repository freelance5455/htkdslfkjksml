import { OfflineAction } from '../types/index.ts';
import {
  saveRecordToIndexedDB,
  getPendingRecordsFromIndexedDB,
  updateRecordStatusInIndexedDB,
  removeRecordFromIndexedDB,
} from './indexedDbSync.ts';
import { processOfflineQueue, removeOfflineAction, updateOfflineActionStatus } from './offlineQueue.ts';

export interface ServiceWorkerSyncEvent {
  type: 'started' | 'completed' | 'failed';
  syncedCount?: number;
  attendanceCount?: number;
  taskCount?: number;
  error?: string;
  timestamp: string;
}

type SyncEventListener = (event: ServiceWorkerSyncEvent) => void;
const syncEventListeners: Set<SyncEventListener> = new Set();

let swRegistration: ServiceWorkerRegistration | null = null;
let isServiceWorkerSupported = typeof window !== 'undefined' && 'serviceWorker' in navigator;

/**
 * Registers the FieldFlow offline service worker and sets up sync listeners.
 */
export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (!isServiceWorkerSupported) {
    console.info('Service Worker is not supported in this browser.');
    return null;
  }

  try {
    const reg = await navigator.serviceWorker.register('/sw.js', {
      scope: '/',
    });
    swRegistration = reg;

    // Listen for broadcast messages from the Service Worker
    navigator.serviceWorker.addEventListener('message', (event) => {
      const data = event.data;
      if (!data) return;

      if (data.type === 'SERVICE_WORKER_SYNC_STARTED') {
        notifySyncListeners({
          type: 'started',
          timestamp: new Date().toISOString(),
          attendanceCount: data.attendanceCount,
          taskCount: data.taskCount,
        });
      } else if (data.type === 'SERVICE_WORKER_SYNC_COMPLETED') {
        // Also update client memory queue
        if (Array.isArray(data.records)) {
          data.records.forEach((r: OfflineAction) => {
            updateOfflineActionStatus(r.id, 'synced');
            setTimeout(() => removeOfflineAction(r.id), 2000);
          });
        }

        notifySyncListeners({
          type: 'completed',
          syncedCount: data.syncedCount,
          attendanceCount: data.attendanceCount,
          taskCount: data.taskCount,
          timestamp: data.timestamp || new Date().toISOString(),
        });
      } else if (data.type === 'SERVICE_WORKER_SYNC_FAILED') {
        notifySyncListeners({
          type: 'failed',
          error: data.error,
          timestamp: new Date().toISOString(),
        });
      }
    });

    // Auto-sync whenever browser connectivity is restored
    window.addEventListener('online', () => {
      console.info('Browser online event: Triggering Service Worker offline data sync...');
      requestServiceWorkerSync();
    });

    return reg;
  } catch (err) {
    console.warn('Service worker registration failed:', err);
    return null;
  }
}

/**
 * Requests the Service Worker to perform a background sync.
 * Uses Background Sync API when available, and messages the Service Worker / triggers client sync.
 */
export async function requestServiceWorkerSync(): Promise<void> {
  if (!navigator.onLine) {
    return;
  }

  try {
    // 1. Try Browser Background Sync API
    if (swRegistration && 'sync' in swRegistration) {
      try {
        await (swRegistration as any).sync.register('fieldflow-offline-sync');
      } catch (e) {
        console.warn('Background sync registration error:', e);
      }
    }

    // 2. Message Service Worker controller directly
    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({ type: 'TRIGGER_SYNC' });
    }

    // 3. Fallback client-side queue processor for immediate local sync
    await processOfflineQueue();
  } catch (err) {
    console.warn('Error in requestServiceWorkerSync:', err);
    await processOfflineQueue();
  }
}

/**
 * Enqueues a record into IndexedDB and requests Background Sync.
 */
export async function registerOfflineRecord(action: OfflineAction): Promise<void> {
  // Save to persistent IndexedDB
  await saveRecordToIndexedDB(action);

  // If online, trigger sync immediately; if offline, register sync for when connectivity is restored
  if (navigator.onLine) {
    requestServiceWorkerSync();
  } else if (swRegistration && 'sync' in swRegistration) {
    try {
      await (swRegistration as any).sync.register('fieldflow-offline-sync');
    } catch {
      // ignore
    }
  }
}

function notifySyncListeners(event: ServiceWorkerSyncEvent) {
  syncEventListeners.forEach((fn) => fn(event));
}

export function subscribeServiceWorkerSync(listener: SyncEventListener): () => void {
  syncEventListeners.add(listener);
  return () => {
    syncEventListeners.delete(listener);
  };
}
