import { NavBarConfig, NavBarPosition, NavBarActiveIndicatorStyle, NavBarLabelMode } from "../types";

export const DEFAULT_NAVBAR_CONFIG: NavBarConfig = {
  position: "floating_dock",
  height: 64,
  widthPercent: 94,
  iconLabelScale: 1.0,
  labelMode: "always",
  borderRadius: 26,
  glassmorphism: true,
  opacity: 95,
  blur: 16,
  activeIndicatorStyle: "pill",
  showBadges: true,
};

export interface NavBarPositionMeta {
  id: NavBarPosition;
  name: string;
  badge: string;
  description: string;
  iconType: "bottom" | "floating" | "top" | "sidebar-left" | "sidebar-right";
}

export const NAVBAR_POSITIONS: NavBarPositionMeta[] = [
  {
    id: "floating_dock",
    name: "Yüzen Kart / Dok (Floating Dock)",
    badge: "Modern Standart",
    description: "Ekranın altından 12dp-18dp yukarıda askıda duran, mikro-gölgeli dinamik kapsül.",
    iconType: "floating",
  },
  {
    id: "bottom_fixed",
    name: "Alt Yapışık (Bottom Fixed)",
    badge: "Klasik Mobil",
    description: "Ekranın en altına sıfırlanmış, kenardan kenara uzanan tam genişlikli alt menü.",
    iconType: "bottom",
  },
  {
    id: "top_bar",
    name: "Üst Çubuk (Top Navigation)",
    badge: "Masaüstü / Hub",
    description: "Sayfa başlığının hemen altında veya üzerinde konumlanan yatay üst navigasyon barı.",
    iconType: "top",
  },
  {
    id: "sidebar_left",
    name: "Sol Kenar Çubuğu (Left Sidebar)",
    badge: "Tablet & Geniş Ekran",
    description: "Geniş ekranlar ve tabletler için sol kenara dikey yerleşen kompakt sütun menü.",
    iconType: "sidebar-left",
  },
  {
    id: "sidebar_right",
    name: "Sağ Kenar Çubuğu (Right Sidebar)",
    badge: "Tek El / Stylus",
    description: "Sağ elle veya kalemle kullanım için sağ kenara dikey yerleşen ergonomik bar.",
    iconType: "sidebar-right",
  },
];

export const ACTIVE_INDICATOR_OPTIONS: Array<{
  id: NavBarActiveIndicatorStyle;
  name: string;
  desc: string;
}> = [
  { id: "pill", name: "Parlak Arka Plan Hapı (Pill)", desc: "Vurgu renginde yumuşak mikro arka plan hapı" },
  { id: "underline", name: "Alt Çizgi (Underline)", desc: "Aktif sekmenin altına zarif renkli çizgi" },
  { id: "glow", name: "Neon Parıltı & Halka (Glow)", desc: "Çevreleyen neon ışıma ve gölge efekti" },
  { id: "scale_icon", name: "Büyüyen İkon (Scale)", desc: "Seçili ikona dinamik büyüme ve zıplama animasyonu" },
];

export const LABEL_MODE_OPTIONS: Array<{
  id: NavBarLabelMode;
  name: string;
  desc: string;
}> = [
  { id: "always", name: "Her Zaman Göster", desc: "Tüm sekmelerin alt metinleri açık" },
  { id: "active_only", name: "Sadece Aktif Sekmede", desc: "Yalnızca seçilen sekmede metin göster" },
  { id: "hidden", name: "Gizle (Sadece İkonlar)", desc: "Ultra minimalist yalnızca ikon görünümü" },
];

/**
 * 4. DİNAMİK LEYOUT & GÜVENLİK ALANI (SAFE AREA INSETS) HESAPLAMA MOTORU
 * Navigasyon çubuğunun konumu ve boyutuna göre ana sayfa ve tuval içeriklerine
 * dinamik padding hesaplar, içeriklerin menü altında kalmasını önler.
 */
export function computeLayoutSafePadding(
  config: NavBarConfig = DEFAULT_NAVBAR_CONFIG,
  scaleMultiplier: number = 1.0
): {
  paddingTop: number;
  paddingBottom: number;
  paddingLeft: number;
  paddingRight: number;
  inlineStyle: React.CSSProperties;
} {
  const scaledHeight = Math.round(config.height * scaleMultiplier);

  let paddingTop = 0;
  let paddingBottom = 0;
  let paddingLeft = 0;
  let paddingRight = 0;

  switch (config.position) {
    case "bottom_fixed":
      paddingBottom = scaledHeight + 16;
      break;
    case "floating_dock":
      paddingBottom = scaledHeight + 36;
      break;
    case "top_bar":
      paddingTop = scaledHeight + 16;
      paddingBottom = 24;
      break;
    case "sidebar_left":
      paddingLeft = Math.max(72, scaledHeight) + 16;
      paddingBottom = 24;
      break;
    case "sidebar_right":
      paddingRight = Math.max(72, scaledHeight) + 16;
      paddingBottom = 24;
      break;
  }

  return {
    paddingTop,
    paddingBottom,
    paddingLeft,
    paddingRight,
    inlineStyle: {
      paddingTop: paddingTop > 0 ? `${paddingTop}px` : undefined,
      paddingBottom: paddingBottom > 0 ? `${paddingBottom}px` : undefined,
      paddingLeft: paddingLeft > 0 ? `${paddingLeft}px` : undefined,
      paddingRight: paddingRight > 0 ? `${paddingRight}px` : undefined,
      transition: "padding 0.25s cubic-bezier(0.16, 1, 0.3, 1)",
    },
  };
}
