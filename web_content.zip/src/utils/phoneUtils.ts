/**
 * International Phone Formatting & Normalization Utility
 * Defaulting to Kenya (+254) with full E.164 compliance
 */

export interface CountryInfo {
  code: string; // e.g. 'KE'
  name: string;
  dialCode: string; // e.g. '+254'
  flag: string;
  formatPlaceholder: string;
}

export const SUPPORTED_COUNTRIES: CountryInfo[] = [
  { code: 'KE', name: 'Kenya', dialCode: '+254', flag: '🇰🇪', formatPlaceholder: '0712 345 678' },
  { code: 'UG', name: 'Uganda', dialCode: '+256', flag: '🇺🇬', formatPlaceholder: '0700 123 456' },
  { code: 'TZ', name: 'Tanzania', dialCode: '+255', flag: '🇹🇿', formatPlaceholder: '0712 345 678' },
  { code: 'RW', name: 'Rwanda', dialCode: '+250', flag: '🇷🇼', formatPlaceholder: '0788 123 456' },
  { code: 'UK', name: 'United Kingdom', dialCode: '+44', flag: '🇬🇧', formatPlaceholder: '07911 123456' },
  { code: 'US', name: 'United States', dialCode: '+1', flag: '🇺🇸', formatPlaceholder: '(555) 123-4567' },
];

/**
 * Normalizes any phone number into E.164 format (e.g. +254712345678)
 */
export function normalizePhoneToE164(input: string, defaultCountryCode = '+254'): string {
  if (!input) return '';
  const cleaned = input.trim().replace(/[\s\-\(\)\.]/g, '');

  if (cleaned.startsWith('+')) {
    return cleaned;
  }

  if (cleaned.startsWith('07') || cleaned.startsWith('01')) {
    return `+254${cleaned.slice(1)}`;
  }

  if (cleaned.startsWith('254')) {
    return `+${cleaned}`;
  }

  return `${defaultCountryCode}${cleaned.replace(/^0+/, '')}`;
}

/**
 * Validates whether a phone number is a valid Safaricom/Airtel Kenya or international number
 */
export function isValidPhoneNumber(input: string): boolean {
  if (!input) return false;
  const e164 = normalizePhoneToE164(input);
  // Kenya numbers must be +254 followed by 7XX or 1XX and 6 more digits (total 13 chars)
  if (e164.startsWith('+254')) {
    return /^\+254[17]\d{8}$/.test(e164);
  }
  return /^\+[1-9]\d{7,14}$/.test(e164);
}

/**
 * Pretty formats an E.164 number for UI display (e.g. "+254 712 345 678")
 */
export function formatPhoneForDisplay(phone: string): string {
  if (!phone) return '';
  const e164 = normalizePhoneToE164(phone);
  if (e164.startsWith('+254') && e164.length === 13) {
    return `+254 ${e164.slice(4, 7)} ${e164.slice(7, 10)} ${e164.slice(10)}`;
  }
  return e164;
}

/**
 * Extracts the 9-digit or 10-digit local format for Safaricom Daraja API (e.g. 254712345678)
 */
export function toDarajaPhoneFormat(phone: string): string {
  const e164 = normalizePhoneToE164(phone);
  return e164.replace('+', '');
}
