import JSZip from 'jszip';
import { FileItem } from '../types';

export function getFileLanguage(fileName: string): string {
  const ext = fileName.split('.').pop()?.toLowerCase() || '';
  switch (ext) {
    case 'html':
    case 'htm':
      return 'html';
    case 'css':
    case 'scss':
    case 'less':
      return 'css';
    case 'js':
    case 'jsx':
    case 'mjs':
      return 'javascript';
    case 'ts':
    case 'tsx':
      return 'typescript';
    case 'json':
      return 'json';
    case 'png':
    case 'jpg':
    case 'jpeg':
    case 'gif':
    case 'webp':
    case 'svg':
    case 'ico':
      return 'image';
    default:
      return 'plaintext';
  }
}

export function isImageFile(file: FileItem | null | undefined): boolean {
  if (!file) return false;
  if (file.content && file.content.startsWith('data:image/')) return true;
  const ext = file.name.split('.').pop()?.toLowerCase() || '';
  return ['png', 'jpg', 'jpeg', 'svg', 'webp', 'gif', 'ico'].includes(ext);
}

export function buildFileFolderPath(file: FileItem, allFiles: FileItem[]): string {
  const parts: string[] = [file.name];
  let currentParentId = file.parentId;

  while (currentParentId) {
    const parent = allFiles.find((f) => f.id === currentParentId);
    if (!parent) break;
    parts.unshift(parent.name);
    currentParentId = parent.parentId;
  }

  return parts.join('/');
}

export async function exportProjectZip(projectName: string, files: FileItem[]): Promise<void> {
  const zip = new JSZip();
  const folderMap: Record<string, JSZip> = {};

  // Sort: folders first so parent folders exist
  const sorted = [...files].sort((a, b) => {
    if (a.isFolder === b.isFolder) return 0;
    return a.isFolder ? -1 : 1;
  });

  for (const item of sorted) {
    if (item.isFolder) {
      const fullPath = buildFileFolderPath(item, files);
      folderMap[item.id] = zip.folder(fullPath) || zip;
    } else {
      const targetFolder = (item.parentId ? folderMap[item.parentId] : zip) || zip;
      if (item.content?.startsWith('data:image/')) {
        const base64Data = item.content.split(',')[1];
        if (base64Data) {
          targetFolder.file(item.name, base64Data, { base64: true });
        } else {
          targetFolder.file(item.name, item.content || '');
        }
      } else {
        targetFolder.file(item.name, item.content || '');
      }
    }
  }

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `${projectName || 'noxora_project'}.zip`;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}
