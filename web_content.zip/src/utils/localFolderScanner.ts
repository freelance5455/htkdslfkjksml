import type { ComicEntry, LibraryFolder } from '../types/comic';
import { isComicArchiveFileName, scanComicArchive } from './archiveEngine';
import {
  getOfflineArchiveBlob,
  loadComics,
  saveComic,
  saveFolder,
  saveOfflineArchive,
} from './libraryDb';

export function supportsDirectoryPicker(): boolean {
  return typeof window !== 'undefined' && 'showDirectoryPicker' in window;
}

function cleanDisplayTitle(fileName: string): string {
  return fileName
    .replace(/\.(cbz|cbr|zip|rar)$/i, '')
    .replace(/[_]+/g, ' ')
    .trim();
}

function makeComicId(folderId: string, relativePath: string): string {
  return `${folderId}::${relativePath}`;
}

export interface ScanProgress {
  folderName: string;
  processed: number;
  total: number;
  currentFile?: string;
}

interface DiscoveredHandleFile {
  file: File;
  handle: FileSystemFileHandle;
  relativePath: string;
}

async function collectFilesFromDirectoryHandle(
  dirHandle: FileSystemDirectoryHandle,
  prefix = '',
): Promise<DiscoveredHandleFile[]> {
  const results: DiscoveredHandleFile[] = [];
  const entries = (
    dirHandle as unknown as {
      values: () => AsyncIterable<FileSystemHandle>;
    }
  ).values();

  for await (const entry of entries) {
    if (entry.name.startsWith('.')) continue;
    const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.kind === 'directory') {
      const sub = await collectFilesFromDirectoryHandle(entry as FileSystemDirectoryHandle, rel);
      results.push(...sub);
    } else if (entry.kind === 'file' && isComicArchiveFileName(entry.name)) {
      const fh = entry as FileSystemFileHandle;
      const file = await fh.getFile();
      results.push({ file, handle: fh, relativePath: rel });
    }
  }
  return results;
}

export async function pickAndScanDirectoryHandle(
  onProgress?: (p: ScanProgress) => void,
): Promise<{ folder: LibraryFolder; comics: ComicEntry[] }> {
  const picker = (
    window as unknown as {
      showDirectoryPicker: (opts?: { mode?: 'read' | 'readwrite' }) => Promise<FileSystemDirectoryHandle>;
    }
  ).showDirectoryPicker;

  const dirHandle = await picker({ mode: 'read' });
  const folderId = `fs-${dirHandle.name}-${Date.now().toString(36)}`;
  return await scanDirectoryHandleIntoFolder(dirHandle, folderId, onProgress);
}

export async function rescanDirectoryFolder(
  folder: LibraryFolder,
  onProgress?: (p: ScanProgress) => void,
): Promise<{ folder: LibraryFolder; comics: ComicEntry[] }> {
  if (!folder.handle) {
    throw new Error('This folder does not have a live directory handle to re-scan.');
  }
  const permHandle = folder.handle as unknown as {
    queryPermission: (opts: { mode: 'read' }) => Promise<'granted' | 'denied' | 'prompt'>;
    requestPermission: (opts: { mode: 'read' }) => Promise<'granted' | 'denied' | 'prompt'>;
  };
  let perm = await permHandle.queryPermission({ mode: 'read' });
  if (perm !== 'granted') {
    perm = await permHandle.requestPermission({ mode: 'read' });
  }
  if (perm !== 'granted') {
    const updated: LibraryFolder = { ...folder, permissionState: perm };
    await saveFolder(updated);
    throw new Error('Folder read permission was not granted.');
  }
  return await scanDirectoryHandleIntoFolder(folder.handle, folder.id, onProgress);
}

async function scanDirectoryHandleIntoFolder(
  dirHandle: FileSystemDirectoryHandle,
  folderId: string,
  onProgress?: (p: ScanProgress) => void,
): Promise<{ folder: LibraryFolder; comics: ComicEntry[] }> {
  const existingComics = await loadComics();
  const existingMap = new Map(existingComics.map((c) => [c.id, c]));

  const discovered = await collectFilesFromDirectoryHandle(dirHandle);
  const scannedComics: ComicEntry[] = [];

  for (let i = 0; i < discovered.length; i++) {
    const item = discovered[i];
    onProgress?.({
      folderName: dirHandle.name,
      processed: i + 1,
      total: discovered.length,
      currentFile: item.file.name,
    });

    const id = makeComicId(folderId, item.relativePath);
    const prev = existingMap.get(id);

    // Fast path: reuse cached ComicInfo + thumbnail if file size & mtime haven't changed
    if (
      prev &&
      prev.fileSize === item.file.size &&
      prev.lastModified === item.file.lastModified &&
      prev.coverBlob
    ) {
      const updated: ComicEntry = {
        ...prev,
        fileHandle: item.handle,
      };
      await saveComic(updated);
      scannedComics.push(updated);
      continue;
    }

    try {
      const scan = await scanComicArchive(item.file, item.file.name);
      const entry: ComicEntry = {
        id,
        fileName: item.file.name,
        displayTitle: scan.comicInfo?.title || cleanDisplayTitle(item.file.name),
        folderId,
        folderName: dirHandle.name,
        relativePath: item.relativePath,
        format: scan.format,
        fileSize: item.file.size,
        lastModified: item.file.lastModified,
        pageCount: scan.pageCount,
        coverBlob: scan.coverBlob,
        comicInfo: scan.comicInfo,
        currentPage: prev?.currentPage ?? 0,
        scrollProgress: prev?.scrollProgress ?? 0,
        lastReadAt: prev?.lastReadAt,
        addedAt: prev?.addedAt ?? Date.now(),
        isOfflineCached: prev?.isOfflineCached ?? false,
        userBookmarks: prev?.userBookmarks ?? [],
        fileHandle: item.handle,
        imageFormatsFound: scan.imageFormatsFound,
      };
      await saveComic(entry);
      scannedComics.push(entry);
    } catch {
      // Skip corrupted or unreadable archive gracefully
    }
  }

  const folder: LibraryFolder = {
    id: folderId,
    name: dirHandle.name,
    sourceType: 'fs-access',
    comicCount: scannedComics.length,
    lastScannedAt: Date.now(),
    handle: dirHandle,
    permissionState: 'granted',
  };
  await saveFolder(folder);

  return { folder, comics: scannedComics };
}

/**
 * Ingests files from <input webkitdirectory>, <input type="file" multiple>, or Drag & Drop.
 * Automatically groups by folder and stores archives in IndexedDB for 100% offline reading.
 */
export async function ingestUploadedFiles(
  fileList: File[] | FileList,
  fallbackFolderName = 'Local Imports',
  onProgress?: (p: ScanProgress) => void,
): Promise<{ folders: LibraryFolder[]; comics: ComicEntry[] }> {
  const files = Array.from(fileList).filter((f) => isComicArchiveFileName(f.name));
  if (files.length === 0) {
    return { folders: [], comics: [] };
  }

  const existingComics = await loadComics();
  const existingMap = new Map(existingComics.map((c) => [c.id, c]));

  const folderGroups = new Map<string, { name: string; files: { file: File; relPath: string }[] }>();

  for (const file of files) {
    const rel = (file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name;
    const segments = rel.split('/').filter(Boolean);
    const groupName = segments.length > 1 ? segments[0] : fallbackFolderName;
    const group = folderGroups.get(groupName) || { name: groupName, files: [] };
    group.files.push({ file, relPath: rel });
    folderGroups.set(groupName, group);
  }

  const createdFolders: LibraryFolder[] = [];
  const createdComics: ComicEntry[] = [];

  let processedCount = 0;
  const totalCount = files.length;

  for (const [groupName, group] of folderGroups.entries()) {
    const folderId = `upload-${groupName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
    let folderComicCount = 0;

    for (const item of group.files) {
      processedCount++;
      onProgress?.({
        folderName: groupName,
        processed: processedCount,
        total: totalCount,
        currentFile: item.file.name,
      });

      const id = makeComicId(folderId, item.relPath);
      const prev = existingMap.get(id);

      try {
        const scan = await scanComicArchive(item.file, item.file.name);
        const entry: ComicEntry = {
          id,
          fileName: item.file.name,
          displayTitle: scan.comicInfo?.title || cleanDisplayTitle(item.file.name),
          folderId,
          folderName: groupName,
          relativePath: item.relPath,
          format: scan.format,
          fileSize: item.file.size,
          lastModified: item.file.lastModified,
          pageCount: scan.pageCount,
          coverBlob: scan.coverBlob,
          comicInfo: scan.comicInfo,
          currentPage: prev?.currentPage ?? 0,
          scrollProgress: prev?.scrollProgress ?? 0,
          lastReadAt: prev?.lastReadAt,
          addedAt: prev?.addedAt ?? Date.now(),
          isOfflineCached: true,
          userBookmarks: prev?.userBookmarks ?? [],
          imageFormatsFound: scan.imageFormatsFound,
        };
        await saveComic(entry);
        await saveOfflineArchive(entry.id, entry.fileName, item.file);
        createdComics.push(entry);
        folderComicCount++;
      } catch {
        // Skip invalid archive
      }
    }

    if (folderComicCount > 0) {
      const folder: LibraryFolder = {
        id: folderId,
        name: groupName,
        sourceType: 'upload',
        comicCount: folderComicCount,
        lastScannedAt: Date.now(),
        permissionState: 'granted',
      };
      await saveFolder(folder);
      createdFolders.push(folder);
    }
  }

  return { folders: createdFolders, comics: createdComics };
}

/**
 * Resolves a readable Blob for opening a comic:
 * 1) Checks IndexedDB offline cache first (instant & works offline even without folder handle permissions)
 * 2) Falls back to FileSystemFileHandle (requesting read permission if needed)
 */
export async function resolveComicBlob(comic: ComicEntry): Promise<Blob> {
  const cached = await getOfflineArchiveBlob(comic.id);
  if (cached) return cached;

  if (comic.fileHandle) {
    const fh = comic.fileHandle as unknown as {
      queryPermission: (opts: { mode: 'read' }) => Promise<'granted' | 'denied' | 'prompt'>;
      requestPermission: (opts: { mode: 'read' }) => Promise<'granted' | 'denied' | 'prompt'>;
      getFile: () => Promise<File>;
    };
    let perm = await fh.queryPermission({ mode: 'read' });
    if (perm !== 'granted') {
      perm = await fh.requestPermission({ mode: 'read' });
    }
    if (perm !== 'granted') {
      throw new Error('Permission to read this local file was denied. Re-select its folder to restore access.');
    }
    return await fh.getFile();
  }

  throw new Error('Comic archive is not cached offline and its local file handle is unavailable.');
}
