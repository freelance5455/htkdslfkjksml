import { MacroBreakdown } from '../types';

export interface AnalysisResult {
  mealName: string;
  mealNameEn: string;
  category: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  weightGrams: number;
  macros: MacroBreakdown;
  healthScore: number;
  aiInsight: string;
  aiSwaps: string[];
  ingredients: string[];
  confidence: number;
}

// Smart heuristic & semantic food detection
export function analyzeFoodImageOrVoice(input: {
  imageSrc?: string;
  textDescription?: string;
  sampleMeal?: any;
}): Promise<AnalysisResult> {
  return new Promise((resolve) => {
    // If it's one of our preset sample meals
    if (input.sampleMeal) {
      setTimeout(() => {
        resolve({
          mealName: input.sampleMeal.name,
          mealNameEn: input.sampleMeal.nameEn,
          category: input.sampleMeal.category,
          weightGrams: input.sampleMeal.weightGrams,
          macros: input.sampleMeal.macros,
          healthScore: input.sampleMeal.healthScore,
          aiInsight: input.sampleMeal.aiInsight,
          aiSwaps: input.sampleMeal.aiSwaps || [],
          ingredients: input.sampleMeal.ingredients || [],
          confidence: 0.98,
        });
      }, 1200);
      return;
    }

    // If text description from voice
    const text = (input.textDescription || '').toLowerCase();
    
    // Simulate smart AI vision / voice recognition pipeline
    setTimeout(() => {
      let mealName = 'طبق ممسوح بالذكاء الاصطناعي';
      let mealNameEn = 'AI-Scanned Healthy Meal';
      let category: 'breakfast' | 'lunch' | 'dinner' | 'snack' = 'lunch';
      let cals = 480;
      let p = 38;
      let c = 44;
      let f = 14;
      let fib = 7;
      let sug = 5;
      let sod = 420;
      let satFat = 2.9;
      let health = 92;
      let ingredients = ['مكونات طازجة متنوعة', 'توابل طبيعية', 'ألياف نباتية'];

      if (text.includes('بيض') || text.includes('إفطار') || text.includes('بانكيك') || text.includes('شوفان') || text.includes('egg') || text.includes('pancake')) {
        mealName = 'إفطار بروتيني متوازن مع خضار';
        mealNameEn = 'Balanced Protein Breakfast';
        category = 'breakfast';
        cals = 390;
        p = 28;
        c = 36;
        f = 12;
        fib = 6;
        sug = 4;
        sod = 310;
        satFat = 2.4;
        health = 94;
        ingredients = ['بيض مسلوق أو مقلي بزيت خفيف', 'خبز حبوب كاملة', 'طماطم وخيار', 'زيتون'];
      } else if (text.includes('دجاج') || text.includes('رز') || text.includes('chicken') || text.includes('rice')) {
        mealName = 'صدر دجاج مشوي مع أرز بسمتي وخضار';
        mealNameEn = 'Grilled Chicken with Basmati Rice';
        category = 'lunch';
        cals = 520;
        p = 48;
        c = 54;
        f = 11;
        fib = 6;
        sug = 3;
        sod = 440;
        satFat = 2.2;
        health = 95;
        ingredients = ['صدر دجاج متبل 200غ', 'أرز بسمتي مسلوق 150غ', 'سلطة خضراء', 'ليمون وثوم'];
      } else if (text.includes('لحم') || text.includes('ستيك') || text.includes('meat') || text.includes('steak')) {
        mealName = 'شريحة لحم مشوي مع بطاطس مشوية';
        mealNameEn = 'Lean Grilled Beef with Roasted Potatoes';
        category = 'dinner';
        cals = 560;
        p = 50;
        c = 42;
        f = 18;
        fib = 5;
        sug = 2;
        sod = 480;
        satFat = 4.5;
        health = 89;
        ingredients = ['لحم بقري قليل الدهن', 'بطاطس مشوية بالأعشاب', 'خضار مشوية'];
      } else if (text.includes('سلطة') || text.includes('salad') || text.includes('تونة') || text.includes('tuna')) {
        mealName = 'سلطة تونة صحية مع بيض وخضروات ورقية';
        mealNameEn = 'Healthy Tuna Salad with Boiled Egg';
        category = 'dinner';
        cals = 360;
        p = 39;
        c = 14;
        f = 13;
        fib = 8;
        sug = 4;
        sod = 520;
        satFat = 2.1;
        health = 96;
        ingredients = ['تونة بالماء مصفاة', 'خس وجرجير وطماطم', 'بيضة مسلوقة', 'عصير ليمون ونصف ملعقة زيت زيتون'];
      } else if (text.includes('سناك') || text.includes('تفاح') || text.includes('مكسرات') || text.includes('snack') || text.includes('apple')) {
        mealName = 'سناك صحي: تفاح ومكسرات غير مملحة';
        mealNameEn = 'Healthy Snack: Fresh Apple & Almonds';
        category = 'snack';
        cals = 220;
        p = 6;
        c = 26;
        f = 11;
        fib = 5;
        sug = 18;
        sod = 10;
        satFat = 1.0;
        health = 95;
        ingredients = ['تفاحة طازجة متوسطة', 'لوز نيء 20غ'];
      }

      resolve({
        mealName,
        mealNameEn,
        category,
        weightGrams: Math.floor(cals * 0.75),
        macros: {
          calories: cals,
          protein: p,
          carbs: c,
          fat: f,
          fiber: fib,
          sugar: sug,
          sodium: sod,
          saturatedFat: satFat,
        },
        healthScore: health,
        aiInsight: `تم تحليل الوجبة بنجاح بواسطة خوارزميات Cal AI. تحتوي على نسبة ممتازة من البروتين لدعم عضلاتك وطاقتك.`,
        aiSwaps: [
          'يمكن استبدال الملح بخلطات الأعشاب وعصير الليمون لتقليل احتباس السوائل.',
          'شرب كوب ماء كبير قبل الوجبة يعزز الإحساس بالشبع ويسرع الهضم.',
        ],
        ingredients,
        confidence: 0.94,
      });
    }, 1400);
  });
}
