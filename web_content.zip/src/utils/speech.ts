/**
 * Voice Speech Engine for JARVIS
 * Combines Web Speech Recognition (voice input / wake-word)
 * and SpeechSynthesis (authentic British Jarvis voice synthesis).
 */

export interface SpeechCallbacks {
  onTranscript?: (transcript: string, isFinal: boolean) => void;
  onListeningChange?: (isListening: boolean) => void;
  onSpeakingChange?: (isSpeaking: boolean) => void;
  onError?: (error: string) => void;
}

class JarvisSpeechService {
  private recognition: any = null;
  private isListening: boolean = false;
  private isSpeaking: boolean = false;
  private continuousMode: boolean = false;
  private callbacks: SpeechCallbacks = {};
  private voicesLoaded: boolean = false;
  private selectedVoice: SpeechSynthesisVoice | null = null;

  constructor() {
    this.initVoices();
  }

  private initVoices(): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    const load = () => {
      const voices = window.speechSynthesis.getVoices();
      if (voices.length > 0) {
        this.voicesLoaded = true;
        // Check for Urdu voices (ur-PK, ur) first, then clean articulate English voice for Roman Urdu
        this.selectedVoice =
          voices.find((v) => v.lang === 'ur-PK' || v.lang.startsWith('ur')) ||
          voices.find((v) => v.lang === 'en-GB' && v.name.toLowerCase().includes('male')) ||
          voices.find((v) => v.name.toLowerCase().includes('daniel')) ||
          voices.find((v) => v.name.toLowerCase().includes('google')) ||
          voices.find((v) => v.lang.startsWith('en')) ||
          voices[0];
      }
    };

    load();
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = load;
    }
  }

  setCallbacks(callbacks: SpeechCallbacks): void {
    this.callbacks = { ...this.callbacks, ...callbacks };
  }

  /**
   * Speak response using SpeechSynthesis
   */
  speak(text: string, onDone?: () => void): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      if (onDone) onDone();
      return;
    }

    // Cancel current speech if any
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    if (!this.selectedVoice && !this.voicesLoaded) {
      this.initVoices();
    }
    if (this.selectedVoice) {
      utterance.voice = this.selectedVoice;
    }

    utterance.pitch = 0.95; // Slightly lower pitch for composure
    utterance.rate = 1.05;  // Crisp, articulate cadence

    utterance.onstart = () => {
      this.isSpeaking = true;
      if (this.callbacks.onSpeakingChange) {
        this.callbacks.onSpeakingChange(true);
      }
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      if (this.callbacks.onSpeakingChange) {
        this.callbacks.onSpeakingChange(false);
      }
      if (onDone) onDone();
    };

    utterance.onerror = (e) => {
      console.warn('SpeechSynthesis error:', e);
      this.isSpeaking = false;
      if (this.callbacks.onSpeakingChange) {
        this.callbacks.onSpeakingChange(false);
      }
      if (onDone) onDone();
    };

    window.speechSynthesis.speak(utterance);
  }

  stopSpeaking(): void {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      this.isSpeaking = false;
      if (this.callbacks.onSpeakingChange) {
        this.callbacks.onSpeakingChange(false);
      }
    }
  }

  /**
   * Start listening for speech input
   */
  startListening(continuous: boolean = false): boolean {
    if (typeof window === 'undefined') return false;

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      if (this.callbacks.onError) {
        this.callbacks.onError('Web Speech Recognition is not supported in this browser.');
      }
      return false;
    }

    if (this.isListening) {
      return true;
    }

    try {
      this.continuousMode = continuous;
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = continuous;
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';

      this.recognition.onstart = () => {
        this.isListening = true;
        if (this.callbacks.onListeningChange) {
          this.callbacks.onListeningChange(true);
        }
      };

      this.recognition.onresult = (event: any) => {
        let finalTranscript = '';
        let interimTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const item = event.results[i];
          if (item.isFinal) {
            finalTranscript += item[0].transcript;
          } else {
            interimTranscript += item[0].transcript;
          }
        }

        const currentText = finalTranscript || interimTranscript;
        const isFinal = Boolean(finalTranscript);

        if (this.callbacks.onTranscript) {
          this.callbacks.onTranscript(currentText, isFinal);
        }
      };

      this.recognition.onerror = (event: any) => {
        console.warn('SpeechRecognition error:', event.error);
        if (event.error !== 'no-speech' && this.callbacks.onError) {
          this.callbacks.onError(event.error);
        }
        if (event.error === 'not-allowed') {
          this.stopListening();
        }
      };

      this.recognition.onend = () => {
        // If continuous mode is enabled, keep listening unless explicitly stopped
        if (this.continuousMode && this.isListening) {
          try {
            this.recognition.start();
            return;
          } catch {
            // failed to restart
          }
        }
        this.isListening = false;
        if (this.callbacks.onListeningChange) {
          this.callbacks.onListeningChange(false);
        }
      };

      this.recognition.start();
      return true;
    } catch (err) {
      console.warn('Error starting speech recognition:', err);
      return false;
    }
  }

  stopListening(): void {
    this.continuousMode = false;
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch {
        // ignore
      }
    }
    this.isListening = false;
    if (this.callbacks.onListeningChange) {
      this.callbacks.onListeningChange(false);
    }
  }

  getIsListening(): boolean {
    return this.isListening;
  }

  getIsSpeaking(): boolean {
    return this.isSpeaking;
  }
}

export const jarvisSpeech = new JarvisSpeechService();
