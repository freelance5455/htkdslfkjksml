/**
 * Speech Recognition and Speech Synthesis helper utilities
 * Completely safe against browser incompatibility, permission denials, and iframe restrictions
 */

export interface SpeechRecognitionHook {
  isListening: boolean;
  isSupported: boolean;
  startListening: (onResult: (text: string) => void, onError?: (err: string) => void) => void;
  stopListening: () => void;
}

// Check Speech Recognition support safely
export function isSpeechRecognitionSupported(): boolean {
  if (typeof window === "undefined") return false;
  return Boolean(
    (window as any).SpeechRecognition ||
    (window as any).webkitSpeechRecognition
  );
}

// Speech Recognition Manager class
class SpeechManager {
  private recognition: any = null;
  private isListening = false;

  constructor() {
    if (typeof window !== "undefined") {
      const SpeechRecognitionConstructor =
        (window as any).SpeechRecognition ||
        (window as any).webkitSpeechRecognition;

      if (SpeechRecognitionConstructor) {
        try {
          this.recognition = new SpeechRecognitionConstructor();
          this.recognition.continuous = false;
          this.recognition.interimResults = false;
          this.recognition.lang = "hi-IN"; // Supports Hindi & English accents nicely
        } catch (e) {
          console.warn("Speech recognition initialization error:", e);
          this.recognition = null;
        }
      }
    }
  }

  public listen(
    onResult: (text: string) => void,
    onStatusChange: (listening: boolean) => void,
    onError: (errMessage: string) => void
  ) {
    if (!this.recognition) {
      onError("Voice input is not supported in this browser. Please type your question.");
      return;
    }

    try {
      this.recognition.abort(); // Cancel any existing
    } catch {}

    this.recognition.onstart = () => {
      this.isListening = true;
      onStatusChange(true);
    };

    this.recognition.onresult = (event: any) => {
      if (event.results && event.results[0] && event.results[0][0]) {
        const transcript = event.results[0][0].transcript;
        onResult(transcript);
      }
    };

    this.recognition.onerror = (event: any) => {
      this.isListening = false;
      onStatusChange(false);
      let msg = "Microphone error. Please type your question.";
      if (event.error === "not-allowed") {
        msg = "Microphone permission was denied. Please allow microphone access in your browser settings.";
      } else if (event.error === "no-speech") {
        msg = "No voice detected. Please tap the microphone and try again.";
      }
      onError(msg);
    };

    this.recognition.onend = () => {
      this.isListening = false;
      onStatusChange(false);
    };

    try {
      this.recognition.start();
    } catch (e: any) {
      this.isListening = false;
      onStatusChange(false);
      onError("Could not start voice recognition. Please try typing.");
    }
  }

  public stop() {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch {}
      this.isListening = false;
    }
  }
}

export const speechManager = new SpeechManager();

// Text-to-Speech (TTS) manager
class TTSManager {
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private activeId: string | null = null;

  public isSupported(): boolean {
    return typeof window !== "undefined" && "speechSynthesis" in window;
  }

  public speak(
    id: string,
    rawText: string,
    onStart: (id: string) => void,
    onEnd: (id: string) => void,
    onError?: (err: string) => void
  ) {
    if (!this.isSupported()) {
      onError?.("Text to Speech is not supported on this device.");
      return;
    }

    this.stop();

    try {
      // Clean markdown symbols for natural speaking
      const cleanedText = rawText
        .replace(/[*_#`~[\]]/g, "")
        .replace(/₹/g, " Rupees ")
        .replace(/\n+/g, ". ")
        .trim();

      if (!cleanedText) return;

      const utterance = new SpeechSynthesisUtterance(cleanedText);
      this.currentUtterance = utterance;
      this.activeId = id;

      // Select suitable voice
      const voices = window.speechSynthesis.getVoices();
      const hindiVoice = voices.find(
        (v) => v.lang.includes("hi") || v.lang.includes("HI")
      );
      const indianEngVoice = voices.find(
        (v) => v.lang.includes("en-IN") || v.name.includes("India")
      );

      if (hindiVoice) {
        utterance.voice = hindiVoice;
        utterance.lang = "hi-IN";
      } else if (indianEngVoice) {
        utterance.voice = indianEngVoice;
        utterance.lang = "en-IN";
      }

      utterance.rate = 0.95;
      utterance.pitch = 1.0;

      utterance.onstart = () => {
        onStart(id);
      };

      utterance.onend = () => {
        this.activeId = null;
        this.currentUtterance = null;
        onEnd(id);
      };

      utterance.onerror = (e) => {
        this.activeId = null;
        this.currentUtterance = null;
        onEnd(id);
        console.warn("Speech synthesis error:", e);
      };

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      this.activeId = null;
      onEnd(id);
      console.warn("TTS speak exception:", e);
    }
  }

  public stop() {
    if (this.isSupported()) {
      try {
        window.speechSynthesis.cancel();
      } catch {}
    }
    this.activeId = null;
    this.currentUtterance = null;
  }

  public getActiveId(): string | null {
    return this.activeId;
  }
}

export const ttsManager = new TTSManager();
