// Speech synthesis (TTS) & Speech recognition (Dictation)

let currentUtterance: SpeechSynthesisUtterance | null = null;

export const speakText = (
  text: string,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: () => void
): boolean => {
  if (typeof window === 'undefined' || !window.speechSynthesis) {
    return false;
  }

  // If already speaking, cancel
  window.speechSynthesis.cancel();

  // Strip markdown symbols for cleaner voice
  const cleanText = text
    .replace(/```[\s\S]*?```/g, 'Bloc de code omis.')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/[*_#~>]/g, '')
    .trim();

  if (!cleanText) return false;

  const utterance = new SpeechSynthesisUtterance(cleanText);
  currentUtterance = utterance;

  // Find preferred French voice or fallback
  const voices = window.speechSynthesis.getVoices();
  const frVoice = voices.find((v) => v.lang.startsWith('fr') || v.lang === 'fr-FR');
  if (frVoice) {
    utterance.voice = frVoice;
    utterance.lang = frVoice.lang;
  } else {
    utterance.lang = 'fr-FR';
  }

  utterance.rate = 1.05;
  utterance.pitch = 1.0;

  utterance.onstart = () => {
    onStart?.();
  };

  utterance.onend = () => {
    currentUtterance = null;
    onEnd?.();
  };

  utterance.onerror = () => {
    currentUtterance = null;
    onError?.();
  };

  window.speechSynthesis.speak(utterance);
  return true;
};

export const stopSpeech = () => {
  if (typeof window !== 'undefined' && window.speechSynthesis) {
    window.speechSynthesis.cancel();
    currentUtterance = null;
  }
};

export const isSpeaking = (): boolean => {
  if (typeof window === 'undefined' || !window.speechSynthesis) return false;
  return window.speechSynthesis.speaking;
};

// Speech Recognition (Dictation)
export const createSpeechRecognizer = (
  onResult: (transcript: string) => void,
  onError?: (error: any) => void,
  onEnd?: () => void
) => {
  if (typeof window === 'undefined') return null;

  const SpeechRecognitionClass =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

  if (!SpeechRecognitionClass) {
    return null;
  }

  try {
    const recognition = new SpeechRecognitionClass();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = 'fr-FR';

    recognition.onresult = (event: any) => {
      let current = '';
      for (let i = 0; i < event.results.length; i++) {
        current += event.results[i][0].transcript;
      }
      onResult(current);
    };

    recognition.onerror = (e: any) => {
      onError?.(e);
    };

    recognition.onend = () => {
      onEnd?.();
    };

    return recognition;
  } catch (err) {
    console.error('Speech recognition initialization failed:', err);
    return null;
  }
};
