// Speech Recognition and Speech Synthesis utilities for Mobile Chrome and modern browsers
// Upgraded: Voice barge-in interruption, echo cancellation, single-session controller, and no 3s cutoffs

import {
  hasWakeWord,
  hasStopPhrase,
  hasInterruptPhrase,
  isSpokenTextEcho,
} from './wakeWord';

export interface SpeechRecognitionResultPayload {
  transcript: string;
  isFinal: boolean;
}

export type SpeechRecognitionErrorType =
  | 'not-allowed'
  | 'service-not-allowed'
  | 'no-speech'
  | 'network'
  | 'audio-capture'
  | 'not-supported'
  | 'aborted'
  | 'unknown';

// Language code to BCP-47 locale tag mapping
export function mapLanguageToLocale(langCode: string): string {
  switch (langCode) {
    case 'bn':
      return 'bn-BD'; // Bengali (Bangladesh), also works for bn-IN
    case 'en':
      return 'en-US';
    case 'hi':
      return 'hi-IN';
    case 'es':
      return 'es-ES';
    case 'fr':
      return 'fr-FR';
    case 'ar':
      return 'ar-SA';
    case 'de':
      return 'de-DE';
    case 'ja':
      return 'ja-JP';
    case 'auto':
    default:
      if (typeof navigator !== 'undefined' && navigator.language) {
        return navigator.language;
      }
      return 'en-US';
  }
}

/**
 * Check if browser supports Web Speech Recognition
 */
export function isSpeechRecognitionSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return Boolean(
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
  );
}

/**
 * Check if browser supports Web Speech Synthesis
 */
export function isSpeechSynthesisSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;
}

/**
 * Get available device voices, filtering and sorting
 */
export function getAvailableVoices(): SpeechSynthesisVoice[] {
  if (!isSpeechSynthesisSupported()) return [];
  return window.speechSynthesis.getVoices();
}

/**
 * Select the best matching voice.
 * Prioritizes natural female voices as requested.
 */
export function pickBestVoice(
  langCode: string,
  voices: SpeechSynthesisVoice[],
  preferredVoiceURI?: string
): SpeechSynthesisVoice | null {
  if (!voices || voices.length === 0) return null;

  // 1. If explicit user preference was chosen
  if (preferredVoiceURI) {
    const found = voices.find((v) => v.voiceURI === preferredVoiceURI);
    if (found) return found;
  }

  const targetLocale = mapLanguageToLocale(langCode).toLowerCase();
  const langPrefix = targetLocale.split('-')[0];

  // Voices matching the language
  const langMatches = voices.filter((v) => {
    const vLang = v.lang.toLowerCase();
    return vLang.startsWith(langPrefix) || vLang === targetLocale;
  });

  const pool = langMatches.length > 0 ? langMatches : voices;

  // Female voice keywords
  const femaleKeywords = [
    'female',
    'karen',
    'samantha',
    'victoria',
    'zira',
    'google us english',
    'google uk english female',
    'google বাংলা',
    'bangla',
    'bengali',
    'aria',
    'jenny',
    'serena',
    'moira',
  ];

  // Look for preferred female voice in pool
  const femaleVoice = pool.find((v) => {
    const name = v.name.toLowerCase();
    return femaleKeywords.some((kw) => name.includes(kw));
  });

  if (femaleVoice) return femaleVoice;

  // Fallback to default or first in pool
  const defaultVoice = pool.find((v) => v.default);
  return defaultVoice || pool[0] || null;
}

/**
 * Clean text for Speech Synthesis:
 * Strip markdown symbols, code blocks, excessive formatting, and emojis so speech flows naturally
 */
export function sanitizeTextForSpeech(text: string): string {
  if (!text) return '';
  return text
    // Remove code blocks
    .replace(/```[\s\S]*?```/g, 'Code block omitted.')
    // Remove inline code
    .replace(/`([^`]+)`/g, '$1')
    // Remove markdown headers
    .replace(/^#{1,6}\s+/gm, '')
    // Remove bold/italics
    .replace(/[*_]{1,3}([^*_]+)[*_]{1,3}/g, '$1')
    // Remove links [text](url)
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    // Remove bullets and blockquotes
    .replace(/^\s*[-*+>]\s+/gm, '')
    // Remove hashtags
    .replace(/#(\w+)/g, '$1')
    // Remove common emojis
    .replace(/[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
    // Condense whitespace
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Stop any current speech playback immediately
 */
export function stopSpeaking() {
  if (isSpeechSynthesisSupported()) {
    try {
      window.speechSynthesis.cancel();
      console.log('[JARVIS TTS] stopSpeaking(): Speech synthesis cancelled.');
    } catch (e) {
      console.warn('[JARVIS TTS] Error cancelling speech synthesis:', e);
    }
  }
}

/**
 * Speak text aloud using SpeechSynthesis
 */
export function speakText(
  text: string,
  options: {
    langCode?: string;
    voiceURI?: string;
    rate?: number;
    pitch?: number;
    onStart?: () => void;
    onEnd?: () => void;
    onError?: (err: any) => void;
  } = {}
) {
  if (!isSpeechSynthesisSupported()) {
    options.onError?.('Speech synthesis not supported on this device.');
    return;
  }

  // Cancel prior speech immediately
  stopSpeaking();

  const cleanText = sanitizeTextForSpeech(text);
  if (!cleanText) {
    options.onEnd?.();
    return;
  }

  const utterance = new SpeechSynthesisUtterance(cleanText);
  const voices = window.speechSynthesis.getVoices();
  const selectedVoice = pickBestVoice(
    options.langCode || 'auto',
    voices,
    options.voiceURI
  );

  if (selectedVoice) {
    utterance.voice = selectedVoice;
    utterance.lang = selectedVoice.lang;
  } else {
    utterance.lang = mapLanguageToLocale(options.langCode || 'auto');
  }

  utterance.rate = Math.max(0.7, Math.min(1.5, options.rate ?? 1.05));
  utterance.pitch = Math.max(0.8, Math.min(1.3, options.pitch ?? 1.0));

  let hasEnded = false;
  const finish = () => {
    if (!hasEnded) {
      hasEnded = true;
      options.onEnd?.();
    }
  };

  utterance.onstart = () => {
    options.onStart?.();
  };

  utterance.onend = () => {
    finish();
  };

  utterance.onerror = (e) => {
    if (e.error === 'interrupted' || e.error === 'canceled') {
      finish();
    } else {
      console.warn('[JARVIS TTS] SpeechSynthesis error:', e);
      options.onError?.(e);
      finish();
    }
  };

  try {
    window.speechSynthesis.speak(utterance);
  } catch (err) {
    options.onError?.(err);
    finish();
  }
}

/**
 * Single-Session Speech Recognition Controller with Voice Barge-in Interruption
 * Resolves:
 * 1. 3-second timeout bug (continuous session preservation, zero penalty on no-speech)
 * 2. Voice interruption / barge-in while JARVIS speaks (with echo suppression)
 * 3. Mobile Chrome visibility and single-instance session lifecycle
 */
export class JarvisSpeechRecognizer {
  private recognition: any = null;

  // Controlled state flags
  private isVoiceModeEnabled = false;
  private isRecognizing = false;
  private isSpeaking = false;
  private isStopping = false;
  private isTabVisible =
    typeof document !== 'undefined' ? document.visibilityState === 'visible' : true;

  // Barge-in & Echo detection
  private currentlySpeakingText = '';
  private voiceBargeInEnabled = true;

  // Continuous speech buffer across Chrome session wraps
  private sessionAccumulatedText = '';

  private consecutiveErrors = 0;
  private lastErrorType: SpeechRecognitionErrorType | null = null;
  private restartTimer: ReturnType<typeof setTimeout> | null = null;
  private currentLanguage = 'auto';

  private onResultCallback?: (result: SpeechRecognitionResultPayload) => void;
  private onStateChangeCallback?: (isRecognizing: boolean) => void;
  private onErrorCallback?: (type: SpeechRecognitionErrorType, rawError: any) => void;
  private onInterruptCallback?: (transcript: string) => void;

  constructor() {
    this.init();
    this.setupVisibilityListener();
  }

  private init() {
    if (typeof window === 'undefined') return;

    const SpeechRecognitionClass =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognitionClass) {
      console.warn('[JARVIS Voice] Web Speech Recognition is not supported in this browser.');
      return;
    }

    try {
      this.recognition = new SpeechRecognitionClass();
      // continuous=true allows speech over multiple phrases without closing the microphone
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.maxAlternatives = 1;

      this.recognition.onstart = () => {
        this.isRecognizing = true;
        this.consecutiveErrors = 0;
        this.lastErrorType = null;
        console.log('[JARVIS Voice] onstart: microphone session active.');
        this.onStateChangeCallback?.(true);
      };

      this.recognition.onresult = (event: any) => {
        let chunkFinal = '';
        let chunkInterim = '';

        for (let i = 0; i < event.results.length; ++i) {
          const item = event.results[i];
          if (item.isFinal) {
            chunkFinal += item[0].transcript + ' ';
          } else {
            chunkInterim += item[0].transcript;
          }
        }

        const currentChunk = (chunkFinal + chunkInterim).trim();
        const fullTranscript = (
          (this.sessionAccumulatedText ? this.sessionAccumulatedText + ' ' : '') + currentChunk
        ).trim();

        const lastResult = event.results[event.results.length - 1];
        const isFinal = Boolean(lastResult?.isFinal);

        // Store confirmed chunks across sessions
        if (chunkFinal) {
          this.sessionAccumulatedText = (
            (this.sessionAccumulatedText ? this.sessionAccumulatedText + ' ' : '') + chunkFinal
          ).trim();
        }

        // ==========================================
        // VOICE BARGE-IN INTERRUPTION LOGIC
        // ==========================================
        if (this.isSpeaking && fullTranscript) {
          // If voice barge-in is enabled, check if the spoken words represent an intentional user interruption
          const isInterrupt =
            hasWakeWord(fullTranscript) ||
            hasStopPhrase(fullTranscript) ||
            hasInterruptPhrase(fullTranscript) ||
            !isSpokenTextEcho(fullTranscript, this.currentlySpeakingText);

          if (isInterrupt) {
            console.log(
              `[JARVIS Voice] User voice interruption detected during speech: "${fullTranscript}"`
            );
            // Cancel TTS speech immediately
            stopSpeaking();
            this.isSpeaking = false;
            this.currentlySpeakingText = '';
            this.onInterruptCallback?.(fullTranscript);
            return;
          } else {
            // It's the assistant's own voice being picked up from loudspeaker (echo)
            // Suppress echo so JARVIS does not interpret its own speech as a prompt
            console.log('[JARVIS Voice] Echo suppressed from speaker audio.');
            return;
          }
        }

        // Normal speech event when not speaking
        if (fullTranscript) {
          this.onResultCallback?.({
            transcript: fullTranscript,
            isFinal,
          });
        }
      };

      this.recognition.onerror = (event: any) => {
        const errorType = (event.error as SpeechRecognitionErrorType) || 'unknown';
        this.lastErrorType = errorType;
        console.warn(`[JARVIS Voice] onerror: ${errorType}`);

        if (errorType === 'not-allowed' || errorType === 'service-not-allowed') {
          // Explicit permission block by user or browser
          this.isVoiceModeEnabled = false;
          this.isStopping = true;
          this.clearRestartTimer();
          this.onErrorCallback?.('not-allowed', event);
        } else if (errorType === 'no-speech') {
          // Normal room silence between words: DO NOT penalize or treat as a fatal error
          this.consecutiveErrors = 0;
          this.onErrorCallback?.('no-speech', event);
        } else if (errorType === 'audio-capture') {
          // Microphone pipeline temporarily occupied
          this.consecutiveErrors++;
          this.onErrorCallback?.('audio-capture', event);
        } else if (errorType === 'aborted') {
          // Expected during sleep or manual mode toggle
          this.onErrorCallback?.('aborted', event);
        } else if (errorType === 'network') {
          this.consecutiveErrors++;
          this.onErrorCallback?.('network', event);
        } else {
          this.consecutiveErrors++;
          this.onErrorCallback?.('unknown', event);
        }
      };

      this.recognition.onend = () => {
        this.isRecognizing = false;
        console.log(
          `[JARVIS Voice] onend: session ended. (enabled=${this.isVoiceModeEnabled}, speaking=${this.isSpeaking}, stopping=${this.isStopping}, visible=${this.isTabVisible})`
        );
        this.onStateChangeCallback?.(false);

        // Seamless continuous listening restart:
        // Even when the browser wraps the session after silence or pauses,
        // we restart immediately if Voice Mode is active, tab is visible, and user hasn't commanded Stop.
        if (this.isVoiceModeEnabled && this.isTabVisible && !this.isStopping) {
          this.scheduleRestart('session_closed_by_browser');
        }
      };
    } catch (err) {
      console.error('[JARVIS Voice] Initialization error:', err);
    }
  }

  /**
   * Listen to browser tab visibility changes
   */
  private setupVisibilityListener() {
    if (typeof document === 'undefined') return;

    document.addEventListener('visibilitychange', () => {
      this.isTabVisible = document.visibilityState === 'visible';
      console.log(`[JARVIS Voice] Document visibility changed: ${document.visibilityState}`);

      if (!this.isTabVisible) {
        // Tab backgrounded or switched away: pause gracefully without losing user's Voice Mode setting
        console.log('[JARVIS Voice] App backgrounded, pausing active speech recognition.');
        this.clearRestartTimer();
        if (this.isRecognizing) {
          this.abort();
        }
      } else {
        // Tab foregrounded / user returned: resume listening if Voice Mode is enabled!
        console.log('[JARVIS Voice] App returned to foreground.');
        if (this.isVoiceModeEnabled && !this.isStopping && !this.isRecognizing) {
          setTimeout(() => {
            if (this.isVoiceModeEnabled && this.isTabVisible && !this.isStopping && !this.isRecognizing) {
              console.log('[JARVIS Voice] Resuming recognition upon return to active tab.');
              this.start();
            }
          }, 200);
        }
      }
    });
  }

  /**
   * Schedule restart with fast recovery and safeguards against infinite error loops
   */
  private scheduleRestart(reason: string) {
    this.clearRestartTimer();

    if (!this.isVoiceModeEnabled || !this.isTabVisible || this.isStopping || this.isRecognizing) {
      console.log(`[JARVIS Voice] Restart skipped: conditions not met (reason: ${reason})`);
      return;
    }

    // Fast recovery delay (eliminates 3s gap):
    // If previous was normal onend or no-speech silence, restart in 75ms.
    // If audio-capture error, give hardware 750ms to release.
    let delay = 75;
    if (this.lastErrorType === 'audio-capture') {
      delay = 750;
    } else if (this.consecutiveErrors > 3) {
      delay = 2500;
    } else if (this.consecutiveErrors > 1) {
      delay = 1000;
    }

    console.log(`[JARVIS Voice] Scheduling restart in ${delay}ms (reason: ${reason})`);
    this.restartTimer = setTimeout(() => {
      this.restartTimer = null;
      if (
        this.isVoiceModeEnabled &&
        this.isTabVisible &&
        !this.isStopping &&
        !this.isRecognizing
      ) {
        this.start();
      }
    }, delay);
  }

  private clearRestartTimer() {
    if (this.restartTimer) {
      clearTimeout(this.restartTimer);
      this.restartTimer = null;
    }
  }

  /**
   * Start speech recognition safely
   */
  public start(): boolean {
    this.clearRestartTimer();

    if (!this.recognition) {
      this.onErrorCallback?.('not-supported', null);
      return false;
    }

    if (!this.isTabVisible) {
      console.log('[JARVIS Voice] Cannot start recognition while tab is hidden.');
      return false;
    }

    if (this.isRecognizing) {
      console.log('[JARVIS Voice] start() called but already recognizing. No-op.');
      return true;
    }

    try {
      this.recognition.lang = mapLanguageToLocale(this.currentLanguage);
      this.recognition.start();
      console.log(`[JARVIS Voice] recognition.start() initiated with locale: ${this.recognition.lang}`);
      return true;
    } catch (err: any) {
      if (err.name === 'InvalidStateError') {
        this.isRecognizing = true;
        this.onStateChangeCallback?.(true);
        return true;
      }
      console.warn('[JARVIS Voice] Error starting recognition:', err);
      this.consecutiveErrors++;
      return false;
    }
  }

  /**
   * Stop speech recognition gracefully
   */
  public stop() {
    this.clearRestartTimer();
    if (this.recognition && this.isRecognizing) {
      try {
        console.log('[JARVIS Voice] recognition.stop() called.');
        this.recognition.stop();
      } catch (e) {
        // Ignore
      }
    }
    this.isRecognizing = false;
    this.onStateChangeCallback?.(false);
  }

  /**
   * Abort speech recognition immediately
   */
  public abort() {
    this.clearRestartTimer();
    if (this.recognition && this.isRecognizing) {
      try {
        console.log('[JARVIS Voice] recognition.abort() called.');
        this.recognition.abort();
      } catch (e) {
        // Ignore
      }
    }
    this.isRecognizing = false;
    this.onStateChangeCallback?.(false);
  }

  /**
   * Enable Voice Mode (Hands-free continuous)
   */
  public enableVoiceMode() {
    console.log('[JARVIS Voice] enableVoiceMode()');
    this.isVoiceModeEnabled = true;
    this.isStopping = false;
    this.consecutiveErrors = 0;
    this.sessionAccumulatedText = '';
    if (this.isTabVisible) {
      this.start();
    }
  }

  /**
   * Disable Voice Mode completely (Stop Voice Mode)
   */
  public disableVoiceMode() {
    console.log('[JARVIS Voice] disableVoiceMode(): releasing microphone session and canceling restarts.');
    this.isVoiceModeEnabled = false;
    this.isStopping = true;
    this.clearRestartTimer();
    this.sessionAccumulatedText = '';
    this.abort();
    setTimeout(() => {
      this.isStopping = false;
    }, 200);
  }

  /**
   * Call when assistant begins speaking aloud.
   * If voice barge-in is enabled, keeps listening to allow voice interruption with echo protection.
   */
  public setSpeaking(speaking: boolean, text: string = '') {
    this.isSpeaking = speaking;
    this.currentlySpeakingText = text;

    if (speaking) {
      console.log('[JARVIS Voice] setSpeaking(true): monitoring for user voice barge-in.');
      // If voice barge-in is active, ensure speech recognition is actively listening
      if (this.voiceBargeInEnabled && this.isVoiceModeEnabled && !this.isRecognizing && this.isTabVisible) {
        this.start();
      }
    } else {
      console.log('[JARVIS Voice] setSpeaking(false): vocalization concluded.');
      this.sessionAccumulatedText = '';
      if (this.isVoiceModeEnabled && !this.isRecognizing && this.isTabVisible && !this.isStopping) {
        this.start();
      }
    }
  }

  /**
   * Signal intentional stop or sleep command
   */
  public prepareSleepTransition() {
    console.log('[JARVIS Voice] prepareSleepTransition()');
    this.isStopping = true;
    this.clearRestartTimer();
    this.sessionAccumulatedText = '';
    if (this.isRecognizing) {
      this.abort();
    }
  }

  public finishSleepTransition() {
    this.isStopping = false;
    this.sessionAccumulatedText = '';
    if (this.isVoiceModeEnabled && this.isTabVisible && !this.isRecognizing) {
      this.start();
    }
  }

  /**
   * Clear accumulated speech buffer once a prompt has been dispatched to backend
   */
  public resetAccumulatedText() {
    this.sessionAccumulatedText = '';
  }

  public setLanguage(langCode: string) {
    this.currentLanguage = langCode;
    if (this.recognition) {
      this.recognition.lang = mapLanguageToLocale(langCode);
      console.log(`[JARVIS Voice] setLanguage: ${langCode} -> ${this.recognition.lang}`);
    }
  }

  public setVoiceBargeIn(enabled: boolean) {
    this.voiceBargeInEnabled = enabled;
  }

  public setCallbacks(callbacks: {
    onResult?: (result: SpeechRecognitionResultPayload) => void;
    onStateChange?: (isRecognizing: boolean) => void;
    onError?: (type: SpeechRecognitionErrorType, rawError: any) => void;
    onInterrupt?: (transcript: string) => void;
  }) {
    this.onResultCallback = callbacks.onResult;
    this.onStateChangeCallback = callbacks.onStateChange;
    this.onErrorCallback = callbacks.onError;
    this.onInterruptCallback = callbacks.onInterrupt;
  }

  public getIsRecognizing(): boolean {
    return this.isRecognizing;
  }

  public getIsVoiceModeEnabled(): boolean {
    return this.isVoiceModeEnabled;
  }
}
