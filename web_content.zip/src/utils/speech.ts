// Web Speech API text-to-speech utility with fallback notification
export interface SpeechResult {
  success: boolean;
  message?: string;
}

export function speakText(
  text: string,
  lang: 'fr' | 'ar' | 'en' = 'fr',
  rate: number = 0.95
): Promise<SpeechResult> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      resolve({
        success: false,
        message: 'ميزة النطق الصوتي غير مدعومة في هذا المتصفح'
      });
      return;
    }

    try {
      window.speechSynthesis.cancel(); // Stop any pending speech

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = rate;
      utterance.pitch = 1.0;

      const langCode = lang === 'ar' ? 'ar-SA' : lang === 'fr' ? 'fr-FR' : 'en-US';
      utterance.lang = langCode;

      // Check available voices
      const voices = window.speechSynthesis.getVoices();
      const matchedVoice = voices.find((v) => v.lang.startsWith(langCode.slice(0, 2)));
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }

      utterance.onend = () => {
        resolve({ success: true });
      };

      utterance.onerror = (e) => {
        console.warn('SpeechSynthesis error:', e);
        resolve({
          success: false,
          message: lang === 'ar' 
            ? 'تعذر نطق المصطلح بالصوت المحلي. يرجى التأكد من تفعيل حزمة الأصوات على جهازك.'
            : 'Impossible de lire le mot audio. Vérifiez les packs vocaux du système.'
        });
      };

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.error('Speech synthesis exception:', err);
      resolve({
        success: false,
        message: 'حدث خطأ أثناء تشغيل الصوت'
      });
    }
  });
}
