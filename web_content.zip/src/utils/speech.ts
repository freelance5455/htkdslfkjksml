/**
 * Speech utilities for SpeechSynthesis and SpeechRecognition
 */

export function speakText(text: string, onEnd?: () => void) {
  if (!('speechSynthesis' in window)) {
    return false;
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  // Strip code blocks and markdown symbols before reading
  const cleanText = text
    .replace(/```[\s\S]*?```/g, 'Блоки рамзи барномасозӣ')
    .replace(/[#*`_~[\]]/g, '')
    .trim();

  if (!cleanText) return false;

  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.rate = 1.0;
  utterance.pitch = 1.0;

  // Try to find a suitable voice (prefer Tajik/Persian/Russian if available, otherwise default)
  const voices = window.speechSynthesis.getVoices();
  const selectedVoice =
    voices.find((v) => v.lang.startsWith('tg')) ||
    voices.find((v) => v.lang.startsWith('fa')) ||
    voices.find((v) => v.lang.startsWith('ru')) ||
    voices[0];

  if (selectedVoice) {
    utterance.voice = selectedVoice;
  }

  if (onEnd) {
    utterance.onend = onEnd;
    utterance.onerror = onEnd;
  }

  window.speechSynthesis.speak(utterance);
  return true;
}

export function stopSpeaking() {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export function isSpeechSynthesisSpeaking(): boolean {
  if ('speechSynthesis' in window) {
    return window.speechSynthesis.speaking;
  }
  return false;
}

export function getSpeechRecognition() {
  const SpeechRecognition =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

  if (!SpeechRecognition) {
    return null;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = 'tg-TJ'; // Primary Tajik, fallback handles Russian or auto
  return recognition;
}
