// Speech-to-Text & Text-to-Speech utilities for Ranabir AI Assistant

export const RANABIR_OFFICIAL_VOICE_URL = "/audio/ranabir_intro.mp3";
export const RANABIR_HELP_VOICE_URL = "/audio/ranabir_help.mp3";
export const RANABIR_LISTENING_VOICE_URL = "/audio/ranabir_listening.mp3";

const CUSTOM_VOICE_STORAGE_KEY = "ranabir_custom_voice_data";

let currentActiveAudio: HTMLAudioElement | null = null;

export function isSpeechRecognitionSupported(): boolean {
  return typeof window !== "undefined" && ("webkitSpeechRecognition" in window || "SpeechRecognition" in window);
}

export function isSpeechSynthesisSupported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

// Custom Voice Storage Management
export function getSavedCustomVoice(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return localStorage.getItem(CUSTOM_VOICE_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function saveCustomVoice(dataUrl: string): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(CUSTOM_VOICE_STORAGE_KEY, dataUrl);
  } catch (e) {
    console.warn("Could not save custom voice to localStorage:", e);
  }
}

export function removeCustomVoice(): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.removeItem(CUSTOM_VOICE_STORAGE_KEY);
  } catch (e) {
    console.warn("Could not remove custom voice:", e);
  }
}

export function hasCustomVoice(): boolean {
  return !!getSavedCustomVoice();
}

export function getActiveRanabirGreetingAudioUrl(): string {
  const custom = getSavedCustomVoice();
  if (custom) return custom;
  return RANABIR_OFFICIAL_VOICE_URL;
}

// Play Ranabir's authentic voice greeting
export function playRanabirGreeting(
  onStart?: () => void,
  onEnd?: () => void
): HTMLAudioElement {
  stopSpeaking();

  const audioUrl = getActiveRanabirGreetingAudioUrl();
  const audio = new Audio(audioUrl);
  currentActiveAudio = audio;

  audio.onplay = () => {
    if (onStart) onStart();
  };

  audio.onended = () => {
    currentActiveAudio = null;
    if (onEnd) onEnd();
  };

  audio.onerror = () => {
    console.warn("Could not play audio greeting, falling back to speech synthesis");
    currentActiveAudio = null;
    speakText("হাই, আমি রণবীর। তো আজকে আমি আপনাকে কি করে সাহায্য করতে পারি?", "bn", onStart, onEnd);
  };

  audio.play().catch(() => {
    // Autoplay policy fallback
    speakText("হাই, আমি রণবীর। তো আজকে আমি আপনাকে কি করে সাহায্য করতে পারি?", "bn", onStart, onEnd);
  });

  return audio;
}

export function createSpeechRecognizer(
  language: string,
  onResult: (transcript: string, isFinal: boolean) => void,
  onError?: (error: string) => void,
  onEnd?: () => void
): any {
  if (!isSpeechRecognitionSupported()) return null;

  const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  const recognizer = new SpeechRec();
  recognizer.continuous = true;
  recognizer.interimResults = true;

  // Set language code
  if (language === "bn") {
    recognizer.lang = "bn-IN";
  } else if (language === "hi") {
    recognizer.lang = "hi-IN";
  } else if (language === "en") {
    recognizer.lang = "en-US";
  } else {
    recognizer.lang = "bn-IN";
  }

  recognizer.onresult = (event: any) => {
    let interim = "";
    let final = "";

    for (let i = event.resultIndex; i < event.results.length; ++i) {
      if (event.results[i].isFinal) {
        final += event.results[i][0].transcript;
      } else {
        interim += event.results[i][0].transcript;
      }
    }

    if (final) {
      onResult(final.trim(), true);
    } else if (interim) {
      onResult(interim.trim(), false);
    }
  };

  recognizer.onerror = (e: any) => {
    if (onError) onError(e.error || "Speech recognition error");
  };

  recognizer.onend = () => {
    if (onEnd) onEnd();
  };

  return recognizer;
}

export function speakText(
  text: string,
  language: string = "bn",
  onStart?: () => void,
  onEnd?: () => void
): void {
  stopSpeaking();

  // Strip markdown formatting for cleaner audio
  const clean = text
    .replace(/[#*_`~>-]/g, "")
    .replace(/\[(.*?)\]\(.*?\)/g, "$1")
    .slice(0, 300);

  // First try natural high-fidelity stream from /api/tts
  if (clean.length > 0 && clean.length <= 180) {
    try {
      const audio = new Audio(`/api/tts?text=${encodeURIComponent(clean)}&lang=${language === "en" ? "en" : language === "hi" ? "hi" : "bn"}`);
      currentActiveAudio = audio;
      audio.onplay = () => {
        if (onStart) onStart();
      };
      audio.onended = () => {
        currentActiveAudio = null;
        if (onEnd) onEnd();
      };
      audio.onerror = () => {
        currentActiveAudio = null;
        speakWithBrowserSynthesis(clean, language, onStart, onEnd);
      };
      audio.play().catch(() => {
        speakWithBrowserSynthesis(clean, language, onStart, onEnd);
      });
      return;
    } catch {
      // Fall through to browser synthesis
    }
  }

  speakWithBrowserSynthesis(clean, language, onStart, onEnd);
}

function speakWithBrowserSynthesis(
  clean: string,
  language: string,
  onStart?: () => void,
  onEnd?: () => void
): void {
  if (!isSpeechSynthesisSupported()) {
    if (onEnd) onEnd();
    return;
  }

  const utterance = new SpeechSynthesisUtterance(clean);
  utterance.rate = 1.05;
  utterance.pitch = 1.0;

  const voices = window.speechSynthesis.getVoices();
  let selectedVoice = null;

  if (language === "bn") {
    selectedVoice = voices.find((v) => v.lang.includes("bn") || v.lang.includes("Bengali"));
    utterance.lang = "bn-IN";
  } else if (language === "hi") {
    selectedVoice = voices.find((v) => v.lang.includes("hi") || v.lang.includes("Hindi"));
    utterance.lang = "hi-IN";
  } else {
    selectedVoice = voices.find((v) => v.lang.includes("en-US") || v.lang.includes("en-IN") || v.lang.includes("en"));
    utterance.lang = "en-US";
  }

  if (selectedVoice) {
    utterance.voice = selectedVoice;
  }

  if (onStart) utterance.onstart = onStart;
  if (onEnd) utterance.onend = onEnd;
  utterance.onerror = () => {
    if (onEnd) onEnd();
  };

  window.speechSynthesis.speak(utterance);
}

export function stopSpeaking(): void {
  if (currentActiveAudio) {
    try {
      currentActiveAudio.pause();
      currentActiveAudio.currentTime = 0;
    } catch (_) {}
    currentActiveAudio = null;
  }
  if (isSpeechSynthesisSupported()) {
    window.speechSynthesis.cancel();
  }
}
