// IndexedDB helper for persisting the user's chosen phone ringtone audio file

const DB_NAME = 'studypulse_ringtone_db';
const STORE_NAME = 'ringtones';
const KEY_CUSTOM = 'custom_phone_ringtone';

export interface SavedPhoneRingtone {
  name: string;
  type: string;
  data: ArrayBuffer;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function savePhoneRingtoneFile(file: File): Promise<SavedPhoneRingtone> {
  const data = await file.arrayBuffer();
  const record: SavedPhoneRingtone = {
    name: file.name,
    type: file.type || 'audio/mpeg',
    data,
  };
  const db = await openDB();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put(record, KEY_CUSTOM);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  return record;
}

export async function loadPhoneRingtoneFile(): Promise<SavedPhoneRingtone | null> {
  try {
    const db = await openDB();
    return await new Promise<SavedPhoneRingtone | null>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).get(KEY_CUSTOM);
      req.onsuccess = () => resolve((req.result as SavedPhoneRingtone) || null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

export async function clearPhoneRingtoneFile(): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(KEY_CUSTOM);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // Ignore cleanup errors
  }
}
