import test from 'node:test';
import assert from 'node:assert/strict';
import {
  generateQRCodeDataURL,
  generateQRCodeSVG,
  isValidQRCodeData,
  clearQRCodeCache,
} from './qrcode';

test('isValidQRCodeData accurately identifies valid strings', () => {
  assert.equal(isValidQRCodeData('TK652:ALG:IST'), true);
  assert.equal(isValidQRCodeData('M1BENALI/AHMED'), true);
  assert.equal(isValidQRCodeData(''), false);
  assert.equal(isValidQRCodeData('  '), false);
  assert.equal(isValidQRCodeData(null as any), false);
  assert.equal(isValidQRCodeData(undefined as any), false);
});

test('generateQRCodeDataURL generates a scannable PNG data URL', async () => {
  clearQRCodeCache();
  const rawData = 'TK652:ALG:IST:SEAT14A:GATE16:ONTIME';
  const dataUrl = await generateQRCodeDataURL(rawData, { width: 250 });

  assert.equal(typeof dataUrl, 'string');
  assert.equal(dataUrl.startsWith('data:image/png;base64,'), true);
  assert.ok(dataUrl.length > 100);

  // Test caching returns the exact same data URL
  const cachedUrl = await generateQRCodeDataURL(rawData, { width: 250 });
  assert.equal(cachedUrl, dataUrl);
});

test('generateQRCodeSVG generates valid XML SVG markup', async () => {
  const rawData = 'SWISSOTEL:CONF892104:GUEST2:DELUXE_BOSPHORUS';
  const svg = await generateQRCodeSVG(rawData, { width: 200 });

  assert.equal(typeof svg, 'string');
  assert.equal(svg.includes('<svg'), true);
  assert.equal(svg.includes('</svg>'), true);
  assert.equal(svg.includes('viewBox'), true);
});

test('generateQRCodeDataURL throws error on empty string', async () => {
  await assert.rejects(
    async () => {
      await generateQRCodeDataURL('');
    },
    {
      message: 'QR Code data must not be empty',
    }
  );
});

test('generateQRCodeDataURL supports all error correction levels', async () => {
  const levels = ['L', 'M', 'Q', 'H'] as const;
  for (const level of levels) {
    const url = await generateQRCodeDataURL(`TEST_${level}`, { errorCorrectionLevel: level });
    assert.equal(url.startsWith('data:image/png;base64,'), true);
  }
});
