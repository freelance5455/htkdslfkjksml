// Bridge / Compatibility layer for Habivio Audio
// Delegates cleanly to the robust, multi-channel procedural AudioManager

import {
  SOUND_LIBRARY,
  SoundOption,
  startAlarmChannel,
  stopAlarmChannel,
  stopAllAlarms,
  isAlarmChannelActive,
  previewRingtone,
  stopRingtonePreview,
  isRingtonePreviewing,
  getSelectedTone,
  setSelectedTone,
  getAlarmVolume,
  setAlarmVolume,
  getCustomAudioInfo,
  setCustomAudioData,
  primeAudioForBackground,
  playTaskCompletionSound,
  getCompletionSoundSetting,
  setCompletionSoundSetting,
  CompletionSoundStyle,
} from './audioManager';

export type AlarmToneOption = SoundOption;
export const ALARM_TONE_OPTIONS: AlarmToneOption[] = SOUND_LIBRARY;

/**
 * Start playing an alarm sound.
 * Guaranteed: only the selected tone plays (no simultaneous sirens or overlaps).
 */
export function startAlarmSound(
  title?: string,
  onSnooze?: () => void,
  onDismiss?: () => void,
  toneKey?: string
): void {
  const chosenTone = toneKey || getSelectedTone();
  startAlarmChannel({
    channelId: 'main_alarm',
    title,
    onSnooze,
    onDismiss,
    toneId: chosenTone,
    volume: getAlarmVolume(),
  });
}

/**
 * Stop alarm sound. Stops either specific channel or all active alarm channels.
 */
export function stopAlarmSound(channelId?: string): void {
  if (channelId) {
    stopAlarmChannel(channelId);
  } else {
    stopAllAlarms();
  }
}

/**
 * Check if alarm is currently ringing.
 */
export function isAlarmPlaying(channelId?: string): boolean {
  return isAlarmChannelActive(channelId || 'main_alarm');
}

/**
 * Check if audio system is ready.
 */
export function isAudioReady(): boolean {
  return true;
}

export {
  previewRingtone,
  stopRingtonePreview,
  isRingtonePreviewing,
  getSelectedTone,
  setSelectedTone,
  getAlarmVolume,
  setAlarmVolume,
  getCustomAudioInfo,
  setCustomAudioData,
  primeAudioForBackground,
  playTaskCompletionSound,
  getCompletionSoundSetting,
  setCompletionSoundSetting,
  startAlarmChannel,
  stopAlarmChannel,
  stopAllAlarms,
};
export type { SoundOption, CompletionSoundStyle };
