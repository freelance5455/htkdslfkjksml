import test from 'node:test';
import assert from 'node:assert/strict';
import { calculatePlayerAchievements } from './achievementsLogic.ts';
import type { AppState } from '../types/index.ts';

test('Achievements calculation computes unlocks and progress correctly', () => {
  const dummyState: AppState = {
    players: [{ id: 'p1', name: 'Nycollas', color: '#10b981', role: 'player', createdAt: '2026-10-01' }],
    categories: [{ id: 'cat-200g', name: '200g', weightGrams: 200, status: 'active', createdBy: 'p1', isOfficialSafe: true }],
    dailyRecords: [
      { id: '1', playerId: 'p1', categoryId: 'cat-200g', localDate: '2026-10-19', bestStreak: 11, trained: true, attemptsCount: 1, updatedAt: '2026-10-19' },
      { id: '2', playerId: 'p1', categoryId: 'cat-200g', localDate: '2026-10-20', bestStreak: 7, trained: true, attemptsCount: 1, updatedAt: '2026-10-20' },
      { id: '3', playerId: 'p1', categoryId: 'cat-200g', localDate: '2026-10-21', bestStreak: 6, trained: true, attemptsCount: 1, updatedAt: '2026-10-21' },
    ],
    attempts: [],
    seasons: [
      {
        id: 's1',
        name: 'Semana 1',
        startDate: '2026-10-19',
        endDate: '2026-10-25',
        status: 'active',
        timezone: 'America/Sao_Paulo',
      },
    ],
    currentSeasonId: 's1',
    tricks: [
      {
        id: 't1',
        name: 'Flip',
        description: 'flip',
        authorId: 'p1',
        difficulty: 'facil',
        status: 'published',
        createdAt: '2026-10-19',
        executionsByPlayer: { p1: 6 },
      },
    ],
    auditLogs: [],
  };

  const achievements = calculatePlayerAchievements('p1', dummyState);
  
  // rec-5 (streak >= 5) and rec-10 (streak >= 10) should be unlocked because maxStreak is 11
  const rec5 = achievements.find((a) => a.id === 'rec-5');
  assert.equal(rec5?.isUnlocked, true);

  const rec10 = achievements.find((a) => a.id === 'rec-10');
  assert.equal(rec10?.isUnlocked, true);

  const rec15 = achievements.find((a) => a.id === 'rec-15');
  assert.equal(rec15?.isUnlocked, false);
  assert.equal(rec15?.progress.current, 11);

  // con-triplo (3 days in a week) should be unlocked
  const con3 = achievements.find((a) => a.id === 'con-triplo');
  assert.equal(con3?.isUnlocked, true);

  // ger-criador (authored 1 trick) should be unlocked
  const gerCriador = achievements.find((a) => a.id === 'ger-criador');
  assert.equal(gerCriador?.isUnlocked, true);

  // ger-execucoes-5 (validated 6 executions) should be unlocked
  const gerExec = achievements.find((a) => a.id === 'ger-execucoes-5');
  assert.equal(gerExec?.isUnlocked, true);
});
