/**
 * IndexedDB storage engine for NoteFlow
 * Provides high-capacity, durable client-side persistence for notes,
 * large binary attachments, audio recordings, and clips without hitting
 * browser localStorage quota limits (~5MB).
 */

import { Note, TrashItem, ElementSnippet, Attachment } from "../types";

const DB_NAME = "noteflow_db_v2";
const DB_VERSION = 1;

export const IDB_STORES = {
  NOTES: "notes",
  TRASH: "trash",
  CLIPS: "clips",
  ATTACHMENTS: "attachments",
  KEYVAL: "keyval",
} as const;

let dbPromise: Promise<IDBDatabase | null> | null = null;

function isIndexedDBAvailable(): boolean {
  try {
    return typeof window !== "undefined" && typeof window.indexedDB !== "undefined" && !!window.indexedDB;
  } catch {
    return false;
  }
}

/**
 * Open or get cached IndexedDB connection
 */
export function getIDB(): Promise<IDBDatabase | null> {
  if (!isIndexedDBAvailable()) {
    return Promise.resolve(null);
  }

  if (dbPromise) {
    return dbPromise;
  }

  dbPromise = new Promise<IDBDatabase | null>((resolve) => {
    try {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        if (!db.objectStoreNames.contains(IDB_STORES.NOTES)) {
          db.createObjectStore(IDB_STORES.NOTES, { keyPath: "id" });
        }
        if (!db.objectStoreNames.contains(IDB_STORES.TRASH)) {
          db.createObjectStore(IDB_STORES.TRASH, { keyPath: "id" });
        }
        if (!db.objectStoreNames.contains(IDB_STORES.CLIPS)) {
          db.createObjectStore(IDB_STORES.CLIPS, { keyPath: "id" });
        }
        if (!db.objectStoreNames.contains(IDB_STORES.ATTACHMENTS)) {
          db.createObjectStore(IDB_STORES.ATTACHMENTS, { keyPath: "id" });
        }
        if (!db.objectStoreNames.contains(IDB_STORES.KEYVAL)) {
          db.createObjectStore(IDB_STORES.KEYVAL, { keyPath: "key" });
        }
      };

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onerror = (err) => {
        console.warn("IndexedDB open failed (falling back to memory/sanitized localStorage):", err);
        resolve(null);
      };

      request.onblocked = () => {
        console.warn("IndexedDB open blocked by other tabs");
        resolve(null);
      };
    } catch (err) {
      console.warn("IndexedDB initialization exception:", err);
      resolve(null);
    }
  });

  return dbPromise;
}

/**
 * Save all notes into IndexedDB
 */
export async function idbSaveNotes(notes: Note[]): Promise<boolean> {
  const db = await getIDB();
  if (!db) return false;

  return new Promise<boolean>((resolve) => {
    try {
      const tx = db.transaction([IDB_STORES.NOTES, IDB_STORES.ATTACHMENTS], "readwrite");
      const notesStore = tx.objectStore(IDB_STORES.NOTES);
      const attStore = tx.objectStore(IDB_STORES.ATTACHMENTS);

      // Clear existing to keep in sync with current state
      notesStore.clear();

      for (const note of notes) {
        notesStore.put(note);

        // Also save attachments in dedicated store for fast single-file lookup
        if (note.attachments && note.attachments.length > 0) {
          for (const att of note.attachments) {
            if (att.id && att.data) {
              attStore.put({
                id: att.id,
                noteId: note.id,
                name: att.name,
                mime: att.mime,
                size: att.size,
                data: att.data,
              });
            }
          }
        }
      }

      tx.oncomplete = () => resolve(true);
      tx.onerror = (err) => {
        console.warn("idbSaveNotes transaction error:", err);
        resolve(false);
      };
      tx.onabort = () => resolve(false);
    } catch (err) {
      console.warn("idbSaveNotes exception:", err);
      resolve(false);
    }
  });
}

/**
 * Retrieve all notes from IndexedDB
 */
export async function idbGetNotes(): Promise<Note[]> {
  const db = await getIDB();
  if (!db) return [];

  return new Promise<Note[]>((resolve) => {
    try {
      const tx = db.transaction(IDB_STORES.NOTES, "readonly");
      const store = tx.objectStore(IDB_STORES.NOTES);
      const request = store.getAll();

      request.onsuccess = () => {
        const result = request.result;
        resolve(Array.isArray(result) ? result : []);
      };

      request.onerror = () => resolve([]);
    } catch {
      resolve([]);
    }
  });
}

/**
 * Save trash items into IndexedDB
 */
export async function idbSaveTrash(trash: TrashItem[]): Promise<boolean> {
  const db = await getIDB();
  if (!db) return false;

  return new Promise<boolean>((resolve) => {
    try {
      const tx = db.transaction(IDB_STORES.TRASH, "readwrite");
      const store = tx.objectStore(IDB_STORES.TRASH);
      store.clear();
      for (const item of trash) {
        store.put(item);
      }
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

/**
 * Retrieve trash items from IndexedDB
 */
export async function idbGetTrash(): Promise<TrashItem[]> {
  const db = await getIDB();
  if (!db) return [];

  return new Promise<TrashItem[]>((resolve) => {
    try {
      const tx = db.transaction(IDB_STORES.TRASH, "readonly");
      const store = tx.objectStore(IDB_STORES.TRASH);
      const request = store.getAll();

      request.onsuccess = () => {
        resolve(Array.isArray(request.result) ? request.result : []);
      };
      request.onerror = () => resolve([]);
    } catch {
      resolve([]);
    }
  });
}

/**
 * Save element clips into IndexedDB
 */
export async function idbSaveClips(clips: ElementSnippet[]): Promise<boolean> {
  const db = await getIDB();
  if (!db) return false;

  return new Promise<boolean>((resolve) => {
    try {
      const tx = db.transaction(IDB_STORES.CLIPS, "readwrite");
      const store = tx.objectStore(IDB_STORES.CLIPS);
      store.clear();
      for (const clip of clips) {
        store.put(clip);
      }
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

/**
 * Retrieve element clips from IndexedDB
 */
export async function idbGetClips(): Promise<ElementSnippet[]> {
  const db = await getIDB();
  if (!db) return [];

  return new Promise<ElementSnippet[]>((resolve) => {
    try {
      const tx = db.transaction(IDB_STORES.CLIPS, "readonly");
      const store = tx.objectStore(IDB_STORES.CLIPS);
      const request = store.getAll();

      request.onsuccess = () => {
        resolve(Array.isArray(request.result) ? request.result : []);
      };
      request.onerror = () => resolve([]);
    } catch {
      resolve([]);
    }
  });
}

/**
 * Retrieve single attachment from IndexedDB by ID
 */
export async function idbGetAttachment(id: string): Promise<Attachment | null> {
  const db = await getIDB();
  if (!db) return null;

  return new Promise<Attachment | null>((resolve) => {
    try {
      const tx = db.transaction(IDB_STORES.ATTACHMENTS, "readonly");
      const store = tx.objectStore(IDB_STORES.ATTACHMENTS);
      const request = store.get(id);

      request.onsuccess = () => {
        resolve(request.result || null);
      };
      request.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

/**
 * Save arbitrary key-value entry into IndexedDB
 */
export async function idbSetKeyVal<T>(key: string, value: T): Promise<boolean> {
  const db = await getIDB();
  if (!db) return false;

  return new Promise<boolean>((resolve) => {
    try {
      const tx = db.transaction(IDB_STORES.KEYVAL, "readwrite");
      const store = tx.objectStore(IDB_STORES.KEYVAL);
      store.put({ key, value, updatedAt: Date.now() });
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

/**
 * Retrieve arbitrary key-value entry from IndexedDB
 */
export async function idbGetKeyVal<T>(key: string): Promise<T | null> {
  const db = await getIDB();
  if (!db) return null;

  return new Promise<T | null>((resolve) => {
    try {
      const tx = db.transaction(IDB_STORES.KEYVAL, "readonly");
      const store = tx.objectStore(IDB_STORES.KEYVAL);
      const request = store.get(key);

      request.onsuccess = () => {
        resolve(request.result ? (request.result.value as T) : null);
      };
      request.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}
