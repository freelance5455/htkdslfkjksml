import test from 'node:test';
import assert from 'node:assert/strict';
import {
  convertRomajiToHiragana,
  convertKanaToRomaji,
  convertHangulToRoman,
  ensureGermanStructure,
  ensureCompleteGermanTranslation,
  isLocalMatch,
  calculateNextSrs,
  createDefaultLangDeck,
  buildExpressiveTtsStyle,
  verifyGatePassword,
  APP_GATE_PASSWORD,
  type StudyItem,
} from './srsLogic.ts';

test('verifyGatePassword blocks invalid passwords and unlocks only with exact password', () => {
  assert.equal(verifyGatePassword(''), false);
  assert.equal(verifyGatePassword('wrong-password'), false);
  assert.equal(verifyGatePassword('yty.0yintoyou.1yty'), false);
  assert.equal(verifyGatePassword(APP_GATE_PASSWORD), true);
  assert.equal(verifyGatePassword('YtY.0YinToYou.1YtY'), true);
});

test('convertRomajiToHiragana and convertKanaToRomaji work accurately', () => {
  assert.equal(convertRomajiToHiragana('ikitai'), 'いきたい');
  assert.equal(convertRomajiToHiragana('kitte'), 'きって');
  assert.equal(convertKanaToRomaji('いきたい'), 'ikitai');
});

test('convertHangulToRoman converts Korean syllables to Revised Romanization', () => {
  assert.equal(convertHangulToRoman('한국'), 'hanguk');
  assert.equal(convertHangulToRoman('약속'), 'yaksok');
});

test('ensureGermanStructure translates Japanese/Korean grammatical terms into German', () => {
  const jaStruct = ensureGermanStructure('動詞て形＋みる', 'grammar', 'versuchen', '～てみる');
  assert.ok(jaStruct.includes('Verb (Te-Form)'));
  assert.ok(!jaStruct.includes('動詞'));

  const koStruct = ensureGermanStructure('동사 어간 + 고 싶다', 'grammar', 'möchten', '-고 싶다');
  assert.ok(koStruct.includes('Verb'));
  assert.ok(koStruct.includes('Verbstamm'));
});

test('ensureCompleteGermanTranslation fixes incomplete modal German sentences and blanks', () => {
  const fixed1 = ensureCompleteGermanTranslation('Ich werde ihn mal.', 'fragen');
  assert.equal(fixed1, 'Ich werde ihn mal fragen.');

  const fixed2 = ensureCompleteGermanTranslation('Ich habe eine [____] mit einem Freund.', 'Verabredung');
  assert.equal(fixed2, 'Ich habe eine Verabredung mit einem Freund.');
});

test('createDefaultLangDeck creates empty Japanese and Korean decks without pre-made cards and with Kore neural voice', () => {
  const jaDeck = createDefaultLangDeck('ja', false);
  const koDeck = createDefaultLangDeck('ko', false);

  assert.equal(jaDeck.items.length, 0);
  assert.equal(koDeck.items.length, 0);
  assert.equal(jaDeck.aiGenLevel, 'N5');
  assert.equal(koDeck.aiGenLevel, 'T1');
  assert.equal(jaDeck.settings.ttsVoice, 'Kore');
  assert.equal(koDeck.settings.ttsVoice, 'Kore');
  assert.equal(Object.keys(jaDeck.srs).length, 0);
  assert.equal(Object.keys(koDeck.srs).length, 0);
});

test('buildExpressiveTtsStyle generates natural prosody and emphasis instructions for questions, exclamations, and statements', () => {
  const jaQuestion = buildExpressiveTtsStyle('一緒に日本語を練習しましょうか？', 'ja');
  assert.ok(jaQuestion.includes('question'));
  assert.ok(jaQuestion.includes('rising intonation'));

  const koExclam = buildExpressiveTtsStyle('오늘 날씨가 정말 좋네요!', 'ko');
  assert.ok(koExclam.includes('emotional emphasis'));
  assert.ok(koExclam.includes('Korean'));

  const jaStatement = buildExpressiveTtsStyle('明日友達に電話してみます。', 'ja');
  assert.ok(jaStatement.includes('pitch accent'));
  assert.ok(jaStatement.includes('emphasis'));
});

test('isLocalMatch and calculateNextSrs work for both Japanese and Korean items', () => {
  const sampleItem: StudyItem = {
    id: 'ko-custom-1',
    order: 1,
    level: 'T1',
    type: 'grammar',
    jp: '-고 싶다',
    reading: '고 싶다',
    meaning: 'möchten',
    structure: 'Verbstamm + -고 싶다',
    explanation: 'Wunsch ausdrücken',
    clozeJp: '내년에 한국에 [____].',
    clozeDe: 'Nächstes Jahr möchte ich nach Korea reisen.',
    answers: ['가고 싶어요', '가고 싶다'],
    examples: [],
  };
  assert.equal(isLocalMatch(sampleItem, '가고 싶어요', '가고 싶어요'), true);
  assert.equal(isLocalMatch(sampleItem, '틀린답', '틀린답'), false);

  const nextUp = calculateNextSrs({ stage: 1, nextReview: 1000 }, true, 5000);
  assert.equal(nextUp.stage, 2);
  assert.ok(nextUp.nextReview > 5000);
});
