// 100% CORS-safe local sample templates with zero external dependencies
// Generates rich canvas data URLs for instant offline & online photo editing

export function generateSampleCanvas(type: "kolkata" | "himalaya" | "howrah"): string {
  const canvas = document.createElement("canvas");
  canvas.width = 1000;
  canvas.height = 700;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";

  if (type === "kolkata") {
    // Cyberpunk Kolkata futuristic cityscape
    const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
    grad.addColorStop(0, "#08071a");
    grad.addColorStop(0.5, "#1e0b36");
    grad.addColorStop(1, "#3b0764");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Glowing futuristic moon / orb
    const moon = ctx.createRadialGradient(780, 180, 20, 780, 180, 160);
    moon.addColorStop(0, "#06b6d4");
    moon.addColorStop(0.5, "rgba(99, 102, 241, 0.4)");
    moon.addColorStop(1, "transparent");
    ctx.fillStyle = moon;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Neon grid mountains / buildings in distance
    ctx.fillStyle = "#120826";
    ctx.beginPath();
    ctx.moveTo(0, 500);
    ctx.lineTo(150, 320);
    ctx.lineTo(300, 480);
    ctx.lineTo(480, 260);
    ctx.lineTo(650, 440);
    ctx.lineTo(850, 220);
    ctx.lineTo(1000, 420);
    ctx.lineTo(1000, 700);
    ctx.lineTo(0, 700);
    ctx.closePath();
    ctx.fill();

    // Futuristic Howrah Bridge silhouette with cyan glow
    ctx.strokeStyle = "#06b6d4";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(100, 520);
    ctx.lineTo(250, 360);
    ctx.lineTo(750, 360);
    ctx.lineTo(900, 520);
    ctx.stroke();

    // Suspension cables
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = "rgba(6, 182, 212, 0.4)";
    for (let x = 250; x <= 750; x += 35) {
      ctx.beginPath();
      ctx.moveTo(x, 360);
      ctx.lineTo(x, 520);
      ctx.stroke();
    }

    // River Hooghly reflection
    const water = ctx.createLinearGradient(0, 520, 0, canvas.height);
    water.addColorStop(0, "#090d1a");
    water.addColorStop(1, "#030712");
    ctx.fillStyle = water;
    ctx.fillRect(0, 520, canvas.width, 180);

    // Reflection ripples
    ctx.fillStyle = "rgba(6, 182, 212, 0.25)";
    for (let y = 530; y < 690; y += 14) {
      ctx.fillRect(300 + Math.sin(y) * 40, y, 400 - (y - 520) * 1.5, 3);
    }

    // Title tag
    ctx.font = "bold 32px 'Plus Jakarta Sans', sans-serif";
    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "left";
    ctx.fillText("KOLKATA 2026 CYBER", 60, 100);
  } else if (type === "himalaya") {
    // Golden Himalayan Sunrise
    const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
    grad.addColorStop(0, "#451a03");
    grad.addColorStop(0.4, "#9a3412");
    grad.addColorStop(0.7, "#ea580c");
    grad.addColorStop(1, "#fed7aa");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Radiant sun
    const sun = ctx.createRadialGradient(500, 380, 20, 500, 380, 240);
    sun.addColorStop(0, "#fffbeb");
    sun.addColorStop(0.4, "#fef08a");
    sun.addColorStop(1, "transparent");
    ctx.fillStyle = sun;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Mountain peaks
    ctx.fillStyle = "#1c1917";
    ctx.beginPath();
    ctx.moveTo(0, 700);
    ctx.lineTo(0, 520);
    ctx.lineTo(240, 320);
    ctx.lineTo(420, 460);
    ctx.lineTo(600, 260);
    ctx.lineTo(820, 480);
    ctx.lineTo(1000, 360);
    ctx.lineTo(1000, 700);
    ctx.closePath();
    ctx.fill();

    // Snow caps with golden reflection
    ctx.fillStyle = "#fef3c7";
    ctx.beginPath();
    ctx.moveTo(240, 320);
    ctx.lineTo(200, 370);
    ctx.lineTo(280, 370);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(600, 260);
    ctx.lineTo(540, 340);
    ctx.lineTo(650, 340);
    ctx.closePath();
    ctx.fill();

    ctx.font = "bold 32px 'Plus Jakarta Sans', sans-serif";
    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "left";
    ctx.fillText("HIMALAYAN DAWN", 60, 100);
  } else {
    // Historical Heritage Artwork
    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, "#0f172a");
    grad.addColorStop(0.6, "#1e1b4b");
    grad.addColorStop(1, "#312e81");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Vintage decorative arches
    ctx.strokeStyle = "rgba(234, 179, 8, 0.4)";
    ctx.lineWidth = 3;
    for (let x = 100; x < canvas.width; x += 200) {
      ctx.beginPath();
      ctx.arc(x, 400, 80, Math.PI, 0, false);
      ctx.stroke();
      ctx.strokeRect(x - 80, 400, 160, 250);
    }

    ctx.font = "bold 32px 'Plus Jakarta Sans', sans-serif";
    ctx.fillStyle = "#fef08a";
    ctx.textAlign = "left";
    ctx.fillText("HERITAGE ARCHITECTURE", 60, 100);
  }

  return canvas.toDataURL("image/jpeg", 0.9);
}
