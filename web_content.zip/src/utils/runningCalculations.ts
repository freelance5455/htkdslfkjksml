import { SplitLap, GPSCoordinate } from '../types';

/**
 * Calculates great-circle distance between two GPS points using the Haversine formula (in meters).
 */
export function calculateHaversineDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000; // Earth radius in meters
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Formats duration in seconds into MM:SS or HH:MM:SS.
 */
export function formatDuration(totalSeconds: number): string {
  const rounded = Math.floor(totalSeconds);
  const hours = Math.floor(rounded / 3600);
  const minutes = Math.floor((rounded % 3600) / 60);
  const seconds = rounded % 60;

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

/**
 * Formats pace in seconds/km to "M:SS" min/km.
 */
export function formatPace(paceSecPerKm: number): string {
  if (!isFinite(paceSecPerKm) || paceSecPerKm <= 0 || paceSecPerKm > 1800) {
    return '--:--';
  }
  const minutes = Math.floor(paceSecPerKm / 60);
  const seconds = Math.floor(paceSecPerKm % 60);
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

/**
 * Calculates pace from distance (in meters) and duration (in seconds).
 */
export function calculatePace(distanceMeters: number, durationSeconds: number): string {
  if (distanceMeters < 10 || durationSeconds < 2) return '--:--';
  const paceSecPerKm = (durationSeconds / distanceMeters) * 1000;
  return formatPace(paceSecPerKm);
}

/**
 * Converts meters and seconds to km/h speed.
 */
export function calculateSpeedKmh(distanceMeters: number, durationSeconds: number): number {
  if (durationSeconds <= 0 || distanceMeters <= 0) return 0;
  const speed = (distanceMeters / 1000) / (durationSeconds / 3600);
  return Number(speed.toFixed(1));
}

/**
 * Calculates target lap splits for 1600m target time (default 4:50).
 * 4:50 total seconds = 290 seconds.
 * 400m = 72.5s (1:12.5)
 * 800m = 145s (2:25)
 * 1200m = 217.5s (3:37.5)
 * 1600m = 290s (4:50)
 */
export function calculate1600mSplits(targetSeconds: number = 290): {
  distance: string;
  targetSplit: string;
  cumulativeTime: string;
  perLapSeconds: number;
}[] {
  const lapTimeSeconds = targetSeconds / 4;
  return [
    {
      distance: '400m (Lap 1)',
      targetSplit: formatSecondsWithDecimal(lapTimeSeconds),
      cumulativeTime: formatSecondsWithDecimal(lapTimeSeconds),
      perLapSeconds: lapTimeSeconds,
    },
    {
      distance: '800m (Lap 2)',
      targetSplit: formatSecondsWithDecimal(lapTimeSeconds),
      cumulativeTime: formatSecondsWithDecimal(lapTimeSeconds * 2),
      perLapSeconds: lapTimeSeconds,
    },
    {
      distance: '1200m (Lap 3)',
      targetSplit: formatSecondsWithDecimal(lapTimeSeconds),
      cumulativeTime: formatSecondsWithDecimal(lapTimeSeconds * 3),
      perLapSeconds: lapTimeSeconds,
    },
    {
      distance: '1600m (Finish)',
      targetSplit: formatSecondsWithDecimal(lapTimeSeconds),
      cumulativeTime: formatSecondsWithDecimal(targetSeconds),
      perLapSeconds: lapTimeSeconds,
    },
  ];
}

export function formatSecondsWithDecimal(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = (seconds % 60).toFixed(1);
  const paddedSecs = parseFloat(secs) < 10 ? `0${secs}` : secs;
  return mins > 0 ? `${mins}:${paddedSecs}` : `${secs}s`;
}

/**
 * Parse time string like "4:50" or "5:30" or "04:50" into total seconds.
 */
export function parseTimeToSeconds(timeStr: string): number {
  if (!timeStr) return 290;
  const parts = timeStr.trim().split(':');
  if (parts.length === 2) {
    const mins = parseInt(parts[0], 10) || 0;
    const secs = parseFloat(parts[1]) || 0;
    return mins * 60 + secs;
  }
  return parseFloat(timeStr) || 290;
}

/**
 * Calculates custom distance target time given a pace or target 1600m time.
 */
export function calculateCustomDistanceSplit(
  distanceMeters: number,
  target1600mSeconds: number
): { distance: number; timeFormatted: string; totalSeconds: number; paceMinKm: string } {
  // Pace per meter in target 1600m:
  const secPerMeter = target1600mSeconds / 1600;
  const totalSeconds = distanceMeters * secPerMeter;
  const pacePerKm = secPerMeter * 1000;

  return {
    distance: distanceMeters,
    timeFormatted: formatSecondsWithDecimal(totalSeconds),
    totalSeconds,
    paceMinKm: formatPace(pacePerKm),
  };
}

/**
 * Provides current sustainable training paces compared to race target pace.
 * (Crucial requirement: "Display target splits separately from runner's current sustainable training pace. Never force target splits during every workout.")
 */
export function calculateTrainingPaces(baseline1600mSec: number) {
  // Baseline pace per km:
  const basePaceSecKm = (baseline1600mSec / 1600) * 1000;

  return {
    easyAerobicPace: formatPace(basePaceSecKm * 1.35) + ' - ' + formatPace(basePaceSecKm * 1.50),
    tempoLactatePace: formatPace(basePaceSecKm * 1.12) + ' - ' + formatPace(basePaceSecKm * 1.18),
    interval400mPace: formatSecondsWithDecimal((baseline1600mSec / 4) * 0.98), // 400m rep
    recoveryRunPace: formatPace(basePaceSecKm * 1.55),
    targetGoal400mPace: '1:12.5 (Sub 4:50)',
  };
}
