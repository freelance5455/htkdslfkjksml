export interface CollegeDirectoryItem {
  id: string;
  name: string;
  state: string;
  district: string;
  badge: string;
}

export interface StateDistrictMapping {
  state: string;
  districts: {
    district: string;
    colleges: { id: string; name: string; badge: string }[];
  }[];
}

export const INDIA_COLLEGES_DATA: StateDistrictMapping[] = [
  {
    state: "Delhi",
    districts: [
      {
        district: "North Delhi",
        colleges: [
          { id: "del-nd-1", name: "Delhi University (North Campus)", badge: "🏛️" },
          { id: "del-nd-2", name: "St. Stephen's College", badge: "🎓" },
          { id: "del-nd-3", name: "Hindu College", badge: "🌟" },
          { id: "del-nd-4", name: "Shri Ram College of Commerce (SRCC)", badge: "📊" },
          { id: "del-nd-5", name: "Miranda House", badge: "👑" },
          { id: "del-nd-6", name: "Hansraj College", badge: "📚" },
          { id: "del-nd-7", name: "Kirori Mal College (KMC)", badge: "🎭" },
          { id: "del-nd-8", name: "Ramjas College", badge: "🏛️" },
          { id: "del-nd-9", name: "Faculty of Law, Delhi University", badge: "⚖️" },
          { id: "del-nd-10", name: "Delhi School of Economics (DSE)", badge: "📈" },
        ]
      },
      {
        district: "South Delhi",
        colleges: [
          { id: "del-sd-1", name: "IIT Delhi (Indian Institute of Technology)", badge: "⚡" },
          { id: "del-sd-2", name: "AIIMS New Delhi", badge: "🩺" },
          { id: "del-sd-3", name: "Jawaharlal Nehru University (JNU)", badge: "🌍" },
          { id: "del-sd-4", name: "Jamia Millia Islamia", badge: "🕌" },
          { id: "del-sd-5", name: "Lady Shri Ram College (LSR)", badge: "🌸" },
          { id: "del-sd-6", name: "Sri Venkateswara College (Venky)", badge: "✨" },
          { id: "del-sd-7", name: "Gargi College", badge: "📚" },
          { id: "del-sd-8", name: "Shaheed Bhagat Singh College", badge: "🎯" },
          { id: "del-sd-9", name: "Atma Ram Sanatan Dharma College (ARSD)", badge: "🌟" },
          { id: "del-sd-10", name: "Motilal Nehru College", badge: "🏛️" },
        ]
      },
      {
        district: "West Delhi",
        colleges: [
          { id: "del-wd-1", name: "Netaji Subhas University of Technology (NSUT)", badge: "🚀" },
          { id: "del-wd-2", name: "Shivaji College", badge: "🏛️" },
          { id: "del-wd-3", name: "Rajdhani College", badge: "📚" },
          { id: "del-wd-4", name: "Deen Dayal Upadhyaya College", badge: "🎯" },
        ]
      },
      {
        district: "Central & East Delhi",
        colleges: [
          { id: "del-ce-1", name: "Delhi Technological University (DTU)", badge: "🔥" },
          { id: "del-ce-2", name: "Indira Gandhi Delhi Technical University for Women (IGDTUW)", badge: "💎" },
          { id: "del-ce-3", name: "Maulana Azad Medical College (MAMC)", badge: "🩺" },
          { id: "del-ce-4", name: "Zakir Husain Delhi College", badge: "📚" },
          { id: "del-ce-5", name: "Ambedkar University Delhi (AUD)", badge: "🎨" },
        ]
      }
    ]
  },
  {
    state: "Uttar Pradesh",
    districts: [
      {
        district: "Mathura",
        colleges: [
          { id: "up-mth-1", name: "GLA University Mathura", badge: "🏛️" },
          { id: "up-mth-2", name: "Babu Shivnath Agrawal College (BSA College Mathura)", badge: "📚" },
          { id: "up-mth-3", name: "Sanskriti University Mathura", badge: "🌟" },
          { id: "up-mth-4", name: "K.D. Medical College Hospital & Research Centre Mathura", badge: "🩺" },
          { id: "up-mth-5", name: "Sachdeva Institute of Technology (SIT Mathura)", badge: "💻" },
          { id: "up-mth-6", name: "UP Pt. Deen Dayal Upadhyaya Veterinary University (DUVASU)", badge: "🐾" },
          { id: "up-mth-7", name: "Rajiv Academy for Technology & Management (RATM)", badge: "🎯" },
          { id: "up-mth-8", name: "K.R. (PG) Girls College Mathura", badge: "🌸" },
          { id: "up-mth-9", name: "Eshan Group of Institutions Mathura", badge: "⚙️" },
          { id: "up-mth-10", name: "Cosmos College of Management & Computer Tech Mathura", badge: "🌐" }
        ]
      },
      {
        district: "Gautam Buddha Nagar (Noida / Greater Noida)",
        colleges: [
          { id: "up-noida-1", name: "Amity University (Noida Sector 125)", badge: "🚀" },
          { id: "up-noida-2", name: "Bennett University (Greater Noida)", badge: "💎" },
          { id: "up-noida-3", name: "Galgotias University", badge: "⚡" },
          { id: "up-noida-4", name: "Sharda University", badge: "🌐" },
          { id: "up-noida-5", name: "JSS Academy of Technical Education", badge: "💻" },
          { id: "up-noida-6", name: "Shiv Nadar University (SNU)", badge: "🔬" },
          { id: "up-noida-7", name: "Noida Institute of Engineering & Technology (NIET)", badge: "⚙️" },
          { id: "up-noida-8", name: "GL Bajaj Institute of Technology & Management", badge: "🎯" },
          { id: "up-noida-9", name: "Jaypee Institute of Information Technology (JIIT)", badge: "🖥️" },
          { id: "up-noida-10", name: "Gautam Buddha University (GBU Greater Noida)", badge: "🏛️" }
        ]
      },
      {
        district: "Lucknow",
        colleges: [
          { id: "up-lko-1", name: "University of Lucknow", badge: "🏛️" },
          { id: "up-lko-2", name: "Institute of Engineering & Technology (IET Lucknow)", badge: "⚡" },
          { id: "up-lko-3", name: "King George's Medical University (KGMU)", badge: "🩺" },
          { id: "up-lko-4", name: "Dr. A.P.J. Abdul Kalam Technical University (AKTU)", badge: "💻" },
          { id: "up-lko-5", name: "Babasaheb Bhimrao Ambedkar University (BBAU)", badge: "📚" },
          { id: "up-lko-6", name: "Indian Institute of Management Lucknow (IIM-L)", badge: "💼" },
          { id: "up-lko-7", name: "National P.G. College Lucknow", badge: "🎓" },
          { id: "up-lko-8", name: "BBD University (Babu Banarasi Das)", badge: "🌟" },
          { id: "up-lko-9", name: "Integral University Lucknow", badge: "🕌" },
          { id: "up-lko-10", name: "Amity University Lucknow Campus", badge: "🚀" }
        ]
      },
      {
        district: "Kanpur Nagar",
        colleges: [
          { id: "up-knp-1", name: "IIT Kanpur (Indian Institute of Technology)", badge: "🔥" },
          { id: "up-knp-2", name: "Harcourt Butler Technical University (HBTU)", badge: "⚙️" },
          { id: "up-knp-3", name: "Chhatrapati Shahu Ji Maharaj University (CSJMU)", badge: "🏛️" },
          { id: "up-knp-4", name: "GSVM Medical College Kanpur", badge: "🩺" },
          { id: "up-knp-5", name: "Pranveer Singh Institute of Technology (PSIT)", badge: "💻" },
          { id: "up-knp-6", name: "Christ Church College Kanpur", badge: "📚" },
          { id: "up-knp-7", name: "D.A.V. College Kanpur", badge: "🎓" }
        ]
      },
      {
        district: "Varanasi",
        colleges: [
          { id: "up-vns-1", name: "IIT (BHU) Varanasi", badge: "🕉️" },
          { id: "up-vns-2", name: "Banaras Hindu University (BHU Main Campus)", badge: "🏛️" },
          { id: "up-vns-3", name: "Institute of Medical Sciences (IMS BHU)", badge: "🩺" },
          { id: "up-vns-4", name: "Mahatma Gandhi Kashi Vidyapith (MGKVP)", badge: "📚" },
          { id: "up-vns-5", name: "Udai Pratap Autonomous College (UP College)", badge: "🎓" },
          { id: "up-vns-6", name: "Sampurnanand Sanskrit Vishwavidyalaya", badge: "📜" },
          { id: "up-vns-7", name: "Harish Chandra Post Graduate College", badge: "✨" }
        ]
      },
      {
        district: "Prayagraj (Allahabad)",
        colleges: [
          { id: "up-ald-1", name: "MNNIT Allahabad (Motilal Nehru National NIT)", badge: "⚡" },
          { id: "up-ald-2", name: "University of Allahabad (Oxford of the East)", badge: "🏛️" },
          { id: "up-ald-3", name: "IIIT Allahabad (Indian Institute of Information Tech)", badge: "💻" },
          { id: "up-ald-4", name: "Motilal Nehru Medical College (MLNMC)", badge: "🩺" },
          { id: "up-ald-5", name: "Ewing Christian College (ECC)", badge: "🎓" },
          { id: "up-ald-6", name: "Sam Higginbottom Univ of Agri, Tech & Sciences (SHUATS)", badge: "🌱" }
        ]
      },
      {
        district: "Agra",
        colleges: [
          { id: "up-agr-1", name: "Dayalbagh Educational Institute (DEI)", badge: "🌟" },
          { id: "up-agr-2", name: "Dr. B.R. Ambedkar University (Agra University)", badge: "🏛️" },
          { id: "up-agr-3", name: "SN Medical College Agra", badge: "🩺" },
          { id: "up-agr-4", name: "Agra College Agra", badge: "📚" },
          { id: "up-agr-5", name: "St. John's College Agra", badge: "🎓" },
          { id: "up-agr-6", name: "Anand Engineering College Agra", badge: "⚙️" },
          { id: "up-agr-7", name: "Raja Balwant Singh College (RBS College)", badge: "🌾" }
        ]
      },
      {
        district: "Aligarh",
        colleges: [
          { id: "up-alg-1", name: "Aligarh Muslim University (AMU)", badge: "🏛️" },
          { id: "up-alg-2", name: "Zakir Husain College of Engineering & Technology", badge: "⚡" },
          { id: "up-alg-3", name: "Jawaharlal Nehru Medical College (JNMC AMU)", badge: "🩺" },
          { id: "up-alg-4", name: "Raja Mahendra Pratap Singh State University", badge: "🎓" },
          { id: "up-alg-5", name: "Dharma Samaj Degree College (DS College)", badge: "📚" },
          { id: "up-alg-6", name: "Shri Varshney College Aligarh", badge: "🎯" }
        ]
      },
      {
        district: "Meerut",
        colleges: [
          { id: "up-mrt-1", name: "Chaudhary Charan Singh University (CCSU)", badge: "🏛️" },
          { id: "up-mrt-2", name: "Meerut Institute of Engineering & Technology (MIET)", badge: "💻" },
          { id: "up-mrt-3", name: "Shobhit University", badge: "🌟" },
          { id: "up-mrt-4", name: "LLRM Medical College", badge: "🩺" },
          { id: "up-mrt-5", name: "Meerut College Meerut", badge: "📚" },
          { id: "up-mrt-6", name: "Swami Vivekanand Subharti University", badge: "🎓" },
          { id: "up-mrt-7", name: "IIMT University Meerut", badge: "⚙️" }
        ]
      },
      {
        district: "Ghaziabad",
        colleges: [
          { id: "up-gzb-1", name: "KIET Group of Institutions", badge: "⚡" },
          { id: "up-gzb-2", name: "ABES Engineering College", badge: "💻" },
          { id: "up-gzb-3", name: "Ajay Kumar Garg Engineering College (AKGEC)", badge: "⚙️" },
          { id: "up-gzb-4", name: "IMS Ghaziabad", badge: "💼" },
          { id: "up-gzb-5", name: "SRM University (NCR Campus)", badge: "🚀" },
          { id: "up-gzb-6", name: "Krishna Engineering College", badge: "🎯" }
        ]
      },
      {
        district: "Gorakhpur",
        colleges: [
          { id: "up-gkp-1", name: "Madan Mohan Malaviya University of Tech (MMMUT)", badge: "⚡" },
          { id: "up-gkp-2", name: "Deen Dayal Upadhyaya Gorakhpur University (DDU)", badge: "🏛️" },
          { id: "up-gkp-3", name: "AIIMS Gorakhpur", badge: "🩺" },
          { id: "up-gkp-4", name: "BRD Medical College Gorakhpur", badge: "💉" },
          { id: "up-gkp-5", name: "St. Andrew's College Gorakhpur", badge: "📚" }
        ]
      },
      {
        district: "Bareilly",
        colleges: [
          { id: "up-bly-1", name: "M.J.P. Rohilkhand University Bareilly", badge: "🏛️" },
          { id: "up-bly-2", name: "Bareilly College Bareilly", badge: "📚" },
          { id: "up-bly-3", name: "Invertis University Bareilly", badge: "🌟" },
          { id: "up-bly-4", name: "Rohilkhand Medical College & Hospital", badge: "🩺" },
          { id: "up-bly-5", name: "SRMS Institute of Medical & Engg Sciences", badge: "⚙️" }
        ]
      },
      {
        district: "Moradabad",
        colleges: [
          { id: "up-mrd-1", name: "Teerthanker Mahaveer University (TMU)", badge: "🏛️" },
          { id: "up-mrd-2", name: "Hindu College Moradabad", badge: "📚" },
          { id: "up-mrd-3", name: "Moradabad Institute of Technology (MIT)", badge: "💻" },
          { id: "up-mrd-4", name: "Gokaldas Hindu Girls PG College", badge: "🌸" }
        ]
      },
      {
        district: "Saharanpur",
        colleges: [
          { id: "up-shn-1", name: "Maa Shakumbhari University Saharanpur", badge: "🏛️" },
          { id: "up-shn-2", name: "IIT Roorkee (Saharanpur Campus)", badge: "🔬" },
          { id: "up-shn-3", name: "J.V. Jain PG College Saharanpur", badge: "📚" },
          { id: "up-shn-4", name: "Glocal University Saharanpur", badge: "🌐" }
        ]
      },
      {
        district: "Jhansi",
        colleges: [
          { id: "up-jhs-1", name: "Bundelkhand University (BU Jhansi)", badge: "🏛️" },
          { id: "up-jhs-2", name: "Bundelkhand Institute of Engg & Tech (BIET)", badge: "⚙️" },
          { id: "up-jhs-3", name: "Maharani Laxmi Bai Medical College Jhansi", badge: "🩺" },
          { id: "up-jhs-4", name: "Bipin Bihari PG College Jhansi", badge: "📚" }
        ]
      },
      {
        district: "Ayodhya (Faizabad)",
        colleges: [
          { id: "up-ayd-1", name: "Dr. Ram Manohar Lohia Avadh University (RMLAU)", badge: "🏛️" },
          { id: "up-ayd-2", name: "Acharya Narendra Deva Univ of Agriculture & Tech", badge: "🌱" },
          { id: "up-ayd-3", name: "KS Saket PG College Ayodhya", badge: "📚" },
          { id: "up-ayd-4", name: "Rajarshi Dashrath Autonomous State Medical College", badge: "🩺" }
        ]
      },
      {
        district: "Firozabad",
        colleges: [
          { id: "up-frz-1", name: "SRK PG College Firozabad", badge: "📚" },
          { id: "up-frz-2", name: "Autonomous State Medical College Firozabad", badge: "🩺" },
          { id: "up-frz-3", name: "M.G. Balika PG College Firozabad", badge: "🌸" }
        ]
      },
      {
        district: "Muzaffarnagar",
        colleges: [
          { id: "up-mzn-1", name: "Sanatan Dharma PG College (SD College)", badge: "📚" },
          { id: "up-mzn-2", name: "DAV College Muzaffarnagar", badge: "🎓" },
          { id: "up-mzn-3", name: "Muzaffarnagar Medical College", badge: "🩺" }
        ]
      },
      {
        district: "Budaun",
        colleges: [
          { id: "up-bdn-1", name: "Government Medical College Budaun", badge: "🩺" },
          { id: "up-bdn-2", name: "NMSN Das PG College Budaun", badge: "📚" },
          { id: "up-bdn-3", name: "Gindo Devi Mahila PG College Budaun", badge: "🌸" }
        ]
      },
      {
        district: "Shahjahanpur",
        colleges: [
          { id: "up-shj-1", name: "Gandhi Faizi PG College (GF College)", badge: "📚" },
          { id: "up-shj-2", name: "Varun Arjun Medical College & Hospital", badge: "🩺" },
          { id: "up-shj-3", name: "Swami Shukdevanand PG College (SS College)", badge: "🎓" }
        ]
      },
      {
        district: "Rampur",
        colleges: [
          { id: "up-rmp-1", name: "Government Raza PG College Rampur", badge: "📚" },
          { id: "up-rmp-2", name: "Mohammad Ali Jauhar University Rampur", badge: "🏛️" }
        ]
      },
      {
        district: "Pilibhit",
        colleges: [
          { id: "up-plb-1", name: "Upadhi PG College Pilibhit", badge: "📚" },
          { id: "up-plb-2", name: "Autonomous State Medical College Pilibhit", badge: "🩺" }
        ]
      },
      {
        district: "Bijnor",
        colleges: [
          { id: "up-bjn-1", name: "Vardhaman College Bijnor", badge: "📚" },
          { id: "up-bjn-2", name: "Krishna College Bijnor", badge: "🎓" },
          { id: "up-bjn-3", name: "Vivek College of Technical Education", badge: "⚙️" }
        ]
      },
      {
        district: "Amroha",
        colleges: [
          { id: "up-amr-1", name: "J.S. Hindu PG College Amroha", badge: "📚" },
          { id: "up-amr-2", name: "Hashmi Girls PG College Amroha", badge: "🌸" }
        ]
      },
      {
        district: "Sambhal",
        colleges: [
          { id: "up-smb-1", name: "M.G.M. PG College Sambhal", badge: "📚" },
          { id: "up-smb-2", name: "Government Degree College Sambhal", badge: "🎓" }
        ]
      },
      {
        district: "Hapur",
        colleges: [
          { id: "up-hpr-1", name: "S.S.V. PG College Hapur", badge: "📚" },
          { id: "up-hpr-2", name: "Saraswathi Institute of Medical Sciences (SIMS)", badge: "🩺" },
          { id: "up-hpr-3", name: "Monad University Hapur", badge: "🏛️" }
        ]
      },
      {
        district: "Bulandshahr",
        colleges: [
          { id: "up-bls-1", name: "I.P. PG College Bulandshahr", badge: "📚" },
          { id: "up-bls-2", name: "D.N. PG College Gulaothi Bulandshahr", badge: "🎓" },
          { id: "up-bls-3", name: "Government Medical College Bulandshahr", badge: "🩺" }
        ]
      },
      {
        district: "Baghpat",
        colleges: [
          { id: "up-bgp-1", name: "Janta Vedic College Baraut Baghpat", badge: "🌾" },
          { id: "up-bgp-2", name: "D.J. College of Dental Sciences & Research", badge: "🦷" }
        ]
      },
      {
        district: "Shamli",
        colleges: [
          { id: "up-shm-1", name: "Rashtriya Kisan PG College Shamli", badge: "🌾" },
          { id: "up-shm-2", name: "V.V. PG College Shamli", badge: "📚" }
        ]
      },
      {
        district: "Hathras",
        colleges: [
          { id: "up-htr-1", name: "Seth Phool Chand Bagla PG College Hathras", badge: "📚" },
          { id: "up-htr-2", name: "P.B.A.S. PG College Hathras", badge: "🎓" }
        ]
      },
      {
        district: "Etah",
        colleges: [
          { id: "up-eth-1", name: "Jawahar Lal Nehru PG College Etah", badge: "📚" },
          { id: "up-eth-2", name: "Autonomous State Medical College Etah", badge: "🩺" }
        ]
      },
      {
        district: "Kasganj",
        colleges: [
          { id: "up-ksg-1", name: "K.A. PG College Kasganj", badge: "📚" },
          { id: "up-ksg-2", name: "Ganesh Shankar Vidyarthi PG College Kasganj", badge: "🎓" }
        ]
      },
      {
        district: "Mainpuri",
        colleges: [
          { id: "up-mnp-1", name: "National PG College Bhogaon Mainpuri", badge: "📚" },
          { id: "up-mnp-2", name: "Ch. Charan Singh Degree College Mainpuri", badge: "🎓" }
        ]
      },
      {
        district: "Etawah",
        colleges: [
          { id: "up-etw-1", name: "UP University of Medical Sciences (UPUMS Saifai)", badge: "🩺" },
          { id: "up-etw-2", name: "Baba Saheb Dr. B.R. Ambedkar Agri Engg College", badge: "⚙️" },
          { id: "up-etw-3", name: "K.K. PG College Etawah", badge: "📚" }
        ]
      },
      {
        district: "Auraiya",
        colleges: [
          { id: "up-aur-1", name: "Tilak Mahavidyalaya Auraiya", badge: "📚" },
          { id: "up-aur-2", name: "Janta Mahavidyalaya Ajitmal Auraiya", badge: "🎓" }
        ]
      },
      {
        district: "Farrukhabad",
        colleges: [
          { id: "up-fbd-1", name: "Badri Vishal PG College Farrukhabad", badge: "📚" },
          { id: "up-fbd-2", name: "D.N. College Fatehgarh Farrukhabad", badge: "🎓" }
        ]
      },
      {
        district: "Kannauj",
        colleges: [
          { id: "up-knj-1", name: "Government Medical College Kannauj", badge: "🩺" },
          { id: "up-knj-2", name: "P.S.M. PG College Kannauj", badge: "📚" }
        ]
      },
      {
        district: "Kanpur Dehat",
        colleges: [
          { id: "up-kpd-1", name: "Akbarpur Degree College Kanpur Dehat", badge: "📚" },
          { id: "up-kpd-2", name: "Government Medical College Kanpur Dehat", badge: "🩺" }
        ]
      },
      {
        district: "Fatehpur",
        colleges: [
          { id: "up-ftp-1", name: "Mahatma Gandhi PG College Fatehpur", badge: "📚" },
          { id: "up-ftp-2", name: "Autonomous State Medical College Fatehpur", badge: "🩺" }
        ]
      },
      {
        district: "Raebareli",
        colleges: [
          { id: "up-rbl-1", name: "AIIMS Raebareli", badge: "🩺" },
          { id: "up-rbl-2", name: "Feroze Gandhi Institute of Engg & Tech (FGIET)", badge: "⚙️" },
          { id: "up-rbl-3", name: "Feroze Gandhi College Raebareli", badge: "📚" },
          { id: "up-rbl-4", name: "National Institute of Pharmaceutical Ed (NIPER)", badge: "💊" }
        ]
      },
      {
        district: "Sitapur",
        colleges: [
          { id: "up-stp-1", name: "R.M.P. PG College Sitapur", badge: "📚" },
          { id: "up-stp-2", name: "Sacred Heart Degree College Sitapur", badge: "🎓" }
        ]
      },
      {
        district: "Hardoi",
        colleges: [
          { id: "up-hrd-1", name: "C.S.N. PG College Hardoi", badge: "📚" },
          { id: "up-hrd-2", name: "Autonomous State Medical College Hardoi", badge: "🩺" },
          { id: "up-hrd-3", name: "Arya Kanya PG College Hardoi", badge: "🌸" }
        ]
      },
      {
        district: "Lakhimpur Kheri",
        colleges: [
          { id: "up-lkh-1", name: "Yuvraj Datta PG College Lakhimpur Kheri", badge: "📚" },
          { id: "up-lkh-2", name: "Cane Growers Nehru PG College Gola Gokaran Nath", badge: "🌾" }
        ]
      },
      {
        district: "Unnao",
        colleges: [
          { id: "up-unn-1", name: "D.S.N. PG College Unnao", badge: "📚" },
          { id: "up-unn-2", name: "Government Degree College Unnao", badge: "🎓" }
        ]
      },
      {
        district: "Barabanki",
        colleges: [
          { id: "up-bbk-1", name: "Jawaharlal Nehru Memorial PG College Barabanki", badge: "📚" },
          { id: "up-bbk-2", name: "Mayo Institute of Medical Sciences Barabanki", badge: "🩺" },
          { id: "up-bbk-3", name: "Hind Institute of Medical Sciences Barabanki", badge: "💉" }
        ]
      },
      {
        district: "Amethi",
        colleges: [
          { id: "up-amt-1", name: "Rajiv Gandhi Institute of Petroleum Tech (RGIPT)", badge: "🛢️" },
          { id: "up-amt-2", name: "Ranvir Rananjay Post Graduate College Amethi", badge: "📚" }
        ]
      },
      {
        district: "Sultanpur",
        colleges: [
          { id: "up-slt-1", name: "Kamla Nehru Institute of Technology (KNIT Sultanpur)", badge: "⚙️" },
          { id: "up-slt-2", name: "KNIPSS Sultanpur", badge: "💻" },
          { id: "up-slt-3", name: "Ganpat Sahai PG College Sultanpur", badge: "📚" }
        ]
      },
      {
        district: "Ambedkar Nagar",
        colleges: [
          { id: "up-abn-1", name: "Rajkiya Engineering College (REC Ambedkar Nagar)", badge: "⚙️" },
          { id: "up-abn-2", name: "Mahamaya Rajkiya Allopathic Medical College", badge: "🩺" },
          { id: "up-abn-3", name: "B.N.K.B. PG College Akbarpur", badge: "📚" }
        ]
      },
      {
        district: "Basti",
        colleges: [
          { id: "up-bst-1", name: "A.P.N. PG College Basti", badge: "📚" },
          { id: "up-bst-2", name: "Autonomous State Medical College Basti", badge: "🩺" },
          { id: "up-bst-3", name: "Mahila Mahavidyalaya Basti", badge: "🌸" }
        ]
      },
      {
        district: "Sant Kabir Nagar",
        colleges: [
          { id: "up-skn-1", name: "Hira Lal Ram Niwas PG College Khalilabad", badge: "📚" },
          { id: "up-skn-2", name: "Government Degree College Khalilabad", badge: "🎓" }
        ]
      },
      {
        district: "Siddharthnagar",
        colleges: [
          { id: "up-sdn-1", name: "Siddharth University Kapilvastu", badge: "🏛️" },
          { id: "up-sdn-2", name: "Madhav Prasad Tripathi State Medical College", badge: "🩺" }
        ]
      },
      {
        district: "Maharajganj",
        colleges: [
          { id: "up-mrj-1", name: "Jawaharlal Nehru PG College Maharajganj", badge: "📚" },
          { id: "up-mrj-2", name: "Maharajganj Medical College", badge: "🩺" }
        ]
      },
      {
        district: "Kushinagar",
        colleges: [
          { id: "up-ksn-1", name: "Buddha PG College Kushinagar", badge: "☸️" },
          { id: "up-ksn-2", name: "Autonomous State Medical College Kushinagar", badge: "🩺" }
        ]
      },
      {
        district: "Deoria",
        colleges: [
          { id: "up-deo-1", name: "B.R.D. PG College Deoria", badge: "📚" },
          { id: "up-deo-2", name: "Maharshi Devraha Baba State Medical College", badge: "🩺" },
          { id: "up-deo-3", name: "Sant Vinoba PG College Deoria", badge: "🎓" }
        ]
      },
      {
        district: "Azamgarh",
        colleges: [
          { id: "up-azm-1", name: "Maharaja Suhel Dev State University Azamgarh", badge: "🏛️" },
          { id: "up-azm-2", name: "Shibli National College Azamgarh", badge: "📚" },
          { id: "up-azm-3", name: "Government Medical College Chakpanchanpur", badge: "🩺" },
          { id: "up-azm-4", name: "Rajkiya Engineering College Azamgarh", badge: "⚙️" }
        ]
      },
      {
        district: "Mau",
        colleges: [
          { id: "up-mau-1", name: "DCSK PG College Mau", badge: "📚" },
          { id: "up-mau-2", name: "Sarvoday PG College Ghosi Mau", badge: "🎓" }
        ]
      },
      {
        district: "Ballia",
        colleges: [
          { id: "up-bla-1", name: "Jananayak Chandrashekhar University (JNCU Ballia)", badge: "🏛️" },
          { id: "up-bla-2", name: "Satish Chandra PG College Ballia", badge: "📚" },
          { id: "up-bla-3", name: "T.D. College Ballia", badge: "🎓" }
        ]
      },
      {
        district: "Jaunpur",
        colleges: [
          { id: "up-jnp-1", name: "Veer Bahadur Singh Purvanchal University (VBSPU)", badge: "🏛️" },
          { id: "up-jnp-2", name: "Tilak Dhari PG College (TD College Jaunpur)", badge: "📚" },
          { id: "up-jnp-3", name: "Prasad Institute of Technology Jaunpur", badge: "💻" },
          { id: "up-jnp-4", name: "Raja Harpal Singh PG College Jaunpur", badge: "🎓" }
        ]
      },
      {
        district: "Ghazipur",
        colleges: [
          { id: "up-gzp-1", name: "Post Graduate College Ghazipur (PG College)", badge: "📚" },
          { id: "up-gzp-2", name: "Maharshi Vishwamitra Autonomous State Medical College", badge: "🩺" },
          { id: "up-gzp-3", name: "Technical Education Research Institute (TERI)", badge: "💻" }
        ]
      },
      {
        district: "Chandauli",
        colleges: [
          { id: "up-chd-1", name: "L.B.S. PG College Mughalsarai Chandauli", badge: "📚" },
          { id: "up-chd-2", name: "Autonomous State Medical College Chandauli", badge: "🩺" }
        ]
      },
      {
        district: "Mirzapur",
        colleges: [
          { id: "up-mzp-1", name: "K.B. PG College Mirzapur", badge: "📚" },
          { id: "up-mzp-2", name: "Maa Vindhyavasini Autonomous State Medical College", badge: "🩺" },
          { id: "up-mzp-3", name: "G.D. Binani PG College Mirzapur", badge: "💼" }
        ]
      },
      {
        district: "Sonbhadra",
        colleges: [
          { id: "up-snb-1", name: "Rajkiya Engineering College Sonbhadra", badge: "⚙️" },
          { id: "up-snb-2", name: "Government PG College Obra Sonbhadra", badge: "📚" },
          { id: "up-snb-3", name: "Autonomous State Medical College Sonbhadra", badge: "🩺" }
        ]
      },
      {
        district: "Bhadohi (Sant Ravidas Nagar)",
        colleges: [
          { id: "up-bdh-1", name: "Indian Institute of Carpet Technology (IICT Bhadohi)", badge: "🧵" },
          { id: "up-bdh-2", name: "K.N. Government PG College Gyanpur Bhadohi", badge: "📚" }
        ]
      },
      {
        district: "Kaushambi",
        colleges: [
          { id: "up-ksh-1", name: "Bhavans Mehta Mahavidyalaya Bharwari Kaushambi", badge: "📚" },
          { id: "up-ksh-2", name: "Autonomous State Medical College Kaushambi", badge: "🩺" }
        ]
      },
      {
        district: "Pratapgarh",
        colleges: [
          { id: "up-ptp-1", name: "P.B. PG College Pratapgarh", badge: "📚" },
          { id: "up-ptp-2", name: "Autonomous State Medical College Pratapgarh", badge: "🩺" },
          { id: "up-ptp-3", name: "Munishwar Dutt PG College Pratapgarh", badge: "🎓" }
        ]
      },
      {
        district: "Jalaun (Orai)",
        colleges: [
          { id: "up-jln-1", name: "Government Medical College Jalaun (Orai)", badge: "🩺" },
          { id: "up-jln-2", name: "Dayanand Vedic College (DV College Orai)", badge: "📚" }
        ]
      },
      {
        district: "Hamirpur",
        colleges: [
          { id: "up-hmr-1", name: "B.N.V. PG College Rath Hamirpur", badge: "📚" },
          { id: "up-hmr-2", name: "Government PG College Hamirpur", badge: "🎓" }
        ]
      },
      {
        district: "Mahoba",
        colleges: [
          { id: "up-mhb-1", name: "Veer Bhumi Government PG College Mahoba", badge: "📚" },
          { id: "up-mhb-2", name: "Government Degree College Charkhari", badge: "🎓" }
        ]
      },
      {
        district: "Banda",
        colleges: [
          { id: "up-bnd-1", name: "Banda University of Agriculture & Tech (BUAT)", badge: "🌱" },
          { id: "up-bnd-2", name: "Pt. J.N. PG College Banda", badge: "📚" },
          { id: "up-bnd-3", name: "Government Medical College Banda", badge: "🩺" },
          { id: "up-bnd-4", name: "Rajkiya Engineering College Banda", badge: "⚙️" }
        ]
      },
      {
        district: "Chitrakoot",
        colleges: [
          { id: "up-ckt-1", name: "Jagadguru Rambhadracharya Divyang University (JRDU)", badge: "🕉️" },
          { id: "up-ckt-2", name: "Goswami Tulsidas Government PG College Karwi", badge: "📚" }
        ]
      },
      {
        district: "Bahraich",
        colleges: [
          { id: "up-bhr-1", name: "Kisan PG College Bahraich", badge: "🌾" },
          { id: "up-bhr-2", name: "Maharshi Balark Autonomous State Medical College", badge: "🩺" },
          { id: "up-bhr-3", name: "Mahila PG College Bahraich", badge: "🌸" }
        ]
      },
      {
        district: "Shrawasti",
        colleges: [
          { id: "up-srw-1", name: "Government Degree College Bhinga Shrawasti", badge: "🎓" },
          { id: "up-srw-2", name: "Al-Haj Shamsuddin Memorial Degree College", badge: "📚" }
        ]
      },
      {
        district: "Balrampur",
        colleges: [
          { id: "up-blm-1", name: "M.L.K. PG College Balrampur", badge: "📚" },
          { id: "up-blm-2", name: "Autonomous State Medical College Balrampur", badge: "🩺" }
        ]
      },
      {
        district: "Gonda",
        colleges: [
          { id: "up-gnd-1", name: "Maa Pateshwari State University Gonda", badge: "🏛️" },
          { id: "up-gnd-2", name: "Lal Bahadur Shastri PG College (LBS Gonda)", badge: "📚" },
          { id: "up-gnd-3", name: "Autonomous State Medical College Gonda", badge: "🩺" }
        ]
      }
    ]
  },
  {
    state: "Maharashtra",
    districts: [
      {
        district: "Mumbai & Suburban",
        colleges: [
          { id: "mh-mum-1", name: "IIT Bombay (Powai)", badge: "⚡" },
          { id: "mh-mum-2", name: "University of Mumbai (Fort & Kalina)", badge: "🏛️" },
          { id: "mh-mum-3", name: "St. Xavier's College Mumbai", badge: "🎓" },
          { id: "mh-mum-4", name: "Veermata Jijabai Technological Institute (VJTI)", badge: "⚙️" },
          { id: "mh-mum-5", name: "NMIMS Mumbai (Mukesh Patel / ASMSOC)", badge: "💼" },
          { id: "mh-mum-6", name: "Mithibai College (Vile Parle)", badge: "🌟" },
          { id: "mh-mum-7", name: "Sardar Patel Institute of Technology (SPIT)", badge: "💻" },
          { id: "mh-mum-8", name: "H.R. College of Commerce & Economics", badge: "📊" },
          { id: "mh-mum-9", name: "Jai Hind College", badge: "✨" },
          { id: "mh-mum-10", name: "K.J. Somaiya College of Engineering", badge: "🔬" },
          { id: "mh-mum-11", name: "Tata Institute of Social Sciences (TISS)", badge: "🌍" },
        ]
      },
      {
        district: "Pune",
        colleges: [
          { id: "mh-pun-1", name: "COEP Technological University (College of Engineering Pune)", badge: "⚡" },
          { id: "mh-pun-2", name: "Savitribai Phule Pune University (SPPU)", badge: "🏛️" },
          { id: "mh-pun-3", name: "Fergusson College Pune", badge: "🎓" },
          { id: "mh-pun-4", name: "Symbiosis International University (SIU)", badge: "🌟" },
          { id: "mh-pun-5", name: "Pune Institute of Computer Technology (PICT)", badge: "💻" },
          { id: "mh-pun-6", name: "MIT World Peace University (MIT-WPU)", badge: "🕊️" },
          { id: "mh-pun-7", name: "Vishwakarma Institute of Technology (VIT Pune)", badge: "⚙️" },
          { id: "mh-pun-8", name: "Dr. D.Y. Patil Vidyapeeth", badge: "🩺" },
          { id: "mh-pun-9", name: "Armed Forces Medical College (AFMC Pune)", badge: "🎖️" },
        ]
      },
      {
        district: "Nagpur",
        colleges: [
          { id: "mh-nag-1", name: "Visvesvaraya National Institute of Tech (VNIT Nagpur)", badge: "⚡" },
          { id: "mh-nag-2", name: "Rashtrasant Tukadoji Maharaj Nagpur University (RTMNU)", badge: "🏛️" },
          { id: "mh-nag-3", name: "AIIMS Nagpur", badge: "🩺" },
          { id: "mh-nag-4", name: "Government Medical College Nagpur", badge: "💉" },
        ]
      },
      {
        district: "Nashik",
        colleges: [
          { id: "mh-nsk-1", name: "K.K. Wagh Institute of Engineering", badge: "⚙️" },
          { id: "mh-nsk-2", name: "Sandip University Nashik", badge: "🌟" },
          { id: "mh-nsk-3", name: "Yashwantrao Chavan Maharashtra Open University", badge: "📚" },
        ]
      }
    ]
  },
  {
    state: "Karnataka",
    districts: [
      {
        district: "Bengaluru (Bangalore)",
        colleges: [
          { id: "ka-blr-1", name: "Indian Institute of Science (IISc Bangalore)", badge: "🔬" },
          { id: "ka-blr-2", name: "R.V. College of Engineering (RVCE)", badge: "⚡" },
          { id: "ka-blr-3", name: "BMS College of Engineering (BMSCE)", badge: "💻" },
          { id: "ka-blr-4", name: "PES University (RR & EC Campus)", badge: "🚀" },
          { id: "ka-blr-5", name: "M.S. Ramaiah Institute of Technology (MSRIT)", badge: "⚙️" },
          { id: "ka-blr-6", name: "IIIT Bangalore", badge: "🖥️" },
          { id: "ka-blr-7", name: "Christ University (Hosur Road / Central)", badge: "🌟" },
          { id: "ka-blr-8", name: "National Law School of India University (NLSIU)", badge: "⚖️" },
          { id: "ka-blr-9", name: "Mount Carmel College (MCC)", badge: "🌸" },
          { id: "ka-blr-10", name: "St. Joseph's University Bangalore", badge: "🎓" },
          { id: "ka-blr-11", name: "Bangalore University", badge: "🏛️" },
        ]
      },
      {
        district: "Mysuru (Mysore)",
        colleges: [
          { id: "ka-mys-1", name: "University of Mysore", badge: "🏛️" },
          { id: "ka-mys-2", name: "Sri Jayachamarajendra College of Engineering (SJCE)", badge: "⚡" },
          { id: "ka-mys-3", name: "Mysore Medical College (MMCRI)", badge: "🩺" },
        ]
      },
      {
        district: "Dakshina Kannada (Mangalore / Surathkal)",
        colleges: [
          { id: "ka-dk-1", name: "NITK Surathkal (National Institute of Technology)", badge: "🏖️" },
          { id: "ka-dk-2", name: "Manipal Academy of Higher Education (MAHE / MIT)", badge: "🌟" },
          { id: "ka-dk-3", name: "Kasturba Medical College (KMC Mangalore)", badge: "🩺" },
          { id: "ka-dk-4", name: "St. Aloysius College Mangaluru", badge: "🎓" },
        ]
      }
    ]
  },
  {
    state: "Rajasthan",
    districts: [
      {
        district: "Jaipur",
        colleges: [
          { id: "rj-jpr-1", name: "MNIT Jaipur (Malaviya National Institute of Tech)", badge: "⚡" },
          { id: "rj-jpr-2", name: "University of Rajasthan (RU)", badge: "🏛️" },
          { id: "rj-jpr-3", name: "Manipal University Jaipur (MUJ)", badge: "🌟" },
          { id: "rj-jpr-4", name: "LNMIIT Jaipur", badge: "💻" },
          { id: "rj-jpr-5", name: "SMS Medical College Jaipur", badge: "🩺" },
          { id: "rj-jpr-6", name: "JECRC University", badge: "🚀" },
          { id: "rj-jpr-7", name: "St. Xavier's College Jaipur", badge: "🎓" },
          { id: "rj-jpr-8", name: "Maharani College Jaipur", badge: "🌸" },
        ]
      },
      {
        district: "Jhunjhunu (Pilani)",
        colleges: [
          { id: "rj-pil-1", name: "BITS Pilani (Birla Institute of Technology & Science)", badge: "🔥" },
          { id: "rj-pil-2", name: "BKBIET Pilani", badge: "💻" },
        ]
      },
      {
        district: "Jodhpur",
        colleges: [
          { id: "rj-jdh-1", name: "IIT Jodhpur", badge: "🔬" },
          { id: "rj-jdh-2", name: "AIIMS Jodhpur", badge: "🩺" },
          { id: "rj-jdh-3", name: "National Law University Jodhpur (NLUJ)", badge: "⚖️" },
          { id: "rj-jdh-4", name: "MBM University (MBM Engineering College)", badge: "⚙️" },
        ]
      },
      {
        district: "Kota",
        colleges: [
          { id: "rj-kta-1", name: "Rajasthan Technical University (RTU Kota)", badge: "⚙️" },
          { id: "rj-kta-2", name: "University of Kota", badge: "🏛️" },
          { id: "rj-kta-3", name: "Government Medical College Kota", badge: "🩺" },
        ]
      },
      {
        district: "Udaipur",
        colleges: [
          { id: "rj-udp-1", name: "IIM Udaipur", badge: "💼" },
          { id: "rj-udp-2", name: "Mohanlal Sukhadia University (MLSU)", badge: "🏛️" },
          { id: "rj-udp-3", name: "College of Technology and Engineering (CTAE)", badge: "🚜" },
        ]
      }
    ]
  },
  {
    state: "Tamil Nadu",
    districts: [
      {
        district: "Chennai",
        colleges: [
          { id: "tn-chn-1", name: "IIT Madras (Indian Institute of Technology)", badge: "⚡" },
          { id: "tn-chn-2", name: "College of Engineering, Guindy (Anna University)", badge: "🏛️" },
          { id: "tn-chn-3", name: "Loyola College Chennai", badge: "🎓" },
          { id: "tn-chn-4", name: "Madras Christian College (MCC)", badge: "🌲" },
          { id: "tn-chn-5", name: "SRM Institute of Science and Technology (Kattankulathur)", badge: "🚀" },
          { id: "tn-chn-6", name: "SSN College of Engineering", badge: "💻" },
          { id: "tn-chn-7", name: "Presidency College Chennai", badge: "📚" },
          { id: "tn-chn-8", name: "Stella Maris College", badge: "🌸" },
          { id: "tn-chn-9", name: "Madras Medical College (MMC)", badge: "🩺" },
        ]
      },
      {
        district: "Coimbatore",
        colleges: [
          { id: "tn-cbe-1", name: "PSG College of Technology", badge: "⚙️" },
          { id: "tn-cbe-2", name: "Coimbatore Institute of Technology (CIT)", badge: "💻" },
          { id: "tn-cbe-3", name: "Amrita Vishwa Vidyapeetham Coimbatore", badge: "🌟" },
          { id: "tn-cbe-4", name: "Kumaraguru College of Technology (KCT)", badge: "🚀" },
        ]
      },
      {
        district: "Tiruchirappalli (Trichy)",
        colleges: [
          { id: "tn-try-1", name: "NIT Trichy (National Institute of Technology)", badge: "🔥" },
          { id: "tn-try-2", name: "IIM Tiruchirappalli", badge: "💼" },
          { id: "tn-try-3", name: "St. Joseph's College Trichy", badge: "🎓" },
        ]
      },
      {
        district: "Vellore",
        colleges: [
          { id: "tn-vel-1", name: "VIT Vellore (Vellore Institute of Technology)", badge: "🌐" },
          { id: "tn-vel-2", name: "Christian Medical College (CMC Vellore)", badge: "🩺" },
        ]
      }
    ]
  },
  {
    state: "Madhya Pradesh",
    districts: [
      {
        district: "Bhopal",
        colleges: [
          { id: "mp-bpl-1", name: "MANIT Bhopal (Maulana Azad National NIT)", badge: "⚡" },
          { id: "mp-bpl-2", name: "AIIMS Bhopal", badge: "🩺" },
          { id: "mp-bpl-3", name: "IISER Bhopal", badge: "🔬" },
          { id: "mp-bpl-4", name: "Rajiv Gandhi Proudyogiki Vishwavidyalaya (RGPV)", badge: "⚙️" },
          { id: "mp-bpl-5", name: "Barkatullah University", badge: "🏛️" },
          { id: "mp-bpl-6", name: "LNCT Bhopal (Lakshmi Narain College of Tech)", badge: "💻" },
        ]
      },
      {
        district: "Indore",
        colleges: [
          { id: "mp-ind-1", name: "IIT Indore", badge: "🔥" },
          { id: "mp-ind-2", name: "IIM Indore", badge: "💼" },
          { id: "mp-ind-3", name: "Devi Ahilya Vishwavidyalaya (DAVV / IET DAVV)", badge: "🏛️" },
          { id: "mp-ind-4", name: "SGSITS Indore (Shri Govindram Seksaria Tech)", badge: "⚡" },
          { id: "mp-ind-5", name: "MGM Medical College Indore", badge: "🩺" },
          { id: "mp-ind-6", name: "Medi-Caps University", badge: "🌟" },
        ]
      },
      {
        district: "Gwalior",
        colleges: [
          { id: "mp-gwl-1", name: "ABV-IIITM Gwalior", badge: "💻" },
          { id: "mp-gwl-2", name: "Jiwaji University", badge: "🏛️" },
          { id: "mp-gwl-3", name: "Madhav Institute of Technology and Science (MITS)", badge: "⚙️" },
        ]
      },
      {
        district: "Jabalpur",
        colleges: [
          { id: "mp-jbl-1", name: "IIITDM Jabalpur", badge: "🎨" },
          { id: "mp-jbl-2", name: "Jabalpur Engineering College (JEC)", badge: "⚡" },
          { id: "mp-jbl-3", name: "Rani Durgavati Vishwavidyalaya (RDVV)", badge: "🏛️" },
        ]
      }
    ]
  },
  {
    state: "Gujarat",
    districts: [
      {
        district: "Ahmedabad",
        colleges: [
          { id: "gj-ahm-1", name: "IIM Ahmedabad (Indian Institute of Management)", badge: "💼" },
          { id: "gj-ahm-2", name: "Gujarat University", badge: "🏛️" },
          { id: "gj-ahm-3", name: "Nirma University", badge: "🌟" },
          { id: "gj-ahm-4", name: "CEPT University", badge: "📐" },
          { id: "gj-ahm-5", name: "L.D. College of Engineering (LDCE)", badge: "⚡" },
          { id: "gj-ahm-6", name: "St. Xavier's College Ahmedabad", badge: "🎓" },
          { id: "gj-ahm-7", name: "B.J. Medical College Ahmedabad", badge: "🩺" },
        ]
      },
      {
        district: "Gandhinagar",
        colleges: [
          { id: "gj-gnd-1", name: "IIT Gandhinagar", badge: "🔬" },
          { id: "gj-gnd-2", name: "DA-IICT (Dhirubhai Ambani Institute)", badge: "💻" },
          { id: "gj-gnd-3", name: "Pandit Deendayal Energy University (PDEU)", badge: "⚡" },
          { id: "gj-gnd-4", name: "National Forensic Sciences University (NFSU)", badge: "🔍" },
        ]
      },
      {
        district: "Vadodara (Baroda)",
        colleges: [
          { id: "gj-vad-1", name: "Maharaja Sayajirao University of Baroda (MSU)", badge: "👑" },
          { id: "gj-vad-2", name: "Parul University", badge: "🌟" },
          { id: "gj-vad-3", name: "Medical College Baroda", badge: "🩺" },
        ]
      },
      {
        district: "Surat",
        colleges: [
          { id: "gj-srt-1", name: "SVNIT Surat (Sardar Vallabhbhai National NIT)", badge: "⚡" },
          { id: "gj-srt-2", name: "Veer Narmad South Gujarat University (VNSGU)", badge: "🏛️" },
        ]
      }
    ]
  },
  {
    state: "West Bengal",
    districts: [
      {
        district: "Kolkata & Howrah",
        colleges: [
          { id: "wb-kol-1", name: "Jadavpur University", badge: "🔥" },
          { id: "wb-kol-2", name: "University of Calcutta", badge: "🏛️" },
          { id: "wb-kol-3", name: "Presidency University Kolkata", badge: "🎓" },
          { id: "wb-kol-4", name: "St. Xavier's College Kolkata", badge: "⭐" },
          { id: "wb-kol-5", name: "IIEST Shibpur (Howrah)", badge: "⚙️" },
          { id: "wb-kol-6", name: "Heritage Institute of Technology", badge: "💻" },
          { id: "wb-kol-7", name: "Medical College Kolkata (Calcutta Medical)", badge: "🩺" },
          { id: "wb-kol-8", name: "Institute of Engineering & Management (IEM)", badge: "🚀" },
        ]
      },
      {
        district: "Paschim Medinipur (Kharagpur)",
        colleges: [
          { id: "wb-kgp-1", name: "IIT Kharagpur (The Pioneer IIT)", badge: "⚡" },
          { id: "wb-kgp-2", name: "Vidyasagar University", badge: "📚" },
        ]
      },
      {
        district: "Paschim Bardhaman (Durgapur / Asansol)",
        colleges: [
          { id: "wb-dgp-1", name: "NIT Durgapur", badge: "⚙️" },
          { id: "wb-dgp-2", name: "Kazi Nazrul University", badge: "🏛️" },
        ]
      }
    ]
  },
  {
    state: "Punjab & Chandigarh",
    districts: [
      {
        district: "Chandigarh (U.T.)",
        colleges: [
          { id: "pb-chd-1", name: "Panjab University Chandigarh (PU)", badge: "🏛️" },
          { id: "pb-chd-2", name: "Punjab Engineering College (PEC)", badge: "⚡" },
          { id: "pb-chd-3", name: "Postgraduate Institute of Med Ed & Research (PGIMER)", badge: "🩺" },
          { id: "pb-chd-4", name: "MCM DAV College for Women", badge: "🌸" },
          { id: "pb-chd-5", name: "Post Graduate Govt College for Girls (Sector 11/42)", badge: "👑" },
          { id: "pb-chd-6", name: "DAV College Sector 10 Chandigarh", badge: "🎓" },
        ]
      },
      {
        district: "Patiala",
        colleges: [
          { id: "pb-pat-1", name: "Thapar Institute of Engineering & Technology (TIET)", badge: "🔥" },
          { id: "pb-pat-2", name: "Punjabi University Patiala", badge: "🏛️" },
          { id: "pb-pat-3", name: "Government Medical College Patiala", badge: "🩺" },
        ]
      },
      {
        district: "Mohali & Ropar",
        colleges: [
          { id: "pb-moh-1", name: "IIT Ropar", badge: "⚡" },
          { id: "pb-moh-2", name: "Chandigarh University (Gharuan)", badge: "🚀" },
          { id: "pb-moh-3", name: "IISER Mohali", badge: "🔬" },
          { id: "pb-moh-4", name: "ISB Mohali (Indian School of Business)", badge: "💼" },
        ]
      },
      {
        district: "Jalandhar & Amritsar",
        colleges: [
          { id: "pb-jal-1", name: "NIT Jalandhar (Dr. B.R. Ambedkar National NIT)", badge: "⚙️" },
          { id: "pb-jal-2", name: "Lovely Professional University (LPU Phagwara)", badge: "🌐" },
          { id: "pb-asr-1", name: "Guru Nanak Dev University (GNDU Amritsar)", badge: "🏛️" },
        ]
      }
    ]
  },
  {
    state: "Haryana",
    districts: [
      {
        district: "Gurugram (Gurgaon)",
        colleges: [
          { id: "hr-ggn-1", name: "The NorthCap University (NCU Gurugram)", badge: "💻" },
          { id: "hr-ggn-2", name: "BML Munjal University", badge: "🌟" },
          { id: "hr-ggn-3", name: "GD Goenka University", badge: "🚀" },
          { id: "hr-ggn-4", name: "KR Mangalam University", badge: "🎓" },
          { id: "hr-ggn-5", name: "Dronacharya College of Engineering", badge: "⚙️" },
        ]
      },
      {
        district: "Kurukshetra",
        colleges: [
          { id: "hr-kkr-1", name: "NIT Kurukshetra", badge: "⚡" },
          { id: "hr-kkr-2", name: "Kurukshetra University (KUK)", badge: "🏛️" },
        ]
      },
      {
        district: "Sonipat",
        colleges: [
          { id: "hr-snp-1", name: "Ashoka University", badge: "💎" },
          { id: "hr-snp-2", name: "O.P. Jindal Global University (JGU)", badge: "⚖️" },
          { id: "hr-snp-3", name: "DCRUST Murthal", badge: "⚙️" },
          { id: "hr-snp-4", name: "SRM University Delhi-NCR (Sonipat)", badge: "🌟" },
        ]
      },
      {
        district: "Rohtak & Faridabad",
        colleges: [
          { id: "hr-rtk-1", name: "IIM Rohtak", badge: "💼" },
          { id: "hr-rtk-2", name: "Maharshi Dayanand University (MDU Rohtak)", badge: "🏛️" },
          { id: "hr-fbd-1", name: "J.C. Bose University (YMCA Faridabad)", badge: "⚡" },
          { id: "hr-fbd-2", name: "Manav Rachna International University", badge: "🚀" },
        ]
      }
    ]
  },
  {
    state: "Bihar",
    districts: [
      {
        district: "Patna",
        colleges: [
          { id: "br-pat-1", name: "IIT Patna", badge: "⚡" },
          { id: "br-pat-2", name: "NIT Patna (National Institute of Technology)", badge: "⚙️" },
          { id: "br-pat-3", name: "Patna University", badge: "🏛️" },
          { id: "br-pat-4", name: "AIIMS Patna", badge: "🩺" },
          { id: "br-pat-5", name: "Patna Science College", badge: "🔬" },
          { id: "br-pat-6", name: "Magadh Mahila College", badge: "🌸" },
          { id: "br-pat-7", name: "Birla Institute of Technology (BIT Patna)", badge: "💻" },
          { id: "br-pat-8", name: "Chanakya National Law University (CNLU)", badge: "⚖️" },
          { id: "br-pat-9", name: "Patna Women's College", badge: "🎓" },
        ]
      },
      {
        district: "Gaya & Muzaffarpur",
        colleges: [
          { id: "br-gay-1", name: "Central University of South Bihar (CUSB Gaya)", badge: "🏛️" },
          { id: "br-gay-2", name: "Magadh University Bodh Gaya", badge: "☸️" },
          { id: "br-muz-1", name: "B.R. Ambedkar Bihar University (BRABU Muzaffarpur)", badge: "📚" },
          { id: "br-muz-2", name: "Muzaffarpur Institute of Technology (MIT)", badge: "⚙️" },
        ]
      }
    ]
  },
  {
    state: "Telangana & Andhra Pradesh",
    districts: [
      {
        district: "Hyderabad",
        colleges: [
          { id: "ts-hyd-1", name: "IIT Hyderabad (Kandi)", badge: "⚡" },
          { id: "ts-hyd-2", name: "IIIT Hyderabad (Gachibowli)", badge: "💻" },
          { id: "ts-hyd-3", name: "BITS Pilani Hyderabad Campus", badge: "🔥" },
          { id: "ts-hyd-4", name: "Osmania University (OU)", badge: "🏛️" },
          { id: "ts-hyd-5", name: "University of Hyderabad (HCU)", badge: "🌲" },
          { id: "ts-hyd-6", name: "JNTU Hyderabad (Jawaharlal Nehru Tech)", badge: "⚙️" },
          { id: "ts-hyd-7", name: "Chaitanya Bharathi Institute of Technology (CBIT)", badge: "🚀" },
          { id: "ts-hyd-8", name: "VNR Vignana Jyothi (VNR VJIET)", badge: "🌟" },
        ]
      },
      {
        district: "Warangal & Visakhapatnam",
        colleges: [
          { id: "ts-wgl-1", name: "NIT Warangal", badge: "🔥" },
          { id: "ap-vzg-1", name: "Andhra University (Visakhapatnam)", badge: "🏛️" },
          { id: "ap-vzg-2", name: "GITAM University Visakhapatnam", badge: "🌟" },
          { id: "ap-vzg-3", name: "IIM Visakhapatnam", badge: "💼" },
        ]
      }
    ]
  },
  {
    state: "Uttarakhand",
    districts: [
      {
        district: "Dehradun",
        colleges: [
          { id: "uk-ddn-1", name: "UPES Dehradun (Energy Acres / Bidholi)", badge: "⚡" },
          { id: "uk-ddn-2", name: "Graphic Era University (GEU Dehradun)", badge: "🚀" },
          { id: "uk-ddn-3", name: "DIT University Dehradun", badge: "💻" },
          { id: "uk-ddn-4", name: "Forest Research Institute (FRI)", badge: "🌲" },
          { id: "uk-ddn-5", name: "DAV PG College Dehradun", badge: "📚" },
        ]
      },
      {
        district: "Haridwar & Roorkee",
        colleges: [
          { id: "uk-rke-1", name: "IIT Roorkee", badge: "🏛️" },
          { id: "uk-rke-2", name: "College of Engineering Roorkee (COER)", badge: "⚙️" },
          { id: "uk-hwr-1", name: "Gurukula Kangri Vishwavidyalaya", badge: "🕉️" },
        ]
      }
    ]
  },
  {
    state: "Kerala",
    districts: [
      {
        district: "Thiruvananthapuram (Trivandrum)",
        colleges: [
          { id: "kl-tvm-1", name: "College of Engineering Trivandrum (CET)", badge: "⚡" },
          { id: "kl-tvm-2", name: "University of Kerala", badge: "🏛️" },
          { id: "kl-tvm-3", name: "IISER Thiruvananthapuram", badge: "🔬" },
        ]
      },
      {
        district: "Kochi (Ernakulam)",
        colleges: [
          { id: "kl-koc-1", name: "CUSAT (Cochin University of Science & Tech)", badge: "🌊" },
          { id: "kl-koc-2", name: "Rajagiri College of Social Sciences", badge: "🌟" },
          { id: "kl-koc-3", name: "Model Engineering College (MEC Kochi)", badge: "💻" },
        ]
      },
      {
        district: "Kozhikode (Calicut)",
        colleges: [
          { id: "kl-clt-1", name: "NIT Calicut", badge: "⚡" },
          { id: "kl-clt-2", name: "IIM Kozhikode", badge: "💼" },
        ]
      }
    ]
  },
  {
    state: "Odisha & Jharkhand",
    districts: [
      {
        district: "Bhubaneswar (Odisha)",
        colleges: [
          { id: "od-bbs-1", name: "IIT Bhubaneswar", badge: "⚡" },
          { id: "od-bbs-2", name: "KIIT University Bhubaneswar", badge: "🚀" },
          { id: "od-bbs-3", name: "Siksha 'O' Anusandhan (SOA University)", badge: "🌟" },
          { id: "od-bbs-4", name: "Utkal University", badge: "🏛️" },
          { id: "od-bbs-5", name: "AIIMS Bhubaneswar", badge: "🩺" },
        ]
      },
      {
        district: "Ranchi & Dhanbad (Jharkhand)",
        colleges: [
          { id: "jh-rnc-1", name: "BIT Mesra (Birla Institute of Technology)", badge: "🔥" },
          { id: "jh-rnc-2", name: "IIM Ranchi", badge: "💼" },
          { id: "jh-rnc-3", name: "Ranchi University", badge: "🏛️" },
          { id: "jh-dnb-1", name: "IIT (ISM) Dhanbad", badge: "⛏️" },
          { id: "jh-jsr-1", name: "XLRI Jamshedpur", badge: "🏆" },
          { id: "jh-jsr-2", name: "NIT Jamshedpur", badge: "⚙️" },
        ]
      }
    ]
  },
  {
    state: "Assam & Northeast",
    districts: [
      {
        district: "Kamrup (Guwahati)",
        colleges: [
          { id: "as-ghy-1", name: "IIT Guwahati", badge: "⚡" },
          { id: "as-ghy-2", name: "Gauhati University", badge: "🏛️" },
          { id: "as-ghy-3", name: "Cotton University", badge: "🎓" },
          { id: "as-ghy-4", name: "Assam Engineering College (AEC)", badge: "⚙️" },
          { id: "as-ghy-5", name: "AIIMS Guwahati", badge: "🩺" },
        ]
      },
      {
        district: "Silchar & Tezpur",
        colleges: [
          { id: "as-slc-1", name: "NIT Silchar", badge: "⚡" },
          { id: "as-tzp-1", name: "Tezpur University", badge: "🌲" },
        ]
      }
    ]
  }
];
