import type { AttendanceRecord, ComputedDay, DayStatus, PeriodSummary, UserProfile } from '../types';

export const DATE_KEY_REGEX = /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/;
export const MAX_NOTE_LENGTH = 200;

export const WEEKDAYS_SHORT_HEADERS: { index: number; label: string; short: string }[] = [
  { index: 6, label: 'السبت', short: 'سبت' },
  { index: 0, label: 'الأحد', short: 'أحد' },
  { index: 1, label: 'الإثنين', short: 'إثنين' },
  { index: 2, label: 'الثلاثاء', short: 'ثلاثاء' },
  { index: 3, label: 'الأربعاء', short: 'أربعاء' },
  { index: 4, label: 'الخميس', short: 'خميس' },
  { index: 5, label: 'الجمعة', short: 'جمعة' },
];

const WEEKDAY_NAME_BY_INDEX: Record<number, string> = {
  0: 'الأحد',
  1: 'الإثنين',
  2: 'الثلاثاء',
  3: 'الأربعاء',
  4: 'الخميس',
  5: 'الجمعة',
  6: 'السبت',
};

const MONTHS_AR = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

export function pad2(n: number): string {
  return String(n).padStart(2, '0');
}

export function formatDateKey(year: number, month: number, day: number): string {
  return `${year}-${pad2(month)}-${pad2(day)}`;
}

export function getTodayDateKey(): string {
  const now = new Date();
  return formatDateKey(now.getFullYear(), now.getMonth() + 1, now.getDate());
}

export function parseDateKey(dateKey: string): { year: number; month: number; day: number } {
  const [y, m, d] = dateKey.split('-').map(Number);
  return { year: y, month: m, day: d };
}

export function getWeekdayUTC(dateKey: string): number {
  const { year, month, day } = parseDateKey(dateKey);
  return new Date(Date.UTC(year, month - 1, day)).getUTCDay();
}

export function diffDaysUTC(startDateKey: string, endDateKey: string): number {
  const a = parseDateKey(startDateKey);
  const b = parseDateKey(endDateKey);
  const utcA = Date.UTC(a.year, a.month - 1, a.day);
  const utcB = Date.UTC(b.year, b.month - 1, b.day);
  return Math.round((utcB - utcA) / 86_400_000);
}

export function addDaysUTC(dateKey: string, days: number): string {
  const { year, month, day } = parseDateKey(dateKey);
  const dt = new Date(Date.UTC(year, month - 1, day + days));
  return formatDateKey(dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate());
}

export function getDaysInMonth(year: number, month: number): number {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

export function formatArabicDateFull(dateKey: string): string {
  if (!DATE_KEY_REGEX.test(dateKey)) return dateKey;
  const { year, month, day } = parseDateKey(dateKey);
  const weekday = WEEKDAY_NAME_BY_INDEX[getWeekdayUTC(dateKey)] ?? '';
  const monthName = MONTHS_AR[month - 1] ?? '';
  return `${weekday}، ${day} ${monthName} ${year}`;
}

export function formatArabicDateShort(dateKey: string): string {
  if (!DATE_KEY_REGEX.test(dateKey)) return dateKey;
  const { year, month, day } = parseDateKey(dateKey);
  const monthName = MONTHS_AR[month - 1] ?? '';
  return `${day} ${monthName} ${year}`;
}

export function formatArabicMonthYear(year: number, month: number): string {
  return `${MONTHS_AR[month - 1] ?? ''} ${year}`;
}

export function getWeekdayName(dateKey: string): string {
  return WEEKDAY_NAME_BY_INDEX[getWeekdayUTC(dateKey)] ?? '';
}

export function getStatusLabelAr(status: DayStatus): string {
  return status === 'annual' ? 'إجازة اعتيادي' : 'حضور (عمل)';
}

export function getStatusShortAr(status: DayStatus): string {
  return status === 'annual' ? 'اعتيادي' : 'حضور';
}

export function getAutoStatusForDate(
  dateKey: string,
  profile: Pick<UserProfile, 'returnStartDate'>
): DayStatus | null {
  if (!profile.returnStartDate || !DATE_KEY_REGEX.test(profile.returnStartDate)) {
    return null;
  }
  const diff = diffDaysUTC(profile.returnStartDate, dateKey);
  if (diff < 0) {
    return null;
  }
  // Every day from returnStartDate onward defaults to work attendance unless marked as leave
  return 'work';
}

export function computeDayInfo(
  dateKey: string,
  todayKey: string,
  profile: UserProfile,
  recordsMap: Map<string, AttendanceRecord>
): ComputedDay | null {
  const manual = recordsMap.get(dateKey);
  const autoStatus = getAutoStatusForDate(dateKey, profile);
  const isFirstReturnDay = profile.returnStartDate === dateKey;
  const isFuture = dateKey > todayKey;

  if (manual) {
    return {
      date: dateKey,
      weekday: getWeekdayUTC(dateKey),
      status: manual.status,
      source: 'manual',
      isFirstReturnDay,
      isFuture,
      note: manual.note || '',
    };
  }

  if (autoStatus === null) {
    return null;
  }

  return {
    date: dateKey,
    weekday: getWeekdayUTC(dateKey),
    status: autoStatus,
    source: 'auto',
    isFirstReturnDay,
    isFuture,
    note: isFirstReturnDay ? 'أول يوم عودة للعمل' : '',
  };
}

export function computeDaysAndSummary(
  todayKey: string,
  profile: UserProfile,
  recordsMap: Map<string, AttendanceRecord>
): { days: ComputedDay[]; summary: PeriodSummary } {
  const dayMap = new Map<string, ComputedDay>();

  if (profile.returnStartDate && DATE_KEY_REGEX.test(profile.returnStartDate)) {
    const endKey = profile.returnStartDate > todayKey ? profile.returnStartDate : todayKey;
    const totalSpan = Math.min(3650, diffDaysUTC(profile.returnStartDate, endKey));
    for (let i = 0; i <= totalSpan; i++) {
      const dateKey = addDaysUTC(profile.returnStartDate, i);
      const info = computeDayInfo(dateKey, todayKey, profile, recordsMap);
      if (info) {
        dayMap.set(dateKey, info);
      }
    }
  }

  // Also include any manual leave/attendance records outside the returnStartDate..todayKey span
  for (const [dateKey, rec] of recordsMap.entries()) {
    if (!dayMap.has(dateKey) && DATE_KEY_REGEX.test(dateKey)) {
      dayMap.set(dateKey, {
        date: dateKey,
        weekday: getWeekdayUTC(dateKey),
        status: rec.status,
        source: 'manual',
        isFirstReturnDay: profile.returnStartDate === dateKey,
        isFuture: dateKey > todayKey,
        note: rec.note || '',
      });
    }
  }

  const days = Array.from(dayMap.values()).sort((a, b) => a.date.localeCompare(b.date));

  let workDays = 0;
  let annualLeaveDays = 0;
  let manualOverrides = 0;

  for (const d of days) {
    if (d.status === 'work') workDays++;
    else annualLeaveDays++;
    if (d.source === 'manual') manualOverrides++;
  }

  return {
    days,
    summary: {
      workDays,
      annualLeaveDays,
      totalDays: workDays + annualLeaveDays,
      manualOverrides,
    },
  };
}

export function computeMonthDays(
  year: number,
  month: number,
  todayKey: string,
  profile: UserProfile,
  recordsMap: Map<string, AttendanceRecord>
): { calendarDays: (ComputedDay | null)[]; summary: PeriodSummary } {
  const totalInMonth = getDaysInMonth(year, month);
  const calendarDays: (ComputedDay | null)[] = [];
  let workDays = 0;
  let annualLeaveDays = 0;
  let manualOverrides = 0;

  for (let d = 1; d <= totalInMonth; d++) {
    const dateKey = formatDateKey(year, month, d);
    const info = computeDayInfo(dateKey, todayKey, profile, recordsMap);
    calendarDays.push(info);
    if (info && (!info.isFuture || info.source === 'manual')) {
      if (info.status === 'work') workDays++;
      else annualLeaveDays++;
      if (info.source === 'manual') manualOverrides++;
    }
  }

  return {
    calendarDays,
    summary: {
      workDays,
      annualLeaveDays,
      totalDays: workDays + annualLeaveDays,
      manualOverrides,
    },
  };
}

export function exportDaysToCSV(days: ComputedDay[], filename: string): void {
  const header = ['التاريخ', 'اليوم', 'الحالة', 'المصدر', 'ملاحظة'];
  const rows = days.map((d) => [
    d.date,
    getWeekdayName(d.date),
    getStatusLabelAr(d.status),
    d.source === 'manual' ? 'تسجيل/تعديل يدوي' : 'حساب تلقائي',
    (d.note || '').replace(/"/g, '""'),
  ]);
  const csvContent =
    '\uFEFF' +
    [header, ...rows]
      .map((row) => row.map((cell) => `"${cell}"`).join(','))
      .join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
