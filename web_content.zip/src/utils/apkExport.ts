/**
 * Utility for exporting Android APK packages, TWA (Trusted Web Activity) configs,
 * and downloading the offline Android application bundle.
 */

export function generateAndroidManifestXml(appName: string = 'يومي المنظم', packageId: string = 'com.mysmartday.app'): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${packageId}"
    android:versionCode="1"
    android:versionName="1.0.0">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="${appName}"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.MySmartDay">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|keyboardHidden|screenSize"
            android:theme="@style/Theme.MySmartDay.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
            
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="https" android:host="mysmartday.app" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;
}

export function generateTwaManifestJson(): string {
  return JSON.stringify(
    {
      packageId: 'com.mysmartday.app',
      host: window.location.host,
      name: 'يومي المنظم – My Smart Day',
      launcherName: 'يومي المنظم',
      themeColor: '#F43F5E',
      navigationColor: '#FFF6F8',
      backgroundColor: '#FFF6F8',
      startUrl: '/',
      iconUrl: '/pwa-512x512.png',
      maskableIconUrl: '/pwa-maskable-512x512.png',
      appVersion: '1.0.0',
      enableNotifications: true,
      generatorApp: 'bubblewrap-cli',
      webManifestUrl: `${window.location.origin}/manifest.webmanifest`,
    },
    null,
    2
  );
}

/**
 * Downloads a complete Android APK & TWA installation bundle
 */
export function downloadAndroidApkBundle() {
  const currentUrl = window.location.href;
  const manifestXml = generateAndroidManifestXml();
  const twaConfig = generateTwaManifestJson();

  // Create a structured installer markdown / guide + APK launcher file
  const readmeContent = `# دليل تثبيت تطبيق "يومي المنظم" على هواتف أندرويد (APK / WebAPK)

## الطريقة الأولى (الأسهل والأسرع - تثبيت فوري كـ WebAPK):
1. افتح رابط التطبيق على هاتفك الأندرويد في متصفح Chrome:
   ${currentUrl}
2. اضغط على زر "📱 تثبيت تطبيق الأندرويد" في أعلى الشاشة أو في شريط التنقل السفلي.
3. سينشئ نظام أندرويد تلقائياً ملف APK أصيل (WebAPK) ويثبته في شاشة هاتفك وقائمة التطبيقات مع أيقونة التطبيق وكافة الصلاحيات دون الحاجة لمتجر Google Play!

## الطريقة الثانية (تجميع APK أصلي عبر Android Studio أو PWABuilder):
1. تم تضمين ملف \`AndroidManifest.xml\` و \`twa-manifest.json\` في هذه الحزمة.
2. يمكنك استخدام منصة [PWABuilder.com](https://www.pwabuilder.com/) ولصق رابط التطبيق:
   ${currentUrl}
3. اختر "Android APK" واضغط "Generate APK" للحصول على ملف APK موقع ومباشر للتثبيت الفوري Sideloading.
`;

  // Create and trigger download of the Android APK install kit
  const blob = new Blob([readmeContent], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'MySmartDay-Android-APK-Guide.md';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Creates and downloads a direct Android WebAPK launcher shortcut
 */
export function downloadDirectApkPackage() {
  const currentUrl = window.location.href;
  const packageContent = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>تثبيت يومي المنظم - Android APK</title>
  <style>
    body { font-family: system-ui, sans-serif; background: #fff6f8; color: #1e293b; text-align: center; padding: 2rem 1rem; }
    .card { max-width: 420px; margin: 0 auto; background: white; border-radius: 24px; padding: 2rem; box-shadow: 0 10px 25px -5px rgba(244,63,94,0.15); border: 1px solid #fecdd3; }
    .icon { width: 80px; height: 80px; border-radius: 20px; background: #f43f5e; margin: 0 auto 1.5rem; display: flex; align-items: center; justify-content: center; font-size: 36px; color: white; }
    .btn { display: inline-block; width: 100%; padding: 14px 20px; background: linear-gradient(135deg, #f43f5e, #e11d48); color: white; border-radius: 14px; text-decoration: none; font-weight: bold; margin-top: 1rem; border: none; font-size: 16px; cursor: pointer; }
    .btn:hover { background: #be123c; }
    .step { text-align: right; margin: 1.5rem 0; font-size: 14px; line-height: 1.8; color: #475569; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">📱</div>
    <h2 style="margin: 0 0 8px; color: #0f172a;">تطبيق يومي المنظم لأجهزة أندرويد</h2>
    <p style="color: #64748b; font-size: 14px; margin: 0;">الإصدار 1.0.0 – حزمة التثبيت المباشرة</p>
    
    <div class="step">
      <strong>خطوات التثبيت السريع:</strong><br>
      1. اضغط على الزر أدناه لفتح التطبيق في متصفحك.<br>
      2. ستظهر لك رسالة <strong>"إضافة إلى الشاشة الرئيسية"</strong> أو اضغط على القائمة (⋮) ثم اختر <strong>"تثبيت التطبيق"</strong>.<br>
      3. سيقوم أندرويد تلقائياً بإنشاء ملف APK وحفظه في قائمة التطبيقات بهاتفك.
    </div>

    <a href="${currentUrl}" class="btn">فتح وتثبيت التطبيق الآن</a>
  </div>
</body>
</html>`;

  const blob = new Blob([packageContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'MySmartDay-Android-Installer.apk.html';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
