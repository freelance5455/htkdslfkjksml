import type { MedicineItem, MedicineStock } from '../types/pharmacy.ts';

export interface ParsedBarcodeResult {
  raw: string;
  normalizedBarcode: string;
  alternateBarcodes: string[];
  expiryDate?: string; // YYYY-MM-DD if extracted from GS1 (AI 17)
  batchNumber?: string; // Batch/Lot if extracted from GS1 (AI 10)
}

/**
 * Normalizes a scanned or typed barcode string and extracts GS1 pharmaceutical data
 * (GTIN / EAN-13 and Expiry Date) when scanning 2D DataMatrix or GS1-128 medicine codes.
 */
export function parseAndNormalizeBarcode(input: string): ParsedBarcodeResult {
  const raw = (input || '').trim();
  if (!raw) {
    return {
      raw: '',
      normalizedBarcode: '',
      alternateBarcodes: [],
    };
  }

  // Strip AIM symbology identifiers (like ]d2, ]C1, ]e0) and control chars (FNC1 \u001d)
  const cleaned = raw
    .replace(/^\][a-zA-Z][0-9]/, '')
    .replace(/[\x00-\x1F\x7F]/g, '')
    .trim();

  // Check for human-readable GS1 format e.g. (01)06291100123456(17)261231(10)BATCH
  const parenGtinMatch = cleaned.match(/\(01\)(\d{14})/);
  if (parenGtinMatch) {
    const gtin14 = parenGtinMatch[1];
    const ean13 = gtin14.startsWith('0') ? gtin14.slice(1) : gtin14;
    const expMatch = cleaned.match(/\(17\)(\d{6})/);
    const expiryDate = expMatch ? parseGs1ExpiryDate(expMatch[1]) : undefined;
    const lotMatch = cleaned.match(/\(10\)([^\(\)]+)/);
    return {
      raw,
      normalizedBarcode: ean13,
      alternateBarcodes: Array.from(new Set([ean13, gtin14, cleaned])),
      expiryDate,
      batchNumber: lotMatch ? lotMatch[1].trim() : undefined,
    };
  }

  // Check for raw GS1-128 / GS1 DataMatrix format starting with AI 01 + 14-digit GTIN
  // Pharmaceutical 2D barcodes are typically >= 16 characters starting with "01" + 14 digits
  if (/^01\d{14}/.test(cleaned) && cleaned.length >= 16) {
    const gtin14 = cleaned.slice(2, 16);
    const ean13 = gtin14.startsWith('0') ? gtin14.slice(1) : gtin14;
    const remainder = cleaned.slice(16);

    let expiryDate: string | undefined;
    let batchNumber: string | undefined;

    // Look for AI 17 (Expiry Date YYMMDD) at start of remainder
    const expDirect = remainder.match(/^17(\d{6})/);
    if (expDirect) {
      expiryDate = parseGs1ExpiryDate(expDirect[1]);
      const afterExp = remainder.slice(8);
      if (afterExp.startsWith('10') && afterExp.length > 2) {
        batchNumber = afterExp.slice(2).slice(0, 20);
      }
    }

    return {
      raw,
      normalizedBarcode: ean13,
      alternateBarcodes: Array.from(new Set([ean13, gtin14, cleaned])),
      expiryDate,
      batchNumber,
    };
  }

  // Standard 1D barcode (EAN-13, UPC-A, EAN-8, Code-128)
  // Handle UPC-A (12 digits) vs EAN-13 with leading zero (13 digits starting with 0)
  const alternates = new Set<string>([cleaned]);
  if (/^\d{13}$/.test(cleaned) && cleaned.startsWith('0')) {
    alternates.add(cleaned.slice(1)); // 12-digit UPC-A equivalent
  } else if (/^\d{12}$/.test(cleaned)) {
    alternates.add('0' + cleaned); // 13-digit EAN-13 equivalent
  } else if (/^\d{14}$/.test(cleaned) && cleaned.startsWith('0')) {
    alternates.add(cleaned.slice(1)); // 13-digit EAN-13 from GTIN-14
  }

  return {
    raw,
    normalizedBarcode: cleaned,
    alternateBarcodes: Array.from(alternates),
  };
}

/**
 * Converts GS1 YYMMDD string into YYYY-MM-DD
 * In GS1 spec, DD="00" means the last day of that month.
 */
export function parseGs1ExpiryDate(yymmdd: string): string | undefined {
  if (!/^\d{6}$/.test(yymmdd)) return undefined;
  const yy = parseInt(yymmdd.slice(0, 2), 10);
  const mm = parseInt(yymmdd.slice(2, 4), 10);
  let dd = parseInt(yymmdd.slice(4, 6), 10);

  if (mm < 1 || mm > 12) return undefined;
  const year = 2000 + yy;

  if (dd === 0) {
    // Last day of the month
    dd = new Date(year, mm, 0).getDate();
  }
  if (dd < 1 || dd > 31) return undefined;

  const mmStr = String(mm).padStart(2, '0');
  const ddStr = String(dd).padStart(2, '0');
  return `${year}-${mmStr}-${ddStr}`;
}

/**
 * Finds a matching barcode key in medicines or stocks, accounting for leading zeros or GS1 GTINs.
 */
export function findMatchingBarcodeKey(
  scannedCode: string,
  medicines: MedicineItem[],
  stocks: Record<string, MedicineStock>
): string | null {
  const parsed = parseAndNormalizeBarcode(scannedCode);
  if (!parsed.normalizedBarcode) return null;

  for (const candidate of parsed.alternateBarcodes) {
    if (stocks[candidate]) return candidate;
    const med = medicines.find((m) => m.barcode.trim() === candidate);
    if (med) return med.barcode.trim();
  }

  // Also check if any stored medicine barcode matches when normalized
  for (const med of medicines) {
    const medParsed = parseAndNormalizeBarcode(med.barcode);
    if (
      medParsed.alternateBarcodes.some((alt) =>
        parsed.alternateBarcodes.includes(alt)
      )
    ) {
      return med.barcode.trim();
    }
  }

  for (const key of Object.keys(stocks)) {
    const keyParsed = parseAndNormalizeBarcode(key);
    if (
      keyParsed.alternateBarcodes.some((alt) =>
        parsed.alternateBarcodes.includes(alt)
      )
    ) {
      return key;
    }
  }

  return null;
}
