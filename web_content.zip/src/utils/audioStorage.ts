import { Song, Playlist } from '../types';

const DB_NAME = 'music_player_db';
const DB_VERSION = 1;
const STORE_SONGS = 'songs';
const STORE_AUDIO = 'audio_blobs';
const STORE_PLAYLISTS = 'playlists';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (e) => {
      const db = (e.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_SONGS)) {
        db.createObjectStore(STORE_SONGS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_AUDIO)) {
        db.createObjectStore(STORE_AUDIO, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_PLAYLISTS)) {
        db.createObjectStore(STORE_PLAYLISTS, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// Generate synthesized pleasant relaxing audio tracks for demo playback out-of-the-box
export function createSynthesizedAudioBlob(notes: number[], bpm: number = 72, durationSec: number = 30): Blob {
  const sampleRate = 44100;
  const numChannels = 2;
  const totalSamples = sampleRate * durationSec;
  const buffer = new Float32Array(totalSamples);

  const secondsPerBeat = 60 / bpm;
  let currentNoteIdx = 0;

  for (let i = 0; i < totalSamples; i++) {
    const time = i / sampleRate;
    const beatTime = time % secondsPerBeat;
    const beatIndex = Math.floor(time / secondsPerBeat);

    const freq = notes[beatIndex % notes.length];
    if (freq > 0) {
      // Pleasant acoustic organ / chime synth envelope
      const env = Math.exp(-beatTime * 3.5);
      const tone1 = Math.sin(2 * Math.PI * freq * time);
      const tone2 = 0.5 * Math.sin(2 * Math.PI * (freq * 2) * time);
      const tone3 = 0.25 * Math.sin(2 * Math.PI * (freq * 0.5) * time);
      const sample = (tone1 + tone2 + tone3) * env * 0.25;
      buffer[i] = sample;
    } else {
      buffer[i] = 0;
    }
  }

  // Convert Float32Array to 16-bit PCM WAV
  const wavBytes = encodeWAV(buffer, sampleRate, numChannels);
  return new Blob([wavBytes], { type: 'audio/wav' });
}

function encodeWAV(samples: Float32Array, sampleRate: number, numChannels: number): Uint8Array {
  const byteRate = sampleRate * numChannels * 2;
  const blockAlign = numChannels * 2;
  const dataSize = samples.length * numChannels * 2;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  function writeString(offset: number, str: string) {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  }

  // RIFF header
  writeString(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, 'WAVE');
  // fmt chunk
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
  view.setUint16(20, 1, true); // AudioFormat (1 = PCM)
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true); // BitsPerSample
  // data chunk
  writeString(36, 'data');
  view.setUint32(40, dataSize, true);

  let offset = 44;
  for (let i = 0; i < samples.length; i++) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    const val = s < 0 ? s * 0x8000 : s * 0x7fff;
    view.setInt16(offset, val, true);
    if (numChannels === 2) {
      view.setInt16(offset + 2, val, true);
      offset += 4;
    } else {
      offset += 2;
    }
  }

  return new Uint8Array(buffer);
}

export const INITIAL_DEMO_TRACKS: Omit<Song, 'audioUrl'>[] = [
  {
    id: 'demo-1',
    title: 'Emerald Horizon',
    artist: 'Antigravity Sound',
    album: 'Ambient Resonance',
    genre: 'Lo-Fi Chill',
    year: 2026,
    duration: 32,
    artworkUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&auto=format&fit=crop&q=80',
    dateAdded: Date.now() - 3600000 * 24 * 2,
    playCount: 14,
    isFavorite: true,
  },
  {
    id: 'demo-2',
    title: 'Midnight Reverie',
    artist: 'Lunar Shift',
    album: 'Echoes in the Dark',
    genre: 'Electronic',
    year: 2025,
    duration: 28,
    artworkUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&auto=format&fit=crop&q=80',
    dateAdded: Date.now() - 3600000 * 24 * 5,
    playCount: 9,
    isFavorite: false,
  },
  {
    id: 'demo-3',
    title: 'Autumn Solitude',
    artist: 'Sierra Valley',
    album: 'Acoustic Memories',
    genre: 'Acoustic',
    year: 2026,
    duration: 36,
    artworkUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400&auto=format&fit=crop&q=80',
    dateAdded: Date.now() - 3600000 * 12,
    playCount: 21,
    isFavorite: true,
  },
];

export async function getSongsFromStorage(): Promise<Song[]> {
  try {
    const db = await openDB();
    const tx = db.transaction([STORE_SONGS, STORE_AUDIO], 'readonly');
    const songStore = tx.objectStore(STORE_SONGS);
    const audioStore = tx.objectStore(STORE_AUDIO);

    const songs: Song[] = await new Promise((resolve) => {
      const req = songStore.getAll();
      req.onsuccess = () => resolve(req.result || []);
    });

    if (songs.length === 0) {
      // Seed demo tracks
      return await seedDemoTracks();
    }

    // Attach object URLs for audio blobs
    for (const song of songs) {
      const audioRecord: { id: string; blob: Blob } = await new Promise((resolve) => {
        const req = audioStore.get(song.id);
        req.onsuccess = () => resolve(req.result);
      });
      if (audioRecord && audioRecord.blob) {
        song.audioUrl = URL.createObjectURL(audioRecord.blob);
      }
    }

    return songs;
  } catch (err) {
    console.error('Error loading songs from IndexedDB', err);
    return [];
  }
}

export async function seedDemoTracks(): Promise<Song[]> {
  const db = await openDB();
  const tx = db.transaction([STORE_SONGS, STORE_AUDIO, STORE_PLAYLISTS], 'readwrite');
  const songStore = tx.objectStore(STORE_SONGS);
  const audioStore = tx.objectStore(STORE_AUDIO);
  const playlistStore = tx.objectStore(STORE_PLAYLISTS);

  const notesList = [
    [261.63, 329.63, 392.0, 523.25, 440.0, 392.0, 329.63, 261.63], // C-E-G-C-A-G-E-C
    [220.0, 261.63, 329.63, 440.0, 349.23, 329.63, 261.63, 220.0], // A-C-E-A-F-E-C-A
    [293.66, 369.99, 440.0, 587.33, 493.88, 440.0, 369.99, 293.66], // D-F#-A-D-B-A-F#-D
  ];

  const loadedSongs: Song[] = [];

  for (let i = 0; i < INITIAL_DEMO_TRACKS.length; i++) {
    const meta = INITIAL_DEMO_TRACKS[i];
    const blob = createSynthesizedAudioBlob(notesList[i], 70 + i * 10, meta.duration);
    const song: Song = {
      ...meta,
      audioUrl: URL.createObjectURL(blob),
      fileSize: blob.size,
      contentHash: `demo_hash_${i}`,
    };

    songStore.put({ ...song, audioUrl: '' });
    audioStore.put({ id: song.id, blob });
    loadedSongs.push(song);
  }

  // Create initial demo playlist
  const initialPlaylist: Playlist = {
    id: 'playlist-chill-vibes',
    name: 'Chill Vibes',
    description: 'Relaxing ambient & acoustic tracks for focus and winding down.',
    createdAt: Date.now() - 3600000 * 24,
    coverUrl: INITIAL_DEMO_TRACKS[0].artworkUrl,
    songIds: ['demo-1', 'demo-3'],
  };
  playlistStore.put(initialPlaylist);

  return loadedSongs;
}

export async function saveSongToStorage(song: Song, audioBlob: Blob): Promise<void> {
  const db = await openDB();
  const tx = db.transaction([STORE_SONGS, STORE_AUDIO], 'readwrite');
  tx.objectStore(STORE_SONGS).put({ ...song, audioUrl: '' });
  tx.objectStore(STORE_AUDIO).put({ id: song.id, blob: audioBlob });
}

export async function updateSongInStorage(song: Song): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(STORE_SONGS, 'readwrite');
  tx.objectStore(STORE_SONGS).put({ ...song, audioUrl: '' });
}

export async function deleteSongFromStorage(songId: string): Promise<void> {
  const db = await openDB();
  const tx = db.transaction([STORE_SONGS, STORE_AUDIO, STORE_PLAYLISTS], 'readwrite');
  tx.objectStore(STORE_SONGS).delete(songId);
  tx.objectStore(STORE_AUDIO).delete(songId);

  // Remove from playlists
  const playlistStore = tx.objectStore(STORE_PLAYLISTS);
  const req = playlistStore.getAll();
  req.onsuccess = () => {
    const list: Playlist[] = req.result || [];
    for (const pl of list) {
      if (pl.songIds.includes(songId)) {
        pl.songIds = pl.songIds.filter((id) => id !== songId);
        playlistStore.put(pl);
      }
    }
  };
}

export async function getPlaylistsFromStorage(): Promise<Playlist[]> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_PLAYLISTS, 'readonly');
    const store = tx.objectStore(STORE_PLAYLISTS);
    return new Promise((resolve) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
    });
  } catch {
    return [];
  }
}

export async function savePlaylistToStorage(playlist: Playlist): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(STORE_PLAYLISTS, 'readwrite');
  tx.objectStore(STORE_PLAYLISTS).put(playlist);
}

export async function deletePlaylistFromStorage(playlistId: string): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(STORE_PLAYLISTS, 'readwrite');
  tx.objectStore(STORE_PLAYLISTS).delete(playlistId);
}

export async function calculateStorageUsage(): Promise<{ songsSize: number; count: number }> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_AUDIO, 'readonly');
    const store = tx.objectStore(STORE_AUDIO);
    const records: { id: string; blob: Blob }[] = await new Promise((resolve) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
    });
    let totalBytes = 0;
    for (const r of records) {
      if (r.blob) totalBytes += r.blob.size;
    }
    return { songsSize: totalBytes, count: records.length };
  } catch {
    return { songsSize: 0, count: 0 };
  }
}

export async function calculateSHA256(file: File | Blob): Promise<string> {
  const buffer = await file.arrayBuffer();
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}
