type EmbeddedAssetRegistry = typeof globalThis & {
  __MANARA_EMBEDDED_ASSETS__?: Record<string, string>;
};

/** يعيد بيانات الملف المضمنة في بناء HTML المستقل، أو يبقي الرابط كما هو في الموقع المعتاد. */
export function resolvePublicAsset(url: string): string {
  if (!url.startsWith('/')) return url;
  const registry = (globalThis as EmbeddedAssetRegistry).__MANARA_EMBEDDED_ASSETS__;
  return registry?.[url] ?? url;
}

/** يحوّل PDF مضمنًا إلى Blob URL لأن بعض المتصفحات تمنع فتح data: في تبويب علوي. */
export function createPdfObjectUrl(url: string): string {
  const hashIndex = url.indexOf('#');
  const dataUrl = hashIndex >= 0 ? url.slice(0, hashIndex) : url;
  const fragment = hashIndex >= 0 ? url.slice(hashIndex) : '';
  const match = /^data:application\/pdf;base64,([\s\S]+)$/i.exec(dataUrl);
  if (!match) return url;
  const encoded = match[1];
  if (!encoded) return url;

  const binary = window.atob(encoded);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return `${URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }))}${fragment}`;
}

/** يفتح رابط الملف عند ضغط المستخدم؛ في وضع HTML المحلي يستخدم Blob URL لا data URL مباشرة. */
export function openAssetInNewTab(url: string, filename = 'manara-document.pdf'): void {
  const objectUrl = createPdfObjectUrl(url);
  const objectUrlBase = objectUrl.split('#', 1)[0] || objectUrl;
  const originalBase = url.split('#', 1)[0] || url;
  const isObjectUrl = objectUrlBase !== originalBase;

  const tab = window.open(objectUrl, '_blank');
  if (tab) {
    tab.opener = null;
  } else {
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = filename.replace(/[\\/:*?"<>|]/g, '-');
    link.rel = 'noopener noreferrer';
    link.click();
  }

  if (isObjectUrl) {
    window.addEventListener('pagehide', () => URL.revokeObjectURL(objectUrlBase), { once: true });
  }
}
