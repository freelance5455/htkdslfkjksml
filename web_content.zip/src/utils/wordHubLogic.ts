import type {
  VocabEntry,
  VocabStore,
  WordDerivativePos,
  WordHubData,
  WordHubGameId,
  WordMasteryRecord,
} from '../types';

const PLACEHOLDER_PATTERN =
  /^(n\/a|none|null|undefined|-+|لا يوجد|غير متوفر|لا ينطبق|none available|not applicable)$/i;

const VALID_POS_MAP: Record<string, { pos: WordDerivativePos; posAr: string }> = {
  noun: { pos: 'Noun', posAr: 'اسم' },
  verb: { pos: 'Verb', posAr: 'فعل' },
  adjective: { pos: 'Adjective', posAr: 'صفة' },
  adj: { pos: 'Adjective', posAr: 'صفة' },
  adverb: { pos: 'Adverb', posAr: 'ظرف' },
  adv: { pos: 'Adverb', posAr: 'ظرف' },
};

function cleanStr(val: unknown, maxLen = 280): string {
  if (typeof val !== 'string') return '';
  const trimmed = val.replace(/\s+/g, ' ').trim();
  if (!trimmed || PLACEHOLDER_PATTERN.test(trimmed)) return '';
  return trimmed.slice(0, maxLen);
}

function normKey(word: string): string {
  return String(word || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s'-]/g, '')
    .trim();
}

export function normalizeWordKey(word: string): string {
  return normKey(word);
}

/**
 * Strictly sanitizes Word Learning Hub data to enforce linguistic integrity:
 * - Removes placeholders ("N/A", "none", "لا يوجد")
 * - Removes self-referential synonyms/antonyms (never list the word as its own synonym/antonym)
 * - Removes duplicates (case-insensitive)
 * - Enforces valid POS values in wordFamily
 * - Preserves empty arrays when genuine linguistic categories do not exist
 */
export function sanitizeWordHubData(
  raw: Partial<WordHubData> | null | undefined,
  fallbackWord: string,
  fallbackAr: string
): WordHubData {
  const baseWord = cleanStr(raw?.word, 80) || cleanStr(fallbackWord, 80);
  const baseNorm = normKey(baseWord);

  const seenSyn = new Set<string>([baseNorm]);
  const synonyms = (Array.isArray(raw?.synonyms) ? raw!.synonyms : [])
    .map((item) => ({
      word: cleanStr(item?.word, 60),
      ar: cleanStr(item?.ar, 120),
      nuanceAr: cleanStr(item?.nuanceAr, 240),
      exampleEn: cleanStr(item?.exampleEn, 220),
      exampleAr: cleanStr(item?.exampleAr, 220),
    }))
    .filter((item) => {
      const k = normKey(item.word);
      if (!k || seenSyn.has(k) || !item.ar) return false;
      seenSyn.add(k);
      return true;
    })
    .slice(0, 6);

  const seenAnt = new Set<string>([baseNorm]);
  const antonyms = (Array.isArray(raw?.antonyms) ? raw!.antonyms : [])
    .map((item) => ({
      word: cleanStr(item?.word, 60),
      ar: cleanStr(item?.ar, 120),
      contrastAr: cleanStr(item?.contrastAr, 240),
      exampleEn: cleanStr(item?.exampleEn, 220),
      exampleAr: cleanStr(item?.exampleAr, 220),
    }))
    .filter((item) => {
      const k = normKey(item.word);
      if (!k || seenAnt.has(k) || seenSyn.has(k) || !item.ar) return false;
      seenAnt.add(k);
      return true;
    })
    .slice(0, 5);

  const seenFam = new Set<string>();
  const rawWordFamily = (Array.isArray(raw?.wordFamily) ? raw!.wordFamily : [])
    .map((item) => {
      const rawPos = cleanStr(item?.pos, 24).toLowerCase();
      const mapped = VALID_POS_MAP[rawPos];
      if (!mapped) return null;
      const w = cleanStr(item?.word, 60);
      const ar = cleanStr(item?.ar, 120);
      if (!w || !ar) return null;
      return {
        word: w,
        pos: mapped.pos,
        posAr: cleanStr(item?.posAr, 40) || mapped.posAr,
        ar,
        exampleEn: cleanStr(item?.exampleEn, 200),
      };
    })
    .filter((item): item is NonNullable<typeof item> => {
      if (!item) return false;
      const k = `${normKey(item.word)}:${item.pos}`;
      if (seenFam.has(k)) return false;
      seenFam.add(k);
      return true;
    })
    .slice(0, 8);
  // If wordFamily only repeats the base word itself with no real derivatives, leave empty
  const wordFamily =
    rawWordFamily.length === 1 && normKey(rawWordFamily[0].word) === baseNorm
      ? []
      : rawWordFamily;

  const seenRel = new Set<string>([baseNorm]);
  const relatedWords = (Array.isArray(raw?.relatedWords) ? raw!.relatedWords : [])
    .map((item) => ({
      word: cleanStr(item?.word, 60),
      ar: cleanStr(item?.ar, 120),
      relationAr: cleanStr(item?.relationAr, 200),
    }))
    .filter((item) => {
      const k = normKey(item.word);
      if (!k || seenRel.has(k) || !item.ar) return false;
      seenRel.add(k);
      return true;
    })
    .slice(0, 8);

  const seenCol = new Set<string>();
  const collocations = (Array.isArray(raw?.collocations) ? raw!.collocations : [])
    .map((item) => ({
      phrase: cleanStr(item?.phrase, 90),
      ar: cleanStr(item?.ar, 140),
      exampleEn: cleanStr(item?.exampleEn, 220),
      exampleAr: cleanStr(item?.exampleAr, 220),
    }))
    .filter((item) => {
      const k = normKey(item.phrase);
      if (!k || seenCol.has(k) || !item.ar) return false;
      seenCol.add(k);
      return true;
    })
    .slice(0, 8);

  const seenEx = new Set<string>();
  const examples = (Array.isArray(raw?.examples) ? raw!.examples : [])
    .map((item) => {
      const reg =
        item?.register === 'formal' || item?.register === 'informal' || item?.register === 'neutral'
          ? item.register
          : 'neutral';
      return {
        en: cleanStr(item?.en, 240),
        ar: cleanStr(item?.ar, 240),
        register: reg as 'neutral' | 'formal' | 'informal',
      };
    })
    .filter((item) => {
      const k = item.en.toLowerCase();
      if (!k || seenEx.has(k)) return false;
      seenEx.add(k);
      return true;
    })
    .slice(0, 6);

  const commonMistakes = (Array.isArray(raw?.commonMistakes) ? raw!.commonMistakes : [])
    .map((item) => ({
      wrong: cleanStr(item?.wrong, 180),
      right: cleanStr(item?.right, 180),
      noteAr: cleanStr(item?.noteAr, 220),
    }))
    .filter((item) => item.wrong && item.right && item.wrong.toLowerCase() !== item.right.toLowerCase())
    .slice(0, 4);

  const usageNotes = (Array.isArray(raw?.usageNotes) ? raw!.usageNotes : [])
    .map((n) => cleanStr(n, 240))
    .filter(Boolean)
    .slice(0, 5);

  const seenIdiom = new Set<string>();
  const idioms = (Array.isArray(raw?.idioms) ? raw!.idioms : [])
    .map((item) => ({
      phrase: cleanStr(item?.phrase, 100),
      ar: cleanStr(item?.ar, 160),
      exampleEn: cleanStr(item?.exampleEn, 220),
    }))
    .filter((item) => {
      const k = normKey(item.phrase);
      if (!k || seenIdiom.has(k) || !item.ar) return false;
      seenIdiom.add(k);
      return true;
    })
    .slice(0, 5);

  const seenPv = new Set<string>();
  const phrasalVerbs = (Array.isArray(raw?.phrasalVerbs) ? raw!.phrasalVerbs : [])
    .map((item) => ({
      phrase: cleanStr(item?.phrase, 80),
      ar: cleanStr(item?.ar, 160),
      exampleEn: cleanStr(item?.exampleEn, 220),
    }))
    .filter((item) => {
      const k = normKey(item.phrase);
      if (!k || seenPv.has(k) || !item.ar || !item.phrase.includes(' ')) return false;
      seenPv.add(k);
      return true;
    })
    .slice(0, 6);

  const secondaryMeanings = (Array.isArray(raw?.secondaryMeanings) ? raw!.secondaryMeanings : [])
    .map((m) => ({
      posEn: cleanStr(m?.posEn, 30),
      definitionEn: cleanStr(m?.definitionEn, 200),
      ar: cleanStr(m?.ar, 120),
    }))
    .filter((m) => m.definitionEn && m.ar)
    .slice(0, 3);

  const fvi = raw?.formalVsInformal;
  const formalVsInformal =
    fvi && cleanStr(fvi.noteAr, 240)
      ? {
          registerLabel:
            fvi.registerLabel === 'Formal' || fvi.registerLabel === 'Informal'
              ? fvi.registerLabel
              : ('Neutral' as const),
          registerLabelAr:
            cleanStr(fvi.registerLabelAr, 40) ||
            (fvi.registerLabel === 'Formal'
              ? 'رسمي'
              : fvi.registerLabel === 'Informal'
                ? 'غير رسمي'
                : 'محايد (شائع في كل المواقف)'),
          noteAr: cleanStr(fvi.noteAr, 240),
          formalAlt: cleanStr(fvi.formalAlt, 80) || undefined,
          informalAlt: cleanStr(fvi.informalAlt, 80) || undefined,
        }
      : null;

  return {
    word: baseWord,
    posEn: cleanStr(raw?.posEn, 32),
    posAr: cleanStr(raw?.posAr, 40),
    ipaUs: cleanStr(raw?.ipaUs, 60).replace(/^\/+|\/+$/g, ''),
    ipaUk: cleanStr(raw?.ipaUk, 60).replace(/^\/+|\/+$/g, ''),
    audioUs: cleanStr(raw?.audioUs, 300) || undefined,
    audioUk: cleanStr(raw?.audioUk, 300) || undefined,
    definitionEn: cleanStr(raw?.definitionEn, 260),
    definitionAr: cleanStr(raw?.definitionAr, 240) || cleanStr(fallbackAr, 160),
    secondaryMeanings: secondaryMeanings.length > 0 ? secondaryMeanings : undefined,
    synonyms,
    antonyms,
    wordFamily,
    relatedWords,
    collocations,
    examples,
    commonMistakes,
    usageNotes,
    formalVsInformal,
    idioms,
    phrasalVerbs,
    wordOrigin: cleanStr(raw?.wordOrigin, 320),
    memoryTip: cleanStr(raw?.memoryTip, 260),
    source: raw?.source || 'dictionary+ai',
  };
}

/**
 * Earned Mastery Calculator:
 * Viewing a word gives 0%. Mastery is ONLY earned by demonstrating real understanding & usage:
 * - Each unique completed Word Hub mini-game: +22% (up to 4 games = 88%)
 * - Passing voice pronunciation: +20%
 * - Passing AI sentence builder using the word: +25%
 * - Bonus for high accuracy (>= 3 correct answers with >= 70% accuracy): +12%
 * Word is considered Earned Mastered at >= 70% AND at least 2 verified activities completed.
 */
export function computeWordMastery(record: WordMasteryRecord | null | undefined): {
  scorePct: number;
  isEarnedMastered: boolean;
  verifiedActivities: number;
} {
  if (!record) {
    return { scorePct: 0, isEarnedMastered: false, verifiedActivities: 0 };
  }
  const uniqueGames = Array.from(new Set(record.completedGames || []));
  const gamePoints = Math.min(80, uniqueGames.length * 22);
  const pronPoints = record.pronunciationPassed ? 20 : 0;
  const sentPoints = record.sentencePassed ? 25 : 0;
  const totalAttempts = (record.correctAnswers || 0) + (record.wrongAnswers || 0);
  const acc = totalAttempts > 0 ? (record.correctAnswers || 0) / totalAttempts : 0;
  const accuracyBonus = (record.correctAnswers || 0) >= 3 && acc >= 0.7 ? 10 : 0;

  const scorePct = Math.min(100, gamePoints + pronPoints + sentPoints + accuracyBonus);
  const verifiedActivities =
    uniqueGames.length + (record.pronunciationPassed ? 1 : 0) + (record.sentencePassed ? 1 : 0);

  return {
    scorePct,
    isEarnedMastered: scorePct >= 70 && verifiedActivities >= 2,
    verifiedActivities,
  };
}

/**
 * Fast lookup of a clicked synonym/antonym/related word inside the local VocabStore.
 */
export function findWordInStore(store: VocabStore, targetWord: string): VocabEntry | null {
  const needle = normKey(targetWord);
  if (!needle) return null;
  for (let i = 0; i < store.words.length; i++) {
    if (store.normEn[i] === needle) {
      return store.words[i];
    }
  }
  return null;
}

// ============================================================
// Dynamic 8 Word-Specific Mini-Games Engine
// ============================================================

export interface WordHubQuizQuestion {
  id: string;
  promptAr: string;
  promptEn?: string;
  options: string[];
  correctIndex: number;
  explanationAr: string;
  correctLabel: string;
}

export interface WordHubMemoryPair {
  id: string;
  leftText: string;
  rightText: string;
  hintAr: string;
}

export interface WordHubGameSpec {
  id: WordHubGameId;
  titleAr: string;
  subtitleAr: string;
  available: boolean;
  unavailableReasonAr?: string;
  kind: 'quiz' | 'memory';
  questions: WordHubQuizQuestion[];
  memoryPairs?: WordHubMemoryPair[];
}

function deterministicShuffle<T>(items: T[], seedStr: string): T[] {
  const arr = [...items];
  let seed = 0;
  for (let i = 0; i < seedStr.length; i++) {
    seed = (seed * 31 + seedStr.charCodeAt(i)) >>> 0;
  }
  for (let i = arr.length - 1; i > 0; i--) {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    const j = seed % (i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function pickDistractors(
  excludeWords: string[],
  pool: VocabEntry[],
  count: number,
  seed: string,
  field: 'en' | 'ar' = 'en'
): string[] {
  const excluded = new Set(excludeWords.map((w) => normKey(w)));
  const candidates: string[] = [];
  const seen = new Set<string>();
  const shuffled = deterministicShuffle(pool.slice(0, 120), seed);
  for (const w of shuffled) {
    const val = (field === 'en' ? w.en : w.ar).trim();
    const k = normKey(val);
    if (!val || excluded.has(normKey(w.en)) || excluded.has(k) || seen.has(k)) continue;
    seen.add(k);
    candidates.push(val);
    if (candidates.length >= count) break;
  }
  return candidates;
}

function maskWordInSentence(sentence: string, target: string): string {
  const escaped = target.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`\\b${escaped}[a-z]*\\b`, 'i');
  if (re.test(sentence)) {
    return sentence.replace(re, '______');
  }
  return sentence;
}

function makeMcq(
  id: string,
  promptAr: string,
  promptEn: string | undefined,
  correct: string,
  distractors: string[],
  explanationAr: string,
  seed: string
): WordHubQuizQuestion {
  const uniqueOpts: string[] = [correct];
  const seen = new Set([correct.toLowerCase()]);
  for (const d of distractors) {
    const clean = d.trim();
    if (clean && !seen.has(clean.toLowerCase())) {
      seen.add(clean.toLowerCase());
      uniqueOpts.push(clean);
    }
    if (uniqueOpts.length >= 4) break;
  }
  const ordered = deterministicShuffle(uniqueOpts, seed);
  return {
    id,
    promptAr,
    promptEn,
    options: ordered,
    correctIndex: ordered.indexOf(correct),
    explanationAr,
    correctLabel: correct,
  };
}

/**
 * Generates all 8 word-specific interactive games strictly from verified WordHubData.
 * Any game that requires linguistic relations not present for this word (e.g., Antonym Challenge
 * for a concrete noun with no direct antonym) is cleanly marked available: false — NEVER fabricated!
 */
export function buildWordHubGames(
  hub: WordHubData,
  word: VocabEntry,
  distractorPool: VocabEntry[]
): WordHubGameSpec[] {
  const baseExclude = [
    word.en,
    ...hub.synonyms.map((s) => s.word),
    ...hub.antonyms.map((a) => a.word),
    ...hub.wordFamily.map((f) => f.word),
  ];

  // 1. Synonym Match
  const synQuestions: WordHubQuizQuestion[] = hub.synonyms.slice(0, 3).map((syn, idx) => {
    const distractors = [
      ...hub.antonyms.map((a) => a.word),
      ...pickDistractors(baseExclude, distractorPool, 4, `${word.en}:syn:${idx}`),
    ];
    return makeMcq(
      `syn-${idx}`,
      `اختر المرادف الأقرب لمعنى كلمة «${word.en}»:`,
      syn.nuanceAr ? `تلميح الفرق: ${syn.nuanceAr}` : undefined,
      syn.word,
      distractors,
      `«${syn.word}» (${syn.ar}) مرادف صحيح لكلمة «${word.en}». ${syn.nuanceAr || ''}`.trim(),
      `${word.en}:syn-opt:${idx}`
    );
  });

  // 2. Antonym Challenge (ONLY enabled if genuine antonyms exist!)
  const antQuestions: WordHubQuizQuestion[] = hub.antonyms.slice(0, 3).map((ant, idx) => {
    const distractors = [
      ...hub.synonyms.map((s) => s.word),
      ...pickDistractors(baseExclude, distractorPool, 4, `${word.en}:ant:${idx}`),
    ];
    return makeMcq(
      `ant-${idx}`,
      `اختر الضد الصحيح لكلمة «${word.en}»:`,
      undefined,
      ant.word,
      distractors,
      `«${ant.word}» (${ant.ar}) هو الضد المباشر لكلمة «${word.en}». ${ant.contrastAr || ''}`.trim(),
      `${word.en}:ant-opt:${idx}`
    );
  });

  // 3. Definition Quiz
  const defQuestions: WordHubQuizQuestion[] = [];
  if (hub.definitionEn) {
    const enDistractors = pickDistractors(baseExclude, distractorPool, 3, `${word.en}:def-en`, 'en');
    defQuestions.push(
      makeMcq(
        'def-0',
        'أي كلمة إنجليزية تطابق هذا التعريف؟',
        hub.definitionEn,
        word.en,
        enDistractors,
        `هذا هو التعريف الدقيق لكلمة «${word.en}» وتعني بالعربية: ${word.ar}.`,
        `${word.en}:def-opt-0`
      )
    );
  }
  const arDistractors = pickDistractors([word.ar, word.en], distractorPool, 3, `${word.en}:def-ar`, 'ar');
  if (word.ar && arDistractors.length >= 2) {
    defQuestions.push(
      makeMcq(
        'def-1',
        `اختر المعنى العربي الأدق لكلمة «${word.en}»:`,
        hub.definitionEn || undefined,
        word.ar,
        arDistractors,
        `«${word.en}» تعني «${word.ar}».`,
        `${word.en}:def-opt-1`
      )
    );
  }

  // 4. Word Family Builder (ONLY enabled if genuine derivatives >= 2)
  const familyQuestions: WordHubQuizQuestion[] =
    hub.wordFamily.length >= 2
      ? hub.wordFamily.slice(0, 3).map((fam, idx) => {
          const sameFamilyOthers = hub.wordFamily
            .filter((f) => f.word.toLowerCase() !== fam.word.toLowerCase())
            .map((f) => f.word);
          const extraDistractors = pickDistractors(
            baseExclude,
            distractorPool,
            3,
            `${word.en}:fam:${idx}`
          );
          return makeMcq(
            `fam-${idx}`,
            `أي صيغة من عائلة «${word.en}» تمثل (${fam.posAr} — ${fam.pos}) وتعني «${fam.ar}»؟`,
            fam.exampleEn ? maskWordInSentence(fam.exampleEn, fam.word) : undefined,
            fam.word,
            [...sameFamilyOthers, ...extraDistractors],
            `الصيغة الصحيحة هي «${fam.word}» وهي (${fam.posAr}) وتعني «${fam.ar}».`,
            `${word.en}:fam-opt:${idx}`
          );
        })
      : [];

  // 5. Collocation Challenge
  const collQuestions: WordHubQuizQuestion[] = hub.collocations.slice(0, 3).map((col, idx) => {
    const otherCols = hub.collocations
      .filter((c) => c.phrase.toLowerCase() !== col.phrase.toLowerCase())
      .map((c) => c.phrase);
    const fakeCols = pickDistractors(baseExclude, distractorPool, 3, `${word.en}:col:${idx}`).map(
      (d) => `${d} ${word.en}`
    );
    return makeMcq(
      `col-${idx}`,
      `اختر التلازم اللفظي (Collocation) الطبيعي الذي يعني «${col.ar}»:`,
      col.exampleEn ? col.exampleEn.replace(new RegExp(col.phrase.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'), '______') : undefined,
      col.phrase,
      [...otherCols, ...fakeCols],
      `التعبير الطبيعي الشائع هو «${col.phrase}» ويعني «${col.ar}».`,
      `${word.en}:col-opt:${idx}`
    );
  });

  // 6. Context Challenge (choose correct sentence or register/usage)
  const ctxQuestions: WordHubQuizQuestion[] = [];
  if (hub.commonMistakes.length > 0) {
    hub.commonMistakes.slice(0, 2).forEach((m, idx) => {
      ctxQuestions.push(
        makeMcq(
          `ctx-m-${idx}`,
          'اختر الجملة الصحيحة لغوياً وطبيعياً:',
          undefined,
          m.right,
          [m.wrong],
          `الصواب: «${m.right}». السبب: ${m.noteAr}`,
          `${word.en}:ctx-m:${idx}`
        )
      );
    });
  }
  if (hub.examples.length > 0 && ctxQuestions.length < 2) {
    const ex = hub.examples[0];
    const distractors = pickDistractors(baseExclude, distractorPool, 3, `${word.en}:ctx-ex`);
    ctxQuestions.push(
      makeMcq(
        'ctx-ex-0',
        `ما الكلمة الأنسب لإكمال هذا السياق الطبيعي؟`,
        maskWordInSentence(ex.en, word.en),
        word.en,
        distractors,
        `الكلمة الصحيحة في هذا السياق هي «${word.en}»: ${ex.en}`,
        `${word.en}:ctx-ex-opt`
      )
    );
  }

  // 7. Memory Match (matching pairs from real synonyms, family, collocations, or related words)
  const memoryPairs: WordHubMemoryPair[] = [];
  const usedLeft = new Set<string>();
  const pushPair = (left: string, right: string, hintAr: string) => {
    const k = left.toLowerCase();
    if (!left || !right || usedLeft.has(k) || memoryPairs.length >= 4) return;
    usedLeft.add(k);
    memoryPairs.push({ id: `pair-${memoryPairs.length}`, leftText: left, rightText: right, hintAr });
  };

  pushPair(word.en, word.ar, 'الكلمة الأساسية ومعناها');
  hub.synonyms.slice(0, 2).forEach((s) => pushPair(s.word, s.ar, `مرادف لـ ${word.en}`));
  hub.wordFamily.slice(0, 2).forEach((f) => pushPair(f.word, `${f.ar} (${f.posAr})`, 'من عائلة الكلمة'));
  hub.collocations.slice(0, 2).forEach((c) => pushPair(c.phrase, c.ar, 'تلازم لفظي شائع'));
  hub.relatedWords.slice(0, 2).forEach((r) => pushPair(r.word, r.ar, 'كلمة مرتبطة'));
  hub.antonyms.slice(0, 1).forEach((a) => pushPair(a.word, `${a.ar} (ضد)`, `ضد ${word.en}`));

  // 8. Sentence Completion (fill the natural blank across all word examples)
  const compQuestions: WordHubQuizQuestion[] = [];
  const candidateExamples = [
    ...hub.examples.map((e) => ({ en: e.en, ar: e.ar, target: word.en })),
    ...hub.synonyms
      .filter((s) => s.exampleEn)
      .slice(0, 1)
      .map((s) => ({ en: s.exampleEn, ar: s.exampleAr || s.ar, target: s.word })),
  ];
  candidateExamples.slice(0, 3).forEach((item, idx) => {
    const masked = maskWordInSentence(item.en, item.target);
    if (masked === item.en) return;
    const distractors = pickDistractors(
      [item.target, ...baseExclude.filter((w) => w.toLowerCase() !== item.target.toLowerCase())],
      distractorPool,
      3,
      `${word.en}:comp:${idx}`
    );
    compQuestions.push(
      makeMcq(
        `comp-${idx}`,
        item.ar ? `أكمل الجملة التالية (${item.ar}):` : 'أكمل الجملة التالية بالكلمة الصحيحة:',
        masked,
        item.target,
        distractors,
        `الجملة الكاملة الصحيحة: «${item.en}».`,
        `${word.en}:comp-opt:${idx}`
      )
    );
  });

  return [
    {
      id: 'synonym_match',
      titleAr: 'مطابقة المرادف',
      subtitleAr: 'اختر المرادف الأدق وافهم الفرق الدقيق',
      available: synQuestions.length > 0,
      unavailableReasonAr: 'لا توجد مرادفات مباشرة مسجلة لهذه الكلمة.',
      kind: 'quiz',
      questions: synQuestions,
    },
    {
      id: 'antonym_challenge',
      titleAr: 'تحدي الضد',
      subtitleAr: 'اختبر معرفتك بالأضداد الحقيقية للكلمة',
      available: antQuestions.length > 0,
      unavailableReasonAr: 'هذه الكلمة ليس لها ضد مباشر باللغة الإنجليزية.',
      kind: 'quiz',
      questions: antQuestions,
    },
    {
      id: 'definition_quiz',
      titleAr: 'اختبار التعريف',
      subtitleAr: 'اربط التعريف الإنجليزي والمعنى بالكلمة',
      available: defQuestions.length > 0,
      unavailableReasonAr: 'التعريف غير متوفر حالياً.',
      kind: 'quiz',
      questions: defQuestions,
    },
    {
      id: 'word_family',
      titleAr: 'بناء عائلة الكلمة',
      subtitleAr: 'ميّز بين الاسم والفعل والصفة والظرف',
      available: familyQuestions.length > 0,
      unavailableReasonAr: 'لا توجد اشتقاقات متعددة لهذه الكلمة.',
      kind: 'quiz',
      questions: familyQuestions,
    },
    {
      id: 'collocation_challenge',
      titleAr: 'تحدي التلازم اللفظي',
      subtitleAr: 'اختر التركيب الطبيعي الذي يستخدمه المتحدثون',
      available: collQuestions.length > 0,
      unavailableReasonAr: 'لا توجد تلازمات لفظية مسجلة حالياً.',
      kind: 'quiz',
      questions: collQuestions,
    },
    {
      id: 'context_challenge',
      titleAr: 'اختيار السياق الصحيح',
      subtitleAr: 'تجنّب الأخطاء الشائعة واختر الاستخدام الصحيح',
      available: ctxQuestions.length > 0,
      unavailableReasonAr: 'سياقات الاستخدام غير متوفرة حالياً.',
      kind: 'quiz',
      questions: ctxQuestions,
    },
    {
      id: 'memory_match',
      titleAr: 'لعبة الذاكرة',
      subtitleAr: 'طابق الكلمة وعلاقاتها ومعانيها بسرعة',
      available: memoryPairs.length >= 3,
      unavailableReasonAr: 'تحتاج 3 عناصر مرتبطة على الأقل.',
      kind: 'memory',
      questions: [],
      memoryPairs,
    },
    {
      id: 'sentence_completion',
      titleAr: 'إكمال الجملة',
      subtitleAr: 'ضع الكلمة في مكانها الطبيعي داخل الجملة',
      available: compQuestions.length > 0,
      unavailableReasonAr: 'لا توجد أمثلة جاهزة لإكمال الجملة.',
      kind: 'quiz',
      questions: compQuestions,
    },
  ];
}
