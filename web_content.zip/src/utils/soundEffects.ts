/**
 * Web Audio API synthesized sound effects and procedural ambient nature sounds for Waqti.
 * Zero external asset dependencies - instant, lightweight, works offline and perfectly in PWA.
 */

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

// ===================== AMBIENT NATURE SOUNDS GENERATOR =====================

export type AmbientSoundType = 'none' | 'rain' | 'forest' | 'whitenoise' | 'waves';

interface AmbientState {
  type: AmbientSoundType;
  volume: number;
  masterGain: GainNode | null;
  sources: (AudioNode | number)[] ; // Nodes to stop or timer IDs
  active: boolean;
}

const currentAmbient: AmbientState = {
  type: 'none',
  volume: 0.5,
  masterGain: null,
  sources: [],
  active: false,
};

function createNoiseBuffer(ctx: AudioContext, duration = 4): AudioBuffer {
  const bufferSize = ctx.sampleRate * duration;
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let lastOut = 0.0;
  for (let i = 0; i < bufferSize; i++) {
    const white = Math.random() * 2 - 1;
    // Pink noise filter
    data[i] = (lastOut + 0.02 * white) / 1.02;
    lastOut = data[i];
    data[i] *= 3.5; // Gain compensation
  }
  return buffer;
}

export function stopAmbientSound() {
  currentAmbient.active = false;
  currentAmbient.sources.forEach((item) => {
    if (typeof item === 'number') {
      window.clearInterval(item);
    } else if (item && 'stop' in item && typeof (item as any).stop === 'function') {
      try {
        (item as any).stop();
      } catch {
        //
      }
    } else if (item && 'disconnect' in item && typeof item.disconnect === 'function') {
      try {
        item.disconnect();
      } catch {
        //
      }
    }
  });
  currentAmbient.sources = [];
  if (currentAmbient.masterGain) {
    try {
      currentAmbient.masterGain.disconnect();
    } catch {
      //
    }
    currentAmbient.masterGain = null;
  }
}

export function setAmbientVolume(volume: number) {
  currentAmbient.volume = Math.max(0, Math.min(1, volume));
  if (currentAmbient.masterGain && audioCtx) {
    currentAmbient.masterGain.gain.setValueAtTime(currentAmbient.volume, audioCtx.currentTime);
  }
}

export function startAmbientSound(type: AmbientSoundType, volume = 0.5) {
  stopAmbientSound();
  if (type === 'none') {
    currentAmbient.type = 'none';
    return;
  }

  const ctx = getAudioContext();
  if (!ctx) return;

  currentAmbient.type = type;
  currentAmbient.volume = Math.max(0, Math.min(1, volume));
  currentAmbient.active = true;

  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(currentAmbient.volume, ctx.currentTime);
  masterGain.connect(ctx.destination);
  currentAmbient.masterGain = masterGain;

  // 1. RAIN (صوت المطر الغزير الرخيم)
  if (type === 'rain') {
    const noiseBuffer = createNoiseBuffer(ctx, 5);
    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    // Bandpass and Lowpass filters to shape rain acoustics
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1400, ctx.currentTime);

    const rainGain = ctx.createGain();
    rainGain.gain.setValueAtTime(0.7, ctx.currentTime);

    noiseSource.connect(filter);
    filter.connect(rainGain);
    rainGain.connect(masterGain);

    noiseSource.start();
    currentAmbient.sources.push(noiseSource, filter, rainGain);
  }

  // 2. WHITE / BROWN NOISE (الضوضاء البيضاء للتركيز العميق)
  else if (type === 'whitenoise') {
    const noiseBuffer = createNoiseBuffer(ctx, 4);
    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, ctx.currentTime); // Deep warm brown noise

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.65, ctx.currentTime);

    noiseSource.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(masterGain);

    noiseSource.start();
    currentAmbient.sources.push(noiseSource, filter, noiseGain);
  }

  // 3. FOREST & BIRDS (نسيم الغابة والطيور)
  else if (type === 'forest') {
    // Breeze wind background
    const noiseBuffer = createNoiseBuffer(ctx, 6);
    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    const windFilter = ctx.createBiquadFilter();
    windFilter.type = 'bandpass';
    windFilter.frequency.setValueAtTime(450, ctx.currentTime);
    windFilter.Q.setValueAtTime(1.5, ctx.currentTime);

    const windGain = ctx.createGain();
    windGain.gain.setValueAtTime(0.35, ctx.currentTime);

    noiseSource.connect(windFilter);
    windFilter.connect(windGain);
    windGain.connect(masterGain);
    noiseSource.start();
    currentAmbient.sources.push(noiseSource, windFilter, windGain);

    // Procedural chirping birds at gentle intervals
    const birdInterval = window.setInterval(() => {
      if (!currentAmbient.active || !audioCtx) return;
      try {
        const now = audioCtx.currentTime;
        const osc = audioCtx.createOscillator();
        const bGain = audioCtx.createGain();
        osc.type = 'sine';

        const baseFreq = 2600 + Math.random() * 800;
        osc.frequency.setValueAtTime(baseFreq, now);
        osc.frequency.linearRampToValueAtTime(baseFreq + 600, now + 0.08);
        osc.frequency.linearRampToValueAtTime(baseFreq - 200, now + 0.18);

        bGain.gain.setValueAtTime(0, now);
        bGain.gain.linearRampToValueAtTime(0.08, now + 0.04);
        bGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);

        osc.connect(bGain);
        bGain.connect(masterGain);
        osc.start(now);
        osc.stop(now + 0.22);
      } catch {
        //
      }
    }, 2800);

    currentAmbient.sources.push(birdInterval);
  }

  // 4. OCEAN WAVES (أمواج المحيط الإيقاعية)
  else if (type === 'waves') {
    const noiseBuffer = createNoiseBuffer(ctx, 6);
    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(600, ctx.currentTime);

    const waveGain = ctx.createGain();
    waveGain.gain.setValueAtTime(0.2, ctx.currentTime);

    // LFO oscillator to modulate gain like rolling waves
    const lfo = ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.setValueAtTime(0.12, ctx.currentTime); // ~8 seconds swell cycle

    const lfoGain = ctx.createGain();
    lfoGain.gain.setValueAtTime(0.35, ctx.currentTime);

    lfo.connect(lfoGain);
    lfoGain.connect(waveGain.gain);

    noiseSource.connect(filter);
    filter.connect(waveGain);
    waveGain.connect(masterGain);

    noiseSource.start();
    lfo.start();
    currentAmbient.sources.push(noiseSource, lfo, filter, waveGain, lfoGain);
  }
}

// ===================== UI SHORT SOUND EFFECTS =====================

export function playCoinSound() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    const now = ctx.currentTime;
    osc.frequency.setValueAtTime(987.77, now); // B5
    osc.frequency.setValueAtTime(1318.51, now + 0.08); // E6

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.35);
  } catch {
    //
  }
}

export function playTaskCompleteSound() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const freqs = [523.25, 659.25, 783.99, 1046.5];
    freqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.value = freq;

      const startTime = now + idx * 0.07;
      const duration = 0.25;
      gain.gain.setValueAtTime(0.12, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + duration);
    });
  } catch {
    //
  }
}

export function playPomodoroCompleteSound() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const notes = [440, 554.37, 659.25, 880];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;

      const startTime = now + i * 0.12;
      gain.gain.setValueAtTime(0.18, startTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 1.2);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + 1.2);
    });
  } catch {
    //
  }
}

export function playPurchaseSound() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    [587.33, 739.99, 880, 1174.66].forEach((f, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = f;

      const start = now + idx * 0.05;
      gain.gain.setValueAtTime(0.14, start);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.4);
    });
  } catch {
    //
  }
}

export function playLevelUpSound() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const notes = [261.63, 392.0, 523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.value = freq;

      const start = now + idx * 0.09;
      const length = idx === notes.length - 1 ? 0.8 : 0.3;
      gain.gain.setValueAtTime(0.15, start);
      gain.gain.exponentialRampToValueAtTime(0.001, start + length);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + length);
    });
  } catch {
    //
  }
}

export function playEquipSound() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.1);

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.15);
  } catch {
    //
  }
}

export function playErrorSound() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.setValueAtTime(164.81, now + 0.1);

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.25);
  } catch {
    //
  }
}
