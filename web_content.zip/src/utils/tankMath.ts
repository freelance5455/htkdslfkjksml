import { CHARTS, TANKS, type TankId } from '../data/tankCharts';

export interface TankBounds {
  minMm: number;
  maxMm: number;
  maxLiters: number;
  keys: number[];
}

export type LookupResult =
  | { value: number; error?: undefined }
  | { error: string; value?: undefined };

const BOUNDS_CACHE: Record<TankId, TankBounds> = {} as Record<TankId, TankBounds>;

for (const tank of TANKS) {
  const chart = CHARTS[tank];
  const keys = Object.keys(chart)
    .map(Number)
    .sort((a, b) => a - b);
  const minMm = keys[0] ?? 0;
  const maxMm = keys[keys.length - 1] ?? 0;
  const maxLiters = chart[String(maxMm)] ?? 0;
  BOUNDS_CACHE[tank] = { minMm, maxMm, maxLiters, keys };
}

export const TOTAL_VESSEL_CAPACITY_LITERS = TANKS.reduce(
  (sum, tank) => sum + BOUNDS_CACHE[tank].maxLiters,
  0
);

export function getTankBounds(tank: TankId): TankBounds {
  return BOUNDS_CACHE[tank];
}

export function lookupLiters(tank: TankId, dip: number): LookupResult {
  const obj = CHARTS[tank];
  const { minMm, maxMm, keys } = BOUNDS_CACHE[tank];

  if (!Number.isFinite(dip) || dip < minMm || dip > maxMm) {
    return { error: `Range ${minMm}–${maxMm} mm` };
  }

  const exact = obj[String(dip)];
  if (exact !== undefined) {
    return { value: exact };
  }

  let lo: number | null = null;
  let hi: number | null = null;
  for (const k of keys) {
    if (k < dip) {
      lo = k;
    } else if (k > dip) {
      hi = k;
      break;
    }
  }

  if (lo === null || hi === null || hi - lo > 10) {
    return { error: 'Chart data unavailable' };
  }

  const loVal = Number(obj[String(lo)]);
  const hiVal = Number(obj[String(hi)]);
  return {
    value: loVal + ((hiVal - loVal) * (dip - lo)) / (hi - lo),
  };
}

export function lookupDipFromLiters(tank: TankId, liters: number): LookupResult {
  const obj = CHARTS[tank];
  const { maxLiters, keys } = BOUNDS_CACHE[tank];

  if (!Number.isFinite(liters) || liters < 0 || liters > maxLiters) {
    return { error: `Range 0–${formatNumber(maxLiters)} L` };
  }

  for (let i = 0; i < keys.length; i++) {
    const k = keys[i];
    const v = Number(obj[String(k)]);
    if (v === liters) {
      return { value: k };
    }
    if (v > liters && i > 0) {
      const prevK = keys[i - 1];
      const prevV = Number(obj[String(prevK)]);
      if (v === prevV) {
        return { value: prevK };
      }
      return {
        value: prevK + ((k - prevK) * (liters - prevV)) / (v - prevV),
      };
    }
  }

  return { error: 'Chart data unavailable' };
}

export function formatNumber(n: number): string {
  return Math.round(n).toLocaleString('en-US');
}

export function formatCubicMeters(liters: number): string {
  return (liters / 1000).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}
