// Pakistani CNIC (Computerized National Identity Card) utilities and PTA 668 simulation

export function cleanCNIC(input: string): string {
  return input.replace(/\D/g, '');
}

export function isValidCNIC(cnic: string): boolean {
  return /^\d{13}$/.test(cleanCNIC(cnic));
}

export function formatCNIC(cnic: string): string {
  const digits = cleanCNIC(cnic);
  if (digits.length !== 13) return cnic;
  return `${digits.slice(0, 5)}-${digits.slice(5, 12)}-${digits.slice(12)}`;
}

export function getProvinceFromCNIC(cnic: string): { en: string; ur: string } {
  const digits = cleanCNIC(cnic);
  if (!digits.length) return { en: 'Unknown', ur: 'نامعلوم' };

  const firstDigit = digits.charAt(0);
  switch (firstDigit) {
    case '1':
      return { en: 'Khyber Pakhtunkhwa', ur: 'خیبر پختونخوا' };
    case '2':
      return { en: 'FATA / Ex-Tribal Area', ur: 'قبائلی علاقہ جات (فاٹا)' };
    case '3':
      return { en: 'Punjab', ur: 'پنجاب' };
    case '4':
      return { en: 'Sindh', ur: 'سندھ' };
    case '5':
      return { en: 'Balochistan', ur: 'بلوچستان' };
    case '6':
      return { en: 'Islamabad Capital (ICT)', ur: 'وفاقی دارالحکومت اسلام آباد' };
    case '7':
      return { en: 'Gilgit-Baltistan / AJK', ur: 'گلگت بلتستان اور آزاد کشمیر' };
    default:
      return { en: 'Pakistan', ur: 'پاکستان' };
  }
}

export function getGenderFromCNIC(cnic: string): { en: 'Male' | 'Female'; ur: string } {
  const digits = cleanCNIC(cnic);
  if (!digits.length) return { en: 'Male', ur: 'مرد' };
  const lastDigit = parseInt(digits.charAt(digits.length - 1), 10);
  if (lastDigit % 2 === 1) {
    return { en: 'Male', ur: 'مرد' };
  }
  return { en: 'Female', ur: 'خاتون' };
}

// Generate realistic Pakistani CNIC for quick testing
export function generateSampleCNIC(): string {
  const provinces = ['3', '4', '1', '5', '6'];
  const first = provinces[Math.floor(Math.random() * provinces.length)];
  const remaining = Math.floor(100000000000 + Math.random() * 900000000000).toString();
  return `${first}${remaining.slice(0, 12)}`;
}

// Generates an authentic PTA 668 SMS reply for the given CNIC
export function generatePTA668Reply(cnic: string): {
  rawText: string;
  breakdown: {
    jazz: number;
    telenor: number;
    zong: number;
    ufone: number;
    warid: number;
    totalVoice: number;
    totalData: number;
    totalSims: number;
  };
} {
  const maskedCNIC = cnic.length === 13 
    ? `${cnic.slice(0, 5)}-${'*'.repeat(7)}-${cnic.slice(12)}`
    : cnic;

  // Pseudo-random distribution based on CNIC hash so repeat checks are consistent
  let seed = 0;
  for (let i = 0; i < cnic.length; i++) {
    seed = (seed * 31 + cnic.charCodeAt(i)) % 1000;
  }

  const jazz = (seed % 3);
  const telenor = ((seed >> 2) % 2);
  const zong = ((seed >> 4) % 2);
  const ufone = ((seed >> 6) % 2);
  const warid = 0;
  const totalVoice = jazz + telenor + zong + ufone + warid;
  const totalData = ((seed >> 3) % 2);
  const totalSims = totalVoice + totalData;

  const rawText = `PTA SIM Info (668): CNIC ${maskedCNIC} has registered SIMs: Jazz: ${jazz}, Telenor: ${telenor}, Ufone: ${ufone}, Zong: ${zong}, Warid: ${warid}. Total Voice SIMs: ${totalVoice}, Data SIMs: ${totalData}. Total: ${totalSims}. Max Voice Limit: 5 SIMs.`;

  return {
    rawText,
    breakdown: {
      jazz,
      telenor,
      zong,
      ufone,
      warid,
      totalVoice,
      totalData,
      totalSims,
    },
  };
}
