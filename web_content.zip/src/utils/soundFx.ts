import type { SoundCue } from '../shared/unoTypes';

class SoundEffects {
  private ctx: AudioContext | null = null;
  private muted: boolean = false;

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        this.muted = localStorage.getItem('fliptable_muted') === 'true';
      } catch {
        this.muted = false;
      }
    }
  }

  private getContext(): AudioContext | null {
    if (this.muted || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public setMuted(val: boolean): void {
    this.muted = val;
    try {
      localStorage.setItem('fliptable_muted', String(val));
    } catch {
      // ignore storage failure
    }
  }

  public toggleMute(): boolean {
    this.setMuted(!this.muted);
    return this.muted;
  }

  private tone(
    freq: number,
    duration: number,
    type: OscillatorType = 'sine',
    gainPeak = 0.12,
    delay = 0,
    endFreq?: number
  ) {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    if (endFreq !== undefined) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(40, endFreq), now + duration);
    }
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(gainPeak, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  public playCue(cue: SoundCue): void {
    switch (cue) {
      case 'play':
        this.tone(420, 0.08, 'triangle', 0.13, 0, 580);
        break;
      case 'draw':
        this.tone(280, 0.09, 'sine', 0.08, 0, 210);
        break;
      case 'action':
        this.tone(520, 0.1, 'triangle', 0.12, 0, 680);
        this.tone(680, 0.14, 'triangle', 0.1, 0.07, 780);
        break;
      case 'flip_dark':
        this.tone(540, 0.24, 'sawtooth', 0.07, 0, 180);
        this.tone(360, 0.28, 'triangle', 0.11, 0.05, 140);
        break;
      case 'flip_light':
        this.tone(260, 0.22, 'triangle', 0.11, 0, 660);
        this.tone(520, 0.2, 'sine', 0.1, 0.08, 880);
        break;
      case 'uno':
        this.tone(523.25, 0.11, 'triangle', 0.14, 0);
        this.tone(659.25, 0.11, 'triangle', 0.14, 0.09);
        this.tone(783.99, 0.22, 'triangle', 0.15, 0.18);
        break;
      case 'penalty':
        this.tone(220, 0.16, 'sawtooth', 0.09, 0, 150);
        this.tone(175, 0.22, 'sawtooth', 0.09, 0.12, 120);
        break;
      case 'turn':
        this.tone(620, 0.07, 'sine', 0.06, 0, 740);
        break;
      case 'win':
        this.tone(523.25, 0.14, 'triangle', 0.13, 0);
        this.tone(659.25, 0.14, 'triangle', 0.13, 0.1);
        this.tone(783.99, 0.14, 'triangle', 0.13, 0.2);
        this.tone(1046.5, 0.35, 'triangle', 0.16, 0.3);
        break;
    }
  }
}

export const soundFx = new SoundEffects();
