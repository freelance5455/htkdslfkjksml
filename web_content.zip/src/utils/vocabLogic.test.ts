import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildMissingLettersData,
  buildScrambleData,
  buildStandaloneHtml,
  checkArabicMatch,
  checkEnglishMatch,
  computeCharDiff,
  extractVocabFromInput,
  getBandSubCount,
  getBandSubIndices,
  parseCSVTextToTSV,
  parseTSVToStore,
  pickDistractors,
  searchVocab,
  splitTargetHighlight,
} from './vocabLogic';
import { STARTER_VOCAB_TSV } from '../data/starterVocab';

test('starter vocabulary parses cleanly across all 7 CEFR bands', () => {
  const store = parseTSVToStore(STARTER_VOCAB_TSV);
  assert.equal(store.words.length, 210);
  for (const band of ['A0', 'A1', 'A2', 'B1', 'B2', 'C1', 'C2'] as const) {
    assert.equal(store.byBand[band].length, 30, `Expected 30 words in ${band}`);
  }
});

test('extractVocabFromInput losslessly extracts <script id="embedded-vocab"> from HTML and merges into standalone HTML', () => {
  const originalLines = [
    'A0\tapple\tتفاحة',
    'A1\tbridge\tجسر',
    'C2\tserendipity\tصدفة سعيدة',
  ].join('\n');
  const mockOriginalHtml = `<!DOCTYPE html>
<html>
<body>
<script type="text/plain" id="embedded-vocab">
${originalLines}
</script>
<script>console.log('old app');</script>
</body>
</html>`;

  const extracted = extractVocabFromInput(mockOriginalHtml);
  assert.equal(extracted.found, true);
  assert.equal(extracted.sourceType, 'html_embedded');
  assert.equal(extracted.rawVocabBlock, originalLines);
  assert.equal(extracted.store.words.length, 3);
  assert.equal(extracted.store.words[2].band, 'C2');
  assert.equal(extracted.store.words[2].en, 'serendipity');
  assert.equal(extracted.store.words[2].ar, 'صدفة سعيدة');

  const mergedHtml = buildStandaloneHtml(extracted.rawVocabBlock);
  assert.ok(mergedHtml.includes('<script type="text/plain" id="embedded-vocab">'));
  assert.ok(mergedHtml.includes(originalLines));
  assert.ok(!mergedHtml.includes('<!-- الصق هنا سطور الكلمات من ملفك الأصلي -->'));

  // Re-extracting from merged HTML preserves the exact same 3 words
  const roundTrip = extractVocabFromInput(mergedHtml);
  assert.equal(roundTrip.store.words.length, 3);
  assert.equal(roundTrip.rawVocabBlock, originalLines);
});

test('parseCSVTextToTSV handles headers, quotes, and deduplication', () => {
  const csv = `Band,English,Arabic\nA0,water,"ماء"\nA0,water,"ماء مكرر"\nB1,solution,"حل، مخرج"`;
  const tsv = parseCSVTextToTSV(csv);
  const store = parseTSVToStore(tsv);
  assert.equal(store.words.length, 2);
  assert.equal(store.words[0].en, 'water');
  assert.equal(store.words[1].ar, 'حل، مخرج');
});

test('Arabic and English answer matching handles normalization, diacritics, and synonyms', () => {
  assert.equal(checkArabicMatch('المدرسة', 'مدرسه'), true);
  assert.equal(checkArabicMatch('مخرج', 'حل / مخرج'), true);
  assert.equal(checkArabicMatch('إجابة', 'اجابه'), true);
  assert.equal(checkArabicMatch('سيارة', 'كتاب'), false);

  assert.equal(checkEnglishMatch('  Café ', 'cafe'), true);
  assert.equal(checkEnglishMatch('wellknown', 'well-known'), true);
  assert.equal(checkEnglishMatch('water', 'bread'), false);
});

test('missing letters and scramble puzzles always contain all required blank letters in bank', () => {
  const missing = buildMissingLettersData('education', () => 0.42);
  const blankTargets = missing.slots.filter((s) => s.type === 'blank').map((s) => s.target).sort();
  assert.ok(blankTargets.length >= 2);
  const bankChars = missing.bank.map((b) => b.ch);
  for (const ch of blankTargets) {
    const idx = bankChars.indexOf(ch);
    assert.ok(idx !== -1, `Expected bank to include required letter "${ch}"`);
    bankChars.splice(idx, 1);
  }

  const scramble = buildScrambleData('bridge', () => 0.33);
  assert.equal(scramble.slots.length, 6);
  assert.equal(
    scramble.bank.map((b) => b.ch).sort().join(''),
    'bridge'.split('').sort().join('')
  );
});

test('distractors exclude target word and duplicate translations', () => {
  const store = parseTSVToStore(STARTER_VOCAB_TSV);
  let seed = 1337;
  const rng = () => {
    seed = (seed * 48271) % 2147483647;
    return seed / 2147483647;
  };
  const dist = pickDistractors(store, 0, 3, true, rng);
  assert.equal(dist.length, 3);
  assert.equal(dist.includes(0), false);
  assert.equal(new Set(dist).size, 3);
});

test('searchVocab finds English and Arabic matches with optional band filter', () => {
  const store = parseTSVToStore(STARTER_VOCAB_TSV);
  const enHits = searchVocab(store, 'water', 'ALL');
  assert.ok(enHits.length >= 1);
  assert.equal(store.words[enHits[0]].en, 'water');

  const arHits = searchVocab(store, 'تفاحه', 'A0');
  assert.equal(arHits.length, 1);
  assert.equal(store.words[arHits[0]].en, 'apple');

  const wrongBand = searchVocab(store, 'apple', 'C2');
  assert.equal(wrongBand.length, 0);
});

test('sub-level slicing and target highlighting work accurately', () => {
  const store = parseTSVToStore(STARTER_VOCAB_TSV);
  assert.equal(getBandSubCount(store, 'A0', 20), 2);
  assert.equal(getBandSubIndices(store, 'A0', 0, 20).length, 20);
  assert.equal(getBandSubIndices(store, 'A0', 1, 20).length, 10);

  const hl = splitTargetHighlight('She is learning new skills daily.', 'learn');
  assert.equal(hl.matched, true);
  assert.equal(hl.segments.some((s) => s.highlight && s.text === 'learning'), true);

  const diff = computeCharDiff('watr', 'water');
  assert.equal(diff.some((d) => d.kind === 'ok' && d.text === 'w'), true);
  assert.equal(diff.some((d) => d.kind === 'bad' && d.text === 'r'), true);
});

test('embedded 18,484-word vocabulary file parses losslessly and builds standalone HTML with Unsplash key', async () => {
  const fs = await import('node:fs');
  const raw = fs.readFileSync('public/vocab-18k.tsv', 'utf8').trim();
  const store = parseTSVToStore(raw);

  assert.equal(store.words.length, 18484);
  assert.equal(store.byBand.A0.length, 404);
  assert.equal(store.byBand.A1.length, 501);
  assert.equal(store.byBand.A2.length, 926);
  assert.equal(store.byBand.B1.length, 1230);
  assert.equal(store.byBand.B2.length, 3228);
  assert.equal(store.byBand.C1.length, 3519);
  assert.equal(store.byBand.C2.length, 8676);

  assert.equal(store.words[0].band, 'A0');
  assert.equal(store.words[0].en, 'the');
  assert.equal(store.words[0].ar, 'ال');
  assert.equal(store.words[18483].band, 'C2');
  assert.equal(store.words[18483].en, 'enjoin');
  assert.equal(store.words[18483].ar, 'يحث');

  const c2Hits = searchVocab(store, 'enjoin', 'C2');
  assert.equal(c2Hits.length, 1);
  assert.equal(store.words[c2Hits[0]].en, 'enjoin');

  const mergedHtml = buildStandaloneHtml(raw);
  assert.ok(mergedHtml.includes('ofbUnj5e3vSjfGor04gqVKKkVBTUet-PqtFnRNqWPzI'));
  const roundTrip = extractVocabFromInput(mergedHtml);
  assert.equal(roundTrip.store.words.length, 18484);
  assert.equal(roundTrip.store.words[18483].en, 'enjoin');
});

test('universal visual query engine maps simple function words and generates fallback visual cards', async () => {
  const { buildVisualQuery, extractVisualKeywordsFromText, buildOfflineVisualCard } = await import(
    './mediaApi'
  );
  assert.notEqual(buildVisualQuery('the'), 'the');
  assert.notEqual(buildVisualQuery('in'), 'in');
  assert.notEqual(buildVisualQuery('yes'), 'yes');
  assert.equal(buildVisualQuery('mountain'), 'mountain');
  assert.equal(buildVisualQuery('to run'), 'run');

  const kw = extractVisualKeywordsFromText(
    'To instruct or urge someone to do something forcefully.',
    'enjoin'
  );
  assert.equal(kw, 'instruct urge');

  const card = buildOfflineVisualCard('enjoin', 'يحث', 'C2');
  assert.equal(card.found, true);
  assert.ok(card.imageUrl?.startsWith('data:image/svg+xml'));
});

test('extracted 21,708 sentences corpus parses cleanly and spoken pronunciation evaluator scores accurately', async () => {
  const fs = await import('node:fs');
  const { parseSentencesTSV, evaluateSpokenMatch, filterSentences } = await import(
    './sentenceLogic'
  );

  const raw = fs.readFileSync('public/sentences-21k.tsv', 'utf8');
  const sentences = parseSentencesTSV(raw);
  assert.equal(sentences.length, 21708);
  assert.equal(sentences[0].num, 1);
  assert.equal(sentences[0].en, "I'm");
  assert.equal(sentences[sentences.length - 1].num, 21710);
  assert.equal(sentences[sentences.length - 1].en, 'The end.');

  // Contraction equivalence: "I am not" matches "I'm not"
  const contractionHit = evaluateSpokenMatch("I'm not", 'I am not');
  assert.equal(contractionHit.score, 100);
  assert.equal(contractionHit.isMatch, true);

  // Partial sentence match highlights missed words
  const partial = evaluateSpokenMatch(
    'Can you take me to the airport, please?',
    'Can you take me to the station'
  );
  assert.ok(partial.score >= 60 && partial.score < 95);
  assert.equal(partial.tokens?.some((t) => t.word.includes('airport') && !t.matched), true);

  // Search by English text and by sentence number
  const airportHits = filterSentences(sentences, 'airport', {}, 'all', new Set(), new Set());
  assert.ok(airportHits.length >= 1);
  assert.ok(airportHits.some((s) => s.num === 9374));

  const numHits = filterSentences(sentences, '#4484', {}, 'all', new Set(), new Set());
  assert.equal(numHits.length, 1);
  assert.equal(numHits[0].en, 'The room is cleaned every morning.');

  // Verify 36 categories cover every sentence from #1 to #21710 with zero gaps
  const { SENTENCE_SECTIONS } = await import('./sentenceLogic');
  assert.equal(SENTENCE_SECTIONS.length, 36);
  let totalCovered = 0;
  for (const sec of SENTENCE_SECTIONS) {
    const inSec = filterSentences(sentences, '', {}, 'all', new Set(), new Set(), sec.id);
    assert.ok(inSec.length > 0, `Category ${sec.id} should not be empty`);
    totalCovered += inSec.length;
  }
  assert.equal(totalCovered, sentences.length);

  const travelSec = filterSentences(sentences, '', {}, 'all', new Set(), new Set(), 'travel');
  assert.equal(travelSec[0].num, 9373);
});



