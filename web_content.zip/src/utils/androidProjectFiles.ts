import { AndroidProjectFile } from '../types';

export const ANDROID_FILES: AndroidProjectFile[] = [
  {
    path: 'app/src/main/java/com/jarvis/assistant/ui/screens/MainScreen.kt',
    name: 'MainScreen.kt',
    language: 'kotlin',
    category: 'Compose UI',
    content: `package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.ui.components.ArcReactorMicButton
import com.jarvis.assistant.ui.components.WaveformVisualizer
import com.jarvis.assistant.ui.theme.*

@Composable
fun MainScreen(
    onNavigateToSettings: () -> Unit,
    onTestCallTrigger: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isListening by remember { mutableStateOf(false) }
    var assistantMessage by remember {
        mutableStateOf("At your service, Sir. Voice interface initialized.")
    }
    val systemStatus = "ONLINE // NOMINAL"

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisBackground)
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(8.dp).clip(CircleShape).background(JarvisGreen)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = systemStatus,
                    color = JarvisCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.2.sp
                )
            }

            IconButton(
                onClick = onNavigateToSettings,
                modifier = Modifier.size(40.dp).clip(CircleShape).background(JarvisSurface)
            ) {
                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = JarvisCyan)
            }
        }

        // Center HUD
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "JARVIS",
                fontSize = 38.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 4.sp,
                color = JarvisTextPrimary
            )
            Text(
                text = "PERSONAL ARTIFICIAL INTELLIGENCE",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp,
                color = JarvisTextDim,
                modifier = Modifier.padding(top = 4.dp, bottom = 32.dp)
            )

            ArcReactorMicButton(
                isListening = isListening,
                onClick = {
                    isListening = !isListening
                    assistantMessage = if (isListening) "Listening for your command, Sir..."
                    else "Command received and processed."
                },
                size = 180.dp
            )

            Spacer(modifier = Modifier.height(28.dp))

            WaveformVisualizer(
                isActive = isListening,
                modifier = Modifier.padding(horizontal = 16.dp),
                height = 36.dp
            )

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = JarvisSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = JarvisCyan, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(text = assistantMessage, color = JarvisTextSecondary, fontSize = 14.sp)
                }
            }
        }

        // Bottom Actions
        Column(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    assistantMessage = "Systems diagnostic complete. All 14 subsystems operating at optimal efficiency."
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color(0xFF0A0E17)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("TEST JARVIS", fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }

            OutlinedButton(
                onClick = onTestCallTrigger,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisCyan),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("TEST JARVIS CALL (INCOMING)", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/jarvis/assistant/ui/screens/SettingsScreen.kt',
    name: 'SettingsScreen.kt',
    language: 'kotlin',
    category: 'Compose UI',
    content: `package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.data.local.PreferencesManager
import com.jarvis.assistant.data.model.JarvisSettings
import com.jarvis.assistant.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    currentSettings: JarvisSettings,
    preferencesManager: PreferencesManager?,
    onNavigateBack: () -> Unit,
    onTestCallClick: () -> Unit,
    onTestMorningTriggerClick: () -> Unit = onTestCallClick,
    onTestNotificationAccessClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var briefingTime by remember { mutableStateOf(currentSettings.morningBriefingTime) }
    var isBriefingEnabled by remember { mutableStateOf(currentSettings.isDailyBriefingEnabled) }
    var voicePitch by remember { mutableFloatStateOf(currentSettings.voicePitch) }
    var voiceSpeed by remember { mutableFloatStateOf(currentSettings.voiceSpeed) }
    val voicePersonality by remember { mutableStateOf(currentSettings.voicePersonality) }
    var readOnArrival by remember { mutableStateOf(currentSettings.readNotificationsOnArrival) }
    var filterImportant by remember { mutableStateOf(currentSettings.filterImportantOnly) }

    Column(
        modifier = modifier.fillMaxSize().background(JarvisBackground)
    ) {
        TopAppBar(
            title = { Text("SETTINGS", fontSize = 18.sp, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp, color = JarvisTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = JarvisCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = JarvisBackground)
        )

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1 & 2. Morning Briefing & Enable Toggle
            SettingsCard(title = "MORNING BRIEFING", icon = Icons.Default.Alarm) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Enable Daily Briefing", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = JarvisTextPrimary)
                        Text("Wake to schedule, weather, and overnight highlights", fontSize = 12.sp, color = JarvisTextDim)
                    }
                    Switch(
                        checked = isBriefingEnabled,
                        onCheckedChange = { checked ->
                            isBriefingEnabled = checked
                            coroutineScope.launch { preferencesManager?.setDailyBriefingEnabled(checked) }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Briefing Time", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = JarvisTextPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("06:30", "07:00", "07:30", "08:00").forEach { time ->
                            val isSelected = briefingTime == time
                            Box(
                                modifier = Modifier
                                    .border(1.dp, if (isSelected) JarvisCyan else Color(0xFF263238), RoundedCornerShape(6.dp))
                                    .background(if (isSelected) Color(0xFF003840) else Color.Transparent, RoundedCornerShape(6.dp))
                                    .clickable {
                                        briefingTime = time
                                        coroutineScope.launch { preferencesManager?.updateMorningBriefingTime(time) }
                                    }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(text = time, color = if (isSelected) JarvisCyan else JarvisTextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isBriefingEnabled) "Scheduled via AlarmManager for $briefingTime (restores on reboot)" else "Daily briefing trigger is disabled.",
                    fontSize = 11.sp,
                    color = if (isBriefingEnabled) JarvisCyan else JarvisTextDim,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onTestMorningTriggerClick,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("TEST MORNING TRIGGER", fontWeight = FontWeight.Bold)
                }
            }

            // 3. Voice/Speech Settings
            SettingsCard(title = "VOICE & SPEECH", icon = Icons.Default.RecordVoiceOver) {
                Text("Personality: $voicePersonality", fontSize = 14.sp, color = JarvisCyan)
                Spacer(modifier = Modifier.height(12.dp))
                Text("Pitch (\${String.format(\"%.1f\", voicePitch)}x)", fontSize = 13.sp, color = JarvisTextSecondary)
                Slider(value = voicePitch, onValueChange = { voicePitch = it }, valueRange = 0.5f..1.5f)
                Text("Speed (\${String.format(\"%.1f\", voiceSpeed)}x)", fontSize = 13.sp, color = JarvisTextSecondary)
                Slider(value = voiceSpeed, onValueChange = { voiceSpeed = it }, valueRange = 0.5f..1.5f)
            }

            // 4. Notification Briefing Settings
            SettingsCard(title = "NOTIFICATION BRIEFING", icon = Icons.Default.Notifications) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Read on Arrival", fontSize = 15.sp, color = JarvisTextPrimary)
                        Text("Vocalize urgent notifications in hands-free mode", fontSize = 12.sp, color = JarvisTextDim)
                    }
                    Switch(checked = readOnArrival, onCheckedChange = { readOnArrival = it })
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Filter VIP Only", fontSize = 15.sp, color = JarvisTextPrimary)
                        Text("Exclude spam and promotional alerts", fontSize = 12.sp, color = JarvisTextDim)
                    }
                    Switch(checked = filterImportant, onCheckedChange = { filterImportant = it })
                }
            }

            // 5. Test Notification Access
            SettingsCard(title = "DIAGNOSTICS", icon = Icons.Default.Security) {
                OutlinedButton(onClick = onTestNotificationAccessClick, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("TEST NOTIFICATION ACCESS")
                }
            }

            // 6. Test JARVIS Call
            SettingsCard(title = "CONVERSATIONAL TRIGGER", icon = Icons.Default.PhoneInTalk) {
                Button(
                    onClick = onTestCallClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color(0xFF0A0E17))
                ) {
                    Icon(Icons.Default.PhoneInTalk, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("TEST JARVIS CALL (FULL SCREEN)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = JarvisSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = JarvisCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = title, color = JarvisCyan, fontSize = 12.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.2.sp)
            }
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/jarvis/assistant/ui/screens/JarvisCallScreen.kt',
    name: 'JarvisCallScreen.kt',
    language: 'kotlin',
    category: 'Compose UI',
    content: `package com.jarvis.assistant.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.jarvis.assistant.ui.components.ArcReactorMicButton
import com.jarvis.assistant.ui.components.WaveformVisualizer
import com.jarvis.assistant.ui.theme.*
import kotlinx.coroutines.delay
import java.util.Locale

enum class CallState {
    INCOMING,
    ACTIVE,
    ENDED
}

enum class VoiceLoopState {
    GREETING,
    LISTENING,
    PROCESSING,
    SPEAKING
}

/**
 * Native Android Jetpack Compose in-app voice call experience for JARVIS.
 * 
 * Features:
 * - Two-way hands-free voice loop using Android TextToSpeech & SpeechRecognizer
 * - Automatic loop resumption after JARVIS speaks
 * - Zero paid APIs or external keys (100% on-device architecture)
 * - Mute/Unmute, Speaker/Earpiece, and End Call controls
 * - Runtime RECORD_AUDIO permission handling and graceful fallbacks
 */
@Composable
fun JarvisCallScreen(
    onEndCall: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    var callState by remember { mutableStateOf(CallState.INCOMING) }
    var voiceLoopState by remember { mutableStateOf(VoiceLoopState.GREETING) }
    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(true) }
    var durationSeconds by remember { mutableIntStateOf(0) }

    var recognizedUserSpeech by remember { mutableStateOf("") }
    var jarvisSpokenResponse by remember {
        mutableStateOf("Voice connection initializing...")
    }
    var speechRecognizerAvailable by remember { mutableStateOf(true) }
    var permissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    var statusFeedbackMessage by remember { mutableStateOf<String?>(null) }

    var ttsInstance by remember { mutableStateOf<TextToSpeech?>(null) }
    var speechRecognizerInstance by remember { mutableStateOf<SpeechRecognizer?>(null) }
    var isTtsReady by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        permissionGranted = isGranted
        if (!isGranted) {
            statusFeedbackMessage = "Microphone permission required for hands-free speech recognition."
        }
    }

    fun speakAndResumeListening(text: String, isExit: Boolean = false) {
        jarvisSpokenResponse = text
        voiceLoopState = VoiceLoopState.SPEAKING

        if (isTtsReady && ttsInstance != null) {
            val params = Bundle()
            params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, if (isExit) "EXIT_UTTERANCE" else "JARVIS_LOOP")
            ttsInstance?.speak(text, TextToSpeech.QUEUE_FLUSH, params, if (isExit) "EXIT_UTTERANCE" else "JARVIS_LOOP")
        } else {
            mainHandler.postDelayed({
                if (callState == CallState.ACTIVE && !isMuted) {
                    voiceLoopState = VoiceLoopState.LISTENING
                }
            }, 3000)
        }
    }

    fun triggerListening() {
        if (callState != CallState.ACTIVE || isMuted) return

        if (!permissionGranted) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizerAvailable = false
            statusFeedbackMessage = "On-device SpeechRecognizer is not available on this Android device."
            return
        }

        mainHandler.post {
            try {
                speechRecognizerInstance?.cancel()
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                voiceLoopState = VoiceLoopState.LISTENING
                speechRecognizerInstance?.startListening(intent)
            } catch (e: Exception) {
                statusFeedbackMessage = "Failed to launch voice recognizer: \${e.localizedMessage}"
            }
        }
    }

    fun processUserSpeech(userSpeech: String) {
        val query = userSpeech.lowercase().trim()
        recognizedUserSpeech = userSpeech
        voiceLoopState = VoiceLoopState.PROCESSING

        val (replyText, isExit) = when {
            query.contains("bye") || query.contains("hang up") || query.contains("disconnect") || query.contains("end call") -> {
                Pair("Understood, Sir. Terminating secure voice session. Good day.", true)
            }
            query.contains("briefing") || query.contains("morning") || query.contains("agenda") || query.contains("schedule") -> {
                Pair("Morning briefing report: You have three schedule milestones starting with Core Systems Review at 9:00 AM. Weather is sunny at 72 degrees Fahrenheit. All VIP communication filters are active.", false)
            }
            query.contains("status") || query.contains("system") || query.contains("diagnostic") || query.contains("health") -> {
                Pair("All fourteen subsystems are operating with optimal precision. Latency is twelve milliseconds, internal memory footprint is nominal, and encrypted audio pipeline is established.", false)
            }
            query.contains("weather") || query.contains("forecast") || query.contains("temperature") -> {
                Pair("Atmospheric sensors record 72 degrees Fahrenheit with clear skies, humidity at 48 percent, and calm northwest winds. Ideal conditions.", false)
            }
            query.contains("notification") || query.contains("message") || query.contains("alert") -> {
                Pair("Notification triage active: zero unread VIP alerts pending. Seven non-critical alerts have been quietly categorized.", false)
            }
            query.contains("who are you") || query.contains("jarvis") || query.contains("what can you do") -> {
                Pair("I am JARVIS, your on-device personal artificial intelligence assistant. I manage your briefings, monitor critical communications, and assist your daily workflow entirely on device.", false)
            }
            query.contains("thank") || query.contains("good job") -> {
                Pair("Always at your service, Sir. Is there anything further I may coordinate for you?", false)
            }
            else -> {
                Pair("Directive received regarding '$userSpeech', Sir. Local parameters are calibrated. How shall we proceed?", false)
            }
        }

        speakAndResumeListening(replyText, isExit)
    }

    DisposableEffect(Unit) {
        val tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsInstance?.language = Locale.US
                isTtsReady = true

                ttsInstance?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        voiceLoopState = VoiceLoopState.SPEAKING
                    }

                    override fun onDone(utteranceId: String?) {
                        mainHandler.post {
                            if (utteranceId == "EXIT_UTTERANCE") {
                                onEndCall()
                            } else if (callState == CallState.ACTIVE && !isMuted) {
                                triggerListening()
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandler.post {
                            if (callState == CallState.ACTIVE && !isMuted) {
                                triggerListening()
                            }
                        }
                    }
                })
            }
        }
        ttsInstance = tts

        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    voiceLoopState = VoiceLoopState.LISTENING
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    voiceLoopState = VoiceLoopState.PROCESSING
                }

                override fun onError(error: Int) {
                    mainHandler.post {
                        if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                            if (callState == CallState.ACTIVE && !isMuted) {
                                triggerListening()
                            }
                        } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()
                    if (!text.isNullOrBlank()) {
                        processUserSpeech(text)
                    } else if (callState == CallState.ACTIVE && !isMuted) {
                        triggerListening()
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!partial.isNullOrBlank()) {
                        recognizedUserSpeech = partial
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            speechRecognizerInstance = recognizer
        } else {
            speechRecognizerAvailable = false
        }

        onDispose {
            tts.stop()
            tts.shutdown()
            speechRecognizerInstance?.destroy()
        }
    }

    DisposableEffect(callState) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (callState == CallState.ACTIVE) {
            audioManager?.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager?.isSpeakerphoneOn = isSpeakerOn
        }
        onDispose {
            audioManager?.mode = AudioManager.MODE_NORMAL
        }
    }

    LaunchedEffect(callState) {
        if (callState == CallState.ACTIVE) {
            while (true) {
                delay(1000)
                durationSeconds++
            }
        }
    }

    DisposableEffect(callState) {
        var vibrator: Vibrator? = null
        if (callState == CallState.INCOMING) {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            val pattern = longArrayOf(0, 400, 800, 400, 800)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        }
        onDispose {
            vibrator?.cancel()
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "ring_anim")
    val ringScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ring_scale"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF03060B), JarvisBackground, Color(0xFF03060B))
                )
            )
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 10.dp)
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF131B2E))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Shield, contentDescription = null, tint = JarvisCyan, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "IN-APP AI VOICE SESSION • NOT A CELLULAR CALL",
                    color = Color(0xFF94A3B8),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "JARVIS",
                color = JarvisTextPrimary,
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 5.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            if (callState == CallState.INCOMING) {
                Text(
                    text = "INCOMING VOICE CONNECTION",
                    color = JarvisCyan,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Hands-Free Assistant Trigger • Direct Audio",
                    color = JarvisTextDim,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            } else {
                Text(
                    text = "ACTIVE VOICE CONVERSATION",
                    color = JarvisCyan,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
                val timerString = String.format("%02d:%02d", durationSeconds / 60, durationSeconds % 60)
                val loopLabel = when {
                    isMuted -> "MIC MUTED"
                    voiceLoopState == VoiceLoopState.LISTENING -> "LISTENING TO YOU..."
                    voiceLoopState == VoiceLoopState.SPEAKING -> "JARVIS SPEAKING"
                    voiceLoopState == VoiceLoopState.PROCESSING -> "PROCESSING..."
                    else -> "INITIALIZING..."
                }
                Text(
                    text = "$timerString • $loopLabel",
                    color = if (isMuted) JarvisAccentRed else JarvisGreen,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(200.dp)) {
                if (callState == CallState.INCOMING) {
                    Box(
                        modifier = Modifier
                            .size(180.dp)
                            .scale(ringScale)
                            .clip(CircleShape)
                            .border(2.dp, JarvisCyan.copy(alpha = 0.4f), CircleShape)
                    )
                }

                ArcReactorMicButton(
                    isListening = callState == CallState.ACTIVE && !isMuted && voiceLoopState == VoiceLoopState.LISTENING,
                    onClick = {},
                    size = 160.dp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (callState == CallState.ACTIVE) {
                WaveformVisualizer(
                    isActive = !isMuted && (voiceLoopState == VoiceLoopState.SPEAKING || voiceLoopState == VoiceLoopState.LISTENING),
                    modifier = Modifier.padding(horizontal = 20.dp),
                    height = 32.dp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.95f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF131B2E))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(
                            text = "JARVIS SPEECH",
                            color = JarvisCyan,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = jarvisSpokenResponse,
                            color = JarvisTextPrimary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        if (recognizedUserSpeech.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "You said: \"$recognizedUserSpeech\"",
                                color = JarvisGreen,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                if (!speechRecognizerAvailable || statusFeedbackMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth(0.95f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF261C14))
                            .border(1.dp, Color(0xFFF59E0B).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = statusFeedbackMessage ?: "Speech recognition unavailable. Using TTS fallback mode.",
                            color = Color(0xFFFDE68A),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            } else {
                Text(
                    text = "Scheduled morning briefing ready for hands-free delivery.",
                    color = JarvisTextDim,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        if (callState == CallState.INCOMING) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FloatingActionButton(
                        onClick = onEndCall,
                        containerColor = JarvisAccentRed,
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier.size(68.dp),
                        elevation = FloatingActionButtonDefaults.elevation(8.dp)
                    ) {
                        Icon(Icons.Default.CallEnd, contentDescription = "Decline", modifier = Modifier.size(28.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("DECLINE", color = JarvisAccentRed, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FloatingActionButton(
                        onClick = {
                            callState = CallState.ACTIVE
                            speakAndResumeListening("Voice link established. Good day, Sir. JARVIS on-device voice assistant is online and subsystems are nominal. What can I do for you?")
                        },
                        containerColor = JarvisGreen,
                        contentColor = Color(0xFF0A0E17),
                        shape = CircleShape,
                        modifier = Modifier.size(68.dp),
                        elevation = FloatingActionButtonDefaults.elevation(8.dp)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = "Answer", modifier = Modifier.size(28.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("ANSWER", color = JarvisGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FloatingActionButton(
                        onClick = {
                            isMuted = !isMuted
                            if (isMuted) {
                                speechRecognizerInstance?.cancel()
                            } else {
                                triggerListening()
                            }
                        },
                        containerColor = Color(0xFF1E293B),
                        contentColor = if (isMuted) JarvisAccentRed else JarvisTextPrimary,
                        shape = CircleShape,
                        modifier = Modifier.size(54.dp)
                    ) {
                        Icon(if (isMuted) Icons.Default.MicOff else Icons.Default.Mic, contentDescription = "Mute")
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(if (isMuted) "MUTED" else "MUTE", color = JarvisTextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FloatingActionButton(
                        onClick = {
                            ttsInstance?.stop()
                            speechRecognizerInstance?.cancel()
                            onEndCall()
                        },
                        containerColor = JarvisAccentRed,
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier.size(68.dp),
                        elevation = FloatingActionButtonDefaults.elevation(8.dp)
                    ) {
                        Icon(Icons.Default.CallEnd, contentDescription = "End Call", modifier = Modifier.size(28.dp))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("END CALL", color = JarvisAccentRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FloatingActionButton(
                        onClick = {
                            isSpeakerOn = !isSpeakerOn
                            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                            audioManager?.isSpeakerphoneOn = isSpeakerOn
                        },
                        containerColor = Color(0xFF1E293B),
                        contentColor = if (isSpeakerOn) JarvisCyan else JarvisTextDim,
                        shape = CircleShape,
                        modifier = Modifier.size(54.dp)
                    ) {
                        Icon(if (isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff, contentDescription = "Speaker")
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(if (isSpeakerOn) "SPEAKER" else "EARPIECE", color = JarvisTextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/jarvis/assistant/data/local/PreferencesManager.kt',
    name: 'PreferencesManager.kt',
    language: 'kotlin',
    category: 'Architecture & Storage',
    content: `package com.jarvis.assistant.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.jarvis.assistant.data.model.JarvisSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "jarvis_settings")

class PreferencesManager(private val context: Context) {
    companion object {
        val KEY_MORNING_BRIEFING_TIME = stringPreferencesKey("morning_briefing_time")
        val KEY_DAILY_BRIEFING_ENABLED = booleanPreferencesKey("daily_briefing_enabled")
        val KEY_VOICE_PITCH = floatPreferencesKey("voice_pitch")
        val KEY_VOICE_SPEED = floatPreferencesKey("voice_speed")
        val KEY_VOICE_PERSONALITY = stringPreferencesKey("voice_personality")
        val KEY_READ_NOTIFICATIONS = booleanPreferencesKey("read_notifications")
        val KEY_FILTER_IMPORTANT = booleanPreferencesKey("filter_important")
    }

    val settingsFlow: Flow<JarvisSettings> = context.dataStore.data.map { prefs ->
        JarvisSettings(
            morningBriefingTime = prefs[KEY_MORNING_BRIEFING_TIME] ?: "07:00",
            isDailyBriefingEnabled = prefs[KEY_DAILY_BRIEFING_ENABLED] ?: true,
            voicePitch = prefs[KEY_VOICE_PITCH] ?: 1.0f,
            voiceSpeed = prefs[KEY_VOICE_SPEED] ?: 1.0f,
            voicePersonality = prefs[KEY_VOICE_PERSONALITY] ?: "British Butler",
            readNotificationsOnArrival = prefs[KEY_READ_NOTIFICATIONS] ?: false,
            filterImportantOnly = prefs[KEY_FILTER_IMPORTANT] ?: true
        )
    }

    suspend fun updateMorningBriefingTime(time: String) {
        context.dataStore.edit { it[KEY_MORNING_BRIEFING_TIME] = time }
    }

    suspend fun setDailyBriefingEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_DAILY_BRIEFING_ENABLED] = enabled }
    }
}`
  },
  {
    path: 'app/src/main/java/com/jarvis/assistant/data/model/JarvisSettings.kt',
    name: 'JarvisSettings.kt',
    language: 'kotlin',
    category: 'Architecture & Storage',
    content: `package com.jarvis.assistant.data.model

data class JarvisSettings(
    val morningBriefingTime: String = "07:00",
    val isDailyBriefingEnabled: Boolean = true,
    val voicePitch: Float = 1.0f,
    val voiceSpeed: Float = 1.0f,
    val voiceLanguage: String = "en-US",
    val voicePersonality: String = "JARVIS", // "JARVIS", "VISION", "ULTRON", "Classic Android"
    val wakeWordEnabled: Boolean = true,
    val readNotificationsOnArrival: Boolean = false,
    val filterImportantOnly: Boolean = true,
    val allowedApps: Set<String> = setOf("com.google.android.gm", "com.whatsapp", "com.google.android.calendar"),
    val userName: String = "Sir"
)`
  },
  {
    path: 'app/src/main/java/com/jarvis/assistant/MainActivity.kt',
    name: 'MainActivity.kt',
    language: 'kotlin',
    category: 'Architecture & Storage',
    content: `package com.jarvis.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.jarvis.assistant.data.model.JarvisSettings
import com.jarvis.assistant.ui.screens.*
import com.jarvis.assistant.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as JarvisApplication
        val preferencesManager = app.preferencesManager

        setContent {
            JarvisTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = JarvisBackground) {
                    val navController = rememberNavController()
                    val currentSettings by preferencesManager.settingsFlow.collectAsState(initial = JarvisSettings())

                    LaunchedEffect(currentSettings.morningBriefingTime, currentSettings.isDailyBriefingEnabled) {
                        MorningBriefingScheduler.scheduleMorningBriefing(
                            this@MainActivity,
                            currentSettings.morningBriefingTime,
                            currentSettings.isDailyBriefingEnabled
                        )
                    }

                    LaunchedEffect(intent) {
                        if (intent?.getStringExtra("EXTRA_NAVIGATE_TO") == "call") {
                            navController.navigate("call") { launchSingleTop = true }
                        }
                    }

                    NavHost(navController = navController, startDestination = "main") {
                        composable("main") {
                            MainScreen(
                                onNavigateToSettings = { navController.navigate("settings") },
                                onTestCallTrigger = { navController.navigate("call") }
                            )
                        }
                        composable("settings") {
                            SettingsScreen(
                                currentSettings = currentSettings,
                                preferencesManager = preferencesManager,
                                onNavigateBack = { navController.popBackStack() },
                                onTestCallClick = { navController.navigate("call") },
                                onTestMorningTriggerClick = {
                                    MorningBriefingScheduler.triggerImmediateTest(this@MainActivity)
                                },
                                onTestNotificationAccessClick = {}
                            )
                        }
                        composable("call") {
                            JarvisCallScreen(onEndCall = { navController.popBackStack() })
                        }
                    }
                }
            }
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/jarvis/assistant/service/JarvisNotificationListenerService.kt',
    name: 'JarvisNotificationListenerService.kt',
    language: 'kotlin',
    category: 'Services & Receivers',
    content: `package com.jarvis.assistant.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class JarvisNotificationListenerService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        sbn?.let { notification ->
            val packageName = notification.packageName
            val extras = notification.notification.extras
            val title = extras.getString("android.title") ?: ""
            val text = extras.getCharSequence("android.text")?.toString() ?: ""
            Log.d("JarvisNotification", "Intercepted from $packageName: $title - $text")
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/jarvis/assistant/service/JarvisVoiceInteractionService.kt',
    name: 'JarvisVoiceInteractionService.kt',
    language: 'kotlin',
    category: 'Services & Receivers',
    content: `package com.jarvis.assistant.service

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

/**
 * Service managing on-device Speech-to-Text (SpeechRecognizer) and
 * Text-to-Speech (TTS) for hands-free two-way conversational voice flow.
 */
class JarvisVoiceInteractionService : Service(), TextToSpeech.OnInitListener {

    private val binder = LocalBinder()
    private var textToSpeech: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isTtsReady = false

    inner class LocalBinder : Binder() {
        fun getService(): JarvisVoiceInteractionService = this@JarvisVoiceInteractionService
    }

    override fun onCreate() {
        super.onCreate()
        textToSpeech = TextToSpeech(this, this)
        initializeSpeechRecognizer()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech?.setLanguage(Locale.US)
            isTtsReady = true

            textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == "JARVIS_LOOP_UTTERANCE") {
                        startListening()
                    }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    startListening()
                }
            })
        }
    }

    private fun initializeSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {
                        if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                            startListening()
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()
                        if (!text.isNullOrBlank()) {
                            // Process recognized speech and respond hands-free
                        } else {
                            startListening()
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }
        speechRecognizer?.startListening(intent)
    }

    fun applyVoiceProfile(profileName: String, basePitch: Float = 1.0f, baseSpeed: Float = 1.0f) {
        val availableVoices = textToSpeech?.voices ?: emptySet()
        when (profileName.uppercase()) {
            "JARVIS" -> {
                textToSpeech?.setPitch(basePitch * 0.84f)
                textToSpeech?.setSpeechRate(baseSpeed * 0.94f)
                val ukVoice = availableVoices.firstOrNull { 
                    it.locale.country.equals("GB", ignoreCase = true) || it.name.contains("en-gb", ignoreCase = true)
                } ?: availableVoices.firstOrNull { it.locale.language == "en" }
                if (ukVoice != null) textToSpeech?.voice = ukVoice
            }
            "VISION" -> {
                textToSpeech?.setPitch(basePitch * 0.98f)
                textToSpeech?.setSpeechRate(baseSpeed * 0.92f)
                val naturalVoice = availableVoices.firstOrNull { 
                    it.name.contains("natural", ignoreCase = true) || it.name.contains("neural", ignoreCase = true)
                } ?: availableVoices.firstOrNull { it.locale.language == "en" }
                if (naturalVoice != null) textToSpeech?.voice = naturalVoice
            }
            "ULTRON" -> {
                textToSpeech?.setPitch(basePitch * 0.72f)
                textToSpeech?.setSpeechRate(baseSpeed * 0.90f)
                val deepVoice = availableVoices.firstOrNull { 
                    it.name.contains("male", ignoreCase = true) || it.name.contains("deep", ignoreCase = true)
                } ?: availableVoices.firstOrNull { it.locale.language == "en" }
                if (deepVoice != null) textToSpeech?.voice = deepVoice
            }
            else -> {
                textToSpeech?.setPitch(basePitch)
                textToSpeech?.setSpeechRate(baseSpeed)
                textToSpeech?.voice = textToSpeech?.defaultVoice
            }
        }
    }

    fun speak(
        text: String,
        pitch: Float = 1.0f,
        speed: Float = 1.0f,
        profile: String = "JARVIS",
        continuousLoop: Boolean = true
    ) {
        if (isTtsReady) {
            speechRecognizer?.stopListening()
            applyVoiceProfile(profile, pitch, speed)
            val utteranceId = if (continuousLoop) "JARVIS_LOOP_UTTERANCE" else "JARVIS_SINGLE_UTTERANCE"
            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            }
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}`
  },
  {
    path: 'app/src/main/java/com/jarvis/assistant/service/JarvisNotificationListenerService.kt',
    name: 'JarvisNotificationListenerService.kt',
    language: 'kotlin',
    category: 'Services & Receivers',
    content: `package com.jarvis.assistant.service

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

data class StoredNotification(
    val id: String,
    val appName: String,
    val packageName: String,
    val title: String,
    val text: String,
    val timestamp: Long,
    val isOngoing: Boolean,
    val priority: Int
)

class JarvisNotificationListenerService : NotificationListenerService() {

    companion object {
        private const val TAG = "JarvisNotification"
        private const val MAX_STORED_NOTIFICATIONS = 30
        private val localNotificationCache = mutableListOf<StoredNotification>()

        fun isNotificationAccessGranted(context: Context): Boolean {
            val enabledListeners = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false

            val expectedComponentName = ComponentName(context, JarvisNotificationListenerService::class.java).flattenToString()
            return enabledListeners.contains(expectedComponentName)
        }

        fun createNotificationAccessSettingsIntent(): Intent {
            return Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }

        @Synchronized
        fun getCapturedNotifications(allowedPackages: Set<String>? = null, filterNoise: Boolean = true): List<StoredNotification> {
            return localNotificationCache.filter { item ->
                if (filterNoise && item.isOngoing) return@filter false
                if (filterNoise && item.priority < Notification.PRIORITY_DEFAULT) return@filter false
                if (allowedPackages != null && !allowedPackages.contains(item.packageName)) return@filter false
                true
            }.sortedByDescending { it.timestamp }
        }

        @Synchronized
        fun clearOldNotifications() {
            localNotificationCache.clear()
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        try {
            val notification = sbn.notification ?: return
            val packageName = sbn.packageName ?: return

            val isOngoing = (notification.flags and Notification.FLAG_ONGOING_EVENT) != 0

            val extras = notification.extras ?: return
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
            val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim() ?: ""

            if (title.isEmpty() && text.isEmpty()) return

            val pm = applicationContext.packageManager
            val appName = try {
                val appInfo = pm.getApplicationInfo(packageName, 0)
                pm.getApplicationLabel(appInfo).toString()
            } catch (e: Exception) {
                packageName
            }

            val stored = StoredNotification(
                id = "\${sbn.key}_\${System.currentTimeMillis()}",
                appName = appName,
                packageName = packageName,
                title = title,
                text = text,
                timestamp = sbn.postTime,
                isOngoing = isOngoing,
                priority = notification.priority
            )

            synchronized(localNotificationCache) {
                val isDuplicate = localNotificationCache.any {
                    it.packageName == packageName &&
                    it.title == title &&
                    it.text == text &&
                    (System.currentTimeMillis() - it.timestamp) < 120_000
                }

                if (!isDuplicate) {
                    localNotificationCache.add(0, stored)
                    if (localNotificationCache.size > MAX_STORED_NOTIFICATIONS) {
                        localNotificationCache.removeAt(localNotificationCache.lastIndex)
                    }
                    Log.d(TAG, "Locally captured notification for briefing: [\$appName] \$title")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error processing notification", e)
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/jarvis/assistant/receiver/MorningBriefingScheduler.kt',
    name: 'MorningBriefingScheduler.kt',
    language: 'kotlin',
    category: 'Services & Receivers',
    content: `package com.jarvis.assistant.receiver

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.jarvis.assistant.MainActivity
import java.util.Calendar

/**
 * Helper object managing exact AlarmManager scheduling for the daily JARVIS morning briefing.
 * Works even when the application is closed, restores across phone reboots,
 * and adheres to Android battery/Doze restrictions via setAlarmClock or setExactAndAllowWhileIdle.
 */
object MorningBriefingScheduler {

    const val ACTION_MORNING_BRIEFING = "com.jarvis.assistant.ACTION_MORNING_BRIEFING"
    const val ACTION_TEST_MORNING_TRIGGER = "com.jarvis.assistant.ACTION_TEST_MORNING_TRIGGER"
    const val REQUEST_CODE_BRIEFING = 7001

    fun scheduleMorningBriefing(context: Context, timeString: String, isEnabled: Boolean) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MorningBriefingReceiver::class.java).apply {
            action = ACTION_MORNING_BRIEFING
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_BRIEFING,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (!isEnabled) {
            alarmManager.cancel(pendingIntent)
            return
        }

        val (hour, minute) = parseTimeString(timeString)
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (before(now) || timeInMillis <= now.timeInMillis) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val triggerTimeMs = target.timeInMillis
        val showIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val showPendingIntent = PendingIntent.getActivity(
            context,
            REQUEST_CODE_BRIEFING,
            showIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerTimeMs, showPendingIntent)
                alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTimeMs, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTimeMs, pendingIntent)
            }
        } catch (se: SecurityException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTimeMs, pendingIntent)
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTimeMs, pendingIntent)
            }
        }
    }

    fun triggerImmediateTest(context: Context) {
        val intent = Intent(context, MorningBriefingReceiver::class.java).apply {
            action = ACTION_TEST_MORNING_TRIGGER
        }
        context.sendBroadcast(intent)
    }

    fun parseTimeString(timeString: String): Pair<Int, Int> {
        return try {
            val parts = timeString.split(":")
            Pair(parts[0].trim().toInt(), parts[1].trim().toInt())
        } catch (e: Exception) {
            Pair(7, 0)
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/jarvis/assistant/receiver/MorningBriefingReceiver.kt',
    name: 'MorningBriefingReceiver.kt',
    language: 'kotlin',
    category: 'Services & Receivers',
    content: `package com.jarvis.assistant.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

/**
 * BroadcastReceiver triggered by AlarmManager at the user's configured
 * morning briefing time (e.g. 07:00 AM) or upon device reboot.
 */
class MorningBriefingReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_MORNING_CALL = "jarvis_morning_call_channel"
        const val NOTIFICATION_ID_MORNING = 1001
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        val app = context.applicationContext as? JarvisApplication
        val preferencesManager = app?.preferencesManager

        when (action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                // Restore scheduled trigger after phone reboot
                CoroutineScope(Dispatchers.IO).launch {
                    val settings = preferencesManager?.settingsFlow?.firstOrNull()
                    val time = settings?.morningBriefingTime ?: "07:00"
                    val isEnabled = settings?.isDailyBriefingEnabled ?: true
                    MorningBriefingScheduler.scheduleMorningBriefing(context, time, isEnabled)
                }
            }

            MorningBriefingScheduler.ACTION_MORNING_BRIEFING,
            MorningBriefingScheduler.ACTION_TEST_MORNING_TRIGGER -> {
                val isTest = action == MorningBriefingScheduler.ACTION_TEST_MORNING_TRIGGER
                CoroutineScope(Dispatchers.IO).launch {
                    val settings = preferencesManager?.settingsFlow?.firstOrNull()
                    val isEnabled = settings?.isDailyBriefingEnabled ?: true
                    val time = settings?.morningBriefingTime ?: "07:00"

                    if (!isTest && !isEnabled) return@launch

                    if (!isTest && isEnabled) {
                        MorningBriefingScheduler.scheduleMorningBriefing(context, time, true)
                    }

                    launchMorningCallExperience(context)
                }
            }
        }
    }

    private fun launchMorningCallExperience(context: Context) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            val channel = NotificationChannel(
                CHANNEL_MORNING_CALL,
                "JARVIS Morning Call",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Incoming voice session trigger for scheduled JARVIS morning briefings"
                enableVibration(true)
                setSound(ringtoneUri, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            }
            notificationManager.createNotificationChannel(channel)
        }

        val fullScreenIntent = Intent(context, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("EXTRA_NAVIGATE_TO", "call")
            putExtra("EXTRA_IS_MORNING_BRIEFING", true)
        }

        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            2001,
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_MORNING_CALL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("JARVIS • IN-APP VOICE SESSION")
            .setContentText("Good morning, Sir. Scheduled morning briefing ready (Not a cellular call).")
            .setSubText("MORNING BRIEFING")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(NOTIFICATION_ID_MORNING, notification)
        try {
            context.startActivity(fullScreenIntent)
        } catch (e: Exception) {}
    }
}`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    language: 'xml',
    category: 'Build & Config',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.READ_CALENDAR" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.USE_FULL_SCREEN_INTENT" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />

    <application
        android:name=".JarvisApplication"
        android:allowBackup="true"
        android:label="@string/app_name"
        android:theme="@style/Theme.JARVIS">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:showOnLockScreen="true"
            android:turnScreenOn="true"
            android:theme="@style/Theme.JARVIS">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".service.JarvisNotificationListenerService"
            android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.service.notification.NotificationListenerService" />
            </intent-filter>
        </service>

        <receiver
            android:name=".receiver.MorningBriefingReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
                <action android:name="com.jarvis.assistant.ACTION_MORNING_BRIEFING" />
                <action android:name="com.jarvis.assistant.ACTION_TEST_MORNING_TRIGGER" />
            </intent-filter>
        </receiver>
    </application>
</manifest>`
  },
  {
    path: 'app/build.gradle.kts',
    name: 'app/build.gradle.kts',
    language: 'groovy',
    category: 'Build & Config',
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.jarvis.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jarvis.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.work.runtime.ktx)
}`
  },
  {
    path: 'settings.gradle.kts',
    name: 'settings.gradle.kts',
    language: 'groovy',
    category: 'Build & Config',
    content: `rootProject.name = "JARVIS"
include(":app")`
  }
];
