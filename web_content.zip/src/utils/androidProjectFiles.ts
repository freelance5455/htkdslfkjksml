import JSZip from 'jszip';

export interface AndroidFileDefinition {
  path: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidFileDefinition[] = [
  // root build.gradle.kts
  {
    path: 'build.gradle.kts',
    content: `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
}
`,
  },
  // settings.gradle.kts
  {
    path: 'settings.gradle.kts',
    content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "PocketToolkit"
include(":app")
`,
  },
  // gradle/libs.versions.toml
  {
    path: 'gradle/libs.versions.toml',
    content: `[versions]
agp = "8.3.2"
kotlin = "2.0.0"
coreKtx = "1.13.1"
lifecycleRuntimeKtx = "2.8.0"
activityCompose = "1.9.0"
composeBom = "2024.05.00"
material3 = "1.2.1"
navigationCompose = "2.7.7"
room = "2.6.1"
ksp = "2.0.0-1.0.21"
junit = "4.13.2"
extJunit = "1.1.5"
espressoCore = "3.5.1"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
androidx-lifecycle-runtime-ktx = { group = "androidx.lifecycle", name = "lifecycle-runtime-ktx", version.ref = "lifecycleRuntimeKtx" }
androidx-activity-compose = { group = "androidx.activity", name = "activity-compose", version.ref = "activityCompose" }
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
androidx-ui = { group = "androidx.compose.ui", name = "ui" }
androidx-ui-graphics = { group = "androidx.compose.ui", name = "ui-graphics" }
androidx-ui-tooling = { group = "androidx.compose.ui", name = "ui-tooling" }
androidx-ui-tooling-preview = { group = "androidx.compose.ui", name = "ui-tooling-preview" }
androidx-material3 = { group = "androidx.compose.material3", name = "material3", version.ref = "material3" }
androidx-material-icons-extended = { group = "androidx.compose.material", name = "material-icons-extended" }
androidx-navigation-compose = { group = "androidx.navigation", name = "navigation-compose", version.ref = "navigationCompose" }
androidx-room-runtime = { group = "androidx.room", name = "room-runtime", version.ref = "room" }
androidx-room-ktx = { group = "androidx.room", name = "room-ktx", version.ref = "room" }
androidx-room-compiler = { group = "androidx.room", name = "room-compiler", version.ref = "room" }
junit = { group = "junit", name = "junit", version.ref = "junit" }
androidx-junit = { group = "androidx.test.ext", name = "junit", version.ref = "extJunit" }
androidx-espresso-core = { group = "androidx.test.espresso", name = "espresso-core", version.ref = "espressoCore" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
ksp = { id = "com.google.devtools.ksp", version.ref = "ksp" }
`,
  },
  // app/build.gradle.kts
  {
    path: 'app/build.gradle.kts',
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.salmanmehdi.pockettoolkit"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.salmanmehdi.pockettoolkit"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.androidx.navigation.compose)

    // Room Database
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // Testing
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    debugImplementation(libs.androidx.ui.tooling)
}
`,
  },
  // app/src/main/AndroidManifest.xml
  {
    path: 'app/src/main/AndroidManifest.xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Standard Network Diagnostics & Connectivity Check -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />

    <!-- Optional Camera for QR Code Scanner & Torch Flashlight (Requested only at runtime) -->
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.flash" android:required="false" />

    <!-- Haptic feedback for tactile buttons -->
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:name=".PocketToolkitApp"
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.PocketToolkit">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.PocketToolkit">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`,
  },
  // app/src/main/res/values/strings.xml
  {
    path: 'app/src/main/res/values/strings.xml',
    content: `<resources>
    <string name="app_name">Pocket Toolkit</string>
    <string name="developer_name">Syed Salman Mehdi</string>
    <string name="developer_bio">Independent writer, IT specialist, and freelance IT consultant. Interested in technology, governance, human rights, regional affairs, and digital tools.</string>
    
    <!-- Navigation Tabs -->
    <string name="nav_home">Home</string>
    <string name="nav_calculator">Calculator</string>
    <string name="nav_phone_care">Phone Care</string>
    <string name="nav_tools">Tools</string>
    <string name="nav_about">About</string>

    <!-- Home Cards -->
    <string name="card_device_info">Device Status</string>
    <string name="card_battery">Battery</string>
    <string name="card_storage">Storage</string>
    <string name="card_memory">RAM &amp; Memory</string>
    <string name="card_network">Network</string>
    <string name="quick_shortcuts">Quick Utilities</string>
    
    <!-- Actions -->
    <string name="action_refresh">Refresh</string>
    <string name="action_copy">Copy</string>
    <string name="action_share">Share</string>
    <string name="action_clear">Clear</string>
    <string name="action_delete">Delete</string>
    <string name="action_calculate">Calculate</string>
</resources>
`,
  },
  // app/src/main/res/values-ur/strings.xml (Urdu translation)
  {
    path: 'app/src/main/res/values-ur/strings.xml',
    content: `<resources>
    <string name="app_name">پاکٹ ٹول کٹ</string>
    <string name="developer_name">سید سلمان مہدی</string>
    <string name="developer_bio">آزاد مصنف، آئی ٹی ماہر اور فری لانس مشیر۔ ٹیکنالوجی، حکمرانی، انسانی حقوق، علاقائی امور اور ڈیجیٹل ٹولز میں دلچسپی۔</string>
    
    <!-- Navigation Tabs -->
    <string name="nav_home">ہوم</string>
    <string name="nav_calculator">کیلکولیٹر</string>
    <string name="nav_phone_care">فون کیئر</string>
    <string name="nav_tools">ٹولز</string>
    <string name="nav_about">تعارف</string>

    <!-- Home Cards -->
    <string name="card_device_info">ڈیوائس کی حالت</string>
    <string name="card_battery">بیٹری</string>
    <string name="card_storage">اسٹوریج</string>
    <string name="card_memory">میموری اور ریم</string>
    <string name="card_network">نیٹ ورک</string>
    <string name="quick_shortcuts">فوری ٹولز</string>
</resources>
`,
  },
  // app/src/main/res/values/colors.xml
  {
    path: 'app/src/main/res/values/colors.xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primary_green">#006C4C</color>
    <color name="primary_dark_green">#004D36</color>
    <color name="accent_green">#89F8C7</color>
    <color name="surface_light">#FBFDF9</color>
    <color name="surface_dark">#0F1512</color>
    <color name="container_light">#EDF2EC</color>
    <color name="container_dark">#1B221E</color>
</resources>
`,
  },
  // app/src/main/res/values/themes.xml
  {
    path: 'app/src/main/res/values/themes.xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.PocketToolkit" parent="android:Theme.Material.Light.NoActionBar">
        <item name="android:statusBarColor">@color/primary_dark_green</item>
        <item name="android:navigationBarColor">@color/surface_light</item>
    </style>
</resources>
`,
  },
  // Kotlin: PocketToolkitApp.kt
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/PocketToolkitApp.kt',
    content: `package com.salmanmehdi.pockettoolkit

import android.app.Application
import androidx.room.Room
import com.salmanmehdi.pockettoolkit.data.local.AppDatabase

class PocketToolkitApp : Application() {
    lateinit var database: AppDatabase
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "pocket_toolkit.db"
        ).fallbackToDestructiveMigration().build()
    }

    companion object {
        lateinit var instance: PocketToolkitApp
            private set
    }
}
`,
  },
  // Kotlin: MainActivity.kt
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/MainActivity.kt',
    content: `package com.salmanmehdi.pockettoolkit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.salmanmehdi.pockettoolkit.ui.navigation.PocketToolkitNavHost
import com.salmanmehdi.pockettoolkit.ui.theme.PocketToolkitTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PocketToolkitTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PocketToolkitNavHost()
                }
            }
        }
    }
}
`,
  },
  // Kotlin: Room Database
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/data/local/AppDatabase.kt',
    content: `package com.salmanmehdi.pockettoolkit.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.salmanmehdi.pockettoolkit.data.local.dao.CalculationDao
import com.salmanmehdi.pockettoolkit.data.local.dao.NoteDao
import com.salmanmehdi.pockettoolkit.data.local.dao.TodoDao
import com.salmanmehdi.pockettoolkit.data.local.entity.CalculationEntity
import com.salmanmehdi.pockettoolkit.data.local.entity.NoteEntity
import com.salmanmehdi.pockettoolkit.data.local.entity.TodoEntity

@Database(
    entities = [CalculationEntity::class, NoteEntity::class, TodoEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun calculationDao(): CalculationDao
    abstract fun noteDao(): NoteDao
    abstract fun todoDao(): TodoDao
}
`,
  },
  // Room Entities
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/data/local/entity/Entities.kt',
    content: `package com.salmanmehdi.pockettoolkit.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "calculation_history")
data class CalculationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val expression: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val isPinned: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "todos")
data class TodoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val isCompleted: Boolean = false,
    val priority: String = "medium",
    val createdAt: Long = System.currentTimeMillis()
)
`,
  },
  // Room DAOs
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/data/local/dao/Daos.kt',
    content: `package com.salmanmehdi.pockettoolkit.data.local.dao

import androidx.room.*
import com.salmanmehdi.pockettoolkit.data.local.entity.CalculationEntity
import com.salmanmehdi.pockettoolkit.data.local.entity.NoteEntity
import com.salmanmehdi.pockettoolkit.data.local.entity.TodoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CalculationDao {
    @Query("SELECT * FROM calculation_history ORDER BY timestamp DESC LIMIT 100")
    fun getAll(): Flow<List<CalculationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: CalculationEntity)

    @Query("DELETE FROM calculation_history")
    suspend fun clearAll()
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY isPinned DESC, updatedAt DESC")
    fun getAll(): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(note: NoteEntity)

    @Delete
    suspend fun delete(note: NoteEntity)
}

@Dao
interface TodoDao {
    @Query("SELECT * FROM todos ORDER BY isCompleted ASC, createdAt DESC")
    fun getAll(): Flow<List<TodoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(todo: TodoEntity)

    @Update
    suspend fun update(todo: TodoEntity)

    @Delete
    suspend fun delete(todo: TodoEntity)
}
`,
  },
  // Kotlin Domain: Math Evaluator
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/domain/calculator/MathEvaluator.kt',
    content: `package com.salmanmehdi.pockettoolkit.domain.calculator

import kotlin.math.*

/**
 * Safe Offline Mathematical Expression Evaluator
 * Developer: Syed Salman Mehdi - Pocket Toolkit
 */
object MathEvaluator {
    fun evaluate(expression: String, isRadians: Boolean = false): Double {
        val clean = expression.replace(" ", "").replace("×", "*").replace("÷", "/")
        if (clean.isEmpty()) return 0.0

        // Parse simple tokens using Shunting-Yard
        val tokens = tokenize(clean)
        return evaluateRpn(shuntingYard(tokens), isRadians)
    }

    private fun tokenize(input: String): List<String> {
        val tokens = mutableListOf<String>()
        var i = 0
        while (i < input.length) {
            val c = input[i]
            if (c.isDigit() || c == '.') {
                val sb = StringBuilder()
                while (i < input.length && (input[i].isDigit() || input[i] == '.')) {
                    sb.append(input[i])
                    i++
                }
                tokens.add(sb.toString())
                continue
            }
            if (c in listOf('+', '-', '*', '/', '%', '^', '(', ')')) {
                tokens.add(c.toString())
                i++
                continue
            }
            // Check scientific functions
            val sub = input.substring(i)
            val funcs = listOf("sin", "cos", "tan", "sqrt", "ln", "log")
            val matched = funcs.find { sub.startsWith(it) }
            if (matched != null) {
                tokens.add(matched)
                i += matched.length
                continue
            }
            i++
        }
        return tokens
    }

    private fun shuntingYard(tokens: List<String>): List<String> {
        val output = mutableListOf<String>()
        val ops = ArrayDeque<String>()
        val precedence = mapOf("+" to 1, "-" to 1, "*" to 2, "/" to 2, "%" to 2, "^" to 3)

        for (token in tokens) {
            if (token.toDoubleOrNull() != null) {
                output.add(token)
            } else if (token in listOf("sin", "cos", "tan", "sqrt", "ln", "log")) {
                ops.addLast(token)
            } else if (token == "(") {
                ops.addLast(token)
            } else if (token == ")") {
                while (ops.isNotEmpty() && ops.last() != "(") {
                    output.add(ops.removeLast())
                }
                if (ops.isNotEmpty() && ops.last() == "(") ops.removeLast()
                if (ops.isNotEmpty() && ops.last() in listOf("sin", "cos", "tan", "sqrt", "ln", "log")) {
                    output.add(ops.removeLast())
                }
            } else if (token in precedence.keys) {
                val p1 = precedence[token] ?: 0
                while (ops.isNotEmpty() && ops.last() != "(" && (precedence[ops.last()] ?: 0) >= p1) {
                    output.add(ops.removeLast())
                }
                ops.addLast(token)
            }
        }
        while (ops.isNotEmpty()) {
            output.add(ops.removeLast())
        }
        return output
    }

    private fun evaluateRpn(rpn: List<String>, isRadians: Boolean): Double {
        val stack = ArrayDeque<Double>()
        for (token in rpn) {
            val num = token.toDoubleOrNull()
            if (num != null) {
                stack.addLast(num)
            } else if (token in listOf("sin", "cos", "tan", "sqrt", "ln", "log")) {
                if (stack.isEmpty()) continue
                val a = stack.removeLast()
                val angle = if (isRadians) a else Math.toRadians(a)
                val res = when (token) {
                    "sin" -> sin(angle)
                    "cos" -> cos(angle)
                    "tan" -> tan(angle)
                    "sqrt" -> if (a >= 0) sqrt(a) else Double.NaN
                    "ln" -> if (a > 0) ln(a) else Double.NaN
                    "log" -> if (a > 0) log10(a) else Double.NaN
                    else -> a
                }
                stack.addLast(res)
            } else {
                if (stack.size < 2) continue
                val b = stack.removeLast()
                val a = stack.removeLast()
                val res = when (token) {
                    "+" -> a + b
                    "-" -> a - b
                    "*" -> a * b
                    "/" -> if (b != 0.0) a / b else throw ArithmeticException("Division by zero")
                    "%" -> a % b
                    "^" -> a.pow(b)
                    else -> 0.0
                }
                stack.addLast(res)
            }
        }
        return if (stack.isNotEmpty()) stack.last() else 0.0
    }
}
`,
  },
  // Unit Test: CalculatorUnitTest.kt
  {
    path: 'app/src/test/java/com/salmanmehdi/pockettoolkit/CalculatorUnitTest.kt',
    content: `package com.salmanmehdi.pockettoolkit

import com.salmanmehdi.pockettoolkit.domain.calculator.MathEvaluator
import org.junit.Assert.assertEquals
import org.junit.Test

class CalculatorUnitTest {
    @Test
    fun testBasicAddition() {
        assertEquals(46.0, MathEvaluator.evaluate("12 + 34"), 0.001)
    }

    @Test
    fun testOperatorPrecedence() {
        assertEquals(14.0, MathEvaluator.evaluate("2 + 3 * 4"), 0.001)
    }

    @Test
    fun testParentheses() {
        assertEquals(20.0, MathEvaluator.evaluate("(2 + 3) * 4"), 0.001)
    }

    @Test
    fun testSquareRoot() {
        assertEquals(12.0, MathEvaluator.evaluate("sqrt(144)"), 0.001)
    }

    @Test
    fun testExponents() {
        assertEquals(8.0, MathEvaluator.evaluate("2 ^ 3"), 0.001)
    }
}
`,
  },
  // Compose Navigation & Main Screen
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/ui/navigation/PocketToolkitNavHost.kt',
    content: `package com.salmanmehdi.pockettoolkit.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.compose.*
import com.salmanmehdi.pockettoolkit.R
import com.salmanmehdi.pockettoolkit.ui.screens.home.HomeScreen
import com.salmanmehdi.pockettoolkit.ui.screens.calculator.CalculatorScreen
import com.salmanmehdi.pockettoolkit.ui.screens.phonecare.PhoneCareScreen
import com.salmanmehdi.pockettoolkit.ui.screens.tools.ToolsScreen
import com.salmanmehdi.pockettoolkit.ui.screens.about.AboutScreen

enum class NavItem(val route: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val labelRes: Int) {
    HOME("home", Icons.Default.Home, R.string.nav_home),
    CALCULATOR("calculator", Icons.Default.Calculate, R.string.nav_calculator),
    PHONE_CARE("phone_care", Icons.Default.Security, R.string.nav_phone_care),
    TOOLS("tools", Icons.Default.Construction, R.string.nav_tools),
    ABOUT("about", Icons.Default.Person, R.string.nav_about)
}

@Composable
fun PocketToolkitNavHost() {
    val navController = rememberNavController()
    var selectedItem by remember { mutableStateOf(NavItem.HOME) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavItem.values().forEach { item ->
                    NavigationBarItem(
                        selected = selectedItem == item,
                        onClick = {
                            selectedItem = item
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = stringResource(item.labelRes)) },
                        label = { Text(stringResource(item.labelRes)) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = NavItem.HOME.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(NavItem.HOME.route) { HomeScreen() }
            composable(NavItem.CALCULATOR.route) { CalculatorScreen() }
            composable(NavItem.PHONE_CARE.route) { PhoneCareScreen() }
            composable(NavItem.TOOLS.route) { ToolsScreen() }
            composable(NavItem.ABOUT.route) { AboutScreen() }
        }
    }
}
`,
  },
  // Compose Theme
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/ui/theme/Theme.kt',
    content: `package com.salmanmehdi.pockettoolkit.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF006C4C)
val GreenOnPrimary = Color(0xFFFFFFFF)
val GreenPrimaryContainer = Color(0xFF89F8C7)
val GreenOnPrimaryContainer = Color(0xFF002114)
val DarkBackground = Color(0xFF0F1512)
val DarkSurface = Color(0xFF1B221E)
val LightBackground = Color(0xFFFBFDF9)
val LightSurface = Color(0xFFEDF2EC)

private val DarkColorScheme = darkColorScheme(
    primary = GreenPrimaryContainer,
    onPrimary = GreenOnPrimaryContainer,
    primaryContainer = GreenPrimary,
    onPrimaryContainer = Color.White,
    background = DarkBackground,
    surface = DarkSurface
)

private val LightColorScheme = lightColorScheme(
    primary = GreenPrimary,
    onPrimary = GreenOnPrimary,
    primaryContainer = GreenPrimaryContainer,
    onPrimaryContainer = GreenOnPrimaryContainer,
    background = LightBackground,
    surface = LightSurface
)

@Composable
fun PocketToolkitTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
`,
  },
  // Compose Screens - Home
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/ui/screens/home/HomeScreen.kt',
    content: `package com.salmanmehdi.pockettoolkit.ui.screens.home

import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Pocket Toolkit", style = MaterialTheme.typography.headlineMedium)
                Text("By Syed Salman Mehdi • Native Android Edition", style = MaterialTheme.typography.bodyMedium)
            }
        }

        // Device Specs Card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Device & System", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(8.dp))
                Text("Manufacturer: \${Build.MANUFACTURER.capitalize()}")
                Text("Model: \${Build.MODEL}")
                Text("Android Release: \${Build.VERSION.RELEASE} (API \${Build.VERSION.SDK_INT})")
                Text("Security Patch: \${Build.VERSION.SECURITY_PATCH}")
                Text("CPU Architecture: \${Build.SUPPORTED_ABIS.joinToString(", ")}")
            }
        }

        // Storage & Memory Guidance
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Storage, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Storage & Memory", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(8.dp))
                Text("• Sandboxed storage allocated securely via Android OS.")
                Text("• Real memory managed automatically by Linux OOM killer.")
                Text("• Zero background bloat or artificial process cleaners.")
            }
        }
    }
}
`,
  },
  // Compose Screens - Calculator
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/ui/screens/calculator/CalculatorScreen.kt',
    content: `package com.salmanmehdi.pockettoolkit.ui.screens.calculator

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.salmanmehdi.pockettoolkit.domain.calculator.MathEvaluator

@Composable
fun CalculatorScreen() {
    var display by remember { mutableStateOf("0") }
    var resultText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Display area
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.End
        ) {
            Text(display, style = MaterialTheme.typography.headlineLarge)
            if (resultText.isNotEmpty()) {
                Text(resultText, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            }
        }

        // Keypad buttons
        val buttons = listOf(
            listOf("C", "(", ")", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "-"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "sqrt", "=")
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            buttons.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { label ->
                        Button(
                            onClick = {
                                when (label) {
                                    "C" -> {
                                        display = "0"
                                        resultText = ""
                                    }
                                    "=" -> {
                                        try {
                                            val res = MathEvaluator.evaluate(display)
                                            resultText = "= \$res"
                                        } catch (e: Exception) {
                                            resultText = "Error"
                                        }
                                    }
                                    "sqrt" -> {
                                        display = if (display == "0") "sqrt(" else display + "sqrt("
                                    }
                                    else -> {
                                        display = if (display == "0") label else display + label
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(label, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }
    }
}
`,
  },
  // Compose Screens - PhoneCare
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/ui/screens/phonecare/PhoneCareScreen.kt',
    content: `package com.salmanmehdi.pockettoolkit.ui.screens.phonecare

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun PhoneCareScreen() {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Phone Care & Maintenance", style = MaterialTheme.typography.headlineSmall)
        Text("Genuine maintenance tools complying with Android privacy policies. No fake RAM killers or deceptive cleaners.")

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("System Storage Settings", style = MaterialTheme.typography.titleMedium)
                Text("Access Android's native file cleaner and storage manager directly.")
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    context.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
                }) {
                    Text("Open Android Storage Settings")
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Battery Health & Optimization", style = MaterialTheme.typography.titleMedium)
                Text("Review battery-consuming applications via genuine Android battery manager.")
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    context.startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY))
                }) {
                    Text("Open Battery Usage Summary")
                }
            }
        }
    }
}
`,
  },
  // Compose Screens - Tools
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/ui/screens/tools/ToolsScreen.kt',
    content: `package com.salmanmehdi.pockettoolkit.ui.screens.tools

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ToolsScreen() {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Everyday Utilities Directory", style = MaterialTheme.typography.headlineSmall)
        
        val utilities = listOf(
            "Unit Converter (Length, Mass, Speed, Temp, Digital Binary)",
            "Cryptographic Password Generator",
            "Secure Random Number Generator",
            "QR Code Generator & Camera Scanner",
            "Local Notes & Text Pad (Room SQLite)",
            "To-Do Task Checklist",
            "Shopping List with Price Tally",
            "Expense & Bill Splitter",
            "Word & Character Counter",
            "Stopwatch & Countdown Timer"
        )

        utilities.forEach { tool ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(16.dp)) {
                    Text(tool, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
`,
  },
  // Compose Screens - About
  {
    path: 'app/src/main/java/com/salmanmehdi/pockettoolkit/ui/screens/about/AboutScreen.kt',
    content: `package com.salmanmehdi.pockettoolkit.ui.screens.about

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun AboutScreen() {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("About Developer & App", style = MaterialTheme.typography.headlineSmall)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Developer: Syed Salman Mehdi", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Independent writer, IT specialist, and freelance IT consultant. " +
                    "Interested in technology, governance, human rights, regional affairs, and digital tools.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Text("Developer Links & Publications", style = MaterialTheme.typography.titleMedium)

        val links = listOf(
            "Connect on LinkedIn" to "https://www.linkedin.com/in/multithinker/",
            "Visit My Substack" to "https://salmanmehdi.substack.com/",
            "Visit My WordPress Blog" to "https://multithinker.wordpress.com/",
            "Visit My Blogspot" to "https://salmanmehdijournal.blogspot.com/",
            "Read My Articles (Muck Rack)" to "https://muckrack.com/syed-salman-mehdi/articles",
            "View My Book (Archive.org)" to "https://archive.org/details/ruthless-might-ssm"
        )

        links.forEach { (label, url) ->
            Button(
                onClick = { openUrl(url) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(label)
            }
        }
    }
}
`,
  },
  // README.md with detailed compilation & sideloading instructions
  {
    path: 'README.md',
    content: `# Pocket Toolkit - Native Android Application

**Developer:** Syed Salman Mehdi  
**Application ID:** \`com.salmanmehdi.pockettoolkit\`  
**Target:** Android 7.0+ (Min SDK 24, Target SDK 34)  
**Tech Stack:** Kotlin, Jetpack Compose, Material 3, Room SQLite, Coroutines  

---

## 1. Quick Start: How to Open & Preview in Android Studio

1. **Prerequisites:**
   - Download and install the free [Android Studio](https://developer.android.com/studio) (Koala or Ladybug edition recommended).
   - JDK 17 (bundled automatically inside Android Studio).

2. **Open Project:**
   - Unzip this source code folder.
   - Open Android Studio and choose **Open**, then select the unzipped directory containing \`settings.gradle.kts\`.
   - Wait for Gradle Sync to complete (takes 1-2 minutes on first run as dependencies download).

3. **Run on Android Emulator:**
   - Open the **Device Manager** in Android Studio.
   - Select any Pixel device (e.g., Pixel 7 / Pixel 8 with Android 13 or 14).
   - Press the green **Run (Play)** button in Android Studio toolbar (or Shift + F10).

---

## 2. How to Build a Debug APK (Free Tools)

You can build the APK via Android Studio or the command line terminal:

\`\`\`bash
# On Linux / macOS:
./gradlew assembleDebug

# On Windows:
gradlew.bat assembleDebug
\`\`\`

The generated APK will be at:
\`app/build/outputs/apk/debug/app-debug.apk\`

---

## 3. How to Install the APK on a Physical Android Phone

1. On your Android phone, enable **Developer options**:
   - Go to **Settings > About phone**.
   - Tap **Build number** 7 times until you see "You are now a developer".
   - In **Settings > System > Developer options**, enable **USB debugging**.
2. Connect your phone via USB cable to your computer.
3. In terminal, run:
   \`\`\`bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   \`\`\`
   *(Alternatively, copy \`app-debug.apk\` to your phone via Google Drive, WhatsApp, or USB transfer, and tap the APK to install. Android will prompt to "Allow installation from unknown sources" - tap Allow).*

---

## 4. How to Build a Signed Release APK for Sharing

To build a release APK you can share with family and friends:
1. In Android Studio, go to menu: **Build > Generate Signed Bundle / APK...**
2. Choose **APK** and click Next.
3. Select or create a new keystore (\`my-release-key.jks\`).
4. Choose destination folder and select **release**.
5. Click **Create**. The signed release APK will be in \`app/release/app-release.apk\`.

---

## 5. Offline Operation & Permission Details

- **100% Offline Utilities:** Calculator, scientific math, unit converters, notes, to-do items, shopping lists, expense splitter, random & password generators work completely offline.
- **Privacy First:** No tracking, no analytics, no external cloud storage, no account registration.
- **Camera Permission:** Only requested if using the QR Code Scanner or Flashlight torch.
- **System Boundaries:** Adheres strictly to Android security guidelines. Does not pretend to "kill RAM" or secretly delete user files.
`,
  },
];

export async function exportAndroidProjectZip(): Promise<Blob> {
  const zip = new JSZip();

  for (const file of ANDROID_PROJECT_FILES) {
    zip.file(`PocketToolkit-Android/${file.path}`, file.content);
  }

  return await zip.generateAsync({ type: 'blob' });
}
