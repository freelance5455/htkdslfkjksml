export interface StudyPlanDay {
  phase: string;
  focus: string;
  weeklyHours: number;
  milestones: string[];
}

export interface StudyPlan {
  skillId: string;
  dailyHours: number;
  totalWeeks: number;
  difficulty: string;
  phases: StudyPlanDay[];
  dailySchedule: { timeSlot: string; activity: string }[];
}

/**
 * Calculates estimated speech duration in seconds given text and words per minute (WPM).
 * For Bengali / multilingual text, standard speech rate is ~125-140 words per minute.
 */
export function calculateEstimatedDuration(text: string, wpm: number = 130): number {
  if (!text || text.trim() === '') return 0;
  const wordCount = text.trim().split(/\s+/).length;
  const minutes = wordCount / Math.max(wpm, 60);
  return Math.round(minutes * 60);
}

/**
 * Formats seconds into MM:SS
 */
export function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

/**
 * Identifies key technology tools and English keywords mentioned in the script text.
 */
export function extractKeyTerms(scriptText: string): string[] {
  if (!scriptText) return [];
  const knownTerms = [
    'AI Prompt Engineering',
    'Automation',
    'ChatGPT',
    'Zapier',
    'Make',
    'Data Analytics',
    'Excel',
    'SQL',
    'Tableau',
    'Power BI',
    'Video Editing',
    'Motion Graphics',
    'Premiere Pro',
    'After Effects',
    'CapCut',
    'Digital Marketing',
    'Google Analytics 4',
    'UI/UX Design',
    'Figma',
    'Adobe XD',
    '2027',
  ];

  const matched = knownTerms.filter((term) =>
    scriptText.toLowerCase().includes(term.toLowerCase())
  );
  return matched;
}

/**
 * Generates an optimized prompt for Lyria music generation based on scene energy & mood
 */
export function generatePromptForMusic(style: string, mood: string, duration: string = '30s'): string {
  const styleDescriptions: Record<string, string> = {
    tech: 'Modern electronic synthwave with ambient futuristic pads and subtle crisp beat',
    inspiring: 'Inspiring uplifting corporate documentary soundtrack with clean acoustic piano and atmospheric strings',
    dynamic: 'High-energy cyberpunk lo-fi beat suitable for fast-paced short-form video reels',
    chill: 'Warm chillhop instrumental with mellow keyboard and smooth melodic bassline',
  };

  const base = styleDescriptions[style] || 'Modern inspiring electronic background track';
  return `Generate a ${duration} instrumental ${base}. Mood: ${mood}. Clean mixing, suitable as unobtrusive video background music.`;
}

/**
 * Recommends best 2027 skill based on user interest and background profile.
 */
export function calculateSkillMatchScore(answers: {
  background?: string;
  interest?: string;
  mathComfort?: string;
  creativityPreference?: string;
}): { skillId: string; titleBn: string; titleEn: string; matchPercent: number; reasonBn: string }[] {
  const scores: Record<string, number> = {
    'ai-automation': 50,
    'data-analytics': 50,
    'video-editing': 50,
    'digital-marketing': 50,
    'ui-ux': 50,
  };

  if (answers.background === 'tech') {
    scores['ai-automation'] += 35;
    scores['data-analytics'] += 25;
  } else if (answers.background === 'creative') {
    scores['video-editing'] += 40;
    scores['ui-ux'] += 35;
  } else if (answers.background === 'business') {
    scores['digital-marketing'] += 35;
    scores['data-analytics'] += 30;
  } else if (answers.background === 'student') {
    scores['ai-automation'] += 20;
    scores['video-editing'] += 25;
    scores['ui-ux'] += 25;
  }

  if (answers.interest === 'automation') {
    scores['ai-automation'] += 30;
  } else if (answers.interest === 'data') {
    scores['data-analytics'] += 30;
  } else if (answers.interest === 'visual') {
    scores['video-editing'] += 30;
  } else if (answers.interest === 'growth') {
    scores['digital-marketing'] += 30;
  } else if (answers.interest === 'design') {
    scores['ui-ux'] += 30;
  }

  if (answers.mathComfort === 'high') {
    scores['data-analytics'] += 25;
  } else if (answers.mathComfort === 'low') {
    scores['video-editing'] += 20;
    scores['ui-ux'] += 15;
  }

  if (answers.creativityPreference === 'visual') {
    scores['video-editing'] += 25;
    scores['ui-ux'] += 25;
  } else if (answers.creativityPreference === 'logical') {
    scores['ai-automation'] += 20;
    scores['data-analytics'] += 20;
  }

  const results = [
    {
      skillId: 'ai-automation',
      titleBn: 'AI Prompt Engineering & Automation',
      titleEn: 'AI Prompt Engineering & Automation',
      matchPercent: Math.min(Math.round((scores['ai-automation'] / 140) * 100), 99),
      reasonBn: 'লজিক্যাল প্রবলেম সলভিং ও এআই টুল দিয়ে যেকোনো বিজনেসের কাজ সহজ করতে আপনার আগ্রহের সাথে সেরা মিল।',
    },
    {
      skillId: 'data-analytics',
      titleBn: 'Data Analytics & Business Intelligence',
      titleEn: 'Data Analytics & BI',
      matchPercent: Math.min(Math.round((scores['data-analytics'] / 140) * 100), 99),
      reasonBn: 'ডেটা বিশ্লেষণ করে গুরুত্বপূর্ণ ব্যবসায়িক সিদ্ধান্ত তৈরিতে সাহায্য করতে এটি অতুলনীয়।',
    },
    {
      skillId: 'video-editing',
      titleBn: 'Video Editing & Motion Graphics',
      titleEn: 'Video Editing & Motion Graphics',
      matchPercent: Math.min(Math.round((scores['video-editing'] / 140) * 100), 99),
      reasonBn: 'শর্ট-ফর্ম ভিডিও ও ভিজ্যুয়াল স্টোরিটেলিংয়ের বৈশ্বিক বাজারে সবচেয়ে দ্রুত আয়ের সুযোগ।',
    },
    {
      skillId: 'digital-marketing',
      titleBn: 'AI-Integrated Digital Marketing',
      titleEn: 'AI-Integrated Digital Marketing',
      matchPercent: Math.min(Math.round((scores['digital-marketing'] / 140) * 100), 99),
      reasonBn: 'ব্যবসায় গ্রোথ, সেলস এবং ডেটা-চালিত আধুনিক মার্কেটিং ক্যাম্পেইনের জন্য পারফেক্ট।',
    },
    {
      skillId: 'ui-ux',
      titleBn: 'UI/UX Design & Product Research',
      titleEn: 'UI/UX Design',
      matchPercent: Math.min(Math.round((scores['ui-ux'] / 140) * 100), 99),
      reasonBn: 'ডিজাইন সেন্স ও ইউজার সাইকোলজি কাজে লাগিয়ে আন্তর্জাতিক স্টার্টআপ ও রিমোট জবে অপার সম্ভাবনা।',
    },
  ];

  return results.sort((a, b) => b.matchPercent - a.matchPercent);
}

/**
 * Generates actionable 1-2 hours daily study routine
 */
export function generateStudyPlan(
  skillId: string,
  hoursPerDay: number = 2,
  currentLevel: 'beginner' | 'intermediate' | 'advanced' = 'beginner'
): StudyPlan {
  const clampedHours = Math.max(1, Math.min(hoursPerDay, 4));
  const weeklyHours = clampedHours * 6; // 6 days a week + 1 rest day

  const phaseMap: Record<string, StudyPlanDay[]> = {
    'ai-automation': [
      {
        phase: 'সপ্তাহ ১-২: ফান্ডামেন্টালস ও প্রম্পট প্যাটার্নস',
        focus: 'Few-shot prompting, System persona architecture, Chain-of-Thought',
        weeklyHours,
        milestones: ['ChatGPT ও Claude দিয়ে ৫টি জটিল প্রম্পট আর্কিটেকচার তৈরি', 'প্রম্পট চেইনিং টেস্ট করা'],
      },
      {
        phase: 'সপ্তাহ ৩-৫: Zapier & Make অটোমেশন',
        focus: 'Webhook integrations, CRM syncing, AI auto-response pipelines',
        weeklyHours,
        milestones: ['Google Sheets to Gmail অটোমেটেড ড্যাশবোর্ড', 'Slack / WhatsApp বট কানেক্ট করা'],
      },
      {
        phase: 'সপ্তাহ ৬-৮: এআই এজেন্সি পোর্টফোলিও বিল্ড',
        focus: 'End-to-end client business automation & demo delivery',
        weeklyHours,
        milestones: ['২টি পূর্ণাঙ্গ অটোমেশন কেস স্টাডি', 'আপওয়ার্ক / লিঙ্কডইন ক্লায়েন্ট ডেমো ভিডিও'],
      },
    ],
    'data-analytics': [
      {
        phase: 'সপ্তাহ ১-২: Advanced Excel & Data Cleaning',
        focus: 'VLOOKUP, XLOOKUP, Pivot Tables, Data Validation',
        weeklyHours,
        milestones: ['১ লাখ ডেটাসেটের সেলস রিপোর্ট সামারি তৈরি'],
      },
      {
        phase: 'সপ্তাহ ৩-৫: SQL & Relational Databases',
        focus: 'SELECT, JOINs, GROUP BY, Window functions',
        weeklyHours,
        milestones: ['ই-কমার্স ডেটাবেজ থেকে ৫০টি অ্যানালিটিকাল কুয়েরি সলভ করা'],
      },
      {
        phase: 'সপ্তাহ ৬-৮: Power BI / Tableau ড্যাশবোর্ড',
        focus: 'Interactive visualizations, KPIs, Storytelling with data',
        weeklyHours,
        milestones: ['লাইভ বিজনেস ড্যাশবোর্ড পোর্টফোলিও পাবলিশ করা'],
      },
    ],
  };

  const defaultPhases: StudyPlanDay[] = [
    {
      phase: 'সপ্তাহ ১-২: বেসিক ফাউন্ডেশন ও মূল সফটওয়্যার',
      focus: 'কোর টুল পরিচিতি ও ফান্ডামেন্টাল প্র্যাকটিস',
      weeklyHours,
      milestones: ['মূল কনসেপ্ট আয়ত্ত করা', 'প্রথম ৩টি ডেমো প্রজেক্ট সম্পন্ন'],
    },
    {
      phase: 'সপ্তাহ ৩-৫: ইন্টারমিডিয়েট হ্যান্ডস-অন প্রজেক্ট',
      focus: 'রিয়েল-ওয়ার্ল্ড প্রবলেম সলভিং ও ক্লায়েন্ট স্ট্যান্ডার্ড ওয়ার্ক',
      weeklyHours,
      milestones: ['২টি ফুল স্কেল পোর্টফোলিও কেস স্টাডি'],
    },
    {
      phase: 'সপ্তাহ ৬-৮: প্রফেশনাল পোর্টফোলিও ও মার্কেটপ্লেস প্রস্তুতি',
      focus: 'Behance / GitHub / LinkedIn শোকেস এবং কোল্ড আউটরিচ',
      weeklyHours,
      milestones: ['আন্তর্জাতিক মানের প্রোফাইল রেডি করা', 'প্রথম ক্লায়েন্ট পিচ পাঠানো'],
    },
  ];

  return {
    skillId,
    dailyHours: clampedHours,
    totalWeeks: 8,
    difficulty: currentLevel,
    phases: phaseMap[skillId] || defaultPhases,
    dailySchedule: [
      { timeSlot: 'প্রথম ২০ মিনিট', activity: 'নতুন কনসেপ্ট ভিডিও/ডকুমেন্টেশন পর্যবেক্ষণ' },
      { timeSlot: 'পরবর্তী ৬০-৭০ মিনিট', activity: 'সফটওয়্যারে সরাসরি প্রজেক্ট হাতে-কলমে প্র্যাকটিস' },
      { timeSlot: 'শেষ ২০ মিনিট', activity: 'নোট তৈরি, কি-বোর্ড শর্টকাট রিভিশন ও প্রগ্রেস ট্র্যাকিং' },
    ],
  };
}
