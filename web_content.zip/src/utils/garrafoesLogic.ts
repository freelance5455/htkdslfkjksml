import type {
  DailyRecord,
  WeeklyResult,
  Season,
  HistoricalRank,
  Trick,
} from '../types/index.ts';

/**
 * Timezone helper: São Paulo timezone format YYYY-MM-DD
 */
export function getSaoPauloDateString(date: Date = new Date()): string {
  // Use Intl with America/Sao_Paulo timezone
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
  return formatter.format(date);
}

/**
 * Returns Monday and Sunday of the current week in São Paulo time
 */
export function getSaoPauloWeekRange(date: Date = new Date()): {
  startDate: string;
  endDate: string;
  seasonId: string;
  seasonLabel: string;
} {
  // Convert current time to São Paulo date
  const spDateStr = getSaoPauloDateString(date);
  const [year, month, day] = spDateStr.split('-').map(Number);
  
  // Create a UTC date based on São Paulo YMD to do clean calendar math
  const d = new Date(Date.UTC(year, month - 1, day));
  const dayOfWeek = d.getUTCDay(); // 0 is Sunday, 1 is Monday ...
  
  // Calculate distance to previous Monday (in SP, week starts Monday 00:00)
  const diffToMonday = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
  const monday = new Date(d);
  monday.setUTCDate(d.getUTCDate() + diffToMonday);

  const sunday = new Date(monday);
  sunday.setUTCDate(monday.getUTCDate() + 6);

  const startStr = monday.toISOString().slice(0, 10);
  const endStr = sunday.toISOString().slice(0, 10);

  // Generate a clean seasonId e.g. "week-2026-10-19"
  const seasonId = `season-${startStr}`;
  const startDay = monday.getUTCDate().toString().padStart(2, '0');
  const startMonth = (monday.getUTCMonth() + 1).toString().padStart(2, '0');
  const endDay = sunday.getUTCDate().toString().padStart(2, '0');
  const endMonth = (sunday.getUTCMonth() + 1).toString().padStart(2, '0');

  const seasonLabel = `Semana ${startDay}/${startMonth} a ${endDay}/${endMonth}`;

  return {
    startDate: startStr,
    endDate: endStr,
    seasonId,
    seasonLabel,
  };
}

/**
 * Acceptance Criterion #2:
 * "Registrar tentativas de 4, 8 e 6 acertos no mesmo dia e categoria:
 * o recorde oficial do dia deve ser 8, não 18 nem 6."
 * Multiple attempts NEVER sum up; only the highest sequence is kept.
 */
export function calculateDailyBest(attempts: number[]): number {
  if (!attempts || attempts.length === 0) return 0;
  return Math.max(...attempts);
}

/**
 * Acceptance Criterion #3 & #6:
 * Regra exata da média:
 * Somar as melhores sequências dos dias registrados na semana e dividir
 * pela quantidade de dias de treino registrados nessa categoria.
 * Dias sem treino não entram na média; quando o jogador treinar,
 * pode registrar 0 se não conseguir uma sequência válida (entra na média como 0).
 */
export function calculateWeeklyStats(
  dailyRecords: Array<{ bestStreak: number; trained: boolean }>
): {
  daysTrained: number;
  sumStreaks: number;
  rawAverage: number;
  formattedAverage: string;
  maxStreak: number;
} {
  // Only days where player trained count
  const validRecords = dailyRecords.filter((r) => r.trained);

  if (validRecords.length === 0) {
    return {
      daysTrained: 0,
      sumStreaks: 0,
      rawAverage: 0,
      formattedAverage: '0,00',
      maxStreak: 0,
    };
  }

  const sumStreaks = validRecords.reduce((acc, r) => acc + r.bestStreak, 0);
  const daysTrained = validRecords.length;
  const rawAverage = sumStreaks / daysTrained;
  const maxStreak = Math.max(...validRecords.map((r) => r.bestStreak));

  // Formatted with 2 decimal places using comma (PT-BR)
  const formattedAverage = rawAverage.toFixed(2).replace('.', ',');

  return {
    daysTrained,
    sumStreaks,
    rawAverage,
    formattedAverage,
    maxStreak,
  };
}

export interface PlayerWeeklyInput {
  playerId: string;
  records: Array<{ bestStreak: number; trained: boolean }>;
}

/**
 * Rank weekly players by exact criteria:
 * 1. Maior média válida (conservando precisão completa, não arredondada)
 * 2. Desempate 1: maior sequência diária da semana
 * 3. Desempate 2: maior número de dias de treino registrados
 * 4. Campeões empatados se persistir
 */
export function calculateWeeklyRanking(
  seasonId: string,
  categoryId: string,
  players: PlayerWeeklyInput[]
): WeeklyResult[] {
  const calculated = players
    .map((p) => {
      const stats = calculateWeeklyStats(p.records);
      return {
        seasonId,
        categoryId,
        playerId: p.playerId,
        ...stats,
        rank: 0,
        isChampion: false,
        tieBreakReason: undefined as string | undefined,
      };
    })
    // Only players who trained at least 1 day are in active competitive ranking
    .filter((p) => p.daysTrained > 0);

  // Sort by raw average DESC, then maxStreak DESC, then daysTrained DESC
  calculated.sort((a, b) => {
    // 1. Raw average
    if (Math.abs(b.rawAverage - a.rawAverage) > 0.0000001) {
      return b.rawAverage - a.rawAverage;
    }
    // 2. Max streak
    if (b.maxStreak !== a.maxStreak) {
      return b.maxStreak - a.maxStreak;
    }
    // 3. Days trained
    if (b.daysTrained !== a.daysTrained) {
      return b.daysTrained - a.daysTrained;
    }
    return 0;
  });

  // Assign ranks & champions
  let currentRank = 1;
  for (let i = 0; i < calculated.length; i++) {
    const item = calculated[i];
    if (i === 0) {
      item.rank = 1;
      item.isChampion = true;
    } else {
      const prev = calculated[i - 1];
      const isExactTie =
        Math.abs(item.rawAverage - prev.rawAverage) < 0.0000001 &&
        item.maxStreak === prev.maxStreak &&
        item.daysTrained === prev.daysTrained;

      if (isExactTie) {
        item.rank = prev.rank;
        item.tieBreakReason = 'Empate técnico completo';
        if (prev.rank === 1) {
          item.isChampion = true;
        }
      } else {
        item.rank = i + 1;
        if (Math.abs(item.rawAverage - prev.rawAverage) < 0.0000001) {
          if (prev.maxStreak > item.maxStreak) {
            prev.tieBreakReason = `Desempate: melhor sequência (${prev.maxStreak} vs ${item.maxStreak})`;
          } else if (prev.daysTrained > item.daysTrained) {
            prev.tieBreakReason = `Desempate: dias registrados (${prev.daysTrained} vs ${item.daysTrained})`;
          }
        }
      }
    }
  }

  return calculated;
}

/**
 * Acceptance Criterion #9:
 * "O ranking histórico inclui apenas semanas encerradas e mantém categorias separadas,
 * com posição, média histórica e número de semanas consideradas."
 * Métrica: média das médias semanais oficiais de cada jogador,
 * considerando somente semanas encerradas nas quais registrou ao menos um dia de treino.
 */
export function calculateHistoricalRankings(
  closedSeasons: Season[],
  categoryId: string,
  playerIds: string[]
): HistoricalRank[] {
  const result: HistoricalRank[] = [];

  for (const playerId of playerIds) {
    const validWeeklyAverages: number[] = [];
    let allTimeBestStreak = 0;
    let championTitlesCount = 0;

    for (const season of closedSeasons) {
      if (season.status !== 'closed' || !season.snapshots) continue;
      const categoryResults = season.snapshots[categoryId];
      if (!categoryResults) continue;

      const playerResult = categoryResults.find((r) => r.playerId === playerId);
      if (playerResult && playerResult.daysTrained >= 1) {
        validWeeklyAverages.push(playerResult.rawAverage);
        if (playerResult.maxStreak > allTimeBestStreak) {
          allTimeBestStreak = playerResult.maxStreak;
        }
        if (playerResult.isChampion) {
          championTitlesCount++;
        }
      }
    }

    if (validWeeklyAverages.length > 0) {
      const sum = validWeeklyAverages.reduce((acc, v) => acc + v, 0);
      const rawHistoricalAverage = sum / validWeeklyAverages.length;
      result.push({
        playerId,
        categoryId,
        rawHistoricalAverage,
        formattedHistoricalAverage: rawHistoricalAverage.toFixed(2).replace('.', ','),
        validWeeksCount: validWeeklyAverages.length,
        allTimeBestStreak,
        rank: 0,
        championTitlesCount,
      });
    }
  }

  // Sort by historical average DESC, then valid weeks DESC, then allTimeBestStreak DESC
  result.sort((a, b) => {
    if (Math.abs(b.rawHistoricalAverage - a.rawHistoricalAverage) > 0.0000001) {
      return b.rawHistoricalAverage - a.rawHistoricalAverage;
    }
    if (b.validWeeksCount !== a.validWeeksCount) {
      return b.validWeeksCount - a.validWeeksCount;
    }
    return b.allTimeBestStreak - a.allTimeBestStreak;
  });

  result.forEach((item, index) => {
    item.rank = index + 1;
  });

  return result;
}

/**
 * Acceptance Criterion #8:
 * "Criar um rascunho de manobra e registrar 4 execuções: publicar continua bloqueado.
 * Na quinta execução, a opção de publicar é liberada."
 */
export function canPublishTrick(trick: Pick<Trick, 'authorId' | 'executionsByPlayer'>): {
  allowed: boolean;
  authorExecutions: number;
  remainingToUnlock: number;
} {
  const authorExecutions = trick.executionsByPlayer[trick.authorId] || 0;
  const allowed = authorExecutions >= 5;
  const remainingToUnlock = Math.max(0, 5 - authorExecutions);

  return {
    allowed,
    authorExecutions,
    remainingToUnlock,
  };
}
