import type { SentenceEntry, SpeechEvalResult, SpokenWordToken } from '../types';

export interface SentenceSection {
  id: string;
  label: string;
  startNum: number;
  endNum: number;
}

export const SENTENCE_SECTIONS: SentenceSection[] = [
  { id: 'basics', label: 'الضمائر والأفعال المساعدة', startNum: 1, endNum: 435 },
  { id: 'modals', label: 'الأفعال الناقصة (Can/Should)', startNum: 436, endNum: 841 },
  { id: 'q_what', label: 'أسئلة What و Which', startNum: 842, endNum: 1172 },
  { id: 'q_where', label: 'أسئلة المكان Where', startNum: 1173, endNum: 1500 },
  { id: 'q_who', label: 'أسئلة الأشخاص Who', startNum: 1501, endNum: 1632 },
  { id: 'q_when', label: 'أسئلة الوقت When', startNum: 1633, endNum: 1762 },
  { id: 'q_why', label: 'أسئلة السبب Why', startNum: 1763, endNum: 2282 },
  { id: 'q_how', label: 'أسئلة الكيفية How', startNum: 2283, endNum: 3001 },
  { id: 'perfect_future', label: 'الأزمنة التامة والمستقبل', startNum: 3002, endNum: 3560 },
  { id: 'there_it', label: 'تراكيب There is و It is', startNum: 3561, endNum: 4202 },
  { id: 'daily_idioms', label: 'تعبيرات ومصطلحات يومية', startNum: 4203, endNum: 4483 },
  { id: 'passive', label: 'المبني للمجهول (Passive)', startNum: 4484, endNum: 4802 },
  { id: 'opinions', label: 'التعبير عن الرأي والاتفاق', startNum: 4803, endNum: 5402 },
  { id: 'comparisons', label: 'المقارنة والاحتمالات', startNum: 5403, endNum: 6002 },
  { id: 'events_desc', label: 'وصف الأحداث والمواقف', startNum: 6003, endNum: 6716 },
  { id: 'daily_chat', label: 'محادثات يومية شائعة', startNum: 6717, endNum: 7802 },
  { id: 'apology', label: 'الاعتذار والتذكير واللطف', startNum: 7803, endNum: 8402 },
  { id: 'short_qa', label: 'أسئلة وردود قصيرة', startNum: 8403, endNum: 9002 },
  { id: 'shopping', label: 'التسوق والبيع والشراء', startNum: 9003, endNum: 9372 },
  { id: 'travel', label: 'السفر والمطار والمواصلات', startNum: 9373, endNum: 9602 },
  { id: 'plans', label: 'الخطط والأهداف الشخصية', startNum: 9603, endNum: 10202 },
  { id: 'feelings_cmd', label: 'المشاعر والأوامر القصيرة', startNum: 10203, endNum: 11402 },
  { id: 'phone_msg', label: 'الاتصال والرسائل والهاتف', startNum: 11403, endNum: 12002 },
  { id: 'traffic_way', label: 'الطريق والمرور والوصول', startNum: 12003, endNum: 12602 },
  { id: 'advice', label: 'النصائح والتشجيع', startNum: 12603, endNum: 13402 },
  { id: 'situations', label: 'مواقف حياتية وعملية', startNum: 13403, endNum: 13802 },
  { id: 'study_lib', label: 'الدراسة والمكتبة والتعلم', startNum: 13803, endNum: 14402 },
  { id: 'tech_work', label: 'التقنية والعمل والأنظمة', startNum: 14403, endNum: 15002 },
  { id: 'phrasal', label: 'الأفعال المركبة والمهنة', startNum: 15003, endNum: 15794 },
  { id: 'habits_causative', label: 'العادات والروتين والسببية', startNum: 15795, endNum: 17288 },
  { id: 'time_schedule', label: 'الوقت والأيام وجدول العمل', startNum: 17289, endNum: 17921 },
  { id: 'proverbs', label: 'الأمثال واللباقة الاجتماعية', startNum: 17922, endNum: 18602 },
  { id: 'perspectives', label: 'وجهات النظر والأولويات', startNum: 18603, endNum: 19188 },
  { id: 'motivation', label: 'التحفيز والإنجاز', startNum: 19189, endNum: 19802 },
  { id: 'warnings', label: 'التحذيرات وضبط النفس', startNum: 19803, endNum: 20402 },
  { id: 'advanced_phrases', label: 'تعبيرات اصطلاحية متقدمة', startNum: 20403, endNum: 21710 },
];

export const STARTER_SENTENCES_TSV = `1\tI'm
2\tI'm not
3\tAm I?
4\tAren't I?
5\tYou are
6\tYou're not
7\tAre you?
8\tAren't you?
9\tHe is
10\tHe isn't
11\tIs he?
12\tIsn't he?
13\tShe is
14\tShe isn't
15\tIs she?
16\tIsn't she?`;

export const STARTER_AR_TRANSLATIONS: Record<string, string> = {
  "I'm": 'أنا أكون',
  "I'm not": 'أنا لستُ',
  'Am I?': 'هل أنا؟',
  "Aren't I?": 'ألستُ أنا؟',
  'You are': 'أنت تكون / أنتم تكونون',
  "You aren't": 'أنت لستَ / أنتم لستم',
  "You're not": 'أنت لستَ',
  'Are you?': 'هل أنت؟',
  "Aren't you?": 'ألستَ أنت؟',
  'He is': 'هو يكون',
  "He isn't": 'هو ليس',
  'Is he?': 'هل هو؟',
  "Isn't he?": 'أليس هو؟',
  'She is': 'هي تكون',
  "She isn't": 'هي ليست',
  'Is she?': 'هل هي؟',
  "Isn't she?": 'أليست هي؟',
  'It is': 'إنه / إنها (لغير العاقل)',
  "It isn't": 'إنه ليس',
  'Is it?': 'هل هو؟ (لغير العاقل)',
  "Isn't it?": 'أليس كذلك؟',
  'We are': 'نحن نكون',
  "We aren't": 'نحن لسنا',
  'Are we?': 'هل نحن؟',
  "Aren't we?": 'ألسنا نحن؟',
  'They are': 'هم يكونون',
  "They aren't": 'هم ليسوا',
  'Are they?': 'هل هم؟',
  "Aren't they?": 'أليسوا هم؟',
  'I do': 'أنا أفعل',
  "I don't": 'أنا لا أفعل',
  'Do I?': 'هل أنا أفعل؟',
  "Don't I?": 'ألا أفعل أنا؟',
  'You do': 'أنت تفعل',
  "You don't": 'أنت لا تفعل',
  'Do you?': 'هل أنت تفعل؟',
  "Don't you?": 'ألا تفعل أنت؟',
  'We do': 'نحن نفعل',
  "We don't": 'نحن لا نفعل',
  'Do we?': 'هل نحن نفعل؟',
  "Don't we?": 'ألا نفعل نحن؟',
  'They do': 'هم يفعلون',
  "They don't": 'هم لا يفعلون',
  'Do they?': 'هل هم يفعلون؟',
  "Don't they?": 'ألا يفعلون هم؟',
  'He does': 'هو يفعل',
  "He doesn't": 'هو لا يفعل',
  'Does he?': 'هل هو يفعل؟',
  "Doesn't he?": 'ألا يفعل هو؟',
  'She does': 'هي تفعل',
  "She doesn't": 'هي لا تفعل',
  'Does she?': 'هل هي تفعل؟',
  "Doesn't she?": 'ألا تفعل هي؟',
  'It does': 'إنه يفعل',
  "It doesn't": 'إنه لا يفعل',
  'Does it?': 'هل يفعل؟',
  "Doesn't it?": 'ألا يفعل؟',
  'I did': 'أنا فعلتُ',
  "I didn't": 'أنا لم أفعل',
  'Did I?': 'هل فعلتُ أنا؟',
  "Didn't I?": 'ألم أفعل أنا؟',
  'You did': 'أنت فعلتَ',
  "You didn't": 'أنت لم تفعل',
  'Did you?': 'هل فعلتَ؟',
  "Didn't you?": 'ألم تفعل؟',
  'We did': 'نحن فعلنا',
};

export function parseSentencesTSV(raw: string): SentenceEntry[] {
  if (!raw || !raw.trim()) return [];
  const lines = raw.split(/\r?\n/);
  const result: SentenceEntry[] = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const tabIdx = line.indexOf('\t');
    if (tabIdx > 0) {
      const num = parseInt(line.slice(0, tabIdx), 10);
      const en = line.slice(tabIdx + 1).trim();
      if (en) {
        result.push({
          id: result.length,
          num: Number.isFinite(num) ? num : result.length + 1,
          en,
        });
      }
    } else {
      result.push({
        id: result.length,
        num: result.length + 1,
        en: line,
      });
    }
  }
  return result;
}

const CONTRACTION_MAP: Record<string, string> = {
  "i'm": 'i am',
  "you're": 'you are',
  "he's": 'he is',
  "she's": 'she is',
  "it's": 'it is',
  "we're": 'we are',
  "they're": 'they are',
  "isn't": 'is not',
  "aren't": 'are not',
  "wasn't": 'was not',
  "weren't": 'were not',
  "don't": 'do not',
  "doesn't": 'does not',
  "didn't": 'did not',
  "won't": 'will not',
  "wouldn't": 'would not',
  "can't": 'cannot',
  "couldn't": 'could not',
  "shouldn't": 'should not',
  "haven't": 'have not',
  "hasn't": 'has not',
  "hadn't": 'had not',
  "i've": 'i have',
  "you've": 'you have',
  "we've": 'we have',
  "they've": 'they have',
  "i'll": 'i will',
  "you'll": 'you will',
  "he'll": 'he will',
  "she'll": 'she will',
  "we'll": 'we will',
  "they'll": 'they will',
  "i'd": 'i would',
  "you'd": 'you would',
  "that's": 'that is',
  "there's": 'there is',
  "what's": 'what is',
  "where's": 'where is',
  "who's": 'who is',
  "let's": 'let us',
  "gonna": 'going to',
  "wanna": 'want to',
  "gotta": 'got to',
};

export function normalizeSpeechWords(text: string): string[] {
  const cleaned = (text || '')
    .toLowerCase()
    .replace(/[’‘`]/g, "'")
    .replace(/[^a-z0-9'\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!cleaned) return [];
  const rawWords = cleaned.split(' ');
  const expanded: string[] = [];
  for (const w of rawWords) {
    const mapped = CONTRACTION_MAP[w];
    if (mapped) {
      expanded.push(...mapped.split(' '));
    } else if (w) {
      expanded.push(w.replace(/'/g, ''));
    }
  }
  return expanded.filter(Boolean);
}

function editDistance(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[m][n];
}

function wordsSimilar(a: string, b: string): boolean {
  if (a === b) return true;
  if (a.length >= 4 && b.length >= 4 && editDistance(a, b) <= 1) return true;
  if (a.length >= 7 && b.length >= 7 && editDistance(a, b) <= 2) return true;
  return false;
}

/**
 * Evaluates how accurately the learner pronounced the target English sentence.
 * Strips explanatory suffixes like "= It is not going to" before scoring.
 */
export function evaluateSpokenMatch(targetSentence: string, spokenText: string): SpeechEvalResult {
  const primaryTarget = targetSentence.split('=')[0].trim() || targetSentence.trim();
  const displayWords = primaryTarget.split(/\s+/).filter(Boolean);
  const spokenNorm = normalizeSpeechWords(spokenText);

  if (!spokenNorm.length) {
    return {
      heardText: spokenText.trim(),
      score: 0,
      isMatch: false,
      tokens: displayWords.map((word) => ({ word, matched: false })),
      feedbackAr: 'لم يتم التقاط صوت واضح. حاول الاقتراب من الميكروفون ونطق الجملة بوضوح.',
      source: 'local',
    };
  }

  const usedSpoken = new Array<boolean>(spokenNorm.length).fill(false);
  const tokens: SpokenWordToken[] = [];
  let matchedUnits = 0;
  let totalUnits = 0;

  for (const rawDisplay of displayWords) {
    const unitNorms = normalizeSpeechWords(rawDisplay);
    if (!unitNorms.length) {
      tokens.push({ word: rawDisplay, matched: true });
      continue;
    }

    let tokenMatchedCount = 0;
    for (const u of unitNorms) {
      totalUnits += 1;
      const foundIdx = spokenNorm.findIndex((sw, idx) => !usedSpoken[idx] && wordsSimilar(u, sw));
      if (foundIdx !== -1) {
        usedSpoken[foundIdx] = true;
        matchedUnits += 1;
        tokenMatchedCount += 1;
      }
    }

    tokens.push({
      word: rawDisplay,
      matched: tokenMatchedCount === unitNorms.length,
    });
  }

  const rawScore = totalUnits > 0 ? Math.round((matchedUnits / totalUnits) * 100) : 0;
  const extraPenalty =
    spokenNorm.length > totalUnits + 3 ? Math.min(15, (spokenNorm.length - totalUnits - 3) * 4) : 0;
  const score = Math.max(0, Math.min(100, rawScore - extraPenalty));
  const isMatch = score >= 75;

  let feedbackAr = '';
  if (score >= 95) {
    feedbackAr = 'ممتاز! نطقك مطابق وواضح جداً.';
  } else if (score >= 80) {
    feedbackAr = 'رائع جداً! نطقك واضح وقريب جداً من الجملة الأصلية.';
  } else if (score >= 60) {
    feedbackAr = 'محاولة جيدة! ركّز على الكلمات المظلّلة بالأحمر وأعد النطق.';
  } else {
    feedbackAr = 'استمع للنطق البطيء أولاً ثم أعد المحاولة بهدوء.';
  }

  return {
    heardText: spokenText.trim(),
    score,
    isMatch,
    tokens,
    feedbackAr,
    source: 'local',
  };
}

export function filterSentences(
  sentences: SentenceEntry[],
  query: string,
  arMap: Record<string, string>,
  tab: 'all' | 'favorites' | 'practiced',
  favSet: Set<number>,
  practicedSet: Set<number>,
  sectionId: string = 'all'
): SentenceEntry[] {
  const q = query.trim().toLowerCase();
  let list =
    tab === 'favorites'
      ? sentences.filter((s) => favSet.has(s.num))
      : tab === 'practiced'
        ? sentences.filter((s) => practicedSet.has(s.num))
        : sentences;

  if (sectionId && sectionId !== 'all') {
    const sec = SENTENCE_SECTIONS.find((s) => s.id === sectionId);
    if (sec) {
      list = list.filter((s) => s.num >= sec.startNum && s.num <= sec.endNum);
    }
  }

  if (!q) return list;

  // Support searching by sentence number e.g. "#4484" or "4484"
  const numQuery = q.startsWith('#') ? q.slice(1) : q;
  if (/^\d+$/.test(numQuery)) {
    const exactNum = parseInt(numQuery, 10);
    return list.filter((s) => s.num === exactNum || String(s.num).startsWith(numQuery));
  }

  return list.filter((s) => {
    if (s.en.toLowerCase().includes(q)) return true;
    const ar = arMap[s.en];
    return Boolean(ar && ar.includes(q));
  });
}
