import test from 'node:test';
import assert from 'node:assert/strict';
import {
  checkAABBCollision,
  checkCircleCollision,
  clamp,
  lerp,
  distance,
  evaluateTicTacToeWin,
  getBestTicTacToeMove,
  getLineAndColumn,
  calculateWaveDifficulty,
} from './engine';

test('AABB Collision detects overlapping boxes', () => {
  const boxA = { x: 10, y: 10, w: 20, h: 20 };
  const boxB = { x: 25, y: 25, w: 20, h: 20 };
  const boxC = { x: 100, y: 100, w: 20, h: 20 };

  assert.equal(checkAABBCollision(boxA, boxB), true, 'Boxes A and B should collide');
  assert.equal(checkAABBCollision(boxA, boxC), false, 'Boxes A and C should not collide');
});

test('Circle Collision detects overlapping circles', () => {
  const c1 = { x: 0, y: 0, r: 10 };
  const c2 = { x: 15, y: 0, r: 10 };
  const c3 = { x: 50, y: 50, r: 5 };

  assert.equal(checkCircleCollision(c1, c2), true, 'Circles 1 and 2 should collide');
  assert.equal(checkCircleCollision(c1, c3), false, 'Circles 1 and 3 should not collide');
});

test('Math helpers clamp, lerp, and distance', () => {
  assert.equal(clamp(15, 0, 10), 10);
  assert.equal(clamp(-5, 0, 10), 0);
  assert.equal(clamp(5, 0, 10), 5);

  assert.equal(lerp(0, 100, 0.5), 50);
  assert.equal(lerp(10, 20, 0), 10);
  assert.equal(lerp(10, 20, 1), 20);

  assert.equal(distance({ x: 0, y: 0 }, { x: 3, y: 4 }), 5);
});

test('Tic-Tac-Toe Win Evaluation recognizes wins and draws', () => {
  const xWins = [
    'X', 'X', 'X',
    'O', 'O', null,
    null, null, null,
  ] as const;

  const resultX = evaluateTicTacToeWin([...xWins]);
  assert.equal(resultX.winner, 'X');
  assert.deepEqual(resultX.line, [0, 1, 2]);

  const drawBoard = [
    'X', 'O', 'X',
    'X', 'O', 'O',
    'O', 'X', 'X',
  ] as const;
  const resultDraw = evaluateTicTacToeWin([...drawBoard]);
  assert.equal(resultDraw.winner, 'draw');
});

test('Tic-Tac-Toe Minimax AI blocks winning moves', () => {
  // Human is X, about to win at index 2
  const board = [
    'X', 'X', null,
    'O', null, null,
    null, null, null,
  ] as const;

  const bestMoveForO = getBestTicTacToeMove([...board], 'O');
  assert.equal(bestMoveForO, 2, 'AI should block human X at index 2');
});

test('Line and column calculator works accurately', () => {
  const text = 'function hello() {\n  return 42;\n}';
  const pos = getLineAndColumn(text, text.indexOf('return'));
  assert.equal(pos.line, 2);
  assert.equal(pos.column, 3);
});

test('Wave difficulty scales progressively', () => {
  const wave1 = calculateWaveDifficulty(1);
  const wave5 = calculateWaveDifficulty(5);

  assert.equal(wave1.enemySpeed < wave5.enemySpeed, true);
  assert.equal(wave1.spawnIntervalMs > wave5.spawnIntervalMs, true);
});
