/**
 * CODEVERSE Pure Game Engine, Math & Collision Rules
 * Independent from DOM/UI for 100% deterministic unit testing and reuse.
 */

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface Circle {
  x: number;
  y: number;
  r: number;
}

export interface Vector2 {
  x: number;
  y: number;
}

/**
 * Axis-Aligned Bounding Box (AABB) Collision Check
 */
export function checkAABBCollision(a: Rect, b: Rect): boolean {
  return (
    a.x < b.x + b.w &&
    a.x + a.w > b.x &&
    a.y < b.y + b.h &&
    a.y + a.h > b.y
  );
}

/**
 * Circle-to-Circle Collision Check
 */
export function checkCircleCollision(a: Circle, b: Circle): boolean {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  const distanceSquared = dx * dx + dy * dy;
  const radiusSum = a.r + b.r;
  return distanceSquared <= radiusSum * radiusSum;
}

/**
 * Clamp value between min and max
 */
export function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

/**
 * Linear interpolation
 */
export function lerp(start: number, end: number, t: number): number {
  return start + (end - start) * clamp(t, 0, 1);
}

/**
 * Calculate Euclidean distance between two points
 */
export function distance(p1: Vector2, p2: Vector2): number {
  const dx = p1.x - p2.x;
  const dy = p1.y - p2.y;
  return Math.sqrt(dx * dx + dy * dy);
}

/**
 * Tic-Tac-Toe Win Evaluation
 * board: Array of 9 cells ('X' | 'O' | null)
 */
export type PlayerMark = 'X' | 'O' | null;

export function evaluateTicTacToeWin(board: PlayerMark[]): {
  winner: 'X' | 'O' | 'draw' | null;
  line: number[] | null;
} {
  const lines = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Cols
    [0, 4, 8], [2, 4, 6],             // Diagonals
  ];

  for (const [a, b, c] of lines) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a] as 'X' | 'O', line: [a, b, c] };
    }
  }

  if (board.every(cell => cell !== null)) {
    return { winner: 'draw', line: null };
  }

  return { winner: null, line: null };
}

/**
 * Tic-Tac-Toe Minimax AI Move Finder
 */
export function getBestTicTacToeMove(board: PlayerMark[], aiPlayer: 'X' | 'O'): number {
  const humanPlayer: 'X' | 'O' = aiPlayer === 'X' ? 'O' : 'X';

  function minimax(currentBoard: PlayerMark[], depth: number, isMaximizing: boolean): number {
    const outcome = evaluateTicTacToeWin(currentBoard);
    if (outcome.winner === aiPlayer) return 10 - depth;
    if (outcome.winner === humanPlayer) return depth - 10;
    if (outcome.winner === 'draw') return 0;

    if (isMaximizing) {
      let maxEval = -Infinity;
      for (let i = 0; i < 9; i++) {
        if (!currentBoard[i]) {
          currentBoard[i] = aiPlayer;
          const evaluation = minimax(currentBoard, depth + 1, false);
          currentBoard[i] = null;
          maxEval = Math.max(maxEval, evaluation);
        }
      }
      return maxEval;
    } else {
      let minEval = Infinity;
      for (let i = 0; i < 9; i++) {
        if (!currentBoard[i]) {
          currentBoard[i] = humanPlayer;
          const evaluation = minimax(currentBoard, depth + 1, true);
          currentBoard[i] = null;
          minEval = Math.min(minEval, evaluation);
        }
      }
      return minEval;
    }
  }

  let bestVal = -Infinity;
  let bestMove = -1;

  for (let i = 0; i < 9; i++) {
    if (!board[i]) {
      board[i] = aiPlayer;
      const moveVal = minimax(board, 0, false);
      board[i] = null;
      if (moveVal > bestVal) {
        bestMove = i;
        bestVal = moveVal;
      }
    }
  }

  return bestMove;
}

/**
 * Calculate line numbers and column from character index
 */
export function getLineAndColumn(content: string, index: number): { line: number; column: number } {
  const safeIndex = clamp(index, 0, content.length);
  const upTo = content.slice(0, safeIndex);
  const lines = upTo.split('\n');
  return {
    line: lines.length,
    column: lines[lines.length - 1].length + 1,
  };
}

/**
 * Score progression formula for arcade games
 */
export function calculateWaveDifficulty(wave: number): {
  enemySpeed: number;
  spawnIntervalMs: number;
  enemyHealth: number;
} {
  const w = Math.max(1, wave);
  return {
    enemySpeed: 1.5 + (w - 1) * 0.35,
    spawnIntervalMs: Math.max(400, 1500 - (w - 1) * 120),
    enemyHealth: 1 + Math.floor((w - 1) / 3),
  };
}
