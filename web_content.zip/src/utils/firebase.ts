// Firebase configuration for Shanju SaaS Platform
import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail,
  onAuthStateChanged,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  getFirestore,
  initializeFirestore,
  collection, 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  onSnapshot
} from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyCThSCwYJVrTsyu1y7so47yafljPHHDE-w",
  authDomain: "gen-lang-client-0855094775.firebaseapp.com",
  projectId: "gen-lang-client-0855094775",
  storageBucket: "gen-lang-client-0855094775.firebasestorage.app",
  messagingSenderId: "510510526409",
  appId: "1:510510526409:web:2808d5c309e4e0c1db4218"
};

// Initialize app singleton
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize Auth
export const auth = getAuth(app);
export const googleAuthProvider = new GoogleAuthProvider();
googleAuthProvider.setCustomParameters({ prompt: 'select_account' });

// Initialize Firestore with specific databaseId and resilient connection settings
const FIRESTORE_DATABASE_ID = "ai-studio-shanjusaasecomme-a2b0df37-3970-4d0b-a1d3-866216f60be4";
export const db = initializeFirestore(app, {
  experimentalAutoDetectLongPolling: true,
}, FIRESTORE_DATABASE_ID);

export {
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  onAuthStateChanged,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
  collection,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  query,
  where,
  orderBy,
  onSnapshot
};

export type { FirebaseUser };
