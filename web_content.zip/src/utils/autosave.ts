import {
  DetectedPdfFont,
  ExtractedTextBlock,
  OverlayElement,
  PdfDocumentTab,
} from '../types/pdf';

export const AUTOSAVE_STORAGE_KEY = 'lipipdf_autosave_v1';
export const AUTOSAVE_INTERVAL_MS = 30_000;

const IDB_NAME = 'lipipdf_storage_v1';
const IDB_STORE = 'pdf_bytes';

export interface AutosavedPageMeta {
  id: string;
  originalPageIndex: number | null;
  widthPt: number;
  heightPt: number;
  rotation: 0 | 90 | 180 | 270;
  extractedBlocks: ExtractedTextBlock[];
}

export interface AutosavedDocumentMeta {
  id: string;
  docName: string;
  activePageId: string;
  zoom: number;
  pages: AutosavedPageMeta[];
  overlays: OverlayElement[];
  detectedFonts: DetectedPdfFont[];
}

export interface AutosavePayload {
  version: 1;
  schemaVersion?: number;
  savedAt: number;
  activeDocId: string | null;
  documents: AutosavedDocumentMeta[];
}

function openBlobDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) {
        db.createObjectStore(IDB_STORE);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('Failed to open IndexedDB'));
  });
}

async function savePdfBytesToDb(docId: string, bytes: Uint8Array | null): Promise<void> {
  try {
    const db = await openBlobDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      const store = tx.objectStore(IDB_STORE);
      if (bytes) {
        store.put(bytes.slice().buffer, docId);
      } else {
        store.delete(docId);
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    // Non-fatal if IndexedDB is restricted
  }
}

export async function loadPdfBytesFromDb(docId: string): Promise<Uint8Array | null> {
  try {
    const db = await openBlobDb();
    const buf = await new Promise<ArrayBuffer | undefined>((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const req = tx.objectStore(IDB_STORE).get(docId);
      req.onsuccess = () => resolve(req.result as ArrayBuffer | undefined);
      req.onerror = () => reject(req.error);
    });
    db.close();
    return buf ? new Uint8Array(buf) : null;
  } catch {
    return null;
  }
}

async function pruneBlobDb(activeDocIds: string[]): Promise<void> {
  try {
    const db = await openBlobDb();
    const activeSet = new Set(activeDocIds);
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      const store = tx.objectStore(IDB_STORE);
      const keysReq = store.getAllKeys();
      keysReq.onsuccess = () => {
        for (const key of keysReq.result) {
          if (typeof key === 'string' && !activeSet.has(key)) {
            store.delete(key);
          }
        }
      };
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    // Ignore cleanup errors
  }
}

export async function saveAutosaveSnapshot(
  documents: PdfDocumentTab[],
  activeDocId: string | null
): Promise<number | null> {
  if (documents.length === 0) {
    try {
      localStorage.removeItem(AUTOSAVE_STORAGE_KEY);
    } catch {
      // ignore
    }
    await pruneBlobDb([]);
    return null;
  }

  const savedAt = Date.now();
  const payload: AutosavePayload = {
    version: 1,
    schemaVersion: 2,
    savedAt,
    activeDocId,
    documents: documents.map((doc) => ({
      id: doc.id,
      docName: doc.docName,
      activePageId: doc.activePageId,
      zoom: doc.zoom,
      detectedFonts: doc.detectedFonts,
      overlays: doc.overlays,
      pages: doc.pages.map((p) => ({
        id: p.id,
        originalPageIndex: p.originalPageIndex,
        widthPt: p.widthPt,
        heightPt: p.heightPt,
        rotation: p.rotation,
        extractedBlocks: p.extractedBlocks,
      })),
    })),
  };

  try {
    localStorage.setItem(AUTOSAVE_STORAGE_KEY, JSON.stringify(payload));
  } catch {
    // Fallback: if oversized due to large embedded images, store minimal metadata without throwing
    try {
      const compactPayload: AutosavePayload = {
        ...payload,
        documents: payload.documents.map((d) => ({
          ...d,
          pages: d.pages.map((p) => ({ ...p, extractedBlocks: [] })),
        })),
      };
      localStorage.setItem(AUTOSAVE_STORAGE_KEY, JSON.stringify(compactPayload));
    } catch {
      return null;
    }
  }

  await Promise.all(
    documents.map((doc) => savePdfBytesToDb(doc.id, doc.originalBytes))
  );
  await pruneBlobDb(documents.map((d) => d.id));
  return savedAt;
}

export function loadAutosavePayload(): AutosavePayload | null {
  try {
    const raw = localStorage.getItem(AUTOSAVE_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AutosavePayload;
    if (
      !parsed ||
      parsed.version !== 1 ||
      !Array.isArray(parsed.documents) ||
      parsed.documents.length === 0
    ) {
      return null;
    }
    return parsed;
  } catch {
    try {
      localStorage.removeItem(AUTOSAVE_STORAGE_KEY);
    } catch {
      // ignore
    }
    return null;
  }
}

export async function clearAutosaveStorage(): Promise<void> {
  try {
    localStorage.removeItem(AUTOSAVE_STORAGE_KEY);
  } catch {
    // ignore
  }
  await pruneBlobDb([]);
}
