/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  toBengaliNum,
  diffInDays,
  addDays,
  getDayOfWeek,
  isDateScheduled,
  getTaskStatusOnDate,
  getMissedDaysInPast100Days,
} from './dateUtils.ts';
import { ToDoTask } from '../types.ts';

test('toBengaliNum converts numbers correctly', () => {
  assert.equal(toBengaliNum(0), '০');
  assert.equal(toBengaliNum(15), '১৫');
  assert.equal(toBengaliNum(100), '১০০');
  assert.equal(toBengaliNum('2026-10-31'), '২০২৬-১০-৩১');
});

test('diffInDays and addDays calculate dates properly', () => {
  assert.equal(diffInDays('2026-10-28', '2026-11-03'), 6);
  assert.equal(addDays('2026-10-28', 6), '2026-11-03');
  assert.equal(addDays('2026-11-03', -6), '2026-10-28');
});

test('isDateScheduled: daily repeat', () => {
  const task: ToDoTask = {
    id: 't1',
    groupId: 'g1',
    name: 'দৈনিক কাজ',
    repeat: { type: 'daily' },
    createdAt: '2026-10-01',
    order: 0,
  };
  assert.equal(isDateScheduled(task, '2026-10-15'), true);
  assert.equal(isDateScheduled(task, '2026-11-01'), true);
});

test('isDateScheduled: weekly repeat', () => {
  // Sunday is 0, Monday is 1, ..., Saturday is 6
  // Let's test a task scheduled on Saturday (6) and Wednesday (3)
  const task: ToDoTask = {
    id: 't2',
    groupId: 'g1',
    name: 'শনি ও বুধ',
    repeat: { type: 'weekly', daysOfWeek: [6, 3] },
    createdAt: '2026-10-01',
    order: 0,
  };

  // 2026-10-31 is Saturday (6)
  assert.equal(getDayOfWeek('2026-10-31'), 6);
  assert.equal(isDateScheduled(task, '2026-10-31'), true);

  // 2026-10-28 is Wednesday (3)
  assert.equal(getDayOfWeek('2026-10-28'), 3);
  assert.equal(isDateScheduled(task, '2026-10-28'), true);

  // 2026-10-29 is Thursday (4) -> not scheduled
  assert.equal(isDateScheduled(task, '2026-10-29'), false);
});

test('isDateScheduled: interval repeat (every 3 days starting Nov 1)', () => {
  const task: ToDoTask = {
    id: 't3',
    groupId: 'g1',
    name: '৩ দিন পর পর',
    repeat: { type: 'interval', intervalDays: 3, startDate: '2026-11-01' },
    createdAt: '2026-10-25',
    order: 0,
  };

  assert.equal(isDateScheduled(task, '2026-11-01'), true); // Day 0
  assert.equal(isDateScheduled(task, '2026-11-02'), false);
  assert.equal(isDateScheduled(task, '2026-11-04'), true); // Day 3
  assert.equal(isDateScheduled(task, '2026-11-07'), true); // Day 6
  assert.equal(isDateScheduled(task, '2026-10-31'), false); // Before start date
});

test('isDateScheduled: postponed date inclusion', () => {
  const task: ToDoTask = {
    id: 't4',
    groupId: 'g1',
    name: 'পিছানো কাজ',
    repeat: { type: 'custom', dates: ['2026-10-20'] },
    createdAt: '2026-10-01',
    order: 0,
    postponedDates: {
      '2026-10-20': '2026-10-28',
    },
  };

  assert.equal(isDateScheduled(task, '2026-10-20'), true);
  assert.equal(isDateScheduled(task, '2026-10-28'), true); // Postponed target
  assert.equal(isDateScheduled(task, '2026-10-29'), false);
});

test('getTaskStatusOnDate follows section 5 rules strictly', () => {
  const today = '2026-10-31';
  const task: ToDoTask = {
    id: 't5',
    groupId: 'g1',
    name: 'নিয়ম পরীক্ষা',
    repeat: { type: 'daily' },
    createdAt: '2026-10-20',
    order: 0,
    reports: {
      '2026-10-25': 'done',
      '2026-10-26': 'wont_do',
      '2026-10-27': 'postponed',
    },
  };

  // Explicit status is final
  assert.equal(getTaskStatusOnDate(task, '2026-10-25', today), 'done');
  assert.equal(getTaskStatusOnDate(task, '2026-10-26', today), 'wont_do');
  assert.equal(getTaskStatusOnDate(task, '2026-10-27', today), 'postponed');

  // Today with no report is 'pending' ("বাকি")
  assert.equal(getTaskStatusOnDate(task, '2026-10-31', today), 'pending');

  // Past scheduled date on/after createdAt with no report is auto 'not_done' ("করিনি")
  assert.equal(getTaskStatusOnDate(task, '2026-10-24', today), 'not_done');
  // Past date before createdAt must NEVER auto become 'not_done'
  assert.equal(getTaskStatusOnDate(task, '2026-10-15', today), null);

  // Future date with no report is null
  assert.equal(getTaskStatusOnDate(task, '2026-11-05', today), null);
});

test('getMissedDaysInPast100Days starts calculation from task start/creation date', () => {
  const today = '2026-10-31';
  // A task created on Oct 28
  const task: ToDoTask = {
    id: 't6',
    groupId: 'g1',
    name: '১০০ দিন টেস্ট',
    repeat: { type: 'daily' },
    createdAt: '2026-10-28', // Started on Oct 28
    order: 0,
    reports: {
      '2026-10-29': 'done', // Done on Oct 29
    },
  };

  // Past days between Oct 28 and Oct 30 (yesterday):
  // Oct 30: no report -> not_done
  // Oct 29: done -> not missed
  // Oct 28: no report -> not_done
  // Days before Oct 28: before task start, so NOT counted!
  const missed = getMissedDaysInPast100Days(task, today);
  assert.deepEqual(missed, ['2026-10-30', '2026-10-28']);
  assert.equal(missed.length, 2);
});
