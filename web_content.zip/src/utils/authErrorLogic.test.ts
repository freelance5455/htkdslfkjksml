import test from 'node:test';
import assert from 'node:assert/strict';
import {
  extractFirebaseErrorCode,
  parseFirebaseAuthError,
  shouldUseRedirectFallback,
} from './authErrorLogic';

test('extractFirebaseErrorCode reads code property or falls back to message pattern', () => {
  assert.equal(
    extractFirebaseErrorCode({ code: 'auth/unauthorized-domain' }),
    'auth/unauthorized-domain'
  );
  assert.equal(
    extractFirebaseErrorCode(new Error('Firebase: Error (auth/popup-blocked).')),
    'auth/popup-blocked'
  );
  assert.equal(extractFirebaseErrorCode(null), '');
});

test('parseFirebaseAuthError flags unauthorized-domain with hostname and clear Arabic guidance', () => {
  const parsed = parseFirebaseAuthError(
    { code: 'auth/unauthorized-domain' },
    'ar',
    'tmn-123.run.app'
  );
  assert.equal(parsed.code, 'auth/unauthorized-domain');
  assert.equal(parsed.isUnauthorizedDomain, true);
  assert.equal(parsed.hostname, 'tmn-123.run.app');
  assert.ok(parsed.message.includes('tmn-123.run.app'));
  assert.ok(parsed.message.includes('Firebase'));
});

test('parseFirebaseAuthError silences user-cancelled popups and surfaces diagnostic code for unknown errors', () => {
  const closed = parseFirebaseAuthError({ code: 'auth/popup-closed-by-user' }, 'ar');
  assert.equal(closed.message, '');

  const unknown = parseFirebaseAuthError({ code: 'auth/custom-weird-code' }, 'ar');
  assert.ok(unknown.message.includes('auth/custom-weird-code'));
});

test('shouldUseRedirectFallback only triggers outside iframes for popup-blocked/unsupported errors', () => {
  assert.equal(shouldUseRedirectFallback('auth/popup-blocked', false), true);
  assert.equal(
    shouldUseRedirectFallback('auth/operation-not-supported-in-this-environment', false),
    true
  );
  assert.equal(shouldUseRedirectFallback('auth/popup-blocked', true), false);
  assert.equal(shouldUseRedirectFallback('auth/unauthorized-domain', false), false);
  assert.equal(shouldUseRedirectFallback('auth/popup-closed-by-user', false), false);
});

test('parseFirebaseAuthError marks operation-not-allowed with isProviderDisabled', () => {
  const parsed = parseFirebaseAuthError({ code: 'auth/operation-not-allowed' }, 'ar');
  assert.equal(parsed.isProviderDisabled, true);
  assert.equal(parsed.isUnauthorizedDomain, false);
  assert.ok(parsed.message.includes('Firebase'));
});
