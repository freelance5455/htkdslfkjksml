import { JarvisSettings } from '../types';

export type PermissionStatus = 'GRANTED' | 'REQUIRED' | 'DENIED';

export interface DevicePermissionItem {
  id: string;
  name: string;
  manifestPermission: string;
  status?: PermissionStatus;
  category: 'Core Audio' | 'Notifications' | 'Scheduling' | 'Battery & Power' | 'System';
  isMandatoryForCore: boolean;
  whyNeeded: string;
  settingsAction: string;
  settingsActionLabel: string;
  adbCommand: string;
  gracefulFallback: string;
  androidApiLevel: string;
}

export const DEVICE_PERMISSIONS_CATALOG: DevicePermissionItem[] = [
  {
    id: 'microphone',
    name: 'Microphone (Audio Record)',
    manifestPermission: 'android.permission.RECORD_AUDIO',
    category: 'Core Audio',
    isMandatoryForCore: false, // Non-crashing graceful degradation
    whyNeeded:
      'Required for continuous hands-free speech recognition and two-way voice dialogue during morning calls.',
    settingsAction: 'android.settings.APPLICATION_DETAILS_SETTINGS',
    settingsActionLabel: 'Open App Permissions > Microphone',
    adbCommand: 'adb shell pm grant com.jarvis.assistant android.permission.RECORD_AUDIO',
    gracefulFallback:
      'If denied: JARVIS speaks full briefing and questions without crashing; displays on-screen text replies.',
    androidApiLevel: 'Android 6.0+ (API 23)',
  },
  {
    id: 'notification_listener',
    name: 'Notification Listener Access',
    manifestPermission: 'android.permission.BIND_NOTIFICATION_LISTENER_SERVICE',
    category: 'Notifications',
    isMandatoryForCore: true,
    whyNeeded:
      'Required to read priority alerts from WhatsApp, Gmail, Slack, and other chosen apps locally on-device.',
    settingsAction: 'android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS',
    settingsActionLabel: 'Open Notification Listener Settings',
    adbCommand:
      'adb shell cmd notification allow_listener com.jarvis.assistant/.service.JarvisNotificationListenerService',
    gracefulFallback:
      'If denied: System prompts user to authorize access; delivers agenda and weather without crashing.',
    androidApiLevel: 'Android 4.3+ (API 18)',
  },
  {
    id: 'calendar',
    name: 'Calendar Access (Read Agenda)',
    manifestPermission: 'android.permission.READ_CALENDAR',
    category: 'Scheduling',
    isMandatoryForCore: false,
    whyNeeded:
      'Allows JARVIS to read daily scheduled meetings and agenda items for the morning briefing.',
    settingsAction: 'android.settings.APPLICATION_DETAILS_SETTINGS',
    settingsActionLabel: 'Open App Permissions > Calendar',
    adbCommand: 'adb shell pm grant com.jarvis.assistant android.permission.READ_CALENDAR',
    gracefulFallback:
      'If denied: Calendar section is cleanly omitted from briefing without inventing false information.',
    androidApiLevel: 'Android 6.0+ (API 23)',
  },
  {
    id: 'fullscreen_intent',
    name: 'Full-Screen Incoming Call Intent',
    manifestPermission: 'android.permission.USE_FULL_SCREEN_INTENT',
    category: 'System',
    isMandatoryForCore: true,
    whyNeeded:
      'Required on modern Android devices to wake the screen and display the JARVIS incoming call HUD over the lockscreen.',
    settingsAction: 'android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT',
    settingsActionLabel: 'Open Full-Screen Intent Settings',
    adbCommand:
      'adb shell appops set com.jarvis.assistant USE_FULL_SCREEN_INTENT allow',
    gracefulFallback:
      'If denied: Fallback to high-priority notification banner requiring manual unlock to answer.',
    androidApiLevel: 'Android 14+ (API 34)',
  },
  {
    id: 'exact_alarm',
    name: 'Exact Alarm Scheduling',
    manifestPermission: 'android.permission.SCHEDULE_EXACT_ALARM',
    category: 'Scheduling',
    isMandatoryForCore: true,
    whyNeeded:
      'Guarantees the scheduled morning wake trigger executes at the precise second without Android OS sleep throttling.',
    settingsAction: 'android.settings.REQUEST_SCHEDULE_EXACT_ALARM',
    settingsActionLabel: 'Open Alarms & Reminders Settings',
    adbCommand:
      'adb shell appops set com.jarvis.assistant SCHEDULE_EXACT_ALARM allow',
    gracefulFallback:
      'If denied: AlarmManager uses inexact delivery which may be delayed up to 15 minutes by Doze mode.',
    androidApiLevel: 'Android 12+ (API 31)',
  },
  {
    id: 'post_notifications',
    name: 'Post Notifications',
    manifestPermission: 'android.permission.POST_NOTIFICATIONS',
    category: 'Notifications',
    isMandatoryForCore: true,
    whyNeeded:
      'Required to display the persistent JARVIS background service status and incoming call alerts in the notification shade.',
    settingsAction: 'android.settings.APP_NOTIFICATION_SETTINGS',
    settingsActionLabel: 'Open App Notification Settings',
    adbCommand: 'adb shell pm grant com.jarvis.assistant android.permission.POST_NOTIFICATIONS',
    gracefulFallback:
      'If denied: Background service remains alive in memory but status icons will not be visible in system tray.',
    androidApiLevel: 'Android 13+ (API 33)',
  },
  {
    id: 'battery_optimization',
    name: 'Battery Optimization Exemption',
    manifestPermission: 'android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS',
    category: 'Battery & Power',
    isMandatoryForCore: false,
    whyNeeded:
      'Prevents OEM background killers (Samsung OneUI, Xiaomi MIUI, Pixel Doze) from sleeping the alarm or notification listener.',
    settingsAction: 'android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS',
    settingsActionLabel: 'Open Battery Optimization Settings',
    adbCommand:
      'adb shell dumpsys deviceidle whitelist +com.jarvis.assistant',
    gracefulFallback:
      'If denied: Alarms rely on standard Android AlarmClock provider; may be suspended if battery is critically low.',
    androidApiLevel: 'Android 6.0+ (API 23)',
  },
  {
    id: 'boot_completed',
    name: 'Boot & Restart Rescheduling',
    manifestPermission: 'android.permission.RECEIVE_BOOT_COMPLETED',
    category: 'System',
    isMandatoryForCore: true,
    whyNeeded:
      'Automatically reschedules the morning alarm with Android OS whenever the device finishes booting or restarting.',
    settingsAction: 'SYSTEM_BOOT_RECEIVER',
    settingsActionLabel: 'Validated via BootReceiver in AndroidManifest',
    adbCommand:
      'adb shell am broadcast -a android.intent.action.BOOT_COMPLETED -n com.jarvis.assistant/.receiver.MorningBriefingReceiver',
    gracefulFallback:
      'If reboot occurs: BootReceiver automatically re-arms the morning alarm clock without requiring app launch.',
    androidApiLevel: 'Android 1.0+ (Universal)',
  },
];

export function getPermissionStatus(settings: JarvisSettings, id: string): PermissionStatus {
  // Check explicit granular status if stored
  if (settings.permissionStatuses && settings.permissionStatuses[id]) {
    return settings.permissionStatuses[id];
  }

  // Fallback to individual boolean properties
  switch (id) {
    case 'microphone':
      return settings.isMicrophonePermissionGranted ? 'GRANTED' : 'REQUIRED';
    case 'notification_listener':
      return settings.isNotificationAccessGranted ? 'GRANTED' : 'REQUIRED';
    case 'calendar':
      return settings.isCalendarPermissionGranted ? 'GRANTED' : 'REQUIRED';
    case 'fullscreen_intent':
      return settings.isFullScreenIntentGranted !== false ? 'GRANTED' : 'REQUIRED';
    case 'exact_alarm':
      return settings.isExactAlarmGranted !== false ? 'GRANTED' : 'REQUIRED';
    case 'post_notifications':
      return settings.isPostNotificationsGranted !== false ? 'GRANTED' : 'REQUIRED';
    case 'battery_optimization':
      return settings.isBatteryOptimizationIgnored ? 'GRANTED' : 'REQUIRED';
    case 'boot_completed':
      return 'GRANTED'; // System declared & verified
    default:
      return 'REQUIRED';
  }
}

export interface ReadinessAuditResult {
  total: number;
  grantedCount: number;
  requiredCount: number;
  deniedCount: number;
  percentage: number;
  isFullyReady: boolean;
  isCoreReady: boolean;
  remainingItems: DevicePermissionItem[];
  reportMessage: string;
}

export function performDeviceReadinessCheck(settings: JarvisSettings): ReadinessAuditResult {
  const items: DevicePermissionItem[] = DEVICE_PERMISSIONS_CATALOG.map(cat => ({
    ...cat,
    status: getPermissionStatus(settings, cat.id),
  }));

  const total = items.length;
  const grantedCount = items.filter(i => i.status === 'GRANTED').length;
  const requiredCount = items.filter(i => i.status === 'REQUIRED').length;
  const deniedCount = items.filter(i => i.status === 'DENIED').length;
  const remainingItems = items.filter(i => i.status !== 'GRANTED');
  const percentage = Math.round((grantedCount / total) * 100);

  const coreMissing = remainingItems.filter(i => i.isMandatoryForCore);
  const isFullyReady = remainingItems.length === 0;
  const isCoreReady = coreMissing.length === 0;

  let reportMessage = '';
  if (isFullyReady) {
    reportMessage =
      '100% DEVICE READY: All permissions, background listeners, and hardware interfaces are nominal for real Android device operation.';
  } else if (isCoreReady) {
    reportMessage = `${grantedCount} of ${total} Ready (${percentage}%): Core subsystems operational. ${remainingItems.length} optional permissions remaining for enhanced convenience.`;
  } else {
    reportMessage = `${grantedCount} of ${total} Ready (${percentage}%): Action required on ${coreMissing.length} critical permissions (${coreMissing.map(m => m.name).join(', ')}).`;
  }

  return {
    total,
    grantedCount,
    requiredCount,
    deniedCount,
    percentage,
    isFullyReady,
    isCoreReady,
    remainingItems,
    reportMessage,
  };
}
