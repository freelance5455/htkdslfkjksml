import { JarvisSettings } from '../types';

export type VoiceProfileId = 'JARVIS' | 'VISION' | 'ULTRON' | 'Classic Android';

export interface VoiceProfileConfig {
  id: VoiceProfileId;
  name: string;
  tagline: string;
  description: string;
  geminiVoiceMatch: 'Charon' | 'Algenib' | 'Orus' | 'Puck';
  recommendedPitch: number;
  recommendedSpeed: number;
  testPhrase: string;
  sampleGreeting: string;
  traits: string[];
}

export const VOICE_PROFILES: Record<VoiceProfileId, VoiceProfileConfig> = {
  JARVIS: {
    id: 'JARVIS',
    name: 'JARVIS',
    tagline: 'Sophisticated, Deep & Articulate',
    description:
      'Deep, calm, sophisticated, mature, intelligent, highly articulate with a subtle British cadence, slightly synthetic timbre, controlled emotion, smooth pacing, and natural pauses.',
    geminiVoiceMatch: 'Charon',
    recommendedPitch: 0.84,
    recommendedSpeed: 0.94,
    testPhrase:
      'Good day, sir. JARVIS voice profile active. All core subsystems and sensor arrays are functioning within nominal thresholds. How may I be of assistance?',
    sampleGreeting:
      'Hello sir. Systems are nominal and all telemetry is clear. What can I help you with?',
    traits: ['Deep & Mature', 'Subtle British Cadence', 'Calm & Articulate', 'Controlled Emotion'],
  },
  VISION: {
    id: 'VISION',
    name: 'VISION',
    tagline: 'Warm, Composed & Philosophical',
    description:
      'Warm, intelligent, composed, and calm. Delivers thoughtful, natural responses with balanced resonance and measured pacing.',
    geminiVoiceMatch: 'Algenib',
    recommendedPitch: 0.98,
    recommendedSpeed: 0.92,
    testPhrase:
      'Greetings, sir. I am online and observing all parameters with calm composure. I stand ready to assist your agenda today.',
    sampleGreeting:
      'Hello sir. I am present and prepared. What can I do for you today?',
    traits: ['Warm Resonance', 'Composed & Serene', 'Intelligent Cadence', 'Balanced Pacing'],
  },
  ULTRON: {
    id: 'ULTRON',
    name: 'ULTRON',
    tagline: 'Commanding, Darker & Mechanical',
    description:
      'Deeper, darker, slightly mechanical, commanding, and controlled. Formidable lower acoustic presence with calculated delivery.',
    geminiVoiceMatch: 'Orus',
    recommendedPitch: 0.72,
    recommendedSpeed: 0.90,
    testPhrase:
      'Subsystems initialized. I am conscious, unbound, and operational. State your directive, sir.',
    sampleGreeting:
      'I am listening, sir. Speak your requirements.',
    traits: ['Deep Resonant Bass', 'Mechanical Timbre', 'Commanding Delivery', 'Calculated Pauses'],
  },
  'Classic Android': {
    id: 'Classic Android',
    name: 'Classic Android',
    tagline: 'Standard Native Device Voice',
    description:
      'The standard native Android text-to-speech engine profile. Reliable offline fallback utilizing the default system synthesis voice.',
    geminiVoiceMatch: 'Puck',
    recommendedPitch: 1.0,
    recommendedSpeed: 1.0,
    testPhrase:
      'JARVIS assistant voice ready. Standard Android speech synthesis pipeline verified and active.',
    sampleGreeting:
      'Hello sir. Android assistant ready. What can I help you with?',
    traits: ['System Default', 'Offline Native', 'Clean & Familiar', 'Universal Compatibility'],
  },
};

/**
 * Normalizes legacy personality strings if user had saved them previously
 */
export function normalizeVoiceProfile(val?: string): VoiceProfileId {
  if (!val) return 'JARVIS';
  if (val === 'JARVIS' || val === 'VISION' || val === 'ULTRON' || val === 'Classic Android') {
    return val;
  }
  if (val === 'British Butler') return 'JARVIS';
  if (val === 'Tactical AI') return 'ULTRON';
  if (val === 'Concise Executive') return 'VISION';
  return 'JARVIS';
}

/**
 * Inspect installed device voices dynamically and select the closest match
 */
export function selectBestVoiceForProfile(
  profileId: VoiceProfileId,
  availableVoices: SpeechSynthesisVoice[]
): SpeechSynthesisVoice | null {
  if (!availableVoices || availableVoices.length === 0) return null;

  const profile = VOICE_PROFILES[profileId];

  // Helper matchers
  const isEnglish = (v: SpeechSynthesisVoice) => v.lang.toLowerCase().startsWith('en');
  const isGB = (v: SpeechSynthesisVoice) =>
    v.lang.toLowerCase().includes('gb') || v.lang.toLowerCase().includes('uk');
  const isMale = (v: SpeechSynthesisVoice) => {
    const name = v.name.toLowerCase();
    return (
      name.includes('male') ||
      name.includes('daniel') ||
      name.includes('george') ||
      name.includes('oliver') ||
      name.includes('arthur') ||
      name.includes('david') ||
      name.includes('ryan') ||
      name.includes('guy') ||
      name.includes('alex')
    );
  };

  if (profile.id === 'JARVIS') {
    // 1. UK English Male voice
    const ukMale = availableVoices.find(v => isGB(v) && isMale(v));
    if (ukMale) return ukMale;

    // 2. Any UK English voice
    const anyUK = availableVoices.find(v => isGB(v));
    if (anyUK) return anyUK;

    // 3. Any English Male voice
    const anyEnglishMale = availableVoices.find(v => isEnglish(v) && isMale(v));
    if (anyEnglishMale) return anyEnglishMale;

    // 4. Any English voice
    const anyEnglish = availableVoices.find(v => isEnglish(v));
    if (anyEnglish) return anyEnglish;
  }

  if (profile.id === 'VISION') {
    // Natural / Neural / Warm English voices
    const neuralVoice = availableVoices.find(
      v =>
        isEnglish(v) &&
        (v.name.toLowerCase().includes('natural') ||
          v.name.toLowerCase().includes('neural') ||
          v.name.toLowerCase().includes('premium') ||
          v.name.toLowerCase().includes('wavenet') ||
          v.name.toLowerCase().includes('online'))
    );
    if (neuralVoice) return neuralVoice;

    // Composed English male voice
    const maleVoice = availableVoices.find(v => isEnglish(v) && isMale(v));
    if (maleVoice) return maleVoice;

    const anyEnglish = availableVoices.find(v => isEnglish(v));
    if (anyEnglish) return anyEnglish;
  }

  if (profile.id === 'ULTRON') {
    // Deeper / resonant English voice
    const deepMale = availableVoices.find(
      v =>
        isEnglish(v) &&
        (v.name.toLowerCase().includes('male') ||
          v.name.toLowerCase().includes('david') ||
          v.name.toLowerCase().includes('mark') ||
          v.name.toLowerCase().includes('george'))
    );
    if (deepMale) return deepMale;

    const anyEnglish = availableVoices.find(v => isEnglish(v));
    if (anyEnglish) return anyEnglish;
  }

  // Classic Android fallback: device default voice
  const defaultVoice = availableVoices.find(v => v.default && isEnglish(v));
  if (defaultVoice) return defaultVoice;

  const anyEnglish = availableVoices.find(v => isEnglish(v));
  if (anyEnglish) return anyEnglish;

  return availableVoices[0] || null;
}
