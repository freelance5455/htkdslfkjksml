/**
 * استخراج معرّف فيديو يوتيوب من أي صيغة رابط أو من معرّف خام.
 * الصيغ المدعومة:
 *  - https://www.youtube.com/watch?v=ID  (مع أي بارامترات إضافية)
 *  - https://youtu.be/ID
 *  - https://www.youtube.com/shorts/ID
 *  - https://www.youtube.com/embed/ID
 *  - https://www.youtube.com/live/ID
 *  - https://www.youtube.com/v/ID
 *  - https://m.youtube.com/... و youtube-nocookie.com/embed/ID
 *  - playlist: يُستخرج معرّف الفيديو من بارامتر v إن وُجد
 *  - ID خام من ١١ حرفاً
 * يعيد سلسلة فارغة إذا لم يجد معرّفاً صالحاً.
 */

const ID_RE = /^[A-Za-z0-9_-]{11}$/;

export function extractVideoId(input: string | null | undefined): string {
  if (!input) return '';
  const raw = input.trim();
  if (!raw) return '';

  // معرّف خام
  if (ID_RE.test(raw)) return raw;

  // نضيف البروتوكول عند غيابه لتسهيل التحليل
  const withProto = /^https?:\/\//i.test(raw) ? raw : `https://${raw.replace(/^\/+/, '')}`;

  let url: URL;
  try {
    url = new URL(withProto);
  } catch {
    return '';
  }

  const host = url.hostname.replace(/^www\.|^m\./i, '').toLowerCase();
  const segments = url.pathname.split('/').filter(Boolean);

  // youtu.be/ID أو youtu.be/ID?t=30
  if (host === 'youtu.be') {
    const candidate = segments[0] ?? '';
    return ID_RE.test(candidate) ? candidate : '';
  }

  if (host === 'youtube.com' || host === 'youtube-nocookie.com' || host === 'music.youtube.com') {
    const v = url.searchParams.get('v');
    if (v && ID_RE.test(v)) return v;

    const keyed = ['embed', 'shorts', 'live', 'v', 'e'];
    for (const key of keyed) {
      const idx = segments.indexOf(key);
      if (idx >= 0) {
        const candidate = segments[idx + 1] ?? '';
        if (ID_RE.test(candidate)) return candidate;
      }
    }
    // playlist مع v داخل الهاش (صيغ قديمة)
    const hash = url.hash.replace(/^#/, '');
    if (hash.includes('v=')) {
      const candidate = new URLSearchParams(hash).get('v');
      if (candidate && ID_RE.test(candidate)) return candidate;
    }
  }

  // محاولة أخيرة: أي مقطع يشبه المعرّف
  const fallback = segments.reverse().find((s) => ID_RE.test(s));
  return fallback ?? '';
}

export function youtubeWatchUrl(videoId: string): string {
  return `https://www.youtube.com/watch?v=${videoId}`;
}

/**
 * اختبارات سريعة تُنفَّذ في وضع التطوير فقط (تظهر في وحدة التحكّم).
 * تعيد قائمة بالفشل حتى يسهل التصحيح.
 */
export function runExtractVideoIdTests(): { passed: number; failed: string[] } {
  const id = 'dQw4w9WgXcQ';
  const cases: Array<[string, string]> = [
    [`https://www.youtube.com/watch?v=${id}`, id],
    [`https://www.youtube.com/watch?v=${id}&t=42s&list=PL123`, id],
    [`https://youtu.be/${id}?si=abc`, id],
    [`https://youtu.be/${id}`, id],
    [`https://www.youtube.com/shorts/${id}`, id],
    [`https://www.youtube.com/embed/${id}?rel=0`, id],
    [`https://www.youtube-nocookie.com/embed/${id}`, id],
    [`https://m.youtube.com/watch?v=${id}`, id],
    [`https://www.youtube.com/live/${id}`, id],
    [`https://www.youtube.com/playlist?list=PLabc&v=${id}`, id],
    [`www.youtube.com/watch?v=${id}`, id],
    [`youtube.com/watch?v=${id}`, id],
    [id, id],
    ['', ''],
    ['https://vimeo.com/12345', ''],
    ['not a link', ''],
  ];
  const failed: string[] = [];
  let passed = 0;
  for (const [input, expected] of cases) {
    const got = extractVideoId(input);
    if (got === expected) passed += 1;
    else failed.push(`«${input}» → ${got || '(فارغ)'} بدل ${expected || '(فارغ)'}`);
  }
  return { passed, failed };
}
