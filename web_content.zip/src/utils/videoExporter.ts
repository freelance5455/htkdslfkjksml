import JSZip from 'jszip';
import { VideoProject, VideoSegment } from '../types/project';

export interface ExportProgress {
  currentClipIndex: number;
  totalClips: number;
  progressPercent: number;
  message: string;
}

/**
 * Real Video Rendering & Export Engine
 * Uses Canvas captureStream + Web Audio API + MediaRecorder to produce genuine playable MP4/WebM files.
 */
export async function exportVideoSegment(
  videoElement: HTMLVideoElement,
  project: VideoProject,
  startTime: number,
  endTime: number,
  resolution: '480p' | '720p' | '1080p',
  onProgress?: (pct: number) => void
): Promise<Blob> {
  return new Promise(async (resolve, reject) => {
    try {
      const targetDimensions = getResolutionDimensions(project.aspectRatio, resolution);
      const canvas = document.createElement('canvas');
      canvas.width = targetDimensions.width;
      canvas.height = targetDimensions.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('تعذر إنشاء سياق الرسم للـ Canvas');

      // Audio setup
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioCtxClass();
      const dest = audioCtx.createMediaStreamDestination();

      let sourceNode: MediaElementAudioSourceNode | null = null;
      try {
        // Connect video audio if not muted
        if (!project.isMuted) {
          sourceNode = audioCtx.createMediaElementSource(videoElement);
          const gainNode = audioCtx.createGain();
          gainNode.gain.setValueAtTime(project.volume ?? 1, audioCtx.currentTime);
          sourceNode.connect(gainNode);
          gainNode.connect(dest);
          gainNode.connect(audioCtx.destination);
        }
      } catch (audioErr) {
        // Already connected or cross-origin audio handled gracefully
        console.warn('Audio capture notice:', audioErr);
      }

      // Stream setup
      const canvasStream = canvas.captureStream(30);
      const audioTracks = dest.stream.getAudioTracks();
      if (audioTracks.length > 0) {
        canvasStream.addTrack(audioTracks[0]);
      }

      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
        ? 'video/webm;codecs=vp9,opus'
        : MediaRecorder.isTypeSupported('video/webm')
        ? 'video/webm'
        : 'video/mp4';

      const recorder = new MediaRecorder(canvasStream, {
        mimeType,
        videoBitsPerSecond: getBitrateForResolution(resolution)
      });

      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunks.push(e.data);
      };

      recorder.onstop = () => {
        audioCtx.close().catch(() => {});
        const finalBlob = new Blob(chunks, { type: mimeType });
        resolve(finalBlob);
      };

      const duration = endTime - startTime;
      videoElement.currentTime = startTime;
      videoElement.playbackRate = project.speed || 1;

      // Wait until seek completes
      await new Promise<void>((r) => {
        const onSeeked = () => {
          videoElement.removeEventListener('seeked', onSeeked);
          r();
        };
        videoElement.addEventListener('seeked', onSeeked);
      });

      recorder.start(100);
      await videoElement.play().catch(() => {});

      let isRecording = true;
      const checkFrame = () => {
        if (!isRecording) return;

        const currentPos = videoElement.currentTime;
        const elapsed = currentPos - startTime;
        const progress = Math.min(1, Math.max(0, elapsed / duration));

        if (onProgress) {
          onProgress(Math.round(progress * 100));
        }

        // Draw current frame onto canvas with all overlays, filters, and aspect ratios
        renderProjectFrameToCanvas(ctx, videoElement, project, canvas.width, canvas.height);

        if (currentPos >= endTime || videoElement.ended) {
          isRecording = false;
          videoElement.pause();
          setTimeout(() => {
            recorder.stop();
          }, 150);
        } else {
          requestAnimationFrame(checkFrame);
        }
      };

      requestAnimationFrame(checkFrame);
    } catch (err) {
      reject(err);
    }
  });
}

/**
 * Batch export all split clips and optionally compress into a single ZIP archive.
 */
export async function exportAllSegments(
  videoElement: HTMLVideoElement,
  project: VideoProject,
  segments: VideoSegment[],
  resolution: '480p' | '720p' | '1080p',
  asZip: boolean,
  onProgress?: (status: ExportProgress) => void
): Promise<{ blobs: { name: string; blob: Blob }[]; zipBlob?: Blob }> {
  const blobs: { name: string; blob: Blob }[] = [];
  const zip = asZip ? new JSZip() : null;

  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i];
    const clipName = `Designo_${project.name.replace(/\s+/g, '_')}_Part_${seg.index}.webm`;

    if (onProgress) {
      onProgress({
        currentClipIndex: i + 1,
        totalClips: segments.length,
        progressPercent: Math.round((i / segments.length) * 100),
        message: `جاري معالجة المقطع ${i + 1} من أصل ${segments.length}...`
      });
    }

    const clipBlob = await exportVideoSegment(
      videoElement,
      project,
      seg.startTime,
      seg.endTime,
      resolution,
      (clipPct) => {
        if (onProgress) {
          const overallPct = Math.round(((i + clipPct / 100) / segments.length) * 100);
          onProgress({
            currentClipIndex: i + 1,
            totalClips: segments.length,
            progressPercent: overallPct,
            message: `معالجة المقطع ${i + 1}/${segments.length}: ${clipPct}%`
          });
        }
      }
    );

    blobs.push({ name: clipName, blob: clipBlob });
    if (zip) {
      zip.file(clipName, clipBlob);
    }
  }

  let zipBlob: Blob | undefined;
  if (zip) {
    if (onProgress) {
      onProgress({
        currentClipIndex: segments.length,
        totalClips: segments.length,
        progressPercent: 99,
        message: 'جاري تجميع وحفظ جميع المقاطع في ملف ZIP مضغوط...'
      });
    }
    zipBlob = await zip.generateAsync({ type: 'blob' });
  }

  if (onProgress) {
    onProgress({
      currentClipIndex: segments.length,
      totalClips: segments.length,
      progressPercent: 100,
      message: 'تم إتمام التصدير بنجاح! 🚀'
    });
  }

  return { blobs, zipBlob };
}

/**
 * Canvas drawing logic: renders video frame, smart background mirror, filters, watermark & titles
 */
export function renderProjectFrameToCanvas(
  ctx: CanvasRenderingContext2D,
  video: HTMLVideoElement,
  project: VideoProject,
  width: number,
  height: number
) {
  // Clear canvas
  ctx.clearRect(0, 0, width, height);

  // Background
  ctx.fillStyle = '#0b0b14';
  ctx.fillRect(0, 0, width, height);

  // Apply visual adjustments filter
  const filterString = buildCssFilterString(project);
  ctx.filter = filterString;

  const vw = video.videoWidth || 1280;
  const vh = video.videoHeight || 720;
  const videoAspect = vw / vh;
  const canvasAspect = width / height;

  // Blurred background mirror for vertical/aspect transforms
  if (project.blurBackground && Math.abs(videoAspect - canvasAspect) > 0.05) {
    ctx.save();
    ctx.filter = `blur(28px) brightness(0.6) ${filterString}`;
    // Stretch to cover whole canvas
    ctx.drawImage(video, 0, 0, width, height);
    ctx.restore();

    // Dark semi-transparent scrim over blurred background
    ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
    ctx.fillRect(0, 0, width, height);
  }

  // Draw main video fitted neatly
  let drawW = width;
  let drawH = height;
  let drawX = 0;
  let drawY = 0;

  if (videoAspect > canvasAspect) {
    // Video is wider than canvas
    drawW = width;
    drawH = width / videoAspect;
    drawY = (height - drawH) / 2;
  } else {
    // Video is taller than canvas
    drawH = height;
    drawW = height * videoAspect;
    drawX = (width - drawW) / 2;
  }

  ctx.save();
  ctx.filter = filterString;
  ctx.drawImage(video, drawX, drawY, drawW, drawH);
  ctx.restore();

  // Reset filter for text overlays
  ctx.filter = 'none';

  // Draw Template / Video Overlays
  drawOverlays(ctx, project, width, height);
}

function drawOverlays(
  ctx: CanvasRenderingContext2D,
  project: VideoProject,
  width: number,
  height: number
) {
  // Watermark (e.g. Channel name or brand)
  if (project.watermarkText) {
    ctx.save();
    ctx.font = '600 20px Cairo, sans-serif';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
    ctx.shadowBlur = 6;
    ctx.textAlign = 'right';
    ctx.fillText(`@${project.watermarkText}`, width - 24, 40);
    ctx.restore();
  }

  // Text overlays (Titles, Subtitles)
  if (project.textOverlays && project.textOverlays.length > 0) {
    project.textOverlays.forEach((t) => {
      if (!t.text) return;
      ctx.save();

      const fontSize = Math.max(18, Math.round((t.fontSize || 32) * (width / 720)));
      ctx.font = `bold ${fontSize}px Cairo, sans-serif`;
      ctx.textAlign = 'center';

      let yPos = height / 2;
      if (t.position === 'top') {
        yPos = height * 0.16;
      } else if (t.position === 'bottom') {
        yPos = height * 0.85;
      }

      const textMetrics = ctx.measureText(t.text);
      const textWidth = textMetrics.width;
      const paddingX = 24;
      const paddingY = 14;

      if (t.hasBackground) {
        ctx.fillStyle = t.bgColor || 'rgba(0, 0, 0, 0.75)';
        ctx.beginPath();
        ctx.roundRect(
          width / 2 - textWidth / 2 - paddingX,
          yPos - fontSize + 4 - paddingY,
          textWidth + paddingX * 2,
          fontSize + paddingY * 2,
          12
        );
        ctx.fill();
      }

      ctx.fillStyle = t.color || '#ffffff';
      ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
      ctx.shadowBlur = 8;
      ctx.fillText(t.text, width / 2, yPos);
      ctx.restore();
    });
  }
}

function buildCssFilterString(project: VideoProject): string {
  const parts: string[] = [];

  const b = project.brightness ?? 1;
  const c = project.contrast ?? 1;
  const s = project.saturation ?? 1;

  parts.push(`brightness(${b})`);
  parts.push(`contrast(${c})`);
  parts.push(`saturate(${s})`);

  switch (project.filter) {
    case 'cinematic':
      parts.push('contrast(1.15) saturate(1.2) hue-rotate(-8deg)');
      break;
    case 'vibrant':
      parts.push('saturate(1.5) contrast(1.1)');
      break;
    case 'gold':
      parts.push('sepia(0.35) saturate(1.3) hue-rotate(-15deg)');
      break;
    case 'bw':
      parts.push('grayscale(100%) contrast(1.2)');
      break;
    case 'vintage':
      parts.push('sepia(0.6) contrast(0.9) brightness(0.95)');
      break;
    case 'warm':
      parts.push('sepia(0.2) saturate(1.2)');
      break;
    default:
      break;
  }

  return parts.join(' ');
}

export function getResolutionDimensions(
  aspect: VideoProject['aspectRatio'],
  res: '480p' | '720p' | '1080p'
): { width: number; height: number } {
  const baseSize = res === '1080p' ? 1080 : res === '720p' ? 720 : 480;

  switch (aspect) {
    case '9:16':
      // Height is standard, width is 9/16 * height
      return {
        width: Math.round((baseSize * 9) / 16 / 2) * 2, // Even numbers for codecs
        height: baseSize === 1080 ? 1920 : baseSize === 720 ? 1280 : 854
      };
    case '1:1':
      return { width: baseSize, height: baseSize };
    case '4:5':
      return {
        width: baseSize,
        height: Math.round((baseSize * 5) / 4 / 2) * 2
      };
    case '16:9':
    default:
      return {
        width: baseSize === 1080 ? 1920 : baseSize === 720 ? 1280 : 854,
        height: baseSize
      };
  }
}

function getBitrateForResolution(res: '480p' | '720p' | '1080p'): number {
  switch (res) {
    case '1080p':
      return 6000000;
    case '720p':
      return 3500000;
    case '480p':
    default:
      return 1500000;
  }
}
