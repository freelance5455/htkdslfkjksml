import { OperationalStatus, Priority, Shift } from '../types/report';

export function formatDate(isoString: string): string {
  try {
    const d = new Date(isoString);
    return d.toLocaleDateString('it-IT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  } catch {
    return isoString;
  }
}

export function formatDateTime(isoString: string): string {
  try {
    const d = new Date(isoString);
    return `${d.toLocaleDateString('it-IT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })} ${d.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })}`;
  } catch {
    return isoString;
  }
}

export function getStatusLabel(status: OperationalStatus): string {
  switch (status) {
    case 'completato':
      return 'Completato';
    case 'in_corso':
      return 'In Lavorazione';
    case 'in_revisione':
      return 'In Revisione';
    case 'critico':
      return 'Critico / Bloccante';
    default:
      return status;
  }
}

export function getStatusTextColor(status: OperationalStatus): string {
  switch (status) {
    case 'completato':
      return 'text-emerald-700 font-medium';
    case 'in_corso':
      return 'text-blue-700 font-medium';
    case 'in_revisione':
      return 'text-amber-700 font-medium';
    case 'critico':
      return 'text-rose-700 font-semibold';
    default:
      return 'text-neutral-700';
  }
}

export function getPriorityLabel(priority: Priority): string {
  switch (priority) {
    case 'urgente':
      return 'Urgente';
    case 'alta':
      return 'Alta';
    case 'media':
      return 'Media';
    case 'bassa':
      return 'Bassa';
    default:
      return priority;
  }
}

export function getPriorityTextColor(priority: Priority): string {
  switch (priority) {
    case 'urgente':
      return 'text-rose-700 font-semibold';
    case 'alta':
      return 'text-amber-700 font-medium';
    case 'media':
      return 'text-neutral-700';
    case 'bassa':
      return 'text-neutral-500';
    default:
      return 'text-neutral-600';
  }
}

export function getShiftLabel(shift: Shift): string {
  switch (shift) {
    case 'mattina':
      return 'Mattina (06-14)';
    case 'pomeriggio':
      return 'Pomeriggio (14-22)';
    case 'notte':
      return 'Notte (22-06)';
    case 'giornaliero':
      return 'Giornaliero (08-17)';
    default:
      return shift;
  }
}
