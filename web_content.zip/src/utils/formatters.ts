export interface CurrencyOption {
  symbol: string;
  label: string;
  locale: string;
}

export const CURRENCIES: CurrencyOption[] = [
  { symbol: '₹', label: 'INR – Indian Rupee (₹)', locale: 'en-IN' },
  { symbol: '$', label: 'USD – US Dollar ($)', locale: 'en-US' },
  { symbol: '€', label: 'EUR – Euro (€)', locale: 'de-DE' },
  { symbol: '£', label: 'GBP – British Pound (£)', locale: 'en-GB' },
  { symbol: 'AED ', label: 'AED – UAE Dirham (AED)', locale: 'en-US' },
  { symbol: 'Rs ', label: 'PKR – Pakistani Rupee (Rs)', locale: 'en-IN' },
  { symbol: '৳', label: 'BDT – Bangladeshi Taka (৳)', locale: 'en-IN' },
  { symbol: '¥', label: 'JPY – Japanese Yen (¥)', locale: 'ja-JP' },
  { symbol: 'C$', label: 'CAD – Canadian Dollar (C$)', locale: 'en-CA' },
  { symbol: 'A$', label: 'AUD – Australian Dollar (A$)', locale: 'en-AU' },
  { symbol: '₱', label: 'PHP – Philippine Peso (₱)', locale: 'en-PH' },
];

export function formatMoney(amount: number, symbol: string = '₹'): string {
  const cur = CURRENCIES.find((c) => c.symbol.trim() === symbol.trim()) || CURRENCIES[0];
  const absVal = Math.abs(amount || 0);
  const formattedNumber = absVal.toLocaleString(cur.locale, {
    minimumFractionDigits: absVal % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  });

  return `${amount < 0 ? '-' : ''}${symbol}${formattedNumber}`;
}

export function formatNumber(num: number): string {
  return Number(num || 0).toLocaleString('en-IN');
}

export function formatShortNumber(n: number): string {
  const val = Math.abs(n || 0);
  if (val >= 1e7) return (n / 1e7).toFixed(1) + 'Cr';
  if (val >= 1e5) return (n / 1e5).toFixed(1) + 'L';
  if (val >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return Math.round(n).toString();
}

export function getTodayIso(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatDisplayDate(isoDate: string): string {
  if (!isoDate) return '';
  const parts = isoDate.split('-');
  if (parts.length === 3) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthIdx = parseInt(parts[1], 10) - 1;
    return `${parts[2]} ${months[monthIdx] || parts[1]} ${parts[0]}`;
  }
  return isoDate;
}
