// Utility functions for formatting numbers, dates, and Bangla digits

const BANGLA_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

export function toBanglaDigits(numberStr: string | number): string {
  const str = String(numberStr);
  return str.replace(/\d/g, (digit) => BANGLA_DIGITS[parseInt(digit, 10)]);
}

export function formatCurrency(
  amount: number,
  useBanglaDigits: boolean = true,
  symbol: string = '৳'
): string {
  const formattedNumber = new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  }).format(amount);

  if (useBanglaDigits) {
    return `${symbol} ${toBanglaDigits(formattedNumber)}`;
  }
  return `${symbol} ${formattedNumber}`;
}

export function formatDate(
  dateStr: string,
  lang: 'bn' | 'en' = 'bn',
  useBanglaDigits: boolean = true
): string {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return dateStr;

  if (lang === 'en') {
    const enMonths = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return `${date.getDate()} ${enMonths[date.getMonth()]}, ${date.getFullYear()}`;
  }

  const months = [
    'জানুয়ারি',
    'ফেব্রুয়ারি',
    'মার্চ',
    'এপ্রিল',
    'মে',
    'জুন',
    'জুলাই',
    'আগস্ট',
    'সেপ্টেম্বর',
    'অক্টোবর',
    'নভেম্বর',
    'ডিসেম্বর',
  ];

  const day = date.getDate();
  const month = months[date.getMonth()];
  const year = date.getFullYear();

  if (useBanglaDigits) {
    return `${toBanglaDigits(day)} ${month}, ${toBanglaDigits(year)}`;
  }
  return `${day} ${month}, ${year}`;
}

export function formatDateBangla(dateStr: string): string {
  return formatDate(dateStr, 'bn', true);
}

export function getCurrentMonthFormatted(): string {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
}

export function getMonthName(
  yearMonth: string,
  lang: 'bn' | 'en' = 'bn',
  useBanglaDigits: boolean = true
): string {
  const [year, month] = yearMonth.split('-');
  const monthIndex = parseInt(month, 10) - 1;

  if (lang === 'en') {
    const enMonths = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return `${enMonths[monthIndex]} ${year}`;
  }

  const months = [
    'জানুয়ারি',
    'ফেব্রুয়ারি',
    'মার্চ',
    'এপ্রিল',
    'মে',
    'জুন',
    'জুলাই',
    'আগস্ট',
    'সেপ্টেম্বর',
    'অক্টোবর',
    'নভেম্বর',
    'ডিসেম্বর',
  ];

  if (useBanglaDigits) {
    return `${months[monthIndex]} ${toBanglaDigits(year)}`;
  }
  return `${months[monthIndex]} ${year}`;
}

export function getMonthNameBangla(yearMonth: string): string {
  return getMonthName(yearMonth, 'bn', true);
}

export function getPaymentMethodLabel(method: string, lang: 'bn' | 'en' = 'bn'): string {
  const bnMap: Record<string, string> = {
    cash: 'ক্যাশ / নগদ টাকা',
    bkash: 'বিকাশ (bKash)',
    nagad: 'নগদ (Nagad)',
    rocket: 'রকেট (Rocket)',
    bank: 'ব্যাংক অ্যাকাউন্ট',
    card: 'ডেবিট/ক্রেডিট কার্ড',
    other: 'অন্যান্য',
  };

  const enMap: Record<string, string> = {
    cash: 'Cash',
    bkash: 'bkash',
    nagad: 'Nagad',
    rocket: 'Rocket',
    bank: 'Bank Account',
    card: 'Debit/Credit Card',
    other: 'Other',
  };

  return lang === 'bn' ? bnMap[method] || method : enMap[method] || method;
}

