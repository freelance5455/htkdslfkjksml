/**
 * High-precision formatting and economic math for Realm Capitalist
 */

const SUFFIXES = [
  '',
  'K',
  'M',
  'B',
  'T',
  'Qa',
  'Qi',
  'Sx',
  'Sp',
  'Oc',
  'No',
  'Dc',
  'Ud',
  'Dd',
  'Td',
  'QaD',
  'QiD',
  'SxD',
  'SpD',
  'OcD',
  'NoD',
  'Vg',
  'UVg',
  'DVg',
  'TVg',
  'QaVg',
  'QiVg',
  'SxVg',
  'SpVg',
  'OcVg',
  'NoVg',
  'Tg',
];

export function formatNumber(
  num: number,
  format: 'SUFFIX' | 'SCIENTIFIC' = 'SUFFIX',
  decimals: number = 2
): string {
  if (num === null || num === undefined || isNaN(num)) return '0';
  if (!isFinite(num)) return '∞';
  if (num < 0) return '-' + formatNumber(-num, format, decimals);
  if (num === 0) return '0';

  if (format === 'SCIENTIFIC' && num >= 1e6) {
    return num.toExponential(2).replace('+', '');
  }

  if (num < 1000) {
    if (num >= 100) return num.toFixed(0);
    if (num >= 10) return num.toFixed(1).replace(/\.0$/, '');
    return num.toFixed(decimals).replace(/\.00$/, '').replace(/(\.[1-9])0$/, '$1');
  }

  // Tiered suffixes
  let tier = Math.floor(Math.log10(num) / 3);
  if (tier < SUFFIXES.length) {
    let scale = Math.pow(10, tier * 3);
    let scaled = num / scale;

    // Check rounding overflow (e.g. 999.999 rounded to 2 decimals becomes 1000.00)
    if (parseFloat(scaled.toFixed(decimals)) >= 1000 && tier + 1 < SUFFIXES.length) {
      tier += 1;
      scale = Math.pow(10, tier * 3);
      scaled = num / scale;
    }

    return `${scaled.toFixed(decimals)} ${SUFFIXES[tier]}`;
  }

  // Fallback to scientific for super astronomical numbers
  return num.toExponential(2).replace('+', '');
}

export function formatTime(seconds: number): string {
  if (seconds <= 0) return '0.0s';
  if (seconds < 60) return `${seconds.toFixed(1)}s`;
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  if (m < 60) return `${m}m ${s}s`;
  const h = Math.floor(m / 60);
  const remM = m % 60;
  return `${h}h ${remM}m`;
}

/**
 * Geometric cost formula for AdCap style ventures
 */
export function calculateVentureCost(
  baseCost: number,
  costFactor: number,
  currentCount: number,
  quantityToBuy: number
): number {
  if (quantityToBuy <= 0) return 0;
  if (quantityToBuy === 1) {
    return baseCost * Math.pow(costFactor, currentCount);
  }

  // Sum = baseCost * costFactor^currentCount * (costFactor^k - 1) / (costFactor - 1)
  const firstTerm = baseCost * Math.pow(costFactor, currentCount);
  return firstTerm * (Math.pow(costFactor, quantityToBuy) - 1) / (costFactor - 1);
}

/**
 * Calculate max quantity a player can afford
 * Hardened against floating-point epsilon precision errors
 */
export function calculateMaxAffordable(
  baseCost: number,
  costFactor: number,
  currentCount: number,
  availableGold: number
): { count: number; cost: number } {
  const nextSingleCost = baseCost * Math.pow(costFactor, currentCount);
  if (availableGold < nextSingleCost) {
    return { count: 1, cost: nextSingleCost };
  }

  // k = floor( ln( 1 + G * (r - 1) / (baseCost * r^n) ) / ln(r) )
  const r = costFactor;
  const numerator = availableGold * (r - 1);
  const denominator = baseCost * Math.pow(r, currentCount);
  const maxK = Math.floor(Math.log(1 + numerator / denominator) / Math.log(r));

  let count = Math.max(1, maxK);
  let cost = calculateVentureCost(baseCost, costFactor, currentCount, count);

  // If floating point slight excess causes cost to slightly exceed availableGold, decrement safely
  while (cost > availableGold && count > 1) {
    count--;
    cost = calculateVentureCost(baseCost, costFactor, currentCount, count);
  }

  return { count, cost };
}

/**
 * Calculate quantity needed to reach next milestone
 */
export function calculateNextMilestoneTarget(
  currentCount: number,
  milestones: { count: number }[]
): number {
  for (const m of milestones) {
    if (m.count > currentCount) {
      return m.count - currentCount;
    }
  }
  // If past all defined milestones, every 100
  const nextHundred = (Math.floor(currentCount / 100) + 1) * 100;
  return Math.max(1, nextHundred - currentCount);
}

/**
 * Archon (Prestige) calculation formula
 */
export function calculateArchonsFromGold(lifetimeGold: number): number {
  if (lifetimeGold < 1e6) return 0;
  const archons = Math.floor(150 * Math.sqrt(lifetimeGold / 1e9));
  return Math.max(0, archons);
}
