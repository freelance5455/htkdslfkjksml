import { LabourRoleType, MessExpenseCategory } from '../types';

/**
 * ইংরেজি সংখ্যাকে বাংলা সংখ্যায় রূপান্তর (অথবা স্পষ্টতার জন্য ভারতীয় কারেন্সি ফরম্যাটে রাখা)
 */
export function formatCurrency(amount: number): string {
  if (isNaN(amount)) return '₹০';
  const formatted = new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 0
  }).format(Math.round(amount));
  return `₹${formatted}`;
}

export function formatNumber(num: number): string {
  if (isNaN(num)) return '০';
  return new Intl.NumberFormat('en-IN').format(num);
}

/**
 * তারিখকে বাংলা পাঠযোগ্য ফরম্যাটে রূপান্তর
 */
export function formatDateBengali(dateString?: string | null): string {
  if (!dateString) return 'প্রযোজ্য নয়';
  try {
    const [y, m, d] = dateString.split('-');
    if (!y || !m || !d) return dateString;
    const months = [
      'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
      'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
    ];
    const monthName = months[parseInt(m, 10) - 1] || m;
    return `${parseInt(d, 10)} ${monthName}, ${y}`;
  } catch {
    return dateString;
  }
}

/**
 * লেবারের কাজের ধরন ও মেস স্ট্যাটাস লেবেল
 */
export function getRoleTypeBadge(roleType: LabourRoleType): {
  label: string;
  badgeClass: string;
  description: string;
} {
  switch (roleType) {
    case 'mess_and_site':
      return {
        label: 'মেসে থাকে ও সাইটে কাজ করে',
        badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        description: 'সাইটের নিয়মিত কাজে যুক্ত এবং মেসের খাদ্য ও রুম শেয়ার করে।'
      };
    case 'mess_only':
      return {
        label: 'মেসে থাকে কিন্তু বাইরে কাজ করে',
        badgeClass: 'bg-amber-50 text-amber-800 border-amber-200',
        description: 'মেসে থাকে কিন্তু নিজস্ব উপায়ে বাইরে কাজ করে। মেসের ভাড়া ও খাবার দেয়।'
      };
    case 'site_only':
      return {
        label: 'সাইটে কাজ করে কিন্তু মেসে থাকে না',
        badgeClass: 'bg-blue-50 text-blue-800 border-blue-200',
        description: 'স্থানীয়ভাবে বাড়ি থেকে এসে সাইটে কাজ করে। মেসের খরচের আওতাভুক্ত নয়।'
      };
    default:
      return {
        label: 'অনির্ধারিত',
        badgeClass: 'bg-slate-100 text-slate-850 border-slate-200',
        description: ''
      };
  }
}

/**
 * মেস খরচের ক্যাটাগরি লেবেল
 */
export function getExpenseCategoryLabel(category: MessExpenseCategory): {
  label: string;
  badgeColor: string;
} {
  switch (category) {
    case 'bazar':
      return { label: 'বাজার ও কাঁচামাল', badgeColor: 'text-emerald-700 bg-emerald-50' };
    case 'gas':
      return { label: 'গ্যাস সিলিন্ডার', badgeColor: 'text-orange-700 bg-orange-50' };
    case 'cook_salary':
      return { label: 'বাবুর্চির বেতন', badgeColor: 'text-purple-700 bg-purple-50' };
    case 'electricity':
      return { label: 'বিদ্যুৎ বিল', badgeColor: 'text-amber-700 bg-amber-50' };
    case 'water_repairs':
      return { label: 'জল ও মেরামত', badgeColor: 'text-cyan-700 bg-cyan-50' };
    case 'other':
      return { label: 'অন্যান্য খরচ', badgeColor: 'text-slate-700 bg-slate-100' };
  }
}

/**
 * পেমেন্ট মেথড লেবেল
 */
export function getPaymentMethodLabel(method: string): string {
  switch (method) {
    case 'cash':
      return 'নগদ (Cash)';
    case 'upi':
      return 'UPI / অনলাইন';
    case 'bank':
      return 'ব্যাংক ট্রান্সফার';
    case 'cheque':
      return 'চেক (Cheque)';
    default:
      return method;
  }
}
