// Bengali number map
const bnDigits: { [key: string]: string } = {
  '0': '০',
  '1': '১',
  '2': '২',
  '3': '৩',
  '4': '৪',
  '5': '৫',
  '6': '৬',
  '7': '৭',
  '8': '৮',
  '9': '৯',
};

export function toBnNum(num: number | string | undefined | null): string {
  if (num === undefined || num === null) return '০';
  const str = typeof num === 'number' ? num.toLocaleString('en-US', { maximumFractionDigits: 2 }) : String(num);
  return str.replace(/[0-9]/g, (w) => bnDigits[w] || w);
}

export function formatTaka(amount: number, useBnDigits = true): string {
  const val = Math.round(amount * 100) / 100;
  if (!useBnDigits) {
    return `৳${val.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
  }
  return `৳ ${toBnNum(val)}`;
}

export function formatBengaliDateTime(isoString: string): string {
  try {
    const date = new Date(isoString);
    if (isNaN(date.getTime())) return isoString;

    const monthsBn = [
      'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
      'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
    ];

    const day = toBnNum(date.getDate());
    const month = monthsBn[date.getMonth()];
    const year = toBnNum(date.getFullYear());
    
    let hours = date.getHours();
    const minutes = toBnNum(String(date.getMinutes()).padStart(2, '0'));
    const ampm = hours >= 12 ? 'অপরাহ্ন' : 'পূর্বাহ্ন';
    hours = hours % 12;
    hours = hours ? hours : 12; // 0 should be 12
    const hoursBn = toBnNum(hours);

    return `${day} ${month} ${year}, ${hoursBn}:${minutes} ${ampm}`;
  } catch (e) {
    return isoString;
  }
}

export function formatShortDate(isoString: string): string {
  try {
    const date = new Date(isoString);
    const day = toBnNum(date.getDate());
    const month = toBnNum(date.getMonth() + 1);
    const year = toBnNum(date.getFullYear());
    return `${day}/${month}/${year}`;
  } catch {
    return isoString;
  }
}
