import { Client, StudioSettings } from '../types';

export function formatINR(amount: number): string {
  const isNegative = amount < 0;
  const abs = Math.round(Math.abs(amount));
  const formatted = new Intl.NumberFormat('en-IN').format(abs);
  return `${isNegative ? '-' : ''}₹${formatted}`;
}

export function formatDateShort(dateStr: string): string {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  if (Number.isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatDateTimeShort(isoStr: string): string {
  if (!isoStr) return '—';
  const d = new Date(isoStr);
  if (Number.isNaN(d.getTime())) return isoStr;
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function getDaysPending(pendingSince?: string): number {
  if (!pendingSince) return 0;
  const start = new Date(pendingSince);
  const now = new Date();
  const diffMs = now.getTime() - start.getTime();
  return Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
}

export function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good Morning';
  if (hour < 17) return 'Good Afternoon';
  return 'Good Evening';
}

export function buildWhatsAppReminderMessage(
  client: Client,
  settings: StudioSettings,
  customAmount?: number
): string {
  const pending = customAmount ?? Math.max(0, client.totalAmount - client.paidAmount);
  return `Namaste Sir, ${settings.companyName} se ${settings.adminName} bol raha hu. Aapke ${client.projectTitle} ka ${formatINR(
    pending
  )} pending hai. Please aaj pay kar dijiye. UPI: ${settings.upiId}. Thank You!`;
}

export function buildWhatsAppUrl(phone: string, message: string): string {
  const digits = phone.replace(/[^\d]/g, '');
  const normalized = digits.length === 10 ? `91${digits}` : digits;
  return `https://wa.me/${normalized}?text=${encodeURIComponent(message)}`;
}

export function getClientPending(client: Client): number {
  return Math.max(0, client.totalAmount - client.paidAmount);
}
