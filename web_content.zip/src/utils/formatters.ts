export function formatRelativeTimeRu(iso: string, nowMs: number = Date.now()): string {
  const ts = new Date(iso).getTime();
  if (Number.isNaN(ts)) return '—';
  const diffSec = Math.max(0, Math.floor((nowMs - ts) / 1000));
  if (diffSec < 45) return 'только что';
  const mins = Math.floor(diffSec / 60);
  if (mins < 60) return `${mins} мин назад`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} ч назад`;
  const days = Math.floor(hours / 24);
  return `${days} дн назад`;
}

export function formatDateTimeRu(iso?: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatShortTimeRu(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatCountdown(finishesAtIso: string, nowMs: number): string {
  const diffSec = Math.max(0, Math.floor((new Date(finishesAtIso).getTime() - nowMs) / 1000));
  const h = Math.floor(diffSec / 3600);
  const m = Math.floor((diffSec % 3600) / 60);
  const s = diffSec % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function getStatusTextColor(status: 'Фулл' | 'Сбалансирована' | 'В прокачке' | 'Раш'): string {
  switch (status) {
    case 'Фулл':
      return 'text-emerald-400';
    case 'Сбалансирована':
      return 'text-sky-400';
    case 'В прокачке':
      return 'text-amber-400';
    case 'Раш':
      return 'text-rose-400';
  }
}

export const TH_SERIES_COLORS: Record<number, string> = {
  18: '#FBBF24',
  17: '#F59E0B',
  16: '#38BDF8',
  15: '#10B981',
  14: '#A78BFA',
  13: '#FB7185',
  12: '#94A3B8',
  11: '#CBD5E1',
  10: '#64748B',
  9: '#475569',
};

export const PLAYER_PALETTE = [
  '#F59E0B',
  '#38BDF8',
  '#10B981',
  '#A78BFA',
  '#FB7185',
  '#2DD4BF',
];
