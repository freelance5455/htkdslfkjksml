import test from 'node:test';
import assert from 'node:assert/strict';
import { expandContractions, extractSentenceVideoTargets } from './sentenceVideoLogic';

test('extractSentenceVideoTargets picks meaningful content keywords over stop words', () => {
  const res = extractSentenceVideoTargets(
    'Could you tell me how to get to the nearest train station?'
  );
  assert.ok(res.keywords.length >= 3);
  assert.ok(!res.keywords.includes('the'));
  assert.ok(!res.keywords.includes('could'));
  assert.ok(res.keywords.includes('station'));
  assert.ok(res.keywords.includes('nearest') || res.keywords.includes('train'));
  assert.equal(res.primaryQuery, res.keywords[0]);
});

test('extractSentenceVideoTargets handles synonym sentences with = and short greeting sentences', () => {
  const withAlt = extractSentenceVideoTargets('I appreciate your patience. = Thank you for waiting.');
  assert.equal(withAlt.cleanSentence, 'I appreciate your patience.');
  assert.ok(withAlt.keywords.includes('appreciate'));
  assert.ok(withAlt.keywords.includes('patience'));

  const shortGreeting = extractSentenceVideoTargets('How are you?');
  assert.ok(shortGreeting.primaryQuery.length >= 2);
  assert.ok(shortGreeting.keywords.length >= 1);
});

test('expandContractions and extractSentenceVideoTargets handle short contraction sentences', () => {
  assert.match(expandContractions("I'm fine"), /i am fine/i);
  assert.match(expandContractions("Aren't you ready?"), /are not you ready/i);
  assert.match(expandContractions("Don't stop!"), /do not stop/i);

  const imRes = extractSentenceVideoTargets("I'm fine.");
  assert.equal(imRes.primaryQuery, 'fine');
  assert.ok(imRes.keywords.includes('fine'));

  const arentRes = extractSentenceVideoTargets("Aren't you?");
  assert.ok(arentRes.primaryQuery.length >= 2);
  assert.ok(arentRes.keywords.length >= 1);
  assert.ok(!arentRes.keywords.includes('aren'));

  const dontRes = extractSentenceVideoTargets("Don't stop.");
  assert.equal(dontRes.primaryQuery, 'stop');

  const itsRes = extractSentenceVideoTargets("It's working.");
  assert.equal(itsRes.primaryQuery, 'working');
});

test('extractSentenceVideoTargets returns empty safely for blank input', () => {
  const empty = extractSentenceVideoTargets('   ');
  assert.equal(empty.primaryQuery, '');
  assert.deepEqual(empty.keywords, []);
});
