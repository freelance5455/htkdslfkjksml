export interface SegmentationOptions {
  tolerance: number; // 5 to 80, default ~35
  feather: number; // 0 to 8 px
  edgeContrast: number;
}

export interface ColorPreset {
  name: string;
  hex: string;
  textColor: string;
}

export const COMMON_COLOR_PRESETS: ColorPreset[] = [
  { name: 'Transparent', hex: 'transparent', textColor: '#1E293B' },
  { name: 'White', hex: '#FFFFFF', textColor: '#1E293B' },
  { name: 'Black', hex: '#000000', textColor: '#FFFFFF' },
  { name: 'Blue', hex: '#1E40AF', textColor: '#FFFFFF' },
  { name: 'Red', hex: '#DC2626', textColor: '#FFFFFF' },
  { name: 'Grey', hex: '#64748B', textColor: '#FFFFFF' },
  { name: 'Studio Blue', hex: '#2563EB', textColor: '#FFFFFF' },
  { name: 'Soft Cream', hex: '#FDFBF7', textColor: '#1E293B' },
  { name: 'Emerald', hex: '#059669', textColor: '#FFFFFF' },
  { name: 'Charcoal', hex: '#1F2937', textColor: '#FFFFFF' }
];

// Helper: Parse HEX color to RGBA components
export function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  if (hex === 'transparent') return null;
  const clean = hex.replace('#', '');
  if (clean.length === 3) {
    return {
      r: parseInt(clean[0] + clean[0], 16),
      g: parseInt(clean[1] + clean[1], 16),
      b: parseInt(clean[2] + clean[2], 16)
    };
  }
  if (clean.length === 6) {
    return {
      r: parseInt(clean.substring(0, 2), 16),
      g: parseInt(clean.substring(2, 4), 16),
      b: parseInt(clean.substring(4, 6), 16)
    };
  }
  return null;
}

// Genuine on-device pixel-level background segmentation algorithm
export function segmentBackgroundOnCanvas(
  sourceCanvas: HTMLCanvasElement,
  options: SegmentationOptions = { tolerance: 32, feather: 2, edgeContrast: 1.2 }
): HTMLCanvasElement {
  const width = sourceCanvas.width;
  const height = sourceCanvas.height;

  const outputCanvas = document.createElement('canvas');
  outputCanvas.width = width;
  outputCanvas.height = height;
  const outCtx = outputCanvas.getContext('2d')!;

  const srcCtx = sourceCanvas.getContext('2d')!;
  const srcImgData = srcCtx.getImageData(0, 0, width, height);
  const srcData = srcImgData.data;

  const outImgData = outCtx.createImageData(width, height);
  const outData = outImgData.data;

  // 1. Sample background candidate colors from perimeter (corners & edge points)
  const samplePoints = [
    { x: 2, y: 2 },
    { x: width - 3, y: 2 },
    { x: 2, y: height - 3 },
    { x: width - 3, y: height - 3 },
    { x: Math.floor(width / 2), y: 2 },
    { x: Math.floor(width / 2), y: height - 3 },
    { x: 2, y: Math.floor(height / 2) },
    { x: width - 3, y: Math.floor(height / 2) }
  ];

  const bgPalette: Array<{ r: number; g: number; b: number }> = [];
  for (const pt of samplePoints) {
    const idx = (pt.y * width + pt.x) * 4;
    bgPalette.push({
      r: srcData[idx],
      g: srcData[idx + 1],
      b: srcData[idx + 2]
    });
  }

  // Calculate average corner background color
  const avgBg = bgPalette.reduce(
    (acc, c) => ({ r: acc.r + c.r, g: acc.g + c.g, b: acc.b + c.b }),
    { r: 0, g: 0, b: 0 }
  );
  avgBg.r = Math.round(avgBg.r / bgPalette.length);
  avgBg.g = Math.round(avgBg.g / bgPalette.length);
  avgBg.b = Math.round(avgBg.b / bgPalette.length);

  const tolSq = options.tolerance * options.tolerance * 3;
  const featherRange = 25; // alpha gradient transition zone

  // 2. Perform color distance classification with alpha falloff
  for (let i = 0; i < srcData.length; i += 4) {
    const r = srcData[i];
    const g = srcData[i + 1];
    const b = srcData[i + 2];
    const a = srcData[i + 3];

    // If source pixel is already transparent
    if (a < 10) {
      outData[i] = r;
      outData[i + 1] = g;
      outData[i + 2] = b;
      outData[i + 3] = 0;
      continue;
    }

    // Find minimum distance to any sampled background anchor
    let minDiffSq = Infinity;
    for (const bg of bgPalette) {
      const dr = r - bg.r;
      const dg = g - bg.g;
      const db = b - bg.b;
      const diffSq = dr * dr + dg * dg + db * db;
      if (diffSq < minDiffSq) {
        minDiffSq = diffSq;
      }
    }

    // Distance to average background
    const dAr = r - avgBg.r;
    const dAg = g - avgBg.g;
    const dAb = b - avgBg.b;
    const avgDiffSq = dAr * dAr + dAg * dAg + dAb * dAb;
    const effDiff = Math.sqrt(Math.min(minDiffSq, avgDiffSq));

    // Alpha ramp
    let alpha = 255;
    if (effDiff < options.tolerance) {
      alpha = 0; // Pure background
    } else if (effDiff < options.tolerance + featherRange) {
      // Soft transition feathering
      const ratio = (effDiff - options.tolerance) / featherRange;
      alpha = Math.round(ratio * 255);
    }

    outData[i] = r;
    outData[i + 1] = g;
    outData[i + 2] = b;
    outData[i + 3] = alpha;
  }

  outCtx.putImageData(outImgData, 0, 0);
  return outputCanvas;
}

// Replace transparent background with solid color or export transparent PNG
export function renderCanvasWithBackgroundColor(
  transparentCanvas: HTMLCanvasElement,
  backgroundHex: string
): HTMLCanvasElement {
  const width = transparentCanvas.width;
  const height = transparentCanvas.height;

  const finalCanvas = document.createElement('canvas');
  finalCanvas.width = width;
  finalCanvas.height = height;
  const ctx = finalCanvas.getContext('2d')!;

  if (backgroundHex !== 'transparent') {
    ctx.fillStyle = backgroundHex;
    ctx.fillRect(0, 0, width, height);
  }

  ctx.drawImage(transparentCanvas, 0, 0);
  return finalCanvas;
}

// Convert image file or data URL to HTMLCanvasElement
export function imageToCanvas(imgSrc: string | File): Promise<HTMLCanvasElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0);
        resolve(canvas);
      } else {
        reject(new Error('Could not get 2D canvas context'));
      }
    };

    img.onerror = (e) => reject(e);

    if (imgSrc instanceof File) {
      img.src = URL.createObjectURL(imgSrc);
    } else {
      img.src = imgSrc;
    }
  });
}
