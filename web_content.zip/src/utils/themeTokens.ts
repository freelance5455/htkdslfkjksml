/**
 * NoteFlow Design Tokens & Theme Data Model Architecture
 * Cross-Platform (Android, iOS, Windows, macOS, Huawei HMS/HarmonyOS)
 * Zero UI Re-Render Overhead | GMS-Independent
 */

export enum NoteFlowThemeStyle {
  Minimalist = 'Minimalist',
  Terminal = 'Terminal',
  CyberpunkGlow = 'CyberpunkGlow',
  MindMap = 'MindMap',
  EnterprisePKM = 'EnterprisePKM',
  CircadianPKM = 'CircadianPKM'
}

export interface ColorTokens {
  primary: string;
  secondary: string;
  background: string;
  surface: string;
  textPrimary: string;
  textSecondary: string;
  border: string;
  accent: string;
  error: string;
  success: string;
  warning: string;
}

export interface TypographyTokens {
  fontFamily: string;
  fontSizeSmall: string;
  fontSizeBody: string;
  fontSizeTitle: string;
  fontWeightNormal: number;
  fontWeightBold: number;
  lineHeight: number;
}

export interface BorderRadiusTokens {
  small: string;
  medium: string;
  large: string;
  pill: string;
}

export interface SpacingTokens {
  xs: string;
  sm: string;
  md: string;
  lg: string;
  xl: string;
}

export interface ElevationTokens {
  none: string;
  low: string;
  medium: string;
  high: string;
  glow: string;
}

export interface NoteFlowTokens {
  themeStyle: NoteFlowThemeStyle;
  colors: ColorTokens;
  typography: TypographyTokens;
  borderRadius: BorderRadiusTokens;
  spacing: SpacingTokens;
  elevation: ElevationTokens;
}

// Immutable Token Configurations
export const NOTE_FLOW_THEME_TOKENS: Record<NoteFlowThemeStyle, NoteFlowTokens> = {
  [NoteFlowThemeStyle.Minimalist]: {
    themeStyle: NoteFlowThemeStyle.Minimalist,
    colors: {
      primary: '#0d9488',
      secondary: '#64748b',
      background: '#f8fafc',
      surface: '#ffffff',
      textPrimary: '#0f172a',
      textSecondary: '#475569',
      border: '#e2e8f0',
      accent: '#14b8a6',
      error: '#ef4444',
      success: '#10b981',
      warning: '#f59e0b',
    },
    typography: {
      fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      fontSizeSmall: '0.75rem',
      fontSizeBody: '0.875rem',
      fontSizeTitle: '1.25rem',
      fontWeightNormal: 400,
      fontWeightBold: 700,
      lineHeight: 1.5,
    },
    borderRadius: {
      small: '0.375rem',
      medium: '0.75rem',
      large: '1.25rem',
      pill: '9999px',
    },
    spacing: {
      xs: '0.25rem',
      sm: '0.5rem',
      md: '1rem',
      lg: '1.5rem',
      xl: '2rem',
    },
    elevation: {
      none: 'none',
      low: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
      medium: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
      high: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
      glow: 'none',
    },
  },

  [NoteFlowThemeStyle.Terminal]: {
    themeStyle: NoteFlowThemeStyle.Terminal,
    colors: {
      primary: '#10b981',
      secondary: '#059669',
      background: '#020617',
      surface: '#0f172a',
      textPrimary: '#34d399',
      textSecondary: '#059669',
      border: '#064e3b',
      accent: '#22c55e',
      error: '#f87171',
      success: '#34d399',
      warning: '#fbbf24',
    },
    typography: {
      fontFamily: '"Fira Code", "Courier New", Courier, monospace',
      fontSizeSmall: '0.7rem',
      fontSizeBody: '0.825rem',
      fontSizeTitle: '1.15rem',
      fontWeightNormal: 400,
      fontWeightBold: 700,
      lineHeight: 1.4,
    },
    borderRadius: {
      small: '0.125rem',
      medium: '0.25rem',
      large: '0.375rem',
      pill: '0.375rem',
    },
    spacing: {
      xs: '0.2rem',
      sm: '0.4rem',
      md: '0.8rem',
      lg: '1.2rem',
      xl: '1.6rem',
    },
    elevation: {
      none: 'none',
      low: '0 0 5px rgba(16, 185, 129, 0.15)',
      medium: '0 0 10px rgba(16, 185, 129, 0.25)',
      high: '0 0 20px rgba(16, 185, 129, 0.35)',
      glow: '0 0 15px rgba(16, 185, 129, 0.5)',
    },
  },

  [NoteFlowThemeStyle.CyberpunkGlow]: {
    themeStyle: NoteFlowThemeStyle.CyberpunkGlow,
    colors: {
      primary: '#06b6d4',
      secondary: '#a855f7',
      background: '#030712',
      surface: '#0b0f19',
      textPrimary: '#a5f3fc',
      textSecondary: '#c084fc',
      border: '#155e75',
      accent: '#f43f5e',
      error: '#ff2a6d',
      success: '#05dda1',
      warning: '#ffb800',
    },
    typography: {
      fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, sans-serif',
      fontSizeSmall: '0.75rem',
      fontSizeBody: '0.875rem',
      fontSizeTitle: '1.3rem',
      fontWeightNormal: 500,
      fontWeightBold: 800,
      lineHeight: 1.5,
    },
    borderRadius: {
      small: '0.25rem',
      medium: '0.5rem',
      large: '1rem',
      pill: '9999px',
    },
    spacing: {
      xs: '0.25rem',
      sm: '0.5rem',
      md: '1rem',
      lg: '1.5rem',
      xl: '2.25rem',
    },
    elevation: {
      none: 'none',
      low: '0 0 8px rgba(6, 182, 212, 0.3)',
      medium: '0 0 15px rgba(6, 182, 212, 0.45)',
      high: '0 0 25px rgba(168, 85, 247, 0.5)',
      glow: '0 0 20px rgba(6, 182, 212, 0.6), 0 0 35px rgba(168, 85, 247, 0.4)',
    },
  },

  [NoteFlowThemeStyle.MindMap]: {
    themeStyle: NoteFlowThemeStyle.MindMap,
    colors: {
      primary: '#6366f1',
      secondary: '#8b5cf6',
      background: '#0f172a',
      surface: '#1e293b',
      textPrimary: '#f8fafc',
      textSecondary: '#cbd5e1',
      border: '#334155',
      accent: '#818cf8',
      error: '#f87171',
      success: '#34d399',
      warning: '#fbbf24',
    },
    typography: {
      fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, sans-serif',
      fontSizeSmall: '0.75rem',
      fontSizeBody: '0.875rem',
      fontSizeTitle: '1.25rem',
      fontWeightNormal: 400,
      fontWeightBold: 700,
      lineHeight: 1.5,
    },
    borderRadius: {
      small: '0.5rem',
      medium: '1rem',
      large: '1.5rem',
      pill: '9999px',
    },
    spacing: {
      xs: '0.25rem',
      sm: '0.5rem',
      md: '1rem',
      lg: '1.5rem',
      xl: '2rem',
    },
    elevation: {
      none: 'none',
      low: '0 2px 4px rgba(0, 0, 0, 0.2)',
      medium: '0 6px 12px rgba(0, 0, 0, 0.3)',
      high: '0 12px 24px rgba(0, 0, 0, 0.4)',
      glow: '0 0 15px rgba(99, 102, 241, 0.4)',
    },
  },

  [NoteFlowThemeStyle.EnterprisePKM]: {
    themeStyle: NoteFlowThemeStyle.EnterprisePKM,
    colors: {
      primary: '#2563eb',
      secondary: '#475569',
      background: '#f1f5f9',
      surface: '#ffffff',
      textPrimary: '#0f172a',
      textSecondary: '#334155',
      border: '#cbd5e1',
      accent: '#1d4ed8',
      error: '#dc2626',
      success: '#16a34a',
      warning: '#d97706',
    },
    typography: {
      fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      fontSizeSmall: '0.75rem',
      fontSizeBody: '0.875rem',
      fontSizeTitle: '1.2rem',
      fontWeightNormal: 400,
      fontWeightBold: 600,
      lineHeight: 1.5,
    },
    borderRadius: {
      small: '0.25rem',
      medium: '0.5rem',
      large: '0.75rem',
      pill: '9999px',
    },
    spacing: {
      xs: '0.25rem',
      sm: '0.5rem',
      md: '1rem',
      lg: '1.5rem',
      xl: '2rem',
    },
    elevation: {
      none: 'none',
      low: '0 1px 3px rgba(0, 0, 0, 0.1)',
      medium: '0 4px 6px rgba(0, 0, 0, 0.12)',
      high: '0 10px 20px rgba(0, 0, 0, 0.15)',
      glow: 'none',
    },
  },

  [NoteFlowThemeStyle.CircadianPKM]: {
    themeStyle: NoteFlowThemeStyle.CircadianPKM,
    colors: {
      primary: '#E0533C',
      secondary: '#E11D48',
      background: '#FAF6EE',
      surface: '#FFFFFF',
      textPrimary: '#1C1917',
      textSecondary: '#57534E',
      border: '#E0533C',
      accent: '#E11D48',
      error: '#EF4444',
      success: '#10B981',
      warning: '#F59E0B',
    },
    typography: {
      fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      fontSizeSmall: '0.75rem',
      fontSizeBody: '0.875rem',
      fontSizeTitle: '1.25rem',
      fontWeightNormal: 400,
      fontWeightBold: 800,
      lineHeight: 1.5,
    },
    borderRadius: {
      small: '0.5rem',
      medium: '1rem',
      large: '1.5rem',
      pill: '9999px',
    },
    spacing: {
      xs: '0.25rem',
      sm: '0.5rem',
      md: '1rem',
      lg: '1.5rem',
      xl: '2rem',
    },
    elevation: {
      none: 'none',
      low: '0 0 10px rgba(224, 83, 60, 0.25)',
      medium: '0 0 18px rgba(224, 83, 60, 0.35)',
      high: '0 0 25px rgba(225, 29, 72, 0.45)',
      glow: '0 0 20px rgba(224, 83, 60, 0.4), 0 0 25px rgba(225, 29, 72, 0.5)',
    },
  },
};

export function getNoteFlowTokens(theme: NoteFlowThemeStyle): NoteFlowTokens {
  return NOTE_FLOW_THEME_TOKENS[theme] || NOTE_FLOW_THEME_TOKENS[NoteFlowThemeStyle.Minimalist];
}
