/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TaskStatus, ToDoTask } from '../types.ts';

export const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

export const BENGALI_WEEKDAYS = [
  'রবিবার',
  'সোমবার',
  'মঙ্গলবার',
  'বুধবার',
  'বৃহস্পতিবার',
  'শুক্রবার',
  'শনিবার',
];

export const BENGALI_WEEKDAYS_SHORT = [
  'রবি',
  'সোম',
  'মঙ্গল',
  'বুধ',
  'বৃহঃ',
  'শুক্র',
  'শনি',
];

export const BENGALI_MONTHS = [
  'জানুয়ারি',
  'ফেব্রুয়ারি',
  'মার্চ',
  'এপ্রিল',
  'মে',
  'জুন',
  'জুলাই',
  'আগস্ট',
  'সেপ্টেম্বর',
  'অক্টোবর',
  'নভেম্বর',
  'ডিসেম্বর',
];

/**
 * Convert any English number or string with digits to Bengali numerals.
 */
export function toBengaliNum(num: number | string): string {
  const str = String(num);
  return str.replace(/[0-9]/g, (digit) => BENGALI_DIGITS[parseInt(digit, 10)] ?? digit);
}

/**
 * Get local date as YYYY-MM-DD
 */
export function getTodayDateString(date: Date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Parse YYYY-MM-DD into a local Date object (at midnight)
 */
export function parseDate(isoDate: string): Date {
  const [y, m, d] = isoDate.split('-').map(Number);
  return new Date(y, m - 1, d, 0, 0, 0, 0);
}

/**
 * Calculate difference in days between two ISO date strings (d2 - d1)
 */
export function diffInDays(d1: string, d2: string): number {
  const date1 = parseDate(d1).getTime();
  const date2 = parseDate(d2).getTime();
  const diffTime = date2 - date1;
  return Math.round(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Add N days to an ISO date string
 */
export function addDays(isoDate: string, days: number): string {
  const d = parseDate(isoDate);
  d.setDate(d.getDate() + days);
  return getTodayDateString(d);
}

/**
 * Get weekday index 0 (Sunday) to 6 (Saturday)
 */
export function getDayOfWeek(isoDate: string): number {
  return parseDate(isoDate).getDay();
}

/**
 * Format ISO date string into readable Bengali (e.g., "২৮ অক্টোবর" or "১ নভেম্বর ২০২৬")
 */
export function formatDateToBengali(isoDate: string, includeYear = true): string {
  if (!isoDate) return '';
  const [yearStr, monthStr, dayStr] = isoDate.split('-');
  const dayNum = parseInt(dayStr, 10);
  const monthNum = parseInt(monthStr, 10) - 1;
  const yearNum = parseInt(yearStr, 10);

  const bengaliDay = toBengaliNum(dayNum);
  const bengaliMonth = BENGALI_MONTHS[monthNum] ?? '';
  const bengaliYear = toBengaliNum(yearNum);

  if (includeYear) {
    return `${bengaliDay} ${bengaliMonth} ${bengaliYear}`;
  }
  return `${bengaliDay} ${bengaliMonth}`;
}

/**
 * Determines whether a task is scheduled on a given date (Section 5)
 * - Repeat schedule
 * - OR date is the target of a "postponed" (পরে করবো) action
 */
export function isDateScheduled(task: ToDoTask, dateStr: string): boolean {
  // Check if it was postponed to this date
  if (task.postponedDates) {
    for (const [, targetDate] of Object.entries(task.postponedDates)) {
      if (targetDate === dateStr) {
        return true;
      }
    }
  }

  // Check repeat configuration
  const repeat = task.repeat;
  if (!repeat) return false;

  switch (repeat.type) {
    case 'daily':
      return true;

    case 'weekly': {
      if (!repeat.daysOfWeek || repeat.daysOfWeek.length === 0) return false;
      const day = getDayOfWeek(dateStr);
      return repeat.daysOfWeek.includes(day);
    }

    case 'interval': {
      if (!repeat.intervalDays || repeat.intervalDays <= 0) return false;
      const startDate = repeat.startDate || task.createdAt;
      const diff = diffInDays(startDate, dateStr);
      if (diff < 0) return false;
      return diff % repeat.intervalDays === 0;
    }

    case 'custom': {
      if (!repeat.dates || repeat.dates.length === 0) return false;
      return repeat.dates.includes(dateStr);
    }

    default:
      return false;
  }
}

/**
 * Get status of a ToDo task on a specific date (Section 5)
 * Returns 'done' | 'not_done' | 'wont_do' | 'postponed' | 'pending' | null
 */
export function getTaskStatusOnDate(
  task: ToDoTask,
  dateStr: string,
  todayStr: string = getTodayDateString()
): TaskStatus | 'pending' | null {
  // 1. Explicit user report is final
  if (task.reports && task.reports[dateStr]) {
    return task.reports[dateStr];
  }

  // 2. Check if the day is scheduled
  const scheduled = isDateScheduled(task, dateStr);
  if (!scheduled) {
    return null;
  }

  // 3. If today and no report, status is 'pending' ("বাকি")
  if (dateStr === todayStr) {
    return 'pending';
  }

  // 4. Past date check: যেই দিন কাজ শুরু করবো (createdAt) ওই দিন থেকে হিসেব শুরু করবে
  if (dateStr < todayStr) {
    if (task.createdAt && dateStr >= task.createdAt) {
      return 'not_done';
    }
    // কাজ তৈরির আগের কোনো দিন নিজে থেকে 'করিনি' হবে না
    return null;
  }

  // 5. Future date with no report is blank
  return null;
}

/**
 * Calculates missed dates for a task in the past 100 days (excluding today).
 * Rolling window: [today - 100 days, today - 1 day].
 * Sorted newest to oldest.
 */
export function getMissedDaysInPast100Days(
  task: ToDoTask,
  todayStr: string = getTodayDateString()
): string[] {
  const missedDates: string[] = [];

  // 1 to 100 days ago
  for (let i = 1; i <= 100; i++) {
    const checkDate = addDays(todayStr, -i);
    const status = getTaskStatusOnDate(task, checkDate, todayStr);
    if (status === 'not_done') {
      missedDates.push(checkDate);
    }
  }

  // Already ordered newest (yesterday) to oldest (100 days ago)
  return missedDates;
}
