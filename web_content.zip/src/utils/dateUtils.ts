import { Season } from '../types/cultivation';

export const INITIAL_DATE_ISO = '2026-11-16';
export const INITIAL_CLOCK_MINUTES = 12 * 60 + 1; // 12:01 PM

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export function addDaysToIso(isoDate: string, days: number): string {
  const [y, m, d] = isoDate.split('-').map(Number);
  const dt = new Date(Date.UTC(y || 2026, (m || 11) - 1, d || 16));
  dt.setUTCDate(dt.getUTCDate() + days);
  const yy = dt.getUTCFullYear();
  const mm = String(dt.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(dt.getUTCDate()).padStart(2, '0');
  return `${yy}-${mm}-${dd}`;
}

export function formatCalendarDate(isoDate: string): string {
  const [y, m, d] = isoDate.split('-').map(Number);
  const monthName = MONTH_NAMES[((m || 11) - 1 + 12) % 12];
  return `${monthName} ${d || 16}, ${y || 2026}`;
}

export function getSeasonFromIsoDate(isoDate: string): Season {
  const m = Number(isoDate.split('-')[1]) || 11;
  if (m >= 3 && m <= 5) return 'Spring';
  if (m >= 6 && m <= 8) return 'Summer';
  if (m >= 9 && m <= 11) return 'Autumn';
  return 'Winter';
}

export function formatClockMinutes(totalMinutes: number): string {
  const normalized = ((totalMinutes % 1440) + 1440) % 1440;
  const h24 = Math.floor(normalized / 60);
  const m = normalized % 60;
  const period = h24 >= 12 ? 'PM' : 'AM';
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h12}:${String(m).padStart(2, '0')} ${period}`;
}

export function getMonthIndexFromIso(isoDate: string): number {
  const [y, m] = isoDate.split('-').map(Number);
  return (y || 2026) * 12 + ((m || 11) - 1);
}
