import { Customer, CustomerReminderInfo, ReminderStatus } from '../types';

const HINDI_MONTHS = [
  'जनवरी', 'फरवरी', 'मार्च', 'अप्रैल', 'मई', 'जून',
  'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'
];

/**
 * Returns date parts parsed in local time from "YYYY-MM-DD"
 */
export function parseLocalDate(dateStr: string): Date {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(y, m - 1, d, 0, 0, 0, 0);
}

/**
 * Formats a Date into Hindi string e.g. "28 अक्टूबर 2026"
 */
export function formatHindiDate(date: Date | string, showYear = true): string {
  const d = typeof date === 'string' ? parseLocalDate(date) : new Date(date);
  const day = d.getDate();
  const month = HINDI_MONTHS[d.getMonth()];
  const year = d.getFullYear();
  return showYear ? `${day} ${month} ${year}` : `${day} ${month}`;
}

/**
 * Formats Date to YYYY-MM-DD for <input type="date" />
 */
export function toInputDateFormat(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Calculates the 26th day reminder (Deal date + 25 days) at 09:00:00 AM
 */
export function getReminderDate(dealDateStr: string): Date {
  const deal = parseLocalDate(dealDateStr);
  const reminder = new Date(deal.getTime());
  // Add 25 full days to reach the 26th day
  reminder.setDate(reminder.getDate() + 25);
  reminder.setHours(9, 0, 0, 0);
  return reminder;
}

/**
 * Computes reminder information for a customer based on current time
 */
export function computeCustomerReminder(customer: Customer, referenceDate = new Date()): CustomerReminderInfo {
  const dealDate = parseLocalDate(customer.dealDate);
  const reminderDate = getReminderDate(customer.dealDate);

  // Compare calendar days
  const todayStart = new Date(referenceDate.getFullYear(), referenceDate.getMonth(), referenceDate.getDate(), 0, 0, 0, 0);
  const reminderStart = new Date(reminderDate.getFullYear(), reminderDate.getMonth(), reminderDate.getDate(), 0, 0, 0, 0);

  const msPerDay = 1000 * 60 * 60 * 24;
  const diffDays = Math.round((reminderStart.getTime() - todayStart.getTime()) / msPerDay);

  let status: ReminderStatus;
  let is26thDay = false;

  if (diffDays === 0) {
    status = 'today';
    is26thDay = true;
  } else if (diffDays < 0) {
    status = 'overdue';
  } else {
    status = 'upcoming';
  }

  return {
    customer,
    dealDate,
    reminderDate,
    status,
    daysRemaining: diffDays,
    is26thDay,
    formattedDealDate: formatHindiDate(dealDate),
    formattedReminderDate: formatHindiDate(reminderDate),
  };
}

/**
 * Returns human-readable Hindi badge text for the reminder
 */
export function getReminderBadge(info: CustomerReminderInfo): {
  text: string;
  subtext: string;
  badgeClass: string;
  borderClass: string;
  bgLightClass: string;
} {
  if (info.status === 'today') {
    return {
      text: '🔔 आज 26वां दिन (रिमाइंडर समय)',
      subtext: 'आज सुबह 9:00 बजे का अलार्म',
      badgeClass: 'bg-amber-500 text-white font-bold animate-pulse',
      borderClass: 'border-amber-400 ring-2 ring-amber-300',
      bgLightClass: 'bg-amber-50/70',
    };
  }

  if (info.status === 'overdue') {
    const overdueDays = Math.abs(info.daysRemaining);
    return {
      text: `⚠️ समय बीत चुका (${overdueDays} दिन पहले)`,
      subtext: `26वां दिन निकल गया (${info.formattedReminderDate})`,
      badgeClass: 'bg-rose-600 text-white font-bold',
      borderClass: 'border-rose-300',
      bgLightClass: 'bg-rose-50/50',
    };
  }

  // Upcoming
  return {
    text: `⏳ शेष: ${info.daysRemaining} दिन`,
    subtext: `26वां दिन: ${info.formattedReminderDate} सुबह 9:00 बजे`,
    badgeClass: 'bg-emerald-600 text-white font-medium',
    borderClass: 'border-emerald-200',
    bgLightClass: 'bg-white',
  };
}
