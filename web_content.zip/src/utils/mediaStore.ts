import { PresetMediaItem, StoredMediaFile } from '../types/alarm';

// Reliable High-Quality Preset Media Assets (MP4 Videos & Audio Streams)
export const PRESET_MEDIA_ITEMS: PresetMediaItem[] = [
  {
    id: 'preset-video-sunrise',
    name: 'Glorious Morning Sunrise',
    type: 'video',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&w=600&q=80',
    durationStr: '0:15',
    artistOrDesc: '4K Cinematic Nature'
  },
  {
    id: 'preset-video-waves',
    name: 'Gentle Ocean Shore Waves',
    type: 'video',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=600&q=80',
    durationStr: '0:15',
    artistOrDesc: 'Relaxing Coastal Motion'
  },
  {
    id: 'preset-video-lofi',
    name: 'Energizing City Skylines',
    type: 'video',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=600&q=80',
    durationStr: '0:12',
    artistOrDesc: 'Modern Urban Vibes'
  },
  {
    id: 'preset-audio-acoustic',
    name: 'Sunny Morning Acoustic Guitar',
    type: 'audio',
    url: 'https://actions.google.com/sounds/v1/ambiences/morning_birds.ogg',
    thumbnail: 'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?auto=format&fit=crop&w=600&q=80',
    durationStr: '1:00',
    artistOrDesc: 'Acoustic Morning Melody'
  },
  {
    id: 'preset-audio-synth',
    name: 'Cyberpunk Energizer Alarm',
    type: 'audio',
    url: 'https://actions.google.com/sounds/v1/science_fiction/alien_beacon.ogg',
    thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
    durationStr: '0:45',
    artistOrDesc: 'High-Energy Wake Beat'
  },
  {
    id: 'preset-audio-chime',
    name: 'Zen Tibetan Chimes & Bells',
    type: 'audio',
    url: 'https://actions.google.com/sounds/v1/alarms/alarm_clock.ogg',
    thumbnail: 'https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?auto=format&fit=crop&w=600&q=80',
    durationStr: '0:30',
    artistOrDesc: 'Gentle Calming Chimes'
  }
];

const DB_NAME = 'WakeUp_MediaStore_DB';
const DB_VERSION = 1;
const STORE_NAME = 'user_media_files';

let dbPromise: Promise<IDBDatabase> | null = null;

function getDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });

  return dbPromise;
}

export async function saveUserMediaFile(file: File, type: 'video' | 'audio'): Promise<StoredMediaFile> {
  const db = await getDB();
  const id = `user-media-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  
  const storedItem: StoredMediaFile = {
    id,
    name: file.name,
    type,
    blob: file,
    size: file.size,
    duration: 0,
    createdAt: Date.now()
  };

  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.put(storedItem);

    req.onsuccess = () => resolve(storedItem);
    req.onerror = () => reject(req.error);
  });
}

export async function getAllUserMediaFiles(): Promise<StoredMediaFile[]> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();

      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('IndexedDB not supported or accessible', err);
    return [];
  }
}

export async function getUserMediaFileById(id: string): Promise<StoredMediaFile | null> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(id);

      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    return null;
  }
}

export async function deleteUserMediaFile(id: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.delete(id);

    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// Helper to resolve media URL for playback (Preset vs IndexedDB Blobs)
export async function getMediaPlaybackUrl(mediaUri: string): Promise<{ url: string; isBlob: boolean }> {
  if (!mediaUri) {
    return { url: PRESET_MEDIA_ITEMS[0].url, isBlob: false };
  }

  // Check if it's a preset ID
  const preset = PRESET_MEDIA_ITEMS.find((p) => p.id === mediaUri);
  if (preset) {
    return { url: preset.url, isBlob: false };
  }

  // Check if it's a direct web URL or data URL
  if (mediaUri.startsWith('http://') || mediaUri.startsWith('https://') || mediaUri.startsWith('data:')) {
    return { url: mediaUri, isBlob: false };
  }

  // Otherwise, try retrieving from IndexedDB
  if (mediaUri.startsWith('user-media-')) {
    const mediaFile = await getUserMediaFileById(mediaUri);
    if (mediaFile && mediaFile.blob) {
      const blobUrl = URL.createObjectURL(mediaFile.blob);
      return { url: blobUrl, isBlob: true };
    }
  }

  // Fallback default
  return { url: PRESET_MEDIA_ITEMS[0].url, isBlob: false };
}
