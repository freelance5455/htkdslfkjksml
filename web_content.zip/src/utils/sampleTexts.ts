import { NarrationStyleId } from '../types/tts';

export interface SampleTeluguText {
  id: string;
  category: string;
  title: string;
  presetStyle: string;
  recommendedStyle?: NarrationStyleId;
  text: string;
}

export const SAMPLE_TELUGU_TEXTS: SampleTeluguText[] = [
  {
    id: 'sample-tech',
    category: 'సాంకేతిక పరిజ్ఞానం',
    title: 'AI విప్లవం (Tech & AI)',
    presetStyle: 'podcast',
    text: '2026లో AI technology చాలా వేగంగా అభివృద్ధి చెందుతోంది! కృత్రిమ మేధస్సు మరియు కంప్యూటర్ సైన్స్ ద్వారా మన దైనందిన జీవితంలో విప్లవాత్మక మార్పులు చోటుచేసుకుంటున్నాయి. కొత్త ఆవిష్కరణలు మానవాళి పురోగతికి సరికొత్త బాటలు వేస్తున్నాయి.',
  },
  {
    id: 'sample-story',
    category: 'పురాణ / జానపద కథ',
    title: 'గుహ రహస్యం (Mystery Story)',
    presetStyle: 'storytelling',
    text: 'అనగనగా ఒక సుందరమైన గ్రామంలో రామయ్య అనే రైతు ఉండేవాడు. ఒకరోజు పొలంలో పని చేస్తుండగా అతనికి ఒక ప్రాచీన రాతి గుహ కనిపించింది. ఆ గుహ లోపలి నుంచి ఒక అద్భుతమైన దివ్య వెలుగు ప్రసరిస్తోంది. కానీ ఆ కథ వెనుక ఎవరికీ తెలియని ఒక పెద్ద రహస్యం దాగి ఉంది.',
  },
  {
    id: 'sample-news',
    category: 'వార్తా బులెటిన్',
    title: 'రాష్ట్ర వార్తలు (News Bulletin)',
    presetStyle: 'news',
    text: 'తాజా వార్తలకు స్వాగతం. అమరావతిలో నేడు రాష్ట్ర స్థాయి టెక్నాలజీ మరియు డిజిటల్ సదస్సు ఘనంగా ప్రారంభమైంది. రాబోయే సంవత్సరంలో గ్రామీణ ప్రాంతాలకు కూడా హైస్పీడ్ 5G ఇంటర్నెట్ సౌకర్యం అందించడమే లక్ష్యంగా ప్రభుత్వం సరికొత్త ప్రణాళికను రూపొందించింది.',
  },
  {
    id: 'sample-motivational',
    category: 'ప్రేరణార్థక సందేశం',
    title: 'విజయ సాధన (Motivation)',
    presetStyle: 'motivational',
    text: 'విజయం అనేది ఒక్క రాత్రిలో లభించే వరం కాదు. నిరంతర శ్రమ, అచంచలమైన ఆత్మవిశ్వాసం, అంకితభావం ఉన్నప్పుడే అసాధ్యమైన శిఖరాలను కూడా అధిరోహించవచ్చు. పరాజయాలకు భయపడకండి, ప్రతి వైఫల్యం ఒక సరికొత్త పాఠం!',
  },
  {
    id: 'sample-cinematic',
    category: 'సినిమాటిక్',
    title: 'చీకటి సమయం (Cinematic Suspense)',
    presetStyle: 'cinematic',
    text: 'నిశ్శబ్దంగా ఉన్న ఆ దట్టమైన అడవిలో అకస్మాత్తుగా ఒక వింత శబ్దం వినిపించింది. చల్లటి గాలి వీస్తోంది. అక్కడ ఏం జరగబోతోందో ఎవరికీ అర్థం కావడం లేదు. క్షణాలు గడుస్తున్న కొద్దీ ఉత్కంఠ పరాకాష్టకు చేరుకుంది.',
  },
  {
    id: 'sample-calm',
    category: 'ఆధ్యాత్మికం / ధ్యానం',
    title: 'ప్రశాంత జీవనం (Mindful Calm)',
    presetStyle: 'calm',
    recommendedStyle: 'calm',
    text: 'జీవితం ఒక నిశ్చలమైన నది లాంటిది. ఉరుకులు పరుగుల ఈ ప్రపంచంలో కాసేపు కళ్లు మూసుకుని లోతైన శ్వాస తీసుకోండి. అంతరంగంలో ఉన్న నిశ్శబ్దాన్ని అనుభూతి చెందండి. నిజమైన ఆనందం మన మనస్సులోనే ఉంది.',
  },
  {
    id: 'sample-devotional',
    category: 'భక్తి / ప్రవచనం',
    title: 'శ్రీ వెంకటేశ్వర వైభవం (Devotional Stotram)',
    presetStyle: 'devotional',
    recommendedStyle: 'devotional',
    text: 'ఓం నమో వేంకటేశాయ! శేషాచల శిఖరాగ్రవాసియై, భక్తుల కోరిన కోర్కెలు తీర్చే కలియుగ వైకుంఠనాథుని దివ్య సన్నిధికి కోటి ప్రణామాలు. స్వామివారి దర్శన భాగ్యం సర్వ పాపహరణం, అనంత పుణ్యప్రదం.',
  },
  {
    id: 'sample-poetry',
    category: 'పద్య పఠనం / కావ్యం',
    title: 'సుమతీ శతక పద్యం (Classical Verse)',
    presetStyle: 'poetry',
    recommendedStyle: 'poetry',
    text: 'ఉపకారికి నుపకారము విపరీతము కాదు సేయ వివరింపంగా, నపకారికి నుపకారము నెపమెన్నక సేయువాడె నేర్పరి సుమతీ! సజ్జనుల లక్షణం ఎల్లప్పుడూ ధర్మమార్గమే.',
  },
  {
    id: 'sample-dialogue',
    category: 'సంభాషణా శైలి',
    title: 'స్నేహితుల ముచ్చట (Conversational Banter)',
    presetStyle: 'dialogue',
    recommendedStyle: 'dialogue',
    text: 'నమస్కారం బాబాయ్! ఎలా ఉన్నావు? మొన్న నువ్వు చెప్పిన ఆ కొత్త టెక్నాలజీ గురించి ఆలోచిస్తున్నాను. నిజంగా అది మన వ్యవసాయానికి, వ్యాపారానికి చాలా ఉపయోగపడుతుంది కదా!',
  },
  {
    id: 'sample-sports',
    category: 'స్పోర్ట్స్ కామెంట్రీ',
    title: 'మ్యాచ్ ఉత్కంఠ (Cricket Commentary)',
    presetStyle: 'energetic',
    recommendedStyle: 'energetic',
    text: 'చివరి ఓవర్‌లో ఆరు బంతులకు పన్నెండు పరుగులు కావాలి! బౌలర్ పరుగెత్తుకుంటూ వచ్చాడు... గాల్లోకి లేచింది బంతి! బౌండరీ లైన్ దగ్గర ఫీల్డర్ పరిగెడుతున్నాడు... క్యాచ్ పట్టలేకపోయాడు! అద్భుతమైన ఫోర్!',
  },
  {
    id: 'sample-kids',
    category: 'బాలల కథలు',
    title: 'తెలివైన కుందేలు (Kids Story)',
    presetStyle: 'storytelling',
    recommendedStyle: 'storytelling',
    text: 'ఒక అందమైన అడవిలో ఒక బుల్లి కుందేలు ఉండేది. అది చాలా చురుగ్గా, అందరితో ఎంతో ప్రేమగా ఉండేది. ఒకరోజు దానికి ఒక పెద్ద బంగారు క్యారెట్ కనిపించింది. అప్పుడేం జరిగిందో తెలుసా పిల్లలూ?',
  },
  {
    id: 'sample-whisper',
    category: 'మృదు గుసగుస / ASMR',
    title: 'గాఢ నిద్ర విశ్రాంతి (Sleep Whisper)',
    presetStyle: 'whisper',
    recommendedStyle: 'whisper',
    text: 'రోజంతా పడిన శ్రమను మరిచిపోండి... నెమ్మదిగా కన్నులు మూయండి. చల్లని వెన్నెల కురుస్తోంది. మీ మనస్సులోని ఆలోచనలన్నీ మాయమైపోతున్నాయి... శుభరాత్రి.',
  },
];
