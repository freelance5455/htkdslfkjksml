import Decimal from 'decimal.js';
import type { AngleMode } from '../types/calculator';

// Configure high-precision decimal arithmetic (34 significant digits)
const CalcDecimal = Decimal.clone({
  precision: 34,
  rounding: Decimal.ROUND_HALF_UP,
  toExpNeg: -10,
  toExpPos: 14,
});

const PI = CalcDecimal.acos(-1);
const E_CONST = new CalcDecimal(1).exp();
const DEG_TO_RAD = PI.div(180);
const RAD_TO_DEG = new CalcDecimal(180).div(PI);
const ZERO = new CalcDecimal(0);
const ONE = new CalcDecimal(1);

export class CalcError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CalcError';
  }
}

type TokenType =
  | 'number'
  | 'const'
  | 'func'
  | 'op'
  | 'postfix'
  | 'lparen'
  | 'rparen';

interface Token {
  type: TokenType;
  value: string;
}

const FUNCTIONS = [
  'sin⁻¹',
  'cos⁻¹',
  'tan⁻¹',
  'asin',
  'acos',
  'atan',
  'sin',
  'cos',
  'tan',
  'log',
  'ln',
  'abs',
  'sqrt',
  'cbrt',
  '√',
  '∛',
] as const;

/**
 * Tokenizes an expression string and automatically inserts implicit multiplication
 * where mathematically standard (e.g., 2π, 3(4+5), 2sin(30), (1+2)(3+4)).
 */
export function tokenize(expr: string): Token[] {
  const rawTokens: Token[] = [];
  let i = 0;
  const len = expr.length;

  while (i < len) {
    const ch = expr[i];

    // Skip whitespace
    if (/\s/.test(ch)) {
      i++;
      continue;
    }

    // Number literal (including optional scientific E notation like 2.5E6 or 1E-4)
    if (/[0-9.]/.test(ch)) {
      let numStr = '';
      let hasDot = false;
      while (i < len && /[0-9.]/.test(expr[i])) {
        if (expr[i] === '.') {
          if (hasDot) {
            throw new CalcError('Invalid number format');
          }
          hasDot = true;
        }
        numStr += expr[i];
        i++;
      }

      if (numStr === '.') {
        throw new CalcError('Invalid decimal');
      }

      // Check for scientific notation exponent 'E'
      if (i < len && expr[i] === 'E') {
        let expPart = 'E';
        let j = i + 1;
        if (j < len && (expr[j] === '+' || expr[j] === '-' || expr[j] === '−')) {
          expPart += expr[j] === '−' ? '-' : expr[j];
          j++;
        }
        let expDigits = '';
        while (j < len && /[0-9]/.test(expr[j])) {
          expDigits += expr[j];
          j++;
        }
        if (expDigits.length === 0) {
          throw new CalcError('Incomplete exponent');
        }
        numStr += expPart + expDigits;
        i = j;
      }

      rawTokens.push({ type: 'number', value: numStr });
      continue;
    }

    // Check multi-character functions & 'mod'
    let matchedFunc: string | null = null;
    for (const fn of FUNCTIONS) {
      if (expr.startsWith(fn, i)) {
        matchedFunc = fn;
        break;
      }
    }
    if (matchedFunc) {
      rawTokens.push({ type: 'func', value: matchedFunc });
      i += matchedFunc.length;
      continue;
    }

    if (expr.startsWith('mod', i)) {
      rawTokens.push({ type: 'op', value: 'mod' });
      i += 3;
      continue;
    }

    // Constants
    if (ch === 'π') {
      rawTokens.push({ type: 'const', value: 'π' });
      i++;
      continue;
    }
    if (ch === 'e') {
      rawTokens.push({ type: 'const', value: 'e' });
      i++;
      continue;
    }

    // Parentheses
    if (ch === '(') {
      rawTokens.push({ type: 'lparen', value: '(' });
      i++;
      continue;
    }
    if (ch === ')') {
      rawTokens.push({ type: 'rparen', value: ')' });
      i++;
      continue;
    }

    // Postfix operators
    if (ch === '!' || ch === '%' || ch === '²' || ch === '³') {
      rawTokens.push({ type: 'postfix', value: ch });
      i++;
      continue;
    }

    // Binary / Unary operators
    if (ch === '+' || ch === '-' || ch === '−') {
      rawTokens.push({ type: 'op', value: ch === '−' ? '-' : ch });
      i++;
      continue;
    }
    if (ch === '×' || ch === '*') {
      rawTokens.push({ type: 'op', value: '*' });
      i++;
      continue;
    }
    if (ch === '÷' || ch === '/') {
      rawTokens.push({ type: 'op', value: '/' });
      i++;
      continue;
    }
    if (ch === '^') {
      rawTokens.push({ type: 'op', value: '^' });
      i++;
      continue;
    }

    throw new CalcError(`Unexpected symbol "${ch}"`);
  }

  // Insert implicit multiplication
  const tokens: Token[] = [];
  for (let idx = 0; idx < rawTokens.length; idx++) {
    const curr = rawTokens[idx];
    if (idx > 0) {
      const prev = rawTokens[idx - 1];
      const prevEndsValue =
        prev.type === 'number' ||
        prev.type === 'const' ||
        prev.type === 'rparen' ||
        prev.type === 'postfix';

      const currStartsValue =
        curr.type === 'const' ||
        curr.type === 'lparen' ||
        curr.type === 'func' ||
        (curr.type === 'number' &&
          (prev.type === 'const' || prev.type === 'rparen' || prev.type === 'postfix'));

      if (prevEndsValue && currStartsValue) {
        tokens.push({ type: 'op', value: '*' });
      }
    }
    tokens.push(curr);
  }

  return tokens;
}

interface EvalValue {
  val: Decimal;
  isDirectPercent: boolean;
}

function cleanDecimal(d: Decimal): Decimal {
  if (!d.isFinite()) {
    throw new CalcError('Result out of range');
  }
  if (d.abs().lt('1e-26')) {
    return ZERO;
  }
  // Round to 24 significant digits to cancel irrational/trig truncation tails (e.g. 1/3 * 3 -> 1)
  const rounded = d.toSignificantDigits(24);
  if (rounded.abs().lt('1e-24')) {
    return ZERO;
  }
  return rounded;
}

function factorialDecimal(n: Decimal): Decimal {
  if (!n.isInteger() || n.isNegative()) {
    throw new CalcError('Domain error');
  }
  const num = n.toNumber();
  if (!Number.isFinite(num) || num > 1000) {
    throw new CalcError('Overflow');
  }
  let res = ONE;
  for (let k = 2; k <= num; k++) {
    res = res.times(k);
  }
  return res;
}

class Parser {
  private pos = 0;
  constructor(
    private readonly tokens: Token[],
    private readonly angleMode: AngleMode
  ) {}

  private peek(): Token | undefined {
    return this.tokens[this.pos];
  }

  private consume(): Token {
    return this.tokens[this.pos++];
  }

  public parse(): Decimal {
    if (this.tokens.length === 0) {
      return ZERO;
    }
    const res = this.parseAddSub();
    if (this.pos < this.tokens.length) {
      throw new CalcError('Syntax error');
    }
    return cleanDecimal(res.val);
  }

  private parseAddSub(): EvalValue {
    let left = this.parseMulDivMod();

    while (true) {
      const tok = this.peek();
      if (!tok || tok.type !== 'op' || (tok.value !== '+' && tok.value !== '-')) {
        break;
      }
      this.consume();
      const right = this.parseMulDivMod();

      if (right.isDirectPercent) {
        // Smartphone calculator rule: A + B% => A + (A * B / 100)
        const delta = left.val.times(right.val);
        left = {
          val: tok.value === '+' ? left.val.plus(delta) : left.val.minus(delta),
          isDirectPercent: false,
        };
      } else {
        left = {
          val: tok.value === '+' ? left.val.plus(right.val) : left.val.minus(right.val),
          isDirectPercent: false,
        };
      }
    }

    return left;
  }

  private parseMulDivMod(): EvalValue {
    let left = this.parseUnary();

    while (true) {
      const tok = this.peek();
      if (
        !tok ||
        tok.type !== 'op' ||
        (tok.value !== '*' && tok.value !== '/' && tok.value !== 'mod')
      ) {
        break;
      }
      this.consume();
      const right = this.parseUnary();

      if (tok.value === '*') {
        left = { val: left.val.times(right.val), isDirectPercent: false };
      } else if (tok.value === '/') {
        if (right.val.isZero()) {
          throw new CalcError('Cannot divide by zero');
        }
        left = { val: left.val.div(right.val), isDirectPercent: false };
      } else {
        if (right.val.isZero()) {
          throw new CalcError('Cannot divide by zero');
        }
        // Standard mathematical modulo / remainder matching JS & calculators
        left = { val: left.val.mod(right.val), isDirectPercent: false };
      }
    }

    return left;
  }

  private parseUnary(): EvalValue {
    const tok = this.peek();
    if (tok && tok.type === 'op' && (tok.value === '+' || tok.value === '-')) {
      this.consume();
      const inner = this.parseUnary();
      return {
        val: tok.value === '-' ? inner.val.neg() : inner.val,
        isDirectPercent: inner.isDirectPercent,
      };
    }
    return this.parsePower();
  }

  private parsePower(): EvalValue {
    const base = this.parsePostfix();
    const tok = this.peek();
    if (tok && tok.type === 'op' && tok.value === '^') {
      this.consume();
      // Right-associative exponentiation, allowing unary signs in exponent (e.g. 2^-3)
      const exponent = this.parseUnary();
      if (base.val.isZero() && exponent.val.isNegative()) {
        throw new CalcError('Cannot divide by zero');
      }
      if (base.val.isNegative() && !exponent.val.isInteger()) {
        throw new CalcError('Domain error');
      }
      try {
        const result = base.val.pow(exponent.val);
        if (!result.isFinite()) {
          throw new CalcError('Overflow');
        }
        return { val: result, isDirectPercent: false };
      } catch (e) {
        if (e instanceof CalcError) throw e;
        throw new CalcError('Overflow');
      }
    }
    return base;
  }

  private parsePostfix(): EvalValue {
    let curr = this.parsePrimary();

    while (true) {
      const tok = this.peek();
      if (!tok || tok.type !== 'postfix') {
        break;
      }
      this.consume();
      if (tok.value === '!') {
        curr = { val: factorialDecimal(curr.val), isDirectPercent: false };
      } else if (tok.value === '%') {
        curr = { val: curr.val.div(100), isDirectPercent: true };
      } else if (tok.value === '²') {
        curr = { val: curr.val.pow(2), isDirectPercent: false };
      } else if (tok.value === '³') {
        curr = { val: curr.val.pow(3), isDirectPercent: false };
      }
    }

    return curr;
  }

  private parsePrimary(): EvalValue {
    const tok = this.peek();
    if (!tok) {
      throw new CalcError('Syntax error');
    }

    if (tok.type === 'number') {
      this.consume();
      try {
        return { val: new CalcDecimal(tok.value), isDirectPercent: false };
      } catch {
        throw new CalcError('Invalid number');
      }
    }

    if (tok.type === 'const') {
      this.consume();
      if (tok.value === 'π') {
        return { val: PI, isDirectPercent: false };
      }
      if (tok.value === 'e') {
        return { val: E_CONST, isDirectPercent: false };
      }
    }

    if (tok.type === 'lparen') {
      this.consume();
      if (this.peek()?.type === 'rparen') {
        throw new CalcError('Empty parentheses');
      }
      const inner = this.parseAddSub();
      const next = this.peek();
      if (next && next.type === 'rparen') {
        this.consume();
      } else {
        throw new CalcError('Missing closing parenthesis');
      }
      return { val: inner.val, isDirectPercent: inner.isDirectPercent };
    }

    if (tok.type === 'func') {
      this.consume();
      const next = this.peek();
      let arg: Decimal;

      if (next && next.type === 'lparen') {
        this.consume();
        if (this.peek()?.type === 'rparen') {
          throw new CalcError('Missing argument');
        }
        arg = this.parseAddSub().val;
        const close = this.peek();
        if (close && close.type === 'rparen') {
          this.consume();
        } else {
          throw new CalcError('Missing closing parenthesis');
        }
      } else {
        // Allow sin 30 or √9 without explicit parens
        arg = this.parseUnary().val;
      }

      return {
        val: this.evalFunction(tok.value, arg),
        isDirectPercent: false,
      };
    }

    throw new CalcError('Syntax error');
  }

  private evalFunction(name: string, arg: Decimal): Decimal {
    const toRadians = (v: Decimal) =>
      this.angleMode === 'DEG' ? v.times(DEG_TO_RAD) : v;
    const fromRadians = (v: Decimal) =>
      this.angleMode === 'DEG' ? v.times(RAD_TO_DEG) : v;

    switch (name) {
      case 'sin': {
        const rad = toRadians(arg);
        return cleanDecimal(rad.sin());
      }
      case 'cos': {
        const rad = toRadians(arg);
        return cleanDecimal(rad.cos());
      }
      case 'tan': {
        const rad = toRadians(arg);
        const cosVal = cleanDecimal(rad.cos());
        if (cosVal.isZero()) {
          throw new CalcError('Undefined');
        }
        return cleanDecimal(rad.sin().div(cosVal));
      }
      case 'sin⁻¹':
      case 'asin': {
        if (arg.lt(-1) || arg.gt(1)) {
          throw new CalcError('Domain error');
        }
        return cleanDecimal(fromRadians(arg.asin()));
      }
      case 'cos⁻¹':
      case 'acos': {
        if (arg.lt(-1) || arg.gt(1)) {
          throw new CalcError('Domain error');
        }
        return cleanDecimal(fromRadians(arg.acos()));
      }
      case 'tan⁻¹':
      case 'atan': {
        return cleanDecimal(fromRadians(arg.atan()));
      }
      case 'log': {
        if (arg.lte(0)) {
          throw new CalcError('Domain error');
        }
        return cleanDecimal(arg.log(10));
      }
      case 'ln': {
        if (arg.lte(0)) {
          throw new CalcError('Domain error');
        }
        return cleanDecimal(arg.ln());
      }
      case 'abs': {
        return arg.abs();
      }
      case '√':
      case 'sqrt': {
        if (arg.isNegative()) {
          throw new CalcError('Domain error');
        }
        return cleanDecimal(arg.sqrt());
      }
      case '∛':
      case 'cbrt': {
        return cleanDecimal(arg.cbrt());
      }
      default:
        throw new CalcError(`Unknown function "${name}"`);
    }
  }
}

/**
 * Auto-balances unclosed parentheses at the end of a user-typed expression
 * so standard smartphone inputs like `sin(30` evaluate seamlessly on `=`.
 */
export function balanceParentheses(expr: string): string {
  let openCount = 0;
  for (const ch of expr) {
    if (ch === '(') openCount++;
    else if (ch === ')') openCount = Math.max(0, openCount - 1);
  }
  return expr + ')'.repeat(openCount);
}

export function evaluateExpression(
  expression: string,
  angleMode: AngleMode
): { ok: true; value: Decimal; rawString: string } | { ok: false; error: string } {
  const trimmed = expression.trim();
  if (!trimmed) {
    return { ok: true, value: ZERO, rawString: '0' };
  }

  try {
    const balanced = balanceParentheses(trimmed);
    const tokens = tokenize(balanced);
    const parser = new Parser(tokens, angleMode);
    const val = parser.parse();
    const rawString = toRawString(val);
    return { ok: true, value: val, rawString };
  } catch (err) {
    if (err instanceof CalcError) {
      return { ok: false, error: err.message };
    }
    return { ok: false, error: 'Invalid expression' };
  }
}

/**
 * Evaluates a partial expression silently for the live preview display.
 * Returns null if the expression is incomplete or invalid while typing.
 */
export function evaluatePreview(
  expression: string,
  angleMode: AngleMode
): { value: Decimal; rawString: string } | null {
  const trimmed = expression.trim();
  if (!trimmed) return null;

  // Strip trailing incomplete binary operators for live preview
  let candidate = trimmed;
  if (/(?:[+\-−×*/÷^]|mod|E[+\-−]?)$/.test(candidate)) {
    return null;
  }

  // If expression is just a single plain number, no preview needed unless it contains % or constants
  const res = evaluateExpression(candidate, angleMode);
  if (!res.ok) return null;
  return { value: res.value, rawString: res.rawString };
}

export function toRawString(d: Decimal): string {
  const cleaned = cleanDecimal(d);
  if (cleaned.isZero()) return '0';
  // Use up to 15 significant digits for clean standard display/storage
  const sig = cleaned.toSignificantDigits(15);
  return sig.toString().replace(/e([+-]?\d+)/i, 'E$1');
}

export function formatDisplayNumber(
  rawStr: string,
  forceScientific = false
): string {
  if (!rawStr) return '0';
  let d: Decimal;
  try {
    d = new CalcDecimal(rawStr.replace(/E/g, 'e'));
  } catch {
    return rawStr;
  }

  if (d.isZero()) return '0';

  const abs = d.abs();
  const shouldUseSci =
    forceScientific || abs.gte('1e12') || abs.lt('1e-7');

  if (shouldUseSci) {
    const expStr = d.toSignificantDigits(10).toExponential();
    const [mantissa, exp] = expStr.split('e');
    const cleanMantissa = mantissa.replace(/(\.\d*?[1-9])0+$/, '$1').replace(/\.0+$/, '');
    const expNum = Number(exp);
    const signPrefix = expNum >= 0 ? '' : '−';
    return `${cleanMantissa.replace('-', '−')} × 10^${signPrefix}${Math.abs(expNum)}`;
  }

  const fixed = d.toSignificantDigits(14).toFixed();
  const [intPart, decPart] = fixed.split('.');
  const isNeg = intPart.startsWith('-');
  const unsignedInt = isNeg ? intPart.slice(1) : intPart;
  const formattedInt = unsignedInt.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const prefix = isNeg ? '−' : '';

  if (decPart !== undefined) {
    const trimmedDec = decPart.replace(/0+$/, '');
    return trimmedDec ? `${prefix}${formattedInt}.${trimmedDec}` : `${prefix}${formattedInt}`;
  }
  return `${prefix}${formattedInt}`;
}

/**
 * Converts a finite or repeating decimal into an exact reduced fraction string (e.g. "3/4" or "1 1/2")
 * using continued fractions. Returns null for integers or non-rational numbers.
 */
export function toFractionString(rawStr: string): string | null {
  let num: number;
  try {
    num = new CalcDecimal(rawStr.replace(/E/g, 'e')).toNumber();
  } catch {
    return null;
  }
  if (!Number.isFinite(num) || Number.isInteger(num) || Math.abs(num) > 1e7) {
    return null;
  }

  const sign = num < 0 ? '−' : '';
  const x = Math.abs(num);
  const tolerance = 1e-10;
  const maxDen = 100000;

  let h1 = 1;
  let h2 = 0;
  let k1 = 0;
  let k2 = 1;
  let b = x;

  for (let iter = 0; iter < 64; iter++) {
    const a = Math.floor(b);
    const auxH = h1;
    h1 = a * h1 + h2;
    h2 = auxH;
    const auxK = k1;
    k1 = a * k1 + k2;
    k2 = auxK;

    if (k1 > maxDen) {
      return null;
    }

    if (Math.abs(x - h1 / k1) <= x * tolerance + 1e-12) {
      if (k1 === 1) return null;
      const whole = Math.floor(h1 / k1);
      const rem = h1 % k1;
      if (whole > 0) {
        return `${sign}${whole} ${rem}/${k1}`;
      }
      return `${sign}${h1}/${k1}`;
    }

    const frac = b - a;
    if (frac < 1e-14) break;
    b = 1 / frac;
  }

  return null;
}

/**
 * Helper to delete the last token cleanly (e.g., deleting "sin(" or "mod" in one step).
 */
export function deleteLastToken(expr: string): string {
  if (!expr) return '';
  const multiTokens = [
    'sin⁻¹(',
    'cos⁻¹(',
    'tan⁻¹(',
    'sin(',
    'cos(',
    'tan(',
    'log(',
    'ln(',
    'abs(',
    '√(',
    '∛(',
    'mod',
    '10^(',
    'e^(',
  ];
  for (const tok of multiTokens) {
    if (expr.endsWith(tok)) {
      return expr.slice(0, -tok.length);
    }
  }
  return expr.slice(0, -1);
}

/**
 * Toggles the sign (+/-) of the trailing operand in the expression.
 */
export function toggleSignInExpression(expr: string): string {
  if (!expr) return '−';
  if (expr === '−' || expr === '-') return '';

  // Match trailing parenthesized negative like "(−123)" or "(-123.45)"
  const wrappedNegMatch = expr.match(/\([−-](\d+(?:\.\d+)?(?:E[+-]?\d+)?|π|e)\)$/);
  if (wrappedNegMatch) {
    const startIdx = expr.length - wrappedNegMatch[0].length;
    return expr.slice(0, startIdx) + wrappedNegMatch[1];
  }

  // Match whole expression being negative number e.g. "−42"
  if (/^[−-](\d+(?:\.\d+)?(?:E[+-]?\d+)?|π|e)$/.test(expr)) {
    return expr.slice(1);
  }

  // Match trailing positive number or constant
  const trailingNumMatch = expr.match(/(\d+(?:\.\d+)?(?:E[+-]?\d+)?|π|e)$/);
  if (trailingNumMatch) {
    const num = trailingNumMatch[1];
    const startIdx = expr.length - num.length;
    if (startIdx === 0) {
      return `−${num}`;
    }
    const prevChar = expr[startIdx - 1];
    if (prevChar === '(') {
      return expr.slice(0, startIdx) + `−${num}`;
    }
    return expr.slice(0, startIdx) + `(−${num})`;
  }

  // Trailing open paren or operator: insert unary minus
  if (/[+\-×÷^(]$/.test(expr) || expr.endsWith('mod')) {
    return expr + '(−';
  }

  // Fallback: negate whole expression
  if (expr.startsWith('−(') && expr.endsWith(')')) {
    return expr.slice(2, -1);
  }
  return `−(${expr})`;
}

/**
 * Applies reciprocal 1/(...) to the trailing operand or entire expression.
 */
export function applyReciprocalInExpression(expr: string): string {
  if (!expr) return '1÷(';

  // If expression ends with a parenthesized group, wrap it
  if (expr.endsWith(')')) {
    let depth = 0;
    let start = expr.length - 1;
    for (let i = expr.length - 1; i >= 0; i--) {
      if (expr[i] === ')') depth++;
      else if (expr[i] === '(') {
        depth--;
        if (depth === 0) {
          start = i;
          break;
        }
      }
    }
    // Check if there's a function name immediately before '('
    let fnStart = start;
    for (const fn of FUNCTIONS) {
      if (start >= fn.length && expr.slice(start - fn.length, start) === fn) {
        fnStart = start - fn.length;
        break;
      }
    }
    const target = expr.slice(fnStart);
    return expr.slice(0, fnStart) + `(1÷${target})`;
  }

  // Trailing number or constant
  const match = expr.match(/(\d+(?:\.\d+)?(?:E[+-]?\d+)?|π|e)$/);
  if (match) {
    const val = match[1];
    const idx = expr.length - val.length;
    return expr.slice(0, idx) + `(1÷${val})`;
  }

  return expr + '1÷(';
}

export function addToMemory(currentMemory: string, deltaRaw: string): string {
  const mem = new CalcDecimal(currentMemory.replace(/E/g, 'e') || '0');
  const delta = new CalcDecimal(deltaRaw.replace(/E/g, 'e') || '0');
  return toRawString(mem.plus(delta));
}

export function subtractFromMemory(currentMemory: string, deltaRaw: string): string {
  const mem = new CalcDecimal(currentMemory.replace(/E/g, 'e') || '0');
  const delta = new CalcDecimal(deltaRaw.replace(/E/g, 'e') || '0');
  return toRawString(mem.minus(delta));
}
