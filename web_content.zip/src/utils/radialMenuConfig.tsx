import React from "react";
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Heading1,
  Heading2,
  Heading3,
  FileText,
  List,
  ListOrdered,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Type,
  Palette,
  Highlighter,
  Mic,
  Camera,
  Paperclip,
  Network,
  Sparkles,
  PenTool,
  Eraser,
  Layers,
  Settings,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  Repeat,
  Flame,
  Heart,
  Shield,
  Zap,
  Sun,
  Contrast,
  Scissors,
  Lightbulb,
  Thermometer,
  Lock,
  Music,
  Globe,
  Mail,
  Folder,
  Image as ImageIcon,
} from "lucide-react";
import { RadialMenuTheme, RadialMenuItem, RadialMenuConfig, RadialActionType } from "../types";

export interface RadialThemePresetDef {
  id: RadialMenuTheme;
  title: string;
  subtitle: string;
  description: string;
  badge: string;
  badgeColor: string;
  centerLabel: string;
  ringBg: string;
  centerBg: string;
  glowShadow: string;
  borderColor: string;
  items: Array<{
    id: string;
    label: string;
    iconName: string;
    color: string;
    badge?: string;
  }>;
}

export const CONTEXTUAL_RADIAL_ITEMS: RadialMenuItem[] = [
  { id: "bold", label: "Kalın (B)", icon: "Bold", category: "format", isVisible: true, order: 1, color: "text-amber-500" },
  { id: "italic", label: "İtalik (I)", icon: "Italic", category: "format", isVisible: true, order: 2, color: "text-indigo-500" },
  { id: "underline", label: "Altı Çizili", icon: "Underline", category: "format", isVisible: true, order: 3, color: "text-blue-500" },
  { id: "strikethrough", label: "Üstü Çizili", icon: "Strikethrough", category: "format", isVisible: true, order: 4, color: "text-rose-500" },
  { id: "h1", label: "Başlık H1", icon: "Heading1", category: "structure", isVisible: true, order: 5, color: "text-teal-500" },
  { id: "h2", label: "Başlık H2", icon: "Heading2", category: "structure", isVisible: true, order: 6, color: "text-emerald-500" },
  { id: "ul", label: "Maddeli Liste", icon: "List", category: "structure", isVisible: true, order: 7, color: "text-cyan-500" },
  { id: "ol", label: "Numaralı Liste", icon: "ListOrdered", category: "structure", isVisible: true, order: 8, color: "text-sky-500" },
  { id: "voice-record", label: "Ses Kaydı / STT", icon: "Mic", category: "media", isVisible: true, order: 9, color: "text-rose-600", badge: "REC" },
  { id: "camera-capture", label: "Kamera / Görsel", icon: "Camera", category: "media", isVisible: true, order: 10, color: "text-purple-500" },
  { id: "attachment", label: "Dosya Ekle", icon: "Paperclip", category: "media", isVisible: true, order: 11, color: "text-slate-500" },
  { id: "ai-mindmap", label: "AI Zihin Haritası", icon: "Network", category: "ai", isVisible: true, order: 12, color: "text-amber-400", badge: "AI" },
];

export const RADIAL_THEMES: Record<RadialMenuTheme, RadialThemePresetDef> = {
  productivity: {
    id: "productivity",
    title: "Verimlilik ve Araç Paneli",
    subtitle: "Kırtasiye & Çizim Araçları",
    description: "Kalem, Silgi, Vurgulayıcı, Katmanlar ve Ayarlar içeren minimalist açık renkli daire",
    badge: "Çizim & Not",
    badgeColor: "bg-teal-500",
    centerLabel: "Araçlar",
    ringBg: "bg-white/95 dark:bg-slate-900/98 backdrop-blur-2xl",
    centerBg: "bg-gradient-to-tr from-teal-500 to-indigo-600 text-white shadow-lg",
    glowShadow: "shadow-[0_12px_36px_rgba(20,184,166,0.25)]",
    borderColor: "border-teal-500/30 dark:border-teal-400/40",
    items: [
      { id: "bold", label: "Kalın", iconName: "Bold", color: "text-amber-500" },
      { id: "italic", label: "İtalik", iconName: "Italic", color: "text-indigo-500" },
      { id: "voice-record", label: "Ses Kaydı", iconName: "Mic", color: "text-rose-500", badge: "REC" },
      { id: "camera-capture", label: "Kamera", iconName: "Camera", color: "text-purple-500" },
      { id: "ai-mindmap", label: "Zihin Haritası", iconName: "Network", color: "text-emerald-500", badge: "AI" },
    ],
  },
  media: {
    id: "media",
    title: "Medya Kontrol Tekerleği",
    subtitle: "Müzik & Ses Çalar",
    description: "Oynat/Duraklat, İleri/Geri, Ses ve Döngü içeren koyu temalı gradyan tekerlek",
    badge: "Müzik & Ses",
    badgeColor: "bg-blue-500",
    centerLabel: "Medya",
    ringBg: "bg-slate-950/95 backdrop-blur-2xl text-white",
    centerBg: "bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-500 text-white shadow-xl shadow-blue-500/30",
    glowShadow: "shadow-[0_12px_40px_rgba(37,99,235,0.4)]",
    borderColor: "border-blue-500/40",
    items: [
      { id: "voice-record", label: "Ses Kaydı", iconName: "Mic", color: "text-rose-400" },
      { id: "camera-capture", label: "Kamera", iconName: "Camera", color: "text-sky-400" },
      { id: "attachment", label: "Dosya", iconName: "Paperclip", color: "text-purple-400" },
      { id: "play_pause", label: "Oynat", iconName: "Play", color: "text-blue-400" },
      { id: "volume", label: "Ses", iconName: "Volume2", color: "text-indigo-400" },
    ],
  },
  gaming: {
    id: "gaming",
    title: "Oyun Yeteneği Seçici",
    subtitle: "Aksiyon & Büyü Çarkı",
    description: "Ateş Topu, İyileşme, Kalkan ve Atılma detaylarına sahip neonsal yetenek çarkı",
    badge: "Gamer / Neon",
    badgeColor: "bg-purple-600",
    centerLabel: "Yetenek",
    ringBg: "bg-purple-950/98 backdrop-blur-2xl text-purple-100",
    centerBg: "bg-gradient-to-tr from-purple-600 via-pink-600 to-amber-500 text-white shadow-2xl shadow-purple-500/50",
    glowShadow: "shadow-[0_0_50px_rgba(168,85,247,0.5)]",
    borderColor: "border-purple-400/50",
    items: [
      { id: "bold", label: "Kalın (MAX)", iconName: "Bold", color: "text-amber-400", badge: "MAX" },
      { id: "voice-record", label: "Ses Kaydı", iconName: "Mic", color: "text-rose-400" },
      { id: "ai-mindmap", label: "Büyü Haritası", iconName: "Network", color: "text-cyan-400" },
      { id: "camera-capture", label: "Ekran Görüntüsü", iconName: "Camera", color: "text-purple-400" },
    ],
  },
  photo: {
    id: "photo",
    title: "Fotoğraf Düzenleme Araç Çubuğu",
    subtitle: "Görsel İşleme & Filtre",
    description: "Parlaklık, Kontrast, Doygunluk ve Kırpma ayarlarına sahip ince çizgili hassas UI",
    badge: "Fotoğraf & UI",
    badgeColor: "bg-amber-600",
    centerLabel: "Düzenle",
    ringBg: "bg-neutral-900/95 backdrop-blur-2xl text-neutral-200",
    centerBg: "bg-gradient-to-tr from-amber-500 to-rose-600 text-white shadow-lg",
    glowShadow: "shadow-[0_12px_36px_rgba(245,158,11,0.3)]",
    borderColor: "border-amber-500/30",
    items: [
      { id: "camera-capture", label: "Fotoğraf Çek", iconName: "Camera", color: "text-amber-400" },
      { id: "attachment", label: "Görsel Yükle", iconName: "Paperclip", color: "text-cyan-400" },
      { id: "highlight", label: "Vurgu Rengi", iconName: "Highlighter", color: "text-rose-400" },
      { id: "text-color", label: "Yazı Rengi", iconName: "Palette", color: "text-emerald-400" },
    ],
  },
  smarthome: {
    id: "smarthome",
    title: "Akıllı Ev Kontrol Paneli",
    subtitle: "IoT & Ev Otomasyonu",
    description: "Işıklar, Termostat, Güvenlik ve Müzik kontrolleri içeren merkezi Menu yazılı arayüz",
    badge: "Akıllı Ev",
    badgeColor: "bg-emerald-600",
    centerLabel: "MENU",
    ringBg: "bg-white/95 dark:bg-slate-800/98 backdrop-blur-2xl text-slate-800 dark:text-slate-100",
    centerBg: "bg-emerald-600 text-white font-mono shadow-lg",
    glowShadow: "shadow-[0_12px_32px_rgba(16,185,129,0.25)]",
    borderColor: "border-emerald-500/40",
    items: [
      { id: "voice-record", label: "Komut Ver", iconName: "Mic", color: "text-amber-500" },
      { id: "camera-capture", label: "Güvenlik Kamerası", iconName: "Camera", color: "text-rose-500" },
      { id: "ai-mindmap", label: "Otomasyon Ağı", iconName: "Network", color: "text-emerald-500" },
      { id: "attachment", label: "Rapor Bağla", iconName: "Paperclip", color: "text-indigo-500" },
    ],
  },
  launcher: {
    id: "launcher",
    title: "Uygulama Başlatıcı Yuvası",
    subtitle: "Hızlı Kısayol Dock",
    description: "Tarayıcı, E-posta, Dosyalar ve Fotoğraflar kısayollı pürüzsüz başlatıcı",
    badge: "Dock / Apps",
    badgeColor: "bg-indigo-600",
    centerLabel: "Başlat",
    ringBg: "bg-white/95 dark:bg-slate-900/98 backdrop-blur-2xl text-slate-900 dark:text-white",
    centerBg: "bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 text-white shadow-xl shadow-purple-500/30",
    glowShadow: "shadow-[0_12px_40px_rgba(99,102,241,0.3)]",
    borderColor: "border-indigo-500/30",
    items: [
      { id: "bold", label: "Kalın", iconName: "Bold", color: "text-blue-500" },
      { id: "italic", label: "İtalik", iconName: "Italic", color: "text-rose-500" },
      { id: "voice-record", label: "Sesli Not", iconName: "Mic", color: "text-amber-500" },
      { id: "ai-mindmap", label: "AI Harita", iconName: "Network", color: "text-emerald-500" },
    ],
  },
};

export const DEFAULT_RADIAL_MENU_CONFIG: RadialMenuConfig = {
  activeTheme: "productivity",
  useLegacyMenu: false,
  position: { x: 180, y: 180 },
  scale: 1.0,
  isOpen: false,
  followCursor: false,
  idleAutoCollapse: true,
  visibleActions: {
    bold: true,
    italic: true,
    underline: true,
    strikethrough: true,
    h1: true,
    h2: true,
    ul: true,
    ol: true,
    "voice-record": true,
    "camera-capture": true,
    attachment: true,
    "ai-mindmap": true,
  },
};

const STORAGE_KEY = "noteflow_radial_menu_config_v4";

export function getStoredRadialMenuConfig(): RadialMenuConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_RADIAL_MENU_CONFIG;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_RADIAL_MENU_CONFIG,
      ...parsed,
      position: parsed.position || DEFAULT_RADIAL_MENU_CONFIG.position,
      visibleActions: {
        ...DEFAULT_RADIAL_MENU_CONFIG.visibleActions,
        ...(parsed.visibleActions || {}),
      },
    };
  } catch (e) {
    console.warn("Failed to load radial menu config:", e);
    return DEFAULT_RADIAL_MENU_CONFIG;
  }
}

export function saveStoredRadialMenuConfig(cfg: RadialMenuConfig): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
  } catch (e) {
    console.warn("Failed to save radial menu config:", e);
  }
}

/**
 * Boundary Collision Detection: Clamps position to keep the radial menu strictly inside window boundaries.
 */
export function clampRadialPosition(
  pos: { x: number; y: number },
  scale: number = 1.0,
  menuRadiusPx: number = 110
): { x: number; y: number } {
  if (typeof window === "undefined") return pos;

  const effectiveRadius = menuRadiusPx * scale + 16;
  const viewportWidth = window.innerWidth || 1024;
  const viewportHeight = window.innerHeight || 768;

  const clampedX = Math.max(effectiveRadius, Math.min(viewportWidth - effectiveRadius, pos.x));
  const clampedY = Math.max(effectiveRadius, Math.min(viewportHeight - effectiveRadius, pos.y));

  return { x: Math.round(clampedX), y: Math.round(clampedY) };
}

/**
 * Returns clean Lucide SVG icon corresponding to iconName string
 */
export function renderRadialIcon(iconName: string, className: string = "w-5 h-5"): React.ReactNode {
  switch (iconName) {
    case "Bold":
      return <Bold className={className} />;
    case "Italic":
      return <Italic className={className} />;
    case "Underline":
      return <Underline className={className} />;
    case "Strikethrough":
      return <Strikethrough className={className} />;
    case "Heading1":
      return <Heading1 className={className} />;
    case "Heading2":
      return <Heading2 className={className} />;
    case "Heading3":
      return <Heading3 className={className} />;
    case "Paragraph":
    case "FileText":
      return <FileText className={className} />;
    case "List":
      return <List className={className} />;
    case "ListOrdered":
      return <ListOrdered className={className} />;
    case "AlignLeft":
      return <AlignLeft className={className} />;
    case "AlignCenter":
      return <AlignCenter className={className} />;
    case "AlignRight":
      return <AlignRight className={className} />;
    case "Type":
      return <Type className={className} />;
    case "Palette":
      return <Palette className={className} />;
    case "Highlighter":
      return <Highlighter className={className} />;
    case "Mic":
      return <Mic className={className} />;
    case "Camera":
      return <Camera className={className} />;
    case "Paperclip":
      return <Paperclip className={className} />;
    case "Network":
      return <Network className={className} />;
    case "Sparkles":
      return <Sparkles className={className} />;
    case "PenTool":
      return <PenTool className={className} />;
    case "Eraser":
      return <Eraser className={className} />;
    case "Layers":
      return <Layers className={className} />;
    case "Settings":
      return <Settings className={className} />;
    case "Play":
      return <Play className={className} />;
    case "Pause":
      return <Pause className={className} />;
    case "SkipForward":
      return <SkipForward className={className} />;
    case "SkipBack":
      return <SkipBack className={className} />;
    case "Volume2":
      return <Volume2 className={className} />;
    case "Repeat":
      return <Repeat className={className} />;
    case "Flame":
      return <Flame className={className} />;
    case "Heart":
      return <Heart className={className} />;
    case "Shield":
      return <Shield className={className} />;
    case "Zap":
      return <Zap className={className} />;
    case "Sun":
      return <Sun className={className} />;
    case "Contrast":
      return <Contrast className={className} />;
    case "Scissors":
      return <Scissors className={className} />;
    case "Lightbulb":
      return <Lightbulb className={className} />;
    case "Thermometer":
      return <Thermometer className={className} />;
    case "Lock":
      return <Lock className={className} />;
    case "Music":
      return <Music className={className} />;
    case "Globe":
      return <Globe className={className} />;
    case "Mail":
      return <Mail className={className} />;
    case "Folder":
      return <Folder className={className} />;
    case "ImageIcon":
      return <ImageIcon className={className} />;
    default:
      return <Sparkles className={className} />;
  }
}

// Compatibility Aliases
export type RadialMenuStyleId = RadialMenuTheme;
export type RadialStyleDefinition = RadialThemePresetDef;
export const RADIAL_MENU_STYLES = RADIAL_THEMES;
export function getToolIcon(iconName: string): React.ReactNode {
  return renderRadialIcon(iconName);
}
export const RadialMenuController = {
  getStyle: () => getStoredRadialMenuConfig().activeTheme,
  setStyle: (style: RadialMenuTheme) => {
    const cfg = getStoredRadialMenuConfig();
    saveStoredRadialMenuConfig({ ...cfg, activeTheme: style });
  },
};
export const ALL_AVAILABLE_TOOLS: any[] = [];
