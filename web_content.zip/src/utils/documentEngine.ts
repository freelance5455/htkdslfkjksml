import {
  Document,
  Paragraph,
  TextRun,
  Table,
  TableRow,
  TableCell,
  WidthType,
  AlignmentType,
  HeadingLevel,
  Packer,
  Header,
  Footer,
  PageNumber,
  NumberFormat,
  convertInchesToTwip,
  BorderStyle
} from 'docx';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { jsPDF } from 'jspdf';
import {
  DocumentStyleSettings,
  DocumentTemplateId,
  DocumentSection,
  PageSize,
  PageOrientation
} from '../types';

export const SUPPORTED_FONTS = [
  { name: 'Times New Roman', category: 'Serif', description: 'Academic & Legal Standard' },
  { name: 'Arial', category: 'Sans-Serif', description: 'Clean & Universally Readable' },
  { name: 'Calibri', category: 'Sans-Serif', description: 'Modern Business Classic' },
  { name: 'Aptos', category: 'Sans-Serif', description: 'Contemporary Corporate' },
  { name: 'Georgia', category: 'Serif', description: 'Warm & High-Readability Editorial' },
  { name: 'Garamond', category: 'Serif', description: 'Timeless Elegant Literary' },
  { name: 'Cambria', category: 'Serif', description: 'Clear On-Screen & Print Serif' },
  { name: 'Verdana', category: 'Sans-Serif', description: 'Wide & Ultra-Legible' },
  { name: 'Tahoma', category: 'Sans-Serif', description: 'Compact Modern Technical' },
  { name: 'Trebuchet MS', category: 'Sans-Serif', description: 'Friendly Dynamic Sans' },
  { name: 'Courier New', category: 'Monospace', description: 'Precise Code & Form Data' },
  { name: 'Roboto', category: 'Material', description: 'Android Material 3 Modern' },
  { name: 'Inter', category: 'Modern', description: 'Ultra-Crisp UI & Documents' },
  { name: 'Lora', category: 'Serif', description: 'Contemporary Book Typography' },
  { name: 'Merriweather', category: 'Serif', description: 'Pleasant Long-form Reading' }
];

export const TEMPLATE_PRESETS: Record<DocumentTemplateId, {
  name: string;
  description: string;
  settings: Partial<DocumentStyleSettings>;
  sampleSections: DocumentSection[];
}> = {
  academic: {
    name: 'Academic Research (APA/MLA)',
    description: 'Double-spaced serif formatting with first-line indentation and standard references layout.',
    settings: {
      templateId: 'academic',
      fontFamily: 'Times New Roman',
      headingFont: 'Times New Roman',
      bodySize: 12,
      headingSize: 14,
      lineSpacing: 2.0,
      paragraphSpacing: 0,
      indentFirstLine: true,
      alignment: 'left',
      pageSize: 'A4',
      orientation: 'portrait',
      margins: { top: 1.0, bottom: 1.0, left: 1.0, right: 1.0 },
      includePageNumbers: true,
      pageNumberPosition: 'top-right',
      headerText: 'RUNNING HEAD: ACADEMIC INQUIRY',
      footerText: '',
      accentColor: '#1A365D'
    },
    sampleSections: [
      { id: '1', type: 'heading', content: 'Cognitive Architecture and Document Processing', level: 1 },
      { id: '2', type: 'subheading', content: 'Abstract and Theoretical Grounding', level: 2 },
      { id: '3', type: 'paragraph', content: 'Modern mobile document engineering necessitates robust client-side synthesis and lossless semantic extraction. Through synchronized layout heuristics, digital documents maintain compositional integrity across divergent rendering targets.' },
      { id: '4', type: 'subheading', content: 'Empirical Findings and Cross-Platform Benchmarks', level: 2 },
      { id: '5', type: 'bullet_list', content: 'High-precision optical character recognition with glyph confidence filtering\nDeterministic document pagination with widow/orphan suppression\nSeamless vector and bitmap asset embedding with boundary containment' },
      { id: '6', type: 'quote', content: 'The fidelity of reconstructed typography reflects the rigor of the underlying layout parser.' },
      { id: '7', type: 'heading', content: 'Comparative Metrics Table', level: 2 },
      { id: '8', type: 'table', content: 'Metric | Baseline | DocuForge Optimized\nLatency (ms) | 1250 | 320\nOCR Accuracy | 92.4% | 98.7%\nMemory Overhead | 142MB | 48MB' }
    ]
  },
  business: {
    name: 'Executive Business Proposal',
    description: 'Crisp corporate layout with Aptos headers, Calibri body, and brand accent styling.',
    settings: {
      templateId: 'business',
      fontFamily: 'Calibri',
      headingFont: 'Aptos',
      bodySize: 11,
      headingSize: 18,
      lineSpacing: 1.15,
      paragraphSpacing: 10,
      indentFirstLine: false,
      alignment: 'left',
      pageSize: 'A4',
      orientation: 'portrait',
      margins: { top: 1.0, bottom: 1.0, left: 1.0, right: 1.0 },
      includePageNumbers: true,
      pageNumberPosition: 'bottom-right',
      headerText: 'DocuForge Enterprise Solutions',
      footerText: 'Confidential & Proprietary',
      accentColor: '#005FB8'
    },
    sampleSections: [
      { id: '1', type: 'heading', content: 'Enterprise Document Transformation Strategy', level: 1 },
      { id: '2', type: 'paragraph', content: 'This strategic initiative unifies mobile document acquisition, automated OCR reconstruction, and high-fidelity file synthesis into a zero-compromise executive workflow.' },
      { id: '3', type: 'subheading', content: 'Key Deliverables and Outcomes', level: 2 },
      { id: '4', type: 'numbered_list', content: 'Unified conversion pipeline across DOCX, PDF, and high-res imagery\nOn-device confidential processing preserving customer data privacy\nInstant AI formatting assistance with zero hallucination guarantee' },
      { id: '5', type: 'heading', content: 'Quarterly Milestone Projections', level: 2 },
      { id: '6', type: 'table', content: 'Quarter | Objective | Target Status\nQ1 | Mobile OCR & Engine Architecture | Complete\nQ2 | Cross-Format Merging Suite | Production Ready\nQ3 | AI Formatting Assistant Integration | Active' }
    ]
  },
  report: {
    name: 'Technical & Financial Report',
    description: 'Structured report format featuring Georgia body, Arial headings, and spacious table layouts.',
    settings: {
      templateId: 'report',
      fontFamily: 'Georgia',
      headingFont: 'Arial',
      bodySize: 11,
      headingSize: 20,
      lineSpacing: 1.25,
      paragraphSpacing: 12,
      indentFirstLine: false,
      alignment: 'left',
      pageSize: 'A4',
      orientation: 'portrait',
      margins: { top: 1.0, bottom: 1.0, left: 1.0, right: 1.0 },
      includePageNumbers: true,
      pageNumberPosition: 'bottom-center',
      headerText: 'Annual Performance & Technical Audit',
      footerText: 'DocuForge Systems',
      accentColor: '#0F766E'
    },
    sampleSections: [
      { id: '1', type: 'heading', content: 'Annual System Audit & Throughput Evaluation', level: 1 },
      { id: '2', type: 'subheading', content: 'Executive Summary', level: 2 },
      { id: '3', type: 'paragraph', content: 'Operational efficiency rose substantially following the implementation of local OCR execution and streaming document pagination. Processing latencies dropped by 68% while maintaining zero memory leaks under intensive file-merging workloads.' }
    ]
  },
  letter: {
    name: 'Formal Correspondence Letter',
    description: 'Classic single-column letterhead with Garamond typography and elegant margins.',
    settings: {
      templateId: 'letter',
      fontFamily: 'Garamond',
      headingFont: 'Garamond',
      bodySize: 12,
      headingSize: 16,
      lineSpacing: 1.15,
      paragraphSpacing: 14,
      indentFirstLine: false,
      alignment: 'left',
      pageSize: 'Letter',
      orientation: 'portrait',
      margins: { top: 1.25, bottom: 1.25, left: 1.0, right: 1.0 },
      includePageNumbers: false,
      pageNumberPosition: 'bottom-center',
      headerText: '',
      footerText: '',
      accentColor: '#374151'
    },
    sampleSections: [
      { id: '1', type: 'heading', content: 'DocuForge Studio', level: 1 },
      { id: '2', type: 'paragraph', content: 'November 8, 2026\n\nDear Colleague,\n\nI am pleased to present the latest release of our document processing environment. With native Android Material 3 design patterns and genuine document transformation pipelines, users can convert, merge, and format documents with complete confidence.\n\nPlease review the accompanying documentation and let us know your feedback.\n\nSincerely,\n\nThe Engineering Team' }
    ]
  },
  notes: {
    name: 'Structured Meeting & Study Notes',
    description: 'Clean Verdana layout tailored for actionable lists, key takeaways, and rapid scannability.',
    settings: {
      templateId: 'notes',
      fontFamily: 'Verdana',
      headingFont: 'Verdana',
      bodySize: 10.5,
      headingSize: 16,
      lineSpacing: 1.3,
      paragraphSpacing: 8,
      indentFirstLine: false,
      alignment: 'left',
      pageSize: 'A4',
      orientation: 'portrait',
      margins: { top: 0.8, bottom: 0.8, left: 0.8, right: 0.8 },
      includePageNumbers: true,
      pageNumberPosition: 'bottom-right',
      headerText: 'Meeting Notes & Action Items',
      footerText: 'DocuForge Workspace',
      accentColor: '#7C3AED'
    },
    sampleSections: [
      { id: '1', type: 'heading', content: 'Sprint Review & Architecture Session', level: 1 },
      { id: '2', type: 'subheading', content: 'Key Takeaways', level: 2 },
      { id: '3', type: 'bullet_list', content: 'Completed OCR multi-language model loading with local caching\nOptimized canvas background removal with color threshold adjustment\nIntegrated drag-and-drop file merging sequence engine' }
    ]
  },
  general: {
    name: 'Clean Universal Document',
    description: 'Balanced modern document template suitable for general writing, articles, and documentation.',
    settings: {
      templateId: 'general',
      fontFamily: 'Arial',
      headingFont: 'Arial',
      bodySize: 11,
      headingSize: 18,
      lineSpacing: 1.2,
      paragraphSpacing: 8,
      indentFirstLine: false,
      alignment: 'left',
      pageSize: 'A4',
      orientation: 'portrait',
      margins: { top: 1.0, bottom: 1.0, left: 1.0, right: 1.0 },
      includePageNumbers: true,
      pageNumberPosition: 'bottom-center',
      headerText: '',
      footerText: '',
      accentColor: '#2563EB'
    },
    sampleSections: [
      { id: '1', type: 'heading', content: 'Document Title', level: 1 },
      { id: '2', type: 'paragraph', content: 'Start typing or paste your content here. Use the formatting controls above to customize fonts, margins, headers, and templates.' }
    ]
  }
};

export const DEFAULT_STYLE_SETTINGS: DocumentStyleSettings = {
  title: 'Untitled Document',
  templateId: 'general',
  fontFamily: 'Arial',
  headingFont: 'Arial',
  bodySize: 11,
  headingSize: 18,
  lineSpacing: 1.2,
  paragraphSpacing: 8,
  indentFirstLine: false,
  alignment: 'left',
  pageSize: 'A4',
  orientation: 'portrait',
  margins: { top: 1.0, bottom: 1.0, left: 1.0, right: 1.0 },
  includePageNumbers: true,
  pageNumberPosition: 'bottom-center',
  headerText: '',
  footerText: '',
  accentColor: '#2563EB'
};

// Dimensions in Points (72 pt = 1 inch)
export const PAGE_DIMENSIONS_PT: Record<PageSize, { width: number; height: number }> = {
  A4: { width: 595.28, height: 841.89 },
  Letter: { width: 612.0, height: 792.0 },
  Legal: { width: 612.0, height: 1008.0 }
};

export function getEffectivePageDimensions(pageSize: PageSize, orientation: PageOrientation) {
  const base = PAGE_DIMENSIONS_PT[pageSize] || PAGE_DIMENSIONS_PT.A4;
  if (orientation === 'landscape') {
    return { width: base.height, height: base.width };
  }
  return { width: base.width, height: base.height };
}

// Convert alignment string to docx AlignmentType
function getDocxAlignment(align: string): (typeof AlignmentType)[keyof typeof AlignmentType] {
  switch (align) {
    case 'center':
      return AlignmentType.CENTER;
    case 'right':
      return AlignmentType.RIGHT;
    case 'justify':
      return AlignmentType.JUSTIFIED;
    default:
      return AlignmentType.LEFT;
  }
}

// Generate real .docx file blob using the `docx` package
export async function generateDocxBlob(
  title: string,
  sections: DocumentSection[],
  settings: DocumentStyleSettings
): Promise<Blob> {
  const orientationVal = settings.orientation === 'landscape' ? 'landscape' : 'portrait';
  const dims = getEffectivePageDimensions(settings.pageSize, settings.orientation);

  const docChildren: any[] = [];

  // Title if provided
  if (title && title.trim()) {
    docChildren.push(
      new Paragraph({
        text: title,
        heading: HeadingLevel.TITLE,
        alignment: getDocxAlignment(settings.alignment),
        spacing: { after: 240 }
      })
    );
  }

  // Iterate sections
  for (const section of sections) {
    const rawContent = section.content || '';

    switch (section.type) {
      case 'heading': {
        docChildren.push(
          new Paragraph({
            heading: section.level === 2 ? HeadingLevel.HEADING_2 : HeadingLevel.HEADING_1,
            alignment: getDocxAlignment(settings.alignment),
            spacing: { before: 240, after: 120 },
            children: [
              new TextRun({
                text: rawContent,
                bold: true,
                font: settings.headingFont || settings.fontFamily,
                size: (settings.headingSize || 18) * 2, // docx uses half-points
                color: settings.accentColor.replace('#', '')
              })
            ]
          })
        );
        break;
      }

      case 'subheading': {
        docChildren.push(
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            alignment: getDocxAlignment(settings.alignment),
            spacing: { before: 180, after: 80 },
            children: [
              new TextRun({
                text: rawContent,
                bold: true,
                font: settings.headingFont || settings.fontFamily,
                size: Math.round((settings.headingSize || 18) * 1.5),
                color: '333333'
              })
            ]
          })
        );
        break;
      }

      case 'bullet_list': {
        const items = rawContent.split('\n').filter(l => l.trim().length > 0);
        for (const item of items) {
          docChildren.push(
            new Paragraph({
              bullet: { level: 0 },
              alignment: getDocxAlignment(settings.alignment),
              spacing: { after: Math.round(settings.paragraphSpacing * 10) },
              children: [
                new TextRun({
                  text: item.replace(/^[-*•]\s*/, ''),
                  font: settings.fontFamily,
                  size: settings.bodySize * 2
                })
              ]
            })
          );
        }
        break;
      }

      case 'numbered_list': {
        const items = rawContent.split('\n').filter(l => l.trim().length > 0);
        items.forEach((item, idx) => {
          docChildren.push(
            new Paragraph({
              alignment: getDocxAlignment(settings.alignment),
              spacing: { after: Math.round(settings.paragraphSpacing * 10) },
              children: [
                new TextRun({
                  text: `${idx + 1}. `,
                  bold: true,
                  font: settings.fontFamily,
                  size: settings.bodySize * 2
                }),
                new TextRun({
                  text: item.replace(/^\d+\.\s*/, ''),
                  font: settings.fontFamily,
                  size: settings.bodySize * 2
                })
              ]
            })
          );
        });
        break;
      }

      case 'quote': {
        docChildren.push(
          new Paragraph({
            alignment: getDocxAlignment(settings.alignment),
            indent: { left: convertInchesToTwip(0.5), right: convertInchesToTwip(0.5) },
            spacing: { before: 120, after: 120 },
            children: [
              new TextRun({
                text: `"${rawContent}"`,
                italics: true,
                font: settings.fontFamily,
                size: settings.bodySize * 2,
                color: '555555'
              })
            ]
          })
        );
        break;
      }

      case 'table': {
        const rows = rawContent.split('\n').filter(r => r.trim().length > 0);
        const tableRows: TableRow[] = [];

        rows.forEach((rowStr, rowIndex) => {
          const cells = rowStr.split('|').map(c => c.trim()).filter(c => c.length > 0);
          if (cells.length === 0) return;

          const isHeader = rowIndex === 0;
          tableRows.push(
            new TableRow({
              children: cells.map(cellText => (
                new TableCell({
                  width: { size: Math.round(100 / cells.length), type: WidthType.PERCENTAGE },
                  shading: isHeader ? { fill: 'F3F4F6' } : undefined,
                  margins: { top: 120, bottom: 120, left: 160, right: 160 },
                  children: [
                    new Paragraph({
                      children: [
                        new TextRun({
                          text: cellText,
                          bold: isHeader,
                          font: settings.fontFamily,
                          size: (settings.bodySize - (isHeader ? 0 : 1)) * 2
                        })
                      ]
                    })
                  ]
                })
              ))
            })
          );
        });

        if (tableRows.length > 0) {
          docChildren.push(
            new Table({
              rows: tableRows,
              width: { size: 100, type: WidthType.PERCENTAGE }
            })
          );
          // Add spacing after table
          docChildren.push(new Paragraph({ spacing: { after: 180 } }));
        }
        break;
      }

      case 'page_break': {
        docChildren.push(
          new Paragraph({
            pageBreakBefore: true
          })
        );
        break;
      }

      case 'paragraph':
      default: {
        const pLines = rawContent.split('\n');
        for (const pl of pLines) {
          docChildren.push(
            new Paragraph({
              alignment: getDocxAlignment(settings.alignment),
              indent: settings.indentFirstLine ? { firstLine: convertInchesToTwip(0.5) } : undefined,
              spacing: {
                line: Math.round(settings.lineSpacing * 240),
                after: Math.round(settings.paragraphSpacing * 20)
              },
              children: [
                new TextRun({
                  text: pl,
                  font: settings.fontFamily,
                  size: settings.bodySize * 2
                })
              ]
            })
          );
        }
        break;
      }
    }
  }

  // Header and Footer config
  const headerObj = settings.headerText
    ? new Header({
        children: [
          new Paragraph({
            alignment: AlignmentType.RIGHT,
            children: [
              new TextRun({
                text: settings.headerText,
                font: settings.fontFamily,
                size: 18,
                color: '888888'
              })
            ]
          })
        ]
      })
    : undefined;

  const footerChildren: any[] = [];
  if (settings.footerText) {
    footerChildren.push(
      new TextRun({
        text: settings.footerText + '   ',
        font: settings.fontFamily,
        size: 18,
        color: '888888'
      })
    );
  }

  if (settings.includePageNumbers) {
    footerChildren.push(
      new TextRun({
        children: ['Page ', PageNumber.CURRENT, ' of ', PageNumber.TOTAL_PAGES],
        font: settings.fontFamily,
        size: 18,
        color: '888888'
      })
    );
  }

  const footerObj = footerChildren.length > 0
    ? new Footer({
        children: [
          new Paragraph({
            alignment: settings.pageNumberPosition === 'bottom-right' ? AlignmentType.RIGHT : AlignmentType.CENTER,
            children: footerChildren
          })
        ]
      })
    : undefined;

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            size: {
              width: convertInchesToTwip(dims.width / 72),
              height: convertInchesToTwip(dims.height / 72),
              orientation: orientationVal as any
            },
            margin: {
              top: convertInchesToTwip(settings.margins.top),
              bottom: convertInchesToTwip(settings.margins.bottom),
              left: convertInchesToTwip(settings.margins.left),
              right: convertInchesToTwip(settings.margins.right)
            }
          }
        },
        headers: headerObj ? { default: headerObj } : undefined,
        footers: footerObj ? { default: footerObj } : undefined,
        children: docChildren
      }
    ]
  });

  const blob = await Packer.toBlob(doc);
  return blob;
}

// Generate real .pdf file blob using pdf-lib
export async function generatePdfBlob(
  title: string,
  sections: DocumentSection[],
  settings: DocumentStyleSettings
): Promise<Blob> {
  const pdfDoc = await PDFDocument.create();

  // Pick Standard Font based on style
  let bodyFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
  let boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  let italicFont = await pdfDoc.embedFont(StandardFonts.HelveticaOblique);

  const lowerFont = (settings.fontFamily || '').toLowerCase();
  if (lowerFont.includes('times') || lowerFont.includes('georgia') || lowerFont.includes('garamond') || lowerFont.includes('cambria') || lowerFont.includes('serif') || lowerFont.includes('lora') || lowerFont.includes('merriweather')) {
    bodyFont = await pdfDoc.embedFont(StandardFonts.TimesRoman);
    boldFont = await pdfDoc.embedFont(StandardFonts.TimesRomanBold);
    italicFont = await pdfDoc.embedFont(StandardFonts.TimesRomanItalic);
  } else if (lowerFont.includes('courier') || lowerFont.includes('mono')) {
    bodyFont = await pdfDoc.embedFont(StandardFonts.Courier);
    boldFont = await pdfDoc.embedFont(StandardFonts.CourierBold);
    italicFont = await pdfDoc.embedFont(StandardFonts.CourierOblique);
  }

  const dims = getEffectivePageDimensions(settings.pageSize, settings.orientation);
  const pageWidth = dims.width;
  const pageHeight = dims.height;

  const marginLeft = settings.margins.left * 72;
  const marginRight = settings.margins.right * 72;
  const marginTop = settings.margins.top * 72;
  const marginBottom = settings.margins.bottom * 72;
  const contentWidth = pageWidth - marginLeft - marginRight;

  let currentPage = pdfDoc.addPage([pageWidth, pageHeight]);
  let currentY = pageHeight - marginTop;

  const checkPageOverflow = (requiredHeight: number) => {
    if (currentY - requiredHeight < marginBottom) {
      currentPage = pdfDoc.addPage([pageWidth, pageHeight]);
      currentY = pageHeight - marginTop;
      return true;
    }
    return false;
  };

  // Helper to wrap text into lines
  const wrapText = (text: string, font: any, size: number, maxWidth: number): string[] => {
    const words = text.split(' ');
    const lines: string[] = [];
    let currentLine = '';

    for (const word of words) {
      const testLine = currentLine ? `${currentLine} ${word}` : word;
      const width = font.widthOfTextAtSize(testLine, size);
      if (width <= maxWidth) {
        currentLine = testLine;
      } else {
        if (currentLine) lines.push(currentLine);
        currentLine = word;
      }
    }
    if (currentLine) lines.push(currentLine);
    return lines.length > 0 ? lines : [''];
  };

  // Parse accent color hex to RGB 0-1
  const parseHex = (hex: string) => {
    const clean = hex.replace('#', '');
    const r = parseInt(clean.substring(0, 2) || '00', 16) / 255;
    const g = parseInt(clean.substring(2, 4) || '00', 16) / 255;
    const b = parseInt(clean.substring(4, 6) || '00', 16) / 255;
    return rgb(r, g, b);
  };

  const accentColorRgb = parseHex(settings.accentColor || '#1972E8');

  // Title if provided
  if (title && title.trim()) {
    const titleLines = wrapText(title, boldFont, settings.headingSize + 4, contentWidth);
    for (const tl of titleLines) {
      checkPageOverflow(settings.headingSize + 8);
      currentPage.drawText(tl, {
        x: marginLeft,
        y: currentY - (settings.headingSize + 4),
        size: settings.headingSize + 4,
        font: boldFont,
        color: accentColorRgb
      });
      currentY -= (settings.headingSize + 10);
    }
    currentY -= 12; // spacing after title
  }

  // Iterate sections
  for (const section of sections) {
    const content = section.content || '';

    switch (section.type) {
      case 'heading': {
        const lines = wrapText(content, boldFont, settings.headingSize, contentWidth);
        checkPageOverflow(lines.length * (settings.headingSize + 6) + 16);
        currentY -= 14;
        for (const line of lines) {
          currentPage.drawText(line, {
            x: marginLeft,
            y: currentY - settings.headingSize,
            size: settings.headingSize,
            font: boldFont,
            color: accentColorRgb
          });
          currentY -= (settings.headingSize + 4);
        }
        currentY -= 8;
        break;
      }

      case 'subheading': {
        const subSize = Math.max(12, settings.headingSize - 3);
        const lines = wrapText(content, boldFont, subSize, contentWidth);
        checkPageOverflow(lines.length * (subSize + 4) + 12);
        currentY -= 10;
        for (const line of lines) {
          currentPage.drawText(line, {
            x: marginLeft,
            y: currentY - subSize,
            size: subSize,
            font: boldFont,
            color: rgb(0.2, 0.2, 0.2)
          });
          currentY -= (subSize + 4);
        }
        currentY -= 6;
        break;
      }

      case 'bullet_list': {
        const items = content.split('\n').filter(i => i.trim());
        for (const item of items) {
          const cleanItem = item.replace(/^[-*•]\s*/, '');
          const lines = wrapText(cleanItem, bodyFont, settings.bodySize, contentWidth - 16);
          checkPageOverflow(lines.length * (settings.bodySize * settings.lineSpacing) + 4);
          
          currentPage.drawText('•', {
            x: marginLeft + 4,
            y: currentY - settings.bodySize,
            size: settings.bodySize,
            font: boldFont,
            color: accentColorRgb
          });

          for (let li = 0; li < lines.length; li++) {
            currentPage.drawText(lines[li], {
              x: marginLeft + 16,
              y: currentY - settings.bodySize,
              size: settings.bodySize,
              font: bodyFont,
              color: rgb(0.1, 0.1, 0.1)
            });
            currentY -= (settings.bodySize * settings.lineSpacing);
          }
          currentY -= settings.paragraphSpacing;
        }
        break;
      }

      case 'numbered_list': {
        const items = content.split('\n').filter(i => i.trim());
        items.forEach((item, idx) => {
          const cleanItem = item.replace(/^\d+\.\s*/, '');
          const prefix = `${idx + 1}. `;
          const lines = wrapText(cleanItem, bodyFont, settings.bodySize, contentWidth - 20);
          checkPageOverflow(lines.length * (settings.bodySize * settings.lineSpacing) + 4);

          currentPage.drawText(prefix, {
            x: marginLeft,
            y: currentY - settings.bodySize,
            size: settings.bodySize,
            font: boldFont,
            color: accentColorRgb
          });

          for (let li = 0; li < lines.length; li++) {
            currentPage.drawText(lines[li], {
              x: marginLeft + 20,
              y: currentY - settings.bodySize,
              size: settings.bodySize,
              font: bodyFont,
              color: rgb(0.1, 0.1, 0.1)
            });
            currentY -= (settings.bodySize * settings.lineSpacing);
          }
          currentY -= settings.paragraphSpacing;
        });
        break;
      }

      case 'quote': {
        const lines = wrapText(`"${content}"`, italicFont, settings.bodySize, contentWidth - 32);
        checkPageOverflow(lines.length * (settings.bodySize * settings.lineSpacing) + 12);
        currentY -= 6;
        
        // Draw decorative left quote bar
        currentPage.drawLine({
          start: { x: marginLeft + 8, y: currentY },
          end: { x: marginLeft + 8, y: currentY - (lines.length * settings.bodySize * 1.3) },
          thickness: 2.5,
          color: accentColorRgb
        });

        for (const line of lines) {
          currentPage.drawText(line, {
            x: marginLeft + 20,
            y: currentY - settings.bodySize,
            size: settings.bodySize,
            font: italicFont,
            color: rgb(0.3, 0.3, 0.3)
          });
          currentY -= (settings.bodySize * settings.lineSpacing);
        }
        currentY -= 10;
        break;
      }

      case 'table': {
        const rows = content.split('\n').filter(r => r.trim());
        if (rows.length === 0) break;

        const parsedRows = rows.map(r => r.split('|').map(c => c.trim()).filter(c => c.length > 0));
        const maxCols = Math.max(...parsedRows.map(r => r.length));
        if (maxCols === 0) break;

        const colWidth = contentWidth / maxCols;
        const rowHeight = 22;

        checkPageOverflow(parsedRows.length * rowHeight + 12);

        parsedRows.forEach((row, rIdx) => {
          const isHeader = rIdx === 0;
          const y = currentY - rowHeight;

          // Background fill for header
          if (isHeader) {
            currentPage.drawRectangle({
              x: marginLeft,
              y: y,
              width: contentWidth,
              height: rowHeight,
              color: rgb(0.93, 0.94, 0.96)
            });
          }

          // Cell contents and borders
          row.forEach((cellText, cIdx) => {
            const cellX = marginLeft + (cIdx * colWidth);
            
            // Text inside cell
            currentPage.drawText(cellText.slice(0, 30), {
              x: cellX + 6,
              y: y + 6,
              size: settings.bodySize - 1,
              font: isHeader ? boldFont : bodyFont,
              color: isHeader ? rgb(0.1, 0.1, 0.1) : rgb(0.25, 0.25, 0.25)
            });

            // Cell border
            currentPage.drawRectangle({
              x: cellX,
              y: y,
              width: colWidth,
              height: rowHeight,
              borderWidth: 0.5,
              borderColor: rgb(0.8, 0.8, 0.8),
              color: undefined
            });
          });

          currentY -= rowHeight;
        });

        currentY -= 12;
        break;
      }

      case 'page_break': {
        currentPage = pdfDoc.addPage([pageWidth, pageHeight]);
        currentY = pageHeight - marginTop;
        break;
      }

      case 'paragraph':
      default: {
        const paragraphs = content.split('\n');
        for (const p of paragraphs) {
          if (!p.trim()) {
            currentY -= 8;
            continue;
          }
          const indent = settings.indentFirstLine ? 24 : 0;
          const lines = wrapText(p, bodyFont, settings.bodySize, contentWidth - indent);
          
          for (let li = 0; li < lines.length; li++) {
            checkPageOverflow(settings.bodySize * settings.lineSpacing);
            const lineX = (li === 0 && settings.indentFirstLine) ? marginLeft + indent : marginLeft;
            
            currentPage.drawText(lines[li], {
              x: lineX,
              y: currentY - settings.bodySize,
              size: settings.bodySize,
              font: bodyFont,
              color: rgb(0.1, 0.1, 0.1)
            });
            currentY -= (settings.bodySize * settings.lineSpacing);
          }
          currentY -= settings.paragraphSpacing;
        }
        break;
      }
    }
  }

  // Draw Headers and Footers across all created pages
  const totalPages = pdfDoc.getPageCount();
  for (let pIdx = 0; pIdx < totalPages; pIdx++) {
    const page = pdfDoc.getPage(pIdx);

    // Top Header
    if (settings.headerText) {
      const headerWidth = bodyFont.widthOfTextAtSize(settings.headerText, 8.5);
      page.drawText(settings.headerText, {
        x: pageWidth - marginRight - headerWidth,
        y: pageHeight - (marginTop / 2),
        size: 8.5,
        font: bodyFont,
        color: rgb(0.5, 0.5, 0.5)
      });
      page.drawLine({
        start: { x: marginLeft, y: pageHeight - (marginTop / 2) - 4 },
        end: { x: pageWidth - marginRight, y: pageHeight - (marginTop / 2) - 4 },
        thickness: 0.5,
        color: rgb(0.85, 0.85, 0.85)
      });
    }

    // Bottom Footer
    if (settings.footerText) {
      page.drawText(settings.footerText, {
        x: marginLeft,
        y: marginBottom / 2,
        size: 8.5,
        font: bodyFont,
        color: rgb(0.5, 0.5, 0.5)
      });
    }

    // Page Number
    if (settings.includePageNumbers) {
      const pageStr = `Page ${pIdx + 1} of ${totalPages}`;
      const pageStrWidth = bodyFont.widthOfTextAtSize(pageStr, 8.5);
      const pageNumX = settings.pageNumberPosition === 'bottom-right'
        ? pageWidth - marginRight - pageStrWidth
        : (pageWidth - pageStrWidth) / 2;

      page.drawText(pageStr, {
        x: pageNumX,
        y: marginBottom / 2,
        size: 8.5,
        font: bodyFont,
        color: rgb(0.5, 0.5, 0.5)
      });
    }
  }

  const pdfBytes = await pdfDoc.save();
  return new Blob([pdfBytes as any], { type: 'application/pdf' });
}

// Generate PDF blob using jsPDF library with formatting preservation
export async function generatePdfBlobWithJsPdf(
  title: string,
  sections: DocumentSection[],
  settings: DocumentStyleSettings
): Promise<Blob> {
  const orientation = settings.orientation === 'landscape' ? 'landscape' : 'portrait';
  const format = settings.pageSize === 'Letter' ? 'letter' : settings.pageSize === 'Legal' ? 'legal' : 'a4';

  const doc = new jsPDF({
    orientation,
    unit: 'pt',
    format
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginLeft = settings.margins.left * 72;
  const marginRight = settings.margins.right * 72;
  const marginTop = settings.margins.top * 72;
  const marginBottom = settings.margins.bottom * 72;
  const contentWidth = pageWidth - marginLeft - marginRight;

  let currentY = marginTop + 20;

  const checkPageBreak = (neededHeight: number) => {
    if (currentY + neededHeight > pageHeight - marginBottom) {
      doc.addPage(format, orientation);
      currentY = marginTop + 20;
      return true;
    }
    return false;
  };

  // Document Title
  if (title && title.trim()) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(settings.headingSize + 4);
    doc.setTextColor(25, 114, 232); // Primary blue
    const titleLines = doc.splitTextToSize(title, contentWidth);
    for (const tl of titleLines) {
      checkPageBreak(settings.headingSize + 6);
      doc.text(tl, marginLeft, currentY);
      currentY += (settings.headingSize + 6);
    }
    currentY += 14;
  }

  // Iterate sections
  for (const sec of sections) {
    const content = sec.content || '';

    switch (sec.type) {
      case 'heading': {
        checkPageBreak(settings.headingSize + 16);
        currentY += 10;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(settings.headingSize);
        doc.setTextColor(30, 41, 59);
        const lines = doc.splitTextToSize(content, contentWidth);
        for (const line of lines) {
          doc.text(line, marginLeft, currentY);
          currentY += (settings.headingSize + 4);
        }
        currentY += 6;
        break;
      }

      case 'subheading': {
        checkPageBreak(settings.headingSize + 10);
        currentY += 8;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(Math.max(12, settings.headingSize - 3));
        doc.setTextColor(51, 65, 85);
        const lines = doc.splitTextToSize(content, contentWidth);
        for (const line of lines) {
          doc.text(line, marginLeft, currentY);
          currentY += (settings.headingSize + 2);
        }
        currentY += 4;
        break;
      }

      case 'bullet_list': {
        const items = content.split('\n').filter(Boolean);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(settings.bodySize);
        doc.setTextColor(30, 41, 59);
        for (const item of items) {
          checkPageBreak(settings.bodySize * settings.lineSpacing + 4);
          const clean = item.replace(/^[-*•]\s*/, '');
          doc.setFillColor(25, 114, 232);
          doc.circle(marginLeft + 4, currentY - 3, 2, 'F');
          const lines = doc.splitTextToSize(clean, contentWidth - 14);
          for (let li = 0; li < lines.length; li++) {
            doc.text(lines[li], marginLeft + 14, currentY);
            currentY += (settings.bodySize * settings.lineSpacing);
          }
          currentY += settings.paragraphSpacing;
        }
        break;
      }

      case 'numbered_list': {
        const items = content.split('\n').filter(Boolean);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(settings.bodySize);
        doc.setTextColor(30, 41, 59);
        items.forEach((item, idx) => {
          checkPageBreak(settings.bodySize * settings.lineSpacing + 4);
          const clean = item.replace(/^\d+\.\s*/, '');
          const prefix = `${idx + 1}. `;
          doc.text(prefix, marginLeft, currentY);
          const lines = doc.splitTextToSize(clean, contentWidth - 18);
          for (let li = 0; li < lines.length; li++) {
            doc.text(lines[li], marginLeft + 18, currentY);
            currentY += (settings.bodySize * settings.lineSpacing);
          }
          currentY += settings.paragraphSpacing;
        });
        break;
      }

      case 'table': {
        const rows = content.split('\n').filter(Boolean);
        const parsedRows = rows.map(r => r.split('|').map(c => c.trim()).filter(Boolean));
        if (parsedRows.length === 0) break;
        const maxCols = Math.max(...parsedRows.map(r => r.length));
        const colW = contentWidth / Math.max(1, maxCols);
        const rowH = 22;

        parsedRows.forEach((row, rIdx) => {
          checkPageBreak(rowH + 4);
          const isHeader = rIdx === 0;

          if (isHeader) {
            doc.setFillColor(241, 245, 249);
            doc.rect(marginLeft, currentY - 14, contentWidth, rowH, 'F');
          }

          doc.setDrawColor(203, 213, 225);
          doc.rect(marginLeft, currentY - 14, contentWidth, rowH, 'S');

          row.forEach((cell, cIdx) => {
            const cellX = marginLeft + (cIdx * colW);
            doc.setFont('helvetica', isHeader ? 'bold' : 'normal');
            doc.setFontSize(settings.bodySize - 1);
            doc.setTextColor(isHeader ? 15 : 51, isHeader ? 23 : 65, isHeader ? 42 : 85);
            doc.text(cell.slice(0, 30), cellX + 6, currentY);
          });
          currentY += rowH;
        });
        currentY += 8;
        break;
      }

      case 'paragraph':
      default: {
        const paragraphs = content.split('\n');
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(settings.bodySize);
        doc.setTextColor(30, 41, 59);

        for (const p of paragraphs) {
          if (!p.trim()) {
            currentY += 8;
            continue;
          }
          const indent = settings.indentFirstLine ? 20 : 0;
          const lines = doc.splitTextToSize(p, contentWidth - indent);
          for (let li = 0; li < lines.length; li++) {
            checkPageBreak(settings.bodySize * settings.lineSpacing);
            const lineX = (li === 0 && settings.indentFirstLine) ? marginLeft + indent : marginLeft;
            doc.text(lines[li], lineX, currentY);
            currentY += (settings.bodySize * settings.lineSpacing);
          }
          currentY += settings.paragraphSpacing;
        }
        break;
      }
    }
  }

  // Draw headers and footers across pages
  const totalPages = doc.getNumberOfPages();
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(148, 163, 184);

    if (settings.headerText) {
      doc.text(settings.headerText, pageWidth - marginRight, marginTop / 2, { align: 'right' });
    }

    if (settings.includePageNumbers) {
      doc.text(`Page ${p} of ${totalPages}`, pageWidth / 2, pageHeight - (marginBottom / 2), { align: 'center' });
    }
  }

  const pdfOutput = doc.output('blob');
  return pdfOutput;
}

// Convert plain string or OCR text into structured document sections
export function parseRawTextToSections(rawText: string): DocumentSection[] {
  const lines = rawText.split('\n');
  const sections: DocumentSection[] = [];
  let currentParagraphLines: string[] = [];
  let tableBuffer: string[] = [];

  const flushParagraph = () => {
    if (currentParagraphLines.length > 0) {
      sections.push({
        id: 'sec-' + Math.random().toString(36).substring(2, 9),
        type: 'paragraph',
        content: currentParagraphLines.join('\n')
      });
      currentParagraphLines = [];
    }
  };

  const flushTable = () => {
    if (tableBuffer.length > 0) {
      sections.push({
        id: 'sec-' + Math.random().toString(36).substring(2, 9),
        type: 'table',
        content: tableBuffer.join('\n')
      });
      tableBuffer = [];
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = rawLine.trim();

    if (!line) {
      flushParagraph();
      flushTable();
      continue;
    }

    // Detect markdown or pipe table
    if (line.includes('|') && line.split('|').length > 2) {
      flushParagraph();
      tableBuffer.push(line);
      continue;
    } else if (tableBuffer.length > 0) {
      flushTable();
    }

    // Detect heading
    if (/^#+\s+/.test(line)) {
      flushParagraph();
      const level = (line.match(/^#+/)?.[0].length || 1) <= 1 ? 1 : 2;
      sections.push({
        id: 'sec-' + Math.random().toString(36).substring(2, 9),
        type: level === 1 ? 'heading' : 'subheading',
        content: line.replace(/^#+\s*/, ''),
        level
      });
    } else if (/^(ABSTRACT|INTRODUCTION|METHODOLOGY|RESULTS|DISCUSSION|CONCLUSION|EXECUTIVE SUMMARY|DELIVERABLES|REFERENCES):?$/i.test(line)) {
      flushParagraph();
      sections.push({
        id: 'sec-' + Math.random().toString(36).substring(2, 9),
        type: 'heading',
        content: line,
        level: 1
      });
    } else if (/^([-*•])\s+/.test(line)) {
      flushParagraph();
      // Group contiguous bullets
      let bulletContent = line.replace(/^([-*•])\s+/, '');
      while (i + 1 < lines.length && /^([-*•])\s+/.test(lines[i + 1].trim())) {
        i++;
        bulletContent += '\n' + lines[i].trim().replace(/^([-*•])\s+/, '');
      }
      sections.push({
        id: 'sec-' + Math.random().toString(36).substring(2, 9),
        type: 'bullet_list',
        content: bulletContent
      });
    } else if (/^\d+\.\s+/.test(line)) {
      flushParagraph();
      let numContent = line.replace(/^\d+\.\s+/, '');
      while (i + 1 < lines.length && /^\d+\.\s+/.test(lines[i + 1].trim())) {
        i++;
        numContent += '\n' + lines[i].trim().replace(/^\d+\.\s+/, '');
      }
      sections.push({
        id: 'sec-' + Math.random().toString(36).substring(2, 9),
        type: 'numbered_list',
        content: numContent
      });
    } else if (/^>/.test(line)) {
      flushParagraph();
      sections.push({
        id: 'sec-' + Math.random().toString(36).substring(2, 9),
        type: 'quote',
        content: line.replace(/^>\s*/, '')
      });
    } else {
      currentParagraphLines.push(rawLine);
    }
  }

  flushParagraph();
  flushTable();

  return sections.length > 0 ? sections : [{
    id: 'sec-init',
    type: 'paragraph',
    content: rawText
  }];
}
