/**
 * High-definition acoustic wood & tournament chess sound synthesizer.
 * Uses layered bandpass-filtered noise transients + damped woody body resonators
 * to replicate authentic weighted Staunton pieces on a wooden board (Chess.com style).
 */
class ChessSoundEngine {
  private ctx: AudioContext | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  public enabled: boolean = true;

  private getContext(): AudioContext | null {
    if (!this.enabled || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private getNoiseBuffer(ctx: AudioContext): AudioBuffer {
    if (this.noiseBuffer && this.noiseBuffer.sampleRate === ctx.sampleRate) {
      return this.noiseBuffer;
    }
    const duration = 0.25;
    const bufferSize = Math.floor(ctx.sampleRate * duration);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    this.noiseBuffer = buffer;
    return buffer;
  }

  /**
   * Internal helper: synthesizes a single realistic wooden piece knock at `startTime`.
   */
  private triggerWoodKnock(
    ctx: AudioContext,
    startTime: number,
    options: {
      bodyFreq: number;
      endFreq: number;
      clickFreq: number;
      q: number;
      volume: number;
      decay: number;
    }
  ) {
    const { bodyFreq, endFreq, clickFreq, q, volume, decay } = options;

    // 1. Damped wooden cavity resonance (low-mid thud)
    const bodyOsc = ctx.createOscillator();
    const bodyGain = ctx.createGain();
    bodyOsc.type = 'sine';
    bodyOsc.frequency.setValueAtTime(bodyFreq, startTime);
    bodyOsc.frequency.exponentialRampToValueAtTime(endFreq, startTime + decay);

    bodyGain.gain.setValueAtTime(0.001, startTime);
    bodyGain.gain.linearRampToValueAtTime(volume, startTime + 0.003);
    bodyGain.gain.exponentialRampToValueAtTime(0.0001, startTime + decay);

    bodyOsc.connect(bodyGain);
    bodyGain.connect(ctx.destination);
    bodyOsc.start(startTime);
    bodyOsc.stop(startTime + decay + 0.005);

    // 2. Crisp wooden surface contact transient (bandpass-filtered noise)
    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = this.getNoiseBuffer(ctx);

    const bandpass = ctx.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.setValueAtTime(clickFreq, startTime);
    bandpass.Q.setValueAtTime(q, startTime);

    const lowpass = ctx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.setValueAtTime(2800, startTime);

    const noiseGain = ctx.createGain();
    const transientDecay = Math.min(0.032, decay * 0.65);
    noiseGain.gain.setValueAtTime(0.001, startTime);
    noiseGain.gain.linearRampToValueAtTime(volume * 0.85, startTime + 0.0015);
    noiseGain.gain.exponentialRampToValueAtTime(0.0001, startTime + transientDecay);

    noiseSource.connect(bandpass);
    bandpass.connect(lowpass);
    lowpass.connect(noiseGain);
    noiseGain.connect(ctx.destination);

    noiseSource.start(startTime);
    noiseSource.stop(startTime + transientDecay + 0.005);
  }

  /**
   * Standard piece placement — crisp weighted Staunton wood tap + subtle base settle
   */
  public playMove() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    // Primary heel contact
    this.triggerWoodKnock(ctx, now, {
      bodyFreq: 155,
      endFreq: 68,
      clickFreq: 980,
      q: 3.2,
      volume: 0.42,
      decay: 0.048,
    });

    // Subtle secondary rim settle 14ms later
    this.triggerWoodKnock(ctx, now + 0.014, {
      bodyFreq: 210,
      endFreq: 95,
      clickFreq: 1350,
      q: 4.0,
      volume: 0.16,
      decay: 0.032,
    });
  }

  /**
   * Piece capture — sharper piece-on-piece clack + heavier board thud
   */
  public playCapture() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    // Initial sharp piece-on-piece collision clack
    this.triggerWoodKnock(ctx, now, {
      bodyFreq: 290,
      endFreq: 120,
      clickFreq: 1750,
      q: 2.8,
      volume: 0.48,
      decay: 0.038,
    });

    // Firm board placement thud 16ms later
    this.triggerWoodKnock(ctx, now + 0.016, {
      bodyFreq: 135,
      endFreq: 52,
      clickFreq: 860,
      q: 2.5,
      volume: 0.55,
      decay: 0.062,
    });
  }

  /**
   * Castling — two distinct wooden placements (King then Rook)
   */
  public playCastle() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    this.triggerWoodKnock(ctx, now, {
      bodyFreq: 150,
      endFreq: 65,
      clickFreq: 950,
      q: 3.2,
      volume: 0.42,
      decay: 0.048,
    });

    this.triggerWoodKnock(ctx, now + 0.085, {
      bodyFreq: 175,
      endFreq: 78,
      clickFreq: 1120,
      q: 3.5,
      volume: 0.38,
      decay: 0.045,
    });
  }

  /**
   * Pawn promotion — firm wood placement + warm acoustic marimba fifth
   */
  public playPromote() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    this.triggerWoodKnock(ctx, now, {
      bodyFreq: 165,
      endFreq: 72,
      clickFreq: 1150,
      q: 3.0,
      volume: 0.45,
      decay: 0.05,
    });

    const notes = [523.25, 783.99]; // C5 -> G5
    notes.forEach((freq, idx) => {
      const t = now + idx * 0.055;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(0.18, t + 0.005);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.24);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.25);
    });
  }

  /**
   * King in Check — sharp wooden snap + low-mid percussive tension chime
   */
  public playCheck() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    this.triggerWoodKnock(ctx, now, {
      bodyFreq: 210,
      endFreq: 85,
      clickFreq: 1450,
      q: 2.8,
      volume: 0.46,
      decay: 0.045,
    });

    // Subtle percussive woody marimba octaves (E4 + E5)
    [329.63, 659.25].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + 0.01);

      gain.gain.setValueAtTime(0.001, now + 0.01);
      gain.gain.linearRampToValueAtTime(i === 0 ? 0.16 : 0.08, now + 0.016);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + 0.01);
      osc.stop(now + 0.23);
    });
  }

  /**
   * Low time warning tick (when player drops below 10 seconds)
   */
  public playLowTimeTick() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    this.triggerWoodKnock(ctx, now, {
      bodyFreq: 420,
      endFreq: 280,
      clickFreq: 2100,
      q: 6.0,
      volume: 0.18,
      decay: 0.022,
    });
  }

  /**
   * Game Over — decisive double wood knock + warm resonant chord
   */
  public playGameOver() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    this.triggerWoodKnock(ctx, now, {
      bodyFreq: 145,
      endFreq: 55,
      clickFreq: 980,
      q: 2.8,
      volume: 0.5,
      decay: 0.06,
    });

    const chord = [261.63, 329.63, 392.0, 523.25];
    chord.forEach((freq, idx) => {
      const start = now + 0.04 + idx * 0.045;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, start);

      gain.gain.setValueAtTime(0.001, start);
      gain.gain.linearRampToValueAtTime(0.14, start + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.55);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.56);
    });
  }
}

export const soundEngine = new ChessSoundEngine();
