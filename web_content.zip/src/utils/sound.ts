/**
 * Kid-friendly sound generator using Web Audio API and Speech Synthesis
 */

class SoundManager {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private ttsQuotaExceeded: boolean = false;

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  // Play a cheerful celebration chime
  public playSuccessSound() {
    if (this.isMuted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.08);

      gain.gain.setValueAtTime(0, now + i * 0.08);
      gain.gain.linearRampToValueAtTime(0.2, now + i * 0.08 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + i * 0.08);
      osc.stop(now + i * 0.08 + 0.4);
    });
  }

  // Play a cute pop sound on card tap
  public playPopSound() {
    if (this.isMuted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(300, now);
    osc.frequency.exponentialRampToValueAtTime(750, now + 0.08);

    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.09);
  }

  // Play a sparkling star reward sound
  public playStarSound() {
    if (this.isMuted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const freqs = [880, 1108.73, 1318.51, 1760]; // A5, C#6, E6, A6
    freqs.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.06);

      gain.gain.setValueAtTime(0.18, now + i * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.06 + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + i * 0.06);
      osc.stop(now + i * 0.06 + 0.26);
    });
  }

  // Instant speech pronunciation for letters, words, and teacher speech
  public speakText(text: string, lang: 'ur' | 'en' = 'ur'): Promise<void> {
    return new Promise((resolve) => {
      if (this.isMuted || typeof window === 'undefined' || !('speechSynthesis' in window)) {
        resolve();
        return;
      }

      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.88; // Slightly gentle & slow for preschool kids
      utterance.pitch = 1.25; // Friendly, warm, slightly cheerful pitch

      const voices = window.speechSynthesis.getVoices();
      if (lang === 'ur') {
        // Try finding Urdu or Hindi or Pakistani/Indian voices
        const urduVoice = voices.find(
          (v) =>
            v.lang.startsWith('ur') ||
            v.lang.startsWith('pa') ||
            v.lang.startsWith('hi') ||
            v.name.toLowerCase().includes('urdu') ||
            v.name.toLowerCase().includes('hindi')
        );
        if (urduVoice) {
          utterance.voice = urduVoice;
        }
        utterance.lang = 'ur-PK';
      } else {
        const engVoice = voices.find(
          (v) =>
            v.lang.startsWith('en') &&
            (v.name.toLowerCase().includes('female') ||
              v.name.toLowerCase().includes('samantha') ||
              v.name.toLowerCase().includes('child') ||
              v.name.toLowerCase().includes('natural'))
        ) || voices.find((v) => v.lang.startsWith('en'));
        if (engVoice) {
          utterance.voice = engVoice;
        }
        utterance.lang = 'en-US';
      }

      utterance.onend = () => resolve();
      utterance.onerror = () => resolve();

      window.speechSynthesis.speak(utterance);
    });
  }

  // Speak using local speech or Gemini TTS with instant fallback
  public async speakWithGeminiOrLocal(text: string, lang: 'ur' | 'en' = 'ur') {
    if (this.isMuted) return;

    // If quota was already exceeded or for quick letters, use instant local Web Speech
    if (this.ttsQuotaExceeded) {
      await this.speakText(text, lang);
      return;
    }

    try {
      const res = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.quotaExceeded) {
          this.ttsQuotaExceeded = true;
        } else if (data.audio) {
          await this.playPcmAudio(data.audio, data.sampleRate || 24000);
          return;
        }
      } else {
        this.ttsQuotaExceeded = true;
      }
    } catch {
      this.ttsQuotaExceeded = true;
    }

    // Always fallback smoothly to local speech synthesis
    await this.speakText(text, lang);
  }

  // Play PCM audio from Gemini TTS
  private async playPcmAudio(base64Data: string, sampleRate: number): Promise<void> {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const binaryString = atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const pcm16 = new Int16Array(bytes.buffer);
      const audioBuffer = ctx.createBuffer(1, pcm16.length, sampleRate);
      const channelData = audioBuffer.getChannelData(0);

      for (let i = 0; i < pcm16.length; i++) {
        channelData[i] = pcm16[i] / 32768;
      }

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);

      return new Promise((resolve) => {
        source.onended = () => resolve();
        source.start();
      });
    } catch {
      // Fallback cleanly
    }
  }
}

export const sound = new SoundManager();
