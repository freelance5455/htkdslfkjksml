/**
 * Device Orientation helper for outdoor night orientation / compass
 */

export interface OrientationData {
  heading: number | null; // 0-360 degrees
  cardinal: string;
  supported: boolean;
}

export function getCardinalDirection(deg: number): string {
  const normalized = (deg % 360 + 360) % 360;
  if (normalized >= 337.5 || normalized < 22.5) return 'S'; // Sever (North in CZ)
  if (normalized >= 22.5 && normalized < 67.5) return 'SV'; // Severovýchod
  if (normalized >= 67.5 && normalized < 112.5) return 'V'; // Východ
  if (normalized >= 112.5 && normalized < 157.5) return 'JV'; // Jihovýchod
  if (normalized >= 157.5 && normalized < 202.5) return 'J'; // Jih
  if (normalized >= 202.5 && normalized < 247.5) return 'JZ'; // Jihozápad
  if (normalized >= 247.5 && normalized < 292.5) return 'Z'; // Západ
  return 'SZ'; // Severozápad
}

interface WebkitDeviceOrientationEvent extends DeviceOrientationEvent {
  webkitCompassHeading?: number;
}

class OrientationController {
  private data: OrientationData = {
    heading: null,
    cardinal: 'S',
    supported: false,
  };
  private listeners: Set<(data: OrientationData) => void> = new Set();
  private isListening: boolean = false;

  public subscribe(listener: (data: OrientationData) => void): () => void {
    this.listeners.add(listener);
    listener(this.data);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public async startListening() {
    if (this.isListening || typeof window === 'undefined') return;

    // Check iOS permission
    const DeviceOrientationEventAny = window.DeviceOrientationEvent as unknown as {
      requestPermission?: () => Promise<'granted' | 'denied'>;
    };

    if (typeof DeviceOrientationEventAny?.requestPermission === 'function') {
      try {
        const response = await DeviceOrientationEventAny.requestPermission();
        if (response !== 'granted') return;
      } catch {
        return;
      }
    }

    window.addEventListener('deviceorientation', this.handleOrientation, true);
    this.isListening = true;
  }

  public stopListening() {
    if (!this.isListening || typeof window === 'undefined') return;
    window.removeEventListener('deviceorientation', this.handleOrientation, true);
    this.isListening = false;
  }

  private handleOrientation = (e: DeviceOrientationEvent) => {
    let heading: number | null = null;
    const webkitEvent = e as WebkitDeviceOrientationEvent;

    if (typeof webkitEvent.webkitCompassHeading !== 'undefined') {
      heading = Math.round(webkitEvent.webkitCompassHeading);
    } else if (e.alpha !== null) {
      heading = Math.round(360 - e.alpha);
    }

    if (heading !== null) {
      const cardinal = getCardinalDirection(heading);
      this.data = { heading, cardinal, supported: true };
      this.listeners.forEach((l) => l(this.data));
    }
  };
}

export const orientationService = new OrientationController();
