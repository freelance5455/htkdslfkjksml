/**
 * Calcolo psicrometrico del Punto di Rugiada (Dew Point) secondo formula Magnus-Tetens
 * e verifica conformità norma ISO 8502-4 / SSPC per sabbiatura e verniciatura industriale.
 */

export function calculateDewPoint(airTempC: number, relativeHumidityPct: number): number {
  if (relativeHumidityPct <= 0) return -50;
  if (relativeHumidityPct > 100) relativeHumidityPct = 100;

  const a = 17.27;
  const b = 237.7;

  const alpha = (a * airTempC) / (b + airTempC) + Math.log(relativeHumidityPct / 100.0);
  const dewPoint = (b * alpha) / (a - alpha);

  // Return rounded to 1 decimal place
  return Math.round(dewPoint * 10) / 10;
}

export function evaluateCoatingConditions(
  airTempC: number,
  relativeHumidityPct: number,
  surfaceTempC: number
): {
  dewPoint: number;
  delta: number;
  isDeltaOk: boolean;
  statusText: string;
} {
  const dewPoint = calculateDewPoint(airTempC, relativeHumidityPct);
  const delta = Math.round((surfaceTempC - dewPoint) * 10) / 10;
  // Rule of 3°C: Surface must be >= Dew Point + 3°C
  const isDeltaOk = delta >= 3.0;

  return {
    dewPoint,
    delta,
    isDeltaOk,
    statusText: isDeltaOk ? 'OK' : 'ATTENZIONE CONDENSA (ΔT < 3°C)'
  };
}
