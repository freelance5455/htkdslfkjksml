import {
  Invoice,
  InvoiceItem,
  Product,
  PaymentRecord,
  ReturnRecord,
  Visit,
  Customer,
  TreasuryMove,
} from '../db/indexedDB';
import {
  formatMoney,
  getEffectiveThreshold,
  isStockBelowSafetyThreshold,
  getSafetyStockDeficit,
  calcInventoryTotals,
  getArabicDayName,
} from './calc';

export interface CompanySettings {
  companyName: string;
  companyPhone: string;
  companyAddress: string;
  taxNo: string;
  receiptFooter: string;
}

export interface ReportDataBundle {
  invoices: Invoice[];
  invoiceItems: InvoiceItem[];
  payments: PaymentRecord[];
  returns: ReturnRecord[];
  visits: Visit[];
  customers: Customer[];
  products: Product[];
  treasuryMoves: TreasuryMove[];
}

/**
 * Print 80mm Thermal Receipt for Invoices
 */
export function printInvoiceReceipt(
  invoice: Invoice,
  items: InvoiceItem[] = [],
  settings: Partial<CompanySettings> = {}
) {
  const printArea = document.getElementById('receipt-print-area');
  if (!printArea) return;

  const dateFormatted = new Date(invoice.date).toLocaleString('ar-EG');

  // Fallback if items were not loaded or single line
  const effectiveItems =
    items.length > 0
      ? items
      : [
          {
            id: 'fallback',
            invoiceId: invoice.id,
            productId: 'P-GEN',
            name: 'مبيعات منتجات متنوعة',
            qty: 1,
            price: invoice.grandTotal,
            itemDiscount: 0,
            lineTotal: invoice.grandTotal,
          } as InvoiceItem,
        ];

  printArea.innerHTML = `
    <div style="font-family: monospace, Tahoma, sans-serif; font-size: 11px; direction: rtl; color: #000; width: 74mm; margin: auto; padding: 2mm 0; line-height: 1.4;">
      <div style="text-align: center; margin-bottom: 8px;">
        <h2 style="font-size: 16px; margin: 0 0 3px; font-weight: 900;">${settings.companyName || 'شركة المبيعات والتوزيع'}</h2>
        <div style="font-size: 10px;">${settings.companyAddress || 'القاهرة - مستودع التوزيع الرئيسي'}</div>
        <div style="font-size: 10px;">هاتف: ${settings.companyPhone || '0123456789'}</div>
        ${settings.taxNo ? `<div style="font-size: 9px; margin-top: 2px;">سجل ضريبي: ${settings.taxNo}</div>` : ''}
      </div>
      
      <div style="border-top: 1px dashed #000; border-bottom: 1px dashed #000; padding: 5px 0; margin: 6px 0; font-size: 10px;">
        <div style="display:flex; justify-content:space-between;"><b>فاتورة رقم:</b> <span style="font-family:monospace; font-weight:bold;">${invoice.invoiceNo}</span></div>
        <div style="display:flex; justify-content:space-between;"><b>التاريخ:</b> <span>${dateFormatted}</span></div>
        <div style="display:flex; justify-content:space-between;"><b>العميل:</b> <span>${invoice.customerName}</span></div>
        <div style="display:flex; justify-content:space-between;"><b>نوع السداد:</b> <span>${invoice.payType}</span></div>
        <div style="display:flex; justify-content:space-between;"><b>السيارة / المندوب:</b> <span>VAN-9902</span></div>
      </div>

      <table style="width: 100%; border-collapse: collapse; font-size: 10px; margin-bottom: 6px;">
        <thead>
          <tr style="border-bottom: 1px solid #000; text-align: right;">
            <th style="padding: 3px 0;">الصنف</th>
            <th style="padding: 3px 0; text-align: center;">سعر</th>
            <th style="padding: 3px 0; text-align: center;">ك</th>
            <th style="padding: 3px 0; text-align: left;">الإجمالي</th>
          </tr>
        </thead>
        <tbody>
          ${effectiveItems
            .map(
              (i) => `
            <tr style="border-bottom: 1px dashed #ddd;">
              <td style="padding: 3px 0;">
                <div>${i.name}</div>
                ${i.itemDiscount && i.itemDiscount > 0 ? `<div style="font-size:8px; color:#555;">(خصم صنف: ${formatMoney(i.itemDiscount)})</div>` : ''}
              </td>
              <td style="padding: 3px 0; text-align: center; font-family: monospace;">${formatMoney(i.price)}</td>
              <td style="padding: 3px 0; text-align: center; font-weight:bold;">${i.qty}</td>
              <td style="padding: 3px 0; text-align: left; font-family:monospace; font-weight: bold;">${formatMoney(i.lineTotal)}</td>
            </tr>
          `
            )
            .join('')}
        </tbody>
      </table>

      <div style="border-top: 1px dashed #000; padding-top: 5px; font-size: 11px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
          <span>الإجمالي قبل الخصم:</span>
          <b>${formatMoney(invoice.subtotal)} ج.م</b>
        </div>
        ${
          invoice.monthlyDiscountValue > 0
            ? `
          <div style="display: flex; justify-content: space-between; color: #333; margin-bottom: 2px;">
            <span>الخصم الشهري (${invoice.monthlyDiscountRate}%):</span>
            <b>-${formatMoney(invoice.monthlyDiscountValue)} ج.م</b>
          </div>
        `
            : ''
        }
        <div style="display: flex; justify-content: space-between; font-size: 13px; font-weight: 900; border-top: 1px solid #000; border-bottom: 1px solid #000; padding: 4px 0; margin: 4px 0;">
          <span>الصافي المطلوب:</span>
          <span>${formatMoney(invoice.grandTotal)} ج.م</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
          <span>المبلغ المسدد الآن:</span>
          <b>${formatMoney(invoice.paidAmount)} ج.م</b>
        </div>
        ${
          invoice.remainingAmount > 0
            ? `
          <div style="display: flex; justify-content: space-between; font-weight: bold; color: #900;">
            <span>المتبقي آجل على الحساب:</span>
            <b>${formatMoney(invoice.remainingAmount)} ج.م</b>
          </div>
        `
            : ''
        }
      </div>

      <div style="text-align: center; margin-top: 10px; padding-top: 6px; border-top: 1px dashed #000; font-size: 10px;">
        <p style="margin: 0; font-weight:bold;">${settings.receiptFooter || 'شكراً لتعاملكم معنا'}</p>
        <p style="margin: 3px 0 0; font-size: 8px; color: #666;">مطبوعة من تطبيق مندوب مبيعات برو • سيارة VAN-9902</p>
      </div>
    </div>
  `;

  document.body.classList.remove('printing-report');
  document.body.classList.add('printing-invoice');
  printArea.classList.remove('hidden');

  const cleanup = () => {
    printArea.classList.add('hidden');
    printArea.innerHTML = '';
    document.body.classList.remove('printing-invoice');
    window.removeEventListener('afterprint', cleanup);
  };

  window.addEventListener('afterprint', cleanup);
  setTimeout(() => window.print(), 200);
  setTimeout(cleanup, 3500);
}

/**
 * Print 80mm Thermal Receipt for Cash Collection (سند قبض نقدي)
 */
export function printPaymentReceipt(
  payment: PaymentRecord,
  remainingBalance: number,
  settings: Partial<CompanySettings> = {}
) {
  const printArea = document.getElementById('receipt-print-area');
  if (!printArea) return;

  const dateFormatted = new Date(payment.date).toLocaleString('ar-EG');

  printArea.innerHTML = `
    <div style="font-family: monospace, Tahoma, sans-serif; font-size: 11px; direction: rtl; color: #000; width: 74mm; margin: auto; padding: 2mm 0; line-height: 1.4;">
      <div style="text-align: center; margin-bottom: 8px;">
        <h2 style="font-size: 15px; margin: 0 0 3px; font-weight: 900;">${settings.companyName || 'شركة المبيعات والتوزيع'}</h2>
        <div style="font-size: 11px; font-weight: bold; background: #000; color: #fff; padding: 2px 4px; border-radius: 3px; display: inline-block; margin: 2px 0;">سند قبض نقدي • إيصال سداد</div>
        <div style="font-size: 9px; color: #333;">${settings.companyAddress || 'المستودع الرئيسي'} • هاتف: ${settings.companyPhone || '-'}</div>
      </div>
      
      <div style="border-top: 1px dashed #000; border-bottom: 1px dashed #000; padding: 5px 0; margin: 6px 0; font-size: 10px;">
        <div style="display:flex; justify-content:space-between;"><b>رقم السند:</b> <span style="font-family:monospace; font-weight:bold;">${payment.id}</span></div>
        <div style="display:flex; justify-content:space-between;"><b>التاريخ والوقت:</b> <span>${dateFormatted}</span></div>
        <div style="display:flex; justify-content:space-between;"><b>اسم العميل:</b> <b>${payment.customerName}</b></div>
        <div style="display:flex; justify-content:space-between;"><b>السيارة / المندوب:</b> <span>VAN-9902</span></div>
      </div>

      <div style="border: 2px solid #000; padding: 8px; text-align: center; margin: 8px 0; border-radius: 4px; background: #fff;">
        <div style="font-size: 10px; font-weight: bold; color: #333;">المبلغ المقبوض نقداً</div>
        <div style="font-size: 20px; font-weight: 900; font-family: monospace; margin: 4px 0;">${formatMoney(payment.amount)} ج.م</div>
        <div style="font-size: 9px; color: #444;">البيان: ${payment.notes || 'سداد نقدي من حساب المديونية'}</div>
      </div>

      <div style="border-top: 1px dashed #000; border-bottom: 1px dashed #000; padding: 5px 0; font-size: 10px; margin-bottom: 8px;">
        <div style="display: flex; justify-content: space-between;">
          <span>المديونية المتبقية بعد السداد:</span>
          <b style="font-family: monospace; font-size: 11px; color: ${remainingBalance > 0 ? '#900' : '#000'};">${formatMoney(remainingBalance)} ج.م</b>
        </div>
      </div>

      <div style="display: flex; justify-content: space-between; margin-top: 12px; font-size: 10px; padding-top: 5px;">
        <div style="text-align: center; width: 45%;">
          <div>توقيع المندوب</div>
          <div style="margin-top: 18px; border-bottom: 1px dotted #000;"></div>
        </div>
        <div style="text-align: center; width: 45%;">
          <div>توقيع / ختم العميل</div>
          <div style="margin-top: 18px; border-bottom: 1px dotted #000;"></div>
        </div>
      </div>

      <div style="text-align: center; margin-top: 12px; font-size: 8px; color: #555; border-top: 1px dashed #000; padding-top: 4px;">
        ${settings.receiptFooter || 'شكراً لتعاملكم معنا'} • تم السداد من خلال مندوب مبيعات برو
      </div>
    </div>
  `;

  document.body.classList.remove('printing-report');
  document.body.classList.add('printing-invoice');
  printArea.classList.remove('hidden');

  const cleanup = () => {
    printArea.classList.add('hidden');
    printArea.innerHTML = '';
    document.body.classList.remove('printing-invoice');
    window.removeEventListener('afterprint', cleanup);
  };

  window.addEventListener('afterprint', cleanup);
  setTimeout(() => window.print(), 200);
  setTimeout(cleanup, 3500);
}

/**
 * Standard A4 / Report Document Print Engine
 */
export function printReportDocument(title: string, subtitle: string, contentHtml: string) {
  const printArea = document.getElementById('report-print-area');
  if (!printArea) return;

  printArea.innerHTML = `
    <div style="font-family: 'Cairo', Tahoma, sans-serif; direction: rtl; color: #000; padding: 15px; max-width: 900px; margin: auto;">
      <div style="text-align: center; border-bottom: 2px solid #000; padding-bottom: 12px; margin-bottom: 15px;">
        <h1 style="margin: 0; font-size: 20px; font-weight: 900;">${title}</h1>
        <div style="font-size: 12px; color: #444; margin-top: 4px; font-weight: bold;">${subtitle}</div>
        <div style="font-size: 10px; color: #666; margin-top: 3px;">مندوب مبيعات برو • تاريخ الطباعة: ${new Date().toLocaleString('ar-EG')}</div>
      </div>
      <div>${contentHtml}</div>
    </div>
  `;

  document.body.classList.remove('printing-invoice');
  document.body.classList.add('printing-report');
  printArea.classList.remove('hidden');

  const cleanup = () => {
    printArea.classList.add('hidden');
    printArea.innerHTML = '';
    document.body.classList.remove('printing-report');
    window.removeEventListener('afterprint', cleanup);
  };

  window.addEventListener('afterprint', cleanup);
  setTimeout(() => window.print(), 200);
  setTimeout(cleanup, 3500);
}

/**
 * Detailed Print Report for Van Stock & Safety Deficits (رصيد السيارة)
 */
export function printVanInventoryReport(
  products: Product[],
  vanInventory: Map<string, number>,
  vanSafetyThreshold: number,
  settings: Partial<CompanySettings> = {}
) {
  const totals = calcInventoryTotals(products, vanInventory);
  const lowItems = products.filter((p) => {
    const q = vanInventory.get(p.id) || 0;
    return isStockBelowSafetyThreshold(q, p.minQty, vanSafetyThreshold);
  });

  const totalDeficit = lowItems.reduce((acc, p) => {
    const q = vanInventory.get(p.id) || 0;
    return acc + getSafetyStockDeficit(q, p.minQty, vanSafetyThreshold);
  }, 0);

  const rowsHtml = products
    .map((p, idx) => {
      const q = vanInventory.get(p.id) || 0;
      const th = getEffectiveThreshold(p.minQty, vanSafetyThreshold);
      const isLow = isStockBelowSafetyThreshold(q, p.minQty, vanSafetyThreshold);
      const deficit = getSafetyStockDeficit(q, p.minQty, vanSafetyThreshold);
      const lineTotal = q * Number(p.price || 0);

      return `
        <tr style="border-bottom: 1px solid #ddd; ${isLow ? 'background-color: #fff1f2;' : ''}">
          <td style="padding: 6px; text-align: center;">${idx + 1}</td>
          <td style="padding: 6px; font-family: monospace;">${p.code}</td>
          <td style="padding: 6px;">${p.group}</td>
          <td style="padding: 6px; font-weight: bold;">
            ${p.name}
            ${isLow ? '<span style="color: #e11d48; font-size: 10px; margin-right: 4px;">⚠️ (تحت حد الأمان)</span>' : ''}
          </td>
          <td style="padding: 6px; text-align: center; font-weight: 900; font-size: 13px; ${isLow ? 'color: #e11d48;' : ''}">
            ${q}
          </td>
          <td style="padding: 6px; text-align: center; color: #555;">${th}</td>
          <td style="padding: 6px; text-align: center;">
            ${isLow ? `<b style="color: #e11d48;">عجز ${deficit} ق</b>` : '<span style="color: #059669;">آمن</span>'}
          </td>
          <td style="padding: 6px; text-align: left; font-family: monospace;">${formatMoney(p.price)}</td>
          <td style="padding: 6px; text-align: left; font-weight: bold; font-family: monospace;">${formatMoney(lineTotal)}</td>
        </tr>
      `;
    })
    .join('');

  const contentHtml = `
    <!-- KPI Header Cards -->
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 15px; font-size: 11px;">
      <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
        <div style="color: #64748b;">إجمالي الأصناف بالسيارة</div>
        <div style="font-size: 16px; font-weight: 900; margin-top: 4px;">${products.length} صنف</div>
      </div>
      <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
        <div style="color: #64748b;">إجمالي القطع المحملة</div>
        <div style="font-size: 16px; font-weight: 900; margin-top: 4px;">${totals.totalQty} قطعة</div>
      </div>
      <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
        <div style="color: #64748b;">القيمة الإجمالية بسعر البيع</div>
        <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: #0284c7;">${formatMoney(totals.totalSaleValue)} ج.م</div>
      </div>
      <div style="border: 1px solid ${lowItems.length > 0 ? '#fda4af' : '#ccc'}; border-radius: 8px; padding: 8px; text-align: center; background: ${lowItems.length > 0 ? '#ffe4e6' : '#f8fafc'};">
        <div style="color: ${lowItems.length > 0 ? '#e11d48' : '#64748b'}; font-weight:bold;">الأصناف تحت حد الأمان</div>
        <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: ${lowItems.length > 0 ? '#e11d48' : '#000'};">
          ${lowItems.length} صنف (عجز ${totalDeficit} ق)
        </div>
      </div>
    </div>

    ${
      lowItems.length > 0
        ? `
      <div style="background: #fff1f2; border: 1px solid #f43f5e; border-radius: 8px; padding: 10px; margin-bottom: 15px; font-size: 11px;">
        <strong style="color: #e11d48; display: block; margin-bottom: 4px;">🚨 تنبيه استباقي لنواقص السيارة:</strong>
        <span>يوجد <b>${lowItems.length}</b> أصناف انخفض رصيدها عن حد الأمان المقرر بالإعدادات (${vanSafetyThreshold} قطعة). يوصى بطلب تحميل فوري من المخزن الرئيسي لتعويض عجز قدره <b>${totalDeficit}</b> قطعة.</span>
      </div>
    `
        : ''
    }

    <!-- Main Table -->
    <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 20px;">
      <thead>
        <tr style="background: #0f172a; color: #fff; text-align: right;">
          <th style="padding: 6px; text-align: center; width: 30px;">#</th>
          <th style="padding: 6px; width: 75px;">الكود</th>
          <th style="padding: 6px; width: 75px;">المجموعة</th>
          <th style="padding: 6px;">اسم الصنف</th>
          <th style="padding: 6px; text-align: center; width: 70px;">رصيد السيارة</th>
          <th style="padding: 6px; text-align: center; width: 60px;">حد الأمان</th>
          <th style="padding: 6px; text-align: center; width: 80px;">الحالة</th>
          <th style="padding: 6px; text-align: left; width: 75px;">سعر البيع</th>
          <th style="padding: 6px; text-align: left; width: 95px;">إجمالي القيمة</th>
        </tr>
      </thead>
      <tbody>
        ${rowsHtml}
      </tbody>
      <tfoot>
        <tr style="background: #f1f5f9; font-weight: 900; border-top: 2px solid #000;">
          <td colspan="4" style="padding: 8px; text-align: right;">الإجمالي العام لحمولة السيارة:</td>
          <td style="padding: 8px; text-align: center; font-size: 13px;">${totals.totalQty}</td>
          <td colspan="3"></td>
          <td style="padding: 8px; text-align: left; font-size: 13px; color: #0284c7;">${formatMoney(totals.totalSaleValue)} ج.م</td>
        </tr>
      </tfoot>
    </table>

    <!-- Sign-off Block -->
    <div style="display: flex; justify-content: space-between; margin-top: 35px; padding-top: 15px; border-top: 1px dashed #999; font-size: 11px;">
      <div style="text-align: center; width: 30%;">
        <div>توقيع مندوب المبيعات</div>
        <div style="margin-top: 30px; border-bottom: 1px solid #000; width: 140px; margin-left: auto; margin-right: auto;"></div>
      </div>
      <div style="text-align: center; width: 30%;">
        <div>توقيع أمين المستودع</div>
        <div style="margin-top: 30px; border-bottom: 1px solid #000; width: 140px; margin-left: auto; margin-right: auto;"></div>
      </div>
      <div style="text-align: center; width: 30%;">
        <div>مسؤول الحركة والسيارات</div>
        <div style="margin-top: 30px; border-bottom: 1px solid #000; width: 140px; margin-left: auto; margin-right: auto;"></div>
      </div>
    </div>
  `;

  printReportDocument(
    'تقرير جرد حمولة ورصيد السيارة (VAN)',
    `السيارة: VAN-9902 • حد الأمان المعتمد: ${vanSafetyThreshold} قطعة • ${settings.companyName || 'شركة المبيعات والتوزيع'}`,
    contentHtml
  );
}

/**
 * Detailed Print Report for Main Warehouse Stock (رصيد المخزن الرئيسي)
 */
export function printMainInventoryReport(
  products: Product[],
  mainInventory: Map<string, number>,
  settings: Partial<CompanySettings> = {}
) {
  const totals = calcInventoryTotals(products, mainInventory);
  const totalMargin =
    totals.totalSaleValue > 0
      ? Math.round(((totals.totalSaleValue - totals.totalCostValue) / totals.totalSaleValue) * 100)
      : 0;

  const rowsHtml = products
    .map((p, idx) => {
      const q = mainInventory.get(p.id) || 0;
      const costTotal = q * Number(p.cost || 0);
      const saleTotal = q * Number(p.price || 0);
      const margin = p.price > 0 ? Math.round(((p.price - p.cost) / p.price) * 100) : 0;

      return `
        <tr style="border-bottom: 1px solid #ddd;">
          <td style="padding: 6px; text-align: center;">${idx + 1}</td>
          <td style="padding: 6px; font-family: monospace;">${p.code}</td>
          <td style="padding: 6px; font-family: monospace; font-size: 10px; color: #555;">${p.barcode || '-'}</td>
          <td style="padding: 6px;">${p.group}</td>
          <td style="padding: 6px; font-weight: bold;">${p.name}</td>
          <td style="padding: 6px; text-align: center; font-weight: 900; font-size: 13px; color: #0284c7;">
            ${q}
          </td>
          <td style="padding: 6px; text-align: left; font-family: monospace;">${formatMoney(p.cost)}</td>
          <td style="padding: 6px; text-align: left; font-family: monospace;">${formatMoney(p.price)}</td>
          <td style="padding: 6px; text-align: center; color: #059669; font-weight: bold;">${margin}%</td>
          <td style="padding: 6px; text-align: left; font-family: monospace;">${formatMoney(costTotal)}</td>
          <td style="padding: 6px; text-align: left; font-weight: bold; font-family: monospace;">${formatMoney(saleTotal)}</td>
        </tr>
      `;
    })
    .join('');

  const contentHtml = `
    <!-- Summary Header Cards -->
    <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; margin-bottom: 15px; font-size: 11px;">
      <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
        <div style="color: #64748b;">إجمالي الأصناف</div>
        <div style="font-size: 16px; font-weight: 900; margin-top: 4px;">${products.length} صنف</div>
      </div>
      <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
        <div style="color: #64748b;">إجمالي القطع المتوفرة</div>
        <div style="font-size: 16px; font-weight: 900; margin-top: 4px;">${totals.totalQty} قطعة</div>
      </div>
      <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
        <div style="color: #64748b;">إجمالي رأس المال (التكلفة)</div>
        <div style="font-size: 15px; font-weight: 900; margin-top: 4px; color: #334155;">${formatMoney(totals.totalCostValue)} ج.م</div>
      </div>
      <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
        <div style="color: #64748b;">القيمة البيعية المتوقعة</div>
        <div style="font-size: 15px; font-weight: 900; margin-top: 4px; color: #0284c7;">${formatMoney(totals.totalSaleValue)} ج.م</div>
      </div>
      <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
        <div style="color: #64748b;">هامش الربح الإجمالي</div>
        <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: #059669;">${totalMargin}%</div>
      </div>
    </div>

    <!-- Main Table -->
    <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 20px;">
      <thead>
        <tr style="background: #0369a1; color: #fff; text-align: right;">
          <th style="padding: 6px; text-align: center; width: 25px;">#</th>
          <th style="padding: 6px; width: 65px;">الكود</th>
          <th style="padding: 6px; width: 65px;">الباركود</th>
          <th style="padding: 6px; width: 65px;">المجموعة</th>
          <th style="padding: 6px;">اسم الصنف</th>
          <th style="padding: 6px; text-align: center; width: 65px;">رصيد المخزن</th>
          <th style="padding: 6px; text-align: left; width: 65px;">التكلفة</th>
          <th style="padding: 6px; text-align: left; width: 65px;">البيع</th>
          <th style="padding: 6px; text-align: center; width: 50px;">الربح</th>
          <th style="padding: 6px; text-align: left; width: 85px;">إجمالي التكلفة</th>
          <th style="padding: 6px; text-align: left; width: 90px;">إجمالي البيع</th>
        </tr>
      </thead>
      <tbody>
        ${rowsHtml}
      </tbody>
      <tfoot>
        <tr style="background: #f1f5f9; font-weight: 900; border-top: 2px solid #000;">
          <td colspan="5" style="padding: 8px; text-align: right;">الإجمالي العام للمخزن الرئيسي:</td>
          <td style="padding: 8px; text-align: center; font-size: 13px; color: #0284c7;">${totals.totalQty}</td>
          <td colspan="3"></td>
          <td style="padding: 8px; text-align: left; font-size: 12px;">${formatMoney(totals.totalCostValue)} ج.م</td>
          <td style="padding: 8px; text-align: left; font-size: 12px; color: #0284c7;">${formatMoney(totals.totalSaleValue)} ج.م</td>
        </tr>
      </tfoot>
    </table>

    <!-- Sign-off Block -->
    <div style="display: flex; justify-content: space-between; margin-top: 35px; padding-top: 15px; border-top: 1px dashed #999; font-size: 11px;">
      <div style="text-align: center; width: 30%;">
        <div>أمين المستودع المركزي</div>
        <div style="margin-top: 30px; border-bottom: 1px solid #000; width: 140px; margin-left: auto; margin-right: auto;"></div>
      </div>
      <div style="text-align: center; width: 30%;">
        <div>مدقق الجرد والمخازن</div>
        <div style="margin-top: 30px; border-bottom: 1px solid #000; width: 140px; margin-left: auto; margin-right: auto;"></div>
      </div>
      <div style="text-align: center; width: 30%;">
        <div>المدير المالي واللوجستي</div>
        <div style="margin-top: 30px; border-bottom: 1px solid #000; width: 140px; margin-left: auto; margin-right: auto;"></div>
      </div>
    </div>
  `;

  printReportDocument(
    'تقرير جرد المخزن الرئيسي (المركزي)',
    `المستودع الرئيسي • ${settings.companyName || 'شركة المبيعات والتوزيع'} • هاتف: ${settings.companyPhone || ''}`,
    contentHtml
  );
}

/**
 * Universal Print Report Handler covering all 7 report types
 */
export function printGeneralReport(
  type: string,
  date: string,
  data: ReportDataBundle,
  settings: Partial<CompanySettings> = {}
) {
  const arabicDay = getArabicDayName(date);
  const companyName = settings.companyName || 'شركة البركة للتوزيع واللوجستيات';

  const dateInvoices = data.invoices.filter((i) => i.date?.slice(0, 10) === date);
  const datePayments = data.payments.filter((p) => p.date?.slice(0, 10) === date);
  const dateReturns = data.returns.filter((r) => r.date?.slice(0, 10) === date);
  const dateVisits = data.visits.filter((v) => v.date === date);
  const dateMoves = data.treasuryMoves.filter((m) => m.date?.slice(0, 10) === date);

  let title = '';
  let subtitle = `تاريخ التقرير: ${date} (${arabicDay}) • سيارة: VAN-9902 • ${companyName}`;
  let contentHtml = '';

  const signOffHtml = `
    <div style="display: flex; justify-content: space-between; margin-top: 35px; padding-top: 15px; border-top: 1px dashed #999; font-size: 11px;">
      <div style="text-align: center; width: 30%;">
        <div>توقيع مندوب المبيعات</div>
        <div style="margin-top: 30px; border-bottom: 1px solid #000; width: 140px; margin-left: auto; margin-right: auto;"></div>
      </div>
      <div style="text-align: center; width: 30%;">
        <div>المراجع المالي</div>
        <div style="margin-top: 30px; border-bottom: 1px solid #000; width: 140px; margin-left: auto; margin-right: auto;"></div>
      </div>
      <div style="text-align: center; width: 30%;">
        <div>اعتماد مدير الفرع</div>
        <div style="margin-top: 30px; border-bottom: 1px solid #000; width: 140px; margin-left: auto; margin-right: auto;"></div>
      </div>
    </div>
  `;

  if (type === 'daily' || type === 'summary') {
    title = 'تقرير إجمالي اليوم الشامل (Z-Report)';
    const totalSales = dateInvoices.reduce((a, i) => a + Number(i.grandTotal || 0), 0);
    const totalColl = datePayments.reduce((a, p) => a + Number(p.amount || 0), 0);
    const totalRet = dateReturns.reduce((a, r) => a + Number(r.amount || 0), 0);
    const completedV = dateVisits.filter((v) => v.status === 'تمت الزيارة' || v.status.includes('تمت')).length;
    const totalIncome = dateMoves.filter((m) => m.type === 'إيراد').reduce((a, m) => a + m.amount, 0);
    const totalExpense = dateMoves.filter((m) => m.type === 'مصروف').reduce((a, m) => a + m.amount, 0);
    const netCash = totalIncome - totalExpense;

    contentHtml = `
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 15px; font-size: 11px;">
        <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
          <div style="color: #64748b;">إجمالي المبيعات</div>
          <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: #059669;">${formatMoney(totalSales)} ج.م</div>
          <div style="font-size: 10px; color: #555;">${dateInvoices.length} فاتورة</div>
        </div>
        <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
          <div style="color: #64748b;">المحصل نقداً</div>
          <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: #0284c7;">${formatMoney(totalColl)} ج.م</div>
          <div style="font-size: 10px; color: #555;">${datePayments.length} إيصال سداد</div>
        </div>
        <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
          <div style="color: #64748b;">المرتجعات</div>
          <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: #e11d48;">${formatMoney(totalRet)} ج.م</div>
          <div style="font-size: 10px; color: #555;">${dateReturns.length} حركة مرتجع</div>
        </div>
        <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
          <div style="color: #64748b;">صافي نقدية الخزنة</div>
          <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: #d97706;">${formatMoney(netCash)} ج.م</div>
          <div style="font-size: 10px; color: #555;">مصروفات: ${formatMoney(totalExpense)} ج.م</div>
        </div>
      </div>

      <h3 style="font-size: 13px; margin: 15px 0 6px; border-right: 3px solid #059669; padding-right: 6px;">فواتير المبيعات الصادرة اليوم</h3>
      <table style="width: 100%; border-collapse: collapse; font-size: 10px; margin-bottom: 15px;">
        <thead>
          <tr style="background: #0f172a; color: #fff; text-align: right;">
            <th style="padding: 5px;">رقم الفاتورة</th>
            <th style="padding: 5px;">العميل</th>
            <th style="padding: 5px; text-align: center;">طريقة السداد</th>
            <th style="padding: 5px; text-align: left;">الإجمالي</th>
            <th style="padding: 5px; text-align: left;">المسدد</th>
            <th style="padding: 5px; text-align: left;">المتبقي آجل</th>
          </tr>
        </thead>
        <tbody>
          ${
            dateInvoices.length > 0
              ? dateInvoices
                  .map(
                    (i) => `
              <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 5px; font-family: monospace; font-weight: bold;">${i.invoiceNo}</td>
                <td style="padding: 5px;">${i.customerName}</td>
                <td style="padding: 5px; text-align: center;">${i.payType}</td>
                <td style="padding: 5px; text-align: left; font-family: monospace; font-weight: bold;">${formatMoney(i.grandTotal)}</td>
                <td style="padding: 5px; text-align: left; font-family: monospace; color: #059669;">${formatMoney(i.paidAmount)}</td>
                <td style="padding: 5px; text-align: left; font-family: monospace; color: ${i.remainingAmount > 0 ? '#e11d48' : '#555'};">${formatMoney(i.remainingAmount)}</td>
              </tr>
            `
                  )
                  .join('')
              : '<tr><td colspan="6" style="padding: 10px; text-align: center; color: #888;">لا توجد فواتير مبيعات صادرة اليوم</td></tr>'
          }
        </tbody>
      </table>

      <h3 style="font-size: 13px; margin: 15px 0 6px; border-right: 3px solid #0284c7; padding-right: 6px;">حركة نقدية الخزنة والمصروفات اليومية</h3>
      <table style="width: 100%; border-collapse: collapse; font-size: 10px; margin-bottom: 15px;">
        <thead>
          <tr style="background: #334155; color: #fff; text-align: right;">
            <th style="padding: 5px;">الوقت</th>
            <th style="padding: 5px;">النوع</th>
            <th style="padding: 5px;">البيان والملاحظات</th>
            <th style="padding: 5px; text-align: left;">المبلغ (ج.م)</th>
          </tr>
        </thead>
        <tbody>
          ${
            dateMoves.length > 0
              ? dateMoves
                  .map(
                    (m) => `
              <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 5px; font-family: monospace;">${new Date(m.date).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}</td>
                <td style="padding: 5px; font-weight: bold; color: ${m.type === 'إيراد' ? '#059669' : '#e11d48'};">${m.type}</td>
                <td style="padding: 5px;">${m.notes || '-'}</td>
                <td style="padding: 5px; text-align: left; font-family: monospace; font-weight: bold;">${m.type === 'إيراد' ? '+' : '-'}${formatMoney(m.amount)}</td>
              </tr>
            `
                  )
                  .join('')
              : '<tr><td colspan="4" style="padding: 10px; text-align: center; color: #888;">لا توجد حركات خزنة مسجلة لهذا التاريخ</td></tr>'
          }
        </tbody>
      </table>
      ${signOffHtml}
    `;
  } else if (type === 'sales') {
    title = 'كشف فواتير المبيعات التفصيلي';
    const totalSales = dateInvoices.reduce((a, i) => a + Number(i.grandTotal || 0), 0);
    const totalPaid = dateInvoices.reduce((a, i) => a + Number(i.paidAmount || 0), 0);
    const totalCredit = dateInvoices.reduce((a, i) => a + Number(i.remainingAmount || 0), 0);

    contentHtml = `
      <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 15px;">
        <thead>
          <tr style="background: #0f172a; color: #fff; text-align: right;">
            <th style="padding: 6px; text-align: center; width: 30px;">#</th>
            <th style="padding: 6px;">رقم الفاتورة</th>
            <th style="padding: 6px;">الوقت</th>
            <th style="padding: 6px;">اسم العميل</th>
            <th style="padding: 6px; text-align: center;">طريقة الدفع</th>
            <th style="padding: 6px; text-align: left;">صافي الفاتورة</th>
            <th style="padding: 6px; text-align: left;">المسدد</th>
            <th style="padding: 6px; text-align: left;">المتبقي</th>
          </tr>
        </thead>
        <tbody>
          ${
            dateInvoices.length > 0
              ? dateInvoices
                  .map(
                    (i, idx) => `
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 6px; text-align: center;">${idx + 1}</td>
                <td style="padding: 6px; font-family: monospace; font-weight: bold;">${i.invoiceNo}</td>
                <td style="padding: 6px; font-family: monospace;">${new Date(i.date).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}</td>
                <td style="padding: 6px; font-weight: bold;">${i.customerName}</td>
                <td style="padding: 6px; text-align: center;">${i.payType}</td>
                <td style="padding: 6px; text-align: left; font-family: monospace; font-weight: bold;">${formatMoney(i.grandTotal)}</td>
                <td style="padding: 6px; text-align: left; font-family: monospace; color: #059669;">${formatMoney(i.paidAmount)}</td>
                <td style="padding: 6px; text-align: left; font-family: monospace; color: ${i.remainingAmount > 0 ? '#e11d48' : '#333'};">${formatMoney(i.remainingAmount)}</td>
              </tr>
            `
                  )
                  .join('')
              : '<tr><td colspan="8" style="padding: 15px; text-align: center; color: #888;">لا توجد فواتير مبيعات في هذا التاريخ</td></tr>'
          }
        </tbody>
        <tfoot>
          <tr style="background: #f1f5f9; font-weight: 900; border-top: 2px solid #000;">
            <td colspan="5" style="padding: 8px; text-align: right;">إجمالي فواتير المبيعات:</td>
            <td style="padding: 8px; text-align: left; font-size: 13px; color: #059669;">${formatMoney(totalSales)} ج.م</td>
            <td style="padding: 8px; text-align: left; font-size: 13px; color: #0284c7;">${formatMoney(totalPaid)} ج.م</td>
            <td style="padding: 8px; text-align: left; font-size: 13px; color: #e11d48;">${formatMoney(totalCredit)} ج.م</td>
          </tr>
        </tfoot>
      </table>
      ${signOffHtml}
    `;
  } else if (type === 'collections') {
    title = 'كشف التحصيلات النقدية وسندات القبض';
    const totalCollected = datePayments.reduce((a, p) => a + Number(p.amount || 0), 0);

    contentHtml = `
      <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 15px;">
        <thead>
          <tr style="background: #0284c7; color: #fff; text-align: right;">
            <th style="padding: 6px; text-align: center; width: 30px;">#</th>
            <th style="padding: 6px;">رقم السند</th>
            <th style="padding: 6px;">الوقت</th>
            <th style="padding: 6px;">اسم العميل</th>
            <th style="padding: 6px;">البيان والملاحظات</th>
            <th style="padding: 6px; text-align: left;">المبلغ المحصل</th>
          </tr>
        </thead>
        <tbody>
          ${
            datePayments.length > 0
              ? datePayments
                  .map(
                    (p, idx) => `
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 6px; text-align: center;">${idx + 1}</td>
                <td style="padding: 6px; font-family: monospace; font-weight: bold;">${p.id}</td>
                <td style="padding: 6px; font-family: monospace;">${new Date(p.date).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}</td>
                <td style="padding: 6px; font-weight: bold;">${p.customerName}</td>
                <td style="padding: 6px;">${p.notes || 'سداد نقدي'}</td>
                <td style="padding: 6px; text-align: left; font-family: monospace; font-weight: 900; color: #0284c7; font-size: 12px;">${formatMoney(p.amount)} ج.م</td>
              </tr>
            `
                  )
                  .join('')
              : '<tr><td colspan="6" style="padding: 15px; text-align: center; color: #888;">لا توجد سندات تحصيل مسجلة في هذا التاريخ</td></tr>'
          }
        </tbody>
        <tfoot>
          <tr style="background: #f1f5f9; font-weight: 900; border-top: 2px solid #000;">
            <td colspan="5" style="padding: 8px; text-align: right;">إجمالي التحصيلات المقبوضة:</td>
            <td style="padding: 8px; text-align: left; font-size: 14px; color: #0284c7;">${formatMoney(totalCollected)} ج.م</td>
          </tr>
        </tfoot>
      </table>
      ${signOffHtml}
    `;
  } else if (type === 'returns') {
    title = 'كشف مرتجعات البضاعة والمردودات';
    const totalReturns = dateReturns.reduce((a, r) => a + Number(r.amount || 0), 0);

    contentHtml = `
      <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 15px;">
        <thead>
          <tr style="background: #e11d48; color: #fff; text-align: right;">
            <th style="padding: 6px; text-align: center; width: 30px;">#</th>
            <th style="padding: 6px;">رقم المرتجع</th>
            <th style="padding: 6px;">اسم العميل</th>
            <th style="padding: 6px;">اسم الصنف</th>
            <th style="padding: 6px; text-align: center;">الكمية</th>
            <th style="padding: 6px; text-align: center;">حالة الصنف</th>
            <th style="padding: 6px; text-align: center;">الوجهة</th>
            <th style="padding: 6px; text-align: left;">القيمة</th>
          </tr>
        </thead>
        <tbody>
          ${
            dateReturns.length > 0
              ? dateReturns
                  .map(
                    (r, idx) => {
                      const prodName = data.products.find((p) => p.id === r.productId)?.name || r.productId;
                      const custName = r.customerName || data.customers.find((c) => c.id === r.customerId)?.name || r.customerId;
                      return `
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 6px; text-align: center;">${idx + 1}</td>
                <td style="padding: 6px; font-family: monospace; font-weight: bold;">${r.returnNo}</td>
                <td style="padding: 6px; font-weight: bold;">${custName}</td>
                <td style="padding: 6px;">${prodName}</td>
                <td style="padding: 6px; text-align: center; font-weight: bold;">${r.qty}</td>
                <td style="padding: 6px; text-align: center;">${r.type}</td>
                <td style="padding: 6px; text-align: center;">${r.destination}</td>
                <td style="padding: 6px; text-align: left; font-family: monospace; font-weight: bold; color: #e11d48;">${formatMoney(r.amount)} ج.م</td>
              </tr>
            `;
                    }
                  )
                  .join('')
              : '<tr><td colspan="8" style="padding: 15px; text-align: center; color: #888;">لا توجد مرتجعات مسجلة في هذا التاريخ</td></tr>'
          }
        </tbody>
        <tfoot>
          <tr style="background: #f1f5f9; font-weight: 900; border-top: 2px solid #000;">
            <td colspan="7" style="padding: 8px; text-align: right;">إجمالي قيمة المرتجعات:</td>
            <td style="padding: 8px; text-align: left; font-size: 14px; color: #e11d48;">${formatMoney(totalReturns)} ج.م</td>
          </tr>
        </tfoot>
      </table>
      ${signOffHtml}
    `;
  } else if (type === 'visits') {
    title = 'تقرير إنجاز خط السير والزيارات الميدانية';
    const completed = dateVisits.filter((v) => v.status === 'تمت الزيارة' || v.status.includes('تمت')).length;
    const cancelled = dateVisits.filter((v) => v.status.includes('ملغاة') || v.status.includes('مغلق')).length;
    const postponed = dateVisits.filter((v) => v.status.includes('مؤجل')).length;

    contentHtml = `
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 15px; font-size: 11px;">
        <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
          <div style="color: #64748b;">إجمالي الزيارات المسجلة</div>
          <div style="font-size: 16px; font-weight: 900; margin-top: 4px;">${dateVisits.length} زيارة</div>
        </div>
        <div style="border: 1px solid #a7f3d0; border-radius: 8px; padding: 8px; text-align: center; background: #ecfdf5;">
          <div style="color: #059669; font-weight: bold;">تمت بنجاح</div>
          <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: #059669;">${completed}</div>
        </div>
        <div style="border: 1px solid #fecdd3; border-radius: 8px; padding: 8px; text-align: center; background: #fff1f2;">
          <div style="color: #e11d48; font-weight: bold;">ملغاة / مغلق</div>
          <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: #e11d48;">${cancelled}</div>
        </div>
        <div style="border: 1px solid #fde68a; border-radius: 8px; padding: 8px; text-align: center; background: #fffbeb;">
          <div style="color: #d97706; font-weight: bold;">مؤجلة</div>
          <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: #d97706;">${postponed}</div>
        </div>
      </div>

      <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 15px;">
        <thead>
          <tr style="background: #d97706; color: #fff; text-align: right;">
            <th style="padding: 6px; text-align: center; width: 30px;">#</th>
            <th style="padding: 6px;">الوقت</th>
            <th style="padding: 6px;">اسم العميل</th>
            <th style="padding: 6px; text-align: center;">حالة الزيارة</th>
            <th style="padding: 6px;">ملاحظات الزيارة</th>
          </tr>
        </thead>
        <tbody>
          ${
            dateVisits.length > 0
              ? dateVisits
                  .map(
                    (v, idx) => `
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 6px; text-align: center;">${idx + 1}</td>
                <td style="padding: 6px; font-family: monospace;">${v.timestamp ? new Date(v.timestamp).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }) : '-'}</td>
                <td style="padding: 6px; font-weight: bold;">${v.customerName}</td>
                <td style="padding: 6px; text-align: center; font-weight: bold;">${v.status}</td>
                <td style="padding: 6px; color: #555;">${v.notes || '-'}</td>
              </tr>
            `
                  )
                  .join('')
              : '<tr><td colspan="5" style="padding: 15px; text-align: center; color: #888;">لم تسجل أي زيارات في هذا التاريخ بعد</td></tr>'
          }
        </tbody>
      </table>
      ${signOffHtml}
    `;
  } else if (type === 'debt') {
    title = 'كشف مديونيات وأرصدة العملاء المستحقة';
    const debtCustomers = data.customers
      .filter((c) => Number(c.balance || 0) > 0)
      .sort((a, b) => Number(b.balance || 0) - Number(a.balance || 0));
    const totalDebt = debtCustomers.reduce((acc, c) => acc + Number(c.balance || 0), 0);

    contentHtml = `
      <div style="background: #fff1f2; border: 1px solid #fda4af; border-radius: 8px; padding: 10px; margin-bottom: 15px; font-size: 11px;">
        <span style="color: #e11d48; font-weight: bold; font-size: 13px;">إجمالي المديونية المستحقة على العملاء: ${formatMoney(totalDebt)} ج.م</span>
        <span style="display: block; color: #666; margin-top: 2px;">عدد العملاء المدينين: ${debtCustomers.length} عميل (مرتبين من الأعلى مديونية إلى الأقل)</span>
      </div>

      <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 15px;">
        <thead>
          <tr style="background: #881337; color: #fff; text-align: right;">
            <th style="padding: 6px; text-align: center; width: 30px;">#</th>
            <th style="padding: 6px;">كود العميل</th>
            <th style="padding: 6px;">اسم العميل</th>
            <th style="padding: 6px; text-align: center;">يوم الزيارة</th>
            <th style="padding: 6px;">الهاتف</th>
            <th style="padding: 6px;">العنوان</th>
            <th style="padding: 6px; text-align: left;">رصيد المديونية</th>
          </tr>
        </thead>
        <tbody>
          ${
            debtCustomers.length > 0
              ? debtCustomers
                  .map(
                    (c, idx) => `
              <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 6px; text-align: center;">${idx + 1}</td>
                <td style="padding: 6px; font-family: monospace;">${c.id}</td>
                <td style="padding: 6px; font-weight: bold;">${c.name}</td>
                <td style="padding: 6px; text-align: center;">${c.dayOfWeek}</td>
                <td style="padding: 6px; font-family: monospace;">${c.phone || '-'}</td>
                <td style="padding: 6px; font-size: 10px;">${c.address || '-'}</td>
                <td style="padding: 6px; text-align: left; font-family: monospace; font-weight: 900; color: #e11d48; font-size: 13px;">${formatMoney(c.balance)} ج.م</td>
              </tr>
            `
                  )
                  .join('')
              : '<tr><td colspan="7" style="padding: 15px; text-align: center; color: #059669; font-weight: bold;">لا توجد أي مديونيات متأخرة على العملاء</td></tr>'
          }
        </tbody>
        <tfoot>
          <tr style="background: #f1f5f9; font-weight: 900; border-top: 2px solid #000;">
            <td colspan="6" style="padding: 8px; text-align: right;">الإجمالي الكلي للمديونية:</td>
            <td style="padding: 8px; text-align: left; font-size: 14px; color: #e11d48;">${formatMoney(totalDebt)} ج.م</td>
          </tr>
        </tfoot>
      </table>
      ${signOffHtml}
    `;
  } else if (type === 'profit') {
    title = 'تقرير تحليل هوامش الربحية والتكلفة';
    const totalSales = dateInvoices.reduce((a, i) => a + Number(i.grandTotal || 0), 0);
    const totalReturns = dateReturns.reduce((a, r) => a + Number(r.amount || 0), 0);
    const prodMap = new Map(data.products.map((p) => [p.id, p]));
    const dateInvIds = new Set(dateInvoices.map((i) => i.id));
    const relevantItems = data.invoiceItems.filter((i) => dateInvIds.has(i.invoiceId));

    let costOfGoods = 0;
    for (const item of relevantItems) {
      const prod = prodMap.get(item.productId);
      costOfGoods += (prod?.cost || 0) * (item.qty || 0);
    }
    const netProfit = Math.max(0, totalSales - costOfGoods - totalReturns);
    const profitMargin = totalSales > 0 ? Math.round((netProfit / totalSales) * 100) : 0;

    contentHtml = `
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px; font-size: 11px;">
        <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
          <div style="color: #64748b;">إجمالي قيمة المبيعات</div>
          <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: #0284c7;">${formatMoney(totalSales)} ج.م</div>
        </div>
        <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
          <div style="color: #64748b;">تكلفة البضاعة المباعة (COGS)</div>
          <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: #334155;">${formatMoney(costOfGoods)} ج.م</div>
        </div>
        <div style="border: 1px solid #ccc; border-radius: 8px; padding: 8px; text-align: center; background: #f8fafc;">
          <div style="color: #64748b;">خصم المرتجعات</div>
          <div style="font-size: 16px; font-weight: 900; margin-top: 4px; color: #e11d48;">${formatMoney(totalReturns)} ج.م</div>
        </div>
        <div style="border: 2px solid #059669; border-radius: 8px; padding: 8px; text-align: center; background: #ecfdf5;">
          <div style="color: #059669; font-weight: bold;">صافي الربح التقديري (${profitMargin}%)</div>
          <div style="font-size: 17px; font-weight: 900; margin-top: 4px; color: #059669;">${formatMoney(netProfit)} ج.م</div>
        </div>
      </div>

      <h3 style="font-size: 13px; margin: 15px 0 6px; border-right: 3px solid #059669; padding-right: 6px;">تفاصيل بنود فواتير المبيعات والتكلفة</h3>
      <table style="width: 100%; border-collapse: collapse; font-size: 10px; margin-bottom: 15px;">
        <thead>
          <tr style="background: #0f172a; color: #fff; text-align: right;">
            <th style="padding: 5px;">الصنف</th>
            <th style="padding: 5px; text-align: center;">الكمية</th>
            <th style="padding: 5px; text-align: left;">سعر التكلفة</th>
            <th style="padding: 5px; text-align: left;">سعر البيع</th>
            <th style="padding: 5px; text-align: left;">إجمالي التكلفة</th>
            <th style="padding: 5px; text-align: left;">إجمالي البيع</th>
            <th style="padding: 5px; text-align: left;">الربح المحقق</th>
          </tr>
        </thead>
        <tbody>
          ${
            relevantItems.length > 0
              ? relevantItems
                  .map((item) => {
                    const prod = prodMap.get(item.productId);
                    const costVal = (prod?.cost || 0) * item.qty;
                    const saleVal = item.lineTotal;
                    const profitVal = saleVal - costVal;
                    return `
              <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 5px; font-weight: bold;">${item.name}</td>
                <td style="padding: 5px; text-align: center;">${item.qty}</td>
                <td style="padding: 5px; text-align: left; font-family: monospace;">${formatMoney(prod?.cost || 0)}</td>
                <td style="padding: 5px; text-align: left; font-family: monospace;">${formatMoney(item.price)}</td>
                <td style="padding: 5px; text-align: left; font-family: monospace;">${formatMoney(costVal)}</td>
                <td style="padding: 5px; text-align: left; font-family: monospace; font-weight: bold;">${formatMoney(saleVal)}</td>
                <td style="padding: 5px; text-align: left; font-family: monospace; font-weight: bold; color: ${profitVal >= 0 ? '#059669' : '#e11d48'};">${formatMoney(profitVal)}</td>
              </tr>
            `;
                  })
                  .join('')
              : '<tr><td colspan="7" style="padding: 15px; text-align: center; color: #888;">لا توجد بنود مبيعات لهذا التاريخ</td></tr>'
          }
        </tbody>
      </table>
      ${signOffHtml}
    `;
  } else {
    title = `تقرير ${type}`;
    contentHtml = `<p>تاريخ التقرير: ${date} — ${companyName}</p>${signOffHtml}`;
  }

  printReportDocument(title, subtitle, contentHtml);
}
