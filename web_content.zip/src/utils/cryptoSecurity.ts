export interface PasswordOptions {
  length: number;
  includeUppercase: boolean;
  includeLowercase: boolean;
  includeNumbers: boolean;
  includeSymbols: boolean;
  excludeAmbiguous: boolean;
}

const UPPERCASE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const LOWERCASE = 'abcdefghijklmnopqrstuvwxyz';
const NUMBERS = '0123456789';
const SYMBOLS = '!@#$%^&*()_+-=[]{}|;:,.<>?';
const AMBIGUOUS = 'Il1O0';

export function generateSecurePassword(options: PasswordOptions): string {
  let chars = '';
  if (options.includeUppercase) chars += UPPERCASE;
  if (options.includeLowercase) chars += LOWERCASE;
  if (options.includeNumbers) chars += NUMBERS;
  if (options.includeSymbols) chars += SYMBOLS;

  if (options.excludeAmbiguous) {
    chars = chars
      .split('')
      .filter((c) => !AMBIGUOUS.includes(c))
      .join('');
  }

  if (chars.length === 0) {
    chars = LOWERCASE + NUMBERS;
  }

  const length = Math.max(6, Math.min(128, options.length));
  const array = new Uint32Array(length);
  crypto.getRandomValues(array);

  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars[array[i] % chars.length];
  }

  return result;
}

export function calculatePasswordEntropy(pwd: string): { bits: number; strength: 'Very Weak' | 'Weak' | 'Medium' | 'Strong' | 'Very Strong'; score: number } {
  if (!pwd) return { bits: 0, strength: 'Very Weak', score: 0 };

  let poolSize = 0;
  if (/[a-z]/.test(pwd)) poolSize += 26;
  if (/[A-Z]/.test(pwd)) poolSize += 26;
  if (/[0-9]/.test(pwd)) poolSize += 10;
  if (/[^a-zA-Z0-9]/.test(pwd)) poolSize += 32;

  if (poolSize === 0) poolSize = 10;

  const bits = Math.round(pwd.length * (Math.log(poolSize) / Math.LN2));

  let score = 0;
  let strength: 'Very Weak' | 'Weak' | 'Medium' | 'Strong' | 'Very Strong' = 'Very Weak';

  if (bits < 28) {
    score = 1;
    strength = 'Very Weak';
  } else if (bits < 36) {
    score = 2;
    strength = 'Weak';
  } else if (bits < 60) {
    score = 3;
    strength = 'Medium';
  } else if (bits < 80) {
    score = 4;
    strength = 'Strong';
  } else {
    score = 5;
    strength = 'Very Strong';
  }

  return { bits, strength, score };
}

export function generateSecureRandomNumbers(
  min: number,
  max: number,
  count: number,
  unique: boolean = false
): number[] {
  if (min > max) {
    const temp = min;
    min = max;
    max = temp;
  }

  const range = max - min + 1;
  if (range <= 0) return [min];

  if (unique && count > range) {
    count = range;
  }

  const results: number[] = [];
  const set = new Set<number>();

  while (results.length < count) {
    const randomBuffer = new Uint32Array(1);
    crypto.getRandomValues(randomBuffer);
    const val = min + (randomBuffer[0] % range);

    if (unique) {
      if (!set.has(val)) {
        set.add(val);
        results.push(val);
      }
    } else {
      results.push(val);
    }
  }

  return results;
}
