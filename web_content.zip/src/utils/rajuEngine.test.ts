import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateLevelFromXP,
  computeMasteryLevel,
  validateMemoryInput,
  validateTaskInput,
  float32ToBase64Pcm16,
  base64Pcm16ToFloat32,
  getRelevantMemories,
  extractReadableError,
  evaluateSmartAnswer,
  computeWeakTopics,
  buildAntiRepetitionList,
  VOICE_PROFILES,
} from './rajuEngine';
import {
  HIRAGANA_DATA,
  KATAKANA_DATA,
  DAKUTEN_DATA,
  KANJI_DATA,
  CUET_STUDY_SUBJECTS,
  SEED_SMART_QUESTIONS,
} from './japaneseData';

test('calculateLevelFromXP computes accurate level and progress percentage', () => {
  const start = calculateLevelFromXP(0);
  assert.equal(start.level, 1);
  assert.equal(start.progressPercent, 0);

  const mid = calculateLevelFromXP(2937); // 11 * 250 = 2750, remainder 187 -> 75%
  assert.equal(mid.level, 12);
  assert.equal(mid.progressPercent, 75);
});

test('computeMasteryLevel assigns Beginner, Intermediate, Advanced, and Mastered accurately', () => {
  assert.equal(computeMasteryLevel(5, 5), 'Mastered');
  assert.equal(computeMasteryLevel(4, 5), 'Advanced');
  assert.equal(computeMasteryLevel(3, 5), 'Intermediate');
  assert.equal(computeMasteryLevel(1, 5), 'Beginner');
});

test('validateMemoryInput enforces explicit user consent and length bounds', () => {
  const unconsented = validateMemoryInput({
    title: 'Exam Goal',
    content: 'Target CUET 2027',
    category: 'Study Goal',
    userConsented: false,
  });
  assert.equal(unconsented.valid, false);

  const valid = validateMemoryInput({
    title: '  CUET Target  ',
    content: '  Aiming for 100 percentile in Biology and Japanese  ',
    category: 'Study Goal',
    userConsented: true,
  });
  assert.equal(valid.valid, true);
  assert.equal(valid.sanitized?.title, 'CUET Target');
});

test('validateTaskInput validates categories and priorities', () => {
  const invalid = validateTaskInput({
    title: '',
    category: 'Study',
    priority: 'High',
    dueDate: '2026-11-15',
  });
  assert.equal(invalid.valid, false);

  const valid = validateTaskInput({
    title: 'Complete Hiragana & Katakana Quiz',
    category: 'Japanese',
    priority: 'High',
    dueDate: '2026-11-15',
  });
  assert.equal(valid.valid, true);
  assert.equal(valid.sanitized?.category, 'Japanese');
});

test('PCM16 audio encoding and decoding roundtrip preserves waveform', () => {
  const input = new Float32Array([0, 0.5, -0.5, 1.0, -1.0]);
  const b64 = float32ToBase64Pcm16(input);
  const decoded = base64Pcm16ToFloat32(b64);
  assert.equal(decoded.length, input.length);
  assert.ok(Math.abs(decoded[1] - 0.5) < 0.001);
  assert.ok(Math.abs(decoded[2] + 0.5) < 0.001);
});

test('getRelevantMemories filters unconsented items and ranks matching memories first', () => {
  const memories = [
    {
      id: '1',
      ownerId: 'u1',
      title: 'Favorite Language',
      content: 'Studying Japanese N5 and Hindi explanations',
      category: 'Language' as const,
      userConsented: true,
      createdAt: '',
      updatedAt: '',
    },
    {
      id: '2',
      ownerId: 'u1',
      title: 'Biology Exam',
      content: 'Preparing for CUET Biology Molecular Inheritance',
      category: 'Study Goal' as const,
      userConsented: true,
      createdAt: '',
      updatedAt: '',
    },
  ];
  const ranked = getRelevantMemories(memories, 'Help me with CUET Biology DNA');
  assert.equal(ranked[0].id, '2');
});

test('extractReadableError never returns [object Object] and unwraps nested error objects', () => {
  assert.equal(extractReadableError('[object Object]', 'Fallback'), 'Fallback');
  assert.equal(extractReadableError({ error: { message: 'Live session quota exceeded' } }), 'Live session quota exceeded');
  assert.equal(extractReadableError(new Error('Mic permission denied')), 'Mic permission denied');
  assert.equal(extractReadableError({ reason: 'Network timeout' }), 'Network timeout');
});

test('evaluateSmartAnswer grades MCQs, fill-in-the-blanks, translations, and descriptive responses', () => {
  const mcq = SEED_SMART_QUESTIONS[0];
  assert.equal(evaluateSmartAnswer(mcq, '', mcq.correctIndex).isCorrect, true);
  assert.equal(evaluateSmartAnswer(mcq, '', ((mcq.correctIndex ?? 0) + 1) % 4).isCorrect, false);

  const fill = {
    id: 'f1',
    type: 'fill_blank' as const,
    topic: 'Particles',
    difficulty: 'Beginner' as const,
    conceptTag: 'particle-ni',
    question: '学校___行きます。',
    expectedAnswer: 'に',
    acceptableAnswers: ['へ'],
    explanation: 'Use に or へ for direction.',
  };
  assert.equal(evaluateSmartAnswer(fill, 'に').isCorrect, true);
  assert.equal(evaluateSmartAnswer(fill, 'へ').isCorrect, true);
  assert.equal(evaluateSmartAnswer(fill, 'を').isCorrect, false);

  const descriptive = {
    id: 'd1',
    type: 'descriptive' as const,
    topic: 'Particles',
    difficulty: 'Intermediate' as const,
    conceptTag: 'wa-vs-ga',
    question: 'Explain は vs が.',
    expectedAnswer: 'は marks the topic while が marks the grammatical subject and new emphasis.',
    explanation: 'Topic vs subject marker.',
  };
  assert.equal(
    evaluateSmartAnswer(descriptive, 'wa marks the topic whereas ga highlights the grammatical subject emphasis').isCorrect,
    true
  );
  assert.equal(evaluateSmartAnswer(descriptive, 'nothing').isCorrect, false);
});

test('computeWeakTopics and buildAntiRepetitionList detect weak areas (<70%) and prevent repetition', () => {
  const attempts = [
    {
      id: 'a1',
      questionId: 'q1',
      topic: 'Kanji N5',
      conceptTag: 'yama',
      type: 'mcq' as const,
      difficulty: 'Beginner' as const,
      questionText: 'What does 山 mean?',
      userAnswer: 'Water',
      isCorrect: false,
      timestamp: '2026-11-13T00:00:00Z',
    },
    {
      id: 'a2',
      questionId: 'q2',
      topic: 'Kanji N5',
      conceptTag: 'hi',
      type: 'mcq' as const,
      difficulty: 'Beginner' as const,
      questionText: 'What does 日 mean?',
      userAnswer: 'Sun',
      isCorrect: true,
      timestamp: '2026-11-13T00:01:00Z',
    },
    {
      id: 'a3',
      questionId: 'q3',
      topic: 'Hiragana',
      conceptTag: 'a',
      type: 'mcq' as const,
      difficulty: 'Beginner' as const,
      questionText: 'Read あ',
      userAnswer: 'a',
      isCorrect: true,
      timestamp: '2026-11-13T00:02:00Z',
    },
  ];
  const weak = computeWeakTopics(attempts);
  assert.equal(weak[0].topic, 'Kanji N5');
  assert.equal(weak[0].accuracyPercent, 50);
  assert.equal(weak[0].isWeak, true);

  const antiRep = buildAntiRepetitionList(attempts);
  assert.equal(antiRep.length, 3);
  assert.ok(antiRep.includes('What does 山 mean?'));
});

test('Japanese and CUET datasets and 6 Voice Personalities are complete and verified', () => {
  assert.equal(VOICE_PROFILES.length, 6);
  const byId = Object.fromEntries(VOICE_PROFILES.map((v) => [v.id, v]));
  assert.equal(byId['Natural Male'].geminiVoice, 'Charon');
  assert.equal(byId['Natural Female'].geminiVoice, 'Kore');
  assert.equal(byId['Anime Hero'].geminiVoice, 'Fenrir');
  assert.equal(byId['Anime Girl'].geminiVoice, 'Zephyr');
  assert.equal(byId['Japanese Teacher'].geminiVoice, 'Puck');
  assert.equal(byId['My Voice'].isFutureFeature, true);

  assert.equal(HIRAGANA_DATA.length, 46);
  assert.equal(KATAKANA_DATA.length, 46);
  assert.equal(DAKUTEN_DATA.length, 50);
  assert.ok(SEED_SMART_QUESTIONS.length >= 6);
  assert.equal(CUET_STUDY_SUBJECTS.length, 7);

  for (const level of ['N5', 'N4', 'N3', 'N2', 'N1'] as const) {
    assert.ok(KANJI_DATA.some((k) => k.jlpt === level), `Missing JLPT ${level} Kanji`);
  }
  for (const k of KANJI_DATA) {
    assert.ok(k.onyomi.length > 0, `Missing onyomi for ${k.kanji}`);
    assert.ok(k.kunyomi.length > 0, `Missing kunyomi for ${k.kanji}`);
    assert.ok(k.radicals.length > 0, `Missing radicals for ${k.kanji}`);
    assert.ok(k.memoryTrick.length > 0, `Missing memoryTrick for ${k.kanji}`);
    assert.ok(k.strokePaths.length > 0, `Missing strokePaths for ${k.kanji}`);
  }
});
