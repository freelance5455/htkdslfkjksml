import { PaintingReport } from '../types/domain';

/**
 * Genera il Blob in formato Microsoft Excel con formattazione e griglia tabelle complete (MOD. RV-U).
 */
export function generatePaintingReportExcelBlob(report: PaintingReport): Blob {
  const sanitize = (str: any) =>
    String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

  const layersCols = report.layers;
  const numLayers = layersCols.length;
  const totalCols = 1 + numLayers;

  const html = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <style>
        body { font-family: Arial, sans-serif; font-size: 11pt; color: #000000; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
        th, td { border: 1px solid #000000; padding: 6px 8px; vertical-align: middle; }
        .title-company { font-size: 14pt; font-weight: bold; background-color: #1a1a1a; color: #ffffff; text-align: left; }
        .title-report { font-size: 13pt; font-weight: bold; background-color: #f2f2f2; text-align: right; }
        .section-header { font-size: 11pt; font-weight: bold; background-color: #d9d9d9; text-transform: uppercase; }
        .sub-header { font-size: 9pt; color: #555555; font-style: italic; }
        .label-cell { background-color: #f9f9f9; font-weight: bold; font-size: 10pt; color: #333333; width: 220px; }
        .value-cell { font-size: 10pt; }
        .center-cell { text-align: center; }
        .calc-cell { background-color: #fff2cc; font-weight: bold; text-align: center; }
        .ok-cell { color: #0070c0; font-weight: bold; text-align: center; }
        .footer-cell { font-size: 9pt; color: #666666; text-align: center; height: 50px; }
      </style>
    </head>
    <body>
      <!-- INTESTAZIONE AZIENDALE E TITOLO REPORT -->
      <table>
        <tr>
          <td colspan="2" class="title-company">
            SFILLER SABBIATURA &amp; VERNICIATURA A LIQUIDO
            <br/><span style="font-size: 9pt; font-weight: normal; color: #cccccc;">www.sabbiaturaeverniciatura.it</span>
          </td>
          <td colspan="${Math.max(totalCols - 2, 2)}" class="title-report">
            RAPPORTO DI VERNICIATURA / PAINTING REPORT No. <u>${sanitize(report.reportNumber)}</u>
            <br/><span style="font-size: 10pt; font-weight: normal;">Date: <strong>${sanitize(report.date)}</strong></span>
          </td>
        </tr>
      </table>

      <!-- 1. DATI IDENTIFICATIVI -->
      <table>
        <tr>
          <th colspan="${totalCols}" class="section-header">DATI IDENTIFICATIVI / Identification Data</th>
        </tr>
        <tr>
          <td class="label-cell">CLIENTE / Client:</td>
          <td colspan="${totalCols - 1}" class="value-cell"><strong>${sanitize(report.client)}</strong></td>
        </tr>
        <tr>
          <td class="label-cell">SUBFORNITORE / Sub-supplier:</td>
          <td colspan="${totalCols - 1}" class="value-cell">${sanitize(report.subSupplier)}</td>
        </tr>
        <tr>
          <td class="label-cell">COMMESSA-MATRICOLA / Job-Serial No.:</td>
          <td colspan="${totalCols - 1}" class="value-cell" style="font-family: monospace;"><strong>${sanitize(report.jobSerialNumber)}</strong></td>
        </tr>
        <tr>
          <td class="label-cell">N. ORDINE - POS. / Purchase Order N.:</td>
          <td colspan="${totalCols - 1}" class="value-cell">${sanitize(report.purchaseOrderNumber)}</td>
        </tr>
        <tr>
          <td class="label-cell">DENOMINAZIONE ITEM / Item Name:</td>
          <td colspan="${totalCols - 1}" class="value-cell"><strong>${sanitize(report.itemName)}</strong></td>
        </tr>
      </table>

      <!-- 2. PREPARAZIONE SUPERFICIALE -->
      <table>
        <tr>
          <th colspan="${totalCols}" class="section-header">PREPARAZIONE SUPERFICIALE / Surface Preparation</th>
        </tr>
        <tr>
          <td class="label-cell">PREPARZ. SUPERFICIALE:</td>
          <td class="value-cell"><strong>${sanitize(report.surfacePreparationStd)}</strong></td>
          <td class="label-cell">RUGOSITÀ / Incision Profile:</td>
          <td colspan="${Math.max(totalCols - 3, 1)}" class="value-cell"><strong>${sanitize(report.incisionProfile)}</strong></td>
        </tr>
        <tr>
          <td class="label-cell">TIPO ABRASIVO / Abrasive Type:</td>
          <td class="value-cell">${sanitize(report.abrasiveTypeMesh)}</td>
          <td class="label-cell">PULIZIA SUPERFICIALE / Blast Cleaning:</td>
          <td colspan="${Math.max(totalCols - 3, 1)}" class="value-cell"><strong>${sanitize(report.blastCleaningGrade)}</strong></td>
        </tr>
        <tr>
          <td class="label-cell">CONTAMINAZIONI / Contaminants:</td>
          <td class="value-cell">${sanitize(report.abrasiveContaminants)}</td>
          <td class="label-cell">CONTAMINAZIONE POLVERE / Dust:</td>
          <td colspan="${Math.max(totalCols - 3, 1)}" class="value-cell">${sanitize(report.dustTestingGrade)}</td>
        </tr>
      </table>

      <!-- CONDIZIONI AMBIENTE SABBIATURA -->
      <table>
        <tr>
          <th colspan="4" class="section-header" style="background-color: #ebebeb; font-size: 10pt;">
            CONDIZIONI AMBIENTE SABBIATURA / Weather Conditions
          </th>
        </tr>
        <tr class="center-cell" style="font-weight: bold; background-color: #f7f7f7;">
          <td>DATA</td>
          <td>TEMPERATURA ARIA</td>
          <td>TEMPERATURA SUPERFICIE</td>
          <td style="background-color: #fff2cc;">PUNTO DI RUGIADA (CALCOLATO)</td>
        </tr>
        <tr class="center-cell">
          <td>${sanitize(report.surfacePrepWeather.date)}</td>
          <td>${report.surfacePrepWeather.airTemperature} °C</td>
          <td>${report.surfacePrepWeather.surfaceTemperature} °C</td>
          <td class="calc-cell">${report.surfacePrepWeather.dewPoint} °C (OK)</td>
        </tr>
      </table>

      <!-- 3. VERNICIATURA COATING -->
      <table>
        <tr>
          <th colspan="${totalCols}" class="section-header">
            VERNICIATURA / Coating
            <span style="font-size: 9pt; font-weight: normal; text-transform: none;">
              (SPEC: ${sanitize(report.paintingSpecification)} | CICLO: ${sanitize(report.paintSystem)})
            </span>
          </th>
        </tr>
        <tr style="background-color: #fff2cc; font-weight: bold;">
          <td class="label-cell">Strato n° / Coat No.</td>
          ${layersCols.map((l) => `<td class="center-cell">${sanitize(l.coatType)}<br/><span style="font-size: 9pt; font-weight: normal;">REQ'D DFT ${l.requiredDftUm} µm</span></td>`).join('')}
        </tr>
        <tr>
          <td class="label-cell">NOME PRODOTTO / Paint Name</td>
          ${layersCols.map((l) => `<td class="center-cell"><strong>${sanitize(l.paintName)}</strong></td>`).join('')}
        </tr>
        <tr>
          <td class="label-cell">LOTTO COMP. A / Batch No. A</td>
          ${layersCols.map((l) => `<td class="center-cell" style="font-family: monospace;">${sanitize(l.batchCompA)}</td>`).join('')}
        </tr>
        <tr>
          <td class="label-cell">LOTTO COMP. B / Batch No. B</td>
          ${layersCols.map((l) => `<td class="center-cell" style="font-family: monospace;">${sanitize(l.batchCompB)}</td>`).join('')}
        </tr>
        <tr>
          <td class="label-cell">COLORE / Color</td>
          ${layersCols.map((l) => `<td class="center-cell">${sanitize(l.color)}</td>`).join('')}
        </tr>
        <tr>
          <td class="label-cell">METODO DI APPLIC. / Method</td>
          ${layersCols.map((l) => `<td class="center-cell"><strong>${sanitize(l.applicationMethod)}</strong></td>`).join('')}
        </tr>
        <tr>
          <td class="label-cell">DATA / Date</td>
          ${layersCols.map((l) => `<td class="center-cell">${sanitize(l.date)}</td>`).join('')}
        </tr>
        <tr>
          <td class="label-cell">TEMP-ARIA / Air Temperature</td>
          ${layersCols.map((l) => `<td class="center-cell">${l.airTemp} °C</td>`).join('')}
        </tr>
        <tr>
          <td class="label-cell">UMIDITÀ RELATIVA / Rel. Humidity</td>
          ${layersCols.map((l) => `<td class="center-cell">${l.relativeHumidity} %</td>`).join('')}
        </tr>
        <tr>
          <td class="label-cell">TEMP-SUPERFICIE / Surface Temp.</td>
          ${layersCols.map((l) => `<td class="center-cell">${l.surfaceTemp} °C</td>`).join('')}
        </tr>
        <tr style="background-color: #fff2cc;">
          <td class="label-cell" style="background-color: #ffe599;">PUNTO DI RUGIADA / Dew Point (CALC)</td>
          ${layersCols.map((l) => `<td class="calc-cell">${l.dewPoint} °C (ΔT ${Math.round((l.surfaceTemp - l.dewPoint) * 10) / 10}°C)</td>`).join('')}
        </tr>
        <tr style="background-color: #f2f2f2;">
          <td class="label-cell">SPESSORE FILM SEC. (DFT Med/Min/Max)</td>
          ${layersCols.map((l) => `<td class="center-cell"><strong>Med: ${l.dftMeasured.med} µm</strong><br/><span style="font-size: 8pt; color: #555;">Min: ${l.dftMeasured.min} / Max: ${l.dftMeasured.max} µm</span></td>`).join('')}
        </tr>
      </table>

      <!-- 4. CONTROLLI / Testing -->
      <table>
        <tr>
          <th colspan="${totalCols}" class="section-header">CONTROLLI / Testing</th>
        </tr>
        <tr>
          <td class="label-cell">ESAME VISIVO / Visual Check</td>
          ${layersCols.map((l) => `<td class="ok-cell">${sanitize(l.visualCheck)}</td>`).join('')}
        </tr>
        <tr>
          <td class="label-cell">SPESSORE FILM SECCO / DFT Av</td>
          ${layersCols.map((l) => `<td class="ok-cell">${sanitize(l.dftCheck)}</td>`).join('')}
        </tr>
        <tr>
          <td class="label-cell">PROVA DI ADESIONE / Pull-Off Test</td>
          ${layersCols.map((l, i) => `<td class="center-cell">${i === layersCols.length - 1 ? sanitize(l.pullOffTest) : '-'}</td>`).join('')}
        </tr>
      </table>

      <!-- 5. NOTE E STRUMENTI -->
      <table>
        <tr>
          <th colspan="${totalCols}" class="section-header">NOTE / Remarks (Strumenti Tarati)</th>
        </tr>
        <tr>
          <td colspan="${totalCols}" style="font-family: monospace; font-size: 9pt; background-color: #fafafa; padding: 10px;">
            ${sanitize(report.instrumentNotes).replace(/\n/g, '<br/>')}
            ${report.generalRemarks ? `<br/><br/><strong>Osservazioni:</strong> ${sanitize(report.generalRemarks)}` : ''}
          </td>
        </tr>
      </table>

      <!-- 6. COLLAUDO & FIRME -->
      <table>
        <tr>
          <th class="section-header" style="width: 25%;">COLLAUDO SABBIATURA &amp; VERNICIATURA SFILLER</th>
          <th class="section-header" style="width: 25%;">CONTROLLO Q.TA' / Quality Control</th>
          <th class="section-header" style="width: 25%;">ENTE DI COLLAUDO / Inspection Agency</th>
          <th class="section-header" style="width: 25%;">ISPETTORE CLIENTE / Customer Inspector</th>
        </tr>
        <tr>
          <td class="footer-cell">
            <strong>${sanitize(report.signoffs.companyInspection.name)}</strong>
            <br/>DATA: ${sanitize(report.signoffs.companyInspection.date)} - <em>F.to Regolarmente</em>
          </td>
          <td class="footer-cell">
            <strong>${sanitize(report.signoffs.qualityControl.name)}</strong>
            <br/>DATA: ${sanitize(report.signoffs.qualityControl.date)} - <em>F.to Regolarmente</em>
          </td>
          <td class="footer-cell">
            ${report.signoffs.inspectionAgency?.signed ? `<strong>${sanitize(report.signoffs.inspectionAgency.name)}</strong><br/>DATA: ${sanitize(report.signoffs.inspectionAgency.date)}` : 'N.A. / Non Richiesto'}
          </td>
          <td class="footer-cell">
            ${report.signoffs.customerInspector?.signed ? `<strong>${sanitize(report.signoffs.customerInspector.name)}</strong><br/>DATA: ${sanitize(report.signoffs.customerInspector.date)}` : 'In attesa'}
          </td>
        </tr>
      </table>

      <div style="font-size: 8pt; color: #888888; text-align: right;">
        MOD. RV-U Rev 0 del 12/04/2013 - Conforme a ISO 12944 / ISO 8501-3
      </div>
    </body>
    </html>
  `;

  return new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8' });
}

/**
 * Esporta il Painting Report in formato Microsoft Excel con formattazione e griglia tabelle complete (MOD. RV-U).
 * Genera un file .xls compatibile con Microsoft Excel, LibreOffice Calc e Google Fogli.
 */
export function exportPaintingReportToExcel(report: PaintingReport): void {
  const blob = generatePaintingReportExcelBlob(report);
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  const safeFilename = (report.reportNumber || 'PaintingReport').replace(/[^a-zA-Z0-9_-]/g, '_');
  link.href = url;
  link.download = `Painting_Report_${safeFilename}.xls`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
