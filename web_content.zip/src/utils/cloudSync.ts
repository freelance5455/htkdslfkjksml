import type {
  CloudSyncManifest,
  ComicEntry,
  ReadStatus,
  SyncedComicRecord,
} from '../types/comic';
import { computeComicSyncKey } from './libraryDb';

const SYNC_FILE_NAME = 'koma-reader-sync-v1.json';

export interface RemoteSyncState {
  fileId: string | null;
  modifiedTime?: string;
  manifest: CloudSyncManifest | null;
}

export interface SyncDiffSummary {
  remoteFileId: string | null;
  mergedManifest: CloudSyncManifest;
  updatedLocalComics: ComicEntry[];
  pulledCount: number;
  pushedCount: number;
  pulledTitles: string[];
  pushedTitles: string[];
}

function getDeviceLabel(): string {
  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : '';
  if (/android/i.test(ua)) return 'Android Tablet / Phone';
  if (/ipad|iphone/i.test(ua)) return 'iOS / iPadOS';
  return 'Web Browser';
}

function deriveReadStatus(comic: ComicEntry): ReadStatus {
  if (comic.readStatus) return comic.readStatus;
  if (comic.pageCount > 0 && (comic.currentPage >= comic.pageCount - 1 || comic.scrollProgress >= 0.97)) {
    return 'completed';
  }
  if (comic.currentPage > 0 || comic.scrollProgress > 0.01 || comic.lastReadAt) {
    return 'reading';
  }
  return 'unread';
}

export async function pullRemoteManifest(accessToken: string): Promise<RemoteSyncState> {
  const query = encodeURIComponent(`name='${SYNC_FILE_NAME}' and trashed=false`);
  const listRes = await fetch(
    `https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=${query}&fields=files(id,name,modifiedTime)`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    },
  );

  if (listRes.status === 401) {
    throw new Error('GOOGLE_AUTH_EXPIRED');
  }
  if (!listRes.ok) {
    throw new Error(`Google Drive query failed (${listRes.status})`);
  }

  const listJson = (await listRes.json()) as {
    files?: { id: string; name: string; modifiedTime?: string }[];
  };
  const file = listJson.files?.[0];
  if (!file) {
    return { fileId: null, manifest: null };
  }

  const contentRes = await fetch(
    `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(file.id)}?alt=media`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    },
  );
  if (contentRes.status === 401) {
    throw new Error('GOOGLE_AUTH_EXPIRED');
  }
  if (!contentRes.ok) {
    throw new Error(`Failed to download sync data (${contentRes.status})`);
  }

  const manifest = (await contentRes.json()) as CloudSyncManifest;
  return {
    fileId: file.id,
    modifiedTime: file.modifiedTime,
    manifest,
  };
}

export function buildSyncDiff(
  localComics: ComicEntry[],
  remoteState: RemoteSyncState,
): SyncDiffSummary {
  const remoteRecords = remoteState.manifest?.records || {};
  const mergedRecords: Record<string, SyncedComicRecord> = { ...remoteRecords };

  const updatedLocalComics: ComicEntry[] = [];
  const pulledTitles: string[] = [];
  const pushedTitles: string[] = [];

  for (const comic of localComics) {
    const syncKey = computeComicSyncKey(comic);
    const localUpdatedAt = comic.updatedAt || comic.lastReadAt || 0;
    const localRecord: SyncedComicRecord = {
      syncKey,
      fileName: comic.fileName,
      displayTitle: comic.displayTitle,
      pageCount: comic.pageCount,
      currentPage: comic.currentPage,
      scrollProgress: comic.scrollProgress,
      scrollOffsetY: comic.scrollOffsetY ?? 0,
      scrollRatio: comic.scrollRatio ?? comic.scrollProgress ?? 0,
      readStatus: deriveReadStatus(comic),
      lastReadAt: comic.lastReadAt || 0,
      updatedAt: localUpdatedAt,
      userBookmarks: comic.userBookmarks || [],
    };

    const remote = remoteRecords[syncKey];

    if (!remote) {
      // Only push local comics that have reading activity, bookmarks, or dirty changes
      if (
        comic.syncDirty ||
        localRecord.currentPage > 0 ||
        localRecord.scrollProgress > 0 ||
        localRecord.readStatus !== 'unread' ||
        localRecord.userBookmarks.length > 0
      ) {
        mergedRecords[syncKey] = {
          ...localRecord,
          updatedAt: localUpdatedAt || Date.now(),
        };
        pushedTitles.push(comic.displayTitle);
      }
      if (comic.syncDirty) {
        updatedLocalComics.push({ ...comic, syncKey, syncDirty: false });
      }
      continue;
    }

    if (remote.updatedAt > localUpdatedAt && !comic.syncDirty) {
      // Remote is newer -> update local comic metadata
      pulledTitles.push(comic.displayTitle);
      updatedLocalComics.push({
        ...comic,
        syncKey,
        currentPage: Math.min(Math.max(0, comic.pageCount - 1), remote.currentPage),
        scrollProgress: remote.scrollProgress,
        scrollOffsetY: remote.scrollOffsetY,
        scrollRatio: remote.scrollRatio,
        readStatus: remote.readStatus,
        lastReadAt: remote.lastReadAt,
        updatedAt: remote.updatedAt,
        userBookmarks: remote.userBookmarks || [],
        syncDirty: false,
      });
    } else if (remote.updatedAt > localUpdatedAt && comic.syncDirty) {
      // Both modified: compare actual timestamps
      if (localUpdatedAt >= remote.updatedAt) {
        mergedRecords[syncKey] = localRecord;
        pushedTitles.push(comic.displayTitle);
        updatedLocalComics.push({ ...comic, syncKey, syncDirty: false });
      } else {
        pulledTitles.push(comic.displayTitle);
        updatedLocalComics.push({
          ...comic,
          syncKey,
          currentPage: Math.min(Math.max(0, comic.pageCount - 1), remote.currentPage),
          scrollProgress: remote.scrollProgress,
          scrollOffsetY: remote.scrollOffsetY,
          scrollRatio: remote.scrollRatio,
          readStatus: remote.readStatus,
          lastReadAt: remote.lastReadAt,
          updatedAt: remote.updatedAt,
          userBookmarks: remote.userBookmarks || [],
          syncDirty: false,
        });
      }
    } else if (localUpdatedAt > remote.updatedAt || comic.syncDirty) {
      mergedRecords[syncKey] = {
        ...localRecord,
        updatedAt: localUpdatedAt || Date.now(),
      };
      pushedTitles.push(comic.displayTitle);
      updatedLocalComics.push({ ...comic, syncKey, syncDirty: false });
    }
  }

  const mergedManifest: CloudSyncManifest = {
    version: 1,
    lastSyncedAt: Date.now(),
    deviceLabel: getDeviceLabel(),
    records: mergedRecords,
  };

  return {
    remoteFileId: remoteState.fileId,
    mergedManifest,
    updatedLocalComics,
    pulledCount: pulledTitles.length,
    pushedCount: pushedTitles.length,
    pulledTitles,
    pushedTitles,
  };
}

export async function pushRemoteManifest(
  accessToken: string,
  manifest: CloudSyncManifest,
  existingFileId?: string | null,
): Promise<{ fileId: string }> {
  const payload = JSON.stringify(manifest);

  if (existingFileId) {
    const res = await fetch(
      `https://www.googleapis.com/upload/drive/v3/files/${encodeURIComponent(existingFileId)}?uploadType=media`,
      {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: payload,
      },
    );
    if (res.status === 401) throw new Error('GOOGLE_AUTH_EXPIRED');
    if (!res.ok) throw new Error(`Failed to update Google Drive sync file (${res.status})`);
    const json = (await res.json()) as { id: string };
    return { fileId: json.id || existingFileId };
  }

  // Create new file inside private appDataFolder
  const boundary = `koma_boundary_${Date.now().toString(36)}`;
  const metadata = JSON.stringify({
    name: SYNC_FILE_NAME,
    parents: ['appDataFolder'],
    mimeType: 'application/json',
  });

  const body =
    `--${boundary}\r\n` +
    `Content-Type: application/json; charset=UTF-8\r\n\r\n` +
    `${metadata}\r\n` +
    `--${boundary}\r\n` +
    `Content-Type: application/json\r\n\r\n` +
    `${payload}\r\n` +
    `--${boundary}--`;

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body,
    },
  );
  if (res.status === 401) throw new Error('GOOGLE_AUTH_EXPIRED');
  if (!res.ok) throw new Error(`Failed to create Google Drive sync file (${res.status})`);
  const json = (await res.json()) as { id: string };
  return { fileId: json.id };
}

export async function deleteRemoteManifest(
  accessToken: string,
  fileId: string,
): Promise<void> {
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}`,
    {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${accessToken}` },
    },
  );
  if (res.status === 401) throw new Error('GOOGLE_AUTH_EXPIRED');
  if (!res.ok && res.status !== 404) {
    throw new Error(`Failed to delete Google Drive sync data (${res.status})`);
  }
}
