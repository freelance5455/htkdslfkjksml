/**
 * Cloud Sync & Multi-Device Authentication Service
 * Allows users to register a User ID, log in across multiple devices or after switching phones,
 * and automatically keep all accounts, transactions, and settings synchronized.
 */

import { UserProfile } from '../types';
import { storage, ExportDataEnvelope } from './storage';

export interface CloudAuthResponse {
  success: boolean;
  userId?: string;
  profile?: UserProfile;
  data?: ExportDataEnvelope;
  lastSyncedAt?: string;
  error?: string;
  message?: string;
}

export const cloudSyncService = {
  /**
   * Check if a proposed User ID is available
   */
  async checkUserIdAvailability(userId: string): Promise<{ available: boolean; exists: boolean; error?: string }> {
    const cleanId = (userId || '').trim().replace(/\s+/g, '_');
    if (cleanId.length < 3) {
      return { available: false, exists: false, error: 'User ID must be at least 3 characters' };
    }

    try {
      const res = await fetch(`/api/auth/check-user?userId=${encodeURIComponent(cleanId)}`);
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { available: false, exists: false, error: data.error || 'Check failed' };
      }
      return { available: !!data.available, exists: !!data.exists };
    } catch (err: any) {
      console.warn('Network error checking user ID:', err);
      // If offline or network fails, assume locally ok
      return { available: true, exists: false };
    }
  },

  /**
   * Register a new User ID on the server with current device data
   */
  async register(
    userId: string,
    password: string,
    profile: UserProfile,
    dataEnvelope?: ExportDataEnvelope
  ): Promise<CloudAuthResponse> {
    const cleanId = (userId || '').trim();
    const cleanPassword = (password || '').trim();

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: cleanId,
          password: cleanPassword,
          profile: {
            ...profile,
            userId: cleanId,
            isCloudSynced: true,
          },
          dataEnvelope: dataEnvelope || storage.exportBackupFile(),
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          error: data.error || 'রেজিস্ট্রেশন করতে ব্যর্থ হয়েছে',
        };
      }

      // Store cloud credentials in userProfile and storage
      const updatedProfile: UserProfile = {
        ...profile,
        userId: cleanId,
        cloudPassword: cleanPassword,
        isCloudSynced: true,
        lastSyncedAt: data.lastSyncedAt || new Date().toISOString(),
      };
      storage.saveUserProfile(updatedProfile);

      return {
        success: true,
        userId: cleanId,
        profile: updatedProfile,
        lastSyncedAt: data.lastSyncedAt,
        message: data.message,
      };
    } catch (err: any) {
      console.error('Register network error:', err);
      return {
        success: false,
        error: 'সার্ভারের সাথে সংযোগ করা সম্ভব হয়নি। অনুগ্রহ করে ইন্টারনেট সংযোগ পরীক্ষা করুন।',
      };
    }
  },

  /**
   * Login with an existing User ID & Password (e.g. on a new phone or second device)
   * Fetches all previous cloud data and restores it.
   */
  async login(userId: string, password: string): Promise<CloudAuthResponse> {
    const cleanId = (userId || '').trim();
    const cleanPassword = (password || '').trim();

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: cleanId,
          password: cleanPassword,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          error: data.error || 'লগইন ব্যর্থ হয়েছে। আইডি ও পাসওয়ার্ড সঠিক কিনা যাচাই করুন।',
        };
      }

      // If previous data exists in the cloud, import it into local storage
      if (data.data) {
        storage.importBackupFile(data.data);
      }

      // Save user profile with linked cloud credentials
      const updatedProfile: UserProfile = {
        ...(data.profile || storage.getUserProfile()),
        userId: cleanId,
        cloudPassword: cleanPassword,
        isCloudSynced: true,
        lastSyncedAt: data.lastSyncedAt || new Date().toISOString(),
      };
      storage.saveUserProfile(updatedProfile);

      return {
        success: true,
        userId: cleanId,
        profile: updatedProfile,
        data: data.data,
        lastSyncedAt: data.lastSyncedAt,
        message: data.message || 'সকল পূর্বের হিসাব ও তথ্য সফলভাবে সিঙ্ক সম্পন্ন হয়েছে!',
      };
    } catch (err: any) {
      console.error('Login network error:', err);
      return {
        success: false,
        error: 'সার্ভারের সাথে সংযোগ স্থাপন করা যায়নি। অনুগ্রহ করে ইন্টারনেট সংযোগ পরীক্ষা করুন।',
      };
    }
  },

  /**
   * Push current device updates to the cloud (automatic sync)
   */
  async pushSync(profile?: UserProfile): Promise<{ success: boolean; lastSyncedAt?: string; error?: string }> {
    const currentProfile = profile || storage.getUserProfile();
    const { userId, cloudPassword } = currentProfile;

    if (!userId || !cloudPassword) {
      return { success: false, error: 'No cloud account linked' };
    }

    try {
      const dataEnvelope = storage.exportBackupFile();
      const res = await fetch('/api/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          password: cloudPassword,
          dataEnvelope,
          profile: currentProfile,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Push sync failed' };
      }

      // Update lastSyncedAt locally
      const updatedProfile = {
        ...currentProfile,
        lastSyncedAt: data.lastSyncedAt || new Date().toISOString(),
      };
      storage.saveUserProfile(updatedProfile);

      return { success: true, lastSyncedAt: data.lastSyncedAt };
    } catch (err: any) {
      console.warn('Background push sync failed:', err);
      return { success: false, error: err?.message };
    }
  },

  /**
   * Pull latest changes from the cloud (e.g. on app launch to check for updates from another device)
   */
  async pullSync(profile?: UserProfile): Promise<{ success: boolean; data?: ExportDataEnvelope; error?: string }> {
    const currentProfile = profile || storage.getUserProfile();
    const { userId, cloudPassword } = currentProfile;

    if (!userId || !cloudPassword) {
      return { success: false, error: 'No cloud account linked' };
    }

    try {
      const res = await fetch('/api/sync/pull', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          password: cloudPassword,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Pull sync failed' };
      }

      if (data.data) {
        storage.importBackupFile(data.data);
      }

      const updatedProfile = {
        ...currentProfile,
        ...(data.profile || {}),
        userId,
        cloudPassword,
        lastSyncedAt: data.lastSyncedAt || new Date().toISOString(),
      };
      storage.saveUserProfile(updatedProfile);

      return { success: true, data: data.data };
    } catch (err: any) {
      console.warn('Background pull sync failed:', err);
      return { success: false, error: err?.message };
    }
  },

  /**
   * Helper to generate a friendly random User ID suggestion
   */
  generateSuggestedUserId(name?: string): string {
    const base = (name || 'user')
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]/g, '');
    const prefix = base.length >= 2 ? base.slice(0, 8) : 'onu';
    const randNum = Math.floor(1000 + Math.random() * 9000);
    return `${prefix}_${randNum}`;
  },
};
