import {
  StylusToolType,
  StylusPoint,
  StylusStroke,
  StylusSettings,
  SmartEraserFilterMode,
  BoundedFrame,
} from "../types";
import { calculateStrokeWidth, calculateStrokeOpacity } from "./digitalInkEngine";

/**
 * Interface for Custom Palette Configuration
 */
export interface CustomPaletteConfig {
  id: string;
  name: string;
  description: string;
  colors: string[];
  strokeWidths: number[];
  pressureCurve: "linear" | "sensitive" | "firm" | "dynamic";
  smoothingLevel: "off" | "standard" | "cubic_bezier_gpu";
}

export const DEFAULT_CUSTOM_PALETTES: CustomPaletteConfig[] = [
  {
    id: "academic_work",
    name: "Kombinasyon 1 - İş & Akademik",
    description: "Kömür siyahı, safir mavisi, zümrüt yeşili ve kırmızı vurgular",
    colors: ["#0F172A", "#0284C7", "#059669", "#E11D48", "#7C3AED"],
    strokeWidths: [2, 4, 8, 16],
    pressureCurve: "sensitive",
    smoothingLevel: "cubic_bezier_gpu",
  },
  {
    id: "creative_neon",
    name: "Kombinasyon 2 - Yaratıcı & Neon",
    description: "Parlak neon sarı, kehribar, mor ve siber cam göbeği",
    colors: ["#FACC15", "#D97706", "#9333EA", "#06B6D4", "#EC4899"],
    strokeWidths: [3, 6, 12, 24],
    pressureCurve: "dynamic",
    smoothingLevel: "cubic_bezier_gpu",
  },
  {
    id: "custom_user_palette",
    name: "Kombinasyon 3 - Özelleştirilmiş Paletim",
    description: "Kendi seçtiğiniz özel renkler ve kalem ayarları",
    colors: ["#1E293B", "#2563EB", "#10B981", "#F59E0B", "#EF4444"],
    strokeWidths: [2, 5, 10, 20],
    pressureCurve: "linear",
    smoothingLevel: "cubic_bezier_gpu",
  },
];

const CUSTOM_PALETTE_STORAGE_KEY = "noteflow_custom_palettes_v1";

/**
 * Storage manager for custom palette configurations
 */
export class CustomPaletteManager {
  public static getPalettes(): CustomPaletteConfig[] {
    if (typeof window === "undefined") return DEFAULT_CUSTOM_PALETTES;
    try {
      const saved = localStorage.getItem(CUSTOM_PALETTE_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (err) {
      console.warn("Failed to load custom palettes", err);
    }
    return DEFAULT_CUSTOM_PALETTES;
  }

  public static savePalettes(palettes: CustomPaletteConfig[]): void {
    if (typeof window === "undefined") return;
    try {
      localStorage.setItem(CUSTOM_PALETTE_STORAGE_KEY, JSON.stringify(palettes));
    } catch (err) {
      console.warn("Failed to save custom palettes", err);
    }
  }

  public static updatePalette(id: string, updated: Partial<CustomPaletteConfig>): void {
    const current = this.getPalettes();
    const index = current.findIndex((p) => p.id === id);
    if (index !== -1) {
      current[index] = { ...current[index], ...updated };
      this.savePalettes(current);
    }
  }
}

/**
 * GPU-Accelerated Cubic Bezier Drawing Engine
 * Low latency, getHistoricalX/Y coalesced point extraction, dynamic pressure,
 * Active Recall Tape, Layer Manager, Smart Eraser filtering & Night Mode Ink Inversion.
 */
export class CanvasDrawingEngine {
  /**
   * Adapts ink color for dark/night mode without losing vibrant tones.
   * Inverts deep blacks/dark slates to crisp high-contrast off-white,
   * while keeping highlighters, blues, and neon colors intact.
   */
  public static adaptColorForTheme(hexColor: string, isDarkMode: boolean): string {
    if (!isDarkMode || !hexColor) return hexColor;
    const cleanHex = hexColor.trim().toUpperCase();

    // Pure black or dark blue-grays in dark mode become high-contrast light ink
    if (["#000000", "#0F172A", "#1E293B", "#18181B", "#0A0A0A", "#111827", "#334155"].includes(cleanHex)) {
      return "#F8FAFC";
    }

    // Pure white in dark mode remains white
    if (["#FFFFFF", "#F8FAFC"].includes(cleanHex)) {
      return "#FFFFFF";
    }

    return hexColor;
  }

  /**
   * Extracts historical / coalesced motion points from hardware touch & stylus sensors.
   * Equivalent to Android MotionEvent getHistoricalX/Y API.
   */
  public static extractCoalescedPoints(
    e: PointerEvent | React.PointerEvent,
    canvasRect: DOMRect
  ): StylusPoint[] {
    const points: StylusPoint[] = [];
    const nativeEv = ((e as any).nativeEvent || e) as PointerEvent;

    if (typeof nativeEv.getCoalescedEvents === "function") {
      const coalesced = nativeEv.getCoalescedEvents();
      if (coalesced && coalesced.length > 0) {
        coalesced.forEach((cp) => {
          points.push({
            x: cp.clientX - canvasRect.left,
            y: cp.clientY - canvasRect.top,
            pressure: cp.pressure > 0 ? cp.pressure : 0.5,
            tiltX: cp.tiltX || 0,
            tiltY: cp.tiltY || 0,
            timestamp: cp.timeStamp,
          });
        });
        return points;
      }
    }

    const pressure = e.pressure > 0 ? e.pressure : 0.5;
    points.push({
      x: e.clientX - canvasRect.left,
      y: e.clientY - canvasRect.top,
      pressure,
      tiltX: e.tiltX || 0,
      tiltY: e.tiltY || 0,
      timestamp: e.timeStamp || Date.now(),
    });

    return points;
  }

  /**
   * Calculates dynamic stroke width based on pen tool and pen pressure.
   */
  public static getPressureWidth(
    baseSize: number,
    pressure: number,
    tool: StylusToolType,
    sensitivity: number = 1.0
  ): number {
    return calculateStrokeWidth(baseSize, pressure, tool, sensitivity);
  }

  /**
   * Renders a stroke with GPU-accelerated Cubic Bezier curves onto a Canvas context.
   * Supports Active Recall Tape (scratch & reveal tape), Highlighters, and Adaptive Ink.
   */
  public static drawSmoothStroke(
    ctx: CanvasRenderingContext2D,
    stroke: StylusStroke,
    settings: StylusSettings,
    isDarkMode: boolean = false
  ) {
    if (!stroke.points || stroke.points.length === 0) return;

    ctx.save();
    const effectiveColor = settings.adaptiveNightModeInk
      ? this.adaptColorForTheme(stroke.color, isDarkMode)
      : stroke.color;

    ctx.lineCap =
      stroke.tool === "highlighter" || stroke.tool === "technical" || stroke.tool === "recall_tape"
        ? "square"
        : "round";
    ctx.lineJoin =
      stroke.tool === "highlighter" || stroke.tool === "technical" || stroke.tool === "recall_tape"
        ? "miter"
        : "round";

    if (stroke.tool === "highlighter" || stroke.tool === "watercolor") {
      ctx.globalCompositeOperation = isDarkMode ? "screen" : "multiply";
    } else if (stroke.tool === "eraser") {
      ctx.globalCompositeOperation = "destination-out";
    } else {
      ctx.globalCompositeOperation = "source-over";
    }

    // Neon Glow and Laser Marker special effects
    if (stroke.tool === "neon_glow") {
      ctx.shadowColor = effectiveColor;
      ctx.shadowBlur = 14;
    } else if (stroke.tool === "laser_marker") {
      ctx.shadowColor = effectiveColor || "#EF4444";
      ctx.shadowBlur = 18;
    }

    // Recall Tape special styling (Active Recall adhesive band)
    if (stroke.tool === "recall_tape") {
      const isRevealed = stroke.isRevealed;
      ctx.strokeStyle = effectiveColor || settings.recallTapeColor || "#F59E0B";
      ctx.fillStyle = effectiveColor || settings.recallTapeColor || "#F59E0B";

      if (isRevealed) {
        // Semi-transparent when revealed so underlying text is readable
        ctx.globalAlpha = 0.16;
        ctx.setLineDash([4, 4]);
      } else {
        // Fully opaque scratch tape covering the text
        ctx.globalAlpha = 0.98;
      }
    } else if (stroke.tool === "lasso_cut") {
      ctx.setLineDash([6, 4]);
      ctx.strokeStyle = "#0D9488";
      ctx.fillStyle = "rgba(13, 148, 136, 0.15)";
    } else {
      ctx.strokeStyle = effectiveColor;
      ctx.fillStyle = effectiveColor;
    }

    const points = stroke.points;

    if (points.length === 1) {
      const pt = points[0];
      const w = this.getPressureWidth(stroke.size, pt.pressure, stroke.tool, settings.pressureSensitivity);
      if (stroke.tool !== "recall_tape") {
        ctx.globalAlpha = calculateStrokeOpacity(stroke.tool, pt.pressure);
      }
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, w / 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      return;
    }

    if (points.length === 2) {
      const p0 = points[0];
      const p1 = points[1];
      const w = this.getPressureWidth(stroke.size, p1.pressure, stroke.tool, settings.pressureSensitivity);
      ctx.lineWidth = w;
      if (stroke.tool !== "recall_tape") {
        ctx.globalAlpha = calculateStrokeOpacity(stroke.tool, p1.pressure);
      }
      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y);
      ctx.lineTo(p1.x, p1.y);
      ctx.stroke();
      if (stroke.tool === "lasso_cut") {
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
      return;
    }

    // GPU Cubic Bezier Curve Rendering
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);

    for (let i = 0; i < points.length - 1; i++) {
      const p0 = points[i === 0 ? i : i - 1];
      const p1 = points[i];
      const p2 = points[i + 1];
      const p3 = points[i + 2 < points.length ? i + 2 : i + 1];

      // Compute Cubic Bezier Control Points C1 and C2
      const cp1x = p1.x + (p2.x - p0.x) / 6;
      const cp1y = p1.y + (p2.y - p0.y) / 6;
      const cp2x = p2.x - (p3.x - p1.x) / 6;
      const cp2y = p2.y - (p3.y - p1.y) / 6;

      const w = this.getPressureWidth(stroke.size, p1.pressure, stroke.tool, settings.pressureSensitivity);
      ctx.lineWidth = w;
      if (stroke.tool !== "recall_tape") {
        ctx.globalAlpha = calculateStrokeOpacity(stroke.tool, p1.pressure);
      }

      ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, p2.x, p2.y);
    }

    ctx.stroke();

    if (stroke.tool === "lasso_cut" && points.length > 5) {
      ctx.closePath();
      ctx.fill();
    }

    // If Recall Tape is not revealed, draw subtle diagonal lines / tape tag indicating interactive recall
    if (stroke.tool === "recall_tape" && !stroke.isRevealed && points.length > 2) {
      const midIdx = Math.floor(points.length / 2);
      const midPoint = points[midIdx];
      ctx.save();
      ctx.fillStyle = "rgba(255, 255, 255, 0.9)";
      ctx.font = "bold 9px sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("TAP TO REVEAL 👁️", midPoint.x, midPoint.y);
      ctx.restore();
    }

    ctx.restore();
  }

  /**
   * Layer Manager: Renders canvas objects with strict Z-index hierarchy:
   * Z=0: Grid / Bounded Frames
   * Z=1: Highlighter strokes
   * Z=2: Text boxes
   * Z=3: Ink strokes (fountain, ballpoint, etc.)
   * Z=4: Active Recall Tapes (covers everything underneath until tapped)
   */
  public static renderLayerHierarchical(
    ctx: CanvasRenderingContext2D,
    strokes: StylusStroke[],
    settings: StylusSettings,
    isDarkMode: boolean = false
  ) {
    // 1. Z=1: Highlighter strokes
    const highlighters = strokes.filter((s) => s.tool === "highlighter");
    highlighters.forEach((h) => this.drawSmoothStroke(ctx, h, settings, isDarkMode));

    // 2. Z=3: Normal Ink strokes & tools
    const normalStrokes = strokes.filter(
      (s) => s.tool !== "highlighter" && s.tool !== "recall_tape"
    );
    normalStrokes.forEach((st) => this.drawSmoothStroke(ctx, st, settings, isDarkMode));

    // 3. Z=4: Active Recall Tape (top layer covering ink)
    const tapes = strokes.filter((s) => s.tool === "recall_tape");
    tapes.forEach((t) => this.drawSmoothStroke(ctx, t, settings, isDarkMode));
  }

  /**
   * Checks if a point hits any Active Recall Tape on the canvas to toggle its revealed state.
   */
  public static findRecallTapeHit(
    x: number,
    y: number,
    strokes: StylusStroke[],
    sensitivity: number = 24
  ): StylusStroke | null {
    const tapes = strokes.filter((s) => s.tool === "recall_tape");
    for (let i = tapes.length - 1; i >= 0; i--) {
      const tape = tapes[i];
      const hit = tape.points.some((pt) => {
        const dx = pt.x - x;
        const dy = pt.y - y;
        return Math.sqrt(dx * dx + dy * dy) <= (tape.size * 2 + sensitivity);
      });
      if (hit) return tape;
    }
    return null;
  }

  /**
   * Smart Eraser with Layer Filtering:
   * 'all': erases all touched strokes.
   * 'ink_only': erases only regular ink strokes (keeps highlighter & recall tapes intact).
   * 'highlighter_only': erases only highlighter strokes (leaves ink untouched!).
   * 'tape_only': erases only active recall tapes.
   */
  public static filterStrokesWithSmartEraser(
    strokes: StylusStroke[],
    eraseX: number,
    eraseY: number,
    eraserRadius: number,
    filterMode: SmartEraserFilterMode
  ): StylusStroke[] {
    return strokes.filter((stroke) => {
      // Check if this stroke matches the active filter mode
      if (filterMode === "ink_only" && (stroke.tool === "highlighter" || stroke.tool === "recall_tape")) {
        return true; // Keep untouched
      }
      if (filterMode === "highlighter_only" && stroke.tool !== "highlighter") {
        return true; // Keep untouched
      }
      if (filterMode === "tape_only" && stroke.tool !== "recall_tape") {
        return true; // Keep untouched
      }

      // Check proximity collision with eraser point
      const isHit = stroke.points.some((p) => {
        const dx = p.x - eraseX;
        const dy = p.y - eraseY;
        return Math.sqrt(dx * dx + dy * dy) <= eraserRadius;
      });

      return !isHit;
    });
  }

  /**
   * Renders Bounded Frames (A4, B5, PDF pages) inside an infinite canvas.
   */
  public static drawBoundedFrames(
    ctx: CanvasRenderingContext2D,
    frames: BoundedFrame[],
    isDarkMode: boolean
  ) {
    if (!frames || frames.length === 0) return;

    frames.forEach((f) => {
      ctx.save();
      // Drop Shadow
      ctx.shadowColor = isDarkMode ? "rgba(0, 0, 0, 0.6)" : "rgba(0, 0, 0, 0.12)";
      ctx.shadowBlur = 16;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 4;

      // Frame background
      ctx.fillStyle = isDarkMode ? "#18181B" : "#FFFFFF";
      ctx.fillRect(f.x, f.y, f.width, f.height);

      // Frame border
      ctx.shadowColor = "transparent";
      ctx.strokeStyle = isDarkMode ? "rgba(255, 255, 255, 0.12)" : "rgba(0, 0, 0, 0.1)";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(f.x, f.y, f.width, f.height);

      // Page Badge / Title
      ctx.fillStyle = isDarkMode ? "rgba(255, 255, 255, 0.4)" : "rgba(0, 0, 0, 0.4)";
      ctx.font = "bold 11px sans-serif";
      ctx.textAlign = "left";
      ctx.fillText(`${f.title} (${f.type.toUpperCase()})`, f.x + 16, f.y - 8);

      ctx.restore();
    });
  }

  /**
   * Renders a live micro signature stroke preview for a specific pen tool into a canvas element.
   * Perfect for Palette Popups & Profile Pen Settings.
   */
  public static renderToolPreviewCanvas(
    canvas: HTMLCanvasElement,
    tool: StylusToolType,
    color: string,
    size: number = 6
  ) {
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = canvas.width || 80;
    const height = canvas.height || 36;

    ctx.clearRect(0, 0, width, height);

    // Sample points forming a smooth "S" wave curve
    const points: StylusPoint[] = [
      { x: 8, y: height * 0.7, pressure: 0.25, timestamp: 1 },
      { x: width * 0.3, y: height * 0.2, pressure: 0.6, timestamp: 2 },
      { x: width * 0.7, y: height * 0.8, pressure: 0.9, timestamp: 3 },
      { x: width - 8, y: height * 0.3, pressure: 0.4, timestamp: 4 },
    ];

    const previewStroke: StylusStroke = {
      id: "preview",
      tool,
      color,
      size,
      opacity: calculateStrokeOpacity(tool, 0.8),
      points,
    };

    const dummySettings: StylusSettings = {
      palmRejection: "strict",
      doubleTapAction: "eraser",
      smoothingEnabled: true,
      pressureSensitivity: 1.0,
      gridSnapping: false,
      autoOCR: false,
      engineType: "universal",
      hapticFeedback: false,
      activeEraserFilter: "all",
      activeFramePreset: "infinite",
      adaptiveNightModeInk: true,
      bidirectionalLinksEnabled: true,
      recallTapeColor: "#F59E0B",
    };

    this.drawSmoothStroke(ctx, previewStroke, dummySettings);
  }
}

