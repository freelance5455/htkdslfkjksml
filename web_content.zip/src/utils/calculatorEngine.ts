import { AngleMode } from '../types';

export class CalculatorError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CalculatorError';
  }
}

function factorial(n: number): number {
  if (n < 0 || !Number.isInteger(n)) {
    throw new CalculatorError('Factorial requires non-negative integer');
  }
  if (n > 170) {
    throw new CalculatorError('Result overflow');
  }
  let res = 1;
  for (let i = 2; i <= n; i++) {
    res *= i;
  }
  return res;
}

export function evaluateExpression(expr: string, angleMode: AngleMode = 'deg'): number {
  if (!expr || expr.trim() === '') {
    throw new CalculatorError('Empty expression');
  }

  // Pre-process expression
  let clean = expr
    .replace(/\s+/g, '')
    .replace(/×/g, '*')
    .replace(/÷/g, '/')
    .replace(/π/g, `${Math.PI}`)
    .replace(/\be\b/g, `${Math.E}`);

  // Handle implicit multiplication: e.g. 2(3) -> 2*(3) or (2)(3) -> (2)*(3)
  clean = clean.replace(/(\d)(\()/g, '$1*$2');
  clean = clean.replace(/(\))(\d)/g, '$1*$2');
  clean = clean.replace(/(\))(\()/g, '$1*$2');

  const tokens = tokenize(clean);
  const rpn = shuntingYard(tokens);
  return evaluateRPN(rpn, angleMode);
}

type TokenType = 'NUMBER' | 'OPERATOR' | 'FUNCTION' | 'LPAREN' | 'RPAREN';

interface Token {
  type: TokenType;
  value: string;
}

function tokenize(input: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;

  const functions = ['sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'sqrt', 'cbrt', 'ln', 'log', 'abs'];

  while (i < input.length) {
    const char = input[i];

    // Check functions
    let matchedFunc = false;
    for (const fn of functions) {
      if (input.startsWith(fn, i)) {
        tokens.push({ type: 'FUNCTION', value: fn });
        i += fn.length;
        matchedFunc = true;
        break;
      }
    }
    if (matchedFunc) continue;

    // Check Numbers (including decimal point)
    if (/[0-9.]/.test(char)) {
      let numStr = '';
      let hasDot = false;
      while (i < input.length && /[0-9.]/.test(input[i])) {
        if (input[i] === '.') {
          if (hasDot) throw new CalculatorError('Invalid decimal number');
          hasDot = true;
        }
        numStr += input[i];
        i++;
      }
      tokens.push({ type: 'NUMBER', value: numStr });
      continue;
    }

    // Check Parentheses
    if (char === '(') {
      tokens.push({ type: 'LPAREN', value: '(' });
      i++;
      continue;
    }
    if (char === ')') {
      tokens.push({ type: 'RPAREN', value: ')' });
      i++;
      continue;
    }

    // Check unary minus vs binary minus
    if (char === '-') {
      const prevToken = tokens[tokens.length - 1];
      const isUnary = !prevToken || prevToken.type === 'OPERATOR' || prevToken.type === 'LPAREN';
      if (isUnary) {
        tokens.push({ type: 'OPERATOR', value: 'neg' });
        i++;
        continue;
      }
    }

    // Check Operators
    if (['+', '-', '*', '/', '%', '^', '!'].includes(char)) {
      tokens.push({ type: 'OPERATOR', value: char });
      i++;
      continue;
    }

    throw new CalculatorError(`Unexpected character: ${char}`);
  }

  return tokens;
}

const PRECEDENCE: Record<string, number> = {
  '+': 1,
  '-': 1,
  '*': 2,
  '/': 2,
  '%': 2,
  'neg': 3,
  '^': 4,
  '!': 5,
};

const IS_RIGHT_ASSOCIATIVE: Record<string, boolean> = {
  '^': true,
  'neg': true,
};

function shuntingYard(tokens: Token[]): Token[] {
  const output: Token[] = [];
  const opStack: Token[] = [];

  for (const token of tokens) {
    if (token.type === 'NUMBER') {
      output.push(token);
    } else if (token.type === 'FUNCTION') {
      opStack.push(token);
    } else if (token.type === 'OPERATOR') {
      const op1 = token.value;
      while (opStack.length > 0) {
        const top = opStack[opStack.length - 1];
        if (top.type === 'FUNCTION') {
          output.push(opStack.pop()!);
          continue;
        }
        if (top.type === 'OPERATOR') {
          const op2 = top.value;
          const p1 = PRECEDENCE[op1] || 0;
          const p2 = PRECEDENCE[op2] || 0;
          const isRightAssoc = IS_RIGHT_ASSOCIATIVE[op1] || false;

          if ((!isRightAssoc && p1 <= p2) || (isRightAssoc && p1 < p2)) {
            output.push(opStack.pop()!);
            continue;
          }
        }
        break;
      }
      opStack.push(token);
    } else if (token.type === 'LPAREN') {
      opStack.push(token);
    } else if (token.type === 'RPAREN') {
      let foundMatchingLparen = false;
      while (opStack.length > 0) {
        const top = opStack.pop()!;
        if (top.type === 'LPAREN') {
          foundMatchingLparen = true;
          break;
        }
        output.push(top);
      }
      if (!foundMatchingLparen) {
        throw new CalculatorError('Mismatched parentheses');
      }
      if (opStack.length > 0 && opStack[opStack.length - 1].type === 'FUNCTION') {
        output.push(opStack.pop()!);
      }
    }
  }

  while (opStack.length > 0) {
    const top = opStack.pop()!;
    if (top.type === 'LPAREN' || top.type === 'RPAREN') {
      throw new CalculatorError('Mismatched parentheses');
    }
    output.push(top);
  }

  return output;
}

function evaluateRPN(rpn: Token[], angleMode: AngleMode): number {
  const stack: number[] = [];

  const toRad = (val: number) => (angleMode === 'deg' ? (val * Math.PI) / 180 : val);
  const fromRad = (val: number) => (angleMode === 'deg' ? (val * 180) / Math.PI : val);

  for (const token of rpn) {
    if (token.type === 'NUMBER') {
      stack.push(parseFloat(token.value));
    } else if (token.type === 'OPERATOR') {
      if (token.value === '!') {
        if (stack.length < 1) throw new CalculatorError('Invalid expression');
        const a = stack.pop()!;
        stack.push(factorial(a));
      } else if (token.value === 'neg') {
        if (stack.length < 1) throw new CalculatorError('Invalid expression');
        const a = stack.pop()!;
        stack.push(-a);
      } else {
        if (stack.length < 2) throw new CalculatorError('Invalid expression');
        const b = stack.pop()!;
        const a = stack.pop()!;
        switch (token.value) {
          case '+':
            stack.push(a + b);
            break;
          case '-':
            stack.push(a - b);
            break;
          case '*':
            stack.push(a * b);
            break;
          case '/':
            if (b === 0) throw new CalculatorError('Cannot divide by zero');
            stack.push(a / b);
            break;
          case '%':
            stack.push(a % b);
            break;
          case '^':
            stack.push(Math.pow(a, b));
            break;
          default:
            throw new CalculatorError(`Unknown operator: ${token.value}`);
        }
      }
    } else if (token.type === 'FUNCTION') {
      if (stack.length < 1) throw new CalculatorError('Invalid expression');
      const a = stack.pop()!;
      switch (token.value) {
        case 'sin':
          stack.push(Math.sin(toRad(a)));
          break;
        case 'cos':
          stack.push(Math.cos(toRad(a)));
          break;
        case 'tan': {
          const cosVal = Math.cos(toRad(a));
          if (Math.abs(cosVal) < 1e-12) throw new CalculatorError('Undefined tangent');
          stack.push(Math.tan(toRad(a)));
          break;
        }
        case 'asin':
          if (a < -1 || a > 1) throw new CalculatorError('Domain error: asin');
          stack.push(fromRad(Math.asin(a)));
          break;
        case 'acos':
          if (a < -1 || a > 1) throw new CalculatorError('Domain error: acos');
          stack.push(fromRad(Math.acos(a)));
          break;
        case 'atan':
          stack.push(fromRad(Math.atan(a)));
          break;
        case 'sqrt':
          if (a < 0) throw new CalculatorError('Domain error: square root of negative number');
          stack.push(Math.sqrt(a));
          break;
        case 'cbrt':
          stack.push(Math.cbrt(a));
          break;
        case 'ln':
          if (a <= 0) throw new CalculatorError('Domain error: ln requires positive number');
          stack.push(Math.log(a));
          break;
        case 'log':
          if (a <= 0) throw new CalculatorError('Domain error: log10 requires positive number');
          stack.push(Math.log10(a));
          break;
        case 'abs':
          stack.push(Math.abs(a));
          break;
        default:
          throw new CalculatorError(`Unknown function: ${token.value}`);
      }
    }
  }

  if (stack.length !== 1) {
    throw new CalculatorError('Invalid expression');
  }

  const result = stack[0];
  if (!Number.isFinite(result)) {
    throw new CalculatorError('Result is non-finite');
  }

  // Round to avoid IEEE 754 precision artifacts (e.g. 0.1 + 0.2 = 0.30000000000000004)
  return Math.round(result * 1e12) / 1e12;
}

// Unit Test Suite for in-app verification & test reporting
export interface TestCase {
  name: string;
  expr: string;
  expected: number | string;
  angleMode?: AngleMode;
  isError?: boolean;
}

export const CALCULATOR_UNIT_TESTS: TestCase[] = [
  { name: 'Basic Addition', expr: '12 + 34', expected: 46 },
  { name: 'Operator Precedence', expr: '2 + 3 * 4', expected: 14 },
  { name: 'Parentheses Handling', expr: '(2 + 3) * 4', expected: 20 },
  { name: 'Decimal Arithmetic', expr: '0.1 + 0.2', expected: 0.3 },
  { name: 'Implicit Multiplication', expr: '3(4 + 2)', expected: 18 },
  { name: 'Negative Numbers', expr: '-5 + 12', expected: 7 },
  { name: 'Unary Minus Chain', expr: '10 - -5', expected: 15 },
  { name: 'Exponents Right-Assoc', expr: '2 ^ 3', expected: 8 },
  { name: 'Square Root', expr: 'sqrt(144)', expected: 12 },
  { name: 'Factorial', expr: '5!', expected: 120 },
  { name: 'Sine (30 degrees)', expr: 'sin(30)', expected: 0.5, angleMode: 'deg' },
  { name: 'Natural Logarithm', expr: 'ln(e)', expected: 1 },
  { name: 'Log base 10', expr: 'log(1000)', expected: 3 },
  { name: 'Division by Zero Guard', expr: '10 / 0', expected: 'Cannot divide by zero', isError: true },
  { name: 'Mismatched Parentheses Guard', expr: '(5 + 3', expected: 'Mismatched parentheses', isError: true },
];

export function runCalculatorUnitTests(): { passed: number; total: number; results: { name: string; passed: boolean; message: string }[] } {
  let passed = 0;
  const results = CALCULATOR_UNIT_TESTS.map((tc) => {
    try {
      const res = evaluateExpression(tc.expr, tc.angleMode || 'deg');
      if (tc.isError) {
        return { name: tc.name, passed: false, message: `Expected error but got ${res}` };
      }
      const isClose = Math.abs(res - (tc.expected as number)) < 1e-6;
      if (isClose) {
        passed++;
        return { name: tc.name, passed: true, message: `Passed (${res})` };
      } else {
        return { name: tc.name, passed: false, message: `Expected ${tc.expected}, got ${res}` };
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (tc.isError) {
        passed++;
        return { name: tc.name, passed: true, message: `Expected error caught: ${msg}` };
      }
      return { name: tc.name, passed: false, message: `Unexpected error: ${msg}` };
    }
  });

  return { passed, total: CALCULATOR_UNIT_TESTS.length, results };
}
