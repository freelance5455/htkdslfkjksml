import {
  LanguageCode,
  TtsVoiceName,
  buildExpressiveTtsStyle,
  APP_GATE_PASSWORD,
  GATE_STORAGE_KEY,
  verifyGatePassword,
} from './srsLogic';

const STORAGE_KEY = 'YTY_SRS_MULTILANG_V1';

let currentAudioElement: HTMLAudioElement | null = null;
let currentAudioRequestId = 0;
let cachedJaVoice: SpeechSynthesisVoice | null = null;
let cachedKoVoice: SpeechSynthesisVoice | null = null;
const ttsAudioCache = new Map<string, string>();

function initVoices() {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  const findVoice = () => {
    const voices = window.speechSynthesis.getVoices() || [];
    cachedJaVoice =
      voices.find(v => v.lang && v.lang.toLowerCase() === 'ja-jp') ||
      voices.find(v => v.lang && v.lang.toLowerCase().startsWith('ja')) ||
      null;
    cachedKoVoice =
      voices.find(v => v.lang && v.lang.toLowerCase() === 'ko-kr') ||
      voices.find(v => v.lang && v.lang.toLowerCase().startsWith('ko')) ||
      null;
  };
  findVoice();
  window.speechSynthesis.onvoiceschanged = findVoice;
}
initVoices();

export function clearTtsAudioCache() {
  ttsAudioCache.forEach(url => {
    try {
      URL.revokeObjectURL(url);
    } catch {
      // ignore
    }
  });
  ttsAudioCache.clear();
}

export function stopAllAudio() {
  currentAudioRequestId++;
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // ignore
    }
  }
  if (currentAudioElement) {
    try {
      currentAudioElement.pause();
      currentAudioElement.currentTime = 0;
    } catch {
      // ignore
    }
    currentAudioElement = null;
  }
}

function base64ToUint8(b64: string): Uint8Array {
  const bin = atob(b64);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return arr;
}

function pcm16ToWav(pcm16: Int16Array, sampleRate: number): Blob {
  const buffer = new ArrayBuffer(44 + pcm16.length * 2);
  const view = new DataView(buffer);
  const writeStr = (off: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i));
  };
  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + pcm16.length * 2, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, 'data');
  view.setUint32(40, pcm16.length * 2, true);
  for (let i = 0; i < pcm16.length; i++) view.setInt16(44 + i * 2, pcm16[i], true);
  return new Blob([buffer], { type: 'audio/wav' });
}

function readStoredTtsPrefs(lang: LanguageCode): {
  customApiKey: string;
  voiceName: TtsVoiceName;
} {
  try {
    if (typeof window !== 'undefined') {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        const customApiKey =
          typeof parsed?.googleApiKey === 'string' ? parsed.googleApiKey.trim() : '';
        const voiceName: TtsVoiceName =
          parsed?.decks?.[lang]?.settings?.ttsVoice || 'Kore';
        return { customApiKey, voiceName };
      }
    }
  } catch {
    // ignore
  }
  return { customApiKey: '', voiceName: 'Kore' };
}

function fallbackBrowserSpeech(cleanText: string, lang: LanguageCode) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    const voices = window.speechSynthesis.getVoices() || [];
    if (lang === 'ko' && !cachedKoVoice) {
      cachedKoVoice =
        voices.find(v => v.lang && v.lang.toLowerCase().startsWith('ko')) || null;
    } else if (lang === 'ja' && !cachedJaVoice) {
      cachedJaVoice =
        voices.find(v => v.lang && v.lang.toLowerCase().startsWith('ja')) || null;
    }

    const utter = new SpeechSynthesisUtterance(cleanText);
    utter.lang = lang === 'ko' ? 'ko-KR' : 'ja-JP';
    utter.rate = 0.95;
    const matchedVoice = lang === 'ko' ? cachedKoVoice : cachedJaVoice;
    if (matchedVoice) {
      utter.voice = matchedVoice;
    }
    window.speechSynthesis.speak(utter);
  } catch {
    // ignore
  }
}

/**
 * Prioritizes Google Neural / Gemini TTS with expressive intonation and emphasis first,
 * using the optional user-supplied Google API Key if configured in Settings, and only
 * falls back to browser speechSynthesis if the neural TTS endpoint is unreachable.
 */
export async function speakTargetText(
  text: string,
  lang: LanguageCode = 'ja',
  overrideOptions?: { customApiKey?: string; voiceName?: TtsVoiceName }
) {
  if (!text) return;
  if (typeof window !== 'undefined') {
    const storedGate = localStorage.getItem(GATE_STORAGE_KEY) || '';
    if (!verifyGatePassword(storedGate)) return;
  }
  const cleanText = text.replace(/\[____\]/g, '').trim();
  if (!cleanText) return;

  stopAllAudio();
  const myRequestId = currentAudioRequestId;

  const stored = readStoredTtsPrefs(lang);
  const customApiKey =
    overrideOptions?.customApiKey !== undefined
      ? overrideOptions.customApiKey.trim()
      : stored.customApiKey;
  const voiceName = overrideOptions?.voiceName || stored.voiceName || 'Kore';
  const stylePrompt = buildExpressiveTtsStyle(cleanText, lang);

  const keyTag = customApiKey ? `custom-${customApiKey.slice(-4)}` : 'default';
  const cacheKey = `${lang}:${voiceName}:${keyTag}:${cleanText}`;

  try {
    if (ttsAudioCache.has(cacheKey)) {
      if (myRequestId !== currentAudioRequestId) return;
      const audio = new Audio(ttsAudioCache.get(cacheKey)!);
      currentAudioElement = audio;
      await audio.play();
      return;
    }

    const res = await fetch('/api/gemini/tts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-gate-password': APP_GATE_PASSWORD,
      },
      body: JSON.stringify({
        text: cleanText,
        lang,
        voiceName,
        stylePrompt,
        customApiKey,
      }),
    });

    if (res.ok) {
      const { audioBase64, mimeType } = await res.json();
      if (audioBase64 && myRequestId === currentAudioRequestId) {
        const bytes = base64ToUint8(audioBase64);
        const isWavHeader =
          bytes.length > 4 &&
          bytes[0] === 0x52 &&
          bytes[1] === 0x49 &&
          bytes[2] === 0x46 &&
          bytes[3] === 0x46;

        let wavBlob: Blob;
        if (isWavHeader) {
          wavBlob = new Blob([bytes.buffer as ArrayBuffer], { type: 'audio/wav' });
        } else {
          const rateMatch = String(mimeType || 'audio/L16;rate=24000').match(/rate=(\d+)/);
          const sampleRate = rateMatch ? parseInt(rateMatch[1], 10) : 24000;
          const pcm16 = new Int16Array(bytes.buffer);
          wavBlob = pcm16ToWav(pcm16, sampleRate);
        }

        const url = URL.createObjectURL(wavBlob);
        ttsAudioCache.set(cacheKey, url);

        if (myRequestId !== currentAudioRequestId) return;
        const audio = new Audio(url);
        currentAudioElement = audio;
        await audio.play();
        return;
      }
    }
  } catch {
    // Fall through to browser speechSynthesis only if neural TTS fails
  }

  if (myRequestId === currentAudioRequestId) {
    fallbackBrowserSpeech(cleanText, lang);
  }
}
