// Screen Wake Lock & Background Audio Keep-Alive Manager for Mobile Browsers
// Keeps alarms and audio active when device is locked or tab goes to background

let wakeLockSentinel: any = null;
let keepAliveAudio: HTMLAudioElement | null = null;
let isWakeLockRequested = false;

// Request Screen Wake Lock (keeps device screen alive and CPU running)
export async function requestScreenWakeLock(): Promise<boolean> {
  if (typeof window === 'undefined') return false;
  isWakeLockRequested = true;

  if ('wakeLock' in navigator) {
    try {
      wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
      wakeLockSentinel.addEventListener('release', () => {
        wakeLockSentinel = null;
      });
      return true;
    } catch (err) {
      console.warn('Wake Lock request error:', err);
      return false;
    }
  }
  return false;
}

// Release Screen Wake Lock
export async function releaseScreenWakeLock(): Promise<void> {
  isWakeLockRequested = false;
  if (wakeLockSentinel) {
    try {
      await wakeLockSentinel.release();
    } catch {
      // ignore
    }
    wakeLockSentinel = null;
  }
}

// Auto re-acquire wake lock if user switches back to tab or device unlocks
if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', async () => {
    if (document.visibilityState === 'visible' && isWakeLockRequested && !wakeLockSentinel) {
      try {
        await requestScreenWakeLock();
      } catch {
        // ignore
      }
    }
  });
}

export function isWakeLockSupported(): boolean {
  return typeof navigator !== 'undefined' && 'wakeLock' in navigator;
}

export function isWakeLockActive(): boolean {
  return wakeLockSentinel !== null;
}

// Play silent inaudible loop to keep the mobile OS audio pipeline active in the background
let silentAudioCtx: AudioContext | null = null;
let silentOscillator: OscillatorNode | null = null;

export function startBackgroundAudioKeepAlive(): void {
  if (typeof window === 'undefined') return;
  try {
    if (!silentAudioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      silentAudioCtx = new AudioCtxClass();
    }
    if (silentAudioCtx.state === 'suspended') {
      silentAudioCtx.resume();
    }
    if (!silentOscillator) {
      silentOscillator = silentAudioCtx.createOscillator();
      const gainNode = silentAudioCtx.createGain();
      // Extremely low inaudible gain
      gainNode.gain.setValueAtTime(0.0001, silentAudioCtx.currentTime);
      silentOscillator.frequency.setValueAtTime(40, silentAudioCtx.currentTime); // Inaudible sub-bass
      silentOscillator.connect(gainNode);
      gainNode.connect(silentAudioCtx.destination);
      silentOscillator.start();
    }
  } catch (e) {
    console.warn('Silent audio keep-alive not available:', e);
  }
}

export function stopBackgroundAudioKeepAlive(): void {
  try {
    if (silentOscillator) {
      silentOscillator.stop();
      silentOscillator.disconnect();
      silentOscillator = null;
    }
  } catch {
    // ignore
  }
}
