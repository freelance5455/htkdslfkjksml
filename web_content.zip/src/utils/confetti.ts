import confetti from 'canvas-confetti';

/**
 * Trigger a minimal, classy celebratory micro-burst for day completion
 */
export function triggerDayCompletedCelebration(originX = 0.5, originY = 0.5) {
  try {
    confetti({
      particleCount: 35,
      spread: 60,
      startVelocity: 25,
      origin: { x: originX, y: originY },
      colors: ['#10b981', '#34d399', '#6ee7b7', '#f4f4f5', '#a1a1aa'],
      ticks: 150,
      gravity: 0.9,
      scalar: 0.8,
      shapes: ['circle'],
      disableForReducedMotion: true,
    });
  } catch (e) {
    // Graceful fallback
  }
}

/**
 * Trigger a smooth, festive celebration when completing the entire week
 */
export function triggerWeekCompletedCelebration() {
  try {
    confetti({
      particleCount: 65,
      spread: 80,
      startVelocity: 30,
      origin: { x: 0.5, y: 0.4 },
      colors: ['#10b981', '#34d399', '#fbbf24', '#f59e0b', '#ffffff'],
      ticks: 200,
      gravity: 0.85,
      scalar: 0.9,
      shapes: ['circle'],
      disableForReducedMotion: true,
    });
  } catch (e) {
    // Graceful fallback
  }
}
