import confetti from 'canvas-confetti';

export function triggerCelebration(originY = 0.7) {
  try {
    confetti({
      particleCount: 40,
      spread: 60,
      origin: { y: originY },
      colors: ['#6366f1', '#8b5cf6', '#38bdf8', '#10b981', '#f59e0b'],
      disableForReducedMotion: true,
    });
  } catch {
    // Fail gracefully if canvas isn't available
  }
}

export function triggerBigCelebration() {
  try {
    const end = Date.now() + 1000;
    const colors = ['#6366f1', '#a855f7', '#ec4899', '#38bdf8', '#10b981'];

    (function frame() {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0, y: 0.7 },
        colors,
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1, y: 0.7 },
        colors,
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    })();
  } catch {
    // Graceful fallback
  }
}
