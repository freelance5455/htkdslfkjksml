import test from 'node:test';
import assert from 'node:assert/strict';
import {
  addDaysToDate,
  calculateCommitteeSummaries,
  calculateLeaveBalances,
  calculateLoanSummaries,
  calculatePurchaseAmounts,
  evaluateFormula,
  getLeaveYearForDate,
  summarizePurchases,
} from './calculations';
import type {
  CommitteeAccount,
  CommitteeTransaction,
  LeaveRecord,
  LoanPerson,
  LoanTransaction,
  PurchaseRecord,
} from '../types';

test('Purchase Maund-to-KG conversion and both rate-unit formulas', () => {
  const perMaund = calculatePurchaseAmounts(3200, 'per_maund', 2.5, 40);
  assert.equal(perMaund.equivalentKg, 100);
  assert.equal(perMaund.totalAmount, 8000);

  const perKg = calculatePurchaseAmounts(85, 'per_kg', 2.5, 40);
  assert.equal(perKg.equivalentKg, 100);
  assert.equal(perKg.totalAmount, 8500);

  const list: PurchaseRecord[] = [
    {
      id: 'p1',
      date: '2026-11-01',
      rate: 3200,
      rateUnit: 'per_maund',
      quantityMaund: 2,
      equivalentKg: 80,
      totalAmount: 6400,
      supplier: 'Mill A',
      paymentStatus: 'Paid',
      remarks: '',
      createdAt: '',
      updatedAt: '',
    },
    {
      id: 'p2',
      date: '2026-11-10',
      rate: 90,
      rateUnit: 'per_kg',
      quantityMaund: 2,
      equivalentKg: 80,
      totalAmount: 7200,
      supplier: 'Mill B',
      paymentStatus: 'Pending',
      remarks: '',
      createdAt: '',
      updatedAt: '',
    },
  ];
  const summary = summarizePurchases(list, 40);
  assert.equal(summary.totalMaund, 4);
  assert.equal(summary.totalKg, 160);
  assert.equal(summary.totalAmount, 13600);
  assert.equal(summary.avgRatePerMaund, 3400);
});

test('Leave July–June leave year bounds and CL/SL balances', () => {
  assert.equal(getLeaveYearForDate('2026-07-01'), '2026-2027');
  assert.equal(getLeaveYearForDate('2026-11-20'), '2026-2027');
  assert.equal(getLeaveYearForDate('2027-06-30'), '2026-2027');
  assert.equal(getLeaveYearForDate('2026-06-15'), '2025-2026');

  const leaves: LeaveRecord[] = [
    {
      id: 'l1',
      date: '2026-08-10',
      leaveYear: '2026-2027',
      employee: 'Saif Ullah',
      type: 'CL',
      days: 2,
      reason: 'Personal work',
      status: 'Approved',
      createdAt: '',
      updatedAt: '',
    },
    {
      id: 'l2',
      date: '2026-09-05',
      leaveYear: '2026-2027',
      employee: 'Saif Ullah',
      type: 'SL',
      days: 1,
      reason: 'Fever',
      status: 'Approved',
      createdAt: '',
      updatedAt: '',
    },
  ];

  const bal = calculateLeaveBalances(leaves, '2026-2027', undefined, 10, 8, 40, '2026-11-20');
  assert.equal(bal.clRemaining, 8);
  assert.equal(bal.slRemaining, 7);
  assert.equal(bal.cplAvail, 0);
  assert.equal(bal.totalRemaining, 15);
});

test('CPL Due adds to CPL Avail, FIFO 40-day expiry consumes oldest first and excludes expired lots', () => {
  const leaves: LeaveRecord[] = [
    {
      id: 'due1',
      date: '2026-09-01', // expires 2026-10-11 (expired by 2026-11-20)
      leaveYear: '2026-2027',
      employee: 'Saif Ullah',
      type: 'CPL_DUE',
      days: 2,
      expiryDate: addDaysToDate('2026-09-01', 40),
      reason: 'Sunday duty',
      status: 'Approved',
      createdAt: '',
      updatedAt: '',
    },
    {
      id: 'used1',
      date: '2026-09-20', // consumes 1 from due1 before it expires
      leaveYear: '2026-2027',
      employee: 'Saif Ullah',
      type: 'CPL_USED',
      days: 1,
      reason: 'Comp off',
      status: 'Approved',
      createdAt: '',
      updatedAt: '',
    },
    {
      id: 'due2',
      date: '2026-11-05', // expires 2026-12-15 (valid on 2026-11-20)
      leaveYear: '2026-2027',
      employee: 'Saif Ullah',
      type: 'CPL_DUE',
      days: 3,
      expiryDate: addDaysToDate('2026-11-05', 40),
      reason: 'Holiday shift',
      status: 'Approved',
      createdAt: '',
      updatedAt: '',
    },
    {
      id: 'used2',
      date: '2026-11-15', // consumes 1 from due2
      leaveYear: '2026-2027',
      employee: 'Saif Ullah',
      type: 'CPL_USED',
      days: 1,
      reason: 'Rest day',
      status: 'Approved',
      createdAt: '',
      updatedAt: '',
    },
  ];

  const bal = calculateLeaveBalances(leaves, '2026-2027', undefined, 10, 8, 40, '2026-11-20');
  assert.equal(bal.cplDueTotal, 5);
  assert.equal(bal.cplUsedTotal, 2);
  assert.equal(bal.cplExpiredTotal, 1); // 1 unused day from due1 expired
  assert.equal(bal.cplAvail, 2); // 3 - 1 from due2
  assert.equal(bal.totalRemaining, 20); // 10 CL + 8 SL + 2 CPL
});

test('Loan Payable equals Opening + Received - Repaid and is completely separate from Committee', () => {
  const persons: LoanPerson[] = [
    { id: 'lp1', name: 'Ahmed', openingBalance: 5000, notes: '', createdAt: '' },
  ];
  const loanTxs: LoanTransaction[] = [
    {
      id: 'lt1',
      personId: 'lp1',
      personName: 'Ahmed',
      loanDate: '2026-11-01',
      transactionDate: '2026-11-01',
      type: 'received',
      amount: 50000,
      description: 'Home repair',
      paymentMethod: 'Cash',
      remarks: '',
      createdAt: '',
      updatedAt: '',
    },
    {
      id: 'lt2',
      personId: 'lp1',
      personName: 'Ahmed',
      loanDate: '2026-11-01',
      transactionDate: '2026-11-15',
      type: 'repaid',
      amount: 15000,
      description: 'Part repayment',
      paymentMethod: 'Bank Transfer',
      remarks: '',
      createdAt: '',
      updatedAt: '',
    },
  ];

  const loanSummary = calculateLoanSummaries(persons, loanTxs);
  assert.equal(loanSummary.totalLoanPayable, 40000); // 5000 + 50000 - 15000

  const committees: CommitteeAccount[] = [
    {
      id: 'c1',
      title: 'Office Committee 2026',
      personOrGroup: 'Factory Staff',
      totalAmount: 100000,
      installmentAmount: 10000,
      startDate: '2026-08-01',
      totalInstallments: 10,
      frequency: 'Monthly',
      dueDay: '5th of month',
      openingBalance: 0,
      direction: 'payable',
      remarks: '',
      createdAt: '',
      updatedAt: '',
    },
  ];
  const comTxs: CommitteeTransaction[] = [
    {
      id: 'ct1',
      committeeId: 'c1',
      committeeTitle: 'Office Committee 2026',
      date: '2026-11-05',
      type: 'Installment',
      amount: 10000,
      paymentMethod: 'Cash',
      remarks: '',
      createdAt: '',
      updatedAt: '',
    },
  ];

  const comSummary = calculateCommitteeSummaries(committees, comTxs);
  assert.equal(comSummary.totalInstallmentsPaid, 10000);
  assert.equal(comSummary.totalRemainingToPay, 90000);
  assert.equal(comSummary.perCommittee[0].installmentsPaidCount, 1);
  assert.equal(comSummary.perCommittee[0].installmentsRemainingCount, 9);
  assert.equal(comSummary.perCommittee[0].statusLabel, 'To Pay');
  // Loan Payable remains strictly 40000
  assert.equal(loanSummary.totalLoanPayable, 40000);
});

test('Safe formula evaluator handles field tokens and arithmetic', () => {
  assert.equal(evaluateFormula('{qty} * {rate}', { qty: 5, rate: 240 }), 1200);
  assert.equal(evaluateFormula('({a} + {b}) * 0.5', { a: 10, b: 20 }), 15);
  assert.equal(evaluateFormula('{total} / {zero}', { total: 100, zero: 0 }), 0);
});
