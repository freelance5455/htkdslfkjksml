import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatIQD,
  formatDateArabic,
  getDaysUntilExpiry,
  calculateMedicineStocks,
  getNearestExpiryForSale,
  calculateDebts,
  calculateProfitReport,
} from './calculations.ts';
import type { PurchaseItem, SaleItem, ExpenseItem, DebtPayment } from '../types/pharmacy.ts';

test('formatIQD formats numbers into Iraqi Dinar correctly', () => {
  assert.equal(formatIQD(15000), '15,000 د.ع');
  assert.equal(formatIQD(1250750), '1,250,750 د.ع');
  assert.equal(formatIQD(0), '0 د.ع');
});

test('formatDateArabic formats YYYY-MM-DD into DD/MM/YYYY', () => {
  assert.equal(formatDateArabic('2026-10-20'), '20/10/2026');
  assert.equal(formatDateArabic(''), '-');
});

test('getDaysUntilExpiry calculates remaining days accurately', () => {
  const mockToday = new Date('2026-10-20T12:00:00');
  // Expiry in 10 days
  assert.equal(getDaysUntilExpiry('2026-10-30', mockToday), 10);
  // Expiry in the past
  assert.equal(getDaysUntilExpiry('2026-10-10', mockToday), -10);
  // Expiry today
  assert.equal(getDaysUntilExpiry('2026-10-20', mockToday), 0);
});

test('calculateMedicineStocks computes weighted average cost and FEFO remaining batches', () => {
  const mockPurchases: PurchaseItem[] = [
    {
      id: 'p1',
      date: '2026-09-01',
      supplier: 'مذخر الرشيد',
      barcode: '62911001',
      medicineName: 'Panadol Extra',
      qty: 100,
      unitPrice: 2000,
      totalAmount: 200000,
      expiryDate: '2027-01-01',
      amountPaid: 200000,
      remainingUnpaid: 0,
      createdAt: 1,
    },
    {
      id: 'p2',
      date: '2026-09-15',
      supplier: 'مذخر باب المعظم',
      barcode: '62911001',
      medicineName: 'Panadol Extra',
      qty: 100,
      unitPrice: 2400,
      totalAmount: 240000,
      expiryDate: '2026-12-01', // Earlier expiry!
      amountPaid: 140000,
      remainingUnpaid: 100000,
      createdAt: 2,
    },
  ];

  const mockSales: SaleItem[] = [
    {
      id: 's1',
      date: '2026-10-01',
      buyer: 'صيدلية الشفاء',
      barcode: '62911001',
      medicineName: 'Panadol Extra',
      qty: 50,
      unitPrice: 3000,
      totalAmount: 150000,
      avgCostAtSale: 2200,
      amountPaid: 100000,
      remainingUnpaid: 50000,
      createdAt: 3,
    },
  ];

  const mockToday = new Date('2026-10-20T12:00:00');
  const stocks = calculateMedicineStocks(mockPurchases, mockSales, { '62911001': 20 }, mockToday);
  const panadol = stocks['62911001'];

  assert.ok(panadol, 'Panadol stock item exists');
  assert.equal(panadol.totalBought, 200);
  assert.equal(panadol.totalSold, 50);
  assert.equal(panadol.remaining, 150);

  // Total spend = 200000 + 240000 = 440000 for 200 units -> Weighted Average Cost = 2200
  assert.equal(panadol.averageCost, 2200);
  assert.equal(panadol.stockValue, 150 * 2200); // 330,000 د.ع

  // Earliest expiry batch is 2026-12-01 (from p2)
  assert.equal(panadol.nearestExpiry, '2026-12-01');
  // Days to expiry from 2026-10-20 to 2026-12-01 is 42 days <= 90 -> isNearExpiry should be true
  assert.equal(panadol.isNearExpiry, true);
});

test('getNearestExpiryForSale returns advisory info for the sales screen', () => {
  const mockPurchases: PurchaseItem[] = [
    {
      id: 'p1',
      date: '2026-09-01',
      supplier: 'مذخر الرشيد',
      barcode: '62911002',
      medicineName: 'Augmentin 1g',
      qty: 30,
      unitPrice: 8500,
      totalAmount: 255000,
      expiryDate: '2027-06-15',
      amountPaid: 255000,
      remainingUnpaid: 0,
      createdAt: 1,
    },
  ];
  const stocks = calculateMedicineStocks(mockPurchases, []);
  const saleInfo = getNearestExpiryForSale('62911002', stocks);

  assert.equal(saleInfo.availableQty, 30);
  assert.equal(saleInfo.nearestExpiry, '2027-06-15');
  assert.equal(saleInfo.avgCost, 8500);
});

test('calculateDebts tracks what buyers owe us and what we owe suppliers with partial payments', () => {
  const mockPurchases: PurchaseItem[] = [
    {
      id: 'p1',
      date: '2026-10-01',
      supplier: 'مذخر الحارثية',
      barcode: '111',
      medicineName: 'Med A',
      qty: 10,
      unitPrice: 10000,
      totalAmount: 100000,
      expiryDate: '2027-01-01',
      amountPaid: 40000, // Left 60,000 unpaid
      remainingUnpaid: 60000,
      createdAt: 1,
    },
  ];

  const mockSales: SaleItem[] = [
    {
      id: 's1',
      date: '2026-10-05',
      buyer: 'صيدلية النور',
      barcode: '111',
      medicineName: 'Med A',
      qty: 5,
      unitPrice: 15000,
      totalAmount: 75000,
      avgCostAtSale: 10000,
      amountPaid: 25000, // Left 50,000 unpaid
      remainingUnpaid: 50000,
      createdAt: 2,
    },
  ];

  const mockPayments: DebtPayment[] = [
    // Pharmacy paid an additional 20,000 later
    {
      id: 'pay1',
      partyType: 'buyer',
      partyName: 'صيدلية النور',
      date: '2026-10-10',
      amount: 20000,
      type: 'receipt',
      createdAt: 3,
    },
    // We paid an additional 15,000 to supplier
    {
      id: 'pay2',
      partyType: 'supplier',
      partyName: 'مذخر الحارثية',
      date: '2026-10-12',
      amount: 15000,
      type: 'payment',
      createdAt: 4,
    },
  ];

  const debts = calculateDebts(mockPurchases, mockSales, mockPayments);

  // Pharmacy owed 75,000 - (25,000 + 20,000) = 30,000
  assert.equal(debts.totalOwedToUs, 30000);
  assert.equal(debts.buyersDebts[0].balanceRemaining, 30000);

  // We owed supplier 100,000 - (40,000 + 15,000) = 45,000
  assert.equal(debts.totalWeOwe, 45000);
  assert.equal(debts.suppliersDebts[0].balanceRemaining, 45000);

  assert.equal(debts.netDebtPosition, 30000 - 45000);
});

test('calculateProfitReport computes accurate sales, COGS, gross profit, expenses and net profit', () => {
  const mockPurchases: PurchaseItem[] = [
    {
      id: 'p1',
      date: '2026-10-01',
      supplier: 'مذخر الرشيد',
      barcode: '123',
      medicineName: 'Profen 400',
      qty: 100,
      unitPrice: 1500,
      totalAmount: 150000,
      expiryDate: '2027-01-01',
      amountPaid: 150000,
      remainingUnpaid: 0,
      createdAt: 1,
    },
  ];

  const mockSales: SaleItem[] = [
    {
      id: 's1',
      date: '2026-10-05',
      buyer: 'صيدلية الشعب',
      barcode: '123',
      medicineName: 'Profen 400',
      qty: 40,
      unitPrice: 2500,
      totalAmount: 100000, // 40 * 2500
      avgCostAtSale: 1500,
      amountPaid: 100000,
      remainingUnpaid: 0,
      createdAt: 2,
    },
  ];

  const mockExpenses: ExpenseItem[] = [
    {
      id: 'e1',
      date: '2026-10-06',
      type: 'نقل وشحن',
      amount: 15000,
      note: 'توصيل بضاعة للمذخر',
      createdAt: 3,
    },
  ];

  const report = calculateProfitReport(mockPurchases, mockSales, mockExpenses, '2026-10-01', '2026-10-31', 'شهر 10');

  // Sales = 100,000
  // COGS = 40 * 1500 = 60,000
  // Gross Profit = 40,000
  // Expenses = 15,000
  // Net Profit = 25,000
  assert.equal(report.totalSales, 100000);
  assert.equal(report.cogs, 60000);
  assert.equal(report.grossProfit, 40000);
  assert.equal(report.totalExpenses, 15000);
  assert.equal(report.netProfit, 25000);
  assert.equal(report.profitMarginPercent, 25); // 25,000 / 100,000 = 25%

  assert.equal(report.medicineProfits.length, 1);
  assert.equal(report.medicineProfits[0].medicineName, 'Profen 400');
  assert.equal(report.medicineProfits[0].grossProfit, 40000);
});
