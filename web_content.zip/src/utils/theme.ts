/**
 * Theme & OLED Display Mode Controller
 * Supports OLED True Black (#000000 pixels powered off) and Cyber Slate Dark (#0a0f1d).
 */

export type DarkModeType = 'oled-true-black' | 'cyber-dark';

class ThemeController {
  private mode: DarkModeType = 'oled-true-black';
  private listeners: Set<(mode: DarkModeType) => void> = new Set();

  constructor() {
    const saved = localStorage.getItem('neonbeam_oled_mode') as DarkModeType | null;
    if (saved === 'oled-true-black' || saved === 'cyber-dark') {
      this.mode = saved;
    } else {
      // Default to requested OLED True Black for maximum battery conservation
      this.mode = 'oled-true-black';
    }
    this.applyTheme(this.mode);
  }

  public getMode(): DarkModeType {
    return this.mode;
  }

  public setMode(mode: DarkModeType) {
    this.mode = mode;
    localStorage.setItem('neonbeam_oled_mode', mode);
    this.applyTheme(mode);
    this.listeners.forEach((l) => l(mode));
  }

  public subscribe(listener: (mode: DarkModeType) => void): () => void {
    this.listeners.add(listener);
    listener(this.mode);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private applyTheme(mode: DarkModeType) {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    if (mode === 'oled-true-black') {
      root.classList.add('oled-true-black');
      root.classList.remove('cyber-dark');
      document.body.style.backgroundColor = '#000000';
    } else {
      root.classList.add('cyber-dark');
      root.classList.remove('oled-true-black');
      document.body.style.backgroundColor = '#070b14';
    }
  }
}

export const themeService = new ThemeController();
