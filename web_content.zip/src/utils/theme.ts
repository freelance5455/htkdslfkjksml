import { THEMES, ACCENTS } from '../constants';

export function applyTheme(themeId: string, accentId?: string): void {
  const theme = THEMES[themeId] || THEMES['vscode-dark'];
  const root = document.documentElement;

  root.style.setProperty('--bg-main', theme.bg);
  root.style.setProperty('--bg-surface', theme.surface);
  root.style.setProperty('--bg-surface-hover', theme.surfaceHover);
  root.style.setProperty('--bg-header', theme.header);
  root.style.setProperty('--bg-sidebar', theme.sidebar);
  root.style.setProperty('--border-color', theme.border);
  root.style.setProperty('--text-main', theme.text);
  root.style.setProperty('--text-muted', theme.textMuted);

  const accent = accentId ? ACCENTS[accentId] : undefined;
  const accentColor = accent?.color || theme.accent;
  const accentHover = accent?.hover || theme.accentHover;
  const accentText = accent?.text || theme.accentText;

  root.style.setProperty('--accent-color', accentColor);
  root.style.setProperty('--accent-text', accentText);
  root.style.setProperty('--accent-hover', accentHover);

  if (theme.isDark) {
    root.classList.add('dark');
    root.classList.remove('light');
  } else {
    root.classList.remove('dark');
    root.classList.add('light');
  }
}
