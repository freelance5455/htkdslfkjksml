import type React from 'react';
import { ThemeAccent, ThemeMode } from '../types';

export interface AccentColorConfig {
  id: ThemeAccent;
  hex: string;
  selectedRingHex: string;
  nameEn: string;
  nameBn: string;
  bgClass: string;
  ringClass: string;
  textClass: string;
  borderClass: string;
}

// Exactly 10 colors from the reference image, ordered 5 in row 1, 5 in row 2
export const PRIMARY_ACCENT_COLORS: AccentColorConfig[] = [
  // Row 1
  {
    id: 'green',
    hex: '#5db962',
    selectedRingHex: '#2e7d32',
    nameEn: 'Green',
    nameBn: 'সবুজ',
    bgClass: 'bg-[#5db962]',
    ringClass: 'ring-[#5db962]',
    textClass: 'text-[#5db962]',
    borderClass: 'border-[#5db962]',
  },
  {
    id: 'teal',
    hex: '#1ea896',
    selectedRingHex: '#0f685c',
    nameEn: 'Teal',
    nameBn: 'টিয়াল',
    bgClass: 'bg-[#1ea896]',
    ringClass: 'ring-[#1ea896]',
    textClass: 'text-[#1ea896]',
    borderClass: 'border-[#1ea896]',
  },
  {
    id: 'cyan',
    hex: '#20c1e8',
    selectedRingHex: '#00838f',
    nameEn: 'Cyan',
    nameBn: 'আকাশি',
    bgClass: 'bg-[#20c1e8]',
    ringClass: 'ring-[#20c1e8]',
    textClass: 'text-[#20c1e8]',
    borderClass: 'border-[#20c1e8]',
  },
  {
    id: 'blue',
    hex: '#3b96f6',
    selectedRingHex: '#1565c0',
    nameEn: 'Blue',
    nameBn: 'নীল',
    bgClass: 'bg-[#3b96f6]',
    ringClass: 'ring-[#3b96f6]',
    textClass: 'text-[#3b96f6]',
    borderClass: 'border-[#3b96f6]',
  },
  {
    id: 'navy',
    hex: '#3950ba',
    selectedRingHex: '#1a237e',
    nameEn: 'Royal Blue',
    nameBn: 'রয়েল ব্লু',
    bgClass: 'bg-[#3950ba]',
    ringClass: 'ring-[#3950ba]',
    textClass: 'text-[#3950ba]',
    borderClass: 'border-[#3950ba]',
  },
  // Row 2
  {
    id: 'purple',
    hex: '#6d4ec4',
    selectedRingHex: '#4527a0',
    nameEn: 'Purple',
    nameBn: 'বেগুনি',
    bgClass: 'bg-[#6d4ec4]',
    ringClass: 'ring-[#6d4ec4]',
    textClass: 'text-[#6d4ec4]',
    borderClass: 'border-[#6d4ec4]',
  },
  {
    id: 'magenta',
    hex: '#a836a8',
    selectedRingHex: '#6a1b9a',
    nameEn: 'Magenta',
    nameBn: 'ম্যাজেন্টা',
    bgClass: 'bg-[#a836a8]',
    ringClass: 'ring-[#a836a8]',
    textClass: 'text-[#a836a8]',
    borderClass: 'border-[#a836a8]',
  },
  {
    id: 'red',
    hex: '#ea4d4d',
    selectedRingHex: '#b71c1c',
    nameEn: 'Red',
    nameBn: 'লাল',
    bgClass: 'bg-[#ea4d4d]',
    ringClass: 'ring-[#ea4d4d]',
    textClass: 'text-[#ea4d4d]',
    borderClass: 'border-[#ea4d4d]',
  },
  {
    id: 'orange',
    hex: '#f8961e',
    selectedRingHex: '#e65100',
    nameEn: 'Orange',
    nameBn: 'কমলা',
    bgClass: 'bg-[#f8961e]',
    ringClass: 'ring-[#f8961e]',
    textClass: 'text-[#f8961e]',
    borderClass: 'border-[#f8961e]',
  },
  {
    id: 'yellow',
    hex: '#fae34c',
    selectedRingHex: '#c79c00',
    nameEn: 'Yellow',
    nameBn: 'হলুদ',
    bgClass: 'bg-[#fae34c]',
    ringClass: 'ring-[#fae34c]',
    textClass: 'text-[#c79c00]',
    borderClass: 'border-[#fae34c]',
  },
];

// Full spectrum curated colors for quick selection across the entire color wheel
export const EXTENDED_SPECTRUM_PALETTE = [
  { hex: '#ea4d4d', nameEn: 'Crimson Red', nameBn: 'গাঢ় লাল' },
  { hex: '#f43f5e', nameEn: 'Rose', nameBn: 'রোজ' },
  { hex: '#ec4899', nameEn: 'Pink', nameBn: 'গোলাপি' },
  { hex: '#d946ef', nameEn: 'Fuchsia', nameBn: 'ফুসিয়া' },
  { hex: '#a836a8', nameEn: 'Magenta', nameBn: 'ম্যাজেন্টা' },
  { hex: '#8b5cf6', nameEn: 'Violet', nameBn: 'ভায়োলেট' },
  { hex: '#6d4ec4', nameEn: 'Purple', nameBn: 'বেগুনি' },
  { hex: '#3950ba', nameEn: 'Royal Blue', nameBn: 'রয়েল ব্লু' },
  { hex: '#3b96f6', nameEn: 'Sky Blue', nameBn: 'নীল' },
  { hex: '#0ea5e9', nameEn: 'Ocean Blue', nameBn: 'সমুদ্র নীল' },
  { hex: '#20c1e8', nameEn: 'Cyan', nameBn: 'আকাশি' },
  { hex: '#14b8a6', nameEn: 'Mint', nameBn: 'মিন্ট' },
  { hex: '#1ea896', nameEn: 'Teal', nameBn: 'টিয়াল' },
  { hex: '#10b981', nameEn: 'Emerald', nameBn: 'পান্না' },
  { hex: '#5db962', nameEn: 'Green', nameBn: 'সবুজ' },
  { hex: '#84cc16', nameEn: 'Lime', nameBn: 'লেবু সবুজ' },
  { hex: '#eab308', nameEn: 'Gold', nameBn: 'সোনালী' },
  { hex: '#fae34c', nameEn: 'Yellow', nameBn: 'হলুদ' },
  { hex: '#f59e0b', nameEn: 'Amber', nameBn: 'অ্যাম্বার' },
  { hex: '#f8961e', nameEn: 'Orange', nameBn: 'কমলা' },
  { hex: '#f97316', nameEn: 'Tangerine', nameBn: 'ট্যাঞ্জারিন' },
  { hex: '#ef4444', nameEn: 'Red', nameBn: 'লাল' },
  { hex: '#0f766e', nameEn: 'Deep Pine', nameBn: 'গভীর পাইন' },
  { hex: '#475569', nameEn: 'Slate Gray', nameBn: 'স্লেট গ্রে' },
];

export function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const clean = hex.replace(/^#/, '');
  if (clean.length === 3) {
    return {
      r: parseInt(clean[0] + clean[0], 16),
      g: parseInt(clean[1] + clean[1], 16),
      b: parseInt(clean[2] + clean[2], 16),
    };
  }
  if (clean.length === 6) {
    return {
      r: parseInt(clean.substring(0, 2), 16),
      g: parseInt(clean.substring(2, 4), 16),
      b: parseInt(clean.substring(4, 6), 16),
    };
  }
  return null;
}

export function darkenHex(hex: string, amount = 0.25): string {
  const rgb = hexToRgb(hex);
  if (!rgb) return hex;
  const r = Math.max(0, Math.round(rgb.r * (1 - amount)));
  const g = Math.max(0, Math.round(rgb.g * (1 - amount)));
  const b = Math.max(0, Math.round(rgb.b * (1 - amount)));
  return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
}

export function hslToHex(h: number, s: number, l: number): string {
  l /= 100;
  const a = (s * Math.min(l, 1 - l)) / 100;
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color)
      .toString(16)
      .padStart(2, '0');
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

export function hexToHsl(hex: string): { h: number; s: number; l: number } {
  const rgb = hexToRgb(hex);
  if (!rgb) return { h: 140, s: 50, l: 50 };
  const r = rgb.r / 255;
  const g = rgb.g / 255;
  const b = rgb.b / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h = Math.round(h * 60);
  }

  return { h, s: Math.round(s * 100), l: Math.round(l * 100) };
}

export function getHueColorName(hue: number): { en: string; bn: string } {
  const h = ((hue % 360) + 360) % 360;
  if (h >= 345 || h < 12) return { en: 'Red', bn: 'লাল' };
  if (h >= 12 && h < 32) return { en: 'Orange', bn: 'কমলা' };
  if (h >= 32 && h < 48) return { en: 'Amber', bn: 'অ্যাম্বার' };
  if (h >= 48 && h < 68) return { en: 'Yellow', bn: 'হলুদ' };
  if (h >= 68 && h < 95) return { en: 'Lime', bn: 'লেবু সবুজ' };
  if (h >= 95 && h < 145) return { en: 'Green', bn: 'সবুজ' };
  if (h >= 145 && h < 168) return { en: 'Emerald', bn: 'পান্না' };
  if (h >= 168 && h < 190) return { en: 'Teal', bn: 'টিয়াল' };
  if (h >= 190 && h < 210) return { en: 'Cyan / Sky', bn: 'আকাশি' };
  if (h >= 210 && h < 235) return { en: 'Blue', bn: 'নীল' };
  if (h >= 235 && h < 265) return { en: 'Royal Blue', bn: 'রয়েল ব্লু' };
  if (h >= 265 && h < 290) return { en: 'Purple', bn: 'বেগুনি' };
  if (h >= 290 && h < 320) return { en: 'Magenta', bn: 'ম্যাজেন্টা' };
  return { en: 'Pink / Rose', bn: 'গোলাপি' };
}

export function getAccentConfig(accent?: ThemeAccent): AccentColorConfig {
  if (!accent) return PRIMARY_ACCENT_COLORS[0];
  
  // Normalization for legacy aliases
  let normalizedId = accent;
  if (accent === 'emerald') normalizedId = 'green';
  else if (accent === 'indigo') normalizedId = 'navy';
  else if (accent === 'amber') normalizedId = 'orange';

  const found = PRIMARY_ACCENT_COLORS.find((c) => c.id === normalizedId);
  if (found) return found;

  // Check extended palette
  const extendedMatch = EXTENDED_SPECTRUM_PALETTE.find((c) => c.hex.toLowerCase() === accent.toLowerCase());
  if (extendedMatch) {
    const ring = darkenHex(extendedMatch.hex, 0.3);
    return {
      id: accent,
      hex: extendedMatch.hex,
      selectedRingHex: ring,
      nameEn: extendedMatch.nameEn,
      nameBn: extendedMatch.nameBn,
      bgClass: `bg-[${extendedMatch.hex}]`,
      ringClass: `ring-[${extendedMatch.hex}]`,
      textClass: `text-[${extendedMatch.hex}]`,
      borderClass: `border-[${extendedMatch.hex}]`,
    };
  }

  // If it's any custom hex code
  if (accent.startsWith('#') || /^[0-9a-fA-F]{6}$/.test(accent)) {
    const validHex = accent.startsWith('#') ? accent : `#${accent}`;
    const hsl = hexToHsl(validHex);
    const colorNames = getHueColorName(hsl.h);
    const ring = darkenHex(validHex, 0.3);
    return {
      id: accent,
      hex: validHex,
      selectedRingHex: ring,
      nameEn: `${colorNames.en} (${validHex.toUpperCase()})`,
      nameBn: `${colorNames.bn} (${validHex.toUpperCase()})`,
      bgClass: `bg-[${validHex}]`,
      ringClass: `ring-[${validHex}]`,
      textClass: `text-[${validHex}]`,
      borderClass: `border-[${validHex}]`,
    };
  }

  return PRIMARY_ACCENT_COLORS[0];
}

export interface DualAccentInfo {
  primary: AccentColorConfig;
  secondary: AccentColorConfig;
  percentage: number;
  gradient: string;
  primaryGradient: string;
  gradientHorizontal: string;
  gradientVertical: string;
  gradientSoft: string;
  primaryGlow: string;
  secondaryGlow: string;
  dualGlow: string;
  buttonStyle: React.CSSProperties;
  primaryButtonStyle: React.CSSProperties;
  secondaryButtonStyle: React.CSSProperties;
  badgeStyle: React.CSSProperties;
  badgePrimaryStyle: React.CSSProperties;
  badgeSecondaryStyle: React.CSSProperties;
  iconBoxPrimaryStyle: React.CSSProperties;
  iconBoxSecondaryStyle: React.CSSProperties;
  iconBoxDualStyle: React.CSSProperties;
  activeTabPrimaryStyle: React.CSSProperties;
  activeTabSecondaryStyle: React.CSSProperties;
  cardAccentBorder: React.CSSProperties;
  cssVariables: Record<string, string>;
}

export function getDualAccentInfo(
  primaryAccent?: ThemeAccent,
  secondaryAccent?: ThemeAccent,
  accentPercentage?: number
): DualAccentInfo {
  const primary = getAccentConfig(primaryAccent || 'green');
  const secondary = getAccentConfig(secondaryAccent || 'cyan');
  const percentage = typeof accentPercentage === 'number' ? Math.max(0, Math.min(100, accentPercentage)) : 50;

  const gradient = `linear-gradient(135deg, ${primary.hex} 0%, ${primary.hex} ${percentage}%, ${secondary.hex} 100%)`;
  const gradientHorizontal = `linear-gradient(90deg, ${primary.hex} 0%, ${primary.hex} ${percentage}%, ${secondary.hex} 100%)`;
  const gradientVertical = `linear-gradient(180deg, ${primary.hex} 0%, ${secondary.hex} 100%)`;
  const gradientSoft = `linear-gradient(135deg, ${primary.hex}25 0%, ${secondary.hex}25 100%)`;

  const primaryGlow = `${primary.hex}45`;
  const secondaryGlow = `${secondary.hex}45`;
  const dualGlow = `0 10px 25px -4px ${primary.hex}45, 0 4px 12px -2px ${secondary.hex}35`;

  const buttonStyle: React.CSSProperties = {
    background: gradient,
    color: '#ffffff',
    boxShadow: `0 8px 20px -4px ${primary.hex}50, 0 4px 12px -2px ${secondary.hex}40`,
  };

  const primaryButtonStyle: React.CSSProperties = {
    backgroundColor: primary.hex,
    color: '#ffffff',
    boxShadow: `0 6px 16px -3px ${primary.hex}45`,
  };

  const secondaryButtonStyle: React.CSSProperties = {
    backgroundColor: secondary.hex,
    color: '#ffffff',
    boxShadow: `0 6px 16px -3px ${secondary.hex}45`,
  };

  const badgeStyle: React.CSSProperties = {
    background: gradientSoft,
    border: `1px solid ${primary.hex}40`,
    color: primary.hex,
  };

  const badgePrimaryStyle: React.CSSProperties = {
    backgroundColor: `${primary.hex}1a`,
    border: `1px solid ${primary.hex}35`,
    color: primary.hex,
  };

  const badgeSecondaryStyle: React.CSSProperties = {
    backgroundColor: `${secondary.hex}1a`,
    border: `1px solid ${secondary.hex}35`,
    color: secondary.hex,
  };

  const iconBoxPrimaryStyle: React.CSSProperties = {
    backgroundColor: `${primary.hex}20`,
    border: `1px solid ${primary.hex}35`,
    color: primary.hex,
  };

  const iconBoxSecondaryStyle: React.CSSProperties = {
    backgroundColor: `${secondary.hex}20`,
    border: `1px solid ${secondary.hex}35`,
    color: secondary.hex,
  };

  const iconBoxDualStyle: React.CSSProperties = {
    background: gradientSoft,
    border: `1px solid ${primary.hex}35`,
    color: primary.hex,
  };

  const activeTabPrimaryStyle: React.CSSProperties = {
    backgroundColor: `${primary.hex}22`,
    border: `1px solid ${primary.hex}55`,
    color: primary.hex,
  };

  const activeTabSecondaryStyle: React.CSSProperties = {
    backgroundColor: `${secondary.hex}22`,
    border: `1px solid ${secondary.hex}55`,
    color: secondary.hex,
  };

  const cardAccentBorder: React.CSSProperties = {
    borderTop: `3px solid ${primary.hex}`,
  };

  const pRgb = hexToRgb(primary.hex) || { r: 93, g: 185, b: 98 };
  const sRgb = hexToRgb(secondary.hex) || { r: 32, g: 193, b: 232 };

  const cssVariables: Record<string, string> = {
    '--color-primary': primary.hex,
    '--color-secondary': secondary.hex,
    '--color-primary-rgb': `${pRgb.r}, ${pRgb.g}, ${pRgb.b}`,
    '--color-secondary-rgb': `${sRgb.r}, ${sRgb.g}, ${sRgb.b}`,
    '--color-primary-ring': primary.selectedRingHex,
    '--color-secondary-ring': secondary.selectedRingHex,
    '--color-primary-glow': primaryGlow,
    '--color-secondary-glow': secondaryGlow,
    '--color-primary-5': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.05)`,
    '--color-primary-10': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.10)`,
    '--color-primary-15': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.15)`,
    '--color-primary-20': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.20)`,
    '--color-primary-30': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.30)`,
    '--color-primary-40': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.40)`,
    '--color-primary-50': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.50)`,
    '--color-secondary-10': `rgba(${sRgb.r}, ${sRgb.g}, ${sRgb.b}, 0.10)`,
    '--color-secondary-20': `rgba(${sRgb.r}, ${sRgb.g}, ${sRgb.b}, 0.20)`,
    '--theme-primary': primary.hex,
    '--theme-secondary': secondary.hex,
    '--accent-percent': `${percentage}%`,
    '--accent-gradient': gradient,
    '--accent-gradient-h': gradientHorizontal,
    '--accent-gradient-v': gradientVertical,
    '--accent-gradient-soft': gradientSoft,
  };

  return {
    primary,
    secondary,
    percentage,
    gradient,
    primaryGradient: gradient,
    gradientHorizontal,
    gradientVertical,
    gradientSoft,
    primaryGlow,
    secondaryGlow,
    dualGlow,
    buttonStyle,
    primaryButtonStyle,
    secondaryButtonStyle,
    badgeStyle,
    badgePrimaryStyle,
    badgeSecondaryStyle,
    iconBoxPrimaryStyle,
    iconBoxSecondaryStyle,
    iconBoxDualStyle,
    activeTabPrimaryStyle,
    activeTabSecondaryStyle,
    cardAccentBorder,
    cssVariables,
  };
}

export interface ThemeToneConfig {
  shade: number; // 0 to 100
  titleEn: string;
  titleBn: string;
  tagEn: string;
  tagBn: string;
  chassisBg: string;
  outerBg: string;
  headerBg: string;
  cardBg: string;
  cardBorder: string;
  subtleBg: string;
  sliderTrackGradient: string;
}

export function getThemeToneStyles(
  mode: ThemeMode = 'dark',
  rawShade = 50,
  isEn = false,
  accent?: ThemeAccent
): ThemeToneConfig {
  const shade = Math.min(100, Math.max(0, typeof rawShade === 'number' && !isNaN(rawShade) ? rawShade : 50));
  const factor = shade / 100; // 0 (lightest/softest) to 1 (deepest/darkest)

  const primaryConfig = getAccentConfig(accent || 'green');
  const rgb = hexToRgb(primaryConfig.hex) || { r: 93, g: 185, b: 98 };
  const hsl = hexToHsl(primaryConfig.hex);
  const hue = hsl.h;

  if (mode === 'light') {
    // Light Mode:
    // 0%: Ultra Soft / Crisp Pure Light (Lightness: 100%)
    // 50%: Balanced Soft Modern Light (Lightness: 96%)
    // 100%: Deep Tinted Slate Light (Lightness: 89%)
    const chassisL = 100 - factor * 7;
    const outerL = 98 - factor * 12;
    const cardL = 100 - factor * 3;
    const borderAlpha = 0.16 + factor * 0.22;

    const tagEn = shade < 30 ? 'Ultra Soft' : shade <= 70 ? 'Balanced' : 'Deep Tint';
    const tagBn = shade < 30 ? 'খুব হালকা' : shade <= 70 ? 'ব্যালেন্সড' : 'ডিপ লাইট';
    const titleEn = `${tagEn} Light (${shade}%)`;
    const titleBn = `${tagBn} লাইট (${shade}%)`;

    return {
      shade,
      titleEn,
      titleBn,
      tagEn,
      tagBn,
      chassisBg: `hsl(${hue}, 12%, ${Math.round(chassisL)}%)`,
      outerBg: `hsl(${hue}, 14%, ${Math.round(outerL)}%)`,
      headerBg: `hsla(0, 0%, 100%, ${(0.98 - factor * 0.08).toFixed(2)})`,
      cardBg: `hsl(0, 0%, ${Math.round(cardL)}%)`,
      cardBorder: `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${borderAlpha.toFixed(2)})`,
      subtleBg: `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${(0.04 + factor * 0.06).toFixed(2)})`,
      sliderTrackGradient: `linear-gradient(to right, #ffffff 0%, rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.2) 50%, ${primaryConfig.hex} 100%)`,
    };
  }

  if (mode === 'oled') {
    // OLED Mode:
    // 0%: Elevated OLED cards with subtle dark tone
    // 50%: Pure True Black OLED (#000000)
    // 100%: Infinite Zero-Light OLED with ultra high contrast
    const cardElevation = Math.round(18 * (1 - factor));
    const borderOpacity = (0.18 + factor * 0.20).toFixed(2);

    const tagEn = shade < 30 ? 'Soft OLED' : shade <= 70 ? 'Pure Black' : 'Infinite Zero';
    const tagBn = shade < 30 ? 'সফট ওলেড' : shade <= 70 ? 'পিওর ব্ল্যাক' : 'ইনফিনিট জিরো';
    const titleEn = `${tagEn} OLED (${shade}%)`;
    const titleBn = `${tagBn} ওলেড (${shade}%)`;

    return {
      shade,
      titleEn,
      titleBn,
      tagEn,
      tagBn,
      chassisBg: '#000000',
      outerBg: factor < 0.25 ? '#0c0e12' : '#000000',
      headerBg: 'rgba(5, 5, 8, 0.95)',
      cardBg: `rgb(${cardElevation}, ${cardElevation}, ${cardElevation + 2})`,
      cardBorder: `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${borderOpacity})`,
      subtleBg: `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${(0.05 + factor * 0.05).toFixed(2)})`,
      sliderTrackGradient: `linear-gradient(to right, #27272a 0%, rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.3) 50%, #000000 100%)`,
    };
  }

  // Dark Mode:
  // 0% = Soft Charcoal (comfortable daylight dark, lightness ~19%)
  // 50% = Midnight Slate (sleek balanced dark, lightness ~11%)
  // 100% = Abyss Pitch (deep obsidian black, lightness ~4%)
  const lightness = 19 - factor * 15;
  const outerL = 22 - factor * 17;
  const cardL = 25 - factor * 18;
  const borderOpacity = 0.16 + (1 - factor) * 0.10;

  const tagEn = shade < 30 ? 'Soft Charcoal' : shade <= 70 ? 'Midnight Slate' : 'Abyss Pitch';
  const tagBn = shade < 30 ? 'হালকা চারকোল' : shade <= 70 ? 'মিডনাইট স্লিপ' : 'ডিপ অ্যাবিস';
  const titleEn = `${tagEn} Dark (${shade}%)`;
  const titleBn = `${tagBn} ডার্ক (${shade}%)`;

  return {
    shade,
    titleEn,
    titleBn,
    tagEn,
    tagBn,
    chassisBg: `hsl(${hue}, 14%, ${lightness.toFixed(1)}%)`,
    outerBg: `hsl(${hue}, 16%, ${outerL.toFixed(1)}%)`,
    headerBg: `hsla(${hue}, 16%, ${(lightness + 2.5).toFixed(1)}%, 0.95)`,
    cardBg: `hsl(${hue}, 12%, ${cardL.toFixed(1)}%)`,
    cardBorder: `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${borderOpacity.toFixed(2)})`,
    subtleBg: `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.10)`,
    sliderTrackGradient: `linear-gradient(to right, rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.3) 0%, #0f172a 50%, #020617 100%)`,
  };
}

export function applyThemeCssVariables(appSettings?: {
  themeMode?: ThemeMode;
  themeAccent?: ThemeAccent;
  secondaryAccent?: ThemeAccent;
  accentPercentage?: number;
  themeShade?: number;
}): DualAccentInfo {
  const dual = getDualAccentInfo(
    appSettings?.themeAccent,
    appSettings?.secondaryAccent,
    appSettings?.accentPercentage
  );

  const tone = getThemeToneStyles(
    appSettings?.themeMode || 'dark',
    typeof appSettings?.themeShade === 'number' ? appSettings.themeShade : 50,
    false,
    appSettings?.themeAccent
  );

  if (typeof document !== 'undefined') {
    const root = document.documentElement;
    Object.entries(dual.cssVariables).forEach(([key, val]) => {
      root.style.setProperty(key, val);
    });

    // Sync theme tone CSS variables
    root.style.setProperty('--theme-shade', `${tone.shade}%`);
    root.style.setProperty('--theme-chassis-bg', tone.chassisBg);
    root.style.setProperty('--theme-outer-bg', tone.outerBg);
    root.style.setProperty('--theme-header-bg', tone.headerBg);
    root.style.setProperty('--theme-card-bg', tone.cardBg);
    root.style.setProperty('--theme-card-border', tone.cardBorder);
    root.style.setProperty('--theme-subtle-bg', tone.subtleBg);
  }

  return dual;
}
