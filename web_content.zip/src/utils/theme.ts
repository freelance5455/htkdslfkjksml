import { ThemeAccent, UIThemeStyle } from "../types";

export interface AccentDefinition {
  id: ThemeAccent;
  name: string;
  preview: string;
  gradient: string;
  gradientHover: string;
  buttonBg: string;
  text: string;
  textDark: string;
  bgLight: string;
  bgLightDark: string;
  border: string;
  borderDark: string;
  ring: string;
  activeTab: string;
  badgeBg: string;
  badgeText: string;
  dotBg: string;
}

export interface UIThemeStyleDefinition {
  id: UIThemeStyle;
  name: string;
  tagline: string;
  description: string;
  badge: string;
  bgClass: string;
  cardClass: string;
  fontClass: string;
  previewGradient: string;
  primaryAccentHex: string;
  features: string[];
}

export const UI_THEME_STYLE_CONFIGS: Record<UIThemeStyle, UIThemeStyleDefinition> = {
  minimalist: {
    id: "minimalist",
    name: "Klasik NoteFlow (Minimalist)",
    tagline: "Hızlı Not Alma, Kategori Çipleri & Esnek Izgara",
    description: "Eski klasik NoteFlow stili: Temiz kartlar, kategori sekmeleri, arama, filtreler ve odaklanmayı kolaylaştıran modern açık/koyu ızgara.",
    badge: "Klasik Orijinal",
    bgClass: "bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100",
    cardClass: "bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm",
    fontClass: "font-sans",
    previewGradient: "from-teal-500 to-emerald-500",
    primaryAccentHex: "#0d9488",
    features: ["Klasik hızlı not alma çubuğu", "Kategori filtreleme çipleri", "Esnek kart ızgarası"],
  },
  circadian_pkm: {
    id: "circadian_pkm",
    name: "Sirkadiyen Stratejik PKM (Gündüz & Gece)",
    tagline: "12:00 Gündüz & 22:00 Gece İkili Sirkadiyen Düzen",
    description: "Görseldeki yeni stil: Sıcak parşömen (#FAF6EE) ve obsidiyen (#15161A) ikili mod, mercan ve fuşya neon dış ışıma kartları, dairesel cam eylem diski ve mobil çerçeve.",
    badge: "Sirkadiyen İkili",
    bgClass: "bg-[#FAF6EE] dark:bg-[#15161A] text-slate-900 dark:text-slate-100",
    cardClass: "bg-white dark:bg-[#1F2027] border-2 border-[#E0533C] dark:border-[#E11D48] shadow-lg",
    fontClass: "font-sans",
    previewGradient: "from-[#E0533C] via-[#E11D48] to-[#15161A]",
    primaryAccentHex: "#E11D48",
    features: [
      "12:00 Gündüz & 22:00 Gece ikili bölünmüş mod",
      "Mercan Kırmızı & Fuşya neon ışıma kartları",
      "Dairesel cam eylem diski (Metin, Sesli, Liste)",
      "Mobil Cihaz ve Genişletilmiş Tuval modları",
    ],
  },
  enterprise_pkm: {
    id: "enterprise_pkm",
    name: "Entegre Stratejik PKM (Kurumsal 4 Bölge)",
    tagline: "Zaman Çizelgesi, Kanban & Denetimli Bilgi Paneli",
    description: "Koyu Slate (#1E222A), Bal Köpüğü Altın (#C7AE70) ve Elektrik Camgöbeği (#00F5FF) 4 bölgeli kurumsal bilgi mimarisi.",
    badge: "Stratejik PKM",
    bgClass: "bg-slate-100 dark:bg-slate-900 text-slate-900 dark:text-slate-100",
    cardClass: "bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 shadow-md",
    fontClass: "font-sans",
    previewGradient: "from-[#C7AE70] via-blue-600 to-slate-900",
    primaryAccentHex: "#C7AE70",
    features: [
      "4 Bölgeli dashboard düzeni",
      "Zaman çizelgesi ve aktif proje kartları",
      "Denetimli arşiv ve hızlı eylem menüsü",
    ],
  },
  terminal: {
    id: "terminal",
    name: "Functional Terminal",
    tagline: "Koyu Konsol Ortamı & Eş Aralıklı Fontlar",
    description: "Yazılımcılar ve geliştiriciler için koyu konsol ortamı, monospaced fontlar ve renk kodlu [ERR], [INFO], [OK] etiketleri.",
    badge: "Terminal",
    bgClass: "font-mono bg-slate-950 text-emerald-400",
    cardClass: "font-mono bg-slate-900/90 border border-emerald-800/60 shadow-lg shadow-emerald-950/40 text-emerald-300",
    fontClass: "font-mono",
    previewGradient: "from-emerald-600 to-green-400",
    primaryAccentHex: "#10b981",
    features: ["Monospaced kod stili", "Koyu konsol log görünümü", "Renk kodlu durum etiketleri"],
  },
  cyberpunk: {
    id: "cyberpunk",
    name: "Project-Centric Glow",
    tagline: "Neon Parıltılar & Yüksek Enerjili Siber Estetik",
    description: "Sabitlenmiş görevler ve aktif projeler etrafında parlak mor/siyan neon halkalar sunan enerjik koyu arayüz.",
    badge: "Project Glow",
    bgClass: "bg-slate-950 text-cyan-200",
    cardClass: "bg-slate-900/95 border border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.25)] text-cyan-100",
    fontClass: "font-sans",
    previewGradient: "from-cyan-500 via-purple-500 to-pink-500",
    primaryAccentHex: "#06b6d4",
    features: ["Neon parıltılı kart kenarlıkları", "Ametist moru ve siyan ışıma", "Siber renk vurguları"],
  },
  mental_canvas: {
    id: "mental_canvas",
    name: "Mental Architecture",
    tagline: "Çok Sütunlu Tuval & Ağ Bağlantılı Düğümler",
    description: "Sol tarafta zaman tüneli akışı, ortada kanban ve sağda süzülmüş günlüklere sahip PKM bilgi mimarisi.",
    badge: "Mental Architecture",
    bgClass: "bg-slate-900 text-slate-100",
    cardClass: "bg-slate-800/90 border border-indigo-500/40 shadow-md text-slate-100",
    fontClass: "font-sans",
    previewGradient: "from-indigo-500 to-purple-600",
    primaryAccentHex: "#6366f1",
    features: ["Bağlantılı zihin düğümleri", "Zaman tüneli ve kanban akışı", "Gelişmiş bilgi haritası"],
  },
};

export const THEME_ACCENTS: Record<ThemeAccent, AccentDefinition> = {
  teal: {
    id: "teal",
    name: "Zümrüt Teal",
    preview: "#0d9488",
    gradient: "from-teal-600 to-emerald-600",
    gradientHover: "hover:from-teal-500 hover:to-emerald-500",
    buttonBg: "bg-teal-600 hover:bg-teal-700 text-white",
    text: "text-teal-600",
    textDark: "dark:text-teal-400",
    bgLight: "bg-teal-50",
    bgLightDark: "dark:bg-teal-950/40",
    border: "border-teal-500",
    borderDark: "dark:border-teal-500/50",
    ring: "focus:ring-teal-500",
    activeTab: "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-300 shadow-xs font-bold",
    badgeBg: "bg-teal-100 dark:bg-teal-950/80",
    badgeText: "text-teal-800 dark:text-teal-300 border-teal-200 dark:border-teal-800",
    dotBg: "bg-teal-500",
  },
  emerald: {
    id: "emerald",
    name: "Orman Yeşili",
    preview: "#059669",
    gradient: "from-emerald-600 to-teal-600",
    gradientHover: "hover:from-emerald-500 hover:to-teal-500",
    buttonBg: "bg-emerald-600 hover:bg-emerald-700 text-white",
    text: "text-emerald-600",
    textDark: "dark:text-emerald-400",
    bgLight: "bg-emerald-50",
    bgLightDark: "dark:bg-emerald-950/40",
    border: "border-emerald-500",
    borderDark: "dark:border-emerald-500/50",
    ring: "focus:ring-emerald-500",
    activeTab: "bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-300 shadow-xs font-bold",
    badgeBg: "bg-emerald-100 dark:bg-emerald-950/80",
    badgeText: "text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800",
    dotBg: "bg-emerald-500",
  },
  blue: {
    id: "blue",
    name: "Klasik Mavi",
    preview: "#2563eb",
    gradient: "from-blue-600 to-cyan-600",
    gradientHover: "hover:from-blue-500 hover:to-cyan-500",
    buttonBg: "bg-blue-600 hover:bg-blue-700 text-white",
    text: "text-blue-600",
    textDark: "dark:text-blue-400",
    bgLight: "bg-blue-50",
    bgLightDark: "dark:bg-blue-950/40",
    border: "border-blue-500",
    borderDark: "dark:border-blue-500/50",
    ring: "focus:ring-blue-500",
    activeTab: "bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-300 shadow-xs font-bold",
    badgeBg: "bg-blue-100 dark:bg-blue-950/80",
    badgeText: "text-blue-800 dark:text-blue-300 border-blue-200 dark:border-blue-800",
    dotBg: "bg-blue-500",
  },
  ocean: {
    id: "ocean",
    name: "Derin Okyanus",
    preview: "#0284c7",
    gradient: "from-sky-600 to-indigo-600",
    gradientHover: "hover:from-sky-500 hover:to-indigo-500",
    buttonBg: "bg-sky-600 hover:bg-sky-700 text-white",
    text: "text-sky-600",
    textDark: "dark:text-sky-400",
    bgLight: "bg-sky-50",
    bgLightDark: "dark:bg-sky-950/40",
    border: "border-sky-500",
    borderDark: "dark:border-sky-500/50",
    ring: "focus:ring-sky-500",
    activeTab: "bg-white dark:bg-slate-700 text-sky-600 dark:text-sky-300 shadow-xs font-bold",
    badgeBg: "bg-sky-100 dark:bg-sky-950/80",
    badgeText: "text-sky-800 dark:text-sky-300 border-sky-200 dark:border-sky-800",
    dotBg: "bg-sky-500",
  },
  purple: {
    id: "purple",
    name: "Ametist Moru",
    preview: "#9333ea",
    gradient: "from-purple-600 to-pink-600",
    gradientHover: "hover:from-purple-500 hover:to-pink-500",
    buttonBg: "bg-purple-600 hover:bg-purple-700 text-white",
    text: "text-purple-600",
    textDark: "dark:text-purple-400",
    bgLight: "bg-purple-50",
    bgLightDark: "dark:bg-purple-950/40",
    border: "border-purple-500",
    borderDark: "dark:border-purple-500/50",
    ring: "focus:ring-purple-500",
    activeTab: "bg-white dark:bg-slate-700 text-purple-600 dark:text-purple-300 shadow-xs font-bold",
    badgeBg: "bg-purple-100 dark:bg-purple-950/80",
    badgeText: "text-purple-800 dark:text-purple-300 border-purple-200 dark:border-purple-800",
    dotBg: "bg-purple-500",
  },
  rose: {
    id: "rose",
    name: "Yakut Gül",
    preview: "#e11d48",
    gradient: "from-rose-600 to-orange-600",
    gradientHover: "hover:from-rose-500 hover:to-orange-500",
    buttonBg: "bg-rose-600 hover:bg-rose-700 text-white",
    text: "text-rose-600",
    textDark: "dark:text-rose-400",
    bgLight: "bg-rose-50",
    bgLightDark: "dark:bg-rose-950/40",
    border: "border-rose-500",
    borderDark: "dark:border-rose-500/50",
    ring: "focus:ring-rose-500",
    activeTab: "bg-white dark:bg-slate-700 text-rose-600 dark:text-rose-300 shadow-xs font-bold",
    badgeBg: "bg-rose-100 dark:bg-rose-950/80",
    badgeText: "text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800",
    dotBg: "bg-rose-500",
  },
  amber: {
    id: "amber",
    name: "Sıcak Kehribar",
    preview: "#d97706",
    gradient: "from-amber-500 to-orange-600",
    gradientHover: "hover:from-amber-400 hover:to-orange-500",
    buttonBg: "bg-amber-600 hover:bg-amber-700 text-white",
    text: "text-amber-600",
    textDark: "dark:text-amber-400",
    bgLight: "bg-amber-50",
    bgLightDark: "dark:bg-amber-950/40",
    border: "border-amber-500",
    borderDark: "dark:border-amber-500/50",
    ring: "focus:ring-amber-500",
    activeTab: "bg-white dark:bg-slate-700 text-amber-600 dark:text-amber-300 shadow-xs font-bold",
    badgeBg: "bg-amber-100 dark:bg-amber-950/80",
    badgeText: "text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800",
    dotBg: "bg-amber-500",
  },
  slate: {
    id: "slate",
    name: "Arduvaz Minimalist",
    preview: "#475569",
    gradient: "from-slate-700 to-zinc-800",
    gradientHover: "hover:from-slate-600 hover:to-zinc-700",
    buttonBg: "bg-slate-800 hover:bg-slate-900 text-white dark:bg-slate-700 dark:hover:bg-slate-600",
    text: "text-slate-800",
    textDark: "dark:text-slate-200",
    bgLight: "bg-slate-100",
    bgLightDark: "dark:bg-slate-800/80",
    border: "border-slate-600",
    borderDark: "dark:border-slate-400/50",
    ring: "focus:ring-slate-500",
    activeTab: "bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 shadow-xs font-bold",
    badgeBg: "bg-slate-200 dark:bg-slate-800",
    badgeText: "text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700",
    dotBg: "bg-slate-600",
  },
};

export function applyThemeAccentToDocument(accent: ThemeAccent) {
  if (typeof document === "undefined") return;
  const def = THEME_ACCENTS[accent] || THEME_ACCENTS.teal;
  const root = document.documentElement;
  root.style.setProperty("--accent-preview", def.preview);
  root.style.setProperty("--accent-primary", def.preview);
}
