import { GradeLevel } from '../types';

export const GRADE_LEVELS: GradeLevel[] = [
  '1st Grade',
  '2nd Grade',
  '3rd Grade',
  '4th Grade',
  '5th Grade',
  '6th Grade',
  '7th Grade',
  '8th Grade',
  '9th Grade (Freshman)',
  '10th Grade (Sophomore)',
  '11th Grade (Junior / AP)',
  '12th Grade (Senior / AP)',
  'College / Undergraduate',
];

export const AVATAR_OPTIONS = [
  { emoji: '🦉', label: 'Wise Owl', color: 'from-amber-400 to-orange-500' },
  { emoji: '🚀', label: 'Cosmic Explorer', color: 'from-blue-500 to-indigo-600' },
  { emoji: '🦊', label: 'Clever Fox', color: 'from-orange-400 to-amber-600' },
  { emoji: '🧪', label: 'Mad Scientist', color: 'from-emerald-400 to-teal-600' },
  { emoji: '⚡', label: 'Quick Thinker', color: 'from-yellow-400 to-amber-500' },
  { emoji: '🎨', label: 'Creative Artist', color: 'from-pink-400 to-rose-600' },
  { emoji: '🌟', label: 'Star Student', color: 'from-purple-400 to-indigo-500' },
  { emoji: '📚', label: 'Book Master', color: 'from-cyan-400 to-blue-600' },
];

// Generates an SVG data URL for sample math/science/history cards so users can snap or pick them
export function createSampleImage(title: string, problem: string, subtext: string, bgColor: string, textColor: string): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400">
    <rect width="600" height="400" fill="${bgColor}" rx="24"/>
    <rect x="20" y="20" width="560" height="360" fill="#ffffff" rx="16" stroke="#e2e8f0" stroke-width="2"/>
    <rect x="40" y="40" width="140" height="32" rx="16" fill="${bgColor}"/>
    <text x="110" y="62" fill="#ffffff" font-family="sans-serif" font-weight="bold" font-size="14" text-anchor="middle">${title}</text>
    <foreignObject x="40" y="90" width="520" height="230">
      <div xmlns="http://www.w3.org/1999/xhtml" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 20px; line-height: 1.5; color: ${textColor}; font-weight: 600; padding: 10px;">
        ${problem}
      </div>
    </foreignObject>
    <text x="50" y="350" fill="#64748b" font-family="sans-serif" font-size="14" font-weight="500">${subtext}</text>
  </svg>`;
  return `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(svg)))}`;
}

export const SAMPLE_PROBLEMS = [
  {
    id: 'sample-math',
    subject: 'Math',
    title: 'Algebra: Quadratic Equation',
    difficulty: 'Middle / High School',
    image: createSampleImage(
      'MATH ALGEBRA',
      'Solve for x:<br/><br/><span style="font-size: 26px; color: #1e3a8a; font-family: monospace;">2x² - 8x - 10 = 0</span><br/><br/>Find all real solutions and show your work by factoring or quadratic formula.',
      'Topic: Quadratic Roots & Factoring',
      '#2563eb',
      '#0f172a'
    ),
    previewText: 'Solve for x: 2x² - 8x - 10 = 0. Find all real solutions.',
  },
  {
    id: 'sample-science',
    subject: 'Science',
    title: 'Biology: Cellular Respiration',
    difficulty: 'Middle / High School',
    image: createSampleImage(
      'BIOLOGY SCIENCE',
      'During intense exercise, human muscle cells run low on oxygen.<br/><br/><strong>Questions:</strong><br/>1. What process occurs when oxygen is insufficient?<br/>2. What byproduct accumulates causing muscle fatigue?<br/>3. How many ATP are produced compared to aerobic respiration?',
      'Topic: Glycolysis & Lactic Acid Fermentation',
      '#059669',
      '#0f172a'
    ),
    previewText: 'Cellular respiration under anaerobic conditions and lactic acid.',
  },
  {
    id: 'sample-history',
    subject: 'History',
    title: 'US History: Declaration of Independence',
    difficulty: 'All Grades',
    image: createSampleImage(
      'US HISTORY',
      'Examine this historical context:<br/><br/><em>"We hold these truths to be self-evident, that all men are created equal, that they are endowed by their Creator with certain unalienable Rights..."</em><br/><br/><strong>Question:</strong> Which Enlightenment philosopher most heavily influenced Thomas Jefferson when drafting this statement, and what was his original phrase?',
      'Primary Source Analysis (1776)',
      '#7c3aed',
      '#0f172a'
    ),
    previewText: 'Enlightenment influence on the Declaration of Independence & John Locke.',
  },
];
