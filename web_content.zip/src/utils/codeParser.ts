import type { CodeSegment } from '../types/mycode';
import { inferLanguageFromPath, normalizeWorkspacePath } from './workspaceStore';

function extractFilePathFromInfo(
  rawInfo: string,
  precedingMarkdown: string
): { language: string; filePath: string | null } {
  const info = rawInfo.trim();

  // Pattern 1: ```tsx:src/App.tsx or ```python:app.py
  const colonMatch = info.match(/^([a-zA-Z0-9_+-]+):([^\s]+)$/);
  if (colonMatch) {
    return {
      language: colonMatch[1].toLowerCase(),
      filePath: normalizeWorkspacePath(colonMatch[2]),
    };
  }

  // Pattern 2: ```python path="app.py" or ```html file="index.html"
  const attrMatch = info.match(/^([a-zA-Z0-9_+-]+)\s+(?:path|file|filename)=["']?([^"'\s]+)["']?/i);
  if (attrMatch) {
    return {
      language: attrMatch[1].toLowerCase(),
      filePath: normalizeWorkspacePath(attrMatch[2]),
    };
  }

  // Pattern 3: ```html index.html or ```src/App.tsx
  const spaceMatch = info.match(/^([a-zA-Z0-9_+-]+)\s+([^\s]+\.[a-zA-Z0-9]{1,10})$/);
  if (spaceMatch) {
    return {
      language: spaceMatch[1].toLowerCase(),
      filePath: normalizeWorkspacePath(spaceMatch[2]),
    };
  }

  if (info.includes('.') && !info.includes(' ')) {
    const cleaned = normalizeWorkspacePath(info);
    return {
      language: inferLanguageFromPath(cleaned),
      filePath: cleaned,
    };
  }

  const language = info.split(/\s+/)[0]?.toLowerCase() || 'text';

  // Pattern 4: Check the last non-empty line before the fence for `filename.ext` or **filename.ext**
  const lines = precedingMarkdown.trimEnd().split('\n');
  const lastLine = (lines[lines.length - 1] || '').trim();
  const headingOrInlineFile = lastLine.match(
    /^(?:#{1,4}\s*)?(?:File:\s*)?[`*]{0,2}([a-zA-Z0-9_./-]+\.[a-zA-Z0-9]{1,10})[`*]{0,2}:?$/i
  );
  if (headingOrInlineFile) {
    const candidate = normalizeWorkspacePath(headingOrInlineFile[1]);
    if (candidate && !candidate.startsWith('http')) {
      return { language, filePath: candidate };
    }
  }

  return { language, filePath: null };
}

export function parseResponseSegments(rawText: string): CodeSegment[] {
  const segments: CodeSegment[] = [];
  const fenceRegex = /```([^\n]*)\n([\s\S]*?)```/g;

  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = fenceRegex.exec(rawText)) !== null) {
    const preceding = rawText.slice(lastIndex, match.index);
    if (preceding) {
      segments.push({ type: 'markdown', text: preceding });
    }

    const { language, filePath } = extractFilePathFromInfo(match[1], preceding);
    segments.push({
      type: 'code',
      language,
      filePath,
      code: match[2].replace(/\n$/, ''),
      isClosed: true,
    });

    lastIndex = fenceRegex.lastIndex;
  }

  const remainder = rawText.slice(lastIndex);
  if (remainder) {
    // Check if there is an unclosed streaming fence at the end
    const unclosedIdx = remainder.indexOf('```');
    if (unclosedIdx !== -1) {
      const beforeFence = remainder.slice(0, unclosedIdx);
      if (beforeFence) {
        segments.push({ type: 'markdown', text: beforeFence });
      }
      const afterTicks = remainder.slice(unclosedIdx + 3);
      const newlineIdx = afterTicks.indexOf('\n');
      if (newlineIdx !== -1) {
        const info = afterTicks.slice(0, newlineIdx);
        const codeBody = afterTicks.slice(newlineIdx + 1);
        const { language, filePath } = extractFilePathFromInfo(info, beforeFence);
        segments.push({
          type: 'code',
          language,
          filePath,
          code: codeBody,
          isClosed: false,
        });
      } else {
        // Still typing the opening fence info line
        segments.push({
          type: 'code',
          language: afterTicks.trim() || 'text',
          filePath: null,
          code: '',
          isClosed: false,
        });
      }
    } else {
      segments.push({ type: 'markdown', text: remainder });
    }
  }

  return segments;
}

export function extractCompletedFiles(rawText: string): Array<{
  path: string;
  content: string;
  language: string;
}> {
  const segments = parseResponseSegments(rawText);
  const byPath = new Map<string, { path: string; content: string; language: string }>();

  for (const seg of segments) {
    if (seg.type === 'code' && seg.isClosed && seg.filePath) {
      byPath.set(seg.filePath, {
        path: seg.filePath,
        content: seg.code,
        language: seg.language || inferLanguageFromPath(seg.filePath),
      });
    }
  }

  return Array.from(byPath.values());
}
