import {
  Account,
  CustomCategory,
  DebtRecord,
  HisabKhataBackupSchema,
  RepaymentRecord,
  SubscriptionPaymentRecord,
  SubscriptionRecord,
  TransactionRecord,
} from '../types/finance';

export const BACKUP_FORMAT_VERSION = 2;
export const DRIVE_BACKUP_FILENAME = 'hisab_khata_backup_v2.enc.json';

export interface EncryptedBackupEnvelope {
  app: 'HisabKhata';
  backupFormatVersion: number;
  encryptedAt: string;
  algorithm: 'AES-256-GCM';
  kdf: 'PBKDF2-HMAC-SHA256';
  iterations: number;
  saltBase64: string;
  ivBase64: string;
  ciphertextBase64: string;
  plaintextSha256Hex: string;
  recordCounts: {
    accounts: number;
    transactions: number;
    debts: number;
    subscriptions: number;
    categories: number;
  };
}

export interface FullBackupPayload extends HisabKhataBackupSchema {
  schemaVersion: 1;
  appName: 'HisabKhata';
  backupVersion: number;
  exportedAt: string;
  currency: 'BDT';
  accounts: Account[];
  transactions: TransactionRecord[];
  debts: DebtRecord[];
  subscriptions: SubscriptionRecord[];
  categories: CustomCategory[];
  settings?: {
    useBengaliDigits: boolean;
    autoBackupEnabled: boolean;
  };
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

async function sha256Hex(data: Uint8Array): Promise<string> {
  const hashBuffer = await window.crypto.subtle.digest(
    'SHA-256',
    data as unknown as BufferSource
  );
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function deriveAesGcmKey(
  passphrase: string,
  salt: Uint8Array,
  iterations = 150000
): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    encoder.encode(passphrase) as unknown as BufferSource,
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt as unknown as BufferSource,
      iterations,
      hash: 'SHA-256',
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * Encrypts the complete HisabKhata backup payload using AES-256-GCM with PBKDF2 key derivation.
 * Plaintext financial records never leave the device unencrypted.
 */
export async function encryptBackupPayload(
  payload: FullBackupPayload,
  passphrase: string
): Promise<{ envelope: EncryptedBackupEnvelope; serializedJson: string; sizeBytes: number }> {
  if (!passphrase || passphrase.trim().length < 6) {
    throw new Error('নিরাপত্তার জন্য পাসফ্রেজ কমপক্ষে ৬ অক্ষরের হতে হবে।');
  }

  const encoder = new TextEncoder();
  const plaintextJson = JSON.stringify(payload);
  const plaintextBytes = encoder.encode(plaintextJson);
  const plaintextSha256Hex = await sha256Hex(plaintextBytes);

  const salt = window.crypto.getRandomValues(new Uint8Array(16));
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const iterations = 150000;

  const aesKey = await deriveAesGcmKey(passphrase, salt, iterations);
  const encryptedBuffer = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv: iv as unknown as BufferSource,
      tagLength: 128,
    },
    aesKey,
    plaintextBytes as unknown as BufferSource
  );

  const envelope: EncryptedBackupEnvelope = {
    app: 'HisabKhata',
    backupFormatVersion: BACKUP_FORMAT_VERSION,
    encryptedAt: new Date().toISOString(),
    algorithm: 'AES-256-GCM',
    kdf: 'PBKDF2-HMAC-SHA256',
    iterations,
    saltBase64: bytesToBase64(salt),
    ivBase64: bytesToBase64(iv),
    ciphertextBase64: bytesToBase64(new Uint8Array(encryptedBuffer)),
    plaintextSha256Hex,
    recordCounts: {
      accounts: payload.accounts.length,
      transactions: payload.transactions.length,
      debts: payload.debts.length,
      subscriptions: payload.subscriptions.length,
      categories: payload.categories.length,
    },
  };

  const serializedJson = JSON.stringify(envelope, null, 2);
  const sizeBytes = new Blob([serializedJson]).size;

  return { envelope, serializedJson, sizeBytes };
}

/**
 * Validates the encrypted envelope, decrypts using AES-256-GCM, verifies SHA-256 integrity,
 * and deduplicates all records by ID so restoring never creates duplicate entries.
 */
export async function decryptAndValidateBackup(
  rawEnvelopeJson: string,
  passphrase: string
): Promise<FullBackupPayload> {
  if (!passphrase || passphrase.trim().length < 6) {
    throw new Error('সঠিক রিকভারি পাসফ্রেজ প্রদান করুন।');
  }

  let parsedEnvelope: EncryptedBackupEnvelope;
  try {
    parsedEnvelope = JSON.parse(rawEnvelopeJson);
  } catch {
    throw new Error('ব্যাকআপ ফাইলটি ক্ষতিগ্রস্ত বা সঠিক JSON ফরম্যাটে নেই।');
  }

  if (
    parsedEnvelope.app !== 'HisabKhata' ||
    parsedEnvelope.algorithm !== 'AES-256-GCM' ||
    !parsedEnvelope.saltBase64 ||
    !parsedEnvelope.ivBase64 ||
    !parsedEnvelope.ciphertextBase64 ||
    !parsedEnvelope.plaintextSha256Hex
  ) {
    throw new Error('অসম্পূর্ণ বা অবৈধ এনক্রিপ্টেড ব্যাকআপ ফাইল।');
  }

  let decryptedBuffer: ArrayBuffer;
  try {
    const salt = base64ToBytes(parsedEnvelope.saltBase64);
    const iv = base64ToBytes(parsedEnvelope.ivBase64);
    const ciphertext = base64ToBytes(parsedEnvelope.ciphertextBase64);
    const iterations = parsedEnvelope.iterations || 150000;

    const aesKey = await deriveAesGcmKey(passphrase, salt, iterations);
    decryptedBuffer = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: iv as unknown as BufferSource,
        tagLength: 128,
      },
      aesKey,
      ciphertext as unknown as BufferSource
    );
  } catch {
    throw new Error(
      'ডিক্রিপ্ট করা সম্ভব হয়নি! রিকভারি পাসফ্রেজ ভুল অথবা ব্যাকআপ ফাইলটি পরিবর্তন/ক্ষতিগ্রস্ত হয়েছে।'
    );
  }

  const decryptedBytes = new Uint8Array(decryptedBuffer);
  const computedHash = await sha256Hex(decryptedBytes);
  if (computedHash !== parsedEnvelope.plaintextSha256Hex) {
    throw new Error('ব্যাকআপ ফাইলের অখণ্ডতা যাচাই (SHA-256 Checksum) ব্যর্থ হয়েছে!');
  }

  const decoder = new TextDecoder();
  let payload: FullBackupPayload;
  try {
    payload = JSON.parse(decoder.decode(decryptedBytes));
  } catch {
    throw new Error('ডিক্রিপ্টকৃত ডাটা সঠিক ফরম্যাটে নেই।');
  }

  return validateAndDeduplicatePayload(payload);
}

function deduplicateById<T extends { id: string }>(items: T[]): T[] {
  const seen = new Set<string>();
  const result: T[] = [];
  for (const item of items) {
    if (item && typeof item.id === 'string' && !seen.has(item.id)) {
      seen.add(item.id);
      result.push(item);
    }
  }
  return result;
}

export function validateAndDeduplicatePayload(raw: unknown): FullBackupPayload {
  if (!raw || typeof raw !== 'object') {
    throw new Error('ব্যাকআপ ডাটা অবৈধ।');
  }

  const candidate = raw as Partial<FullBackupPayload>;
  if (
    candidate.appName !== 'HisabKhata' ||
    candidate.schemaVersion !== 1 ||
    !Array.isArray(candidate.accounts) ||
    !Array.isArray(candidate.transactions) ||
    !Array.isArray(candidate.debts) ||
    !Array.isArray(candidate.subscriptions)
  ) {
    throw new Error('ব্যাকআপ ফাইলের কাঠামো (Schema) সঠিক নয় বা অসম্পূর্ণ।');
  }

  // Validate numeric amounts & preserve IDs, dates, and relationships without duplicates
  const accounts = deduplicateById(candidate.accounts).filter(
    (a) => typeof a.nameBn === 'string' && Number.isFinite(a.openingBalancePaisa)
  );

  const transactions = deduplicateById(candidate.transactions).filter(
    (t) =>
      typeof t.date === 'string' &&
      typeof t.accountId === 'string' &&
      Number.isFinite(t.amountPaisa) &&
      t.amountPaisa >= 0
  );

  const debts = deduplicateById(candidate.debts)
    .filter(
      (d) =>
        typeof d.contactName === 'string' &&
        Number.isFinite(d.principalPaisa) &&
        Array.isArray(d.repayments)
    )
    .map((d) => ({
      ...d,
      repayments: deduplicateById<RepaymentRecord>(d.repayments).filter((r) =>
        Number.isFinite(r.amountPaisa)
      ),
    }));

  const subscriptions = deduplicateById(candidate.subscriptions)
    .filter(
      (s) =>
        typeof s.nameBn === 'string' &&
        Number.isFinite(s.amountPaisa) &&
        Array.isArray(s.paymentHistory)
    )
    .map((s) => ({
      ...s,
      paymentHistory: deduplicateById<SubscriptionPaymentRecord>(
        s.paymentHistory
      ).filter((p) => Number.isFinite(p.amountPaisa)),
    }));

  const categories = Array.isArray(candidate.categories)
    ? deduplicateById(candidate.categories)
    : [];

  return {
    schemaVersion: 1,
    appName: 'HisabKhata',
    backupVersion: candidate.backupVersion ?? BACKUP_FORMAT_VERSION,
    exportedAt: candidate.exportedAt || new Date().toISOString(),
    currency: 'BDT',
    accounts,
    transactions,
    debts,
    subscriptions,
    categories,
    settings: candidate.settings,
  };
}
