import { ElementSnippet } from "../types";
import { safeSetItem } from "./storage";

export const ELEMENTS_STORAGE_KEY = "noteflow_element_library_v2";

// Helper to create URL-safe SVG data URLs
function svgToDataUrl(svgString: string): string {
  return `data:image/svg+xml;utf8,${encodeURIComponent(svgString.trim())}`;
}

// Curated Goodnotes & Notability style Element & Sticker presets
export const DEFAULT_ELEMENT_PRESETS: ElementSnippet[] = [
  // 1. Stamps & Badges (Stickers)
  {
    id: "sticker-onemli",
    name: "ÖNEMLİ!",
    category: "Çıkartmalar (Stickers)",
    type: "sticker",
    width: 140,
    height: 52,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 60" width="160" height="60">
        <rect x="3" y="3" width="154" height="54" rx="12" fill="#ef4444" stroke="#dc2626" stroke-width="2"/>
        <rect x="6" y="6" width="148" height="48" rx="9" fill="none" stroke="#ffffff" stroke-width="2" stroke-dasharray="6,4"/>
        <text x="80" y="38" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="22" font-weight="900" fill="#ffffff" text-anchor="middle" letter-spacing="2">ÖNEMLİ!</text>
      </svg>
    `),
  },
  {
    id: "sticker-acil",
    name: "ACİL 🚨",
    category: "Çıkartmalar (Stickers)",
    type: "sticker",
    width: 130,
    height: 50,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 140 50" width="140" height="50">
        <rect x="2" y="2" width="136" height="46" rx="23" fill="#b91c1c"/>
        <circle cx="25" cy="25" r="14" fill="#ffffff" opacity="0.2"/>
        <text x="25" y="31" font-size="16" text-anchor="middle">🚨</text>
        <text x="82" y="32" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="18" font-weight="900" fill="#ffffff" letter-spacing="2">ACİL</text>
      </svg>
    `),
  },
  {
    id: "sticker-dikkat",
    name: "DİKKAT ⚠️",
    category: "Çıkartmalar (Stickers)",
    type: "sticker",
    width: 140,
    height: 50,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 50" width="150" height="50">
        <rect x="2" y="2" width="146" height="46" rx="10" fill="#f59e0b" stroke="#d97706" stroke-width="2"/>
        <text x="26" y="32" font-size="18" text-anchor="middle">⚠️</text>
        <text x="86" y="33" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="18" font-weight="900" fill="#ffffff" letter-spacing="1.5">DİKKAT</text>
      </svg>
    `),
  },
  {
    id: "sticker-vize-final",
    name: "VİZE / FİNAL 🎓",
    category: "Çıkartmalar (Stickers)",
    type: "sticker",
    width: 170,
    height: 52,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 180 54" width="180" height="54">
        <rect x="3" y="3" width="174" height="48" rx="12" fill="#3b82f6" stroke="#2563eb" stroke-width="2"/>
        <text x="26" y="34" font-size="18" text-anchor="middle">🎓</text>
        <text x="100" y="34" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="16" font-weight="900" fill="#ffffff" letter-spacing="1">VİZE / FİNAL</text>
      </svg>
    `),
  },
  {
    id: "sticker-fikir",
    name: "FİKİR 💡",
    category: "Çıkartmalar (Stickers)",
    type: "sticker",
    width: 130,
    height: 50,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 140 50" width="140" height="50">
        <rect x="2" y="2" width="136" height="46" rx="23" fill="#8b5cf6" stroke="#7c3aed" stroke-width="2"/>
        <text x="26" y="32" font-size="18" text-anchor="middle">💡</text>
        <text x="80" y="32" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="17" font-weight="900" fill="#ffffff" letter-spacing="1.5">FİKİR</text>
      </svg>
    `),
  },
  {
    id: "sticker-tamamlandi",
    name: "TAMAMLANDI ✔️",
    category: "Çıkartmalar (Stickers)",
    type: "sticker",
    width: 170,
    height: 50,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 180 50" width="180" height="50">
        <rect x="2" y="2" width="176" height="46" rx="12" fill="#10b981" stroke="#059669" stroke-width="2"/>
        <circle cx="28" cy="25" r="12" fill="#ffffff"/>
        <path d="M22 25 L26 29 L34 21" stroke="#059669" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
        <text x="104" y="32" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="15" font-weight="900" fill="#ffffff" letter-spacing="1">TAMAMLANDI</text>
      </svg>
    `),
  },
  {
    id: "sticker-yildiz",
    name: "YILDIZ ⭐",
    category: "Çıkartmalar (Stickers)",
    type: "sticker",
    width: 130,
    height: 50,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 140 50" width="140" height="50">
        <rect x="2" y="2" width="136" height="46" rx="10" fill="#fbbf24" stroke="#d97706" stroke-width="2"/>
        <text x="26" y="33" font-size="20" text-anchor="middle">⭐</text>
        <text x="80" y="33" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="17" font-weight="900" fill="#78350f" letter-spacing="1">YILDIZ</text>
      </svg>
    `),
  },
  {
    id: "sticker-gozden-gecir",
    name: "TEKRAR ET 🔁",
    category: "Çıkartmalar (Stickers)",
    type: "sticker",
    width: 160,
    height: 50,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 170 50" width="170" height="50">
        <rect x="2" y="2" width="166" height="46" rx="12" fill="#06b6d4" stroke="#0891b2" stroke-width="2"/>
        <text x="26" y="33" font-size="18" text-anchor="middle">🔁</text>
        <text x="96" y="32" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="15" font-weight="900" fill="#ffffff" letter-spacing="1">TEKRAR ET</text>
      </svg>
    `),
  },

  // 2. Sticky Notes / Post-itler
  {
    id: "postit-yellow",
    name: "Sarı Post-it Notu",
    category: "Post-it & Notlar",
    type: "postit",
    width: 200,
    height: 140,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 220 150" width="220" height="150">
        <defs>
          <filter id="shadow" x="-5%" y="-5%" width="115%" height="115%">
            <feDropShadow dx="2" dy="4" stdDeviation="3" flood-opacity="0.18"/>
          </filter>
        </defs>
        <g filter="url(#shadow)">
          <path d="M 5 5 L 215 5 L 215 125 L 195 145 L 5 145 Z" fill="#fef08a"/>
          <path d="M 195 125 L 215 125 L 195 145 Z" fill="#fde047"/>
          <rect x="85" y="1" width="50" height="12" fill="#facc15" opacity="0.6" rx="2"/>
          <line x1="20" y1="38" x2="200" y2="38" stroke="#ca8a04" stroke-width="1" opacity="0.3" stroke-dasharray="4,4"/>
          <line x1="20" y1="68" x2="200" y2="68" stroke="#ca8a04" stroke-width="1" opacity="0.3" stroke-dasharray="4,4"/>
          <line x1="20" y1="98" x2="200" y2="98" stroke="#ca8a04" stroke-width="1" opacity="0.3" stroke-dasharray="4,4"/>
          <text x="24" y="32" font-family="'Caveat', cursive, sans-serif" font-size="16" font-weight="bold" fill="#854d0e">📌 Hızlı Hatırlatma</text>
          <text x="24" y="60" font-family="'Caveat', cursive, sans-serif" font-size="14" fill="#a16207">Önemli notlarınızı buraya</text>
          <text x="24" y="90" font-family="'Caveat', cursive, sans-serif" font-size="14" fill="#a16207">kaydedebilirsiniz...</text>
        </g>
      </svg>
    `),
  },
  {
    id: "postit-pink",
    name: "Pembe Post-it Notu",
    category: "Post-it & Notlar",
    type: "postit",
    width: 200,
    height: 140,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 220 150" width="220" height="150">
        <defs>
          <filter id="shadowP" x="-5%" y="-5%" width="115%" height="115%">
            <feDropShadow dx="2" dy="4" stdDeviation="3" flood-opacity="0.18"/>
          </filter>
        </defs>
        <g filter="url(#shadowP)">
          <path d="M 5 5 L 215 5 L 215 125 L 195 145 L 5 145 Z" fill="#fbcfe8"/>
          <path d="M 195 125 L 215 125 L 195 145 Z" fill="#f472b6"/>
          <rect x="85" y="1" width="50" height="12" fill="#f472b6" opacity="0.6" rx="2"/>
          <line x1="20" y1="38" x2="200" y2="38" stroke="#db2777" stroke-width="1" opacity="0.3" stroke-dasharray="4,4"/>
          <line x1="20" y1="68" x2="200" y2="68" stroke="#db2777" stroke-width="1" opacity="0.3" stroke-dasharray="4,4"/>
          <line x1="20" y1="98" x2="200" y2="98" stroke="#db2777" stroke-width="1" opacity="0.3" stroke-dasharray="4,4"/>
          <text x="24" y="32" font-family="sans-serif" font-size="15" font-weight="bold" fill="#9d174d">🌸 Görev Notu</text>
          <text x="24" y="60" font-family="sans-serif" font-size="13" fill="#be185d">• Hedeflerini gözden geçir</text>
          <text x="24" y="90" font-family="sans-serif" font-size="13" fill="#be185d">• Kontrol listesini tamamla</text>
        </g>
      </svg>
    `),
  },
  {
    id: "postit-mint",
    name: "Nane Yeşili Post-it",
    category: "Post-it & Notlar",
    type: "postit",
    width: 200,
    height: 140,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 220 150" width="220" height="150">
        <defs>
          <filter id="shadowM" x="-5%" y="-5%" width="115%" height="115%">
            <feDropShadow dx="2" dy="4" stdDeviation="3" flood-opacity="0.18"/>
          </filter>
        </defs>
        <g filter="url(#shadowM)">
          <path d="M 5 5 L 215 5 L 215 125 L 195 145 L 5 145 Z" fill="#a7f3d0"/>
          <path d="M 195 125 L 215 125 L 195 145 Z" fill="#34d399"/>
          <rect x="85" y="1" width="50" height="12" fill="#34d399" opacity="0.6" rx="2"/>
          <text x="24" y="34" font-family="sans-serif" font-size="15" font-weight="bold" fill="#065f46">🌿 Proje Özeti</text>
          <line x1="20" y1="42" x2="200" y2="42" stroke="#059669" stroke-width="1.5" opacity="0.4"/>
          <text x="24" y="66" font-family="sans-serif" font-size="13" fill="#047857">1. Planlama aşaması</text>
          <text x="24" y="92" font-family="sans-serif" font-size="13" fill="#047857">2. Uygulama ve testler</text>
        </g>
      </svg>
    `),
  },

  // 3. Washi Tapes & Highlighters (Vurgulayıcı Bantlar)
  {
    id: "washi-yellow",
    name: "Sarı Vurgulayıcı Bant",
    category: "Şekil & İşaretçiler",
    type: "sticker",
    width: 200,
    height: 36,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 40" width="240" height="40">
        <rect x="4" y="6" width="232" height="28" fill="#fef08a" opacity="0.75" rx="3"/>
        <line x1="4" y1="6" x2="8" y2="34" stroke="#ca8a04" stroke-width="1" stroke-dasharray="2,2"/>
        <line x1="236" y1="6" x2="232" y2="34" stroke="#ca8a04" stroke-width="1" stroke-dasharray="2,2"/>
        <text x="120" y="25" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="13" font-weight="700" fill="#854d0e" text-anchor="middle" letter-spacing="1">⚡ ÖNEMLİ VURGU ALANI</text>
      </svg>
    `),
  },
  {
    id: "washi-coral",
    name: "Mercan Vurgulayıcı Bant",
    category: "Şekil & İşaretçiler",
    type: "sticker",
    width: 200,
    height: 36,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 40" width="240" height="40">
        <rect x="4" y="6" width="232" height="28" fill="#fecdd3" opacity="0.8" rx="3"/>
        <line x1="4" y1="6" x2="8" y2="34" stroke="#e11d48" stroke-width="1" stroke-dasharray="2,2"/>
        <line x1="236" y1="6" x2="232" y2="34" stroke="#e11d48" stroke-width="1" stroke-dasharray="2,2"/>
        <text x="120" y="25" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="13" font-weight="700" fill="#9f1239" text-anchor="middle" letter-spacing="1">📌 UNUTMA & DİKKAT ET</text>
      </svg>
    `),
  },

  // 4. Arrows & Markers
  {
    id: "arrow-cyan",
    name: "Vurgu Oku (Sağ)",
    category: "Şekil & İşaretçiler",
    type: "sticker",
    width: 120,
    height: 48,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 140 50" width="140" height="50">
        <path d="M 15 25 Q 70 12 105 25" fill="none" stroke="#0ea5e9" stroke-width="6" stroke-linecap="round"/>
        <path d="M 90 12 L 125 25 L 95 38" fill="none" stroke="#0ea5e9" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `),
  },
  {
    id: "badge-target",
    name: "Hedef İşareti 🎯",
    category: "Şekil & İşaretçiler",
    type: "sticker",
    width: 140,
    height: 46,
    createdAt: "2026-01-01T00:00:00.000Z",
    data: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 48" width="150" height="48">
        <rect x="2" y="2" width="146" height="44" rx="22" fill="#ec4899" stroke="#db2777" stroke-width="2"/>
        <text x="26" y="31" font-size="18" text-anchor="middle">🎯</text>
        <text x="86" y="30" font-family="sans-serif" font-size="15" font-weight="900" fill="#ffffff" letter-spacing="1">HEDEF</text>
      </svg>
    `),
  },
];

// Load elements from localStorage (or fallback to defaults)
export function getStoredElements(): ElementSnippet[] {
  try {
    const raw = localStorage.getItem(ELEMENTS_STORAGE_KEY);
    if (!raw) {
      return DEFAULT_ELEMENT_PRESETS;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return DEFAULT_ELEMENT_PRESETS;
    }

    // Filter out duplicate presets and keep user-created custom clips
    const userCustomClips = parsed.filter((p: any) => p && p.id && !p.id.startsWith("sticker-"));
    return [...DEFAULT_ELEMENT_PRESETS, ...userCustomClips];
  } catch (err) {
    console.warn("Failed to load elements library:", err);
    return DEFAULT_ELEMENT_PRESETS;
  }
}

// Save elements into localStorage (persists custom user clips only to save storage quota)
export function saveStoredElements(elements: ElementSnippet[]): void {
  try {
    // Only save user-created custom clips to avoid bloating localStorage with built-in SVG presets
    const userCustomClips = elements.filter((el) => el && el.id && !el.id.startsWith("sticker-"));
    safeSetItem(ELEMENTS_STORAGE_KEY, JSON.stringify(userCustomClips.slice(0, 50)));
  } catch (err) {
    console.warn("Failed to save elements library:", err);
  }
}

// Generate an SVG sticker dataURL for custom clipped text
export function createTextSnippetSticker(
  title: string,
  text: string,
  category: string = "Kırpıntılarım (Snippets)"
): ElementSnippet {
  const safeTitle = title ? title.slice(0, 30) : "Önemli Kırpıntı";
  const safeText = text.trim();
  const lines = safeText.split("\n").slice(0, 5);

  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 280 140" width="280" height="140">
      <defs>
        <filter id="boxShadow" x="-5%" y="-5%" width="115%" height="115%">
          <feDropShadow dx="2" dy="4" stdDeviation="3" flood-opacity="0.14"/>
        </filter>
      </defs>
      <g filter="url(#boxShadow)">
        <rect x="4" y="4" width="272" height="132" rx="14" fill="#ffffff" stroke="#0d9488" stroke-width="2"/>
        <rect x="4" y="4" width="272" height="28" rx="14" fill="#0d9488"/>
        <rect x="4" y="18" width="272" height="14" fill="#0d9488"/>
        <text x="14" y="23" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="12" font-weight="bold" fill="#ffffff">✂️ ${safeTitle}</text>
        <g fill="#1e293b" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="12" line-height="1.5">
          ${lines.map((l, idx) => `<text x="14" y="${54 + idx * 18}">${l.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").slice(0, 36)}</text>`).join("")}
        </g>
      </g>
    </svg>
  `;

  return {
    id: `snippet-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    name: safeTitle,
    category: "Kırpıntılarım (Snippets)",
    type: "lasso",
    data: svgToDataUrl(svg),
    sourceText: text,
    createdAt: new Date().toISOString(),
    width: 280,
    height: 140,
  };
}
