import JSZip from 'jszip';
import { ExambroConfig } from '../types/exambro';

export interface GeneratedAndroidFile {
  path: string;
  label: string;
  language: 'kotlin' | 'xml' | 'yaml' | 'markdown';
  content: string;
}

function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, "\\'");
}

function escapeKotlinString(str: string): string {
  return str.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}

export function generateAndroidFiles(
  config: ExambroConfig,
): GeneratedAndroidFile[] {
  const pkgPath = config.packageName.replace(/\./g, '/');
  const domainsKotlinList = config.allowedDomains
    .map((d) => `"${escapeKotlinString(d.trim().toLowerCase())}"`)
    .join(',\n        ');

  const mainActivityKt = `package ${config.packageName}

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val EXAM_URL = "${escapeKotlinString(config.examUrl)}"
        private const val EXIT_PIN = "${escapeKotlinString(config.exitPin)}"
        private const val EXAM_TOKEN = "${escapeKotlinString(config.security.examToken)}"
        private const val REQUIRE_TOKEN = ${config.security.requireToken}
        private const val EXAM_DURATION_MINUTES = ${config.durationMinutes}L
        private const val MAX_VIOLATIONS = ${config.maxViolationsBeforeLock}

        private const val ENABLE_LOCK_TASK = ${config.security.lockTaskMode}
        private const val ENABLE_FLAG_SECURE = ${config.security.flagSecure}
        private const val BLOCK_SPLIT_SCREEN = ${config.security.blockSplitScreen}
        private const val DETECT_FLOATING_APPS = ${config.security.detectFloatingApps}
        private const val MUTE_SYSTEM_AUDIO = ${config.security.muteAudio}
        private const val BLOCK_BACK_BUTTON = ${config.security.blockBackNavigation}
        private const val CLEAR_DATA_ON_EXIT = ${config.security.clearDataOnExit}
        private const val PLAY_ALARM_ON_VIOLATION = ${config.security.kioskSoundAlarm}

        private val ALLOWED_HOSTS = setOf(
        ${domainsKotlinList}
        )
    }

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvTimer: TextView
    private lateinit var tvViolations: TextView
    private lateinit var lockOverlay: LinearLayout
    private lateinit var tvLockReason: TextView
    private lateinit var btnResumeExam: Button
    private lateinit var btnUnlockProctor: Button
    private lateinit var btnReload: Button
    private lateinit var btnExit: Button

    private var violationCount = 0
    private var isAuthorizedExit = false
    private var examStarted = false
    private var countDownTimer: CountDownTimer? = null
    private var previousMediaVolume: Int = -1
    private var previousNotificationVolume: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Anti-Screenshot & Anti-Screen Recording
        if (ENABLE_FLAG_SECURE) {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_main)
        enableImmersiveFullscreen()

        webView = findViewById(R.id.examWebView)
        progressBar = findViewById(R.id.examProgressBar)
        tvTimer = findViewById(R.id.tvExamTimer)
        tvViolations = findViewById(R.id.tvViolationCount)
        lockOverlay = findViewById(R.id.securityLockOverlay)
        tvLockReason = findViewById(R.id.tvLockReason)
        btnResumeExam = findViewById(R.id.btnResumeExam)
        btnUnlockProctor = findViewById(R.id.btnUnlockProctor)
        btnReload = findViewById(R.id.btnReloadExam)
        btnExit = findViewById(R.id.btnExitExam)

        setupBackNavigationLock()
        setupWebView()
        setupToolbarActions()

        if (MUTE_SYSTEM_AUDIO) {
            muteDeviceAudio()
        }

        if (REQUIRE_TOKEN) {
            promptExamToken()
        } else {
            startExamSession()
        }
    }

    private fun enableImmersiveFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun setupBackNavigationLock() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (BLOCK_BACK_BUTTON) {
                    Toast.makeText(
                        this@MainActivity,
                        "Tombol kembali dinonaktifkan selama ujian. Gunakan tombol Keluar (PIN Pengawas).",
                        Toast.LENGTH_SHORT
                    ).show()
                } else if (webView.canGoBack()) {
                    webView.goBack()
                }
            }
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.setSupportMultipleWindows(false)
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        webView.setOnLongClickListener { true }
        webView.isLongClickable = false
        webView.isHapticFeedbackEnabled = false

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
                progressBar.progress = newProgress
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url ?: return true
                return !isUrlAllowed(url)
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    val offlineHtml = """
                        <html>
                        <body style="font-family:sans-serif;padding:32px;text-align:center;background:#f8fafc;color:#0f172a;">
                          <h2>Halaman Ujian Tidak Dapat Dimuat</h2>
                          <p>Periksa koneksi internet perangkat siswa lalu tekan tombol Muat Ulang di bilah atas.</p>
                        </body>
                        </html>
                    """.trimIndent()
                    webView.loadDataWithBaseURL(null, offlineHtml, "text/html", "utf-8", null)
                }
            }
        }
    }

    private fun isUrlAllowed(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return false
        if (scheme != "https" && scheme != "http") {
            Toast.makeText(this, "Aplikasi eksternal diblokir oleh Exambro.", Toast.LENGTH_SHORT).show()
            return false
        }
        val host = uri.host?.lowercase() ?: return false
        val allowed = ALLOWED_HOSTS.any { domain ->
            host == domain || host.endsWith(".\$domain")
        }
        if (!allowed) {
            Toast.makeText(
                this,
                "Akses ke domain luar (\$host) diblokir selama ujian.",
                Toast.LENGTH_SHORT
            ).show()
        }
        return allowed
    }

    private fun setupToolbarActions() {
        btnReload.setOnClickListener {
            if (isInternetAvailable()) {
                webView.reload()
            } else {
                Toast.makeText(this, "Tidak ada koneksi internet.", Toast.LENGTH_SHORT).show()
            }
        }

        btnExit.setOnClickListener {
            showProctorPinDialog(isExitRequest = true)
        }

        btnResumeExam.setOnClickListener {
            if (violationCount < MAX_VIOLATIONS && !isSplitScreenActive()) {
                lockOverlay.visibility = View.GONE
                enableImmersiveFullscreen()
                ensureLockTaskActive()
            } else {
                Toast.makeText(
                    this,
                    "Perangkat terkunci. Pengawas harus memasukkan PIN.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        btnUnlockProctor.setOnClickListener {
            showProctorPinDialog(isExitRequest = false)
        }
    }

    private fun promptExamToken() {
        val input = EditText(this).apply {
            hint = "Masukkan Token Ujian"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        AlertDialog.Builder(this)
            .setTitle("Verifikasi Token Asesmen")
            .setMessage("${escapeKotlinString(config.examTitle)}\\nMasukkan token dari pengawas ruang:")
            .setCancelable(false)
            .setView(input)
            .setPositiveButton("Masuk Ujian") { _, _ ->
                if (input.text.toString().trim().equals(EXAM_TOKEN, ignoreCase = true)) {
                    startExamSession()
                } else {
                    Toast.makeText(this, "Token salah!", Toast.LENGTH_SHORT).show()
                    promptExamToken()
                }
            }
            .setNegativeButton("Keluar") { _, _ ->
                showProctorPinDialog(isExitRequest = true)
            }
            .show()
    }

    private fun startExamSession() {
        examStarted = true
        ensureLockTaskActive()
        startExamTimer()
        webView.loadUrl(EXAM_URL)
    }

    private fun ensureLockTaskActive() {
        if (!ENABLE_LOCK_TASK) return
        try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val inLockTask = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE
            } else {
                @Suppress("DEPRECATION")
                am.isInLockTaskMode
            }
            if (!inLockTask) {
                startLockTask()
            }
        } catch (_: Exception) {
            // Pengguna dapat menyetujui dialog Sematkan Layar (Screen Pinning) dari sistem Android
        }
    }

    private fun startExamTimer() {
        countDownTimer?.cancel()
        countDownTimer = object : CountDownTimer(EXAM_DURATION_MINUTES * 60_000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val totalSec = millisUntilFinished / 1000
                val hours = totalSec / 3600
                val mins = (totalSec % 3600) / 60
                val secs = totalSec % 60
                tvTimer.text = String.format("%02d:%02d:%02d", hours, mins, secs)
            }

            override fun onFinish() {
                tvTimer.text = "00:00:00"
                triggerSecurityLock("Waktu ujian telah berakhir. Silakan serahkan perangkat atau hubungi pengawas.")
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        enableImmersiveFullscreen()
        if (examStarted && !isAuthorizedExit) {
            ensureLockTaskActive()
            if (BLOCK_SPLIT_SCREEN && isSplitScreenActive()) {
                registerViolation("Mode Layar Terbagi (Split-Screen) atau Picture-in-Picture terdeteksi.")
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            enableImmersiveFullscreen()
        } else if (examStarted && !isAuthorizedExit && DETECT_FLOATING_APPS) {
            registerViolation("Fokus aplikasi hilang (mencoba membuka aplikasi lain / floating window / panel notifikasi).")
        }
    }

    private fun isSplitScreenActive(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            isInMultiWindowMode || isInPictureInPictureMode
        } else {
            false
        }
    }

    private fun registerViolation(reason: String) {
        violationCount += 1
        tvViolations.text = "Pelanggaran: \$violationCount"
        if (PLAY_ALARM_ON_VIOLATION) {
            playWarningTone()
        }
        triggerSecurityLock(reason)
    }

    private fun triggerSecurityLock(reason: String) {
        lockOverlay.visibility = View.VISIBLE
        tvLockReason.text = "\$reason\\n\\nTotal pelanggaran tercatat: \$violationCount / \$MAX_VIOLATIONS"
        btnResumeExam.visibility =
            if (violationCount < MAX_VIOLATIONS && !isSplitScreenActive()) View.VISIBLE else View.GONE
    }

    private fun playWarningTone() {
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_ALARM, 90)
            toneGen.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 600)
        } catch (_: Exception) {
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (MUTE_SYSTEM_AUDIO && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun muteDeviceAudio() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            previousMediaVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            previousNotificationVolume = audioManager.getStreamVolume(AudioManager.STREAM_NOTIFICATION)
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
            audioManager.setStreamVolume(AudioManager.STREAM_NOTIFICATION, 0, 0)
        } catch (_: Exception) {
        }
    }

    private fun restoreDeviceAudio() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (previousMediaVolume >= 0) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, previousMediaVolume, 0)
            }
            if (previousNotificationVolume >= 0) {
                audioManager.setStreamVolume(AudioManager.STREAM_NOTIFICATION, previousNotificationVolume, 0)
            }
        } catch (_: Exception) {
        }
    }

    private fun showProctorPinDialog(isExitRequest: Boolean) {
        val input = EditText(this).apply {
            hint = "Masukkan PIN Pengawas"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }

        val title = if (isExitRequest) "Konfirmasi Keluar Ujian" else "Buka Kunci Pengawas"
        val message = if (isExitRequest) {
            "Masukkan PIN Pengawas untuk mengakhiri sesi ujian dan melepas kunci aplikasi."
        } else {
            "Masukkan PIN Pengawas untuk mereset kunci pelanggaran siswa."
        }

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setView(input)
            .setPositiveButton("Verifikasi") { _, _ ->
                if (input.text.toString().trim() == EXIT_PIN) {
                    if (isExitRequest) {
                        performSafeExit()
                    } else {
                        violationCount = 0
                        tvViolations.text = "Pelanggaran: 0"
                        lockOverlay.visibility = View.GONE
                        enableImmersiveFullscreen()
                        ensureLockTaskActive()
                    }
                } else {
                    Toast.makeText(this, "PIN Pengawas salah!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun performSafeExit() {
        isAuthorizedExit = true
        countDownTimer?.cancel()
        if (MUTE_SYSTEM_AUDIO) {
            restoreDeviceAudio()
        }
        if (CLEAR_DATA_ON_EXIT) {
            webView.clearCache(true)
            webView.clearHistory()
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        }
        try {
            stopLockTask()
        } catch (_: Exception) {
        }
        finishAndRemoveTask()
    }

    private fun isInternetAvailable(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    override fun onDestroy() {
        countDownTimer?.cancel()
        super.onDestroy()
    }
}
`;

  const androidManifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.REORDER_TASKS" />

    <application
        android:allowBackup="false"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="false"
        android:icon="@android:drawable/ic_lock_lock"
        android:label="@string/app_name"
        android:networkSecurityConfig="@xml/network_security_config"
        android:supportsRtl="true"
        android:theme="@style/Theme.Exambro"
        android:usesCleartextTraffic="false"
        tools:targetApi="35">

        <activity
            android:name=".MainActivity"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:excludeFromRecents="true"
            android:exported="true"
            android:launchMode="singleTask"
            android:lockTaskMode="normal"
            android:resizeableActivity="${config.security.blockSplitScreen ? 'false' : 'true'}"
            android:screenOrientation="portrait"
            android:supportsPictureInPicture="false">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

    </application>

</manifest>
`;

  const appBuildGradleKts = `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "${config.packageName}"
    compileSdk = 35

    defaultConfig {
        applicationId = "${config.packageName}"
        minSdk = 26
        targetSdk = 35
        versionCode = ${config.versionCode}
        versionName = "${config.versionName}"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
`;

  const rootBuildGradleKts = `plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
`;

  const settingsGradleKts = `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "ExambroMTsInayatulMarzuki"
include(":app")
`;

  const gradleProperties = `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`;

  const gradleWrapperProperties = `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.9-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`;

  const activityMainXml = `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#0F172A">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:orientation="vertical">

        <!-- Bilah Atas Ujian -->
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:background="#064E3B"
            android:gravity="center_vertical"
            android:orientation="horizontal"
            android:paddingHorizontal="12dp"
            android:paddingVertical="10dp">

            <LinearLayout
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:orientation="vertical">

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:ellipsize="end"
                    android:maxLines="1"
                    android:text="@string/school_name"
                    android:textColor="#FFFFFF"
                    android:textSize="13sp"
                    android:textStyle="bold" />

                <LinearLayout
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal">

                    <TextView
                        android:id="@+id/tvExamTimer"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:fontFamily="monospace"
                        android:text="01:30:00"
                        android:textColor="#A7F3D0"
                        android:textSize="12sp" />

                    <TextView
                        android:id="@+id/tvViolationCount"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_marginStart="12dp"
                        android:text="Pelanggaran: 0"
                        android:textColor="#FDE68A"
                        android:textSize="12sp" />
                </LinearLayout>
            </LinearLayout>

            <Button
                android:id="@+id/btnReloadExam"
                android:layout_width="wrap_content"
                android:layout_height="36dp"
                android:layout_marginEnd="6dp"
                android:backgroundTint="#047857"
                android:minWidth="0dp"
                android:paddingHorizontal="10dp"
                android:text="Muat Ulang"
                android:textAllCaps="false"
                android:textColor="#FFFFFF"
                android:textSize="12sp" />

            <Button
                android:id="@+id/btnExitExam"
                android:layout_width="wrap_content"
                android:layout_height="36dp"
                android:backgroundTint="#B91C1C"
                android:minWidth="0dp"
                android:paddingHorizontal="10dp"
                android:text="Keluar"
                android:textAllCaps="false"
                android:textColor="#FFFFFF"
                android:textSize="12sp" />
        </LinearLayout>

        <ProgressBar
            android:id="@+id/examProgressBar"
            style="?android:attr/progressBarStyleHorizontal"
            android:layout_width="match_parent"
            android:layout_height="3dp"
            android:max="100"
            android:progressTint="#10B981" />

        <WebView
            android:id="@+id/examWebView"
            android:layout_width="match_parent"
            android:layout_height="0dp"
            android:layout_weight="1" />
    </LinearLayout>

    <!-- Layar Kunci Pelanggaran -->
    <LinearLayout
        android:id="@+id/securityLockOverlay"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:background="#F07F1D1D"
        android:gravity="center"
        android:orientation="vertical"
        android:padding="28dp"
        android:visibility="gone">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="AKSES UJIAN TERKUNCI"
            android:textColor="#FFFFFF"
            android:textSize="20sp"
            android:textStyle="bold" />

        <TextView
            android:id="@+id/tvLockReason"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp"
            android:gravity="center"
            android:text="Aktivitas mencurigakan terdeteksi."
            android:textColor="#FEE2E2"
            android:textSize="14sp" />

        <Button
            android:id="@+id/btnResumeExam"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="24dp"
            android:backgroundTint="#FFFFFF"
            android:text="Kembali ke Ujian"
            android:textAllCaps="false"
            android:textColor="#7F1D1D" />

        <Button
            android:id="@+id/btnUnlockProctor"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="10dp"
            android:backgroundTint="#450A0A"
            android:text="Buka Kunci (PIN Pengawas)"
            android:textAllCaps="false"
            android:textColor="#FFFFFF" />
    </LinearLayout>
</FrameLayout>
`;

  const stringsXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${escapeXml(config.appName)}</string>
    <string name="school_name">${escapeXml(config.schoolName)}</string>
</resources>
`;

  const themesXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.Exambro" parent="Theme.Material3.DayNight.NoActionBar">
        <item name="colorPrimary">#047857</item>
        <item name="android:statusBarColor">#064E3B</item>
        <item name="android:navigationBarColor">#0F172A</item>
    </style>
</resources>
`;

  const networkSecurityXml = `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false" />
</network-security-config>
`;

  const dataExtractionXml = `<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <exclude domain="sharedpref" path="." />
    </cloud-backup>
</data-extraction-rules>
`;

  const proguardRules = `-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
`;

  const githubWorkflowYml = `name: Build Exambro Android APK

on:
  workflow_dispatch:
  push:
    branches: [ main, master ]

jobs:
  build-apk:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'

      - name: Build Debug APK
        run: gradle assembleDebug --no-daemon

      - name: Build Release Unsigned APK
        run: gradle assembleRelease --no-daemon

      - name: Upload APK Artifacts
        uses: actions/upload-artifact@v4
        with:
          name: Exambro-MTs-Inayatul-Marzuki-APK
          path: |
            app/build/outputs/apk/debug/*.apk
            app/build/outputs/apk/release/*.apk
`;

  const readmeMd = `# ${config.appName}

Project Android Studio siap kompilasi (\`.apk\`) untuk **${config.schoolName}** — **${config.examTitle}**.

## URL Ujian Tertanam
- \`${config.examUrl}\`
- **PIN Pengawas (Keluar / Buka Kunci)**: \`${config.exitPin}\`

## Fitur Penguncian Anti-Aplikasi Lain
1. **Lock Task / Screen Pinning (\`startLockTask()\`)**: Mengunci siswa di dalam aplikasi sehingga tombol Home & Recent Apps tidak dapat digunakan untuk berpindah ke browser lain, WhatsApp, atau aplikasi AI.
2. **Anti-Screenshot & Screen Record (\`FLAG_SECURE\`)**: Mencegah siswa mengambil tangkapan layar atau merekam soal.
3. **Anti-Split Screen & Floating Window**: Menolak mode layar terbagi (\`resizeableActivity="false"\`) serta mendeteksi jendela mengambang via \`onWindowFocusChanged\`.
4. **Domain Whitelist**: Hanya mengizinkan akses ke domain asesmen (${config.allowedDomains.join(', ')}).

## Cara 1: Build APK di Android Studio (Lokal)
1. Ekstrak file ZIP ini.
2. Buka **Android Studio** -> **Open** -> pilih folder hasil ekstrak.
3. Tunggu Gradle Sync selesai.
4. Klik menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. File \`app-debug.apk\` siap dibagikan ke siswa (di folder \`app/build/outputs/apk/debug/\`).

## Cara 2: Build APK Otomatis di Cloud (Tanpa Install Android Studio)
1. Buat repository baru di GitHub (boleh Private atau Public).
2. Unggah seluruh isi folder ZIP ini ke repository tersebut.
3. Buka tab **Actions** -> pilih **Build Exambro Android APK** -> klik **Run workflow**.
4. Setelah selesai (~2 menit), unduh file **Exambro-MTs-Inayatul-Marzuki-APK** dari bagian Artifacts.

## Pengaktifan Mode Kiosk Penuh (Opsional untuk Tablet Sekolah)
Jika menggunakan perangkat milik sekolah yang baru di-reset, jalankan perintah ADB berikut agar Lock Task berjalan tanpa dialog konfirmasi:
\`\`\`bash
adb shell dpm set-device-owner ${config.packageName}/.MainActivity
\`\`\`
Atau pada HP pribadi siswa, aktifkan fitur **Sematkan Aplikasi / Screen Pinning** di Pengaturan Keamanan Android saat pertama kali masuk ujian.
`;

  return [
    {
      path: `app/src/main/java/${pkgPath}/MainActivity.kt`,
      label: 'MainActivity.kt',
      language: 'kotlin',
      content: mainActivityKt,
    },
    {
      path: 'app/src/main/AndroidManifest.xml',
      label: 'AndroidManifest.xml',
      language: 'xml',
      content: androidManifestXml,
    },
    {
      path: 'app/build.gradle.kts',
      label: 'app/build.gradle.kts',
      language: 'kotlin',
      content: appBuildGradleKts,
    },
    {
      path: 'app/src/main/res/layout/activity_main.xml',
      label: 'activity_main.xml',
      language: 'xml',
      content: activityMainXml,
    },
    {
      path: '.github/workflows/build-apk.yml',
      label: 'GitHub Actions (build-apk.yml)',
      language: 'yaml',
      content: githubWorkflowYml,
    },
    {
      path: 'build.gradle.kts',
      label: 'build.gradle.kts (Root)',
      language: 'kotlin',
      content: rootBuildGradleKts,
    },
    {
      path: 'settings.gradle.kts',
      label: 'settings.gradle.kts',
      language: 'kotlin',
      content: settingsGradleKts,
    },
    {
      path: 'gradle.properties',
      label: 'gradle.properties',
      language: 'yaml',
      content: gradleProperties,
    },
    {
      path: 'gradle/wrapper/gradle-wrapper.properties',
      label: 'gradle-wrapper.properties',
      language: 'yaml',
      content: gradleWrapperProperties,
    },
    {
      path: 'app/src/main/res/values/strings.xml',
      label: 'strings.xml',
      language: 'xml',
      content: stringsXml,
    },
    {
      path: 'app/src/main/res/values/themes.xml',
      label: 'themes.xml',
      language: 'xml',
      content: themesXml,
    },
    {
      path: 'app/src/main/res/xml/network_security_config.xml',
      label: 'network_security_config.xml',
      language: 'xml',
      content: networkSecurityXml,
    },
    {
      path: 'app/src/main/res/xml/data_extraction_rules.xml',
      label: 'data_extraction_rules.xml',
      language: 'xml',
      content: dataExtractionXml,
    },
    {
      path: 'app/proguard-rules.pro',
      label: 'proguard-rules.pro',
      language: 'yaml',
      content: proguardRules,
    },
    {
      path: 'README_BUILD_APK.md',
      label: 'README_BUILD_APK.md',
      language: 'markdown',
      content: readmeMd,
    },
  ];
}

export async function downloadAndroidProjectZip(
  config: ExambroConfig,
): Promise<void> {
  const zip = new JSZip();
  const files = generateAndroidFiles(config);

  for (const file of files) {
    zip.file(file.path, file.content);
  }

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  const safeSlug = config.appName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
  link.href = url;
  link.download = `${safeSlug || 'exambro-android-project'}.zip`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
