import { GeneratedImagePayload } from '../types';

export async function renderHighResVisual(
  payload: GeneratedImagePayload,
  scale: 'preview' | 'hd' | '4k' = 'hd'
): Promise<string> {
  const is16by9 = payload.aspectRatio !== '1:1';
  let width = 1280;
  let height = 720;

  if (scale === 'preview') {
    width = is16by9 ? 800 : 600;
    height = is16by9 ? 450 : 600;
  } else if (scale === 'hd') {
    width = is16by9 ? 1920 : 1080;
    height = is16by9 ? 1080 : 1080;
  } else if (scale === '4k') {
    width = is16by9 ? 3840 : 2160;
    height = is16by9 ? 2160 : 2160;
  }

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return payload.dataUrl || '';

  // If real AI image data/URL is provided, render it directly on high-resolution canvas
  if (payload.dataUrl) {
    try {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      await new Promise<void>((resolve) => {
        img.onload = () => resolve();
        img.onerror = () => resolve();
        img.src = payload.dataUrl!;
      });

      if (img.width > 0) {
        ctx.drawImage(img, 0, 0, width, height);
        return canvas.toDataURL('image/jpeg', 0.95);
      }
    } catch (e) {
      console.error('Error drawing image on canvas:', e);
    }
    return payload.dataUrl;
  }

  const scaleFactor = width / 1280;
  const promptLower = (payload.prompt || '').toLowerCase();
  const title = payload.title || 'VIRAL YOUTUBE BLUEPRINT';
  const subtitle = payload.subtitle || 'Algorithm Secret Revealed';
  const badge = payload.badge || '100% VIRAL';

  // Determine theme mode from prompt
  const isAnniversary = promptLower.includes('anniversary') || promptLower.includes('marriage') || promptLower.includes('love') || promptLower.includes('couple');
  const isFood = promptLower.includes('food') || promptLower.includes('paratha') || promptLower.includes('street') || promptLower.includes('cook');
  const isTechAI = promptLower.includes('ai') || promptLower.includes('tech') || promptLower.includes('robot') || promptLower.includes('future') || promptLower.includes('code');
  const isGaming = promptLower.includes('game') || promptLower.includes('gaming') || promptLower.includes('setup') || promptLower.includes('pc') || promptLower.includes('gta');

  // 1. Draw Background
  if (isAnniversary) {
    const bgGrad = ctx.createRadialGradient(width / 2, height / 2, 50 * scaleFactor, width / 2, height / 2, width * 0.7);
    bgGrad.addColorStop(0, '#581c87');
    bgGrad.addColorStop(0.4, '#831843');
    bgGrad.addColorStop(0.8, '#4c0519');
    bgGrad.addColorStop(1, '#0f051d');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // Golden sparkles / bokeh
    for (let i = 0; i < 90; i++) {
      const x = Math.random() * width;
      const y = Math.random() * height;
      const r = (Math.random() * 4 + 1) * scaleFactor;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255, 215, 0, ${Math.random() * 0.7 + 0.3})`;
      ctx.shadowColor = '#FFD700';
      ctx.shadowBlur = 10 * scaleFactor;
      ctx.fill();
    }
  } else if (isFood) {
    const bgGrad = ctx.createLinearGradient(0, 0, width, height);
    bgGrad.addColorStop(0, '#7c2d12');
    bgGrad.addColorStop(0.5, '#451a03');
    bgGrad.addColorStop(1, '#0c0a09');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // Warm embers
    for (let i = 0; i < 70; i++) {
      const x = Math.random() * width;
      const y = Math.random() * height;
      const r = (Math.random() * 5 + 1) * scaleFactor;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(251, 146, 60, ${Math.random() * 0.8 + 0.2})`;
      ctx.shadowColor = '#EA580C';
      ctx.shadowBlur = 12 * scaleFactor;
      ctx.fill();
    }
  } else if (isGaming) {
    const bgGrad = ctx.createLinearGradient(0, 0, width, height);
    bgGrad.addColorStop(0, '#064e3b');
    bgGrad.addColorStop(0.5, '#022c22');
    bgGrad.addColorStop(1, '#050505');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // Matrix neon lines
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.25)';
    ctx.lineWidth = 1 * scaleFactor;
    for (let x = 0; x < width; x += 60 * scaleFactor) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
  } else {
    // Default Cyberpunk / High CTR YouTube neon
    const bgGrad = ctx.createRadialGradient(width * 0.25, height * 0.3, 100 * scaleFactor, width / 2, height / 2, width * 0.8);
    bgGrad.addColorStop(0, '#083344');
    bgGrad.addColorStop(0.4, '#1e1b4b');
    bgGrad.addColorStop(0.7, '#111827');
    bgGrad.addColorStop(1, '#030712');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // Cyber grid perspective lines
    ctx.strokeStyle = 'rgba(0, 255, 255, 0.15)';
    ctx.lineWidth = 1.5 * scaleFactor;
    for (let x = -width; x < width * 2; x += 120 * scaleFactor) {
      ctx.beginPath();
      ctx.moveTo(width / 2, height * 0.3);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
  }

  ctx.shadowBlur = 0;

  // 2. High-Tech Hexagon / Circle Central Emblem
  const centerX = width * 0.82;
  const centerY = height * 0.5;
  const emblemRadius = 160 * scaleFactor;

  // Glowing orb backdrop
  const orbGrad = ctx.createRadialGradient(centerX, centerY, 10 * scaleFactor, centerX, centerY, emblemRadius * 1.4);
  orbGrad.addColorStop(0, isAnniversary ? 'rgba(255, 105, 180, 0.7)' : 'rgba(0, 240, 255, 0.7)');
  orbGrad.addColorStop(0.7, isAnniversary ? 'rgba(234, 179, 8, 0.3)' : 'rgba(236, 72, 153, 0.3)');
  orbGrad.addColorStop(1, 'transparent');
  ctx.fillStyle = orbGrad;
  ctx.beginPath();
  ctx.arc(centerX, centerY, emblemRadius * 1.5, 0, Math.PI * 2);
  ctx.fill();

  // Emblem Outline Ring
  ctx.beginPath();
  ctx.arc(centerX, centerY, emblemRadius, 0, Math.PI * 2);
  ctx.strokeStyle = isAnniversary ? '#FFD700' : '#00FFFF';
  ctx.lineWidth = 6 * scaleFactor;
  ctx.shadowColor = isAnniversary ? '#FFD700' : '#00FFFF';
  ctx.shadowBlur = 20 * scaleFactor;
  ctx.stroke();
  ctx.shadowBlur = 0;

  // Play Button / Heart Icon in Emblem
  if (isAnniversary) {
    // Draw Heart Symbol
    ctx.save();
    ctx.translate(centerX, centerY - 10 * scaleFactor);
    ctx.beginPath();
    const hSize = 50 * scaleFactor;
    ctx.moveTo(0, 0);
    ctx.bezierCurveTo(-hSize, -hSize, -hSize * 1.4, hSize * 0.3, 0, hSize * 1.2);
    ctx.bezierCurveTo(hSize * 1.4, hSize * 0.3, hSize, -hSize, 0, 0);
    ctx.fillStyle = '#FF1493';
    ctx.shadowColor = '#FF69B4';
    ctx.shadowBlur = 25 * scaleFactor;
    ctx.fill();
    ctx.restore();
  } else {
    // Glowing YouTube Play Triangle
    ctx.save();
    ctx.beginPath();
    const pSize = 55 * scaleFactor;
    ctx.moveTo(centerX - pSize * 0.5, centerY - pSize);
    ctx.lineTo(centerX + pSize * 0.8, centerY);
    ctx.lineTo(centerX - pSize * 0.5, centerY + pSize);
    ctx.closePath();
    ctx.fillStyle = '#FFFFFF';
    ctx.shadowColor = '#00F0FF';
    ctx.shadowBlur = 25 * scaleFactor;
    ctx.fill();
    ctx.restore();
  }

  // 3. Top Banner Badge (e.g., "100% VIRAL", "SPECIAL CELEBRATION", "TREND #1")
  const badgeX = 60 * scaleFactor;
  const badgeY = 70 * scaleFactor;
  const badgeWidth = 240 * scaleFactor;
  const badgeHeight = 44 * scaleFactor;

  ctx.fillStyle = isAnniversary ? '#831843' : '#000000';
  ctx.strokeStyle = isAnniversary ? '#F43F5E' : '#00FFFF';
  ctx.lineWidth = 2 * scaleFactor;
  // Safe round rect helper
  if (typeof (ctx as any).roundRect === 'function') {
    (ctx as any).roundRect(badgeX, badgeY, badgeWidth, badgeHeight, 10 * scaleFactor);
  } else {
    ctx.rect(badgeX, badgeY, badgeWidth, badgeHeight);
  }
  ctx.fill();
  ctx.stroke();

  ctx.font = `bold ${18 * scaleFactor}px sans-serif`;
  ctx.fillStyle = isAnniversary ? '#FBCFE8' : '#00FFFF';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(`⚡ ${badge.toUpperCase()}`, badgeX + badgeWidth / 2, badgeY + badgeHeight / 2);

  // 4. Large Eye-Grabbing Title Typography (YouTube Thumbnail Style)
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';

  // Title shadow for contrast
  ctx.shadowColor = 'rgba(0,0,0,0.95)';
  ctx.shadowBlur = 25 * scaleFactor;
  ctx.shadowOffsetX = 4 * scaleFactor;
  ctx.shadowOffsetY = 6 * scaleFactor;

  // Split title if long
  const words = title.toUpperCase().split(' ');
  let line1 = words.slice(0, 3).join(' ');
  let line2 = words.slice(3, 7).join(' ');
  let line3 = words.slice(7).join(' ');

  const titleFontSize = 68 * scaleFactor;
  ctx.font = `900 ${titleFontSize}px "Impact", "Arial Black", sans-serif`;

  const textStartX = 60 * scaleFactor;
  let textY = 145 * scaleFactor;

  // Line 1
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText(line1, textStartX, textY);
  textY += titleFontSize * 1.15;

  // Line 2 (Highlighted with Golden/Yellow or Cyan Gradient)
  if (line2) {
    const textGrad = ctx.createLinearGradient(textStartX, textY, textStartX + 400 * scaleFactor, textY);
    textGrad.addColorStop(0, isAnniversary ? '#FFD700' : '#FFE600');
    textGrad.addColorStop(1, isAnniversary ? '#FF69B4' : '#FF0055');
    ctx.fillStyle = textGrad;
    ctx.fillText(line2, textStartX, textY);
    textY += titleFontSize * 1.15;
  }

  // Line 3
  if (line3) {
    ctx.fillStyle = '#00F0FF';
    ctx.fillText(line3, textStartX, textY);
    textY += titleFontSize * 1.15;
  }

  // Subtitle / Prompt context
  ctx.shadowBlur = 10 * scaleFactor;
  ctx.font = `600 ${28 * scaleFactor}px sans-serif`;
  ctx.fillStyle = '#E2E8F0';
  ctx.fillText(subtitle, textStartX, textY + 10 * scaleFactor);

  // 5. Watermark / Branding in bottom right
  ctx.shadowBlur = 0;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;
  ctx.font = `bold ${16 * scaleFactor}px sans-serif`;
  ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
  ctx.textAlign = 'right';
  ctx.textBaseline = 'bottom';
  ctx.fillText('👑 VIRALSAMRAT AI STUDIO', width - 40 * scaleFactor, height - 30 * scaleFactor);

  // Return base64 data URL
  return canvas.toDataURL('image/png', 0.95);
}

export function downloadImageFile(dataUrl: string, filename = 'viralsamrat_image.png') {
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export async function shareImageFile(dataUrl: string, title: string, text: string): Promise<boolean> {
  try {
    // Convert DataURL to Blob
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    const file = new File([blob], 'viralsamrat_creation.png', { type: 'image/png' });

    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({
        title,
        text,
        files: [file],
      });
      return true;
    } else if (navigator.share) {
      await navigator.share({
        title,
        text,
        url: window.location.href,
      });
      return true;
    } else {
      // Fallback: Copy Image to Clipboard
      if (navigator.clipboard && (window as any).ClipboardItem) {
        const item = new (window as any).ClipboardItem({ 'image/png': blob });
        await navigator.clipboard.write([item]);
        alert('Image copied to clipboard! You can now paste (Ctrl+V) in WhatsApp, YouTube, or Discord.');
        return true;
      }
      // Simple download fallback
      downloadImageFile(dataUrl, 'viralsamrat_creation.png');
      return true;
    }
  } catch (err: any) {
    if (err.name !== 'AbortError') {
      downloadImageFile(dataUrl, 'viralsamrat_creation.png');
    }
    return false;
  }
}
