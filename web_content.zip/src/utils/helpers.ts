import { WallpaperPreset, UserProfile } from '../types';

export const STORAGE_KEY = 'asef_luxury_v20';

export const DEFAULT_WALLPAPER = 'https://firebasestorage.googleapis.com/v0/b/asef-web-86bcb.appspot.com/o/profiles%2F1000070297.png?alt=media';

export const WALLPAPER_PRESETS: WallpaperPreset[] = [
  {
    id: 'asef_original',
    name: 'شعار عاصف الفاخر الأصلي',
    url: 'https://firebasestorage.googleapis.com/v0/b/asef-web-86bcb.appspot.com/o/profiles%2F1000070297.png?alt=media',
    thumbnail: 'https://firebasestorage.googleapis.com/v0/b/asef-web-86bcb.appspot.com/o/profiles%2F1000070297.png?alt=media',
    description: 'الخلفية الرسمية لعالم عاصف الملكي'
  },
  {
    id: 'royal_emerald',
    name: 'الزمرد الملكي الأسود',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=300&q=80',
    description: 'تموجات زمردية عميقة مع لمسات ذهبية داكنة'
  },
  {
    id: 'gold_luxury',
    name: 'الأناقة الذهبية الملكية',
    url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=300&q=80',
    description: 'رخام فاحم عاكس للضوء مع عروق ذهبية'
  },
  {
    id: 'deep_cyber',
    name: 'الليل السيبراني الفاخر',
    url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=300&q=80',
    description: 'تدرجات عصرية فائقة النعومة مع هدوء تام'
  },
  {
    id: 'carbon_pattern',
    name: 'ألياف الكربون المظلمة',
    url: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=300&q=80',
    description: 'نسيج ألياف داكنة فاخرة تناسب شاشات AMOLED'
  }
];

export function generateUniqueAsefId(): string {
  return `ASEF-${Math.floor(111111 + Math.random() * 888888)}`;
}

export function pairKey(a: string, b: string): string {
  return [a, b].sort().join('_');
}

export function formatTime(timestamp: any): string {
  if (!timestamp) return 'الآن';
  try {
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return date.toLocaleTimeString('ar-EG', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  } catch {
    return 'الآن';
  }
}

/**
 * High-precision check for whether a user is genuinely online right now.
 * Combines boolean flag with heartbeat recency (< 40 seconds) to prevent stale ghost online status.
 */
export function isUserActuallyOnline(user?: UserProfile | null): boolean {
  if (!user || user.online !== true) return false;
  if (!user.lastSeen) return false;
  try {
    const date = user.lastSeen.toDate ? user.lastSeen.toDate() : new Date(user.lastSeen);
    const diffMs = Date.now() - date.getTime();
    return diffMs < 40000; // Within 40 seconds of last heartbeat
  } catch {
    return false;
  }
}

export function formatLastSeen(lastSeen: any, isOnline?: boolean): string {
  if (isOnline) return 'متصل الآن 🟢';
  if (!lastSeen) return 'غير متصل';
  try {
    const date = lastSeen.toDate ? lastSeen.toDate() : new Date(lastSeen);
    const diffMin = Math.floor((Date.now() - date.getTime()) / 60000);
    if (diffMin < 1) return 'كان متصلاً للتو';
    if (diffMin < 60) return `آخر ظهور منذ ${diffMin} دقيقة`;
    const diffHours = Math.floor(diffMin / 60);
    if (diffHours < 24) return `آخر ظهور منذ ${diffHours} ساعة`;
    return `آخر ظهور: ${date.toLocaleDateString('ar-EG', { month: 'short', day: 'numeric' })}`;
  } catch {
    return 'غير متصل';
  }
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const maxDim = 1200;
          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            resolve(canvas.toDataURL('image/jpeg', 0.82));
          } else {
            resolve(e.target?.result as string);
          }
        };
        img.onerror = () => resolve(e.target?.result as string);
        img.src = e.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    } else {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    }
  });
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function contactDeveloper() {
  const phone = '967738654396';
  const text = encodeURIComponent('مرحباً أستاذ عاصف الحاتمي، أريد استفسار أو دعم حول تطبيق ASEF | عالم عاصف الفاخر 👑');
  window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
}
