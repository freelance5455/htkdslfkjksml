// Web Speech API Voice Narrator for Axiler Quantum Quotex Engine
import { QuantumSignal } from '../types/trading';

class VoiceNarrator {
  private enabled: boolean = true;
  private autoSpeak: boolean = true;
  private isSpeakingState: boolean = false;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('qx_voice_enabled');
      this.enabled = saved !== null ? saved === 'true' : true;
      const savedAuto = localStorage.getItem('qx_auto_voice');
      this.autoSpeak = savedAuto !== null ? savedAuto === 'true' : true;
    }
  }

  public setVoiceEnabled(enabled: boolean) {
    this.enabled = enabled;
    if (typeof window !== 'undefined') {
      localStorage.setItem('qx_voice_enabled', String(enabled));
      if (!enabled) {
        this.stop();
      }
    }
  }

  public isVoiceEnabled(): boolean {
    return this.enabled;
  }

  public setAutoSpeak(autoSpeak: boolean) {
    this.autoSpeak = autoSpeak;
    if (typeof window !== 'undefined') {
      localStorage.setItem('qx_auto_voice', String(autoSpeak));
    }
  }

  public isAutoSpeak(): boolean {
    return this.autoSpeak;
  }

  public stop() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      this.isSpeakingState = false;
    }
  }

  public isSpeaking(): boolean {
    return this.isSpeakingState;
  }

  public speak(text: string, priority: boolean = false): Promise<void> {
    return new Promise((resolve) => {
      if (!this.enabled || typeof window === 'undefined' || !('speechSynthesis' in window)) {
        resolve();
        return;
      }

      if (priority) {
        window.speechSynthesis.cancel();
      }

      const utterance = new SpeechSynthesisUtterance(text);
      this.currentUtterance = utterance;

      // Select voice: Prefer English natural or standard voices
      const voices = window.speechSynthesis.getVoices();
      const englishVoice =
        voices.find(
          (v) =>
            (v.name.includes('Google') ||
              v.name.includes('Natural') ||
              v.name.includes('Samantha') ||
              v.name.includes('English') ||
              v.name.includes('en-US')) &&
            v.lang.startsWith('en')
        ) || voices.find((v) => v.lang.startsWith('en')) || null;

      if (englishVoice) {
        utterance.voice = englishVoice;
      }

      utterance.rate = 1.05; // Slightly confident, brisk pace
      utterance.pitch = 1.0;
      utterance.volume = 1.0;

      utterance.onstart = () => {
        this.isSpeakingState = true;
      };

      utterance.onend = () => {
        this.isSpeakingState = false;
        resolve();
      };

      utterance.onerror = () => {
        this.isSpeakingState = false;
        resolve();
      };

      window.speechSynthesis.speak(utterance);
    });
  }

  /**
   * Spoken market narrative: tells the trader what the market is saying out loud
   */
  public speakMarketNarrative(signal: QuantumSignal) {
    if (!this.enabled) return;

    const action = signal.direction === 'UP' ? 'BUY CALL' : 'SELL PUT';
    const pairSpoken = signal.pair.replace(' OTC', ' O-T-C').replace('/', ' ');
    const buyerPower = signal.buyerPressure || (signal.direction === 'UP' ? 78 : 22);
    const sellerPower = signal.sellerPressure || (signal.direction === 'UP' ? 22 : 78);

    let narrative = '';
    if (signal.direction === 'UP') {
      narrative = `Market voice for ${pairSpoken}. Buyers have dominant strength at ${buyerPower} percent. Bullish impulse wave confirmed. What the market is saying: Upward continuation. Recommended action: ${action} at candle open. Hold for ${signal.timeframe}.`;
    } else {
      narrative = `Market voice for ${pairSpoken}. Sellers have dominant strength at ${sellerPower} percent. Bearish breakdown confirmed. What the market is saying: Downward cascade. Recommended action: ${action} at candle open. Hold for ${signal.timeframe}.`;
    }

    this.speak(narrative, true);
  }

  /**
   * Final countdown voice announcement so user never misses out
   */
  public speakCountdown(seconds: number, actionName: string) {
    if (!this.enabled) return;
    if (seconds === 3) {
      this.speak('Three', true);
    } else if (seconds === 2) {
      this.speak('Two', true);
    } else if (seconds === 1) {
      this.speak('One', true);
    } else if (seconds === 0) {
      this.speak(`Strike ${actionName.split(' ')[0]} now!`, true);
    }
  }
}

export const voiceNarrator = new VoiceNarrator();
