/**
 * Safe Decimal Arithmetic for BDT Currency (1 BDT = 100 Paisa).
 * All internal storage and calculations operate on exact integer Paisa
 * to prevent floating-point inaccuracies.
 */

const EN_TO_BN_DIGITS: Record<string, string> = {
  '0': '০',
  '1': '১',
  '2': '২',
  '3': '৩',
  '4': '৪',
  '5': '৫',
  '6': '৬',
  '7': '৭',
  '8': '৮',
  '9': '৯',
};

const BN_TO_EN_DIGITS: Record<string, string> = {
  '০': '0',
  '১': '1',
  '২': '2',
  '৩': '3',
  '৪': '4',
  '৫': '5',
  '৬': '6',
  '৭': '7',
  '৮': '8',
  '৯': '9',
};

export function normalizeDigitsToEnglish(input: string): string {
  return input.replace(/[০-৯]/g, (match) => BN_TO_EN_DIGITS[match] ?? match);
}

export function toBengaliDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (match) => EN_TO_BN_DIGITS[match] ?? match);
}

/**
 * Parses a user-entered string (supports both English and Bengali digits)
 * into exact integer paisa. Returns null if invalid or <= 0.
 */
export function parseAmountToPaisa(rawInput: string): number | null {
  const normalized = normalizeDigitsToEnglish(rawInput.trim()).replace(/,/g, '');
  if (!normalized) return null;

  // Allow up to 2 decimal places
  if (!/^\d+(\.\d{1,2})?$/.test(normalized)) {
    return null;
  }

  const [wholePart, fracPart = ''] = normalized.split('.');
  const paddedFrac = (fracPart + '00').slice(0, 2);
  const whole = parseInt(wholePart, 10);
  const frac = parseInt(paddedFrac, 10);

  if (Number.isNaN(whole) || Number.isNaN(frac)) return null;
  const totalPaisa = whole * 100 + frac;
  if (!Number.isSafeInteger(totalPaisa) || totalPaisa < 0) return null;

  return totalPaisa;
}

/**
 * Converts integer paisa back to an editable decimal string (e.g., "1250" or "1250.50")
 */
export function paisaToInputString(paisa: number): string {
  const safePaisa = Math.round(paisa);
  const whole = Math.floor(Math.abs(safePaisa) / 100);
  const frac = Math.abs(safePaisa) % 100;
  const sign = safePaisa < 0 ? '-' : '';
  if (frac === 0) {
    return `${sign}${whole}`;
  }
  return `${sign}${whole}.${String(frac).padStart(2, '0')}`;
}

/**
 * Formats a number in South Asian Lakh/Crore grouping (e.g., 1,25,500)
 */
function formatSouthAsianGrouping(intStr: string): string {
  if (intStr.length <= 3) return intStr;
  const lastThree = intStr.slice(-3);
  const otherNumbers = intStr.slice(0, -3);
  const groupedOthers = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return `${groupedOthers},${lastThree}`;
}

/**
 * Formats exact paisa into BDT currency string.
 * Supports Bengali digits ('bn') or English digits ('en').
 */
export function formatBDT(
  paisa: number,
  options?: {
    useBengaliDigits?: boolean;
    showDecimals?: boolean;
    showSign?: boolean;
  }
): string {
  const useBn = options?.useBengaliDigits ?? true;
  const showSign = options?.showSign ?? false;
  const safePaisa = Math.round(paisa);
  const isNegative = safePaisa < 0;
  const absPaisa = Math.abs(safePaisa);

  const whole = Math.floor(absPaisa / 100);
  const frac = absPaisa % 100;

  const groupedWhole = formatSouthAsianGrouping(String(whole));
  const hasDecimals = options?.showDecimals ?? frac !== 0;
  const decimalStr = hasDecimals ? `.${String(frac).padStart(2, '0')}` : '';

  const signPrefix = isNegative ? '-' : showSign && safePaisa > 0 ? '+' : '';
  const formattedNumber = `${ groupedWhole }${ decimalStr }`;
  const finalDigits = useBn ? toBengaliDigits(formattedNumber) : formattedNumber;

  return `${signPrefix}৳ ${finalDigits}`;
}

/**
 * Date helper utilities
 */
export function getTodayISO(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getCurrentYearMonth(): string {
  return getTodayISO().slice(0, 7); // YYYY-MM
}

export function addCycleToDate(
  dateISO: string,
  cycle: 'MONTHLY' | 'YEARLY' | 'CUSTOM_DAYS',
  customDays?: number
): string {
  const [y, m, d] = dateISO.split('-').map(Number);
  const date = new Date(y, m - 1, d);

  if (cycle === 'MONTHLY') {
    date.setMonth(date.getMonth() + 1);
  } else if (cycle === 'YEARLY') {
    date.setFullYear(date.getFullYear() + 1);
  } else {
    const daysToAdd = customDays && customDays > 0 ? customDays : 30;
    date.setDate(date.getDate() + daysToAdd);
  }

  const ny = date.getFullYear();
  const nm = String(date.getMonth() + 1).padStart(2, '0');
  const nd = String(date.getDate()).padStart(2, '0');
  return `${ny}-${nm}-${nd}`;
}

const BN_MONTHS = [
  'জানুয়ারি',
  'ফেব্রুয়ারি',
  'মার্চ',
  'এপ্রিল',
  'মে',
  'জুন',
  'জুলাই',
  'আগস্ট',
  'সেপ্টেম্বর',
  'অক্টোবর',
  'নভেম্বর',
  'ডিসেম্বর',
];

const EN_MONTHS = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

export function formatDateBnEn(dateISO?: string, useBengali = true): string {
  if (!dateISO) return '—';
  const parts = dateISO.split('-');
  if (parts.length !== 3) return dateISO;
  const [y, m, d] = parts.map(Number);
  if (!y || !m || !d) return dateISO;

  if (useBengali) {
    const monthName = BN_MONTHS[m - 1] ?? '';
    return `${toBengaliDigits(d)} ${monthName}, ${toBengaliDigits(y)}`;
  } else {
    const monthName = EN_MONTHS[m - 1] ?? '';
    return `${d} ${monthName} ${y}`;
  }
}
