import JSZip from 'jszip';
import type { ArchivePageDescriptor, ComicArchiveFormat, ComicInfoMetadata } from '../types/comic';
import { parseComicInfoXml } from './comicInfoParser';
import { createCoverThumbnailBlob, getImageExtension, isSupportedImageFile } from './imageDecoder';

const naturalCollator = new Intl.Collator(undefined, {
  numeric: true,
  sensitivity: 'base',
});

let unrarWasmCache: ArrayBuffer | null = null;

async function getUnrarWasmBinary(): Promise<ArrayBuffer> {
  if (unrarWasmCache) return unrarWasmCache;
  const res = await fetch('/wasm/unrar.wasm');
  if (!res.ok) {
    throw new Error('Unable to load unrar.wasm decoder');
  }
  unrarWasmCache = await res.arrayBuffer();
  return unrarWasmCache;
}

export function detectArchiveFormat(fileName: string, headerBytes?: Uint8Array): ComicArchiveFormat | null {
  if (headerBytes && headerBytes.length >= 4) {
    // ZIP magic: PK\x03\x04 or PK\x05\x06
    if (headerBytes[0] === 0x50 && headerBytes[1] === 0x4b) {
      return fileName.toLowerCase().endsWith('.zip') ? 'zip' : 'cbz';
    }
    // RAR magic: Rar!\x1a\x07
    if (
      headerBytes[0] === 0x52 &&
      headerBytes[1] === 0x61 &&
      headerBytes[2] === 0x72 &&
      headerBytes[3] === 0x21
    ) {
      return fileName.toLowerCase().endsWith('.rar') ? 'rar' : 'cbr';
    }
  }
  const lower = fileName.toLowerCase();
  if (lower.endsWith('.cbz')) return 'cbz';
  if (lower.endsWith('.zip')) return 'zip';
  if (lower.endsWith('.cbr')) return 'cbr';
  if (lower.endsWith('.rar')) return 'rar';
  return null;
}

export function isComicArchiveFileName(fileName: string): boolean {
  const lower = fileName.toLowerCase();
  return (
    lower.endsWith('.cbz') ||
    lower.endsWith('.cbr') ||
    lower.endsWith('.zip') ||
    lower.endsWith('.rar')
  );
}

export interface ArchiveScanResult {
  format: ComicArchiveFormat;
  pageCount: number;
  pages: ArchivePageDescriptor[];
  comicInfo?: ComicInfoMetadata;
  coverBlob?: Blob;
  imageFormatsFound: string[];
}

export interface OpenedComicArchive {
  format: ComicArchiveFormat;
  pages: ArchivePageDescriptor[];
  comicInfo?: ComicInfoMetadata;
  getPageBytes: (pageIndex: number) => Promise<Uint8Array>;
  dispose: () => void;
}

function isComicInfoPath(entryName: string): boolean {
  const clean = entryName.replace(/\\/g, '/');
  const base = clean.split('/').pop()?.toLowerCase();
  return base === 'comicinfo.xml' && !clean.includes('__MACOSX/');
}

async function openZipArchive(buffer: ArrayBuffer, format: ComicArchiveFormat): Promise<OpenedComicArchive> {
  const zip = await JSZip.loadAsync(buffer);
  const imageEntries: { name: string; ext: string; size: number; obj: JSZip.JSZipObject }[] = [];
  let comicInfoObj: JSZip.JSZipObject | null = null;

  zip.forEach((relPath, zipObj) => {
    if (zipObj.dir) return;
    if (isComicInfoPath(relPath)) {
      if (!comicInfoObj || relPath.split('/').length < comicInfoObj.name.split('/').length) {
        comicInfoObj = zipObj;
      }
      return;
    }
    if (isSupportedImageFile(relPath)) {
      const ext = getImageExtension(relPath);
      imageEntries.push({
        name: relPath,
        ext,
        size: 0,
        obj: zipObj,
      });
    }
  });

  imageEntries.sort((a, b) => naturalCollator.compare(a.name, b.name));

  let comicInfo: ComicInfoMetadata | undefined;
  if (comicInfoObj) {
    try {
      const xmlText = await (comicInfoObj as JSZip.JSZipObject).async('text');
      comicInfo = parseComicInfoXml(xmlText);
    } catch {
      comicInfo = undefined;
    }
  }

  const pages: ArchivePageDescriptor[] = imageEntries.map((item, index) => ({
    index,
    name: item.name,
    ext: item.ext,
    size: item.size,
  }));

  const byteCache = new Map<number, Uint8Array>();

  return {
    format,
    pages,
    comicInfo,
    getPageBytes: async (pageIndex: number) => {
      const cached = byteCache.get(pageIndex);
      if (cached) return cached;
      const entry = imageEntries[pageIndex];
      if (!entry) throw new Error(`Page ${pageIndex} out of range`);
      const data = await entry.obj.async('uint8array');
      // Keep bounded cache of raw compressed bytes
      if (byteCache.size > 16) {
        const firstKey = byteCache.keys().next().value;
        if (firstKey !== undefined) byteCache.delete(firstKey);
      }
      byteCache.set(pageIndex, data);
      return data;
    },
    dispose: () => {
      byteCache.clear();
    },
  };
}

async function openRarArchive(buffer: ArrayBuffer, format: ComicArchiveFormat): Promise<OpenedComicArchive> {
  const { createExtractorFromData } = await import('node-unrar-js/esm/index.esm.js');
  const wasmBinary = await getUnrarWasmBinary();
  const extractor = await createExtractorFromData({
    wasmBinary,
    data: buffer,
  });

  const list = extractor.getFileList();
  const headers = [...list.fileHeaders];
  const imageHeaders: { name: string; ext: string; size: number }[] = [];
  let comicInfoName: string | null = null;

  for (const h of headers) {
    if (h.flags.directory) continue;
    if (isComicInfoPath(h.name)) {
      if (!comicInfoName || h.name.split('/').length < comicInfoName.split('/').length) {
        comicInfoName = h.name;
      }
      continue;
    }
    if (isSupportedImageFile(h.name)) {
      imageHeaders.push({
        name: h.name,
        ext: getImageExtension(h.name),
        size: h.unpSize,
      });
    }
  }

  imageHeaders.sort((a, b) => naturalCollator.compare(a.name, b.name));

  let comicInfo: ComicInfoMetadata | undefined;
  if (comicInfoName) {
    try {
      const extracted = extractor.extract({ files: [comicInfoName] });
      const files = [...extracted.files];
      if (files[0]?.extraction) {
        const xmlText = new TextDecoder('utf-8').decode(files[0].extraction);
        comicInfo = parseComicInfoXml(xmlText);
      }
    } catch {
      comicInfo = undefined;
    }
  }

  const pages: ArchivePageDescriptor[] = imageHeaders.map((item, index) => ({
    index,
    name: item.name,
    ext: item.ext,
    size: item.size,
  }));

  const extractedMap = new Map<string, Uint8Array>();

  const extractSingleOrBatch = async (targetIndex: number): Promise<Uint8Array> => {
    const target = imageHeaders[targetIndex];
    if (!target) throw new Error(`Page ${targetIndex} out of range`);
    const existing = extractedMap.get(target.name);
    if (existing) return existing;

    // Extract small prefetch window around target page to minimize RAR solid-block passes
    const windowNames: string[] = [];
    for (let i = Math.max(0, targetIndex - 1); i <= Math.min(imageHeaders.length - 1, targetIndex + 3); i++) {
      const n = imageHeaders[i].name;
      if (!extractedMap.has(n)) windowNames.push(n);
    }

    const extracted = extractor.extract({ files: windowNames.length > 0 ? windowNames : [target.name] });
    for (const f of extracted.files) {
      if (f.extraction) {
        extractedMap.set(f.fileHeader.name, f.extraction);
      }
    }

    // Evict older entries if map grows large on memory-constrained tablets
    if (extractedMap.size > 20) {
      const keep = new Set(
        imageHeaders
          .slice(Math.max(0, targetIndex - 3), Math.min(imageHeaders.length, targetIndex + 5))
          .map((h) => h.name),
      );
      for (const key of extractedMap.keys()) {
        if (!keep.has(key)) extractedMap.delete(key);
      }
    }

    const res = extractedMap.get(target.name);
    if (!res) throw new Error(`Failed to extract page ${target.name} from RAR archive`);
    return res;
  };

  return {
    format,
    pages,
    comicInfo,
    getPageBytes: extractSingleOrBatch,
    dispose: () => {
      extractedMap.clear();
    },
  };
}

export async function openComicArchive(file: Blob, fileName: string): Promise<OpenedComicArchive> {
  const buffer = await file.arrayBuffer();
  const header = new Uint8Array(buffer.slice(0, 8));
  const format = detectArchiveFormat(fileName, header);
  if (!format) {
    throw new Error(`Unsupported comic archive format: ${fileName}`);
  }
  if (format === 'cbz' || format === 'zip') {
    return await openZipArchive(buffer, format);
  }
  return await openRarArchive(buffer, format);
}

/**
 * Quickly scans an archive file to extract ComicInfo.xml, page count, supported image formats,
 * and a compressed cover thumbnail for fast offline library caching.
 */
export async function scanComicArchive(file: Blob, fileName: string): Promise<ArchiveScanResult> {
  const archive = await openComicArchive(file, fileName);
  try {
    const formatsSet = new Set<string>();
    for (const p of archive.pages) {
      formatsSet.add(p.ext.toUpperCase());
    }

    // Determine cover page index from ComicInfo FrontCover if present, else page 0
    let coverIndex = 0;
    const frontCover = archive.comicInfo?.pages.find(
      (p) => p.type?.toLowerCase() === 'frontcover',
    );
    if (frontCover && frontCover.imageIndex >= 0 && frontCover.imageIndex < archive.pages.length) {
      coverIndex = frontCover.imageIndex;
    }

    let coverBlob: Blob | undefined;
    if (archive.pages.length > 0) {
      const coverPage = archive.pages[coverIndex];
      const coverBytes = await archive.getPageBytes(coverIndex);
      coverBlob = await createCoverThumbnailBlob(coverBytes, coverPage.ext);
    }

    return {
      format: archive.format,
      pageCount: archive.pages.length,
      pages: archive.pages,
      comicInfo: archive.comicInfo,
      coverBlob,
      imageFormatsFound: Array.from(formatsSet),
    };
  } finally {
    archive.dispose();
  }
}
