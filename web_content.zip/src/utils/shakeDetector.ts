/**
 * Shake-to-Toggle Detector for smartphones
 * Uses DeviceMotionEvent API with calibration, sensitivity presets, and simulated test support.
 */

export type ShakeSensitivity = 'low' | 'medium' | 'high';

export interface ShakeStatus {
  enabled: boolean;
  supported: boolean;
  permissionState: 'unknown' | 'granted' | 'denied';
  sensitivity: ShakeSensitivity;
  threshold: number; // m/s^2
  currentIntensity: number; // 0 - 100% for visual feedback
  lastShakeTimestamp: number | null;
}

const THRESHOLDS: Record<ShakeSensitivity, number> = {
  high: 13,
  medium: 18,
  low: 26,
};

class ShakeDetector {
  private enabled: boolean = true;
  private sensitivity: ShakeSensitivity = 'medium';
  private supported: boolean = false;
  private permissionState: 'unknown' | 'granted' | 'denied' = 'unknown';
  private lastX: number | null = null;
  private lastY: number | null = null;
  private lastZ: number | null = null;
  private lastTime: number = 0;
  private lastShakeTime: number = 0;
  private currentIntensity: number = 0;

  private shakeListeners: Set<() => void> = new Set();
  private statusListeners: Set<(status: ShakeStatus) => void> = new Set();
  private boundHandler: ((e: DeviceMotionEvent) => void) | null = null;

  constructor() {
    const savedEnabled = localStorage.getItem('neonbeam_shake_enabled');
    if (savedEnabled !== null) {
      this.enabled = savedEnabled === 'true';
    }
    const savedSens = localStorage.getItem('neonbeam_shake_sensitivity') as ShakeSensitivity | null;
    if (savedSens && THRESHOLDS[savedSens]) {
      this.sensitivity = savedSens;
    }

    if (typeof window !== 'undefined') {
      this.supported = 'DeviceMotionEvent' in window;
    }
  }

  public subscribeShake(callback: () => void): () => void {
    this.shakeListeners.add(callback);
    return () => {
      this.shakeListeners.delete(callback);
    };
  }

  public subscribeStatus(callback: (status: ShakeStatus) => void): () => void {
    this.statusListeners.add(callback);
    callback(this.getStatus());
    return () => {
      this.statusListeners.delete(callback);
    };
  }

  public getStatus(): ShakeStatus {
    return {
      enabled: this.enabled,
      supported: this.supported,
      permissionState: this.permissionState,
      sensitivity: this.sensitivity,
      threshold: THRESHOLDS[this.sensitivity],
      currentIntensity: this.currentIntensity,
      lastShakeTimestamp: this.lastShakeTime || null,
    };
  }

  private notifyStatus() {
    const status = this.getStatus();
    this.statusListeners.forEach((l) => l(status));
  }

  public setEnabled(enabled: boolean) {
    this.enabled = enabled;
    localStorage.setItem('neonbeam_shake_enabled', String(enabled));
    if (enabled) {
      this.startListening();
    } else {
      this.stopListening();
    }
    this.notifyStatus();
  }

  public setSensitivity(sens: ShakeSensitivity) {
    this.sensitivity = sens;
    localStorage.setItem('neonbeam_shake_sensitivity', sens);
    this.notifyStatus();
  }

  public async requestPermission(): Promise<boolean> {
    if (typeof window === 'undefined') return false;

    const MotionAny = window.DeviceMotionEvent as unknown as {
      requestPermission?: () => Promise<'granted' | 'denied'>;
    };

    if (typeof MotionAny?.requestPermission === 'function') {
      try {
        const response = await MotionAny.requestPermission();
        this.permissionState = response;
        this.notifyStatus();
        if (response === 'granted') {
          this.startListening();
          return true;
        }
        return false;
      } catch (err) {
        console.warn('Shake permission request error:', err);
        this.permissionState = 'denied';
        this.notifyStatus();
        return false;
      }
    } else {
      this.permissionState = 'granted';
      this.notifyStatus();
      this.startListening();
      return true;
    }
  }

  public startListening() {
    if (!this.enabled || typeof window === 'undefined' || !this.supported) return;
    if (this.boundHandler) return;

    this.boundHandler = this.handleMotion.bind(this);
    window.addEventListener('devicemotion', this.boundHandler, false);
  }

  public stopListening() {
    if (this.boundHandler && typeof window !== 'undefined') {
      window.removeEventListener('devicemotion', this.boundHandler, false);
      this.boundHandler = null;
    }
  }

  private handleMotion(event: DeviceMotionEvent) {
    const acc = event.accelerationIncludingGravity || event.acceleration;
    if (!acc || acc.x === null || acc.y === null || acc.z === null) return;

    const currentTime = Date.now();
    if (currentTime - this.lastTime < 60) return; // limit to ~16 Hz sample

    if (this.lastX !== null && this.lastY !== null && this.lastZ !== null) {
      const deltaX = acc.x - this.lastX;
      const deltaY = acc.y - this.lastY;
      const deltaZ = acc.z - this.lastZ;

      // Calculate euclidean distance of acceleration change
      const deltaAcc = Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
      const threshold = THRESHOLDS[this.sensitivity];

      // Normalized intensity 0-100%
      const intensity = Math.min(100, Math.round((deltaAcc / (threshold * 1.5)) * 100));
      this.currentIntensity = intensity;

      if (deltaAcc > threshold) {
        // Enforce 900ms debounce between shakes
        if (currentTime - this.lastShakeTime > 900) {
          this.lastShakeTime = currentTime;
          this.triggerShake();
        }
      }
    }

    this.lastX = acc.x;
    this.lastY = acc.y;
    this.lastZ = acc.z;
    this.lastTime = currentTime;
    this.notifyStatus();
  }

  public triggerShake() {
    this.lastShakeTime = Date.now();
    this.shakeListeners.forEach((callback) => callback());
    this.notifyStatus();
  }
}

export const shakeService = new ShakeDetector();
