/**
 * Battery Status Controller for mobile battery status display
 */

export interface BatteryState {
  level: number; // 0 to 100
  charging: boolean;
  supported: boolean;
}

interface BatteryManagerPolyfill extends EventTarget {
  level: number;
  charging: boolean;
  addEventListener(type: string, listener: EventListenerOrEventListenerObject): void;
}

interface NavigatorWithBattery extends Navigator {
  getBattery?: () => Promise<BatteryManagerPolyfill>;
}

class BatteryController {
  private state: BatteryState = {
    level: 100,
    charging: false,
    supported: false,
  };
  private listeners: Set<(state: BatteryState) => void> = new Set();

  constructor() {
    this.init();
  }

  public subscribe(listener: (state: BatteryState) => void): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private async init() {
    if (typeof navigator === 'undefined') return;
    const nav = navigator as NavigatorWithBattery;
    if (typeof nav.getBattery === 'function') {
      try {
        const battery = await nav.getBattery();
        this.updateState({
          level: Math.round(battery.level * 100),
          charging: battery.charging,
          supported: true,
        });

        battery.addEventListener('levelchange', () => {
          this.updateState({ level: Math.round(battery.level * 100) });
        });

        battery.addEventListener('chargingchange', () => {
          this.updateState({ charging: battery.charging });
        });
      } catch {
        // Battery API blocked
      }
    }
  }

  private updateState(patch: Partial<BatteryState>) {
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((l) => l(this.state));
  }

  public getState(): BatteryState {
    return this.state;
  }
}

export const batteryService = new BatteryController();
