import { BallColor, BallInfo, MatchSettings, Player } from '../types';

export const SNOOKER_BALLS: Record<BallColor, BallInfo> = {
  red: {
    id: 'red',
    name: 'Red',
    faName: 'قرمز',
    points: 1, // Will be overridden dynamically if custom mode (e.g. 10)
    bgGradient: 'radial-gradient(circle at 35% 30%, #ff4b4b, #d70000 60%, #870000 95%)',
    shadowColor: 'rgba(239, 68, 68, 0.45)',
    textColor: '#ffffff',
  },
  yellow: {
    id: 'yellow',
    name: 'Yellow',
    faName: 'زرد',
    points: 2,
    bgGradient: 'radial-gradient(circle at 35% 30%, #fff066, #eab308 60%, #926700 95%)',
    shadowColor: 'rgba(234, 179, 8, 0.45)',
    textColor: '#1a1300',
  },
  green: {
    id: 'green',
    name: 'Green',
    faName: 'سبز',
    points: 3,
    bgGradient: 'radial-gradient(circle at 35% 30%, #52f08a, #16a34a 60%, #064e1f 95%)',
    shadowColor: 'rgba(22, 163, 74, 0.45)',
    textColor: '#ffffff',
  },
  brown: {
    id: 'brown',
    name: 'Brown',
    faName: 'قهوه‌ای',
    points: 4,
    bgGradient: 'radial-gradient(circle at 35% 30%, #d49757, #96541e 60%, #4a2408 95%)',
    shadowColor: 'rgba(150, 84, 30, 0.45)',
    textColor: '#ffffff',
  },
  blue: {
    id: 'blue',
    name: 'Blue',
    faName: 'آبی',
    points: 5,
    bgGradient: 'radial-gradient(circle at 35% 30%, #60a5fa, #2563eb 60%, #172554 95%)',
    shadowColor: 'rgba(37, 99, 235, 0.45)',
    textColor: '#ffffff',
  },
  pink: {
    id: 'pink',
    name: 'Pink',
    faName: 'صورتی',
    points: 6,
    bgGradient: 'radial-gradient(circle at 35% 30%, #f472b6, #db2777 60%, #700d3d 95%)',
    shadowColor: 'rgba(219, 39, 119, 0.45)',
    textColor: '#ffffff',
  },
  black: {
    id: 'black',
    name: 'Black',
    faName: 'مشکی',
    points: 7,
    bgGradient: 'radial-gradient(circle at 35% 30%, #64748b, #1e293b 60%, #020617 95%)',
    shadowColor: 'rgba(15, 23, 42, 0.65)',
    textColor: '#ffffff',
    borderClass: 'ring-1 ring-slate-600/60',
  },
};

export const COLOR_ORDER: BallColor[] = ['yellow', 'green', 'brown', 'blue', 'pink', 'black'];

/**
 * Format numbers into Persian digits
 */
export function toPersianDigits(n: number | string): string {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  if (typeof n === 'number' && n < 0) {
    const absVal = Math.abs(n).toString().replace(/\d/g, (x) => persianDigits[parseInt(x, 10)]);
    return `-${absVal}`;
  }
  return n.toString().replace(/\d/g, (x) => persianDigits[parseInt(x, 10)]);
}

/**
 * Calculate remaining points on table
 */
export function calculateRemainingPoints(remainingReds: number, redPoints: number = 1): number {
  if (remainingReds > 0) {
    // Each red can be paired with black (7 points) + the 6 colours (27 points)
    const colorMax = 7;
    return remainingReds * (redPoints + colorMax) + 27;
  }
  return 27; // If only colors left, up to 27 points
}

/**
 * Calculate snookers required (how many 4-point fouls trailing player needs to catch up)
 */
export function calculateSnookersNeeded(
  leaderScore: number,
  trailerScore: number,
  remainingPoints: number
): number {
  const diff = leaderScore - trailerScore;
  if (diff <= remainingPoints) return 0;
  const deficit = diff - remainingPoints;
  // A standard foul yields at least 4 points
  return Math.ceil(deficit / 4);
}

export const INITIAL_SETTINGS: MatchSettings = {
  ruleMode: 'custom', // Matches user original (+10 for red, miss button), but allows switching to official snooker
  redValue: 10,
  totalReds: 15,
  remainingReds: 15,
  bestOfFrames: 3,
  currentFrame: 1,
  soundEnabled: true,
};

export const INITIAL_PLAYERS: Player[] = [
  {
    id: 1,
    name: 'بازیکن ۱',
    score: 0,
    framesWon: 0,
    hits: 0,
    misses: 0,
    highestBreak: 0,
    currentBreak: 0,
    matchHighestBreak: 0,
  },
  {
    id: 2,
    name: 'بازیکن ۲',
    score: 0,
    framesWon: 0,
    hits: 0,
    misses: 0,
    highestBreak: 0,
    currentBreak: 0,
    matchHighestBreak: 0,
  },
];
