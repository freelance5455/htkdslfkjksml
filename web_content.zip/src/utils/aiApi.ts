import type {
  AiCoachApiResponse,
  CefrBand,
  CoachScenarioId,
  SpeechEvalResult,
} from '../types';

export function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const commaIdx = result.indexOf(',');
      resolve(commaIdx >= 0 ? result.slice(commaIdx + 1) : result);
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

async function gtxTranslateChunk(
  items: string[],
  targetLang = 'ar',
  signal?: AbortSignal
): Promise<Record<string, string>> {
  const out: Record<string, string> = {};
  if (!items.length) return out;
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 5000);
  const onOuterAbort = () => controller.abort();
  signal?.addEventListener('abort', onOuterAbort, { once: true });
  try {
    const res = await fetch('/api/translate-ui-batch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ texts: items, sourceLang: 'en', targetLang }),
      signal: controller.signal,
    });
    if (res.ok) {
      const json = (await res.json()) as { translations?: Record<string, string> };
      if (json?.translations && typeof json.translations === 'object') {
        for (const [k, v] of Object.entries(json.translations)) {
          if (typeof v === 'string' && v.trim()) out[k] = v.trim();
        }
      }
    }
  } catch {
    // Ignore transient network failure
  } finally {
    window.clearTimeout(timer);
    signal?.removeEventListener('abort', onOuterAbort);
  }
  return out;
}

export async function translateSentencesBatch(
  sentences: string[],
  signal?: AbortSignal,
  targetLang = 'ar'
): Promise<Record<string, string>> {
  const cleanList = Array.from(new Set(sentences.map((s) => s.trim()).filter(Boolean)));
  if (!cleanList.length) return {};

  const result: Record<string, string> = {};
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 6000);
  const onOuterAbort = () => controller.abort();
  signal?.addEventListener('abort', onOuterAbort, { once: true });

  try {
    const res = await fetch('/api/translate-sentences', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sentences: cleanList, targetLang }),
      signal: controller.signal,
    });
    if (res.ok) {
      const data = (await res.json().catch(() => ({}))) as {
        translations?: Record<string, string>;
      };
      if (data.translations && typeof data.translations === 'object') {
        for (const [k, v] of Object.entries(data.translations)) {
          if (typeof v === 'string' && v.trim()) {
            result[k] = v.trim();
          }
        }
      }
    }
  } catch {
    // 6s timeout or network hiccup -> fill immediately via fast GTX chunks below
  } finally {
    window.clearTimeout(timer);
    signal?.removeEventListener('abort', onOuterAbort);
  }

  if (signal?.aborted) return result;

  const missing = cleanList.filter((s) => !result[s]);
  if (missing.length > 0) {
    const gtxFilled = await gtxTranslateChunk(missing, targetLang, signal);
    Object.assign(result, gtxFilled);
  }
  return result;
}

export async function evaluateSpeechWithAi(params: {
  targetSentence: string;
  spokenText?: string;
  audioBase64?: string;
  audioMimeType?: string;
}): Promise<SpeechEvalResult> {
  const res = await fetch('/api/evaluate-speech', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json().catch(() => ({}))) as Partial<SpeechEvalResult> & {
    error?: string;
  };
  if (!res.ok) {
    throw new Error(data.error || 'تعذر تقييم التسجيل الصوتي.');
  }
  return {
    heardText: data.heardText || params.spokenText || '',
    score: typeof data.score === 'number' ? data.score : 0,
    isMatch: Boolean(data.isMatch),
    feedbackAr: data.feedbackAr || 'تم تقييم النطق.',
    tipAr: data.tipAr || '',
    source: 'ai',
  };
}

export async function sendAiCoachTurn(params: {
  scenario: CoachScenarioId;
  level: CefrBand;
  provider?: 'auto' | 'open' | 'gemini';
  history: Array<{ role: 'user' | 'model'; text: string }>;
  userText?: string;
  audioBase64?: string;
  audioMimeType?: string;
}): Promise<AiCoachApiResponse> {
  const res = await fetch('/api/ai-coach', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json().catch(() => ({}))) as Partial<AiCoachApiResponse> & {
    error?: string;
  };
  if (!res.ok || !data.replyEn) {
    throw new Error(data.error || 'تعذر التواصل مع المدرب الذكي.');
  }
  return {
    userTranscript: data.userTranscript || params.userText || '',
    replyEn: data.replyEn,
    replyAr: data.replyAr || '',
    hasErrors: Boolean(data.hasErrors),
    correctedEn: data.correctedEn || data.userTranscript || params.userText || '',
    explanationAr: data.explanationAr || '',
    betterPhrasing: data.betterPhrasing || '',
    score: typeof data.score === 'number' ? data.score : 85,
    suggestions: Array.isArray(data.suggestions) ? data.suggestions : [],
    providerLabel: data.providerLabel,
  };
}

export async function checkWordSentenceWithAi(params: {
  targetWord: string;
  targetMeaningAr?: string;
  sentence?: string;
  audioBase64?: string;
  audioMimeType?: string;
}): Promise<import('../types').WordSentenceCheckResult> {
  const res = await fetch('/api/check-word-sentence', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json().catch(() => ({}))) as Partial<
    import('../types').WordSentenceCheckResult
  > & { error?: string };
  if (!res.ok) {
    throw new Error(data.error || 'تعذر تصحيح الجملة حالياً.');
  }
  return {
    userSentence: data.userSentence || params.sentence || '',
    containsTargetWord: Boolean(data.containsTargetWord),
    isCorrect: Boolean(data.isCorrect),
    score: typeof data.score === 'number' ? data.score : 0,
    correctedEn: data.correctedEn || data.userSentence || params.sentence || '',
    wrongParts: Array.isArray(data.wrongParts) ? data.wrongParts : [],
    explanationAr: data.explanationAr || '',
    betterExampleEn: data.betterExampleEn || '',
  };
}

export async function evaluateWritingTaskWithAi(params: {
  taskType: 'picture' | 'topic' | 'article_summary';
  level: CefrBand;
  contextTitle: string;
  contextText: string;
  userText?: string;
  audioBase64?: string;
  audioMimeType?: string;
}): Promise<import('../types').WritingEvaluationResult> {
  const res = await fetch('/api/evaluate-writing-task', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json().catch(() => ({}))) as Partial<
    import('../types').WritingEvaluationResult
  > & { error?: string };
  if (!res.ok) {
    throw new Error(data.error || 'تعذر تصحيح الإجابة حالياً.');
  }
  return {
    userText: data.userText || params.userText || '',
    hasErrors: Boolean(data.hasErrors),
    score: typeof data.score === 'number' ? data.score : 80,
    overallFeedbackAr: data.overallFeedbackAr || '',
    contentFeedbackAr: data.contentFeedbackAr || '',
    correctedText: data.correctedText || data.userText || params.userText || '',
    wrongParts: Array.isArray(data.wrongParts) ? data.wrongParts : [],
    sentenceFeedback: Array.isArray(data.sentenceFeedback) ? data.sentenceFeedback : [],
    improvedVersionEn: data.improvedVersionEn || '',
    vocabularyTips: Array.isArray(data.vocabularyTips) ? data.vocabularyTips : [],
    providerLabel: data.providerLabel,
  };
}

export async function generateWritingTopicWithAi(params: {
  level: CefrBand;
  previousTitles?: string[];
}): Promise<import('../types').WritingTopicPrompt> {
  const res = await fetch('/api/generate-topic-prompt', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json().catch(() => ({}))) as Partial<
    import('../types').WritingTopicPrompt
  > & { error?: string };
  if (!res.ok || !data.titleEn) {
    throw new Error(data.error || 'تعذر توليد موضوع جديد.');
  }
  return {
    id: data.id || `topic-${Date.now()}`,
    titleEn: data.titleEn,
    titleAr: data.titleAr || data.titleEn,
    promptEn: data.promptEn || '',
    promptAr: data.promptAr || '',
    keywords: Array.isArray(data.keywords) ? data.keywords : [],
    level: data.level || params.level,
  };
}

export async function searchArticlesWithAi(params: {
  query: string;
  level: CefrBand;
  contentType: 'all' | 'article' | 'story' | 'essay';
}): Promise<import('../types').ArticleItem[]> {
  const res = await fetch('/api/articles/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json().catch(() => ({}))) as {
    articles?: import('../types').ArticleItem[];
    error?: string;
  };
  if (!res.ok || !Array.isArray(data.articles)) {
    throw new Error(data.error || 'تعذر جلب المقالات حالياً.');
  }
  return data.articles;
}

export async function translateSingleWordWithAi(params: {
  word: string;
  contextSentence?: string;
  targetLang?: string;
}): Promise<{ word: string; ar: string; posAr?: string }> {
  const targetLang = params.targetLang || 'ar';
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 6000);
  try {
    const res = await fetch('/api/translate-word', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...params, targetLang }),
      signal: controller.signal,
    });
    const data = (await res.json().catch(() => ({}))) as {
      word?: string;
      ar?: string;
      posAr?: string;
      error?: string;
    };
    if (res.ok && data.ar) {
      return {
        word: data.word || params.word,
        ar: data.ar,
        posAr: data.posAr,
      };
    }
  } catch {
    // Fall through to instant Google GTX
  } finally {
    window.clearTimeout(timer);
  }

  const gtx = await gtxTranslateChunk([params.word], targetLang);
  const translated = gtx[params.word];
  if (translated) {
    return { word: params.word, ar: translated };
  }
  throw new Error('تعذر ترجمة الكلمة.');
}

export async function evaluateSentenceSwapWithAi(params: {
  originalSentence: string;
  targetSlotType: import('../types').PatternSwapSlotType;
  targetSlotText: string;
  userSentence?: string;
  audioBase64?: string;
  audioMimeType?: string;
}): Promise<import('../types').PatternSwapEvalResult> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 7000);
  try {
    const res = await fetch('/api/evaluate-sentence-swap', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
      signal: controller.signal,
    });
    const data = (await res.json().catch(() => ({}))) as Partial<
      import('../types').PatternSwapEvalResult
    > & { error?: string };
    if (!res.ok) {
      throw new Error(data.error || 'AI evaluation unavailable');
    }
    return {
      heardText: (data.heardText || params.userSentence || '').trim(),
      swappedCorrectly: Boolean(data.swappedCorrectly),
      isGrammaticallyCorrect: Boolean(data.isGrammaticallyCorrect),
      score: typeof data.score === 'number' ? data.score : 0,
      correctedEn: (data.correctedEn || data.heardText || params.userSentence || '').trim(),
      newSentenceAr: (data.newSentenceAr || '').trim(),
      feedbackAr: (data.feedbackAr || '').trim(),
      wrongParts: Array.isArray(data.wrongParts) ? data.wrongParts : [],
      source: 'ai',
    };
  } finally {
    window.clearTimeout(timer);
  }
}


