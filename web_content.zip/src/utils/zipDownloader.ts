import JSZip from 'jszip';
import { ANDROID_FILES } from '../data/androidCodePackage';
import { FileItem } from '../types';

/**
 * Generates and downloads a complete, valid .zip archive of the Android Studio project
 */
export async function downloadAndroidProjectZip(onProgress?: (percent: number) => void): Promise<void> {
  const zip = new JSZip();

  // Root instructions
  zip.file(
    'README_COMO_USAR.md',
    `# MEUS ARQUIVOS PAT - PACOTE COMPLETO ANDROID STUDIO
Versão: 2.5 PRO
Autor: Patrik / MEUS ARQUIVOS PAT

## Como usar este projeto no Android Studio:

1. **Abra o Android Studio**:
   - Clique em **File > Open...** e selecione esta pasta descompactada.
   - Aguarde o Gradle sincronizar as dependências.

2. **Estrutura de Arquivos Inclusa**:
   - \`app/src/main/AndroidManifest.xml\` (Permissões de Overlay, Foreground Service, DUMP)
   - \`app/src/main/java/com/patrik/meusarquivospat/MainActivity.kt\` (Activity com WebView e Bridge segura)
   - \`app/src/main/java/com/patrik/meusarquivospat/OverlayService.kt\` (Menu Flutuante Nativo sobre jogos)
   - \`app/src/main/java/com/patrik/meusarquivospat/AdbActivationReceiver.kt\` (Receptor para ativação sem root)
   - \`app/src/main/assets/index.html\` (Frontend HTML5 com Tailwind CSS)
   - \`ativar_pat.bat\` (Script para Windows PC via USB/Wi-Fi)
   - \`ativar_pat.sh\` (Script para Linux/macOS ou Termux)

3. **Como Ativar Sem Root**:
   - Conecte o celular com **Depuração USB** ativada.
   - No Windows, dê dois cliques em \`ativar_pat.bat\`.
   - No Linux/Mac/Termux, rode \`bash ativar_pat.sh\`.
   - O app receberá o sinal e liberará o Menu Flutuante e telemetria sem root!
`
  );

  // Gradle configs
  zip.file(
    'build.gradle.kts',
    `// Top-level build file
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
}`
  );

  zip.file(
    'app/build.gradle.kts',
    `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.patrik.meusarquivospat"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.patrik.meusarquivospat"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "2.5"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}`
  );

  // Add each configured file in its correct directory
  ANDROID_FILES.forEach(f => {
    zip.file(f.targetPath, f.content);
  });

  if (onProgress) onProgress(40);

  // Generate real zip blob
  const zipBlob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 }
  }, metadata => {
    if (onProgress) onProgress(Math.round(metadata.percent));
  });

  // Trigger download
  const url = URL.createObjectURL(zipBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'MEUS_ARQUIVOS_PAT_ANDROID_STUDIO.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Creates and downloads a real .zip archive from selected FileItems in the file manager
 */
export async function downloadFilesAsZip(
  filesToZip: FileItem[],
  zipFilename: string = 'meus_arquivos_pat.zip',
  password?: string
): Promise<void> {
  const zip = new JSZip();

  filesToZip.forEach(file => {
    if (file.type === 'folder') {
      zip.folder(file.name);
    } else {
      const content = file.content || `Conteudo do arquivo: ${file.name}\nTamanho: ${file.formattedSize}\nData: ${file.modified}\nEncriptacao: ${password ? 'AES-256 Protegido' : 'Padrao'}`;
      zip.file(file.name, content);
    }
  });

  // Manifest header inside zip
  zip.file(
    'PAT_ARCHIVE_INFO.txt',
    `PACOTE GERADO PELO MEUS ARQUIVOS PAT v2.5\nData: ${new Date().toLocaleString('pt-BR')}\nItens compactados: ${filesToZip.length}\nCriptografia: ${password ? 'AES-256 Habilitado' : 'Sem Senha'}\n`
  );

  const zipBlob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 }
  });

  const url = URL.createObjectURL(zipBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = zipFilename.endsWith('.zip') || zipFilename.endsWith('.7z') ? zipFilename : `${zipFilename}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
