import type { MediaAttachment } from '../types';

const MIME_BY_EXT: Record<string, string> = {
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  webp: 'image/webp',
  gif: 'image/gif',
  mp4: 'video/mp4',
  webm: 'video/webm',
  mov: 'video/quicktime',
  m4v: 'video/mp4',
};

const CODE_EXTENSIONS = new Set([
  'html',
  'htm',
  'css',
  'scss',
  'js',
  'jsx',
  'mjs',
  'cjs',
  'ts',
  'tsx',
  'py',
  'java',
  'kt',
  'kts',
  'c',
  'h',
  'cpp',
  'hpp',
  'cc',
  'cs',
  'php',
  'sql',
  'dart',
  'xml',
  'json',
  'lua',
  'swift',
  'md',
  'txt',
  'yaml',
  'yml',
  'gradle',
]);

function resolveMimeType(file: File): string {
  if (file.type && file.type !== 'application/octet-stream') {
    return file.type;
  }
  const ext = file.name.split('.').pop()?.toLowerCase() || '';
  if (MIME_BY_EXT[ext]) return MIME_BY_EXT[ext];
  if (CODE_EXTENSIONS.has(ext)) return 'text/plain';
  return 'application/octet-stream';
}

function readBlobAsDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to encode media blob as Data URL.'));
      }
    };
    reader.onerror = () => reject(new Error('FileReader failed to read the selected media.'));
    reader.readAsDataURL(blob);
  });
}

function readBlobAsText(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to read source file as text.'));
      }
    };
    reader.onerror = () => reject(new Error('FileReader failed to read the selected file.'));
    reader.readAsText(blob);
  });
}

function encodeImageBlob(
  blob: Blob,
  mimeType: string,
  maxDim = 1600
): Promise<{
  dataUrl: string;
  base64: string;
  mimeType: string;
}> {
  return new Promise((resolve, reject) => {
    const objectUrl = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      try {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const width = Math.max(1, Math.round(img.width * scale));
        const height = Math.max(1, Math.round(img.height * scale));

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          throw new Error('Canvas 2D context unavailable');
        }
        ctx.drawImage(img, 0, 0, width, height);

        const targetMime = mimeType === 'image/png' ? 'image/png' : 'image/jpeg';
        canvas.toBlob(
          async (outBlob) => {
            URL.revokeObjectURL(objectUrl);
            if (!outBlob) {
              reject(new Error('Failed to serialize processed image blob.'));
              return;
            }
            const dataUrl = await readBlobAsDataUrl(outBlob);
            const base64 = dataUrl.split(',')[1] || '';
            resolve({ dataUrl, base64, mimeType: targetMime });
          },
          targetMime,
          0.9
        );
      } catch (err) {
        URL.revokeObjectURL(objectUrl);
        reject(err);
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Could not decode image blob.'));
    };
    img.src = objectUrl;
  });
}

/**
 * Supports images, videos, and source code / text files cleanly.
 */
export async function prepareMediaAttachment(file: File): Promise<MediaAttachment> {
  const ext = file.name.split('.').pop()?.toLowerCase() || '';
  const mimeType = resolveMimeType(file);
  const isVideo = mimeType.startsWith('video/');
  const isImage = mimeType.startsWith('image/');
  const isCode =
    CODE_EXTENSIONS.has(ext) ||
    mimeType.startsWith('text/') ||
    mimeType === 'application/json' ||
    mimeType === 'application/xml';

  if (!isVideo && !isImage && !isCode) {
    throw new Error('Please choose an image, video, or source code file.');
  }

  const sliceBlob = file.slice(0, file.size, mimeType);

  if (isCode) {
    if (file.size > 1024 * 1024) {
      throw new Error('Source file exceeds 1 MB limit.');
    }
    const textContent = await readBlobAsText(sliceBlob);
    return {
      name: file.name,
      mimeType: 'text/plain',
      data: textContent,
      previewUrl: '',
      kind: 'code',
    };
  }

  if (isVideo) {
    if (file.size > 20 * 1024 * 1024) {
      throw new Error('Video is over 20 MB. Please select a shorter clip.');
    }
    const dataUrl = await readBlobAsDataUrl(sliceBlob);
    const base64 = dataUrl.split(',')[1] || '';
    return {
      name: file.name,
      mimeType,
      data: base64,
      previewUrl: dataUrl,
      kind: 'video',
    };
  }

  try {
    const processed = await encodeImageBlob(sliceBlob, mimeType);
    return {
      name: file.name,
      mimeType: processed.mimeType,
      data: processed.base64,
      previewUrl: processed.dataUrl,
      kind: 'image',
    };
  } catch {
    const fallbackUrl = await readBlobAsDataUrl(sliceBlob);
    return {
      name: file.name,
      mimeType,
      data: fallbackUrl.split(',')[1] || '',
      previewUrl: fallbackUrl,
      kind: 'image',
    };
  }
}

export function inferLanguageFromFilename(path: string): string {
  const ext = path.split('.').pop()?.toLowerCase() || '';
  const map: Record<string, string> = {
    html: 'html',
    htm: 'html',
    css: 'css',
    scss: 'css',
    js: 'javascript',
    jsx: 'javascript',
    mjs: 'javascript',
    ts: 'typescript',
    tsx: 'typescript',
    py: 'python',
    java: 'java',
    kt: 'kotlin',
    kts: 'kotlin',
    c: 'c',
    h: 'c',
    cpp: 'cpp',
    hpp: 'cpp',
    cc: 'cpp',
    cs: 'csharp',
    php: 'php',
    sql: 'sql',
    dart: 'dart',
    xml: 'xml',
    json: 'json',
    lua: 'lua',
    swift: 'swift',
    md: 'markdown',
  };
  return map[ext] || 'text';
}
