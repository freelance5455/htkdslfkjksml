/**
 * Hardware Camera LED Flashlight (Torch) Controller
 * Utilizes navigator.mediaDevices.getUserMedia and ImageCapture / MediaStreamTrack constraints.
 */

export interface TorchStatus {
  isSupported: boolean | null; // null = unprobed/probing, true = supported, false = not supported
  isActive: boolean;
  isPermissionGranted: boolean;
  errorMessage: string | null;
}

class TorchController {
  private mediaStream: MediaStream | null = null;
  private videoTrack: MediaStreamTrack | null = null;
  private statusListeners: Set<(status: TorchStatus) => void> = new Set();
  private status: TorchStatus = {
    isSupported: null,
    isActive: false,
    isPermissionGranted: false,
    errorMessage: null,
  };

  constructor() {
    this.checkInitialSupport();
  }

  public subscribe(listener: (status: TorchStatus) => void): () => void {
    this.statusListeners.add(listener);
    listener(this.status);
    return () => {
      this.statusListeners.delete(listener);
    };
  }

  private updateStatus(patch: Partial<TorchStatus>) {
    this.status = { ...this.status, ...patch };
    this.statusListeners.forEach((listener) => listener(this.status));
  }

  public getStatus(): TorchStatus {
    return this.status;
  }

  private async checkInitialSupport() {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      this.updateStatus({
        isSupported: false,
        errorMessage: 'Prohlížeč nepodporuje přístup ke kameře (MediaDevices API).',
      });
      return;
    }
  }

  /**
   * Acquire camera stream with torch capability
   */
  private async acquireTrack(): Promise<MediaStreamTrack | null> {
    if (this.videoTrack && this.videoTrack.readyState === 'live') {
      return this.videoTrack;
    }

    try {
      this.updateStatus({ errorMessage: null });
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          // Some browsers accept advanced constraint directly
          width: { ideal: 640 },
          height: { ideal: 480 },
        },
        audio: false,
      });

      this.mediaStream = stream;
      const tracks = stream.getVideoTracks();
      if (!tracks.length) {
        throw new Error('Nenalezena žádná videostopka kamery.');
      }

      const track = tracks[0];
      this.videoTrack = track;
      this.updateStatus({ isPermissionGranted: true });

      // Check capabilities
      const capabilities = (track.getCapabilities?.() || {}) as { torch?: boolean };
      const hasTorch = Boolean(capabilities.torch);

      this.updateStatus({
        isSupported: hasTorch,
        errorMessage: hasTorch ? null : 'Vaše zařízení nebo vybraná kamera nemá hardwarový LED blesk (bude použito světlo displeje).',
      });

      track.onended = () => {
        this.updateStatus({ isActive: false });
        this.cleanup();
      };

      return track;
    } catch (err: unknown) {
      const error = err as Error;
      let userFriendlyMsg = 'Nepodařilo se zapnout LED blesk.';

      if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
        userFriendlyMsg = 'Přístup ke kameře byl zamítnut. Pro hardwarový blesk povolte oprávnění v prohlížeči.';
      } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
        userFriendlyMsg = 'Zadní kamera s LED bleskem nebyla nalezena.';
      } else if (error.name === 'NotReadableError' || error.name === 'TrackStartError') {
        userFriendlyMsg = 'Kamera je využívána jinou aplikací.';
      }

      this.updateStatus({
        isSupported: false,
        isActive: false,
        errorMessage: userFriendlyMsg,
      });
      return null;
    }
  }

  /**
   * Turn the physical LED flash ON
   */
  public async turnOn(): Promise<boolean> {
    const track = await this.acquireTrack();
    if (!track) {
      return false;
    }

    try {
      // Cast to constraint with torch
      const constraints = {
        advanced: [{ torch: true } as unknown as MediaTrackConstraintSet],
      };
      await track.applyConstraints(constraints);
      this.updateStatus({ isActive: true, errorMessage: null });
      return true;
    } catch (err: unknown) {
      console.warn('Torch applyConstraints failed:', err);
      this.updateStatus({
        isActive: false,
        errorMessage: 'Zařízení nepodporuje ovládání LED blesku přes webové API. Můžete použít světlo displeje.',
      });
      return false;
    }
  }

  /**
   * Turn the physical LED flash OFF
   */
  public async turnOff(): Promise<void> {
    if (this.videoTrack && this.videoTrack.readyState === 'live') {
      try {
        const constraints = {
          advanced: [{ torch: false } as unknown as MediaTrackConstraintSet],
        };
        await this.videoTrack.applyConstraints(constraints);
      } catch {
        // Ignore error when turning off
      }
    }
    this.cleanup();
    this.updateStatus({ isActive: false });
  }

  /**
   * Toggle physical torch
   */
  public async toggle(): Promise<boolean> {
    if (this.status.isActive) {
      await this.turnOff();
      return false;
    } else {
      return await this.turnOn();
    }
  }

  /**
   * Quick pulse for strobe/SOS (without destroying stream)
   */
  public async setTorchState(active: boolean): Promise<boolean> {
    let track = this.videoTrack;
    if (active && (!track || track.readyState !== 'live')) {
      track = await this.acquireTrack();
    }
    if (!track || track.readyState !== 'live') return false;

    try {
      await track.applyConstraints({
        advanced: [{ torch: active } as unknown as MediaTrackConstraintSet],
      });
      this.updateStatus({ isActive: active });
      return true;
    } catch {
      return false;
    }
  }

  public cleanup() {
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }
    this.videoTrack = null;
  }
}

export const torchService = new TorchController();
