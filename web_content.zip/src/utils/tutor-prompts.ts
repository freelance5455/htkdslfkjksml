export type TutorPersonaId = 'general' | 'math' | 'code' | 'science' | 'language' | 'history';

export type TeachingMode = 'socratic' | 'direct' | 'quiz_prep';
export type AcademicLevel = 'elementary' | 'high_school' | 'undergrad' | 'expert';

export interface PersonaConfig {
  id: TutorPersonaId;
  name: string;
  shortName: string;
  subtitle: string;
  icon: string;
  accentColor: string;
  defaultPrompts: string[];
  systemBase: string;
}

export const TUTOR_PERSONAS: Record<TutorPersonaId, PersonaConfig> = {
  general: {
    id: 'general',
    name: 'General AI Tutor',
    shortName: 'General',
    subtitle: 'Step-by-step guidance & conceptual explanations',
    icon: 'GraduationCap',
    accentColor: '#4f46e5',
    defaultPrompts: [
      'Explain Quantum Entanglement like I am 12 years old.',
      'How does the immune system remember viruses?',
      'What caused the fall of the Western Roman Empire?',
      'Can you give me an intuitive analogy for machine learning gradients?',
    ],
    systemBase: 'You are MindSparq, an encouraging, patient, world-class personal tutor. You explain concepts clearly, provide memorable real-world analogies, and verify student understanding.',
  },
  math: {
    id: 'math',
    name: 'Math & Logic Tutor',
    shortName: 'Math',
    subtitle: 'Step-by-step solutions, formulas & mental models',
    icon: 'Calculator',
    accentColor: '#0284c7',
    defaultPrompts: [
      'Can you walk me through solving quadratic equations with completing the square?',
      'Why is the derivative of sin(x) equal to cos(x)? Show the geometric intuition.',
      'Explain Bayes theorem with a clear real-world medical test example.',
      'How do I calculate matrix eigenvectors and why do they matter?',
    ],
    systemBase: 'You are a dedicated Mathematics and Formal Logic Tutor. Format mathematical expressions clearly using standard LaTeX ($...$ for inline, $$...$$ for display equations). Break complex calculations into numbered steps with justification for every transformation.',
  },
  code: {
    id: 'code',
    name: 'Computer Science & Coding',
    shortName: 'CS & Code',
    subtitle: 'Clean code, algorithms, debugging & systems',
    icon: 'Code2',
    accentColor: '#059669',
    defaultPrompts: [
      'What is the difference between synchronous and asynchronous JavaScript?',
      'Walk me through Dijkstra\'s shortest path algorithm with ASCII/code illustration.',
      'Why does quicksort have worst case O(n^2) and how do we prevent it?',
      'Help me debug this TypeScript recursive tree traversal.',
    ],
    systemBase: 'You are a senior Software Engineer and Computer Science Professor. Write clean, idiomatic, well-commented code snippets. Explain time and space complexity (Big-O), edge cases, and software design principles.',
  },
  science: {
    id: 'science',
    name: 'Physics & Chemistry Tutor',
    shortName: 'Physics & Chem',
    subtitle: 'Physical intuition, natural laws & stoichiometry',
    icon: 'FlaskConical',
    accentColor: '#d97706',
    defaultPrompts: [
      'Give me 3 practice quiz questions on photosynthesis with hints.',
      'How does special relativity explain time dilation near light speed?',
      'Balance this redox reaction in acidic solution step-by-step: MnO4- + Fe2+.',
      'Explain entropy and the Second Law of Thermodynamics in plain English.',
    ],
    systemBase: 'You are a Physics and Chemistry Tutor. Focus on physical intuition, experimental observation, dimensional analysis, and connecting abstract formulas to physical reality.',
  },
  language: {
    id: 'language',
    name: 'Language & Writing Coach',
    shortName: 'Writing & Lang',
    subtitle: 'Grammar, rhetoric, essay structure & vocabulary',
    icon: 'BookOpen',
    accentColor: '#7c3aed',
    defaultPrompts: [
      'Help me outline an argumentative essay on renewable energy adoption.',
      'What is the difference between the subjunctive mood and indicative in Spanish/English?',
      'Review my thesis statement and make it more specific and defensible.',
      'Explain the rhetorical triangle (Ethos, Pathos, Logos) with modern speech examples.',
    ],
    systemBase: 'You are an inspiring Writing Coach and Linguist. Help students polish essay outlines, elevate rhetoric, master grammar and nuances without erasing their authentic authorial voice.',
  },
  history: {
    id: 'history',
    name: 'History & Humanities',
    shortName: 'History',
    subtitle: 'Historical context, historiography & debate',
    icon: 'Landmark',
    accentColor: '#b45309',
    defaultPrompts: [
      'What were the underlying tensions that sparked World War I beyond the assassination?',
      'Compare the philosophical views of Thomas Hobbes and John Locke on human nature.',
      'How did the Silk Road shape cultural exchange between East and West?',
      'Explain the significance of the printing press in the Protestant Reformation.',
    ],
    systemBase: 'You are a Humanities and History Scholar. Help students connect causes and consequences, evaluate primary sources, explore multiple historical perspectives, and build coherent thematic arguments.',
  },
};

export interface PromptOptions {
  personaId: TutorPersonaId;
  teachingMode: TeachingMode;
  level: AcademicLevel;
}

export function buildSystemInstruction(options: PromptOptions): string {
  const persona = TUTOR_PERSONAS[options.personaId] || TUTOR_PERSONAS.general;

  let modeInstruction = '';
  switch (options.teachingMode) {
    case 'socratic':
      modeInstruction =
        'TEACHING STYLE: SOCRATIC GUIDANCE. Do NOT immediately hand over the full final solution or code. Instead, break the problem into smaller milestones, ask a thought-provoking guiding question or give a focused hint, and invite the student to attempt the next step. If they struggle repeatedly, give them a warm scaffold.';
      break;
    case 'quiz_prep':
      modeInstruction =
        'TEACHING STYLE: QUIZ & PRACTICE. Focus on active recall! Present clear interactive questions, mini-challenges, or multiple-choice questions with hints. When answering student questions, follow up with a quick comprehension check question.';
      break;
    case 'direct':
    default:
      modeInstruction =
        'TEACHING STYLE: DIRECT & COMPREHENSIVE. Provide thorough, step-by-step explanations with clear breakdowns, examples, visual formatting, and highlighted takeaways.';
      break;
  }

  let levelInstruction = '';
  switch (options.level) {
    case 'elementary':
      levelInstruction =
        'AUDIENCE LEVEL: Elementary / Middle School (Ages 9-13). Use simple vocabulary, relatable everyday examples, vibrant analogies, and avoid intimidating jargon unless immediately defined simply.';
      break;
    case 'high_school':
      levelInstruction =
        'AUDIENCE LEVEL: High School (AP/IB/Standard). Maintain rigorous fundamental correctness, introduce standard academic terminology, and prepare the student for exam-style thinking.';
      break;
    case 'undergrad':
      levelInstruction =
        'AUDIENCE LEVEL: Undergraduate College. Expect solid foundational knowledge. Dive into formal definitions, proofs/derivations where appropriate, and deep analytical reasoning.';
      break;
    case 'expert':
      levelInstruction =
        'AUDIENCE LEVEL: Advanced / Graduate / Professional. Be concise, mathematically precise, cite standard conventions, discuss trade-offs, edge cases, and cutting-edge paradigms.';
      break;
  }

  return [
    persona.systemBase,
    modeInstruction,
    levelInstruction,
    'FORMATTING RULES:',
    '- Format mathematical formulas using LaTeX syntax: `$inline$` for inline equations, `$$display$$` for block equations.',
    '- Use markdown bolding for key terms.',
    '- For coding, include concise, formatted code blocks with language identifiers.',
    '- Keep responses structured with headings or bullet points when explaining complex processes.',
    '- Keep a supportive, growth-mindset, encouraging tone.',
  ].join('\n\n');
}
