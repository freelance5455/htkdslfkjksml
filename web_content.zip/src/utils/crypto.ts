import CryptoJS from 'crypto-js';
import { EncryptedDataPayload } from '../types';

const DEFAULT_APP_SALT = 'TakaTrackerBangla_2026_SecureVault';

/**
 * Hash a PIN or password securely
 */
export function hashPin(pin: string): string {
  return CryptoJS.SHA256(`${pin}_${DEFAULT_APP_SALT}`).toString(CryptoJS.enc.Hex);
}

/**
 * Verify if provided PIN matches stored hash
 */
export function verifyPin(inputPin: string, storedHash: string): boolean {
  return hashPin(inputPin) === storedHash;
}

/**
 * Encrypt arbitrary JSON object with user key or default device key
 */
export function encryptData<T>(data: T, userKey: string = DEFAULT_APP_SALT): string {
  try {
    const jsonString = JSON.stringify(data);
    const ciphertext = CryptoJS.AES.encrypt(jsonString, userKey).toString();
    const payload: EncryptedDataPayload = {
      v: 1,
      timestamp: Date.now(),
      ciphertext,
    };
    return JSON.stringify(payload);
  } catch (error) {
    console.error('Encryption failed:', error);
    return JSON.stringify(data);
  }
}

/**
 * Decrypt data payload back to typed object
 */
export function decryptData<T>(encryptedString: string, userKey: string = DEFAULT_APP_SALT): T | null {
  if (!encryptedString) return null;

  try {
    // Check if payload is encrypted JSON wrapper
    if (encryptedString.startsWith('{') && encryptedString.includes('"ciphertext"')) {
      const payload: EncryptedDataPayload = JSON.parse(encryptedString);
      const bytes = CryptoJS.AES.decrypt(payload.ciphertext, userKey);
      const originalText = bytes.toString(CryptoJS.enc.Utf8);
      if (!originalText) return null;
      return JSON.parse(originalText) as T;
    }

    // Unencrypted legacy string fallback
    return JSON.parse(encryptedString) as T;
  } catch (error) {
    console.error('Decryption error:', error);
    return null;
  }
}

/**
 * Generate a 6-digit 2FA simulation OTP code
 */
export function generate2FACode(): string {
  const code = Math.floor(100000 + Math.random() * 900000);
  return String(code);
}

/**
 * Hash a pattern (represented as dot indices, e.g. [0, 1, 2, 4, 8])
 */
export function hashPattern(pattern: number[] | string): string {
  const str = Array.isArray(pattern) ? pattern.join('-') : pattern;
  return CryptoJS.SHA256(`pattern_${str}_${DEFAULT_APP_SALT}`).toString(CryptoJS.enc.Hex);
}

/**
 * Verify pattern against stored hash
 */
export function verifyPattern(inputPattern: number[] | string, storedHash: string): boolean {
  if (!storedHash) return false;
  return hashPattern(inputPattern) === storedHash;
}
