import { Note, VaultMetadata } from "../types";

// Base64 helpers
export function bufferToBase64(buf: ArrayBuffer): string {
  let binary = "";
  const bytes = new Uint8Array(buf);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export function base64ToBuffer(base64: string): ArrayBuffer {
  if (!base64) return new ArrayBuffer(0);
  const cleanBase64 = base64.trim().replace(/[\r\n]/g, "");
  const binaryString = atob(cleanBase64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

// Convert bytes to Hex string
export function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

// Convert Hex string to Uint8Array
export function hexToBytes(hex: string): Uint8Array {
  const cleanHex = hex.trim().replace(/[^0-9a-fA-F]/g, "");
  const bytes = new Uint8Array(cleanHex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(cleanHex.substr(i * 2, 2), 16);
  }
  return bytes;
}

// 256 carefully selected BIP39-compatible memorable words for 12-word cryptographic seed recovery
export const MNEMONIC_WORDS = [
  "atlas", "akdeniz", "anadolu", "ay", "yildiz", "aslan", "kartal", "kaplan", "deniz", "nehir",
  "dag", "orman", "gunes", "ruzgar", "bulut", "yagmur", "simsek", "ates", "toprak", "agac",
  "cicek", "yaprak", "bahar", "yaz", "sonbahar", "kis", "gece", "safak", "gokyuzu", "pusula",
  "kristal", "elmas", "yakut", "safir", "inci", "kehribar", "zümrüt", "altin", "gümüs", "bakir",
  "demir", "celik", "kalkan", "kilic", "mizrak", "ok", "yay", "hisar", "kale", "kule",
  "saray", "liman", "gemi", "yelken", "fener", "yol", "kopru", "vadi", "zirve", "kaya",
  "ada", "okyanus", "dalga", "marti", "kugu", "guvercin", "sahin", "atmaca", "serce", "bulbul",
  "leylek", "turna", "ceylan", "geyik", "kurt", "tilki", "sincap", "tavsan", "kirpi", "yunus",
  "balina", "mercan", "yosun", "sedef", "ceviz", "findik", "badem", "fistik", "zeytin", "incir",
  "uzum", "nar", "elma", "armut", "kiraz", "visne", "erik", "kayisi", "seftali", "kavun",
  "karpuz", "limon", "portakal", "mandalina", "cilek", "bogurtlen", "ahududu", "dut", "lavanta", "gul",
  "lale", "nergis", "papatya", "menekse", "karanfil", "orkide", "nilufer", "yasemin", "leylak", "cam",
  "mese", "cinar", "gurgen", "kayin", "kavak", "ihlamur", "selvi", "sedir", "ardic", "sofut",
  "kitap", "kalem", "defter", "kagit", "muhur", "harita", "saat", "ayna", "kandil", "meale",
  "isik", "golge", "yankı", "ezgi", "beste", "sarki", "siir", "destan", "masal", "efsane",
  "bilge", "ozan", "yigite", "kahraman", "dost", "yoldas", "sırdas", "hazine", "sandik", "anahtar",
  "kilit", "muhafiz", "noebetci", "rehber", "oncu", "gezgin", "kaptan", "tayfa", "ustad", "cirak",
  "ziya", "nur", "hilal", "dolunay", "kutup", "samanyolu", "galaksi", "gezegen", "yildiztozu", "kuyruklu",
  "safir", "beril", "opal", "kuvars", "granit", "mermer", "lav", "volkan", "magma", "kaynak",
  "pinar", "dere", "cay", "irmak", "selale", "göl", "bent", "baraj", "kanyon", "gecit",
  "patika", "menzil", "ufuk", "ziyafet", "sevinç", "huzur", "guven", "umut", "cesaret", "sabir",
  "sadakat", "adalet", "erdem", "hikmet", "akil", "fikir", "ilham", "hafiza", "zihin", "ruh",
  "can", "omur", "zaman", "asir", "devir", "cag", "mevsim", "an", "sonsuzluk", "dunya",
  "evren", "kainat", "mekan", "vatan", "yurt", "ocak", "yolculuk", "zafer", "bayrak", "sancak",
  "ozgurluk", "baris", "birlik", "dirlik", "ugur", "bereket", "kudret", "sevgi", "vefa", "merhamet",
  "engin", "derin", "yuksek", "berrak", "durak", "sessizlik", "yankı", "nefes", "soluk", "yasam"
];

// Encode 32-byte raw master key to 12 recovery words + 1 checksum word
export function rawKeyToMnemonic(rawKey: Uint8Array): string {
  const words: string[] = [];
  // Use 16 bytes for 12 words (approx 8 bits per word) or slice 24 bytes
  for (let i = 0; i < 12; i++) {
    const idx = rawKey[i % rawKey.length] % MNEMONIC_WORDS.length;
    words.push(MNEMONIC_WORDS[idx]);
  }
  return words.join(" ");
}

// Derive AES-GCM 256 key from PIN and salt via PBKDF2
export async function deriveKeyFromPin(pin: string, salt: Uint8Array): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  const baseKey = await crypto.subtle.importKey(
    "raw",
    encoder.encode(pin),
    "PBKDF2",
    false,
    ["deriveKey"]
  );

  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: salt as unknown as BufferSource,
      iterations: 120000,
      hash: "SHA-256",
    },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

// Encrypt payload using AES-GCM
export async function encryptData(data: any, keyBytes: Uint8Array): Promise<{ iv: string; data: string }> {
  const key = await crypto.subtle.importKey("raw", keyBytes as unknown as BufferSource, { name: "AES-GCM" }, false, ["encrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encoded = new TextEncoder().encode(JSON.stringify(data));
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, encoded);

  return {
    iv: bufferToBase64(iv.buffer),
    data: bufferToBase64(ciphertext),
  };
}

// Decrypt payload using AES-GCM
export async function decryptData(encryptedIv: string, encryptedData: string, keyBytes: Uint8Array): Promise<any> {
  const key = await crypto.subtle.importKey("raw", keyBytes as unknown as BufferSource, { name: "AES-GCM" }, false, ["decrypt"]);
  const iv = new Uint8Array(base64ToBuffer(encryptedIv));
  const ciphertext = base64ToBuffer(encryptedData);
  const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, ciphertext);
  const decoded = new TextDecoder().decode(decrypted);
  return JSON.parse(decoded);
}

// Normalize string for recovery answer comparison (turkish-aware, trim punctuation & space)
export function normalizeAnswer(ans: string): string {
  if (!ans) return "";
  return ans
    .trim()
    .toLowerCase()
    .replace(/ğ/g, "g")
    .replace(/ü/g, "u")
    .replace(/ş/g, "s")
    .replace(/ı/g, "i")
    .replace(/ö/g, "o")
    .replace(/ç/g, "c")
    .replace(/[\s\W_]+/g, "");
}

// Initialize a new Vault with PIN, Security Question, Mnemonic Recovery Phrase & Emergency Key
export async function initializeVault(
  pin: string,
  securityQuestion?: string,
  securityAnswer?: string,
  hint?: string,
  autoLockTimeout: number = 0
): Promise<{ record: VaultMetadata; rawKey: Uint8Array; mnemonicPhrase: string; emergencyHexKey: string }> {
  const rawKey = crypto.getRandomValues(new Uint8Array(32));
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const pinKey = await deriveKeyFromPin(pin, salt);

  const keyIv = crypto.getRandomValues(new Uint8Array(12));
  const wrappedKey = await crypto.subtle.encrypt({ name: "AES-GCM", iv: keyIv as unknown as BufferSource }, pinKey, rawKey.buffer as ArrayBuffer);

  let recoveryKeyIv: string | undefined;
  let recoveryKeyData: string | undefined;

  if (securityAnswer && securityAnswer.trim().length > 0) {
    const normAns = normalizeAnswer(securityAnswer);
    const recoveryPinKey = await deriveKeyFromPin(normAns, salt);
    const recIv = crypto.getRandomValues(new Uint8Array(12));
    const recWrapped = await crypto.subtle.encrypt({ name: "AES-GCM", iv: recIv as unknown as BufferSource }, recoveryPinKey, rawKey.buffer as ArrayBuffer);
    recoveryKeyIv = bufferToBase64(recIv.buffer);
    recoveryKeyData = bufferToBase64(recWrapped);
  }

  // Generate 12-word mnemonic phrase & Mnemonic wrapper key
  const mnemonicPhrase = rawKeyToMnemonic(rawKey);
  const mnemonicDerivedKey = await deriveKeyFromPin(normalizeAnswer(mnemonicPhrase), salt);
  const mnemIv = crypto.getRandomValues(new Uint8Array(12));
  const mnemWrapped = await crypto.subtle.encrypt({ name: "AES-GCM", iv: mnemIv as unknown as BufferSource }, mnemonicDerivedKey, rawKey.buffer as ArrayBuffer);

  const emergencyHexKey = bytesToHex(rawKey);

  const initialNotes: Note[] = [];
  const payload = await encryptData(initialNotes, rawKey);

  const record: VaultMetadata = {
    version: 2,
    salt: bufferToBase64(salt.buffer),
    keyIv: bufferToBase64(keyIv.buffer),
    keyData: bufferToBase64(wrappedKey),
    dataIv: payload.iv,
    data: payload.data,
    securityQuestion: securityQuestion?.trim() || undefined,
    recoveryKeyIv,
    recoveryKeyData,
    recoveryMnemonicIv: bufferToBase64(mnemIv.buffer),
    recoveryMnemonicData: bufferToBase64(mnemWrapped),
    hint: hint?.trim() || undefined,
    autoLockTimeout,
  };

  return { record, rawKey, mnemonicPhrase, emergencyHexKey };
}

// Unlock Vault using PIN
export async function unlockVault(record: VaultMetadata, pin: string): Promise<{ notes: Note[]; rawKey: Uint8Array }> {
  if (!record || !record.salt || !record.keyIv || !record.keyData || !record.dataIv || !record.data) {
    throw new Error("Kasa kayıt verileri eksik veya bozulmuş.");
  }
  const salt = new Uint8Array(base64ToBuffer(record.salt));
  const pinKey = await deriveKeyFromPin(pin, salt);

  const keyIv = new Uint8Array(base64ToBuffer(record.keyIv));
  const wrappedKey = base64ToBuffer(record.keyData);

  const rawKeyBuffer = await crypto.subtle.decrypt({ name: "AES-GCM", iv: keyIv }, pinKey, wrappedKey);
  const rawKey = new Uint8Array(rawKeyBuffer);

  const notes = await decryptData(record.dataIv, record.data, rawKey);
  return { notes: Array.isArray(notes) ? notes : [], rawKey };
}

// Recover/Unlock Vault using Security Answer
export async function unlockVaultWithSecurityAnswer(
  record: VaultMetadata,
  answer: string
): Promise<{ notes: Note[]; rawKey: Uint8Array }> {
  if (!record || !record.salt || !record.recoveryKeyIv || !record.recoveryKeyData || !record.dataIv || !record.data) {
    throw new Error("Güvenlik sorusu kaydı bulunamadı.");
  }

  const salt = new Uint8Array(base64ToBuffer(record.salt));
  const normAns = normalizeAnswer(answer);
  const recoveryPinKey = await deriveKeyFromPin(normAns, salt);

  const recIv = new Uint8Array(base64ToBuffer(record.recoveryKeyIv));
  const wrappedKey = base64ToBuffer(record.recoveryKeyData);

  const rawKeyBuffer = await crypto.subtle.decrypt({ name: "AES-GCM", iv: recIv }, recoveryPinKey, wrappedKey);
  const rawKey = new Uint8Array(rawKeyBuffer);

  const notes = await decryptData(record.dataIv, record.data, rawKey);
  return { notes: Array.isArray(notes) ? notes : [], rawKey };
}

// Recover/Unlock Vault using 12-Word Mnemonic Phrase
export async function unlockVaultWithMnemonic(
  record: VaultMetadata,
  mnemonicPhrase: string
): Promise<{ notes: Note[]; rawKey: Uint8Array }> {
  if (!record || !record.salt || !record.dataIv || !record.data) {
    throw new Error("Kasa kayıt verisi bulunamadı.");
  }

  const salt = new Uint8Array(base64ToBuffer(record.salt));
  const normMnem = normalizeAnswer(mnemonicPhrase);

  if (record.recoveryMnemonicIv && record.recoveryMnemonicData) {
    const mnemonicKey = await deriveKeyFromPin(normMnem, salt);
    const mnemIv = new Uint8Array(base64ToBuffer(record.recoveryMnemonicIv));
    const mnemWrapped = base64ToBuffer(record.recoveryMnemonicData);
    const rawKeyBuffer = await crypto.subtle.decrypt({ name: "AES-GCM", iv: mnemIv }, mnemonicKey, mnemWrapped);
    const rawKey = new Uint8Array(rawKeyBuffer);
    const notes = await decryptData(record.dataIv, record.data, rawKey);
    return { notes: Array.isArray(notes) ? notes : [], rawKey };
  }

  throw new Error("Kasa için kurtarma cümlesi kaydı bulunamadı.");
}

// Recover/Unlock Vault directly using Emergency Master Hex Key (256-bit token)
export async function unlockVaultWithEmergencyHexKey(
  record: VaultMetadata,
  hexKey: string
): Promise<{ notes: Note[]; rawKey: Uint8Array }> {
  if (!record || !record.dataIv || !record.data) {
    throw new Error("Kasa verisi eksik.");
  }
  const cleanHex = hexKey.trim().replace(/[^0-9a-fA-F]/g, "");
  if (cleanHex.length !== 64) {
    throw new Error("Geçersiz Acil Durum Anahtarı (64 karakterlik Hex olmalıdır).");
  }
  const rawKey = hexToBytes(cleanHex);
  const notes = await decryptData(record.dataIv, record.data, rawKey);
  return { notes: Array.isArray(notes) ? notes : [], rawKey };
}

// Reset Vault PIN using rawKey (derived via Security Answer, 12-word Mnemonic, or Emergency Hex Token)
export async function resetVaultPinWithRawKey(
  record: VaultMetadata,
  rawKey: Uint8Array,
  newPin: string,
  newQuestion?: string,
  newAnswer?: string,
  newHint?: string
): Promise<{ newRecord: VaultMetadata; newRawKey: Uint8Array; mnemonicPhrase: string; emergencyHexKey: string }> {
  const notes = await decryptData(record.dataIv, record.data, rawKey);

  const newSalt = crypto.getRandomValues(new Uint8Array(16));
  const newPinKey = await deriveKeyFromPin(newPin, newSalt);

  const keyIv = crypto.getRandomValues(new Uint8Array(12));
  const wrappedKey = await crypto.subtle.encrypt({ name: "AES-GCM", iv: keyIv as unknown as BufferSource }, newPinKey, rawKey.buffer as ArrayBuffer);

  let recoveryKeyIv: string | undefined;
  let recoveryKeyData: string | undefined;

  const finalAnswer = newAnswer && newAnswer.trim().length > 0 ? newAnswer : undefined;
  if (finalAnswer && finalAnswer.trim().length > 0) {
    const normAns = normalizeAnswer(finalAnswer);
    const recoveryPinKey = await deriveKeyFromPin(normAns, newSalt);
    const recIv = crypto.getRandomValues(new Uint8Array(12));
    const recWrapped = await crypto.subtle.encrypt({ name: "AES-GCM", iv: recIv as unknown as BufferSource }, recoveryPinKey, rawKey.buffer as ArrayBuffer);
    recoveryKeyIv = bufferToBase64(recIv.buffer);
    recoveryKeyData = bufferToBase64(recWrapped);
  }

  // Regenerate mnemonic wrapper with new salt
  const mnemonicPhrase = rawKeyToMnemonic(rawKey);
  const mnemonicDerivedKey = await deriveKeyFromPin(normalizeAnswer(mnemonicPhrase), newSalt);
  const mnemIv = crypto.getRandomValues(new Uint8Array(12));
  const mnemWrapped = await crypto.subtle.encrypt({ name: "AES-GCM", iv: mnemIv as unknown as BufferSource }, mnemonicDerivedKey, rawKey.buffer as ArrayBuffer);

  const payload = await encryptData(notes, rawKey);

  const newRecord: VaultMetadata = {
    version: 2,
    salt: bufferToBase64(newSalt.buffer),
    keyIv: bufferToBase64(keyIv.buffer),
    keyData: bufferToBase64(wrappedKey),
    dataIv: payload.iv,
    data: payload.data,
    securityQuestion: newQuestion?.trim() || record.securityQuestion,
    recoveryKeyIv,
    recoveryKeyData,
    recoveryMnemonicIv: bufferToBase64(mnemIv.buffer),
    recoveryMnemonicData: bufferToBase64(mnemWrapped),
    hint: newHint !== undefined ? newHint.trim() || undefined : record.hint,
    autoLockTimeout: record.autoLockTimeout,
  };

  return { newRecord, newRawKey: rawKey, mnemonicPhrase, emergencyHexKey: bytesToHex(rawKey) };
}

// Reset Vault PIN using Security Answer (Forgot Password flow)
export async function resetVaultPinWithSecurityAnswer(
  record: VaultMetadata,
  securityAnswer: string,
  newPin: string,
  newQuestion?: string,
  newAnswer?: string,
  newHint?: string
): Promise<{ newRecord: VaultMetadata; newRawKey: Uint8Array; mnemonicPhrase: string; emergencyHexKey: string }> {
  const { rawKey } = await unlockVaultWithSecurityAnswer(record, securityAnswer);
  return resetVaultPinWithRawKey(record, rawKey, newPin, newQuestion, newAnswer, newHint);
}

// Re-encrypt Vault when saving new/updated vault notes
export async function saveVaultPayload(record: VaultMetadata, notes: Note[], rawKey: Uint8Array): Promise<VaultMetadata> {
  const payload = await encryptData(notes, rawKey);
  return {
    ...record,
    dataIv: payload.iv,
    data: payload.data,
  };
}

// Change Vault PIN
export async function changeVaultPin(
  record: VaultMetadata,
  currentPin: string,
  newPin: string,
  currentNotes: Note[],
  newQuestion?: string,
  newAnswer?: string,
  newHint?: string
): Promise<{ newRecord: VaultMetadata; newRawKey: Uint8Array; mnemonicPhrase: string; emergencyHexKey: string }> {
  // First verify current PIN and unlock
  const { rawKey } = await unlockVault(record, currentPin);
  return resetVaultPinWithRawKey(record, rawKey, newPin, newQuestion, newAnswer, newHint);
}

// =========================================================================
// SENSITIVE & PASSWORD NOTE DETECTION ENGINE (Autonomous Scanner)
// =========================================================================

export interface SensitiveDetectionResult {
  isSensitive: boolean;
  detectedTypes: string[];
  primaryReason: string;
  confidence: number;
}

export function detectSensitiveDataInNote(note: Partial<Note>): SensitiveDetectionResult {
  const detectedTypes: string[] = [];
  const text = `${note.title || ""} ${note.content || ""} ${(note.tags || []).join(" ")} ${note.category || ""}`;

  // Explicit Category or Flag
  const cat = (note.category || "").toLowerCase();
  if (cat.includes("şifre") || cat.includes("parola") || cat.includes("kasa") || cat.includes("vault") || cat.includes("güvenli") || cat.includes("hesaplar") || cat.includes("banka")) {
    detectedTypes.push("Şifre/Kasa Kategorisi");
  }

  // Tags
  const tagStr = (note.tags || []).join(" ").toLowerCase();
  if (tagStr.includes("şifre") || tagStr.includes("parola") || tagStr.includes("kasa") || tagStr.includes("gizli") || tagStr.includes("private") || tagStr.includes("secret") || tagStr.includes("iban") || tagStr.includes("kart") || tagStr.includes("pin")) {
    detectedTypes.push("Hassas Güvenlik Etiketi");
  }

  // Title keywords
  const titleLower = (note.title || "").toLowerCase();
  if (titleLower.includes("şifre") || titleLower.includes("parola") || titleLower.includes("password") || titleLower.includes("pin") || titleLower.includes("kredi kart") || titleLower.includes("iban") || titleLower.includes("hesap giriş") || titleLower.includes("cüzdan") || titleLower.includes("private key")) {
    detectedTypes.push("Hassas Başlık Bilgisi");
  }

  // IBAN Pattern (TR + 24 digits)
  const ibanRegex = /\bTR\d{2}\s?(?:\d{4}\s?){5}\d{2}\b/i;
  if (ibanRegex.test(text)) {
    detectedTypes.push("IBAN Banka Hesabı");
  }

  // Credit/Debit Card Pattern (16 digits)
  const ccRegex = /\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})\b|\b\d{4}[- ]\d{4}[- ]\d{4}[- ]\d{4}\b/;
  if (ccRegex.test(text)) {
    detectedTypes.push("Kredi / Banka Kartı");
  }

  // TC Identity Number Pattern (11 digits, first non-zero)
  const tcRegex = /\b[1-9]\d{10}\b/;
  if (tcRegex.test(text) && (text.toLowerCase().includes("tc") || text.toLowerCase().includes("kimlik") || text.toLowerCase().includes("t.c"))) {
    detectedTypes.push("T.C. Kimlik Numarası");
  }

  // Password / Credentials pattern
  const pwRegex = /\b(?:şifre|parola|password|pin\s*kodu?|kullanıcı\s*adı\s*[\/:]\s*\w+|giriş\s*bilgileri|login|passcode)\s*[:=]\s*[^\s\n]{3,}\b/i;
  if (pwRegex.test(text)) {
    detectedTypes.push("Kullanıcı Adı / Parola / PIN");
  }

  // Crypto Seed Phrase / Private Key / API Token
  const cryptoRegex = /\b(?:seed\s*phrase|private\s*key|gizli\s*anahtar|bip39|kurtarma\s*kelimeleri|mnemonic|api[_-]?key|bearer\s+[a-zA-Z0-9_\-\.]{15,}|jwt\s+[a-zA-Z0-9_\-\.]{20,})\b/i;
  if (cryptoRegex.test(text)) {
    detectedTypes.push("Kripto Anahtar / API Token / Kurtarma Cümlesi");
  }

  const isSensitive = detectedTypes.length > 0 || !!note.isVault;
  const primaryReason = detectedTypes[0] || (note.isVault ? "Korumalı Kasa Notu" : "");
  const confidence = isSensitive ? Math.min(1.0, 0.7 + detectedTypes.length * 0.1) : 0;

  return {
    isSensitive,
    detectedTypes,
    primaryReason,
    confidence,
  };
}

