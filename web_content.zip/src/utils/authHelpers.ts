export type PortalAccessDecision =
  | 'allow-student'
  | 'allow-admin'
  | 'deny-admin-access'
  | 'require-auth';

export function mapFirebaseAuthError(err: unknown, currentHostname?: string): string {
  const code = (err as { code?: string })?.code || '';
  const msg =
    err instanceof Error
      ? err.message
      : typeof (err as { message?: unknown })?.message === 'string'
        ? String((err as { message: string }).message)
        : String(err);
  const hostSuffix = currentHostname ? ` (${currentHostname})` : '';

  switch (code) {
    case 'auth/popup-closed-by-user':
    case 'auth/cancelled-popup-request':
      return 'Google sign-in was cancelled. Tap Continue with Google whenever you are ready.';
    case 'auth/popup-blocked':
      return 'Sign-in popup was blocked by your browser. Allow popups for this site and try again.';
    case 'auth/unauthorized-domain':
      return `This app domain${hostSuffix} is not authorized in Firebase Console → Authentication → Settings → Authorized domains.`;
    case 'auth/app-not-authorized':
      return `This app${hostSuffix} is not authorized to use Firebase Authentication with the configured project.`;
    case 'auth/operation-not-allowed':
      return 'Google Sign-In is not enabled in Firebase Console → Authentication → Sign-in method.';
    case 'auth/account-exists-with-different-credential':
      return 'An account already exists with this email under another sign-in provider.';
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return 'Invalid administrator email or password. Only authorized admin credentials are accepted.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    case 'auth/user-disabled':
      return 'This account has been disabled. Contact an administrator for assistance.';
    case 'auth/web-storage-unsupported':
      return 'Browser storage or cookies are blocked, preventing persistent login. Enable site storage and retry.';
    case 'auth/network-request-failed':
      return 'Network error while contacting Firebase. Check your internet connection and retry.';
    default:
      return msg || 'Authentication failed. Please try again.';
  }
}

export type AuthenticatedDestination =
  | 'require-auth'
  | 'checking-role'
  | 'admin-dashboard'
  | 'student-dashboard';

export type WorkspaceAccessDecision =
  | 'require-auth'
  | 'checking-role'
  | 'admin-dashboard'
  | 'student-dashboard-with-admin-nav'
  | 'student-dashboard-only'
  | 'deny-admin-entry';

/**
 * Resolves the post-login destination after Google Sign-In.
 * Normal Google accounts route strictly to 'student-dashboard'.
 * Server-verified Admin accounts route to 'admin-dashboard'.
 */
export function resolvePostAuthDestination(
  isAuthenticated: boolean,
  adminCheckStatus: 'idle' | 'checking' | 'authorized' | 'denied'
): AuthenticatedDestination {
  if (!isAuthenticated) {
    return 'require-auth';
  }
  if (adminCheckStatus === 'idle' || adminCheckStatus === 'checking') {
    return 'checking-role';
  }
  return adminCheckStatus === 'authorized' ? 'admin-dashboard' : 'student-dashboard';
}

/**
 * Resolves workspace access with separate Admin Panel entry, student isolation,
 * and optional Student Preview navigation for verified Admins only.
 */
export function resolveWorkspaceAccess(params: {
  isAuthenticated: boolean;
  adminCheckStatus: 'idle' | 'checking' | 'authorized' | 'denied';
  entryIntent: 'student' | 'admin';
  adminWorkspacePreference: 'admin' | 'student';
}): WorkspaceAccessDecision {
  const { isAuthenticated, adminCheckStatus, entryIntent, adminWorkspacePreference } = params;
  if (!isAuthenticated) {
    return 'require-auth';
  }
  if (adminCheckStatus === 'idle' || adminCheckStatus === 'checking') {
    return 'checking-role';
  }
  if (adminCheckStatus === 'authorized') {
    if (entryIntent === 'admin' || adminWorkspacePreference === 'admin') {
      return 'admin-dashboard';
    }
    return 'student-dashboard-with-admin-nav';
  }
  // Never expose Admin access or Admin navigation to non-admin students
  return entryIntent === 'admin' ? 'deny-admin-entry' : 'student-dashboard-only';
}

/**
 * Pure role-based route access resolver enforcing strict separation between Student and Admin dashboards.
 */
export function resolvePortalRouteAccess(
  portalMode: 'student' | 'admin',
  isAuthenticated: boolean,
  isServerVerifiedAdmin: boolean
): PortalAccessDecision {
  if (!isAuthenticated) {
    return 'require-auth';
  }
  if (portalMode === 'admin') {
    return isServerVerifiedAdmin ? 'allow-admin' : 'deny-admin-access';
  }
  return 'allow-student';
}
