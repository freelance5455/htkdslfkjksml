import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDailyBest,
  calculateWeeklyStats,
  calculateWeeklyRanking,
  calculateHistoricalRankings,
  canPublishTrick,
  getSaoPauloWeekRange,
} from './garrafoesLogic.ts';
import type { Season } from '../types/index.ts';

test('Acceptance Criterion 2: Best sequence from multiple attempts on same day is max, never summed', () => {
  // Nycollas attempts 4, 8, 6
  const attempts = [4, 8, 6];
  const best = calculateDailyBest(attempts);
  assert.equal(best, 8, 'Best sequence of 4, 8, 6 must be 8 (never 18 or 6)');

  // Later does 10
  const updatedAttempts = [...attempts, 10];
  const updatedBest = calculateDailyBest(updatedAttempts);
  assert.equal(updatedBest, 10, 'A subsequent higher attempt of 10 must update daily best to 10');

  // Then does 3 (lower attempt must never overwrite)
  const afterLower = [...updatedAttempts, 3];
  assert.equal(calculateDailyBest(afterLower), 10, 'A lower attempt must never overwrite a higher record');
});

test('Acceptance Criterion 3: 10 on Monday, 7 on Wednesday, 6 on Friday yields average 7.67 with 3 days', () => {
  const records = [
    { bestStreak: 10, trained: true }, // Segunda
    { bestStreak: 7, trained: true },  // Quarta
    { bestStreak: 6, trained: true },  // Sexta
  ];

  const stats = calculateWeeklyStats(records);
  assert.equal(stats.daysTrained, 3, 'Must record exactly 3 days of training');
  assert.equal(stats.sumStreaks, 23, 'Sum of streaks must be 23');
  assert.equal(stats.formattedAverage, '7,67', 'Formatted average with 2 decimals must be 7,67');
  assert.equal(stats.maxStreak, 10, 'Weekly max streak must be 10');
  // Precision check: 23 / 3 = 7.666666666666667
  assert.ok(Math.abs(stats.rawAverage - 7.666666666666667) < 0.00001, 'Raw average retains full precision');
});

test('Acceptance Criterion 6: Days without training do not enter average, but training with 0 enters as 0', () => {
  // Case A: 2 days trained (8 and 4) + 1 day marked as not trained
  const recordsWithoutZero = [
    { bestStreak: 8, trained: true },
    { bestStreak: 4, trained: true },
    { bestStreak: 0, trained: false }, // untyped or missed day
  ];
  const statsA = calculateWeeklyStats(recordsWithoutZero);
  assert.equal(statsA.daysTrained, 2);
  assert.equal(statsA.rawAverage, 6.0);
  assert.equal(statsA.formattedAverage, '6,00');

  // Case B: Player officially trained on a day, but failed all flips (0 valid sequence)
  const recordsWithZeroTraining = [
    { bestStreak: 8, trained: true },
    { bestStreak: 4, trained: true },
    { bestStreak: 0, trained: true }, // trained with 0
  ];
  const statsB = calculateWeeklyStats(recordsWithZeroTraining);
  assert.equal(statsB.daysTrained, 3);
  assert.equal(statsB.rawAverage, 4.0, '12 / 3 days = 4.0');
  assert.equal(statsB.formattedAverage, '4,00');
});

test('Acceptance Criterion 8: Trick draft locked until author reaches at least 5 executions', () => {
  const authorId = 'player-nycollas';
  const trickDraft = {
    authorId,
    executionsByPlayer: {
      [authorId]: 4,
    },
  };

  const check4 = canPublishTrick(trickDraft);
  assert.equal(check4.allowed, false, 'Publishing must be locked with only 4 executions');
  assert.equal(check4.remainingToUnlock, 1, '1 execution remaining to unlock');

  // 5th execution
  trickDraft.executionsByPlayer[authorId] = 5;
  const check5 = canPublishTrick(trickDraft);
  assert.equal(check5.allowed, true, 'Publishing must be unlocked at 5 executions');
  assert.equal(check5.remainingToUnlock, 0);

  // Other players executing does not unlock author requirement
  const trickOther = {
    authorId,
    executionsByPlayer: {
      [authorId]: 3,
      'player-v': 10,
    },
  };
  const checkOther = canPublishTrick(trickOther);
  assert.equal(checkOther.allowed, false, 'Author must personally have 5 validations');
});

test('Weekly ranking sorts by unrounded raw average and applies tiebreakers correctly', () => {
  const players = [
    {
      playerId: 'p1',
      records: [
        { bestStreak: 10, trained: true },
        { bestStreak: 8, trained: true }, // sum 18, avg 9.0
      ],
    },
    {
      playerId: 'p2',
      records: [
        { bestStreak: 12, trained: true },
        { bestStreak: 6, trained: true }, // sum 18, avg 9.0 (tied avg, but higher maxStreak: 12 vs 10)
      ],
    },
    {
      playerId: 'p3',
      records: [
        { bestStreak: 7, trained: true }, // sum 7, avg 7.0
      ],
    },
  ];

  const ranking = calculateWeeklyRanking('season-1', 'cat-200g', players);
  assert.equal(ranking.length, 3);
  assert.equal(ranking[0].playerId, 'p2', 'p2 should win tiebreaker due to higher maxStreak (12 vs 10)');
  assert.equal(ranking[0].rank, 1);
  assert.equal(ranking[0].isChampion, true);
  assert.equal(ranking[1].playerId, 'p1');
  assert.equal(ranking[1].rank, 2);
  assert.equal(ranking[2].playerId, 'p3');
  assert.equal(ranking[2].rank, 3);
});

test('Acceptance Criterion 9: Historical rankings calculate average of official weekly averages for closed seasons only', () => {
  const closedSeasons: Season[] = [
    {
      id: 'season-1',
      name: 'Semana 1',
      startDate: '2026-10-05',
      endDate: '2026-10-11',
      status: 'closed',
      timezone: 'America/Sao_Paulo',
      snapshots: {
        'cat-200g': [
          {
            seasonId: 'season-1',
            categoryId: 'cat-200g',
            playerId: 'p1',
            sumStreaks: 24,
            daysTrained: 3,
            rawAverage: 8.0,
            formattedAverage: '8,00',
            maxStreak: 10,
            rank: 1,
            isChampion: true,
          },
          {
            seasonId: 'season-1',
            categoryId: 'cat-200g',
            playerId: 'p2',
            sumStreaks: 18,
            daysTrained: 3,
            rawAverage: 6.0,
            formattedAverage: '6,00',
            maxStreak: 7,
            rank: 2,
            isChampion: false,
          },
        ],
      },
    },
    {
      id: 'season-2',
      name: 'Semana 2',
      startDate: '2026-10-12',
      endDate: '2026-10-18',
      status: 'closed',
      timezone: 'America/Sao_Paulo',
      snapshots: {
        'cat-200g': [
          {
            seasonId: 'season-2',
            categoryId: 'cat-200g',
            playerId: 'p1',
            sumStreaks: 20,
            daysTrained: 2,
            rawAverage: 10.0,
            formattedAverage: '10,00',
            maxStreak: 12,
            rank: 1,
            isChampion: true,
          },
          // p2 did not train in week 2
        ],
      },
    },
    {
      id: 'season-3-active',
      name: 'Semana 3 Ativa',
      startDate: '2026-10-19',
      endDate: '2026-10-25',
      status: 'active', // Active seasons MUST be excluded from historical
      timezone: 'America/Sao_Paulo',
      snapshots: {
        'cat-200g': [
          {
            seasonId: 'season-3-active',
            categoryId: 'cat-200g',
            playerId: 'p2',
            sumStreaks: 100,
            daysTrained: 1,
            rawAverage: 100.0,
            formattedAverage: '100,00',
            maxStreak: 100,
            rank: 1,
            isChampion: true,
          },
        ],
      },
    },
  ];

  const historical = calculateHistoricalRankings(closedSeasons, 'cat-200g', ['p1', 'p2']);
  assert.equal(historical.length, 2);

  // p1: week1 avg 8.0, week2 avg 10.0 -> average of averages = (8 + 10) / 2 = 9.0
  assert.equal(historical[0].playerId, 'p1');
  assert.equal(historical[0].validWeeksCount, 2);
  assert.equal(historical[0].rawHistoricalAverage, 9.0);
  assert.equal(historical[0].formattedHistoricalAverage, '9,00');
  assert.equal(historical[0].allTimeBestStreak, 12);
  assert.equal(historical[0].championTitlesCount, 2);

  // p2: week1 avg 6.0 (active week 3 was ignored!) -> avg = 6.0
  assert.equal(historical[1].playerId, 'p2');
  assert.equal(historical[1].validWeeksCount, 1);
  assert.equal(historical[1].rawHistoricalAverage, 6.0);
  assert.equal(historical[1].formattedHistoricalAverage, '6,00');
});

test('Sao Paulo week range calculation', () => {
  const range = getSaoPauloWeekRange(new Date('2026-10-20T12:00:00Z'));
  assert.ok(range.startDate);
  assert.ok(range.endDate);
  assert.ok(range.seasonId.startsWith('season-'));
});
