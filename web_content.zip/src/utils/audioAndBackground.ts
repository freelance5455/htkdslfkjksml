// Audio, Phone Ringtone Player, Silent Background Sleep-Mode Guard, Wake Lock & Notification Engine
import type { AlarmSlot } from '../types/study';

let audioCtx: AudioContext | null = null;
let alarmVibrationInterval: number | null = null;
let silentAudioElement: HTMLAudioElement | null = null;
let ringAudioElement: HTMLAudioElement | null = null;
let silentWavUrl: string | null = null;
let defaultAlarmWavUrl: string | null = null;
let customRingtoneUrl: string | null = null;
let wakeLockSentinel: WakeLockSentinel | null = null;
let bgGuardRunning = false;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const Ctx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return null;
  if (!audioCtx) {
    audioCtx = new Ctx();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

/**
 * Generates a 1-second silent PCM WAV Blob URL to keep the mobile browser audio session
 * and JS timers alive when the screen is turned off or locked.
 */
export function getSilentWavDataUri(): string {
  if (silentWavUrl) return silentWavUrl;
  const sampleRate = 8000;
  const numSamples = sampleRate;
  const dataSize = numSamples * 2;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  const writeStr = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, 'data');
  view.setUint32(40, dataSize, true);

  const blob = new Blob([buffer], { type: 'audio/wav' });
  silentWavUrl = URL.createObjectURL(blob);
  return silentWavUrl;
}

/**
 * Generates a crisp 1.8-second looping Phone Alarm WAV Blob URL.
 * Playing through HTMLAudioElement guarantees ringing even when the phone screen
 * is locked / asleep and Web Audio oscillators are throttled.
 */
export function getDefaultAlarmWavUri(): string {
  if (defaultAlarmWavUrl) return defaultAlarmWavUrl;
  const sampleRate = 22050;
  const durationSec = 1.8;
  const numSamples = Math.floor(sampleRate * durationSec);
  const dataSize = numSamples * 2;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  const writeStr = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, 'data');
  view.setUint32(40, dataSize, true);

  // Classic 4-pulse alarm chime pattern inside 1.8s
  const notes = [
    { start: 0.0, end: 0.16, freq: 880 },
    { start: 0.2, end: 0.36, freq: 1046.5 },
    { start: 0.4, end: 0.56, freq: 880 },
    { start: 0.6, end: 0.88, freq: 1174.66 },
  ];

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let sample = 0;
    for (const note of notes) {
      if (t >= note.start && t <= note.end) {
        const localT = t - note.start;
        const len = note.end - note.start;
        const env =
          Math.min(1, localT / 0.015) * Math.min(1, (len - localT) / 0.025);
        sample +=
          env *
          0.55 *
          (0.75 * Math.sin(2 * Math.PI * note.freq * t) +
            0.25 * Math.sin(2 * Math.PI * note.freq * 2 * t));
      }
    }
    const clamped = Math.max(-1, Math.min(1, sample));
    view.setInt16(44 + i * 2, Math.floor(clamped * 32767), true);
  }

  const blob = new Blob([buffer], { type: 'audio/wav' });
  defaultAlarmWavUrl = URL.createObjectURL(blob);
  return defaultAlarmWavUrl;
}

function ensureRingAudioElement(): HTMLAudioElement {
  if (!ringAudioElement) {
    ringAudioElement = document.createElement('audio');
    ringAudioElement.loop = true;
    ringAudioElement.volume = 1.0;
    ringAudioElement.setAttribute('playsinline', 'true');
  }
  const desiredSrc = customRingtoneUrl || getDefaultAlarmWavUri();
  if (ringAudioElement.src !== desiredSrc) {
    ringAudioElement.src = desiredSrc;
  }
  return ringAudioElement;
}

export function setCustomPhoneRingtoneUrl(blobUrl: string | null): void {
  if (customRingtoneUrl && customRingtoneUrl !== blobUrl) {
    URL.revokeObjectURL(customRingtoneUrl);
  }
  customRingtoneUrl = blobUrl;
  if (ringAudioElement) {
    ringAudioElement.src = customRingtoneUrl || getDefaultAlarmWavUri();
  }
}

export async function unlockAlarmAudioPlayback(): Promise<void> {
  try {
    getAudioContext();
    const audio = ensureRingAudioElement();
    const prevMuted = audio.muted;
    audio.muted = true;
    await audio.play();
    audio.pause();
    audio.currentTime = 0;
    audio.muted = prevMuted;
  } catch {
    // Ignore autoplay restriction errors before direct user gesture
  }
}

export async function startSilentBackgroundAudio(): Promise<boolean> {
  try {
    if (!silentAudioElement) {
      silentAudioElement = document.createElement('audio');
      silentAudioElement.src = getSilentWavDataUri();
      silentAudioElement.loop = true;
      silentAudioElement.volume = 0.01;
      silentAudioElement.setAttribute('playsinline', 'true');
    }

    await silentAudioElement.play();
    bgGuardRunning = true;

    if ('mediaSession' in navigator && 'MediaMetadata' in window) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: 'StudyPulse Alarm Guard',
        artist: 'Active in Sleep Mode',
        album: 'StudyPulse',
      });
      navigator.mediaSession.playbackState = 'playing';
    }
    return true;
  } catch {
    return false;
  }
}

export function stopSilentBackgroundAudio(): void {
  bgGuardRunning = false;
  if (silentAudioElement) {
    silentAudioElement.pause();
    silentAudioElement.currentTime = 0;
  }
  if ('mediaSession' in navigator) {
    navigator.mediaSession.playbackState = 'none';
  }
}

export async function toggleScreenWakeLock(enable: boolean): Promise<boolean> {
  if (!('wakeLock' in navigator)) return false;
  try {
    if (enable) {
      if (!wakeLockSentinel) {
        wakeLockSentinel = await navigator.wakeLock.request('screen');
        wakeLockSentinel.addEventListener('release', () => {
          wakeLockSentinel = null;
        });
      }
      return true;
    } else {
      if (wakeLockSentinel) {
        await wakeLockSentinel.release();
        wakeLockSentinel = null;
      }
      return false;
    }
  } catch {
    return false;
  }
}

export function playSoftChime(): void {
  const ctx = getAudioContext();
  if (!ctx) return;

  const notes = [523.25, 659.25, 783.99, 1046.5];
  const now = ctx.currentTime;

  notes.forEach((freq, i) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now + i * 0.14);

    gain.gain.setValueAtTime(0.001, now + i * 0.14);
    gain.gain.exponentialRampToValueAtTime(0.2, now + i * 0.14 + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.14 + 0.55);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + i * 0.14);
    osc.stop(now + i * 0.14 + 0.6);
  });
}

function playWebAudioFallbackBurst(): void {
  const ctx = getAudioContext();
  if (!ctx) return;
  const now = ctx.currentTime;
  const pattern = [880, 1046.5, 880, 1174.66];
  pattern.forEach((freq, idx) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, now + idx * 0.18);
    gain.gain.setValueAtTime(0.001, now + idx * 0.18);
    gain.gain.exponentialRampToValueAtTime(0.32, now + idx * 0.18 + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.18 + 0.16);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + idx * 0.18);
    osc.stop(now + idx * 0.18 + 0.17);
  });
}

export function startAlarmRinging(alarmTitle?: string): void {
  stopAlarmRinging();

  // Pause silent audio briefly so the main alarm ringtone owns speaker focus
  if (silentAudioElement && !silentAudioElement.paused) {
    silentAudioElement.pause();
  }

  const audio = ensureRingAudioElement();
  audio.currentTime = 0;
  audio.volume = 1.0;
  audio.play().catch(() => {
    // Fallback to Web Audio if HTMLAudioElement is blocked
    playWebAudioFallbackBurst();
  });

  if ('mediaSession' in navigator && 'MediaMetadata' in window) {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: alarmTitle || 'StudyPulse Alarm',
      artist: 'StudyPulse',
      album: 'Alarm',
    });
    navigator.mediaSession.playbackState = 'playing';
  }

  const vibrateOnce = () => {
    if ('vibrate' in navigator) {
      navigator.vibrate([300, 140, 300, 140, 400]);
    }
  };
  vibrateOnce();
  alarmVibrationInterval = window.setInterval(vibrateOnce, 1800);
}

export function stopAlarmRinging(): void {
  if (ringAudioElement) {
    ringAudioElement.pause();
    ringAudioElement.currentTime = 0;
  }
  if (alarmVibrationInterval !== null) {
    window.clearInterval(alarmVibrationInterval);
    alarmVibrationInterval = null;
  }
  if ('vibrate' in navigator) {
    navigator.vibrate(0);
  }

  // Resume background sleep-mode guard if it was active
  if (bgGuardRunning && silentAudioElement) {
    silentAudioElement.play().catch(() => {});
    if ('mediaSession' in navigator && 'MediaMetadata' in window) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: 'StudyPulse Alarm Guard',
        artist: 'Active in Sleep Mode',
        album: 'StudyPulse',
      });
      navigator.mediaSession.playbackState = 'playing';
    }
  }
}

export async function requestAppNotificationPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  if (Notification.permission === 'granted') {
    return 'granted';
  }
  return await Notification.requestPermission();
}

export async function dispatchStudyNotification(payload: {
  title: string;
  body: string;
  tag: string;
  kind: 'alarm' | 'pomodoro' | 'timer';
  alarmId?: number;
}): Promise<void> {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  if (Notification.permission !== 'granted') return;

  try {
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.ready;
      if (reg && reg.active) {
        reg.active.postMessage({
          type: 'SHOW_STUDY_NOTIFICATION',
          ...payload,
        });
        return;
      }
      if (reg && typeof reg.showNotification === 'function') {
        await reg.showNotification(payload.title, {
          body: payload.body,
          icon: '/pwa-192x192.png',
          tag: payload.tag,
          requireInteraction: true,
        });
        return;
      }
    }
    new Notification(payload.title, {
      body: payload.body,
      icon: '/pwa-192x192.png',
      tag: payload.tag,
    });
  } catch {
    // Silent fallback if browser blocks notifications
  }
}

/**
 * Generates and downloads a standard .ics calendar alarm file (with VALARM audio trigger)
 * so the user can attach any StudyPulse alarm directly into their phone's native Calendar/Alarm app.
 */
export function exportAlarmToPhoneCalendar(alarm: AlarmSlot): void {
  const [hhStr, mmStr] = (alarm.time || '06:00').split(':');
  const hh = Number(hhStr) || 6;
  const mm = Number(mmStr) || 0;

  const now = new Date();
  const target = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hh, mm, 0);
  if (target.getTime() <= now.getTime()) {
    target.setDate(target.getDate() + 1);
  }

  const pad = (n: number) => String(n).padStart(2, '0');
  const dtStart = `${target.getFullYear()}${pad(target.getMonth() + 1)}${pad(
    target.getDate()
  )}T${pad(hh)}${pad(mm)}00`;
  const endTarget = new Date(target.getTime() + 5 * 60 * 1000);
  const dtEnd = `${endTarget.getFullYear()}${pad(endTarget.getMonth() + 1)}${pad(
    endTarget.getDate()
  )}T${pad(endTarget.getHours())}${pad(endTarget.getMinutes())}00`;

  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//StudyPulse//Alarm//EN',
    'BEGIN:VEVENT',
    `UID:studypulse-alarm-${alarm.id}-${Date.now()}@studypulse.app`,
    `DTSTART:${dtStart}`,
    `DTEND:${dtEnd}`,
    `SUMMARY:${(alarm.name || `StudyPulse Alarm #${alarm.id}`).replace(/\r?\n/g, ' ')}`,
    ...(alarm.repeat === 'daily' ? ['RRULE:FREQ=DAILY'] : []),
    'BEGIN:VALARM',
    'TRIGGER:PT0M',
    'ACTION:AUDIO',
    'DESCRIPTION:StudyPulse Alarm',
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR',
  ];

  const blob = new Blob([lines.join('\r\n')], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `StudyPulse-Alarm-${pad(alarm.id)}.ics`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.setTimeout(() => URL.revokeObjectURL(url), 2000);
}
