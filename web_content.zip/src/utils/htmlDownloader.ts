import { Ebook } from '../types';

export function downloadEbookAsHtml(ebook: Ebook, isPurchasedOrFree: boolean) {
  const dateStr = new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const contentSection = isPurchasedOrFree
    ? `
    <div class="unlocked-badge">
      <span class="badge-icon">✓</span>
      <span>Full Edition Study Material — Authorized Offline Access</span>
    </div>

    <section class="chapter">
      <h2>Chapter 1: Official Exam Blueprint & Subject Strategy</h2>
      <p class="chapter-lead">Targeting ${ebook.targetExam} requires strategic mastery of foundational concepts, high-speed calculation shortcuts, and rigorous mock revision.</p>
      <div class="note-box">
        <strong>Important Exam Note:</strong>
        <p>Always review past 5 years question patterns. SLRC, SLPRB, RRB, and SSC frequently repeat question themes in Assam GK, Indian History, and Quantitative Aptitude.</p>
      </div>
      <h3>Key Formulae & Quick Revision Matrix</h3>
      <table>
        <thead>
          <tr>
            <th>Concept / Topic</th>
            <th>Standard Rule / Formula</th>
            <th>Shortcut Exam Application</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Percentage to Fraction</td>
            <td>P% = P / 100</td>
            <td>16.66% = 1/6, 12.5% = 1/8, 14.28% = 1/7</td>
          </tr>
          <tr>
            <td>Effective Discount Rate</td>
            <td>a + b - (ab / 100)</td>
            <td>Successive 20% + 10% = 30 - 2 = 28% net discount</td>
          </tr>
          <tr>
            <td>Time, Speed & Distance</td>
            <td>Speed = Distance / Time</td>
            <td>Convert km/h to m/s: Multiply by 5/18</td>
          </tr>
          <tr>
            <td>Assam State History Landmark</td>
            <td>1826: Treaty of Yandabo</td>
            <td>Ended Burmese rule; British administration began</td>
          </tr>
        </tbody>
      </table>
    </section>

    <section class="chapter">
      <h2>${ebook.sampleContent.title}</h2>
      <h3 class="subchapter-title">${ebook.sampleContent.chapterName}</h3>
      <div class="content-body">
        <p>${ebook.sampleContent.text}</p>
        <p>In addition to historical chronology, candidates must pay special attention to constitutional safeguards, statutory recruitment procedures, and administrative frameworks. Regular practice with previous year question sets sharpens conceptual clarity and minimizes exam hall hesitation.</p>
      </div>

      <div class="high-yield-card">
        <h4>High-Yield Topic Summary for ${ebook.targetExam}</h4>
        <ul>
          <li><strong>Weightage Analysis:</strong> 25-35% questions directly based on state/national foundational general knowledge.</li>
          <li><strong>Accuracy Focus:</strong> In negative-marking exams (typically -0.50 or -0.33 per wrong answer), elimination strategy is vital.</li>
          <li><strong>Time Allocation:</strong> Aim to complete General Knowledge in under 20 minutes to reserve time for Numerical & Analytical Reasoning.</li>
        </ul>
      </div>

      <h3>Practice MCQs with Detailed Solutions</h3>
      <div class="questions-list">
        ${ebook.sampleContent.sampleQuestions
          .map(
            (q, idx) => `
          <div class="question-item">
            <p class="q-text"><strong>Q${idx + 1}.</strong> ${q.q}</p>
            <div class="q-ans"><strong>Answer:</strong> ${q.a}</div>
            <div class="q-expl"><em>Explanation:</em> ${q.explanation}</div>
          </div>
        `
          )
          .join('')}
      </div>
    </section>

    <section class="chapter">
      <h2>Complete Table of Contents Reference</h2>
      <ul class="toc-list">
        ${ebook.tableOfContents
          .map(
            (item) => `
          <li>
            <span class="toc-num">Chapter ${item.chapterNumber}:</span>
            <span class="toc-title">${item.title}</span>
            <span class="toc-pages">pp. ${item.pages}</span>
          </li>
        `
          )
          .join('')}
      </ul>
    </section>
  `
    : `
    <div class="sample-notice">
      <h3>Sample Preview Mode</h3>
      <p>This is an authorized sample preview from NEXA EXAM BOOKS. To read the complete 400+ pages edition with all practice papers, please purchase the book from the NEXA EXAM BOOKS app.</p>
    </div>

    <section class="chapter">
      <h2>${ebook.sampleContent.title}</h2>
      <h3 class="subchapter-title">${ebook.sampleContent.chapterName}</h3>
      <p>${ebook.sampleContent.text}</p>
      <h3>Sample Practice Questions</h3>
      <div class="questions-list">
        ${ebook.sampleContent.sampleQuestions
          .map(
            (q, idx) => `
          <div class="question-item">
            <p class="q-text"><strong>Q${idx + 1}.</strong> ${q.q}</p>
            <div class="q-ans"><strong>Answer:</strong> ${q.a}</div>
            <div class="q-expl"><em>Explanation:</em> ${q.explanation}</div>
          </div>
        `
          )
          .join('')}
      </div>
    </section>
  `;

  const htmlDocument = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ebook.title} - NEXA EXAM BOOKS Offline Study Edition</title>
  <style>
    :root {
      --navy: #0B192C;
      --navy-light: #1E3E62;
      --yellow: #F59E0B;
      --text: #1E293B;
      --bg: #F8FAFC;
      --card-bg: #FFFFFF;
      --border: #E2E8F0;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      line-height: 1.65;
      color: var(--text);
      background: var(--bg);
      padding: 0 0 60px 0;
    }
    .header-bar {
      background: var(--navy);
      color: white;
      padding: 24px 20px;
      border-bottom: 4px solid var(--yellow);
    }
    .container {
      max-width: 860px;
      margin: 0 auto;
      padding: 24px 20px;
    }
    .app-brand {
      display: flex;
      align-items: center;
      gap: 12px;
      font-weight: 800;
      font-size: 1.25rem;
      letter-spacing: 0.05em;
    }
    .brand-badge {
      background: var(--yellow);
      color: #000;
      font-size: 0.75rem;
      font-weight: 800;
      padding: 2px 8px;
      border-radius: 4px;
    }
    .book-header {
      background: var(--card-bg);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 28px;
      margin-top: -20px;
      box-shadow: 0 10px 25px -5px rgba(0,0,0,0.06);
    }
    .book-title {
      font-size: 1.65rem;
      font-weight: 800;
      color: var(--navy);
      line-height: 1.3;
      margin-bottom: 8px;
    }
    .book-subtitle {
      color: #64748B;
      font-size: 1rem;
      margin-bottom: 16px;
    }
    .meta-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
      gap: 12px;
      margin-top: 16px;
      padding-top: 16px;
      border-top: 1px dashed var(--border);
      font-size: 0.88rem;
    }
    .meta-item strong { display: block; color: var(--navy); font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; }
    .unlocked-badge {
      background: #ECFDF5;
      border: 1px solid #A7F3D0;
      color: #065F46;
      padding: 12px 16px;
      border-radius: 8px;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 24px 0;
    }
    .sample-notice {
      background: #FEF3C7;
      border: 1px solid #FCD34D;
      color: #92400E;
      padding: 16px;
      border-radius: 8px;
      margin: 24px 0;
    }
    .chapter {
      background: var(--card-bg);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 28px;
      margin-bottom: 24px;
    }
    .chapter h2 {
      color: var(--navy);
      font-size: 1.35rem;
      font-weight: 700;
      margin-bottom: 12px;
      border-bottom: 2px solid #F1F5F9;
      padding-bottom: 8px;
    }
    .subchapter-title {
      color: #2563EB;
      font-size: 1.1rem;
      margin: 12px 0 16px;
    }
    .content-body p {
      margin-bottom: 16px;
      text-align: justify;
    }
    .note-box {
      background: #EFF6FF;
      border-left: 4px solid #3B82F6;
      padding: 12px 16px;
      border-radius: 0 8px 8px 0;
      margin: 16px 0;
    }
    .high-yield-card {
      background: #FFFBEB;
      border: 1px solid #FDE68A;
      border-radius: 8px;
      padding: 16px;
      margin: 20px 0;
    }
    .high-yield-card h4 {
      color: #92400E;
      margin-bottom: 8px;
    }
    .high-yield-card ul {
      padding-left: 20px;
    }
    .high-yield-card li {
      margin-bottom: 6px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 16px 0;
      font-size: 0.9rem;
    }
    th, td {
      border: 1px solid var(--border);
      padding: 10px 12px;
      text-align: left;
    }
    th {
      background: #F1F5F9;
      color: var(--navy);
      font-weight: 700;
    }
    .questions-list {
      display: flex;
      flex-direction: column;
      gap: 16px;
      margin-top: 16px;
    }
    .question-item {
      background: #F8FAFC;
      border: 1px solid #E2E8F0;
      border-radius: 8px;
      padding: 16px;
    }
    .q-text {
      color: var(--navy);
      font-size: 0.98rem;
      margin-bottom: 8px;
    }
    .q-ans {
      color: #059669;
      font-weight: 600;
      margin-bottom: 4px;
      font-size: 0.92rem;
    }
    .q-expl {
      color: #64748B;
      font-size: 0.88rem;
    }
    .toc-list {
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .toc-list li {
      display: flex;
      justify-content: space-between;
      padding: 8px 12px;
      background: #F8FAFC;
      border-radius: 6px;
      font-size: 0.92rem;
    }
    .toc-num { font-weight: 700; color: var(--navy-light); width: 110px; }
    .toc-title { flex: 1; color: var(--text); }
    .toc-pages { color: #64748B; font-size: 0.85rem; }
    .footer-bar {
      margin-top: 40px;
      text-align: center;
      color: #64748B;
      font-size: 0.85rem;
      border-top: 1px solid var(--border);
      padding-top: 20px;
    }
    .print-btn {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: var(--yellow);
      color: #000;
      border: none;
      padding: 12px 20px;
      border-radius: 30px;
      font-weight: 700;
      box-shadow: 0 4px 15px rgba(0,0,0,0.2);
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 8px;
      z-index: 100;
    }
    @media print {
      .print-btn, .header-bar .brand-badge { display: none; }
      body { background: white; }
      .book-header, .chapter { box-shadow: none; border: 1px solid #ccc; page-break-inside: avoid; }
    }
  </style>
</head>
<body>
  <div class="header-bar">
    <div class="container" style="padding-top: 0; padding-bottom: 0;">
      <div class="app-brand">
        <span>NEXA EXAM BOOKS</span>
        <span class="brand-badge">OFFLINE STUDY EDITION</span>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="book-header">
      <h1 class="book-title">${ebook.title}</h1>
      <p class="book-subtitle">${ebook.subtitle}</p>
      <div class="meta-grid">
        <div class="meta-item"><strong>Target Exam</strong>${ebook.targetExam}</div>
        <div class="meta-item"><strong>Language</strong>${ebook.language}</div>
        <div class="meta-item"><strong>Author/Publisher</strong>${ebook.publisher}</div>
        <div class="meta-item"><strong>Pages</strong>${ebook.pageCount} Pages</div>
        <div class="meta-item"><strong>Downloaded On</strong>${dateStr}</div>
      </div>
    </div>

    ${contentSection}

    <div class="footer-bar">
      <p>© 2026 NEXA EXAM BOOKS. All Rights Reserved. Offline Study Material for personal educational use.</p>
      <p>For questions, exam syllabus updates & live mock tests, visit <strong>NEXA EXAM BOOKS</strong>.</p>
    </div>
  </div>

  <button class="print-btn" onclick="window.print()">
    🖨️ Print / Save to PDF
  </button>
</body>
</html>`;

  const blob = new Blob([htmlDocument], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  const sanitizedTitle = ebook.title.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 40);
  link.download = `NEXA_${sanitizedTitle}_Offline.html`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
