import {
  Account,
  DebtRecord,
  SubscriptionRecord,
  TransactionRecord,
} from '../types/finance';

export type LedgerSourceGroup = 'INCOME' | 'EXPENSE' | 'DEBT' | 'BILL';

export interface UnifiedLedgerItem {
  id: string;
  sourceGroup: LedgerSourceGroup;
  sourceKind:
    | 'TRANSACTION'
    | 'DEBT_ORIGIN'
    | 'DEBT_REPAYMENT'
    | 'SUBSCRIPTION_PAYMENT'
    | 'SUBSCRIPTION_BILL';
  titleBn: string;
  typeLabelBn: string;
  categoryBn: string;
  amountPaisa: number;
  date: string;
  accountId?: string;
  accountNameBn: string;
  flowDirection: 'IN' | 'OUT' | 'NEUTRAL';
  rawTransaction?: TransactionRecord;
  rawDebtId?: string;
  rawRepaymentId?: string;
  rawSubscriptionId?: string;
}

export function buildUnifiedLedger(params: {
  transactions: TransactionRecord[];
  debts: DebtRecord[];
  subscriptions: SubscriptionRecord[];
  accounts: Account[];
}): UnifiedLedgerItem[] {
  const { transactions, debts, subscriptions, accounts } = params;
  const items: UnifiedLedgerItem[] = [];
  const linkedTxIdsFromSubPayments = new Set<string>();

  const getAccountName = (accId?: string) => {
    if (!accId) return 'বাকির খাতা';
    return accounts.find((a) => a.id === accId)?.nameBn ?? 'নগদ ক্যাশ';
  };

  // Track which transactions came from subscription payments so we label them as নিয়মিত বিল without duplicating
  for (const sub of subscriptions) {
    for (const pay of sub.paymentHistory) {
      if (pay.transactionId) {
        linkedTxIdsFromSubPayments.add(pay.transactionId);
      }
    }
  }

  // 1. Direct Transactions (আয় / ব্যয় / বিল পরিশোধ)
  for (const tx of transactions) {
    if (tx.type === 'TRANSFER') continue;
    const isInflow = tx.type === 'INCOME' || tx.type === 'SALE';
    const isSubLinked =
      Boolean(tx.linkedSubscriptionId) || linkedTxIdsFromSubPayments.has(tx.id);
    const accName = getAccountName(tx.accountId);

    items.push({
      id: `tx-${tx.id}`,
      sourceGroup: isSubLinked ? 'BILL' : isInflow ? 'INCOME' : 'EXPENSE',
      sourceKind: 'TRANSACTION',
      titleBn: tx.note || tx.category,
      typeLabelBn: isSubLinked
        ? `নিয়মিত বিল পরিশোধ (মাধ্যম: ${accName})`
        : isInflow
        ? 'আয়'
        : 'ব্যয়',
      categoryBn: tx.category,
      amountPaisa: tx.amountPaisa,
      date: tx.date,
      accountId: tx.accountId,
      accountNameBn: accName,
      flowDirection: isInflow ? 'IN' : 'OUT',
      rawTransaction: tx,
    });
  }

  // 2. Debts (ধার দেওয়া, ধার নেওয়া, বাকিতে বিক্রয় পাওনা, বাকিতে ক্রয় দেনা) & Repayments (কিস্তি)
  for (const debt of debts) {
    const dirLabel =
      debt.direction === 'LENT'
        ? 'ধার দেওয়া'
        : debt.direction === 'RECEIVABLE_OTHER'
        ? 'বাকিতে বিক্রয় পাওনা'
        : debt.direction === 'BORROWED'
        ? 'ধার নেওয়া'
        : 'বাকিতে ক্রয় দেনা';

    // Cash flow direction of debt origination
    const originFlow: 'IN' | 'OUT' | 'NEUTRAL' =
      debt.direction === 'BORROWED'
        ? 'IN'
        : debt.direction === 'LENT'
        ? 'OUT'
        : debt.direction === 'RECEIVABLE_OTHER'
        ? 'IN'
        : 'OUT';

    items.push({
      id: `debt-origin-${debt.id}`,
      sourceGroup: 'DEBT',
      sourceKind: 'DEBT_ORIGIN',
      titleBn: `${debt.contactName}${debt.notes ? ` — ${debt.notes}` : ''}`,
      typeLabelBn: `দেনা-পাওনা (${dirLabel})`,
      categoryBn: dirLabel,
      amountPaisa: debt.principalPaisa,
      date: debt.date,
      accountId: debt.accountId,
      accountNameBn: getAccountName(debt.accountId),
      flowDirection: originFlow,
      rawDebtId: debt.id,
    });

    // Repayments under this debt
    for (const rep of debt.repayments) {
      const isReceivingBack =
        debt.direction === 'LENT' || debt.direction === 'RECEIVABLE_OTHER';
      const repLabel = isReceivingBack ? 'পাওনা আদায় (কিস্তি)' : 'দেনা পরিশোধ (কিস্তি)';

      items.push({
        id: `debt-rep-${rep.id}`,
        sourceGroup: 'DEBT',
        sourceKind: 'DEBT_REPAYMENT',
        titleBn: `${debt.contactName} — ${rep.note || repLabel}`,
        typeLabelBn: repLabel,
        categoryBn: 'কিস্তি জমা',
        amountPaisa: rep.amountPaisa,
        date: rep.date,
        accountId: rep.accountId ?? debt.accountId,
        accountNameBn: getAccountName(rep.accountId ?? debt.accountId),
        flowDirection: isReceivingBack ? 'IN' : 'OUT',
        rawDebtId: debt.id,
        rawRepaymentId: rep.id,
      });
    }
  }

  // 3. Subscription Payments that were NOT already recorded as a linked Transaction, plus active un-paid bills
  for (const sub of subscriptions) {
    for (const pay of sub.paymentHistory) {
      if (
        pay.transactionId &&
        transactions.some((t) => t.id === pay.transactionId)
      ) {
        continue; // Already included in step 1 with sourceGroup = 'BILL'
      }

      const accName = getAccountName(pay.accountId ?? sub.defaultAccountId);
      items.push({
        id: `sub-pay-${pay.id}`,
        sourceGroup: 'BILL',
        sourceKind: 'SUBSCRIPTION_PAYMENT',
        titleBn: `${sub.nameBn} — ${pay.note || `বিল পরিশোধ (${accName})`}`,
        typeLabelBn: `নিয়মিত বিল পরিশোধ (মাধ্যম: ${accName})`,
        categoryBn: sub.category || 'নিয়মিত বিল',
        amountPaisa: pay.amountPaisa,
        date: pay.paidDate,
        accountId: pay.accountId ?? sub.defaultAccountId,
        accountNameBn: accName,
        flowDirection: 'OUT',
        rawSubscriptionId: sub.id,
      });
    }

    // If a subscription has no payment history yet, also show its scheduled bill entry so the user sees it in লেনদেন
    if (sub.paymentHistory.length === 0) {
      items.push({
        id: `sub-bill-${sub.id}`,
        sourceGroup: 'BILL',
        sourceKind: 'SUBSCRIPTION_BILL',
        titleBn: `${sub.nameBn}${sub.notes ? ` — ${sub.notes}` : ''}`,
        typeLabelBn: 'নিয়মিত বিল (নির্ধারিত)',
        categoryBn: sub.category || 'নিয়মিত বিল',
        amountPaisa: sub.amountPaisa,
        date: sub.nextDueDate,
        accountId: sub.defaultAccountId,
        accountNameBn: getAccountName(sub.defaultAccountId),
        flowDirection: 'OUT',
        rawSubscriptionId: sub.id,
      });
    }
  }

  return items.sort((a, b) => b.date.localeCompare(a.date));
}
