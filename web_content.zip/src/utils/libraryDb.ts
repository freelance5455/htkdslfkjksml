import { openDB, type DBSchema, type IDBPDatabase } from 'idb';
import type {
  AppThemeSettings,
  ComicEntry,
  LibraryFolder,
  ReaderSettings,
  ReadStatus,
  TocBookmark,
} from '../types/comic';

interface KomaDBSchema extends DBSchema {
  folders: {
    key: string;
    value: LibraryFolder;
  };
  comics: {
    key: string;
    value: ComicEntry;
    indexes: { 'by-folder': string; 'by-lastRead': number };
  };
  offlineArchives: {
    key: string;
    value: {
      id: string;
      blob: Blob;
      fileName: string;
      cachedAt: number;
    };
  };
  preferences: {
    key: string;
    value: unknown;
  };
}

export const DEFAULT_READER_SETTINGS: ReaderSettings = {
  readingMode: 'vertical',
  orientationMode: 'free',
  pageTransition: 'slide',
  fitMode: 'fit-width',
  customZoom: 100,
  marginLeft: 6,
  marginRight: 6,
  marginLinked: true,
  pageGap: 8,
  readerBg: '#0b0b0d',
  hardwareAccel: true,
  sliceLongStrips: true,
  showPageNumberHud: true,
  keepScreenAwake: false,
};

export const DEFAULT_THEME_SETTINGS: AppThemeSettings = {
  colorMode: 'dark',
  accentColor: '#e11d48',
  gridDensity: 'comfortable',
};

let dbPromise: Promise<IDBPDatabase<KomaDBSchema>> | null = null;

function getDb(): Promise<IDBPDatabase<KomaDBSchema>> {
  if (!dbPromise) {
    dbPromise = openDB<KomaDBSchema>('koma-reader-db', 1, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('folders')) {
          db.createObjectStore('folders', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('comics')) {
          const comicStore = db.createObjectStore('comics', { keyPath: 'id' });
          comicStore.createIndex('by-folder', 'folderId');
          comicStore.createIndex('by-lastRead', 'lastReadAt');
        }
        if (!db.objectStoreNames.contains('offlineArchives')) {
          db.createObjectStore('offlineArchives', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('preferences')) {
          db.createObjectStore('preferences');
        }
      },
    });
  }
  return dbPromise;
}

export async function loadFolders(): Promise<LibraryFolder[]> {
  const db = await getDb();
  return await db.getAll('folders');
}

export async function saveFolder(folder: LibraryFolder): Promise<void> {
  const db = await getDb();
  await db.put('folders', folder);
}

export async function deleteFolderAndComics(folderId: string): Promise<void> {
  const db = await getDb();
  const comics = await db.getAllFromIndex('comics', 'by-folder', folderId);
  const tx = db.transaction(['folders', 'comics', 'offlineArchives'], 'readwrite');
  await tx.objectStore('folders').delete(folderId);
  for (const c of comics) {
    await tx.objectStore('comics').delete(c.id);
    await tx.objectStore('offlineArchives').delete(c.id);
  }
  await tx.done;
}

export async function loadComics(): Promise<ComicEntry[]> {
  const db = await getDb();
  return await db.getAll('comics');
}

export async function saveComic(comic: ComicEntry): Promise<void> {
  const db = await getDb();
  await db.put('comics', comic);
}

export async function deleteComic(comicId: string): Promise<void> {
  const db = await getDb();
  const tx = db.transaction(['comics', 'offlineArchives'], 'readwrite');
  await tx.objectStore('comics').delete(comicId);
  await tx.objectStore('offlineArchives').delete(comicId);
  await tx.done;
}

export function computeComicSyncKey(comic: Pick<ComicEntry, 'fileName' | 'pageCount' | 'syncKey'>): string {
  if (comic.syncKey) return comic.syncKey;
  return `${comic.fileName.trim().toLowerCase()}::${comic.pageCount}`;
}

export async function updateComicProgress(
  comicId: string,
  progress: {
    currentPage: number;
    scrollProgress: number;
    scrollOffsetY?: number;
    scrollRatio?: number;
    readStatus?: ReadStatus;
  },
): Promise<void> {
  const db = await getDb();
  const existing = await db.get('comics', comicId);
  if (!existing) return;
  const now = Date.now();
  existing.syncKey = computeComicSyncKey(existing);
  existing.currentPage = progress.currentPage;
  existing.scrollProgress = progress.scrollProgress;
  if (progress.scrollOffsetY !== undefined) existing.scrollOffsetY = progress.scrollOffsetY;
  if (progress.scrollRatio !== undefined) existing.scrollRatio = progress.scrollRatio;
  if (progress.readStatus) {
    existing.readStatus = progress.readStatus;
  } else {
    const isCompleted =
      existing.pageCount > 0 &&
      (progress.currentPage >= existing.pageCount - 1 || progress.scrollProgress >= 0.97);
    existing.readStatus = isCompleted
      ? 'completed'
      : progress.currentPage > 0 || progress.scrollProgress > 0.01
        ? 'reading'
        : existing.readStatus || 'reading';
  }
  existing.lastReadAt = now;
  existing.updatedAt = now;
  existing.syncDirty = true;
  await db.put('comics', existing);
}

export async function updateComicReadStatus(
  comicId: string,
  readStatus: ReadStatus,
): Promise<void> {
  const db = await getDb();
  const existing = await db.get('comics', comicId);
  if (!existing) return;
  const now = Date.now();
  existing.syncKey = computeComicSyncKey(existing);
  existing.readStatus = readStatus;
  if (readStatus === 'unread') {
    existing.currentPage = 0;
    existing.scrollProgress = 0;
    existing.scrollOffsetY = 0;
    existing.scrollRatio = 0;
  } else if (readStatus === 'completed' && existing.pageCount > 0) {
    existing.currentPage = existing.pageCount - 1;
    existing.scrollProgress = 1;
    existing.scrollRatio = 1;
  }
  existing.updatedAt = now;
  existing.syncDirty = true;
  await db.put('comics', existing);
}

export async function updateComicUserBookmarks(
  comicId: string,
  userBookmarks: TocBookmark[],
): Promise<void> {
  const db = await getDb();
  const existing = await db.get('comics', comicId);
  if (!existing) return;
  existing.syncKey = computeComicSyncKey(existing);
  existing.userBookmarks = userBookmarks;
  existing.updatedAt = Date.now();
  existing.syncDirty = true;
  await db.put('comics', existing);
}

export async function saveSyncedComicsBatch(updatedComics: ComicEntry[]): Promise<void> {
  const db = await getDb();
  const tx = db.transaction('comics', 'readwrite');
  for (const comic of updatedComics) {
    await tx.store.put(comic);
  }
  await tx.done;
}

export async function saveOfflineArchive(id: string, fileName: string, blob: Blob): Promise<void> {
  const db = await getDb();
  const tx = db.transaction(['offlineArchives', 'comics'], 'readwrite');
  await tx.objectStore('offlineArchives').put({
    id,
    fileName,
    blob,
    cachedAt: Date.now(),
  });
  const comic = await tx.objectStore('comics').get(id);
  if (comic) {
    comic.isOfflineCached = true;
    await tx.objectStore('comics').put(comic);
  }
  await tx.done;
}

export async function removeOfflineArchive(id: string): Promise<void> {
  const db = await getDb();
  const tx = db.transaction(['offlineArchives', 'comics'], 'readwrite');
  await tx.objectStore('offlineArchives').delete(id);
  const comic = await tx.objectStore('comics').get(id);
  if (comic) {
    comic.isOfflineCached = false;
    await tx.objectStore('comics').put(comic);
  }
  await tx.done;
}

export async function getOfflineArchiveBlob(id: string): Promise<Blob | undefined> {
  const db = await getDb();
  const rec = await db.get('offlineArchives', id);
  return rec?.blob;
}

export async function loadReaderSettings(): Promise<ReaderSettings> {
  const db = await getDb();
  const stored = (await db.get('preferences', 'readerSettings')) as Partial<ReaderSettings> | undefined;
  return { ...DEFAULT_READER_SETTINGS, ...(stored || {}) };
}

export async function saveReaderSettings(settings: ReaderSettings): Promise<void> {
  const db = await getDb();
  await db.put('preferences', settings, 'readerSettings');
}

export async function loadThemeSettings(): Promise<AppThemeSettings> {
  const db = await getDb();
  const stored = (await db.get('preferences', 'themeSettings')) as Partial<AppThemeSettings> | undefined;
  return { ...DEFAULT_THEME_SETTINGS, ...(stored || {}) };
}

export async function saveThemeSettings(settings: AppThemeSettings): Promise<void> {
  const db = await getDb();
  await db.put('preferences', settings, 'themeSettings');
}

export async function hasSeededSamples(): Promise<boolean> {
  const db = await getDb();
  return Boolean(await db.get('preferences', 'samplesSeeded'));
}

export async function markSamplesSeeded(): Promise<void> {
  const db = await getDb();
  await db.put('preferences', true, 'samplesSeeded');
}

export async function loadLastSyncTimestamp(): Promise<number | null> {
  const db = await getDb();
  const val = await db.get('preferences', 'lastCloudSyncAt');
  return typeof val === 'number' ? val : null;
}

export async function saveLastSyncTimestamp(ts: number): Promise<void> {
  const db = await getDb();
  await db.put('preferences', ts, 'lastCloudSyncAt');
}
