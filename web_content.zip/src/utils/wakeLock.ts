/**
 * Utility for managing Screen Wake Lock API and Call Screen Persistence
 */

let wakeLockSentinel: WakeLockSentinel | null = null;

export const isWakeLockSupported = (): boolean => {
  return typeof navigator !== 'undefined' && 'wakeLock' in navigator;
};

export const requestScreenWakeLock = async (): Promise<{ success: boolean; message: string }> => {
  if (!isWakeLockSupported()) {
    return {
      success: false,
      message: 'خاصية قفل الشاشة (Wake Lock API) غير مدعومة مباشرة في هذا المتصفح، ولكن تم تفعيل نمط التنشيط المستمر محلياً.',
    };
  }

  try {
    if (wakeLockSentinel && !wakeLockSentinel.released) {
      return { success: true, message: 'الشاشة قيد الإبقاء مضاءة بالفعل.' };
    }

    wakeLockSentinel = await navigator.wakeLock.request('screen');
    
    wakeLockSentinel.addEventListener('release', () => {
      // Released by system or user
    });

    return {
      success: true,
      message: 'تم تفعيل إبقاء الشاشة مضاءة بنجاح عبر النظام.',
    };
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'خطأ غير معروف';
    return {
      success: false,
      message: `تعذر حجز قفل الشاشة: ${errorMsg}. تأكد من عدم تفعيل وضع توفير الطاقة الفائق.`,
    };
  }
};

export const releaseScreenWakeLock = async (): Promise<boolean> => {
  if (wakeLockSentinel) {
    try {
      await wakeLockSentinel.release();
      wakeLockSentinel = null;
      return true;
    } catch {
      wakeLockSentinel = null;
      return false;
    }
  }
  return true;
};

export const isWakeLockActive = (): boolean => {
  return !!wakeLockSentinel && !wakeLockSentinel.released;
};
