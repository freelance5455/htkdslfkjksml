import { ImageClip } from "../types";

export interface FramePreset {
  id: string;
  name: string;
  category: "modern" | "vintage" | "creative" | "office" | "neon" | "artistic";
  categoryLabel: string;
  description: string;
  badgeLabel: string;
  iconSymbol: string;
  borderColor: string;
  bgPreview: string;
  // Rich HTML template for inserting into contentEditable
  getHtml: (content: string, title?: string) => string;
  // Canvas render configuration for 800x480 high-res snapshots
  renderCanvas: (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    text: string,
    title: string,
    categoryName: string,
    fontFamily: string
  ) => void;
}

const RECENT_FRAMES_KEY = "noteflow_recent_frames_v1";

// Helper for drawing rounded rect
function drawRoundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  if (ctx.roundRect) {
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, r);
  } else {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }
}

// Text word wrap helper for canvas
function wrapCanvasText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  startY: number,
  maxW: number,
  lineH: number,
  maxLines: number = 8
) {
  const clean = text.replace(/<[^>]*>?/gm, " ").trim();
  const words = clean.split(/\s+/);
  let line = "";
  let currY = startY;
  let lineCount = 0;

  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + " ";
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxW && n > 0) {
      ctx.fillText(line, x, currY);
      line = words[n] + " ";
      currY += lineH;
      lineCount++;
      if (lineCount >= maxLines) {
        ctx.fillText(line.trim() + "...", x, currY);
        return;
      }
    } else {
      line = testLine;
    }
  }
  if (line.trim() && lineCount < maxLines) {
    ctx.fillText(line.trim(), x, currY);
  }
}

// ============================================================================
// 30 DISTINCT, CRAFTED FRAME PRESETS
// ============================================================================
export const ALL_FRAME_PRESETS: FramePreset[] = [
  // 1. Zümrüt Neon Glow
  {
    id: "frame-teal-neon",
    name: "Zümrüt Işıltısı",
    category: "neon",
    categoryLabel: "Neon & Siber",
    description: "Modern zümrüt yeşili neon parıltılı çift bordür",
    badgeLabel: "✦ ÖNEMLİ VURGU",
    iconSymbol: "💎",
    borderColor: "#0d9488",
    bgPreview: "bg-teal-950 text-teal-300 border-teal-500",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-teal-neon" style="border: 2px solid #0d9488; box-shadow: 0 0 15px rgba(13,148,136,0.3); border-radius: 16px; padding: 18px; margin: 16px 0; background: rgba(13,148,136,0.08);">
        <div style="display:inline-block; font-size: 11px; font-weight: bold; background: #0d9488; color: #ffffff; padding: 3px 10px; border-radius: 8px; margin-bottom: 8px;">✦ ${title || "ZÜMRÜT VURGU"}</div>
        <div style="font-size: 14px; line-height: 1.6; color: inherit;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, "#042f2e");
      grad.addColorStop(1, "#115e59");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 24);
      ctx.fillStyle = "rgba(13, 148, 136, 0.15)";
      ctx.fill();
      ctx.strokeStyle = "#2dd4bf";
      ctx.lineWidth = 3;
      ctx.shadowColor = "#14b8a6";
      ctx.shadowBlur = 15;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Badge
      ctx.fillStyle = "#0d9488";
      drawRoundRect(ctx, 60, 60, 200, 34, 8);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 13px 'Plus Jakarta Sans', sans-serif";
      ctx.fillText("✦ ZÜMRÜT VURGU", 75, 82);

      // Title
      ctx.fillStyle = "#ffffff";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText((title || "Önemli Not Karesi").substring(0, 36), 60, 135);

      // Text
      ctx.fillStyle = "#ccfbf1";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 60, 180, w - 120, 30, 7);

      ctx.fillStyle = "#99f6e4";
      ctx.font = "12px sans-serif";
      ctx.fillText(`Kategori: ${category} • NoteFlow Zümrüt`, 60, h - 55);
    },
  },

  // 2. Polaroid Nostalji
  {
    id: "frame-polaroid",
    name: "Polaroid Nostalji",
    category: "vintage",
    categoryLabel: "Vintage & Nostalji",
    description: "Geniş alt kenarlık ve nostaljik fotoğraf kartı hissi",
    badgeLabel: "📷 POLAROID ANISI",
    iconSymbol: "📷",
    borderColor: "#e2e8f0",
    bgPreview: "bg-stone-100 text-stone-800 border-stone-300",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-polaroid" style="border: 1px solid #cbd5e1; border-radius: 12px; padding: 16px 16px 28px 16px; margin: 16px 0; background: #ffffff; box-shadow: 0 8px 20px rgba(0,0,0,0.12); color: #1e293b;">
        <div style="background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px; padding: 14px; margin-bottom: 12px;">${content}</div>
        <div style="font-family: 'Caveat', cursive; font-size: 18px; font-weight: bold; text-align: center; color: #475569;">~ ${title || "Unutulmaz Bir An"} ~</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#e2e8f0";
      ctx.fillRect(0, 0, w, h);

      // White card
      drawRoundRect(ctx, 40, 30, w - 80, h - 60, 16);
      ctx.fillStyle = "#ffffff";
      ctx.shadowColor = "rgba(0,0,0,0.2)";
      ctx.shadowBlur = 20;
      ctx.shadowOffsetY = 8;
      ctx.fill();
      ctx.shadowBlur = 0;

      // Inner Photo Area
      drawRoundRect(ctx, 65, 55, w - 130, h - 170, 8);
      ctx.fillStyle = "#1e293b";
      ctx.fill();

      // Title & Text
      ctx.fillStyle = "#f8fafc";
      ctx.font = `bold 20px '${font}', sans-serif`;
      ctx.fillText((title || "Polaroid Notu").substring(0, 34), 90, 100);

      ctx.fillStyle = "#e2e8f0";
      ctx.font = `17px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 90, 140, w - 180, 28, 6);

      // Bottom Handwritten Label
      ctx.fillStyle = "#334155";
      ctx.font = "bold 24px 'Caveat', cursive, sans-serif";
      ctx.fillText(`“${title || "Hatıra & Not"}”`, w / 2 - 80, h - 65);
    },
  },

  // 3. Antik Parşömen
  {
    id: "frame-parchment",
    name: "Antik Parşömen",
    category: "vintage",
    categoryLabel: "Vintage & Nostalji",
    description: "Eski el yazması parşömen ve kahverengi antik çerçeve",
    badgeLabel: "📜 KADİM METİN",
    iconSymbol: "📜",
    borderColor: "#b45309",
    bgPreview: "bg-amber-100 text-amber-950 border-amber-600",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-parchment" style="border: 3px double #b45309; border-radius: 14px; padding: 18px; margin: 16px 0; background: #fef3c7; color: #451a03; box-shadow: inset 0 0 20px rgba(180,83,9,0.15);">
        <div style="font-family: 'Merriweather', serif; font-weight: bold; border-bottom: 1px solid #d97706; padding-bottom: 4px; margin-bottom: 8px; font-size: 15px;">📜 ${title || "Kadim Not"}</div>
        <div style="font-family: 'Merriweather', serif; font-size: 14px; line-height: 1.7;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      const grad = ctx.createRadialGradient(w / 2, h / 2, 50, w / 2, h / 2, 400);
      grad.addColorStop(0, "#fef3c7");
      grad.addColorStop(1, "#d97706");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Antique Border
      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 12);
      ctx.strokeStyle = "#78350f";
      ctx.lineWidth = 4;
      ctx.stroke();

      drawRoundRect(ctx, 42, 42, w - 84, h - 84, 8);
      ctx.strokeStyle = "#b45309";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Title
      ctx.fillStyle = "#451a03";
      ctx.font = "bold 22px 'Merriweather', serif";
      ctx.fillText(`📜 ${title || "Kadim El Yazması"}`, 65, 95);

      // Body text
      ctx.font = "17px 'Merriweather', serif";
      wrapCanvasText(ctx, text, 65, 145, w - 130, 29, 7);

      ctx.fillStyle = "#78350f";
      ctx.font = "italic 13px 'Merriweather', serif";
      ctx.fillText(`~ ${category} Arşivi ~`, w - 220, h - 55);
    },
  },

  // 4. Sibernetik Matris (Cyberpunk Neon)
  {
    id: "frame-cyberpunk",
    name: "Sibernetik Matris",
    category: "neon",
    categoryLabel: "Neon & Siber",
    description: "Koyu mor ve elektrik mavisi cyberpunk kod kutusu",
    badgeLabel: "⚡ SYS://CYBER_NOTE",
    iconSymbol: "⚡",
    borderColor: "#06b6d4",
    bgPreview: "bg-slate-950 text-cyan-400 border-cyan-500",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-cyberpunk" style="border: 2px solid #06b6d4; border-radius: 10px; padding: 16px; margin: 16px 0; background: #090d16; color: #38bdf8; box-shadow: 0 0 16px rgba(6,182,212,0.4); font-family: 'JetBrains Mono', monospace;">
        <div style="display:flex; justify-content:space-between; border-bottom: 1px solid #0891b2; padding-bottom: 6px; margin-bottom: 10px; font-size: 11px; font-weight: bold; color: #a5f3fc;">
          <span>[SYSTEM NODE: ${title || "EXEC"}]</span>
          <span>⚡ ONLINE</span>
        </div>
        <div style="font-size: 13px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#030712";
      ctx.fillRect(0, 0, w, h);

      // Neon frame
      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 12);
      ctx.fillStyle = "#0b1329";
      ctx.fill();
      ctx.strokeStyle = "#06b6d4";
      ctx.lineWidth = 3;
      ctx.shadowColor = "#38bdf8";
      ctx.shadowBlur = 16;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Header bar
      ctx.fillStyle = "#0891b2";
      ctx.fillRect(55, 55, w - 110, 36);

      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 13px 'JetBrains Mono', monospace";
      ctx.fillText(`⚡ SYSTEM NODE: ${title || "TERMINAL_RECORD"}`, 70, 78);
      ctx.fillText("STATUS: ACTIVE", w - 210, 78);

      // Code text
      ctx.fillStyle = "#38bdf8";
      ctx.font = "16px 'JetBrains Mono', monospace";
      wrapCanvasText(ctx, text, 65, 135, w - 130, 27, 8);

      ctx.fillStyle = "#06b6d4";
      ctx.font = "11px 'JetBrains Mono', monospace";
      ctx.fillText(`ID#${Date.now().toString(16)} // ENCRYPTED NODE`, 65, h - 55);
    },
  },

  // 5. Pastel Yapışkan Not (Post-It)
  {
    id: "frame-postit",
    name: "Pastel Post-It",
    category: "creative",
    categoryLabel: "Yaratıcı & Renkli",
    description: "Sarı yapışkan not kağıdı ve iğneli raptiye görünümü",
    badgeLabel: "📌 HATIRLATICI",
    iconSymbol: "📌",
    borderColor: "#f59e0b",
    bgPreview: "bg-yellow-200 text-yellow-950 border-yellow-400",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-postit" style="background: #fef08a; border-left: 6px solid #eab308; border-radius: 8px 16px 16px 8px; padding: 16px; margin: 16px 0; color: #713f12; box-shadow: 2px 6px 15px rgba(0,0,0,0.08); transform: rotate(-0.5deg);">
        <div style="font-weight: bold; font-size: 14px; margin-bottom: 6px; color: #854d0e;">📌 ${title || "Yapılacak / Önemli"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#f1f5f9";
      ctx.fillRect(0, 0, w, h);

      // Yellow note with shadow
      drawRoundRect(ctx, 45, 35, w - 90, h - 70, 16);
      ctx.fillStyle = "#fef08a";
      ctx.shadowColor = "rgba(0,0,0,0.15)";
      ctx.shadowBlur = 18;
      ctx.shadowOffsetY = 6;
      ctx.fill();
      ctx.shadowBlur = 0;

      // Pin
      ctx.fillStyle = "#ef4444";
      ctx.beginPath();
      ctx.arc(w / 2, 55, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#b91c1c";
      ctx.beginPath();
      ctx.arc(w / 2 - 2, 53, 4, 0, Math.PI * 2);
      ctx.fill();

      // Title
      ctx.fillStyle = "#713f12";
      ctx.font = "bold 22px 'Caveat', cursive, sans-serif";
      ctx.fillText(`📌 ${title || "Önemli Not"}`, 75, 110);

      // Text
      ctx.font = "19px 'Caveat', cursive, sans-serif";
      wrapCanvasText(ctx, text, 75, 150, w - 150, 28, 8);
    },
  },

  // 6. Resmi Sertifika (Royal Certificate)
  {
    id: "frame-certificate",
    name: "Resmi Sertifika",
    category: "office",
    categoryLabel: "Ofis & Kurumsal",
    description: "Altın varaklı çift bordür ve mühür amblemi",
    badgeLabel: "🎖️ ONAYLI BELGE",
    iconSymbol: "🎖️",
    borderColor: "#d97706",
    bgPreview: "bg-amber-50 text-slate-900 border-amber-500",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-certificate" style="border: 3px double #d97706; border-radius: 12px; padding: 20px; margin: 16px 0; background: #fffbeb; color: #1e293b; box-shadow: 0 4px 16px rgba(217,119,6,0.15); text-align: center;">
        <div style="font-size: 11px; font-weight: bold; letter-spacing: 2px; color: #b45309; text-transform: uppercase;">✦ RESMİ KAYIT / PROTOKOL ✦</div>
        <h4 style="font-family: 'Playfair Display', serif; font-size: 18px; font-weight: bold; margin: 6px 0 10px 0; color: #78350f;">${title || "Sertifikalı Karar"}</h4>
        <div style="font-size: 14px; line-height: 1.6; text-align: left; background: #ffffff; padding: 12px; border-radius: 8px; border: 1px solid #fde68a;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#fffbeb";
      ctx.fillRect(0, 0, w, h);

      // Double gold borders
      drawRoundRect(ctx, 30, 30, w - 60, h - 60, 14);
      ctx.strokeStyle = "#d97706";
      ctx.lineWidth = 4;
      ctx.stroke();

      drawRoundRect(ctx, 38, 38, w - 76, h - 76, 10);
      ctx.strokeStyle = "#f59e0b";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Seal Ribbon
      ctx.fillStyle = "#b45309";
      ctx.font = "bold 13px 'Playfair Display', serif";
      ctx.fillText("✦ NOTEFLOW RESMİ SERTİFİKASI ✦", w / 2 - 130, 75);

      ctx.fillStyle = "#78350f";
      ctx.font = "bold 24px 'Playfair Display', serif";
      ctx.fillText((title || "Onaylı Belge Notu").substring(0, 34), 70, 125);

      ctx.fillStyle = "#1e293b";
      ctx.font = "17px 'Playfair Display', serif";
      wrapCanvasText(ctx, text, 70, 170, w - 140, 28, 7);

      // Gold seal badge at bottom right
      ctx.fillStyle = "#d97706";
      ctx.beginPath();
      ctx.arc(w - 90, h - 80, 24, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 18px sans-serif";
      ctx.fillText("★", w - 97, h - 74);
    },
  },

  // 7. Minimalist Arduvaz Kart (Minimal Slate)
  {
    id: "frame-minimal-slate",
    name: "Minimalist Arduvaz",
    category: "modern",
    categoryLabel: "Modern & Şık",
    description: "Temiz 1px ayrım çizgisi, nötr gri ve ferah tipografi",
    badgeLabel: "● GENEL NOT",
    iconSymbol: "◽",
    borderColor: "#64748b",
    bgPreview: "bg-slate-100 text-slate-800 border-slate-300",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-minimal-slate" style="border: 1px solid #cbd5e1; border-radius: 14px; padding: 16px; margin: 16px 0; background: #f8fafc; color: #1e293b; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
        <div style="font-size: 12px; font-weight: 700; color: #475569; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px;">● ${title || "Not Bloğu"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#f8fafc";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 40, 40, w - 80, h - 80, 16);
      ctx.fillStyle = "#ffffff";
      ctx.shadowColor = "rgba(0,0,0,0.06)";
      ctx.shadowBlur = 14;
      ctx.fill();
      ctx.strokeStyle = "#e2e8f0";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.shadowBlur = 0;

      ctx.fillStyle = "#475569";
      ctx.font = "bold 13px 'Plus Jakarta Sans', sans-serif";
      ctx.fillText(`● ${title || "MİNİMAL KART"}`, 70, 85);

      ctx.fillStyle = "#0f172a";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 70, 135, w - 140, 28, 8);
    },
  },

  // 8. Kareli Matematik Defteri (Grid Notebook)
  {
    id: "frame-grid-notebook",
    name: "Kareli Defter",
    category: "creative",
    categoryLabel: "Yaratıcı & Renkli",
    description: "Mavi kareli defter ızgarası ve sol kırmızı marjin çizgisi",
    badgeLabel: "📐 HESAP & FORMÜL",
    iconSymbol: "📐",
    borderColor: "#3b82f6",
    bgPreview: "bg-blue-50 text-blue-900 border-blue-300",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-grid-notebook" style="border: 1px solid #bfdbfe; border-left: 5px solid #ef4444; border-radius: 10px; padding: 16px; margin: 16px 0; background: #f0f9ff; background-image: linear-gradient(#e0f2fe 1px, transparent 1px), linear-gradient(90deg, #e0f2fe 1px, transparent 1px); background-size: 16px 16px; color: #1e3a8a;">
        <div style="font-weight: bold; font-size: 13px; color: #1d4ed8; margin-bottom: 6px;">📐 ${title || "Matematik & Hesap"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#f0f9ff";
      ctx.fillRect(0, 0, w, h);

      // Grid lines
      ctx.strokeStyle = "#e0f2fe";
      ctx.lineWidth = 1;
      for (let x = 0; x < w; x += 20) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += 20) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Red Margin Line
      ctx.strokeStyle = "#ef4444";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(80, 0);
      ctx.lineTo(80, h);
      ctx.stroke();

      // Title & Text
      ctx.fillStyle = "#1e3a8a";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText(`📐 ${title || "Hesap / Formül Karesi"}`, 105, 75);

      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 105, 125, w - 150, 28, 8);
    },
  },

  // 9. Çizgili Mektup Kağıdı (Lined Letter)
  {
    id: "frame-lined-letter",
    name: "Çizgili Mektup",
    category: "vintage",
    categoryLabel: "Vintage & Nostalji",
    description: "Klasik defter çizgileri ve sıcak nostaljik mektup hissi",
    badgeLabel: "✉️ MEKTUP NOTU",
    iconSymbol: "✉️",
    borderColor: "#a8a29e",
    bgPreview: "bg-stone-50 text-stone-900 border-stone-400",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-lined-letter" style="border: 1px solid #d6d3d1; border-radius: 12px; padding: 18px; margin: 16px 0; background: #fafaf9; background-image: repeating-linear-gradient(transparent, transparent 27px, #e7e5e4 28px); color: #292524; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
        <div style="font-family: 'Merriweather', serif; font-weight: bold; font-size: 14px; margin-bottom: 8px; color: #44403c;">✉️ ${title || "Sevgili Günlük"}</div>
        <div style="font-family: 'Merriweather', serif; font-size: 14px; line-height: 28px;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#fafaf9";
      ctx.fillRect(0, 0, w, h);

      // Lines
      ctx.strokeStyle = "#e7e5e4";
      ctx.lineWidth = 1;
      for (let y = 80; y < h - 40; y += 30) {
        ctx.beginPath();
        ctx.moveTo(50, y);
        ctx.lineTo(w - 50, y);
        ctx.stroke();
      }

      ctx.fillStyle = "#44403c";
      ctx.font = "bold 22px 'Merriweather', serif";
      ctx.fillText(`✉️ ${title || "Mektup Kaydı"}`, 60, 60);

      ctx.font = "16px 'Merriweather', serif";
      wrapCanvasText(ctx, text, 60, 105, w - 120, 30, 8);
    },
  },

  // 10. Geliştirici Terminali (Dev Terminal)
  {
    id: "frame-dev-terminal",
    name: "Geliştirici Terminali",
    category: "modern",
    categoryLabel: "Modern & Şık",
    description: "macOS pencereli karanlık kod ve komut konsolu",
    badgeLabel: "💻 BASH // KOD",
    iconSymbol: "💻",
    borderColor: "#475569",
    bgPreview: "bg-slate-900 text-emerald-400 border-slate-700",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-dev-terminal" style="border: 1px solid #334155; border-radius: 12px; margin: 16px 0; background: #0f172a; color: #10b981; font-family: 'JetBrains Mono', monospace; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.3);">
        <div style="background: #1e293b; padding: 8px 12px; display: flex; align-items: center; gap: 6px; border-bottom: 1px solid #334155;">
          <span style="width: 10px; height: 10px; border-radius: 50%; background: #ef4444; display: inline-block;"></span>
          <span style="width: 10px; height: 10px; border-radius: 50%; background: #f59e0b; display: inline-block;"></span>
          <span style="width: 10px; height: 10px; border-radius: 50%; background: #10b981; display: inline-block;"></span>
          <span style="font-size: 11px; color: #94a3b8; margin-left: 8px;">bash — ${title || "code-snippet.ts"}</span>
        </div>
        <div style="padding: 14px; font-size: 13px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#020617";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 30, w - 70, h - 60, 14);
      ctx.fillStyle = "#0f172a";
      ctx.fill();
      ctx.strokeStyle = "#334155";
      ctx.lineWidth = 2;
      ctx.stroke();

      // Top bar
      ctx.fillStyle = "#1e293b";
      drawRoundRect(ctx, 35, 30, w - 70, 38, 14);
      ctx.fill();
      ctx.fillRect(35, 54, w - 70, 14); // square bottom

      // Dots
      ctx.fillStyle = "#ef4444";
      ctx.beginPath();
      ctx.arc(60, 49, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#f59e0b";
      ctx.beginPath();
      ctx.arc(76, 49, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#10b981";
      ctx.beginPath();
      ctx.arc(92, 49, 5, 0, Math.PI * 2);
      ctx.fill();

      // Title
      ctx.fillStyle = "#94a3b8";
      ctx.font = "12px 'JetBrains Mono', monospace";
      ctx.fillText(`bash ~ ${title || "terminal_export.sh"}`, 115, 53);

      // Terminal text
      ctx.fillStyle = "#34d399";
      ctx.font = "15px 'JetBrains Mono', monospace";
      wrapCanvasText(ctx, `$ ${text}`, 60, 105, w - 120, 26, 9);
    },
  },

  // 11. Gökkuşağı Buzlu Cam (Rainbow Glass)
  {
    id: "frame-rainbow-glass",
    name: "Gökkuşağı Buzlu Cam",
    category: "modern",
    categoryLabel: "Modern & Şık",
    description: "Glassmorphism yarı saydam gökkuşağı gradyan kenarlığı",
    badgeLabel: "🌈 GLASSMORPHISM",
    iconSymbol: "🌈",
    borderColor: "#8b5cf6",
    bgPreview: "bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 text-white",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-rainbow-glass" style="border: 2px solid transparent; background: linear-gradient(#ffffff,#ffffff) padding-box, linear-gradient(135deg,#ec4899,#8b5cf6,#06b6d4) border-box; border-radius: 16px; padding: 18px; margin: 16px 0; color: #1e293b; box-shadow: 0 8px 24px rgba(139,92,246,0.15);">
        <div style="font-weight: bold; font-size: 13px; color: #7c3aed; margin-bottom: 6px;">🌈 ${title || "Işıltılı Not Karesi"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, "#ec4899");
      grad.addColorStop(0.5, "#8b5cf6");
      grad.addColorStop(1, "#06b6d4");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 20);
      ctx.fillStyle = "rgba(15, 23, 42, 0.85)";
      ctx.fill();
      ctx.strokeStyle = "rgba(255, 255, 255, 0.4)";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = "#f472b6";
      ctx.font = "bold 13px sans-serif";
      ctx.fillText(`🌈 ${title || "PREMIUM GLASS CARD"}`, 65, 80);

      ctx.fillStyle = "#ffffff";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 65, 130, w - 130, 28, 8);
    },
  },

  // 12. Önemli İkaz Şeridi (Warning Caution)
  {
    id: "frame-warning-caution",
    name: "Önemli İkaz Şeridi",
    category: "creative",
    categoryLabel: "Yaratıcı & Renkli",
    description: "Sarı/siyah ikaz şeritli dikkat ve alarm kutusu",
    badgeLabel: "⚠️ DİKKAT // UYARI",
    iconSymbol: "⚠️",
    borderColor: "#eab308",
    bgPreview: "bg-amber-100 text-amber-950 border-amber-600",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-warning-caution" style="border: 2px dashed #eab308; border-radius: 12px; padding: 16px; margin: 16px 0; background: #fffbeb; color: #78350f; border-left: 8px solid #f59e0b;">
        <div style="font-weight: 800; font-size: 13px; color: #b45309; margin-bottom: 6px; display: flex; align-items: center; gap: 6px;">
          <span>⚠️</span> <span>${title || "KRİTİK DİKKAT VE UYARI"}</span>
        </div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#1e1b4b";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 14);
      ctx.fillStyle = "#fffbeb";
      ctx.fill();
      ctx.strokeStyle = "#f59e0b";
      ctx.lineWidth = 3;
      ctx.stroke();

      // Caution stripe at top
      ctx.fillStyle = "#f59e0b";
      ctx.fillRect(35, 35, w - 70, 24);

      ctx.fillStyle = "#78350f";
      ctx.font = "bold 22px sans-serif";
      ctx.fillText(`⚠️ ${title || "KRİTİK UYARI VE NOT"}`, 65, 105);

      ctx.fillStyle = "#451a03";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 65, 150, w - 130, 28, 8);
    },
  },

  // 13. Sanatsal Suluboya (Artistic Watercolor)
  {
    id: "frame-watercolor",
    name: "Sanatsal Suluboya",
    category: "artistic",
    categoryLabel: "Sanat & Tasarım",
    description: "Pastel renk geçişli fırça ve suluboya arka planı",
    badgeLabel: "🎨 SANAT ATÖLYESİ",
    iconSymbol: "🎨",
    borderColor: "#ec4899",
    bgPreview: "bg-pink-100 text-pink-900 border-pink-300",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-watercolor" style="border: 2px solid #f472b6; border-radius: 20px; padding: 18px; margin: 16px 0; background: linear-gradient(135deg, #fdf2f8, #fce7f3, #fae8ff); color: #831843; box-shadow: 0 6px 18px rgba(244,114,182,0.15);">
        <div style="font-weight: bold; font-size: 13px; color: #be185d; margin-bottom: 6px;">🎨 ${title || "Sanatsal Not"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, "#fdf2f8");
      grad.addColorStop(0.5, "#fce7f3");
      grad.addColorStop(1, "#f3e8ff");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 40, 40, w - 80, h - 80, 24);
      ctx.strokeStyle = "#f472b6";
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.fillStyle = "#be185d";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText(`🎨 ${title || "Sanat Notu"}`, 70, 95);

      ctx.fillStyle = "#831843";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 70, 145, w - 140, 28, 8);
    },
  },

  // 14. Retro Bilet (Perforated Ticket)
  {
    id: "frame-ticket",
    name: "Retro Bilet",
    category: "creative",
    categoryLabel: "Yaratıcı & Renkli",
    description: "Tırtıklı kenarlı sinema/uçak bileti formatı",
    badgeLabel: "🎟️ ADMIT ONE",
    iconSymbol: "🎟️",
    borderColor: "#fb923c",
    bgPreview: "bg-orange-100 text-orange-950 border-orange-400",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-ticket" style="border: 2px dashed #fb923c; border-radius: 12px; padding: 16px; margin: 16px 0; background: #fff7ed; color: #7c2d12; position: relative;">
        <div style="display:flex; justify-content:space-between; border-bottom: 2px dashed #fdba74; padding-bottom: 8px; margin-bottom: 10px; font-weight: bold; font-size: 12px; color: #ea580c;">
          <span>🎟️ PASS: ${title || "TICKET"}</span>
          <span>NO: #${Math.floor(1000 + Math.random() * 9000)}</span>
        </div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#ea580c";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 14);
      ctx.fillStyle = "#fff7ed";
      ctx.fill();

      // Top ticket header
      ctx.fillStyle = "#c2410c";
      ctx.font = "bold 14px monospace";
      ctx.fillText(`🎟️ PASS NO: #7749 // ${title || "NOTEFLOW TICKET"}`, 60, 75);

      // Dash line
      ctx.strokeStyle = "#fdba74";
      ctx.lineWidth = 2;
      ctx.setLineDash([8, 6]);
      ctx.beginPath();
      ctx.moveTo(50, 95);
      ctx.lineTo(w - 50, 95);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = "#7c2d12";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 60, 135, w - 120, 28, 8);
    },
  },

  // 15. Gazete Kupürü (Newspaper Clipping)
  {
    id: "frame-newspaper",
    name: "Gazete Kupürü",
    category: "vintage",
    categoryLabel: "Vintage & Nostalji",
    description: "Sütunlu gazete manşeti ve daktilo yazı stili",
    badgeLabel: "📰 GÜNLÜK BASIN",
    iconSymbol: "📰",
    borderColor: "#78716c",
    bgPreview: "bg-stone-200 text-stone-900 border-stone-400",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-newspaper" style="border: 2px solid #57534e; padding: 18px; margin: 16px 0; background: #e7e5e4; color: #1c1917; font-family: 'Merriweather', serif; box-shadow: 2px 4px 10px rgba(0,0,0,0.1);">
        <div style="text-align: center; border-bottom: 2px solid #1c1917; padding-bottom: 6px; margin-bottom: 10px;">
          <div style="font-size: 10px; letter-spacing: 2px; text-transform: uppercase;">THE NOTEFLOW CHRONICLE • GÜNLÜK BASKI</div>
          <h3 style="font-size: 18px; font-weight: 800; margin: 4px 0;">${title || "SON DAKİKA GELİŞMESİ"}</h3>
        </div>
        <div style="font-size: 13px; line-height: 1.7;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#d6d3d1";
      ctx.fillRect(0, 0, w, h);

      ctx.fillStyle = "#f5f5f4";
      ctx.fillRect(35, 30, w - 70, h - 60);
      ctx.strokeStyle = "#292524";
      ctx.lineWidth = 3;
      ctx.strokeRect(35, 30, w - 70, h - 60);

      // Newspaper header
      ctx.fillStyle = "#1c1917";
      ctx.font = "bold 11px 'Playfair Display', serif";
      ctx.fillText("THE DAILY NOTEFLOW GAZETTE • BASKI NO: 1", 60, 60);

      ctx.font = "bold 24px 'Playfair Display', serif";
      ctx.fillText((title || "MANŞET GELİŞME").substring(0, 32), 60, 95);

      // Divider
      ctx.strokeStyle = "#1c1917";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(55, 110);
      ctx.lineTo(w - 55, 110);
      ctx.stroke();

      ctx.font = "16px 'Merriweather', serif";
      wrapCanvasText(ctx, text, 60, 145, w - 120, 27, 8);
    },
  },

  // 16. Mantar Pano & Raptiye (Corkboard Pin)
  {
    id: "frame-corkboard",
    name: "Mantar Pano",
    category: "creative",
    categoryLabel: "Yaratıcı & Renkli",
    description: "Sıcak mantar dokusu üzerine renkli raptiyeli kart",
    badgeLabel: "📌 PANOYA İĞNELİ",
    iconSymbol: "📌",
    borderColor: "#92400e",
    bgPreview: "bg-amber-800 text-amber-100",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-corkboard" style="border: 4px solid #78350f; border-radius: 14px; padding: 18px; margin: 16px 0; background: #d97706; background-image: radial-gradient(#b45309 15%, transparent 16%); background-size: 12px 12px; color: #451a03; box-shadow: 0 8px 18px rgba(0,0,0,0.2);">
        <div style="background: #fffbeb; border-radius: 10px; padding: 14px; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
          <div style="font-weight: bold; font-size: 13px; color: #b45309; margin-bottom: 6px;">📌 ${title || "Panodaki Not"}</div>
          <div style="font-size: 14px; line-height: 1.6;">${content}</div>
        </div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#92400e";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 45, 35, w - 90, h - 70, 12);
      ctx.fillStyle = "#fffbeb";
      ctx.shadowColor = "rgba(0,0,0,0.25)";
      ctx.shadowBlur = 16;
      ctx.fill();
      ctx.shadowBlur = 0;

      // Pin
      ctx.fillStyle = "#3b82f6";
      ctx.beginPath();
      ctx.arc(w / 2, 50, 10, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "#78350f";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText(`📌 ${title || "Pano Notu"}`, 70, 100);

      ctx.fillStyle = "#451a03";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 70, 145, w - 140, 28, 8);
    },
  },

  // 17. Lüks Gece Altını (Gold Noir Luxury)
  {
    id: "frame-gold-noir",
    name: "Lüks Gece Altını",
    category: "modern",
    categoryLabel: "Modern & Şık",
    description: "Karanlık obsidyen üzerine 24k altın yaldızlı ince bordür",
    badgeLabel: "⚜️ 24K NOIR GOLD",
    iconSymbol: "⚜️",
    borderColor: "#eab308",
    bgPreview: "bg-black text-amber-300 border-amber-500",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-gold-noir" style="border: 2px solid #eab308; border-radius: 16px; padding: 20px; margin: 16px 0; background: #0a0a0a; color: #fef08a; box-shadow: 0 0 20px rgba(234,179,8,0.25);">
        <div style="display:flex; align-items:center; gap:8px; font-size: 11px; font-weight: bold; letter-spacing: 2px; color: #facc15; margin-bottom: 8px;">
          <span>⚜️</span> <span>${title || "PRESTIGE NOIR"}</span>
        </div>
        <div style="font-size: 14px; line-height: 1.6; color: #fef9c3;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#050505";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 16);
      ctx.fillStyle = "#111111";
      ctx.fill();
      ctx.strokeStyle = "#eab308";
      ctx.lineWidth = 3;
      ctx.shadowColor = "#facc15";
      ctx.shadowBlur = 16;
      ctx.stroke();
      ctx.shadowBlur = 0;

      ctx.fillStyle = "#facc15";
      ctx.font = "bold 13px 'Playfair Display', serif";
      ctx.fillText(`⚜️ ${title || "PRESTİJ ALTIN NOT"}`, 65, 80);

      ctx.fillStyle = "#fef9c3";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 65, 130, w - 130, 29, 8);
    },
  },

  // 18. Kuzey Işıkları (Aurora Borealis)
  {
    id: "frame-aurora",
    name: "Kuzey Işıkları",
    category: "neon",
    categoryLabel: "Neon & Siber",
    description: "Zümrüt yeşili ve mor aurora dalgaları ile canlı gradyan",
    badgeLabel: "🌌 AURORA BOREALIS",
    iconSymbol: "🌌",
    borderColor: "#10b981",
    bgPreview: "bg-gradient-to-r from-emerald-600 via-teal-700 to-indigo-800 text-white",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-aurora" style="border: 2px solid #34d399; border-radius: 18px; padding: 18px; margin: 16px 0; background: linear-gradient(135deg, #064e3b, #0f766e, #312e81); color: #ecfdf5; box-shadow: 0 8px 25px rgba(16,185,129,0.3);">
        <div style="font-weight: bold; font-size: 13px; color: #6ee7b7; margin-bottom: 6px;">🌌 ${title || "Aurora Işıltısı"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, "#064e3b");
      grad.addColorStop(0.5, "#0f766e");
      grad.addColorStop(1, "#312e81");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 20);
      ctx.strokeStyle = "#34d399";
      ctx.lineWidth = 3;
      ctx.shadowColor = "#6ee7b7";
      ctx.shadowBlur = 18;
      ctx.stroke();
      ctx.shadowBlur = 0;

      ctx.fillStyle = "#a7f3d0";
      ctx.font = "bold 22px sans-serif";
      ctx.fillText(`🌌 ${title || "Aurora Notu"}`, 65, 90);

      ctx.fillStyle = "#ffffff";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 65, 140, w - 130, 28, 8);
    },
  },

  // 19. Bantlı Fotoğraf (Washi Tape)
  {
    id: "frame-washi-tape",
    name: "Bantlı Fotoğraf",
    category: "creative",
    categoryLabel: "Yaratıcı & Renkli",
    description: "Üst köşelerinde yarı saydam washi bant süsü olan kart",
    badgeLabel: "🎀 WASHI BANTLI",
    iconSymbol: "🎀",
    borderColor: "#f43f5e",
    bgPreview: "bg-rose-50 text-rose-950 border-rose-300",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-washi-tape" style="border: 1px solid #fecdd3; border-radius: 12px; padding: 18px; margin: 16px 0; background: #fff1f2; color: #881337; box-shadow: 0 6px 16px rgba(244,63,94,0.1); position: relative;">
        <div style="font-weight: bold; font-size: 13px; color: #e11d48; margin-bottom: 6px;">🎀 ${title || "Bantlı Not"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#e2e8f0";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 45, 35, w - 90, h - 70, 14);
      ctx.fillStyle = "#fff1f2";
      ctx.fill();

      // Washi Tapes at corners
      ctx.fillStyle = "rgba(244, 63, 94, 0.6)";
      ctx.fillRect(35, 20, 80, 22);
      ctx.fillRect(w - 115, 20, 80, 22);

      ctx.fillStyle = "#e11d48";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText(`🎀 ${title || "Bantlı Not"}`, 70, 95);

      ctx.fillStyle = "#881337";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 70, 145, w - 140, 28, 8);
    },
  },

  // 20. Büyük Alıntı Bloğu (Modern Quote)
  {
    id: "frame-quote-block",
    name: "Büyük Alıntı Bloğu",
    category: "artistic",
    categoryLabel: "Sanat & Tasarım",
    description: "Zarif büyük tırnak işareti ve italik edebi yazı stili",
    badgeLabel: "❝ GÜNÜN SÖZÜ",
    iconSymbol: "❝",
    borderColor: "#6366f1",
    bgPreview: "bg-indigo-50 text-indigo-950 border-indigo-400",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-quote-block" style="border-left: 6px solid #6366f1; border-radius: 4px 14px 14px 4px; padding: 18px; margin: 16px 0; background: #eef2ff; color: #312e81; font-style: italic;">
        <div style="font-size: 24px; color: #6366f1; line-height: 1; font-weight: bold; margin-bottom: 4px;">“</div>
        <div style="font-size: 15px; line-height: 1.7;">${content}</div>
        <div style="text-align: right; font-weight: bold; font-size: 12px; color: #4f46e5; margin-top: 8px;">— ${title || "Anonim"}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#eef2ff";
      ctx.fillRect(0, 0, w, h);

      ctx.fillStyle = "#6366f1";
      ctx.fillRect(40, 40, 8, h - 80);

      // Quote symbol
      ctx.fillStyle = "#818cf8";
      ctx.font = "bold 60px 'Playfair Display', serif";
      ctx.fillText("“", 65, 105);

      ctx.fillStyle = "#1e1b4b";
      ctx.font = "italic 19px 'Playfair Display', serif";
      wrapCanvasText(ctx, text, 70, 150, w - 140, 30, 7);

      ctx.fillStyle = "#4f46e5";
      ctx.font = "bold 15px 'Playfair Display', serif";
      ctx.fillText(`— ${title || "Edebi Alıntı"}`, w - 240, h - 60);
    },
  },

  // 21. Mühendislik Çizimi (CAD Blueprint)
  {
    id: "frame-blueprint",
    name: "Mühendislik Projesi",
    category: "office",
    categoryLabel: "Ofis & Kurumsal",
    description: "Koyu mavi teknik çizim zemin ve beyaz kesikli kılavuzlar",
    badgeLabel: "📐 CAD // BLUEPRINT",
    iconSymbol: "📐",
    borderColor: "#38bdf8",
    bgPreview: "bg-blue-900 text-blue-100 border-blue-400",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-blueprint" style="border: 2px dashed #38bdf8; border-radius: 8px; padding: 18px; margin: 16px 0; background: #0c4a6e; color: #e0f2fe; font-family: 'JetBrains Mono', monospace;">
        <div style="font-weight: bold; font-size: 12px; color: #7dd3fc; border-bottom: 1px dashed #0284c7; padding-bottom: 4px; margin-bottom: 8px;">📐 SCHEMATIC PLAN // ${title || "PROJECT_REV_1"}</div>
        <div style="font-size: 13px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#082f49";
      ctx.fillRect(0, 0, w, h);

      // Blueprint grid
      ctx.strokeStyle = "#0c4a6e";
      ctx.lineWidth = 1;
      for (let x = 0; x < w; x += 30) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += 30) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 8);
      ctx.strokeStyle = "#38bdf8";
      ctx.lineWidth = 2;
      ctx.setLineDash([8, 6]);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = "#7dd3fc";
      ctx.font = "bold 14px 'JetBrains Mono', monospace";
      ctx.fillText(`📐 CAD BLUEPRINT: ${title || "SPECIFICATION_DOC"}`, 60, 75);

      ctx.fillStyle = "#e0f2fe";
      ctx.font = "16px 'JetBrains Mono', monospace";
      wrapCanvasText(ctx, text, 60, 125, w - 120, 27, 8);
    },
  },

  // 22. Retro 8-Bit Arcade
  {
    id: "frame-arcade-8bit",
    name: "8-Bit Arcade",
    category: "creative",
    categoryLabel: "Yaratıcı & Renkli",
    description: "Pikselize kalın siyah hatlar ve retro oyun teması",
    badgeLabel: "🕹️ LEVEL UP",
    iconSymbol: "🕹️",
    borderColor: "#10b981",
    bgPreview: "bg-emerald-900 text-emerald-200 border-emerald-400",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-arcade-8bit" style="border: 4px solid #10b981; border-radius: 4px; padding: 16px; margin: 16px 0; background: #064e3b; color: #a7f3d0; font-family: monospace; box-shadow: 4px 4px 0 #047857;">
        <div style="font-weight: bold; font-size: 13px; color: #34d399; margin-bottom: 6px;">🕹️ [PLAYER 1: ${title || "QUEST_LOG"}]</div>
        <div style="font-size: 13px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#022c22";
      ctx.fillRect(0, 0, w, h);

      ctx.fillStyle = "#064e3b";
      ctx.fillRect(35, 35, w - 70, h - 70);
      ctx.strokeStyle = "#10b981";
      ctx.lineWidth = 4;
      ctx.strokeRect(35, 35, w - 70, h - 70);

      ctx.fillStyle = "#34d399";
      ctx.font = "bold 16px monospace";
      ctx.fillText(`🕹️ [MISSION: ${title || "START_GAME"}]`, 60, 75);

      ctx.fillStyle = "#a7f3d0";
      ctx.font = "16px monospace";
      wrapCanvasText(ctx, text, 60, 120, w - 120, 26, 8);
    },
  },

  // 23. Ametist Kristali
  {
    id: "frame-amethyst",
    name: "Ametist Kristali",
    category: "neon",
    categoryLabel: "Neon & Siber",
    description: "Koyu mor ve parlayan ametist kristali hatları",
    badgeLabel: "🔮 MİSTİK AMETİST",
    iconSymbol: "🔮",
    borderColor: "#9333ea",
    bgPreview: "bg-purple-950 text-purple-200 border-purple-500",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-amethyst" style="border: 2px solid #a855f7; border-radius: 16px; padding: 18px; margin: 16px 0; background: #3b0764; color: #f3e8ff; box-shadow: 0 0 20px rgba(168,85,247,0.3);">
        <div style="font-weight: bold; font-size: 13px; color: #d8b4fe; margin-bottom: 6px;">🔮 ${title || "Ametist Sırrı"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, "#2e1065");
      grad.addColorStop(1, "#581c87");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 18);
      ctx.strokeStyle = "#c084fc";
      ctx.lineWidth = 3;
      ctx.shadowColor = "#a855f7";
      ctx.shadowBlur = 16;
      ctx.stroke();
      ctx.shadowBlur = 0;

      ctx.fillStyle = "#e9d5ff";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText(`🔮 ${title || "Ametist Notu"}`, 65, 85);

      ctx.fillStyle = "#ffffff";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 65, 135, w - 130, 28, 8);
    },
  },

  // 24. Gül Kurusu Romantik
  {
    id: "frame-rose-elegance",
    name: "Gül Kurusu Romantik",
    category: "artistic",
    categoryLabel: "Sanat & Tasarım",
    description: "Yumuşak pembe tonlar, çiçeksi ve romantik kart",
    badgeLabel: "🌸 ZARİF GÜL",
    iconSymbol: "🌸",
    borderColor: "#fb7185",
    bgPreview: "bg-rose-100 text-rose-900 border-rose-400",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-rose-elegance" style="border: 2px solid #fda4af; border-radius: 20px; padding: 18px; margin: 16px 0; background: #fff1f2; color: #9f1239; box-shadow: 0 4px 14px rgba(251,113,133,0.15);">
        <div style="font-weight: bold; font-size: 13px; color: #e11d48; margin-bottom: 6px;">🌸 ${title || "Zarif Günlük"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#fff1f2";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 20);
      ctx.strokeStyle = "#fb7185";
      ctx.lineWidth = 2.5;
      ctx.stroke();

      ctx.fillStyle = "#be123c";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText(`🌸 ${title || "Zarif Gül Notu"}`, 65, 85);

      ctx.fillStyle = "#881337";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 65, 135, w - 130, 28, 8);
    },
  },

  // 25. Hedef ve Görev Kontrolü (Goal Checklist)
  {
    id: "frame-goal-checklist",
    name: "Hedef & Kontrol",
    category: "office",
    categoryLabel: "Ofis & Kurumsal",
    description: "Yeşil başarı rozetli ve kontrol kutucuklu çerçeve",
    badgeLabel: "✅ HEDEF // TAMAM",
    iconSymbol: "✅",
    borderColor: "#10b981",
    bgPreview: "bg-emerald-50 text-emerald-950 border-emerald-400",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-goal-checklist" style="border: 2px solid #10b981; border-radius: 14px; padding: 18px; margin: 16px 0; background: #ecfdf5; color: #064e3b; box-shadow: 0 4px 14px rgba(16,185,129,0.12);">
        <div style="display:flex; align-items:center; gap:6px; font-weight: bold; font-size: 13px; color: #047857; margin-bottom: 6px;">
          <span>✅</span> <span>${title || "HEDEF VE KONTROL PLANI"}</span>
        </div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#ecfdf5";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 16);
      ctx.strokeStyle = "#10b981";
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.fillStyle = "#047857";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText(`✅ ${title || "Hedef ve Görev Planı"}`, 65, 85);

      ctx.fillStyle = "#064e3b";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 65, 135, w - 130, 28, 8);
    },
  },

  // 26. Kırmızı İpek Ayraç (Bookmark Ribbon)
  {
    id: "frame-bookmark-ribbon",
    name: "Kırmızı İpek Ayraç",
    category: "vintage",
    categoryLabel: "Vintage & Nostalji",
    description: "Üstten sarkan şık kitap ayracı kurdelesi detayı",
    badgeLabel: "🔖 KİTAP AYRACI",
    iconSymbol: "🔖",
    borderColor: "#dc2626",
    bgPreview: "bg-stone-100 text-stone-900 border-stone-300",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-bookmark-ribbon" style="border: 1px solid #e7e5e4; border-radius: 12px; padding: 18px; margin: 16px 0; background: #fafaf9; color: #1c1917; position: relative; box-shadow: 0 4px 12px rgba(0,0,0,0.06);">
        <div style="font-weight: bold; font-size: 13px; color: #b91c1c; margin-bottom: 6px;">🔖 ${title || "Kitap Alıntısı"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#fafaf9";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 14);
      ctx.strokeStyle = "#e7e5e4";
      ctx.lineWidth = 2;
      ctx.stroke();

      // Red ribbon hanging
      ctx.fillStyle = "#dc2626";
      ctx.fillRect(80, 20, 24, 60);
      ctx.beginPath();
      ctx.moveTo(80, 80);
      ctx.lineTo(92, 70);
      ctx.lineTo(104, 80);
      ctx.fill();

      ctx.fillStyle = "#1c1917";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText((title || "Kitap Ayracı Notu").substring(0, 30), 125, 65);

      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 65, 135, w - 130, 28, 8);
    },
  },

  // 27. Holografik Gelecek (Holo Cyber)
  {
    id: "frame-holo-cyber",
    name: "Holografik Gelecek",
    category: "neon",
    categoryLabel: "Neon & Siber",
    description: "Yansıyan sedefli gradyan ve fütüristik köşe hatları",
    badgeLabel: "🌐 HOLO // MATRIX",
    iconSymbol: "🌐",
    borderColor: "#38bdf8",
    bgPreview: "bg-gradient-to-tr from-cyan-600 to-fuchsia-600 text-white",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-holo-cyber" style="border: 2px solid #38bdf8; border-radius: 16px; padding: 18px; margin: 16px 0; background: linear-gradient(135deg, #0f172a, #1e1b4b, #0e7490); color: #e0f2fe; box-shadow: 0 0 20px rgba(56,189,248,0.3);">
        <div style="font-weight: bold; font-size: 13px; color: #67e8f9; margin-bottom: 6px;">🌐 ${title || "Hologram Kaydı"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, "#0f172a");
      grad.addColorStop(0.5, "#1e1b4b");
      grad.addColorStop(1, "#0e7490");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 16);
      ctx.strokeStyle = "#38bdf8";
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.fillStyle = "#67e8f9";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText(`🌐 ${title || "Holografik Veri"}`, 65, 85);

      ctx.fillStyle = "#ffffff";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 65, 135, w - 130, 28, 8);
    },
  },

  // 28. Kahve Molası Günlüğü (Barista Coffee)
  {
    id: "frame-coffee-barista",
    name: "Kahve Molası",
    category: "artistic",
    categoryLabel: "Sanat & Tasarım",
    description: "Sıcak latte tonları ve barista defteri kahve dokusu",
    badgeLabel: "☕ KAHVE MOLASI",
    iconSymbol: "☕",
    borderColor: "#78350f",
    bgPreview: "bg-amber-100 text-amber-950 border-amber-700",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-coffee-barista" style="border: 2px solid #92400e; border-radius: 16px; padding: 18px; margin: 16px 0; background: #fef3c7; color: #451a03; box-shadow: 0 4px 14px rgba(120,53,15,0.12);">
        <div style="font-weight: bold; font-size: 13px; color: #78350f; margin-bottom: 6px;">☕ ${title || "Kahve Molası Notları"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#fef3c7";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 16);
      ctx.strokeStyle = "#92400e";
      ctx.lineWidth = 3;
      ctx.stroke();

      // Coffee ring stain watermark
      ctx.strokeStyle = "rgba(180, 83, 9, 0.15)";
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.arc(w - 110, 120, 45, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = "#78350f";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText(`☕ ${title || "Kahve Molası"}`, 65, 85);

      ctx.fillStyle = "#451a03";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 65, 135, w - 130, 28, 8);
    },
  },

  // 29. Doğa ve Botanik (Botanic Leaf)
  {
    id: "frame-botanic-leaf",
    name: "Doğa & Botanik",
    category: "artistic",
    categoryLabel: "Sanat & Tasarım",
    description: "Doğal zeytin yeşili ve yaprak motifli ferah çerçeve",
    badgeLabel: "🌿 DOĞAL DOKU",
    iconSymbol: "🌿",
    borderColor: "#65a30d",
    bgPreview: "bg-lime-50 text-lime-950 border-lime-400",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-botanic-leaf" style="border: 2px solid #84cc16; border-radius: 18px; padding: 18px; margin: 16px 0; background: #f7fee7; color: #365314; box-shadow: 0 4px 14px rgba(101,163,13,0.12);">
        <div style="font-weight: bold; font-size: 13px; color: #4d7c0f; margin-bottom: 6px;">🌿 ${title || "Doğa & Botanik"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#f7fee7";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 18);
      ctx.strokeStyle = "#84cc16";
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.fillStyle = "#4d7c0f";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText(`🌿 ${title || "Doğa & Botanik Notu"}`, 65, 85);

      ctx.fillStyle = "#365314";
      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 65, 135, w - 130, 28, 8);
    },
  },

  // 30. Sade İkiz Çizgi (Double Line Classic)
  {
    id: "frame-double-classic",
    name: "Sade İkiz Çizgi",
    category: "modern",
    categoryLabel: "Modern & Şık",
    description: "Zarif çift katmanlı klasik dosya ve doküman çerçevesi",
    badgeLabel: "◈ DOKÜMAN DOSYASI",
    iconSymbol: "◈",
    borderColor: "#334155",
    bgPreview: "bg-slate-100 text-slate-900 border-slate-400",
    getHtml: (content, title) => `
      <div class="noteflow-frame-box" data-frame-id="frame-double-classic" style="border: 3px double #334155; border-radius: 12px; padding: 18px; margin: 16px 0; background: #ffffff; color: #0f172a; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
        <div style="font-weight: bold; font-size: 13px; color: #334155; margin-bottom: 6px;">◈ ${title || "Klasik Dosya Notu"}</div>
        <div style="font-size: 14px; line-height: 1.6;">${content}</div>
      </div><p><br></p>`,
    renderCanvas: (ctx, w, h, text, title, category, font) => {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, w, h);

      drawRoundRect(ctx, 35, 35, w - 70, h - 70, 12);
      ctx.strokeStyle = "#334155";
      ctx.lineWidth = 3.5;
      ctx.stroke();

      drawRoundRect(ctx, 42, 42, w - 84, h - 84, 8);
      ctx.strokeStyle = "#94a3b8";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = "#0f172a";
      ctx.font = `bold 22px '${font}', sans-serif`;
      ctx.fillText(`◈ ${title || "Klasik Dosya"}`, 65, 85);

      ctx.font = `18px '${font}', sans-serif`;
      wrapCanvasText(ctx, text, 65, 135, w - 130, 28, 8);
    },
  },
];

// ============================================================================
// RECENT FRAMES MANAGEMENT (Stores maximum 10 most recently used frame IDs)
// ============================================================================
export function getRecentFrameIds(): string[] {
  try {
    const raw = localStorage.getItem(RECENT_FRAMES_KEY);
    if (!raw) {
      // Default top 10 frames
      return ALL_FRAME_PRESETS.slice(0, 10).map((f) => f.id);
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed.slice(0, 10);
    }
  } catch (e) {
    console.error("Error reading recent frames:", e);
  }
  return ALL_FRAME_PRESETS.slice(0, 10).map((f) => f.id);
}

export function recordFrameUsage(frameId: string): string[] {
  try {
    const current = getRecentFrameIds();
    const updated = [frameId, ...current.filter((id) => id !== frameId)].slice(0, 10);
    localStorage.setItem(RECENT_FRAMES_KEY, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error("Error saving recent frame:", e);
    return getRecentFrameIds();
  }
}

export function getFrameById(id: string): FramePreset {
  return ALL_FRAME_PRESETS.find((f) => f.id === id) || ALL_FRAME_PRESETS[0];
}

// Generate canvas snapshot dataURL for any given frame preset and text
export function renderFrameToDataUrl(
  frame: FramePreset,
  text: string,
  title: string,
  category: string = "Genel",
  fontFamily: string = "Plus Jakarta Sans"
): string {
  const canvas = document.createElement("canvas");
  canvas.width = 800;
  canvas.height = 460;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";

  frame.renderCanvas(ctx, 800, 460, text, title, category, fontFamily);
  return canvas.toDataURL("image/png");
}
