/**
 * Web Vibration API tactile feedback utilities for Apple-like haptics
 */
export type HapticStyle = 'light' | 'medium' | 'heavy' | 'selection' | 'success' | 'warning' | 'error';

export const triggerHaptic = (style: HapticStyle = 'light'): void => {
  if (typeof window === 'undefined' || !('vibrate' in navigator)) {
    return;
  }
  try {
    switch (style) {
      case 'light':
      case 'selection':
        // Crisp gentle tap (Apple selection tick)
        navigator.vibrate(8);
        break;
      case 'medium':
        // Standard tactile button feedback
        navigator.vibrate(18);
        break;
      case 'heavy':
        // Firm confirmation press
        navigator.vibrate(30);
        break;
      case 'success':
        // Rhythmic double-pulse confirmation (Apple Pay / Turnstile pass check-in)
        navigator.vibrate([12, 45, 22]);
        break;
      case 'warning':
        // Moderate alert double-pulse
        navigator.vibrate([22, 50, 28]);
        break;
      case 'error':
        // Distinct alert triple pulse
        navigator.vibrate([35, 60, 35, 60, 35]);
        break;
      default:
        navigator.vibrate(12);
        break;
    }
  } catch {
    // Fail silently if vibration is blocked or unsupported by browser
  }
};
