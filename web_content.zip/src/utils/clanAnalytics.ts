import {
  ClanDashboardState,
  ClanSnapshot,
  ClanSnapshotPlayerEntry,
  OfficialUnitEntry,
  PlayerProfile,
} from '../shared/cocData';

const UNIT_NAMES_RU: Record<string, string> = {
  // Heroes
  'Barbarian King': 'Король варваров',
  'Archer Queen': 'Королева лучниц',
  'Grand Warden': 'Хранитель',
  'Royal Champion': 'Королевский чемпион',
  'Minion Prince': 'Принц миньонов',
  'Battle Machine': 'Боевая машина',
  'Battle Copter': 'Боевой вертолёт',
  // Elixir & Dark Troops
  Barbarian: 'Варвар',
  Archer: 'Лучница',
  Giant: 'Гигант',
  Goblin: 'Гоблин',
  'Wall Breaker': 'Стенобой',
  Balloon: 'Воздушный шар',
  Wizard: 'Маг',
  Healer: 'Целительница',
  Dragon: 'Дракон',
  'P.E.K.K.A': 'П.Е.К.К.А',
  'Baby Dragon': 'Малыш дракон',
  Miner: 'Шахтёр',
  'Electro Dragon': 'Электродракон',
  Yeti: 'Йети',
  'Dragon Rider': 'Наездник на драконе',
  'Electro Titan': 'Электротитан',
  'Root Rider': 'Наездник на корнях',
  Thrower: 'Метатель',
  Minion: 'Миньон',
  'Hog Rider': 'Всадник на кабане',
  Valkyrie: 'Валькирия',
  Golem: 'Голем',
  Witch: 'Ведьма',
  'Lava Hound': 'Адская гончая',
  Bowler: 'Вышибала',
  'Ice Golem': 'Ледяной голем',
  Headhunter: 'Охотница за головами',
  'Apprentice Warden': 'Ученик Хранителя',
  Druid: 'Друид',
  Furnace: 'Печь',
  // Spells
  'Lightning Spell': 'Молниеносное заклинание',
  'Healing Spell': 'Исцеляющее заклинание',
  'Rage Spell': 'Заклинание ярости',
  'Jump Spell': 'Заклинание прыжка',
  'Freeze Spell': 'Заклинание заморозки',
  'Clone Spell': 'Заклинание клонирования',
  'Invisibility Spell': 'Заклинание невидимости',
  'Recall Spell': 'Заклинание возврата',
  'Revive Spell': 'Заклинание возрождения',
  'Poison Spell': 'Ядовитое заклинание',
  'Earthquake Spell': 'Землетрясущее заклинание',
  'Haste Spell': 'Заклинание спешки',
  'Skeleton Spell': 'Скелетное заклинание',
  'Bat Spell': 'Заклинание летучих мышей',
  'Overgrowth Spell': 'Заклинание зарастания',
  // Siege Machines
  'Wall Wrecker': 'Таран',
  'Battle Blimp': 'Боевой дирижабль',
  'Stone Slammer': 'Камнебросатель',
  'Siege Barracks': 'Осадная казарма',
  'Log Launcher': 'Бревномёт',
  'Flame Flinger': 'Огнемётчица',
  'Battle Drill': 'Боевой бур',
  'Troop Launcher': 'Катапульта войск',
  // Pets
  'L.A.S.S.I': 'Л.А.С.С.И.',
  'Electro Owl': 'Электросова',
  'Mighty Yak': 'Могучий як',
  Unicorn: 'Единорог',
  Frosty: 'Снежок',
  Diggy: 'Дигги',
  'Poison Lizard': 'Ядовитая ящерица',
  Phoenix: 'Феникс',
  'Spirit Fox': 'Духовная лиса',
  'Angry Jelly': 'Злая медуза',
  Sneezy: 'Чихун',
};

export function translateCocUnitNameRu(name: string): string {
  return UNIT_NAMES_RU[name] ?? name;
}

export function sumUnitLevels(items: OfficialUnitEntry[]): { sum: number; maxSum: number } {
  let sum = 0;
  let maxSum = 0;
  for (const item of items) {
    if (item.village && item.village !== 'home') continue;
    sum += item.level || 0;
    maxSum += Math.max(item.level || 0, item.maxLevel || 0);
  }
  return { sum, maxSum };
}

export function buildSnapshotPlayerEntry(
  p: PlayerProfile,
  compositeScore?: number
): ClanSnapshotPlayerEntry {
  const heroes = sumUnitLevels(p.apiHeroes);
  const troops = sumUnitLevels(p.apiTroops);
  const spells = sumUnitLevels(p.apiSpells);
  const siege = sumUnitLevels(p.apiSiegeMachines);
  const pets = sumUnitLevels(p.apiPets);
  const equip = sumUnitLevels(p.apiHeroEquipment);

  return {
    name: p.name,
    townHallLevel: p.townHallLevel,
    trophies: p.trophies,
    donations: p.donations,
    donationsReceived: p.donationsReceived,
    warStars: p.warStars,
    expLevel: p.expLevel,
    overallPct: p.progress.overallPct,
    heroesLevelSum: heroes.sum,
    heroesMaxSum: heroes.maxSum,
    troopsLevelSum: troops.sum,
    troopsMaxSum: troops.maxSum,
    spellsLevelSum: spells.sum,
    spellsMaxSum: spells.maxSum,
    siegeLevelSum: siege.sum,
    petsLevelSum: pets.sum,
    equipmentLevelSum: equip.sum,
    clanCapitalContributions: p.clanCapitalContributions,
    compositeScore,
  };
}

function ratioOfUnits(units: OfficialUnitEntry[]): number | null {
  const homeUnits = units.filter((u) => !u.village || u.village === 'home');
  if (homeUnits.length === 0) return null;
  let lv = 0;
  let maxLv = 0;
  for (const u of homeUnits) {
    const m = Math.max(u.level, u.maxLevel || 0);
    if (m <= 0) continue;
    lv += u.level;
    maxLv += m;
  }
  if (maxLv === 0) return null;
  return Math.min(1, lv / maxLv);
}

// Rough expected hero+troop+warStar benchmarks per TH level for fair TH-normalized scoring
function expectedWarStarsForTh(th: number): number {
  const map: Record<number, number> = {
    3: 15,
    4: 30,
    5: 50,
    6: 80,
    7: 130,
    8: 200,
    9: 300,
    10: 420,
    11: 560,
    12: 720,
    13: 900,
    14: 1100,
    15: 1300,
    16: 1500,
    17: 1700,
    18: 1900,
  };
  return map[Math.max(3, Math.min(18, th))] ?? 400;
}

function expectedTrophiesForTh(th: number): number {
  const map: Record<number, number> = {
    3: 400,
    4: 600,
    5: 900,
    6: 1200,
    7: 1500,
    8: 1900,
    9: 2300,
    10: 2700,
    11: 3100,
    12: 3600,
    13: 4100,
    14: 4600,
    15: 5000,
    16: 5300,
    17: 5500,
    18: 5700,
  };
  return map[Math.max(3, Math.min(18, th))] ?? 2500;
}

function expectedDonationsForTh(th: number): number {
  return Math.max(150, th * 140);
}

export interface PlayerPeriodDelta {
  periodId: '24h' | '7d' | '30d' | '90d' | 'all';
  label: string;
  available: boolean;
  reason?: string;
  fromTimestamp?: string;
  toTimestamp?: string;
  snapshotsUsed: number;
  deltas: {
    townHall: number;
    expLevel: number;
    trophies: number;
    donations: number;
    donationsReceived: number;
    warStars: number;
    capitalContributions: number;
    heroesLevels: number | null;
    troopsLevels: number | null;
    spellsLevels: number | null;
    equipmentLevels: number | null;
    siegeLevels: number | null;
    petsLevels: number | null;
    overallPct: number;
    totalUpgradesCount: number;
  };
}

export function computePlayerPeriodDeltas(
  snapshots: ClanSnapshot[],
  playerTag: string,
  nowMs: number
): PlayerPeriodDelta[] {
  const playerSnaps = snapshots
    .map((s) => ({
      timestamp: s.timestamp,
      ms: new Date(s.timestamp).getTime(),
      entry: s.byPlayer[playerTag],
    }))
    .filter((x): x is { timestamp: string; ms: number; entry: ClanSnapshotPlayerEntry } =>
      Boolean(x.entry)
    )
    .sort((a, b) => a.ms - b.ms);

  const periods: Array<{ id: '24h' | '7d' | '30d' | '90d' | 'all'; label: string; ms: number | null }> = [
    { id: '24h', label: 'Сегодня / Вчера (24 ч)', ms: 24 * 60 * 60 * 1000 },
    { id: '7d', label: 'Последние 7 дней', ms: 7 * 24 * 60 * 60 * 1000 },
    { id: '30d', label: 'Последние 30 дней', ms: 30 * 24 * 60 * 60 * 1000 },
    { id: '90d', label: 'Последние 90 дней', ms: 90 * 24 * 60 * 60 * 1000 },
    { id: 'all', label: 'За весь период сбора', ms: null },
  ];

  const latest = playerSnaps[playerSnaps.length - 1];

  return periods.map((period) => {
    if (playerSnaps.length < 2 || !latest) {
      return {
        periodId: period.id,
        label: period.label,
        available: false,
        reason:
          playerSnaps.length === 0
            ? 'Нет сохранённых снимков для игрока'
            : 'Нужно минимум 2 снимка в разное время для расчёта изменений',
        snapshotsUsed: playerSnaps.length,
        deltas: {
          townHall: 0,
          expLevel: 0,
          trophies: 0,
          donations: 0,
          donationsReceived: 0,
          warStars: 0,
          capitalContributions: 0,
          heroesLevels: null,
          troopsLevels: null,
          spellsLevels: null,
          equipmentLevels: null,
          siegeLevels: null,
          petsLevels: null,
          overallPct: 0,
          totalUpgradesCount: 0,
        },
      };
    }

    let baseline = playerSnaps[0];
    let used = playerSnaps.length;

    if (period.ms !== null) {
      const targetMs = nowMs - period.ms;
      const inRange = playerSnaps.filter((s) => s.ms >= targetMs);
      // Use the snapshot right before cutoff if available, otherwise earliest in range
      const beforeCutoff = [...playerSnaps].reverse().find((s) => s.ms <= targetMs);
      baseline = beforeCutoff ?? inRange[0] ?? playerSnaps[0];
      used = beforeCutoff ? inRange.length + 1 : inRange.length;
    }

    if (baseline.timestamp === latest.timestamp) {
      return {
        periodId: period.id,
        label: period.label,
        available: false,
        reason: 'За этот интервал пока зафиксирован только 1 снимок',
        fromTimestamp: baseline.timestamp,
        toTimestamp: latest.timestamp,
        snapshotsUsed: 1,
        deltas: {
          townHall: 0,
          expLevel: 0,
          trophies: 0,
          donations: 0,
          donationsReceived: 0,
          warStars: 0,
          capitalContributions: 0,
          heroesLevels: null,
          troopsLevels: null,
          spellsLevels: null,
          equipmentLevels: null,
          siegeLevels: null,
          petsLevels: null,
          overallPct: 0,
          totalUpgradesCount: 0,
        },
      };
    }

    const a = baseline.entry;
    const b = latest.entry;
    const diffOpt = (x?: number, y?: number) =>
      x !== undefined && y !== undefined ? y - x : null;

    const heroesDelta = diffOpt(a.heroesLevelSum, b.heroesLevelSum);
    const troopsDelta = diffOpt(a.troopsLevelSum, b.troopsLevelSum);
    const spellsDelta = diffOpt(a.spellsLevelSum, b.spellsLevelSum);
    const equipDelta = diffOpt(a.equipmentLevelSum, b.equipmentLevelSum);
    const siegeDelta = diffOpt(a.siegeLevelSum, b.siegeLevelSum);
    const petsDelta = diffOpt(a.petsLevelSum, b.petsLevelSum);
    const thDelta = b.townHallLevel - a.townHallLevel;

    const totalUpgradesCount =
      Math.max(0, thDelta) +
      Math.max(0, heroesDelta ?? 0) +
      Math.max(0, troopsDelta ?? 0) +
      Math.max(0, spellsDelta ?? 0) +
      Math.max(0, equipDelta ?? 0) +
      Math.max(0, siegeDelta ?? 0) +
      Math.max(0, petsDelta ?? 0);

    return {
      periodId: period.id,
      label: period.label,
      available: true,
      fromTimestamp: baseline.timestamp,
      toTimestamp: latest.timestamp,
      snapshotsUsed: used,
      deltas: {
        townHall: thDelta,
        expLevel: b.expLevel - a.expLevel,
        trophies: b.trophies - a.trophies,
        donations: Math.max(0, b.donations - a.donations),
        donationsReceived: Math.max(0, b.donationsReceived - a.donationsReceived),
        warStars: Math.max(0, b.warStars - a.warStars),
        capitalContributions: Math.max(
          0,
          (b.clanCapitalContributions ?? 0) - (a.clanCapitalContributions ?? 0)
        ),
        heroesLevels: heroesDelta,
        troopsLevels: troopsDelta,
        spellsLevels: spellsDelta,
        equipmentLevels: equipDelta,
        siegeLevels: siegeDelta,
        petsLevels: petsDelta,
        overallPct: Number((b.overallPct - a.overallPct).toFixed(1)),
        totalUpgradesCount,
      },
    };
  });
}

export interface CategoryScoreDetail {
  id: 'account' | 'activity' | 'wars' | 'donations' | 'heroes_troops' | 'capital';
  label: string;
  weightPct: number;
  maxPoints: number;
  score: number;
  hasFullData: boolean;
  note: string;
}

export interface PlayerCompositeRating {
  player: PlayerProfile;
  totalScore: number; // 0..1000
  isPreliminary: boolean;
  missingReasons: string[];
  categories: CategoryScoreDetail[];
  metrics: {
    accountDevPct: number;
    heroesCompletionPct: number | null;
    troopsCompletionPct: number | null;
    activityIndex: number;
    donationNet: number;
    donationGrowth: number;
    warStarsTotal: number;
    warRecentAttacks: number;
    warRecentStars: number;
    warRecentAvgDest: number;
    cwlAttacks: number;
    cwlStars: number;
    cwlThreeStars: number;
    cwlAvgDest: number;
    capitalLootTotal: number;
    capitalAttacksTotal: number;
    capitalContributions: number;
    progress7dPoints: number | null;
    progress30dPoints: number | null;
    upgrades7dCount: number | null;
    upgrades30dCount: number | null;
  };
}

export function computeClanPlayerRatings(
  state: ClanDashboardState,
  nowMs: number = Date.now()
): PlayerCompositeRating[] {
  const players = state.players;
  if (players.length === 0) return [];

  // Aggregate currentWar + war stats per player
  const currentWarStats = new Map<
    string,
    { attacks: number; stars: number; destSum: number; expectedAttacks: number }
  >();
  if (state.currentWar && state.currentWar.state !== 'notInWar') {
    const exp = state.currentWar.attacksPerMember || 2;
    for (const m of state.currentWar.clan.members) {
      const stars = m.attacks.reduce((s, a) => s + a.stars, 0);
      const destSum = m.attacks.reduce((s, a) => s + a.destructionPercentage, 0);
      currentWarStats.set(m.tag, {
        attacks: m.attacks.length,
        stars,
        destSum,
        expectedAttacks: exp,
      });
    }
  }

  // Aggregate CWL stats strictly separately
  const cwlStats = new Map<
    string,
    { attacks: number; stars: number; threeStars: number; avgDest: number }
  >();
  for (const r of state.cwl?.playerRatings ?? []) {
    cwlStats.set(r.tag, {
      attacks: r.attacksUsed,
      stars: r.stars,
      threeStars: r.threeStars,
      avgDest: r.avgDestruction,
    });
  }

  // Aggregate Capital Raid stats across all captured seasons
  const capitalStats = new Map<
    string,
    { attacks: number; limit: number; loot: number }
  >();
  for (const season of state.capitalRaids) {
    for (const m of season.members) {
      const cur = capitalStats.get(m.tag) ?? { attacks: 0, limit: 0, loot: 0 };
      cur.attacks += m.attacks;
      cur.limit += m.attackLimit + m.bonusAttackLimit;
      cur.loot += m.capitalResourcesLooted;
      capitalStats.set(m.tag, cur);
    }
  }

  const maxClanDonations = Math.max(1, ...players.map((p) => p.donations));
  const maxClanAttacksWon = Math.max(1, ...players.map((p) => p.combat.attacksWon));
  const maxClanCapContrib = Math.max(1, ...players.map((p) => p.clanCapitalContributions));
  const hasMultiSnapshots = state.snapshots.length >= 2;

  return players
    .map((p) => {
      const missingReasons: string[] = [];

      // 1. Account Development (25% = 250 pts) - TH-normalized
      const heroRatio = ratioOfUnits(p.apiHeroes);
      const equipRatio = ratioOfUnits(p.apiHeroEquipment);
      const troopRatio = ratioOfUnits(p.apiTroops);
      const spellRatio = ratioOfUnits(p.apiSpells);
      const siegeRatio = ratioOfUnits(p.apiSiegeMachines);
      const petRatio = ratioOfUnits(p.apiPets);

      const availableUnitRatios = [heroRatio, troopRatio, spellRatio, equipRatio, siegeRatio, petRatio].filter(
        (x): x is number => x !== null
      );
      const avgApiUnitRatio =
        availableUnitRatios.length > 0
          ? availableUnitRatios.reduce((a, b) => a + b, 0) / availableUnitRatios.length
          : null;

      // If village JSON was imported, blend verified base progress; otherwise use API unit completion + TH trophy benchmark
      const trophyThRatio = Math.min(1, p.trophies / expectedTrophiesForTh(p.townHallLevel));
      let accountRatio = 0;
      let accountHasFull = false;
      if (p.buildingsVerified) {
        accountRatio = 0.65 * (p.progress.overallPct / 100) + 0.35 * (avgApiUnitRatio ?? 0.5);
        accountHasFull = true;
      } else if (avgApiUnitRatio !== null) {
        accountRatio = 0.85 * avgApiUnitRatio + 0.15 * trophyThRatio;
        accountHasFull = true;
      } else {
        accountRatio = trophyThRatio * 0.5;
        missingReasons.push('Профиль игрока не загружен полностью');
      }
      const accountScore = Math.round(Math.min(250, Math.max(0, accountRatio * 250)));

      // 2. Activity & Progress (20% = 200 pts)
      const periods = computePlayerPeriodDeltas(state.snapshots, p.tag, nowMs);
      const p7d = periods.find((d) => d.periodId === '7d');
      const p30d = periods.find((d) => d.periodId === '30d');
      const pAll = periods.find((d) => d.periodId === 'all');

      const attacksWonNorm = Math.min(1, p.combat.attacksWon / Math.max(10, maxClanAttacksWon * 0.8));
      const seasonActivityRatio =
        0.55 * attacksWonNorm +
        0.45 * Math.min(1, (p.donations + p.donationsReceived) / Math.max(200, expectedDonationsForTh(p.townHallLevel) * 1.5));

      let progressGrowthRatio = 0;
      if (hasMultiSnapshots && pAll?.available) {
        const upgPts = pAll.deltas.totalUpgradesCount;
        const trophyGain = Math.max(0, pAll.deltas.trophies);
        const donGain = pAll.deltas.donations;
        progressGrowthRatio = Math.min(1, upgPts * 0.15 + trophyGain / 300 + donGain / 800);
      } else {
        missingReasons.push('Недостаточно снимков для оценки динамики прогресса');
      }

      const activityRatio = hasMultiSnapshots
        ? 0.6 * seasonActivityRatio + 0.4 * progressGrowthRatio
        : seasonActivityRatio * 0.75; // Honest: cannot fabricate snapshot growth when only 1 snapshot exists
      const activityScore = Math.round(Math.min(200, Math.max(0, activityRatio * 200)));
      const activityIndex = Math.round(
        p.combat.attacksWon * 15 +
          (p.donations + p.donationsReceived) * 0.25 +
          (pAll?.available ? pAll.deltas.totalUpgradesCount * 60 : 0) +
          Math.min(200, p.clanCapitalContributions / 500)
      );

      // 3. War Participation (20% = 200 pts)
      const cw = currentWarStats.get(p.tag);
      const cwl = cwlStats.get(p.tag);
      const thWarExpected = expectedWarStarsForTh(p.townHallLevel);
      const lifetimeWarRatio = Math.min(1, p.warStars / thWarExpected);

      let warScore = 0;
      let warHasFull = false;
      if (cw || cwl) {
        const recentAttacks = (cw?.attacks ?? 0) + (cwl?.attacks ?? 0);
        const recentStars = (cw?.stars ?? 0) + (cwl?.stars ?? 0);
        const avgStars = recentAttacks > 0 ? recentStars / recentAttacks : 0;
        const recentRatio = recentAttacks > 0 ? Math.min(1, (avgStars / 3) * 0.8 + Math.min(1, recentAttacks / 2) * 0.2) : 0;
        warScore = Math.round(Math.min(200, (0.6 * recentRatio + 0.4 * lifetimeWarRatio) * 200));
        warHasFull = true;
      } else if (p.warStars > 0) {
        // Honest partial score from official player warStars normalized by TH; marked preliminary
        warScore = Math.round(Math.min(140, lifetimeWarRatio * 140));
        missingReasons.push('Нет детальных данных текущих атак в КВ/CWL');
      } else {
        missingReasons.push('Нет данных об участии в войнах');
      }

      // 4. Donations (15% = 150 pts) - TH-normalized + clan relative
      const thDonExpected = expectedDonationsForTh(p.townHallLevel);
      const donAbsoluteThNorm = Math.min(1, p.donations / thDonExpected);
      const donRelativeClan = Math.min(1, p.donations / Math.max(100, maxClanDonations * 0.75));
      const balanceFactor =
        p.donations + p.donationsReceived > 0
          ? Math.min(1, (p.donations + 25) / (p.donations + p.donationsReceived + 25) * 1.4)
          : 0;
      const donationsRatio = 0.45 * donAbsoluteThNorm + 0.35 * donRelativeClan + 0.2 * balanceFactor;
      const donationsScore = Math.round(Math.min(150, Math.max(0, donationsRatio * 150)));

      // 5. Heroes & Troops (10% = 100 pts)
      const heroesRatioVal = heroRatio ?? 0;
      const troopsRatioVal =
        troopRatio !== null && spellRatio !== null
          ? 0.7 * troopRatio + 0.3 * spellRatio
          : troopRatio ?? spellRatio ?? 0;
      const htHasData = heroRatio !== null || troopRatio !== null;
      const htRatio =
        heroRatio !== null && troopRatio !== null
          ? 0.55 * heroesRatioVal + 0.45 * troopsRatioVal
          : heroRatio ?? troopRatio ?? 0;
      const heroesTroopsScore = Math.round(Math.min(100, Math.max(0, htRatio * 100)));
      if (!htHasData) missingReasons.push('Не загружены уровни героев и войск');

      // 6. Clan Capital (10% = 100 pts)
      const cap = capitalStats.get(p.tag);
      let capitalScore = 0;
      let capitalHasFull = false;
      if (cap && cap.limit > 0) {
        const atkRatio = Math.min(1, cap.attacks / cap.limit);
        const lootRatio = Math.min(1, cap.loot / 18000);
        const contribRatio = Math.min(1, p.clanCapitalContributions / Math.max(50000, maxClanCapContrib * 0.6));
        capitalScore = Math.round(Math.min(100, (0.45 * atkRatio + 0.35 * lootRatio + 0.2 * contribRatio) * 100));
        capitalHasFull = true;
      } else if (p.clanCapitalContributions > 0) {
        const contribRatio = Math.min(1, p.clanCapitalContributions / Math.max(50000, maxClanCapContrib * 0.7));
        capitalScore = Math.round(Math.min(70, contribRatio * 70));
        missingReasons.push('Нет логов рейдовых выходных Столицы');
      } else {
        missingReasons.push('Нет данных о вкладе в Столицу клана');
      }

      const totalScore =
        accountScore +
        activityScore +
        warScore +
        donationsScore +
        heroesTroopsScore +
        capitalScore;

      const calcProgressPoints = (deltaObj?: PlayerPeriodDelta): number | null => {
        if (!deltaObj || !deltaObj.available) return null;
        return (
          deltaObj.deltas.totalUpgradesCount * 25 +
          Math.max(0, deltaObj.deltas.expLevel) * 10 +
          Math.max(0, Math.round(deltaObj.deltas.trophies / 20)) +
          Math.round(deltaObj.deltas.donations / 50) +
          deltaObj.deltas.warStars * 8
        );
      };

      const uniqueMissing = Array.from(new Set(missingReasons));
      const isPreliminary = uniqueMissing.length > 0;

      const categories: CategoryScoreDetail[] = [
        {
          id: 'account',
          label: 'Развитие аккаунта',
          weightPct: 25,
          maxPoints: 250,
          score: accountScore,
          hasFullData: accountHasFull,
          note: p.buildingsVerified
            ? 'Учтены уровни зданий из JSON и юниты/герои API'
            : 'Оценка по героям, войскам, заклинаниям, питомцам и оборудованию для своего TH',
        },
        {
          id: 'activity',
          label: 'Активность и прогресс',
          weightPct: 20,
          maxPoints: 200,
          score: activityScore,
          hasFullData: hasMultiSnapshots,
          note: hasMultiSnapshots
            ? 'Победы в сезоне, донаты и реальный прирост по снимкам'
            : 'Оценка по сезону; для полной оценки прогресса нужно ≥2 снимка',
        },
        {
          id: 'wars',
          label: 'Участие в войнах',
          weightPct: 20,
          maxPoints: 200,
          score: warScore,
          hasFullData: warHasFull,
          note: warHasFull
            ? 'Учтены атаки/звёзды в КВ или CWL и звёзды профиля (норм. по TH)'
            : 'Только общие звёзды КВ (приватный/пустой лог текущих войн)',
        },
        {
          id: 'donations',
          label: 'Пожертвования войск',
          weightPct: 15,
          maxPoints: 150,
          score: donationsScore,
          hasFullData: true,
          note: 'Отправлено войск (норм. по TH), баланс отд./пол. и доля в клане',
        },
        {
          id: 'heroes_troops',
          label: 'Герои и войска',
          weightPct: 10,
          maxPoints: 100,
          score: heroesTroopsScore,
          hasFullData: htHasData,
          note: 'Прогресс уровней героев, войск и заклинаний к максимуму',
        },
        {
          id: 'capital',
          label: 'Столица клана',
          weightPct: 10,
          maxPoints: 100,
          score: capitalScore,
          hasFullData: capitalHasFull,
          note: capitalHasFull
            ? 'Атаки и добыча в рейдах + общий вклад золота столицы'
            : 'Учтён только накопленный вклад в столицу (нет данных рейдовых выходных)',
        },
      ];

      return {
        player: p,
        totalScore,
        isPreliminary,
        missingReasons: uniqueMissing,
        categories,
        metrics: {
          accountDevPct: p.buildingsVerified
            ? p.progress.overallPct
            : avgApiUnitRatio !== null
            ? Number((avgApiUnitRatio * 100).toFixed(1))
            : p.progress.overallPct,
          heroesCompletionPct: heroRatio !== null ? Number((heroRatio * 100).toFixed(1)) : null,
          troopsCompletionPct:
            troopRatio !== null && spellRatio !== null
              ? Number((((0.7 * troopRatio + 0.3 * spellRatio) * 100)).toFixed(1))
              : troopRatio !== null
              ? Number((troopRatio * 100).toFixed(1))
              : null,
          activityIndex,
          donationNet: p.donations - p.donationsReceived,
          donationGrowth: pAll?.available ? pAll.deltas.donations : 0,
          warStarsTotal: p.warStars,
          warRecentAttacks: cw?.attacks ?? 0,
          warRecentStars: cw?.stars ?? 0,
          warRecentAvgDest:
            cw && cw.attacks > 0 ? Number((cw.destSum / cw.attacks).toFixed(1)) : 0,
          cwlAttacks: cwl?.attacks ?? 0,
          cwlStars: cwl?.stars ?? 0,
          cwlThreeStars: cwl?.threeStars ?? 0,
          cwlAvgDest: cwl?.avgDest ?? 0,
          capitalLootTotal: cap?.loot ?? 0,
          capitalAttacksTotal: cap?.attacks ?? 0,
          capitalContributions: p.clanCapitalContributions,
          progress7dPoints: calcProgressPoints(p7d),
          progress30dPoints: calcProgressPoints(p30d),
          upgrades7dCount: p7d?.available ? p7d.deltas.totalUpgradesCount : null,
          upgrades30dCount: p30d?.available ? p30d.deltas.totalUpgradesCount : null,
        },
      };
    })
    .sort((a, b) => b.totalScore - a.totalScore || b.player.trophies - a.player.trophies);
}

export interface MiniLeaderboardRow {
  rank: number;
  tag: string;
  name: string;
  townHallLevel: number;
  valueText: string;
  subText?: string;
}

export interface MiniLeaderboard {
  id: string;
  title: string;
  subtitle: string;
  emptyReason?: string;
  rows: MiniLeaderboardRow[];
}

export function buildElevenLeaderboards(
  state: ClanDashboardState,
  ratings: PlayerCompositeRating[]
): MiniLeaderboard[] {
  const toRows = <T,>(
    items: T[],
    mapFn: (item: T, idx: number) => MiniLeaderboardRow
  ): MiniLeaderboardRow[] => items.map(mapFn);

  // 1. Лучший участник клана (0..1000)
  const board1: MiniLeaderboard = {
    id: 'best_overall',
    title: '1. Лучший участник клана',
    subtitle: 'Общий взвешенный рейтинг (0–1000 баллов)',
    rows: toRows(ratings, (r, i) => ({
      rank: i + 1,
      tag: r.player.tag,
      name: r.player.name,
      townHallLevel: r.player.townHallLevel,
      valueText: `${r.totalScore} / 1000`,
      subText: r.isPreliminary ? 'предв.' : undefined,
    })),
  };

  // 2. Самый активный участник
  const byActivity = [...ratings].sort(
    (a, b) => b.metrics.activityIndex - a.metrics.activityIndex
  );
  const board2: MiniLeaderboard = {
    id: 'most_active',
    title: '2. Самый активный участник',
    subtitle: 'Атаки в сезоне, донаты, вклад в столицу и прирост уровней',
    rows: toRows(byActivity, (r, i) => ({
      rank: i + 1,
      tag: r.player.tag,
      name: r.player.name,
      townHallLevel: r.player.townHallLevel,
      valueText: `${r.metrics.activityIndex.toLocaleString('ru-RU')} инд.`,
      subText: `${r.player.combat.attacksWon} побед`,
    })),
  };

  // 3. Лучший участник по пожертвованиям
  const byDonations = [...ratings].sort(
    (a, b) => b.player.donations - a.player.donations || b.metrics.donationNet - a.metrics.donationNet
  );
  const board3: MiniLeaderboard = {
    id: 'top_donors',
    title: '3. Лучший участник по пожертвованиям',
    subtitle: 'Отдано войск и баланс отправлено/получено',
    rows: toRows(byDonations, (r, i) => ({
      rank: i + 1,
      tag: r.player.tag,
      name: r.player.name,
      townHallLevel: r.player.townHallLevel,
      valueText: `${r.player.donations.toLocaleString('ru-RU')} отд.`,
      subText: `баланс ${r.metrics.donationNet >= 0 ? '+' : ''}${r.metrics.donationNet}`,
    })),
  };

  // 4. Лучший участник по развитию аккаунта
  const byAccount = [...ratings].sort(
    (a, b) => b.metrics.accountDevPct - a.metrics.accountDevPct || b.player.townHallLevel - a.player.townHallLevel
  );
  const board4: MiniLeaderboard = {
    id: 'top_account_dev',
    title: '4. Лучший участник по развитию аккаунта',
    subtitle: 'Завершённость развития для своей Ратуши (TH-нормализация)',
    rows: toRows(byAccount, (r, i) => ({
      rank: i + 1,
      tag: r.player.tag,
      name: r.player.name,
      townHallLevel: r.player.townHallLevel,
      valueText: `${r.metrics.accountDevPct.toFixed(1)}%`,
      subText: `TH${r.player.townHallLevel}`,
    })),
  };

  // 5. Лучший участник по развитию героев
  const byHeroes = [...ratings].sort(
    (a, b) => (b.metrics.heroesCompletionPct ?? -1) - (a.metrics.heroesCompletionPct ?? -1)
  );
  const board5: MiniLeaderboard = {
    id: 'top_heroes',
    title: '5. Лучший участник по развитию героев',
    subtitle: 'Суммарный прогресс уровней героев к максимуму',
    rows: toRows(byHeroes, (r, i) => ({
      rank: i + 1,
      tag: r.player.tag,
      name: r.player.name,
      townHallLevel: r.player.townHallLevel,
      valueText:
        r.metrics.heroesCompletionPct !== null
          ? `${r.metrics.heroesCompletionPct.toFixed(1)}%`
          : 'Нет данных',
    })),
  };

  // 6. Лучший участник по развитию войск
  const byTroops = [...ratings].sort(
    (a, b) => (b.metrics.troopsCompletionPct ?? -1) - (a.metrics.troopsCompletionPct ?? -1)
  );
  const board6: MiniLeaderboard = {
    id: 'top_troops',
    title: '6. Лучший участник по развитию войск',
    subtitle: 'Уровни войск и заклинаний относительно макс. уровней',
    rows: toRows(byTroops, (r, i) => ({
      rank: i + 1,
      tag: r.player.tag,
      name: r.player.name,
      townHallLevel: r.player.townHallLevel,
      valueText:
        r.metrics.troopsCompletionPct !== null
          ? `${r.metrics.troopsCompletionPct.toFixed(1)}%`
          : 'Нет данных',
    })),
  };

  // 7. Лучший участник по результатам войн (строго обычные КВ / warStars, без CWL)
  const hasCurrentWar = ratings.some((r) => r.metrics.warRecentAttacks > 0);
  const byWars = [...ratings].sort((a, b) =>
    hasCurrentWar
      ? b.metrics.warRecentStars - a.metrics.warRecentStars ||
        b.metrics.warRecentAvgDest - a.metrics.warRecentAvgDest ||
        b.player.warStars - a.player.warStars
      : b.player.warStars - a.player.warStars
  );
  const board7: MiniLeaderboard = {
    id: 'top_wars',
    title: '7. Лучший участник по результатам войн',
    subtitle: hasCurrentWar
      ? 'Звёзды и разрушение в текущей КВ (отдельно от CWL)'
      : 'Всего звёзд в войнах (текущая КВ неактивна)',
    rows: toRows(byWars, (r, i) => ({
      rank: i + 1,
      tag: r.player.tag,
      name: r.player.name,
      townHallLevel: r.player.townHallLevel,
      valueText: hasCurrentWar
        ? `${r.metrics.warRecentStars}★ (${r.metrics.warRecentAvgDest}%)`
        : `${r.player.warStars.toLocaleString('ru-RU')}★`,
      subText: hasCurrentWar ? `всего ${r.player.warStars}★` : undefined,
    })),
  };

  // 8. Лучший участник Clan War League (строго CWL)
  const cwlList = [...(state.cwl?.playerRatings ?? [])].sort(
    (a, b) => b.stars - a.stars || b.avgDestruction - a.avgDestruction || b.threeStars - a.threeStars
  );
  const board8: MiniLeaderboard = {
    id: 'top_cwl',
    title: '8. Лучший участник Clan War League',
    subtitle: 'Отдельный рейтинг строго по раундам CWL',
    emptyReason:
      cwlList.length === 0
        ? state.cwl?.unavailableReason || 'Сезон CWL сейчас неактивен или данные не получены из API'
        : undefined,
    rows: toRows(cwlList, (c, i) => ({
      rank: i + 1,
      tag: c.tag,
      name: c.name,
      townHallLevel: c.townHallLevel,
      valueText: `${c.stars}★ (${c.avgDestruction}%)`,
      subText: `${c.attacksUsed} атак · ${c.threeStars}×3★`,
    })),
  };

  // 9. Лучший участник столицы клана
  const byCapital = [...ratings].sort(
    (a, b) =>
      b.metrics.capitalLootTotal - a.metrics.capitalLootTotal ||
      b.metrics.capitalContributions - a.metrics.capitalContributions
  );
  const board9: MiniLeaderboard = {
    id: 'top_capital',
    title: '9. Лучший участник столицы клана',
    subtitle: 'Добыча в рейдовых выходных и общий вклад в Столицу',
    rows: toRows(byCapital, (r, i) => ({
      rank: i + 1,
      tag: r.player.tag,
      name: r.player.name,
      townHallLevel: r.player.townHallLevel,
      valueText:
        r.metrics.capitalLootTotal > 0
          ? `${r.metrics.capitalLootTotal.toLocaleString('ru-RU')} зол.`
          : `${r.metrics.capitalContributions.toLocaleString('ru-RU')} вкл.`,
      subText:
        r.metrics.capitalAttacksTotal > 0
          ? `${r.metrics.capitalAttacksTotal} атак`
          : undefined,
    })),
  };

  // 10. Самый большой прогресс за последние 7 дней
  const p7Available = ratings.filter((r) => r.metrics.progress7dPoints !== null);
  const by7d = [...p7Available].sort(
    (a, b) => (b.metrics.progress7dPoints ?? 0) - (a.metrics.progress7dPoints ?? 0)
  );
  const board10: MiniLeaderboard = {
    id: 'progress_7d',
    title: '10. Прогресс за последние 7 дней',
    subtitle: 'Реальная дельта уровней и показателей по снимкам (≤7 дней)',
    emptyReason:
      by7d.length === 0
        ? 'Накоплено менее 2 снимков за 7 дней — история появится после повторного обновления'
        : undefined,
    rows: toRows(by7d, (r, i) => ({
      rank: i + 1,
      tag: r.player.tag,
      name: r.player.name,
      townHallLevel: r.player.townHallLevel,
      valueText: `+${r.metrics.progress7dPoints ?? 0} очк.`,
      subText: `${r.metrics.upgrades7dCount ?? 0} улучш.`,
    })),
  };

  // 11. Самый большой прогресс за последние 30 дней
  const p30Available = ratings.filter((r) => r.metrics.progress30dPoints !== null);
  const by30d = [...p30Available].sort(
    (a, b) => (b.metrics.progress30dPoints ?? 0) - (a.metrics.progress30dPoints ?? 0)
  );
  const board11: MiniLeaderboard = {
    id: 'progress_30d',
    title: '11. Прогресс за последние 30 дней',
    subtitle: 'Реальная дельта уровней и показателей по снимкам (≤30 дней)',
    emptyReason:
      by30d.length === 0
        ? 'Накоплено менее 2 снимков за 30 дней — история появится после повторного обновления'
        : undefined,
    rows: toRows(by30d, (r, i) => ({
      rank: i + 1,
      tag: r.player.tag,
      name: r.player.name,
      townHallLevel: r.player.townHallLevel,
      valueText: `+${r.metrics.progress30dPoints ?? 0} очк.`,
      subText: `${r.metrics.upgrades30dCount ?? 0} улучш.`,
    })),
  };

  return [
    board1,
    board2,
    board3,
    board4,
    board5,
    board6,
    board7,
    board8,
    board9,
    board10,
    board11,
  ];
}
