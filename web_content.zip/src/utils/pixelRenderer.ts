import { CarModel, DecorItem, FloatingText, Obstacle, Pedestrian, PowerupItem, RoadHazard, SkidMark, TimeOfDay } from '../types.ts';

// Cache rendered car sprites
const spriteCache = new Map<string, HTMLCanvasElement>();

/**
 * Generate high-definition pixel car with detailed 4 wheels, chrome rims, mirrors, lights & glass reflection
 */
export function getCarCanvas(car: CarModel, scale = 3, isBraking = false): HTMLCanvasElement {
  const cacheKey = `${car.id}_${scale}_${isBraking ? 'b' : 'n'}`;
  const cached = spriteCache.get(cacheKey);
  if (cached) return cached;

  const px = car.pixels;
  const w = px[0].length;
  const h = px.length;

  const cv = document.createElement('canvas');
  cv.width = w * scale;
  cv.height = h * scale;
  const ctx = cv.getContext('2d')!;

  // 1. Draw base pixel matrix
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const char = px[y][x];
      let color: string | null = null;

      if (char === '1') color = car.color;
      else if (char === '2') color = car.accent;
      else if (char === '3') color = '#1a252f'; // Windshield / dark glass
      else if (char === '4') color = '#f1c40f'; // Front headlights
      else if (char === '5') color = isBraking ? '#ff1744' : '#c0392b'; // Brake lights
      else if (char === '6') color = '#bdc3c7'; // Chrome bumpers / trim
      else if (char === '7') color = '#111111'; // Base wheel rubber

      if (color) {
        ctx.fillStyle = color;
        ctx.fillRect(x * scale, y * scale, scale, scale);
      }
    }
  }

  spriteCache.set(cacheKey, cv);
  return cv;
}

/**
 * Draw highly detailed car with prominent 4 rubber wheels, chrome alloy rims,
 * front wheel steering angle, headlights, mirrors, windshield glare, and shadows!
 */
export function drawDetailedCar(
  ctx: CanvasRenderingContext2D,
  car: CarModel,
  x: number,
  y: number,
  steerAngle: number = 0, // -1 to +1
  isBraking: boolean = false,
  isPlayer: boolean = false,
  timeOfDay: TimeOfDay = 'day'
) {
  ctx.save();
  ctx.translate(x, y);

  const carW = 48;
  const carH = 74;

  // 1. Ambient Ground Drop Shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
  ctx.beginPath();
  ctx.ellipse(0, 36, 27, 8, 0, 0, Math.PI * 2);
  ctx.fill();

  // 2. Headlight Beams Projection on the road in front
  if (timeOfDay !== 'day' || isPlayer) {
    const beamAlpha = timeOfDay === 'night' ? 0.45 : timeOfDay === 'sunset' ? 0.25 : 0.15;
    const beamLength = timeOfDay === 'night' ? 140 : 90;

    // Left beam
    const leftBeam = ctx.createRadialGradient(-14, -20, 2, -22, -20 - beamLength, 45);
    leftBeam.addColorStop(0, `rgba(255, 245, 180, ${beamAlpha})`);
    leftBeam.addColorStop(1, 'rgba(255, 245, 180, 0)');
    ctx.fillStyle = leftBeam;
    ctx.beginPath();
    ctx.moveTo(-14, -20);
    ctx.lineTo(-40, -20 - beamLength);
    ctx.lineTo(-4, -20 - beamLength);
    ctx.closePath();
    ctx.fill();

    // Right beam
    const rightBeam = ctx.createRadialGradient(14, -20, 2, 22, -20 - beamLength, 45);
    rightBeam.addColorStop(0, `rgba(255, 245, 180, ${beamAlpha})`);
    rightBeam.addColorStop(1, 'rgba(255, 245, 180, 0)');
    ctx.fillStyle = rightBeam;
    ctx.beginPath();
    ctx.moveTo(14, -20);
    ctx.lineTo(4, -20 - beamLength);
    ctx.lineTo(40, -20 - beamLength);
    ctx.closePath();
    ctx.fill();
  }

  // 3. Draw 4 Prominent High-Detail Rubber Wheels with Chrome Hubcaps!
  const wheelW = 9;
  const wheelH = 17;

  const drawWheel = (wx: number, wy: number, angle: number = 0) => {
    ctx.save();
    ctx.translate(wx, wy);
    if (angle !== 0) {
      ctx.rotate(angle * 0.28); // Steer rotation
    }

    // Tire tread rubber (outer black)
    ctx.fillStyle = '#080808';
    ctx.fillRect(-wheelW / 2, -wheelH / 2, wheelW, wheelH);

    // Tire body (dark charcoal)
    ctx.fillStyle = '#1c1c1c';
    ctx.fillRect(-wheelW / 2 + 1, -wheelH / 2 + 1, wheelW - 2, wheelH - 2);

    // Tread grooved lines
    ctx.fillStyle = '#101010';
    ctx.fillRect(-wheelW / 2, -wheelH / 2 + 4, wheelW, 2);
    ctx.fillRect(-wheelW / 2, -wheelH / 2 + 11, wheelW, 2);

    // Chrome alloy wheel rim
    ctx.fillStyle = '#dcdde1';
    ctx.fillRect(-wheelW / 2 + 2, -wheelH / 2 + 4, wheelW - 4, wheelH - 8);

    // Center lug cap
    ctx.fillStyle = '#718093';
    ctx.fillRect(-1, -1, 2, 2);

    ctx.restore();
  };

  // Front-Left Wheel (steers with steerAngle)
  drawWheel(-25, -16, steerAngle);
  // Front-Right Wheel (steers with steerAngle)
  drawWheel(25, -16, steerAngle);
  // Rear-Left Wheel
  drawWheel(-25, 20, 0);
  // Rear-Right Wheel
  drawWheel(25, 20, 0);

  // 4. Draw Main Car Body Pixel Sprite
  const baseCanvas = getCarCanvas(car, 3, isBraking);
  ctx.drawImage(baseCanvas, -carW / 2, -carH / 2);

  // 5. Side Rearview Mirrors (Maréas)
  ctx.fillStyle = car.accent;
  // Left mirror
  ctx.fillRect(-carW / 2 - 3, -15, 4, 6);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(-carW / 2 - 2, -14, 2, 4);

  // Right mirror
  ctx.fillStyle = car.accent;
  ctx.fillRect(carW / 2 - 1, -15, 4, 6);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(carW / 2, -14, 2, 4);

  // 6. Windshield Specular Glass Glare (Diagonal reflection streak)
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.45)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-10, -10);
  ctx.lineTo(6, -26);
  ctx.stroke();

  // 7. Dynamic Brake Lights Glow when braking
  if (isBraking) {
    ctx.fillStyle = 'rgba(255, 0, 50, 0.4)';
    ctx.beginPath();
    ctx.arc(-15, 28, 8, 0, Math.PI * 2);
    ctx.fill();

    ctx.beginPath();
    ctx.arc(15, 28, 8, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

/**
 * Draw classic Algerian Taxi or Heavy Sonacome Truck
 */
export function drawObstacleVehicle(ctx: CanvasRenderingContext2D, obs: Obstacle, car: CarModel, timeOfDay: TimeOfDay = 'day') {
  ctx.save();
  ctx.translate(obs.x, obs.y);

  // Shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
  ctx.beginPath();
  ctx.ellipse(0, 36, 26, 6, 0, 0, Math.PI * 2);
  ctx.fill();

  // Draw detailed car with wheels
  drawDetailedCar(ctx, car, 0, 0, obs.vx * 2, false, false, timeOfDay);

  // If taxi, draw Algerian Taxi yellow roof sign with TAXI letters
  if (obs.type === 'taxi') {
    ctx.fillStyle = '#f39c12';
    ctx.fillRect(-13, -27, 26, 7);
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 6px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('TAXI', 0, -23);
  }

  // If heavy truck, draw extended cargo bed behind
  if (obs.type === 'truck') {
    ctx.fillStyle = '#795548';
    ctx.fillRect(-23, -8, 46, 44);
    ctx.fillStyle = '#4e342e';
    ctx.strokeRect(-23, -8, 46, 44);
    // Cargo crates
    ctx.fillStyle = '#a1887f';
    ctx.fillRect(-18, -4, 16, 16);
    ctx.fillRect(2, -4, 16, 16);
    ctx.fillRect(-18, 16, 16, 16);
    ctx.fillRect(2, 16, 16, 16);
  }

  ctx.restore();
}

/**
 * Draw pedestrian in traditional Algerian attire (Djellaba/Kachabia)
 */
export function drawPedestrian(ctx: CanvasRenderingContext2D, p: Pedestrian) {
  ctx.save();
  ctx.translate(p.x, p.y);

  // Head (Turban / Chechia or head)
  ctx.fillStyle = '#eed9c4';
  ctx.fillRect(-4, -14, 8, 7);

  // Traditional Chechia (Red hat or white turban)
  ctx.fillStyle = p.clothing === 'djellaba' ? '#ffffff' : '#c0392b';
  ctx.fillRect(-5, -17, 10, 4);

  // Body (Djellaba / Robe)
  ctx.fillStyle = p.color;
  ctx.fillRect(-6, -7, 12, 16);

  // Animated feet
  const step = Math.sin(p.frame) * 3;
  ctx.fillStyle = '#333333';
  ctx.fillRect(-4, 9, 3, 4 + step);
  ctx.fillRect(1, 9, 3, 4 - step);

  // Walking staff / cane for elders
  if (p.clothing === 'djellaba') {
    ctx.fillStyle = '#8b5a2b';
    ctx.fillRect(7, -8, 2, 20);
  }

  ctx.restore();
}

/**
 * Draw roadside decor (Camels, Sheep, Palms, Rocks, Cacti)
 */
export function drawDecor(ctx: CanvasRenderingContext2D, d: DecorItem) {
  ctx.save();
  ctx.translate(d.x, d.y);

  if (d.type === 'cactus') {
    // Desert prickly pear / Algerian Cactus (الهندي)
    ctx.fillStyle = '#27ae60';
    ctx.fillRect(-3, -20, 6, 20);
    ctx.fillRect(-9, -14, 6, 8);
    ctx.fillRect(3, -11, 6, 8);
    // Flowers / fruit
    ctx.fillStyle = '#e74c3c';
    ctx.fillRect(-8, -16, 4, 3);
    ctx.fillRect(4, -13, 4, 3);
  } else if (d.type === 'palm') {
    // Sahara Date Palm Tree
    ctx.fillStyle = '#795548';
    ctx.fillRect(-4, -28, 8, 28);
    // Palm fronds
    ctx.fillStyle = '#2e7d32';
    ctx.beginPath();
    ctx.arc(0, -28, 16, 0, Math.PI, true);
    ctx.fill();
    ctx.fillStyle = '#1b5e20';
    ctx.fillRect(-18, -32, 36, 4);
    ctx.fillRect(-14, -26, 28, 4);
  } else if (d.type === 'pine') {
    // Atlas Cedar / Pine tree
    ctx.fillStyle = '#4e342e';
    ctx.fillRect(-3, -8, 6, 8);
    ctx.fillStyle = '#1e392a';
    ctx.beginPath();
    ctx.moveTo(0, -32);
    ctx.lineTo(14, -8);
    ctx.lineTo(-14, -8);
    ctx.closePath();
    ctx.fill();
  } else if (d.type === 'camel') {
    // Sahara Camel (جمل صحراوي)
    ctx.fillStyle = '#c79c5e';
    // Body & hump
    ctx.fillRect(-12, -10, 24, 12);
    ctx.fillRect(-4, -18, 10, 8);
    // Neck & head
    ctx.fillRect(8, -20, 4, 12);
    ctx.fillRect(10, -22, 6, 4);
    // Legs
    ctx.fillRect(-10, 2, 3, 10);
    ctx.fillRect(6, 2, 3, 10);
  } else if (d.type === 'sheep') {
    // Algerian sheep (خروف)
    ctx.fillStyle = '#f5f5f5';
    ctx.fillRect(-8, -6, 16, 10);
    ctx.fillStyle = '#333333';
    ctx.fillRect(8, -8, 4, 6); // head
    ctx.fillRect(-6, 4, 2, 6);  // legs
    ctx.fillRect(4, 4, 2, 6);
  } else if (d.type === 'rock') {
    ctx.fillStyle = '#5d4a30';
    ctx.fillRect(-8, -6, 16, 12);
    ctx.fillStyle = '#8b6f47';
    ctx.fillRect(-5, -4, 10, 5);
  } else if (d.type === 'dune') {
    ctx.fillStyle = 'rgba(210, 166, 121, 0.4)';
    ctx.beginPath();
    ctx.ellipse(0, 0, 30, 12, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

/**
 * Draw Road Hazards (Potholes / Sand traps / Oil slick)
 */
export function drawHazard(ctx: CanvasRenderingContext2D, h: RoadHazard) {
  ctx.save();
  ctx.translate(h.x, h.y);

  if (h.type === 'pothole') {
    // Realistic Algerian pothole (حفرة الطريق)
    ctx.fillStyle = '#1e1712';
    ctx.beginPath();
    ctx.ellipse(0, 0, h.width / 2, h.height / 2, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#3e2e1e';
    ctx.lineWidth = 2;
    ctx.stroke();
  } else if (h.type === 'oil') {
    ctx.fillStyle = 'rgba(18, 22, 28, 0.85)';
    ctx.beginPath();
    ctx.ellipse(0, 0, h.width / 2, h.height / 2, 0.2, 0, Math.PI * 2);
    ctx.fill();
  } else {
    // Sand drift
    ctx.fillStyle = 'rgba(218, 165, 32, 0.65)';
    ctx.beginPath();
    ctx.ellipse(0, 0, h.width / 2, h.height / 2, -0.1, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

/**
 * Draw Collectible Items (Nitro, Couscous, Amrou Coin, Repair Wrench)
 */
export function drawPowerup(ctx: CanvasRenderingContext2D, item: PowerupItem, time: number) {
  if (item.collected) return;

  ctx.save();
  const bob = Math.sin(time * 0.006 + item.id) * 3;
  ctx.translate(item.x, item.y + bob);

  // Sparkle aura
  ctx.fillStyle = 'rgba(255, 215, 0, 0.25)';
  ctx.beginPath();
  ctx.arc(0, 0, 16, 0, Math.PI * 2);
  ctx.fill();

  if (item.type === 'coin') {
    // Golden Amrou PC coin
    ctx.fillStyle = '#f1c40f';
    ctx.beginPath();
    ctx.arc(0, 0, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#b7950b';
    ctx.lineWidth = 2;
    ctx.stroke();
    // 1 / DZD symbol
    ctx.fillStyle = '#7d6608';
    ctx.font = 'bold 9px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('DZ', 0, 0);
  } else if (item.type === 'nitro') {
    // Cyan turbo canister
    ctx.fillStyle = '#00d2d3';
    ctx.fillRect(-6, -10, 12, 20);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(-3, -12, 6, 3);
    ctx.fillStyle = '#ff4757';
    ctx.fillRect(-6, -2, 12, 4);
    // Letter N
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 8px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('N', 0, 4);
  } else if (item.type === 'couscous') {
    // Traditional Algerian Couscous bowl
    ctx.fillStyle = '#e67e22';
    ctx.beginPath();
    ctx.arc(0, 2, 10, 0, Math.PI);
    ctx.fill();
    // Couscous grain mound
    ctx.fillStyle = '#f39c12';
    ctx.beginPath();
    ctx.arc(0, 2, 8, Math.PI, 0);
    ctx.fill();
    // Steam
    ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.fillRect(-3, -7, 2, 4);
    ctx.fillRect(1, -9, 2, 5);
  } else if (item.type === 'repair') {
    // Wrench
    ctx.fillStyle = '#bdc3c7';
    ctx.fillRect(-2, -9, 4, 18);
    ctx.fillRect(-6, -9, 12, 4);
    ctx.fillRect(-6, 5, 12, 4);
  }

  ctx.restore();
}

/**
 * Draw Tire Skid Marks left on the road
 */
export function drawSkidMarks(ctx: CanvasRenderingContext2D, marks: SkidMark[]) {
  ctx.save();
  ctx.strokeStyle = '#111111';
  ctx.lineWidth = 4;
  ctx.lineCap = 'round';

  marks.forEach((m) => {
    ctx.globalAlpha = m.alpha * 0.45;
    ctx.beginPath();
    ctx.moveTo(m.x1, m.y1);
    ctx.lineTo(m.x2, m.y2);
    ctx.stroke();
  });

  ctx.globalAlpha = 1.0;
  ctx.restore();
}

/**
 * Draw Floating Arcade Text ("CLOSE PASS! +100", "CHECKPOINT!")
 */
export function drawFloatingTexts(ctx: CanvasRenderingContext2D, texts: FloatingText[]) {
  ctx.save();
  texts.forEach((ft) => {
    ctx.globalAlpha = Math.max(0, ft.alpha);
    ctx.fillStyle = ft.color;
    ctx.font = 'bold 13px "Press Start 2P", monospace';
    ctx.textAlign = 'center';
    ctx.shadowColor = '#000000';
    ctx.shadowBlur = 6;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 2;
    ctx.fillText(ft.text, ft.x, ft.y);
  });
  ctx.restore();
}

/**
 * Draw background horizon with Algerian monuments and dunes
 */
export function drawHorizon(ctx: CanvasRenderingContext2D, width: number, horizonY: number, silhouette: string, offset: number) {
  ctx.save();

  if (silhouette === 'monument') {
    // Maqam Echahid (مقام الشهيد) on the Algiers skyline
    const monumentX = ((width * 0.7 + offset * 0.05) % width);
    ctx.fillStyle = '#1f2e38';

    // Three palm leaf arches
    ctx.beginPath();
    ctx.moveTo(monumentX - 16, horizonY);
    ctx.quadraticCurveTo(monumentX - 10, horizonY - 45, monumentX, horizonY - 50);
    ctx.quadraticCurveTo(monumentX + 10, horizonY - 45, monumentX + 16, horizonY);
    ctx.lineTo(monumentX + 10, horizonY);
    ctx.quadraticCurveTo(monumentX, horizonY - 35, monumentX - 10, horizonY);
    ctx.closePath();
    ctx.fill();

    // Central eternal flame spire
    ctx.fillRect(monumentX - 2, horizonY - 45, 4, 15);
  } else if (silhouette === 'mountains') {
    // Atlas snow-capped mountain peaks
    ctx.fillStyle = '#2c3e50';
    ctx.beginPath();
    ctx.moveTo(0, horizonY);
    for (let x = 0; x <= width; x += 40) {
      const peak = Math.sin((x + offset * 0.1) * 0.02) * 25 + 20;
      ctx.lineTo(x, horizonY - peak);
    }
    ctx.lineTo(width, horizonY);
    ctx.closePath();
    ctx.fill();

    // Snow caps
    ctx.fillStyle = '#ecf0f1';
    for (let x = 20; x < width; x += 80) {
      const peakX = x;
      const peakY = horizonY - 40;
      ctx.beginPath();
      ctx.moveTo(peakX, peakY);
      ctx.lineTo(peakX + 8, peakY + 12);
      ctx.lineTo(peakX - 8, peakY + 12);
      ctx.closePath();
      ctx.fill();
    }
  } else {
    // Sahara Dunes wave
    ctx.fillStyle = '#a0785a';
    ctx.beginPath();
    ctx.moveTo(0, horizonY);
    for (let x = 0; x <= width; x += 30) {
      const duneH = Math.sin((x + offset * 0.08) * 0.015) * 18 + 12;
      ctx.lineTo(x, horizonY - duneH);
    }
    ctx.lineTo(width, horizonY);
    ctx.closePath();
    ctx.fill();
  }

  ctx.restore();
}
