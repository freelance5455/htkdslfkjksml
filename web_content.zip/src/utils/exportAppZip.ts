import JSZip from 'jszip';

export async function downloadAppZipPackage(showToast?: (msg: string) => void) {
  try {
    if (showToast) showToast('Packaging Handsome AI app zip...');

    const zip = new JSZip();

    // Readme instructions
    const readme = `# Handsome AI — Mobile Creative Intelligence Suite

Handsome AI is a regal midnight purple & metallic gold mobile creative application built with Node.js, Express, React, and Gemini AI (@google/genai).

## 🚀 How to Run on Android (via Termux)

1. Install **Termux** from F-Droid.
2. In Termux, install Node.js:
   \`\`\`bash
   pkg update && pkg install nodejs
   \`\`\`
3. Extract this zip folder or navigate to your app directory:
   \`\`\`bash
   npm install
   \`\`\`
4. Add your Gemini API key in your \`.env\` file:
   \`\`\`env
   GEMINI_API_KEY="your-gemini-api-key"
   PORT=3000
   \`\`\`
5. Start the server:
   \`\`\`bash
   npm run dev
   \`\`\`
6. Open mobile Chrome or Edge on your Android phone and visit:
   \`http://localhost:3000\`

---

## 📱 How to Run as a Native Android App (PWA)

1. Open the hosted URL in Chrome or Edge on your phone.
2. Tap the **three dots (⋮)** menu in the browser.
3. Select **"Add to Home screen"** or **"Install app"**.
4. Handsome AI is now installed on your app drawer with a full-screen, native experience!
`;

    zip.file('README.md', readme);

    // .env.example
    zip.file(
      '.env.example',
      `# GEMINI_API_KEY: Required for Gemini AI API calls
GEMINI_API_KEY="MY_GEMINI_API_KEY"
PORT=3000
`
    );

    // package.json template
    zip.file(
      'package.json',
      JSON.stringify(
        {
          name: 'handsome-ai',
          version: '1.0.0',
          description:
            'Handsome AI - Regal creative intelligence suite for mobile',
          type: 'module',
          scripts: {
            dev: 'tsx server.ts',
            build: 'vite build',
            start: 'node server.ts',
          },
          dependencies: {
            '@google/genai': '^2.4.0',
            express: '^4.21.2',
            dotenv: '^17.2.3',
            react: '^19.0.1',
            'react-dom': '^19.0.1',
            'lucide-react': '^0.546.0',
          },
        },
        null,
        2
      )
    );

    // Generate zip blob
    const content = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(content);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'handsome-ai-app.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    if (showToast) showToast('Handsome AI app package downloaded (.zip)!');
    return true;
  } catch (err) {
    console.error('Error generating app zip:', err);
    if (showToast) showToast('Failed to generate app package');
    return false;
  }
}
