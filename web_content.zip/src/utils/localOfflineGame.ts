import {
  calculateHandPoints,
  canPlayCard,
  chooseBestColorForHand,
  chooseBotMove,
  createUnoFlipDeck,
  formatFaceNameId,
  getCardFace,
  getDefaultColorForSide,
  isColorValidForSide,
  shuffleArray,
} from '../shared/unoEngine';
import {
  COLOR_LABELS_ID,
  type ActionLogEntry,
  type ActiveColor,
  type AvatarId,
  type EmoteBubble,
  type PublicRoomState,
  type RoomSettings,
  type RoundSummary,
  type Side,
  type SoundCue,
  type UnoCardData,
} from '../shared/unoTypes';

const OFFLINE_BOT_NAMES = ['Raka Bot', 'Sinta Bot', 'Bima Bot', 'Nadia Bot', 'Arka Bot'];
const OFFLINE_AVATARS: AvatarId[] = ['diamond', 'flame', 'bolt', 'crown', 'prism', 'spade'];

interface LocalPlayer {
  id: string;
  name: string;
  avatar: AvatarId;
  isBot: boolean;
  isHost: boolean;
  hand: UnoCardData[];
  score: number;
  calledUno: boolean;
  unoVulnerable: boolean;
}

export class LocalOfflineGame {
  private players: LocalPlayer[] = [];
  private settings: RoomSettings = { targetScore: 500, turnSeconds: 0 };
  private activeSide: Side = 'light';
  private activeColor: ActiveColor = 'red';
  private direction: 1 | -1 = 1;
  private currentTurnIndex = 0;
  private roundNumber = 0;
  private phase: PublicRoomState['phase'] = 'LOBBY';
  private drawPile: UnoCardData[] = [];
  private discardPile: UnoCardData[] = [];
  private pendingDrawnCardId: string | null = null;
  private pendingFlipColorPickerPlayerId: string | null = null;
  private lastCue: { id: string; cue: SoundCue } | null = null;
  private lastEventText = 'Siapkan pemain untuk mabar offline.';
  private actionLog: ActionLogEntry[] = [];
  private emotes: EmoteBubble[] = [];
  private roundSummary: RoundSummary | null = null;
  private matchWinnerId: string | null = null;
  private botTimer: ReturnType<typeof setTimeout> | null = null;
  private onChange: (state: PublicRoomState) => void;

  constructor(
    playerName: string,
    avatar: AvatarId,
    mode: 'solo' | 'mabar_lobby',
    onChange: (state: PublicRoomState) => void
  ) {
    this.onChange = onChange;
    const cleanName = playerName.trim() || 'Pemain 1';

    this.players = [
      {
        id: 'local_p1',
        name: cleanName,
        avatar,
        isBot: false,
        isHost: true,
        hand: [],
        score: 0,
        calledUno: false,
        unoVulnerable: false,
      },
    ];

    if (mode === 'solo') {
      this.settings.targetScore = 0;
      for (let i = 0; i < 3; i++) {
        this.players.push({
          id: `bot_${i + 1}`,
          name: OFFLINE_BOT_NAMES[i],
          avatar: OFFLINE_AVATARS[i % OFFLINE_AVATARS.length],
          isBot: true,
          isHost: false,
          hand: [],
          score: 0,
          calledUno: false,
          unoVulnerable: false,
        });
      }
      this.startRound(true);
    } else {
      // Pre-add a second local human player so user can edit or add more players/bots immediately
      this.players.push({
        id: 'local_p2',
        name: 'Pemain 2',
        avatar: OFFLINE_AVATARS.find((a) => a !== avatar) ?? 'diamond',
        isBot: false,
        isHost: false,
        hand: [],
        score: 0,
        calledUno: false,
        unoVulnerable: false,
      });
      this.emit();
    }
  }

  public destroy(): void {
    if (this.botTimer) {
      clearTimeout(this.botTimer);
      this.botTimer = null;
    }
  }

  public addHumanPlayer(name?: string): void {
    if (this.phase !== 'LOBBY' || this.players.length >= 6) return;
    const humanNum = this.players.filter((p) => !p.isBot).length + 1;
    const clean = (name || `Pemain ${humanNum}`).trim().slice(0, 18) || `Pemain ${humanNum}`;
    this.players.push({
      id: `local_p${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
      name: clean,
      avatar: OFFLINE_AVATARS[(this.players.length + 1) % OFFLINE_AVATARS.length],
      isBot: false,
      isHost: false,
      hand: [],
      score: 0,
      calledUno: false,
      unoVulnerable: false,
    });
    this.emit();
  }

  public addBot(): void {
    if (this.phase !== 'LOBBY' || this.players.length >= 6) return;
    const botIdx = this.players.filter((p) => p.isBot).length;
    this.players.push({
      id: `bot_${Date.now().toString(36)}_${botIdx}`,
      name: OFFLINE_BOT_NAMES[botIdx % OFFLINE_BOT_NAMES.length],
      avatar: OFFLINE_AVATARS[botIdx % OFFLINE_AVATARS.length],
      isBot: true,
      isHost: false,
      hand: [],
      score: 0,
      calledUno: false,
      unoVulnerable: false,
    });
    this.emit();
  }

  public renamePlayer(targetId: string, newName: string): void {
    if (this.phase !== 'LOBBY') return;
    const p = this.players.find((x) => x.id === targetId);
    if (!p) return;
    const clean = newName.trim().slice(0, 18);
    if (clean) {
      p.name = clean;
      this.emit();
    }
  }

  public removePlayer(targetId: string): void {
    if (this.phase !== 'LOBBY') return;
    const target = this.players.find((p) => p.id === targetId);
    if (!target || target.isHost) return;
    this.players = this.players.filter((p) => p.id !== targetId);
    this.emit();
  }

  public updateSettings(partial: Partial<RoomSettings>): void {
    if (this.phase !== 'LOBBY') return;
    if (partial.targetScore !== undefined) {
      this.settings.targetScore = partial.targetScore === 0 ? 0 : 500;
    }
    this.emit();
  }

  private addLog(text: string, tone: ActionLogEntry['tone'] = 'neutral'): void {
    this.lastEventText = text;
    this.actionLog.unshift({
      id: `log_${Math.random().toString(36).slice(2, 9)}`,
      text,
      timestamp: Date.now(),
      tone,
    });
    if (this.actionLog.length > 30) this.actionLog.length = 30;
  }

  private setCue(cue: SoundCue): void {
    this.lastCue = { id: `cue_${Math.random().toString(36).slice(2, 9)}`, cue };
  }

  /**
   * In offline pass-and-play, the viewer ("myId") switches to whichever human player's
   * turn it currently is (or the first human player if a bot is taking its turn).
   */
  private getActiveViewer(): LocalPlayer {
    const curr = this.players[this.currentTurnIndex];
    if (this.phase === 'PLAYING' && curr && !curr.isBot) {
      return curr;
    }
    if (this.pendingFlipColorPickerPlayerId) {
      const picker = this.players.find((p) => p.id === this.pendingFlipColorPickerPlayerId);
      if (picker && !picker.isBot) return picker;
    }
    return this.players.find((p) => !p.isBot) ?? this.players[0];
  }

  private emit(): void {
    const now = Date.now();
    this.emotes = this.emotes.filter((e) => now - e.timestamp < 4500);
    const viewer = this.getActiveViewer();

    this.onChange({
      code: 'OFFLINE',
      phase: this.phase,
      settings: { ...this.settings },
      roundNumber: this.roundNumber,
      activeSide: this.activeSide,
      activeColor: this.activeColor,
      direction: this.direction,
      currentTurnIndex: this.currentTurnIndex,
      turnDeadline: null,
      drawPileCount: this.drawPile.length,
      topCard: this.discardPile[this.discardPile.length - 1] ?? null,
      previousCard:
        this.discardPile.length > 1 ? this.discardPile[this.discardPile.length - 2] : null,
      players: this.players.map((p) => ({
        id: p.id,
        name: p.name,
        avatar: p.avatar,
        isBot: p.isBot,
        isHost: p.isHost,
        connected: true,
        cardCount: p.hand.length,
        score: p.score,
        calledUno: p.calledUno,
        unoVulnerable: p.unoVulnerable,
      })),
      myId: viewer.id,
      myHand: [...viewer.hand],
      pendingDrawnCardId:
        this.players[this.currentTurnIndex]?.id === viewer.id ? this.pendingDrawnCardId : null,
      pendingFlipColorPickerPlayerId: this.pendingFlipColorPickerPlayerId,
      lastCue: this.lastCue,
      lastEventText: this.lastEventText,
      actionLog: [...this.actionLog],
      emotes: [...this.emotes],
      roundSummary: this.roundSummary,
      matchWinnerId: this.matchWinnerId,
    });
  }

  private nextIdx(from: number, steps = 1): number {
    const n = this.players.length;
    return (((from + this.direction * steps) % n) + n) % n;
  }

  private drawCards(count: number): UnoCardData[] {
    const out: UnoCardData[] = [];
    for (let i = 0; i < count; i++) {
      if (this.drawPile.length === 0 && this.discardPile.length > 1) {
        const top = this.discardPile.pop()!;
        this.drawPile = shuffleArray(this.discardPile);
        this.discardPile = [top];
      }
      const c = this.drawPile.pop();
      if (c) out.push(c);
    }
    return out;
  }

  public startRound(resetScores: boolean): void {
    if (this.players.length < 2) return;
    if (this.botTimer) {
      clearTimeout(this.botTimer);
      this.botTimer = null;
    }
    if (resetScores) {
      this.roundNumber = 1;
      this.matchWinnerId = null;
      for (const p of this.players) p.score = 0;
    } else {
      this.roundNumber += 1;
    }
    this.phase = 'PLAYING';
    this.activeSide = 'light';
    this.direction = 1;
    this.pendingDrawnCardId = null;
    this.pendingFlipColorPickerPlayerId = null;
    this.roundSummary = null;

    const deck = createUnoFlipDeck();
    for (const p of this.players) {
      p.hand = deck.splice(0, 7);
      p.calledUno = false;
      p.unoVulnerable = false;
    }

    let idx = deck.findIndex((c) => c.light.color !== 'wild' && c.light.value !== 'flip');
    if (idx === -1) idx = 0;
    const [first] = deck.splice(idx, 1);

    this.drawPile = deck;
    this.discardPile = [first];
    this.activeColor =
      first.light.color === 'wild'
        ? getDefaultColorForSide('light')
        : (first.light.color as ActiveColor);

    // Start on the first human player for clean pass-and-play flow
    const firstHumanIdx = this.players.findIndex((p) => !p.isBot);
    this.currentTurnIndex = firstHumanIdx >= 0 ? firstHumanIdx : 0;
    const starter = this.players[this.currentTurnIndex];

    this.addLog(`Ronde ${this.roundNumber} dimulai! Giliran ${starter.name}.`, 'neutral');
    this.setCue('play');
    this.emit();
    this.scheduleBotIfNeeded();
  }

  private scheduleBotIfNeeded(): void {
    if (this.botTimer) {
      clearTimeout(this.botTimer);
      this.botTimer = null;
    }
    if (this.phase !== 'PLAYING') return;

    if (this.pendingFlipColorPickerPlayerId) {
      const picker = this.players.find((p) => p.id === this.pendingFlipColorPickerPlayerId);
      if (picker?.isBot) {
        this.botTimer = setTimeout(() => {
          const best = chooseBestColorForHand(picker.hand, this.activeSide);
          this.chooseFlipColor(picker.id, best);
        }, 700);
      }
      return;
    }

    const curr = this.players[this.currentTurnIndex];
    if (curr?.isBot) {
      this.botTimer = setTimeout(() => {
        this.runBotTurn(curr.id);
      }, 780);
    }
  }

  private runBotTurn(botId: string): void {
    if (this.phase !== 'PLAYING') return;
    const bot = this.players[this.currentTurnIndex];
    if (!bot || bot.id !== botId) return;

    const top = this.discardPile[this.discardPile.length - 1] ?? null;
    const nextP = this.players[this.nextIdx(this.currentTurnIndex, 1)];
    const move = chooseBotMove(
      bot.hand,
      top,
      this.activeColor,
      this.activeSide,
      nextP ? nextP.hand.length : 7
    );

    if (move) {
      if (bot.hand.length === 2 && Math.random() < 0.85) {
        bot.calledUno = true;
      }
      this.playCard(botId, move.card.id, move.chosenColor);
    } else {
      const [drawn] = this.drawCards(1);
      if (!drawn) {
        this.currentTurnIndex = this.nextIdx(this.currentTurnIndex, 1);
        this.emit();
        this.scheduleBotIfNeeded();
        return;
      }
      bot.hand.push(drawn);
      bot.calledUno = false;
      bot.unoVulnerable = false;
      if (canPlayCard(drawn, top, this.activeColor, this.activeSide)) {
        const face = getCardFace(drawn, this.activeSide);
        const chosenColor =
          face.color === 'wild'
            ? chooseBestColorForHand(
                bot.hand.filter((c) => c.id !== drawn.id),
                this.activeSide
              )
            : undefined;
        this.addLog(`${bot.name} mengambil kartu dan langsung memainkannya!`, 'neutral');
        this.playCard(botId, drawn.id, chosenColor);
      } else {
        this.addLog(`${bot.name} mengambil 1 kartu.`, 'neutral');
        this.setCue('draw');
        this.currentTurnIndex = this.nextIdx(this.currentTurnIndex, 1);
        this.emit();
        this.scheduleBotIfNeeded();
      }
    }
  }

  public playCard(playerId: string, cardId: string, chosenColor?: ActiveColor): void {
    if (this.phase !== 'PLAYING' || this.pendingFlipColorPickerPlayerId) return;
    const player = this.players[this.currentTurnIndex];
    if (!player || player.id !== playerId) return;

    const cardIdx = player.hand.findIndex((c) => c.id === cardId);
    if (cardIdx === -1) return;
    const card = player.hand[cardIdx];
    const top = this.discardPile[this.discardPile.length - 1] ?? null;

    if (!canPlayCard(card, top, this.activeColor, this.activeSide)) return;
    const face = getCardFace(card, this.activeSide);
    if (
      face.color === 'wild' &&
      (!chosenColor || !isColorValidForSide(chosenColor, this.activeSide))
    ) {
      return;
    }

    for (const p of this.players) {
      if (p.id !== player.id) p.unoVulnerable = false;
    }

    player.hand.splice(cardIdx, 1);
    this.discardPile.push(card);
    this.pendingDrawnCardId = null;

    if (player.hand.length === 1) {
      if (!player.calledUno) player.unoVulnerable = true;
    } else {
      player.calledUno = false;
      player.unoVulnerable = false;
    }

    if (player.hand.length === 0) {
      this.finishRound(player);
      return;
    }

    this.activeColor = face.color === 'wild' ? chosenColor! : (face.color as ActiveColor);

    let step = 1;
    let cue: SoundCue = 'play';

    switch (face.value) {
      case 'draw1': {
        const victim = this.players[this.nextIdx(this.currentTurnIndex, 1)];
        victim.hand.push(...this.drawCards(1));
        victim.calledUno = false;
        victim.unoVulnerable = false;
        step = 2;
        cue = 'action';
        this.addLog(`${player.name} memainkan +1! ${victim.name} menarik 1 kartu.`, 'action');
        break;
      }
      case 'draw5': {
        const victim = this.players[this.nextIdx(this.currentTurnIndex, 1)];
        victim.hand.push(...this.drawCards(5));
        victim.calledUno = false;
        victim.unoVulnerable = false;
        step = 2;
        cue = 'action';
        this.addLog(`${player.name} melempar +5! ${victim.name} menarik 5 kartu.`, 'action');
        break;
      }
      case 'skip': {
        const skipped = this.players[this.nextIdx(this.currentTurnIndex, 1)];
        step = 2;
        cue = 'action';
        this.addLog(`${player.name} memainkan Skip! ${skipped.name} dilewati.`, 'action');
        break;
      }
      case 'skip_all': {
        step = 0;
        cue = 'action';
        this.addLog(`${player.name} memainkan Skip Semua & main lagi!`, 'action');
        break;
      }
      case 'reverse': {
        this.direction = this.direction === 1 ? -1 : 1;
        cue = 'action';
        if (this.players.length === 2) {
          step = 0;
          this.addLog(`${player.name} memutar arah (2 pemain: main lagi!).`, 'action');
        } else {
          this.addLog(`${player.name} memutar arah permainan!`, 'action');
        }
        break;
      }
      case 'wild': {
        cue = 'action';
        this.addLog(
          `${player.name} memilih warna ${COLOR_LABELS_ID[this.activeColor]}.`,
          'action'
        );
        break;
      }
      case 'wild_draw2': {
        const victim = this.players[this.nextIdx(this.currentTurnIndex, 1)];
        victim.hand.push(...this.drawCards(2));
        victim.calledUno = false;
        victim.unoVulnerable = false;
        step = 2;
        cue = 'action';
        this.addLog(
          `${player.name} memainkan Wild +2 (${COLOR_LABELS_ID[this.activeColor]})!`,
          'action'
        );
        break;
      }
      case 'wild_draw_color': {
        const victim = this.players[this.nextIdx(this.currentTurnIndex, 1)];
        let cnt = 0;
        while (cnt < 16) {
          const [d] = this.drawCards(1);
          if (!d) break;
          victim.hand.push(d);
          cnt++;
          if (d.dark.color === this.activeColor) break;
        }
        victim.calledUno = false;
        victim.unoVulnerable = false;
        step = 2;
        cue = 'action';
        this.addLog(
          `${player.name} memainkan Wild +Warna (${COLOR_LABELS_ID[this.activeColor]})! ${victim.name} menarik ${cnt} kartu.`,
          'action'
        );
        break;
      }
      case 'flip': {
        const nextSide: Side = this.activeSide === 'light' ? 'dark' : 'light';
        this.activeSide = nextSide;
        if (this.discardPile.length > 1) this.discardPile.reverse();
        this.drawPile.reverse();
        const newTop = this.discardPile[this.discardPile.length - 1];
        const newFace = getCardFace(newTop, nextSide);
        cue = nextSide === 'dark' ? 'flip_dark' : 'flip_light';
        if (newFace.color === 'wild') {
          this.activeColor = getDefaultColorForSide(nextSide);
          this.pendingFlipColorPickerPlayerId = player.id;
          this.addLog(
            `FLIP! Meja berbalik ke ${nextSide === 'dark' ? 'Sisi Gelap' : 'Sisi Terang'}!`,
            'flip'
          );
          this.setCue(cue);
          this.emit();
          this.scheduleBotIfNeeded();
          return;
        } else {
          this.activeColor = newFace.color as ActiveColor;
          this.addLog(
            `FLIP! Meja berbalik ke ${nextSide === 'dark' ? 'Sisi Gelap' : 'Sisi Terang'} (${COLOR_LABELS_ID[this.activeColor]}).`,
            'flip'
          );
        }
        break;
      }
      default: {
        this.addLog(
          `${player.name} memainkan ${COLOR_LABELS_ID[this.activeColor]} ${formatFaceNameId(face)}.`,
          'neutral'
        );
        break;
      }
    }

    this.currentTurnIndex = this.nextIdx(this.currentTurnIndex, step);
    this.setCue(cue);
    this.emit();
    this.scheduleBotIfNeeded();
  }

  public chooseFlipColor(playerId: string, color: ActiveColor): void {
    if (this.pendingFlipColorPickerPlayerId !== playerId) return;
    if (!isColorValidForSide(color, this.activeSide)) return;
    const p = this.players.find((x) => x.id === playerId);
    this.activeColor = color;
    this.pendingFlipColorPickerPlayerId = null;
    this.addLog(`${p?.name ?? 'Pemain'} memilih warna ${COLOR_LABELS_ID[color]}.`, 'flip');
    this.currentTurnIndex = this.nextIdx(this.currentTurnIndex, 1);
    this.setCue('action');
    this.emit();
    this.scheduleBotIfNeeded();
  }

  public drawForCurrent(): void {
    if (this.phase !== 'PLAYING' || this.pendingFlipColorPickerPlayerId) return;
    const curr = this.players[this.currentTurnIndex];
    if (!curr || curr.isBot || this.pendingDrawnCardId) return;

    for (const p of this.players) {
      if (p.id !== curr.id) p.unoVulnerable = false;
    }

    const [drawn] = this.drawCards(1);
    if (!drawn) {
      this.currentTurnIndex = this.nextIdx(this.currentTurnIndex, 1);
      this.emit();
      this.scheduleBotIfNeeded();
      return;
    }

    curr.hand.push(drawn);
    curr.calledUno = false;
    curr.unoVulnerable = false;
    this.setCue('draw');

    const top = this.discardPile[this.discardPile.length - 1] ?? null;
    if (canPlayCard(drawn, top, this.activeColor, this.activeSide)) {
      this.pendingDrawnCardId = drawn.id;
      this.addLog(`${curr.name} mengambil 1 kartu (cocok!).`, 'neutral');
      this.emit();
    } else {
      this.addLog(`${curr.name} mengambil 1 kartu.`, 'neutral');
      this.currentTurnIndex = this.nextIdx(this.currentTurnIndex, 1);
      this.emit();
      this.scheduleBotIfNeeded();
    }
  }

  public playDrawnCard(chosenColor?: ActiveColor): void {
    if (!this.pendingDrawnCardId) return;
    const curr = this.players[this.currentTurnIndex];
    if (!curr) return;
    this.playCard(curr.id, this.pendingDrawnCardId, chosenColor);
  }

  public passAfterDraw(): void {
    if (!this.pendingDrawnCardId) return;
    const curr = this.players[this.currentTurnIndex];
    this.pendingDrawnCardId = null;
    this.addLog(`${curr?.name ?? 'Pemain'} menyimpan kartu dan melewati giliran.`, 'neutral');
    this.currentTurnIndex = this.nextIdx(this.currentTurnIndex, 1);
    this.emit();
    this.scheduleBotIfNeeded();
  }

  public callUno(): void {
    const viewer = this.getActiveViewer();
    if (viewer.hand.length <= 2) {
      viewer.calledUno = true;
      viewer.unoVulnerable = false;
      this.addLog(`${viewer.name} berteriak UNO!!`, 'uno');
      this.setCue('uno');
      this.emit();
    }
  }

  public catchUno(targetId: string): void {
    const target = this.players.find((p) => p.id === targetId);
    if (!target || !target.unoVulnerable || target.hand.length !== 1) return;
    target.unoVulnerable = false;
    target.calledUno = false;
    target.hand.push(...this.drawCards(2));
    this.addLog(`TERTANGKAP! ${target.name} lupa bilang UNO (+2 kartu)!`, 'penalty');
    this.setCue('penalty');
    this.emit();
  }

  public sendEmote(text: string): void {
    const viewer = this.getActiveViewer();
    this.emotes.push({
      id: `em_${Math.random().toString(36).slice(2, 8)}`,
      playerId: viewer.id,
      playerName: viewer.name,
      text: text.trim().slice(0, 60),
      timestamp: Date.now(),
    });
    this.emit();
  }

  private finishRound(winner: LocalPlayer): void {
    if (this.botTimer) {
      clearTimeout(this.botTimer);
      this.botTimer = null;
    }
    let pts = 0;
    const breakdowns = this.players.map((p) => {
      const handPts = p.id === winner.id ? 0 : calculateHandPoints(p.hand, this.activeSide);
      pts += handPts;
      return {
        playerId: p.id,
        playerName: p.name,
        remainingCards: p.hand.length,
        handPoints: handPts,
        totalScore: p.score,
      };
    });
    winner.score += pts;
    for (const b of breakdowns) {
      if (b.playerId === winner.id) b.totalScore = winner.score;
    }

    this.roundSummary = {
      roundNumber: this.roundNumber,
      winnerId: winner.id,
      winnerName: winner.name,
      pointsEarned: pts,
      playerBreakdowns: breakdowns.sort((a, b) => b.totalScore - a.totalScore),
    };

    const reachedTarget =
      this.settings.targetScore === 0 || winner.score >= this.settings.targetScore;
    if (reachedTarget) {
      this.phase = 'GAME_OVER';
      this.matchWinnerId = winner.id;
      this.addLog(`${winner.name} memenangkan pertandingan (${winner.score} poin)!`, 'win');
    } else {
      this.phase = 'ROUND_OVER';
      this.addLog(`${winner.name} menang Ronde ${this.roundNumber} (+${pts} poin)!`, 'win');
    }
    this.setCue('win');
    this.emit();
  }
}
