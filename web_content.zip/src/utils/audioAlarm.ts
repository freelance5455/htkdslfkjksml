/**
 * Web Audio API synthesizer for reminder alarm chime and vibrations
 */

class AlarmSoundService {
  private audioCtx: AudioContext | null = null;

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  /**
   * Plays a pleasant 3-tone notification chime
   */
  public playChime(): void {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      // Frequencies for bell chime: D5 (587.33), A5 (880.00), D6 (1174.66)
      const notes = [
        { freq: 587.33, start: now + 0.0, dur: 0.35 },
        { freq: 783.99, start: now + 0.18, dur: 0.35 },
        { freq: 1046.50, start: now + 0.36, dur: 0.65 },
      ];

      notes.forEach(({ freq, start, dur }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, start);

        gain.gain.setValueAtTime(0, start);
        gain.gain.linearRampToValueAtTime(0.28, start + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, start + dur);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(start);
        osc.stop(start + dur);
      });

      // Vibrate mobile device if supported
      this.vibrate([150, 80, 150]);
    } catch (err) {
      console.warn('Audio chime playback error:', err);
    }
  }

  /**
   * Plays full alarm sequence for critical reminder
   */
  public playUrgentAlarm(): void {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      // 2 sets of double chimes
      [0, 0.45].forEach((offset) => {
        const t = now + offset;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(880, t);
        osc.frequency.setValueAtTime(1320, t + 0.12);

        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.35, t + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.38);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(t);
        osc.stop(t + 0.4);
      });

      this.vibrate([250, 100, 250, 100, 400]);
    } catch (err) {
      console.warn('Urgent alarm playback error:', err);
    }
  }

  public vibrate(pattern: number[] = [200, 100, 200]): void {
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch (err) {
        // Ignored if user hasn't interacted yet
      }
    }
  }
}

export const alarmAudio = new AlarmSoundService();
