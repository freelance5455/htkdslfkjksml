import test from 'node:test';
import assert from 'node:assert/strict';
import { createAppExport, validateImportData } from './appImportExport';
import { TravelTrip, WalletDocument, UserProfile } from '../types';

test('App Import & Export Utility', async (t) => {
  const mockUser: UserProfile = {
    id: 'usr-test',
    fullName: 'Test Traveler',
    email: 'test@travel.dz',
    phone: '+213 555 123 456',
    nationality: 'Algerian',
    avatarUrl: 'https://avatar.test',
    role: 'client',
    language: 'ar',
    currency: 'DZD',
    isLoggedIn: true,
  };

  const mockTrip: TravelTrip = {
    id: 'trip-001',
    destinationCity: 'إسطنبول (Istanbul)',
    destinationCountry: 'تركيا',
    startDate: '12 Dec 2026',
    endDate: '19 Dec 2026',
    status: 'upcoming',
    flightInfo: {
      airline: 'Turkish Airlines',
      flightNumber: 'TK 652',
      departureTime: '08:20 AM',
      origin: 'ALG',
      destination: 'IST',
      terminal: 'T4',
      gate: '16',
      seat: '14A',
      boardingGroup: 'B',
      guardianStatus: 'on_time',
      statusNote: 'On time',
    },
    hotelInfo: {
      name: 'Swissôtel The Bosphorus',
      address: 'Macka, Istanbul',
      checkIn: '14:00',
      checkOut: '12:00',
      roomType: 'Deluxe Room',
    },
    timeline: [],
    weather: { temperatureC: 18, condition: 'Sunny', icon: '☀️' },
    voucherCode: 'TAKI-001',
  };

  const mockDocs: WalletDocument[] = [
    {
      id: 'doc-001',
      title: 'Boarding Pass ALG-IST',
      category: 'boarding_pass',
      documentNumber: 'BP-99881',
      passengerName: 'Test Traveler',
      issueDate: '2026-11-01',
      qrCodeData: 'https://takigo.dz/pass/99881',
      offlineReady: true,
      fileSize: '1.2 MB',
    },
  ];

  await t.test('creates structured export backup accurately', () => {
    const backup = createAppExport(mockTrip, mockDocs, mockUser);
    assert.equal(backup.version, '1.2.0');
    assert.equal(backup.source, 'TAKI-GO | Tourism By Taki');
    assert.equal(backup.metadata.totalDocuments, 1);
    assert.equal(backup.metadata.destinationCity, 'إسطنبول (Istanbul)');
    assert.equal(backup.user?.fullName, 'Test Traveler');
    assert.equal(backup.activeTrip?.id, 'trip-001');
  });

  await t.test('validates valid imported JSON successfully', () => {
    const backup = createAppExport(mockTrip, mockDocs, mockUser);
    const jsonStr = JSON.stringify(backup);

    const result = validateImportData(jsonStr);
    assert.equal(result.valid, true);
    assert.equal(result.summary?.hasTrip, true);
    assert.equal(result.summary?.tripDestination, 'إسطنبول (Istanbul)');
    assert.equal(result.summary?.documentsCount, 1);
    assert.equal(result.summary?.userName, 'Test Traveler');
  });

  await t.test('rejects empty, invalid or corrupt JSON imports', () => {
    const res1 = validateImportData('');
    assert.equal(res1.valid, false);

    const res2 = validateImportData('{ bad json string }');
    assert.equal(res2.valid, false);

    const res3 = validateImportData(JSON.stringify({ randomKey: 'no trip or docs' }));
    assert.equal(res3.valid, false);
    assert.ok(res3.error?.includes('Unsupported backup format'));
  });
});
