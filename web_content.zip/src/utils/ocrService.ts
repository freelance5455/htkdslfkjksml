import { createWorker } from 'tesseract.js';
import { OcrResultItem } from '../types';

export const SUPPORTED_OCR_LANGUAGES = [
  { code: 'eng', name: 'English' },
  { code: 'spa', name: 'Spanish (Español)' },
  { code: 'fra', name: 'French (Français)' },
  { code: 'deu', name: 'German (Deutsch)' },
  { code: 'ita', name: 'Italian (Italiano)' },
  { code: 'por', name: 'Portuguese (Português)' },
  { code: 'chi_sim', name: 'Chinese (Simplified)' },
  { code: 'jpn', name: 'Japanese (日本語)' },
  { code: 'kor', name: 'Korean (한국어)' },
  { code: 'rus', name: 'Russian (Русский)' },
  { code: 'ara', name: 'Arabic (العربية)' },
  { code: 'hin', name: 'Hindi (हिन्दी)' }
];

export interface OcrProgressCallback {
  (progress: { status: string; progress: number; currentItem?: number; totalItems?: number }): void;
}

// Enhance image on canvas prior to OCR for maximum accuracy
export async function preprocessImageForOcr(imageSource: string | File | Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(typeof imageSource === 'string' ? imageSource : URL.createObjectURL(imageSource));
        return;
      }

      // Scale to appropriate OCR resolution (around 1800-2400px width)
      let width = img.naturalWidth;
      let height = img.naturalHeight;
      const maxDim = 2400;
      if (width > maxDim || height > maxDim) {
        if (width > height) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }

      canvas.width = width;
      canvas.height = height;

      // Draw original
      ctx.drawImage(img, 0, 0, width, height);

      // Contrast enhancement and grayscale preprocessing
      try {
        const imgData = ctx.getImageData(0, 0, width, height);
        const data = imgData.data;

        for (let i = 0; i < data.length; i += 4) {
          // Standard ITU-R BT.601 luminance
          const gray = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
          // Slight contrast stretch
          const contrasted = Math.min(255, Math.max(0, (gray - 128) * 1.25 + 128));
          data[i] = contrasted;
          data[i + 1] = contrasted;
          data[i + 2] = contrasted;
        }

        ctx.putImageData(imgData, 0, 0);
        resolve(canvas.toDataURL('image/png'));
      } catch (e) {
        // Fallback to original image if tainted canvas
        resolve(canvas.toDataURL('image/png'));
      }
    };

    img.onerror = (err) => reject(err);

    if (typeof imageSource === 'string') {
      img.src = imageSource;
    } else {
      img.src = URL.createObjectURL(imageSource);
    }
  });
}

// Perform OCR on a single image file or data URL
export async function performOcr(
  imageSource: string | File | Blob,
  fileName: string = 'Captured Image',
  language: string = 'eng',
  onProgress?: OcrProgressCallback
): Promise<OcrResultItem> {
  const itemId = 'ocr-' + Math.random().toString(36).substring(2, 9);
  let dataUrl = typeof imageSource === 'string' ? imageSource : URL.createObjectURL(imageSource);

  try {
    onProgress?.({ status: 'Preprocessing image for contrast & clarity...', progress: 0.1 });
    const preprocessedUrl = await preprocessImageForOcr(imageSource);
    dataUrl = preprocessedUrl;

    onProgress?.({ status: `Initializing ${language} OCR engine...`, progress: 0.25 });

    const worker = await createWorker(language);

    onProgress?.({ status: 'Extracting text and layout structure...', progress: 0.5 });
    const ret = await worker.recognize(preprocessedUrl);

    onProgress?.({ status: 'Finalizing extraction...', progress: 0.95 });
    await worker.terminate();

    const text = ret.data.text.trim();
    const confidence = Math.round(ret.data.confidence || 90);

    // Heuristically extract paragraphs and blocks
    const lines = text.split('\n').filter(l => l.trim().length > 0);
    const detectedBlocks = lines.map(line => {
      let type: 'paragraph' | 'heading' | 'table' = 'paragraph';
      if (/^(#|\d+\.\s+[A-Z]|[A-Z\s]{4,}$)/.test(line) && line.length < 80) {
        type = 'heading';
      } else if (line.includes('|')) {
        type = 'table';
      }
      return { text: line, type };
    });

    onProgress?.({ status: 'Completed', progress: 1.0 });

    return {
      id: itemId,
      imageName: fileName,
      imageDataUrl: dataUrl,
      extractedText: text || 'No readable text was detected in the specified image area.',
      confidence,
      status: 'completed',
      language,
      detectedBlocks
    };
  } catch (err: any) {
    console.error('OCR recognition error:', err);
    return {
      id: itemId,
      imageName: fileName,
      imageDataUrl: dataUrl,
      extractedText: '',
      confidence: 0,
      status: 'error',
      errorMessage: err?.message || 'Failed to extract text from image',
      language
    };
  }
}

// Batch OCR processing
export async function performBatchOcr(
  images: Array<{ file?: File; dataUrl?: string; name: string }>,
  language: string = 'eng',
  onProgress?: OcrProgressCallback
): Promise<OcrResultItem[]> {
  const results: OcrResultItem[] = [];

  for (let i = 0; i < images.length; i++) {
    const item = images[i];
    const source = item.file || item.dataUrl!;
    
    onProgress?.({
      status: `Processing image ${i + 1} of ${images.length} (${item.name})...`,
      progress: (i / images.length),
      currentItem: i + 1,
      totalItems: images.length
    });

    const result = await performOcr(source, item.name, language, (sub) => {
      const overall = (i / images.length) + (sub.progress / images.length);
      onProgress?.({
        status: `[${i + 1}/${images.length}] ${sub.status}`,
        progress: overall,
        currentItem: i + 1,
        totalItems: images.length
      });
    });

    results.push(result);
  }

  onProgress?.({ status: 'Batch OCR Complete', progress: 1.0, currentItem: images.length, totalItems: images.length });
  return results;
}
