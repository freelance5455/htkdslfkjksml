// Heuristic detector & converter for legacy Bijoy / SutonnyMJ ANSI-encoded Bangla text in PDFs.

const BIJOY_CHAR_MAP: Record<string, string> = {
  'Av': 'আ',
  'A': 'অ',
  'B': 'ই',
  'C': 'ঈ',
  'D': 'উ',
  'E': 'ঊ',
  'F': 'ঋ',
  'G': 'এ',
  'H': 'ঐ',
  'I': 'ও',
  'J': 'ঔ',
  'K': 'ক',
  'L': 'খ',
  'M': 'গ',
  'N': 'ঘ',
  'O': 'ঙ',
  'P': 'চ',
  'Q': 'ছ',
  'R': 'জ',
  'S': 'ঝ',
  'T': 'ঞ',
  'U': 'ট',
  'V': 'ঠ',
  'W': 'ড',
  'X': 'ঢ',
  'Y': 'ণ',
  'Z': 'ত',
  '_': 'থ',
  '`': 'দ',
  'a': 'ধ',
  'b': 'ন',
  'c': 'প',
  'd': 'ফ',
  'e': 'ব',
  'f': 'ভ',
  'g': 'ম',
  'h': 'য',
  'i': 'র',
  'j': 'ল',
  'k': 'শ',
  'l': 'ষ',
  'm': 'স',
  'n': 'হ',
  'o': 'ড়',
  'p': 'ঢ়',
  'q': 'য়',
  'r': 'ৎ',
  's': 'ং',
  't': 'ঃ',
  'u': 'ঁ',
  'v': 'া',
  'w': 'ি',
  'x': 'ী',
  'y': 'ু',
  '~': 'ূ',
  '„': 'ৃ',
  '‡': 'ে',
  '‰': 'ৈ',
  'Š': 'ৌ',
  '†': 'ে',
  'ˆ': 'ৈ',
  '&': '্',
  'ª': '্র',
  '«': '্র',
  '¨': '্য',
  '©': 'র্',
  '°': '০',
  '±': '১',
  '²': '২',
  '³': '৩',
  '´': '৪',
  'µ': '৫',
  '¶': '৬',
  '·': '৭',
  '¸': '৮',
  '¹': '৯',
  '0': '০',
  '1': '১',
  '2': '২',
  '3': '৩',
  '4': '৪',
  '5': '৫',
  '6': '৬',
  '7': '৭',
  '8': '৮',
  '9': '৯',
  '|': '।',
  'Ô': '‘',
  'Õ': '’',
  'Ò': '“',
  'Ó': '”',
};

const BIJOY_CONJUNCT_MAP: Record<string, string> = {
  '¶': 'ক্ষ',
  'ÿ': 'ক্ষ',
  'Á': 'জ্ঞ',
  'Ä': 'ঞ্জ',
  'Å': 'ঞ্ছ',
  'Æ': 'ঞ্জ',
  'Ç': 'ট্ট',
  'È': 'ড্ড',
  'É': 'ণ্ঠ',
  'Ê': 'ণ্ড',
  'Ë': 'ত্ত',
  'Ì': 'ত্থ',
  'Í': 'দ্দ',
  'Î': 'দ্ধ',
  'Ï': 'দ্ব',
  'Ð': 'দ্ম',
  'Ñ': 'ন্ত',
  'Ò': 'ন্থ',
  'Ó': 'ন্দ',
  'Ô': 'ন্ধ',
  'Õ': 'ন্ন',
  'Ö': 'প্প',
  '×': 'প্ত',
  'Ø': 'প্ন',
  'Ù': 'প্স',
  'Ú': 'ব্ব',
  'Û': 'ব্দ',
  'Ü': 'ব্ধ',
  'Ý': 'ভ্র',
  'Þ': 'ম্ন',
  'ß': 'ম্প',
  'à': 'ম্ভ',
  'á': 'ম্ম',
  'â': 'ল্ক',
  'ã': 'ল্গ',
  'ä': 'ল্ট',
  'å': 'ল্ড',
  'æ': 'ল্প',
  'ç': 'ল্ল',
  'è': 'শ্চ',
  'é': 'শ্ছ',
  'ê': 'ষ্ণ',
  'ë': 'ষ্ট',
  'ì': 'ষ্ঠ',
  'í': 'ষ্ফ',
  'î': 'স্ক',
  'ï': 'স্ট',
  'ð': 'স্ত',
  'ñ': 'স্থ',
  'ò': 'স্ন',
  'ó': 'স্প',
  'ô': 'স্ফ',
  'õ': 'স্ব',
  'ö': 'স্ম',
  '÷': 'স্ল',
  'ø': 'হু',
  'ù': 'হৃ',
  'ú': 'হ্ম',
  'û': 'হ্ল',
  'ü': 'গু',
  'ý': 'রু',
  'þ': 'রূ',
  'K¬': 'ক্ল',
  'Mø': 'গ্ল',
  'cø': 'প্ল',
  'eø': 'ব্ল',
  'gø': 'ম্ল',
  'kø': 'শ্ল',
  '¯‹': 'স্ক',
  '¯’': 'স্থ',
  '¯Í': 'স্ত',
  '¯ú': 'স্প',
  '¯^': 'স্ব',
  '¯§': 'স্ম',
  '¯œ': 'স্ন',
  '¯ø': 'স্ল',
  '”P': 'চ্চ',
  '”Q': 'চ্ছ',
  '¾': 'জ্জ',
  'À': 'জ্ব',
  '•': 'ঙ্',
  '–': 'ঙ্গ',
  '—': 'ঙ্ক',
  '˜': 'ঙ্খ',
  '™': 'ঙ্ঘ',
  'š': 'ক্ষ্ম',
  '›': 'ত্র',
  'œ': 'ত্র',
  'ž': 'দ্র',
  'Ÿ': 'ধ্র',
  '¡': 'প্র',
  '¢': 'ফ্র',
  '£': 'ব্র',
  '¤': 'ভ্র',
  '¥': 'ম্র',
  '¦': 'শ্র',
  '§': 'স্র',
  '¨': '্য',
  '©': 'র্',
  'ª': '্র',
  '«': '্র',
  '¬': '্ল',
};

const PRE_BASE_VOWELS = new Set(['ি', 'ে', 'ৈ']);

export function looksLikeBijoyAnsi(text: string, fontName = ''): boolean {
  if (/sutonny|bijoy|nikoshban|tonny|bangsee/i.test(fontName)) {
    return true;
  }
  // Contains typical Bijoy Latin+symbol patterns and no Unicode Bangla
  const hasBanglaUnicode = /[\u0980-\u09FF]/.test(text);
  if (hasBanglaUnicode) return false;
  const bijoyMarkers = /[‡†ˆ‰Šª«¨©¯°±²³´µ¶·¸¹vwxy~&]{2,}|\b(Avwg|evsjv|Avgv‡`i|cÖwZ|KvRwU)\b/;
  return bijoyMarkers.test(text);
}

export function convertBijoyToUnicode(input: string): string {
  if (!input) return input;
  let result = '';
  let i = 0;

  while (i < input.length) {
    // Check 2-char sequences first
    const two = input.slice(i, i + 2);
    if (two === 'Av') {
      result += 'আ';
      i += 2;
      continue;
    }
    if (two === '‡v' || two === '†v') {
      result += 'ো';
      i += 2;
      continue;
    }
    if (two === '‡Š' || two === '†Š') {
      result += 'ৌ';
      i += 2;
      continue;
    }
    if (BIJOY_CONJUNCT_MAP[two]) {
      result += BIJOY_CONJUNCT_MAP[two];
      i += 2;
      continue;
    }

    const ch = input[i];
    if (BIJOY_CONJUNCT_MAP[ch]) {
      result += BIJOY_CONJUNCT_MAP[ch];
    } else if (BIJOY_CHAR_MAP[ch]) {
      result += BIJOY_CHAR_MAP[ch];
    } else {
      result += ch;
    }
    i += 1;
  }

  // Reorder pre-base vowel signs (ি, ে, ৈ) after the consonant/conjunct cluster
  // In Bijoy, 'w' (ি), '‡'/'†' (ে), '‰'/'ˆ' (ৈ) appear BEFORE the consonant
  const chars = Array.from(result);
  const reordered: string[] = [];
  let idx = 0;
  while (idx < chars.length) {
    const current = chars[idx];
    if (PRE_BASE_VOWELS.has(current) && idx + 1 < chars.length) {
      // Collect consonant + possible hasant chains
      let end = idx + 1;
      while (
        end + 1 < chars.length &&
        (chars[end + 1] === '্' || chars[end] === '্')
      ) {
        if (chars[end] === '্' && end + 1 < chars.length) {
          end += 1;
        } else if (chars[end + 1] === '্' && end + 2 < chars.length) {
          end += 2;
        } else {
          break;
        }
      }
      const cluster = chars.slice(idx + 1, end + 1).join('');
      // Check if followed by া or ৌ to form ো / ৌ
      if (current === 'ে' && end + 1 < chars.length && chars[end + 1] === 'া') {
        reordered.push(cluster, 'ো');
        idx = end + 2;
        continue;
      }
      if (current === 'ে' && end + 1 < chars.length && chars[end + 1] === 'ৗ') {
        reordered.push(cluster, 'ৌ');
        idx = end + 2;
        continue;
      }
      reordered.push(cluster, current);
      idx = end + 1;
      continue;
    }
    reordered.push(current);
    idx += 1;
  }

  return reordered.join('').replace(/অা/g, 'আ');
}
