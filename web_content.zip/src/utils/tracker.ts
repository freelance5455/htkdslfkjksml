import { Activity, ActivityCategory, DayRecord } from '../types';

/**
 * Format a Date object to YYYY-MM-DD in local time
 */
export function formatDate(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Parse a YYYY-MM-DD string into a local Date
 */
export function parseDate(dateStr: string): Date {
  const [year, month, day] = dateStr.split('-').map(Number);
  return new Date(year, month - 1, day);
}

/**
 * Calculate the Day Number (1 - 90) relative to program start date
 */
export function calculateDayNumber(startDateStr: string, targetDateStr: string): number {
  const start = parseDate(startDateStr);
  const target = parseDate(targetDateStr);
  const diffTime = target.getTime() - start.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  const dayNumber = diffDays + 1;
  return Math.max(1, Math.min(90, dayNumber));
}

/**
 * Check if an activity is scheduled for a given date based on its recurrence rule
 */
export function isActivityScheduledForDate(activity: Activity, dateStr: string): boolean {
  if (activity.scheduleType === 'daily') {
    return true;
  }
  const date = parseDate(dateStr);
  const dayOfWeek = date.getDay(); // 0 is Sunday, 1 is Monday...
  if (activity.selectedDays && activity.selectedDays.length > 0) {
    return activity.selectedDays.includes(dayOfWeek);
  }
  return true;
}

/**
 * Get active activities for a specific date
 */
export function getScheduledActivitiesForDate(activities: Activity[], dateStr: string): Activity[] {
  return activities.filter((act) => isActivityScheduledForDate(act, dateStr));
}

/**
 * Calculate completion percentage and task stats for a given day
 */
export function calculateDailyProgress(
  activities: Activity[],
  dayRecord: DayRecord | undefined,
  dateStr: string
): { total: number; completed: number; percentage: number; remaining: number } {
  const scheduled = getScheduledActivitiesForDate(activities, dateStr);
  const total = scheduled.length;
  if (total === 0) {
    return { total: 0, completed: 0, percentage: 100, remaining: 0 };
  }

  if (!dayRecord || !dayRecord.tasks) {
    return { total, completed: 0, percentage: 0, remaining: total };
  }

  let completed = 0;
  for (const act of scheduled) {
    const task = dayRecord.tasks[act.id];
    if (task && task.completed) {
      completed++;
    }
  }

  const percentage = Math.round((completed / total) * 100);
  const remaining = Math.max(0, total - completed);

  return { total, completed, percentage, remaining };
}

/**
 * Calculate total calories and protein consumed for completed meals on a date
 */
export function calculateDailyNutrition(
  activities: Activity[],
  dayRecord: DayRecord | undefined,
  dateStr: string
): { calories: number; protein: number } {
  const nutritionActivities = getScheduledActivitiesForDate(activities, dateStr).filter(
    (a) => a.category === 'nutrition'
  );

  let calories = 0;
  let protein = 0;

  if (dayRecord && dayRecord.tasks) {
    for (const act of nutritionActivities) {
      const task = dayRecord.tasks[act.id];
      if (task && task.completed) {
        calories += act.calories || 0;
        protein += act.protein || 0;
      }
    }
  }

  return { calories, protein };
}

/**
 * Calculate current consecutive streak of completed days (or active tracking days >= 70% completed)
 */
export function calculateStreak(
  history: Record<string, DayRecord>,
  activities: Activity[],
  todayDateStr: string
): number {
  let streak = 0;
  let checkDate = parseDate(todayDateStr);

  // Check today first; if not >= 70% yet, check from yesterday to not break streak mid-day
  const todayRecord = history[todayDateStr];
  const todayProgress = calculateDailyProgress(activities, todayRecord, todayDateStr);
  const todayIsComplete = todayProgress.total > 0 && todayProgress.percentage >= 70;

  if (todayIsComplete) {
    streak++;
    checkDate.setDate(checkDate.getDate() - 1);
  } else {
    // If today is just starting, streak is based on preceding days
    checkDate.setDate(checkDate.getDate() - 1);
  }

  for (let i = 0; i < 90; i++) {
    const dStr = formatDate(checkDate);
    const rec = history[dStr];
    if (!rec) break;

    const prog = calculateDailyProgress(activities, rec, dStr);
    if (prog.total > 0 && prog.percentage >= 70) {
      streak++;
      checkDate.setDate(checkDate.getDate() - 1);
    } else {
      break;
    }
  }

  return streak;
}

/**
 * Calculate consistency percentage for a specific category over a time window
 */
export function calculateCategoryConsistency(
  category: ActivityCategory,
  history: Record<string, DayRecord>,
  activities: Activity[],
  daysBack: number = 30,
  todayDateStr: string
): number {
  const catActivities = activities.filter((a) => a.category === category);
  if (catActivities.length === 0) return 0;

  let totalScheduled = 0;
  let totalCompleted = 0;

  const current = parseDate(todayDateStr);
  for (let i = 0; i < daysBack; i++) {
    const d = new Date(current);
    d.setDate(d.getDate() - i);
    const dStr = formatDate(d);

    const scheduledToday = catActivities.filter((a) => isActivityScheduledForDate(a, dStr));
    totalScheduled += scheduledToday.length;

    const dayRec = history[dStr];
    if (dayRec && dayRec.tasks) {
      for (const act of scheduledToday) {
        if (dayRec.tasks[act.id]?.completed) {
          totalCompleted++;
        }
      }
    }
  }

  if (totalScheduled === 0) return 100;
  return Math.round((totalCompleted / totalScheduled) * 100);
}

/**
 * Calculate sleep duration in minutes from bedtime and wake time strings (HH:mm)
 */
export function calculateSleepDuration(bedtime: string, wakeTime: string): number {
  const [bHour, bMin] = bedtime.split(':').map(Number);
  const [wHour, wMin] = wakeTime.split(':').map(Number);

  let bedMinutes = bHour * 60 + bMin;
  let wakeMinutes = wHour * 60 + wMin;

  if (wakeMinutes <= bedMinutes) {
    wakeMinutes += 24 * 60; // Crosses midnight
  }

  return wakeMinutes - bedMinutes;
}

/**
 * Korean Aesthetic & Lookmaxing daily motivational wisdom
 */
export const KOREAN_MOTIVATIONAL_QUOTES = [
  {
    quote: "True beauty is not a sudden miracle, but an accumulation of quiet discipline.",
    principle: "Jeong-seong (Sincere Devotion)",
    author: "K-Aesthetic Wisdom"
  },
  {
    quote: "Glass skin is born from consistency: barrier repair, hydration, and UV shield every single sunrise.",
    principle: "Pibu-Gwanri (Skin Care Craft)",
    author: "Seoul Dermatologic Maxim"
  },
  {
    quote: "Your posture commands respect before you speak a single syllable. Shoulders back, crown high.",
    principle: "Jase (Poised Bearing)",
    author: "Physique Architecture"
  },
  {
    quote: "Small daily repetitions carve out a chiselled jawline and iron willpower. Respect the process.",
    principle: "Kyun-hyoeng (Balance & Form)",
    author: "GlowUp 90 Principle"
  },
  {
    quote: "Hydration cleanses the blood and radiates from the eyes. Sip deliberately.",
    principle: "Mool-Dae (Pure Hydration)",
    author: "Wellness Philosophy"
  },
  {
    quote: "Rest is when growth hormone sculpts muscle and repairs cellular glow. Honour your sleep window.",
    principle: "Sook-myeon (Deep Rest)",
    author: "Restorative Science"
  },
  {
    quote: "The version of you 90 days from now is built in this exact hour. Don't negotiate with comfort.",
    principle: "Uiji (Indomitable Will)",
    author: "Transformation Code"
  }
];

export function getKoreanMotivationalQuote(dayNumber: number) {
  const index = (dayNumber - 1) % KOREAN_MOTIVATIONAL_QUOTES.length;
  return KOREAN_MOTIVATIONAL_QUOTES[index];
}
