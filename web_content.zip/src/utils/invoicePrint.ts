import type { PurchaseItem, SaleItem } from '../types/pharmacy.ts';

export type PrintableInvoiceType = 'sale' | 'purchase' | 'order';

export type InvoiceSortOrder = 'manual' | 'name_asc' | 'qty_desc' | 'price_desc' | 'expiry_asc';

export interface PrintableInvoiceLine {
  id: string;
  barcode: string;
  medicineName: string;
  unit: string;
  qty: number;
  unitPrice: number;
  expiryDate?: string;
  notes?: string;
}

export interface PrintableInvoiceConfig {
  invoiceNumber: string;
  invoiceType: PrintableInvoiceType;
  customTitle: string;
  date: string;
  /** The name under which the user prints the invoice (issuer warehouse/pharmacy name) */
  issuerName: string;
  issuerSubtitle: string;
  issuerPhone: string;
  /** The target supplier, warehouse, or pharmacy receiving the invoice/order */
  recipientLabel: string;
  recipientName: string;
  recipientPhone: string;
  lines: PrintableInvoiceLine[];
  amountPaid: number;
  discountAmount: number;
  notes: string;
  showPrices: boolean;
  showExpiry: boolean;
  showBarcode: boolean;
  showPaymentSummary: boolean;
  showSignatures: boolean;
}

export const DEFAULT_ISSUER_PRESETS_KEY = 'meshmesh_print_issuer_presets_v1';
export const LAST_ISSUER_CONFIG_KEY = 'meshmesh_print_last_issuer_v1';

export function getSavedIssuerPresets(): string[] {
  if (typeof window === 'undefined') {
    return ['مذخر التمشمش للأدوية والمستلزمات الطبية', 'صيدلية التمشمش المركزية', 'مكتب التمشمش العلمي لتجارة الأدوية'];
  }
  try {
    const raw = localStorage.getItem(DEFAULT_ISSUER_PRESETS_KEY);
    if (!raw) {
      return ['مذخر التمشمش للأدوية والمستلزمات الطبية', 'صيدلية التمشمش المركزية', 'مكتب التمشمش العلمي لتجارة الأدوية'];
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
  } catch {
    // ignore
  }
  return ['مذخر التمشمش للأدوية والمستلزمات الطبية', 'صيدلية التمشمش المركزية', 'مكتب التمشمش العلمي لتجارة الأدوية'];
}

export function saveIssuerPreset(name: string): string[] {
  const trimmed = name.trim();
  if (!trimmed) return getSavedIssuerPresets();
  const current = getSavedIssuerPresets();
  const next = [trimmed, ...current.filter((item) => item !== trimmed)].slice(0, 12);
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(DEFAULT_ISSUER_PRESETS_KEY, JSON.stringify(next));
    } catch {
      // ignore
    }
  }
  return next;
}

export function sortInvoiceLines(
  lines: PrintableInvoiceLine[],
  sortOrder: InvoiceSortOrder
): PrintableInvoiceLine[] {
  const copy = [...lines];
  switch (sortOrder) {
    case 'name_asc':
      return copy.sort((a, b) => a.medicineName.localeCompare(b.medicineName, 'ar'));
    case 'qty_desc':
      return copy.sort((a, b) => b.qty - a.qty || a.medicineName.localeCompare(b.medicineName, 'ar'));
    case 'price_desc':
      return copy.sort(
        (a, b) =>
          b.qty * b.unitPrice - a.qty * a.unitPrice ||
          a.medicineName.localeCompare(b.medicineName, 'ar')
      );
    case 'expiry_asc':
      return copy.sort((a, b) => {
        const ea = a.expiryDate || '9999-12-31';
        const eb = b.expiryDate || '9999-12-31';
        return ea.localeCompare(eb);
      });
    case 'manual':
    default:
      return copy;
  }
}

export function moveInvoiceLine(
  lines: PrintableInvoiceLine[],
  index: number,
  direction: 'up' | 'down'
): PrintableInvoiceLine[] {
  const targetIndex = direction === 'up' ? index - 1 : index + 1;
  if (index < 0 || index >= lines.length || targetIndex < 0 || targetIndex >= lines.length) {
    return lines;
  }
  const copy = [...lines];
  const [moved] = copy.splice(index, 1);
  copy.splice(targetIndex, 0, moved);
  return copy;
}

export function calculatePrintableTotals(
  lines: PrintableInvoiceLine[],
  discountAmount: number = 0,
  amountPaid: number = 0
): {
  subtotal: number;
  totalQty: number;
  discount: number;
  netTotal: number;
  paid: number;
  remaining: number;
} {
  const subtotal = lines.reduce(
    (sum, line) => sum + Math.max(0, Number(line.qty) || 0) * Math.max(0, Number(line.unitPrice) || 0),
    0
  );
  const totalQty = lines.reduce((sum, line) => sum + Math.max(0, Number(line.qty) || 0), 0);
  const discount = Math.min(subtotal, Math.max(0, Number(discountAmount) || 0));
  const netTotal = Math.max(0, subtotal - discount);
  const paid = Math.min(netTotal, Math.max(0, Number(amountPaid) || 0));
  const remaining = Math.max(0, netTotal - paid);

  return {
    subtotal,
    totalQty,
    discount,
    netTotal,
    paid,
    remaining,
  };
}

export function buildPrintableFromSalesGroup(group: {
  date: string;
  buyer: string;
  invoiceTag?: string;
  items: SaleItem[];
  totalAmount: number;
  amountPaid: number;
}, defaultIssuerName?: string): PrintableInvoiceConfig {
  const cleanNote = group.items[0]?.notes
    ? group.items[0].notes.replace(/^\[SINV-[A-Za-z0-9_-]+\]\s*/, '')
    : '';
  return {
    invoiceNumber: group.invoiceTag || `S-${Date.now().toString().slice(-5)}`,
    invoiceType: 'sale',
    customTitle: 'فاتورة بيع وتجهيز أدوية',
    date: group.date || new Date().toISOString().split('T')[0],
    issuerName: defaultIssuerName || getSavedIssuerPresets()[0],
    issuerSubtitle: 'لتجارة وتوزيع الأدوية والمستلزمات الطبية',
    issuerPhone: '',
    recipientLabel: 'معنون إلى الصيدلية / المذخر:',
    recipientName: group.buyer || '',
    recipientPhone: '',
    lines: group.items.map((item) => ({
      id: item.id,
      barcode: item.barcode,
      medicineName: item.medicineName,
      unit: 'باكيت',
      qty: item.qty,
      unitPrice: item.unitPrice,
      expiryDate: item.nearestExpiryBatch,
    })),
    amountPaid: group.amountPaid,
    discountAmount: 0,
    notes: cleanNote,
    showPrices: true,
    showExpiry: true,
    showBarcode: false,
    showPaymentSummary: true,
    showSignatures: true,
  };
}

export function buildPrintableFromPurchasesGroup(group: {
  date: string;
  supplier: string;
  invoiceTag?: string;
  items: PurchaseItem[];
  totalAmount: number;
  amountPaid: number;
}, defaultIssuerName?: string): PrintableInvoiceConfig {
  const cleanNote = group.items[0]?.notes
    ? group.items[0].notes.replace(/^\[INV-[A-Za-z0-9_-]+\]\s*/, '')
    : '';
  return {
    invoiceNumber: group.invoiceTag || `P-${Date.now().toString().slice(-5)}`,
    invoiceType: 'purchase',
    customTitle: 'قائمة طلبية وشراء أدوية (مذخر / مورد)',
    date: group.date || new Date().toISOString().split('T')[0],
    issuerName: defaultIssuerName || getSavedIssuerPresets()[0],
    issuerSubtitle: 'قسم المشتريات والطلبيات الدوائية',
    issuerPhone: '',
    recipientLabel: 'اسم المورد / المذخر المجهز:',
    recipientName: group.supplier || '',
    recipientPhone: '',
    lines: group.items.map((item) => ({
      id: item.id,
      barcode: item.barcode,
      medicineName: item.medicineName,
      unit: 'باكيت',
      qty: item.qty,
      unitPrice: item.unitPrice,
      expiryDate: item.expiryDate,
    })),
    amountPaid: group.amountPaid,
    discountAmount: 0,
    notes: cleanNote,
    showPrices: true,
    showExpiry: true,
    showBarcode: false,
    showPaymentSummary: true,
    showSignatures: true,
  };
}
