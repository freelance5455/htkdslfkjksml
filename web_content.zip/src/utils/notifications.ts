import { MotivationalQuote } from '../types';

export const MOTIVATIONAL_QUOTES: MotivationalQuote[] = [
  {
    quote: "النجاح هو مجموع تفاصيل صغيرة تتكرر يوماً بعد يوم.",
    author: "روبرت كولير",
    category: "الاستمرارية",
  },
  {
    quote: "ابدأ من حيث أنت، واستخدم ما لديك، وافعل ما تستطيع.",
    author: "آرثر آش",
    category: "البدايات",
  },
  {
    quote: "الوقت هو أثمن ما تملكه، وتنظيمه هو أول خطوات السيطرة على مستقبلك.",
    author: "حكمة معاصرة",
    category: "إدارة الوقت",
  },
  {
    quote: "ليس المهم أن تسير بسرعة، المهم ألا تتوقف.",
    author: "كونفوشيوس",
    category: "الإصرار",
  },
  {
    quote: "العلم لا يُنال براحة الجسد، ولكنه يثمر راحة الضمير وشرف المنزلة.",
    author: "الإمام الشافعي",
    category: "طلب العلم",
  },
  {
    quote: "اليوم المنظم يمنحك ساعات إضافية لم تكن تعلم بوجودها.",
    author: "فلسفة الإنجاز",
    category: "الإنتاجية",
  },
  {
    quote: "صحتك وصلاتك وعلمك هي أركان يومك المبارك؛ فاحرص على ألا يُهدم منها ركن.",
    author: "نصيحة يومية",
    category: "التوازن",
  },
];

export function getDailyQuote(seed?: number): MotivationalQuote {
  const dayOfYear = seed !== undefined ? seed : Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 1000 / 60 / 60 / 24);
  const index = Math.abs(dayOfYear) % MOTIVATIONAL_QUOTES.length;
  return MOTIVATIONAL_QUOTES[index];
}

// Gentle audio chime synthesized via Web Audio API
export function playNotificationChime(toneType: 'success' | 'alert' | 'prayer' | 'timer' | 'alarm' | 'click' = 'alert') {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();

    if (toneType === 'click') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.05);
      return;
    }

    if (toneType === 'alarm') {
      // 3 repeating attention pulses
      [0, 0.25, 0.5, 0.75].forEach((offset) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, ctx.currentTime + offset);
        gain.gain.setValueAtTime(0.2, ctx.currentTime + offset);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + offset + 0.18);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + offset);
        osc.stop(ctx.currentTime + offset + 0.18);
      });
      return;
    }

    if (toneType === 'prayer') {
      // Gentle calm bell harmonic
      const freqs = [440, 554.37, 659.25];
      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);

        gain.gain.setValueAtTime(0.15, ctx.currentTime + idx * 0.15);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + idx * 0.15 + 1.2);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(ctx.currentTime + idx * 0.15);
        osc.stop(ctx.currentTime + idx * 0.15 + 1.2);
      });
    } else if (toneType === 'success') {
      // Pleasant upward chord
      [523.25, 659.25, 783.99].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);

        const start = ctx.currentTime + idx * 0.08;
        gain.gain.setValueAtTime(0.12, start);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.5);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(start);
        osc.stop(start + 0.5);
      });
    } else {
      // Dual crisp chime
      [600, 900].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);

        const start = ctx.currentTime + idx * 0.12;
        gain.gain.setValueAtTime(0.1, start);
        gain.gain.exponentialRampToValueAtTime(0.001, start + 0.35);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(start);
        osc.stop(start + 0.35);
      });
    }
  } catch {
    // AudioContext might be blocked until user gesture, safely ignore
  }
}

export async function requestBrowserNotificationPermission(): Promise<boolean> {
  if (!('Notification' in window)) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission !== 'denied') {
    const perm = await Notification.requestPermission();
    return perm === 'granted';
  }
  return false;
}

export function showBrowserNotification(title: string, options?: NotificationOptions) {
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, {
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        ...options,
      });
    } catch {
      // Ignore background restrictions
    }
  }
}
