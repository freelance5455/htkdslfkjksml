/**
 * Background and Web Notifications manager for Waqti
 * Works in background tabs, locked screens, and PWA via Service Worker.
 */

let swRegistration: ServiceWorkerRegistration | null = null;

export async function initNotifications(): Promise<void> {
  if (typeof window === 'undefined') return;

  if ('serviceWorker' in navigator) {
    try {
      const reg = await navigator.serviceWorker.register('/sw.js');
      swRegistration = reg;
    } catch {
      //
    }
  }
}

export function isNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

export function getNotificationPermission(): NotificationPermission {
  if (!isNotificationSupported()) return 'denied';
  return Notification.permission;
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (!isNotificationSupported()) return false;
  try {
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      sendBackgroundNotification('🔔 تفعيل إشعارات وقتي في الخلفية', {
        body: 'رائع! سيصلك تنبيه فوري عند انتهاء مؤقت البومودورو وتذكيرات بالمهام حتى عندما يكون التطبيق في الخلفية 🚀',
      });
      return true;
    }
  } catch {
    //
  }
  return false;
}

export async function sendBackgroundNotification(
  title: string,
  options: {
    body: string;
    tag?: string;
    icon?: string;
  }
) {
  if (!isNotificationSupported() || Notification.permission !== 'granted') {
    return;
  }

  const notificationOptions = {
    body: options.body,
    icon: options.icon || '/favicon.ico',
    badge: '/favicon.ico',
    tag: options.tag || 'waqti-notification',
    dir: 'rtl' as NotificationDirection,
    lang: 'ar',
    vibrate: [200, 100, 200],
  };

  try {
    // Prefer Service Worker showNotification for persistent background support
    if (swRegistration && 'showNotification' in swRegistration) {
      await swRegistration.showNotification(title, notificationOptions);
      return;
    }

    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg) {
        await reg.showNotification(title, notificationOptions);
        return;
      }
    }

    // Direct Notification constructor fallback
    new Notification(title, notificationOptions);
  } catch (err) {
    console.warn('Notification failed:', err);
  }
}
