import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseRawTextToSections,
  getEffectivePageDimensions,
  TEMPLATE_PRESETS,
  PAGE_DIMENSIONS_PT
} from './documentEngine';

test('getEffectivePageDimensions computes orientation correctly', () => {
  const a4Portrait = getEffectivePageDimensions('A4', 'portrait');
  assert.equal(a4Portrait.width, PAGE_DIMENSIONS_PT.A4.width);
  assert.equal(a4Portrait.height, PAGE_DIMENSIONS_PT.A4.height);

  const a4Landscape = getEffectivePageDimensions('A4', 'landscape');
  assert.equal(a4Landscape.width, PAGE_DIMENSIONS_PT.A4.height);
  assert.equal(a4Landscape.height, PAGE_DIMENSIONS_PT.A4.width);

  const letterPortrait = getEffectivePageDimensions('Letter', 'portrait');
  assert.equal(letterPortrait.width, 612.0);
  assert.equal(letterPortrait.height, 792.0);
});

test('parseRawTextToSections extracts headings, lists, tables and paragraphs', () => {
  const sample = `# Introduction
This is the first paragraph.
It spans multiple lines.

## Subsection
- First point
- Second point
- Third point

1. Step one
2. Step two

Col A | Col B | Col C
Val 1 | Val 2 | Val 3

> This is an insightful quote from the author.
`;

  const sections = parseRawTextToSections(sample);
  
  assert.ok(sections.length >= 6, `Expected at least 6 sections, got ${sections.length}`);
  
  const heading = sections.find(s => s.type === 'heading');
  assert.ok(heading, 'Heading should be found');
  assert.equal(heading.content, 'Introduction');

  const subheading = sections.find(s => s.type === 'subheading');
  assert.ok(subheading, 'Subheading should be found');
  assert.equal(subheading.content, 'Subsection');

  const bulletList = sections.find(s => s.type === 'bullet_list');
  assert.ok(bulletList, 'Bullet list should be found');
  assert.ok(bulletList.content.includes('First point'));

  const numberedList = sections.find(s => s.type === 'numbered_list');
  assert.ok(numberedList, 'Numbered list should be found');
  assert.ok(numberedList.content.includes('Step one'));

  const table = sections.find(s => s.type === 'table');
  assert.ok(table, 'Table should be found');
  assert.ok(table.content.includes('Col A'));

  const quote = sections.find(s => s.type === 'quote');
  assert.ok(quote, 'Quote should be found');
  assert.ok(quote.content.includes('insightful quote'));
});

test('TEMPLATE_PRESETS defines all standard templates with required properties', () => {
  const templates = ['academic', 'business', 'report', 'letter', 'notes', 'general'] as const;
  for (const t of templates) {
    const preset = TEMPLATE_PRESETS[t];
    assert.ok(preset, `Preset ${t} must exist`);
    assert.ok(preset.settings.fontFamily, `Font family must be defined for ${t}`);
    assert.ok(preset.settings.margins, `Margins must be defined for ${t}`);
    assert.ok(preset.sampleSections.length > 0, `Sample sections must exist for ${t}`);
  }
});

test('generatePdfBlobWithJsPdf creates a valid PDF blob', async () => {
  const { generatePdfBlobWithJsPdf, DEFAULT_STYLE_SETTINGS } = await import('./documentEngine');
  const sections = [
    { id: '1', type: 'heading' as const, content: 'Test Title' },
    { id: '2', type: 'paragraph' as const, content: 'This is a test paragraph.' }
  ];
  const blob = await generatePdfBlobWithJsPdf('Test Document', sections, DEFAULT_STYLE_SETTINGS);
  assert.ok(blob instanceof Blob, 'Output must be a Blob');
  assert.equal(blob.type, 'application/pdf');
  assert.ok(blob.size > 200, 'Blob size must be non-trivial');
});
