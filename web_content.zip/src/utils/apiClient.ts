export class ClientApiError extends Error {
  statusCode: number;
  reason?: string;
  stage: 'network' | 'timeout' | 'http' | 'parse';

  constructor(
    message: string,
    options: {
      statusCode?: number;
      reason?: string;
      stage: 'network' | 'timeout' | 'http' | 'parse';
    }
  ) {
    super(message);
    this.name = 'ClientApiError';
    this.statusCode = options.statusCode ?? 0;
    this.reason = options.reason;
    this.stage = options.stage;
  }
}

export async function apiFetchJson<T>(
  url: string,
  options?: RequestInit & { timeoutMs?: number }
): Promise<T> {
  const timeoutMs = options?.timeoutMs ?? 20000;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);

  let resp: Response;
  try {
    resp = await fetch(url, {
      ...options,
      signal: ctrl.signal,
      headers: {
        Accept: 'application/json',
        ...(options?.headers ?? {}),
      },
    });
  } catch (err) {
    clearTimeout(timer);
    if (err instanceof Error && err.name === 'AbortError') {
      throw new ClientApiError(
        `Превышено время ожидания ответа от сервера (${Math.round(timeoutMs / 1000)} с).`,
        { stage: 'timeout' }
      );
    }
    const detail = err instanceof Error && err.message ? ` (${err.message})` : '';
    throw new ClientApiError(
      `Network Error: не удалось установить соединение с сервером приложения${detail}. Проверьте, что сервер запущен.`,
      { stage: 'network' }
    );
  } finally {
    clearTimeout(timer);
  }

  const rawText = await resp.text();
  let parsed: Record<string, unknown> | null = null;
  if (rawText.trim()) {
    try {
      parsed = JSON.parse(rawText) as Record<string, unknown>;
    } catch {
      parsed = null;
    }
  }

  if (!resp.ok) {
    const serverMsg =
      parsed && typeof parsed.error === 'string' && parsed.error.trim()
        ? parsed.error
        : `Ошибка сервера (HTTP ${resp.status}${resp.statusText ? ` ${resp.statusText}` : ''}).`;
    throw new ClientApiError(serverMsg, {
      statusCode: resp.status,
      reason: parsed && typeof parsed.reason === 'string' ? parsed.reason : undefined,
      stage: 'http',
    });
  }

  if (!parsed) {
    throw new ClientApiError(
      `Сервер вернул некорректный ответ (не JSON, HTTP ${resp.status}). Возможно, маршрут API недоступен.`,
      { statusCode: resp.status, stage: 'parse' }
    );
  }

  return parsed as T;
}
