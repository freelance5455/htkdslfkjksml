/**
 * Utility for handling photo and video uploads from Android gallery or desktop
 */

export interface ProcessedMedia {
  file: File;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  thumbnailUrl?: string;
  duration?: number;
  fileName: string;
  fileSize: number;
}

/**
 * Reads a File and generates a fast, usable ObjectURL or optimized DataURL
 */
export async function processGalleryUpload(file: File): Promise<ProcessedMedia> {
  const isVideo = file.type.startsWith('video/') || /\.(mp4|webm|mov|m4v)$/i.test(file.name);
  const mediaType: 'image' | 'video' = isVideo ? 'video' : 'image';

  // Read file as base64 or create object URL
  const base64Data = await readFileAsDataURL(file);

  let thumbnailUrl: string | undefined = undefined;
  let duration: number | undefined = undefined;

  if (isVideo) {
    try {
      const videoMeta = await extractVideoMetadata(base64Data);
      thumbnailUrl = videoMeta.thumbnail;
      duration = videoMeta.duration;
    } catch (e) {
      console.warn('Could not extract video thumbnail:', e);
    }
  }

  return {
    file,
    mediaUrl: base64Data,
    mediaType,
    thumbnailUrl,
    duration,
    fileName: file.name,
    fileSize: file.size,
  };
}

function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    // If it's an image and greater than 2MB, compress it
    if (file.type.startsWith('image/') && file.size > 2 * 1024 * 1024) {
      compressImage(file, 1600, 0.85)
        .then(resolve)
        .catch(() => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
      return;
    }

    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function compressImage(file: File, maxDimension: number, quality: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(e.target?.result as string);

        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = reject;
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function extractVideoMetadata(videoSrc: string): Promise<{ thumbnail: string; duration: number }> {
  return new Promise((resolve) => {
    if (!videoSrc) {
      return resolve({ thumbnail: '', duration: 0 });
    }

    try {
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.muted = true;
      video.playsInline = true;

      let hasFinished = false;
      const finish = (result: { thumbnail: string; duration: number }) => {
        if (!hasFinished) {
          hasFinished = true;
          video.removeAttribute('src');
          video.load();
          resolve(result);
        }
      };

      video.onloadedmetadata = () => {
        try {
          video.currentTime = Math.min(1.0, (video.duration || 2) / 2);
        } catch {
          finish({ thumbnail: '', duration: Math.round(video.duration || 0) });
        }
      };

      video.onseeked = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = video.videoWidth || 480;
          canvas.height = video.videoHeight || 640;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const thumbnail = canvas.toDataURL('image/jpeg', 0.7);
            finish({ thumbnail, duration: Math.round(video.duration || 0) });
            return;
          }
        } catch (err) {
          console.warn('Canvas export failed:', err);
        }
        finish({ thumbnail: '', duration: Math.round(video.duration || 0) });
      };

      video.onerror = () => {
        finish({ thumbnail: '', duration: 0 });
      };

      // Timeout safety
      setTimeout(() => {
        finish({ thumbnail: '', duration: 0 });
      }, 3000);

      video.src = videoSrc;
    } catch {
      resolve({ thumbnail: '', duration: 0 });
    }
  });
}
