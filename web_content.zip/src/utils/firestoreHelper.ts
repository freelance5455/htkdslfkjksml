/**
 * Utility to strip undefined properties from an object before passing to Firestore setDoc/updateDoc/addDoc.
 * Firestore throws a runtime error if any property value is undefined.
 */
export function removeUndefinedFields<T>(obj: T): T {
  if (!obj || typeof obj !== 'object') return obj;

  if (Array.isArray(obj)) {
    return obj.map((item) =>
      item !== null && typeof item === 'object' && !(item instanceof Date)
        ? removeUndefinedFields(item)
        : item
    ) as unknown as T;
  }

  const result: Record<string, any> = {};
  for (const [key, val] of Object.entries(obj as Record<string, any>)) {
    if (val !== undefined) {
      if (val !== null && typeof val === 'object' && !(val instanceof Date)) {
        result[key] = removeUndefinedFields(val);
      } else {
        result[key] = val;
      }
    }
  }
  return result as T;
}
