import JSZip from 'jszip';

export async function downloadProjectZip(): Promise<void> {
  const zip = new JSZip();

  const readmeContent = `# Bait ul Ukasha — Home Essentials
Crafted with modern responsive design, offline-first local persistence, and zero paid API dependencies.

## 🚀 Quick Start on Windows

### Prerequisites
1. Download & install **Node.js (LTS version)** from https://nodejs.org
2. Verify installation in Command Prompt or PowerShell:
   \`\`\`cmd
   node -v
   npm -v
   \`\`\`

### Running the Project
1. Extract this ZIP archive into a folder of your choice (e.g. \`C:\\BaitUlUkasha\`).
2. Double-click \`RUN_WINDOWS.bat\` OR open Command Prompt / PowerShell in that directory:
   \`\`\`cmd
   npm install
   npm run dev
   \`\`\`
3. Open your browser and navigate to:
   \`http://localhost:3000\`

---

## 📦 Building an Installable Application

### Option A: Progressive Web App (PWA) / Chrome & Edge Desktop Install (Easiest)
1. Run \`npm run dev\` and open \`http://localhost:3000\` in Google Chrome or Microsoft Edge.
2. Click the install icon in the URL bar (top right) or go to **Menu (...) -> "Cast, save, and share" -> "Install Bait ul Ukasha as App"**.
3. It will install as an isolated Windows Desktop Application with its own taskbar icon and desktop shortcut!

### Option B: Packaging as a Windows .exe with Electron
1. Install Electron in this project:
   \`\`\`cmd
   npm install --save-dev electron electron-builder
   \`\`\`
2. Add a simple \`electron.cjs\` main script:
   \`\`\`js
   const { app, BrowserWindow } = require('electron');
   function createWindow() {
     const win = new BrowserWindow({ width: 1280, height: 850 });
     win.loadURL('http://localhost:3000');
   }
   app.whenReady().then(createWindow);
   \`\`\`
3. Run \`npm run build\` and package it with \`npx electron-builder\`.

---

## 💾 Backing Up Your Files & Local Data
- **Source Code Backup**: Simply keep a copy of this ZIP archive or commit to GitHub/Git.
- **Customer & Order Data Backup**: In the application top navigation, open the **Data & Backup** menu and click **Export Backup (.JSON)**. This creates a portable snapshot of all your cart items, wishlists, orders, shipping addresses, and room checklists.
`;

  const windowsBatScript = `@echo off
echo ====================================================
echo   Starting Bait ul Ukasha Home Essentials Web App
echo ====================================================
echo.

where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js is not found on your system!
    echo Please install Node.js (LTS) from https://nodejs.org
    echo Then run this file again.
    pause
    exit /b
)

echo [1/2] Checking and installing dependencies...
call npm install

echo.
echo [2/2] Launching local development server on port 3000...
echo.
echo Open your browser at http://localhost:3000
call npm run dev

pause
`;

  const packageJsonContent = JSON.stringify({
    name: "bait-ul-ukasha-home-essentials",
    private: true,
    version: "1.0.0",
    type: "module",
    scripts: {
      dev: "vite --port 3000",
      build: "tsc && vite build",
      preview: "vite preview"
    },
    dependencies: {
      "@tailwindcss/vite": "^4.3.3",
      "jszip": "^3.10.1",
      "lucide-react": "^0.546.0",
      "motion": "^12.23.24",
      "react": "^19.0.1",
      "react-dom": "^19.0.1",
      "tailwindcss": "^4.3.3",
      "vite": "^8.3.0"
    },
    devDependencies: {
      "@types/node": "^22.14.0",
      "@types/react": "^19.3.0",
      "@types/react-dom": "^19.3.0",
      "@vitejs/plugin-react": "^6.1.1",
      "typescript": "^7.0.2"
    }
  }, null, 2);

  // Add files to zip
  zip.file('README.md', readmeContent);
  zip.file('RUN_WINDOWS.bat', windowsBatScript);
  zip.file('package.json', packageJsonContent);
  
  // Generate zip file blob and trigger download
  const blob = await zip.generateAsync({ type: 'blob' });
  const downloadUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = downloadUrl;
  anchor.download = 'bait-ul-ukasha-home-essentials-source.zip';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(downloadUrl);
}
