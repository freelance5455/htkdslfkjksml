import { compressImage } from './imageCompressor.ts';
import type { FileAttachmentMetadata } from '../types/index.ts';

export const MAX_ATTACHMENT_SIZE_BYTES = 500 * 1024 * 1024; // 500 MB
export const DEFAULT_CHUNK_SIZE_BYTES = 2 * 1024 * 1024; // 2 MB per chunk

export interface ProcessedMedia {
  messageType: 'image' | 'document' | 'video' | 'voice';
  mediaUrl: string;
  fileName: string;
  fileSizeBytes: number;
  mimeType: string;
  storagePath?: string;
  fileId?: string;
  thumbnailUrl?: string;
}

export interface ValidatedAttachmentFile {
  file: File;
  fileName: string;
  fileSizeBytes: number;
  mimeType: string;
  extension: string;
  messageType: 'image' | 'document' | 'video' | 'voice';
  thumbnailUrl?: string;
  objectPreviewUrl?: string;
}

export interface ResumableUploadProgress {
  uploadId: string;
  fileId: string;
  fileName: string;
  fileSizeBytes: number;
  uploadedBytes: number;
  remainingBytes: number;
  percentage: number;
  speedBytesPerSec: number;
  etaSeconds: number | null;
  status: 'uploading' | 'paused' | 'completed' | 'failed' | 'cancelled';
  error?: string;
}

const BLOCKED_EXTENSIONS = new Set([
  'exe', 'bat', 'cmd', 'sh', 'ps1', 'vbs', 'js', 'mjs', 'cjs', 'msi', 'dll', 'scr', 'com', 'jar', 'php', 'py', 'rb', 'pl', 'apk', 'dmg', 'app', 'html', 'htm', 'svg'
]);

const ALLOWED_EXTENSIONS = new Set([
  'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'ppt', 'pptx', 'txt',
  'jpg', 'jpeg', 'png', 'webp', 'gif',
  'mp4', 'mov', 'webm',
  'mp3', 'wav', 'ogg', 'm4a',
  'zip'
]);

const EXTENSION_TO_MIME: Record<string, string> = {
  pdf: 'application/pdf',
  doc: 'application/msword',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xls: 'application/vnd.ms-excel',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  csv: 'text/csv',
  ppt: 'application/vnd.ms-powerpoint',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  txt: 'text/plain',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  png: 'image/png',
  webp: 'image/webp',
  gif: 'image/gif',
  mp4: 'video/mp4',
  mov: 'video/quicktime',
  webm: 'video/webm',
  mp3: 'audio/mpeg',
  wav: 'audio/wav',
  ogg: 'audio/ogg',
  m4a: 'audio/mp4',
  zip: 'application/zip',
};

export const CHAT_FILE_INPUT_ACCEPT =
  '.pdf,.doc,.docx,.xls,.xlsx,.csv,.ppt,.pptx,.txt,.jpg,.jpeg,.png,.webp,.mp4,.mov,.webm,.zip,image/jpeg,image/png,image/webp,video/mp4,video/quicktime,video/webm,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/zip,text/plain';

export function formatFileSize(bytes?: number): string {
  if (bytes === undefined || bytes === null || isNaN(bytes)) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(kb >= 100 ? 0 : 1)} KB`;
  const mb = kb / 1024;
  if (mb < 1024) return `${mb.toFixed(mb >= 100 ? 1 : 2)} MB`;
  const gb = mb / 1024;
  return `${gb.toFixed(2)} GB`;
}

export function formatUploadSpeed(bytesPerSec: number): string {
  if (!bytesPerSec || bytesPerSec <= 0) return 'Calculating...';
  return `${formatFileSize(bytesPerSec)}/s`;
}

export function getFileExtension(fileName: string): string {
  const parts = String(fileName || '').toLowerCase().trim().split('.');
  return parts.length > 1 ? parts[parts.length - 1] : '';
}

export function getFileTypeLabel(fileName?: string, mimeType?: string): string {
  const ext = getFileExtension(fileName || '');
  if (ext) return ext.toUpperCase();
  if (!mimeType) return 'FILE';
  if (mimeType.includes('pdf')) return 'PDF';
  if (mimeType.includes('word')) return 'DOCX';
  if (mimeType.includes('spreadsheet') || mimeType.includes('excel')) return 'XLSX';
  if (mimeType.includes('presentation') || mimeType.includes('powerpoint')) return 'PPTX';
  if (mimeType.includes('csv')) return 'CSV';
  if (mimeType.includes('zip')) return 'ZIP';
  if (mimeType.startsWith('image/')) return mimeType.replace('image/', '').toUpperCase();
  if (mimeType.startsWith('video/')) return mimeType.replace('video/', '').toUpperCase();
  return 'FILE';
}

/**
 * Validates file size (<= 500 MB), extension, and MIME type BEFORE starting any upload.
 * Does NOT load the entire file into memory.
 */
export async function validateAndPrepareAttachment(file: File): Promise<ValidatedAttachmentFile> {
  if (!file) {
    throw new Error('No file selected.');
  }

  // 1. Validate File Size BEFORE starting upload
  if (file.size <= 0) {
    throw new Error('Selected file is empty (0 bytes).');
  }
  if (file.size > MAX_ATTACHMENT_SIZE_BYTES) {
    throw new Error('File is too large. Maximum supported size is 500 MB.');
  }

  // 2. Validate Extension & MIME type
  const ext = getFileExtension(file.name);
  if (!ext || BLOCKED_EXTENSIONS.has(ext)) {
    throw new Error(`Unsupported or restricted file type (.${ext || 'unknown'}). Executable and script files are not allowed.`);
  }
  if (!ALLOWED_EXTENSIONS.has(ext)) {
    throw new Error(
      `Unsupported file format (.${ext}). Supported formats: PDF, DOCX, XLSX, CSV, PPTX, JPG, JPEG, PNG, WEBP, MP4, MOV, ZIP.`
    );
  }

  const rawMime = (file.type || '').toLowerCase().trim();
  if (
    rawMime.includes('application/x-msdownload') ||
    rawMime.includes('application/x-executable') ||
    rawMime.includes('application/x-sh') ||
    rawMime.includes('text/html') ||
    rawMime.includes('application/javascript')
  ) {
    throw new Error('Unsupported or dangerous MIME type rejected for security.');
  }

  // Verify magic bytes on the first 16 bytes ONLY (using Blob.slice so zero memory bloat on 500MB files)
  await verifyMagicBytesHeader(file, ext);

  const resolvedMime = rawMime || EXTENSION_TO_MIME[ext] || 'application/octet-stream';

  let messageType: 'image' | 'document' | 'video' | 'voice' = 'document';
  if (['jpg', 'jpeg', 'png', 'webp', 'gif'].includes(ext) || resolvedMime.startsWith('image/')) {
    messageType = 'image';
  } else if (['mp4', 'mov', 'webm'].includes(ext) || resolvedMime.startsWith('video/')) {
    messageType = 'video';
  } else if (['mp3', 'wav', 'ogg', 'm4a'].includes(ext) || resolvedMime.startsWith('audio/')) {
    messageType = 'voice';
  }

  // Generate lightweight thumbnail ONLY for reasonable-sized images (< 15 MB)
  let thumbnailUrl: string | undefined = undefined;
  let objectPreviewUrl: string | undefined = undefined;

  if (messageType === 'image') {
    objectPreviewUrl = URL.createObjectURL(file);
    if (file.size <= 15 * 1024 * 1024) {
      try {
        const thumb = await compressImage(file, { maxWidth: 320, maxHeight: 320, quality: 0.7 });
        thumbnailUrl = thumb.dataUrl;
      } catch (e) {
        // Fallback to no inline thumbnail if image decoding fails
      }
    }
  } else if (messageType === 'video' && file.size <= 50 * 1024 * 1024) {
    try {
      thumbnailUrl = await generateLightweightVideoThumbnail(file);
    } catch (e) {
      // Ignore if browser cannot decode video frame
    }
  }

  return {
    file,
    fileName: file.name,
    fileSizeBytes: file.size,
    mimeType: resolvedMime,
    extension: ext,
    messageType,
    thumbnailUrl,
    objectPreviewUrl,
  };
}

/**
 * Inspects only the first 8 bytes via file.slice(0, 8) to block disguised executables (MZ / ELF / shebang scripts).
 */
async function verifyMagicBytesHeader(file: File, ext: string): Promise<void> {
  try {
    const headerSlice = file.slice(0, 8);
    const buf = await headerSlice.arrayBuffer();
    const bytes = new Uint8Array(buf);
    if (bytes.length >= 2) {
      // Windows PE Executable 'MZ' (0x4D 0x5A)
      if (bytes[0] === 0x4d && bytes[1] === 0x5a) {
        throw new Error('Security check failed: Disguised executable file detected.');
      }
      // Linux ELF binary (0x7F 'E' 'L' 'F')
      if (bytes.length >= 4 && bytes[0] === 0x7f && bytes[1] === 0x45 && bytes[2] === 0x4c && bytes[3] === 0x46) {
        throw new Error('Security check failed: Binary executable file detected.');
      }
      // Shell script '#!' (0x23 0x21) unless txt/csv
      if (bytes[0] === 0x23 && bytes[1] === 0x21 && ext !== 'txt') {
        throw new Error('Security check failed: Executable script file detected.');
      }
    }
  } catch (err: any) {
    if (err?.message?.includes('Security check failed')) {
      throw err;
    }
  }
}

/**
 * Lightweight video metadata/thumbnail extraction using an offscreen video element and URL.createObjectURL (zero full-file memory read).
 */
function generateLightweightVideoThumbnail(file: File): Promise<string | undefined> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;

    const cleanup = () => {
      URL.revokeObjectURL(url);
    };

    const timeout = setTimeout(() => {
      cleanup();
      resolve(undefined);
    }, 3500);

    video.onloadeddata = () => {
      video.currentTime = Math.min(0.5, (video.duration || 1) / 2);
    };

    video.onseeked = () => {
      clearTimeout(timeout);
      try {
        const canvas = document.createElement('canvas');
        const maxDim = 280;
        const w = video.videoWidth || 280;
        const h = video.videoHeight || 160;
        const scale = Math.min(maxDim / w, maxDim / h, 1);
        canvas.width = Math.round(w * scale);
        canvas.height = Math.round(h * scale);
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.65);
          cleanup();
          resolve(dataUrl);
          return;
        }
      } catch (e) {
        // ignore
      }
      cleanup();
      resolve(undefined);
    };

    video.onerror = () => {
      clearTimeout(timeout);
      cleanup();
      resolve(undefined);
    };

    video.src = url;
  });
}

/**
 * Controller for a chunked, resumable file upload.
 * Uses File.slice() per chunk so even 500 MB files use < 4 MB of RAM.
 */
export class ResumableUploadTask {
  public uploadId: string = '';
  public fileId: string = '';
  public storagePath: string = '';
  private file: File;
  private companyId: string;
  private conversationId: string;
  private uploaderId: string;
  private uploaderName: string;
  private employeeId?: string;
  private thumbnailUrl?: string;
  private mimeType: string;
  private onProgress: (progress: ResumableUploadProgress) => void;
  private abortController: AbortController | null = null;
  private isCancelled = false;
  private isPaused = false;
  private uploadedBytes = 0;
  private chunkSize = DEFAULT_CHUNK_SIZE_BYTES;
  private startTime = 0;
  private bytesAtStart = 0;

  constructor(params: {
    file: File;
    mimeType: string;
    companyId: string;
    conversationId: string;
    uploaderId: string;
    uploaderName: string;
    employeeId?: string;
    thumbnailUrl?: string;
    existingUploadId?: string;
    onProgress: (progress: ResumableUploadProgress) => void;
  }) {
    this.file = params.file;
    this.mimeType = params.mimeType;
    this.companyId = params.companyId;
    this.conversationId = params.conversationId;
    this.uploaderId = params.uploaderId;
    this.uploaderName = params.uploaderName;
    this.employeeId = params.employeeId;
    this.thumbnailUrl = params.thumbnailUrl;
    this.uploadId = params.existingUploadId || '';
    this.onProgress = params.onProgress;
  }

  private emitProgress(
    status: ResumableUploadProgress['status'],
    speedBytesPerSec: number = 0,
    error?: string
  ) {
    const total = this.file.size;
    const uploaded = Math.min(this.uploadedBytes, total);
    const remaining = Math.max(0, total - uploaded);
    const percentage = total > 0 ? Math.min(100, Math.round((uploaded / total) * 100)) : 0;
    const etaSeconds = speedBytesPerSec > 0 ? Math.ceil(remaining / speedBytesPerSec) : null;

    this.onProgress({
      uploadId: this.uploadId,
      fileId: this.fileId,
      fileName: this.file.name,
      fileSizeBytes: total,
      uploadedBytes: uploaded,
      remainingBytes: remaining,
      percentage,
      speedBytesPerSec,
      etaSeconds,
      status,
      error,
    });
  }

  public async startOrResume(messageId?: string): Promise<FileAttachmentMetadata> {
    this.isCancelled = false;
    this.isPaused = false;
    this.abortController = new AbortController();

    // 1. Initialize or resume session on server
    const initRes = await fetch('/api/storage/init', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fileName: this.file.name,
        fileSize: this.file.size,
        mimeType: this.mimeType,
        companyId: this.companyId,
        conversationId: this.conversationId,
        uploaderId: this.uploaderId,
        uploaderName: this.uploaderName,
        employeeId: this.employeeId,
        thumbnailUrl: this.thumbnailUrl,
        existingUploadId: this.uploadId || undefined,
      }),
      signal: this.abortController.signal,
    });

    if (!initRes.ok) {
      const errData = await initRes.json().catch(() => ({}));
      const msg = errData.error || `Upload initialization failed (${initRes.status})`;
      this.emitProgress('failed', 0, msg);
      throw new Error(msg);
    }

    const initData = await initRes.json();
    this.uploadId = initData.uploadId;
    this.fileId = initData.fileId;
    this.storagePath = initData.storagePath;
    this.uploadedBytes = Number(initData.uploadedBytes || 0);
    if (initData.chunkSize) {
      this.chunkSize = Number(initData.chunkSize);
    }

    this.startTime = Date.now();
    this.bytesAtStart = this.uploadedBytes;
    this.emitProgress('uploading', 0);

    // 2. Upload binary chunks sequentially with automatic retry for transient network glitches
    while (this.uploadedBytes < this.file.size) {
      if (this.isCancelled) {
        this.emitProgress('cancelled', 0, 'Upload cancelled by user.');
        throw new Error('Upload cancelled by user.');
      }
      if (this.isPaused) {
        this.emitProgress('paused', 0, 'Upload paused.');
        throw new Error('Upload paused.');
      }

      if (!navigator.onLine) {
        this.emitProgress('failed', 0, 'Network connection lost. Tap Retry when back online to resume from where it stopped.');
        throw new Error('Network connection lost. Tap Retry to resume.');
      }

      const start = this.uploadedBytes;
      const end = Math.min(start + this.chunkSize, this.file.size);
      const chunkBlob = this.file.slice(start, end);

      let attempt = 0;
      const maxAttempts = 3;
      let chunkSuccess = false;

      while (attempt < maxAttempts && !chunkSuccess) {
        attempt++;
        try {
          const chunkRes = await fetch(`/api/storage/chunk/${encodeURIComponent(this.uploadId)}`, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/octet-stream',
              'X-Uploader-Id': this.uploaderId,
              'X-Company-Id': this.companyId,
              'X-Chunk-Offset': String(start),
            },
            body: chunkBlob,
            signal: this.abortController.signal,
          });

          if (chunkRes.status === 409) {
            // Offset mismatch: sync with server's actual received bytes
            const mismatchData = await chunkRes.json().catch(() => ({}));
            if (typeof mismatchData.uploadedBytes === 'number') {
              this.uploadedBytes = mismatchData.uploadedBytes;
              chunkSuccess = true;
              break;
            }
          }

          if (!chunkRes.ok) {
            const errBody = await chunkRes.json().catch(() => ({}));
            throw new Error(errBody.error || `Chunk upload failed with status ${chunkRes.status}`);
          }

          const chunkData = await chunkRes.json();
          this.uploadedBytes = Number(chunkData.uploadedBytes ?? end);
          chunkSuccess = true;

          const elapsedSec = Math.max(0.1, (Date.now() - this.startTime) / 1000);
          const bytesTransferredThisRun = Math.max(0, this.uploadedBytes - this.bytesAtStart);
          const speed = Math.round(bytesTransferredThisRun / elapsedSec);

          this.emitProgress('uploading', speed);
        } catch (chunkErr: any) {
          if (this.isCancelled || chunkErr?.name === 'AbortError') {
            this.emitProgress('cancelled', 0, 'Upload cancelled.');
            throw new Error('Upload cancelled.');
          }
          if (attempt >= maxAttempts) {
            const errMsg = chunkErr?.message || 'Network interrupted during upload. Tap Retry to resume.';
            this.emitProgress('failed', 0, errMsg);
            throw new Error(errMsg);
          }
          // Wait briefly before retrying the chunk
          await new Promise((r) => setTimeout(r, 800 * attempt));
        }
      }
    }

    // 3. Finalize upload and confirm server completion
    const completeRes = await fetch(`/api/storage/complete/${encodeURIComponent(this.uploadId)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        uploaderId: this.uploaderId,
        companyId: this.companyId,
        messageId,
      }),
      signal: this.abortController.signal,
    });

    if (!completeRes.ok) {
      const errData = await completeRes.json().catch(() => ({}));
      const msg = errData.error || 'Server failed to confirm upload completion.';
      this.emitProgress('failed', 0, msg);
      throw new Error(msg);
    }

    const completeData = await completeRes.json();
    const elapsedSec = Math.max(0.1, (Date.now() - this.startTime) / 1000);
    const speed = Math.round((this.file.size - this.bytesAtStart) / elapsedSec);
    this.emitProgress('completed', speed);

    return completeData.metadata as FileAttachmentMetadata;
  }

  public async cancel(): Promise<void> {
    this.isCancelled = true;
    if (this.abortController) {
      this.abortController.abort();
    }
    if (this.uploadId) {
      try {
        await fetch(
          `/api/storage/cancel/${encodeURIComponent(this.uploadId)}?uploaderId=${encodeURIComponent(this.uploaderId)}&companyId=${encodeURIComponent(this.companyId)}`,
          { method: 'DELETE' }
        );
      } catch (e) {
        // ignore network error during cancel
      }
    }
    this.emitProgress('cancelled', 0, 'Upload cancelled and temporary data cleaned up.');
  }
}

/**
 * Requests a short-lived, company-authorized download or inline open URL for a file attachment.
 * Never loads the file into browser memory — uses browser native download/streaming.
 */
export async function requestAuthorizedFileUrl(params: {
  fileId?: string;
  storagePath?: string;
  mediaUrl?: string;
  userId: string;
  companyId: string;
  employeeId?: string;
}): Promise<{ downloadUrl: string; openUrl: string }> {
  // Legacy inline data URL or direct URL fallback for existing messages
  if (!params.fileId && !params.storagePath && params.mediaUrl) {
    return {
      downloadUrl: params.mediaUrl,
      openUrl: params.mediaUrl,
    };
  }

  const res = await fetch('/api/storage/authorize-download', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      fileId: params.fileId,
      storagePath: params.storagePath,
      userId: params.userId,
      companyId: params.companyId,
      employeeId: params.employeeId,
    }),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || `Unable to access file (${res.status}).`);
  }

  const data = await res.json();
  return {
    downloadUrl: data.downloadUrl,
    openUrl: data.openUrl,
  };
}

/**
 * Triggers a streaming browser download without buffering the file in JS memory.
 */
export async function triggerAuthenticatedDownload(params: {
  fileId?: string;
  storagePath?: string;
  mediaUrl?: string;
  fileName?: string;
  userId: string;
  companyId: string;
  employeeId?: string;
  mode: 'download' | 'open';
}): Promise<string> {
  const { downloadUrl, openUrl } = await requestAuthorizedFileUrl(params);
  const targetUrl = params.mode === 'open' ? openUrl : downloadUrl;

  if (params.mode === 'download') {
    const a = document.createElement('a');
    a.href = targetUrl;
    a.download = params.fileName || 'download';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  return targetUrl;
}

/**
 * Backwards-compatible helper in case any legacy callers invoke processMediaAttachment.
 */
export async function processMediaAttachment(file: File): Promise<ProcessedMedia> {
  const validated = await validateAndPrepareAttachment(file);
  return {
    messageType: validated.messageType,
    mediaUrl: validated.thumbnailUrl || '',
    fileName: validated.fileName,
    fileSizeBytes: validated.fileSizeBytes,
    mimeType: validated.mimeType,
    thumbnailUrl: validated.thumbnailUrl,
  };
}
