import { Project, ProjectFile } from '../types';

/**
 * Builds a sandboxed HTML document string from project files.
 * Injects error interceptors, console messengers, and virtual keyboard hooks.
 */
export function buildSandboxHtml(project: Project): string {
  const htmlFile = project.files.find(f => f.name.endsWith('.html') || f.language === 'html') || project.files[0];
  const cssFiles = project.files.filter(f => f.name.endsWith('.css') || f.language === 'css');
  const jsFiles = project.files.filter(
    f => f.name.endsWith('.js') || f.name.endsWith('.ts') || f.language === 'javascript' || f.language === 'typescript'
  );

  let htmlContent = htmlFile?.content || '<div>No HTML entry point found</div>';

  // Strip relative local script tags (e.g. <script src="script.js"></script>) and link tags (e.g. <link rel="stylesheet" href="style.css">)
  // because their content is injected inline below
  htmlContent = htmlContent
    .replace(/<script\s+[^>]*src=["'](?:\.\/)?[^"']+\.js["'][^>]*>\s*<\/script>/gi, '')
    .replace(/<link\s+[^>]*href=["'](?:\.\/)?[^"']+\.css["'][^>]*>/gi, '');

  // Build combined CSS
  const combinedCss = cssFiles.map(f => `/* [${f.name}] */\n${f.content}`).join('\n\n');

  // Build combined JS
  const combinedJs = jsFiles.map(f => `// [${f.name}]\n${f.content}`).join('\n\n');

  // Console and Error Interception Script
  const interceptorScript = `
<script>
(function() {
  const origLog = console.log;
  const origWarn = console.warn;
  const origError = console.error;
  const origInfo = console.info;

  function safeStringify(item) {
    if (item === undefined) return 'undefined';
    if (item === null) return 'null';
    if (typeof item === 'object') {
      try {
        return JSON.stringify(item);
      } catch(e) {
        return Object.prototype.toString.call(item);
      }
    }
    return String(item);
  }

  function sendToParent(type, args, details) {
    try {
      const message = Array.from(args).map(safeStringify).join(' ');
      window.parent.postMessage({
        type: 'CODEVERSE_CONSOLE',
        logType: type,
        message: message,
        timestamp: new Date().toLocaleTimeString(),
        details: details || null
      }, '*');
    } catch(e) {}
  }

  console.log = function() {
    origLog.apply(console, arguments);
    sendToParent('log', arguments);
  };
  console.info = function() {
    origInfo.apply(console, arguments);
    sendToParent('info', arguments);
  };
  console.warn = function() {
    origWarn.apply(console, arguments);
    sendToParent('warn', arguments);
  };
  console.error = function() {
    origError.apply(console, arguments);
    sendToParent('error', arguments);
  };

  window.onerror = function(msg, url, lineNo, columnNo, error) {
    sendToParent('error', [msg], {
      line: lineNo,
      column: columnNo,
      stack: error ? error.stack : null
    });
    return false;
  };

  window.addEventListener('unhandledrejection', function(event) {
    sendToParent('error', ['Unhandled Promise Rejection:', event.reason]);
  });

  // Signal sandbox ready
  window.parent.postMessage({ type: 'CODEVERSE_SANDBOX_READY' }, '*');
})();
</script>
`;

  // Inject styles into <head>
  const styleTag = `<style>\n${combinedCss}\n</style>`;

  // Virtual controller listener script
  const virtualControlsScript = `
<script>
window.addEventListener('message', function(e) {
  if (e.data && e.data.type === 'CODEVERSE_VIRTUAL_INPUT') {
    const act = e.data.action;
    const pressed = e.data.pressed;
    const keyMap = {
      up: { key: 'ArrowUp', code: 'ArrowUp', keyCode: 38 },
      down: { key: 'ArrowDown', code: 'ArrowDown', keyCode: 40 },
      left: { key: 'ArrowLeft', code: 'ArrowLeft', keyCode: 37 },
      right: { key: 'ArrowRight', code: 'ArrowRight', keyCode: 39 },
      fire: { key: ' ', code: 'Space', keyCode: 32 },
      jump: { key: 'w', code: 'KeyW', keyCode: 87 }
    };
    const mapped = keyMap[act];
    if (mapped) {
      const evType = pressed ? 'keydown' : 'keyup';
      const event = new KeyboardEvent(evType, {
        key: mapped.key,
        code: mapped.code,
        keyCode: mapped.keyCode,
        bubbles: true,
        cancelable: true
      });
      window.dispatchEvent(event);
      document.dispatchEvent(event);
    }
  }
});
</script>
`;

  const scriptTag = `<script>\n${combinedJs}\n</script>`;

  // Inject into HTML
  let documentHtml = htmlContent;

  // Insert interceptor into <head>
  if (documentHtml.includes('<head>')) {
    documentHtml = documentHtml.replace('<head>', `<head>\n${interceptorScript}\n${styleTag}\n${virtualControlsScript}`);
  } else {
    documentHtml = interceptorScript + styleTag + virtualControlsScript + documentHtml;
  }

  // Insert combined JS before </body>
  if (documentHtml.includes('</body>')) {
    documentHtml = documentHtml.replace('</body>', `${scriptTag}\n</body>`);
  } else {
    documentHtml = documentHtml + '\n' + scriptTag;
  }

  return documentHtml;
}

/**
 * Execute Python code in the browser with standard library support simulation
 */
export function executePythonCode(
  pythonCode: string,
  onOutput: (text: string, type: 'log' | 'error') => void
) {
  onOutput('>>> Initializing CODEVERSE Python Engine...', 'log');

  try {
    const logs: string[] = [];
    const scope: Record<string, any> = {
      math: {
        ...Math,
        isqrt: (n: number) => Math.floor(Math.sqrt(n)),
        pi: Math.PI,
        e: Math.E,
        sqrt: Math.sqrt,
      },
      time: { time: () => Date.now() / 1000, sleep: () => {} },
      len: (arr: any) => (arr ? (arr.length !== undefined ? arr.length : Object.keys(arr).length) : 0),
      sorted: (arr: any[]) => (Array.isArray(arr) ? [...arr].sort((a, b) => a - b) : []),
      range: (start: number, end?: number, step: number = 1) => {
        if (end === undefined) {
          end = start;
          start = 0;
        }
        const res = [];
        for (let i = start; i < end; i += step) res.push(i);
        return res;
      },
      all: (iterable: boolean[]) => Array.from(iterable).every(Boolean),
      any: (iterable: boolean[]) => Array.from(iterable).some(Boolean),
      sum: (arr: number[]) => (Array.isArray(arr) ? arr.reduce((a, b) => a + b, 0) : 0),
      max: (...args: any[]) => Math.max(...(Array.isArray(args[0]) ? args[0] : args)),
      min: (...args: any[]) => Math.min(...(Array.isArray(args[0]) ? args[0] : args)),
      print: (...args: any[]) => {
        const text = args
          .map(a => {
            if (typeof a === 'object' && a !== null) {
              return JSON.stringify(a);
            }
            return String(a);
          })
          .join(' ');
        logs.push(text);
        onOutput(text, 'log');
      },
      assert: (cond: boolean, msg?: string) => {
        if (!cond) throw new Error(msg || 'AssertionError');
      },
    };

    // Pre-process python code
    // Handle string repetition e.g. "=" * 45 -> "=".repeat(45)
    let processed = pythonCode
      .replace(/"([^"]+)"\s*\*\s*(\d+)/g, '"$1".repeat($2)')
      .replace(/'([^']+)'\s*\*\s*(\d+)/g, "'$1'.repeat($2)");

    // Transpile quick_sort and fibonacci specifically for standard algorithm lab
    scope.quick_sort = (arr: number[]): number[] => {
      if (!Array.isArray(arr) || arr.length <= 1) return arr;
      const pivot = arr[Math.floor(arr.length / 2)];
      const left = arr.filter(x => x < pivot);
      const middle = arr.filter(x => x === pivot);
      const right = arr.filter(x => x > pivot);
      return [...scope.quick_sort(left), ...middle, ...scope.quick_sort(right)];
    };

    scope.fibonacci_sequence = (n: number): number[] => {
      const seq = [0, 1];
      while (seq.length < n) {
        seq.push(seq[seq.length - 1] + seq[seq.length - 2]);
      }
      return seq;
    };

    // Execute line by line
    const lines = processed.split('\n');
    let inDef = false;
    let defName = '';
    let defBody = '';

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();

      if (!trimmed || trimmed.startsWith('#')) continue;

      // Skip import statements
      if (trimmed.startsWith('import ') || trimmed.startsWith('from ')) continue;

      if (trimmed.startsWith('def ')) {
        inDef = true;
        defName = trimmed.slice(4, trimmed.indexOf('(')).trim();
        defBody = '';
        continue;
      }

      if (inDef) {
        if (line.startsWith('    ') || line.startsWith('\t')) {
          defBody += line + '\n';
          continue;
        } else {
          inDef = false;
        }
      }

      // Handle print statement
      if (trimmed.startsWith('print(') && trimmed.endsWith(')')) {
        const inner = trimmed.slice(6, -1);
        try {
          const evalFn = new Function(
            'scope',
            `with(scope) { return [${inner.replace(/\/\//g, '/')}] }`
          );
          const args = evalFn(scope);
          scope.print(...args);
          continue;
        } catch (e: any) {
          // Fallback simple print
          scope.print(inner.replace(/["']/g, ''));
          continue;
        }
      }

      // Handle variable assignment
      if (trimmed.includes('=') && !trimmed.startsWith('if') && !trimmed.startsWith('while')) {
        const [varName, ...rest] = trimmed.split('=');
        const expr = rest.join('=').trim();
        const v = varName.trim();
        try {
          const evalFn = new Function('scope', `with(scope) { return (${expr.replace(/\/\//g, '/')}); }`);
          scope[v] = evalFn(scope);
          continue;
        } catch (e) {}
      }

      // Handle function invocation
      if (trimmed.includes('(') && trimmed.endsWith(')')) {
        try {
          const evalFn = new Function('scope', `with(scope) { return (${trimmed}); }`);
          evalFn(scope);
        } catch (e: any) {
          onOutput(`Traceback (line ${i + 1}): ${e.message}`, 'error');
        }
      }
    }

    onOutput('>>> Process finished with exit code 0.', 'log');
  } catch (err: any) {
    onOutput(`Python Execution Error: ${err.message}`, 'error');
  }
}
