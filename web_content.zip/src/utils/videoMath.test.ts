import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateVideoSegments, formatTime, estimateFileSizeMB } from './videoMath';

test('formatTime correctly formats seconds to MM:SS and HH:MM:SS', () => {
  assert.equal(formatTime(0), '00:00');
  assert.equal(formatTime(45), '00:45');
  assert.equal(formatTime(65), '01:05');
  assert.equal(formatTime(205), '03:25');
  assert.equal(formatTime(3665), '01:01:05');
});

test('calculateVideoSegments splits 205 seconds (3m 25s) into 50s clips with remainder', () => {
  // 3 minutes 25 seconds = 205 seconds
  // Splitting by 50 seconds:
  // Clip 1: 0 to 50 (50s)
  // Clip 2: 50 to 100 (50s)
  // Clip 3: 100 to 150 (50s)
  // Clip 4: 150 to 200 (50s)
  // Clip 5: 200 to 205 (5s)
  const segments = calculateVideoSegments(205, 'duration', 50);
  assert.equal(segments.length, 5);
  assert.equal(segments[0].startTime, 0);
  assert.equal(segments[0].endTime, 50);
  assert.equal(segments[0].duration, 50);

  assert.equal(segments[3].startTime, 150);
  assert.equal(segments[3].endTime, 200);

  assert.equal(segments[4].startTime, 200);
  assert.equal(segments[4].endTime, 205);
  assert.equal(segments[4].duration, 5);
});

test('calculateVideoSegments splits video into exact number of parts', () => {
  const segments = calculateVideoSegments(100, 'count', 5);
  assert.equal(segments.length, 5);
  assert.equal(segments[0].duration, 20);
  assert.equal(segments[4].endTime, 100);
});

test('calculateVideoSegments handles edge case of 0 or invalid duration', () => {
  assert.deepEqual(calculateVideoSegments(0, 'duration', 30), []);
  assert.deepEqual(calculateVideoSegments(-10, 'duration', 30), []);
});

test('estimateFileSizeMB computes sensible size estimates', () => {
  const mb = estimateFileSizeMB(60, '720p', 'medium');
  assert.ok(mb > 0);
  assert.ok(mb < 100);
});
