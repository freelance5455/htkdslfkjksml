import { collection, doc, getDocs, setDoc, onSnapshot, query, orderBy, limit } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, testConnection } from '../firebase';
import { TransactionRecord, CashierRequest, UserProfile, TransferVoucher, CashierAgent, SupportTicket } from '../types';

const AUDIT_COLLECTION = 'audit_logs';
const USERS_COLLECTION = 'users';
const CASHIER_COLLECTION = 'cashier_requests';
const TRANSFERS_COLLECTION = 'currency_transfers';
const CASHIER_AGENTS_COLLECTION = 'cashier_agents';
const SUPPORT_TICKETS_COLLECTION = 'support_tickets';

/**
 * Checks Firebase database connection status
 */
export async function checkFirebaseStatus(): Promise<{ connected: boolean; message: string }> {
  return await testConnection();
}

/**
 * Save an audit log / transaction record to Firestore
 */
export async function saveAuditRecordToFirestore(record: TransactionRecord): Promise<boolean> {
  try {
    const docRef = doc(db, AUDIT_COLLECTION, record.transactionId);
    await setDoc(docRef, {
      ...record,
      updatedAt: new Date().toISOString(),
    });
    console.log(`[Firestore] Saved audit log: ${record.transactionId}`);
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${AUDIT_COLLECTION}/${record.transactionId}`);
    return false;
  }
}

/**
 * Seed initial records into Firestore if the collection is empty
 */
export async function seedAuditRecordsIfEmpty(defaultRecords: TransactionRecord[]): Promise<void> {
  try {
    const snap = await getDocs(collection(db, AUDIT_COLLECTION));
    if (snap.empty) {
      console.log(`[Firestore] Seeding ${defaultRecords.length} default audit records...`);
      for (const rec of defaultRecords) {
        await saveAuditRecordToFirestore(rec);
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, AUDIT_COLLECTION);
  }
}

/**
 * Subscribe to real-time audit log updates from Firestore
 */
export function subscribeToAuditLogs(
  onUpdate: (records: TransactionRecord[]) => void,
  onError?: (err: any) => void
) {
  try {
    const colRef = collection(db, AUDIT_COLLECTION);
    return onSnapshot(
      colRef,
      (snapshot) => {
        const records: TransactionRecord[] = [];
        snapshot.forEach((doc) => {
          records.push(doc.data() as TransactionRecord);
        });
        if (records.length > 0) {
          records.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
          onUpdate(records);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, AUDIT_COLLECTION);
        if (onError) onError(error);
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, AUDIT_COLLECTION);
    return () => {};
  }
}

/**
 * Save user profile to Firestore
 */
export async function saveUserProfileToFirestore(user: UserProfile): Promise<boolean> {
  try {
    const docRef = doc(db, USERS_COLLECTION, user.id);
    await setDoc(docRef, {
      ...user,
      updatedAt: new Date().toISOString(),
    });
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${USERS_COLLECTION}/${user.id}`);
    return false;
  }
}

/**
 * Save transfer voucher record to Firestore
 */
export async function saveTransferVoucherToFirestore(voucher: TransferVoucher): Promise<boolean> {
  try {
    const docRef = doc(db, TRANSFERS_COLLECTION, voucher.voucherId);
    await setDoc(docRef, {
      ...voucher,
      updatedAt: new Date().toISOString(),
    });
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${TRANSFERS_COLLECTION}/${voucher.voucherId}`);
    return false;
  }
}

/**
 * Save / Update Cashier Agent in Firestore
 */
export async function saveCashierAgentToFirestore(agent: CashierAgent): Promise<boolean> {
  try {
    const docRef = doc(db, CASHIER_AGENTS_COLLECTION, agent.id);
    await setDoc(docRef, {
      ...agent,
      updatedAt: new Date().toISOString(),
    });
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${CASHIER_AGENTS_COLLECTION}/${agent.id}`);
    return false;
  }
}

/**
 * Subscribe to Transfer Vouchers in Firestore
 */
export function subscribeToTransferVouchers(
  onUpdate: (vouchers: TransferVoucher[]) => void
) {
  try {
    const colRef = collection(db, TRANSFERS_COLLECTION);
    return onSnapshot(
      colRef,
      (snapshot) => {
        const vouchers: TransferVoucher[] = [];
        snapshot.forEach((doc) => {
          vouchers.push(doc.data() as TransferVoucher);
        });
        if (vouchers.length > 0) {
          vouchers.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
          onUpdate(vouchers);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, TRANSFERS_COLLECTION);
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, TRANSFERS_COLLECTION);
    return () => {};
  }
}

/**
 * Save / Update Customer Support Ticket in Firestore
 */
export async function saveSupportTicketToFirestore(ticket: SupportTicket): Promise<boolean> {
  try {
    const docRef = doc(db, SUPPORT_TICKETS_COLLECTION, ticket.id);
    await setDoc(docRef, {
      ...ticket,
      updatedAt: new Date().toISOString(),
    });
    console.log(`[Firestore] Saved support ticket: ${ticket.id}`);
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${SUPPORT_TICKETS_COLLECTION}/${ticket.id}`);
    return false;
  }
}

/**
 * Subscribe to Customer Support Tickets in Firestore
 */
export function subscribeToSupportTickets(
  onUpdate: (tickets: SupportTicket[]) => void,
  onError?: (err: any) => void
) {
  try {
    const colRef = collection(db, SUPPORT_TICKETS_COLLECTION);
    return onSnapshot(
      colRef,
      (snapshot) => {
        const tickets: SupportTicket[] = [];
        snapshot.forEach((doc) => {
          tickets.push(doc.data() as SupportTicket);
        });
        if (tickets.length > 0) {
          tickets.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
          onUpdate(tickets);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, SUPPORT_TICKETS_COLLECTION);
        if (onError) onError(error);
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, SUPPORT_TICKETS_COLLECTION);
    return () => {};
  }
}

/**
 * Seed initial Support Tickets if collection is empty
 */
export async function seedSupportTicketsIfEmpty(defaultTickets: SupportTicket[]): Promise<void> {
  try {
    const snap = await getDocs(collection(db, SUPPORT_TICKETS_COLLECTION));
    if (snap.empty) {
      console.log(`[Firestore] Seeding ${defaultTickets.length} default support tickets...`);
      for (const t of defaultTickets) {
        await saveSupportTicketToFirestore(t);
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, SUPPORT_TICKETS_COLLECTION);
  }
}

