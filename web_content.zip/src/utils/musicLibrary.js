import { parseBlob, selectCover } from 'music-metadata';
export const BUILTIN_MUSIC_TRACK = {
    id: 'builtin-sky-kingdom',
    title: 'Sky Kingdom Theme',
    subtitleAr: 'الموسيقى الأساسية للعبة',
    subtitleEn: 'Default Game Theme',
    duration: 33.15,
    src: 'assets/flapora/audio/bgm_sky.mp3',
    coverUrl: 'assets/flapora/FLAPORA_background.webp',
    isCustom: false,
};
const DB_NAME = 'flapora_music_db';
const DB_VERSION = 1;
const STORE_NAME = 'tracks';
const PREFS_KEY = 'flapora_music_prefs_v1';
export const DEFAULT_MUSIC_PREFS = {
    selectedTrackId: BUILTIN_MUSIC_TRACK.id,
    volume: 0.45,
    loopMode: 'all',
};
export function loadMusicPrefs() {
    try {
        const raw = window.localStorage.getItem(PREFS_KEY);
        if (!raw)
            return DEFAULT_MUSIC_PREFS;
        const parsed = JSON.parse(raw);
        return {
            selectedTrackId: parsed.selectedTrackId || BUILTIN_MUSIC_TRACK.id,
            volume: typeof parsed.volume === 'number' && parsed.volume >= 0 && parsed.volume <= 1
                ? parsed.volume
                : DEFAULT_MUSIC_PREFS.volume,
            loopMode: parsed.loopMode === 'one' || parsed.loopMode === 'shuffle' || parsed.loopMode === 'all'
                ? parsed.loopMode
                : DEFAULT_MUSIC_PREFS.loopMode,
        };
    }
    catch {
        return DEFAULT_MUSIC_PREFS;
    }
}
export function saveMusicPrefs(prefs) {
    try {
        window.localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
    }
    catch {
        // ignore storage limits
    }
}
function openMusicDb() {
    return new Promise((resolve, reject) => {
        if (typeof window === 'undefined' || !window.indexedDB) {
            reject(new Error('IndexedDB unavailable'));
            return;
        }
        const request = window.indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = () => {
            const db = request.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME, { keyPath: 'id' });
            }
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error ?? new Error('Failed to open DB'));
    });
}
export async function getAllStoredTracks() {
    try {
        const db = await openMusicDb();
        return await new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readonly');
            const store = tx.objectStore(STORE_NAME);
            const req = store.getAll();
            req.onsuccess = () => {
                const rows = req.result || [];
                rows.sort((a, b) => b.createdAt - a.createdAt);
                resolve(rows);
            };
            req.onerror = () => reject(req.error);
        });
    }
    catch {
        return [];
    }
}
export async function saveStoredTrack(record) {
    const db = await openMusicDb();
    await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const req = store.put(record);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
    });
}
export async function deleteStoredTrack(id) {
    const db = await openMusicDb();
    await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const req = store.delete(id);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
    });
}
const AUDIO_EXT_RE = /\.(mp3|m4a|wav|ogg|aac|flac|opus|webm)$/i;
export function isSupportedAudioFile(file) {
    if (file.type && file.type.startsWith('audio/'))
        return true;
    return AUDIO_EXT_RE.test(file.name);
}
export function cleanTrackTitle(filename) {
    const withoutExt = filename.replace(/\.[^/.]+$/, '');
    return withoutExt.replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim() || 'Audio Track';
}
export async function probeAudioDuration(blob) {
    const url = URL.createObjectURL(blob);
    try {
        return await new Promise((resolve) => {
            const audio = new Audio();
            const timeout = window.setTimeout(() => {
                resolve(0);
            }, 2500);
            audio.preload = 'metadata';
            audio.onloadedmetadata = () => {
                window.clearTimeout(timeout);
                const dur = Number.isFinite(audio.duration) ? audio.duration : 0;
                resolve(dur);
            };
            audio.onerror = () => {
                window.clearTimeout(timeout);
                resolve(0);
            };
            audio.src = url;
        });
    }
    finally {
        URL.revokeObjectURL(url);
    }
}
async function compressCoverBlob(rawBlob) {
    if (rawBlob.size <= 160 * 1024)
        return rawBlob;
    const objUrl = URL.createObjectURL(rawBlob);
    try {
        const img = await new Promise((resolve, reject) => {
            const el = new Image();
            el.onload = () => resolve(el);
            el.onerror = () => reject(new Error('Invalid cover'));
            el.src = objUrl;
        });
        const maxDim = 256;
        const scale = Math.min(1, maxDim / Math.max(img.naturalWidth, img.naturalHeight));
        const w = Math.max(1, Math.round(img.naturalWidth * scale));
        const h = Math.max(1, Math.round(img.naturalHeight * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return rawBlob;
        ctx.drawImage(img, 0, 0, w, h);
        const compressed = await new Promise((resolve) => canvas.toBlob((b) => resolve(b), 'image/webp', 0.85));
        return compressed ?? rawBlob;
    }
    catch {
        return rawBlob;
    }
    finally {
        URL.revokeObjectURL(objUrl);
    }
}
export async function extractAudioMetadata(blob, fallbackFilename) {
    const fallbackTitle = cleanTrackTitle(fallbackFilename);
    let title = fallbackTitle;
    let artist;
    let duration = 0;
    let coverBlob;
    try {
        const meta = await parseBlob(blob);
        if (meta.common.title?.trim()) {
            title = meta.common.title.trim();
        }
        if (meta.common.artist?.trim()) {
            artist = meta.common.artist.trim();
        }
        if (meta.format.duration && Number.isFinite(meta.format.duration)) {
            duration = meta.format.duration;
        }
        const picture = selectCover(meta.common.picture) ?? meta.common.picture?.[0];
        if (picture?.data && picture.data.length > 0) {
            const rawCover = new Blob([new Uint8Array(picture.data)], {
                type: picture.format || 'image/jpeg',
            });
            coverBlob = await compressCoverBlob(rawCover);
        }
    }
    catch {
        // fallback gracefully if file has non-standard tags
    }
    if (duration <= 0) {
        duration = await probeAudioDuration(blob);
    }
    return { title, artist, duration, coverBlob };
}
export function formatTime(seconds) {
    if (!Number.isFinite(seconds) || seconds < 0)
        return '0:00';
    const totalSec = Math.floor(seconds);
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}
export function formatFileSize(bytes) {
    if (!Number.isFinite(bytes) || bytes <= 0)
        return '';
    if (bytes < 1024 * 1024) {
        return `${Math.max(1, Math.round(bytes / 1024))} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
export async function collectAudioFilesFromDirectory(dirHandle, maxDepth = 4, depth = 0) {
    if (!dirHandle.values || depth > maxDepth)
        return [];
    const results = [];
    for await (const entry of dirHandle.values()) {
        if (entry.kind === 'file' && entry.getFile) {
            try {
                const file = await entry.getFile();
                if (isSupportedAudioFile(file)) {
                    results.push(file);
                }
            }
            catch {
                // skip unreadable entries
            }
        }
        else if (entry.kind === 'directory') {
            const nested = await collectAudioFilesFromDirectory(entry, maxDepth, depth + 1);
            results.push(...nested);
        }
    }
    return results.sort((a, b) => a.name.localeCompare(b.name));
}
