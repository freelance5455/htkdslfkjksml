import { BUILTIN_MUSIC_TRACK } from './musicLibrary';
const AUDIO_PATHS = {
    bgm: 'assets/flapora/audio/bgm_sky.mp3',
    flap: 'assets/flapora/audio/sfx_flap.mp3',
    score: 'assets/flapora/audio/sfx_score.mp3',
    crash: 'assets/flapora/audio/sfx_crash.mp3',
    click: 'assets/flapora/audio/sfx_button_pop.mp3',
};
class SoundManager {
    ctx = null;
    buffers = {};
    loadingStarted = false;
    bgmAudio = null;
    playlist = [BUILTIN_MUSIC_TRACK];
    activeTrackId = BUILTIN_MUSIC_TRACK.id;
    currentSrcLoaded = '';
    musicVolume = 0.45;
    loopMode = 'all';
    manuallyPaused = false;
    listeners = new Set();
    trackChangeListeners = new Set();
    musicEnabled = true;
    sfxEnabled = true;
    ensureContext() {
        if (typeof window === 'undefined')
            return null;
        if (!this.ctx) {
            const AudioCtx = window.AudioContext ||
                window
                    .webkitAudioContext;
            if (!AudioCtx)
                return null;
            this.ctx = new AudioCtx();
        }
        if (this.ctx.state === 'suspended') {
            void this.ctx.resume();
        }
        return this.ctx;
    }
    getActiveTrack() {
        return (this.playlist.find((t) => t.id === this.activeTrackId) ??
            this.playlist[0] ??
            BUILTIN_MUSIC_TRACK);
    }
    ensureBgmAudio() {
        if (typeof window === 'undefined')
            return null;
        if (!this.bgmAudio) {
            const bgm = new Audio();
            bgm.preload = 'auto';
            bgm.volume = this.musicVolume;
            bgm.addEventListener('timeupdate', () => this.emitSnapshot());
            bgm.addEventListener('loadedmetadata', () => this.emitSnapshot());
            bgm.addEventListener('play', () => this.emitSnapshot());
            bgm.addEventListener('pause', () => this.emitSnapshot());
            bgm.addEventListener('ended', () => this.handleTrackEnded());
            this.bgmAudio = bgm;
        }
        return this.bgmAudio;
    }
    syncAudioSourceIfNeeded() {
        const bgm = this.ensureBgmAudio();
        if (!bgm)
            return null;
        const track = this.getActiveTrack();
        if (this.currentSrcLoaded !== track.src) {
            this.currentSrcLoaded = track.src;
            bgm.src = track.src;
            bgm.load();
        }
        bgm.volume = this.musicVolume;
        return bgm;
    }
    handleTrackEnded() {
        const bgm = this.bgmAudio;
        if (!bgm)
            return;
        if (this.loopMode === 'one' || this.playlist.length <= 1) {
            bgm.currentTime = 0;
            if (this.musicEnabled) {
                void bgm.play().catch(() => { });
            }
            this.emitSnapshot();
            return;
        }
        const currentIdx = this.playlist.findIndex((t) => t.id === this.activeTrackId);
        let nextIdx = 0;
        if (this.loopMode === 'shuffle') {
            const candidates = this.playlist
                .map((_, idx) => idx)
                .filter((idx) => idx !== currentIdx);
            nextIdx = candidates[Math.floor(Math.random() * candidates.length)] ?? 0;
        }
        else {
            nextIdx = currentIdx >= 0 ? (currentIdx + 1) % this.playlist.length : 0;
        }
        const nextTrack = this.playlist[nextIdx];
        if (nextTrack) {
            this.activeTrackId = nextTrack.id;
            this.trackChangeListeners.forEach((cb) => cb(nextTrack.id));
            const audio = this.syncAudioSourceIfNeeded();
            if (audio && this.musicEnabled) {
                audio.currentTime = 0;
                void audio.play().catch(() => { });
            }
            this.emitSnapshot();
        }
    }
    getSnapshot() {
        const active = this.getActiveTrack();
        const bgm = this.bgmAudio;
        const rawDuration = bgm && Number.isFinite(bgm.duration) && bgm.duration > 0
            ? bgm.duration
            : active.duration;
        return {
            activeTrackId: active.id,
            isPlaying: Boolean(bgm && !bgm.paused && !bgm.ended),
            currentTime: bgm ? bgm.currentTime : 0,
            duration: rawDuration || 0,
            volume: this.musicVolume,
            loopMode: this.loopMode,
        };
    }
    emitSnapshot() {
        const snap = this.getSnapshot();
        this.listeners.forEach((cb) => cb(snap));
    }
    subscribe(listener) {
        this.listeners.add(listener);
        listener(this.getSnapshot());
        return () => {
            this.listeners.delete(listener);
        };
    }
    subscribeTrackChange(listener) {
        this.trackChangeListeners.add(listener);
        return () => {
            this.trackChangeListeners.delete(listener);
        };
    }
    setPlaylist(tracks, selectedId) {
        const prevSrc = this.currentSrcLoaded;
        this.playlist = tracks.length > 0 ? tracks : [BUILTIN_MUSIC_TRACK];
        if (selectedId && this.playlist.some((t) => t.id === selectedId)) {
            this.activeTrackId = selectedId;
        }
        else if (!this.playlist.some((t) => t.id === this.activeTrackId)) {
            this.activeTrackId = this.playlist[0].id;
        }
        const bgm = this.syncAudioSourceIfNeeded();
        if (bgm && prevSrc !== this.currentSrcLoaded && this.musicEnabled && !this.manuallyPaused) {
            void bgm.play().catch(() => { });
        }
        this.emitSnapshot();
    }
    selectTrack(trackId, autoPlay = false) {
        const exists = this.playlist.find((t) => t.id === trackId);
        if (!exists)
            return;
        const changed = this.activeTrackId !== trackId;
        this.activeTrackId = trackId;
        const bgm = this.syncAudioSourceIfNeeded();
        if (bgm && changed) {
            bgm.currentTime = 0;
        }
        if (bgm && autoPlay) {
            this.manuallyPaused = false;
            this.musicEnabled = true;
            void bgm.play().catch(() => { });
        }
        this.emitSnapshot();
    }
    togglePlayPause() {
        const bgm = this.syncAudioSourceIfNeeded();
        if (!bgm)
            return;
        if (!bgm.paused && !bgm.ended) {
            this.manuallyPaused = true;
            bgm.pause();
        }
        else {
            this.manuallyPaused = false;
            this.musicEnabled = true;
            void bgm.play().catch(() => { });
        }
        this.emitSnapshot();
    }
    stepTrack(direction, autoPlay = true) {
        if (this.playlist.length === 0)
            return;
        const currentIdx = this.playlist.findIndex((t) => t.id === this.activeTrackId);
        let nextIdx = 0;
        if (this.loopMode === 'shuffle' && this.playlist.length > 1) {
            const candidates = this.playlist
                .map((_, idx) => idx)
                .filter((idx) => idx !== currentIdx);
            nextIdx = candidates[Math.floor(Math.random() * candidates.length)] ?? 0;
        }
        else {
            const base = currentIdx >= 0 ? currentIdx : 0;
            nextIdx = (base + direction + this.playlist.length) % this.playlist.length;
        }
        const nextTrack = this.playlist[nextIdx];
        if (nextTrack) {
            this.selectTrack(nextTrack.id, autoPlay);
            this.trackChangeListeners.forEach((cb) => cb(nextTrack.id));
        }
    }
    seekTo(seconds) {
        const bgm = this.syncAudioSourceIfNeeded();
        if (!bgm)
            return;
        const maxDur = Number.isFinite(bgm.duration) && bgm.duration > 0
            ? bgm.duration
            : this.getActiveTrack().duration;
        bgm.currentTime = Math.max(0, Math.min(seconds, maxDur || seconds));
        this.emitSnapshot();
    }
    setMusicVolume(volume) {
        this.musicVolume = Math.max(0, Math.min(1, volume));
        if (this.bgmAudio) {
            this.bgmAudio.volume = this.musicVolume;
        }
        this.emitSnapshot();
    }
    setLoopMode(mode) {
        this.loopMode = mode;
        this.emitSnapshot();
    }
    preload() {
        if (typeof window === 'undefined' || this.loadingStarted)
            return;
        this.loadingStarted = true;
        const ctx = this.ensureContext();
        if (ctx) {
            Object.keys(AUDIO_PATHS).forEach(async (key) => {
                if (key === 'bgm')
                    return;
                try {
                    const res = await fetch(AUDIO_PATHS[key]);
                    const arr = await res.arrayBuffer();
                    const decoded = await ctx.decodeAudioData(arr);
                    this.buffers[key] = decoded;
                }
                catch {
                    // fallback handled gracefully
                }
            });
        }
        this.syncAudioSourceIfNeeded();
    }
    playSfx(key, volume = 0.7) {
        if (!this.sfxEnabled || typeof window === 'undefined')
            return;
        this.preload();
        const ctx = this.ensureContext();
        const buffer = this.buffers[key];
        if (ctx && buffer) {
            const source = ctx.createBufferSource();
            const gain = ctx.createGain();
            source.buffer = buffer;
            gain.gain.value = volume;
            source.connect(gain);
            gain.connect(ctx.destination);
            source.start(0);
            return;
        }
        // Fallback if buffer is still decoding on first click
        const fallback = new Audio(AUDIO_PATHS[key]);
        fallback.volume = volume;
        void fallback.play().catch(() => { });
    }
    ensureContinuousMusic() {
        if (typeof window === 'undefined')
            return;
        this.preload();
        const bgm = this.syncAudioSourceIfNeeded();
        if (!bgm || !this.musicEnabled || this.manuallyPaused)
            return;
        if (!bgm.paused && !bgm.ended)
            return;
        bgm.volume = this.musicVolume;
        void bgm.play().catch(() => { });
    }
    startMusic() {
        if (typeof window === 'undefined')
            return;
        this.preload();
        const bgm = this.syncAudioSourceIfNeeded();
        if (!bgm || !this.musicEnabled || this.manuallyPaused)
            return;
        if (!bgm.paused && !bgm.ended)
            return;
        bgm.volume = this.musicVolume;
        void bgm.play().catch(() => { });
        this.emitSnapshot();
    }
    pauseMusic() {
        if (!this.bgmAudio)
            return;
        this.manuallyPaused = true;
        this.bgmAudio.pause();
        this.emitSnapshot();
    }
    stopMusic() {
        if (!this.bgmAudio)
            return;
        this.bgmAudio.pause();
        this.bgmAudio.currentTime = 0;
        this.emitSnapshot();
    }
    setMusicEnabled(enabled) {
        this.musicEnabled = enabled;
        if (!enabled && this.bgmAudio) {
            this.bgmAudio.pause();
            this.emitSnapshot();
        }
        else if (enabled) {
            this.manuallyPaused = false;
            this.ensureContinuousMusic();
        }
    }
    setSfxEnabled(enabled) {
        this.sfxEnabled = enabled;
    }
    playClick() {
        this.playSfx('click', 0.32);
    }
    playFlap() {
        this.playSfx('flap', 0.72);
    }
    playScore() {
        this.playSfx('score', 0.15);
    }
    playCrash() {
        this.playSfx('crash', 0.75);
    }
}
export const sound = new SoundManager();
