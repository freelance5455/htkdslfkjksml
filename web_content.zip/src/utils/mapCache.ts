/**
 * TAKI-GO Map Caching & Route Generation Engine
 * Provides offline-resilient route geometry, airport pins, hotel locations, and itinerary waypoints.
 */

export interface MapCoordinate {
  id: string;
  lat: number;
  lng: number;
  title: string;
  subtitle?: string;
  type: 'origin_airport' | 'dest_airport' | 'hotel' | 'attraction' | 'transit_hub';
  code?: string;
  day?: number;
  iconName?: string;
}

export interface FlightRoutePath {
  origin: MapCoordinate;
  destination: MapCoordinate;
  airline: string;
  flightNumber: string;
  distanceKm: number;
  estimatedFlightHours: number;
  waypoints: Array<{ lat: number; lng: number }>;
}

export interface CityMapData {
  cityName: string;
  countryName: string;
  center: { lat: number; lng: number };
  zoomLevel: number;
  hotel: MapCoordinate;
  attractions: MapCoordinate[];
}

export interface CachedTripMapData {
  tripId: string;
  cachedAt: string;
  lastSyncedTimestamp: number;
  flightRoute: FlightRoutePath;
  cityMap: CityMapData;
  isOfflineAvailable: boolean;
  version: string;
  cacheSizeKb: number;
}

const MAP_CACHE_KEY_PREFIX = 'takigo_route_map_cache_';

/**
 * Calculates Great-Circle distance using Haversine formula in kilometers.
 */
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's mean radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

/**
 * Generates an array of intermediate coordinates forming an aerodynamic flight arc
 * between two geographic coordinates.
 */
export function generateFlightArc(
  origin: { lat: number; lng: number },
  destination: { lat: number; lng: number },
  steps: number = 24
): Array<{ lat: number; lng: number }> {
  const points: Array<{ lat: number; lng: number }> = [];

  for (let i = 0; i <= steps; i++) {
    const f = i / steps;
    // Linear geographic progression
    const latLinear = origin.lat + (destination.lat - origin.lat) * f;
    const lngLinear = origin.lng + (destination.lng - origin.lng) * f;

    // Parabolic north/curvature offset simulating jetstream airways
    const curveApex = Math.sin(f * Math.PI) * 4.2;
    const lat = Number((latLinear + curveApex).toFixed(4));
    const lng = Number(lngLinear.toFixed(4));

    points.push({ lat, lng });
  }

  return points;
}

/**
 * Constructs the default map data for the active trip (Algiers ALG -> Istanbul IST).
 */
export function createDefaultTripMapData(tripId: string = 'trip-ist-2026'): CachedTripMapData {
  const originAirport: MapCoordinate = {
    id: 'pt-alg',
    lat: 36.691,
    lng: 3.2154,
    title: 'مطار هواري بومدين الدولي (Algiers)',
    subtitle: 'Houari Boumediene Airport (ALG) - مبنى الركاب T4',
    type: 'origin_airport',
    code: 'ALG',
  };

  const destAirport: MapCoordinate = {
    id: 'pt-ist',
    lat: 41.2753,
    lng: 28.7519,
    title: 'مطار إسطنبول الدولي (Istanbul Airport)',
    subtitle: 'Istanbul International Airport (IST) - صالة الوصول الدولية',
    type: 'dest_airport',
    code: 'IST',
  };

  const hotelCoord: MapCoordinate = {
    id: 'pt-hotel',
    lat: 41.0422,
    lng: 29.0003,
    title: 'فندق سويسوتيل البوسفور (Swissôtel The Bosphorus)',
    subtitle: 'Maçka, Beşiktaş, Istanbul — حجز ديلوكس مؤكد',
    type: 'hotel',
    iconName: 'Building2',
  };

  const attractions: MapCoordinate[] = [
    {
      id: 'attr-1',
      lat: 41.0391,
      lng: 29.0001,
      title: 'قصر دولما بهتشة ومضيق البوسفور',
      subtitle: 'جولة اليخت الخاصة وزيارة القصر الإمبراطوري',
      type: 'attraction',
      day: 2,
    },
    {
      id: 'attr-2',
      lat: 41.0086,
      lng: 28.9802,
      title: 'جامع آيا صوفيا والمسجد الأزرق',
      subtitle: 'ميدان السلطان أحمد التاريخي والتراث البيزنطي العثماني',
      type: 'attraction',
      day: 3,
    },
    {
      id: 'attr-3',
      lat: 41.0107,
      lng: 28.968,
      title: 'البازار الكبير وسوق التوابل المصري',
      subtitle: 'Kapalıçarşı — جولة تسوق الحرف اليدوية والهدايا التذكارية',
      type: 'attraction',
      day: 3,
    },
    {
      id: 'attr-4',
      lat: 40.875,
      lng: 29.13,
      title: 'جزر الأميرات (جزيرة بيوك أضا)',
      subtitle: 'رحلة بحرية بالعبارة وجولة طبيعية نقية بدون سيارات',
      type: 'attraction',
      day: 5,
    },
    {
      id: 'attr-5',
      lat: 41.0538,
      lng: 28.9339,
      title: 'تلة بيير لوتي والقرن الذهبي',
      subtitle: 'تلفريك إيوب وإطلالة بانورامية ساحرة على مضيق القرن الذهبي',
      type: 'attraction',
      day: 6,
    },
  ];

  const distanceKm = calculateDistanceKm(
    originAirport.lat,
    originAirport.lng,
    destAirport.lat,
    destAirport.lng
  );

  const waypoints = generateFlightArc(
    { lat: originAirport.lat, lng: originAirport.lng },
    { lat: destAirport.lat, lng: destAirport.lng },
    24
  );

  const cityMap: CityMapData = {
    cityName: 'إسطنبول (Istanbul)',
    countryName: 'تركيا',
    center: { lat: 41.0082, lng: 28.9784 },
    zoomLevel: 13,
    hotel: hotelCoord,
    attractions,
  };

  const flightRoute: FlightRoutePath = {
    origin: originAirport,
    destination: destAirport,
    airline: 'Turkish Airlines',
    flightNumber: 'TK 652',
    distanceKm,
    estimatedFlightHours: 4.4,
    waypoints,
  };

  return {
    tripId,
    cachedAt: new Date().toISOString(),
    lastSyncedTimestamp: Date.now(),
    flightRoute,
    cityMap,
    isOfflineAvailable: true,
    version: '1.2.0',
    cacheSizeKb: 14.8,
  };
}

/**
 * Saves trip route map data into localStorage for offline operation.
 */
export function saveTripMapCache(tripId: string, mapData: CachedTripMapData): boolean {
  try {
    const key = `${MAP_CACHE_KEY_PREFIX}${tripId}`;
    const payload = JSON.stringify({
      ...mapData,
      lastSyncedTimestamp: Date.now(),
      cachedAt: new Date().toISOString(),
      isOfflineAvailable: true,
    });
    localStorage.setItem(key, payload);
    return true;
  } catch {
    return false;
  }
}

/**
 * Retrieves cached route map data from localStorage. If none exists, initializes default and caches it.
 */
export function loadTripMapCache(tripId: string = 'trip-ist-2026'): CachedTripMapData {
  try {
    const key = `${MAP_CACHE_KEY_PREFIX}${tripId}`;
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.tripId === tripId && parsed.flightRoute && parsed.cityMap) {
        return parsed as CachedTripMapData;
      }
    }
  } catch {
    // fallback
  }

  // Generate fresh, save it, and return
  const fresh = createDefaultTripMapData(tripId);
  saveTripMapCache(tripId, fresh);
  return fresh;
}

/**
 * Clears cached map data for a trip.
 */
export function clearTripMapCache(tripId: string): boolean {
  try {
    localStorage.removeItem(`${MAP_CACHE_KEY_PREFIX}${tripId}`);
    return true;
  } catch {
    return false;
  }
}

/**
 * Checks whether offline map data exists in local storage.
 */
export function isTripMapCached(tripId: string): boolean {
  try {
    return localStorage.getItem(`${MAP_CACHE_KEY_PREFIX}${tripId}`) !== null;
  } catch {
    return false;
  }
}
