import type { ApiKeysMap, ModelOption } from '../types/mycode';

const KEYSTORE_DB_NAME = 'mycode_secure_store';
const KEYSTORE_STORE_NAME = 'crypto_keys';
const MASTER_KEY_ID = 'master_aes_gcm_key';
const ENCRYPTED_KEYS_STORAGE = 'mycode_encrypted_api_keys_v1';
const CUSTOM_MODELS_STORAGE = 'mycode_custom_models_v1';

export const EMPTY_API_KEYS: ApiKeysMap = {
  google: '',
  groq: '',
  openrouter: '',
  zhipu: '',
  openai: '',
  anthropic: '',
};

function openKeyDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(KEYSTORE_DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(KEYSTORE_STORE_NAME)) {
        db.createObjectStore(KEYSTORE_STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function getOrCreateMasterKey(): Promise<CryptoKey | null> {
  if (typeof window === 'undefined' || !window.crypto?.subtle || !window.indexedDB) {
    return null;
  }

  try {
    const db = await openKeyDb();
    const existing = await new Promise<CryptoKey | undefined>((resolve, reject) => {
      const tx = db.transaction(KEYSTORE_STORE_NAME, 'readonly');
      const req = tx.objectStore(KEYSTORE_STORE_NAME).get(MASTER_KEY_ID);
      req.onsuccess = () => resolve(req.result as CryptoKey | undefined);
      req.onerror = () => reject(req.error);
    });

    if (existing) {
      db.close();
      return existing;
    }

    const generated = await window.crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );

    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(KEYSTORE_STORE_NAME, 'readwrite');
      const req = tx.objectStore(KEYSTORE_STORE_NAME).put(generated, MASTER_KEY_ID);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });

    db.close();
    return generated;
  } catch {
    return null;
  }
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

export async function saveEncryptedApiKeys(keys: ApiKeysMap): Promise<void> {
  const payload = JSON.stringify(keys);
  const cryptoKey = await getOrCreateMasterKey();

  if (cryptoKey) {
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const encoded = new TextEncoder().encode(payload);
    const cipherBuffer = await window.crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      cryptoKey,
      encoded
    );
    const stored = JSON.stringify({
      v: 1,
      alg: 'AES-GCM',
      iv: bytesToBase64(iv),
      data: bytesToBase64(new Uint8Array(cipherBuffer)),
    });
    localStorage.setItem(ENCRYPTED_KEYS_STORAGE, stored);
  } else {
    localStorage.setItem(ENCRYPTED_KEYS_STORAGE, JSON.stringify({ v: 0, raw: payload }));
  }
}

export async function loadEncryptedApiKeys(): Promise<ApiKeysMap> {
  try {
    const raw = localStorage.getItem(ENCRYPTED_KEYS_STORAGE);
    if (!raw) return { ...EMPTY_API_KEYS };

    const parsed = JSON.parse(raw) as {
      v?: number;
      iv?: string;
      data?: string;
      raw?: string;
    };

    if (parsed.v === 1 && parsed.iv && parsed.data) {
      const cryptoKey = await getOrCreateMasterKey();
      if (!cryptoKey) return { ...EMPTY_API_KEYS };
      const ivBytes = base64ToBytes(parsed.iv);
      const dataBytes = base64ToBytes(parsed.data);
      const plainBuffer = await window.crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: ivBytes.buffer as ArrayBuffer },
        cryptoKey,
        dataBytes.buffer as ArrayBuffer
      );
      const decoded = new TextDecoder().decode(plainBuffer);
      return { ...EMPTY_API_KEYS, ...(JSON.parse(decoded) as Partial<ApiKeysMap>) };
    }

    if (parsed.v === 0 && parsed.raw) {
      return { ...EMPTY_API_KEYS, ...(JSON.parse(parsed.raw) as Partial<ApiKeysMap>) };
    }
  } catch {
    // Return empty keys if storage was cleared or master key rotated
  }
  return { ...EMPTY_API_KEYS };
}

export function loadCustomModels(): ModelOption[] {
  try {
    const raw = localStorage.getItem(CUSTOM_MODELS_STORAGE);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as ModelOption[]) : [];
  } catch {
    return [];
  }
}

export function saveCustomModels(models: ModelOption[]): void {
  localStorage.setItem(CUSTOM_MODELS_STORAGE, JSON.stringify(models));
}
