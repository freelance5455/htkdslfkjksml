import { DevisItem } from '../types';

export interface DevisCalculationResult {
  subtotalDZD: number;
  agencyFeeDZD: number;
  taxAmountDZD: number;
  totalDZD: number;
}

/**
 * Calculates accurate subtotal, agency fee, tax, and grand total for a Tourism By Taki quotation (Devis)
 */
export function calculateDevisTotals(
  items: DevisItem[],
  agencyFeeDZD: number = 0,
  taxRatePercent: number = 9 // Standard Algerian tourism VAT rate
): DevisCalculationResult {
  const subtotalDZD = items.reduce((acc, item) => {
    const qty = Math.max(0, item.quantity);
    const price = Math.max(0, item.unitPriceDZD);
    return acc + qty * price;
  }, 0);

  const safeAgencyFee = Math.max(0, agencyFeeDZD);
  const taxableBase = subtotalDZD + safeAgencyFee;
  const taxAmountDZD = Math.round((taxableBase * (taxRatePercent / 100)) * 100) / 100;
  const totalDZD = Math.round(taxableBase + taxAmountDZD);

  return {
    subtotalDZD,
    agencyFeeDZD: safeAgencyFee,
    taxAmountDZD,
    totalDZD,
  };
}

/**
 * Generates an official sequential Devis reference number for Tourism By Taki
 */
export function generateDevisNumber(sequence: number, year: number = 2026): string {
  const padded = String(sequence).padStart(4, '0');
  return `DEV-${year}-${padded}`;
}
