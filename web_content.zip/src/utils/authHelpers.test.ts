import assert from 'node:assert/strict';
import {
  mapFirebaseAuthError,
  resolvePortalRouteAccess,
  resolvePostAuthDestination,
  resolveWorkspaceAccess,
} from './authHelpers';

// 1. Google Authentication error mapping (signup, login, cancelled, popup blocked, domain)
{
  const googleCancelled = mapFirebaseAuthError({ code: 'auth/popup-closed-by-user' });
  assert.ok(googleCancelled.toLowerCase().includes('cancelled'));

  const popupBlocked = mapFirebaseAuthError({ code: 'auth/popup-blocked' });
  assert.ok(popupBlocked.toLowerCase().includes('popup'));

  const googleNotEnabled = mapFirebaseAuthError({ code: 'auth/operation-not-allowed' });
  assert.ok(googleNotEnabled.includes('Google Sign-In'));

  const domainErr = mapFirebaseAuthError(
    { code: 'auth/unauthorized-domain' },
    'ais-dev-example.run.app'
  );
  assert.ok(domainErr.includes('ais-dev-example.run.app'));
}

// 2. Single-login automatic role routing (Student vs Server-Verified Admin)
{
  assert.equal(resolvePostAuthDestination(false, 'idle'), 'require-auth');
  assert.equal(resolvePostAuthDestination(false, 'authorized'), 'require-auth');

  assert.equal(resolvePostAuthDestination(true, 'idle'), 'checking-role');
  assert.equal(resolvePostAuthDestination(true, 'checking'), 'checking-role');

  assert.equal(resolvePostAuthDestination(true, 'denied'), 'student-dashboard');
  assert.equal(resolvePostAuthDestination(true, 'authorized'), 'admin-dashboard');
}

// 3. Separate Admin Panel entry & Admin Dashboard navigation isolation
{
  // Normal student sees strictly student dashboard without admin navigation
  assert.equal(
    resolveWorkspaceAccess({
      isAuthenticated: true,
      adminCheckStatus: 'denied',
      entryIntent: 'student',
      adminWorkspacePreference: 'admin',
    }),
    'student-dashboard-only'
  );

  // Student attempting Admin Panel entry is denied
  assert.equal(
    resolveWorkspaceAccess({
      isAuthenticated: true,
      adminCheckStatus: 'denied',
      entryIntent: 'admin',
      adminWorkspacePreference: 'admin',
    }),
    'deny-admin-entry'
  );

  // Authorized Admin opens Admin Dashboard by default or via Admin Panel entry
  assert.equal(
    resolveWorkspaceAccess({
      isAuthenticated: true,
      adminCheckStatus: 'authorized',
      entryIntent: 'admin',
      adminWorkspacePreference: 'student',
    }),
    'admin-dashboard'
  );

  // Authorized Admin switching to Student View retains Admin Dashboard navigation option
  assert.equal(
    resolveWorkspaceAccess({
      isAuthenticated: true,
      adminCheckStatus: 'authorized',
      entryIntent: 'student',
      adminWorkspacePreference: 'student',
    }),
    'student-dashboard-with-admin-nav'
  );

  assert.equal(resolvePortalRouteAccess('admin', true, true), 'allow-admin');
  assert.equal(resolvePortalRouteAccess('admin', true, false), 'deny-admin-access');
}

console.log('All EduToon Auth, Admin Entry & Role Isolation tests passed (3/3 suites).');
