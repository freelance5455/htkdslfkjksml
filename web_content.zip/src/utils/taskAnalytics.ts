import { Task, TaskSubmission, SystemSettings } from '../types';

export interface DailyTrendPoint {
  date: string;          // e.g. "Sep 1"
  isoDate: string;       // "2026-09-01"
  dayLabel: string;      // "Mon", "Tue" etc.
  completions: number;   // number of completed tasks
  payoutCoins: number;   // total coins rewarded
  payoutCurrency: number;// real currency equivalent (e.g. INR ₹)
  uniqueUsers: number;   // active users count
  avgReward: number;     // avg coins per task
}

export interface CategoryMetric {
  category: string;
  categoryLabel: string;
  completions: number;
  totalCoins: number;
  avgCoins: number;
  percentage: number;
  color: string;
}

export interface PayoutOptimizationMetrics {
  total30DayCompletions: number;
  total30DayPayoutCoins: number;
  total30DayPayoutCurrency: number;
  avgDailyCompletions: number;
  avgDailyPayoutCoins: number;
  avgPayoutPerTask: number;
  activeCompletersCount: number;
  projectedMonthlyCoins: number;
  payoutHealthScore: number; // 0 - 100
  payoutHealthStatus: 'Healthy & Sustainable' | 'Moderate Burn' | 'High Inflation Risk';
  payoutHealthColor: string;
  recommendations: {
    id: string;
    type: 'positive' | 'warning' | 'tip';
    title: string;
    description: string;
    suggestedAction?: string;
  }[];
}

const CATEGORY_COLORS: Record<string, string> = {
  daily_checkin: '#10b981', // emerald
  google_tasks: '#3b82f6',  // blue
  quiz: '#8b5cf6',          // purple
  survey: '#f59e0b',        // amber
  vip_task: '#ec4899',      // pink
  external_partner: '#06b6d4', // cyan
  video_demo: '#ef4444',    // red
  game: '#6366f1',          // indigo
  review: '#14b8a6',        // teal
};

const CATEGORY_LABELS: Record<string, string> = {
  daily_checkin: 'Daily Check-in',
  google_tasks: 'Google Tasks',
  quiz: 'Knowledge Quiz',
  survey: 'User Surveys',
  vip_task: 'VIP Exclusive',
  external_partner: 'Partner Tasks',
  video_demo: 'Video Watch',
  game: 'Mini Games',
  review: 'App Reviews',
};

/**
 * Generates realistic 30-day historical task submissions for immediate visual analysis
 */
export function generateSeed30DaySubmissions(): TaskSubmission[] {
  const submissions: TaskSubmission[] = [];
  const baseDate = new Date();
  
  // Seed demo task templates
  const sampleTasks = [
    { id: 'task-1', title: 'Daily Productivity Check-in', coins: 25, cat: 'daily_checkin' },
    { id: 'task-2', title: 'Google Tasks: Complete a To-Do Item', coins: 50, cat: 'google_tasks' },
    { id: 'task-3', title: 'Cybersecurity & Safe Online Habits Quiz', coins: 40, cat: 'quiz' },
    { id: 'task-4', title: 'App Feedback & Feature Survey', coins: 35, cat: 'survey' },
    { id: 'task-vip-1', title: 'VIP Exclusive Ad Campaign Verification', coins: 200, cat: 'vip_task' },
    { id: 'task-yt-1', title: 'Watch Partner Educational Video', coins: 45, cat: 'video_demo' },
  ];

  const userIds = [
    'user-demo-1',
    'user-demo-2',
    'user-demo-3',
    'user-demo-4',
    'user-demo-5',
    'user-demo-6',
    'user-demo-7'
  ];

  // Generate day by day for the past 30 days
  for (let i = 29; i >= 0; i--) {
    const targetDate = new Date(baseDate);
    targetDate.setDate(targetDate.getDate() - i);
    const dayOfWeek = targetDate.getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

    // Base volume: higher on weekends, organic curve rising towards recent days
    const baseCount = Math.floor(6 + (29 - i) * 0.25 + (isWeekend ? 4 : 0));
    const dayCount = Math.max(3, baseCount + Math.floor((Math.sin(i * 0.8) * 3)));

    for (let j = 0; j < dayCount; j++) {
      const taskIndex = Math.floor(Math.random() * sampleTasks.length);
      const chosenTask = sampleTasks[taskIndex];
      const userIndex = Math.floor(Math.random() * userIds.length);
      const chosenUser = userIds[userIndex];

      // Distribute completion hours organically throughout the day
      const hour = Math.floor(8 + Math.random() * 14); // 8 AM to 10 PM
      const minute = Math.floor(Math.random() * 60);
      const submissionDate = new Date(targetDate);
      submissionDate.setHours(hour, minute, Math.floor(Math.random() * 60));

      submissions.push({
        id: `sub-seed-${i}-${j}-${Date.now().toString(36)}`,
        userId: chosenUser,
        taskId: chosenTask.id,
        taskTitle: chosenTask.title,
        rewardCoins: chosenTask.coins,
        rewardRupees: chosenTask.coins,
        completedAt: submissionDate.toISOString(),
        status: 'completed',
        proofText: chosenTask.cat === 'quiz' ? '3/3 Correct Answers' : 'Completed and verified automatically',
      });
    }
  }

  return submissions;
}

/**
 * Computes 30-day day-by-day trend data for Recharts
 */
export function get30DayCompletionTrendData(
  submissions: TaskSubmission[],
  systemSettings: SystemSettings,
  daysRange: number = 30
): DailyTrendPoint[] {
  const now = new Date();
  const points: DailyTrendPoint[] = [];
  const coinsPerCurrency = systemSettings?.coinsPerCurrencyUnit || 1;

  for (let i = daysRange - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const isoString = d.toISOString().split('T')[0]; // YYYY-MM-DD
    
    const monthName = d.toLocaleDateString('en-US', { month: 'short' });
    const dayNum = d.getDate();
    const dayLabel = d.toLocaleDateString('en-US', { weekday: 'short' });

    // Filter submissions on this date
    const daySubs = submissions.filter((s) => s.completedAt.startsWith(isoString));
    const completions = daySubs.length;
    const payoutCoins = daySubs.reduce((sum, s) => sum + s.rewardCoins, 0);
    const payoutCurrency = Number((payoutCoins / coinsPerCurrency).toFixed(2));
    const uniqueUsers = new Set(daySubs.map((s) => s.userId)).size;
    const avgReward = completions > 0 ? Math.round(payoutCoins / completions) : 0;

    points.push({
      date: `${monthName} ${dayNum}`,
      isoDate: isoString,
      dayLabel,
      completions,
      payoutCoins,
      payoutCurrency,
      uniqueUsers,
      avgReward,
    });
  }

  return points;
}

/**
 * Calculates category breakdown metrics for pie & bar distribution
 */
export function getCategoryBreakdownData(
  submissions: TaskSubmission[],
  tasks: Task[]
): CategoryMetric[] {
  const taskMap = new Map(tasks.map((t) => [t.id, t.category]));
  const categoryStats: Record<string, { completions: number; totalCoins: number }> = {};

  submissions.forEach((sub) => {
    const category = taskMap.get(sub.taskId) || 'daily_checkin';
    if (!categoryStats[category]) {
      categoryStats[category] = { completions: 0, totalCoins: 0 };
    }
    categoryStats[category].completions += 1;
    categoryStats[category].totalCoins += sub.rewardCoins;
  });

  const totalCompletions = submissions.length || 1;

  return Object.keys(categoryStats).map((cat) => {
    const data = categoryStats[cat];
    return {
      category: cat,
      categoryLabel: CATEGORY_LABELS[cat] || cat.replace('_', ' ').toUpperCase(),
      completions: data.completions,
      totalCoins: data.totalCoins,
      avgCoins: Math.round(data.totalCoins / data.completions),
      percentage: Number(((data.completions / totalCompletions) * 100).toFixed(1)),
      color: CATEGORY_COLORS[cat] || '#64748b',
    };
  }).sort((a, b) => b.completions - a.completions);
}

/**
 * Calculates actionable payout optimization recommendations
 */
export function getPayoutOptimizationMetrics(
  trendPoints: DailyTrendPoint[],
  submissions: TaskSubmission[],
  tasks: Task[],
  systemSettings: SystemSettings
): PayoutOptimizationMetrics {
  const total30DayCompletions = trendPoints.reduce((sum, p) => sum + p.completions, 0);
  const total30DayPayoutCoins = trendPoints.reduce((sum, p) => sum + p.payoutCoins, 0);
  const total30DayPayoutCurrency = trendPoints.reduce((sum, p) => sum + p.payoutCurrency, 0);

  const daysCount = trendPoints.length || 30;
  const avgDailyCompletions = Math.round(total30DayCompletions / daysCount);
  const avgDailyPayoutCoins = Math.round(total30DayPayoutCoins / daysCount);
  const avgPayoutPerTask = total30DayCompletions > 0 
    ? Math.round(total30DayPayoutCoins / total30DayCompletions) 
    : 0;

  const allActiveUsers = new Set(submissions.map((s) => s.userId));
  const activeCompletersCount = allActiveUsers.size;
  const projectedMonthlyCoins = avgDailyPayoutCoins * 30;

  // Determine payout health score based on velocity and balance
  let payoutHealthScore = 92;
  let payoutHealthStatus: 'Healthy & Sustainable' | 'Moderate Burn' | 'High Inflation Risk' = 'Healthy & Sustainable';
  let payoutHealthColor = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';

  if (avgPayoutPerTask > 120) {
    payoutHealthScore = 68;
    payoutHealthStatus = 'Moderate Burn';
    payoutHealthColor = 'text-amber-400 bg-amber-500/10 border-amber-500/30';
  } else if (avgPayoutPerTask > 250) {
    payoutHealthScore = 45;
    payoutHealthStatus = 'High Inflation Risk';
    payoutHealthColor = 'text-rose-400 bg-rose-500/10 border-rose-500/30';
  }

  const recommendations: PayoutOptimizationMetrics['recommendations'] = [
    {
      id: 'rec-1',
      type: 'tip',
      title: 'Optimal Reward Range for Daily Check-in',
      description: 'Your current check-in baseline of 25 coins generates steady user retention with minimal coin liability. Maintain streak multipliers between 1.2x and 2.0x for max loyalty.',
      suggestedAction: 'Keep Base Check-in 25-30 Coins'
    },
    {
      id: 'rec-2',
      type: avgPayoutPerTask > 80 ? 'warning' : 'positive',
      title: 'Average Task Cost Assessment',
      description: `Current average payout per task is 🪙${avgPayoutPerTask} coins (${systemSettings?.currencySymbol || '₹'}${avgPayoutPerTask}). This is within the sustainable engagement band.`,
      suggestedAction: 'Recommended cap: 100 coins for general tasks'
    },
    {
      id: 'rec-3',
      type: 'tip',
      title: 'Proof Verification Impact on Payouts',
      description: 'Tasks requiring proof (screenshots or verification words) deter automated clicks by 98% while ensuring legitimate engagement for advertisers and partner portals.',
      suggestedAction: 'Enable "Requires Proof" on high-coin tasks (>50 coins)'
    },
    {
      id: 'rec-4',
      type: 'positive',
      title: 'VIP Task ROI Optimization',
      description: 'VIP tasks require active membership plan subscriptions, making high coin rewards (₹200 - ₹400) self-funding from user upfront plan payments.',
      suggestedAction: 'Keep VIP task daily limits at 2-3 per member'
    }
  ];

  return {
    total30DayCompletions,
    total30DayPayoutCoins,
    total30DayPayoutCurrency,
    avgDailyCompletions,
    avgDailyPayoutCoins,
    avgPayoutPerTask,
    activeCompletersCount,
    projectedMonthlyCoins,
    payoutHealthScore,
    payoutHealthStatus,
    payoutHealthColor,
    recommendations,
  };
}
