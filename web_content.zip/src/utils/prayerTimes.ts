// Prayer Times Calculation, Expiration Detection & Remaining Hours/Minutes Utility for Habivio

export interface PrayerPeriodConfig {
  key: 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha' | 'tahajjud';
  nameEn: string;
  nameBn: string;
  defaultStart: string; // "HH:MM"
  defaultEnd: string;   // "HH:MM"
  icon: string;
  rakats: string;
  isVoluntary?: boolean;
}

export const DEFAULT_PRAYER_PERIODS: PrayerPeriodConfig[] = [
  {
    key: 'fajr',
    nameEn: 'Fajr',
    nameBn: 'ফজর',
    defaultStart: '05:00',
    defaultEnd: '06:15', // Sunrise
    icon: '🌅',
    rakats: '2 Rakat',
  },
  {
    key: 'dhuhr',
    nameEn: 'Dhuhr',
    nameBn: 'যোহর',
    defaultStart: '12:05',
    defaultEnd: '15:45',
    icon: '☀️',
    rakats: '4 Rakat',
  },
  {
    key: 'asr',
    nameEn: 'Asr',
    nameBn: 'আসর',
    defaultStart: '15:45',
    defaultEnd: '17:35', // Sunset / Maghrib start
    icon: '⛅',
    rakats: '4 Rakat',
  },
  {
    key: 'maghrib',
    nameEn: 'Maghrib',
    nameBn: 'মাগরিব',
    defaultStart: '17:35',
    defaultEnd: '18:50',
    icon: '🌇',
    rakats: '3 Rakat',
  },
  {
    key: 'isha',
    nameEn: 'Isha',
    nameBn: 'এশা',
    defaultStart: '18:50',
    defaultEnd: '05:00', // Spans midnight until Fajr dawn
    icon: '🌙',
    rakats: '4 Rakat',
  },
  {
    key: 'tahajjud',
    nameEn: 'Tahajjud',
    nameBn: 'তাহাজ্জুদ',
    defaultStart: '03:30',
    defaultEnd: '05:00',
    icon: '✨',
    rakats: 'Nafil',
    isVoluntary: true,
  },
];

export interface PrayerStatusInfo {
  key: string;
  name: string;
  icon: string;
  startTime: string;
  endTime: string;
  status: 'upcoming' | 'active' | 'expired';
  isExpired: boolean;
  isActive: boolean;
  isUpcoming: boolean;
  remainingMinutes: number;
  remainingHours: number;
  remainingMinsOnly: number;
  totalDurationMinutes: number;
  elapsedMinutes: number;
  progressPercent: number;
  formattedRemaining: string;
  formattedHoursAndMinutes: string;
  formattedTimeRange: string;
}

// Convert "HH:MM" string to minutes from 00:00
export function timeStringToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  const parts = timeStr.split(':').map((p) => parseInt(p, 10));
  if (parts.length < 2 || isNaN(parts[0]) || isNaN(parts[1])) return 0;
  return parts[0] * 60 + parts[1];
}

// Convert Bengali numerals
export function toBengaliNumerals(num: number | string): string {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(num).replace(/[0-9]/g, (w) => bnDigits[parseInt(w, 10)]);
}

// Format duration into hours first, then minutes ("আগে ঘন্টা পরে মিনিট")
export function formatHoursAndMinutes(totalMinutes: number, isBn = false): string {
  if (totalMinutes <= 0) {
    return isBn ? '০ মিনিট' : '0 min';
  }
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  if (hours > 0 && minutes > 0) {
    return isBn
      ? `${toBengaliNumerals(hours)} ঘণ্টা ${toBengaliNumerals(minutes)} মিনিট`
      : `${hours} hr ${minutes} min`;
  } else if (hours > 0) {
    return isBn
      ? `${toBengaliNumerals(hours)} ঘণ্টা`
      : `${hours} hr`;
  } else {
    return isBn
      ? `${toBengaliNumerals(minutes)} মিনিট`
      : `${minutes} min`;
  }
}

// Format "HH:MM" 24h time to 12h with pure localized numerals (৭:১৫ vs 7:15)
export function formatTo12Hour(timeStr: string, isBn = false, includePeriod = false): string {
  if (!timeStr) return '';
  const [h, m] = timeStr.split(':').map(Number);
  if (isNaN(h) || isNaN(m)) return timeStr;
  const period = h >= 12 ? 'PM' : 'AM';
  const periodBn = h >= 12 ? 'পিএম' : 'এএম';
  const hours12 = h % 12 === 0 ? 12 : h % 12;
  const formattedM = String(m).padStart(2, '0');
  const formattedH = String(hours12).padStart(2, '0');

  if (isBn) {
    const timeBn = `${toBengaliNumerals(formattedH)}:${toBengaliNumerals(formattedM)}`;
    return includePeriod ? `${timeBn} ${periodBn}` : timeBn;
  }
  const timeEn = `${formattedH}:${formattedM}`;
  return includePeriod ? `${timeEn} ${period}` : timeEn;
}

// Get prayer periods dynamically adapting for Holy Friday (Jummah)
export function getPrayerPeriods(now: Date = new Date()): PrayerPeriodConfig[] {
  const isFriday = now.getDay() === 5;
  return DEFAULT_PRAYER_PERIODS.map((period) => {
    if (period.key === 'dhuhr' && isFriday) {
      return {
        ...period,
        nameEn: 'Jummah',
        nameBn: 'জুম্মা',
        icon: '🕌',
      };
    }
    return period;
  });
}

/**
 * Calculates live waqt status for a given prayer period.
 * Handles daytime prayers as well as midnight-spanning Isha and Tahajjud.
 * Always formats remaining time as hours first, then minutes (আগে ঘণ্টা, পরে মিনিট).
 */
export function calculatePrayerStatus(
  key: string,
  startTime: string,
  endTime: string,
  now: Date = new Date(),
  isBn = false
): {
  status: 'upcoming' | 'active' | 'expired';
  isExpired: boolean;
  isActive: boolean;
  isUpcoming: boolean;
  remainingMinutes: number;
  remainingHours: number;
  remainingMinsOnly: number;
  progressPercent: number;
  formattedRemaining: string;
  formattedHoursAndMinutes: string;
} {
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const startMin = timeStringToMinutes(startTime);
  const endMin = timeStringToMinutes(endTime);

  // Standard case: startMin < endMin (e.g. Fajr 05:00 -> 06:15, Dhuhr 12:05 -> 15:45)
  if (startMin < endMin) {
    if (currentMinutes < startMin) {
      const remaining = startMin - currentMinutes;
      const hours = Math.floor(remaining / 60);
      const minsOnly = remaining % 60;
      const formattedDuration = formatHoursAndMinutes(remaining, isBn);
      const formattedRemaining = isBn
        ? `শুরু হতে আর ${formattedDuration} বাকি`
        : `Starts in ${formattedDuration}`;

      return {
        status: 'upcoming',
        isExpired: false,
        isActive: false,
        isUpcoming: true,
        remainingMinutes: remaining,
        remainingHours: hours,
        remainingMinsOnly: minsOnly,
        progressPercent: 0,
        formattedRemaining,
        formattedHoursAndMinutes: formattedDuration,
      };
    } else if (currentMinutes <= endMin) {
      const remaining = endMin - currentMinutes;
      const hours = Math.floor(remaining / 60);
      const minsOnly = remaining % 60;
      const duration = endMin - startMin;
      const elapsed = currentMinutes - startMin;
      const percent = duration > 0 ? Math.min(100, Math.round((elapsed / duration) * 100)) : 0;
      const formattedDuration = formatHoursAndMinutes(remaining, isBn);
      const formattedRemaining = isBn
        ? `ওয়াক্ত শেষ হতে আর ${formattedDuration} বাকি`
        : `${formattedDuration} remaining until end`;

      return {
        status: 'active',
        isExpired: false,
        isActive: true,
        isUpcoming: false,
        remainingMinutes: remaining,
        remainingHours: hours,
        remainingMinsOnly: minsOnly,
        progressPercent: percent,
        formattedRemaining,
        formattedHoursAndMinutes: formattedDuration,
      };
    } else {
      // Past end time
      return {
        status: 'expired',
        isExpired: true,
        isActive: false,
        isUpcoming: false,
        remainingMinutes: 0,
        remainingHours: 0,
        remainingMinsOnly: 0,
        progressPercent: 100,
        formattedRemaining: isBn ? 'ওয়াক্ত শেষ হয়ে গেছে' : 'Waqt Expired',
        formattedHoursAndMinutes: isBn ? 'ওয়াক্ত শেষ' : 'Expired',
      };
    }
  }

  // Midnight wrap case: startMin >= endMin (e.g. Isha 18:50 -> 05:00 next day)
  // Active if currentMinutes >= 18:50 (evening) OR currentMinutes <= 05:00 (early morning)
  const isNightActive = currentMinutes >= startMin || currentMinutes <= endMin;

  if (isNightActive) {
    let remaining = 0;
    const duration = (1440 - startMin) + endMin;

    if (currentMinutes >= startMin) {
      remaining = (1440 - currentMinutes) + endMin;
    } else {
      remaining = endMin - currentMinutes;
    }

    const elapsed = currentMinutes >= startMin
      ? currentMinutes - startMin
      : (1440 - startMin) + currentMinutes;

    const percent = duration > 0 ? Math.min(100, Math.round((elapsed / duration) * 100)) : 0;
    const hours = Math.floor(remaining / 60);
    const minsOnly = remaining % 60;
    const formattedDuration = formatHoursAndMinutes(remaining, isBn);
    const formattedRemaining = isBn
      ? `ওয়াক্ত শেষ হতে আর ${formattedDuration} বাকি`
      : `${formattedDuration} remaining until end`;

    return {
      status: 'active',
      isExpired: false,
      isActive: true,
      isUpcoming: false,
      remainingMinutes: remaining,
      remainingHours: hours,
      remainingMinsOnly: minsOnly,
      progressPercent: percent,
      formattedRemaining,
      formattedHoursAndMinutes: formattedDuration,
    };
  } else {
    // Current time is between endMin and startMin (e.g. 05:01 to 18:49)
    // For today, it is upcoming in the evening
    const remaining = startMin - currentMinutes;
    const hours = Math.floor(remaining / 60);
    const minsOnly = remaining % 60;
    const formattedDuration = formatHoursAndMinutes(remaining, isBn);
    const formattedRemaining = isBn
      ? `শুরু হতে আর ${formattedDuration} বাকি`
      : `Starts in ${formattedDuration}`;

    return {
      status: 'upcoming',
      isExpired: false,
      isActive: false,
      isUpcoming: true,
      remainingMinutes: remaining,
      remainingHours: hours,
      remainingMinsOnly: minsOnly,
      progressPercent: 0,
      formattedRemaining,
      formattedHoursAndMinutes: formattedDuration,
    };
  }
}

/**
 * Returns complete prayer statuses for all 5 obligatory prayers + Tahajjud
 */
export function getAllPrayerStatuses(
  customTimes: Record<string, string> = {},
  now: Date = new Date(),
  isBn = false
): PrayerStatusInfo[] {
  const periods = getPrayerPeriods(now);
  return periods.map((period) => {
    const startTime = customTimes[`${period.key}Start`] || period.defaultStart;
    const endTime = customTimes[`${period.key}End`] || period.defaultEnd;
    const statusResult = calculatePrayerStatus(period.key, startTime, endTime, now, isBn);

    const name = isBn ? period.nameBn : period.nameEn;
    const formattedTimeRange = `${formatTo12Hour(startTime, isBn)} - ${formatTo12Hour(endTime, isBn)}`;

    return {
      key: period.key,
      name,
      icon: period.icon,
      startTime,
      endTime,
      status: statusResult.status,
      isExpired: statusResult.isExpired,
      isActive: statusResult.isActive,
      isUpcoming: statusResult.isUpcoming,
      remainingMinutes: statusResult.remainingMinutes,
      remainingHours: statusResult.remainingHours,
      remainingMinsOnly: statusResult.remainingMinsOnly,
      totalDurationMinutes: 0,
      elapsedMinutes: 0,
      progressPercent: statusResult.progressPercent,
      formattedRemaining: statusResult.formattedRemaining,
      formattedHoursAndMinutes: statusResult.formattedHoursAndMinutes,
      formattedTimeRange,
    };
  });
}

/**
 * Find the currently active prayer waqt, if any
 */
export function getActivePrayerWaqt(
  customTimes: Record<string, string> = {},
  now: Date = new Date(),
  isBn = false
): PrayerStatusInfo | null {
  const all = getAllPrayerStatuses(customTimes, now, isBn);
  // Prioritize obligatory active prayer over voluntary
  const activeObligatory = all.find((p) => p.isActive && p.key !== 'tahajjud');
  if (activeObligatory) return activeObligatory;
  return all.find((p) => p.isActive) || null;
}
