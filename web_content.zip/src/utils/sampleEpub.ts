import JSZip from 'jszip';

/**
 * Creates a valid, real EPUB 3 file buffer locally using JSZip
 * Useful for instant verification and debugging.
 */
export async function createSampleEpub(): Promise<ArrayBuffer> {
  const zip = new JSZip();

  // 1. mimetype (MUST be first file in EPUB, uncompressed)
  zip.file('mimetype', 'application/epub+zip', { compression: 'STORE' });

  // 2. META-INF/container.xml
  zip.file(
    'META-INF/container.xml',
    `<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>`
  );

  // 3. OEBPS/content.opf
  zip.file(
    'OEBPS/content.opf',
    `<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" unique-identifier="pub-id" version="3.0">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:identifier id="pub-id">urn:uuid:prueba-epub-sample-001</dc:identifier>
    <dc:title>El Arte de la Lectura Digital</dc:title>
    <dc:creator>Biblioteca Técnica</dc:creator>
    <dc:language>es</dc:language>
    <dc:description>Libro de prueba técnica para validar renderizado, selección de texto, resaltados y almacenamiento local en APK Android.</dc:description>
    <meta property="dcterms:modified">2026-10-05T00:00:00Z</meta>
  </metadata>
  <manifest>
    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
    <item id="style" href="style.css" media-type="text/css"/>
    <item id="chapter1" href="chapter1.xhtml" media-type="application/xhtml+xml"/>
    <item id="chapter2" href="chapter2.xhtml" media-type="application/xhtml+xml"/>
    <item id="chapter3" href="chapter3.xhtml" media-type="application/xhtml+xml"/>
  </manifest>
  <spine>
    <itemref idref="chapter1"/>
    <itemref idref="chapter2"/>
    <itemref idref="chapter3"/>
  </spine>
</package>`
  );

  // 4. OEBPS/nav.xhtml
  zip.file(
    'OEBPS/nav.xhtml',
    `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head>
  <title>Índice de Contenido</title>
</head>
<body>
  <nav epub:type="toc" id="toc">
    <h1>Índice</h1>
    <ol>
      <li><a href="chapter1.xhtml">Capítulo 1: Introducción a la Lectura</a></li>
      <li><a href="chapter2.xhtml">Capítulo 2: Selección y Resaltados</a></li>
      <li><a href="chapter3.xhtml">Capítulo 3: Persistencia en APK</a></li>
    </ol>
  </nav>
</body>
</html>`
  );

  // 5. OEBPS/style.css
  zip.file(
    'OEBPS/style.css',
    `body {
  font-family: system-ui, -apple-system, sans-serif;
  line-height: 1.7;
  padding: 1rem;
}
h1 {
  font-size: 1.6rem;
  margin-bottom: 1rem;
  border-bottom: 1px solid rgba(255,255,255,0.15);
  padding-bottom: 0.5rem;
}
p {
  margin-bottom: 1.2rem;
  font-size: 1.05rem;
}
.quote {
  font-style: italic;
  padding: 0.75rem 1rem;
  border-left: 3px solid #3b82f6;
  background: rgba(255,255,255,0.03);
  margin: 1.5rem 0;
}`
  );

  // 6. OEBPS/chapter1.xhtml
  zip.file(
    'OEBPS/chapter1.xhtml',
    `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Capítulo 1</title>
  <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
  <h1>Capítulo 1: Introducción a la Lectura</h1>
  <p>Bienvenido a la prueba técnica de renderizado de archivos EPUB para entornos móviles y aplicaciones web empaquetadas en Android.</p>
  <p>Los libros electrónicos en formato EPUB son contenedores basados en estándares web abiertos (XHTML, CSS y metadatos XML). Cada capítulo corresponde a un documento estructurado que permite un ajuste fluido del texto a cualquier tamaño de pantalla.</p>
  <div class="quote">
    «Un lector vive mil vidas antes de morir. Aquel que nunca lee vive solo una.» — George R.R. Martin
  </div>
  <p>Puedes probar desplazándote a través de este contenido, navegando entre capítulos mediante la barra de controles superior o inferior, y seleccionando cualquier fragmento de texto con el dedo o el ratón para crear un resaltado.</p>
</body>
</html>`
  );

  // 7. OEBPS/chapter2.xhtml
  zip.file(
    'OEBPS/chapter2.xhtml',
    `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Capítulo 2</title>
  <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
  <h1>Capítulo 2: Selección y Resaltados</h1>
  <p>Una de las características más críticas de cualquier lector digital es la capacidad de subrayar o destacar pasajes significativos.</p>
  <p>En este visor, cuando seleccionas cualquier palabra o frase, el motor captura las coordenadas canónicas del fragmento (CFI o Canonical Fragment Identifier). El CFI es una especificación estándar de la IDPF que identifica de forma inequívoca cualquier rango de caracteres dentro del archivo EPUB, independientemente del tamaño de pantalla o del tipo de letra utilizado.</p>
  <p>Al pulsar el botón <strong>«Resaltar»</strong>, la marca se guarda inmediatamente en la base de datos local del dispositivo (IndexedDB). Si sales de la aplicación o la cierras completamente y vuelves a abrirla, los resaltados seguirán presentes en su posición exacta original.</p>
</body>
</html>`
  );

  // 8. OEBPS/chapter3.xhtml
  zip.file(
    'OEBPS/chapter3.xhtml',
    `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Capítulo 3</title>
  <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
  <h1>Capítulo 3: Persistencia en APK</h1>
  <p>Cuando esta aplicación web se empaqueta como un archivo APK utilizando Apache Cordova o Capacitor, se ejecuta dentro de un componente WebView de Android.</p>
  <p>El almacenamiento de IndexedDB funciona de forma totalmente nativa y persistente en el dispositivo del usuario. No requiere conexión a internet, ni servidores externos, ni cuentas de usuario. Tanto el archivo binario del libro como los marcadores de posición y resaltados permanecen en la memoria local protegida del teléfono.</p>
  <p>Con esto concluye la verificación de la estructura del libro de muestra. ¡Prueba a importar tu propio archivo .epub real para comprobar su funcionamiento!</p>
</body>
</html>`
  );

  return await zip.generateAsync({ type: 'arraybuffer', mimeType: 'application/epub+zip' });
}
