// Wake word, interruption, and command parsing utilities for English and Bangla (বাংলা)

// Wake words in English & Bengali
const WAKE_PATTERNS = [
  // English
  /\b(hey|hi|hello|ok|okay)?\s*jarvis\b/i,
  /\bjarvis\b/i,
  // Bengali
  /(হে|এই|হ্যালো|ওহে)?\s*জার্ভিস/i,
  /(হে|এই|হ্যালো|ওহে)?\s*জারভিস/i,
  /জার্ভিস/i,
  /জারভিস/i,
];

// Stop / Sleep phrases in English & Bengali
const STOP_PATTERNS = [
  // English
  /\b(stop now|go to sleep|jarvis sleep|sleep now|stop listening|shut down|good night|pause listening|stand down|halt)\b/i,
  /\bstop\b/i,
  // Bengali
  /(এখন থামো|ঘুমাও|জার্ভিস ঘুমাও|থামো|বন্ধ করো|ঘুমাতে যাও|স্লিপ মোডে যাও|বিশ্রাম নাও)/i,
];

// Barge-in / Interruption phrases in English & Bengali (specifically used to cut off speech)
const INTERRUPT_PATTERNS = [
  // English
  /\b(stop|stop now|shut up|wait|hold on|pause|quiet|be quiet|cancel|enough|jarvis|hey jarvis|listen)\b/i,
  // Bengali
  /(থামো|এখন থামো|চুপ|চুপ করো|দাঁড়াও|একটু থামো|শোনো|জার্ভিস|বন্ধ করো|আর বলতে হবে না)/i,
];

/**
 * Checks if the speech transcript contains a wake word
 */
export function hasWakeWord(text: string): boolean {
  if (!text) return false;
  const clean = text.trim();
  return WAKE_PATTERNS.some((pattern) => pattern.test(clean));
}

/**
 * Checks if the speech transcript contains a stop / go-to-sleep phrase
 */
export function hasStopPhrase(text: string): boolean {
  if (!text) return false;
  const clean = text.trim();
  return STOP_PATTERNS.some((pattern) => pattern.test(clean));
}

/**
 * Checks if the speech transcript contains a voice interruption phrase
 */
export function hasInterruptPhrase(text: string): boolean {
  if (!text) return false;
  const clean = text.trim();
  return INTERRUPT_PATTERNS.some((pattern) => pattern.test(clean));
}

/**
 * Removes the wake word prefix from the user speech to get the actual command.
 * E.g.: "Jarvis what is quantum computing" -> "what is quantum computing"
 * E.g.: "জার্ভিস আজকের আবহাওয়া কেমন" -> "আজকের আবহাওয়া কেমন"
 */
export function extractCommand(text: string): string {
  if (!text) return '';
  let cleaned = text.trim();

  // Strip English wake prefixes
  cleaned = cleaned.replace(/^(hey|hi|hello|ok|okay)?\s*jarvis[,.:?!]?\s*/i, '');
  cleaned = cleaned.replace(/\bjarvis[,.:?!]?\s*/i, '');

  // Strip Bengali wake prefixes
  cleaned = cleaned.replace(/^(হে|এই|হ্যালো|ওহে)?\s*জার্ভিস[,.:?!]?\s*/i, '');
  cleaned = cleaned.replace(/^(হে|এই|হ্যালো|ওহে)?\s*জারভিস[,.:?!]?\s*/i, '');
  cleaned = cleaned.replace(/^জার্ভিস[,.:?!]?\s*/i, '');
  cleaned = cleaned.replace(/^জারভিস[,.:?!]?\s*/i, '');

  return cleaned.trim();
}

/**
 * Detect language from text (checks for Bengali script range \u0980-\u09FF)
 */
export function detectLanguageFromText(text: string): 'bn' | 'en' {
  if (!text) return 'en';
  // Bengali Unicode block is 0980–09FF
  const hasBengali = /[\u0980-\u09FF]/.test(text);
  return hasBengali ? 'bn' : 'en';
}

/**
 * Helper to determine if an incoming speech recognition transcript is an echo
 * of what JARVIS is currently vocalizing through device speakers.
 * If incoming speech matches words that JARVIS is currently speaking, it's echo.
 * If user speaks a wake word, stop word, or distinct command words, it is NOT echo.
 */
export function isSpokenTextEcho(
  incomingTranscript: string,
  currentlySpokenText: string
): boolean {
  if (!incomingTranscript || !currentlySpokenText) return false;

  // Wake word or stop word is ALWAYS an intentional user command, never considered echo
  if (hasWakeWord(incomingTranscript) || hasStopPhrase(incomingTranscript)) {
    return false;
  }

  const normalize = (s: string) =>
    s
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, '')
      .split(/\s+/)
      .filter((w) => w.length > 1);

  const incomingWords = normalize(incomingTranscript);
  if (incomingWords.length === 0) return true;

  const assistantWords = new Set(normalize(currentlySpokenText));

  // Count how many words of the incoming transcript match the assistant's speech
  let matchCount = 0;
  for (const word of incomingWords) {
    if (assistantWords.has(word)) {
      matchCount++;
    }
  }

  // If >= 70% of the words match what JARVIS is speaking, consider it speaker echo
  const matchRatio = matchCount / incomingWords.length;
  return matchRatio >= 0.7;
}
