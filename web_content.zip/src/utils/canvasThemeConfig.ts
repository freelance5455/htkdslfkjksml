import { CanvasThemeStyle, CanvasThemeDefinition } from "../types";

export const CANVAS_THEME_DEFINITIONS: Record<CanvasThemeStyle, CanvasThemeDefinition> = {
  hybrid_white: {
    id: "hybrid_white",
    title: "1. Modern Minimalist",
    subtitle: "The Clean Canvas - Saf Odaklanma",
    badge: "Clean Canvas",
    description: "Sadelik ön planda. Gündüz saf beyaz ve koyu gri tipografi; Gece komür siyahı (#1A1A1A) ve yüksek kontrastlı minimalist odaklanma.",
    dayBg: "#FFFFFF",
    nightBg: "#1A1A1A",
    dayText: "#1E293B",
    nightText: "#F8FAFC",
    bgGradient: "from-[#FFFFFF] via-[#FAFAFA] to-[#F8FAFC]",
    lineStructureDesc: "Çizgisiz, sade ve auto-hidden gizlenebilir üst bar alanı",
    typographyDesc: "Koyu gri / Yüksek kontrastlı beyaz minimalist sans-serif",
    lineType: "clean_white",
    fontFamily: "'Inter', -apple-system, system-ui, sans-serif",
    headingColor: "#0F172A",
    features: [
      "Gündüz: Saf Beyaz (#FFFFFF)",
      "Gece: Kömür Siyahı (#1A1A1A)",
      "Gizlenebilir Auto-Hidden Çubuk",
      "Göz Yormayan Minimalist Yapı",
    ],
  },
  zen_sapphire: {
    id: "zen_sapphire",
    title: "2. Katmanlı Sensörel",
    subtitle: "Layered Depth - Cam Dokusu & Derinlik",
    badge: "Layered Depth",
    description: "Sıcak krem (#FDFBF7) ve buzlu cam (glassmorphism) katmanları; Gece derin safir mavisi (#0A1128), katman gölgeleri ve altın/kehribar parıltısı.",
    dayBg: "#FDFBF7",
    nightBg: "#0A1128",
    dayText: "#1E293B",
    nightText: "#E0F2FE",
    bgGradient: "from-[#0A1128] via-[#101A36] to-[#1C2541]",
    lineStructureDesc: "Buzlu cam katmanları, ızgara (grid) hatları ve derinlik gölgeleri",
    typographyDesc: "Safir mavisi vurgular, kehribar/altın parıltılı imleç",
    lineType: "sapphire_grid",
    fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif",
    headingColor: "#38BDF8",
    features: [
      "Gündüz: Sıcak Krem (#FDFBF7) & Safir",
      "Gece: Derin Safir Mavisi (#0A1128)",
      "Buzlu Cam (Glassmorphism)",
      "Altın/Kehribar Radyal Parıltı",
    ],
  },
  fluid_parchment: {
    id: "fluid_parchment",
    title: "3. Hibrit Kanvas",
    subtitle: "Interactive Drawing & Stylus - Çizim Katmanı",
    badge: "Interactive Canvas",
    description: "Yumuşak parşömen (#F5EFEB) kâğıt dokusu, sınırsız kanvas hissi; Gece koyu lacivert kanvas (#081432), parlayan neon çizgiler ve avuç içi engelleme.",
    dayBg: "#F5EFEB",
    nightBg: "#081432",
    dayText: "#291804",
    nightText: "#E2E8F0",
    bgGradient: "from-[#FDFBF7] via-[#FAF6F0] to-[#F5EFEB]",
    lineStructureDesc: "Yumuşak altın yatay çizgiler ve neon parıltı kalem izleri",
    typographyDesc: "Klasik serif & el yazısı / klavye metni hibrit desteği",
    lineType: "horizontal_gold",
    fontFamily: "'Georgia', 'Comic Sans MS', cursive, serif",
    headingColor: "#78350F",
    features: [
      "Gündüz: Yumuşak Parşömen (#F5EFEB)",
      "Gece: Koyu Lacivert Kanvas (#081432)",
      "Parlayan Neon Kalem Uçları (Glow)",
      "Palm Rejection (Avuç İçi Filtresi)",
    ],
  },
  timeline_chronicle: {
    id: "timeline_chronicle",
    title: "4. Kronolojik Akış",
    subtitle: "Chronicle Timeline - Zaman Tüneli",
    badge: "Chronicle",
    description: "Temiz nötr gri (#F5F5F5) arka plan, üst kaydırılabilir renkli etiket rozetleri (Tags, Klasör, Tarih); Gece koyu kömür ve amber zaman çizelgesi.",
    dayBg: "#F5F5F5",
    nightBg: "#121827",
    dayText: "#1F2937",
    nightText: "#F3F4F6",
    bgGradient: "from-[#F4EFEA] via-[#F9F7F5] to-[#EFEAE4]",
    lineStructureDesc: "Dikey kronolojik çizelge, medya ve ses dalgası kartları",
    typographyDesc: "Modern yapılandırılmış blok tipi zaman damgalı tipografi",
    lineType: "timeline_vertical",
    fontFamily: "'Inter', -apple-system, sans-serif",
    headingColor: "#334155",
    features: [
      "Gündüz: Temiz Gri (#F5F5F5) & Etiketler",
      "Gece: Koyu Kömür & Amber Çizgisi",
      "Kaydırılabilir Etiket Rozetleri",
      "Zaman Damgalı Medya Blokları",
    ],
  },
};

const STORAGE_KEY = "veritas_active_canvas_theme_style_v1";

class CanvasThemeControllerManager {
  private activeStyle: CanvasThemeStyle;
  private listeners: Set<(style: CanvasThemeStyle) => void> = new Set();

  constructor() {
    this.activeStyle = this.loadInitialStyle();
  }

  private loadInitialStyle(): CanvasThemeStyle {
    if (typeof window === "undefined") return "fluid_parchment";
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved && saved in CANVAS_THEME_DEFINITIONS) {
        return saved as CanvasThemeStyle;
      }
    } catch (e) {
      console.warn("Failed to load canvas style", e);
    }
    return "fluid_parchment";
  }

  public getStyle(): CanvasThemeStyle {
    return this.activeStyle;
  }

  public getDefinition(style?: CanvasThemeStyle): CanvasThemeDefinition {
    const target = style || this.activeStyle;
    return CANVAS_THEME_DEFINITIONS[target] || CANVAS_THEME_DEFINITIONS.fluid_parchment;
  }

  public setStyle(newStyle: CanvasThemeStyle) {
    if (this.activeStyle === newStyle) return;
    this.activeStyle = newStyle;
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem(STORAGE_KEY, newStyle);
        window.dispatchEvent(
          new CustomEvent("veritas_canvas_style_change", { detail: newStyle })
        );
      } catch (e) {
        console.warn("Failed to save canvas style", e);
      }
    }
    this.listeners.forEach((listener) => {
      try {
        listener(newStyle);
      } catch (err) {
        console.error(err);
      }
    });
  }

  public subscribe(listener: (style: CanvasThemeStyle) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }
}

export const CanvasThemeController = new CanvasThemeControllerManager();
