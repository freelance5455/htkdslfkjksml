import * as XLSX from 'xlsx';
import { MeterRecord } from '../types/meter';

/**
 * Normalizes header string for comparison
 */
function normalizeHeader(h: string): string {
  return h
    .toLowerCase()
    .replace(/[éèêë]/g, 'e')
    .replace(/[àâä]/g, 'a')
    .replace(/[îï]/g, 'i')
    .replace(/[ôö]/g, 'o')
    .replace(/[ùûü]/g, 'u')
    .replace(/[^a-z0-9]/g, '')
    .trim();
}

/**
 * Parses boolean/check values from cell (e.g. '1', 'true', 'oui', 'yes', 'x', 'v')
 */
function isTruthy(val: any): boolean {
  if (val === true || val === 1 || val === '1') return true;
  if (typeof val === 'string') {
    const s = val.trim().toLowerCase();
    return s === '1' || s === 'true' || s === 'oui' || s === 'yes' || s === 'x' || s === 'v' || s === 'نعم';
  }
  return false;
}

/**
 * Parses CSV text (semicolon or comma delimited)
 */
export function parseCSVToMeters(csvText: string): MeterRecord[] {
  const lines = csvText.split(/\r?\n/).filter(line => line.trim().length > 0);
  if (lines.length < 2) return [];

  // Determine delimiter (semicolon or comma or tab)
  const firstLine = lines[0];
  const semicolonCount = (firstLine.match(/;/g) || []).length;
  const commaCount = (firstLine.match(/,/g) || []).length;
  const tabCount = (firstLine.match(/\t/g) || []).length;

  let delimiter = ';';
  if (tabCount > semicolonCount && tabCount > commaCount) {
    delimiter = '\t';
  } else if (commaCount > semicolonCount) {
    delimiter = ',';
  }

  const rawHeaders = splitCSVLine(lines[0], delimiter);
  const headerMap = buildHeaderMap(rawHeaders);

  const results: MeterRecord[] = [];

  for (let i = 1; i < lines.length; i++) {
    const cols = splitCSVLine(lines[i], delimiter);
    // Skip empty lines
    if (cols.length === 0 || cols.every(c => !c.trim())) continue;

    const record = rowToMeterRecord(cols, headerMap, `imp-${Date.now()}-${i}`);
    // Only add if at least one key field exists (gda, ref, ctr, or compt)
    if (record.gda || record.ref || record.compt || record.ctr) {
      results.push(record);
    }
  }

  return results;
}

/**
 * Splits a CSV line taking quotes into account
 */
function splitCSVLine(line: string, delimiter: string): string[] {
  const result: string[] = [];
  let cur = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === delimiter && !inQuotes) {
      result.push(cur.trim());
      cur = '';
    } else {
      cur += char;
    }
  }
  result.push(cur.trim());
  return result;
}

/**
 * Maps column index to property
 */
function buildHeaderMap(headers: string[]): Record<string, number> {
  const map: Record<string, number> = {};

  headers.forEach((h, idx) => {
    const norm = normalizeHeader(h);
    if (!norm) return;

    if (norm.includes('gda') || norm === 'groupe' || norm === 'tournee') map['gda'] = idx;
    else if (norm.includes('ref') || norm.includes('police') || norm.includes('abon')) map['ref'] = idx;
    else if (norm.includes('ctr') || norm.includes('contrat')) map['ctr'] = idx;
    else if (norm === 'index' || norm.includes('ancienindex') || norm.includes('indexprec')) map['index'] = idx;
    else if (norm.includes('compt') || norm.includes('compteur') || norm.includes('serie')) map['compt'] = idx;
    else if (norm.includes('nonsaisie') || norm.includes('nonlu')) map['nonSaisie'] = idx;
    else if (norm === 'saisie' || norm === 'lu') map['saisie'] = idx;
    else if (norm.includes('bloqu') || norm.includes('arrete') || norm.includes('panne')) map['bloque'] = idx;
    else if (norm.includes('nouvindex') || norm.includes('nouvelindex') || norm.includes('newindex')) map['nouvIndex'] = idx;
    else if (norm.includes('hublot') || norm.includes('taps') || norm.includes('vitre')) map['hublotTaps'] = idx;
    else if (norm.includes('absent') || norm.includes('inaccess')) map['clientAbsent'] = idx;
    else if (norm.includes('verif') || norm.includes('doute') || norm.includes('fraude')) map['necessiteVerification'] = idx;
    else if (norm.includes('sansplomb') || norm.includes('plombage') || norm.includes('deplomb')) map['sansPlombage'] = idx;
    else if (norm.includes('fi') || norm.includes('fiche') || norm.includes('numfi')) map['numFI'] = idx;
    else if (norm.includes('observ') || norm.includes('remarque') || norm.includes('note')) map['observation'] = idx;
    else if (norm.includes('lat') || norm.includes('latitude')) map['latitude'] = idx;
    else if (norm.includes('lng') || norm.includes('lon') || norm.includes('longitude')) map['longitude'] = idx;
    else if (norm.includes('adress') || norm.includes('rue') || norm.includes('quartier') || norm.includes('lieu')) map['address'] = idx;
    else if (norm.includes('nom') || norm.includes('client') || norm.includes('abonne')) map['clientName'] = idx;
    else if (norm.includes('tel') || norm.includes('phone')) map['phone'] = idx;
  });

  return map;
}

/**
 * Converts array of column values to a MeterRecord
 */
function rowToMeterRecord(cols: string[], map: Record<string, number>, fallbackId: string): MeterRecord {
  const getCol = (key: string): string => {
    const idx = map[key];
    return idx !== undefined && cols[idx] !== undefined ? cols[idx].trim() : '';
  };

  const getNum = (key: string, defaultVal: number = 0): number => {
    const val = getCol(key);
    if (!val) return defaultVal;
    const clean = val.replace(/[^0-9.-]/g, '');
    const parsed = parseFloat(clean);
    return isNaN(parsed) ? defaultVal : parsed;
  };

  const getNullableNum = (key: string): number | null => {
    const val = getCol(key);
    if (!val) return null;
    const clean = val.replace(/[^0-9.-]/g, '');
    const parsed = parseFloat(clean);
    return isNaN(parsed) ? null : parsed;
  };

  const isSaisie = isTruthy(getCol('saisie'));
  const isNonSaisie = isTruthy(getCol('nonSaisie'));

  return {
    id: fallbackId,
    gda: getCol('gda'),
    ref: getCol('ref'),
    ctr: getCol('ctr'),
    index: getNum('index', 0),
    compt: getCol('compt'),
    saisie: isSaisie || (!isNonSaisie && getNullableNum('nouvIndex') !== null),
    nonSaisie: isNonSaisie || (!isSaisie && getNullableNum('nouvIndex') === null),
    bloque: isTruthy(getCol('bloque')),
    nouvIndex: getNullableNum('nouvIndex'),
    hublotTaps: isTruthy(getCol('hublotTaps')),
    clientAbsent: isTruthy(getCol('clientAbsent')),
    necessiteVerification: isTruthy(getCol('necessiteVerification')),
    sansPlombage: isTruthy(getCol('sansPlombage')),
    numFI: getCol('numFI'),
    observation: getCol('observation'),
    latitude: getNullableNum('latitude'),
    longitude: getNullableNum('longitude'),
    address: getCol('address'),
    clientName: getCol('clientName'),
    phone: getCol('phone'),
    dateReleve: isSaisie ? new Date().toISOString().substring(0, 16).replace('T', ' ') : null
  };
}

/**
 * Parses an Excel file (.xlsx or .xls) from ArrayBuffer
 */
export async function parseExcelToMeters(fileBuffer: ArrayBuffer): Promise<MeterRecord[]> {
  const workbook = XLSX.read(fileBuffer, { type: 'array' });
  if (workbook.SheetNames.length === 0) return [];

  const firstSheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[firstSheetName];
  
  // Convert sheet to array of arrays (strings)
  const rows: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' });
  if (rows.length < 2) return [];

  const rawHeaders = rows[0].map(h => String(h || ''));
  const headerMap = buildHeaderMap(rawHeaders);

  const results: MeterRecord[] = [];

  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (!row || row.every(c => c === '' || c === null || c === undefined)) continue;
    const strCols = row.map(c => String(c !== null && c !== undefined ? c : ''));
    const record = rowToMeterRecord(strCols, headerMap, `imp-xl-${Date.now()}-${i}`);
    if (record.gda || record.ref || record.compt || record.ctr) {
      results.push(record);
    }
  }

  return results;
}

/**
 * Exports MeterRecords to a formatted Excel file (.xlsx)
 */
export function exportMetersToExcel(records: MeterRecord[], filename: string = 'Tournee_Compteurs_Gaz.xlsx'): void {
  const headers = [
    'GDA',
    'REF',
    'CTR',
    'INDEX',
    'COMPT',
    'Non saisie',
    'Saisie',
    'Bloqué',
    'Nouv,Index',
    'Hublot+Taps',
    'Client absent/inaccess',
    'Necessite Verification',
    'Sans plombage',
    'N° FI',
    'Observation',
    'Latitude',
    'Longitude',
    'Adresse / الموقع',
    'Nom Client',
    'Date Relevé'
  ];

  const dataRows = records.map(r => [
    r.gda,
    r.ref,
    r.ctr,
    r.index,
    r.compt,
    r.nonSaisie ? 1 : '',
    r.saisie ? 1 : '',
    r.bloque ? 1 : '',
    r.nouvIndex !== null ? r.nouvIndex : '',
    r.hublotTaps ? 1 : '',
    r.clientAbsent ? 1 : '',
    r.necessiteVerification ? 1 : '',
    r.sansPlombage ? 1 : '',
    r.numFI || '',
    r.observation || '',
    r.latitude || '',
    r.longitude || '',
    r.address || '',
    r.clientName || '',
    r.dateReleve || ''
  ]);

  const wsData = [headers, ...dataRows];
  const worksheet = XLSX.utils.aoa_to_sheet(wsData);

  // Auto column widths
  const colWidths = headers.map((h, i) => {
    let maxLen = h.length;
    dataRows.forEach(row => {
      const valStr = String(row[i] || '');
      if (valStr.length > maxLen) maxLen = valStr.length;
    });
    return { wch: Math.min(Math.max(maxLen + 3, 10), 35) };
  });
  worksheet['!cols'] = colWidths;

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Relevé Compteurs');

  XLSX.writeFile(workbook, filename);
}

/**
 * Exports MeterRecords to CSV (with semicolon delimiter matching the user's template)
 */
export function exportMetersToCSV(records: MeterRecord[], filename: string = 'Tournee_Compteurs_Gaz.csv'): void {
  const headers = [
    'GDA',
    'REF',
    'CTR',
    'INDEX',
    'COMPT,SAISIE',
    'Non saisie',
    'Saisie',
    'Bloqué',
    'Nouv,Index',
    'Hublot+Taps',
    'Client absent/inaccess',
    'Necessite Verification',
    'Sans plombage',
    'N° FI',
    'Observation',
    'Latitude',
    'Longitude',
    'Adresse',
    'Nom Client'
  ];

  const lines = [headers.join(';') + ';'];

  for (const r of records) {
    const row = [
      r.gda,
      r.ref,
      r.ctr,
      r.index,
      r.compt,
      r.nonSaisie ? '1' : '',
      r.saisie ? '1' : '',
      r.bloque ? '1' : '',
      r.nouvIndex !== null ? r.nouvIndex : '',
      r.hublotTaps ? '1' : '',
      r.clientAbsent ? '1' : '',
      r.necessiteVerification ? '1' : '',
      r.sansPlombage ? '1' : '',
      r.numFI || '',
      (r.observation || '').replace(/;/g, ' '),
      r.latitude ?? '',
      r.longitude ?? '',
      (r.address || '').replace(/;/g, ' '),
      (r.clientName || '').replace(/;/g, ' ')
    ];
    lines.push(row.join(';') + ';');
  }

  // BOM for UTF-8 in Excel
  const blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
