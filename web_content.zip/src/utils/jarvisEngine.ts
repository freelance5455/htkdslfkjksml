import {
  CalendarEvent,
  Reminder,
  Contact,
  AndroidApp,
  DeviceSettings,
  JarvisAction,
  JarvisResponse,
} from '../types/jarvis';

/**
 * Standard seed contacts
 */
export const DEFAULT_CONTACTS: Contact[] = [
  { id: 'c1', name: 'Pepper Potts', phone: '+1-310-555-0101', role: 'Stark CEO', favorite: true },
  { id: 'c2', name: 'Happy Hogan', phone: '+1-310-555-0142', role: 'Head of Security', favorite: true },
  { id: 'c3', name: 'Colonel Rhodes', phone: '+1-202-555-0189', role: 'War Machine', favorite: true },
  { id: 'c4', name: 'Peter Parker', phone: '+1-718-555-0177', role: 'Stark Intern', favorite: false },
  { id: 'c5', name: 'Bruce Banner', phone: '+1-212-555-0133', role: 'Gamma Lab Director', favorite: false },
  { id: 'c6', name: 'Emergency 911', phone: '911', role: 'Emergency Dispatch', favorite: false },
];

/**
 * Android apps with deep-link URI schemes and web fallbacks
 */
export const DEFAULT_APPS: AndroidApp[] = [
  { id: 'whatsapp', name: 'WhatsApp', category: 'Comms', intentUrl: 'whatsapp://send', webFallback: 'https://web.whatsapp.com', iconName: 'MessageCircle', color: '#25D366' },
  { id: 'phone', name: 'Phone', category: 'Comms', intentUrl: 'tel:', webFallback: 'tel:', iconName: 'Phone', color: '#10B981' },
  { id: 'messages', name: 'Messages (SMS)', category: 'Comms', intentUrl: 'sms:', webFallback: 'sms:', iconName: 'MessageSquare', color: '#3B82F6' },
  { id: 'youtube', name: 'YouTube', category: 'Media', intentUrl: 'vnd.youtube://', webFallback: 'https://m.youtube.com', iconName: 'Youtube', color: '#EF4444' },
  { id: 'spotify', name: 'Spotify', category: 'Media', intentUrl: 'spotify://', webFallback: 'https://open.spotify.com', iconName: 'Music', color: '#1DB954' },
  { id: 'maps', name: 'Google Maps', category: 'Google', intentUrl: 'geo:0,0?q=', webFallback: 'https://maps.google.com', iconName: 'MapPin', color: '#EA4335' },
  { id: 'chrome', name: 'Chrome', category: 'Tools', intentUrl: 'googlechrome://', webFallback: 'https://www.google.com', iconName: 'Globe', color: '#4285F4' },
  { id: 'camera', name: 'Camera', category: 'Tools', intentUrl: 'camera:', webFallback: '#camera', iconName: 'Camera', color: '#8B5CF6' },
  { id: 'gmail', name: 'Gmail', category: 'Google', intentUrl: 'googlegmail://', webFallback: 'https://mail.google.com', iconName: 'Mail', color: '#D93025' },
  { id: 'telegram', name: 'Telegram', category: 'Comms', intentUrl: 'tg://resolve', webFallback: 'https://web.telegram.org', iconName: 'Send', color: '#0088CC' },
  { id: 'settings', name: 'Android Settings', category: 'Tools', intentUrl: 'intent:#Intent;action=android.settings.SETTINGS;end', webFallback: '#settings', iconName: 'Settings', color: '#64748B' },
  { id: 'clock', name: 'Clock & Alarms', category: 'Tools', intentUrl: 'intent:#Intent;action=android.intent.action.SHOW_ALARMS;end', webFallback: '#alarms', iconName: 'Clock', color: '#F59E0B' },
];

/**
 * Generate initial events and reminders for a realistic user experience
 */
export function getInitialEvents(baseDate: Date = new Date()): CalendarEvent[] {
  const d = new Date(baseDate);
  const pad = (n: number) => String(n).padStart(2, '0');
  const dateStr = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

  return [
    {
      id: 'evt-1',
      title: 'Stark Industries Board Review',
      startTime: `${dateStr}T10:00:00`,
      endTime: `${dateStr}T11:30:00`,
      location: 'Tower Penthouse Conference Room',
      category: 'work',
      priority: 'high',
      notified: false,
    },
    {
      id: 'evt-2',
      title: 'Clean Energy Arc Grid Inspection',
      startTime: `${dateStr}T14:00:00`,
      endTime: `${dateStr}T15:00:00`,
      location: 'Sector 4 Sub-level',
      category: 'ops',
      priority: 'normal',
      notified: false,
    },
    {
      id: 'evt-3',
      title: 'Dinner with Pepper Potts',
      startTime: `${dateStr}T19:30:00`,
      endTime: `${dateStr}T21:00:00`,
      location: 'Le Bernardin',
      category: 'personal',
      priority: 'high',
      notified: false,
    },
  ];
}

export function getInitialReminders(baseDate: Date = new Date()): Reminder[] {
  const d = new Date(baseDate);
  const pad = (n: number) => String(n).padStart(2, '0');
  const dateStr = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

  return [
    {
      id: 'rem-1',
      title: 'Review flight telemetry for Mark LXXXV armor',
      dueTime: `${dateStr}T11:45:00`,
      completed: false,
      priority: 'urgent',
      category: 'Engineering',
      notified: false,
    },
    {
      id: 'rem-2',
      title: 'Authorize procurement order for vibranium alloy batch',
      dueTime: `${dateStr}T16:00:00`,
      completed: false,
      priority: 'normal',
      category: 'Finance',
      notified: false,
    },
    {
      id: 'rem-3',
      title: 'Take daily nutrient & cardiovascular supplement',
      dueTime: `${dateStr}T20:00:00`,
      completed: true,
      priority: 'normal',
      category: 'Health',
      notified: false,
    },
  ];
}

/**
 * Natural Language Time Parser
 */
export function parseNaturalTime(text: string, base: Date = new Date()): Date {
  const target = new Date(base.getTime());
  const lower = text.toLowerCase();

  // Pattern: "in X minutes" / "in X mins" / "in an hour"
  const inMinMatch = lower.match(/in\s+(\d+)\s*(?:minutes?|mins?)/);
  if (inMinMatch) {
    target.setMinutes(target.getMinutes() + parseInt(inMinMatch[1], 10));
    return target;
  }
  if (lower.includes('in an hour') || lower.includes('in 1 hour')) {
    target.setHours(target.getHours() + 1);
    return target;
  }
  const inHoursMatch = lower.match(/in\s+(\d+)\s*(?:hours?|hrs?)/);
  if (inHoursMatch) {
    target.setHours(target.getHours() + parseInt(inHoursMatch[1], 10));
    return target;
  }

  // Check for "tomorrow"
  if (lower.includes('tomorrow')) {
    target.setDate(target.getDate() + 1);
  }

  // Pattern: "at X(:YY)? (am|pm)?"
  const timeMatch = lower.match(/(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/);
  if (timeMatch && timeMatch[1]) {
    let hours = parseInt(timeMatch[1], 10);
    const minutes = timeMatch[2] ? parseInt(timeMatch[2], 10) : 0;
    const meridiem = timeMatch[3];

    if (meridiem === 'pm' && hours < 12) hours += 12;
    if (meridiem === 'am' && hours === 12) hours = 0;

    // If no meridiem specified and hour is less than current hour today, assume PM or next occurrence
    if (!meridiem && hours < 8 && !lower.includes('tomorrow')) {
      hours += 12; // e.g. "at 4" usually means 4 PM
    }

    target.setHours(hours, minutes, 0, 0);
  } else {
    // Default to +1 hour from now
    target.setHours(target.getHours() + 1, 0, 0, 0);
  }

  return target;
}

/**
 * Add calendar event
 */
export function addCalendarEvent(
  events: CalendarEvent[],
  data: Partial<CalendarEvent> & { title: string; startTime: string }
): { updatedEvents: CalendarEvent[]; newEvent: CalendarEvent } {
  const startTime = new Date(data.startTime);
  const endTime = data.endTime
    ? new Date(data.endTime)
    : new Date(startTime.getTime() + 60 * 60 * 1000); // 1 hour default

  const newEvent: CalendarEvent = {
    id: data.id || `evt-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    title: data.title.trim(),
    startTime: startTime.toISOString().slice(0, 19),
    endTime: endTime.toISOString().slice(0, 19),
    location: data.location || 'Stark HQ',
    category: data.category || 'work',
    priority: data.priority || 'normal',
    notified: false,
  };

  // Keep events sorted by start time
  const updatedEvents = [...events, newEvent].sort((a, b) =>
    a.startTime.localeCompare(b.startTime)
  );

  return { updatedEvents, newEvent };
}

/**
 * Modify existing calendar event
 */
export function modifyCalendarEvent(
  events: CalendarEvent[],
  targetQuery: string,
  updates: Partial<CalendarEvent>
): { updatedEvents: CalendarEvent[]; modifiedEvent: CalendarEvent | null } {
  const query = targetQuery.toLowerCase();
  let found: CalendarEvent | null = null;

  const updatedEvents = events.map((event) => {
    if (
      event.id === targetQuery ||
      event.title.toLowerCase().includes(query) ||
      query.includes(event.title.toLowerCase())
    ) {
      found = { ...event, ...updates, id: event.id };
      return found;
    }
    return event;
  });

  return { updatedEvents, modifiedEvent: found };
}

/**
 * Delete calendar event
 */
export function deleteCalendarEvent(
  events: CalendarEvent[],
  targetQuery: string
): { updatedEvents: CalendarEvent[]; deletedEvent: CalendarEvent | null } {
  const query = targetQuery.toLowerCase();
  const deletedEvent =
    events.find(
      (e) =>
        e.id === targetQuery ||
        e.title.toLowerCase().includes(query) ||
        query.includes(e.title.toLowerCase())
    ) || null;

  const updatedEvents = events.filter((e) => e !== deletedEvent);
  return { updatedEvents, deletedEvent };
}

/**
 * Add reminder
 */
export function addReminderItem(
  reminders: Reminder[],
  data: Partial<Reminder> & { title: string }
): { updatedReminders: Reminder[]; newReminder: Reminder } {
  const newReminder: Reminder = {
    id: data.id || `rem-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    title: data.title.trim(),
    dueTime: data.dueTime ? data.dueTime.slice(0, 19) : null,
    completed: false,
    priority: data.priority || 'normal',
    category: data.category || 'General',
    notified: false,
  };

  return {
    updatedReminders: [newReminder, ...reminders],
    newReminder,
  };
}

/**
 * Toggle or modify reminder
 */
export function modifyReminderItem(
  reminders: Reminder[],
  targetQuery: string,
  updates: Partial<Reminder>
): { updatedReminders: Reminder[]; modifiedReminder: Reminder | null } {
  const query = targetQuery.toLowerCase();
  let found: Reminder | null = null;

  const updatedReminders = reminders.map((rem) => {
    if (
      rem.id === targetQuery ||
      rem.title.toLowerCase().includes(query) ||
      query.includes(rem.title.toLowerCase())
    ) {
      found = { ...rem, ...updates, id: rem.id };
      return found;
    }
    return rem;
  });

  return { updatedReminders, modifiedReminder: found };
}

/**
 * Delete reminder
 */
export function deleteReminderItem(
  reminders: Reminder[],
  targetQuery: string
): { updatedReminders: Reminder[]; deletedReminder: Reminder | null } {
  const query = targetQuery.toLowerCase();
  const deletedReminder =
    reminders.find(
      (r) =>
        r.id === targetQuery ||
        r.title.toLowerCase().includes(query) ||
        query.includes(r.title.toLowerCase())
    ) || null;

  const updatedReminders = reminders.filter((r) => r !== deletedReminder);
  return { updatedReminders, deletedReminder };
}

/**
 * Notification check: returns items that are due within the notice window
 */
export function checkUpcomingNotifications(
  events: CalendarEvent[],
  reminders: Reminder[],
  now: Date = new Date(),
  windowMinutes: number = 15
): { dueEvents: CalendarEvent[]; dueReminders: Reminder[] } {
  const nowMs = now.getTime();
  const windowMs = windowMinutes * 60 * 1000;

  const dueEvents = events.filter((evt) => {
    if (evt.notified) return false;
    const evtTime = new Date(evt.startTime).getTime();
    const diff = evtTime - nowMs;
    // Notify if starting within windowMinutes or already started within the last 5 minutes
    return diff <= windowMs && diff >= -5 * 60 * 1000;
  });

  const dueReminders = reminders.filter((rem) => {
    if (rem.completed || rem.notified || !rem.dueTime) return false;
    const remTime = new Date(rem.dueTime).getTime();
    const diff = remTime - nowMs;
    return diff <= windowMs && diff >= -5 * 60 * 1000;
  });

  return { dueEvents, dueReminders };
}

/**
 * Format timestamp nicely
 */
export function formatTimeDisplay(isoString: string): string {
  try {
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } catch {
    return isoString;
  }
}

export function formatDateDisplay(isoString: string): string {
  try {
    const d = new Date(isoString);
    return d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
  } catch {
    return isoString;
  }
}

/**
 * Fast deterministic intent extractor for Jarvis
 * Works offline, in tests, and as an immediate fallback or parallel validator.
 */
export function parseLocalJarvisCommand(
  rawInput: string,
  context: {
    now?: Date;
    events: CalendarEvent[];
    reminders: Reminder[];
    contacts: Contact[];
    apps: AndroidApp[];
    settings?: Partial<DeviceSettings>;
  }
): JarvisResponse {
  const now = context.now || new Date();
  const text = rawInput.trim();
  const lower = text.toLowerCase();

  // 1. ADD CALENDAR EVENT
  if (
    lower.startsWith('schedule') ||
    lower.startsWith('add event') ||
    lower.startsWith('book') ||
    lower.includes('schedule a meeting') ||
    lower.includes('add a meeting') ||
    lower.includes('calendar event')
  ) {
    let title = text
      .replace(/^(?:jarvis\s+)?(?:please\s+)?(?:schedule|add event|book|add a meeting|schedule a meeting|create event)\s+/i, '')
      .trim();

    // Extract time hints
    const parsedDate = parseNaturalTime(title, now);
    // Strip time words from title
    const cleanTitle = title
      .replace(/(?:for|at|on|tomorrow|in \d+ (?:mins|minutes|hours)).*$/i, '')
      .replace(/^(?:a\s+|an\s+)/i, '')
      .trim() || 'New Meeting';

    return {
      speechText: `Right away, Sir. I have scheduled "${cleanTitle}" for ${formatDateDisplay(parsedDate.toISOString())} at ${formatTimeDisplay(parsedDate.toISOString())}.`,
      action: {
        type: 'ADD_EVENT',
        payload: {
          title: cleanTitle,
          startTime: parsedDate.toISOString(),
          endTime: new Date(parsedDate.getTime() + 60 * 60 * 1000).toISOString(),
          priority: lower.includes('urgent') || lower.includes('high priority') ? 'high' : 'normal',
          category: lower.includes('health') || lower.includes('doctor') ? 'health' : 'work',
        },
      },
    };
  }

  // 2. MODIFY / RESCHEDULE EVENT
  if (
    lower.includes('reschedule') ||
    lower.includes('move meeting') ||
    lower.includes('change meeting') ||
    lower.includes('modify event')
  ) {
    const targetMatch = text.match(/(?:reschedule|move|change|modify)\s+(?:the\s+)?(.+?)(?:\s+to|\s+at|$)/i);
    const targetQuery = targetMatch ? targetMatch[1].trim() : 'meeting';
    const newTime = parseNaturalTime(text, now);

    return {
      speechText: `Adjusting your schedule, Sir. Updated "${targetQuery}" to ${formatTimeDisplay(newTime.toISOString())}.`,
      action: {
        type: 'MODIFY_EVENT',
        payload: {
          targetQuery,
          updatedFields: {
            startTime: newTime.toISOString(),
            endTime: new Date(newTime.getTime() + 60 * 60 * 1000).toISOString(),
          },
        },
      },
    };
  }

  // 3. DELETE / CANCEL EVENT
  if (
    lower.includes('cancel meeting') ||
    lower.includes('delete event') ||
    lower.includes('remove event') ||
    lower.includes('delete meeting')
  ) {
    const target = text
      .replace(/^(?:jarvis\s+)?(?:please\s+)?(?:cancel meeting|delete event|remove event|delete meeting|cancel the)\s+/i, '')
      .trim();

    return {
      speechText: `Understood, Sir. I have removed the event "${target}" from your calendar.`,
      action: {
        type: 'DELETE_EVENT',
        payload: { targetQuery: target },
      },
    };
  }

  // 4. ADD REMINDER
  if (
    lower.startsWith('remind me') ||
    lower.includes('set a reminder') ||
    lower.includes('add a reminder') ||
    lower.startsWith('reminder to')
  ) {
    const title = text
      .replace(/^(?:jarvis\s+)?(?:please\s+)?(?:remind me to|remind me|set a reminder for|set a reminder to|add a reminder to|reminder to)\s+/i, '')
      .trim();

    const parsedDue = parseNaturalTime(title, now);
    const cleanTitle = title
      .replace(/(?:in \d+ (?:mins|minutes|hours)|at \d+.*|tomorrow.*)$/i, '')
      .trim() || 'General reminder';

    return {
      speechText: `Reminder logged, Sir. I will remind you to ${cleanTitle} at ${formatTimeDisplay(parsedDue.toISOString())}.`,
      action: {
        type: 'ADD_REMINDER',
        payload: {
          title: cleanTitle,
          dueTime: parsedDue.toISOString(),
          priority: lower.includes('urgent') || lower.includes('critical') ? 'urgent' : 'normal',
          category: 'Voice Command',
        },
      },
    };
  }

  // 5. COMPLETE / MODIFY REMINDER
  if (
    lower.includes('complete reminder') ||
    lower.includes('mark reminder') ||
    lower.includes('check off') ||
    lower.includes('finish reminder')
  ) {
    const target = text
      .replace(/^(?:jarvis\s+)?(?:please\s+)?(?:complete reminder|mark reminder|check off|finish reminder|mark)\s+/i, '')
      .replace(/\s+(?:done|completed|as done)$/i, '')
      .trim();

    return {
      speechText: `Task completed, Sir. Marked "${target}" as resolved.`,
      action: {
        type: 'MODIFY_REMINDER',
        payload: { targetQuery: target, completed: true },
      },
    };
  }

  // 6. DELETE REMINDER
  if (
    lower.includes('delete reminder') ||
    lower.includes('remove reminder') ||
    lower.includes('clear reminder')
  ) {
    const target = text
      .replace(/^(?:jarvis\s+)?(?:please\s+)?(?:delete reminder|remove reminder|clear reminder)\s+/i, '')
      .trim();

    return {
      speechText: `Reminder "${target}" has been expunged from the docket.`,
      action: {
        type: 'DELETE_REMINDER',
        payload: { targetQuery: target },
      },
    };
  }

  // 7. PHONE CALL
  if (lower.startsWith('call ') || lower.startsWith('dial ') || lower.includes('place a call to')) {
    const targetName = text
      .replace(/^(?:jarvis\s+)?(?:please\s+)?(?:call|dial|place a call to)\s+/i, '')
      .replace(/^(?:my\s+)/i, '')
      .trim();

    // Check contact match
    const matchedContact = context.contacts.find(
      (c) => c.name.toLowerCase().includes(targetName.toLowerCase()) || targetName.toLowerCase().includes(c.name.toLowerCase())
    );

    const phoneNumber = matchedContact ? matchedContact.phone : targetName.replace(/[^\d+]/g, '') || '+1-310-555-0100';
    const displayName = matchedContact ? matchedContact.name : targetName;

    return {
      speechText: `Connecting you to ${displayName} now, Sir. Engaging comms array.`,
      action: {
        type: 'MAKE_CALL',
        payload: {
          contactName: displayName,
          phoneNumber,
        },
      },
    };
  }

  // 8. SEND MESSAGE (SMS / WhatsApp)
  if (
    lower.startsWith('send message') ||
    lower.startsWith('text ') ||
    lower.startsWith('whatsapp ') ||
    lower.includes('send a message to')
  ) {
    const isWhatsApp = lower.includes('whatsapp');
    let content = text
      .replace(/^(?:jarvis\s+)?(?:please\s+)?(?:send message to|send a message to|text|whatsapp)\s+/i, '')
      .trim();

    // Match "Pepper saying I will be there soon"
    let recipient = 'Pepper Potts';
    let messageBody = content;

    const sayingMatch = content.match(/^(.+?)\s+(?:saying|that|with)\s+(.+)$/i);
    if (sayingMatch) {
      recipient = sayingMatch[1].trim();
      messageBody = sayingMatch[2].trim();
    } else {
      const parts = content.split(':');
      if (parts.length > 1) {
        recipient = parts[0].trim();
        messageBody = parts.slice(1).join(':').trim();
      }
    }

    const matchedContact = context.contacts.find(
      (c) => c.name.toLowerCase().includes(recipient.toLowerCase()) || recipient.toLowerCase().includes(c.name.toLowerCase())
    );

    const phoneNumber = matchedContact ? matchedContact.phone : '+1-310-555-0101';
    const finalName = matchedContact ? matchedContact.name : recipient;

    return {
      speechText: `Drafted message to ${finalName}: "${messageBody}". Dispatching over mobile protocol.`,
      action: {
        type: 'SEND_MESSAGE',
        payload: {
          contactName: finalName,
          phoneNumber,
          message: messageBody,
          app: isWhatsApp ? 'whatsapp' : 'sms',
        },
      },
    };
  }

  // 9. OPEN APP
  if (lower.startsWith('open ') || lower.startsWith('launch ') || lower.includes('start app')) {
    const targetAppName = text
      .replace(/^(?:jarvis\s+)?(?:please\s+)?(?:open|launch|start app|start)\s+/i, '')
      .trim();

    const matchedApp = context.apps.find(
      (a) =>
        a.name.toLowerCase().includes(targetAppName.toLowerCase()) ||
        targetAppName.toLowerCase().includes(a.name.toLowerCase()) ||
        a.id.toLowerCase() === targetAppName.toLowerCase()
    );

    if (matchedApp) {
      return {
        speechText: `Opening ${matchedApp.name} immediately, Sir.`,
        action: {
          type: 'OPEN_APP',
          payload: { app: matchedApp },
        },
      };
    }

    return {
      speechText: `Attempting to launch ${targetAppName} on your Android device.`,
      action: {
        type: 'OPEN_APP',
        payload: {
          app: {
            id: 'custom',
            name: targetAppName,
            category: 'Tools',
            intentUrl: `intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;end`,
            webFallback: `https://www.google.com/search?q=${encodeURIComponent(targetAppName)}`,
            iconName: 'ExternalLink',
            color: '#06b6d4',
          },
        },
      },
    };
  }

  // 10. TOGGLE SETTING (Flashlight, Vibrate, Night Mode, Battery Saver)
  if (lower.includes('flashlight') || lower.includes('torch')) {
    const enable = !lower.includes('off') && !lower.includes('disable');
    return {
      speechText: enable ? 'Illuminating flashlight torch, Sir.' : 'Flashlight deactivated, Sir.',
      action: {
        type: 'TOGGLE_SETTING',
        payload: { setting: 'flashlight', value: enable },
      },
    };
  }

  if (lower.includes('silent') || lower.includes('mute') || lower.includes('sound mode')) {
    const isSilent = !lower.includes('unmute') && !lower.includes('normal');
    return {
      speechText: isSilent ? 'Audio systems muted. Switching to silent profile.' : 'Sound profile restored to standard.',
      action: {
        type: 'TOGGLE_SETTING',
        payload: { setting: 'soundMode', value: isSilent ? 'silent' : 'normal' },
      },
    };
  }

  if (lower.includes('battery saver') || lower.includes('power save')) {
    const enable = !lower.includes('off') && !lower.includes('disable');
    return {
      speechText: enable ? 'Power preservation protocol engaged. Battery saver active.' : 'Full power routing restored.',
      action: {
        type: 'TOGGLE_SETTING',
        payload: { setting: 'batterySaver', value: enable },
      },
    };
  }

  if (lower.includes('vibration') || lower.includes('haptic')) {
    const enable = !lower.includes('off') && !lower.includes('disable');
    return {
      speechText: enable ? 'Haptic feedback array enabled.' : 'Haptics disabled.',
      action: {
        type: 'TOGGLE_SETTING',
        payload: { setting: 'vibrate', value: enable },
      },
    };
  }

  // 11. SCHEDULE QUERY & BRIEFING
  if (
    lower.includes('schedule') ||
    lower.includes('briefing') ||
    lower.includes('what do i have') ||
    lower.includes('what is on my calendar') ||
    lower.includes('agenda')
  ) {
    const count = context.events.length;
    const remCount = context.reminders.filter((r) => !r.completed).length;
    const firstEvt = context.events[0];

    const nextStr = firstEvt
      ? `Your next engagement is "${firstEvt.title}" at ${formatTimeDisplay(firstEvt.startTime)}.`
      : 'You have no immediate appointments.';

    return {
      speechText: `Good day, Sir. You have ${count} events on the docket today and ${remCount} pending reminders. ${nextStr}`,
      action: {
        type: 'BRIEFING',
        payload: { eventsCount: count, remindersCount: remCount },
      },
    };
  }

  // 12. GENERAL INTELLIGENCE RESPONSE
  return {
    speechText: `At your service, Sir. All Android telemetry and system subroutines are operating at 100% capacity.`,
    action: {
      type: 'GENERAL_RESPONSE',
      payload: { query: text },
    },
  };
}
