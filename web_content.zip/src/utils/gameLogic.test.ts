import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getRequiredExp,
  addExperience,
  calculateAnimalHarvest,
  calculateAquaticHarvest,
  getTimeOfDayFromHour,
  getBeeGachaRate,
  getBatchCraftWaitTime,
  getAnimalSellPrice,
  getButlerPerks,
} from './gameLogic.ts';

test('getRequiredExp calculates early and advanced levels', () => {
  assert.equal(getRequiredExp(1), 100);
  assert.equal(getRequiredExp(2), 220);
  assert.equal(getRequiredExp(3), 400);
  assert.equal(getRequiredExp(4), 650);
  assert.equal(getRequiredExp(6), Math.floor(100 * Math.pow(6, 1.65)));
});

test('addExperience: respects single harvest 25% cap at level 5+', () => {
  const reqL5 = getRequiredExp(5);
  // Trying to add 500 exp from a single harvest when max 25% is floor(reqL5 * 0.25)
  const cap = Math.floor(reqL5 * 0.25);
  const result = addExperience(5, 0, 500, true);
  assert.equal(result.actualGainedExp, cap);
  assert.equal(result.newExp, cap);
  assert.equal(result.leveledUp, false);
});

test('addExperience: levels up exactly 1 level at a time and caps excess at 25% of new level', () => {
  // Level 1: 0/100 EXP. Add 250 EXP.
  // Level should become 2, excess is 150, but next level req is 220, so max allowed excess is 220 * 0.25 = 55.
  const result = addExperience(1, 0, 250, false);
  assert.equal(result.newLevel, 2);
  assert.equal(result.leveledUp, true);
  assert.equal(result.newExp, 55); // capped at 25% of level 2 (220 * 0.25 = 55)
});

test('calculateAnimalHarvest: applies satisfaction multipliers and scales with animal count', () => {
  // Count 10, satisfaction 100% -> 1.35x yield and +10% exp
  const harvest100 = calculateAnimalHarvest(10, 100, 2, 10);
  assert.equal(harvest100.totalYield, Math.round(2 * 10 * 1.35)); // 27
  assert.equal(harvest100.totalExp, Math.round(10 * 10 * 1.1)); // 110
  assert.equal(harvest100.isGoldenStar, true);

  // Satisfaction < 50%
  const harvest0 = calculateAnimalHarvest(2, 20, 3, 5);
  assert.equal(harvest0.totalYield, 6);
  assert.equal(harvest0.totalExp, 10);
  assert.equal(harvest0.isGoldenStar, false);
});

test('calculateAquaticHarvest: applies favorite food milestones', () => {
  // 10 fish at 100% favorite food -> +20% bonus
  const h100 = calculateAquaticHarvest(10, 100, 1, 10);
  assert.equal(h100.totalYield, Math.round(1 * 10 * 1.2)); // 12

  // 5 fish at 50% favorite food -> +10% bonus
  const h50 = calculateAquaticHarvest(5, 50, 2, 10);
  assert.equal(h50.totalYield, Math.round(2 * 5 * 1.1)); // 11
});

test('getTimeOfDayFromHour returns correct 6 time slices', () => {
  assert.equal(getTimeOfDayFromHour(6), 'dawn');
  assert.equal(getTimeOfDayFromHour(12), 'day');
  assert.equal(getTimeOfDayFromHour(17), 'golden');
  assert.equal(getTimeOfDayFromHour(19), 'dusk');
  assert.equal(getTimeOfDayFromHour(21), 'night');
  assert.equal(getTimeOfDayFromHour(1), 'midnight');
});

test('getBeeGachaRate implements 6-roll pity protection', () => {
  assert.equal(getBeeGachaRate(0), 0.15);
  assert.equal(getBeeGachaRate(1), 0.3);
  assert.equal(getBeeGachaRate(2), 0.5);
  assert.equal(getBeeGachaRate(3), 0.7);
  assert.equal(getBeeGachaRate(4), 0.85);
  assert.equal(getBeeGachaRate(5), 1.0); // Guaranteed on 6th roll!
});

test('getBatchCraftWaitTime applies -10% discount for batches >= 10', () => {
  assert.equal(getBatchCraftWaitTime(10, 5), 50);
  assert.equal(getBatchCraftWaitTime(10, 10), 90); // 100 - 10% = 90
});

test('getAnimalSellPrice scales properly for store vs bred tiers', () => {
  // Store animal (T1-3): 75% of buy price
  assert.equal(getAnimalSellPrice(1, 200, 200), 150);
  // Bred Tier 4: 1.5x baseValuation
  assert.equal(getAnimalSellPrice(4, 0, 1000), 1500);
  // Bred Tier 5: 2.0x baseValuation
  assert.equal(getAnimalSellPrice(5, 0, 3000), 6000);
});

test('getButlerPerks returns accurate speed and bonuses per tier', () => {
  const p1 = getButlerPerks(1);
  assert.equal(p1.intervalSeconds, 60);
  assert.equal(p1.missChance, 0.35);

  const p5 = getButlerPerks(5);
  assert.equal(p5.intervalSeconds, 3);
  assert.equal(p5.missChance, 0);
  assert.equal(p5.yieldBonus, 0.3);
});
