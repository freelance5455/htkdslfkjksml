import { Alarm } from '../types/alarm';

// Calculates the exact next Date timestamp when an alarm should fire
export function getNextAlarmDate(alarm: Alarm, fromDate: Date = new Date()): Date {
  const target = new Date(fromDate);
  target.setHours(alarm.hour, alarm.minute, 0, 0);

  // If one-time alarm (repeatDays empty)
  if (!alarm.repeatDays || alarm.repeatDays.length === 0) {
    if (target.getTime() <= fromDate.getTime()) {
      // Scheduled for tomorrow
      target.setDate(target.getDate() + 1);
    }
    return target;
  }

  // Repeating alarm
  const currentDay = fromDate.getDay(); // 0 = Sun, 1 = Mon, ..., 6 = Sat
  let daysUntilNext = 7;

  // Find the smallest positive difference
  for (const day of alarm.repeatDays) {
    let diff = day - currentDay;
    if (diff < 0) {
      diff += 7;
    } else if (diff === 0) {
      // Same day of week: check if time has already passed today
      if (target.getTime() <= fromDate.getTime()) {
        diff = 7;
      }
    }
    if (diff < daysUntilNext) {
      daysUntilNext = diff;
    }
  }

  target.setDate(fromDate.getDate() + daysUntilNext);
  return target;
}

// Returns the single next upcoming active alarm among all enabled alarms
export function getNextUpcomingAlarm(alarms: Alarm[]): { alarm: Alarm; nextDate: Date } | null {
  const enabledAlarms = alarms.filter((a) => a.isEnabled);
  if (enabledAlarms.length === 0) return null;

  const now = new Date();
  let earliest: { alarm: Alarm; nextDate: Date } | null = null;

  for (const alarm of enabledAlarms) {
    const nextDate = getNextAlarmDate(alarm, now);
    if (!earliest || nextDate.getTime() < earliest.nextDate.getTime()) {
      earliest = { alarm, nextDate };
    }
  }

  return earliest;
}

// Formats millisecond countdown into human readable text (e.g., "7 hours 24 mins")
export function formatCountdown(targetDate: Date, now: Date = new Date()): string {
  const diffMs = targetDate.getTime() - now.getTime();
  if (diffMs <= 0) return 'Ringing now...';

  const totalSeconds = Math.floor(diffMs / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours > 24) {
    const days = Math.floor(hours / 24);
    const remHours = hours % 24;
    return `in ${days}d ${remHours}h ${minutes}m`;
  }

  if (hours > 0) {
    return `in ${hours}h ${minutes}m ${seconds}s`;
  }
  if (minutes > 0) {
    return `in ${minutes}m ${seconds}s`;
  }
  return `in ${seconds}s`;
}

// Formats time display according to 12h or 24h format
export function formatAlarmTime(hour: number, minute: number, is24h: boolean = false): { timeStr: string; period: string } {
  const formattedMin = minute < 10 ? `0${minute}` : `${minute}`;

  if (is24h) {
    const formattedHour = hour < 10 ? `0${hour}` : `${hour}`;
    return { timeStr: `${formattedHour}:${formattedMin}`, period: '' };
  }

  const period = hour >= 12 ? 'PM' : 'AM';
  let hour12 = hour % 12;
  if (hour12 === 0) hour12 = 12;

  return { timeStr: `${hour12}:${formattedMin}`, period };
}

// Weekday helper labels
export const WEEKDAY_LABELS = [
  { short: 'S', full: 'Sun', value: 0 },
  { short: 'M', full: 'Mon', value: 1 },
  { short: 'T', full: 'Tue', value: 2 },
  { short: 'W', full: 'Wed', value: 3 },
  { short: 'T', full: 'Thu', value: 4 },
  { short: 'F', full: 'Fri', value: 5 },
  { short: 'S', full: 'Sat', value: 6 },
];

export function formatRepeatDays(repeatDays: number[]): string {
  if (!repeatDays || repeatDays.length === 0) return 'One-time alarm';
  if (repeatDays.length === 7) return 'Every day';
  if (repeatDays.length === 5 && repeatDays.every((d) => d >= 1 && d <= 5)) return 'Weekdays (Mon-Fri)';
  if (repeatDays.length === 2 && repeatDays.includes(0) && repeatDays.includes(6)) return 'Weekends (Sat-Sun)';

  return repeatDays
    .map((d) => WEEKDAY_LABELS.find((w) => w.value === d)?.full)
    .filter(Boolean)
    .join(', ');
}

// Wake Lock Helper
let wakeLockSentinel: WakeLockSentinel | null = null;

export async function requestWakeLock(): Promise<boolean> {
  if ('wakeLock' in navigator) {
    try {
      wakeLockSentinel = await navigator.wakeLock.request('screen');
      return true;
    } catch (err) {
      console.warn('Wake Lock request failed:', err);
    }
  }
  return false;
}

export function releaseWakeLock(): void {
  if (wakeLockSentinel) {
    wakeLockSentinel.release().catch(() => {});
    wakeLockSentinel = null;
  }
}

// Notification Helper
export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (!('Notification' in window)) {
    return 'denied';
  }
  if (Notification.permission === 'granted') {
    return 'granted';
  }
  return await Notification.requestPermission();
}

export function sendAlarmNotification(title: string, body: string, icon?: string): void {
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: icon || '/favicon.ico',
        requireInteraction: true,
        tag: 'wakeup-alarm-notification',
      });
    } catch (err) {
      console.warn('Failed to dispatch notification:', err);
    }
  }
}

// Vibration Helper - Disabled per user request (no vibration on alarm)
export function triggerAlarmVibration(): void {
  // Vibration disabled for alarm playback
}

export function stopAlarmVibration(): void {
  if ('vibrate' in navigator) {
    try {
      navigator.vibrate(0);
    } catch (err) {}
  }
}
