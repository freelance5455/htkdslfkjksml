import { ProfileInterfaceConfig, ToolSortMode } from "../types";

export interface InterfaceToolItem {
  id: string;
  title: string;
  categoryGroup: "notes" | "media" | "pkm" | "system";
  groupLabel: string;
  description: string;
  badgeText?: string;
  badgeColor?: string;
  thumbnailUrl?: string; // Pre-generated mini thumbnail
}

export const APP_INTERFACE_TOOLS: InterfaceToolItem[] = [
  {
    id: "home",
    title: "Tüm Notlar & Liste",
    categoryGroup: "notes",
    groupLabel: "Not & İçerik Yönetimi",
    description: "Zengin metinli notlar, etiketler, arama ve filtreler",
    badgeText: "Ana Modül",
    badgeColor: "bg-teal-500",
    thumbnailUrl: "https://images.unsplash.com/photo-1517842645767-c639042777db?w=120&auto=format&fit=crop&q=80",
  },
  {
    id: "docs",
    title: "Belge İnceleyici Hub",
    categoryGroup: "notes",
    groupLabel: "Not & İçerik Yönetimi",
    description: "PDF, Word, Excel, PowerPoint ve Markdown aktarımları",
    badgeText: "15+ Format",
    badgeColor: "bg-blue-500",
    thumbnailUrl: "https://images.unsplash.com/photo-1568667256549-094345857637?w=120&auto=format&fit=crop&q=80",
  },
  {
    id: "mindmap",
    title: "Zihin Haritası & Tuval",
    categoryGroup: "pkm",
    groupLabel: "PKM & Bilgi Ağı",
    description: "İki yönlü bağlantılı PKM düğüm haritası ve serbest çizim",
    badgeText: "Görsel Düğüm",
    badgeColor: "bg-purple-500",
    thumbnailUrl: "https://images.unsplash.com/photo-1558655146-d09347e92766?w=120&auto=format&fit=crop&q=80",
  },
  {
    id: "study",
    title: "Öğrenme & Hafıza Kartları",
    categoryGroup: "pkm",
    groupLabel: "PKM & Bilgi Ağı",
    description: "Aralıklı tekrar (Spaced Repetition) ve test modülleri",
    badgeText: "Flashcard",
    badgeColor: "bg-amber-500",
    thumbnailUrl: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=120&auto=format&fit=crop&q=80",
  },
  {
    id: "voice_memo",
    title: "Sesli Not & Transkripsiyon",
    categoryGroup: "media",
    groupLabel: "Medya & Çizim",
    description: "Tek tıkla yüksek kalitede ses kaydı ve metne dökme",
    badgeText: "Ses Kaydı",
    badgeColor: "bg-rose-500",
    thumbnailUrl: "https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=120&auto=format&fit=crop&q=80",
  },
  {
    id: "vault",
    title: "Şifreli Kasa (Vault)",
    categoryGroup: "system",
    groupLabel: "Sistem & Güvenlik",
    description: "AES-256-GCM ile korunan askeri düzeyde gizli depo",
    badgeText: "AES-256",
    badgeColor: "bg-emerald-500",
    thumbnailUrl: "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=120&auto=format&fit=crop&q=80",
  },
  {
    id: "ai_chat",
    title: "AI Asistan & Sohbet",
    categoryGroup: "notes",
    groupLabel: "Not & İçerik Yönetimi",
    description: "Yapay zeka ile belge analizi ve soru-cevap asistanı",
    badgeText: "AI Studio",
    badgeColor: "bg-indigo-500",
    thumbnailUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80",
  },
  {
    id: "settings",
    title: "Sistem Ayarları & Depolama",
    categoryGroup: "system",
    groupLabel: "Sistem & Güvenlik",
    description: "Yedek alma, çöp kutusu, sıfırlama ve tema tercihleri",
    badgeText: "Yedek/Sıfırla",
    badgeColor: "bg-slate-500",
    thumbnailUrl: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=120&auto=format&fit=crop&q=80",
  },
];

export const DEFAULT_PROFILE_INTERFACE_CONFIG: ProfileInterfaceConfig = {
  navigationConcept: "classic",
  showThumbnails: true,
  showInlineControls: true,
  toolSortMode: "smart_relational",
  customToolOrder: APP_INTERFACE_TOOLS.map((t) => t.id),
  inlineUiScale: 1.0,
  inlineFontSize: 16,
};

const STORAGE_KEY = "noteflow_profile_interface_config_v2";

export function getStoredProfileInterfaceConfig(): ProfileInterfaceConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PROFILE_INTERFACE_CONFIG;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_PROFILE_INTERFACE_CONFIG,
      ...parsed,
    };
  } catch (e) {
    console.warn("Failed to load stored interface config:", e);
    return DEFAULT_PROFILE_INTERFACE_CONFIG;
  }
}

export function saveStoredProfileInterfaceConfig(config: ProfileInterfaceConfig): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch (e) {
    console.warn("Failed to save interface config:", e);
  }
}

/**
 * Sort tools according to selected mode:
 * - 'alphabetical': Turkish locale A-Z sort by title
 * - 'smart_relational': Grouped by categoryGroup in logical order
 * - 'drag_drop': Custom order from customToolOrder IDs
 */
export function sortInterfaceTools(
  tools: InterfaceToolItem[],
  mode: ToolSortMode,
  customOrder: string[] = []
): InterfaceToolItem[] {
  const toolsCopy = [...tools];

  if (mode === "alphabetical") {
    return toolsCopy.sort((a, b) => a.title.localeCompare(b.title, "tr", { sensitivity: "base" }));
  }

  if (mode === "drag_drop" && customOrder && customOrder.length > 0) {
    const orderMap = new Map<string, number>(customOrder.map((id, index) => [id, index]));
    return toolsCopy.sort((a, b) => {
      const idxA = orderMap.has(a.id) ? orderMap.get(a.id)! : 999;
      const idxB = orderMap.has(b.id) ? orderMap.get(b.id)! : 999;
      return idxA - idxB;
    });
  }

  // Default: 'smart_relational'
  const groupPriority: Record<string, number> = {
    notes: 1,
    pkm: 2,
    media: 3,
    system: 4,
  };

  return toolsCopy.sort((a, b) => {
    const prioA = groupPriority[a.categoryGroup] || 99;
    const prioB = groupPriority[b.categoryGroup] || 99;
    if (prioA !== prioB) return prioA - prioB;
    return a.title.localeCompare(b.title, "tr");
  });
}
