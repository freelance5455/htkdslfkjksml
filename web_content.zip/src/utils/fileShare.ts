/**
 * Utility per la condivisione nativa di file (PDF, Excel, CSV) su smartphone
 * (ottimizzato per Google Pixel 9 / Android con Web Share API, WhatsApp e altre app).
 */

export interface ShareOptions {
  title: string;
  text?: string;
  filename: string;
  blob: Blob;
  mimeType: string;
}

/**
 * Condivide un file tramite la Web Share API nativa di Android / Google Pixel,
 * aprendo direttamente il menu di sistema (WhatsApp, Gmail, Drive, Telegram, ecc.).
 * Se il browser non supporta la condivisione diretta di file, effettua il download
 * automatico e apre WhatsApp con il testo di riepilogo.
 */
export async function shareFileNative({
  title,
  text,
  filename,
  blob,
  mimeType
}: ShareOptions): Promise<{ success: boolean; method: 'native_share' | 'whatsapp_link' | 'download_fallback'; message: string }> {
  const safeFilename = filename.endsWith(mimeType.includes('pdf') ? '.pdf' : '.xls')
    ? filename
    : `${filename}${mimeType.includes('pdf') ? '.pdf' : '.xls'}`;

  // Crea un oggetto File compatibile con navigator.share
  const file = new File([blob], safeFilename, { type: mimeType });

  // 1. Prova Web Share API con allegato file (supportato su Pixel 9 / Chrome Android)
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try {
      await navigator.share({
        title,
        text: text || `${title} - Documento generato con Sfiller Sabbiatura & Verniciatura`,
        files: [file]
      });
      return {
        success: true,
        method: 'native_share',
        message: 'File inviato al menu di condivisione nativo (WhatsApp, Mail, Drive).'
      };
    } catch (err: any) {
      // Se l'utente ha annullato la condivisione, non trattarlo come errore grave
      if (err.name === 'AbortError') {
        return {
          success: false,
          method: 'native_share',
          message: 'Condivisione annullata dall\'utente.'
        };
      }
      console.warn('Errore in navigator.share, procedo con fallback:', err);
    }
  }

  // 2. Se navigator.share fallisce o non supporta i file, scarica il file e offri apertura WhatsApp
  try {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = safeFilename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    // Crea link per aprire WhatsApp con messaggio pronto
    const waText = encodeURIComponent(
      `*${title}*\n${text || 'In allegato il documento aziendale Sfiller.'}\n(Il file ${safeFilename} è stato scaricato sul tuo dispositivo ed è pronto da allegare alla chat)`
    );
    const waUrl = `https://api.whatsapp.com/send?text=${waText}`;

    // Chiedi all'utente se vuole aprire WhatsApp
    return {
      success: true,
      method: 'whatsapp_link',
      message: `File scaricato sul Pixel 9. Puoi aprire WhatsApp e allegare "${safeFilename}".`
    };
  } catch (err) {
    console.error('Fallback fallito:', err);
    return {
      success: false,
      method: 'download_fallback',
      message: 'Impossibile completare la condivisione automatica del file.'
    };
  }
}

/**
 * Apre direttamente WhatsApp con messaggio precompilato
 */
export function openWhatsAppWithMessage(message: string, phoneNumber?: string): void {
  const cleanPhone = phoneNumber ? phoneNumber.replace(/[^0-9+]/g, '') : '';
  const encodedText = encodeURIComponent(message);
  const url = cleanPhone
    ? `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedText}`
    : `https://api.whatsapp.com/send?text=${encodedText}`;
  window.open(url, '_blank');
}
