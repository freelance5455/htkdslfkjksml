/**
 * Pure calculation utilities for Sales & Logistics Mobile App
 */

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  qty: number;
  itemDiscount?: number;
}

export interface InvoiceCalculations {
  lines: Array<CartItem & { lineTotal: number; itemDiscount: number }>;
  subtotal: number;
  monthlyDiscountRate: number;
  monthlyDiscountValue: number;
  grandTotal: number;
}

/**
 * Calculates subtotal, item discounts, monthly discount, and grand total
 */
export function calcInvoice(cart: CartItem[], monthlyDiscountRate: number = 0): InvoiceCalculations {
  const safeRate = Math.min(100, Math.max(0, Number(monthlyDiscountRate) || 0));
  
  const lines = cart.map((item) => {
    const price = Math.max(0, Number(item.price) || 0);
    const qty = Math.max(0, Number(item.qty) || 0);
    const gross = price * qty;
    const itemDiscount = Math.min(gross, Math.max(0, Number(item.itemDiscount) || 0));
    const lineTotal = Math.max(0, gross - itemDiscount);
    return {
      ...item,
      price,
      qty,
      itemDiscount,
      lineTotal,
    };
  });

  const subtotal = lines.reduce((acc, line) => acc + line.lineTotal, 0);
  const monthlyDiscountValue = Math.round((subtotal * safeRate / 100) * 100) / 100;
  const grandTotal = Math.max(0, Math.round((subtotal - monthlyDiscountValue) * 100) / 100);

  return {
    lines,
    subtotal,
    monthlyDiscountRate: safeRate,
    monthlyDiscountValue,
    grandTotal,
  };
}

/**
 * Calculates Haversine distance between two coordinates in meters
 */
export function calculateDistanceMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000; // Earth radius in meters
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

/**
 * FIFO debt payment allocation across unpaid invoices
 */
export interface UnpaidInvoice {
  id: string;
  remainingAmount: number;
  paidAmount: number;
}

export function allocatePaymentToInvoices(
  invoices: UnpaidInvoice[],
  paymentAmount: number
): { updatedInvoices: UnpaidInvoice[]; unallocatedAmount: number } {
  let remainingPayment = Math.max(0, paymentAmount);
  const updatedInvoices = invoices.map((inv) => ({ ...inv }));

  for (const inv of updatedInvoices) {
    if (remainingPayment <= 0) break;
    const debt = Math.max(0, inv.remainingAmount);
    if (debt > 0) {
      const pay = Math.min(debt, remainingPayment);
      inv.remainingAmount -= pay;
      inv.paidAmount += pay;
      remainingPayment -= pay;
    }
  }

  return {
    updatedInvoices,
    unallocatedAmount: Math.round(remainingPayment * 100) / 100,
  };
}

/**
 * Format currency with 2 decimals in Arabic / English locale
 */
export function formatMoney(amount: number): string {
  const n = Number(amount) || 0;
  return n.toLocaleString('ar-EG', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

/**
 * Get YYYY-MM-DD for today in local timezone
 */
export function getTodayDateString(): string {
  const d = new Date();
  const offset = d.getTimezoneOffset();
  return new Date(d.getTime() - offset * 60000).toISOString().slice(0, 10);
}

export const ARABIC_DAYS = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'] as const;
export const ROUTE_DAYS = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'] as const;

export function getArabicDayName(dateString?: string): string {
  const d = dateString ? new Date(dateString + 'T12:00:00') : new Date();
  return ARABIC_DAYS[d.getDay()] || 'السبت';
}

/**
 * Resolves effective safety threshold:
 * Prefers globalThreshold if configured > 0, otherwise falls back to product-specific minQty.
 */
export function getEffectiveThreshold(productMinQty: number, globalThreshold?: number): number {
  const g = Math.max(0, Number(globalThreshold) || 0);
  const p = Math.max(0, Number(productMinQty) || 0);
  return g > 0 ? g : p;
}

/**
 * Checks if van inventory is below or equal to safety threshold
 */
export function isStockBelowSafetyThreshold(
  stockQty: number,
  productMinQty: number,
  globalThreshold?: number
): boolean {
  const current = Number(stockQty) || 0;
  const threshold = getEffectiveThreshold(productMinQty, globalThreshold);
  return threshold > 0 && current <= threshold;
}

/**
 * Calculates stock safety percentage relative to safety threshold (0 - 100%)
 */
export function getStockSafetyPercentage(
  stockQty: number,
  productMinQty: number,
  globalThreshold?: number
): number {
  const current = Math.max(0, Number(stockQty) || 0);
  const threshold = getEffectiveThreshold(productMinQty, globalThreshold);
  if (threshold <= 0) return 100;
  return Math.min(100, Math.round((current / (threshold * 2)) * 100));
}

/**
 * Calculates how many items are missing to reach the safety stock threshold
 */
export function getSafetyStockDeficit(
  stockQty: number,
  productMinQty: number,
  globalThreshold?: number
): number {
  const current = Math.max(0, Number(stockQty) || 0);
  const threshold = getEffectiveThreshold(productMinQty, globalThreshold);
  return Math.max(0, threshold - current);
}

export interface VisitStatusCounts {
  completed: number;
  cancelled: number;
  postponed: number;
  total: number;
}

/**
 * Calculates visit status distribution: completed (تمت), cancelled (ملغاة), and postponed (مؤجلة)
 */
export function calcVisitStatusDistribution(
  visits: Array<{ status: string }>
): VisitStatusCounts {
  let completed = 0;
  let cancelled = 0;
  let postponed = 0;

  for (const v of visits) {
    const s = (v.status || '').trim();
    if (s.includes('تمت') || s === 'تمت الزيارة') {
      completed++;
    } else if (
      s.includes('ملغاة') ||
      s.includes('مغلق') ||
      s.includes('لم تتم') ||
      s.includes('إلغاء')
    ) {
      cancelled++;
    } else if (s.includes('مؤجل') || s.includes('تأجيل')) {
      postponed++;
    }
  }

  return {
    completed,
    cancelled,
    postponed,
    total: completed + cancelled + postponed,
  };
}

/**
 * Calculates total stock quantity and valuation (at cost and sale prices)
 */
export function calcInventoryTotals(
  products: Array<{ id: string; price: number; cost: number }>,
  stockMap: Map<string, number>
): { totalQty: number; totalCostValue: number; totalSaleValue: number } {
  let totalQty = 0;
  let totalCostValue = 0;
  let totalSaleValue = 0;

  for (const p of products) {
    const q = Math.max(0, stockMap.get(p.id) || 0);
    totalQty += q;
    totalCostValue += q * (Number(p.cost) || 0);
    totalSaleValue += q * (Number(p.price) || 0);
  }

  return {
    totalQty,
    totalCostValue: Math.round(totalCostValue * 100) / 100,
    totalSaleValue: Math.round(totalSaleValue * 100) / 100,
  };
}



