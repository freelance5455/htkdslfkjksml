// موتور محاسبات امن (بدون eval) با پارسر بازگشتی

type Tok =
  | { t: "num"; v: number }
  | { t: "const"; v: number }
  | { t: "fn"; v: string }
  | { t: "op"; v: string };

const FN_RE = /^(sin|cos|tan|ln|log)/;

function tokenize(src: string): Tok[] {
  const out: Tok[] = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === " ") {
      i++;
      continue;
    }
    if (/[0-9.]/.test(c)) {
      const m = src.slice(i).match(/^(\d+\.?\d*|\.\d+)(E[+\-−]?\d+)?/);
      if (!m) throw new Error("num");
      out.push({ t: "num", v: parseFloat(m[0].replace("−", "-")) });
      i += m[0].length;
      continue;
    }
    const fm = src.slice(i).match(FN_RE);
    if (fm) {
      out.push({ t: "fn", v: fm[1] });
      i += fm[1].length;
      continue;
    }
    if (c === "√") {
      out.push({ t: "fn", v: "sqrt" });
      i++;
      continue;
    }
    if (c === "π") {
      out.push({ t: "const", v: Math.PI });
      i++;
      continue;
    }
    if (c === "e") {
      out.push({ t: "const", v: Math.E });
      i++;
      continue;
    }
    if ("+−-×÷*/^()!%".includes(c)) {
      const map: Record<string, string> = { "-": "−", "*": "×", "/": "÷" };
      out.push({ t: "op", v: map[c] ?? c });
      i++;
      continue;
    }
    throw new Error("char");
  }
  return out;
}

function clean(v: number): number {
  return Math.abs(v) < 1e-12 ? 0 : v;
}

function factorial(n: number): number {
  if (!Number.isInteger(n) || n < 0 || n > 170) throw new Error("fact");
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}

type R = { v: number; pct: boolean };

class Parser {
  pos = 0;
  constructor(
    private toks: Tok[],
    private deg: boolean,
  ) {}

  private peek() {
    return this.toks[this.pos];
  }
  private isOp(v: string) {
    const t = this.peek();
    return !!t && t.t === "op" && t.v === v;
  }

  parse(): number {
    const v = this.expr();
    if (this.pos < this.toks.length) throw new Error("syntax");
    return v;
  }

  private expr(): number {
    let v = this.term().v;
    // eslint-disable-next-line no-constant-condition
    while (true) {
      if (this.isOp("+")) {
        this.pos++;
        const r = this.term();
        v = v + (r.pct ? v * r.v : r.v);
      } else if (this.isOp("−")) {
        this.pos++;
        const r = this.term();
        v = v - (r.pct ? v * r.v : r.v);
      } else break;
    }
    return v;
  }

  private startsPrimary(): boolean {
    const t = this.peek();
    if (!t) return false;
    return t.t === "num" || t.t === "const" || t.t === "fn" || (t.t === "op" && t.v === "(");
  }

  private term(): R {
    let r = this.unary();
    let multiplied = false;
    // eslint-disable-next-line no-constant-condition
    while (true) {
      if (this.isOp("×")) {
        this.pos++;
        r = { v: r.v * this.unary().v, pct: false };
        multiplied = true;
      } else if (this.isOp("÷")) {
        this.pos++;
        const d = this.unary().v;
        if (d === 0) throw new Error("div0");
        r = { v: r.v / d, pct: false };
        multiplied = true;
      } else if (this.startsPrimary()) {
        r = { v: r.v * this.unary().v, pct: false };
        multiplied = true;
      } else break;
    }
    return multiplied ? { v: r.v, pct: false } : r;
  }

  private unary(): R {
    if (this.isOp("−")) {
      this.pos++;
      return { v: -this.unary().v, pct: false };
    }
    if (this.isOp("+")) {
      this.pos++;
      return this.unary();
    }
    return this.power();
  }

  private power(): R {
    const base = this.postfix();
    if (this.isOp("^")) {
      this.pos++;
      const e = this.unary();
      return { v: Math.pow(base.v, e.v), pct: false };
    }
    return base;
  }

  private postfix(): R {
    let { v } = this.primary();
    let pct = false;
    // eslint-disable-next-line no-constant-condition
    while (true) {
      if (this.isOp("!")) {
        this.pos++;
        v = factorial(v);
        pct = false;
      } else if (this.isOp("%")) {
        this.pos++;
        v = v / 100;
        pct = true;
      } else break;
    }
    return { v, pct };
  }

  private paren(): number {
    this.pos++; // (
    const v = this.expr();
    if (this.isOp(")")) this.pos++; // بستن خودکار پرانتز
    return v;
  }

  private primary(): R {
    const t = this.peek();
    if (!t) throw new Error("eof");
    if (t.t === "num" || t.t === "const") {
      this.pos++;
      return { v: t.v, pct: false };
    }
    if (t.t === "fn") {
      this.pos++;
      const arg = this.isOp("(") ? this.paren() : this.unary().v;
      return { v: this.applyFn(t.v, arg), pct: false };
    }
    if (t.t === "op" && t.v === "(") {
      return { v: this.paren(), pct: false };
    }
    throw new Error("syntax");
  }

  private applyFn(name: string, x: number): number {
    const k = this.deg ? Math.PI / 180 : 1;
    switch (name) {
      case "sin":
        return clean(Math.sin(x * k));
      case "cos":
        return clean(Math.cos(x * k));
      case "tan":
        if (this.deg && Math.abs(x % 180) === 90) throw new Error("tan");
        return Math.tan(x * k);
      case "ln":
        if (x <= 0) throw new Error("ln");
        return Math.log(x);
      case "log":
        if (x <= 0) throw new Error("log");
        return Math.log10(x);
      case "sqrt":
        if (x < 0) throw new Error("sqrt");
        return Math.sqrt(x);
    }
    throw new Error("fn");
  }
}

export function evaluate(expr: string, deg: boolean): number {
  const toks = tokenize(expr);
  if (!toks.length) throw new Error("empty");
  const v = new Parser(toks, deg).parse();
  if (!Number.isFinite(v)) throw new Error("inf");
  return Number(v.toPrecision(12));
}

/** تبدیل عدد به رشته‌ای که دوباره قابل پارس باشد */
export function toPlain(n: number): string {
  return n.toString().replace("e", "E").replace(/-/g, "−");
}

const FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";

export function toFaDigits(s: string): string {
  return s.replace(/\d/g, (d) => FA_DIGITS[Number(d)]);
}

export function fromFaDigits(s: string): string {
  return s.replace(/[۰-۹]/g, (d) => String(FA_DIGITS.indexOf(d)));
}

function group(intPart: string): string {
  return intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/** قالب‌بندی عبارت برای نمایش (جداکننده هزارگان + ارقام فارسی) */
export function fmtExpr(expr: string, fa: boolean): string {
  const out = expr.replace(/(\d*)(\.\d*)?(E[+\-−]?\d+)?/g, (m, i: string, f: string | undefined, e: string | undefined) => {
    if (!m) return m;
    let s = group(i || "");
    if (f) s += fa ? "٫" + f.slice(1) : f;
    if (e) s += e.replace("E", "e").replace("-", "−");
    return fa ? toFaDigits(s) : s;
  });
  return out;
}

/** قالب‌بندی نتیجه نهایی */
export function fmtResult(n: number, fa: boolean): string {
  const abs = Math.abs(n);
  let s: string;
  if (abs !== 0 && (abs >= 1e15 || abs < 1e-9)) {
    s = n.toExponential(8).replace(/\.?0+e/, "e").replace("-", "−");
    s = s.replace("e+", "e");
    return fa ? toFaDigits(s) : s;
  }
  s = n.toLocaleString("en-US", { maximumFractionDigits: 10 }).replace("-", "−");
  if (fa) s = toFaDigits(s).replace(/\./g, "٫");
  return s;
}
