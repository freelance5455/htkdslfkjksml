export interface ScriptSegment {
  start: number;
  end: number;
  name: 'hook' | 'demo' | 'cta';
}

export function getActiveSegment(time: number): 'hook' | 'demo' | 'cta' {
  if (time < 3.0) return 'hook';
  if (time < 12.0) return 'demo';
  return 'cta';
}

export function validate16sPacing(captions: Array<{ start: number; end: number; text: string }>): boolean {
  if (!captions || captions.length === 0) return false;
  const last = captions[captions.length - 1];
  return last.end <= 16.5 && captions[0].start >= 0;
}

export function formatTimeClock(seconds: number): string {
  const clamped = Math.max(0, Math.min(16, seconds));
  const s = clamped.toFixed(1);
  return `${s.padStart(4, '0')}s / 16.0s`;
}
