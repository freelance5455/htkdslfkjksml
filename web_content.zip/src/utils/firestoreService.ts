import {
  db,
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy
} from './firebase';
import { Store, Product, Order, Customer, MerchantUser, SubscriptionPayment, PaymentGatewayConfig, DraftOrder, AbandonedCheckout, ReturnRefundRecord, ShippingSettings, Collection } from '../types';
import { 
  initialStores, 
  initialProducts, 
  initialOrders, 
  initialCustomers, 
  initialMerchantUsers, 
  initialPaymentGateways, 
  initialSubscriptionPayments 
} from '../data/initialData';

// Firestore collection names matching architecture guidelines
const STORES_COL = 'stores';
const PRODUCTS_COL = 'products';
const ORDERS_COL = 'orders';
const CUSTOMERS_COL = 'customers';
const USERS_COL = 'merchant_users';
const GATEWAYS_COL = 'payment_gateways';
const PAYMENTS_COL = 'subscription_payments';
const DRAFT_ORDERS_COL = 'draft_orders';
const ABANDONED_CHECKOUTS_COL = 'abandoned_checkouts';
const RETURNS_REFUNDS_COL = 'returns_refunds';
const SHIPPING_SETTINGS_COL = 'shipping_settings';
const COLLECTIONS_COL = 'collections';

// Helpers to sanitize undefined values before writing to Firestore
function sanitizeForFirestore<T extends Record<string, any>>(obj: T): T {
  const result: any = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) {
      if (value && typeof value === 'object' && !Array.isArray(value)) {
        result[key] = sanitizeForFirestore(value);
      } else {
        result[key] = value;
      }
    }
  }
  return result;
}

// ---------------- STORES ----------------
export async function fetchStoresFromDB(): Promise<Store[]> {
  try {
    const snap = await getDocs(collection(db, STORES_COL));
    if (!snap.empty) {
      return snap.docs.map((d) => d.data() as Store);
    }
    // Seed initial stores if empty
    for (const store of initialStores) {
      await setDoc(doc(db, STORES_COL, store.id), sanitizeForFirestore(store));
    }
    return initialStores;
  } catch (err) {
    console.warn('Firestore fetchStores failed, returning cached/initial:', err);
    return initialStores;
  }
}

export async function saveStoreToDB(store: Store): Promise<void> {
  try {
    await setDoc(doc(db, STORES_COL, store.id), sanitizeForFirestore(store));
  } catch (err) {
    console.warn('Firestore saveStore error:', err);
  }
}

// ---------------- PRODUCTS ----------------
export async function fetchProductsFromDB(storeId?: string): Promise<Product[]> {
  try {
    const colRef = collection(db, PRODUCTS_COL);
    const q = storeId ? query(colRef, where('storeId', '==', storeId)) : colRef;
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map((d) => d.data() as Product);
    }
    // Seed initial products if collection empty
    for (const prod of initialProducts) {
      await setDoc(doc(db, PRODUCTS_COL, prod.id), sanitizeForFirestore(prod));
    }
    return storeId ? initialProducts.filter((p) => p.storeId === storeId) : initialProducts;
  } catch (err) {
    console.warn('Firestore fetchProducts failed, returning initial:', err);
    return storeId ? initialProducts.filter((p) => p.storeId === storeId) : initialProducts;
  }
}

export async function saveProductToDB(product: Product): Promise<void> {
  try {
    await setDoc(doc(db, PRODUCTS_COL, product.id), sanitizeForFirestore(product));
  } catch (err) {
    console.warn('Firestore saveProduct error:', err);
  }
}

export async function deleteProductFromDB(productId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, PRODUCTS_COL, productId));
  } catch (err) {
    console.warn('Firestore deleteProduct error:', err);
  }
}

// ---------------- ORDERS ----------------
export async function fetchOrdersFromDB(storeId?: string): Promise<Order[]> {
  try {
    const colRef = collection(db, ORDERS_COL);
    const q = storeId ? query(colRef, where('storeId', '==', storeId)) : colRef;
    const snap = await getDocs(q);
    if (!snap.empty) {
      const list = snap.docs.map((d) => d.data() as Order);
      return list.filter((o) => o && typeof o === 'object' && typeof o.id === 'string');
    }
    // Only seed demo data if fetching without storeId or for initial demo store-1
    if (!storeId || storeId === 'store-1') {
      for (const ord of initialOrders) {
        await setDoc(doc(db, ORDERS_COL, ord.id), sanitizeForFirestore(ord));
      }
      return storeId ? initialOrders.filter((o) => o.storeId === storeId) : initialOrders;
    }
    return [];
  } catch (err) {
    console.warn('Firestore fetchOrders failed:', err);
    return [];
  }
}

export async function saveOrderToDB(order: Order): Promise<void> {
  try {
    await setDoc(doc(db, ORDERS_COL, order.id), sanitizeForFirestore(order));
  } catch (err) {
    console.warn('Firestore saveOrder error:', err);
  }
}

export async function updateOrderStatusInDB(orderId: string, status: Order['orderStatus']): Promise<void> {
  try {
    await updateDoc(doc(db, ORDERS_COL, orderId), { 
      orderStatus: status,
      updatedAt: new Date().toISOString()
    });
  } catch (err) {
    console.warn('Firestore updateOrderStatus error:', err);
  }
}

// ---------------- CUSTOMERS ----------------
export async function fetchCustomersFromDB(storeId?: string): Promise<Customer[]> {
  try {
    const colRef = collection(db, CUSTOMERS_COL);
    const q = storeId ? query(colRef, where('storeId', '==', storeId)) : colRef;
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map((d) => d.data() as Customer);
    }
    for (const cust of initialCustomers) {
      await setDoc(doc(db, CUSTOMERS_COL, cust.id), sanitizeForFirestore(cust));
    }
    return storeId ? initialCustomers.filter((c) => c.storeId === storeId) : initialCustomers;
  } catch (err) {
    console.warn('Firestore fetchCustomers error:', err);
    return storeId ? initialCustomers.filter((c) => c.storeId === storeId) : initialCustomers;
  }
}

export async function saveCustomerToDB(customer: Customer): Promise<void> {
  try {
    await setDoc(doc(db, CUSTOMERS_COL, customer.id), sanitizeForFirestore(customer));
  } catch (err) {
    console.warn('Firestore saveCustomer error:', err);
  }
}

// ---------------- MERCHANT USERS (Admin) ----------------
export async function fetchMerchantUsersFromDB(): Promise<MerchantUser[]> {
  try {
    const snap = await getDocs(collection(db, USERS_COL));
    if (!snap.empty) {
      return snap.docs.map((d) => d.data() as MerchantUser);
    }
    for (const u of initialMerchantUsers) {
      await setDoc(doc(db, USERS_COL, u.id), sanitizeForFirestore(u));
    }
    return initialMerchantUsers;
  } catch (err) {
    console.warn('Firestore fetchMerchantUsers error:', err);
    return initialMerchantUsers;
  }
}

export async function saveMerchantUserToDB(user: MerchantUser): Promise<void> {
  try {
    await setDoc(doc(db, USERS_COL, user.id), sanitizeForFirestore(user));
  } catch (err) {
    console.warn('Firestore saveMerchantUser error:', err);
  }
}

export async function deleteMerchantUserFromDB(userId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, USERS_COL, userId));
  } catch (err) {
    console.warn('Firestore deleteMerchantUser error:', err);
  }
}

// ---------------- GATEWAYS & SUBSCRIPTIONS ----------------
export async function fetchGatewaysFromDB(): Promise<PaymentGatewayConfig[]> {
  try {
    const snap = await getDocs(collection(db, GATEWAYS_COL));
    if (!snap.empty) {
      return snap.docs.map((d) => d.data() as PaymentGatewayConfig);
    }
    for (const g of initialPaymentGateways) {
      await setDoc(doc(db, GATEWAYS_COL, g.id), sanitizeForFirestore(g));
    }
    return initialPaymentGateways;
  } catch (err) {
    console.warn('Firestore fetchGateways error:', err);
    return initialPaymentGateways;
  }
}

export async function saveGatewayToDB(gateway: PaymentGatewayConfig): Promise<void> {
  try {
    await setDoc(doc(db, GATEWAYS_COL, gateway.id), sanitizeForFirestore(gateway));
  } catch (err) {
    console.warn('Firestore saveGateway error:', err);
  }
}

export async function fetchSubscriptionPaymentsFromDB(): Promise<SubscriptionPayment[]> {
  try {
    const snap = await getDocs(collection(db, PAYMENTS_COL));
    if (!snap.empty) {
      return snap.docs.map((d) => d.data() as SubscriptionPayment);
    }
    for (const p of initialSubscriptionPayments) {
      await setDoc(doc(db, PAYMENTS_COL, p.id), sanitizeForFirestore(p));
    }
    return initialSubscriptionPayments;
  } catch (err) {
    console.warn('Firestore fetchSubscriptionPayments error:', err);
    return initialSubscriptionPayments;
  }
}

export async function saveSubscriptionPaymentToDB(payment: SubscriptionPayment): Promise<void> {
  try {
    await setDoc(doc(db, PAYMENTS_COL, payment.id), sanitizeForFirestore(payment));
  } catch (err) {
    console.warn('Firestore saveSubscriptionPayment error:', err);
  }
}

// ==================== DRAFT ORDERS ====================
export async function fetchDraftOrdersFromDB(storeId?: string): Promise<DraftOrder[]> {
  try {
    const q = storeId 
      ? query(collection(db, DRAFT_ORDERS_COL), where('storeId', '==', storeId))
      : collection(db, DRAFT_ORDERS_COL);
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map((d) => d.data() as DraftOrder);
    }
    return [];
  } catch (err) {
    console.warn('Firestore fetchDraftOrders error:', err);
    return [];
  }
}

export async function saveDraftOrderToDB(draft: DraftOrder): Promise<void> {
  try {
    await setDoc(doc(db, DRAFT_ORDERS_COL, draft.id), sanitizeForFirestore(draft));
  } catch (err) {
    console.warn('Firestore saveDraftOrder error:', err);
  }
}

export async function deleteDraftOrderFromDB(draftId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, DRAFT_ORDERS_COL, draftId));
  } catch (err) {
    console.warn('Firestore deleteDraftOrder error:', err);
  }
}

// ==================== ABANDONED CHECKOUTS ====================
export async function fetchAbandonedCheckoutsFromDB(storeId?: string): Promise<AbandonedCheckout[]> {
  try {
    const q = storeId 
      ? query(collection(db, ABANDONED_CHECKOUTS_COL), where('storeId', '==', storeId))
      : collection(db, ABANDONED_CHECKOUTS_COL);
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map((d) => d.data() as AbandonedCheckout);
    }
    return [];
  } catch (err) {
    console.warn('Firestore fetchAbandonedCheckouts error:', err);
    return [];
  }
}

export async function saveAbandonedCheckoutToDB(session: AbandonedCheckout): Promise<void> {
  try {
    await setDoc(doc(db, ABANDONED_CHECKOUTS_COL, session.id), sanitizeForFirestore(session));
  } catch (err) {
    console.warn('Firestore saveAbandonedCheckout error:', err);
  }
}

export async function updateAbandonedCheckoutStatusInDB(checkoutId: string, status: 'incomplete' | 'recovered' | 'blocked'): Promise<void> {
  try {
    await updateDoc(doc(db, ABANDONED_CHECKOUTS_COL, checkoutId), { recoveryStatus: status, updatedAt: new Date().toISOString() });
  } catch (err) {
    console.warn('Firestore updateAbandonedCheckoutStatus error:', err);
  }
}

// ==================== RETURNS & REFUNDS ====================
export async function fetchReturnsRefundsFromDB(storeId?: string): Promise<ReturnRefundRecord[]> {
  try {
    const q = storeId 
      ? query(collection(db, RETURNS_REFUNDS_COL), where('storeId', '==', storeId))
      : collection(db, RETURNS_REFUNDS_COL);
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map((d) => d.data() as ReturnRefundRecord);
    }
    return [];
  } catch (err) {
    console.warn('Firestore fetchReturnsRefunds error:', err);
    return [];
  }
}

export async function saveReturnRefundToDB(record: ReturnRefundRecord): Promise<void> {
  try {
    await setDoc(doc(db, RETURNS_REFUNDS_COL, record.id), sanitizeForFirestore(record));
  } catch (err) {
    console.warn('Firestore saveReturnRefund error:', err);
  }
}

export async function updateReturnRefundStatusInDB(recordId: string, status: 'pending' | 'approved' | 'processed' | 'rejected'): Promise<void> {
  try {
    await updateDoc(doc(db, RETURNS_REFUNDS_COL, recordId), { status, updatedAt: new Date().toISOString() });
  } catch (err) {
    console.warn('Firestore updateReturnRefundStatus error:', err);
  }
}

// ==================== SHIPPING SETTINGS ====================
export async function fetchShippingSettingsFromDB(storeId: string): Promise<ShippingSettings | null> {
  try {
    const docRef = doc(db, SHIPPING_SETTINGS_COL, storeId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as ShippingSettings;
    }
    return null;
  } catch (err) {
    console.warn('Firestore fetchShippingSettings error:', err);
    return null;
  }
}

export async function saveShippingSettingsToDB(settings: ShippingSettings): Promise<void> {
  try {
    await setDoc(doc(db, SHIPPING_SETTINGS_COL, settings.storeId), sanitizeForFirestore(settings));
  } catch (err) {
    console.warn('Firestore saveShippingSettings error:', err);
  }
}

// ==================== COLLECTIONS ====================
export async function fetchCollectionsFromDB(storeId?: string): Promise<Collection[]> {
  try {
    const colRef = collection(db, COLLECTIONS_COL);
    const q = storeId ? query(colRef, where('storeId', '==', storeId)) : colRef;
    const snap = await getDocs(q);
    if (!snap.empty) {
      const list = snap.docs.map((d) => d.data() as Collection);
      return list.filter((c) => c && typeof c === 'object' && typeof c.id === 'string');
    }
    return [];
  } catch (err) {
    console.warn('Firestore fetchCollections error:', err);
    return [];
  }
}

export async function saveCollectionToDB(item: Collection): Promise<void> {
  try {
    await setDoc(doc(db, COLLECTIONS_COL, item.id), sanitizeForFirestore(item));
  } catch (err) {
    console.warn('Firestore saveCollection error:', err);
  }
}

export async function deleteCollectionFromDB(collectionId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, COLLECTIONS_COL, collectionId));
  } catch (err) {
    console.warn('Firestore deleteCollection error:', err);
  }
}
