import { ReviewRating, Topic } from '../types';

/**
 * Standard Ebbinghaus Forgetting Curve intervals in days
 * Explicitly requested: Day 1, 3, 7, 21, 30, and so on (60, 90).
 */
export const FORGETTING_INTERVALS = [1, 3, 7, 21, 30, 60, 90] as const;

export interface MasteryTier {
  level: number;
  label: string;
  minScore: number;
  maxScore: number;
  colorHex: string;
  badgeBg: string;
  badgeText: string;
  description: string;
}

export const MASTERY_TIERS: MasteryTier[] = [
  {
    level: 0,
    label: 'Initial Learning',
    minScore: 0,
    maxScore: 14,
    colorHex: '#94a3b8', // slate-400
    badgeBg: 'bg-slate-100 dark:bg-slate-800',
    badgeText: 'text-slate-700 dark:text-slate-300',
    description: 'Freshly registered concept. First 24-hour review critical.',
  },
  {
    level: 1,
    label: 'Initial Recall (Day 1)',
    minScore: 15,
    maxScore: 29,
    colorHex: '#f43f5e', // rose-500
    badgeBg: 'bg-rose-50 dark:bg-rose-950/40',
    badgeText: 'text-rose-700 dark:text-rose-300',
    description: 'Passed Day 1 hurdle. Next review at Day 3.',
  },
  {
    level: 2,
    label: 'Consolidating (Day 3)',
    minScore: 30,
    maxScore: 49,
    colorHex: '#f59e0b', // amber-500
    badgeBg: 'bg-amber-50 dark:bg-amber-950/40',
    badgeText: 'text-amber-700 dark:text-amber-300',
    description: 'Memory trace establishing. Next review at Day 7.',
  },
  {
    level: 3,
    label: 'Consolidated (Day 7)',
    minScore: 50,
    maxScore: 69,
    colorHex: '#eab308', // yellow-500
    badgeBg: 'bg-yellow-50 dark:bg-yellow-950/40',
    badgeText: 'text-yellow-700 dark:text-yellow-300',
    description: 'Synaptic stabilization underway. Next review at Day 21.',
  },
  {
    level: 4,
    label: 'Long-Term Transfer (Day 21)',
    minScore: 70,
    maxScore: 84,
    colorHex: '#0284c7', // sky-600
    badgeBg: 'bg-sky-50 dark:bg-sky-950/40',
    badgeText: 'text-sky-700 dark:text-sky-300',
    description: 'Solid intermediate retention. Next review at Day 30.',
  },
  {
    level: 5,
    label: 'Deep Retention (Day 30)',
    minScore: 85,
    maxScore: 94,
    colorHex: '#6366f1', // indigo-500
    badgeBg: 'bg-indigo-50 dark:bg-indigo-950/40',
    badgeText: 'text-indigo-700 dark:text-indigo-300',
    description: 'Permanent cortical storage established. Next review at Day 60.',
  },
  {
    level: 6,
    label: 'Mastered (Day 60+)',
    minScore: 95,
    maxScore: 100,
    colorHex: '#10b981', // emerald-500
    badgeBg: 'bg-emerald-50 dark:bg-emerald-950/40',
    badgeText: 'text-emerald-700 dark:text-emerald-300',
    description: 'Mastered long-term memory. Minimal forgetting decay.',
  },
];

/**
 * Returns the mastery tier object based on current mastery score (0-100)
 */
export function getMasteryTier(score: number): MasteryTier {
  const boundedScore = Math.max(0, Math.min(100, Math.round(score)));
  for (const tier of MASTERY_TIERS) {
    if (boundedScore >= tier.minScore && boundedScore <= tier.maxScore) {
      return tier;
    }
  }
  return MASTERY_TIERS[MASTERY_TIERS.length - 1];
}

/**
 * Compute the initial next review date: 1 day after creation
 */
export function getInitialNextReviewDate(createdDate: string | Date = new Date()): string {
  const d = new Date(createdDate);
  d.setDate(d.getDate() + 1);
  return d.toISOString().split('T')[0];
}

/**
 * Incremental days to add from each review milestone to reach the next curve milestone:
 * - From Day 0: +1 day -> Day 1 milestone
 * - From Day 1: +2 days -> Day 3 milestone
 * - From Day 3: +4 days -> Day 7 milestone
 * - From Day 7: +14 days -> Day 21 milestone
 * - From Day 21: +9 days -> Day 30 milestone
 * - From Day 30: +30 days -> Day 60 milestone
 * - From Day 60: +30 days -> Day 90 milestone
 */
export const STAGE_INCREMENTAL_DAYS = [1, 2, 4, 14, 9, 30, 30] as const;

/**
 * Calculate the next review date based on stage and rating
 */
export function calculateNextReviewDate(
  currentStage: number,
  rating: ReviewRating,
  baseDate: Date = new Date()
): { nextStage: number; nextReviewDate: string; intervalDays: number; stability: number } {
  let nextStage = currentStage;
  let intervalDays = 1;

  if (rating === 'again') {
    // Reset back to stage 0 (review due tomorrow)
    nextStage = 0;
    intervalDays = 1;
  } else if (rating === 'hard') {
    // Stay at current stage, interval is half of normal step (min 1)
    const normalStep = STAGE_INCREMENTAL_DAYS[Math.min(currentStage, STAGE_INCREMENTAL_DAYS.length - 1)] || 1;
    intervalDays = Math.max(1, Math.round(normalStep * 0.5));
    nextStage = currentStage;
  } else if (rating === 'good') {
    // Normal progression to next curve milestone
    const stepIdx = Math.min(currentStage, STAGE_INCREMENTAL_DAYS.length - 1);
    intervalDays = STAGE_INCREMENTAL_DAYS[stepIdx];
    nextStage = Math.min(currentStage + 1, FORGETTING_INTERVALS.length);
  } else if (rating === 'easy') {
    // Jump ahead: advance 2 stages or expand interval
    const stepIdx = Math.min(currentStage, STAGE_INCREMENTAL_DAYS.length - 1);
    const normalStep = STAGE_INCREMENTAL_DAYS[stepIdx];
    intervalDays = Math.max(2, Math.round(normalStep * 1.5));
    nextStage = Math.min(currentStage + 1, FORGETTING_INTERVALS.length);
  }

  // Calculate memory stability S in days
  const stability = Math.max(1, intervalDays * 1.6);

  const nextDate = new Date(baseDate);
  nextDate.setDate(nextDate.getDate() + intervalDays);
  const nextDateStr = nextDate.toISOString().split('T')[0];

  return {
    nextStage,
    nextReviewDate: nextDateStr,
    intervalDays,
    stability,
  };
}

/**
 * Calculate estimated retention percentage R(t) = e^(-t/S) * 100
 */
export function calculateRetention(
  lastReviewedAt: string | undefined,
  createdAt: string,
  stability: number = 3.5,
  currentDate: Date = new Date()
): number {
  const referenceDate = new Date(lastReviewedAt || createdAt);
  const diffMs = currentDate.getTime() - referenceDate.getTime();
  const elapsedDays = Math.max(0, diffMs / (1000 * 60 * 60 * 24));

  const safeStability = Math.max(0.5, stability);
  // Ebbinghaus formula: R = e^(-t/S)
  const retentionFraction = Math.exp(-elapsedDays / safeStability);
  return Math.max(1, Math.min(100, Math.round(retentionFraction * 100)));
}

/**
 * Calculate overall mastery score (0-100) based on stage, consistency, and flashcard performance
 */
export function calculateMasteryScore(
  stage: number,
  consecutiveSuccesses: number,
  flashcardPerformancePct: number = 100
): number {
  // Max stage in our milestone array is 7
  const baseStageScore = (Math.min(stage, 7) / 7) * 80;
  const streakBonus = Math.min(15, consecutiveSuccesses * 2.5);
  const flashcardFactor = (flashcardPerformancePct / 100) * 5;

  const total = Math.round(baseStageScore + streakBonus + flashcardFactor);
  return Math.max(0, Math.min(100, total));
}

/**
 * Check if a topic is due for review today or overdue
 */
export function isDueForReview(nextReviewDateStr: string, todayDate: Date = new Date()): boolean {
  const todayStr = todayDate.toISOString().split('T')[0];
  return nextReviewDateStr <= todayStr;
}

/**
 * Days remaining until review (negative if overdue)
 */
export function getDaysUntilReview(nextReviewDateStr: string, todayDate: Date = new Date()): number {
  const target = new Date(nextReviewDateStr + 'T00:00:00');
  const today = new Date(todayDate.toISOString().split('T')[0] + 'T00:00:00');
  const diffTime = target.getTime() - today.getTime();
  return Math.round(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Process a full review for a topic and return updated topic object
 */
export function processTopicReview(
  topic: Topic,
  rating: ReviewRating,
  reviewDate: Date = new Date()
): Topic {
  const currentStage = topic.stage;
  const result = calculateNextReviewDate(currentStage, rating, reviewDate);

  const consecutive = rating === 'again' ? 0 : topic.consecutiveSuccesses + 1;
  const newMasteryScore = calculateMasteryScore(result.nextStage, consecutive);

  const reviewEntry = {
    date: reviewDate.toISOString(),
    rating,
    stageBefore: currentStage,
    stageAfter: result.nextStage,
  };

  return {
    ...topic,
    stage: result.nextStage,
    nextReviewDate: result.nextReviewDate,
    lastReviewedAt: reviewDate.toISOString(),
    stability: result.stability,
    consecutiveSuccesses: consecutive,
    masteryScore: newMasteryScore,
    history: [reviewEntry, ...topic.history],
  };
}

/**
 * Generate (x, y) coordinates for drawing the Ebbinghaus forgetting curve SVG
 */
export function generateDecayCurvePoints(stability: number, totalDays: number = 30): { day: number; retention: number }[] {
  const points: { day: number; retention: number }[] = [];
  const step = totalDays / 20;
  for (let d = 0; d <= totalDays; d += step) {
    const r = Math.exp(-d / Math.max(0.5, stability)) * 100;
    points.push({ day: Number(d.toFixed(1)), retention: Math.round(r) });
  }
  return points;
}
