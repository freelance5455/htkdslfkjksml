import { Confession, Poll, QuizQuestion, EmojiPuzzle, TruthDareItem, ChatRoom, College } from '../types';

// Zero pre-added colleges! Every college is activated by students through the State & District Directory
export const INITIAL_COLLEGES: College[] = [];

// Empty clean production state - ready for real user confessions!
export const INITIAL_CONFESSIONS: Confession[] = [];

// Empty clean production polls - ready for real student votes
export const INITIAL_POLLS: Poll[] = [];

// Games & Trivia content (fun campus quizzes & games for students)
export const INITIAL_QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q-1',
    question: "What is the universal law of studying for a semester final?",
    options: [
      "Consistent 2 hours daily from week 1",
      "Panic studying 6 chapters in 5 hours at 3 AM",
      "Making aesthetic Notion templates that you never open",
      "Watching 2x speed YouTube Indian tutor videos",
    ],
    correctIndex: 3,
    explanation: "YouTube tutors have carried 99.4% of engineering & science degrees since 2012.",
    points: 100,
  },
  {
    id: 'q-2',
    question: "If a professor says 'This will NOT be on the exam', what happens?",
    options: [
      "It never appears",
      "It becomes a 20-mark compulsory question on Page 1",
      "The exam gets cancelled",
      "Everyone gets bonus marks",
    ],
    correctIndex: 1,
    explanation: "Murphy's Academic Law guarantees it will be the highest weighted question.",
    points: 100,
  },
  {
    id: 'q-3',
    question: "What does the hostel mess cook when they run out of ideas?",
    options: [
      "Mystery Dal with infinite viscosity",
      "Aloo with everything",
      "Paneer cubes hidden like rare Pokémon",
      "All of the above combined",
    ],
    correctIndex: 3,
    explanation: "Mess chefs possess an innate culinary superpower of universal fusion.",
    points: 100,
  },
  {
    id: 'q-4',
    question: "How long is a '5 minute break' during group study?",
    options: [
      "Exactly 5 minutes",
      "15 minutes with snacks",
      "3 hours watching Instagram reels together",
      "Next day morning",
    ],
    correctIndex: 2,
    explanation: "Time dilation around college study tables is scientifically proven.",
    points: 100,
  }
];

export const INITIAL_EMOJI_PUZZLES: EmojiPuzzle[] = [
  {
    id: 'ep-1',
    title: "Campus Location",
    emojis: "☕ 🥪 🗣️ 🎸",
    category: "Campus Spot",
    hint: "Where everyone sits when they should be in class",
    answer: "canteen",
    solved: false,
  },
  {
    id: 'ep-2',
    title: "Student Mood",
    emojis: "😴 ☕ ⏰ 🏃‍♂️ 🚪",
    category: "Student Routine",
    hint: "Running for the 8:00 AM lecture after 2 hours of sleep",
    answer: "attendance",
    solved: false,
  },
  {
    id: 'ep-3',
    title: "Hostel Life",
    emojis: "🍜 ⚡ 🌙 📱",
    category: "Hostel Classic",
    hint: "Cooked with an electric kettle at 2:30 AM",
    answer: "maggi",
    solved: false,
  },
  {
    id: 'ep-4',
    title: "College Event",
    emojis: "🎪 🎤 💃 🎟️",
    category: "Fest Season",
    hint: "When even proxy attendances reach peak levels",
    answer: "college fest",
    solved: false,
  }
];

export const INITIAL_TRUTH_DARE: TruthDareItem[] = [
  {
    id: 'td-1',
    type: 'truth',
    prompt: "Who is your secret college crush that no one in your friend circle knows about?",
    intensity: 'Spicy',
    category: 'Romance'
  },
  {
    id: 'td-2',
    type: 'truth',
    prompt: "What is the biggest academic lie you have ever told to your parents or professors?",
    intensity: 'Insane',
    category: 'Academics'
  },
  {
    id: 'td-3',
    type: 'dare',
    prompt: "Drop an anonymous compliment in the Campus Gossip feed right now describing someone without naming them.",
    intensity: 'Mild',
    category: 'Social'
  },
  {
    id: 'td-4',
    type: 'truth',
    prompt: "Have you ever secretly taken credit for someone else's work in a college project?",
    intensity: 'Spicy',
    category: 'Friendship'
  },
  {
    id: 'td-5',
    type: 'dare',
    prompt: "Post an anonymous confession admitting the weirdest food combination you eat in the hostel mess.",
    intensity: 'Mild',
    category: 'Hostel'
  }
];

// Clean ready-to-use chat rooms (empty message history for real students)
export const INITIAL_CHAT_ROOMS: ChatRoom[] = [
  {
    id: 'room-night-owls',
    name: 'Midnight Study Sanctum',
    tag: '#3am-thoughts',
    description: 'For students awake past 1 AM studying, overthinking, or contemplating life.',
    activeCount: 1,
    icon: '🦉',
    gradient: 'from-indigo-900/60 to-purple-900/60',
    messages: []
  },
  {
    id: 'room-crush',
    name: 'Campus Crush Radar',
    tag: '#secret-feelings',
    description: 'Describe your crush anonymously. Maybe they will recognize themselves.',
    activeCount: 1,
    icon: '💘',
    gradient: 'from-pink-900/60 to-purple-900/60',
    messages: []
  },
  {
    id: 'room-exam',
    name: 'Exam Vent & Panic Room',
    tag: '#academic-trauma',
    description: 'Scream into the void. We are all winging this semester together.',
    activeCount: 1,
    icon: '🔥',
    gradient: 'from-amber-900/60 to-rose-900/60',
    messages: []
  },
  {
    id: 'room-memes',
    name: 'Hostel Shenanigans & Tea',
    tag: '#mess-food-and-tea',
    description: 'Mess food reviews, warden escapes, corridor rumors and campus banter.',
    activeCount: 1,
    icon: '🍕',
    gradient: 'from-emerald-900/60 to-teal-900/60',
    messages: []
  }
];

export const INITIAL_LEADERBOARD = [
  { rank: 1, name: 'Campus Prime', emoji: '🔮', karma: 100, badge: 'Founding Member', college: 'IITD-2026' }
];
