import test from 'node:test';
import assert from 'node:assert/strict';
import { parseTravelRequest, generateTripSuggestion, getSamplePrompts } from './aiAssistant';

test('AI Assistant Travel Parsing', async (t) => {
  await t.test('correctly extracts destination from Arabic and English input', () => {
    const res1 = parseTravelRequest('أريد السفر إلى إسطنبول مع زوجتي');
    assert.equal(res1.destinationKey, 'istanbul');
    assert.ok(res1.destination.includes('إسطنبول'));

    const res2 = parseTravelRequest('عمرة مباركة لشخصين في شهر رمضان');
    assert.equal(res2.destinationKey, 'umrah');
    assert.equal(res2.destinationCountry, 'المملكة العربية السعودية');

    const res3 = parseTravelRequest('Summer holiday in Dubai with family');
    assert.equal(res3.destinationKey, 'dubai');

    const res4 = parseTravelRequest('Romantic trip to Paris for 5 days');
    assert.equal(res4.destinationKey, 'paris');

    const res5 = parseTravelRequest('Overwater villa honeymoon in Maldives');
    assert.equal(res5.destinationKey, 'maldives');
  });

  await t.test('extracts duration and dates correctly', () => {
    const res1 = parseTravelRequest('رحلة إلى إسطنبول لمدة 10 أيام');
    assert.equal(res1.durationDays, 10);

    const res2 = parseTravelRequest('Trip to Paris for 5 days');
    assert.equal(res2.durationDays, 5);

    const res3 = parseTravelRequest('عطلة في دبي لمدة أسبوع');
    assert.equal(res3.durationDays, 7);

    const res4 = parseTravelRequest('عمرة لشخصين لمدة أسبوعين');
    assert.equal(res4.durationDays, 14);

    const res5 = parseTravelRequest('Weekend getaway to Rome');
    assert.equal(res5.durationDays, 3);
  });

  await t.test('extracts traveler count and demographics accurately', () => {
    const res1 = parseTravelRequest('رحلة لشخصين إلى إسطنبول');
    assert.equal(res1.travelersCount, 2);

    const res2 = parseTravelRequest('سفر عائلي 4 أشخاص إلى دبي');
    assert.equal(res2.travelersCount, 4);

    const res3 = parseTravelRequest('Solo adventure in Paris for 1 person');
    assert.equal(res3.travelersCount, 1);

    const res4 = parseTravelRequest('رحلة جماعية لـ 6 مسافرين إلى ماليزيا');
    assert.equal(res4.travelersCount, 6);
  });

  await t.test('extracts budget in DZD, colloquial millions, and foreign currencies', () => {
    // Exact DZD
    const res1 = parseTravelRequest('رحلة إلى إسطنبول بميزانية 250,000 دج');
    assert.equal(res1.budgetSpecified, true);
    assert.equal(res1.budgetEstimatedDZD, 250000);

    // Colloquial Algerian centimes (30 million centimes = 300,000 DZD)
    const res2 = parseTravelRequest('ميزانيتي حوالي 30 مليون سنتيم لإسطنبول');
    assert.equal(res2.budgetSpecified, true);
    assert.equal(res2.budgetEstimatedDZD, 300000);

    // Foreign currency EUR conversion
    const res3 = parseTravelRequest('Trip to Paris budget 1500 EUR');
    assert.equal(res3.budgetSpecified, true);
    assert.ok(res3.budgetEstimatedDZD > 300000);

    // Budget tier detection
    const resVIP = parseTravelRequest('رحلة VIP فاخرة جداً إلى دبي');
    assert.equal(resVIP.budgetTier, 'vip');

    const resEco = parseTravelRequest('رحلة اقتصادية رخيصة بميزانية محدودة لإسطنبول');
    assert.equal(resEco.budgetTier, 'economy');
  });

  await t.test('generates complete and structured trip suggestions', () => {
    const parsed = parseTravelRequest('رحلة إلى إسطنبول لمدة 7 أيام لشخصين بميزانية 250,000 دج');
    const suggestion = generateTripSuggestion(parsed, 'ar');

    assert.ok(suggestion.id.startsWith('plan-istanbul-'));
    assert.equal(suggestion.durationDays, 7);
    assert.equal(suggestion.travelersCount, 2);
    assert.ok(suggestion.flight.airline.length > 0);
    assert.ok(suggestion.hotel.name.length > 0);
    assert.ok(suggestion.timelineHighlights.length > 0);
    assert.ok(suggestion.includedServices.length >= 4);
    assert.ok(suggestion.smartTip.length > 10);
    assert.ok(suggestion.visaRequirementsSummary.length > 10);
  });

  await t.test('provides multi-lingual quick suggested prompts', () => {
    const arPrompts = getSamplePrompts('ar');
    assert.ok(arPrompts.length >= 4);
    assert.ok(arPrompts[0].includes('إسطنبول'));

    const enPrompts = getSamplePrompts('en');
    assert.ok(enPrompts.length >= 4);
    assert.ok(enPrompts[0].includes('Istanbul'));

    const frPrompts = getSamplePrompts('fr');
    assert.ok(frPrompts.length >= 4);
    assert.ok(frPrompts[0].includes('Istanbul'));
  });
});
