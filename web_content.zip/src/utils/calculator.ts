import { BOQItem, CalculationResult, CategoryItem } from "../types";

/**
 * Format numbers in Indian numbering format with Rupee symbol
 */
export function formatINR(amount: number | null | undefined): string {
  if (amount === null || amount === undefined || isNaN(amount)) {
    return "₹0";
  }
  return `₹${Math.round(amount).toLocaleString("en-IN")}`;
}

/**
 * Format raw numbers with 2 decimal places if fractional, else whole
 */
export function formatNumber(val: number | null | undefined): string {
  if (val === null || val === undefined || isNaN(val)) {
    return "0";
  }
  if (Number.isInteger(val)) {
    return val.toLocaleString("en-IN");
  }
  return Number(val.toFixed(2)).toLocaleString("en-IN");
}

/**
 * Generate exact Bill of Quantities (BOQ) for any given area
 */
export function generateBOQ(
  categoryId: string,
  area: number,
  customBaseRate?: number | null
): { items: BOQItem[]; hasDetailedBOQ: boolean; boqMessage?: string } {
  const safeArea = Math.max(0, area);
  const scale = safeArea / 100; // standard 100 sq ft reference scale

  switch (categoryId) {
    case "wallpaper": {
      // For 100 sq ft = 3 Rolls @ ₹1,500/Roll = ₹4,500
      const rolls = Number(((safeArea / 100) * 3).toFixed(2));
      const rollRate = 1500;
      return {
        hasDetailedBOQ: true,
        items: [
          {
            id: "wp_roll",
            name: "Wallpaper Rolls",
            hindiName: "वॉलपेपर रोल्स",
            size: "Std Roll (~33.3 sq ft coverage)",
            unit: "Rolls",
            quantity: rolls,
            unitRate: rollRate,
            amount: Number((rolls * rollRate).toFixed(2)),
            note: "3 Rolls per 100 sq ft @ ₹1,500/Roll",
          },
        ],
      };
    }

    case "grid_ceiling": {
      // 100 sq ft exact BOQ: Total = ₹2,642.50
      const items: BOQItem[] = [
        {
          id: "gc_tile",
          name: "2×2 Tile",
          hindiName: "2×2 टाइल",
          size: "2 ft × 2 ft",
          unit: "pieces",
          quantity: Number((25 * scale).toFixed(2)),
          unitRate: 72,
          amount: Number((25 * scale * 72).toFixed(2)),
        },
        {
          id: "gc_l_profile",
          name: "L / L Profile",
          hindiName: "एल / एल प्रोफाइल",
          size: "Standard",
          unit: "pieces",
          quantity: Number((5 * scale).toFixed(2)),
          unitRate: 50,
          amount: Number((5 * scale * 50).toFixed(2)),
        },
        {
          id: "gc_manti",
          name: "Manti",
          hindiName: "मान्टी",
          size: "Standard",
          unit: "pieces",
          quantity: Number((2 * scale).toFixed(2)),
          unitRate: 100,
          amount: Number((2 * scale * 100).toFixed(2)),
        },
        {
          id: "gc_4ft_piece",
          name: "4 ft pieces",
          hindiName: "4 फीट टी-सेक्शन",
          size: "4 ft",
          unit: "pieces",
          quantity: Number((8 * scale).toFixed(2)),
          unitRate: 25,
          amount: Number((8 * scale * 25).toFixed(2)),
        },
        {
          id: "gc_2ft_piece",
          name: "2 ft pieces",
          hindiName: "2 फीट टी-सेक्शन",
          size: "2 ft",
          unit: "pieces",
          quantity: Number((15 * scale).toFixed(2)),
          unitRate: 7.5,
          amount: Number((15 * scale * 7.5).toFixed(2)),
        },
        {
          id: "gc_gitti",
          name: "Gitti",
          hindiName: "गिट्टी पैकेट",
          size: "Packet",
          unit: "packet",
          quantity: Number((1 * scale).toFixed(2)),
          unitRate: 30,
          amount: Number((1 * scale * 30).toFixed(2)),
        },
        {
          id: "gc_358_box",
          name: "35.8 Box",
          hindiName: "35.8 बॉक्स स्क्रू",
          size: "Box",
          unit: "box",
          quantity: Number((1 * scale).toFixed(2)),
          unitRate: 50,
          amount: Number((1 * scale * 50).toFixed(2)),
        },
      ];
      return { hasDetailedBOQ: true, items };
    }

    case "fluted_panel": {
      // 100 sq ft exact BOQ: Total = ₹9,280
      const items: BOQItem[] = [
        {
          id: "fp_panel",
          name: "Fluted Panel",
          hindiName: "फ्लूटेड पैनल",
          size: "1 ft × 10 ft",
          unit: "pieces",
          quantity: Number((10 * scale).toFixed(2)),
          unitRate: 900,
          amount: Number((10 * scale * 900).toFixed(2)),
          note: "1 ft × 10 ft = 10 sq ft @ ₹90/sq ft (₹900/pc)",
        },
        {
          id: "fp_u_bedding",
          name: "U Bedding",
          hindiName: "यू बेडिंग",
          size: "Standard",
          unit: "pieces",
          quantity: Number((4 * scale).toFixed(2)),
          unitRate: 45,
          amount: Number((4 * scale * 45).toFixed(2)),
        },
        {
          id: "fp_keel",
          name: "Keel Packet",
          hindiName: "कील पैकेट",
          size: "Packet",
          unit: "packet",
          quantity: Number((1 * scale).toFixed(2)),
          unitRate: 100,
          amount: Number((1 * scale * 100).toFixed(2)),
        },
      ];
      return { hasDetailedBOQ: true, items };
    }

    case "louver_panel": {
      // 100 sq ft exact BOQ: Total = ₹17,290
      const items: BOQItem[] = [
        {
          id: "lp_panel",
          name: "Louver / Lower Panel",
          hindiName: "लूवर पैनल",
          size: "6 inch × 9.5 ft",
          unit: "pieces",
          quantity: Number((20 * scale).toFixed(2)),
          unitRate: 855,
          amount: Number((20 * scale * 855).toFixed(2)),
          note: "6 in × 9.5 ft @ ₹855/piece",
        },
        {
          id: "lp_l_profile",
          name: "L Profile / Section",
          hindiName: "एल प्रोफाइल / सेक्शन",
          size: "Standard",
          unit: "pieces",
          quantity: Number((2 * scale).toFixed(2)),
          unitRate: 45,
          amount: Number((2 * scale * 45).toFixed(2)),
        },
        {
          id: "lp_keel",
          name: "Keel Packet",
          hindiName: "कील पैकेट",
          size: "Packet",
          unit: "packet",
          quantity: Number((1 * scale).toFixed(2)),
          unitRate: 100,
          amount: Number((1 * scale * 100).toFixed(2)),
        },
      ];
      return { hasDetailedBOQ: true, items };
    }

    case "pvc_wall_panel": {
      // 100 sq ft exact BOQ: Total = ₹2,490
      const items: BOQItem[] = [
        {
          id: "pwp_panel",
          name: "PVC Wall Panel",
          hindiName: "पीवीसी वॉल पैनल",
          size: "Standard Panel",
          unit: "panels",
          quantity: Number((13 * scale).toFixed(2)),
          unitRate: 170,
          amount: Number((13 * scale * 170).toFixed(2)),
        },
        {
          id: "pwp_u_bedding",
          name: "U-Bedding",
          hindiName: "यू-बेडिंग",
          size: "Standard",
          unit: "pieces",
          quantity: Number((4 * scale).toFixed(2)),
          unitRate: 45,
          amount: Number((4 * scale * 45).toFixed(2)),
        },
        {
          id: "pwp_keel",
          name: "17 Number Keel Packet",
          hindiName: "17 नंबर कील पैकेट",
          size: "Packet",
          unit: "packet",
          quantity: Number((1 * scale).toFixed(2)),
          unitRate: 100,
          amount: Number((1 * scale * 100).toFixed(2)),
        },
      ];
      return { hasDetailedBOQ: true, items };
    }

    case "uv_marble_sheet": {
      // 100 sq ft exact BOQ:
      // UV Marble Sheet: 8 ft × 4 ft = 32 sq ft @ ₹120/sq ft = ₹3,840
      // Lower Panel: 15 pcs (6 inch) - rate not configured/unknown shown clearly
      // Lower L: 5 pcs @ ₹45 = ₹225
      // Bond Silicone: 2 pcs @ ₹300 = ₹600 (Included in Material Cost)
      const sheetRate = customBaseRate ?? 120;
      const sheetSqFt = 32;
      const sheetCount = Number((1 * scale).toFixed(2));
      const sheetAmount = Number((sheetCount * sheetSqFt * sheetRate).toFixed(2));

      const items: BOQItem[] = [
        {
          id: "uv_sheet",
          name: "UV Marble Sheet",
          hindiName: "यूवी मार्बल शीट",
          size: "8 ft × 4 ft (32 sq ft)",
          unit: "sheet",
          quantity: sheetCount,
          unitRate: sheetRate * sheetSqFt,
          amount: sheetAmount,
          note: `1 sheet (32 sq ft) @ ₹${sheetRate}/sq ft = ₹${sheetRate * sheetSqFt}`,
        },
        {
          id: "uv_lower_panel",
          name: "Lower Panel",
          hindiName: "लोअर पैनल",
          size: "6 inch",
          unit: "pieces",
          quantity: Number((15 * scale).toFixed(2)),
          unitRate: 0,
          amount: 0,
          note: "Rate not configured (Rate unset)",
        },
        {
          id: "uv_lower_l",
          name: "Lower L",
          hindiName: "लोअर एल",
          size: "Standard",
          unit: "pieces",
          quantity: Number((5 * scale).toFixed(2)),
          unitRate: 45,
          amount: Number((5 * scale * 45).toFixed(2)),
        },
        {
          id: "uv_bond_silicone",
          name: "Bond Silicone",
          hindiName: "बॉन्ड सिलिकॉन",
          size: "Standard Tube",
          unit: "pieces",
          quantity: Number((2 * scale).toFixed(2)),
          unitRate: 300,
          amount: Number((2 * scale * 300).toFixed(2)),
          note: "2 pcs @ ₹300 = ₹600 (Included in Material Cost)",
        },
      ];
      return { hasDetailedBOQ: true, items };
    }

    case "pvc_ceiling": {
      // 100 sq ft = ₹6,000 (@ ₹60/sq ft)
      const rate = customBaseRate ?? 60;
      return {
        hasDetailedBOQ: false,
        items: [
          {
            id: "pvc_ceiling_mat",
            name: "PVC Ceiling Panels (White Material)",
            hindiName: "पीवीसी सीलिंग पैनल्स (व्हाइट मटेरियल)",
            size: "Standard Heavy Gauge",
            unit: "sq ft",
            quantity: safeArea,
            unitRate: rate,
            amount: Number((safeArea * rate).toFixed(2)),
            note: `Base white material @ ₹${rate}/sq ft`,
          },
        ],
      };
    }

    case "gypsum_ceiling": {
      // 100 sq ft = ₹6,500 (@ ₹65/sq ft)
      const rate = customBaseRate ?? 65;
      return {
        hasDetailedBOQ: false,
        boqMessage: "Gypsum material BOQ not fully configured (Using base material estimate)",
        items: [
          {
            id: "gypsum_mat",
            name: "Gypsum Board & Channel Framework",
            hindiName: "जिप्सम बोर्ड एवं फ्रेमवर्क",
            size: "Standard False Ceiling Material",
            unit: "sq ft",
            quantity: safeArea,
            unitRate: rate,
            amount: Number((safeArea * rate).toFixed(2)),
            note: `Configured base rate @ ₹${rate}/sq ft`,
          },
        ],
      };
    }

    case "pop_ceiling": {
      // 100 sq ft = ₹12,000 (@ ₹120/sq ft)
      const rate = customBaseRate ?? 120;
      return {
        hasDetailedBOQ: false,
        items: [
          {
            id: "pop_mat",
            name: "Plaster of Paris (POP) Raw Material",
            hindiName: "पीओपी रॉ मटेरियल एवं जाली",
            size: "Standard POP Grade",
            unit: "sq ft",
            quantity: safeArea,
            unitRate: rate,
            amount: Number((safeArea * rate).toFixed(2)),
            note: `White material rate @ ₹${rate}/sq ft`,
          },
        ],
      };
    }

    default: {
      if (customBaseRate !== null && customBaseRate !== undefined && customBaseRate > 0) {
        return {
          hasDetailedBOQ: false,
          items: [
            {
              id: `${categoryId}_mat`,
              name: "Standard White Material",
              hindiName: "व्हाइट मटेरियल",
              size: "Standard",
              unit: "sq ft",
              quantity: safeArea,
              unitRate: customBaseRate,
              amount: Number((safeArea * customBaseRate).toFixed(2)),
            },
          ],
        };
      }
      return {
        hasDetailedBOQ: false,
        boqMessage: "Rate not configured",
        items: [],
      };
    }
  }
}

/**
 * Perform exact ceiling and interior calculation with strict Zero Mismatch Guarantee
 */
export function computeEstimate(
  length: number,
  width: number,
  category: CategoryItem,
  customRate: number | null = null,
  includeLabour: boolean = true,
  customLabourRate?: number | null,
  includeBuffer: boolean = false,
  bufferPercent: number = 5
): CalculationResult {
  const safeLength = Math.max(0, isNaN(length) ? 0 : length);
  const safeWidth = Math.max(0, isNaN(width) ? 0 : width);
  const area = Number((safeLength * safeWidth).toFixed(2));

  const activeBaseRate = customRate !== null && customRate !== undefined ? customRate : category.defaultRate;
  const isRateConfigured = activeBaseRate !== null && activeBaseRate > 0;

  // Generate BOQ
  const { items: boqItems, hasDetailedBOQ, boqMessage } = generateBOQ(
    category.id,
    area,
    activeBaseRate
  );

  // Material Total is strictly the sum of all BOQ items
  const materialTotal = Number(
    boqItems.reduce((sum, item) => sum + item.amount, 0).toFixed(2)
  );

  // Buffer calculation (optional, 0 if disabled)
  const bufferAmount = includeBuffer
    ? Number((materialTotal * (bufferPercent / 100)).toFixed(2))
    : 0;

  // Labour calculation
  let labourRate = 0;
  let labourUnit = category.labourUnit || "sq ft";
  let labourQuantity = area;

  if (category.id === "wallpaper") {
    labourUnit = "Roll";
    labourQuantity = Number(((area / 100) * 3).toFixed(2)); // wallpaper rolls
    labourRate =
      customLabourRate !== null && customLabourRate !== undefined && !isNaN(customLabourRate)
        ? customLabourRate
        : category.defaultLabourRate ?? 400;
  } else {
    labourUnit = "sq ft";
    labourQuantity = area;
    labourRate =
      customLabourRate !== null && customLabourRate !== undefined && !isNaN(customLabourRate)
        ? customLabourRate
        : category.defaultLabourRate ?? 18;
  }

  const safeLabourRate = includeLabour && !isNaN(labourRate) && labourRate > 0 ? labourRate : 0;
  const labourTotal = includeLabour
    ? Number((labourQuantity * safeLabourRate).toFixed(2))
    : 0;

  // Grand Total = Material Total + Buffer Amount + Labour Total
  const grandTotal = Number((materialTotal + bufferAmount + labourTotal).toFixed(2));

  return {
    id: `est_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    timestamp: Date.now(),
    length: safeLength,
    width: safeWidth,
    area,
    categoryId: category.id,
    categoryName: category.name,
    categoryHindiName: category.hindiName,
    referenceRatePerSqFt: activeBaseRate,
    hasDetailedBOQ,
    boqMessage,
    boqItems,
    materialTotal,
    bufferEnabled: includeBuffer,
    bufferPercent,
    bufferAmount,
    includeLabour,
    labourRate: safeLabourRate,
    labourUnit,
    labourQuantity,
    labourTotal,
    grandTotal,
    isRateConfigured: isRateConfigured || boqItems.length > 0,
  };
}

/**
 * Prepare readable text for sharing via WhatsApp / native share
 */
export function generateShareText(result: CalculationResult): string {
  const dateStr = new Date(result.timestamp).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  let text = `🏠 *CEILING & INTERIOR ESTIMATE*\n`;
  text += `📅 Date: ${dateStr}\n`;
  text += `━━━━━━━━━━━━━━━━━━━━━\n`;
  text += `🔨 *Work Type:* ${result.categoryName}\n`;
  text += `📐 *Room Size:* ${result.length} ft × ${result.width} ft\n`;
  text += `📏 *Total Area:* ${formatNumber(result.area)} sq ft\n`;
  text += `━━━━━━━━━━━━━━━━━━━━━\n`;

  // Material BOQ section
  text += `📦 *MATERIAL BOQ:*\n`;
  if (result.boqItems.length > 0) {
    result.boqItems.forEach((item, idx) => {
      text += `${idx + 1}. *${item.name}* (${item.size || item.unit})\n`;
      text += `   Qty: ${formatNumber(item.quantity)} ${item.unit} @ ₹${formatNumber(item.unitRate)} = *${formatINR(item.amount)}*\n`;
    });
  } else if (result.boqMessage) {
    text += `   _${result.boqMessage}_\n`;
  }
  text += `\n💰 *MATERIAL TOTAL:* ${formatINR(result.materialTotal)}\n`;

  // Buffer (if enabled)
  if (result.bufferEnabled && result.bufferAmount > 0) {
    text += `🛡️ *Buffer / Wastage (${result.bufferPercent}%):* ${formatINR(result.bufferAmount)}\n`;
  }

  text += `━━━━━━━━━━━━━━━━━━━━━\n`;

  // Labour section
  if (result.includeLabour && result.labourTotal > 0) {
    text += `👷 *LABOUR CHARGE:*\n`;
    text += `   Rate: ₹${formatNumber(result.labourRate)} / ${result.labourUnit}\n`;
    text += `   Units: ${formatNumber(result.labourQuantity)} ${result.labourUnit}\n`;
    text += `   *Labour Total:* ${formatINR(result.labourTotal)}\n`;
  } else {
    text += `👷 *LABOUR:* Not included\n`;
  }

  text += `━━━━━━━━━━━━━━━━━━━━━\n`;
  text += `✨ *GRAND TOTAL:* ${formatINR(result.grandTotal)}\n`;
  text += `━━━━━━━━━━━━━━━━━━━━━\n`;
  text += `📱 Calculated with *Ceiling Calculation* App`;

  return text;
}

