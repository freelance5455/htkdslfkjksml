import { Capacitor, registerPlugin } from '@capacitor/core';
import { Task } from '../types';

export interface AlarmPermissionsStatus {
  isNative: boolean;
  exactAlarmAllowed: boolean;
  notificationsAllowed: boolean;
  batteryOptimizationIgnored: boolean;
  isXiaomiOrRedmi: boolean;
  manufacturer?: string;
  model?: string;
  sdkInt?: number;
}

export interface NativeAlarmPluginInterface {
  scheduleAlarm(options: {
    taskId: string;
    title: string;
    triggerMillis: number;
    dueTime: string;
    notes?: string;
    ringtone?: string;
    minutesBefore?: number;
  }): Promise<{ success: boolean; taskId: string; triggerMillis: number }>;

  cancelAlarm(options: { taskId: string }): Promise<{ success: boolean }>;

  cancelAllAlarms(): Promise<{ success: boolean }>;

  getPermissionsStatus(): Promise<{
    exactAlarmAllowed: boolean;
    notificationsAllowed: boolean;
    batteryOptimizationIgnored: boolean;
    isXiaomiOrRedmi: boolean;
    manufacturer?: string;
    model?: string;
    sdkInt?: number;
  }>;

  requestExactAlarmPermission(): Promise<{ success: boolean }>;

  requestIgnoreBatteryOptimizations(): Promise<{ success: boolean }>;

  openAutostartSettings(): Promise<{ success: boolean }>;

  silenceAlarm(): Promise<{ success: boolean }>;

  dismissAlarm(options?: { taskId?: string }): Promise<{ success: boolean }>;

  snoozeAlarm(options: {
    taskId: string;
    minutes?: number;
    title?: string;
    ringtone?: string;
  }): Promise<{ success: boolean; snoozeTime: string }>;

  testLockScreenAlarm(options: {
    delaySeconds?: number;
    title?: string;
  }): Promise<{ success: boolean; taskId: string }>;

  addListener(eventName: string, listenerFunc: (data: any) => void): Promise<any>;
  removeAllListeners(): Promise<void>;
}

// Register Capacitor plugin
export const HabivioAlarm = registerPlugin<NativeAlarmPluginInterface>('HabivioAlarm');

/**
 * Check if the app is running as a native Android APK
 */
export function isNativeAndroid(): boolean {
  return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
}

/**
 * Query Android exact alarms, battery saver exemption, and notification status
 */
export async function getAlarmPermissionsStatus(): Promise<AlarmPermissionsStatus> {
  if (!isNativeAndroid()) {
    const notifGranted = typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted';
    return {
      isNative: false,
      exactAlarmAllowed: true,
      notificationsAllowed: notifGranted,
      batteryOptimizationIgnored: true,
      isXiaomiOrRedmi: false,
    };
  }

  try {
    const res = await HabivioAlarm.getPermissionsStatus();
    return {
      isNative: true,
      exactAlarmAllowed: res.exactAlarmAllowed,
      notificationsAllowed: res.notificationsAllowed,
      batteryOptimizationIgnored: res.batteryOptimizationIgnored,
      isXiaomiOrRedmi: res.isXiaomiOrRedmi,
      manufacturer: res.manufacturer,
      model: res.model,
      sdkInt: res.sdkInt,
    };
  } catch (e) {
    console.warn('Native getPermissionsStatus error:', e);
    return {
      isNative: true,
      exactAlarmAllowed: false,
      notificationsAllowed: false,
      batteryOptimizationIgnored: false,
      isXiaomiOrRedmi: false,
    };
  }
}

/**
 * Schedule a native AlarmManager alarm
 */
export async function scheduleNativeAlarm(task: Task, triggerDate: Date): Promise<boolean> {
  if (!isNativeAndroid()) return false;

  try {
    await HabivioAlarm.scheduleAlarm({
      taskId: task.id,
      title: task.title,
      triggerMillis: triggerDate.getTime(),
      dueTime: task.dueTime || '',
      notes: task.notes || '',
      ringtone: task.ringtone || 'morning_birds',
      minutesBefore: task.alarmMinutesBefore || 0,
    });
    return true;
  } catch (err) {
    console.warn(`Failed to schedule native alarm for task ${task.id}:`, err);
    return false;
  }
}

/**
 * Cancel a specific native alarm
 */
export async function cancelNativeAlarm(taskId: string): Promise<boolean> {
  if (!isNativeAndroid()) return false;

  try {
    await HabivioAlarm.cancelAlarm({ taskId });
    return true;
  } catch (err) {
    console.warn(`Failed to cancel native alarm ${taskId}:`, err);
    return false;
  }
}

/**
 * Cancel all native alarms
 */
export async function cancelAllNativeAlarms(): Promise<boolean> {
  if (!isNativeAndroid()) return false;

  try {
    await HabivioAlarm.cancelAllAlarms();
    return true;
  } catch (err) {
    console.warn('Failed to cancel all native alarms:', err);
    return false;
  }
}

/**
 * Launch system settings to request exact alarm permissions (Android 12+)
 */
export async function requestExactAlarmPermission(): Promise<void> {
  if (!isNativeAndroid()) return;
  try {
    await HabivioAlarm.requestExactAlarmPermission();
  } catch (e) {
    console.warn('Failed to request exact alarm permission:', e);
  }
}

/**
 * Request exemption from battery optimization
 */
export async function requestIgnoreBatteryOptimizations(): Promise<void> {
  if (!isNativeAndroid()) return;
  try {
    await HabivioAlarm.requestIgnoreBatteryOptimizations();
  } catch (e) {
    console.warn('Failed to request battery optimization:', e);
  }
}

/**
 * Open Xiaomi / Redmi / POCO Autostart settings
 */
export async function openRedmiAutostartSettings(): Promise<boolean> {
  if (!isNativeAndroid()) return false;
  try {
    const res = await HabivioAlarm.openAutostartSettings();
    return Boolean(res.success);
  } catch (e) {
    console.warn('Failed to open Redmi autostart settings:', e);
    return false;
  }
}

/**
 * Silence any currently sounding alarm
 */
export async function silenceNativeAlarm(): Promise<void> {
  if (!isNativeAndroid()) return;
  try {
    await HabivioAlarm.silenceAlarm();
  } catch (e) {
    console.warn('Failed to silence native alarm:', e);
  }
}

/**
 * Stop and dismiss native alarm
 */
export async function dismissNativeAlarm(taskId?: string): Promise<void> {
  if (!isNativeAndroid()) return;
  try {
    await HabivioAlarm.dismissAlarm(taskId ? { taskId } : undefined);
  } catch (e) {
    console.warn('Failed to dismiss native alarm:', e);
  }
}

/**
 * Snooze native alarm for 5 minutes
 */
export async function snoozeNativeAlarm(task: Task, minutes: number = 5): Promise<string | null> {
  if (!isNativeAndroid()) return null;
  try {
    const res = await HabivioAlarm.snoozeAlarm({
      taskId: task.id,
      minutes,
      title: task.title,
      ringtone: task.ringtone,
    });
    return res.snoozeTime;
  } catch (e) {
    console.warn('Failed to snooze native alarm:', e);
    return null;
  }
}

/**
 * Test Lock-Screen alarm with countdown
 */
export async function testNativeLockScreenAlarm(delaySeconds: number = 5, title: string = 'লক স্ক্রিন অ্যালার্ম টেস্ট — Habivio'): Promise<boolean> {
  if (!isNativeAndroid()) return false;
  try {
    await HabivioAlarm.testLockScreenAlarm({ delaySeconds, title });
    return true;
  } catch (e) {
    console.warn('Failed to trigger test native alarm:', e);
    return false;
  }
}

/**
 * Attach listeners to receive native alarm lifecycle events in React
 */
export function setupNativeAlarmListeners(handlers: {
  onTriggered?: (data: { taskId: string; title: string; dueTime: string; ringtone: string }) => void;
  onCompleted?: (data: { taskId: string }) => void;
  onSnoozed?: (data: { taskId: string; snoozeTime: string }) => void;
  onDismissed?: (data: { taskId: string }) => void;
}): () => void {
  if (!isNativeAndroid()) return () => {};

  const cleanups: Array<() => void> = [];

  if (handlers.onTriggered) {
    HabivioAlarm.addListener('alarmTriggered', handlers.onTriggered).then((handle) => {
      cleanups.push(() => handle?.remove?.());
    });
  }

  if (handlers.onCompleted) {
    HabivioAlarm.addListener('alarmCompleted', handlers.onCompleted).then((handle) => {
      cleanups.push(() => handle?.remove?.());
    });
  }

  if (handlers.onSnoozed) {
    HabivioAlarm.addListener('alarmSnoozed', handlers.onSnoozed).then((handle) => {
      cleanups.push(() => handle?.remove?.());
    });
  }

  if (handlers.onDismissed) {
    HabivioAlarm.addListener('alarmDismissed', handlers.onDismissed).then((handle) => {
      cleanups.push(() => handle?.remove?.());
    });
  }

  return () => {
    cleanups.forEach((c) => c());
  };
}
