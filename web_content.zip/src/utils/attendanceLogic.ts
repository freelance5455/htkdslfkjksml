import type {
  AppState,
  AttendanceMark,
  DailyAttendanceRecord,
  Department,
  DepartmentSummary,
  GlobalOverview,
  ShiftType,
  Worker,
} from '../types/attendance';

export const STORAGE_KEY = 'daily_attendance_system_v1';

export const COMMON_ROLES = [
  'Welder',
  'Fitter',
  'Mason',
  'Helper',
  'Electrician',
  'Fabricator',
  'Rigger',
  'Supervisor',
];

export function getTodayDateString(now: Date = new Date()): string {
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatDisplayDate(dateStr: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    return dateStr;
  }
  const [y, m, d] = dateStr.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return date.toLocaleDateString('en-US', {
    weekday: 'short',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function createSeedWorkers(): Worker[] {
  return [
    { id: 'WRK-101', name: 'Rajesh Kumar', role: 'Welder' },
    { id: 'WRK-102', name: 'Suresh Hembram', role: 'Fitter' },
    { id: 'WRK-103', name: 'Vikram Soren', role: 'Mason' },
    { id: 'WRK-104', name: 'Anil Murmu', role: 'Helper' },
    { id: 'WRK-105', name: 'Deepak Tudu', role: 'Electrician' },
    { id: 'WRK-106', name: 'Manoj Baskey', role: 'Welder' },
    { id: 'WRK-107', name: 'Prakash Hansda', role: 'Fitter' },
    { id: 'WRK-108', name: 'Sanjay Kisku', role: 'Helper' },
  ];
}

export function createSeedHistory(
  workers: Worker[],
  todayStr: string = getTodayDateString(),
): Record<string, DailyAttendanceRecord> {
  const { dates } = getMonthlyCycleRange(todayStr);
  const history: Record<string, DailyAttendanceRecord> = {};

  dates.forEach((dateStr, dayIdx) => {
    // Keep today and future dates clean/unmarked so the user starts today fresh
    if (dateStr >= todayStr) {
      return;
    }

    const [y, m, d] = dateStr.split('-').map(Number);
    const dayOfWeek = new Date(y, m - 1, d).getDay();
    // Skip Sundays as off-day in sample workshop history
    if (dayOfWeek === 0) {
      return;
    }

    const marks: Record<string, AttendanceMark> = {};
    workers.forEach((worker, workerIdx) => {
      // Deterministic realistic attendance (~85-90% present, ~10-15% absent)
      const hash = (dayIdx * 7 + workerIdx * 13 + d) % 11;
      marks[worker.id] = hash === 0 ? 'absent' : 'present';
    });

    history[getAttendanceRecordKey(dateStr, 'day')] = {
      marks,
      submitted: true,
      submittedAt: `${dateStr}T18:00:00.000Z`,
    };
  });

  return history;
}

export function createInitialState(): AppState {
  const workers = createSeedWorkers();
  return {
    departments: [
      {
        id: 'dept-samir-eng',
        name: 'Samir Eng',
        supervisor: 'Ramesh Marandi',
        isPrimary: true,
        workers,
        attendanceByDate: createSeedHistory(workers),
      },
    ],
  };
}

export function loadState(): AppState {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return createInitialState();
    }
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return createInitialState();
    }
    const parsed = JSON.parse(raw) as Partial<AppState>;
    if (!parsed || !Array.isArray(parsed.departments) || parsed.departments.length === 0) {
      return createInitialState();
    }
    const sanitized: Department[] = parsed.departments
      .filter((d): d is Department => Boolean(d && typeof d.id === 'string' && typeof d.name === 'string'))
      .map((d) => ({
        id: d.id,
        name: d.name,
        supervisor: typeof d.supervisor === 'string' ? d.supervisor : '',
        isPrimary: Boolean(d.isPrimary),
        workers: Array.isArray(d.workers)
          ? d.workers.filter(
              (w): w is Worker =>
                Boolean(w && typeof w.id === 'string' && typeof w.name === 'string' && typeof w.role === 'string'),
            )
          : [],
        attendanceByDate:
          d.attendanceByDate && typeof d.attendanceByDate === 'object' ? d.attendanceByDate : {},
      }));
    if (sanitized.length === 0) {
      return createInitialState();
    }
    return { departments: sanitized };
  } catch {
    return createInitialState();
  }
}

export function saveState(state: AppState): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    }
  } catch {
    // Ignore storage quota or private mode errors gracefully
  }
}

export function getAttendanceRecordKey(date: string, shift: ShiftType = 'day'): string {
  return `${date}__${shift}`;
}

export function formatShiftLabel(shift: ShiftType): string {
  return shift === 'night' ? 'Night Shift' : 'Day Shift';
}

export function getRecordForDate(
  department: Department,
  date: string,
  shift: ShiftType = 'day',
): DailyAttendanceRecord {
  const shiftKey = getAttendanceRecordKey(date, shift);
  if (department.attendanceByDate[shiftKey]) {
    return department.attendanceByDate[shiftKey];
  }
  if (shift === 'day' && department.attendanceByDate[date]) {
    return department.attendanceByDate[date];
  }
  return {
    marks: {},
    submitted: false,
  };
}

export function computeDepartmentSummary(
  department: Department,
  date: string,
  shift: ShiftType = 'day',
): DepartmentSummary {
  const record = getRecordForDate(department, date, shift);
  const total = department.workers.length;
  let present = 0;
  let absent = 0;

  for (const worker of department.workers) {
    const mark = record.marks[worker.id];
    if (mark === 'present') {
      present += 1;
    } else if (mark === 'absent') {
      absent += 1;
    }
  }

  return {
    total,
    present,
    absent,
    unmarked: Math.max(0, total - present - absent),
    submitted: Boolean(record.submitted),
    submittedAt: record.submittedAt,
  };
}

export function computeGlobalOverview(
  state: AppState,
  date: string,
  shift: ShiftType = 'day',
): GlobalOverview {
  let totalWorkers = 0;
  let presentToday = 0;
  let absentToday = 0;

  for (const dept of state.departments) {
    const summary = computeDepartmentSummary(dept, date, shift);
    totalWorkers += summary.total;
    presentToday += summary.present;
    absentToday += summary.absent;
  }

  return {
    totalDepartments: state.departments.length,
    totalWorkers,
    presentToday,
    absentToday,
  };
}

export interface MonthlyCycleRange {
  startDate: string;
  endDate: string;
  dates: string[];
  label: string;
}

function toYmd(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getMonthlyCycleRange(referenceDateStr: string = getTodayDateString()): MonthlyCycleRange {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(referenceDateStr);
  const ref = match
    ? new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]))
    : new Date();

  const year = ref.getFullYear();
  const month = ref.getMonth();
  const day = ref.getDate();

  const start = day <= 25 ? new Date(year, month - 1, 26) : new Date(year, month, 26);
  const end = day <= 25 ? new Date(year, month, 25) : new Date(year, month + 1, 25);

  const dates: string[] = [];
  const cursor = new Date(start.getTime());
  while (cursor <= end) {
    dates.push(toYmd(cursor));
    cursor.setDate(cursor.getDate() + 1);
  }

  const startLabel = start.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  const endLabel = end.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

  return {
    startDate: toYmd(start),
    endDate: toYmd(end),
    dates,
    label: `${startLabel} – ${endLabel}`,
  };
}

export interface DailyTrendPoint {
  date: string;
  shortLabel: string;
  dayNumber: string;
  present: number;
  absent: number;
}

export interface DepartmentCycleTotal {
  departmentId: string;
  departmentName: string;
  supervisor: string;
  present: number;
  absent: number;
}

export interface MonthlyTrendSummary {
  days: DailyTrendPoint[];
  totalPresent: number;
  totalAbsent: number;
  maxDailyCount: number;
  byDepartment: DepartmentCycleTotal[];
}

export function computeMonthlyTrend(
  departments: Department[],
  dates: string[],
  selectedDepartmentId: string = 'all',
  shift: ShiftType = 'day',
): MonthlyTrendSummary {
  const targetDepartments =
    selectedDepartmentId === 'all'
      ? departments
      : departments.filter((d) => d.id === selectedDepartmentId);

  let totalPresent = 0;
  let totalAbsent = 0;
  let maxDailyCount = 1;

  const days: DailyTrendPoint[] = dates.map((dateStr) => {
    let present = 0;
    let absent = 0;

    for (const dept of targetDepartments) {
      const record = getRecordForDate(dept, dateStr, shift);
      for (const worker of dept.workers) {
        const mark = record.marks[worker.id];
        if (mark === 'present') present += 1;
        else if (mark === 'absent') absent += 1;
      }
    }

    totalPresent += present;
    totalAbsent += absent;
    if (present > maxDailyCount) maxDailyCount = present;
    if (absent > maxDailyCount) maxDailyCount = absent;

    const [y, m, d] = dateStr.split('-').map(Number);
    const dt = new Date(y, m - 1, d);
    const shortLabel = dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

    return {
      date: dateStr,
      shortLabel,
      dayNumber: String(d),
      present,
      absent,
    };
  });

  const byDepartment: DepartmentCycleTotal[] = departments.map((dept) => {
    let present = 0;
    let absent = 0;
    for (const dateStr of dates) {
      const record = getRecordForDate(dept, dateStr, shift);
      for (const worker of dept.workers) {
        const mark = record.marks[worker.id];
        if (mark === 'present') present += 1;
        else if (mark === 'absent') absent += 1;
      }
    }
    return {
      departmentId: dept.id,
      departmentName: dept.name,
      supervisor: dept.supervisor,
      present,
      absent,
    };
  });

  return {
    days,
    totalPresent,
    totalAbsent,
    maxDailyCount,
    byDepartment,
  };
}

export function filterWorkers(workers: Worker[], query: string): Worker[] {
  const normalized = query.trim().toLowerCase();
  if (!normalized) {
    return workers;
  }
  return workers.filter(
    (w) =>
      w.name.toLowerCase().includes(normalized) ||
      w.id.toLowerCase().includes(normalized) ||
      w.role.toLowerCase().includes(normalized),
  );
}

export interface BulkParseError {
  lineNumber: number;
  raw: string;
  reason: string;
}

export interface BulkParseResult {
  workers: Worker[];
  errors: BulkParseError[];
}

export function parseBulkWorkersText(text: string): BulkParseResult {
  const lines = text.split(/\r?\n/);
  const workers: Worker[] = [];
  const errors: BulkParseError[] = [];
  const seenIds = new Set<string>();

  lines.forEach((rawLine, index) => {
    const trimmed = rawLine.trim();
    if (!trimmed) {
      return;
    }

    // Support comma, tab, or pipe delimiters
    const delimiter = trimmed.includes('\t') ? '\t' : trimmed.includes('|') ? '|' : ',';
    const parts = trimmed.split(delimiter).map((p) => p.trim());

    // Skip an obvious header line like "ID, Name, Role"
    if (
      index === 0 &&
      parts.length >= 3 &&
      parts[0].toLowerCase().includes('id') &&
      parts[1].toLowerCase().includes('name')
    ) {
      return;
    }

    if (parts.length < 3) {
      errors.push({
        lineNumber: index + 1,
        raw: trimmed,
        reason: 'Expected 3 values: ID, Name, Role',
      });
      return;
    }

    const id = parts[0];
    const name = parts[1];
    const role = parts.slice(2).join(' ').trim();

    if (!id || !name || !role) {
      errors.push({
        lineNumber: index + 1,
        raw: trimmed,
        reason: 'ID, Name, and Role must all be non-empty',
      });
      return;
    }

    const normalizedKey = id.toLowerCase();
    if (seenIds.has(normalizedKey)) {
      errors.push({
        lineNumber: index + 1,
        raw: trimmed,
        reason: `Duplicate Worker ID "${id}" in input`,
      });
      return;
    }

    seenIds.add(normalizedKey);
    workers.push({ id, name, role });
  });

  return { workers, errors };
}

export function mergeWorkers(
  existing: Worker[],
  incoming: Worker[],
  mode: 'append' | 'replace',
): Worker[] {
  if (mode === 'replace') {
    return [...incoming];
  }

  const byId = new Map<string, number>();
  const result = existing.map((w, idx) => {
    byId.set(w.id.toLowerCase(), idx);
    return w;
  });

  for (const w of incoming) {
    const existingIdx = byId.get(w.id.toLowerCase());
    if (existingIdx !== undefined) {
      result[existingIdx] = w;
    } else {
      byId.set(w.id.toLowerCase(), result.length);
      result.push(w);
    }
  }

  return result;
}

export function toggleWorkerAttendance(
  department: Department,
  date: string,
  workerId: string,
  targetMark: AttendanceMark,
  shift: ShiftType = 'day',
): Department {
  const key = getAttendanceRecordKey(date, shift);
  const existingRecord = getRecordForDate(department, date, shift);
  const currentMark = existingRecord.marks[workerId];
  const nextMarks = { ...existingRecord.marks };

  if (currentMark === targetMark) {
    delete nextMarks[workerId];
  } else {
    nextMarks[workerId] = targetMark;
  }

  return {
    ...department,
    attendanceByDate: {
      ...department.attendanceByDate,
      [key]: {
        ...existingRecord,
        marks: nextMarks,
        submitted: false,
      },
    },
  };
}

export function submitDepartmentAttendance(
  department: Department,
  date: string,
  submittedAt: string = new Date().toISOString(),
  shift: ShiftType = 'day',
): Department {
  const key = getAttendanceRecordKey(date, shift);
  const existingRecord = getRecordForDate(department, date, shift);
  return {
    ...department,
    attendanceByDate: {
      ...department.attendanceByDate,
      [key]: {
        ...existingRecord,
        submitted: true,
        submittedAt,
      },
    },
  };
}

export function removeWorkerFromDepartment(
  department: Department,
  workerId: string,
): Department {
  const nextWorkers = department.workers.filter((w) => w.id !== workerId);
  const nextAttendanceByDate: Department['attendanceByDate'] = {};

  for (const [dateKey, record] of Object.entries(department.attendanceByDate)) {
    const nextMarks = { ...record.marks };
    delete nextMarks[workerId];
    nextAttendanceByDate[dateKey] = {
      ...record,
      marks: nextMarks,
    };
  }

  return {
    ...department,
    workers: nextWorkers,
    attendanceByDate: nextAttendanceByDate,
  };
}

function escapeCsvCell(value: string | number): string {
  const str = String(value);
  if (/[",\r\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function generateAttendanceCsv(
  department: Department,
  date: string,
  shift: ShiftType = 'day',
): string {
  const record = getRecordForDate(department, date, shift);
  const summary = computeDepartmentSummary(department, date, shift);

  const rows: (string | number)[][] = [
    ['Daily Attendance Register Report'],
    ['Department Name', department.name],
    ['Supervisor Name', department.supervisor],
    ['Date', date],
    ['Shift', formatShiftLabel(shift)],
    ['Session Status', summary.submitted ? 'Submitted' : 'Draft'],
    [],
    ['Summary Counts'],
    ['Total Workers', summary.total],
    ['Present (P)', summary.present],
    ['Absent (Ab)', summary.absent],
    ['Unmarked', summary.unmarked],
    [],
    ['Worker ID', 'Full Name', 'Role / Designation', 'Status'],
  ];

  for (const worker of department.workers) {
    const mark = record.marks[worker.id];
    const statusLabel = mark === 'present' ? 'Present' : mark === 'absent' ? 'Absent' : 'Unmarked';
    rows.push([worker.id, worker.name, worker.role, statusLabel]);
  }

  return rows.map((row) => row.map(escapeCsvCell).join(',')).join('\r\n');
}

export function slugifyFilename(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'department';
}
