import { useState, useEffect } from "react";
import { PaperThemeId, PaperNotebookConfig } from "../types";

export type { PaperThemeId, PaperNotebookConfig };

export interface PaperThemeDefinition {
  id: PaperThemeId;
  name: string;
  badge: string;
  description: string;
  bgColor: string;
  bgGradient: string;
  lineColor: string;
  marginLineColor: string;
  textColor: string;
  dateColor: string;
  caretColor: string;
  activeLineHighlight: string;
  previewClass: string;
}

export const PAPER_THEME_DEFINITIONS: Record<PaperThemeId, PaperThemeDefinition> = {
  yellow_parchment: {
    id: "yellow_parchment",
    name: "Sarı Parşömen (ColorNote)",
    badge: "Orijinal Defter",
    description: "ColorNote klasiği gözü yormayan sıcak sarı kağıt, yumuşak defter çizgileri ve kırmızı sol marj kılavuzu.",
    bgColor: "#FFF9C4",
    bgGradient: "linear-gradient(180deg, #FFFDE7 0%, #FFF9C4 100%)",
    lineColor: "rgba(180, 160, 50, 0.28)",
    marginLineColor: "rgba(220, 38, 38, 0.35)",
    textColor: "#282012",
    dateColor: "#8C7D52",
    caretColor: "#B45309",
    activeLineHighlight: "rgba(255, 235, 59, 0.22)",
    previewClass: "bg-[#FFF9C4] text-[#282012] border-[#E0D890]",
  },
  night_charcoal: {
    id: "night_charcoal",
    name: "Gece Modu Kömür",
    badge: "Koyu Odaklanma",
    description: "Karanlık ortamda sıfır göz yorgunluğu sağlayan mat kömür siyahı zemin, ince beyaz ışık çizgileri.",
    bgColor: "#18181B",
    bgGradient: "linear-gradient(180deg, #1C1C20 0%, #121214 100%)",
    lineColor: "rgba(255, 255, 255, 0.09)",
    marginLineColor: "rgba(239, 68, 68, 0.32)",
    textColor: "#F4F4F5",
    dateColor: "#A1A1AA",
    caretColor: "#38BDF8",
    activeLineHighlight: "rgba(255, 255, 255, 0.05)",
    previewClass: "bg-[#18181B] text-[#F4F4F5] border-[#27272A]",
  },
  pastel_green: {
    id: "pastel_green",
    name: "Pastel Yeşil",
    badge: "Ferah & Doğal",
    description: "Zihni dinlendiren narin yeşil parşömen, yaprak tonlu defter çizgileri ve ferah okuma ritmi.",
    bgColor: "#F1F8E9",
    bgGradient: "linear-gradient(180deg, #F9FBE7 0%, #EDF7E7 100%)",
    lineColor: "rgba(76, 175, 80, 0.25)",
    marginLineColor: "rgba(220, 38, 38, 0.3)",
    textColor: "#1B3B1E",
    dateColor: "#4E7C50",
    caretColor: "#15803D",
    activeLineHighlight: "rgba(76, 175, 80, 0.12)",
    previewClass: "bg-[#F1F8E9] text-[#1B3B1E] border-[#C8E6C9]",
  },
  classic_white: {
    id: "classic_white",
    name: "Klasik Beyaz",
    badge: "Okul & Ofis",
    description: "Geleneksel çizgili okul ve ofis defteri: Saf beyaz kağıt, ince açık mavi çizgiler ve kırmızı marj çizgisi.",
    bgColor: "#FFFFFF",
    bgGradient: "linear-gradient(180deg, #FFFFFF 0%, #FAFAFA 100%)",
    lineColor: "rgba(59, 130, 246, 0.22)",
    marginLineColor: "rgba(239, 68, 68, 0.35)",
    textColor: "#0F172A",
    dateColor: "#64748B",
    caretColor: "#2563EB",
    activeLineHighlight: "rgba(59, 130, 246, 0.08)",
    previewClass: "bg-white text-[#0F172A] border-slate-200",
  },
};

export const DEFAULT_PAPER_CONFIG: PaperNotebookConfig = {
  activeTheme: "yellow_parchment",
  fontSize: 17,          // 17sp (Ferah & Okunaklı)
  lineHeightRatio: 1.65, // 1.65x
  showRuledLines: true,
  showMarginLine: true,
  enableLineHighlight: true,
};

export const DEFAULT_PAPER_NOTEBOOK_CONFIG = DEFAULT_PAPER_CONFIG;

const STORAGE_KEY = "noteflow_paper_notebook_config_v1";

/**
 * Baseline Grid Alignment Mathematics
 * LineSpacing == TextLineHeight garantisi ile harflerin tam çizgi üzerine oturması.
 */
export function computeNotebookMetrics(
  baseFontSize: number = 17,
  typographyScaleMultiplier: number = 1.0,
  lineHeightRatio: number = 1.65,
  lineColor: string = "rgba(180, 160, 50, 0.28)",
  marginLineColor: string = "rgba(220, 38, 38, 0.35)",
  showMarginLine: boolean = true
) {
  // Clamped effective font size
  const fontSize = Math.max(12, Math.min(36, Math.round(baseFontSize * typographyScaleMultiplier)));
  // Integer pixel line height ensuring zero fractional pixel blur
  const lineHeight = Math.round(fontSize * lineHeightRatio);
  
  // Baseline offset calculation:
  // In western typography, the baseline sits ~76-78% down from the line-box top.
  const baselineOffset = Math.round(lineHeight * 0.78);

  // Ruled lines background generator
  // Creates a clean 1px horizontal line at every exact lineHeight interval
  const backgroundRules = `linear-gradient(to bottom, transparent ${lineHeight - 1}px, ${lineColor} ${lineHeight}px)`;

  // Red left margin rule generator (ColorNote classic 48px from left)
  const backgroundMargin = showMarginLine
    ? `linear-gradient(to right, transparent 48px, ${marginLineColor} 48px, ${marginLineColor} 50px, transparent 50px)`
    : "";

  return {
    fontSize,
    lineHeight,
    baselineOffset,
    backgroundRules,
    backgroundMargin,
    // Combined background image CSS
    backgroundImage: backgroundMargin ? `${backgroundMargin}, ${backgroundRules}` : backgroundRules,
    backgroundSize: backgroundMargin ? `100% 100%, 100% ${lineHeight}px` : `100% ${lineHeight}px`,
  };
}

export class PaperNotebookController {
  private static config: PaperNotebookConfig = PaperNotebookController.loadConfig();
  private static listeners: Set<(config: PaperNotebookConfig) => void> = new Set();

  private static loadConfig(): PaperNotebookConfig {
    if (typeof localStorage === "undefined") return { ...DEFAULT_PAPER_CONFIG };
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        return {
          ...DEFAULT_PAPER_CONFIG,
          ...parsed,
        };
      }
    } catch {}
    return { ...DEFAULT_PAPER_CONFIG };
  }

  public static getConfig(): PaperNotebookConfig {
    return { ...this.config };
  }

  public static setConfig(partial: Partial<PaperNotebookConfig>): void {
    this.config = {
      ...this.config,
      ...partial,
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.config));
    } catch {}
    this.listeners.forEach((fn) => fn(this.config));
  }

  public static setTheme(theme: PaperThemeId): void {
    this.setConfig({ activeTheme: theme });
  }

  public static setFontSize(size: number): void {
    this.setConfig({ fontSize: Math.max(13, Math.min(32, size)) });
  }

  public static setLineHeightRatio(ratio: number): void {
    this.setConfig({ lineHeightRatio: Math.max(1.4, Math.min(2.2, ratio)) });
  }

  public static toggleRuledLines(): void {
    this.setConfig({ showRuledLines: !this.config.showRuledLines });
  }

  public static toggleMarginLine(): void {
    this.setConfig({ showMarginLine: !this.config.showMarginLine });
  }

  public static resetToDefaults(): void {
    this.setConfig({ ...DEFAULT_PAPER_CONFIG });
  }

  public static subscribe(fn: (config: PaperNotebookConfig) => void): () => void {
    this.listeners.add(fn);
    fn(this.config);
    return () => {
      this.listeners.delete(fn);
    };
  }
}

export function usePaperNotebook() {
  const [config, setConfigState] = useState<PaperNotebookConfig>(() =>
    PaperNotebookController.getConfig()
  );

  useEffect(() => {
    return PaperNotebookController.subscribe((newCfg) => {
      setConfigState(newCfg);
    });
  }, []);

  const themeDef = PAPER_THEME_DEFINITIONS[config.activeTheme] || PAPER_THEME_DEFINITIONS.yellow_parchment;

  return {
    config,
    themeDef,
    setTheme: PaperNotebookController.setTheme.bind(PaperNotebookController),
    setFontSize: PaperNotebookController.setFontSize.bind(PaperNotebookController),
    setLineHeightRatio: PaperNotebookController.setLineHeightRatio.bind(PaperNotebookController),
    toggleRuledLines: PaperNotebookController.toggleRuledLines.bind(PaperNotebookController),
    toggleMarginLine: PaperNotebookController.toggleMarginLine.bind(PaperNotebookController),
    resetToDefaults: PaperNotebookController.resetToDefaults.bind(PaperNotebookController),
  };
}
