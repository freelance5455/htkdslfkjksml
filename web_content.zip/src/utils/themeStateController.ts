import { ReactNode, lazy, ComponentType } from "react";
import { NoteFlowThemeStyle, NoteFlowTokens, getNoteFlowTokens } from "./themeTokens";

/**
 * NoteFlow High-Performance Theme & Layout State Controller
 * Features:
 * 1. Selective Listener Subscriptions (Zero Global UI Re-render Overhead)
 * 2. Cross-Platform Storage Adapter (DataStore / Hive / LocalStorage)
 * 3. On-Demand Lazy Module Allocator (Memory Leak Prevention for Heavy Canvas / PKM Modules)
 */

export interface ThemeState {
  currentTheme: NoteFlowThemeStyle;
  tokens: NoteFlowTokens;
  activeLayout: string;
  isDarkMode: boolean;
}

type ThemeChangeListener = (state: ThemeState) => void;

class ThemeStateControllerImpl {
  private static STORAGE_KEY_THEME = "noteflow_pref_theme_style_v1";
  private static STORAGE_KEY_LAYOUT = "noteflow_pref_active_layout_v1";
  private static STORAGE_KEY_DARK_MODE = "noteflow_pref_dark_mode_v1";

  private listeners: Set<ThemeChangeListener> = new Set();
  private state: ThemeState;

  constructor() {
    const initialTheme = this.readStoredTheme();
    const initialLayout = this.readStoredLayout();
    const initialDarkMode = this.readStoredDarkMode();

    this.state = {
      currentTheme: initialTheme,
      tokens: getNoteFlowTokens(initialTheme),
      activeLayout: initialLayout,
      isDarkMode: initialDarkMode,
    };

    this.applyCssRootVariables(this.state.tokens, this.state.isDarkMode);
  }

  // Read State without re-render
  public getState(): ThemeState {
    return this.state;
  }

  public getTheme(): NoteFlowThemeStyle {
    return this.state.currentTheme;
  }

  // Fine-Grained Subscription (Prevents Global Application Re-renders)
  public subscribe(listener: ThemeChangeListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  // Switch Theme with zero-lag atomic update
  public setTheme(newTheme: NoteFlowThemeStyle): void {
    if (this.state.currentTheme === newTheme) return;

    const newTokens = getNoteFlowTokens(newTheme);
    this.state = {
      ...this.state,
      currentTheme: newTheme,
      tokens: newTokens,
    };

    // Apply tokens directly to document root variables for zero-JS render style recalculations
    this.applyCssRootVariables(newTokens, this.state.isDarkMode);

    // Persist to local storage driver (DataStore / Hive equivalent)
    this.persistTheme(newTheme);

    // Notify registered sub-tree listeners only
    this.notifyListeners();
  }

  // Switch Layout
  public setLayout(layout: string): void {
    if (this.state.activeLayout === layout) return;

    this.state = {
      ...this.state,
      activeLayout: layout,
    };

    this.persistLayout(layout);
    this.notifyListeners();
  }

  // Toggle Dark Mode
  public toggleDarkMode(): void {
    const nextMode = !this.state.isDarkMode;
    this.state = {
      ...this.state,
      isDarkMode: nextMode,
    };

    this.applyCssRootVariables(this.state.tokens, nextMode);
    this.persistDarkMode(nextMode);
    this.notifyListeners();
  }

  private notifyListeners(): void {
    this.listeners.forEach((listener) => listener(this.state));
  }

  // Inject CSS Root Variables for Hardware-Accelerated Instant Styling
  private applyCssRootVariables(tokens: NoteFlowTokens, isDark: boolean): void {
    if (typeof document === "undefined") return;

    const root = document.documentElement;
    root.style.setProperty("--color-primary", tokens.colors.primary);
    root.style.setProperty("--color-background", tokens.colors.background);
    root.style.setProperty("--color-surface", tokens.colors.surface);
    root.style.setProperty("--color-text-primary", tokens.colors.textPrimary);
    root.style.setProperty("--color-border", tokens.colors.border);
    root.style.setProperty("--font-family-base", tokens.typography.fontFamily);
    root.style.setProperty("--radius-medium", tokens.borderRadius.medium);

    if (isDark) {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }

  // Persistent Local Storage Driver
  private readStoredTheme(): NoteFlowThemeStyle {
    try {
      if (typeof localStorage !== "undefined") {
        const val = localStorage.getItem(ThemeStateControllerImpl.STORAGE_KEY_THEME);
        if (val && Object.values(NoteFlowThemeStyle).includes(val as NoteFlowThemeStyle)) {
          return val as NoteFlowThemeStyle;
        }
      }
    } catch (e) {
      console.warn("Storage driver read failed:", e);
    }
    return NoteFlowThemeStyle.Minimalist;
  }

  private readStoredLayout(): string {
    try {
      if (typeof localStorage !== "undefined") {
        return localStorage.getItem(ThemeStateControllerImpl.STORAGE_KEY_LAYOUT) || "grid";
      }
    } catch (e) {
      console.warn("Storage driver read failed:", e);
    }
    return "grid";
  }

  private readStoredDarkMode(): boolean {
    try {
      if (typeof localStorage !== "undefined") {
        return localStorage.getItem(ThemeStateControllerImpl.STORAGE_KEY_DARK_MODE) === "true";
      }
    } catch (e) {
      console.warn("Storage driver read failed:", e);
    }
    return true;
  }

  private persistTheme(theme: NoteFlowThemeStyle): void {
    try {
      if (typeof localStorage !== "undefined") {
        localStorage.setItem(ThemeStateControllerImpl.STORAGE_KEY_THEME, theme);
      }
    } catch (e) {
      console.warn("Storage driver persist failed:", e);
    }
  }

  private persistLayout(layout: string): void {
    try {
      if (typeof localStorage !== "undefined") {
        localStorage.setItem(ThemeStateControllerImpl.STORAGE_KEY_LAYOUT, layout);
      }
    } catch (e) {
      console.warn("Storage driver persist failed:", e);
    }
  }

  private persistDarkMode(isDark: boolean): void {
    try {
      if (typeof localStorage !== "undefined") {
        localStorage.setItem(ThemeStateControllerImpl.STORAGE_KEY_DARK_MODE, String(isDark));
      }
    } catch (e) {
      console.warn("Storage driver persist failed:", e);
    }
  }
}

export const ThemeStateController = new ThemeStateControllerImpl();

/**
 * Lazy Module Loader Strategy for Heavy Modules
 * Prevents memory allocation for Canvas-based MindMap & Enterprise PKM modules until requested.
 */
export function createLazyModule<T extends ComponentType<unknown>>(
  importFn: () => Promise<{ default: T }>
) {
  return lazy(importFn);
}
