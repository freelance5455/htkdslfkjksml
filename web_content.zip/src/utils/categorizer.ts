import { Note } from "../types";

export interface CategoryRule {
  name: string;
  keywords: string[];
  icon?: string;
  color?: string;
}

export const SMART_CATEGORY_RULES: CategoryRule[] = [
  {
    name: "Görev & Plan",
    keywords: [
      "yapılacak", "görev", "todo", "plan", "kontrol", "checklist", "deadline",
      "teslim", "yarın", "haftalık", "hedef", "takvim", "acil", "öncelikli",
      "program", "toplantı", "görüşme", "ajanda"
    ],
    color: "teal",
  },
  {
    name: "Finans & Alışveriş",
    keywords: [
      "fatura", "banka", "ödeme", "para", "tutar", "fiyat", "ücret", "iban",
      "kredi", "bütçe", "market", "alışveriş", "sipariş", "tl", "usd", "eur",
      "hesap", "gelir", "gider", "satın", "borç", "alacak", "vergi", "kira"
    ],
    color: "emerald",
  },
  {
    name: "Fikir & Proje",
    keywords: [
      "fikir", "proje", "tasarım", "konsept", "vizyon", "taslak", "brainstorm",
      "strateji", "ürün", "inovasyon", "girişim", "startup", "mimari", "model",
      "yol haritası", "roadmap", "araştırma"
    ],
    color: "amber",
  },
  {
    name: "Eğitim & Ders",
    keywords: [
      "ders", "sınav", "üniversite", "okul", "ödev", "kitap", "çalışma",
      "özet", "öğrenme", "kurs", "akademik", "soru", "cevap", "teori",
      "formül", "makale", "tez", "hafıza", "ezber", "flashcard"
    ],
    color: "blue",
  },
  {
    name: "Yazılım & Teknoloji",
    keywords: [
      "kod", "yazılım", "api", "sql", "react", "typescript", "python", "javascript",
      "function", "git", "bug", "hata", "database", "server", "docker", "cloud",
      "frontend", "backend", "npm", "json", "rest", "algoritma", "terminal"
    ],
    color: "purple",
  },
  {
    name: "Sağlık & Yaşam",
    keywords: [
      "sağlık", "doktor", "randevu", "ilaç", "diyet", "spor", "egzersiz",
      "beslenme", "reçete", "hastane", "tahlil", "vitamin", "antreman",
      "su", "kalori", "terapi", "nabız", "tansiyon"
    ],
    color: "rose",
  },
  {
    name: "Seyahat & Gezi",
    keywords: [
      "seyahat", "gezi", "bilet", "otel", "uçuş", "tatil", "rota", "valiz",
      "gezi planı", "rezervasyon", "pasaport", "vize", "konaklama", "tur", "harita"
    ],
    color: "ocean",
  },
  {
    name: "Belge & Arşiv",
    keywords: [
      "belge", "dosya", "yedek", "backup", "arşiv", "rapor", "sözleşme",
      "tutanak", "döküman", "colornote", "sqlite", "import", "pdf", "docx",
      "not dökümü", "resmi", "arşivlenmiş"
    ],
    color: "slate",
  },
  {
    name: "Kişisel & Günlük",
    keywords: [
      "günlük", "hatıra", "düşünce", "anı", "kişisel", "özel", "his", "duygu",
      "günce", "benim", "sevdiklerim", "hayat", "rüya", "deneyim"
    ],
    color: "teal",
  },
];

/**
 * Intelligent classifier that examines note title, content, tags, and tasks
 * to return the most accurate section/category name.
 */
export function classifyNoteCategory(
  title: string = "",
  content: string = "",
  tags: string[] = [],
  tasksCount: number = 0
): string {
  // If tasks exist and dominate, default to Görev & Plan
  if (tasksCount > 0 && tasksCount >= (content.length > 50 ? 2 : 1)) {
    return "Görev & Plan";
  }

  const normalized = `${title} ${content} ${(tags || []).join(" ")}`.toLowerCase();

  let bestMatchCategory = "Genel";
  let highestScore = 0;

  for (const rule of SMART_CATEGORY_RULES) {
    let score = 0;
    for (const kw of rule.keywords) {
      if (normalized.includes(kw)) {
        // Higher weight if matching in title or tags
        if (title.toLowerCase().includes(kw)) {
          score += 4;
        } else if ((tags || []).some((t) => t.toLowerCase().includes(kw))) {
          score += 3;
        } else {
          score += 1;
        }
      }
    }

    if (score > highestScore) {
      highestScore = score;
      bestMatchCategory = rule.name;
    }
  }

  // If minimal match, check content length & structure
  if (highestScore === 0) {
    if (tasksCount > 0) return "Görev & Plan";
    return "Kişisel & Günlük";
  }

  return bestMatchCategory;
}

/**
 * Automatically scans all notes, assigns appropriate categories based on content,
 * discovers newly needed categories, and eliminates unused empty categories.
 */
export function autoCategorizeNotes(
  currentNotes: Note[],
  forceReclassifyAll: boolean = false
): {
  updatedNotes: Note[];
  discoveredCategories: string[];
  reclassifiedCount: number;
} {
  let reclassifiedCount = 0;
  const discoveredSet = new Set<string>();

  const updatedNotes = currentNotes.map((note) => {
    // If note already has a specific user-defined custom category, keep it unless forceReclassify is on
    const hasCustomCat =
      note.category &&
      note.category !== "Tümü" &&
      note.category !== "Genel" &&
      !forceReclassifyAll;

    if (hasCustomCat) {
      discoveredSet.add(note.category);
      return note;
    }

    const suggested = classifyNoteCategory(
      note.title,
      note.content,
      note.tags,
      note.tasks?.length || 0
    );

    if (suggested !== note.category) {
      reclassifiedCount++;
    }

    discoveredSet.add(suggested);
    return {
      ...note,
      category: suggested,
    };
  });

  return {
    updatedNotes,
    discoveredCategories: Array.from(discoveredSet),
    reclassifiedCount,
  };
}

/**
 * Returns dynamic category list synchronized with current notes.
 * Automatically adds sections when notes of that type exist,
 * and prunes empty ones if no notes use them (except defaults).
 */
export function synchronizeCategories(
  existingCategories: string[],
  notes: Note[],
  alwaysKeepDefaults: string[] = [
    "Tümü",
    "Görev & Plan",
    "Kişisel & Günlük",
    "Fikir & Proje",
    "Eğitim & Ders",
    "Finans & Alışveriş"
  ]
): string[] {
  const activeInNotes = new Set(notes.map((n) => n.category).filter(Boolean));
  const result = new Set<string>();

  // Add "Tümü" first
  result.add("Tümü");

  // Add categories present in current notes
  activeInNotes.forEach((cat) => result.add(cat));

  // Add default core categories if not present
  alwaysKeepDefaults.forEach((cat) => result.add(cat));

  // Retain any custom category user explicitly added
  existingCategories.forEach((cat) => {
    if (activeInNotes.has(cat) || alwaysKeepDefaults.includes(cat)) {
      result.add(cat);
    }
  });

  return Array.from(result);
}

/**
 * AI-powered semantic auto-categorization for a single note.
 * Reads note context, tone, and implicit meaning using Gemini LLM.
 */
export async function autoCategorizeSingleNoteWithAI(
  note: { title?: string; content?: string; tasks?: any[]; tags?: string[]; category?: string },
  existingCategories: string[] = []
): Promise<{
  category: string;
  tags: string[];
  reason: string;
  confidence: number;
  isNewCategory: boolean;
}> {
  try {
    const res = await fetch("/api/gemini/semantic-categorize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: note.title || "",
        content: note.content || "",
        tasks: note.tasks || [],
        existingCategories: existingCategories.filter((c) => c !== "Tümü" && c !== "Genel"),
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data && data.category) {
        const existingTags = note.tags || [];
        const aiTags = Array.isArray(data.tags) ? data.tags : [];
        const combinedTags = Array.from(new Set([...existingTags, ...aiTags]));

        return {
          category: data.category,
          tags: combinedTags,
          reason: data.reason || "Yapay zeka semantik analizi ile kategorilendi.",
          confidence: data.confidence || 0.95,
          isNewCategory: Boolean(data.isNewCategory),
        };
      }
    }
  } catch (err) {
    console.warn("AI categorization request failed, using local fallback", err);
  }

  // Local fallback
  const localCat = classifyNoteCategory(note.title, note.content, note.tags, note.tasks?.length || 0);
  return {
    category: localCat,
    tags: note.tags && note.tags.length > 0 ? note.tags : ["#not", "#genel"],
    reason: "Kural tabanlı anlamsal eşleştirme yapıldı.",
    confidence: 0.8,
    isNewCategory: false,
  };
}

/**
 * AI-powered retroactive batch auto-categorization for multiple notes (e.g. ColorNote imports or full vault organizing).
 * Processes notes asynchronously and categorizes based on deep semantic reasoning.
 */
export async function batchCategorizeNotesWithAI(
  notes: Note[],
  existingCategories: string[] = [],
  onProgress?: (processed: number, total: number) => void
): Promise<{
  updatedNotes: Note[];
  discoveredCategories: string[];
  reclassifiedCount: number;
}> {
  if (notes.length === 0) {
    return { updatedNotes: [], discoveredCategories: [], reclassifiedCount: 0 };
  }

  const updatedNotesMap = new Map<string, Note>();
  notes.forEach((n) => updatedNotesMap.set(n.id, { ...n }));

  let reclassifiedCount = 0;
  const discoveredCategoriesSet = new Set<string>();
  const chunkSize = 25;
  const validCategories = existingCategories.filter((c) => c !== "Tümü");

  for (let i = 0; i < notes.length; i += chunkSize) {
    const chunk = notes.slice(i, i + chunkSize);

    try {
      const res = await fetch("/api/gemini/batch-categorize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          notes: chunk.map((n) => ({
            id: n.id,
            title: n.title,
            content: n.content,
            tasks: n.tasks,
          })),
          existingCategories: Array.from(new Set([...validCategories, ...discoveredCategoriesSet])),
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data && Array.isArray(data.results)) {
          data.results.forEach((item: any) => {
            const original = updatedNotesMap.get(item.id);
            if (original && item.category) {
              const oldCat = original.category;
              const newCat = item.category;
              const newTags = Array.from(new Set([...(original.tags || []), ...(item.tags || [])]));

              if (oldCat !== newCat) {
                reclassifiedCount++;
              }

              discoveredCategoriesSet.add(newCat);

              updatedNotesMap.set(item.id, {
                ...original,
                category: newCat,
                tags: newTags,
                aiCategorized: true,
                aiCategoryReason: item.reason || "Toplu semantik analiz ile atandı.",
                aiCategoryConfidence: 0.92,
                updatedAt: new Date().toISOString(),
              });
            }
          });
        }
      } else {
        throw new Error("Batch API response error");
      }
    } catch (err) {
      console.warn("Batch AI categorization chunk failed, falling back locally:", err);
      chunk.forEach((n) => {
        const localCat = classifyNoteCategory(n.title, n.content, n.tags, n.tasks?.length || 0);
        if (localCat !== n.category) reclassifiedCount++;
        discoveredCategoriesSet.add(localCat);
        updatedNotesMap.set(n.id, {
          ...updatedNotesMap.get(n.id)!,
          category: localCat,
          aiCategorized: true,
          aiCategoryReason: "Algoritmik anlamsal analiz",
          aiCategoryConfidence: 0.82,
        });
      });
    }

    if (onProgress) {
      onProgress(Math.min(i + chunkSize, notes.length), notes.length);
    }
  }

  const finalNotes = Array.from(updatedNotesMap.values());
  return {
    updatedNotes: finalNotes,
    discoveredCategories: Array.from(discoveredCategoriesSet),
    reclassifiedCount,
  };
}
