import { Card, Suit, CardRank, GamePlayer, PlayedCard, PlayerPosition } from '../types';

export const SUITS: Suit[] = ['spades', 'hearts', 'diamonds', 'clubs'];
export const SUIT_SYMBOLS: Record<Suit, string> = {
  spades: '♠',
  hearts: '♥',
  diamonds: '♦',
  clubs: '♣',
};

export const SUIT_ARABIC: Record<Suit, string> = {
  spades: 'بستوني',
  hearts: 'هاص',
  diamonds: 'ديناري',
  clubs: 'سباتي',
};

export const SUIT_COLORS: Record<Suit, string> = {
  spades: 'text-gray-100',
  hearts: 'text-red-500',
  diamonds: 'text-red-500',
  clubs: 'text-gray-100',
};

export const RANKS: CardRank[] = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

export const RANK_VALUES: Record<CardRank, number> = {
  '2': 2,
  '3': 3,
  '4': 4,
  '5': 5,
  '6': 6,
  '7': 7,
  '8': 8,
  '9': 9,
  '10': 10,
  'J': 11,
  'Q': 12,
  'K': 13,
  'A': 14,
};

/**
 * Exact TABEONA Bidding Value Lookup
 * 2 -> 2, 3 -> 3, 4 -> 4, 5 -> 5, 6 -> 6
 * 7 -> 14, 8 -> 16, 9 -> 18, 10 -> 20, 11 -> 22, 12 -> 24, 13 -> 26
 */
export const BID_POINTS_MAP: Record<number, number> = {
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 14,
  8: 16,
  9: 18,
  10: 20,
  11: 22,
  12: 24,
  13: 26,
};

export function getBidPoints(bid: number): number {
  return BID_POINTS_MAP[bid] ?? bid;
}

/**
 * Determines the minimum required bid based on a player's current score
 * Score >= 30: min bid is 3
 * Score >= 40: min bid is 4
 * Otherwise: min bid is 2
 */
export function getMinimumAllowedBid(currentScore: number): number {
  if (currentScore >= 40) return 4;
  if (currentScore >= 30) return 3;
  return 2;
}

/**
 * Generate standard 52 card deck
 */
export function createDeck(): Card[] {
  const deck: Card[] = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push({
        id: `${suit}-${rank}`,
        suit,
        rank,
        value: RANK_VALUES[rank],
      });
    }
  }
  return deck;
}

/**
 * Fisher-Yates deck shuffle
 */
export function shuffleDeck(deck: Card[]): Card[] {
  const shuffled = [...deck];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

/**
 * Sort hand by suit and rank for optimal display
 */
export function sortHand(cards: Card[]): Card[] {
  const suitOrder: Record<Suit, number> = {
    spades: 1,
    hearts: 2,
    clubs: 3,
    diamonds: 4,
  };

  return [...cards].sort((a, b) => {
    if (suitOrder[a.suit] !== suitOrder[b.suit]) {
      return suitOrder[a.suit] - suitOrder[b.suit];
    }
    return b.value - a.value;
  });
}

/**
 * Deal 13 cards to each of the 4 players
 */
export function dealCards(players: GamePlayer[]): { players: GamePlayer[]; dealtHands: Record<string, Card[]> } {
  const deck = shuffleDeck(createDeck());
  const dealtHands: Record<string, Card[]> = {};

  const updatedPlayers = players.map((player, idx) => {
    const hand = sortHand(deck.slice(idx * 13, (idx + 1) * 13));
    dealtHands[player.id] = hand;
    return {
      ...player,
      cardsCount: 13,
      cards: player.id === 'player_south' ? hand : undefined,
      tricksWonThisRound: 0,
      currentBid: undefined,
    };
  });

  return { players: updatedPlayers, dealtHands };
}

/**
 * Check whether a card is legal to play
 * Must follow suit if player holds any cards of led suit!
 */
export function isCardLegal(card: Card, hand: Card[], ledSuit: Suit | null): boolean {
  if (!ledSuit) return true; // First card of trick can be anything
  const hasLedSuit = hand.some((c) => c.suit === ledSuit);
  if (!hasLedSuit) return true; // If player doesn't have led suit, any card is valid
  return card.suit === ledSuit; // Must follow suit
}

/**
 * Determine trick winner
 * Rule:
 * - If any Tarneeb (trump) cards played, highest Tarneeb wins.
 * - Otherwise, highest card of the led suit wins.
 */
export function determineTrickWinner(
  playedCards: PlayedCard[],
  trumpSuit: Suit,
  ledSuit: Suit
): PlayedCard {
  const trumpCards = playedCards.filter((pc) => pc.card.suit === trumpSuit);

  if (trumpCards.length > 0) {
    // Highest trump wins
    return trumpCards.reduce((highest, current) =>
      current.card.value > highest.card.value ? current : highest
    );
  }

  // No trump played: highest of led suit wins
  const ledSuitCards = playedCards.filter((pc) => pc.card.suit === ledSuit);
  return ledSuitCards.reduce((highest, current) =>
    current.card.value > highest.card.value ? current : highest
  );
}

/**
 * AI Bot logic for selecting card to play
 */
export function pickBotCard(
  botHand: Card[],
  ledSuit: Suit | null,
  trumpSuit: Suit | null,
  currentTrick: PlayedCard[]
): Card {
  const legalCards = botHand.filter((c) => isCardLegal(c, botHand, ledSuit));

  if (legalCards.length === 1) {
    return legalCards[0];
  }

  // If leading
  if (!ledSuit) {
    // Try to lead high Ace or King if available, or low card
    const aces = legalCards.filter((c) => c.rank === 'A');
    if (aces.length > 0) return aces[0];
    return legalCards[Math.floor(Math.random() * legalCards.length)];
  }

  // If following suit
  const matchingSuit = legalCards.filter((c) => c.suit === ledSuit);
  if (matchingSuit.length > 0) {
    // Play lowest winning card or lowest card
    return matchingSuit[matchingSuit.length - 1];
  }

  // Can't follow suit: decide if we trump
  if (trumpSuit) {
    const trumps = legalCards.filter((c) => c.suit === trumpSuit);
    if (trumps.length > 0 && Math.random() > 0.3) {
      return trumps[trumps.length - 1]; // low trump
    }
  }

  // Discard lowest non-trump card
  return legalCards[legalCards.length - 1];
}

/**
 * AI Bot bidding calculation
 */
export function calculateBotBid(botHand: Card[], currentHighestBid: number, botScore: number): number | 'pass' {
  const minAllowed = getMinimumAllowedBid(botScore);

  // Count high cards and trump potentials
  let highPoints = 0;
  const suitCounts: Record<Suit, number> = { spades: 0, hearts: 0, diamonds: 0, clubs: 0 };

  botHand.forEach((c) => {
    suitCounts[c.suit]++;
    if (c.rank === 'A') highPoints += 4;
    else if (c.rank === 'K') highPoints += 3;
    else if (c.rank === 'Q') highPoints += 2;
    else if (c.rank === 'J') highPoints += 1;
  });

  const maxSuitLength = Math.max(...Object.values(suitCounts));
  const estimatedTricks = Math.floor(highPoints / 4) + (maxSuitLength >= 5 ? maxSuitLength - 2 : 0);

  const potentialBid = Math.max(minAllowed, Math.min(10, estimatedTricks));

  if (potentialBid > currentHighestBid) {
    return potentialBid;
  }

  return 'pass';
}

/**
 * Win condition at 41 check
 * Requirement:
 * - A player reaches >= 41
 * - Player only wins IF their partner's score is >= 0!
 *   If partner's score < 0: ❌ DOES NOT WIN.
 */
export function checkTarneebVictory(scores: {
  bottom: number;
  top: number;
  left: number;
  right: number;
}): { hasWinner: boolean; winnerTeam?: 1 | 2; winnerPlayers?: string[]; reason?: string } {
  // Team 1: bottom (you) + top (partner)
  // Team 2: left + right

  const bottomReached = scores.bottom >= 41;
  const topReached = scores.top >= 41;
  const leftReached = scores.left >= 41;
  const rightReached = scores.right >= 41;

  // Check Team 1 (Bottom + Top)
  if (bottomReached || topReached) {
    // Both must not be below 0
    if (scores.bottom >= 41 && scores.top < 0) {
      return {
        hasWinner: false,
        reason: 'اللاعب وصل 41 ولكن شريكه تحت الصفر، يستمر اللعب!',
      };
    }
    if (scores.top >= 41 && scores.bottom < 0) {
      return {
        hasWinner: false,
        reason: 'الشريك وصل 41 ولكن اللاعب تحت الصفر، يستمر اللعب!',
      };
    }
    return {
      hasWinner: true,
      winnerTeam: 1,
      winnerPlayers: ['Player 1', 'أحمد'],
      reason: 'فوز الفريق الأول بعد تخطي 41 نقطة وشريكه فوق الصفر!',
    };
  }

  // Check Team 2 (Left + Right)
  if (leftReached || rightReached) {
    if (scores.left >= 41 && scores.right < 0) {
      return {
        hasWinner: false,
        reason: 'الخصم وصل 41 ولكن شريكه تحت الصفر، يستمر اللعب!',
      };
    }
    if (scores.right >= 41 && scores.left < 0) {
      return {
        hasWinner: false,
        reason: 'الخصم وصل 41 ولكن شريكه تحت الصفر، يستمر اللعب!',
      };
    }
    return {
      hasWinner: true,
      winnerTeam: 2,
      winnerPlayers: ['سامي', 'ليلى'],
      reason: 'فوز الفريق الخصم بعد تخطي 41 نقطة!',
    };
  }

  return { hasWinner: false };
}
