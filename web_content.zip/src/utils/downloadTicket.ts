import { PurchasedTicket } from '../types';

export const downloadTicketPass = (ticket: PurchasedTicket) => {
  const canvas = document.createElement('canvas');
  canvas.width = 800;
  canvas.height = 1050;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Background
  ctx.fillStyle = '#090a0d';
  ctx.fillRect(0, 0, 800, 1050);

  // Card Container
  ctx.fillStyle = '#111317';
  ctx.beginPath();
  ctx.roundRect(40, 40, 720, 970, 32);
  ctx.fill();

  // Border outline
  ctx.strokeStyle = '#1f2229';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Top header banner
  ctx.fillStyle = '#17191f';
  ctx.fillRect(40, 40, 720, 170);

  // Brand text
  ctx.fillStyle = '#10b981';
  ctx.font = 'bold 20px system-ui, -apple-system, sans-serif';
  ctx.fillText('EVENTRA · OFFICIAL ADMISSION PASS', 70, 85);

  ctx.fillStyle = '#f4f4f6';
  ctx.font = 'bold 28px system-ui, -apple-system, sans-serif';
  const truncatedTitle = ticket.eventTitle.length > 32 ? ticket.eventTitle.slice(0, 32) + '...' : ticket.eventTitle;
  ctx.fillText(truncatedTitle, 70, 135);

  ctx.fillStyle = '#9496a1';
  ctx.font = '15px system-ui, -apple-system, sans-serif';
  ctx.fillText(`${ticket.venue} · ${ticket.city}, Kenya`, 70, 175);

  // Ticket details body
  ctx.fillStyle = '#646875';
  ctx.font = 'bold 12px system-ui, -apple-system, sans-serif';
  ctx.fillText('PASSHOLDER', 70, 255);
  ctx.fillText('DATE & TIME', 450, 255);

  ctx.fillStyle = '#f4f4f6';
  ctx.font = 'bold 18px system-ui, -apple-system, sans-serif';
  ctx.fillText(ticket.holderName, 70, 290);
  ctx.fillText(`${ticket.date.split(',')[1] || ticket.date} · ${ticket.time}`, 450, 290);

  ctx.fillStyle = '#646875';
  ctx.font = 'bold 12px system-ui, -apple-system, sans-serif';
  ctx.fillText('ADMISSION TIER', 70, 345);
  ctx.fillText('TOTAL PAID (KES)', 450, 345);

  ctx.fillStyle = '#f4f4f6';
  ctx.font = 'bold 18px system-ui, -apple-system, sans-serif';
  ctx.fillText(`${ticket.groupTierName || (ticket.ticketType === 'group' ? 'Group Pass' : 'Personal Ticket')} (${ticket.quantity} Guest${ticket.quantity > 1 ? 's' : ''})`, 70, 380);
  ctx.fillStyle = '#10b981';
  ctx.fillText(`KSh ${ticket.totalPaid.toLocaleString()}`, 450, 380);

  ctx.fillStyle = '#646875';
  ctx.font = 'bold 12px system-ui, -apple-system, sans-serif';
  ctx.fillText('ORDER NUMBER', 70, 435);
  ctx.fillText('TRANSACTION REF', 450, 435);

  ctx.fillStyle = '#9496a1';
  ctx.font = 'bold 15px monospace';
  ctx.fillText(ticket.orderNumber, 70, 465);
  ctx.fillText(ticket.transactionRef, 450, 465);

  // Perforated line
  ctx.setLineDash([8, 8]);
  ctx.strokeStyle = '#1f2229';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(40, 515);
  ctx.lineTo(760, 515);
  ctx.stroke();
  ctx.setLineDash([]);

  // Notches
  ctx.fillStyle = '#090a0d';
  ctx.beginPath();
  ctx.arc(40, 515, 24, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(760, 515, 24, 0, Math.PI * 2);
  ctx.fill();

  // Manual Gate Verification Showcase Box
  ctx.fillStyle = '#17191f';
  ctx.beginPath();
  ctx.roundRect(80, 560, 640, 280, 20);
  ctx.fill();

  ctx.strokeStyle = '#10b981';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Badge inside box
  ctx.fillStyle = '#10b981';
  ctx.font = 'bold 13px system-ui, -apple-system, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('MANUAL TURNSTILE GATE ADMISSION', 400, 605);

  ctx.fillStyle = '#9496a1';
  ctx.font = '14px system-ui, -apple-system, sans-serif';
  ctx.fillText('Present this distinct verification code to the venue steward for manual entry:', 400, 635);

  // Large Distinct Code
  ctx.fillStyle = '#090a0d';
  ctx.beginPath();
  ctx.roundRect(140, 665, 520, 90, 16);
  ctx.fill();

  ctx.fillStyle = '#10b981';
  ctx.font = 'bold 36px monospace';
  ctx.fillText(ticket.ticketCode, 400, 725);

  ctx.fillStyle = '#646875';
  ctx.font = '12px system-ui, -apple-system, sans-serif';
  ctx.fillText('Cryptographic Verification Hash: ' + (ticket.ticketCode + '-' + ticket.orderNumber).slice(0, 24), 400, 800);

  // Footer text
  ctx.fillStyle = '#646875';
  ctx.font = '13px system-ui, -apple-system, sans-serif';
  ctx.fillText('Show at turnstile gate to authorized event steward for check-in.', 400, 895);
  ctx.fillText(`Direct Host Line: ${ticket.hostMpesa} · Eventra Cloud Synced Pass`, 400, 925);
  ctx.textAlign = 'left';

  // Trigger download
  const image = canvas.toDataURL('image/png');
  const a = document.createElement('a');
  a.download = `Eventra-Pass-${ticket.ticketCode || ticket.orderNumber}.png`;
  a.href = image;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
};

export const printTicketPass = (ticket: PurchasedTicket) => {
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (!doc) return;

  doc.open();
  doc.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Eventra Pass - ${ticket.ticketCode}</title>
        <style>
          @page { size: auto; margin: 15mm; }
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; margin: 0; padding: 20px; color: #111827; }
          .ticket-card { max-width: 650px; margin: 0 auto; border: 2px solid #111827; border-radius: 24px; padding: 32px; background: #ffffff; }
          .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #e5e7eb; padding-bottom: 20px; }
          .brand { font-size: 18px; font-weight: 800; color: #10b981; letter-spacing: -0.5px; }
          .title { font-size: 24px; font-weight: 800; margin-top: 6px; }
          .venue { font-size: 14px; color: #6b7280; margin-top: 4px; }
          .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 24px 0; }
          .label { font-size: 11px; text-transform: uppercase; font-weight: 700; color: #9ca3af; }
          .val { font-size: 16px; font-weight: 700; color: #1f2937; margin-top: 2px; }
          .manual-box { background: #f9fafb; border: 2px solid #10b981; border-radius: 16px; padding: 20px; text-align: center; margin: 20px 0; }
          .manual-label { font-size: 11px; font-weight: 800; color: #10b981; text-transform: uppercase; letter-spacing: 1px; }
          .code-box { font-family: monospace; font-size: 28px; font-weight: 900; color: #111827; margin: 8px 0; letter-spacing: 2px; }
          .manual-sub { font-size: 12px; color: #6b7280; }
          .footer { border-top: 2px dashed #cbd5e1; padding-top: 20px; text-align: center; font-size: 12px; color: #6b7280; }
        </style>
      </head>
      <body>
        <div class="ticket-card">
          <div class="header">
            <div>
              <div class="brand">EVENTRA · OFFICIAL ADMISSION PASS</div>
              <div class="title">${ticket.eventTitle}</div>
              <div class="venue">${ticket.venue} &middot; ${ticket.city}, Kenya</div>
            </div>
          </div>
          <div class="grid">
            <div>
              <div class="label">Passholder Name</div>
              <div class="val">${ticket.holderName}</div>
            </div>
            <div>
              <div class="label">Date & Showtime</div>
              <div class="val">${ticket.date.split(',')[1] || ticket.date} &middot; ${ticket.time}</div>
            </div>
            <div>
              <div class="label">Admission Category</div>
              <div class="val">${ticket.groupTierName || (ticket.ticketType === 'group' ? 'Group Pass' : 'Personal Ticket')} (${ticket.quantity} Guests)</div>
            </div>
            <div>
              <div class="label">Total Amount Paid</div>
              <div class="val" style="color: #10b981;">KSh ${ticket.totalPaid.toLocaleString()} (Verified)</div>
            </div>
            <div>
              <div class="label">Order Number</div>
              <div class="val" style="font-family: monospace;">${ticket.orderNumber}</div>
            </div>
            <div>
              <div class="label">Transaction Ref</div>
              <div class="val" style="font-family: monospace;">${ticket.transactionRef}</div>
            </div>
          </div>

          <div class="manual-box">
            <div class="manual-label">Manual Turnstile Gate Admission</div>
            <div class="code-box">${ticket.ticketCode}</div>
            <div class="manual-sub">Present this distinct code to the gate steward for manual admission.</div>
          </div>

          <div class="footer">
            <div>Authorized event steward verifies this distinct code against the central Eventra cloud system.</div>
            <div style="margin-top: 4px; font-size: 11px;">Host Line: ${ticket.hostMpesa} &middot; Verified Digital Pass</div>
          </div>
        </div>
      </body>
    </html>
  `);
  doc.close();

  setTimeout(() => {
    iframe.contentWindow?.focus();
    iframe.contentWindow?.print();
    setTimeout(() => {
      document.body.removeChild(iframe);
    }, 1500);
  }, 400);
};
