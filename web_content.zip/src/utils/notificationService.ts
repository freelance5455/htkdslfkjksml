import { Customer } from '../types';
import { alarmAudio } from './audioAlarm';

export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }

  if (Notification.permission === 'granted') {
    return 'granted';
  }

  try {
    const result = await Notification.requestPermission();
    return result;
  } catch (err) {
    console.warn('Failed to request notification permission:', err);
    return 'denied';
  }
}

export function getNotificationPermissionStatus(): NotificationPermission {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  return Notification.permission;
}

export async function sendCustomerReminderNotification(customer: Customer, isOverdue = false): Promise<boolean> {
  alarmAudio.playUrgentAlarm();

  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }

  if (Notification.permission !== 'granted') {
    return false;
  }

  const title = isOverdue
    ? `⚠️ गैस रिमाइंडर: ${customer.name} (समय बीत चुका)`
    : `🔔 26वां दिन रिमाइंडर: ${customer.name}`;

  const body = `ग्राहक: ${customer.name}\nमोबाइल: ${customer.phone}\nपता: ${customer.address}\nसिलेंडर रिफिल/पुष्टि का 26वां दिन (9:00 AM)`;

  try {
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.ready;
      if (reg && reg.showNotification) {
        await reg.showNotification(title, {
          body,
          icon: '/pwa-192x192.png',
          badge: '/pwa-192x192.png',
          tag: `customer-${customer.id}-${Date.now()}`,
          data: {
            customerId: customer.id,
            phone: customer.phone,
            url: window.location.href,
          },
        } as NotificationOptions);
        return true;
      }
    }

    // Fallback standard Notification
    new Notification(title, {
      body,
      icon: '/pwa-192x192.png',
      tag: `customer-${customer.id}`,
    });
    return true;
  } catch (err) {
    console.error('Error dispatching notification:', err);
    return false;
  }
}
