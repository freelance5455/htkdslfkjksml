// Daily Reminder Notification Service for Hisn Al-Muslim (In-App & System Notifications)
import { InAppNotification } from '../types';

export interface NotificationStatus {
  supported: boolean;
  permission: NotificationPermission | 'unsupported';
}

export interface NextReminderInfo {
  category: 'morning' | 'evening';
  title: string;
  timeFormatted: string;
  diffMinutes: number;
  timeText: string;
}

export function getNotificationStatus(): NotificationStatus {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return { supported: false, permission: 'unsupported' };
  }
  return { supported: true, permission: Notification.permission };
}

export async function requestNotificationPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  try {
    const result = await Notification.requestPermission();
    return result;
  } catch {
    return 'denied';
  }
}

export function sendLocalNotification(title: string, body: string, tag?: string): boolean {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }

  if (Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: '/favicon.ico',
        tag: tag || 'hisn-reminder',
        dir: 'rtl',
        lang: 'ar',
      });
      return true;
    } catch {
      // In some mobile browsers Notification constructor requires service worker
      return false;
    }
  }
  return false;
}

/**
 * Formats a 24-hour time string ("06:30" or "17:30") to friendly Arabic ("06:30 ص" or "05:30 م")
 */
export function formatArabicTimeString(timeStr: string): string {
  if (!timeStr || !timeStr.includes(':')) return timeStr;
  const [hStr, mStr] = timeStr.split(':');
  let h = parseInt(hStr, 10);
  const m = parseInt(mStr, 10);
  if (isNaN(h) || isNaN(m)) return timeStr;

  const isPM = h >= 12;
  const h12 = h % 12 || 12;
  const mPad = m < 10 ? `0${m}` : `${m}`;
  return `${h12}:${mPad} ${isPM ? 'م' : 'ص'}`;
}

/**
 * Calculates the next upcoming reminder and time remaining
 */
export function getNextReminderInfo(
  morningEnabled: boolean,
  morningTime: string,
  eveningEnabled: boolean,
  eveningTime: string
): NextReminderInfo | null {
  if (!morningEnabled && !eveningEnabled) return null;

  const now = new Date();
  const nowMinutes = now.getHours() * 60 + now.getMinutes();

  const parseToMinutes = (tStr: string) => {
    const [h, m] = tStr.split(':').map(Number);
    return (h || 0) * 60 + (m || 0);
  };

  const candidates: { category: 'morning' | 'evening'; minutes: number; timeStr: string }[] = [];

  if (morningEnabled && morningTime) {
    candidates.push({ category: 'morning', minutes: parseToMinutes(morningTime), timeStr: morningTime });
  }
  if (eveningEnabled && eveningTime) {
    candidates.push({ category: 'evening', minutes: parseToMinutes(eveningTime), timeStr: eveningTime });
  }

  if (candidates.length === 0) return null;

  let bestCandidate = candidates[0];
  let minDiff = 24 * 60 + 1;

  for (const cand of candidates) {
    let diff = cand.minutes - nowMinutes;
    if (diff <= 0) {
      diff += 24 * 60; // Next day
    }
    if (diff < minDiff) {
      minDiff = diff;
      bestCandidate = cand;
    }
  }

  const hoursRemaining = Math.floor(minDiff / 60);
  const minutesRemaining = minDiff % 60;

  let timeText = '';
  if (hoursRemaining > 0 && minutesRemaining > 0) {
    timeText = `متبقي ${hoursRemaining} ساعة و${minutesRemaining} دقيقة`;
  } else if (hoursRemaining > 0) {
    timeText = `متبقي ${hoursRemaining} ساعة`;
  } else if (minutesRemaining > 0) {
    timeText = `متبقي ${minutesRemaining} دقيقة`;
  } else {
    timeText = 'الآن';
  }

  return {
    category: bestCandidate.category,
    title: bestCandidate.category === 'morning' ? 'أذكار الصباح المباركة ☀️' : 'أذكار المساء الهادئة 🌙',
    timeFormatted: formatArabicTimeString(bestCandidate.timeStr),
    diffMinutes: minDiff,
    timeText,
  };
}

/**
 * Checks scheduled reminders and triggers both In-App alert callback and browser notification
 */
export function checkAndTriggerScheduledReminders(
  morningEnabled: boolean,
  morningTime: string,
  eveningEnabled: boolean,
  eveningTime: string,
  onTriggerInApp?: (notification: InAppNotification) => void
): void {
  if (typeof window === 'undefined') return;

  const now = new Date();
  const currentHours = String(now.getHours()).padStart(2, '0');
  const currentMinutes = String(now.getMinutes()).padStart(2, '0');
  const currentTimeStr = `${currentHours}:${currentMinutes}`;
  const todayDateStr = now.toISOString().slice(0, 10); // YYYY-MM-DD

  // Morning check
  if (morningEnabled && currentTimeStr === morningTime) {
    const morningKey = `hisn_morning_sent_${todayDateStr}`;
    if (!localStorage.getItem(morningKey)) {
      localStorage.setItem(morningKey, 'true');

      const morningNotification: InAppNotification = {
        id: `morning-${Date.now()}`,
        title: 'حان وقت أذكار الصباح المباركة ☀️',
        body: 'أصبحنا وأصبح الملك لله والحمد لله.. ابدأ يومك ببركة الذكر وحصن نفسك.',
        category: 'morning',
        time: currentTimeStr,
        timestamp: Date.now(),
        read: false,
      };

      if (onTriggerInApp) {
        onTriggerInApp(morningNotification);
      }

      sendLocalNotification(
        'حصن المسلم ☀️ أذكار الصباح',
        'أصبحنا وأصبح الملك لله.. حان وقت أذكار الصباح المباركة لتحصين نفسك وبيتك.',
        'hisn-morning'
      );
    }
  }

  // Evening check
  if (eveningEnabled && currentTimeStr === eveningTime) {
    const eveningKey = `hisn_evening_sent_${todayDateStr}`;
    if (!localStorage.getItem(eveningKey)) {
      localStorage.setItem(eveningKey, 'true');

      const eveningNotification: InAppNotification = {
        id: `evening-${Date.now()}`,
        title: 'حان وقت أذكار المساء الهادئة 🌙',
        body: 'أمسينا وأمسى الملك لله والحمد لله.. اختم يومك بسكينة القلب وحفظ النفس.',
        category: 'evening',
        time: currentTimeStr,
        timestamp: Date.now(),
        read: false,
      };

      if (onTriggerInApp) {
        onTriggerInApp(eveningNotification);
      }

      sendLocalNotification(
        'حصن المسلم 🌙 أذكار المساء',
        'أمسينا وأمسى الملك لله.. حان وقت أذكار المساء لسكينة القلب وحفظ النفس.',
        'hisn-evening'
      );
    }
  }
}
