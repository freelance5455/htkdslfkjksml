import { TutorPersonaId, TeachingMode, AcademicLevel, TUTOR_PERSONAS } from './tutor-prompts';
import { QuizQuestion, Flashcard } from './quiz-state';

export function generateEducationalResponse(
  query: string,
  personaId: TutorPersonaId,
  mode: TeachingMode,
  level: AcademicLevel
): string {
  const q = query.toLowerCase();
  const persona = TUTOR_PERSONAS[personaId] || TUTOR_PERSONAS.general;

  // Quantum entanglement
  if (q.includes('quantum') || q.includes('entangle')) {
    if (mode === 'socratic') {
      return `### 🌌 Exploring Quantum Entanglement Together

Imagine you and a best friend each have a mysterious closed box with a magic coin inside.

Before we open the boxes:
1. The coins are spinning continuously — neither strictly **Heads** nor **Tails**.
2. When you open your box in Tokyo and observe **Heads**, your friend's box in New York instantaneously becomes **Tails**!

> **Ponder this milestone question:**
> Does the coin choose its state *before* it leaves the factory, or does your observation in Tokyo instantly determine what your friend sees?

What do you think? Reply with your intuition!`;
    }

    return `### 🌌 Quantum Entanglement Explained Simply

Imagine you have a pair of special socks — one **Blue** and one **Red** — placed into two identical sealed boxes without looking:

1. **The Classical Picture:**
   Before you open a box, the sock is already definitely blue or definitely red. You just didn't know which one yet.

2. **The Quantum Reality:**
   In the quantum realm, until you observe them, particles exist in a **superposition of states**:
   $$\\lvert \\psi \\rangle = \\frac{1}{\\sqrt{2}} (\\lvert 01 \\rangle + \\lvert 10 \\rangle)$$
   Neither particle has a fixed property until measured.

3. **Instantaneous Correlation:**
   The exact instant you observe particle A to be state $\\lvert 0 \\rangle$, particle B *instantaneously* becomes state $\\lvert 1 \\rangle$, regardless of whether they are 1 centimeter or 1,000 light-years apart!

> **Key Takeaway:** Albert Einstein famously called this *"spooky action at a distance."* Modern experiments (which won the 2022 Nobel Prize in Physics) proved that the universe really is non-local at the quantum scale!

**Quick Check:** Would you like to explore how this is used in quantum cryptography, or test your understanding with a practice question?`;
  }

  // Quadratic equations or math
  if (q.includes('quadratic') || q.includes('square') || q.includes('equation') || personaId === 'math') {
    if (mode === 'socratic') {
      return `### 📐 Let's Solve It Step-by-Step

Let's look at the standard quadratic form:
$$ax^2 + bx + c = 0$$

When completing the square, our goal is to rewrite the expression into:
$$(x + d)^2 = k$$

> **Step 1 Hint for you:**
> If we have $x^2 + 6x = 7$, what number must we add to both sides so that the left side becomes a perfect square $(x + 3)^2$?
>
> *(Hint: Take half of the coefficient of $x$, then square it!)*

What is that number? Give it a try!`;
    }

    return `### 📐 Solving Quadratic Equations by Completing the Square

Here is the structured breakdown for solving any quadratic equation $ax^2 + bx + c = 0$:

#### 1. Standardize the Equation
Divide by $a$ if $a \\neq 1$, and move the constant term to the right side:
$$x^2 + \\frac{b}{a}x = -\\frac{c}{a}$$

#### 2. Complete the Square
Take half of the $x$-coefficient and square it:
$$\\text{Term to add} = \\left( \\frac{b}{2a} \\right)^2 = \\frac{b^2}{4a^2}$$

Add this value to **both sides** of the equality:
$$x^2 + \\frac{b}{a}x + \\frac{b^2}{4a^2} = \\frac{b^2 - 4ac}{4a^2}$$

#### 3. Factor and Take Square Root
The left side collapses neatly into a binomial square:
$$\\left(x + \\frac{b}{2a}\\right)^2 = \\frac{b^2 - 4ac}{4a^2}$$

Taking the square root on both sides reveals the famous **Quadratic Formula**:
$$x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$$

**Takeaway:** Completing the square is actually the mathematical proof from which the quadratic formula is derived!`;
  }

  // Computer Science / Async JS
  if (q.includes('async') || q.includes('javascript') || q.includes('sync') || personaId === 'code') {
    return `### 💻 Synchronous vs. Asynchronous JavaScript

Understanding how JavaScript executes code is fundamental to writing responsive applications.

#### 1. Synchronous Execution (Blocking)
JavaScript is single-threaded. In synchronous code, tasks run line-by-line sequentially:
\`\`\`javascript
console.log("Step 1: Boiled water");
// If this loop takes 5 seconds, the browser freezes completely!
for (let i = 0; i < 1e9; i++) {}
console.log("Step 2: Made coffee");
\`\`\`

#### 2. Asynchronous Execution (Non-Blocking)
Time-consuming operations (network requests, timers, disk I/O) are offloaded to Web APIs:
\`\`\`typescript
console.log("1. Placed coffee order");

// Offloaded to event loop / background
setTimeout(() => {
  console.log("3. Coffee is ready! (Async callback)");
}, 1000);

console.log("2. Sat down and continued studying");
\`\`\`

**Output order:**
1. \`1. Placed coffee order\`
2. \`2. Sat down and continued studying\`
3. \`3. Coffee is ready! (Async callback)\`

> **Mental Model:** Synchronous is like standing at the counter waiting for your sandwich before anyone else can order. Asynchronous is taking a buzzer, sitting at your table, and picking up your sandwich when it buzzes!`;
  }

  // Default encouraging explanation
  return `### 🎓 Conceptual Breakdown: ${query}

Let's break this down into clear, digestible learning points tailored for **${persona.name}** at the **${level}** level.

1. **The Core Concept:**
   At its foundation, understanding this requires looking at the governing principles rather than memorizing isolated rules.

2. **Step-by-Step Logic:**
   - First, identify the given parameters and core relationships.
   - Second, apply the fundamental formula or framework.
   - Third, verify the edge cases or boundary conditions.

3. **Practical Application:**
   In real-world problem solving, master practitioners look for invariant properties that remain constant across changes.

> **Tutor Guidance:** What specific part of this problem feels most challenging? We can dive into an analogy, work through a concrete calculation, or take a practice quiz!`;
}

export function generateFallbackQuiz(topic: string): QuizQuestion[] {
  return [
    {
      id: 'fb1',
      question: `What is the foundational principle underlying "${topic}"?`,
      options: [
        'Conservation and equilibrium in state transformations',
        'Independent arbitrary variance without constraint',
        'Static non-interactive isolation',
        'Inverse proportional degradation only',
      ],
      correctOptionIndex: 0,
      explanation: 'Core scientific and analytical frameworks rely on conservation laws, balance, and structured state transformations.',
      hint: 'Think about balance and conservation.',
    },
    {
      id: 'fb2',
      question: `When analyzing problem scenarios in ${topic}, what is the recommended first step?`,
      options: [
        'Jump straight to final calculations without diagramming',
        'Identify knowns, unknowns, and governing boundary conditions',
        'Assume all variables are equal to zero',
        'Disregard dimensional units',
      ],
      correctOptionIndex: 1,
      explanation: 'Establishing known variables, target unknowns, and constraints prevents procedural errors.',
      hint: 'Always establish what you know and what you are solving for.',
    },
  ];
}
