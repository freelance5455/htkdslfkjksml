/**
 * Background Keep-Alive and Screen WakeLock manager
 * Provides continuous background audio processing, WakeLock, and MediaSession persistence
 * so that reminders work uninterrupted even when the screen is locked on Android devices.
 */

class BackgroundKeepAliveService {
  private silentAudio: HTMLAudioElement | null = null;
  private wakeLock: any = null;
  private isKeepAliveActive: boolean = false;
  private audioContext: AudioContext | null = null;

  constructor() {
    this.handleVisibilityChange = this.handleVisibilityChange.bind(this);
  }

  /**
   * Initializes a minimal 1-second silent MP3 loop and audio context.
   * On mobile Android Chrome, looping silent audio tells the Android OS
   * audio server (AudioFlinger / MediaSession) that the app has an active playback,
   * preventing the OS battery optimizer from suspending the JavaScript timers when the screen turns off.
   */
  public startKeepAlive() {
    if (this.isKeepAliveActive) return;
    this.isKeepAliveActive = true;

    try {
      if (!this.silentAudio) {
        // Base64 of a minimal silent 1-second WAV audio
        const silentWavBase64 =
          'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA';
        const audio = new Audio(silentWavBase64);
        audio.loop = true;
        audio.volume = 0.01; // virtually silent
        this.silentAudio = audio;
      }

      const playPromise = this.silentAudio.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {
          // Autoplay policy may hold until user interaction
        });
      }
    } catch (e) {
      console.warn('Silent keepalive audio error:', e);
    }

    // Request Screen Wake Lock if supported and allowed
    this.requestWakeLock();

    // Listen for visibility change to re-request WakeLock when screen turns back on
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', this.handleVisibilityChange);
    }
  }

  public stopKeepAlive() {
    this.isKeepAliveActive = false;

    if (this.silentAudio) {
      try {
        this.silentAudio.pause();
        this.silentAudio.currentTime = 0;
      } catch (e) {
        // ignore
      }
    }

    this.releaseWakeLock();

    if (typeof document !== 'undefined') {
      document.removeEventListener('visibilitychange', this.handleVisibilityChange);
    }
  }

  /**
   * Screen Wake Lock API: keeps the screen from dimming/locking if desired
   */
  public async requestWakeLock(): Promise<boolean> {
    if (typeof navigator === 'undefined' || !('wakeLock' in navigator)) {
      return false;
    }

    try {
      this.wakeLock = await (navigator as any).wakeLock.request('screen');
      this.wakeLock.addEventListener('release', () => {
        this.wakeLock = null;
      });
      return true;
    } catch (err) {
      // e.g. low battery mode or user tab not active
      return false;
    }
  }

  public releaseWakeLock() {
    if (this.wakeLock) {
      try {
        this.wakeLock.release();
      } catch (e) {
        // ignore
      }
      this.wakeLock = null;
    }
  }

  private handleVisibilityChange() {
    if (document.visibilityState === 'visible' && this.isKeepAliveActive) {
      this.requestWakeLock();
    }
  }

  public isSupported(): boolean {
    return typeof navigator !== 'undefined' && 'wakeLock' in navigator;
  }
}

export const backgroundKeepAlive = new BackgroundKeepAliveService();
