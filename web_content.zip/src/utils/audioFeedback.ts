// Audio & Haptic feedback using Web Audio API and Navigator Vibration API (100% offline)

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function playTapSound(enabled: boolean = true) {
  if (!enabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = 'sine';
    // Gentle mellow warm droplet frequency
    osc.frequency.setValueAtTime(580, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(320, ctx.currentTime + 0.04);
    
    gain.gain.setValueAtTime(0.10, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start();
    osc.stop(ctx.currentTime + 0.05);
  } catch {
    // Ignore audio context errors gracefully
  }
}

export function playMilestoneSound(enabled: boolean = true) {
  if (!enabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = 'sine';
    // Elegant ascending chime for reaching a milestone (33, 66, 100...)
    osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
    osc.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.10); // G5
    
    gain.gain.setValueAtTime(0.12, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.14);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start();
    osc.stop(ctx.currentTime + 0.15);
  } catch {
    // Ignore audio context errors gracefully
  }
}

export function playCompleteSound(enabled: boolean = true) {
  if (!enabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    
    // Peaceful double harmonic chime
    const playNote = (freq: number, delay: number, dur: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + delay);
      gain.gain.setValueAtTime(0.15, ctx.currentTime + delay);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + delay);
      osc.stop(ctx.currentTime + delay + dur);
    };

    playNote(659.25, 0, 0.25); // E5
    playNote(880.00, 0.08, 0.35); // A5
  } catch {
    // Ignore audio context errors gracefully
  }
}

// Gentle serene bell chime for Dhikr Pacing Timer (مؤقت التمهل والتدبر)
export function playGentleBell(enabled: boolean = true) {
  if (!enabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    
    // Serene harmonic chord (528Hz Love/Peace frequency + 792Hz harmonic)
    const playHarmonic = (freq: number, gainVal: number, duration: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(gainVal, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    };

    playHarmonic(528, 0.16, 1.2);
    playHarmonic(792, 0.08, 0.9);
    playHarmonic(1056, 0.04, 0.6);
  } catch {
    // Ignore audio context errors
  }
}

export function playPacingTick(enabled: boolean = true) {
  if (!enabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(659.25, ctx.currentTime); // E5 soft droplet
    osc.frequency.exponentialRampToValueAtTime(523.25, ctx.currentTime + 0.08); // C5
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.09);
  } catch {
    // Ignore
  }
}

export function triggerVibration(
  enabled: boolean = true, 
  type: 'tap' | 'milestone' | 'complete' | 'undo' | 'light' = 'tap'
) {
  if (!enabled) return;
  if (typeof window !== 'undefined' && 'navigator' in window && navigator.vibrate) {
    try {
      if (type === 'tap') {
        // Crisp, punchy tactile bump for standard tasbeeh counter tap (28ms)
        navigator.vibrate(28);
      } else if (type === 'milestone') {
        // Distinct double-buzz pattern for milestone numbers (33, 66, 100...)
        navigator.vibrate([35, 45, 35]);
      } else if (type === 'complete') {
        // Celebratory target-reached vibration pattern (three distinct crescendo pulses)
        navigator.vibrate([60, 80, 60, 80, 160]);
      } else if (type === 'undo') {
        // Soft short haptic tick for undo
        navigator.vibrate(16);
      } else if (type === 'light') {
        // Ultra-light tick
        navigator.vibrate(12);
      }
    } catch {
      // Ignore vibration error gracefully
    }
  }
}
