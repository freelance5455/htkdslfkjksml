const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** converts western digits to persian digits */
export function toFa(value: string | number): string {
  return String(value).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

/** formats a number with thousand separators and persian digits */
export function faNumber(value: number): string {
  return toFa(Math.round(value).toLocaleString("en-US"));
}
