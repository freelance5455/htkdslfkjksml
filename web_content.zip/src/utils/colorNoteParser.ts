// ColorNote (.BIN) Decryption & Note Extraction Engine
// Handles AES-128-CBC with OpenSSL PBE EVP_BytesToKey (MD5 + "ColorNote Fixed Salt")
// Extracts JSON notes, checklists, YouTube Shorts/links, color tags, and timestamps

import { TaskItem, Attachment } from "../types";

export interface ColorNoteLink {
  url: string;
  isYouTube: boolean;
  isShorts: boolean;
  videoId?: string;
  thumbnailUrl?: string;
  domain: string;
}

export interface ColorNoteItem {
  id: string;
  title: string;
  content: string;
  rawType: number; // 0 = text, 16 = checklist
  isChecklist: boolean;
  isLocked?: boolean;
  tasks: TaskItem[];
  colorIndex: number;
  colorName: string;
  themeColor: "amber" | "blue" | "rose" | "emerald" | "purple" | "teal" | "slate";
  links: ColorNoteLink[];
  createdDate: string; // ISO string
  modifiedDate: string; // ISO string
  tags: string[];
}

export interface ColorNoteDecryptionResult {
  success: boolean;
  notes: ColorNoteItem[];
  message: string;
  passwordUsed: string;
  offsetUsed: number;
  rawJsonCount?: number;
  requiresCustomPassword?: boolean;
}

// Color palette mapping according to ColorNote spec:
// 0: Blue, 1: Red, 2: Orange, 3: Yellow, 4: Green, 5: Cyan, 6: Purple, 7: Gray, 8: Dark
export const COLORNOTE_COLOR_MAP: Record<number, { name: string; themeColor: "amber" | "blue" | "rose" | "emerald" | "purple" | "teal" | "slate"; hex: string }> = {
  0: { name: "Mavi", themeColor: "blue", hex: "#3b82f6" },
  1: { name: "Kırmızı", themeColor: "rose", hex: "#ef4444" },
  2: { name: "Turuncu", themeColor: "amber", hex: "#f97316" },
  3: { name: "Sarı", themeColor: "amber", hex: "#eab308" },
  4: { name: "Yeşil", themeColor: "emerald", hex: "#22c55e" },
  5: { name: "Camgöbeği", themeColor: "teal", hex: "#06b6d4" },
  6: { name: "Mor", themeColor: "purple", hex: "#a855f7" },
  7: { name: "Gri", themeColor: "slate", hex: "#64748b" },
  8: { name: "Koyu", themeColor: "slate", hex: "#334155" },
};

// Check if a file or buffer is a ColorNote or SQLite system backup
export function isColorNoteFile(buffer: Uint8Array | null, fileName: string): boolean {
  const lowerName = fileName.toLowerCase();
  
  if (
    lowerName.includes("colornote") ||
    lowerName.includes("color_note") ||
    lowerName.endsWith(".backup") ||
    lowerName.includes(".backup.") ||
    lowerName.endsWith(".idx") ||
    lowerName.startsWith("doc-") ||
    lowerName.includes("doc-") ||
    (lowerName.endsWith(".bin") && (lowerName.includes("note") || lowerName.includes("backup") || lowerName.includes("doc"))) ||
    (lowerName.endsWith(".doc") && lowerName.startsWith("doc-"))
  ) {
    return true;
  }

  if (buffer && buffer.length >= 4) {
    // NOTE signature: 0x4E 0x4F 0x54 0x45 ('NOTE')
    if (buffer[0] === 0x4e && buffer[1] === 0x4f && buffer[2] === 0x54 && buffer[3] === 0x45) {
      return true;
    }
    // SQLite format 3: 'SQLite format 3\0'
    if (
      buffer.length >= 16 &&
      buffer[0] === 0x53 &&
      buffer[1] === 0x51 &&
      buffer[2] === 0x4c &&
      buffer[3] === 0x69 &&
      buffer[4] === 0x74 &&
      buffer[5] === 0x65
    ) {
      return true;
    }
    // Search first 64 bytes for NOTE or SQLite signature
    for (let i = 0; i < Math.min(buffer.length - 4, 64); i++) {
      if (buffer[i] === 0x4e && buffer[i + 1] === 0x4f && buffer[i + 2] === 0x54 && buffer[i + 3] === 0x45) {
        return true;
      }
      if (
        i + 6 < buffer.length &&
        buffer[i] === 0x53 &&
        buffer[i + 1] === 0x51 &&
        buffer[i + 2] === 0x4c &&
        buffer[i + 3] === 0x69 &&
        buffer[i + 4] === 0x74 &&
        buffer[i + 5] === 0x65
      ) {
        return true;
      }
    }
  }

  return false;
}

// Extract YouTube and general URLs with rich metadata
export function parseLinksInText(text: string): ColorNoteLink[] {
  const urlRegex = /(https?:\/\/[^\s<>"{}|\^~`\[\]]+)/gi;
  const matches = text.match(urlRegex) || [];
  const uniqueUrls = Array.from(new Set(matches));

  return uniqueUrls.map((url) => {
    let isYouTube = false;
    let isShorts = false;
    let videoId: string | undefined;
    let domain = "";

    try {
      const parsed = new URL(url);
      domain = parsed.hostname.replace(/^www\./, "");
      if (domain.includes("youtube.com") || domain.includes("youtu.be")) {
        isYouTube = true;
        if (parsed.pathname.includes("/shorts/")) {
          isShorts = true;
          videoId = parsed.pathname.split("/shorts/")[1]?.split(/[?#&]/)[0];
        } else if (parsed.pathname.includes("/watch")) {
          videoId = parsed.searchParams.get("v") || undefined;
        } else if (domain.includes("youtu.be")) {
          videoId = parsed.pathname.slice(1).split(/[?#&]/)[0];
        }
      }
    } catch {
      domain = url.split("/")[2] || "web";
    }

    const thumbnailUrl = videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : undefined;

    return {
      url,
      isYouTube,
      isShorts,
      videoId,
      thumbnailUrl,
      domain,
    };
  });
}

// Parse checklist items from ColorNote note text
export function parseChecklistItems(noteText: string, rawTasks?: any[]): { tasks: TaskItem[]; isChecklist: boolean } {
  if (Array.isArray(rawTasks) && rawTasks.length > 0) {
    const tasks: TaskItem[] = rawTasks.map((t: any, idx: number) => ({
      id: `task-${Date.now()}-${idx}`,
      text: typeof t === "string" ? t : (t.task || t.text || String(t)),
      completed: !!(t.checked || t.completed || t.done),
    }));
    return { tasks, isChecklist: true };
  }

  const lines = noteText.split(/\r?\n/);
  const tasks: TaskItem[] = [];
  let detectedChecklist = false;

  lines.forEach((line, idx) => {
    const trimmed = line.trim();
    if (!trimmed) return;

    // Detect [ ] or [V] or [x] or [X]
    const checkMatch = trimmed.match(/^\[([ vVxX\-])\]\s*(.*)$/);
    if (checkMatch) {
      detectedChecklist = true;
      const mark = checkMatch[1].toLowerCase();
      const isDone = mark === "v" || mark === "x";
      tasks.push({
        id: `task-${Date.now()}-${idx}`,
        text: checkMatch[2] || trimmed,
        completed: isDone,
      });
      return;
    }

    // Detect markdown style: - [ ] or * [ ]
    const mdCheckMatch = trimmed.match(/^[-*]\s*\[([ vVxX\-])\]\s*(.*)$/);
    if (mdCheckMatch) {
      detectedChecklist = true;
      const mark = mdCheckMatch[1].toLowerCase();
      const isDone = mark === "v" || mark === "x";
      tasks.push({
        id: `task-${Date.now()}-${idx}`,
        text: mdCheckMatch[2] || trimmed,
        completed: isDone,
      });
      return;
    }

    // If already in checklist mode, add line as task
    if (detectedChecklist) {
      tasks.push({
        id: `task-${Date.now()}-${idx}`,
        text: trimmed,
        completed: false,
      });
    }
  });

  return { tasks, isChecklist: detectedChecklist };
}

// Call backend decryption service
export async function decryptColorNoteBackupApi(
  fileBase64: string,
  password = "0000",
  offset = 28
): Promise<ColorNoteDecryptionResult> {
  try {
    const cleanBase64 = fileBase64.includes(";base64,") ? fileBase64.split(";base64,")[1] : fileBase64;
    const response = await fetch("/api/colornote/decrypt", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        fileBase64: cleanBase64,
        password,
        offset,
      }),
    });

    if (!response.ok) {
      const errJson = await response.json().catch(() => ({}));
      return {
        success: false,
        notes: [],
        message: errJson.error || "Şifre çözülemedi. Lütfen ColorNote master parolanızı kontrol edin.",
        passwordUsed: password,
        offsetUsed: offset,
        requiresCustomPassword: true,
      };
    }

    const data = await response.json();
    return data;
  } catch (error: any) {
    return {
      success: false,
      notes: [],
      message: error.message || "Bağlantı hatası oluştu. Lütfen tekrar deneyin.",
      passwordUsed: password,
      offsetUsed: offset,
      requiresCustomPassword: true,
    };
  }
}
