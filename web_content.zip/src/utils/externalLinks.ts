export const MONETAG_DIRECT_LINK = 'https://uplcm.com/4/12076908';

/**
 * Robustly opens an external URL on Web and Android WebViews / APKs
 * without breaking inside iframes or strict WebViews.
 */
export function openExternalOfferLink(url: string = MONETAG_DIRECT_LINK): boolean {
  if (!url) return false;

  try {
    // 1. Android Native WebView interface check (common in Capacitor / Cordova / Custom WebView APKs)
    const win = window as unknown as {
      Android?: { openBrowser?: (u: string) => void; openUrl?: (u: string) => void };
      AndroidInterface?: { openUrl?: (u: string) => void };
      navigator?: { app?: { loadUrl?: (u: string, opt?: object) => void } };
    };

    if (win.Android?.openBrowser) {
      win.Android.openBrowser(url);
      return true;
    }
    if (win.Android?.openUrl) {
      win.Android.openUrl(url);
      return true;
    }
    if (win.AndroidInterface?.openUrl) {
      win.AndroidInterface.openUrl(url);
      return true;
    }

    // 2. Cordova inAppBrowser check
    if (win.navigator?.app?.loadUrl) {
      win.navigator.app.loadUrl(url, { openExternal: true });
      return true;
    }

    // 3. Standard anchor tag click (safest for mobile browsers, popup blockers, and WebViews)
    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      if (document.body.contains(link)) {
        document.body.removeChild(link);
      }
    }, 150);

    return true;
  } catch (err) {
    console.warn('External link navigation error:', err);
    // Graceful fallback
    try {
      window.location.href = url;
      return true;
    } catch {
      return false;
    }
  }
}
