import { BiText } from '../data/types';

export type RoutineCategory = 'morning' | 'progress' | 'safety';

export interface RoutineItem {
  id: string;
  category: RoutineCategory;
  timeTag: string;
  title: BiText;
  detail: BiText;
  isCustom?: boolean;
}

export interface RoutinePhoto {
  id: string;
  dataUrl: string;
  capturedAt: string;
}

export interface DailyRoutinePersistedState {
  version: 1;
  checkedMap: Record<string, boolean>;
  customItems: RoutineItem[];
  photosMap: Record<string, RoutinePhoto[]>;
  lastSavedAt: string | null;
}

const ROUTINE_STORAGE_KEY = 'farid_plumber_daily_routine_state_v1';
const LEGACY_CHECKED_KEY = 'farid_plumber_daily_checked_v1';
const LEGACY_CUSTOM_KEY = 'farid_plumber_daily_custom_v1';

function isValidCheckedMap(value: unknown): value is Record<string, boolean> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  return Object.values(value).every((v) => typeof v === 'boolean');
}

function isValidCustomItem(item: unknown): item is RoutineItem {
  if (!item || typeof item !== 'object') return false;
  const candidate = item as Partial<RoutineItem>;
  return (
    typeof candidate.id === 'string' &&
    (candidate.category === 'morning' ||
      candidate.category === 'progress' ||
      candidate.category === 'safety') &&
    typeof candidate.timeTag === 'string' &&
    Boolean(candidate.title && typeof candidate.title.en === 'string' && typeof candidate.title.hi === 'string') &&
    Boolean(candidate.detail && typeof candidate.detail.en === 'string' && typeof candidate.detail.hi === 'string')
  );
}

function isValidPhoto(photo: unknown): photo is RoutinePhoto {
  if (!photo || typeof photo !== 'object') return false;
  const candidate = photo as Partial<RoutinePhoto>;
  return (
    typeof candidate.id === 'string' &&
    typeof candidate.dataUrl === 'string' &&
    candidate.dataUrl.startsWith('data:image/') &&
    typeof candidate.capturedAt === 'string'
  );
}

function sanitizePhotosMap(value: unknown): Record<string, RoutinePhoto[]> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  const result: Record<string, RoutinePhoto[]> = {};
  for (const [key, list] of Object.entries(value)) {
    if (Array.isArray(list)) {
      const valid = list.filter(isValidPhoto);
      if (valid.length > 0) {
        result[key] = valid;
      }
    }
  }
  return result;
}

export function loadDailyRoutineState(): DailyRoutinePersistedState {
  const emptyState: DailyRoutinePersistedState = {
    version: 1,
    checkedMap: {},
    customItems: [],
    photosMap: {},
    lastSavedAt: null,
  };

  if (typeof window === 'undefined' || !window.localStorage) {
    return emptyState;
  }

  try {
    const raw = window.localStorage.getItem(ROUTINE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<DailyRoutinePersistedState>;
      return {
        version: 1,
        checkedMap: isValidCheckedMap(parsed.checkedMap) ? parsed.checkedMap : {},
        customItems: Array.isArray(parsed.customItems)
          ? parsed.customItems.filter(isValidCustomItem)
          : [],
        photosMap: sanitizePhotosMap(parsed.photosMap),
        lastSavedAt: typeof parsed.lastSavedAt === 'string' ? parsed.lastSavedAt : null,
      };
    }

    const legacyCheckedRaw = window.localStorage.getItem(LEGACY_CHECKED_KEY);
    const legacyCustomRaw = window.localStorage.getItem(LEGACY_CUSTOM_KEY);
    if (legacyCheckedRaw || legacyCustomRaw) {
      const checkedParsed = legacyCheckedRaw ? (JSON.parse(legacyCheckedRaw) as unknown) : {};
      const customParsed = legacyCustomRaw ? (JSON.parse(legacyCustomRaw) as unknown) : [];
      const migrated: DailyRoutinePersistedState = {
        version: 1,
        checkedMap: isValidCheckedMap(checkedParsed) ? checkedParsed : {},
        customItems: Array.isArray(customParsed) ? customParsed.filter(isValidCustomItem) : [],
        photosMap: {},
        lastSavedAt: new Date().toISOString(),
      };
      saveDailyRoutineState(migrated);
      return migrated;
    }
  } catch {
    return emptyState;
  }

  return emptyState;
}

export interface SaveRoutineResult {
  state: DailyRoutinePersistedState;
  quotaExceeded: boolean;
}

export function saveDailyRoutineState(
  state: Omit<DailyRoutinePersistedState, 'version'>
): SaveRoutineResult {
  const payload: DailyRoutinePersistedState = {
    version: 1,
    checkedMap: state.checkedMap,
    customItems: state.customItems,
    photosMap: state.photosMap,
    lastSavedAt: state.lastSavedAt ?? new Date().toISOString(),
  };

  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      window.localStorage.setItem(ROUTINE_STORAGE_KEY, JSON.stringify(payload));
      return { state: payload, quotaExceeded: false };
    } catch {
      return { state: payload, quotaExceeded: true };
    }
  }

  return { state: payload, quotaExceeded: false };
}

export function getRoutineStorageKey(): string {
  return ROUTINE_STORAGE_KEY;
}
