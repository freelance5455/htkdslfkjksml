import { CurrencyCode, CurrencyConfig } from '../types';

export const CURRENCIES: Record<CurrencyCode, CurrencyConfig> = {
  USD: { code: 'USD', symbol: '$', rate: 1.0, name: 'US Dollar' },
  PKR: { code: 'PKR', symbol: '₨', rate: 278.0, name: 'Pakistani Rupee' },
  AED: { code: 'AED', symbol: 'AED ', rate: 3.67, name: 'UAE Dirham' },
  GBP: { code: 'GBP', symbol: '£', rate: 0.79, name: 'British Pound' },
  EUR: { code: 'EUR', symbol: '€', rate: 0.92, name: 'Euro' },
};

export function formatPrice(amountUsd: number, currency: CurrencyCode = 'USD'): string {
  const config = CURRENCIES[currency] || CURRENCIES.USD;
  const converted = amountUsd * config.rate;

  if (currency === 'PKR') {
    return `${config.symbol} ${Math.round(converted).toLocaleString()}`;
  }

  if (currency === 'AED') {
    return `${config.symbol}${Math.round(converted).toLocaleString()}`;
  }

  return `${config.symbol}${converted.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}
