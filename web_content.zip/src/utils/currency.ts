import { Currency, Language } from '../types';

/**
 * Currency conversion constants (baseline in Algerian Dinar DZD)
 */
export const RATES_TO_DZD: Record<Currency, number> = {
  DZD: 1,
  EUR: 240, // 1 EUR = 240 DZD
  USD: 220, // 1 USD = 220 DZD
};

/**
 * Converts an amount from DZD into the target currency
 */
export function convertFromDZD(amountDZD: number, targetCurrency: Currency): number {
  if (amountDZD < 0) return 0;
  const rate = RATES_TO_DZD[targetCurrency] || 1;
  const converted = amountDZD / rate;
  return Math.round(converted * 100) / 100;
}

/**
 * Converts an amount from a given currency back into DZD
 */
export function convertToDZD(amount: number, fromCurrency: Currency): number {
  if (amount < 0) return 0;
  const rate = RATES_TO_DZD[fromCurrency] || 1;
  return Math.round(amount * rate);
}

/**
 * Formats a DZD price value into the active currency with localized symbol
 */
export function formatPrice(amountDZD: number, currency: Currency, language: Language = 'ar'): string {
  const converted = convertFromDZD(amountDZD, currency);
  const formattedNumber = new Intl.NumberFormat(
    language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US',
    {
      maximumFractionDigits: currency === 'DZD' ? 0 : 2,
      minimumFractionDigits: currency === 'DZD' ? 0 : 2,
    }
  ).format(converted);

  if (currency === 'DZD') {
    return language === 'ar' ? `${formattedNumber} دج` : `${formattedNumber} DZD`;
  }
  if (currency === 'EUR') {
    return language === 'ar' ? `${formattedNumber} €` : `€${formattedNumber}`;
  }
  if (currency === 'USD') {
    return language === 'ar' ? `${formattedNumber} $` : `$${formattedNumber}`;
  }
  return `${formattedNumber} ${currency}`;
}
