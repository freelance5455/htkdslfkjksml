import { ColorId, Coordinate, LevelConfig, SpecialTile } from '../types/game';

// Deterministic Pseudo-Random Number Generator (Mulberry32)
export function createPRNG(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6D2B79F5) >>> 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (Math.imul(31, hash) + str.charCodeAt(i)) | 0;
  }
  return Math.abs(hash);
}

const AVAILABLE_COLORS: ColorId[] = [
  'red',
  'blue',
  'green',
  'yellow',
  'purple',
  'orange',
  'cyan',
  'pink'
];

/**
 * Generate a 100% solvable Flow/Connection puzzle
 * Using self-avoiding random walk partitioning
 */
export function generateSolvableLevel(options: {
  id: string | number;
  name: string;
  worldIndex: number;
  rows: number;
  cols: number;
  pairCount: number;
  seed: number;
  hasSpecialTiles?: boolean;
  timeLimit?: number;
}): LevelConfig {
  const { id, name, worldIndex, rows, cols, pairCount, seed, hasSpecialTiles, timeLimit } = options;
  const rng = createPRNG(seed);

  const colors = AVAILABLE_COLORS.slice(0, Math.min(pairCount, AVAILABLE_COLORS.length));
  
  // Board occupancy: -1 = free, >= 0 = color index
  const board: number[][] = Array.from({ length: rows }, () => Array(cols).fill(-1));
  const paths: Coordinate[][] = [];

  const directions = [
    { dr: -1, dc: 0 },
    { dr: 1, dc: 0 },
    { dr: 0, dc: -1 },
    { dr: 0, dc: 1 }
  ];

  function getNeighbors(r: number, c: number): Coordinate[] {
    const list: Coordinate[] = [];
    for (const d of directions) {
      const nr = r + d.dr;
      const nc = c + d.dc;
      if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && board[nr][nc] === -1) {
        list.push({ r: nr, c: nc });
      }
    }
    return list;
  }

  // Shuffle utility with RNG
  function shuffle<T>(arr: T[]): T[] {
    const copy = [...arr];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }

  // Generate paths for each color
  for (let colorIdx = 0; colorIdx < colors.length; colorIdx++) {
    // Find free cells
    const freeCells: Coordinate[] = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (board[r][c] === -1) {
          freeCells.push({ r, c });
        }
      }
    }

    if (freeCells.length < 3) break;

    // Pick a starting cell
    const startCell = freeCells[Math.floor(rng() * freeCells.length)];
    const currentPath: Coordinate[] = [startCell];
    board[startCell.r][startCell.c] = colorIdx;

    const minLength = 3;
    const maxLength = Math.max(minLength, Math.floor(rng() * 4) + 4);

    let curr = startCell;
    while (currentPath.length < maxLength) {
      const neighbors = shuffle(getNeighbors(curr.r, curr.c));
      if (neighbors.length === 0) break;
      const next = neighbors[0];
      board[next.r][next.c] = colorIdx;
      currentPath.push(next);
      curr = next;
    }

    if (currentPath.length >= 2) {
      paths.push(currentPath);
    } else {
      // Revert if single cell
      board[startCell.r][startCell.c] = -1;
    }
  }

  // If we couldn't place enough paths, fallback to minimal clean distribution
  if (paths.length < 2) {
    paths.length = 0;
    // Hard fallback: 2 horizontal / vertical stripes
    paths.push([
      { r: 0, c: 0 },
      { r: 0, c: 1 },
      { r: 0, c: 2 }
    ]);
    paths.push([
      { r: 2, c: 0 },
      { r: 2, c: 1 },
      { r: 2, c: 2 }
    ]);
  }

  const pairs = paths.map((path, idx) => ({
    color: colors[idx % colors.length],
    start: path[0],
    end: path[path.length - 1]
  }));

  // Special tiles (bombs, multipliers, portals, ice)
  const specialTiles: SpecialTile[] = [];
  if (hasSpecialTiles) {
    // Add multiplier on an interior path cell if possible
    for (let i = 0; i < paths.length; i++) {
      const p = paths[i];
      if (p.length >= 3 && rng() > 0.4) {
        const midCell = p[Math.floor(p.length / 2)];
        specialTiles.push({
          type: 'multiplier',
          r: midCell.r,
          c: midCell.c,
          value: rng() > 0.5 ? 3 : 2
        });
        break;
      }
    }

    // Add bomb or ice or portal
    if (worldIndex >= 3 && rng() > 0.3) {
      // Find empty or boundary cells
      const emptyCells: Coordinate[] = [];
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          if (board[r][c] === -1) {
            emptyCells.push({ r, c });
          }
        }
      }

      if (emptyCells.length >= 2 && worldIndex >= 4 && rng() > 0.5) {
        // Portal pair
        const p1 = emptyCells[0];
        const p2 = emptyCells[1];
        specialTiles.push({
          type: 'portal',
          r: p1.r,
          c: p1.c,
          targetPortal: p2
        });
        specialTiles.push({
          type: 'portal',
          r: p2.r,
          c: p2.c,
          targetPortal: p1
        });
      } else if (emptyCells.length >= 1) {
        const b = emptyCells[0];
        specialTiles.push({
          type: 'bomb',
          r: b.r,
          c: b.c
        });
      }
    }
  }

  const parMoves = pairs.length;
  const maxMoves = Math.max(parMoves + 5, Math.ceil(parMoves * 1.6));

  return {
    id,
    worldIndex,
    name,
    rows,
    cols,
    pairs,
    specialTiles,
    maxMoves,
    parMoves,
    timeLimit
  };
}

/**
 * Generate deterministic Daily Challenge puzzle from date string (YYYY-MM-DD)
 */
export function getDailyChallengeLevel(dateStr: string): LevelConfig {
  const seed = hashString(dateStr);
  const prng = createPRNG(seed);
  
  // Daily challenge rotates grid size between 6x6, 7x7, 8x8
  const sizes = [
    { rows: 6, cols: 6, pairs: 5 },
    { rows: 7, cols: 7, pairs: 6 },
    { rows: 8, cols: 8, pairs: 7 }
  ];
  const choice = sizes[Math.floor(prng() * sizes.length)];

  return generateSolvableLevel({
    id: `daily_${dateStr}`,
    name: `Daily Pulse ${dateStr}`,
    worldIndex: 3,
    rows: choice.rows,
    cols: choice.cols,
    pairCount: choice.pairs,
    seed,
    hasSpecialTiles: true
  });
}

/**
 * Generate Endless Mode progressive puzzles
 */
export function getEndlessLevel(stage: number): LevelConfig {
  const seed = stage * 1039 + 771;
  const prng = createPRNG(seed);

  let rows = 5;
  let cols = 5;
  let pairs = 4;
  let hasSpecial = false;

  if (stage > 4) {
    rows = 6;
    cols = 6;
    pairs = 5;
  }
  if (stage > 12) {
    rows = 7;
    cols = 7;
    pairs = 6;
    hasSpecial = true;
  }
  if (stage > 25) {
    rows = 8;
    cols = 8;
    pairs = 7;
    hasSpecial = true;
  }
  if (stage > 45) {
    rows = 9;
    cols = 9;
    pairs = 8;
    hasSpecial = true;
  }

  return generateSolvableLevel({
    id: `endless_${stage}`,
    name: `Endless Stage ${stage}`,
    worldIndex: Math.min(5, Math.floor(stage / 10) + 1),
    rows,
    cols,
    pairCount: pairs,
    seed,
    hasSpecialTiles: hasSpecial
  });
}

/**
 * Generate Time Challenge puzzles (speed matching with ticking clock!)
 */
export function getTimeChallengeLevel(stage: number): LevelConfig {
  const seed = stage * 911 + 43;
  const rows = stage <= 3 ? 5 : stage <= 8 ? 6 : 7;
  const cols = rows;
  const pairs = rows - 1;

  return generateSolvableLevel({
    id: `time_${stage}`,
    name: `Speed Wave ${stage}`,
    worldIndex: 2,
    rows,
    cols,
    pairCount: pairs,
    seed,
    hasSpecialTiles: stage > 4,
    timeLimit: Math.max(18, 32 - stage)
  });
}
