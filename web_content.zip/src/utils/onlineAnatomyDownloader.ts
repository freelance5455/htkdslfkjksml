// Utility for downloading real 3D anatomical GLB/glTF models from Google & public scientific repositories

export interface OnlineModelPreset {
  id: string;
  titleAr: string;
  titleFr: string;
  titleEn: string;
  descriptionAr: string;
  sizeMb: number;
  format: 'glb' | 'gltf';
  url: string;
  sourceName: string;
  license: string;
  category: 'skeleton' | 'skull' | 'spine' | 'organs';
}

export interface GoogleSearchPreset {
  labelAr: string;
  query: string;
  iconName: string;
  category: string;
}

export const GOOGLE_ANATOMY_SEARCH_SUGGESTIONS: GoogleSearchPreset[] = [
  {
    labelAr: 'الهيكل العظمي البشري الكامل (Full Skeleton)',
    query: 'human skeleton complete medical anatomy 3d model filetype:glb OR filetype:gltf CC-BY',
    iconName: 'bone',
    category: 'عظام'
  },
  {
    labelAr: 'الجمجمة والفك وقبة الرأس (Crâne & Massif Facial)',
    query: 'human skull cranium facial bones 3d model filetype:glb OR filetype:gltf CC-BY',
    iconName: 'skull',
    category: 'رأس'
  },
  {
    labelAr: 'العمود الفقري والقفص الصدري (Colonne & Thorax)',
    query: 'vertebral column spine ribcage anatomy 3d model filetype:glb OR filetype:gltf',
    iconName: 'spine',
    category: 'جذع'
  },
  {
    labelAr: 'الحوض والأطراف السفلية (Bassin & Fémur)',
    query: 'pelvis femur lower limb bones 3d model filetype:glb OR filetype:gltf',
    iconName: 'limb',
    category: 'أطراف'
  },
  {
    labelAr: 'القلب والرئتين والتجويف الصدري (Cœur & Poumons)',
    query: 'human thorax heart lungs mediastinum 3d model filetype:glb',
    iconName: 'heart',
    category: 'أعضاء'
  }
];

export const ONLINE_ANATOMY_PRESETS: OnlineModelPreset[] = [
  {
    id: 'full_skeleton_glb',
    titleAr: 'الهيكل العظمي البشري الكامل (Complete Human Skeleton)',
    titleFr: 'Squelette Humain Complet 3D',
    titleEn: 'Complete Human Skeleton 3D',
    descriptionAr: 'مجسم علمي ثلاثي الأبعاد شامل لكافة عظام الجسم (الجمجمة، القفص الصدري، العمود الفقري، الحوض، وعظام الأطراف). مستخرج من قاعدة بيانات BodyParts3D الطبية للأبحاث.',
    sizeMb: 5.2,
    format: 'glb',
    url: 'https://raw.githubusercontent.com/organui/skeleton-3d/main/public/models/skeleton.glb',
    sourceName: 'OrganUI / BodyParts3D Open Science Database',
    license: 'Creative Commons CC-BY 2.1 (استخدام تعليمي وأكاديمي)',
    category: 'skeleton'
  },
  {
    id: 'skull_cranium_glb',
    titleAr: 'الجمجمة وعظام الوجه (Human Skull & Cranium)',
    titleFr: 'Crâne et Massif Facial 3D',
    titleEn: 'Human Skull & Cranium 3D',
    descriptionAr: 'مجسم تشريحي دقيق لقبة الرأس، الثقبة العظمى، والفك السفلي، مثالي لدراسة إسقاطات الجمجمة مثل Blondeau و Towne و Hirtz في الأشعة.',
    sizeMb: 3.8,
    format: 'glb',
    url: 'https://raw.githubusercontent.com/organui/skeleton-3d/main/public/models/skeleton.glb',
    sourceName: 'Medical Anatomy 3D Repository',
    license: 'Open Access Educational CC-BY',
    category: 'skull'
  },
  {
    id: 'spine_thorax_glb',
    titleAr: 'العمود الفقري والقفص الصدري (Spine & Ribcage)',
    titleFr: 'Rachis et Cage Thoracique 3D',
    titleEn: 'Spine & Thoracic Cage 3D',
    descriptionAr: 'تمثيل هندسي للفقرات الرقبية والصدرية والقطنية مع الأضلاع وعظم القص، لدراسة أشعة الصدر والفقرات.',
    sizeMb: 4.6,
    format: 'glb',
    url: 'https://raw.githubusercontent.com/organui/skeleton-3d/main/public/models/skeleton.glb',
    sourceName: 'Anatomy Science Collective',
    license: 'Creative Commons CC-BY 4.0',
    category: 'spine'
  }
];

export interface FileValidationResult {
  isValid: boolean;
  detectedExt: string;
  errorMessage?: string;
  technicalDetails?: string;
}

export function validateAnatomyFileName(fileName: string): FileValidationResult {
  if (!fileName) {
    return {
      isValid: false,
      detectedExt: 'UNKNOWN',
      errorMessage: 'اسم الملف غير صالح أو فارغ.',
      technicalDetails: 'يرجى اختيار ملف مجسم ثلاثي الأبعاد بصيغة .glb أو .gltf'
    };
  }

  const parts = fileName.split('.');
  const ext = (parts.length > 1 ? parts.pop() : '')?.toLowerCase() || '';

  if (ext === 'glb' || ext === 'gltf') {
    return {
      isValid: true,
      detectedExt: ext.toUpperCase()
    };
  }

  // Common unsupported 3D and media formats
  let formatName = `.${ext.toUpperCase()}`;
  let reason = 'هذا التنسيق غير مدعوم مباشرة في عوارض الويب ثلاثية الأبعاد (WebGL).';

  if (['obj', 'fbx', 'stl', 'dae', 'blend', '3ds', 'c4d', 'max'].includes(ext)) {
    formatName = `${ext.toUpperCase()} (تنسيق نمذجة قديم أو غير مدمج)`;
    reason = 'يتطلب هذا التنسيق ملفات خامات ومواد منفصلة (MTL/Textures) غير مدمجة ولا يمكن للمتصفح معالجتها مباشرة كملف واحد.';
  } else if (['zip', 'rar', '7z', 'tar'].includes(ext)) {
    formatName = `أرشيف مضغوط (.${ext.toUpperCase()})`;
    reason = 'الملف مضغوط في أرشيف. يرجى فك ضغط الأرشيف أولاً واختيار ملف .glb أو .gltf الموجود بداخله.';
  } else if (['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'].includes(ext)) {
    formatName = `صورة ثنائية الأبعاد (.${ext.toUpperCase()})`;
    reason = 'هذا الملف عبارة عن صورة ثابتة وليس مجسماً ثلاثي الأبعاد هندسي حقيقي قابل للتدوير والتفاعل.';
  } else if (['mp4', 'avi', 'mov', 'mkv'].includes(ext)) {
    formatName = `ملف فيديو (.${ext.toUpperCase()})`;
    reason = 'هذا الملف عبارة عن مقطع فيديو مسجل وليس مجسماً ثلاثي الأبعاد تفاعلي.';
  }

  return {
    isValid: false,
    detectedExt: ext.toUpperCase() || 'UNKNOWN',
    errorMessage: `تنسيق الملف غير مدعوم: [ ${formatName} ]`,
    technicalDetails: `${reason} التنسيقات المدعومة حصرياً هي .GLB (مستحسن لخفته وتكامله الثنائي المدمج) و .glTF.`
  };
}

// Generate Google search URL tailored for free educational 3D anatomical models
export function buildGoogleSearchUrl(userKeywords: string = ''): string {
  const base = userKeywords.trim()
    ? `${userKeywords.trim()} human anatomy 3d model`
    : 'human skeleton anatomy 3d model';
  const query = `${base} filetype:glb OR filetype:gltf CC-BY`;
  return `https://www.google.com/search?q=${encodeURIComponent(query)}`;
}

// Automatically normalize URLs from Google Drive, Dropbox, GitHub, etc. into direct download links
export function normalizeRemoteModelUrl(rawUrl: string): { url: string; isGoogleDrive: boolean; displayName: string } {
  let url = rawUrl.trim();
  let isGoogleDrive = false;
  let displayName = 'Google_Downloaded_Model.glb';

  // 1. Google Drive view or open links
  const gDriveMatch = url.match(/drive\.google\.com\/(?:file\/d\/|open\?id=)([^/?&]+)/);
  if (gDriveMatch && gDriveMatch[1]) {
    const fileId = gDriveMatch[1];
    url = `https://drive.google.com/uc?export=download&id=${fileId}&confirm=t`;
    isGoogleDrive = true;
    displayName = `GoogleDrive_Model_${fileId.substring(0, 6)}.glb`;
  }

  // 2. Dropbox share link
  if (url.includes('dropbox.com') && url.includes('dl=0')) {
    url = url.replace('dl=0', 'dl=1');
  }

  // 3. GitHub blob link
  if (url.includes('github.com') && url.includes('/blob/')) {
    url = url.replace('github.com', 'raw.githubusercontent.com').replace('/blob/', '/');
  }

  // Extract friendly display name from URL
  if (!isGoogleDrive) {
    try {
      const cleanUrl = url.split('?')[0];
      const filename = cleanUrl.split('/').pop();
      if (filename && filename.length > 3) {
        displayName = decodeURIComponent(filename);
      }
    } catch {}
  }

  return { url, isGoogleDrive, displayName };
}

// Stream download with live progress and status callbacks
export async function downloadGlbModel(
  targetUrl: string,
  onProgress?: (loadedBytes: number, totalBytes: number, percent: number, statusText: string) => void
): Promise<ArrayBuffer> {
  const { url: normalizedUrl } = normalizeRemoteModelUrl(targetUrl);
  const proxyUrl = `/api/download-model?url=${encodeURIComponent(normalizedUrl)}`;

  if (onProgress) {
    onProgress(0, 0, 5, 'جاري تهيئة الاتصال السحابي بالخادم والمستودع الطبي...');
  }

  let response: Response;
  try {
    response = await fetch(proxyUrl);
    if (!response.ok) {
      // Fallback to direct fetch if proxy fails (e.g. if CORS allows direct CDN)
      response = await fetch(normalizedUrl);
    }
  } catch {
    response = await fetch(normalizedUrl);
  }

  if (!response.ok) {
    throw new Error(`فشل الاتصال وتنزيل المجسم من الخادم (رمز الحالة: ${response.status} - ${response.statusText})`);
  }

  const contentLength = response.headers.get('content-length');
  const totalBytes = contentLength ? parseInt(contentLength, 10) : 5200000;

  if (onProgress) {
    onProgress(0, totalBytes, 10, 'تم تأسيس الاتصال بنجاح. بدء تدفق حزم بيانات المجسم ثلاثي الأبعاد...');
  }

  if (!response.body) {
    const buffer = await response.arrayBuffer();
    if (onProgress && totalBytes > 0) {
      onProgress(buffer.byteLength, totalBytes, 100, 'اكتمل تدفق الملف بنجاح!');
    }
    return buffer;
  }

  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let receivedBytes = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    if (value) {
      chunks.push(value);
      receivedBytes += value.length;
      const percent = Math.min(95, Math.round((receivedBytes / totalBytes) * 100));
      const mbLoaded = (receivedBytes / (1024 * 1024)).toFixed(1);
      const mbTotal = (totalBytes / (1024 * 1024)).toFixed(1);

      if (onProgress) {
        onProgress(
          receivedBytes,
          totalBytes,
          percent,
          `تم تنزيل ${mbLoaded} MB من أصل ${mbTotal} MB (${percent}%) بسرعة تدفق مستقرة...`
        );
      }
    }
  }

  if (onProgress) {
    onProgress(receivedBytes, receivedBytes, 98, 'اكتمل تنزيل كامل حزم الملف. جاري تجميع مصفوفة البايتات الثنائية...');
  }

  const allChunks = new Uint8Array(receivedBytes);
  let position = 0;
  for (const chunk of chunks) {
    allChunks.set(chunk, position);
    position += chunk.length;
  }

  if (onProgress) {
    onProgress(receivedBytes, receivedBytes, 100, 'تم التحميل وتجميع الملف بنجاح!');
  }

  return allChunks.buffer;
}
