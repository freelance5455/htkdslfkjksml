import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getLanguageMeta,
  getTranslations,
  SUPPORTED_LANGUAGES,
} from '../i18n/translations';
import {
  computePlacementResult,
  PLACEMENT_LISTENING_ITEMS,
  PLACEMENT_READING_ITEMS,
  PLACEMENT_SENTENCE_ITEMS,
  PLACEMENT_SPEAKING_PROMPTS,
  PLACEMENT_VOCAB_ITEMS,
  scoreWritingResponse,
} from './placementLogic';
import {
  buildSentenceDictationRound,
  checkSentenceDictation,
} from './sentenceGamesLogic';

test('i18n covers all 10 required languages with correct RTL/LTR direction and complete keys', () => {
  const expectedCodes = ['ar', 'hi', 'zh', 'ru', 'de', 'fr', 'es', 'it', 'pt', 'sv'];
  assert.equal(SUPPORTED_LANGUAGES.length, 10);
  assert.deepEqual(
    SUPPORTED_LANGUAGES.map((l) => l.code),
    expectedCodes
  );

  for (const code of expectedCodes) {
    const meta = getLanguageMeta(code as (typeof SUPPORTED_LANGUAGES)[number]['code']);
    assert.equal(meta.dir, code === 'ar' ? 'rtl' : 'ltr');

    const dict = getTranslations(code as (typeof SUPPORTED_LANGUAGES)[number]['code']);
    assert.ok(dict.navReading.length > 0, `navReading missing for ${code}`);
    assert.ok(dict.pwaInstallBtn.length > 0, `pwaInstallBtn missing for ${code}`);
    assert.ok(dict.signUp.length > 0, `signUp missing for ${code}`);
    assert.ok(dict.signIn.length > 0, `signIn missing for ${code}`);
    assert.ok(dict.sentDictTitle.length > 0, `sentDictTitle missing for ${code}`);
    assert.equal(Object.keys(dict.games).length, 10, `all 10 games present for ${code}`);
  }

  // Arabic reading tab must be renamed to القراءة
  assert.equal(getTranslations('ar').navReading, 'القراءة');
});

test('placementLogic has all 6 CEFR skill banks populated', () => {
  assert.ok(PLACEMENT_VOCAB_ITEMS.length >= 3);
  assert.ok(PLACEMENT_SENTENCE_ITEMS.length >= 3);
  assert.ok(PLACEMENT_READING_ITEMS.length >= 2);
  assert.ok(PLACEMENT_LISTENING_ITEMS.length >= 2);
  assert.ok(PLACEMENT_SPEAKING_PROMPTS.length >= 2);
});

test('scoreWritingResponse rewards rich English writing and rejects empty input', () => {
  assert.equal(scoreWritingResponse(''), 0);
  const shortScore = scoreWritingResponse('I learn English.');
  const richScore = scoreWritingResponse(
    'I am learning English because it helps my career and travel plans. Although grammar can be challenging, I practice listening and reading every morning, and therefore my confidence improves every week.'
  );
  assert.ok(shortScore > 0 && shortScore < 65, `shortScore=${shortScore}`);
  assert.ok(richScore >= 80, `richScore=${richScore}`);
});

test('computePlacementResult maps CEFR bands A0-C2 and calculates exact next-level gap', () => {
  const low = computePlacementResult({
    vocabulary: 10,
    sentences: 15,
    reading: 20,
    writing: 10,
    listening: 15,
    speaking: 10,
  });
  assert.equal(low.cefrBand, 'A0');
  assert.equal(low.nextBand, 'A1');
  assert.equal(low.pointsToNext, 20 - low.overallScore);
  assert.equal(low.weakestSkills.length, 2);

  // Average = 63 -> B1 (50..64), next band B2 starts at 65 -> pointsToNext = 2
  const mid = computePlacementResult({
    vocabulary: 70,
    sentences: 68,
    reading: 65,
    writing: 60,
    listening: 62,
    speaking: 55,
  });
  assert.equal(mid.cefrBand, 'B1');
  assert.equal(mid.nextBand, 'B2');
  assert.equal(mid.pointsToNext, 65 - mid.overallScore);
  assert.equal(mid.weakestSkills[0], 'speaking');

  const top = computePlacementResult({
    vocabulary: 98,
    sentences: 95,
    reading: 96,
    writing: 94,
    listening: 95,
    speaking: 92,
  });
  assert.equal(top.cefrBand, 'C2');
  assert.equal(top.nextBand, null);
  assert.equal(top.pointsToNext, 0);
});

test('sentence dictation builds rounds and diffs typed answers word by word', () => {
  const round = buildSentenceDictationRound(5, 42);
  assert.equal(round.length, 5);
  for (const item of round) {
    assert.ok(item.en.length > 10);
    assert.ok(item.ar.length > 2);
    assert.ok(item.wordCount >= 5);
  }

  const exact = checkSentenceDictation(
    'where is the nearest train station',
    'Where is the nearest train station?'
  );
  assert.equal(exact.isExact, true);
  assert.equal(exact.accuracyPct, 100);
  assert.ok(exact.tokens.every((tk) => tk.correct));

  const partial = checkSentenceDictation(
    'Where is the bus station',
    'Where is the nearest train station?'
  );
  assert.equal(partial.isExact, false);
  assert.ok(partial.accuracyPct >= 50 && partial.accuracyPct < 90);
  assert.ok(partial.tokens.some((tk) => !tk.correct));

  const empty = checkSentenceDictation('   ', 'Where is the train?');
  assert.equal(empty.isExact, false);
  assert.equal(empty.accuracyPct, 0);
});
