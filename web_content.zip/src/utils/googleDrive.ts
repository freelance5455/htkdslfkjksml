import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  signOut,
  User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { getFullApkDownloadUrl, getFullZipDownloadUrl } from './downloadHelper';

// Single Firebase App instance
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Provider with Google Drive file scope
const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/drive.file');
provider.setCustomParameters({
  prompt: 'select_account',
});

// In-memory token cache (never stored in localStorage/sessionStorage per security guidelines)
let cachedAccessToken: string | null = null;
let isSigningIn = false;

export const initAuth = (
  onAuthSuccess?: (user: User, token: string | null) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const signInWithGoogle = async (): Promise<{ user: User; accessToken: string }> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);

    if (!credential?.accessToken) {
      throw new Error('Google Drive access token prapt nahi hua. Kripya dobara try karein.');
    }

    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Sign-In Error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getCachedToken = (): string | null => {
  return cachedAccessToken;
};

export const logoutGoogle = async () => {
  await signOut(auth);
  cachedAccessToken = null;
};

export interface DriveUploadResult {
  success: boolean;
  fileId?: string;
  name?: string;
  webViewLink?: string;
  directDownloadLink?: string;
  webContentLink?: string;
  error?: string;
}

/**
 * Uploads genuine BrandMorph_Julli_v1.0.apk (7.09 MB) to User's Google Drive.
 */
export async function uploadApkToGoogleDrive(
  onProgress?: (progressPercent: number, statusText: string) => void
): Promise<DriveUploadResult> {
  try {
    let token = cachedAccessToken;

    // If no token in memory, prompt sign in with Google
    if (!token) {
      if (onProgress) onProgress(5, 'Google Account se jud rahe hain...');
      const signinRes = await signInWithGoogle();
      token = signinRes.accessToken;
    }

    if (!token) {
      throw new Error('Google Drive authorization token nahi mila.');
    }

    if (onProgress) onProgress(15, 'Verified 7.09 MB APK binary fetch ho rahi hai...');

    // Fetch the real local APK
    const directUrl = getFullApkDownloadUrl();
    let res = await fetch(directUrl);
    if (!res.ok) {
      res = await fetch('/BrandMorph_Julli_v1.0.apk');
    }
    if (!res.ok) {
      res = await fetch('/api/download-apk');
    }

    if (!res.ok) {
      throw new Error(`APK file read karne me samasya: HTTP ${res.status}`);
    }

    const apkBlob = await res.blob();

    // Verify package size strictly (must be ~7.09 MB, not the legacy 0.42 KB placeholder)
    if (apkBlob.size < 5000000) {
      throw new Error(
        `Corrupt/small package detected (${(apkBlob.size / 1024).toFixed(1)} KB). Expected verified 7.09 MB APK.`
      );
    }

    const sizeMB = (apkBlob.size / (1024 * 1024)).toFixed(2);
    if (onProgress) onProgress(30, `BrandMorph_Julli_v1.0.apk (${sizeMB} MB) Google Drive me bhej rahe hain...`);

    const metadata = {
      name: 'BrandMorph_Julli_v1.0.apk',
      mimeType: 'application/vnd.android.package-archive',
      description: 'BrandMorph & Julli AI Studio Android APK (7.09 MB • Real Binary Package)',
    };

    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const multipartBody = new Blob(
      [
        delimiter,
        'Content-Type: application/json; charset=UTF-8\r\n\r\n',
        JSON.stringify(metadata),
        delimiter,
        'Content-Type: application/vnd.android.package-archive\r\n\r\n',
        apkBlob,
        closeDelimiter,
      ],
      { type: `multipart/related; boundary=${boundary}` }
    );

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open(
        'POST',
        'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink,webContentLink'
      );
      xhr.setRequestHeader('Authorization', `Bearer ${token}`);

      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) {
          const percent = Math.min(99, Math.round(30 + (e.loaded / e.total) * 65));
          const uploadedMB = (e.loaded / (1024 * 1024)).toFixed(2);
          const totalMB = (e.total / (1024 * 1024)).toFixed(2);
          if (onProgress) {
            onProgress(percent, `Google Drive Upload: ${uploadedMB} MB / ${totalMB} MB (${percent}%)...`);
          }
        }
      };

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const data = JSON.parse(xhr.responseText);
            if (onProgress) onProgress(100, 'Google Drive me safaltapoorvak save ho gaya!');

            // Make the file link shareable with anyone with the link
            try {
              fetch(`https://www.googleapis.com/drive/v3/files/${data.id}/permissions`, {
                method: 'POST',
                headers: {
                  Authorization: `Bearer ${token}`,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  role: 'reader',
                  type: 'anyone',
                }),
              }).catch(() => {});
            } catch {}

            const shareUrl =
              data.webViewLink ||
              `https://drive.google.com/file/d/${data.id}/view?usp=sharing`;
            const directDownloadUrl = `https://drive.google.com/uc?export=download&id=${data.id}`;

            resolve({
              success: true,
              fileId: data.id,
              name: data.name || 'BrandMorph_Julli_v1.0.apk',
              webViewLink: shareUrl,
              directDownloadLink: directDownloadUrl,
              webContentLink: data.webContentLink,
            });
          } catch (e: any) {
            reject(new Error('Drive response parse error: ' + e.message));
          }
        } else {
          try {
            const errJson = JSON.parse(xhr.responseText);
            reject(
              new Error(
                errJson.error?.message || `Drive upload failed with status ${xhr.status}`
              )
            );
          } catch {
            reject(new Error(`Drive upload failed with HTTP ${xhr.status}`));
          }
        }
      };

      xhr.onerror = () => {
        reject(new Error('Network error while uploading to Google Drive'));
      };

      xhr.send(multipartBody);
    });
  } catch (error: any) {
    console.error('Upload to Google Drive error:', error);
    return {
      success: false,
      error: error?.message || 'Google Drive upload me truti aayi.',
    };
  }
}

/**
 * Uploads BrandMorph_Project.zip (3.0 MB) to User's Google Drive.
 */
export async function uploadZipToGoogleDrive(
  onProgress?: (progressPercent: number, statusText: string) => void
): Promise<DriveUploadResult> {
  try {
    let token = cachedAccessToken;

    if (!token) {
      if (onProgress) onProgress(5, 'Google Account se jud rahe hain...');
      const signinRes = await signInWithGoogle();
      token = signinRes.accessToken;
    }

    if (!token) {
      throw new Error('Google Drive authorization token nahi mila.');
    }

    if (onProgress) onProgress(15, 'Project ZIP (3.0 MB) fetch ho rahi hai...');

    let res = await fetch('/BrandMorph_Project.zip');
    if (!res.ok) {
      res = await fetch('/api/download-zip');
    }
    if (!res.ok) {
      res = await fetch(getFullZipDownloadUrl());
    }

    if (!res.ok) {
      throw new Error(`ZIP file read karne me samasya: HTTP ${res.status}`);
    }

    const zipBlob = await res.blob();
    if (zipBlob.size < 100000) {
      throw new Error(`Incomplete zip detected: ${(zipBlob.size / 1024).toFixed(1)} KB`);
    }

    const sizeMB = (zipBlob.size / (1024 * 1024)).toFixed(2);
    if (onProgress) onProgress(30, `BrandMorph_Project.zip (${sizeMB} MB) Google Drive me bhej rahe hain...`);

    const metadata = {
      name: 'BrandMorph_Project.zip',
      mimeType: 'application/zip',
      description: 'BrandMorph & Julli AI Studio Complete Project Source Code & Files (3.0 MB)',
    };

    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const multipartBody = new Blob(
      [
        delimiter,
        'Content-Type: application/json; charset=UTF-8\r\n\r\n',
        JSON.stringify(metadata),
        delimiter,
        'Content-Type: application/zip\r\n\r\n',
        zipBlob,
        closeDelimiter,
      ],
      { type: `multipart/related; boundary=${boundary}` }
    );

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open(
        'POST',
        'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink,webContentLink'
      );
      xhr.setRequestHeader('Authorization', `Bearer ${token}`);

      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) {
          const percent = Math.min(99, Math.round(30 + (e.loaded / e.total) * 65));
          const uploadedMB = (e.loaded / (1024 * 1024)).toFixed(2);
          const totalMB = (e.total / (1024 * 1024)).toFixed(2);
          if (onProgress) {
            onProgress(percent, `Google Drive ZIP Upload: ${uploadedMB} MB / ${totalMB} MB (${percent}%)...`);
          }
        }
      };

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const data = JSON.parse(xhr.responseText);
            if (onProgress) onProgress(100, 'Project ZIP Google Drive me safaltapoorvak save ho gaya!');

            try {
              fetch(`https://www.googleapis.com/drive/v3/files/${data.id}/permissions`, {
                method: 'POST',
                headers: {
                  Authorization: `Bearer ${token}`,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  role: 'reader',
                  type: 'anyone',
                }),
              }).catch(() => {});
            } catch {}

            const shareUrl =
              data.webViewLink ||
              `https://drive.google.com/file/d/${data.id}/view?usp=sharing`;
            const directDownloadUrl = `https://drive.google.com/uc?export=download&id=${data.id}`;

            resolve({
              success: true,
              fileId: data.id,
              name: data.name || 'BrandMorph_Project.zip',
              webViewLink: shareUrl,
              directDownloadLink: directDownloadUrl,
              webContentLink: data.webContentLink,
            });
          } catch (e: any) {
            reject(new Error('Drive response parse error: ' + e.message));
          }
        } else {
          try {
            const errJson = JSON.parse(xhr.responseText);
            reject(
              new Error(
                errJson.error?.message || `Drive upload failed with status ${xhr.status}`
              )
            );
          } catch {
            reject(new Error(`Drive upload failed with HTTP ${xhr.status}`));
          }
        }
      };

      xhr.onerror = () => {
        reject(new Error('Network error while uploading ZIP to Google Drive'));
      };

      xhr.send(multipartBody);
    });
  } catch (error: any) {
    console.error('Upload ZIP to Google Drive error:', error);
    return {
      success: false,
      error: error?.message || 'Google Drive ZIP upload me truti aayi.',
    };
  }
}

