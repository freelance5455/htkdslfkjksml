import { initializeApp, getApps } from 'firebase/app';
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  signOut,
  User 
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Defined scopes matching set_up_oauth
export const SCOPES = [
  'https://www.googleapis.com/auth/drive.file',
];

// Initialize Firebase App singleton
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
export const auth = getAuth(app);

const provider = new GoogleAuthProvider();
SCOPES.forEach((scope) => provider.addScope(scope));

// In-memory access token cache (MANDATORY per workspace-integration skill: never store in localStorage)
let cachedAccessToken: string | null = null;
let isSigningIn = false;

// Initialize Google Auth state listener
export const initGoogleAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        // If user is signed in with Firebase but token is not in memory, re-prompt or reset
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

// Sign in with Google Popup
export const signInWithGoogle = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      console.warn('Google Drive access token was not returned.');
      return null;
    }

    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    // Gracefully handle standard popup closure or cancellation by user
    if (
      error?.code === 'auth/popup-closed-by-user' ||
      error?.code === 'auth/cancelled-popup-request' ||
      error?.code === 'auth/popup-blocked'
    ) {
      console.info('[SK TTS Google Auth] Popup closed or cancelled by user.');
      return null;
    }
    console.warn('[SK TTS Google Auth Notice]', error?.message || error);
    return null;
  } finally {
    isSigningIn = false;
  }
};

// Retrieve in-memory access token
export const getGoogleAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

// Sign out
export const signOutGoogle = async () => {
  await signOut(auth);
  cachedAccessToken = null;
};

export interface DriveUploadedFile {
  id: string;
  name: string;
  mimeType: string;
  webViewLink?: string;
  webContentLink?: string;
  size?: string;
}

/**
 * Finds or creates the "SK TTS Audio" folder in the user's Google Drive
 */
async function getOrCreateFolder(accessToken: string, folderName = 'SK TTS Audio'): Promise<string | null> {
  try {
    // 1. Search for existing folder
    const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
      `name = '${folderName}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`
    )}&fields=files(id,name)`;

    const res = await fetch(searchUrl, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    if (res.ok) {
      const data = await res.json();
      if (data.files && data.files.length > 0) {
        return data.files[0].id;
      }
    }

    // 2. Create the folder if not present
    const createRes = await fetch('https://www.googleapis.com/drive/v3/files', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: folderName,
        mimeType: 'application/vnd.google-apps.folder',
      }),
    });

    if (createRes.ok) {
      const newFolder = await createRes.json();
      return newFolder.id;
    }
  } catch (err) {
    console.warn('Could not create folder in Google Drive:', err);
  }
  return null;
}

/**
 * Uploads an audio Blob directly to user's Google Drive using Drive v3 multipart upload
 */
export async function uploadAudioToGoogleDrive(
  fileName: string,
  audioBlob: Blob,
  token?: string
): Promise<DriveUploadedFile> {
  const accessToken = token || cachedAccessToken;
  if (!accessToken) {
    throw new Error('Google Drive authorization required. Please connect your Google account.');
  }

  // Ensure "SK TTS Audio" target folder exists
  const folderId = await getOrCreateFolder(accessToken, 'SK TTS Audio');

  const metadata: Record<string, any> = {
    name: fileName,
    mimeType: audioBlob.type || 'audio/wav',
    description: 'Generated with SK TTS (Multilingual Text to Speech Studio)',
  };

  if (folderId) {
    metadata.parents = [folderId];
  }

  const boundary = '-------sk_tts_boundary_31415926';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const metadataBlob = new Blob([JSON.stringify(metadata)], {
    type: 'application/json; charset=UTF-8',
  });

  const multipartBody = new Blob(
    [
      delimiter,
      metadataBlob,
      `\r\n--${boundary}\r\nContent-Type: ${audioBlob.type || 'audio/wav'}\r\n\r\n`,
      audioBlob,
      closeDelimiter,
    ],
    { type: `multipart/related; boundary=${boundary}` }
  );

  const uploadUrl = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,webViewLink,webContentLink,size';

  const response = await fetch(uploadUrl, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': `multipart/related; boundary=${boundary}`,
    },
    body: multipartBody,
  });

  if (!response.ok) {
    const errorBody = await response.text();
    let errorMsg = `Google Drive upload failed with status ${response.status}`;
    try {
      const errJson = JSON.parse(errorBody);
      if (errJson.error?.message) {
        errorMsg = errJson.error.message;
      }
    } catch (e) {
      // Ignored
    }
    throw new Error(errorMsg);
  }

  const uploaded = await response.json();
  return {
    id: uploaded.id,
    name: uploaded.name,
    mimeType: uploaded.mimeType,
    webViewLink: uploaded.webViewLink || `https://drive.google.com/file/d/${uploaded.id}/view`,
    webContentLink: uploaded.webContentLink,
    size: uploaded.size ? `${(parseInt(uploaded.size, 10) / 1024).toFixed(1)} KB` : undefined,
  };
}
