// Audio recording and Web Audio synthesis engine for video voiceovers

export class AudioEngine {
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private audioStream: MediaStream | null = null;

  async startMicRecording(): Promise<void> {
    this.audioChunks = [];
    this.audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.mediaRecorder = new MediaRecorder(this.audioStream);

    this.mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) {
        this.audioChunks.push(e.data);
      }
    };

    this.mediaRecorder.start();
  }

  stopMicRecording(): Promise<{ blob: Blob; url: string }> {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) {
        return reject(new Error("No active mic recording"));
      }

      this.mediaRecorder.onstop = () => {
        const blob = new Blob(this.audioChunks, { type: "audio/webm" });
        const url = URL.createObjectURL(blob);
        // Stop stream tracks
        if (this.audioStream) {
          this.audioStream.getTracks().forEach((track) => track.stop());
        }
        resolve({ blob, url });
      };

      this.mediaRecorder.stop();
    });
  }

  // Create an audio stream destination from recorded audio or synthetic music
  static createMixedAudioStream(
    audioElement: HTMLAudioElement | null,
    includeAmbientMusic = false,
    ambientVolume = 0.2
  ): { stream: MediaStream; cleanup: () => void } {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = new AudioContextClass();
    const dest = ctx.createMediaStreamDestination();

    let ambientOsc1: OscillatorNode | null = null;
    let ambientGain: GainNode | null = null;

    // Connect user voice if element exists
    if (audioElement && audioElement.src) {
      try {
        const source = ctx.createMediaElementSource(audioElement);
        source.connect(dest);
        source.connect(ctx.destination); // also monitor
      } catch (e) {
        console.warn("Could not pipe audio element into stream destination:", e);
      }
    }

    // Optional background synth beat
    if (includeAmbientMusic) {
      try {
        ambientOsc1 = ctx.createOscillator();
        ambientGain = ctx.createGain();
        ambientOsc1.type = "sine";
        ambientOsc1.frequency.setValueAtTime(220, ctx.currentTime); // A3
        ambientGain.gain.setValueAtTime(ambientVolume, ctx.currentTime);

        ambientOsc1.connect(ambientGain);
        ambientGain.connect(dest);
        ambientOsc1.start();
      } catch (e) {
        console.warn("Error creating ambient synth music:", e);
      }
    }

    const cleanup = () => {
      if (ambientOsc1) {
        try {
          ambientOsc1.stop();
        } catch (_) {}
      }
      ctx.close();
    };

    return { stream: dest.stream, cleanup };
  }
}
