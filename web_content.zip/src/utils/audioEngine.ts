/**
 * Web Audio Engine for Speaker Diagnostics, Unstick Frequency Bursts,
 * and Audio Routing Verification.
 */

let audioCtx: AudioContext | null = null;

export const getAudioContext = (): AudioContext => {
  if (!audioCtx || audioCtx.state === 'closed') {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
};

/**
 * Enumerate connected audio devices
 */
export const inspectAudioDevices = async () => {
  if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
    return {
      supported: false,
      devices: [],
      error: 'واجهة استكشاف أجهزة الصوت غير مدعومة في هذا النظام.',
    };
  }

  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const audioOutputs = devices.filter((d) => d.kind === 'audiooutput');
    const audioInputs = devices.filter((d) => d.kind === 'audioinput');

    return {
      supported: true,
      audioOutputs,
      audioInputs,
      totalAudioDevices: audioOutputs.length + audioInputs.length,
      hasExplicitHeadphones: audioOutputs.some(
        (d) =>
          d.label.toLowerCase().includes('headphone') ||
          d.label.toLowerCase().includes('headset') ||
          d.label.toLowerCase().includes('wired') ||
          d.label.includes('سماعة')
      ),
    };
  } catch (err) {
    return {
      supported: false,
      devices: [],
      error: (err as Error).message || 'فشل فحص أجهزة الصوت',
    };
  }
};

/**
 * Runs the Multi-Stage Audio Unstick Frequency Sequence:
 * Stage 1: Low-frequency 50Hz sub-pulse (vibrates DAC coil/switch)
 * Stage 2: Alternating high-power 440Hz & 880Hz square pulses
 * Stage 3: Linear acoustic sweep (100Hz -> 3000Hz)
 * Stage 4: High impulse tone to trigger output stage amplifier
 */
export const executeAudioUnstickSequence = async (
  onProgress?: (step: number, total: number, label: string) => void
): Promise<{ success: boolean; message: string }> => {
  const ctx = getAudioContext();
  await ctx.resume();

  const totalSteps = 4;

  try {
    // Stage 1: 50Hz Low Resonance (Dislodge / wake transducer)
    onProgress?.(1, totalSteps, 'توليد نبضات ترددية منخفضة (50Hz) لإثارة موصلات الصوت...');
    await playTone(ctx, 50, 'triangle', 0.8, 0.7);
    await delay(300);

    // Stage 2: Alternating Square Wave Bursts (High dynamic range DAC wake)
    onProgress?.(2, totalSteps, 'بث نبضات كهرومغناطيسية متناوبة لإعادة تهيئة قفل السماعة...');
    await playTone(ctx, 440, 'square', 0.5, 0.4);
    await delay(150);
    await playTone(ctx, 880, 'square', 0.5, 0.4);
    await delay(300);

    // Stage 3: Frequency Sweep 120Hz -> 2400Hz
    onProgress?.(3, totalSteps, 'مسح ترددي متصاعد لتجاوز توجيه القناة العالقة...');
    await playFrequencySweep(ctx, 120, 2400, 1.2);
    await delay(300);

    // Stage 4: Codec Routing Ping
    onProgress?.(4, totalSteps, 'فحص استجابة المكبر وتحديث مسار الإخراج النهائي...');
    await playTone(ctx, 1000, 'sine', 0.6, 0.5);

    return {
      success: true,
      message: 'اكتملت دورة النبضات الترددية بنجاح! تم إرسال إشارات تفريغ الشحنة وإعادة تنشيط مضخم الصوت الداخلي.',
    };
  } catch (err) {
    return {
      success: false,
      message: `حدث خطأ أثناء بث النبضات: ${(err as Error).message}`,
    };
  }
};

/**
 * Play a high quality clear test melody to verify speaker sound
 */
export const playSpeakerTestSound = async (): Promise<void> => {
  const ctx = getAudioContext();
  await ctx.resume();

  const notes = [
    { freq: 523.25, duration: 0.2 }, // C5
    { freq: 659.25, duration: 0.2 }, // E5
    { freq: 783.99, duration: 0.25 }, // G5
    { freq: 1046.50, duration: 0.45 }, // C6
  ];

  for (let i = 0; i < notes.length; i++) {
    const note = notes[i];
    await playTone(ctx, note.freq, 'sine', note.duration, 0.6);
    await delay(60);
  }
};

// Helper: play single tone
const playTone = (
  ctx: AudioContext,
  freq: number,
  type: OscillatorType,
  duration: number,
  volume = 0.5
): Promise<void> => {
  return new Promise((resolve) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);

    gain.gain.setValueAtTime(0.001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(volume, ctx.currentTime + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + duration);

    osc.onended = () => resolve();
  });
};

// Helper: play frequency sweep
const playFrequencySweep = (
  ctx: AudioContext,
  startFreq: number,
  endFreq: number,
  duration: number
): Promise<void> => {
  return new Promise((resolve) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(startFreq, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(endFreq, ctx.currentTime + duration);

    gain.gain.setValueAtTime(0.001, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.4, ctx.currentTime + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + duration);

    osc.onended = () => resolve();
  });
};

const delay = (ms: number) => new Promise((res) => setTimeout(res, ms));
