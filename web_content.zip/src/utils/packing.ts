/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PackingCategory = 'clothing' | 'electronics' | 'documents' | 'toiletries' | 'essentials';
export type TripPurpose = 'leisure' | 'business' | 'religious' | 'honeymoon' | 'adventure';
export type ClimateType = 'temperate' | 'hot' | 'cold' | 'tropical';

export interface PackingItem {
  id: string;
  name: string;
  nameEn: string;
  nameFr: string;
  category: PackingCategory;
  quantity: number;
  packed: boolean;
  isEssential: boolean;
  baggageType: 'carry_on' | 'checked';
  tip?: string;
}

export interface PackingPlan {
  id: string;
  destination: string;
  durationDays: number;
  purpose: TripPurpose;
  climate: ClimateType;
  items: PackingItem[];
  updatedAt: string;
}

export const PACKING_STORAGE_KEY = 'taki_smart_packing_v1';

/**
 * Heuristically detect climate from destination name.
 */
export function detectClimate(destination: string): ClimateType {
  const destLower = destination.toLowerCase().trim();
  if (/dubai|دبي|cairo|القاهرة|riyadh|الرياض|doha|الدوحة|jeddah|جدة|muscat|مسقط/.test(destLower)) {
    return 'hot';
  }
  if (/istanbul|إسطنبول|paris|باريس|london|لندن|rome|روما|madrid|مدريد|algiers|الجزائر/.test(destLower)) {
    return 'temperate';
  }
  if (/moscow|موسكو|oslo|أوسلو|switzerland|سويسرا|geneva|جنيف|iceland|آيسلندا/.test(destLower)) {
    return 'cold';
  }
  if (/malaysia|ماليزيا|kuala|كوالالمبور|bali|بالي|phuket|بوكيت|zanzibar|زنجبار|maldives|المالديف/.test(destLower)) {
    return 'tropical';
  }
  return 'temperate';
}

/**
 * Pure generator creating a customized, categorized packing list
 * based on destination, duration, purpose, and climate.
 */
export function generatePackingList(
  destination: string,
  durationDays: number,
  purpose: TripPurpose = 'leisure',
  overrideClimate?: ClimateType
): PackingItem[] {
  const safeDays = Math.max(1, Math.min(30, durationDays || 7));
  const climate = overrideClimate || detectClimate(destination);

  const items: PackingItem[] = [];

  // Helper to push items
  const add = (
    idSuffix: string,
    name: string,
    nameEn: string,
    nameFr: string,
    category: PackingCategory,
    quantity: number,
    isEssential: boolean,
    baggageType: 'carry_on' | 'checked',
    tip?: string
  ) => {
    items.push({
      id: `pack-${idSuffix}-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name,
      nameEn,
      nameFr,
      category,
      quantity,
      packed: false,
      isEssential,
      baggageType,
      tip,
    });
  };

  // --- 1. DOCUMENTS (Always in carry-on for security) ---
  add(
    'passport',
    'جواز السفر الأصلي وتأشيرة الدخول',
    'Passport & Travel Visa',
    'Passeport & Visa',
    'documents',
    1,
    true,
    'carry_on',
    'صالح لأكثر من 6 أشهر ومحفوظ في TAKI SecureVault'
  );

  add(
    'boarding-passes',
    'تذاكر الطيران وبطاقات الصعود الرقمية',
    'Flight Tickets & Boarding Passes',
    'Billets d’avion & Cartes d’embarquement',
    'documents',
    1,
    true,
    'carry_on',
    'مخزنة في محفظة TAKI-GO مع رمز QR دون إنترنت'
  );

  add(
    'hotel-voucher',
    'قسيمة الحجز الفندقي والتأمين السياحي',
    'Hotel Voucher & Travel Insurance',
    'Voucher Hôtel & Assurance Voyage',
    'documents',
    1,
    true,
    'carry_on',
    'مطلوبة أحياناً عند شرطة الحدود بالمطار'
  );

  add(
    'payment-cards',
    'بطاقات الدفع الدولية ونقد بالعملة المحلية (EUR/USD/DZD)',
    'Credit Cards & Foreign Currency Cash',
    'Cartes Bancaires & Devises',
    'documents',
    1,
    true,
    'carry_on',
    'ينصح ببطاقتين بنكيتين منفصلتين للطوارئ'
  );

  if (purpose === 'religious') {
    add(
      'umrah-permit',
      'تصريح نسك والعمرة والشهادات الصحية',
      'Nusuk Umrah Permit & Health Documents',
      'Permis Nusuk Omra',
      'documents',
      1,
      true,
      'carry_on',
      'تأكيد حجز الروضة الشريفة وتصاريح الحرم'
    );
  }

  // --- 2. ELECTRONICS ---
  add(
    'phone-charger',
    'شاحن الهاتف وكابلات الشحن السريع',
    'Phone Charger & Fast-Charge Cables',
    'Chargeur & Câbles Rapides',
    'electronics',
    2,
    true,
    'carry_on'
  );

  add(
    'power-bank',
    'بنك طاقة محمول (Power Bank ≤ 20,000mAh)',
    'Portable Power Bank (≤ 20,000mAh)',
    'Batterie Externe Portable',
    'electronics',
    1,
    true,
    'carry_on',
    'إلزامي وضعه في حقيبة اليد (ممنوع في الشحن الجوي)'
  );

  add(
    'universal-adapter',
    'محول كهربائي دولي عالمي (Universal Adapter)',
    'Universal Power Plug Adapter',
    'Adaptateur Prise Universel',
    'electronics',
    1,
    true,
    'carry_on',
    'للتوافق مع مقابس وجهتك الجغرافية'
  );

  add(
    'noise-earphones',
    'سماعات عازلة للضوضاء للطائرة',
    'Noise-Cancelling Headphones',
    'Écouteurs Anti-Bruit',
    'electronics',
    1,
    false,
    'carry_on',
    'راحة مثالية أثناء الرحلات الجوية الطويلة'
  );

  if (purpose === 'business') {
    add(
      'laptop-work',
      'الكمبيوتر المحمول والملحقات والشاحن',
      'Laptop & Business Accessories',
      'Ordinateur Portable & Accessoires',
      'electronics',
      1,
      true,
      'carry_on'
    );
  }

  // --- 3. CLOTHING (Dynamically calculated based on duration & climate) ---
  const tshirtsCount = Math.min(10, Math.max(3, Math.ceil(safeDays * 0.9)));
  const pantsCount = Math.min(5, Math.max(2, Math.ceil(safeDays * 0.4)));
  const underwearCount = safeDays + 2;
  const socksCount = safeDays + 2;

  add(
    'tshirts',
    `قمصان مريحة وتيشيرتات قطنية (${tshirtsCount} قطع)`,
    `Comfortable T-shirts/Shirts (${tshirtsCount} pcs)`,
    `T-shirts & Chemises (${tshirtsCount} pcs)`,
    'clothing',
    tshirtsCount,
    true,
    'checked'
  );

  add(
    'pants',
    `بناطيل مريحة للسفر والتنقل (${pantsCount} قطع)`,
    `Travel Pants/Jeans (${pantsCount} pcs)`,
    `Pantalons & Jeans (${pantsCount} pcs)`,
    'clothing',
    pantsCount,
    true,
    'checked'
  );

  add(
    'underwear',
    `ملابس داخلية قطنية (${underwearCount} أطقم)`,
    `Undergarments (${underwearCount} sets)`,
    `Sous-vêtements (${underwearCount} ensembles)`,
    'clothing',
    underwearCount,
    true,
    'checked'
  );

  add(
    'socks',
    `جوارب قطنية ومريحة للمشي (${socksCount} أزواج)`,
    `Socks (${socksCount} pairs)`,
    `Chaussettes de marche (${socksCount} paires)`,
    'clothing',
    socksCount,
    true,
    'checked'
  );

  add(
    'walking-shoes',
    'حذاء رياضي مريح للجولات الطويلة',
    'Comfortable Walking/Running Shoes',
    'Chaussures de Marche Confortables',
    'clothing',
    1,
    true,
    'carry_on',
    'ارتده في الطائرة لتوفير وزن ومساحة الحقيبة'
  );

  // Climate specific clothing
  if (climate === 'cold') {
    add(
      'winter-jacket',
      'سترة شتوية عازلة للرياح والمطر (Down Jacket)',
      'Heavy Winter Jacket / Parka',
      'Veste d’Hiver Chaude',
      'clothing',
      1,
      true,
      'checked'
    );
    add(
      'thermal-layers',
      'ملابس حرارية داخلية (Thermal Underwear)',
      'Thermal Base Layers',
      'Sous-vêtements Thermiques',
      'clothing',
      2,
      false,
      'checked'
    );
  } else if (climate === 'hot' || climate === 'tropical') {
    add(
      'summer-hat',
      'قبعة شمسية ونظارات شمسية مع حماية UV',
      'Sun Hat & UV Sunglasses',
      'Chapeau de Soleil & Lunettes UV',
      'clothing',
      1,
      false,
      'carry_on'
    );
    add(
      'swimwear',
      'ملابس سباحة وبحر سريعة الجفاف',
      'Swimwear / Beach Attire',
      'Maillot de Bain',
      'clothing',
      2,
      false,
      'checked'
    );
  }

  if (purpose === 'religious') {
    add(
      'ihram-garments',
      'ملابس الإحرام البيضاء وحزام مريح (للرجال)',
      'Ihram Attire & Secure Belt',
      'Tenue d’Ihram & Ceinture',
      'clothing',
      2,
      true,
      'carry_on',
      'احرص على أخذ طقم في حقيبة اليد تحسباً للإحرام بالطائرة'
    );
  }

  // --- 4. TOILETRIES & HEALTH ---
  add(
    'travel-toiletries',
    'مجموعة النظافة الشخصية للسفر (أقل من 100ml)',
    'Travel Toiletries Kit (≤ 100ml bottles)',
    'Kit de Toilette Voyage (≤ 100ml)',
    'toiletries',
    1,
    true,
    'checked',
    'فرشاة ومعجون أسنان، شامبو وصابون مصغر'
  );

  add(
    'first-aid-meds',
    'صيدلية الطوارئ الشخصية ومسكنات الألم',
    'Personal Meds & First-Aid Travel Pack',
    'Trousse à Pharmacie & Médicaments',
    'toiletries',
    1,
    true,
    'carry_on',
    'بانادول، مضاد للحساسية، وأدويتك الموصوفة'
  );

  if (climate === 'hot' || climate === 'tropical') {
    add(
      'sunscreen',
      'واقي شمس واسع النطاق (SPF 50+)',
      'High-Protection Sunscreen (SPF 50+)',
      'Crème Solaire Haute Protection',
      'toiletries',
      1,
      false,
      'checked'
    );
  }

  // --- 5. ESSENTIALS & EXTRAS ---
  add(
    'neck-pillow',
    'وسادة رقبة مريحة وغطاء عين للنوم',
    'Memory-Foam Travel Pillow & Eye Mask',
    'Coussin de Voyage & Masque de Sommeil',
    'essentials',
    1,
    false,
    'carry_on'
  );

  add(
    'water-bottle',
    'قارورة مياه فارغة قابلة لإعادة التعبئة',
    'Empty Reusable Water Bottle',
    'Gourde Réutilisable',
    'essentials',
    1,
    false,
    'carry_on',
    'املأها بعد اجتياز نقاط التفتيش بالمطار'
  );

  return items;
}

/**
 * Calculate completion stats for a packing items list.
 */
export function calculatePackingProgress(items: PackingItem[]): {
  total: number;
  packed: number;
  percentage: number;
  isComplete: boolean;
} {
  if (!items || items.length === 0) {
    return { total: 0, packed: 0, percentage: 0, isComplete: false };
  }
  const total = items.length;
  const packed = items.filter((item) => item.packed).length;
  const percentage = Math.round((packed / total) * 100);
  return {
    total,
    packed,
    percentage,
    isComplete: packed === total,
  };
}

/**
 * Toggle packed state of a specific item.
 */
export function toggleItemPacked(items: PackingItem[], itemId: string): PackingItem[] {
  return items.map((item) => {
    if (item.id === itemId) {
      return { ...item, packed: !item.packed };
    }
    return item;
  });
}

/**
 * Filter items by category, completion, and baggage type.
 */
export function filterPackingItems(
  items: PackingItem[],
  filters: {
    category?: PackingCategory | 'all';
    packedFilter?: 'all' | 'unpacked' | 'packed';
    baggageType?: 'all' | 'carry_on' | 'checked';
  }
): PackingItem[] {
  return items.filter((item) => {
    if (filters.category && filters.category !== 'all' && item.category !== filters.category) {
      return false;
    }
    if (filters.packedFilter === 'unpacked' && item.packed) {
      return false;
    }
    if (filters.packedFilter === 'packed' && !item.packed) {
      return false;
    }
    if (filters.baggageType && filters.baggageType !== 'all' && item.baggageType !== filters.baggageType) {
      return false;
    }
    return true;
  });
}

/**
 * Add custom user item to packing list.
 */
export function addCustomPackingItem(
  items: PackingItem[],
  newItem: {
    name: string;
    category: PackingCategory;
    quantity?: number;
    isEssential?: boolean;
    baggageType?: 'carry_on' | 'checked';
    tip?: string;
  }
): PackingItem[] {
  const created: PackingItem = {
    id: `custom-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    name: newItem.name.trim(),
    nameEn: newItem.name.trim(),
    nameFr: newItem.name.trim(),
    category: newItem.category,
    quantity: newItem.quantity && newItem.quantity > 0 ? newItem.quantity : 1,
    packed: false,
    isEssential: newItem.isEssential ?? false,
    baggageType: newItem.baggageType ?? 'checked',
    tip: newItem.tip,
  };
  return [created, ...items];
}

/**
 * Delete an item from packing list.
 */
export function deletePackingItem(items: PackingItem[], itemId: string): PackingItem[] {
  return items.filter((item) => item.id !== itemId);
}

/**
 * Storage helpers for persisting packing plan in local storage.
 */
export function savePackingPlan(plan: PackingPlan, storage: Storage = localStorage): void {
  try {
    storage.setItem(`${PACKING_STORAGE_KEY}_${plan.destination.toLowerCase().trim()}`, JSON.stringify(plan));
    storage.setItem(PACKING_STORAGE_KEY, JSON.stringify(plan));
  } catch (e) {
    console.error('Failed to save packing plan to storage:', e);
  }
}

export function loadSavedPackingPlan(destination?: string, storage: Storage = localStorage): PackingPlan | null {
  try {
    const key = destination
      ? `${PACKING_STORAGE_KEY}_${destination.toLowerCase().trim()}`
      : PACKING_STORAGE_KEY;
    const raw = storage.getItem(key);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}
