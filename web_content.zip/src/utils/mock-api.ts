/* ============================================
   plix_ai studio — Mock API (simulates real backend)
   ============================================ */

import type { BuildJob, BuildStage, BuildLog, Project } from '../types';
import { saveBuildJob } from '../store';

const STAGE_NAMES = ['Validate', 'Prepare', 'Package', 'Sign', 'Encrypt & Upload', 'Verify'] as const;

function createInitialStages(): BuildStage[] {
  return STAGE_NAMES.map(name => ({
    name,
    status: 'pending',
    progress: 0,
  }));
}

function generateLogs(stage: string, progress: number): BuildLog[] {
  const now = Date.now();
  const logs: BuildLog[] = [];
  const templates: Record<string, string[]> = {
    'Validate': [
      'Checking source integrity...',
      'Verifying manifest structure...',
      'Validating icon dimensions (512x512 ✓)',
      'Checking for mixed content warnings...',
      'Package ID format validated: com.example.app',
      'All preflight checks passed.',
    ],
    'Prepare': [
      'Creating build workspace...',
      'Extracting source files...',
      'Generating adaptive icon layers...',
      'Applying color scheme (#38bdf8 primary)...',
      'Configuring WebView wrapper template...',
      'Building resource manifest...',
      'Generating splash screen assets...',
    ],
    'Package': [
      'Initializing Gradle build system...',
      'Compiling WebView activity...',
      'Packaging web assets into /assets/www...',
      'Generating AndroidManifest.xml...',
      'Processing drawable resources...',
      'Running AAPT2 resource compilation...',
      'Building DEX bytecode...',
      'Assembling APK structure...',
      'Zipaligning package...',
    ],
    'Sign': [
      'Loading keystore (demo-key.jks)...',
      'Signing with v2 signature scheme...',
      'Generating SHA-256 digest...',
      'Verifying signature integrity...',
      'Signature verified successfully.',
    ],
    'Encrypt & Upload': [
      'Encrypting artifact with AES-256-GCM...',
      'Generating download token...',
      'Uploading to artifact storage...',
      'Setting expiration (72 hours)...',
      'Upload complete.',
    ],
    'Verify': [
      'Running final integrity check...',
      'Verifying APK structure...',
      'Checking file size (4.2 MB ✓)',
      'Generating checksums...',
      'SHA-256: a7f3b2c1d4e5...',
      'Build verification complete.',
    ],
  };

  const stageLogs = templates[stage] || [];
  const logCount = Math.floor((progress / 100) * stageLogs.length);

  for (let i = 0; i < logCount; i++) {
    logs.push({
      timestamp: now - (logCount - i) * 200,
      level: i === logCount - 1 && stage === 'Validate' && progress === 100 ? 'info' : 'debug',
      message: stageLogs[i],
    });
  }

  return logs;
}

// --- Simulate a build job ---
export function simulateBuild(project: Project, onProgress: (job: BuildJob) => void): () => void {
  const job: BuildJob = {
    id: crypto.randomUUID(),
    projectId: project.id,
    status: 'pending',
    stages: createInitialStages(),
    logs: [],
    progress: 0,
    createdAt: Date.now(),
  };

  let cancelled = false;
  let currentStage = 0;
  let stageProgress = 0;

  function tick() {
    if (cancelled) return;

    if (currentStage >= STAGE_NAMES.length) {
      job.status = 'completed';
      job.completedAt = Date.now();
      job.progress = 100;
      job.artifactSize = 3800000 + Math.floor(Math.random() * 2000000);
      job.checksumSha256 = generateMockChecksum();
      job.stages.forEach(s => { s.status = 'completed'; s.progress = 100; });
      onProgress(job);
      saveBuildJob(job);
      return;
    }

    const stage = job.stages[currentStage];
    stage.status = 'running';
    stage.startedAt = stage.startedAt || Date.now();

    const step = 5 + Math.random() * 10;
    stageProgress = Math.min(100, stageProgress + step);

    if (stageProgress >= 100) {
      stage.status = 'completed';
      stage.progress = 100;
      stage.completedAt = Date.now();
      job.logs.push(...generateLogs(STAGE_NAMES[currentStage], 100));
      currentStage++;
      stageProgress = 0;
    } else {
      stage.progress = Math.round(stageProgress);
      job.logs = [];
      for (let i = 0; i <= currentStage; i++) {
        job.logs.push(...generateLogs(STAGE_NAMES[i], i === currentStage ? stageProgress : 100));
      }
    }

    // Update overall progress
    const completedWeight = currentStage * (100 / STAGE_NAMES.length);
    const currentWeight = (stageProgress / STAGE_NAMES.length);
    job.progress = Math.round(completedWeight + currentWeight);
    job.status = job.progress > 0 ? 'validating' : 'pending';
    if (currentStage > 0) job.status = 'preparing';
    if (currentStage > 2) job.status = 'packaging';
    if (currentStage > 3) job.status = 'signing';
    if (currentStage > 4) job.status = 'uploading';
    if (currentStage > 5) job.status = 'verifying';

    if (!job.startedAt) job.startedAt = Date.now();

    onProgress(job);
    setTimeout(tick, 200 + Math.random() * 400);
  }

  setTimeout(tick, 500);

  return () => {
    cancelled = true;
    job.status = 'cancelled';
    onProgress(job);
  };
}

function generateMockChecksum(): string {
  const chars = '0123456789abcdef';
  let result = '';
  for (let i = 0; i < 64; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

// --- Mock URL validation ---
export async function validateUrl(url: string): Promise<{ valid: boolean; title?: string; error?: string }> {
  // Simulate network delay
  await new Promise(r => setTimeout(r, 800 + Math.random() * 600));

  try {
    const parsed = new URL(url);
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      return { valid: false, error: 'Only HTTP and HTTPS URLs are supported.' };
    }
    return {
      valid: true,
      title: parsed.hostname.replace('www.', ''),
    };
  } catch {
    return { valid: false, error: 'Invalid URL format. Please include https://' };
  }
}

// --- Mock PWA manifest fetch ---
export async function validateManifest(url: string): Promise<{
  valid: boolean;
  manifest?: { name: string; shortName: string; icons: number; startUrl: string };
  error?: string;
}> {
  await new Promise(r => setTimeout(r, 1200));
  try {
    new URL(url);
    return {
      valid: true,
      manifest: {
        name: 'Example PWA',
        shortName: 'Example',
        icons: 3,
        startUrl: '/',
      },
    };
  } catch {
    return { valid: false, error: 'Invalid manifest URL.' };
  }
}

// --- Preflight checks ---
export function runPreflightChecks(project: Project): Array<{ id: string; name: string; description: string; status: 'pass' | 'fail' | 'warn' | 'skip'; message?: string }> {
  const checks = [];

  // Icons
  checks.push({
    id: 'icon_512',
    name: 'App Icon (512×512)',
    description: 'High-res icon for Play Store listing',
    status: project.branding.logoDataUrl ? 'pass' as const : 'warn' as const,
    message: project.branding.logoDataUrl ? 'Logo uploaded' : 'No logo provided — using default placeholder',
  });

  checks.push({
    id: 'adaptive_icon',
    name: 'Adaptive Icon',
    description: 'Foreground + background layers for Android 8+',
    status: project.branding.logoDataUrl ? 'pass' as const : 'warn' as const,
  });

  // Package ID
  const pkgValid = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){2,}$/.test(project.branding.packageId);
  checks.push({
    id: 'package_id',
    name: 'Package ID Format',
    description: 'Must be reverse-domain notation (e.g., com.company.app)',
    status: pkgValid ? 'pass' as const : 'fail' as const,
    message: pkgValid ? project.branding.packageId : 'Invalid format',
  });

  // Version
  checks.push({
    id: 'version',
    name: 'Version Consistency',
    description: 'Version name and code should be consistent',
    status: project.branding.versionCode > 0 ? 'pass' as const : 'fail' as const,
  });

  // Mixed content
  checks.push({
    id: 'mixed_content',
    name: 'Mixed Content',
    description: 'Check for HTTP resources on HTTPS pages',
    status: project.buildConfig.mixedContentMode === 'never' ? 'pass' as const : 'warn' as const,
    message: project.buildConfig.mixedContentMode === 'never' ? 'Mixed content blocked' : 'Mixed content allowed — may cause warnings',
  });

  // Permissions
  const dangerousPerms = project.buildConfig.permissions.filter(p => p.dangerous && p.selected);
  checks.push({
    id: 'permissions',
    name: 'Permission Safety',
    description: 'Check for unnecessary dangerous permissions',
    status: dangerousPerms.length === 0 ? 'pass' as const : 'warn' as const,
    message: dangerousPerms.length > 0 ? `${dangerousPerms.length} dangerous permission(s) selected` : 'No dangerous permissions',
  });

  // Size check (simulated)
  checks.push({
    id: 'asset_size',
    name: 'Asset Size',
    description: 'Total bundled assets should be under 100MB',
    status: 'pass' as const,
    message: 'Estimated: ~4.2 MB',
  });

  // App name
  checks.push({
    id: 'app_name',
    name: 'App Name',
    description: 'Display name should be set',
    status: project.branding.appName.length > 0 ? 'pass' as const : 'fail' as const,
  });

  // Deep links
  if (project.buildConfig.deepLinks.length > 0) {
    const hasValidLink = project.buildConfig.deepLinks.every(dl => dl.scheme && dl.host);
    checks.push({
      id: 'deep_links',
      name: 'Deep Link Configuration',
      description: 'Verify scheme and host are set',
      status: hasValidLink ? 'pass' as const : 'fail' as const,
    });
  }

  return checks;
}

// --- Mock CLI snippets ---
export const CLI_SNIPPETS = [
  {
    id: 'gh-actions',
    title: 'GitHub Actions',
    platform: 'github-actions' as const,
    description: 'Automate APK builds on push to main',
    code: `name: Build Android APK
on:
  push:
    branches: [main]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build with plix_ai
        run: |
          curl -X POST https://api.plix.studio/api/jobs \\
            -H "Authorization: Bearer \${{ secrets.PLIX_API_KEY }}" \\
            -F "source=./dist.zip" \\
            -F "config=./plix.config.json"
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: app-release
          path: app-release.apk`,
  },
  {
    id: 'gitlab-ci',
    title: 'GitLab CI',
    platform: 'gitlab-ci' as const,
    description: 'CI/CD pipeline for GitLab repositories',
    code: `build:android:
  stage: build
  image: curlimages/curl:latest
  script:
    - curl -X POST https://api.plix.studio/api/jobs
        -H "Authorization: Bearer $PLIX_API_KEY"
        -F "source=./dist.zip"
        -F "config=./plix.config.json"
        -o build-response.json
    - cat build-response.json
  artifacts:
    paths:
      - "*.apk"`,
  },
  {
    id: 'cli',
    title: 'CLI (cURL)',
    platform: 'cli' as const,
    description: 'Direct API call from terminal',
    code: `# Create a conversion job
curl -X POST https://api.plix.studio/api/jobs \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: multipart/form-data" \\
  -F "source=@./my-site.zip" \\
  -F "config=@./plix.config.json" \\
  -F "format=apk"

# Poll job status
curl https://api.plix.studio/api/jobs/JOB_ID \\
  -H "Authorization: Bearer YOUR_API_KEY"

# Download artifact
curl -L https://api.plix.studio/api/jobs/JOB_ID/artifact \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -o app-release.apk`,
  },
];

// --- Mock API contract docs ---
export const API_CONTRACT = {
  baseUrl: 'https://api.plix.studio',
  version: 'v1',
  endpoints: [
    {
      method: 'POST',
      path: '/api/jobs',
      description: 'Create a new conversion job',
      auth: 'Bearer token',
      body: {
        source: 'File (multipart) or URL string',
        config: 'JSON — branding, build config, permissions',
        format: '"apk" | "aab"',
        callbackUrl: 'Optional webhook URL for completion',
      },
      response: {
        id: 'string (UUID)',
        status: '"pending"',
        createdAt: 'ISO timestamp',
      },
    },
    {
      method: 'GET',
      path: '/api/jobs/:id',
      description: 'Get job status, logs, and progress',
      response: {
        id: 'string',
        status: 'JobStatus',
        progress: 'number (0-100)',
        stages: 'BuildStage[]',
        logs: 'BuildLog[]',
        artifactUrl: 'string | null (signed, expires in 72h)',
        checksumSha256: 'string | null',
      },
    },
    {
      method: 'GET',
      path: '/api/jobs/:id/artifact',
      description: 'Download build artifact (redirects to signed URL)',
      response: 'Binary APK/AAB file',
    },
    {
      method: 'DELETE',
      path: '/api/jobs/:id',
      description: 'Cancel a running job or delete artifacts',
    },
    {
      method: 'POST',
      path: '/api/keystores/encrypt',
      description: 'Encrypt and store keystore (never logged)',
      body: {
        keystore: 'File (multipart)',
        alias: 'string',
        passwords: 'Encrypted JSON',
      },
    },
  ],
  security: [
    'All secrets encrypted at rest with AES-256-GCM',
    'Keystore passwords never logged or stored in plaintext',
    'Build containers are isolated and destroyed after each job',
    'Artifacts expire after 72 hours by default',
    'Malware scanning on all uploaded files',
    'Rate-limited: 100 jobs/hour per API key',
  ],
};

// --- Templates ---
export const TEMPLATES = [
  {
    id: 'blank-webview',
    name: 'Blank WebView',
    description: 'Empty Android WebView wrapper. Add your own HTML/JS.',
    icon: '📱',
    sourceType: 'html' as const,
    defaultBranding: {
      appName: 'My WebView App',
      displayName: 'My WebView App',
      packageId: 'com.example.webview',
    },
    tags: ['starter', 'webview'],
  },
  {
    id: 'pwa-wrapper',
    name: 'PWA Wrapper',
    description: 'Wrap an existing Progressive Web App for the Play Store.',
    icon: '🌐',
    sourceType: 'pwa' as const,
    defaultBranding: {
      appName: 'PWA App',
      displayName: 'PWA App',
      packageId: 'com.example.pwa',
    },
    tags: ['pwa', 'wrapper'],
  },
  {
    id: 'docs-site',
    name: 'Documentation Site',
    description: 'Package a static documentation site as a native app.',
    icon: '📖',
    sourceType: 'url' as const,
    defaultBranding: {
      appName: 'Docs',
      displayName: 'Documentation',
      packageId: 'com.example.docs',
    },
    tags: ['docs', 'static'],
  },
  {
    id: 'html-game',
    name: 'HTML Game',
    description: 'Full-screen WebView for HTML5 games with gamepad support.',
    icon: '🎮',
    sourceType: 'zip' as const,
    defaultBranding: {
      appName: 'My Game',
      displayName: 'My Game',
      packageId: 'com.example.game',
      orientation: 'landscape',
      fullscreen: true,
    },
    tags: ['game', 'fullscreen'],
  },
  {
    id: 'react-vite',
    name: 'React/Vite Web App',
    description: 'Build a React + Vite SPA and package for Android.',
    icon: '⚛️',
    sourceType: 'zip' as const,
    defaultBranding: {
      appName: 'React App',
      displayName: 'React App',
      packageId: 'com.example.react',
    },
    tags: ['react', 'vite', 'spa'],
  },
  {
    id: 'custom',
    name: 'Bring Your Own Build',
    description: 'Upload a pre-built ZIP, APK, or AAB for repackaging.',
    icon: '📦',
    sourceType: 'zip' as const,
    defaultBranding: {
      appName: 'Custom App',
      displayName: 'Custom App',
      packageId: 'com.example.custom',
    },
    tags: ['custom', 'advanced'],
  },
];