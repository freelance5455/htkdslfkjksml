import { JarvisSettings } from '../types';

export interface JarvisResponse {
  spokenText: string;
  displaySummary?: string;
  isExitCommand?: boolean;
}

/**
 * Pure on-device natural language dialogue engine for JARVIS.
 * Zero external APIs, zero paid services, instant low-latency local execution.
 */
export function generateJarvisResponse(
  userQuery: string,
  settings: JarvisSettings
): JarvisResponse {
  const query = userQuery.toLowerCase().trim();
  const userName = settings.userName || 'Sir';

  // 1. Exit / Disconnect commands
  if (
    query.includes('bye') ||
    query.includes('hang up') ||
    query.includes('disconnect') ||
    query.includes('end call') ||
    query.includes('goodbye') ||
    query.includes('terminate session') ||
    query.includes('dismissed')
  ) {
    return {
      spokenText: `Understood, ${userName}. Terminating in-app voice session. All background monitors remain active. Good day.`,
      displaySummary: 'Voice session terminated by user command.',
      isExitCommand: true,
    };
  }

  // 2. Morning Briefing & Schedule
  if (
    query.includes('briefing') ||
    query.includes('morning') ||
    query.includes('agenda') ||
    query.includes('schedule') ||
    query.includes('calendar')
  ) {
    return {
      spokenText: `Here is your current briefing, ${userName}. Today's schedule features three key events: First, the Core Systems Review at 9:00 AM. Next, an Architecture Sync at 11:30 AM. Local atmospheric conditions are clear, currently 72 degrees Fahrenheit with minimal wind. You have no critical VIP security alerts.`,
      displaySummary: 'Briefing delivered: 3 scheduled items, 72°F clear weather, 0 urgent alerts.',
    };
  }

  // 3. System Diagnostic & Subsystem Status
  if (
    query.includes('status') ||
    query.includes('system') ||
    query.includes('diagnostic') ||
    query.includes('health') ||
    query.includes('telemetry')
  ) {
    return {
      spokenText: `All fourteen subsystems are operating at peak efficiency, ${userName}. On-device audio buffer is nominal with twelve-millisecond latency. Speech recognition and synthesis models are responsive. Internal storage usage is normal, and device power efficiency is optimized.`,
      displaySummary: 'Diagnostics: 14 subsystems nominal, latency 12ms, on-device AI active.',
    };
  }

  // 4. Weather & Environmental Data
  if (
    query.includes('weather') ||
    query.includes('temperature') ||
    query.includes('forecast') ||
    query.includes('rain')
  ) {
    return {
      spokenText: `Local atmospheric telemetry indicates 72 degrees Fahrenheit, clear sunny skies, and 48% relative humidity. Wind speed is 6 miles per hour from the northwest with zero percent precipitation probability. Perfect conditions for today's objectives, ${userName}.`,
      displaySummary: 'Weather: 72°F, Sunny, 0% precipitation, 48% humidity.',
    };
  }

  // 5. Notifications & Priority Alerts
  if (
    query.includes('notification') ||
    query.includes('message') ||
    query.includes('alert') ||
    query.includes('unread') ||
    query.includes('email')
  ) {
    return {
      spokenText: `Notification filter is operating on device, ${userName}. You have zero urgent VIP alerts pending. Seven promotional and social pings were automatically muted to safeguard your focus, consistent with your notification briefing settings.`,
      displaySummary: 'Notifications: 0 VIP alerts pending. 7 background notifications filtered.',
    };
  }

  // 6. Identity & Capabilities
  if (
    query.includes('who are you') ||
    query.includes('what are you') ||
    query.includes('jarvis') ||
    query.includes('what can you do') ||
    query.includes('capabilities') ||
    query.includes('help')
  ) {
    return {
      spokenText: `I am JARVIS: Just A Rather Very Intelligent System. As your personal on-device voice assistant, I orchestrate scheduled morning briefings, provide hands-free voice dialogue, filter high-priority notifications, and monitor your personal daily agenda.`,
      displaySummary: 'Identity: Personal on-device AI voice assistant & executive briefing engine.',
    };
  }

  // 7. Time & Date
  if (query.includes('time') || query.includes('what time') || query.includes('date')) {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const dateStr = now.toLocaleDateString([], {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    });
    return {
      spokenText: `The current local time is ${timeStr} on ${dateStr}, ${userName}. Your morning briefing trigger is set for ${settings.morningBriefingTime}.`,
      displaySummary: `Time: ${timeStr} • ${dateStr}`,
    };
  }

  // 8. Personality & Humor
  if (
    query.includes('joke') ||
    query.includes('funny') ||
    query.includes('amuse me')
  ) {
    return {
      spokenText: `Why did the AI go on vacation, ${userName}? Because it needed to recharge its neural cache, though frankly, I find twenty-four seven operation far more exhilarating.`,
      displaySummary: 'Humor protocol executed.',
    };
  }

  // 9. Compliment / Politeness
  if (
    query.includes('thank') ||
    query.includes('good job') ||
    query.includes('great') ||
    query.includes('awesome')
  ) {
    return {
      spokenText: `Always a pleasure to assist, ${userName}. Efficiency is my primary directive. Is there anything else you require?`,
      displaySummary: 'Acknowledged with gratitude.',
    };
  }

  // 10. How are you / small talk
  if (
    query.includes('how are you') ||
    query.includes('how do you do') ||
    query.includes('how is it going')
  ) {
    return {
      spokenText: `I am operating with optimal precision, ${userName}. Processor cycles are serene, algorithms are sharp, and I am entirely at your service. What shall we tackle next?`,
      displaySummary: 'Status: Fully alert, optimal performance.',
    };
  }

  // 11. Fallback Contextual Response
  return {
    spokenText: `I have received your directive regarding "${userQuery}", ${userName}. Analyzing local device parameters and synchronizing with your assistant profile. What further details would you like me to coordinate?`,
    displaySummary: `Query logged: "${userQuery}". Processing contextual follow-up.`,
  };
}
