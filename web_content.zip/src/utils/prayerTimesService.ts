// Prayer Times Calculation Engine (100% Offline, Astronomical Algorithm with High Accuracy)
// Calculates Fajr, Sunrise (الشروق), Dhuhr, Asr, Maghrib, Isha based on latitude, longitude, and date.
// Supports standard calculation methods (Umm al-Qura Makkah, Egyptian General Authority of Survey, Muslim World League, ISNA, Karachi).

export interface Coordinates {
  latitude: number;
  longitude: number;
  city?: string;
  source: 'location' | 'preset' | 'default';
}

export type CalculationMethod = 'MWL' | 'Makkah' | 'Egypt' | 'ISNA' | 'Karachi';

export interface MethodParams {
  name: string;
  nameArabic: string;
  fajrAngle: number;
  ishaAngle?: number;
  ishaInterval?: number; // minutes after maghrib (e.g. 90 mins for Umm al-Qura)
}

export const CALCULATION_METHODS: Record<CalculationMethod, MethodParams> = {
  Makkah: {
    name: 'Umm al-Qura, Makkah',
    nameArabic: 'أم القرى (مكة المكرمة)',
    fajrAngle: 18.5,
    ishaInterval: 90,
  },
  Egypt: {
    name: 'Egyptian General Authority',
    nameArabic: 'الهيئة المصرية العامة للمساحة',
    fajrAngle: 19.5,
    ishaAngle: 17.5,
  },
  MWL: {
    name: 'Muslim World League',
    nameArabic: 'رابطة العالم الإسلامي',
    fajrAngle: 18,
    ishaAngle: 17,
  },
  ISNA: {
    name: 'Islamic Society of North America',
    nameArabic: 'أمريكا الشمالية (ISNA)',
    fajrAngle: 15,
    ishaAngle: 15,
  },
  Karachi: {
    name: 'University of Islamic Sciences, Karachi',
    nameArabic: 'جامعة العلوم الإسلامية بكراتشي',
    fajrAngle: 18,
    ishaAngle: 18,
  },
};

export type PrayerId = 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';

export interface PrayerTimeItem {
  id: PrayerId;
  nameArabic: string;
  nameEnglish: string;
  time: Date;
  timeFormatted: string; // e.g. "04:52 ص"
  isNext: boolean;
  isPassed: boolean;
  iconName: string;
}

export interface NextPrayerInfo {
  id: PrayerId;
  nameArabic: string;
  time: Date;
  timeFormatted: string;
  remainingSeconds: number;
  remainingFormatted: string; // e.g. "01:45:20" or "ساعة و45 دقيقة"
}

export interface PrayerTimesResult {
  date: Date;
  dateHijriFormatted?: string;
  city: string;
  coordinates: Coordinates;
  method: CalculationMethod;
  prayers: PrayerTimeItem[];
  nextPrayer: NextPrayerInfo;
  previousPrayer: PrayerTimeItem | null;
}

// Math helpers for spherical astronomy
const D2R = Math.PI / 180.0;
const R2D = 180.0 / Math.PI;

function sinD(deg: number): number {
  return Math.sin(deg * D2R);
}

function cosD(deg: number): number {
  return Math.cos(deg * D2R);
}

function tanD(deg: number): number {
  return Math.tan(deg * D2R);
}

function asinD(x: number): number {
  return Math.asin(x) * R2D;
}

function acosD(x: number): number {
  return Math.acos(x) * R2D;
}

function atan2D(y: number, x: number): number {
  return Math.atan2(y, x) * R2D;
}

function fixAngle(a: number): number {
  let res = a - 360.0 * Math.floor(a / 360.0);
  if (res < 0) res += 360.0;
  return res;
}

function fixHour(a: number): number {
  let res = a - 24.0 * Math.floor(a / 24.0);
  if (res < 0) res += 24.0;
  return res;
}

/**
 * Sun's Astronomical Position & Declination
 */
function sunPosition(julianDate: number) {
  const D = julianDate - 2451545.0;
  const g = fixAngle(357.529 + 0.98560028 * D);
  const q = fixAngle(280.459 + 0.98564736 * D);
  const L = fixAngle(q + 1.915 * sinD(g) + 0.020 * sinD(2 * g));
  const e = 23.439 - 0.00000036 * D;
  const d = asinD(sinD(e) * sinD(L));
  let RA = atan2D(cosD(e) * sinD(L), cosD(L)) / 15.0;
  RA = fixHour(RA);
  const EqT = q / 15.0 - RA;
  return { declination: d, equationOfTime: EqT };
}

function julianDay(year: number, month: number, day: number): number {
  if (month <= 2) {
    year -= 1;
    month += 12;
  }
  const A = Math.floor(year / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + B - 1524.5;
}

/**
 * Time difference for given sun altitude angle
 */
function sunAngleTime(angle: number, lat: number, dec: number, isSunrise: boolean): number {
  const cosH = (sinD(angle) - sinD(lat) * sinD(dec)) / (cosD(lat) * cosD(dec));
  if (cosH > 1.0) return 0; // Sun never reaches angle
  if (cosH < -1.0) return 12; // Sun always below angle
  const H = acosD(cosH) / 15.0;
  return isSunrise ? -H : H;
}

/**
 * Asr time calculation (Shafi/Hanbali/Maliki standard: shadow factor = 1)
 */
function asrTime(shadowFactor: number, lat: number, dec: number): number {
  const d = -Math.atan(1.0 / (shadowFactor + Math.tan(Math.abs(lat - dec) * D2R))) * R2D;
  return sunAngleTime(d, lat, dec, false);
}

/**
 * Formats time in standard Arabic 12-hour format with AM/PM (ص / م)
 */
export function formatArabicPrayerTime(d: Date): string {
  let hours = d.getHours();
  const minutes = d.getMinutes();
  const isPM = hours >= 12;
  hours = hours % 12;
  if (hours === 0) hours = 12;

  const hStr = hours < 10 ? `0${hours}` : `${hours}`;
  const mStr = minutes < 10 ? `0${minutes}` : `${minutes}`;
  const period = isPM ? 'م' : 'ص';

  return `${hStr}:${mStr} ${period}`;
}

export function formatRemainingTime(seconds: number): string {
  if (seconds <= 0) return 'الآن';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

export function formatRemainingTimeArabicWords(seconds: number): string {
  if (seconds <= 60) return 'أقل من دقيقة';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);

  if (h === 0) {
    return `${m} دقيقة`;
  }
  if (h === 1 && m === 0) return 'ساعة واحدة';
  if (h === 1) return `ساعة و${m} دقيقة`;
  if (h === 2 && m === 0) return 'ساعتان';
  if (h === 2) return `ساعتان و${m} دقيقة`;
  if (m === 0) return `${h} ساعات`;
  return `${h} ساعات و${m} دقيقة`;
}

/**
 * Approximate Hijri Date Formatter
 */
export function getArabicHijriDate(date: Date): string {
  try {
    const formatter = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
    return formatter.format(date);
  } catch {
    return 'التاريخ الهجري المبارك';
  }
}

/**
 * Main Prayer Calculation Function
 */
export function calculatePrayerTimes(
  date: Date,
  lat: number,
  lng: number,
  method: CalculationMethod = 'Makkah',
  cityName: string = 'موقعك الجغرافي'
): PrayerTimesResult {
  const methodParams = CALCULATION_METHODS[method] || CALCULATION_METHODS.Makkah;

  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();

  const jd = julianDay(year, month, day);
  const { declination, equationOfTime } = sunPosition(jd);

  // Timezone offset in hours
  // Date.getTimezoneOffset() returns minutes west of UTC, so invert sign
  const tzOffset = -date.getTimezoneOffset() / 60.0;

  // Midday / Solar Noon (Dhuhr)
  const noon = fixHour(12.0 + tzOffset - lng / 15.0 - equationOfTime);

  // Fajr
  const fajrDiff = sunAngleTime(-methodParams.fajrAngle, lat, declination, true);
  const fajrHour = noon + fajrDiff;

  // Sunrise (Zenith 90.833° accounting for refraction and solar diameter)
  const sunriseDiff = sunAngleTime(-0.833, lat, declination, true);
  const sunriseHour = noon + sunriseDiff;

  // Asr (Shafi/Hanbali: shadow factor = 1)
  const asrDiff = asrTime(1, lat, declination);
  const asrHour = noon + asrDiff;

  // Maghrib / Sunset
  const sunsetDiff = sunAngleTime(-0.833, lat, declination, false);
  const maghribHour = noon + sunsetDiff;

  // Isha
  let ishaHour: number;
  if (methodParams.ishaInterval) {
    ishaHour = maghribHour + methodParams.ishaInterval / 60.0;
  } else if (methodParams.ishaAngle) {
    const ishaDiff = sunAngleTime(-methodParams.ishaAngle, lat, declination, false);
    ishaHour = noon + ishaDiff;
  } else {
    ishaHour = maghribHour + 1.5;
  }

  // Construct Date objects
  const makeDate = (hoursFraction: number): Date => {
    const d = new Date(date);
    const fixedH = fixHour(hoursFraction);
    const h = Math.floor(fixedH);
    const m = Math.floor((fixedH - h) * 60);
    const s = Math.floor(((fixedH - h) * 60 - m) * 60);
    d.setHours(h, m, s, 0);
    return d;
  };

  const fajrTime = makeDate(fajrHour);
  const sunriseTime = makeDate(sunriseHour);
  const dhuhrTime = makeDate(noon);
  const asrTimeObj = makeDate(asrHour);
  const maghribTime = makeDate(maghribHour);
  const ishaTime = makeDate(ishaHour);

  const rawPrayers: { id: PrayerId; nameArabic: string; nameEnglish: string; time: Date; icon: string }[] = [
    { id: 'fajr', nameArabic: 'الفجر', nameEnglish: 'Fajr', time: fajrTime, icon: 'Sunrise' },
    { id: 'sunrise', nameArabic: 'الشروق', nameEnglish: 'Sunrise', time: sunriseTime, icon: 'Sun' },
    { id: 'dhuhr', nameArabic: 'الظهر', nameEnglish: 'Dhuhr', time: dhuhrTime, icon: 'SunMedium' },
    { id: 'asr', nameArabic: 'العصر', nameEnglish: 'Asr', time: asrTimeObj, icon: 'Sunset' },
    { id: 'maghrib', nameArabic: 'المغرب', nameEnglish: 'Maghrib', time: maghribTime, icon: 'Moon' },
    { id: 'isha', nameArabic: 'العشاء', nameEnglish: 'Isha', time: ishaTime, icon: 'MoonStar' },
  ];

  const now = date.getTime();
  let nextIdx = rawPrayers.findIndex((p) => p.time.getTime() > now);

  // If all prayers passed today, the next prayer is Fajr tomorrow
  let isTomorrowFajr = false;
  let nextPrayerTargetTime: Date;
  let nextPrayerId: PrayerId = 'fajr';
  let nextPrayerNameArabic = 'الفجر';

  if (nextIdx === -1) {
    isTomorrowFajr = true;
    nextPrayerTargetTime = new Date(fajrTime);
    nextPrayerTargetTime.setDate(nextPrayerTargetTime.getDate() + 1);
    nextPrayerId = 'fajr';
    nextPrayerNameArabic = 'الفجر (غداً)';
  } else {
    nextPrayerTargetTime = rawPrayers[nextIdx].time;
    nextPrayerId = rawPrayers[nextIdx].id;
    nextPrayerNameArabic = rawPrayers[nextIdx].nameArabic;
  }

  const remainingMs = Math.max(0, nextPrayerTargetTime.getTime() - now);
  const remainingSeconds = Math.floor(remainingMs / 1000);

  const prayers: PrayerTimeItem[] = rawPrayers.map((p, idx) => {
    const isPassed = p.time.getTime() <= now;
    const isNext = !isTomorrowFajr ? idx === nextIdx : false;
    return {
      id: p.id,
      nameArabic: p.nameArabic,
      nameEnglish: p.nameEnglish,
      time: p.time,
      timeFormatted: formatArabicPrayerTime(p.time),
      isNext,
      isPassed,
      iconName: p.icon,
    };
  });

  // Previous prayer
  let previousPrayer: PrayerTimeItem | null = null;
  for (let i = prayers.length - 1; i >= 0; i--) {
    if (prayers[i].isPassed) {
      previousPrayer = prayers[i];
      break;
    }
  }

  const nextPrayer: NextPrayerInfo = {
    id: nextPrayerId,
    nameArabic: nextPrayerNameArabic,
    time: nextPrayerTargetTime,
    timeFormatted: formatArabicPrayerTime(nextPrayerTargetTime),
    remainingSeconds,
    remainingFormatted: formatRemainingTime(remainingSeconds),
  };

  return {
    date,
    dateHijriFormatted: getArabicHijriDate(date),
    city: cityName,
    coordinates: {
      latitude: lat,
      longitude: lng,
      city: cityName,
      source: 'location',
    },
    method,
    prayers,
    nextPrayer,
    previousPrayer,
  };
}
