export interface AgeBreakdown {
  years: number;
  months: number;
  days: number;
  totalMonths: number;
  totalWeeks: number;
  totalDays: number;
  totalHours: number;
  totalMinutes: number;
  totalSeconds: number;
  isBirthdayToday: boolean;
  generation: string;
}

export interface NextBirthdayInfo {
  date: Date;
  formattedDate: string;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  daysLeftHeadline: number;
  turningAge: number;
  yearProgressPct: number;
}

export interface MilestoneItem {
  id: string;
  title: string;
  subtitle: string;
  targetDate: Date;
  formattedDate: string;
  achieved: boolean;
  relativeLabel: string;
}

export type PlanetKey = 'mercury' | 'venus' | 'mars' | 'jupiter' | 'saturn' | 'uranus';

export interface PlanetaryAgeItem {
  key: PlanetKey;
  name: string;
  ageYears: string;
  orbitalPeriodDays: number;
  nextBirthdayDays: number;
}

export interface BirthDetailsInfo {
  dayBorn: string;
  formattedBirthDate: string;
  zodiacName: string;
  zodiacSymbol: string;
  chineseZodiac: string;
  birthstone: string;
  season: string;
  isLeapYear: boolean;
}

export interface LifetimeStatItem {
  id: 'heartbeats' | 'breaths' | 'sleep' | 'meals' | 'words' | 'moons';
  label: string;
  value: number;
  unitHint: string;
}

export interface AgeAnalytics {
  birthDate: Date;
  referenceDate: Date;
  breakdown: AgeBreakdown;
  nextBirthday: NextBirthdayInfo;
  milestones: MilestoneItem[];
  planets: PlanetaryAgeItem[];
  birthDetails: BirthDetailsInfo;
  lifetimeStats: LifetimeStatItem[];
  summaryText: string;
}

const ZODIAC_TABLE: Array<[string, string, number]> = [
  ['Capricorn', '♑', 1222],
  ['Aquarius', '♒', 120],
  ['Pisces', '♓', 219],
  ['Aries', '♈', 321],
  ['Taurus', '♉', 420],
  ['Gemini', '♊', 521],
  ['Cancer', '♋', 621],
  ['Leo', '♌', 723],
  ['Virgo', '♍', 823],
  ['Libra', '♎', 923],
  ['Scorpio', '♏', 1023],
  ['Sagittarius', '♐', 1122],
  ['Capricorn', '♑', 1222],
];

const CHINESE_ANIMALS = [
  'Rat',
  'Ox',
  'Tiger',
  'Rabbit',
  'Dragon',
  'Snake',
  'Horse',
  'Goat',
  'Monkey',
  'Rooster',
  'Dog',
  'Pig',
];

const BIRTHSTONES = [
  'Garnet',
  'Amethyst',
  'Aquamarine',
  'Diamond',
  'Emerald',
  'Pearl',
  'Ruby',
  'Peridot',
  'Sapphire',
  'Opal',
  'Topaz',
  'Turquoise',
];

const WEEKDAYS = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
];

export function formatInteger(n: number): string {
  return Math.floor(Math.max(0, n)).toLocaleString('en-US');
}

export function padTwo(n: number): string {
  return String(Math.max(0, Math.floor(n))).padStart(2, '0');
}

export function safeDate(year: number, month: number, day: number, hour: number, minute: number): Date {
  const dt = new Date(year, month, day, hour, minute, 0, 0);
  if (dt.getMonth() !== month) {
    dt.setDate(0);
  }
  return dt;
}

export function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

export function getZodiac(month1to12: number, day: number): [string, string] {
  const md = month1to12 * 100 + day;
  for (let i = 1; i < ZODIAC_TABLE.length; i++) {
    if (md < ZODIAC_TABLE[i][2]) {
      return [ZODIAC_TABLE[i - 1][0], ZODIAC_TABLE[i - 1][1]];
    }
  }
  return [ZODIAC_TABLE[0][0], ZODIAC_TABLE[0][1]];
}

export function getGeneration(year: number): string {
  if (year >= 2013) return 'Gen Alpha';
  if (year >= 1997) return 'Gen Z';
  if (year >= 1981) return 'Millennial';
  if (year >= 1965) return 'Gen X';
  if (year >= 1946) return 'Baby Boomer';
  return 'Silent Gen';
}

function formatRelativeDays(diffMs: number): string {
  const absDays = Math.round(Math.abs(diffMs) / 86400000);
  if (absDays === 0) return diffMs >= 0 ? 'Today' : 'Today';
  const suffix = diffMs >= 0 ? 'ago' : 'from now';
  if (absDays < 30) return `${absDays} day${absDays === 1 ? '' : 's'} ${suffix}`;
  const months = Math.round(absDays / 30.4375);
  if (months < 12) return `${months} month${months === 1 ? '' : 's'} ${suffix}`;
  const years = (absDays / 365.25).toFixed(1).replace(/\.0$/, '');
  return `${years} year${years === '1' ? '' : 's'} ${suffix}`;
}

export function calculateAgeAnalytics(birthDate: Date, referenceDate: Date): AgeAnalytics {
  const endDay = new Date(referenceDate.getFullYear(), referenceDate.getMonth(), referenceDate.getDate());
  const bMin = birthDate.getHours() * 60 + birthDate.getMinutes();
  const nMin = referenceDate.getHours() * 60 + referenceDate.getMinutes();
  if (nMin < bMin) {
    endDay.setDate(endDay.getDate() - 1);
  }

  const bDay = new Date(birthDate.getFullYear(), birthDate.getMonth(), birthDate.getDate());
  let years = endDay.getFullYear() - bDay.getFullYear();
  let months = endDay.getMonth() - bDay.getMonth();
  let days = endDay.getDate() - bDay.getDate();

  if (days < 0) {
    months--;
    days += new Date(endDay.getFullYear(), endDay.getMonth(), 0).getDate();
  }
  if (months < 0) {
    years--;
    months += 12;
  }

  years = Math.max(0, years);
  months = Math.max(0, months);
  days = Math.max(0, days);

  const ms = Math.max(0, referenceDate.getTime() - birthDate.getTime());
  const totalSeconds = Math.floor(ms / 1000);
  const totalMinutes = Math.floor(ms / 60000);
  const totalHours = Math.floor(ms / 3600000);
  const totalDays = Math.floor(ms / 86400000);
  const totalWeeks = Math.floor(totalDays / 7);
  const totalMonths = years * 12 + months;

  const bdThisYear = safeDate(
    referenceDate.getFullYear(),
    birthDate.getMonth(),
    birthDate.getDate(),
    birthDate.getHours(),
    birthDate.getMinutes(),
  );
  const isBirthdayToday =
    bdThisYear.getMonth() === referenceDate.getMonth() &&
    bdThisYear.getDate() === referenceDate.getDate();

  const generation = getGeneration(birthDate.getFullYear());

  let next = bdThisYear;
  if (next.getTime() <= referenceDate.getTime()) {
    next = safeDate(
      referenceDate.getFullYear() + 1,
      birthDate.getMonth(),
      birthDate.getDate(),
      birthDate.getHours(),
      birthDate.getMinutes(),
    );
  }

  const diff = Math.max(0, next.getTime() - referenceDate.getTime());
  const cdDays = Math.floor(diff / 86400000);
  const cdHours = Math.floor(diff / 3600000) % 24;
  const cdMinutes = Math.floor(diff / 60000) % 60;
  const cdSeconds = Math.floor(diff / 1000) % 60;
  const daysLeftHeadline = Math.ceil(diff / 86400000);

  const last = safeDate(
    next.getFullYear() - 1,
    birthDate.getMonth(),
    birthDate.getDate(),
    birthDate.getHours(),
    birthDate.getMinutes(),
  );
  const span = Math.max(1, next.getTime() - last.getTime());
  const yearProgressPct = Math.min(100, Math.max(0, ((referenceDate.getTime() - last.getTime()) / span) * 100));

  const nextBirthday: NextBirthdayInfo = {
    date: next,
    formattedDate: next.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }),
    days: cdDays,
    hours: cdHours,
    minutes: cdMinutes,
    seconds: cdSeconds,
    daysLeftHeadline,
    turningAge: next.getFullYear() - birthDate.getFullYear(),
    yearProgressPct,
  };

  const rawMilestones: Array<{ id: string; title: string; subtitle: string; targetDate: Date }> = [
    {
      id: '10k-days',
      title: '10,000 Days Alive',
      subtitle: 'Approx. 27.4 Earth years',
      targetDate: new Date(birthDate.getTime() + 10000 * 86400000),
    },
    {
      id: '1b-sec',
      title: '1 Billion Seconds',
      subtitle: 'Approx. 31.7 Earth years',
      targetDate: new Date(birthDate.getTime() + 1000000000 * 1000),
    },
    {
      id: '15k-days',
      title: '15,000 Days Alive',
      subtitle: 'Approx. 41.1 Earth years',
      targetDate: new Date(birthDate.getTime() + 15000 * 86400000),
    },
    {
      id: 'golden-50',
      title: 'Golden Jubilee (50 Years)',
      subtitle: 'Half-century solar milestone',
      targetDate: safeDate(
        birthDate.getFullYear() + 50,
        birthDate.getMonth(),
        birthDate.getDate(),
        birthDate.getHours(),
        birthDate.getMinutes(),
      ),
    },
    {
      id: '20k-days',
      title: '20,000 Days Alive',
      subtitle: 'Approx. 54.8 Earth years',
      targetDate: new Date(birthDate.getTime() + 20000 * 86400000),
    },
  ];

  const milestones: MilestoneItem[] = rawMilestones.map((m) => {
    const achieved = referenceDate.getTime() >= m.targetDate.getTime();
    return {
      id: m.id,
      title: m.title,
      subtitle: m.subtitle,
      targetDate: m.targetDate,
      formattedDate: m.targetDate.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }),
      achieved,
      relativeLabel: formatRelativeDays(referenceDate.getTime() - m.targetDate.getTime()),
    };
  });

  const earthYears = ms / (365.25 * 86400000);
  const planetDefs: Array<{ key: PlanetKey; name: string; ratio: number; decimals: number }> = [
    { key: 'mercury', name: 'Mercury', ratio: 0.2408467, decimals: 1 },
    { key: 'venus', name: 'Venus', ratio: 0.61519726, decimals: 1 },
    { key: 'mars', name: 'Mars', ratio: 1.8808158, decimals: 1 },
    { key: 'jupiter', name: 'Jupiter', ratio: 11.862615, decimals: 2 },
    { key: 'saturn', name: 'Saturn', ratio: 29.447498, decimals: 2 },
    { key: 'uranus', name: 'Uranus', ratio: 84.016846, decimals: 2 },
  ];

  const planets: PlanetaryAgeItem[] = planetDefs.map((p) => {
    const orbitalPeriodDays = Math.round(p.ratio * 365.25);
    const planetaryYears = earthYears / p.ratio;
    const fractionToNext = 1 - (planetaryYears - Math.floor(planetaryYears));
    const nextBirthdayDays = Math.max(1, Math.round(fractionToNext * orbitalPeriodDays));
    return {
      key: p.key,
      name: p.name,
      ageYears: planetaryYears.toFixed(p.decimals),
      orbitalPeriodDays,
      nextBirthdayDays,
    };
  });

  const [zodiacName, zodiacSymbol] = getZodiac(birthDate.getMonth() + 1, birthDate.getDate());
  const chineseZodiac = CHINESE_ANIMALS[(((birthDate.getFullYear() - 4) % 12) + 12) % 12];
  const birthstone = BIRTHSTONES[birthDate.getMonth()];
  const month1to12 = birthDate.getMonth() + 1;
  const season =
    month1to12 === 12 || month1to12 <= 2
      ? 'Winter'
      : month1to12 <= 5
        ? 'Spring'
        : month1to12 <= 8
          ? 'Summer'
          : 'Autumn';

  const birthDetails: BirthDetailsInfo = {
    dayBorn: WEEKDAYS[birthDate.getDay()],
    formattedBirthDate: birthDate.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }),
    zodiacName,
    zodiacSymbol,
    chineseZodiac,
    birthstone,
    season,
    isLeapYear: isLeapYear(birthDate.getFullYear()),
  };

  const mins = ms / 60000;
  const lifetimeStats: LifetimeStatItem[] = [
    { id: 'heartbeats', label: 'Heartbeats', value: mins * 72, unitHint: '~72 bpm avg' },
    { id: 'breaths', label: 'Breaths Taken', value: mins * 16, unitHint: '~16/min avg' },
    { id: 'sleep', label: 'Hours Slept', value: totalHours / 3, unitHint: '~8 hrs/day' },
    { id: 'meals', label: 'Meals Eaten', value: totalDays * 3, unitHint: '~3 meals/day' },
    { id: 'words', label: 'Words Spoken', value: totalDays * 16000, unitHint: '~16k words/day' },
    { id: 'moons', label: 'Full Moons', value: totalDays / 29.53, unitHint: '29.53-day lunar cycle' },
  ];

  const marsAge = (earthYears / 1.8808158).toFixed(1);
  const summaryText = [
    `ChronoAge Pro Summary`,
    `Exact Age: ${years} Years, ${months} Months, ${days} Days (${formatInteger(totalDays)} days total)`,
    `Next Birthday: ${nextBirthday.formattedDate} (${isBirthdayToday && cdDays === 0 ? 'Today!' : `${daysLeftHeadline} days left`})`,
    `Zodiac: ${zodiacSymbol} ${zodiacName} · Chinese Zodiac: ${chineseZodiac} · Mars Age: ${marsAge} yrs`,
  ].join('\n');

  return {
    birthDate,
    referenceDate,
    breakdown: {
      years,
      months,
      days,
      totalMonths,
      totalWeeks,
      totalDays,
      totalHours,
      totalMinutes,
      totalSeconds,
      isBirthdayToday,
      generation,
    },
    nextBirthday,
    milestones,
    planets,
    birthDetails,
    lifetimeStats,
    summaryText,
  };
}
