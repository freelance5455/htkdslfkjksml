/**
 * TAKI-GO App Import & Export Utility
 * Handles exporting and importing travel dossiers, wallet documents, and app state.
 */

import { TravelTrip, WalletDocument, UserProfile } from '../types';

export interface AppExportData {
  version: string;
  exportedAt: string;
  source: 'TAKI-GO | Tourism By Taki';
  user?: Partial<UserProfile>;
  activeTrip?: TravelTrip;
  walletDocuments?: WalletDocument[];
  metadata: {
    totalDocuments: number;
    destinationCity?: string;
  };
}

export interface ImportValidationResult {
  valid: boolean;
  error?: string;
  data?: AppExportData;
  summary?: {
    hasTrip: boolean;
    tripDestination?: string;
    documentsCount: number;
    userName?: string;
  };
}

/**
 * Creates a structured export backup of the application state.
 */
export function createAppExport(
  activeTrip?: TravelTrip,
  walletDocuments?: WalletDocument[],
  user?: UserProfile
): AppExportData {
  return {
    version: '1.2.0',
    exportedAt: new Date().toISOString(),
    source: 'TAKI-GO | Tourism By Taki',
    user: user
      ? {
          id: user.id,
          fullName: user.fullName,
          email: user.email,
          passportNumber: user.passportNumber,
          nationality: user.nationality,
          language: user.language,
          currency: user.currency,
        }
      : undefined,
    activeTrip,
    walletDocuments,
    metadata: {
      totalDocuments: walletDocuments ? walletDocuments.length : 0,
      destinationCity: activeTrip?.destinationCity,
    },
  };
}

/**
 * Validates and safely parses an imported JSON backup string.
 */
export function validateImportData(rawJson: string): ImportValidationResult {
  if (!rawJson || !rawJson.trim()) {
    return { valid: false, error: 'Empty file or input provided' };
  }

  try {
    const parsed = JSON.parse(rawJson);

    // Validate structure
    if (typeof parsed !== 'object' || parsed === null) {
      return { valid: false, error: 'Invalid JSON format: root must be an object' };
    }

    const hasTrip = Boolean(parsed.activeTrip && parsed.activeTrip.id && parsed.activeTrip.destinationCity);
    const hasDocs = Array.isArray(parsed.walletDocuments);

    if (!hasTrip && !hasDocs && !parsed.user) {
      return {
        valid: false,
        error: 'Unsupported backup format. Expected activeTrip, walletDocuments, or user profile data.',
      };
    }

    return {
      valid: true,
      data: parsed as AppExportData,
      summary: {
        hasTrip,
        tripDestination: parsed.activeTrip?.destinationCity,
        documentsCount: hasDocs ? parsed.walletDocuments.length : 0,
        userName: parsed.user?.fullName,
      },
    };
  } catch (err) {
    return {
      valid: false,
      error: `JSON parse error: ${err instanceof Error ? err.message : 'Syntax error'}`,
    };
  }
}

/**
 * Triggers client-side browser file download for exported JSON.
 */
export function downloadBackupFile(exportData: AppExportData, filename: string = 'takigo-app-export.json') {
  try {
    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    return true;
  } catch {
    return false;
  }
}
