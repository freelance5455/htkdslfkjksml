import assert from 'node:assert/strict';
import { buildDailyActivitySeries, extractTimestampMillis } from './adminStats';

// 1. Timestamp extraction across Firestore Timestamp, Date, number, and ISO strings
{
  const date = new Date(2026, 10, 16, 10, 30, 0);
  assert.equal(extractTimestampMillis(date), date.getTime());
  assert.equal(extractTimestampMillis(date.getTime()), date.getTime());
  assert.equal(extractTimestampMillis({ toMillis: () => date.getTime() }), date.getTime());
  assert.equal(extractTimestampMillis({ seconds: 1700000000, nanoseconds: 500_000_000 }), 1700000000500);
  assert.equal(extractTimestampMillis(null), null);
}

// 2. Daily bucketing across student signups and quiz attempts
{
  const ref = new Date(2026, 10, 16, 12, 0, 0);
  const twoDaysAgo = new Date(2026, 10, 14, 9, 15, 0);
  const today = new Date(2026, 10, 16, 16, 45, 0);
  const outOfRange = new Date(2026, 9, 1, 12, 0, 0);

  const series = buildDailyActivitySeries({
    days: 7,
    referenceDate: ref,
    students: [
      { createdAt: twoDaysAgo },
      { createdAt: { toDate: () => today } },
      { createdAt: { toMillis: () => today.getTime() } },
      { createdAt: outOfRange },
      { createdAt: null },
    ],
    quizAttempts: [
      { updatedAt: twoDaysAgo },
      { updatedAt: twoDaysAgo },
      { updatedAt: today },
      { updatedAt: outOfRange },
    ],
  });

  assert.equal(series.length, 7);
  assert.equal(series[0].dateKey, '2026-11-10');
  assert.equal(series[6].dateKey, '2026-11-16');

  const nov14 = series.find((p) => p.dateKey === '2026-11-14');
  const nov16 = series.find((p) => p.dateKey === '2026-11-16');
  assert.equal(nov14?.signups, 1);
  assert.equal(nov14?.quizAttempts, 2);
  assert.equal(nov16?.signups, 2);
  assert.equal(nov16?.quizAttempts, 1);
}

console.log('All Admin Dashboard recent activity aggregation tests passed.');
