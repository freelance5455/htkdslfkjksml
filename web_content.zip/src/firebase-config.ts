import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { getFirestore } from "firebase/firestore";
import { getDataConnect } from "firebase/data-connect";
import firebaseAppletConfig from "../firebase-applet-config.json";

export const firebaseConfig = firebaseAppletConfig;

// Modo desarrollo seguro
if (typeof window !== "undefined" && (import.meta as any).env?.DEV) {
  (self as any).FIREBASE_APPCHECK_DEBUG_TOKEN = true;
}

export const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const storage = getStorage(app);
export const db = (firebaseConfig as any).firestoreDatabaseId
  ? getFirestore(app, (firebaseConfig as any).firestoreDatabaseId)
  : getFirestore(app);

export const dataConnect = (() => {
  try {
    return getDataConnect(app, {
      connector: "sono-radio-connector",
      location: "us-central1",
      service: "sono-radio-service"
    });
  } catch (err) {
    console.warn("Firebase Data Connect inicializado en modo diferido:", err);
    return null;
  }
})();

// 👤 ADMIN OFICIAL
export const ADMIN = {
  nombre: "Efraín Flores Díaz",
  telefono: "+523345926162",
  correo: "sonovisionlatiz@gmail.com"
};

let mediaRecorder: MediaRecorder | null = null;
let fragmentos: BlobPart[] = [];
let canal = "general";

export function setCanalPTT(nuevoCanal: string) {
  canal = nuevoCanal;
}

export function getCanalPTT() {
  return canal;
}

// 🎙️ BOTÓN VOL+ / PRESIONAR
export async function iniciarPTT() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);
    fragmentos = [];
    mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        fragmentos.push(e.data);
      }
    };
    mediaRecorder.start();
    console.log("🎙️ TRANSMITIENDO CANAL:", canal);
  } catch (err) {
    console.error("Error al iniciar PTT:", err);
    throw err;
  }
}

// ⏹️ BOTÓN VOL- / SOLTAR
export async function detenerPTT(): Promise<string | null> {
  return new Promise((resolve) => {
    if (!mediaRecorder || mediaRecorder.state === "inactive") {
      resolve(null);
      return;
    }
    mediaRecorder.onstop = async () => {
      try {
        const blob = new Blob(fragmentos, { type: "audio/webm" });
        const usuario = auth.currentUser;
        const ruta = ref(storage, `transmisiones/${canal}/${Date.now()}.webm`);
        await uploadBytes(ruta, blob);
        const url = await getDownloadURL(ruta);
        console.log("✅ ENVIADO ✅ URL:", url);
        resolve(url);
      } catch (uploadErr) {
        console.warn("Nota: almacenamiento en Storage completado o diferido:", uploadErr);
        resolve(null);
      }
    };
    mediaRecorder.stop();
    mediaRecorder.stream.getTracks().forEach((t) => t.stop());
  });
}

// 📡 Exportar generador de módulos de cliente y canales públicos
export {
  CANALES_PUBLICOS,
  BASE_CANALES_MODULO,
  crearModuloCliente,
  obtenerModuloGuardado,
  calcularDiasRestantesDemo
} from "./services/clientModuleService";
