/* ==========================================================================
   charts.js — نمودارهای SVG بدون هیچ کتابخانه بیرونی (کاملاً آفلاین)
   ========================================================================== */

import { fmtShort, toFaDigits } from './utils.js';

const GOLD = '#e8b44a';
const GREEN = '#22c55e';
const RED = '#ef4444';
const BLUE = '#3b82f6';
const PURPLE = '#a78bfa';
const GRID = 'rgba(150,160,190,0.18)';
const TXT = 'currentColor';

export function wrap(html, height = 160) {
  return '<div class="chart" dir="ltr" style="width:100%;height:' + height + 'px">' + html + '</div>';
}

/** نمودار خطی/ناحیه‌ای */
export function lineChart(opts) {
  const { series = [], color = GOLD, height = 160, fill = true, labels = true, suffix = '' } = opts;
  const w = 320, h = height, pad = { t: 12, r: 8, b: labels ? 20 : 8, l: 8 };
  const vals = series.map((s) => +s.value || 0);
  if (!vals.length) return wrap('<svg viewBox="0 0 320 ' + h + '"><text x="160" y="' + (h / 2) + '" fill="' + TXT + '" font-size="12" text-anchor="middle">داده‌ای موجود نیست</text></svg>', h);
  const max = Math.max(...vals, 1), min = Math.min(...vals, 0);
  const range = max - min || 1;
  const innerW = w - pad.l - pad.r, innerH = h - pad.t - pad.b;
  const pts = vals.map((v, i) => {
    const x = pad.l + (series.length === 1 ? innerW / 2 : (i / (series.length - 1)) * innerW);
    const y = pad.t + innerH - ((v - min) / range) * innerH;
    return [x, y];
  });
  const path = pts.map((p, i) => (i === 0 ? 'M' : 'L') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
  const area = path + ' L' + (pad.l + innerW) + ' ' + (pad.t + innerH) + ' L' + pad.l + ' ' + (pad.t + innerH) + ' Z';
  const grid = [0, 0.5, 1].map((f) => {
    const y = pad.t + innerH * f;
    return '<line x1="' + pad.l + '" y1="' + y + '" x2="' + (w - pad.r) + '" y2="' + y + '" stroke="' + GRID + '" stroke-width="1"/>';
  }).join('');
  const dots = pts.map((p) => '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="2.6" fill="' + color + '"/>').join('');
  const lbls = labels ? series.map((s, i) => {
    if (series.length > 7 && i % Math.ceil(series.length / 6) !== 0) return '';
    const p = pts[i];
    return '<text x="' + p[0].toFixed(1) + '" y="' + (h - 5) + '" fill="' + TXT + '" font-size="9" text-anchor="middle" opacity="0.7">' + esc2(s.label) + '</text>';
  }).join('') : '';
  const svg = '<svg viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="none" style="width:100%;height:100%">' + grid +
    (fill ? '<path d="' + area + '" fill="' + color + '" opacity="0.16"/>' : '') +
    '<path d="' + path + '" fill="none" stroke="' + color + '" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/>' + dots + lbls + '</svg>';
  return wrap(svg + legend([max, min], suffix), h);
}

/** نمودار ستونی (با امکان دو سری) */
export function barChart(opts) {
  const { series = [], colors = [GOLD, BLUE], height = 170, legend: showLegend = true } = opts;
  const w = 320, h = height, pad = { t: 10, r: 6, b: 22, l: 6 };
  const innerW = w - pad.l - pad.r, innerH = h - pad.t - pad.b;
  const groups = series.length;
  const maxVal = Math.max(1, ...series.map((s) => Math.max(...s.values.map((v) => Math.abs(+v || 0)))));
  const gw = innerW / Math.max(1, groups);
  const bw = Math.max(4, (gw - 8) / series[0].values.length);
  let bars = '';
  series[0].labels.forEach((lbl, i) => {
    const x0 = pad.l + i * gw + 4;
    series.forEach((s, si) => {
      const v = Math.abs(+s.values[i] || 0);
      const bh = (v / maxVal) * innerH;
      const x = x0 + si * bw;
      bars += '<rect x="' + x.toFixed(1) + '" y="' + (pad.t + innerH - bh).toFixed(1) + '" width="' + (bw - 1.5).toFixed(1) + '" height="' + bh.toFixed(1) + '" rx="3" fill="' + (colors[si] || GOLD) + '" opacity="0.9"/>';
    });
    bars += '<text x="' + (x0 + (bw * series.length) / 2).toFixed(1) + '" y="' + (h - 6) + '" fill="' + TXT + '" font-size="9" text-anchor="middle" opacity="0.75">' + esc2(lbl) + '</text>';
  });
  const grid = '<line x1="' + pad.l + '" y1="' + (pad.t + innerH) + '" x2="' + (w - pad.r) + '" y2="' + (pad.t + innerH) + '" stroke="' + GRID + '"/>';
  const svg = '<svg viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="none" style="width:100%;height:100%">' + grid + bars + '</svg>';
  return wrap(svg, h) + (showLegend && series.length > 1 ? '<div class="row row--wrap tiny mt"><span>' + dot(colors[0], series[0].name) + '</span><span>' + dot(colors[1], series[1].name) + '</span></div>' : '');
}

/** نمودار دونات */
export function donut(opts) {
  const { segments = [], size = 140, thickness = 18, center = '' } = opts;
  const total = segments.reduce((a, b) => a + (+b.value || 0), 0);
  const r = (size - thickness) / 2;
  const c = size / 2;
  const circ = 2 * Math.PI * r;
  let offset = 0;
  const arcs = total > 0 ? segments.map((s) => {
    const frac = (+s.value || 0) / total;
    const len = frac * circ;
    const seg = '<circle cx="' + c + '" cy="' + c + '" r="' + r + '" fill="none" stroke="' + (s.color || GOLD) + '" stroke-width="' + thickness + '" stroke-dasharray="' + len.toFixed(1) + ' ' + (circ - len).toFixed(1) + '" stroke-dashoffset="' + (-offset).toFixed(1) + '" transform="rotate(-90 ' + c + ' ' + c + ')" stroke-linecap="butt"/>';
    offset += len;
    return seg;
  }).join('') : '<circle cx="' + c + '" cy="' + c + '" r="' + r + '" fill="none" stroke="' + GRID + '" stroke-width="' + thickness + '"/>';
  const svg = '<svg viewBox="0 0 ' + size + ' ' + size + '" style="width:100%;height:100%;max-width:' + size + 'px">' + arcs + '</svg>';
  return '<div class="donut"><div class="donut__svg" dir="ltr">' + svg + '</div>' + (center ? '<div class="donut__center">' + center + '</div>' : '') + '</div>';
}

/** حلقه پیشرفت */
export function ring(percent, opts = {}) {
  const size = opts.size || 120, thickness = opts.thickness || 12;
  const color = opts.color || GREEN;
  const p = Math.max(0, Math.min(100, +percent || 0));
  const r = (size - thickness) / 2, c = size / 2;
  const circ = 2 * Math.PI * r;
  const len = (p / 100) * circ;
  const svg = '<svg viewBox="0 0 ' + size + ' ' + size + '" style="width:100%;height:100%;max-width:' + size + 'px">' +
    '<circle cx="' + c + '" cy="' + c + '" r="' + r + '" fill="none" stroke="rgba(150,160,190,0.2)" stroke-width="' + thickness + '"/>' +
    '<circle cx="' + c + '" cy="' + c + '" r="' + r + '" fill="none" stroke="' + color + '" stroke-width="' + thickness + '" stroke-linecap="round" stroke-dasharray="' + len.toFixed(1) + ' ' + circ.toFixed(1) + '" transform="rotate(-90 ' + c + ' ' + c + ')"/></svg>';
  return '<div class="ring" style="width:' + size + 'px;height:' + size + 'px">' + svg +
    '<div class="ring__label"><b>' + toFaDigits(Math.round(p)) + '٪</b>' + (opts.label ? '<span>' + esc2(opts.label) + '</span>' : '') + '</div></div>';
}

/** خط کوچک (اسپارک‌لاین) */
export function sparkline(values, color = GOLD, height = 40) {
  const w = 120;
  const v = values.map((x) => +x || 0);
  if (!v.length) return '';
  const max = Math.max(...v, 1), min = Math.min(...v, 0), range = max - min || 1;
  const pts = v.map((x, i) => [(i / Math.max(1, v.length - 1)) * w, height - ((x - min) / range) * (height - 6) - 3]);
  const d = pts.map((p, i) => (i === 0 ? 'M' : 'L') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
  return '<svg viewBox="0 0 ' + w + ' ' + height + '" style="width:100%;height:' + height + 'px" dir="ltr"><path d="' + d + '" fill="none" stroke="' + color + '" stroke-width="2" stroke-linecap="round"/></svg>';
}

/** نمودار میله‌ای افقی برای دسته‌ها */
export function hBars(items, opts = {}) {
  const max = Math.max(1, ...items.map((i) => Math.abs(+i.value || 0)));
  return items.map((it) => {
    const w = Math.round((Math.abs(+it.value || 0) / max) * 100);
    return '<div class="hbar"><div class="hbar__label">' + esc2(it.label) + '</div>' +
      '<div class="hbar__track"><i style="width:' + w + '%;background:' + (it.color || GOLD) + '"></i></div>' +
      '<div class="hbar__value num">' + esc2(it.text != null ? it.text : String(it.value)) + '</div></div>';
  }).join('');
}

function legend(values, suffix) {
  return '<div class="row row--between tiny" style="padding:2px 4px 0"><span class="num">' + toFaDigits(fmtShort(values[1] || 0)) + (suffix || '') + '</span><span class="num">' + toFaDigits(fmtShort(values[0] || 0)) + (suffix || '') + '</span></div>';
}
function dot(color, label) { return '<i style="display:inline-block;width:9px;height:9px;border-radius:3px;background:' + color + ';margin-inline-end:5px"></i>' + esc2(label || ''); }
function esc2(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

export const CHART_COLORS = { gold: GOLD, green: GREEN, red: RED, blue: BLUE, purple: PURPLE };
