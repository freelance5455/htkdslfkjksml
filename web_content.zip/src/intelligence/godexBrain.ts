/**
 * GODEX Phase 2 - AI Brain & Context Orchestrator
 * Central orchestrator powering the Context Intelligence Engine:
 * 1. Intent Analysis
 * 2. Task Classification & Anaphora Resolution
 * 3. Graph-Aware & Symbol-Aware Context Retrieval
 * 4. Multi-Signal Relevance Ranking
 * 5. Context Budgeting & Smart Compression
 * 6. ContextPack Assembly
 * 7. AI Provider Dispatch & Model Routing
 * 8. Epistemic Response Parsing (KNOWN / INFERRED / UNKNOWN)
 * 9. Source Reference Grounding
 * 10. Conversation Memory Continuity
 */

import { 
  BrainOrchestrationResult, 
  BrainEvent, 
  ContextBudgetConfig, 
  AIRequestInspectData 
} from './contextTypes';
import { ProjectIntelligence } from './intelligenceEngine';
import { IntentClassifier } from './intentClassifier';
import { TaskExtractor } from './taskExtractor';
import { ContextPackBuilder } from './contextPackBuilder';
import { ConversationMemory } from './conversationContinuity';
import { ContextCache } from './contextCache';
import { GeminiBrainProvider } from './aiProvider';
import { ModelRouter } from './modelRouter';
import { DEFAULT_CONTEXT_BUDGET } from './contextBudget';
import { WorkspaceService } from '../services/workspaceService';

export class GodexBrain {
  private static instance: GodexBrain;
  private provider = new GeminiBrainProvider();
  private recentEvents: BrainEvent[] = [];
  private eventListeners: Array<(event: BrainEvent) => void> = [];
  private latestResult: BrainOrchestrationResult | null = null;

  private constructor() {}

  public static getInstance(): GodexBrain {
    if (!this.instance) {
      this.instance = new GodexBrain();
    }
    return this.instance;
  }

  public getLatestResult(): BrainOrchestrationResult | null {
    return this.latestResult;
  }

  public subscribeEvents(listener: (event: BrainEvent) => void): () => void {
    this.eventListeners.push(listener);
    return () => {
      this.eventListeners = this.eventListeners.filter(l => l !== listener);
    };
  }

  private emitEvent(type: BrainEvent['type'], message: string, payload: Record<string, any> = {}): void {
    const event: BrainEvent = {
      type,
      timestamp: Date.now(),
      message,
      payload
    };
    this.recentEvents.push(event);
    if (this.recentEvents.length > 50) this.recentEvents.shift();
    for (const listener of this.eventListeners) {
      try {
        listener(event);
      } catch (e) {
        console.error('Brain event listener error:', e);
      }
    }
  }

  public getRecentEvents(): BrainEvent[] {
    return [...this.recentEvents];
  }

  /**
   * Main Request Execution Pipeline
   */
  public async processRequest(
    userPrompt: string,
    options: {
      budget?: Partial<ContextBudgetConfig>;
      model?: string;
      recentModifiedFiles?: string[];
    } = {}
  ): Promise<BrainOrchestrationResult> {
    const events: BrainEvent[] = [];
    const recordEvent = (type: BrainEvent['type'], message: string, payload: Record<string, any> = {}) => {
      const ev: BrainEvent = { type, timestamp: Date.now(), message, payload };
      events.push(ev);
      this.emitEvent(type, message, payload);
    };

    try {
      recordEvent('REQUEST_RECEIVED', `Processing user request: "${userPrompt.slice(0, 80)}..."`, { prompt: userPrompt });

      // 1. Resolve Multi-Turn Conversation References
      const { resolvedPrompt } = ConversationMemory.resolvePrompt(userPrompt);

      // 2. Classify Intent
      const classification = IntentClassifier.classify(resolvedPrompt);
      recordEvent('INTENT_CLASSIFIED', `Classified intent as ${classification.intent} (${Math.round(classification.confidence * 100)}% confidence)`, {
        intent: classification.intent,
        confidence: classification.confidence,
        reason: classification.reason
      });

      // 3. Extract Structured Task
      const intelState = ProjectIntelligence.getState();
      const rawFiles = await WorkspaceService.getAllFiles();
      const allFilePaths = Object.keys(intelState.files);
      const allSymbols = Object.values(intelState.files).flatMap(f => f.symbols?.map(s => s.name) || []);

      const task = TaskExtractor.extract(resolvedPrompt, allFilePaths, allSymbols);
      recordEvent('TASK_EXTRACTED', `Extracted goal: "${task.goal}" with action: ${task.requestedAction}`, { task });

      // 4. Retrieve Context and Rank
      recordEvent('CONTEXT_SEARCH_STARTED', `Searching AST symbol index and module dependency graph`, { intent: classification.intent });

      const budgetConfig: ContextBudgetConfig = {
        ...DEFAULT_CONTEXT_BUDGET,
        ...(options.budget || {})
      };

      // 5. Construct Context Pack
      const contextPack = ContextPackBuilder.build(
        resolvedPrompt,
        classification.intent,
        task,
        intelState,
        rawFiles,
        budgetConfig,
        options.recentModifiedFiles || []
      );

      recordEvent('CONTEXT_SELECTED', `Selected ${contextPack.relevantFiles.length} file(s) and ${contextPack.relevantSymbols.length} symbol(s)`, {
        files: contextPack.relevantFiles.map(f => f.path),
        symbols: contextPack.relevantSymbols.map(s => s.name)
      });

      recordEvent('CONTEXT_COMPRESSED', `Budget usage: ${contextPack.budgetUsagePercent}% (${contextPack.totalTokensEstimate} estimated tokens)`, {
        tokens: contextPack.totalTokensEstimate,
        characters: contextPack.totalCharacters,
        budgetUsagePercent: contextPack.budgetUsagePercent
      });

      // 6. Model Routing
      const routeDecision = ModelRouter.route(
        classification.intent,
        task,
        contextPack.totalTokensEstimate,
        options.model
      );

      // 7. Prepare Technical Inspection Data
      const inspectData: AIRequestInspectData = {
        requestId: contextPack.id,
        timestamp: Date.now(),
        intent: classification.intent,
        task,
        contextFilesCount: contextPack.relevantFiles.length,
        contextSymbolsCount: contextPack.relevantSymbols.length,
        contextTestsCount: contextPack.tests.length,
        model: routeDecision.selectedModel,
        contextTokensEstimate: contextPack.totalTokensEstimate,
        characterCount: contextPack.totalCharacters,
        budgetPercent: contextPack.budgetUsagePercent,
        toolsDeclared: [], // Phase 2 intelligence only (no unsolicited tools)
        confidence: classification.confidence,
        activeContextMode: classification.intent
      };

      // 8. Execute AI Model Call
      recordEvent('AI_REQUEST_STARTED', `Querying model provider with grounded ContextPack`, {
        model: routeDecision.selectedModel,
        temperature: routeDecision.temperature
      });

      const structuredResponse = await this.provider.generate({
        prompt: resolvedPrompt,
        contextPack,
        model: routeDecision.selectedModel,
        temperature: routeDecision.temperature
      });

      recordEvent('AI_RESPONSE_RECEIVED', `Received structured response (${structuredResponse.sources.length} cited sources)`, {
        sourcesCount: structuredResponse.sources.length,
        confidence: structuredResponse.confidence
      });

      // 9. Update Conversation Continuity Memory
      ConversationMemory.recordTurn(userPrompt, classification.intent, task, contextPack);
      ContextCache.setContextPack(userPrompt, contextPack);

      const result: BrainOrchestrationResult = {
        success: true,
        contextPack,
        inspectData,
        structuredResponse,
        events
      };

      this.latestResult = result;
      return result;
    } catch (err: any) {
      const errMsg = err.message || 'Unknown Context Engine error';
      recordEvent('CONTEXT_WARNING', `Context Engine encountered an error: ${errMsg}`, { error: errMsg });

      // Fallback safe response
      const emptyTask = TaskExtractor.extract(userPrompt);
      const emptyPack = ContextPackBuilder.build(userPrompt, 'GENERAL', emptyTask, ProjectIntelligence.getState(), {});
      
      const failResult: BrainOrchestrationResult = {
        success: false,
        contextPack: emptyPack,
        inspectData: {
          requestId: 'err-' + Date.now(),
          timestamp: Date.now(),
          intent: 'GENERAL',
          task: emptyTask,
          contextFilesCount: 0,
          contextSymbolsCount: 0,
          contextTestsCount: 0,
          model: options.model || 'gemini-3.7-flash',
          contextTokensEstimate: 0,
          characterCount: 0,
          budgetPercent: 0,
          toolsDeclared: [],
          confidence: 0,
          activeContextMode: 'GENERAL'
        },
        structuredResponse: {
          answer: `Context retrieval encountered an error: ${errMsg}. Please retry your request.`,
          summary: 'Context retrieval failed.',
          sources: [],
          suggestedActions: ['Retry request', 'Check workspace syntax'],
          warnings: [errMsg],
          confidence: 0,
          epistemicSummary: {
            known: [],
            inferred: [],
            unknown: [errMsg]
          }
        },
        events,
        error: errMsg
      };

      this.latestResult = failResult;
      return failResult;
    }
  }
}

export const Brain = GodexBrain.getInstance();
