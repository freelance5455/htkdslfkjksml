/**
 * GODEX Phase 1 - Global Symbol Index
 * Inverted index of functions, components, interfaces, classes, and types with cross-reference tracking.
 */

import { ProjectSymbol, SymbolKind } from './types';

export type SymbolRelationType =
  | 'DECLARATION'
  | 'IMPORT'
  | 'EXPORT'
  | 'REFERENCE'
  | 'CALL'
  | 'TYPE_REFERENCE'
  | 'GLOBAL_SEARCH_MATCH'
  | 'DEPENDENCY'
  | 'REVERSE_DEPENDENCY';

export interface ClassifiedSymbolMatch {
  symbol: ProjectSymbol;
  relationType: SymbolRelationType;
  confidence: number;
  sourceFilePath?: string;
}

export class SymbolIndex {
  private indexByName: Map<string, ProjectSymbol[]> = new Map();
  private indexByFile: Map<string, ProjectSymbol[]> = new Map();

  public clear(): void {
    this.indexByName.clear();
    this.indexByFile.clear();
  }

  public updateFileSymbols(filePath: string, symbols: ProjectSymbol[]): void {
    // Remove old symbols associated with this file
    const oldSymbols = this.indexByFile.get(filePath) || [];
    for (const old of oldSymbols) {
      const list = this.indexByName.get(old.name);
      if (list) {
        const filtered = list.filter(s => s.filePath !== filePath);
        if (filtered.length === 0) {
          this.indexByName.delete(old.name);
        } else {
          this.indexByName.set(old.name, filtered);
        }
      }
    }

    // Set new file symbols
    this.indexByFile.set(filePath, symbols);

    // Index new symbols by name
    for (const sym of symbols) {
      const list = this.indexByName.get(sym.name) || [];
      list.push(sym);
      this.indexByName.set(sym.name, list);
    }
  }

  public removeFile(filePath: string): void {
    const oldSymbols = this.indexByFile.get(filePath) || [];
    for (const old of oldSymbols) {
      const list = this.indexByName.get(old.name);
      if (list) {
        const filtered = list.filter(s => s.filePath !== filePath);
        if (filtered.length === 0) {
          this.indexByName.delete(old.name);
        } else {
          this.indexByName.set(old.name, filtered);
        }
      }
    }
    this.indexByFile.delete(filePath);
  }

  public getSymbolsByName(name: string): ProjectSymbol[] {
    return this.indexByName.get(name) || [];
  }

  public getSymbolsInFile(filePath: string): ProjectSymbol[] {
    return this.indexByFile.get(filePath) || [];
  }

  public getSymbolsByKind(kind: SymbolKind): ProjectSymbol[] {
    const results: ProjectSymbol[] = [];
    for (const list of this.indexByName.values()) {
      for (const sym of list) {
        if (sym.kind === kind) {
          results.push(sym);
        }
      }
    }
    return results;
  }

  public search(query: string, limit = 20): ProjectSymbol[] {
    const q = query.toLowerCase().trim();
    if (!q) return this.getAllSymbols().slice(0, limit);

    const matches: Array<{ symbol: ProjectSymbol; score: number }> = [];

    for (const [name, list] of this.indexByName.entries()) {
      const lowerName = name.toLowerCase();
      let score = 0;
      if (lowerName === q) score = 100;
      else if (lowerName.startsWith(q)) score = 80;
      else if (lowerName.includes(q)) score = 50;

      if (score > 0) {
        for (const sym of list) {
          matches.push({ symbol: sym, score });
        }
      }
    }

    matches.sort((a, b) => b.score - a.score);
    return matches.slice(0, limit).map(m => m.symbol);
  }

  /**
   * Scoped symbol resolution for a specific file. Differentiates direct imports,
   * declarations, and dependencies from global un-scoped text matches.
   */
  public resolveFileScopedSymbols(
    targetFilePath: string,
    fileImports: string[] = [],
    query = ''
  ): ClassifiedSymbolMatch[] {
    const results: ClassifiedSymbolMatch[] = [];
    const declaredInFile = this.getSymbolsInFile(targetFilePath);

    // 1. Direct Declarations in File
    for (const sym of declaredInFile) {
      if (!query || sym.name.toLowerCase().includes(query.toLowerCase())) {
        results.push({
          symbol: sym,
          relationType: 'DECLARATION',
          confidence: 1.0,
          sourceFilePath: targetFilePath
        });
      }
    }

    // 2. Direct Imported Symbols from target dependencies
    for (const impPath of fileImports) {
      const symbolsInDep = this.getSymbolsInFile(impPath);
      for (const sym of symbolsInDep) {
        if (!query || sym.name.toLowerCase().includes(query.toLowerCase())) {
          results.push({
            symbol: sym,
            relationType: 'IMPORT',
            confidence: 0.95,
            sourceFilePath: impPath
          });
        }
      }
    }

    // 3. Global Search Matches (Strictly labeled as GLOBAL_SEARCH_MATCH, never falsely as REFERENCE)
    if (query) {
      const globalMatches = this.search(query, 20);
      for (const gSym of globalMatches) {
        const alreadyIncluded = results.some(r => r.symbol.id === gSym.id);
        if (!alreadyIncluded) {
          results.push({
            symbol: gSym,
            relationType: 'GLOBAL_SEARCH_MATCH',
            confidence: 0.4,
            sourceFilePath: gSym.filePath
          });
        }
      }
    }

    return results;
  }

  public getAllSymbols(): ProjectSymbol[] {
    const all: ProjectSymbol[] = [];
    for (const list of this.indexByName.values()) {
      all.push(...list);
    }
    return all;
  }

  public toJSON(): Record<string, ProjectSymbol[]> {
    const obj: Record<string, ProjectSymbol[]> = {};
    for (const [name, list] of this.indexByName.entries()) {
      obj[name] = list;
    }
    return obj;
  }
}
