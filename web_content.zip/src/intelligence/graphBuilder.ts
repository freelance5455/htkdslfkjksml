/**
 * GODEX Phase 1 - Project Graph & Dependency Builder
 * Builds module graphs, resolves import paths, maps component render hierarchies, and detects cycles.
 */

import { 
  ProjectGraph, 
  GraphNode, 
  GraphEdge, 
  ProjectImport, 
  DependencyRelationType 
} from './types';
import { ParsedFileAst } from './astParser';

export class GraphBuilder {
  public static buildGraph(
    files: Record<string, string>,
    parsedAsts: Record<string, ParsedFileAst>
  ): ProjectGraph {
    const filePaths = Object.keys(files);
    const nodesMap: Map<string, GraphNode> = new Map();
    const edges: GraphEdge[] = [];
    const adjacency: Record<string, string[]> = {};
    const reverseAdjacency: Record<string, string[]> = {};

    for (const p of filePaths) {
      adjacency[p] = [];
      reverseAdjacency[p] = [];
    }

    // 1. Create Nodes for each file
    for (const filePath of filePaths) {
      const ast = parsedAsts[filePath];
      const content = files[filePath] || '';
      const lines = content.split('\n').length;
      const bytes = content.length;
      const layer = this.classifyLayer(filePath);

      nodesMap.set(filePath, {
        id: filePath,
        name: filePath.split('/').pop() || filePath,
        type: this.isEntryPoint(filePath) ? 'entry_point' : 'file',
        filePath,
        layer,
        symbolsCount: ast ? ast.symbols.length : 0,
        lines,
        bytes
      });
    }

    // 2. Resolve Imports and create edges
    for (const [sourcePath, ast] of Object.entries(parsedAsts)) {
      if (!ast) continue;

      for (const imp of ast.imports) {
        if (imp.isExternal) {
          // External package node
          const pkgId = `pkg:${imp.source}`;
          if (!nodesMap.has(pkgId)) {
            nodesMap.set(pkgId, {
              id: pkgId,
              name: imp.source,
              type: 'external_package',
              layer: 'external',
              symbolsCount: 0,
              lines: 0,
              bytes: 0
            });
            adjacency[pkgId] = [];
            reverseAdjacency[pkgId] = [];
          }

          const edgeId = `edge-${sourcePath}->${pkgId}`;
          edges.push({
            id: edgeId,
            source: sourcePath,
            target: pkgId,
            type: 'IMPORTS',
            label: imp.specifiers.map(s => s.local).join(', ')
          });

          if (!adjacency[sourcePath].includes(pkgId)) adjacency[sourcePath].push(pkgId);
          if (!reverseAdjacency[pkgId].includes(sourcePath)) reverseAdjacency[pkgId].push(sourcePath);
        } else {
          // Internal file import resolution
          const resolved = this.resolveRelativeImport(sourcePath, imp.source, filePaths);
          if (resolved) {
            imp.resolvedPath = resolved;
            const edgeId = `edge-${sourcePath}->${resolved}`;
            
            edges.push({
              id: edgeId,
              source: sourcePath,
              target: resolved,
              type: 'IMPORTS',
              label: imp.specifiers.map(s => s.local).join(', ')
            });

            if (!adjacency[sourcePath].includes(resolved)) adjacency[sourcePath].push(resolved);
            if (!reverseAdjacency[resolved].includes(sourcePath)) reverseAdjacency[resolved].push(sourcePath);
          }
        }
      }

      // Render relationships: If component A renders component B (found in JSX tags)
      for (const compName of ast.renderedComponents) {
        // Find which file defines this component
        for (const [otherPath, otherAst] of Object.entries(parsedAsts)) {
          if (otherPath === sourcePath) continue;
          const defines = otherAst.symbols.some(s => s.name === compName && s.kind === 'component');
          if (defines) {
            const edgeId = `render-${sourcePath}->${otherPath}`;
            if (!edges.some(e => e.id === edgeId)) {
              edges.push({
                id: edgeId,
                source: sourcePath,
                target: otherPath,
                type: 'RENDERS',
                label: compName
              });
            }
          }
        }
      }
    }

    // 3. Detect Circular Dependencies (internal files only)
    const circularDependencies = this.findCycles(filePaths, adjacency);

    return {
      nodes: Array.from(nodesMap.values()),
      edges,
      adjacency,
      reverseAdjacency,
      circularDependencies
    };
  }

  public static resolveRelativeImport(
    currentFilePath: string,
    importPath: string,
    allFiles: string[]
  ): string | null {
    if (!importPath.startsWith('.')) return null;

    const currentDir = currentFilePath.includes('/')
      ? currentFilePath.substring(0, currentFilePath.lastIndexOf('/'))
      : '';

    const combined = currentDir ? `${currentDir}/${importPath}` : importPath;
    const parts = combined.split('/');
    const resolvedParts: string[] = [];

    for (const part of parts) {
      if (part === '.' || part === '') continue;
      if (part === '..') {
        resolvedParts.pop();
      } else {
        resolvedParts.push(part);
      }
    }

    const basePath = resolvedParts.join('/');
    const candidates = [
      basePath,
      `${basePath}.tsx`,
      `${basePath}.ts`,
      `${basePath}.jsx`,
      `${basePath}.js`,
      `${basePath}.json`,
      `${basePath}/index.tsx`,
      `${basePath}/index.ts`,
      `${basePath}/index.js`
    ];

    for (const cand of candidates) {
      if (allFiles.includes(cand)) {
        return cand;
      }
    }

    return null;
  }

  public static classifyLayer(filePath: string): GraphNode['layer'] {
    if (filePath.startsWith('src/components') || filePath === 'src/App.tsx') return 'ui';
    if (filePath.startsWith('src/services') || filePath === 'server.ts' || filePath.startsWith('src/intelligence')) return 'services';
    if (filePath.startsWith('src/types') || filePath.startsWith('src/templates')) return 'core';
    if (filePath.startsWith('src/routes') || filePath.startsWith('src/pages') || filePath.startsWith('api/')) return 'routes';
    return 'config';
  }

  private static isEntryPoint(filePath: string): boolean {
    return (
      filePath === 'src/main.tsx' ||
      filePath === 'src/index.tsx' ||
      filePath === 'src/App.tsx' ||
      filePath === 'server.ts' ||
      filePath === 'index.html'
    );
  }

  private static findCycles(nodes: string[], adj: Record<string, string[]>): string[][] {
    const visited: Record<string, boolean> = {};
    const recursionStack: Record<string, boolean> = {};
    const path: string[] = [];
    const cycles: string[][] = [];

    const dfs = (curr: string) => {
      visited[curr] = true;
      recursionStack[curr] = true;
      path.push(curr);

      const neighbors = adj[curr] || [];
      for (const neighbor of neighbors) {
        if (neighbor.startsWith('pkg:')) continue; // Skip external packages

        if (!visited[neighbor]) {
          dfs(neighbor);
        } else if (recursionStack[neighbor]) {
          // Cycle found
          const cycleStartIndex = path.indexOf(neighbor);
          if (cycleStartIndex !== -1) {
            const cycle = path.slice(cycleStartIndex).concat(neighbor);
            cycles.push(cycle);
          }
        }
      }

      path.pop();
      recursionStack[curr] = false;
    };

    for (const node of nodes) {
      if (!visited[node]) {
        dfs(node);
      }
    }

    return cycles;
  }
}
