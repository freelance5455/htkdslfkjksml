/**
 * GODEX Phase 2 - Context Retrieval Engine
 * Graph-aware, symbol-aware, and intent-specific context retrieval engine
 * querying Phase 1 Project Intelligence Engine.
 */

import { 
  IntentCategory, 
  TaskExtraction, 
  ContextFileItem, 
  ContextSymbolItem, 
  ContextBudgetConfig 
} from './contextTypes';
import { ProjectIntelligenceState, ProjectSymbol } from './types';
import { RelevanceRanker } from './relevanceRanker';
import { SymbolExtractor } from './symbolExtractor';

export interface RetrievedContext {
  files: ContextFileItem[];
  symbols: ContextSymbolItem[];
  dependencies: Array<{ name: string; version: string; isFramework?: boolean; category?: string }>;
  tests: string[];
  documentation: string[];
  recentChanges: string[];
  warnings: string[];
}

export class ContextRetriever {
  /**
   * Secret protection filter - sanitizes sensitive tokens, private keys, or passwords
   */
  public static redactSecrets(content: string): string {
    return content
      .replace(/(AIza[0-9A-Za-z-_]{35})/g, '[REDACTED_GOOGLE_API_KEY]')
      .replace(/(sk-[a-zA-Z0-9]{20,})/g, '[REDACTED_API_KEY]')
      .replace(/(ghp_[a-zA-Z0-9]{36})/g, '[REDACTED_GITHUB_TOKEN]')
      .replace(/(eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,})/g, '[REDACTED_JWT_TOKEN]')
      .replace(/(password|secret|apiKey|api_key|token|auth_token)\s*[:=]\s*["'][^"'\n]{6,}["']/gi, '$1: "[REDACTED_SECRET]"');
  }

  /**
   * Graph-aware traversal: retrieves direct (depth 1) and secondary (depth 2) dependencies of candidate files
   */
  public static traverseGraphDependencies(
    initialFiles: string[],
    intelState: ProjectIntelligenceState,
    maxDepth: number = 1
  ): { directDeps: string[]; secondaryDeps: string[]; callers: Record<string, string[]> } {
    const directDeps: Set<string> = new Set();
    const secondaryDeps: Set<string> = new Set();
    const callers: Record<string, string[]> = {};

    const adjacency = intelState.graph.adjacency || {};
    const reverseAdjacency = intelState.graph.reverseAdjacency || {};

    for (const file of initialFiles) {
      // Find files imported by this file
      const targets = adjacency[file] || [];
      for (const target of targets) {
        if (!initialFiles.includes(target) && intelState.files[target]) {
          directDeps.add(target);
          if (!callers[target]) callers[target] = [];
          if (!callers[target].includes(file)) callers[target].push(file);
        }
      }

      // Find files that import this file
      const incoming = reverseAdjacency[file] || [];
      for (const inc of incoming) {
        if (!initialFiles.includes(inc) && intelState.files[inc]) {
          directDeps.add(inc);
          if (!callers[file]) callers[file] = [];
          if (!callers[file].includes(inc)) callers[file].push(inc);
        }
      }
    }

    if (maxDepth >= 2) {
      for (const dep of Array.from(directDeps)) {
        const secondary = adjacency[dep] || [];
        for (const sec of secondary) {
          if (!initialFiles.includes(sec) && !directDeps.has(sec) && intelState.files[sec]) {
            secondaryDeps.add(sec);
            if (!callers[sec]) callers[sec] = [];
            if (!callers[sec].includes(dep)) callers[sec].push(dep);
          }
        }
      }
    }

    return {
      directDeps: Array.from(directDeps),
      secondaryDeps: Array.from(secondaryDeps),
      callers
    };
  }

  /**
   * Retrieves context tailored specifically to the given task and intent
   */
  public static retrieve(
    prompt: string,
    intent: IntentCategory,
    task: TaskExtraction,
    intelState: ProjectIntelligenceState,
    rawFiles: Record<string, string>,
    budget: ContextBudgetConfig,
    recentChanges: string[] = []
  ): RetrievedContext {
    const allFilePaths = Object.keys(intelState.files);
    const warnings: string[] = [];

    // 1. Initial file ranking
    const rankedFiles = RelevanceRanker.rankFiles(
      allFilePaths,
      prompt,
      intent,
      task,
      intelState,
      recentChanges
    );

    // Filter top candidates (respecting maxFiles budget before graph expansion)
    const initialCandidates = rankedFiles
      .filter(r => r.totalScore > 0.15)
      .slice(0, Math.min(budget.maxFiles, 6))
      .map(r => r.filePath);

    // Fallback: If no candidate matched, include entry point
    if (initialCandidates.length === 0 && intelState.metadata.entryPoints.browser) {
      initialCandidates.push(intelState.metadata.entryPoints.browser);
    }
    if (initialCandidates.length === 0 && allFilePaths.length > 0) {
      initialCandidates.push(allFilePaths[0]);
    }

    // 2. Graph-Aware Traversal
    const graphExpansion = this.traverseGraphDependencies(
      initialCandidates,
      intelState,
      budget.maxGraphDepth
    );

    // Combine candidate set
    const candidateFileSet = new Set<string>([...initialCandidates]);
    if (intent === 'DEBUG' || intent === 'ARCHITECTURE' || intent === 'IMPLEMENT') {
      for (const dep of graphExpansion.directDeps.slice(0, 3)) {
        candidateFileSet.add(dep);
      }
    }

    // 3. Extract ContextFileItems
    const finalFileItems: ContextFileItem[] = [];
    for (const filePath of Array.from(candidateFileSet)) {
      const fileData = intelState.files[filePath];
      const rankInfo = rankedFiles.find(r => r.filePath === filePath);
      const content = rawFiles[filePath] || '';
      const isDirectDep = graphExpansion.directDeps.includes(filePath);

      let reason = rankInfo?.reason || 'Associated project module';
      let relevanceScore = rankInfo?.totalScore || 0.4;
      let source: any = 'exact_match';

      if (isDirectDep) {
        reason = `Direct dependency connected via import graph (callers: ${graphExpansion.callers[filePath]?.join(', ') || 'workspace'})`;
        relevanceScore = Math.max(relevanceScore, 0.65);
        source = 'import_graph';
      }

      // Slicing content / summary
      const safeContent = this.redactSecrets(content);
      const linesCount = fileData?.lines || safeContent.split('\n').length;
      
      // Compute architectural layer
      let layer: any = 'services';
      if (filePath.includes('components/') || filePath.includes('views/')) layer = 'ui';
      else if (filePath.includes('routes/') || filePath.includes('server') || filePath.includes('api/')) layer = 'routes';
      else if (filePath.includes('config') || filePath.endsWith('.json')) layer = 'config';
      else if (filePath.includes('core/') || filePath.includes('types')) layer = 'core';

      finalFileItems.push({
        path: filePath,
        relevanceScore,
        reason,
        source,
        linesCount,
        bytes: fileData?.bytes || safeContent.length,
        layer,
        isEntry: fileData?.isEntry || false,
        isTest: filePath.includes('test') || filePath.includes('spec'),
        symbolsCount: fileData?.symbols?.length || 0,
        snippet: safeContent.slice(0, 2000), // First chunk
        includedSymbols: fileData?.symbols?.map(s => s.name)
      });
    }

    // 4. Symbol-Aware Context Extraction
    const allSymbols: ProjectSymbol[] = Object.values(intelState.files).flatMap(f => f.symbols || []);
    const rankedSymbols = RelevanceRanker.rankSymbols(allSymbols, prompt, intent, task);

    const targetSymbols = rankedSymbols
      .filter(s => s.totalScore > 0.3 || initialCandidates.includes(s.symbol.filePath))
      .slice(0, budget.maxSymbols);

    const finalSymbolItems: ContextSymbolItem[] = targetSymbols.map(s => {
      const fileContent = rawFiles[s.symbol.filePath] || '';
      const callers = graphExpansion.callers[s.symbol.filePath] || [];
      return SymbolExtractor.extractSymbolContext(
        s.symbol,
        this.redactSecrets(fileContent),
        s.totalScore,
        s.reason,
        callers
      );
    });

    // 5. Dependency extraction
    const relevantDeps: Array<{ name: string; version: string; isFramework?: boolean; category?: string }> = [];
    for (const [depName, info] of Object.entries(intelState.dependencies || {})) {
      if (
        info.isFramework ||
        prompt.toLowerCase().includes(depName.toLowerCase()) ||
        task.entities.some(e => depName.toLowerCase().includes(e))
      ) {
        relevantDeps.push({
          name: depName,
          version: info.version,
          isFramework: info.isFramework,
          category: info.category
        });
      }
    }

    // 6. Tests & Documentation
    const testFiles = allFilePaths.filter(p => p.includes('test') || p.includes('spec'));
    const docFiles = allFilePaths.filter(p => p.endsWith('.md'));

    // Check circular dependency warnings
    if (intelState.graph.circularDependencies && intelState.graph.circularDependencies.length > 0) {
      warnings.push(`Warning: ${intelState.graph.circularDependencies.length} circular dependency cycle(s) detected in graph.`);
    }

    return {
      files: finalFileItems.sort((a, b) => b.relevanceScore - a.relevanceScore),
      symbols: finalSymbolItems,
      dependencies: relevantDeps,
      tests: testFiles,
      documentation: docFiles,
      recentChanges,
      warnings
    };
  }
}
