/**
 * GODEX Phase 2 - Context Intelligence Engine Types
 * Data contracts for Intent Classification, Task Extraction, Context Retrieval,
 * Relevance Ranking, Context Budgeting, Context Pack, Conversation Continuity,
 * Epistemic Grounding, and AI Model Provider Abstraction.
 */

import { 
  ProjectSymbol, 
  SymbolKind, 
  DetectedFramework, 
  DetectedLanguage, 
  DetectedRuntime 
} from './types';

export type IntentCategory = 
  | 'EXPLAIN'
  | 'SEARCH'
  | 'DEBUG'
  | 'IMPLEMENT'
  | 'REFACTOR'
  | 'REVIEW'
  | 'TEST'
  | 'ARCHITECTURE'
  | 'SECURITY'
  | 'DOCUMENTATION'
  | 'PROJECT_OVERVIEW'
  | 'GIT'
  | 'GENERAL';

export type ChatRoutingCategory =
  | 'CONVERSATIONAL'
  | 'READ_ONLY_ENGINEERING_QUERY'
  | 'ENGINEERING_ACTION'
  | 'LONG_HORIZON_MISSION'
  | 'AMBIGUOUS';

export type EpistemicStatus = 'KNOWN' | 'INFERRED' | 'UNKNOWN';

export interface IntentClassificationResult {
  intent: IntentCategory;
  route: ChatRoutingCategory;
  confidence: number; // 0 to 1
  secondaryIntents?: IntentCategory[];
  reason: string;
  matchedKeywords: string[];
  suggestedContextMode: IntentCategory;
  clarificationPrompt?: string;
}

export interface TaskExtraction {
  goal: string;
  requestedAction: IntentCategory;
  entities: string[];
  targetArea?: string;
  constraints: string[];
  expectedOutput?: string;
  targetFiles?: string[];
  affectedSymbols?: string[];
  errorDetails?: string;
  rawPrompt: string;
}

export type ContextSourceType = 
  | 'exact_match' 
  | 'symbol_owner' 
  | 'import_graph' 
  | 'entry_point' 
  | 'test' 
  | 'config' 
  | 'recent_change' 
  | 'security_scope'
  | 'layer_scope'
  | 'conversation_history';

export interface ContextFileItem {
  path: string;
  relevanceScore: number; // 0 to 1
  reason: string;
  source: ContextSourceType;
  linesCount: number;
  bytes: number;
  layer: 'ui' | 'services' | 'core' | 'config' | 'routes' | 'external';
  isEntry: boolean;
  isTest: boolean;
  symbolsCount: number;
  snippet?: string;
  includedSymbols?: string[];
  compressionLevel?: 'full' | 'summary' | 'symbols_only';
}

export interface ContextSymbolItem {
  id: string;
  name: string;
  kind: SymbolKind;
  filePath: string;
  line: number;
  endLine?: number;
  relevanceScore: number;
  reason: string;
  signature?: string;
  docstring?: string;
  isExported: boolean;
  callers?: string[];
  dependencies?: string[];
  codeSnippet?: string;
}

export interface ContextBudgetConfig {
  maxFiles: number;
  maxSymbols: number;
  maxTokens: number;
  maxCharacters: number;
  maxGraphDepth: number;
}

export interface ProjectSummary {
  name: string;
  framework: DetectedFramework;
  primaryLanguage: DetectedLanguage;
  runtime: DetectedRuntime;
  entryPoint: string;
  totalFiles: number;
  totalLines: number;
  totalDependencies: number;
  totalTests: number;
  healthScore: number;
  healthRating: string;
  architectureLayers: string[];
}

export interface ContextPack {
  id: string;
  createdAt: number;
  userPrompt: string;
  taskIntent: IntentCategory;
  taskExtraction: TaskExtraction;
  projectSummary: ProjectSummary;
  relevantFiles: ContextFileItem[];
  relevantSymbols: ContextSymbolItem[];
  architectureSummary: {
    totalLayers: number;
    layersPresent: string[];
    keyNodes: string[];
    circularWarnings: string[][];
    healthScore: number;
  };
  dependencies: Array<{
    name: string;
    version: string;
    isFramework?: boolean;
    category?: string;
  }>;
  tests: string[];
  documentation: string[];
  recentChanges: string[];
  constraints: string[];
  warnings: string[];
  totalTokensEstimate: number;
  totalCharacters: number;
  budgetUsagePercent: number;
  budget: ContextBudgetConfig;
  engineeringMemory?: Array<{
    id: string;
    type: string;
    content: string;
    epistemicStatus: string;
    whyIncluded?: string;
  }>;
  gitHistory?: Array<{
    hash: string;
    shortHash: string;
    message: string;
    author: string;
    date: number;
  }>;
  explanation: {
    fileReasons: Record<string, string>;
    symbolReasons: Record<string, string>;
    exclusionReasons?: Record<string, string>;
    memoryReasons?: Record<string, string>;
  };
}

export interface ConversationContinuityState {
  sessionId: string;
  currentTask?: TaskExtraction;
  previousIntent?: IntentCategory;
  referencedFiles: string[];
  referencedSymbols: string[];
  conversationEntities: string[];
  activeProjectArea?: string;
  turnCount: number;
  historySummary?: string;
  lastUpdated: number;
}

export interface SourceReference {
  path: string;
  line?: number;
  endLine?: number;
  symbol?: string;
  description: string;
  epistemic: EpistemicStatus;
}

export interface StructuredAIResponse {
  answer: string;
  summary: string;
  sources: SourceReference[];
  suggestedActions: string[];
  warnings: string[];
  confidence: number;
  epistemicSummary: {
    known: string[];
    inferred: string[];
    unknown: string[];
  };
  rawText?: string;
}

export interface AIRequestInspectData {
  requestId: string;
  timestamp: number;
  intent: IntentCategory;
  task: TaskExtraction;
  contextFilesCount: number;
  contextSymbolsCount: number;
  contextTestsCount: number;
  model: string;
  contextTokensEstimate: number;
  characterCount: number;
  budgetPercent: number;
  toolsDeclared: string[];
  confidence: number;
  activeContextMode: string;
}

export interface BrainEvent {
  type: 
    | 'REQUEST_RECEIVED'
    | 'INTENT_CLASSIFIED'
    | 'TASK_EXTRACTED'
    | 'CONTEXT_SEARCH_STARTED'
    | 'CONTEXT_SELECTED'
    | 'CONTEXT_COMPRESSED'
    | 'AI_REQUEST_STARTED'
    | 'AI_RESPONSE_RECEIVED'
    | 'CONTEXT_WARNING'
    | 'CACHE_HIT'
    | 'CACHE_INVALIDATED';
  timestamp: number;
  payload: Record<string, any>;
  message: string;
}

export interface BrainOrchestrationResult {
  success: boolean;
  contextPack: ContextPack;
  inspectData: AIRequestInspectData;
  structuredResponse: StructuredAIResponse;
  events: BrainEvent[];
  error?: string;
}
