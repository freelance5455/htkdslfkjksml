/**
 * GODEX Phase 2 - Multi-Signal Relevance Ranking Engine
 * Computes deterministic multi-factor relevance scores for project files and symbols
 * against the user request, intent, task extraction, AST graph, and layer topology.
 */

import { IntentCategory, TaskExtraction } from './contextTypes';
import { ProjectIntelligenceState, ProjectSymbol } from './types';

export interface FileRankingScore {
  filePath: string;
  totalScore: number;
  reason: string;
  signals: {
    exactMatch: number;
    symbolMatch: number;
    pathRelevance: number;
    importProximity: number;
    layerRelevance: number;
    intentRelevance: number;
    testRelationship: number;
    recentChange: number;
  };
}

export interface SymbolRankingScore {
  symbol: ProjectSymbol;
  totalScore: number;
  reason: string;
}

export class RelevanceRanker {
  /**
   * Ranks all candidate files based on multi-signal scoring
   */
  public static rankFiles(
    files: string[],
    prompt: string,
    intent: IntentCategory,
    task: TaskExtraction,
    intelState: ProjectIntelligenceState,
    recentModifiedFiles: string[] = []
  ): FileRankingScore[] {
    const promptLower = prompt.toLowerCase();
    const promptTokens = promptLower.split(/\W+/).filter(t => t.length > 2);

    const scores: FileRankingScore[] = files.map(filePath => {
      const fileData = intelState.files[filePath];
      const fileName = filePath.split('/').pop() || '';
      const baseName = fileName.replace(/\.[^/.]+$/, '').toLowerCase();
      const lowerPath = filePath.toLowerCase();

      const signals = {
        exactMatch: 0,
        symbolMatch: 0,
        pathRelevance: 0,
        importProximity: 0,
        layerRelevance: 0,
        intentRelevance: 0,
        testRelationship: 0,
        recentChange: 0
      };

      const reasons: string[] = [];

      // 1. Exact / Direct Name Match (Weight: 1.0)
      if (task.targetFiles && task.targetFiles.includes(filePath)) {
        signals.exactMatch = 1.0;
        reasons.push('Directly referenced in user request');
      } else if (promptLower.includes(fileName.toLowerCase())) {
        signals.exactMatch = 0.95;
        reasons.push(`File name "${fileName}" explicitly mentioned in prompt`);
      } else if (promptTokens.includes(baseName)) {
        signals.exactMatch = 0.85;
        reasons.push(`Base name "${baseName}" matched prompt token`);
      }

      // 2. Symbol Match (Weight: 0.9)
      if (fileData && fileData.symbols) {
        let matchedSymbolsCount = 0;
        const matchedNames: string[] = [];
        for (const sym of fileData.symbols) {
          const symNameLower = sym.name.toLowerCase();
          if (
            (task.affectedSymbols && task.affectedSymbols.includes(sym.name)) ||
            promptLower.includes(symNameLower) ||
            promptTokens.includes(symNameLower)
          ) {
            matchedSymbolsCount++;
            matchedNames.push(sym.name);
          }
        }
        if (matchedSymbolsCount > 0) {
          signals.symbolMatch = Math.min(1.0, 0.4 + matchedSymbolsCount * 0.2);
          reasons.push(`Defines requested symbol(s): [${matchedNames.slice(0, 3).join(', ')}]`);
        }
      }

      // 3. Path & Entity Relevance (Weight: 0.75)
      for (const entity of task.entities) {
        if (lowerPath.includes(entity)) {
          signals.pathRelevance = Math.max(signals.pathRelevance, 0.8);
          reasons.push(`Path matches entity "${entity}"`);
        }
      }

      // 4. Intent-Specific Relevance (Weight: 0.85)
      const isTestFile = lowerPath.includes('test') || lowerPath.includes('spec') || lowerPath.includes('__tests__');
      const isConfigFile = filePath.endsWith('.json') || filePath.endsWith('.config.ts') || filePath.endsWith('.config.js') || filePath.includes('.env');
      const isRouteFile = lowerPath.includes('route') || lowerPath.includes('api/') || lowerPath.includes('server');
      const isUIFile = lowerPath.includes('components/') || lowerPath.includes('views/') || lowerPath.includes('pages/');
      const isServiceFile = lowerPath.includes('services/') || lowerPath.includes('intelligence/') || lowerPath.includes('lib/');

      if (intent === 'TEST') {
        if (isTestFile) {
          signals.intentRelevance = 1.0;
          reasons.push('Test file matching TEST intent');
        } else if (signals.exactMatch > 0 || signals.symbolMatch > 0) {
          signals.intentRelevance = 0.8;
          reasons.push('Implementation target for tests');
        }
      } else if (intent === 'SECURITY') {
        if (lowerPath.includes('auth') || lowerPath.includes('token') || lowerPath.includes('security') || lowerPath.includes('env') || isConfigFile) {
          signals.intentRelevance = 0.95;
          reasons.push('Security-critical path / authentication / config');
        }
      } else if (intent === 'DEBUG') {
        if (task.errorDetails && task.errorDetails.toLowerCase().includes(baseName)) {
          signals.intentRelevance = 1.0;
          reasons.push('Mentioned in error diagnostics / stack trace');
        } else if (signals.symbolMatch > 0) {
          signals.intentRelevance = 0.85;
          reasons.push('Contains symbols under debug investigation');
        }
      } else if (intent === 'ARCHITECTURE') {
        if (fileData?.isEntry || isRouteFile || isServiceFile) {
          signals.intentRelevance = 0.8;
          reasons.push('Core architectural component / boundary');
        }
      } else if (intent === 'DOCUMENTATION' || intent === 'PROJECT_OVERVIEW') {
        if (filePath.endsWith('.md') || fileData?.isEntry) {
          signals.intentRelevance = 0.9;
          reasons.push('Documentation / Entrypoint file');
        }
      }

      // 5. Layer Alignment
      if (task.targetArea) {
        if (task.targetArea.includes('UI') && isUIFile) {
          signals.layerRelevance = 0.7;
        } else if (task.targetArea.includes('Services') && isServiceFile) {
          signals.layerRelevance = 0.7;
        } else if (task.targetArea.includes('API') && isRouteFile) {
          signals.layerRelevance = 0.7;
        }
      }

      // 6. Test Relationship for non-test queries (if related test exists)
      if (!isTestFile && intent !== 'TEST') {
        // slight down-weight of test files for non-test intents
      } else if (isTestFile && intent !== 'TEST') {
        signals.testRelationship = 0.3; // Low priority
      }

      // 7. Recent Change (Weight: 0.5)
      if (recentModifiedFiles.includes(filePath)) {
        signals.recentChange = 0.6;
        reasons.push('Recently modified in workspace');
      }

      // 8. Entry point bonus
      if (fileData?.isEntry && (intent === 'EXPLAIN' || intent === 'PROJECT_OVERVIEW' || intent === 'ARCHITECTURE')) {
        signals.layerRelevance = Math.max(signals.layerRelevance, 0.75);
        reasons.push('Primary application entry point');
      }

      // Calculate total weighted score
      const totalScore = Number((
        signals.exactMatch * 0.35 +
        signals.symbolMatch * 0.25 +
        signals.intentRelevance * 0.20 +
        signals.pathRelevance * 0.10 +
        signals.importProximity * 0.05 +
        signals.recentChange * 0.03 +
        signals.layerRelevance * 0.02
      ).toFixed(3));

      const finalReason = reasons.length > 0 ? reasons.join('; ') : 'General project file in workspace';

      return {
        filePath,
        totalScore,
        reason: finalReason,
        signals
      };
    });

    // Sort by totalScore descending
    return scores.sort((a, b) => b.totalScore - a.totalScore);
  }

  /**
   * Ranks candidate symbols
   */
  public static rankSymbols(
    symbols: ProjectSymbol[],
    prompt: string,
    intent: IntentCategory,
    task: TaskExtraction
  ): SymbolRankingScore[] {
    const promptLower = prompt.toLowerCase();
    const promptTokens = promptLower.split(/\W+/).filter(t => t.length > 2);

    const scores: SymbolRankingScore[] = symbols.map(sym => {
      const symNameLower = sym.name.toLowerCase();
      let score = 0;
      const reasons: string[] = [];

      if (task.affectedSymbols && task.affectedSymbols.includes(sym.name)) {
        score += 0.95;
        reasons.push('Explicitly identified as target symbol');
      } else if (promptLower.includes(symNameLower)) {
        score += 0.85;
        reasons.push(`Symbol name "${sym.name}" matched prompt`);
      } else if (promptTokens.some(t => symNameLower.includes(t))) {
        score += 0.5;
        reasons.push(`Symbol name partially matched prompt token`);
      }

      // Exported symbols score higher
      if (sym.isExported) {
        score += 0.1;
      }

      // Components score higher for UI intent
      if (sym.kind === 'component' && (task.targetArea?.includes('UI') || intent === 'IMPLEMENT')) {
        score += 0.15;
      }

      // Functions/routes score higher for API/Services intent
      if ((sym.kind === 'route' || sym.kind === 'function') && (intent === 'DEBUG' || intent === 'SEARCH')) {
        score += 0.15;
      }

      const totalScore = Number(Math.min(1.0, score).toFixed(3));
      const reason = reasons.length > 0 ? reasons.join('; ') : `Symbol declared in ${sym.filePath}`;

      return {
        symbol: sym,
        totalScore,
        reason
      };
    });

    return scores.sort((a, b) => b.totalScore - a.totalScore);
  }
}
