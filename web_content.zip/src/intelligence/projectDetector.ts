/**
 * GODEX Phase 1 - Project Characteristic & Framework Detector
 * Infers framework, runtime, primary language, package manager, build tool, and entry points.
 */

import { 
  DetectedFramework, 
  DetectedLanguage, 
  DetectedRuntime, 
  DetectedPackageManager, 
  DetectedBuildTool,
  ProjectMetadata 
} from './types';

export class ProjectDetector {
  public static detectLanguage(filePath: string): DetectedLanguage {
    if (filePath.endsWith('.tsx') || filePath.endsWith('.ts')) return 'typescript';
    if (filePath.endsWith('.jsx') || filePath.endsWith('.js') || filePath.endsWith('.mjs') || filePath.endsWith('.cjs')) return 'javascript';
    if (filePath.endsWith('.json')) return 'json';
    if (filePath.endsWith('.html') || filePath.endsWith('.htm')) return 'html';
    if (filePath.endsWith('.css') || filePath.endsWith('.scss') || filePath.endsWith('.sass') || filePath.endsWith('.less')) return 'css';
    if (filePath.endsWith('.py')) return 'python';
    if (filePath.endsWith('.md') || filePath.endsWith('.markdown')) return 'markdown';
    if (filePath.endsWith('.sh') || filePath.endsWith('.bash')) return 'shell';
    return 'unknown';
  }

  public static analyzeProjectMetadata(files: Record<string, string>): ProjectMetadata {
    const filePaths = Object.keys(files);
    let pkgJson: any = null;

    // Parse package.json if present
    if (files['package.json']) {
      try {
        pkgJson = JSON.parse(files['package.json']);
      } catch (e) {
        pkgJson = null;
      }
    }

    const dependencies = {
      ...(pkgJson?.dependencies || {}),
      ...(pkgJson?.devDependencies || {})
    };

    // 1. Detect Framework
    let framework: DetectedFramework = 'unknown';
    if (dependencies['next'] || filePaths.some(p => p.startsWith('pages/') || p.startsWith('app/'))) {
      framework = 'next';
    } else if (dependencies['react'] || dependencies['react-dom'] || filePaths.some(p => p.endsWith('.tsx') || p.endsWith('.jsx'))) {
      framework = 'react';
    } else if (dependencies['vue'] || filePaths.some(p => p.endsWith('.vue'))) {
      framework = 'vue';
    } else if (dependencies['svelte'] || filePaths.some(p => p.endsWith('.svelte'))) {
      framework = 'svelte';
    } else if (dependencies['@angular/core']) {
      framework = 'angular';
    } else if (dependencies['express'] || files['server.ts']?.includes('express') || files['server.js']?.includes('express')) {
      framework = 'express';
    } else if (filePaths.some(p => p.endsWith('.html'))) {
      framework = 'vanilla';
    }

    // 2. Detect Runtime
    let runtime: DetectedRuntime = 'browser';
    const hasServerFile = filePaths.some(p => p === 'server.ts' || p === 'server.js' || p.startsWith('api/') || p.startsWith('server/'));
    const hasClientUi = filePaths.some(p => p.endsWith('.tsx') || p.endsWith('.jsx') || p.endsWith('.html'));

    if (hasServerFile && hasClientUi) {
      runtime = 'fullstack';
    } else if (hasServerFile) {
      runtime = 'node';
    } else if (hasClientUi) {
      runtime = 'browser';
    }

    // 3. Detect Primary Language
    let tsCount = 0;
    let jsCount = 0;
    let pyCount = 0;

    for (const path of filePaths) {
      if (path.endsWith('.ts') || path.endsWith('.tsx')) tsCount++;
      else if (path.endsWith('.js') || path.endsWith('.jsx')) jsCount++;
      else if (path.endsWith('.py')) pyCount++;
    }

    let primaryLanguage: DetectedLanguage = 'typescript';
    if (tsCount >= jsCount && tsCount >= pyCount && tsCount > 0) {
      primaryLanguage = 'typescript';
    } else if (jsCount > tsCount && jsCount >= pyCount) {
      primaryLanguage = 'javascript';
    } else if (pyCount > 0 && pyCount > tsCount) {
      primaryLanguage = 'python';
    }

    // 4. Detect Package Manager
    let packageManager: DetectedPackageManager = 'npm';
    if (filePaths.some(p => p.includes('pnpm-lock'))) packageManager = 'pnpm';
    else if (filePaths.some(p => p.includes('yarn.lock'))) packageManager = 'yarn';
    else if (filePaths.some(p => p.includes('bun.lock') || p.includes('bun.lockb'))) packageManager = 'bun';

    // 5. Detect Build Tool
    let buildTool: DetectedBuildTool = 'none';
    if (dependencies['vite'] || filePaths.some(p => p.includes('vite.config'))) {
      buildTool = 'vite';
    } else if (dependencies['esbuild']) {
      buildTool = 'esbuild';
    } else if (dependencies['webpack'] || filePaths.some(p => p.includes('webpack.config'))) {
      buildTool = 'webpack';
    } else if (primaryLanguage === 'typescript') {
      buildTool = 'tsc';
    }

    // 6. Detect Entry Points
    const entryPoints: ProjectMetadata['entryPoints'] = {};
    if (files['src/main.tsx']) entryPoints.browser = 'src/main.tsx';
    else if (files['src/index.tsx']) entryPoints.browser = 'src/index.tsx';
    else if (files['src/main.ts']) entryPoints.browser = 'src/main.ts';
    else if (files['src/index.ts']) entryPoints.browser = 'src/index.ts';
    else if (files['src/App.tsx']) entryPoints.browser = 'src/App.tsx';

    if (files['server.ts']) entryPoints.server = 'server.ts';
    else if (files['server.js']) entryPoints.server = 'server.js';
    else if (files['src/server.ts']) entryPoints.server = 'src/server.ts';

    if (files['index.html']) entryPoints.html = 'index.html';
    if (files['src/index.css']) entryPoints.styles = 'src/index.css';
    else if (files['src/App.css']) entryPoints.styles = 'src/App.css';

    // 7. Find Config Files
    const configFiles = filePaths.filter(p => 
      p.endsWith('.config.js') || 
      p.endsWith('.config.ts') || 
      p.endsWith('.config.mjs') || 
      p.endsWith('.json') || 
      p.startsWith('.env') ||
      p.startsWith('tsconfig')
    );

    // 8. Extract Environment Keys
    const envKeysSet = new Set<string>();
    for (const [path, content] of Object.entries(files)) {
      if (path.startsWith('.env')) {
        const lines = content.split('\n');
        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed && !trimmed.startsWith('#') && trimmed.includes('=')) {
            envKeysSet.add(trimmed.split('=')[0].trim());
          }
        }
      } else {
        // Search for process.env.KEY and import.meta.env.KEY
        const processEnvRegex = /process\.env\.([A-Z0-9_]+)/g;
        let match: RegExpExecArray | null;
        while ((match = processEnvRegex.exec(content)) !== null) {
          envKeysSet.add(match[1]);
        }
        const importMetaRegex = /import\.meta\.env\.([A-Z0-9_]+)/g;
        while ((match = importMetaRegex.exec(content)) !== null) {
          envKeysSet.add(match[1]);
        }
      }
    }

    let totalLines = 0;
    let totalBytes = 0;
    for (const content of Object.values(files)) {
      totalLines += content ? content.split('\n').length : 0;
      totalBytes += content ? content.length : 0;
    }

    return {
      name: pkgJson?.name || 'godex-workspace',
      version: pkgJson?.version || '1.0.0',
      description: pkgJson?.description,
      framework,
      runtime,
      primaryLanguage,
      packageManager,
      buildTool,
      entryPoints,
      configFiles,
      envKeys: Array.from(envKeysSet),
      totalFiles: filePaths.length,
      totalLines,
      totalBytes
    };
  }
}
