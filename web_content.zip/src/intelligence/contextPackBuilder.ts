/**
 * GODEX Phase 2 - Context Pack Builder
 * Assembles the complete formal ContextPack for the AI Brain with full traceability,
 * reasoning justifications ("Why did you include this file?"), and token budgeting.
 */

import { 
  ContextPack, 
  ContextBudgetConfig, 
  TaskExtraction, 
  IntentCategory 
} from './contextTypes';
import { ProjectIntelligenceState } from './types';
import { ProjectSummaryGenerator } from './projectSummaryGenerator';
import { ContextRetriever } from './contextRetriever';
import { ContextBudgetEngine, DEFAULT_CONTEXT_BUDGET } from './contextBudget';
import { MemoryQueryService } from '../memory/memoryQuery';
import { GitIntelligence } from '../git/gitIntelligence';

export class ContextPackBuilder {
  /**
   * Constructs a fully qualified ContextPack
   */
  public static build(
    userPrompt: string,
    intent: IntentCategory,
    task: TaskExtraction,
    intelState: ProjectIntelligenceState,
    rawFiles: Record<string, string>,
    budget: ContextBudgetConfig = DEFAULT_CONTEXT_BUDGET,
    recentChanges: string[] = []
  ): ContextPack {
    const projectSummary = ProjectSummaryGenerator.generate(intelState);

    // 1. Retrieve raw candidates
    const retrieved = ContextRetriever.retrieve(
      userPrompt,
      intent,
      task,
      intelState,
      rawFiles,
      budget,
      recentChanges
    );

    // 2. Apply Budget and Smart Compression
    const {
      compressedFiles,
      compressedSymbols,
      totalCharacters,
      totalTokens,
      budgetUsagePercent
    } = ContextBudgetEngine.applyBudget(retrieved.files, retrieved.symbols, budget);

    // 3. Assemble Architecture Summary
    const architectureSummary = {
      totalLayers: projectSummary.architectureLayers.length,
      layersPresent: projectSummary.architectureLayers,
      keyNodes: compressedFiles.filter(f => f.isEntry || f.symbolsCount > 2).map(f => f.path),
      circularWarnings: intelState.graph.circularDependencies || [],
      healthScore: projectSummary.healthScore
    };

    // 4. Retrieve Scoped Engineering Memory
    const targetFilePaths = Array.from(new Set([
      ...compressedFiles.map(f => f.path),
      ...(task.targetFiles || []),
      ...(task.entities || [])
    ]));
    const affectedSymbolNames = Array.from(new Set([
      ...compressedSymbols.map(s => s.name),
      ...(task.affectedSymbols || [])
    ]));
    const scoredMemories = MemoryQueryService.getScopedMemoryForAgent(
      'GENERAL',
      targetFilePaths,
      affectedSymbolNames,
      task.errorDetails,
      undefined,
      4
    );

    const memoryReasons: Record<string, string> = {};
    const engineeringMemory = scoredMemories.map(sm => {
      memoryReasons[sm.memory.id] = sm.whyIncluded;
      return {
        id: sm.memory.id,
        type: sm.memory.type,
        content: sm.memory.content,
        epistemicStatus: sm.memory.epistemicStatus,
        whyIncluded: sm.whyIncluded
      };
    });

    // 5. Retrieve Relevant Git History
    const gitCommits = GitIntelligence.getInstance().getRecentCommits(3).map(c => ({
      hash: c.hash,
      shortHash: c.shortHash,
      message: c.message,
      author: c.author,
      date: c.date
    }));

    // 6. Build Detailed Explanations
    const fileReasons: Record<string, string> = {};
    for (const f of compressedFiles) {
      fileReasons[f.path] = f.reason;
    }

    const symbolReasons: Record<string, string> = {};
    for (const s of compressedSymbols) {
      symbolReasons[s.name] = `${s.reason} (${s.filePath}:${s.line})`;
    }

    const packId = 'ctx-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);

    return {
      id: packId,
      createdAt: Date.now(),
      userPrompt,
      taskIntent: intent,
      taskExtraction: task,
      projectSummary,
      relevantFiles: compressedFiles,
      relevantSymbols: compressedSymbols,
      architectureSummary,
      dependencies: retrieved.dependencies,
      tests: retrieved.tests,
      documentation: retrieved.documentation,
      recentChanges: retrieved.recentChanges,
      constraints: task.constraints,
      warnings: retrieved.warnings,
      totalTokensEstimate: totalTokens,
      totalCharacters,
      budgetUsagePercent,
      budget,
      engineeringMemory,
      gitHistory: gitCommits,
      explanation: {
        fileReasons,
        symbolReasons,
        memoryReasons
      }
    };
  }
}
