/**
 * GODEX Phase 2 - Intent Classification Engine
 * High-precision, multi-signal heuristic & semantic classifier for developer requests.
 * Classifies into 13 typed categories with confidence scoring, secondary intent detection,
 * and context mode routing.
 */

import { IntentCategory, IntentClassificationResult, ChatRoutingCategory } from './contextTypes';

interface IntentRule {
  intent: IntentCategory;
  patterns: RegExp[];
  keywords: string[];
  weight: number;
}

export class IntentClassifier {
  private static readonly RULES: IntentRule[] = [
    {
      intent: 'DEBUG',
      patterns: [
        /why\s+(?:does|is|did|won't|can't)\s+/i,
        /(?:fix|solve|resolve|debug|diagnose|troubleshoot)\s+(?:error|bug|issue|failure|exception|crash|problem)/i,
        /error(?::|\s+in|\s+at|\s+occurred)|exception|stack\s*trace|crash|failed\s+to/i,
        /cannot\s+read\s+properties|undefined\s+is\s+not|null\s+pointer|is\s+not\s+a\s+function/i,
        /broken|failing|not\s+working|throws?\s+(?:an?\s+)?error/i
      ],
      keywords: ['fix', 'debug', 'error', 'bug', 'fail', 'failing', 'crash', 'exception', 'stacktrace', 'broken', 'issue', 'solve', 'problem'],
      weight: 1.3
    },
    {
      intent: 'SEARCH',
      patterns: [
        /where\s+(?:is|are|can\s+i\s+find|is\s+the|does)\s+/i,
        /find\s+(?:all\s+)?(?:files?|symbols?|functions?|classes?|usages?|references?|routes?)/i,
        /search\s+(?:for|in|workspace)/i,
        /locate\s+/i,
        /which\s+file\s+(?:contains|has|handles|defines)/i,
        /list\s+all\s+(?:components|routes|endpoints|services|types)/i
      ],
      keywords: ['where', 'find', 'search', 'locate', 'which file', 'list all', 'references of', 'usages of'],
      weight: 1.2
    },
    {
      intent: 'EXPLAIN',
      patterns: [
        /explain\s+(?:how|what|why|the)?/i,
        /what\s+does\s+(?:this|the)?\s*[\w.-]+\s*(?:do|mean)/i,
        /how\s+does\s+[\w.-]+\s+work/i,
        /walk\s+me\s+through/i,
        /help\s+me\s+understand/i,
        /give\s+an\s+overview\s+of\s+how/i
      ],
      keywords: ['explain', 'understand', 'how does', 'what does', 'walkthrough', 'meaning of', 'concept'],
      weight: 1.1
    },
    {
      intent: 'SECURITY',
      patterns: [
        /security\s+(?:audit|check|review|vulnerability|flaw|leak)/i,
        /(?:secret|token|api\s*key|password|credential|jwt|auth\s*token)\s+(?:leak|exposed|hardcoded|storage)/i,
        /xss|csrf|injection|cors|sanitiz|vulnerab/i,
        /is\s+(?:this|the\s+app)\s+secure/i,
        /check\s+for\s+(?:vulnerabilities|security\s+issues|leaks)/i
      ],
      keywords: ['security', 'vulnerability', 'xss', 'csrf', 'secret', 'apikey', 'credential', 'leak', 'sanitize', 'auth token', 'cors'],
      weight: 1.3
    },
    {
      intent: 'ARCHITECTURE',
      patterns: [
        /architecture\s+(?:overview|review|design|diagram|structure)/i,
        /module\s+(?:coupling|cohesion|layers?|boundaries)/i,
        /circular\s+(?:dependency|import|loop)/i,
        /how\s+is\s+the\s+(?:project|system|app)\s+structured/i,
        /layer\s+separation|separation\s+of\s+concerns/i,
        /data\s+flow|state\s+management\s+pattern/i
      ],
      keywords: ['architecture', 'structure', 'coupling', 'cohesion', 'circular dependency', 'layer', 'system design', 'data flow'],
      weight: 1.2
    },
    {
      intent: 'REFACTOR',
      patterns: [
        /refactor\s+/i,
        /clean\s+up\s+(?:the\s+code|duplicate|messy)/i,
        /simplify\s+(?:the\s+logic|function|component)/i,
        /remove\s+(?:duplicate|redundant|dead|unused)\s+(?:code|logic|functions?)/i,
        /extract\s+(?:into\s+a\s+hook|component|helper|service)/i,
        /optimize\s+(?:structure|performance|re-renders)/i,
        /modularize\s+/i
      ],
      keywords: ['refactor', 'clean up', 'simplify', 'remove duplicate', 'extract', 'modularize', 'optimize', 'dry', 'dead code'],
      weight: 1.2
    },
    {
      intent: 'TEST',
      patterns: [
        /(?:write|add|generate|run|create)\s+(?:unit\s+|integration\s+|e2e\s+)?tests?/i,
        /test\s+(?:coverage|cases?|suite)/i,
        /how\s+to\s+test\s+/i,
        /assert\s+|mock\s+|jest|vitest|playwright/i,
        /testing\s+strategy/i
      ],
      keywords: ['test', 'tests', 'unit test', 'integration test', 'mock', 'assertion', 'coverage', 'vitest', 'jest', 'spec'],
      weight: 1.2
    },
    {
      intent: 'REVIEW',
      patterns: [
        /code\s+review|review\s+(?:this|my|the)?\s*(?:code|pr|pull\s+request|file|changes)/i,
        /critique\s+(?:this|the)/i,
        /any\s+(?:improvements|best\s+practices|code\s+smells)/i,
        /audit\s+(?:this|the\s+file)/i
      ],
      keywords: ['review', 'code review', 'critique', 'audit', 'code smell', 'best practices', 'lint issue', 'feedback'],
      weight: 1.15
    },
    {
      intent: 'DOCUMENTATION',
      patterns: [
        /(?:write|generate|add|update)\s+(?:docs|documentation|readme|jsdoc|docstrings?|comments?)/i,
        /document\s+(?:the\s+api|component|service|functions?)/i,
        /api\s+docs?|changelog/i
      ],
      keywords: ['doc', 'docs', 'documentation', 'readme', 'jsdoc', 'docstring', 'comment', 'changelog', 'document'],
      weight: 1.1
    },
    {
      intent: 'PROJECT_OVERVIEW',
      patterns: [
        /what\s+is\s+this\s+project/i,
        /project\s+(?:overview|summary|info|stats|health)/i,
        /tell\s+me\s+about\s+(?:this|the)\s+project/i,
        /what\s+tech\s+stack\s+is\s+used/i,
        /summarize\s+(?:the\s+codebase|this\s+repository)/i
      ],
      keywords: ['project overview', 'codebase summary', 'what is this project', 'tech stack', 'health score', 'repository stats'],
      weight: 1.15
    },
    {
      intent: 'GIT',
      patterns: [
        /git\s+(?:status|diff|commit|branch|log|merge|stash|revert)/i,
        /version\s+control|recent\s+changes|snapshots?/i,
        /who\s+changed\s+|commit\s+history/i
      ],
      keywords: ['git', 'commit', 'branch', 'diff', 'stash', 'merge', 'snapshot', 'version control', 'git status'],
      weight: 1.1
    },
    {
      intent: 'IMPLEMENT',
      patterns: [
        /(?:add|create|build|implement|make|generate|write|develop|construct|design)\s+(?:me\s+)?(?:a\s+|an\s+|the\s+)?(?:new\s+)?(?:app|application|project|tool|website|game|feature|component|page|endpoint|service|function|hook|button|modal|view|handler|screen|dashboard)/i,
        /(?:mere\s+liye\s+)?(?:ek\s+)?(?:app|application|project|component)\s+(?:bana|banao|banaye|karo|bana\s+ke\s+deh|bana\s+do|banado)/i,
        /(?:banao|bana|likho|kardo|banado)\s+(?:ek\s+)?(?:app|application|project|feature)/i,
        /(?:integrate|connect|hook\s+up)\s+/i,
        /support\s+(?:for|adding)\s+/i
      ],
      keywords: ['add', 'create', 'build', 'implement', 'make', 'generate', 'write', 'develop', 'integrate', 'support', 'bana', 'banao', 'banado', 'app', 'application'],
      weight: 1.2
    }
  ];

  /**
   * Classify user request prompt into structured IntentClassificationResult
   */
  public static classify(userPrompt: string): IntentClassificationResult {
    const cleanPrompt = userPrompt.trim();
    if (!cleanPrompt) {
      return {
        intent: 'GENERAL',
        route: 'CONVERSATIONAL',
        confidence: 0.5,
        reason: 'Empty prompt defaulted to GENERAL',
        matchedKeywords: [],
        suggestedContextMode: 'GENERAL'
      };
    }

    const scores: Record<IntentCategory, { score: number; matchedKeywords: string[]; patternsCount: number }> = {
      EXPLAIN: { score: 0, matchedKeywords: [], patternsCount: 0 },
      SEARCH: { score: 0, matchedKeywords: [], patternsCount: 0 },
      DEBUG: { score: 0, matchedKeywords: [], patternsCount: 0 },
      IMPLEMENT: { score: 0, matchedKeywords: [], patternsCount: 0 },
      REFACTOR: { score: 0, matchedKeywords: [], patternsCount: 0 },
      REVIEW: { score: 0, matchedKeywords: [], patternsCount: 0 },
      TEST: { score: 0, matchedKeywords: [], patternsCount: 0 },
      ARCHITECTURE: { score: 0, matchedKeywords: [], patternsCount: 0 },
      SECURITY: { score: 0, matchedKeywords: [], patternsCount: 0 },
      DOCUMENTATION: { score: 0, matchedKeywords: [], patternsCount: 0 },
      PROJECT_OVERVIEW: { score: 0, matchedKeywords: [], patternsCount: 0 },
      GIT: { score: 0, matchedKeywords: [], patternsCount: 0 },
      GENERAL: { score: 0.1, matchedKeywords: [], patternsCount: 0 }
    };

    const lower = cleanPrompt.toLowerCase();

    // Check each rule
    for (const rule of this.RULES) {
      // 1. Regex pattern matches (high weight)
      for (const pattern of rule.patterns) {
        if (pattern.test(cleanPrompt)) {
          scores[rule.intent].score += 3.5 * rule.weight;
          scores[rule.intent].patternsCount += 1;
        }
      }

      // 2. Keyword occurrences (scaled by length & frequency)
      for (const kw of rule.keywords) {
        const regex = new RegExp(`\\b${kw.replace(/\s+/g, '\\s+')}\\b`, 'i');
        if (regex.test(cleanPrompt)) {
          scores[rule.intent].score += 1.2 * rule.weight;
          if (!scores[rule.intent].matchedKeywords.includes(kw)) {
            scores[rule.intent].matchedKeywords.push(kw);
          }
        }
      }
    }

    // Heuristics for question structures
    if (lower.startsWith('where') || lower.includes('where is') || lower.includes('where are')) {
      scores.SEARCH.score += 2.5;
    }
    if (lower.startsWith('why') || lower.includes('why is') || lower.includes('why does')) {
      // Could be debug or explain
      if (lower.includes('error') || lower.includes('fail') || lower.includes('not working') || lower.includes('broken')) {
        scores.DEBUG.score += 3.0;
      } else {
        scores.EXPLAIN.score += 2.0;
      }
    }
    if (lower.startsWith('how to test') || lower.includes('run test')) {
      scores.TEST.score += 3.0;
    }
    if (lower.includes('security') || lower.includes('vulnerability') || lower.includes('secret')) {
      scores.SECURITY.score += 2.5;
    }

    // Sort entries by score descending
    const sorted = (Object.entries(scores) as [IntentCategory, { score: number; matchedKeywords: string[]; patternsCount: number }][])
      .sort((a, b) => b[1].score - a[1].score);

    const best = sorted[0] || ['GENERAL', { score: 0.1, matchedKeywords: [], patternsCount: 0 }];
    const second = sorted[1];
    const secondScore = second && second[1] ? second[1].score : 0;

    let finalIntent: IntentCategory = best[1].score > 0.4 ? best[0] : 'GENERAL';
    const confidence = Math.min(1.0, Math.max(0.4, Number((best[1].score / (best[1].score + secondScore + 1)).toFixed(2))));

    const secondaryIntents: IntentCategory[] = sorted
      .filter(([intent, data]) => intent !== finalIntent && data.score > 1.5)
      .map(([intent]) => intent);

    const reason = best[1].patternsCount > 0 
      ? `Matched ${best[1].patternsCount} semantic pattern(s) and keywords: [${best[1].matchedKeywords.join(', ')}]`
      : (best[1].matchedKeywords.length > 0 
          ? `Matched keywords: [${best[1].matchedKeywords.join(', ')}]` 
          : 'Heuristic structural evaluation');

    const routeInfo = this.classifyChatRoute(cleanPrompt, finalIntent);

    return {
      intent: finalIntent,
      route: routeInfo.route,
      confidence,
      secondaryIntents: secondaryIntents.length > 0 ? secondaryIntents : undefined,
      reason: `${reason} (Route: ${routeInfo.route})`,
      matchedKeywords: best[1].matchedKeywords,
      suggestedContextMode: finalIntent,
      clarificationPrompt: routeInfo.clarificationPrompt
    };
  }

  /**
   * Deterministic, intent-aware routing classification for GODEX Chat.
   * Classifies user requests into:
   * 1. CONVERSATIONAL (Greetings, system explanations, capabilities, advice without code changes)
   * 2. READ_ONLY_ENGINEERING_QUERY (File search, module inspection, symbol lookups, questions about codebase)
   * 3. ENGINEERING_ACTION (Directives to create, modify, refactor, fix, or run pipelines)
   * 4. AMBIGUOUS (Vague prompts that could mean either discussion or action)
   */
  public static classifyChatRoute(
    userPrompt: string,
    inferredIntent?: IntentCategory
  ): {
    route: ChatRoutingCategory;
    intent: IntentCategory;
    clarificationPrompt?: string;
    reason: string;
  } {
    const raw = userPrompt.trim();
    const lower = raw.toLowerCase().replace(/[?!.,;:]+$/, '').trim();

    // --- 1. CONVERSATIONAL: Greetings & Capability Inquiries ---
    const isGreeting = /^(?:hello|hi|hey|greetings|good\s+(?:morning|afternoon|evening)|howdy)(?:\s+godex|\s+there|\s+ai|\s+studio|\s*!)?$/i.test(lower);
    const isHowAreYou = /^(?:(?:i said|i asked|no i said|i mean)\s+)?(?:(?:hey|hi|hello)[ ,]+)?(?:how are you(?: doing)?|how're you|how is it going|how's it going|what's up|how do you do)[?.!\s]*$/i.test(lower);
    const isCapabilityInquiry = /\b(?:what\s+(?:can|do)\s+you\s+(?:currently\s+)?do|what\s+are\s+your\s+capabilities|who\s+are\s+you|tell\s+me\s+about\s+yourself|what\s+is\s+godex|what\s+can\s+godex\s+do|explain\s+what\s+you\s+can\s+(?:currently\s+)?do|how\s+can\s+you\s+help|what\s+are\s+you\s+capable\s+of)\b/i.test(lower);
    
    if (isGreeting || isHowAreYou || isCapabilityInquiry || lower.startsWith('hello godex, explain what you can currently do') || lower.startsWith('hello godex')) {
      if (lower.includes('build') || lower.includes('create a file') || lower.includes('fix the') || lower.includes('now and make')) {
        // If there's an explicit secondary engineering command, let it fall through
      } else {
        return {
          route: 'CONVERSATIONAL',
          intent: 'GENERAL',
          reason: 'Greeting or general capability inquiry'
        };
      }
    }

    // --- 2. READ-ONLY ENGINEERING QUERY (Specific files, modules, symbols, codebase inspections, audits) ---
    // e.g. "Inspect the codebase", "List all components", "Audit dependencies", "Where is GodexChatView?", "Explain how OperationManager works"
    const isExplicitReadOnlyVerb = /^(?:inspect|audit|explain|find|search|locate|list|show|check|review|summarize|diagnose|analyze|describe|read|query)\b/i.test(lower) ||
      /\b(?:without\s+(?:modifying|changing|editing|writing)|read-only|read\s+only|just\s+tell\s+me|just\s+explain|give\s+an\s+overview)\b/i.test(lower);

    const isFileLocationQuery = /\b(?:which\s+file\s+(?:contains|has|defines|implements|renders)|where\s+is\s+[a-zA-Z0-9_\-\./]+(?:\s+(?:implemented|defined|located|rendered|stored))?|where\s+(?:are\s+the|can\s+i\s+find)|find\s+all\s+(?:references|usages|symbols|routes|files|components)|locate\s+the\s+file)\b/i.test(lower);
    
    const isCodebaseSymbolOrInspectionQuery = /\b(?:what\s+is\s+(?:the\s+)?|how\s+does\s+(?:the\s+)?|explain\s+(?:the\s+)?|where\s+is\s+(?:the\s+)?)(?:godexcontrolplane|controlplane|operationmanager|toolsystem|workspaceservice|astparser|graphbuilder|healthanalyzer|eventbus|modelprovider|godexchatview|chatview|previewhealthreport|previewservice|filetreeview|inspectorview)\b/i.test(lower) ||
      /^(?:explain\s+(?:the\s+)?|how\s+does\s+(?:the\s+)?)(?:[a-zA-Z0-9_$]+(?:\.tsx|\.ts|\.js|\.jsx)?)\s*(?:and\s+how\s+does\s+it\s+work|work|function|operate)?\??$/i.test(lower) ||
      /\b(?:list\s+all\s+(?:components|files|symbols|routes|dependencies|exports|interfaces)|search\s+for\s+(?:symbol|file|function)|show\s+me\s+symbols\s+in|check\s+(?:if\s+there\s+are\s+)?circular\s+dependencies|audit\s+dependencies\s+without\s+changing|inspect\s+(?:the\s+)?(?:workspace|codebase|repository|project|app|files))\b/i.test(lower);

    // Check if there is an explicit negative mutation guard (e.g., "do not modify anything", "without changing code", "read-only")
    const hasNegativeMutationGuard = /\b(?:do\s+not\s+(?:modify|change|edit|touch|write|mutate)|don't\s+(?:modify|change|edit|touch|write|mutate)|without\s+(?:modifying|changing|editing|writing|touching)|read-only|read\s+only|no\s+(?:changes|mutation|code\s+changes|edits))\b/i.test(lower);

    const isAppBuildingDirective = 
      /\b(?:build|create|make|generate|develop|construct)\s+(?:me\s+)?(?:an?|the)?\s*(?:new\s+)?(?:app|application|tool|dashboard|game|project|website)\b/i.test(lower) ||
      /\b(?:mere\s+liye\s+)?(?:ek\s+)?app\s+(?:bana|banao|banaye|karo|bana\s+ke\s+deh|bana\s+do|banado)\b/i.test(lower) ||
      /\b(?:banao|bana|banado)\s+(?:ek\s+)?(?:app|application|project)\b/i.test(lower);

    // Check if there is an explicit mutation command overriding read-only intent (only valid if not guarded)
    const hasMutatingDirective = !hasNegativeMutationGuard && (
      isAppBuildingDirective ||
      /\b(?:refactor|fix|change|update|delete|remove|rewrite|modify|create|build|implement|patch|write|add\s+(?:a\s+new|component|file|code)|bana|banao|likho|kardo|banado)\s+(?:godexcontrolplane|controlplane|operationmanager|toolsystem|workspaceservice|astparser|file|code|component|ui|app|application|project|feature)\b/i.test(lower) ||
      /\b(?:apply\s+now|implement\s+it\s+now|change\s+it\s+now|create\s+it\s+now|make\s+the\s+change)\b/i.test(lower)
    );

    if (hasNegativeMutationGuard || ((isExplicitReadOnlyVerb || isFileLocationQuery || isCodebaseSymbolOrInspectionQuery) && !hasMutatingDirective)) {
      return {
        route: 'READ_ONLY_ENGINEERING_QUERY',
        intent: isFileLocationQuery || /find|search|locate|list/i.test(lower) ? 'SEARCH' : (inferredIntent || 'EXPLAIN'),
        reason: hasNegativeMutationGuard ? 'Explicit read-only constraint specified by user' : 'Read-only codebase inspection or symbol/file location query'
      };
    }

    // --- 3. CONVERSATIONAL: Advice, Recommendations & General Conceptual Questions ---
    // e.g. "How could I improve the GODEX Chat UI?", "Suggest three ways to improve the Chat UI.", "What should I improve in the Chat UI?", "Explain how I could improve the Chat UI."
    const isAdviceOrIdeaQuery = /\b(?:what\s+should\s+i\s+(?:improve|build|do|change|refactor)\s*(?:next)?|explain\s+how\s+(?:i|we|one)\s+could\s+(?:improve|optimize|refactor|design|build)|how\s+(?:could|can|would)\s+(?:i|we|one)\s+(?:improve|make\s+better|optimize|enhance)|suggest\s+.*?\b(?:ways|ideas|methods|improvements|tips|suggestions|features|options)\b|can\s+you\s+suggest|give\s+(?:me\s+)?(?:advice|suggestions?|ideas?|recommendations?|tips)|what\s+are\s+(?:some\s+)?(?:ways|methods|best\s+practices|ideas)\s+to\s+improve)\b/i.test(lower);
    
    const isConceptualQuestion = /^(?:what\s+is\s+(?:the\s+)?|how\s+does\s+(?:the\s+)?|why\s+is\s+(?:the\s+|my\s+)?|why\s+does\s+(?:the\s+)?|explain\s+(?:the\s+)?)(?:architecture|preview|system|agent\s*matrix|workspace|runtime|sandbox|pipeline)(?:\s+slow|\s+work|\s+designed|\s+structured|\s+implemented)?\??$/i.test(lower);

    if (isAdviceOrIdeaQuery || isConceptualQuestion) {
      // Must NOT be an imperative command with direct action keywords like "now", "and change", "banao", "create", "please improve ... now"
      if (!/\b(?:now\s+and|apply\s+now|implement\s+it\s+now|change\s+it\s+now|go\s+ahead\s+and|improve\s+.*?\bnow|please\s+improve\s+.*?\bnow)\b/i.test(lower)) {
        return {
          route: 'CONVERSATIONAL',
          intent: 'EXPLAIN',
          reason: 'Conceptual explanation or engineering advice query'
        };
      }
    }

    // --- 4. AMBIGUOUS: Truly Vague / Open-ended without specific directives or details ---
    // e.g. "Make the Chat better.", "Make the app better.", "The Chat needs work.", "Can we improve this?", "Improve this."
    const isGenuinelyAmbiguous = 
      /^(?:can\s+(?:you|we)\s+)?make\s+(?:the\s+)?(?:chat|app|application|system|it|this|ui|code)\s+better[\.\?!]?$/i.test(lower) ||
      /^(?:can\s+(?:you|we)\s+)?make\s+it\s+(?:better|faster|work|nicer)[\.\?!]?$/i.test(lower) ||
      /^(?:can\s+(?:you|we)\s+)?improve\s+(?:this|it|the\s+app|the\s+application)[\.\?!]?$/i.test(lower) ||
      /^(?:the\s+)?(?:chat|app|application|system|code|ui)\s+needs\s+work[\.\?!]?$/i.test(lower) ||
      /^(?:can\s+(?:you|we)\s+)?do\s+something\s+(?:with|about)\s+(?:this|it|the\s+app|the\s+chat)[\.\?!]?$/i.test(lower);

    // Must NOT contain compound clauses, specific sub-components, properties, or detailed instructions
    const hasConcreteDetails = 
      lower.includes('composer') ||
      lower.includes('rendering') ||
      lower.includes('empty state') ||
      lower.includes('button') ||
      lower.includes('shortcut') ||
      lower.includes('logo') ||
      lower.includes('preview') ||
      lower.includes('dark mode') ||
      lower.includes('layout') ||
      lower.includes('polished') ||
      lower.includes('smoother') ||
      lower.includes('responsive') ||
      lower.includes('error') ||
      lower.includes('test') ||
      lower.includes('feature') ||
      lower.includes('component') ||
      lower.includes('and ') ||
      lower.includes('with ') ||
      lower.includes('by ') ||
      lower.includes('now');

    if (isGenuinelyAmbiguous && !hasConcreteDetails) {
      return {
        route: 'AMBIGUOUS',
        intent: 'GENERAL',
        clarificationPrompt: 'Do you want suggestions, or should I actually modify the GODEX application?',
        reason: 'Ambiguous request requiring developer clarification'
      };
    }

    // --- 5. LONG-HORIZON MISSION (Complex multi-step engineering directives) ---
    const isExplicitMissionDirective = 
      /^\/mission\b/i.test(raw) ||
      /\b(?:start|run|launch|execute)\s+(?:a\s+)?(?:new\s+)?(?:autonomous\s+)?mission\b/i.test(lower) ||
      /\b(?:long-horizon|long\s+horizon|multi-phase|multi-stage|multi-step\s+(?:mission|workflow|plan|feature|refactor|overhaul))\b/i.test(lower) ||
      /\b(?:architect,\s*implement(?:,\s*test)?\s+and\s+verify|full\s+lifecycle\s+overhaul|end-to-end\s+system\s+refactor|decompose\s+and\s+execute)\b/i.test(lower) ||
      (/\b(?:phase\s+1|step\s+1|milestone\s+1)\b/i.test(lower) && /\b(?:phase\s+2|step\s+2|milestone\s+2)\b/i.test(lower));

    if (isExplicitMissionDirective) {
      return {
        route: 'LONG_HORIZON_MISSION',
        intent: inferredIntent || 'IMPLEMENT',
        reason: 'Complex multi-step engineering mission requiring DAG decomposition and autonomy policy'
      };
    }

    // --- 6. ENGINEERING ACTION ---
    // All imperative instructions to create, build, fix, change, refactor, add, improve, or implement code
    const isImperativeAction = isAppBuildingDirective || /\b(?:build|create|implement|make|add|fix|change|refactor|update|delete|remove|patch|write|generate|modify|bana|banao|likho|kardo|banado|integrate|setup|repair|debug|test|run|replace|redesign|rewrite|improve|enhance)\b/i.test(lower);
    
    // Explicit requests directed at codebase targets, UI elements, or system features
    const hasEngineeringTarget = /\b(?:app|apps|application|applications|project|dashboard|tool|website|chat|ui|composer|preview|logo|shortcut|shortcuts|dark\s*mode|godexchatview|layout|button|component|error|tests?|feature|empty\s*state|view|service|handler|route|store|state|api|css|style|styles|experience)\b/i.test(lower);

    if (isAppBuildingDirective || isImperativeAction || hasEngineeringTarget || inferredIntent === 'IMPLEMENT' || inferredIntent === 'REFACTOR' || inferredIntent === 'DEBUG' || inferredIntent === 'TEST') {
      return {
        route: 'ENGINEERING_ACTION',
        intent: isAppBuildingDirective ? 'IMPLEMENT' : (inferredIntent || 'IMPLEMENT'),
        reason: isAppBuildingDirective
          ? 'Explicit application creation directive routed to engineering pipeline'
          : 'Explicit engineering action directive requiring authoritative pipeline execution'
      };
    }

    // Fallback: If not explicitly action-driven, default to CONVERSATIONAL for safety
    return {
      route: 'CONVERSATIONAL',
      intent: inferredIntent || 'GENERAL',
      reason: 'Standard conversational query'
    };
  }
}

