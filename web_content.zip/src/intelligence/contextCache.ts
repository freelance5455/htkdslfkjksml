/**
 * GODEX Phase 2 - Context Cache & Incremental Invalidation
 * Caches project summaries, ranked file slices, and recent ContextPacks.
 * Automatically invalidates entries when relevant files change.
 */

import { ContextPack, ProjectSummary } from './contextTypes';
import { WorkspaceService } from '../services/workspaceService';

export class ContextCacheManager {
  private static instance: ContextCacheManager;
  private projectSummaryCache: { data: ProjectSummary; timestamp: number } | null = null;
  private contextPackCache: Map<string, { pack: ContextPack; timestamp: number }> = new Map();
  private fileHashCache: Map<string, string> = new Map();

  private constructor() {
    this.setupWorkspaceListeners();
  }

  public static getInstance(): ContextCacheManager {
    if (!this.instance) {
      this.instance = new ContextCacheManager();
    }
    return this.instance;
  }

  private setupWorkspaceListeners(): void {
    if (typeof window !== 'undefined') {
      WorkspaceService.subscribe((event) => {
        if (event.path) {
          this.invalidatePath(event.path);
        } else {
          this.invalidateAll();
        }
      });
    }
  }

  public getSummary(): ProjectSummary | null {
    if (this.projectSummaryCache && Date.now() - this.projectSummaryCache.timestamp < 60000) {
      return this.projectSummaryCache.data;
    }
    return null;
  }

  public setSummary(summary: ProjectSummary): void {
    this.projectSummaryCache = {
      data: summary,
      timestamp: Date.now()
    };
  }

  public getContextPack(prompt: string): ContextPack | null {
    const entry = this.contextPackCache.get(prompt);
    if (entry && Date.now() - entry.timestamp < 30000) {
      return entry.pack;
    }
    return null;
  }

  public setContextPack(prompt: string, pack: ContextPack): void {
    this.contextPackCache.set(prompt, {
      pack,
      timestamp: Date.now()
    });
    // Keep max 20 cached packs
    if (this.contextPackCache.size > 20) {
      const oldestKey = this.contextPackCache.keys().next().value;
      if (oldestKey) this.contextPackCache.delete(oldestKey);
    }
  }

  public invalidatePath(path: string): void {
    this.projectSummaryCache = null;
    this.fileHashCache.delete(path);
    // Invalidate any context packs containing this file
    for (const [key, entry] of this.contextPackCache.entries()) {
      if (entry.pack.relevantFiles.some(f => f.path === path)) {
        this.contextPackCache.delete(key);
      }
    }
  }

  public invalidateForFile(path: string): void {
    this.invalidatePath(path);
  }

  public invalidateAll(): void {
    this.projectSummaryCache = null;
    this.contextPackCache.clear();
    this.fileHashCache.clear();
  }

  public clear(): void {
    this.invalidateAll();
  }
}

export const ContextCache = ContextCacheManager.getInstance();
