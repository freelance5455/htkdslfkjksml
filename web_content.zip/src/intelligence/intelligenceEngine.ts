/**
 * GODEX Phase 1 - Project Intelligence Engine (Master Orchestrator)
 * Central store managing project indexing lifecycle, incremental updates, and state persistence.
 */

import { 
  ProjectIntelligenceState, 
  IndexingStatus, 
  ProjectMetadata, 
  ProjectFolderNode 
} from './types';
import { IgnoreSystem } from './ignoreSystem';
import { ProjectDetector } from './projectDetector';
import { DependencyAnalyzer } from './dependencyAnalyzer';
import { AstParser, ParsedFileAst } from './astParser';
import { SymbolIndex } from './symbolIndex';
import { GraphBuilder } from './graphBuilder';
import { HealthAnalyzer } from './healthAnalyzer';
import { ImpactAnalyzer, ImpactAnalysisResult } from './impactAnalyzer';
import { WorkspaceEventPayload } from '../types';

export class IntelligenceEngine {
  private static instance: IntelligenceEngine | null = null;

  private state: ProjectIntelligenceState;
  private ignoreSystem: IgnoreSystem;
  private symbolIndex: SymbolIndex;
  private parsedAsts: Record<string, ParsedFileAst> = {};
  private rawFiles: Record<string, string> = {};
  private listeners: Set<(state: ProjectIntelligenceState) => void> = new Set();
  private isProcessing = false;

  private constructor() {
    this.ignoreSystem = new IgnoreSystem();
    this.symbolIndex = new SymbolIndex();
    this.state = this.getInitialState();
  }

  public static getInstance(): IntelligenceEngine {
    if (!IntelligenceEngine.instance) {
      IntelligenceEngine.instance = new IntelligenceEngine();
    }
    return IntelligenceEngine.instance;
  }

  private getInitialState(): ProjectIntelligenceState {
    return {
      status: 'IDLE',
      progressPercent: 0,
      statusMessage: 'Intelligence Engine Ready',
      lastIndexedAt: Date.now(),
      metadata: {
        name: 'godex-project',
        version: '1.0.0',
        framework: 'unknown',
        runtime: 'browser',
        primaryLanguage: 'typescript',
        packageManager: 'npm',
        buildTool: 'vite',
        entryPoints: {},
        configFiles: [],
        envKeys: [],
        totalFiles: 0,
        totalLines: 0,
        totalBytes: 0
      },
      files: {},
      folders: {},
      dependencies: {},
      symbolIndex: {},
      graph: {
        nodes: [],
        edges: [],
        adjacency: {},
        reverseAdjacency: {},
        circularDependencies: []
      },
      health: {
        score: 100,
        rating: 'EXCELLENT',
        syntaxValid: true,
        circularDependencyCount: 0,
        brokenImportCount: 0,
        secretLeakCount: 0,
        warningCount: 0,
        totalSymbols: 0,
        totalComponents: 0,
        totalRoutes: 0,
        totalDependencies: 0,
        issues: [],
        metrics: {
          totalFiles: 0,
          totalLines: 0,
          totalBytes: 0,
          componentRatio: 0,
          avgFileSizeLines: 0
        }
      }
    };
  }

  /**
   * Subscribe to live state updates
   */
  public subscribe(listener: (state: ProjectIntelligenceState) => void): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(): void {
    const cloned = { ...this.state };
    for (const listener of this.listeners) {
      try {
        listener(cloned);
      } catch (err) {
        console.error('IntelligenceEngine notification error:', err);
      }
    }
  }

  public getState(): ProjectIntelligenceState {
    return this.state;
  }

  public getSymbolIndex(): SymbolIndex {
    return this.symbolIndex;
  }

  /**
   * Full scan of workspace files
   */
  public async scanProject(files: Record<string, string>): Promise<ProjectIntelligenceState> {
    this.isProcessing = true;
    this.rawFiles = { ...files };

    try {
      // 1. DISCOVERING
      this.updateState({
        status: 'DISCOVERING',
        progressPercent: 15,
        statusMessage: 'Scanning directory hierarchy and ignore rules...'
      });

      // Update ignore system if .gitignore exists
      if (files['.gitignore']) {
        this.ignoreSystem = new IgnoreSystem(files['.gitignore']);
      }

      // Filter non-ignored files
      const validFiles: Record<string, string> = {};
      for (const [path, content] of Object.entries(files)) {
        if (!this.ignoreSystem.shouldIgnore(path)) {
          validFiles[path] = content;
        }
      }

      // Build folder tree
      const folders = this.buildFolderNodes(Object.keys(validFiles));

      // Detect Project Characteristics
      const metadata = ProjectDetector.analyzeProjectMetadata(validFiles);

      // 2. PARSING
      this.updateState({
        status: 'PARSING',
        progressPercent: 40,
        statusMessage: `Parsing AST for ${Object.keys(validFiles).length} project files...`
      });

      this.parsedAsts = {};
      this.symbolIndex.clear();
      const filesState: ProjectIntelligenceState['files'] = {};
      const importedPackagesMap: Record<string, string[]> = {};

      for (const [filePath, content] of Object.entries(validFiles)) {
        const language = ProjectDetector.detectLanguage(filePath);
        const ast = AstParser.parse(filePath, content);
        this.parsedAsts[filePath] = ast;
        this.symbolIndex.updateFileSymbols(filePath, ast.symbols);

        for (const imp of ast.imports) {
          if (imp.isExternal) {
            if (!importedPackagesMap[imp.source]) importedPackagesMap[imp.source] = [];
            if (!importedPackagesMap[imp.source].includes(filePath)) {
              importedPackagesMap[imp.source].push(filePath);
            }
          }
        }

        filesState[filePath] = {
          path: filePath,
          language,
          lines: content.split('\n').length,
          bytes: content.length,
          hash: this.calculateHash(content),
          imports: ast.imports,
          exports: ast.exports,
          symbols: ast.symbols,
          routes: ast.routes,
          envReferences: ast.envReferences,
          isEntry: metadata.entryPoints.browser === filePath || metadata.entryPoints.server === filePath
        };
      }

      // 3. INDEXING
      this.updateState({
        status: 'INDEXING',
        progressPercent: 70,
        statusMessage: 'Constructing symbol index and dependency graph...'
      });

      // Analyze dependencies
      const dependencies = DependencyAnalyzer.analyzeDependencies(
        validFiles['package.json'] || '',
        importedPackagesMap
      );

      // Build Graph
      const graph = GraphBuilder.buildGraph(validFiles, this.parsedAsts);

      // 4. ANALYZING
      this.updateState({
        status: 'ANALYZING',
        progressPercent: 90,
        statusMessage: 'Performing health, circularity, and security audit...'
      });

      const health = HealthAnalyzer.analyzeHealth(validFiles, this.parsedAsts, graph, metadata);

      // 5. READY
      this.state = {
        status: 'READY',
        progressPercent: 100,
        statusMessage: `Project indexed: ${Object.keys(validFiles).length} files, ${health.totalSymbols} symbols, ${graph.nodes.length} nodes.`,
        lastIndexedAt: Date.now(),
        metadata,
        files: filesState,
        folders,
        dependencies,
        symbolIndex: this.symbolIndex.toJSON(),
        graph,
        health
      };

      this.notify();
      return this.state;
    } catch (err: any) {
      console.error('IntelligenceEngine scan error:', err);
      this.updateState({
        status: 'ERROR',
        progressPercent: 100,
        statusMessage: `Indexing failed: ${err.message || 'Unknown error'}`
      });
      return this.state;
    } finally {
      this.isProcessing = false;
    }
  }

  /**
   * Updates an individual file in intelligence state
   */
  public async updateFile(path: string, content: string): Promise<void> {
    await this.handleWorkspaceEvent({
      type: 'workspace:file-modified',
      path,
      content,
      timestamp: Date.now(),
      source: 'ai_tool'
    });
  }

  /**
   * Incremental Indexing for Workspace Events (File Created, Modified, Deleted, Renamed)
   */
  public async handleWorkspaceEvent(event: WorkspaceEventPayload): Promise<void> {
    if (!event.path) return;
    const path = event.path;

    if (this.ignoreSystem.shouldIgnore(path)) {
      return;
    }

    if (event.type === 'workspace:file-deleted') {
      delete this.rawFiles[path];
      delete this.parsedAsts[path];
      delete this.state.files[path];
      this.symbolIndex.removeFile(path);
    } else if (event.type === 'workspace:file-renamed' && event.oldPath) {
      const content = event.content ?? this.rawFiles[event.oldPath] ?? '';
      delete this.rawFiles[event.oldPath];
      delete this.parsedAsts[event.oldPath];
      delete this.state.files[event.oldPath];
      this.symbolIndex.removeFile(event.oldPath);

      this.rawFiles[path] = content;
      const ast = AstParser.parse(path, content);
      this.parsedAsts[path] = ast;
      this.symbolIndex.updateFileSymbols(path, ast.symbols);
    } else if (event.type === 'workspace:file-created' || event.type === 'workspace:file-modified') {
      const content = event.content ?? this.rawFiles[path] ?? '';
      this.rawFiles[path] = content;
      const ast = AstParser.parse(path, content);
      this.parsedAsts[path] = ast;
      this.symbolIndex.updateFileSymbols(path, ast.symbols);

      this.state.files[path] = {
        path,
        language: ProjectDetector.detectLanguage(path),
        lines: content.split('\n').length,
        bytes: content.length,
        hash: this.calculateHash(content),
        imports: ast.imports,
        exports: ast.exports,
        symbols: ast.symbols,
        routes: ast.routes,
        envReferences: ast.envReferences,
        isEntry: this.state.metadata.entryPoints.browser === path || this.state.metadata.entryPoints.server === path
      };
    }

    // Rebuild Graph and Health incrementally
    const metadata = ProjectDetector.analyzeProjectMetadata(this.rawFiles);
    const graph = GraphBuilder.buildGraph(this.rawFiles, this.parsedAsts);
    const health = HealthAnalyzer.analyzeHealth(this.rawFiles, this.parsedAsts, graph, metadata);

    this.state.metadata = metadata;
    this.state.graph = graph;
    this.state.health = health;
    this.state.symbolIndex = this.symbolIndex.toJSON();
    this.state.lastIndexedAt = Date.now();
    this.state.statusMessage = `Incremental index: updated ${path}`;

    this.notify();
  }

  private buildFolderNodes(filePaths: string[]): Record<string, ProjectFolderNode> {
    const folders: Record<string, ProjectFolderNode> = {};

    for (const filePath of filePaths) {
      const parts = filePath.split('/');
      let currentPath = '';

      for (let i = 0; i < parts.length - 1; i++) {
        const folderName = parts[i];
        const prevPath = currentPath;
        currentPath = currentPath ? `${currentPath}/${folderName}` : folderName;

        if (!folders[currentPath]) {
          folders[currentPath] = {
            path: currentPath,
            name: folderName,
            fileCount: 0,
            subfolderCount: 0,
            subfolders: [],
            files: []
          };
        }

        if (prevPath && folders[prevPath] && !folders[prevPath].subfolders.includes(currentPath)) {
          folders[prevPath].subfolders.push(currentPath);
          folders[prevPath].subfolderCount++;
        }
      }

      const parentDir = parts.slice(0, -1).join('/');
      if (parentDir && folders[parentDir]) {
        folders[parentDir].files.push(filePath);
        folders[parentDir].fileCount++;
      }
    }

    return folders;
  }

  private updateState(partial: Partial<ProjectIntelligenceState>): void {
    this.state = { ...this.state, ...partial };
    this.notify();
  }

  private calculateHash(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0;
    }
    return Math.abs(hash).toString(16).padStart(8, '0');
  }

  /**
   * Performs blast radius and downstream dependency impact analysis on a target file or symbol
   */
  public analyzeImpact(targetPath: string, targetSymbolName?: string): ImpactAnalysisResult {
    return ImpactAnalyzer.analyze(targetPath, this.rawFiles, targetSymbolName);
  }
}

export const ProjectIntelligence = IntelligenceEngine.getInstance();
