/**
 * GODEX Phase 1 - Dependency & Package Analyzer
 * Analyzes package.json, maps external packages to internal files, and checks dependency usage.
 */

import { ProjectDependencyInfo } from './types';

export class DependencyAnalyzer {
  public static analyzeDependencies(
    packageJsonContent: string,
    importedPackagesMap: Record<string, string[]> = {}
  ): Record<string, ProjectDependencyInfo> {
    const result: Record<string, ProjectDependencyInfo> = {};

    if (!packageJsonContent) return result;

    try {
      const pkg = JSON.parse(packageJsonContent);

      const prodDeps = pkg.dependencies || {};
      const devDeps = pkg.devDependencies || {};
      const peerDeps = pkg.peerDependencies || {};

      for (const [name, version] of Object.entries(prodDeps)) {
        result[name] = {
          name,
          version: String(version),
          category: 'production',
          isFramework: this.isMajorFrameworkPackage(name),
          importedBy: importedPackagesMap[name] || []
        };
      }

      for (const [name, version] of Object.entries(devDeps)) {
        if (!result[name]) {
          result[name] = {
            name,
            version: String(version),
            category: 'dev',
            isFramework: this.isMajorFrameworkPackage(name),
            importedBy: importedPackagesMap[name] || []
          };
        }
      }

      for (const [name, version] of Object.entries(peerDeps)) {
        if (!result[name]) {
          result[name] = {
            name,
            version: String(version),
            category: 'peer',
            isFramework: this.isMajorFrameworkPackage(name),
            importedBy: importedPackagesMap[name] || []
          };
        }
      }
    } catch (err) {
      console.warn('DependencyAnalyzer parse error:', err);
    }

    return result;
  }

  private static isMajorFrameworkPackage(name: string): boolean {
    const frameworks = [
      'react',
      'react-dom',
      'vue',
      'svelte',
      '@angular/core',
      'next',
      'express',
      'fastify',
      'tailwindcss',
      '@tailwindcss/vite',
      'vite',
      'esbuild',
      'typescript',
      'motion',
      'lucide-react'
    ];
    return frameworks.includes(name) || name.startsWith('@types/');
  }
}
