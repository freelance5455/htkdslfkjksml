/**
 * GODEX Phase 2 - Project Summary Generator
 * Deterministically constructs high-level project summaries and architectural snapshots
 * from Phase 1 intelligence.
 */

import { ProjectIntelligenceState } from './types';
import { ProjectSummary } from './contextTypes';

export class ProjectSummaryGenerator {
  /**
   * Generates a structured ProjectSummary object
   */
  public static generate(intelState: ProjectIntelligenceState): ProjectSummary {
    const meta = intelState.metadata;
    const allPaths = Object.keys(intelState.files);
    const testCount = allPaths.filter(p => p.includes('test') || p.includes('spec')).length;

    // Detect architectural layers present
    const layers = new Set<string>();
    for (const path of allPaths) {
      if (path.includes('components/') || path.includes('views/')) layers.add('UI');
      else if (path.includes('services/')) layers.add('Services');
      else if (path.includes('intelligence/')) layers.add('Intelligence');
      else if (path.includes('core/') || path.includes('types')) layers.add('Core');
      else if (path.includes('routes/') || path.includes('server') || path.includes('api/')) layers.add('Routes');
      else if (path.includes('config') || path.endsWith('.json')) layers.add('Config');
    }

    return {
      name: meta.name || 'GODEX Project',
      framework: meta.framework,
      primaryLanguage: meta.primaryLanguage,
      runtime: meta.runtime,
      entryPoint: meta.entryPoints.browser || meta.entryPoints.server || 'src/App.tsx',
      totalFiles: meta.totalFiles || allPaths.length,
      totalLines: meta.totalLines || 0,
      totalDependencies: Object.keys(intelState.dependencies || {}).length,
      totalTests: testCount,
      healthScore: intelState.health?.score ?? 85,
      healthRating: intelState.health?.rating ?? 'GOOD',
      architectureLayers: Array.from(layers)
    };
  }

  /**
   * Generates a formatted text summary for prompt inclusion
   */
  public static formatMarkdown(summary: ProjectSummary): string {
    return `PROJECT SUMMARY
Framework: ${summary.framework.toUpperCase()} | Language: ${summary.primaryLanguage} | Runtime: ${summary.runtime}
Entry Point: ${summary.entryPoint}
Files: ${summary.totalFiles} | Lines: ${summary.totalLines} | Tests: ${summary.totalTests} | Dependencies: ${summary.totalDependencies}
Health Score: ${summary.healthScore}/100 (${summary.healthRating})
Layers: ${summary.architectureLayers.join(' → ')}`;
  }
}
