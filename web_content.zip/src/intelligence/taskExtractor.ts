/**
 * GODEX Phase 2 - Task Extraction Engine
 * Parses developer requests into formal structured tasks:
 * - goal
 * - requestedAction
 * - entities
 * - targetArea
 * - constraints
 * - expectedOutput
 * - targetFiles
 * - affectedSymbols
 * - errorDetails
 */

import { IntentCategory, TaskExtraction } from './contextTypes';
import { IntentClassifier } from './intentClassifier';

export class TaskExtractor {
  /**
   * Extracts structured task parameters from natural language request
   */
  public static extract(
    userPrompt: string, 
    availableFiles: string[] = [], 
    availableSymbols: string[] = []
  ): TaskExtraction {
    const classification = IntentClassifier.classify(userPrompt);
    const action: IntentCategory = classification.intent;

    // Extract file references mentioned in prompt
    const targetFiles: string[] = [];
    for (const file of availableFiles) {
      const fileName = file.split('/').pop() || '';
      const baseName = fileName.replace(/\.[^/.]+$/, '');
      if (
        userPrompt.includes(file) || 
        (fileName.length > 3 && userPrompt.includes(fileName)) ||
        (baseName.length > 4 && new RegExp(`\\b${baseName}\\b`, 'i').test(userPrompt))
      ) {
        if (!targetFiles.includes(file)) {
          targetFiles.push(file);
        }
      }
    }

    // Extract symbol references mentioned in prompt
    const affectedSymbols: string[] = [];
    for (const sym of availableSymbols) {
      if (sym.length > 3 && new RegExp(`\\b${sym}\\b`).test(userPrompt)) {
        if (!affectedSymbols.includes(sym)) {
          affectedSymbols.push(sym);
        }
      }
    }

    // Extract entity nouns / keywords
    const entityMatches = userPrompt.match(/\b(?:auth|login|token|jwt|user|session|header|sidebar|editor|terminal|preview|database|store|state|theme|modal|button|api|route|graph|health|memory|agent|verification|diff)\w*\b/gi) || [];
    const entities = Array.from(new Set(entityMatches.map(e => e.toLowerCase())));

    // Extract target area
    let targetArea: string | undefined = undefined;
    if (userPrompt.toLowerCase().includes('ui') || userPrompt.toLowerCase().includes('component') || userPrompt.toLowerCase().includes('view')) {
      targetArea = 'UI Layer';
    } else if (userPrompt.toLowerCase().includes('service') || userPrompt.toLowerCase().includes('engine') || userPrompt.toLowerCase().includes('api')) {
      targetArea = 'Services / Core Layer';
    } else if (userPrompt.toLowerCase().includes('route') || userPrompt.toLowerCase().includes('server') || userPrompt.toLowerCase().includes('endpoint')) {
      targetArea = 'API Routes';
    } else if (userPrompt.toLowerCase().includes('test')) {
      targetArea = 'Testing Suite';
    } else if (targetFiles.length > 0) {
      targetArea = targetFiles[0];
    }

    // Extract constraints
    const constraints: string[] = [];
    if (/without\s+(?:changing|modifying|breaking)/i.test(userPrompt) || /preserve\s+(?:behavior|compatibility)/i.test(userPrompt)) {
      constraints.push('Preserve existing interface & behavior');
    }
    if (/no\s+(?:third\s*party|new\s+dependencies|external\s+libraries)/i.test(userPrompt)) {
      constraints.push('Zero new external dependencies');
    }
    if (/clean\s*up|dry|do\s+not\s+repeat/i.test(userPrompt)) {
      constraints.push('Eliminate duplicate / redundant logic');
    }
    if (/type\s*safe|typescript\s*types/i.test(userPrompt)) {
      constraints.push('Strict TypeScript type safety');
    }
    if (/responsive|mobile/i.test(userPrompt)) {
      constraints.push('Mobile-friendly responsive layout');
    }

    // Extract error details if debug intent
    let errorDetails: string | undefined = undefined;
    if (action === 'DEBUG') {
      const errorMatch = userPrompt.match(/(?:error|exception|fails?|cannot read|undefined is not)[\s\S]+/i);
      if (errorMatch) {
        errorDetails = errorMatch[0].trim();
      }
    }

    // Determine goal
    let goal = userPrompt.trim();
    // Clean common prefixes
    goal = goal.replace(/^(?:please|can you|could you|help me|i want to|i need to)\s+/i, '');

    // Determine expected output
    let expectedOutput: string = 'Structured explanation and context breakdown';
    if (action === 'SEARCH') {
      expectedOutput = 'List of matched files, symbols, locations, and references';
    } else if (action === 'DEBUG') {
      expectedOutput = 'Root cause analysis, affected symbols, and diagnostic resolution';
    } else if (action === 'IMPLEMENT') {
      expectedOutput = 'Implementation plan, targeted files, and required architecture contracts';
    } else if (action === 'REFACTOR') {
      expectedOutput = 'Refactoring blueprint, duplicate elimination plan, and preserved interface definitions';
    } else if (action === 'REVIEW') {
      expectedOutput = 'Code quality analysis, health warnings, and best practice recommendations';
    } else if (action === 'ARCHITECTURE') {
      expectedOutput = 'Layer topology, dependency graph flow, coupling analysis, and circular import review';
    } else if (action === 'SECURITY') {
      expectedOutput = 'Security audit, secret exposure scan, and access control review';
    } else if (action === 'TEST') {
      expectedOutput = 'Test strategy, test cases, and assertion requirements';
    }

    return {
      goal,
      requestedAction: action,
      entities,
      targetArea,
      constraints,
      expectedOutput,
      targetFiles: targetFiles.length > 0 ? targetFiles : undefined,
      affectedSymbols: affectedSymbols.length > 0 ? affectedSymbols : undefined,
      errorDetails,
      rawPrompt: userPrompt
    };
  }
}
