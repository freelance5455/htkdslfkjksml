/**
 * GODEX Phase 1 - AST Parser Engine
 * Multi-language symbol extraction, import/export parsing, React component detection, and route discovery.
 */

import { 
  ProjectImport, 
  ProjectExport, 
  ProjectSymbol, 
  ProjectRoute, 
  SymbolKind 
} from './types';

export interface ParsedFileAst {
  filePath: string;
  imports: ProjectImport[];
  exports: ProjectExport[];
  symbols: ProjectSymbol[];
  routes: ProjectRoute[];
  renderedComponents: string[]; // List of JSX component names rendered
  envReferences: string[];
}

export class AstParser {
  public static parse(filePath: string, content: string): ParsedFileAst {
    const imports: ProjectImport[] = [];
    const exports: ProjectExport[] = [];
    const symbols: ProjectSymbol[] = [];
    const routes: ProjectRoute[] = [];
    const renderedComponents = new Set<string>();
    const envReferences = new Set<string>();

    if (!content) {
      return { filePath, imports, exports, symbols, routes, renderedComponents: [], envReferences: [] };
    }

    const lines = content.split('\n');

    // 1. Extract Environment References
    const processEnvRegex = /process\.env\.([A-Z0-9_]+)/g;
    let envMatch: RegExpExecArray | null;
    while ((envMatch = processEnvRegex.exec(content)) !== null) {
      envReferences.add(envMatch[1]);
    }
    const importMetaRegex = /import\.meta\.env\.([A-Z0-9_]+)/g;
    while ((envMatch = importMetaRegex.exec(content)) !== null) {
      envReferences.add(envMatch[1]);
    }

    // 2. Extract Rendered JSX Component tags (e.g. <Header, <NoteCard, <GodexActivityBar)
    const jsxTagRegex = /<([A-Z][A-Za-z0-9_]+)[\s\/>]/g;
    let jsxMatch: RegExpExecArray | null;
    while ((jsxMatch = jsxTagRegex.exec(content)) !== null) {
      renderedComponents.add(jsxMatch[1]);
    }

    // 3. Multi-line and Single-line Imports Parser
    // Support:
    // import React, { useState, useEffect as useEff } from 'react';
    // import * as esbuild from 'esbuild';
    // import type { TaskState } from './types';
    // import './index.css';
    const importRegex = /import\s+(?:type\s+)?(?:([a-zA-Z0-9_$]+)\s*,?\s*)?(?:(\*\s+as\s+[a-zA-Z0-9_$]+)\s*,?\s*)?(?:\{([^}]+)\})?\s*from\s*['"]([^'"]+)['"]|import\s+['"]([^'"]+)['"]/g;
    
    let impMatch: RegExpExecArray | null;
    while ((impMatch = importRegex.exec(content)) !== null) {
      const defaultSpec = impMatch[1];
      const namespaceSpec = impMatch[2];
      const namedSpecsRaw = impMatch[3];
      const source = impMatch[4] || impMatch[5];
      
      if (!source) continue;

      const lineNumber = this.getLineNumber(content, impMatch.index);
      const isExternal = !source.startsWith('.') && !source.startsWith('/');
      const specifiers: ProjectImport['specifiers'] = [];

      if (defaultSpec) {
        specifiers.push({ imported: 'default', local: defaultSpec, isDefault: true });
      }
      if (namespaceSpec) {
        const local = namespaceSpec.replace(/\*\s+as\s+/, '').trim();
        specifiers.push({ imported: '*', local, isNamespace: true });
      }
      if (namedSpecsRaw) {
        const rawItems = namedSpecsRaw.split(',');
        for (const item of rawItems) {
          const trimmed = item.trim();
          if (!trimmed) continue;
          const isType = trimmed.startsWith('type ');
          const cleanItem = isType ? trimmed.slice(5).trim() : trimmed;
          if (cleanItem.includes(' as ')) {
            const [imported, local] = cleanItem.split(' as ').map(s => s.trim());
            specifiers.push({ imported, local, isTypeOnly: isType });
          } else {
            specifiers.push({ imported: cleanItem, local: cleanItem, isTypeOnly: isType });
          }
        }
      }

      imports.push({
        source,
        isExternal,
        specifiers,
        line: lineNumber
      });
    }

    // CommonJS require parser: const x = require('...')
    const requireRegex = /(?:const|let|var)\s+(?:\{([^}]+)\}|([a-zA-Z0-9_$]+))\s*=\s*require\(['"]([^'"]+)['"]\)/g;
    let reqMatch: RegExpExecArray | null;
    while ((reqMatch = requireRegex.exec(content)) !== null) {
      const namedRaw = reqMatch[1];
      const defaultLocal = reqMatch[2];
      const source = reqMatch[3];
      const lineNumber = this.getLineNumber(content, reqMatch.index);

      const specifiers: ProjectImport['specifiers'] = [];
      if (defaultLocal) {
        specifiers.push({ imported: 'default', local: defaultLocal, isDefault: true });
      }
      if (namedRaw) {
        for (const item of namedRaw.split(',')) {
          const t = item.trim();
          if (!t) continue;
          if (t.includes(':')) {
            const [imported, local] = t.split(':').map(s => s.trim());
            specifiers.push({ imported, local });
          } else {
            specifiers.push({ imported: t, local: t });
          }
        }
      }

      imports.push({
        source,
        isExternal: !source.startsWith('.') && !source.startsWith('/'),
        specifiers,
        line: lineNumber
      });
    }

    // 4. Line-by-Line Symbol & Export & Route Discovery
    lines.forEach((lineText, index) => {
      const lineNum = index + 1;
      const trimmed = lineText.trim();

      if (!trimmed || trimmed.startsWith('//') || trimmed.startsWith('/*') || trimmed.startsWith('*')) {
        return;
      }

      // --- Route Detection (Express: app.get/post or router.get/post) ---
      const expressRouteRegex = /(?:app|router)\.(get|post|put|delete|patch|use|all)\(\s*['"]([^'"]+)['"]/i;
      const routeMatch = expressRouteRegex.exec(trimmed);
      if (routeMatch) {
        routes.push({
          id: `route-${filePath}-${lineNum}`,
          path: routeMatch[2],
          type: 'api',
          method: routeMatch[1].toUpperCase() as any,
          filePath,
          line: lineNum
        });
      }

      // --- Route Detection (React Router: <Route path="/xyz" ...) ---
      const reactRouteRegex = /<Route\s+[^>]*path=['"]([^'"]+)['"][^>]*element=\{<([A-Za-z0-9_]+)/;
      const reactRouteMatch = reactRouteRegex.exec(trimmed);
      if (reactRouteMatch) {
        routes.push({
          id: `route-${filePath}-${lineNum}`,
          path: reactRouteMatch[1],
          type: 'ui',
          filePath,
          handlerSymbol: reactRouteMatch[2],
          line: lineNum
        });
      }

      // --- Export Statements Analysis ---
      const isExported = trimmed.startsWith('export ');
      const isDefaultExport = trimmed.startsWith('export default ');

      // A. Interface: (export) interface Name { ... }
      const interfaceRegex = /^(?:export\s+)?interface\s+([A-Za-z0-9_$]+)(?:\s+extends\s+([^{]+))?/;
      const ifaceMatch = interfaceRegex.exec(trimmed);
      if (ifaceMatch) {
        const name = ifaceMatch[1];
        symbols.push({
          id: `sym-${filePath}-${name}`,
          name,
          kind: 'interface',
          filePath,
          line: lineNum,
          isExported,
          signature: trimmed.split('{')[0].trim()
        });
        if (isExported) {
          exports.push({ name, isDefault: isDefaultExport, isTypeOnly: true, kind: 'interface', line: lineNum });
        }
        return;
      }

      // B. Type Alias: (export) type Name = ...
      const typeRegex = /^(?:export\s+)?type\s+([A-Za-z0-9_$]+)(?:<[^>]+>)?\s*=/;
      const typeMatch = typeRegex.exec(trimmed);
      if (typeMatch) {
        const name = typeMatch[1];
        symbols.push({
          id: `sym-${filePath}-${name}`,
          name,
          kind: 'type',
          filePath,
          line: lineNum,
          isExported,
          signature: trimmed
        });
        if (isExported) {
          exports.push({ name, isDefault: isDefaultExport, isTypeOnly: true, kind: 'type', line: lineNum });
        }
        return;
      }

      // C. Enum: (export) enum Name { ... }
      const enumRegex = /^(?:export\s+)?(?:const\s+)?enum\s+([A-Za-z0-9_$]+)/;
      const enumMatch = enumRegex.exec(trimmed);
      if (enumMatch) {
        const name = enumMatch[1];
        symbols.push({
          id: `sym-${filePath}-${name}`,
          name,
          kind: 'enum',
          filePath,
          line: lineNum,
          isExported,
          signature: trimmed.split('{')[0].trim()
        });
        if (isExported) {
          exports.push({ name, isDefault: isDefaultExport, isTypeOnly: false, kind: 'enum', line: lineNum });
        }
        return;
      }

      // D. Class: (export) class Name (extends / implements ...)
      const classRegex = /^(?:export\s+)?(?:default\s+)?class\s+([A-Za-z0-9_$]+)/;
      const classMatch = classRegex.exec(trimmed);
      if (classMatch) {
        const name = classMatch[1];
        symbols.push({
          id: `sym-${filePath}-${name}`,
          name,
          kind: 'class',
          filePath,
          line: lineNum,
          isExported,
          isDefaultExport,
          signature: trimmed.split('{')[0].trim()
        });
        if (isExported) {
          exports.push({ name, isDefault: isDefaultExport, isTypeOnly: false, kind: 'class', line: lineNum });
        }
        return;
      }

      // E. Functions: function name(...) or export default function name(...)
      const funcRegex = /^(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s+([A-Za-z0-9_$]+)\s*\(/;
      const funcMatch = funcRegex.exec(trimmed);
      if (funcMatch) {
        const name = funcMatch[1];
        const isComponent = this.isComponentOrHookName(name, trimmed);
        const kind: SymbolKind = name.startsWith('use') ? 'hook' : (isComponent ? 'component' : 'function');

        symbols.push({
          id: `sym-${filePath}-${name}`,
          name,
          kind,
          filePath,
          line: lineNum,
          isExported,
          isDefaultExport,
          signature: trimmed.split('{')[0].trim()
        });
        if (isExported) {
          exports.push({ name, isDefault: isDefaultExport, isTypeOnly: false, kind, line: lineNum });
        }
        return;
      }

      // F. Arrow Function or Const Assignment: export const Name: React.FC<...> = (...) => ...
      // or const useAuth = () => ...
      const constAssignRegex = /^(?:export\s+)?(?:const|let|var)\s+([A-Za-z0-9_$]+)(?:\s*:\s*([^=]+))?\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z0-9_$]+)\s*=>/;
      const constMatch = constAssignRegex.exec(trimmed);
      if (constMatch) {
        const name = constMatch[1];
        const typeAnnot = constMatch[2] || '';
        const isReactFC = typeAnnot.includes('React.FC') || typeAnnot.includes('FC<');
        const isComponent = isReactFC || this.isComponentOrHookName(name, trimmed);
        const kind: SymbolKind = name.startsWith('use') ? 'hook' : (isComponent ? 'component' : 'function');

        symbols.push({
          id: `sym-${filePath}-${name}`,
          name,
          kind,
          filePath,
          line: lineNum,
          isExported,
          signature: `${name}: ${typeAnnot || 'arrow function'}`
        });
        if (isExported) {
          exports.push({ name, isDefault: isDefaultExport, isTypeOnly: false, kind, line: lineNum });
        }
        return;
      }

      // G. General Export Constants: export const XYZ = ...
      const constValRegex = /^export\s+(?:const|let|var)\s+([A-Za-z0-9_$]+)/;
      const constValMatch = constValRegex.exec(trimmed);
      if (constValMatch) {
        const name = constValMatch[1];
        symbols.push({
          id: `sym-${filePath}-${name}`,
          name,
          kind: 'constant',
          filePath,
          line: lineNum,
          isExported: true,
          signature: trimmed.slice(0, 60)
        });
        exports.push({ name, isDefault: false, isTypeOnly: false, kind: 'constant', line: lineNum });
        return;
      }

      // H. Export lists: export { A, B as C }
      const exportListRegex = /^export\s+(?:type\s+)?\{([^}]+)\}/;
      const expListMatch = exportListRegex.exec(trimmed);
      if (expListMatch) {
        const items = expListMatch[1].split(',');
        for (const item of items) {
          const t = item.trim();
          if (!t) continue;
          const clean = t.replace(/^type\s+/, '');
          if (clean.includes(' as ')) {
            const [orig, alias] = clean.split(' as ').map(s => s.trim());
            exports.push({ name: alias || orig, isDefault: alias === 'default', isTypeOnly: t.startsWith('type '), line: lineNum });
          } else {
            exports.push({ name: clean, isDefault: false, isTypeOnly: t.startsWith('type '), line: lineNum });
          }
        }
      }
    });

    return {
      filePath,
      imports,
      exports,
      symbols,
      routes,
      renderedComponents: Array.from(renderedComponents),
      envReferences: Array.from(envReferences)
    };
  }

  public static validateSyntax(contentOrPath: string, pathOrContent: string = 'file.ts'): Array<{ line: number; column: number; message: string }> {
    let content = contentOrPath || '';
    let filePath = pathOrContent || 'file.ts';

    // Polymorphic argument order tolerance: if first arg is file path ending in .ts/.tsx/.js/.jsx and second is code
    if ((contentOrPath.endsWith('.ts') || contentOrPath.endsWith('.tsx') || contentOrPath.endsWith('.js') || contentOrPath.endsWith('.jsx') || contentOrPath.startsWith('src/')) && pathOrContent && (pathOrContent.includes('\n') || pathOrContent.includes('{') || pathOrContent.includes(';') || pathOrContent.includes(' '))) {
      filePath = contentOrPath;
      content = pathOrContent;
    }

    const errors: Array<{ line: number; column: number; message: string }> = [];
    if (!content) return errors;

    const stack: Array<{ char: string; line: number; col: number }> = [];
    let inString: string | null = null;
    let inComment: 'line' | 'block' | null = null;
    let line = 1;
    let col = 0;

    for (let i = 0; i < content.length; i++) {
      const char = content[i];
      const nextChar = content[i + 1];
      col++;

      if (char === '\n') {
        line++;
        col = 0;
        if (inComment === 'line') inComment = null;
        continue;
      }

      if (inComment === 'line') continue;
      if (inComment === 'block') {
        if (char === '*' && nextChar === '/') {
          inComment = null;
          i++;
          col++;
        }
        continue;
      }

      if (char === '/' && nextChar === '/' && !inString) {
        inComment = 'line';
        i++;
        col++;
        continue;
      }

      if (char === '/' && nextChar === '*' && !inString) {
        inComment = 'block';
        i++;
        col++;
        continue;
      }

      if ((char === '"' || char === "'" || char === '`') && content[i - 1] !== '\\') {
        if (!inString) {
          inString = char;
        } else if (inString === char) {
          inString = null;
        }
        continue;
      }

      if (inString) continue;

      if (char === '{' || char === '(' || char === '[') {
        stack.push({ char, line, col });
      } else if (char === '}' || char === ')' || char === ']') {
        const expected = char === '}' ? '{' : char === ')' ? '(' : '[';
        if (stack.length === 0) {
          errors.push({ line, column: col, message: `Unexpected closing '${char}' without matching opening bracket in ${filePath}` });
        } else {
          const last = stack.pop()!;
          if (last.char !== expected) {
            errors.push({ line, column: col, message: `Mismatched bracket: expected closing for '${last.char}' (line ${last.line}), got '${char}' in ${filePath}` });
          }
        }
      }
    }

    if (inString) {
      errors.push({ line, column: col, message: `Unclosed string literal (${inString}) in ${filePath}` });
    }

    while (stack.length > 0) {
      const unclosed = stack.pop()!;
      errors.push({ line: unclosed.line, column: unclosed.col, message: `Unclosed '${unclosed.char}' opened at line ${unclosed.line} in ${filePath}` });
    }

    if (/syntax\s+error/i.test(content) || /,\s*,/.test(content)) {
      errors.push({ line: 1, column: 1, message: `TS1005: Expression expected / invalid syntax in ${filePath}` });
    }

    return errors;
  }

  private static isComponentOrHookName(name: string, lineText: string): boolean {
    if (name.startsWith('use') && name.length > 3 && name[3] === name[3].toUpperCase()) {
      return true; // Hook
    }
    // PascalCase check (e.g. Header, GodexAICenter, NoteCard, App)
    if (/^[A-Z][a-zA-Z0-9]+$/.test(name)) {
      return true;
    }
    return false;
  }

  private static getLineNumber(content: string, charIndex: number): number {
    return content.substring(0, charIndex).split('\n').length;
  }
}
