/**
 * GODEX Phase 2 - Context Budget Engine & Smart Compressor
 * Enforces token and size limits. Prioritizes high-value context and compresses
 * secondary context cleanly rather than randomly truncating.
 */

import { ContextBudgetConfig, ContextFileItem, ContextSymbolItem } from './contextTypes';

export const DEFAULT_CONTEXT_BUDGET: ContextBudgetConfig = {
  maxFiles: 8,
  maxSymbols: 20,
  maxTokens: 12000,
  maxCharacters: 48000,
  maxGraphDepth: 1
};

export class ContextBudgetEngine {
  /**
   * Fast token estimation (approx ~3.8 characters per token in code/JSON)
   */
  public static estimateTokens(text: string): number {
    return Math.ceil(text.length / 3.8);
  }

  /**
   * Applies budget constraints and smart compression to file items and symbols
   */
  public static applyBudget(
    files: ContextFileItem[],
    symbols: ContextSymbolItem[],
    budget: ContextBudgetConfig = DEFAULT_CONTEXT_BUDGET
  ): {
    compressedFiles: ContextFileItem[];
    compressedSymbols: ContextSymbolItem[];
    totalCharacters: number;
    totalTokens: number;
    budgetUsagePercent: number;
  } {
    // 1. Cap file count
    let candidateFiles = files.slice(0, budget.maxFiles);

    // 2. Cap symbol count
    let candidateSymbols = symbols.slice(0, budget.maxSymbols);

    // 3. Progressive Compression if character count exceeds limit
    let currentTotalChars = candidateFiles.reduce((acc, f) => acc + (f.snippet?.length || 0), 0) +
      candidateSymbols.reduce((acc, s) => acc + (s.codeSnippet?.length || 0), 0);

    // If exceeding character budget, compress secondary files to symbols only
    if (currentTotalChars > budget.maxCharacters) {
      candidateFiles = candidateFiles.map((file, index) => {
        // Keep top 2 files full, compress remainder to signatures
        if (index >= 2 && file.snippet && file.snippet.length > 500) {
          return {
            ...file,
            snippet: `// [Compressed by GODEX Context Engine: Symbols Summary]\n// File: ${file.path} (${file.linesCount} lines)\n// Defined Symbols: ${file.includedSymbols?.join(', ') || 'None'}\n`,
            compressionLevel: 'symbols_only' as const
          };
        }
        return file;
      });

      // Recalculate
      currentTotalChars = candidateFiles.reduce((acc, f) => acc + (f.snippet?.length || 0), 0) +
        candidateSymbols.reduce((acc, s) => acc + (s.codeSnippet?.length || 0), 0);
    }

    // If still exceeding, trim lowest-scoring symbols
    while (currentTotalChars > budget.maxCharacters && candidateSymbols.length > 5) {
      candidateSymbols.pop();
      currentTotalChars = candidateFiles.reduce((acc, f) => acc + (f.snippet?.length || 0), 0) +
        candidateSymbols.reduce((acc, s) => acc + (s.codeSnippet?.length || 0), 0);
    }

    const totalTokens = this.estimateTokens(JSON.stringify({ files: candidateFiles, symbols: candidateSymbols }));
    const budgetUsagePercent = Math.min(100, Math.round((totalTokens / budget.maxTokens) * 100));

    return {
      compressedFiles: candidateFiles,
      compressedSymbols: candidateSymbols,
      totalCharacters: currentTotalChars,
      totalTokens,
      budgetUsagePercent
    };
  }
}
