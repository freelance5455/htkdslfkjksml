/**
 * GODEX UI Intent Compiler
 * Translates abstract user styling requests (e.g. "Make this app premium")
 * into mathematically consistent, anti-slop, accessible UI specifications.
 */

export interface UIIntent {
  id: string;
  rawPrompt: string;
  visualDirection: 'PREMIUM_EDITORIAL' | 'DENSE_ENGINEERING' | 'MINIMAL_SYSTEM' | 'ACCESSIBLE_HIGH_CONTRAST';
  hierarchy: {
    displayHeadlineRatio: number;
    h1ToH3SkipForbidden: boolean;
    contentDensity: 'compact' | 'comfortable' | 'spacious';
  };
  typography: {
    primaryFamily: string;
    headingFamily: string;
    baseSize: string;
    lineHeight: string;
    maxLineLengthCh: number;
  };
  spacingSystem: {
    outerPaddingMin: number;
    buttonHorizontalToVerticalRatio: number; // exactly 2x
    nestedBorderRadiusFormula: string; // Inner = Outer - Padding
  };
  colorSystem: {
    theme: 'light_refined' | 'dark_subtle';
    neutralSaturationMaxPercent: number; // < 5% HSB
    bannedGradients: string[];
    minContrastRatio: number; // 4.5:1 WCAG AA
  };
  componentDensity: 'high' | 'medium' | 'low';
  borderTreatment: {
    maxBorderRadiusPx: number; // 12-16px max
    pillButtonsAllowed: boolean;
    thickAccentWithRoundedCornersForbidden: boolean;
  };
  elevation: {
    shadowType: 'subtle_layered' | 'flat_stroke' | 'none';
    glowingShadowsForbidden: boolean;
  };
  motion: {
    type: 'subtle_fade' | 'micro_spring' | 'none';
    reducedMotionSafe: boolean;
  };
  responsiveRules: {
    mobileBreakpoint: number; // 390px
    tabletBreakpoint: number; // 768px
    desktopBreakpoint: number; // 1280px
    minTouchTargetPx: number; // 44px
  };
  interactionStates: {
    hover: boolean;
    focusVisible: boolean;
    active: boolean;
    disabled: boolean;
  };
  emptyStates: { required: boolean; hintMessage?: string };
  loadingStates: { required: boolean; skeletonOrSpinner: 'skeleton' | 'spinner' };
  errorStates: { required: boolean; retryAction: boolean };
  accessibilityRequirements: {
    wcagLevel: 'AA' | 'AAA';
    colorOnlyInformationForbidden: boolean;
    ariaLabelsRequired: boolean;
  };
  antiSlopBannedPatterns: string[];
}

export class UIIntentCompiler {
  public static compile(prompt: string): UIIntent {
    const pLower = prompt.toLowerCase();
    const isDark = /\b(?:dark|night|dim|black)\b/i.test(pLower);
    const isEditorial = /\b(?:premium|luxury|modern|editorial|magazine|article|blog|journal|book)\b/i.test(pLower);
    const isDense = /\b(?:dashboard|analytics|dense|matrix|terminal|table|grid|complex)\b/i.test(pLower);

    let visualDirection: UIIntent['visualDirection'] = 'PREMIUM_EDITORIAL';
    if (isDense) visualDirection = 'DENSE_ENGINEERING';
    else if (isEditorial) visualDirection = 'PREMIUM_EDITORIAL';
    else if (/\b(?:contrast|accessible|a11y)\b/i.test(pLower)) visualDirection = 'ACCESSIBLE_HIGH_CONTRAST';
    else visualDirection = 'MINIMAL_SYSTEM';

    return {
      id: `ui-intent-${Date.now()}`,
      rawPrompt: prompt,
      visualDirection,
      hierarchy: {
        displayHeadlineRatio: isEditorial ? 1.333 : 1.25,
        h1ToH3SkipForbidden: true,
        contentDensity: isDense ? 'compact' : 'comfortable'
      },
      typography: {
        primaryFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        headingFamily: isEditorial ? '"Playfair Display", Georgia, serif' : 'system-ui, -apple-system, sans-serif',
        baseSize: '16px',
        lineHeight: '1.6',
        maxLineLengthCh: 72
      },
      spacingSystem: {
        outerPaddingMin: 16,
        buttonHorizontalToVerticalRatio: 2,
        nestedBorderRadiusFormula: 'Inner Radius = Outer Radius - Padding'
      },
      colorSystem: {
        theme: isDark ? 'dark_subtle' : 'light_refined',
        neutralSaturationMaxPercent: 5,
        bannedGradients: [
          'bg-gradient-to-r from-purple-500 to-blue-500',
          'bg-gradient-to-tr from-pink-500 to-indigo-500',
          'cyan-on-dark-glow'
        ],
        minContrastRatio: 4.5
      },
      componentDensity: isDense ? 'high' : 'medium',
      borderTreatment: {
        maxBorderRadiusPx: 16,
        pillButtonsAllowed: true,
        thickAccentWithRoundedCornersForbidden: true
      },
      elevation: {
        shadowType: 'subtle_layered',
        glowingShadowsForbidden: true
      },
      motion: {
        type: 'subtle_fade',
        reducedMotionSafe: true
      },
      responsiveRules: {
        mobileBreakpoint: 390,
        tabletBreakpoint: 768,
        desktopBreakpoint: 1280,
        minTouchTargetPx: 44
      },
      interactionStates: {
        hover: true,
        focusVisible: true,
        active: true,
        disabled: true
      },
      emptyStates: {
        required: true,
        hintMessage: 'No items yet. Create your first record.'
      },
      loadingStates: {
        required: true,
        skeletonOrSpinner: 'skeleton'
      },
      errorStates: {
        required: true,
        retryAction: true
      },
      accessibilityRequirements: {
        wcagLevel: 'AA',
        colorOnlyInformationForbidden: true,
        ariaLabelsRequired: true
      },
      antiSlopBannedPatterns: [
        'No purple-to-blue generic gradient text',
        'No glowing cyan drop-shadows on dark cards',
        'No cards inside identical cards without semantic hierarchy',
        'No hero metric blocks with big numbers and tiny unreadable labels',
        'No skipping heading hierarchy (e.g. H1 straight to H3)',
        'No wrapping button labels (text inside button must remain on one line)'
      ]
    };
  }

  /**
   * Audits generated code against UI Intent and Anti-Slop principles.
   */
  public static validateImplementation(code: string, intent: UIIntent): { passed: boolean; violations: string[] } {
    const violations: string[] = [];

    // Check for banned gradients
    if (/from-purple-\d+\s+to-blue-\d+/i.test(code) || /from-pink-\d+\s+to-indigo-\d+/i.test(code)) {
      violations.push('Anti-Slop Violation: Generic purple-to-blue gradient detected.');
    }

    // Check for excessive border radii on cards
    if (/rounded-3xl|rounded-\[3\dpx\]/i.test(code) && !/rounded-full/i.test(code)) {
      violations.push('Design Rule Violation: Excessive border radius on card container (capped at 16px).');
    }

    // Check for glowing shadows in dark mode
    if (/shadow-\[0_0_\d+px/i.test(code) || /shadow-cyan/i.test(code) || /shadow-purple/i.test(code)) {
      violations.push('Anti-Slop Violation: Glowing color drop-shadows detected.');
    }

    return {
      passed: violations.length === 0,
      violations
    };
  }
}
