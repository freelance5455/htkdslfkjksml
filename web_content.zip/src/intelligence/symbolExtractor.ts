/**
 * GODEX Phase 2 - Symbol-Aware Context Extractor
 * Instead of embedding entire 500+ line files, extracts targeted symbol definitions,
 * exact signatures, surrounding code blocks, callers, dependencies, and docstrings.
 */

import { ProjectSymbol } from './types';
import { ContextSymbolItem } from './contextTypes';

export class SymbolExtractor {
  /**
   * Extracts a structured ContextSymbolItem with sliced code block
   */
  public static extractSymbolContext(
    symbol: ProjectSymbol,
    fileContent: string,
    relevanceScore: number,
    reason: string,
    callers: string[] = []
  ): ContextSymbolItem {
    const lines = fileContent.split('\n');
    const startLine = Math.max(1, symbol.line - 1);
    const endLine = symbol.endLine ? Math.min(lines.length, symbol.endLine + 1) : Math.min(lines.length, symbol.line + 25);
    
    // Slice code around symbol
    const codeSlice = lines.slice(startLine - 1, endLine).join('\n');

    return {
      id: symbol.id,
      name: symbol.name,
      kind: symbol.kind,
      filePath: symbol.filePath,
      line: symbol.line,
      endLine: symbol.endLine,
      relevanceScore,
      reason,
      signature: symbol.signature || `${symbol.kind} ${symbol.name}`,
      docstring: symbol.docstring,
      isExported: symbol.isExported,
      callers: callers.length > 0 ? callers : undefined,
      dependencies: symbol.dependencies,
      codeSnippet: codeSlice
    };
  }

  /**
   * Generate lightweight symbol summary header for a file
   */
  public static summarizeSymbolsInFile(symbols: ProjectSymbol[]): string {
    if (symbols.length === 0) return 'No declared symbols.';
    return symbols
      .map(s => `  • ${s.kind} ${s.name}${s.signature ? `: ${s.signature}` : ''} (line ${s.line})`)
      .join('\n');
  }
}
