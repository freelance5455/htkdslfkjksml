/**
 * GODEX Phase 2 - Model Routing Foundation
 * Interfaces and criteria for selecting AI models based on intent,
 * context budget size, complexity, and latency requirements.
 */

import { IntentCategory, TaskExtraction } from './contextTypes';

export interface ModelRouteDecision {
  selectedModel: string;
  reason: string;
  estimatedComplexity: 'low' | 'medium' | 'high';
  temperature: number;
  recommendedTokens: number;
}

export class ModelRouter {
  /**
   * Routes a request to the appropriate model configuration
   */
  public static route(
    intent: IntentCategory,
    task: TaskExtraction,
    contextTokensEstimate: number,
    configuredModel?: string
  ): ModelRouteDecision {
    if (configuredModel) {
      return {
        selectedModel: configuredModel,
        reason: 'User explicitly configured model',
        estimatedComplexity: 'medium',
        temperature: intent === 'SEARCH' || intent === 'DEBUG' ? 0.1 : 0.4,
        recommendedTokens: 4096
      };
    }

    // High complexity tasks: Advanced reasoning, deep refactoring, complex architecture
    if (intent === 'ARCHITECTURE' || intent === 'SECURITY' || intent === 'REFACTOR') {
      return {
        selectedModel: 'local-ast-reasoner',
        reason: `High complexity task category: ${intent} (Local AST Analysis Engine)`,
        estimatedComplexity: 'high',
        temperature: 0.2,
        recommendedTokens: 8192
      };
    }

    // Large context size tasks
    if (contextTokensEstimate > 8000) {
      return {
        selectedModel: 'local-grounded-model',
        reason: `Large context window required (${contextTokensEstimate} estimated tokens)`,
        estimatedComplexity: 'medium',
        temperature: 0.2,
        recommendedTokens: 4096
      };
    }

    // Default fast coding & analysis model
    return {
      selectedModel: 'local-deterministic-engine',
      reason: 'Optimal balance of latency, precision, and deterministic AST grounding',
      estimatedComplexity: 'low',
      temperature: 0.3,
      recommendedTokens: 4096
    };
  }
}
