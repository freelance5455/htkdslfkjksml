/**
 * GODEX Phase 2 - Conversation Memory & Continuity Manager
 * Tracks short-term conversational context, entity mentions, and resolves
 * anaphoric references across multi-turn developer dialogues.
 */

import { 
  ConversationContinuityState, 
  TaskExtraction, 
  IntentCategory, 
  ContextPack 
} from './contextTypes';

export class ConversationContinuityManager {
  private static instance: ConversationContinuityManager;
  private state: ConversationContinuityState;

  private constructor() {
    this.state = this.createEmptyState();
  }

  public static getInstance(): ConversationContinuityManager {
    if (!this.instance) {
      this.instance = new ConversationContinuityManager();
    }
    return this.instance;
  }

  private createEmptyState(): ConversationContinuityState {
    return {
      sessionId: 'session-' + Date.now().toString(36),
      referencedFiles: [],
      referencedSymbols: [],
      conversationEntities: [],
      turnCount: 0,
      lastUpdated: Date.now()
    };
  }

  public getState(): ConversationContinuityState {
    return { ...this.state };
  }

  public reset(): void {
    this.state = this.createEmptyState();
  }

  /**
   * Resolves anaphoric expressions (e.g. "that file", "the previous function", "this service")
   * using short-term conversation state.
   */
  public resolvePrompt(prompt: string): { resolvedPrompt: string; injectedFiles: string[]; injectedSymbols: string[] } {
    let resolved = prompt;
    const injectedFiles: string[] = [];
    const injectedSymbols: string[] = [];

    const lower = prompt.toLowerCase();

    // 1. Resolve "that file" / "the file" / "this file"
    if (/\b(?:that|this|the)\s+file\b/i.test(prompt) && this.state.referencedFiles.length > 0) {
      const lastFile = this.state.referencedFiles[0];
      resolved = resolved.replace(/\b(?:that|this|the)\s+file\b/gi, `file "${lastFile}"`);
      injectedFiles.push(lastFile);
    }

    // 2. Resolve "the previous function" / "that function" / "this function"
    if (/\b(?:that|the\s+previous|this)\s+(?:function|method|symbol)\b/i.test(prompt) && this.state.referencedSymbols.length > 0) {
      const lastSym = this.state.referencedSymbols[0];
      resolved = resolved.replace(/\b(?:that|the\s+previous|this)\s+(?:function|method|symbol)\b/gi, `function "${lastSym}"`);
      injectedSymbols.push(lastSym);
    }

    // 3. Resolve "this service" / "the service"
    if (/\b(?:that|this|the)\s+service\b/i.test(prompt)) {
      const serviceFile = this.state.referencedFiles.find(f => f.includes('service') || f.includes('engine'));
      if (serviceFile) {
        resolved = resolved.replace(/\b(?:that|this|the)\s+service\b/gi, `service in "${serviceFile}"`);
        injectedFiles.push(serviceFile);
      }
    }

    // 4. Resolve "now show me the tests" / "show tests"
    if (/\b(?:show|run|see|where\s+are)\s+(?:the\s+)?tests?\b/i.test(lower) && this.state.referencedFiles.length > 0) {
      const target = this.state.referencedFiles[0];
      resolved = `${resolved} for ${target}`;
    }

    return {
      resolvedPrompt: resolved,
      injectedFiles,
      injectedSymbols
    };
  }

  /**
   * Updates state after a turn is executed
   */
  public recordTurn(
    prompt: string,
    intent: IntentCategory,
    task: TaskExtraction,
    pack: ContextPack
  ): void {
    const newFiles = [...pack.relevantFiles.map(f => f.path), ...(task.targetFiles || [])];
    const newSymbols = [...pack.relevantSymbols.map(s => s.name), ...(task.affectedSymbols || [])];

    // Maintain unique list with most recent first
    const updatedFiles = Array.from(new Set([...newFiles, ...this.state.referencedFiles])).slice(0, 10);
    const updatedSymbols = Array.from(new Set([...newSymbols, ...this.state.referencedSymbols])).slice(0, 15);
    const updatedEntities = Array.from(new Set([...task.entities, ...this.state.conversationEntities])).slice(0, 15);

    this.state = {
      ...this.state,
      currentTask: task,
      previousIntent: intent,
      referencedFiles: updatedFiles,
      referencedSymbols: updatedSymbols,
      conversationEntities: updatedEntities,
      activeProjectArea: task.targetArea || this.state.activeProjectArea,
      turnCount: this.state.turnCount + 1,
      lastUpdated: Date.now()
    };
  }
}

export const ConversationMemory = ConversationContinuityManager.getInstance();
