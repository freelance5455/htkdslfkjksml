/**
 * GODEX Reality Gap Detector
 * Audits all agent plans, mutations, runtime outputs, and generated claims
 * against concrete physical workspace and runtime evidence.
 */

import { computeLineDiff } from '../services/diffEngine';

export type TruthStatus =
  | 'TRUTHFUL'
  | 'PARTIALLY_VERIFIED'
  | 'CONTRADICTED'
  | 'NOT_VERIFIED'
  | 'FABRICATED_CLAIM';

export interface DiscrepancyItem {
  category:
    | 'CLAIM_CONTRADICTION'
    | 'FABRICATED_DIFF_CLAIM'
    | 'FALSE_RUNTIME_PASS'
    | 'MISSING_EVIDENCE'
    | 'UNSUPPORTED_VERIFICATION'
    | 'MUTATION_LEAK';
  claim: string;
  reality: string;
  severity: 'critical' | 'warning' | 'info';
  correction: string;
}

export interface RealityAuditInput {
  userRequest: string;
  classifiedIntent: string;
  plannedActions?: string[];
  filesBefore: Record<string, string>;
  filesAfter: Record<string, string>;
  runtimeErrors?: string[];
  buildPassed?: boolean;
  testPassedCount?: number;
  testTotalCount?: number;
  proposedClaims?: string[];
}

export interface RealityRecord {
  id: string;
  timestamp: number;
  request: string;
  classifiedIntent: string;
  plannedActions: string[];
  actualFileChanges: {
    created: string[];
    modified: string[];
    deleted: string[];
    totalCount: number;
  };
  actualDiff: {
    additions: number;
    deletions: number;
    hasChanges: boolean;
    fileDiffs: Array<{ filePath: string; additions: number; deletions: number }>;
  };
  runtimeResults: {
    buildSuccess: boolean;
    uncaughtErrors: string[];
    hasCrashes: boolean;
  };
  verificationEvidence: {
    passedChecks: number;
    totalChecks: number;
    isFullyVerified: boolean;
  };
  finalClaims: string[];
  discrepancies: DiscrepancyItem[];
  truthStatus: TruthStatus;
  correctedSummary: string;
}

export class RealityGapDetector {
  public static audit(input: RealityAuditInput): RealityRecord {
    const {
      userRequest,
      classifiedIntent,
      plannedActions = [],
      filesBefore = {},
      filesAfter = {},
      runtimeErrors = [],
      buildPassed = true,
      testPassedCount = 0,
      testTotalCount = 0,
      proposedClaims = []
    } = input;

    const discrepancies: DiscrepancyItem[] = [];

    // 1. Calculate Actual Filesystem Mutations
    const pathsBefore = Object.keys(filesBefore);
    const pathsAfter = Object.keys(filesAfter);

    const created: string[] = [];
    const modified: string[] = [];
    const deleted: string[] = [];
    let additions = 0;
    let deletions = 0;
    const fileDiffs: Array<{ filePath: string; additions: number; deletions: number }> = [];

    pathsAfter.forEach(p => {
      if (!pathsBefore.includes(p)) {
        created.push(p);
        const diff = computeLineDiff('', filesAfter[p] || '', p);
        additions += diff.additions;
        deletions += diff.deletions;
        fileDiffs.push({ filePath: p, additions: diff.additions, deletions: diff.deletions });
      } else if (filesBefore[p] !== filesAfter[p]) {
        modified.push(p);
        const diff = computeLineDiff(filesBefore[p] || '', filesAfter[p] || '', p);
        additions += diff.additions;
        deletions += diff.deletions;
        fileDiffs.push({ filePath: p, additions: diff.additions, deletions: diff.deletions });
      }
    });

    pathsBefore.forEach(p => {
      if (!pathsAfter.includes(p)) {
        deleted.push(p);
        const diff = computeLineDiff(filesBefore[p] || '', '', p);
        additions += diff.additions;
        deletions += diff.deletions;
        fileDiffs.push({ filePath: p, additions: diff.additions, deletions: diff.deletions });
      }
    });

    const totalMutatedFiles = created.length + modified.length + deleted.length;
    const hasChanges = totalMutatedFiles > 0;

    // 2. Audit Proposed Claims against Physical Reality
    const joinedClaims = proposedClaims.join(' ');

    // Check for Claim Contradiction (e.g. claiming component creation when 0 files changed)
    if (!hasChanges && (
      /generated|created|implemented|modified|patched|rewrote/i.test(joinedClaims) ||
      /\b\+[1-9][0-9]*\/-\b/i.test(joinedClaims)
    )) {
      discrepancies.push({
        category: 'CLAIM_CONTRADICTION',
        claim: 'Claimed code modification or component generation.',
        reality: 'Actual workspace experienced 0 file mutations (+0/-0).',
        severity: 'critical',
        correction: 'Update summary to state that workspace was inspected/verified with 0 mutations required.'
      });
    }

    // Check for Fabricated Diff Claims (e.g. +47/-422 when diff is different)
    const diffMatch = joinedClaims.match(/\+(\d+)\/-(\d+)/);
    if (diffMatch) {
      const claimedAdd = parseInt(diffMatch[1], 10);
      const claimedDel = parseInt(diffMatch[2], 10);
      if (claimedAdd !== additions || claimedDel !== deletions) {
        discrepancies.push({
          category: 'FABRICATED_DIFF_CLAIM',
          claim: `Claimed diff +${claimedAdd}/-${claimedDel}`,
          reality: `Actual diff calculated from filesystem: +${additions}/-${deletions}`,
          severity: 'critical',
          correction: `Use exact filesystem diff +${additions}/-${deletions}`
        });
      }
    }

    // Check for False Runtime Pass
    if (runtimeErrors.length > 0 && /preview passed|0 errors|runtime clean/i.test(joinedClaims)) {
      discrepancies.push({
        category: 'FALSE_RUNTIME_PASS',
        claim: 'Claimed clean preview/runtime execution.',
        reality: `Runtime threw ${runtimeErrors.length} uncaught error(s): ${runtimeErrors[0]}`,
        severity: 'critical',
        correction: `Acknowledge runtime error: ${runtimeErrors[0]}`
      });
    }

    // Check for Unsupported Verification Claims
    if (testTotalCount === 0 && /passed all tests|certified by 6-pillar/i.test(joinedClaims)) {
      discrepancies.push({
        category: 'UNSUPPORTED_VERIFICATION',
        claim: 'Claimed tests passed.',
        reality: '0 test cases were executed in this operation.',
        severity: 'warning',
        correction: 'State that static inspection occurred without executing dynamic test assertions.'
      });
    }

    // 3. Determine Truth Status
    let truthStatus: TruthStatus = 'TRUTHFUL';
    if (discrepancies.some(d => d.category === 'FABRICATED_DIFF_CLAIM' || d.category === 'CLAIM_CONTRADICTION')) {
      truthStatus = 'FABRICATED_CLAIM';
    } else if (discrepancies.some(d => d.category === 'FALSE_RUNTIME_PASS')) {
      truthStatus = 'CONTRADICTED';
    } else if (discrepancies.length > 0) {
      truthStatus = 'PARTIALLY_VERIFIED';
    } else if (!hasChanges && totalMutatedFiles === 0) {
      truthStatus = 'TRUTHFUL';
    }

    // 4. Synthesize Fact-Grounded Summary
    let correctedSummary = '';
    if (hasChanges) {
      correctedSummary = `Completed objective: "${userRequest}". Modified ${totalMutatedFiles} file(s) (+${additions}/-${deletions} lines), verified AST integrity (${testPassedCount}/${testTotalCount || 1} passed checks).`;
    } else {
      correctedSummary = `Completed objective: "${userRequest}". Verified workspace AST integrity (0 file changes needed, +0/-0), validated ${testPassedCount}/${testTotalCount || 1} checks.`;
    }

    return {
      id: `reality-${Date.now()}`,
      timestamp: Date.now(),
      request: userRequest,
      classifiedIntent,
      plannedActions,
      actualFileChanges: {
        created,
        modified,
        deleted,
        totalCount: totalMutatedFiles
      },
      actualDiff: {
        additions,
        deletions,
        hasChanges,
        fileDiffs
      },
      runtimeResults: {
        buildSuccess: buildPassed,
        uncaughtErrors: runtimeErrors,
        hasCrashes: runtimeErrors.length > 0
      },
      verificationEvidence: {
        passedChecks: testPassedCount,
        totalChecks: testTotalCount,
        isFullyVerified: testTotalCount > 0 && testPassedCount === testTotalCount && buildPassed && runtimeErrors.length === 0
      },
      finalClaims: proposedClaims,
      discrepancies,
      truthStatus,
      correctedSummary
    };
  }
}
