/**
 * GODEX Phase 1 - Project Intelligence Engine Types
 * Core data contracts for Project Scan, Index, AST Analysis, Graph Modeling, and Context Querying.
 */

export type IndexingStatus = 'IDLE' | 'DISCOVERING' | 'PARSING' | 'INDEXING' | 'ANALYZING' | 'READY' | 'ERROR';

export type DetectedFramework = 
  | 'react' 
  | 'next' 
  | 'vue' 
  | 'svelte' 
  | 'angular' 
  | 'express' 
  | 'fastify' 
  | 'nest' 
  | 'vanilla' 
  | 'unknown';

export type DetectedLanguage = 
  | 'typescript' 
  | 'javascript' 
  | 'html' 
  | 'css' 
  | 'json' 
  | 'python' 
  | 'markdown' 
  | 'shell' 
  | 'unknown';

export type DetectedRuntime = 'browser' | 'node' | 'fullstack' | 'termux' | 'unknown';
export type DetectedPackageManager = 'npm' | 'pnpm' | 'yarn' | 'bun';
export type DetectedBuildTool = 'vite' | 'esbuild' | 'webpack' | 'rollup' | 'tsc' | 'none';

export type SymbolKind = 
  | 'component' 
  | 'hook' 
  | 'function' 
  | 'class' 
  | 'interface' 
  | 'type' 
  | 'enum' 
  | 'variable' 
  | 'constant' 
  | 'route';

export type DependencyRelationType = 
  | 'IMPORTS' 
  | 'EXPORTS' 
  | 'RENDERS' 
  | 'USES' 
  | 'EXTENDS' 
  | 'IMPLEMENTS' 
  | 'CALLS';

export interface ProjectImport {
  source: string; // e.g. 'react', './types', '../components/Header'
  isExternal: boolean;
  specifiers: Array<{
    imported: string;
    local: string;
    isTypeOnly?: boolean;
    isDefault?: boolean;
    isNamespace?: boolean;
  }>;
  resolvedPath?: string;
  line: number;
}

export interface ProjectExport {
  name: string;
  isDefault: boolean;
  isTypeOnly: boolean;
  kind?: SymbolKind;
  line: number;
}

export interface ProjectSymbol {
  id: string;
  name: string;
  kind: SymbolKind;
  filePath: string;
  line: number;
  endLine?: number;
  isExported: boolean;
  isDefaultExport?: boolean;
  signature?: string;
  docstring?: string;
  dependencies?: string[]; // identifiers referenced
  props?: string[];
  returnType?: string;
}

export interface ProjectRoute {
  id: string;
  path: string; // e.g. '/dashboard', '/api/verify'
  type: 'ui' | 'api';
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'ALL';
  filePath: string;
  handlerSymbol?: string;
  line: number;
}

export interface ProjectDependencyInfo {
  name: string;
  version: string;
  category: 'production' | 'dev' | 'peer';
  isFramework?: boolean;
  description?: string;
  importedBy: string[]; // file paths
}

export interface ProjectFolderNode {
  path: string;
  name: string;
  fileCount: number;
  subfolderCount: number;
  subfolders: string[];
  files: string[];
}

export interface ProjectMetadata {
  name: string;
  version: string;
  description?: string;
  framework: DetectedFramework;
  runtime: DetectedRuntime;
  primaryLanguage: DetectedLanguage;
  packageManager: DetectedPackageManager;
  buildTool: DetectedBuildTool;
  entryPoints: {
    browser?: string;
    server?: string;
    html?: string;
    styles?: string;
  };
  configFiles: string[];
  envKeys: string[];
  totalFiles: number;
  totalLines: number;
  totalBytes: number;
}

export interface GraphNode {
  id: string; // file path or external package name
  name: string;
  type: 'file' | 'external_package' | 'entry_point' | 'route';
  filePath?: string;
  layer: 'ui' | 'services' | 'core' | 'config' | 'routes' | 'external';
  symbolsCount: number;
  lines: number;
  bytes: number;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  type: DependencyRelationType;
  label?: string;
}

export interface ProjectGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
  adjacency: Record<string, string[]>; // source -> targets
  reverseAdjacency: Record<string, string[]>; // target -> sources
  circularDependencies: string[][]; // list of cycles
}

export interface ProjectHealthIssue {
  id: string;
  severity: 'error' | 'warning' | 'info';
  category: 'syntax' | 'import' | 'circular' | 'security' | 'dead_code' | 'structure';
  title: string;
  message: string;
  filePath?: string;
  line?: number;
  suggestion?: string;
}

export interface ProjectHealthSnapshot {
  score: number; // 0 - 100
  rating: 'EXCELLENT' | 'GOOD' | 'FAIR' | 'POOR';
  syntaxValid: boolean;
  circularDependencyCount: number;
  brokenImportCount: number;
  secretLeakCount: number;
  warningCount: number;
  totalSymbols: number;
  totalComponents: number;
  totalRoutes: number;
  totalDependencies: number;
  issues: ProjectHealthIssue[];
  metrics: {
    totalFiles: number;
    totalLines: number;
    totalBytes: number;
    componentRatio: number; // components per file
    avgFileSizeLines: number;
  };
}

export interface ProjectIntelligenceState {
  status: IndexingStatus;
  progressPercent: number;
  statusMessage: string;
  lastIndexedAt: number;
  metadata: ProjectMetadata;
  files: Record<string, {
    path: string;
    language: DetectedLanguage;
    lines: number;
    bytes: number;
    hash: string;
    imports: ProjectImport[];
    exports: ProjectExport[];
    symbols: ProjectSymbol[];
    routes: ProjectRoute[];
    envReferences: string[];
    isEntry: boolean;
  }>;
  folders: Record<string, ProjectFolderNode>;
  dependencies: Record<string, ProjectDependencyInfo>;
  symbolIndex: Record<string, ProjectSymbol[]>; // symbolName -> symbols
  graph: ProjectGraph;
  health: ProjectHealthSnapshot;
}
