/**
 * GODEX Phase 1 - Extensible Ignore System
 * Respects .gitignore, default ignore sets (node_modules, build artifacts, lockfiles, hidden directories)
 */

export class IgnoreSystem {
  private customPatterns: string[] = [];

  private static DEFAULT_IGNORED_DIRS = new Set([
    'node_modules',
    '.git',
    '.svn',
    '.hg',
    'dist',
    'build',
    'out',
    '.next',
    '.nuxt',
    '.output',
    'coverage',
    '.turbo',
    '.cache',
    'tmp',
    'temp'
  ]);

  private static DEFAULT_IGNORED_FILES = new Set([
    '.DS_Store',
    'Thumbs.db',
    'package-lock.json',
    'yarn.lock',
    'pnpm-lock.yaml',
    'bun.lockb',
    'bun.lock',
    '.env.local'
  ]);

  constructor(gitignoreContent?: string) {
    if (gitignoreContent) {
      this.parseGitignore(gitignoreContent);
    }
  }

  public parseGitignore(content: string): void {
    const lines = content.split('\n');
    for (let line of lines) {
      line = line.trim();
      if (!line || line.startsWith('#')) continue;
      this.customPatterns.push(line);
    }
  }

  public shouldIgnore(filePath: string): boolean {
    const normalized = filePath.replace(/\\/g, '/').replace(/^\.\//, '');
    const parts = normalized.split('/');

    // Check directory exclusions
    for (let i = 0; i < parts.length - 1; i++) {
      if (IgnoreSystem.DEFAULT_IGNORED_DIRS.has(parts[i])) {
        return true;
      }
    }

    const fileName = parts[parts.length - 1];
    if (IgnoreSystem.DEFAULT_IGNORED_FILES.has(fileName)) {
      return true;
    }

    // Check custom patterns from gitignore
    for (const pattern of this.customPatterns) {
      if (this.matchesPattern(normalized, pattern)) {
        return true;
      }
    }

    return false;
  }

  public isIgnoredFolder(folderPath: string): boolean {
    const normalized = folderPath.replace(/\\/g, '/').replace(/^\.\//, '').replace(/\/$/, '');
    const folderName = normalized.split('/').pop() || '';
    if (IgnoreSystem.DEFAULT_IGNORED_DIRS.has(folderName)) return true;

    for (const pattern of this.customPatterns) {
      const cleanPattern = pattern.replace(/\/$/, '');
      if (normalized === cleanPattern || normalized.endsWith('/' + cleanPattern)) {
        return true;
      }
    }

    return false;
  }

  private matchesPattern(path: string, pattern: string): boolean {
    const cleanPattern = pattern.replace(/^\//, '').replace(/\/$/, '');
    if (cleanPattern === '') return false;

    // Direct match or wildcard extension
    if (cleanPattern.startsWith('*.')) {
      const ext = cleanPattern.slice(1);
      return path.endsWith(ext);
    }

    if (path === cleanPattern || path.startsWith(cleanPattern + '/') || path.includes('/' + cleanPattern + '/')) {
      return true;
    }

    return false;
  }
}
