/**
 * GODEX Reality-First Engineering Intelligence Simulation Test Matrix
 * Verifies Mutation Firewall, Reality Gap Detector, Project Digital Twin,
 * Counterfactual Engineer, UI Intent Compiler, Symbol Intelligence, and Preview Isolation.
 */

import { MutationFirewall } from '../services/mutationFirewall';
import { RealityGapDetector } from './realityGapDetector';
import { ProjectDigitalTwin } from './digitalTwin';
import { CounterfactualEngineer } from './counterfactualEngineer';
import { UIIntentCompiler } from './uiIntentCompiler';
import { SymbolIndex } from './symbolIndex';
import { SoftwareEvolutionEngine } from './softwareEvolutionEngine';
import { EngineeringOracle } from './engineeringOracle';

export interface RealityTestResult {
  suiteName: string;
  passed: boolean;
  testsRun: number;
  testsPassed: number;
  testsFailed: number;
  details: Array<{ name: string; passed: boolean; message: string }>;
}

export class SimulationRealityTestRunner {
  public static runAll(): RealityTestResult {
    const details: Array<{ name: string; passed: boolean; message: string }> = [];
    let testsRun = 0;
    let testsPassed = 0;
    let testsFailed = 0;

    const record = (name: string, passed: boolean, message: string) => {
      testsRun++;
      if (passed) testsPassed++;
      else testsFailed++;
      details.push({ name, passed, message });
    };

    const mockWorkspace: Record<string, string> = {
      'src/App.tsx': `import React, { useState } from 'react';
import { Header } from './components/Header';
import { TaskGraph } from './orchestration/orchestrationTypes';

export default function App() {
  const [count, setCount] = useState(0);
  return (
    <div className="p-4">
      <Header title="My App" />
      <button onClick={() => setCount(c => c + 1)}>Count: {count}</button>
    </div>
  );
}`,
      'src/components/Header.tsx': `import React from 'react';
export interface HeaderProps { title: string; }
export function Header({ title }: HeaderProps) {
  return <h1 className="text-xl font-bold">{title}</h1>;
}`,
      'src/orchestration/taskScheduler.ts': `import { TaskGraph } from './orchestrationTypes';
export class TaskScheduler {
  public run(graph: TaskGraph) { return true; }
}`,
      'src/orchestration/orchestrationTypes.ts': `export interface TaskGraph { nodes: Record<string, any>; }`
    };

    // =========================================================================
    // 1. MUTATION FIREWALL TESTS
    // =========================================================================
    try {
      const firewall = MutationFirewall.getInstance();

      // Test 1.1: Read-only query classification
      const decision1 = firewall.evaluateRequest('Inspect the generated app. Do not modify anything.');
      const test1_1 = decision1.mode === 'READ_ONLY' && !decision1.isMutationPermitted;
      record('Mutation Firewall: Read-only guard classification', test1_1, `Mode: ${decision1.mode}`);

      // Test 1.2: Tool permission assertion blocking write tool
      const checkWrite = firewall.assertPermission('write_file', decision1);
      const test1_2 = !checkWrite.allowed && checkWrite.isMutationBlocked === true;
      record('Mutation Firewall: Blocks write_file under READ_ONLY', test1_2, checkWrite.reason);

      // Test 1.3: Tool permission assertion blocking checkpoint creation
      const checkCheckpoint = firewall.assertPermission('create_checkpoint', decision1);
      const test1_3 = !checkCheckpoint.allowed;
      record('Mutation Firewall: Blocks checkpoint creation under READ_ONLY', test1_3, checkCheckpoint.reason);

      // Test 1.4: Permitting write tool when explicit mutation requested
      const decision2 = firewall.evaluateRequest('Refactor the App component to add a dark theme.');
      const checkModify = firewall.assertPermission('write_file', decision2);
      const test1_4 = decision2.isMutationPermitted && checkModify.allowed;
      record('Mutation Firewall: Permits write_file under MODIFY mode', test1_4, checkModify.reason);

      // Test 1.5: Oracle queries cannot mutate workspace
      const oracleDecision = firewall.evaluateRequest('What is becoming risky?', 'READ_ONLY_ENGINEERING_QUERY');
      const oracleWriteCheck = firewall.assertPermission('writeFile', oracleDecision);
      const test1_5 = !oracleWriteCheck.allowed;
      record('Mutation Firewall: Oracle queries strictly blocked from mutating workspace', test1_5, 'Zero mutations permitted');
    } catch (err: any) {
      record('Mutation Firewall Suite', false, `Crash: ${err.message}`);
    }

    // =========================================================================
    // 2. REALITY GAP DETECTOR TESTS
    // =========================================================================
    try {
      // Test 2.1: Truthful mutation
      const reality1 = RealityGapDetector.audit({
        userRequest: 'Add Header component',
        classifiedIntent: 'MUTATION',
        filesBefore: { 'src/App.tsx': 'hello' },
        filesAfter: { 'src/App.tsx': 'hello', 'src/components/Header.tsx': 'export const Header = () => null;' },
        buildPassed: true,
        testPassedCount: 2,
        testTotalCount: 2
      });
      const test2_1 = reality1.truthStatus === 'TRUTHFUL' && reality1.actualFileChanges.created.length === 1;
      record('Reality Gap Detector: Truthful mutation verification', test2_1, `Truth: ${reality1.truthStatus}`);

      // Test 2.2: Zero-file mutation contradiction catch
      const reality2 = RealityGapDetector.audit({
        userRequest: 'Check codebase health',
        classifiedIntent: 'INSPECTION',
        filesBefore: { 'src/App.tsx': 'same' },
        filesAfter: { 'src/App.tsx': 'same' },
        proposedClaims: ['Generated new Button component +40/-10']
      });
      const test2_2 = reality2.truthStatus === 'FABRICATED_CLAIM' && reality2.discrepancies.length > 0;
      record('Reality Gap Detector: Catches fabricated mutation claims when 0 files changed', test2_2, `Caught: ${reality2.discrepancies[0]?.category}`);

      // Test 2.3: False runtime pass catch
      const reality3 = RealityGapDetector.audit({
        userRequest: 'Render live preview',
        classifiedIntent: 'EXECUTION',
        filesBefore: { 'src/App.tsx': 'app' },
        filesAfter: { 'src/App.tsx': 'app' },
        runtimeErrors: ['Uncaught TypeError: Cannot read properties of undefined'],
        proposedClaims: ['preview passed with 0 errors']
      });
      const test2_3 = reality3.discrepancies.some(d => d.category === 'FALSE_RUNTIME_PASS');
      record('Reality Gap Detector: Catches false runtime pass when exceptions occur', test2_3, 'Caught FALSE_RUNTIME_PASS');
    } catch (err: any) {
      record('Reality Gap Detector Suite', false, `Crash: ${err.message}`);
    }

    // =========================================================================
    // 3. PROJECT DIGITAL TWIN TESTS
    // =========================================================================
    try {
      const snapshot = ProjectDigitalTwin.createSnapshot(mockWorkspace, []);
      const test3_1 = snapshot.totalFiles === 4 && snapshot.previewSnapshot.containsGodexUI === false;
      record('Digital Twin: Snapshot creation & Preview Isolation verification', test3_1, `Files: ${snapshot.totalFiles}, IsIsolated: ${snapshot.previewSnapshot.isolationVerified}`);

      // Test 3.2: Stale detection
      const mutatedWorkspace = { ...mockWorkspace, 'src/New.tsx': 'export const x = 1;' };
      const staleCheck = ProjectDigitalTwin.validateFingerprint(snapshot, mutatedWorkspace);
      const test3_2 = !staleCheck.isValid && !!staleCheck.staleReason;
      record('Digital Twin: Rejects stale snapshot on workspace mutation', test3_2, staleCheck.staleReason || 'OK');
    } catch (err: any) {
      record('Digital Twin Suite', false, `Crash: ${err.message}`);
    }

    // =========================================================================
    // 4. COUNTERFACTUAL ENGINEER TESTS
    // =========================================================================
    try {
      const cfResult = CounterfactualEngineer.simulate('Make dashboard premium with responsive layout', mockWorkspace);
      const test4_1 = cfResult.options.length >= 3 && cfResult.verificationStatus === 'VERIFIED';
      record('Counterfactual Engineer: Generates multi-strategy simulations without mutations', test4_1, `Strategies: ${cfResult.options.map(o => o.title).join(', ')}`);

      const hasRiskScores = cfResult.options.every(o => typeof o.riskScore === 'number' && o.riskScore >= 0);
      record('Counterfactual Engineer: Computes risk & visual scores for all options', hasRiskScores, 'Risk scoring verified');
    } catch (err: any) {
      record('Counterfactual Engineer Suite', false, `Crash: ${err.message}`);
    }

    // =========================================================================
    // 5. UI INTENT COMPILER TESTS
    // =========================================================================
    try {
      const uiIntent = UIIntentCompiler.compile('Make this app premium and modern');
      const test5_1 = uiIntent.visualDirection === 'PREMIUM_EDITORIAL' &&
        uiIntent.colorSystem.neutralSaturationMaxPercent <= 5 &&
        uiIntent.borderTreatment.maxBorderRadiusPx <= 16;
      record('UI Intent Compiler: Compiles structured premium intent with anti-slop rules', test5_1, `Direction: ${uiIntent.visualDirection}`);

      const badCode = '<div className="bg-gradient-to-r from-purple-500 to-blue-500 rounded-3xl shadow-[0_0_20px_cyan]">';
      const validation = UIIntentCompiler.validateImplementation(badCode, uiIntent);
      const test5_2 = !validation.passed && validation.violations.length >= 2;
      record('UI Intent Compiler: Rejects superficial AI slop (purple-to-blue gradients & glowing shadows)', test5_2, `Violations caught: ${validation.violations.length}`);
    } catch (err: any) {
      record('UI Intent Compiler Suite', false, `Crash: ${err.message}`);
    }

    // =========================================================================
    // 6. SYMBOL INTELLIGENCE HARDENING & TASKSCHEDULER REGRESSION TEST
    // =========================================================================
    try {
      const symIndex = new SymbolIndex();
      symIndex.updateFileSymbols('src/orchestration/orchestrationTypes.ts', [
        { id: 's1', name: 'TaskGraph', kind: 'interface', filePath: 'src/orchestration/orchestrationTypes.ts', line: 1, isExported: true }
      ]);
      symIndex.updateFileSymbols('src/App.tsx', [
        { id: 's2', name: 'App', kind: 'function', filePath: 'src/App.tsx', line: 4, isExported: true }
      ]);
      symIndex.updateFileSymbols('src/templates/novaNotesProject.ts', [
        { id: 's3', name: 'NovaNotesApp', kind: 'function', filePath: 'src/templates/novaNotesProject.ts', line: 1, isExported: true }
      ]);

      const scopedMatches = symIndex.resolveFileScopedSymbols(
        'src/orchestration/taskScheduler.ts',
        ['src/orchestration/orchestrationTypes.ts'],
        'App'
      );

      const taskGraphMatch = symIndex.resolveFileScopedSymbols(
        'src/orchestration/taskScheduler.ts',
        ['src/orchestration/orchestrationTypes.ts'],
        'TaskGraph'
      );

      const isTaskGraphDirectImport = taskGraphMatch.some(m => m.symbol.name === 'TaskGraph' && m.relationType === 'IMPORT');
      const isAppGlobalSearchOnly = scopedMatches.some(m => m.symbol.name === 'App' && m.relationType === 'GLOBAL_SEARCH_MATCH');

      record('Symbol Intelligence: Direct import classified as IMPORT relation', isTaskGraphDirectImport, 'TaskGraph -> IMPORT');
      record('Symbol Intelligence: Unrelated symbol labeled as GLOBAL_SEARCH_MATCH (not false REFERENCE)', isAppGlobalSearchOnly, 'App -> GLOBAL_SEARCH_MATCH');
    } catch (err: any) {
      record('Symbol Intelligence Suite', false, `Crash: ${err.message}`);
    }

    // =========================================================================
    // 7. SOFTWARE EVOLUTION ENGINE TESTS
    // =========================================================================
    try {
      const snapshot = ProjectDigitalTwin.createSnapshot(mockWorkspace, []);
      const evolutionEngine = SoftwareEvolutionEngine.getInstance();

      // Test 7.1: Snapshot generation and evolution report
      const report = evolutionEngine.analyzeEvolution(snapshot, []);
      const test7_1 = report.latestSnapshot.fileCount === 4 && report.healthModel.overallIntegrity > 0;
      record('Evolution Engine: Snapshot generation & health model calculation', test7_1, `Integrity: ${report.healthModel.overallIntegrity}/100`);

      // Test 7.2: Multidimensional health dimensions check
      const dims = Object.keys(report.healthModel.metrics);
      const test7_2 = dims.includes('ARCHITECTURE_HEALTH') && dims.includes('CODE_HEALTH') && dims.includes('AGENT_RELIABILITY');
      record('Evolution Engine: Evaluates 8 distinct health dimensions', test7_2, `Dimensions: ${dims.length}`);

      // Test 7.3: Agent reliability rewards safe mutation refusals
      evolutionEngine.recordAgentActivity('CODER', { success: true, refusedUnsafeMutation: true });
      const coderRel = evolutionEngine.analyzeEvolution(snapshot, []).agentReliabilityModels['CODER'];
      const test7_3 = !!coderRel && coderRel.safeRefusalCount >= 1 && coderRel.reliabilityScore >= 90;
      record('Evolution Engine: Rewards safe mutation refusals in agent reliability model', test7_3, `Safe refusals: ${coderRel?.safeRefusalCount}`);

      // Test 7.4: Recurring runtime failure detection
      evolutionEngine.recordRuntimeEvidence('Uncaught RangeError: Maximum call stack size exceeded');
      evolutionEngine.recordRuntimeEvidence('Uncaught RangeError: Maximum call stack size exceeded');
      const reportWithFailures = evolutionEngine.analyzeEvolution(snapshot, []);
      const test7_4 = reportWithFailures.recurringFailurePredictions.length > 0;
      record('Evolution Engine: Detects recurring runtime failure patterns', test7_4, `Recurring failures: ${reportWithFailures.recurringFailurePredictions.length}`);
    } catch (err: any) {
      record('Software Evolution Engine Suite', false, `Crash: ${err.message}`);
    }

    // =========================================================================
    // 8. ENGINEERING ORACLE TESTS
    // =========================================================================
    try {
      const oracle = EngineeringOracle.getInstance();
      const snapshot = ProjectDigitalTwin.createSnapshot(mockWorkspace, []);

      // Test 8.1: Risk query reasoning
      const res1 = oracle.query('What is becoming risky?', mockWorkspace, snapshot);
      const test8_1 = res1.status === 'OPTIMAL' && res1.observations.length > 0 && Array.isArray(res1.risks);
      record('Engineering Oracle: Answers risk queries with evidence-backed reasoning', test8_1, `Risks detected: ${res1.risks.length}`);

      // Test 8.2: Stable boundaries (What NOT to change)
      const res2 = oracle.query('What should we NOT change?', mockWorkspace, snapshot);
      const test8_2 = res2.whatNotToChange.length >= 0 && (res2.formattedAnswer?.includes('NOT to Change') || res2.formattedAnswer?.includes('Stable'));
      record('Engineering Oracle: Identifies stable boundaries (What NOT to change)', test8_2, `Stable modules: ${res2.whatNotToChange.length}`);

      // Test 8.3: Stale Digital Twin rejection
      const staleSnapshot = { ...snapshot, workspaceFingerprint: 'fp-stale-hash' };
      const resStale = oracle.query('What is becoming risky?', mockWorkspace, staleSnapshot);
      const test8_3 = resStale.isStale === true || resStale.status === 'DIGITAL_TWIN_STALE';
      record('Engineering Oracle: Rejects stale DigitalTwin snapshot with DIGITAL_TWIN_STALE status', test8_3, `Status: ${resStale.status}`);

      // Test 8.4: Secret redaction in oracle output
      const rawTextWithKey = 'Found key AIzaSyD9x8c7V6b5N4m3L2k1J0h9G8f7E6d5C4b3 in config';
      const redacted = EngineeringOracle.redactSecrets(rawTextWithKey);
      const test8_4 = !redacted.includes('AIzaSyD9') && redacted.includes('[REDACTED_API_KEY]');
      record('Engineering Oracle: Redacts API keys and sensitive tokens from reports', test8_4, redacted);
    } catch (err: any) {
      record('Engineering Oracle Suite', false, `Crash: ${err.message}`);
    }

    return {
      suiteName: 'Reality-First Engineering Intelligence Test Matrix',
      passed: testsFailed === 0,
      testsRun,
      testsPassed,
      testsFailed,
      details
    };
  }
}
