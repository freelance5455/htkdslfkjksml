/**
 * GODEX Project Digital Twin
 * Read-only, fingerprint-validated computational mirror of the workspace,
 * AST structures, dependency graph, runtime health, and preview isolation.
 */

import { AstParser } from './astParser';
import { ProjectSymbol } from './types';

export interface DigitalTwinFileNode {
  path: string;
  size: number;
  hash: string;
  lines: number;
  symbols: ProjectSymbol[];
  imports: string[];
  exports: string[];
  isEntry: boolean;
}

export interface DigitalTwinSnapshot {
  workspaceFingerprint: string;
  generatedAt: number;
  isStale: boolean;
  totalFiles: number;
  totalLines: number;
  totalBytes: number;
  files: Record<string, DigitalTwinFileNode>;
  symbols: Record<string, ProjectSymbol[]>;
  dependencyGraph: {
    adjacency: Record<string, string[]>;
    reverseAdjacency: Record<string, string[]>;
    entryPoints: string[];
    circularDependencies: string[][];
  };
  runtimeSnapshot: {
    entryPointFound: boolean;
    activeErrors: string[];
    isHealthy: boolean;
  };
  previewSnapshot: {
    containsGodexUI: boolean; // MUST be false
    rootMounted: boolean;
    isolationVerified: boolean;
  };
  operationSnapshot: {
    activeOperationId: string | null;
    status: string;
  };
}

export class ProjectDigitalTwin {
  /**
   * Computes a deterministic hash fingerprint from workspace file contents and paths.
   */
  public static computeFingerprint(files: Record<string, string>): string {
    const keys = Object.keys(files).sort();
    let hash = 0;
    for (const key of keys) {
      const content = files[key] || '';
      const str = `${key}:${content.length}:${content.slice(0, 100)}`;
      for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = (hash << 5) - hash + char;
        hash |= 0; // Convert to 32bit integer
      }
    }
    return `fp-${Math.abs(hash).toString(16)}-${keys.length}`;
  }

  /**
   * Generates a complete read-only digital twin snapshot of the active project.
   */
  public static createSnapshot(
    workspaceFiles: Record<string, string>,
    runtimeErrors: string[] = [],
    activeOperationId: string | null = null,
    operationStatus = 'IDLE'
  ): DigitalTwinSnapshot {
    const fileNodes: Record<string, DigitalTwinFileNode> = {};
    const symbolMap: Record<string, ProjectSymbol[]> = {};
    const adjacency: Record<string, string[]> = {};
    const reverseAdjacency: Record<string, string[]> = {};
    const entryPoints: string[] = [];

    let totalLines = 0;
    let totalBytes = 0;

    const filePaths = Object.keys(workspaceFiles);

    for (const filePath of filePaths) {
      const content = workspaceFiles[filePath] || '';
      const lines = content.split('\n').length;
      const size = content.length;
      totalLines += lines;
      totalBytes += size;

      const isEntry = filePath === 'src/App.tsx' || filePath === 'src/main.tsx' || filePath === 'index.html';
      if (isEntry) {
        entryPoints.push(filePath);
      }

      // AST extraction
      const ast = AstParser.parse(filePath, content);

      // File imports resolution
      const importedPaths: string[] = [];
      for (const imp of ast.imports) {
        if (!imp.isExternal && imp.source.startsWith('.')) {
          // Normalize relative path
          const cleanSource = imp.source.replace(/^\.\//, '');
          const candidatePath = filePath.includes('/')
            ? `${filePath.substring(0, filePath.lastIndexOf('/'))}/${cleanSource}`
            : cleanSource;
          
          // Match against known files
          const matched = filePaths.find(p => 
            p === candidatePath || 
            p === `${candidatePath}.ts` || 
            p === `${candidatePath}.tsx` ||
            p === `${candidatePath}/index.ts` ||
            p === `${candidatePath}/index.tsx`
          );
          if (matched) {
            importedPaths.push(matched);
          }
        }
      }

      adjacency[filePath] = importedPaths;

      // Reverse adjacency mapping
      for (const imp of importedPaths) {
        if (!reverseAdjacency[imp]) {
          reverseAdjacency[imp] = [];
        }
        if (!reverseAdjacency[imp].includes(filePath)) {
          reverseAdjacency[imp].push(filePath);
        }
      }

      // Symbol mapping
      for (const sym of ast.symbols) {
        if (!symbolMap[sym.name]) {
          symbolMap[sym.name] = [];
        }
        symbolMap[sym.name].push(sym);
      }

      fileNodes[filePath] = {
        path: filePath,
        size,
        hash: `h-${content.length}-${lines}`,
        lines,
        symbols: ast.symbols,
        imports: importedPaths,
        exports: ast.exports.map(e => e.name),
        isEntry
      };
    }

    const fingerprint = this.computeFingerprint(workspaceFiles);

    // Preview isolation assertion: generated app must NEVER mount GODEX Studio internals
    const hasGodexLeakingIntoPreview = filePaths.some(p => {
      if (p.startsWith('src/components/Godex') || p.startsWith('src/godex/')) {
        // If a file inside the app template directly renders GodexChatView or AgentStudioShell, flag it
        const c = workspaceFiles[p] || '';
        return c.includes('GodexAgentStudioShell') && p === 'src/App.tsx';
      }
      return false;
    });

    const entryPointFound = !!workspaceFiles['src/App.tsx'] || !!workspaceFiles['src/App.jsx'] || !!workspaceFiles['App.tsx'];

    return {
      workspaceFingerprint: fingerprint,
      generatedAt: Date.now(),
      isStale: false,
      totalFiles: filePaths.length,
      totalLines,
      totalBytes,
      files: fileNodes,
      symbols: symbolMap,
      dependencyGraph: {
        adjacency,
        reverseAdjacency,
        entryPoints,
        circularDependencies: []
      },
      runtimeSnapshot: {
        entryPointFound,
        activeErrors: runtimeErrors,
        isHealthy: entryPointFound && runtimeErrors.length === 0
      },
      previewSnapshot: {
        containsGodexUI: hasGodexLeakingIntoPreview,
        rootMounted: entryPointFound,
        isolationVerified: !hasGodexLeakingIntoPreview
      },
      operationSnapshot: {
        activeOperationId,
        status: operationStatus
      }
    };
  }

  /**
   * Validates if an existing snapshot matches current workspace state.
   */
  public static validateFingerprint(
    snapshot: DigitalTwinSnapshot,
    currentFiles: Record<string, string>
  ): { isValid: boolean; staleReason?: string } {
    const currentFp = this.computeFingerprint(currentFiles);
    if (snapshot.workspaceFingerprint !== currentFp) {
      return {
        isValid: false,
        staleReason: `Workspace modified since snapshot (${snapshot.workspaceFingerprint} vs ${currentFp}). Re-indexing required.`
      };
    }
    return { isValid: true };
  }
}
