/**
 * GODEX Universal UI/UX Quality System - Typography Engine
 * Enforces clear typographic hierarchy, mathematical step scales, controlled weights,
 * optimal line lengths (65-75ch), and font pairings.
 */

import { TypographyScale, TypographyScaleItem, DesignPersonality } from './types';

export class TypographyEngine {
  /**
   * Builds the complete typography scale for the given design personality
   */
  public static getScale(personality: DesignPersonality): TypographyScale {
    const isDense = personality.densityPreference === 'compact';

    return {
      display: {
        name: 'Display',
        fontSize: isDense ? '2rem (32px)' : '2.5rem (40px)',
        lineHeight: '1.2',
        fontWeight: '800',
        letterSpacing: '-0.025em',
        tailwindClass: isDense 
          ? 'text-2xl sm:text-3xl font-extrabold tracking-tight leading-tight text-white' 
          : 'text-3xl sm:text-4xl font-extrabold tracking-tight leading-tight text-white'
      },
      h1: {
        name: 'Heading 1',
        fontSize: isDense ? '1.5rem (24px)' : '1.75rem (28px)',
        lineHeight: '1.25',
        fontWeight: '700',
        letterSpacing: '-0.02em',
        tailwindClass: isDense 
          ? 'text-xl sm:text-2xl font-bold tracking-tight text-white' 
          : 'text-2xl sm:text-3xl font-bold tracking-tight text-white'
      },
      h2: {
        name: 'Heading 2',
        fontSize: '1.25rem (20px)',
        lineHeight: '1.3',
        fontWeight: '700',
        letterSpacing: '-0.015em',
        tailwindClass: 'text-lg sm:text-xl font-bold text-white tracking-tight'
      },
      h3: {
        name: 'Heading 3',
        fontSize: '1.0625rem (17px)',
        lineHeight: '1.4',
        fontWeight: '600',
        letterSpacing: '-0.01em',
        tailwindClass: 'text-base font-semibold text-slate-200'
      },
      body: {
        name: 'Body',
        fontSize: '0.9375rem (15px)',
        lineHeight: '1.6',
        fontWeight: '400',
        letterSpacing: '0',
        tailwindClass: 'text-sm sm:text-base text-slate-300 font-normal leading-relaxed max-w-[70ch]'
      },
      bodySmall: {
        name: 'Body Small',
        fontSize: '0.8125rem (13px)',
        lineHeight: '1.5',
        fontWeight: '400',
        letterSpacing: '0',
        tailwindClass: 'text-xs sm:text-sm text-slate-400 font-normal leading-normal'
      },
      label: {
        name: 'Label',
        fontSize: '0.75rem (12px)',
        lineHeight: '1.2',
        fontWeight: '600',
        letterSpacing: '0.05em',
        tailwindClass: 'text-xs font-semibold uppercase tracking-wider text-slate-400'
      },
      caption: {
        name: 'Caption',
        fontSize: '0.6875rem (11px)',
        lineHeight: '1.3',
        fontWeight: '500',
        letterSpacing: '0.02em',
        tailwindClass: 'text-[11px] text-slate-400 font-medium'
      },
      code: {
        name: 'Code / Mono',
        fontSize: '0.8125rem (13px)',
        lineHeight: '1.5',
        fontWeight: '500',
        letterSpacing: '0',
        tailwindClass: 'font-mono text-xs text-cyan-300 bg-[#0F172A] px-1.5 py-0.5 rounded border border-[#1E293B]'
      }
    };
  }

  /**
   * Validates if a code string follows typography rules (no skipped heading levels, no wrapped button text)
   */
  public static validateTypography(code: string): { valid: boolean; issues: string[] } {
    const issues: string[] = [];

    // Check for skipped heading levels (e.g. h1 directly to h3 without h2)
    const hasH1 = /<h1\b/i.test(code);
    const hasH2 = /<h2\b/i.test(code);
    const hasH3 = /<h3\b/i.test(code);

    if (hasH1 && hasH3 && !hasH2) {
      issues.push('Heading hierarchy skipped level 2 (<h1 ...> followed by <h3 ...> without <h2 ...>).');
    }

    // Check for all-caps body text
    if (/className=["'][^"']*\buppercase\b[^"']*(?:text-sm|text-base|text-lg)[^"']*["']/i.test(code)) {
      issues.push('All-caps (uppercase) detected on full body-sized text element. Reserve uppercase for micro-labels and badges only.');
    }

    return {
      valid: issues.length === 0,
      issues
    };
  }
}
