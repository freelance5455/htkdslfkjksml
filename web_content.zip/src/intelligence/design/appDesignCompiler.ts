/**
 * GODEX Universal UI/UX Quality System - Generated App Design Compiler
 * Master pipeline orchestrating:
 * User Intent -> Product Type Inference -> Information Architecture ->
 * Design Personality -> Design Tokens -> Component Primitives ->
 * Layout Structure -> Responsive Rules -> Real UI States ->
 * Motion Rules -> Accessibility Gate -> Visual Quality Audit -> Verified Output.
 */

import { ProductCategory, DesignPersonality, ColorTokens, UIQualityAuditResult, InformationArchitectureSpec } from './types';
import { DesignPersonalityInferer } from './designPersonality';
import { DesignTokenCompiler } from './tokenCompiler';
import { TypographyEngine } from './typographyEngine';
import { SpacingEngine } from './spacingEngine';
import { ComponentPrimitivesGenerator } from './componentPrimitives';
import { InformationArchitectureEngine } from './informationArchitecture';
import { AntiUglyEngine } from './antiUglyEngine';
import { VisualQualityGate } from './visualQualityGate';
import { DesignSystemMemory } from './designSystemMemory';

export interface AppDesignCompilationContext {
  prompt: string;
  projectId?: string;
  existingFiles?: Record<string, string>;
}

export interface AppDesignCompilationResult {
  category: ProductCategory;
  personality: DesignPersonality;
  tokens: ColorTokens;
  qualityAudit: UIQualityAuditResult;
  primitivesSourceCode: string;
  systemPromptGuidelines: string;
  iaSpec: InformationArchitectureSpec;
}

export class AppDesignCompiler {
  /**
   * Compiles design specifications and guidelines for a given prompt
   */
  public static compile(context: AppDesignCompilationContext): AppDesignCompilationResult {
    const { prompt, projectId = 'proj-default', existingFiles = {} } = context;

    // 1. INFER CATEGORY & PERSONALITY
    const filePaths = Object.keys(existingFiles);
    const category = DesignPersonalityInferer.inferCategory(prompt, filePaths);
    const personality = DesignPersonalityInferer.getPersonality(category, prompt);

    // 2. COMPILE DESIGN TOKENS
    const tokens = DesignTokenCompiler.compileTokens(personality);

    // 3. GENERATE ACCESSIBLE COMPONENT PRIMITIVES
    const primitivesSourceCode = ComponentPrimitivesGenerator.generatePrimitivesCode(personality, tokens);

    // 4. PLAN INFORMATION ARCHITECTURE
    const iaSpec = InformationArchitectureEngine.planLayout(prompt, category);

    // 5. RUN INITIAL QUALITY & ANTI-UGLY AUDIT
    const qualityAudit = VisualQualityGate.auditWorkspace(existingFiles, personality);

    // 6. RECORD IN DESIGN SYSTEM MEMORY
    DesignSystemMemory.getInstance().recordDecision(
      projectId,
      category,
      tokens,
      personality.radiusProfile.containerRadiusPx,
      iaSpec.groupingStrategy
    );

    // 7. BUILD PROMPT DIRECTIVES FOR GEMINI
    const systemPromptGuidelines = `
=== GODEX UNIVERSAL UI/UX QUALITY DIRECTIVES (ZERO-SLOP DESIGN ENGINE) ===
[DESIGN PERSONALITY: ${personality.archetype.toUpperCase()} | CATEGORY: ${category.toUpperCase()}]
- Tone: ${personality.tone} | Density: ${personality.densityPreference} | Color Mode: ${personality.colorMode}
- Palette: Background: ${tokens.background}, Surface: ${tokens.surface}, Elevated: ${tokens.elevatedSurface}, Primary: ${tokens.primary}, Border: ${tokens.border}, Text: ${tokens.textPrimary}.
- Strict Anti-Slop Rules:
  1. NO generic purple-to-blue gradient cards or cyan text on dark with low contrast. Use solid dark surfaces with subtle border strokes.
  2. NO cards inside cards. Flatten layouts using subtle dividers, typography contrast, or clean spacing.
  3. NO generic SaaS fluff ("supercharge", "empower"). Use exact domain terminology.
  4. NO arbitrary spacing (e.g. p-[13px]). Use standard mathematical scale [4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80]px.
  5. Enforce full UI state lifecycle: Loading skeletons, Empty states with call-to-actions, Error states with retry, and disabled/hover/focus-visible states.
  6. Accessibility: Touch targets >= 44px on mobile, aria-label on all icon-only buttons, semantic <main>, <header>, <nav>/<aside>.
  7. Multi-viewport reflow: Every grid must collapse gracefully (e.g. "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4").
==========================================================================
`;

    return {
      category,
      personality,
      tokens,
      qualityAudit,
      primitivesSourceCode,
      systemPromptGuidelines,
      iaSpec
    };
  }
}
