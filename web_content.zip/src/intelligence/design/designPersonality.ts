/**
 * GODEX Universal UI/UX Quality System - Design Personality Inferer
 * Infers product category and determines tailored aesthetic personalities
 * (SaaS, Finance, Creative, DevTools, Healthcare, Gaming, E-commerce, Productivity).
 */

import { ProductCategory, DesignPersonality } from './types';

export class DesignPersonalityInferer {
  /**
   * Infers product category from user prompt, existing files, or architecture context
   */
  public static inferCategory(prompt: string, filePaths: string[] = []): ProductCategory {
    const p = prompt.toLowerCase();
    const joinedPaths = filePaths.join(' ').toLowerCase();

    // 1. Finance & Fintech
    if (
      /\b(?:finance|fintech|banking|crypto|portfolio|wallet|stock|trading|invoice|budget|expense|accounting|ledger|payroll|tax)\b/i.test(p) ||
      /\b(?:currency|transactions|balance|pnl|revenue|stripe|paypal)\b/i.test(p)
    ) {
      return 'finance';
    }

    // 2. DevTools & Engineering
    if (
      /\b(?:devtools|terminal|debugger|compiler|git|ast|code\s*editor|ide|regex|linter|api\s*tester|json\s*formatter|log\s*viewer|docker|kubernetes|telemetry)\b/i.test(p) ||
      joinedPaths.includes('terminal') || joinedPaths.includes('editor') || joinedPaths.includes('ast')
    ) {
      return 'devtools';
    }

    // 3. Healthcare & Medical
    if (
      /\b(?:health|medical|clinic|doctor|patient|prescription|hospital|telehealth|vitals|ehr|emr|medication|cardio|fitness|wellness)\b/i.test(p)
    ) {
      return 'healthcare';
    }

    // 4. Creative & Media
    if (
      /\b(?:video|media|audio|canvas|drawing|photo|editor|timeline|sound|music|synth|art|design\s*tool|cineforge|animation|vector)\b/i.test(p) ||
      joinedPaths.includes('timeline') || joinedPaths.includes('canvas')
    ) {
      return 'creative';
    }

    // 5. Gaming & Interactive
    if (
      /\b(?:game|gaming|arcade|racer|rpg|quest|inventory|leaderboard|score|fps|multiplayer|turn-based|chess|boardgame)\b/i.test(p)
    ) {
      return 'gaming';
    }

    // 6. E-Commerce & Retail
    if (
      /\b(?:ecommerce|e-commerce|store|shop|cart|checkout|product\s*catalog|inventory\s*store|pos|orders|customer\s*orders)\b/i.test(p)
    ) {
      return 'ecommerce';
    }

    // 7. Productivity, Tasks & Notes
    if (
      /\b(?:todo|tasks|kanban|notes|notepad|planner|calendar|habit|reminder|document|wiki|workflow|board|sprint|project\s*management)\b/i.test(p)
    ) {
      return 'productivity';
    }

    // 8. SaaS & Analytics
    if (
      /\b(?:saas|dashboard|analytics|metrics|admin|crm|kpi|overview|insights|monitoring|platform|portal|subscribers)\b/i.test(p)
    ) {
      return 'saas';
    }

    return 'general';
  }

  /**
   * Generates a fully fleshed out design personality for the inferred category
   */
  public static getPersonality(category: ProductCategory, prompt = ''): DesignPersonality {
    const isDarkRequested = /\b(?:dark|night|dim|black|obsidian)\b/i.test(prompt);

    switch (category) {
      case 'finance':
        return {
          category: 'finance',
          archetype: 'Calm Data-First Ledger',
          tone: 'calm',
          visualKeywords: ['restrained', 'monospaced-metrics', 'high-legibility', 'muted-surfaces', 'crisp-borders'],
          densityPreference: 'compact',
          colorMode: 'dark_refined',
          typographyProfile: {
            headingFont: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            bodyFont: 'system-ui, -apple-system, BlinkMacSystemFont, sans-serif',
            monoFont: '"JetBrains Mono", "SF Mono", Menlo, Consolas, monospace',
            stepRatio: 1.2
          },
          elevationStyle: 'subtle_stroke',
          radiusProfile: {
            baseRadiusPx: 8,
            containerRadiusPx: 12,
            tagRadiusPx: 6
          },
          motionProfile: {
            entranceDurationMs: 150,
            hoverTransitionMs: 100,
            springStiffness: 300
          },
          layoutArchetype: 'dense_matrix'
        };

      case 'devtools':
        return {
          category: 'devtools',
          archetype: 'Dense Technical Workbench',
          tone: 'dense',
          visualKeywords: ['keyboard-friendly', 'high-information-density', 'monospaced', 'flat-contrast', 'tool-docked'],
          densityPreference: 'compact',
          colorMode: 'high_contrast_dark',
          typographyProfile: {
            headingFont: 'system-ui, -apple-system, sans-serif',
            bodyFont: 'system-ui, -apple-system, sans-serif',
            monoFont: '"JetBrains Mono", "Fira Code", monospace',
            stepRatio: 1.15
          },
          elevationStyle: 'flat_minimal',
          radiusProfile: {
            baseRadiusPx: 6,
            containerRadiusPx: 10,
            tagRadiusPx: 4
          },
          motionProfile: {
            entranceDurationMs: 100,
            hoverTransitionMs: 80,
            springStiffness: 400
          },
          layoutArchetype: 'split_workbench'
        };

      case 'creative':
        return {
          category: 'creative',
          archetype: 'Immersive Media Studio',
          tone: 'expressive',
          visualKeywords: ['deep-canvas', 'floating-inspectors', 'visual-preview', 'accent-illuminated', 'frameless-viewport'],
          densityPreference: 'comfortable',
          colorMode: 'dark_refined',
          typographyProfile: {
            headingFont: 'system-ui, -apple-system, sans-serif',
            bodyFont: 'system-ui, -apple-system, sans-serif',
            monoFont: '"SF Mono", Menlo, monospace',
            stepRatio: 1.25
          },
          elevationStyle: 'layered_soft',
          radiusProfile: {
            baseRadiusPx: 10,
            containerRadiusPx: 14,
            tagRadiusPx: 8
          },
          motionProfile: {
            entranceDurationMs: 200,
            hoverTransitionMs: 150,
            springStiffness: 250
          },
          layoutArchetype: 'canvas_studio'
        };

      case 'healthcare':
        return {
          category: 'healthcare',
          archetype: 'Reassuring Accessible Clinical Portal',
          tone: 'accessible',
          visualKeywords: ['soft-contrast', 'high-clarity', 'large-touch-targets', 'peaceful', 'clear-hierarchy'],
          densityPreference: 'spacious',
          colorMode: isDarkRequested ? 'dark_refined' : 'light_refined',
          typographyProfile: {
            headingFont: 'system-ui, -apple-system, sans-serif',
            bodyFont: 'system-ui, -apple-system, sans-serif',
            monoFont: 'monospace',
            stepRatio: 1.25
          },
          elevationStyle: 'subtle_stroke',
          radiusProfile: {
            baseRadiusPx: 12,
            containerRadiusPx: 16,
            tagRadiusPx: 8
          },
          motionProfile: {
            entranceDurationMs: 180,
            hoverTransitionMs: 120,
            springStiffness: 280
          },
          layoutArchetype: 'hierarchical_overview'
        };

      case 'gaming':
        return {
          category: 'gaming',
          archetype: 'Dynamic High-Energy Interactive Engine',
          tone: 'expressive',
          visualKeywords: ['high-contrast-neon-accents', 'cyber-surfaces', 'responsive-audio-visual', 'hud-overlay'],
          densityPreference: 'comfortable',
          colorMode: 'high_contrast_dark',
          typographyProfile: {
            headingFont: 'system-ui, -apple-system, sans-serif',
            bodyFont: 'system-ui, -apple-system, sans-serif',
            monoFont: '"JetBrains Mono", monospace',
            stepRatio: 1.333
          },
          elevationStyle: 'layered_soft',
          radiusProfile: {
            baseRadiusPx: 8,
            containerRadiusPx: 14,
            tagRadiusPx: 6
          },
          motionProfile: {
            entranceDurationMs: 250,
            hoverTransitionMs: 120,
            springStiffness: 350
          },
          layoutArchetype: 'centered_feed'
        };

      case 'ecommerce':
        return {
          category: 'ecommerce',
          archetype: 'Conversion-Focused Product Showcase',
          tone: 'conversion',
          visualKeywords: ['product-first', 'clear-call-to-action', 'crisp-pricing', 'fluid-grid', 'accessible-checkout'],
          densityPreference: 'comfortable',
          colorMode: isDarkRequested ? 'dark_refined' : 'light_refined',
          typographyProfile: {
            headingFont: 'system-ui, -apple-system, sans-serif',
            bodyFont: 'system-ui, -apple-system, sans-serif',
            monoFont: 'monospace',
            stepRatio: 1.25
          },
          elevationStyle: 'subtle_stroke',
          radiusProfile: {
            baseRadiusPx: 10,
            containerRadiusPx: 16,
            tagRadiusPx: 8
          },
          motionProfile: {
            entranceDurationMs: 180,
            hoverTransitionMs: 150,
            springStiffness: 280
          },
          layoutArchetype: 'hierarchical_overview'
        };

      case 'productivity':
        return {
          category: 'productivity',
          archetype: 'Focused Low-Cognitive-Load Workspace',
          tone: 'lightweight',
          visualKeywords: ['focused', 'low-cognitive-load', 'clean-kanban', 'smooth-drag', 'uncluttered-feed'],
          densityPreference: 'comfortable',
          colorMode: 'dark_refined',
          typographyProfile: {
            headingFont: 'system-ui, -apple-system, sans-serif',
            bodyFont: 'system-ui, -apple-system, sans-serif',
            monoFont: 'monospace',
            stepRatio: 1.2
          },
          elevationStyle: 'subtle_stroke',
          radiusProfile: {
            baseRadiusPx: 8,
            containerRadiusPx: 12,
            tagRadiusPx: 6
          },
          motionProfile: {
            entranceDurationMs: 160,
            hoverTransitionMs: 120,
            springStiffness: 300
          },
          layoutArchetype: 'split_workbench'
        };

      case 'saas':
      default:
        return {
          category: 'saas',
          archetype: 'Precise Structured Enterprise SaaS',
          tone: 'precise',
          visualKeywords: ['structured', 'efficient', 'trustworthy', 'executive-telemetry', 'modular-grid'],
          densityPreference: 'comfortable',
          colorMode: 'dark_refined',
          typographyProfile: {
            headingFont: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            bodyFont: 'system-ui, -apple-system, BlinkMacSystemFont, sans-serif',
            monoFont: '"JetBrains Mono", "SF Mono", monospace',
            stepRatio: 1.25
          },
          elevationStyle: 'subtle_stroke',
          radiusProfile: {
            baseRadiusPx: 8,
            containerRadiusPx: 14,
            tagRadiusPx: 6
          },
          motionProfile: {
            entranceDurationMs: 180,
            hoverTransitionMs: 120,
            springStiffness: 300
          },
          layoutArchetype: 'hierarchical_overview'
        };
    }
  }
}
