/**
 * GODEX Universal UI/UX Quality System - Component Primitives Generator
 * Produces clean, accessible, zero-slop component templates in React/TypeScript
 * (Button, Input, Card, Badge, Modal, EmptyState, LoadingState, ErrorState, Alert, Avatar, Skeleton, Tabs, Table).
 */

import { ColorTokens, DesignPersonality } from './types';

export class ComponentPrimitivesGenerator {
  /**
   * Generates a cohesive set of reusable UI primitives in a single exportable module
   */
  public static generatePrimitivesCode(personality: DesignPersonality, tokens: ColorTokens): string {
    const isDark = personality.colorMode !== 'light_refined';
    const radius = personality.radiusProfile.baseRadiusPx;
    const containerRadius = personality.radiusProfile.containerRadiusPx;

    return `import React, { forwardRef, useState } from 'react';
import { 
  AlertCircle, CheckCircle2, AlertTriangle, Info, X, ChevronRight, 
  Loader2, RefreshCw, Eye, EyeOff, Search, Sparkles
} from 'lucide-react';

/* =========================================================================
   1. BUTTON PRIMITIVE (Primary, Secondary, Danger, Ghost, Outline)
   ========================================================================= */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(({
  variant = 'primary',
  size = 'md',
  isLoading = false,
  leftIcon,
  rightIcon,
  children,
  className = '',
  disabled,
  ...props
}, ref) => {
  const baseClasses = "inline-flex items-center justify-center font-semibold transition-all duration-150 select-none whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-1 disabled:opacity-50 disabled:pointer-events-none active:scale-[0.98]";
  
  const sizeClasses = {
    sm: "text-xs px-3 py-1.5 min-h-[36px] rounded-lg gap-1.5",
    md: "text-xs sm:text-sm px-4 py-2 min-h-[42px] rounded-xl gap-2",
    lg: "text-sm sm:text-base px-5 py-2.5 min-h-[48px] rounded-xl gap-2.5"
  }[size];

  const variantClasses = {
    primary: "${isDark ? 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-950/40 focus-visible:ring-cyan-400' : 'bg-slate-900 hover:bg-slate-800 text-white shadow-sm focus-visible:ring-slate-900'}",
    secondary: "${isDark ? 'bg-[#141E34] hover:bg-[#1C2A48] text-slate-200 border border-[#233355] focus-visible:ring-slate-400' : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 focus-visible:ring-slate-400'}",
    danger: "${isDark ? 'bg-rose-900/80 hover:bg-rose-800 text-rose-200 border border-rose-700/80 focus-visible:ring-rose-400' : 'bg-rose-600 hover:bg-rose-500 text-white shadow-sm focus-visible:ring-rose-500'}",
    ghost: "${isDark ? 'text-slate-300 hover:text-white hover:bg-slate-800/60 focus-visible:ring-slate-400' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 focus-visible:ring-slate-400'}",
    outline: "${isDark ? 'bg-transparent text-cyan-400 border border-cyan-700/60 hover:bg-cyan-950/30 focus-visible:ring-cyan-400' : 'bg-transparent text-slate-800 border border-slate-300 hover:bg-slate-50 focus-visible:ring-slate-400'}"
  }[variant];

  return (
    <button
      ref={ref}
      disabled={disabled || isLoading}
      className={\`\${baseClasses} \${sizeClasses} \${variantClasses} \${className}\`}
      {...props}
    >
      {isLoading ? (
        <Loader2 className="w-4 h-4 animate-spin text-current shrink-0" />
      ) : leftIcon ? (
        <span className="shrink-0">{leftIcon}</span>
      ) : null}
      <span>{children}</span>
      {!isLoading && rightIcon && <span className="shrink-0">{rightIcon}</span>}
    </button>
  );
});
Button.displayName = 'Button';

/* =========================================================================
   2. INPUT & TEXTAREA PRIMITIVES
   ========================================================================= */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  leftIcon?: React.ReactNode;
  rightElement?: React.ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(({
  label,
  error,
  helperText,
  leftIcon,
  rightElement,
  id,
  className = '',
  ...props
}, ref) => {
  const inputId = id || (label ? label.toLowerCase().replace(/\\s+/g, '-') : undefined);

  return (
    <div className="w-full space-y-1.5 text-left">
      {label && (
        <label htmlFor={inputId} className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
          {label}
        </label>
      )}
      <div className="relative flex items-center">
        {leftIcon && (
          <div className="absolute left-3.5 pointer-events-none text-slate-400 flex items-center justify-center">
            {leftIcon}
          </div>
        )}
        <input
          ref={ref}
          id={inputId}
          className={\`w-full text-xs sm:text-sm min-h-[42px] px-3.5 py-2 rounded-xl transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 disabled:opacity-50 disabled:cursor-not-allowed \${
            leftIcon ? 'pl-10' : ''
          } \${rightElement ? 'pr-10' : ''} \${
            error 
              ? 'border-rose-500 bg-rose-950/20 text-rose-200 focus-visible:ring-rose-500' 
              : '${isDark ? 'bg-[#0D1424] border-[#1E2B45] text-slate-100 placeholder-slate-500 focus-visible:ring-cyan-500/50 focus-visible:border-cyan-500' : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400 focus-visible:ring-blue-500/30 focus-visible:border-blue-500'}'
          } border \${className}\`}
          {...props}
        />
        {rightElement && (
          <div className="absolute right-3 flex items-center justify-center">
            {rightElement}
          </div>
        )}
      </div>
      {error ? (
        <p className="text-[11px] font-medium text-rose-400 flex items-center gap-1">
          <AlertCircle className="w-3 h-3 shrink-0" />
          {error}
        </p>
      ) : helperText ? (
        <p className="text-[11px] text-slate-400 font-medium">{helperText}</p>
      ) : null}
    </div>
  );
});
Input.displayName = 'Input';

/* =========================================================================
   3. CARD CONTAINER PRIMITIVE
   ========================================================================= */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'surface' | 'elevated' | 'outlined';
  header?: React.ReactNode;
  footer?: React.ReactNode;
}

export const Card: React.FC<CardProps> = ({
  variant = 'surface',
  header,
  footer,
  children,
  className = '',
  ...props
}) => {
  const variantStyles = {
    surface: "${isDark ? 'bg-[#0D1424] border-[#1E2B45]' : 'bg-white border-slate-200 shadow-sm'}",
    elevated: "${isDark ? 'bg-[#141E34] border-[#253657] shadow-xl' : 'bg-white border-slate-200 shadow-md'}",
    outlined: "${isDark ? 'bg-transparent border-[#1E2B45]' : 'bg-transparent border-slate-300'}"
  }[variant];

  return (
    <div
      className={\`rounded-2xl border p-5 sm:p-6 transition-all duration-150 \${variantStyles} \${className}\`}
      {...props}
    >
      {header && (
        <div className="pb-4 mb-4 border-b ${isDark ? 'border-[#1E2B45]' : 'border-slate-100'}">
          {header}
        </div>
      )}
      <div className="space-y-4">{children}</div>
      {footer && (
        <div className="pt-4 mt-4 border-t ${isDark ? 'border-[#1E2B45]' : 'border-slate-100'} flex items-center justify-end gap-2">
          {footer}
        </div>
      )}
    </div>
  );
};

/* =========================================================================
   4. BADGE / CHIP PRIMITIVE
   ========================================================================= */
export interface BadgeProps {
  variant?: 'neutral' | 'info' | 'success' | 'warning' | 'danger';
  size?: 'sm' | 'md';
  children: React.ReactNode;
  dot?: boolean;
}

export const Badge: React.FC<BadgeProps> = ({
  variant = 'neutral',
  size = 'md',
  children,
  dot = false
}) => {
  const variantStyles = {
    neutral: "${isDark ? 'bg-[#162035] text-slate-300 border-[#233350]' : 'bg-slate-100 text-slate-700 border-slate-200'}",
    info: "${isDark ? 'bg-cyan-950/80 text-cyan-300 border-cyan-800/80' : 'bg-blue-50 text-blue-700 border-blue-200'}",
    success: "${isDark ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800/80' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}",
    warning: "${isDark ? 'bg-amber-950/80 text-amber-300 border-amber-800/80' : 'bg-amber-50 text-amber-700 border-amber-200'}",
    danger: "${isDark ? 'bg-rose-950/80 text-rose-300 border-rose-800/80' : 'bg-rose-50 text-rose-700 border-rose-200'}"
  }[variant];

  const dotColors = {
    neutral: 'bg-slate-400',
    info: 'bg-cyan-400',
    success: 'bg-emerald-400 animate-pulse',
    warning: 'bg-amber-400',
    danger: 'bg-rose-400'
  }[variant];

  return (
    <span className={\`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border font-mono font-semibold tracking-wide whitespace-nowrap \${
      size === 'sm' ? 'text-[10px]' : 'text-xs'
    } \${variantStyles}\`}>
      {dot && <span className={\`w-1.5 h-1.5 rounded-full \${dotColors}\`} />}
      {children}
    </span>
  );
};

/* =========================================================================
   5. EMPTY STATE PRIMITIVE
   ========================================================================= */
export interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  actionLabel,
  onAction
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 sm:p-12 text-center rounded-2xl border border-dashed ${isDark ? 'border-[#1E2B45] bg-[#090D17]/50' : 'border-slate-200 bg-slate-50/50'} space-y-3">
      {icon ? (
        <div className="w-12 h-12 rounded-2xl ${isDark ? 'bg-[#141E34] text-cyan-400' : 'bg-white text-slate-600 shadow-sm'} flex items-center justify-center mb-1">
          {icon}
        </div>
      ) : (
        <div className="w-12 h-12 rounded-2xl ${isDark ? 'bg-[#141E34] text-cyan-400' : 'bg-white text-slate-600 shadow-sm'} flex items-center justify-center mb-1">
          <Sparkles className="w-6 h-6" />
        </div>
      )}
      <h4 className="text-sm sm:text-base font-bold text-white tracking-tight">{title}</h4>
      <p className="text-xs sm:text-sm text-slate-400 max-w-sm leading-relaxed">{description}</p>
      {actionLabel && onAction && (
        <div className="pt-2">
          <Button variant="primary" size="sm" onClick={onAction}>
            {actionLabel}
          </Button>
        </div>
      )}
    </div>
  );
};

/* =========================================================================
   6. ERROR STATE PRIMITIVE
   ========================================================================= */
export interface ErrorStateProps {
  title?: string;
  message: string;
  onRetry?: () => void;
}

export const ErrorState: React.FC<ErrorStateProps> = ({
  title = "Something went wrong",
  message,
  onRetry
}) => {
  return (
    <div className="p-6 rounded-2xl border border-rose-800/60 bg-rose-950/20 text-rose-200 space-y-3">
      <div className="flex items-center gap-2 font-bold text-sm text-rose-300">
        <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
        <span>{title}</span>
      </div>
      <p className="text-xs text-rose-300/80 leading-relaxed font-mono">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-900/60 hover:bg-rose-900 text-rose-200 border border-rose-700 transition-all active:scale-95"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Retry Operation</span>
        </button>
      )}
    </div>
  );
};

/* =========================================================================
   7. SKELETON / LOADING PRIMITIVE
   ========================================================================= */
export const Skeleton: React.FC<{ className?: string }> = ({ className = 'h-4 w-full' }) => {
  return (
    <div className={\`animate-pulse rounded-lg \${
      "${isDark ? 'bg-[#162238]' : 'bg-slate-200'}"
    } \${className}\`} />
  );
};
`;
  }
}
