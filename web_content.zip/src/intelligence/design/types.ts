/**
 * GODEX Universal UI/UX Quality System - Core Data Types
 * Comprehensive data contracts for design intelligence, token compiler,
 * typography, spacing, component primitives, anti-ugly validations, and quality gates.
 */

export type ProductCategory = 
  | 'saas' 
  | 'finance' 
  | 'creative' 
  | 'devtools' 
  | 'healthcare' 
  | 'gaming' 
  | 'ecommerce' 
  | 'productivity' 
  | 'general';

export interface DesignPersonality {
  category: ProductCategory;
  archetype: string;
  tone: 'precise' | 'calm' | 'expressive' | 'dense' | 'accessible' | 'conversion' | 'lightweight';
  visualKeywords: string[];
  densityPreference: 'compact' | 'comfortable' | 'spacious';
  colorMode: 'dark_refined' | 'light_refined' | 'high_contrast_dark';
  typographyProfile: {
    headingFont: string;
    bodyFont: string;
    monoFont: string;
    stepRatio: number; // e.g. 1.25 (Major Second) or 1.333 (Perfect Fourth)
  };
  elevationStyle: 'subtle_stroke' | 'layered_soft' | 'flat_minimal';
  radiusProfile: {
    baseRadiusPx: number; // 8 - 14px
    containerRadiusPx: number; // 12 - 16px
    tagRadiusPx: number; // 6 - 8px or pill
  };
  motionProfile: {
    entranceDurationMs: number;
    hoverTransitionMs: number;
    springStiffness: number;
  };
  layoutArchetype: 'split_workbench' | 'centered_feed' | 'dense_matrix' | 'canvas_studio' | 'hierarchical_overview';
}

export interface ColorTokens {
  background: string;
  surface: string;
  elevatedSurface: string;
  primary: string;
  primaryHover: string;
  primaryActive: string;
  secondary: string;
  secondaryHover: string;
  accent: string;
  accentSubtle: string;
  success: string;
  successSubtle: string;
  warning: string;
  warningSubtle: string;
  danger: string;
  dangerSubtle: string;
  info: string;
  infoSubtle: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  textInverse: string;
  border: string;
  borderSubtle: string;
  borderHighlight: string;
  focusRing: string;
}

export interface TypographyScaleItem {
  name: string;
  fontSize: string;
  lineHeight: string;
  fontWeight: string;
  letterSpacing: string;
  tailwindClass: string;
}

export interface TypographyScale {
  display: TypographyScaleItem;
  h1: TypographyScaleItem;
  h2: TypographyScaleItem;
  h3: TypographyScaleItem;
  body: TypographyScaleItem;
  bodySmall: TypographyScaleItem;
  label: TypographyScaleItem;
  caption: TypographyScaleItem;
  code: TypographyScaleItem;
}

export interface SpacingScale {
  scale: number[]; // [4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80]
  unit: 'px';
  buttonPaddingRatio: number; // exactly 2x (horizontal to vertical)
  minContainerPaddingPx: number; // 16px
  nestedRadiusFormula: (outerRadius: number, padding: number) => number;
}

export type UIState = 
  | 'DEFAULT' 
  | 'HOVER' 
  | 'FOCUS' 
  | 'ACTIVE' 
  | 'DISABLED' 
  | 'LOADING' 
  | 'SUCCESS' 
  | 'ERROR' 
  | 'EMPTY' 
  | 'PARTIAL' 
  | 'OFFLINE' 
  | 'RETRY';

export interface AntiUglyViolation {
  id: string;
  category: 'COLOR_FX' | 'LAYOUT' | 'BORDERS' | 'TYPOGRAPHY' | 'COPYWRITING' | 'STATE' | 'DENSITY' | 'SPACING' | 'ACCESSIBILITY';
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  ruleName: string;
  description: string;
  snippet?: string;
  recommendedFix: string;
  autoFixAvailable: boolean;
}

export interface InformationArchitectureSpec {
  primaryUserGoal: string;
  primaryAction: {
    label: string;
    description: string;
    prominence: 'prominent' | 'inline' | 'contextual';
  };
  primaryDataPoints: string[];
  secondaryDataPoints: string[];
  progressiveDisclosureElements: string[];
  groupingStrategy: string;
  aboveTheFoldElements: string[];
  layoutStructure: {
    hasNavigation: boolean;
    navigationType: 'top_bar' | 'sidebar' | 'bottom_bar' | 'compact_dock';
    mainContentLayout: 'grid' | 'stack' | 'split' | 'flow';
    hasSecondaryPanel: boolean;
  };
}

export interface UIQualityScoreBreakdown {
  typography: number; // 0 - 100
  spacing: number;    // 0 - 100
  hierarchy: number;  // 0 - 100
  accessibility: number; // 0 - 100
  responsiveness: number; // 0 - 100
  interaction: number; // 0 - 100
  consistency: number; // 0 - 100
}

export interface UIQualityAuditResult {
  timestamp: number;
  overallScore: number; // 0 - 100
  rating: 'PERFECT' | 'EXEMPLARY' | 'PROFESSIONAL' | 'ACCEPTABLE' | 'NEEDS_REFINEMENT';
  breakdown: UIQualityScoreBreakdown;
  violations: AntiUglyViolation[];
  passedInvariants: string[];
  truthfulEvidence: string[];
  designPersonalityApplied: DesignPersonality;
}

export interface DesignSystemMemoryRecord {
  projectId: string;
  category: ProductCategory;
  appliedTokens: Partial<ColorTokens>;
  typographyChoices: { heading: string; body: string };
  preferredRadius: number;
  successfulPatterns: string[];
  lastUpdated: number;
}
