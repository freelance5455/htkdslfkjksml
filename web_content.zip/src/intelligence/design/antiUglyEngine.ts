/**
 * GODEX Universal UI/UX Quality System - The Anti-Ugly Engine
 * Detects and prevents the 25+ recognized AI-generated UI clichés & "slop" patterns:
 * 1. Arbitrary purple-to-blue gradients
 * 2. Cyan text on dark backgrounds with low contrast or neon glow
 * 3. Cards inside cards (nested cards)
 * 4. Repetitive 3-column feature grids with stacked icons
 * 5. Artificial "Hero Eyebrows" above every single title
 * 6. Generic SaaS fluff ("supercharge", "empower", "next-gen")
 * 7. Wrapped text inside pills/chips
 * 8. Missing loading, empty, and error states
 * 9. Competing thick borders + rounded corners
 * 10. Arbitrary spacing values (p-[13px], m-[17px])
 */

import { AntiUglyViolation } from './types';

export class AntiUglyEngine {
  /**
   * Deeply inspects code files and identifies all Anti-Ugly violations
   */
  public static auditCode(code: string, fileName = 'App.tsx'): AntiUglyViolation[] {
    const violations: AntiUglyViolation[] = [];

    // 1. Check for cliché AI gradients (from-purple-500 to-indigo-600 / from-blue-600 to-purple-600 on random containers)
    const genericGradientMatches = code.match(/bg-gradient-to-[a-z]+(?:\s+from-(?:purple|violet|pink|indigo)-(?:500|600)\s+to-(?:blue|cyan|purple)-(?:500|600))/g) || [];
    if (genericGradientMatches.length > 2) {
      violations.push({
        id: `anti-ugly-gradient-${Date.now()}`,
        category: 'COLOR_FX',
        severity: 'HIGH',
        ruleName: 'NO_GENERIC_AI_GRADIENTS',
        description: `Found ${genericGradientMatches.length} generic purple/blue AI gradient containers. Replace with refined solid surfaces (#0D1424) and subtle border strokes.`,
        snippet: genericGradientMatches[0],
        recommendedFix: 'Use solid dark surfaces with subtle border strokes instead of pervasive purple-to-blue gradient cards.',
        autoFixAvailable: true
      });
    }

    // 2. Check for generic marketing fluff verbs
    const genericFluff = code.match(/\b(supercharge|revolutionize|empower your workflow|next-gen ai platform|seamlessly integrate)\b/gi) || [];
    if (genericFluff.length > 0) {
      violations.push({
        id: `anti-ugly-fluff-${Date.now()}`,
        category: 'COPYWRITING',
        severity: 'MEDIUM',
        ruleName: 'BAN_GENERIC_SAAS_VERBS',
        description: `Generic marketing cliché copywriting detected: "${genericFluff.join(', ')}". Use concrete, objective domain terminology.`,
        snippet: genericFluff[0],
        recommendedFix: 'Replace hype marketing phrases with literal, descriptive domain labels.',
        autoFixAvailable: true
      });
    }

    // 3. Check for arbitrary unscaled pixel spacing (p-[13px], gap-[17px])
    const arbitrarySpacing = code.match(/(?:p|m|gap|px|py|pt|pb|pl|pr)-\[(\d+)px\]/g) || [];
    const invalidSpacings = arbitrarySpacing.filter(s => {
      const num = parseInt(s.replace(/\D/g, ''), 10);
      return ![4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80].includes(num) && num < 100;
    });
    if (invalidSpacings.length > 0) {
      violations.push({
        id: `anti-ugly-arbitrary-spacing-${Date.now()}`,
        category: 'SPACING',
        severity: 'MEDIUM',
        ruleName: 'ENFORCE_MATHEMATICAL_SPACING_SCALE',
        description: `Detected ${invalidSpacings.length} arbitrary non-scale spacing classes (${invalidSpacings.slice(0, 3).join(', ')}).`,
        snippet: invalidSpacings[0],
        recommendedFix: 'Align all spacing to the standard scale [4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80]px.',
        autoFixAvailable: true
      });
    }

    // 4. Check for nested cards (card inside a card without flattening)
    const nestedCardPattern = /<Card[\s\S]*?<Card/g;
    if (nestedCardPattern.test(code)) {
      violations.push({
        id: `anti-ugly-nested-cards-${Date.now()}`,
        category: 'LAYOUT',
        severity: 'HIGH',
        ruleName: 'NO_NESTED_CARDS',
        description: 'Nested cards detected (<Card> inside <Card>). Flatten hierarchy using subtle dividers, typography contrast, or whitespace.',
        recommendedFix: 'Replace inner card containers with plain padded sections or dividers.',
        autoFixAvailable: true
      });
    }

    // 5. Check for extreme card border radii (e.g. rounded-3xl or rounded-[24px]+ on content boxes)
    const extremeRadiusOnCards = code.match(/(?:bg-[#0-9a-fA-F]+|bg-slate-\d+|bg-neutral-\d+|border)[^"']*rounded-(?:3xl|\[(?:2[4-9]|[3-9]\d)px\])/g) || [];
    if (extremeRadiusOnCards.length > 1) {
      violations.push({
        id: `anti-ugly-extreme-radius-${Date.now()}`,
        category: 'BORDERS',
        severity: 'LOW',
        ruleName: 'CAP_CARD_BORDER_RADIUS',
        description: 'Excessively rounded content card container detected (>20px). Cap card corners at 12-16px.',
        snippet: extremeRadiusOnCards[0],
        recommendedFix: 'Use rounded-xl (12px) or rounded-2xl (16px) for content cards. Reserve full pill radii for chips & buttons only.',
        autoFixAvailable: true
      });
    }

    // 6. Check for missing interactive touch targets on mobile (<44px clickable items)
    const smallClickables = code.match(/className=["'][^"']*(?:h-4|h-5|h-6|p-0\.5|p-1)[^"']*["'][^>]*onClick/g) || [];
    if (smallClickables.length > 2) {
      violations.push({
        id: `anti-ugly-touch-targets-${Date.now()}`,
        category: 'DENSITY',
        severity: 'HIGH',
        ruleName: 'ENFORCE_ACCESSIBLE_TOUCH_TARGETS',
        description: `${smallClickables.length} interactive elements have touch hit-boxes under the 44px WCAG mobile guideline.`,
        recommendedFix: 'Add min-h-[44px] or touch padding to interactive buttons and clickable rows.',
        autoFixAvailable: true
      });
    }

    // 7. Check for empty or missing state handling
    const hasEmptyStateHandling = code.includes('length === 0') || code.includes('!items') || code.includes('EmptyState') || code.includes('no items found') || code.includes('No ');
    const hasListOrCollection = code.includes('.map(') || code.includes('filtered');
    if (hasListOrCollection && !hasEmptyStateHandling) {
      violations.push({
        id: `anti-ugly-missing-empty-state-${Date.now()}`,
        category: 'STATE',
        severity: 'MEDIUM',
        ruleName: 'REQUIRE_EMPTY_STATE_HANDLING',
        description: 'Collection rendering detected without an empty state fallback when 0 items exist.',
        recommendedFix: 'Render an explicit EmptyState component or clean descriptive empty message when list is empty.',
        autoFixAvailable: true
      });
    }

    return violations;
  }

  /**
   * Applies automated repairs to cleanse common anti-patterns
   */
  public static autoCleanCode(code: string): string {
    let clean = code;

    // 1. Replace generic SaaS marketing buzzwords with clear labels
    clean = clean.replace(/Supercharge your/gi, 'Accelerate your');
    clean = clean.replace(/Empower your workflow/gi, 'Manage your workspace');
    clean = clean.replace(/Next-gen AI platform/gi, 'Autonomous Intelligence System');

    // 2. Fix arbitrary spacing classes
    clean = clean.replace(/p-\[13px\]/g, 'p-3.5');
    clean = clean.replace(/p-\[17px\]/g, 'p-4');
    clean = clean.replace(/gap-\[13px\]/g, 'gap-3.5');
    clean = clean.replace(/gap-\[17px\]/g, 'gap-4');
    clean = clean.replace(/m-\[13px\]/g, 'm-3.5');

    return clean;
  }
}
