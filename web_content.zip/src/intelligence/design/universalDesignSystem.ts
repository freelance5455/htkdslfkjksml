/**
 * GODEX Universal UI/UX Quality System - Master Facade
 * Provides single-point entry to token compilation, personality inference,
 * anti-ugly verification, accessibility gating, and visual quality scores.
 */

import { ProductCategory, DesignPersonality, ColorTokens, UIQualityAuditResult } from './types';
import { DesignPersonalityInferer } from './designPersonality';
import { DesignTokenCompiler } from './tokenCompiler';
import { TypographyEngine } from './typographyEngine';
import { SpacingEngine } from './spacingEngine';
import { AntiUglyEngine } from './antiUglyEngine';
import { ResponsiveEngine } from './responsiveEngine';
import { UIStatesEngine } from './uiStatesEngine';
import { MotionIntelligence } from './motionIntelligence';
import { AccessibilityGate } from './accessibilityGate';
import { VisualQualityGate } from './visualQualityGate';
import { AppDesignCompiler, AppDesignCompilationResult } from './appDesignCompiler';

export class UniversalDesignSystem {
  public static inferCategory(prompt: string, filePaths: string[] = []): ProductCategory {
    return DesignPersonalityInferer.inferCategory(prompt, filePaths);
  }

  public static getPersonality(category: ProductCategory, prompt = ''): DesignPersonality {
    return DesignPersonalityInferer.getPersonality(category, prompt);
  }

  public static compileTokens(personality: DesignPersonality): ColorTokens {
    return DesignTokenCompiler.compileTokens(personality);
  }

  public static auditWorkspace(
    files: Record<string, string>,
    prompt = ''
  ): UIQualityAuditResult {
    const category = DesignPersonalityInferer.inferCategory(prompt, Object.keys(files));
    const personality = DesignPersonalityInferer.getPersonality(category, prompt);
    return VisualQualityGate.auditWorkspace(files, personality);
  }

  public static compileForApp(
    prompt: string,
    existingFiles: Record<string, string> = {}
  ): AppDesignCompilationResult {
    return AppDesignCompiler.compile({
      prompt,
      existingFiles
    });
  }

  public static cleanCode(code: string): string {
    return AntiUglyEngine.autoCleanCode(code);
  }
}
