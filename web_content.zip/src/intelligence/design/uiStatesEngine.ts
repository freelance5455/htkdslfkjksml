/**
 * GODEX Universal UI/UX Quality System - UI States Engine
 * Verifies and provides state matrices for all user interaction flows:
 * DEFAULT, HOVER, FOCUS, ACTIVE, DISABLED, LOADING, SUCCESS, ERROR, EMPTY, OFFLINE, RETRY.
 */

import { UIState } from './types';

export class UIStatesEngine {
  /**
   * Evaluates if a generated component or app implements proper state coverage
   */
  public static auditStateCoverage(code: string): {
    score: number; // 0 - 100
    missingStates: UIState[];
    presentStates: UIState[];
    details: string[];
  } {
    const present: UIState[] = ['DEFAULT'];
    const missing: UIState[] = [];
    const details: string[] = [];

    // Hover state check
    if (code.includes('hover:')) {
      present.push('HOVER');
    } else {
      missing.push('HOVER');
      details.push('Missing interactive hover styling classes (hover:bg-*, hover:text-*).');
    }

    // Focus state check
    if (code.includes('focus:') || code.includes('focus-visible:')) {
      present.push('FOCUS');
    } else {
      missing.push('FOCUS');
      details.push('Missing keyboard focus states (focus-visible:ring-2).');
    }

    // Active state check
    if (code.includes('active:')) {
      present.push('ACTIVE');
    } else {
      missing.push('ACTIVE');
    }

    // Disabled state check
    if (code.includes('disabled:') || code.includes('disabled={')) {
      present.push('DISABLED');
    } else {
      missing.push('DISABLED');
    }

    // Loading state check
    if (code.includes('isLoading') || code.includes('loading') || code.includes('Skeleton') || code.includes('animate-spin')) {
      present.push('LOADING');
    } else {
      missing.push('LOADING');
      details.push('No loading indicators, skeletons, or spin states detected for asynchronous flows.');
    }

    // Empty state check
    if (code.includes('EmptyState') || code.includes('.length === 0') || code.includes('!items') || code.includes('No items')) {
      present.push('EMPTY');
    } else {
      missing.push('EMPTY');
      details.push('No empty state handler detected for empty collections or zero-search results.');
    }

    // Error state check
    if (code.includes('error') || code.includes('ErrorState') || code.includes('AlertCircle') || code.includes('AlertTriangle')) {
      present.push('ERROR');
    } else {
      missing.push('ERROR');
    }

    const totalAudited = 7;
    const coveredCount = present.length - 1; // exclude default
    const score = Math.round((coveredCount / totalAudited) * 100);

    return {
      score,
      missingStates: missing,
      presentStates: present,
      details
    };
  }
}
