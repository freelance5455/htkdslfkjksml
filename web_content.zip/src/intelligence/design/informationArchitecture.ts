/**
 * GODEX Universal UI/UX Quality System - Information Architecture Engine
 * Deconstructs prompt requirements into purpose-driven layout hierarchies:
 * Primary Goal, Primary Action, Essential Data, Progressive Disclosure, and Layout Topology.
 */

import { ProductCategory, InformationArchitectureSpec } from './types';

export class InformationArchitectureEngine {
  public static planLayout(
    prompt: string,
    category: ProductCategory
  ): InformationArchitectureSpec {
    const p = prompt.toLowerCase();

    // Check if simple single-screen utility (e.g. calculator, profile card, stopwatch)
    const isSingleScreen = 
      p.includes('profile card') || 
      p.includes('calculator') || 
      p.includes('stopwatch') || 
      p.includes('timer') || 
      p.includes('counter') ||
      p.includes('hello world');

    if (isSingleScreen) {
      return {
        primaryUserGoal: 'Focused single-purpose interaction',
        primaryAction: {
          label: 'Interact / Submit',
          description: 'Direct primary execution on central card surface',
          prominence: 'prominent'
        },
        primaryDataPoints: ['Core active state', 'Direct feedback value'],
        secondaryDataPoints: ['Status pill', 'Interaction counters'],
        progressiveDisclosureElements: [],
        groupingStrategy: 'Single centered container with balanced negative space',
        aboveTheFoldElements: ['Main interactive card', 'Status indicator'],
        layoutStructure: {
          hasNavigation: false,
          navigationType: 'compact_dock',
          mainContentLayout: 'flow',
          hasSecondaryPanel: false
        }
      };
    }

    // Determine layout structure based on product category
    switch (category) {
      case 'devtools':
      case 'productivity':
        return {
          primaryUserGoal: 'Manage tasks, code, or technical assets with high efficiency',
          primaryAction: {
            label: category === 'productivity' ? 'New Task' : 'Execute Command',
            description: 'Top-right prominent call-to-action button',
            prominence: 'prominent'
          },
          primaryDataPoints: ['Active status columns', 'Task counts', 'Critical alerts'],
          secondaryDataPoints: ['Subtask details', 'Activity logs', 'Assignee metadata'],
          progressiveDisclosureElements: ['Modal drawer for task creation/editing', 'Collapsible subtasks'],
          groupingStrategy: 'Horizontal workflow columns (Kanban) or dual-pane editor',
          aboveTheFoldElements: ['Header controls', 'Search & Filter bar', 'Main board/viewport'],
          layoutStructure: {
            hasNavigation: true,
            navigationType: 'sidebar',
            mainContentLayout: 'split',
            hasSecondaryPanel: true
          }
        };

      case 'creative':
        return {
          primaryUserGoal: 'Inspect, manipulate, and preview visual media or audio canvas',
          primaryAction: {
            label: 'Render / Export',
            description: 'Primary toolbar action in canvas header',
            prominence: 'prominent'
          },
          primaryDataPoints: ['Active canvas timeline', 'Keyframe track', 'Inspector properties'],
          secondaryDataPoints: ['Layer properties', 'Media asset library', 'Effects stack'],
          progressiveDisclosureElements: ['Collapsible right-side inspector', 'Floating floating playback dock'],
          groupingStrategy: 'Central large viewport framed by left asset dock and right inspector',
          aboveTheFoldElements: ['Canvas viewport', 'Playback transport bar', 'Timeline'],
          layoutStructure: {
            hasNavigation: true,
            navigationType: 'compact_dock',
            mainContentLayout: 'grid',
            hasSecondaryPanel: true
          }
        };

      case 'finance':
        return {
          primaryUserGoal: 'Monitor portfolio balance, cashflow, and transaction history',
          primaryAction: {
            label: 'Transfer / Deposit',
            description: 'Top-level action in account header',
            prominence: 'prominent'
          },
          primaryDataPoints: ['Net Portfolio Worth', '24h Delta / PnL', 'Recent Transactions'],
          secondaryDataPoints: ['Asset distribution pie/bar', 'Historical trend chart', 'Fee breakdown'],
          progressiveDisclosureElements: ['Transaction details drawer', 'Date range selector modal'],
          groupingStrategy: 'Top balance summary metrics -> mid-level trend visualizer -> bottom ledger table',
          aboveTheFoldElements: ['Key financial metrics', 'Performance chart', 'Recent transaction list'],
          layoutStructure: {
            hasNavigation: true,
            navigationType: 'top_bar',
            mainContentLayout: 'stack',
            hasSecondaryPanel: false
          }
        };

      case 'saas':
      default:
        return {
          primaryUserGoal: 'Monitor operational health and manage business entities',
          primaryAction: {
            label: 'Create Resource',
            description: 'Header action button',
            prominence: 'prominent'
          },
          primaryDataPoints: ['Key Operational KPIs', 'Live Status Stream', 'Entity Ledger'],
          secondaryDataPoints: ['Detailed breakdown charts', 'Historical log stream', 'Audit trail'],
          progressiveDisclosureElements: ['Filter dropdowns', 'Row expansion', 'Entity detail modal'],
          groupingStrategy: 'Executive KPI row -> Visual telemetry -> Filterable entity table',
          aboveTheFoldElements: ['KPI metrics', 'Realtime activity preview'],
          layoutStructure: {
            hasNavigation: true,
            navigationType: 'sidebar',
            mainContentLayout: 'grid',
            hasSecondaryPanel: false
          }
        };
    }
  }
}
