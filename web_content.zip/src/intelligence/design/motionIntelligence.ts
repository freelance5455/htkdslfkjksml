/**
 * GODEX Universal UI/UX Quality System - Motion Intelligence
 * Governs purposeful, restrained animation: micro-interactions, entrance transitions,
 * active state feedback, and prefers-reduced-motion safety.
 */

export class MotionIntelligence {
  /**
   * Evaluates motion and animation patterns in code
   */
  public static auditMotion(code: string): {
    score: number;
    issues: string[];
    passes: string[];
  } {
    const issues: string[] = [];
    const passes: string[] = [];

    // Check for smooth CSS transition utility usage
    if (code.includes('transition-all') || code.includes('transition-colors') || code.includes('transition-transform')) {
      passes.push('Interactive elements utilize smooth transition durations.');
    } else {
      issues.push('Missing CSS transition classes on interactive elements for smooth hover/active feedback.');
    }

    // Check for excessive, continuous spinning or floating animations (potential distraction)
    const floatOrInfiniteMatches = code.match(/animate-(?:bounce|pulse|spin)/g) || [];
    if (floatOrInfiniteMatches.length > 5) {
      issues.push(`Detected ${floatOrInfiniteMatches.length} continuous CSS animations. Cap continuous animations to active loaders and status dots.`);
    } else {
      passes.push('Continuous animations are restrained to micro-status indicators.');
    }

    // Check active scale feedback
    if (code.includes('active:scale-') || code.includes('active:scale-95') || code.includes('active:scale-[0.98]')) {
      passes.push('Interactive buttons implement tactile active-scale tactile response.');
    }

    const score = issues.length === 0 ? 100 : Math.max(50, 100 - issues.length * 20);

    return {
      score,
      issues,
      passes
    };
  }
}
