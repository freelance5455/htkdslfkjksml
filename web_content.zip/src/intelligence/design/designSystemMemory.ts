/**
 * GODEX Universal UI/UX Quality System - Design System Memory
 * Caches and persists successful design tokens, typography pairings,
 * preferred corner radii, and component patterns per project.
 */

import { DesignSystemMemoryRecord, ProductCategory, ColorTokens } from './types';

export class DesignSystemMemory {
  private static instance: DesignSystemMemory;
  private memoryStore: Map<string, DesignSystemMemoryRecord> = new Map();

  private constructor() {}

  public static getInstance(): DesignSystemMemory {
    if (!DesignSystemMemory.instance) {
      DesignSystemMemory.instance = new DesignSystemMemory();
    }
    return DesignSystemMemory.instance;
  }

  public recordDecision(
    projectId: string,
    category: ProductCategory,
    tokens: Partial<ColorTokens>,
    radius: number,
    pattern: string
  ): void {
    const existing = this.memoryStore.get(projectId) || {
      projectId,
      category,
      appliedTokens: {},
      typographyChoices: { heading: 'system-ui', body: 'system-ui' },
      preferredRadius: radius,
      successfulPatterns: [],
      lastUpdated: Date.now()
    };

    existing.appliedTokens = { ...existing.appliedTokens, ...tokens };
    existing.preferredRadius = radius;
    if (!existing.successfulPatterns.includes(pattern)) {
      existing.successfulPatterns.push(pattern);
    }
    existing.lastUpdated = Date.now();

    this.memoryStore.set(projectId, existing);
  }

  public getDecision(projectId: string): DesignSystemMemoryRecord | undefined {
    return this.memoryStore.get(projectId);
  }
}
