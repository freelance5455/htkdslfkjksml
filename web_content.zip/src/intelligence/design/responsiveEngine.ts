/**
 * GODEX Universal UI/UX Quality System - Responsive Design Engine
 * Evaluates and enforces multi-viewport layout reflow across:
 * - Mobile (390px)
 * - Tablet (768px)
 * - Desktop (1280px)
 * - Large Desktop (1536px)
 */

export class ResponsiveEngine {
  /**
   * Scans TSX code for responsive layout defects:
   * 1. Hardcoded non-responsive multi-column grids (e.g. `grid-cols-4` without `sm:grid-cols-2 lg:grid-cols-4`)
   * 2. Unresponsive fixed width containers (`w-[600px]`)
   * 3. Missing mobile drawer/menu toggle for desktop sidebars
   * 4. Missing min-h-[44px] touch target padding on mobile buttons
   */
  public static validateResponsiveness(code: string): {
    valid: boolean;
    issues: string[];
    recommendations: string[];
  } {
    const issues: string[] = [];
    const recommendations: string[] = [];

    // 1. Check for un-breakpoint-prefixed grid columns (e.g. `grid-cols-3` or `grid-cols-4` without `sm:` or `md:`)
    const unResponsiveGridMatches = code.match(/className=["'][^"']*\bgrid-cols-(?:3|4|5|6)\b[^"']*["']/g) || [];
    const rigidGrids = unResponsiveGridMatches.filter(m => !m.includes('sm:') && !m.includes('md:') && !m.includes('lg:'));
    if (rigidGrids.length > 0) {
      issues.push(`Found ${rigidGrids.length} grid layouts lacking mobile breakpoint reflow (e.g. 'grid-cols-4' without 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4').`);
      recommendations.push('Prefix multi-column grids with mobile single-column baseline: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4".');
    }

    // 2. Check for rigid fixed widths > 390px
    const fixedWidthMatches = code.match(/w-\[(\d{3,4})px\]/g) || [];
    for (const match of fixedWidthMatches) {
      const px = parseInt(match.replace(/\D/g, ''), 10);
      if (px > 380) {
        issues.push(`Hardcoded fixed width (${px}px) exceeds mobile viewport width (390px).`);
        recommendations.push(`Replace "${match}" with "w-full max-w-[${px}px]".`);
      }
    }

    // 3. Check for desktop-only sidebar without mobile hamburger/drawer handling
    const hasSidebar = code.includes('<aside') || code.includes('w-64') || code.includes('w-72');
    const hasMobileToggle = code.includes('mobileMenu') || code.includes('mobileNav') || code.includes('setMobileMenuOpen') || code.includes('hidden md:flex') || code.includes('hidden lg:flex');
    if (hasSidebar && !hasMobileToggle) {
      issues.push('Sidebar component present without mobile drawer/collapse toggle handling.');
      recommendations.push('Add "hidden md:flex" to aside and provide a mobile drawer menu bar with a toggle button.');
    }

    return {
      valid: issues.length === 0,
      issues,
      recommendations
    };
  }
}
