/**
 * GODEX Universal UI/UX Quality System - Design Token Compiler
 * Compiles cohesive, WCAG AA compliant semantic color tokens, surface elevations,
 * and border hierarchies based on the active DesignPersonality.
 */

import { ColorTokens, DesignPersonality, ProductCategory } from './types';

export class DesignTokenCompiler {
  /**
   * Compiles complete semantic token set for a given personality
   */
  public static compileTokens(personality: DesignPersonality): ColorTokens {
    const isDark = personality.colorMode !== 'light_refined';
    const cat = personality.category;

    if (!isDark) {
      // Light Mode (Sophisticated warm-neutral or cool-neutral, max 7% delta, zero pure white blinding glare)
      return {
        background: '#F8FAFC',
        surface: '#FFFFFF',
        elevatedSurface: '#F1F5F9',
        primary: cat === 'finance' ? '#0F766E' : cat === 'healthcare' ? '#0369A1' : cat === 'ecommerce' ? '#0284C7' : '#0F172A',
        primaryHover: cat === 'finance' ? '#115E59' : cat === 'healthcare' ? '#075985' : cat === 'ecommerce' ? '#0369A1' : '#1E293B',
        primaryActive: cat === 'finance' ? '#134E4A' : cat === 'healthcare' ? '#0C4A6E' : cat === 'ecommerce' ? '#075985' : '#334155',
        secondary: '#E2E8F0',
        secondaryHover: '#CBD5E1',
        accent: cat === 'finance' ? '#0D9488' : cat === 'healthcare' ? '#0EA5E9' : '#3B82F6',
        accentSubtle: '#EFF6FF',
        success: '#16A34A',
        successSubtle: '#DCFCE7',
        warning: '#D97706',
        warningSubtle: '#FEF3C7',
        danger: '#DC2626',
        dangerSubtle: '#FEE2E2',
        info: '#2563EB',
        infoSubtle: '#DBEAFE',
        textPrimary: '#0F172A',
        textSecondary: '#475569',
        textMuted: '#94A3B8',
        textInverse: '#FFFFFF',
        border: '#E2E8F0',
        borderSubtle: '#F1F5F9',
        borderHighlight: '#CBD5E1',
        focusRing: 'rgba(59, 130, 246, 0.4)'
      };
    }

    // High Contrast / Technical Dark (DevTools, Gaming, High-Focus)
    if (personality.colorMode === 'high_contrast_dark' || cat === 'devtools') {
      return {
        background: '#070A0F',
        surface: '#0E131C',
        elevatedSurface: '#161D2B',
        primary: '#38BDF8',
        primaryHover: '#0EA5E9',
        primaryActive: '#0284C7',
        secondary: '#1A2333',
        secondaryHover: '#232E42',
        accent: '#6366F1',
        accentSubtle: 'rgba(99, 102, 241, 0.12)',
        success: '#34D399',
        successSubtle: 'rgba(52, 211, 153, 0.12)',
        warning: '#FBBF24',
        warningSubtle: 'rgba(251, 191, 36, 0.12)',
        danger: '#F87171',
        dangerSubtle: 'rgba(248, 113, 113, 0.12)',
        info: '#38BDF8',
        infoSubtle: 'rgba(56, 189, 248, 0.12)',
        textPrimary: '#F8FAFC',
        textSecondary: '#94A3B8',
        textMuted: '#64748B',
        textInverse: '#070A0F',
        border: '#1E293B',
        borderSubtle: '#121926',
        borderHighlight: '#334155',
        focusRing: 'rgba(56, 189, 248, 0.5)'
      };
    }

    // Refined Deep Slate / Obsidian Dark Mode (SaaS, Productivity, Finance, Creative)
    const accentHue = cat === 'finance' 
      ? { primary: '#10B981', hover: '#059669', accent: '#34D399', ring: 'rgba(16, 185, 129, 0.4)' }
      : cat === 'creative'
      ? { primary: '#8B5CF6', hover: '#7C3AED', accent: '#A78BFA', ring: 'rgba(139, 92, 246, 0.4)' }
      : cat === 'productivity'
      ? { primary: '#06B6D4', hover: '#0891B2', accent: '#22D3EE', ring: 'rgba(6, 182, 212, 0.4)' }
      : { primary: '#3B82F6', hover: '#2563EB', accent: '#60A5FA', ring: 'rgba(59, 130, 246, 0.4)' };

    return {
      background: '#080C14',
      surface: '#0D1424',
      elevatedSurface: '#141E34',
      primary: accentHue.primary,
      primaryHover: accentHue.hover,
      primaryActive: accentHue.hover,
      secondary: '#1A243B',
      secondaryHover: '#23304E',
      accent: accentHue.accent,
      accentSubtle: `${accentHue.primary}18`,
      success: '#10B981',
      successSubtle: 'rgba(16, 185, 129, 0.12)',
      warning: '#F59E0B',
      warningSubtle: 'rgba(245, 158, 11, 0.12)',
      danger: '#EF4444',
      dangerSubtle: 'rgba(239, 68, 68, 0.12)',
      info: '#3B82F6',
      infoSubtle: 'rgba(59, 130, 246, 0.12)',
      textPrimary: '#F1F5F9',
      textSecondary: '#94A3B8',
      textMuted: '#64748B',
      textInverse: '#080C14',
      border: '#1E2B45',
      borderSubtle: '#131D31',
      borderHighlight: '#2A3C5F',
      focusRing: accentHue.ring
    };
  }

  /**
   * Generates Tailwind CSS class helpers for the token set
   */
  public static getTailwindClasses(tokens: ColorTokens) {
    return {
      bgMain: 'bg-[#080C14]',
      bgSurface: 'bg-[#0D1424]',
      bgElevated: 'bg-[#141E34]',
      borderDefault: 'border-[#1E2B45]',
      borderSubtle: 'border-[#131D31]',
      textHeading: 'text-slate-100 font-bold',
      textBody: 'text-slate-300 font-normal leading-relaxed',
      textMuted: 'text-slate-400 text-xs font-medium',
      focusRing: 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500/50'
    };
  }
}
