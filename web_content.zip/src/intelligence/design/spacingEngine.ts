/**
 * GODEX Universal UI/UX Quality System - Spacing Engine
 * Mathematical optical spacing system (4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80),
 * 2:1 button padding ratio, nested border radius calculations, and anti-arbitrary spacing audit.
 */

import { SpacingScale, DesignPersonality } from './types';

export class SpacingEngine {
  public static readonly SCALE: number[] = [4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80];

  public static getScaleSpec(personality: DesignPersonality): SpacingScale {
    return {
      scale: SpacingEngine.SCALE,
      unit: 'px',
      buttonPaddingRatio: 2.0,
      minContainerPaddingPx: personality.densityPreference === 'compact' ? 12 : 16,
      nestedRadiusFormula: (outerRadius: number, padding: number): number => {
        return Math.max(0, outerRadius - padding);
      }
    };
  }

  /**
   * Mathematically computes the exact inner border-radius for nested containers
   */
  public static calculateInnerRadius(outerRadiusPx: number, paddingPx: number): number {
    return Math.max(0, outerRadiusPx - paddingPx);
  }

  /**
   * Validates spacing patterns in code (flags arbitrary px values like p-[13px] or m-[17px])
   */
  public static validateSpacing(code: string): { valid: boolean; issues: string[] } {
    const issues: string[] = [];

    // Check for arbitrary un-scaled pixel classes
    const arbitraryMatches = code.match(/(?:p|m|gap|px|py|pt|pb|pl|pr)-\[(\d+)px\]/g) || [];
    for (const match of arbitraryMatches) {
      const numMatch = match.match(/\[(\d+)px\]/);
      if (numMatch) {
        const val = parseInt(numMatch[1], 10);
        if (!SpacingEngine.SCALE.includes(val) && val < 100) {
          issues.push(`Arbitrary spacing detected: "${match}". Replace with standard scale (${SpacingEngine.SCALE.join(', ')}px).`);
        }
      }
    }

    return {
      valid: issues.length === 0,
      issues
    };
  }
}
