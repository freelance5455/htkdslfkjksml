/**
 * GODEX Autonomous Visual Engineering Loop - Runtime Failure & Healing Types
 */

import { VerificationClaimStatus } from '../types';

export type RepairLifecycleState =
  | 'IDLE'
  | 'DETECTED'
  | 'CONTEXT_CAPTURED'
  | 'SOURCE_LOCATED'
  | 'HYPOTHESIS_CREATED'
  | 'PATCH_PROPOSED'
  | 'PATCH_APPROVED'
  | 'PATCH_APPLIED'
  | 'TYPECHECKING'
  | 'BUILDING'
  | 'REPRODUCING'
  | 'REGRESSION_CHECK'
  | 'VERIFIED'
  | 'ROLLBACK_REQUIRED'
  | 'ROLLED_BACK'
  | 'NOT_VERIFIED';

export interface RuntimeExceptionCapture {
  id: string;
  timestamp: number;
  message: string;
  stack?: string;
  componentStack?: string;
  sourceFile?: string;
  sourceLine?: number;
  sourceColumn?: number;
  componentName?: string;
  consoleErrors: string[];
  domSnapshotSnippet?: string;
  activeRoute?: string;
  viewport: { width: number; height: number };
  workspaceFingerprint: string;
}

export interface DiagnosticHypothesis {
  id: string;
  rank: number;
  confidence: number; // 0 - 100
  title: string;
  explanation: string;
  suspectedSymbol?: string;
  suspectedFile: string;
  suspectedLine?: number;
  suggestedFixStrategy: string;
}

export interface SafePatchProposal {
  id: string;
  hypothesisId: string;
  targetFile: string;
  originalContent: string;
  patchedContent: string;
  unifiedDiff: string;
  additions: number;
  deletions: number;
  blastRadius: {
    affectedFiles: string[];
    affectedSymbols: string[];
    riskScore: number; // 0 - 100
  };
  attemptNumber: number;
}

export interface RepairAttemptRecord {
  attemptNumber: number;
  timestamp: number;
  state: RepairLifecycleState;
  hypothesis: DiagnosticHypothesis;
  patch: SafePatchProposal;
  checkpointId?: string;
  typecheckPassed: boolean;
  buildPassed: boolean;
  reproductionPassed: boolean; // True if error disappeared
  regressionPassed: boolean;
  verified: boolean;
  rollbackOccurred: boolean;
  failureReason?: string;
}

export interface FailureReplayRecord {
  id: string;
  exception: RuntimeExceptionCapture;
  reproductionSteps: string[];
  reproducible: boolean;
  lastReplayedAt?: number;
  status: 'REPRODUCED' | 'FIXED' | 'UNREPRODUCED';
}

export interface VisualElementInspection {
  elementId?: string;
  tagName: string;
  className: string;
  idAttr?: string;
  textContentSnippet: string;
  componentName?: string;
  sourceFile?: string;
  sourceLine?: number;
  computedStyles: {
    width: number;
    height: number;
    padding: { top: number; right: number; bottom: number; left: number };
    margin: { top: number; right: number; bottom: number; left: number };
    fontSize: string;
    fontWeight: string;
    lineHeight: string;
    letterSpacing: string;
    color: string;
    backgroundColor: string;
    borderRadius: string;
    border: string;
    boxShadow: string;
    opacity: string;
    display: string;
    flexDirection?: string;
    justifyContent?: string;
    alignItems?: string;
    gap?: string;
  };
  accessibility: {
    role?: string;
    ariaLabel?: string;
    isInteractive: boolean;
    hasAccessibleName: boolean;
    contrastRatio?: number;
  };
  hierarchy: {
    parentTag?: string;
    parentComponent?: string;
    childrenCount: number;
    depth: number;
  };
}

export interface VisualRegressionResult {
  viewport: 'mobile' | 'tablet' | 'desktop';
  dimensions: { width: number; height: number };
  passed: boolean;
  status: 'VISUAL_REGRESSION_PASS' | 'VISUAL_REGRESSION_FAILED';
  hasHorizontalOverflow: boolean;
  hasClipping: boolean;
  hasLayoutShift: boolean;
  shiftedElementsCount: number;
  details: string[];
}

export interface VisualRegressionReport {
  timestamp: number;
  overallStatus: 'VISUAL_REGRESSION_PASS' | 'VISUAL_REGRESSION_FAILED';
  passed: boolean;
  viewports: {
    mobile: VisualRegressionResult;
    tablet: VisualRegressionResult;
    desktop: VisualRegressionResult;
  };
  summary: string;
}

export interface FuzzAction {
  id: string;
  stepNumber: number;
  type: 'click' | 'input' | 'clear' | 'submit' | 'tab_switch' | 'toggle' | 'viewport_resize' | 'rapid_click';
  targetSelector: string;
  targetDescription: string;
  value?: string;
  timestamp: number;
}

export interface FuzzCaseResult {
  caseId: string; // e.g. FUZZ_CASE_001
  timestamp: number;
  title: string;
  actions: FuzzAction[];
  detectedIssue: 'NONE' | 'RUNTIME_EXCEPTION' | 'DEAD_BUTTON' | 'BROKEN_FORM' | 'HORIZONTAL_OVERFLOW' | 'CONSOLE_ERROR';
  details: string;
  isReproducible: boolean;
  stackSnippet?: string;
}

export interface AutonomousLoopDossier {
  operationId: string;
  timestamp: number;
  initialException?: RuntimeExceptionCapture;
  attempts: RepairAttemptRecord[];
  totalAttempts: number;
  maxAttemptsAllowed: number;
  finalState: RepairLifecycleState;
  visualRegressionReport?: VisualRegressionReport;
  fuzzResults: FuzzCaseResult[];
  whatChanged: {
    files: string[];
    unifiedDiff: string;
    linesAdded: number;
    linesDeleted: number;
  };
  whatWasTested: string[];
  whatPassed: string[];
  whatFailed: string[];
  whatCouldNotBeVerified: string[];
  isCertifiable: boolean;
}
