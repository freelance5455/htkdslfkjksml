/**
 * GODEX Engineering Oracle
 * Evidence-based architectural reasoning and predictive engineering layer.
 * Strictly distinguishes OBSERVED FACT, DERIVED INFERENCE, PREDICTION, HYPOTHESIS, and UNKNOWN.
 * Performs zero workspace mutations.
 */

import { DigitalTwinSnapshot, ProjectDigitalTwin } from './digitalTwin';
import { SoftwareEvolutionEngine, EvolutionEngineReport, EvolutionConfidence } from './softwareEvolutionEngine';
import { CounterfactualEngineer, CounterfactualOption } from './counterfactualEngineer';
import { MutationFirewall } from '../services/mutationFirewall';
import { RealityRecord } from './realityGapDetector';

export type TimeHorizon = 'IMMEDIATE' | 'SHORT_TERM' | 'MEDIUM_TERM' | 'LONG_TERM';
export type EvidenceType = 'OBSERVED' | 'DERIVED' | 'PREDICTED' | 'UNKNOWN';

export interface OracleObservation {
  fact: string;
  type: EvidenceType;
  source: string;
}

export interface OraclePrediction {
  id: string;
  prediction: string;
  confidence: EvolutionConfidence;
  supportingEvidence: string[];
  counterEvidence: string[];
  affectedArea: string;
  timeHorizon: TimeHorizon;
}

export interface OracleRisk {
  id: string;
  title: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  description: string;
  affectedFiles: string[];
  evidence: string[];
  confidence: EvolutionConfidence;
}

export interface OracleOpportunity {
  id: string;
  title: string;
  impact: 'LOW' | 'MEDIUM' | 'HIGH';
  description: string;
  preventionBenefit: string;
}

export interface OracleRecommendation {
  id: string;
  title: string;
  priority: 'URGENT' | 'HIGH' | 'MEDIUM' | 'LOW';
  action: string;
  rationale: string;
  expandableEvidence: string[];
  preventiveOptions?: Array<{
    title: string;
    strategy: string;
    impact: string;
    risk: string;
  }>;
}

export interface EngineeringOracleResult {
  question?: string;
  observations: OracleObservation[];
  predictions: OraclePrediction[];
  risks: OracleRisk[];
  opportunities: OracleOpportunity[];
  recommendations: OracleRecommendation[];
  whatNotToChange: Array<{
    module: string;
    reason: string;
    stabilityScore: number;
    evidence: string[];
  }>;
  counterEvidence: string[];
  confidence: EvolutionConfidence;
  evidence: string[];
  unknowns: string[];
  generatedAt: number;
  digitalTwinFingerprint: string;
  isStale: boolean;
  status: 'OPTIMAL' | 'DEGRADED' | 'DIGITAL_TWIN_STALE';
  formattedAnswer?: string;
}

export class EngineeringOracle {
  private static instance: EngineeringOracle | null = null;
  private cachedReport: EvolutionEngineReport | null = null;
  private cachedFingerprint = '';

  public static getInstance(): EngineeringOracle {
    if (!EngineeringOracle.instance) {
      EngineeringOracle.instance = new EngineeringOracle();
    }
    return EngineeringOracle.instance;
  }

  /**
   * Sanitizes text to prevent accidental exposure of API keys or credentials in Oracle outputs.
   */
  public static redactSecrets(text: string): string {
    if (!text) return '';
    return text
      .replace(/(?:AIza[0-9A-Za-z-_]{35})/g, '[REDACTED_API_KEY]')
      .replace(/(?:sk-[a-zA-Z0-9]{32,})/g, '[REDACTED_SECRET_KEY]')
      .replace(/(?:Bearer\s+[a-zA-Z0-9._-]{20,})/gi, 'Bearer [REDACTED_TOKEN]')
      .replace(/(?:process\.env\.[A-Z0-9_]+)/g, '[REDACTED_ENV_VAR]');
  }

  /**
   * Performs an authoritative query or holistic assessment of the project state.
   */
  public query(
    userQuestion: string,
    workspaceFiles: Record<string, string>,
    digitalTwinSnapshot?: DigitalTwinSnapshot,
    realityRecords: RealityRecord[] = []
  ): EngineeringOracleResult {
    // 1. Mutation Firewall Strict Assertion: Oracle queries are strictly READ_ONLY
    const firewall = MutationFirewall.getInstance();
    const firewallDecision = firewall.evaluateRequest(userQuestion || 'What is becoming risky?', 'READ_ONLY_ENGINEERING_QUERY');
    const writeCheck = firewall.assertPermission('writeFile', firewallDecision);
    if (writeCheck.allowed) {
      // Ensure firewall is locked down
      firewallDecision.isMutationPermitted = false;
    }

    // 2. Validate DigitalTwin Fingerprint
    const currentFingerprint = ProjectDigitalTwin.computeFingerprint(workspaceFiles);
    let twin = digitalTwinSnapshot;

    if (!twin) {
      // If no snapshot provided, generate fresh snapshot
      twin = ProjectDigitalTwin.createSnapshot(workspaceFiles);
    }

    // Check if snapshot is stale
    const isStale = twin.workspaceFingerprint !== currentFingerprint;
    if (isStale) {
      return {
        question: userQuestion,
        observations: [
          { fact: `Workspace fingerprint mismatch: snapshot (${twin.workspaceFingerprint}) vs current (${currentFingerprint})`, type: 'OBSERVED', source: 'DigitalTwin' }
        ],
        predictions: [],
        risks: [{
          id: 'risk-stale-twin',
          title: 'Digital Twin Stale',
          severity: 'HIGH',
          description: 'Workspace modified since snapshot. Stale architecture prevents confident prediction.',
          affectedFiles: [],
          evidence: ['Snapshot hash differs from current workspace content hash'],
          confidence: 'HIGH'
        }],
        opportunities: [],
        recommendations: [{
          id: 'rec-refresh-snapshot',
          title: 'Refresh Digital Twin Snapshot',
          priority: 'URGENT',
          action: 'Re-index AST and project dependency graph before consulting Oracle.',
          rationale: 'Predictions must only be derived from active, validated workspace mirrors.',
          expandableEvidence: ['Stale state detected']
        }],
        whatNotToChange: [],
        counterEvidence: [],
        confidence: 'VERY_LOW',
        evidence: ['Digital Twin stale validation failed'],
        unknowns: ['Current unindexed workspace AST state'],
        generatedAt: Date.now(),
        digitalTwinFingerprint: twin.workspaceFingerprint,
        isStale: true,
        status: 'DIGITAL_TWIN_STALE',
        formattedAnswer: 'Digital Twin snapshot is stale. Please refresh workspace analysis before querying the Oracle.'
      };
    }

    // 3. Obtain Software Evolution Engine Report
    const evolutionEngine = SoftwareEvolutionEngine.getInstance();
    const report = evolutionEngine.analyzeEvolution(twin, realityRecords);
    this.cachedReport = report;
    this.cachedFingerprint = currentFingerprint;

    // 4. Synthesize Fact vs Prediction vs Unknown
    const observations: OracleObservation[] = [];
    const predictions: OraclePrediction[] = [];
    const risks: OracleRisk[] = [];
    const opportunities: OracleOpportunity[] = [];
    const recommendations: OracleRecommendation[] = [];
    const unknowns: string[] = [];
    const counterEvidence: string[] = [];

    // Observed Facts
    observations.push({
      fact: `${report.latestSnapshot.fileCount} source files indexed (${report.latestSnapshot.dependencyCount} dependency edges).`,
      type: 'OBSERVED',
      source: 'DigitalTwin AST'
    });

    observations.push({
      fact: `Preview runtime status: ${twin.runtimeSnapshot.isHealthy ? 'Clean (0 active runtime crashes)' : `${twin.runtimeSnapshot.activeErrors.length} error(s)`}.`,
      type: 'OBSERVED',
      source: 'RuntimeSandbox'
    });

    observations.push({
      fact: `Preview isolation verified (Zero GODEX UI inside generated app).`,
      type: 'OBSERVED',
      source: 'DigitalTwin PreviewSnapshot'
    });

    // Extract Top Risks
    const highDepRisks = report.dependencyRiskForecasts.filter(r => r.riskLevel === 'CRITICAL' || r.riskLevel === 'HIGH');
    highDepRisks.slice(0, 3).forEach((hdr, idx) => {
      risks.push({
        id: `risk-dep-${idx + 1}`,
        title: `Dependency Nexus Risk: ${hdr.modulePath}`,
        severity: hdr.riskLevel,
        description: hdr.prediction,
        affectedFiles: [hdr.modulePath],
        evidence: hdr.evidence,
        confidence: hdr.confidence
      });

      predictions.push({
        id: `pred-dep-${idx + 1}`,
        prediction: `Modifications to "${hdr.modulePath}" have elevated blast radius across ${hdr.consumerCount} consumer(s).`,
        confidence: hdr.confidence,
        supportingEvidence: hdr.evidence,
        counterEvidence: hdr.consumerCount <= 2 ? ['Module consumers are currently localized within the same directory'] : [],
        affectedArea: hdr.modulePath,
        timeHorizon: 'MEDIUM_TERM'
      });
    });

    // Technical Debt Risks
    report.technicalDebtForecasts.forEach((td, idx) => {
      risks.push({
        id: `risk-debt-${idx + 1}`,
        title: td.title,
        severity: td.severity,
        description: td.estimatedFutureImpact,
        affectedFiles: td.affectedFiles,
        evidence: td.evidence,
        confidence: td.confidence
      });

      recommendations.push({
        id: `rec-debt-${idx + 1}`,
        title: `Mitigate ${td.title}`,
        priority: td.severity === 'CRITICAL' || td.severity === 'HIGH' ? 'HIGH' : 'MEDIUM',
        action: td.recommendedPrevention,
        rationale: td.estimatedFutureImpact,
        expandableEvidence: td.evidence
      });
    });

    // Recurring Failure Risks
    report.recurringFailurePredictions.forEach((rfp, idx) => {
      risks.push({
        id: `risk-recurring-${idx + 1}`,
        title: `Recurring Runtime Failure: ${rfp.pattern.slice(0, 40)}`,
        severity: 'HIGH',
        description: `Observed ${rfp.previousOccurrences} times in historical execution.`,
        affectedFiles: [],
        evidence: rfp.evidence,
        confidence: rfp.confidence
      });

      predictions.push({
        id: `pred-recurring-${idx + 1}`,
        prediction: `Subsystem ${rfp.affectedSubsystems.join(', ')} is prone to recurring exception "${rfp.pattern.slice(0, 40)}" unless guarded.`,
        confidence: rfp.confidence,
        supportingEvidence: rfp.evidence,
        counterEvidence: [],
        affectedArea: rfp.affectedSubsystems.join(', '),
        timeHorizon: 'SHORT_TERM'
      });

      recommendations.push({
        id: `rec-recurring-${idx + 1}`,
        title: `Add Guard for ${rfp.affectedSubsystems[0] || 'Runtime'}`,
        priority: 'URGENT',
        action: rfp.prevention,
        rationale: 'Eliminates recurring preview crash pattern.',
        expandableEvidence: rfp.evidence
      });
    });

    // Top Opportunities
    if (report.stableModulesNotToChange.length > 0) {
      opportunities.push({
        id: 'opp-stable-anchor',
        title: 'Leverage Stable Architectural Cores',
        impact: 'HIGH',
        description: `${report.stableModulesNotToChange.length} modules identified with high stability and bounded interfaces.`,
        preventionBenefit: 'Building new features on top of verified stable modules minimizes regression probability.'
      });
    }

    if (report.uiEvolutionForecast.divergentButtonCount > 2) {
      opportunities.push({
        id: 'opp-token-consolidation',
        title: 'Design System Token Consolidation',
        impact: 'MEDIUM',
        description: 'Consolidate multiple button styles into a shared UI primitive.',
        preventionBenefit: 'Eliminates UI styling drift and simplifies cross-screen responsiveness.'
      });
    }

    // 5. Counterfactual Simulation Integration (Zero Mutations)
    if (highDepRisks.length > 0) {
      const topRiskModule = highDepRisks[0].modulePath;
      const sim = CounterfactualEngineer.simulate(
        `Prevent regression bottleneck in ${topRiskModule}`,
        workspaceFiles
      );

      recommendations.push({
        id: 'rec-cf-simulation',
        title: `Architectural Strategy for ${topRiskModule}`,
        priority: 'MEDIUM',
        action: 'Review simulated refactoring options without applying physical mutations.',
        rationale: 'Evaluates risk vs blast radius before initiating code edits.',
        expandableEvidence: [
          `Simulated ${sim.options.length} non-mutating architectural paths`,
          `Selected recommended option: ${sim.options.find(o => o.recommendation === 'RECOMMENDED')?.title || sim.options[0].title}`
        ],
        preventiveOptions: sim.options.map(o => ({
          title: o.title,
          strategy: o.strategy,
          impact: o.architectureImpact,
          risk: `Risk Score: ${o.riskScore}/100 (${o.recommendation})`
        }))
      });
    }

    // Explicit Unknowns
    unknowns.push('Live production user concurrency and network latency patterns');
    unknowns.push('External third-party API rate limits during peak usage');

    // Filter by Specific Question Intent
    const qLower = (userQuestion || '').toLowerCase();
    let formattedAnswer = '';

    if (/\b(?:what\s+is\s+becoming\s+risky|risky|risks)\b/i.test(qLower)) {
      formattedAnswer = this.formatRisksResponse(risks, predictions, report);
    } else if (/\b(?:what\s+should\s+(?:we|i)\s+fix|fix\s+first|priority|fix\s+before)\b/i.test(qLower)) {
      formattedAnswer = this.formatRecommendationsResponse(recommendations, risks);
    } else if (/\b(?:what\s+should\s+(?:we|i)\s+not\s+change|not\s+to\s+change|avoid\s+changing|stable)\b/i.test(qLower)) {
      formattedAnswer = this.formatWhatNotToChangeResponse(report.stableModulesNotToChange);
    } else if (/\b(?:where\s+will\s+the\s+next\s+regression|next\s+regression|break)\b/i.test(qLower)) {
      formattedAnswer = this.formatRegressionForecastResponse(predictions, risks);
    } else if (/\b(?:why|evidence|reasoning)\b/i.test(qLower)) {
      formattedAnswer = this.formatEvidenceExplanation(observations, predictions, recommendations);
    } else {
      formattedAnswer = this.formatGeneralSummary(report, risks, recommendations);
    }

    return {
      question: userQuestion,
      observations,
      predictions,
      risks: risks.slice(0, 5),
      opportunities: opportunities.slice(0, 3),
      recommendations: recommendations.slice(0, 5),
      whatNotToChange: report.stableModulesNotToChange.slice(0, 5),
      counterEvidence,
      confidence: risks.some(r => r.severity === 'CRITICAL') ? 'HIGH' : 'MEDIUM',
      evidence: observations.map(o => o.fact),
      unknowns,
      generatedAt: Date.now(),
      digitalTwinFingerprint: currentFingerprint,
      isStale: false,
      status: 'OPTIMAL',
      formattedAnswer: EngineeringOracle.redactSecrets(formattedAnswer)
    };
  }

  private formatRisksResponse(risks: OracleRisk[], predictions: OraclePrediction[], report: EvolutionEngineReport): string {
    const lines: string[] = [
      '### 🔍 Engineering Oracle: Risk & Blast-Radius Assessment',
      '',
      `**Observed Baseline**: ${report.latestSnapshot.fileCount} files, ${report.latestSnapshot.dependencyCount} dependency edges (Architecture Health: ${report.healthModel.metrics.ARCHITECTURE_HEALTH.score}/100).`,
      ''
    ];

    if (risks.length === 0) {
      lines.push('**Status**: No currently observed evidence indicates an elevated structural risk.');
    } else {
      lines.push('**Key Predicted Risks**:');
      risks.slice(0, 3).forEach((r, i) => {
        lines.push(`${i + 1}. **[${r.severity}] ${r.title}** (Confidence: ${r.confidence})`);
        lines.push(`   - *Evidence*: ${r.evidence.join('; ')}`);
        lines.push(`   - *Impact*: ${r.description}`);
      });
    }

    return lines.join('\n');
  }

  private formatRecommendationsResponse(recs: OracleRecommendation[], risks: OracleRisk[]): string {
    const lines: string[] = [
      '### 💡 Engineering Oracle: Prioritized Preventive Actions',
      '',
      'Preventive maintenance recommendations based on AST dependency analysis and technical debt forecasts:',
      ''
    ];

    if (recs.length === 0) {
      lines.push('No urgent refactoring required. Current module boundaries are operating stably.');
    } else {
      recs.slice(0, 3).forEach((rec, i) => {
        lines.push(`${i + 1}. **[${rec.priority}] ${rec.title}**`);
        lines.push(`   - *Action*: ${rec.action}`);
        lines.push(`   - *Rationale*: ${rec.rationale}`);
      });
    }

    return lines.join('\n');
  }

  private formatWhatNotToChangeResponse(stableModules: Array<{ module: string; stabilityScore: number; reason: string; evidence: string[] }>): string {
    const lines: string[] = [
      '### 🛡️ Engineering Oracle: Stable Architectural Boundaries (What NOT to Change)',
      '',
      'The following modules have demonstrated high cohesion, low internal complexity, and zero recurring regressions. Modifying them casually introduces unnecessary blast-radius risk:',
      ''
    ];

    if (stableModules.length === 0) {
      lines.push('All modules currently exhibit active coupling or evolution dynamics.');
    } else {
      stableModules.slice(0, 4).forEach((sm, i) => {
        lines.push(`${i + 1}. **\`${sm.module}\`** (Stability Score: ${sm.stabilityScore}/100)`);
        lines.push(`   - *Reason*: ${sm.reason}`);
        lines.push(`   - *Evidence*: ${sm.evidence.join(', ')}`);
      });
    }

    return lines.join('\n');
  }

  private formatRegressionForecastResponse(predictions: OraclePrediction[], risks: OracleRisk[]): string {
    const lines: string[] = [
      '### ⚠️ Engineering Oracle: Regression Vulnerability Forecast',
      '',
      'Based on dependency fan-in/fan-out analysis and historical execution data:',
      ''
    ];

    if (predictions.length === 0) {
      lines.push('No currently observed evidence indicates an imminent high-risk regression hotspot.');
    } else {
      predictions.slice(0, 3).forEach((p, i) => {
        lines.push(`${i + 1}. **Affected Area: \`${p.affectedArea}\`** (Time Horizon: ${p.timeHorizon}, Confidence: ${p.confidence})`);
        lines.push(`   - *Prediction*: ${p.prediction}`);
        lines.push(`   - *Supporting Evidence*: ${p.supportingEvidence.join('; ')}`);
        if (p.counterEvidence.length > 0) {
          lines.push(`   - *Counter-Evidence*: ${p.counterEvidence.join('; ')}`);
        }
      });
    }

    return lines.join('\n');
  }

  private formatEvidenceExplanation(observations: OracleObservation[], predictions: OraclePrediction[], recs: OracleRecommendation[]): string {
    const lines: string[] = [
      '### 🔬 Engineering Oracle: Evidence & Epistemic Chain',
      '',
      '**1. Observed Facts (Ground Truth)**:'
    ];

    observations.forEach(o => {
      lines.push(`- [${o.type}] (${o.source}): ${o.fact}`);
    });

    lines.push('', '**2. Derived Predictions**:');
    predictions.slice(0, 3).forEach(p => {
      lines.push(`- **${p.affectedArea}** (${p.confidence} confidence): ${p.prediction}`);
    });

    return lines.join('\n');
  }

  private formatGeneralSummary(report: EvolutionEngineReport, risks: OracleRisk[], recs: OracleRecommendation[]): string {
    const lines: string[] = [
      '### 🔮 GODEX Engineering Oracle Summary',
      '',
      `**Overall Project Integrity**: ${report.healthModel.overallIntegrity}/100 | **Trajectory**: ${report.healthModel.trajectory}`,
      '',
      '**Multidimensional Health Breakdown**:',
      `- Architecture: ${report.healthModel.metrics.ARCHITECTURE_HEALTH.score}/100 (${report.healthModel.metrics.ARCHITECTURE_HEALTH.trend})`,
      `- Code Quality: ${report.healthModel.metrics.CODE_HEALTH.score}/100 (${report.healthModel.metrics.CODE_HEALTH.trend})`,
      `- Testing & Verification: ${report.healthModel.metrics.TEST_HEALTH.score}/100 (${report.healthModel.metrics.TEST_HEALTH.trend})`,
      `- Runtime Sandbox: ${report.healthModel.metrics.RUNTIME_HEALTH.score}/100 (${report.healthModel.metrics.RUNTIME_HEALTH.trend})`,
      `- UI & Design Tokens: ${report.healthModel.metrics.UI_HEALTH.score}/100 (${report.healthModel.metrics.UI_HEALTH.trend})`,
      `- Maintainability: ${report.healthModel.metrics.MAINTAINABILITY_HEALTH.score}/100 (${report.healthModel.metrics.MAINTAINABILITY_HEALTH.trend})`,
      `- Agent Reliability: ${report.healthModel.metrics.AGENT_RELIABILITY.score}/100 (${report.healthModel.metrics.AGENT_RELIABILITY.confidence} confidence)`
    ];

    if (risks.length > 0) {
      lines.push('', `**Top Risk**: [${risks[0].severity}] ${risks[0].title} — *${risks[0].description}*`);
    }

    if (recs.length > 0) {
      lines.push('', `**Top Recommended Prevention**: ${recs[0].title} — *${recs[0].action}*`);
    }

    return lines.join('\n');
  }
}
