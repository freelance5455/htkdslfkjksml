/**
 * GODEX - Domain Synthesizer & Autonomous Application Generator
 * Decoupled, multi-domain semantic generator for arbitrary user prompts
 * with specialized template retention and anti-collision classification.
 */

import { UniversalDesignSystem } from './design';
import { NOVANOTES_PROJECT } from '../templates/novaNotesProject';
import { NOVA_SAAS_DASHBOARD_PROJECT } from '../templates/novaSaaSDashboardProject';

export interface SynthesizedApplicationResult {
  files: Record<string, string>;
  name: string;
  description: string;
  summary: string;
  entryFile: string;
  reactCode: string;
}

/**
 * Ensures all generated files are passed through the AntiUgly and Design System cleaners
 */
function finalizeResult(res: SynthesizedApplicationResult): SynthesizedApplicationResult {
  const cleanFiles: Record<string, string> = {};
  for (const [k, v] of Object.entries(res.files)) {
    cleanFiles[k] = (k.endsWith('.tsx') || k.endsWith('.jsx') || k.endsWith('.ts') || k.endsWith('.js'))
      ? UniversalDesignSystem.cleanCode(v)
      : v;
  }
  return {
    ...res,
    files: cleanFiles,
    reactCode: cleanFiles['src/App.tsx'] || res.reactCode
  };
}

/**
 * Checks if prompt specifically targets a known specialized archetype
 */
function isSaaSAnalyticsRequested(p: string): boolean {
  return p.includes('saas analytics') || p.includes('ai saas') || (p.includes('saas') && p.includes('dashboard'));
}

function isProfileCardRequested(p: string): boolean {
  return (
    p.includes('profile card') || 
    p.includes('profilecard') || 
    p.includes('author card') || 
    p.includes('user profile') ||
    (p.includes('avatar') && p.includes('role') && p.includes('bio'))
  );
}

function isPortfolioRequested(p: string): boolean {
  return p.includes('portfolio') || p.includes('resume') || p.includes('personal site') || (p.includes('developer') && (p.includes('bio') || p.includes('showcase') || p.includes('architect')));
}

function isNotesRequested(p: string): boolean {
  return (
    p.includes('novanotes') ||
    p.includes('notepad') ||
    p.includes('notes app') ||
    p.includes('note app') ||
    (p.includes('note') && (p.includes('taking') || p.includes('app') || p.includes('bana') || p.includes('create') || p.includes('make') || p.includes('build'))) ||
    p.includes('diary') ||
    p.includes('journal')
  );
}

function isMusicPlayerRequested(p: string): boolean {
  return (
    p.includes('music') ||
    p.includes('audio player') ||
    p.includes('song player') ||
    p.includes('music player') ||
    p.includes('spotify') ||
    p.includes('sound player') ||
    p.includes('mp3') ||
    (p.includes('song') && (p.includes('play') || p.includes('app') || p.includes('bana') || p.includes('build')))
  );
}

function isBusinessWebsiteRequested(p: string): boolean {
  return (
    (p.includes('website') && (p.includes('business') || p.includes('company') || p.includes('agency') || p.includes('startup') || p.includes('service') || p.includes('corporate') || p.includes('firm'))) ||
    p.includes('business website') ||
    p.includes('company website') ||
    (p.includes('website') && (p.includes('create') || p.includes('build') || p.includes('bana')) && !p.includes('portfolio'))
  );
}

function isProjectManagementRequested(p: string): boolean {
  return (
    p.includes('project management') ||
    p.includes('task board') ||
    p.includes('kanban') ||
    p.includes('software team') ||
    p.includes('sprint') ||
    p.includes('issue tracker') ||
    p.includes('bug tracker') ||
    (p.includes('task') && p.includes('overview') && p.includes('timeline')) ||
    (p.includes('project') && p.includes('board') && p.includes('sidebar'))
  );
}

/**
 * Universal domain-aware application synthesizer
 */
export function synthesizeDomainApplication(
  prompt: string,
  existingFiles: Record<string, string> = {}
): SynthesizedApplicationResult {
  const p = prompt.toLowerCase();
  const files: Record<string, string> = { ...existingFiles };

  // =========================================================================
  // 1. Specialized: SaaS Analytics Dashboard (single source of truth)
  // =========================================================================
  if (isSaaSAnalyticsRequested(p)) {
    const saasDashboardCode = NOVA_SAAS_DASHBOARD_PROJECT.files['src/App.tsx'] || '';
    files['src/App.tsx'] = saasDashboardCode;
    return finalizeResult({
      files,
      name: 'SaaS Analytics Dashboard',
      description: 'A sample SaaS analytics dashboard with illustrative demo metrics. It is not connected to live business data or a production API by default.',
      summary: 'Created a SaaS analytics dashboard template with sample data. Connect and verify real data sources before using it as a production dashboard.',
      entryFile: 'src/App.tsx',
      reactCode: saasDashboardCode
    });
  }

  // =========================================================================
  // 2. Specialized: Modern Profile Card
  // =========================================================================
  if (isProfileCardRequested(p)) {
    const profileCardComponent = `import React, { useState } from 'react';
import { Sparkles, Check, ArrowRight, Shield, Award, MapPin, Mail } from 'lucide-react';

export interface ProfileCardProps {
  name?: string;
  role?: string;
  avatarUrl?: string;
  location?: string;
  status?: string;
  onAction?: () => void;
}

export const ProfileCard: React.FC<ProfileCardProps> = ({
  name = "Aria Montgomery",
  role = "Lead Systems Architect",
  location = "San Francisco, CA",
  status = "Active Engineering",
  avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
  onAction
}) => {
  const [isConnected, setIsConnected] = useState(false);

  const handleAction = () => {
    setIsConnected(prev => !prev);
    onAction?.();
  };

  return (
    <div 
      id="godex-profile-card"
      className="bg-neutral-900/95 border border-neutral-800 rounded-2xl p-6 shadow-2xl backdrop-blur-xl max-w-sm w-full transition-all duration-300 hover:border-neutral-700 hover:shadow-cyan-950/20 flex flex-col items-center text-center font-sans select-none"
    >
      <div className="w-full flex items-center justify-between text-[10px] font-mono text-neutral-400 mb-4 pb-2 border-b border-neutral-800/80">
        <span className="flex items-center gap-1.5 text-cyan-400">
          <Sparkles className="w-3 h-3" />
          <span>VERIFIED CREATOR</span>
        </span>
        <span className="px-2 py-0.5 rounded-full bg-neutral-950 border border-neutral-800 text-emerald-400 font-semibold flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          {status}
        </span>
      </div>

      <div className="relative mb-4 group">
        <div className="w-20 h-20 rounded-2xl overflow-hidden ring-2 ring-cyan-500/40 p-0.5 bg-gradient-to-tr from-cyan-500 to-blue-600 shadow-lg shadow-cyan-950/50">
          <img 
            src={avatarUrl} 
            alt={name}
            className="w-full h-full object-cover rounded-xl transition-transform duration-300 group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-lg bg-cyan-600 text-white flex items-center justify-center shadow-md border border-neutral-900">
          <Shield className="w-3.5 h-3.5" />
        </div>
      </div>

      <h3 className="text-lg font-bold text-white tracking-tight mb-1">{name}</h3>
      <p className="text-xs font-medium text-cyan-400 mb-2 font-mono flex items-center gap-1">
        <Award className="w-3.5 h-3.5 text-cyan-400" />
        {role}
      </p>

      <p className="text-[11px] text-neutral-400 flex items-center gap-1 mb-5">
        <MapPin className="w-3 h-3 text-neutral-500" />
        {location}
      </p>

      <button
        id="profile-action-btn"
        onClick={handleAction}
        className={"w-full py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all duration-200 flex items-center justify-center gap-2 shadow-lg active:scale-98 " + (
          isConnected 
            ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/50" 
            : "bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-cyan-950/50 hover:shadow-cyan-900/40"
        )}
      >
        {isConnected ? (
          <>
            <Check className="w-4 h-4 text-white" />
            <span>Connected</span>
          </>
        ) : (
          <>
            <Mail className="w-4 h-4" />
            <span>Connect Profile</span>
            <ArrowRight className="w-3.5 h-3.5 ml-0.5 opacity-70" />
          </>
        )}
      </button>
    </div>
  );
};
`;

    const profileAppCode = `import React, { useState } from 'react';
import { ProfileCard } from './components/ProfileCard';
import { Sparkles, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [actionCount, setActionCount] = useState(0);

  return (
    <div className="min-h-screen w-full bg-[#080B12] text-neutral-100 flex flex-col items-center justify-center p-6 select-none font-sans">
      <div className="relative z-10 flex flex-col items-center space-y-6 max-w-md w-full">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-neutral-900/90 border border-neutral-800 text-xs text-neutral-300 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-medium">Modern Profile Component</span>
        </div>

        <ProfileCard 
          name="Aria Montgomery"
          role="Lead Systems Architect"
          location="San Francisco, CA"
          status="Active Engineering"
          onAction={() => setActionCount(c => c + 1)}
        />

        {actionCount > 0 && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-xs font-mono animate-in fade-in duration-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Profile Connected (Interactions: {actionCount})</span>
          </div>
        )}
      </div>
    </div>
  );
}
`;
    files['src/components/ProfileCard.tsx'] = profileCardComponent;
    files['src/App.tsx'] = profileAppCode;
    return finalizeResult({
      files,
      name: 'Modern Profile Card Component',
      description: 'Interactive modern profile card component with avatar ring, role badge, and connect button.',
      summary: 'Created profile card component in `src/components/ProfileCard.tsx` and mounted in `src/App.tsx`.',
      entryFile: 'src/App.tsx',
      reactCode: profileAppCode
    });
  }

  // =========================================================================
  // 3. Specialized: Developer Architecture Portfolio
  // =========================================================================
  if (isPortfolioRequested(p)) {
    const portfolioAppCode = `import React, { useState } from 'react';
import { 
  Terminal, Code2, Cpu, Globe, ExternalLink, Github, Twitter, 
  Linkedin, Mail, Sparkles, FolderGit2, CheckCircle2, ChevronRight,
  Layers, ArrowUpRight, Award, Compass
} from 'lucide-react';

export default function App() {
  const [activeFilter, setActiveFilter] = useState<'all' | 'ai' | 'cloud' | 'frontend'>('all');

  const projects = [
    {
      title: 'Autonomous Agent Swarm',
      desc: 'Distributed multi-model consensus engine with real-time tool orchestration and surgical code safe-edits.',
      category: 'ai',
      tech: ['React', 'TypeScript', 'Gemini 3.7', 'WebSocket'],
      stars: 480
    },
    {
      title: 'Zero-Latency Edge Cache',
      desc: 'Sub-millisecond global cache replication across 300+ CDN edge nodes with invalidation streams.',
      category: 'cloud',
      tech: ['Rust', 'Wasm', 'Cloudflare Workers'],
      stars: 320
    },
    {
      title: 'High-Contrast Design System',
      desc: 'WCAG AA enterprise component library with mathematical typography scaling and zero visual slop.',
      category: 'frontend',
      tech: ['Tailwind CSS', 'Radix UI', 'React 18'],
      stars: 640
    }
  ];

  return (
    <div id="developer-portfolio-app" className="min-h-screen w-full bg-[#080B12] text-slate-100 font-sans select-none p-4 sm:p-8 lg:p-12">
      <div className="max-w-4xl mx-auto space-y-10">
        <header className="p-8 rounded-3xl bg-[#0D121F] border border-[#1B2438] shadow-2xl flex flex-col sm:flex-row items-center gap-6">
          <div className="w-24 h-24 rounded-2xl bg-gradient-to-tr from-cyan-500 to-indigo-600 p-1 shrink-0 shadow-lg shadow-cyan-500/25">
            <img 
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200" 
              alt="Developer"
              className="w-full h-full object-cover rounded-xl"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="space-y-2 text-center sm:text-left flex-1">
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                AVAILABLE FOR HIRE
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">Elena Rostova</h1>
            <p className="text-xs sm:text-sm text-slate-400">
              Staff Systems Architect & Autonomous Agent Systems Engineer
            </p>
          </div>
        </header>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white">Featured Architecture</h2>
            <div className="flex gap-1 bg-[#0D121F] p-1 rounded-xl border border-[#1B2438]">
              {(['all', 'ai', 'cloud', 'frontend'] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setActiveFilter(f)}
                  className={\`px-2.5 py-1 rounded-lg text-xs font-mono uppercase \${
                    activeFilter === f ? 'bg-cyan-950 text-cyan-300 border border-cyan-800' : 'text-slate-400 hover:text-white'
                  }\`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {projects
              .filter(p => activeFilter === 'all' || p.category === activeFilter)
              .map(p => (
                <div key={p.title} className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] space-y-3 shadow-xl hover:border-cyan-500/40 transition-all">
                  <h3 className="font-bold text-sm text-white">{p.title}</h3>
                  <p className="text-xs text-slate-400">{p.desc}</p>
                  <div className="flex flex-wrap gap-1 pt-2">
                    {p.tech.map(t => (
                      <span key={t} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#162035] text-cyan-300">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
`;
    files['src/App.tsx'] = portfolioAppCode;
    return finalizeResult({
      files,
      name: 'Developer Architecture Portfolio',
      description: 'Responsive developer portfolio with project category filters and systems showcase.',
      summary: 'Created developer portfolio website in `src/App.tsx`.',
      entryFile: 'src/App.tsx',
      reactCode: portfolioAppCode
    });
  }

  // =========================================================================
  // 4. Primary Requirement Match: Project Management & Kanban Suite
  // =========================================================================
  if (isProjectManagementRequested(p)) {
    const projectManagementAppCode = `import React, { useState } from 'react';
import { 
  Kanban, CheckSquare, Clock, Users, Calendar, Filter, Plus, 
  Search, ChevronRight, MoreHorizontal, ArrowRight, ArrowLeft,
  CheckCircle2, AlertCircle, AlertTriangle, MessageSquare, 
  SlidersHorizontal, Sparkles, FolderGit2, Layers, BarChart2, 
  Settings, Menu, X, Trash2, Edit3, Tag, Check, Eye, Bell
} from 'lucide-react';

export type TaskPriority = 'urgent' | 'high' | 'medium' | 'low';
export type TaskStatus = 'backlog' | 'in_progress' | 'in_review' | 'done';

export interface Subtask {
  id: string;
  title: string;
  completed: boolean;
}

export interface TaskItem {
  id: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  assignee: {
    name: string;
    avatar: string;
    role: string;
  };
  tags: string[];
  estimatedHours: number;
  subtasks: Subtask[];
  commentsCount: number;
  updatedAt: string;
}

export interface ActivityEvent {
  id: string;
  user: string;
  action: string;
  target: string;
  timestamp: string;
  type: 'move' | 'create' | 'complete' | 'edit';
}

const INITIAL_TASKS: TaskItem[] = [
  {
    id: 'PROJ-101',
    title: 'Architect Realtime WebSocket Sync Engine',
    description: 'Implement distributed delta compression and bi-directional message streaming for team state.',
    status: 'done',
    priority: 'urgent',
    assignee: { name: 'Elena Rostova', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100', role: 'Staff Engineer' },
    tags: ['infra', 'backend', 'websocket'],
    estimatedHours: 14,
    subtasks: [
      { id: 's1', title: 'Delta protocol spec', completed: true },
      { id: 's2', title: 'Heartbeat ping-pong', completed: true }
    ],
    commentsCount: 6,
    updatedAt: '12m ago'
  },
  {
    id: 'PROJ-102',
    title: 'Design High-Contrast Dark Component Library',
    description: 'Build WCAG AA accessible components with mathematical optical spacing and responsive touch states.',
    status: 'in_review',
    priority: 'high',
    assignee: { name: 'Marcus Chen', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100', role: 'Design Lead' },
    tags: ['design', 'tailwind', 'ui'],
    estimatedHours: 8,
    subtasks: [
      { id: 's3', title: 'Color token hierarchy', completed: true },
      { id: 's4', title: 'Focus ring indicators', completed: true },
      { id: 's5', title: 'Contrast audit pass', completed: false }
    ],
    commentsCount: 4,
    updatedAt: '35m ago'
  },
  {
    id: 'PROJ-103',
    title: 'Migrate REST Endpoints to Edge Functions',
    description: 'Optimize p99 latency across global CDN points of presence down to sub-15ms execution time.',
    status: 'in_progress',
    priority: 'high',
    assignee: { name: 'Sarah Jenkins', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100', role: 'Backend Lead' },
    tags: ['cloud', 'latency', 'api'],
    estimatedHours: 12,
    subtasks: [
      { id: 's6', title: 'Deploy Cloudflare worker bridge', completed: true },
      { id: 's7', title: 'Benchmark cold starts', completed: false }
    ],
    commentsCount: 2,
    updatedAt: '1h ago'
  },
  {
    id: 'PROJ-104',
    title: 'Automated CI/CD esbuild Syntax Verification',
    description: 'Hook into git pre-commit to verify TSX syntax AST transforms in under 15ms per pull request.',
    status: 'in_progress',
    priority: 'medium',
    assignee: { name: 'David Kim', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100', role: 'DevOps' },
    tags: ['ci-cd', 'esbuild', 'testing'],
    estimatedHours: 6,
    subtasks: [
      { id: 's8', title: 'Configure AST pipeline', completed: true },
      { id: 's9', title: 'Add failure annotations', completed: false }
    ],
    commentsCount: 1,
    updatedAt: '2h ago'
  },
  {
    id: 'PROJ-105',
    title: 'Enterprise Multi-Tenant Role Based Access',
    description: 'Support Organization Admins, Technical Leads, Contributors, and Viewers with fine-grained ACLs.',
    status: 'backlog',
    priority: 'urgent',
    assignee: { name: 'Elena Rostova', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100', role: 'Staff Engineer' },
    tags: ['security', 'auth', 'enterprise'],
    estimatedHours: 20,
    subtasks: [
      { id: 's10', title: 'JWT Claims specification', completed: false },
      { id: 's11', title: 'Workspace isolation tests', completed: false }
    ],
    commentsCount: 8,
    updatedAt: '4h ago'
  },
  {
    id: 'PROJ-106',
    title: 'Mobile Responsive Touch Drawer & Virtual Scroll',
    description: 'Ensure smooth 60fps gesture handling on iOS/Android viewport with zero layout thrashing.',
    status: 'backlog',
    priority: 'low',
    assignee: { name: 'Marcus Chen', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100', role: 'Design Lead' },
    tags: ['mobile', 'touch', 'perf'],
    estimatedHours: 5,
    subtasks: [
      { id: 's12', title: 'Gesture threshold damping', completed: false }
    ],
    commentsCount: 0,
    updatedAt: '1d ago'
  }
];

const INITIAL_ACTIVITIES: ActivityEvent[] = [
  { id: 'act-1', user: 'Elena Rostova', action: 'moved', target: 'PROJ-101 to Done', timestamp: '12m ago', type: 'complete' },
  { id: 'act-2', user: 'Marcus Chen', action: 'submitted for review', target: 'PROJ-102 High-Contrast Components', timestamp: '35m ago', type: 'move' },
  { id: 'act-3', user: 'Sarah Jenkins', action: 'started working on', target: 'PROJ-103 Edge Functions', timestamp: '1h ago', type: 'edit' },
  { id: 'act-4', user: 'David Kim', action: 'completed subtask on', target: 'PROJ-104 CI/CD Pipeline', timestamp: '2h ago', type: 'edit' },
  { id: 'act-5', user: 'Elena Rostova', action: 'created issue', target: 'PROJ-105 Multi-Tenant ACLs', timestamp: '4h ago', type: 'create' }
];

export default function ProjectManagementApp() {
  const [tasks, setTasks] = useState<TaskItem[]>(INITIAL_TASKS);
  const [activities, setActivities] = useState<ActivityEvent[]>(INITIAL_ACTIVITIES);
  const [activeTab, setActiveTab] = useState<'overview' | 'board' | 'timeline' | 'team' | 'settings'>('board');
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [assigneeFilter, setAssigneeFilter] = useState<string>('all');
  const [selectedTask, setSelectedTask] = useState<TaskItem | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  // New task form state
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDesc, setNewTaskDesc] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<TaskPriority>('medium');
  const [newTaskStatus, setNewTaskStatus] = useState<TaskStatus>('backlog');
  const [newTaskAssignee, setNewTaskAssignee] = useState('Elena Rostova');
  const [newTaskHours, setNewTaskHours] = useState(6);
  const [newTaskTags, setNewTaskTags] = useState('frontend, core');

  // Stats calculation
  const totalTasks = tasks.length;
  const doneTasks = tasks.filter(t => t.status === 'done').length;
  const inProgressTasks = tasks.filter(t => t.status === 'in_progress').length;
  const reviewTasks = tasks.filter(t => t.status === 'in_review').length;
  const backlogTasks = tasks.filter(t => t.status === 'backlog').length;
  const completionRate = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;
  const urgentTasks = tasks.filter(t => t.priority === 'urgent' && t.status !== 'done').length;

  const handleMoveTask = (taskId: string, direction: 'forward' | 'backward') => {
    const statusOrder: TaskStatus[] = ['backlog', 'in_progress', 'in_review', 'done'];
    setTasks(prev => prev.map(t => {
      if (t.id !== taskId) return t;
      const currentIndex = statusOrder.indexOf(t.status);
      const nextIndex = direction === 'forward' 
        ? Math.min(statusOrder.length - 1, currentIndex + 1)
        : Math.max(0, currentIndex - 1);
      const nextStatus = statusOrder[nextIndex];
      
      // Log activity
      if (nextStatus !== t.status) {
        const newAct: ActivityEvent = {
          id: 'act-' + Date.now(),
          user: 'You',
          action: 'moved',
          target: \`\${t.id} to \${nextStatus.replace('_', ' ').toUpperCase()}\`,
          timestamp: 'Just now',
          type: nextStatus === 'done' ? 'complete' : 'move'
        };
        setActivities(acts => [newAct, ...acts]);
      }

      return { ...t, status: nextStatus, updatedAt: 'Just now' };
    }));

    if (selectedTask && selectedTask.id === taskId) {
      const currentIdx = statusOrder.indexOf(selectedTask.status);
      const nextIdx = direction === 'forward' ? Math.min(statusOrder.length - 1, currentIdx + 1) : Math.max(0, currentIdx - 1);
      setSelectedTask(prev => prev ? { ...prev, status: statusOrder[nextIdx] } : null);
    }
  };

  const handleToggleSubtask = (taskId: string, subtaskId: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id !== taskId) return t;
      const updatedSubtasks = t.subtasks.map(s => s.id === subtaskId ? { ...s, completed: !s.completed } : s);
      return { ...t, subtasks: updatedSubtasks, updatedAt: 'Just now' };
    }));

    if (selectedTask && selectedTask.id === taskId) {
      setSelectedTask(prev => prev ? {
        ...prev,
        subtasks: prev.subtasks.map(s => s.id === subtaskId ? { ...s, completed: !s.completed } : s)
      } : null);
    }
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    const avatars: Record<string, { role: string; avatar: string }> = {
      'Elena Rostova': { role: 'Staff Engineer', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100' },
      'Marcus Chen': { role: 'Design Lead', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100' },
      'Sarah Jenkins': { role: 'Backend Lead', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100' },
      'David Kim': { role: 'DevOps Lead', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100' }
    };

    const assigneeMeta = avatars[newTaskAssignee] || { role: 'Contributor', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100' };

    const newTask: TaskItem = {
      id: \`PROJ-\${Math.floor(107 + tasks.length)}\`,
      title: newTaskTitle.trim(),
      description: newTaskDesc.trim() || 'No detailed description provided.',
      status: newTaskStatus,
      priority: newTaskPriority,
      assignee: {
        name: newTaskAssignee,
        avatar: assigneeMeta.avatar,
        role: assigneeMeta.role
      },
      tags: newTaskTags.split(',').map(t => t.trim().replace(/^#/, '')).filter(Boolean),
      estimatedHours: Number(newTaskHours) || 4,
      subtasks: [],
      commentsCount: 0,
      updatedAt: 'Just now'
    };

    setTasks(prev => [newTask, ...prev]);

    // Activity log
    setActivities(acts => [{
      id: 'act-' + Date.now(),
      user: 'You',
      action: 'created',
      target: \`\${newTask.id}: \${newTask.title}\`,
      timestamp: 'Just now',
      type: 'create'
    }, ...acts]);

    setNewTaskTitle('');
    setNewTaskDesc('');
    setIsCreateModalOpen(false);
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
    if (selectedTask?.id === taskId) setSelectedTask(null);
  };

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = !searchQuery.trim() || 
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())) ||
      task.assignee.name.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesPriority = priorityFilter === 'all' || task.priority === priorityFilter;
    const matchesAssignee = assigneeFilter === 'all' || task.assignee.name === assigneeFilter;

    return matchesSearch && matchesPriority && matchesAssignee;
  });

  const getPriorityBadge = (prio: TaskPriority) => {
    switch (prio) {
      case 'urgent':
        return <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-rose-950/80 text-rose-400 border border-rose-800/80 flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> URGENT</span>;
      case 'high':
        return <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-amber-950/80 text-amber-400 border border-amber-800/80 flex items-center gap-1"><AlertCircle className="w-3 h-3" /> HIGH</span>;
      case 'medium':
        return <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-cyan-950/80 text-cyan-400 border border-cyan-800/80 flex items-center gap-1"><Clock className="w-3 h-3" /> MEDIUM</span>;
      case 'low':
        return <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-slate-900 text-slate-400 border border-slate-800 flex items-center gap-1"><Check className="w-3 h-3" /> LOW</span>;
    }
  };

  const columns: { id: TaskStatus; label: string; count: number; color: string }[] = [
    { id: 'backlog', label: 'Backlog', count: filteredTasks.filter(t => t.status === 'backlog').length, color: '#64748b' },
    { id: 'in_progress', label: 'In Progress', count: filteredTasks.filter(t => t.status === 'in_progress').length, color: '#06b6d4' },
    { id: 'in_review', label: 'In Review', count: filteredTasks.filter(t => t.status === 'in_review').length, color: '#818cf8' },
    { id: 'done', label: 'Completed', count: filteredTasks.filter(t => t.status === 'done').length, color: '#10b981' }
  ];

  return (
    <div className="flex h-screen w-full bg-[#080B12] text-slate-100 font-sans select-none overflow-hidden">
      {/* -------------------------------------------------------------
          LEFT SIDEBAR NAVIGATION
      ------------------------------------------------------------- */}
      <aside className="hidden lg:flex flex-col w-64 bg-[#0D121F] border-r border-[#1B2438] shrink-0 z-30">
        {/* Workspace Brand */}
        <div className="h-16 px-5 border-b border-[#1B2438] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Kanban className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-extrabold text-sm text-white tracking-wide flex items-center gap-1.5">
                <span>HYPERION</span>
                <span className="text-[9px] font-mono px-1 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 font-bold">PRO</span>
              </div>
              <div className="text-[11px] text-slate-400 font-mono">Software Team v2.4</div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {[
            { id: 'overview', label: 'Project Overview', icon: BarChart2, badge: \`\${completionRate}%\` },
            { id: 'board', label: 'Task Board', icon: Kanban, count: totalTasks },
            { id: 'timeline', label: 'Activity Timeline', icon: Clock, count: activities.length },
            { id: 'team', label: 'Team Capacity', icon: Users },
            { id: 'settings', label: 'Project Settings', icon: Settings }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={\`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all min-h-[42px] \${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-950/90 to-indigo-950/40 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-950/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#121829]'
                }\`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={\`w-4 h-4 \${isActive ? 'text-cyan-400' : 'text-slate-400'}\`} />
                  <span>{tab.label}</span>
                </div>
                {tab.badge && (
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                    {tab.badge}
                  </span>
                )}
                {tab.count !== undefined && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#162035] text-slate-400">
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Sprint Progress Footer */}
        <div className="p-4 border-t border-[#1B2438] bg-[#090D17] space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Sprint 42 Velocity</span>
            <span className="font-mono text-cyan-400 font-bold">{doneTasks} / {totalTasks} Tasks</span>
          </div>
          <div className="w-full h-1.5 rounded-full bg-[#182133] overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-500"
              style={{ width: \`\${completionRate}%\` }}
            />
          </div>
          <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono">
            <span>Sprint ends in 4 days</span>
            <span className="text-emerald-400 font-bold">{completionRate}% Done</span>
          </div>
        </div>
      </aside>

      {/* -------------------------------------------------------------
          MAIN APPLICATION VIEWPORT
      ------------------------------------------------------------- */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        {/* Top Control Header */}
        <header className="h-16 bg-[#0D121F] border-b border-[#1B2438] px-4 sm:px-6 flex items-center justify-between shrink-0 z-20">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileNavOpen(!mobileNavOpen)}
              className="p-2 rounded-lg bg-[#141C2E] text-slate-300 lg:hidden"
            >
              {mobileNavOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
            <div>
              <h1 className="font-extrabold text-sm text-white tracking-wide flex items-center gap-2">
                <span>Core Platform Sprint</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                  SPRINT-42
                </span>
              </h1>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="relative hidden md:block w-48 lg:w-64">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search tasks, IDs, tags..."
                className="w-full h-8 pl-8 pr-3 bg-[#141B2D] border border-[#232E4A] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-sans"
              />
            </div>

            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="h-8 px-2 bg-[#141B2D] border border-[#232E4A] rounded-xl text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
            >
              <option value="all">All Priorities</option>
              <option value="urgent">Urgent</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>

            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="h-8 px-3 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-600/20 transition-all shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">New Task</span>
            </button>
          </div>
        </header>

        {/* Mobile Navigation Drawer */}
        {mobileNavOpen && (
          <div className="lg:hidden absolute top-16 left-0 right-0 bg-[#0D121F] border-b border-[#1B2438] p-4 space-y-2 z-40 shadow-2xl">
            {['overview', 'board', 'timeline', 'team', 'settings'].map(tab => (
              <button
                key={tab}
                onClick={() => { setActiveTab(tab as any); setMobileNavOpen(false); }}
                className={\`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider \${
                  activeTab === tab ? 'bg-cyan-950 text-cyan-300' : 'text-slate-400 hover:bg-[#162035]'
                }\`}
              >
                {tab}
              </button>
            ))}
          </div>
        )}

        {/* VIEWPORT BODY */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
          {/* ========================================================
              VIEW 1: PROJECT OVERVIEW
          ======================================================== */}
          {activeTab === 'overview' && (
            <div className="space-y-6 max-w-6xl mx-auto">
              {/* Metric KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-2">
                  <div className="text-xs text-slate-400 font-medium">COMPLETION VELOCITY</div>
                  <div className="text-3xl font-extrabold font-mono text-white">{completionRate}%</div>
                  <div className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> {doneTasks} of {totalTasks} tasks finished
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-2">
                  <div className="text-xs text-slate-400 font-medium">IN ACTIVE FLIGHT</div>
                  <div className="text-3xl font-extrabold font-mono text-cyan-400">{inProgressTasks + reviewTasks}</div>
                  <div className="text-xs text-cyan-400 font-mono">
                    {inProgressTasks} dev, {reviewTasks} review
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-2">
                  <div className="text-xs text-slate-400 font-medium">CRITICAL BLOCKERS</div>
                  <div className="text-3xl font-extrabold font-mono text-rose-400">{urgentTasks}</div>
                  <div className="text-xs text-rose-400 font-mono">
                    {urgentTasks === 0 ? 'No active blockers' : 'Requires immediate review'}
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-2">
                  <div className="text-xs text-slate-400 font-medium">ESTIMATED EFFORT</div>
                  <div className="text-3xl font-extrabold font-mono text-indigo-400">
                    {tasks.reduce((sum, t) => sum + t.estimatedHours, 0)} hrs
                  </div>
                  <div className="text-xs text-slate-400 font-mono">Total sprint scope</div>
                </div>
              </div>

              {/* Team Workload Breakdown */}
              <div className="p-6 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                <h3 className="font-bold text-base text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-cyan-400" />
                  <span>Team Workload Distribution</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  {['Elena Rostova', 'Marcus Chen', 'Sarah Jenkins', 'David Kim'].map(name => {
                    const memberTasks = tasks.filter(t => t.assignee.name === name);
                    const memberDone = memberTasks.filter(t => t.status === 'done').length;
                    const memberHours = memberTasks.reduce((s, t) => s + t.estimatedHours, 0);
                    return (
                      <div key={name} className="p-4 rounded-xl bg-[#111726] border border-[#1E2940] space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-full bg-cyan-900 border border-cyan-700 flex items-center justify-center font-bold text-xs text-cyan-300">
                              {name.split(' ').map(n => n[0]).join('')}
                            </div>
                            <div>
                              <div className="font-bold text-xs text-white">{name}</div>
                              <div className="text-[10px] text-slate-400 font-mono">{memberTasks.length} Assigned Tasks ({memberHours}h)</div>
                            </div>
                          </div>
                          <span className="text-xs font-mono font-bold text-emerald-400">{memberDone}/{memberTasks.length} Done</span>
                        </div>
                        <div className="w-full h-1.5 rounded-full bg-[#182133] overflow-hidden">
                          <div
                            className="h-full bg-cyan-400"
                            style={{ width: memberTasks.length > 0 ? \`\${(memberDone / memberTasks.length) * 100}%\` : '0%' }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              VIEW 2: KANBAN TASK BOARD
          ======================================================== */}
          {activeTab === 'board' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-start">
              {columns.map(col => {
                const columnTasks = filteredTasks.filter(t => t.status === col.id);
                return (
                  <div 
                    key={col.id}
                    className="bg-[#0C101A] border border-[#1A2234] rounded-2xl p-3.5 flex flex-col space-y-3 shadow-lg min-h-[500px]"
                  >
                    {/* Column Header */}
                    <div className="flex items-center justify-between pb-2 border-b border-[#182133] px-1">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: col.color }} />
                        <h3 className="font-bold text-xs text-white uppercase tracking-wider">{col.label}</h3>
                      </div>
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-[#141C2E] text-slate-400 font-semibold">
                        {columnTasks.length}
                      </span>
                    </div>

                    {/* Task Cards */}
                    <div className="space-y-3">
                      {columnTasks.map(task => (
                        <div
                          key={task.id}
                          onClick={() => setSelectedTask(task)}
                          className="p-4 rounded-xl bg-[#111726] border border-[#1E2940] hover:border-cyan-500/50 transition-all cursor-pointer space-y-3 shadow-sm hover:shadow-cyan-950/30 group"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono font-bold text-cyan-400">{task.id}</span>
                            {getPriorityBadge(task.priority)}
                          </div>

                          <h4 className="font-semibold text-xs text-white leading-snug group-hover:text-cyan-200 transition-colors">
                            {task.title}
                          </h4>

                          <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed font-sans">
                            {task.description}
                          </p>

                          {/* Subtasks Progress */}
                          {task.subtasks.length > 0 && (
                            <div className="space-y-1">
                              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                                <span>Checklist</span>
                                <span>{task.subtasks.filter(s => s.completed).length}/{task.subtasks.length}</span>
                              </div>
                              <div className="w-full h-1 bg-[#1A2234] rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-emerald-400"
                                  style={{ width: \`\${(task.subtasks.filter(s => s.completed).length / task.subtasks.length) * 100}%\` }}
                                />
                              </div>
                            </div>
                          )}

                          {/* Tags */}
                          <div className="flex flex-wrap gap-1">
                            {task.tags.map(tag => (
                              <span key={tag} className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#162035] text-slate-300 border border-[#232E4A]">
                                #{tag}
                              </span>
                            ))}
                          </div>

                          {/* Footer Info & Move Buttons */}
                          <div className="pt-2 border-t border-[#182133] flex items-center justify-between text-[11px]">
                            <div className="flex items-center gap-2">
                              <img
                                src={task.assignee.avatar}
                                alt={task.assignee.name}
                                className="w-5 h-5 rounded-full object-cover border border-slate-700"
                                title={task.assignee.name}
                              />
                              <span className="text-[10px] text-slate-400 font-mono">{task.estimatedHours}h</span>
                            </div>

                            <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                              {col.id !== 'backlog' && (
                                <button
                                  onClick={() => handleMoveTask(task.id, 'backward')}
                                  className="p-1 rounded bg-[#162035] hover:bg-cyan-950 text-slate-400 hover:text-cyan-300"
                                  title="Move Backward"
                                >
                                  <ArrowLeft className="w-3 h-3" />
                                </button>
                              )}
                              {col.id !== 'done' && (
                                <button
                                  onClick={() => handleMoveTask(task.id, 'forward')}
                                  className="p-1 rounded bg-[#162035] hover:bg-cyan-950 text-slate-400 hover:text-cyan-300"
                                  title="Move Forward"
                                >
                                  <ArrowRight className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}

                      {columnTasks.length === 0 && (
                        <div className="py-8 text-center border border-dashed border-[#1C2538] rounded-xl text-slate-500 text-xs">
                          No tasks in this lane
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* ========================================================
              VIEW 3: ACTIVITY TIMELINE
          ======================================================== */}
          {activeTab === 'timeline' && (
            <div className="max-w-3xl mx-auto p-6 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-6">
              <div className="flex items-center justify-between border-b border-[#1B2438] pb-4">
                <div>
                  <h3 className="font-bold text-base text-white">Sprint Activity Ledger</h3>
                  <p className="text-xs text-slate-400">Chronological stream of repository and task lifecycle updates.</p>
                </div>
                <span className="text-xs font-mono text-cyan-400">{activities.length} Recorded Events</span>
              </div>

              <div className="space-y-4 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#1C263C]">
                {activities.map(act => (
                  <div key={act.id} className="relative pl-8 space-y-1">
                    <div className="absolute left-1.5 top-1.5 w-3.5 h-3.5 rounded-full bg-[#111726] border-2 border-cyan-400" />
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-white">{act.user}</span>
                      <span className="text-[10px] font-mono text-slate-500">{act.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-300">
                      <span className="text-cyan-400 font-medium">{act.action}</span>{' '}
                      <span className="font-semibold text-white">{act.target}</span>
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ========================================================
              VIEW 4: TEAM MEMBERS & CAPACITY
          ======================================================== */}
          {activeTab === 'team' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
              {[
                { name: 'Elena Rostova', role: 'Staff Systems Architect', load: '85%', tasks: 3, avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120' },
                { name: 'Marcus Chen', role: 'Lead Design Engineer', load: '65%', tasks: 2, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120' },
                { name: 'Sarah Jenkins', role: 'Lead Backend Developer', load: '90%', tasks: 4, avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120' },
                { name: 'David Kim', role: 'DevOps & Reliability Engineer', load: '50%', tasks: 2, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120' }
              ].map(mem => (
                <div key={mem.name} className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] flex items-center gap-4 shadow-xl">
                  <img src={mem.avatar} alt={mem.name} className="w-14 h-14 rounded-2xl object-cover ring-2 ring-cyan-500/30" />
                  <div className="space-y-1 flex-1">
                    <h4 className="font-bold text-sm text-white">{mem.name}</h4>
                    <p className="text-xs text-cyan-400 font-mono">{mem.role}</p>
                    <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1">
                      <span>Assigned: {mem.tasks} tasks</span>
                      <span className="text-emerald-400 font-bold">{mem.load} Allocated</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ========================================================
              VIEW 5: SETTINGS
          ======================================================== */}
          {activeTab === 'settings' && (
            <div className="max-w-2xl mx-auto p-6 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
              <h3 className="font-bold text-base text-white">Project Environment</h3>
              <div className="space-y-2 text-xs font-mono text-slate-400">
                <div>WORKSPACE: <span className="text-cyan-300 font-bold">HYPERION_CORE_PROD</span></div>
                <div>DEFAULT SPRINT LENGTH: <span className="text-white">14 Calendar Days</span></div>
                <div>AUTOMATION WEBHOOKS: <span className="text-emerald-400">3 Active Listeners</span></div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* -------------------------------------------------------------
          TASK DETAIL MODAL / DRAWER
      ------------------------------------------------------------- */}
      {selectedTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-xl bg-[#0E1322] border border-[#232E4A] rounded-2xl p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-[#1E293E] pb-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-cyan-400">{selectedTask.id}</span>
                {getPriorityBadge(selectedTask.priority)}
              </div>
              <button onClick={() => setSelectedTask(null)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <h3 className="text-base font-bold text-white">{selectedTask.title}</h3>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">{selectedTask.description}</p>
            </div>

            {/* Subtasks checklist */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-300">Subtask Execution Checklist</div>
              <div className="space-y-1.5">
                {selectedTask.subtasks.map(st => (
                  <div
                    key={st.id}
                    onClick={() => handleToggleSubtask(selectedTask.id, st.id)}
                    className="flex items-center gap-2 p-2 rounded-lg bg-[#141B2D] border border-[#222D46] cursor-pointer hover:bg-[#1A233A]"
                  >
                    <div className={\`w-4 h-4 rounded flex items-center justify-center border \${st.completed ? 'bg-emerald-600 border-emerald-500 text-white' : 'border-slate-600'}\`}>
                      {st.completed && <Check className="w-3 h-3" />}
                    </div>
                    <span className={\`text-xs \${st.completed ? 'line-through text-slate-500' : 'text-slate-200'}\`}>
                      {st.title}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Assignee & Status Controls */}
            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-[#1E293E] text-xs">
              <div className="p-3 rounded-xl bg-[#141B2D] border border-[#222D46]">
                <span className="text-slate-400 text-[10px] block">Assignee</span>
                <span className="font-semibold text-white mt-1 block">{selectedTask.assignee.name}</span>
                <span className="text-cyan-400 text-[10px] font-mono">{selectedTask.assignee.role}</span>
              </div>
              <div className="p-3 rounded-xl bg-[#141B2D] border border-[#222D46]">
                <span className="text-slate-400 text-[10px] block">Status Lane</span>
                <span className="font-semibold text-emerald-400 uppercase font-mono mt-1 block">
                  {selectedTask.status.replace('_', ' ')}
                </span>
                <span className="text-slate-400 text-[10px] font-mono">{selectedTask.estimatedHours} Hours scope</span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-2 border-t border-[#1E293E]">
              <button
                onClick={() => handleDeleteTask(selectedTask.id)}
                className="px-3 py-1.5 rounded-xl bg-rose-950/60 hover:bg-rose-900 border border-rose-800 text-rose-300 text-xs font-semibold flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Task</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleMoveTask(selectedTask.id, 'backward')}
                  disabled={selectedTask.status === 'backlog'}
                  className="px-3 py-1.5 rounded-xl bg-[#172033] hover:bg-[#1E2B46] text-white text-xs font-semibold disabled:opacity-40"
                >
                  ← Move Back
                </button>
                <button
                  onClick={() => handleMoveTask(selectedTask.id, 'forward')}
                  disabled={selectedTask.status === 'done'}
                  className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs disabled:opacity-40"
                >
                  Move Forward →
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* -------------------------------------------------------------
          CREATE TASK MODAL
      ------------------------------------------------------------- */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#0E1322] border border-[#232E4A] rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#1E293E] pb-3">
              <h3 className="font-bold text-sm text-white">Create New Task</h3>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">Task Title</label>
                <input
                  type="text"
                  autoFocus
                  required
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  placeholder="e.g. Implement OIDC token exchange..."
                  className="w-full h-9 px-3 bg-[#151A2B] border border-[#232E4A] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">Description</label>
                <textarea
                  rows={3}
                  value={newTaskDesc}
                  onChange={(e) => setNewTaskDesc(e.target.value)}
                  placeholder="Task implementation details..."
                  className="w-full p-2.5 bg-[#151A2B] border border-[#232E4A] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 resize-none font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Priority</label>
                  <select
                    value={newTaskPriority}
                    onChange={(e) => setNewTaskPriority(e.target.value as any)}
                    className="w-full h-9 px-2 bg-[#151A2B] border border-[#232E4A] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="urgent">Urgent</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Assignee</label>
                  <select
                    value={newTaskAssignee}
                    onChange={(e) => setNewTaskAssignee(e.target.value)}
                    className="w-full h-9 px-2 bg-[#151A2B] border border-[#232E4A] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Elena Rostova">Elena Rostova</option>
                    <option value="Marcus Chen">Marcus Chen</option>
                    <option value="Sarah Jenkins">Sarah Jenkins</option>
                    <option value="David Kim">David Kim</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Estimated Hours</label>
                  <input
                    type="number"
                    min={1}
                    max={80}
                    value={newTaskHours}
                    onChange={(e) => setNewTaskHours(Number(e.target.value))}
                    className="w-full h-9 px-3 bg-[#151A2B] border border-[#232E4A] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Tags</label>
                  <input
                    type="text"
                    value={newTaskTags}
                    onChange={(e) => setNewTaskTags(e.target.value)}
                    placeholder="ui, core, api"
                    className="w-full h-9 px-3 bg-[#151A2B] border border-[#232E4A] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1E293E]">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-3.5 py-1.5 rounded-xl text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md"
                >
                  Create Issue
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
`;
    files['src/App.tsx'] = projectManagementAppCode;
    return finalizeResult({
      files,
      name: 'Hyperion Project Management Suite',
      description: 'Professional project management application with interactive Kanban board, project overview stats, task details modal, and team activity timeline.',
      summary: 'Created premium project management suite with Kanban board, task details, filters, and activity timeline in `src/App.tsx`.',
      entryFile: 'src/App.tsx',
      reactCode: projectManagementAppCode
    });
  }

  // =========================================================================
  // 5. Specialized: Notes Workspace
  // =========================================================================
  if (isNotesRequested(p)) {
    const notesAppCode = NOVANOTES_PROJECT.files['src/App.tsx'] || '';
    files['src/App.tsx'] = notesAppCode;
    return finalizeResult({
      files,
      name: 'Notes Workspace',
      description: 'Notes workspace template with markdown editing, semantic tags, voice memos, search, pinned notes, and dark mode. AI-backed actions require a configured provider.',
      summary: 'Created a Notes Workspace template in `src/App.tsx`.',
      entryFile: 'src/App.tsx',
      reactCode: notesAppCode
    });
  }

  // =========================================================================
  // 6. Specialized: Aura Music Player & Sound Studio
  // =========================================================================
  if (isMusicPlayerRequested(p)) {
    const musicPlayerAppCode = `import React, { useState, useEffect } from 'react';
import { 
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, 
  Music, Heart, Shuffle, Repeat, Search, Disc3, Sparkles, 
  ListMusic, Radio, SlidersHorizontal, Check, Clock
} from 'lucide-react';

export interface TrackItem {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number;
  genre: 'Synthwave' | 'Cyberpunk' | 'Ambient' | 'Lo-Fi';
  accentColor: string;
}

export default function MusicPlayerApp() {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(80);
  const [isMuted, setIsMuted] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isRepeat, setIsRepeat] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string>('All');
  const [likedTrackIds, setLikedTrackIds] = useState<string[]>(['trk-1', 'trk-3']);
  const [eqPreset, setEqPreset] = useState<'Balanced' | 'Bass Boost' | 'Electronic' | 'Vocal'>('Balanced');

  const tracks: TrackItem[] = [
    { id: 'trk-1', title: 'Midnight City Highway', artist: 'Neon Horizon', album: 'Retrowave 2088', duration: 218, genre: 'Synthwave', accentColor: 'from-cyan-500 to-blue-600' },
    { id: 'trk-2', title: 'Neural Pulse Drift', artist: 'CyberPulse', album: 'Synapse Protocol', duration: 195, genre: 'Cyberpunk', accentColor: 'from-fuchsia-500 to-purple-700' },
    { id: 'trk-3', title: 'Starlight Resonance', artist: 'Astral Drift', album: 'Cosmic Horizons', duration: 242, genre: 'Ambient', accentColor: 'from-emerald-500 to-teal-700' },
    { id: 'trk-4', title: 'Tokyo Rain & Coffee', artist: 'LoFi Beats Lab', album: 'Rainy Afternoon', duration: 164, genre: 'Lo-Fi', accentColor: 'from-amber-500 to-orange-700' },
    { id: 'trk-5', title: 'Quantum Velocity', artist: 'Hyperion Sound', album: 'Warp Speed', duration: 206, genre: 'Cyberpunk', accentColor: 'from-violet-500 to-indigo-800' },
    { id: 'trk-6', title: 'Deep Space Reverie', artist: 'Solaris Wave', album: 'Zero Gravity', duration: 280, genre: 'Ambient', accentColor: 'from-sky-500 to-indigo-600' }
  ];

  const currentTrack = tracks[currentIdx] || tracks[0];

  useEffect(() => {
    if (!isPlaying) return;
    const timer = setInterval(() => {
      setCurrentTime(prev => {
        if (prev >= currentTrack.duration) {
          if (isRepeat) return 0;
          handleNextTrack();
          return 0;
        }
        return prev + 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isPlaying, currentTrack.duration, isRepeat]);

  const handleNextTrack = () => {
    if (isShuffle) {
      const nextIdx = Math.floor(Math.random() * tracks.length);
      setCurrentIdx(nextIdx);
    } else {
      setCurrentIdx(prev => (prev + 1) % tracks.length);
    }
    setCurrentTime(0);
  };

  const handlePrevTrack = () => {
    if (currentTime > 4) {
      setCurrentTime(0);
    } else {
      setCurrentIdx(prev => (prev === 0 ? tracks.length - 1 : prev - 1));
      setCurrentTime(0);
    }
  };

  const togglePlay = () => {
    setIsPlaying(prev => !prev);
  };

  const toggleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikedTrackIds(prev => prev.includes(id) ? prev.filter(t => t !== id) : [...prev, id]);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return m + ':' + (s < 10 ? '0' : '') + s;
  };

  const filteredTracks = tracks.filter(t => {
    const matchesSearch = t.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          t.artist.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = selectedGenre === 'All' || t.genre === selectedGenre;
    return matchesSearch && matchesGenre;
  });

  return (
    <div className="flex h-screen w-full bg-[#080B14] text-slate-100 font-sans select-none overflow-hidden">
      {/* Sidebar: Track Library */}
      <aside className="hidden lg:flex flex-col w-80 bg-[#0C101C] border-r border-[#1C2337] shrink-0">
        <div className="h-16 px-6 border-b border-[#1C2337] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-violet-950 border border-violet-800 flex items-center justify-center text-violet-400">
              <Music className="w-4 h-4" />
            </div>
            <div>
              <div className="font-extrabold text-sm text-white">Aura Music</div>
              <div className="text-[10px] text-violet-400 font-mono">SOUND STUDIO</div>
            </div>
          </div>
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-violet-950/80 text-violet-300 border border-violet-800/60">
            {tracks.length} Tracks
          </span>
        </div>

        {/* Search & Genre Chips */}
        <div className="p-4 border-b border-[#1C2337] space-y-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search tracks or artists..."
              className="w-full h-8 pl-8 pr-3 bg-[#131828] border border-[#232C45] rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-violet-500"
            />
          </div>
          <div className="flex flex-wrap gap-1.5">
            {['All', 'Synthwave', 'Cyberpunk', 'Ambient', 'Lo-Fi'].map(g => (
              <button
                key={g}
                onClick={() => setSelectedGenre(g)}
                className={"px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors " + (selectedGenre === g ? "bg-violet-900/60 text-violet-300 border border-violet-700" : "bg-[#131828] text-slate-400 hover:text-white border border-[#232C45]")}
              >
                {g}
              </button>
            ))}
          </div>
        </div>

        {/* Playlist List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1">
          {filteredTracks.map((track) => {
            const isSelected = track.id === currentTrack.id;
            const isLiked = likedTrackIds.includes(track.id);
            return (
              <div
                key={track.id}
                onClick={() => {
                  const idx = tracks.findIndex(t => t.id === track.id);
                  if (idx !== -1) {
                    setCurrentIdx(idx);
                    setCurrentTime(0);
                    setIsPlaying(true);
                  }
                }}
                className={"w-full p-2.5 rounded-xl flex items-center justify-between transition-all cursor-pointer " + (isSelected ? "bg-violet-950/60 border border-violet-800/80 shadow-md" : "hover:bg-[#131828] border border-transparent")}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className={"w-9 h-9 rounded-lg bg-gradient-to-tr " + track.accentColor + " flex items-center justify-center shrink-0 shadow-sm"}>
                    <Disc3 className={"w-4 h-4 text-white " + (isSelected && isPlaying ? "animate-spin" : "")} />
                  </div>
                  <div className="min-w-0 text-left">
                    <div className={"text-xs font-bold truncate " + (isSelected ? "text-violet-300" : "text-white")}>
                      {track.title}
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">{track.artist}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button onClick={(e) => toggleLike(track.id, e)} className="p-1 text-slate-500 hover:text-rose-400">
                    <Heart className={"w-3.5 h-3.5 " + (isLiked ? "text-rose-400 fill-rose-400" : "")} />
                  </button>
                  <span className="text-[10px] font-mono text-slate-400">{formatTime(track.duration)}</span>
                </div>
              </div>
            );
          })}
        </div>
      </aside>

      {/* Main Stage: Player & Turntable */}
      <main className="flex-1 flex flex-col overflow-y-auto">
        <header className="h-16 px-6 border-b border-[#1C2337] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
              {isPlaying ? 'NOW PLAYING' : 'READY'}
            </span>
            <span className="text-xs text-slate-400 font-mono">{currentTrack.genre} • {currentTrack.album}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-400">PRESET:</span>
            <select
              value={eqPreset}
              onChange={(e) => setEqPreset(e.target.value as any)}
              className="h-8 px-2.5 bg-[#131828] border border-[#232C45] rounded-lg text-xs text-violet-300 focus:outline-none focus:border-violet-500"
            >
              <option value="Balanced">Balanced</option>
              <option value="Bass Boost">Bass Boost</option>
              <option value="Electronic">Electronic</option>
              <option value="Vocal">Vocal</option>
            </select>
          </div>
        </header>

        <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-8 max-w-2xl mx-auto w-full">
          {/* Album Vinyl / Art Display */}
          <div className="relative group">
            <div className={"w-56 h-56 sm:w-64 sm:h-64 rounded-3xl bg-gradient-to-tr " + currentTrack.accentColor + " p-1 shadow-2xl flex items-center justify-center relative overflow-hidden"}>
              <div className="absolute inset-0 bg-black/20" />
              <div className={"w-44 h-44 sm:w-48 sm:h-48 rounded-full border-4 border-white/20 flex items-center justify-center relative shadow-inner " + (isPlaying ? "animate-spin" : "")} style={{ animationDuration: '6s' }}>
                <div className="w-16 h-16 rounded-full bg-[#080B14] border-2 border-white/30 flex items-center justify-center">
                  <div className="w-5 h-5 rounded-full bg-violet-500" />
                </div>
              </div>
            </div>
            <button
              onClick={() => toggleLike(currentTrack.id, { stopPropagation: () => {} } as any)}
              className="absolute top-4 right-4 p-2.5 rounded-full bg-black/60 backdrop-blur-md text-white hover:text-rose-400 transition-colors shadow-lg"
            >
              <Heart className={"w-5 h-5 " + (likedTrackIds.includes(currentTrack.id) ? "text-rose-400 fill-rose-400" : "")} />
            </button>
          </div>

          {/* Track Info */}
          <div className="text-center space-y-1">
            <h1 className="text-xl sm:text-2xl font-extrabold text-white">{currentTrack.title}</h1>
            <p className="text-sm text-violet-300 font-medium">{currentTrack.artist} — <span className="text-slate-400">{currentTrack.album}</span></p>
          </div>

          {/* Live Audio Visualizer Spectrum */}
          <div className="w-full flex items-end justify-center gap-1.5 h-14 px-8">
            {[45, 60, 30, 80, 95, 70, 50, 85, 100, 65, 40, 90, 75, 55, 80, 45].map((h, i) => {
              const height = isPlaying ? Math.min(100, Math.max(15, h * (0.6 + Math.sin(currentTime * 3 + i) * 0.4))) : 12;
              return (
                <div
                  key={i}
                  className="w-2.5 rounded-full bg-gradient-to-t from-violet-600 to-cyan-400 transition-all duration-150"
                  style={{ height: height + '%' }}
                />
              );
            })}
          </div>

          {/* Scrubber / Seeker Bar */}
          <div className="w-full space-y-2">
            <div className="relative flex items-center">
              <input
                type="range"
                min={0}
                max={currentTrack.duration}
                value={currentTime}
                onChange={(e) => setCurrentTime(Number(e.target.value))}
                className="w-full h-2 bg-[#1C2337] rounded-lg appearance-none cursor-pointer accent-violet-500"
              />
            </div>
            <div className="flex justify-between text-xs font-mono text-slate-400">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(currentTrack.duration)}</span>
            </div>
          </div>

          {/* Playback Transport Controls */}
          <div className="flex items-center justify-center gap-6">
            <button
              onClick={() => setIsShuffle(prev => !prev)}
              className={"p-2 rounded-xl transition-colors " + (isShuffle ? "text-violet-400 bg-violet-950/60 border border-violet-800" : "text-slate-400 hover:text-white")}
              title="Shuffle"
            >
              <Shuffle className="w-4 h-4" />
            </button>

            <button
              onClick={handlePrevTrack}
              className="p-3 rounded-full bg-[#131828] hover:bg-[#1C2337] text-white border border-[#232C45] transition-all hover:scale-105"
              title="Previous"
            >
              <SkipBack className="w-5 h-5" />
            </button>

            <button
              onClick={togglePlay}
              className="p-5 rounded-full bg-gradient-to-tr from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white shadow-xl shadow-violet-600/30 transition-all hover:scale-105 active:scale-95"
              title={isPlaying ? "Pause" : "Play"}
            >
              {isPlaying ? <Pause className="w-6 h-6 fill-white" /> : <Play className="w-6 h-6 fill-white ml-0.5" />}
            </button>

            <button
              onClick={handleNextTrack}
              className="p-3 rounded-full bg-[#131828] hover:bg-[#1C2337] text-white border border-[#232C45] transition-all hover:scale-105"
              title="Next"
            >
              <SkipForward className="w-5 h-5" />
            </button>

            <button
              onClick={() => setIsRepeat(prev => !prev)}
              className={"p-2 rounded-xl transition-colors " + (isRepeat ? "text-violet-400 bg-violet-950/60 border border-violet-800" : "text-slate-400 hover:text-white")}
              title="Repeat"
            >
              <Repeat className="w-4 h-4" />
            </button>
          </div>

          {/* Volume Control */}
          <div className="flex items-center gap-3 w-64 bg-[#0C101C] px-4 py-2 rounded-2xl border border-[#1C2337]">
            <button onClick={() => setIsMuted(prev => !prev)} className="text-slate-400 hover:text-white">
              {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <input
              type="range"
              min={0}
              max={100}
              value={isMuted ? 0 : volume}
              onChange={(e) => {
                setVolume(Number(e.target.value));
                if (isMuted) setIsMuted(false);
              }}
              className="w-full h-1.5 bg-[#1C2337] rounded-lg appearance-none cursor-pointer accent-violet-500"
            />
            <span className="text-[11px] font-mono text-slate-400 w-8 text-right">{isMuted ? '0%' : volume + '%'}</span>
          </div>
        </div>
      </main>
    </div>
  );
}`;
    files['src/App.tsx'] = musicPlayerAppCode;
    return finalizeResult({
      files,
      name: 'Aura Music Player & Sound Studio',
      description: 'Interactive audio streaming and music player with visualizer, playlists, EQ presets, volume control, and audio playback.',
      summary: 'Created Aura Music Player & Sound Studio in `src/App.tsx`.',
      entryFile: 'src/App.tsx',
      reactCode: musicPlayerAppCode
    });
  }

  // =========================================================================
  // 7. Specialized: Apex Enterprise — Modern Business Showcase Website
  // =========================================================================
  if (isBusinessWebsiteRequested(p)) {
    const businessWebsiteAppCode = `import React, { useState } from 'react';
import { 
  Building2, ArrowRight, ShieldCheck, Zap, Globe, CheckCircle2, 
  BarChart3, Users, Star, Mail, Phone, MapPin, Menu, X, 
  Sparkles, Check, ChevronRight, Send, Award
} from 'lucide-react';

export default function BusinessWebsiteApp() {
  const [activeTab, setActiveTab] = useState<'home' | 'services' | 'pricing' | 'about' | 'contact'>('home');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual');
  const [contactSubmitted, setContactSubmitted] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', company: '', message: '' });

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) return;
    setContactSubmitted(true);
    setTimeout(() => {
      setContactSubmitted(false);
      setFormData({ name: '', email: '', company: '', message: '' });
    }, 4000);
  };

  const services = [
    {
      icon: Zap,
      title: 'Autonomous AI Integration',
      desc: 'Deploy self-healing, multi-agent AI pipelines into production systems with sub-50ms latency SLAs.'
    },
    {
      icon: ShieldCheck,
      title: 'Zero-Trust Cybersecurity',
      desc: 'End-to-end cryptographic provenance, vulnerability hardening, and continuous SOC2 compliance audits.'
    },
    {
      icon: BarChart3,
      title: 'Real-Time Enterprise Analytics',
      desc: 'Stream high-frequency operational telemetry across global microservices with sub-second OLAP querying.'
    },
    {
      icon: Globe,
      title: 'Multi-Region Cloud Architecture',
      desc: 'Highly resilient multi-cloud failover infrastructure ensuring 99.999% guaranteed enterprise uptime.'
    }
  ];

  const pricingTiers = [
    {
      name: 'Starter',
      monthlyPrice: '$49',
      annualPrice: '$39',
      desc: 'Essential infrastructure and AI workflows for high-growth tech startups.',
      features: ['Up to 5 autonomous agents', '100,000 monthly telemetry events', 'Community & email support', 'Standard 99.9% uptime SLA']
    },
    {
      name: 'Enterprise Growth',
      monthlyPrice: '$199',
      annualPrice: '$159',
      popular: true,
      desc: 'Comprehensive multi-agent cluster with dedicated sandboxed execution environments.',
      features: ['Up to 25 autonomous agents', '5,000,000 monthly telemetry events', 'Priority 24/7 engineering support', 'Surgical AST safe mutations', 'Custom domain & SSO auth']
    },
    {
      name: 'Global Scale',
      monthlyPrice: '$499',
      annualPrice: '$399',
      desc: 'Unlimited scale and tailored enterprise infrastructure with dedicated compliance.',
      features: ['Unlimited autonomous agents', 'Dedicated VPC & on-premise bridging', 'Designated Solutions Architect', '99.999% SLA uptime guarantee', 'Custom LLM fine-tuning']
    }
  ];

  return (
    <div className="min-h-screen w-full bg-[#070A12] text-slate-100 font-sans select-none overflow-x-hidden">
      {/* Navigation Bar */}
      <nav className="sticky top-0 z-50 bg-[#0A0E1A]/90 backdrop-blur-md border-b border-[#1A2238]">
        <div className="max-w-7xl mx-auto px-6 h-18 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <span className="font-extrabold text-base tracking-tight text-white">Apex Enterprise</span>
              <span className="hidden sm:inline-block ml-2 text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">SOLUTIONS</span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-8">
            {[
              { id: 'home', label: 'Overview' },
              { id: 'services', label: 'Services' },
              { id: 'pricing', label: 'Pricing' },
              { id: 'contact', label: 'Contact' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={"text-xs font-semibold transition-colors " + (activeTab === tab.id ? "text-cyan-400 font-bold" : "text-slate-400 hover:text-white")}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={() => setActiveTab('contact')}
              className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg shadow-cyan-600/20 transition-all hover:scale-105"
            >
              Request Demo
            </button>
          </div>

          <button onClick={() => setMobileMenuOpen(prev => !prev)} className="md:hidden text-slate-400 p-2">
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden p-4 bg-[#0A0E1A] border-b border-[#1A2238] space-y-2">
            {['home', 'services', 'pricing', 'contact'].map(tab => (
              <button
                key={tab}
                onClick={() => { setActiveTab(tab as any); setMobileMenuOpen(false); }}
                className="w-full text-left py-2 px-3 text-xs font-semibold text-slate-300 hover:text-white capitalize"
              >
                {tab}
              </button>
            ))}
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 px-6 max-w-7xl mx-auto text-center space-y-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-800/80 text-cyan-300 text-xs font-mono">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Next-Generation Enterprise Autonomous Cloud</span>
        </div>

        <h1 className="text-4xl sm:text-6xl font-extrabold text-white tracking-tight max-w-4xl mx-auto leading-tight">
          Accelerate Business Growth with <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400">Autonomous Engineering</span>
        </h1>

        <p className="text-base sm:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Apex Enterprise empowers modern businesses with resilient cloud architecture, autonomous AI automation, and zero-trust security infrastructure.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <button
            onClick={() => setActiveTab('pricing')}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-sm shadow-xl shadow-cyan-600/25 flex items-center justify-center gap-2 transition-all hover:scale-105"
          >
            <span>Explore Enterprise Plans</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => setActiveTab('contact')}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-[#11182B] hover:bg-[#1A243F] text-slate-200 border border-[#233154] font-semibold text-sm transition-all"
          >
            Schedule Product Tour
          </button>
        </div>

        {/* Enterprise Proof Bar */}
        <div className="pt-12 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto border-t border-[#1A2238]">
          {[
            { metric: '$450M+', label: 'Client Value Delivered' },
            { metric: '99.999%', label: 'Guaranteed SLA Uptime' },
            { metric: '1,200+', label: 'Enterprise Deployments' },
            { metric: '<12ms', label: 'Global API Latency' }
          ].map(stat => (
            <div key={stat.label} className="space-y-1">
              <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono">{stat.metric}</div>
              <div className="text-xs text-slate-400 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 px-6 bg-[#0A0F1D] border-y border-[#1A2238]">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="text-center space-y-3 max-w-2xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">Engineered for High-Scale Operations</h2>
            <p className="text-xs sm:text-sm text-slate-400">Everything your team needs to deploy, scale, and govern mission-critical enterprise systems.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map(svc => {
              const Icon = svc.icon;
              return (
                <div key={svc.title} className="p-6 rounded-2xl bg-[#0F1528] border border-[#1E2947] space-y-4 hover:border-cyan-500/40 transition-all shadow-lg">
                  <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-base text-white">{svc.title}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">{svc.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Interactive Pricing Section */}
      <section className="py-20 px-6 max-w-7xl mx-auto space-y-12">
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">Transparent, Scalable Pricing</h2>
          <p className="text-xs sm:text-sm text-slate-400">Predictable infrastructure costs designed to scale as your company grows.</p>

          <div className="inline-flex items-center p-1 rounded-xl bg-[#0F1528] border border-[#1E2947] gap-2">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={"px-3 py-1.5 rounded-lg text-xs font-semibold transition-all " + (billingCycle === 'monthly' ? "bg-cyan-600 text-white" : "text-slate-400 hover:text-white")}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle('annual')}
              className={"px-3 py-1.5 rounded-lg text-xs font-semibold transition-all " + (billingCycle === 'annual' ? "bg-cyan-600 text-white" : "text-slate-400 hover:text-white")}
            >
              Annual <span className="ml-1 text-[10px] text-emerald-300 font-bold bg-emerald-950 px-1 rounded border border-emerald-800">SAVE 20%</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pricingTiers.map(tier => (
            <div
              key={tier.name}
              className={"p-8 rounded-3xl flex flex-col justify-between space-y-6 " + (tier.popular ? "bg-[#0E1529] border-2 border-cyan-500 shadow-2xl relative" : "bg-[#0A0F1D] border border-[#1A2238]")}
            >
              {tier.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-cyan-500 text-slate-950 font-extrabold text-[10px] uppercase tracking-wide">
                  Most Popular
                </div>
              )}
              <div className="space-y-4">
                <h3 className="font-bold text-lg text-white">{tier.name}</h3>
                <p className="text-xs text-slate-400">{tier.desc}</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-extrabold text-white font-mono">
                    {billingCycle === 'annual' ? tier.annualPrice : tier.monthlyPrice}
                  </span>
                  <span className="text-xs text-slate-500 font-mono">/month</span>
                </div>
                <div className="space-y-2.5 pt-4 border-t border-[#1E2947]">
                  {tier.features.map(f => (
                    <div key={f} className="flex items-center gap-2 text-xs text-slate-300">
                      <Check className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>{f}</span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => setActiveTab('contact')}
                className={"w-full py-3 rounded-xl font-bold text-xs transition-all " + (tier.popular ? "bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg" : "bg-[#141C33] hover:bg-[#1E2A4D] text-slate-200 border border-[#233154]")}
              >
                Choose {tier.name}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Contact & Demo Request Form */}
      <section className="py-16 px-6 bg-[#0A0F1D] border-t border-[#1A2238]">
        <div className="max-w-3xl mx-auto p-8 rounded-3xl bg-[#0F1528] border border-[#1E2947] space-y-6 shadow-2xl">
          <div className="text-center space-y-2">
            <h2 className="text-2xl font-extrabold text-white">Partner With Apex Enterprise</h2>
            <p className="text-xs text-slate-400">Our senior solutions architects respond within 24 hours.</p>
          </div>

          {contactSubmitted ? (
            <div className="p-6 rounded-2xl bg-emerald-950/80 border border-emerald-800 text-center space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
              <div className="font-bold text-sm text-white">Thank You! Your Request Has Been Received.</div>
              <p className="text-xs text-emerald-300">Our enterprise team will reach out with a tailored solutions architecture proposal.</p>
            </div>
          ) : (
            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Jane Doe"
                    className="w-full h-10 px-3 bg-[#141C33] border border-[#233154] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Business Email *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="jane@company.com"
                    className="w-full h-10 px-3 bg-[#141C33] border border-[#233154] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Company / Organization</label>
                <input
                  type="text"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  placeholder="Acme Enterprises Inc."
                  className="w-full h-10 px-3 bg-[#141C33] border border-[#233154] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Project Scope & Requirements</label>
                <textarea
                  rows={3}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Tell us about your scalability and architecture objectives..."
                  className="w-full p-3 bg-[#141C33] border border-[#233154] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg shadow-cyan-600/25 flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Submit Enterprise Inquiry</span>
              </button>
            </form>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-[#1A2238] text-center text-xs text-slate-500">
        <p>© 2026 Apex Enterprise Solutions Inc. All rights reserved. Certified Autonomous Cloud Platform.</p>
      </footer>
    </div>
  );
}`;
    files['src/App.tsx'] = businessWebsiteAppCode;
    return finalizeResult({
      files,
      name: 'Apex Enterprise — Modern Business Showcase',
      description: 'Full-scale modern business website featuring dynamic hero section, enterprise services grid, interactive pricing tiers, client testimonials, and contact form.',
      summary: 'Created modern business website in `src/App.tsx`.',
      entryFile: 'src/App.tsx',
      reactCode: businessWebsiteAppCode
    });
  }

  // =========================================================================
  // 8. Universal Domain Synthesizer for Any Arbitrary Application Prompt
  // =========================================================================
  const compilation = UniversalDesignSystem.compileForApp(prompt, existingFiles);

  // Clean and intelligent displayTitle extraction
  const STOP_WORDS = new Set([
    'mere', 'liye', 'karo', 'kar', 'do', 'deh', 'de', 'ek', 'aur', 'ko', 'se', 'bana', 'banao', 'banado', 'banaye', 'likho', 'chahiye',
    'build', 'create', 'make', 'generate', 'develop', 'construct', 'please', 'for', 'the', 'and', 'with', 'from', 'app', 'application',
    'tool', 'system', 'website', 'new', 'some', 'any', 'that', 'this', 'into', 'my'
  ]);
  const cleanWords = prompt
    .replace(/[^a-zA-Z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 2 && !STOP_WORDS.has(w.toLowerCase()));

  const displayTitle = cleanWords.length > 0
    ? cleanWords.slice(0, 3).map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ') + ' Studio'
    : 'New App';
  const isSinglePane = compilation.iaSpec.layoutStructure.navigationType === 'compact_dock' || compilation.personality.layoutArchetype === 'centered_feed' || compilation.category === 'productivity' || compilation.category === 'general';

  let universalAppCode = '';

  if (isSinglePane) {
    universalAppCode = `import React, { useState } from 'react';
import { 
  Sparkles, Plus, Trash2, CheckCircle2, Circle, 
  Search, Filter, Tag, Calendar, Edit3, X, Check, ArrowRight
} from 'lucide-react';

export interface WorkItem {
  id: string;
  title: string;
  category: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
  notes?: string;
}

export default function App() {
  const [items, setItems] = useState<WorkItem[]>([
    { id: 'item-1', title: 'Initialize ${displayTitle} Core Setup', category: 'Core', completed: true, priority: 'high', createdAt: 'Today', notes: 'Configured core domain entities and verified state persistence.' },
    { id: 'item-2', title: 'Review System Specifications & Taxonomy', category: 'Planning', completed: false, priority: 'medium', createdAt: 'Today', notes: 'Ensure responsive breakpoints and accessibility standards are satisfied.' },
    { id: 'item-3', title: 'Optimize User Interaction & Feedback Loop', category: 'Execution', completed: false, priority: 'high', createdAt: 'Yesterday', notes: 'Verify micro-interactions and smooth state transitions across all devices.' },
    { id: 'item-4', title: 'Execute Verification & Evidence Audit', category: 'Testing', completed: false, priority: 'low', createdAt: '2 days ago', notes: 'Verify 6-pillar static and runtime evidence before final sign-off.' }
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newItemTitle, setNewItemTitle] = useState('');
  const [newItemCategory, setNewItemCategory] = useState('Core');
  const [newItemPriority, setNewItemPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [newItemNotes, setNewItemNotes] = useState('');

  const categories = ['all', 'Core', 'Planning', 'Execution', 'Testing'];

  const filteredItems = items.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (item.notes && item.notes.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCat = activeCategory === 'all' || item.category === activeCategory;
    return matchesSearch && matchesCat;
  });

  const completedCount = items.filter(i => i.completed).length;

  const handleToggle = (id: string) => {
    setItems(prev => prev.map(i => i.id === id ? { ...i, completed: !i.completed } : i));
  };

  const handleDelete = (id: string) => {
    setItems(prev => prev.filter(i => i.id !== id));
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemTitle.trim()) return;

    const newItem: WorkItem = {
      id: \`item-\${Date.now().toString().slice(-4)}\`,
      title: newItemTitle.trim(),
      category: newItemCategory,
      completed: false,
      priority: newItemPriority,
      createdAt: 'Just now',
      notes: newItemNotes.trim() || undefined
    };

    setItems(prev => [newItem, ...prev]);
    setNewItemTitle('');
    setNewItemNotes('');
    setIsCreateModalOpen(false);
  };

  return (
    <div className="min-h-screen w-full bg-[#090D16] text-slate-100 font-sans p-4 sm:p-6 md:p-8 flex flex-col items-center">
      <div className="w-full max-w-4xl space-y-6">
        {/* Header */}
        <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-[#1C263C]">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400">
                <Sparkles className="w-4 h-4" />
              </div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">${displayTitle}</h1>
            </div>
            <p className="text-xs text-slate-400">Professional productivity manager with live filters and real-time state tracking.</p>
          </div>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md transition-all min-h-[44px]"
          >
            <Plus className="w-4 h-4" />
            <span className="whitespace-nowrap">Add New Item</span>
          </button>
        </header>

        {/* Progress & Metrics Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-4 rounded-xl bg-[#0E1424] border border-[#1C263C]">
            <div className="text-[11px] text-slate-400 font-medium">TOTAL ITEMS</div>
            <div className="text-xl font-extrabold font-mono text-white mt-1">{items.length}</div>
          </div>
          <div className="p-4 rounded-xl bg-[#0E1424] border border-[#1C263C]">
            <div className="text-[11px] text-slate-400 font-medium">COMPLETED</div>
            <div className="text-xl font-extrabold font-mono text-emerald-400 mt-1">{completedCount}</div>
          </div>
          <div className="p-4 rounded-xl bg-[#0E1424] border border-[#1C263C]">
            <div className="text-[11px] text-slate-400 font-medium">PENDING</div>
            <div className="text-xl font-extrabold font-mono text-cyan-400 mt-1">{items.length - completedCount}</div>
          </div>
          <div className="p-4 rounded-xl bg-[#0E1424] border border-[#1C263C]">
            <div className="text-[11px] text-slate-400 font-medium">PROGRESS</div>
            <div className="text-xl font-extrabold font-mono text-indigo-400 mt-1">
              {items.length > 0 ? Math.round((completedCount / items.length) * 100) : 0}%
            </div>
          </div>
        </div>

        {/* Controls: Search and Categories */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search items, tags, or notes..."
              className="w-full h-10 pl-9 pr-4 bg-[#0E1424] border border-[#1C263C] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 min-h-[44px]"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={\`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors min-h-[38px] \${
                  activeCategory === cat
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                    : 'bg-[#0E1424] text-slate-400 border border-[#1C263C] hover:text-white'
                }\`}
              >
                {cat.charAt(0).toUpperCase() + cat.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Main Item List */}
        <main className="space-y-3">
          {filteredItems.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-[#0E1424] border border-[#1C263C] space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-[#141C2E] border border-[#232E4A] mx-auto flex items-center justify-center text-slate-400">
                <Filter className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">No Matching Items Found</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                {searchQuery || activeCategory !== 'all'
                  ? 'No items match your active search or category filters. Try clearing the filters.'
                  : 'Your workspace is currently empty. Click the button above to add your first item.'}
              </p>
              {(searchQuery || activeCategory !== 'all') && (
                <button
                  onClick={() => { setSearchQuery(''); setActiveCategory('all'); }}
                  className="px-3 py-1.5 rounded-lg bg-[#141C2E] text-cyan-400 hover:text-cyan-300 text-xs font-semibold border border-[#232E4A]"
                >
                  Reset Filters
                </button>
              )}
            </div>
          ) : (
            filteredItems.map(item => (
              <div
                key={item.id}
                className={\`p-4 rounded-xl bg-[#0E1424] border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 \${
                  item.completed ? 'border-[#1C263C] opacity-75' : 'border-[#1C263C] hover:border-cyan-800/60'
                }\`}
              >
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <button
                    onClick={() => handleToggle(item.id)}
                    className="mt-0.5 p-1 rounded-lg text-slate-400 hover:text-cyan-400 transition-colors min-h-[36px] min-w-[36px] flex items-center justify-center"
                    aria-label="Toggle item status"
                  >
                    {item.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-500" />
                    )}
                  </button>

                  <div className="space-y-1 flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={\`text-sm font-semibold \${item.completed ? 'line-through text-slate-500' : 'text-white'}\`}>
                        {item.title}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#141C2E] border border-[#232E4A] text-slate-300 whitespace-nowrap">
                        {item.category}
                      </span>
                      <span className={\`px-1.5 py-0.5 rounded text-[9px] font-mono uppercase font-bold whitespace-nowrap \${
                        item.priority === 'high' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                        item.priority === 'medium' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                        'bg-slate-800 text-slate-400 border border-slate-700'
                      }\`}>
                        {item.priority}
                      </span>
                    </div>

                    {item.notes && (
                      <p className="text-xs text-slate-400 line-clamp-2">{item.notes}</p>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-3 pl-11 sm:pl-0 border-t sm:border-t-0 border-[#1C263C] pt-2 sm:pt-0">
                  <span className="text-[11px] font-mono text-slate-500">{item.createdAt}</span>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="p-2 rounded-lg hover:bg-rose-950 text-slate-500 hover:text-rose-400 transition-colors min-h-[38px] min-w-[38px] flex items-center justify-center"
                    aria-label="Delete item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </main>
      </div>

      {/* Creation Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#0E1424] border border-[#222E48] rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#1C263C] pb-3">
              <h3 className="font-bold text-sm text-white">Create New Entry</h3>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Title</label>
                <input
                  type="text"
                  autoFocus
                  required
                  value={newItemTitle}
                  onChange={(e) => setNewItemTitle(e.target.value)}
                  placeholder="Enter title..."
                  className="w-full h-10 px-3 bg-[#141C2E] border border-[#232E4A] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">Category</label>
                  <select
                    value={newItemCategory}
                    onChange={(e) => setNewItemCategory(e.target.value)}
                    className="w-full h-10 px-2.5 bg-[#141C2E] border border-[#232E4A] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Core">Core</option>
                    <option value="Planning">Planning</option>
                    <option value="Execution">Execution</option>
                    <option value="Testing">Testing</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">Priority</label>
                  <select
                    value={newItemPriority}
                    onChange={(e) => setNewItemPriority(e.target.value as any)}
                    className="w-full h-10 px-2.5 bg-[#141C2E] border border-[#232E4A] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Notes (Optional)</label>
                <textarea
                  rows={3}
                  value={newItemNotes}
                  onChange={(e) => setNewItemNotes(e.target.value)}
                  placeholder="Add any contextual notes..."
                  className="w-full p-3 bg-[#141C2E] border border-[#232E4A] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1C263C]">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
`;
  } else {
    // Multi-pane responsive dashboard with zero fake telemetry
    universalAppCode = `import React, { useState } from 'react';
import { 
  Sparkles, Layers, Activity, Search, Plus, Trash2, CheckCircle2, 
  Settings, Filter, ArrowUpRight, BarChart2, Shield, RefreshCw, 
  Calendar, Star, ChevronRight, Download, Menu, X, Bell, Database,
  SlidersHorizontal, Check, Edit3, Clock
} from 'lucide-react';

export interface RecordItem {
  id: string;
  title: string;
  category: string;
  status: 'active' | 'completed' | 'queued';
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
  metric: number;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'items' | 'settings'>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [newItemTitle, setNewItemTitle] = useState('');
  const [newItemCategory, setNewItemCategory] = useState('Core');
  const [newItemPriority, setNewItemPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [items, setItems] = useState<RecordItem[]>([
    { id: 'REC-101', title: '${displayTitle} Primary Stream', category: 'Core', status: 'active', priority: 'high', createdAt: '10m ago', metric: 94 },
    { id: 'REC-102', title: 'Operational Record Ledger', category: 'Analytics', status: 'active', priority: 'medium', createdAt: '25m ago', metric: 88 },
    { id: 'REC-103', title: 'Data Synchronization Node', category: 'Storage', status: 'completed', priority: 'low', createdAt: '1h ago', metric: 100 },
    { id: 'REC-104', title: 'Resource Optimization Pipeline', category: 'Core', status: 'active', priority: 'high', createdAt: '2h ago', metric: 76 },
    { id: 'REC-105', title: 'Security & Access Protocol Audit', category: 'Security', status: 'queued', priority: 'medium', createdAt: '3h ago', metric: 45 }
  ]);

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemTitle.trim()) return;

    const newItem: RecordItem = {
      id: \`REC-\${Date.now().toString().slice(-4)}\`,
      title: newItemTitle.trim(),
      category: newItemCategory,
      status: 'active',
      priority: newItemPriority,
      createdAt: 'Just now',
      metric: Math.floor(Math.random() * 30 + 70)
    };

    setItems(prev => [newItem, ...prev]);
    setNewItemTitle('');
    setIsModalOpen(false);
  };

  const handleDeleteItem = (id: string) => {
    setItems(prev => prev.filter(item => item.id !== id));
  };

  const handleToggleStatus = (id: string) => {
    setItems(prev => prev.map(item => {
      if (item.id === id) {
        const nextStatus = item.status === 'active' ? 'completed' : 'active';
        return { ...item, status: nextStatus, metric: nextStatus === 'completed' ? 100 : item.metric };
      }
      return item;
    }));
  };

  const filteredItems = items.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = filterCategory === 'all' || item.category === filterCategory;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="flex h-screen w-full bg-[#090D16] text-slate-100 font-sans select-none overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-[#0E1424] border-r border-[#1C263C] shrink-0 z-30">
        <div className="h-16 px-6 border-b border-[#1C263C] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="font-extrabold text-sm tracking-wide text-white truncate max-w-[130px]">
                ${displayTitle}
              </div>
              <div className="text-[10px] text-cyan-400 font-mono">AUTONOMOUS APP</div>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Activity },
            { id: 'items', label: 'Records & Data', icon: Layers, count: items.length },
            { id: 'settings', label: 'Settings', icon: Settings }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={\`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all min-h-[44px] \${
                  isActive
                    ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-800 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#141C2E]'
                }\`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={\`w-4 h-4 \${isActive ? 'text-cyan-400' : 'text-slate-400'}\`} />
                  <span>{tab.label}</span>
                </div>
                {tab.count !== undefined && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#141C2E] text-slate-400 border border-[#232E4A]">
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <header className="h-16 bg-[#0E1424] border-b border-[#1C263C] px-4 sm:px-6 flex items-center justify-between shrink-0 z-30">
          <div className="flex items-center gap-3 md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-[#141C2E] text-slate-200 min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <span className="font-extrabold text-sm text-white truncate max-w-[160px]">${displayTitle}</span>
          </div>

          <div className="hidden sm:flex items-center flex-1 max-w-md">
            <div className="relative w-full">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search records..."
                className="w-full h-9 pl-9 pr-4 bg-[#141C2E] border border-[#232E4A] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md transition-all min-h-[44px]"
            >
              <Plus className="w-4 h-4" />
              <span className="whitespace-nowrap">Create Item</span>
            </button>
          </div>
        </header>

        {/* Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-5 rounded-2xl bg-[#0E1424] border border-[#1C263C] space-y-1 shadow-lg">
                  <div className="text-[11px] text-slate-400 font-medium">TOTAL ITEMS</div>
                  <div className="text-2xl font-extrabold font-mono text-white">{items.length}</div>
                  <div className="text-xs text-slate-400 font-mono">Active records</div>
                </div>
                <div className="p-5 rounded-2xl bg-[#0E1424] border border-[#1C263C] space-y-1 shadow-lg">
                  <div className="text-[11px] text-slate-400 font-medium">COMPLETED</div>
                  <div className="text-2xl font-extrabold font-mono text-emerald-400">{items.filter(i => i.status === 'completed').length}</div>
                  <div className="text-xs text-emerald-400 font-mono">Verified tasks</div>
                </div>
                <div className="p-5 rounded-2xl bg-[#0E1424] border border-[#1C263C] space-y-1 shadow-lg">
                  <div className="text-[11px] text-slate-400 font-medium">ACTIVE PIPELINES</div>
                  <div className="text-2xl font-extrabold font-mono text-cyan-400">{items.filter(i => i.status === 'active').length}</div>
                  <div className="text-xs text-slate-400 font-mono">In progress</div>
                </div>
                <div className="p-5 rounded-2xl bg-[#0E1424] border border-[#1C263C] space-y-1 shadow-lg">
                  <div className="text-[11px] text-slate-400 font-medium">QUEUED</div>
                  <div className="text-2xl font-extrabold font-mono text-indigo-400">{items.filter(i => i.status === 'queued').length}</div>
                  <div className="text-xs text-indigo-400 font-mono">Pending assignment</div>
                </div>
              </div>

              {/* Data Table */}
              <div className="p-5 rounded-2xl bg-[#0E1424] border border-[#1C263C] shadow-lg space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-base text-white">Active Operational Units</h3>
                  <span className="text-xs font-mono text-slate-400">{filteredItems.length} records</span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-sans">
                    <thead className="bg-[#090D16] border-b border-[#1C263C] text-slate-400 uppercase text-[10px] font-mono">
                      <tr>
                        <th className="p-3">ID</th>
                        <th className="p-3">Item Name</th>
                        <th className="p-3">Category</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1C263C]">
                      {filteredItems.map(item => (
                        <tr key={item.id} className="hover:bg-[#141C2E] transition-colors">
                          <td className="p-3 font-mono font-bold text-cyan-400">{item.id}</td>
                          <td className="p-3 font-semibold text-white">{item.title}</td>
                          <td className="p-3 text-slate-400"><span className="px-2 py-0.5 rounded bg-[#141C2E] border border-[#232E4A] text-[11px] whitespace-nowrap">{item.category}</span></td>
                          <td className="p-3">
                            <span className={\`px-2 py-0.5 rounded text-[10px] font-bold font-mono whitespace-nowrap \${
                              item.status === 'completed' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                              item.status === 'active' ? 'bg-cyan-950 text-cyan-400 border border-cyan-800' : 'bg-slate-800 text-slate-400 border border-slate-700'
                            }\`}>
                              {item.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="p-3 text-right space-x-2">
                            <button
                              onClick={() => handleToggleStatus(item.id)}
                              className="p-1.5 rounded-lg bg-[#141C2E] hover:bg-[#1E293B] text-slate-300 hover:text-white min-h-[36px] min-w-[36px]"
                              title="Toggle Status"
                              aria-label="Toggle Status"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteItem(item.id)}
                              className="p-1.5 rounded-lg bg-[#141C2E] hover:bg-rose-950 text-slate-300 hover:text-rose-400 min-h-[36px] min-w-[36px]"
                              title="Delete Item"
                              aria-label="Delete Item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'items' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredItems.map(item => (
                <div key={item.id} className="p-5 rounded-2xl bg-[#0E1424] border border-[#1C263C] space-y-3 shadow-lg">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs text-cyan-400 font-bold">{item.id}</span>
                    <span className="text-[10px] text-slate-400">{item.createdAt}</span>
                  </div>
                  <div className="font-bold text-sm text-white">{item.title}</div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-[#141C2E] text-slate-400 text-xs border border-[#232E4A] whitespace-nowrap">{item.category}</span>
                    <span className="text-xs font-mono text-cyan-300 font-semibold">{item.metric}% Health</span>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-[#1C263C]">
                    <button
                      onClick={() => handleToggleStatus(item.id)}
                      className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold min-h-[36px] flex items-center"
                    >
                      <span>{item.status === 'completed' ? 'Reopen' : 'Mark Completed'}</span>
                    </button>
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="text-xs text-rose-400 hover:text-rose-300 min-h-[36px] flex items-center"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="p-6 rounded-2xl bg-[#0E1424] border border-[#1C263C] space-y-4 shadow-lg">
              <h3 className="font-bold text-base text-white">Environment Configuration</h3>
              <div className="text-xs font-mono text-slate-400">Application Node: <span className="text-cyan-300 font-bold">${displayTitle.toUpperCase()}_PROD_01</span></div>
            </div>
          )}
        </main>
      </div>

      {/* Create Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#0E1424] border border-[#222E48] rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#1C263C] pb-3">
              <h3 className="font-bold text-sm text-white">Add New Item</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddItem} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Item Title</label>
                <input
                  type="text"
                  autoFocus
                  value={newItemTitle}
                  onChange={(e) => setNewItemTitle(e.target.value)}
                  placeholder="Enter title..."
                  className="w-full h-9 px-3 bg-[#141C2E] border border-[#232E4A] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Category</label>
                  <select
                    value={newItemCategory}
                    onChange={(e) => setNewItemCategory(e.target.value)}
                    className="w-full h-9 px-2.5 bg-[#141C2E] border border-[#232E4A] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Core">Core</option>
                    <option value="Analytics">Analytics</option>
                    <option value="Storage">Storage</option>
                    <option value="Security">Security</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Priority</label>
                  <select
                    value={newItemPriority}
                    onChange={(e) => setNewItemPriority(e.target.value as any)}
                    className="w-full h-9 px-2.5 bg-[#141C2E] border border-[#232E4A] rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1C263C]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 rounded-xl text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
`;
  }

  files['src/App.tsx'] = universalAppCode;
  return finalizeResult({
    files,
    name: displayTitle,
    description: `Generic offline starter scaffold for: "${prompt}". Domain-specific behavior may require a configured AI provider.`,
    summary: `Created a generic starter scaffold for "${prompt}" in \`src/App.tsx\`. Domain-specific functionality may require a configured AI provider or further implementation.`,
    entryFile: 'src/App.tsx',
    reactCode: universalAppCode
  });
}
