/**
 * GODEX Phase 1 - Project Context Service
 * High-level AI query interface for retrieving project structures, AST context, dependency subgraphs, and prompt grounding.
 */

import { IntelligenceEngine } from './intelligenceEngine';
import { 
  ProjectSymbol, 
  GraphNode, 
  ProjectHealthSnapshot, 
  ProjectMetadata 
} from './types';

export interface FileContextSummary {
  filePath: string;
  language: string;
  lines: number;
  isEntry: boolean;
  imports: string[];
  exports: string[];
  symbols: Array<{ name: string; kind: string; signature?: string }>;
  routes: Array<{ path: string; method?: string; type: string }>;
  dependencies: string[];
  dependents: string[];
}

export interface PromptContextResult {
  relevantFiles: string[];
  relevantSymbols: ProjectSymbol[];
  frameworkSummary: string;
  contextPromptBlock: string;
}

export class ProjectContextService {
  private engine: IntelligenceEngine;

  constructor(engine: IntelligenceEngine = IntelligenceEngine.getInstance()) {
    this.engine = engine;
  }

  public getProjectMetadata(): ProjectMetadata {
    return this.engine.getState().metadata;
  }

  public getProjectHealth(): ProjectHealthSnapshot {
    return this.engine.getState().health;
  }

  public getFileContext(filePath: string): FileContextSummary | null {
    const state = this.engine.getState();
    const file = state.files[filePath];
    if (!file) return null;

    const imports = file.imports.map(i => i.source);
    const exports = file.exports.map(e => e.name);
    const symbols = file.symbols.map(s => ({
      name: s.name,
      kind: s.kind,
      signature: s.signature
    }));
    const routes = file.routes.map(r => ({
      path: r.path,
      method: r.method,
      type: r.type
    }));

    const dependencies = state.graph.adjacency[filePath] || [];
    const dependents = state.graph.reverseAdjacency[filePath] || [];

    return {
      filePath,
      language: file.language,
      lines: file.lines,
      isEntry: file.isEntry,
      imports,
      exports,
      symbols,
      routes,
      dependencies,
      dependents
    };
  }

  public getSymbolContext(symbolName: string): {
    symbols: ProjectSymbol[];
    definedInFiles: string[];
    importedByFiles: string[];
  } {
    const state = this.engine.getState();
    const symbols = this.engine.getSymbolIndex().getSymbolsByName(symbolName);
    const definedInFiles = symbols.map(s => s.filePath);

    const importedByFiles: string[] = [];
    for (const [filePath, fileData] of Object.entries(state.files)) {
      for (const imp of fileData.imports) {
        if (imp.specifiers.some(s => s.local === symbolName || s.imported === symbolName)) {
          importedByFiles.push(filePath);
        }
      }
    }

    return {
      symbols,
      definedInFiles,
      importedByFiles
    };
  }

  public getArchitectureLayers(): {
    ui: GraphNode[];
    services: GraphNode[];
    core: GraphNode[];
    routes: GraphNode[];
    config: GraphNode[];
  } {
    const state = this.engine.getState();
    const layers = {
      ui: [] as GraphNode[],
      services: [] as GraphNode[],
      core: [] as GraphNode[],
      routes: [] as GraphNode[],
      config: [] as GraphNode[]
    };

    for (const node of state.graph.nodes) {
      if (node.layer === 'ui') layers.ui.push(node);
      else if (node.layer === 'services') layers.services.push(node);
      else if (node.layer === 'core') layers.core.push(node);
      else if (node.layer === 'routes') layers.routes.push(node);
      else if (node.layer === 'config') layers.config.push(node);
    }

    return layers;
  }

  public searchSymbols(query: string, limit = 20): ProjectSymbol[] {
    return this.engine.getSymbolIndex().search(query, limit);
  }

  /**
   * Grounds AI user prompts by extracting mentioned symbols, components, and files
   * and constructing a structured project context block.
   */
  public getRelevantContextForPrompt(userPrompt: string): PromptContextResult {
    const state = this.engine.getState();
    const clean = userPrompt.toLowerCase();
    const relevantFilesSet = new Set<string>();
    const relevantSymbols: ProjectSymbol[] = [];

    // Match file paths
    for (const filePath of Object.keys(state.files)) {
      const fileName = filePath.split('/').pop()?.toLowerCase() || '';
      const baseName = fileName.replace(/\.[^/.]+$/, '');
      if (clean.includes(filePath.toLowerCase()) || clean.includes(fileName) || clean.includes(baseName)) {
        relevantFilesSet.add(filePath);
      }
    }

    // Always include entry points if matched or relevant
    if (state.metadata.entryPoints.browser) {
      relevantFilesSet.add(state.metadata.entryPoints.browser);
    }

    // Match symbols
    const allSymbols = this.engine.getSymbolIndex().getAllSymbols();
    for (const sym of allSymbols) {
      if (clean.includes(sym.name.toLowerCase())) {
        relevantSymbols.push(sym);
        relevantFilesSet.add(sym.filePath);
      }
    }

    const relevantFiles = Array.from(relevantFilesSet).slice(0, 8);
    const frameworkSummary = `${state.metadata.framework.toUpperCase()} (${state.metadata.primaryLanguage}) on ${state.metadata.runtime} with ${state.metadata.buildTool}`;

    const contextPromptBlock = `
PROJECT INTELLIGENCE CONTEXT:
- Stack: ${frameworkSummary}
- Entry Points: ${JSON.stringify(state.metadata.entryPoints)}
- Health Score: ${state.health.score}% (${state.health.rating})
- Total Tracked Symbols: ${state.health.totalSymbols}
- Relevant Target Files: ${relevantFiles.join(', ') || 'src/App.tsx'}
- Relevant Symbols: ${relevantSymbols.map(s => `${s.kind} ${s.name} (${s.filePath}:${s.line})`).join(', ') || 'None detected'}
`;

    return {
      relevantFiles,
      relevantSymbols,
      frameworkSummary,
      contextPromptBlock
    };
  }
}

export const ProjectContext = new ProjectContextService();
