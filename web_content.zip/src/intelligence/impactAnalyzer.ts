/**
 * GODEX Phase 1 & 2 - Deep Project Intelligence: Impact Analyzer
 * Determines exact ripple effects of modifying any file, symbol, or dependency.
 * Answers "What will break if I change X?" with risk scores, dependent symbols,
 * required regression tests, and preview inspection areas.
 */

import { ProjectGraph, ProjectSymbol } from './types';
import { GraphBuilder } from './graphBuilder';
import { AstParser } from './astParser';

export type ImpactRiskLevel = 'HIGH' | 'MEDIUM' | 'LOW';

export interface ImpactAnalysisResult {
  targetPath: string;
  targetSymbol?: string;
  affectedFiles: Array<{
    path: string;
    relation: 'DIRECT_IMPORT' | 'INDIRECT_IMPORT' | 'PROP_DEPENDENT' | 'TYPE_CONSUMER';
    risk: ImpactRiskLevel;
  }>;
  affectedSymbols: Array<{
    name: string;
    file: string;
    kind: string;
  }>;
  directDependenciesCount: number;
  indirectDependenciesCount: number;
  overallRisk: ImpactRiskLevel;
  requiredValidation: {
    typecheck: boolean;
    tests: string[];
    previewAreas: string[];
    rebuildRequired: boolean;
  };
  summary: string;
}

export class ImpactAnalyzer {
  /**
   * Analyzes blast radius and downstream dependencies for a given file or symbol
   */
  public static analyze(
    targetPath: string,
    files: Record<string, string>,
    targetSymbolName?: string
  ): ImpactAnalysisResult {
    const filePaths = Object.keys(files);
    const affectedFiles: ImpactAnalysisResult['affectedFiles'] = [];
    const affectedSymbols: ImpactAnalysisResult['affectedSymbols'] = [];

    // 1. Direct Importers
    const directImporters = new Set<string>();
    const indirectImporters = new Set<string>();

    const targetBase = targetPath.replace(/\.(tsx?|jsx?|json)$/, '');
    const targetFileName = targetPath.split('/').pop()?.replace(/\.(tsx?|jsx?|json)$/, '') || '';

    // Pass 1: Find direct importers
    for (const [filePath, content] of Object.entries(files)) {
      if (filePath === targetPath) continue;

      const hasImport = 
        content.includes(`'./${targetFileName}'`) ||
        content.includes(`"../${targetFileName}"`) ||
        content.includes(`/${targetFileName}`) ||
        content.includes(`'${targetBase}'`) ||
        content.includes(`"${targetBase}"`);

      if (hasImport) {
        directImporters.add(filePath);
        affectedFiles.push({
          path: filePath,
          relation: 'DIRECT_IMPORT',
          risk: filePath === 'src/App.tsx' || filePath === 'server.ts' ? 'HIGH' : 'MEDIUM'
        });
      }
    }

    // Pass 2: Find indirect importers (importers of direct importers)
    for (const [filePath, content] of Object.entries(files)) {
      if (filePath === targetPath || directImporters.has(filePath)) continue;

      for (const directPath of Array.from(directImporters)) {
        const directBase = directPath.split('/').pop()?.replace(/\.(tsx?|jsx?|json)$/, '') || '';
        if (content.includes(`'./${directBase}'`) || content.includes(`"../${directBase}"`) || content.includes(`/${directBase}`)) {
          indirectImporters.add(filePath);
          affectedFiles.push({
            path: filePath,
            relation: 'INDIRECT_IMPORT',
            risk: 'LOW'
          });
          break;
        }
      }
    }

    // 2. Symbol-level blast radius
    if (targetSymbolName) {
      for (const filePath of Array.from(directImporters)) {
        const content = files[filePath] || '';
        if (content.includes(targetSymbolName)) {
          affectedSymbols.push({
            name: targetSymbolName,
            file: filePath,
            kind: 'consumed_symbol'
          });
        }
      }
    }

    // 3. Determine Overall Risk
    let overallRisk: ImpactRiskLevel = 'LOW';
    if (targetPath === 'src/types.ts' || targetPath === 'src/App.tsx' || targetPath === 'server.ts' || directImporters.size >= 5) {
      overallRisk = 'HIGH';
    } else if (directImporters.size > 1 || indirectImporters.size > 0) {
      overallRisk = 'MEDIUM';
    }

    // 4. Recommend Required Validations
    const requiredTests: string[] = ['npm run lint (TypeScript static typecheck)'];
    const previewAreas: string[] = [];

    if (targetPath.includes('Chat') || targetPath.includes('Composer')) {
      previewAreas.push('Chat & Stream interaction bubble', 'Multimodal attachments handler', 'Copy code actions');
    }
    if (targetPath.includes('Preview') || targetPath.includes('LivePreview')) {
      previewAreas.push('Responsive Preview container (Desktop, Tablet, Mobile)', 'Iframe sandbox containment');
    }
    if (targetPath.includes('debugger') || targetPath.includes('Healing')) {
      previewAreas.push('Self-healing state machine cycle', 'Rollback verification');
    }
    if (previewAreas.length === 0) {
      previewAreas.push('Workspace UI Shell', 'Live Preview re-render');
    }

    const summary = `Modifying "${targetPath}" directly affects ${directImporters.size} files and indirectly affects ${indirectImporters.size} files. Overall Risk: ${overallRisk}.`;

    return {
      targetPath,
      targetSymbol: targetSymbolName,
      affectedFiles,
      affectedSymbols,
      directDependenciesCount: directImporters.size,
      indirectDependenciesCount: indirectImporters.size,
      overallRisk,
      requiredValidation: {
        typecheck: true,
        tests: requiredTests,
        previewAreas,
        rebuildRequired: overallRisk === 'HIGH'
      },
      summary
    };
  }
}
