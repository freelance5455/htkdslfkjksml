/**
 * GODEX Phase 1 - Project Health & Static Diagnostic Analyzer
 * Evaluates syntax validity, broken imports, circular dependencies, secret leaks, and metrics.
 */

import { 
  ProjectHealthSnapshot, 
  ProjectHealthIssue, 
  ProjectGraph, 
  ProjectMetadata 
} from './types';
import { ParsedFileAst } from './astParser';

export class HealthAnalyzer {
  public static analyzeHealth(
    files: Record<string, string>,
    parsedAsts: Record<string, ParsedFileAst>,
    graph: ProjectGraph,
    metadata: ProjectMetadata
  ): ProjectHealthSnapshot {
    const issues: ProjectHealthIssue[] = [];
    let syntaxValid = true;

    // 1. Broken / Unresolved Relative Imports Check
    let brokenImportCount = 0;
    for (const [filePath, ast] of Object.entries(parsedAsts)) {
      if (!ast) continue;
      for (const imp of ast.imports) {
        if (!imp.isExternal && !imp.resolvedPath) {
          brokenImportCount++;
          issues.push({
            id: `issue-broken-imp-${filePath}-${imp.line}`,
            severity: 'error',
            category: 'import',
            title: 'Unresolved Import Path',
            message: `File "${filePath}" imports "${imp.source}" which cannot be resolved.`,
            filePath,
            line: imp.line,
            suggestion: 'Verify the relative path or file extension.'
          });
        }
      }
    }

    // 2. Circular Dependencies Check
    const circularDependencyCount = graph.circularDependencies.length;
    for (const cycle of graph.circularDependencies) {
      issues.push({
        id: `issue-cycle-${cycle.join('->')}`,
        severity: 'warning',
        category: 'circular',
        title: 'Circular Module Dependency Detected',
        message: `Cyclic import chain: ${cycle.join(' ➔ ')}`,
        filePath: cycle[0],
        suggestion: 'Extract shared types or utilities into a separate file to decouple modules.'
      });
    }

    // 3. Secret Leak Auditing (Hardcoded tokens, API keys, private keys in source files)
    let secretLeakCount = 0;
    const secretPatterns = [
      { name: 'OpenAI API Key', regex: /sk-[a-zA-Z0-9]{20,}/g },
      { name: 'Anthropic API Key', regex: /sk-ant-[a-zA-Z0-9_-]{20,}/g },
      { name: 'Generic API Key / Token', regex: /(?:api[_-]?key|secret|password|auth[_-]?token)\s*[:=]\s*['"][a-zA-Z0-9_-]{24,}['"]/gi },
      { name: 'Private Key Block', regex: /-----BEGIN PRIVATE KEY-----/g }
    ];

    for (const [filePath, content] of Object.entries(files)) {
      if (filePath.startsWith('.env') || filePath === '.env.example') continue; // Allowed in env declarations

      const lines = content.split('\n');
      lines.forEach((lineText, lineIdx) => {
        for (const pattern of secretPatterns) {
          if (pattern.regex.test(lineText)) {
            // Exclude safe mock/placeholder tokens
            if (!lineText.includes('process.env') && !lineText.includes('import.meta.env') && !lineText.includes('PLACEHOLDER') && !lineText.includes('your-key')) {
              secretLeakCount++;
              issues.push({
                id: `issue-secret-${filePath}-${lineIdx + 1}`,
                severity: 'error',
                category: 'security',
                title: `Hardcoded Secret Detected (${pattern.name})`,
                message: `Potential API key or secret exposed in "${filePath}" line ${lineIdx + 1}.`,
                filePath,
                line: lineIdx + 1,
                suggestion: 'Store sensitive keys in .env and access via environment variables.'
              });
            }
          }
        }
      });
    }

    // 4. Basic Syntax Sanity Check (Unclosed braces/brackets)
    for (const [filePath, content] of Object.entries(files)) {
      if (filePath.endsWith('.tsx') || filePath.endsWith('.ts') || filePath.endsWith('.jsx') || filePath.endsWith('.js')) {
        let openBraces = 0;
        let openParens = 0;
        for (let i = 0; i < content.length; i++) {
          if (content[i] === '{') openBraces++;
          else if (content[i] === '}') openBraces--;
          else if (content[i] === '(') openParens++;
          else if (content[i] === ')') openParens--;
        }
        if (openBraces !== 0 || openParens !== 0) {
          syntaxValid = false;
          issues.push({
            id: `issue-syntax-${filePath}`,
            severity: 'error',
            category: 'syntax',
            title: 'Syntax Bracket Mismatch',
            message: `File "${filePath}" has unbalanced brackets or parentheses.`,
            filePath,
            suggestion: 'Check for unclosed braces or parentheses in this file.'
          });
        }
      }
    }

    // 5. Calculate Metrics
    let totalSymbols = 0;
    let totalComponents = 0;
    let totalRoutes = 0;
    for (const ast of Object.values(parsedAsts)) {
      if (ast) {
        totalSymbols += ast.symbols.length;
        totalComponents += ast.symbols.filter(s => s.kind === 'component').length;
        totalRoutes += ast.routes.length;
      }
    }

    const totalFiles = Object.keys(files).length || 1;
    const avgFileSizeLines = Math.round(metadata.totalLines / totalFiles);
    const componentRatio = parseFloat((totalComponents / totalFiles).toFixed(2));

    // 6. Calculate Health Score (0 - 100)
    let score = 100;
    score -= brokenImportCount * 15;
    score -= circularDependencyCount * 10;
    score -= secretLeakCount * 25;
    if (!syntaxValid) score -= 30;

    score = Math.max(0, Math.min(100, score));

    let rating: ProjectHealthSnapshot['rating'] = 'EXCELLENT';
    if (score < 60) rating = 'POOR';
    else if (score < 80) rating = 'FAIR';
    else if (score < 95) rating = 'GOOD';

    const warningCount = issues.filter(i => i.severity === 'warning').length;

    return {
      score,
      rating,
      syntaxValid,
      circularDependencyCount,
      brokenImportCount,
      secretLeakCount,
      warningCount,
      totalSymbols,
      totalComponents,
      totalRoutes,
      totalDependencies: Object.keys(metadata.configFiles).length,
      issues,
      metrics: {
        totalFiles,
        totalLines: metadata.totalLines,
        totalBytes: metadata.totalBytes,
        componentRatio,
        avgFileSizeLines
      }
    };
  }
}
