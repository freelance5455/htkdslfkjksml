// Volume-preserving liquid geometry for a tube drawn in an 80x220 viewBox.
// The liquid surface always stays perpendicular to world gravity, even when
// the glass tilts. Liquid area (2D volume) is conserved exactly.

export interface P { x: number; y: number }

export const TUBE_BOTTOM = 196;
export const UNIT_H = 43.5;
/** Pouring lip corner (local coords) for a clockwise (+) tilt. */
export const LIP_RIGHT: P = { x: 64, y: 15 };
export const LIP_LEFT: P = { x: 16, y: 15 };
/** Inner corner where liquid actually leaves the cavity. */
export const INNER_LIP: P = { x: 61, y: 20 };
export const TUBE_CENTER: P = { x: 40, y: 110 };

function quad(a: P, c: P, b: P, t: number): P {
  const u = 1 - t;
  return { x: u * u * a.x + 2 * u * t * c.x + t * t * b.x, y: u * u * a.y + 2 * u * t * c.y + t * t * b.y };
}

/** Inner cavity polygon: matches the clipPath "M19 20 L19 173 Q19 196 40 196 Q61 196 61 173 L61 20 Z". */
const INNER: P[] = (() => {
  const pts: P[] = [{ x: 19, y: 20 }, { x: 19, y: 173 }];
  for (let i = 1; i <= 8; i += 1) pts.push(quad({ x: 19, y: 173 }, { x: 19, y: 196 }, { x: 40, y: 196 }, i / 8));
  for (let i = 1; i <= 8; i += 1) pts.push(quad({ x: 40, y: 196 }, { x: 61, y: 196 }, { x: 61, y: 173 }, i / 8));
  pts.push({ x: 61, y: 20 });
  return pts;
})();

export function downFor(theta: number): P {
  // CSS rotate(θ) is clockwise in screen space; world-down expressed locally.
  return { x: Math.sin(theta), y: Math.cos(theta) };
}

const dot = (p: P, d: P) => p.x * d.x + p.y * d.y;

/** Area of the cavity where dot(p, down) >= level (i.e. below the surface). */
function areaBelow(down: P, level: number): number {
  const out: P[] = [];
  for (let i = 0; i < INNER.length; i += 1) {
    const a = INNER[i];
    const b = INNER[(i + 1) % INNER.length];
    const fa = dot(a, down) - level;
    const fb = dot(b, down) - level;
    if (fa >= 0) out.push(a);
    if ((fa >= 0) !== (fb >= 0)) {
      const t = fa / (fa - fb);
      out.push({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t });
    }
  }
  let area = 0;
  for (let i = 0; i < out.length; i += 1) {
    const a = out[i];
    const b = out[(i + 1) % out.length];
    area += a.x * b.y - b.x * a.y;
  }
  return Math.abs(area) / 2;
}

const volumeCache = new Map<number, number>();
/** Liquid area for `units` measured in the upright tube. */
export function volumeOf(units: number): number {
  const key = Math.round(units * 1000);
  const hit = volumeCache.get(key);
  if (hit !== undefined) return hit;
  const v = areaBelow({ x: 0, y: 1 }, TUBE_BOTTOM - units * UNIT_H);
  volumeCache.set(key, v);
  return v;
}

/** Surface level (dot value) holding `units` of liquid at tilt `theta`. */
export function levelFor(theta: number, units: number): number {
  const down = downFor(theta);
  let lo = Infinity;
  let hi = -Infinity;
  for (const p of INNER) {
    const v = dot(p, down);
    lo = Math.min(lo, v);
    hi = Math.max(hi, v);
  }
  if (units <= 0.0001) return hi + 1;
  const target = volumeOf(units);
  for (let i = 0; i < 24; i += 1) {
    const mid = (lo + hi) / 2;
    if (areaBelow(down, mid) > target) lo = mid;
    else hi = mid;
  }
  return (lo + hi) / 2;
}

const tiltCache = new Map<number, number>();
/** Tilt (radians, positive) at which `units` of liquid just reaches the lip. */
export function pourTilt(units: number): number {
  const key = Math.round(units * 60);
  const hit = tiltCache.get(key);
  if (hit !== undefined) return hit;
  const target = volumeOf(Math.max(0.02, units));
  let lo = 0.25;
  let hi = 1.48;
  const f = (theta: number) => {
    const down = downFor(theta);
    return areaBelow(down, dot(INNER_LIP, down)) - target;
  };
  let result: number;
  if (f(hi) > 0) result = hi;
  else if (f(lo) < 0) result = lo;
  else {
    for (let i = 0; i < 22; i += 1) {
      const mid = (lo + hi) / 2;
      if (f(mid) > 0) lo = mid;
      else hi = mid;
    }
    result = (lo + hi) / 2;
  }
  tiltCache.set(key, result);
  return result;
}

export function rotate(v: P, theta: number): P {
  const c = Math.cos(theta);
  const s = Math.sin(theta);
  return { x: v.x * c - v.y * s, y: v.x * s + v.y * c };
}
