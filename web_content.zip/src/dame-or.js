/** Registre individuel officiel de la Dame d'Or.
 * Seuls les résultats de rencontres de clubs homologués alimentent le classement.
 * Les indicateurs restent factuels : matchs, victoires/nuls/défaites, points et buts.
 */
export const DAME_OR_ID = 'dame-or';

function ensureState(state) {
  state.dameOr ??= { version: 1, seasons: {}, history: [] };
  state.dameOr.seasons ??= {};
  state.dameOr.history ??= [];
  return state.dameOr;
}
function seasonRecord(state, season = state.season) {
  const root = ensureState(state);
  return root.seasons[season] ??= { season, status: 'in-progress', players: {}, fixtureIds: [] };
}
function findClub(state, clubId) {
  return state.divisions.flatMap(d => d.clubs).find(c => c.id === clubId) ?? null;
}
function stableIndex(text, length) {
  let hash = 2166136261;
  for (const ch of String(text)) hash = Math.imul(hash ^ ch.charCodeAt(0), 16777619) >>> 0;
  return hash % length;
}
export function getFixtureDamiste(club, fixture, side) {
  const players = club?.damistes ?? [];
  if (players.length !== 2) throw new Error(`Effectif invalide pour ${club?.name ?? club?.id}: deux damistes requis`);
  const chosenId = fixture.damisteSelections?.[side];
  const chosen = chosenId ? players.find(p => p.id === chosenId) : null;
  if (chosen) return chosen;
  // Choix déterministe pour les rencontres gérées par l'IA ; jamais de tirage aléatoire.
  return players[stableIndex(`${fixture.id}|${club.id}|${side}`, players.length)];
}

/** Le manager peut désigner le damiste titulaire de chaque côté avant le coup d'envoi. */
export function selectFixtureDamiste(state, fixtureId, side, damisteId) {
  if (!['home', 'away'].includes(side)) throw new Error('Côté de rencontre invalide');
  const fixture = state.calendar.fixtures.find(f => f.id === fixtureId);
  if (!fixture || fixture.status === 'played') throw new Error('Rencontre absente ou déjà terminée');
  const club = findClub(state, fixture[side]);
  if (!club) throw new Error('Cette rencontre ne concerne pas deux clubs du CGD');
  if (!club.damistes?.some(p => p.id === damisteId)) throw new Error('Damiste non inscrit dans ce club');
  fixture.damisteSelections ??= {};
  fixture.damisteSelections[side] = damisteId;
  return true;
}

/** Appelé uniquement après homologation du résultat central. Idempotent par identifiant de match. */
export function recordDameOrResult(state, fixture, homeScore, awayScore, matchDetails = {}) {
  if (!fixture || fixture.competitionId === 'intergalactique' || fixture.competitionId === 'coupe-lunaire') return false;
  const home = findClub(state, fixture.home), away = findClub(state, fixture.away);
  if (!home || !away) return false;
  const season = seasonRecord(state, fixture.season ?? state.season);
  if (season.fixtureIds.includes(fixture.id)) return false;
  const homePlayer = getFixtureDamiste(home, fixture, 'home');
  const awayPlayer = getFixtureDamiste(away, fixture, 'away');
  const resultFor = (player, club, gf, ga) => {
    const row = season.players[player.id] ??= {
      damisteId: player.id, name: player.name, gender: player.gender ?? null,
      clubId: club.id, clubName: club.name, played: 0, won: 0, drawn: 0, lost: 0,
      points: 0, goalsFor: 0, goalsAgainst: 0, moves: 0, captures: 0, promotions: 0, kingMoves: 0
    };
    row.name = player.name; row.gender = player.gender ?? row.gender;
    for (const key of ['moves','captures','promotions','kingMoves']) row[key] = Math.max(0, Number(row[key]) || 0);
    row.clubId = club.id; row.clubName = club.name;
    row.played++; row.goalsFor += gf; row.goalsAgainst += ga;
    if (gf > ga) { row.won++; row.points += 3; }
    else if (gf === ga) { row.drawn++; row.points++; }
    else row.lost++;
    const sideStats = matchDetails.performance?.[club.id === fixture.home ? 'home' : 'away'];
    if (sideStats) { for (const key of ['moves','captures','promotions','kingMoves']) row[key] += Math.max(0, Number(sideStats[key]) || 0); }
  };
  resultFor(homePlayer, home, homeScore, awayScore);
  resultFor(awayPlayer, away, awayScore, homeScore);
  season.fixtureIds.push(fixture.id);
  fixture.damisteSelections = { home: homePlayer.id, away: awayPlayer.id };
  fixture.dameOrRecorded = true;
  return true;
}

export function getDameOrRanking(state, season = state.season) {
  const record = state.dameOr?.seasons?.[season];
  return Object.values(record?.players ?? {}).sort((a, b) =>
    b.points - a.points || b.won - a.won || (b.goalsFor - b.goalsAgainst) - (a.goalsFor - a.goalsAgainst) ||
    b.goalsFor - a.goalsFor || b.captures - a.captures || b.promotions - a.promotions || b.kingMoves - a.kingMoves || b.played - a.played || a.name.localeCompare(b.name, 'fr')
  ).map((p, index) => ({ rank: index + 1, ...p, goalDifference: p.goalsFor - p.goalsAgainst }));
}

/** Clôture explicite de saison : archive le classement sans inventer de cérémonie ni de vote. */
export function closeDameOrSeason(state, season = state.season) {
  const record = seasonRecord(state, season);
  if (record.status === 'completed') return record.winnerId ?? null;
  const ranking = getDameOrRanking(state, season);
  const winner = ranking[0] ?? null;
  record.status = 'completed';
  record.winnerId = winner?.damisteId ?? null;
  record.completedAt = new Date().toISOString();
  record.finalRanking = ranking;
  const root = ensureState(state);
  if (!root.history.some(x => x.season === season)) root.history.push({ season, winnerId: record.winnerId, winnerName: winner?.name ?? null, clubId: winner?.clubId ?? null, clubName: winner?.clubName ?? null, points: winner?.points ?? 0, played: winner?.played ?? 0 });
  root.history.sort((a, b) => a.season - b.season);
  return record.winnerId;
}

export function getDameOrStatus(state) {
  const ranking = getDameOrRanking(state);
  return { season: state.season, status: state.dameOr?.seasons?.[state.season]?.status ?? 'in-progress', ranking, history: [...(state.dameOr?.history ?? [])].sort((a,b)=>b.season-a.season), recordedMatches: state.dameOr?.seasons?.[state.season]?.fixtureIds?.length ?? 0 };
}
