import test from 'node:test';
import assert from 'node:assert/strict';
import {
  clampPitchRadians,
  computeStereoViewports,
  createInitialGazeState,
  deviceOrientationToQuaternion,
  shortestAngleDiffRadians,
  stepGaze,
} from './gazeEngine';
import {
  applyKeyboardKey,
  clampScrollOffset,
  clampVolume,
  createInitialBrowserState,
  CURATED_WEBSITES,
  cycleCinemaScreenSize,
  cycleGalleryFilter,
  cycleIndex,
  cycleSceneEnvironment,
  cycleTheaterLightMode,
  ENVIRONMENT_OPTIONS,
  extractGalleryFolders,
  filterGalleryItems,
  formatFileSize,
  formatPlaybackTime,
  formatVolumePercent,
  getNextGalleryItem,
  getProjectionSpec,
  inferProjectionFromFilename,
  isBookmarkSaved,
  isSupportedMediaFileName,
  mapBrowserUvToGazeId,
  mapGalleryUvToGazeId,
  PROJECTION_OPTIONS,
  resolveBrowserInput,
  stepVolume,
  toggleBookmark,
  VOLUME_SLIDER_STEPS,
} from './vrState';

test('gaze dwell accumulates and triggers once upon completion', () => {
  let state = createInitialGazeState(1000);

  let step = stepGaze(state, 'portal-cinema', 400, 400);
  assert.equal(step.triggeredId, null);
  assert.ok(Math.abs(step.progress - 0.4) < 0.001);
  state = step.nextState;

  step = stepGaze(state, 'portal-cinema', 400, 800);
  assert.equal(step.triggeredId, null);
  assert.ok(Math.abs(step.progress - 0.8) < 0.001);
  state = step.nextState;

  step = stepGaze(state, 'portal-cinema', 250, 1050);
  assert.equal(step.triggeredId, 'portal-cinema');
  assert.equal(step.progress, 1);
  assert.equal(step.nextState.triggeredCount, 1);
  state = step.nextState;

  step = stepGaze(state, 'portal-cinema', 200, 1250);
  assert.equal(step.triggeredId, null);
  assert.equal(step.progress, 0);

  step = stepGaze(step.nextState, null, 16, 1300);
  assert.equal(step.nextState.targetId, null);
  assert.equal(step.progress, 0);
});

test('switching gaze target resets previous dwell progress', () => {
  let state = createInitialGazeState(1000);
  state = stepGaze(state, 'portal-360', 600, 600).nextState;
  const switched = stepGaze(state, 'portal-browser', 100, 700);
  assert.equal(switched.nextState.targetId, 'portal-browser');
  assert.ok(Math.abs(switched.progress - 0.1) < 0.001);
});

test('stereo viewport splits canvas cleanly and computes half-IPD', () => {
  const spec = computeStereoViewports(1920, 1080, 64);
  assert.deepEqual(spec.leftViewport, { x: 0, y: 0, width: 960, height: 1080 });
  assert.deepEqual(spec.rightViewport, { x: 960, y: 0, width: 960, height: 1080 });
  assert.ok(Math.abs(spec.eyeOffsetMeters - 0.032) < 1e-6);
  assert.ok(Math.abs(spec.eyeAspect - 960 / 1080) < 1e-6);
});

test('deviceOrientationToQuaternion produces unit-length quaternion', () => {
  const q = deviceOrientationToQuaternion(45, 90, -10, 90);
  const mag = Math.hypot(q.x, q.y, q.z, q.w);
  assert.ok(Math.abs(mag - 1) < 1e-5);
});

test('clampPitchRadians prevents camera gimbal flip', () => {
  assert.ok(clampPitchRadians(5) < Math.PI / 2);
  assert.ok(clampPitchRadians(-5) > -Math.PI / 2);
});

test('keyboard input handles Arabic/English append, space, backspace, clear', () => {
  let text = '';
  text = applyKeyboardKey(text, 'ا');
  text = applyKeyboardKey(text, 'ل');
  text = applyKeyboardKey(text, 'SPACE');
  text = applyKeyboardKey(text, 'ق');
  assert.equal(text, 'ال ق');

  text = applyKeyboardKey(text, 'BACKSPACE');
  assert.equal(text, 'ال ');

  text = applyKeyboardKey(text, 'CLEAR');
  assert.equal(text, '');
});

test('playlist index cycling and time formatting work reliably', () => {
  assert.equal(cycleIndex(0, 4, -1), 3);
  assert.equal(cycleIndex(3, 4, 1), 0);
  assert.equal(clampScrollOffset(-2, 10), 0);
  assert.equal(clampScrollOffset(14, 10), 10);
  assert.equal(formatPlaybackTime(125), '02:05');
});

test('360 and 3D projection specs expose 180 and 360 stereo modes', () => {
  assert.equal(PROJECTION_OPTIONS.length, 5);
  assert.equal(getProjectionSpec('180-sbs').is180, true);
  assert.equal(getProjectionSpec('180-sbs').stereoLayout, 'sbs');
  assert.equal(getProjectionSpec('360-tb').is180, false);
  assert.equal(getProjectionSpec('360-tb').stereoLayout, 'tb');
});

test('cinema lighting and screen zoom presets cycle through all options', () => {
  let light = cycleTheaterLightMode('cinematic');
  assert.equal(light, 'dark');
  light = cycleTheaterLightMode(light);
  assert.equal(light, 'ambient');
  light = cycleTheaterLightMode(light);
  assert.equal(light, 'bright');
  light = cycleTheaterLightMode(light);
  assert.equal(light, 'cinematic');

  let size = cycleCinemaScreenSize('classic');
  assert.equal(size, 'imax');
  size = cycleCinemaScreenSize(size);
  assert.equal(size, 'giant');
  size = cycleCinemaScreenSize(size);
  assert.equal(size, 'classic');
});

test('browser bookmarks can be saved, detected, and removed', () => {
  const initial = [
    {
      id: '1',
      title: 'Wikipedia',
      url: 'https://ar.wikipedia.org/wiki/VR',
      domain: 'ar.wikipedia.org',
      savedAt: 'اليوم',
    },
  ];
  assert.equal(isBookmarkSaved(initial, 'https://ar.wikipedia.org/wiki/VR'), true);
  assert.equal(isBookmarkSaved(initial, 'https://example.com'), false);

  const added = toggleBookmark(initial, {
    title: 'Example Site',
    url: 'https://example.com/article',
  });
  assert.equal(added.saved, true);
  assert.equal(added.nextBookmarks.length, 2);
  assert.equal(added.nextBookmarks[0].domain, 'example.com');

  const removed = toggleBookmark(added.nextBookmarks, {
    title: 'Example Site',
    url: 'https://example.com/article',
  });
  assert.equal(removed.saved, false);
  assert.equal(removed.nextBookmarks.length, 1);
});

test('gallery media detection and filename projection inference', () => {
  assert.equal(isSupportedMediaFileName('vacation_180_sbs.mp4'), 'video');
  assert.equal(isSupportedMediaFileName('panorama_360.jpg'), 'image');
  assert.equal(isSupportedMediaFileName('notes.txt'), null);

  assert.deepEqual(inferProjectionFromFilename('concert_vr180_sbs.mp4'), {
    target: '360',
    projection: '180-sbs',
  });
  assert.deepEqual(inferProjectionFromFilename('space_360_tb.mp4'), {
    target: '360',
    projection: '360-tb',
  });
  assert.deepEqual(inferProjectionFromFilename('family_movie.mp4'), {
    target: 'cinema',
    projection: '360-mono',
  });
});

test('gallery filtering and file size formatting', () => {
  const sample = [
    {
      id: '1',
      name: 'clip.mp4',
      kind: 'video' as const,
      sourceType: 'device' as const,
      url: 'blob:1',
      defaultTarget: 'cinema' as const,
      defaultProjection: '360-mono' as const,
      addedAt: 'اليوم',
    },
    {
      id: '2',
      name: 'pano.jpg',
      kind: 'image' as const,
      sourceType: 'device' as const,
      url: 'blob:2',
      defaultTarget: '360' as const,
      defaultProjection: '360-mono' as const,
      addedAt: 'اليوم',
    },
  ];
  assert.equal(filterGalleryItems(sample, 'all').length, 2);
  assert.equal(filterGalleryItems(sample, 'video').length, 1);
  assert.equal(filterGalleryItems(sample, 'image').length, 1);
  assert.equal(cycleGalleryFilter('all'), 'video');
  assert.equal(cycleGalleryFilter('video'), 'image');
  assert.equal(cycleGalleryFilter('image'), 'all');
  assert.equal(formatFileSize(1572864), '1.5 MB');
});

test('browser input resolver distinguishes direct URLs from search queries', () => {
  assert.deepEqual(resolveBrowserInput('https://openai.com/ar/'), {
    type: 'url',
    url: 'https://openai.com/ar/',
  });
  assert.deepEqual(resolveBrowserInput('ar.wikipedia.org/wiki/VR'), {
    type: 'url',
    url: 'https://ar.wikipedia.org/wiki/VR',
  });
  assert.deepEqual(resolveBrowserInput('الواقع الافتراضي في التعليم'), {
    type: 'search',
    query: 'الواقع الافتراضي في التعليم',
  });
});

test('volume slider helpers clamp, step, and format percentages cleanly', () => {
  assert.deepEqual([...VOLUME_SLIDER_STEPS], [20, 40, 60, 80, 100]);
  assert.equal(clampVolume(1.5), 1);
  assert.equal(clampVolume(-0.2), 0);
  assert.equal(clampVolume(Number.NaN), 0.8);
  assert.equal(stepVolume(0.8, 0.1), 0.9);
  assert.equal(stepVolume(0.95, 0.1), 1);
  assert.equal(stepVolume(0.05, -0.1), 0);
  assert.equal(formatVolumePercent(0.6, false), '60%');
  assert.equal(formatVolumePercent(0.6, true), '0%');
});

test('shortestAngleDiffRadians wraps smoothly across +-PI', () => {
  const diff1 = shortestAngleDiffRadians(Math.PI * 0.9, -Math.PI * 0.9);
  assert.ok(Math.abs(diff1 + Math.PI * 0.2) < 1e-6);
  const diff2 = shortestAngleDiffRadians(-Math.PI * 0.9, Math.PI * 0.9);
  assert.ok(Math.abs(diff2 - Math.PI * 0.2) < 1e-6);
  assert.ok(Math.abs(shortestAngleDiffRadians(0.5, 0.5)) < 1e-6);
});

test('curated websites and scene environments cycle through all presets', () => {
  assert.ok(CURATED_WEBSITES.length >= 8);
  assert.equal(ENVIRONMENT_OPTIONS.length, 5);

  let env = cycleSceneEnvironment('observatory');
  assert.equal(env, 'living_room');
  env = cycleSceneEnvironment(env);
  assert.equal(env, 'beach');
  env = cycleSceneEnvironment(env);
  assert.equal(env, 'moon');
  env = cycleSceneEnvironment(env);
  assert.equal(env, 'bedroom');
  env = cycleSceneEnvironment(env);
  assert.equal(env, 'observatory');
});

test('gallery folder extraction, folder filtering, and next-item cycling', () => {
  const sample = [
    {
      id: 'a',
      name: 'beach.mp4',
      kind: 'video' as const,
      sourceType: 'device' as const,
      url: 'blob:a',
      folderName: 'Camera',
      defaultTarget: 'cinema' as const,
      defaultProjection: '360-mono' as const,
      addedAt: 'اليوم',
    },
    {
      id: 'b',
      name: 'pano.jpg',
      kind: 'image' as const,
      sourceType: 'device' as const,
      url: 'blob:b',
      folderName: 'VR',
      defaultTarget: '360' as const,
      defaultProjection: '360-mono' as const,
      addedAt: 'اليوم',
    },
    {
      id: 'c',
      name: 'sunset.jpg',
      kind: 'image' as const,
      sourceType: 'device' as const,
      url: 'blob:c',
      folderName: 'Camera',
      defaultTarget: 'cinema' as const,
      defaultProjection: '360-mono' as const,
      addedAt: 'اليوم',
    },
  ];

  const folders = extractGalleryFolders(sample);
  assert.deepEqual(folders, [
    { name: 'Camera', count: 2 },
    { name: 'VR', count: 1 },
  ]);
  assert.equal(filterGalleryItems(sample, 'all', 'Camera').length, 2);
  assert.equal(filterGalleryItems(sample, 'image', 'Camera').length, 1);

  assert.equal(getNextGalleryItem(sample, 'blob:a', 1)?.id, 'b');
  assert.equal(getNextGalleryItem(sample, 'blob:c', 1)?.id, 'a');
  assert.equal(getNextGalleryItem(sample, null, 1)?.id, 'a');
});

test('mapBrowserUvToGazeId maps Home grid, Results cards, Article links, and empty space', () => {
  const homeState = createInitialBrowserState();
  // Top-left card in 2x2 grid (x=0.25, y_canvas=0.45 => uvY = 1 - 0.45 = 0.55)
  assert.deepEqual(mapBrowserUvToGazeId(0.25, 0.55, homeState), {
    gazeId: 'browser:open-1',
    slot: 0,
  });
  // Bottom-right card in 2x2 grid (x=0.72, y_canvas=0.70 => uvY = 0.30)
  assert.deepEqual(mapBrowserUvToGazeId(0.72, 0.3, homeState), {
    gazeId: 'browser:open-4',
    slot: 3,
  });
  // Empty header margin
  assert.deepEqual(mapBrowserUvToGazeId(0.5, 0.92, homeState), {
    gazeId: null,
    slot: null,
  });

  const resultsState = {
    ...homeState,
    view: 'results' as const,
    results: [
      { id: '1', title: 'R1', url: 'https://a.com', snippet: '', domain: 'a.com' },
      { id: '2', title: 'R2', url: 'https://b.com', snippet: '', domain: 'b.com' },
    ],
  };
  const yCard2 = 1 - (182 + 165 + 60) / 875;
  assert.deepEqual(mapBrowserUvToGazeId(0.5, yCard2, resultsState), {
    gazeId: 'browser:open-2',
    slot: 1,
  });

  const articleState = {
    ...homeState,
    view: 'article' as const,
    currentPage: {
      title: 'T',
      url: 'https://a.com',
      blocks: [],
      links: [
        { title: 'L1', url: 'https://a.com/1', domain: 'a.com' },
        { title: 'L2', url: 'https://a.com/2', domain: 'a.com' },
      ],
      live: true,
    },
  };
  assert.deepEqual(mapBrowserUvToGazeId(0.7, 1 - 0.92, articleState), {
    gazeId: 'browser:open-2',
    slot: 1,
  });
});

test('mapGalleryUvToGazeId maps visible cards and ignores out-of-bounds areas', () => {
  const state = {
    items: [
      {
        id: '1',
        name: 'Item 1',
        kind: 'video' as const,
        sourceType: 'device' as const,
        url: 'blob:1',
        defaultTarget: 'cinema' as const,
        defaultProjection: '360-mono' as const,
        addedAt: 'اليوم',
      },
      {
        id: '2',
        name: 'Item 2',
        kind: 'image' as const,
        sourceType: 'device' as const,
        url: 'blob:2',
        defaultTarget: '360' as const,
        defaultProjection: '360-mono' as const,
        addedAt: 'اليوم',
      },
    ],
    filter: 'all' as const,
    folderFilter: 'all',
    scrollOffset: 0,
    preferredTarget: 'auto' as const,
  };

  const ySlot1 = 1 - (138 + 60) / 875;
  const ySlot2 = 1 - (138 + 172 + 60) / 875;
  assert.deepEqual(mapGalleryUvToGazeId(0.5, ySlot1, state), {
    gazeId: 'gallery:open-1',
    slot: 0,
  });
  assert.deepEqual(mapGalleryUvToGazeId(0.5, ySlot2, state), {
    gazeId: 'gallery:open-2',
    slot: 1,
  });
  assert.deepEqual(mapGalleryUvToGazeId(0.5, 0.05, state), {
    gazeId: null,
    slot: null,
  });
});


