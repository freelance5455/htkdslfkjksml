import * as THREE from 'three';
import {
  BrowserState,
  CURATED_WEBSITES,
  isBookmarkSaved,
} from './vrState';

export class BrowserScreenRenderer {
  public readonly canvas: HTMLCanvasElement;
  public readonly texture: THREE.CanvasTexture;
  private ctx: CanvasRenderingContext2D;

  constructor(isSoftwareGl: boolean) {
    this.canvas = document.createElement('canvas');
    this.canvas.width = isSoftwareGl ? 1024 : 1400;
    this.canvas.height = isSoftwareGl ? 640 : 875;
    const ctx = this.canvas.getContext('2d');
    if (!ctx) throw new Error('Could not create browser canvas context');
    this.ctx = ctx;

    this.texture = new THREE.CanvasTexture(this.canvas);
    this.texture.colorSpace = THREE.SRGBColorSpace;
    this.texture.minFilter = THREE.LinearFilter;
    this.texture.magFilter = THREE.LinearFilter;
  }

  private wrapLines(text: string, maxWidth: number): string[] {
    const words = text.split(/\s+/);
    const lines: string[] = [];
    let current = '';
    for (const word of words) {
      const test = current ? `${current} ${word}` : word;
      if (this.ctx.measureText(test).width <= maxWidth) {
        current = test;
      } else {
        if (current) lines.push(current);
        current = word;
      }
    }
    if (current) lines.push(current);
    return lines;
  }

  public render(state: BrowserState): void {
    const { width: w, height: h } = this.canvas;
    const ctx = this.ctx;
    const scale = w / 1400;

    ctx.fillStyle = '#0f1623';
    ctx.fillRect(0, 0, w, h);

    // Top Browser Address / Google Bar
    ctx.fillStyle = '#172033';
    ctx.fillRect(0, 0, w, 108 * scale);
    ctx.fillStyle = '#27344d';
    ctx.fillRect(0, 107 * scale, w, 2 * scale);

    // Google Brand Wordmark (left)
    const gX = 48 * scale;
    const gY = 66 * scale;
    ctx.font = `700 ${Math.round(34 * scale)}px "Plus Jakarta Sans", sans-serif`;
    ctx.textAlign = 'left';
    ctx.direction = 'ltr';
    const letters: Array<[string, string]> = [
      ['G', '#4285F4'],
      ['o', '#EA4335'],
      ['o', '#FBBC05'],
      ['g', '#4285F4'],
      ['l', '#34A853'],
      ['e', '#EA4335'],
    ];
    let cursorX = gX;
    for (const [ch, col] of letters) {
      ctx.fillStyle = col;
      ctx.fillText(ch, cursorX, gY);
      cursorX += ctx.measureText(ch).width + 1 * scale;
    }

    // Address / Search Pill Box
    const barX = 210 * scale;
    const barY = 24 * scale;
    const barW = w - 260 * scale;
    const barH = 60 * scale;
    ctx.fillStyle = '#0b111c';
    ctx.beginPath();
    ctx.roundRect(barX, barY, barW, barH, 16 * scale);
    ctx.fill();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2 * scale;
    ctx.stroke();

    ctx.fillStyle = '#f8fafc';
    ctx.font = `600 ${Math.round(25 * scale)}px Cairo, "Plus Jakarta Sans", sans-serif`;
    const displayInput =
      state.view === 'article' && state.currentPage
        ? state.currentPage.url
        : state.view === 'bookmarks'
          ? `المواقع المحفوظة (${state.savedBookmarks.length})`
          : `${state.inputText || 'اكتب للبحث أو اختر موقعاً...'}_`;
    const inputIsRtl = /[\u0600-\u06FF]/.test(displayInput);
    ctx.direction = inputIsRtl ? 'rtl' : 'ltr';
    ctx.textAlign = 'right';
    ctx.fillText(displayInput.slice(0, 56), barX + barW - 24 * scale, barY + 40 * scale);

    if (state.loading) {
      ctx.direction = 'rtl';
      ctx.fillStyle = '#38bdf8';
      ctx.textAlign = 'center';
      ctx.font = `700 ${Math.round(36 * scale)}px Cairo, sans-serif`;
      ctx.fillText('جاري البحث وتحميل الموقع من الويب...', w / 2, h * 0.5);
      this.texture.needsUpdate = true;
      return;
    }

    if (state.view === 'home') {
      ctx.direction = 'rtl';
      ctx.textAlign = 'center';
      ctx.font = `700 ${Math.round(52 * scale)}px "Plus Jakarta Sans", Cairo, sans-serif`;
      ctx.fillStyle = '#f8fafc';
      ctx.fillText('اختر موقعاً للتصفح المباشر', w / 2, 194 * scale);

      ctx.fillStyle = '#94a3b8';
      ctx.font = `500 ${Math.round(23 * scale)}px Cairo, sans-serif`;
      ctx.fillText(
        'انظر مباشرة على أي بطاقة موقع لفتحه فوراً أو ابحث عبر لوحة المفاتيح بالأسفل',
        w / 2,
        244 * scale
      );

      const visibleSites = CURATED_WEBSITES.slice(
        state.scrollOffset,
        state.scrollOffset + 4
      );
      const cardW = 590 * scale;
      const cardH = 190 * scale;
      const gapX = 44 * scale;
      const gapY = 34 * scale;
      const startX = (w - (cardW * 2 + gapX)) / 2;
      const startY = 300 * scale;

      visibleSites.forEach((site, idx) => {
        const col = idx % 2;
        const row = Math.floor(idx / 2);
        const cx = startX + col * (cardW + gapX);
        const cy = startY + row * (cardH + gapY);
        const isHovered = state.hoveredSlot === idx;

        ctx.fillStyle = isHovered ? '#1d2d47' : '#162033';
        ctx.beginPath();
        ctx.roundRect(cx, cy, cardW, cardH, 20 * scale);
        ctx.fill();
        ctx.strokeStyle = isHovered ? site.accent : '#2d3f5e';
        ctx.lineWidth = (isHovered ? 4 : 2) * scale;
        ctx.stroke();

        // Top accent bar
        ctx.fillStyle = site.accent;
        ctx.fillRect(cx + 22 * scale, cy, cardW - 44 * scale, 5 * scale);

        // Slot number badge (top-left)
        ctx.fillStyle = isHovered ? site.accent : '#0284c7';
        ctx.beginPath();
        ctx.roundRect(cx + 20 * scale, cy + 24 * scale, 52 * scale, 52 * scale, 12 * scale);
        ctx.fill();
        ctx.fillStyle = isHovered ? '#090c12' : '#ffffff';
        ctx.direction = 'ltr';
        ctx.textAlign = 'center';
        ctx.font = `700 ${Math.round(25 * scale)}px "JetBrains Mono", monospace`;
        ctx.fillText(String(idx + 1), cx + 46 * scale, cy + 59 * scale);

        // Category pill (top-left beside number)
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.roundRect(cx + 86 * scale, cy + 30 * scale, 126 * scale, 38 * scale, 10 * scale);
        ctx.fill();
        ctx.fillStyle = site.accent;
        ctx.direction = 'rtl';
        ctx.textAlign = 'center';
        ctx.font = `700 ${Math.round(18 * scale)}px Cairo, sans-serif`;
        ctx.fillText(site.category, cx + 149 * scale, cy + 55 * scale);

        // Site Title (right)
        ctx.fillStyle = '#f8fafc';
        ctx.direction = 'rtl';
        ctx.textAlign = 'right';
        ctx.font = `700 ${Math.round(30 * scale)}px Cairo, sans-serif`;
        ctx.fillText(site.label, cx + cardW - 26 * scale, cy + 114 * scale);

        // Domain (right bottom)
        ctx.fillStyle = '#34d399';
        ctx.direction = 'ltr';
        ctx.textAlign = 'right';
        ctx.font = `600 ${Math.round(21 * scale)}px "JetBrains Mono", "Plus Jakarta Sans", sans-serif`;
        ctx.fillText(site.domain, cx + cardW - 26 * scale, cy + 158 * scale);
      });

      const totalPages = Math.max(1, Math.ceil(CURATED_WEBSITES.length / 4));
      const curPage = Math.floor(state.scrollOffset / 4) + 1;
      ctx.direction = 'rtl';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#94a3b8';
      ctx.font = `600 ${Math.round(22 * scale)}px Cairo, sans-serif`;
      ctx.fillText(
        `المجموعة ${curPage} من ${totalPages}  ·  استخدم أسهم الأعلى/الأسفل لعرض المزيد من المواقع`,
        w / 2,
        792 * scale
      );
    } else if (state.view === 'bookmarks') {
      ctx.direction = 'rtl';
      ctx.textAlign = 'right';
      ctx.fillStyle = '#fbbf24';
      ctx.font = `700 ${Math.round(28 * scale)}px Cairo, sans-serif`;
      ctx.fillText(
        `المواقع المحفوظة (${state.savedBookmarks.length}) — انظر مباشرة لأي موقع للعودة إليه`,
        w - 54 * scale,
        158 * scale
      );

      if (state.savedBookmarks.length === 0) {
        ctx.textAlign = 'center';
        ctx.fillStyle = '#94a3b8';
        ctx.font = `500 ${Math.round(28 * scale)}px Cairo, sans-serif`;
        ctx.fillText(
          'لا توجد مواقع محفوظة بعد. افتح أي موقع ثم انظر لزر النجمة ★.',
          w / 2,
          h * 0.52
        );
      } else {
        const visible = state.savedBookmarks.slice(state.scrollOffset, state.scrollOffset + 4);
        visible.forEach((bm, i) => {
          const cardX = 54 * scale;
          const cardY = (182 + i * 165) * scale;
          const cardW = w - 108 * scale;
          const cardH = 146 * scale;
          const isHovered = state.hoveredSlot === i;

          ctx.fillStyle = isHovered ? '#1f293d' : '#151e2e';
          ctx.beginPath();
          ctx.roundRect(cardX, cardY, cardW, cardH, 16 * scale);
          ctx.fill();
          ctx.strokeStyle = isHovered ? '#fbbf24' : '#d97706';
          ctx.lineWidth = (isHovered ? 3.5 : 1.5) * scale;
          ctx.stroke();

          ctx.fillStyle = '#f59e0b';
          ctx.beginPath();
          ctx.roundRect(cardX + 18 * scale, cardY + 26 * scale, 52 * scale, 52 * scale, 12 * scale);
          ctx.fill();
          ctx.fillStyle = '#090c12';
          ctx.direction = 'ltr';
          ctx.textAlign = 'center';
          ctx.font = `700 ${Math.round(26 * scale)}px "JetBrains Mono", monospace`;
          ctx.fillText(String(state.scrollOffset + i + 1), cardX + 44 * scale, cardY + 61 * scale);

          ctx.direction = 'ltr';
          ctx.textAlign = 'right';
          ctx.fillStyle = '#34d399';
          ctx.font = `500 ${Math.round(20 * scale)}px "Plus Jakarta Sans", sans-serif`;
          ctx.fillText(`${bm.domain} · ${bm.savedAt}`, cardX + cardW - 24 * scale, cardY + 38 * scale);

          ctx.direction = /[\u0600-\u06FF]/.test(bm.title) ? 'rtl' : 'ltr';
          ctx.fillStyle = '#f8fafc';
          ctx.font = `700 ${Math.round(28 * scale)}px Cairo, sans-serif`;
          ctx.fillText(bm.title.slice(0, 62), cardX + cardW - 24 * scale, cardY + 82 * scale);

          ctx.direction = 'ltr';
          ctx.fillStyle = '#94a3b8';
          ctx.font = `400 ${Math.round(19 * scale)}px "Plus Jakarta Sans", sans-serif`;
          ctx.fillText(bm.url.slice(0, 74), cardX + cardW - 24 * scale, cardY + 120 * scale);
        });
      }
    } else if (state.view === 'results') {
      ctx.direction = 'rtl';
      ctx.textAlign = 'right';
      ctx.fillStyle = '#94a3b8';
      ctx.font = `600 ${Math.round(24 * scale)}px Cairo, sans-serif`;
      ctx.fillText(
        `نتائج البحث عن: "${state.query}" (${state.results.length}) — انظر لأي نتيجة لفتحها`,
        w - 54 * scale,
        156 * scale
      );

      const visible = state.results.slice(state.scrollOffset, state.scrollOffset + 4);
      visible.forEach((item, i) => {
        const cardX = 54 * scale;
        const cardY = (182 + i * 165) * scale;
        const cardW = w - 108 * scale;
        const cardH = 146 * scale;
        const isHovered = state.hoveredSlot === i;

        ctx.fillStyle = isHovered ? '#1e2c44' : '#151e2e';
        ctx.beginPath();
        ctx.roundRect(cardX, cardY, cardW, cardH, 16 * scale);
        ctx.fill();
        ctx.strokeStyle = isHovered ? '#38bdf8' : '#26354d';
        ctx.lineWidth = (isHovered ? 3.5 : 1.5) * scale;
        ctx.stroke();

        ctx.fillStyle = isHovered ? '#38bdf8' : '#0284c7';
        ctx.beginPath();
        ctx.roundRect(cardX + 18 * scale, cardY + 24 * scale, 52 * scale, 52 * scale, 12 * scale);
        ctx.fill();
        ctx.fillStyle = isHovered ? '#090c12' : '#ffffff';
        ctx.direction = 'ltr';
        ctx.textAlign = 'center';
        ctx.font = `700 ${Math.round(26 * scale)}px "JetBrains Mono", monospace`;
        ctx.fillText(String(state.scrollOffset + i + 1), cardX + 44 * scale, cardY + 59 * scale);

        ctx.direction = 'ltr';
        ctx.textAlign = 'right';
        ctx.fillStyle = '#34d399';
        ctx.font = `500 ${Math.round(20 * scale)}px "Plus Jakarta Sans", sans-serif`;
        ctx.fillText(item.domain, cardX + cardW - 24 * scale, cardY + 36 * scale);

        ctx.direction = /[\u0600-\u06FF]/.test(item.title) ? 'rtl' : 'ltr';
        ctx.fillStyle = '#60a5fa';
        ctx.font = `700 ${Math.round(27 * scale)}px Cairo, sans-serif`;
        ctx.fillText(item.title.slice(0, 68), cardX + cardW - 24 * scale, cardY + 76 * scale);

        ctx.direction = /[\u0600-\u06FF]/.test(item.snippet) ? 'rtl' : 'ltr';
        ctx.fillStyle = '#cbd5e1';
        ctx.font = `400 ${Math.round(22 * scale)}px Cairo, sans-serif`;
        ctx.fillText(item.snippet.slice(0, 88), cardX + cardW - 24 * scale, cardY + 118 * scale);
      });
    } else if (state.view === 'article' && state.currentPage) {
      const page = state.currentPage;
      const saved = isBookmarkSaved(state.savedBookmarks, page.url);

      ctx.direction = /[\u0600-\u06FF]/.test(page.title) ? 'rtl' : 'ltr';
      ctx.textAlign = 'right';
      ctx.fillStyle = '#38bdf8';
      ctx.font = `700 ${Math.round(32 * scale)}px Cairo, sans-serif`;
      ctx.fillText(page.title.slice(0, 56), w - 54 * scale, 164 * scale);

      ctx.direction = 'rtl';
      ctx.textAlign = 'left';
      ctx.fillStyle = saved ? '#fbbf24' : '#94a3b8';
      ctx.font = `700 ${Math.round(22 * scale)}px Cairo, sans-serif`;
      ctx.fillText(saved ? 'محفوظ ★' : 'غير محفوظ ☆', 54 * scale, 164 * scale);

      ctx.direction = 'ltr';
      ctx.textAlign = 'right';
      ctx.fillStyle = '#34d399';
      ctx.font = `400 ${Math.round(20 * scale)}px "Plus Jakarta Sans", sans-serif`;
      ctx.fillText(page.url.slice(0, 85), w - 54 * scale, 202 * scale);

      const hasLinks = (page.links?.length ?? 0) > 0;
      const contentBottomLimit = hasLinks ? h - 145 * scale : h - 55 * scale;
      let y = 254 * scale;
      const maxW = w - 120 * scale;
      const blocks = state.scrollOffset > 0 ? page.blocks.slice(state.scrollOffset) : page.blocks;

      for (const block of blocks) {
        if (y > contentBottomLimit) break;
        if (block.type === 'heading') {
          ctx.fillStyle = '#f8fafc';
          ctx.font = `700 ${Math.round(28 * scale)}px Cairo, sans-serif`;
        } else {
          ctx.fillStyle = '#cbd5e1';
          ctx.font = `400 ${Math.round(24 * scale)}px Cairo, sans-serif`;
        }
        const isAr = /[\u0600-\u06FF]/.test(block.text);
        ctx.direction = isAr ? 'rtl' : 'ltr';
        ctx.textAlign = isAr ? 'right' : 'left';
        const anchorX = isAr ? w - 60 * scale : 60 * scale;
        const lines = this.wrapLines(block.text, maxW);
        for (const line of lines.slice(0, 4)) {
          if (y > contentBottomLimit) break;
          ctx.fillText(line, anchorX, y);
          y += 38 * scale;
        }
        y += 18 * scale;
      }

      if (hasLinks && page.links) {
        const footerY = h - 118 * scale;
        ctx.fillStyle = '#141e30';
        ctx.fillRect(48 * scale, footerY - 12 * scale, w - 96 * scale, 108 * scale);
        ctx.strokeStyle = '#2a3a57';
        ctx.lineWidth = 1.5 * scale;
        ctx.strokeRect(48 * scale, footerY - 12 * scale, w - 96 * scale, 108 * scale);

        ctx.direction = 'rtl';
        ctx.textAlign = 'right';
        ctx.fillStyle = '#38bdf8';
        ctx.font = `700 ${Math.round(20 * scale)}px Cairo, sans-serif`;
        ctx.fillText('روابط داخل الصفحة (انظر للرابط لفتحه):', w - 66 * scale, footerY + 18 * scale);

        const linkCount = Math.min(4, page.links.length);
        const colW = (w - 132 * scale) / Math.max(1, linkCount);
        page.links.slice(0, 4).forEach((lnk, idx) => {
          const lx = 66 * scale + idx * colW;
          const isHovered = state.hoveredSlot === idx;
          ctx.fillStyle = isHovered ? '#1d4ed8' : '#1e2c44';
          ctx.beginPath();
          ctx.roundRect(lx, footerY + 32 * scale, colW - 12 * scale, 50 * scale, 10 * scale);
          ctx.fill();
          if (isHovered) {
            ctx.strokeStyle = '#38bdf8';
            ctx.lineWidth = 2.5 * scale;
            ctx.stroke();
          }

          ctx.direction = /[\u0600-\u06FF]/.test(lnk.title) ? 'rtl' : 'ltr';
          ctx.textAlign = 'right';
          ctx.fillStyle = '#ffffff';
          ctx.font = `600 ${Math.round(19 * scale)}px Cairo, sans-serif`;
          ctx.fillText(
            `#${idx + 1} ${lnk.title.slice(0, 22)}`,
            lx + colW - 22 * scale,
            footerY + 64 * scale
          );
        });
      }
    }

    this.texture.needsUpdate = true;
  }

  public dispose(): void {
    this.texture.dispose();
  }
}
