import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { buildEnvironmentController } from './environments';
import {
  ARABIC_KEY_ROWS,
  CINEMA_SCREEN_OPTIONS,
  CinemaScreenSize,
  ENGLISH_KEY_ROWS,
  ENVIRONMENT_OPTIONS,
  formatVolumePercent,
  getProjectionSpec,
  KeyboardLang,
  PROJECTION_OPTIONS,
  SceneEnvironmentId,
  TheaterLightMode,
  Video360Projection,
  VOLUME_SLIDER_STEPS,
  VRMode,
} from './vrState';

export interface GazeButtonMeta {
  id: string;
  group: THREE.Group;
  hitMesh: THREE.Mesh;
  borderMat: THREE.MeshBasicMaterial;
  faceMat: THREE.MeshBasicMaterial;
  labelCanvas?: HTMLCanvasElement;
  labelCtx?: CanvasRenderingContext2D;
  labelTex?: THREE.CanvasTexture;
  baseScale: number;
  accentHex: string;
  active?: boolean;
  isSliderSegment?: boolean;
}

export interface VRSceneBundle {
  scene: THREE.Scene;
  hubGroup: THREE.Group;
  player360Group: THREE.Group;
  player360MenuGroup: THREE.Group;
  player360ShowGroup: THREE.Group;
  cinemaGroup: THREE.Group;
  browserGroup: THREE.Group;
  galleryGroup: THREE.Group;
  floorQuickGroup: THREE.Group;
  sphere360Mesh: THREE.Mesh;
  sphere360Mat: THREE.ShaderMaterial;
  set360Texture: (texture: THREE.Texture) => void;
  set360Projection: (projection: Video360Projection) => void;
  set360Eye: (eyeIndex: 0 | 1) => void;
  set360MenuVisible: (visible: boolean) => void;
  is360MenuVisible: () => boolean;
  cinemaScreenMesh: THREE.Mesh;
  cinemaScreenMat: THREE.MeshBasicMaterial;
  cinemaFrameGroup: THREE.Group;
  cinemaBounceLight: THREE.PointLight;
  cinemaAmbientLight: THREE.HemisphereLight;
  cinemaWallLight: THREE.PointLight;
  browserScreenMesh: THREE.Mesh;
  browserScreenMat: THREE.MeshBasicMaterial;
  galleryScreenMesh: THREE.Mesh;
  galleryScreenMat: THREE.MeshBasicMaterial;
  keyboardContainer: THREE.Group;
  animatedProps: {
    hubGlobe: THREE.Group;
    hubCinemaIcon: THREE.Group;
    hubBrowserIcon: THREE.Group;
    hubRing: THREE.Mesh;
    stars: THREE.Points;
  };
  interactablesByMode: Record<VRMode, THREE.Mesh[]>;
  floorInteractables: THREE.Mesh[];
  getActiveInteractables: (mode: VRMode) => THREE.Mesh[];
  buttons: Map<string, GazeButtonMeta>;
  updateButtonLabel: (id: string, title: string, subtitle?: string, active?: boolean) => void;
  rebuildKeyboard: (lang: KeyboardLang) => void;
  setActiveModeVisibility: (mode: VRMode) => void;
  setTheaterLighting: (mode: TheaterLightMode, screenColor?: THREE.Color) => void;
  setCinemaScreenScale: (size: CinemaScreenSize) => void;
  updateDynamicHudTextures: (
    player360Info: { title: string; timeText: string; isPlaying: boolean },
    cinemaInfo: { title: string; timeText: string; isPlaying: boolean }
  ) => void;
  updateVolumeSliders: (volume: number, muted: boolean) => void;
  setEnvironment: (envId: SceneEnvironmentId, activeMode: VRMode) => void;
  updateEnvironment: (deltaSec: number, nowMs: number) => void;
  dispose: () => void;
}

function fitFont(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  startPx: number,
  minPx: number,
  weight: number
): number {
  let px = startPx;
  while (px > minPx) {
    ctx.font = `${weight} ${px}px Cairo, "Plus Jakarta Sans", sans-serif`;
    if (ctx.measureText(text).width <= maxWidth) break;
    px -= 2;
  }
  return px;
}

function drawCanvasIcon(
  ctx: CanvasRenderingContext2D,
  iconName: string,
  cx: number,
  cy: number,
  size: number,
  color: string
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = Math.max(3, size * 0.12);
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  const r = size * 0.45;

  switch (iconName) {
    case 'play': {
      ctx.beginPath();
      ctx.moveTo(-r * 0.6, -r * 0.85);
      ctx.lineTo(r * 0.9, 0);
      ctx.lineTo(-r * 0.6, r * 0.85);
      ctx.closePath();
      ctx.fill();
      break;
    }
    case 'pause': {
      const bw = r * 0.42;
      const bh = r * 1.55;
      ctx.beginPath();
      ctx.roundRect(-r * 0.72, -bh / 2, bw, bh, 4);
      ctx.roundRect(r * 0.3, -bh / 2, bw, bh, 4);
      ctx.fill();
      break;
    }
    case 'seek-back': {
      ctx.beginPath();
      ctx.moveTo(0, -r * 0.65);
      ctx.lineTo(-r * 0.75, 0);
      ctx.lineTo(0, r * 0.65);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(-r * 0.7, -r * 0.65);
      ctx.lineTo(-r * 1.4, 0);
      ctx.lineTo(-r * 0.7, r * 0.65);
      ctx.closePath();
      ctx.fill();
      ctx.direction = 'ltr';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.font = `800 ${Math.round(size * 0.48)}px "JetBrains Mono", sans-serif`;
      ctx.fillText('10', r * 0.18, 2);
      break;
    }
    case 'seek-fwd': {
      ctx.direction = 'ltr';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';
      ctx.font = `800 ${Math.round(size * 0.48)}px "JetBrains Mono", sans-serif`;
      ctx.fillText('10', -r * 0.18, 2);
      ctx.beginPath();
      ctx.moveTo(0, -r * 0.65);
      ctx.lineTo(r * 0.75, 0);
      ctx.lineTo(0, r * 0.65);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(r * 0.7, -r * 0.65);
      ctx.lineTo(r * 1.4, 0);
      ctx.lineTo(r * 0.7, r * 0.65);
      ctx.closePath();
      ctx.fill();
      break;
    }
    case 'next': {
      ctx.beginPath();
      ctx.moveTo(-r * 0.85, -r * 0.75);
      ctx.lineTo(r * 0.35, 0);
      ctx.lineTo(-r * 0.85, r * 0.75);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.roundRect(r * 0.5, -r * 0.75, r * 0.3, r * 1.5, 3);
      ctx.fill();
      break;
    }
    case 'home': {
      ctx.beginPath();
      ctx.moveTo(-r * 0.95, 0);
      ctx.lineTo(0, -r * 0.88);
      ctx.lineTo(r * 0.95, 0);
      ctx.stroke();
      ctx.beginPath();
      ctx.roundRect(-r * 0.66, -r * 0.05, r * 1.32, r * 0.92, 4);
      ctx.stroke();
      ctx.beginPath();
      ctx.roundRect(-r * 0.22, r * 0.34, r * 0.44, r * 0.52, 2);
      ctx.fill();
      break;
    }
    case 'volume-on': {
      ctx.beginPath();
      ctx.moveTo(-r * 0.95, -r * 0.35);
      ctx.lineTo(-r * 0.45, -r * 0.35);
      ctx.lineTo(r * 0.1, -r * 0.82);
      ctx.lineTo(r * 0.1, r * 0.82);
      ctx.lineTo(-r * 0.45, r * 0.35);
      ctx.lineTo(-r * 0.95, r * 0.35);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.arc(r * 0.15, 0, r * 0.52, -0.75, 0.75);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(r * 0.15, 0, r * 0.88, -0.82, 0.82);
      ctx.stroke();
      break;
    }
    case 'volume-off': {
      ctx.fillStyle = '#f87171';
      ctx.strokeStyle = '#f87171';
      ctx.beginPath();
      ctx.moveTo(-r * 0.95, -r * 0.35);
      ctx.lineTo(-r * 0.45, -r * 0.35);
      ctx.lineTo(r * 0.1, -r * 0.82);
      ctx.lineTo(r * 0.1, r * 0.82);
      ctx.lineTo(-r * 0.45, r * 0.35);
      ctx.lineTo(-r * 0.95, r * 0.35);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(r * 0.36, -r * 0.42);
      ctx.lineTo(r * 0.98, r * 0.42);
      ctx.moveTo(r * 0.98, -r * 0.42);
      ctx.lineTo(r * 0.36, r * 0.42);
      ctx.stroke();
      break;
    }
    case 'minus': {
      ctx.beginPath();
      ctx.moveTo(-r * 0.72, 0);
      ctx.lineTo(r * 0.72, 0);
      ctx.stroke();
      break;
    }
    case 'plus': {
      ctx.beginPath();
      ctx.moveTo(-r * 0.72, 0);
      ctx.lineTo(r * 0.72, 0);
      ctx.moveTo(0, -r * 0.72);
      ctx.lineTo(0, r * 0.72);
      ctx.stroke();
      break;
    }
    case 'eye': {
      ctx.beginPath();
      ctx.moveTo(-r * 1.15, 0);
      ctx.quadraticCurveTo(0, -r * 1.05, r * 1.15, 0);
      ctx.quadraticCurveTo(0, r * 1.05, -r * 1.15, 0);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.36, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case 'eye-off': {
      ctx.beginPath();
      ctx.moveTo(-r * 1.1, 0);
      ctx.quadraticCurveTo(0, -r * 0.95, r * 1.1, 0);
      ctx.quadraticCurveTo(0, r * 0.95, -r * 1.1, 0);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#f87171';
      ctx.beginPath();
      ctx.moveTo(-r * 0.92, r * 0.78);
      ctx.lineTo(r * 0.92, -r * 0.78);
      ctx.stroke();
      break;
    }
    case 'up': {
      ctx.beginPath();
      ctx.moveTo(-r * 0.78, r * 0.42);
      ctx.lineTo(0, -r * 0.52);
      ctx.lineTo(r * 0.78, r * 0.42);
      ctx.stroke();
      break;
    }
    case 'down': {
      ctx.beginPath();
      ctx.moveTo(-r * 0.78, -r * 0.42);
      ctx.lineTo(0, r * 0.52);
      ctx.lineTo(r * 0.78, -r * 0.42);
      ctx.stroke();
      break;
    }
    case 'back': {
      ctx.beginPath();
      ctx.moveTo(-r * 0.78, -r * 0.15);
      ctx.lineTo(r * 0.35, -r * 0.15);
      ctx.arc(r * 0.35, r * 0.28, r * 0.43, -Math.PI / 2, Math.PI / 2);
      ctx.lineTo(-r * 0.2, r * 0.71);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-r * 0.32, -r * 0.62);
      ctx.lineTo(-r * 0.84, -r * 0.15);
      ctx.lineTo(-r * 0.32, r * 0.32);
      ctx.stroke();
      break;
    }
    case 'star-outline':
    case 'star-filled': {
      ctx.beginPath();
      for (let i = 0; i < 10; i++) {
        const rad = i % 2 === 0 ? r * 0.92 : r * 0.4;
        const ang = -Math.PI / 2 + (i * Math.PI) / 5;
        const px = Math.cos(ang) * rad;
        const py = Math.sin(ang) * rad;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      if (iconName === 'star-filled') {
        ctx.fillStyle = '#fbbf24';
        ctx.fill();
      } else {
        ctx.stroke();
      }
      break;
    }
    case 'bookmarks': {
      ctx.beginPath();
      ctx.moveTo(-r * 0.62, -r * 0.85);
      ctx.lineTo(r * 0.62, -r * 0.85);
      ctx.lineTo(r * 0.62, r * 0.88);
      ctx.lineTo(0, r * 0.38);
      ctx.lineTo(-r * 0.62, r * 0.88);
      ctx.closePath();
      ctx.stroke();
      break;
    }
    case 'search': {
      ctx.beginPath();
      ctx.arc(-r * 0.18, -r * 0.18, r * 0.56, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(r * 0.24, r * 0.24);
      ctx.lineTo(r * 0.84, r * 0.84);
      ctx.stroke();
      break;
    }
    case 'backspace': {
      ctx.beginPath();
      ctx.moveTo(-r * 1.0, 0);
      ctx.lineTo(-r * 0.42, -r * 0.66);
      ctx.lineTo(r * 0.88, -r * 0.66);
      ctx.lineTo(r * 0.88, r * 0.66);
      ctx.lineTo(-r * 0.42, r * 0.66);
      ctx.closePath();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-r * 0.1, -r * 0.28);
      ctx.lineTo(r * 0.46, r * 0.28);
      ctx.moveTo(r * 0.46, -r * 0.28);
      ctx.lineTo(-r * 0.1, r * 0.28);
      ctx.stroke();
      break;
    }
    case 'space': {
      ctx.beginPath();
      ctx.moveTo(-r * 1.2, -r * 0.24);
      ctx.lineTo(-r * 1.2, r * 0.34);
      ctx.lineTo(r * 1.2, r * 0.34);
      ctx.lineTo(r * 1.2, -r * 0.24);
      ctx.stroke();
      break;
    }
    case 'clear': {
      ctx.strokeStyle = '#f87171';
      ctx.beginPath();
      ctx.moveTo(-r * 0.62, -r * 0.62);
      ctx.lineTo(r * 0.62, r * 0.62);
      ctx.moveTo(r * 0.62, -r * 0.62);
      ctx.lineTo(-r * 0.62, r * 0.62);
      ctx.stroke();
      break;
    }
    case 'recenter': {
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.56, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.18, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(0, -r * 0.96);
      ctx.lineTo(0, -r * 0.68);
      ctx.moveTo(0, r * 0.68);
      ctx.lineTo(0, r * 0.96);
      ctx.moveTo(-r * 0.96, 0);
      ctx.lineTo(-r * 0.68, 0);
      ctx.moveTo(r * 0.68, 0);
      ctx.lineTo(r * 0.96, 0);
      ctx.stroke();
      break;
    }
    case 'folder-plus': {
      ctx.beginPath();
      ctx.moveTo(-r * 0.92, -r * 0.58);
      ctx.lineTo(-r * 0.22, -r * 0.58);
      ctx.lineTo(0, -r * 0.34);
      ctx.lineTo(r * 0.92, -r * 0.34);
      ctx.lineTo(r * 0.92, r * 0.68);
      ctx.lineTo(-r * 0.92, r * 0.68);
      ctx.closePath();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-r * 0.28, r * 0.17);
      ctx.lineTo(r * 0.28, r * 0.17);
      ctx.moveTo(0, -r * 0.11);
      ctx.lineTo(0, r * 0.45);
      ctx.stroke();
      break;
    }
    case 'globe': {
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.78, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.ellipse(0, 0, r * 0.36, r * 0.78, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-r * 0.76, 0);
      ctx.lineTo(r * 0.76, 0);
      ctx.stroke();
      break;
    }
    case 'sun': {
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.42, 0, Math.PI * 2);
      ctx.stroke();
      for (let i = 0; i < 8; i++) {
        const a = (i * Math.PI) / 4;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * r * 0.64, Math.sin(a) * r * 0.64);
        ctx.lineTo(Math.cos(a) * r * 0.9, Math.sin(a) * r * 0.9);
        ctx.stroke();
      }
      break;
    }
    case 'expand': {
      ctx.beginPath();
      ctx.moveTo(-r * 0.85, -r * 0.32);
      ctx.lineTo(-r * 0.85, -r * 0.85);
      ctx.lineTo(-r * 0.32, -r * 0.85);
      ctx.moveTo(r * 0.32, -r * 0.85);
      ctx.lineTo(r * 0.85, -r * 0.85);
      ctx.lineTo(r * 0.85, -r * 0.32);
      ctx.moveTo(-r * 0.85, r * 0.32);
      ctx.lineTo(-r * 0.85, r * 0.85);
      ctx.lineTo(-r * 0.32, r * 0.85);
      ctx.moveTo(r * 0.32, r * 0.85);
      ctx.lineTo(r * 0.85, r * 0.85);
      ctx.lineTo(r * 0.85, r * 0.32);
      ctx.stroke();
      break;
    }
  }

  ctx.restore();
}

function drawButtonCanvas(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  title: string,
  subtitle: string | undefined,
  accentHex: string,
  bgHex = '#111827',
  active = false
) {
  ctx.fillStyle = active ? '#172840' : bgHex;
  ctx.fillRect(0, 0, w, h);

  ctx.fillStyle = accentHex;
  ctx.fillRect(0, 0, w, Math.max(6, h * (active ? 0.1 : 0.065)));

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const maxTextW = w * 0.86;

  if (title.startsWith('icon:') && !subtitle) {
    const [iconToken, labelPart] = title.slice(5).split('|');
    const iconColor = active ? accentHex : '#f8fafc';
    if (!labelPart) {
      const iconSize = Math.min(w * 0.56, h * 0.58);
      drawCanvasIcon(ctx, iconToken, w / 2, h * 0.54, iconSize, iconColor);
      return;
    }
    const iconSize = Math.min(w * 0.24, h * 0.44);
    const dir: CanvasDirection = /[\u0600-\u06FF]/.test(labelPart) ? 'rtl' : 'ltr';
    ctx.canvas.dir = dir;
    ctx.direction = dir;
    drawCanvasIcon(ctx, iconToken, w - iconSize * 0.9 - 14, h * 0.54, iconSize, accentHex);
    const labelPx = fitFont(ctx, labelPart, maxTextW - iconSize * 1.4, Math.round(h * 0.32), 14, 700);
    ctx.fillStyle = iconColor;
    ctx.textAlign = 'left';
    ctx.font = `700 ${labelPx}px Cairo, "Plus Jakarta Sans", sans-serif`;
    ctx.fillText(labelPart, 18, h * 0.54);
    return;
  }

  if (subtitle) {
    ctx.direction = /[\u0600-\u06FF]/.test(title) ? 'rtl' : 'ltr';
    const titlePx = fitFont(ctx, title, maxTextW, Math.round(h * 0.24), 18, 700);
    ctx.fillStyle = '#f8fafc';
    ctx.font = `700 ${titlePx}px Cairo, "Plus Jakarta Sans", sans-serif`;
    ctx.fillText(title, w / 2, h * 0.42);

    ctx.direction = /[\u0600-\u06FF]/.test(subtitle) ? 'rtl' : 'ltr';
    const subPx = fitFont(ctx, subtitle, maxTextW, Math.round(h * 0.14), 14, 500);
    ctx.fillStyle = '#94a3b8';
    ctx.font = `500 ${subPx}px Cairo, "Plus Jakarta Sans", sans-serif`;
    ctx.fillText(subtitle, w / 2, h * 0.74);
  } else {
    const dir: CanvasDirection = /[\u0600-\u06FF]/.test(title) ? 'rtl' : 'ltr';
    ctx.canvas.dir = dir;
    ctx.direction = dir;
    const titlePx = fitFont(ctx, title, maxTextW, Math.round(h * 0.34), 15, 700);
    ctx.fillStyle = active ? accentHex : '#f8fafc';
    ctx.font = `700 ${titlePx}px Cairo, "Plus Jakarta Sans", sans-serif`;
    ctx.fillText(title, w / 2, h * 0.54);
  }
}

function createGazeButton(
  id: string,
  title: string,
  subtitle: string | undefined,
  width: number,
  height: number,
  accentHex = '#38BDF8',
  bgHex = '#111827',
  active = false
): GazeButtonMeta {
  const group = new THREE.Group();

  const canvas = document.createElement('canvas');
  canvas.width = Math.max(160, Math.round(width * 340));
  canvas.height = Math.max(96, Math.round(height * 340));
  const ctx = canvas.getContext('2d')!;
  drawButtonCanvas(ctx, canvas.width, canvas.height, title, subtitle, accentHex, bgHex, active);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;

  const borderGeo = new THREE.BoxGeometry(width + 0.036, height + 0.036, 0.03);
  const borderMat = new THREE.MeshBasicMaterial({
    color: active ? accentHex : 0x26344a,
  });
  const borderMesh = new THREE.Mesh(borderGeo, borderMat);
  borderMesh.position.z = -0.018;
  group.add(borderMesh);

  const faceGeo = new THREE.PlaneGeometry(width, height);
  const faceMat = new THREE.MeshBasicMaterial({ map: tex });
  const hitMesh = new THREE.Mesh(faceGeo, faceMat);
  hitMesh.userData.gazeId = id;
  group.add(hitMesh);

  return {
    id,
    group,
    hitMesh,
    borderMat,
    faceMat,
    labelCanvas: canvas,
    labelCtx: ctx,
    labelTex: tex,
    baseScale: 1,
    accentHex,
    active,
  };
}

function createInfoBanner(width: number, height: number): {
  mesh: THREE.Mesh;
  update: (title: string, timeText: string) => void;
  dispose: () => void;
} {
  const canvas = document.createElement('canvas');
  canvas.width = 960;
  canvas.height = 150;
  const ctx = canvas.getContext('2d')!;
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;

  let lastKey = '';
  const update = (title: string, timeText: string) => {
    const key = `${title}|${timeText}`;
    if (key === lastKey) return;
    lastKey = key;

    ctx.fillStyle = '#0b111e';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#253349';
    ctx.lineWidth = 4;
    ctx.strokeRect(2, 2, canvas.width - 4, canvas.height - 4);

    ctx.direction = /[\u0600-\u06FF]/.test(title) ? 'rtl' : 'ltr';
    ctx.textAlign = 'right';
    ctx.fillStyle = '#f8fafc';
    const px = fitFont(ctx, title, 560, 34, 20, 700);
    ctx.font = `700 ${px}px Cairo, sans-serif`;
    ctx.fillText(title, canvas.width - 32, 58);

    ctx.direction = 'ltr';
    ctx.textAlign = 'left';
    ctx.fillStyle = '#38bdf8';
    ctx.font = '600 30px "JetBrains Mono", monospace';
    ctx.fillText(timeText, 32, 58);

    ctx.direction = 'rtl';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#94a3b8';
    ctx.font = '500 22px Cairo, sans-serif';
    ctx.fillText('التحكم بالنظر فقط — ثبّت نظرك على أي زر للتنفيذ', canvas.width / 2, 114);

    tex.needsUpdate = true;
  };

  update('جاهز', '00:00 / 00:00');
  const mesh = new THREE.Mesh(
    new THREE.PlaneGeometry(width, height),
    new THREE.MeshBasicMaterial({ map: tex })
  );

  return {
    mesh,
    update,
    dispose: () => {
      mesh.geometry.dispose();
      (mesh.material as THREE.Material).dispose();
      tex.dispose();
    },
  };
}

function createGazeVolumeSlider(
  prefix: '360' | 'cinema',
  mode: 'player360' | 'cinema',
  accentHex: string,
  registerButton: (m: VRMode | 'floor', btn: GazeButtonMeta) => void
): {
  group: THREE.Group;
  update: (volume: number, muted: boolean) => void;
  dispose: () => void;
} {
  const group = new THREE.Group();

  const trackWidth = 2.24;
  const trackHeight = 0.34;
  const trackCenterX = -0.27;

  const trackCanvas = document.createElement('canvas');
  trackCanvas.width = 760;
  trackCanvas.height = 132;
  const ctx = trackCanvas.getContext('2d')!;
  const trackTex = new THREE.CanvasTexture(trackCanvas);
  trackTex.colorSpace = THREE.SRGBColorSpace;
  trackTex.minFilter = THREE.LinearFilter;
  trackTex.magFilter = THREE.LinearFilter;

  const trackFrameMat = new THREE.MeshBasicMaterial({ color: 0x26344a });
  const trackFrame = new THREE.Mesh(
    new THREE.BoxGeometry(trackWidth + 0.036, trackHeight + 0.036, 0.028),
    trackFrameMat
  );
  trackFrame.position.set(trackCenterX, 0, -0.018);
  group.add(trackFrame);

  const trackPlaneMat = new THREE.MeshBasicMaterial({ map: trackTex });
  const trackPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(trackWidth, trackHeight),
    trackPlaneMat
  );
  trackPlane.position.set(trackCenterX, 0, 0);
  group.add(trackPlane);

  const segWidth = trackWidth / VOLUME_SLIDER_STEPS.length;
  VOLUME_SLIDER_STEPS.forEach((pct, idx) => {
    const segGroup = new THREE.Group();
    const segX = trackCenterX - trackWidth / 2 + segWidth * (idx + 0.5);
    segGroup.position.set(segX, 0, 0.008);

    const hoverMat = new THREE.MeshBasicMaterial({
      color: accentHex,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    });
    const hoverMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(segWidth - 0.016, trackHeight - 0.02),
      hoverMat
    );
    segGroup.add(hoverMesh);

    const hitMat = new THREE.MeshBasicMaterial({
      transparent: true,
      opacity: 0,
      depthWrite: false,
    });
    const hitMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(segWidth, trackHeight),
      hitMat
    );
    hitMesh.position.z = 0.004;
    const gazeId = `${prefix}:vol-set:${pct}`;
    hitMesh.userData.gazeId = gazeId;
    segGroup.add(hitMesh);

    group.add(segGroup);
    registerButton(mode, {
      id: gazeId,
      group: segGroup,
      hitMesh,
      borderMat: hoverMat,
      faceMat: hitMat,
      baseScale: 1,
      accentHex,
      isSliderSegment: true,
    });
  });

  const actionSpecs = [
    { id: `${prefix}:vol-down`, title: 'icon:minus', x: -1.68, w: 0.46, col: accentHex },
    { id: `${prefix}:vol-up`, title: 'icon:plus', x: 1.14, w: 0.46, col: accentHex },
    { id: `${prefix}:mute`, title: 'icon:volume-on', x: 1.7, w: 0.54, col: '#38BDF8' },
  ];
  actionSpecs.forEach((spec) => {
    const btn = createGazeButton(
      spec.id,
      spec.title,
      undefined,
      spec.w,
      trackHeight,
      spec.col,
      '#0b111e'
    );
    btn.group.position.set(spec.x, 0, 0);
    group.add(btn.group);
    registerButton(mode, btn);
  });

  let lastDrawKey = '';
  const update = (volume: number, muted: boolean) => {
    const effective = muted ? 0 : Math.max(0, Math.min(1, volume));
    const key = `${Math.round(effective * 100)}|${muted ? 1 : 0}`;
    if (key === lastDrawKey) return;
    lastDrawKey = key;

    const w = trackCanvas.width;
    const h = trackCanvas.height;

    ctx.fillStyle = '#0b111e';
    ctx.fillRect(0, 0, w, h);

    ctx.fillStyle = muted ? '#ef4444' : accentHex;
    ctx.fillRect(0, 0, w, 7);

    // Header row: crisp Speaker icon (right) + volume percentage (left)
    drawCanvasIcon(
      ctx,
      muted || effective <= 0 ? 'volume-off' : 'volume-on',
      w - 46,
      36,
      32,
      muted ? '#f87171' : accentHex
    );

    const pctText = `\u2066${formatVolumePercent(volume, muted)}\u2069`;
    ctx.direction = 'ltr';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = muted ? '#f87171' : accentHex;
    ctx.font = '700 28px "JetBrains Mono", monospace';
    ctx.fillText(pctText, 30, 36);

    // Slider groove
    const barX = 34;
    const barW = w - 68;
    const barY = 76;
    const barH = 14;

    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.roundRect(barX, barY, barW, barH, 7);
    ctx.fill();

    const fillW = Math.max(effective > 0 ? 14 : 0, barW * effective);
    if (fillW > 0) {
      ctx.fillStyle = muted ? '#64748b' : accentHex;
      ctx.beginPath();
      ctx.roundRect(barX, barY, fillW, barH, 7);
      ctx.fill();
    }

    // Step tick marks & labels (20%..100%)
    VOLUME_SLIDER_STEPS.forEach((stepPct, idx) => {
      const segCenter = barX + (barW / VOLUME_SLIDER_STEPS.length) * (idx + 0.5);
      const isReached = effective * 100 >= stepPct - 1;
      ctx.fillStyle = isReached ? '#f8fafc' : '#64748b';
      ctx.direction = 'ltr';
      ctx.textAlign = 'center';
      ctx.font = '600 17px "JetBrains Mono", monospace';
      ctx.fillText(`${stepPct}%`, segCenter, 112);

      if (idx > 0) {
        const divX = barX + (barW / VOLUME_SLIDER_STEPS.length) * idx;
        ctx.fillStyle = 'rgba(148, 163, 184, 0.25)';
        ctx.fillRect(divX - 1, barY - 4, 2, barH + 8);
      }
    });

    // Thumb knob
    const knobX = barX + barW * effective;
    const knobY = barY + barH / 2;
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(knobX, knobY, 13, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = muted ? '#f87171' : '#ffffff';
    ctx.lineWidth = 4;
    ctx.stroke();

    trackTex.needsUpdate = true;
  };

  update(0.8, false);

  return {
    group,
    update,
    dispose: () => {
      trackFrame.geometry.dispose();
      trackFrameMat.dispose();
      trackPlane.geometry.dispose();
      trackPlaneMat.dispose();
      trackTex.dispose();
    },
  };
}

export function buildVRScene(
  renderer: THREE.WebGLRenderer,
  isSoftwareGl: boolean
): VRSceneBundle {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#070b12');
  scene.fog = new THREE.FogExp2('#070b12', 0.025);

  const pmremGenerator = new THREE.PMREMGenerator(renderer);
  const envTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environment = envTex;
  pmremGenerator.dispose();

  const buttons = new Map<string, GazeButtonMeta>();
  const interactablesByMode: Record<VRMode, THREE.Mesh[]> = {
    hub: [],
    player360: [],
    cinema: [],
    browser: [],
    gallery: [],
  };
  const floorInteractables: THREE.Mesh[] = [];

  const registerButton = (mode: VRMode | 'floor', btn: GazeButtonMeta) => {
    buttons.set(btn.id, btn);
    if (mode === 'floor') {
      floorInteractables.push(btn.hitMesh);
    } else {
      interactablesByMode[mode].push(btn.hitMesh);
    }
  };

  const envController = buildEnvironmentController(renderer, isSoftwareGl);
  scene.add(envController.root);

  // =========================================================================
  // 1. OBSERVATORY HUB ENVIRONMENT (Interactive 3D Menu + Selectable Places)
  // =========================================================================
  const hubGroup = new THREE.Group();
  scene.add(hubGroup);

  const hubShellGroup = new THREE.Group();
  hubGroup.add(hubShellGroup);

  const hubKeyLight = new THREE.DirectionalLight(0xfff1d6, 1.5);
  hubKeyLight.position.set(5, 9, 6);
  hubGroup.add(hubKeyLight);

  const hubHemi = new THREE.HemisphereLight(0x60a5fa, 0x0f172a, 0.9);
  hubGroup.add(hubHemi);

  const floorMat = new THREE.MeshStandardMaterial({
    color: 0x111827,
    roughness: 0.72,
    metalness: 0.25,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    roughness: 0.28,
    metalness: 0.85,
  });
  const glowRingMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });

  const mainFloor = new THREE.Mesh(new THREE.CylinderGeometry(8.5, 8.8, 0.24, 48), floorMat);
  mainFloor.position.y = -0.14;
  hubShellGroup.add(mainFloor);

  const centerDais = new THREE.Mesh(new THREE.CylinderGeometry(2.1, 2.35, 0.06, 36), trimMat);
  centerDais.position.y = 0.01;
  hubShellGroup.add(centerDais);

  const hubRing = new THREE.Mesh(new THREE.TorusGeometry(2.25, 0.025, 12, 64), glowRingMat);
  hubRing.rotation.x = Math.PI / 2;
  hubRing.position.y = 0.04;
  hubShellGroup.add(hubRing);

  const outerRing = new THREE.Mesh(new THREE.TorusGeometry(8.3, 0.035, 12, 72), glowRingMat);
  outerRing.rotation.x = Math.PI / 2;
  outerRing.position.y = 0.02;
  hubShellGroup.add(outerRing);

  const ribMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.4,
    metalness: 0.75,
  });
  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2;
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.11, 1.1, 10), ribMat);
    post.position.set(Math.cos(angle) * 8.0, 0.55, Math.sin(angle) * 8.0);
    hubShellGroup.add(post);

    const archCurve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(Math.cos(angle) * 8.0, 1.0, Math.sin(angle) * 8.0),
      new THREE.Vector3(Math.cos(angle) * 6.8, 5.6, Math.sin(angle) * 6.8),
      new THREE.Vector3(Math.cos(angle) * 1.4, 7.0, Math.sin(angle) * 1.4)
    );
    const archGeo = new THREE.TubeGeometry(archCurve, 14, 0.06, 8, false);
    hubShellGroup.add(new THREE.Mesh(archGeo, ribMat));
  }

  const oculusRing = new THREE.Mesh(new THREE.TorusGeometry(1.4, 0.07, 12, 36), trimMat);
  oculusRing.rotation.x = Math.PI / 2;
  oculusRing.position.y = 7.0;
  hubShellGroup.add(oculusRing);

  const starCount = isSoftwareGl ? 350 : 900;
  const starPositions = new Float32Array(starCount * 3);
  for (let i = 0; i < starCount; i++) {
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(Math.random() * 0.85 + 0.1);
    const r = 28 + Math.random() * 14;
    starPositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    starPositions[i * 3 + 1] = r * Math.cos(phi);
    starPositions[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
  }
  const starGeo = new THREE.BufferGeometry();
  starGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
  const stars = new THREE.Points(
    starGeo,
    new THREE.PointsMaterial({ color: 0xe2e8f0, size: 0.16, transparent: true, opacity: 0.85 })
  );
  hubShellGroup.add(stars);

  const portalSpecs: Array<{
    id: string;
    title: string;
    subtitle: string;
    accent: string;
    x: number;
    z: number;
    rotY: number;
  }> = [
    {
      id: 'portal:360',
      title: 'مشغل فيديو \u2066360° / 3D\u2069',
      subtitle: '\u2066180° · 360°\u2069 · فيديو ثلاثي الأبعاد',
      accent: '#2DD4BF',
      x: -2.45,
      z: -4.2,
      rotY: 0.36,
    },
    {
      id: 'portal:cinema',
      title: 'السينما الافتراضية',
      subtitle: 'إضاءة سينمائية وتكبير الشاشة',
      accent: '#F59E0B',
      x: 0,
      z: -4.7,
      rotY: 0,
    },
    {
      id: 'portal:browser',
      title: 'متصفح جوجل \u2066VR\u2069',
      subtitle: 'بحث وحفظ المواقع بالنظارة',
      accent: '#38BDF8',
      x: 2.45,
      z: -4.2,
      rotY: -0.36,
    },
  ];

  const hubGlobe = new THREE.Group();
  const hubCinemaIcon = new THREE.Group();
  const hubBrowserIcon = new THREE.Group();

  // Sculpted Lathe Pedestal Profile (reused across all 3 portals)
  const pedestalLatheGeo = new THREE.LatheGeometry(
    [
      new THREE.Vector2(0, 0),
      new THREE.Vector2(0.86, 0),
      new THREE.Vector2(0.82, 0.14),
      new THREE.Vector2(0.68, 0.2),
      new THREE.Vector2(0.54, 0.24),
      new THREE.Vector2(0.46, 0.98),
      new THREE.Vector2(0.64, 1.08),
      new THREE.Vector2(0, 1.08),
    ],
    24
  );
  const pedestalShadowMat = new THREE.MeshBasicMaterial({
    color: 0x000000,
    transparent: true,
    opacity: 0.38,
    depthWrite: false,
  });

  portalSpecs.forEach((spec, idx) => {
    const pedestalGroup = new THREE.Group();
    pedestalGroup.position.set(spec.x, 0, spec.z);
    pedestalGroup.rotation.y = spec.rotY;

    const shadowDisc = new THREE.Mesh(new THREE.CircleGeometry(1.05, 24), pedestalShadowMat);
    shadowDisc.rotation.x = -Math.PI / 2;
    shadowDisc.position.y = 0.015;
    pedestalGroup.add(shadowDisc);

    const sculptedBase = new THREE.Mesh(pedestalLatheGeo, floorMat);
    pedestalGroup.add(sculptedBase);

    const collarRing = new THREE.Mesh(
      new THREE.TorusGeometry(0.63, 0.025, 10, 32),
      new THREE.MeshBasicMaterial({ color: spec.accent })
    );
    collarRing.rotation.x = Math.PI / 2;
    collarRing.position.y = 1.08;
    pedestalGroup.add(collarRing);

    [-0.42, 0.42].forEach((fx) => {
      const fin = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.78, 0.28), trimMat);
      fin.position.set(fx, 0.62, 0);
      pedestalGroup.add(fin);
    });

    const btn = createGazeButton(
      spec.id,
      spec.title,
      spec.subtitle,
      1.95,
      1.08,
      spec.accent,
      '#0f172a'
    );
    btn.group.position.set(0, 1.82, 0);
    pedestalGroup.add(btn.group);
    registerButton('hub', btn);

    if (idx === 0) {
      const core = new THREE.Mesh(
        new THREE.SphereGeometry(0.26, 20, 16),
        new THREE.MeshStandardMaterial({ color: 0x0d9488, roughness: 0.35, metalness: 0.25 })
      );
      const eqRing = new THREE.Mesh(
        new THREE.TorusGeometry(0.38, 0.022, 10, 32),
        new THREE.MeshBasicMaterial({ color: 0x2dd4bf })
      );
      eqRing.rotation.x = Math.PI * 0.35;
      const merRing = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.018, 8, 32), trimMat);
      merRing.rotation.y = Math.PI * 0.25;
      const sat = new THREE.Mesh(
        new THREE.SphereGeometry(0.055, 10, 8),
        new THREE.MeshBasicMaterial({ color: 0xfef08a })
      );
      sat.position.set(0.45, 0.1, 0);
      hubGlobe.add(core, eqRing, merRing, sat);
      hubGlobe.position.set(0, 2.86, 0);
      pedestalGroup.add(hubGlobe);
    } else if (idx === 1) {
      const body = new THREE.Mesh(
        new THREE.BoxGeometry(0.56, 0.32, 0.32),
        new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.32, metalness: 0.72 })
      );
      const lens = new THREE.Mesh(
        new THREE.CylinderGeometry(0.11, 0.08, 0.22, 14),
        new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.18, metalness: 0.88 })
      );
      lens.rotation.x = Math.PI / 2;
      lens.position.set(0, 0, 0.24);
      const reelL = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.05, 16), trimMat);
      reelL.rotation.z = Math.PI / 2;
      reelL.position.set(-0.14, 0.26, -0.06);
      const reelR = reelL.clone();
      reelR.position.set(0.14, 0.26, 0.08);
      const beamCone = new THREE.Mesh(
        new THREE.ConeGeometry(0.34, 0.65, 16, 1, true),
        new THREE.MeshBasicMaterial({
          color: 0xfbbf24,
          transparent: true,
          opacity: 0.2,
          side: THREE.DoubleSide,
          depthWrite: false,
        })
      );
      beamCone.rotation.x = -Math.PI / 2;
      beamCone.position.set(0, 0, 0.62);
      hubCinemaIcon.add(body, lens, reelL, reelR, beamCone);
      hubCinemaIcon.position.set(0, 2.88, 0);
      pedestalGroup.add(hubCinemaIcon);
    } else {
      const prism = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.26, 0),
        new THREE.MeshStandardMaterial({
          color: 0x38bdf8,
          roughness: 0.12,
          metalness: 0.88,
        })
      );
      const halo = new THREE.Mesh(
        new THREE.TorusGeometry(0.38, 0.022, 10, 32),
        new THREE.MeshBasicMaterial({ color: 0x38bdf8 })
      );
      halo.rotation.x = Math.PI * 0.5;
      const haloTilt = new THREE.Mesh(new THREE.TorusGeometry(0.43, 0.015, 8, 32), trimMat);
      haloTilt.rotation.y = Math.PI * 0.35;
      haloTilt.rotation.x = Math.PI * 0.22;
      hubBrowserIcon.add(prism, halo, haloTilt);
      hubBrowserIcon.position.set(0, 2.86, 0);
      pedestalGroup.add(hubBrowserIcon);
    }

    hubGroup.add(pedestalGroup);
  });

  const hubUtilSpecs = [
    { id: 'hub:toggle-stereo', title: 'وضع \u2066VR Box\u2069', x: -2.04, col: '#F59E0B' },
    { id: 'hub:open-gallery', title: 'icon:folder-plus|المعرض', x: -0.68, col: '#2DD4BF' },
    { id: 'hub:dwell-speed', title: 'السرعة: عادي', x: 0.68, col: '#38BDF8' },
    { id: 'hub:recenter', title: 'icon:recenter', x: 2.04, col: '#38BDF8' },
  ];
  hubUtilSpecs.forEach((u) => {
    const btn = createGazeButton(u.id, u.title, undefined, 1.24, 0.38, u.col, '#151f32');
    btn.group.position.set(u.x, 0.96, -3.5);
    btn.group.rotation.x = -0.18;
    hubGroup.add(btn.group);
    registerButton('hub', btn);
  });

  // Hub Environment Switcher Row (Observatory, Living Room, Beach, Moon, Bedroom)
  const hubEnvX = [-1.84, -0.92, 0, 0.92, 1.84];
  ENVIRONMENT_OPTIONS.forEach((opt, idx) => {
    const btn = createGazeButton(
      `hub:env:${opt.id}`,
      opt.shortLabel,
      undefined,
      0.86,
      0.27,
      opt.accent,
      '#0f172a',
      opt.id === 'observatory'
    );
    btn.group.position.set(hubEnvX[idx], 0.54, -3.32);
    btn.group.rotation.x = -0.24;
    hubGroup.add(btn.group);
    registerButton('hub', btn);
  });

  // =========================================================================
  // 2. 360 / 180 / 3D VR PLAYER ENVIRONMENT (Equirectangular & Stereo Shader)
  // =========================================================================
  const player360Group = new THREE.Group();
  player360Group.visible = false;
  scene.add(player360Group);

  const placeholderTex = new THREE.DataTexture(new Uint8Array([10, 15, 25, 255]), 1, 1);
  placeholderTex.needsUpdate = true;

  const sphere360Mat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    uniforms: {
      uMap: { value: placeholderTex },
      uEye: { value: 0 },
      uIs180: { value: 0 },
      uStereoLayout: { value: 0 }, // 0=mono, 1=SBS, 2=TB
    },
    vertexShader: `
      varying vec3 vLocalDir;
      void main() {
        vLocalDir = normalize(position);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform sampler2D uMap;
      uniform float uEye;
      uniform float uIs180;
      uniform float uStereoLayout;
      varying vec3 vLocalDir;

      const float PI = 3.14159265359;

      void main() {
        vec3 dir = normalize(vLocalDir);

        // In 180-degree VR mode, render sleek dark theater void behind the viewer (dir.z > 0)
        if (uIs180 > 0.5 && dir.z > 0.0) {
          gl_FragColor = vec4(0.025, 0.035, 0.055, 1.0);
          return;
        }

        float azimuth = atan(dir.x, -dir.z); // -PI..PI, 0 is straight ahead (-Z)
        float elevation = asin(clamp(dir.y, -1.0, 1.0)); // -PI/2..PI/2

        float u = uIs180 > 0.5
          ? (0.5 + azimuth / PI)
          : (0.5 + azimuth / (2.0 * PI));
        float v = 0.5 + elevation / PI;

        if (uStereoLayout > 0.5 && uStereoLayout < 1.5) {
          // Side-by-Side (SBS)
          u = u * 0.5 + uEye * 0.5;
        } else if (uStereoLayout > 1.5) {
          // Top-Bottom (TB): Left eye top half [0.5..1.0], Right eye bottom half [0.0..0.5]
          v = v * 0.5 + (1.0 - uEye) * 0.5;
        }

        vec4 texel = texture2D(uMap, vec2(clamp(u, 0.001, 0.999), clamp(v, 0.001, 0.999)));
        gl_FragColor = texel;
      }
    `,
  });

  const sphereGeo = new THREE.SphereGeometry(68, 48, 32);
  const sphere360Mesh = new THREE.Mesh(sphereGeo, sphere360Mat);
  player360Group.add(sphere360Mesh);

  const player360MenuGroup = new THREE.Group();
  player360Group.add(player360MenuGroup);

  const player360ShowGroup = new THREE.Group();
  player360ShowGroup.visible = false;
  player360Group.add(player360ShowGroup);

  const player360Banner = createInfoBanner(4.1, 0.5);
  player360Banner.mesh.position.set(0, 1.94, -3.6);
  player360Banner.mesh.rotation.x = -0.08;
  player360MenuGroup.add(player360Banner.mesh);

  // Row 1: Symbol-based Playback Controls + Hide Menu toggle
  const player360Controls = [
    { id: '360:play-pause', title: 'icon:pause', x: -1.75, col: '#2DD4BF' },
    { id: '360:seek-back', title: 'icon:seek-back', x: -1.05, col: '#2DD4BF' },
    { id: '360:seek-fwd', title: 'icon:seek-fwd', x: -0.35, col: '#2DD4BF' },
    { id: '360:next-scene', title: 'icon:next', x: 0.35, col: '#2DD4BF' },
    { id: '360:hide-menu', title: 'icon:eye-off', x: 1.05, col: '#38BDF8' },
    { id: 'common:go-hub', title: 'icon:home', x: 1.75, col: '#F59E0B' },
  ];
  player360Controls.forEach((c) => {
    const btn = createGazeButton(
      c.id,
      c.title,
      undefined,
      0.62,
      0.34,
      c.col,
      '#0b111e'
    );
    btn.group.position.set(c.x, 1.44, -3.5);
    btn.group.rotation.x = -0.13;
    player360MenuGroup.add(btn.group);
    registerButton('player360', btn);
  });

  // Row 2: All 3D & 180 / 360 Video Projection Options (Concise Symbol Badges)
  const projXPositions = [-1.68, -0.84, 0, 0.84, 1.68];
  PROJECTION_OPTIONS.forEach((opt, idx) => {
    const btn = createGazeButton(
      `360:proj:${opt.id}`,
      opt.shortLabel,
      undefined,
      0.78,
      0.31,
      '#38BDF8',
      '#0f172a',
      opt.id === '360-mono'
    );
    btn.group.position.set(projXPositions[idx], 1.05, -3.42);
    btn.group.rotation.x = -0.17;
    player360MenuGroup.add(btn.group);
    registerButton('player360', btn);
  });

  // Row 3: Gaze Volume Slider Bar
  const player360VolumeSlider = createGazeVolumeSlider(
    '360',
    'player360',
    '#2DD4BF',
    registerButton
  );
  player360VolumeSlider.group.position.set(0, 0.68, -3.34);
  player360VolumeSlider.group.rotation.x = -0.22;
  player360MenuGroup.add(player360VolumeSlider.group);

  // Floating "Show Menu" button visible only when 360 menu is hidden
  const player360ShowMenuBtn = createGazeButton(
    '360:show-menu',
    'icon:eye',
    undefined,
    0.72,
    0.4,
    '#2DD4BF',
    '#0b111e'
  );
  player360ShowMenuBtn.group.position.set(0, 0.7, -3.25);
  player360ShowMenuBtn.group.rotation.x = -0.22;
  player360ShowGroup.add(player360ShowMenuBtn.group);
  buttons.set(player360ShowMenuBtn.id, player360ShowMenuBtn);

  // =========================================================================
  // 3. VR CINEMA HALL ENVIRONMENT
  // =========================================================================
  const cinemaGroup = new THREE.Group();
  cinemaGroup.visible = false;
  scene.add(cinemaGroup);

  const cinemaAmbientLight = new THREE.HemisphereLight(0x93c5fd, 0x1e293b, 0.45);
  cinemaGroup.add(cinemaAmbientLight);

  const cinemaBounceLight = new THREE.PointLight(0x38bdf8, 5.5, 24, 1.4);
  cinemaBounceLight.position.set(0, 3.6, -7.0);
  cinemaGroup.add(cinemaBounceLight);

  const cinemaWallLight = new THREE.PointLight(0xf59e0b, 1.4, 20, 1.6);
  cinemaWallLight.position.set(0, 5.4, 1.5);
  cinemaGroup.add(cinemaWallLight);

  const cinemaShellGroup = new THREE.Group();
  cinemaGroup.add(cinemaShellGroup);

  const hallWallMat = new THREE.MeshStandardMaterial({
    color: 0x0d121d,
    roughness: 0.85,
    metalness: 0.1,
  });
  const hallCarpetMat = new THREE.MeshStandardMaterial({
    color: 0x1e1b2e,
    roughness: 0.92,
    metalness: 0.05,
  });
  const seatFabricMat = new THREE.MeshStandardMaterial({
    color: 0x7f1d1d,
    roughness: 0.8,
    metalness: 0.08,
  });
  const seatFrameMat = new THREE.MeshStandardMaterial({
    color: 0x1f2937,
    roughness: 0.35,
    metalness: 0.8,
  });
  const aisleStripMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
  const cinemaSconceMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });

  const hallFloor = new THREE.Mesh(new THREE.BoxGeometry(16, 0.2, 20), hallCarpetMat);
  hallFloor.position.set(0, -0.1, -3);
  cinemaShellGroup.add(hallFloor);

  const hallStage = new THREE.Mesh(
    new THREE.CylinderGeometry(7.2, 7.6, 0.26, 36, 1, false, Math.PI * 0.72, Math.PI * 0.56),
    seatFrameMat
  );
  hallStage.position.set(0, 0.12, -1.6);
  cinemaShellGroup.add(hallStage);

  const hallCeiling = new THREE.Mesh(new THREE.BoxGeometry(16, 0.2, 20), hallWallMat);
  hallCeiling.position.set(0, 7.6, -3);
  cinemaShellGroup.add(hallCeiling);

  const leftWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, 7.8, 20), hallWallMat);
  leftWall.position.set(-8, 3.8, -3);
  cinemaShellGroup.add(leftWall);

  const rightWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, 7.8, 20), hallWallMat);
  rightWall.position.set(8, 3.8, -3);
  cinemaShellGroup.add(rightWall);

  const frontWall = new THREE.Mesh(new THREE.BoxGeometry(16.2, 7.8, 0.3), hallWallMat);
  frontWall.position.set(0, 3.8, -12.8);
  cinemaShellGroup.add(frontWall);

  const backWall = new THREE.Mesh(new THREE.BoxGeometry(16.2, 7.8, 0.3), hallWallMat);
  backWall.position.set(0, 3.8, 6.8);
  cinemaShellGroup.add(backWall);

  for (let i = 0; i < 6; i++) {
    const zPos = -10 + i * 3;
    const ribL = new THREE.Mesh(new THREE.BoxGeometry(0.24, 7.2, 0.45), seatFrameMat);
    ribL.position.set(-7.78, 3.6, zPos);
    const ribR = ribL.clone();
    ribR.position.x = 7.78;
    cinemaShellGroup.add(ribL, ribR);

    // Dynamic wall sconces for Cinematic Ambilight mode
    const sconceL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.35, 0.16), cinemaSconceMat);
    sconceL.position.set(-7.62, 3.5, zPos);
    const sconceR = sconceL.clone();
    sconceR.position.x = 7.62;
    cinemaShellGroup.add(sconceL, sconceR);

    // Ceiling cove light ribs
    const coveL = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.06, 0.12), cinemaSconceMat);
    coveL.position.set(-5.8, 7.45, zPos);
    const coveR = coveL.clone();
    coveR.position.x = 5.8;
    cinemaShellGroup.add(coveL, coveR);
  }

  const seatCushionGeo = new THREE.BoxGeometry(0.64, 0.15, 0.58);
  const seatBackGeo = new THREE.BoxGeometry(0.62, 0.8, 0.14);
  const seatHeadrestGeo = new THREE.CylinderGeometry(0.11, 0.11, 0.56, 12);
  const armrestGeo = new THREE.BoxGeometry(0.1, 0.11, 0.54);

  const rows = [
    { z: -5.4, y: 0.0 },
    { z: -2.0, y: 0.0 },
    { z: 1.6, y: 0.32 },
  ];
  rows.forEach((row) => {
    if (row.y > 0) {
      const riser = new THREE.Mesh(new THREE.BoxGeometry(14, row.y, 2.8), hallCarpetMat);
      riser.position.set(0, row.y / 2, row.z);
      cinemaShellGroup.add(riser);
    }

    const stripL = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.03, 1.8), aisleStripMat);
    stripL.position.set(-1.35, row.y + 0.02, row.z);
    const stripR = stripL.clone();
    stripR.position.x = 1.35;
    cinemaShellGroup.add(stripL, stripR);

    const xCols = [-4.2, -3.1, -2.0, 2.0, 3.1, 4.2];
    xCols.forEach((sx) => {
      if (Math.abs(row.z) < 2.2 && Math.abs(sx) < 2.2) return;
      const chair = new THREE.Group();
      const cushion = new THREE.Mesh(seatCushionGeo, seatFabricMat);
      cushion.position.y = 0.42;
      const backrest = new THREE.Mesh(seatBackGeo, seatFabricMat);
      backrest.position.set(0, 0.84, 0.24);
      backrest.rotation.x = 0.14;
      const headrest = new THREE.Mesh(seatHeadrestGeo, seatFabricMat);
      headrest.rotation.z = Math.PI / 2;
      headrest.position.set(0, 1.24, 0.28);
      const armL = new THREE.Mesh(armrestGeo, seatFrameMat);
      armL.position.set(-0.34, 0.56, 0);
      const armR = new THREE.Mesh(armrestGeo, seatFrameMat);
      armR.position.set(0.34, 0.56, 0);
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.22, 0.36, 12), seatFrameMat);
      leg.position.y = 0.18;

      chair.add(cushion, backrest, headrest, armL, armR, leg);
      chair.position.set(sx, row.y, row.z);
      cinemaShellGroup.add(chair);
    });
  });

  const cinemaFrameGroup = new THREE.Group();
  cinemaFrameGroup.position.set(0, 3.85, -1.4);
  cinemaGroup.add(cinemaFrameGroup);

  const arcRadius = 9.8;
  const arcAngle = Math.PI * 0.46;
  const screenGeo = new THREE.CylinderGeometry(
    arcRadius,
    arcRadius,
    5.0,
    40,
    1,
    true,
    Math.PI - arcAngle / 2,
    arcAngle
  );
  screenGeo.scale(-1, 1, 1);
  const cinemaScreenMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const cinemaScreenMesh = new THREE.Mesh(screenGeo, cinemaScreenMat);
  cinemaFrameGroup.add(cinemaScreenMesh);

  const bezelTop = new THREE.Mesh(
    new THREE.CylinderGeometry(
      arcRadius + 0.05,
      arcRadius + 0.05,
      0.22,
      40,
      1,
      true,
      Math.PI - arcAngle / 2,
      arcAngle
    ),
    seatFrameMat
  );
  bezelTop.scale.set(-1, 1, 1);
  bezelTop.position.y = 2.58;
  const bezelBot = bezelTop.clone();
  bezelBot.position.y = -2.58;
  cinemaFrameGroup.add(bezelTop, bezelBot);

  const cinemaBanner = createInfoBanner(3.8, 0.56);
  cinemaBanner.mesh.position.set(0, 1.62, -4.42);
  cinemaBanner.mesh.rotation.x = -0.08;
  cinemaGroup.add(cinemaBanner.mesh);

  const cinemaControlSpecs = [
    { id: 'cinema:play-pause', title: 'icon:pause', x: -2.52, w: 0.68 },
    { id: 'cinema:seek-back', title: 'icon:seek-back', x: -1.78, w: 0.68 },
    { id: 'cinema:seek-fwd', title: 'icon:seek-fwd', x: -1.04, w: 0.68 },
    { id: 'cinema:lights', title: 'icon:sun|سينمائية', x: -0.16, w: 0.94 },
    { id: 'cinema:screen-size', title: 'icon:expand|IMAX', x: 0.86, w: 0.94 },
    { id: 'cinema:next-movie', title: 'icon:next', x: 1.74, w: 0.68 },
    { id: 'common:go-hub', title: 'icon:home', x: 2.48, w: 0.68 },
  ];
  cinemaControlSpecs.forEach((c) => {
    const btn = createGazeButton(
      c.id,
      c.title,
      undefined,
      c.w,
      0.35,
      c.id === 'common:go-hub' ? '#38BDF8' : '#F59E0B',
      '#0b111e'
    );
    btn.group.position.set(c.x, 1.12, -4.28);
    btn.group.rotation.x = -0.15;
    cinemaGroup.add(btn.group);
    registerButton('cinema', btn);
  });

  const cinemaVolumeSlider = createGazeVolumeSlider(
    'cinema',
    'cinema',
    '#F59E0B',
    registerButton
  );
  cinemaVolumeSlider.group.position.set(0, 0.7, -4.14);
  cinemaVolumeSlider.group.rotation.x = -0.2;
  cinemaVolumeSlider.group.scale.setScalar(1.06);
  cinemaGroup.add(cinemaVolumeSlider.group);

  // Cinema Environment Switcher Row (Hall, Living Room, Beach, Moon, Bedroom)
  const cinemaEnvX = [-1.88, -0.94, 0, 0.94, 1.88];
  ENVIRONMENT_OPTIONS.forEach((opt, idx) => {
    const label = opt.id === 'observatory' ? 'القاعة' : opt.shortLabel;
    const btn = createGazeButton(
      `cinema:env:${opt.id}`,
      label,
      undefined,
      0.88,
      0.27,
      opt.accent,
      '#0b111e',
      opt.id === 'observatory'
    );
    btn.group.position.set(cinemaEnvX[idx], 0.3, -3.94);
    btn.group.rotation.x = -0.26;
    cinemaGroup.add(btn.group);
    registerButton('cinema', btn);
  });

  // =========================================================================
  // 4. GOOGLE VR BROWSER STUDIO (With Saved Bookmarks)
  // =========================================================================
  const browserGroup = new THREE.Group();
  browserGroup.visible = false;
  scene.add(browserGroup);

  browserGroup.add(new THREE.HemisphereLight(0x93c5fd, 0x0f172a, 0.85));
  const browserFloor = new THREE.Mesh(new THREE.CylinderGeometry(7, 7.4, 0.2, 42), floorMat);
  browserFloor.position.y = -0.12;
  browserGroup.add(browserFloor);

  const browserFloorRing = new THREE.Mesh(
    new THREE.TorusGeometry(6.8, 0.03, 10, 64),
    new THREE.MeshBasicMaterial({ color: 0x38bdf8 })
  );
  browserFloorRing.rotation.x = Math.PI / 2;
  browserFloorRing.position.y = 0.01;
  browserGroup.add(browserFloorRing);

  const bRadius = 4.9;
  const bArc = Math.PI * 0.31;
  const browserGeo = new THREE.CylinderGeometry(
    bRadius,
    bRadius,
    2.35,
    36,
    1,
    true,
    Math.PI - bArc / 2,
    bArc
  );
  browserGeo.scale(-1, 1, 1);
  const browserScreenMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const browserScreenMesh = new THREE.Mesh(browserGeo, browserScreenMat);
  browserScreenMesh.position.set(0, 2.86, -0.35);
  browserGroup.add(browserScreenMesh);

  // Curved top/bottom console frame & twin support stanchions for Browser screen
  const bFrameTop = new THREE.Mesh(
    new THREE.CylinderGeometry(
      bRadius + 0.04,
      bRadius + 0.04,
      0.09,
      36,
      1,
      true,
      Math.PI - bArc / 2,
      bArc
    ),
    trimMat
  );
  bFrameTop.scale.set(-1, 1, 1);
  bFrameTop.position.set(0, 4.07, -0.35);
  const bFrameBot = bFrameTop.clone();
  bFrameBot.position.set(0, 1.65, -0.35);
  const bDeskBar = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.14, 0.72), trimMat);
  bDeskBar.position.set(0, 0.34, -3.45);
  bDeskBar.rotation.x = -0.2;
  const bPillarL = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.09, 1.65, 12), trimMat);
  bPillarL.position.set(-2.35, 0.82, -4.65);
  const bPillarR = bPillarL.clone();
  bPillarR.position.x = 2.35;
  browserGroup.add(bFrameTop, bFrameBot, bDeskBar, bPillarL, bPillarR);

  const leftActions = [
    { id: 'browser:open-1', title: '#1', y: 3.05, col: '#38BDF8' },
    { id: 'browser:open-2', title: '#2', y: 2.62, col: '#38BDF8' },
    { id: 'browser:open-3', title: '#3', y: 2.19, col: '#38BDF8' },
    { id: 'browser:open-4', title: '#4', y: 1.76, col: '#38BDF8' },
    { id: 'browser:bookmarks', title: 'icon:bookmarks', y: 1.33, col: '#F59E0B' },
  ];
  leftActions.forEach((a) => {
    const btn = createGazeButton(a.id, a.title, undefined, 0.72, 0.34, a.col, '#111827');
    btn.group.position.set(-2.98, a.y, -3.28);
    btn.group.rotation.y = 0.56;
    browserGroup.add(btn.group);
    registerButton('browser', btn);
  });

  const rightActions = [
    { id: 'browser:scroll-up', title: 'icon:up', y: 3.05, col: '#38BDF8' },
    { id: 'browser:scroll-down', title: 'icon:down', y: 2.62, col: '#38BDF8' },
    { id: 'browser:save', title: 'icon:star-outline', y: 2.19, col: '#F59E0B' },
    { id: 'browser:back', title: 'icon:back', y: 1.76, col: '#38BDF8' },
    { id: 'browser:home', title: 'icon:globe', y: 1.33, col: '#38BDF8' },
    { id: 'common:go-hub', title: 'icon:home', y: 0.9, col: '#EF4444' },
  ];
  rightActions.forEach((a) => {
    const btn = createGazeButton(a.id, a.title, undefined, 0.72, 0.33, a.col, '#111827');
    btn.group.position.set(2.98, a.y, -3.28);
    btn.group.rotation.y = -0.56;
    browserGroup.add(btn.group);
    registerButton('browser', btn);
  });

  const keyboardContainer = new THREE.Group();
  keyboardContainer.position.set(0, 0.92, -3.35);
  keyboardContainer.rotation.x = -0.34;
  browserGroup.add(keyboardContainer);

  const rebuildKeyboard = (lang: KeyboardLang) => {
    while (keyboardContainer.children.length > 0) {
      keyboardContainer.remove(keyboardContainer.children[0]);
    }
    interactablesByMode.browser = interactablesByMode.browser.filter(
      (m) =>
        !String(m.userData.gazeId).startsWith('browser:key:') &&
        m.userData.gazeId !== 'browser:search' &&
        m.userData.gazeId !== 'browser:lang'
    );
    for (const [k, meta] of buttons.entries()) {
      if (k.startsWith('browser:key:') || k === 'browser:search' || k === 'browser:lang') {
        meta.labelTex?.dispose();
        meta.hitMesh.geometry.dispose();
        meta.faceMat.dispose();
        meta.borderMat.dispose();
        buttons.delete(k);
      }
    }

    const rowsData = lang === 'ar' ? ARABIC_KEY_ROWS : ENGLISH_KEY_ROWS;
    rowsData.forEach((rowChars, rIdx) => {
      const y = (1 - rIdx) * 0.25 + 0.14;
      const stepX = 0.34;
      const startX = -((rowChars.length - 1) * stepX) / 2;
      rowChars.forEach((ch, cIdx) => {
        const btn = createGazeButton(
          `browser:key:${ch}`,
          ch,
          undefined,
          0.3,
          0.21,
          '#38BDF8',
          '#162033'
        );
        btn.group.position.set(startX + cIdx * stepX, y, 0);
        keyboardContainer.add(btn.group);
        registerButton('browser', btn);
      });
    });

    const bottomKeys = [
      {
        id: 'browser:lang',
        title: lang === 'ar' ? 'EN / ع' : 'AR / EN',
        x: -1.42,
        w: 0.72,
        col: '#818CF8',
      },
      { id: 'browser:key:CLEAR', title: 'icon:clear', x: -0.76, w: 0.48, col: '#EF4444' },
      { id: 'browser:key:SPACE', title: 'icon:space', x: 0.0, w: 0.92, col: '#38BDF8' },
      { id: 'browser:key:BACKSPACE', title: 'icon:backspace', x: 0.76, w: 0.52, col: '#F59E0B' },
      { id: 'browser:search', title: 'icon:search', x: 1.44, w: 0.76, col: '#10B981' },
    ];
    bottomKeys.forEach((bk) => {
      const btn = createGazeButton(bk.id, bk.title, undefined, bk.w, 0.23, bk.col, '#111827');
      btn.group.position.set(bk.x, -0.36, 0);
      keyboardContainer.add(btn.group);
      registerButton('browser', btn);
    });
  };
  rebuildKeyboard('ar');

  // =========================================================================
  // 4B. 3D VR FILES & GALLERY BROWSER STUDIO
  // =========================================================================
  const galleryGroup = new THREE.Group();
  galleryGroup.visible = false;
  scene.add(galleryGroup);

  galleryGroup.add(new THREE.HemisphereLight(0x5eead4, 0x0f172a, 0.85));
  const galleryFloor = new THREE.Mesh(new THREE.CylinderGeometry(7, 7.4, 0.2, 42), floorMat);
  galleryFloor.position.y = -0.12;
  galleryGroup.add(galleryFloor);

  const galleryFloorRing = new THREE.Mesh(
    new THREE.TorusGeometry(6.8, 0.03, 10, 64),
    new THREE.MeshBasicMaterial({ color: 0x2dd4bf })
  );
  galleryFloorRing.rotation.x = Math.PI / 2;
  galleryFloorRing.position.y = 0.01;
  galleryGroup.add(galleryFloorRing);

  const gRadius = 4.9;
  const gArc = Math.PI * 0.33;
  const galleryGeo = new THREE.CylinderGeometry(
    gRadius,
    gRadius,
    2.35,
    36,
    1,
    true,
    Math.PI - gArc / 2,
    gArc
  );
  galleryGeo.scale(-1, 1, 1);
  const galleryScreenMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const galleryScreenMesh = new THREE.Mesh(galleryGeo, galleryScreenMat);
  galleryScreenMesh.position.set(0, 2.75, -0.35);
  galleryGroup.add(galleryScreenMesh);

  const gFrameTop = new THREE.Mesh(
    new THREE.CylinderGeometry(
      gRadius + 0.04,
      gRadius + 0.04,
      0.09,
      36,
      1,
      true,
      Math.PI - gArc / 2,
      gArc
    ),
    trimMat
  );
  gFrameTop.scale.set(-1, 1, 1);
  gFrameTop.position.set(0, 3.965, -0.35);
  const gFrameBot = gFrameTop.clone();
  gFrameBot.position.set(0, 1.535, -0.35);
  const gPillarL = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.09, 1.54, 12), trimMat);
  gPillarL.position.set(-2.45, 0.77, -4.62);
  const gPillarR = gPillarL.clone();
  gPillarR.position.x = 2.45;
  galleryGroup.add(gFrameTop, gFrameBot, gPillarL, gPillarR);

  const galleryLeftActions = [
    { id: 'gallery:open-1', title: '#1 ▶', y: 2.95, col: '#2DD4BF' },
    { id: 'gallery:open-2', title: '#2 ▶', y: 2.5, col: '#2DD4BF' },
    { id: 'gallery:open-3', title: '#3 ▶', y: 2.05, col: '#2DD4BF' },
    { id: 'gallery:open-4', title: '#4 ▶', y: 1.6, col: '#2DD4BF' },
    { id: 'gallery:filter', title: 'الكل', y: 1.15, col: '#38BDF8' },
  ];
  galleryLeftActions.forEach((a) => {
    const btn = createGazeButton(a.id, a.title, undefined, 0.78, 0.36, a.col, '#111827');
    btn.group.position.set(-3.12, a.y, -3.15);
    btn.group.rotation.y = 0.62;
    galleryGroup.add(btn.group);
    registerButton('gallery', btn);
  });

  const galleryRightActions = [
    { id: 'gallery:scroll-up', title: 'icon:up', y: 2.95, col: '#38BDF8' },
    { id: 'gallery:scroll-down', title: 'icon:down', y: 2.5, col: '#38BDF8' },
    { id: 'gallery:target', title: 'تلقائي', y: 2.05, col: '#F59E0B' },
    { id: 'gallery:import', title: 'icon:folder-plus', y: 1.6, col: '#10B981' },
    { id: 'common:go-hub', title: 'icon:home', y: 1.15, col: '#EF4444' },
  ];
  galleryRightActions.forEach((a) => {
    const btn = createGazeButton(a.id, a.title, undefined, 0.78, 0.36, a.col, '#111827');
    btn.group.position.set(3.12, a.y, -3.15);
    btn.group.rotation.y = -0.62;
    galleryGroup.add(btn.group);
    registerButton('gallery', btn);
  });

  // =========================================================================
  // 5. FLOOR QUICK-RETURN & RECENTER RING
  // =========================================================================
  const floorQuickGroup = new THREE.Group();
  scene.add(floorQuickGroup);

  const floorHubBtn = createGazeButton(
    'common:go-hub',
    'icon:home',
    undefined,
    0.76,
    0.42,
    '#38BDF8',
    '#0b111e'
  );
  floorHubBtn.group.position.set(-0.5, 0.18, -0.68);
  floorHubBtn.group.rotation.x = -Math.PI * 0.42;
  floorQuickGroup.add(floorHubBtn.group);
  registerButton('floor', floorHubBtn);

  const floorRecenterBtn = createGazeButton(
    'common:recenter',
    'icon:recenter',
    undefined,
    0.76,
    0.42,
    '#F59E0B',
    '#0b111e'
  );
  floorRecenterBtn.group.position.set(0.5, 0.18, -0.68);
  floorRecenterBtn.group.rotation.x = -Math.PI * 0.42;
  floorQuickGroup.add(floorRecenterBtn.group);
  registerButton('floor', floorRecenterBtn);

  const updateButtonLabel = (
    id: string,
    title: string,
    subtitle?: string,
    active?: boolean
  ) => {
    const meta = buttons.get(id);
    if (!meta || !meta.labelCtx || !meta.labelCanvas || !meta.labelTex) return;
    if (typeof active === 'boolean') {
      meta.active = active;
    }
    drawButtonCanvas(
      meta.labelCtx,
      meta.labelCanvas.width,
      meta.labelCanvas.height,
      title,
      subtitle,
      meta.accentHex,
      '#111827',
      Boolean(meta.active)
    );
    meta.labelTex.needsUpdate = true;
  };

  const set360Texture = (texture: THREE.Texture) => {
    sphere360Mat.uniforms.uMap.value = texture;
  };

  const set360Projection = (projection: Video360Projection) => {
    const spec = getProjectionSpec(projection);
    sphere360Mat.uniforms.uIs180.value = spec.is180 ? 1.0 : 0.0;
    sphere360Mat.uniforms.uStereoLayout.value =
      spec.stereoLayout === 'sbs' ? 1.0 : spec.stereoLayout === 'tb' ? 2.0 : 0.0;

    PROJECTION_OPTIONS.forEach((opt) => {
      updateButtonLabel(`360:proj:${opt.id}`, opt.shortLabel, undefined, opt.id === projection);
    });
  };

  const set360Eye = (eyeIndex: 0 | 1) => {
    sphere360Mat.uniforms.uEye.value = eyeIndex;
  };

  let menu360Visible = true;
  const set360MenuVisible = (visible: boolean) => {
    menu360Visible = visible;
    player360MenuGroup.visible = visible;
    player360ShowGroup.visible = !visible;
  };
  const is360MenuVisible = () => menu360Visible;

  const getActiveInteractables = (mode: VRMode): THREE.Mesh[] => {
    if (mode === 'hub') return interactablesByMode.hub;
    if (mode === 'player360') {
      const activeTargets = menu360Visible
        ? interactablesByMode.player360
        : [player360ShowMenuBtn.hitMesh];
      return activeTargets.concat(floorInteractables);
    }
    if (mode === 'browser') {
      return interactablesByMode.browser.concat(browserScreenMesh, floorInteractables);
    }
    if (mode === 'gallery') {
      return interactablesByMode.gallery.concat(galleryScreenMesh, floorInteractables);
    }
    return interactablesByMode[mode].concat(floorInteractables);
  };

  let currentEnvId: SceneEnvironmentId = 'observatory';
  let currentActiveMode: VRMode = 'hub';

  const setEnvironment = (envId: SceneEnvironmentId, activeMode: VRMode) => {
    currentEnvId = envId;
    currentActiveMode = activeMode;
    const usesThemedEnv = activeMode === 'hub' || activeMode === 'cinema';

    hubShellGroup.visible = envId === 'observatory';
    cinemaShellGroup.visible = envId === 'observatory';
    envController.setEnvironment(envId, usesThemedEnv);

    if (usesThemedEnv) {
      const { bgColor, fogColor, fogDensity } = envController.getBackgroundAndFog(envId);
      (scene.background as THREE.Color).setHex(bgColor);
      if (scene.fog instanceof THREE.FogExp2) {
        scene.fog.color.setHex(fogColor);
        scene.fog.density = fogDensity;
      }
    } else {
      (scene.background as THREE.Color).setHex(0x070b12);
      if (scene.fog instanceof THREE.FogExp2) {
        scene.fog.color.setHex(0x070b12);
        scene.fog.density = 0.025;
      }
    }

    ENVIRONMENT_OPTIONS.forEach((opt) => {
      updateButtonLabel(`hub:env:${opt.id}`, opt.shortLabel, undefined, opt.id === envId);
      updateButtonLabel(
        `cinema:env:${opt.id}`,
        opt.id === 'observatory' ? 'القاعة' : opt.shortLabel,
        undefined,
        opt.id === envId
      );
    });
  };

  const updateEnvironment = (deltaSec: number, nowMs: number) => {
    envController.update(deltaSec, nowMs);
  };

  const setActiveModeVisibility = (mode: VRMode) => {
    hubGroup.visible = mode === 'hub';
    player360Group.visible = mode === 'player360';
    cinemaGroup.visible = mode === 'cinema';
    browserGroup.visible = mode === 'browser';
    galleryGroup.visible = mode === 'gallery';
    floorQuickGroup.visible = mode !== 'hub';
    setEnvironment(currentEnvId, mode);
  };

  const setTheaterLighting = (lightMode: TheaterLightMode, screenColor?: THREE.Color) => {
    if (lightMode === 'cinematic') {
      cinemaAmbientLight.intensity = 0.42;
      cinemaWallLight.intensity = 1.1;
      cinemaBounceLight.intensity = 6.5;
      if (screenColor) {
        cinemaSconceMat.color.copy(screenColor).lerp(new THREE.Color(0xffffff), 0.15);
      } else {
        cinemaSconceMat.color.set(0x38bdf8);
      }
      aisleStripMat.color.set(0xf59e0b);
    } else if (lightMode === 'dark') {
      cinemaAmbientLight.intensity = 0.1;
      cinemaWallLight.intensity = 0.15;
      cinemaBounceLight.intensity = 4.2;
      cinemaSconceMat.color.set(0x0b101b);
      aisleStripMat.color.set(0x78350f);
    } else if (lightMode === 'ambient') {
      cinemaAmbientLight.intensity = 0.58;
      cinemaWallLight.intensity = 1.8;
      cinemaBounceLight.intensity = 4.0;
      cinemaSconceMat.color.set(0xf59e0b);
      aisleStripMat.color.set(0xf59e0b);
    } else {
      cinemaAmbientLight.intensity = 1.25;
      cinemaWallLight.intensity = 3.5;
      cinemaBounceLight.intensity = 3.2;
      cinemaSconceMat.color.set(0xfff1d6);
      aisleStripMat.color.set(0xfbbf24);
    }
  };

  const setCinemaScreenScale = (size: CinemaScreenSize) => {
    const spec =
      CINEMA_SCREEN_OPTIONS.find((o) => o.id === size) ?? CINEMA_SCREEN_OPTIONS[1];
    cinemaFrameGroup.scale.set(spec.scale, spec.scale, spec.scale);
    cinemaFrameGroup.position.z = -1.6 + spec.zOffset;
  };

  const updateDynamicHudTextures = (
    player360Info: { title: string; timeText: string; isPlaying: boolean },
    cinemaInfo: { title: string; timeText: string; isPlaying: boolean }
  ) => {
    if (player360Group.visible && menu360Visible) {
      player360Banner.update(player360Info.title, player360Info.timeText);
    }
    if (cinemaGroup.visible) {
      cinemaBanner.update(cinemaInfo.title, cinemaInfo.timeText);
    }
  };

  const updateVolumeSliders = (volume: number, muted: boolean) => {
    player360VolumeSlider.update(volume, muted);
    cinemaVolumeSlider.update(volume, muted);
  };

  const dispose = () => {
    placeholderTex.dispose();
    player360Banner.dispose();
    cinemaBanner.dispose();
    player360VolumeSlider.dispose();
    cinemaVolumeSlider.dispose();
    envController.dispose();
    buttons.forEach((b) => {
      b.labelTex?.dispose();
      b.hitMesh.geometry.dispose();
      b.faceMat.dispose();
      b.borderMat.dispose();
    });
    scene.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh;
        mesh.geometry?.dispose();
        if (Array.isArray(mesh.material)) {
          mesh.material.forEach((m) => m.dispose());
        } else {
          mesh.material?.dispose();
        }
      }
    });
    envTex.dispose();
  };

  // Initialize environment state cleanly
  setEnvironment(currentEnvId, currentActiveMode);

  return {
    scene,
    hubGroup,
    player360Group,
    player360MenuGroup,
    player360ShowGroup,
    cinemaGroup,
    browserGroup,
    galleryGroup,
    floorQuickGroup,
    sphere360Mesh,
    sphere360Mat,
    set360Texture,
    set360Projection,
    set360Eye,
    set360MenuVisible,
    is360MenuVisible,
    cinemaScreenMesh,
    cinemaScreenMat,
    cinemaFrameGroup,
    cinemaBounceLight,
    cinemaAmbientLight,
    cinemaWallLight,
    browserScreenMesh,
    browserScreenMat,
    galleryScreenMesh,
    galleryScreenMat,
    keyboardContainer,
    animatedProps: {
      hubGlobe,
      hubCinemaIcon,
      hubBrowserIcon,
      hubRing,
      stars,
    },
    interactablesByMode,
    floorInteractables,
    getActiveInteractables,
    buttons,
    updateButtonLabel,
    rebuildKeyboard,
    setActiveModeVisibility,
    setTheaterLighting,
    setCinemaScreenScale,
    updateDynamicHudTextures,
    updateVolumeSliders,
    setEnvironment,
    updateEnvironment,
    dispose,
  };
}
