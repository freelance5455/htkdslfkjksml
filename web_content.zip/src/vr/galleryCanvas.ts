import * as THREE from 'three';
import {
  filterGalleryItems,
  formatFileSize,
  GalleryViewState,
  getProjectionSpec,
} from './vrState';

export class GalleryScreenRenderer {
  public readonly canvas: HTMLCanvasElement;
  public readonly texture: THREE.CanvasTexture;
  private ctx: CanvasRenderingContext2D;
  private thumbCache = new Map<string, HTMLImageElement>();

  constructor(isSoftwareGl: boolean) {
    this.canvas = document.createElement('canvas');
    this.canvas.width = isSoftwareGl ? 1024 : 1400;
    this.canvas.height = isSoftwareGl ? 640 : 875;
    const ctx = this.canvas.getContext('2d');
    if (!ctx) throw new Error('Could not create gallery canvas context');
    this.ctx = ctx;

    this.texture = new THREE.CanvasTexture(this.canvas);
    this.texture.colorSpace = THREE.SRGBColorSpace;
    this.texture.minFilter = THREE.LinearFilter;
    this.texture.magFilter = THREE.LinearFilter;
  }

  private ensureThumbnail(id: string, dataUrl: string, onLoaded: () => void): HTMLImageElement | null {
    const existing = this.thumbCache.get(id);
    if (existing) return existing.complete ? existing : null;

    const img = new Image();
    img.onload = () => {
      onLoaded();
    };
    img.src = dataUrl;
    this.thumbCache.set(id, img);
    return img.complete ? img : null;
  }

  public render(state: GalleryViewState): void {
    const { width: w, height: h } = this.canvas;
    const ctx = this.ctx;
    const scale = w / 1400;

    ctx.fillStyle = '#0d1320';
    ctx.fillRect(0, 0, w, h);

    // Header Bar
    ctx.fillStyle = '#151e30';
    ctx.fillRect(0, 0, w, 110 * scale);
    ctx.fillStyle = '#26344d';
    ctx.fillRect(0, 108 * scale, w, 2 * scale);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#f8fafc';
    ctx.font = `700 ${Math.round(34 * scale)}px Cairo, sans-serif`;
    ctx.fillText('المعرض ومتصفح الملفات داخل VR', w - 48 * scale, 54 * scale);

    const filterLabel =
      state.filter === 'all'
        ? 'الكل'
        : state.filter === 'video'
          ? 'الفيديوهات فقط'
          : 'الصور فقط';
    const targetLabel =
      state.preferredTarget === 'auto'
        ? 'تلقائي حسب الملف'
        : state.preferredTarget === 'cinema'
          ? 'السينما الافتراضية'
          : 'مشغل 360° / 3D';

    ctx.fillStyle = '#38bdf8';
    ctx.font = `500 ${Math.round(21 * scale)}px Cairo, sans-serif`;
    ctx.fillText(
      `التصفية: ${filterLabel}   ·   الوجهة: ${targetLabel}`,
      w - 48 * scale,
      90 * scale
    );

    const deviceCount = state.items.filter((i) => i.sourceType === 'device').length;
    ctx.textAlign = 'left';
    ctx.fillStyle = deviceCount > 0 ? '#34d399' : '#fbbf24';
    ctx.font = `700 ${Math.round(22 * scale)}px Cairo, sans-serif`;
    ctx.fillText(
      deviceCount > 0
        ? `ملفات الجهاز: ${deviceCount} | المجموع: ${state.items.length}`
        : 'انظر لزر «استيراد من المعرض» لإضافة صورك وأفلامك',
      48 * scale,
      68 * scale
    );

    const filtered = filterGalleryItems(state.items, state.filter, state.folderFilter);
    const visible = filtered.slice(state.scrollOffset, state.scrollOffset + 4);

    if (visible.length === 0) {
      ctx.direction = 'rtl';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#94a3b8';
      ctx.font = `600 ${Math.round(28 * scale)}px Cairo, sans-serif`;
      ctx.fillText(
        'لا توجد ملفات مطابقة للتصفية الحالية. انظر لزر الإضافة لاختيار ملفات.',
        w / 2,
        h * 0.52
      );
      this.texture.needsUpdate = true;
      return;
    }

    visible.forEach((item, i) => {
      const cardX = 48 * scale;
      const cardY = (138 + i * 172) * scale;
      const cardW = w - 96 * scale;
      const cardH = 152 * scale;
      const isHovered = state.hoveredSlot === i;

      ctx.fillStyle = isHovered
        ? '#1b2b44'
        : item.sourceType === 'device'
          ? '#142033'
          : '#131b2b';
      ctx.beginPath();
      ctx.roundRect(cardX, cardY, cardW, cardH, 16 * scale);
      ctx.fill();
      ctx.strokeStyle = isHovered
        ? '#38bdf8'
        : item.sourceType === 'device'
          ? '#2dd4bf'
          : '#26354d';
      ctx.lineWidth = (isHovered ? 3.5 : 2) * scale;
      ctx.stroke();

      // Slot #1..#4 Badge (left)
      ctx.fillStyle = isHovered ? '#38bdf8' : item.kind === 'image' ? '#2dd4bf' : '#f59e0b';
      ctx.beginPath();
      ctx.roundRect(cardX + 18 * scale, cardY + 24 * scale, 52 * scale, 52 * scale, 12 * scale);
      ctx.fill();
      ctx.fillStyle = '#090c12';
      ctx.direction = 'ltr';
      ctx.textAlign = 'center';
      ctx.font = `700 ${Math.round(26 * scale)}px "JetBrains Mono", monospace`;
      ctx.fillText(String(i + 1), cardX + 44 * scale, cardY + 59 * scale);

      // Thumbnail Box
      const thumbX = cardX + 88 * scale;
      const thumbY = cardY + 18 * scale;
      const thumbW = 196 * scale;
      const thumbH = 116 * scale;

      ctx.save();
      ctx.beginPath();
      ctx.roundRect(thumbX, thumbY, thumbW, thumbH, 12 * scale);
      ctx.clip();

      const thumbImg = item.thumbnailDataUrl
        ? this.ensureThumbnail(item.id, item.thumbnailDataUrl, () => this.render(state))
        : null;

      if (thumbImg) {
        ctx.drawImage(thumbImg, thumbX, thumbY, thumbW, thumbH);
      } else {
        const grad = ctx.createLinearGradient(thumbX, thumbY, thumbX + thumbW, thumbY + thumbH);
        grad.addColorStop(0, '#0f172a');
        grad.addColorStop(1, item.accentColor || '#38bdf8');
        ctx.fillStyle = grad;
        ctx.fillRect(thumbX, thumbY, thumbW, thumbH);
        // Subtle stylized horizon / play emblem for builtin previews
        ctx.fillStyle = 'rgba(255,255,255,0.16)';
        ctx.beginPath();
        ctx.arc(thumbX + thumbW * 0.5, thumbY + thumbH * 0.5, 24 * scale, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#f8fafc';
        ctx.direction = 'ltr';
        ctx.textAlign = 'center';
        ctx.font = `700 ${Math.round(20 * scale)}px "Plus Jakarta Sans", Cairo, sans-serif`;
        ctx.fillText(
          item.kind === 'image' ? 'IMG' : item.defaultTarget === '360' ? '360° VR' : 'CINEMA',
          thumbX + thumbW / 2,
          thumbY + thumbH / 2 + 7 * scale
        );
      }
      ctx.restore();

      // Metadata (right-aligned)
      const textRightX = cardX + cardW - 24 * scale;
      ctx.direction = 'rtl';
      ctx.textAlign = 'right';

      const sourceBadge = item.sourceType === 'device' ? 'ملف من جهازك' : 'عرض مدمج';
      const kindBadge = item.kind === 'image' ? 'صورة' : 'فيديو';
      const projBadge =
        item.defaultTarget === '360'
          ? getProjectionSpec(item.defaultProjection).label
          : 'شاشة السينما';

      ctx.fillStyle = item.sourceType === 'device' ? '#34d399' : '#38bdf8';
      ctx.font = `600 ${Math.round(19 * scale)}px Cairo, sans-serif`;
      ctx.fillText(
        `${sourceBadge}  ·  ${kindBadge}  ·  ${formatFileSize(item.sizeBytes)}`,
        textRightX,
        cardY + 38 * scale
      );

      ctx.direction = /[\u0600-\u06FF]/.test(item.name) ? 'rtl' : 'ltr';
      ctx.fillStyle = '#f8fafc';
      ctx.font = `700 ${Math.round(28 * scale)}px Cairo, sans-serif`;
      ctx.fillText(item.name.slice(0, 44), textRightX, cardY + 84 * scale);

      ctx.direction = 'rtl';
      ctx.fillStyle = '#94a3b8';
      ctx.font = `400 ${Math.round(20 * scale)}px Cairo, sans-serif`;
      ctx.fillText(
        `المجلد: ${item.folderName || 'المعرض'}   ·   ${projBadge}`,
        textRightX,
        cardY + 124 * scale
      );
    });

    // Footer pagination
    const pageInfo = `عرض ${state.scrollOffset + 1}–${Math.min(
      filtered.length,
      state.scrollOffset + 4
    )} من أصل ${filtered.length} ملف — انظر مباشرة على أي بطاقة لتشغيلها`;
    ctx.direction = 'rtl';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#94a3b8';
    ctx.font = `500 ${Math.round(20 * scale)}px Cairo, sans-serif`;
    ctx.fillText(pageInfo, w / 2, h - 22 * scale);

    this.texture.needsUpdate = true;
  }

  public dispose(): void {
    this.thumbCache.clear();
    this.texture.dispose();
  }
}
