export interface GazeState {
  targetId: string | null;
  dwellElapsedMs: number;
  dwellDurationMs: number;
  cooldownUntilMs: number;
  lastTriggeredId: string | null;
  triggeredCount: number;
}

export interface GazeStepResult {
  nextState: GazeState;
  progress: number;
  triggeredId: string | null;
}

export function createInitialGazeState(dwellDurationMs = 1300): GazeState {
  return {
    targetId: null,
    dwellElapsedMs: 0,
    dwellDurationMs,
    cooldownUntilMs: 0,
    lastTriggeredId: null,
    triggeredCount: 0,
  };
}

/**
 * Advances the hands-free gaze dwell state machine by deltaMs.
 * Triggers once when dwellElapsedMs reaches dwellDurationMs, then enforces a
 * cooldown before the same or next target re-triggers.
 */
export function stepGaze(
  state: GazeState,
  hoveredId: string | null,
  deltaMs: number,
  nowMs: number,
  cooldownMs = 750
): GazeStepResult {
  const safeDelta = Math.max(0, Math.min(deltaMs, 500));

  if (!hoveredId) {
    return {
      nextState: {
        ...state,
        targetId: null,
        dwellElapsedMs: 0,
      },
      progress: 0,
      triggeredId: null,
    };
  }

  // During post-trigger cooldown, wait before filling again on the same target
  if (nowMs < state.cooldownUntilMs && hoveredId === state.lastTriggeredId) {
    return {
      nextState: {
        ...state,
        targetId: hoveredId,
        dwellElapsedMs: 0,
      },
      progress: 0,
      triggeredId: null,
    };
  }

  const isSameTarget = state.targetId === hoveredId;
  const elapsed = isSameTarget ? state.dwellElapsedMs + safeDelta : safeDelta;
  const duration = Math.max(300, state.dwellDurationMs);

  if (elapsed >= duration) {
    return {
      nextState: {
        ...state,
        targetId: hoveredId,
        dwellElapsedMs: 0,
        cooldownUntilMs: nowMs + cooldownMs,
        lastTriggeredId: hoveredId,
        triggeredCount: state.triggeredCount + 1,
      },
      progress: 1,
      triggeredId: hoveredId,
    };
  }

  return {
    nextState: {
      ...state,
      targetId: hoveredId,
      dwellElapsedMs: elapsed,
    },
    progress: Math.min(1, elapsed / duration),
    triggeredId: null,
  };
}

export interface StereoViewportSpec {
  leftViewport: { x: number; y: number; width: number; height: number };
  rightViewport: { x: number; y: number; width: number; height: number };
  eyeOffsetMeters: number;
  eyeAspect: number;
}

/**
 * Computes left and right eye viewport rectangles and physical half-IPD offset
 * for VR Box side-by-side stereo rendering.
 */
export function computeStereoViewports(
  canvasWidth: number,
  canvasHeight: number,
  ipdMm = 64
): StereoViewportSpec {
  const halfW = Math.max(1, Math.floor(canvasWidth / 2));
  const h = Math.max(1, Math.floor(canvasHeight));
  const clampedIpd = Math.max(50, Math.min(76, ipdMm));

  return {
    leftViewport: { x: 0, y: 0, width: halfW, height: h },
    rightViewport: { x: halfW, y: 0, width: canvasWidth - halfW, height: h },
    eyeOffsetMeters: (clampedIpd / 1000) * 0.5,
    eyeAspect: halfW / h,
  };
}

export interface QuaternionTuple {
  x: number;
  y: number;
  z: number;
  w: number;
}

/**
 * Converts Android DeviceOrientation (alpha, beta, gamma in degrees) plus
 * screen orientation angle (0, 90, -90, 180) into a normalized world-space
 * camera quaternion (WebVR / W3C DeviceOrientation standard).
 */
export function deviceOrientationToQuaternion(
  alphaDeg: number,
  betaDeg: number,
  gammaDeg: number,
  screenAngleDeg = 0
): QuaternionTuple {
  const deg2rad = Math.PI / 180;
  const alpha = alphaDeg * deg2rad;
  const beta = betaDeg * deg2rad;
  const gamma = gammaDeg * deg2rad;
  const orient = screenAngleDeg * deg2rad;

  // ZXY Euler (beta = X, alpha = Z, -gamma = Y)
  const c1 = Math.cos(beta / 2);
  const c2 = Math.cos(-gamma / 2);
  const c3 = Math.cos(alpha / 2);
  const s1 = Math.sin(beta / 2);
  const s2 = Math.sin(-gamma / 2);
  const s3 = Math.sin(alpha / 2);

  // YXZ quaternion for ZXY order: Rz(alpha) * Rx(beta) * Ry(-gamma)
  const qx = s1 * c2 * c3 + c1 * s2 * s3;
  const qy = c1 * s2 * c3 - s1 * c2 * s3;
  const qz = c1 * c2 * s3 - s1 * s2 * c3;
  const qw = c1 * c2 * c3 + s1 * s2 * s3;

  // Multiply by -90 deg around X to align phone back camera to -Z forward: q1 = (-sqrt(0.5), 0, 0, sqrt(0.5))
  const sHalf = Math.SQRT1_2;
  const a1x = qx * sHalf - qw * sHalf;
  const a1y = qy * sHalf + qz * sHalf;
  const a1z = qz * sHalf - qy * sHalf;
  const a1w = qw * sHalf + qx * sHalf;

  // Multiply by screen orientation around Z: q2 = (0, 0, sin(-orient/2), cos(-orient/2))
  const sz = Math.sin(-orient / 2);
  const cz = Math.cos(-orient / 2);

  const fx = a1x * cz + a1y * sz;
  const fy = a1y * cz - a1x * sz;
  const fz = a1z * cz + a1w * sz;
  const fw = a1w * cz - a1z * sz;

  const len = Math.hypot(fx, fy, fz, fw) || 1;
  return { x: fx / len, y: fy / len, z: fz / len, w: fw / len };
}

export function clampPitchRadians(pitchRad: number): number {
  const limit = Math.PI * 0.47;
  return Math.max(-limit, Math.min(limit, pitchRad));
}

export function shortestAngleDiffRadians(targetRad: number, currentRad: number): number {
  let diff = (targetRad - currentRad) % (Math.PI * 2);
  if (diff > Math.PI) diff -= Math.PI * 2;
  if (diff < -Math.PI) diff += Math.PI * 2;
  return diff;
}
