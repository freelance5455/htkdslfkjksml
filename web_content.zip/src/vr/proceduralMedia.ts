import * as THREE from 'three';
import type { MediaSceneItem, Video360Projection } from './vrState';
import { getProjectionSpec } from './vrState';

export class SpatialAudioEngine {
  private ctx: AudioContext | null = null;
  public muted = false;
  public volume = 0.8;

  public setVolume(v: number): void {
    this.volume = Math.max(0, Math.min(1, v));
  }

  private ensureContext(): AudioContext | null {
    if (this.muted || this.volume <= 0 || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public playHover(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(640, now);
    osc.frequency.exponentialRampToValueAtTime(820, now + 0.05);
    gain.gain.setValueAtTime(Math.max(0.002, 0.04 * this.volume), now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.065);
  }

  public playSelect(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const notes = [523.25, 783.99];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      const t = now + idx * 0.06;
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(Math.max(0.002, 0.08 * this.volume), t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.2);
    });
  }

  public playBack(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(320, now + 0.14);
    gain.gain.setValueAtTime(Math.max(0.002, 0.07 * this.volume), now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.17);
  }

  public dispose(): void {
    if (this.ctx) {
      this.ctx.close().catch(() => {});
      this.ctx = null;
    }
  }
}

export class Procedural360Renderer {
  public readonly canvas: HTMLCanvasElement;
  public readonly texture: THREE.CanvasTexture;
  private ctx: CanvasRenderingContext2D;

  constructor(isSoftwareGl: boolean) {
    this.canvas = document.createElement('canvas');
    this.canvas.width = isSoftwareGl ? 1024 : 1536;
    this.canvas.height = isSoftwareGl ? 512 : 768;
    const ctx = this.canvas.getContext('2d');
    if (!ctx) throw new Error('Could not initialize 360 canvas context');
    this.ctx = ctx;

    this.texture = new THREE.CanvasTexture(this.canvas);
    this.texture.colorSpace = THREE.SRGBColorSpace;
    this.texture.wrapS = THREE.RepeatWrapping;
    this.texture.wrapT = THREE.ClampToEdgeWrapping;
    this.texture.minFilter = THREE.LinearFilter;
    this.texture.magFilter = THREE.LinearFilter;
  }

  private drawEyePanorama(
    theme: MediaSceneItem['theme'],
    timeSec: number,
    rx: number,
    ry: number,
    rw: number,
    rh: number,
    eyeParallax: number
  ): void {
    const ctx = this.ctx;
    ctx.save();
    ctx.beginPath();
    ctx.rect(rx, ry, rw, rh);
    ctx.clip();
    ctx.translate(rx, ry);

    const w = rw;
    const h = rh;
    const horizon = h * 0.52;

    if (theme === 'space') {
      const sky = ctx.createLinearGradient(0, 0, 0, h);
      sky.addColorStop(0, '#02040a');
      sky.addColorStop(0.42, '#071426');
      sky.addColorStop(0.56, '#0c2748');
      sky.addColorStop(0.75, '#0b1b36');
      sky.addColorStop(1, '#040914');
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, w, h);

      for (let i = 0; i < 90; i++) {
        const u = (i * 0.6180339887) % 1;
        const v = (i * 0.381966 + 0.11) % 0.68;
        const twinkle = 0.4 + 0.6 * Math.abs(Math.sin(timeSec * 1.4 + i));
        ctx.fillStyle = `rgba(226, 240, 255, ${twinkle.toFixed(2)})`;
        const size = (i % 4 === 0 ? 2.4 : 1.3) * (w / 1024);
        ctx.fillRect(u * w, v * h, size, size);
      }

      for (let band = 0; band < 3; band++) {
        ctx.beginPath();
        const baseY = h * (0.24 + band * 0.05);
        for (let step = 0; step <= 48; step++) {
          const u = step / 48;
          const ang = u * Math.PI * 2;
          const y =
            baseY +
            Math.sin(ang * 2 + timeSec * 0.6 + band) * h * 0.045 +
            Math.cos(ang * 3 - timeSec * 0.4) * h * 0.02;
          if (step === 0) ctx.moveTo(u * w, y);
          else ctx.lineTo(u * w, y);
        }
        ctx.strokeStyle =
          band === 0
            ? 'rgba(56, 189, 248, 0.36)'
            : band === 1
              ? 'rgba(45, 212, 191, 0.28)'
              : 'rgba(129, 140, 248, 0.22)';
        ctx.lineWidth = (16 - band * 3) * (w / 1024);
        ctx.stroke();
      }

      // 3D depth foreground orb centered ahead (u = 0.5) with eye parallax
      const orbX = w * 0.5 + eyeParallax * w * 0.012;
      const orbY = h * 0.42;
      const orbR = Math.min(w, h) * 0.09;
      const orbGrad = ctx.createRadialGradient(
        orbX - orbR * 0.3,
        orbY - orbR * 0.3,
        orbR * 0.1,
        orbX,
        orbY,
        orbR
      );
      orbGrad.addColorStop(0, '#e0f2fe');
      orbGrad.addColorStop(0.5, '#38bdf8');
      orbGrad.addColorStop(1, '#0c4a6e');
      ctx.fillStyle = orbGrad;
      ctx.beginPath();
      ctx.arc(orbX, orbY, orbR, 0, Math.PI * 2);
      ctx.fill();

      const earthGrad = ctx.createLinearGradient(0, h * 0.54, 0, h);
      earthGrad.addColorStop(0, 'rgba(56, 189, 248, 0.45)');
      earthGrad.addColorStop(0.12, '#0b3c6e');
      earthGrad.addColorStop(0.55, '#072247');
      earthGrad.addColorStop(1, '#041226');
      ctx.fillStyle = earthGrad;
      ctx.fillRect(0, h * 0.56, w, h * 0.44);

      ctx.fillStyle = 'rgba(224, 242, 254, 0.16)';
      for (let c = 0; c < 8; c++) {
        const cx = (((c / 8 + timeSec * 0.008 + eyeParallax * 0.004) % 1 + 1) % 1) * w;
        const cy = h * (0.64 + (c % 3) * 0.08);
        ctx.beginPath();
        ctx.ellipse(cx, cy, w * 0.08, h * 0.028, 0, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (theme === 'ocean') {
      const water = ctx.createLinearGradient(0, 0, 0, h);
      water.addColorStop(0, '#38bdf8');
      water.addColorStop(0.25, '#0284c7');
      water.addColorStop(0.6, '#0f3d5e');
      water.addColorStop(1, '#051a2e');
      ctx.fillStyle = water;
      ctx.fillRect(0, 0, w, h);

      for (let i = 0; i < 8; i++) {
        const u = (i / 8 + Math.sin(timeSec * 0.3 + i) * 0.02 + 1) % 1;
        const x = u * w;
        const beam = ctx.createLinearGradient(x, 0, x, h * 0.72);
        beam.addColorStop(0, 'rgba(224, 247, 255, 0.32)');
        beam.addColorStop(1, 'rgba(56, 189, 248, 0)');
        ctx.fillStyle = beam;
        ctx.beginPath();
        ctx.moveTo(x - w * 0.02, 0);
        ctx.lineTo(x + w * 0.02, 0);
        ctx.lineTo(x + w * 0.06, h * 0.72);
        ctx.lineTo(x - w * 0.06, h * 0.72);
        ctx.closePath();
        ctx.fill();
      }

      ctx.fillStyle = '#072238';
      ctx.beginPath();
      ctx.moveTo(0, h);
      for (let s = 0; s <= 40; s++) {
        const u = s / 40;
        const ang = u * Math.PI * 2;
        const y =
          h * 0.76 + Math.sin(ang * 5) * h * 0.04 + Math.cos(ang * 9) * h * 0.025;
        ctx.lineTo(u * w, y);
      }
      ctx.lineTo(w, h);
      ctx.closePath();
      ctx.fill();

      for (let f = 0; f < 18; f++) {
        const fx =
          (((f * 0.13 + timeSec * (0.03 + (f % 3) * 0.006) + eyeParallax * 0.006) % 1 + 1) %
            1) *
          w;
        const fy = h * (0.34 + (f % 5) * 0.07) + Math.sin(timeSec * 2 + f) * h * 0.015;
        ctx.fillStyle = f % 2 === 0 ? '#5eead4' : '#fde047';
        ctx.beginPath();
        ctx.ellipse(fx, fy, w * 0.014, h * 0.009, 0, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (theme === 'desert') {
      const sky = ctx.createLinearGradient(0, 0, 0, horizon);
      sky.addColorStop(0, '#090b1a');
      sky.addColorStop(0.55, '#1e1b4b');
      sky.addColorStop(1, '#c2410c');
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, w, horizon);

      for (let i = 0; i < 80; i++) {
        const u = (i * 0.61803) % 1;
        const v = (i * 0.291) % 0.42;
        ctx.fillStyle = `rgba(255, 245, 220, ${0.4 + 0.5 * Math.sin(timeSec + i)})`;
        ctx.fillRect(u * w, v * h, 2, 2);
      }

      const duneColors = ['#7c2d12', '#9a3412', '#451a03'];
      duneColors.forEach((col, idx) => {
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(0, h);
        for (let s = 0; s <= 40; s++) {
          const u = s / 40;
          const ang = u * Math.PI * 2;
          const y =
            horizon +
            idx * h * 0.09 +
            Math.sin(ang * (2 + idx) + idx + eyeParallax * idx * 0.02) * h * 0.045;
          ctx.lineTo(u * w, y);
        }
        ctx.lineTo(w, h);
        ctx.closePath();
        ctx.fill();
      });
    } else {
      const sky = ctx.createLinearGradient(0, 0, 0, horizon);
      sky.addColorStop(0, '#060914');
      sky.addColorStop(0.65, '#0f172a');
      sky.addColorStop(1, '#1e293b');
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, w, horizon);

      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, horizon, w, h - horizon);

      const towerCount = 26;
      const bw = w / towerCount;
      for (let i = 0; i < towerCount; i++) {
        const bh = h * (0.12 + ((i * 37) % 19) * 0.014);
        const bx = i * bw + eyeParallax * 2;
        const by = horizon - bh;
        ctx.fillStyle = i % 2 === 0 ? '#111827' : '#0f172a';
        ctx.fillRect(bx + 2, by, bw - 4, bh);

        ctx.fillStyle = i % 3 === 0 ? 'rgba(56, 189, 248, 0.7)' : 'rgba(251, 191, 36, 0.6)';
        for (let wy = by + 8; wy < horizon - 8; wy += 12) {
          if ((wy + i) % 3 !== 0) {
            ctx.fillRect(bx + 6, wy, Math.max(3, bw - 14), 4);
          }
        }
      }
    }

    ctx.restore();
  }

  public render(
    theme: MediaSceneItem['theme'],
    timeSec: number,
    projection: Video360Projection = '360-mono'
  ): void {
    const { width: w, height: h } = this.canvas;
    const spec = getProjectionSpec(projection);

    if (spec.stereoLayout === 'sbs') {
      // Side-by-Side 3D: Left half (eye -1), Right half (eye +1)
      this.drawEyePanorama(theme, timeSec, 0, 0, w / 2, h, -1);
      this.drawEyePanorama(theme, timeSec, w / 2, 0, w / 2, h, 1);
    } else if (spec.stereoLayout === 'tb') {
      // Top-Bottom 3D: Top half (Left eye), Bottom half (Right eye)
      this.drawEyePanorama(theme, timeSec, 0, 0, w, h / 2, -1);
      this.drawEyePanorama(theme, timeSec, 0, h / 2, w, h / 2, 1);
    } else {
      this.drawEyePanorama(theme, timeSec, 0, 0, w, h, 0);
    }

    this.texture.needsUpdate = true;
  }

  public dispose(): void {
    this.texture.dispose();
  }
}

export class ProceduralCinemaRenderer {
  public readonly canvas: HTMLCanvasElement;
  public readonly texture: THREE.CanvasTexture;
  private ctx: CanvasRenderingContext2D;
  public dominantColor = new THREE.Color('#38bdf8');

  constructor(isSoftwareGl: boolean) {
    this.canvas = document.createElement('canvas');
    this.canvas.width = isSoftwareGl ? 640 : 1024;
    this.canvas.height = isSoftwareGl ? 360 : 576;
    const ctx = this.canvas.getContext('2d');
    if (!ctx) throw new Error('Could not initialize cinema canvas');
    this.ctx = ctx;

    this.texture = new THREE.CanvasTexture(this.canvas);
    this.texture.colorSpace = THREE.SRGBColorSpace;
    this.texture.minFilter = THREE.LinearFilter;
    this.texture.magFilter = THREE.LinearFilter;
  }

  public render(
    movie: MediaSceneItem,
    timeSec: number,
    isPlaying: boolean
  ): void {
    const { width: w, height: h } = this.canvas;
    const ctx = this.ctx;
    const t = timeSec;

    const bg = ctx.createLinearGradient(0, 0, w, h);
    if (movie.theme === 'space') {
      bg.addColorStop(0, '#04091a');
      bg.addColorStop(0.5, '#0c2344');
      bg.addColorStop(1, '#091124');
      this.dominantColor.set('#38bdf8');
    } else if (movie.theme === 'ocean') {
      bg.addColorStop(0, '#042f2e');
      bg.addColorStop(0.5, '#0e7490');
      bg.addColorStop(1, '#082f49');
      this.dominantColor.set('#2dd4bf');
    } else if (movie.theme === 'desert') {
      bg.addColorStop(0, '#271206');
      bg.addColorStop(0.5, '#b45309');
      bg.addColorStop(1, '#451a03');
      this.dominantColor.set('#f59e0b');
    } else {
      bg.addColorStop(0, '#0f172a');
      bg.addColorStop(0.5, '#1e1b4b');
      bg.addColorStop(1, '#090d16');
      this.dominantColor.set('#818cf8');
    }
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    ctx.save();
    ctx.translate(w / 2, h / 2);
    for (let i = 0; i < 6; i++) {
      const radius = ((t * 26 + i * 55) % 320) * (w / 1024);
      const alpha = Math.max(0, 1 - radius / (320 * (w / 1024))) * 0.45;
      ctx.strokeStyle =
        movie.theme === 'desert'
          ? `rgba(251, 191, 36, ${alpha.toFixed(2)})`
          : `rgba(56, 189, 248, ${alpha.toFixed(2)})`;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(0, 0, radius, 0, Math.PI * 2);
      ctx.stroke();
    }

    const orbR = w * 0.11;
    const orbGrad = ctx.createRadialGradient(-orbR * 0.3, -orbR * 0.3, orbR * 0.1, 0, 0, orbR);
    orbGrad.addColorStop(0, '#ffffff');
    orbGrad.addColorStop(0.35, movie.accentColor);
    orbGrad.addColorStop(1, 'rgba(9, 12, 18, 0.9)');
    ctx.fillStyle = orbGrad;
    ctx.beginPath();
    ctx.arc(0, 0, orbR, 0, Math.PI * 2);
    ctx.fill();

    ctx.rotate(Math.sin(t * 0.35) * 0.25);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(0, 0, orbR * 1.9, orbR * 0.48, 0.2, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();

    const barH = h * 0.085;
    ctx.fillStyle = '#030509';
    ctx.fillRect(0, 0, w, barH);
    ctx.fillRect(0, h - barH, w, barH);

    ctx.fillStyle = '#e2e8f0';
    ctx.font = `600 ${Math.round(w * 0.024)}px Cairo, sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillText(movie.title, w / 2, h - barH * 0.34);

    if (!isPlaying) {
      ctx.fillStyle = 'rgba(9, 12, 18, 0.52)';
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = '#f8fafc';
      ctx.font = `700 ${Math.round(w * 0.04)}px Cairo, sans-serif`;
      ctx.fillText('متوقف مؤقتاً — انظر لزر التشغيل للمتابعة', w / 2, h / 2 + w * 0.17);
    }

    this.texture.needsUpdate = true;
  }

  public dispose(): void {
    this.texture.dispose();
  }
}
