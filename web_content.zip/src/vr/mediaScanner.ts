import {
  GalleryItem,
  inferProjectionFromFilename,
  isSupportedMediaFileName,
} from './vrState';

interface FileSystemDirectoryHandleLike {
  name: string;
  values(): AsyncIterable<FileSystemHandleLike>;
}

interface FileSystemHandleLike {
  kind: 'file' | 'directory';
  name: string;
  getFile?: () => Promise<File>;
  values?: () => AsyncIterable<FileSystemHandleLike>;
}

const DB_NAME = 'nazar_vr_gallery_db';
const STORE_NAME = 'device_media';
const DB_VERSION = 1;

interface StoredMediaRecord {
  id: string;
  name: string;
  kind: 'video' | 'image';
  mimeType: string;
  sizeBytes: number;
  folderName?: string;
  thumbnailDataUrl?: string;
  addedAt: string;
  blob: Blob;
}

function openMediaDB(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === 'undefined') return Promise.resolve(null);
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

export async function generateThumbnail(
  file: Blob,
  kind: 'video' | 'image'
): Promise<string | undefined> {
  if (typeof document === 'undefined') return undefined;
  const tempUrl = URL.createObjectURL(file);

  try {
    if (kind === 'image') {
      const img = await new Promise<HTMLImageElement>((res, rej) => {
        const el = new Image();
        el.onload = () => res(el);
        el.onerror = () => rej(new Error('Image load failed'));
        el.src = tempUrl;
      });
      const canvas = document.createElement('canvas');
      canvas.width = 240;
      canvas.height = 144;
      const ctx = canvas.getContext('2d');
      if (!ctx) return undefined;
      const ratio = Math.max(canvas.width / img.width, canvas.height / img.height);
      const dw = img.width * ratio;
      const dh = img.height * ratio;
      ctx.drawImage(img, (canvas.width - dw) / 2, (canvas.height - dh) / 2, dw, dh);
      return canvas.toDataURL('image/jpeg', 0.72);
    }

    const vid = document.createElement('video');
    vid.muted = true;
    vid.playsInline = true;
    vid.preload = 'metadata';
    vid.src = tempUrl;

    await new Promise<void>((res, rej) => {
      const timer = setTimeout(() => rej(new Error('timeout')), 2500);
      vid.onloadeddata = () => {
        if (vid.duration && Number.isFinite(vid.duration)) {
          vid.currentTime = Math.min(1.5, vid.duration * 0.15);
        } else {
          clearTimeout(timer);
          res();
        }
      };
      vid.onseeked = () => {
        clearTimeout(timer);
        res();
      };
      vid.onerror = () => {
        clearTimeout(timer);
        rej(new Error('video error'));
      };
    });

    const canvas = document.createElement('canvas');
    canvas.width = 240;
    canvas.height = 144;
    const ctx = canvas.getContext('2d');
    if (!ctx || vid.videoWidth === 0) return undefined;
    const ratio = Math.max(canvas.width / vid.videoWidth, canvas.height / vid.videoHeight);
    const dw = vid.videoWidth * ratio;
    const dh = vid.videoHeight * ratio;
    ctx.drawImage(vid, (canvas.width - dw) / 2, (canvas.height - dh) / 2, dw, dh);
    return canvas.toDataURL('image/jpeg', 0.7);
  } catch {
    return undefined;
  } finally {
    URL.revokeObjectURL(tempUrl);
  }
}

export interface FileWithFolder {
  file: File;
  folderName: string;
}

export function buildImmediateGalleryItems(
  entries: Array<File | FileWithFolder>,
  fallbackFolder = 'المعرض المحلي'
): { items: GalleryItem[]; fileMap: Map<string, File> } {
  const items: GalleryItem[] = [];
  const fileMap = new Map<string, File>();
  const addedLabel = new Date().toLocaleDateString('ar-EG', {
    month: 'short',
    day: 'numeric',
  });

  for (const entry of entries) {
    const file = entry instanceof File ? entry : entry.file;
    const explicitFolder = entry instanceof File ? undefined : entry.folderName;
    const kind = isSupportedMediaFileName(file.name, file.type);
    if (!kind) continue;

    const relativePath = (file as File & { webkitRelativePath?: string }).webkitRelativePath;
    const folderName =
      explicitFolder ||
      (relativePath
        ? relativePath.split('/').slice(0, -1).join('/') || fallbackFolder
        : fallbackFolder);
    const inferred = inferProjectionFromFilename(file.name);
    const url = URL.createObjectURL(file);
    const id = `dev-${file.name}-${file.size}-${file.lastModified}`;

    fileMap.set(id, file);
    items.push({
      id,
      name: file.name,
      kind,
      sourceType: 'device',
      url,
      sizeBytes: file.size,
      mimeType: file.type || (kind === 'video' ? 'video/mp4' : 'image/jpeg'),
      folderName,
      defaultTarget: inferred.target,
      defaultProjection: inferred.projection,
      accentColor: kind === 'video' ? '#F59E0B' : '#2DD4BF',
      addedAt: addedLabel,
    });
  }

  return { items, fileMap };
}

export async function hydrateThumbnailsAndPersist(
  items: GalleryItem[],
  fileMap: Map<string, File>,
  onThumbnailReady: (id: string, thumbnailDataUrl: string) => void
): Promise<void> {
  const concurrency = 3;
  let cursor = 0;

  const worker = async () => {
    while (cursor < items.length) {
      const idx = cursor++;
      const item = items[idx];
      const file = fileMap.get(item.id);
      if (!file) continue;

      const thumbnailDataUrl = await generateThumbnail(file, item.kind);
      if (thumbnailDataUrl) {
        onThumbnailReady(item.id, thumbnailDataUrl);
      }

      if (file.size <= 150 * 1024 * 1024) {
        await saveRecordToDB({
          id: item.id,
          name: item.name,
          kind: item.kind,
          mimeType: item.mimeType || 'application/octet-stream',
          sizeBytes: item.sizeBytes ?? file.size,
          folderName: item.folderName,
          thumbnailDataUrl,
          addedAt: item.addedAt,
          blob: file,
        });
      }
    }
  };

  await Promise.all(
    Array.from({ length: Math.min(concurrency, items.length) }, () => worker())
  );
}

export async function filesToGalleryItems(
  fileList: File[] | FileList,
  fallbackFolder = 'المعرض المحلي'
): Promise<GalleryItem[]> {
  const { items, fileMap } = buildImmediateGalleryItems(Array.from(fileList), fallbackFolder);
  await hydrateThumbnailsAndPersist(items, fileMap, (id, thumb) => {
    const found = items.find((i) => i.id === id);
    if (found) found.thumbnailDataUrl = thumb;
  });
  return items;
}

export async function extractDroppedMediaFiles(
  dataTransfer: DataTransfer
): Promise<FileWithFolder[]> {
  const collected: FileWithFolder[] = [];

  type WebkitEntry = {
    isFile: boolean;
    isDirectory: boolean;
    name: string;
    file?: (cb: (f: File) => void, err?: () => void) => void;
    createReader?: () => {
      readEntries: (cb: (entries: WebkitEntry[]) => void, err?: () => void) => void;
    };
  };

  const readEntry = async (entry: WebkitEntry, folderLabel: string, depth: number): Promise<void> => {
    if (depth > 4 || collected.length >= 120) return;
    if (entry.isFile && entry.file) {
      const f = await new Promise<File | null>((res) => {
        entry.file?.((file) => res(file), () => res(null));
      });
      if (f && isSupportedMediaFileName(f.name, f.type)) {
        collected.push({ file: f, folderName: folderLabel });
      }
      return;
    }
    if (entry.isDirectory && entry.createReader) {
      const reader = entry.createReader();
      const nextFolder = folderLabel === 'المعرض المحلي' ? entry.name : `${folderLabel}/${entry.name}`;
      let batch: WebkitEntry[] = [];
      do {
        batch = await new Promise<WebkitEntry[]>((res) => {
          reader.readEntries((entries) => res(entries), () => res([]));
        });
        for (const child of batch) {
          await readEntry(child, nextFolder, depth + 1);
        }
      } while (batch.length > 0 && collected.length < 120);
    }
  };

  const dtItems = Array.from(dataTransfer.items || []);
  let usedEntries = false;
  for (const item of dtItems) {
    const getEntry = (item as DataTransferItem & { webkitGetAsEntry?: () => WebkitEntry | null })
      .webkitGetAsEntry;
    if (typeof getEntry === 'function') {
      const entry = getEntry.call(item);
      if (entry) {
        usedEntries = true;
        await readEntry(entry, 'المعرض المحلي', 0);
      }
    }
  }

  if (!usedEntries && dataTransfer.files.length > 0) {
    for (const file of Array.from(dataTransfer.files)) {
      if (isSupportedMediaFileName(file.name, file.type)) {
        collected.push({ file, folderName: 'المعرض المحلي' });
      }
    }
  }

  return collected;
}

export async function scanDirectoryWithPicker(): Promise<{
  supported: boolean;
  entries: FileWithFolder[];
  items: GalleryItem[];
  cancelled?: boolean;
}> {
  const win = window as unknown as {
    showDirectoryPicker?: (opts?: { mode?: string }) => Promise<FileSystemDirectoryHandleLike>;
  };
  if (typeof win.showDirectoryPicker !== 'function') {
    return { supported: false, entries: [], items: [] };
  }

  try {
    const dirHandle = await win.showDirectoryPicker({ mode: 'read' });
    const collectedFiles: FileWithFolder[] = [];

    const walk = async (
      handle: FileSystemDirectoryHandleLike,
      pathLabel: string,
      depth: number
    ) => {
      if (depth > 3 || collectedFiles.length >= 100) return;
      for await (const entry of handle.values()) {
        if (collectedFiles.length >= 100) break;
        if (entry.kind === 'file' && entry.getFile) {
          const file = await entry.getFile();
          if (isSupportedMediaFileName(file.name, file.type)) {
            collectedFiles.push({ file, folderName: pathLabel });
          }
        } else if (entry.kind === 'directory' && entry.values) {
          await walk(
            entry as unknown as FileSystemDirectoryHandleLike,
            `${pathLabel}/${entry.name}`,
            depth + 1
          );
        }
      }
    };

    await walk(dirHandle, dirHandle.name, 0);
    return { supported: true, entries: collectedFiles, items: [] };
  } catch (err) {
    if ((err as { name?: string })?.name === 'AbortError') {
      return { supported: true, entries: [], items: [], cancelled: true };
    }
    return { supported: false, entries: [], items: [] };
  }
}

async function saveRecordToDB(record: StoredMediaRecord): Promise<void> {
  const db = await openMediaDB();
  if (!db) return;
  try {
    await new Promise<void>((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } catch {
    // Ignore quota errors
  } finally {
    db.close();
  }
}

export async function loadPersistedDeviceGallery(): Promise<GalleryItem[]> {
  const db = await openMediaDB();
  if (!db) return [];
  try {
    const records = await new Promise<StoredMediaRecord[]>((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).getAll();
      req.onsuccess = () => resolve((req.result as StoredMediaRecord[]) || []);
      req.onerror = () => resolve([]);
    });

    return records.map((rec) => {
      const inferred = inferProjectionFromFilename(rec.name);
      return {
        id: rec.id,
        name: rec.name,
        kind: rec.kind,
        sourceType: 'device',
        url: URL.createObjectURL(rec.blob),
        sizeBytes: rec.sizeBytes,
        mimeType: rec.mimeType,
        folderName: rec.folderName,
        defaultTarget: inferred.target,
        defaultProjection: inferred.projection,
        thumbnailDataUrl: rec.thumbnailDataUrl,
        accentColor: rec.kind === 'video' ? '#F59E0B' : '#2DD4BF',
        addedAt: rec.addedAt,
      };
    });
  } catch {
    return [];
  } finally {
    db.close();
  }
}

export async function removePersistedGalleryItem(id: string): Promise<void> {
  const db = await openMediaDB();
  if (!db) return;
  try {
    await new Promise<void>((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } finally {
    db.close();
  }
}
