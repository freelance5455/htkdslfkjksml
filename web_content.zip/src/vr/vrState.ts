export type VRMode = 'hub' | 'player360' | 'cinema' | 'browser' | 'gallery';
export type TheaterLightMode = 'cinematic' | 'dark' | 'ambient' | 'bright';
export type CinemaScreenSize = 'classic' | 'imax' | 'giant';
export type SceneEnvironmentId = 'observatory' | 'living_room' | 'beach' | 'moon' | 'bedroom';
export type Video360Projection = '360-mono' | '180-mono' | '180-sbs' | '360-sbs' | '360-tb';
export type KeyboardLang = 'ar' | 'en';
export type MediaFileKind = 'video' | 'image';
export type GalleryFilter = 'all' | 'video' | 'image';

export interface GalleryItem {
  id: string;
  name: string;
  kind: MediaFileKind;
  sourceType: 'device' | 'builtin';
  url: string;
  sizeBytes?: number;
  mimeType?: string;
  folderName?: string;
  defaultTarget: '360' | 'cinema';
  defaultProjection: Video360Projection;
  builtinIndex?: number;
  thumbnailDataUrl?: string;
  accentColor?: string;
  addedAt: string;
}

export interface GalleryViewState {
  items: GalleryItem[];
  filter: GalleryFilter;
  folderFilter: string;
  scrollOffset: number;
  preferredTarget: 'auto' | 'cinema' | '360';
  hoveredSlot?: number | null;
}

export interface MediaSceneItem {
  id: string;
  title: string;
  subtitle: string;
  durationSeconds: number;
  theme: 'space' | 'ocean' | 'desert' | 'city';
  accentColor: string;
  customUrl?: string;
}

export interface SearchResultCard {
  id: string;
  title: string;
  url: string;
  snippet: string;
  domain: string;
}

export interface BrowserPageLink {
  title: string;
  url: string;
  domain: string;
}

export interface BrowserPageContent {
  title: string;
  url: string;
  blocks: Array<{ type: 'heading' | 'paragraph' | 'link'; text: string; href?: string }>;
  links?: BrowserPageLink[];
  videoUrl?: string;
  imageUrl?: string;
  live: boolean;
}

export interface SavedBookmark {
  id: string;
  title: string;
  url: string;
  domain: string;
  savedAt: string;
}

export interface CuratedWebsite {
  id: string;
  label: string;
  domain: string;
  url: string;
  category: string;
  accent: string;
}

export interface BrowserHistoryEntry {
  view: 'home' | 'results' | 'article' | 'bookmarks';
  query: string;
  url?: string;
  results?: SearchResultCard[];
  currentPage?: BrowserPageContent | null;
}

export interface BrowserState {
  query: string;
  inputText: string;
  view: 'home' | 'results' | 'article' | 'bookmarks';
  results: SearchResultCard[];
  currentPage: BrowserPageContent | null;
  savedBookmarks: SavedBookmark[];
  scrollOffset: number;
  loading: boolean;
  keyboardLang: KeyboardLang;
  history: BrowserHistoryEntry[];
  hoveredSlot?: number | null;
}

export const PROJECTION_OPTIONS: Array<{
  id: Video360Projection;
  label: string;
  shortLabel: string;
  is180: boolean;
  stereoLayout: 'mono' | 'sbs' | 'tb';
}> = [
  { id: '360-mono', label: '360° عادي', shortLabel: '360°', is180: false, stereoLayout: 'mono' },
  { id: '180-mono', label: '180° VR', shortLabel: '180°', is180: true, stereoLayout: 'mono' },
  { id: '180-sbs', label: '180° 3D جنباً لجنب', shortLabel: '180° 3D', is180: true, stereoLayout: 'sbs' },
  { id: '360-sbs', label: '360° 3D جنباً لجنب', shortLabel: '360° SBS', is180: false, stereoLayout: 'sbs' },
  { id: '360-tb', label: '360° 3D فوق-تحت', shortLabel: '360° TB', is180: false, stereoLayout: 'tb' },
];

export const THEATER_LIGHT_OPTIONS: Array<{
  id: TheaterLightMode;
  label: string;
  shortLabel: string;
}> = [
  { id: 'cinematic', label: 'إضاءة: سينمائية', shortLabel: 'سينمائية' },
  { id: 'dark', label: 'إضاءة: مظلمة', shortLabel: 'مظلمة' },
  { id: 'ambient', label: 'إضاءة: خافتة', shortLabel: 'خافتة' },
  { id: 'bright', label: 'إضاءة: كاملة', shortLabel: 'كاملة' },
];

export const CINEMA_SCREEN_OPTIONS: Array<{
  id: CinemaScreenSize;
  label: string;
  shortLabel: string;
  scale: number;
  zOffset: number;
}> = [
  { id: 'classic', label: 'تكبير: قياسي', shortLabel: 'قياسي', scale: 0.78, zOffset: 0 },
  { id: 'imax', label: 'تكبير: IMAX', shortLabel: 'IMAX', scale: 1.0, zOffset: 0.2 },
  { id: 'giant', label: 'تكبير: عملاق +', shortLabel: 'عملاق+', scale: 1.32, zOffset: 1.4 },
];

export const ENVIRONMENT_OPTIONS: Array<{
  id: SceneEnvironmentId;
  hubLabel: string;
  cinemaLabel: string;
  shortLabel: string;
  accent: string;
}> = [
  {
    id: 'observatory',
    hubLabel: 'المرصد الفضائي',
    cinemaLabel: 'قاعة السينما',
    shortLabel: 'الكلاسيكي',
    accent: '#38BDF8',
  },
  {
    id: 'living_room',
    hubLabel: 'غرفة المعيشة',
    cinemaLabel: 'غرفة المعيشة',
    shortLabel: 'المعيشة',
    accent: '#F59E0B',
  },
  {
    id: 'beach',
    hubLabel: 'الشاطئ',
    cinemaLabel: 'الشاطئ',
    shortLabel: 'الشاطئ',
    accent: '#2DD4BF',
  },
  {
    id: 'moon',
    hubLabel: 'سطح القمر',
    cinemaLabel: 'سطح القمر',
    shortLabel: 'القمر',
    accent: '#94A3B8',
  },
  {
    id: 'bedroom',
    hubLabel: 'غرفة النوم',
    cinemaLabel: 'غرفة النوم',
    shortLabel: 'النوم',
    accent: '#A78BFA',
  },
];

export const VIDEO_360_SCENES: MediaSceneItem[] = [
  {
    id: '360-orbit',
    title: 'مدار الأرض والشفق القطبي 360°',
    subtitle: 'جولة بانورامية كاملة فوق الغلاف الجوي والنجوم',
    durationSeconds: 180,
    theme: 'space',
    accentColor: '#38BDF8',
  },
  {
    id: '360-ocean',
    title: 'أعماق الشعاب المرجانية 360°',
    subtitle: 'غوص افتراضي محيطي وسط أشعة الشمس والأسماك',
    durationSeconds: 150,
    theme: 'ocean',
    accentColor: '#2DD4BF',
  },
  {
    id: '360-desert',
    title: 'ليلة الصحراء ودرب التبانة 360°',
    subtitle: 'كثبان ذهبية تحت سماء صافية مرصعة بالنجوم',
    durationSeconds: 165,
    theme: 'desert',
    accentColor: '#F59E0B',
  },
  {
    id: '360-city',
    title: 'أفق مدينة المستقبل الليلي 360°',
    subtitle: 'منظر بانورامي من أعلى ناطحة سحاب زجاجية',
    durationSeconds: 140,
    theme: 'city',
    accentColor: '#60A5FA',
  },
];

export const CINEMA_MOVIES: MediaSceneItem[] = [
  {
    id: 'cine-nebula',
    title: 'رحلة عبر السديم الكوني',
    subtitle: 'فيلم وثائقي IMAX · 4K السينما الافتراضية',
    durationSeconds: 210,
    theme: 'space',
    accentColor: '#38BDF8',
  },
  {
    id: 'cine-reef',
    title: 'أسرار المحيط الأزرق',
    subtitle: 'تجربة طبيعة سينمائية · صوت محيطي',
    durationSeconds: 195,
    theme: 'ocean',
    accentColor: '#2DD4BF',
  },
  {
    id: 'cine-dunes',
    title: 'رمال الزمن الذهبية',
    subtitle: 'تصوير جوي سينمائي فوق الواحات والصحراء',
    durationSeconds: 175,
    theme: 'desert',
    accentColor: '#F59E0B',
  },
  {
    id: 'cine-horizon',
    title: 'أضواء الأفق الرقمي',
    subtitle: 'معرض العمارة الحضرية والتصميم المستقبلي',
    durationSeconds: 160,
    theme: 'city',
    accentColor: '#818CF8',
  },
];

export const CURATED_WEBSITES: CuratedWebsite[] = [
  {
    id: 'site-wiki-ar',
    label: 'ويكيبيديا العربية',
    domain: 'ar.wikipedia.org',
    url: 'https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%88%D8%A7%D9%82%D8%B9_%D8%A7%D9%84%D8%A7%D9%81%D8%AA%D8%B1%D8%A7%D8%B6%D9%8A',
    category: 'معرفة',
    accent: '#38BDF8',
  },
  {
    id: 'site-nasa',
    label: 'وكالة ناسا (NASA)',
    domain: 'nasa.gov',
    url: 'https://www.nasa.gov/',
    category: 'علوم وفضاء',
    accent: '#60A5FA',
  },
  {
    id: 'site-bbc-ar',
    label: 'BBC News عربي',
    domain: 'bbc.com/arabic',
    url: 'https://www.bbc.com/arabic',
    category: 'أخبار',
    accent: '#F87171',
  },
  {
    id: 'site-aljazeera',
    label: 'الجزيرة نت',
    domain: 'aljazeera.net',
    url: 'https://www.aljazeera.net/',
    category: 'أخبار',
    accent: '#F59E0B',
  },
  {
    id: 'site-google-ai',
    label: 'بحث جوجل: الذكاء الاصطناعي',
    domain: 'google.com',
    url: 'https://www.google.com/search?q=%D8%A7%D9%84%D8%B0%D9%83%D8%A7%D8%A1+%D8%A7%D9%84%D8%A7%D8%B5%D8%B7%D9%86%D8%A7%D8%B9%D9%8A',
    category: 'بحث مباشر',
    accent: '#34D399',
  },
  {
    id: 'site-github',
    label: 'GitHub Explore',
    domain: 'github.com',
    url: 'https://github.com/explore',
    category: 'تقنية',
    accent: '#A78BFA',
  },
  {
    id: 'site-wiki-en',
    label: 'Wikipedia English',
    domain: 'en.wikipedia.org',
    url: 'https://en.wikipedia.org/wiki/Virtual_reality',
    category: 'معرفة',
    accent: '#2DD4BF',
  },
  {
    id: 'site-space-ar',
    label: 'استكشاف الفضاء — ويكيبيديا',
    domain: 'ar.wikipedia.org',
    url: 'https://ar.wikipedia.org/wiki/%D8%A7%D8%B3%D8%AA%D9%83%D8%B4%D8%A7%D9%81_%D8%A7%D9%84%D9%81%D8%B6%D8%A7%D8%A1',
    category: 'علوم',
    accent: '#38BDF8',
  },
];

export const QUICK_BOOKMARKS = CURATED_WEBSITES.slice(0, 4).map((site) => ({
  id: site.id,
  label: site.label,
  query: site.url,
}));

export const DEFAULT_SAVED_BOOKMARKS: SavedBookmark[] = [
  {
    id: 'saved-wiki-ar',
    title: 'الواقع الافتراضي — ويكيبيديا',
    url: 'https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%88%D8%A7%D9%82%D8%B9_%D8%A7%D9%84%D8%A7%D9%81%D8%AA%D8%B1%D8%A7%D8%B6%D9%8A',
    domain: 'ar.wikipedia.org',
    savedAt: 'افتراضي',
  },
  {
    id: 'saved-space-ar',
    title: 'فضاء — ويكيبيديا الموسوعة الحرة',
    url: 'https://ar.wikipedia.org/wiki/%D9%81%D8%B6%D8%A7%D8%A1',
    domain: 'ar.wikipedia.org',
    savedAt: 'افتراضي',
  },
];

export const ARABIC_KEY_ROWS: string[][] = [
  ['ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح', 'ج'],
  ['ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك', 'ط'],
  ['ئ', 'ء', 'ؤ', 'ر', 'لا', 'ى', 'ة', 'و', 'ز', 'ظ', 'د'],
];

export const ENGLISH_KEY_ROWS: string[][] = [
  ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
  ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', '.'],
  ['z', 'x', 'c', 'v', 'b', 'n', 'm', '/', '-', '_'],
];

export const BOOKMARKS_STORAGE_KEY = 'nazar_vr_saved_bookmarks_v1';

export function loadSavedBookmarks(): SavedBookmark[] {
  if (typeof window === 'undefined' || !window.localStorage) {
    return DEFAULT_SAVED_BOOKMARKS;
  }
  try {
    const raw = window.localStorage.getItem(BOOKMARKS_STORAGE_KEY);
    if (!raw) return DEFAULT_SAVED_BOOKMARKS;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return DEFAULT_SAVED_BOOKMARKS;
  } catch {
    return DEFAULT_SAVED_BOOKMARKS;
  }
}

export function persistSavedBookmarks(bookmarks: SavedBookmark[]): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    window.localStorage.setItem(BOOKMARKS_STORAGE_KEY, JSON.stringify(bookmarks));
  } catch {
    // Ignore storage quota errors
  }
}

export function isBookmarkSaved(bookmarks: SavedBookmark[], url: string): boolean {
  return bookmarks.some((b) => b.url === url);
}

export function toggleBookmark(
  bookmarks: SavedBookmark[],
  candidate: { title: string; url: string }
): { nextBookmarks: SavedBookmark[]; saved: boolean } {
  const existing = bookmarks.find((b) => b.url === candidate.url);
  if (existing) {
    return {
      nextBookmarks: bookmarks.filter((b) => b.url !== candidate.url),
      saved: false,
    };
  }
  let domain = candidate.url;
  try {
    domain = new URL(candidate.url).hostname.replace(/^www\./, '');
  } catch {
    // fallback domain string
  }
  const newItem: SavedBookmark = {
    id: `bm-${Date.now()}`,
    title: candidate.title || domain,
    url: candidate.url,
    domain,
    savedAt: new Date().toLocaleDateString('ar-EG', { month: 'short', day: 'numeric' }),
  };
  return {
    nextBookmarks: [newItem, ...bookmarks].slice(0, 20),
    saved: true,
  };
}

export function createInitialBrowserState(
  initialBookmarks: SavedBookmark[] = loadSavedBookmarks()
): BrowserState {
  return {
    query: '',
    inputText: 'الواقع الافتراضي',
    view: 'home',
    results: [],
    currentPage: null,
    savedBookmarks: initialBookmarks,
    scrollOffset: 0,
    loading: false,
    keyboardLang: 'ar',
    history: [],
    hoveredSlot: null,
  };
}

export function getProjectionSpec(id: Video360Projection) {
  return PROJECTION_OPTIONS.find((p) => p.id === id) ?? PROJECTION_OPTIONS[0];
}

export function cycleTheaterLightMode(current: TheaterLightMode): TheaterLightMode {
  const idx = THEATER_LIGHT_OPTIONS.findIndex((o) => o.id === current);
  return THEATER_LIGHT_OPTIONS[(idx + 1) % THEATER_LIGHT_OPTIONS.length].id;
}

export function cycleCinemaScreenSize(current: CinemaScreenSize): CinemaScreenSize {
  const idx = CINEMA_SCREEN_OPTIONS.findIndex((o) => o.id === current);
  return CINEMA_SCREEN_OPTIONS[(idx + 1) % CINEMA_SCREEN_OPTIONS.length].id;
}

export function cycleSceneEnvironment(current: SceneEnvironmentId): SceneEnvironmentId {
  const idx = ENVIRONMENT_OPTIONS.findIndex((o) => o.id === current);
  return ENVIRONMENT_OPTIONS[(idx + 1) % ENVIRONMENT_OPTIONS.length].id;
}

export function resolveBrowserInput(raw: string):
  | { type: 'url'; url: string }
  | { type: 'search'; query: string } {
  const trimmed = raw.trim();
  if (/^https?:\/\/\S+/i.test(trimmed)) {
    return { type: 'url', url: trimmed };
  }
  if (
    !trimmed.includes(' ') &&
    /^[a-z0-9-]+(\.[a-z0-9-]+)+(\/\S*)?$/i.test(trimmed)
  ) {
    return { type: 'url', url: `https://${trimmed}` };
  }
  return { type: 'search', query: trimmed };
}

export function applyKeyboardKey(currentText: string, keyAction: string): string {
  if (keyAction === 'BACKSPACE') {
    const chars = Array.from(currentText);
    chars.pop();
    return chars.join('');
  }
  if (keyAction === 'CLEAR') {
    return '';
  }
  if (keyAction === 'SPACE') {
    return currentText.endsWith(' ') || currentText.length === 0
      ? currentText
      : `${currentText} `;
  }
  if (currentText.length >= 64) {
    return currentText;
  }
  return `${currentText}${keyAction}`;
}

export function cycleIndex(currentIndex: number, total: number, delta: number): number {
  if (total <= 0) return 0;
  return ((currentIndex + delta) % total + total) % total;
}

export function clampScrollOffset(offset: number, maxOffset: number): number {
  return Math.max(0, Math.min(Math.max(0, maxOffset), offset));
}

export function formatPlaybackTime(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

const VIDEO_EXTENSIONS = ['.mp4', '.webm', '.mkv', '.mov', '.m4v', '.avi', '.ogv'];
const IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.webp', '.avif', '.bmp', '.gif'];

export function isSupportedMediaFileName(
  fileName: string,
  mimeType?: string
): MediaFileKind | null {
  if (mimeType) {
    if (mimeType.startsWith('video/')) return 'video';
    if (mimeType.startsWith('image/')) return 'image';
  }
  const lower = fileName.toLowerCase();
  if (VIDEO_EXTENSIONS.some((ext) => lower.endsWith(ext))) return 'video';
  if (IMAGE_EXTENSIONS.some((ext) => lower.endsWith(ext))) return 'image';
  return null;
}

export function inferProjectionFromFilename(fileName: string): {
  target: '360' | 'cinema';
  projection: Video360Projection;
} {
  const lower = fileName.toLowerCase();
  const is180 = /(^|[^0-9])180([^0-9]|$)|vr180/.test(lower);
  const is360 = /(^|[^0-9])360([^0-9]|$)|equirect|pano/.test(lower);
  const isSbs = /(sbs|side.?by.?side|3d.?lr|lr|hsbs)/.test(lower);
  const isTb = /(tb|top.?bottom|over.?under|ou|3d.?tb)/.test(lower);

  if (is180 && isSbs) return { target: '360', projection: '180-sbs' };
  if (is180) return { target: '360', projection: '180-mono' };
  if (is360 && isSbs) return { target: '360', projection: '360-sbs' };
  if (is360 && isTb) return { target: '360', projection: '360-tb' };
  if (is360) return { target: '360', projection: '360-mono' };
  if (isSbs) return { target: '360', projection: '180-sbs' };
  if (isTb) return { target: '360', projection: '360-tb' };
  return { target: 'cinema', projection: '360-mono' };
}

export function filterGalleryItems(
  items: GalleryItem[],
  filter: GalleryFilter,
  folderFilter = 'all'
): GalleryItem[] {
  return items.filter((item) => {
    if (filter !== 'all' && item.kind !== filter) return false;
    if (folderFilter !== 'all' && (item.folderName || 'المعرض المحلي') !== folderFilter) {
      return false;
    }
    return true;
  });
}

export function extractGalleryFolders(
  items: GalleryItem[]
): Array<{ name: string; count: number }> {
  const counts = new Map<string, number>();
  for (const item of items) {
    const folder = item.folderName || 'المعرض المحلي';
    counts.set(folder, (counts.get(folder) ?? 0) + 1);
  }
  return Array.from(counts.entries()).map(([name, count]) => ({ name, count }));
}

export function getNextGalleryItem(
  items: GalleryItem[],
  currentUrl: string | null,
  delta = 1
): GalleryItem | null {
  if (items.length === 0) return null;
  const idx = currentUrl ? items.findIndex((i) => i.url === currentUrl) : -1;
  if (idx === -1) return items[0];
  const nextIdx = cycleIndex(idx, items.length, delta);
  return items[nextIdx] ?? items[0];
}

export function cycleGalleryFilter(current: GalleryFilter): GalleryFilter {
  if (current === 'all') return 'video';
  if (current === 'video') return 'image';
  return 'all';
}

export function formatFileSize(bytes?: number): string {
  if (!bytes || bytes <= 0) return 'مدمج';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

export function createBuiltinGalleryItems(): GalleryItem[] {
  const scenes360: GalleryItem[] = VIDEO_360_SCENES.map((s, idx) => ({
    id: `builtin-${s.id}`,
    name: s.title,
    kind: 'video',
    sourceType: 'builtin',
    url: `builtin:360:${idx}`,
    folderName: 'عروض 360° المدمجة',
    defaultTarget: '360',
    defaultProjection: '360-mono',
    builtinIndex: idx,
    accentColor: s.accentColor,
    addedAt: 'مدمج',
  }));

  const cinemaItems: GalleryItem[] = CINEMA_MOVIES.map((m, idx) => ({
    id: `builtin-${m.id}`,
    name: m.title,
    kind: 'video',
    sourceType: 'builtin',
    url: `builtin:cinema:${idx}`,
    folderName: 'أفلام السينما المدمجة',
    defaultTarget: 'cinema',
    defaultProjection: '360-mono',
    builtinIndex: idx,
    accentColor: m.accentColor,
    addedAt: 'مدمج',
  }));

  return [...scenes360, ...cinemaItems];
}

export const VOLUME_SLIDER_STEPS = [20, 40, 60, 80, 100] as const;

export function clampVolume(volume: number): number {
  if (!Number.isFinite(volume)) return 0.8;
  return Math.max(0, Math.min(1, Math.round(volume * 100) / 100));
}

export function stepVolume(current: number, delta: number): number {
  return clampVolume(current + delta);
}

export function formatVolumePercent(volume: number, muted: boolean): string {
  const pct = muted ? 0 : Math.round(clampVolume(volume) * 100);
  return `${pct}%`;
}

export function mapBrowserUvToGazeId(
  uvX: number,
  uvY: number,
  state: BrowserState
): { gazeId: string | null; slot: number | null } {
  if (state.loading) return { gazeId: null, slot: null };
  const x = uvX;
  const y = 1 - uvY;

  if (state.view === 'home') {
    const visibleCount = Math.min(4, Math.max(0, CURATED_WEBSITES.length - state.scrollOffset));
    const col = x >= 0.06 && x <= 0.486 ? 0 : x >= 0.514 && x <= 0.94 ? 1 : -1;
    const row = y >= 0.34 && y <= 0.562 ? 0 : y >= 0.596 && y <= 0.818 ? 1 : -1;
    if (col !== -1 && row !== -1) {
      const slot = row * 2 + col;
      if (slot < visibleCount) {
        return { gazeId: `browser:open-${slot + 1}`, slot };
      }
    }
    return { gazeId: null, slot: null };
  }

  if (state.view === 'results' || state.view === 'bookmarks') {
    const listLen =
      state.view === 'results' ? state.results.length : state.savedBookmarks.length;
    const visibleCount = Math.min(4, Math.max(0, listLen - state.scrollOffset));
    if (x < 0.038 || x > 0.962) return { gazeId: null, slot: null };
    for (let i = 0; i < visibleCount; i++) {
      const top = (182 + i * 165) / 875;
      const bottom = (182 + i * 165 + 146) / 875;
      if (y >= top && y <= bottom) {
        return { gazeId: `browser:open-${i + 1}`, slot: i };
      }
    }
    return { gazeId: null, slot: null };
  }

  if (state.view === 'article' && state.currentPage?.links?.length) {
    const linkCount = Math.min(4, state.currentPage.links.length);
    if (y >= 0.87 && y <= 0.97 && x >= 0.047 && x <= 0.953) {
      const relX = (x - 0.047) / (0.953 - 0.047);
      const slot = Math.min(linkCount - 1, Math.max(0, Math.floor(relX * linkCount)));
      return { gazeId: `browser:open-${slot + 1}`, slot };
    }
  }

  return { gazeId: null, slot: null };
}

export function mapGalleryUvToGazeId(
  uvX: number,
  uvY: number,
  state: GalleryViewState
): { gazeId: string | null; slot: number | null } {
  const filtered = filterGalleryItems(state.items, state.filter, state.folderFilter);
  const visibleCount = Math.min(4, Math.max(0, filtered.length - state.scrollOffset));
  if (visibleCount === 0) return { gazeId: null, slot: null };

  const x = uvX;
  const y = 1 - uvY;
  if (x < 0.034 || x > 0.966) return { gazeId: null, slot: null };

  for (let i = 0; i < visibleCount; i++) {
    const top = (138 + i * 172) / 875;
    const bottom = (138 + i * 172 + 152) / 875;
    if (y >= top && y <= bottom) {
      return { gazeId: `gallery:open-${i + 1}`, slot: i };
    }
  }

  return { gazeId: null, slot: null };
}
