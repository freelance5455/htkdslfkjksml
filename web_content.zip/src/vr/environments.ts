import * as THREE from 'three';
import { SceneEnvironmentId } from './vrState';

export interface EnvironmentController {
  root: THREE.Group;
  setEnvironment: (envId: SceneEnvironmentId, active: boolean) => void;
  update: (deltaSec: number, nowMs: number) => void;
  getBackgroundAndFog: (envId: SceneEnvironmentId) => {
    bgColor: number;
    fogColor: number;
    fogDensity: number;
  };
  dispose: () => void;
}

function createWoodTexture(maxAniso: number, baseHex: string, grainHex: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, 512, 512);

  for (let row = 0; row < 8; row++) {
    const y = row * 64;
    ctx.fillStyle = row % 2 === 0 ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.06)';
    ctx.fillRect(0, y, 512, 62);
    ctx.fillStyle = 'rgba(0,0,0,0.22)';
    ctx.fillRect(0, y + 62, 512, 2);

    ctx.strokeStyle = grainHex;
    ctx.lineWidth = 1.5;
    for (let g = 0; g < 10; g++) {
      ctx.beginPath();
      const gy = y + 6 + g * 5.5;
      ctx.moveTo(0, gy);
      ctx.bezierCurveTo(170, gy + ((g % 3) - 1) * 4, 340, gy - ((g % 2) * 3), 512, gy);
      ctx.stroke();
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(5, 5);
  tex.anisotropy = maxAniso;
  return tex;
}

function createSandTexture(maxAniso: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#d4b483';
  ctx.fillRect(0, 0, 512, 512);

  for (let y = 0; y < 512; y += 16) {
    ctx.strokeStyle = y % 32 === 0 ? 'rgba(180,136,80,0.34)' : 'rgba(255,236,198,0.22)';
    ctx.lineWidth = 4;
    ctx.beginPath();
    for (let x = 0; x <= 512; x += 32) {
      const py = y + Math.sin((x / 512) * Math.PI * 4) * 5;
      if (x === 0) ctx.moveTo(x, py);
      else ctx.lineTo(x, py);
    }
    ctx.stroke();
  }

  for (let i = 0; i < 450; i++) {
    ctx.fillStyle = i % 2 === 0 ? 'rgba(130,96,54,0.16)' : 'rgba(255,244,214,0.18)';
    ctx.fillRect((i * 73) % 512, (i * 137) % 512, 3, 3);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(14, 14);
  tex.anisotropy = maxAniso;
  return tex;
}

function createWaterTexture(maxAniso: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createLinearGradient(0, 0, 512, 512);
  grad.addColorStop(0, '#0c4a6e');
  grad.addColorStop(0.5, '#0369a1');
  grad.addColorStop(1, '#0e7490');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);

  for (let i = 0; i < 42; i++) {
    ctx.strokeStyle = i % 2 === 0 ? 'rgba(186,230,253,0.18)' : 'rgba(45,212,191,0.14)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    const y = (i / 42) * 512;
    for (let x = 0; x <= 512; x += 32) {
      const py = y + Math.sin((x / 512) * Math.PI * 6 + i) * 6;
      if (x === 0) ctx.moveTo(x, py);
      else ctx.lineTo(x, py);
    }
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(18, 18);
  tex.anisotropy = maxAniso;
  return tex;
}

function createLunarTextures(maxAniso: number): {
  colorMap: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const cCanvas = document.createElement('canvas');
  cCanvas.width = 512;
  cCanvas.height = 512;
  const cCtx = cCanvas.getContext('2d')!;
  cCtx.fillStyle = '#6f7682';
  cCtx.fillRect(0, 0, 512, 512);

  const bCanvas = document.createElement('canvas');
  bCanvas.width = 512;
  bCanvas.height = 512;
  const bCtx = bCanvas.getContext('2d')!;
  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, 512, 512);

  for (let i = 0; i < 36; i++) {
    const cx = ((i * 157 + 43) % 440) + 36;
    const cy = ((i * 211 + 89) % 440) + 36;
    const r = 10 + (i % 5) * 9;

    const cg = cCtx.createRadialGradient(cx, cy, r * 0.2, cx, cy, r);
    cg.addColorStop(0, '#4b525d');
    cg.addColorStop(0.72, '#5c6370');
    cg.addColorStop(0.88, '#8c94a3');
    cg.addColorStop(1, 'rgba(111,118,130,0)');
    cCtx.fillStyle = cg;
    cCtx.beginPath();
    cCtx.arc(cx, cy, r, 0, Math.PI * 2);
    cCtx.fill();

    const bg = bCtx.createRadialGradient(cx, cy, r * 0.15, cx, cy, r);
    bg.addColorStop(0, '#383838');
    bg.addColorStop(0.75, '#555555');
    bg.addColorStop(0.9, '#c8c8c8');
    bg.addColorStop(1, 'rgba(128,128,128,0)');
    bCtx.fillStyle = bg;
    bCtx.beginPath();
    bCtx.arc(cx, cy, r, 0, Math.PI * 2);
    bCtx.fill();
  }

  const colorMap = new THREE.CanvasTexture(cCanvas);
  colorMap.colorSpace = THREE.SRGBColorSpace;
  colorMap.wrapS = THREE.RepeatWrapping;
  colorMap.wrapT = THREE.RepeatWrapping;
  colorMap.repeat.set(12, 12);
  colorMap.anisotropy = maxAniso;

  const bumpMap = new THREE.CanvasTexture(bCanvas);
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.RepeatWrapping;
  bumpMap.repeat.set(12, 12);
  return { colorMap, bumpMap };
}

function createEarthTexture(maxAniso: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const sea = ctx.createLinearGradient(0, 0, 0, 256);
  sea.addColorStop(0, '#1e3a8a');
  sea.addColorStop(0.5, '#0284c7');
  sea.addColorStop(1, '#1e3a8a');
  ctx.fillStyle = sea;
  ctx.fillRect(0, 0, 512, 256);

  // Stylized continents
  ctx.fillStyle = '#22c55e';
  const blobs = [
    [130, 110, 48, 34],
    [170, 165, 28, 42],
    [290, 95, 58, 36],
    [310, 150, 32, 36],
    [400, 115, 54, 42],
    [430, 185, 26, 20],
  ];
  blobs.forEach(([x, y, rx, ry]) => {
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, 0.25, 0, Math.PI * 2);
    ctx.fill();
  });

  // Cloud wisps
  ctx.fillStyle = 'rgba(255,255,255,0.42)';
  for (let i = 0; i < 18; i++) {
    ctx.beginPath();
    ctx.ellipse((i * 67) % 512, 30 + ((i * 41) % 190), 34, 8, 0.1, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAniso;
  return tex;
}

function createSkyDomeTexture(topHex: string, midHex: string, horizonHex: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createLinearGradient(0, 0, 0, 256);
  grad.addColorStop(0, topHex);
  grad.addColorStop(0.45, midHex);
  grad.addColorStop(0.75, horizonHex);
  grad.addColorStop(1, horizonHex);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 256);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function buildCompositePalmTree(heightScale = 1): THREE.Group {
  const tree = new THREE.Group();
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x6b4423, roughness: 0.88, metalness: 0.05 });
  const frondMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.65, metalness: 0.05, side: THREE.DoubleSide });
  const coconutMat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.72 });

  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0, 0),
    new THREE.Vector3(0.25, 1.4, 0.12),
    new THREE.Vector3(0.55, 2.9, 0.25),
    new THREE.Vector3(0.72, 4.3, 0.3),
  ]);
  const trunkGeo = new THREE.TubeGeometry(curve, 14, 0.16, 8, false);
  const trunk = new THREE.Mesh(trunkGeo, trunkMat);
  tree.add(trunk);

  const topPos = new THREE.Vector3(0.72, 4.3, 0.3);
  for (let c = 0; c < 3; c++) {
    const a = (c / 3) * Math.PI * 2;
    const coco = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 8), coconutMat);
    coco.position.set(topPos.x + Math.cos(a) * 0.16, topPos.y - 0.14, topPos.z + Math.sin(a) * 0.16);
    tree.add(coco);
  }

  for (let f = 0; f < 7; f++) {
    const yaw = (f / 7) * Math.PI * 2;
    const frondGroup = new THREE.Group();
    frondGroup.position.copy(topPos);
    frondGroup.rotation.y = yaw;
    frondGroup.rotation.z = -0.35 - (f % 2) * 0.15;

    const leaf = new THREE.Mesh(new THREE.BoxGeometry(1.75, 0.03, 0.38), frondMat);
    leaf.position.set(0.88, 0.05, 0);
    frondGroup.add(leaf);

    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.6, 4), frondMat);
    tip.rotation.z = -Math.PI / 2;
    tip.position.set(1.95, -0.05, 0);
    tip.scale.set(1, 1, 0.3);
    frondGroup.add(tip);
    tree.add(frondGroup);
  }

  tree.scale.setScalar(heightScale);
  return tree;
}

function buildSculptedLamp(shadeColor: number, glowColor: number): THREE.Group {
  const lamp = new THREE.Group();
  const brassMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.25, metalness: 0.88 });
  const shadeMat = new THREE.MeshStandardMaterial({
    color: shadeColor,
    emissive: glowColor,
    emissiveIntensity: 0.65,
    roughness: 0.7,
    side: THREE.DoubleSide,
  });

  const pts = [
    new THREE.Vector2(0, 0),
    new THREE.Vector2(0.22, 0),
    new THREE.Vector2(0.2, 0.05),
    new THREE.Vector2(0.05, 0.1),
    new THREE.Vector2(0.035, 1.45),
    new THREE.Vector2(0.08, 1.5),
  ];
  const stand = new THREE.Mesh(new THREE.LatheGeometry(pts, 18), brassMat);
  lamp.add(stand);

  const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.32, 0.38, 20, 1, true), shadeMat);
  shade.position.y = 1.65;
  lamp.add(shade);

  const bulb = new THREE.Mesh(
    new THREE.SphereGeometry(0.07, 10, 8),
    new THREE.MeshBasicMaterial({ color: glowColor })
  );
  bulb.position.y = 1.6;
  lamp.add(bulb);
  return lamp;
}

export function buildEnvironmentController(
  renderer: THREE.WebGLRenderer,
  isSoftwareGl: boolean
): EnvironmentController {
  const root = new THREE.Group();
  const maxAniso = isSoftwareGl ? 1 : renderer.capabilities.getMaxAnisotropy();
  const texturesToDispose: THREE.Texture[] = [];

  const registerTex = <T extends THREE.Texture>(t: T): T => {
    texturesToDispose.push(t);
    return t;
  };

  // =========================================================================
  // 1. LIVING ROOM ENVIRONMENT (غرفة المعيشة)
  // =========================================================================
  const livingGroup = new THREE.Group();
  livingGroup.visible = false;
  root.add(livingGroup);

  const oakTex = registerTex(createWoodTexture(maxAniso, '#5c3d28', 'rgba(42,24,14,0.35)'));
  const lrFloorMat = new THREE.MeshStandardMaterial({ map: oakTex, color: 0xffffff, roughness: 0.52, metalness: 0.06 });
  const lrWallMat = new THREE.MeshStandardMaterial({ color: 0x1e2430, roughness: 0.85, metalness: 0.05 });
  const lrTrimMat = new THREE.MeshStandardMaterial({ color: 0x3b2a1e, roughness: 0.48, metalness: 0.15 });
  const lrSofaMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.86, metalness: 0.04 });
  const lrCushionMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.82, metalness: 0.04 });
  const lrRugMat = new THREE.MeshStandardMaterial({ color: 0x2a2438, roughness: 0.94, metalness: 0.02 });
  const lrGlassMat = new THREE.MeshStandardMaterial({
    color: 0xbae6fd,
    roughness: 0.12,
    metalness: 0.2,
    transparent: true,
    opacity: 0.42,
  });

  const lrWarmLight = new THREE.PointLight(0xffb86c, 4.5, 22, 1.4);
  lrWarmLight.position.set(-4.5, 2.8, -1.8);
  livingGroup.add(lrWarmLight);

  const lrFillLight = new THREE.HemisphereLight(0x93c5fd, 0x3f2e21, 0.72);
  livingGroup.add(lrFillLight);

  const lrFloor = new THREE.Mesh(new THREE.BoxGeometry(17, 0.2, 21), lrFloorMat);
  lrFloor.position.set(0, -0.1, -3.5);
  livingGroup.add(lrFloor);

  const lrCeiling = new THREE.Mesh(new THREE.BoxGeometry(17, 0.2, 21), lrWallMat);
  lrCeiling.position.set(0, 7.4, -3.5);
  livingGroup.add(lrCeiling);

  const lrRug = new THREE.Mesh(new THREE.BoxGeometry(7.2, 0.03, 5.6), lrRugMat);
  lrRug.position.set(0, 0.025, -2.5);
  livingGroup.add(lrRug);

  // Perimeter room walls (front wall at z=-14 sits behind the z=-11.2 Cinema screen)
  const lrBackWall = new THREE.Mesh(new THREE.BoxGeometry(17.2, 7.6, 0.3), lrWallMat);
  lrBackWall.position.set(0, 3.7, 7.0);
  const lrFrontWall = new THREE.Mesh(new THREE.BoxGeometry(17.2, 7.6, 0.3), lrWallMat);
  lrFrontWall.position.set(0, 3.7, -14.0);
  const lrLeftWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, 7.6, 21), lrWallMat);
  lrLeftWall.position.set(-8.5, 3.7, -3.5);
  const lrRightWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, 7.6, 21), lrWallMat);
  lrRightWall.position.set(8.5, 3.7, -3.5);
  livingGroup.add(lrBackWall, lrFrontWall, lrLeftWall, lrRightWall);

  // Decorative wood slats on front wall
  for (let i = -6; i <= 6; i++) {
    const slat = new THREE.Mesh(new THREE.BoxGeometry(0.14, 7.3, 0.1), lrTrimMat);
    slat.position.set(i * 1.15, 3.7, -13.8);
    livingGroup.add(slat);
  }

  // Composite Left Lounge Sofa (5-part)
  const buildSofa = (x: number, z: number, rotY: number) => {
    const sofa = new THREE.Group();
    const base = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.32, 1.05), lrTrimMat);
    base.position.y = 0.22;
    const seat = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.22, 0.96), lrSofaMat);
    seat.position.set(0, 0.46, 0.04);
    const back = new THREE.Mesh(new THREE.BoxGeometry(3.1, 0.72, 0.24), lrSofaMat);
    back.position.set(0, 0.82, -0.4);
    back.rotation.x = -0.12;
    const armL = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.56, 1.04), lrSofaMat);
    armL.position.set(-1.52, 0.56, 0);
    const armR = armL.clone();
    armR.position.x = 1.52;
    const pillow1 = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.36, 0.16), lrCushionMat);
    pillow1.position.set(-1.05, 0.72, -0.2);
    pillow1.rotation.z = 0.15;
    const pillow2 = pillow1.clone();
    pillow2.position.x = 1.05;
    pillow2.rotation.z = -0.15;
    sofa.add(base, seat, back, armL, armR, pillow1, pillow2);
    sofa.position.set(x, 0, z);
    sofa.rotation.y = rotY;
    return sofa;
  };
  livingGroup.add(buildSofa(-5.2, -1.6, Math.PI / 2));
  livingGroup.add(buildSofa(5.2, -1.6, -Math.PI / 2));

  // Glass & Walnut Side Coffee Table
  const coffeeTable = new THREE.Group();
  const tableTop = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.05, 0.8), lrGlassMat);
  tableTop.position.y = 0.46;
  const tableShelf = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.04, 0.65), lrTrimMat);
  tableShelf.position.y = 0.22;
  coffeeTable.add(tableTop, tableShelf);
  [
    [-0.6, -0.32],
    [0.6, -0.32],
    [-0.6, 0.32],
    [0.6, 0.32],
  ].forEach(([lx, lz]) => {
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.025, 0.46, 8), lrTrimMat);
    leg.position.set(lx, 0.23, lz);
    coffeeTable.add(leg);
  });
  const mug = new THREE.Mesh(
    new THREE.CylinderGeometry(0.055, 0.045, 0.11, 12),
    new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.25 })
  );
  mug.position.set(0.18, 0.54, 0.08);
  coffeeTable.add(mug);
  coffeeTable.position.set(-3.7, 0, -1.6);
  livingGroup.add(coffeeTable);

  // Standing Floor Lamps
  const lrLampL = buildSculptedLamp(0xfef3c7, 0xfbbf24);
  lrLampL.position.set(-5.6, 0, -4.1);
  const lrLampR = buildSculptedLamp(0xfef3c7, 0xfbbf24);
  lrLampR.position.set(5.6, 0, -4.1);
  livingGroup.add(lrLampL, lrLampR);

  // Panoramic Window on Right Wall overlooking city lights
  const windowFrame = new THREE.Mesh(new THREE.BoxGeometry(0.24, 2.8, 5.2), lrTrimMat);
  windowFrame.position.set(7.8, 2.6, -2.2);
  const windowGlass = new THREE.Mesh(
    new THREE.PlaneGeometry(5.0, 2.6),
    new THREE.MeshBasicMaterial({ color: 0x0f172a })
  );
  windowGlass.rotation.y = -Math.PI / 2;
  windowGlass.position.set(7.65, 2.6, -2.2);
  livingGroup.add(windowFrame, windowGlass);

  // Potted Indoor Plant (composite 6-part)
  const buildPlant = (px: number, pz: number) => {
    const plant = new THREE.Group();
    const pot = new THREE.Mesh(
      new THREE.CylinderGeometry(0.28, 0.2, 0.46, 16),
      new THREE.MeshStandardMaterial({ color: 0x9a3412, roughness: 0.78 })
    );
    pot.position.y = 0.23;
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x16a34a, roughness: 0.55 });
    plant.add(pot);
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const blade = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.95, 5), leafMat);
      blade.position.set(Math.cos(a) * 0.22, 0.82, Math.sin(a) * 0.22);
      blade.rotation.z = -Math.cos(a) * 0.42;
      blade.rotation.x = Math.sin(a) * 0.42;
      plant.add(blade);
    }
    plant.position.set(px, 0, pz);
    return plant;
  };
  livingGroup.add(buildPlant(-6.3, -6.2), buildPlant(6.3, -6.2));

  // =========================================================================
  // 2. TROPICAL BEACH ENVIRONMENT (الشاطئ)
  // =========================================================================
  const beachGroup = new THREE.Group();
  beachGroup.visible = false;
  root.add(beachGroup);

  const beachSkyTex = registerTex(createSkyDomeTexture('#0f172a', '#1e3a5f', '#f59e0b'));
  const beachSky = new THREE.Mesh(
    new THREE.SphereGeometry(62, 32, 20),
    new THREE.MeshBasicMaterial({ map: beachSkyTex, side: THREE.BackSide, fog: false })
  );
  beachGroup.add(beachSky);

  const beachSunLight = new THREE.DirectionalLight(0xffcf8b, 1.8);
  beachSunLight.position.set(-10, 12, -24);
  const beachHemi = new THREE.HemisphereLight(0x7dd3fc, 0xd4a373, 0.92);
  beachGroup.add(beachSunLight, beachHemi);

  // Sun disc near horizon
  const sunsetOrb = new THREE.Mesh(
    new THREE.SphereGeometry(2.6, 24, 16),
    new THREE.MeshBasicMaterial({ color: 0xfbbf24, fog: false })
  );
  sunsetOrb.position.set(-14, 7.5, -48);
  beachGroup.add(sunsetOrb);

  const sandTex = registerTex(createSandTexture(maxAniso));
  const sandMat = new THREE.MeshStandardMaterial({ map: sandTex, color: 0xffffff, roughness: 0.92, metalness: 0.02 });
  const sandBeach = new THREE.Mesh(new THREE.CylinderGeometry(36, 38, 0.4, 48), sandMat);
  sandBeach.position.set(0, -0.22, 16);
  beachGroup.add(sandBeach);

  const waterTex = registerTex(createWaterTexture(maxAniso));
  const waterMat = new THREE.MeshStandardMaterial({
    map: waterTex,
    color: 0xffffff,
    roughness: 0.16,
    metalness: 0.45,
  });
  const oceanPlane = new THREE.Mesh(new THREE.PlaneGeometry(140, 110), waterMat);
  oceanPlane.rotation.x = -Math.PI / 2;
  oceanPlane.position.set(0, -0.08, -34);
  beachGroup.add(oceanPlane);

  // Wooden Pier Deck under viewer
  const pierWoodTex = registerTex(createWoodTexture(maxAniso, '#7c5334', 'rgba(40,22,10,0.4)'));
  const pierMat = new THREE.MeshStandardMaterial({ map: pierWoodTex, color: 0xffffff, roughness: 0.72 });
  const pierDeck = new THREE.Mesh(new THREE.BoxGeometry(5.6, 0.16, 8.5), pierMat);
  pierDeck.position.set(0, 0.02, -2.0);
  beachGroup.add(pierDeck);

  [-2.6, 2.6].forEach((px) => {
    for (let pz = -5.5; pz <= 1.5; pz += 2.3) {
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.11, 1.1, 10), pierMat);
      post.position.set(px, 0.45, pz);
      beachGroup.add(post);
    }
  });

  // Palm trees & coastal rocks framing the flanks cleanly
  const palmPositions: Array<[number, number, number, number]> = [
    [-7.1, -4.4, 0.96, 0.45],
    [7.2, -4.6, 1.05, -0.55],
    [-8.8, 2.2, 1.12, 1.2],
    [8.6, 1.8, 0.94, -1.1],
  ];
  palmPositions.forEach(([x, z, s, ry]) => {
    const palm = buildCompositePalmTree(s);
    palm.position.set(x, -0.02, z);
    palm.rotation.y = ry;
    beachGroup.add(palm);
  });

  const rockMat = new THREE.MeshStandardMaterial({ color: 0x57534e, roughness: 0.9 });
  [
    [-7.8, -6.5, 1.1],
    [-9.2, -5.8, 0.7],
    [7.9, -6.8, 1.25],
    [9.4, -5.9, 0.8],
  ].forEach(([rx, rz, rs]) => {
    const rock = new THREE.Mesh(new THREE.IcosahedronGeometry(rs, 1), rockMat);
    rock.scale.set(1.4, 0.72, 1.1);
    rock.position.set(rx, rs * 0.3, rz);
    beachGroup.add(rock);
  });

  // Beach Tiki Torches with warm glow
  const tikiFlames: THREE.Mesh[] = [];
  [-3.2, 3.2].forEach((tx) => {
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 1.75, 8), pierMat);
    pole.position.set(tx, 0.88, -5.4);
    const cup = new THREE.Mesh(
      new THREE.CylinderGeometry(0.12, 0.07, 0.22, 10),
      new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.5, metalness: 0.4 })
    );
    cup.position.set(tx, 1.78, -5.4);
    const flame = new THREE.Mesh(
      new THREE.ConeGeometry(0.09, 0.24, 8),
      new THREE.MeshBasicMaterial({ color: 0xfbbf24 })
    );
    flame.position.set(tx, 1.98, -5.4);
    tikiFlames.push(flame);
    beachGroup.add(pole, cup, flame);
  });

  // =========================================================================
  // 3. LUNAR SURFACE ENVIRONMENT (القمر)
  // =========================================================================
  const moonGroup = new THREE.Group();
  moonGroup.visible = false;
  root.add(moonGroup);

  const moonSun = new THREE.DirectionalLight(0xf8fafc, 2.1);
  moonSun.position.set(14, 18, -10);
  const moonHemi = new THREE.HemisphereLight(0x94a3b8, 0x0f172a, 0.45);
  moonGroup.add(moonSun, moonHemi);

  // Starfield sky for Moon
  const moonStarCount = isSoftwareGl ? 420 : 1000;
  const moonStarPos = new Float32Array(moonStarCount * 3);
  for (let i = 0; i < moonStarCount; i++) {
    const th = (i * 2.39996) % (Math.PI * 2);
    const ph = Math.acos(0.08 + ((i * 0.61803) % 0.9));
    const r = 42 + (i % 9) * 1.8;
    moonStarPos[i * 3] = r * Math.sin(ph) * Math.cos(th);
    moonStarPos[i * 3 + 1] = r * Math.cos(ph);
    moonStarPos[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
  }
  const moonStarGeo = new THREE.BufferGeometry();
  moonStarGeo.setAttribute('position', new THREE.BufferAttribute(moonStarPos, 3));
  moonGroup.add(
    new THREE.Points(
      moonStarGeo,
      new THREE.PointsMaterial({ color: 0xffffff, size: 0.16, fog: false })
    )
  );

  // Earthrise Sphere positioned clearly in upper-left sky above the Cinema screen
  const earthTex = registerTex(createEarthTexture(maxAniso));
  const earthMesh = new THREE.Mesh(
    new THREE.SphereGeometry(3.8, 32, 24),
    new THREE.MeshStandardMaterial({ map: earthTex, color: 0xffffff, roughness: 0.65, metalness: 0.08 })
  );
  earthMesh.position.set(-8.6, 11.4, -26);
  moonGroup.add(earthMesh);

  const lunarTex = createLunarTextures(maxAniso);
  registerTex(lunarTex.colorMap);
  registerTex(lunarTex.bumpMap);
  const lunarGroundMat = new THREE.MeshStandardMaterial({
    map: lunarTex.colorMap,
    bumpMap: lunarTex.bumpMap,
    bumpScale: 0.22,
    color: 0xffffff,
    roughness: 0.94,
    metalness: 0.04,
  });
  const lunarGround = new THREE.Mesh(new THREE.CylinderGeometry(64, 64, 0.4, 48), lunarGroundMat);
  lunarGround.position.set(0, -0.2, 0);
  moonGroup.add(lunarGround);

  // Sculpted 3D Lunar Craters
  [
    [-8.5, -8.5, 2.6],
    [9.2, -9.5, 3.1],
    [-12, 3.5, 2.2],
    [11.5, 4.5, 2.8],
  ].forEach(([cx, cz, cr]) => {
    const rim = new THREE.Mesh(new THREE.TorusGeometry(cr, cr * 0.14, 10, 28), lunarGroundMat);
    rim.rotation.x = Math.PI / 2;
    rim.position.set(cx, 0.06, cz);
    moonGroup.add(rim);
  });

  // Composite Lunar Lander Outpost (7-part) on the left flank
  const lander = new THREE.Group();
  const goldFoil = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.28, metalness: 0.85 });
  const titanMat = new THREE.MeshStandardMaterial({ color: 0xcbd5e1, roughness: 0.35, metalness: 0.78 });
  const descentStage = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1.05, 0.72, 8), goldFoil);
  descentStage.position.y = 0.78;
  const ascentCabin = new THREE.Mesh(new THREE.CylinderGeometry(0.68, 0.82, 0.74, 8), titanMat);
  ascentCabin.position.y = 1.5;
  const dish = new THREE.Mesh(new THREE.ConeGeometry(0.32, 0.18, 12, 1, true), titanMat);
  dish.position.set(0.35, 2.05, 0.1);
  dish.rotation.x = -0.5;
  lander.add(descentStage, ascentCabin, dish);
  for (let l = 0; l < 4; l++) {
    const ang = (l / 4) * Math.PI * 2 + Math.PI / 4;
    const strut = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.15, 8), titanMat);
    strut.position.set(Math.cos(ang) * 1.05, 0.45, Math.sin(ang) * 1.05);
    strut.rotation.z = Math.cos(ang) * 0.45;
    strut.rotation.x = -Math.sin(ang) * 0.45;
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.24, 0.05, 10), titanMat);
    pad.position.set(Math.cos(ang) * 1.35, 0.03, Math.sin(ang) * 1.35);
    lander.add(strut, pad);
  }
  lander.position.set(-6.5, 0, -5.8);
  moonGroup.add(lander);

  // Lunar Observation Pad beneath viewer
  const moonPad = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.7, 0.08, 32), titanMat);
  moonPad.position.y = 0.02;
  moonGroup.add(moonPad);

  // =========================================================================
  // 4. COZY BEDROOM ENVIRONMENT (غرفة النوم)
  // =========================================================================
  const bedroomGroup = new THREE.Group();
  bedroomGroup.visible = false;
  root.add(bedroomGroup);

  const brWarmLight = new THREE.PointLight(0xfde68a, 3.6, 18, 1.5);
  brWarmLight.position.set(0, 3.2, -1.0);
  const brHemi = new THREE.HemisphereLight(0x818cf8, 0x1e1b4b, 0.55);
  bedroomGroup.add(brWarmLight, brHemi);

  const brFloorMat = new THREE.MeshStandardMaterial({
    map: registerTex(createWoodTexture(maxAniso, '#3e2723', 'rgba(20,10,6,0.4)')),
    color: 0xffffff,
    roughness: 0.62,
  });
  const brWallMat = new THREE.MeshStandardMaterial({ color: 0x1a1c2c, roughness: 0.88 });
  const brSheetMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.88 });
  const brDuvetMat = new THREE.MeshStandardMaterial({ color: 0x4c1d95, roughness: 0.85 });
  const brHeadboardMat = new THREE.MeshStandardMaterial({ color: 0x312e81, roughness: 0.78 });

  const brFloor = new THREE.Mesh(new THREE.BoxGeometry(16, 0.2, 21), brFloorMat);
  brFloor.position.set(0, -0.1, -3.5);
  const brCeiling = new THREE.Mesh(new THREE.BoxGeometry(16, 0.2, 21), brWallMat);
  brCeiling.position.set(0, 7.4, -3.5);
  const brRug = new THREE.Mesh(
    new THREE.BoxGeometry(6.6, 0.03, 5.4),
    new THREE.MeshStandardMaterial({ color: 0x312e81, roughness: 0.95 })
  );
  brRug.position.set(0, 0.025, -2.2);
  bedroomGroup.add(brFloor, brCeiling, brRug);

  const brBackWall = new THREE.Mesh(new THREE.BoxGeometry(16.2, 7.6, 0.3), brWallMat);
  brBackWall.position.set(0, 3.7, 7.0);
  const brFrontWall = new THREE.Mesh(new THREE.BoxGeometry(16.2, 7.6, 0.3), brWallMat);
  brFrontWall.position.set(0, 3.7, -14.0);
  const brLeftWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, 7.6, 21), brWallMat);
  brLeftWall.position.set(-8, 3.7, -3.5);
  const brRightWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, 7.6, 21), brWallMat);
  brRightWall.position.set(8, 3.7, -3.5);
  bedroomGroup.add(brBackWall, brFrontWall, brLeftWall, brRightWall);

  // Composite Queen Bed placed on Left flank (facing room center)
  const bed = new THREE.Group();
  const bedFrame = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.28, 2.2), lrTrimMat);
  bedFrame.position.y = 0.22;
  const mattress = new THREE.Mesh(new THREE.BoxGeometry(2.34, 0.26, 2.04), brSheetMat);
  mattress.position.y = 0.48;
  const duvet = new THREE.Mesh(new THREE.BoxGeometry(2.38, 0.2, 1.35), brDuvetMat);
  duvet.position.set(0, 0.54, 0.34);
  const headboard = new THREE.Mesh(new THREE.BoxGeometry(2.58, 1.35, 0.18), brHeadboardMat);
  headboard.position.set(0, 0.85, -1.04);
  const pillowL = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.16, 0.48), brSheetMat);
  pillowL.position.set(-0.54, 0.66, -0.68);
  const pillowR = pillowL.clone();
  pillowR.position.x = 0.54;
  bed.add(bedFrame, mattress, duvet, headboard, pillowL, pillowR);
  bed.rotation.y = Math.PI / 2;
  bed.position.set(-5.8, 0, -1.2);
  bedroomGroup.add(bed);

  // Nightstands + Bedside Lamps
  [-2.9, 0.5].forEach((nz) => {
    const stand = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.56, 0.55), lrTrimMat);
    stand.position.set(-6.9, 0.28, nz);
    const lamp = buildSculptedLamp(0xe9d5ff, 0xfbbf24);
    lamp.scale.setScalar(0.45);
    lamp.position.set(-6.9, 0.56, nz);
    bedroomGroup.add(stand, lamp);
  });

  // LED cove accent strip along upper wall & cozy reading chair on Right
  const ledStrip = new THREE.Mesh(
    new THREE.BoxGeometry(12.2, 0.08, 0.08),
    new THREE.MeshBasicMaterial({ color: 0xa78bfa })
  );
  ledStrip.position.set(0, 6.8, -13.78);
  bedroomGroup.add(ledStrip);

  const brChair = buildSofa(5.9, -1.4, -Math.PI / 2);
  brChair.scale.set(0.65, 0.95, 0.9);
  bedroomGroup.add(brChair);

  const envGroups: Record<SceneEnvironmentId, THREE.Group | null> = {
    observatory: null,
    living_room: livingGroup,
    beach: beachGroup,
    moon: moonGroup,
    bedroom: bedroomGroup,
  };

  const setEnvironment = (envId: SceneEnvironmentId, active: boolean) => {
    (Object.keys(envGroups) as SceneEnvironmentId[]).forEach((k) => {
      const grp = envGroups[k];
      if (grp) {
        grp.visible = active && k === envId;
      }
    });
  };

  const getBackgroundAndFog = (envId: SceneEnvironmentId) => {
    switch (envId) {
      case 'living_room':
        return { bgColor: 0x0f121b, fogColor: 0x0f121b, fogDensity: 0.018 };
      case 'beach':
        return { bgColor: 0x152c44, fogColor: 0x152c44, fogDensity: 0.013 };
      case 'moon':
        return { bgColor: 0x03050a, fogColor: 0x03050a, fogDensity: 0.008 };
      case 'bedroom':
        return { bgColor: 0x0b0a16, fogColor: 0x0b0a16, fogDensity: 0.018 };
      default:
        return { bgColor: 0x070b12, fogColor: 0x070b12, fogDensity: 0.025 };
    }
  };

  const update = (deltaSec: number, nowMs: number) => {
    if (beachGroup.visible) {
      waterTex.offset.x = (waterTex.offset.x + deltaSec * 0.025) % 1;
      waterTex.offset.y = (waterTex.offset.y + deltaSec * 0.015) % 1;
      tikiFlames.forEach((f, idx) => {
        const s = 0.9 + Math.sin(nowMs * 0.012 + idx * 2.1) * 0.16;
        f.scale.set(1, s, 1);
      });
    }
    if (moonGroup.visible) {
      earthMesh.rotation.y += deltaSec * 0.04;
    }
  };

  const dispose = () => {
    texturesToDispose.forEach((t) => t.dispose());
    root.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh || (obj as THREE.Points).isPoints) {
        const m = obj as THREE.Mesh;
        m.geometry?.dispose();
        if (Array.isArray(m.material)) {
          m.material.forEach((mat) => mat.dispose());
        } else {
          m.material?.dispose();
        }
      }
    });
  };

  return {
    root,
    setEnvironment,
    update,
    getBackgroundAndFog,
    dispose,
  };
}
