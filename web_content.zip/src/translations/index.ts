import { AppLanguage } from '../types';

export interface Translations {
  appName: string;
  tagline: string;
  subtitle: string;
  searchPlaceholder: string;
  exploreNow: string;
  browseAllBooks: string;
  viewAll: string;
  viewDetails: string;
  addToCart: string;
  buyNow: string;
  readNow: string;
  downloadPdf: string;
  downloadHtml: string;
  samplePreview: string;
  price: string;
  free: string;
  off: string;
  bestseller: string;
  newArrival: string;
  featured: string;
  pages: string;
  language: string;
  format: string;
  tableOfContents: string;
  whatIsIncluded: string;
  customerReviews: string;
  home: string;
  categories: string;
  myBooks: string;
  cart: string;
  profile: string;
  purchased: string;
  downloads: string;
  readingHistory: string;
  wishlist: string;
  checkout: string;
  emptyCart: string;
  emptyCartDesc: string;
  continueShopping: string;
  orderSummary: string;
  subtotal: string;
  discount: string;
  totalPayable: string;
  applyCoupon: string;
  enterCoupon: string;
  proceedToCheckout: string;
  mockTests: string;
  currentAffairs: string;
  examUpdates: string;
  comboOffers: string;
  assamSpecial: string;
  adminPanel: string;
  helpSupport: string;
  demoNotice: string;
  verifiedOfficialSources: string;
  lastUpdated: string;
}

export const translations: Record<AppLanguage, Translations> = {
  en: {
    appName: 'NEXA EXAM BOOKS',
    tagline: 'Your Success, Our Mission',
    subtitle: 'Best Study Material for Government Exams',
    searchPlaceholder: 'Search for exams, books, topics (e.g. Railway, Assam Police, ADRE, SSC)...',
    exploreNow: 'Explore Now',
    browseAllBooks: 'Browse All Books',
    viewAll: 'View All',
    viewDetails: 'View Details',
    addToCart: 'Add to Cart',
    buyNow: 'Buy Now',
    readNow: 'Read Now',
    downloadPdf: 'Download PDF',
    downloadHtml: 'Download Offline HTML',
    samplePreview: 'Sample Preview',
    price: 'Price',
    free: 'FREE',
    off: 'OFF',
    bestseller: 'BESTSELLER',
    newArrival: 'NEW ARRIVAL',
    featured: 'FEATURED',
    pages: 'Pages',
    language: 'Language',
    format: 'Format',
    tableOfContents: 'Table of Contents',
    whatIsIncluded: "What's Included",
    customerReviews: 'Student Reviews',
    home: 'Home',
    categories: 'Categories',
    myBooks: 'My Books',
    cart: 'Cart',
    profile: 'Profile',
    purchased: 'Purchased Books',
    downloads: 'Downloads',
    readingHistory: 'Reading History',
    wishlist: 'Wishlist',
    checkout: 'Checkout',
    emptyCart: 'Your Cart is Empty',
    emptyCartDesc: 'Explore our top exam preparation books and unlock your career goals.',
    continueShopping: 'Continue Shopping',
    orderSummary: 'Order Summary',
    subtotal: 'Subtotal',
    discount: 'Discount',
    totalPayable: 'Total Payable',
    applyCoupon: 'Apply',
    enterCoupon: 'Enter promo code',
    proceedToCheckout: 'Proceed to Checkout',
    mockTests: 'Mock Tests Hub',
    currentAffairs: 'Current Affairs',
    examUpdates: 'Official Exam Updates',
    comboOffers: 'Super Saver Combos',
    assamSpecial: 'Assam Exams Special',
    adminPanel: 'Admin Panel',
    helpSupport: 'Help & Support',
    demoNotice: 'Demo Mode: Payments & live database are configured for testing preview.',
    verifiedOfficialSources: 'Verified Official Govt Notification Sources',
    lastUpdated: 'Last Updated',
  },
  hi: {
    appName: 'नेक्सा एग्जाम बुक्स',
    tagline: 'आपकी सफलता, हमारा संकल्प',
    subtitle: 'सरकारी परीक्षाओं के लिए सर्वश्रेष्ठ अध्ययन सामग्री',
    searchPlaceholder: 'परीक्षाएं, पुस्तकें, विषय खोजें (उदा. रेलवे, पुलिस, एसएससी)...',
    exploreNow: 'अभी देखें',
    browseAllBooks: 'सभी पुस्तकें देखें',
    viewAll: 'सभी देखें',
    viewDetails: 'विवरण देखें',
    addToCart: 'कार्ट में जोड़ें',
    buyNow: 'अभी खरीदें',
    readNow: 'अभी पढ़ें',
    downloadPdf: 'पीडीएफ डाउनलोड करें',
    downloadHtml: 'ऑफ़लाइन HTML डाउनलोड करें',
    samplePreview: 'सैंपल देखें',
    price: 'मूल्य',
    free: 'निःशुल्क',
    off: 'छूट',
    bestseller: 'बेस्टसेलर',
    newArrival: 'नया संग्रह',
    featured: 'प्रमुख',
    pages: 'पृष्ठ',
    language: 'भाषा',
    format: 'प्रारूप',
    tableOfContents: 'अनुक्रमणिका',
    whatIsIncluded: 'इस ईबुक में क्या शामिल है',
    customerReviews: 'छात्र समीक्षाएं',
    home: 'होम',
    categories: 'श्रेणियां',
    myBooks: 'मेरी पुस्तकें',
    cart: 'कार्ट',
    profile: 'प्रोफाइल',
    purchased: 'खरीदी गई पुस्तकें',
    downloads: 'डाउनलोड',
    readingHistory: 'पठन इतिहास',
    wishlist: 'इच्छा सूची',
    checkout: 'चेकआउट',
    emptyCart: 'आपकी कार्ट खाली है',
    emptyCartDesc: 'परीक्षा अध्ययन सामग्री खोजें और अपनी तैयारी मजबूत करें।',
    continueShopping: 'खरीदारी जारी रखें',
    orderSummary: 'ऑर्डर सारांश',
    subtotal: 'उप-योग',
    discount: 'छूट',
    totalPayable: 'कुल देय राशि',
    applyCoupon: 'लागू करें',
    enterCoupon: 'कूपन कोड डालें',
    proceedToCheckout: 'भुगतान के लिए आगे बढ़ें',
    mockTests: 'मॉक टेस्ट हब',
    currentAffairs: 'करेंट अफेयर्स',
    examUpdates: 'सरकारी परीक्षा अपडेट',
    comboOffers: 'कॉम्बो ऑफर्स',
    assamSpecial: 'असम विशेष परीक्षाएं',
    adminPanel: 'एडमिन पैनल',
    helpSupport: 'सहायता एवं संपर्क',
    demoNotice: 'डेमो मोड: भुगतान प्रणाली परीक्षण पूर्वावलोकन के लिए सक्रिय है।',
    verifiedOfficialSources: 'सत्यापित आधिकारिक सरकारी सूचना स्रोत',
    lastUpdated: 'अंतिम अद्यतन',
  },
  as: {
    appName: 'নেক্সা এক্সাম বুক্স',
    tagline: 'আপোনাৰ সফলতা, আমাৰ লক্ষ্য',
    subtitle: 'চৰকাৰী পৰীক্ষাৰ বাবে সৰ্বশ্ৰেষ্ঠ অধ্যয়ন সামগ্ৰী',
    searchPlaceholder: 'পৰীক্ষা, কিতাপ বা বিষয় সন্ধান কৰক (যেনে ADRE, অসম আৰক্ষী, ৰে’লৱে)...',
    exploreNow: 'এতিয়াই অন্বেষণ কৰক',
    browseAllBooks: 'সকলো কিতাপ চাওক',
    viewAll: 'সকলো চাওক',
    viewDetails: 'বিৱৰণ চাওক',
    addToCart: 'কাৰ্টত যোগ কৰক',
    buyNow: 'এতিয়াই কিনক',
    readNow: 'এতিয়াই পঢ়ক',
    downloadPdf: 'PDF ডাউনলোড কৰক',
    downloadHtml: 'অফলাইন HTML সংগ্ৰহ কৰক',
    samplePreview: 'নমুনা পৃষ্ঠা চাওক',
    price: 'মূল্য',
    free: 'বিনামূলীয়া',
    off: 'ৰেহাই',
    bestseller: 'বেষ্টচেলাৰ',
    newArrival: 'নতুন কিতাপ',
    featured: 'বিশেষ',
    pages: 'পৃষ্ঠা',
    language: 'ভাষা',
    format: 'ফৰ্মেট',
    tableOfContents: 'সূচীপত্ৰ',
    whatIsIncluded: 'এই কিতাপখনত কি কি আছে',
    customerReviews: 'শিক্ষাৰ্থীৰ মতামত',
    home: 'মূল পৃষ্ঠা',
    categories: 'শ্ৰেণীসমূহ',
    myBooks: 'মোৰ কিতাপ',
    cart: 'কাৰ্ট',
    profile: 'প্ৰফাইল',
    purchased: 'ক্ৰয় কৰা কিতাপ',
    downloads: 'ডাউনলোডসমূহ',
    readingHistory: 'পঢ়া ইতিহাস',
    wishlist: 'পছন্দৰ তালিকা',
    checkout: 'চেকআউট',
    emptyCart: 'আপোনাৰ কাৰ্ট খালী আছে',
    emptyCartDesc: 'উন্নত পৰীক্ষা প্ৰস্তুতিৰ বাবে আমাৰ জনপ্ৰিয় কিতাপসমূহ চাওক।',
    continueShopping: 'অধ্যয়ন সামগ্ৰী চাওক',
    orderSummary: 'অৰ্ডাৰৰ বিৱৰণ',
    subtotal: 'মুঠ ধন',
    discount: 'বিশেষ ৰেহাই',
    totalPayable: 'পৰিশোধ কৰিবলগীয়া মুঠ',
    applyCoupon: 'প্ৰয়োগ কৰক',
    enterCoupon: 'কুপন ক’ড দিয়ক',
    proceedToCheckout: 'পেমেন্টলৈ যাওক',
    mockTests: 'মক টেষ্ট বিভাগ',
    currentAffairs: 'সাম্প্ৰতিক বিষয়',
    examUpdates: 'চৰকাৰী পৰীক্ষাৰ জাননী',
    comboOffers: 'কম্বো পেক',
    assamSpecial: 'অসম চৰকাৰী পৰীক্ষা বিশেষ',
    adminPanel: 'এডমিন পেনেল',
    helpSupport: 'সহায় আৰু যোগাযোগ',
    demoNotice: 'ডেম’ মোড: পৰীক্ষাৰ্থীৰ বাবে প্ৰিভিউ সংস্কৰণ সক্ৰিয় হৈ আছে।',
    verifiedOfficialSources: 'চৰকাৰী অফিচিয়েল উৎসসমূহ',
    lastUpdated: 'শেহতীয়া আপডেট',
  },
  bn: {
    appName: 'নেক্সা এক্সাম বুক্স',
    tagline: 'আপনার সাফল্য, আমাদের লক্ষ্য',
    subtitle: 'সরকারি চাকরির পরীক্ষার সেরা স্টাডি ম্যাটেরিয়াল',
    searchPlaceholder: 'পরীক্ষা, বই বা বিষয় অনুসন্ধান করুন (রেলওয়ে, পুলিশ, এসএসসি)...',
    exploreNow: 'এখনই দেখুন',
    browseAllBooks: 'সব বই দেখুন',
    viewAll: 'সব দেখুন',
    viewDetails: 'বিস্তারিত দেখুন',
    addToCart: 'কার্টে যোগ করুন',
    buyNow: 'এখনই কিনুন',
    readNow: 'এখনই পড়ুন',
    downloadPdf: 'PDF ডাউনলোড করুন',
    downloadHtml: 'অফলাইন HTML ডাউনলোড',
    samplePreview: 'নমুনা দেখুন',
    price: 'মূল্য',
    free: 'বিনামূল্যে',
    off: 'ছাড়',
    bestseller: 'বেস্টসেলার',
    newArrival: 'নতুন প্রকাশনা',
    featured: 'বিশেষ নির্বাচিত',
    pages: 'পৃষ্ঠা',
    language: 'ভাষা',
    format: 'ফরম্যাট',
    tableOfContents: 'সূচিপত্র',
    whatIsIncluded: 'এই ই-বুকে যা পাবেন',
    customerReviews: 'শিক্ষার্থীদের পর্যালোচনা',
    home: 'হোম',
    categories: 'ক্যাটেগরি',
    myBooks: 'আমার বই',
    cart: 'কার্ট',
    profile: 'প্রোফাইল',
    purchased: 'কেনা বইসমূহ',
    downloads: 'ডাউনলোড',
    readingHistory: 'পড়ার ইতিহাস',
    wishlist: 'পছন্দের তালিকা',
    checkout: 'চেকআউট',
    emptyCart: 'আপনার কার্ট খালি আছে',
    emptyCartDesc: 'চাকরির পরীক্ষার প্রস্তুতি নিতে বই নির্বাচন করুন।',
    continueShopping: 'কেনাকাটা চালিয়ে যান',
    orderSummary: 'অর্ডারের বিবরণ',
    subtotal: 'মোট দাম',
    discount: 'বিশেষ ছাড়',
    totalPayable: 'প্রদেয় মূল্য',
    applyCoupon: 'প্রয়োগ করুন',
    enterCoupon: 'কুপন কোড দিন',
    proceedToCheckout: 'পেমেন্টে এগিয়ে যান',
    mockTests: 'মক টেস্ট হাব',
    currentAffairs: 'কারেন্ট অ্যাফেয়ার্স',
    examUpdates: 'সরকারি পরীক্ষার বিজ্ঞপ্তি',
    comboOffers: 'কম্বো অফার',
    assamSpecial: 'আসাম স্পেশাল প্রস্তুতি',
    adminPanel: 'অ্যাডমিন প্যানেল',
    helpSupport: 'সহায়তা ও যোগাযোগ',
    demoNotice: 'ডেমো মোড: পেমেন্ট এবং ডাটাবেজ প্রিভিউ মোডে সক্রিয় রয়েছে।',
    verifiedOfficialSources: 'যাচাইকৃত সরকারি অফিসিয়াল সূত্র',
    lastUpdated: 'সর্বশেষ আপডেট',
  },
};
