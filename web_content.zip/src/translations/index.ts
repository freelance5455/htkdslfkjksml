import { Language } from '../types';

export interface Translations {
  appName: string;
  appSubtitle: string;
  ownerOnly: string;
  adminLogin: string;
  adminLock: string;
  enterPin: string;
  unlock: string;
  incorrectPin: string;
  
  // Navigation
  dashboard: string;
  customers: string;
  billing: string;
  payments: string;
  googleSheets: string;
  apkDownload: string;
  settings: string;
  
  // Dashboard KPI
  totalCustomers: string;
  activeCustomers: string;
  inactiveCustomers: string;
  totalMonthlyBilling: string;
  totalCollection: string;
  totalOutstanding: string;
  cashCollection: string;
  upiCollection: string;
  collectionRate: string;
  quickCollect: string;
  recentCollections: string;
  areaBreakdown: string;
  billingMonth: string;
  
  // Customer
  customerList: string;
  addCustomer: string;
  editCustomer: string;
  deleteCustomer: string;
  confirmDelete: string;
  customerDetails: string;
  customerId: string;
  customerName: string;
  mobileNumber: string;
  address: string;
  area: string;
  serviceType: string;
  monthlySubscription: string;
  status: string;
  active: string;
  inactive: string;
  suspended: string;
  cableTV: string;
  broadband: string;
  combo: string;
  searchPlaceholder: string;
  filterByService: string;
  filterByArea: string;
  filterByStatus: string;
  allAreas: string;
  allServices: string;
  allStatuses: string;
  boxOrRouterNo: string;
  ipAddress: string;
  connectionDate: string;
  previousDues: string;
  currentBalance: string;
  
  // Billing
  generateBills: string;
  billsGeneratedSuccess: string;
  billNumber: string;
  planAmount: string;
  totalPayable: string;
  paidAmount: string;
  balanceDue: string;
  paid: string;
  unpaid: string;
  partial: string;
  dueDate: string;
  sendWhatsAppReminder: string;
  allBills: string;
  unpaidOnly: string;
  paidOnly: string;
  
  // Payment
  recordPayment: string;
  paymentMode: string;
  cash: string;
  upi: string;
  upiReference: string;
  paymentDate: string;
  receiptNumber: string;
  printReceipt: string;
  thermalReceipt: string;
  fullInvoice: string;
  shareWhatsApp: string;
  paymentSuccess: string;
  collectedBy: string;
  notes: string;
  scanToPay: string;
  
  // Google Sheets
  googleSheetsTitle: string;
  uploadSheet: string;
  dragDropText: string;
  importPreview: string;
  duplicateDetected: string;
  skipDuplicates: string;
  overwriteDuplicates: string;
  saveImportedData: string;
  downloadCustomers: string;
  exportMonthlyReport: string;
  twoWaySync: string;
  syncSuccess: string;
  syncWithSheets: string;
  
  // APK & Android
  androidApkTitle: string;
  downloadApk: string;
  installPwa: string;
  androidStudioProject: string;
  installationGuide: string;
  step1Title: string;
  step1Desc: string;
  step2Title: string;
  step2Desc: string;
  step3Title: string;
  step3Desc: string;
  apkFeatures: string;
  
  // Settings & Database
  supabaseConfig: string;
  supabaseUrl: string;
  supabaseKey: string;
  connectSupabase: string;
  connected: string;
  disconnected: string;
  downloadSqlSchema: string;
  backupData: string;
  restoreData: string;
  upiIdSetting: string;
  businessAddress: string;
  saveChanges: string;
  
  // Common
  cancel: string;
  save: string;
  close: string;
  actions: string;
  currencySymbol: string;
  noDataFound: string;
  loading: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    appName: "CCTV NETWORK CHAMPESWAR",
    appSubtitle: "Cable TV & High-Speed Internet Billing System",
    ownerOnly: "Owner & Admin Portal",
    adminLogin: "Admin Login",
    adminLock: "App Locked",
    enterPin: "Enter 4-Digit Owner PIN",
    unlock: "Unlock Dashboard",
    incorrectPin: "Incorrect PIN. Default is 1234",
    
    dashboard: "Dashboard",
    customers: "Customers",
    billing: "Monthly Billing",
    payments: "Payments & Ledger",
    googleSheets: "Google Sheets Sync",
    apkDownload: "Android APK & Setup",
    settings: "Settings & Cloud DB",
    
    totalCustomers: "Total Customers",
    activeCustomers: "Active Connections",
    inactiveCustomers: "Inactive / Suspended",
    totalMonthlyBilling: "Current Month Billing",
    totalCollection: "Total Collected",
    totalOutstanding: "Total Outstanding Dues",
    cashCollection: "Cash Collection",
    upiCollection: "UPI Collection",
    collectionRate: "Collection Progress",
    quickCollect: "Quick Collect Payment",
    recentCollections: "Recent Collections",
    areaBreakdown: "Area-wise Dues Breakdown",
    billingMonth: "Billing Month",
    
    customerList: "Customer Management",
    addCustomer: "Add New Customer",
    editCustomer: "Edit Customer",
    deleteCustomer: "Delete Customer",
    confirmDelete: "Are you sure you want to remove this customer and their billing history?",
    customerDetails: "Customer Profile & Ledger",
    customerId: "Customer ID",
    customerName: "Customer Name",
    mobileNumber: "Mobile Number",
    address: "Street / Landmark",
    area: "Area / Village",
    serviceType: "Service Type",
    monthlySubscription: "Monthly Plan (₹)",
    status: "Connection Status",
    active: "Active",
    inactive: "Inactive",
    suspended: "Suspended",
    cableTV: "Cable TV",
    broadband: "Broadband ISP",
    combo: "Combo (Cable + Internet)",
    searchPlaceholder: "Search by Name, Customer ID, Mobile, or Area...",
    filterByService: "Filter by Service",
    filterByArea: "Filter by Area",
    filterByStatus: "Filter by Status",
    allAreas: "All Areas",
    allServices: "All Services",
    allStatuses: "All Statuses",
    boxOrRouterNo: "Set-Top Box / ONT MAC",
    ipAddress: "Static IP / VLAN ID",
    connectionDate: "Connection Date",
    previousDues: "Previous Dues (₹)",
    currentBalance: "Current Balance (₹)",
    
    generateBills: "Generate Monthly Bills",
    billsGeneratedSuccess: "Monthly bills generated successfully!",
    billNumber: "Bill No",
    planAmount: "Plan Amount",
    totalPayable: "Total Payable",
    paidAmount: "Paid Amount",
    balanceDue: "Balance Due",
    paid: "Paid",
    unpaid: "Unpaid",
    partial: "Partial",
    dueDate: "Due Date",
    sendWhatsAppReminder: "WhatsApp Bill Reminder",
    allBills: "All Bills",
    unpaidOnly: "Unpaid & Partial",
    paidOnly: "Fully Paid",
    
    recordPayment: "Collect Payment",
    paymentMode: "Payment Mode",
    cash: "Cash",
    upi: "UPI (GPay / PhonePe / Paytm)",
    upiReference: "UPI Ref / UTR No.",
    paymentDate: "Payment Date",
    receiptNumber: "Receipt No",
    printReceipt: "Print Receipt",
    thermalReceipt: "Thermal POS Receipt (80mm)",
    fullInvoice: "Standard Invoice",
    shareWhatsApp: "Send Receipt on WhatsApp",
    paymentSuccess: "Payment collected and receipt generated!",
    collectedBy: "Collected By",
    notes: "Remarks / Notes",
    scanToPay: "Scan to Pay via UPI",
    
    googleSheetsTitle: "Google Sheets & Excel Integration",
    uploadSheet: "Upload Google Sheet / Excel (.xlsx, .csv)",
    dragDropText: "Click or drag & drop customer file here to import",
    importPreview: "Import Preview & Verification",
    duplicateDetected: "Duplicate Customer Found",
    skipDuplicates: "Skip Existing Records",
    overwriteDuplicates: "Update Existing Records",
    saveImportedData: "Import Verified Customers",
    downloadCustomers: "Download Customer Master (Excel)",
    exportMonthlyReport: "Export Monthly Collection (Excel)",
    twoWaySync: "Google Sheets Webhook & Auto-Sync",
    syncSuccess: "Data synchronized successfully!",
    syncWithSheets: "Sync with Google Sheets Now",
    
    androidApkTitle: "Android Mobile App (APK) & Native Source",
    downloadApk: "Download Signed Release APK",
    installPwa: "Install WebAPK on Android Device",
    androidStudioProject: "Download Android Studio Kotlin Project (ZIP)",
    installationGuide: "APK Installation & Setup Guide",
    step1Title: "1. Download the APK file",
    step1Desc: "Download CCTV-Network-Champeswar-v1.0.apk directly to your Android smartphone.",
    step2Title: "2. Allow Installation from Unknown Sources",
    step2Desc: "Open Settings > Security > Install Unknown Apps. Allow permission for your browser or file manager.",
    step3Title: "3. Open and Log in",
    step3Desc: "Tap the downloaded APK, tap Install, then open the app. Enter your 4-digit Owner PIN to start collecting bills.",
    apkFeatures: "Field Agent & Offline Billing Ready",
    
    supabaseConfig: "Supabase & PostgreSQL Database",
    supabaseUrl: "Supabase Project URL",
    supabaseKey: "Supabase Anon API Key",
    connectSupabase: "Connect & Test Supabase",
    connected: "Cloud Database Connected",
    disconnected: "Local Offline Storage Active",
    downloadSqlSchema: "Download PostgreSQL SQL Schema File",
    backupData: "Backup All Data (JSON)",
    restoreData: "Restore from Backup File",
    upiIdSetting: "Owner UPI ID for QR Receipts",
    businessAddress: "Business Center Address",
    saveChanges: "Save Configuration",
    
    cancel: "Cancel",
    save: "Save",
    close: "Close",
    actions: "Actions",
    currencySymbol: "₹",
    noDataFound: "No records found matching criteria",
    loading: "Loading data...",
  },

  or: {
    appName: "ସିସିଟିଭି ନେଟୱର୍କ ଚମ୍ପେଶ୍ୱର",
    appSubtitle: "କେବୁଲ୍ ଟିଭି ଏବଂ ଇଣ୍ଟରନେଟ୍ ବିଲିଂ ଆପ୍",
    ownerOnly: "ମାଲିକ ଏବଂ ଆଡମିନ୍ ପୋର୍ଟାଲ୍",
    adminLogin: "ଆଡମିନ୍ ଲଗଇନ୍",
    adminLock: "ଆପ୍ ଲକ୍ ଅଛି",
    enterPin: "୪-ଅଙ୍କ ବିଶିଷ୍ଟ ପିନ୍ ଦିଅନ୍ତୁ",
    unlock: "ଡ୍ୟାସବୋର୍ଡ୍ ଖୋଲନ୍ତୁ",
    incorrectPin: "ଭୁଲ୍ ପିନ୍! ଡିଫଲ୍ଟ ପିନ୍ ହେଉଛି 1234",
    
    dashboard: "ଡ୍ୟାସବୋର୍ଡ୍",
    customers: "ଗ୍ରାହକ ତାଲିକା",
    billing: "ମାସିକ ବିଲିଂ",
    payments: "ଆଦାୟ ଏବଂ ଲେଜର",
    googleSheets: "ଗୁଗୁଲ୍ ସିଟ୍ସ ସିଙ୍କ୍",
    apkDownload: "ଆଣ୍ଡ୍ରଏଡ୍ APK",
    settings: "ସେଟିଂସ ଏବଂ କ୍ଲାଉଡ୍",
    
    totalCustomers: "ମୋଟ ଗ୍ରାହକ",
    activeCustomers: "ସକ୍ରିୟ ସଂଯୋଗ",
    inactiveCustomers: "ନିଷ୍କ୍ରିୟ / ବନ୍ଦ",
    totalMonthlyBilling: "ଚଳିତ ମାସ ବିଲିଂ",
    totalCollection: "ମୋଟ ଆଦାୟ",
    totalOutstanding: "ବାକି ଟଙ୍କା (ବକେୟା)",
    cashCollection: "ନଗଦ ଆଦାୟ (Cash)",
    upiCollection: "ୟୁପିଆଇ ଆଦାୟ (UPI)",
    collectionRate: "ଆଦାୟ ଅଗ୍ରଗତି",
    quickCollect: "ତୁରନ୍ତ ଟଙ୍କା ଆଦାୟ କରନ୍ତୁ",
    recentCollections: "ନିକଟରେ ହୋଇଥିବା ଆଦାୟ",
    areaBreakdown: "ଅଞ୍ଚଳ ଅନୁସାରେ ବକେୟା",
    billingMonth: "ବିଲିଂ ମାସ",
    
    customerList: "ଗ୍ରାହକ ପରିଚାଳନା",
    addCustomer: "ନୂତନ ଗ୍ରାହକ ଯୋଡନ୍ତୁ",
    editCustomer: "ଗ୍ରାହକ ସଂଶୋଧନ",
    deleteCustomer: "ଗ୍ରାହକ ହଟାନ୍ତୁ",
    confirmDelete: "ଆପଣ ନିଶ୍ଚିତ କି ଏହି ଗ୍ରାହକଙ୍କୁ ତାଙ୍କ ବିଲିଂ ଇତିହାସ ସହିତ ହଟାଇବାକୁ ଚାହାଁନ୍ତି?",
    customerDetails: "ଗ୍ରାହକ ବିବରଣୀ ଏବଂ ଖାତା",
    customerId: "ଗ୍ରାହକ ଆଇଡି",
    customerName: "ଗ୍ରାହକଙ୍କ ନାମ",
    mobileNumber: "ମୋବାଇଲ୍ ନମ୍ବର",
    address: "ଠିକଣା / ସାହି",
    area: "ଅଞ୍ଚଳ / ଗ୍ରାମ",
    serviceType: "ସେବା ପ୍ରକାର",
    monthlySubscription: "ମାସିକ ପ୍ଲାନ୍ (₹)",
    status: "ସଂଯୋଗ ସ୍ଥିତି",
    active: "ସକ୍ରିୟ (Active)",
    inactive: "ନିଷ୍କ୍ରିୟ (Inactive)",
    suspended: "ସ୍ଥଗିତ (Suspended)",
    cableTV: "କେବୁଲ୍ ଟିଭି (Cable)",
    broadband: "ଇଣ୍ଟରନେଟ୍ (Broadband)",
    combo: "ଉଭୟ କେବୁଲ୍ + ନେଟ୍ (Combo)",
    searchPlaceholder: "ନାମ, ଆଇଡି, ମୋବାଇଲ୍ କିମ୍ବା ଅଞ୍ଚଳ ଅନୁସାରେ ଖୋଜନ୍ତୁ...",
    filterByService: "ସେବା ଅନୁସାରେ ଫିଲ୍ଟର୍",
    filterByArea: "ଅଞ୍ଚଳ ଅନୁସାରେ ଫିଲ୍ଟର୍",
    filterByStatus: "ସ୍ଥିତି ଅନୁସାରେ ଫିଲ୍ଟର୍",
    allAreas: "ସମସ୍ତ ଅଞ୍ଚଳ",
    allServices: "ସମସ୍ତ ସେବା",
    allStatuses: "ସମସ୍ତ ସ୍ଥିତି",
    boxOrRouterNo: "ସେଟ୍-ଟପ୍ ବକ୍ସ / ରାଉଟର୍ ନମ୍ବର",
    ipAddress: "ଆଇପି / ଭିଲାନ୍ ଆଇଡି",
    connectionDate: "ସଂଯୋଗ ତାରିଖ",
    previousDues: "ପୂର୍ବ ବକେୟା (₹)",
    currentBalance: "ମୋଟ ବାକି (₹)",
    
    generateBills: "ମାସିକ ବିଲ୍ ତିଆରି କରନ୍ତୁ",
    billsGeneratedSuccess: "ମାସିକ ବିଲ୍ ସଫଳତାର ସହ ପ୍ରସ୍ତୁତ ହୋଇଗଲା!",
    billNumber: "ବିଲ୍ ନମ୍ବର",
    planAmount: "ପ୍ଲାନ୍ ମୂଲ୍ୟ",
    totalPayable: "ମୋଟ ଦେୟ",
    paidAmount: "ଦିଆଯାଇଥିବା ଟଙ୍କା",
    balanceDue: "ବାକି ଟଙ୍କା",
    paid: "ପରିଶୋଧିତ (Paid)",
    unpaid: "ଅପରିଶୋଧିତ (Unpaid)",
    partial: "ଆଂଶିକ (Partial)",
    dueDate: "ଶେଷ ତାରିଖ",
    sendWhatsAppReminder: "ହ୍ୱାଟ୍ସଆପ୍ ବିଲ୍ ରିମାଇଣ୍ଡର୍",
    allBills: "ସମସ୍ତ ବିଲ୍",
    unpaidOnly: "କେବଳ ବାକି ଥିବା",
    paidOnly: "ପୂରା ପରିଶୋଧିତ",
    
    recordPayment: "ଟଙ୍କା ଆଦାୟ ଲେଖନ୍ତୁ",
    paymentMode: "ଟଙ୍କା ପେମେଣ୍ଟ ମାଧ୍ୟମ",
    cash: "ନଗଦ ଟଙ୍କା (Cash)",
    upi: "ୟୁପିଆଇ (Google Pay / PhonePe / Paytm)",
    upiReference: "ୟୁପିଆଇ ରେଫରେନ୍ସ (UTR No.)",
    paymentDate: "ଆଦାୟ ତାରିଖ",
    receiptNumber: "ରସିଦ୍ ନମ୍ବର",
    printReceipt: "ରସିଦ୍ ପ୍ରିଣ୍ଟ୍ କରନ୍ତୁ",
    thermalReceipt: "ଥର୍ମାଲ୍ ପ୍ରିଣ୍ଟର୍ ରସିଦ୍ (80mm)",
    fullInvoice: "ସାଧାରଣ ଇନଭଏସ୍",
    shareWhatsApp: "ହ୍ୱାଟ୍ସଆପ୍‌ରେ ରସିଦ୍ ପଠାନ୍ତୁ",
    paymentSuccess: "ଟଙ୍କା ସଫଳତାର ସହ ଆଦାୟ ହେଲା ଏବଂ ରସିଦ୍ ପ୍ରସ୍ତୁତ!",
    collectedBy: "ଆଦାୟକାରୀ",
    notes: "ଟିପ୍ପଣୀ",
    scanToPay: "ୟୁପିଆଇ କ୍ୟୁଆର୍ କୋଡ୍ ସ୍କାନ୍ କରନ୍ତୁ",
    
    googleSheetsTitle: "ଗୁଗୁଲ୍ ସିଟ୍ସ ଏବଂ ଏକ୍ସେଲ୍ ତଥ୍ୟ",
    uploadSheet: "ଗୁଗୁଲ୍ ସିଟ୍ / ଏକ୍ସେଲ୍ ଫାଇଲ୍ ଅପଲୋଡ୍ (.xlsx, .csv)",
    dragDropText: "ଗ୍ରାହକ ଫାଇଲ୍ ଏଠାରେ ଡ୍ରପ୍ କରନ୍ତୁ କିମ୍ବା ବାଛନ୍ତୁ",
    importPreview: "ଇମ୍ପୋର୍ଟ୍ ପୂର୍ବାବଲୋକନ ଏବଂ ଯାଞ୍ଚ",
    duplicateDetected: "ପୂର୍ବରୁ ଥିବା ଗ୍ରାହକ ମିଳିଲେ",
    skipDuplicates: "ପୂର୍ବରୁ ଥିବା ଗ୍ରାହକଙ୍କୁ ଛାଡନ୍ତୁ",
    overwriteDuplicates: "ତଥ୍ୟ ଅପଡେଟ୍ କରନ୍ତୁ",
    saveImportedData: "ଯାଞ୍ଚ ହୋଇଥିବା ଗ୍ରାହକ ଯୋଡନ୍ତୁ",
    downloadCustomers: "ଗ୍ରାହକ ତାଲିକା ଏକ୍ସେଲ୍ ଡାଉନଲୋଡ୍",
    exportMonthlyReport: "ମାସିକ ଆଦାୟ ରିପୋର୍ଟ୍ ଡାଉନଲୋଡ୍",
    twoWaySync: "ଗୁଗୁଲ୍ ସିଟ୍ସ ଦ୍ୱିମୁଖୀ ସିଙ୍କ୍",
    syncSuccess: "ତଥ୍ୟ ସଫଳତାର ସହ ସିଙ୍କ୍ ହୋଇଗଲା!",
    syncWithSheets: "ଏବେ ଗୁଗୁଲ୍ ସିଟ୍ସ ସହିତ ସିଙ୍କ୍ କରନ୍ତୁ",
    
    androidApkTitle: "ଆଣ୍ଡ୍ରଏଡ୍ ମୋବାଇଲ୍ ଆପ୍ (APK) ଏବଂ କୋଡ୍",
    downloadApk: "ରିଲିଜ୍ APK ଡାଉନଲୋଡ୍ କରନ୍ତୁ",
    installPwa: "ଆଣ୍ଡ୍ରଏଡ୍ ଫୋନ୍‌ରେ ସିଧାସଳଖ ଇନଷ୍ଟଲ୍ କରନ୍ତୁ (WebAPK)",
    androidStudioProject: "ଆଣ୍ଡ୍ରଏଡ୍ ଷ୍ଟୁଡିଓ କୋଟଲିନ୍ ପ୍ରୋଜେକ୍ଟ (ZIP)",
    installationGuide: "APK ଇନଷ୍ଟଲେସନ୍ ନିୟମାବଳୀ",
    step1Title: "୧. APK ଫାଇଲ୍ ଡାଉନଲୋଡ୍ କରନ୍ତୁ",
    step1Desc: "ଆପଣଙ୍କ ମୋବାଇଲ୍ ଫୋନ୍‌ରେ CCTV-Network-Champeswar.apk ସେଭ୍ କରନ୍ତୁ।",
    step2Title: "୨. Unknown Sources ଅନୁମତି ଦିଅନ୍ତୁ",
    step2Desc: "ସେଟିଂସ > ସୁରକ୍ଷା > Install Unknown Apps କୁ ଯାଇ ବ୍ରାଉଜର୍ କୁ ଅନୁମତି ଦିଅନ୍ତୁ।",
    step3Title: "୩. ଆପ୍ ଖୋଲି ବିଲ୍ ଆଦାୟ କରନ୍ତୁ",
    step3Desc: "ଆପ୍ ଇନଷ୍ଟଲ୍ ହେବା ପରେ ୪-ଅଙ୍କ ବିଶିଷ୍ଟ ପିନ୍ 1234 ଦେଇ ଲଗଇନ୍ କରନ୍ତୁ।",
    apkFeatures: "ଫିଲ୍ଡ ଏଜେଣ୍ଟ ଏବଂ ଅଫଲାଇନ୍ ବିଲିଂ ପାଇଁ ଉପଯୁକ୍ତ",
    
    supabaseConfig: "ସୁପାବେସ୍ ଏବଂ ପୋଷ୍ଟଗ୍ରେସ୍କ୍ୟୁଏଲ୍ ଡାଟାବେସ୍",
    supabaseUrl: "ସୁପାବେସ୍ ପ୍ରୋଜେକ୍ଟ URL",
    supabaseKey: "ସୁପାବେସ୍ Anon Key",
    connectSupabase: "ସୁପାବେସ୍ କନେକ୍ଟ ଏବଂ ଟେଷ୍ଟ୍ କରନ୍ତୁ",
    connected: "କ୍ଲାଉଡ୍ ଡାଟାବେସ୍ ସକ୍ରିୟ ଅଛି",
    disconnected: "ଲୋକାଲ୍ ଅଫଲାଇନ୍ ଷ୍ଟୋରେଜ୍ ଚାଲିଛି",
    downloadSqlSchema: "PostgreSQL SQL ସ୍କ୍ରିପ୍ଟ ଡାଉନଲୋଡ୍",
    backupData: "ସମସ୍ତ ତଥ୍ୟ ବ୍ୟାକଅପ୍ (JSON)",
    restoreData: "ବ୍ୟାକଅପ୍ ଫାଇଲ୍ ରୁ ରିଷ୍ଟୋର୍ କରନ୍ତୁ",
    upiIdSetting: "ୟୁପିଆଇ ଆଇଡି (କ୍ୟୁଆର୍ କୋଡ୍ ପାଇଁ)",
    businessAddress: "ଅଫିସ୍ ଠିକଣା",
    saveChanges: "ସେଟିଂସ ସେଭ୍ କରନ୍ତୁ",
    
    cancel: "ବାତିଲ୍",
    save: "ସେଭ୍",
    close: "ବନ୍ଦ କରନ୍ତୁ",
    actions: "କାର୍ଯ୍ୟ",
    currencySymbol: "₹",
    noDataFound: "କୌଣସି ରେକର୍ଡ ମିଳିଲା ନାହିଁ",
    loading: "ଲୋଡ୍ ହେଉଛି...",
  },

  hi: {
    appName: "सीसीटीवी नेटवर्क चंपेश्वर",
    appSubtitle: "केबल टीवी एवं हाई-स्पीड इंटरनेट बिलिंग ऐप",
    ownerOnly: "मालिक एवं एडमिन पोर्टल",
    adminLogin: "एडमिन लॉगिन",
    adminLock: "ऐप लॉक है",
    enterPin: "4-अंकीय मालिक पिन दर्ज करें",
    unlock: "डैशबोर्ड खोलें",
    incorrectPin: "गलत पिन! डिफ़ॉल्ट पिन 1234 है",
    
    dashboard: "डैशबोर्ड",
    customers: "ग्राहक सूची",
    billing: "मासिक बिलिंग",
    payments: "भुगतान एवं लेजर",
    googleSheets: "गूगल शीट्स सिंक",
    apkDownload: "एंड्रॉयड APK",
    settings: "सेटिंग्स व डेटाबेस",
    
    totalCustomers: "कुल ग्राहक",
    activeCustomers: "सक्रिय कनेक्शन",
    inactiveCustomers: "निष्क्रिय / बंद",
    totalMonthlyBilling: "चालू माह बिलिंग",
    totalCollection: "कुल वसूली (संग्रह)",
    totalOutstanding: "कुल बकाया राशि",
    cashCollection: "नकद वसूली (Cash)",
    upiCollection: "यूपीआई वसूली (UPI)",
    collectionRate: "संग्रह प्रगति",
    quickCollect: "त्वरित भुगतान संग्रह",
    recentCollections: "हालिया संग्रह",
    areaBreakdown: "क्षेत्र अनुसार बकाया",
    billingMonth: "बिलिंग माह",
    
    customerList: "ग्राहक प्रबंधन",
    addCustomer: "नया ग्राहक जोड़ें",
    editCustomer: "ग्राहक संपादित करें",
    deleteCustomer: "ग्राहक हटाएं",
    confirmDelete: "क्या आप इस ग्राहक को उनके बिलिंग इतिहास सहित हटाना चाहते हैं?",
    customerDetails: "ग्राहक विवरण एवं खाता",
    customerId: "ग्राहक आईडी",
    customerName: "ग्राहक का नाम",
    mobileNumber: "मोबाइल नंबर",
    address: "गली / पता",
    area: "क्षेत्र / गांव",
    serviceType: "सेवा प्रकार",
    monthlySubscription: "मासिक शुल्क (₹)",
    status: "कनेक्शन स्थिति",
    active: "सक्रिय (Active)",
    inactive: "निष्क्रिय (Inactive)",
    suspended: "निलंबित (Suspended)",
    cableTV: "केबल टीवी",
    broadband: "ब्रॉडबैंड इंटरनेट",
    combo: "कॉम्बो (केबल + नेट)",
    searchPlaceholder: "नाम, आईडी, मोबाइल या क्षेत्र से खोजें...",
    filterByService: "सेवा अनुसार फ़िल्टर",
    filterByArea: "क्षेत्र अनुसार फ़िल्टर",
    filterByStatus: "स्थिति अनुसार फ़िल्टर",
    allAreas: "सभी क्षेत्र",
    allServices: "सभी सेवाएं",
    allStatuses: "सभी स्थितियां",
    boxOrRouterNo: "सेट-टॉप बॉक्स / राउटर मैक",
    ipAddress: "आईपी / वीलैन आईडी",
    connectionDate: "कनेक्शन दिनांक",
    previousDues: "पिछला बकाया (₹)",
    currentBalance: "कुल बकाया (₹)",
    
    generateBills: "मासिक बिल जनरेट करें",
    billsGeneratedSuccess: "मासिक बिल सफलतापूर्वक तैयार हो गए!",
    billNumber: "बिल नंबर",
    planAmount: "प्लान राशि",
    totalPayable: "कुल देय",
    paidAmount: "भुगतान राशि",
    balanceDue: "शेष बकाया",
    paid: "भुगतान संपन्न (Paid)",
    unpaid: "अदत्त (Unpaid)",
    partial: "आंशिक (Partial)",
    dueDate: "अंतिम तिथि",
    sendWhatsAppReminder: "व्हाट्सएप बिल रिमाइंडर",
    allBills: "सभी बिल",
    unpaidOnly: "केवल बकाया बिल",
    paidOnly: "पूर्ण भुगतान बिल",
    
    recordPayment: "भुगतान दर्ज करें",
    paymentMode: "भुगतान का माध्यम",
    cash: "नकद (Cash)",
    upi: "यूपीआई (Google Pay / PhonePe / Paytm)",
    upiReference: "यूपीआई संदर्भ / UTR नंबर",
    paymentDate: "भुगतान दिनांक",
    receiptNumber: "रसीद नंबर",
    printReceipt: "रसीद प्रिंट करें",
    thermalReceipt: "थर्मल प्रिंटर रसीद (80mm)",
    fullInvoice: "मानक चालान (Invoice)",
    shareWhatsApp: "व्हाट्सएप पर रसीद भेजें",
    paymentSuccess: "भुगतान दर्ज किया गया एवं रसीद तैयार!",
    collectedBy: "संग्रहकर्ता",
    notes: "टिप्पणी / विवरण",
    scanToPay: "यूपीआई क्यूआर कोड स्कैन करें",
    
    googleSheetsTitle: "गूगल शीट्स एवं एक्सेल एकीकरण",
    uploadSheet: "गूगल शीट / एक्सेल अपलोड करें (.xlsx, .csv)",
    dragDropText: "ग्राहक डेटा फ़ाइल यहां खींचें या चुनें",
    importPreview: "आयात पूर्वावलोकन एवं सत्यापन",
    duplicateDetected: "डुप्लीकेट ग्राहक मिला",
    skipDuplicates: "मौजूदा रिकॉर्ड छोड़ें",
    overwriteDuplicates: "मौजूदा रिकॉर्ड अपडेट करें",
    saveImportedData: "सत्यापित ग्राहक सहेजें",
    downloadCustomers: "ग्राहक सूची एक्सेल डाउनलोड",
    exportMonthlyReport: "मासिक संग्रह रिपोर्ट डाउनलोड",
    twoWaySync: "गूगल शीट्स ऑटो-सिंक",
    syncSuccess: "डेटा सफलतापूर्वक सिंक हुआ!",
    syncWithSheets: "गूगल शीट्स से अभी सिंक करें",
    
    androidApkTitle: "एंड्रॉयड मोबाइल ऐप (APK) एवं सोर्स कोड",
    downloadApk: "रिलीज़ APK डाउनलोड करें",
    installPwa: "फोन में सीधे इंस्टॉल करें (WebAPK)",
    androidStudioProject: "एंड्रॉयड स्टूडियो कोटलिन प्रोजेक्ट (ZIP)",
    installationGuide: "APK इंस्टॉलेशन मार्गदर्शिका",
    step1Title: "1. APK फ़ाइल डाउनलोड करें",
    step1Desc: "अपने मोबाइल पर CCTV-Network-Champeswar.apk डाउनलोड करें।",
    step2Title: "2. अज्ञात स्रोत (Unknown Sources) चालू करें",
    step2Desc: "सेटिंग्स > सुरक्षा > अज्ञात ऐप्स इंस्टॉल की अनुमति दें।",
    step3Title: "3. ऐप खोलें और बिल संग्रह करें",
    step3Desc: "ऐप इंस्टॉल करने के बाद 4-अंकीय पिन 1234 से लॉगिन करें।",
    apkFeatures: "फील्ड एजेंट और ऑफलाइन बिलिंग हेतु उपयुक्त",
    
    supabaseConfig: "सुपाबेस एवं पोस्टग्रेएसक्यूएल डेटाबेस",
    supabaseUrl: "सुपाबेस प्रोजेक्ट URL",
    supabaseKey: "सुपाबेस Anon Key",
    connectSupabase: "सुपाबेस कनेक्ट व टेस्ट करें",
    connected: "क्लाउड डेटाबेस सक्रिय है",
    disconnected: "लोकल ऑफलाइन स्टोरेज चालू है",
    downloadSqlSchema: "PostgreSQL SQL स्कीमा डाउनलोड",
    backupData: "पूरा डेटा बैकअप लें (JSON)",
    restoreData: "बैकअप फ़ाइल से पुनर्स्थापित करें",
    upiIdSetting: "क्यूआर रसीद हेतु यूपीआई आईडी",
    businessAddress: "कार्यालय का पता",
    saveChanges: "सेटिंग्स सहेजें",
    
    cancel: "रद्द करें",
    save: "सहेजें",
    close: "बंद करें",
    actions: "कार्रवाई",
    currencySymbol: "₹",
    noDataFound: "कोई डेटा नहीं मिला",
    loading: "लोड हो रहा है...",
  }
};
