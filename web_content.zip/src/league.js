import { DIVISIONS } from './config.js';
import { generateSeasonCalendar } from './calendar.js';

export function standings(division) {
  return [...division.clubs].sort((a,b) => b.points-a.points || (b.gf-b.ga)-(a.gf-a.ga) || b.gf-a.gf || a.name.localeCompare(b.name));
}
export function activateExpansions(state, clubPool = null) {
  const activated = [];
  for (const spec of DIVISIONS.filter(d => !d.initial && d.activationSeason <= state.season)) {
    const div = state.divisions.find(d => d.id === spec.id);
    if (div.status === 'active') continue;
    const sourcePool = clubPool === null
      ? (state.world?.clubCatalog || []).filter(club => club.divisionId === spec.id)
      : clubPool;
    const candidates = sourcePool.filter(c => !state.divisions.some(x => x.clubs.some(y => y.id === c.id)));
    if (candidates.length < 12) { div.status = 'waiting-for-12-clubs'; continue; }
    div.clubs = candidates.slice(0,12).map(c => ({ ...c, divisionId: spec.id }));
    if (div.clubs.some(c => c.damistes?.length !== 2)) throw new Error('Chaque nouveau club doit avoir exactement deux damistes');
    div.status = 'active'; activated.push(spec.id);
    state.history.notices.push({ season: state.season, type: 'division-opened', divisionId: spec.id, text: `${spec.name} officiellement ouverte` });
  }
  if (activated.length) { state.calendar.fixtures = state.calendar.fixtures.filter(f => f.status === 'played'); generateSeasonCalendar(state); }
  return activated;
}
export function applyPromotionRelegation(state) {
  const active = state.divisions.filter(d => d.status === 'active').sort((a,b) => a.rank-b.rank);
  const moves = [];
  for (let i=0; i<active.length-1; i++) {
    const upper = active[i], lower = active[i+1];
    if (upper.clubs.length < 4 || lower.clubs.length < 4) continue;
    const up = standings(lower).slice(0,2), down = standings(upper).slice(-2);
    for (let j=0;j<2;j++) {
      moveClub(up[j], lower, upper); moves.push({ clubId: up[j].id, from: lower.id, to: upper.id, direction: 'promotion' });
      moveClub(down[j], upper, lower); moves.push({ clubId: down[j].id, from: upper.id, to: lower.id, direction: 'relegation' });
    }
  }
  return moves;
}
function moveClub(club, from, to) { from.clubs = from.clubs.filter(c => c.id !== club.id); club.divisionId = to.id; resetSeasonStats(club); to.clubs.push(club); }
function resetSeasonStats(c) { Object.assign(c,{played:0,won:0,drawn:0,lost:0,gf:0,ga:0,points:0}); }
