const valid=(value,fallback)=>/^#[0-9a-f]{6}$/i.test(value||'')?value:fallback;
export function buildMatchKitStyle(homeClub,awayClub,userClubId=null){
 const userIsHome=!userClubId||userClubId===homeClub?.id;
 const playerClub=userIsHome?homeClub:awayClub,opponentClub=userIsHome?awayClub:homeClub;
 const home=homeClub?.visualIdentity?.kit||{},player=playerClub?.visualIdentity?.kit||{},opponent=opponentClub?.visualIdentity?.kit||{};
 return {
  board:{primary:valid(home.primary,'#17345f'),secondary:valid(home.secondary,'#dce7f5')},
  home:{primary:valid(player.primary,'#b72e3d'),secondary:valid(player.secondary,'#641c2b'),accent:valid(player.accent,'#f5d16b'),motif:player.motif||'uni',number:String(player.number||'').slice(0,2)},
  away:{primary:valid(opponent.primary,'#1769aa'),secondary:valid(opponent.secondary,'#102f55'),accent:valid(opponent.accent,'#f5d16b'),motif:opponent.motif||'uni',number:String(opponent.number||'').slice(0,2)}
 };
}
export function getPieceKit(style,piece){return piece>0?style.home:style.away;}
