// Real catalog: public-domain classics, free & legal (archive.org). Admin can replace/extend in panel.
export const GENRES = ["اکشن","درام","کمدی","جنایی","رازآلود","ماجراجویی","عاشقانه","مستند","ترسناک","علمی‌تخیلی","کلاسیک"];
export const COUNTRIES = ["ایران","آمریکا","کره جنوبی","ترکیه","فرانسه","ایتالیا"];
const A = "https://archive.org/download/";
export const MOVIES = [
 {id:"m1", title:"شب مردگان زنده", en:"Night of the Living Dead", year:1968, type:"film", genre:["ترسناک","کلاسیک"], country:"آمریکا", rating:7.8, dur:"۱س ۳۶د", hue:[0,80,30], video:A+"night-of-the-living-dead-1968-hd/Night%20Of%20The%20Living%20Dead%20%281968%29%20%5BHD%5D.mp4", cast:["دوئن جونز","جودیت اودی"], desc:"گروهی غریبه در خانه‌ای روستایی پناه می‌گیرند؛ بیرون، مردگان برمی‌خیزند. آغاز سینمای زامبی مدرن."},
 {id:"m2", title:"معما", en:"Charade", year:1963, type:"film", genre:["کمدی","رازآلود","عاشقانه"], country:"آمریکا", rating:7.9, dur:"۱س ۵۳د", hue:[220,70,60], video:A+"batvwi-Charade_1963/Charade_1963.mp4", cast:["کری گرانت","آدری هپبورن"], desc:"بیوه‌ای جوان در پاریس می‌فهمد شوهرش ثروتی دزدی پنهان کرده و حالا همه دنبال اویند."},
 {id:"m3", title:"دختر جمعه او", en:"His Girl Friday", year:1940, type:"film", genre:["کمدی","کلاسیک"], country:"آمریکا", rating:7.8, dur:"۱س ۳۲د", hue:[45,140,55], video:A+"his_girl_friday/his_girl_friday_512kb.mp4", cast:["کری گرانت","رزالیند راسل"], desc:"سردبیر زیرک می‌خواهد خبرنگار سابقش را با یک سوژه جنایی داغ به تحریریه برگرداند."},
 {id:"m4", title:"خانه تسخیرشده", en:"House on Haunted Hill", year:1959, type:"film", genre:["ترسناک","کلاسیک"], country:"آمریکا", rating:6.8, dur:"۱س ۱۵د", hue:[260,60,40], video:A+"house_on_haunted_hill/house_on_haunted_hill.mp4", cast:["وینسنت پرایس"], desc:"میلیونری عجیب به پنج مهمان پیشنهاد می‌دهد: یک شب در خانه جن‌زده بمانید و پول بگیرید."},
 {id:"m5", title:"بیراهه", en:"Detour", year:1945, type:"film", genre:["جنایی","کلاسیک"], country:"آمریکا", rating:7.3, dur:"۱س ۸د", hue:[190,50,45], video:A+"detour-1945/Detour%201945.mp4", cast:["تام نیل","ان سوج"], desc:"پیانیستی دوره‌گرد سوار ماشین غریبه‌ای می‌شود و قدم‌به‌قدم در باتلاقی از سوءتفاهم فرو می‌رود."},
 {id:"m6", title:"کارناوال ارواح", en:"Carnival of Souls", year:1962, type:"film", genre:["ترسناک","رازآلود"], country:"آمریکا", rating:7.0, dur:"۱س ۱۸د", hue:[140,70,45], video:A+"carnival_of_souls/carnival_of_souls_512kb.mp4", cast:["کندس هیلیگاس"], desc:"زنی از تصادفی مرگبار جان سالم به در می‌برد، اما سایه‌هایی او را به سمت کارناوالی متروک می‌کشانند."},
 {id:"m7", title:"ناگهان", en:"Suddenly", year:1954, type:"film", genre:["جنایی","کلاسیک"], country:"آمریکا", rating:6.9, dur:"۱س ۱۵د", hue:[8,120,45], video:A+"Suddenly_1954/Suddenly_1954.mp4", cast:["فرانک سیناترا","استرلینگ هایدن"], desc:"تک‌تیراندازی در شهر کوچکی کمین می‌کند تا قطار رئیس‌جمهور را هدف بگیرد؛ کلانتر شهر تنها مانع اوست."},
 {id:"m8", title:"زامبی سفید", en:"White Zombie", year:1932, type:"film", genre:["ترسناک","کلاسیک"], country:"آمریکا", rating:6.1, dur:"۱س ۷د", hue:[24,150,40], video:A+"White_Zombie_1932/White_Zombie_512kb.mp4", cast:["بلا لوگوسی"], desc:"در هائیتی، جادوگری مردگان را به بردگی می‌گیرد و چشم به نامزد جوانی دوخته است."},
 {id:"m9", title:"مغزی که نمرد", en:"The Brain That Wouldn't Die", year:1962, type:"film", genre:["ترسناک","علمی‌تخیلی"], country:"آمریکا", rating:6.0, dur:"۱س ۲۲د", hue:[0,60,35], video:A+"the_brain_that_wouldnt_die/the_brain_that_wouldnt_die_512kb.mp4", cast:["جیسون اورز","ویرجینیا لیث"], desc:"جراحی دیوانه سرِ نامزدش را پس از تصادف زنده نگه می‌دارد و دنبال بدنی تازه برای او می‌گردد."},
 {id:"m10", title:"مأموریت در فضا", en:"Assignment Outer Space", year:1960, type:"film", genre:["علمی‌تخیلی","ماجراجویی"], country:"ایتالیا", rating:5.6, dur:"۱س ۱۹د", hue:[210,60,50], video:A+"Assignment_Outer_Space/Assignment_Outer_Space_512kb.mp4", cast:["ریک ون ناتر"], desc:"سفینه‌ای زمینی در اعماق فضا با سفینه‌ای بیگانه روبه‌رو می‌شود و سرنوشت زمین به یک تصمیم بند است."},
 {id:"m11", title:"مرد نامرئی", en:"The Amazing Transparent Man", year:1960, type:"film", genre:["علمی‌تخیلی","جنایی"], country:"آمریکا", rating:5.2, dur:"۵۸د", hue:[200,60,45], video:A+"The_Amazing_Transparent_Man/The_Amazing_Transparent_Man.mp4", cast:["داگلاس کندی"], desc:"دانشمندی سابق‌القتلی پرتویی می‌سازد که انسان را نامرئی می‌کند؛ گانگسترها بوی پول می‌شنوند."},
 {id:"m12", title:"سیاره زنان", en:"Voyage to the Planet of Prehistoric Women", year:1968, type:"film", genre:["علمی‌تخیلی","ماجراجویی"], country:"آمریکا", rating:4.9, dur:"۱س ۱۸د", hue:[35,130,50], video:A+"Voyage_to_the_Planet_of_Prehistoric_Women/Voyage_to_the_Planet_of_Prehistoric_Women.mp4", cast:["مامی ون دورن"], desc:"فضانوردان روی سیاره‌ای فرود می‌آیند که زنان آمازون بر آن فرمان می‌رانند."}
];
export const COLLECTIONS = [
 {id:"c1", title:"پیشنهاد سردبیر", ids:["m2","m1","m3","m5"]},
 {id:"c2", title:"ترسناک‌های کلاسیک", ids:["m1","m4","m6","m8","m9"]},
 {id:"c3", title:"علمی‌تخیلی قدیمی", ids:["m10","m11","m12"]}
];
export const NEWS = [
 {id:"n1", title:"۱۲ فیلم کلاسیک رایگان اضافه شد", body:"آثار ماندگار تاریخ سینما — از «شب مردگان زنده» تا «معما» با بازی آدری هپبورن — حالا با پخش و دانلود رایگان در فیلم‌لند.", date:"۱۴۰۳/۰۸/۱۲"},
 {id:"n2", title:"پخش مستقیم از آرشیو آزاد", body:"این فیلم‌ها از آرشیوهای عمومی و قانونی پخش می‌شوند؛ بدون نیاز به اشخاص ثالث و با کیفیت اصلی.", date:"۱۴۰۳/۰۸/۰۵"},
 {id:"n3", title:"به‌زودی: دوبله و زیرنویس فارسی", body:"نسخه‌های دوبله و زیرنویس فارسی به‌تدریج به بخش دانلود اضافه می‌شود.", date:"۱۴۰۳/۰۷/۲۸"}
];
