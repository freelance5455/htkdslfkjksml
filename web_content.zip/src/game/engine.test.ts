import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateMaxEnergy,
  getXpRequiredForNextLevel,
  getMoodProductivityMultiplier,
  createInitialState,
  trainGym,
  updatePersonName,
  startPregnancy,
  deliverBaby,
  enrollCourse,
  attendCourseDaily,
  executeWork
} from './engine';

test('calculateMaxEnergy scales correctly with fitness level', () => {
  assert.equal(calculateMaxEnergy(0), 100);
  assert.equal(calculateMaxEnergy(1), 110);
  assert.equal(calculateMaxEnergy(5), 150);
  assert.equal(calculateMaxEnergy(20), 300);
});

test('getXpRequiredForNextLevel becomes progressively harder', () => {
  assert.equal(getXpRequiredForNextLevel(0), 100);
  assert.equal(getXpRequiredForNextLevel(1), 120);
  assert.equal(getXpRequiredForNextLevel(5), 200);
});

test('gym training increases fitness XP and levels up when reaching threshold', () => {
  const initial = createInitialState('أحمد', 'نوران');
  initial.energy = 100;
  initial.fitnessXP = 90;
  initial.fitnessLevel = 0;

  const res = trainGym(initial);
  assert.equal(res.leveledUp, true);
  assert.equal(res.state.fitnessLevel, 1);
  assert.equal(calculateMaxEnergy(res.state.fitnessLevel), 110);
});

test('mood productivity multiplier reflects mental state correctly', () => {
  assert.equal(getMoodProductivityMultiplier(85).multiplier, 1.20);
  assert.equal(getMoodProductivityMultiplier(60).multiplier, 1.00);
  assert.equal(getMoodProductivityMultiplier(40).multiplier, 0.85);
  assert.equal(getMoodProductivityMultiplier(20).multiplier, 0.65);
});

test('renaming player, partner, and child updates state properly', () => {
  let s = createInitialState('علي', 'فاطمة');
  s = updatePersonName(s, 'player', 'حسام');
  assert.equal(s.playerName, 'حسام');

  s = updatePersonName(s, 'partner', 'ليلى');
  assert.equal(s.partnerName, 'ليلى');

  const birthRes = deliverBaby(s, 'يوسف', 'boy');
  assert.equal(birthRes.child.name, 'يوسف');
  assert.equal(birthRes.child.gender, 'boy');

  const renamedState = updatePersonName(birthRes.state, birthRes.child.id, 'آدم');
  const targetChild = renamedState.children.find(c => c.id === birthRes.child.id);
  assert.equal(targetChild?.name, 'آدم');
});

test('pregnancy starts, counts down, and delivers baby with custom boy/girl choice', () => {
  let s = createInitialState('مازن', 'سارة');
  s.married = true;

  const startRes = startPregnancy(s);
  assert.equal(startRes.success, true);
  assert.equal(startRes.state.pregnancyDaysRemaining, 10);

  // Deliver girl with custom name
  const birthRes = deliverBaby(startRes.state, 'فريدة', 'girl');
  assert.equal(birthRes.child.name, 'فريدة');
  assert.equal(birthRes.child.gender, 'girl');
  assert.equal(birthRes.state.children.length, 1);
  assert.equal(birthRes.state.pregnancyDaysRemaining, 0);
});

test('enrolling in a course and attending classes progresses to completion', () => {
  let s = createInitialState();
  s.money = 5000;
  s.energy = 100;

  const enrollRes = enrollCourse(s, 'driving_license');
  assert.equal(enrollRes.success, true);
  assert.equal(enrollRes.state.activeCourses.length, 1);

  let state = enrollRes.state;
  for (let i = 0; i < 3; i++) {
    state.energy = 100;
    const attendRes = attendCourseDaily(state, 'driving_license');
    state = attendRes.state;
  }

  assert.equal(state.completedCourseIds.includes('driving_license'), true);
  assert.equal(state.activeCourses.length, 0);
});

test('difficulty setting scales work payout appropriately', () => {
  const realisticState = createInitialState('محمد', 'أروى', 'realistic');
  realisticState.energy = 100;
  realisticState.hunger = 80;
  realisticState.mood = 60;
  const realisticRes = executeWork(realisticState, 'delivery');

  const survivalState = createInitialState('محمد', 'أروى', 'survival');
  survivalState.energy = 100;
  survivalState.hunger = 80;
  survivalState.mood = 60;
  const survivalRes = executeWork(survivalState, 'delivery');

  assert.ok(survivalRes.state.money < realisticRes.state.money, 'Survival mode pays less than realistic');
});
