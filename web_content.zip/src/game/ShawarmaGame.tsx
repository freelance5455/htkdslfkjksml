import { memo, useEffect, useRef, useState, useSyncExternalStore, type ReactNode } from "react";
import { Coins, Pause, Timer, Utensils, Volume2, VolumeX } from "lucide-react";
import { ING_LABEL } from "./content";
import { getHud, initialHud, subscribeHud } from "./hud";
import { gameCommand, input, pushLook, radialDeadzone, requestInteract } from "./input";
import type { Ing } from "./types";

function useHud() {
  return useSyncExternalStore(subscribeHud, getHud, () => initialHud);
}

const CHIP: Record<Ing, string> = {
  bread: "bg-chip-bread text-primary-ink",
  meat: "bg-chip-meat text-fg",
  veg: "bg-chip-veg text-fg",
  cheese: "bg-chip-cheese text-primary-ink",
  sauce: "bg-chip-sauce text-fg",
};

function Chip({ ing }: { ing: Ing }) {
  return (
    <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${CHIP[ing]}`}>{ING_LABEL[ing]}</span>
  );
}

const Joystick = memo(function Joystick() {
  const drag = useRef<{ id: number; ox: number; oy: number } | null>(null);
  const [vis, setVis] = useState({ on: false, x: 0, y: 0, dx: 0, dy: 0 });

  useEffect(() => {
    return () => {
      input.joyX = 0;
      input.joyY = 0;
    };
  }, []);

  function apply(clientX: number, clientY: number) {
    const origin = drag.current;
    if (!origin) return;
    let dx = clientX - origin.ox;
    let dy = clientY - origin.oy;
    const max = 58;
    const mag = Math.hypot(dx, dy);
    if (mag > max) {
      dx = (dx / mag) * max;
      dy = (dy / mag) * max;
    }
    const stuck = radialDeadzone(dx / max, -dy / max);
    input.joyX = stuck.x;
    input.joyY = stuck.y;
    setVis({ on: true, x: origin.ox, y: origin.oy, dx, dy });
  }

  function end(id: number) {
    if (drag.current?.id !== id) return;
    drag.current = null;
    input.joyX = 0;
    input.joyY = 0;
    setVis({ on: false, x: 0, y: 0, dx: 0, dy: 0 });
  }

  return (
    <div
      className="absolute bottom-0 left-0 top-14 z-10 w-1/2 touch-none"
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        event.preventDefault();
        event.currentTarget.setPointerCapture(event.pointerId);
        drag.current = { id: event.pointerId, ox: event.clientX, oy: event.clientY };
        apply(event.clientX, event.clientY);
      }}
      onPointerMove={(event) => {
        if (drag.current?.id !== event.pointerId) return;
        apply(event.clientX, event.clientY);
      }}
      onPointerUp={(event) => end(event.pointerId)}
      onPointerCancel={(event) => end(event.pointerId)}
      aria-label="Walk joystick"
    >
      <div
        className="pointer-events-none fixed z-10 h-36 w-36 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-line bg-surface/75"
        style={
          vis.on
            ? { left: vis.x, top: vis.y }
            : { left: "6.25rem", top: "auto", bottom: "7.5rem", transform: "translate(-50%, 0)" }
        }
      >
        <div
          className="absolute left-1/2 top-1/2 h-14 w-14 rounded-full bg-primary shadow-md"
          style={{ transform: `translate(calc(-50% + ${vis.dx}px), calc(-50% + ${vis.dy}px))` }}
        />
      </div>
    </div>
  );
});

const LookPad = memo(function LookPad() {
  const drag = useRef<{ id: number; x: number; y: number } | null>(null);

  function end(id: number) {
    if (drag.current?.id === id) drag.current = null;
  }

  return (
    <div
      className="absolute bottom-0 left-1/2 right-0 top-14 z-10 touch-none"
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        event.preventDefault();
        event.currentTarget.setPointerCapture(event.pointerId);
        drag.current = { id: event.pointerId, x: event.clientX, y: event.clientY };
      }}
      onPointerMove={(event) => {
        const current = drag.current;
        if (!current || current.id !== event.pointerId) return;
        pushLook(event.clientX - current.x, event.clientY - current.y);
        current.x = event.clientX;
        current.y = event.clientY;
      }}
      onPointerUp={(event) => end(event.pointerId)}
      onPointerCancel={(event) => end(event.pointerId)}
      aria-label="Look around"
    />
  );
});

function OverlayCard({
  kicker,
  title,
  body,
  children,
}: {
  kicker: string;
  title: string;
  body: string;
  children: ReactNode;
}) {
  return (
    <div className="absolute inset-0 z-40 flex items-end justify-center p-4 pt-20 sm:items-center">
      <div className="w-full max-w-md rounded-2xl border border-line bg-surface p-6 text-fg shadow-2xl">
        <p className="text-xs font-semibold tracking-widest text-primary uppercase">{kicker}</p>
        <h1 className="font-display mt-1 text-4xl leading-tight font-semibold sm:text-5xl">{title}</h1>
        <p className="mt-3 text-base leading-relaxed text-muted">{body}</p>
        {children}
      </div>
    </div>
  );
}

function ActionButton({
  children,
  onClick,
  tone = "primary",
}: {
  children: ReactNode;
  onClick: () => void;
  tone?: "primary" | "quiet";
}) {
  const toneClass =
    tone === "primary"
      ? "bg-primary text-primary-ink"
      : "bg-surface-2 text-fg";
  return (
    <button
      type="button"
      onClick={onClick}
      className={`mt-3 w-full rounded-full px-6 py-4 text-lg font-semibold ${toneClass}`}
    >
      {children}
    </button>
  );
}

export function ShawarmaGame() {
  const hud = useHud();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let alive = true;
    let cleanup = () => {};
    void import("./engine").then(({ mountGame }) => {
      if (!alive || !canvasRef.current) return;
      cleanup = mountGame(canvasRef.current);
    });
    return () => {
      alive = false;
      cleanup();
    };
  }, []);

  const playing = hud.phase === "playing";
  const patienceTone = hud.patience > 0.5 ? "bg-good" : hud.patience > 0.25 ? "bg-primary" : "bg-accent";
  const goalPct = hud.goal > 0 ? Math.min(100, (hud.money / hud.goal) * 100) : 0;

  return (
    <main aria-label="Shawarma Legend" className="fixed inset-0 overflow-hidden bg-bg text-fg select-none">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />
      <div className="vignette pointer-events-none absolute inset-0" />

      {playing && (
        <>
          <Joystick />
          <LookPad />
        </>
      )}

      <header className="absolute inset-x-0 top-0 z-20 flex h-14 items-center gap-2 bg-bg/85 px-3 text-fg">
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">Day {hud.day}</p>
          <p className="flex items-center gap-1 text-xs text-muted">
            <Coins className="size-3.5 text-primary" aria-hidden="true" />
            {hud.money} / {hud.goal}
          </p>
        </div>
        <p className={`flex items-center gap-1 text-sm font-semibold ${hud.timeLeft <= 10 && playing ? "text-accent" : "text-fg"}`}>
          <Timer className="size-4" aria-hidden="true" />
          {Math.ceil(hud.timeLeft)}s
        </p>
        <button
          type="button"
          className="flex size-11 items-center justify-center rounded-full bg-surface-2 text-fg"
          aria-label={hud.muted ? "Unmute" : "Mute"}
          onClick={() => gameCommand("toggleMute")}
        >
          {hud.muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
        </button>
        {playing && (
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-full bg-surface-2 text-fg"
            aria-label="Pause"
            onClick={() => gameCommand("pause")}
          >
            <Pause className="size-5" />
          </button>
        )}
        <div className="absolute inset-x-0 bottom-0 h-1 bg-surface-2">
          <div className="h-full bg-primary" style={{ width: `${goalPct}%` }} />
        </div>
      </header>

      {(playing || hud.phase === "paused") && (
        <section className="pointer-events-none absolute inset-x-0 top-16 z-20 flex justify-center px-3">
          <div className="w-full max-w-md rounded-2xl border border-line bg-surface/92 p-3">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-display text-lg leading-tight font-semibold">
                  {hud.customerHere ? hud.customerName : "Counter is clear"}
                </p>
                <p className="text-sm text-muted">
                  {hud.customerHere ? `${hud.recipeName} · ${hud.price}` : "Next guest is on the way"}
                </p>
              </div>
              <Utensils className="mt-1 size-5 shrink-0 text-primary" aria-hidden="true" />
            </div>
            {hud.customerHere && (
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-bg">
                <div className={`h-full ${patienceTone}`} style={{ width: `${hud.patience * 100}%` }} />
              </div>
            )}
            {hud.customerHere && (
              <div className="mt-2 flex flex-wrap gap-1.5">
                {hud.order.map((ing, index) => (
                  <Chip key={`${ing}-${index}`} ing={ing} />
                ))}
              </div>
            )}
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-semibold text-muted">Plate</span>
              {hud.plate.length === 0 && <span className="text-xs text-muted">Empty</span>}
              {hud.plate.map((ing, index) => (
                <Chip key={`plate-${ing}-${index}`} ing={ing} />
              ))}
            </div>
            {hud.cook.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1.5">
                {hud.cook.map((job) => (
                  <span key={job.id} className="rounded-full bg-bg px-2 py-1 text-xs font-semibold text-fg">
                    {job.label} {job.ready ? "ready" : `${Math.round(job.p * 100)}%`}
                  </span>
                ))}
              </div>
            )}
          </div>
        </section>
      )}

      {playing && (
        <>
          <div className="pointer-events-none absolute top-1/2 left-1/2 z-20 h-5 w-5 -translate-x-1/2 -translate-y-1/2">
            <div className={`absolute top-0 left-1/2 h-full w-0.5 -translate-x-1/2 ${hud.canAct ? "bg-primary" : "bg-fg/80"}`} />
            <div className={`absolute top-1/2 left-0 h-0.5 w-full -translate-y-1/2 ${hud.canAct ? "bg-primary" : "bg-fg/80"}`} />
          </div>
          {hud.detail && (
            <p className="pointer-events-none absolute top-1/2 left-1/2 z-20 mt-8 -translate-x-1/2 rounded-full bg-bg/80 px-3 py-1 text-sm font-semibold text-fg">
              {hud.detail}
            </p>
          )}
          {hud.hints && (
            <p className="pointer-events-none absolute bottom-36 left-1/2 z-20 w-full max-w-sm -translate-x-1/2 px-6 text-center text-sm font-semibold text-fg">
              Left stick walks. Drag the right side to look.
            </p>
          )}
          <button
            type="button"
            className={`dock-b absolute right-5 z-20 h-16 min-w-28 rounded-full px-5 text-base font-semibold ${
              hud.canAct ? "bg-primary text-primary-ink" : "bg-surface-2 text-muted"
            }`}
            onPointerDown={(event) => {
              event.stopPropagation();
              event.preventDefault();
              requestInteract();
            }}
          >
            {hud.verb}
          </button>
        </>
      )}

      {hud.toast && (playing || hud.phase === "paused") && (
        <p
          aria-live="polite"
          className={`pointer-events-none absolute top-1/3 left-1/2 z-30 -translate-x-1/2 rounded-full px-4 py-2 text-sm font-semibold ${
            hud.toastTone === "good"
              ? "bg-good text-primary-ink"
              : hud.toastTone === "bad"
                ? "bg-accent text-fg"
                : "bg-surface text-fg"
          }`}
        >
          {hud.toast}
        </p>
      )}

      {hud.phase === "menu" && (
        <OverlayCard
          kicker="Night stall"
          title="Shawarma Legend"
          body="Walk the kitchen, cook what the order asks for, and serve it at the window before they give up."
        >
          <ul className="mt-4 space-y-2 text-sm leading-relaxed">
            <li>
              <span className="font-semibold text-primary">Left side</span>
              <span className="text-muted"> — joystick walks you around</span>
            </li>
            <li>
              <span className="font-semibold text-primary">Right side</span>
              <span className="text-muted"> — drag to look and turn</span>
            </li>
            <li>
              <span className="font-semibold text-primary">Use</span>
              <span className="text-muted"> — run the station in your crosshair</span>
            </li>
          </ul>
          <p className="mt-3 text-sm text-muted">Keyboard: WASD walks, drag the right side to look, E uses a station.</p>
          <ActionButton onClick={() => gameCommand("start")}>Start</ActionButton>
          {hud.bestDay > 0 && (
            <p className="mt-3 text-center text-sm text-muted">
              Best day {hud.bestDay}
              {hud.bestMoney > 0 ? ` · ${hud.bestMoney} in one shift` : ""}
            </p>
          )}
        </OverlayCard>
      )}

      {hud.phase === "paused" && (
        <OverlayCard kicker="Holding" title="Paused" body="The spit can wait. Customers will not.">
          <ActionButton onClick={() => gameCommand("resume")}>Resume</ActionButton>
          <ActionButton tone="quiet" onClick={() => gameCommand("quit")}>
            Back to menu
          </ActionButton>
        </OverlayCard>
      )}

      {hud.phase === "win" && (
        <OverlayCard
          kicker={`Day ${hud.day} clear`}
          title="Sold out happy"
          body={`You made ${hud.money}. The goal was ${hud.goal}. The street is still hungry.`}
        >
          <ActionButton onClick={() => gameCommand("nextDay")}>Next day</ActionButton>
          <ActionButton tone="quiet" onClick={() => gameCommand("quit")}>
            Back to menu
          </ActionButton>
        </OverlayCard>
      )}

      {hud.phase === "lose" && (
        <OverlayCard
          kicker={`Day ${hud.day}`}
          title="Shift over"
          body={`You made ${hud.money} and needed ${hud.goal}. The grill is still hot.`}
        >
          <ActionButton onClick={() => gameCommand("retry")}>Try this day again</ActionButton>
          <ActionButton tone="quiet" onClick={() => gameCommand("quit")}>
            Back to menu
          </ActionButton>
        </OverlayCard>
      )}
    </main>
  );
}
