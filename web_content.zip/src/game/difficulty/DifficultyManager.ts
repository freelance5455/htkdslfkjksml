export type DifficultyLevel = 'easy' | 'normal' | 'hard' | 'custom';

export interface DifficultySettings {
  level: DifficultyLevel;
  healthMultiplier: number;
  damageMultiplier: number;
  speedMultiplier: number;
  intelligence: 'basic' | 'normal' | 'tactical';
  spawnRate: 'slow' | 'normal' | 'fast';
  attackCooldown: number;
  maxZombies: number;
}

export const DIFFICULTY_PRESETS: Record<DifficultyLevel, DifficultySettings> = {
  easy: {
    level: 'easy',
    healthMultiplier: 0.7,
    damageMultiplier: 0.65,
    speedMultiplier: 0.9, // Classic slow shambling zombie pace
    intelligence: 'basic',
    spawnRate: 'slow',
    attackCooldown: 1.6,
    maxZombies: 16,
  },
  normal: {
    level: 'normal',
    healthMultiplier: 1.0,
    damageMultiplier: 1.0,
    speedMultiplier: 1.0,
    intelligence: 'normal',
    spawnRate: 'normal',
    attackCooldown: 1.2,
    maxZombies: 24,
  },
  hard: {
    level: 'hard',
    healthMultiplier: 1.35,
    damageMultiplier: 1.3,
    speedMultiplier: 1.1, // Requirement 3: Only slightly increased! Keeps zombies feeling like zombies
    intelligence: 'tactical',
    spawnRate: 'fast',
    attackCooldown: 0.95,
    maxZombies: 30,
  },
  custom: {
    level: 'custom',
    healthMultiplier: 1.0,
    damageMultiplier: 1.0,
    speedMultiplier: 1.0,
    intelligence: 'normal',
    spawnRate: 'normal',
    attackCooldown: 1.2,
    maxZombies: 24,
  },
};

const STORAGE_KEY = 'omega_outbreak_difficulty';

export class DifficultyManager {
  private static current: DifficultySettings | null = null;

  static get(): DifficultySettings {
    if (this.current) return this.current;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        this.current = JSON.parse(saved);
        return this.current!;
      }
    } catch {
      // Fallback
    }
    this.current = { ...DIFFICULTY_PRESETS.normal };
    return this.current;
  }

  static set(settings: DifficultySettings) {
    this.current = { ...settings };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    } catch {
      // Ignore
    }
  }

  static setLevel(level: DifficultyLevel): DifficultySettings {
    const s = { ...DIFFICULTY_PRESETS[level] };
    this.set(s);
    return s;
  }
}
