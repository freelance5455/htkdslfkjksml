export interface ShapeTemplate {
  id: string;
  name: string;
  emoji: string;
  gridWidth: number;
  gridHeight: number;
  pattern: string[];
}

/**
 * Recognizable shapes formed by MANY small compact tiles packed closely together:
 * Heart, Duck, Rooster, House, Cat, Dog, Flower, Tree, Car, Star, Fish, Crown,
 * Mushroom, Butterfly, Robot, Boat, Sword, Apple, Anchor, Rocket, etc.
 *
 * 'X' = small arrow tile
 * '.' or ' ' = empty space
 */
export const SHAPE_DESIGNS: ShapeTemplate[] = [
  // 1. Starter Heart (Level 1) ~ 27 tiles
  {
    id: 'heart',
    name: 'Heart',
    emoji: '❤️',
    gridWidth: 9,
    gridHeight: 8,
    pattern: [
      '.........',
      '..XX.XX..',
      '.XXXXXXX.',
      '.XXXXXXX.',
      '..XXXXX..',
      '...XXX...',
      '....X....',
      '.........',
    ],
  },

  // 2. Duck (Level 2) ~ 34 tiles
  {
    id: 'duck',
    name: 'Duck',
    emoji: '🦆',
    gridWidth: 10,
    gridHeight: 9,
    pattern: [
      '...XXX....',
      '.XXXXX....',
      '..XXXX....',
      '...XX.....',
      '..XXXXX...',
      '.XXXXXXXX.',
      'XXXXXXXXXX',
      '.XXXXXXXX.',
      '..XX..XX..',
    ],
  },

  // 3. House (Level 3) ~ 38 tiles
  {
    id: 'house',
    name: 'House',
    emoji: '🏠',
    gridWidth: 10,
    gridHeight: 9,
    pattern: [
      '....XX....',
      '...XXXX...',
      '..XXXXXX..',
      '.XXXXXXXX.',
      'XXXXXXXXXX',
      '.XXXXXXXX.',
      '.XX.XX.XX.',
      '.XX....XX.',
      '.XX....XX.',
    ],
  },

  // 4. Star (Level 4) ~ 43 tiles
  {
    id: 'star',
    name: 'Star',
    emoji: '⭐',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '.....X.....',
      '....XXX....',
      '....XXX....',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      '..XXXXXXX..',
      '.XXXXXXXXX.',
      'XXXX...XXXX',
      'XXX.....XXX',
      'XX.......XX',
      '...........',
    ],
  },

  // 5. Tree (Level 5) ~ 46 tiles
  {
    id: 'tree',
    name: 'Tree',
    emoji: '🌲',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '.....X.....',
      '....XXX....',
      '...XXXXX...',
      '....XXX....',
      '..XXXXXXX..',
      '.XXXXXXXXX.',
      '..XXXXXXX..',
      'XXXXXXXXXXX',
      '.....XX.....',
      '.....XX.....',
      '....XXXX....',
    ],
  },

  // 6. Cat (Level 6) ~ 50 tiles
  {
    id: 'cat',
    name: 'Cat',
    emoji: '🐱',
    gridWidth: 11,
    gridHeight: 10,
    pattern: [
      '.XX.....XX.',
      '.XXX...XXX.',
      '.XXXXXXXXX.',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      '..XXXXXXX..',
      '...XXXXX...',
      '..XXXXXXX..',
      '.XX.....XX.',
    ],
  },

  // 7. Flower (Level 7) ~ 48 tiles
  {
    id: 'flower',
    name: 'Flower',
    emoji: '🌸',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '....XXX....',
      '...XXXXX...',
      '.XX..X..XX.',
      'XXXXXXX.XXXX',
      'XXXX.X.XXXX',
      '.XX..X..XX.',
      '....XXX....',
      '.....X.....',
      '..XXXX.....',
      '.....XXXX..',
      '.....X.....',
    ],
  },

  // 8. Car (Level 8) ~ 52 tiles
  {
    id: 'car',
    name: 'Car',
    emoji: '🚗',
    gridWidth: 11,
    gridHeight: 8,
    pattern: [
      '...XXXXX...',
      '..XXXXXXXX.',
      '.XXXXXXXXXX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      '.XX.XXX.XX.',
      '.XX.....XX.',
      '...........',
    ],
  },

  // 9. Rooster (Level 9) ~ 56 tiles
  {
    id: 'rooster',
    name: 'Rooster',
    emoji: '🐓',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '....XXX....',
      '..XXXXXX...',
      '.XXXXXX....',
      '..XXXX.....',
      '.XXXXXXXXX.',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      '..XXXXXXX..',
      '...XX.XX...',
      '..XXX.XXX..',
    ],
  },

  // 10. Dog (Level 10) ~ 58 tiles
  {
    id: 'dog',
    name: 'Dog',
    emoji: '🐶',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '.XX.....XX.',
      'XXXX...XXXX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      '..XXXXXXX..',
      '...XXXXX...',
      '..XXXXXXX..',
      '.XXXXXXXXX.',
      '.XX.XXX.XX.',
      '.XX.....XX.',
    ],
  },

  // 11. Crown (Level 11) ~ 54 tiles
  {
    id: 'crown',
    name: 'Crown',
    emoji: '👑',
    gridWidth: 11,
    gridHeight: 8,
    pattern: [
      'X....X....X',
      'XX..XXX..XX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      '...........',
    ],
  },

  // 12. Mushroom (Level 12) ~ 56 tiles
  {
    id: 'mushroom',
    name: 'Mushroom',
    emoji: '🍄',
    gridWidth: 11,
    gridHeight: 10,
    pattern: [
      '....XXX....',
      '..XXXXXXX..',
      '.XXXXXXXXX.',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      '..XXXXXXX..',
      '...XXXXX...',
      '...XXXXX...',
      '...XXXXX...',
      '..XXXXXXX..',
    ],
  },

  // 13. Fish (Level 13) ~ 52 tiles
  {
    id: 'fish',
    name: 'Fish',
    emoji: '🐟',
    gridWidth: 11,
    gridHeight: 9,
    pattern: [
      '.....XX....',
      '...XXXXXX..',
      'X.XXXXXXXX.',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      'X.XXXXXXXX.',
      '...XXXXXX..',
      '.....XX....',
      '...........',
    ],
  },

  // 14. Butterfly (Level 14) ~ 58 tiles
  {
    id: 'butterfly',
    name: 'Butterfly',
    emoji: '🦋',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      'X.........X',
      'XX...X...XX',
      'XXXX.X.XXXX',
      'XXXXXXX.XXXX',
      '.XXXX.X.XXXX.',
      '..XX.X.XX..',
      '.XXXX.X.XXXX.',
      'XXXX...XXXX',
      'XXX.....XXX',
      '.X.......X.',
      '...........',
    ],
  },

  // 15. Robot (Level 15) ~ 60 tiles
  {
    id: 'robot',
    name: 'Robot',
    emoji: '🤖',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '.....X.....',
      '....XXX....',
      '..XXXXXXX..',
      '..XX.X.XX..',
      '..XXXXXXX..',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      '.XX.XXX.XX.',
      '.XXXXXXXXX.',
      '..XX...XX..',
      '..XX...XX..',
    ],
  },

  // 16. Sailboat (Level 16) ~ 56 tiles
  {
    id: 'sailboat',
    name: 'Sailboat',
    emoji: '⛵',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '.....X.....',
      '....XX.....',
      '...XXX..X..',
      '..XXXX..XX.',
      '.XXXXX..XXX',
      'XXXXXX..XXXX',
      '.....X.....',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      '..XXXXXXX..',
      '...........',
    ],
  },

  // 17. Sword (Level 17) ~ 32 tiles
  {
    id: 'sword',
    name: 'Sword',
    emoji: '🗡️',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '.....X.....',
      '....XXX....',
      '....XXX....',
      '....XXX....',
      '....XXX....',
      '....XXX....',
      'XXXXXXXXXXX',
      '.....X.....',
      '.....X.....',
      '....XXX....',
      '...........',
    ],
  },

  // 18. Apple (Level 18) ~ 64 tiles
  {
    id: 'apple',
    name: 'Apple',
    emoji: '🍎',
    gridWidth: 11,
    gridHeight: 10,
    pattern: [
      '.....XX....',
      '....XX.....',
      '..XXXXXXX..',
      '.XXXXXXXXX.',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      '..XXXXXXX..',
      '...XX.XX...',
    ],
  },

  // 19. Anchor (Level 19) ~ 52 tiles
  {
    id: 'anchor',
    name: 'Anchor',
    emoji: '⚓',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '....XXX....',
      '....X.X....',
      '....XXX....',
      '..XXXXXXX..',
      '.....X.....',
      '.....X.....',
      'X....X....X',
      'XX...X...XX',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      '..XXXXXXX..',
    ],
  },

  // 20. Rocket (Level 20) ~ 56 tiles
  {
    id: 'rocket',
    name: 'Rocket',
    emoji: '🚀',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '.....X.....',
      '....XXX....',
      '....XXX....',
      '...XXXXX...',
      '...XX.XX...',
      '...XXXXX...',
      '..XXXXXXX..',
      '.XXXXXXXXX.',
      'XXXXXXXXXXX',
      '..XX...XX..',
      '.X..X.X..X.',
    ],
  },

  // 21. Guitar (Level 21) ~ 44 tiles
  {
    id: 'guitar',
    name: 'Guitar',
    emoji: '🎸',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '....XX.....',
      '....XX.....',
      '....XX.....',
      '....XX.....',
      '...XXXX....',
      '..XXXXXX...',
      '.XXXXXXXX..',
      '.XXXXXXXX..',
      '..XXXXXX...',
      '...XXXX....',
      '...........',
    ],
  },

  // 22. Ghost (Level 22) ~ 66 tiles
  {
    id: 'ghost',
    name: 'Ghost',
    emoji: '👻',
    gridWidth: 11,
    gridHeight: 10,
    pattern: [
      '...XXXXX...',
      '..XXXXXXX..',
      '.XXXXXXXXX.',
      '.X.XXXXX.X.',
      '.XXXXXXXXX.',
      '.XXXXXXXXX.',
      '.XXXXXXXXX.',
      '.XXXXXXXXX.',
      'XX.XX.XX.XX',
      'X...X.X...X',
    ],
  },

  // 23. Diamond (Level 23) ~ 52 tiles
  {
    id: 'diamond',
    name: 'Diamond',
    emoji: '💎',
    gridWidth: 11,
    gridHeight: 9,
    pattern: [
      '..XXXXXXX..',
      '.XXXXXXXXX.',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      '..XXXXXXX..',
      '...XXXXX...',
      '....XXX....',
      '.....X.....',
      '...........',
    ],
  },

  // 24. Coffee Cup (Level 24) ~ 58 tiles
  {
    id: 'coffee',
    name: 'Coffee Cup',
    emoji: '☕',
    gridWidth: 11,
    gridHeight: 9,
    pattern: [
      '..X...X....',
      '...X...X...',
      'XXXXXXXXX..',
      'XXXXXXXXXXX',
      'XXXXXXXX.XX',
      'XXXXXXXX.XX',
      '.XXXXXXX.XX',
      '..XXXXX.XX.',
      '..XXXXXXX..',
    ],
  },

  // 25. Moon & Star (Level 25) ~ 53 tiles
  {
    id: 'moon',
    name: 'Moon & Star',
    emoji: '🌙',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '..XXXX.....',
      '.XXXXXX....',
      'XXXXXXX..X.',
      'XXXX....XXX',
      'XXXX.....X.',
      'XXXX.......',
      'XXXX.......',
      'XXXX.......',
      '.XXXXXX....',
      '..XXXXX....',
      '...........',
    ],
  },

  // 26. Gamepad (Level 26) ~ 61 tiles
  {
    id: 'gamepad',
    name: 'Gamepad',
    emoji: '🎮',
    gridWidth: 11,
    gridHeight: 8,
    pattern: [
      '.XXXXXXXXX.',
      'XXXXXXXXXXX',
      'XX.XXXXX.XX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      'XXX.....XXX',
      'XX.......XX',
      '...........',
    ],
  },

  // 27. Key (Level 27) ~ 29 tiles
  {
    id: 'key',
    name: 'Key',
    emoji: '🗝️',
    gridWidth: 11,
    gridHeight: 7,
    pattern: [
      '..XXXX.....',
      '.XX..XX....',
      'XXXXXXXXXXX',
      '.XX..XX.X.X',
      '..XXXX.....',
      '...........',
      '...........',
    ],
  },

  // 28. Sun (Level 28) ~ 47 tiles
  {
    id: 'sun',
    name: 'Sun',
    emoji: '☀️',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '.....X.....',
      '.X...X...X.',
      '..XXXXXXX..',
      '..XXXXXXX..',
      'XXXXXXXXXXX',
      '..XXXXXXX..',
      '..XXXXXXX..',
      '.X...X...X.',
      '.....X.....',
      '...........',
      '...........',
    ],
  },

  // 29. Frog (Level 29) ~ 64 tiles
  {
    id: 'frog',
    name: 'Frog',
    emoji: '🐸',
    gridWidth: 11,
    gridHeight: 9,
    pattern: [
      '.XX.....XX.',
      'XXXX...XXXX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      'XXXXXXXXXXX',
      'XX.XXXXX.XX',
      'X...XXX...X',
      '...........',
    ],
  },

  // 30. Airplane (Level 30) ~ 45 tiles
  {
    id: 'airplane',
    name: 'Airplane',
    emoji: '✈️',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '.....X.....',
      '....XXX....',
      '....XXX....',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      '....XXX....',
      '....XXX....',
      '...XXXXX...',
      '..XXXXXXX..',
      '...........',
      '...........',
    ],
  },

  // 31. Earth (Level 31) ~ 99 tiles
  {
    id: 'earth',
    name: 'Earth',
    emoji: '🌍',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '....XXXX...',
      '..XXXXXXXX.',
      '.XXXXXXXXXX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      '.XXXXXXXXXX',
      '..XXXXXXXX.',
      '....XXXX...',
    ],
  },

  // 32. Person (Level 32) ~ 45 tiles
  {
    id: 'person',
    name: 'Person',
    emoji: '🚶',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '....XXX....',
      '....XXX....',
      '....XXX....',
      '..XXXXXXX..',
      '..XXXXXXX..',
      '....XXX....',
      '....XXX....',
      '...XX.XX...',
      '...XX.XX...',
      '..XX...XX..',
      '..XX...XX..',
    ],
  },

  // 33. Planet Saturn (Level 33) ~ 74 tiles
  {
    id: 'planet',
    name: 'Planet Saturn',
    emoji: '🪐',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '........X..',
      '....XXXXX..',
      '..XXXXXXXXX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      'XXXXXXXXX..',
      '..XXXXX....',
      '..X........',
      '...........',
    ],
  },

  // 34. Elephant (Level 34) ~ 76 tiles
  {
    id: 'elephant',
    name: 'Elephant',
    emoji: '🐘',
    gridWidth: 11,
    gridHeight: 10,
    pattern: [
      '....XXXXXX.',
      '...XXXXXXXX',
      '..XXXXXXXXX',
      'X.XXXXXXXXX',
      'X.XXXXXXXXX',
      'X..XXXXXXXX',
      '...XXXXXXXX',
      '...XXXXXXXX',
      '...XX....XX',
      '...XX....XX',
    ],
  },

  // 35. Penguin (Level 35) ~ 72 tiles
  {
    id: 'penguin',
    name: 'Penguin',
    emoji: '🐧',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '....XXX....',
      '...XXXXX...',
      '...X.X.X...',
      '....XXX....',
      '..XXXXXXX..',
      '.XXXXXXXXX.',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      '..XXXXXXX..',
      '...XX.XX...',
    ],
  },

  // 36. Lion (Level 36) ~ 93 tiles
  {
    id: 'lion',
    name: 'Lion',
    emoji: '🦁',
    gridWidth: 11,
    gridHeight: 11,
    pattern: [
      '..XXXXXXX..',
      '.XXXXXXXXX.',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      'XX.XXXXX.XX',
      'XXXXXXXXXXX',
      'XXXXXXXXXXX',
      '.XXXXXXXXX.',
      '..XXXXXXX..',
      '..XX...XX..',
      '..XX...XX..',
    ],
  },
];

/**
 * Parses pattern string into an array of { x, y } coordinates
 */
export function parseShapeCoordinates(pattern: string[]): { x: number; y: number }[] {
  const coords: { x: number; y: number }[] = [];
  for (let y = 0; y < pattern.length; y++) {
    const row = pattern[y];
    for (let x = 0; x < row.length; x++) {
      if (row[x] === 'X' || row[x] === '#' || row[x] === 'O') {
        coords.push({ x, y });
      }
    }
  }
  return coords;
}
