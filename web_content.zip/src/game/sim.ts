import { sfx } from "./audio";
import {
  BUILDINGS,
  COST,
  COTTAGE,
  DECOR,
  FIRE,
  ISLAND_R,
  NIA,
  NODES,
  PADS,
  POND,
  QUESTS,
  SPAWN,
  SPECIES,
  SPECIES_LIST,
  biomeAt,
  daylight,
  workMatch,
  type BuildingType,
  type Decor,
  type NodeKind,
  type QuestId,
  type SpeciesId,
} from "./data";
import { useHud, type Menu } from "./store";

export type Pal = {
  id: number;
  species: SpeciesId;
  wild: boolean;
  x: number;
  z: number;
  yaw: number;
  hp: number;
  maxHp: number;
  level: number;
  xp: number;
  cd: number;
  wander: number;
  tx: number;
  tz: number;
  homeX: number;
  homeZ: number;
  active: boolean;
  workerPad: number | null;
  alive: boolean;
  aggro: boolean;
  shrink: number;
  faint: number;
  flash: number;
  speed: number;
  pending: boolean;
};

export type Building = {
  id: number;
  type: BuildingType;
  pad: number;
  workerId: number | null;
  ticks: number;
};

export type Node = {
  id: number;
  kind: NodeKind;
  x: number;
  z: number;
  amount: number;
  max: number;
  respawn: number;
};

export type Proj = {
  sx: number;
  sy: number;
  sz: number;
  x: number;
  y: number;
  z: number;
  targetId: number;
  t: number;
  alive: boolean;
};

export type Particle = {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
};

type Resources = { wood: number; stone: number; berry: number; orb: number };
type Ever = { wood: number; stone: number; berry: number; caught: number };

export type Sim = {
  mode: "title" | "play";
  paused: boolean;
  time: number;
  day: number;
  acc: number;
  hudAcc: number;
  titleYaw: number;
  camYaw: number;
  autoCam: boolean;
  grace: number;
  battle: number;
  shake: number;
  workAcc: number;
  spawnAcc: number;
  saveAcc: number;
  questAcc: number;
  hasSave: boolean;
  starter: SpeciesId;
  player: {
    x: number;
    z: number;
    yaw: number;
    speed: number;
    hp: number;
    maxHp: number;
    attackCd: number;
    orbCd: number;
    iframes: number;
    lunge: number;
  };
  input: { x: number; z: number; attack: boolean; orb: boolean; use: boolean };
  keys: Set<string>;
  forced: Set<string> | null;
  held: { attack: boolean; orb: boolean; use: boolean; eat: boolean };
  pals: Pal[];
  buildings: Building[];
  nodes: Node[];
  projs: Proj[];
  particles: Particle[];
  resources: Resources;
  ever: Ever;
  discovered: SpeciesId[];
  seen: SpeciesId[];
  questsDone: QuestId[];
  toast: string;
  toastUntil: number;
  line: string;
  lineUntil: number;
  prompt: string;
  targetId: number | null;
  decor: Decor[];
};

const SAVE_KEY = "palmon-lumenrest-v1";
let UID = 1;
let SIM: Sim | null = null;

const solids: { x: number; z: number; r: number }[] = [];

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys: (codes: string[]) => void;
    };
  }
}

function nextId() {
  UID += 1;
  return UID;
}

export function dampAngle(current: number, target: number, speed: number, dt: number) {
  const diff = Math.atan2(Math.sin(target - current), Math.cos(target - current));
  const step = Math.max(-speed * dt, Math.min(speed * dt, diff));
  return current + step;
}

function toast(sim: Sim, text: string) {
  sim.toast = text;
  sim.toastUntil = sim.time + 2.7;
  useHud.getState().bump();
}

function say(sim: Sim, text: string) {
  sim.line = text;
  sim.lineUntil = sim.time + 7.2;
  useHud.getState().bump();
}

function burst(sim: Sim, x: number, y: number, z: number) {
  for (let i = 0; i < 8; i += 1) {
    if (sim.particles.length > 150) sim.particles.shift();
    const a = Math.random() * Math.PI * 2;
    const s = 0.7 + Math.random() * 1.5;
    sim.particles.push({
      x,
      y,
      z,
      vx: Math.cos(a) * s,
      vy: 1.1 + Math.random() * 1.8,
      vz: Math.sin(a) * s,
      life: 0.4 + Math.random() * 0.25,
    });
  }
}

function refreshSolids(sim: Sim) {
  let n = 0;
  const push = (x: number, z: number, r: number) => {
    const s = solids[n] ?? { x: 0, z: 0, r: 0 };
    s.x = x;
    s.z = z;
    s.r = r;
    solids[n] = s;
    n += 1;
  };
  for (const d of sim.decor) {
    if (d.kind === "flower" || d.kind === "reed") continue;
    if (d.kind === "crate") push(d.x, d.z, 0.42 * d.s);
    else if (d.kind === "rock") push(d.x, d.z, 0.62 * d.s);
    else push(d.x, d.z, 0.5 * d.s);
  }
  push(COTTAGE.x, COTTAGE.z, 1.7);
  push(FIRE.x, FIRE.z, 0.5);
  push(NIA.x, NIA.z, 0.38);
  push(POND.x, POND.z, POND.r - 1.55);
  for (const node of sim.nodes) {
    if (node.amount > 0) push(node.x, node.z, node.kind === "stone" ? 0.72 : 0.58);
  }
  for (const b of sim.buildings) {
    const pad = PADS[b.pad];
    if (pad) push(pad.x, pad.z, 1.05);
  }
  solids.length = n;
}

function resolveBody(sim: Sim, x: number, z: number, radius: number) {
  refreshSolids(sim);
  let cx = x;
  let cz = z;
  for (let pass = 0; pass < 2; pass += 1) {
    for (const s of solids) {
      const min = s.r + radius;
      let dx = cx - s.x;
      let dz = cz - s.z;
      let d = Math.hypot(dx, dz);
      if (d < 0.0001) {
        dx = 1;
        dz = 0;
        d = 1;
      }
      if (d < min) {
        const k = min / d;
        cx = s.x + dx * k;
        cz = s.z + dz * k;
      }
    }
    const dist = Math.hypot(cx, cz);
    const max = ISLAND_R - 1.15 - radius;
    if (dist > max) {
      cx = (cx / (dist || 1)) * max;
      cz = (cz / (dist || 1)) * max;
    }
  }
  return { x: cx, z: cz };
}

function makePal(sim: Sim, species: SpeciesId, x: number, z: number, wild: boolean): Pal {
  const spec = SPECIES[species];
  const level = wild ? 1 + Math.floor(Math.random() * 3) : 1;
  const maxHp = spec.hp + (level - 1) * 6;
  return {
    id: nextId(),
    species,
    wild,
    x,
    z,
    yaw: Math.random() * Math.PI * 2,
    hp: maxHp,
    maxHp,
    level,
    xp: 0,
    cd: 0,
    wander: 0,
    tx: x,
    tz: z,
    homeX: x,
    homeZ: z,
    active: false,
    workerPad: null,
    alive: true,
    aggro: false,
    shrink: 0,
    faint: 0,
    flash: 0,
    speed: 0,
    pending: false,
  };
}

function tamedAlive(sim: Sim) {
  return sim.pals.filter((p) => p.alive && !p.wild);
}

export function catchChance(pal: Pal) {
  const spec = SPECIES[pal.species];
  const ratio = pal.hp / pal.maxHp;
  let c = 0.18 + (1 - ratio) * 0.74;
  if (ratio > 0.62) c *= 0.42;
  if (spec.rare) c *= 0.72;
  return Math.max(0.06, Math.min(0.92, c));
}

function pickSpecies(x: number, z: number, day: number): SpeciesId {
  const biome = biomeAt(x, z);
  const night = daylight(day) < 0.42;
  const pool: SpeciesId[] = [];
  for (const s of SPECIES_LIST) {
    const nightOnly = s.biomes.length === 1 && s.biomes[0] === "night";
    if (nightOnly && !night) continue;
    if (s.biomes.includes(biome) || (night && s.biomes.includes("night"))) {
      for (let i = 0; i < s.weight; i += 1) pool.push(s.id);
    }
  }
  if (!pool.length) return "mossbun";
  return pool[Math.floor(Math.random() * pool.length)] ?? "mossbun";
}

function spawnWild(sim: Sim) {
  for (let i = 0; i < 24; i += 1) {
    const ang = Math.random() * Math.PI * 2;
    const dist = 14 + Math.random() * 24;
    const x = Math.cos(ang) * dist;
    const z = Math.sin(ang) * dist;
    const p = resolveBody(sim, x, z, 0.4);
    if (Math.hypot(p.x - sim.player.x, p.z - sim.player.z) < 11) continue;
    if (Math.hypot(p.x - POND.x, p.z - POND.z) < POND.r - 1.2) continue;
    const species = pickSpecies(p.x, p.z, sim.day);
    const pal = makePal(sim, species, p.x, p.z, true);
    sim.pals.push(pal);
    return;
  }
}

function moveToward(sim: Sim, pal: Pal, tx: number, tz: number, speed: number, dt: number) {
  let dx = tx - pal.x;
  let dz = tz - pal.z;
  const d = Math.hypot(dx, dz);
  if (d < 0.08) {
    pal.speed = 0;
    return;
  }
  const step = Math.min(d, speed * dt);
  dx /= d;
  dz /= d;
  pal.x += dx * step;
  pal.z += dz * step;
  const fixed = resolveBody(sim, pal.x, pal.z, 0.32);
  pal.x = fixed.x;
  pal.z = fixed.z;
  pal.yaw = dampAngle(pal.yaw, Math.atan2(-dx, -dz), 8, dt);
  pal.speed = step / dt;
}

function damagePal(sim: Sim, pal: Pal, dmg: number) {
  if (!pal.alive || pal.faint > 0 || pal.shrink > 0 || pal.pending) return;
  pal.hp -= dmg;
  pal.flash = 0.14;
  pal.aggro = true;
  burst(sim, pal.x, 0.7, pal.z);
  if (pal.hp <= 0) {
    pal.hp = 0;
    pal.faint = 0.48;
    pal.aggro = false;
    toast(sim, `${SPECIES[pal.species].name} fainted — throw a Palorb sooner`);
    sfx("faint");
  }
}

function finishCatch(sim: Sim, pal: Pal) {
  if (tamedAlive(sim).length >= 10) {
    sim.resources.orb += 1;
    toast(sim, "The yard is full — 10 Palmons");
    useHud.getState().bumpRoster();
    return;
  }
  const tamed = makePal(sim, pal.species, pal.x, pal.z, false);
  tamed.level = Math.max(1, pal.level);
  tamed.maxHp = SPECIES[pal.species].hp + (tamed.level - 1) * 6;
  tamed.hp = tamed.maxHp;
  tamed.active = !sim.pals.some((p) => p.alive && !p.wild && p.active);
  sim.pals.push(tamed);
  if (!sim.discovered.includes(pal.species)) sim.discovered.push(pal.species);
  if (!sim.seen.includes(pal.species)) sim.seen.push(pal.species);
  sim.ever.caught += 1;
  sfx("catch");
  useHud.getState().bumpRoster();
  saveSim(sim);
}

function resolveOrb(sim: Sim, proj: Proj) {
  const pal = sim.pals.find((p) => p.id === proj.targetId);
  if (!pal || !pal.alive || !pal.wild || pal.faint > 0 || pal.pending) return;
  const chance = catchChance(pal);
  if (Math.random() > chance) {
    toast(sim, `${SPECIES[pal.species].name} broke free (${Math.round(chance * 100)}%)`);
    sfx("fail");
    pal.flash = 0.2;
    pal.aggro = true;
    return;
  }
  if (tamedAlive(sim).length >= 10) {
    sim.resources.orb += 1;
    toast(sim, "The yard is full — 10 Palmons");
    return;
  }
  pal.pending = true;
  pal.shrink = 0.4;
  pal.aggro = false;
  toast(sim, `Caught ${SPECIES[pal.species].name}!`);
  burst(sim, pal.x, 0.8, pal.z);
}

function nearestWild(sim: Sim, x: number, z: number, range: number) {
  let best: Pal | null = null;
  let bestD = range;
  for (const pal of sim.pals) {
    if (!pal.alive || !pal.wild || pal.faint > 0 || pal.shrink > 0 || pal.pending) continue;
    const d = Math.hypot(pal.x - x, pal.z - z);
    if (d < bestD) {
      bestD = d;
      best = pal;
    }
  }
  return best;
}

function attack(sim: Sim) {
  if (sim.player.attackCd > 0) return;
  sim.player.attackCd = 0.42;
  sim.player.lunge = 0.18;
  sim.battle = 2.3;
  sfx("hit");
  const fx = -Math.sin(sim.player.yaw);
  const fz = -Math.cos(sim.player.yaw);
  let hit = false;
  for (const pal of sim.pals) {
    if (!pal.alive || !pal.wild || pal.shrink > 0 || pal.faint > 0 || pal.pending) continue;
    const dx = pal.x - sim.player.x;
    const dz = pal.z - sim.player.z;
    const d = Math.hypot(dx, dz);
    if (d > 2.25 || d < 0.001) continue;
    const dot = (dx / d) * fx + (dz / d) * fz;
    if (dot < 0.22) continue;
    damagePal(sim, pal, 10);
    hit = true;
  }
  if (hit) sim.shake = Math.min(0.4, sim.shake + 0.16);
}

function throwOrb(sim: Sim) {
  if (sim.player.orbCd > 0) return;
  if (sim.resources.orb <= 0) {
    toast(sim, "No Palorbs — cook 3 berries at the fire");
    return;
  }
  const target = sim.pals.find((p) => p.id === sim.targetId && p.alive && p.wild && p.faint <= 0 && !p.pending);
  if (!target) {
    toast(sim, "No wild Palmon ahead");
    return;
  }
  if (Math.hypot(target.x - sim.player.x, target.z - sim.player.z) > 12) {
    toast(sim, "Too far for a Palorb");
    return;
  }
  if (tamedAlive(sim).length >= 10) {
    toast(sim, "The yard is full — 10 Palmons");
    return;
  }
  sim.resources.orb -= 1;
  sim.player.orbCd = 0.55;
  sim.projs.push({
    sx: sim.player.x,
    sy: 1.15,
    sz: sim.player.z,
    x: sim.player.x,
    y: 1.15,
    z: sim.player.z,
    targetId: target.id,
    t: 0,
    alive: true,
  });
  sfx("throw");
}

function currentQuest(sim: Sim) {
  return QUESTS.find((q) => !sim.questsDone.includes(q.id)) ?? null;
}

function computePrompt(sim: Sim) {
  const p = sim.player;
  let best = 2.4;
  let label = "";
  for (const n of sim.nodes) {
    if (n.amount <= 0) continue;
    const d = Math.hypot(n.x - p.x, n.z - p.z);
    if (d < best) {
      best = d;
      label = n.kind === "wood" ? "Gather wood" : n.kind === "stone" ? "Gather stone" : "Pick berries";
    }
  }
  const fire = Math.hypot(FIRE.x - p.x, FIRE.z - p.z);
  if (fire < best) {
    best = fire;
    label = "Cook a Palorb · 3 berries";
  }
  const nia = Math.hypot(NIA.x - p.x, NIA.z - p.z);
  if (nia < best) label = "Talk to Nia";
  return label;
}

function interact(sim: Sim) {
  const p = sim.player;
  let best = 2.4;
  let kind: "node" | "fire" | "nia" | null = null;
  let node: Node | null = null;
  for (const n of sim.nodes) {
    if (n.amount <= 0) continue;
    const d = Math.hypot(n.x - p.x, n.z - p.z);
    if (d < best) {
      best = d;
      kind = "node";
      node = n;
    }
  }
  const fire = Math.hypot(FIRE.x - p.x, FIRE.z - p.z);
  if (fire < best) {
    best = fire;
    kind = "fire";
    node = null;
  }
  const nia = Math.hypot(NIA.x - p.x, NIA.z - p.z);
  if (nia < best) kind = "nia";
  if (kind === "node" && node) {
    node.amount -= 1;
    if (node.kind === "wood") {
      sim.resources.wood += 1;
      sim.ever.wood += 1;
      toast(sim, "+1 wood");
    } else if (node.kind === "stone") {
      sim.resources.stone += 1;
      sim.ever.stone += 1;
      toast(sim, "+1 stone");
    } else {
      sim.resources.berry += 1;
      sim.ever.berry += 1;
      toast(sim, "+1 berry");
    }
    if (node.amount <= 0) node.respawn = 22;
    burst(sim, node.x, 0.8, node.z);
    sfx("gather");
  } else if (kind === "fire") {
    if (sim.resources.berry >= 3) {
      sim.resources.berry -= 3;
      sim.resources.orb += 1;
      toast(sim, "Cooked a Palorb");
      sfx("build");
    } else toast(sim, "Need 3 berries for a Palorb");
  } else if (kind === "nia") {
    const q = currentQuest(sim);
    say(sim, q ? `Nia: ${q.detail}` : "Nia: The meadow is humming again. Merge twins if you want them stronger.");
    sfx("ui");
  } else toast(sim, "Nothing in reach");
}

function eat(sim: Sim) {
  if (sim.resources.berry <= 0) {
    toast(sim, "No berries to eat");
    return;
  }
  if (sim.player.hp >= sim.player.maxHp) {
    toast(sim, "You already feel fine");
    return;
  }
  sim.resources.berry -= 1;
  sim.player.hp = Math.min(sim.player.maxHp, sim.player.hp + 30);
  toast(sim, "Sweet berry, +30");
  sfx("heal");
}

function grant(sim: Sim, species: SpeciesId, active: boolean) {
  const pal = makePal(sim, species, SPAWN.x + 1.2, SPAWN.z + 0.2, false);
  pal.active = active;
  pal.level = 1;
  pal.maxHp = SPECIES[species].hp;
  pal.hp = pal.maxHp;
  sim.pals.push(pal);
  if (!sim.discovered.includes(species)) sim.discovered.push(species);
  if (!sim.seen.includes(species)) sim.seen.push(species);
  return pal;
}

function checkQuests(sim: Sim) {
  for (const q of QUESTS) {
    if (sim.questsDone.includes(q.id)) continue;
    const ok =
      (q.id === "wood" && sim.ever.wood >= 6) ||
      (q.id === "catch" && sim.ever.caught >= 1) ||
      (q.id === "work" && sim.buildings.some((b) => b.workerId != null)) ||
      (q.id === "kinds" && sim.discovered.length >= 4);
    if (!ok) continue;
    sim.questsDone.push(q.id);
    if (q.id === "wood") sim.resources.berry += 6;
    if (q.id === "catch") sim.resources.orb += 4;
    if (q.id === "work") sim.resources.stone += 6;
    if (q.id === "kinds") {
      const owned = sim.pals.some((p) => p.alive && !p.wild && p.species === "glimmoth");
      if (!owned && tamedAlive(sim).length < 10) grant(sim, "glimmoth", false);
      else {
        sim.resources.orb += 5;
        sim.player.hp = sim.player.maxHp;
      }
      useHud.getState().bumpRoster();
    }
    toast(sim, q.done);
    sfx("build");
    saveSim(sim);
  }
}

function readPad() {
  const pads = navigator.getGamepads?.();
  return pads ? pads[0] : null;
}

function tick(sim: Sim, dt: number) {
  sim.player.attackCd = Math.max(0, sim.player.attackCd - dt);
  sim.player.orbCd = Math.max(0, sim.player.orbCd - dt);
  sim.player.iframes = Math.max(0, sim.player.iframes - dt);
  sim.player.lunge = Math.max(0, sim.player.lunge - dt);
  sim.battle = Math.max(0, sim.battle - dt);
  sim.grace = Math.max(0, sim.grace - dt);
  sim.day = (sim.day + dt / 180) % 1;

  const keys = sim.forced ?? sim.keys;
  let ix = sim.input.x;
  let iz = sim.input.z;
  if (keys.has("KeyA") || keys.has("ArrowLeft")) ix -= 1;
  if (keys.has("KeyD") || keys.has("ArrowRight")) ix += 1;
  if (keys.has("KeyW") || keys.has("ArrowUp")) iz += 1;
  if (keys.has("KeyS") || keys.has("ArrowDown")) iz -= 1;
  const gp = readPad();
  let gpAttack = false;
  let gpOrb = false;
  let gpUse = false;
  if (gp) {
    const ax = gp.axes[0] ?? 0;
    const ay = gp.axes[1] ?? 0;
    if (Math.hypot(ax, ay) > 0.2) {
      ix += ax;
      iz += -ay;
    }
    gpAttack = !!gp.buttons[0]?.pressed;
    gpUse = !!gp.buttons[1]?.pressed;
    gpOrb = !!gp.buttons[2]?.pressed;
  }
  const mag = Math.hypot(ix, iz);
  if (mag > 1) {
    ix /= mag;
    iz /= mag;
  }
  const cam = sim.camYaw;
  const fwdX = -Math.sin(cam);
  const fwdZ = -Math.cos(cam);
  const rightX = Math.cos(cam);
  const rightZ = -Math.sin(cam);
  let mx = fwdX * iz + rightX * ix;
  let mz = fwdZ * iz + rightZ * ix;
  const mlen = Math.hypot(mx, mz);
  const ox = sim.player.x;
  const oz = sim.player.z;
  if (mlen > 0.08) {
    mx /= mlen;
    mz /= mlen;
    const shore = Math.hypot(sim.player.x - POND.x, sim.player.z - POND.z);
    const wet = shore < POND.r + 0.9 && shore > POND.r - 2.3;
    const sp = 7.15 * Math.min(1, mlen) * (wet ? 0.62 : 1);
    sim.player.x += mx * sp * dt;
    sim.player.z += mz * sp * dt;
    const fixed = resolveBody(sim, sim.player.x, sim.player.z, 0.42);
    sim.player.x = fixed.x;
    sim.player.z = fixed.z;
    sim.player.yaw = dampAngle(sim.player.yaw, Math.atan2(-mx, -mz), 12, dt);
  }
  sim.player.speed = Math.hypot(sim.player.x - ox, sim.player.z - oz) / dt;
  if (keys.has("KeyZ")) {
    sim.camYaw += 1.7 * dt;
    sim.autoCam = false;
  }
  if (keys.has("KeyX")) {
    sim.camYaw -= 1.7 * dt;
    sim.autoCam = false;
  }
  if (sim.autoCam) sim.camYaw = dampAngle(sim.camYaw, sim.player.yaw, 3.5, dt);

  const attackDown = keys.has("Space") || keys.has("KeyJ") || sim.input.attack || gpAttack;
  const orbDown = keys.has("KeyF") || keys.has("KeyK") || sim.input.orb || gpOrb;
  const useDown = keys.has("KeyE") || sim.input.use || gpUse;
  const eatDown = keys.has("KeyH");
  if (attackDown && !sim.held.attack) attack(sim);
  if (orbDown && !sim.held.orb) throwOrb(sim);
  if (useDown && !sim.held.use) interact(sim);
  if (eatDown && !sim.held.eat) eat(sim);
  sim.held.attack = attackDown;
  sim.held.orb = orbDown;
  sim.held.use = useDown;
  sim.held.eat = eatDown;

  let restIndex = 0;
  for (const pal of sim.pals) {
    if (!pal.alive) continue;
    pal.flash = Math.max(0, pal.flash - dt);
    pal.cd = Math.max(0, pal.cd - dt);
    if (pal.shrink > 0) {
      pal.shrink -= dt;
      if (pal.shrink <= 0) {
        pal.shrink = 0;
        if (pal.pending) {
          pal.pending = false;
          pal.alive = false;
          finishCatch(sim, pal);
        }
      }
      continue;
    }
    if (pal.faint > 0) {
      pal.faint -= dt;
      if (pal.faint <= 0) {
        pal.alive = false;
        if (Math.random() < 0.45) sim.resources.berry += 1;
        useHud.getState().bumpRoster();
      }
      continue;
    }
    if (!pal.wild) {
      if (pal.workerPad != null) {
        const pad = PADS[pal.workerPad];
        if (pad) {
          const fixed = resolveBody(sim, pad.x + 1.4, pad.z + 0.2, 0.3);
          pal.x = fixed.x;
          pal.z = fixed.z;
        }
        pal.speed = 0;
        pal.yaw = dampAngle(pal.yaw, Math.atan2(-(FIRE.x - pal.x), -(FIRE.z - pal.z)), 4, dt);
        continue;
      }
      if (pal.active) {
        const fx = -Math.sin(sim.player.yaw);
        const fz = -Math.cos(sim.player.yaw);
        const rx = Math.cos(sim.player.yaw);
        const rz = -Math.sin(sim.player.yaw);
        const tx = sim.player.x - fx * 1.55 + rx * 0.65;
        const tz = sim.player.z - fz * 1.55 + rz * 0.65;
        const dist = Math.hypot(pal.x - sim.player.x, pal.z - sim.player.z);
        if (dist > 14) {
          pal.x = tx;
          pal.z = tz;
        } else moveToward(sim, pal, tx, tz, SPECIES[pal.species].speed, dt);
        if (pal.cd <= 0) {
          const foe = nearestWild(sim, pal.x, pal.z, 3.35);
          if (foe && (sim.battle > 0 || foe.aggro)) {
            damagePal(sim, foe, SPECIES[pal.species].dmg);
            pal.cd = 0.78;
            pal.xp += 1;
            if (pal.xp >= pal.level * 4) {
              pal.xp = 0;
              pal.level += 1;
              pal.maxHp += 6;
              pal.hp = pal.maxHp;
              toast(sim, `${SPECIES[pal.species].name} reached Lv ${pal.level}`);
            }
          }
        }
        continue;
      }
      const tx = -5.1 + (restIndex % 4) * 1.15;
      const tz = -4.2 - Math.floor(restIndex / 4) * 1.15;
      restIndex += 1;
      moveToward(sim, pal, tx, tz, 3.2, dt);
      continue;
    }
    const spec = SPECIES[pal.species];
    const distP = Math.hypot(pal.x - sim.player.x, pal.z - sim.player.z);
    if (distP < 12 && !sim.seen.includes(pal.species)) {
      sim.seen.push(pal.species);
      useHud.getState().bump();
    }
    const hurt = pal.hp < pal.maxHp * 0.38;
    let mode: "wander" | "chase" | "flee" = "wander";
    if (sim.grace <= 0) {
      if (hurt && spec.temperament !== "bold") mode = "flee";
      else if (pal.aggro || (spec.temperament === "bold" && distP < 7.4)) mode = "chase";
    }
    if (mode === "chase") {
      moveToward(sim, pal, sim.player.x, sim.player.z, spec.speed, dt);
      if (distP < 1.42 && pal.cd <= 0 && sim.player.iframes <= 0) {
        const dmg = Math.max(3, Math.round(spec.dmg * 0.55));
        sim.player.hp -= dmg;
        sim.player.iframes = 0.7;
        sim.shake = Math.min(0.5, sim.shake + 0.22);
        sim.battle = 2.5;
        pal.cd = 1.05;
        sfx("hurt");
        if (sim.player.hp <= 0) {
          sim.player.hp = sim.player.maxHp;
          sim.player.x = SPAWN.x;
          sim.player.z = SPAWN.z;
          sim.player.iframes = 1.4;
          toast(sim, "Nia pulled you back to the green");
          for (const w of sim.pals) if (w.wild) w.aggro = false;
        }
      }
    } else if (mode === "flee") {
      const dx = pal.x - sim.player.x;
      const dz = pal.z - sim.player.z;
      const d = Math.hypot(dx, dz) || 1;
      moveToward(sim, pal, pal.x + (dx / d) * 5, pal.z + (dz / d) * 5, spec.speed * 1.12, dt);
    } else {
      pal.wander -= dt;
      if (pal.wander <= 0) {
        pal.wander = 1.3 + Math.random() * 2.6;
        const ang = Math.random() * Math.PI * 2;
        pal.tx = pal.homeX + Math.cos(ang) * 3.4;
        pal.tz = pal.homeZ + Math.sin(ang) * 3.4;
      }
      moveToward(sim, pal, pal.tx, pal.tz, spec.speed * 0.42, dt);
    }
  }

  for (let i = 0; i < sim.pals.length; i += 1) {
    const a = sim.pals[i];
    if (!a || !a.alive || a.workerPad != null) continue;
    for (let j = i + 1; j < sim.pals.length; j += 1) {
      const b = sim.pals[j];
      if (!b || !b.alive || b.workerPad != null) continue;
      let dx = b.x - a.x;
      let dz = b.z - a.z;
      const d = Math.hypot(dx, dz);
      if (d > 0.001 && d < 0.85) {
        const push = (0.85 - d) / d;
        dx *= push * 0.5;
        dz *= push * 0.5;
        a.x -= dx;
        a.z -= dz;
        b.x += dx;
        b.z += dz;
      }
    }
  }

  for (const pal of sim.pals) {
    if (!pal.alive || pal.wild) continue;
    let dx = pal.x - sim.player.x;
    let dz = pal.z - sim.player.z;
    const d = Math.hypot(dx, dz);
    if (d > 0.001 && d < 0.72) {
      dx /= d;
      dz /= d;
      pal.x += dx * (0.72 - d);
      pal.z += dz * (0.72 - d);
    }
  }

  for (const proj of sim.projs) {
    if (!proj.alive) continue;
    proj.t += dt / 0.42;
    const k = Math.min(1, proj.t);
    const ease = k * k * (3 - 2 * k);
    const target = sim.pals.find((p) => p.id === proj.targetId);
    const tx = target ? target.x : proj.x;
    const tz = target ? target.z : proj.z;
    proj.x = proj.sx + (tx - proj.sx) * ease;
    proj.z = proj.sz + (tz - proj.sz) * ease;
    proj.y = proj.sy + Math.sin(k * Math.PI) * 1.35;
    if (k >= 1) {
      proj.alive = false;
      resolveOrb(sim, proj);
    }
  }
  if (sim.projs.some((p) => !p.alive)) sim.projs = sim.projs.filter((p) => p.alive);

  for (let i = sim.particles.length - 1; i >= 0; i -= 1) {
    const p = sim.particles[i];
    if (!p) continue;
    p.life -= dt;
    p.vy -= 4.2 * dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.z += p.vz * dt;
    if (p.life <= 0 || p.y < 0) sim.particles.splice(i, 1);
  }

  for (const n of sim.nodes) {
    if (n.amount > 0) continue;
    n.respawn -= dt;
    if (n.respawn <= 0) n.amount = n.max;
  }

  sim.workAcc += dt;
  if (sim.workAcc >= 3.2) {
    sim.workAcc = 0;
    let made = false;
    for (const b of sim.buildings) {
      if (b.workerId == null) continue;
      const pal = sim.pals.find((p) => p.id === b.workerId && p.alive && !p.wild);
      if (!pal) continue;
      const bonus = workMatch(b.type, SPECIES[pal.species].element) ? 2 : 1;
      if (b.type === "garden") sim.resources.berry += bonus;
      if (b.type === "mill") {
        sim.resources.wood += bonus;
        sim.ever.wood += bonus;
      }
      if (b.type === "kiln") {
        sim.resources.stone += bonus;
        sim.ever.stone += bonus;
        b.ticks += 1;
        if (b.ticks % 3 === 0) sim.resources.orb += 1;
      }
      made = true;
    }
    if (made) sfx("gather");
  }

  if (sim.buildings.some((b) => b.type === "nest")) {
    const rate = 2.2 * dt;
    sim.player.hp = Math.min(sim.player.maxHp, sim.player.hp + rate);
    for (const pal of sim.pals) {
      if (pal.alive && !pal.wild) pal.hp = Math.min(pal.maxHp, pal.hp + rate);
    }
  }

  sim.spawnAcc += dt;
  const wilds = sim.pals.filter((p) => p.wild && p.alive).length;
  if (wilds < 6 && sim.spawnAcc > 8) {
    sim.spawnAcc = 0;
    spawnWild(sim);
    useHud.getState().bumpRoster();
  }

  let bestId: number | null = null;
  let bestScore = 1e9;
  const lookX = -Math.sin(sim.player.yaw);
  const lookZ = -Math.cos(sim.player.yaw);
  for (const pal of sim.pals) {
    if (!pal.alive || !pal.wild || pal.faint > 0 || pal.pending) continue;
    const dx = pal.x - sim.player.x;
    const dz = pal.z - sim.player.z;
    const d = Math.hypot(dx, dz);
    if (d > 12 || d < 0.001) continue;
    const dot = (dx / d) * lookX + (dz / d) * lookZ;
    if (dot < 0.12 && d > 3.5) continue;
    const score = d - dot * 2.2;
    if (score < bestScore) {
      bestScore = score;
      bestId = pal.id;
    }
  }
  sim.targetId = bestId;
  sim.prompt = computePrompt(sim);

  sim.questAcc += dt;
  if (sim.questAcc > 0.45) {
    sim.questAcc = 0;
    checkQuests(sim);
  }
  sim.saveAcc += dt;
  if (sim.saveAcc > 8) {
    sim.saveAcc = 0;
    saveSim(sim);
  }
}

export function frame(sim: Sim, delta: number) {
  const d = Math.min(Math.max(delta, 0), 0.1);
  sim.time += d;
  if (sim.mode === "title") {
    sim.titleYaw += d * 0.22;
    return;
  }
  if (!sim.paused) {
    sim.acc += d;
    const step = 1 / 60;
    let n = 0;
    while (sim.acc >= step && n < 5) {
      tick(sim, step);
      sim.acc -= step;
      n += 1;
    }
  }
  sim.hudAcc += d;
  if (sim.hudAcc >= 0.12) {
    sim.hudAcc = 0;
    useHud.getState().bump();
  }
}

function blankResources(): Resources {
  return { wood: 0, stone: 0, berry: 2, orb: 10 };
}

export function createSim(): Sim {
  const sim: Sim = {
    mode: "title",
    paused: false,
    time: 0,
    day: 0.32,
    acc: 0,
    hudAcc: 0,
    titleYaw: 0.4,
    camYaw: 0,
    autoCam: true,
    grace: 0,
    battle: 0,
    shake: 0,
    workAcc: 0,
    spawnAcc: 0,
    saveAcc: 0,
    questAcc: 0,
    hasSave: false,
    starter: "sproutkit",
    player: {
      x: SPAWN.x,
      z: SPAWN.z,
      yaw: 0,
      speed: 0,
      hp: 100,
      maxHp: 100,
      attackCd: 0,
      orbCd: 0,
      iframes: 0,
      lunge: 0,
    },
    input: { x: 0, z: 0, attack: false, orb: false, use: false },
    keys: new Set(),
    forced: null,
    held: { attack: false, orb: false, use: false, eat: false },
    pals: [],
    buildings: [],
    nodes: NODES.map((n) => ({
      id: nextId(),
      kind: n.kind,
      x: n.x,
      z: n.z,
      amount: n.max,
      max: n.max,
      respawn: 0,
    })),
    projs: [],
    particles: [],
    resources: blankResources(),
    ever: { wood: 0, stone: 0, berry: 0, caught: 0 },
    discovered: [],
    seen: [],
    questsDone: [],
    toast: "",
    toastUntil: 0,
    line: "",
    lineUntil: 0,
    prompt: "",
    targetId: null,
    decor: DECOR,
  };
  return sim;
}

type SavePal = {
  species: SpeciesId;
  hp: number;
  maxHp: number;
  level: number;
  xp: number;
  active: boolean;
};
type SaveBuilding = { type: BuildingType; pad: number; worker: number | null };
type Save = {
  version: 1;
  starter: SpeciesId;
  day: number;
  player: { x: number; z: number; yaw: number; hp: number };
  resources: Resources;
  ever: Ever;
  discovered: SpeciesId[];
  seen: SpeciesId[];
  questsDone: QuestId[];
  pals: SavePal[];
  buildings: SaveBuilding[];
};

function toSave(sim: Sim): Save {
  const tamed = sim.pals.filter((p) => p.alive && !p.wild);
  return {
    version: 1,
    starter: sim.starter,
    day: sim.day,
    player: { x: sim.player.x, z: sim.player.z, yaw: sim.player.yaw, hp: sim.player.hp },
    resources: sim.resources,
    ever: sim.ever,
    discovered: sim.discovered,
    seen: sim.seen,
    questsDone: sim.questsDone,
    pals: tamed.map((p) => ({
      species: p.species,
      hp: p.hp,
      maxHp: p.maxHp,
      level: p.level,
      xp: p.xp,
      active: p.active && p.workerPad == null,
    })),
    buildings: sim.buildings.map((b) => ({
      type: b.type,
      pad: b.pad,
      worker: b.workerId == null ? null : tamed.findIndex((p) => p.id === b.workerId),
    })),
  };
}

export function saveSim(sim: Sim = getSim()) {
  if (sim.mode !== "play") return;
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(toSave(sim)));
    sim.hasSave = true;
  } catch {
    /* ignore quota */
  }
}

function applySave(sim: Sim, save: Save) {
  if (save.version !== 1) return;
  if (!SPECIES[save.starter]) return;
  sim.hasSave = true;
  sim.starter = save.starter;
  sim.day = save.day;
  sim.player.x = save.player.x;
  sim.player.z = save.player.z;
  sim.player.yaw = save.player.yaw;
  sim.player.hp = save.player.hp;
  sim.camYaw = save.player.yaw;
  sim.resources = { ...save.resources };
  sim.ever = { ...save.ever };
  sim.discovered = save.discovered.filter((id) => SPECIES[id]);
  sim.seen = (save.seen ?? save.discovered).filter((id) => SPECIES[id]);
  sim.questsDone = save.questsDone.filter((id) => QUESTS.some((q) => q.id === id));
  const ids: number[] = [];
  for (const p of save.pals) {
    if (!SPECIES[p.species]) continue;
    const pal = makePal(sim, p.species, SPAWN.x, SPAWN.z - 1, false);
    pal.hp = p.hp;
    pal.maxHp = p.maxHp;
    pal.level = p.level;
    pal.xp = p.xp;
    pal.active = p.active;
    sim.pals.push(pal);
    ids.push(pal.id);
  }
  const used = new Set<number>();
  for (const b of save.buildings) {
    if (!BUILDINGS[b.type]) continue;
    if (b.pad < 0 || b.pad >= PADS.length || used.has(b.pad)) continue;
    used.add(b.pad);
    const workerId = b.worker != null && b.worker >= 0 ? (ids[b.worker] ?? null) : null;
    sim.buildings.push({ id: nextId(), type: b.type, pad: b.pad, workerId, ticks: 0 });
    if (workerId != null) {
      const pal = sim.pals.find((p) => p.id === workerId);
      if (pal) {
        pal.workerPad = b.pad;
        pal.active = false;
      }
    }
  }
}

function loadInto(sim: Sim) {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return;
    applySave(sim, JSON.parse(raw) as Save);
  } catch {
    sim.hasSave = false;
  }
}

export function getSim() {
  if (!SIM) {
    SIM = createSim();
    loadInto(SIM);
  }
  return SIM;
}

export function begin(how: "new" | "continue") {
  if (how === "new") {
    try {
      localStorage.removeItem(SAVE_KEY);
    } catch {
      /* ignore */
    }
    SIM = createSim();
  }
  const sim = getSim();
  if (sim.mode === "play") return;
  const preview = useHud.getState().preview;
  if (how === "new" || !sim.hasSave) {
    sim.pals = sim.pals.filter((p) => p.wild);
    sim.buildings = [];
    sim.resources = blankResources();
    sim.ever = { wood: 0, stone: 0, berry: 0, caught: 0 };
    sim.questsDone = [];
    sim.discovered = [];
    sim.seen = [];
    sim.player.hp = sim.player.maxHp;
    sim.player.x = SPAWN.x;
    sim.player.z = SPAWN.z;
    sim.player.yaw = 0;
    sim.day = 0.32;
    sim.starter = preview;
    grant(sim, preview, true);
  }
  sim.mode = "play";
  sim.paused = false;
  sim.camYaw = sim.player.yaw;
  sim.grace = 1.7;
  sim.forced = null;
  sim.projs = [];
  let guard = 0;
  while (sim.pals.filter((p) => p.wild && p.alive).length < 6 && guard < 8) {
    spawnWild(sim);
    guard += 1;
  }
  say(sim, "Nia: The meadow forgot its keepers. Catch the Palmons, and the village wakes.");
  sfx("ui");
  saveSim(sim);
  useHud.getState().setMenu(null);
  useHud.getState().bumpRoster();
}

export function openMenu(menu: Menu) {
  const sim = getSim();
  if (sim.mode === "play") sim.paused = menu != null;
  useHud.getState().setMenu(menu);
}

export function backToTitle() {
  const sim = getSim();
  saveSim(sim);
  sim.mode = "title";
  sim.paused = false;
  sim.forced = null;
  useHud.getState().setMenu(null);
  useHud.getState().bumpRoster();
}

export function buildStation(type: BuildingType) {
  const sim = getSim();
  if (sim.buildings.length >= PADS.length) {
    toast(sim, "Every plot is taken");
    return;
  }
  const cost = COST[type];
  if (sim.resources.wood < cost.wood || sim.resources.stone < cost.stone || sim.resources.berry < cost.berry) {
    toast(sim, "Not enough materials");
    return;
  }
  const used = new Set(sim.buildings.map((b) => b.pad));
  const pad = PADS.findIndex((_, i) => !used.has(i));
  if (pad < 0) return;
  sim.resources.wood -= cost.wood;
  sim.resources.stone -= cost.stone;
  sim.resources.berry -= cost.berry;
  sim.buildings.push({ id: nextId(), type, pad, workerId: null, ticks: 0 });
  toast(sim, `${BUILDINGS[type].name} is up`);
  sfx("build");
  useHud.getState().bumpRoster();
  saveSim(sim);
}

export function setActive(id: number) {
  const sim = getSim();
  const pal = sim.pals.find((p) => p.id === id && p.alive && !p.wild);
  if (!pal) return;
  for (const other of sim.pals) if (!other.wild) other.active = false;
  for (const b of sim.buildings) if (b.workerId === pal.id) b.workerId = null;
  pal.workerPad = null;
  pal.active = true;
  sfx("ui");
  useHud.getState().bumpRoster();
  saveSim(sim);
}

export function assignWorker(id: number, pad: number) {
  const sim = getSim();
  const pal = sim.pals.find((p) => p.id === id && p.alive && !p.wild);
  const building = sim.buildings.find((b) => b.pad === pad);
  if (!pal || !building) return;
  for (const b of sim.buildings) {
    if (b.workerId === pal.id) b.workerId = null;
  }
  if (building.workerId != null) {
    const prev = sim.pals.find((p) => p.id === building.workerId);
    if (prev) prev.workerPad = null;
  }
  for (const other of sim.pals) if (other.id === pal.id) other.active = false;
  pal.active = false;
  pal.workerPad = pad;
  building.workerId = pal.id;
  toast(sim, `${SPECIES[pal.species].name} is working the ${BUILDINGS[building.type].name.toLowerCase()}`);
  sfx("ui");
  useHud.getState().bumpRoster();
  saveSim(sim);
}

export function restPal(id: number) {
  const sim = getSim();
  const pal = sim.pals.find((p) => p.id === id && p.alive && !p.wild);
  if (!pal) return;
  for (const b of sim.buildings) if (b.workerId === pal.id) b.workerId = null;
  pal.workerPad = null;
  pal.active = false;
  sfx("ui");
  useHud.getState().bumpRoster();
  saveSim(sim);
}

export function mergePal(id: number) {
  const sim = getSim();
  const pal = sim.pals.find((p) => p.id === id && p.alive && !p.wild);
  if (!pal) return;
  const other = sim.pals.find((p) => p.id !== id && p.alive && !p.wild && p.species === pal.species);
  if (!other) {
    toast(sim, "Catch a twin to merge");
    return;
  }
  other.alive = false;
  for (const b of sim.buildings) if (b.workerId === other.id) b.workerId = null;
  pal.level += 1;
  pal.maxHp += 8;
  pal.hp = pal.maxHp;
  toast(sim, `${SPECIES[pal.species].name} merged to Lv ${pal.level}`);
  sfx("catch");
  useHud.getState().bumpRoster();
  saveSim(sim);
}

export function eatBerry() {
  eat(getSim());
}

export function installProbe() {
  window.__controlsTest = {
    getYaw: () => getSim().player.yaw,
    getSpeed: () => getSim().player.speed,
    setKeys: (codes: string[]) => {
      getSim().forced = new Set(codes);
    },
  };
}

export function currentQuestOf(sim: Sim) {
  return currentQuest(sim);
}
