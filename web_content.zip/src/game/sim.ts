import {
  CUSTOMER_META,
  LOCATION_MAP,
  PRODUCT_MAP,
  PRODUCTS,
  ROLE_META,
  STAFF_NAMES,
  STORE_LABELS,
  SUPPLIERS,
  UPGRADE_COST,
  storeFootprint,
} from "./catalog";
import { NavGrid } from "./pathfinding";
import { defaultSim } from "./save";
import type {
  AABB,
  ActiveEvent,
  CheckoutLane,
  Customer,
  CustomerKind,
  DayReport,
  EmployeeRole,
  EventKind,
  HudSnap,
  LocationId,
  Mission,
  PalletSpot,
  ProductId,
  ShelfSlot,
  SimState,
  Staff,
  Vec2,
} from "./types";

const OPEN_H = 8;
const CLOSE_H = 22;
const TIME_SCALE = 3.1;
const PLAYER_R = 0.38;

function dist(a: Vec2, b: Vec2): number {
  return Math.hypot(a.x - b.x, a.z - b.z);
}

function clamp(v: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, v));
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]!;
}

function collideSlide(
  x: number,
  z: number,
  dx: number,
  dz: number,
  boxes: AABB[],
  r: number,
): { x: number; z: number } {
  const blocked = (px: number, pz: number) => {
    for (const b of boxes) {
      const cx = clamp(px, b.minX, b.maxX);
      const cz = clamp(pz, b.minZ, b.maxZ);
      const ox = px - cx;
      const oz = pz - cz;
      if (ox * ox + oz * oz < r * r) return true;
    }
    return false;
  };
  let nx = x + dx;
  let nz = z + dz;
  if (blocked(nx, z)) nx = x;
  if (blocked(nx, nz)) nz = z;
  if (blocked(nx, nz)) {
    nx = x;
    nz = z;
  }
  return { x: nx, z: nz };
}

function clockStr(h: number): string {
  const hh = Math.floor(h) % 24;
  const mm = Math.floor((h - Math.floor(h)) * 60);
  const ap = hh >= 12 ? "PM" : "AM";
  const h12 = ((hh + 11) % 12) + 1;
  return `${h12}:${mm.toString().padStart(2, "0")} ${ap}`;
}

export class Sim {
  s: SimState;
  colliders: AABB[] = [];
  checkouts: CheckoutLane[] = [];
  pallets: PalletSpot[] = [];
  customers: Customer[] = [];
  grid: NavGrid | null = null;
  entrance = { x: 0, z: 10 };
  warehouseZone: AABB = { minX: -8, maxX: 8, minZ: -12, maxZ: -7 };
  camYaw = Math.PI;
  camPitch = -0.32;
  speed = 0;
  spawnT = 0;
  dirtT = 0;
  eventT = 80;
  stepT = 0;
  toast: { text: string; life: number } | null = null;
  report: DayReport | null = null;
  prompt = "";
  interactTarget: { kind: string; id: string } | null = null;
  lastInteract = 0;
  footT = 0;
  trauma = 0;
  layoutReady = false;
  w = 18;
  d = 24;

  constructor(state: SimState) {
    this.s = state;
  }

  bindLayout(opts: {
    colliders: AABB[];
    checkouts: CheckoutLane[];
    pallets: PalletSpot[];
    shelves: ShelfSlot[];
    grid: NavGrid;
    entrance: Vec2;
    warehouseZone: AABB;
    spawn: { x: number; z: number; yaw: number };
    w: number;
    d: number;
  }): void {
    this.colliders = opts.colliders;
    this.checkouts = opts.checkouts;
    this.pallets = opts.pallets;
    this.grid = opts.grid;
    this.entrance = opts.entrance;
    this.warehouseZone = opts.warehouseZone;
    this.w = opts.w;
    this.d = opts.d;
    const fresh = !this.s.shelves.length;
    if (fresh) this.s.shelves = opts.shelves;
    else {
      for (let i = 0; i < opts.shelves.length; i++) {
        const n = opts.shelves[i]!;
        const o = this.s.shelves[i];
        if (o) {
          o.x = n.x;
          o.z = n.z;
          o.rot = n.rot;
          o.kind = n.kind;
          o.capacity = n.capacity;
          o.w = n.w;
          o.d = n.d;
        } else this.s.shelves.push(n);
      }
    }
    if (!this.layoutReady) {
      if (fresh) {
        this.s.player.x = opts.spawn.x;
        this.s.player.z = opts.spawn.z;
        this.s.player.yaw = opts.spawn.yaw;
      }
      this.camYaw = this.s.player.yaw;
      this.layoutReady = true;
    }
    if (!this.s.missions.length) this.rollMissions();
  }

  notify(text: string): void {
    this.toast = { text, life: 3.2 };
  }

  inWarehouse(x: number, z: number): boolean {
    const b = this.warehouseZone;
    return x > b.minX && x < b.maxX && z > b.minZ && z < b.maxZ;
  }

  nearestShelf(x: number, z: number, max = 2.1): ShelfSlot | null {
    let best: ShelfSlot | null = null;
    let bd = max;
    for (const sh of this.s.shelves) {
      const d = Math.hypot(sh.x - x, sh.z - z);
      if (d < bd) {
        bd = d;
        best = sh;
      }
    }
    return best;
  }

  nearestCheckout(x: number, z: number, max = 2.0): CheckoutLane | null {
    let best: CheckoutLane | null = null;
    let bd = max;
    for (const c of this.checkouts) {
      const d = Math.hypot(c.x - x, c.z - z);
      if (d < bd) {
        bd = d;
        best = c;
      }
    }
    return best;
  }

  pathTo(x: number, z: number, tx: number, tz: number): Vec2[] {
    if (!this.grid) return [{ x: tx, z: tz }];
    return this.grid.find(x, z, tx, tz);
  }

  step(
    dt: number,
    input: { moveX: number; moveY: number; sprint: boolean; interactDown: boolean },
  ): void {
    const s = this.s;
    this.trauma = Math.max(0, this.trauma - dt * 1.8);
    if (this.toast) {
      this.toast.life -= dt;
      if (this.toast.life <= 0) this.toast = null;
    }

    if (s.storeOpen) {
      s.timeOfDay += dt * (TIME_SCALE / 60);
      if (s.timeOfDay >= CLOSE_H) this.closeDay();
    }

    this.updatePlayer(dt, input);
    this.updateOrders(dt);
    this.updateCustomers(dt);
    this.updateStaff(dt);
    this.updateWorld(dt);
    this.updateEvents(dt);
    this.updateMissions();
    this.refreshPrompt();
  }

  private updatePlayer(
    dt: number,
    input: { moveX: number; moveY: number; sprint: boolean; interactDown: boolean },
  ): void {
    const p = this.s.player;
    const fy = -Math.sin(this.camYaw);
    const fz = -Math.cos(this.camYaw);
    const rx = Math.cos(this.camYaw);
    const rz = -Math.sin(this.camYaw);
    const sprint = input.sprint && (Math.abs(input.moveX) > 0.1 || Math.abs(input.moveY) > 0.1);
    const max = sprint ? 6.1 : 3.55;
    const vx = (fy * input.moveY + rx * input.moveX) * max;
    const vz = (fz * input.moveY + rz * input.moveX) * max;
    this.speed = Math.hypot(vx, vz);
    if (this.speed > 0.12) {
      const next = collideSlide(p.x, p.z, vx * dt, vz * dt, this.colliders, PLAYER_R);
      p.x = next.x;
      p.z = next.z;
      p.yaw = Math.atan2(-vx, -vz);
      this.footT += dt * (sprint ? 5.5 : 3.6);
    }
    const { w, d } = storeFootprint(this.s.storeLevel);
    p.x = clamp(p.x, -w / 2 + 0.6, w / 2 - 0.6);
    p.z = clamp(p.z, -d / 2 + 0.6, d / 2 + 1.4);

    if (input.interactDown) this.tryInteract();
  }

  private tryInteract(): void {
    const p = this.s.player;
    const t = this.interactTarget;
    if (!t) {
      this.notify("Nothing to use here.");
      return;
    }
    if (t.kind === "shelf") {
      const sh = this.s.shelves.find((x) => x.id === t.id);
      if (!sh) return;
      if (sh.broken) {
        if (this.s.money >= 80) {
          this.s.money -= 80;
          this.s.daily.expenses += 80;
          sh.broken = false;
          this.notify("Refrigerator repaired.");
        } else this.notify("Need $80 to repair.");
        return;
      }
      if (p.holding) {
        if (sh.productId && sh.productId !== p.holding.productId) {
          this.notify(`This bay is for ${PRODUCT_MAP[sh.productId].name}.`);
          return;
        }
        if (!sh.productId) sh.productId = p.holding.productId;
        const room = sh.capacity - sh.stock;
        const n = Math.min(room, p.holding.qty);
        if (n <= 0) {
          this.notify("Shelf is full.");
          return;
        }
        sh.stock += n;
        p.holding.qty -= n;
        if (p.holding.qty <= 0) p.holding = null;
        if (this.s.tutorial === 2) this.s.tutorial = 3;
        this.notify(`Stocked ${n} ${PRODUCT_MAP[sh.productId].name}.`);
        return;
      }
      if (sh.dirty > 0.4) {
        sh.dirty = 0;
        this.s.cleanliness = clamp(this.s.cleanliness + 0.04, 0, 1);
        this.notify("Shelf wiped down.");
        return;
      }
      this.notify(sh.stock ? `${PRODUCT_MAP[sh.productId ?? "bread"].name}: ${sh.stock} left` : "Empty bay.");
      return;
    }
    if (t.kind === "pallet") {
      if (p.holding) {
        this.s.warehouse[p.holding.productId] += p.holding.qty;
        this.notify("Crate returned to warehouse.");
        p.holding = null;
        return;
      }
      const ids = (Object.keys(this.s.warehouse) as ProductId[]).filter(
        (id) => this.s.warehouse[id] > 0 && this.s.unlocked[id],
      );
      if (!ids.length) {
        this.notify("Warehouse is empty. Place an order.");
        return;
      }
      const low = this.s.shelves.find((sh) => sh.productId && sh.stock < sh.capacity * 0.45);
      const pickId = (low?.productId && this.s.warehouse[low.productId] > 0 ? low.productId : ids[0])!;
      const qty = Math.min(8, this.s.warehouse[pickId]);
      this.s.warehouse[pickId] -= qty;
      p.holding = { productId: pickId, qty };
      if (this.s.tutorial === 1) this.s.tutorial = 2;
      this.notify(`Picked ${qty} ${PRODUCT_MAP[pickId].name}.`);
      return;
    }
    if (t.kind === "checkout") {
      this.serveCheckout(t.id);
      return;
    }
    if (t.kind === "dirt") {
      this.s.cleanliness = clamp(this.s.cleanliness + 0.08, 0, 1);
      this.notify("Floor cleaned.");
    }
    if (t.kind === "thief") {
      const c = this.customers.find((x) => x.id === Number(t.id));
      if (c) {
        c.state = "flee";
        c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
        this.notify("Shoplifter stopped.");
        this.s.rating = clamp(this.s.rating + 0.05, 1, 5);
      }
    }
  }

  private serveCheckout(laneId: string): void {
    const c = this.customers.find((x) => x.state === "queue" && x.lane === laneId);
    if (!c) {
      this.notify("No one in this lane.");
      return;
    }
    if (!c.cart.length) {
      c.state = "leave";
      c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
      return;
    }
    const item = c.cart.shift()!;
    this.ringSale(c, item.productId, item.qty, item.price);
    if (!c.cart.length) this.finishSale(c);
    else this.notify(`Scanned ${PRODUCT_MAP[item.productId].name}.`);
    if (this.s.tutorial === 3) this.s.tutorial = 4;
  }

  private ringSale(c: Customer, id: ProductId, qty: number, price: number): void {
    const total = price * qty;
    this.s.money += total;
    this.s.daily.revenue += total;
    this.s.daily.sold += qty;
    this.s.soldToday[id] += qty;
    this.s.xp += qty;
  }

  private finishSale(c: Customer): void {
    c.state = "leave";
    c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
    this.s.daily.served += 1;
    const waitPenalty = c.wait > 25 ? 0.15 : c.wait > 12 ? 0.05 : 0;
    c.satisfaction = clamp(c.satisfaction - waitPenalty, 0, 1);
    this.s.rating = clamp(this.s.rating * 0.97 + (1 + c.satisfaction * 4) * 0.03, 1, 5);
    this.notify("Receipt printed. Thanks for shopping.");
    this.trauma = Math.min(1, this.trauma + 0.12);
  }

  private updateOrders(dt: number): void {
    const speed = 1 + this.s.staff.filter((e) => e.role === "delivery").length * 0.35;
    for (const o of this.s.orders) {
      if (o.delayed && this.s.event?.kind === "delay") continue;
      o.eta -= dt * speed;
    }
    const done = this.s.orders.filter((o) => o.eta <= 0);
    this.s.orders = this.s.orders.filter((o) => o.eta > 0);
    for (const o of done) {
      const room = this.s.warehouseCap - this.warehouseUsed();
      const qty = Math.min(o.qty, Math.max(0, room));
      this.s.warehouse[o.productId] += qty;
      this.notify(`Delivery: ${qty} ${PRODUCT_MAP[o.productId].name}.`);
      if (this.s.tutorial === 0) this.s.tutorial = 1;
    }
  }

  warehouseUsed(): number {
    let n = 0;
    for (const id of PRODUCTS.map((p) => p.id)) n += this.s.warehouse[id];
    return n;
  }

  private peakMul(): number {
    const h = this.s.timeOfDay;
    if (h >= 12 && h <= 13.5) return 1.55;
    if (h >= 17 && h <= 19.5) return 1.7;
    if (h < 9 || h > 20.5) return 0.45;
    return 1;
  }

  private updateCustomers(dt: number): void {
    const s = this.s;
    if (s.storeOpen) {
      const loc = LOCATION_MAP[s.location];
      const cap = 4 + s.storeLevel * 3 + Math.floor(s.rating);
      const festival = s.event?.kind === "festival" ? 1.5 : 1;
      const rate = (0.22 + loc.traffic * 0.18) * this.peakMul() * festival * (s.rating / 3.5);
      this.spawnT += dt * rate;
      if (this.spawnT > 1 && this.customers.length < cap) {
        this.spawnT = 0;
        this.spawnCustomer();
      }
    }

    for (const c of this.customers) {
      c.anim += dt * (c.speed * 3.2);
      if (c.state === "pay") continue;
      if (c.state === "queue") {
        c.wait += dt;
        c.patience -= dt * (c.kind === "impatient" ? 1.6 : 1);
        if (c.patience <= 0) {
          c.state = "leave";
          c.satisfaction = 0.15;
          s.daily.lost += 1;
          s.rating = clamp(s.rating - 0.08, 1, 5);
          c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
          this.notify("A customer left the queue.");
        }
      }
      this.steer(c, dt);
      this.thinkCustomer(c, dt);
    }
    this.customers = this.customers.filter((c) => {
      if (c.state === "leave" && dist(c, this.entrance) < 1.4 && c.z > this.entrance.z - 0.2) return false;
      if (c.state === "flee" && dist(c, this.entrance) < 1.6) return false;
      return true;
    });
  }

  private spawnCustomer(): void {
    const loc = this.s.location;
    const weights: [CustomerKind, number][] = [
      ["budget", loc === "town" ? 3 : 1.4],
      ["regular", 2.2],
      ["rich", loc === "downtown" || loc === "business" ? 2.2 : 0.6],
      ["impatient", loc === "downtown" || loc === "business" ? 2 : 0.8],
      ["elderly", loc === "town" ? 1.8 : 0.7],
      ["child", loc === "beach" ? 1.6 : 0.7],
    ];
    const sum = weights.reduce((a, [, w]) => a + w, 0);
    let r = Math.random() * sum;
    let kind: CustomerKind = "regular";
    for (const [k, w] of weights) {
      r -= w;
      if (r <= 0) {
        kind = k;
        break;
      }
    }
    const meta = CUSTOMER_META[kind];
    const unlocked = PRODUCTS.filter((p) => this.s.unlocked[p.id]);
    const n = kind === "child" ? 1 + (Math.random() < 0.4 ? 1 : 0) : kind === "rich" ? 4 + ((Math.random() * 4) | 0) : 2 + ((Math.random() * 4) | 0);
    const list: Customer["list"] = [];
    const prefer =
      loc === "beach"
        ? unlocked.filter((p) => p.id === "drinks" || p.category === "snacks")
        : unlocked;
    const pool = prefer.length ? prefer : unlocked;
    for (let i = 0; i < n; i++) {
      const p = pick(pool);
      if (list.some((l) => l.productId === p.id)) continue;
      if (kind === "budget" && p.sellPrice * this.s.sellMul[p.id] > p.buyPrice * 2.4) continue;
      const demand = p.demand * (this.s.demandMul[p.id] ?? 1);
      if (Math.random() > 0.35 + demand * 0.4) continue;
      list.push({ productId: p.id, qty: 1 + ((Math.random() * (kind === "rich" ? 3 : 2)) | 0), got: 0 });
    }
    if (!list.length && pool.length) {
      const p = pick(pool);
      list.push({ productId: p.id, qty: 1, got: 0 });
    }
    const c: Customer = {
      id: this.s.nextCustomer++,
      kind,
      x: this.entrance.x + (Math.random() - 0.5) * 1.2,
      z: this.entrance.z + 1.2,
      yaw: Math.PI,
      state: "enter",
      list,
      cart: [],
      target: null,
      path: this.pathTo(this.entrance.x, this.entrance.z + 1, 0, 0),
      wait: 0,
      patience: meta.patience * (0.85 + Math.random() * 0.3),
      satisfaction: 0.7,
      speed: meta.speed * (this.s.event?.kind === "weather" ? 0.82 : 1),
      payMethod: kind === "rich" || Math.random() > 0.4 ? "card" : "cash",
      lane: null,
      anim: Math.random() * 10,
      shoplift: this.s.event?.kind === "shoplifter" && Math.random() < 0.35,
      color: meta.color,
      scale: meta.scale,
    };
    if (this.s.event?.kind === "fire") c.state = "flee";
    this.customers.push(c);
  }

  private thinkCustomer(c: Customer, dt: number): void {
    if (c.state === "enter" && c.path.length <= 1) c.state = "seek";
    if (c.state === "flee") {
      if (!c.path.length) c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
      return;
    }
    if (c.state === "seek") {
      const need = c.list.find((l) => l.got < l.qty);
      if (!need) {
        this.sendToQueue(c);
        return;
      }
      const sh = this.findShelfFor(need.productId);
      if (!sh) {
        const alt = this.altBrand(need.productId);
        if (alt) {
          need.productId = alt;
          c.satisfaction -= 0.05;
          return;
        }
        need.got = need.qty;
        c.satisfaction -= 0.18;
        return;
      }
      const stand = this.standPoint(sh);
      if (dist(c, stand) < 0.85) {
        c.state = "take";
        c.wait = 0.55;
        c.target = { x: sh.x, z: sh.z };
        return;
      }
      if (c.path.length <= 1) c.path = this.pathTo(c.x, c.z, stand.x, stand.z);
    }
    if (c.state === "take") {
      c.wait -= dt;
      if (c.wait > 0) return;
      const need = c.list.find((l) => l.got < l.qty);
      if (!need) {
        c.state = "seek";
        return;
      }
      const sh = this.s.shelves.find((x) => x.productId === need.productId && x.stock > 0 && !x.broken);
      if (sh) {
        const take = Math.min(need.qty - need.got, sh.stock, 2);
        sh.stock -= take;
        need.got += take;
        const price = PRODUCT_MAP[need.productId].sellPrice * this.s.sellMul[need.productId];
        const existing = c.cart.find((i) => i.productId === need.productId);
        if (existing) existing.qty += take;
        else c.cart.push({ productId: need.productId, qty: take, price });
        if (c.shoplift && Math.random() < 0.5) {
          c.state = "flee";
          c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
          this.notify("Someone is stealing!");
          this.s.daily.lost += 1;
          return;
        }
      } else {
        const alt = this.altBrand(need.productId);
        if (alt) need.productId = alt;
        else {
          need.got = need.qty;
          c.satisfaction -= 0.2;
        }
      }
      c.state = "seek";
    }
    if (c.state === "queue") {
      const lane = this.checkouts.find((l) => l.id === c.lane) ?? this.checkouts[0];
      if (!lane) return;
      const idx = this.customers.filter((x) => x.state === "queue" && x.lane === lane.id).sort((a, b) => a.id - b.id).indexOf(c);
      const slot = lane.queue[Math.min(idx, lane.queue.length - 1)] ?? { x: lane.x, z: lane.z - 1 };
      if (dist(c, slot) > 0.35 && c.path.length <= 1) c.path = this.pathTo(c.x, c.z, slot.x, slot.z);
    }
  }

  private sendToQueue(c: Customer): void {
    let best = this.checkouts[0];
    let bestN = 999;
    for (const lane of this.checkouts) {
      const n = this.customers.filter((x) => x.lane === lane.id && (x.state === "queue" || x.state === "pay")).length;
      if (n < bestN) {
        bestN = n;
        best = lane;
      }
    }
    if (!best) {
      c.state = "leave";
      c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
      return;
    }
    c.lane = best.id;
    c.state = "queue";
    const slot = best.queue[Math.min(bestN, best.queue.length - 1)] ?? { x: best.x, z: best.z - 1 };
    c.path = this.pathTo(c.x, c.z, slot.x, slot.z);
  }

  private findShelfFor(id: ProductId): ShelfSlot | undefined {
    return this.s.shelves.find((s) => s.productId === id && s.stock > 0 && !s.broken);
  }

  private altBrand(id: ProductId): ProductId | null {
    const cat = PRODUCT_MAP[id].category;
    const sh = this.s.shelves.find(
      (s) => s.productId && PRODUCT_MAP[s.productId].category === cat && s.stock > 0 && s.productId !== id,
    );
    return sh?.productId ?? null;
  }

  private standPoint(sh: ShelfSlot): Vec2 {
    const dx = this.s.player.x - sh.x;
    const face = Math.abs(dx) > 0.2 ? Math.sign(dx) : 1;
    return { x: sh.x + face * 0.95, z: sh.z };
  }

  private steer(c: { x: number; z: number; yaw: number; speed: number; path: Vec2[] }, dt: number): void {
    if (!c.path.length) return;
    const t = c.path[0]!;
    const dx = t.x - c.x;
    const dz = t.z - c.z;
    const d = Math.hypot(dx, dz);
    if (d < 0.28) {
      c.path.shift();
      return;
    }
    const sp = c.speed;
    const nx = (dx / d) * sp * dt;
    const nz = (dz / d) * sp * dt;
    const next = collideSlide(c.x, c.z, nx, nz, this.colliders, 0.3);
    c.x = next.x;
    c.z = next.z;
    c.yaw = Math.atan2(-dx, -dz);
  }

  private updateStaff(dt: number): void {
    const cashiers = this.s.staff.filter((e) => e.role === "cashier");
    if (cashiers.length) {
      for (const lane of this.checkouts) {
        const waiting = this.customers.filter((c) => c.state === "queue" && c.lane === lane.id);
        const first = waiting.sort((a, b) => a.id - b.id)[0];
        if (!first || !first.cart.length) continue;
        first.wait += dt;
        const skill = 0.9 + cashiers[0]!.level * 0.25;
        if (first.wait > 1.1 / skill) {
          first.wait = 0;
          const item = first.cart.shift()!;
          this.ringSale(first, item.productId, item.qty, item.price);
          if (!first.cart.length) this.finishSale(first);
        }
      }
    }
    for (const e of this.s.staff) {
      e.anim += dt * 4;
      e.speed = 1.7 + e.level * 0.15;
      if (e.role === "stocker") this.runStocker(e, dt);
      else if (e.role === "cleaner") this.runCleaner(e, dt);
      else if (e.role === "security") this.runSecurity(e, dt);
      else if (e.role === "cashier") {
        const lane = this.checkouts[0];
        if (lane) {
          e.target = { x: lane.x + 0.9, z: lane.z + 0.2 };
          e.path = this.pathTo(e.x, e.z, e.target.x, e.target.z);
        }
      } else if (e.role === "manager") {
        if (!e.path.length) {
          const sh = pick(this.s.shelves);
          e.path = this.pathTo(e.x, e.z, sh.x + 1, sh.z);
        }
      } else if (e.role === "delivery") {
        if (!e.path.length) {
          e.path = this.pathTo(e.x, e.z, this.warehouseZone.minX + 2, (this.warehouseZone.minZ + this.warehouseZone.maxZ) / 2);
        }
      }
      this.steer(e, dt);
    }
  }

  private runStocker(e: Staff, _dt: number): void {
    if (e.holding) {
      const sh = this.s.shelves.find(
        (s) => (s.productId === e.holding!.productId || !s.productId) && s.stock < s.capacity && !s.broken,
      );
      if (!sh) {
        this.s.warehouse[e.holding.productId] += e.holding.qty;
        e.holding = null;
        return;
      }
      const stand = this.standPoint(sh);
      if (dist(e, stand) < 0.9) {
        if (!sh.productId) sh.productId = e.holding.productId;
        if (sh.productId === e.holding.productId) {
          const n = Math.min(sh.capacity - sh.stock, e.holding.qty);
          sh.stock += n;
          e.holding.qty -= n;
          if (e.holding.qty <= 0) e.holding = null;
        }
        return;
      }
      if (e.path.length <= 1) e.path = this.pathTo(e.x, e.z, stand.x, stand.z);
      return;
    }
    const low = this.s.shelves.find(
      (s) => s.productId && s.stock < s.capacity * 0.5 && this.s.warehouse[s.productId] > 0,
    );
    if (!low?.productId) return;
    if (!this.inWarehouse(e.x, e.z)) {
      if (e.path.length <= 1)
        e.path = this.pathTo(e.x, e.z, (this.warehouseZone.minX + this.warehouseZone.maxX) / 2, (this.warehouseZone.minZ + this.warehouseZone.maxZ) / 2);
      return;
    }
    const qty = Math.min(8, this.s.warehouse[low.productId]);
    this.s.warehouse[low.productId] -= qty;
    e.holding = { productId: low.productId, qty };
  }

  private runCleaner(e: Staff, dt: number): void {
    const dirty = this.s.shelves.find((s) => s.dirty > 0.35);
    if (dirty) {
      if (dist(e, dirty) < 1.1) {
        dirty.dirty = Math.max(0, dirty.dirty - dt * 0.4);
        this.s.cleanliness = clamp(this.s.cleanliness + dt * 0.03, 0, 1);
        return;
      }
      if (e.path.length <= 1) e.path = this.pathTo(e.x, e.z, dirty.x + 0.9, dirty.z);
      return;
    }
    this.s.cleanliness = clamp(this.s.cleanliness + dt * 0.01, 0, 1);
    if (e.path.length <= 1) {
      const sh = pick(this.s.shelves);
      e.path = this.pathTo(e.x, e.z, sh.x + 1, sh.z);
    }
  }

  private runSecurity(e: Staff, _dt: number): void {
    const thief = this.customers.find((c) => c.shoplift && c.state === "flee");
    if (thief) {
      if (dist(e, thief) < 0.9) {
        thief.shoplift = false;
        thief.state = "queue";
        this.sendToQueue(thief);
        this.notify("Guard caught a thief.");
        return;
      }
      if (e.path.length <= 1) e.path = this.pathTo(e.x, e.z, thief.x, thief.z);
      return;
    }
    if (e.path.length <= 1) {
      e.path = this.pathTo(e.x, e.z, (Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8);
    }
  }

  private updateWorld(dt: number): void {
    this.dirtT += dt;
    if (this.dirtT > 8) {
      this.dirtT = 0;
      this.s.cleanliness = clamp(this.s.cleanliness - 0.012 * this.customers.length * 0.04, 0.15, 1);
      const sh = this.s.shelves[Math.floor(Math.random() * this.s.shelves.length)];
      if (sh) sh.dirty = clamp(sh.dirty + 0.08, 0, 1);
    }
    if (this.s.event?.kind === "outage") this.s.cleanliness = clamp(this.s.cleanliness - dt * 0.01, 0.1, 1);
  }

  private updateEvents(dt: number): void {
    if (this.s.event) {
      this.s.event.t += dt;
      if (this.s.event.t >= this.s.event.dur) {
        this.notify(`${this.s.event.label} ended.`);
        this.s.event = null;
        for (const id of PRODUCTS.map((p) => p.id)) this.s.demandMul[id] = 1;
      }
      return;
    }
    if (!this.s.storeOpen) return;
    this.eventT -= dt;
    if (this.eventT > 0) return;
    this.eventT = 70 + Math.random() * 80;
    if (Math.random() > 0.55) return;
    const kinds: EventKind[] = ["demand", "delay", "weather", "festival", "outage", "fridge", "shoplifter", "fire"];
    const kind = pick(kinds);
    this.triggerEvent(kind);
  }

  triggerEvent(kind: EventKind): void {
    const table: Record<EventKind, { label: string; dur: number }> = {
      fire: { label: "Fire alarm", dur: 18 },
      outage: { label: "Power outage", dur: 22 },
      delay: { label: "Delivery delay", dur: 30 },
      demand: { label: "Demand spike", dur: 40 },
      shoplifter: { label: "Shoplifter reported", dur: 28 },
      weather: { label: "Bad weather", dur: 36 },
      festival: { label: "Festival sale", dur: 50 },
      fridge: { label: "Fridge breakdown", dur: 1 },
    };
    const meta = table[kind];
    this.s.event = { kind, t: 0, dur: meta.dur, label: meta.label };
    this.notify(meta.label);
    this.trauma = Math.min(1, this.trauma + 0.35);
    if (kind === "demand") {
      const p = pick(PRODUCTS.filter((x) => this.s.unlocked[x.id]));
      this.s.demandMul[p.id] = 2.2;
    }
    if (kind === "festival") {
      for (const id of PRODUCTS.map((x) => x.id)) this.s.demandMul[id] = 1.4;
    }
    if (kind === "fridge") {
      const fr = this.s.shelves.find((s) => s.kind === "fridge");
      if (fr) fr.broken = true;
      this.s.event = null;
      this.notify("A refrigerator broke down.");
    }
    if (kind === "fire") {
      for (const c of this.customers) {
        c.state = "flee";
        c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
      }
      this.s.storeOpen = false;
    }
    if (kind === "delay") {
      for (const o of this.s.orders) o.delayed = true;
    }
  }

  private updateMissions(): void {
    for (const m of this.s.missions) {
      if (m.done) continue;
      if (m.kind === "sell") m.progress = this.s.daily.sold;
      if (m.kind === "earn") m.progress = Math.floor(this.s.daily.revenue);
      if (m.kind === "serve") m.progress = this.s.daily.served;
      if (m.kind === "rating") m.progress = +this.s.rating.toFixed(2);
      if (m.kind === "product" && m.productId) m.progress = this.s.soldToday[m.productId];
      const ok = m.kind === "rating" ? m.progress >= m.target : m.progress >= m.target;
      if (ok) m.done = true;
    }
  }

  claimMission(id: string): void {
    const m = this.s.missions.find((x) => x.id === id);
    if (!m || !m.done || m.claimed) return;
    m.claimed = true;
    this.s.money += m.rewardMoney;
    this.s.xp += m.rewardXp;
    this.notify(`Mission complete. +$${m.rewardMoney}`);
    this.unlockByXp();
  }

  private unlockByXp(): void {
    for (const p of PRODUCTS) {
      if (!this.s.unlocked[p.id] && (this.s.storeLevel >= p.unlockLevel || this.s.xp > p.unlockLevel * 80)) {
        this.s.unlocked[p.id] = true;
        this.notify(`Unlocked ${p.name}.`);
      }
    }
  }

  rollMissions(): void {
    const unlocked = PRODUCTS.filter((p) => this.s.unlocked[p.id]);
    const p = pick(unlocked);
    this.s.missions = [
      {
        id: "m1",
        title: "Move units",
        detail: "Sell 40 products today",
        kind: "sell",
        target: 40,
        progress: 0,
        rewardMoney: 220,
        rewardXp: 40,
        done: false,
        claimed: false,
      },
      {
        id: "m2",
        title: "Till goal",
        detail: "Earn $1,200 revenue",
        kind: "earn",
        target: 1200,
        progress: 0,
        rewardMoney: 300,
        rewardXp: 50,
        done: false,
        claimed: false,
      },
      {
        id: "m3",
        title: `Push ${p.name}`,
        detail: `Sell 16 ${p.name}`,
        kind: "product",
        productId: p.id,
        target: 16,
        progress: 0,
        rewardMoney: 180,
        rewardXp: 35,
        done: false,
        claimed: false,
      },
    ];
  }

  private refreshPrompt(): void {
    const p = this.s.player;
    this.interactTarget = null;
    this.prompt = "";
    const thief = this.customers.find((c) => c.shoplift && dist(c, p) < 1.6);
    if (thief) {
      this.interactTarget = { kind: "thief", id: String(thief.id) };
      this.prompt = "Stop shoplifter";
      return;
    }
    const co = this.nearestCheckout(p.x, p.z, 1.8);
    if (co) {
      const q = this.customers.filter((c) => c.state === "queue" && c.lane === co.id).length;
      this.interactTarget = { kind: "checkout", id: co.id };
      this.prompt = q ? `Checkout · ${q} waiting` : "Checkout lane";
      return;
    }
    const sh = this.nearestShelf(p.x, p.z, 1.7);
    if (sh) {
      this.interactTarget = { kind: "shelf", id: sh.id };
      const name = sh.productId ? PRODUCT_MAP[sh.productId].name : "Empty bay";
      if (p.holding) this.prompt = `Stock ${PRODUCT_MAP[p.holding.productId].name}`;
      else if (sh.broken) this.prompt = "Repair refrigerator · $80";
      else this.prompt = `${name} · ${sh.stock}/${sh.capacity}`;
      return;
    }
    if (this.inWarehouse(p.x, p.z)) {
      this.interactTarget = { kind: "pallet", id: "wh" };
      this.prompt = p.holding ? "Return crate" : "Pick up crate";
      return;
    }
    if (this.s.cleanliness < 0.55) {
      this.interactTarget = { kind: "dirt", id: "floor" };
      this.prompt = "Clean floor";
    }
  }

  toggleOpen(): void {
    if (this.s.storeOpen) {
      this.s.storeOpen = false;
      this.notify("Store closed. Customers will finish and leave.");
      return;
    }
    this.s.storeOpen = true;
    if (this.s.timeOfDay < OPEN_H || this.s.timeOfDay >= CLOSE_H) this.s.timeOfDay = OPEN_H;
    this.notify("Doors are open.");
  }

  closeDay(): void {
    this.s.storeOpen = false;
    this.s.timeOfDay = CLOSE_H;
    const loc = LOCATION_MAP[this.s.location];
    const rent = loc.rent * this.s.storeLevel;
    const power = 28 + this.s.storeLevel * 18 + this.s.shelves.filter((s) => s.kind === "fridge" || s.kind === "freezer").length * 6;
    const wages = this.s.staff.reduce((a, e) => a + ROLE_META[e.role].salary + (e.level - 1) * 12, 0);
    const expenses = rent + power + wages;
    this.s.money -= expenses;
    this.s.daily.expenses += expenses;
    const profit = this.s.daily.revenue - this.s.daily.expenses;
    this.report = {
      day: this.s.day,
      revenue: this.s.daily.revenue,
      expenses: this.s.daily.expenses,
      profit,
      sold: this.s.daily.sold,
      served: this.s.daily.served,
      lost: this.s.daily.lost,
      rating: this.s.rating,
      rent,
      power,
      wages,
    };
    const mgr = this.s.staff.some((e) => e.role === "manager");
    this.s.rating = clamp(this.s.rating + (mgr ? 0.05 : 0) + (this.s.cleanliness - 0.5) * 0.1, 1, 5);
  }

  nextDay(): void {
    this.s.day += 1;
    this.s.timeOfDay = OPEN_H;
    this.s.daily = { revenue: 0, expenses: 0, sold: 0, served: 0, lost: 0 };
    for (const id of PRODUCTS.map((p) => p.id)) this.s.soldToday[id] = 0;
    this.customers = [];
    this.s.event = null;
    this.report = null;
    this.rollMissions();
    this.unlockByXp();
    this.notify(`Day ${this.s.day} · ${LOCATION_MAP[this.s.location].name}`);
  }

  placeOrder(productId: ProductId, qty: number, supplierId: string): string {
    const p = PRODUCT_MAP[productId];
    const sup = SUPPLIERS.find((x) => x.id === supplierId) ?? SUPPLIERS[1]!;
    if (!this.s.unlocked[productId]) return "Product is locked.";
    if (qty < 1) return "Choose a quantity.";
    const spec =
      sup.specialty === "all" || sup.specialty === p.category || (sup.specialty === "frozen" && p.shelf === "freezer");
    const mul = spec ? sup.priceMul : sup.priceMul * 1.12;
    const bulk = qty >= 40 ? sup.bulk : 1;
    const cost = +(p.buyPrice * qty * mul * bulk).toFixed(2);
    if (cost > this.s.money) return "Not enough cash.";
    if (this.warehouseUsed() + qty > this.s.warehouseCap) return "Warehouse is full.";
    this.s.money -= cost;
    this.s.daily.expenses += cost;
    const eta = sup.delayMin * (0.7 + Math.random() * 0.5);
    this.s.orders.push({
      id: this.s.nextOrder++,
      productId,
      qty,
      supplierId: sup.id,
      cost,
      eta,
      delayed: false,
    });
    this.notify(`Ordered ${qty} ${p.name} from ${sup.name}.`);
    return "";
  }

  hire(role: EmployeeRole): string {
    const meta = ROLE_META[role];
    if (this.s.money < meta.hire) return "Not enough cash.";
    if (this.s.staff.filter((e) => e.role === role).length >= (role === "cashier" ? this.s.checkouts : 2))
      return "No more slots for that role.";
    this.s.money -= meta.hire;
    this.s.daily.expenses += meta.hire;
    const name = pick(STAFF_NAMES.filter((n) => !this.s.staff.some((e) => e.name === n))) || pick(STAFF_NAMES);
    this.s.staff.push({
      id: this.s.nextStaff++,
      role,
      name,
      level: 1,
      x: this.s.player.x,
      z: this.s.player.z,
      yaw: 0,
      target: null,
      path: [],
      wait: 0,
      holding: null,
      anim: 0,
      speed: 1.7,
    });
    this.notify(`Hired ${name} · ${meta.label}`);
    return "";
  }

  fire(id: number): void {
    this.s.staff = this.s.staff.filter((e) => e.id !== id);
    this.notify("Employee released.");
  }

  train(id: number): string {
    const e = this.s.staff.find((x) => x.id === id);
    if (!e) return "Missing staff.";
    const cost = 180 * e.level;
    if (this.s.money < cost) return "Not enough cash.";
    if (e.level >= 5) return "Already max level.";
    this.s.money -= cost;
    e.level += 1;
    this.notify(`${e.name} trained to Lv.${e.level}`);
    return "";
  }

  upgradeStore(): string {
    if (this.s.storeLevel >= 4) return "Already a hypermarket.";
    const cost = UPGRADE_COST[this.s.storeLevel] ?? 99999;
    if (this.s.money < cost) return `Need $${cost.toLocaleString()}.`;
    this.s.money -= cost;
    this.s.storeLevel += 1;
    this.s.checkouts = Math.min(4, this.s.storeLevel);
    this.s.warehouseCap += 80;
    for (const p of PRODUCTS) if (p.unlockLevel <= this.s.storeLevel) this.s.unlocked[p.id] = true;
    this.notify(`Upgraded to ${STORE_LABELS[this.s.storeLevel - 1]}.`);
    return "rebuild";
  }

  buyCheckout(): string {
    if (this.s.checkouts >= Math.min(4, this.s.storeLevel + 1)) return "No more lanes at this size.";
    if (this.s.money < 2500) return "Need $2,500.";
    this.s.money -= 2500;
    this.s.checkouts += 1;
    this.notify("New checkout installed.");
    return "rebuild";
  }

  buyLights(): string {
    if (this.s.lights >= 3) return "Lighting is maxed.";
    if (this.s.money < 1200) return "Need $1,200.";
    this.s.money -= 1200;
    this.s.lights += 1;
    this.s.rating = clamp(this.s.rating + 0.08, 1, 5);
    this.notify("Lighting improved.");
    return "";
  }

  buyDecor(): string {
    if (this.s.decor >= 3) return "Decor is maxed.";
    if (this.s.money < 1600) return "Need $1,600.";
    this.s.money -= 1600;
    this.s.decor += 1;
    this.s.rating = clamp(this.s.rating + 0.1, 1, 5);
    this.notify("Store dressed up.");
    return "";
  }

  expandWarehouse(): string {
    if (this.s.warehouseCap >= 600) return "Warehouse is maxed.";
    if (this.s.money < 2800) return "Need $2,800.";
    this.s.money -= 2800;
    this.s.warehouseCap += 120;
    this.notify("Warehouse expanded.");
    return "";
  }

  setLocation(id: LocationId): string {
    const loc = LOCATION_MAP[id];
    if (this.s.storeLevel < loc.unlockLevel) return `Requires ${STORE_LABELS[loc.unlockLevel - 1]}.`;
    if (this.s.location === id) return "Already here.";
    this.s.location = id;
    this.notify(`Relocated to ${loc.name}.`);
    return "";
  }

  setPrice(id: ProductId, mul: number): void {
    this.s.sellMul[id] = clamp(mul, 0.7, 1.8);
  }

  hud(): HudSnap {
    const hold = this.s.player.holding;
    const tut =
      this.s.tutorial === 0
        ? "Order stock from the Orders panel, then open the doors."
        : this.s.tutorial === 1
          ? "Walk to the warehouse (back of the store) and pick up a crate."
          : this.s.tutorial === 2
            ? "Carry the crate to a matching shelf and stock it."
            : this.s.tutorial === 3
              ? "Open the store and serve a customer at checkout (E)."
              : null;
    return {
      money: this.s.money,
      rating: this.s.rating,
      day: this.s.day,
      clock: clockStr(this.s.timeOfDay),
      open: this.s.storeOpen,
      prompt: this.prompt,
      holding: hold ? { ...hold, name: PRODUCT_MAP[hold.productId].name } : null,
      cleanliness: this.s.cleanliness,
      customers: this.customers.length,
      queue: this.customers.filter((c) => c.state === "queue").length,
      event: this.s.event?.label ?? null,
      tutorial: this.s.seenHelp ? null : tut,
      interact: !!this.interactTarget,
      speed: this.speed,
      yaw: this.s.player.yaw,
      px: this.s.player.x,
      pz: this.s.player.z,
      storeLevel: this.s.storeLevel,
      location: this.s.location,
      xp: this.s.xp,
    };
  }
}

export function freshSim(): Sim {
  return new Sim(defaultSim());
}
