import type {
  Bullet,
  Enemy,
  Floater,
  Input,
  Kind,
  Particle,
  Phase,
  Pickup,
  PickupKind,
  Player,
  Sim,
  Spawn,
  Star,
} from "@/game/types";
import { H, W } from "@/game/types";

const MAX_PLAYER_BULLETS = 72;
const MAX_ENEMY_BULLETS = 96;
const MAX_PARTICLES = 180;

function freshPlayer(): Player {
  return {
    x: W / 2,
    y: H - 150,
    vx: 0,
    vy: 0,
    r: 12,
    iframes: 0,
    fireCd: 0.2,
    multi: 0,
    shield: 0,
    speedT: 0,
    exhaust: 0,
    alive: true,
  };
}

function makeStars(): Star[] {
  const stars: Star[] = [];
  for (let i = 0; i < 120; i++) {
    const layer: 0 | 1 | 2 = i < 55 ? 0 : i < 95 ? 1 : 2;
    stars.push({
      x: Math.random() * W,
      y: Math.random() * H,
      layer,
      r: layer === 0 ? 0.7 : layer === 1 ? 1.15 : 1.8,
      a: 0.35 + Math.random() * 0.6,
    });
  }
  return stars;
}

export function createSim(reduceMotion = false): Sim {
  return {
    phase: "title",
    clock: 0,
    runTime: 0,
    score: 0,
    lives: 3,
    wave: 0,
    waveState: "banner",
    waveTimer: 0,
    banner: "",
    queue: [],
    player: freshPlayer(),
    bullets: [],
    enemies: [],
    pickups: [],
    particles: [],
    floats: [],
    flashes: [],
    stars: makeStars(),
    shake: 0,
    hitStop: 0,
    hurtFlash: 0,
    combo: 0,
    comboTimer: 0,
    reduceMotion,
    sfx: () => {},
    onChange: () => {},
  };
}

function setPhase(sim: Sim, phase: Phase) {
  if (sim.phase === phase) return;
  sim.phase = phase;
  queueMicrotask(() => sim.onChange());
}

export function startRun(sim: Sim) {
  sim.score = 0;
  sim.lives = 3;
  sim.wave = 0;
  sim.runTime = 0;
  sim.combo = 0;
  sim.comboTimer = 0;
  sim.player = freshPlayer();
  sim.bullets = [];
  sim.enemies = [];
  sim.pickups = [];
  sim.particles = [];
  sim.floats = [];
  sim.flashes = [];
  sim.shake = 0;
  sim.hitStop = 0;
  sim.hurtFlash = 0;
  sim.queue = [];
  beginWave(sim);
  setPhase(sim, "playing");
}

export function pauseRun(sim: Sim) {
  if (sim.phase === "playing") setPhase(sim, "paused");
}

export function resumeRun(sim: Sim) {
  if (sim.phase === "paused") setPhase(sim, "playing");
}

export function togglePause(sim: Sim) {
  if (sim.phase === "playing") pauseRun(sim);
  else if (sim.phase === "paused") resumeRun(sim);
}

export function toTitle(sim: Sim) {
  setPhase(sim, "title");
}

function beginWave(sim: Sim) {
  sim.wave += 1;
  sim.waveState = "banner";
  sim.waveTimer = 1.05;
  sim.banner = sim.wave % 5 === 0 ? `BOSS  ${sim.wave}` : `WAVE  ${sim.wave}`;
  sim.queue = buildQueue(sim.wave);
  sim.sfx(sim.wave % 5 === 0 ? "boss" : "wave");
}

function buildQueue(wave: number): Spawn[] {
  const out: Spawn[] = [];
  if (wave % 5 === 0) {
    out.push({ t: 0.2, kind: "boss", x: W / 2, y: -100, pattern: "boss", amp: 0 });
    const escorts = Math.min(6, 2 + Math.floor(wave / 5));
    for (let i = 0; i < escorts; i++) {
      out.push({
        t: 1.5 + i * 0.42,
        kind: "dart",
        x: 48 + (i % 6) * 60,
        y: -36,
        pattern: "down",
        amp: 0,
      });
    }
    return out;
  }
  const slot = wave % 5;
  if (slot === 1) {
    const count = Math.min(11, 5 + Math.floor(wave / 2));
    for (let i = 0; i < count; i++) {
      const col = i % 5;
      out.push({
        t: 0.1 + i * 0.18,
        kind: "dart",
        x: 46 + col * ((W - 92) / 4),
        y: -28 - Math.floor(i / 5) * 34,
        pattern: "down",
        amp: 0,
      });
    }
  } else if (slot === 2) {
    const count = Math.min(8, 4 + Math.floor(wave / 2));
    for (let i = 0; i < count; i++) {
      out.push({
        t: i * 0.3,
        kind: "weaver",
        x: i % 2 === 0 ? 100 : W - 100,
        y: -40,
        pattern: "sine",
        amp: 72 + (i % 3) * 20,
      });
    }
  } else if (slot === 3) {
    const guns = Math.min(4, 1 + Math.floor(wave / 3));
    for (let i = 0; i < guns; i++) {
      out.push({
        t: 0.15 + i * 0.65,
        kind: "gunner",
        x: W * (0.22 + (i % 3) * 0.28),
        y: -70,
        pattern: "down",
        amp: 0,
      });
    }
    const n = Math.min(8, 3 + Math.floor(wave / 2));
    for (let i = 0; i < n; i++) {
      out.push({
        t: 0.35 + i * 0.16,
        kind: "dart",
        x: 36 + ((i * 97) % (W - 72)),
        y: -24,
        pattern: "down",
        amp: 0,
      });
    }
  } else {
    for (let i = 0; i < 8; i++) {
      const left = i < 4;
      out.push({
        t: i * 0.15,
        kind: i % 4 === 0 ? "weaver" : "dart",
        x: left ? -28 : W + 28,
        y: 80 + (i % 4) * 52,
        pattern: "swoop",
        amp: left ? 1 : -1,
      });
    }
    const guns = Math.min(3, 1 + Math.floor(wave / 4));
    for (let i = 0; i < guns; i++) {
      out.push({
        t: 0.4 + i * 0.55,
        kind: "gunner",
        x: W * (0.3 + i * 0.2),
        y: -60,
        pattern: "down",
        amp: 0,
      });
    }
  }
  return out;
}

function stats(kind: Kind, wave: number): { hp: number; r: number; score: number } {
  if (kind === "dart") return { hp: 1 + Math.floor(wave / 8), r: 15, score: 100 };
  if (kind === "weaver") return { hp: 2 + Math.floor(wave / 6), r: 18, score: 160 };
  if (kind === "gunner") return { hp: 5 + Math.floor(wave / 4), r: 24, score: 280 };
  return { hp: 78 + wave * 8, r: 52, score: 2500 };
}

function spawnEnemy(sim: Sim, s: Spawn) {
  const st = stats(s.kind, sim.wave);
  const enemy: Enemy = {
    kind: s.kind,
    pattern: s.pattern,
    x: s.x,
    y: s.y,
    vx: 0,
    vy: 0,
    hp: st.hp,
    maxHp: st.hp,
    r: st.r,
    age: 0,
    shoot: s.kind === "boss" ? 3.3 : s.kind === "gunner" ? 1.2 : 1.6,
    originX: s.x,
    amp: s.amp,
    phase: Math.random() * Math.PI * 2,
    flash: 0,
    score: st.score,
    bossShot: 0,
    alive: true,
  };
  sim.enemies.push(enemy);
}

function countBullets(sim: Sim, friendly: boolean) {
  let n = 0;
  for (const b of sim.bullets) if (b.alive && b.friendly === friendly) n++;
  return n;
}

function pushBullet(
  sim: Sim,
  x: number,
  y: number,
  vx: number,
  vy: number,
  friendly: boolean,
  r: number,
) {
  if (countBullets(sim, friendly) >= (friendly ? MAX_PLAYER_BULLETS : MAX_ENEMY_BULLETS)) return;
  const bullet: Bullet = { x, y, vx, vy, r, friendly, life: friendly ? 1.6 : 4, alive: true };
  sim.bullets.push(bullet);
}

const SPREAD = [
  [0],
  [-0.18, 0, 0.18],
  [-0.34, -0.15, 0, 0.15, 0.34],
  [-0.42, -0.2, 0, 0.2, 0.42],
] as const;

function firePlayer(sim: Sim) {
  const p = sim.player;
  const angles = SPREAD[Math.min(3, p.multi)] ?? SPREAD[0];
  const speed = 760;
  for (const a of angles) {
    pushBullet(sim, p.x, p.y - 30, Math.sin(a) * speed, -Math.cos(a) * speed, true, 3.5);
    sim.flashes.push({
      x: p.x + Math.sin(a) * 10,
      y: p.y - 32,
      life: 0.06,
      max: 0.06,
      angle: a,
      alive: true,
    });
  }
  sim.sfx("shoot");
}

function fireAimed(sim: Sim, e: Enemy, speed: number, spread: number) {
  if (e.y < 8) return;
  const p = sim.player;
  const ang = Math.atan2(p.y - e.y, p.x - e.x) + (Math.random() - 0.5) * spread;
  pushBullet(sim, e.x, e.y + e.r * 0.4, Math.cos(ang) * speed, Math.sin(ang) * speed, false, 5);
}

function fireDown(sim: Sim, e: Enemy, speed: number) {
  if (e.y < 8) return;
  pushBullet(sim, e.x, e.y + e.r, (Math.random() - 0.5) * 30, speed, false, 4.5);
}

function fireBoss(sim: Sim, e: Enemy) {
  if (e.y < 70) return;
  e.bossShot += 1;
  if (e.bossShot % 2 === 0) {
    const gap = sim.runTime * 0.9;
    const n = 11;
    for (let i = 0; i < n; i++) {
      const a = gap + (i / n) * Math.PI * 2;
      pushBullet(sim, e.x, e.y, Math.cos(a) * 150, Math.sin(a) * 150, false, 5);
    }
  } else {
    const p = sim.player;
    const base = Math.atan2(p.y - e.y, p.x - e.x);
    for (const off of [-0.22, 0, 0.22]) {
      const a = base + off;
      pushBullet(sim, e.x, e.y + 20, Math.cos(a) * 250, Math.sin(a) * 250, false, 5.5);
    }
  }
}

function floatText(sim: Sim, x: number, y: number, text: string, color: string) {
  const item: Floater = { x, y, text, life: 0.8, max: 0.8, color, alive: true };
  sim.floats.push(item);
}

function burst(sim: Sim, x: number, y: number, color: string, n: number, speed = 180) {
  const count = sim.reduceMotion ? Math.ceil(n * 0.35) : n;
  for (let i = 0; i < count; i++) {
    if (sim.particles.length >= MAX_PARTICLES) break;
    const a = (i / count) * Math.PI * 2 + Math.random() * 0.2;
    const sp = speed * (0.35 + Math.random() * 0.75);
    const particle: Particle = {
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp,
      life: 0.35 + Math.random() * 0.35,
      max: 0.7,
      size: 1.5 + Math.random() * 2.4,
      color,
      alive: true,
    };
    sim.particles.push(particle);
  }
}

function dropChance(kind: Kind) {
  if (kind === "boss") return 1;
  if (kind === "gunner") return 0.45;
  if (kind === "weaver") return 0.22;
  return 0.14;
}

function rollKind(sim: Sim): PickupKind {
  if (sim.player.multi < 2 && Math.random() < 0.46) return "multi";
  if (Math.random() < 0.55) return "shield";
  return "speed";
}

function spawnPickup(sim: Sim, x: number, y: number, kind: PickupKind) {
  const pickup: Pickup = { kind, x, y, vy: 40, r: 14, life: 9, alive: true };
  sim.pickups.push(pickup);
}

function killEnemy(sim: Sim, e: Enemy) {
  if (!e.alive) return;
  e.alive = false;
  sim.combo = sim.comboTimer > 0 ? sim.combo + 1 : 1;
  sim.comboTimer = 1.35;
  const mult = Math.min(4, 1 + (sim.combo - 1) * 0.5);
  const gained = Math.round(e.score * mult);
  sim.score += gained;
  floatText(
    sim,
    e.x,
    e.y,
    sim.combo >= 2 ? `+${gained}  x${sim.combo}` : `+${gained}`,
    "#ffb020",
  );
  burst(sim, e.x, e.y, e.kind === "weaver" ? "#7dffe4" : e.kind === "dart" ? "#ff8aa8" : "#ffb020", e.kind === "boss" ? 28 : 12, e.kind === "boss" ? 260 : 160);
  if (!sim.reduceMotion) sim.shake = Math.min(16, sim.shake + (e.kind === "boss" ? 12 : 4));
  sim.hitStop = e.kind === "boss" ? 0.07 : 0.03;
  sim.sfx("explode");
  if (Math.random() < dropChance(e.kind)) spawnPickup(sim, e.x, e.y, rollKind(sim));
}

function clearEnemyBullets(sim: Sim) {
  for (const b of sim.bullets) if (!b.friendly) b.alive = false;
}

function hurtPlayer(sim: Sim) {
  const p = sim.player;
  if (!p.alive || p.iframes > 0) return;
  if (p.shield > 0) {
    p.shield = Math.max(0, p.shield - 1.5);
    if (!sim.reduceMotion) sim.shake = Math.min(10, sim.shake + 4);
    sim.sfx("hit");
    return;
  }
  sim.lives -= 1;
  p.iframes = 2;
  p.multi = Math.max(0, p.multi - 1);
  sim.hurtFlash = 0.4;
  if (!sim.reduceMotion) sim.shake = Math.min(16, sim.shake + 11);
  clearEnemyBullets(sim);
  burst(sim, p.x, p.y, "#ff3d7a", 18, 220);
  sim.sfx("hurt");
  if (sim.lives <= 0) {
    p.alive = false;
    sim.sfx("explode");
    setPhase(sim, "over");
  }
}

function collect(sim: Sim, kind: PickupKind) {
  const p = sim.player;
  if (kind === "multi") {
    p.multi = Math.min(3, p.multi + 1);
    floatText(sim, p.x, p.y - 28, "SPREAD", "#3ee0ff");
  } else if (kind === "shield") {
    p.shield = Math.min(12, p.shield + 9);
    floatText(sim, p.x, p.y - 28, "SHIELD", "#3ee0ff");
  } else {
    p.speedT = Math.min(14, p.speedT + 8);
    floatText(sim, p.x, p.y - 28, "BOOST", "#ffb020");
  }
  sim.sfx("pickup");
}

function grantWaveReward(sim: Sim) {
  const bonus = 120 * sim.wave;
  sim.score += bonus;
  floatText(sim, W / 2, H * 0.38, `CLEAR  +${bonus}`, "#e8eef8");
  const kind: PickupKind = sim.wave % 3 === 1 ? "multi" : sim.wave % 3 === 2 ? "shield" : "speed";
  spawnPickup(sim, W / 2 + (Math.random() * 80 - 40), 70, kind);
}

function stepStars(sim: Sim, dt: number, factor: number) {
  const speeds = [24, 58, 128];
  for (const s of sim.stars) {
    s.y += speeds[s.layer] * factor * dt;
    s.x += (s.layer - 1) * 6 * factor * dt;
    if (s.y > H) {
      s.y = 0;
      s.x = Math.random() * W;
    }
    if (s.x < 0) s.x += W;
    if (s.x > W) s.x -= W;
  }
}

function decayVisuals(sim: Sim, dt: number) {
  sim.shake = Math.max(0, sim.shake - dt * 26);
  sim.hurtFlash = Math.max(0, sim.hurtFlash - dt);
  for (const f of sim.flashes) {
    f.life -= dt;
    if (f.life <= 0) f.alive = false;
  }
  for (const p of sim.particles) {
    p.life -= dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vy += 40 * dt;
    if (p.life <= 0) p.alive = false;
  }
  for (const f of sim.floats) {
    f.life -= dt;
    f.y -= 36 * dt;
    if (f.life <= 0) f.alive = false;
  }
}

function compact<T extends { alive: boolean }>(arr: T[]) {
  let w = 0;
  for (let i = 0; i < arr.length; i++) {
    const item = arr[i];
    if (item && item.alive) arr[w++] = item;
  }
  arr.length = w;
}

function stepPlayer(sim: Sim, dt: number, input: Input) {
  const p = sim.player;
  if (!p.alive) return;
  const max = p.speedT > 0 ? 440 : 292;
  if (input.mode === "keys") {
    let ix = 0;
    let iy = 0;
    if (input.left) ix -= 1;
    if (input.right) ix += 1;
    if (input.up) iy -= 1;
    if (input.down) iy += 1;
    const len = Math.hypot(ix, iy);
    if (len > 0) {
      ix /= len;
      iy /= len;
      p.vx += ix * 2700 * dt;
      p.vy += iy * 2700 * dt;
      const sp = Math.hypot(p.vx, p.vy);
      if (sp > max) {
        p.vx = (p.vx / sp) * max;
        p.vy = (p.vy / sp) * max;
      }
    } else {
      const d = Math.exp(-10 * dt);
      p.vx *= d;
      p.vy *= d;
    }
  } else if (input.mode === "pointer") {
    const tx = input.px;
    let ty = input.py;
    if (input.touch) ty -= 78;
    const dx = tx - p.x;
    const dy = ty - p.y;
    const dist = Math.hypot(dx, dy);
    if (dist > 3) {
      const want = Math.min(max, dist * 8.5);
      const tvx = (dx / dist) * want;
      const tvy = (dy / dist) * want;
      const k = 1 - Math.exp(-12 * dt);
      p.vx += (tvx - p.vx) * k;
      p.vy += (tvy - p.vy) * k;
    } else {
      const d = Math.exp(-14 * dt);
      p.vx *= d;
      p.vy *= d;
    }
  } else {
    const d = Math.exp(-9 * dt);
    p.vx *= d;
    p.vy *= d;
  }

  p.x += p.vx * dt;
  p.y += p.vy * dt;
  const m = 26;
  if (p.x < m) {
    p.x = m;
    p.vx = 0;
  }
  if (p.x > W - m) {
    p.x = W - m;
    p.vx = 0;
  }
  if (p.y < 230) {
    p.y = 230;
    p.vy = 0;
  }
  if (p.y > H - 40) {
    p.y = H - 40;
    p.vy = 0;
  }

  if (p.iframes > 0) p.iframes -= dt;
  if (p.shield > 0) p.shield = Math.max(0, p.shield - dt);
  if (p.speedT > 0) p.speedT = Math.max(0, p.speedT - dt);

  p.fireCd -= dt;
  const rate = p.multi >= 3 ? 0.1 : 0.145;
  if (p.fireCd <= 0) {
    p.fireCd += rate;
    firePlayer(sim);
  }

  p.exhaust += dt;
  const exhaustRate = Math.hypot(p.vx, p.vy) > 40 ? 0.02 : 0.045;
  if (p.exhaust > exhaustRate && sim.particles.length < MAX_PARTICLES) {
    p.exhaust = 0;
    const particle: Particle = {
      x: p.x + (Math.random() - 0.5) * 8,
      y: p.y + 26,
      vx: (Math.random() - 0.5) * 20,
      vy: 80 + Math.random() * 70,
      life: 0.28,
      max: 0.28,
      size: 2 + Math.random() * 2,
      color: Math.random() > 0.45 ? "#ffb020" : "#3ee0ff",
      alive: true,
    };
    sim.particles.push(particle);
  }
}

function stepEnemy(sim: Sim, e: Enemy, dt: number) {
  e.age += dt;
  e.flash = Math.max(0, e.flash - dt * 6);
  const wave = sim.wave;
  if (e.pattern === "boss") {
    const targetY = 132;
    if (e.y < targetY) {
      e.vy = 72;
      e.vx = 0;
      e.y += e.vy * dt;
    } else {
      e.y = targetY;
      e.vy = 0;
      const span = W * 0.28;
      e.x = W / 2 + Math.sin(e.age * 0.7) * span;
      e.vx = Math.cos(e.age * 0.7) * span * 0.7;
    }
  } else if (e.pattern === "sine") {
    e.vy = 80 + wave * 3;
    e.y += e.vy * dt;
    const w = 2.05;
    e.x = e.originX + Math.sin(e.age * w + e.phase) * e.amp;
    e.vx = Math.cos(e.age * w + e.phase) * e.amp * w;
  } else if (e.pattern === "swoop") {
    const dir = e.amp >= 0 ? 1 : -1;
    const passed = dir > 0 ? e.x > W * 0.62 : e.x < W * 0.38;
    e.vx = dir * (passed ? 48 : 160 + wave * 3);
    e.vy = 96 + wave * 4;
    e.x += e.vx * dt;
    e.y += e.vy * dt;
  } else {
    const steer = Math.max(-80, Math.min(80, (sim.player.x - e.x) * 0.45));
    e.vx = steer;
    e.vy = (e.kind === "gunner" ? 58 : 124) + wave * (e.kind === "gunner" ? 2 : 6);
    if (e.kind === "gunner" && e.y > 160 && e.y < 300) e.vy = 26 + wave;
    e.x += e.vx * dt;
    e.y += e.vy * dt;
  }

  const armed = e.kind === "boss" || e.kind === "gunner" || (e.kind === "dart" && wave >= 6);
  if (armed) {
    e.shoot -= dt;
    if (e.shoot <= 0) {
      if (e.kind === "boss") fireBoss(sim, e);
      else if (e.kind === "gunner") fireAimed(sim, e, 200 + wave * 4, 0.06);
      else fireDown(sim, e, 230);
      e.shoot = e.kind === "boss" ? 0.92 : e.kind === "gunner" ? 1.4 : 1.7;
    }
  }

  if (e.kind !== "boss" && (e.y > H + 80 || e.x < -150 || e.x > W + 150)) e.alive = false;
}

function separate(sim: Sim) {
  const list = sim.enemies;
  for (let i = 0; i < list.length; i++) {
    const a = list[i];
    if (!a?.alive || a.kind === "boss") continue;
    for (let j = i + 1; j < list.length; j++) {
      const b = list[j];
      if (!b?.alive || b.kind === "boss") continue;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const d = Math.hypot(dx, dy) || 0.001;
      const min = (a.r + b.r) * 0.85;
      if (d < min) {
        const push = (min - d) * 0.5;
        const nx = dx / d;
        const ny = dy / d;
        a.x -= nx * push;
        a.y -= ny * push;
        b.x += nx * push;
        b.y += ny * push;
      }
    }
  }
}

function overlaps(ax: number, ay: number, ar: number, bx: number, by: number, br: number) {
  const dx = ax - bx;
  const dy = ay - by;
  const rr = ar + br;
  return dx * dx + dy * dy <= rr * rr;
}

function stepWorld(sim: Sim, dt: number, input: Input) {
  sim.runTime += dt;
  if (sim.comboTimer > 0) {
    sim.comboTimer -= dt;
    if (sim.comboTimer <= 0) sim.combo = 0;
  }

  stepPlayer(sim, dt, input);

  if (sim.waveState === "banner") {
    sim.waveTimer -= dt;
    if (sim.waveTimer <= 0) sim.waveState = "fight";
  } else if (sim.waveState === "fight") {
    for (const s of sim.queue) s.t -= dt;
    const ready: Spawn[] = [];
    const waiting: Spawn[] = [];
    for (const s of sim.queue) (s.t <= 0 ? ready : waiting).push(s);
    sim.queue = waiting;
    for (const s of ready) spawnEnemy(sim, s);
    if (sim.queue.length === 0 && sim.enemies.every((e) => !e.alive)) {
      sim.waveState = "clear";
      sim.waveTimer = 1.2;
      grantWaveReward(sim);
    }
  } else {
    sim.waveTimer -= dt;
    if (sim.waveTimer <= 0) beginWave(sim);
  }

  for (const e of sim.enemies) if (e.alive) stepEnemy(sim, e, dt);
  separate(sim);

  for (const b of sim.bullets) {
    if (!b.alive) continue;
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    b.life -= dt;
    if (b.life <= 0 || b.y < -40 || b.y > H + 50 || b.x < -40 || b.x > W + 40) b.alive = false;
  }

  const p = sim.player;
  let hurt = false;
  const tryHurt = () => {
    if (hurt || !p.alive) return;
    hurt = true;
    hurtPlayer(sim);
  };

  for (const b of sim.bullets) {
    if (!b.alive || !b.friendly) continue;
    for (const e of sim.enemies) {
      if (!e.alive) continue;
      if (!overlaps(b.x, b.y, b.r, e.x, e.y, e.r)) continue;
      b.alive = false;
      e.hp -= 1;
      e.flash = 1;
      if (e.hp <= 0) killEnemy(sim, e);
      else sim.sfx("hit");
      break;
    }
  }

  if (p.alive) {
    for (const b of sim.bullets) {
      if (!b.alive || b.friendly) continue;
      if (overlaps(b.x, b.y, b.r, p.x, p.y, p.r)) {
        b.alive = false;
        tryHurt();
      }
    }
    for (const e of sim.enemies) {
      if (!e.alive) continue;
      if (!overlaps(e.x, e.y, e.r * 0.72, p.x, p.y, p.r)) continue;
      tryHurt();
      if (e.kind !== "boss" && p.shield > 0) killEnemy(sim, e);
    }
    for (const item of sim.pickups) {
      if (!item.alive) continue;
      item.life -= dt;
      item.vy = Math.min(120, item.vy + 18 * dt);
      item.y += item.vy * dt;
      const dx = p.x - item.x;
      const dy = p.y - item.y;
      const dist = Math.hypot(dx, dy);
      if (dist < 120 && dist > 0.01) {
        item.x += (dx / dist) * 120 * dt;
        item.y += (dy / dist) * 120 * dt;
      }
      if (dist < p.r + item.r + 6) {
        item.alive = false;
        collect(sim, item.kind);
      } else if (item.y > H + 40 || item.life <= 0) item.alive = false;
    }
  }

  if (sim.phase !== "playing") return;

  compact(sim.bullets);
  compact(sim.enemies);
  compact(sim.pickups);
  compact(sim.particles);
  compact(sim.floats);
  compact(sim.flashes);
}

export function step(sim: Sim, dt: number, input: Input) {
  const capped = Math.min(0.05, dt);
  sim.clock += capped;
  if (sim.phase === "title") {
    stepStars(sim, capped, 1);
    decayVisuals(sim, capped);
    return;
  }
  if (sim.phase === "over") {
    stepStars(sim, capped, 0.35);
    decayVisuals(sim, capped);
    return;
  }
  if (sim.phase === "paused") return;

  if (sim.hitStop > 0) {
    sim.hitStop -= capped;
    stepStars(sim, capped, 0.15);
    decayVisuals(sim, capped);
    return;
  }

  stepStars(sim, capped, 1);
  stepWorld(sim, capped, input);
  decayVisuals(sim, capped);
  if (sim.phase === "playing") {
    compact(sim.bullets);
    compact(sim.enemies);
    compact(sim.pickups);
    compact(sim.particles);
    compact(sim.floats);
    compact(sim.flashes);
  }
}
