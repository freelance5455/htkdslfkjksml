/** Arcade-sim hot hatch. +steer / +wheel / +yaw = left. */

export const REDLINE = 7000;
export const IDLE_RPM = 850;
export const MAX_WHEEL = (430 * Math.PI) / 180;
export const TRACK_RADIUS = 24;
export const TRACK_STRAIGHT = 64;
export const ROAD_HALF = 4.7;

export type PathPt = { x: number; z: number };

export type Shift = { from: number; to: number; u: number };

export type SimState = {
  x: number;
  z: number;
  yaw: number;
  speed: number;
  wheel: number;
  wheelVel: number;
  throttle: number;
  brake: number;
  steer: number;
  gear: number;
  rpm: number;
  clutch: number;
  shift: Shift | null;
  queue: number;
  time: number;
  longG: number;
  latG: number;
  overrun: number;
  /** Positive = exhaust pop strength. */
  pops: number[];
  gearPing: boolean;
  edge: number;
  started: boolean;
  flare: number;
  prevThrottle: number;
};

export type SimInput = {
  steer: number;
  throttle: number;
  brake: number;
  sensitivity: number;
  /** +1 up, -1 down, 0 none. Edge-triggered by the caller. */
  shift: number;
};

const GEAR_RPM_PER_MS = [0, 470, 290, 198, 150, 122, 102];
const GEAR_FORCE = [0, 8400, 6100, 4600, 3500, 2750, 2250];
const MASS = 1180;
const WHEELBASE = 2.48;
const MAX_TIRE = 0.46;

export function createSim(): SimState {
  return {
    x: -TRACK_RADIUS,
    z: TRACK_STRAIGHT * 0.28,
    yaw: 0,
    speed: 0,
    wheel: 0,
    wheelVel: 0,
    throttle: 0,
    brake: 0,
    steer: 0,
    gear: 1,
    rpm: IDLE_RPM,
    clutch: 1,
    shift: null,
    queue: -1,
    time: 0,
    longG: 0,
    latG: 0,
    overrun: 0,
    pops: [],
    gearPing: false,
    edge: 0,
    started: false,
    flare: 0,
    prevThrottle: 0,
  };
}

export function buildOval(): PathPt[] {
  const radius = TRACK_RADIUS;
  const straight = TRACK_STRAIGHT;
  const pts: PathPt[] = [];
  const strSteps = 24;
  const arcSteps = 16;
  for (let i = 0; i <= strSteps; i++) {
    const t = i / strSteps;
    pts.push({ x: -radius, z: straight / 2 - t * straight });
  }
  for (let i = 1; i <= arcSteps; i++) {
    const ang = Math.PI + (i / arcSteps) * Math.PI;
    pts.push({
      x: radius * Math.cos(ang),
      z: -straight / 2 + radius * Math.sin(ang),
    });
  }
  for (let i = 1; i <= strSteps; i++) {
    const t = i / strSteps;
    pts.push({ x: radius, z: -straight / 2 + t * straight });
  }
  for (let i = 1; i < arcSteps; i++) {
    const ang = (i / arcSteps) * Math.PI;
    pts.push({
      x: radius * Math.cos(ang),
      z: straight / 2 + radius * Math.sin(ang),
    });
  }
  return pts;
}

export const TRACK = buildOval();

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

function smoothstep(e0: number, e1: number, x: number) {
  const t = clamp((x - e0) / (e1 - e0), 0, 1);
  return t * t * (3 - 2 * t);
}

function shapeSteer(input: number) {
  const s = Math.sign(input);
  const a = Math.abs(input);
  return s * (a * 0.7 + a * a * 0.3);
}

function torqueCurve(rpm: number) {
  const t = clamp((rpm - 900) / 5600, 0, 1);
  const hump = Math.sin(Math.pow(t, 0.7) * Math.PI);
  const idlePull = rpm < 1100 ? 0.48 : 0;
  return Math.max(idlePull, 0.38 + 0.62 * hump) * (rpm > 6600 ? 0.82 : 1);
}

function clutchOf(u: number) {
  if (u < 0.14) return 1 - u / 0.14;
  if (u < 0.46) return 0;
  if (u < 0.68) return (u - 0.46) / 0.22;
  return 1;
}

function beginShift(sim: SimState, target: number) {
  if (target === sim.gear || sim.shift) {
    if (sim.shift && target !== sim.shift.to) sim.queue = target;
    return;
  }
  sim.shift = { from: sim.gear, to: target, u: 0 };
}

function constrain(sim: SimState) {
  const pts = TRACK;
  const n = pts.length;
  let best = Infinity;
  let bx = sim.x;
  let bz = sim.z;
  for (let i = 0; i < n; i++) {
    const a = pts[i]!;
    const b = pts[(i + 1) % n]!;
    const sx = b.x - a.x;
    const sz = b.z - a.z;
    const sl2 = sx * sx + sz * sz || 1;
    let t = ((sim.x - a.x) * sx + (sim.z - a.z) * sz) / sl2;
    t = clamp(t, 0, 1);
    const px = a.x + sx * t;
    const pz = a.z + sz * t;
    const dx = sim.x - px;
    const dz = sim.z - pz;
    const d2 = dx * dx + dz * dz;
    if (d2 < best) {
      best = d2;
      bx = px;
      bz = pz;
    }
  }
  const dist = Math.sqrt(best);
  const over = dist - ROAD_HALF;
  if (over > 0) {
    let vx = sim.x - bx;
    let vz = sim.z - bz;
    const vl = Math.hypot(vx, vz) || 1;
    vx /= vl;
    vz /= vl;
    const pull = Math.min(over, 0.06 + over * 0.45);
    sim.x -= vx * pull;
    sim.z -= vz * pull;
    const grass = clamp(over / 2.4, 0, 1);
    sim.speed *= 1 - grass * 0.12;
    sim.edge = over < 0.85 ? 0.65 : grass * 0.4;
    if (dist > ROAD_HALF + 2.8) {
      sim.x = bx + vx * (ROAD_HALF + 2.8);
      sim.z = bz + vz * (ROAD_HALF + 2.8);
      sim.speed *= 0.9;
    }
  } else {
    sim.edge = over > -0.65 ? (over + 0.65) / 0.65 : 0;
  }
}

export function stepSim(sim: SimState, dt: number, input: SimInput) {
  sim.time += dt;
  sim.gearPing = false;
  sim.flare *= Math.exp(-dt * 5.5);

  if (!sim.started) {
    sim.rpm = IDLE_RPM + Math.sin(sim.time * 3.2) * 18;
    sim.throttle = 0;
    sim.brake = 0;
    return;
  }

  if (input.shift !== 0) {
    const target = clamp(sim.gear + input.shift, 0, 6);
    beginShift(sim, target);
  }

  if (sim.shift) {
    sim.shift.u += dt / 0.74;
    sim.clutch = clutchOf(sim.shift.u);
    if (sim.shift.u >= 0.4 && sim.gear !== sim.shift.to) {
      const from = sim.gear;
      const to = sim.shift.to;
      if (to > from && sim.rpm > 4000) {
        sim.pops.push(0.55 + (sim.rpm / REDLINE) * 0.7);
        sim.pops.push(0.32 + Math.random() * 0.3);
      }
      if (to < from && to > 0 && sim.speed > 4) {
        const match = Math.abs(sim.speed) * GEAR_RPM_PER_MS[to]!;
        sim.flare = Math.max(sim.flare, Math.min(REDLINE - 200, match));
        sim.pops.push(0.48 + Math.random() * 0.25);
      }
      sim.gear = to;
      sim.gearPing = true;
    }
    if (sim.shift.u >= 1) {
      sim.shift = null;
      sim.clutch = 1;
      if (sim.queue >= 0) {
        const q = sim.queue;
        sim.queue = -1;
        beginShift(sim, q);
      }
    }
  } else {
    sim.clutch = 1;
  }

  const sens = clamp(input.sensitivity, 0.45, 1.75);
  const shaped = shapeSteer(clamp(input.steer, -1, 1));
  const speedSens = lerp(1, 0.4, smoothstep(6, 38, Math.abs(sim.speed)));
  const target = shaped * MAX_WHEEL * speedSens * sens;
  const k = 70 + Math.min(Math.abs(sim.speed), 28) * 2.4;
  const dampC = 12.5 + Math.min(Math.abs(sim.speed), 22) * 0.22;
  sim.wheelVel += ((target - sim.wheel) * k - sim.wheelVel * dampC) * dt;
  sim.wheel += sim.wheelVel * dt;
  sim.wheel = clamp(sim.wheel, -MAX_WHEEL, MAX_WHEEL);
  sim.steer = shaped;

  const steerNorm = sim.wheel / MAX_WHEEL;
  const tire = steerNorm * MAX_TIRE;
  const prevSpeed = sim.speed;

  const rpmRoad = sim.gear === 0 ? 0 : Math.abs(sim.speed) * GEAR_RPM_PER_MS[sim.gear]!;
  let rpmTarget: number;
  if (sim.gear === 0 || sim.clutch < 0.35) {
    rpmTarget = IDLE_RPM + input.throttle * 5200;
  } else {
    const free = IDLE_RPM + input.throttle * (sim.gear === 1 ? 3400 : 2200);
    if (input.throttle > 0.18 && rpmRoad < free) {
      rpmTarget = free;
    } else {
      rpmTarget = Math.max(IDLE_RPM * 0.85, rpmRoad);
    }
  }
  if (rpmTarget > REDLINE) rpmTarget = REDLINE - 60;
  const follow = 1 - Math.exp(-dt * (sim.clutch > 0.6 ? 14 : 8));
  sim.rpm += (rpmTarget - sim.rpm) * follow;
  sim.rpm = Math.max(sim.rpm, IDLE_RPM * 0.7);

  let drive = 0;
  if (sim.gear > 0 && sim.clutch > 0.05) {
    let cut = 1;
    if (sim.rpm > REDLINE - 180 && input.throttle > 0.55) {
      const gate = Math.sin(sim.time * 62);
      cut = gate > 0 ? 1 : 0.22;
      if (gate > 0.92) sim.pops.push(0.36 + Math.random() * 0.2);
    }
    drive = input.throttle * torqueCurve(sim.rpm) * GEAR_FORCE[sim.gear]! * sim.clutch * cut;
  }

  const brakeF = input.brake * 14500;
  const drag = sim.speed * Math.abs(sim.speed) * 0.4 + sim.speed * 20;
  let engineBrake = 0;
  if (sim.gear > 0 && input.throttle < 0.08 && sim.clutch > 0.55 && sim.speed > 0.4) {
    engineBrake = (sim.rpm / REDLINE) * 2400 * sim.clutch;
  }
  const net = drive - brakeF - drag - engineBrake;
  sim.speed += (net / MASS) * dt;
  if (sim.speed < 0) sim.speed = 0;

  const yawBicycle = (sim.speed / WHEELBASE) * Math.tan(tire);
  const lowAssist = 0.95 * steerNorm * Math.min(1, sim.speed / 2);
  const yawRate = yawBicycle + lowAssist;
  sim.yaw += yawRate * dt;

  const fx = -Math.sin(sim.yaw);
  const fz = -Math.cos(sim.yaw);
  sim.x += fx * sim.speed * dt;
  sim.z += fz * sim.speed * dt;

  sim.longG = (sim.speed - prevSpeed) / Math.max(dt, 1e-4) / 9.81;
  sim.latG = (sim.speed * yawRate) / 9.81;

  const lifting = sim.prevThrottle > 0.42 && input.throttle < 0.1;
  if (lifting && sim.rpm > 3400 && sim.gear > 0 && sim.clutch > 0.55) {
    const n = 3 + Math.floor(sim.rpm / 2000);
    for (let i = 0; i < n; i++) sim.pops.push(0.4 + Math.random() * 0.75 * (sim.rpm / REDLINE));
  }
  const coast =
    input.throttle < 0.12 &&
    sim.brake < 0.2 &&
    sim.rpm > 3000 &&
    sim.gear > 0 &&
    sim.speed > 5 &&
    sim.clutch > 0.6;
  sim.overrun = coast ? clamp((sim.rpm - 2800) / 3800, 0, 1) : 0;
  if (coast && Math.random() < dt * (3.2 + sim.rpm / 1100)) {
    sim.pops.push(0.22 + Math.random() * 0.55 * sim.overrun);
  }

  if (sim.pops.length > 8) sim.pops.splice(0, sim.pops.length - 8);

  constrain(sim);
  sim.throttle = input.throttle;
  sim.brake = input.brake;
  sim.prevThrottle = input.throttle;
}
