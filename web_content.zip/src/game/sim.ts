/** Grid maze + circle collision. Axis-aligned hedges, separate-axis slide. */

export const CELL = 2.5;
export const PLAYER_RADIUS = 0.34;
export const EYE = 1.62;
export const WALK_SPEED = 4.55;
export const SPRINT_SPEED = 7.15;

export type Cell = { x: number; z: number };

export type MazeData = {
  seed: number;
  w: number;
  h: number;
  walls: Uint8Array;
  start: Cell;
  exit: Cell;
  pickups: Cell[];
};

export type MoveResult = {
  x: number;
  z: number;
  blockedX: boolean;
  blockedZ: boolean;
};

const DIRS = [
  [1, 0],
  [-1, 0],
  [0, 1],
  [0, -1],
] as const;

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function isWall(maze: MazeData, x: number, z: number) {
  if (x < 0 || z < 0 || x >= maze.w || z >= maze.h) return true;
  return maze.walls[z * maze.w + x] === 1;
}

export function cellCenter(cell: Cell) {
  return { x: (cell.x + 0.5) * CELL, z: (cell.z + 0.5) * CELL };
}

/** yaw 0 faces world −Z. +yaw turns the nose toward −X (CCW about +Y). */
export function basis(yaw: number) {
  return {
    fx: -Math.sin(yaw),
    fz: -Math.cos(yaw),
    rx: Math.cos(yaw),
    rz: -Math.sin(yaw),
  };
}

/** FPS strafe wish direction. inputF > 0 forward, inputR > 0 strafe right. */
export function wishVelocity(yaw: number, inputF: number, inputR: number) {
  const b = basis(yaw);
  return {
    x: b.fx * inputF + b.rx * inputR,
    z: b.fz * inputF + b.rz * inputR,
  };
}

export function preferredYaw(maze: MazeData, cell: Cell) {
  const { x, z } = cell;
  if (!isWall(maze, x, z - 1)) return 0;
  if (!isWall(maze, x + 1, z)) return -Math.PI / 2;
  if (!isWall(maze, x, z + 1)) return Math.PI;
  if (!isWall(maze, x - 1, z)) return Math.PI / 2;
  return 0;
}

/** Torus hole along Z by default. Rotate π/2 when the entrance is on X. */
export function gateRotY(maze: MazeData) {
  const { x, z } = maze.exit;
  if (!isWall(maze, x - 1, z) || !isWall(maze, x + 1, z)) return Math.PI / 2;
  return 0;
}

function shuffle<T>(items: T[], rng: () => number) {
  const arr = items.slice();
  for (let i = arr.length - 1; i > 0; i--) {
    const j = (rng() * (i + 1)) | 0;
    const tmp = arr[i];
    arr[i] = arr[j]!;
    arr[j] = tmp!;
  }
  return arr;
}

export function generateMaze(seed: number, rooms = 7): MazeData {
  const rng = mulberry32(seed);
  const w = rooms * 2 + 1;
  const h = rooms * 2 + 1;
  const walls = new Uint8Array(w * h);
  walls.fill(1);

  const seen = new Uint8Array(rooms * rooms);
  const stack: Array<[number, number]> = [[0, 0]];
  seen[0] = 1;
  walls[1 * w + 1] = 0;

  while (stack.length) {
    const [i, j] = stack[stack.length - 1]!;
    const options: Array<[number, number, number, number]> = [];
    for (const [di, dj] of DIRS) {
      const ni = i + di;
      const nj = j + dj;
      if (ni < 0 || nj < 0 || ni >= rooms || nj >= rooms) continue;
      if (seen[nj * rooms + ni]) continue;
      options.push([ni, nj, di, dj]);
    }
    if (!options.length) {
      stack.pop();
      continue;
    }
    const pick = options[(rng() * options.length) | 0]!;
    const ni = pick[0];
    const nj = pick[1];
    const di = pick[2];
    const dj = pick[3];
    const x = i * 2 + 1;
    const z = j * 2 + 1;
    walls[(z + dj) * w + (x + di)] = 0;
    walls[(z + 2 * dj) * w + (x + 2 * di)] = 0;
    seen[nj * rooms + ni] = 1;
    stack.push([ni, nj]);
  }

  const start = { x: 1, z: 1 };
  const exit = { x: w - 2, z: h - 2 };

  const floors: Cell[] = [];
  for (let z = 1; z < h - 1; z++) {
    for (let x = 1; x < w - 1; x++) {
      if (walls[z * w + x]) continue;
      floors.push({ x, z });
    }
  }

  const degree = (c: Cell) => {
    let n = 0;
    for (const [dx, dz] of DIRS) {
      if (!isWall({ seed, w, h, walls, start, exit, pickups: [] }, c.x + dx, c.z + dz)) n++;
    }
    return n;
  };

  const far = (c: Cell, min: number) =>
    Math.abs(c.x - start.x) + Math.abs(c.z - start.z) > min &&
    !(c.x === exit.x && c.z === exit.z);

  const dead = shuffle(
    floors.filter((c) => degree(c) === 1 && far(c, 2)),
    rng,
  );
  const pickups: Cell[] = [];
  for (const c of dead) {
    if (pickups.length >= 8) break;
    pickups.push(c);
  }
  const rest = shuffle(
    floors.filter(
      (c) =>
        far(c, 4) &&
        !pickups.some((p) => p.x === c.x && p.z === c.z) &&
        degree(c) >= 2,
    ),
    rng,
  );
  for (const c of rest) {
    if (pickups.length >= 10) break;
    if (pickups.some((p) => Math.abs(p.x - c.x) + Math.abs(p.z - c.z) < 4)) continue;
    pickups.push(c);
  }

  return { seed, w, h, walls, start, exit, pickups };
}

export function circleHits(maze: MazeData, px: number, pz: number, radius: number) {
  const skin = radius - 0.006;
  if (skin <= 0) return false;
  const r2 = skin * skin;
  const minX = Math.floor((px - radius) / CELL);
  const maxX = Math.floor((px + radius) / CELL);
  const minZ = Math.floor((pz - radius) / CELL);
  const maxZ = Math.floor((pz + radius) / CELL);
  for (let z = minZ; z <= maxZ; z++) {
    for (let x = minX; x <= maxX; x++) {
      if (!isWall(maze, x, z)) continue;
      const nx = Math.max(x * CELL, Math.min(px, (x + 1) * CELL));
      const nz = Math.max(z * CELL, Math.min(pz, (z + 1) * CELL));
      const dx = px - nx;
      const dz = pz - nz;
      if (dx * dx + dz * dz < r2) return true;
    }
  }
  return false;
}

function depenetrate(maze: MazeData, x: number, z: number, radius: number) {
  if (!circleHits(maze, x, z, radius)) return { x, z };
  for (let i = 1; i <= 18; i++) {
    const s = i * 0.045;
    const tries = [
      [s, 0],
      [-s, 0],
      [0, s],
      [0, -s],
      [s, s],
      [s, -s],
      [-s, s],
      [-s, -s],
    ];
    for (const [dx, dz] of tries) {
      if (!circleHits(maze, x + dx!, z + dz!, radius)) return { x: x + dx!, z: z + dz! };
    }
  }
  return { x, z };
}

/**
 * Substepped circle move. X then Z so corridors slide instead of sticking.
 * Steps stay under the radius so a fast frame cannot tunnel a hedge.
 */
export function moveCircle(
  maze: MazeData,
  px: number,
  pz: number,
  dx: number,
  dz: number,
  radius: number,
): MoveResult {
  let x = px;
  let z = pz;
  if (circleHits(maze, x, z, radius)) {
    const freed = depenetrate(maze, x, z, radius);
    x = freed.x;
    z = freed.z;
  }
  const dist = Math.hypot(dx, dz);
  const steps = Math.max(1, Math.ceil(dist / 0.12));
  const sx = dx / steps;
  const sz = dz / steps;
  let blockedX = false;
  let blockedZ = false;
  for (let i = 0; i < steps; i++) {
    const nx = x + sx;
    if (!circleHits(maze, nx, z, radius)) x = nx;
    else blockedX = true;
    const nz = z + sz;
    if (!circleHits(maze, x, nz, radius)) z = nz;
    else blockedZ = true;
  }
  return { x, z, blockedX, blockedZ };
}

/** Reveal open cells a few steps ahead, never through hedges. */
export function revealAround(maze: MazeData, px: number, pz: number, visited: Uint8Array) {
  const sx = Math.floor(px / CELL);
  const sz = Math.floor(pz / CELL);
  if (sx < 0 || sz < 0 || sx >= maze.w || sz >= maze.h) return;
  const w = maze.w;
  const seen = new Uint8Array(maze.w * maze.h);
  const q: Array<[number, number, number]> = [[sx, sz, 0]];
  seen[sz * w + sx] = 1;
  let qi = 0;
  while (qi < q.length) {
    const [x, z, d] = q[qi++]!;
    if (isWall(maze, x, z)) continue;
    visited[z * w + x] = 1;
    if (d >= 4) continue;
    for (const [dx, dz] of DIRS) {
      const nx = x + dx;
      const nz = z + dz;
      if (nx < 0 || nz < 0 || nx >= maze.w || nz >= maze.h) continue;
      const k = nz * w + nx;
      if (seen[k] || isWall(maze, nx, nz)) continue;
      seen[k] = 1;
      q.push([nx, nz, d + 1]);
    }
  }
}

export function mapCellVisible(maze: MazeData, x: number, z: number, visited: Uint8Array) {
  if (!isWall(maze, x, z)) return visited[z * maze.w + x] === 1;
  for (const [dx, dz] of DIRS) {
    const nx = x + dx;
    const nz = z + dz;
    if (nx < 0 || nz < 0 || nx >= maze.w || nz >= maze.h) continue;
    if (!isWall(maze, nx, nz) && visited[nz * maze.w + nx]) return true;
  }
  return false;
}

export function formatTime(ms: number) {
  const clamped = Math.max(0, ms);
  const total = clamped / 1000;
  const m = Math.floor(total / 60);
  const s = total - m * 60;
  const whole = Math.floor(s);
  const tenth = Math.floor((s - whole) * 10);
  return `${m}:${String(whole).padStart(2, "0")}.${tenth}`;
}
