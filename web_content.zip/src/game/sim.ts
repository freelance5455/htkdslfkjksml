import { clamp, HALF_H, HALF_W, GOAL_HALF, GOAL_H, len, lerp, lerpAngle, norm, rand } from "./math";
import type { Actions } from "./input";
import type { Difficulty } from "./save";
import type { Role, TeamDef } from "./teams";

export type Player = {
  id: number;
  team: 0 | 1;
  name: string;
  num: number;
  role: Role;
  x: number;
  y: number;
  px: number;
  py: number;
  vx: number;
  vy: number;
  facing: number;
  stamina: number;
  cooldown: number;
  anim: number;
  skin: number;
  hair: number;
};

export type Ball = {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  px: number;
  py: number;
  pz: number;
  owner: number | null;
  spin: number;
  lastKicker: number;
  lastKickT: number;
};

export type Phase = "kickoff" | "play" | "goal" | "halftime" | "fulltime" | "setpiece";

export type Match = {
  players: Player[];
  ball: Ball;
  score: [number, number];
  clock: number;
  half: 1 | 2;
  phase: Phase;
  phaseT: number;
  controlled: number;
  userTeam: 0 | 1 | -1;
  attack: [number, number];
  event: string;
  eventT: number;
  excitement: number;
  trauma: number;
  shootHold: number;
  home: TeamDef;
  away: TeamDef;
  difficulty: Difficulty;
  practice: boolean;
  autoSwitch: boolean;
  ended: boolean;
  lastScorer: 0 | 1;
};

const SKIN = ["#f3d2b5", "#e0b089", "#c68642", "#8d5524", "#5c3317", "#f6e0c8"];
const HAIR = ["#1a120c", "#3b2314", "#6b4a2b", "#111111", "#4a2c12", "#c8b48a"];

const FORM: Record<Role, [number, number][]> = {
  gk: [[-47.2, 0]],
  def: [
    [-33, -24],
    [-35, -8],
    [-35, 8],
    [-33, 24],
  ],
  mid: [
    [-18, -16],
    [-22, 0],
    [-18, 16],
  ],
  fwd: [
    [6, -22],
    [12, 0],
    [6, 22],
  ],
};

function diffMul(d: Difficulty) {
  if (d === "amateur") return { ai: 0.72, acc: 0.55, press: 0.7, gk: 0.75 };
  if (d === "world") return { ai: 1.12, acc: 1.05, press: 1.2, gk: 1.15 };
  return { ai: 0.95, acc: 0.88, press: 1, gk: 0.95 };
}

function makePlayer(id: number, team: 0 | 1, def: TeamDef, slot: number, attack: number): Player {
  const s = def.squad[slot]!;
  const [bx, by] = homeSlot(s.role, slotRoleIndex(def, slot), attack);
  return {
    id,
    team,
    name: s.name,
    num: s.num,
    role: s.role,
    x: bx,
    y: by,
    px: bx,
    py: by,
    vx: 0,
    vy: 0,
    facing: attack > 0 ? 0 : Math.PI,
    stamina: 1,
    cooldown: 0,
    anim: Math.random() * 10,
    skin: Math.floor(Math.random() * SKIN.length),
    hair: Math.floor(Math.random() * HAIR.length),
  };
}

function slotRoleIndex(def: TeamDef, slot: number) {
  const role = def.squad[slot]!.role;
  let n = 0;
  for (let i = 0; i < slot; i++) if (def.squad[i]!.role === role) n++;
  return n;
}

function homeSlot(role: Role, idx: number, attack: number): [number, number] {
  const list = FORM[role];
  const [x, y] = list[Math.min(idx, list.length - 1)]!;
  return [x * attack, y];
}

export function createMatch(
  home: TeamDef,
  away: TeamDef,
  opts: { userTeam: 0 | 1 | -1; difficulty: Difficulty; practice?: boolean; autoSwitch?: boolean },
): Match {
  const attack: [number, number] = [1, -1];
  const players: Player[] = [];
  for (let i = 0; i < 11; i++) players.push(makePlayer(i, 0, home, i, attack[0]));
  for (let i = 0; i < 11; i++) players.push(makePlayer(11 + i, 1, away, i, attack[1]));
  const st = players.find((p) => p.team === (opts.userTeam === -1 ? 0 : opts.userTeam) && p.role === "fwd" && p.num === 9) ?? players[9]!;
  return {
    players,
    ball: {
      x: 0,
      y: 0,
      z: 0.22,
      vx: 0,
      vy: 0,
      vz: 0,
      px: 0,
      py: 0,
      pz: 0.22,
      owner: null,
      spin: 0,
      lastKicker: -1,
      lastKickT: 0,
    },
    score: [0, 0],
    clock: 0,
    half: 1,
    phase: "kickoff",
    phaseT: 0,
    controlled: opts.userTeam === -1 ? -1 : st.id,
    userTeam: opts.userTeam,
    attack,
    event: "Kick off",
    eventT: 1.6,
    excitement: 0.2,
    trauma: 0,
    shootHold: 0,
    home,
    away,
    difficulty: opts.difficulty,
    practice: !!opts.practice,
    autoSwitch: opts.autoSwitch !== false,
    ended: false,
    lastScorer: 0,
  };
}

function teamOf(m: Match, t: 0 | 1) {
  return t === 0 ? m.home : m.away;
}

function rating(m: Match, p: Player) {
  const tm = teamOf(m, p.team);
  if (p.role === "gk") return tm.def / 100;
  if (p.role === "def") return tm.def / 100;
  if (p.role === "mid") return tm.mid / 100;
  return tm.attack / 100;
}

function snapshotPrev(m: Match) {
  for (const p of m.players) {
    p.px = p.x;
    p.py = p.y;
  }
  const b = m.ball;
  b.px = b.x;
  b.py = b.y;
  b.pz = b.z;
}

function formationTarget(m: Match, p: Player): [number, number] {
  const atk = m.attack[p.team]!;
  const idx = m.players.filter((q) => q.team === p.team && q.role === p.role && q.id <= p.id).length - 1;
  let [x, y] = homeSlot(p.role, idx, atk);
  const ball = m.ball;
  const has = m.players.some((q) => q.team === p.team && m.ball.owner === q.id);
  const push = has ? 8 : -4;
  if (p.role !== "gk") {
    x += atk * push;
    x += clamp(ball.x * 0.22, -14, 14);
    y += clamp(ball.y * 0.16, -10, 10);
  } else {
    y = clamp(ball.y * 0.22, -8, 8);
    x = -47.2 * atk + atk * clamp((ball.x * atk > 20 ? 2 : 0), 0, 4);
  }
  x = clamp(x, -HALF_W + 1.5, HALF_W - 1.5);
  y = clamp(y, -HALF_H + 1.5, HALF_H - 1.5);
  return [x, y];
}

function closestTo(m: Match, team: 0 | 1 | "any", x: number, y: number, skipId = -1, allowGk = true) {
  let best: Player | null = null;
  let bestD = 1e9;
  for (const p of m.players) {
    if (skipId === p.id) continue;
    if (team !== "any" && p.team !== team) continue;
    if (!allowGk && p.role === "gk") continue;
    const d = (p.x - x) ** 2 + (p.y - y) ** 2;
    if (d < bestD) {
      bestD = d;
      best = p;
    }
  }
  return best;
}

function kickBall(m: Match, p: Player, vx: number, vy: number, vz: number) {
  const b = m.ball;
  b.owner = null;
  b.vx = vx;
  b.vy = vy;
  b.vz = vz;
  b.lastKicker = p.id;
  b.lastKickT = 0;
  p.cooldown = 0.28;
  b.spin += len(vx, vy) * 0.4;
}

function aimWorld(m: Match, actions: Actions, p: Player): [number, number] {
  let ax = actions.moveX;
  let ay = actions.moveY;
  if (camFlip(m)) {
    ax = -ax;
    ay = -ay;
  }
  if (Math.hypot(ax, ay) < 0.28) {
    ax = Math.cos(p.facing);
    ay = Math.sin(p.facing);
  }
  return norm(ax, ay);
}

export function camFlip(m: Match) {
  if (m.userTeam !== 0 && m.userTeam !== 1) return false;
  return m.attack[m.userTeam] < 0;
}

function passTarget(m: Match, p: Player, ax: number, ay: number, through: boolean) {
  let best: Player | null = null;
  let bestScore = -1e9;
  for (const q of m.players) {
    if (q.team !== p.team || q.id === p.id) continue;
    const dx = q.x - p.x;
    const dy = q.y - p.y;
    const d = Math.hypot(dx, dy);
    if (d < 2 || d > (through ? 48 : 32)) continue;
    const ndx = dx / d;
    const ndy = dy / d;
    const cone = ndx * ax + ndy * ay;
    if (cone < 0.15) continue;
    const fwd = (q.x - p.x) * m.attack[p.team]!;
    let open = 0;
    for (const o of m.players) {
      if (o.team === p.team) continue;
      const t = clamp(((o.x - p.x) * dx + (o.y - p.y) * dy) / (d * d), 0, 1);
      const cx = p.x + dx * t;
      const cy = p.y + dy * t;
      const od = Math.hypot(o.x - cx, o.y - cy);
      if (od < 3.5) open -= 4;
      else if (od < 7) open -= 1;
    }
    const score = cone * 12 + fwd * 0.15 + open - d * 0.08 + (through && q.role === "fwd" ? 3 : 0);
    if (score > bestScore) {
      bestScore = score;
      best = q;
    }
  }
  return best;
}

function doPass(m: Match, p: Player, ax: number, ay: number, through: boolean) {
  const t = passTarget(m, p, ax, ay, through);
  let vx: number, vy: number, vz: number;
  if (t) {
    const lead = through ? 0.35 : 0.12;
    const tx = t.x + t.vx * lead * 8;
    const ty = t.y + t.vy * lead * 8;
    const dx = tx - p.x;
    const dy = ty - p.y;
    const d = Math.hypot(dx, dy);
    const spd = through ? 18 + d * 0.18 : 12 + d * 0.22;
    vx = (dx / d) * spd;
    vy = (dy / d) * spd;
    vz = through ? 2.4 : 0.6;
    m.event = `${through ? "Through" : "Pass"} — ${t.name}`;
    m.eventT = 1.1;
  } else {
    const spd = through ? 20 : 14;
    vx = ax * spd;
    vy = ay * spd;
    vz = through ? 2.2 : 0.5;
  }
  kickBall(m, p, vx, vy, vz);
}

function doShot(m: Match, p: Player, ax: number, ay: number, power: number) {
  const atk = m.attack[p.team]!;
  const gx = HALF_W * atk;
  const gy = clamp(m.ball.y * 0.3 + rand(-1.2, 1.2), -GOAL_HALF + 0.4, GOAL_HALF - 0.4);
  let dx = gx - p.x;
  let dy = gy - p.y;
  if (Math.hypot(ax, ay) > 0.35) {
    dx = ax;
    dy = ay;
  }
  const [nx, ny] = norm(dx, dy);
  const d = Math.hypot(gx - p.x, gy - p.y);
  const acc = diffMul(m.difficulty).acc * rating(m, p);
  const spread = (1.15 - acc) * (0.35 + (1 - power) * 0.4) * (d > 22 ? 1.4 : 1);
  const ang = Math.atan2(ny, nx) + rand(-spread, spread);
  const spd = 16 + power * 14;
  kickBall(m, p, Math.cos(ang) * spd, Math.sin(ang) * spd, 1.2 + power * 2.4);
  m.event = `Shot — ${p.name}`;
  m.eventT = 1.2;
  m.trauma = Math.max(m.trauma, 0.35 + power * 0.4);
  m.excitement = Math.min(1, m.excitement + 0.35);
}

function switchPlayer(m: Match, actions: Actions) {
  if (m.userTeam < 0) return;
  const team = m.userTeam as 0 | 1;
  let ax = actions.moveX;
  let ay = actions.moveY;
  if (camFlip(m)) {
    ax = -ax;
    ay = -ay;
  }
  const cur = m.players[m.controlled];
  if (Math.hypot(ax, ay) > 0.35 && cur) {
    let best: Player | null = null;
    let bestDot = -1e9;
    for (const p of m.players) {
      if (p.team !== team || p.id === cur.id || p.role === "gk") continue;
      const dx = p.x - cur.x;
      const dy = p.y - cur.y;
      const d = Math.hypot(dx, dy) || 1;
      const dot = (dx / d) * ax + (dy / d) * ay;
      if (dot > bestDot) {
        bestDot = dot;
        best = p;
      }
    }
    if (best) m.controlled = best.id;
    return;
  }
  const near = closestTo(m, team, m.ball.x, m.ball.y, -1, false);
  if (near) m.controlled = near.id;
}

function movePlayer(m: Match, p: Player, ax: number, ay: number, sprint: boolean, dt: number) {
  const r = rating(m, p);
  const maxWalk = (p.role === "gk" ? 6.4 : 7.1) * (0.85 + r * 0.25);
  const maxSprint = (p.role === "gk" ? 8.2 : 10.6) * (0.85 + r * 0.28);
  const canSprint = sprint && p.stamina > 0.06 && p.role !== "gk";
  const maxS = canSprint ? maxSprint : maxWalk;
  const acc = 36 * (0.9 + r * 0.2);
  if (Math.hypot(ax, ay) > 0.08) {
    p.vx += ax * acc * dt;
    p.vy += ay * acc * dt;
    p.facing = lerpAngle(p.facing, Math.atan2(ay, ax), 1 - Math.exp(-10 * dt));
  } else {
    p.vx *= Math.exp(-8 * dt);
    p.vy *= Math.exp(-8 * dt);
  }
  const sp = Math.hypot(p.vx, p.vy);
  if (sp > maxS) {
    p.vx *= maxS / sp;
    p.vy *= maxS / sp;
  }
  p.x += p.vx * dt;
  p.y += p.vy * dt;
  p.x = clamp(p.x, -HALF_W - 1.2, HALF_W + 1.2);
  p.y = clamp(p.y, -HALF_H - 1.2, HALF_H + 1.2);
  if (canSprint && sp > 6) p.stamina = Math.max(0, p.stamina - dt * 0.16);
  else p.stamina = Math.min(1, p.stamina + dt * 0.12);
  p.anim += sp * dt * 2.4;
  p.cooldown = Math.max(0, p.cooldown - dt);
}

function aiAct(m: Match, p: Player, dt: number): { ax: number; ay: number; sprint: boolean; kick: "pass" | "through" | "shot" | "tackle" | null } {
  const D = diffMul(m.difficulty);
  const b = m.ball;
  const atk = m.attack[p.team]!;
  const [tx0, ty0] = formationTarget(m, p);
  let tx = tx0;
  let ty = ty0;
  let sprint = false;
  let kick: "pass" | "through" | "shot" | "tackle" | null = null;
  const hasBall = b.owner === p.id;
  const teamHas = m.players.some((q) => q.team === p.team && b.owner === q.id);

  if (p.role === "gk") {
    const goalX = -HALF_W * atk;
    tx = goalX + atk * 1.4;
    ty = clamp(b.y * 0.55, -GOAL_HALF - 1.5, GOAL_HALF + 1.5);
    const incoming = (b.x - p.x) * atk < 0 && Math.abs(b.vx) > 8 && Math.abs(b.x) > 38;
    if (incoming) {
      const t = Math.abs((p.x - b.x) / (b.vx || 1));
      ty = clamp(b.y + b.vy * Math.min(t, 0.8), -GOAL_HALF - 2, GOAL_HALF + 2);
      sprint = true;
    }
    if (hasBall && p.cooldown <= 0) kick = "pass";
    if (!hasBall && Math.hypot(p.x - b.x, p.y - b.y) < 2.4 && b.z < 2.2) {
      /* keeper claims in ball pickup */
    }
  } else if (hasBall) {
    const goalX = HALF_W * atk;
    const distGoal = Math.hypot(goalX - p.x, -p.y);
    const inBox = (p.x * atk > 30 && Math.abs(p.y) < 16) || distGoal < 18;
    tx = p.x + atk * 8;
    ty = p.y * 0.92;
    sprint = Math.random() < 0.35 * D.ai;
    if (p.cooldown <= 0) {
      if (inBox && Math.random() < 0.045 * D.acc) kick = "shot";
      else if (Math.random() < 0.028 * D.ai) kick = Math.random() < 0.35 ? "through" : "pass";
      else if (distGoal < 26 && Math.random() < 0.02) kick = "shot";
    }
  } else if (teamHas) {
    tx = tx0 + atk * 4;
    ty = ty0;
    const owner = m.players[b.owner!];
    if (owner && p.role === "fwd") {
      tx = owner.x + atk * 10 + rand(-3, 3);
      ty = clamp(ty0 + rand(-4, 4), -HALF_H + 4, HALF_H - 4);
      sprint = true;
    }
  } else {
    const presser = closestTo(m, p.team, b.x, b.y, -1, false);
    if (presser && presser.id === p.id) {
      tx = b.x + b.vx * 0.15;
      ty = b.y + b.vy * 0.15;
      sprint = true;
      if (Math.hypot(p.x - b.x, p.y - b.y) < 1.6 && Math.random() < 0.08 * D.press) kick = "tackle";
    } else {
      const mark = closestTo(m, p.team === 0 ? 1 : 0, p.x, p.y, -1, false);
      if (mark && p.role === "def") {
        tx = lerp(tx0, mark.x - atk * 2, 0.55);
        ty = lerp(ty0, mark.y, 0.5);
      }
    }
  }

  const dx = tx - p.x;
  const dy = ty - p.y;
  const d = Math.hypot(dx, dy);
  let ax = 0;
  let ay = 0;
  if (d > 0.4) {
    ax = dx / d;
    ay = dy / d;
    if (d < 2.2) {
      ax *= d / 2.2;
      ay *= d / 2.2;
    }
  }
  sprint = sprint && d > 6;
  void dt;
  return { ax, ay, sprint, kick };
}

function resolvePlayers(m: Match) {
  const ps = m.players;
  for (let i = 0; i < ps.length; i++) {
    for (let j = i + 1; j < ps.length; j++) {
      const a = ps[i]!;
      const b = ps[j]!;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const d2 = dx * dx + dy * dy;
      const min = 1.35;
      if (d2 < min * min && d2 > 1e-6) {
        const d = Math.sqrt(d2);
        const pen = (min - d) * 0.5;
        const nx = dx / d;
        const ny = dy / d;
        a.x -= nx * pen;
        a.y -= ny * pen;
        b.x += nx * pen;
        b.y += ny * pen;
      }
    }
  }
}

function updateBall(m: Match, dt: number) {
  const b = m.ball;
  b.lastKickT += dt;
  if (b.owner !== null) {
    const p = m.players[b.owner];
    if (!p) {
      b.owner = null;
    } else {
      const hold = 0.78 + (p.role === "fwd" ? 0.08 : 0);
      b.x = p.x + Math.cos(p.facing) * hold;
      b.y = p.y + Math.sin(p.facing) * hold;
      b.z = 0.22;
      b.vx = p.vx;
      b.vy = p.vy;
      b.vz = 0;
      return;
    }
  }
  b.vz -= 18 * dt;
  b.x += b.vx * dt;
  b.y += b.vy * dt;
  b.z += b.vz * dt;
  if (b.z < 0.22) {
    b.z = 0.22;
    if (b.vz < 0) b.vz *= -0.42;
    b.vx *= 0.82;
    b.vy *= 0.82;
  }
  b.vx *= Math.exp(-0.55 * dt);
  b.vy *= Math.exp(-0.55 * dt);
  b.spin += len(b.vx, b.vy) * dt * 0.8;

  if (Math.abs(b.y) > HALF_H && Math.abs(b.x) < HALF_W + 2) {
    b.y = clamp(b.y, -HALF_H, HALF_H);
    b.vy *= -0.35;
  }
}

function tryPickup(m: Match) {
  const b = m.ball;
  if (b.owner !== null) return;
  if (b.lastKickT < 0.22) return;
  if (b.z > 1.6) return;
  const spd = len(b.vx, b.vy);
  let best: Player | null = null;
  let bestD = 1.25;
  for (const p of m.players) {
    if (p.cooldown > 0) continue;
    const d = Math.hypot(p.x - b.x, p.y - b.y);
    const reach = p.role === "gk" ? 1.7 : 1.15;
    if (d < reach && d < bestD) {
      bestD = d;
      best = p;
    }
  }
  if (!best) return;
  if (spd > 13 && best.role !== "gk") {
    const nx = (best.x - b.x) / (bestD || 1);
    const ny = (best.y - b.y) / (bestD || 1);
    b.vx += nx * 3;
    b.vy += ny * 3;
    b.vx *= 0.55;
    b.vy *= 0.55;
    return;
  }
  b.owner = best.id;
  b.vx = best.vx;
  b.vy = best.vy;
  if (m.userTeam === best.team && m.autoSwitch && m.userTeam >= 0 && best.role !== "gk") {
    m.controlled = best.id;
  }
}

function stealCheck(m: Match, p: Player) {
  const b = m.ball;
  if (b.owner === null || b.owner === p.id) return;
  const o = m.players[b.owner];
  if (!o || o.team === p.team) return;
  const d = Math.hypot(p.x - b.x, p.y - b.y);
  if (d > 1.35) return;
  const chance = 0.55 * (p.stamina + 0.3) * (1.1 - rating(m, o) * 0.4);
  if (Math.random() < chance) {
    b.owner = null;
    const [nx, ny] = norm(p.vx + rand(-1, 1), p.vy + rand(-1, 1));
    b.vx = nx * 6;
    b.vy = ny * 6;
    b.lastKickT = 0;
    o.cooldown = 0.25;
    m.event = `Tackle — ${p.name}`;
    m.eventT = 0.9;
  } else {
    p.cooldown = 0.4;
  }
}

function inGoal(b: Ball, side: 1 | -1) {
  const line = HALF_W * side;
  const past = side > 0 ? b.x > line : b.x < -line;
  return past && Math.abs(b.y) < GOAL_HALF && b.z < GOAL_H;
}

function resetKickoff(m: Match, kicking: 0 | 1) {
  m.attack = m.half === 1 ? [1, -1] : [-1, 1];
  for (const p of m.players) {
    const idx = m.players.filter((q) => q.team === p.team && q.role === p.role && q.id <= p.id).length - 1;
    const [x, y] = homeSlot(p.role, idx, m.attack[p.team]!);
    p.x = x;
    p.y = y;
    p.vx = 0;
    p.vy = 0;
    p.facing = m.attack[p.team]! > 0 ? 0 : Math.PI;
    p.px = x;
    p.py = y;
  }
  m.ball.x = 0;
  m.ball.y = 0;
  m.ball.z = 0.22;
  m.ball.vx = 0;
  m.ball.vy = 0;
  m.ball.vz = 0;
  m.ball.owner = null;
  const kicker = m.players.find((p) => p.team === kicking && p.role === "fwd") ?? m.players[9]!;
  kicker.x = -1.2 * m.attack[kicking]!;
  kicker.y = 0;
  m.ball.owner = kicker.id;
  if (m.userTeam === kicking) m.controlled = kicker.id;
  m.phase = "kickoff";
  m.phaseT = 0;
}

function placeSetPiece(m: Match, x: number, y: number, team: 0 | 1) {
  m.ball.x = clamp(x, -HALF_W + 0.6, HALF_W - 0.6);
  m.ball.y = clamp(y, -HALF_H + 0.6, HALF_H - 0.6);
  m.ball.z = 0.22;
  m.ball.vx = 0;
  m.ball.vy = 0;
  m.ball.vz = 0;
  const taker = closestTo(m, team, x, y, -1, Math.abs(x) > 45);
  if (taker) {
    taker.x = x - m.attack[team]! * 1.2;
    taker.y = y;
    m.ball.owner = taker.id;
    if (m.userTeam === team) m.controlled = taker.id;
  }
  m.phase = "setpiece";
  m.phaseT = 0;
}

function checkBounds(m: Match) {
  const b = m.ball;
  if (m.phase !== "play") return;
  if (inGoal(b, 1)) {
    const scorer = (m.attack[0] === 1 ? 0 : 1) as 0 | 1;
    score(m, scorer);
    return;
  }
  if (inGoal(b, -1)) {
    const scorer = (m.attack[0] === -1 ? 0 : 1) as 0 | 1;
    score(m, scorer);
    return;
  }
  if (Math.abs(b.x) > HALF_W) {
    const last = m.players[b.lastKicker];
    const teamLast = last?.team ?? 0;
    const attackingSide = b.x > 0 ? 0 : 1;
    const byTeam0 = m.attack[0] > 0 ? b.x > 0 : b.x < 0;
    const attackTeam = byTeam0 ? 0 : 1;
    void attackingSide;
    if (teamLast === attackTeam) {
      const gkTeam = (1 - attackTeam) as 0 | 1;
      placeSetPiece(m, (HALF_W - 8) * Math.sign(b.x), clamp(b.y, -8, 8), gkTeam);
      m.event = "Goal kick";
    } else {
      placeSetPiece(m, (HALF_W - 0.8) * Math.sign(b.x), Math.sign(b.y || 1) * (HALF_H - 0.8), attackTeam);
      m.event = "Corner";
    }
    m.eventT = 1.4;
    return;
  }
  if (Math.abs(b.y) > HALF_H) {
    const last = m.players[b.lastKicker];
    const team = ((last?.team ?? 0) === 0 ? 1 : 0) as 0 | 1;
    placeSetPiece(m, clamp(b.x, -HALF_W + 2, HALF_W - 2), Math.sign(b.y) * (HALF_H - 0.4), team);
    m.event = "Throw-in";
    m.eventT = 1.2;
  }
}

function score(m: Match, team: 0 | 1) {
  m.score[team] += 1;
  m.phase = "goal";
  m.phaseT = 0;
  const tm = team === 0 ? m.home : m.away;
  m.event = m.practice ? "GOAL" : `GOAL — ${tm.short}`;
  m.eventT = 2.5;
  m.trauma = 1;
  m.excitement = 1;
  m.ball.owner = null;
  m.lastScorer = team;
}

export function stepMatch(m: Match, actions: Actions, dt: number) {
  snapshotPrev(m);
  m.phaseT += dt;
  m.eventT = Math.max(0, m.eventT - dt);
  m.trauma = Math.max(0, m.trauma - dt * 1.6);
  m.excitement = lerp(m.excitement, m.phase === "play" ? 0.22 + Math.abs(m.ball.x) / 140 : 0.15, 1 - Math.exp(-1.2 * dt));

  if (m.phase === "fulltime") {
    m.ended = true;
    return;
  }

  if (m.phase === "halftime") {
    if (m.phaseT > 3.2) {
      m.half = 2;
      m.clock = 45;
      resetKickoff(m, 1);
      m.event = "Second half";
      m.eventT = 1.6;
    }
    return;
  }

  if (m.phase === "goal") {
    if (m.phaseT > 2.5) {
      resetKickoff(m, (1 - m.lastScorer) as 0 | 1);
    }
    return;
  }

  if (m.phase === "kickoff" && m.phaseT > 1.15) m.phase = "play";
  if (m.phase === "setpiece" && m.phaseT > 0.35) m.phase = "play";

  if (!m.practice && (m.phase === "play" || m.phase === "kickoff")) {
    const halfLen = 45;
    const realHalf = 75;
    m.clock += dt * (halfLen / realHalf);
    if (m.half === 1 && m.clock >= 45) {
      m.clock = 45;
      m.phase = "halftime";
      m.phaseT = 0;
      m.event = "Half time";
      m.eventT = 3;
      return;
    }
    if (m.half === 2 && m.clock >= 90) {
      m.clock = 90;
      m.phase = "fulltime";
      m.phaseT = 0;
      m.event = "Full time";
      m.eventT = 4;
      m.ended = true;
      return;
    }
  }

  if (m.userTeam >= 0 && actions.switchP) switchPlayer(m, actions);

  if (m.autoSwitch && m.userTeam >= 0 && m.phase === "play") {
    const owner = m.ball.owner !== null ? m.players[m.ball.owner] : null;
    if (owner && owner.team === m.userTeam && owner.role !== "gk" && owner.id !== m.controlled) {
      const me = m.players[m.controlled];
      if (!me || Math.hypot(me.x - m.ball.x, me.y - m.ball.y) > 16) m.controlled = owner.id;
    }
  }

  const user = m.userTeam >= 0 ? m.players[m.controlled] : undefined;
  let aimX = 0;
  let aimY = 0;
  if (user) {
    [aimX, aimY] = aimWorld(m, actions, user);
    if (actions.shootHeld) m.shootHold = Math.min(1, m.shootHold + dt * 0.9);
    else if (actions.shoot && m.ball.owner === user.id) {
      doShot(m, user, aimX, aimY, Math.max(0.25, m.shootHold));
      m.shootHold = 0;
    } else if (!actions.shootHeld) m.shootHold = 0;
    if (actions.pass && m.ball.owner === user.id) doPass(m, user, aimX, aimY, false);
    if (actions.through && m.ball.owner === user.id) doPass(m, user, aimX, aimY, true);
    if (actions.tackle) stealCheck(m, user);
  } else {
    m.shootHold = 0;
  }

  for (const p of m.players) {
    const isUser = user && p.id === user.id;
    if (isUser) {
      let ax = actions.moveX;
      let ay = actions.moveY;
      if (camFlip(m)) {
        ax = -ax;
        ay = -ay;
      }
      movePlayer(m, p, ax, ay, actions.sprint, dt);
    } else {
      const a = aiAct(m, p, dt);
      movePlayer(m, p, a.ax, a.ay, a.sprint, dt);
      if (a.kick === "pass" && m.ball.owner === p.id) {
        const [nx, ny] = norm(m.attack[p.team]!, rand(-0.4, 0.4));
        doPass(m, p, nx, ny, false);
      } else if (a.kick === "through" && m.ball.owner === p.id) {
        const [nx, ny] = norm(m.attack[p.team]!, rand(-0.5, 0.5));
        doPass(m, p, nx, ny, true);
      } else if (a.kick === "shot" && m.ball.owner === p.id) {
        doShot(m, p, m.attack[p.team]!, 0, rand(0.55, 0.95));
      } else if (a.kick === "tackle") stealCheck(m, p);
    }
  }

  resolvePlayers(m);
  updateBall(m, dt);
  tryPickup(m);
  checkBounds(m);
}

export function interpPlayer(p: Player, a: number) {
  return { x: lerp(p.px, p.x, a), y: lerp(p.py, p.y, a) };
}

export function interpBall(b: Ball, a: number) {
  return { x: lerp(b.px, b.x, a), y: lerp(b.py, b.y, a), z: lerp(b.pz, b.z, a) };
}

export function skinColor(i: number) {
  return SKIN[i % SKIN.length]!;
}
export function hairColor(i: number) {
  return HAIR[i % HAIR.length]!;
}
