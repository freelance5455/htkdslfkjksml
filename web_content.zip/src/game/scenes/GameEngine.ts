/**
 * SPR - Sahil Powerful Run
 * Core 3D Endless Runner Game Engine
 * - Morning Daylight Atmosphere & Chunk Pooling
 * - 12 Stylized 3D Character Models with Glowing LED Soles
 * - Integrated 3D Skateboard equipment, riding physics & crash protection
 * - Responsive Mobile Touch Gestures & Desktop Controls
 */

import * as THREE from 'three';
import { Character3D } from '../models/Character3D';
import { JungleEnvironment } from '../environment/JungleEnvironment';
import { ObstacleManager } from '../obstacles/ObstacleManager';
import { ItemManager } from '../items/ItemManager';
import { RocketFlightSystem } from '../models/RocketFlightSystem';
import { soundManager } from '../audio/SoundManager';
import { saveManager } from '../storage/SaveManager';
import { GAME_CONFIG, ObstacleType, PowerUpType } from '../constants';
import { SKATEBOARDS, SkateboardDef } from '../constants/skateboards';
import { deviceTierManager, GraphicsQualitySetting, GraphicsTierConfig } from '../utils/DeviceTier';

export interface GameEngineCallbacks {
  onScoreUpdate: (score: number, distance: number, coins: number, speed: number) => void;
  onPowerUpUpdate: (activePowerUps: Record<PowerUpType, number>) => void;
  onSkateboardUpdate: (isSkating: boolean, remainingSeconds: number) => void;
  onGameOver: (finalScore: number, distance: number, coinsEarned: number, isNewHigh: boolean) => void;
  onRequestRevive?: (currentScore: number, currentDistance: number, currentCoins: number, currentReviveCount: number) => void;
  onDangerWarning: () => void;
  onNewHighScore?: (newScore: number) => void;
}

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  
  // Game Systems
  public player!: Character3D;
  private environment!: JungleEnvironment;
  private obstacleManager!: ObstacleManager;
  public itemManager!: ItemManager;
  public currentBoardDef: SkateboardDef = SKATEBOARDS[0];

  // High score tracking during active run
  private initialHighScore: number = 0;
  private hasTriggeredHighScoreNotice: boolean = false;

  // Running State
  public isHomeMode: boolean = true;
  public isRunning: boolean = false;
  public isPaused: boolean = false;
  private isDead: boolean = false;

  // Diamond Revive System State (Strict limit: max 3 per run)
  public reviveCount: number = 0;
  private invincibilityTimer: number = 0;

  // Skateboard State
  public isSkating: boolean = false;
  private skateboardTimer: number = 0;

  // Player physics & motion
  private currentLane: number = 1; // 0: Left, 1: Middle, 2: Right
  private targetLaneX: number = 0;
  private playerX: number = 0;
  private playerY: number = 0;
  private playerZ: number = 0;
  private velocityY: number = 0;
  private isJumping: boolean = false;
  private isSliding: boolean = false;
  private slideTimer: number = 0;
  private currentSpeed: number = GAME_CONFIG.INITIAL_SPEED;

  // Gameplay metrics
  private distance: number = 0;
  private score: number = 0;
  private sessionCoins: number = 0;
  private spawnProgressZ: number = -30;

  // Camera & Visual FX
  private cameraTarget = new THREE.Vector3();
  private cameraShakeIntensity: number = 0;
  private shieldSphereMesh!: THREE.Mesh;
  private boostAuraMesh!: THREE.Mesh;
  private rocketFlightSystem!: RocketFlightSystem;
  private isRocketActive: boolean = false;
  private rocketFlightPhase: 'none' | 'ascent' | 'cruise' | 'descent' = 'none';
  private targetDescentLane: number = 1;
  private rocketAudioHumTimer: number = 0;

  // Callbacks to UI
  private callbacks: GameEngineCallbacks;
  private hudThrottleTimer: number = 0;

  // Reusable Bounding Box and Vectors (zero GC per frame)
  private playerBBox = new THREE.Box3();
  private playerBoxCenter = new THREE.Vector3();
  private playerBoxSize = new THREE.Vector3();

  // Loop handles
  private animationFrameId: number | null = null;
  private deathTimeoutId: number | null = null;
  private lastTime: number = 0;

  // Touch & Double-Tap Gesture State
  private touchStartX: number = 0;
  private touchStartY: number = 0;
  private touchStartTime: number = 0;
  private lastTapTime: number = 0;

  constructor(canvas: HTMLCanvasElement, callbacks: GameEngineCallbacks) {
    this.canvas = canvas;
    this.callbacks = callbacks;
    this.initThree();
    this.initEntities();
    this.initInputListeners();
    this.applyTierConfig(deviceTierManager.getTierConfig());
    this.handleResize();
    this.enterHomeMode();
  }

  private initThree() {
    this.scene = new THREE.Scene();

    const clientW = this.canvas.clientWidth || window.innerWidth || 800;
    const clientH = this.canvas.clientHeight || window.innerHeight || 600;
    const aspect = clientW / clientH || 16 / 9;
    const initialConfig = deviceTierManager.getTierConfig();

    this.camera = new THREE.PerspectiveCamera(65, aspect, 0.1, initialConfig.cameraFar);
    this.camera.position.set(0, 4.8, 6.5);

    try {
      this.renderer = new THREE.WebGLRenderer({
        canvas: this.canvas,
        antialias: initialConfig.antialias,
        powerPreference: 'high-performance',
      });
    } catch {
      // Safe fallback if high-performance/antialias context fails to initialize
      this.renderer = new THREE.WebGLRenderer({
        canvas: this.canvas,
        antialias: false,
        powerPreference: 'default',
      });
    }

    this.renderer.setSize(clientW, clientH, false);
    this.renderer.setPixelRatio(initialConfig.pixelRatio);
    this.renderer.shadowMap.enabled = initialConfig.shadows;
    this.renderer.shadowMap.type = initialConfig.shadowMapType;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
  }

  private initEntities() {
    // 1. Morning Daylight Environment
    this.environment = new JungleEnvironment(this.scene);

    // 2. Obstacles and Collectibles
    this.obstacleManager = new ObstacleManager(this.scene);
    this.itemManager = new ItemManager(this.scene);

    // 3. 3D Player Character
    const selectedCharId = saveManager.getSelectedCharacterId();
    this.player = new Character3D(selectedCharId);
    this.syncEquippedSkateboard();
    this.scene.add(this.player.group);

    // 4. Power-up Visual FX
    const shieldGeo = new THREE.IcosahedronGeometry(1.6, 2);
    const shieldMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.38,
      wireframe: true,
    });
    this.shieldSphereMesh = new THREE.Mesh(shieldGeo, shieldMat);
    this.shieldSphereMesh.visible = false;
    this.player.group.add(this.shieldSphereMesh);

    const boostGeo = new THREE.CylinderGeometry(0.1, 1.4, 3, 8);
    boostGeo.rotateX(Math.PI / 2);
    const boostMat = new THREE.MeshBasicMaterial({
      color: 0xfbbf24,
      transparent: true,
      opacity: 0.35,
      wireframe: true,
    });
    this.boostAuraMesh = new THREE.Mesh(boostGeo, boostMat);
    this.boostAuraMesh.position.set(0, 1.0, 1.2);
    this.boostAuraMesh.visible = false;
    this.player.group.add(this.boostAuraMesh);

    // 5. High-Octane 3D Rocket Flight Propulsion System with dual engine nozzles & procedural flames
    this.rocketFlightSystem = new RocketFlightSystem(this.scene);
  }

  private initInputListeners() {
    window.addEventListener('resize', this.handleResize);
    window.addEventListener('keydown', this.handleKeyDown);

    // Passive false ensures pull-to-refresh and swipe-navigation are disabled during gameplay
    this.canvas.addEventListener('touchstart', this.handleTouchStart, { passive: false });
    this.canvas.addEventListener('touchmove', this.handleTouchMove, { passive: false });
    this.canvas.addEventListener('touchend', this.handleTouchEnd, { passive: false });

    // WebGL Context Loss Recovery
    this.canvas.addEventListener('webglcontextlost', this.handleContextLost);
    this.canvas.addEventListener('webglcontextrestored', this.handleContextRestored);
  }

  public destroy() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    if (this.deathTimeoutId !== null) {
      clearTimeout(this.deathTimeoutId);
      this.deathTimeoutId = null;
    }
    this.isRunning = false;
    this.isDead = false;

    window.removeEventListener('resize', this.handleResize);
    window.removeEventListener('keydown', this.handleKeyDown);
    this.canvas.removeEventListener('touchstart', this.handleTouchStart);
    this.canvas.removeEventListener('touchmove', this.handleTouchMove);
    this.canvas.removeEventListener('touchend', this.handleTouchEnd);
    this.canvas.removeEventListener('webglcontextlost', this.handleContextLost);
    this.canvas.removeEventListener('webglcontextrestored', this.handleContextRestored);

    this.obstacleManager?.destroy();
    this.itemManager?.destroy();
    this.environment?.destroy();
    this.player?.dispose();

    this.shieldSphereMesh?.geometry.dispose();
    (this.shieldSphereMesh?.material as THREE.Material)?.dispose();
    this.boostAuraMesh?.geometry.dispose();
    (this.boostAuraMesh?.material as THREE.Material)?.dispose();
    this.rocketFlightSystem?.destroy();

    this.renderer?.dispose();
  }

  private handleContextLost = (e: Event) => {
    e.preventDefault();
    console.warn('SPR 3D: WebGL context lost - conserving state');
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    this.isPaused = true;
  };

  private handleContextRestored = () => {
    console.log('SPR 3D: WebGL context restored - re-initializing renderer');
    this.applyTierConfig(deviceTierManager.getTierConfig());
    if (this.isRunning && !this.isPaused) {
      this.lastTime = performance.now();
      this.tick(this.lastTime);
    }
  };

  private handleTouchStart = (e: TouchEvent) => {
    if (this.isRunning && !this.isPaused && e.cancelable) {
      e.preventDefault();
    }
    if (e.touches.length > 0) {
      this.touchStartX = e.touches[0].clientX;
      this.touchStartY = e.touches[0].clientY;
      this.touchStartTime = Date.now();
    }
  };

  private handleTouchMove = (e: TouchEvent) => {
    if (this.isRunning && !this.isPaused && e.cancelable) {
      e.preventDefault();
    }
  };

  private handleTouchEnd = (e: TouchEvent) => {
    if (this.isRunning && !this.isPaused && e.cancelable) {
      e.preventDefault();
    }
    if (!this.isRunning || this.isPaused || this.isDead) return;
    if (e.changedTouches.length === 0) return;

    const deltaX = e.changedTouches[0].clientX - this.touchStartX;
    const deltaY = e.changedTouches[0].clientY - this.touchStartY;
    const deltaTime = Date.now() - this.touchStartTime;

    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);
    const minSwipe = 24;

    if (deltaTime < 550 && (absX > minSwipe || absY > minSwipe)) {
      if (absX > absY * 1.15) {
        if (deltaX > 0) {
          this.swipeRight();
        } else {
          this.swipeLeft();
        }
      } else if (absY > absX * 1.15) {
        if (deltaY < 0) {
          this.swipeUp();
        } else {
          this.swipeDown();
        }
      } else {
        // Fallback for diagonal swipe: resolve to highest vector
        if (absX > absY) {
          if (deltaX > 0) this.swipeRight();
          else this.swipeLeft();
        } else {
          if (deltaY < 0) this.swipeUp();
          else this.swipeDown();
        }
      }
    } else if (deltaTime < 300 && absX < 18 && absY < 18) {
      // Fast double-tap anywhere on screen activates 3D Skateboard!
      const now = Date.now();
      if (now - this.lastTapTime < 350) {
        this.toggleSkateboard();
      }
      this.lastTapTime = now;
    }
  };

  private handleResize = () => {
    if (!this.canvas) return;
    const width = this.canvas.parentElement ? this.canvas.parentElement.clientWidth : window.innerWidth;
    const height = this.canvas.parentElement ? this.canvas.parentElement.clientHeight : window.innerHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    const config = deviceTierManager.getTierConfig();
    this.renderer.setPixelRatio(config.pixelRatio);
  };

  private handleKeyDown = (e: KeyboardEvent) => {
    if (!this.isRunning || this.isPaused || this.isDead) return;

    switch (e.key) {
      case 'ArrowLeft':
      case 'a':
      case 'A':
        this.swipeLeft();
        break;
      case 'ArrowRight':
      case 'd':
      case 'D':
        this.swipeRight();
        break;
      case 'ArrowUp':
      case 'w':
      case 'W':
      case ' ':
        this.swipeUp();
        break;
      case 'ArrowDown':
      case 's':
      case 'S':
        this.swipeDown();
        break;
      case 'b':
      case 'B':
        this.toggleSkateboard();
        break;
      case 'Escape':
      case 'p':
      case 'P':
        this.togglePause();
        break;
    }
  };

  // --- CONTROLS ACTIONS ---
  public swipeLeft() {
    if (this.currentLane > 0) {
      this.currentLane -= 1;
      this.targetLaneX = GAME_CONFIG.LANES[this.currentLane];
      soundManager.playLaneSwitchSound();
    }
  }

  public swipeRight() {
    if (this.currentLane < GAME_CONFIG.LANES.length - 1) {
      this.currentLane += 1;
      this.targetLaneX = GAME_CONFIG.LANES[this.currentLane];
      soundManager.playLaneSwitchSound();
    }
  }

  public swipeUp() {
    if (!this.isJumping) {
      this.isJumping = true;
      this.isSliding = false;
      const jumpMult = this.isSkating && this.currentBoardDef ? this.currentBoardDef.bonusStats.jumpMultiplier : 1.0;
      this.velocityY = GAME_CONFIG.JUMP_FORCE * jumpMult;
      this.player.setAnimation('jump');
      soundManager.playJumpSound();
    }
  }

  public swipeDown() {
    if (this.isJumping) {
      this.velocityY = -26;
    }
    this.isSliding = true;
    this.slideTimer = GAME_CONFIG.SLIDE_DURATION;
    this.player.setAnimation('slide');
    soundManager.playSlideSound();
  }

  // --- 3D SKATEBOARD SYSTEM ---
  public toggleSkateboard() {
    if (this.isSkating) {
      this.deactivateSkateboard();
    } else {
      this.activateSkateboard();
    }
  }

  public activateSkateboard() {
    if (this.isDead || !this.isRunning) return;
    const equippedId = saveManager.getEquippedSkateboardId();
    if (!equippedId || !saveManager.isSkateboardUnlocked(equippedId)) {
      // User hasn't purchased/unlocked any skateboard yet
      soundManager.playButtonClick();
      return;
    }
    this.syncEquippedSkateboard();
    this.isSkating = true;
    const duration = GAME_CONFIG.SKATEBOARD_DURATION + (this.currentBoardDef?.bonusStats.durationBonus || 0);
    this.skateboardTimer = duration;
    this.player.setSkateboardActive(true);
    soundManager.playPowerupSound();
    this.callbacks.onSkateboardUpdate(true, Math.ceil(this.skateboardTimer));
  }

  public deactivateSkateboard() {
    this.isSkating = false;
    this.skateboardTimer = 0;
    this.player.setSkateboardActive(false);
    this.callbacks.onSkateboardUpdate(false, 0);
  }

  public togglePause() {
    this.isPaused = !this.isPaused;
    if (this.isPaused) {
      soundManager.pauseMusic();
    } else {
      this.lastTime = performance.now();
      soundManager.resumeMusic();
    }
  }

  public pauseGame() {
    if (!this.isRunning || this.isPaused) return;
    this.isPaused = true;
    soundManager.pauseMusic();
  }

  public resumeGame() {
    if (!this.isRunning || !this.isPaused) return;
    this.isPaused = false;
    this.lastTime = performance.now();
    soundManager.resumeMusic();
  }

  public setGraphicsQuality(quality: GraphicsQualitySetting) {
    deviceTierManager.setSetting(quality);
    saveManager.updateSettings({ graphicsQuality: quality });
    this.applyTierConfig(deviceTierManager.getTierConfig());
  }

  public applyTierConfig(config: GraphicsTierConfig) {
    if (!this.renderer) return;
    this.renderer.setPixelRatio(config.pixelRatio);
    this.renderer.shadowMap.enabled = config.shadows;
    this.renderer.shadowMap.type = config.shadowMapType;
    this.camera.far = config.cameraFar;
    this.camera.updateProjectionMatrix();

    if (this.environment) {
      this.environment.applyGraphicsTier(config);
    }
  }

  public enterHomeMode() {
    this.isHomeMode = true;
    this.isRunning = false;
    this.isDead = false;
    this.isPaused = false;
    soundManager.stopMusic();

    if (this.deathTimeoutId !== null) {
      clearTimeout(this.deathTimeoutId);
      this.deathTimeoutId = null;
    }

    this.currentLane = 1;
    this.targetLaneX = GAME_CONFIG.LANES[1];
    this.playerX = 0;
    this.playerY = 0;
    this.playerZ = 0;
    this.velocityY = 0;
    this.isJumping = false;
    this.isSliding = false;
    this.slideTimer = 0;

    this.player.group.position.set(0, 0, 0);
    this.player.group.rotation.set(0, 0, 0);

    // Sync character and skateboard
    this.syncEquippedSkateboard();
    const equippedBoardId = saveManager.getEquippedSkateboardId();
    if (equippedBoardId && saveManager.isSkateboardUnlocked(equippedBoardId)) {
      this.player.setSkateboardActive(true);
      this.player.setAnimation('skate');
    } else {
      this.player.setSkateboardActive(false);
      this.player.setAnimation('run');
    }

    // Camera for Home Screen framing - gives perfect perspective matching reference image
    this.camera.position.set(0, 2.2, 4.0);
    this.camera.lookAt(0, 1.45, -6.0);

    // Reset 3D environment & showcase items
    this.environment.reset(0);
    this.obstacleManager.clearAll();
    this.itemManager.clearAll();

    // Showcase 3D commuter train on left track (lane 0) matching reference image
    this.obstacleManager.spawnObstacle('train', 0, -18);

    // Showcase golden crown coins on center track (lane 1) floating ahead of player
    this.itemManager.spawnCoinLine(1, -4, 5, 1.0);

    if (this.animationFrameId === null) {
      this.lastTime = performance.now();
      this.tick(this.lastTime);
    }
  }

  public start() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    if (this.deathTimeoutId !== null) {
      clearTimeout(this.deathTimeoutId);
      this.deathTimeoutId = null;
    }

    this.isHomeMode = false;
    this.initialHighScore = saveManager.getSaveData().highScore;
    this.hasTriggeredHighScoreNotice = false;
    this.syncEquippedSkateboard();
    this.resetState();
    this.isRunning = true;
    this.isPaused = false;
    this.isDead = false;
    this.player.setAnimation('run');
    soundManager.startMusic();

    this.lastTime = performance.now();
    this.tick(this.lastTime);
  }

  public stop() {
    this.isRunning = false;
    this.isDead = false;
    soundManager.stopMusic();
    this.enterHomeMode();
  }

  public setCharacter(id: number) {
    this.player.setCharacter(id);
    this.syncEquippedSkateboard();
  }

  public syncEquippedSkateboard() {
    const equippedId = saveManager.getEquippedSkateboardId();
    this.currentBoardDef = SKATEBOARDS.find((b) => b.id === equippedId) || SKATEBOARDS[0];
    if (this.player) {
      this.player.setSkateboardSkin(this.currentBoardDef.visuals, this.currentBoardDef.id);
    }
  }

  public setEquippedSkateboard(boardId: number) {
    saveManager.setEquippedSkateboardId(boardId);
    this.syncEquippedSkateboard();
  }

  private resetState() {
    this.reviveCount = 0;
    this.invincibilityTimer = 0;
    this.currentLane = 1;
    this.targetLaneX = GAME_CONFIG.LANES[1];
    this.playerX = 0;
    this.playerY = 0;
    this.playerZ = 0;
    this.velocityY = 0;
    this.isJumping = false;
    this.isSliding = false;
    this.slideTimer = 0;
    this.isSkating = false;
    this.skateboardTimer = 0;
    this.currentSpeed = GAME_CONFIG.INITIAL_SPEED;
    this.distance = 0;
    this.score = 0;
    this.sessionCoins = 0;
    this.spawnProgressZ = -30;
    this.cameraShakeIntensity = 0;

    this.isRocketActive = false;
    this.rocketFlightPhase = 'none';
    this.targetDescentLane = 1;
    this.rocketAudioHumTimer = 0;
    this.rocketFlightSystem?.reset();

    this.player.setFlightPitch(0);
    this.player.setSkateboardActive(false);
    this.player.group.position.set(0, 0, 0);
    this.player.group.rotation.set(0, 0, 0);

    this.environment.reset(0);
    this.obstacleManager.clearAll();
    this.itemManager.clearAll();

    this.callbacks.onScoreUpdate(0, 0, 0, Math.floor(GAME_CONFIG.INITIAL_SPEED));
    this.callbacks.onPowerUpUpdate({
      magnet: 0,
      rocket: 0,
      shield: 0,
      doubleCoins: 0,
      speedBoost: 0,
    });
    this.callbacks.onSkateboardUpdate(false, 0);

    // Iconic Opening Layout Mirroring the SPR Reference Image:
    // Left lane: Commuter train ahead
    this.obstacleManager.spawnObstacle('train', 0, -22);
    // Right lane: Red & white hazard barricade
    this.obstacleManager.spawnObstacle('barricade', 2, -18);
    // Center lane: Golden SPR crown coins leading to wooden crate & yellow chevron booster ramp
    this.itemManager.spawnCoinLine(1, -8, 5, 1.0);
    this.obstacleManager.spawnObstacle('jumpRamp', 1, -34);
    // Commuter train behind the ramp with coins along roof
    this.obstacleManager.spawnObstacle('train', 1, -48);
    this.itemManager.spawnCoinLine(1, -44, 4, 3.8);

    // Continue procedural dynamic track generation ahead
    this.generateUpcomingObstaclesAndCoins(-60, -220);
  }

  private generateUpcomingObstaclesAndCoins(fromZ: number, toZ: number) {
    let currentZ = fromZ;
    // Strict railway track obstacles matching the SPR coastal railway system:
    // Trains (only large vehicle), track barricades, wooden crates, and overhead signal gantries
    const obstacleTypes: ObstacleType[] = [
      'train',
      'barricade',
      'woodenCrates',
      'overheadSignal',
    ];

    while (currentZ > toZ) {
      const step = 20 + Math.random() * 12;
      currentZ -= step;

      if (Math.random() < 0.78) {
        const obsType = obstacleTypes[Math.floor(Math.random() * obstacleTypes.length)];
        const blockedLane = Math.floor(Math.random() * 3);

        this.obstacleManager.spawnObstacle(obsType, blockedLane, currentZ);

        if (obsType === 'train') {
          // Yellow Chevron Booster Ramp placed in front of train so player can vault onto train roof!
          if (Math.random() < 0.65) {
            this.obstacleManager.spawnObstacle('jumpRamp', blockedLane, currentZ + 12);
          }
          // Spawn golden coins along the train roof!
          this.itemManager.spawnCoinLine(blockedLane, currentZ + 6, 4, 3.8);
        }

        const freeLane = (blockedLane + 1) % 3;
        if (Math.random() < 0.8) {
          this.itemManager.spawnCoinLine(freeLane, currentZ + 6, 4, 1.0);
        }
      } else {
        if (Math.random() < 0.35) {
          const powerUps: PowerUpType[] = ['magnet', 'rocket', 'shield', 'doubleCoins', 'speedBoost'];
          const puType = powerUps[Math.floor(Math.random() * powerUps.length)];
          const lane = Math.floor(Math.random() * 3);
          this.itemManager.spawnPowerUp(puType, lane, currentZ);
        } else {
          const lane = Math.floor(Math.random() * 3);
          if (this.isRocketActive) {
            // High altitude aerial coin trails for rocket flight!
            this.itemManager.spawnAerialSkywayCoinPath(lane, currentZ, 6, 5.0);
          } else {
            this.itemManager.spawnHighCoinArc(lane, currentZ, 6);
          }
        }
      }
    }

    this.spawnProgressZ = toZ;
  }

  private tick = (currentTime: number) => {
    // If not actively running, not in home mode, and not playing death animation, pause the loop
    if (!this.isRunning && !this.isDead && !this.isHomeMode) {
      if (this.animationFrameId !== null) {
        cancelAnimationFrame(this.animationFrameId);
        this.animationFrameId = null;
      }
      return;
    }

    this.animationFrameId = requestAnimationFrame(this.tick);

    // Delta time clamped to 0.08s (prevents player tunneling or glitching when returning from background)
    const delta = Math.min((currentTime - this.lastTime) / 1000, 0.08);
    this.lastTime = currentTime;

    // Dynamic FPS Monitoring: Automatically steps down graphics quality if device drops frames
    const autoTierChange = deviceTierManager.recordFrame(delta);
    if (autoTierChange) {
      this.applyTierConfig(deviceTierManager.getTierConfig(autoTierChange));
    }

    // Home Screen 3D Interactive Mode Loop
    if (this.isHomeMode) {
      this.player.update(delta);
      this.itemManager.update(delta, this.player.group.position);
      this.environment.update(0, delta);

      // Gentle cinematic breathing sway
      const sway = Math.sin(currentTime * 0.001) * 0.05;
      this.camera.position.set(sway * 0.3, 2.2 + Math.cos(currentTime * 0.0012) * 0.02, 4.0);
      this.camera.lookAt(0, 1.45, -6.0);

      this.renderer.render(this.scene, this.camera);
      return;
    }

    if (this.isPaused) {
      this.player.update(delta);
      this.renderer.render(this.scene, this.camera);
      return;
    }

    this.updateGame(delta);
    this.renderer.render(this.scene, this.camera);
  };

  private updateGame(delta: number) {
    if (this.isDead) {
      this.player.update(delta);
      return;
    }

    // 1. Power-ups & Skateboard Timer
    const hasRocket = this.itemManager.activePowerUps.rocket > 0;
    const hasSpeedBoost = this.itemManager.activePowerUps.speedBoost > 0;
    const hasShield = this.itemManager.activePowerUps.shield > 0;
    const isInvincible = this.invincibilityTimer > 0;

    if (this.invincibilityTimer > 0) {
      this.invincibilityTimer -= delta;
      if (this.invincibilityTimer <= 0) {
        this.invincibilityTimer = 0;
      }
    }

    if (this.isSkating) {
      this.skateboardTimer -= delta;
      if (this.skateboardTimer <= 0) {
        this.deactivateSkateboard();
      } else {
        this.callbacks.onSkateboardUpdate(true, Math.ceil(this.skateboardTimer));
      }
    }

    this.shieldSphereMesh.visible = hasShield || isInvincible;
    if (hasShield || isInvincible) {
      this.shieldSphereMesh.rotation.y += delta * (isInvincible ? 4 : 2);
      this.shieldSphereMesh.rotation.z += delta * (isInvincible ? 3 : 1.5);
      if (isInvincible) {
        const pulse = 1.0 + Math.sin(this.invincibilityTimer * 18) * 0.15;
        this.shieldSphereMesh.scale.set(pulse, pulse, pulse);
      } else {
        this.shieldSphereMesh.scale.set(1, 1, 1);
      }
    }

    this.boostAuraMesh.visible = hasSpeedBoost;
    this.player.setJetpackActive(hasRocket);

    // Progressive Speed Progression based on distance and score:
    // - Starts slow (INITIAL_SPEED = 14)
    // - Low score (0 - 500) = slow/medium (15-18 km/h)
    // - Medium/Higher score (500 - 3000) = faster (20-28 km/h)
    // - Very high score (5000+) = maximum speed (capped at MAX_SPEED = 34 km/h)
    // Uses smooth asymptotic curve with lerping for ultra-smooth acceleration
    const speedRange = GAME_CONFIG.MAX_SPEED - GAME_CONFIG.INITIAL_SPEED;
    const progressFactor = 1 - Math.exp(-this.score / 3200);
    const targetProgressiveSpeed = GAME_CONFIG.INITIAL_SPEED + speedRange * progressFactor;
    this.currentSpeed = THREE.MathUtils.lerp(this.currentSpeed, targetProgressiveSpeed, delta * 0.9);

    let effectiveSpeed = this.currentSpeed;
    if (hasSpeedBoost) {
      effectiveSpeed += 14;
    } else if (hasRocket) {
      effectiveSpeed += 8;
    } else if (this.isSkating) {
      const speedBonus = this.currentBoardDef ? this.currentBoardDef.bonusStats.speedBonus : 0;
      effectiveSpeed += 4 + speedBonus; // Skateboard cruising boost + perks!
    }

    // 2. Advance Player Along Z & Calculate Score with Board Perks
    const scoreMult = this.isSkating && this.currentBoardDef ? this.currentBoardDef.bonusStats.scoreMultiplier : 1.0;
    this.playerZ -= effectiveSpeed * delta;
    this.distance += effectiveSpeed * delta;
    this.score += effectiveSpeed * delta * GAME_CONFIG.SCORE_PER_METER * scoreMult;

    // Trigger high score notification dynamically as soon as previous high score is beaten
    if (!this.hasTriggeredHighScoreNotice && this.initialHighScore > 0 && this.score > this.initialHighScore) {
      this.hasTriggeredHighScoreNotice = true;
      soundManager.playPowerupSound();
      this.callbacks.onNewHighScore?.(Math.floor(this.score));
    }

    // 3. Smooth Lane Changing
    const handlingMult = (this.isSkating && this.currentBoardDef?.bonusStats?.handlingMultiplier) || 1.0;
    this.playerX = THREE.MathUtils.lerp(
      this.playerX,
      this.targetLaneX,
      GAME_CONFIG.LANE_SWITCH_SPEED * handlingMult * delta
    );

    // 4. Vertical Physics or Rocket Flight
    if (hasRocket) {
      const remainingRocketTime = this.itemManager.activePowerUps.rocket;
      const totalRocketDuration = GAME_CONFIG.POWERUP_DURATIONS.rocket;
      const elapsedRocketTime = totalRocketDuration - remainingRocketTime;

      this.isRocketActive = true;
      this.isJumping = false;
      this.isSliding = false;
      this.player.setSkateboardActive(true); // Keep skateboard attached under the horizontal player!
      this.player.setAnimation('rocket_fly'); // Horizontal sleeping/flying pose!

      // State Machine: Ascent (first 2.2s), Cruise Flight (until last 3.5s), Descent / Safe Re-entry (last 3.5s)
      const cruiseAltitude = 5.2;

      if (elapsedRocketTime < 2.2) {
        // --- ASCENT PHASE ---
        this.rocketFlightPhase = 'ascent';
        const ascentProgress = Math.min(1.0, elapsedRocketTime / 2.2);
        this.player.setFlightPitch(ascentProgress);
        this.playerY = THREE.MathUtils.lerp(this.playerY, cruiseAltitude, delta * 4.5);
        this.triggerCameraShake(0.08 * (1 - ascentProgress));
      } else if (remainingRocketTime > 3.5) {
        // --- CRUISE FLIGHT PHASE (Horizontal Sleeping Posture) ---
        this.rocketFlightPhase = 'cruise';
        this.player.setFlightPitch(1.0);
        const flightHoverOffset = Math.sin(this.distance * 0.25) * 0.18;
        this.playerY = THREE.MathUtils.lerp(this.playerY, cruiseAltitude + flightHoverOffset, delta * 5.0);
      } else {
        // --- SAFE DESCENT & RE-ENTRY PHASE ---
        this.rocketFlightPhase = 'descent';
        const descentRemaining = remainingRocketTime; // 3.5s down to 0s

        // Determine safe landing lane dynamically using ObstacleManager
        if (descentRemaining <= 3.0 && descentRemaining > 2.8) {
          this.targetDescentLane = this.obstacleManager.findSafeLandingLane(this.playerZ - 45);
          this.currentLane = this.targetDescentLane;
          this.targetLaneX = GAME_CONFIG.LANES[this.targetDescentLane];
        }

        // Smoothly glide down to ground level as remaining time approaches 0
        const descentFactor = Math.max(0, descentRemaining / 3.5);
        this.player.setFlightPitch(descentFactor);
        const targetDescendY = cruiseAltitude * Math.pow(descentFactor, 1.4);
        this.playerY = THREE.MathUtils.lerp(this.playerY, targetDescendY, delta * 3.8);

        if (descentRemaining <= 0.2) {
          this.playerY = THREE.MathUtils.lerp(this.playerY, 0, delta * 8.0);
        }
      }

      // Aerodynamic banking into lane changes
      const laneDiff = (this.targetLaneX - this.playerX) / 2.0;
      this.player.group.rotation.z = THREE.MathUtils.lerp(this.player.group.rotation.z, -laneDiff * 0.25, delta * 8.0);

      // High-Octane Dual Rocket Engine Propulsion System
      this.rocketFlightSystem.update(
        delta,
        true,
        this.playerX,
        this.playerY,
        this.playerZ,
        this.player.group.rotation.z,
        this.player.flightPitch
      );

      // Audio hum & thruster loop simulation
      this.rocketAudioHumTimer += delta;
      if (this.rocketAudioHumTimer > 0.85) {
        this.rocketAudioHumTimer = 0;
        soundManager.playPowerupSound();
      }
    } else {
      if (this.isRocketActive) {
        // Just transitioned out of rocket flight
        this.isRocketActive = false;
        this.rocketFlightPhase = 'none';
        this.player.setFlightPitch(0);
        this.player.group.rotation.z = 0;
        this.player.setSkateboardActive(this.isSkating);
        this.player.setAnimation(this.isSkating ? 'skate' : 'run');
        this.rocketFlightSystem.reset();
        this.playerY = 0;
        this.velocityY = 0;
        this.isJumping = false;
        soundManager.playSlideSound();
      } else {
        this.player.group.rotation.z = THREE.MathUtils.lerp(this.player.group.rotation.z, 0, delta * 10.0);
      }

      if (this.isJumping) {
        this.playerY += this.velocityY * delta;
        this.velocityY += GAME_CONFIG.GRAVITY * delta;

        if (this.playerY <= 0) {
          this.playerY = 0;
          this.isJumping = false;
          this.velocityY = 0;
          if (this.isSkating) {
            this.player.triggerSkateboardLanding();
          }
          if (!this.isSliding) {
            this.player.setAnimation(this.isSkating ? 'skate' : 'run');
          }
        }
      }

      if (this.isSliding) {
        this.slideTimer -= delta;
        if (this.slideTimer <= 0) {
          this.isSliding = false;
          if (!this.isJumping) {
            this.player.setAnimation(this.isSkating ? 'skate' : 'run');
          }
        }
      }
    }

    // Set 3D Player Group Position
    this.player.group.position.set(this.playerX, this.playerY, this.playerZ);
    this.player.setRunSpeed(effectiveSpeed);

    // Provide real-time motion state for dynamic 3D skateboard power effects
    const laneDiff = (this.targetLaneX - this.playerX) / 2.0;
    this.player.setMotionState({
      isJumping: this.isJumping,
      isSliding: this.isSliding,
      isSpeedBoost: hasSpeedBoost || hasRocket,
      laneSwitchingIntensity: Math.max(-1, Math.min(1, laneDiff)),
      verticalVelocity: this.velocityY,
      effectiveSpeed: effectiveSpeed,
    });

    this.player.update(delta);

    // 5. Update Environment & Chunks
    this.environment.update(this.playerZ, delta);

    // 6. Spawn more track content ahead
    if (this.playerZ - 120 < this.spawnProgressZ) {
      this.generateUpcomingObstaclesAndCoins(this.spawnProgressZ, this.spawnProgressZ - 150);
    }

    // 7. Update Obstacles
    this.obstacleManager.update(delta, this.playerZ);

    // 8. Update Items (Coins & Power-ups with Skateboard Magnet & Multiplier Perks)
    const isBoardMagnet = this.isSkating && (this.currentBoardDef?.bonusStats.coinAttraction ?? false);
    const boardCoinMult = this.isSkating && this.currentBoardDef ? this.currentBoardDef.bonusStats.coinMultiplier : 1.0;

    const { collectedCoins, collectedPowerUp } = this.itemManager.update(
      delta,
      this.player.group.position,
      isBoardMagnet,
      boardCoinMult
    );

    if (collectedCoins > 0) {
      this.sessionCoins += collectedCoins;
      this.score += collectedCoins * GAME_CONFIG.COIN_SCORE;
      soundManager.playCoinSound();
    }

    if (collectedPowerUp) {
      soundManager.playPowerupSound();
    }

    // 9. Collision Check with Skateboard Crash Protection (Zero allocation)
    if (!hasRocket) {
      this.playerBoxCenter.set(
        this.playerX,
        this.isSliding ? 0.45 : this.playerY + 0.9,
        this.playerZ
      );
      this.playerBoxSize.set(0.8, this.isSliding ? 0.8 : 1.7, 0.8);
      this.playerBBox.setFromCenterAndSize(this.playerBoxCenter, this.playerBoxSize);

      const hit = this.obstacleManager.checkPlayerCollision(
        this.playerBBox,
        this.isJumping,
        this.isSliding,
        this.playerY
      );

      if (hit) {
        if (hit.isRamp) {
          // Yellow Chevron Booster Ramp - Launch up onto train roofs or over barriers!
          this.velocityY = 24;
          this.isJumping = true;
          this.player.setAnimation('jump');
          soundManager.playJumpSound();
          this.triggerCameraShake(0.15);
        } else if (isInvincible) {
          // REVIVE INVINCIBILITY: Safely vaporize obstacle without taking damage!
          hit.active = false;
          hit.group.visible = false;
          this.triggerCameraShake(0.2);
        } else if (hasSpeedBoost) {
          // Speed boost destroys obstacle
          hit.active = false;
          hit.group.visible = false;
          this.triggerCameraShake(0.35);
        } else if (this.isSkating) {
          // SKATEBOARD CRASH PROTECTION: Saves player from fatal impact!
          this.deactivateSkateboard();
          soundManager.playShieldBreakSound();
          hit.active = false;
          hit.group.visible = false;
          this.triggerCameraShake(0.5);
        } else if (this.itemManager.consumeShield()) {
          // Shield saved player
          soundManager.playShieldBreakSound();
          hit.active = false;
          hit.group.visible = false;
          this.triggerCameraShake(0.45);
        } else {
          // Fatal collision -> Game Over
          this.handlePlayerDeath();
          return;
        }
      }
    }

    // 10. Third Person 3D Camera Follow
    this.updateCamera(delta, effectiveSpeed, hasRocket);

    // 11. Send state to React UI HUD (Throttled to ~20 Hz to ensure 60-120 FPS game rendering)
    this.hudThrottleTimer += delta;
    if (this.hudThrottleTimer >= 0.05) {
      this.hudThrottleTimer = 0;
      this.callbacks.onScoreUpdate(
        Math.floor(this.score),
        Math.floor(this.distance),
        this.sessionCoins,
        Math.floor(effectiveSpeed)
      );
      this.callbacks.onPowerUpUpdate({ ...this.itemManager.activePowerUps });
    }
  }

  private updateCamera(delta: number, speed: number, hasRocket: boolean) {
    const baseDistance = hasRocket ? 9.0 : 7.2 + (speed - GAME_CONFIG.INITIAL_SPEED) * 0.08;
    const baseHeight = hasRocket ? 6.8 : 4.6 + (this.playerY > 0 ? this.playerY * 0.35 : 0);

    const targetCamX = this.playerX * 0.72;
    const targetCamY = this.playerY + baseHeight;
    const targetCamZ = this.playerZ + baseDistance;

    this.camera.position.x = THREE.MathUtils.lerp(this.camera.position.x, targetCamX, delta * 9);
    this.camera.position.y = THREE.MathUtils.lerp(this.camera.position.y, targetCamY, delta * 6);
    this.camera.position.z = THREE.MathUtils.lerp(this.camera.position.z, targetCamZ, delta * 12);

    if (this.cameraShakeIntensity > 0) {
      this.camera.position.x += (Math.random() - 0.5) * this.cameraShakeIntensity;
      this.camera.position.y += (Math.random() - 0.5) * this.cameraShakeIntensity;
      this.cameraShakeIntensity = Math.max(0, this.cameraShakeIntensity - delta * 2.5);
    }

    this.cameraTarget.set(
      this.playerX * 0.5,
      this.playerY + 1.25,
      this.playerZ - 18
    );
    this.camera.lookAt(this.cameraTarget);
  }

  public triggerCameraShake(intensity: number = 0.5) {
    this.cameraShakeIntensity = intensity;
  }

  private handlePlayerDeath() {
    this.isDead = true;
    this.player.setAnimation('death');
    this.triggerCameraShake(0.8);

    if (this.deathTimeoutId !== null) {
      clearTimeout(this.deathTimeoutId);
    }

    // Check if player is eligible for Diamond Revive:
    // Strict limit: exactly 3 successful Diamond revives per run AND must have at least 1 diamond
    const currentDiamonds = saveManager.getDiamonds();
    const canRevive = this.reviveCount < 3 && currentDiamonds >= 1;

    if (canRevive && this.callbacks.onRequestRevive) {
      // Play impact collision sound, keep music CONTINUING seamlessly (do NOT stop, pause, or fade music!)
      soundManager.playShieldBreakSound();
      soundManager.continueMusic();

      this.deathTimeoutId = window.setTimeout(() => {
        this.deathTimeoutId = null;
        if (this.animationFrameId !== null) {
          cancelAnimationFrame(this.animationFrameId);
          this.animationFrameId = null;
        }
        this.callbacks.onRequestRevive!(
          Math.floor(this.score),
          Math.floor(this.distance),
          this.sessionCoins,
          this.reviveCount
        );
      }, 700);
      return;
    }

    // If 3 revives were already used or player has 0 diamonds, normal game over
    soundManager.fadeOutMusic(600);
    soundManager.playGameOverSound();
    this.finalizeGameOver();
  }

  public revivePlayer() {
    this.reviveCount++;
    this.isDead = false;
    this.isRunning = true;
    this.isPaused = false;
    this.playerY = 0;
    this.velocityY = 0;
    this.isJumping = false;
    this.isSliding = false;

    // Reposition player safely in current lane
    this.targetLaneX = GAME_CONFIG.LANES[this.currentLane];
    this.playerX = this.targetLaneX;
    this.player.group.position.set(this.playerX, 0, this.playerZ);

    // Clear any obstacles 40m ahead of player so they don't immediately hit anything
    this.obstacleManager.clearNearZ(this.playerZ - 40, this.playerZ + 6);

    // 3.5 seconds invincibility period with visual shield
    this.invincibilityTimer = 3.5;
    this.shieldSphereMesh.visible = true;

    // Restore riding/running animation and continue music seamlessly
    if (this.isSkating) {
      this.player.setAnimation('skate');
    } else {
      this.player.setAnimation('run');
    }

    soundManager.playPowerupSound();
    soundManager.continueMusic();

    this.lastTime = performance.now();
    if (this.animationFrameId === null) {
      this.tick(this.lastTime);
    }
  }

  public declineRevive() {
    soundManager.fadeOutMusic(600);
    soundManager.playGameOverSound();
    this.finalizeGameOver();
  }

  private finalizeGameOver() {
    const previousHighScore = saveManager.getSaveData().highScore;
    const isNewHigh = this.score > previousHighScore;
    saveManager.updateRunStats(this.score, this.distance, this.sessionCoins);

    if (this.deathTimeoutId !== null) {
      clearTimeout(this.deathTimeoutId);
    }

    this.deathTimeoutId = window.setTimeout(() => {
      this.deathTimeoutId = null;
      this.isDead = false;
      this.isRunning = false;
      if (this.animationFrameId !== null) {
        cancelAnimationFrame(this.animationFrameId);
        this.animationFrameId = null;
      }
      this.callbacks.onGameOver(
        Math.floor(this.score),
        Math.floor(this.distance),
        this.sessionCoins,
        isNewHigh
      );
    }, 600);
  }
}
