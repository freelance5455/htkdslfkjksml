import Phaser from 'phaser';
import { DEPTH, PALETTE, TEX, THEME } from '../constants';
import { computeLayout, type Layout, type SafeArea } from '../layout';
import { storage, type QualityPref } from '../storage';
import { formatScore } from '../scoring';
import { qualityFor, resolveTier, type Quality } from '../perf';
import { UIButton, makeText } from '../ui';
import { settingsRow } from '../overlays';
import { PieceView } from '../PieceView';
import { SHAPES } from '../shapes';
import { sound } from '../audio';

export class MenuScene extends Phaser.Scene {
  private L!: Layout;
  private q!: Quality;
  private starting = false;

  constructor() {
    super('Menu');
  }

  create(): void {
    this.starting = false;
    this.q = this.registry.get('quality') as Quality;
    const dpr = (this.registry.get('dpr') as number) || 1;
    const safe = (this.registry.get('safe') as SafeArea) || { top: 0, bottom: 0 };
    this.L = computeLayout(this.scale.width, this.scale.height, dpr, safe);

    this.build();

    const onResize = () => {
      const next = computeLayout(this.scale.width, this.scale.height, dpr, safe);
      if (Math.abs(next.W - this.L.W) < 1 && Math.abs(next.H - this.L.H) < 1) return;
      this.scene.restart();
    };
    this.scale.on(Phaser.Scale.Events.RESIZE, onResize);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => this.scale.off(Phaser.Scale.Events.RESIZE, onResize));

    this.input.once('pointerdown', () => sound.unlock());
    this.cameras.main.fadeIn(300, 20, 27, 56);
  }

  private build(): void {
    const L = this.L;
    const u = L.u;
    const W = L.W;
    const H = L.H;

    this.add.image(0, 0, 'bg').setOrigin(0).setDisplaySize(W + 2, H + 2).setDepth(DEPTH.BG);
    this.buildDecor();

    const save = storage.getSave();
    const best = storage.getBest();
    const stats = storage.getStats();

    // ---- Title ----
    const titleY = L.safeTop + H * 0.2;
    const t1 = makeText(this, W / 2, titleY - 58 * u, 'BLOCK', 118 * u, {
      stroke: '#3a1d00',
      strokeThickness: 10 * u,
      shadow: true,
      shadowBlur: this.q.textShadowBlur ? 10 : 0,
    }).setDepth(DEPTH.HUD);
    this.gradientFill(t1, ['#fff3a0', '#ffd14d', '#ff9a3c']);
    const t2 = makeText(this, W / 2, titleY + 62 * u, 'BLAST', 118 * u, {
      stroke: '#0a2a5c',
      strokeThickness: 10 * u,
      shadow: true,
      shadowBlur: this.q.textShadowBlur ? 10 : 0,
    }).setDepth(DEPTH.HUD);
    this.gradientFill(t2, ['#b8f1ff', '#5ec6ff', '#3b7ae6']);
    t1.setAngle(-3);
    t2.setAngle(-3);

    if (this.q.menuAnimation) {
      this.tweens.add({ targets: [t1, t2], y: '-=10', duration: 1800, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    }

    // ---- Best score + stats ----
    const bestY = titleY + 190 * u;
    const crown = this.add.image(0, bestY, TEX, 'icon_crown').setDisplaySize(52 * u, 52 * u).setTint(THEME.goldHex).setDepth(DEPTH.HUD);
    const bestTxt = makeText(this, 0, bestY, formatScore(best), 56 * u, {
      color: THEME.gold,
      origin: [0, 0.5],
      shadow: true,
    }).setDepth(DEPTH.HUD);
    const total = 52 * u + 16 * u + bestTxt.width;
    crown.x = W / 2 - total / 2 + 26 * u;
    bestTxt.x = W / 2 - total / 2 + 68 * u;
    makeText(this, W / 2, bestY + 46 * u, 'BEST SCORE', 22 * u, { color: THEME.muted }).setDepth(DEPTH.HUD);
    if (stats.games > 0) {
      makeText(
        this,
        W / 2,
        bestY + 80 * u,
        `Games ${stats.games}   ·   Lines ${stats.lines}   ·   Max combo ${stats.maxCombo}`,
        20 * u,
        { color: '#6f7ca8' }
      ).setDepth(DEPTH.HUD);
    }

    // ---- Buttons ----
    const bw = Math.min(W * 0.72, 460 * u);
    const by = L.safeTop + H * 0.55;
    if (save) {
      new UIButton(this, {
        x: W / 2,
        y: by,
        w: bw,
        h: 116 * u,
        label: 'CONTINUE',
        subLabel: `Score ${formatScore(save.score)}`,
        icon: 'icon_play',
        fill: THEME.green,
        edge: THEME.greenEdge,
        fontSize: 40 * u,
        onClick: () => this.startGame(true),
      }).setDepth(DEPTH.HUD);
      new UIButton(this, {
        x: W / 2,
        y: by + 126 * u,
        w: bw,
        h: 92 * u,
        label: 'NEW GAME',
        icon: 'icon_replay',
        fill: THEME.blue,
        edge: THEME.blueEdge,
        fontSize: 32 * u,
        onClick: () => this.startGame(false),
      }).setDepth(DEPTH.HUD);
    } else {
      const play = new UIButton(this, {
        x: W / 2,
        y: by + 30 * u,
        w: bw,
        h: 124 * u,
        label: 'PLAY',
        icon: 'icon_play',
        fill: THEME.green,
        edge: THEME.greenEdge,
        fontSize: 46 * u,
        onClick: () => this.startGame(false),
      }).setDepth(DEPTH.HUD);
      if (this.q.menuAnimation) {
        this.tweens.add({ targets: play, scale: 1.04, duration: 900, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      }
    }

    // ---- Settings ----
    const settingsY = H - L.safeBottom - 180 * u;
    settingsRow(this, L, settingsY).setX(W / 2).setDepth(DEPTH.HUD);

    const pref = storage.getSettings().quality;
    const qualityBtn = new UIButton(this, {
      x: W / 2,
      y: H - L.safeBottom - 46 * u,
      w: 300 * u,
      h: 52 * u,
      label: this.qualityLabel(pref),
      fill: THEME.dark,
      edge: THEME.darkEdge,
      fontSize: 22 * u,
      textColor: '#c9d3ff',
      onClick: () => {
        const order: QualityPref[] = ['auto', 'low', 'high'];
        const cur = storage.getSettings();
        const next = order[(order.indexOf(cur.quality) + 1) % order.length];
        storage.setSettings({ ...cur, quality: next });
        qualityBtn.setLabel(this.qualityLabel(next));
        this.applyQuality(next);
      },
    }).setDepth(DEPTH.HUD);
  }

  private qualityLabel(pref: QualityPref): string {
    const tier = resolveTier(pref);
    const name = pref === 'auto' ? `AUTO (${tier.toUpperCase()})` : pref.toUpperCase();
    return `GRAPHICS: ${name}`;
  }

  private applyQuality(pref: QualityPref): void {
    const q = qualityFor(resolveTier(pref));
    this.registry.set('quality', q);
    this.q = q;
    const setDpr = this.registry.get('setDpr') as ((d: number) => void) | undefined;
    setDpr?.(Math.min(window.devicePixelRatio || 1, q.dprCap));
  }

  private gradientFill(t: Phaser.GameObjects.Text, stops: string[]): void {
    const g = t.context.createLinearGradient(0, 0, 0, t.height);
    stops.forEach((s, i) => g.addColorStop(i / (stops.length - 1), s));
    t.setFill(g);
  }

  private buildDecor(): void {
    const L = this.L;
    const u = L.u;
    const rnd = Phaser.Math.Between;
    const count = this.q.tier === 'low' ? 7 : 14;
    for (let i = 0; i < count; i++) {
      const size = rnd(30, 64) * u;
      const img = this.add
        .image(rnd(0, L.W), rnd(0, L.H), TEX, `block_${rnd(0, PALETTE.length - 1)}`)
        .setDisplaySize(size, size)
        .setAlpha(0.18 + Math.random() * 0.22)
        .setAngle(rnd(-25, 25))
        .setDepth(DEPTH.BOARD);
      if (this.q.menuAnimation) {
        this.tweens.add({
          targets: img,
          y: img.y - rnd(20, 60) * u,
          angle: img.angle + rnd(-20, 20),
          duration: rnd(2500, 5000),
          yoyo: true,
          repeat: -1,
          ease: 'Sine.easeInOut',
          delay: rnd(0, 1500),
        });
      }
    }

    // Three showcase pieces around the title.
    const picks = [
      SHAPES.find((s) => s.family === 'l4')!,
      SHAPES.find((s) => s.family === 'sq2')!,
      SHAPES.find((s) => s.family === 'line3' && s.h === 1)!,
    ];
    const positions: Array<[number, number, number]> = [
      [L.W * 0.17, L.safeTop + L.H * 0.09, -12],
      [L.W * 0.85, L.safeTop + L.H * 0.12, 14],
      [L.W * 0.8, L.safeTop + L.H * 0.34, -8],
    ];
    picks.forEach((shape, i) => {
      if (!shape) return;
      const [x, y, ang] = positions[i];
      const pv = new PieceView(this, shape, 56 * u, 50 * u, false);
      pv.setPosition(x, y).setAngle(ang).setDepth(DEPTH.CELLS).setAlpha(0.9);
      if (this.q.menuAnimation) {
        this.tweens.add({
          targets: pv,
          y: y - 14 * u,
          angle: ang + 6,
          duration: 2200 + i * 400,
          yoyo: true,
          repeat: -1,
          ease: 'Sine.easeInOut',
        });
      }
    });
  }

  private startGame(cont: boolean): void {
    if (this.starting) return;
    this.starting = true;
    sound.unlock();
    if (!cont) storage.clearSave();
    this.cameras.main.fadeOut(220, 20, 27, 56);
    this.cameras.main.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => {
      this.scene.start('Game', { continue: cont });
    });
  }
}
