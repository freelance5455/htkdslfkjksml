/**
 * SPR - Sahil Powerful Run
 * 3D Skateboard Interactive Preview Canvas for Skateboard Shop
 * Allows full 360-degree rotation, showing deck top grip, graphic bottom, neon rails, and wheels
 * Single WebGL context lifecycle with zero memory leaks across 15 skateboard selections
 */

import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { Skateboard3D } from '../models/Skateboard3D';
import { SkateboardDef } from '../constants/skateboards';

interface Props {
  board: SkateboardDef;
  viewAngle?: 'top' | 'bottom' | 'side';
}

export const SkateboardPreviewCanvas: React.FC<Props> = ({ board }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const boardMeshRef = useRef<Skateboard3D | null>(null);
  const fillLightRef = useRef<THREE.DirectionalLight | null>(null);
  const ringMeshRef = useRef<THREE.Mesh<THREE.RingGeometry, THREE.MeshBasicMaterial> | null>(null);

  // 1. Mount WebGLRenderer and Three.js Stage ONCE
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const width = containerRef.current.clientWidth || 360;
    const height = containerRef.current.clientHeight || 280;

    const scene = new THREE.Scene();
    scene.background = null;

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 50);
    camera.position.set(0, 1.3, 2.6);
    camera.lookAt(0, 0.15, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Studio Stage Lighting
    const keyLight = new THREE.DirectionalLight(0xfffaed, 2.4);
    keyLight.position.set(3, 4, 3);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(board.visuals.deckEdge, 1.8);
    fillLight.position.set(-3, 2, -2);
    scene.add(fillLight);
    fillLightRef.current = fillLight;

    const bottomRimLight = new THREE.DirectionalLight(board.visuals.wheelsGlow || 0x38bdf8, 2.0);
    bottomRimLight.position.set(0, -2, 2);
    scene.add(bottomRimLight);

    const ambLight = new THREE.AmbientLight(0xffffff, 1.0);
    scene.add(ambLight);

    // Illuminated Podium Stand
    const podiumGroup = new THREE.Group();
    podiumGroup.position.set(0, -0.35, 0);

    const baseGeo = new THREE.CylinderGeometry(1.2, 1.35, 0.12, 32);
    const baseMat = new THREE.MeshStandardMaterial({
      color: 0x090d16,
      metalness: 0.85,
      roughness: 0.2,
    });
    const baseMesh = new THREE.Mesh(baseGeo, baseMat);
    podiumGroup.add(baseMesh);

    // Neon Halo Ring on Pedestal
    const ringGeo = new THREE.RingGeometry(1.15, 1.25, 32);
    ringGeo.rotateX(-Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({
      color: board.visuals.deckEdge,
      side: THREE.DoubleSide,
    });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.position.set(0, 0.065, 0);
    podiumGroup.add(ringMesh);
    ringMeshRef.current = ringMesh;

    scene.add(podiumGroup);

    // 3D Skateboard Instance
    const skateboard = new Skateboard3D(board.visuals, board.id);
    skateboard.group.position.set(0, 0.05, 0);
    skateboard.group.rotation.set(0.2, 0.6, 0.12);
    scene.add(skateboard.group);
    boardMeshRef.current = skateboard;

    // Interaction / Drag Rotation
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let manualRotY = 0.6;
    let manualRotX = 0.2;

    const handlePointerDown = (e: PointerEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const handlePointerMove = (e: PointerEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      manualRotY += deltaX * 0.015;
      manualRotX = Math.max(-1.0, Math.min(1.0, manualRotX + deltaY * 0.015));
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const handlePointerUp = () => {
      isDragging = false;
    };

    const dom = containerRef.current;
    dom.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);

    // Animation Loop
    let animId: number;
    let clock = 0;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      clock += 0.016;

      if (!isDragging) {
        manualRotY += 0.012; // Gentle 360-degree showcase rotation
      }

      if (boardMeshRef.current) {
        boardMeshRef.current.group.position.y = 0.05 + Math.sin(clock * 2.2) * 0.04;
        boardMeshRef.current.group.rotation.y = manualRotY;
        boardMeshRef.current.group.rotation.x = manualRotX + Math.sin(clock * 1.5) * 0.05;
        boardMeshRef.current.group.rotation.z = Math.cos(clock * 1.8) * 0.08;
        boardMeshRef.current.update(0.016, 12);
      }

      if (ringMeshRef.current) {
        ringMeshRef.current.rotation.z += 0.005;
      }

      renderer.render(scene, camera);
    };

    animate();

    const updateDimensions = () => {
      if (!containerRef.current || !canvasRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      if (w === 0 || h === 0) return;
      const curAspect = w / h;
      camera.aspect = curAspect;
      const dist = curAspect < 0.8 ? 3.4 : curAspect < 1.0 ? 3.0 : curAspect < 1.3 ? 2.7 : 2.5;
      camera.position.set(0, 1.2, dist);
      camera.lookAt(0, 0.1, 0);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', updateDimensions);

    let resizeObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined' && containerRef.current) {
      resizeObserver = new ResizeObserver(() => {
        updateDimensions();
      });
      resizeObserver.observe(containerRef.current);
    }

    return () => {
      cancelAnimationFrame(animId);
      dom.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('resize', updateDimensions);
      if (resizeObserver) {
        resizeObserver.disconnect();
      }

      if (boardMeshRef.current) {
        scene.remove(boardMeshRef.current.group);
        boardMeshRef.current.dispose();
        boardMeshRef.current = null;
      }

      baseGeo.dispose();
      baseMat.dispose();
      ringGeo.dispose();
      ringMat.dispose();

      renderer.dispose();
    };
  }, []);

  // 2. React to board updates smoothly WITHOUT recreating WebGL context
  useEffect(() => {
    if (boardMeshRef.current) {
      boardMeshRef.current.setSkin(board.visuals);
    }
    if (fillLightRef.current) {
      fillLightRef.current.color.set(board.visuals.deckEdge);
    }
    if (ringMeshRef.current) {
      ringMeshRef.current.material.color.set(board.visuals.deckEdge);
    }
  }, [board]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full min-h-[220px] flex items-center justify-center select-none cursor-grab active:cursor-grabbing touch-none overflow-hidden"
    >
      <canvas ref={canvasRef} className="block w-full h-full" />
      {/* Floating 360 Degree Drag Hint */}
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-black/60 border border-slate-700/60 rounded-full text-[10px] text-slate-300 pointer-events-none backdrop-blur flex items-center gap-1.5">
        <span>🔄 Drag to rotate 360°</span>
      </div>
    </div>
  );
};
