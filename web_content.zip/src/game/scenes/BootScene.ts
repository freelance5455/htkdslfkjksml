import Phaser from 'phaser';
import { buildTextures } from '../textures';
import { storage } from '../storage';
import { sound } from '../audio';
import { haptics } from '../haptics';

export class BootScene extends Phaser.Scene {
  constructor() {
    super('Boot');
  }

  create(): void {
    buildTextures(this);
    const settings = storage.getSettings();
    sound.enabled = settings.sound;
    haptics.enabled = settings.haptics;

    const onReady = this.registry.get('onReady') as (() => void) | undefined;
    onReady?.();

    this.scene.start('Menu');
  }
}
