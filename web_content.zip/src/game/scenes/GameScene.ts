import Phaser from 'phaser';
import { Board, type ClearedCell, type Lines } from '../Board';
import { PieceGenerator } from '../PieceGenerator';
import { shapeById, type Shape } from '../shapes';
import { COMBO_WINDOW, formatScore, linePoints, praiseFor } from '../scoring';
import { storage, type SaveData } from '../storage';
import { sound } from '../audio';
import { haptics } from '../haptics';
import { computeLayout, type Layout, type SafeArea } from '../layout';
import { BLOCK_TEX, DEPTH, GRID, PALETTE, TEX, THEME, TRAY_SCALE } from '../constants';
import { PieceView } from '../PieceView';
import { IconButton, makeText } from '../ui';
import { hexCss, lighten, roundedTexture } from '../textures';
import { FpsMonitor, qualityFor, type Quality, type Tier } from '../perf';
import { Overlay, showGameOver, showPause } from '../overlays';

interface DragState {
  piece: PieceView;
  pointerId: number;
  px: number;
  py: number;
  grabDX: number;
  grabDY: number;
  startScale: number;
  t: number;
  row: number;
  col: number;
  valid: boolean;
}

const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export class GameScene extends Phaser.Scene {
  private L!: Layout;
  private q!: Quality;
  private blockScale = 1;

  private board = new Board();
  private gen = new PieceGenerator();
  private pieces: Array<PieceView | null> = [null, null, null];

  private score = 0;
  private displayedScore = 0;
  private best = 0;
  private startBest = 0;
  private combo = 0;
  private movesSinceClear = 0;
  private maxCombo = 0;
  private linesTotal = 0;

  private drag: DragState | null = null;
  private locked = false;
  private paused = false;
  private over = false;
  private continueGame = false;

  private bg!: Phaser.GameObjects.Image;
  private boardPanel!: Phaser.GameObjects.Image;
  private cells: Phaser.GameObjects.Image[] = [];
  private blocks: Phaser.GameObjects.Image[] = [];
  private ghosts: Phaser.GameObjects.Image[] = [];
  private flashes: Phaser.GameObjects.Image[] = [];
  private emitters: Phaser.GameObjects.Particles.ParticleEmitter[] = [];
  private hiMap = new Map<number, string>();

  private scoreText!: Phaser.GameObjects.Text;
  private bestText!: Phaser.GameObjects.Text;
  private crown!: Phaser.GameObjects.Image;
  private comboBadge!: Phaser.GameObjects.Text;
  private pauseBtn!: IconButton;
  private popups: Phaser.GameObjects.Text[] = [];
  private praiseText!: Phaser.GameObjects.Text;
  private comboText!: Phaser.GameObjects.Text;
  private hintText: Phaser.GameObjects.Text | null = null;
  private scoreTween: Phaser.Tweens.Tween | null = null;

  private overlay: Overlay | null = null;
  private overlayKind: 'pause' | 'over' | null = null;
  private fpsMon: FpsMonitor | null = null;
  private onVisibility = () => {
    if (document.hidden) {
      this.cancelDrag();
      sound.suspend();
    } else {
      sound.resume();
    }
  };

  constructor() {
    super('Game');
  }

  init(data: { continue?: boolean }): void {
    this.continueGame = !!data?.continue;
    this.board = new Board();
    this.pieces = [null, null, null];
    this.score = 0;
    this.displayedScore = 0;
    this.combo = 0;
    this.movesSinceClear = 0;
    this.maxCombo = 0;
    this.linesTotal = 0;
    this.drag = null;
    this.locked = false;
    this.paused = false;
    this.over = false;
    this.overlay = null;
    this.overlayKind = null;
    this.hiMap = new Map();
    this.cells = [];
    this.blocks = [];
    this.ghosts = [];
    this.flashes = [];
    this.emitters = [];
    this.popups = [];
    this.hintText = null;
    this.scoreTween = null;
  }

  /* ------------------------------------------------------------------ */
  /*  Lifecycle                                                          */
  /* ------------------------------------------------------------------ */

  create(): void {
    this.q = this.registry.get('quality') as Quality;
    this.L = this.makeLayout();
    this.best = storage.getBest();
    this.startBest = this.best;

    this.buildObjects();
    this.applyLayout();

    this.input.on('pointermove', this.onPointerMove, this);
    this.input.on('pointerup', this.onPointerUp, this);
    this.input.on('pointerupoutside', this.onPointerUp, this);
    this.scale.on(Phaser.Scale.Events.RESIZE, this.onResize, this);
    this.game.events.on(Phaser.Core.Events.BLUR, this.cancelDrag, this);
    document.addEventListener('visibilitychange', this.onVisibility);

    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      this.scale.off(Phaser.Scale.Events.RESIZE, this.onResize, this);
      this.game.events.off(Phaser.Core.Events.BLUR, this.cancelDrag, this);
      document.removeEventListener('visibilitychange', this.onVisibility);
    });

    const save = this.continueGame ? storage.getSave() : null;
    if (save) this.restore(save);
    else this.startNew();

    if (storage.getSettings().quality === 'auto') {
      this.fpsMon = new FpsMonitor((level) => this.downgrade(level));
    }

    this.cameras.main.fadeIn(260, 20, 27, 56);
  }

  update(_time: number, delta: number): void {
    if (this.drag) {
      this.drag.t = Math.min(1, this.drag.t + delta / 110);
      this.updateDragVisual();
    }
    if (this.fpsMon && !this.paused && !this.over) {
      this.fpsMon.update(delta, this.game.loop.actualFps);
    }
  }

  private makeLayout(): Layout {
    const dpr = (this.registry.get('dpr') as number) || 1;
    const safe = (this.registry.get('safe') as SafeArea) || { top: 0, bottom: 0 };
    return computeLayout(this.scale.width, this.scale.height, dpr, safe);
  }

  /* ------------------------------------------------------------------ */
  /*  Construction & layout                                              */
  /* ------------------------------------------------------------------ */

  private buildObjects(): void {
    this.bg = this.add.image(0, 0, 'bg').setOrigin(0).setDepth(DEPTH.BG);
    this.boardPanel = this.add.image(0, 0, TEX, 'white').setOrigin(0).setDepth(DEPTH.BOARD);

    for (let i = 0; i < GRID * GRID; i++) {
      this.cells.push(this.add.image(0, 0, TEX, 'cell').setDepth(DEPTH.CELLS));
      this.blocks.push(this.add.image(0, 0, TEX, 'block_0').setDepth(DEPTH.BLOCKS).setVisible(false));
    }
    for (let i = 0; i < 9; i++) {
      this.ghosts.push(this.add.image(0, 0, TEX, 'flat').setDepth(DEPTH.GHOST).setVisible(false));
    }
    for (let i = 0; i < 12; i++) {
      const f = this.add.image(0, 0, TEX, 'flat').setDepth(DEPTH.FLASH).setVisible(false);
      if (this.q.flashes) f.setBlendMode(Phaser.BlendModes.ADD);
      this.flashes.push(f);
    }

    this.crown = this.add.image(0, 0, TEX, 'icon_crown').setTint(THEME.goldHex).setDepth(DEPTH.HUD);
    this.bestText = makeText(this, 0, 0, formatScore(this.best), 34, {
      color: THEME.gold,
      origin: [0, 0.5],
    }).setDepth(DEPTH.HUD);
    this.scoreText = makeText(this, 0, 0, '0', 76, { shadow: true, shadowBlur: this.q.textShadowBlur ? 6 : 0 }).setDepth(DEPTH.HUD);
    this.comboBadge = makeText(this, 0, 0, '', 26, {
      color: '#ffb347',
      stroke: '#4a2200',
      strokeThickness: 4,
    })
      .setDepth(DEPTH.HUD)
      .setVisible(false);
    this.pauseBtn = new IconButton(this, {
      x: 0,
      y: 0,
      size: 72,
      icon: 'icon_pause',
      onClick: () => this.openPause(),
    }).setDepth(DEPTH.HUD);

    for (let i = 0; i < 5; i++) {
      this.popups.push(
        makeText(this, 0, 0, '', 44, { stroke: '#1a1030', strokeThickness: 6, shadow: true })
          .setDepth(DEPTH.POPUP)
          .setVisible(false)
      );
    }
    this.praiseText = makeText(this, 0, 0, '', 64, { stroke: '#2a1040', strokeThickness: 9, shadow: true })
      .setDepth(DEPTH.POPUP)
      .setVisible(false);
    this.comboText = makeText(this, 0, 0, '', 56, {
      color: THEME.gold,
      stroke: '#5a2a00',
      strokeThickness: 8,
      shadow: true,
    })
      .setDepth(DEPTH.POPUP)
      .setVisible(false);
  }

  private rebuildEmitters(): void {
    for (const e of this.emitters) e.destroy();
    this.emitters = [];
    if (this.q.particlesPerBlock <= 0) return;
    const u = this.L.u;
    for (let i = 0; i < PALETTE.length; i++) {
      const e = this.add.particles(0, 0, TEX, {
        frame: 'particle',
        lifespan: { min: 380, max: 720 },
        speed: { min: 80 * u, max: 360 * u },
        angle: { min: 0, max: 360 },
        scale: { start: 0.95 * u, end: 0 },
        gravityY: 1150 * u,
        alpha: { start: 1, end: 0 },
        rotate: { min: 0, max: 360 },
        tint: [PALETTE[i], lighten(PALETTE[i], 0.45), 0xffffff],
        emitting: false,
      });
      e.setDepth(DEPTH.PARTICLES);
      this.emitters.push(e);
    }
  }

  private cellX(c: number): number {
    return this.L.gridX + (c + 0.5) * this.L.cell;
  }

  private cellY(r: number): number {
    return this.L.gridY + (r + 0.5) * this.L.cell;
  }

  private slotX(i: number): number {
    return this.L.boardX + this.L.slotW * (i + 0.5);
  }

  private applyLayout(): void {
    const L = this.L;
    const u = L.u;
    this.blockScale = L.block / BLOCK_TEX;

    this.bg.setDisplaySize(L.W + 2, L.H + 2);
    this.boardPanel
      .setTexture(
        roundedTexture(this, L.boardSize, L.boardSize, 26 * u, hexCss(THEME.board), {
          border: hexCss(0x2d3b6c),
          borderW: Math.max(1, 2 * u),
        })
      )
      .setPosition(L.boardX, L.boardY);

    for (let r = 0; r < GRID; r++) {
      for (let c = 0; c < GRID; c++) {
        const i = r * GRID + c;
        this.cells[i].setPosition(this.cellX(c), this.cellY(r)).setScale(this.blockScale);
        this.blocks[i].setPosition(this.cellX(c), this.cellY(r));
      }
    }
    for (const g of this.ghosts) g.setScale(this.blockScale);
    for (const f of this.flashes) f.setVisible(false);
    this.rebuildEmitters();
    this.syncBoard();

    // HUD
    const crownSize = 44 * u;
    this.crown.setDisplaySize(crownSize, crownSize).setPosition(L.boardX + crownSize / 2 + 4 * u, L.hudY - 6 * u);
    this.bestText.setFontSize(34 * u).setPosition(L.boardX + crownSize + 16 * u, L.hudY - 6 * u);
    this.scoreText.setFontSize(76 * u).setPosition(L.W / 2, L.hudY - 10 * u).setScale(1);
    this.comboBadge.setFontSize(26 * u).setStroke('#4a2200', 4 * u).setPosition(L.W / 2, L.hudY + 50 * u);
    this.pauseBtn.destroy();
    this.pauseBtn = new IconButton(this, {
      x: L.W - L.boardX - 36 * u,
      y: L.hudY - 6 * u,
      size: 72 * u,
      icon: 'icon_pause',
      onClick: () => this.openPause(),
    }).setDepth(DEPTH.HUD);

    for (const p of this.popups) p.setFontSize(44 * u).setStroke('#1a1030', 6 * u).setVisible(false);
    this.praiseText.setFontSize(64 * u).setStroke('#2a1040', 9 * u).setVisible(false);
    this.comboText.setFontSize(56 * u).setStroke('#5a2a00', 8 * u).setVisible(false);
  }

  /** Reset block sprites from the model (kills any running animations). */
  private syncBoard(): void {
    for (let i = 0; i < GRID * GRID; i++) {
      const b = this.blocks[i];
      this.tweens.killTweensOf(b);
      const v = this.board.cells[i];
      b.setScale(this.blockScale).setAlpha(1);
      if (v >= 0) b.setFrame(`block_${v}`).setVisible(true);
      else b.setVisible(false);
    }
    this.hiMap.clear();
    for (const g of this.ghosts) g.setVisible(false);
  }

  private onResize(): void {
    const next = this.makeLayout();
    if (Math.abs(next.W - this.L.W) < 1 && Math.abs(next.H - this.L.H) < 1) return;
    this.cancelDrag();
    this.L = next;
    this.applyLayout();
    this.pieces.forEach((p, i) => {
      if (!p) return;
      const shape = p.shape;
      p.destroy();
      this.pieces[i] = null;
      this.spawnPiece(shape, i, -1);
    });
    this.updateAvailability();
    if (this.hintText) this.showHint();
    if (this.overlay) {
      const kind = this.overlayKind;
      this.overlay.destroy();
      this.overlay = null;
      if (kind === 'pause') this.openPause(true);
      else if (kind === 'over') this.showGameOverPanel(this.score > this.startBest && this.score > 0);
    }
  }

  private downgrade(level: number): void {
    const cur = this.q.tier;
    let next: Tier = 'low';
    if (cur === 'high' && level === 1) next = 'mid';
    if (next === cur) return;
    this.q = qualityFor(next);
    this.registry.set('quality', this.q);
    storage.setAutoTier(next);
    for (const f of this.flashes) f.setBlendMode(this.q.flashes ? Phaser.BlendModes.ADD : Phaser.BlendModes.NORMAL);
    this.rebuildEmitters();
    const setDpr = this.registry.get('setDpr') as ((d: number) => void) | undefined;
    setDpr?.(Math.min(window.devicePixelRatio || 1, this.q.dprCap));
  }

  /* ------------------------------------------------------------------ */
  /*  Game state                                                         */
  /* ------------------------------------------------------------------ */

  private startNew(): void {
    this.board = new Board();
    this.score = 0;
    this.displayedScore = 0;
    this.combo = 0;
    this.movesSinceClear = 0;
    this.syncBoard();
    this.updateHud();
    this.refillTray(true);
    const stats = storage.getStats();
    storage.setStats({ ...stats, games: stats.games + 1 });
    this.saveGame();
    if (stats.games < 2) this.showHint();
  }

  /** Onboarding hint for the first couple of games. */
  private showHint(): void {
    const L = this.L;
    this.hintText?.destroy();
    const y = (L.boardY + L.boardSize + (L.trayY - L.trayH / 2)) / 2;
    this.hintText = makeText(this, L.W / 2, y, 'Drag pieces onto the board\nFill a row or column to clear it', 24 * L.u, {
      color: '#aab6e6',
    }).setDepth(DEPTH.HUD);
    this.hintText.setLineSpacing(6 * L.u);
    this.tweens.add({ targets: this.hintText, alpha: 0.55, duration: 900, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
  }

  private hideHint(): void {
    const t = this.hintText;
    if (!t) return;
    this.hintText = null;
    this.tweens.killTweensOf(t);
    this.tweens.add({ targets: t, alpha: 0, duration: 300, onComplete: () => t.destroy() });
  }

  private restore(save: SaveData): void {
    this.board = new Board(save.board);
    this.score = save.score;
    this.displayedScore = save.score;
    this.combo = save.combo;
    this.movesSinceClear = save.movesSinceClear;
    if (this.score > this.best) {
      this.best = this.score;
      storage.setBest(this.best);
    }
    this.syncBoard();
    this.updateHud();
    const shapes = save.pieces.map((id) => (id === null ? null : shapeById(id)));
    if (shapes.every((s) => !s)) {
      this.refillTray(true);
    } else {
      shapes.forEach((s, i) => s && this.spawnPiece(s, i, i * 60));
      this.updateAvailability();
    }
    if (!this.anyMovePossible()) this.time.delayedCall(600, () => this.startGameOver());
  }

  private saveGame(): void {
    if (this.over) return;
    storage.setSave({
      board: this.board.toArray(),
      pieces: this.pieces.map((p) => (p ? p.shape.id : null)),
      score: this.score,
      combo: this.combo,
      movesSinceClear: this.movesSinceClear,
    });
  }

  private updateHud(): void {
    this.scoreText.setText(formatScore(this.score));
    this.bestText.setText(formatScore(this.best));
    this.updateComboBadge();
  }

  private updateComboBadge(): void {
    if (this.combo >= 2) {
      this.comboBadge.setText(`COMBO x${this.combo}`).setVisible(true);
    } else {
      this.comboBadge.setVisible(false);
    }
  }

  private anyMovePossible(): boolean {
    return this.pieces.some((p) => p && this.board.canPlaceAnywhere(p.shape));
  }

  private updateAvailability(): void {
    for (const p of this.pieces) if (p) p.setAvailable(this.board.canPlaceAnywhere(p.shape));
  }

  /* ------------------------------------------------------------------ */
  /*  Tray                                                               */
  /* ------------------------------------------------------------------ */

  private refillTray(animate: boolean): void {
    const set = this.gen.generateSet(this.board);
    set.forEach((shape, i) => this.spawnPiece(shape, i, animate ? i * 70 : -1));
    this.updateAvailability();
    if (animate) sound.appear();
  }

  private spawnPiece(shape: Shape, slot: number, delay: number): void {
    const L = this.L;
    const p = new PieceView(this, shape, L.cell, L.block, this.q.dragShadow);
    p.slot = slot;
    p.homeX = this.slotX(slot);
    p.homeY = L.trayY;
    p.setPosition(p.homeX, p.homeY).setDepth(DEPTH.TRAY);
    const hw = L.slotW / 2 / TRAY_SCALE;
    const hh = L.trayH / 2 / TRAY_SCALE;
    p.setInteractive(new Phaser.Geom.Rectangle(-hw, -hh, hw * 2, hh * 2), Phaser.Geom.Rectangle.Contains);
    p.on('pointerdown', (pointer: Phaser.Input.Pointer) => this.beginDrag(p, pointer));
    this.pieces[slot] = p;
    if (delay >= 0) {
      p.setScale(0);
      this.tweens.add({ targets: p, scale: TRAY_SCALE, duration: 320, delay, ease: 'Back.easeOut' });
    } else {
      p.setScale(TRAY_SCALE);
    }
  }

  /* ------------------------------------------------------------------ */
  /*  Drag & drop                                                        */
  /* ------------------------------------------------------------------ */

  private beginDrag(piece: PieceView, pointer: Phaser.Input.Pointer): void {
    if (this.locked || this.drag || this.paused || this.over) return;
    sound.unlock();
    this.tweens.killTweensOf(piece);
    piece.setDepth(DEPTH.DRAG);
    piece.setShadowVisible(true);
    this.drag = {
      piece,
      pointerId: pointer.id,
      px: pointer.x,
      py: pointer.y,
      grabDX: piece.x - pointer.x,
      grabDY: piece.y - pointer.y,
      startScale: piece.scale,
      t: 0,
      row: -99,
      col: -99,
      valid: false,
    };
    sound.pickup();
    haptics.tap();
    this.updateDragVisual();
  }

  private onPointerMove(p: Phaser.Input.Pointer): void {
    if (this.drag && p.id === this.drag.pointerId) {
      this.drag.px = p.x;
      this.drag.py = p.y;
    }
  }

  private onPointerUp(p: Phaser.Input.Pointer): void {
    if (this.drag && p.id === this.drag.pointerId) this.endDrag();
  }

  private liftFor(piece: PieceView): number {
    return this.L.cell * 1.35 + (piece.shape.h * this.L.cell) / 2;
  }

  private updateDragVisual(): void {
    const d = this.drag;
    if (!d) return;
    const L = this.L;
    const e = easeOutCubic(d.t);
    const lift = this.liftFor(d.piece);
    const tx = d.px;
    const ty = d.py - lift;
    d.piece.setPosition(lerp(d.px + d.grabDX, tx, e), lerp(d.py + d.grabDY, ty, e));
    d.piece.setScale(lerp(d.startScale, 1, e));

    const shape = d.piece.shape;
    const left = tx - (shape.w * L.cell) / 2;
    const top = ty - (shape.h * L.cell) / 2;
    const col = Math.round((left - L.gridX) / L.cell);
    const row = Math.round((top - L.gridY) / L.cell);
    const valid = this.board.canPlace(shape, row, col);
    if (row !== d.row || col !== d.col || valid !== d.valid) {
      d.row = row;
      d.col = col;
      d.valid = valid;
      this.updatePreview();
    }
  }

  private updatePreview(): void {
    this.clearPreview();
    const d = this.drag;
    if (!d || !d.valid) return;
    const shape = d.piece.shape;
    const color = shape.color;
    shape.cells.forEach(([dr, dc], i) => {
      this.ghosts[i]
        .setPosition(this.cellX(d.col + dc), this.cellY(d.row + dr))
        .setTint(PALETTE[color])
        .setAlpha(0.4)
        .setVisible(true);
    });
    const lines = this.board.previewLines(shape, d.row, d.col);
    if (lines.rows.length || lines.cols.length) {
      const frame = `block_${color}`;
      const mark = (r: number, c: number) => {
        const idx = r * GRID + c;
        if (this.board.cells[idx] < 0 || this.hiMap.has(idx)) return;
        const b = this.blocks[idx];
        this.hiMap.set(idx, b.frame.name);
        b.setFrame(frame);
      };
      for (const r of lines.rows) for (let c = 0; c < GRID; c++) mark(r, c);
      for (const c of lines.cols) for (let r = 0; r < GRID; r++) mark(r, c);
      for (let i = 0; i < shape.cells.length; i++) this.ghosts[i].setAlpha(0.72);
    }
  }

  private clearPreview(): void {
    for (const g of this.ghosts) g.setVisible(false);
    for (const [idx, frame] of this.hiMap) this.blocks[idx].setFrame(frame);
    this.hiMap.clear();
  }

  private endDrag(): void {
    const d = this.drag;
    if (!d) return;
    this.drag = null;
    const piece = d.piece;
    if (d.valid && !this.locked) {
      this.placePiece(piece, d.row, d.col);
      return;
    }
    this.clearPreview();
    this.returnPiece(piece);
    const L = this.L;
    const overBoard =
      d.px > L.boardX && d.px < L.boardX + L.boardSize && d.py - this.liftFor(piece) > L.boardY - L.cell && d.py < L.boardY + L.boardSize + L.cell;
    if (overBoard && d.t > 0.3) {
      sound.invalid();
      haptics.fail();
    }
  }

  private returnPiece(piece: PieceView): void {
    piece.setShadowVisible(false);
    piece.setDepth(DEPTH.TRAY);
    this.tweens.killTweensOf(piece);
    this.tweens.add({
      targets: piece,
      x: piece.homeX,
      y: piece.homeY,
      scale: TRAY_SCALE,
      duration: 220,
      ease: 'Quad.easeOut',
    });
  }

  private cancelDrag(): void {
    if (!this.drag) return;
    const p = this.drag.piece;
    this.drag = null;
    this.clearPreview();
    this.returnPiece(p);
  }

  /* ------------------------------------------------------------------ */
  /*  Placement, clearing & scoring                                      */
  /* ------------------------------------------------------------------ */

  private placePiece(piece: PieceView, row: number, col: number): void {
    const L = this.L;
    const shape = piece.shape;
    const color = shape.color;

    this.clearPreview();
    this.hideHint();
    this.board.place(shape, row, col, color);
    this.pieces[piece.slot] = null;
    piece.destroy();

    for (const [dr, dc] of shape.cells) {
      const b = this.blocks[(row + dr) * GRID + col + dc];
      this.tweens.killTweensOf(b);
      b.setFrame(`block_${color}`).setVisible(true).setAlpha(1).setScale(this.blockScale * 1.16);
      this.tweens.add({ targets: b, scale: this.blockScale, duration: 140, ease: 'Back.easeOut' });
    }
    sound.drop();
    haptics.place();

    const cx = L.gridX + (col + shape.w / 2) * L.cell;
    const cy = L.gridY + (row + shape.h / 2) * L.cell;
    const lines = this.board.getFullLines();
    const n = lines.rows.length + lines.cols.length;
    let points = shape.cells.length;

    if (n > 0) {
      this.combo += 1;
      this.movesSinceClear = 0;
      this.maxCombo = Math.max(this.maxCombo, this.combo);
      this.linesTotal += n;
      points += linePoints(n, this.combo);
      const cleared = this.board.clearLines(lines);
      this.animateClear(cleared, lines, cx, cy, color);
      const praise = praiseFor(n, this.combo);
      this.showCombo(this.combo, praise, n);
      sound.clear(n, this.combo);
      if (this.combo >= 2) sound.combo(this.combo);
      if (praise) sound.praise();
      haptics.clear(n);
      if (n >= 3 && this.q.shake) this.cameras.main.shake(160, 0.0035);
    } else {
      this.movesSinceClear += 1;
      if (this.movesSinceClear >= COMBO_WINDOW) this.combo = 0;
    }

    this.addScore(points, cx, cy - L.cell * 0.5, n > 0);
    this.updateComboBadge();

    if (this.pieces.every((p) => !p)) this.refillTray(true);
    else this.updateAvailability();
    this.saveGame();

    if (!this.anyMovePossible()) {
      this.time.delayedCall(n > 0 ? 700 : 300, () => this.startGameOver());
    }
  }

  private animateClear(cells: ClearedCell[], lines: Lines, ox: number, oy: number, color: number): void {
    const L = this.L;
    const base = this.blockScale;
    const per = this.q.particlesPerBlock;
    const emitter = this.emitters[color];

    if (this.q.flashes) {
      const midX = L.gridX + L.gridSize / 2;
      const midY = L.gridY + L.gridSize / 2;
      for (const r of lines.rows) this.flash(midX, this.cellY(r), L.gridSize - L.gap, L.block, color);
      for (const c of lines.cols) this.flash(this.cellX(c), midY, L.block, L.gridSize - L.gap, color);
    }

    const frame = `block_${color}`;
    for (const cell of cells) {
      const b = this.blocks[cell.r * GRID + cell.c];
      const x = this.cellX(cell.c);
      const y = this.cellY(cell.r);
      const dist = Math.hypot(x - ox, y - oy) / L.cell;
      const delay = Math.min(280, dist * 30);
      this.tweens.killTweensOf(b);
      b.setFrame(frame).setVisible(true).setAlpha(1).setScale(base);
      this.tweens.add({
        targets: b,
        scale: base * 0.15,
        alpha: 0,
        duration: 210,
        delay,
        ease: 'Quad.easeIn',
        onComplete: () => {
          b.setVisible(false).setScale(base).setAlpha(1);
        },
      });
      if (per > 0 && emitter) {
        this.time.delayedCall(delay + 40, () => emitter.explode(per, x, y));
      }
    }
  }

  private flash(x: number, y: number, w: number, h: number, color: number): void {
    const f = this.flashes.find((s) => !s.visible) ?? this.flashes[0];
    this.tweens.killTweensOf(f);
    f.setPosition(x, y).setDisplaySize(w, h).setTint(lighten(PALETTE[color], 0.55)).setAlpha(0.9).setVisible(true);
    const sx = f.scaleX;
    const sy = f.scaleY;
    this.tweens.add({
      targets: f,
      alpha: 0,
      scaleX: w > h ? sx * 1.03 : sx * 1.6,
      scaleY: w > h ? sy * 1.6 : sy * 1.03,
      duration: 340,
      ease: 'Quad.easeOut',
      onComplete: () => f.setVisible(false),
    });
  }

  private addScore(points: number, x: number, y: number, big: boolean): void {
    this.score += points;
    if (this.score > this.best) {
      const wasBelow = this.best <= this.startBest;
      this.best = this.score;
      storage.setBest(this.best);
      this.bestText.setText(formatScore(this.best));
      if (wasBelow && this.startBest > 0) {
        this.tweens.add({ targets: this.crown, scale: this.crown.scale * 1.4, duration: 180, yoyo: true, ease: 'Quad.easeOut' });
        this.tweens.add({ targets: this.bestText, scale: 1.25, duration: 180, yoyo: true, ease: 'Quad.easeOut' });
      }
    }

    this.scoreTween?.stop();
    const o = { v: this.displayedScore };
    this.scoreTween = this.tweens.add({
      targets: o,
      v: this.score,
      duration: 450,
      ease: 'Quad.easeOut',
      onUpdate: () => {
        this.displayedScore = o.v;
        this.scoreText.setText(formatScore(o.v));
      },
      onComplete: () => {
        this.displayedScore = this.score;
        this.scoreText.setText(formatScore(this.score));
      },
    });
    this.tweens.killTweensOf(this.scoreText);
    this.scoreText.setScale(1);
    this.tweens.add({ targets: this.scoreText, scale: big ? 1.16 : 1.07, duration: 90, yoyo: true, ease: 'Quad.easeOut' });

    this.showPopup(`+${points}`, x, y, big ? THEME.gold : '#ffffff', big ? 52 : 42);
  }

  private showPopup(str: string, x: number, y: number, color: string, size: number): void {
    const L = this.L;
    const t = this.popups.find((p) => !p.visible) ?? this.popups[0];
    this.tweens.killTweensOf(t);
    const px = Phaser.Math.Clamp(x, L.boardX + 70 * L.u, L.boardX + L.boardSize - 70 * L.u);
    const py = Phaser.Math.Clamp(y, L.boardY + 40 * L.u, L.boardY + L.boardSize - 40 * L.u);
    t.setText(str).setColor(color).setFontSize(size * L.u).setPosition(px, py).setAlpha(1).setScale(0.5).setVisible(true);
    this.tweens.add({ targets: t, scale: 1, duration: 160, ease: 'Back.easeOut' });
    this.tweens.add({
      targets: t,
      y: py - 90 * L.u,
      alpha: 0,
      duration: 820,
      delay: 160,
      ease: 'Quad.easeIn',
      onComplete: () => t.setVisible(false),
    });
  }

  private showCombo(combo: number, praise: string | null, lines: number): void {
    const L = this.L;
    const cx = L.gridX + L.gridSize / 2;
    const cy = L.boardY + L.boardSize / 2;
    const showBoth = combo >= 2 && praise;
    const pop = (t: Phaser.GameObjects.Text, y: number, hold: number) => {
      this.tweens.killTweensOf(t);
      t.setPosition(cx, y).setAlpha(1).setScale(0.3).setVisible(true);
      this.tweens.add({ targets: t, scale: 1, duration: 260, ease: 'Back.easeOut' });
      this.tweens.add({
        targets: t,
        alpha: 0,
        y: y - 40 * L.u,
        scale: 1.1,
        duration: 240,
        delay: hold,
        ease: 'Quad.easeIn',
        onComplete: () => t.setVisible(false),
      });
    };
    if (praise) {
      const color = lines >= 5 ? '#ff6b9d' : lines === 4 ? '#ff8f5c' : lines === 3 ? '#ffd14d' : lines === 2 ? '#7ee3ff' : '#9dff8a';
      this.praiseText.setText(praise).setColor(color);
      pop(this.praiseText, cy - (showBoth ? 48 * L.u : 0), 620);
    }
    if (combo >= 2) {
      this.comboText.setText(`COMBO x${combo}`);
      pop(this.comboText, cy + (showBoth ? 44 * L.u : 0), 560);
    }
  }

  /* ------------------------------------------------------------------ */
  /*  Game over                                                          */
  /* ------------------------------------------------------------------ */

  private startGameOver(): void {
    if (this.over) return;
    this.over = true;
    this.locked = true;
    this.cancelDrag();
    this.clearPreview();
    for (const p of this.pieces) p?.disableInteractive();
    if (this.overlay && this.overlayKind === 'pause') {
      this.overlay.destroy();
      this.overlay = null;
      this.overlayKind = null;
    }
    this.pauseBtn.enabled = false;

    const record = this.score > this.startBest && this.score > 0;
    storage.clearSave();
    storage.setBest(Math.max(this.best, this.score));
    const stats = storage.getStats();
    storage.setStats({
      games: stats.games,
      lines: stats.lines + this.linesTotal,
      maxCombo: Math.max(stats.maxCombo, this.maxCombo),
    });

    sound.gameOver();
    haptics.gameOver();

    for (const p of this.pieces) {
      if (p) this.tweens.add({ targets: p, alpha: 0, scale: TRAY_SCALE * 0.8, duration: 320, ease: 'Quad.easeIn' });
    }

    const filled: number[] = [];
    for (let i = 0; i < GRID * GRID; i++) if (this.board.cells[i] >= 0) filled.push(i);
    const step = Phaser.Math.Clamp(900 / Math.max(1, filled.length), 8, 24);
    filled.forEach((idx, i) => {
      this.time.delayedCall(i * step, () => {
        const b = this.blocks[idx];
        this.tweens.killTweensOf(b);
        b.setFrame('block_gray').setVisible(true).setAlpha(1).setScale(this.blockScale * 0.8);
        this.tweens.add({ targets: b, scale: this.blockScale, duration: 180, ease: 'Back.easeOut' });
      });
    });
    this.time.delayedCall(filled.length * step + 550, () => this.showGameOverPanel(record));
  }

  private showGameOverPanel(record: boolean): void {
    this.overlayKind = 'over';
    this.overlay = showGameOver(
      this,
      this.L,
      { score: this.score, best: Math.max(this.best, this.score), record },
      {
        again: () => this.closeOverlay(() => this.restart()),
        home: () => this.closeOverlay(() => this.goHome()),
      }
    );
    if (record) {
      sound.record();
      haptics.record();
      this.celebrate();
    }
  }

  private celebrate(): void {
    if (!this.emitters.length) return;
    const L = this.L;
    for (const e of this.emitters) e.setDepth(DEPTH.OVERLAY + 5);
    const bursts = this.q.tier === 'low' ? 2 : 4;
    for (let k = 0; k < bursts; k++) {
      this.time.delayedCall(k * 220, () => {
        this.emitters.forEach((e, i) => {
          const x = L.W * (0.15 + Math.random() * 0.7);
          const y = L.H * (0.12 + Math.random() * 0.2);
          e.explode(this.q.tier === 'low' ? 3 : 6 + (i % 2) * 3, x, y);
        });
      });
    }
  }

  /* ------------------------------------------------------------------ */
  /*  Pause / navigation                                                 */
  /* ------------------------------------------------------------------ */

  private openPause(force = false): void {
    if (this.over || (this.paused && !force) || this.drag) return;
    this.paused = true;
    this.locked = true;
    this.overlayKind = 'pause';
    this.overlay = showPause(this, this.L, {
      resume: () =>
        this.closeOverlay(() => {
          this.paused = false;
          this.locked = false;
        }),
      restart: () => this.closeOverlay(() => this.restart()),
      home: () => this.closeOverlay(() => this.goHome()),
    });
  }

  private closeOverlay(cb: () => void): void {
    const o = this.overlay;
    this.overlay = null;
    this.overlayKind = null;
    if (o) o.close(cb);
    else cb();
  }

  private restart(): void {
    storage.clearSave();
    this.over = false;
    this.cameras.main.fadeOut(180, 20, 27, 56);
    this.cameras.main.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => {
      this.scene.restart({ continue: false });
    });
  }

  private goHome(): void {
    this.cameras.main.fadeOut(200, 20, 27, 56);
    this.cameras.main.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => {
      this.scene.start('Menu');
    });
  }
}
