/**
 * SPR - Sahil Powerful Run
 * 3D Character Preview Stage for Shop
 * Supports rotating 3D character with real-time Skateboard preview toggle
 * Single WebGL context lifecycle with zero memory leaks across selections
 */

import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { Character3D } from '../models/Character3D';

interface Props {
  characterId: number;
  showSkateboard?: boolean;
}

export const CharacterPreviewCanvas: React.FC<Props> = ({ characterId, showSkateboard = true }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const characterRef = useRef<Character3D | null>(null);

  // 1. Mount WebGLRenderer and Three.js Stage ONCE
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const width = containerRef.current.clientWidth || 300;
    const height = containerRef.current.clientHeight || 300;

    const scene = new THREE.Scene();
    scene.background = null;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 50);
    const aspect = width / height;
    const initialDist = aspect < 0.8 ? 4.8 : aspect < 1.0 ? 4.4 : aspect < 1.3 ? 4.0 : 3.8;
    camera.position.set(0, 1.2, initialDist);
    camera.lookAt(0, 0.9, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Studio Lighting
    const keyLight = new THREE.DirectionalLight(0xfffaed, 2.2);
    keyLight.position.set(3, 5, 4);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x38bdf8, 1.4);
    fillLight.position.set(-3, 2, -2);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xf59e0b, 1.5);
    rimLight.position.set(0, 3, -4);
    scene.add(rimLight);

    const ambLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambLight);

    // Glowing Pedestal Mesh
    const pedGeo = new THREE.CylinderGeometry(1.4, 1.6, 0.25, 24);
    const pedMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.8,
      roughness: 0.2,
    });
    const pedestal = new THREE.Mesh(pedGeo, pedMat);
    pedestal.position.set(0, -0.12, 0);
    scene.add(pedestal);

    const ringGeo = new THREE.RingGeometry(1.2, 1.45, 24);
    ringGeo.rotateX(-Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      side: THREE.DoubleSide,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.set(0, 0.02, 0);
    scene.add(ring);

    // Particle Sparks around Pedestal (matches reference design)
    const particleCount = 28;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleSpeeds = new Float32Array(particleCount);
    const particleRadii = new Float32Array(particleCount);
    const particleAngles = new Float32Array(particleCount);

    for (let i = 0; i < particleCount; i++) {
      particleAngles[i] = (i / particleCount) * Math.PI * 2;
      particleRadii[i] = 1.15 + Math.random() * 0.35;
      particleSpeeds[i] = 0.8 + Math.random() * 0.6;
      particlePositions[i * 3] = Math.cos(particleAngles[i]) * particleRadii[i];
      particlePositions[i * 3 + 1] = 0.05 + Math.random() * 0.2;
      particlePositions[i * 3 + 2] = Math.sin(particleAngles[i]) * particleRadii[i];
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0xf59e0b,
      size: 0.06,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
    });
    const sparkPoints = new THREE.Points(particleGeo, particleMat);
    scene.add(sparkPoints);

    // 3D Character Instance
    const character = new Character3D(characterId);
    character.setSkateboardActive(showSkateboard);
    character.setAnimation(showSkateboard ? 'skate' : 'victory');
    scene.add(character.group);
    characterRef.current = character;

    let animId: number;
    let lastTime = performance.now();

    const animate = (time: number) => {
      animId = requestAnimationFrame(animate);
      const delta = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      if (characterRef.current) {
        characterRef.current.group.rotation.y += delta * 0.7;
        characterRef.current.update(delta);
      }

      // Orbit particles
      const posAttr = particleGeo.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < particleCount; i++) {
        particleAngles[i] += delta * particleSpeeds[i];
        posAttr.setX(i, Math.cos(particleAngles[i]) * particleRadii[i]);
        posAttr.setY(i, 0.05 + Math.sin(time * 0.003 + i) * 0.08);
        posAttr.setZ(i, Math.sin(particleAngles[i]) * particleRadii[i]);
      }
      posAttr.needsUpdate = true;

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    const updateDimensions = () => {
      if (!containerRef.current || !canvasRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      if (w === 0 || h === 0) return;
      const curAspect = w / h;
      camera.aspect = curAspect;
      const dist = curAspect < 0.8 ? 4.8 : curAspect < 1.0 ? 4.4 : curAspect < 1.3 ? 4.0 : 3.8;
      camera.position.set(0, 1.2, dist);
      camera.lookAt(0, 0.9, 0);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', updateDimensions);

    let resizeObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined' && containerRef.current) {
      resizeObserver = new ResizeObserver(() => {
        updateDimensions();
      });
      resizeObserver.observe(containerRef.current);
    }

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', updateDimensions);
      if (resizeObserver) {
        resizeObserver.disconnect();
      }

      if (characterRef.current) {
        scene.remove(characterRef.current.group);
        characterRef.current.dispose();
        characterRef.current = null;
      }

      pedGeo.dispose();
      pedMat.dispose();
      ringGeo.dispose();
      ringMat.dispose();
      particleGeo.dispose();
      particleMat.dispose();

      renderer.dispose();
    };
  }, []);

  // 2. React to characterId or showSkateboard updates smoothly WITHOUT recreating WebGL context
  useEffect(() => {
    if (characterRef.current) {
      characterRef.current.setCharacter(characterId);
      characterRef.current.setSkateboardActive(showSkateboard);
      characterRef.current.setAnimation(showSkateboard ? 'skate' : 'victory');
    }
  }, [characterId, showSkateboard]);

  return (
    <div ref={containerRef} className="w-full h-full relative overflow-hidden flex items-center justify-center">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};
