import { WeatherType, Particle } from '../types/game';
import { sounds } from './audio';

export class WeatherSystem {
  public currentWeather: WeatherType = 'clear';
  public timer: number = 0;
  public weatherDuration: number = 1800; // ~30-45 seconds in game ticks
  public lightningTimer: number = 0;
  public lightningFlash: number = 0; // 0 to 1 intensity
  public rainIntensity: number = 0; // smooth blend 0 to 1

  public get current(): WeatherType {
    return this.currentWeather;
  }

  public update(
    timeOfDay: number,
    particlesList: Particle[],
    camX: number,
    camY: number,
    viewW: number,
    viewH: number
  ) {
    this.timer++;

    // Random weather progression
    if (this.timer >= this.weatherDuration) {
      this.timer = 0;
      this.cycleWeather();
    }

    // Target rain intensity
    const targetIntensity = this.currentWeather === 'rain' ? 0.7 : this.currentWeather === 'storm' ? 1.0 : 0;
    this.rainIntensity += (targetIntensity - this.rainIntensity) * 0.05;

    // Emit rain particles if raining or storming
    if (this.rainIntensity > 0.1) {
      const dropCount = Math.floor((this.currentWeather === 'storm' ? 8 : 4) * this.rainIntensity);
      for (let i = 0; i < dropCount; i++) {
        const x = camX - viewW / 2 + Math.random() * (viewW + 200) - 100;
        const y = camY - viewH / 2 - 20;
        particlesList.push({
          x,
          y,
          vx: -1.5 - Math.random() * 1.5,
          vy: 8 + Math.random() * 4,
          life: 30,
          maxLife: 30,
          size: 2,
          color: this.currentWeather === 'storm' ? '#93c5fd' : '#bfdbfe',
          alpha: 0.6,
          shape: 'rain',
        });
      }
    }

    // Lightning in storms
    if (this.currentWeather === 'storm') {
      this.lightningTimer++;
      if (this.lightningTimer > 300 && Math.random() < 0.015) {
        this.lightningTimer = 0;
        this.lightningFlash = 0.8;
        sounds.playThunder();
      }
    }

    if (this.lightningFlash > 0) {
      this.lightningFlash = Math.max(0, this.lightningFlash - 0.08);
    }
  }

  private cycleWeather() {
    const r = Math.random();
    if (r < 0.45) {
      this.currentWeather = 'clear';
      this.weatherDuration = 2400;
    } else if (r < 0.7) {
      this.currentWeather = 'cloudy';
      this.weatherDuration = 1800;
    } else if (r < 0.9) {
      this.currentWeather = 'rain';
      this.weatherDuration = 1600;
    } else {
      this.currentWeather = 'storm';
      this.weatherDuration = 1200;
    }
  }

  public setWeather(w: WeatherType) {
    this.currentWeather = w;
    this.timer = 0;
  }

  public render(ctx: CanvasRenderingContext2D, width: number, height: number) {
    // 1. Rain / Storm atmospheric darkening & tint
    if (this.rainIntensity > 0.01) {
      ctx.save();
      const alpha = this.currentWeather === 'storm'
        ? Math.min(0.38, 0.28 * this.rainIntensity)
        : Math.min(0.22, 0.16 * this.rainIntensity);
      ctx.fillStyle = `rgba(15, 25, 45, ${alpha})`;
      ctx.fillRect(0, 0, width, height);
      ctx.restore();
    } else if (this.currentWeather === 'cloudy') {
      ctx.save();
      ctx.fillStyle = 'rgba(45, 55, 70, 0.08)';
      ctx.fillRect(0, 0, width, height);
      ctx.restore();
    }

    // 2. Full-screen lightning flash during storms
    if (this.lightningFlash > 0.01) {
      ctx.save();
      ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(0.85, this.lightningFlash * 0.9)})`;
      ctx.fillRect(0, 0, width, height);
      ctx.restore();
    }
  }
}

export const weather = new WeatherSystem();
