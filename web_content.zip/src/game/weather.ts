import * as THREE from 'three';
import type { DayTimePhase, WeatherCondition } from './types';

export interface WeatherPhysicsModifiers {
  gripMultiplier: number;
  brakeMultiplier: number;
  dragMultiplier: number;
  wheelieLiftMultiplier: number;
  nightFactor: number;
  rainFactor: number;
  fogDensity: number;
}

export class DynamicWeatherSystem {
  public weather: WeatherCondition = 'sol';
  public autoWeather = true;
  public autoDayNight = true;
  // 0.0 = midnight, 0.25 = dawn, 0.5 = noon, 0.75 = sunset
  public timeOfDay = 0.44;
  private weatherTimer = 0;
  private weatherTransition = 1;
  private prevWeather: WeatherCondition = 'sol';

  private sunLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private fog: THREE.FogExp2;
  private skyColor = new THREE.Color(0x8ec5f7);
  private fogColor = new THREE.Color(0x9ec8ed);

  private rainPoints: THREE.Points;
  private rainPositions: Float32Array;
  private starsPoints: THREE.Points;
  private sunDisc: THREE.Mesh;

  private readonly rainCount = 420;

  constructor(scene: THREE.Scene, isSoftwareGl: boolean) {
    this.fog = new THREE.FogExp2(0x9ec8ed, 0.0014);
    scene.fog = this.fog;
    scene.background = this.skyColor;

    this.hemiLight = new THREE.HemisphereLight(0x9fd3ff, 0x5c5346, 0.72);
    scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff4dd, 1.85);
    this.sunLight.position.set(120, 180, 90);
    this.sunLight.castShadow = !isSoftwareGl;
    this.sunLight.shadow.mapSize.width = 1024;
    this.sunLight.shadow.mapSize.height = 1024;
    const d = 40;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.camera.near = 2;
    this.sunLight.shadow.camera.far = 260;
    this.sunLight.shadow.bias = -0.0006;
    this.sunLight.shadow.normalBias = 0.025;
    scene.add(this.sunLight);
    scene.add(this.sunLight.target);

    // Visual Sun/Moon disc in far sky
    this.sunDisc = new THREE.Mesh(
      new THREE.SphereGeometry(18, 16, 16),
      new THREE.MeshBasicMaterial({ color: 0xfff7cc, fog: false })
    );
    scene.add(this.sunDisc);

    // Stars dome for night sky
    const starCount = 220;
    const starPos = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI * 0.44;
      const r = 680;
      starPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      starPos[i * 3 + 1] = r * Math.cos(phi) + 40;
      starPos[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
    }
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    const starMat = new THREE.PointsMaterial({
      color: 0xf8fafc,
      size: 2.8,
      transparent: true,
      opacity: 0,
      fog: false,
      depthWrite: false,
    });
    this.starsPoints = new THREE.Points(starGeo, starMat);
    scene.add(this.starsPoints);

    // 3D Rain streaks surrounding player
    this.rainPositions = new Float32Array(this.rainCount * 3);
    for (let i = 0; i < this.rainCount; i++) {
      this.rainPositions[i * 3] = (Math.random() - 0.5) * 68;
      this.rainPositions[i * 3 + 1] = Math.random() * 28;
      this.rainPositions[i * 3 + 2] = (Math.random() - 0.5) * 68;
    }
    const rainGeo = new THREE.BufferGeometry();
    rainGeo.setAttribute('position', new THREE.BufferAttribute(this.rainPositions, 3));
    const rainMat = new THREE.PointsMaterial({
      color: 0xcbd5e1,
      size: 0.24,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    });
    this.rainPoints = new THREE.Points(rainGeo, rainMat);
    this.rainPoints.frustumCulled = false;
    scene.add(this.rainPoints);
  }

  public setWeather(next: WeatherCondition, manual = true): void {
    if (next === this.weather) return;
    this.prevWeather = this.weather;
    this.weather = next;
    this.weatherTransition = 0;
    if (manual) {
      this.weatherTimer = 0;
    }
  }

  public setTimePhase(phase: DayTimePhase): void {
    if (phase === 'amanhecer') this.timeOfDay = 0.27;
    else if (phase === 'dia') this.timeOfDay = 0.5;
    else if (phase === 'entardecer') this.timeOfDay = 0.74;
    else this.timeOfDay = 0.02;
  }

  public getTimePhase(): DayTimePhase {
    if (this.timeOfDay >= 0.21 && this.timeOfDay < 0.34) return 'amanhecer';
    if (this.timeOfDay >= 0.34 && this.timeOfDay < 0.68) return 'dia';
    if (this.timeOfDay >= 0.68 && this.timeOfDay < 0.82) return 'entardecer';
    return 'noite';
  }

  public getClockLabel(): string {
    const hoursFloat = this.timeOfDay * 24;
    const hh = Math.floor(hoursFloat) % 24;
    const mm = Math.floor((hoursFloat - Math.floor(hoursFloat)) * 60);
    return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
  }

  public update(dt: number, playerX: number, playerY: number, playerZ: number): WeatherPhysicsModifiers {
    // Full day/night cycle every ~210 seconds when autoDayNight is active
    if (this.autoDayNight) {
      this.timeOfDay = (this.timeOfDay + dt / 210) % 1;
    }

    // Dynamic weather rotation every ~55 seconds when autoWeather is active
    if (this.autoWeather) {
      this.weatherTimer += dt;
      if (this.weatherTimer > 55) {
        this.weatherTimer = 0;
        const order: WeatherCondition[] = ['sol', 'neblina', 'chuva', 'sol'];
        const nextIdx = (order.indexOf(this.weather) + 1) % order.length;
        this.setWeather(order[nextIdx], false);
      }
    }

    if (this.weatherTransition < 1) {
      this.weatherTransition = Math.min(1, this.weatherTransition + dt * 0.25);
    }

    const rainTarget = this.weather === 'chuva' ? 1 : 0;
    const prevRain = this.prevWeather === 'chuva' ? 1 : 0;
    const rainFactor = THREE.MathUtils.lerp(prevRain, rainTarget, this.weatherTransition);

    const fogWeatherTarget = this.weather === 'neblina' ? 1 : 0;
    const prevFogWeather = this.prevWeather === 'neblina' ? 1 : 0;
    const fogFactor = THREE.MathUtils.lerp(prevFogWeather, fogWeatherTarget, this.weatherTransition);

    // Sun orbital angle: 0.25 = horizon east, 0.5 = zenith, 0.75 = horizon west
    const sunAngle = (this.timeOfDay - 0.25) * Math.PI * 2;
    const sunHeight = Math.sin(sunAngle);
    const sunX = Math.cos(sunAngle) * 240;
    const sunY = sunHeight * 240;
    const sunZ = 95;

    // Night factor: 0 during bright day, 1 at deep night
    const nightFactor = THREE.MathUtils.clamp(1 - (sunHeight + 0.12) / 0.42, 0, 1);
    const sunsetFactor = Math.exp(-Math.pow((sunHeight - 0.08) / 0.18, 2));

    // Sun shadow follows player so shadows stay crisp across the 1000x1000 map!
    if (sunHeight > -0.1) {
      this.sunLight.position.set(playerX + sunX * 0.45, Math.max(25, sunY * 0.6), playerZ + sunZ * 0.45);
      this.sunLight.target.position.set(playerX, playerY, playerZ);
    } else {
      // Moonlight from above
      this.sunLight.position.set(playerX - 70, 110, playerZ - 50);
      this.sunLight.target.position.set(playerX, playerY, playerZ);
    }

    this.sunDisc.position.set(playerX + sunX * 2.1, sunY * 2.1, playerZ + sunZ * 2.1);
    (this.sunDisc.material as THREE.MeshBasicMaterial).color.setHex(
      nightFactor > 0.6 ? 0xe2e8f0 : sunsetFactor > 0.45 ? 0xfb923c : 0xfff7cc
    );
    this.sunDisc.visible = sunHeight > -0.05 || nightFactor > 0.55;

    // Sky & Fog Color Palette
    const daySky = new THREE.Color(0x7ec2f8);
    const sunsetSky = new THREE.Color(0xe87b4a);
    const nightSky = new THREE.Color(0x0b1224);
    const stormSky = new THREE.Color(0x475569);
    const mistSky = new THREE.Color(0x94a3b8);

    this.skyColor.copy(daySky).lerp(sunsetSky, sunsetFactor * 0.78).lerp(nightSky, nightFactor);
    this.skyColor.lerp(stormSky, rainFactor * (1 - nightFactor * 0.55) * 0.72);
    this.skyColor.lerp(mistSky, fogFactor * (1 - nightFactor * 0.6) * 0.72);

    this.fogColor.copy(this.skyColor);
    this.fog.color.copy(this.fogColor);

    const baseFog = 0.0014 + nightFactor * 0.0016;
    const weatherFog = rainFactor * 0.0032 + fogFactor * 0.0095;
    this.fog.density = baseFog + weatherFog;

    // Light Intensities
    const weatherDim = 1 - rainFactor * 0.45 - fogFactor * 0.35;
    const sunColor = new THREE.Color(0xfff5e0).lerp(new THREE.Color(0xff8c42), sunsetFactor * 0.7);
    if (nightFactor > 0.7) {
      sunColor.lerp(new THREE.Color(0x93c5fd), (nightFactor - 0.7) / 0.3);
    }
    this.sunLight.color.copy(sunColor);
    this.sunLight.intensity = THREE.MathUtils.lerp(1.95 * weatherDim, 0.35, nightFactor);

    this.hemiLight.color.setHex(nightFactor > 0.5 ? 0x1e293b : 0xa5d8ff);
    this.hemiLight.groundColor.setHex(nightFactor > 0.5 ? 0x0f172a : 0x5c5346);
    this.hemiLight.intensity = THREE.MathUtils.lerp(0.75 * weatherDim, 0.28, nightFactor);

    // Stars visibility
    (this.starsPoints.material as THREE.PointsMaterial).opacity = Math.max(0, nightFactor - rainFactor * 0.8 - fogFactor * 0.8) * 0.85;
    this.starsPoints.position.set(playerX, 0, playerZ);

    // Animate 3D rain streaks around the player
    const rainMat = this.rainPoints.material as THREE.PointsMaterial;
    rainMat.opacity = rainFactor * 0.68;
    this.rainPoints.visible = rainFactor > 0.02;
    if (this.rainPoints.visible) {
      this.rainPoints.position.set(playerX, playerY, playerZ);
      for (let i = 0; i < this.rainCount; i++) {
        this.rainPositions[i * 3 + 1] -= 28 * dt;
        this.rainPositions[i * 3] -= 2.8 * dt;
        if (this.rainPositions[i * 3 + 1] < -1) {
          this.rainPositions[i * 3 + 1] = 26 + Math.random() * 4;
          this.rainPositions[i * 3] = (Math.random() - 0.5) * 68;
          this.rainPositions[i * 3 + 2] = (Math.random() - 0.5) * 68;
        }
      }
      (this.rainPoints.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    }

    // Subtle realistic physics modifiers for each weather condition
    const gripMultiplier = 1 - rainFactor * 0.22 - fogFactor * 0.05;
    const brakeMultiplier = 1 - rainFactor * 0.18 - fogFactor * 0.04;
    const dragMultiplier = 1 + rainFactor * 0.04 + fogFactor * 0.06;
    const wheelieLiftMultiplier = 1 - rainFactor * 0.10;

    return {
      gripMultiplier,
      brakeMultiplier,
      dragMultiplier,
      wheelieLiftMultiplier,
      nightFactor,
      rainFactor,
      fogDensity: this.fog.density,
    };
  }

  public dispose(): void {
    this.rainPoints.geometry.dispose();
    (this.rainPoints.material as THREE.Material).dispose();
    this.starsPoints.geometry.dispose();
    (this.starsPoints.material as THREE.Material).dispose();
    this.sunDisc.geometry.dispose();
    (this.sunDisc.material as THREE.Material).dispose();
  }
}
