import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { World } from './world';
import { getTexture, type TexKey } from './textures';
import type { MapId } from './data/content';

type MatKey = 'concrete' | 'asphalt' | 'brick' | 'facade' | 'facadeDesert' | 'sand' | 'metal' | 'crate' | 'sandbag' | 'rock' | 'tile' | 'roof'
  | 'contRed' | 'contBlue' | 'contGreen' | 'contYellow' | 'olive' | 'line' | 'glass' | 'dark' | 'redLight' | 'wood' | 'white' | 'target' | 'plaster' | 'carRed' | 'carBlue' | 'carGray' | 'leaf';

const MAT_DEF: Record<MatKey, { tex?: TexKey; color: number; rough?: number; metal?: number; emissive?: number; scale?: number }> = {
  concrete: { tex: 'concrete', color: 0xb8b8b4, scale: 4 }, asphalt: { tex: 'asphalt', color: 0xffffff, scale: 6 }, brick: { tex: 'brick', color: 0xffffff, scale: 3 },
  facade: { tex: 'facade', color: 0xffffff, scale: 3.4 }, facadeDesert: { tex: 'facadeDesert', color: 0xffffff, scale: 3.4 }, sand: { tex: 'sand', color: 0xffffff, scale: 8 },
  metal: { tex: 'metal', color: 0xaab0b6, metal: 0.5, rough: 0.5, scale: 3 }, crate: { tex: 'crate', color: 0xffffff, scale: 1.2 }, sandbag: { tex: 'sandbag', color: 0xffffff, scale: 1.6 },
  rock: { tex: 'rock', color: 0xffffff, scale: 5 }, tile: { tex: 'tile', color: 0xffffff, scale: 2 }, roof: { tex: 'roof', color: 0xffffff, scale: 4 },
  contRed: { tex: 'container', color: 0xa33a2a, scale: 3 }, contBlue: { tex: 'container', color: 0x2f5a8a, scale: 3 }, contGreen: { tex: 'container', color: 0x4a6a3a, scale: 3 }, contYellow: { tex: 'container', color: 0xc09030, scale: 3 },
  olive: { tex: 'metal', color: 0x5a6340, scale: 3 }, line: { color: 0xd8c050, emissive: 0.1 }, glass: { color: 0x1a2a38, rough: 0.1, metal: 0.8 }, dark: { color: 0x26282b, rough: 0.6, metal: 0.4 },
  redLight: { color: 0xff2a1a, emissive: 2 }, wood: { tex: 'crate', color: 0x9a7a55, scale: 2 }, white: { color: 0xe8e8e0 }, target: { tex: 'target', color: 0xffffff, scale: 1 },
  plaster: { tex: 'concrete', color: 0xd8c4a0, scale: 4 }, carRed: { color: 0x8a2020, metal: 0.6, rough: 0.35 }, carBlue: { color: 0x203a6a, metal: 0.6, rough: 0.35 }, carGray: { color: 0x6a6e72, metal: 0.6, rough: 0.35 }, leaf: { color: 0x4a6030, rough: 0.9 },
};

export interface TargetSpec { x: number; z: number; kind: 'static' | 'moving' | 'dummy'; minX?: number; maxX?: number; speed?: number }
export interface SkyDef { top: number; bottom: number; fog: number; sunDir: THREE.Vector3; sun: number; sunI: number; amb: number; ambI: number }
export interface MapData {
  id: MapId; world: World; group: THREE.Group; spawns: THREE.Vector3[]; teamSpawns: [THREE.Vector3[], THREE.Vector3[]];
  lootSpots: THREE.Vector3[]; crateSpots: THREE.Vector3[]; patrol: THREE.Vector3[]; targets: TargetSpec[]; sky: SkyDef;
  minimap: HTMLCanvasElement; animate: (t: number) => void; playerStart: THREE.Vector3; size: number; dispose: () => void;
}

class Builder {
  world = new World();
  group = new THREE.Group();
  buckets = new Map<string, THREE.BufferGeometry[]>();
  mats = new Map<MatKey, THREE.Material>();
  lootSpots: THREE.Vector3[] = []; crateSpots: THREE.Vector3[] = [];
  private seed = 1;
  disposables: { dispose: () => void }[] = [];
  constructor(public quality: number, public lowMat: boolean) {}
  rand() { this.seed = (this.seed * 16807) % 2147483647; return (this.seed - 1) / 2147483646; }
  setSeed(s: number) { this.seed = s; }
  mat(k: MatKey) {
    let m = this.mats.get(k);
    if (!m) {
      const d = MAT_DEF[k];
      const map = d.tex ? getTexture(d.tex, this.quality) : null;
      if (this.lowMat && !d.emissive) m = new THREE.MeshLambertMaterial({ color: d.color, map });
      else m = new THREE.MeshStandardMaterial({ color: d.color, map, roughness: d.rough ?? 0.85, metalness: d.metal ?? 0.05, emissive: d.emissive ? d.color : 0, emissiveIntensity: d.emissive ?? 0 });
      this.mats.set(k, m); this.disposables.push(m);
    }
    return m;
  }
  /** Box with bottom at y; world-space UVs so textures tile consistently */
  box(cx: number, y: number, cz: number, w: number, h: number, d: number, mat: MatKey, collide = true, metal = false) {
    const g = new THREE.BoxGeometry(w, h, d);
    const sc = MAT_DEF[mat].scale ?? 4;
    const uv = g.attributes.uv as THREE.BufferAttribute;
    const dims: [number, number][] = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
    for (let f = 0; f < 6; f++) for (let v = 0; v < 4; v++) { const i = f * 4 + v; uv.setXY(i, uv.getX(i) * dims[f][0] / sc, uv.getY(i) * dims[f][1] / sc); }
    g.translate(cx, y + h / 2, cz);
    const key = `${mat}_${Math.floor(cx / 48)}_${Math.floor(cz / 48)}`;
    let arr = this.buckets.get(key); if (!arr) { arr = []; this.buckets.set(key, arr); } arr.push(g);
    if (collide) this.world.addBox(cx - w / 2, y, cz - d / 2, cx + w / 2, y + h, cz + d / 2, metal);
  }
  addMesh(m: THREE.Object3D) { this.group.add(m); }
  finalize(shadows: boolean) {
    for (const [key, geos] of this.buckets) {
      const mk = key.split('_')[0] as MatKey;
      const merged = mergeGeometries(geos, false);
      geos.forEach(g => g.dispose());
      if (!merged) continue;
      merged.computeBoundingSphere();
      const mesh = new THREE.Mesh(merged, this.mat(mk));
      mesh.castShadow = shadows && mk !== 'line' && mk !== 'asphalt'; mesh.receiveShadow = shadows;
      mesh.matrixAutoUpdate = false; mesh.updateMatrix();
      this.group.add(mesh); this.disposables.push(merged);
    }
    this.buckets.clear();
  }

  // ---------- composite helpers ----------
  /** wall along X (axis 'x') or Z with rectangular openings [{at, w, y0, y1}] */
  wall(axis: 'x' | 'z', a0: number, a1: number, fixed: number, y: number, h: number, t: number, mat: MatKey, openings: { at: number; w: number; y0: number; y1: number }[] = []) {
    const segs: [number, number, number, number][] = []; // a0,a1,ybot,ytop
    const ops = openings.slice().sort((p, q) => p.at - q.at);
    let cur = a0;
    for (const o of ops) {
      const s = o.at - o.w / 2, e = o.at + o.w / 2;
      if (s > cur) segs.push([cur, s, 0, h]);
      if (o.y0 > 0) segs.push([s, e, 0, o.y0]);
      if (o.y1 < h) segs.push([s, e, o.y1, h]);
      cur = e;
    }
    if (cur < a1) segs.push([cur, a1, 0, h]);
    for (const [s, e, yb, yt] of segs) {
      if (e - s < 0.01 || yt - yb < 0.01) continue;
      const mid = (s + e) / 2;
      if (axis === 'x') this.box(mid, y + yb, fixed, e - s, yt - yb, t, mat); else this.box(fixed, y + yb, mid, t, yt - yb, e - s, mat);
    }
  }
  slab(x0: number, x1: number, z0: number, z1: number, y: number, th: number, mat: MatKey, hole?: [number, number, number, number]) {
    const add = (a: number, b: number, c: number, d: number) => { if (b - a > 0.05 && d - c > 0.05) this.box((a + b) / 2, y - th, (c + d) / 2, b - a, th, d - c, mat); };
    if (!hole) { add(x0, x1, z0, z1); return; }
    const [hx0, hx1, hz0, hz1] = hole;
    add(x0, hx0, z0, z1); add(hx1, x1, z0, z1); add(hx0, hx1, z0, hz0); add(hx0, hx1, hz1, z1);
  }
  stairs(x: number, z: number, y: number, rise: number, width: number, dirZ: 1 | -1, mat: MatKey, run = 0.5) {
    const n = Math.ceil(rise / 0.34 - 1e-6), r = rise / n;
    for (let i = 0; i < n; i++) this.box(x, y, z + dirZ * (i * run + run / 2), width, (i + 1) * r, run, mat);
    return n * run;
  }
  /** Enterable multi-floor building with doors, windows, internal stairs and optional roof access */
  building(cx: number, cz: number, w: number, d: number, floors: number, base: number, wallMat: MatKey, doors: ('n' | 's' | 'e' | 'w')[], roofAccess = true, floorMat: MatKey = 'tile') {
    const T = 0.3, FH = 3.4;
    const x0 = cx - w / 2, x1 = cx + w / 2, z0 = cz - d / 2, z1 = cz + d / 2;
    const ix0 = x0 + T, ix1 = x1 - T, iz0 = z0 + T, iz1 = z1 - T;
    const flights = floors - 1 + (roofAccess ? 1 : 0);
    const SW = 1.4, RUN = 0.45, stairLen = Math.ceil(FH / 0.34 - 1e-6) * RUN;
    this.box(cx, base - 0.05, cz, w, 0.1, d, floorMat, false);
    for (let f = 0; f < floors; f++) {
      const y = base + f * FH;
      const doorW = 1.8;
      const opsFor = (side: 'n' | 's' | 'e' | 'w', len: number, mid: number) => {
        const sideDoor = side === 'e' || side === 'w';
        if (f === 0) return doors.includes(side) ? [{ at: sideDoor ? mid + len / 2 - T - 1.25 : mid, w: doorW, y0: 0, y1: 2.5 }] : [{ at: mid + (sideDoor ? len * 0.3 : -len * 0.28), w: 1.4, y0: 1.1, y1: 2.2 }];
        return [{ at: mid - len * 0.25, w: 1.5, y0: 1.0, y1: 2.3 }, { at: mid + len * 0.25, w: 1.5, y0: 1.0, y1: 2.3 }];
      };
      this.wall('x', x0, x1, z0 + T / 2, y, FH, T, wallMat, opsFor('n', w, cx));
      this.wall('x', x0, x1, z1 - T / 2, y, FH, T, wallMat, opsFor('s', w, cx));
      this.wall('z', z0 + T, z1 - T, x0 + T / 2, y, FH, T, wallMat, opsFor('w', d, cz));
      this.wall('z', z0 + T, z1 - T, x1 - T / 2, y, FH, T, wallMat, opsFor('e', d, cz));
      this.lootSpots.push(new THREE.Vector3(cx + (this.rand() - 0.5) * w * 0.4, y + 0.05, cz + (this.rand() - 0.5) * d * 0.3));
      // interior cover
      if (w > 9 && this.rand() > 0.3) this.box(cx + (this.rand() - 0.5) * 2, y, cz + (this.rand() > 0.5 ? 1 : -1) * d * 0.15, 1.6, 1.0, 0.8, 'wood');
    }
    // stairs + slabs
    for (let f = 1; f <= floors; f++) {
      const y = base + f * FH;
      const hasFlight = f - 1 < flights;
      const west = (f % 2) === 1;
      const sx = west ? ix0 + SW / 2 : ix1 - SW / 2;
      const sz0 = iz0 + 0.6;
      let hole: [number, number, number, number] | undefined;
      if (hasFlight) {
        this.stairs(sx, sz0, y - FH, FH, SW, 1, 'concrete', RUN);
        hole = [sx - SW / 2, sx + SW / 2, sz0 - 0.1, sz0 + stairLen + 0.1];
      }
      this.slab(f === floors ? x0 : ix0, f === floors ? x1 : ix1, f === floors ? z0 : iz0, f === floors ? z1 : iz1, y, 0.25, f === floors ? 'roof' : floorMat, f < floors || roofAccess ? hole : undefined);
      if (f < floors && hasFlight) { // railing around stair hole edge
        this.box(west ? sx + SW / 2 + 0.05 : sx - SW / 2 - 0.05, y, sz0 + stairLen / 2, 0.08, 1.0, stairLen, 'dark');
      }
    }
    const top = base + floors * FH;
    if (roofAccess) {
      this.wall('x', x0, x1, z0 + 0.1, top, 1.0, 0.2, wallMat); this.wall('x', x0, x1, z1 - 0.1, top, 1.0, 0.2, wallMat);
      this.wall('z', z0 + 0.2, z1 - 0.2, x0 + 0.1, top, 1.0, 0.2, wallMat); this.wall('z', z0 + 0.2, z1 - 0.2, x1 - 0.1, top, 1.0, 0.2, wallMat);
      const west = (floors % 2) === 1; const sx = west ? ix0 + SW / 2 : ix1 - SW / 2;
      this.box(sx + (west ? SW / 2 + 0.05 : -SW / 2 - 0.05), top, iz0 + 0.6 + stairLen / 2, 0.08, 1.0, stairLen, 'dark');
      if (this.rand() > 0.4) this.box(cx + w * 0.2, top, cz + d * 0.2, 1.6, 1.2, 1.2, 'metal', true, true);
      this.lootSpots.push(new THREE.Vector3(cx, top + 0.05, cz + d * 0.25));
    }
  }
  tower(cx: number, cz: number, w: number, d: number, h: number, base: number, mat: MatKey) {
    this.box(cx, base, cz, w, h, d, mat);
    this.box(cx, base + h, cz, w + 0.3, 0.6, d + 0.3, 'concrete', false);
    if (this.rand() > 0.4) this.box(cx + (this.rand() - 0.5) * w * 0.5, base + h + 0.6, cz + (this.rand() - 0.5) * d * 0.5, 2, 1.4, 2, 'metal', false);
  }
  car(cx: number, cz: number, alongX: boolean, base = 0) {
    const mats: MatKey[] = ['carRed', 'carBlue', 'carGray'];
    const m = mats[Math.floor(this.rand() * 3)];
    const L = 4.2, W = 1.9;
    const [w, d] = alongX ? [L, W] : [W, L];
    this.box(cx, base + 0.3, cz, w, 0.75, d, m, true, true);
    this.box(cx, base + 1.05, cz, alongX ? L * 0.55 : W * 0.9, 0.6, alongX ? W * 0.9 : L * 0.55, 'glass', true, true);
    this.box(cx, base, cz, w * 0.9, 0.3, d * 0.9, 'dark', false);
  }
  container(cx: number, cz: number, alongX: boolean, base = 0, stack = 1) {
    const mats: MatKey[] = ['contRed', 'contBlue', 'contGreen', 'contYellow'];
    for (let s = 0; s < stack; s++) {
      const [w, d] = alongX ? [6, 2.5] : [2.5, 6];
      this.box(cx, base + s * 2.6, cz, w, 2.6, d, mats[Math.floor(this.rand() * 4)], true, true);
    }
  }
  sandbags(cx: number, cz: number, len: number, alongX: boolean, base = 0) {
    this.box(cx, base, cz, alongX ? len : 0.9, 1.05, alongX ? 0.9 : len, 'sandbag');
  }
  tree(cx: number, cz: number, base = 0) {
    this.box(cx, base, cz, 0.35, 3, 0.35, 'wood');
    const g = new THREE.IcosahedronGeometry(1.6 + this.rand(), 0); g.translate(cx, base + 3.8, cz);
    const key = `leaf_${Math.floor(cx / 48)}_${Math.floor(cz / 48)}`; let arr = this.buckets.get(key); if (!arr) { arr = []; this.buckets.set(key, arr); } arr.push(g);
  }
}

function skyDome(sky: SkyDef, radius: number) {
  const g = new THREE.SphereGeometry(radius, 24, 12);
  const top = new THREE.Color(sky.top), bot = new THREE.Color(sky.bottom); const cols: number[] = [];
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) { const k = Math.max(0, p.getY(i) / radius); const c = bot.clone().lerp(top, Math.pow(k, 0.6)); cols.push(c.r, c.g, c.b); }
  g.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
  const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false, depthWrite: false }));
  m.renderOrder = -10; m.frustumCulled = false;
  return m;
}

function makeMinimap(world: World): HTMLCanvasElement {
  const S = 256; const c = document.createElement('canvas'); c.width = c.height = S; const ctx = c.getContext('2d')!;
  const { minX, maxX, minZ, maxZ } = world.bounds; const sx = S / (maxX - minX), sz = S / (maxZ - minZ);
  ctx.fillStyle = '#1b2228'; ctx.fillRect(0, 0, S, S);
  if (world.heightFn) {
    for (let j = 0; j < S; j += 4) for (let i = 0; i < S; i += 4) {
      const h = world.heightFn(minX + i / sx, minZ + j / sz); const v = Math.min(255, 40 + h * 9); ctx.fillStyle = `rgb(${v * 0.9},${v * 0.8},${v * 0.6})`; ctx.fillRect(i, j, 4, 4);
    }
  }
  const sorted = world.boxes.slice().sort((a, b) => a.maxY - b.maxY);
  for (const b of sorted) {
    if (b.maxY - b.minY < 0.5 && b.maxY < 1) continue;
    const v = Math.min(220, 70 + b.maxY * 6);
    ctx.fillStyle = `rgb(${v},${v + 8},${v + 14})`;
    ctx.fillRect((b.minX - minX) * sx, (b.minZ - minZ) * sz, Math.max(1, (b.maxX - b.minX) * sx), Math.max(1, (b.maxZ - b.minZ) * sz));
  }
  return c;
}

function walkableSpots(world: World, pts: [number, number][]) {
  return pts.map(([x, z]) => { const p = world.nearestWalkable(x, z); return new THREE.Vector3(p.x, world.ground(p.x, p.z), p.z); });
}
function randomPatrol(world: World, n: number, rand: () => number) {
  const out: THREE.Vector3[] = []; const { minX, maxX, minZ, maxZ } = world.bounds;
  for (let i = 0; i < n * 4 && out.length < n; i++) {
    const x = minX + 6 + rand() * (maxX - minX - 12), z = minZ + 6 + rand() * (maxZ - minZ - 12);
    if (world.walkable(x, z)) out.push(new THREE.Vector3(x, world.ground(x, z), z));
  }
  return out;
}

// =====================================================================
// MAP 1: IRON DISTRICT
// =====================================================================
function buildIron(b: Builder): Partial<MapData> {
  const w = b.world; const H = 84; w.bounds = { minX: -H, maxX: H, minZ: -H, maxZ: H }; b.setSeed(1337);
  // ground: asphalt roads + concrete sidewalks/blocks (visual only)
  b.box(0, -0.5, 0, H * 2, 0.5, H * 2, 'concrete', false);
  const roads = [-42, 0, 42];
  for (const r of roads) { b.box(r, -0.48, 0, 11, 0.5, H * 2, 'asphalt', false); b.box(0, -0.47, r, H * 2, 0.5, 11, 'asphalt', false); }
  for (const r of roads) for (let s = -H; s < H; s += 6) { b.box(r, 0.02, s, 0.2, 0.01, 2.5, 'line', false); b.box(s, 0.02, r, 2.5, 0.01, 0.2, 'line', false); }
  // perimeter: tall boundary buildings
  for (let s = -H; s < H; s += 14) {
    const h1 = 14 + b.rand() * 16, h2 = 14 + b.rand() * 16, h3 = 14 + b.rand() * 16, h4 = 14 + b.rand() * 16;
    b.box(s + 7, 0, -H - 3, 14, h1, 6, 'facade'); b.box(s + 7, 0, H + 3, 14, h2, 6, 'facade');
    b.box(-H - 3, 0, s + 7, 6, h3, 14, 'facade'); b.box(H + 3, 0, s + 7, 6, h4, 14, 'facade');
  }
  // central monument roundabout (landmark)
  b.box(0, 0, 0, 7, 0.6, 7, 'concrete'); b.box(0, 0.6, 0, 2.4, 3, 2.4, 'concrete'); b.box(0, 3.6, 0, 1.2, 4, 1.2, 'metal', true, true);
  b.box(0, 7.6, 0, 2.6, 0.5, 0.6, 'metal', false);
  // blocks
  const spans: [number, number][] = [[-H + 1, -48], [-36, -6], [6, 36], [48, H - 1]];
  const types = ['A', 'B', 'C', 'A', 'D', 'A', 'B', 'A', 'A', 'B', 'A', 'D', 'B', 'A', 'C', 'A'];
  let k = 0;
  for (const [x0, x1] of spans) for (const [z0, z1] of spans) {
    const t = types[k++]; const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, bw = x1 - x0, bd = z1 - z0;
    b.box(cx, 0, cz, bw, 0.15, bd, 'concrete', false); // raised sidewalk visual
    if (t === 'A') {
      const doors: ('n' | 's' | 'e' | 'w')[] = ['n', 's', b.rand() > 0.5 ? 'e' : 'w'];
      b.building(cx - bw * 0.15, cz, Math.min(16, bw * 0.55), Math.min(14, bd * 0.5), b.rand() > 0.5 ? 3 : 2, 0, b.rand() > 0.5 ? 'brick' : 'facade', doors);
      b.tower(cx + bw * 0.33, cz - bd * 0.25, bw * 0.24, bd * 0.35, 12 + b.rand() * 14, 0, 'facade');
      b.box(cx + bw * 0.33, 0, cz + bd * 0.3, 1.6, 1.4, 2.4, 'contGreen', true, true); // dumpster
      b.box(cx + bw * 0.25, 0, cz + bd * 0.12, 1.2, 1.1, 1.2, 'crate');
      b.crateSpots.push(new THREE.Vector3(cx + bw * 0.3, 0, cz + bd * 0.05));
    } else if (t === 'B') {
      const gap = 4;
      b.tower(cx - bw / 4 - gap / 4, cz - bd / 4 - gap / 4, bw / 2 - gap, bd / 2 - gap, 18 + b.rand() * 18, 0, 'facade');
      b.tower(cx + bw / 4 + gap / 4, cz - bd / 4 - gap / 4, bw / 2 - gap, bd / 2 - gap, 10 + b.rand() * 10, 0, 'brick');
      b.tower(cx - bw / 4 - gap / 4, cz + bd / 4 + gap / 4, bw / 2 - gap, bd / 2 - gap, 12 + b.rand() * 12, 0, 'brick');
      b.building(cx + bw / 4 + gap / 4, cz + bd / 4 + gap / 4, bw / 2 - gap, bd / 2 - gap, 2, 0, 'facade', ['n', 'w']);
      b.box(cx, 0, cz, 1.5, 1.3, 2.5, 'contBlue', true, true);
      b.crateSpots.push(new THREE.Vector3(cx + 2, 0, cz - 2));
    } else if (t === 'C') { // park / plaza
      for (let i = 0; i < 6; i++) b.tree(cx + (b.rand() - 0.5) * bw * 0.8, cz + (b.rand() - 0.5) * bd * 0.8);
      b.box(cx, 0, cz, 6, 0.8, 6, 'concrete'); b.box(cx, 0.8, cz, 1, 2.5, 1, 'metal', true, true);
      b.box(cx - bw * 0.3, 0, cz, 0.6, 1.1, bd * 0.4, 'concrete'); b.box(cx + bw * 0.3, 0, cz, 0.6, 1.1, bd * 0.4, 'concrete');
      b.box(cx, 0, cz - bd * 0.32, bw * 0.4, 1.1, 0.6, 'concrete');
      b.crateSpots.push(new THREE.Vector3(cx + 4, 0, cz + 4)); b.lootSpots.push(new THREE.Vector3(cx - 4, 0, cz - 4));
    } else { // parking with containers
      for (let i = 0; i < 4; i++) b.container(cx - bw * 0.3 + i * bw * 0.2, cz - bd * 0.2 + (i % 2) * bd * 0.35, false, 0, i === 1 ? 2 : 1);
      for (let i = 0; i < 3; i++) b.car(cx - bw * 0.25 + i * bw * 0.25, cz + bd * 0.33, true);
      b.crateSpots.push(new THREE.Vector3(cx, 0, cz)); b.lootSpots.push(new THREE.Vector3(cx + 3, 0, cz - 6));
    }
  }
  // street clutter: cars & barriers
  for (const r of roads) for (let i = 0; i < 6; i++) {
    const s = -H + 12 + b.rand() * (H * 2 - 24); if (Math.abs(s) < 8 || roads.some(q => Math.abs(q - s) < 7)) continue;
    if (b.rand() > 0.5) b.car(r + (b.rand() > 0.5 ? 2.5 : -2.5), s, false); else b.car(s, r + (b.rand() > 0.5 ? 2.5 : -2.5), true);
  }
  for (const rx of roads) for (const rz of roads) if (rx || rz) { b.box(rx + 4, 0, rz + 4, 2.6, 1.0, 0.6, 'concrete'); b.box(rx - 4, 0, rz - 4, 0.6, 1.0, 2.6, 'concrete'); b.lootSpots.push(new THREE.Vector3(rx + 3, 0, rz - 3)); }
  // radio tower landmark
  const tx = 60, tz = 60;
  for (const [dx, dz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) b.box(tx + dx * 1.3, 0, tz + dz * 1.3, 0.3, 34, 0.3, 'metal', true, true);
  for (let y = 4; y < 34; y += 5) b.box(tx, y, tz, 2.9, 0.2, 2.9, 'metal', false);
  b.box(tx, 34, tz, 0.5, 0.5, 0.5, 'redLight', false);
  const spawns: [number, number][] = [];
  for (const r of roads) for (let s = -70; s <= 70; s += 20) { spawns.push([r, s]); spawns.push([s, r]); }
  return {
    spawns: [] as THREE.Vector3[], _spawnPts: spawns,
    _team: [[[-60, 72], [-20, 72], [20, 72], [60, 72], [0, 64], [-42, 60], [42, 60]], [[-60, -72], [-20, -72], [20, -72], [60, -72], [0, -64], [-42, -60], [42, -60]]],
    _start: [0, 30],
    sky: { top: 0x3a4a62, bottom: 0xc09a7a, fog: 0x8a8a90, sunDir: new THREE.Vector3(-0.6, 0.45, -0.5).normalize(), sun: 0xffc89a, sunI: 2.2, amb: 0x8090b0, ambI: 0.9 },
  } as unknown as Partial<MapData>;
}

// =====================================================================
// MAP 2: DUST FRONTIER
// =====================================================================
function buildDust(b: Builder): Partial<MapData> {
  const w = b.world; const H = 120; w.bounds = { minX: -H, maxX: H, minZ: -H, maxZ: H }; b.setSeed(4242);
  const zones = [{ x: -60, z: -55, r: 40, h: 0 }, { x: 55, z: 50, r: 34, h: 0 }, { x: 62, z: -60, r: 20, h: 9 }, { x: -55, z: 60, r: 26, h: 0 }, { x: 0, z: 0, r: 18, h: 0 }];
  const roads: [number, number, number, number][] = [[-60, -55, 0, 0], [0, 0, 55, 50], [-55, 60, 0, 0], [0, 0, 62, -60]];
  const segDist = (x: number, z: number, s: [number, number, number, number]) => { const [ax, az, bx, bz] = s; const vx = bx - ax, vz = bz - az; const t = Math.max(0, Math.min(1, ((x - ax) * vx + (z - az) * vz) / (vx * vx + vz * vz))); return Math.hypot(x - ax - vx * t, z - az - vz * t); };
  const sstep = (a: number, bb: number, x: number) => { const t = Math.max(0, Math.min(1, (x - a) / (bb - a))); return t * t * (3 - 2 * t); };
  const raw = (x: number, z: number) => 4.5 + Math.sin(x * 0.035) * Math.cos(z * 0.03) * 5 + Math.sin(x * 0.08 + 2) * Math.sin(z * 0.07 + 1) * 2 + Math.max(0, Math.abs(x) - 90) * 0.35 + Math.max(0, Math.abs(z) - 90) * 0.35;
  const heightFn = (x: number, z: number) => {
    let h = raw(x, z);
    for (const zn of zones) { const m = sstep(zn.r, zn.r + 16, Math.hypot(x - zn.x, z - zn.z)); h = zn.h + (h - zn.h) * m; }
    let rd = Infinity; for (const s of roads) rd = Math.min(rd, segDist(x, z, s));
    const rm = sstep(4, 12, rd); const roadH = raw(x, z) * 0.35; h = roadH + (h - roadH) * rm;
    return Math.max(0, h);
  };
  w.heightFn = heightFn;
  // terrain mesh with vertex colours
  const seg = b.quality === 0 ? 80 : 120;
  const tg = new THREE.PlaneGeometry(H * 2, H * 2, seg, seg); tg.rotateX(-Math.PI / 2);
  const pos = tg.attributes.position; const cols: number[] = []; const uv = tg.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i); const y = heightFn(x, z); pos.setY(i, y);
    let rd = Infinity; for (const s of roads) rd = Math.min(rd, segDist(x, z, s));
    const road = rd < 4.5 ? 1 : 0; const shade = 0.85 + Math.sin(x * 0.3) * Math.cos(z * 0.27) * 0.05 + y * 0.012;
    if (road) cols.push(0.42, 0.38, 0.33); else cols.push(shade, shade * 0.93, shade * 0.82);
    uv.setXY(i, x / 8, z / 8);
  }
  tg.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3)); tg.computeVertexNormals();
  const tm = b.lowMat ? new THREE.MeshLambertMaterial({ map: getTexture('sand', b.quality), vertexColors: true }) : new THREE.MeshStandardMaterial({ map: getTexture('sand', b.quality), vertexColors: true, roughness: 0.95 });
  const terrain = new THREE.Mesh(tg, tm); terrain.receiveShadow = true; b.addMesh(terrain); b.disposables.push(tg, tm);
  const gy = (x: number, z: number) => heightFn(x, z);

  // --- Military base (NW) ---
  const bx = -60, bz = -55, S = 28;
  for (const side of [-1, 1]) {
    b.wall('x', bx - S, bx + S, bz + side * S, 0, 3, 0.6, 'concrete', [{ at: bx, w: 8, y0: 0, y1: 3 }]);
    b.wall('z', bz - S, bz + S, bx + side * S, 0, 3, 0.6, 'concrete', [{ at: bz, w: 8, y0: 0, y1: 3 }]);
  }
  // warehouses (big single floor, wide doors)
  for (const [wx, wz] of [[-72, -64], [-48, -64]]) {
    const ww = 16, wd = 12, wh = 6.5;
    b.wall('x', wx - ww / 2, wx + ww / 2, wz - wd / 2, 0, wh, 0.35, 'metal', [{ at: wx, w: 4.5, y0: 0, y1: 4.2 }]);
    b.wall('x', wx - ww / 2, wx + ww / 2, wz + wd / 2, 0, wh, 0.35, 'metal', [{ at: wx, w: 4.5, y0: 0, y1: 4.2 }]);
    b.wall('z', wz - wd / 2, wz + wd / 2, wx - ww / 2, 0, wh, 0.35, 'metal', [{ at: wz, w: 2, y0: 0, y1: 2.5 }]);
    b.wall('z', wz - wd / 2, wz + wd / 2, wx + ww / 2, 0, wh, 0.35, 'metal');
    b.box(wx, wh, wz, ww + 0.6, 0.3, wd + 0.6, 'roof');
    b.box(wx - 4, 0, wz - 2, 2.4, 1.6, 1.2, 'crate'); b.box(wx + 4, 0, wz + 2, 1.2, 2.4, 1.2, 'crate'); b.box(wx + 3, 0, wz - 3, 1.2, 1.2, 1.2, 'crate');
    b.lootSpots.push(new THREE.Vector3(wx, 0, wz)); b.crateSpots.push(new THREE.Vector3(wx - 5, 0, wz + 3));
  }
  b.building(-58, -42, 12, 9, 2, 0, 'plaster', ['s', 'e'], true, 'concrete'); // barracks / HQ
  // watchtowers with stairs
  for (const [tx, tz] of [[bx - S + 3, bz - S + 3], [bx + S - 3, bz + S - 3]]) {
    for (const [dx, dz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) b.box(tx + dx * 1.4, 0, tz + dz * 1.4, 0.3, 5, 0.3, 'wood');
    b.box(tx, 5, tz, 3.4, 0.25, 3.4, 'wood');
    b.wall('x', tx - 1.7, tx + 1.7, tz + 1.6, 5.25, 1.1, 0.15, 'sandbag'); b.wall('z', tz - 1.5, tz + 1.5, tx + 1.6, 5.25, 1.1, 0.15, 'sandbag');
    b.box(tx, 7.4, tz, 3.8, 0.2, 3.8, 'roof', false);
    b.stairs(tx, tz - 1.7 - 16 * 0.5, 0, 5.25, 1.2, 1, 'wood'); // 16 steps from -z side ending at platform edge
    b.lootSpots.push(new THREE.Vector3(tx, 5.3, tz));
  }
  for (let i = 0; i < 5; i++) b.container(bx + 10 + (i % 3) * 3.2, bz + 8 + Math.floor(i / 3) * 7, false, 0, i === 1 ? 2 : 1);
  b.sandbags(bx, bz + S + 4, 6, true); b.sandbags(bx + S + 4, bz, 6, false); b.sandbags(bx - 6, bz + 2, 5, true); b.sandbags(bx + 2, bz - 8, 5, false);
  b.box(bx - 12, 0.01, bz + 14, 9, 0.05, 9, 'concrete', false); // helipad
  b.crateSpots.push(new THREE.Vector3(bx - 12, 0, bz + 14), new THREE.Vector3(bx + 5, 0, bz - 2));

  // --- Village (SE) ---
  const houses: [number, number, number, number, number][] = [[45, 40, 9, 8, 2], [62, 38, 8, 8, 1], [44, 58, 10, 8, 2], [63, 60, 9, 9, 2], [54, 49, 7, 7, 1], [72, 48, 8, 7, 1]];
  for (const [hx, hz, hw, hd, fl] of houses) b.building(hx, hz, hw, hd, fl, 0, 'facadeDesert', ['n', 's'], true, 'tile');
  b.wall('x', 36, 52, 70, 0, 2, 0.4, 'plaster', [{ at: 44, w: 3, y0: 0, y1: 2 }]); b.wall('z', 30, 46, 80, 0, 2, 0.4, 'plaster');
  for (let i = 0; i < 3; i++) { b.box(52 + i * 3, 0, 32, 2.2, 0.9, 1.2, 'wood'); b.box(52 + i * 3, 2.2, 32, 2.6, 0.08, 1.8, 'contRed', false); }
  b.crateSpots.push(new THREE.Vector3(54, 0, 44), new THREE.Vector3(68, 0, 54));

  // --- Radar station on plateau (NE) ---
  const ry = 9;
  b.building(60, -58, 10, 8, 1, ry, 'concrete', ['w', 's'], true, 'concrete');
  b.box(70, ry, -66, 1, 6, 1, 'metal', true, true);
  const dish = new THREE.Group(); dish.position.set(70, ry + 6.5, -66);
  const dm = new THREE.Mesh(new THREE.SphereGeometry(3, 16, 8, 0, Math.PI * 2, 0, Math.PI / 3.5), new THREE.MeshStandardMaterial({ color: 0xd8d8d0, side: THREE.DoubleSide, metalness: 0.4, roughness: 0.5 }));
  dm.rotation.x = Math.PI / 2.4; dish.add(dm); b.addMesh(dish); b.disposables.push(dm.geometry, dm.material as THREE.Material);
  b.sandbags(52, -48, 6, true, ry); b.sandbags(72, -52, 5, false, ry);
  b.crateSpots.push(new THREE.Vector3(56, ry, -50));

  // --- Fuel depot (SW) ---
  const tankMat = b.lowMat ? new THREE.MeshLambertMaterial({ color: 0xc8c4b8 }) : new THREE.MeshStandardMaterial({ color: 0xc8c4b8, metalness: 0.5, roughness: 0.45 });
  b.disposables.push(tankMat);
  for (const [fx, fz] of [[-64, 54], [-50, 54], [-64, 68], [-50, 68]]) {
    const tg2 = new THREE.CylinderGeometry(4, 4, 7, 20); const t = new THREE.Mesh(tg2, tankMat); t.position.set(fx, 3.5, fz); t.castShadow = t.receiveShadow = true; b.addMesh(t); b.disposables.push(tg2);
    w.addBox(fx - 3.6, 0, fz - 3.6, fx + 3.6, 7, fz + 3.6, true);
  }
  b.box(-57, 1.2, 61, 20, 0.4, 0.4, 'metal', false); b.box(-57, 0, 61, 1.5, 1.5, 1.5, 'metal', true, true);
  b.building(-40, 70, 9, 8, 1, 0, 'plaster', ['w', 'n'], true, 'concrete');
  b.container(-44, 50, true, 0, 2); b.container(-70, 44, false, 0, 1);
  b.crateSpots.push(new THREE.Vector3(-57, 0, 46));

  // --- Central checkpoint ---
  b.building(6, -5, 6, 5, 1, 0, 'concrete', ['w', 'n'], true, 'concrete');
  b.box(-3, 0, 4, 6, 1, 0.6, 'concrete'); b.box(4, 0, 6, 0.6, 1, 4, 'concrete'); b.sandbags(-6, -6, 4, false); b.sandbags(-2, -9, 4, true);
  // destroyed tank
  b.box(-8, 0, 10, 3.4, 1.3, 6.5, 'olive', true, true); b.box(-8, 1.3, 9.6, 2.4, 0.9, 2.6, 'olive', true, true); b.box(-8, 1.7, 6.4, 0.25, 0.25, 4, 'dark', false);
  b.crateSpots.push(new THREE.Vector3(2, 0, 4));
  // scattered rocks and cover
  for (let i = 0; i < 70; i++) {
    const x = -110 + b.rand() * 220, z = -110 + b.rand() * 220;
    if (zones.some(zn => Math.hypot(x - zn.x, z - zn.z) < zn.r + 4) || roads.some(s => segDist(x, z, s) < 6)) continue;
    const s = 1 + b.rand() * 3.2; const y = gy(x, z) - 0.4;
    b.box(x, y, z, s * (0.8 + b.rand() * 0.6), s * (0.6 + b.rand() * 0.8), s * (0.8 + b.rand() * 0.6), 'rock');
    if (i % 9 === 0) b.lootSpots.push(new THREE.Vector3(x + s + 1, gy(x + s + 1, z), z));
  }
  for (let i = 0; i < 10; i++) { const x = -100 + b.rand() * 200, z = -100 + b.rand() * 200; if (!zones.some(zn => Math.hypot(x - zn.x, z - zn.z) < zn.r + 2)) b.sandbags(x, z, 4, b.rand() > 0.5, gy(x, z) - 0.1); }
  return {
    _spawnPts: [[-60, -30], [-30, -28], [0, -20], [25, 25], [40, 70], [80, 30], [62, -40], [-40, 40], [-80, 20], [20, -80], [-20, 90], [90, -10], [-90, -90], [95, 95], [0, 40], [-95, 0]],
    _team: [[[-60, -45], [-66, -40], [-52, -48], [-62, -60], [-55, -35], [-70, -50], [-50, -55]], [[55, 48], [60, 45], [50, 54], [58, 66], [66, 52], [48, 44], [62, 40]]],
    _start: [0, 15],
    sky: { top: 0x4a7ab8, bottom: 0xe8d4b0, fog: 0xd8c8a8, sunDir: new THREE.Vector3(0.5, 0.8, 0.3).normalize(), sun: 0xfff0d8, sunI: 2.8, amb: 0xa0b0c8, ambI: 1.0 },
  } as unknown as Partial<MapData>;
}

// =====================================================================
// PRACTICE RANGE
// =====================================================================
function buildRange(b: Builder): Partial<MapData> {
  const w = b.world; w.bounds = { minX: -30, maxX: 30, minZ: -140, maxZ: 20 }; b.setSeed(7);
  b.box(0, -0.5, -60, 60, 0.5, 160, 'concrete', false);
  b.box(0, -0.48, -70, 50, 0.5, 130, 'sand', false);
  b.wall('z', -140, 20, -30, 0, 6, 1, 'concrete'); b.wall('z', -140, 20, 30, 0, 6, 1, 'concrete');
  b.wall('x', -30, 30, 20, 0, 6, 1, 'concrete'); b.box(0, 0, -140, 60, 14, 2, 'concrete');
  b.box(0, 0, -137, 56, 8, 3, 'sandbag', false);
  // firing line counter with gaps
  for (const x of [-22, -11, 0, 11, 22]) b.box(x, 0, 0, 8, 1.05, 0.6, 'wood');
  b.box(0, 4, 4, 60, 0.3, 10, 'roof', false);
  for (const x of [-27, 27]) b.box(x, 0, 4, 0.4, 4, 0.4, 'metal', false);
  // lane dividers
  for (const x of [-16, -5.5, 5.5, 16]) b.box(x, 0, -12, 0.3, 1.2, 10, 'concrete');
  // distance boards
  for (const d of [10, 25, 50, 75, 100, 120]) b.box(-28, 0, -d, 0.4, 2.4, 3, 'white', false);
  // CQB walls for cover practice
  b.box(-20, 0, -40, 6, 2.5, 0.5, 'concrete'); b.box(20, 0, -40, 6, 2.5, 0.5, 'concrete'); b.box(0, 0, -62, 8, 1.2, 0.6, 'sandbag');
  b.box(-24, 0, 12, 4, 0.9, 1.5, 'dark'); b.box(24, 0, 12, 4, 0.9, 1.5, 'dark'); // weapon tables
  const targets: TargetSpec[] = [];
  for (const [x, d] of [[-22, 10], [-11, 15], [0, 10], [11, 15], [22, 10]] as [number, number][]) targets.push({ x, z: -d, kind: 'dummy' });
  for (const [x, d] of [[-20, 25], [-6, 35], [8, 50], [18, 75], [-12, 100], [4, 120]] as [number, number][]) targets.push({ x, z: -d, kind: 'static' });
  targets.push({ x: 0, z: -30, kind: 'moving', minX: -14, maxX: 14, speed: 3.5 });
  targets.push({ x: 0, z: -55, kind: 'moving', minX: -20, maxX: 20, speed: 5 });
  targets.push({ x: 0, z: -85, kind: 'moving', minX: -18, maxX: 18, speed: 4 });
  return {
    targets, _spawnPts: [[0, 8]], _team: [[[0, 8]], [[0, -100]]], _start: [0, 8],
    sky: { top: 0x587aa8, bottom: 0xd8d0c0, fog: 0xc8c8c0, sunDir: new THREE.Vector3(0.3, 0.9, 0.4).normalize(), sun: 0xffffff, sunI: 2.4, amb: 0xb0c0d0, ambI: 1.1 },
  } as unknown as Partial<MapData>;
}

export function buildMap(id: MapId, quality: { textures: number; shadows: boolean; lowMat: boolean }): MapData {
  const b = new Builder(quality.textures, quality.lowMat);
  const partial = (id === 'iron' ? buildIron(b) : id === 'dust' ? buildDust(b) : buildRange(b)) as Partial<MapData> & { _spawnPts: [number, number][]; _team: [[number, number][], [number, number][]]; _start: [number, number] };
  b.finalize(quality.shadows);
  const world = b.world;
  world.buildNav(1);
  const sky = partial.sky!;
  const size = world.bounds.maxX - world.bounds.minX;
  const dome = skyDome(sky, 600); b.group.add(dome); b.disposables.push(dome.material as THREE.Material);
  const spawns = walkableSpots(world, partial._spawnPts);
  const teamSpawns: [THREE.Vector3[], THREE.Vector3[]] = [walkableSpots(world, partial._team[0]), walkableSpots(world, partial._team[1])];
  const [sx, sz] = partial._start; const st = world.nearestWalkable(sx, sz);
  const playerStart = new THREE.Vector3(st.x, world.ground(st.x, st.z), st.z);
  let rs = 99; const rand = () => { rs = (rs * 16807) % 2147483647; return (rs - 1) / 2147483646; };
  const patrol = randomPatrol(world, 40, rand);
  // animated landmarks
  const redLights: THREE.Mesh[] = []; let dish: THREE.Object3D | null = null;
  b.group.traverse(o => { if ((o as THREE.Mesh).isMesh && ((o as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity === 2) redLights.push(o as THREE.Mesh); });
  if (id === 'dust') dish = b.group.children.find(c => c.type === 'Group') ?? null;
  const animate = (t: number) => {
    for (const r of redLights) { const m = r.material as THREE.MeshStandardMaterial; m.emissiveIntensity = Math.sin(t * 4) > 0 ? 2 : 0.2; }
    if (dish) dish.rotation.y = t * 0.4;
  };
  return {
    id, world, group: b.group, spawns: spawns.length ? spawns : [playerStart], teamSpawns, lootSpots: b.lootSpots, crateSpots: b.crateSpots,
    patrol, targets: partial.targets ?? [], sky, minimap: makeMinimap(world), animate, playerStart, size,
    dispose: () => { b.disposables.forEach(d => d.dispose()); b.group.traverse(o => { if ((o as THREE.Mesh).isMesh && !(o as THREE.Mesh).geometry.userData.keep) (o as THREE.Mesh).geometry.dispose(); }); },
  };
}
