import type { TexName } from './textures';
import desertImg from '../assets/desert.jpg';
import snowImg from '../assets/snow.jpg';
import castleImg from '../assets/castle.jpg';
import mazeImg from '../assets/maze.jpg';
import ruinsImg from '../assets/ruins.jpg';

export interface MapTheme {
  floor: TexName;
  wall: TexName;
  tall: TexName;
  low: TexName;
  skyTop: string;
  skyBottom: string;
  fog: string;
  fogNear: number;
  fogFar: number;
  sun: string;
  sunI: number;
  hemiSky: string;
  hemiGround: string;
  hemiI: number;
  wallH: number;
  tallH: number;
  snow?: boolean;
  dust?: boolean;
}

export interface MapDef {
  id: string;
  name: string;
  en: string;
  img: string;
  desc: string;
  grid: string[];
  theme: MapTheme;
}

export const CELL = 3;

export const MAPS: MapDef[] = [
  {
    id: 'desert', name: 'صحرای داست', en: 'DUST', img: desertImg, desc: 'نقشه کلاسیک صحرایی با کوچه‌های تنگ و جعبه‌های چوبی',
    grid: [
      'PPP...#.........#.......',
      'P.....#..c......#.......',
      '......#..cC.....c.......',
      '..cc.......w............',
      '..c.....###.....###.....',
      '####....#........c#..cc.',
      '....#...#..C......#..c..',
      '....#......C............',
      '.ww.####..........ww....',
      '..........c..###........',
      '......c...cc............',
      '..###.............C.....',
      '....#...ww....###.c.....',
      '....#.........#.........',
      '.c...........c#..###....',
      '.cc.###.......#....#....',
      '.......#...C.......#....',
      '.......#...cc...........',
      '###........c....c...####',
      '......###......cc.......',
      '...c.........##......TT.',
      '.....c....#.........TTTT',
    ],
    theme: {
      floor: 'sand', wall: 'sandstone', tall: 'plaster', low: 'sandstone',
      skyTop: '#3f7fd6', skyBottom: '#d6e6f3', fog: '#e0cfaa', fogNear: 30, fogFar: 140,
      sun: '#fff0d0', sunI: 2.6, hemiSky: '#cfe2ff', hemiGround: '#a8834f', hemiI: 1.1, wallH: 5, tallH: 9, dust: true,
    },
  },
  {
    id: 'snow', name: 'نیوک برفی', en: 'SNOW NUKE', img: snowImg, desc: 'پایگاه نظامی یخ‌زده با کانتینرهای فلزی',
    grid: [
      'PP.....kk.......kk.....',
      'PP.....kk...c...kk.....',
      '.......................',
      '..####.....###.....##..',
      '..#..........#......#..',
      '..#..c...kk..#..c...#..',
      '.....c...kk............',
      '.......................',
      '.kk....###.....###....kk',
      '.kk.....c.......c.....kk',
      '........................',
      '...#####....kk....####..',
      '...#........kk.......#..',
      '...#..c..........c...#..',
      '........................',
      '..kk.....###.###....kk..',
      '..kk..c.............kk..',
      '........c.....c.........',
      '.....###.........###....',
      'TT......kk...kk.......TT',
      'TT......kk...kk.......TT',
    ],
    theme: {
      floor: 'snow', wall: 'snowWall', tall: 'concrete', low: 'snowWall',
      skyTop: '#73859c', skyBottom: '#dfe6ee', fog: '#d4dde7', fogNear: 20, fogFar: 110,
      sun: '#eaf2ff', sunI: 1.8, hemiSky: '#e2ecff', hemiGround: '#9aa6b4', hemiI: 1.4, wallH: 5, tallH: 9, snow: true,
    },
  },
  {
    id: 'castle', name: 'قلعه باستانی', en: 'CASTLE', img: castleImg, desc: 'قلعه سنگی قرون وسطی – مخصوص حالت زامبی',
    grid: [
      'XX#######XXX#######XX',
      'X...................X',
      '#..ww.....c.....ww..#',
      '#...................#',
      '#....XX.......XX....#',
      '#....XX...P...XX....#',
      '#.........PP........#',
      '#..c.....PPP.....c..#',
      '#.........w.........#',
      '#....XX.......XX....#',
      '#....XX.......XX....#',
      '#...................#',
      '#..ww.....c.....ww..#',
      'X...................X',
      'XX###...........###XX',
      '.....T....T....T.....',
      'TTTTTTTTTTTTTTTTTTTTT',
    ],
    theme: {
      floor: 'grass', wall: 'stone', tall: 'stone', low: 'stone',
      skyTop: '#2f6bc6', skyBottom: '#c2dbf4', fog: '#bcd0e0', fogNear: 35, fogFar: 150,
      sun: '#fff6e0', sunI: 2.4, hemiSky: '#cfe0ff', hemiGround: '#55703a', hemiI: 1.1, wallH: 6, tallH: 10,
    },
  },
  {
    id: 'maze', name: 'هزارتوی تاریک', en: 'MAZE', img: mazeImg, desc: 'انبار زیرزمینی پرپیچ‌وخم – نبرد نزدیک',
    grid: [
      'P.#.....#.......#......',
      'P.#.###.#.#####.#.####.',
      '..#...#...#.....#....#.',
      '.####.#####.###.####.#.',
      '......#.....#c#......#.',
      '.####.#.#####.#.######.',
      '.#....#.......#........',
      '.#.####.###c###.######.',
      '.#....#...#.........#..',
      '.####.###.#.#######.#.#',
      '......#...#.#.....#.#..',
      '.######.###.#.###.#.##.',
      '.#........#...#c#.#....',
      '.#.######.#####.#.####.',
      '...#....#.......#....#.',
      '####.##.#.#####.####.#.',
      '.....#..#.#...#......#.',
      '.#####.##.#.#.######.#.',
      '.......#....#.......#.T',
      '.#####.#.##########.#.T',
      '.......#............#TT',
    ],
    theme: {
      floor: 'darkConcrete', wall: 'concrete', tall: 'darkConcrete', low: 'concrete',
      skyTop: '#0d0f13', skyBottom: '#2b2f36', fog: '#1b1d22', fogNear: 8, fogFar: 55,
      sun: '#ffe2b0', sunI: 1.2, hemiSky: '#8a95a8', hemiGround: '#3a3530', hemiI: 1.3, wallH: 4.2, tallH: 6,
    },
  },
  {
    id: 'ruins', name: 'شهر ویران', en: 'RUINS', img: ruinsImg, desc: 'ساختمان‌های آجری مخروبه بعد از جنگ',
    grid: [
      'PP..#....w.....#####....',
      'P...#..c.w.....#...#....',
      '....#..........#.c.w....',
      '.ww.#####..w.......#....',
      '..........##.....###....',
      '..c.......#.......c.....',
      '.###..w...#..ccc........',
      '...#......#.........##..',
      '...#..###...www.....#...',
      '..........#.........#...',
      '.w..c.....#..C...####...',
      '.w......####............',
      '....ww.........w....c...',
      '..#.......c....w........',
      '..#...####.......###....',
      '..#......#..c......#..TT',
      '.........#.........#.TTT',
    ],
    theme: {
      floor: 'tiles', wall: 'brick', tall: 'brick', low: 'brick',
      skyTop: '#7f92ab', skyBottom: '#e8d8bf', fog: '#cdbfa8', fogNear: 20, fogFar: 120,
      sun: '#ffe7c4', sunI: 2.2, hemiSky: '#dfe4ee', hemiGround: '#7a5a44', hemiI: 1.1, wallH: 4.5, tallH: 8, dust: true,
    },
  },
];

export interface Box {
  minX: number; minY: number; minZ: number;
  maxX: number; maxY: number; maxZ: number;
  tex: TexName;
  kind: 'wall' | 'tall' | 'low' | 'crate' | 'container';
}

export interface ParsedMap {
  w: number; h: number;
  boxes: Box[];
  walk: boolean[][];
  ct: { x: number; z: number }[];
  t: { x: number; z: number }[];
  open: { x: number; z: number }[];
}

export function parseMap(def: MapDef): ParsedMap {
  const raw = def.grid;
  const iw = Math.max(...raw.map(r => r.length));
  const w = iw + 2, h = raw.length + 2;
  const grid: string[][] = [];
  for (let z = 0; z < h; z++) {
    const row: string[] = [];
    for (let x = 0; x < w; x++) {
      if (z === 0 || z === h - 1 || x === 0 || x === w - 1) row.push('X');
      else row.push(raw[z - 1][x - 1] ?? '.');
    }
    grid.push(row);
  }
  const th = def.theme;
  const boxes: Box[] = [];
  const walk: boolean[][] = [];
  const ct: { x: number; z: number }[] = [];
  const t: { x: number; z: number }[] = [];
  const open: { x: number; z: number }[] = [];
  for (let z = 0; z < h; z++) {
    walk.push([]);
    for (let x = 0; x < w; x++) {
      const ch = grid[z][x];
      walk[z].push(ch === '.' || ch === 'T' || ch === 'P');
      const cx = x * CELL + CELL / 2, cz = z * CELL + CELL / 2;
      if (ch === 'P') ct.push({ x: cx, z: cz });
      if (ch === 'T') t.push({ x: cx, z: cz });
      if (ch === '.') open.push({ x: cx, z: cz });
    }
  }
  // merge runs for walls
  const runKinds: Record<string, { kind: Box['kind']; hgt: number; tex: TexName }> = {
    '#': { kind: 'wall', hgt: th.wallH, tex: th.wall },
    'X': { kind: 'tall', hgt: th.tallH, tex: th.tall },
    'w': { kind: 'low', hgt: 1.1, tex: th.low },
  };
  for (let z = 0; z < h; z++) {
    let x = 0;
    while (x < w) {
      const ch = grid[z][x];
      const rk = runKinds[ch];
      if (!rk) { x++; continue; }
      let x2 = x;
      while (x2 + 1 < w && grid[z][x2 + 1] === ch) x2++;
      const pad = ch === 'w' ? 0.9 : 0;
      boxes.push({
        minX: x * CELL, maxX: (x2 + 1) * CELL, minY: 0, maxY: rk.hgt,
        minZ: z * CELL + pad, maxZ: (z + 1) * CELL - pad, tex: rk.tex, kind: rk.kind,
      });
      x = x2 + 1;
    }
  }
  // crates & containers
  let seed = 7;
  const rnd = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
  for (let z = 0; z < h; z++) for (let x = 0; x < w; x++) {
    const ch = grid[z][x];
    const cx = x * CELL + CELL / 2, cz = z * CELL + CELL / 2;
    if (ch === 'c' || ch === 'C') {
      const s = 2.0 + rnd() * 0.4;
      const ox = (rnd() - 0.5) * 0.4, oz = (rnd() - 0.5) * 0.4;
      boxes.push({ minX: cx - s / 2 + ox, maxX: cx + s / 2 + ox, minZ: cz - s / 2 + oz, maxZ: cz + s / 2 + oz, minY: 0, maxY: s, tex: 'crate', kind: 'crate' });
      if (ch === 'C') {
        const s2 = 1.6;
        boxes.push({ minX: cx - s2 / 2, maxX: cx + s2 / 2, minZ: cz - s2 / 2, maxZ: cz + s2 / 2, minY: s, maxY: s + s2, tex: 'crate', kind: 'crate' });
      }
    }
    if (ch === 'k') {
      boxes.push({ minX: x * CELL + 0.1, maxX: (x + 1) * CELL - 0.1, minZ: z * CELL + 0.1, maxZ: (z + 1) * CELL - 0.1, minY: 0, maxY: 2.9, tex: (x + z) % 3 === 0 ? 'containerRed' : 'container', kind: 'container' });
    }
  }
  if (!ct.length) ct.push(open[0]);
  if (!t.length) t.push(open[open.length - 1]);
  return { w, h, boxes, walk, ct, t, open };
}
