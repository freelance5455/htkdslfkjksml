import type { Era } from './data';

export interface Rect { x: number; z: number; w: number; h: number }
export interface Circ { x: number; z: number; r: number }
export interface MapDef {
  id: string; n: string; ds: string; pl: number; size: number; eras?: Era[];
  starts: { x: number; z: number }[]; mines: { x: number; z: number; a: number }[];
  water: Rect[]; bridges: Rect[]; rocks: Circ[]; forests: Circ[];
}

function line(x1: number, z1: number, x2: number, z2: number, step: number, r: number, skip?: (t: number, x: number, z: number) => boolean): Circ[] {
  const L = Math.hypot(x2 - x1, z2 - z1); const n = Math.max(1, Math.round(L / step)); const out: Circ[] = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n; const x = x1 + (x2 - x1) * t, z = z1 + (z2 - z1) * t;
    if (skip && skip(t, x, z)) continue; out.push({ x, z, r });
  }
  return out;
}
function arc(cx: number, cz: number, R: number, r: number, skip: (ang: number) => boolean): Circ[] {
  const out: Circ[] = []; const n = Math.round((Math.PI * 2 * R) / (r * 1.9));
  for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2; if (skip(a)) continue; out.push({ x: cx + Math.cos(a) * R, z: cz + Math.sin(a) * R, r }); }
  return out;
}
const M = (x: number) => (x === 0 ? 0 : x);

const RAW: MapDef[] = [
  { id: 'rocks', n: 'وادي الصخور', ds: 'سلسلة صخرية تفصل الجيشين بثلاث ممرات', pl: 2, size: 160,
    starts: [{ x: -56, z: -56 }, { x: 56, z: 56 }],
    mines: [{ x: -22, z: -22, a: 3500 }, { x: 22, z: 22, a: 3500 }, { x: 0, z: 0, a: 5000 }],
    water: [],
    bridges: [],
    rocks: line(-72, 72, 72, -72, 8, 4.5, (t) => Math.abs(t - 0.5) < 0.065 || Math.abs(t - 0.14) < 0.05 || Math.abs(t - 0.86) < 0.05),
    forests: [{ x: -45, z: 12, r: 9 }, { x: 45, z: -12, r: 9 }, { x: 12, z: 45, r: 8 }, { x: -12, z: -45, r: 8 }] },
  { id: 'nile', n: 'النهر العظيم', ds: 'نهر عريض يعبره جسران فقط', pl: 2, size: 170,
    starts: [{ x: -62, z: 0 }, { x: 62, z: 0 }],
    mines: [{ x: -18, z: 0, a: 4000 }, { x: 18, z: 0, a: 4000 }],
    water: [{ x: 0, z: 0, w: 11, h: 190 }],
    bridges: [{ x: 0, z: -38, w: 15, h: 12 }, { x: 0, z: 38, w: 15, h: 12 }],
    rocks: [{ x: -22, z: -22, r: 3.5 }, { x: 22, z: 22, r: 3.5 }, { x: -22, z: 22, r: 3.5 }, { x: 22, z: -22, r: 3.5 }],
    forests: [{ x: -32, z: -52, r: 10 }, { x: 32, z: 52, r: 10 }, { x: -32, z: 52, r: 10 }, { x: 32, z: -52, r: 10 }] },
  { id: 'delta', n: 'الدلتا', ds: 'قنوات مائية وجزيرة وسطى', pl: 2, size: 170, eras: ['anc'],
    starts: [{ x: 0, z: -66 }, { x: 0, z: 66 }],
    mines: [{ x: -26, z: 0, a: 4500 }, { x: 26, z: 0, a: 4500 }],
    water: [{ x: 0, z: -26, w: 190, h: 7 }, { x: 0, z: 26, w: 190, h: 7 }],
    bridges: [{ x: -38, z: -26, w: 12, h: 15 }, { x: 38, z: -26, w: 12, h: 15 }, { x: -38, z: 26, w: 12, h: 15 }, { x: 38, z: 26, w: 12, h: 15 }],
    rocks: [{ x: 0, z: 0, r: 5 }],
    forests: [{ x: -55, z: -40, r: 9 }, { x: 55, z: 40, r: 9 }, { x: 55, z: -40, r: 9 }, { x: -55, z: 40, r: 9 }, { x: 0, z: 14, r: 6 }, { x: 0, z: -14, r: 6 }] },
  { id: 'tri', n: 'المثلث', ds: 'ثلاث قواعد حول بحيرة مركزية', pl: 3, size: 180,
    starts: [{ x: 0, z: -68 }, { x: -62, z: 50 }, { x: 62, z: 50 }],
    mines: [{ x: -20, z: -26, a: 3500 }, { x: 20, z: -26, a: 3500 }, { x: 0, z: 40, a: 3500 }],
    water: [{ x: 0, z: 4, w: 36, h: 30 }],
    bridges: [],
    rocks: [{ x: 0, z: -34, r: 5 }, { x: -36, z: 20, r: 5 }, { x: 36, z: 20, r: 5 }, { x: -20, z: 4, r: 3 }, { x: 20, z: 4, r: 3 }],
    forests: [{ x: -42, z: -22, r: 10 }, { x: 42, z: -22, r: 10 }, { x: 0, z: 62, r: 10 }, { x: 0, z: -4, r: 0 }] },
  { id: 'oasis', n: 'الواحات', ds: 'حلقة صخرية مركزية غنية بالذهب', pl: 3, size: 190,
    starts: [{ x: -68, z: -62 }, { x: 68, z: -62 }, { x: 0, z: 70 }],
    mines: [{ x: 0, z: -7, a: 4500 }, { x: 7, z: 5, a: 4500 }, { x: -7, z: 5, a: 4500 }],
    water: [{ x: -42, z: -8, w: 14, h: 12 }, { x: 42, z: -8, w: 14, h: 12 }, { x: 0, z: 42, w: 12, h: 10 }],
    bridges: [],
    rocks: arc(0, 0, 27, 4.5, (a) => [Math.atan2(-62, -68), Math.atan2(-62, 68), Math.atan2(70, 0)].some(b => Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b))) < 0.3)),
    forests: [{ x: -62, z: 8, r: 9 }, { x: 62, z: 8, r: 9 }, { x: 0, z: -72, r: 9 }, { x: -36, z: 44, r: 8 }, { x: 36, z: 44, r: 8 }] },
  { id: 'kings', n: 'وادي الملوك', ds: 'أودية صخرية ضيقة وممرات ملتوية', pl: 3, size: 190, eras: ['anc'],
    starts: [{ x: -66, z: -62 }, { x: 66, z: -62 }, { x: 0, z: 68 }],
    mines: [{ x: 0, z: -40, a: 4000 }, { x: -40, z: 12, a: 4000 }, { x: 40, z: 12, a: 4000 }],
    water: [],
    bridges: [],
    rocks: [...line(-95, -28, -16, -28, 7, 4.5), ...line(16, -28, 95, -28, 7, 4.5), ...line(-95, 24, -26, 24, 7, 4.5), ...line(26, 24, 95, 24, 7, 4.5), ...line(0, -28, 0, -10, 7, 4)],
    forests: [{ x: -66, z: 2, r: 8 }, { x: 66, z: 2, r: 8 }, { x: 0, z: 40, r: 8 }] },
  { id: 'cross', n: 'الصليب', ds: 'جدران صخرية على شكل صليب بأربع قواعد', pl: 4, size: 200,
    starts: [{ x: -72, z: -72 }, { x: 72, z: 72 }, { x: 72, z: -72 }, { x: -72, z: 72 }],
    mines: [{ x: -16, z: -16, a: 4000 }, { x: 16, z: 16, a: 4000 }, { x: 16, z: -16, a: 4000 }, { x: -16, z: 16, a: 4000 }],
    water: [],
    bridges: [],
    rocks: [...line(-98, 0, 98, 0, 8, 4.5, (_t, x) => Math.abs(x) < 11 || Math.abs(Math.abs(x) - 52) < 7), ...line(0, -98, 0, 98, 8, 4.5, (_t, _x, z) => Math.abs(z) < 11 || Math.abs(Math.abs(z) - 52) < 7)],
    forests: [{ x: -42, z: -42, r: 9 }, { x: 42, z: 42, r: 9 }, { x: 42, z: -42, r: 9 }, { x: -42, z: 42, r: 9 }] },
  { id: 'rivers', n: 'الأنهار الأربعة', ds: 'نهران متقاطعان وجسور وجزيرة مركزية', pl: 4, size: 200,
    starts: [{ x: -72, z: -72 }, { x: 72, z: 72 }, { x: 72, z: -72 }, { x: -72, z: 72 }],
    mines: [{ x: -30, z: -30, a: 4000 }, { x: 30, z: 30, a: 4000 }, { x: 30, z: -30, a: 4000 }, { x: -30, z: 30, a: 4000 }],
    water: [{ x: 0, z: 0, w: 10, h: 210 }, { x: 0, z: 0, w: 210, h: 10 }],
    bridges: [{ x: 0, z: -46, w: 16, h: 12 }, { x: 0, z: 46, w: 16, h: 12 }, { x: -46, z: 0, w: 12, h: 16 }, { x: 46, z: 0, w: 12, h: 16 }, { x: 0, z: 0, w: 18, h: 18 }],
    rocks: [{ x: -48, z: -48, r: 4 }, { x: 48, z: 48, r: 4 }, { x: 48, z: -48, r: 4 }, { x: -48, z: 48, r: 4 }],
    forests: [{ x: -76, z: -24, r: 9 }, { x: 76, z: 24, r: 9 }, { x: 24, z: -76, r: 9 }, { x: -24, z: 76, r: 9 }, { x: 24, z: 28, r: 6 }, { x: -24, z: -28, r: 6 }] },
  { id: 'sahara', n: 'الصحراء الكبرى', ds: 'واحات صغيرة وكثبان صخرية في أرض مفتوحة', pl: 4, size: 210, eras: ['anc'],
    starts: [{ x: -78, z: -78 }, { x: 78, z: 78 }, { x: 78, z: -78 }, { x: -78, z: 78 }],
    mines: [{ x: 0, z: -20, a: 4500 }, { x: 0, z: 20, a: 4500 }, { x: -20, z: 0, a: 4500 }, { x: 20, z: 0, a: 4500 }],
    water: [{ x: -38, z: -38, w: 16, h: 16 }, { x: 38, z: 38, w: 16, h: 16 }, { x: 38, z: -38, w: 16, h: 16 }, { x: -38, z: 38, w: 16, h: 16 }],
    bridges: [],
    rocks: [...arc(0, 0, 40, 5, (a) => Math.abs(Math.sin(a * 2)) < 0.35), { x: -78, z: 0, r: 6 }, { x: 78, z: 0, r: 6 }, { x: 0, z: -78, r: 6 }, { x: 0, z: 78, r: 6 }],
    forests: [{ x: -60, z: -30, r: 7 }, { x: 60, z: 30, r: 7 }, { x: 60, z: -30, r: 7 }, { x: -60, z: 30, r: 7 }, { x: -30, z: -60, r: 7 }, { x: 30, z: 60, r: 7 }] },
];

export const MAPS: Record<string, MapDef> = {};
for (const m of RAW) {
  m.forests = m.forests.filter(f => f.r > 0);
  const mines = [...m.mines];
  for (const s of m.starts) {
    const L = Math.hypot(s.x, s.z) || 1; const dx = -s.x / L, dz = -s.z / L; const px = -dz, pz = dx;
    mines.push({ x: M(s.x + dx * 13 + px * 9), z: M(s.z + dz * 13 + pz * 9), a: 3500 });
    mines.push({ x: M(s.x + dx * 5 - px * 14), z: M(s.z + dz * 5 - pz * 14), a: 3500 });
  }
  m.mines = mines; MAPS[m.id] = m;
}
export const MAP_LIST = RAW;
export function mapsFor(era: Era, players: number) { return MAP_LIST.filter(m => m.pl >= players && (!m.eras || m.eras.includes(era))); }
