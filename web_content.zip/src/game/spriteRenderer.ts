import { ActiveMonsterState, MonsterDef, PlayerStats, WeaponClass } from './types';

export class SpriteRenderer {
  // Draw the Player / Hunter with current weapon, walk bob, roll, and attack swings
  public static drawHunter(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    angle: number,
    stats: PlayerStats,
    weaponClass: WeaponClass,
    isMoving: boolean,
    isSprinting: boolean,
    isRolling: boolean,
    rollProgress: number, // 0..1
    isAttacking: boolean,
    attackProgress: number, // 0..1
    attackType: string,
    isGuarding: boolean,
    walkDistance: number,
    invulnerableTimer: number
  ) {
    ctx.save();
    ctx.translate(x, y);

    // Flashing when i-frames are active
    if (invulnerableTimer > 0 && Math.floor(invulnerableTimer * 25) % 2 === 0) {
      ctx.globalAlpha = 0.5;
    }

    // Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
    ctx.beginPath();
    ctx.ellipse(0, 4, 14, 8, 0, 0, Math.PI * 2);
    ctx.fill();

    if (isRolling) {
      // Tumble roll animation
      const rollAngle = rollProgress * Math.PI * 2;
      ctx.rotate(angle + rollAngle);

      // Hunter rolling ball silhouette
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.arc(0, 0, 12, 0, Math.PI * 2);
      ctx.fill();

      // Armor trim
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(3, 0, 5, 0, Math.PI * 2);
      ctx.fill();

      // Motion trail puff
      ctx.restore();
      return;
    }

    ctx.rotate(angle);

    // Walk animation bob
    const bob = isMoving ? Math.sin(walkDistance * 0.12) * 2.5 : 0;
    const legSwing = isMoving ? Math.sin(walkDistance * 0.12) * 6 : 0;

    // Legs
    ctx.fillStyle = '#334155';
    // Left leg
    ctx.fillRect(-6 + legSwing, 6 + bob, 4, 7);
    // Right leg
    ctx.fillRect(2 - legSwing, 6 + bob, 4, 7);

    // Feet / boots
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(-7 + legSwing, 12 + bob, 5, 3);
    ctx.fillRect(1 - legSwing, 12 + bob, 5, 3);

    // Hunter Body / Tunic
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.ellipse(0, bob, 11, 9, 0, 0, Math.PI * 2);
    ctx.fill();

    // Chestplate
    ctx.fillStyle = '#b45309'; // Bronze/Leather armor tone
    ctx.fillRect(-6, -4 + bob, 12, 8);

    // Belt / pouch
    ctx.fillStyle = '#78350f';
    ctx.fillRect(-7, 3 + bob, 14, 3);
    ctx.fillStyle = '#d97706';
    ctx.fillRect(-2, 3 + bob, 4, 3);

    // Hunter Head
    ctx.fillStyle = '#fed7aa'; // Skin
    ctx.beginPath();
    ctx.arc(0, -6 + bob, 7, 0, Math.PI * 2);
    ctx.fill();

    // Helmet / Hair
    ctx.fillStyle = '#475569'; // Steel Helm
    ctx.beginPath();
    ctx.arc(0, -8 + bob, 7.5, Math.PI, Math.PI * 2);
    ctx.fill();
    // Horn / Feather accent
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(4, -12 + bob, 3, 5);

    // Demon mode aura
    if (stats.demonMode) {
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.6)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, bob, 16, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Arms & Weapon Rendering
    this.drawWeaponAndArms(
      ctx,
      weaponClass,
      bob,
      isAttacking,
      attackProgress,
      attackType,
      isGuarding,
      stats
    );

    ctx.restore();
  }

  // Draw weapons with distinct physical forms and attack animations
  private static drawWeaponAndArms(
    ctx: CanvasRenderingContext2D,
    weaponClass: WeaponClass,
    bob: number,
    isAttacking: boolean,
    attackProgress: number,
    attackType: string,
    isGuarding: boolean,
    stats: PlayerStats
  ) {
    ctx.save();

    switch (weaponClass) {
      case 'greatsword': {
        // Massive two-handed greatsword
        let swingAngle = 0;
        let swordOffset = 0;

        if (isAttacking) {
          if (attackType === 'charge') {
            // Charging overhead pose
            swingAngle = -Math.PI * 0.45;
            // Charge aura
            if (stats.chargeLevel > 0) {
              ctx.strokeStyle =
                stats.chargeLevel === 3
                  ? '#ef4444'
                  : stats.chargeLevel === 2
                  ? '#eab308'
                  : '#3b82f6';
              ctx.lineWidth = 3;
              ctx.strokeRect(-8, -32 + bob, 16, 40);
            }
          } else {
            // Heavy vertical cleave
            swingAngle = -Math.PI * 0.4 + attackProgress * Math.PI * 0.85;
            swordOffset = 6 * Math.sin(attackProgress * Math.PI);
          }
        } else {
          // Resting over shoulder
          swingAngle = -0.3;
        }

        ctx.rotate(swingAngle);

        // Arms holding hilt
        ctx.fillStyle = '#fed7aa';
        ctx.fillRect(4, -2 + bob, 7, 5);

        // Greatsword Blade
        const bladeX = 10 + swordOffset;
        const bladeY = -18 + bob;

        ctx.fillStyle = '#475569';
        ctx.fillRect(bladeX, bladeY, 28, 7); // Blade body
        // Edge bevel
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(bladeX + 2, bladeY + 1, 25, 2);
        // Golden crossguard
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(bladeX - 3, bladeY - 2, 4, 11);
        // Hilt
        ctx.fillStyle = '#78350f';
        ctx.fillRect(bladeX - 8, bladeY + 2, 5, 3);
        break;
      }

      case 'dualblades': {
        // Twin curved daggers
        let lArm = 0;
        let rArm = 0;

        if (isAttacking) {
          const spin = attackProgress * Math.PI * 2;
          lArm = Math.sin(spin) * 12;
          rArm = -Math.sin(spin) * 12;
        }

        // Left Dagger
        ctx.fillStyle = '#64748b';
        ctx.fillRect(6, -10 + bob + lArm, 14, 3);
        ctx.fillStyle = stats.demonMode ? '#ef4444' : '#38bdf8';
        ctx.fillRect(8, -9 + bob + lArm, 11, 1);

        // Right Dagger
        ctx.fillStyle = '#64748b';
        ctx.fillRect(6, 7 + bob + rArm, 14, 3);
        ctx.fillStyle = stats.demonMode ? '#ef4444' : '#38bdf8';
        ctx.fillRect(8, 8 + bob + rArm, 11, 1);
        break;
      }

      case 'hammer': {
        // Colossal crushing hammer
        let hammerAngle = 0.2;
        if (isAttacking) {
          hammerAngle = -Math.PI * 0.3 + attackProgress * Math.PI * 0.9;
        }
        ctx.rotate(hammerAngle);

        // Handle
        ctx.fillStyle = '#78350f';
        ctx.fillRect(6, -3 + bob, 22, 4);

        // Heavy Iron Mallet Head
        ctx.fillStyle = '#334155';
        ctx.fillRect(24, -12 + bob, 14, 22);
        // Spikes on head
        ctx.fillStyle = '#cbd5e1';
        ctx.fillRect(38, -8 + bob, 4, 4);
        ctx.fillRect(38, 2 + bob, 4, 4);
        break;
      }

      case 'longsword': {
        // Katana with spirit glow
        let swordAngle = 0;
        if (isAttacking) {
          swordAngle = -Math.PI * 0.5 + attackProgress * Math.PI * 1.0;
        }
        ctx.rotate(swordAngle);

        // Long thin blade
        ctx.fillStyle = '#cbd5e1';
        ctx.fillRect(8, -2 + bob, 32, 3);

        // Spirit gauge aura on blade
        if (stats.spiritLevel > 0) {
          ctx.strokeStyle =
            stats.spiritLevel === 3
              ? '#ef4444'
              : stats.spiritLevel === 2
              ? '#eab308'
              : '#f8fafc';
          ctx.lineWidth = 2;
          ctx.strokeRect(8, -3 + bob, 32, 5);
        }

        // Tsuba / Guard
        ctx.fillStyle = '#b45309';
        ctx.fillRect(6, -4 + bob, 3, 7);
        break;
      }

      case 'bow': {
        // Bow arc and aimed arrow
        ctx.strokeStyle = '#854d0e';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(14, 0 + bob, 16, -Math.PI * 0.4, Math.PI * 0.4);
        ctx.stroke();

        // Bowstring
        ctx.strokeStyle = '#e2e8f0';
        ctx.lineWidth = 1;
        ctx.beginPath();
        const pullback = isAttacking ? 6 + stats.chargeLevel * 3 : 0;
        ctx.moveTo(14 + Math.cos(-Math.PI * 0.4) * 16, Math.sin(-Math.PI * 0.4) * 16);
        ctx.lineTo(14 - pullback, 0 + bob);
        ctx.lineTo(14 + Math.cos(Math.PI * 0.4) * 16, Math.sin(Math.PI * 0.4) * 16);
        ctx.stroke();

        // Arrow
        if (isAttacking) {
          ctx.fillStyle = stats.bowCoating === 'poison' ? '#84cc16' : '#f59e0b';
          ctx.fillRect(10 - pullback, -1.5 + bob, 22, 3);
          // Arrowhead
          ctx.beginPath();
          ctx.moveTo(32 - pullback, -3 + bob);
          ctx.lineTo(36 - pullback, 0 + bob);
          ctx.lineTo(32 - pullback, 3 + bob);
          ctx.fill();
        }
        break;
      }

      case 'lance': {
        // Heavy Tower Shield & Long Piercing Lance
        if (isGuarding) {
          // Shield raised in front
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(12, -12 + bob, 8, 24);
          ctx.fillStyle = '#38bdf8';
          ctx.fillRect(14, -8 + bob, 4, 16);
          // Shield boss
          ctx.fillStyle = '#f59e0b';
          ctx.fillRect(11, -3 + bob, 4, 6);
        } else {
          // Shield on left arm
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(4, -14 + bob, 6, 16);
        }

        // Long Lance thrust
        let thrust = 0;
        if (isAttacking) {
          thrust = Math.sin(attackProgress * Math.PI) * 18;
        }
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(8 + thrust, 4 + bob, 36, 4);
        // Lance Cone tip
        ctx.beginPath();
        ctx.moveTo(44 + thrust, 1 + bob);
        ctx.lineTo(52 + thrust, 6 + bob);
        ctx.lineTo(44 + thrust, 11 + bob);
        ctx.fill();
        break;
      }
    }

    ctx.restore();
  }

  // Draw any of the 12+ Behemoth species with accurate visual identity, animations, and wound indicators
  public static drawMonster(
    ctx: CanvasRenderingContext2D,
    monster: ActiveMonsterState,
    def: MonsterDef,
    animTime: number
  ) {
    ctx.save();
    ctx.translate(monster.x, monster.y);

    const isDead = monster.state === 'dead';
    const isEnraged = monster.enraged;
    const isFleeing = monster.state === 'flee';
    const isExhausted = monster.state === 'exhausted';

    // Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.beginPath();
    const shadowScale = isDead ? def.size * 0.9 : def.size;
    ctx.ellipse(0, 10, shadowScale * 0.8, shadowScale * 0.45, 0, 0, Math.PI * 2);
    ctx.fill();

    // Dead / Carved state
    if (isDead) {
      ctx.rotate(monster.angle + Math.PI * 0.5);
      ctx.globalAlpha = 0.85;

      // Fallen carcass
      ctx.fillStyle = '#374151';
      ctx.beginPath();
      ctx.ellipse(0, 0, def.size * 0.7, def.size * 0.45, 0, 0, Math.PI * 2);
      ctx.fill();

      // Carvable sparkle prompt
      if (!monster.isCarved) {
        ctx.fillStyle = '#facc15';
        ctx.font = 'bold 12px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('✦ CARVE (E)', 0, -def.size * 0.6);
      }

      ctx.restore();
      return;
    }

    ctx.rotate(monster.angle);

    // Movement walk cycle & limp
    const walkBob =
      monster.state === 'chase' || monster.state === 'patrol' || isFleeing
        ? Math.sin(animTime * (isFleeing ? 6 : 9)) * 3
        : 0;

    // Tail Severed check
    const tailPart = monster.parts.find((p) => p.severable);
    const hasTail = !tailPart || !tailPart.severed;

    // 1. TAIL
    if (hasTail) {
      const tailWag = Math.sin(animTime * 5) * 6;
      ctx.fillStyle = def.color;
      ctx.beginPath();
      ctx.moveTo(-def.size * 0.4, -6 + walkBob);
      ctx.quadraticCurveTo(
        -def.size * 0.8,
        tailWag,
        -def.size * 1.2,
        tailWag * 1.5
      );
      ctx.lineTo(-def.size * 0.4, 6 + walkBob);
      ctx.fill();

      // Tail spikes or tip
      ctx.fillStyle = def.accentColor;
      ctx.fillRect(-def.size * 1.15, tailWag * 1.5 - 4, 10, 8);
    } else {
      // Severed tail stump with wound
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.arc(-def.size * 0.4, 0, 7, 0, Math.PI * 2);
      ctx.fill();
    }

    // 2. MAIN BODY (BEHEMOTH SILHOUETTE)
    ctx.fillStyle = def.color;
    ctx.beginPath();
    ctx.ellipse(0, walkBob, def.size * 0.55, def.size * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();

    // Dorsal Armor Plates or Scales
    ctx.fillStyle = def.accentColor;
    ctx.beginPath();
    ctx.ellipse(-def.size * 0.1, walkBob - 4, def.size * 0.35, def.size * 0.22, 0, 0, Math.PI * 2);
    ctx.fill();

    // 3. LIMBS / LEGS / CLAWS
    ctx.fillStyle = def.color;
    // Front claws
    ctx.fillRect(def.size * 0.25, -def.size * 0.4 + walkBob, 12, 10);
    ctx.fillRect(def.size * 0.25, def.size * 0.25 + walkBob, 12, 10);
    // Back legs
    ctx.fillRect(-def.size * 0.35, -def.size * 0.45 - walkBob, 14, 12);
    ctx.fillRect(-def.size * 0.35, def.size * 0.3 - walkBob, 14, 12);

    // 4. BEHEMOTH HEAD & JAW
    ctx.fillStyle = def.color;
    ctx.beginPath();
    ctx.arc(def.size * 0.48, walkBob, def.size * 0.3, 0, Math.PI * 2);
    ctx.fill();

    // Snout / Maw
    ctx.fillStyle = def.accentColor;
    ctx.beginPath();
    ctx.arc(def.size * 0.65, walkBob, def.size * 0.18, -Math.PI * 0.4, Math.PI * 0.4);
    ctx.fill();

    // 5. HORNS / CREST (check broken state)
    const hornPart = monster.parts.find((p) => p.id === 'horn' || p.id === 'crown' || p.id === 'fangs');
    const hornsBroken = hornPart && hornPart.broken;

    if (!hornsBroken) {
      // Intact majestic horns
      ctx.fillStyle = def.accentColor;
      ctx.beginPath();
      // Left horn
      ctx.moveTo(def.size * 0.45, -def.size * 0.25 + walkBob);
      ctx.lineTo(def.size * 0.85, -def.size * 0.45 + walkBob);
      ctx.lineTo(def.size * 0.55, -def.size * 0.12 + walkBob);
      ctx.fill();
      // Right horn
      ctx.moveTo(def.size * 0.45, def.size * 0.25 + walkBob);
      ctx.lineTo(def.size * 0.85, def.size * 0.45 + walkBob);
      ctx.lineTo(def.size * 0.55, def.size * 0.12 + walkBob);
      ctx.fill();
    } else {
      // Broken horns stump
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(def.size * 0.45, -def.size * 0.22 + walkBob, 6, 6);
      ctx.fillRect(def.size * 0.45, def.size * 0.16 + walkBob, 6, 6);
    }

    // 6. EYES (Red glow if enraged, cyan if exhausted, bright otherwise)
    ctx.fillStyle = isEnraged ? '#ef4444' : isExhausted ? '#38bdf8' : def.glowColor;
    ctx.beginPath();
    ctx.arc(def.size * 0.52, -7 + walkBob, 3.5, 0, Math.PI * 2);
    ctx.arc(def.size * 0.52, 7 + walkBob, 3.5, 0, Math.PI * 2);
    ctx.fill();

    // Enrage fire/steam aura
    if (isEnraged) {
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, walkBob, def.size * 0.75, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Poison status bubbling
    if (monster.isPoisoned) {
      ctx.fillStyle = '#a3e635';
      ctx.beginPath();
      ctx.arc(0, -def.size * 0.4, 5, 0, Math.PI * 2);
      ctx.arc(def.size * 0.2, -def.size * 0.35, 4, 0, Math.PI * 2);
      ctx.fill();
    }

    // Exhausted panting drool
    if (isExhausted) {
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(def.size * 0.7, walkBob + 4, 3, 7);
    }

    // Attack Windup Telegraph (Visual Ground Indicator)
    if (monster.state === 'windup' && monster.currentAttack) {
      this.drawAttackTelegraph(ctx, monster.currentAttack, def.size);
    }

    ctx.restore();
  }

  // Draw readable attack telegraph ground shapes (cone, circle, charge line)
  private static drawAttackTelegraph(
    ctx: CanvasRenderingContext2D,
    attack: { telegraphType: string; range: number; angleRange?: number },
    size: number
  ) {
    ctx.save();
    ctx.fillStyle = 'rgba(239, 68, 68, 0.28)';
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.85)';
    ctx.lineWidth = 2;

    if (attack.telegraphType === 'circle') {
      ctx.beginPath();
      ctx.arc(0, 0, attack.range, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    } else if (attack.telegraphType === 'cone') {
      const half = (attack.angleRange || 1.4) / 2;
      ctx.beginPath();
      ctx.moveTo(size * 0.4, 0);
      ctx.arc(size * 0.4, 0, attack.range, -half, half);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    } else if (attack.telegraphType === 'charge') {
      ctx.fillRect(size * 0.4, -22, attack.range, 44);
      ctx.strokeRect(size * 0.4, -22, attack.range, 44);
    }

    ctx.restore();
  }

  // Draw environment terrain objects (trees, ruins, gathering nodes, rocks, camp)
  public static drawEnvironment(
    ctx: CanvasRenderingContext2D,
    type: 'tree' | 'rock' | 'ruin' | 'tent' | 'anvil' | 'lava_vent' | 'ice_spike',
    x: number,
    y: number,
    themeColor: string
  ) {
    ctx.save();
    ctx.translate(x, y);

    switch (type) {
      case 'tree': {
        // Shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        ctx.beginPath();
        ctx.ellipse(0, 16, 28, 12, 0, 0, Math.PI * 2);
        ctx.fill();

        // Trunk
        ctx.fillStyle = '#451a03';
        ctx.fillRect(-6, 0, 12, 18);

        // Canopy layers
        ctx.fillStyle = '#14532d';
        ctx.beginPath();
        ctx.arc(0, -6, 26, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#16a34a';
        ctx.beginPath();
        ctx.arc(-4, -10, 20, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 'rock': {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        ctx.beginPath();
        ctx.ellipse(0, 8, 20, 10, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#334155';
        ctx.beginPath();
        ctx.moveTo(-16, 8);
        ctx.lineTo(-10, -14);
        ctx.lineTo(8, -18);
        ctx.lineTo(18, -4);
        ctx.lineTo(14, 8);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#64748b';
        ctx.fillRect(-6, -10, 12, 8);
        break;
      }

      case 'ruin': {
        // Ancient stone pillar / collapsed arch
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(-18, -24, 36, 32);
        ctx.fillStyle = '#475569';
        ctx.fillRect(-14, -20, 28, 24);
        ctx.fillStyle = themeColor;
        ctx.fillRect(-10, -12, 4, 12);
        ctx.fillRect(6, -12, 4, 12);
        break;
      }

      case 'tent': {
        // Hunter Camp Pavilion Tent
        ctx.fillStyle = 'rgba(0,0,0,0.35)';
        ctx.beginPath();
        ctx.ellipse(0, 14, 36, 14, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#78350f';
        ctx.beginPath();
        ctx.moveTo(0, -32);
        ctx.lineTo(-32, 14);
        ctx.lineTo(32, 14);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#b45309';
        ctx.beginPath();
        ctx.moveTo(0, -32);
        ctx.lineTo(-12, 14);
        ctx.lineTo(12, 14);
        ctx.closePath();
        ctx.fill();

        // Guild Crest Flag
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(0, -42, 2, 12);
        ctx.fillRect(2, -42, 10, 7);
        break;
      }

      case 'anvil': {
        // Blacksmith forge & anvil
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(-12, -4, 24, 12);
        ctx.fillStyle = '#475569';
        ctx.fillRect(-16, -12, 32, 8);
        // Hammer resting
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(2, -16, 12, 4);
        break;
      }

      case 'lava_vent': {
        ctx.fillStyle = '#7f1d1d';
        ctx.beginPath();
        ctx.arc(0, 0, 18, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#f97316';
        ctx.beginPath();
        ctx.arc(0, 0, 11, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(0, 0, 5, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 'ice_spike': {
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.moveTo(0, -26);
        ctx.lineTo(-10, 10);
        ctx.lineTo(10, 10);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#bae6fd';
        ctx.beginPath();
        ctx.moveTo(0, -26);
        ctx.lineTo(-3, 10);
        ctx.lineTo(4, 10);
        ctx.closePath();
        ctx.fill();
        break;
      }
    }

    ctx.restore();
  }

  // Draw gather node icons (herb, ore, bone, honey, mushroom)
  public static drawGatherNode(
    ctx: CanvasRenderingContext2D,
    type: string,
    x: number,
    y: number,
    isGathered: boolean
  ) {
    if (isGathered) return;

    ctx.save();
    ctx.translate(x, y);

    // Glowing aura
    ctx.fillStyle = 'rgba(250, 204, 21, 0.2)';
    ctx.beginPath();
    ctx.arc(0, 0, 14, 0, Math.PI * 2);
    ctx.fill();

    switch (type) {
      case 'herb':
        ctx.fillStyle = '#22c55e';
        ctx.fillRect(-5, -7, 10, 14);
        ctx.fillStyle = '#86efac';
        ctx.fillRect(-3, -5, 6, 10);
        break;
      case 'ore':
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(-6, -6, 12, 12);
        ctx.fillStyle = '#bae6fd';
        ctx.fillRect(-3, -3, 6, 6);
        break;
      case 'bone':
        ctx.fillStyle = '#f1f5f9';
        ctx.fillRect(-7, -4, 14, 8);
        break;
      case 'honey':
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(0, 0, 6, 0, Math.PI * 2);
        ctx.fill();
        break;
      case 'mushroom':
        ctx.fillStyle = '#ec4899';
        ctx.beginPath();
        ctx.arc(0, -2, 7, Math.PI, 0);
        ctx.fill();
        ctx.fillStyle = '#fed7aa';
        ctx.fillRect(-2, -2, 4, 6);
        break;
    }

    // Sparkle dot
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(3, -7, 3, 3);

    ctx.restore();
  }
}
