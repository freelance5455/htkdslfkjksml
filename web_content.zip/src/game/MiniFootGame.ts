export type GamePhase = "menu" | "playing" | "paused" | "gameover";
export type SoundCue = "start" | "kick" | "miss" | "bounce" | "rival" | "goal" | "concede" | "end";

export interface HudData {
  home: number;
  away: number;
  time: number;
  points: number;
}

export interface GameResult extends HudData {
  bestCombo: number;
}

interface GameCallbacks {
  onHud: (hud: HudData) => void;
  onEnd: (result: GameResult) => void;
  onGoal: (team: "home" | "away") => void;
  onSound: (cue: SoundCue) => void;
}

interface Actor {
  x: number;
  y: number;
  vx: number;
  vy: number;
  faceX: number;
  faceY: number;
  step: number;
  cooldown: number;
  swing: number;
}

interface Ball {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rotation: number;
  flight: number;
  trail: { x: number; y: number }[];
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  total: number;
  size: number;
  gravity: number;
  color: string;
  square: boolean;
  rotation: number;
}

interface Ring {
  x: number;
  y: number;
  life: number;
  total: number;
  radius: number;
  color: string;
}

interface Announcement {
  title: string;
  detail: string;
  color: string;
  life: number;
  total: number;
}

const W = 600;
const H = 760;
const TOP = 60;
const BOTTOM = 700;
const LEFT = 52;
const RIGHT = 548;
const BALL_RADIUS = 14;
const GOAL_LEFT = 222;
const GOAL_RIGHT = 378;

const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const distance = (a: { x: number; y: number }, b: { x: number; y: number }) =>
  Math.hypot(a.x - b.x, a.y - b.y);

function makeActor(x: number, y: number, faceY: number): Actor {
  return { x, y, vx: 0, vy: 0, faceX: 0, faceY, step: 0, cooldown: 0, swing: 0 };
}

export class MiniFootGame {
  phase: GamePhase = "menu";

  private callbacks: GameCallbacks;
  private field: HTMLCanvasElement;
  private player = makeActor(300, 548, -1);
  private rival = makeActor(394, 240, 1);
  private ball: Ball = { x: 300, y: 483, vx: 0, vy: 0, rotation: 0, flight: 0, trail: [] };
  private particles: Particle[] = [];
  private rings: Ring[] = [];
  private announcement: Announcement | null = null;
  private elapsed = 0;
  private timeLeft = 60;
  private lastDisplayedTime = 60;
  private home = 0;
  private away = 0;
  private points = 0;
  private combo = 0;
  private bestCombo = 0;
  private goalDelay = 0;
  private aiWait = 0;
  private kickoffNumber = 0;
  private kickQueued = false;
  private shake = 0;
  private flash = 0;
  private lastWallSound = 0;
  private dustClock = 0;

  constructor(callbacks: GameCallbacks) {
    this.callbacks = callbacks;
    this.field = this.makeField();
  }

  start() {
    this.phase = "playing";
    this.elapsed = 0;
    this.timeLeft = 60;
    this.lastDisplayedTime = 60;
    this.home = 0;
    this.away = 0;
    this.points = 0;
    this.combo = 0;
    this.bestCombo = 0;
    this.kickoffNumber = 0;
    this.goalDelay = 0;
    this.shake = 0;
    this.flash = 0;
    this.lastWallSound = -1;
    this.dustClock = 0;
    this.particles = [];
    this.rings = [];
    this.resetKickoff();
    this.announce("KICK OFF!", "THE CLOCK IS TICKING", "#e4fb8b", 0.85);
    this.emitHud();
    this.callbacks.onSound("start");
  }

  pause() {
    if (this.phase === "playing") this.phase = "paused";
  }

  resume() {
    if (this.phase === "paused") this.phase = "playing";
  }

  requestKick() {
    if (this.phase === "playing" && this.goalDelay <= 0) this.kickQueued = true;
  }

  update(dt: number, input: { x: number; y: number }) {
    if (this.phase === "paused") return;

    this.elapsed += dt;
    this.updateEffects(dt);
    if (this.phase !== "playing") return;

    if (this.goalDelay > 0) {
      this.goalDelay -= dt;
      if (this.goalDelay <= 0) this.resetKickoff();
      return;
    }

    this.timeLeft = Math.max(0, this.timeLeft - dt);
    const displayedTime = Math.ceil(this.timeLeft);
    if (displayedTime !== this.lastDisplayedTime) {
      this.lastDisplayedTime = displayedTime;
      this.emitHud();
    }
    if (this.timeLeft <= 0) {
      this.finish();
      return;
    }

    this.player.cooldown = Math.max(0, this.player.cooldown - dt);
    this.player.swing = Math.max(0, this.player.swing - dt);
    this.rival.cooldown = Math.max(0, this.rival.cooldown - dt);
    this.rival.swing = Math.max(0, this.rival.swing - dt);
    this.aiWait = Math.max(0, this.aiWait - dt);

    const inputLength = Math.hypot(input.x, input.y);
    this.moveActor(
      this.player,
      inputLength > 1 ? input.x / inputLength : input.x,
      inputLength > 1 ? input.y / inputLength : input.y,
      365,
      dt,
    );
    this.moveRival(dt);

    if (this.kickQueued) {
      this.playerKick();
      this.kickQueued = false;
    }

    this.moveBall(dt);
    this.handlePlayerBall(dt);
    this.handleRivalBall();

    this.dustClock += dt;
    if (this.dustClock > 0.075) {
      this.dustClock = 0;
      if (Math.hypot(this.player.vx, this.player.vy) > 190) {
        this.spawnDust(this.player.x, this.player.y + 15, "#bce7ab");
      }
      if (Math.hypot(this.rival.vx, this.rival.vy) > 170) {
        this.spawnDust(this.rival.x, this.rival.y + 15, "#bce7ab");
      }
    }
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.clearRect(0, 0, W, H);
    ctx.save();
    if (this.shake > 0.2) {
      ctx.translate((Math.random() - 0.5) * this.shake, (Math.random() - 0.5) * this.shake);
    }

    ctx.drawImage(this.field, 0, 0, W, H);
    this.drawRings(ctx);
    this.drawBallTrail(ctx);
    this.drawActor(ctx, this.rival, false);
    this.drawActor(ctx, this.player, true);
    this.drawBall(ctx);
    this.drawParticles(ctx);
    this.drawAnnouncement(ctx);

    if (this.flash > 0) {
      ctx.fillStyle = `rgba(245, 255, 222, ${this.flash * 0.32})`;
      ctx.fillRect(0, 0, W, H);
    }
    ctx.restore();
  }

  private resetKickoff() {
    this.player = makeActor(300, 548, -1);
    const openingKickoff = this.kickoffNumber === 0;
    this.rival = makeActor(openingKickoff ? 394 : this.kickoffNumber % 2 === 0 ? 266 : 334, openingKickoff ? 240 : 298, 1);
    this.ball = { x: 300, y: 483, vx: 0, vy: 0, rotation: 0, flight: 0, trail: [] };
    this.aiWait = openingKickoff ? 0.6 : 0.17;
    this.kickQueued = false;
    this.kickoffNumber += 1;
  }

  private moveActor(actor: Actor, x: number, y: number, speed: number, dt: number) {
    const responsiveness = Math.min(1, dt * 14);
    actor.vx += (x * speed - actor.vx) * responsiveness;
    actor.vy += (y * speed - actor.vy) * responsiveness;
    actor.x = clamp(actor.x + actor.vx * dt, 70, 530);
    actor.y = clamp(actor.y + actor.vy * dt, 102, 658);
    if (Math.hypot(x, y) > 0.1) {
      actor.faceX = x;
      actor.faceY = y;
    }
    actor.step += (Math.hypot(actor.vx, actor.vy) * dt) / 30;
  }

  private moveRival(dt: number) {
    if (this.aiWait > 0) {
      this.moveActor(this.rival, 0, 0, 230, dt);
      return;
    }

    const ball = this.ball;
    let targetX = ball.x + clamp(ball.vx * 0.1, -64, 64);
    let targetY = ball.y;

    // The rival pressures a dribbler, but leaves enough space for a quick shot.
    if (ball.y > 440 && distance(this.player, ball) < 105) {
      targetX = this.player.x;
      targetY = ball.y - 58;
    }

    targetX = clamp(targetX, 85, 515);
    targetY = clamp(targetY, 112, 575);
    const dx = targetX - this.rival.x;
    const dy = targetY - this.rival.y;
    const length = Math.hypot(dx, dy);
    this.moveActor(
      this.rival,
      length > 15 ? dx / length : 0,
      length > 15 ? dy / length : 0,
      226,
      dt,
    );
  }

  private playerKick() {
    if (this.player.cooldown > 0) return;
    this.player.cooldown = 0.29;
    this.player.swing = 0.2;

    if (distance(this.player, this.ball) > 99) {
      this.addRing(this.player.x, this.player.y - 14, "#e4fb8b", 42, 0.25);
      this.callbacks.onSound("miss");
      return;
    }

    // A little auto-aim keeps shots rewarding without taking away directional control.
    const aimX = (300 - this.ball.x) * 0.0036 + this.player.faceX * 0.44;
    const aimY = -1;
    const length = Math.hypot(aimX, aimY);
    this.ball.vx = (aimX / length) * 930 + this.player.vx * 0.12;
    this.ball.vy = (aimY / length) * 930 + this.player.vy * 0.08;
    this.ball.flight = 0.42;
    this.ball.trail = [];
    this.shake = Math.max(this.shake, 7);
    this.flash = Math.max(this.flash, 0.13);
    this.addRing(this.ball.x, this.ball.y, "#f5f4d9", 68, 0.34);
    this.burst(this.ball.x, this.ball.y, ["#f5f4d9", "#e4fb8b", "#ff8469"], 15, 175, 80);
    this.callbacks.onSound("kick");
  }

  private moveBall(dt: number) {
    const ball = this.ball;
    const speed = Math.hypot(ball.vx, ball.vy);
    if (speed > 75) {
      ball.trail.unshift({ x: ball.x, y: ball.y });
      if (ball.trail.length > 9) ball.trail.pop();
    } else if (ball.trail.length > 0) {
      ball.trail.pop();
    }

    ball.x += ball.vx * dt;
    ball.y += ball.vy * dt;
    ball.rotation += speed * dt * 0.022;
    ball.flight = Math.max(0, ball.flight - dt);
    const friction = Math.exp(-1.05 * dt);
    ball.vx *= friction;
    ball.vy *= friction;
    if (Math.hypot(ball.vx, ball.vy) < 7) {
      ball.vx = 0;
      ball.vy = 0;
    }

    if (ball.x < LEFT + BALL_RADIUS || ball.x > RIGHT - BALL_RADIUS) {
      ball.x = clamp(ball.x, LEFT + BALL_RADIUS, RIGHT - BALL_RADIUS);
      ball.vx *= -0.78;
      this.wallImpact(ball.x, ball.y);
    }

    if (ball.y < TOP + BALL_RADIUS) {
      if (ball.x > GOAL_LEFT + 8 && ball.x < GOAL_RIGHT - 8 && ball.y < TOP + 4) {
        this.scoreGoal("home");
        return;
      }
      if (ball.x <= GOAL_LEFT + 8 || ball.x >= GOAL_RIGHT - 8) {
        ball.y = TOP + BALL_RADIUS;
        ball.vy = Math.abs(ball.vy) * 0.78;
        this.wallImpact(ball.x, ball.y);
      }
    }

    if (ball.y > BOTTOM - BALL_RADIUS) {
      if (ball.x > GOAL_LEFT + 8 && ball.x < GOAL_RIGHT - 8 && ball.y > BOTTOM - 4) {
        this.scoreGoal("away");
        return;
      }
      if (ball.x <= GOAL_LEFT + 8 || ball.x >= GOAL_RIGHT - 8) {
        ball.y = BOTTOM - BALL_RADIUS;
        ball.vy = -Math.abs(ball.vy) * 0.78;
        this.wallImpact(ball.x, ball.y);
      }
    }
  }

  private handlePlayerBall(dt: number) {
    if (this.goalDelay > 0) return;
    this.separateBall(this.player);

    const ball = this.ball;
    if (
      ball.flight <= 0 &&
      distance(this.player, ball) < 76 &&
      Math.hypot(ball.vx, ball.vy) < 490 &&
      (ball.x - this.player.x) * this.player.faceX +
        (ball.y - this.player.y) * this.player.faceY >
        -12
    ) {
      const targetX = this.player.x + this.player.faceX * 50;
      const targetY = this.player.y + this.player.faceY * 50;
      const desiredVX = (targetX - ball.x) * 11 + this.player.vx * 0.45;
      const desiredVY = (targetY - ball.y) * 11 + this.player.vy * 0.45;
      const grip = Math.min(1, dt * 11);
      ball.vx += (desiredVX - ball.vx) * grip;
      ball.vy += (desiredVY - ball.vy) * grip;
    }
  }

  private handleRivalBall() {
    if (this.goalDelay > 0) return;
    const touching = distance(this.rival, this.ball) < 42;
    if (!touching) return;

    this.separateBall(this.rival);
    if (this.rival.cooldown > 0 || this.aiWait > 0) return;

    this.rival.cooldown = 1.05;
    this.rival.swing = 0.2;
    const targetX = 300 + (Math.random() - 0.5) * 125;
    const dx = targetX - this.ball.x;
    const dy = 710 - this.ball.y;
    const length = Math.hypot(dx, dy);
    this.ball.vx = (dx / length) * 710;
    this.ball.vy = (dy / length) * 710;
    this.ball.flight = 0.38;
    this.ball.trail = [];
    this.shake = Math.max(this.shake, 4);
    this.addRing(this.ball.x, this.ball.y, "#b7a9ff", 56, 0.3);
    this.burst(this.ball.x, this.ball.y, ["#b7a9ff", "#f5f4d9"], 9, 115, 80);
    this.callbacks.onSound("rival");
  }

  private separateBall(actor: Actor) {
    const dx = this.ball.x - actor.x;
    const dy = this.ball.y - actor.y;
    const dist = Math.hypot(dx, dy);
    const minimum = 39;
    if (dist >= minimum) return;

    const nx = dist > 0.001 ? dx / dist : actor.faceX;
    const ny = dist > 0.001 ? dy / dist : actor.faceY;
    this.ball.x = actor.x + nx * minimum;
    this.ball.y = actor.y + ny * minimum;
    const approaching = this.ball.vx * nx + this.ball.vy * ny;
    if (approaching < 105) {
      const impulse = clamp(140 - approaching, 0, 510);
      this.ball.vx += nx * impulse + actor.vx * 0.2;
      this.ball.vy += ny * impulse + actor.vy * 0.2;
      if (approaching < -260) {
        this.addRing(this.ball.x, this.ball.y, "#f5f4d9", 46, 0.22);
        this.burst(this.ball.x, this.ball.y, ["#f5f4d9", "#e4fb8b"], 6, 90, 60);
      }
    }
  }

  private wallImpact(x: number, y: number) {
    this.burst(x, y, ["#d8f4cb", "#ffffff"], 5, 65, 30);
    if (this.elapsed - this.lastWallSound > 0.16) {
      this.callbacks.onSound("bounce");
      this.lastWallSound = this.elapsed;
    }
  }

  private scoreGoal(team: "home" | "away") {
    this.goalDelay = 1.2;
    this.shake = 21;
    this.flash = 0.85;
    const x = this.ball.x;
    const y = team === "home" ? 69 : 691;

    if (team === "home") {
      this.home += 1;
      this.combo = Math.min(this.combo + 1, 4);
      this.bestCombo = Math.max(this.bestCombo, this.combo);
      const earned = 100 * this.combo;
      this.points += earned;
      this.announce(
        "GOOOAL!",
        `+${earned} POINTS${this.combo > 1 ? `  /  ${this.combo}X STREAK` : ""}`,
        "#e4fb8b",
        1.08,
      );
      this.burst(x, y, ["#e4fb8b", "#ff8469", "#f5f4d9", "#75d4ae"], 75, 410, 175, true);
      this.callbacks.onSound("goal");
    } else {
      this.away += 1;
      this.combo = 0;
      this.announce("OH NO!", "THE RIVAL FOUND THE NET", "#c4b6ff", 1.05);
      this.burst(x, y, ["#b7a9ff", "#f5f4d9", "#75d4ae"], 55, 345, 180, true);
      this.callbacks.onSound("concede");
    }

    this.emitHud();
    this.callbacks.onGoal(team);
  }

  private finish() {
    this.phase = "gameover";
    this.timeLeft = 0;
    this.emitHud();
    if (this.home > this.away) {
      this.burst(300, 340, ["#e4fb8b", "#ff8469", "#f5f4d9", "#b7a9ff"], 70, 360, 150, true);
    }
    this.callbacks.onSound("end");
    this.callbacks.onEnd({
      home: this.home,
      away: this.away,
      time: 0,
      points: this.points,
      bestCombo: this.bestCombo,
    });
  }

  private emitHud() {
    this.callbacks.onHud({
      home: this.home,
      away: this.away,
      time: Math.ceil(this.timeLeft),
      points: this.points,
    });
  }

  private announce(title: string, detail: string, color: string, duration: number) {
    this.announcement = { title, detail, color, life: duration, total: duration };
  }

  private addRing(x: number, y: number, color: string, radius: number, duration: number) {
    this.rings.push({ x, y, color, radius, life: duration, total: duration });
  }

  private burst(
    x: number,
    y: number,
    colors: string[],
    count: number,
    speed: number,
    gravity: number,
    square = false,
  ) {
    for (let i = 0; i < count; i += 1) {
      const angle = Math.random() * Math.PI * 2;
      const velocity = speed * (0.25 + Math.random() * 0.75);
      const life = 0.35 + Math.random() * (square ? 0.95 : 0.38);
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * velocity,
        vy: Math.sin(angle) * velocity,
        life,
        total: life,
        size: square ? 4 + Math.random() * 7 : 2 + Math.random() * 4,
        gravity,
        color: colors[i % colors.length],
        square,
        rotation: Math.random() * Math.PI,
      });
    }
    if (this.particles.length > 240) this.particles.splice(0, this.particles.length - 240);
  }

  private spawnDust(x: number, y: number, color: string) {
    this.particles.push({
      x: x + (Math.random() - 0.5) * 20,
      y: y + (Math.random() - 0.5) * 8,
      vx: (Math.random() - 0.5) * 35,
      vy: -10 - Math.random() * 25,
      life: 0.28,
      total: 0.28,
      size: 2 + Math.random() * 3,
      gravity: 0,
      color,
      square: false,
      rotation: 0,
    });
  }

  private updateEffects(dt: number) {
    this.shake *= Math.exp(-dt * 13);
    this.flash = Math.max(0, this.flash - dt * 2.4);
    if (this.announcement) {
      this.announcement.life -= dt;
      if (this.announcement.life <= 0) this.announcement = null;
    }

    for (let i = this.particles.length - 1; i >= 0; i -= 1) {
      const particle = this.particles[i];
      particle.life -= dt;
      if (particle.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vy += particle.gravity * dt;
      particle.vx *= Math.exp(-dt * 1.2);
      particle.rotation += dt * 7;
    }
    for (let i = this.rings.length - 1; i >= 0; i -= 1) {
      this.rings[i].life -= dt;
      if (this.rings[i].life <= 0) this.rings.splice(i, 1);
    }
  }

  private drawRings(ctx: CanvasRenderingContext2D) {
    for (const ring of this.rings) {
      const progress = 1 - ring.life / ring.total;
      ctx.beginPath();
      ctx.arc(ring.x, ring.y, 12 + ring.radius * progress, 0, Math.PI * 2);
      ctx.strokeStyle = ring.color;
      ctx.globalAlpha = (1 - progress) * 0.8;
      ctx.lineWidth = 4 * (1 - progress) + 0.5;
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  private drawBallTrail(ctx: CanvasRenderingContext2D) {
    const length = this.ball.trail.length;
    for (let i = length - 1; i >= 0; i -= 1) {
      const point = this.ball.trail[i];
      const strength = 1 - i / (length + 1);
      ctx.beginPath();
      ctx.arc(point.x, point.y, BALL_RADIUS * (0.35 + strength * 0.42), 0, Math.PI * 2);
      ctx.fillStyle = `rgba(244, 255, 214, ${strength * 0.24})`;
      ctx.fill();
    }
  }

  private drawActor(ctx: CanvasRenderingContext2D, actor: Actor, isPlayer: boolean) {
    const running = clamp(Math.hypot(actor.vx, actor.vy) / 280, 0, 1);
    const bob = Math.sin(actor.step * 2.3) * running * 2;
    const idle = this.phase === "menu" ? Math.sin(this.elapsed * 2.2 + (isPlayer ? 0 : 1.8)) * 1.5 : 0;

    ctx.save();
    ctx.translate(actor.x, actor.y + bob + idle);

    ctx.fillStyle = "rgba(3, 35, 31, 0.34)";
    ctx.beginPath();
    ctx.ellipse(2, 12, 29, 14, 0, 0, Math.PI * 2);
    ctx.fill();

    if (isPlayer) {
      ctx.beginPath();
      ctx.arc(0, 0, 31, 0, Math.PI * 2);
      ctx.strokeStyle = "rgba(228, 251, 139, 0.88)";
      ctx.lineWidth = 2.5;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 0, 36, -Math.PI * 0.73, -Math.PI * 0.27);
      ctx.strokeStyle = "rgba(228, 251, 139, 0.45)";
      ctx.lineWidth = 3;
      ctx.stroke();
    }

    ctx.rotate(Math.atan2(actor.faceY, actor.faceX) + Math.PI / 2);

    // Tiny layered uniforms make the pieces legible even on a narrow phone.
    ctx.fillStyle = "#142c39";
    ctx.beginPath();
    ctx.roundRect(-17, 10 + Math.sin(actor.step * 2) * running * 3, 12, 22, 5);
    ctx.roundRect(5, 10 - Math.sin(actor.step * 2) * running * 3, 12, 22, 5);
    ctx.fill();

    ctx.fillStyle = isPlayer ? "#dd644f" : "#8c80d5";
    ctx.beginPath();
    ctx.arc(-21, -1, 8, 0, Math.PI * 2);
    ctx.arc(21, -1, 8, 0, Math.PI * 2);
    ctx.fill();

    ctx.beginPath();
    ctx.roundRect(-20, -18, 40, 42, 14);
    ctx.fillStyle = "#16313b";
    ctx.fill();
    ctx.beginPath();
    ctx.roundRect(-17, -16, 34, 36, 11);
    ctx.fillStyle = isPlayer ? "#ff8264" : "#b6a7ff";
    ctx.fill();

    ctx.fillStyle = isPlayer ? "#ffe0af" : "#e9c4aa";
    ctx.beginPath();
    ctx.arc(0, -18, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = isPlayer ? "#643a35" : "#463c62";
    ctx.beginPath();
    ctx.arc(0, -21, 10, Math.PI * 1.03, Math.PI * 1.97);
    ctx.lineWidth = 4;
    ctx.strokeStyle = ctx.fillStyle;
    ctx.stroke();

    ctx.font = "900 16px 'Barlow Condensed', Impact, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "#17313a";
    ctx.fillText(isPlayer ? "9" : "7", 0, 8);

    if (actor.swing > 0) {
      const extension = Math.sin((actor.swing / 0.2) * Math.PI) * 15;
      ctx.save();
      ctx.translate(10, -5 - extension);
      ctx.rotate(-0.3);
      ctx.fillStyle = "#142c39";
      ctx.beginPath();
      ctx.roundRect(-6, -9, 12, 23, 5);
      ctx.fill();
      ctx.restore();
    }
    ctx.restore();
  }

  private drawBall(ctx: CanvasRenderingContext2D) {
    const ball = this.ball;
    const idle = this.phase === "menu" ? Math.sin(this.elapsed * 3.5) * 2 : 0;
    ctx.save();
    ctx.translate(ball.x, ball.y + idle);
    ctx.fillStyle = "rgba(6, 35, 35, 0.34)";
    ctx.beginPath();
    ctx.ellipse(4, 10, 16, 8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.rotate(ball.rotation + (this.phase === "menu" ? this.elapsed * 0.4 : 0));

    const gradient = ctx.createRadialGradient(-5, -6, 1, 0, 0, 18);
    gradient.addColorStop(0, "#ffffff");
    gradient.addColorStop(0.67, "#f5f4df");
    gradient.addColorStop(1, "#b7c9bb");
    ctx.beginPath();
    ctx.arc(0, 0, BALL_RADIUS, 0, Math.PI * 2);
    ctx.fillStyle = gradient;
    ctx.fill();
    ctx.strokeStyle = "#173f3b";
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.beginPath();
    for (let i = 0; i < 5; i += 1) {
      const angle = -Math.PI / 2 + (i * Math.PI * 2) / 5;
      const x = Math.cos(angle) * 5.4;
      const y = Math.sin(angle) * 5.4;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fillStyle = "#244a45";
    ctx.fill();

    ctx.strokeStyle = "rgba(36, 74, 69, 0.78)";
    ctx.lineWidth = 1.4;
    for (let i = 0; i < 5; i += 1) {
      const angle = -Math.PI / 2 + (i * Math.PI * 2) / 5;
      ctx.beginPath();
      ctx.moveTo(Math.cos(angle) * 6, Math.sin(angle) * 6);
      ctx.lineTo(Math.cos(angle) * 13, Math.sin(angle) * 13);
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawParticles(ctx: CanvasRenderingContext2D) {
    for (const particle of this.particles) {
      ctx.save();
      ctx.globalAlpha = clamp(particle.life / particle.total, 0, 1);
      ctx.translate(particle.x, particle.y);
      ctx.rotate(particle.rotation);
      ctx.fillStyle = particle.color;
      if (particle.square) {
        ctx.fillRect(-particle.size / 2, -particle.size / 2, particle.size, particle.size * 0.62);
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, particle.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  private drawAnnouncement(ctx: CanvasRenderingContext2D) {
    if (!this.announcement) return;
    const notice = this.announcement;
    const progress = 1 - notice.life / notice.total;
    const opacity = Math.min(1, progress * 9, notice.life * 6);
    const scale = 0.72 + (1 - Math.exp(-progress * 16)) * 0.28;
    const isKickoff = notice.title === "KICK OFF!";

    ctx.save();
    ctx.translate(300, 365);
    ctx.scale(scale, scale);
    ctx.globalAlpha = opacity;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = `900 ${isKickoff ? 82 : notice.title.length > 8 ? 83 : 108}px 'Barlow Condensed', Impact, sans-serif`;
    ctx.lineJoin = "round";
    ctx.lineWidth = 12;
    ctx.strokeStyle = "#123f39";
    ctx.strokeText(notice.title, 0, 0);
    ctx.fillStyle = notice.color;
    ctx.fillText(notice.title, 0, 0);
    ctx.font = "800 16px 'DM Sans', Arial, sans-serif";
    ctx.letterSpacing = "2px";
    ctx.fillStyle = "#ffffff";
    ctx.fillText(notice.detail, 0, 53);
    ctx.restore();
  }

  private makeField() {
    // Static pitch artwork is rasterized once; the frame loop only draws moving pieces.
    const canvas = document.createElement("canvas");
    canvas.width = W * 2;
    canvas.height = H * 2;
    const ctx = canvas.getContext("2d")!;
    ctx.scale(2, 2);

    const grass = ctx.createLinearGradient(0, 0, W, H);
    grass.addColorStop(0, "#196f55");
    grass.addColorStop(0.48, "#176a53");
    grass.addColorStop(1, "#0e5d4b");
    ctx.fillStyle = grass;
    ctx.fillRect(0, 0, W, H);

    for (let stripe = 0; stripe < 10; stripe += 1) {
      ctx.fillStyle = stripe % 2 === 0 ? "rgba(226, 255, 206, 0.045)" : "rgba(0, 34, 34, 0.065)";
      ctx.fillRect(39, 39 + stripe * 69, 522, 69);
    }

    ctx.fillStyle = "#104b42";
    ctx.fillRect(0, 0, 38, H);
    ctx.fillRect(562, 0, 38, H);
    ctx.fillStyle = "rgba(5, 35, 34, 0.25)";
    ctx.fillRect(38, 0, 9, H);
    ctx.fillRect(553, 0, 9, H);

    for (let i = 0; i < 36; i += 1) {
      const y = 15 + i * 21;
      ctx.fillStyle = i % 4 === 0 ? "#6bad7b" : i % 3 === 0 ? "#4c9475" : "#276b5b";
      ctx.beginPath();
      ctx.arc(13 + (i % 2) * 9, y, 3, 0, Math.PI * 2);
      ctx.arc(580 - (i % 2) * 8, y + 8, 3, 0, Math.PI * 2);
      ctx.fill();
    }

    this.drawNet(ctx, true);
    this.drawNet(ctx, false);

    ctx.strokeStyle = "rgba(223, 249, 214, 0.88)";
    ctx.lineWidth = 3;
    ctx.strokeRect(50, 58, 500, 644);
    ctx.beginPath();
    ctx.moveTo(50, 380);
    ctx.lineTo(550, 380);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(300, 380, 72, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeRect(159, 58, 282, 125);
    ctx.strokeRect(222, 58, 156, 56);
    ctx.strokeRect(159, 577, 282, 125);
    ctx.strokeRect(222, 646, 156, 56);
    ctx.beginPath();
    ctx.arc(300, 183, 42, 0, Math.PI);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(300, 577, 42, Math.PI, Math.PI * 2);
    ctx.stroke();

    const corners: Array<[number, number, number, number]> = [
      [50, 58, 0, Math.PI / 2],
      [550, 58, Math.PI / 2, Math.PI],
      [50, 702, -Math.PI / 2, 0],
      [550, 702, Math.PI, Math.PI * 1.5],
    ];
    for (const [x, y, start, end] of corners) {
      ctx.beginPath();
      ctx.arc(x, y, 21, start, end);
      ctx.stroke();
    }

    for (const y of [139, 380, 621]) {
      ctx.beginPath();
      ctx.arc(300, y, 4, 0, Math.PI * 2);
      ctx.fillStyle = "#e5f9d6";
      ctx.fill();
    }

    ctx.strokeStyle = "#f2fae8";
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(GOAL_LEFT, 59);
    ctx.lineTo(GOAL_RIGHT, 59);
    ctx.moveTo(GOAL_LEFT, 701);
    ctx.lineTo(GOAL_RIGHT, 701);
    ctx.stroke();

    let seed = 23571;
    const random = () => {
      seed = (seed * 16807) % 2147483647;
      return (seed - 1) / 2147483646;
    };
    for (let i = 0; i < 300; i += 1) {
      const x = 48 + random() * 504;
      const y = 48 + random() * 663;
      ctx.fillStyle = random() > 0.5 ? "rgba(215, 251, 183, 0.1)" : "rgba(6, 55, 47, 0.13)";
      ctx.fillRect(x, y, 1 + random() * 2, 2 + random() * 5);
    }

    const light = ctx.createRadialGradient(40, 40, 0, 40, 40, 520);
    light.addColorStop(0, "rgba(230, 255, 175, 0.12)");
    light.addColorStop(1, "rgba(230, 255, 175, 0)");
    ctx.fillStyle = light;
    ctx.fillRect(0, 0, W, H);

    ctx.save();
    ctx.translate(22, 470);
    ctx.rotate(-Math.PI / 2);
    ctx.fillStyle = "rgba(224, 255, 201, 0.36)";
    ctx.font = "800 12px 'DM Sans', Arial, sans-serif";
    ctx.letterSpacing = "3px";
    ctx.textAlign = "center";
    ctx.fillText("MINIFOOT  /  ARCADE CUP", 0, 0);
    ctx.restore();

    return canvas;
  }

  private drawNet(ctx: CanvasRenderingContext2D, top: boolean) {
    const y = top ? 11 : 700;
    ctx.fillStyle = "#103d3c";
    ctx.fillRect(214, y, 172, 49);
    ctx.fillStyle = "rgba(207, 241, 210, 0.09)";
    ctx.fillRect(219, y + 4, 162, 40);
    ctx.strokeStyle = "rgba(207, 241, 210, 0.36)";
    ctx.lineWidth = 1;
    for (let x = 220; x <= 380; x += 16) {
      ctx.beginPath();
      ctx.moveTo(x, y + 3);
      ctx.lineTo(x, y + 46);
      ctx.stroke();
    }
    for (let lineY = y + 5; lineY <= y + 45; lineY += 10) {
      ctx.beginPath();
      ctx.moveTo(218, lineY);
      ctx.lineTo(382, lineY);
      ctx.stroke();
    }
    ctx.strokeStyle = "rgba(243, 255, 223, 0.8)";
    ctx.lineWidth = 4;
    ctx.strokeRect(216, y, 168, 48);
  }
}