import { Direction } from '../types';

export interface DesignStroke {
  points: { x: number; y: number }[];
  preferredDir?: Direction;
  // If true, this stroke is only included when difficulty/level allows more details
  isDetail?: boolean;
  minLevel?: number;
}

export interface DesignDefinition {
  id: string;
  name: string;
  emoji: string;
  category: string;
  baseWidth: number;
  baseHeight: number;
  description: string;
  strokes: DesignStroke[];
}

/**
 * Large procedural design library of recognizable objects and silhouettes.
 * Every design is composed of connected right-angle strokes (horizontal and vertical segments).
 */
export const LONG_ARROW_DESIGNS: DesignDefinition[] = [
  // ==========================================
  // LEVEL 1: STARTER HEART (Simple, 4-5 clean arrows)
  // ==========================================
  {
    id: 'heart',
    name: 'Heart',
    emoji: '❤️',
    category: 'Symbols',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Loving Heart Contour',
    strokes: [
      // Left lobe curve: top arch
      {
        points: [
          { x: 2, y: 1 },
          { x: 1, y: 1 },
          { x: 1, y: 3 },
        ],
        preferredDir: 'UP',
      },
      // Right lobe curve: top arch
      {
        points: [
          { x: 4, y: 1 },
          { x: 5, y: 1 },
          { x: 5, y: 3 },
        ],
        preferredDir: 'UP',
      },
      // Left lower slope to bottom tip
      {
        points: [
          { x: 1, y: 4 },
          { x: 2, y: 5 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Right lower slope to bottom tip
      {
        points: [
          { x: 5, y: 4 },
          { x: 4, y: 5 },
          { x: 3, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
      // Center inner pulse
      {
        points: [
          { x: 3, y: 2 },
          { x: 3, y: 3 },
          { x: 3, y: 4 },
        ],
        preferredDir: 'UP',
        isDetail: true,
        minLevel: 3,
      },
    ],
  },

  // ==========================================
  // LEVEL 2: COZY HOUSE
  // ==========================================
  {
    id: 'house',
    name: 'House',
    emoji: '🏠',
    category: 'Architecture',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Gabled Roof Cottage',
    strokes: [
      // Left roof slope
      {
        points: [
          { x: 3, y: 1 },
          { x: 2, y: 2 },
          { x: 1, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // Right roof slope
      {
        points: [
          { x: 3, y: 1 },
          { x: 4, y: 2 },
          { x: 5, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Chimney
      {
        points: [
          { x: 4, y: 1 },
          { x: 4, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // Left wall & foundation
      {
        points: [
          { x: 1, y: 3 },
          { x: 1, y: 6 },
          { x: 2, y: 6 },
        ],
        preferredDir: 'RIGHT',
      },
      // Right wall & foundation
      {
        points: [
          { x: 5, y: 3 },
          { x: 5, y: 6 },
          { x: 4, y: 6 },
        ],
        preferredDir: 'LEFT',
      },
      // Doorway arch
      {
        points: [
          { x: 2, y: 6 },
          { x: 2, y: 4 },
          { x: 3, y: 4 },
          { x: 4, y: 4 },
          { x: 4, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Window cross
      {
        points: [
          { x: 3, y: 2 },
          { x: 3, y: 3 },
        ],
        preferredDir: 'UP',
        isDetail: true,
        minLevel: 4,
      },
    ],
  },

  // ==========================================
  // LEVEL 3: EVERGREEN TREE
  // ==========================================
  {
    id: 'tree',
    name: 'Evergreen Tree',
    emoji: '🌲',
    category: 'Nature',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Pine Tree Silhouette',
    strokes: [
      // Tree crown peak
      {
        points: [
          { x: 3, y: 0 },
          { x: 3, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Top foliage tier: left branch
      {
        points: [
          { x: 3, y: 1 },
          { x: 2, y: 2 },
          { x: 1, y: 2 },
        ],
        preferredDir: 'LEFT',
      },
      // Top foliage tier: right branch
      {
        points: [
          { x: 3, y: 1 },
          { x: 4, y: 2 },
          { x: 5, y: 2 },
        ],
        preferredDir: 'RIGHT',
      },
      // Middle foliage tier: left spread
      {
        points: [
          { x: 2, y: 3 },
          { x: 1, y: 4 },
          { x: 0, y: 4 },
        ],
        preferredDir: 'LEFT',
      },
      // Middle foliage tier: right spread
      {
        points: [
          { x: 4, y: 3 },
          { x: 5, y: 4 },
          { x: 6, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
      // Sturdy trunk
      {
        points: [
          { x: 3, y: 4 },
          { x: 3, y: 5 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Base grass / roots
      {
        points: [
          { x: 2, y: 6 },
          { x: 4, y: 6 },
        ],
        preferredDir: 'RIGHT',
        isDetail: true,
        minLevel: 5,
      },
    ],
  },

  // ==========================================
  // LEVEL 4: BLOOMING FLOWER
  // ==========================================
  {
    id: 'flower',
    name: 'Flower',
    emoji: '🌸',
    category: 'Nature',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Blooming Petal Blossom',
    strokes: [
      // Top Petal
      {
        points: [
          { x: 3, y: 2 },
          { x: 2, y: 1 },
          { x: 3, y: 0 },
          { x: 4, y: 1 },
        ],
        preferredDir: 'DOWN',
      },
      // Left Petal
      {
        points: [
          { x: 2, y: 2 },
          { x: 1, y: 1 },
          { x: 0, y: 2 },
          { x: 1, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Right Petal
      {
        points: [
          { x: 4, y: 2 },
          { x: 5, y: 1 },
          { x: 6, y: 2 },
          { x: 5, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // Center Stem
      {
        points: [
          { x: 3, y: 3 },
          { x: 3, y: 4 },
          { x: 3, y: 5 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Left Leaf
      {
        points: [
          { x: 3, y: 4 },
          { x: 2, y: 4 },
          { x: 1, y: 4 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Leaf
      {
        points: [
          { x: 3, y: 5 },
          { x: 4, y: 5 },
          { x: 5, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 5: SKELETON KEY
  // ==========================================
  {
    id: 'key',
    name: 'Master Key',
    emoji: '🔑',
    category: 'Tools',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Right-Angle Shaft & Bit Teeth',
    strokes: [
      // Bow Loop Top-Left
      {
        points: [
          { x: 1, y: 2 },
          { x: 1, y: 1 },
          { x: 2, y: 1 },
        ],
        preferredDir: 'RIGHT',
      },
      // Bow Loop Bottom-Left
      {
        points: [
          { x: 1, y: 2 },
          { x: 1, y: 3 },
          { x: 2, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Main Shaft
      {
        points: [
          { x: 2, y: 2 },
          { x: 3, y: 2 },
          { x: 4, y: 2 },
          { x: 5, y: 2 },
        ],
        preferredDir: 'RIGHT',
      },
      // Tooth 1 (First bit prong)
      {
        points: [
          { x: 4, y: 2 },
          { x: 4, y: 3 },
          { x: 4, y: 4 },
        ],
        preferredDir: 'DOWN',
      },
      // Tooth 2 (Second bit prong)
      {
        points: [
          { x: 5, y: 2 },
          { x: 5, y: 3 },
          { x: 5, y: 4 },
          { x: 6, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
      // Bow Ring Right Closer
      {
        points: [
          { x: 2, y: 1 },
          { x: 2, y: 2 },
          { x: 2, y: 3 },
        ],
        preferredDir: 'DOWN',
        isDetail: true,
        minLevel: 3,
      },
    ],
  },

  // ==========================================
  // LEVEL 6: SAILBOAT
  // ==========================================
  {
    id: 'sailboat',
    name: 'Sailboat',
    emoji: '⛵',
    category: 'Vehicles',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Rigged Sail & Ocean Hull',
    strokes: [
      // Central Mast
      {
        points: [
          { x: 3, y: 1 },
          { x: 3, y: 2 },
          { x: 3, y: 3 },
          { x: 3, y: 4 },
        ],
        preferredDir: 'UP',
      },
      // Mainsail Right
      {
        points: [
          { x: 3, y: 1 },
          { x: 4, y: 2 },
          { x: 5, y: 3 },
          { x: 5, y: 4 },
          { x: 4, y: 4 },
        ],
        preferredDir: 'LEFT',
      },
      // Jib Sail Left
      {
        points: [
          { x: 3, y: 2 },
          { x: 2, y: 3 },
          { x: 1, y: 4 },
          { x: 2, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
      // Boat Hull Bottom
      {
        points: [
          { x: 0, y: 5 },
          { x: 1, y: 6 },
          { x: 5, y: 6 },
          { x: 6, y: 5 },
        ],
        preferredDir: 'UP',
      },
      // Hull Deck Line
      {
        points: [
          { x: 1, y: 5 },
          { x: 2, y: 5 },
          { x: 3, y: 5 },
          { x: 4, y: 5 },
          { x: 5, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 7: SONGBIRD
  // ==========================================
  {
    id: 'bird',
    name: 'Bird',
    emoji: '🐦',
    category: 'Animals',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Perched Songbird Profile',
    strokes: [
      // Beak pointing left
      {
        points: [
          { x: 1, y: 2 },
          { x: 0, y: 2 },
        ],
        preferredDir: 'LEFT',
      },
      // Head & Crown
      {
        points: [
          { x: 1, y: 2 },
          { x: 1, y: 1 },
          { x: 2, y: 1 },
          { x: 3, y: 1 },
        ],
        preferredDir: 'RIGHT',
      },
      // Breast & Belly
      {
        points: [
          { x: 1, y: 2 },
          { x: 1, y: 3 },
          { x: 2, y: 4 },
          { x: 3, y: 4 },
        ],
        preferredDir: 'DOWN',
      },
      // Wing Fold
      {
        points: [
          { x: 3, y: 2 },
          { x: 4, y: 2 },
          { x: 4, y: 3 },
          { x: 3, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // Back & Tail Feathers
      {
        points: [
          { x: 3, y: 1 },
          { x: 4, y: 1 },
          { x: 5, y: 2 },
          { x: 6, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Perch Branch
      {
        points: [
          { x: 1, y: 5 },
          { x: 2, y: 5 },
          { x: 3, y: 5 },
          { x: 4, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 8: OCEAN FISH
  // ==========================================
  {
    id: 'fish',
    name: 'Fish',
    emoji: '🐟',
    category: 'Animals',
    baseWidth: 8,
    baseHeight: 7,
    description: 'Gliding Ocean Fish',
    strokes: [
      // Mouth & Upper Dorsal Spine
      {
        points: [
          { x: 1, y: 3 },
          { x: 2, y: 2 },
          { x: 3, y: 1 },
          { x: 4, y: 1 },
          { x: 5, y: 2 },
        ],
        preferredDir: 'RIGHT',
      },
      // Mouth & Lower Belly Spine
      {
        points: [
          { x: 1, y: 3 },
          { x: 2, y: 4 },
          { x: 3, y: 5 },
          { x: 4, y: 5 },
          { x: 5, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
      // Tail Fin Upper Lobe
      {
        points: [
          { x: 5, y: 2 },
          { x: 6, y: 3 },
          { x: 7, y: 2 },
          { x: 7, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Tail Fin Lower Lobe
      {
        points: [
          { x: 5, y: 4 },
          { x: 6, y: 3 },
          { x: 7, y: 4 },
          { x: 7, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
      // Eye & Gill Curve
      {
        points: [
          { x: 3, y: 2 },
          { x: 3, y: 3 },
          { x: 3, y: 4 },
        ],
        preferredDir: 'UP',
      },
      // Pectoral Fin
      {
        points: [
          { x: 4, y: 3 },
          { x: 4, y: 4 },
        ],
        preferredDir: 'DOWN',
        isDetail: true,
        minLevel: 4,
      },
    ],
  },

  // ==========================================
  // LEVEL 9: CITY CAR
  // ==========================================
  {
    id: 'car',
    name: 'Car',
    emoji: '🚗',
    category: 'Vehicles',
    baseWidth: 8,
    baseHeight: 7,
    description: 'Chassis, Roof & Wheels',
    strokes: [
      // Hood & Front Bumper
      {
        points: [
          { x: 1, y: 4 },
          { x: 0, y: 4 },
          { x: 0, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
      // Windshield & Roof
      {
        points: [
          { x: 1, y: 4 },
          { x: 2, y: 3 },
          { x: 3, y: 2 },
          { x: 4, y: 2 },
          { x: 5, y: 2 },
          { x: 6, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Rear Trunk & Tail
      {
        points: [
          { x: 6, y: 3 },
          { x: 7, y: 4 },
          { x: 7, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
      // Front Wheel Arch
      {
        points: [
          { x: 1, y: 5 },
          { x: 1, y: 6 },
          { x: 2, y: 6 },
          { x: 2, y: 5 },
        ],
        preferredDir: 'UP',
      },
      // Rear Wheel Arch
      {
        points: [
          { x: 5, y: 5 },
          { x: 5, y: 6 },
          { x: 6, y: 6 },
          { x: 6, y: 5 },
        ],
        preferredDir: 'UP',
      },
      // Chassis Bottom Rail
      {
        points: [
          { x: 2, y: 5 },
          { x: 3, y: 5 },
          { x: 4, y: 5 },
          { x: 5, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
      // Window Pillar
      {
        points: [
          { x: 4, y: 3 },
          { x: 4, y: 4 },
        ],
        preferredDir: 'DOWN',
        isDetail: true,
        minLevel: 5,
      },
    ],
  },

  // ==========================================
  // LEVEL 10: FIVE-POINT STAR
  // ==========================================
  {
    id: 'star',
    name: 'Radiant Star',
    emoji: '⭐',
    category: 'Symbols',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Symmetrical Star Wireframe',
    strokes: [
      // Top Peak
      {
        points: [
          { x: 2, y: 2 },
          { x: 3, y: 0 },
          { x: 4, y: 2 },
        ],
        preferredDir: 'UP',
      },
      // Left Wing Point
      {
        points: [
          { x: 2, y: 2 },
          { x: 0, y: 3 },
          { x: 2, y: 4 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Wing Point
      {
        points: [
          { x: 4, y: 2 },
          { x: 6, y: 3 },
          { x: 4, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
      // Bottom Left Point
      {
        points: [
          { x: 2, y: 4 },
          { x: 1, y: 6 },
          { x: 3, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
      // Bottom Right Point
      {
        points: [
          { x: 4, y: 4 },
          { x: 5, y: 6 },
          { x: 3, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
      // Star Core Center
      {
        points: [
          { x: 3, y: 2 },
          { x: 3, y: 3 },
          { x: 3, y: 4 },
        ],
        preferredDir: 'UP',
        isDetail: true,
        minLevel: 4,
      },
    ],
  },

  // ==========================================
  // LEVEL 11: SPACE ROCKET
  // ==========================================
  {
    id: 'rocket',
    name: 'Space Rocket',
    emoji: '🚀',
    category: 'Space',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Nosecone, Fuselage & Thrusters',
    strokes: [
      // Nosecone Peak
      {
        points: [
          { x: 3, y: 0 },
          { x: 2, y: 1 },
          { x: 4, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Left Fuselage Wall
      {
        points: [
          { x: 2, y: 1 },
          { x: 2, y: 2 },
          { x: 2, y: 3 },
          { x: 2, y: 4 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Fuselage Wall
      {
        points: [
          { x: 4, y: 1 },
          { x: 4, y: 2 },
          { x: 4, y: 3 },
          { x: 4, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
      // Porthole Window
      {
        points: [
          { x: 3, y: 2 },
          { x: 3, y: 3 },
        ],
        preferredDir: 'UP',
      },
      // Left Stabilizer Fin
      {
        points: [
          { x: 2, y: 4 },
          { x: 1, y: 5 },
          { x: 1, y: 6 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Stabilizer Fin
      {
        points: [
          { x: 4, y: 4 },
          { x: 5, y: 5 },
          { x: 5, y: 6 },
        ],
        preferredDir: 'RIGHT',
      },
      // Exhaust Flame Jet
      {
        points: [
          { x: 3, y: 5 },
          { x: 3, y: 6 },
          { x: 3, y: 7 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 12: CURIOUS CAT
  // ==========================================
  {
    id: 'cat',
    name: 'Curious Cat',
    emoji: '🐱',
    category: 'Animals',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Pointed Ears & Curled Tail',
    strokes: [
      // Left Pointed Ear
      {
        points: [
          { x: 1, y: 2 },
          { x: 1, y: 0 },
          { x: 2, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Right Pointed Ear
      {
        points: [
          { x: 5, y: 2 },
          { x: 5, y: 0 },
          { x: 4, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Crown between ears
      {
        points: [
          { x: 2, y: 1 },
          { x: 3, y: 1 },
          { x: 4, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Left Cheek & Whiskers
      {
        points: [
          { x: 1, y: 2 },
          { x: 0, y: 3 },
          { x: 1, y: 4 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Cheek & Whiskers
      {
        points: [
          { x: 5, y: 2 },
          { x: 6, y: 3 },
          { x: 5, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
      // Body Base & Paws
      {
        points: [
          { x: 2, y: 4 },
          { x: 2, y: 6 },
          { x: 3, y: 6 },
          { x: 4, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Curled Tail Upwards
      {
        points: [
          { x: 4, y: 6 },
          { x: 5, y: 6 },
          { x: 6, y: 5 },
          { x: 6, y: 4 },
        ],
        preferredDir: 'UP',
      },
      // Snout / Nose
      {
        points: [
          { x: 3, y: 3 },
          { x: 3, y: 4 },
        ],
        preferredDir: 'DOWN',
        isDetail: true,
        minLevel: 4,
      },
    ],
  },

  // ==========================================
  // LEVEL 13: ROYAL CROWN
  // ==========================================
  {
    id: 'crown',
    name: 'Royal Crown',
    emoji: '👑',
    category: 'Symbols',
    baseWidth: 8,
    baseHeight: 7,
    description: 'Spiked Peaks & Jeweled Rim',
    strokes: [
      // Base Circlet Band
      {
        points: [
          { x: 1, y: 5 },
          { x: 2, y: 5 },
          { x: 3, y: 5 },
          { x: 4, y: 5 },
          { x: 5, y: 5 },
          { x: 6, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
      // Central High Peak
      {
        points: [
          { x: 3, y: 4 },
          { x: 3, y: 1 },
          { x: 4, y: 1 },
          { x: 4, y: 4 },
        ],
        preferredDir: 'UP',
      },
      // Left Peak
      {
        points: [
          { x: 1, y: 4 },
          { x: 1, y: 2 },
          { x: 2, y: 2 },
          { x: 2, y: 4 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Peak
      {
        points: [
          { x: 5, y: 4 },
          { x: 5, y: 2 },
          { x: 6, y: 2 },
          { x: 6, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
      // Jewel Inset 1
      {
        points: [
          { x: 2, y: 4 },
          { x: 3, y: 4 },
        ],
        preferredDir: 'DOWN',
      },
      // Jewel Inset 2
      {
        points: [
          { x: 4, y: 4 },
          { x: 5, y: 4 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 14: STEAMING COFFEE MUG
  // ==========================================
  {
    id: 'coffee',
    name: 'Coffee Mug',
    emoji: '☕',
    category: 'Objects',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Ceramic Cup & Rising Steam',
    strokes: [
      // Left Steam Wisp
      {
        points: [
          { x: 2, y: 2 },
          { x: 1, y: 1 },
          { x: 2, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // Right Steam Wisp
      {
        points: [
          { x: 4, y: 2 },
          { x: 5, y: 1 },
          { x: 4, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // Cup Rim & Left Wall
      {
        points: [
          { x: 1, y: 3 },
          { x: 1, y: 6 },
          { x: 2, y: 6 },
        ],
        preferredDir: 'LEFT',
      },
      // Cup Right Wall & Base
      {
        points: [
          { x: 4, y: 3 },
          { x: 4, y: 6 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Top Rim Line
      {
        points: [
          { x: 1, y: 3 },
          { x: 2, y: 3 },
          { x: 3, y: 3 },
          { x: 4, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Side Handle Loop
      {
        points: [
          { x: 4, y: 4 },
          { x: 5, y: 4 },
          { x: 5, y: 5 },
          { x: 4, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 15: BICYCLE
  // ==========================================
  {
    id: 'bicycle',
    name: 'Bicycle',
    emoji: '🚲',
    category: 'Vehicles',
    baseWidth: 8,
    baseHeight: 7,
    description: 'Diamond Frame & Twin Wheels',
    strokes: [
      // Front Wheel Loop
      {
        points: [
          { x: 6, y: 4 },
          { x: 7, y: 5 },
          { x: 6, y: 6 },
          { x: 5, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
      // Rear Wheel Loop
      {
        points: [
          { x: 1, y: 4 },
          { x: 2, y: 5 },
          { x: 1, y: 6 },
          { x: 0, y: 5 },
        ],
        preferredDir: 'LEFT',
      },
      // Fork & Handlebars
      {
        points: [
          { x: 6, y: 5 },
          { x: 5, y: 3 },
          { x: 5, y: 2 },
          { x: 6, y: 2 },
        ],
        preferredDir: 'UP',
      },
      // Top Tube & Seat Post
      {
        points: [
          { x: 5, y: 3 },
          { x: 3, y: 3 },
          { x: 3, y: 2 },
          { x: 2, y: 2 },
        ],
        preferredDir: 'LEFT',
      },
      // Down Tube to Bottom Bracket
      {
        points: [
          { x: 5, y: 3 },
          { x: 3, y: 5 },
          { x: 1, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
      // Seat Stays to Rear Axle
      {
        points: [
          { x: 3, y: 3 },
          { x: 1, y: 5 },
        ],
        preferredDir: 'DOWN',
        isDetail: true,
        minLevel: 5,
      },
    ],
  },

  // ==========================================
  // LEVEL 16: HEAVY PADLOCK
  // ==========================================
  {
    id: 'lock',
    name: 'Padlock',
    emoji: '🔒',
    category: 'Tools',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Hardened Shackle & Brass Body',
    strokes: [
      // Shackle Loop Left
      {
        points: [
          { x: 2, y: 3 },
          { x: 2, y: 1 },
          { x: 3, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Shackle Loop Right
      {
        points: [
          { x: 4, y: 3 },
          { x: 4, y: 1 },
          { x: 3, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Lock Body Top & Left
      {
        points: [
          { x: 1, y: 3 },
          { x: 5, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Lock Body Left Wall
      {
        points: [
          { x: 1, y: 3 },
          { x: 1, y: 6 },
          { x: 2, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Lock Body Right Wall & Bottom
      {
        points: [
          { x: 5, y: 3 },
          { x: 5, y: 6 },
          { x: 4, y: 6 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Keyhole Slit
      {
        points: [
          { x: 3, y: 4 },
          { x: 3, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 17: ALARM CLOCK
  // ==========================================
  {
    id: 'clock',
    name: 'Alarm Clock',
    emoji: '⏰',
    category: 'Objects',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Twin Bells & Clock Hands',
    strokes: [
      // Left Top Bell
      {
        points: [
          { x: 1, y: 2 },
          { x: 1, y: 0 },
          { x: 2, y: 0 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Top Bell
      {
        points: [
          { x: 5, y: 2 },
          { x: 5, y: 0 },
          { x: 4, y: 0 },
        ],
        preferredDir: 'RIGHT',
      },
      // Clock Rim Left Half
      {
        points: [
          { x: 3, y: 1 },
          { x: 1, y: 2 },
          { x: 1, y: 4 },
          { x: 2, y: 5 },
        ],
        preferredDir: 'LEFT',
      },
      // Clock Rim Right Half
      {
        points: [
          { x: 3, y: 1 },
          { x: 5, y: 2 },
          { x: 5, y: 4 },
          { x: 4, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
      // Hour & Minute Hands (10:10)
      {
        points: [
          { x: 3, y: 3 },
          { x: 2, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      {
        points: [
          { x: 3, y: 3 },
          { x: 3, y: 2 },
          { x: 4, y: 2 },
        ],
        preferredDir: 'RIGHT',
      },
      // Left & Right Foot Pegs
      {
        points: [
          { x: 1, y: 5 },
          { x: 0, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      {
        points: [
          { x: 5, y: 5 },
          { x: 6, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 18: KNIGHT'S SWORD
  // ==========================================
  {
    id: 'sword',
    name: 'Sword',
    emoji: '🗡️',
    category: 'Tools',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Forged Blade, Guard & Pommel',
    strokes: [
      // Blade Tip & Left Edge
      {
        points: [
          { x: 3, y: 0 },
          { x: 2, y: 1 },
          { x: 2, y: 2 },
          { x: 2, y: 3 },
          { x: 2, y: 4 },
        ],
        preferredDir: 'UP',
      },
      // Blade Tip & Right Edge
      {
        points: [
          { x: 3, y: 0 },
          { x: 4, y: 1 },
          { x: 4, y: 2 },
          { x: 4, y: 3 },
          { x: 4, y: 4 },
        ],
        preferredDir: 'UP',
      },
      // Central Fuller Ridge
      {
        points: [
          { x: 3, y: 1 },
          { x: 3, y: 2 },
          { x: 3, y: 3 },
          { x: 3, y: 4 },
        ],
        preferredDir: 'DOWN',
      },
      // Crossguard Left Wing
      {
        points: [
          { x: 2, y: 5 },
          { x: 1, y: 5 },
          { x: 0, y: 5 },
        ],
        preferredDir: 'LEFT',
      },
      // Crossguard Right Wing
      {
        points: [
          { x: 4, y: 5 },
          { x: 5, y: 5 },
          { x: 6, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
      // Hilt Grip & Pommel
      {
        points: [
          { x: 3, y: 5 },
          { x: 3, y: 6 },
          { x: 3, y: 7 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 19: MONARCH BUTTERFLY
  // ==========================================
  {
    id: 'butterfly',
    name: 'Butterfly',
    emoji: '🦋',
    category: 'Animals',
    baseWidth: 8,
    baseHeight: 7,
    description: 'Wing Patterns & Antennae',
    strokes: [
      // Left Antenna
      {
        points: [
          { x: 3, y: 1 },
          { x: 2, y: 0 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Antenna
      {
        points: [
          { x: 4, y: 1 },
          { x: 5, y: 0 },
        ],
        preferredDir: 'RIGHT',
      },
      // Central Body Spine
      {
        points: [
          { x: 3, y: 1 },
          { x: 3, y: 2 },
          { x: 3, y: 3 },
          { x: 3, y: 4 },
          { x: 3, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
      // Upper Left Wing
      {
        points: [
          { x: 2, y: 2 },
          { x: 1, y: 1 },
          { x: 0, y: 2 },
          { x: 1, y: 3 },
          { x: 2, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // Upper Right Wing
      {
        points: [
          { x: 5, y: 2 },
          { x: 6, y: 1 },
          { x: 7, y: 2 },
          { x: 6, y: 3 },
          { x: 5, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Lower Left Wing
      {
        points: [
          { x: 2, y: 4 },
          { x: 1, y: 4 },
          { x: 1, y: 5 },
          { x: 2, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
      // Lower Right Wing
      {
        points: [
          { x: 5, y: 4 },
          { x: 6, y: 4 },
          { x: 6, y: 5 },
          { x: 5, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 20: RADIANT SUN
  // ==========================================
  {
    id: 'sun',
    name: 'Radiant Sun',
    emoji: '☀️',
    category: 'Space',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Solar Core & Radiating Rays',
    strokes: [
      // Core Diamond / Square
      {
        points: [
          { x: 3, y: 2 },
          { x: 2, y: 3 },
          { x: 3, y: 4 },
          { x: 4, y: 3 },
        ],
        preferredDir: 'UP',
      },
      // North Ray
      {
        points: [
          { x: 3, y: 1 },
          { x: 3, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // South Ray
      {
        points: [
          { x: 3, y: 5 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // West Ray
      {
        points: [
          { x: 1, y: 3 },
          { x: 0, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // East Ray
      {
        points: [
          { x: 5, y: 3 },
          { x: 6, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // NW Diagonal Ray
      {
        points: [
          { x: 2, y: 2 },
          { x: 1, y: 1 },
        ],
        preferredDir: 'LEFT',
      },
      // NE Diagonal Ray
      {
        points: [
          { x: 4, y: 2 },
          { x: 5, y: 1 },
        ],
        preferredDir: 'RIGHT',
      },
      // SW Diagonal Ray
      {
        points: [
          { x: 2, y: 4 },
          { x: 1, y: 5 },
        ],
        preferredDir: 'LEFT',
      },
      // SE Diagonal Ray
      {
        points: [
          { x: 4, y: 4 },
          { x: 5, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 21: CRESCENT MOON
  // ==========================================
  {
    id: 'moon',
    name: 'Crescent Moon',
    emoji: '🌙',
    category: 'Space',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Slender Lunar Arc & Star',
    strokes: [
      // Outer Curve Top
      {
        points: [
          { x: 4, y: 0 },
          { x: 3, y: 0 },
          { x: 2, y: 1 },
          { x: 1, y: 2 },
        ],
        preferredDir: 'UP',
      },
      // Outer Curve Middle & Bottom
      {
        points: [
          { x: 1, y: 2 },
          { x: 1, y: 4 },
          { x: 2, y: 5 },
          { x: 3, y: 6 },
          { x: 4, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Inner Cusp Top
      {
        points: [
          { x: 4, y: 0 },
          { x: 3, y: 2 },
          { x: 2, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Inner Cusp Bottom
      {
        points: [
          { x: 4, y: 6 },
          { x: 3, y: 4 },
          { x: 2, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Accompanying Tiny Star
      {
        points: [
          { x: 5, y: 3 },
          { x: 5, y: 2 },
        ],
        preferredDir: 'UP',
      },
      {
        points: [
          { x: 5, y: 3 },
          { x: 6, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 22: ACOUSTIC GUITAR
  // ==========================================
  {
    id: 'guitar',
    name: 'Guitar',
    emoji: '🎸',
    category: 'Objects',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Headstock, Neck & Resonator',
    strokes: [
      // Headstock & Tuning Pegs
      {
        points: [
          { x: 3, y: 0 },
          { x: 2, y: 0 },
          { x: 4, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // Long Fretboard Neck
      {
        points: [
          { x: 3, y: 0 },
          { x: 3, y: 1 },
          { x: 3, y: 2 },
          { x: 3, y: 3 },
        ],
        preferredDir: 'DOWN',
      },
      // Upper Body Bout Left
      {
        points: [
          { x: 3, y: 3 },
          { x: 2, y: 4 },
          { x: 1, y: 4 },
          { x: 1, y: 5 },
        ],
        preferredDir: 'LEFT',
      },
      // Upper Body Bout Right
      {
        points: [
          { x: 3, y: 3 },
          { x: 4, y: 4 },
          { x: 5, y: 4 },
          { x: 5, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
      // Lower Body Bout Left & Base
      {
        points: [
          { x: 1, y: 5 },
          { x: 0, y: 6 },
          { x: 1, y: 7 },
          { x: 3, y: 7 },
        ],
        preferredDir: 'DOWN',
      },
      // Lower Body Bout Right & Base
      {
        points: [
          { x: 5, y: 5 },
          { x: 6, y: 6 },
          { x: 5, y: 7 },
          { x: 3, y: 7 },
        ],
        preferredDir: 'DOWN',
      },
      // Sound Hole
      {
        points: [
          { x: 3, y: 4 },
          { x: 3, y: 5 },
        ],
        preferredDir: 'UP',
        isDetail: true,
        minLevel: 4,
      },
    ],
  },

  // ==========================================
  // LEVEL 23: PLAYFUL PUPPY
  // ==========================================
  {
    id: 'dog',
    name: 'Playful Dog',
    emoji: '🐶',
    category: 'Animals',
    baseWidth: 8,
    baseHeight: 7,
    description: 'Floppy Ears & Wagging Tail',
    strokes: [
      // Snout pointing left
      {
        points: [
          { x: 1, y: 2 },
          { x: 0, y: 2 },
          { x: 0, y: 3 },
          { x: 1, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // Forehead & Crown
      {
        points: [
          { x: 1, y: 2 },
          { x: 2, y: 1 },
          { x: 3, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Floppy Ear Drooping
      {
        points: [
          { x: 3, y: 1 },
          { x: 4, y: 2 },
          { x: 4, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Back Spine
      {
        points: [
          { x: 3, y: 2 },
          { x: 4, y: 3 },
          { x: 5, y: 3 },
          { x: 6, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
      // Front Leg
      {
        points: [
          { x: 2, y: 4 },
          { x: 2, y: 5 },
          { x: 2, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Rear Leg
      {
        points: [
          { x: 5, y: 4 },
          { x: 5, y: 5 },
          { x: 5, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Perky Upright Tail
      {
        points: [
          { x: 6, y: 4 },
          { x: 7, y: 3 },
          { x: 7, y: 2 },
        ],
        preferredDir: 'UP',
      },
    ],
  },

  // ==========================================
  // LEVEL 24: NAUTICAL ANCHOR
  // ==========================================
  {
    id: 'anchor',
    name: 'Anchor',
    emoji: '⚓',
    category: 'Objects',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Stock, Shank & Curved Flukes',
    strokes: [
      // Top Ring Loop
      {
        points: [
          { x: 3, y: 1 },
          { x: 2, y: 0 },
          { x: 3, y: 0 },
          { x: 4, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // Horizontal Stock Bar
      {
        points: [
          { x: 1, y: 2 },
          { x: 2, y: 2 },
          { x: 3, y: 2 },
          { x: 4, y: 2 },
          { x: 5, y: 2 },
        ],
        preferredDir: 'RIGHT',
      },
      // Vertical Center Shank
      {
        points: [
          { x: 3, y: 1 },
          { x: 3, y: 3 },
          { x: 3, y: 4 },
          { x: 3, y: 5 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Left Curved Fluke & Tip
      {
        points: [
          { x: 3, y: 6 },
          { x: 2, y: 7 },
          { x: 1, y: 6 },
          { x: 1, y: 5 },
        ],
        preferredDir: 'UP',
      },
      // Right Curved Fluke & Tip
      {
        points: [
          { x: 3, y: 6 },
          { x: 4, y: 7 },
          { x: 5, y: 6 },
          { x: 5, y: 5 },
        ],
        preferredDir: 'UP',
      },
    ],
  },

  // ==========================================
  // LEVEL 25: JET AIRPLANE
  // ==========================================
  {
    id: 'airplane',
    name: 'Airplane',
    emoji: '✈️',
    category: 'Vehicles',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Fuselage, Wings & Tailplane',
    strokes: [
      // Nosecone & Cockpit
      {
        points: [
          { x: 3, y: 0 },
          { x: 3, y: 1 },
          { x: 3, y: 2 },
        ],
        preferredDir: 'UP',
      },
      // Left Wing Span
      {
        points: [
          { x: 3, y: 2 },
          { x: 2, y: 3 },
          { x: 1, y: 4 },
          { x: 0, y: 4 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Wing Span
      {
        points: [
          { x: 3, y: 2 },
          { x: 4, y: 3 },
          { x: 5, y: 4 },
          { x: 6, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
      // Mid & Aft Fuselage
      {
        points: [
          { x: 3, y: 3 },
          { x: 3, y: 4 },
          { x: 3, y: 5 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Left Tail Stabilizer
      {
        points: [
          { x: 3, y: 6 },
          { x: 2, y: 7 },
          { x: 1, y: 7 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Tail Stabilizer
      {
        points: [
          { x: 3, y: 6 },
          { x: 4, y: 7 },
          { x: 5, y: 7 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 26: FACETED GEMSTONE
  // ==========================================
  {
    id: 'diamond',
    name: 'Diamond Gem',
    emoji: '💎',
    category: 'Symbols',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Faceted Crown & Pavilion Point',
    strokes: [
      // Flat Table Top
      {
        points: [
          { x: 2, y: 1 },
          { x: 3, y: 1 },
          { x: 4, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Left Crown Corner
      {
        points: [
          { x: 2, y: 1 },
          { x: 1, y: 2 },
          { x: 0, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Crown Corner
      {
        points: [
          { x: 4, y: 1 },
          { x: 5, y: 2 },
          { x: 6, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Left Pavilion Lower Slope to Point
      {
        points: [
          { x: 0, y: 3 },
          { x: 1, y: 4 },
          { x: 2, y: 5 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Right Pavilion Lower Slope to Point
      {
        points: [
          { x: 6, y: 3 },
          { x: 5, y: 4 },
          { x: 4, y: 5 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Girdle Center Inset
      {
        points: [
          { x: 2, y: 3 },
          { x: 3, y: 3 },
          { x: 4, y: 3 },
        ],
        preferredDir: 'UP',
        isDetail: true,
        minLevel: 4,
      },
    ],
  },

  // ==========================================
  // LEVEL 27: WOODLAND MUSHROOM
  // ==========================================
  {
    id: 'mushroom',
    name: 'Mushroom',
    emoji: '🍄',
    category: 'Nature',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Domed Cap & Thick Stem',
    strokes: [
      // Cap Dome Top Arc
      {
        points: [
          { x: 2, y: 1 },
          { x: 3, y: 1 },
          { x: 4, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Cap Left Flange
      {
        points: [
          { x: 2, y: 1 },
          { x: 1, y: 2 },
          { x: 0, y: 3 },
          { x: 1, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // Cap Right Flange
      {
        points: [
          { x: 4, y: 1 },
          { x: 5, y: 2 },
          { x: 6, y: 3 },
          { x: 5, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Cap Gills Underside
      {
        points: [
          { x: 1, y: 3 },
          { x: 2, y: 3 },
          { x: 3, y: 3 },
          { x: 4, y: 3 },
          { x: 5, y: 3 },
        ],
        preferredDir: 'UP',
      },
      // Left Stem Wall
      {
        points: [
          { x: 2, y: 4 },
          { x: 2, y: 5 },
          { x: 2, y: 6 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Stem Wall
      {
        points: [
          { x: 4, y: 4 },
          { x: 4, y: 5 },
          { x: 4, y: 6 },
        ],
        preferredDir: 'RIGHT',
      },
      // Base Earth / Spores
      {
        points: [
          { x: 2, y: 6 },
          { x: 3, y: 6 },
          { x: 4, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 28: DESERT SAGUARO CACTUS
  // ==========================================
  {
    id: 'cactus',
    name: 'Cactus',
    emoji: '🌵',
    category: 'Nature',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Saguaro Trunk & Upcurved Arms',
    strokes: [
      // Central High Trunk Top
      {
        points: [
          { x: 3, y: 0 },
          { x: 3, y: 1 },
          { x: 3, y: 2 },
        ],
        preferredDir: 'UP',
      },
      // Left Branch Arm (reaches out and bends up)
      {
        points: [
          { x: 3, y: 3 },
          { x: 2, y: 3 },
          { x: 1, y: 3 },
          { x: 1, y: 2 },
          { x: 1, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Right Branch Arm (reaches out and bends up)
      {
        points: [
          { x: 3, y: 4 },
          { x: 4, y: 4 },
          { x: 5, y: 4 },
          { x: 5, y: 3 },
          { x: 5, y: 2 },
        ],
        preferredDir: 'UP',
      },
      // Lower Central Trunk
      {
        points: [
          { x: 3, y: 3 },
          { x: 3, y: 4 },
          { x: 3, y: 5 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Pot / Sand Dune Base
      {
        points: [
          { x: 2, y: 7 },
          { x: 3, y: 7 },
          { x: 4, y: 7 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 29: RAIN UMBRELLA
  // ==========================================
  {
    id: 'umbrella',
    name: 'Umbrella',
    emoji: '☂️',
    category: 'Objects',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Arched Canopy & Hooked Handle',
    strokes: [
      // Top Ferrule Spike
      {
        points: [
          { x: 3, y: 0 },
          { x: 3, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Canopy Left Arc
      {
        points: [
          { x: 3, y: 1 },
          { x: 2, y: 1 },
          { x: 1, y: 2 },
          { x: 0, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // Canopy Right Arc
      {
        points: [
          { x: 3, y: 1 },
          { x: 4, y: 1 },
          { x: 5, y: 2 },
          { x: 6, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Canopy Bottom Rim
      {
        points: [
          { x: 0, y: 3 },
          { x: 2, y: 3 },
          { x: 4, y: 3 },
          { x: 6, y: 3 },
        ],
        preferredDir: 'DOWN',
      },
      // Central Shaft
      {
        points: [
          { x: 3, y: 2 },
          { x: 3, y: 4 },
          { x: 3, y: 5 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Hooked J-Handle
      {
        points: [
          { x: 3, y: 6 },
          { x: 2, y: 7 },
          { x: 1, y: 7 },
          { x: 1, y: 6 },
        ],
        preferredDir: 'UP',
      },
    ],
  },

  // ==========================================
  // LEVEL 30: INCANDESCENT LIGHTBULB
  // ==========================================
  {
    id: 'lightbulb',
    name: 'Lightbulb',
    emoji: '💡',
    category: 'Objects',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Glass Bulb & Glowing Filament',
    strokes: [
      // Dome Top
      {
        points: [
          { x: 2, y: 1 },
          { x: 3, y: 0 },
          { x: 4, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Left Bulb Globe
      {
        points: [
          { x: 2, y: 1 },
          { x: 1, y: 2 },
          { x: 1, y: 3 },
          { x: 2, y: 4 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Bulb Globe
      {
        points: [
          { x: 4, y: 1 },
          { x: 5, y: 2 },
          { x: 5, y: 3 },
          { x: 4, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
      // Glowing Filament Core
      {
        points: [
          { x: 3, y: 2 },
          { x: 3, y: 3 },
        ],
        preferredDir: 'UP',
      },
      // Screw Base Thread 1
      {
        points: [
          { x: 2, y: 5 },
          { x: 3, y: 5 },
          { x: 4, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
      // Screw Base Thread 2
      {
        points: [
          { x: 2, y: 6 },
          { x: 3, y: 6 },
          { x: 4, y: 6 },
        ],
        preferredDir: 'RIGHT',
      },
      // Bottom Electrical Contact
      {
        points: [
          { x: 3, y: 7 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 31: MAJESTIC ELEPHANT
  // ==========================================
  {
    id: 'elephant',
    name: 'Elephant',
    emoji: '🐘',
    category: 'Animals',
    baseWidth: 8,
    baseHeight: 7,
    description: 'Curved Trunk & Sturdy Stance',
    strokes: [
      // Raised Trunk Loop
      {
        points: [
          { x: 1, y: 1 },
          { x: 0, y: 2 },
          { x: 0, y: 3 },
          { x: 1, y: 3 },
        ],
        preferredDir: 'UP',
      },
      // Forehead & Crown
      {
        points: [
          { x: 1, y: 2 },
          { x: 2, y: 1 },
          { x: 3, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Flapping Ear
      {
        points: [
          { x: 3, y: 1 },
          { x: 3, y: 2 },
          { x: 2, y: 3 },
          { x: 3, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // Broad Back Arc
      {
        points: [
          { x: 3, y: 1 },
          { x: 4, y: 1 },
          { x: 5, y: 2 },
          { x: 6, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Front Sturdy Leg
      {
        points: [
          { x: 2, y: 4 },
          { x: 2, y: 5 },
          { x: 2, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Rear Sturdy Leg
      {
        points: [
          { x: 5, y: 4 },
          { x: 5, y: 5 },
          { x: 5, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Belly & Tail
      {
        points: [
          { x: 6, y: 3 },
          { x: 7, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 32: SUSPENSION BRIDGE
  // ==========================================
  {
    id: 'bridge',
    name: 'Suspension Bridge',
    emoji: '🌉',
    category: 'Architecture',
    baseWidth: 8,
    baseHeight: 7,
    description: 'Twin Towers & Suspension Cables',
    strokes: [
      // Left Suspension Tower
      {
        points: [
          { x: 2, y: 1 },
          { x: 2, y: 2 },
          { x: 2, y: 3 },
          { x: 2, y: 4 },
        ],
        preferredDir: 'UP',
      },
      // Right Suspension Tower
      {
        points: [
          { x: 5, y: 1 },
          { x: 5, y: 2 },
          { x: 5, y: 3 },
          { x: 5, y: 4 },
        ],
        preferredDir: 'UP',
      },
      // Central Cable Sag Arc
      {
        points: [
          { x: 2, y: 1 },
          { x: 3, y: 2 },
          { x: 4, y: 2 },
          { x: 5, y: 1 },
        ],
        preferredDir: 'DOWN',
      },
      // Main Roadway Deck
      {
        points: [
          { x: 0, y: 4 },
          { x: 1, y: 4 },
          { x: 2, y: 4 },
          { x: 3, y: 4 },
          { x: 4, y: 4 },
          { x: 5, y: 4 },
          { x: 6, y: 4 },
          { x: 7, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
      // Left Water Pier
      {
        points: [
          { x: 2, y: 5 },
          { x: 2, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Right Water Pier
      {
        points: [
          { x: 5, y: 5 },
          { x: 5, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 33: MODERN SMARTPHONE
  // ==========================================
  {
    id: 'phone',
    name: 'Smartphone',
    emoji: '📱',
    category: 'Objects',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Slim Bezel & Camera Island',
    strokes: [
      // Top Chassis & Speaker
      {
        points: [
          { x: 1, y: 1 },
          { x: 2, y: 1 },
          { x: 3, y: 1 },
          { x: 4, y: 1 },
          { x: 5, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Left Chassis Wall
      {
        points: [
          { x: 1, y: 1 },
          { x: 1, y: 3 },
          { x: 1, y: 5 },
          { x: 1, y: 7 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Chassis Wall
      {
        points: [
          { x: 5, y: 1 },
          { x: 5, y: 3 },
          { x: 5, y: 5 },
          { x: 5, y: 7 },
        ],
        preferredDir: 'RIGHT',
      },
      // Bottom Bezel & Home Bar
      {
        points: [
          { x: 1, y: 7 },
          { x: 2, y: 7 },
          { x: 3, y: 7 },
          { x: 4, y: 7 },
          { x: 5, y: 7 },
        ],
        preferredDir: 'DOWN',
      },
      // Center Screen UI Message Box
      {
        points: [
          { x: 2, y: 3 },
          { x: 3, y: 3 },
          { x: 4, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      {
        points: [
          { x: 2, y: 5 },
          { x: 3, y: 5 },
        ],
        preferredDir: 'LEFT',
      },
    ],
  },

  // ==========================================
  // LEVEL 34: CRISP APPLE
  // ==========================================
  {
    id: 'apple',
    name: 'Apple',
    emoji: '🍎',
    category: 'Nature',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Curved Stem, Leaf & Round Fruit',
    strokes: [
      // Curved Stem
      {
        points: [
          { x: 3, y: 1 },
          { x: 3, y: 0 },
          { x: 4, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // Sprouting Leaf
      {
        points: [
          { x: 3, y: 1 },
          { x: 4, y: 1 },
          { x: 5, y: 1 },
        ],
        preferredDir: 'RIGHT',
      },
      // Left Apple Lobe
      {
        points: [
          { x: 3, y: 2 },
          { x: 2, y: 1 },
          { x: 1, y: 2 },
          { x: 1, y: 4 },
          { x: 2, y: 5 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Apple Lobe
      {
        points: [
          { x: 3, y: 2 },
          { x: 4, y: 1 },
          { x: 5, y: 2 },
          { x: 5, y: 4 },
          { x: 4, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
      // Bottom Indentation
      {
        points: [
          { x: 2, y: 5 },
          { x: 3, y: 6 },
          { x: 4, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 35: RETRO CAMERA
  // ==========================================
  {
    id: 'camera',
    name: 'Camera',
    emoji: '📷',
    category: 'Objects',
    baseWidth: 8,
    baseHeight: 7,
    description: 'Chassis Body, Shutter & Lens',
    strokes: [
      // Shutter Button & Flash Unit
      {
        points: [
          { x: 2, y: 1 },
          { x: 2, y: 2 },
        ],
        preferredDir: 'UP',
      },
      {
        points: [
          { x: 5, y: 1 },
          { x: 5, y: 2 },
        ],
        preferredDir: 'UP',
      },
      // Top Chassis Plate
      {
        points: [
          { x: 1, y: 2 },
          { x: 3, y: 2 },
          { x: 6, y: 2 },
        ],
        preferredDir: 'UP',
      },
      // Left Body Wall
      {
        points: [
          { x: 1, y: 2 },
          { x: 1, y: 6 },
          { x: 2, y: 6 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Body Wall
      {
        points: [
          { x: 6, y: 2 },
          { x: 6, y: 6 },
          { x: 5, y: 6 },
        ],
        preferredDir: 'RIGHT',
      },
      // Circular Lens Frame (Left & Right halves)
      {
        points: [
          { x: 3, y: 3 },
          { x: 2, y: 4 },
          { x: 3, y: 5 },
        ],
        preferredDir: 'LEFT',
      },
      {
        points: [
          { x: 4, y: 3 },
          { x: 5, y: 4 },
          { x: 4, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 36: ROYAL CASTLE
  // ==========================================
  {
    id: 'castle',
    name: 'Fortress Castle',
    emoji: '🏰',
    category: 'Architecture',
    baseWidth: 8,
    baseHeight: 8,
    description: 'Twin Turrets & Crenellations',
    strokes: [
      // Left Turret Crenellations & Wall
      {
        points: [
          { x: 1, y: 1 },
          { x: 1, y: 2 },
          { x: 1, y: 4 },
          { x: 1, y: 6 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Turret Crenellations & Wall
      {
        points: [
          { x: 6, y: 1 },
          { x: 6, y: 2 },
          { x: 6, y: 4 },
          { x: 6, y: 6 },
        ],
        preferredDir: 'RIGHT',
      },
      // Center Battlement Wall
      {
        points: [
          { x: 2, y: 3 },
          { x: 3, y: 3 },
          { x: 4, y: 3 },
          { x: 5, y: 3 },
        ],
        preferredDir: 'UP',
      },
      // Center Tower Peak
      {
        points: [
          { x: 3, y: 2 },
          { x: 3, y: 1 },
          { x: 4, y: 1 },
          { x: 4, y: 2 },
        ],
        preferredDir: 'UP',
      },
      // Main Archway Gate
      {
        points: [
          { x: 3, y: 6 },
          { x: 3, y: 4 },
          { x: 4, y: 4 },
          { x: 4, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Left Turret Flag
      {
        points: [
          { x: 1, y: 1 },
          { x: 1, y: 0 },
          { x: 2, y: 0 },
        ],
        preferredDir: 'UP',
      },
    ],
  },

  // ==========================================
  // LEVEL 37: EMPEROR PENGUIN
  // ==========================================
  {
    id: 'penguin',
    name: 'Emperor Penguin',
    emoji: '🐧',
    category: 'Animals',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Tuxedo Body & Flippers',
    strokes: [
      // Beak pointing left
      {
        points: [
          { x: 2, y: 1 },
          { x: 1, y: 1 },
        ],
        preferredDir: 'LEFT',
      },
      // Head & Crown
      {
        points: [
          { x: 2, y: 1 },
          { x: 2, y: 0 },
          { x: 3, y: 0 },
          { x: 4, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Left Flipper Wing
      {
        points: [
          { x: 2, y: 3 },
          { x: 1, y: 4 },
          { x: 1, y: 5 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Back Slope
      {
        points: [
          { x: 4, y: 1 },
          { x: 5, y: 2 },
          { x: 5, y: 4 },
          { x: 4, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
      // White Chest Front
      {
        points: [
          { x: 2, y: 2 },
          { x: 2, y: 4 },
          { x: 3, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
      // Webbed Feet Left & Right
      {
        points: [
          { x: 2, y: 6 },
          { x: 1, y: 6 },
        ],
        preferredDir: 'LEFT',
      },
      {
        points: [
          { x: 4, y: 6 },
          { x: 5, y: 6 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 38: RINGED PLANET SATURN
  // ==========================================
  {
    id: 'saturn',
    name: 'Planet Saturn',
    emoji: '🪐',
    category: 'Space',
    baseWidth: 8,
    baseHeight: 7,
    description: 'Orbital Rings & Gas Giant',
    strokes: [
      // Planet Upper Hemisphere
      {
        points: [
          { x: 3, y: 1 },
          { x: 4, y: 1 },
          { x: 5, y: 2 },
        ],
        preferredDir: 'UP',
      },
      // Planet Lower Hemisphere
      {
        points: [
          { x: 3, y: 5 },
          { x: 4, y: 5 },
          { x: 2, y: 4 },
        ],
        preferredDir: 'DOWN',
      },
      // Left Ring Extension
      {
        points: [
          { x: 2, y: 3 },
          { x: 1, y: 3 },
          { x: 0, y: 4 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Ring Extension
      {
        points: [
          { x: 5, y: 3 },
          { x: 6, y: 3 },
          { x: 7, y: 2 },
        ],
        preferredDir: 'RIGHT',
      },
      // Central Equator Band
      {
        points: [
          { x: 2, y: 3 },
          { x: 3, y: 3 },
          { x: 4, y: 3 },
          { x: 5, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 39: CRAFT SCISSORS
  // ==========================================
  {
    id: 'scissors',
    name: 'Scissors',
    emoji: '✂️',
    category: 'Tools',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Finger Rings, Pivot & Blades',
    strokes: [
      // Left Handle Loop
      {
        points: [
          { x: 1, y: 6 },
          { x: 1, y: 7 },
          { x: 2, y: 7 },
          { x: 2, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Right Handle Loop
      {
        points: [
          { x: 4, y: 6 },
          { x: 4, y: 7 },
          { x: 5, y: 7 },
          { x: 5, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Left Blade (crosses right to tip)
      {
        points: [
          { x: 2, y: 5 },
          { x: 3, y: 4 },
          { x: 4, y: 2 },
          { x: 5, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // Right Blade (crosses left to tip)
      {
        points: [
          { x: 4, y: 5 },
          { x: 3, y: 4 },
          { x: 2, y: 2 },
          { x: 1, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // Center Pivot Screw
      {
        points: [
          { x: 3, y: 4 },
          { x: 3, y: 3 },
        ],
        preferredDir: 'UP',
      },
    ],
  },

  // ==========================================
  // LEVEL 40: ROARING CAMPFIRE
  // ==========================================
  {
    id: 'campfire',
    name: 'Campfire',
    emoji: '🔥',
    category: 'Nature',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Kindling Logs & Leaping Flame',
    strokes: [
      // Left Kindling Log
      {
        points: [
          { x: 1, y: 6 },
          { x: 2, y: 5 },
          { x: 4, y: 5 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Kindling Log
      {
        points: [
          { x: 5, y: 6 },
          { x: 4, y: 5 },
          { x: 2, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
      // Center Tall Flame Tongue
      {
        points: [
          { x: 3, y: 4 },
          { x: 3, y: 2 },
          { x: 3, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // Left Flame Tongue
      {
        points: [
          { x: 2, y: 4 },
          { x: 2, y: 2 },
          { x: 1, y: 1 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Flame Tongue
      {
        points: [
          { x: 4, y: 4 },
          { x: 4, y: 2 },
          { x: 5, y: 1 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 41: ANTIQUE HOURGLASS
  // ==========================================
  {
    id: 'hourglass',
    name: 'Hourglass',
    emoji: '⏳',
    category: 'Objects',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Glass Bulbs & Flowing Sand',
    strokes: [
      // Top Wooden Cap Plate
      {
        points: [
          { x: 1, y: 0 },
          { x: 2, y: 0 },
          { x: 3, y: 0 },
          { x: 4, y: 0 },
          { x: 5, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // Bottom Wooden Base Plate
      {
        points: [
          { x: 1, y: 7 },
          { x: 2, y: 7 },
          { x: 3, y: 7 },
          { x: 4, y: 7 },
          { x: 5, y: 7 },
        ],
        preferredDir: 'DOWN',
      },
      // Upper Bulb Left & Neck
      {
        points: [
          { x: 1, y: 1 },
          { x: 2, y: 2 },
          { x: 3, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // Upper Bulb Right & Neck
      {
        points: [
          { x: 5, y: 1 },
          { x: 4, y: 2 },
          { x: 3, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Lower Bulb Left & Base
      {
        points: [
          { x: 3, y: 4 },
          { x: 2, y: 5 },
          { x: 1, y: 6 },
        ],
        preferredDir: 'LEFT',
      },
      // Lower Bulb Right & Base
      {
        points: [
          { x: 3, y: 4 },
          { x: 4, y: 5 },
          { x: 5, y: 6 },
        ],
        preferredDir: 'RIGHT',
      },
      // Falling Sand Trickle
      {
        points: [
          { x: 3, y: 3 },
          { x: 3, y: 4 },
          { x: 3, y: 5 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 42: CYBER ROBOT
  // ==========================================
  {
    id: 'robot',
    name: 'Cyber Robot',
    emoji: '🤖',
    category: 'Objects',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Antenna, Box Head & Claws',
    strokes: [
      // Top Antenna
      {
        points: [
          { x: 3, y: 0 },
          { x: 3, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Head Box Left & Top
      {
        points: [
          { x: 1, y: 1 },
          { x: 2, y: 1 },
          { x: 4, y: 1 },
          { x: 5, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Head Left Wall
      {
        points: [
          { x: 1, y: 1 },
          { x: 1, y: 3 },
          { x: 2, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // Head Right Wall
      {
        points: [
          { x: 5, y: 1 },
          { x: 5, y: 3 },
          { x: 4, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Left Arm & Pincer
      {
        points: [
          { x: 1, y: 4 },
          { x: 0, y: 4 },
          { x: 0, y: 5 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Arm & Pincer
      {
        points: [
          { x: 5, y: 4 },
          { x: 6, y: 4 },
          { x: 6, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
      // Torso & Chassis
      {
        points: [
          { x: 2, y: 4 },
          { x: 4, y: 4 },
          { x: 4, y: 6 },
          { x: 2, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Left & Right Foot Pads
      {
        points: [
          { x: 2, y: 7 },
          { x: 1, y: 7 },
        ],
        preferredDir: 'DOWN',
      },
      {
        points: [
          { x: 4, y: 7 },
          { x: 5, y: 7 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 43: ROTATING WINDMILL
  // ==========================================
  {
    id: 'windmill',
    name: 'Windmill',
    emoji: '🌬️',
    category: 'Architecture',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Tower Hub & 4 Rotating Sails',
    strokes: [
      // Top Sail Blade
      {
        points: [
          { x: 3, y: 2 },
          { x: 3, y: 1 },
          { x: 3, y: 0 },
          { x: 4, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // Bottom Sail Blade
      {
        points: [
          { x: 3, y: 2 },
          { x: 3, y: 3 },
          { x: 3, y: 4 },
          { x: 2, y: 4 },
        ],
        preferredDir: 'DOWN',
      },
      // Left Sail Blade
      {
        points: [
          { x: 3, y: 2 },
          { x: 2, y: 2 },
          { x: 1, y: 2 },
          { x: 1, y: 1 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Sail Blade
      {
        points: [
          { x: 3, y: 2 },
          { x: 4, y: 2 },
          { x: 5, y: 2 },
          { x: 5, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Conical Tower Left
      {
        points: [
          { x: 2, y: 5 },
          { x: 1, y: 7 },
        ],
        preferredDir: 'LEFT',
      },
      // Conical Tower Right
      {
        points: [
          { x: 4, y: 5 },
          { x: 5, y: 7 },
        ],
        preferredDir: 'RIGHT',
      },
      // Tower Door
      {
        points: [
          { x: 3, y: 6 },
          { x: 3, y: 7 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 44: BEAMED MUSIC NOTES
  // ==========================================
  {
    id: 'music',
    name: 'Music Notes',
    emoji: '🎵',
    category: 'Symbols',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Beamed Eighth Notes & Staff',
    strokes: [
      // Left Note Head Loop
      {
        points: [
          { x: 1, y: 5 },
          { x: 0, y: 5 },
          { x: 0, y: 6 },
          { x: 1, y: 6 },
        ],
        preferredDir: 'LEFT',
      },
      // Left Vertical Stem
      {
        points: [
          { x: 1, y: 5 },
          { x: 1, y: 3 },
          { x: 1, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Right Note Head Loop
      {
        points: [
          { x: 5, y: 4 },
          { x: 4, y: 4 },
          { x: 4, y: 5 },
          { x: 5, y: 5 },
        ],
        preferredDir: 'RIGHT',
      },
      // Right Vertical Stem
      {
        points: [
          { x: 5, y: 4 },
          { x: 5, y: 2 },
          { x: 5, y: 0 },
        ],
        preferredDir: 'UP',
      },
      // High Connecting Beam
      {
        points: [
          { x: 1, y: 1 },
          { x: 3, y: 1 },
          { x: 5, y: 0 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 45: DOORWAY
  // ==========================================
  {
    id: 'door',
    name: 'Doorway',
    emoji: '🚪',
    category: 'Architecture',
    baseWidth: 7,
    baseHeight: 8,
    description: 'Panelled Door & Threshold',
    strokes: [
      // Outer Frame Top Lintel
      {
        points: [
          { x: 1, y: 1 },
          { x: 3, y: 1 },
          { x: 5, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Left Post Jamb
      {
        points: [
          { x: 1, y: 1 },
          { x: 1, y: 4 },
          { x: 1, y: 7 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Post Jamb
      {
        points: [
          { x: 5, y: 1 },
          { x: 5, y: 4 },
          { x: 5, y: 7 },
        ],
        preferredDir: 'RIGHT',
      },
      // Door Upper Inset Panel
      {
        points: [
          { x: 2, y: 2 },
          { x: 4, y: 2 },
          { x: 4, y: 3 },
          { x: 2, y: 3 },
        ],
        preferredDir: 'UP',
      },
      // Door Lower Inset Panel
      {
        points: [
          { x: 2, y: 5 },
          { x: 4, y: 5 },
          { x: 4, y: 6 },
          { x: 2, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Door Handle Knob
      {
        points: [
          { x: 2, y: 4 },
          { x: 3, y: 4 },
        ],
        preferredDir: 'RIGHT',
      },
    ],
  },

  // ==========================================
  // LEVEL 46: CLOUD & RAIN
  // ==========================================
  {
    id: 'cloud',
    name: 'Cloud & Rain',
    emoji: '🌧️',
    category: 'Nature',
    baseWidth: 8,
    baseHeight: 7,
    description: 'Fluffy Cloud Scallops & Showers',
    strokes: [
      // Top Center Cloud Dome
      {
        points: [
          { x: 3, y: 1 },
          { x: 4, y: 1 },
          { x: 5, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Left Cloud Scallop
      {
        points: [
          { x: 3, y: 1 },
          { x: 2, y: 2 },
          { x: 1, y: 3 },
        ],
        preferredDir: 'LEFT',
      },
      // Right Cloud Scallop
      {
        points: [
          { x: 5, y: 1 },
          { x: 6, y: 2 },
          { x: 7, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Cloud Flat Base
      {
        points: [
          { x: 1, y: 3 },
          { x: 3, y: 3 },
          { x: 5, y: 3 },
          { x: 7, y: 3 },
        ],
        preferredDir: 'UP',
      },
      // Rain Droplet Stream 1
      {
        points: [
          { x: 2, y: 4 },
          { x: 2, y: 5 },
          { x: 2, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Rain Droplet Stream 2
      {
        points: [
          { x: 4, y: 4 },
          { x: 4, y: 5 },
          { x: 4, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Rain Droplet Stream 3
      {
        points: [
          { x: 6, y: 4 },
          { x: 6, y: 5 },
          { x: 6, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 47: ALPINE MOUNTAIN PEAKS
  // ==========================================
  {
    id: 'mountains',
    name: 'Mountain Peaks',
    emoji: '🏔️',
    category: 'Nature',
    baseWidth: 8,
    baseHeight: 7,
    description: 'Twin Snow-Capped Summits',
    strokes: [
      // Left Tall Peak Summit
      {
        points: [
          { x: 3, y: 1 },
          { x: 2, y: 2 },
          { x: 1, y: 4 },
          { x: 0, y: 6 },
        ],
        preferredDir: 'LEFT',
      },
      // Left Summit Right Slope
      {
        points: [
          { x: 3, y: 1 },
          { x: 4, y: 3 },
        ],
        preferredDir: 'UP',
      },
      // Right Secondary Peak Summit
      {
        points: [
          { x: 6, y: 2 },
          { x: 5, y: 3 },
          { x: 4, y: 3 },
        ],
        preferredDir: 'UP',
      },
      // Right Peak Outer Slope
      {
        points: [
          { x: 6, y: 2 },
          { x: 7, y: 4 },
          { x: 7, y: 6 },
        ],
        preferredDir: 'RIGHT',
      },
      // Snowline Chevron
      {
        points: [
          { x: 2, y: 3 },
          { x: 3, y: 3 },
        ],
        preferredDir: 'DOWN',
      },
      // Base Foothills
      {
        points: [
          { x: 1, y: 6 },
          { x: 3, y: 6 },
          { x: 5, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
    ],
  },

  // ==========================================
  // LEVEL 48: HERALDIC SHIELD
  // ==========================================
  {
    id: 'shield',
    name: 'Heraldic Shield',
    emoji: '🛡️',
    category: 'Symbols',
    baseWidth: 7,
    baseHeight: 7,
    description: 'Emblem Crest & Pointed Base',
    strokes: [
      // Top Edge
      {
        points: [
          { x: 1, y: 1 },
          { x: 3, y: 1 },
          { x: 5, y: 1 },
        ],
        preferredDir: 'UP',
      },
      // Left Upper Rim & Lower Curve
      {
        points: [
          { x: 1, y: 1 },
          { x: 1, y: 3 },
          { x: 2, y: 5 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Right Upper Rim & Lower Curve
      {
        points: [
          { x: 5, y: 1 },
          { x: 5, y: 3 },
          { x: 4, y: 5 },
          { x: 3, y: 6 },
        ],
        preferredDir: 'DOWN',
      },
      // Emblem Cross Horizontal
      {
        points: [
          { x: 2, y: 3 },
          { x: 4, y: 3 },
        ],
        preferredDir: 'RIGHT',
      },
      // Emblem Cross Vertical
      {
        points: [
          { x: 3, y: 2 },
          { x: 3, y: 4 },
        ],
        preferredDir: 'UP',
      },
    ],
  },
];
