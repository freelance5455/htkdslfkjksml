/* ============================================================
   MEME SURVIVORS — procedural pixel-art sprite engine
   Every sprite is drawn pixel-by-pixel on tiny grids, then
   upscaled with nearest-neighbour for a crisp retro look.
   ============================================================ */
import type { LevelDef } from './data';

const SCALE = 3;

class B {
  c: CanvasRenderingContext2D;
  w: number;
  h: number;
  constructor(w: number, h: number) {
    this.w = w; this.h = h;
    const cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    this.c = cv.getContext('2d')!;
  }
  p(x: number, y: number, col: string) { this.c.fillStyle = col; this.c.fillRect(Math.round(x), Math.round(y), 1, 1); }
  rect(x: number, y: number, w: number, h: number, col: string) { this.c.fillStyle = col; this.c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); }
  circle(cx: number, cy: number, r: number, col: string) {
    for (let y = Math.floor(cy - r); y <= cy + r; y++)
      for (let x = Math.floor(cx - r); x <= cx + r; x++) {
        const dx = x - cx, dy = y - cy;
        if (dx * dx + dy * dy <= r * r + 0.4) this.p(x, y, col);
      }
  }
  oval(cx: number, cy: number, rx: number, ry: number, col: string) {
    for (let y = Math.floor(cy - ry); y <= cy + ry; y++)
      for (let x = Math.floor(cx - rx); x <= cx + rx; x++) {
        const dx = (x - cx) / rx, dy = (y - cy) / ry;
        if (dx * dx + dy * dy <= 1.05) this.p(x, y, col);
      }
  }
  // toy-like shaded ball: darker bottom-right, highlight top-left
  ball(cx: number, cy: number, r: number, base: string, dark: string, light: string) {
    for (let y = Math.floor(cy - r); y <= cy + r; y++)
      for (let x = Math.floor(cx - r); x <= cx + r; x++) {
        const dx = x - cx, dy = y - cy;
        if (dx * dx + dy * dy <= r * r + 0.4) {
          const t = (dx + dy) / (r * 1.7);
          this.p(x, y, t > 0.34 ? dark : t < -0.62 ? light : base);
        }
      }
  }
  eye(x: number, y: number, r: number, lookX: number, lookY: number, pupil = '#20223a') {
    this.circle(x, y, r, '#ffffff');
    this.circle(x + lookX * r * 0.4, y + lookY * r * 0.35, Math.max(1, r * 0.55), pupil);
    this.p(x + lookX * r * 0.4 - r * 0.35, y - r * 0.35, '#ffffff');
  }
  canvas(): HTMLCanvasElement { return this.c.canvas; }
}

interface SpriteDef { w: number; h: number; frames: number; draw: (b: B, f: number) => void; }

/* ---------------- palettes ---------------- */
const SKIN = '#ffd6a5', SKIN_D = '#e8b183', SKIN_L = '#ffedcf';
const HAIR = '#2fd3c6', HAIR_D = '#1aa89c';
const JACK = '#3a6fe0', JACK_D = '#2a51ad';
const BOOT = '#232c4e';
const SCARF = '#ff5d8f';

/* ---------------- sprite registry ---------------- */
const SPRITES: Record<string, SpriteDef> = {};

function def(name: string, w: number, h: number, frames: number, draw: (b: B, f: number) => void) {
  SPRITES[name] = { w, h, frames, draw };
}

/* ============ PLAYER HERO (18 x 22, faces right) ============ */
def('hero', 18, 22, 8, (b, f) => {
  const run = [2, 3, 4, 5].includes(f);
  const jump = f === 6;
  const atk = f === 7;
  const bob = (f === 1) ? 1 : 0;                 // idle breathing
  const l1 = f === 2 ? { x: 5, y: 18 } : f === 3 ? { x: 4, y: 17 } : f === 4 ? { x: 5, y: 16 } : f === 5 ? { x: 6, y: 17 } : { x: 5, y: 17 };
  const l2 = f === 2 ? { x: 10, y: 16 } : f === 3 ? { x: 11, y: 17 } : f === 4 ? { x: 10, y: 18 } : f === 5 ? { x: 9, y: 17 } : { x: 10, y: 17 };
  const gy = jump ? -1 : bob;
  // legs + boots
  const leg = (lx: number, ly: number) => {
    b.rect(lx, ly, 3, 22 - ly - 2, JACK_D);
    b.rect(lx - (run ? 1 : 0), 20, 4, 2, BOOT);
    b.p(lx - (run ? 1 : 0), 20, '#5a6aa0');
  };
  if (jump) { b.rect(4, 16, 4, 3, JACK_D); b.rect(4, 18, 5, 2, BOOT); b.rect(10, 17, 4, 3, JACK_D); b.rect(9, 19, 5, 2, BOOT); }
  else { leg(l1.x, l1.y); leg(l2.x, l2.y); }
  // scarf flutter
  const sw = (run || jump) ? (f % 2) : 0;
  b.rect(2 - sw, 11 + gy, 3, 2, SCARF); b.p(1 - sw, 12 + gy - (f % 2), SCARF);
  // body
  b.oval(8.5, 13.5 + gy, 5.5, 4.5, JACK);
  b.oval(8.5, 15 + gy, 5.2, 3.4, JACK_D);
  b.rect(4, 14 + gy, 10, 1, '#ffd23f');          // belt
  b.p(12, 12 + gy, '#8fb7ff'); b.p(11, 11 + gy, '#8fb7ff');
  // arm reaching forward + glove
  b.rect(13, 11 + gy, 3, 2, SKIN); b.rect(15, 11 + gy + (atk ? 0 : 0), 2, 2, BOOT);
  // head
  b.ball(9, 5 + gy, 5, SKIN, SKIN_D, SKIN_L);
  // hair cap + side sweep
  for (let y = 1; y <= 4; y++) for (let x = 3; x <= 14; x++) {
    const dx = x - 9, dy = y - (5 + gy);
    if (dx * dx + dy * dy <= 26 && y + gy < 5) b.p(x, y, (y <= 2 ? HAIR : (x < 6 ? HAIR_D : HAIR)));
  }
  b.rect(3, 2, 2, 1, HAIR); b.p(2, 3, HAIR_D);   // tuft
  b.rect(5, 1 + gy, 7, 1, '#7ff5ea');            // hair shine
  // face (two big cute eyes)
  b.eye(11.6, 5.4 + gy, 1.6, 1, atk ? -1 : 0);
  b.eye(7.2, 5.4 + gy, 1.6, 1, 0);
  b.p(6, 7.6 + gy, '#ff9d9d'); b.p(13.4, 7.6 + gy, '#ff9d9d'); // blush
  b.p(9, 8.3 + gy, '#b25a3c'); b.p(10, 8.3 + gy, '#b25a3c');   // smile
});

/* ============ WEAPON GUNS (16x7, faces right) ============ */
function gun(name: string, bodyCol: string, glow: string, long: boolean, fat: boolean) {
  def('gun_' + name, 16, 7, 1, (b) => {
    const L = long ? 15 : 12;
    b.rect(1, 2, L - 3, fat ? 3 : 2, bodyCol);
    b.rect(1, 2, 3, fat ? 4 : 3, '#2b3352');     // grip
    b.rect(0, fat ? 5 : 4, 3, 2, '#2b3352');
    b.rect(L - 3, 2, 3, fat ? 3 : 2, '#aab6d8'); // barrel
    b.p(L, fat ? 3 : 2.5, glow); b.p(L + 0, fat ? 3 : 2.5, glow);
    b.rect(4, 1, 4, 1, glow);                    // energy cell
    b.p(8, 3, glow);
  });
}
gun('blaster', '#3a4160', '#59d9ff', false, false);
gun('shotgun', '#6b4a2f', '#ffb347', false, true);
gun('laser', '#4a2f6b', '#ff4dd2', true, false);
gun('plasma', '#2f6b4a', '#7dff6a', false, true);
gun('rocket', '#6b2f2f', '#ff8a47', true, true);
gun('dual', '#3a4160', '#ffd23f', false, false);
gun('tesla', '#2f4a6b', '#9df2ff', false, false);
gun('homing', '#5a3a60', '#ff9df2', true, false);

/* ============ XP ORBS ============ */
function xpOrb(name: string, col: string, core: string) {
  def(name, 9, 9, 2, (b, f) => {
    const c = f ? 0.4 : 0;
    b.p(4, 1 - c, col); b.p(3, 2, col); b.p(4, 2, core); b.p(5, 2, col);
    b.p(2, 3, col); b.p(3, 3, core); b.p(4, 3, core); b.p(5, 3, core); b.p(6, 3, col);
    b.p(2, 4, col); b.p(3, 4, core); b.p(4, 4, '#ffffff'); b.p(5, 4, core); b.p(6, 4, col);
    b.p(2, 5, col); b.p(3, 5, core); b.p(4, 5, core); b.p(5, 5, core); b.p(6, 5, col);
    b.p(3, 6, col); b.p(4, 6, core); b.p(5, 6, col); b.p(4, 7 + c, col);
  });
}
xpOrb('xp1', '#54e05e', '#c9ffbe');
xpOrb('xp2', '#4aa8ff', '#c4e6ff');
xpOrb('xp3', '#c25eff', '#ecc9ff');

/* ============ ENEMIES ============ */
// Goofy walking potato
def('potato', 20, 18, 2, (b, f) => {
  const by = f ? 1 : 0;
  b.ball(10, 8 + by, 6.5, '#c9925a', '#a06a38', '#e8bd85');
  b.ball(14, 10 + by, 3.5, '#c9925a', '#a06a38', '#e8bd85');
  b.p(6, 4 + by, '#a06a38'); b.p(13, 5 + by, '#a06a38');      // lumps
  b.rect(9, 0 + by, 1, 2, '#58c24a'); b.rect(10, 0 + by, 2, 1, '#58c24a'); // sprout
  b.eye(8, 7 + by, 1.6, 1, 0); b.eye(13.4, 7 + by, 1.6, 1, 0);
  b.rect(6.6, 4.6 + by, 3, 1, '#5a3a1e'); b.rect(12, 4.6 + by, 3, 1, '#5a3a1e'); // angry brows
  b.rect(9.4, 11 + by, 3, 1, '#5a3a1e');
  b.p(9.4, 11 + by, '#8a5a2e');
  b.rect(f ? 6 : 5, 15, 3, 2, '#8a5a2e'); b.rect(f ? 11 : 12, 15, 3, 2, '#8a5a2e'); // feet
  b.rect(3, 9 + by, 2, 2, '#b57a43'); b.rect(16, 9 - by, 2, 2, '#b57a43');         // arms
});
// Angry chicken warrior
def('chicken', 18, 18, 2, (b, f) => {
  const by = f ? 1 : 0;
  b.rect(f ? 4 : 6, 15, 1, 3, '#e8891c'); b.rect(f ? 11 : 9, 15, 1, 3, '#e8891c'); // legs
  b.ball(8, 10 + by, 6, '#f7f3e8', '#d9d2bd', '#ffffff');
  b.rect(2, 8 + by, 3, 3, '#e8e2d0');                      // tail
  b.p(1, 7 + by, '#e8e2d0');
  b.oval(5, 11 + by, 2.5, 2, '#e8e2d0');                   // wing
  b.ball(11, 5 + by, 3.6, '#f7f3e8', '#d9d2bd', '#ffffff');
  b.rect(9.4, 0 + by, 1.4, 2, '#ff3b3b'); b.rect(11, 0 + by - 1, 1.6, 3, '#ff3b3b'); b.rect(12.8, 0 + by, 1.4, 2, '#ff3b3b'); // comb
  b.p(14.6, 5.4 + by, '#ffb020'); b.p(15.6, 6 + by, '#ffb020'); b.p(14.6, 6.4 + by, '#e8891c'); // beak
  b.eye(12.4, 4.6 + by, 1.3, 1, 0);
  b.rect(11, 2.6 + by, 3, 1, '#7a1e1e');                   // angry brow
});
// Derpy flying cat
def('derpycat', 22, 16, 2, (b, f) => {
  const wy = f ? -2 : 1;
  b.oval(3, 6 + wy, 4, 2.4, '#e8ecf4'); b.oval(3, 7 + wy, 3, 1.6, '#c9cfdd');      // wing back
  b.ball(11, 8, 6, '#c9cede', '#9aa0b8', '#eef1fa');
  b.rect(6.4, 1.6, 2, 2.4, '#c9cede'); b.rect(13.6, 1.6, 2, 2.4, '#c9cede');       // ears
  b.p(7, 2, '#ff9db4'); b.p(14.6, 2, '#ff9db4');
  b.oval(19, 6 + (f ? 0 : 1), 3, 2.2, '#e8ecf4');          // wing front
  b.eye(8.6, 6.6, 2, 1, 1);                                 // derpy eyes
  b.eye(13.6, 8.6, 1.3, 1, -1);
  b.rect(9.8, 11.6, 2.6, 1, '#8a4a5a'); b.rect(10.4, 12.4, 1.4, 1.6, '#ff8aa8');   // tongue
  b.p(17, 9, '#9aa0b8'); b.p(18, 10, '#9aa0b8');
});
// Dancing toilet monster
def('toilet', 22, 22, 2, (b, f) => {
  const s = f ? 1 : -1;                                       // dance sway
  b.rect(2 + s, 2, 6, 10, '#dfe6ee'); b.rect(1 + s, 1, 8, 2, '#f2f6fa');           // tank
  b.p(3 + s, 4, '#aab6c8');
  b.ball(13, 12, 6.5, '#eef2f8', '#c4cedd', '#ffffff');     // bowl
  b.oval(13, 8, 5.6, 2.6, '#c4cedd');                       // seat ring
  b.oval(13, 8, 3.4, 1.4, '#6fb7ff');                       // water
  b.rect(9, 17, 8, 3, '#dfe6ee'); b.rect(8, 19, 10, 2, '#c4cedd');                 // base
  b.eye(10.6, 12.4, 1.5, 1, f ? 1 : 0);
  b.eye(15.2, 12.4, 1.5, 1, f ? -1 : 0);
  if (f) { b.rect(11, 15, 5, 2, '#5a3a4a'); b.rect(11, 15, 5, 1, '#ffffff'); }     // open grin
  else { b.rect(11, 15.4, 5, 1.2, '#5a3a4a'); b.p(12, 15, '#ffffff'); b.p(14.4, 15, '#ffffff'); }
});
// Bouncing frog
def('frog', 20, 16, 2, (b, f) => {
  const sq = f ? 1.4 : 0;
  b.oval(4, 12, 3, 2.4, '#3f9c36'); b.oval(16, 12, 3, 2.4, '#3f9c36');             // legs
  b.oval(10, 9 + sq * 0.5, 7.6, 5.6 - sq, '#58c24a');
  b.oval(10, 12, 6, 2.6, '#d9f0b0');                        // belly
  b.circle(6.4, 3, 2.6, '#58c24a'); b.circle(13.6, 3, 2.6, '#58c24a');
  b.eye(6.4, 3, 1.7, 1, 0); b.eye(13.6, 3, 1.7, 1, 0);
  b.rect(7, 9 + sq * 0.4, 6, 1, '#2c6b26');                 // wide mouth
  b.p(7, 10.2, '#ff7d9c');
});
// Weird smiling blob slime
def('slime', 16, 14, 2, (b, f) => {
  const sq = f ? 1 : 0;
  b.oval(8, 8 + sq, 7 - sq * 0.6, 5.4 + sq * 0.4, '#63dc68');
  b.oval(8, 10.4 + sq, 5.6, 3, '#3fae4b');
  b.p(5, 4, '#b6ffb4'); b.p(6, 3, '#b6ffb4');               // shine
  b.eye(6, 7.4 + sq, 1.2, 1, 0); b.eye(10.6, 7.4 + sq, 1.2, 1, 0);
  b.rect(6.6, 10 + sq, 3.4, 1, '#2c6b26'); b.p(7.2, 11, '#ff8aa8');
});
// Jumping mutant frog (tank)
def('mutantfrog', 24, 20, 2, (b, f) => {
  const sq = f ? 1.4 : 0;
  b.oval(4, 15, 4, 2.6, '#5a32a8'); b.oval(20, 15, 4, 2.6, '#5a32a8');
  b.oval(12, 11 + sq * 0.5, 9, 6.4 - sq, '#7a4dd0');
  b.oval(12, 14.4, 7, 3, '#b39ae8');
  b.circle(7, 3.4, 3, '#7a4dd0'); b.circle(17, 3.4, 3, '#7a4dd0');
  b.eye(7, 3.4, 1.8, 1, 0, '#3a1060'); b.eye(17, 3.4, 1.8, 1, 0, '#3a1060');
  b.p(5, 8, '#9d7ee8'); b.p(19, 9, '#9d7ee8'); b.p(14, 5.4, '#9d7ee8'); b.p(9, 13, '#9d7ee8'); // warts
  b.rect(8, 10 + sq * 0.4, 8, 1, '#3a1060'); b.rect(9, 11, 1, 1, '#fff'); b.rect(14, 11, 1, 1, '#fff');
  b.rect(2, 6, 2, 1, '#4dd06a'); b.rect(20, 5, 2, 1, '#4dd06a'); // toxic spikes
});
// Robot meme
def('robot', 18, 20, 2, (b, f) => {
  const tr = f ? 1 : 0;
  b.rect(3, 16 - tr, 4, 3, '#3c445c'); b.rect(11, 16 + tr, 4, 3, '#3c445c');       // treads
  b.p(4, 17 - tr, '#7c86a8'); b.p(13, 17 + tr, '#7c86a8');
  b.rect(3, 17, 12, 2.4, '#565f7e');
  b.rect(4, 6, 10, 11, '#8b93a8'); b.rect(4, 6, 10, 2, '#aeb6cc'); b.rect(4, 15, 10, 2, '#6b748f');
  b.rect(13.4, 12, 2, 2, '#6b748f'); b.rect(14.6, 11, 2, 3, '#aeb6cc');            // claw arm
  b.oval(8, 1.6, 1, 1.4, '#8b93a8'); b.p(8, 0, '#ff5d5d');                          // antenna
  b.rect(5.6, 8.4, 7, 3, '#2b3352');                                                // visor
  b.p(7.4, 10, '#4dd0e1'); b.p(10, 10, '#4dd0e1');
  b.rect(6, 13, 6, 1, '#6b748f');
  b.p(12, 12.8, '#ffd23f');
});
// Skeleton meme
def('skeleton', 16, 20, 2, (b, f) => {
  const w = f ? 1 : -1;
  b.rect(5, 15, 2, 4, '#e8e8e2'); b.rect(9, 15, 2, 4, '#e8e8e2');
  b.rect(4, 9, 8, 6, '#d0d0c8');
  b.rect(5, 10, 6, 1, '#8f8f86'); b.rect(5, 12, 6, 1, '#8f8f86'); b.rect(5, 14, 6, 1, '#8f8f86');
  b.rect(2 + w, 10, 2, 4, '#e8e8e2'); b.rect(12 - w, 10, 2, 4, '#e8e8e2');         // arms
  b.ball(7.5, 4.6, 4.4, '#f2f2ea', '#cfcfc2', '#ffffff');
  b.circle(5.8, 4.4, 1.5, '#20223a'); b.circle(9.6, 4.4, 1.5, '#20223a');
  b.p(5.4, 4, '#ff5d5d'); b.p(9.2, 4, '#ff5d5d');
  b.rect(6, 7.4, 3.4, 1.2, '#20223a'); b.p(6.6, 7.4, '#fff'); b.p(8.6, 7.4, '#fff');
});
// Ghost meme
def('ghost', 18, 18, 2, (b, f) => {
  const wv = f ? 1 : 0;
  b.ball(8.5, 7, 6.4, '#f4f2ff', '#cfc9ea', '#ffffff');
  b.rect(2.2, 8, 12.6, 5.4, '#f4f2ff');
  b.p(3, 13.4, '#f4f2ff'); b.p(5, 14 - wv, '#f4f2ff'); b.p(7, 13.4, '#f4f2ff'); b.p(9.4, 14 - wv, '#f4f2ff'); b.p(11.6, 13.4, '#f4f2ff'); b.p(13.6, 14 - wv, '#f4f2ff');
  b.eye(6.4, 6.4, 1.7, 1, 0.4); b.eye(11.2, 6.4, 1.7, 1, 0.4);
  b.oval(8.8, 10, 1.6, 2.2, '#3a2a5a');                     // spooky mouth
  b.p(14.6, 4, '#cfc9ea');
});
// Cyber cat
def('cybercat', 22, 16, 2, (b, f) => {
  const r = f ? 1 : 0;
  b.rect(2, 4 + r, 3, 1, '#9df2ff'); b.rect(2, 6, 3, 1, '#ff2ea6');                // rotors
  b.rect(3.4, 3.4, 1.6, 4, '#3a3f52');
  b.ball(11, 8, 6, '#3a3f52', '#262a3a', '#565f7e');
  b.rect(6.4, 1.6, 2, 2.6, '#3a3f52'); b.rect(13.6, 1.6, 2, 2.6, '#3a3f52');
  b.p(7, 2, '#ff2ea6'); b.p(14.6, 2, '#4dd0e1');
  b.rect(6.4, 6, 9.6, 2.6, '#10131f');                                             // visor
  b.rect(7, 6.6, 3.4, 1.4, '#ff2ea6'); b.rect(11.6, 6.6, 3.4, 1.4, '#4dd0e1');
  b.rect(9.6, 11, 3, 1, '#9df2ff');
  b.p(18, 10, '#565f7e');
});
// Brainrot glitch blob
def('brainrot', 22, 18, 2, (b, f) => {
  const sq = f ? 1 : 0;
  b.oval(11, 10 + sq, 8.4, 6 + sq * 0.5, '#c8ff3e');
  b.oval(11, 13 + sq, 6.6, 3.4, '#8fc22c');
  for (let i = 0; i < 9; i++) {
    const x = (i * 37 + (f ? 5 : 0)) % 18 + 2, y = (i * 23) % 12 + 3;
    b.p(x, y, i % 2 ? '#ff2ea6' : '#35d0c5');
    b.p(x + 1, y, i % 3 ? '#ff2ea6' : '#8a5cff');
  }
  b.eye(8, 8 + sq, 2.4, 1, 0.6);
  b.eye(14.4, 6.4 + sq, 1.4, -1, -1);
  b.rect(9, 12.4 + sq, 5, 1.4, '#4a6b12');
  b.rect(12, 13.6 + sq, 1.4, 2.4, '#d7ff9d');                                      // drool
});

/* ============ BOSSES ============ */
// Giant Evil Potato
def('boss_potato', 44, 40, 2, (b, f) => {
  const by = f ? 1 : 0;
  b.rect(f ? 8 : 6, 34, 8, 5, '#8a5a2e'); b.rect(f ? 28 : 30, 34, 8, 5, '#8a5a2e');
  b.ball(22, 18 + by, 15, '#c9925a', '#a06a38', '#e8bd85');
  b.ball(32, 22 + by, 8, '#c9925a', '#a06a38', '#e8bd85');
  b.p(12, 8 + by, '#a06a38'); b.p(28, 6 + by, '#a06a38'); b.p(17, 26 + by, '#a06a38');
  b.rect(19, 0 + by, 2, 4, '#58c24a'); b.rect(21, 0 + by, 4, 2, '#58c24a'); b.rect(23, -1 < 0 ? 0 : 0, 2, 1, '#58c24a');
  b.eye(15, 15 + by, 3, 1, 0.3); b.eye(29, 15 + by, 3, 1, 0.3);
  b.rect(11.4, 9.4 + by, 8, 2, '#5a3a1e'); b.rect(25, 9.4 + by, 8, 2, '#5a3a1e');
  b.rect(16, 25 + by, 12, 3, '#5a3a1e');
  b.rect(17, 25 + by, 2, 2, '#fff'); b.rect(21, 25 + by, 2, 2, '#fff'); b.rect(25, 25 + by, 2, 2, '#fff');
  b.oval(5, 20 + by, 3, 4, '#b57a43'); b.oval(39, 20 - by, 3, 4, '#b57a43');
});
// Swamp Brainrot King
def('boss_frog', 46, 38, 2, (b, f) => {
  const sq = f ? 1.5 : 0;
  b.oval(8, 30, 7, 4, '#5a32a8'); b.oval(38, 30, 7, 4, '#5a32a8');
  b.oval(23, 21 + sq * 0.4, 17, 11 - sq, '#7a4dd0');
  b.oval(23, 27, 13, 5, '#b39ae8');
  b.circle(13, 7, 5.4, '#7a4dd0'); b.circle(33, 7, 5.4, '#7a4dd0');
  b.eye(13, 7, 3.4, 1, 0.3, '#3a1060'); b.eye(33, 7, 3.4, 1, 0.3, '#3a1060');
  b.p(18, 12, '#9d7ee8'); b.p(28, 15, '#9d7ee8'); b.p(36, 20, '#9d7ee8'); b.p(10, 18, '#9d7ee8');
  b.rect(14, 19 + sq * 0.4, 18, 2, '#3a1060');
  b.rect(16, 20 + sq * 0.4, 2, 2, '#fff'); b.rect(22, 20 + sq * 0.4, 2, 2, '#fff'); b.rect(28, 20 + sq * 0.4, 2, 2, '#fff');
  b.rect(18, 0, 10, 4, '#ffd23f'); b.rect(17, 0, 2, 6, '#ffd23f'); b.rect(23, 0, 2, 6, '#ffd23f'); b.rect(27, 0, 2, 6, '#e8a812');
  b.rect(19, 3.4, 8, 2, '#e8a812');
});
// Cyber Toilet Overlord
def('boss_toilet', 48, 42, 2, (b, f) => {
  const s = f ? 1 : -1;
  b.rect(4 + s, 4, 12, 20, '#dfe6ee'); b.rect(3 + s, 2, 14, 4, '#f2f6fa');
  b.rect(4 + s, 8, 12, 2, '#ff5d5d');                                     // warning stripe
  b.ball(28, 25, 14, '#eef2f8', '#c4cedd', '#ffffff');
  b.oval(28, 17, 11.6, 5, '#c4cedd'); b.oval(28, 17, 7.4, 3, '#6fb7ff');
  b.rect(17, 34, 22, 5, '#dfe6ee'); b.rect(15, 38, 26, 3, '#c4cedd');
  b.rect(19, 22, 18, 5, '#10131f');                                       // visor
  b.rect(21, 24, 6, 2, '#ff2ea6'); b.rect(29, 24, 6, 2, '#ff8a00');
  b.rect(23, 30, 10, 2, '#5a3a4a'); b.p(25, 30, '#fff'); b.p(29, 30, '#fff');
  b.rect(40, 20, 7, 4, '#3c445c'); b.p(47, 21, '#ff5d5d');                 // laser cannon
  b.rect(0 + s, 14, 4, 3, '#3c445c'); b.p(0 + s, 14.6, '#4dd0e1');
});
// Cursed Meme Lord
def('boss_lord', 42, 44, 2, (b, f) => {
  const fl = f ? 1 : 0;
  // cloak
  b.rect(12, 12, 18, 22, '#2a1f4a');
  b.p(12, 34, '#2a1f4a'); b.p(15, 36 + fl, '#2a1f4a'); b.p(18, 34, '#2a1f4a'); b.p(21, 36 - fl, '#2a1f4a'); b.p(24, 34, '#2a1f4a'); b.p(27, 36 + fl, '#2a1f4a'); b.p(30, 34, '#2a1f4a');
  b.rect(12, 12, 18, 3, '#4a3585');
  b.oval(9, 26 + (f ? 1 : -1), 3, 5, '#2a1f4a'); b.oval(33, 26 + (f ? -1 : 1), 3, 5, '#2a1f4a'); // sleeve arms
  b.circle(9, 30 + (f ? 1 : -1), 2, '#e8e8e2'); b.circle(33, 30 + (f ? -1 : 1), 2, '#e8e8e2');
  // skull
  b.ball(21, 8, 8, '#f2f2ea', '#cfcfc2', '#ffffff');
  b.circle(17.4, 7, 2.6, '#1a0f2e'); b.circle(24.6, 7, 2.6, '#1a0f2e');
  b.p(16.6, 6.4, '#c25eff'); b.p(23.8, 6.4, '#c25eff');
  b.rect(19, 12, 4, 1.6, '#1a0f2e'); b.p(20, 12, '#fff'); b.p(22, 12, '#fff');
  b.rect(16, 0, 10, 3, '#c25eff'); b.p(17, -0 + 0, '#e2b8ff');             // crown
  b.rect(15, 0, 2, 4, '#c25eff'); b.rect(21, 0, 2, 4, '#c25eff'); b.rect(26, 0, 2, 4, '#8a3ee0');
});
// Ultimate Brainrot Entity
def('boss_brainrot', 50, 46, 2, (b, f) => {
  const sq = f ? 1.6 : 0;
  b.oval(25, 25 + sq * 0.4, 20, 14 - sq, '#c8ff3e');
  b.oval(25, 33, 16, 6, '#8fc22c');
  for (let i = 0; i < 16; i++) {
    const x = (i * 29 + (f ? 7 : 0)) % 42 + 4, y = (i * 17) % 26 + 9;
    b.p(x, y, ['#ff2ea6', '#35d0c5', '#8a5cff', '#ffd23f'][i % 4]);
    if (i % 3 === 0) b.p(x + 1, y, '#ff2ea6');
  }
  b.eye(16, 20 + sq * 0.3, 4.4, 1, 0.4);
  b.eye(33, 15, 3, -1, -0.6);
  b.eye(37, 26, 2, 1, 1);
  b.rect(17, 30 + sq * 0.4, 14, 2.4, '#4a6b12');
  b.rect(19, 30 + sq * 0.4, 2, 2.4, '#fff'); b.rect(26, 30 + sq * 0.4, 2, 2.4, '#fff');
  b.rect(28, 32 + sq * 0.4, 2, 4, '#d7ff9d');
  b.oval(8, 34, 4, 7 - sq, '#8fc22c'); b.oval(42, 34, 4, 7 - sq, '#8fc22c'); // tendrils
});

/* ============ GADGETS ============ */
def('drone', 12, 10, 2, (b, f) => {
  b.rect(1, f ? 0 : 1, 10, 1, '#9df2ff'); b.p(2, f ? 1 : 0, '#9df2ff'); b.p(9, f ? 1 : 0, '#9df2ff');
  b.oval(6, 5, 4, 3, '#565f7e'); b.oval(6, 4.4, 3, 2, '#8b93a8');
  b.circle(7.6, 5, 1.2, '#4dd0e1'); b.p(7.4, 4.6, '#fff');
  b.rect(10, 5.4, 2, 1.4, '#2b3352'); b.p(12, 5.6, '#59d9ff');
});
def('turret', 14, 12, 1, (b) => {
  b.rect(2, 8, 10, 3, '#3c445c'); b.rect(4, 10, 6, 2, '#2b3352');
  b.ball(7, 6, 3.6, '#8b93a8', '#6b748f', '#aeb6cc');
  b.rect(9, 5, 5, 2, '#565f7e'); b.p(14, 5.6, '#59d9ff');
  b.circle(5.6, 5.6, 1, '#ff5d5d');
});
def('mine', 10, 7, 1, (b) => {
  b.oval(5, 4.4, 4.4, 2.6, '#3c445c'); b.oval(5, 3.6, 3.4, 1.8, '#565f7e');
  b.p(5, 1.4, '#ff5d5d'); b.p(4, 4, '#8b93a8'); b.p(7, 4.6, '#2b3352');
});
def('orb_shard', 7, 7, 2, (b, f) => {
  b.p(3, 0 + (f ? 0.4 : 0), '#9df2ff'); b.p(2, 1, '#9df2ff'); b.p(3, 1, '#fff'); b.p(4, 1, '#9df2ff');
  b.p(1, 2, '#9df2ff'); b.p(2, 2, '#fff'); b.p(3, 2, '#4dd0e1'); b.p(4, 2, '#fff'); b.p(5, 2, '#9df2ff');
  b.p(1, 3, '#9df2ff'); b.p(2, 3, '#4dd0e1'); b.p(3, 3, '#fff'); b.p(4, 3, '#4dd0e1'); b.p(5, 3, '#9df2ff');
  b.p(2, 4, '#9df2ff'); b.p(3, 4, '#fff'); b.p(4, 4, '#9df2ff'); b.p(3, 5, '#9df2ff');
});

/* ---------------- sprite cache / access ---------------- */
const CACHE = new Map<string, HTMLCanvasElement>();

function bake(name: string, frame: number, variant: string): HTMLCanvasElement {
  const d = SPRITES[name];
  if (!d) throw new Error('no sprite ' + name);
  const b = new B(d.w, d.h);
  d.draw(b, frame % d.frames);
  const out = document.createElement('canvas');
  out.width = d.w * SCALE; out.height = d.h * SCALE;
  const o = out.getContext('2d')!;
  o.imageSmoothingEnabled = false;
  o.drawImage(b.canvas(), 0, 0, out.width, out.height);
  if (variant) {
    o.globalCompositeOperation = 'source-atop';
    o.globalAlpha = variant === 'white' ? 0.85 : 0.55;
    o.fillStyle = variant === 'white' ? '#ffffff' : variant;
    o.fillRect(0, 0, out.width, out.height);
  }
  return out;
}

export function sprite(name: string, frame = 0, variant: '' | 'white' | 'ice' | 'hurt' = ''): HTMLCanvasElement {
  const key = `${name}|${frame}|${variant}`;
  let c = CACHE.get(key);
  if (!c) {
    c = bake(name, frame, variant === 'white' || variant === 'hurt' ? 'white' : variant === 'ice' ? '#9df2ff' : '');
    CACHE.set(key, c);
  }
  return c;
}
export function spriteDims(name: string): { w: number; h: number; frames: number } {
  const d = SPRITES[name];
  return { w: d.w * SCALE, h: d.h * SCALE, frames: d.frames };
}
export function spriteURL(name: string, frame = 0, scaleup = 2): string {
  const base = sprite(name, frame);
  const out = document.createElement('canvas');
  out.width = base.width * scaleup; out.height = base.height * scaleup;
  const o = out.getContext('2d')!;
  o.imageSmoothingEnabled = false;
  o.drawImage(base, 0, 0, out.width, out.height);
  return out.toDataURL();
}

/* ---------------- backgrounds ---------------- */
function rand(seed: number) {
  let s = seed >>> 0;
  return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
}

const BG_CACHE = new Map<string, { sky: HTMLCanvasElement; far: HTMLCanvasElement; mid: HTMLCanvasElement; ground: HTMLCanvasElement }>();

export function renderLevelBG(lv: LevelDef, W: number, H: number, GROUND: number) {
  const hit = BG_CACHE.get(lv.id);
  if (hit) return hit;
  const R = rand(lv.seed);
  const mk = () => { const c = document.createElement('canvas'); c.width = W; c.height = H; return [c, c.getContext('2d')!] as const; };
  const [sky, sc] = mk();
  const g = sc.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, lv.sky[0]); g.addColorStop(0.62, lv.sky[1]); g.addColorStop(1, lv.sky[2]);
  sc.fillStyle = g; sc.fillRect(0, 0, W, H);
  // celestial body + stars
  if (lv.night) {
    for (let i = 0; i < 90; i++) {
      sc.fillStyle = R() > 0.5 ? '#ffffff88' : '#9df2ff66';
      const s = R() > 0.85 ? 3 : 2;
      sc.fillRect(Math.floor(R() * W), Math.floor(R() * H * 0.55), s, s);
    }
  }
  sc.fillStyle = lv.sun;
  sc.beginPath(); sc.arc(lv.sunPos[0], lv.sunPos[1], 52, 0, Math.PI * 2); sc.fill();
  sc.fillStyle = lv.sunGlow;
  sc.beginPath(); sc.arc(lv.sunPos[0], lv.sunPos[1], 66, 0, Math.PI * 2); sc.globalAlpha = 0.35; sc.fill(); sc.globalAlpha = 1;
  for (let i = 0; i < 5; i++) {  // clouds
    const cx = R() * W, cy = 30 + R() * 120, cw = 60 + R() * 90;
    sc.fillStyle = lv.cloud; sc.globalAlpha = 0.8;
    sc.beginPath(); sc.ellipse(cx, cy, cw / 2, 12 + R() * 8, 0, 0, Math.PI * 2); sc.fill();
    sc.beginPath(); sc.ellipse(cx + cw * 0.3, cy - 8, cw / 3.4, 10, 0, 0, Math.PI * 2); sc.fill();
    sc.globalAlpha = 1;
  }

  const [far, fc] = mk();
  fc.fillStyle = lv.farCol;
  for (let x = -40; x < W + 40;) {                       // far hills / skyline
    const w = 90 + R() * 140, h = 90 + R() * 130;
    if (lv.theme === 'city' || lv.theme === 'castle') {
      fc.fillRect(x, GROUND - h - 60, w * 0.6, h + 60);
      if (lv.theme === 'city') {
        fc.fillStyle = lv.windowCol;
        for (let wy = GROUND - h - 40; wy < GROUND - 30; wy += 22)
          for (let wx = x + 8; wx < x + w * 0.6 - 8; wx += 18)
            if (R() > 0.5) fc.fillRect(wx, wy, 7, 10);
        fc.fillStyle = lv.farCol;
      } else {
        fc.beginPath(); fc.moveTo(x, GROUND - h - 60); fc.lineTo(x + w * 0.3, GROUND - h - 110); fc.lineTo(x + w * 0.6, GROUND - h - 60); fc.fill();
      }
    } else {
      fc.beginPath(); fc.ellipse(x + w / 2, GROUND + 40, w, h + 60, 0, Math.PI, 0); fc.fill();
    }
    x += w * 0.62;
  }

  const [mid, mc] = mk();
  for (let i = 0; i < 14; i++) {
    const x = R() * W, s2 = 0.7 + R() * 0.7;
    mc.save(); mc.translate(x, GROUND - 6); mc.scale(s2, s2);
    if (lv.theme === 'forest') {
      mc.fillStyle = '#5a3a2a'; mc.fillRect(-6, -46, 12, 46);
      mc.fillStyle = lv.midCol; mc.beginPath(); mc.arc(0, -64, 30, 0, Math.PI * 2); mc.fill();
      mc.fillStyle = lv.midCol2; mc.beginPath(); mc.arc(-12, -72, 18, 0, Math.PI * 2); mc.fill();
    } else if (lv.theme === 'swamp') {
      mc.fillStyle = lv.midCol; mc.beginPath(); mc.ellipse(0, -30, 18, 26, 0, 0, Math.PI * 2); mc.fill();
      mc.fillStyle = lv.midCol2; mc.beginPath(); mc.ellipse(0, -52, 26, 12, 0, 0, Math.PI * 2); mc.fill();
      mc.fillStyle = '#d8ffb0'; mc.fillRect(-2, -58, 4, 6);
    } else if (lv.theme === 'city') {
      mc.fillStyle = lv.midCol; mc.fillRect(-16, -90, 32, 90);
      mc.fillStyle = lv.windowCol;
      for (let wy = -80; wy < -10; wy += 16) for (let wx = -11; wx < 10; wx += 11) if (R() > 0.4) mc.fillRect(wx, wy, 6, 9);
      mc.fillStyle = '#ff2ea6'; mc.fillRect(-22, -98, 44, 8);
    } else if (lv.theme === 'castle') {
      mc.fillStyle = lv.midCol; mc.fillRect(-12, -110, 24, 110);
      mc.fillStyle = lv.midCol2; mc.beginPath(); mc.moveTo(-16, -110); mc.lineTo(0, -140); mc.lineTo(16, -110); mc.fill();
      mc.fillStyle = '#ffd23f'; mc.fillRect(-3, -96, 6, 12);
    } else {
      mc.fillStyle = lv.midCol; mc.beginPath(); mc.moveTo(0, -80); mc.lineTo(20, 0); mc.lineTo(-20, 0); mc.fill();
      mc.fillStyle = lv.midCol2; mc.beginPath(); mc.moveTo(0, -60); mc.lineTo(12, -10); mc.lineTo(-12, -10); mc.fill();
    }
    mc.restore();
  }

  const [ground, gc] = mk();
  gc.fillStyle = lv.groundCol; gc.fillRect(0, GROUND, W, H - GROUND);
  gc.fillStyle = lv.groundTop; gc.fillRect(0, GROUND, W, 14);
  gc.fillStyle = lv.groundEdge; gc.fillRect(0, GROUND, W, 5);
  for (let i = 0; i < 160; i++) {                        // texture noise
    gc.fillStyle = R() > 0.5 ? lv.groundTop : lv.groundCol;
    gc.globalAlpha = 0.5;
    gc.fillRect(Math.floor(R() * W / 6) * 6, GROUND + 6 + Math.floor(R() * (H - GROUND - 10) / 6) * 6, 6, 6);
  }
  gc.globalAlpha = 1;
  for (let i = 0; i < 40; i++) {                         // grass tufts / debris
    const x = R() * W;
    gc.fillStyle = lv.groundEdge;
    gc.fillRect(x, GROUND - 4, 3, 5); gc.fillRect(x + 4, GROUND - 2, 3, 3);
  }
  const out = { sky, far, mid, ground };
  BG_CACHE.set(lv.id, out);
  return out;
}

/* platform slab per level style — 26px tall */
const PLAT_CACHE = new Map<string, HTMLCanvasElement>();
export function platformSprite(lv: LevelDef, w: number): HTMLCanvasElement {
  const key = lv.id + '|' + w;
  let c = PLAT_CACHE.get(key);
  if (c) return c;
  c = document.createElement('canvas');
  c.width = w; c.height = 26;
  const g = c.getContext('2d')!;
  const cols: Record<string, [string, string, string, string]> = {
    forest: ['#8a5a2e', '#a5713d', '#58c24a', '#3f9c36'],
    swamp: ['#4a5568', '#5d6b80', '#7ddf64', '#4fae4f'],
    city: ['#262a3a', '#3a3f52', '#ff2ea6', '#4dd0e1'],
    castle: ['#3d3352', '#524570', '#8a7bb8', '#6b5a96'],
    chaos: ['#3a2a5a', '#52408a', '#c25eff', '#7dff6a'],
  };
  const [base, light, top, top2] = cols[lv.theme] || cols.forest;
  g.fillStyle = base; g.fillRect(0, 5, w, 21);
  g.fillStyle = light; g.fillRect(0, 5, w, 4);
  g.fillStyle = top; g.fillRect(0, 0, w, 6);
  g.fillStyle = top2; g.fillRect(0, 4, w, 2);
  const R = rand(w * 31 + lv.seed);
  g.fillStyle = '#00000030';
  for (let x = 6; x < w - 6; x += 16 + Math.floor(R() * 10)) g.fillRect(x, 12 + Math.floor(R() * 8), 8, 3);
  g.fillStyle = '#00000055'; g.fillRect(0, 22, w, 4);
  g.fillStyle = top2; g.fillRect(0, 0, 5, 26); g.fillRect(w - 5, 0, 5, 26);
  PLAT_CACHE.set(key, c);
  return c;
}
