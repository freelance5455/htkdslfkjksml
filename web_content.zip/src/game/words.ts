export interface Word {
  id: string;
  en: string;
  fa: string;
  ipa?: string;
  sentence: string;
  sentenceFa: string;
}

export interface Lesson {
  id: string;
  no: number;
  title: string;
  titleFa: string;
  emoji: string;
  color: string;
  words: Word[];
}

const w = (
  id: string,
  en: string,
  fa: string,
  ipa: string,
  sentence: string,
  sentenceFa: string,
): Word => ({ id, en, fa, ipa, sentence, sentenceFa });

export const LESSONS: Lesson[] = [
  {
    id: "l1",
    no: 1,
    title: "My Name",
    titleFa: "نام من",
    emoji: "👋",
    color: "#38bdf8",
    words: [
      w("name", "name", "نام", "/neɪm/", "My name is Sara.", "نام من سارا است."),
      w("hello", "hello", "سلام", "/həˈləʊ/", "Hello, I am Ali.", "سلام، من علی هستم."),
      w("goodbye", "goodbye", "خداحافظ", "/ˌɡʊdˈbaɪ/", "Goodbye, see you tomorrow.", "خداحافظ، فردا می‌بینمت."),
      w("welcome", "welcome", "خوش آمدید", "/ˈwelkəm/", "Welcome to our school!", "به مدرسه ما خوش آمدید!"),
      w("friend", "friend", "دوست", "/frend/", "She is my best friend.", "او بهترین دوست من است."),
      w("boy", "boy", "پسر", "/bɔɪ/", "The boy is ten years old.", "آن پسر ده ساله است."),
      w("girl", "girl", "دختر", "/ɡɜːl/", "The girl is my cousin.", "آن دختر دخترخواهر من است."),
      w("student", "student", "دانش‌آموز", "/ˈstjuːdnt/", "I am a student in Tehran.", "من دانش‌آموزی در تهران هستم."),
      w("teacher", "teacher", "معلم", "/ˈtiːtʃə/", "Our teacher is very kind.", "معلم ما خیلی مهربان است."),
      w("nice", "nice", "خوب، جالب", "/naɪs/", "Nice to meet you.", "از ملاقات شما خوشحالم."),
      w("meet", "meet", "ملاقات کردن", "/miːt/", "Let me meet my friends.", "بگذارید دوستانم را ملاقات کنم."),
      w("happy", "happy", "خوشحال", "/ˈhæpi/", "I am happy to be here.", "خوشحالم که اینجا هستم."),
    ],
  },
  {
    id: "l2",
    no: 2,
    title: "My Classmates",
    titleFa: "هم‌کلاسی‌های من",
    emoji: "🧑‍🤝‍🧑",
    color: "#a78bfa",
    words: [
      w("classmate", "classmate", "هم‌کلاسی", "/ˈklɑːsmeɪt/", "He is my classmate.", "او هم‌کلاسی من است."),
      w("kind", "kind", "مهربان", "/kaɪnd/", "My classmates are kind.", "هم‌کلاسی‌های من مهربان هستند."),
      w("funny", "funny", "خنده‌دار", "/ˈfʌni/", "Reza is very funny.", "رضا خیلی خنده‌دار است."),
      w("clever", "clever", "باهوش", "/ˈklevə/", "Sara is a clever girl.", "سارا دختری باهوش است."),
      w("polite", "polite", "مؤدب", "/pəˈlaɪt/", "Always be polite to others.", "همیشه با دیگران مؤدب باش."),
      w("friendly", "friendly", "دوستانه", "/ˈfrendli/", "Our new teacher is friendly.", "معلم جدید ما دوستانه است."),
      w("brave", "brave", "شجاع", "/breɪv/", "The boy is very brave.", "آن پسر خیلی شجاع است."),
      w("honest", "honest", "صادق", "/ˈɒnɪst/", "An honest student never cheats.", "دانش‌آموز صادق هرگز تقلب نمی‌کند."),
      w("shy", "shy", "خجالتی", "/ʃaɪ/", "She is shy but smart.", "او خجالتی اما باهوش است."),
      w("quiet", "quiet", "ساکت", "/ˈkwaɪət/", "Please be quiet in the class.", "لطفاً در کلاس ساکت باشید."),
      w("tall", "tall", "بلند", "/tɔːl/", "Amir is taller than me.", "امیر از من بلندتر است."),
      w("hard-working", "hard-working", "پرکار", "/ˌhɑːdˈwɜːkɪŋ/", "She is a hard-working student.", "او دانش‌آموزی پرکار است."),
    ],
  },
  {
    id: "l3",
    no: 3,
    title: "My Age",
    titleFa: "سن من",
    emoji: "🎂",
    color: "#f472b6",
    words: [
      w("age", "age", "سن", "/eɪdʒ/", "My age is thirteen.", "سن من سیزده سال است."),
      w("year", "year", "سال", "/jɪə/", "I am twelve years old.", "من دوازده ساله هستم."),
      w("month", "month", "ماه", "/mʌnθ/", "May is the fifth month.", "مه پنجمین ماه است."),
      w("birthday", "birthday", "تولد", "/ˈbɜːθdeɪ/", "Happy birthday to you!", "تولدت مبارک!"),
      w("january", "January", "ژانویه", "/ˈdʒænjuəri/", "My birthday is in January.", "تولد من در ژانویه است."),
      w("march", "March", "مارس", "/mɑːtʃ/", "We have a test in March.", "ما در مارس آزمون داریم."),
      w("may", "May", "مه", "/meɪ/", "My cousin was born in May.", "پسرعمویم در مه به دنیا آمد."),
      w("july", "July", "ژوئیه", "/dʒuˈlaɪ/", "The school starts in July.", "مدرسه در ژوئیه شروع می‌شود."),
      w("august", "August", "اوت", "/ˈɔːɡəst/", "August is a hot month.", "اوت ماه گرمی است."),
      w("december", "December", "دسامبر", "/dɪˈsembə/", "We travel in December.", "ما در دسامبر سفر می‌کنیم."),
      w("twelve", "twelve", "دوازده", "/twelv/", "My sister is twelve.", "خواهرم دوازده ساله است."),
      w("thirteen", "thirteen", "سیزده", "/ˌθɜːˈtiːn/", "I am thirteen years old.", "من سیزده ساله هستم."),
    ],
  },
  {
    id: "l4",
    no: 4,
    title: "My Family",
    titleFa: "خانواده من",
    emoji: "👨‍👩‍👧",
    color: "#fbbf24",
    words: [
      w("family", "family", "خانواده", "/ˈfæməli/", "This is my family photo.", "این عکس خانواده من است."),
      w("father", "father", "پدر", "/ˈfɑːðə/", "My father is a driver.", "پدرم راننده است."),
      w("mother", "mother", "مادر", "/ˈmʌðə/", "My mother is a housewife.", "مادرم خانه‌دار است."),
      w("brother", "brother", "برادر", "/ˈbrʌðə/", "My brother likes football.", "برادرم فوتبال را دوست دارد."),
      w("sister", "sister", "خواهر", "/ˈsɪstə/", "My sister is in grade seven.", "خواهرم در پایه هفتم است."),
      w("grandfather", "grandfather", "پدربزرگ", "/ˈɡrænfɑːðə/", "My grandfather is a teacher.", "پدربزرگم معلم است."),
      w("grandmother", "grandmother", "مادربزرگ", "/ˈɡrænmʌðə/", "My grandmother makes good bread.", "مادربزرگم نان خوشمزه می‌پزد."),
      w("uncle", "uncle", "عمو، دای", "/ˈʌŋkl/", "My uncle lives in Shiraz.", "دایم در شیراز زندگی می‌کند."),
      w("aunt", "aunt", "عمه، خاله", "/ɑːnt/", "My aunt is a nurse.", "خاله‌ام پرستار است."),
      w("cousin", "cousin", "پسرعمو، دخترعمو", "/ˈkʌzn/", "My cousin is ten years old.", "پسرعمویم ده ساله است."),
      w("parents", "parents", "والدین", "/ˈpeərənts/", "My parents love me.", "والدینم مرا دوست دارند."),
      w("baby", "baby", "نوزاد", "/ˈbeɪbi/", "The baby is sleeping.", "نوزاد خواب است."),
      w("son", "son", "پسر", "/sʌn/", "Their son is a student.", "پسر آن‌ها دانش‌آموز است."),
      w("daughter", "daughter", "دختر", "/ˈdɔːtə/", "Their daughter is six.", "دختر آن‌ها شش ساله است."),
    ],
  },
  {
    id: "l5",
    no: 5,
    title: "My Appearance",
    titleFa: "ظاهر من",
    emoji: "🧒",
    color: "#34d399",
    words: [
      w("appearance", "appearance", "ظاهر", "/əˈpɪərəns/", "His appearance is very nice.", "ظاهر او خیلی خوب است."),
      w("tall-2", "tall", "بلند", "/tɔːl/", "My brother is tall.", "برادرم بلند است."),
      w("short", "short", "کوتاه", "/ʃɔːt/", "She has short hair.", "او موی کوتاه دارد."),
      w("thin", "thin", "لاغر", "/θɪn/", "He is thin and tall.", "او لاغر و بلند است."),
      w("strong", "strong", "قوی", "/strɒŋ/", "My father is very strong.", "پدرم خیلی قوی است."),
      w("pretty", "pretty", "زیبا (دختر)", "/ˈprɪti/", "The girl is pretty.", "آن دختر زیباست."),
      w("handsome", "handsome", "خوش‌قیافه", "/ˈhænsəm/", "My cousin is handsome.", "پسرعمویم خوش‌قیافه است."),
      w("hair", "hair", "مو", "/heə/", "She has long black hair.", "او موی بلند مشکی دارد."),
      w("eyes", "eyes", "چشم‌ها", "/aɪz/", "Her eyes are big.", "چشم‌هایش بزرگ است."),
      w("face", "face", "صورت", "/feɪs/", "Wash your face, please.", "صورتت را بشوی، لطفاً."),
      w("big", "big", "بزرگ", "/bɪɡ/", "This school is big.", "این مدرسه بزرگ است."),
      w("small", "small", "کوچک", "/smɔːl/", "I have a small room.", "اتاق کوچکی دارم."),
    ],
  },
  {
    id: "l6",
    no: 6,
    title: "My House",
    titleFa: "خانه من",
    emoji: "🏠",
    color: "#fb923c",
    words: [
      w("house", "house", "خانه", "/haʊs/", "Our house is near the park.", "خانه ما نزدیک پارک است."),
      w("home", "home", "خانه، منزل", "/həʊm/", "Welcome to our home.", "به خانه ما خوش آمدید."),
      w("room", "room", "اتاق", "/ruːm/", "My room is clean.", "اتاق من تمیز است."),
      w("bedroom", "bedroom", "اتاق خواب", "/ˈbedruːm/", "There are two bedrooms.", "دو اتاق خواب وجود دارد."),
      w("kitchen", "kitchen", "آشپزخانه", "/ˈkɪtʃɪn/", "Mum is in the kitchen.", "مادرم در آشپزخانه است."),
      w("bathroom", "bathroom", "حمام", "/ˈbɑːθruːm/", "Where is the bathroom?", "حمام کجاست؟"),
      w("garden", "garden", "باغ", "/ˈɡɑːdn/", "There are flowers in the garden.", "در باغ گل هست."),
      w("door", "door", "در", "/dɔː/", "Please close the door.", "لطفاً در را ببند."),
      w("window", "window", "پنجره", "/ˈwɪndəʊ/", "Open the window, please.", "لطفاً پنجره را باز کن."),
      w("table", "table", "میز", "/ˈteɪbl/", "The book is on the table.", "کتاب روی میز است."),
      w("chair", "chair", "صندلی", "/tʃeə/", "Sit on the chair.", "روی صندلی بنشین."),
      w("bed", "bed", "تخت", "/bed/", "I go to bed at ten.", "من ساعت ده به تخت می‌روم."),
      w("sofa", "sofa", "مبل", "/ˈsəʊfə/", "We watch TV on the sofa.", "ما روی مبل تلویزیون می‌بینیم."),
    ],
  },
  {
    id: "l7",
    no: 7,
    title: "My Address",
    titleFa: "آدرس من",
    emoji: "📮",
    color: "#60a5fa",
    words: [
      w("address", "address", "آدرس", "/əˈdres/", "Write your address here.", "آدرس خود را اینجا بنویس."),
      w("street", "street", "خیابان", "/striːt/", "I live on this street.", "من در این خیابان زندگی می‌کنم."),
      w("road", "road", "جاده", "/rəʊd/", "The road is very long.", "این جاده خیلی طولانی است."),
      w("city", "city", "شهر", "/ˈsɪti/", "Tehran is a big city.", "تهران شهر بزرگی است."),
      w("town", "town", "شهرک", "/taʊn/", "My grandfather lives in a small town.", "پدربزرگم در یک شهرک کوچک زندگی می‌کند."),
      w("village", "village", "روستا", "/ˈvɪlɪdʒ/", "There are 20 houses in the village.", "در روستا ۲۰ خانه هست."),
      w("country", "country", "کشور", "/ˈkʌntri/", "Iran is a beautiful country.", "ایران کشوری زیباست."),
      w("iran", "Iran", "ایران", "/ɪˈrɑːn/", "I love my country, Iran.", "من کشورم ایران را دوست دارم."),
      w("tehran", "Tehran", "تهران", "/teˈrɑːn/", "Tehran is the capital of Iran.", "تهران پایتخت ایران است."),
      w("phone", "phone", "تلفن", "/fəʊn/", "My phone number is 0912…", "شماره تلفن من ۰۹۱۲… است."),
      w("number", "number", "شماره", "/ˈnʌmbə/", "What is your house number?", "شماره خانه تو چیست؟"),
      w("apartment", "apartment", "آپارتمان", "/əˈpɑːtmənt/", "We live in a small apartment.", "ما در یک آپارتمان کوچک زندگی می‌کنیم."),
    ],
  },
  {
    id: "l8",
    no: 8,
    title: "My Favorite Food",
    titleFa: "غذای مورد علاقه من",
    emoji: "🍔",
    color: "#f43f5e",
    words: [
      w("favorite", "favorite", "مورد علاقه", "/ˈfeɪvərɪt/", "Pizza is my favorite food.", "پیتزا غذای مورد علاقه من است."),
      w("food", "food", "غذا", "/fuːd/", "Iranian food is famous.", "غذای ایرانی معروف است."),
      w("rice", "rice", "برنج", "/raɪs/", "We eat rice with lunch.", "ما با ناهار برنج می‌خوریم."),
      w("bread", "bread", "نان", "/bred/", "She bakes fresh bread.", "او نان تازه می‌پزد."),
      w("kebab", "kebab", "کباب", "/kɪˈbæb/", "My dad cooks kebab on Friday.", "پدرم جمعه‌ها کباب درست می‌کند."),
      w("pizza", "pizza", "پیتزا", "/ˈpiːtsə/", "Let's order a pizza!", "بیایید پیتزا سفارش دهیم!"),
      w("salad", "salad", "سالاد", "/ˈsæləd/", "A green salad is healthy.", "سالاد سبز سالم است."),
      w("soup", "soup", "سوپ", "/suːp/", "The soup is very hot.", "سوپ خیلی داغ است."),
      w("sandwich", "sandwich", "ساندویچ", "/ˈsænwɪdʒ/", "I had a cheese sandwich.", "من یک ساندویچ پنیر خوردم."),
      w("hamburger", "hamburger", "همبرگر", "/ˈhæmbɜːɡə/", "He wants a hamburger and juice.", "او یک همبرگر و آبمیوه می‌خواهد."),
      w("juice", "juice", "آبمیوه", "/dʒuːs/", "Orange juice is my favorite drink.", "آب پرتقال نوشیدنی مورد علاقه من است."),
      w("apple", "apple", "سیب", "/ˈæpl/", "An apple a day keeps you healthy.", "سیب در روز، بدن را سالم نگه می‌دارد."),
      w("banana", "banana", "موز", "/bəˈnɑːnə/", "Monkeys love bananas.", "میمون‌ها موز دوست دارند."),
      w("water", "water", "آب", "/ˈwɔːtə/", "Drink more water.", "آب بیشتری بنوش."),
      w("milk", "milk", "شیر", "/mɪlk/", "I drink milk every morning.", "من هر صبح شیر می‌نوشم."),
      w("fish", "fish", "ماهی", "/fɪʃ/", "We eat fish on Thursdays.", "ما پنج‌شنبه‌ها ماهی می‌خوریم."),
      w("chicken", "chicken", "مرغ", "/ˈtʃɪkɪn/", "My mother cooks chicken for dinner.", "مادرم برای شام مرغ درست می‌کند."),
      w("ice-cream", "ice cream", "بستنی", "/ˈaɪs kriːm/", "Ice cream is cold and sweet.", "بستنی سرد و شیرین است."),
      w("chocolate", "chocolate", "شکلات", "/ˈtʃɒklət/", "She likes chocolate cake.", "او کیک شکلاتی دوست دارد."),
      w("delicious", "delicious", "خوشمزه", "/dɪˈlɪʃəs/", "This kebab is very delicious.", "این کباب خیلی خوشمزه است."),
    ],
  },
];

export const ALL_WORDS: Word[] = LESSONS.flatMap((l) => l.words);

export const REVIEW_LESSON: Lesson = {
  id: "all",
  no: 0,
  title: "Mixed Review",
  titleFa: "مرور همه درس‌ها",
  emoji: "🌟",
  color: "#22d3ee",
  // a balanced sample from every lesson keeps the mixed round playable
  words: ALL_WORDS.filter((_, i) => i % 6 === 0),
};

export function findLesson(id: string): Lesson {
  if (id === "all") return REVIEW_LESSON;
  return LESSONS.find((l) => l.id === id) ?? LESSONS[7];
}

export function wordKey(lessonId: string, wordId: string) {
  return `${lessonId}:${wordId}`;
}
