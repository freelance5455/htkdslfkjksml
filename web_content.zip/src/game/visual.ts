import type { Delivery, Innings, Shot } from "@/game/logic";

export interface LiveVisual {
  delivery: Delivery | null;
  elapsed: number;
  ballSeconds: number;
  shot: Shot | null;
  wicketFly: number;
  night: boolean;
  sky: string;
  grass: string;
  batColor: string;
  bowlColor: string;
  length: Delivery["length"] | null;
  line: Delivery["line"] | null;
  cam: "side" | "behind";
  quality: "low" | "high";
  innings: Innings | null;
}
