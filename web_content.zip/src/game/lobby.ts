import { Link } from './net';
import { ERA_FACS, FACS, type Era } from './data';
import { mapsFor } from './maps';
import type { Cfg, PCfg } from './world';

export interface SlotView { status: 'idle' | 'making' | 'offer' | 'wait' | 'on' | 'err'; code: string; name: string; fac: string }
export interface LobbyMsg { t: 'lobby'; era: Era; map: string; n: number; you: number; slots: { k: string; name: string; fac: string }[] }

export class HostLobby {
  era: Era; n = 2; mapId = ''; diff = 1; fill = true; hostFac = ''; err = '';
  slots: SlotView[] = Array.from({ length: 4 }, (_, i) => ({ status: 'idle', code: '', name: 'لاعب ' + (i + 1), fac: '' }));
  links: (Link | null)[] = [null, null, null, null]; onChange: () => void = () => { };
  constructor(era: Era) { this.era = era; this.setEra(era); }
  setEra(e: Era) {
    this.era = e; const fl = ERA_FACS(e); this.hostFac = fl[0].id;
    this.slots.forEach((s, i) => { s.fac = fl[Math.min(i, fl.length - 1)].id; });
    this.ensureMap(); this.changed();
  }
  setN(n: number) { this.n = n; for (let i = n; i < 4; i++) this.closeSlot(i); this.ensureMap(); this.changed(); }
  setMap(id: string) { this.mapId = id; this.changed(); }
  setHostFac(f: string) { this.hostFac = f; this.changed(); }
  ensureMap() { const l = mapsFor(this.era, this.n); if (!l.find(m => m.id === this.mapId)) this.mapId = l[0].id; }
  changed() { this.broadcast(); this.onChange(); }
  connected() { return this.slots.filter((s, i) => i > 0 && s.status === 'on').length; }
  closeSlot(i: number) { const l = this.links[i]; if (l) { l.onclose = () => { }; l.close(); } this.links[i] = null; this.slots[i].status = 'idle'; this.slots[i].code = ''; }
  async open(i: number) {
    this.closeSlot(i); const s = this.slots[i]; s.status = 'making'; this.onChange();
    try {
      const l = new Link(); this.links[i] = l;
      l.onopen = () => { s.status = 'on'; this.changed(); };
      l.onclose = () => { if (this.links[i] === l) { this.links[i] = null; s.status = 'idle'; s.code = ''; this.changed(); } };
      l.onmsg = m => { if (m.t === 'fac' && FACS[m.f] && FACS[m.f].era === this.era) { s.fac = m.f; this.changed(); } };
      s.code = await l.makeOffer(); s.status = 'offer';
    } catch { s.status = 'err'; }
    this.onChange();
  }
  async scanAnswer(i: number, code: string) {
    const l = this.links[i]; const s = this.slots[i]; if (!l) return;
    try { await l.acceptAnswer(code); s.status = 'wait'; this.onChange(); setTimeout(() => { if (s.status === 'wait') { s.status = 'err'; this.onChange(); } }, 20000); }
    catch { s.status = 'err'; this.onChange(); }
  }
  broadcast() {
    this.links.forEach((l, i) => {
      if (!l || !l.open) return;
      const m: LobbyMsg = { t: 'lobby', era: this.era, map: this.mapId, n: this.n, you: i, slots: this.slots.slice(0, this.n).map((s, k) => ({ k: k === 0 ? 'host' : s.status === 'on' ? 'human' : this.fill ? 'ai' : 'open', name: k === 0 ? 'المضيف' : s.name, fac: k === 0 ? this.hostFac : s.fac })) };
      l.send(m);
    });
  }
  build(): { cfg: Cfg; assign: Map<number, Link> } | string {
    const players: PCfg[] = [{ fac: this.hostFac, name: 'المضيف', ai: -1 }]; const assign = new Map<number, Link>(); const guests: number[] = [];
    const fl = ERA_FACS(this.era);
    for (let i = 1; i < this.n; i++) {
      const s = this.slots[i]; const l = this.links[i];
      if (s.status === 'on' && l && l.open) { players.push({ fac: s.fac, name: s.name, ai: -1 }); assign.set(players.length - 1, l); guests.push(i); }
      else if (this.fill) players.push({ fac: fl[(i + 1) % fl.length].id, name: 'كمبيوتر ' + i, ai: this.diff });
    }
    if (players.length < 2) return 'تحتاج لاعباً واحداً على الأقل (أو فعّل ملء الفراغات بالكمبيوتر)';
    return { cfg: { era: this.era, map: this.mapId, players, seed: (Math.random() * 1e9) | 0, local: 0 }, assign };
  }
  destroy() { for (let i = 0; i < 4; i++) this.closeSlot(i); }
}

export class GuestLobby {
  link: Link | null = null; status: 'idle' | 'making' | 'answer' | 'on' | 'err' | 'closed' = 'idle'; code = ''; info: LobbyMsg | null = null; fac = ''; started = false;
  onChange: () => void = () => { }; onStart: (cfg: Cfg, link: Link) => void = () => { };
  async join(offer: string) {
    this.status = 'making'; this.onChange();
    try {
      const l = new Link(); this.link = l;
      l.onopen = () => { this.status = 'on'; l.send({ t: 'hello' }); this.onChange(); };
      l.onclose = () => { if (!this.started) { this.status = 'closed'; this.onChange(); } };
      l.onmsg = m => {
        if (m.t === 'lobby') { this.info = m; const fl = ERA_FACS(m.era); if (!this.fac || FACS[this.fac]?.era !== m.era) { this.fac = (m.slots[m.you]?.fac && FACS[m.slots[m.you].fac].era === m.era) ? m.slots[m.you].fac : fl[0].id; l.send({ t: 'fac', f: this.fac }); } this.onChange(); }
        else if (m.t === 'start') { this.started = true; this.onStart(m.cfg, l); }
      };
      this.code = await l.makeAnswer(offer); this.status = 'answer';
    } catch { this.status = 'err'; }
    this.onChange();
  }
  pick(f: string) { if (this.info && FACS[f]?.era === this.info.era) { this.fac = f; this.link?.send({ t: 'fac', f }); this.onChange(); } }
  destroy() { if (!this.started) this.link?.close(); }
}
