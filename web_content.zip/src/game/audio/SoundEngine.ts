import { ElementType, RegionId } from '../types/gameTypes';

export class SoundEngine {
  private ctx: AudioContext | null = null;
  private enabled = true;
  private musicVol = 0.25;
  private sfxVol = 0.45;
  private musicTimer: number | null = null;
  private currentTheme: 'village' | 'explore' | 'boss' = 'village';
  private noteIndex = 0;

  public init() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    if (this.musicTimer === null && typeof window !== 'undefined') {
      this.musicTimer = window.setInterval(() => this.tickMusic(), 950);
    }
  }

  public setSettings(enabled: boolean, musicVol: number, sfxVol: number) {
    this.enabled = enabled;
    this.musicVol = musicVol;
    this.sfxVol = sfxVol;
  }

  public setTheme(theme: 'village' | 'explore' | 'boss') {
    if (this.currentTheme !== theme) {
      this.currentTheme = theme;
      this.noteIndex = 0;
    }
  }

  private playTone(
    freq: number,
    duration: number,
    type: OscillatorType,
    volume: number,
    slideToFreq?: number
  ) {
    if (!this.enabled || !this.ctx || this.ctx.state !== 'running') return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    if (slideToFreq) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(30, slideToFreq), now + duration);
    }
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(volume, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.03);
  }

  private tickMusic() {
    if (!this.enabled || !this.ctx || this.ctx.state !== 'running' || this.musicVol <= 0.02) return;
    const v = this.musicVol * 0.14;
    if (this.currentTheme === 'village') {
      const notes = [261.63, 329.63, 392.0, 523.25, 440.0, 392.0, 329.63, 293.66];
      const f = notes[this.noteIndex % notes.length];
      this.playTone(f, 0.85, 'triangle', v);
    } else if (this.currentTheme === 'explore') {
      const notes = [220.0, 261.63, 329.63, 349.23, 329.63, 293.66, 246.94, 220.0];
      const f = notes[this.noteIndex % notes.length];
      this.playTone(f, 1.1, 'sine', v * 0.9);
    } else {
      const notes = [146.83, 146.83, 174.61, 164.81, 130.81, 146.83, 196.0, 174.61];
      const f = notes[this.noteIndex % notes.length];
      this.playTone(f, 0.55, 'sawtooth', v * 0.75);
      this.playTone(f * 0.5, 0.7, 'triangle', v * 0.9);
    }
    this.noteIndex++;
  }

  public playSwordSwing() {
    this.playTone(320, 0.16, 'triangle', this.sfxVol * 0.25, 110);
  }

  public playHit(heavy = false) {
    this.playTone(heavy ? 120 : 190, heavy ? 0.22 : 0.14, 'sawtooth', this.sfxVol * 0.3, 45);
  }

  public playJump() {
    this.playTone(210, 0.14, 'sine', this.sfxVol * 0.18, 390);
  }

  public playFootstep(inWater: boolean) {
    if (inWater) {
      this.playTone(460, 0.09, 'sine', this.sfxVol * 0.12, 220);
    } else {
      this.playTone(95, 0.06, 'triangle', this.sfxVol * 0.09, 55);
    }
  }

  public playSpell(element: ElementType) {
    const v = this.sfxVol * 0.32;
    if (element === 'fire') {
      this.playTone(240, 0.35, 'sawtooth', v, 70);
    } else if (element === 'ice') {
      this.playTone(880, 0.28, 'sine', v, 1320);
    } else if (element === 'water') {
      this.playTone(380, 0.32, 'triangle', v, 210);
    } else {
      this.playTone(920, 0.22, 'square', v * 0.7, 190);
    }
  }

  public playCreatureCall(kind: 'peaceful' | 'dragon' | 'enemy' | 'boss') {
    const v = this.sfxVol * 0.24;
    if (kind === 'peaceful') {
      this.playTone(540, 0.25, 'sine', v, 680);
    } else if (kind === 'dragon') {
      this.playTone(160, 0.45, 'sawtooth', v, 95);
    } else if (kind === 'enemy') {
      this.playTone(185, 0.2, 'square', v * 0.65, 110);
    } else {
      this.playTone(95, 0.7, 'sawtooth', v * 1.2, 48);
    }
  }

  public playLevelUp() {
    const v = this.sfxVol * 0.32;
    this.playTone(440, 0.18, 'triangle', v);
    setTimeout(() => this.playTone(554.37, 0.18, 'triangle', v), 110);
    setTimeout(() => this.playTone(659.25, 0.32, 'triangle', v), 220);
  }

  public playAmbientChime(region: RegionId) {
    if (region === 'green_forest') {
      this.playTone(1180, 0.12, 'sine', this.sfxVol * 0.08, 1480);
    } else if (region === 'ghost_swamp') {
      this.playTone(310, 0.4, 'sine', this.sfxVol * 0.07, 260);
    }
  }

  public dispose() {
    if (this.musicTimer !== null) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
    if (this.ctx) {
      this.ctx.close().catch(() => {});
      this.ctx = null;
    }
  }
}
