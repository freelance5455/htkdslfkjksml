import {
  AudioSettings,
  BiomeId,
  ElementId,
  EntityArchetype,
  SkeletonVariant,
  WeatherKind,
} from '../types';

const EXPLORE_NOTES = [293.66, 349.23, 392.0, 440.0, 523.25, 587.33, 659.25];
const MYSTIC_NOTES = [246.94, 293.66, 329.63, 392.0, 493.88, 587.33];
const COMBAT_NOTES = [146.83, 174.61, 220.0, 261.63, 293.66, 329.63, 440.0];

export interface SpatialHint {
  dx: number;
  dz: number;
  playerYaw: number;
}

export class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private ambientGain: GainNode | null = null;
  private monsterGain: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;

  private ambientSource: AudioBufferSourceNode | null = null;
  private ambientFilter: BiquadFilterNode | null = null;
  private ambientBedGain: GainNode | null = null;

  private settings: AudioSettings;
  private musicTimer = 0;
  private musicStep = 0;
  private birdTimer = 2.5;
  private dripTimer = 1.8;
  private thunderTimer = 9.0;
  private fireCrackleTimer = 1.1;
  private unlocked = false;

  constructor(initialSettings: AudioSettings) {
    this.settings = { ...initialSettings };
  }

  public unlock(): void {
    if (this.unlocked && this.ctx?.state === 'running') return;
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      if (!this.ctx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.musicGain = this.ctx.createGain();
        this.sfxGain = this.ctx.createGain();
        this.ambientGain = this.ctx.createGain();
        this.monsterGain = this.ctx.createGain();

        this.musicGain.connect(this.masterGain);
        this.sfxGain.connect(this.masterGain);
        this.ambientGain.connect(this.masterGain);
        this.monsterGain.connect(this.masterGain);
        this.masterGain.connect(this.ctx.destination);

        this.buildNoiseBuffer();
        this.startAmbientBed();
        this.applyVolumes();
      }
      if (this.ctx.state === 'suspended') {
        void this.ctx.resume();
      }
      this.unlocked = true;
    } catch {
      // AudioContext unavailable in restricted environment
    }
  }

  private buildNoiseBuffer(): void {
    if (!this.ctx) return;
    const len = this.ctx.sampleRate * 2;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    let lastOut = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      lastOut = (lastOut + 0.04 * white) / 1.04;
      data[i] = lastOut * 2.4;
    }
    this.noiseBuffer = buf;
  }

  private startAmbientBed(): void {
    if (!this.ctx || !this.noiseBuffer || !this.ambientGain) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 420;

    const gain = this.ctx.createGain();
    gain.gain.value = 0.06;

    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.ambientGain);
    src.start();

    this.ambientSource = src;
    this.ambientFilter = filter;
    this.ambientBedGain = gain;
  }

  public updateSettings(next: AudioSettings): void {
    this.settings = { ...next };
    this.applyVolumes();
  }

  private applyVolumes(): void {
    if (
      !this.ctx ||
      !this.masterGain ||
      !this.musicGain ||
      !this.sfxGain ||
      !this.ambientGain ||
      !this.monsterGain
    ) {
      return;
    }
    const t = this.ctx.currentTime;
    const master = this.settings.muted ? 0 : this.settings.masterVolume;
    this.masterGain.gain.setTargetAtTime(master, t, 0.05);
    this.musicGain.gain.setTargetAtTime(this.settings.musicVolume, t, 0.05);
    this.sfxGain.gain.setTargetAtTime(this.settings.sfxVolume, t, 0.05);
    this.ambientGain.gain.setTargetAtTime(this.settings.ambientVolume, t, 0.05);
    this.monsterGain.gain.setTargetAtTime(this.settings.monsterVolume ?? 0.8, t, 0.05);
  }

  private getBus(bus: 'sfx' | 'music' | 'ambient' | 'monster'): AudioNode | null {
    if (bus === 'music') return this.musicGain;
    if (bus === 'ambient') return this.ambientGain;
    if (bus === 'monster') return this.monsterGain;
    return this.sfxGain;
  }

  private connectWithSpatial(
    sourceNode: AudioNode,
    bus: 'sfx' | 'music' | 'ambient' | 'monster',
    spatial?: SpatialHint,
  ): void {
    const dest = this.getBus(bus);
    if (!this.ctx || !dest) return;
    if (!spatial) {
      sourceNode.connect(dest);
      return;
    }
    const dist = Math.hypot(spatial.dx, spatial.dz);
    const atten = Math.max(0.06, Math.min(1, 1 - dist / 36));
    const rightX = Math.cos(spatial.playerYaw);
    const rightZ = -Math.sin(spatial.playerYaw);
    const side = spatial.dx * rightX + spatial.dz * rightZ;
    const pan = Math.max(-0.88, Math.min(0.88, side / 14));

    const attenGain = this.ctx.createGain();
    attenGain.gain.value = atten;

    if (typeof this.ctx.createStereoPanner === 'function') {
      const panner = this.ctx.createStereoPanner();
      panner.pan.value = pan;
      sourceNode.connect(attenGain);
      attenGain.connect(panner);
      panner.connect(dest);
    } else {
      sourceNode.connect(attenGain);
      attenGain.connect(dest);
    }
  }

  private playTone(
    freq: number,
    endFreq: number,
    duration: number,
    type: OscillatorType,
    gainVal: number,
    bus: 'sfx' | 'music' | 'ambient' | 'monster' = 'sfx',
    spatial?: SpatialHint,
  ): void {
    if (!this.ctx || this.settings.muted || this.ctx.state !== 'running') return;
    if (!this.getBus(bus)) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(25, freq), t);
    if (endFreq !== freq) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(25, endFreq), t + duration);
    }
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(gainVal, t + Math.min(0.02, duration * 0.25));
    g.gain.exponentialRampToValueAtTime(0.0001, t + duration);

    osc.connect(g);
    this.connectWithSpatial(g, bus, spatial);
    osc.start(t);
    osc.stop(t + duration + 0.02);
  }

  private playNoiseBurst(
    filterFreq: number,
    q: number,
    duration: number,
    gainVal: number,
    bus: 'sfx' | 'ambient' | 'monster' = 'sfx',
    spatial?: SpatialHint,
  ): void {
    if (!this.ctx || !this.noiseBuffer || this.settings.muted || this.ctx.state !== 'running') return;
    if (!this.getBus(bus)) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(filterFreq, t);
    filter.Q.setValueAtTime(q, t);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(gainVal, t + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t + duration);

    src.connect(filter);
    filter.connect(g);
    this.connectWithSpatial(g, bus, spatial);
    src.start(t, Math.random() * 1.0, duration + 0.03);
  }

  public playFootstep(surface: 'grass' | 'stone' | 'water' | 'snow' | 'sand'): void {
    if (!this.unlocked) return;
    if (surface === 'water') {
      this.playNoiseBurst(850, 1.5, 0.16, 0.18, 'sfx');
      this.playTone(260, 140, 0.11, 'sine', 0.08);
    } else if (surface === 'stone') {
      this.playNoiseBurst(1300, 2.5, 0.06, 0.12, 'sfx');
      this.playTone(175, 85, 0.055, 'triangle', 0.09);
    } else if (surface === 'snow' || surface === 'sand') {
      this.playNoiseBurst(2100, 1.2, 0.09, 0.09, 'sfx');
    } else {
      this.playNoiseBurst(1600, 1.8, 0.07, 0.08, 'sfx');
    }
  }

  public playSlash(): void {
    this.playNoiseBurst(920, 0.9, 0.16, 0.22, 'sfx');
    this.playTone(420, 145, 0.14, 'triangle', 0.12);
  }

  public playBlockClang(): void {
    if (!this.unlocked) return;
    this.playTone(980, 560, 0.16, 'triangle', 0.22, 'sfx');
    this.playTone(1520, 1180, 0.12, 'sine', 0.14, 'sfx');
    this.playNoiseBurst(2600, 2.2, 0.09, 0.18, 'sfx');
  }

  public playHit(weaknessBonus = false): void {
    this.playTone(150, 55, 0.12, 'sawtooth', 0.18);
    if (weaknessBonus) {
      this.playTone(680, 980, 0.14, 'sine', 0.12);
    }
  }

  public playElementSpell(
    elementId: ElementId,
    kind: 'attack' | 'heavy' | 'defense' | 'control' | 'ultimate' | 'fusion',
  ): void {
    const baseFreqMap: Record<ElementId, number> = {
      fire: 320,
      water: 480,
      ice: 760,
      lightning: 640,
      wind: 540,
      earth: 140,
      dark: 185,
      light: 720,
      nature: 520,
      poison: 290,
      metal: 860,
      sound: 440,
      gravity: 115,
      time: 610,
      soul: 560,
      blood: 210,
      moon: 680,
      sun: 410,
      void: 130,
      crystal: 920,
      astral: 780,
      chaos: 255,
      life: 590,
      death: 155,
      dream: 640,
      aether: 700,
    };
    const f = baseFreqMap[elementId] ?? 420;
    const mult =
      kind === 'fusion' ? 1.35 : kind === 'ultimate' ? 1.2 : kind === 'heavy' ? 1.12 : 1.0;

    if (elementId === 'fire' || elementId === 'wind' || elementId === 'poison' || elementId === 'chaos') {
      this.playNoiseBurst(f * 2.2, 1.1, 0.28 * mult, 0.22, 'sfx');
    }
    this.playTone(f, kind === 'defense' ? f * 1.45 : f * 0.65, 0.26 * mult, 'sine', 0.18);
    if (kind === 'ultimate' || kind === 'fusion' || kind === 'heavy') {
      this.playTone(f * 1.5, f * 2.0, 0.34, 'triangle', 0.15);
    }
  }

  public playCreatureSound(
    archetype: EntityArchetype,
    action: 'aggro' | 'hit' | 'death',
    spatial?: SpatialHint,
    skeletonVariant?: SkeletonVariant,
  ): void {
    if (!this.unlocked) return;

    if (archetype === 'skeleton') {
      if (action === 'death') {
        // Cascading dry bone collapse clatter
        this.playNoiseBurst(1650, 3.0, 0.09, 0.18, 'monster', spatial);
        this.playTone(340, 120, 0.14, 'triangle', 0.12, 'monster', spatial);
        setTimeout(() => {
          this.playNoiseBurst(1180, 2.8, 0.08, 0.15, 'monster', spatial);
          this.playTone(230, 85, 0.16, 'triangle', 0.1, 'monster', spatial);
        }, 75);
        return;
      }
      if (action === 'hit') {
        this.playNoiseBurst(1900, 3.4, 0.07, 0.16, 'monster', spatial);
        this.playTone(420, 190, 0.09, 'triangle', 0.12, 'monster', spatial);
        return;
      }
      // Aggro variants
      if (skeletonVariant === 'mage' || skeletonVariant === 'rare' || skeletonVariant === 'commander') {
        this.playTone(175, 118, 0.32, 'sawtooth', 0.13, 'monster', spatial);
        this.playTone(262, 310, 0.28, 'sine', 0.09, 'monster', spatial);
      } else if (skeletonVariant === 'archer') {
        this.playTone(540, 220, 0.13, 'triangle', 0.12, 'monster', spatial);
        this.playNoiseBurst(2100, 2.2, 0.08, 0.12, 'monster', spatial);
      } else {
        this.playNoiseBurst(1420, 2.9, 0.12, 0.15, 'monster', spatial);
        this.playTone(skeletonVariant === 'giant' ? 110 : 210, 125, 0.18, 'triangle', 0.13, 'monster', spatial);
      }
      return;
    }

    if (action === 'death') {
      this.playTone(220, 65, 0.25, 'sawtooth', 0.13, 'monster', spatial);
      return;
    }
    switch (archetype) {
      case 'dragon':
        this.playTone(130, 72, 0.34, 'sawtooth', 0.18, 'monster', spatial);
        this.playNoiseBurst(380, 1.0, 0.25, 0.14, 'monster', spatial);
        break;
      case 'golem':
        this.playTone(95, 55, 0.26, 'square', 0.15, 'monster', spatial);
        break;
      case 'winged':
        this.playTone(720, 960, 0.16, 'triangle', 0.11, 'monster', spatial);
        break;
      case 'wisp':
        this.playTone(880, 1180, 0.22, 'sine', 0.1, 'monster', spatial);
        break;
      case 'slime':
        this.playTone(260, 410, 0.12, 'sine', 0.12, 'monster', spatial);
        break;
      default:
        this.playTone(action === 'hit' ? 280 : 190, 120, 0.16, 'triangle', 0.13, 'monster', spatial);
        break;
    }
  }

  public playPickup(kind: 'chest' | 'crystal' | 'crate' | 'levelup'): void {
    if (kind === 'levelup' || kind === 'chest') {
      this.playTone(440, 440, 0.14, 'triangle', 0.16);
      setTimeout(() => this.playTone(554.37, 554.37, 0.14, 'triangle', 0.16), 90);
      setTimeout(() => this.playTone(659.25, 880, 0.28, 'sine', 0.18), 180);
    } else if (kind === 'crystal') {
      this.playTone(880, 1320, 0.18, 'sine', 0.14);
    } else {
      this.playTone(320, 480, 0.12, 'triangle', 0.12);
    }
  }

  public playPortal(): void {
    this.playTone(240, 620, 0.36, 'sine', 0.18);
    this.playNoiseBurst(700, 1.4, 0.35, 0.16, 'sfx');
  }

  public playThunder(): void {
    this.playNoiseBurst(160, 0.7, 0.95, 0.32, 'ambient');
    this.playTone(78, 36, 0.88, 'sawtooth', 0.16, 'ambient');
  }

  public updateAmbientAndMusic(
    dt: number,
    state: {
      biomeId: BiomeId;
      inDungeon: boolean;
      weather: WeatherKind;
      inCombat: boolean;
      isBossFight: boolean;
      isNight?: boolean;
      nearCampfireDist?: number;
      nearWaterfallDist?: number;
    },
  ): void {
    if (!this.unlocked || !this.ctx || this.ctx.state !== 'running') return;

    // 1. Update continuous ambient wind/rain/storm/snow/waterfall/cavern bed
    if (this.ambientFilter && this.ambientBedGain) {
      const waterfallBoost =
        state.nearWaterfallDist !== undefined && state.nearWaterfallDist < 22
          ? Math.max(0, 1 - state.nearWaterfallDist / 22) * 0.14
          : 0;
      const targetFreq = state.inDungeon
        ? 220
        : state.weather === 'storm'
          ? 1750
          : state.weather === 'rain'
            ? 1450
            : state.weather === 'snow' || state.biomeId === 'snow_peaks'
              ? 880
              : 440;
      const baseGain = state.inDungeon
        ? 0.08
        : state.weather === 'storm'
          ? 0.19
          : state.weather === 'rain'
            ? 0.15
            : state.weather === 'snow'
              ? 0.11
              : state.weather === 'mist'
                ? 0.09
                : 0.05;
      this.ambientFilter.frequency.setTargetAtTime(
        Math.max(targetFreq, waterfallBoost > 0.03 ? 1150 : targetFreq),
        this.ctx.currentTime,
        0.4,
      );
      this.ambientBedGain.gain.setTargetAtTime(baseGain + waterfallBoost, this.ctx.currentTime, 0.4);
    }

    // 2. Campfire crackles when resting near village hearth
    if (!state.inDungeon && state.nearCampfireDist !== undefined && state.nearCampfireDist < 12) {
      this.fireCrackleTimer -= dt;
      if (this.fireCrackleTimer <= 0) {
        this.fireCrackleTimer = 0.45 + Math.random() * 0.9;
        const atten = Math.max(0.2, 1 - state.nearCampfireDist / 12);
        this.playNoiseBurst(2200 + Math.random() * 1400, 3.0, 0.045, 0.09 * atten, 'ambient');
      }
    }

    // 3. Forest birds (daytime) / Cave drips / Rain & Storm thunder
    if (state.inDungeon) {
      this.dripTimer -= dt;
      if (this.dripTimer <= 0) {
        this.dripTimer = 2.4 + Math.random() * 3.8;
        this.playTone(1050 + Math.random() * 350, 1450, 0.09, 'sine', 0.045, 'ambient');
      }
    } else if (
      !state.isNight &&
      (state.biomeId === 'emerald_forest' || state.biomeId === 'sunlit_coast') &&
      state.weather === 'clear'
    ) {
      this.birdTimer -= dt;
      if (this.birdTimer <= 0) {
        this.birdTimer = 3.5 + Math.random() * 5.0;
        const base = 1750 + Math.random() * 450;
        this.playTone(base, base * 1.25, 0.08, 'sine', 0.035, 'ambient');
        setTimeout(
          () => this.playTone(base * 1.15, base * 0.95, 0.09, 'sine', 0.03, 'ambient'),
          110,
        );
      }
    }

    if (!state.inDungeon && (state.weather === 'rain' || state.weather === 'storm')) {
      this.thunderTimer -= dt;
      if (this.thunderTimer <= 0) {
        this.thunderTimer =
          state.weather === 'storm' ? 6.5 + Math.random() * 8.0 : 12 + Math.random() * 14;
        this.playThunder();
      }
    }

    // 4. Adaptive Procedural Music (calm exploration / mystic / dungeon vs combat/boss)
    const stepInterval = state.isBossFight ? 0.36 : state.inCombat ? 0.48 : 0.95;
    this.musicTimer -= dt;
    if (this.musicTimer <= 0) {
      this.musicTimer = stepInterval;
      this.musicStep = (this.musicStep + 1) % 16;

      if (state.isBossFight || state.inCombat) {
        const idx = (this.musicStep * 3) % COMBAT_NOTES.length;
        const note = COMBAT_NOTES[idx];
        this.playTone(note, note, 0.28, 'triangle', 0.06, 'music');
        if (this.musicStep % 2 === 0) {
          this.playTone(note * 0.5, note * 0.48, 0.32, 'sawtooth', 0.04, 'music');
        }
      } else if (state.inDungeon || state.biomeId === 'mystic_woods' || state.biomeId === 'arcane_glade') {
        if (this.musicStep % 2 === 0 || Math.random() < 0.5) {
          const idx = (this.musicStep + Math.floor(this.musicStep / 3)) % MYSTIC_NOTES.length;
          const note = MYSTIC_NOTES[idx];
          this.playTone(note, note * 0.99, 0.85, 'sine', 0.05, 'music');
        }
        if (this.musicStep % 8 === 0) {
          this.playTone(123.47, 123.47, 1.7, 'triangle', 0.04, 'music');
        }
      } else {
        if (this.musicStep % 2 === 0 || Math.random() < 0.6) {
          const idx = (this.musicStep + Math.floor(this.musicStep / 4)) % EXPLORE_NOTES.length;
          const note = EXPLORE_NOTES[idx];
          this.playTone(note, note, 0.78, 'sine', 0.055, 'music');
        }
        if (this.musicStep % 8 === 0) {
          this.playTone(146.83, 146.83, 1.6, 'triangle', 0.045, 'music');
        }
      }
    }
  }

  public dispose(): void {
    try {
      this.ambientSource?.stop();
      this.ambientSource?.disconnect();
      void this.ctx?.close();
    } catch {
      // Ignore cleanup errors
    }
    this.ctx = null;
  }
}

