/**
 * SPR - Sahil Powerful Run
 * High-performance Web Audio API Sound & Synthesizer Engine
 * 100% Offline, Gapless Looping, Capacitor Android & iOS Compatible
 */

import { saveManager } from '../storage/SaveManager';

const BGM_TRACK_FILES = [
  'audio/spr_runner_theme.mp3',
  'audio/spr_runner_theme.ogg',
];

function getCandidatePaths(fileName: string): string[] {
  const list: string[] = [];
  const cleanName = fileName.startsWith('/') ? fileName.slice(1) : fileName;

  // 1. Direct relative path (works inside Capacitor WebView and local dev server)
  list.push(cleanName);
  list.push(`./${cleanName}`);

  // 2. Resolved URL against current window origin / href
  if (typeof window !== 'undefined' && window.location && window.location.href) {
    try {
      const resolved = new URL(cleanName, window.location.href).href;
      if (!list.includes(resolved)) {
        list.push(resolved);
      }
    } catch {
      // Ignore URL parsing errors
    }
  }

  // 3. Absolute path with leading slash as final fallback
  list.push(`/${cleanName}`);

  return list;
}

export class SoundManager {
  private ctx: AudioContext | null = null;
  private sfxGainNode: GainNode | null = null;
  private masterGainNode: GainNode | null = null;
  private musicGainNode: GainNode | null = null;

  private isMusicEnabled: boolean = true;
  private isSfxEnabled: boolean = true;
  private musicVolume: number = 0.7;
  private sfxVolume: number = 0.8;

  private isMusicPlaying: boolean = false;
  private isMusicPaused: boolean = false;
  private fadeIntervalId: number | null = null;

  // Primary BGM Web Audio Engine (Guaranteed 100% offline, gapless loop)
  private rawAudioData: ArrayBuffer | null = null;
  private bgmBuffer: AudioBuffer | null = null;
  private bgmSourceNode: AudioBufferSourceNode | null = null;
  private bgmStartTime: number = 0;
  private bgmPauseOffset: number = 0;
  private isLoadingAudio: boolean = false;
  private activeTrackSrc: string = 'audio/spr_runner_theme.mp3';
  private currentTrackName: string = 'SPR Jungle Runner 138 BPM Theme';

  // Secondary HTMLAudioElement fallback
  private htmlAudioElement: HTMLAudioElement | null = null;
  private blobUrl: string | null = null;

  // Pre-allocated Audio Buffers for Zero-Lag SFX
  private slideBuffer: AudioBuffer | null = null;
  private laneSwitchBuffer: AudioBuffer | null = null;
  private lastCoinSoundTime: number = 0;

  constructor() {
    // Read persisted audio preferences from saveManager on startup
    const saved = saveManager.getSaveData().settings;
    if (saved) {
      if (typeof saved.musicEnabled === 'boolean') this.isMusicEnabled = saved.musicEnabled;
      if (typeof saved.sfxEnabled === 'boolean') this.isSfxEnabled = saved.sfxEnabled;
      if (typeof saved.musicVolume === 'number' && Number.isFinite(saved.musicVolume)) {
        this.musicVolume = Math.max(0, Math.min(1, saved.musicVolume));
      }
      if (typeof saved.sfxVolume === 'number' && Number.isFinite(saved.sfxVolume)) {
        this.sfxVolume = Math.max(0, Math.min(1, saved.sfxVolume));
      }
    }

    console.log(`[SPR Audio] Initialized SoundManager (musicEnabled: ${this.isMusicEnabled}, volume: ${this.musicVolume})`);

    // Cross-device iOS & Android audio gesture unlocker
    this.setupGlobalUnlock();
    this.setupVisibilityListener();

    // Start pre-fetching offline audio asset immediately into memory
    this.preloadOfflineAudioAsset();
  }

  private setupGlobalUnlock() {
    if (typeof window === 'undefined') return;
    const unlockHandler = () => {
      this.unlockAudio();
      window.removeEventListener('touchstart', unlockHandler);
      window.removeEventListener('touchend', unlockHandler);
      window.removeEventListener('pointerdown', unlockHandler);
      window.removeEventListener('click', unlockHandler);
      window.removeEventListener('keydown', unlockHandler);
    };

    window.addEventListener('touchstart', unlockHandler, { passive: true });
    window.addEventListener('touchend', unlockHandler, { passive: true });
    window.addEventListener('pointerdown', unlockHandler, { passive: true });
    window.addEventListener('click', unlockHandler, { passive: true });
    window.addEventListener('keydown', unlockHandler, { passive: true });
  }

  private setupVisibilityListener() {
    if (typeof document === 'undefined') return;
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        // App backgrounded / locked / minimized -> suspend playback
        console.log('[SPR Audio] App hidden: suspending audio');
        if (this.htmlAudioElement && !this.htmlAudioElement.paused) {
          this.htmlAudioElement.pause();
        }
        if (this.ctx && this.ctx.state === 'running') {
          this.ctx.suspend().catch(() => {});
        }
      } else {
        // App restored to foreground
        console.log('[SPR Audio] App visible: resuming audio context');
        if (this.ctx && this.ctx.state === 'suspended') {
          this.ctx.resume().catch(() => {});
        }
        if (this.isMusicPlaying && !this.isMusicPaused && this.isMusicEnabled) {
          if (!this.bgmSourceNode && !this.htmlAudioElement) {
            this.playBufferSource(this.bgmPauseOffset);
          } else if (this.htmlAudioElement && this.htmlAudioElement.paused) {
            this.htmlAudioElement.play().catch(() => {});
          }
        }
      }
    });
  }

  /**
   * Preloads the local offline audio file from APK / public assets
   */
  private async preloadOfflineAudioAsset(): Promise<ArrayBuffer | null> {
    if (this.rawAudioData) {
      return this.rawAudioData;
    }
    if (this.isLoadingAudio) {
      return null;
    }
    this.isLoadingAudio = true;

    for (const fileName of BGM_TRACK_FILES) {
      const candidates = getCandidatePaths(fileName);
      for (const path of candidates) {
        try {
          console.log(`[SPR Audio] Checking local audio asset: ${path}`);
          const res = await fetch(path);
          if (res.ok || (res.status === 0 && res.type !== 'error')) {
            const buf = await res.arrayBuffer();
            if (buf && buf.byteLength > 1000) {
              console.log(`[SPR Audio] Successfully loaded offline BGM (${fileName}, ${buf.byteLength} bytes) from: ${path}`);
              this.rawAudioData = buf;
              this.activeTrackSrc = path;
              this.isLoadingAudio = false;

              // Create Blob URL for HTMLAudioElement emergency fallback
              try {
                const mime = fileName.endsWith('.mp3') ? 'audio/mpeg' : fileName.endsWith('.ogg') ? 'audio/ogg' : 'audio/wav';
                const blob = new Blob([buf], { type: mime });
                if (this.blobUrl) {
                  URL.revokeObjectURL(this.blobUrl);
                }
                this.blobUrl = URL.createObjectURL(blob);
              } catch (e) {
                console.warn('[SPR Audio] Blob URL creation notice:', e);
              }

              // Decode buffer into AudioBuffer if context exists
              if (this.ctx) {
                await this.decodeBgmBuffer();
              }
              return buf;
            }
          }
        } catch (err) {
          // Continue to next candidate path
        }
      }
    }

    console.warn('[SPR Audio] Note: Will retry loading offline BGM asset on user interaction.');
    this.isLoadingAudio = false;
    return null;
  }

  /**
   * Decodes in-memory raw audio ArrayBuffer into a Web Audio AudioBuffer
   */
  private async decodeBgmBuffer(): Promise<AudioBuffer | null> {
    if (this.bgmBuffer) {
      return this.bgmBuffer;
    }

    if (!this.rawAudioData) {
      await this.preloadOfflineAudioAsset();
      if (!this.rawAudioData) {
        return null;
      }
    }

    this.initContext();
    if (!this.ctx) return null;

    try {
      console.log('[SPR Audio] Decoding offline BGM audio buffer...');
      // Slice ArrayBuffer to avoid neutering original buffer
      const bufferCopy = this.rawAudioData.slice(0);
      const audioBuffer = await new Promise<AudioBuffer>((resolve, reject) => {
        const promise = this.ctx!.decodeAudioData(bufferCopy, resolve, reject);
        if (promise && typeof promise.then === 'function') {
          promise.then(resolve).catch(reject);
        }
      });

      this.bgmBuffer = audioBuffer;
      console.log(`[SPR Audio] Offline BGM decoded successfully (${audioBuffer.duration.toFixed(2)}s, ${audioBuffer.sampleRate}Hz, ${audioBuffer.numberOfChannels}ch)`);

      // If playback was requested before decoding finished, start playing now
      if (this.isMusicPlaying && !this.isMusicPaused && this.isMusicEnabled && !this.bgmSourceNode) {
        this.playBufferSource(this.bgmPauseOffset);
      }

      return audioBuffer;
    } catch (err) {
      console.error('[SPR Audio] Error decoding audio buffer:', err);
      return null;
    }
  }

  /**
   * Unlocks Web Audio API for Android WebView and iOS Safari
   */
  public unlockAudio() {
    this.initContext();

    if (this.ctx) {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch((err) => {
          console.warn('[SPR Audio] AudioContext resume error:', err);
        });
      }
      try {
        // Inaudible 1-sample buffer to satisfy mobile audio session
        const buffer = this.ctx.createBuffer(1, 1, 22050);
        const source = this.ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(this.ctx.destination);
        source.start(0);
      } catch {
        // Ignore
      }
    }

    // Ensure audio buffer is ready
    if (!this.bgmBuffer) {
      this.decodeBgmBuffer();
    }
  }

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();

        this.masterGainNode = this.ctx.createGain();
        this.masterGainNode.connect(this.ctx.destination);

        this.musicGainNode = this.ctx.createGain();
        this.musicGainNode.gain.value = this.isMusicEnabled ? this.musicVolume : 0;
        this.musicGainNode.connect(this.masterGainNode);

        this.sfxGainNode = this.ctx.createGain();
        this.sfxGainNode.gain.value = this.isSfxEnabled ? this.sfxVolume : 0;
        this.sfxGainNode.connect(this.masterGainNode);

        // Pre-allocate SFX noise buffers once to eliminate runtime garbage collection
        try {
          const sampleRate = this.ctx.sampleRate || 44100;

          // 1. Reusable Slide Noise Buffer (~0.28s)
          const slideSize = Math.floor(sampleRate * 0.28);
          this.slideBuffer = this.ctx.createBuffer(1, slideSize, sampleRate);
          const slideData = this.slideBuffer.getChannelData(0);
          for (let i = 0; i < slideSize; i++) {
            slideData[i] = (Math.random() * 2 - 1) * Math.sin((i / slideSize) * Math.PI);
          }

          // 2. Reusable Lane Switch Whoosh Buffer (~0.16s)
          const whooshSize = Math.floor(sampleRate * 0.16);
          this.laneSwitchBuffer = this.ctx.createBuffer(1, whooshSize, sampleRate);
          const whooshData = this.laneSwitchBuffer.getChannelData(0);
          for (let i = 0; i < whooshSize; i++) {
            whooshData[i] = (Math.random() * 2 - 1) * Math.pow(Math.sin((i / whooshSize) * Math.PI), 1.5);
          }
        } catch {
          // Graceful fallback
        }
      }
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  // --- CONTROLS & PERSISTENCE ---

  public setMusicEnabled(enabled: boolean) {
    console.log(`[SPR Audio] setMusicEnabled(${enabled})`);
    this.isMusicEnabled = enabled;
    saveManager.updateSettings({ musicEnabled: enabled });

    if (this.musicGainNode && this.ctx) {
      this.safeSetValueAtTime(this.musicGainNode.gain, enabled ? this.musicVolume : 0, this.ctx.currentTime);
    }

    if (enabled) {
      if (this.isMusicPlaying && !this.isMusicPaused) {
        if (!this.bgmSourceNode && !this.htmlAudioElement) {
          this.playBufferSource(this.bgmPauseOffset);
        }
      }
    } else {
      this.stopBufferSource();
      this.stopHtmlAudio();
    }
  }

  public toggleMusic(): boolean {
    const next = !this.isMusicEnabled;
    this.setMusicEnabled(next);
    return next;
  }

  public setSfxEnabled(enabled: boolean) {
    this.isSfxEnabled = enabled;
    saveManager.updateSettings({ sfxEnabled: enabled });

    if (this.sfxGainNode) {
      this.sfxGainNode.gain.value = enabled ? this.sfxVolume : 0;
    }
  }

  public toggleSfx(): boolean {
    const next = !this.isSfxEnabled;
    this.setSfxEnabled(next);
    return next;
  }

  public setMusicVolume(vol: number) {
    const safeVol = Number.isFinite(vol) ? Math.max(0, Math.min(1, vol)) : 0.7;
    this.musicVolume = safeVol;
    saveManager.updateSettings({ musicVolume: safeVol });

    if (this.musicGainNode && this.isMusicEnabled && this.ctx) {
      this.safeSetValueAtTime(this.musicGainNode.gain, this.musicVolume, this.ctx.currentTime);
    }
    if (this.htmlAudioElement && this.isMusicEnabled) {
      this.htmlAudioElement.volume = this.musicVolume;
    }
  }

  public setSfxVolume(vol: number) {
    const safeVol = Number.isFinite(vol) ? Math.max(0, Math.min(1, vol)) : 0.8;
    this.sfxVolume = safeVol;
    saveManager.updateSettings({ sfxVolume: safeVol });

    if (this.sfxGainNode && this.isSfxEnabled) {
      this.sfxGainNode.gain.value = this.sfxVolume;
    }
  }

  public getSettings() {
    return {
      musicEnabled: this.isMusicEnabled,
      sfxEnabled: this.isSfxEnabled,
      musicVolume: this.musicVolume,
      sfxVolume: this.sfxVolume,
      trackName: this.currentTrackName,
      isCustomTrack: this.activeTrackSrc !== 'audio/spr_runner_theme.mp3',
    };
  }

  public getIsMusicPlaying(): boolean {
    return this.isMusicPlaying && !this.isMusicPaused && this.isMusicEnabled;
  }

  // --- CUSTOM AUDIO UPLOAD & RESET ---

  public async loadCustomMusic(urlOrBlob: string, fileName?: string) {
    this.stopMusic();
    this.currentTrackName = fileName || 'Custom Music Track';
    this.activeTrackSrc = urlOrBlob;

    try {
      const res = await fetch(urlOrBlob);
      const buf = await res.arrayBuffer();
      this.rawAudioData = buf;
      this.bgmBuffer = null;
      await this.decodeBgmBuffer();
      if (this.isMusicPlaying && this.isMusicEnabled && !this.isMusicPaused) {
        this.playBufferSource(0);
      }
    } catch (err) {
      console.error('[SPR Audio] Error loading custom track:', err);
    }
  }

  public resetToDefaultMusic() {
    this.stopMusic();
    this.rawAudioData = null;
    this.bgmBuffer = null;
    this.currentTrackName = 'SPR Jungle Runner 138 BPM Theme';
    this.activeTrackSrc = 'audio/spr_runner_theme.mp3';
    this.preloadOfflineAudioAsset().then(() => {
      this.decodeBgmBuffer();
    });
  }

  // --- GAMEPLAY BACKGROUND MUSIC LIFECYCLE ---

  /**
   * Starts background music when gameplay begins or restarts.
   * Looping is mathematically seamless and does NOT restart on jump/slide/coin collection.
   * Guarantees ZERO duplicate instances.
   */
  public startMusic() {
    console.log('[SPR Audio] startMusic() called');
    this.initContext();
    this.clearFade();

    // Guard: If already playing without pause, do not create duplicate instance
    if (this.isMusicPlaying && !this.isMusicPaused && this.bgmSourceNode) {
      console.log('[SPR Audio] Music already active, ignoring duplicate start call');
      return;
    }

    this.isMusicPlaying = true;
    this.isMusicPaused = false;
    this.bgmPauseOffset = 0;

    if (!this.isMusicEnabled) {
      this.stopBufferSource();
      this.stopHtmlAudio();
      return;
    }

    if (this.bgmBuffer) {
      this.playBufferSource(0);
    } else {
      this.decodeBgmBuffer().then(() => {
        if (this.isMusicPlaying && !this.isMusicPaused && this.isMusicEnabled) {
          this.playBufferSource(0);
        }
      });
    }
  }

  /**
   * Plays WebAudio in-memory looping buffer.
   * Works 100% offline in Android WebView and Airplane Mode.
   */
  private playBufferSource(offset: number = 0) {
    if (!this.isMusicEnabled || !this.isMusicPlaying || this.isMusicPaused) return;
    this.initContext();
    if (!this.ctx || !this.musicGainNode) return;

    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    if (!this.bgmBuffer) {
      this.decodeBgmBuffer();
      return;
    }

    // Stop any existing instance to strictly prevent duplicate playback
    this.stopBufferSource();
    this.stopHtmlAudio();

    try {
      const source = this.ctx.createBufferSource();
      source.buffer = this.bgmBuffer;
      source.loop = true; // Seamless, gapless looping
      source.connect(this.musicGainNode);

      this.safeSetValueAtTime(this.musicGainNode.gain, this.musicVolume, this.ctx.currentTime);

      const duration = this.bgmBuffer.duration || 1;
      const startOffset = Math.max(0, offset % duration);

      source.start(0, startOffset);

      this.bgmSourceNode = source;
      this.bgmStartTime = this.ctx.currentTime - startOffset;
      console.log(`[SPR Audio] BGM playing via WebAudio (offset: ${startOffset.toFixed(2)}s, volume: ${this.musicVolume})`);
    } catch (err) {
      console.warn('[SPR Audio] WebAudio source error, attempting HTMLAudio fallback:', err);
      this.playHtmlAudio(offset);
    }
  }

  private stopBufferSource() {
    if (this.bgmSourceNode) {
      try {
        this.bgmSourceNode.stop();
        this.bgmSourceNode.disconnect();
      } catch {
        // Already stopped
      }
      this.bgmSourceNode = null;
    }
  }

  /**
   * Secondary fallback using HTMLAudioElement with local blob
   */
  private playHtmlAudio(offset: number = 0) {
    if (!this.isMusicEnabled || !this.isMusicPlaying || this.isMusicPaused) return;

    this.stopHtmlAudio();

    try {
      const audio = new Audio();
      audio.src = this.blobUrl || getCandidatePaths('audio/spr_runner_theme.mp3')[0];
      audio.loop = true;
      audio.volume = this.musicVolume;
      (audio as unknown as { playsInline?: boolean }).playsInline = true;
      audio.setAttribute('playsinline', 'true');
      audio.setAttribute('webkit-playsinline', 'true');

      if (offset > 0) {
        try {
          audio.currentTime = offset;
        } catch {
          // ignore
        }
      }

      const p = audio.play();
      if (p !== undefined) {
        p.then(() => {
          console.log('[SPR Audio] BGM playing via HTMLAudioElement fallback');
        }).catch((e) => {
          console.warn('[SPR Audio] HTMLAudioElement fallback play error:', e);
        });
      }

      this.htmlAudioElement = audio;
    } catch (e) {
      console.error('[SPR Audio] HTMLAudioElement fallback error:', e);
    }
  }

  private stopHtmlAudio() {
    if (this.htmlAudioElement) {
      try {
        this.htmlAudioElement.pause();
        this.htmlAudioElement.src = '';
      } catch {
        // ignore
      }
      this.htmlAudioElement = null;
    }
  }

  /**
   * Pauses background music (e.g. when Pause button is pressed).
   * Remembers the current position to resume seamlessly.
   */
  public pauseMusic() {
    console.log('[SPR Audio] pauseMusic() called');
    this.clearFade();
    this.isMusicPaused = true;

    if (this.ctx && this.bgmSourceNode && this.bgmBuffer) {
      const elapsed = this.ctx.currentTime - this.bgmStartTime;
      const duration = this.bgmBuffer.duration || 1;
      this.bgmPauseOffset = Math.max(0, elapsed % duration);
      console.log(`[SPR Audio] Music paused at offset ${this.bgmPauseOffset.toFixed(2)}s`);
    } else if (this.htmlAudioElement) {
      this.bgmPauseOffset = this.htmlAudioElement.currentTime || 0;
    }

    this.stopBufferSource();
    if (this.htmlAudioElement) {
      this.htmlAudioElement.pause();
    }
  }

  /**
   * Resumes background music from current position when unpausing.
   */
  public resumeMusic() {
    console.log(`[SPR Audio] resumeMusic() called (resuming from ${this.bgmPauseOffset.toFixed(2)}s)`);
    this.clearFade();
    this.isMusicPaused = false;
    this.isMusicPlaying = true;
    if (!this.isMusicEnabled) return;

    this.playBufferSource(this.bgmPauseOffset);
  }

  /**
   * Seamlessly continues background music without stopping or resetting playback position.
   * If already playing, leaves it untouched. If paused, resumes at current time.
   */
  public continueMusic() {
    this.clearFade();
    this.isMusicPlaying = true;
    if (!this.isMusicEnabled) return;

    if (this.isMusicPaused) {
      this.resumeMusic();
    } else if (!this.bgmSourceNode && !this.htmlAudioElement) {
      this.startMusic();
    }
  }

  /**
   * Stops music completely and resets playback position.
   */
  public stopMusic() {
    console.log('[SPR Audio] stopMusic() called');
    this.clearFade();
    this.isMusicPlaying = false;
    this.isMusicPaused = false;
    this.bgmPauseOffset = 0;
    this.stopBufferSource();
    this.stopHtmlAudio();
  }

  /**
   * Smoothly fades out music over durationMs (e.g. on game over), then stops.
   */
  public fadeOutMusic(durationMs: number = 600) {
    console.log(`[SPR Audio] fadeOutMusic(${durationMs}ms) called`);
    this.clearFade();
    this.isMusicPlaying = false;
    this.bgmPauseOffset = 0;

    if (this.ctx && this.musicGainNode) {
      const now = this.ctx.currentTime;
      this.safeSetValueAtTime(this.musicGainNode.gain, this.musicVolume, now);
      this.safeLinearRamp(this.musicGainNode.gain, 0.001, now + durationMs / 1000);
    }

    if (this.htmlAudioElement && this.musicVolume > 0) {
      const startVol = this.htmlAudioElement.volume;
      const steps = 10;
      const stepInterval = Math.max(16, Math.floor(durationMs / steps));
      let currentStep = 0;
      this.fadeIntervalId = window.setInterval(() => {
        currentStep++;
        if (this.htmlAudioElement) {
          const factor = Math.max(0, 1 - currentStep / steps);
          this.htmlAudioElement.volume = startVol * factor;
        }
        if (currentStep >= steps) {
          this.clearFade();
        }
      }, stepInterval);
    }

    setTimeout(() => {
      this.stopMusic();
      if (this.ctx && this.musicGainNode) {
        this.safeSetValueAtTime(this.musicGainNode.gain, this.isMusicEnabled ? this.musicVolume : 0, this.ctx.currentTime);
      }
    }, durationMs + 20);
  }

  private clearFade() {
    if (this.fadeIntervalId !== null) {
      window.clearInterval(this.fadeIntervalId);
      this.fadeIntervalId = null;
    }
  }

  // --- ROBUST AUDIOPARAM GUARDS (Fixes non-finite AudioParam errors) ---
  private safeSetValueAtTime(param: AudioParam | undefined, value: number, time: number) {
    if (!param || !Number.isFinite(value) || !Number.isFinite(time)) return;
    try {
      param.setValueAtTime(value, time);
    } catch {
      // Safety guard
    }
  }

  private safeExponentialRamp(param: AudioParam | undefined, value: number, time: number) {
    if (!param || !Number.isFinite(value) || !Number.isFinite(time)) return;
    const safeVal = Math.max(0.0001, value);
    try {
      param.exponentialRampToValueAtTime(safeVal, time);
    } catch {
      // Safety guard
    }
  }

  private safeLinearRamp(param: AudioParam | undefined, value: number, time: number) {
    if (!param || !Number.isFinite(value) || !Number.isFinite(time)) return;
    try {
      param.linearRampToValueAtTime(value, time);
    } catch {
      // Safety guard
    }
  }

  // --- SOUND EFFECTS ---

  // 1. Coin Sound: Crystalline dual-tone high ping (Throttled to prevent AudioContext congestion)
  public playCoinSound() {
    this.initContext();
    if (!this.isSfxEnabled || !this.ctx || !this.sfxGainNode) return;

    try {
      const now = this.ctx.currentTime;
      if (!Number.isFinite(now)) return;

      // Rate limit to prevent massive oscillator spam during magnet coin floods
      if (now - this.lastCoinSoundTime < 0.038) {
        return;
      }
      this.lastCoinSoundTime = now;

      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc1.type = 'sine';
      osc2.type = 'sine';
      this.safeSetValueAtTime(osc1.frequency, 987.77, now); // B5
      this.safeSetValueAtTime(osc1.frequency, 1318.51, now + 0.06); // E6
      this.safeSetValueAtTime(osc2.frequency, 1975.53, now); // B6
      this.safeSetValueAtTime(osc2.frequency, 2637.02, now + 0.06); // E7

      this.safeSetValueAtTime(gain.gain, 0.35, now);
      this.safeExponentialRamp(gain.gain, 0.001, now + 0.2);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(this.sfxGainNode);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.2);
      osc2.stop(now + 0.2);
    } catch {
      // AudioParam safety
    }
  }

  // 2. Jump Sound: Swift athletic whoosh upwards
  public playJumpSound() {
    this.initContext();
    if (!this.isSfxEnabled || !this.ctx || !this.sfxGainNode) return;

    try {
      const now = this.ctx.currentTime;
      if (!Number.isFinite(now)) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      this.safeSetValueAtTime(osc.frequency, 160, now);
      this.safeExponentialRamp(osc.frequency, 540, now + 0.22);

      this.safeSetValueAtTime(gain.gain, 0.45, now);
      this.safeExponentialRamp(gain.gain, 0.001, now + 0.25);

      osc.connect(gain);
      gain.connect(this.sfxGainNode);

      osc.start(now);
      osc.stop(now + 0.25);
    } catch {
      // AudioParam safety
    }
  }

  // 3. Slide Sound: Ground dust whoosh using pre-allocated buffer (Zero allocations)
  public playSlideSound() {
    this.initContext();
    if (!this.isSfxEnabled || !this.ctx || !this.sfxGainNode || !this.slideBuffer) return;

    try {
      const now = this.ctx.currentTime;
      if (!Number.isFinite(now)) return;

      const noise = this.ctx.createBufferSource();
      noise.buffer = this.slideBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      this.safeSetValueAtTime(filter.frequency, 450, now);
      filter.Q.value = 2;

      const gain = this.ctx.createGain();
      this.safeSetValueAtTime(gain.gain, 0.45, now);
      this.safeExponentialRamp(gain.gain, 0.01, now + 0.28);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.sfxGainNode);

      noise.start(now);
      noise.stop(now + 0.28);
    } catch {
      // AudioParam safety
    }
  }

  // 3b. Lane Switch Sound: Snappy lateral whoosh using pre-allocated buffer
  public playLaneSwitchSound() {
    this.initContext();
    if (!this.isSfxEnabled || !this.ctx || !this.sfxGainNode || !this.laneSwitchBuffer) return;

    try {
      const now = this.ctx.currentTime;
      if (!Number.isFinite(now)) return;

      const noise = this.ctx.createBufferSource();
      noise.buffer = this.laneSwitchBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      this.safeSetValueAtTime(filter.frequency, 650, now);
      filter.Q.value = 1.6;

      const gain = this.ctx.createGain();
      this.safeSetValueAtTime(gain.gain, 0.35, now);
      this.safeExponentialRamp(gain.gain, 0.01, now + 0.16);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.sfxGainNode);

      noise.start(now);
      noise.stop(now + 0.16);
    } catch {
      // AudioParam safety
    }
  }

  // 4. Game Over Sound: Dramatic descending crash and gong
  public playGameOverSound() {
    this.initContext();
    if (!this.isSfxEnabled || !this.ctx || !this.sfxGainNode) return;

    try {
      const now = this.ctx.currentTime;
      if (!Number.isFinite(now)) return;
      
      // Impact thud
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      this.safeSetValueAtTime(osc.frequency, 220, now);
      this.safeExponentialRamp(osc.frequency, 40, now + 0.8);

      this.safeSetValueAtTime(gain.gain, 0.7, now);
      this.safeExponentialRamp(gain.gain, 0.001, now + 1.2);

      osc.connect(gain);
      gain.connect(this.sfxGainNode);
      osc.start(now);
      osc.stop(now + 1.2);

      // Horror bell dissonant tone
      const bell = this.ctx.createOscillator();
      const bellGain = this.ctx.createGain();
      bell.type = 'sine';
      this.safeSetValueAtTime(bell.frequency, 116.54, now); // Bb2 eerie dissonance

      this.safeSetValueAtTime(bellGain.gain, 0.5, now);
      this.safeExponentialRamp(bellGain.gain, 0.001, now + 1.8);

      bell.connect(bellGain);
      bellGain.connect(this.sfxGainNode);
      bell.start(now);
      bell.stop(now + 1.8);
    } catch {
      // AudioParam safety
    }
  }

  // 5. Button Click: Crisp tactile UI feedback
  public playButtonClick() {
    this.initContext();
    if (!this.isSfxEnabled || !this.ctx || !this.sfxGainNode) return;

    try {
      const now = this.ctx.currentTime;
      if (!Number.isFinite(now)) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      this.safeSetValueAtTime(osc.frequency, 800, now);
      this.safeExponentialRamp(osc.frequency, 400, now + 0.04);

      this.safeSetValueAtTime(gain.gain, 0.3, now);
      this.safeExponentialRamp(gain.gain, 0.001, now + 0.05);

      osc.connect(gain);
      gain.connect(this.sfxGainNode);

      osc.start(now);
      osc.stop(now + 0.05);
    } catch {
      // AudioParam safety
    }
  }

  // 6. Danger Warning Horn: Deep horror foghorn echoing through the jungle
  public playDangerWarningHorn() {
    this.initContext();
    if (!this.isSfxEnabled || !this.ctx || !this.sfxGainNode) return;

    try {
      const now = this.ctx.currentTime;
      if (!Number.isFinite(now)) return;
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc1.type = 'sawtooth';
      osc2.type = 'sawtooth';

      // Dissonant minor second foghorn (73.4Hz D2 & 77.8Hz D#2)
      this.safeSetValueAtTime(osc1.frequency, 73.4, now);
      this.safeSetValueAtTime(osc2.frequency, 78.2, now);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      this.safeSetValueAtTime(filter.frequency, 280, now);
      this.safeLinearRamp(filter.frequency, 550, now + 0.3);
      this.safeExponentialRamp(filter.frequency, 180, now + 1.1);

      this.safeSetValueAtTime(gain.gain, 0.01, now);
      this.safeLinearRamp(gain.gain, 0.65, now + 0.2);
      this.safeExponentialRamp(gain.gain, 0.001, now + 1.1);

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);
      gain.connect(this.sfxGainNode);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 1.1);
      osc2.stop(now + 1.1);
    } catch {
      // AudioParam safety
    }
  }

  // 7. Powerup Pickup: Ascending energetic fanfare
  public playPowerupSound() {
    this.initContext();
    if (!this.isSfxEnabled || !this.ctx || !this.sfxGainNode) return;

    try {
      const now = this.ctx.currentTime;
      if (!Number.isFinite(now)) return;
      const freqs = [330, 440, 554.37, 659.25, 880];
      freqs.forEach((freq, idx) => {
        if (!this.ctx || !this.sfxGainNode) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const startTime = now + idx * 0.06;

        osc.type = 'sine';
        this.safeSetValueAtTime(osc.frequency, freq, startTime);

        this.safeSetValueAtTime(gain.gain, 0.3, startTime);
        this.safeExponentialRamp(gain.gain, 0.001, startTime + 0.18);

        osc.connect(gain);
        gain.connect(this.sfxGainNode);

        osc.start(startTime);
        osc.stop(startTime + 0.18);
      });
    } catch {
      // AudioParam safety
    }
  }

  // 8. Shield Smash: Metallic protective barrier break
  public playShieldBreakSound() {
    this.initContext();
    if (!this.isSfxEnabled || !this.ctx || !this.sfxGainNode) return;

    try {
      const now = this.ctx.currentTime;
      if (!Number.isFinite(now)) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      this.safeSetValueAtTime(osc.frequency, 600, now);
      this.safeExponentialRamp(osc.frequency, 80, now + 0.35);

      this.safeSetValueAtTime(gain.gain, 0.5, now);
      this.safeExponentialRamp(gain.gain, 0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(this.sfxGainNode);
      osc.start(now);
      osc.stop(now + 0.35);
    } catch {
      // AudioParam safety
    }
  }

  // 9. Powerful Fire Rock / Rocket Thruster Launch Sound
  public playRocketLaunchSound() {
    this.initContext();
    if (!this.isSfxEnabled || !this.ctx || !this.sfxGainNode) return;

    try {
      const now = this.ctx.currentTime;
      if (!Number.isFinite(now)) return;

      // Sub-bass detonation boom
      const boom = this.ctx.createOscillator();
      const boomGain = this.ctx.createGain();
      boom.type = 'sine';
      this.safeSetValueAtTime(boom.frequency, 160, now);
      this.safeExponentialRamp(boom.frequency, 32, now + 0.7);

      this.safeSetValueAtTime(boomGain.gain, 0.75, now);
      this.safeExponentialRamp(boomGain.gain, 0.001, now + 0.7);

      boom.connect(boomGain);
      boomGain.connect(this.sfxGainNode);
      boom.start(now);
      boom.stop(now + 0.7);

      // Ascending supersonic rocket jet whoosh
      const jet = this.ctx.createOscillator();
      const jetGain = this.ctx.createGain();
      jet.type = 'sawtooth';
      this.safeSetValueAtTime(jet.frequency, 120, now);
      this.safeLinearRamp(jet.frequency, 480, now + 0.4);
      this.safeExponentialRamp(jet.frequency, 220, now + 1.2);

      this.safeSetValueAtTime(jetGain.gain, 0.05, now);
      this.safeLinearRamp(jetGain.gain, 0.55, now + 0.25);
      this.safeExponentialRamp(jetGain.gain, 0.001, now + 1.2);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      this.safeSetValueAtTime(filter.frequency, 300, now);
      this.safeLinearRamp(filter.frequency, 1800, now + 0.5);
      this.safeExponentialRamp(filter.frequency, 400, now + 1.2);

      jet.connect(filter);
      filter.connect(jetGain);
      jetGain.connect(this.sfxGainNode);

      jet.start(now);
      jet.stop(now + 1.2);
    } catch {
      // AudioParam safety
    }
  }

  // 10. Authentic Locomotive Train Horn (Approaching 3D train warning)
  public playTrainHornSound() {
    this.initContext();
    if (!this.isSfxEnabled || !this.ctx || !this.sfxGainNode) return;

    try {
      const now = this.ctx.currentTime;
      if (!Number.isFinite(now)) return;

      // Authentic train horn chord: D#4 (311Hz) + F#4 (370Hz)
      const horn1 = this.ctx.createOscillator();
      const horn2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      horn1.type = 'sawtooth';
      horn2.type = 'sawtooth';
      this.safeSetValueAtTime(horn1.frequency, 311.13, now);
      this.safeSetValueAtTime(horn2.frequency, 369.99, now);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      this.safeSetValueAtTime(filter.frequency, 750, now);
      this.safeLinearRamp(filter.frequency, 1100, now + 0.15);
      this.safeExponentialRamp(filter.frequency, 650, now + 0.85);

      this.safeSetValueAtTime(gain.gain, 0.01, now);
      this.safeLinearRamp(gain.gain, 0.45, now + 0.08);
      this.safeSetValueAtTime(gain.gain, 0.45, now + 0.6);
      this.safeExponentialRamp(gain.gain, 0.001, now + 0.9);

      horn1.connect(filter);
      horn2.connect(filter);
      filter.connect(gain);
      gain.connect(this.sfxGainNode);

      horn1.start(now);
      horn2.start(now);
      horn1.stop(now + 0.9);
      horn2.stop(now + 0.9);
    } catch {
      // AudioParam safety
    }
  }
}

export const soundManager = new SoundManager();
