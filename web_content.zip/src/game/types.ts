export type Quality = "low" | "medium" | "high";
export type ArenaId = "olympus" | "tartarus";
export type Phase = "menu" | "countdown" | "fight" | "roundOver" | "matchOver";

export interface PadInput {
  x: number;
  y: number;
  light: number;
  heavy: number;
  dodge: number;
  special: number;
  block: boolean;
}

export const createPad = (): PadInput => ({
  x: 0,
  y: 0,
  light: 0,
  heavy: 0,
  dodge: 0,
  special: 0,
  block: false,
});

export interface Inputs {
  p1: PadInput;
  p2: PadInput;
}

export const createInputs = (): Inputs => ({ p1: createPad(), p2: createPad() });

export interface Cooldowns {
  light: number;
  heavy: number;
  dodge: number;
  special: number;
}

export interface FighterHud {
  name: string;
  epithet: string;
  health: number;
  maxHealth: number;
  energy: number;
  rounds: number;
  accent: string;
  cooldowns: Cooldowns;
  blocking: boolean;
  state: string;
}

export interface HudState {
  phase: Phase;
  round: number;
  timer: number;
  message: string;
  sub: string;
  messageKey: number;
  winner: 0 | 1 | null;
  fighters: [FighterHud, FighterHud];
  score: [number, number];
  fps: number;
}

export interface EngineOptions {
  canvas: HTMLCanvasElement;
  quality: Quality;
  arena: ArenaId;
  muted: boolean;
  volume: number;
  onHud: (hud: HudState) => void;
  onError: (message: string) => void;
  onAutoPause?: () => void;
}

export interface WarriorPalette {
  primary: number;
  secondary: number;
  accent: number;
  cloth: number;
  leather: number;
  skin: number;
  glow: number;
  glowCss: string;
  blade: number;
}

export interface WarriorConfig {
  id: "aether" | "inferno";
  name: string;
  epithet: string;
  title: string;
  weapon: "sword" | "cleaver";
  palette: WarriorPalette;
  scale: number;
}

export const AETHER: WarriorConfig = {
  id: "aether",
  name: "AETHER",
  epithet: "Champion of the Azure Sky",
  title: "Storm-Bound Sentinel",
  weapon: "sword",
  scale: 1,
  palette: {
    primary: 0x9fb6cc,
    secondary: 0x2f4a66,
    accent: 0x49d8ff,
    cloth: 0x14304f,
    leather: 0x2a2118,
    skin: 0xc79a78,
    glow: 0x54e2ff,
    glowCss: "#54e2ff",
    blade: 0xd8f4ff,
  },
};

export const INFERNO: WarriorConfig = {
  id: "inferno",
  name: "INFERNO",
  epithet: "Tyrant of the Burning Forge",
  title: "Ashen Warlord",
  weapon: "cleaver",
  scale: 1.04,
  palette: {
    primary: 0x6a4a3a,
    secondary: 0x2a1512,
    accent: 0xff7a2f,
    cloth: 0x4a1210,
    leather: 0x241713,
    skin: 0xa8785a,
    glow: 0xff5a22,
    glowCss: "#ff6a2a",
    blade: 0xffb27a,
  },
};

export const ARENAS: Record<
  ArenaId,
  {
    id: ArenaId;
    name: string;
    subtitle: string;
    sky: number;
    fog: number;
    fogNear: number;
    fogFar: number;
    stone: number;
    stoneDark: number;
    trim: number;
    rune: number;
    ember: number;
    banner: string;
    bannerEmblem: string;
    ambient: number;
    sun: number;
    sunIntensity: number;
    rimA: number;
    rimB: number;
  }
> = {
  olympus: {
    id: "olympus",
    name: "TEMPLE OF OLYMPUS",
    subtitle: "Marble ruins beneath a storm-lit sky",
    sky: 0x070d18,
    fog: 0x0a1422,
    fogNear: 16,
    fogFar: 62,
    stone: 0x8e97a3,
    stoneDark: 0x3d4653,
    trim: 0xc9a961,
    rune: 0x49d8ff,
    ember: 0x9fe8ff,
    banner: "#123a5c",
    bannerEmblem: "#7fe6ff",
    ambient: 0x2a4a6a,
    sun: 0xfff0d0,
    sunIntensity: 2.1,
    rimA: 0x3fa9ff,
    rimB: 0xff7a3c,
  },
  tartarus: {
    id: "tartarus",
    name: "FORGE OF TARTARUS",
    subtitle: "Obsidian pillars above a sea of embers",
    sky: 0x120705,
    fog: 0x1c0a06,
    fogNear: 14,
    fogFar: 58,
    stone: 0x6a5148,
    stoneDark: 0x2c1d19,
    trim: 0xb07a3c,
    rune: 0xff6a2a,
    ember: 0xffb066,
    banner: "#4a120c",
    bannerEmblem: "#ffb066",
    ambient: 0x5a2a18,
    sun: 0xffd0a0,
    sunIntensity: 1.9,
    rimA: 0xff5a22,
    rimB: 0x4fa8ff,
  },
};
