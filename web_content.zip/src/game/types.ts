export type WingId = "foyer" | "library" | "conservatory" | "observatory" | "vault";

export type HotspotIcon =
  | "frame"
  | "scroll"
  | "shirt"
  | "umbrella"
  | "clock"
  | "lamp"
  | "book"
  | "feather"
  | "flower"
  | "drop"
  | "sun"
  | "moon"
  | "star"
  | "scope"
  | "key"
  | "scale"
  | "shield"
  | "file"
  | "crown"
  | "gem"
  | "tree"
  | "compass"
  | "stamp"
  | "pen"
  | "door";

export type Hotspot = {
  id: string;
  label: string;
  x: number;
  y: number;
  icon: HotspotIcon;
  text: string;
  note: string;
};

export type Lock =
  | { kind: "code"; answer: string; prompt: string }
  | { kind: "word"; answer: string; prompt: string }
  | {
      kind: "order";
      prompt: string;
      steps: { id: string; label: string }[];
      answer: string[];
    }
  | {
      kind: "dials";
      prompt: string;
      dials: { id: string; label: string; options: string[] }[];
      answer: string[];
    }
  | {
      kind: "pick";
      prompt: string;
      options: { id: string; label: string; detail: string }[];
      answer: string;
    }
  | {
      kind: "signal";
      prompt: string;
      pads: { id: string; label: string }[];
      answer: string[];
    };

export type Room = {
  n: number;
  wing: WingId;
  name: string;
  line: string;
  hotspots: Hotspot[];
  lock: Lock;
  hints: [string, string, string];
  yield: string;
};

export type Wing = {
  id: WingId;
  name: string;
  range: [number, number];
  motto: string;
};
