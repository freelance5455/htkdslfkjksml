export type Gender = 'boy' | 'girl';

export type SchoolStage = 'nursery' | 'primary' | 'preparatory' | 'secondary' | 'university' | 'graduated';

export interface Child {
  id: string;
  name: string;
  gender: Gender;
  ageDays: number;
  education: number; // 0-100
  happiness: number; // 0-100
  discipline: number; // 0-100
  lastGrade?: 'ممتاز (A)' | 'جيد جداً (B)' | 'جيد (C)' | 'مقبول (D)' | 'راسب (F)';
  stage: SchoolStage;
  schoolType: 'public' | 'experimental' | 'private';
  talent?: string;
  groundedDays?: number;
}

export interface PlayerCourse {
  id: string;
  name: string;
  icon: string;
  durationDays: number;
  daysEnrolled: number;
  dailyHours: number;
  cost: number;
  skillBonus: number;
  repBonus: number;
  completed: boolean;
  unlockedCareerPerk?: string;
}

export interface Friend {
  id: string;
  name: string;
  avatar: string;
  role: string;
  closeness: number;
  loyalty: number;
  description: string;
  perk: string;
}

export type CareerTrack = 'commerce' | 'corporate' | 'tech' | 'logistics' | 'freelance';

export type CareerTier = 1 | 2 | 3 | 4 | 5;

export interface CareerPosition {
  id: string;
  track: CareerTrack;
  tier: CareerTier;
  title: string;
  department: string;
  responsibilities: string;
  minDaysWorked: number;
  minSkill: number;
  basePay: number;
  energyCost: number;
  hoursRequired: number;
  requiredAssets?: string[];
  requiredCourseId?: string;
  perkDescription: string;
}

export type JobType = 'delivery' | 'shop' | 'office' | 'freelance' | 'trade' | 'tech';

export type DifficultyMode = 'realistic' | 'survival' | 'relaxed';

export interface GameState {
  playerName: string;
  partnerName: string;
  difficulty: DifficultyMode;
  money: number;
  health: number;
  hunger: number;
  energy: number;
  fitnessXP: number;
  fitnessLevel: number;
  mood: number;
  rep: number;
  skill: number;
  day: number;
  hour: number;
  timeSpeed: 'slow' | 'normal';
  
  // Relationship
  love: number;
  trust: number;
  lastLoveDay: number;
  engaged: boolean;
  married: boolean;
  romanticSurprisesDone: number;
  
  // Pregnancy & Children
  pregnancyDaysRemaining: number;
  pregnancyGender?: Gender;
  pregnancyCheckupsDone: number;
  children: Child[];
  familyMood: number;
  
  // Courses & Higher Education
  activeCourses: PlayerCourse[];
  completedCourseIds: string[];
  
  // Friends & Social Circle
  friends: Friend[];
  
  // Career Path System (المسار المهني والترقيات)
  currentCareerTrack: CareerTrack;
  currentCareerTier: CareerTier;
  careerDaysWorked: Record<CareerTrack, number>;
  promotionsCount: number;
  
  // Assets & Legacy Career
  assets: string[];
  job: string;
  jobType?: JobType;
  daysWorked: number;
  
  // Dark path & risks
  path: 'clean' | 'dark';
  heat: number;
  gang: number;
  loyalty: number;
  suspicion: number;
  jail: number;
  crimesCount: number;
  cleanDays: number;
  partnerKnowsDark: boolean;
  partnerLeft: boolean;
  
  // Metadata & logs
  dreams: number[];
  achievements: string[];
  log: { id: string; day: number; time: string; text: string; icon?: string }[];
  notifications: { id: string; icon: string; title: string; text: string; day: number; read: boolean }[];
  dead: boolean;
  tutorialCompleted: boolean;
}
