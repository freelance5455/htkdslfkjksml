export type Phase = "menu" | "play" | "pause" | "down";
export type Mode = "tank" | "foot";
export type BlipKind = "inf" | "badtank" | "tank";

export type Blip = { x: number; z: number; k: BlipKind };

export type HudSnapshot = {
  ready: boolean;
  phase: Phase;
  mode: Mode;
  hp: number;
  hpMax: number;
  tankHp: number;
  tankMax: number;
  tankAlive: boolean;
  mag: number;
  magMax: number;
  reloading: boolean;
  cannon: number;
  score: number;
  best: number;
  wave: number;
  left: number;
  banner: string;
  hit: number;
  hurt: number;
  nearTank: boolean;
  x: number;
  z: number;
  yaw: number;
  blips: Blip[];
  shield: number;
};

export type PadInput = {
  moveX: number;
  moveY: number;
  lookX: number;
  lookY: number;
  fire: boolean;
  sprint: boolean;
  queueEnter: boolean;
  queueReload: boolean;
  queuePause: boolean;
};

export type GameApi = {
  start: () => void;
  togglePause: () => void;
  dispose: () => void;
  toggleSound: () => boolean;
  soundOn: () => boolean;
};

export function emptyPad(): PadInput {
  return {
    moveX: 0,
    moveY: 0,
    lookX: 0,
    lookY: 0,
    fire: false,
    sprint: false,
    queueEnter: false,
    queueReload: false,
    queuePause: false,
  };
}

export const initialHud: HudSnapshot = {
  ready: false,
  phase: "menu",
  mode: "tank",
  hp: 100,
  hpMax: 100,
  tankHp: 340,
  tankMax: 340,
  tankAlive: true,
  mag: 30,
  magMax: 30,
  reloading: false,
  cannon: 1,
  score: 0,
  best: 0,
  wave: 1,
  left: 0,
  banner: "",
  hit: 0,
  hurt: 0,
  nearTank: false,
  x: 0,
  z: 26,
  yaw: 0,
  blips: [],
  shield: 0,
};
