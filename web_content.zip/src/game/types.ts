export type AABB = {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
};

export type Phase = "title" | "playing" | "paused" | "dead";

export type Actions = {
  moveX: number;
  moveY: number;
  lookDx: number;
  lookDy: number;
  fire: boolean;
  reload: boolean;
  sprint: boolean;
  pause: boolean;
};

export type ControlsProbe = {
  getYaw: () => number;
  getSpeed: () => number;
  getX: () => number;
  getZ: () => number;
  getAmmo?: () => number;
  setKeys: (codes: string[]) => void;
  setSteer?: (v: number) => void;
};

declare global {
  interface Window {
    __controlsTest?: ControlsProbe;
    __startGame?: () => void;
  }
}

export {};
