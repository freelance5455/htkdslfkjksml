export type ProductId =
  | "bread"
  | "milk"
  | "eggs"
  | "drinks"
  | "chocolate"
  | "biscuits"
  | "noodles"
  | "rice"
  | "meat"
  | "vegetables"
  | "fruits"
  | "shampoo"
  | "cleaning"
  | "frozen";

export type ProductCategory =
  | "bakery"
  | "dairy"
  | "drinks"
  | "snacks"
  | "pantry"
  | "fresh"
  | "personal"
  | "household"
  | "frozen";

export type ShelfKind = "gondola" | "fridge" | "freezer" | "produce" | "rack";

export type CustomerKind =
  | "budget"
  | "rich"
  | "impatient"
  | "child"
  | "elderly"
  | "regular";

export type EmployeeRole =
  | "cashier"
  | "stocker"
  | "cleaner"
  | "security"
  | "delivery"
  | "manager";

export type LocationId = "town" | "city" | "downtown" | "beach" | "business";

export type PanelId =
  | "stock"
  | "shop"
  | "staff"
  | "missions"
  | "order"
  | "settings"
  | null;

export type EventKind =
  | "fire"
  | "outage"
  | "delay"
  | "demand"
  | "shoplifter"
  | "weather"
  | "festival"
  | "fridge";

export type GamePhase = "title" | "playing" | "paused" | "dayend";

export type CustomerState =
  | "enter"
  | "seek"
  | "take"
  | "queue"
  | "pay"
  | "leave"
  | "flee";

export interface ProductDef {
  id: ProductId;
  name: string;
  category: ProductCategory;
  buyPrice: number;
  sellPrice: number;
  unlockLevel: number;
  color: number;
  shelf: ShelfKind;
  perishable: boolean;
  demand: number;
}

export interface SupplierDef {
  id: string;
  name: string;
  specialty: ProductCategory | "all";
  priceMul: number;
  delayMin: number;
  bulk: number;
}

export interface LocationDef {
  id: LocationId;
  name: string;
  rent: number;
  traffic: number;
  unlockLevel: number;
  blurb: string;
}

export interface Vec2 {
  x: number;
  z: number;
}

export interface AABB {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export interface ShelfSlot {
  id: string;
  kind: ShelfKind;
  x: number;
  z: number;
  rot: number;
  w: number;
  d: number;
  productId: ProductId | null;
  stock: number;
  capacity: number;
  dirty: number;
  broken: boolean;
}

export interface CheckoutLane {
  id: string;
  x: number;
  z: number;
  queue: Vec2[];
}

export interface PalletSpot {
  id: string;
  x: number;
  z: number;
}

export interface CartItem {
  productId: ProductId;
  qty: number;
  price: number;
}

export interface Customer {
  id: number;
  kind: CustomerKind;
  x: number;
  z: number;
  yaw: number;
  state: CustomerState;
  list: { productId: ProductId; qty: number; got: number }[];
  cart: CartItem[];
  target: Vec2 | null;
  path: Vec2[];
  wait: number;
  patience: number;
  satisfaction: number;
  speed: number;
  payMethod: "cash" | "card";
  lane: string | null;
  anim: number;
  shoplift: boolean;
  color: number;
  scale: number;
}

export interface Staff {
  id: number;
  role: EmployeeRole;
  name: string;
  level: number;
  x: number;
  z: number;
  yaw: number;
  target: Vec2 | null;
  path: Vec2[];
  wait: number;
  holding: { productId: ProductId; qty: number } | null;
  anim: number;
  speed: number;
}

export interface Order {
  id: number;
  productId: ProductId;
  qty: number;
  supplierId: string;
  cost: number;
  eta: number;
  delayed: boolean;
}

export interface Mission {
  id: string;
  title: string;
  detail: string;
  kind: "sell" | "earn" | "serve" | "rating" | "product";
  target: number;
  progress: number;
  productId?: ProductId;
  rewardMoney: number;
  rewardXp: number;
  done: boolean;
  claimed: boolean;
}

export interface ActiveEvent {
  kind: EventKind;
  t: number;
  dur: number;
  label: string;
}

export interface DailyStats {
  revenue: number;
  expenses: number;
  sold: number;
  served: number;
  lost: number;
}

export interface SimState {
  version: number;
  money: number;
  day: number;
  timeOfDay: number;
  storeOpen: boolean;
  storeLevel: number;
  location: LocationId;
  rating: number;
  xp: number;
  warehouse: Record<ProductId, number>;
  unlocked: Record<ProductId, boolean>;
  sellMul: Record<ProductId, number>;
  shelves: ShelfSlot[];
  staff: Staff[];
  orders: Order[];
  missions: Mission[];
  event: ActiveEvent | null;
  cleanliness: number;
  lights: number;
  decor: number;
  warehouseCap: number;
  checkouts: number;
  player: {
    x: number;
    z: number;
    yaw: number;
    holding: { productId: ProductId; qty: number } | null;
  };
  daily: DailyStats;
  tutorial: number;
  seenHelp: boolean;
  settings: {
    sfx: number;
    music: number;
    shake: boolean;
    quality: "low" | "med" | "high";
  };
  nextCustomer: number;
  nextStaff: number;
  nextOrder: number;
  soldToday: Record<ProductId, number>;
  demandMul: Record<ProductId, number>;
}

export interface HudSnap {
  money: number;
  rating: number;
  day: number;
  clock: string;
  open: boolean;
  prompt: string;
  holding: { productId: ProductId; qty: number; name: string } | null;
  cleanliness: number;
  customers: number;
  queue: number;
  event: string | null;
  tutorial: string | null;
  interact: boolean;
  speed: number;
  yaw: number;
  px: number;
  pz: number;
  storeLevel: number;
  location: LocationId;
  xp: number;
}

export interface DayReport {
  day: number;
  revenue: number;
  expenses: number;
  profit: number;
  sold: number;
  served: number;
  lost: number;
  rating: number;
  rent: number;
  power: number;
  wages: number;
}
