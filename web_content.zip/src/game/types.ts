export const W = 420;
export const H = 760;

export type Phase = "title" | "playing" | "paused" | "over";
export type InputMode = "idle" | "keys" | "pointer";
export type Kind = "dart" | "weaver" | "gunner" | "boss";
export type Pattern = "down" | "sine" | "swoop" | "boss";
export type PickupKind = "multi" | "shield" | "speed";
export type Sfx = "shoot" | "hit" | "explode" | "hurt" | "pickup" | "wave" | "boss";
export type SpriteName = "player" | "dart" | "weaver" | "gunner" | "boss" | "multi" | "shield" | "speed";

export type Input = {
  mode: InputMode;
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  px: number;
  py: number;
  touch: boolean;
};

export type Bullet = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  friendly: boolean;
  life: number;
  alive: boolean;
};

export type Enemy = {
  kind: Kind;
  pattern: Pattern;
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  r: number;
  age: number;
  shoot: number;
  originX: number;
  amp: number;
  phase: number;
  flash: number;
  score: number;
  bossShot: number;
  alive: boolean;
};

export type Pickup = {
  kind: PickupKind;
  x: number;
  y: number;
  vy: number;
  r: number;
  life: number;
  alive: boolean;
};

export type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  alive: boolean;
};

export type Floater = {
  x: number;
  y: number;
  text: string;
  life: number;
  max: number;
  color: string;
  alive: boolean;
};

export type Flash = {
  x: number;
  y: number;
  life: number;
  max: number;
  angle: number;
  alive: boolean;
};

export type Star = {
  x: number;
  y: number;
  layer: 0 | 1 | 2;
  r: number;
  a: number;
};

export type Player = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  iframes: number;
  fireCd: number;
  multi: number;
  shield: number;
  speedT: number;
  exhaust: number;
  alive: boolean;
};

export type Spawn = {
  t: number;
  kind: Kind;
  x: number;
  y: number;
  pattern: Pattern;
  amp: number;
};

export type WaveState = "banner" | "fight" | "clear";

export type Sim = {
  phase: Phase;
  clock: number;
  runTime: number;
  score: number;
  lives: number;
  wave: number;
  waveState: WaveState;
  waveTimer: number;
  banner: string;
  queue: Spawn[];
  player: Player;
  bullets: Bullet[];
  enemies: Enemy[];
  pickups: Pickup[];
  particles: Particle[];
  floats: Floater[];
  flashes: Flash[];
  stars: Star[];
  shake: number;
  hitStop: number;
  hurtFlash: number;
  combo: number;
  comboTimer: number;
  reduceMotion: boolean;
  sfx: (name: Sfx) => void;
  onChange: () => void;
};

export type Sprites = Partial<Record<SpriteName, HTMLImageElement>>;

export type ControlsProbe = {
  getYaw: () => number;
  getSpeed: () => number;
  getX: () => number;
  getY: () => number;
  setKeys: (codes: string[]) => void;
};

declare global {
  interface Window {
    __controlsTest?: ControlsProbe;
    __game?: {
      getPhase: () => Phase;
      getScore: () => number;
      getLives: () => number;
      getWave: () => number;
      getMulti: () => number;
      getShield: () => number;
      getSpeedT: () => number;
    };
  }
}
