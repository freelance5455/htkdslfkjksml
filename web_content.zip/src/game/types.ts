export type Tier = 1 | 2 | 3;

export interface Question {
  q: string;
  a: [string, string, string];
  c: number; // index of the correct answer in `a`
  tier: Tier;
  cat: string;
}

export interface GameStats {
  score: number;
  distance: number;
  correct: number;
  answered: number;
  coins: number;
  maxCombo: number;
  time: number;
  level: number;
}

export type EnginePhase = 'attract' | 'running' | 'paused' | 'dying' | 'over';

export type EngineEvent =
  | { type: 'gameover'; stats: GameStats }
  | { type: 'togglePause' }
  | { type: 'primary' };

export interface QuestionGroup {
  id: number;
  question: Question;
  answers: string[]; // shuffled, index = lane
  correctLane: number;
  z: number;
  active: boolean;
  activatedAt: number;
  activationDist: number;
  resolved: boolean;
  chosenLane: number;
  wasCorrect: boolean;
  resultT: number; // time since resolution
  lines?: string[];
  linesWidth?: number;
  fits?: { w: number; items: { size: number; lines: string[] }[] };
}

export interface CoinEnt {
  kind: 'coin';
  z: number;
  lane: number;
  y: number;
  phase: number;
  dead: boolean;
}

export interface ObstacleEnt {
  kind: 'obstacle';
  z: number;
  lane: number;
  variant: 'rock' | 'hurdle';
  dead: boolean;
  hit: boolean;
}

export interface GateEnt {
  kind: 'gate';
  z: number;
  lane: number;
  group: QuestionGroup;
  dead: boolean;
}

export type Entity = CoinEnt | ObstacleEnt | GateEnt;

export type SceneryVariant = 'palm' | 'pillar' | 'rock' | 'bush' | 'torch' | 'obelisk';

export interface SceneryEnt {
  z: number;
  x: number;
  variant: SceneryVariant;
  seed: number;
}

export interface View {
  W: number;
  H: number;
  cx: number;
  horizonY: number;
  baseY: number;
  laneW: number;
}

export interface PlayerState {
  targetLane: number;
  x: number; // 0..2 lane space (smoothed)
  y: number; // jump height (world units)
  vy: number;
  grounded: boolean;
  fastFall: boolean;
  runPhase: number;
  lean: number;
  squash: number;
  stumbleT: number;
  invulnT: number;
  fallT: number;
  blinkT: number;
}

export interface HighScoreEntry {
  name: string;
  score: number;
  correct: number;
  answered: number;
  distance: number;
  maxCombo: number;
  date: number;
}
