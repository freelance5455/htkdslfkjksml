export type RegionId = 'settlement' | 'verdant' | 'ember' | 'frostveil' | 'marsh' | 'crater';

export type WeaponClass =
  | 'greatsword'
  | 'dualblades'
  | 'hammer'
  | 'longsword'
  | 'bow'
  | 'lance';

export type ElementType = 'none' | 'fire' | 'ice' | 'thunder' | 'poison';

export interface WeaponDef {
  id: string;
  name: string;
  weaponClass: WeaponClass;
  rarity: number;
  attack: number;
  element: ElementType;
  elementDamage: number;
  defenseBonus: number;
  affinity: number; // Critical hit chance %
  description: string;
  cost: number;
  materials: { itemId: string; count: number }[];
  upgradeFrom?: string;
}

export type ArmorSlot = 'head' | 'chest' | 'arms' | 'legs' | 'charm';

export interface ArmorDef {
  id: string;
  name: string;
  slot: ArmorSlot;
  rarity: number;
  defense: number;
  fireRes: number;
  iceRes: number;
  thunderRes: number;
  skillName: string;
  skillDescription: string;
  cost: number;
  materials: { itemId: string; count: number }[];
}

export interface ItemDef {
  id: string;
  name: string;
  category: 'consumable' | 'material' | 'tool';
  icon: string;
  color: string;
  description: string;
  maxStack: number;
  healAmount?: number;
  staminaAmount?: number;
  curesPoison?: boolean;
  isTrap?: boolean;
  isFlash?: boolean;
  sellPrice: number;
}

export interface MonsterPart {
  id: string;
  name: string;
  maxHp: number;
  hp: number;
  broken: boolean;
  breakBonusDrop: string;
  dropRate: number; // 0..1
  severable?: boolean;
  severed?: boolean;
}

export interface MonsterDef {
  id: string;
  name: string;
  species: string;
  title: string;
  region: RegionId;
  baseHp: number;
  baseAttack: number;
  speed: number;
  weakness: ElementType;
  resistance: ElementType;
  color: string;
  accentColor: string;
  glowColor: string;
  size: number;
  parts: MonsterPart[];
  attacks: MonsterAttackDef[];
  drops: { itemId: string; rate: number; count: number }[];
  description: string;
  isApex?: boolean;
  isFinalBoss?: boolean;
}

export interface MonsterAttackDef {
  id: string;
  name: string;
  windupTime: number; // seconds
  activeTime: number;
  recoveryTime: number;
  range: number;
  angleRange?: number; // radians (cone)
  damageMultiplier: number;
  element: ElementType;
  knockback: number;
  inflictsPoison?: boolean;
  telegraphType: 'circle' | 'cone' | 'line' | 'charge';
  projectile?: boolean;
  speed?: number;
}

export interface QuestDef {
  id: string;
  title: string;
  rank: number;
  region: RegionId;
  targetMonsterId?: string;
  targetCount?: number;
  gatherItemId?: string;
  gatherCount?: number;
  rewardZenny: number;
  rewardHunterXp: number;
  bonusItems: { itemId: string; count: number }[];
  description: string;
  timeLimit: number; // seconds (e.g. 600)
  isStory?: boolean;
  unlocksRegion?: RegionId;
}

export interface GatherNode {
  id: string;
  x: number;
  y: number;
  type: 'herb' | 'ore' | 'bone' | 'mushroom' | 'honey' | 'carve';
  respawnTimer: number;
  isGathered: boolean;
  carveSource?: string;
  items: { itemId: string; rate: number; count: number }[];
}

export interface SeveredTailDrop {
  x: number;
  y: number;
  monsterId: string;
  carved: boolean;
  dropItemId: string;
}

export interface PlayerStats {
  level: number;
  hunterRank: number;
  hunterXp: number;
  nextRankXp: number;
  zenny: number;
  hp: number;
  maxHp: number;
  stamina: number;
  maxStamina: number;
  equippedWeaponId: string;
  equippedArmor: Record<ArmorSlot, string>;
  pouch: { itemId: string; count: number }[];
  selectedPouchIndex: number;
  // Weapon gauges
  spiritGauge: number; // 0..100 (Longsword)
  spiritLevel: number; // 0, 1, 2, 3
  spiritDuration: number;
  demonMode: boolean; // (Dual Blades)
  demonGauge: number; // 0..100
  chargeLevel: number; // 0, 1, 2, 3 (Greatsword & Bow)
  chargeTimer: number;
  bowCoating: 'none' | 'power' | 'poison';
}

export interface ActiveMonsterState {
  defId: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  hp: number;
  maxHp: number;
  stamina: number;
  state:
    | 'idle'
    | 'patrol'
    | 'alert'
    | 'roar'
    | 'chase'
    | 'windup'
    | 'attacking'
    | 'recovery'
    | 'stagger'
    | 'exhausted'
    | 'flee'
    | 'dead';
  stateTimer: number;
  enraged: boolean;
  enrageTimer: number;
  parts: MonsterPart[];
  currentAttack: MonsterAttackDef | null;
  attackTargetX: number;
  attackTargetY: number;
  staggerBuildup: number;
  stunBuildup: number;
  poisonBuildup: number;
  isPoisoned: boolean;
  poisonTimer: number;
  isCarved: boolean;
  targetHunter: boolean;
  variantPhase?: number; // 1 or 2 for boss phases
}

export interface FloatingNumber {
  x: number;
  y: number;
  value: number;
  text?: string;
  color: string;
  isCrit?: boolean;
  life: number;
  maxLife: number;
}

export interface Projectile {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  damage: number;
  element: ElementType;
  fromPlayer: boolean;
  life: number;
  maxLife: number;
  color: string;
}

export interface HuntingRecord {
  monsterId: string;
  huntsCompleted: number;
  partsBroken: number;
  fastestTimeSeconds: number;
}

export interface GameSaveData {
  version: number;
  timestamp: number;
  hunterRank: number;
  hunterXp: number;
  zenny: number;
  equippedWeaponId: string;
  equippedArmor: Record<ArmorSlot, string>;
  inventory: { itemId: string; count: number }[];
  craftedEquipment: string[];
  completedQuestIds: string[];
  activeQuestId: string | null;
  unlockedRegions: RegionId[];
  bestiaryKills: Record<string, number>;
  huntingRecords: Record<string, HuntingRecord>;
  settings: {
    graphicsQuality: 'low' | 'med' | 'high';
    soundVolume: number;
    showDamageNumbers: boolean;
    joystickScale: number;
  };
}
