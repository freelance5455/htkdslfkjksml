export interface Appearance {
  shirt: number;
  pants: number;
  hat: 'none' | 'cap' | 'crown' | 'beanie';
  skin: number;
  hair: number;
  backpack: boolean;
}

export const DEFAULT_APPEARANCE: Appearance = {
  shirt: 0x2d7ff9,
  pants: 0x3557a6,
  hat: 'none',
  skin: 0xffd7b5,
  hair: 0x3b2a1e,
  backpack: false,
};

export type ShopCategory = 'Shirts' | 'Pants' | 'Hats' | 'Skin' | 'Hair' | 'Backpacks';

export const CATEGORIES: ShopCategory[] = ['Shirts', 'Pants', 'Hats', 'Skin', 'Hair', 'Backpacks'];

export interface ShopItem {
  id: string;
  name: string;
  price: number;
  category: ShopCategory;
  swatch: string;
  patch: Partial<Appearance>;
}

export const SHOP_ITEMS: ShopItem[] = [
  { id: 'shirt-blue', name: 'Ocean Tee', price: 0, category: 'Shirts', swatch: '#2d7ff9', patch: { shirt: 0x2d7ff9 } },
  { id: 'shirt-red', name: 'Red Hoodie', price: 40, category: 'Shirts', swatch: '#d9423b', patch: { shirt: 0xd9423b } },
  { id: 'shirt-mint', name: 'Mint Tee', price: 60, category: 'Shirts', swatch: '#3ccf91', patch: { shirt: 0x3ccf91 } },
  { id: 'shirt-pink', name: 'Bubblegum', price: 70, category: 'Shirts', swatch: '#ff6fb1', patch: { shirt: 0xff6fb1 } },
  { id: 'shirt-black', name: 'Shadow Jacket', price: 90, category: 'Shirts', swatch: '#2b2d33', patch: { shirt: 0x2b2d33 } },
  { id: 'shirt-gold', name: 'Golden Vest', price: 150, category: 'Shirts', swatch: '#f5c542', patch: { shirt: 0xf5c542 } },
  { id: 'pants-denim', name: 'Denim', price: 0, category: 'Pants', swatch: '#3557a6', patch: { pants: 0x3557a6 } },
  { id: 'pants-olive', name: 'Olive Cargo', price: 50, category: 'Pants', swatch: '#6b7a3a', patch: { pants: 0x6b7a3a } },
  { id: 'pants-white', name: 'Snow Pants', price: 60, category: 'Pants', swatch: '#f1f1f1', patch: { pants: 0xf1f1f1 } },
  { id: 'pants-violet', name: 'Violet Jeans', price: 90, category: 'Pants', swatch: '#7c4dff', patch: { pants: 0x7c4dff } },
  { id: 'pants-black', name: 'Night Pants', price: 60, category: 'Pants', swatch: '#222428', patch: { pants: 0x222428 } },
  { id: 'hat-none', name: 'Bare Head', price: 0, category: 'Hats', swatch: '#cfd8dc', patch: { hat: 'none' } },
  { id: 'hat-cap', name: 'Red Cap', price: 60, category: 'Hats', swatch: '#e0424b', patch: { hat: 'cap' } },
  { id: 'hat-beanie', name: 'Pink Beanie', price: 80, category: 'Hats', swatch: '#ff6fb1', patch: { hat: 'beanie' } },
  { id: 'hat-crown', name: 'Gold Crown', price: 250, category: 'Hats', swatch: '#ffc93c', patch: { hat: 'crown' } },
  { id: 'skin-light', name: 'Light', price: 0, category: 'Skin', swatch: '#ffd7b5', patch: { skin: 0xffd7b5 } },
  { id: 'skin-tan', name: 'Tan', price: 20, category: 'Skin', swatch: '#e0ac7e', patch: { skin: 0xe0ac7e } },
  { id: 'skin-brown', name: 'Caramel', price: 30, category: 'Skin', swatch: '#a96f4a', patch: { skin: 0xa96f4a } },
  { id: 'skin-deep', name: 'Cocoa', price: 40, category: 'Skin', swatch: '#6b4226', patch: { skin: 0x6b4226 } },
  { id: 'hair-dark', name: 'Dark Hair', price: 0, category: 'Hair', swatch: '#3b2a1e', patch: { hair: 0x3b2a1e } },
  { id: 'hair-blonde', name: 'Blonde', price: 40, category: 'Hair', swatch: '#f2d16b', patch: { hair: 0xf2d16b } },
  { id: 'hair-white', name: 'Silver', price: 60, category: 'Hair', swatch: '#eeeeee', patch: { hair: 0xeeeeee } },
  { id: 'hair-blue', name: 'Electric Blue', price: 80, category: 'Hair', swatch: '#3a7bd5', patch: { hair: 0x3a7bd5 } },
  { id: 'bp-none', name: 'No Backpack', price: 0, category: 'Backpacks', swatch: '#9e9e9e', patch: { backpack: false } },
  { id: 'bp-pack', name: 'Adventure Pack', price: 150, category: 'Backpacks', swatch: '#3b5b8a', patch: { backpack: true } },
];

export interface MissionDef {
  text: string;
  kind: 'coins' | 'visit' | 'talk' | 'drive' | 'hidden' | 'walk';
  target: number;
}

export const MISSIONS: MissionDef[] = [
  { text: 'Collect 10 coins', kind: 'coins', target: 10 },
  { text: 'Visit 2 houses or shops', kind: 'visit', target: 2 },
  { text: 'Talk to a local NPC', kind: 'talk', target: 1 },
  { text: 'Drive a car for 150 m', kind: 'drive', target: 150 },
  { text: 'Find a hidden location', kind: 'hidden', target: 1 },
  { text: 'Walk 400 m around town', kind: 'walk', target: 400 },
];

export interface SaveData {
  coins: number;
  owned: string[];
  appearance: Appearance;
  mission: number;
  progress: number;
  found: string[];
  lowGfx: boolean;
}

export interface HudState {
  coins: number;
  speed: number;
  clock: string;
  night: boolean;
  inCar: boolean;
  action: string | null;
  mission: string;
  missionProgress: string;
  missionPct: number;
  missionDone: boolean;
  discovered: number;
  totalHidden: number;
  toast: string | null;
  dialogue: { name: string; text: string } | null;
  shopOpen: boolean;
  owned: string[];
  equipped: string[];
  appearance: Appearance;
  lowGfx: boolean;
  fps: number;
}
