export type GamePhase = "start" | "playing" | "paused" | "over";

export interface BannerEvent {
  id: number;
  title: string;
  sub?: string;
  tone?: "gold" | "teal" | "clay";
}

export interface HudSnapshot {
  hp: number;
  maxHp: number;
  water: number;
  maxWater: number;
  score: number;
  combo: number;
  comboProgress: number;
  shrines: [boolean, boolean, boolean];
  cycles: number;
  night: number;
  time: number;
  kills: number;
  shards: number;
  dashReady: boolean;
  dashProgress: number;
  prompt: "shrine" | "heal" | null;
  promptLabel: string;
  banner: BannerEvent | null;
}

export interface RunResult {
  score: number;
  kills: number;
  shards: number;
  shrines: number;
  cycles: number;
  time: number;
}

export interface ScoreEntry {
  id: string;
  name: string;
  score: number;
  kills: number;
  shards: number;
  cycles: number;
  time: number;
  date: string;
}

export const emptyHud: HudSnapshot = {
  hp: 5,
  maxHp: 5,
  water: 100,
  maxWater: 100,
  score: 0,
  combo: 1,
  comboProgress: 0,
  shrines: [false, false, false],
  cycles: 1,
  night: 0,
  time: 0,
  kills: 0,
  shards: 0,
  dashReady: true,
  dashProgress: 1,
  prompt: null,
  promptLabel: "",
  banner: null,
};
