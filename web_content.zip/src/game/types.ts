export type GameMode = "dm" | "tdm";
export type Team = "sun" | "tide";
export type Quality = "low" | "medium" | "high";
export type Layout = "classic" | "compact";

export interface Settings {
  sensitivity: number;
  sfx: number;
  music: number;
  quality: Quality;
  layout: Layout;
  touch: boolean;
  invertY: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  sensitivity: 1,
  sfx: 0.75,
  music: 0.35,
  quality: "high",
  layout: "classic",
  touch: false,
  invertY: false,
};

export interface WeaponHud {
  id: string;
  name: string;
  short: string;
  ammo: number;
  reserve: number;
  reloading: boolean;
  reloadProgress: number;
  color: string;
}

export interface KillFeedItem {
  id: number;
  killer: string;
  victim: string;
  weapon: string;
  killerTeam: Team | "none";
  victimTeam: Team | "none";
  isPlayer: boolean;
}

export interface Blip {
  x: number;
  z: number;
  team: Team | "none";
  kind: "player" | "bot" | "vehicle" | "pickup";
  alive: boolean;
}

export interface HudState {
  health: number;
  maxHealth: number;
  armor: number;
  maxArmor: number;
  weapons: WeaponHud[];
  weaponIndex: number;
  grenades: number;
  score: number;
  kills: number;
  deaths: number;
  streak: number;
  bestStreak: number;
  timeLeft: number;
  mode: GameMode;
  teamScores: { sun: number; tide: number };
  killFeed: KillFeedItem[];
  blips: Blip[];
  obstacles: { x: number; z: number; w: number; d: number }[];
  scoreboard: { name: string; team: Team | "none"; kills: number; deaths: number; isPlayer: boolean }[];
  player: { x: number; z: number; yaw: number; alive: boolean; respawnIn: number };
  vehicle: { name: string; health: number; maxHealth: number; speed: number } | null;
  nearVehicle: string | null;
  reloading: boolean;
  reloadProgress: number;
  spread: number;
  aiming: boolean;
  firstPerson: boolean;
  crouched: boolean;
  scoreLimit: number;
}

export interface GameResults {
  mode: GameMode;
  score: number;
  kills: number;
  deaths: number;
  accuracy: number;
  bestStreak: number;
  teamScores: { sun: number; tide: number };
  won: boolean;
  reason: "time" | "score";
  place: number;
}

export interface HighScore {
  id: string;
  name: string;
  score: number;
  kills: number;
  mode: GameMode;
  date: string;
  accuracy: number;
}

export type GameEvent =
  | { type: "hit" }
  | { type: "kill"; text: string }
  | { type: "damage" }
  | { type: "explosion" }
  | { type: "pickup"; text: string }
  | { type: "toast"; text: string; tone?: "good" | "bad" | "info" }
  | { type: "streak"; text: string };

export interface EngineCallbacks {
  onHud: (hud: HudState) => void;
  onGameOver: (results: GameResults) => void;
  onEvent: (event: GameEvent) => void;
  onPauseRequest: () => void;
}
