import * as THREE from 'three';

export type OpticalMode = 'standard' | 'lowlight' | 'ir_night';

export type LightingMood = 'flare_night' | 'dawn_mist' | 'blackout';

export interface BodycamSettings {
  opticalMode: OpticalMode;
  lightingMood: LightingMood;
  distortion: number; // 0.0 to 1.0
  grain: number; // 0.0 to 1.0
  aberration: number; // 0.0 to 1.0
  exposure: number; // 0.6 to 2.2
  flashlightOn: boolean;
  audioEnabled: boolean;
  mouseSensitivity: number;
}

export interface ObjectiveDrive {
  id: string;
  label: string;
  zone: string;
  collected: boolean;
  position: THREE.Vector3;
}

export interface GameHudState {
  phase: 'briefing' | 'playing' | 'paused' | 'extracted' | 'down';
  health: number;
  maxHealth: number;
  ammo: number;
  magSize: number;
  reserveAmmo: number;
  isReloading: boolean;
  isAiming: boolean;
  isSprinting: boolean;
  isCrouching: boolean;
  flashlightOn: boolean;
  flashlightBattery: number;
  drivesCollected: number;
  totalDrives: number;
  hostilesNeutralized: number;
  totalHostiles: number;
  extractionReady: boolean;
  nearbyPrompt: string | null;
  currentZone: string;
  hitMarkerTimer: number;
  damageFlashTimer: number;
  elapsedSeconds: number;
  pointerLocked: boolean;
  statusBanner: string | null;
}

export interface BoxCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  minY: number;
  maxY: number;
}
