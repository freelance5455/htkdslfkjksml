export type StatKey = "influence" | "reputation" | "intelligence" | "wealth" | "power";

export interface Stats {
  influence: number;
  reputation: number;
  intelligence: number;
  wealth: number;
  power: number;
}

export type NpcStatKey = "trust" | "respect" | "fear" | "loyalty" | "ambition";

export interface NpcStats {
  trust: number;
  respect: number;
  fear: number;
  loyalty: number;
  ambition: number;
}

export type EffectMap = Partial<Record<StatKey, number>>;

export interface Palette {
  skin: string;
  hair: string;
  cloth: string;
  accent: string;
}

export interface NpcDef {
  id: string;
  name: string;
  title: string;
  role: string;
  areaId: string;
  x: number;
  y: number;
  palette: Palette;
  crown?: boolean;
  hood?: boolean;
  bio: string;
}

export interface Memory {
  id: string;
  text: string;
  kind: "good" | "bad" | "info";
  mission: number;
}

export interface NpcState {
  id: string;
  trust: number;
  respect: number;
  fear: number;
  loyalty: number;
  ambition: number;
  areaId: string;
  x: number;
  y: number;
  alive: boolean;
  memories: Memory[];
}

export interface ItemDef {
  id: string;
  name: string;
  icon: string;
  desc: string;
  kind: "gift" | "tool" | "treasure" | "key" | "clue";
  use?: {
    text: string;
    effects?: EffectMap;
    flag?: string;
    consume?: boolean;
  };
}

export interface ItemState {
  id: string;
  count: number;
}

export interface Requirement {
  stat?: Partial<Record<StatKey, number>>;
  item?: string;
  flag?: string;
  npcTrust?: { id: string; min: number };
}

export interface Choice {
  text: string;
  req?: Requirement;
  outcome: string;
  effects?: EffectMap;
  npc?: { id: string; deltas: Partial<NpcStats> }[];
  give?: { item: string; count: number }[];
  take?: { item: string; count: number }[];
  flags?: string[];
  score?: number;
  next?: string;
  end?: "mission" | "step" | "fail";
  shake?: number;
  tone?: "good" | "bad" | "neutral";
}

export interface DialogueNode {
  id: string;
  speaker: string;
  lines: string[];
  choices: Choice[];
}

export type Step =
  | { kind: "dialogue"; node: string }
  | { kind: "collect"; item: string; count: number; hint: string }
  | { kind: "visit"; areaId: string; hint: string }
  | { kind: "talk"; npc: string; hint: string; areaId?: string };

export interface Mission {
  id: number;
  lawTitle: string;
  lawText: string;
  title: string;
  areaId: string;
  giverNpc: string;
  brief: string;
  steps: Step[];
  nodes: Record<string, DialogueNode>;
  reward: { score: number; effects?: EffectMap; item?: string };
  requires?: Requirement;
  unlockAreas?: string[];
}

export interface WorldItem {
  id: string;
  item: string;
  areaId: string;
  x: number;
  y: number;
}

export interface FloatText {
  id: number;
  text: string;
  color: string;
  x: number;
  y: number;
  life: number;
  maxLife: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  gravity: number;
  glow: boolean;
}

export interface Toast {
  id: number;
  text: string;
  tone: "good" | "bad" | "info" | "gold";
  at: number;
}

export interface LogEntry {
  id: number;
  text: string;
  tone: "good" | "bad" | "info" | "gold";
  mission?: number;
}

export type Ending =
  | "king"
  | "advisor"
  | "shadow"
  | "noble"
  | "ruin"
  | "dynasty";

export interface GameState {
  version: number;
  started: boolean;
  player: {
    x: number;
    y: number;
    areaId: string;
    facing: "up" | "down" | "left" | "right";
    anim: number;
    moving: boolean;
  };
  stats: Stats;
  score: number;
  inventory: ItemState[];
  npcs: Record<string, NpcState>;
  flags: string[];
  memoriesByLaw: Record<string, string[]>;
  currentMission: number | null;
  missionStep: number;
  completedMissions: number[];
  unlockedAreas: string[];
  discoveredAreas: string[];
  knownLaws: number[];
  worldItems: WorldItem[];
  log: LogEntry[];
  toasts: Toast[];
  floaters: FloatText[];
  particles: Particle[];
  gameOver: null | { title: string; reason: string };
  ending: Ending | null;
  endingTitle?: string;
  endingText?: string;
  playerName: string;
  turnCount: number;
  time: number;
}

export const STAT_LABELS: Record<StatKey, string> = {
  influence: "Influência",
  reputation: "Reputação",
  intelligence: "Inteligência",
  wealth: "Riqueza",
  power: "Poder Político",
};

export const STAT_ICONS: Record<StatKey, string> = {
  influence: "✦",
  reputation: "❖",
  intelligence: "✧",
  wealth: "◈",
  power: "♛",
};

export const NPC_STAT_LABELS: Record<NpcStatKey, string> = {
  trust: "Confiança",
  respect: "Respeito",
  fear: "Medo",
  loyalty: "Lealdade",
  ambition: "Ambição",
};
