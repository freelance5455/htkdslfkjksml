export type QualityLevel = "high" | "medium" | "eco";
export type TimeLayer = "present" | "past";
export type Phase = "title" | "reconnect" | "intro" | "playing" | "ending" | "credits";

export type Overlay =
  | "none"
  | "inventory"
  | "journal"
  | "map"
  | "constellation"
  | "combine"
  | "settings"
  | "puzzle"
  | "dialogue"
  | "inspect"
  | "hints"
  | "archives"
  | "admin"
  | "choice"
  | "resonance"
  | "cinematic";

export type ItemCategory =
  | "fragments"
  | "artifacts"
  | "keys"
  | "symbols"
  | "memories"
  | "tools"
  | "documents"
  | "unknown";

export type FragmentFamily =
  | "stellar"
  | "temporal"
  | "sound"
  | "symbolic"
  | "memory"
  | "coordinate"
  | "energy"
  | "mirror";

export type FragmentRarity = "common" | "uncommon" | "rare" | "unique";

export type JournalSection =
  | "quete"
  | "lieux"
  | "personnages"
  | "fragments"
  | "artefacts"
  | "mysteres"
  | "resonances"
  | "constellation"
  | "archives";

export type PuzzleKind =
  | "constellation"
  | "memory"
  | "decrypt"
  | "mist"
  | "ghost"
  | "mirror"
  | "rebuild"
  | "sound"
  | "portal"
  | "final";

export interface FragmentDef {
  id: string;
  name: string;
  symbol: string;
  description: string;
  origin: string;
  category: ItemCategory;
  family: FragmentFamily;
  rarity: FragmentRarity;
  functionApparent: string;
  uses: string[];
  storyImportance: "minor" | "major" | "critical";
  inspectSecret?: { angleMin: number; angleMax: number; text: string };
  optional?: boolean;
}

export interface CombinationDef {
  id: string;
  inputs: string[];
  outputId: string;
  outputName: string;
  outputDescription: string;
  outputCategory: ItemCategory;
  requireFlag?: string;
}

export interface JournalEntryDef {
  id: string;
  section: JournalSection;
  title: string;
  stages: string[];
  requireFlag: string;
}

export interface MissionDef {
  id: string;
  act: number;
  title: string;
  description: string;
  optional?: boolean;
  completeFlag: string;
  unlockFlag?: string;
}

export interface DialogueLine {
  speaker: string;
  text: string;
}

export interface DialogueDef {
  id: string;
  npc: string;
  lines: DialogueLine[];
  choices?: { id: string; label: string; flag: string; reply: string }[];
  setFlag?: string;
  giveItem?: string;
}

export interface ResonanceDef {
  id: string;
  prompt: string;
  placeholder: string;
}

export interface PuzzleDef {
  id: string;
  kind: PuzzleKind;
  chapter: number;
  difficulty: "medium" | "hard" | "very-hard";
  title: string;
  prompt: string;
  acceptedAnswers?: string[];
  hints: [string, string, string];
  requiredFragments?: string[];
  requiredItems?: string[];
  unlockFlag?: string;
  rewardItem?: string;
  rewardFlag: string;
  nextMission?: string;
}

export interface HotspotDef {
  id: string;
  x: number;
  y: number;
  label: string;
  layer?: TimeLayer;
  requireFlag?: string;
  requireItem?: string;
  hideFlag?: string;
  nightOnly?: boolean;
  mistOnly?: boolean;
  action: HotspotAction;
}

export type HotspotAction =
  | { type: "examine"; text: string; flag?: string; journalId?: string; lohen?: string }
  | { type: "pickup"; itemId: string; text: string; flag?: string; lohen?: string }
  | { type: "puzzle"; puzzleId: string }
  | { type: "travel"; to: string }
  | { type: "dialogue"; dialogueId: string }
  | { type: "choice"; prompt: string; options: { id: string; label: string; flag: string; text: string }[] }
  | { type: "portal" }
  | { type: "use"; itemId: string; successText: string; flag: string; consume?: boolean }
  | { type: "resonance"; resonanceId: string }
  | { type: "cinematic"; cinematicId: string }
  | { type: "ghost"; fragmentId: string };

export interface LocationDef {
  id: string;
  name: string;
  act: number;
  region: string;
  ambience:
    | "threshold"
    | "village"
    | "forest"
    | "observatory"
    | "city"
    | "sanctuary"
    | "gates"
    | "fall"
    | "quiet"
    | "constellation"
    | "last";
  blurb: string;
  echoes: string[];
  hotspots: HotspotDef[];
  exits: { to: string; label: string; x: number; y: number; requireFlag?: string; hideFlag?: string }[];
  discoverFlag?: string;
  weather?: "clear" | "fog" | "wind" | "overcast" | "starfall";
}

export interface ConstellationStar {
  id: string;
  name: string;
  x: number;
  y: number;
  unlockFlag: string;
}

export interface InspectItem {
  id: string;
  name: string;
  description: string;
  category: ItemCategory;
  family?: FragmentFamily;
  rarity?: FragmentRarity;
  symbol?: string;
  inspectSecret?: { angleMin: number; angleMax: number; text: string };
}

export interface SaveState {
  version: number;
  phase: Phase;
  act: number;
  locationId: string;
  timeLayer: TimeLayer;
  overlay: Overlay;
  activePuzzle: string | null;
  inspectId: string | null;
  dialogueId: string | null;
  cinematicId: string | null;
  inventory: string[];
  flags: Record<string, boolean>;
  journalStage: Record<string, number>;
  choices: Record<string, string>;
  resonances: Record<string, string>;
  starIntensity: Record<string, number>;
  visits: Record<string, number>;
  hintsUsed: number;
  discovered: string[];
  solved: string[];
  secrets: string[];
  names: { player: string; searched: string };
  settings: {
    quality: QualityLevel;
    qualityLocked: boolean;
    master: number;
    music: number;
    sfx: number;
    textScale: number;
    reduceMotion: boolean;
    vibrate: boolean;
    contrast: boolean;
    hudVisible: boolean;
  };
  introStep: number;
  endingStep: number;
  lastSaveAt: number;
}

export interface AdminConfig {
  names: { player: string; searched: string };
  puzzleAnswers: Record<string, string[]>;
  creditsLine1: string;
  creditsLine2: string;
  musicActOverride: number | null;
}
