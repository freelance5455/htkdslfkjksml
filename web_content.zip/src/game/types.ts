export type GameScreenState =
  | 'TITLE_MENU'
  | 'PLAYING'
  | 'PAUSED'
  | 'GAME_OVER'
  | 'VICTORY';

export type AbilityId =
  | 'phase_dash'
  | 'grapple_tether'
  | 'aero_thruster'
  | 'overdrive_arc';

export type SectorId =
  | 'sunken_conduit'
  | 'maglev_spire'
  | 'relay_skybridge'
  | 'cryo_foundry'
  | 'data_vault'
  | 'black_spire'
  | 'void_foundry'
  | 'cryo_abyss'
  | 'zenith_apex';

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface Platform extends Rect {
  kind: 'solid' | 'oneway' | 'neon_wall' | 'gate';
  sector: SectorId;
  requiredAbility?: AbilityId;
  gateId?: string;
  accent?: 'cyan' | 'magenta' | 'amber' | 'emerald';
}

export interface Hazard extends Rect {
  kind: 'laser' | 'spikes' | 'acid';
  /** Phase dash passes through lasers safely */
  phaseable?: boolean;
  /** Down-slash pogo works on spikes and pogo pads */
  pogoable?: boolean;
}

export interface SpeedRail {
  id: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  color: 'cyan' | 'amber';
}

export interface GrappleNode {
  id: string;
  x: number;
  y: number;
  radius: number;
}

export interface UplinkTerminal {
  id: string;
  sector: SectorId;
  name: string;
  x: number;
  y: number;
}

export interface PickupItem {
  id: string;
  kind: 'ability' | 'shard' | 'integrity_cell' | 'repair_relay';
  abilityId?: AbilityId;
  label: string;
  description: string;
  x: number;
  y: number;
  collected: boolean;
}

export type EnemyKind =
  | 'patrol_bot'
  | 'hover_sentinel'
  | 'pogo_mine'
  | 'sniper_turret'
  | 'dash_stalker'
  | 'plasma_orbiter'
  | 'shield_warden'
  | 'boss_archon'
  | 'boss_vortex'
  | 'boss_glacier'
  | 'boss_nexus';

export interface Enemy {
  id: string;
  kind: EnemyKind;
  sector: SectorId;
  x: number;
  y: number;
  w: number;
  h: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  spawnX: number;
  spawnY: number;
  patrolMinX: number;
  patrolMaxX: number;
  facing: 1 | -1;
  alive: boolean;
  hitFlashTimer: number;
  invulnTimer: number;
  stateTimer: number;
  aiPhase: string;
  telegraphTimer: number;
  targetX?: number;
  targetY?: number;
  phase2?: boolean;
}

export interface Projectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  fromPlayer: boolean;
  damage: number;
  life: number;
  color: string;
  piercing?: boolean;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  life: number;
  maxLife: number;
  color: string;
  gravity: number;
}

export interface Afterimage {
  x: number;
  y: number;
  w: number;
  h: number;
  facing: 1 | -1;
  alpha: number;
  color: string;
}

export interface SlashArc {
  x: number;
  y: number;
  dir: 'left' | 'right' | 'up' | 'down';
  life: number;
  maxLife: number;
  overdrive: boolean;
  flip: boolean;
}

export interface HitSlashEffect {
  x: number;
  y: number;
  angle: number;
  life: number;
  maxLife: number;
  color: string;
}

export interface FloatingCallout {
  x: number;
  y: number;
  vy: number;
  text: string;
  color: string;
  life: number;
  maxLife: number;
}

export interface SectorMeta {
  id: SectorId;
  name: string;
  subtitle: string;
  bounds: Rect;
  color: string;
  /** Normalized map coordinates for the Tactical Map modal */
  mapRect: { x: number; y: number; w: number; h: number };
}

export interface HudSnapshot {
  hp: number;
  maxHp: number;
  flux: number;
  shards: number;
  totalShards: number;
  abilities: AbilityId[];
  currentSector: SectorId;
  currentSectorName: string;
  discoveredSectors: SectorId[];
  speed: number;
  comboCount: number;
  healProgress: number;
  activePrompt: string | null;
  bossActive: boolean;
  activeBossName: string;
  bossHp: number;
  bossMaxHp: number;
  bossPhase2: boolean;
  bossDefeated: boolean;
  defeatedBosses: string[];
  playerX: number;
  playerY: number;
  elapsedSeconds: number;
  bannerTitle: string | null;
  bannerSubtitle: string | null;
  muted: boolean;
}
