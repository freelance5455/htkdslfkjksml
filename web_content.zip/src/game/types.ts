export type Phase = "garage" | "countdown" | "race" | "paused" | "finish";

export type RacerResult = {
  name: string;
  player: boolean;
  place: number;
  time: number | null;
};

export type PhasePayload = {
  results?: RacerResult[];
  bestLap: number;
  bestRace: number;
};

export type SaveData = {
  skin: string;
  auto: boolean;
  mute: boolean;
  bestLap: number;
  bestRace: number;
};

export type HudBind = {
  speed: HTMLElement;
  lap: HTMLElement;
  pos: HTMLElement;
  lapTime: HTMLElement;
  raceTime: HTMLElement;
  best: HTMLElement;
  drift: HTMLElement;
  wrong: HTMLElement;
  flash: HTMLElement;
  count: HTMLElement;
  countWrap: HTMLElement;
  boost: HTMLElement;
};

export type GameOptions = {
  view: HTMLCanvasElement;
  map: HTMLCanvasElement;
  hudRoot: HTMLElement;
  save: SaveData;
  onPhase: (phase: Phase, payload: PhasePayload) => void;
};

export type GameHandle = {
  start: () => void;
  pause: () => void;
  resume: () => void;
  toGarage: () => void;
  setSkin: (id: string) => void;
  setPad: (v: number | null) => void;
  setHold: (key: "gas" | "brake" | "drift", v: boolean) => void;
  setAuto: (v: boolean) => void;
  setMute: (v: boolean) => void;
  cycleCam: () => void;
  rescue: () => void;
  unlock: () => void;
  dispose: () => void;
};

export type ControlsProbe = {
  getYaw: () => number;
  getSpeed: () => number;
  setKeys: (codes: string[]) => void;
};

declare global {
  interface Window {
    __controlsTest?: ControlsProbe;
  }
}
