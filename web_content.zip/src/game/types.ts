export type BodyKind =
  | "spiral"
  | "barred"
  | "elliptical"
  | "irregular"
  | "edgeOn"
  | "edgeOnBurst"
  | "ring"
  | "interact"
  | "cluster"
  | "blackhole";

export type MorphologyProfile = {
  dust: number
  starburst: number
  asymmetry: number
  clumpy: number
  ring: number
  tails: number
  companions: number
  jet: number
  edgeOn?: number
};

export type Celestial = {
  id: number
  name: string
  kind: BodyKind
  colorA: number
  colorB: number
  radius: number
  arms: number
  spin: number
  bulge: number
  thick: number
  info: string
  pos: [number, number, number]
  morphology: MorphologyProfile
  recipeId?: number
  seed?: number
};

export type MissionKind =
  | "scan"
  | "dive"
  | "bh"
  | "discover"
  | "samples"
  | "warp"
  | "discover12"
  | "all";

export type MissionDef = {
  id: string
  title: string
  text: string
  xp: number
  goal: number
  kind: MissionKind
};

export type Marker = {
  id: number
  name: string
  kind: BodyKind
  x: number
  y: number
  discovered: boolean
  dist: number
  offscreen: boolean
};

export type HudState = {
  fps: number
  speed: number
  hull: number
  boost: number
  credits: number
  xp: number
  rank: string
  xpInto: number
  xpSpan: number
  discovered: number
  total: number
  samples: number
  missionTitle: string
  missionText: string
  missionProgress: number
  missionGoal: number
  nearestName: string
  nearestDist: number
  nearestKind: string
  canScan: boolean
  scanning: boolean
  targetId: number | null
  targetName: string
  warping: boolean
  markers: Marker[]
  toastTitle: string
  toastText: string
  toastOn: boolean
  phase: "attract" | "play" | "pause" | "complete"
  muted: boolean
  dimension: number
  wSlice: number
  vPhase: number
};

export type TouchState = {
  throttle: number
  steer: number
  pitch: number
  boost: boolean
  scan: boolean
};

export type ControlsProbe = {
  getYaw: () => number
  getSpeed: () => number
  setSteer?: (v: number) => void
  setKeys?: (codes: string[]) => void
};

declare global {
  interface Window {
    __controlsTest?: ControlsProbe
  }
}

export {};
