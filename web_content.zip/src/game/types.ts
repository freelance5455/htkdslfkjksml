export type GameStatus = 'TITLE' | 'PLAYING' | 'PAUSED' | 'GAME_OVER';

export type Direction = 'LEFT' | 'RIGHT' | 'UP' | 'DOWN';

export type MapTheme = 'RAILWAY' | 'TWELVE_CITY';

export type DeathReason = 'TRAIN' | 'LEHAU' | null;

export const TOTAL_COLS = 7;
export const TRACK_COLS = [1, 2, 4, 5] as const;
export const SAFE_COLS = [0, 3, 6] as const;
export const TILE_PX = 24; // Logical pixel size per grid tile
export const CLOVER_HOLD_SECONDS = 3.0;
export const MAP_SWITCH_INTERVAL = 15.0;

export interface PlayerState {
  col: number;
  row: number;
  fromCol: number;
  fromRow: number;
  visualCol: number;
  visualRow: number;
  isMoving: boolean;
  moveTimer: number;
  moveDuration: number;
  facing: Direction;
  squashX: number;
  squashY: number;
  hopZ: number;
  collectPose: boolean;
  knockedOut: boolean;
  knockoutTimer: number;
  knockoutVx: number;
  knockoutVy: number;
  hatOffsetY: number;
}

export interface Clover {
  id: number;
  col: number;
  row: number;
  kind: 'normal' | 'golden';
  age: number;
  maxAge: number;
  collectProgress: number; // 0 to CLOVER_HOLD_SECONDS
  lastTickStep: number;
  swayOffset: number;
}

export type TrainStyle =
  | 'yamanote'
  | 'chuo'
  | 'shinkansen'
  | 'dryellow'
  | 'city_tram'
  | 'twelve_bus'
  | 'metro_12';

export interface Train {
  id: number;
  col: number;
  direction: 1 | -1; // -1 = moving down (from top), +1 = moving up (from bottom)
  rowPos: number;
  lengthRows: number;
  speedRowsPerSec: number;
  style: TrainStyle;
  phase: 'WARNING' | 'ACTIVE';
  warningTimer: number;
  warningDuration: number;
  passedPlayerRow: boolean;
  whooshed: boolean;
}

export interface RainbowNpc {
  id: number;
  col: 0 | 3 | 6;
  rowPos: number;
  direction: 1 | -1; // +1 = running up, -1 = running down
  speedRowsPerSec: number;
  minRowOffset: number;
  maxRowOffset: number;
  anchorRow: number;
  animPhase: number;
  turnPauseTimer: number;
}

export interface Particle {
  active: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  gravity: number;
}

export interface FloatingText {
  id: number;
  worldCol: number;
  worldRow: number;
  text: string;
  color: string;
  life: number;
  maxLife: number;
}

export interface HudSnapshot {
  status: GameStatus;
  score: number;
  bestScore: number;
  clovers: number;
  streak: number;
  elapsedSeconds: number;
  isNewRecord: boolean;
  difficultyLevel: number;
  mapTheme: MapTheme;
  mapTimeRemaining: number;
  deathReason: DeathReason;
}
