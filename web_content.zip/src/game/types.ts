export type Ing = "bread" | "meat" | "veg" | "cheese" | "sauce";

export type Phase = "menu" | "playing" | "paused" | "win" | "lose";

export type StationId = "bread" | "grill" | "chop" | "oven" | "sauce" | "trash" | "serve";

export type CookId = "grill" | "chop" | "oven";

export type CookChip = {
  id: CookId;
  label: string;
  p: number;
  ready: boolean;
};

export type ToastTone = "good" | "bad" | "info";

export type HudSnap = {
  phase: Phase;
  day: number;
  money: number;
  goal: number;
  timeLeft: number;
  customerName: string;
  recipeName: string;
  price: number;
  order: Ing[];
  patience: number;
  plate: Ing[];
  verb: string;
  detail: string;
  canAct: boolean;
  toast: string;
  toastTone: ToastTone;
  cook: CookChip[];
  bestDay: number;
  bestMoney: number;
  muted: boolean;
  customerHere: boolean;
  hints: boolean;
  booted: boolean;
};
