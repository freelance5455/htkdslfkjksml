export type Phase = "load" | "lobby" | "play";

export type ModeId = "freeroam" | "story" | "heist" | "race" | "heat" | "turf";

export type CarKind = "sedan" | "sport" | "suv" | "taxi" | "cop" | "van" | "truck" | "bike";

export type WeaponId = "fists" | "pistol" | "jade" | "shotgun" | "rifle" | "sniper";

export type Step =
  | { kind: "goto"; at: string; r: number; text: string }
  | { kind: "hold"; at: string; r: number; time: number; text: string }
  | { kind: "survive"; stars: number; time: number; text: string }
  | { kind: "race"; points: { x: number; z: number }[]; laps: number; text: string }
  | { kind: "eliminate"; count: number; text: string };

export type MissionDef = {
  id: string;
  name: string;
  chapter: "Story" | "Side" | "Heist" | "Race" | "Heat" | "Turf";
  blurb: string;
  reward: number;
  xp: number;
  difficulty: 1 | 2 | 3 | 4 | 5;
  unlockAfter?: string;
  rewardWeapon?: WeaponId;
  steps: Step[];
};

export type Note = { id: number; text: string };

export type HudState = {
  phase: Phase;
  load: number;
  tip: string;
  name: string;
  rank: number;
  money: number;
  gems: number;
  health: number;
  armor: number;
  stars: number;
  weapon: WeaponId;
  weaponName: string;
  mag: number;
  reserve: number;
  grenades: number;
  inCar: boolean;
  carName: string;
  speed: number;
  district: string;
  clock: string;
  radio: string;
  radioOn: boolean;
  outfit: string;
  ownedWeapons: WeaponId[];
  ownedCars: string[];
  ownedProps: string[];
  carColor: string;
  missionsDone: string[];
  xp: number;
  passClaimed: number;
  missionName: string;
  objective: string;
  hold: number;
  notes: Note[];
  hint: string;
  interact: string;
  paused: boolean;
  phone: boolean;
  down: "" | "wasted" | "busted";
  pain: number;
  mode: ModeId;
  volume: number;
  muted: boolean;
  crouch: boolean;
  raceLap: string;
  bestRace: number | null;
  vaultReady: boolean;
  ownedOutfits: string[];
};
