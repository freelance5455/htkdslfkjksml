export type WeatherCondition = 'sol' | 'chuva' | 'neblina';

export type DayTimePhase = 'amanhecer' | 'dia' | 'entardecer' | 'noite';

export type BikeModelType = 'cg_titan_160' | 'cg_fan_160' | 'bros_160';
export type SensitivityPreset = 'normal' | 'alta';

export interface GameSettings {
  sensitivityPreset: SensitivityPreset;
  steeringSensitivity: number;
  wheelieSensitivity: number;
}

export type TireType = 'urbano' | 'slick' | 'misto';
export type ExhaustType = 'original' | 'dore' | 'trioval' | 'direto';
export type HandlebarType = 'original' | 'esportivo' | 'oxxy';
export type TailBarType = 'original' | 'alca_grau';

export interface BikeCustomization {
  bikeModel: BikeModelType;
  colorId: string;
  tire: TireType;
  exhaust: ExhaustType;
  handlebar: HandlebarType;
  tailBar: TailBarType;
  motorLevel: number; // 1..3 (affects torque/accel, top speed always capped at 140 km/h)
  gearRatioLevel: number; // 1..3 (wheelie punch & acceleration)
  brakeLevel: number; // 1..3 (braking & rear brake wheelie modulation)
  suspensionLevel: number; // 1..3 (hill/bump stability & landing)
}

export interface PaintColorOption {
  id: string;
  name: string;
  hex: string;
  accentHex: string;
  price: number;
}

export const PAINT_COLORS: PaintColorOption[] = [
  { id: 'vermelho_rally', name: 'Vermelho Rally 160', hex: '#d11924', accentHex: '#f5f5f5', price: 0 },
  { id: 'preto_fosco', name: 'Preto Ninja', hex: '#1a1c20', accentHex: '#ef4444', price: 250 },
  { id: 'azul_twister', name: 'Azul Metálico', hex: '#1456d4', accentHex: '#e2e8f0', price: 350 },
  { id: 'branco_perola', name: 'Branco Pérola', hex: '#eceef2', accentHex: '#18181b', price: 350 },
  { id: 'amarelo_ouro', name: 'Amarelo Dourado', hex: '#eab308', accentHex: '#18181b', price: 450 },
  { id: 'verde_floresta', name: 'Verde Esmeralda', hex: '#15803d', accentHex: '#facc15', price: 500 },
  { id: 'laranja_grau', name: 'Laranja Street', hex: '#ea580c', accentHex: '#18181b', price: 600 },
  { id: 'roxo_camaleao', name: 'Roxo Noturno', hex: '#6d28d9', accentHex: '#38bdf8', price: 850 },
];

export interface ControlInputs {
  throttle: boolean;
  brake: boolean;
  wheelie: boolean;
  left: boolean;
  right: boolean;
}

export interface WorldZoneInfo {
  name: string;
  subtitle: string;
}

export type MissionType = 'entrega' | 'tempo' | 'grau' | 'racha' | 'policia';

export interface MissionCheckpoint {
  x: number;
  z: number;
  label: string;
}

export interface MissionDefinition {
  id: string;
  type: MissionType;
  title: string;
  description: string;
  rewardMoney: number;
  rewardXp: number;
  timeLimitSec?: number;
  targetWheelieDistM?: number;
  targetWheelieTimeSec?: number;
  checkpoints?: MissionCheckpoint[];
  policeDurationSec?: number;
  racerStart?: { x: number; z: number; heading: number };
}

export interface ActiveMissionState {
  def: MissionDefinition;
  startedAt: number;
  elapsedSec: number;
  currentCheckpointIndex: number;
  wheelieDistanceM: number;
  wheelieHoldSec: number;
  policeCaughtTimer: number;
  racerProgress: number;
  racerFinished: boolean;
  status: 'active' | 'completed' | 'failed';
  failReason?: string;
}

export interface RemoteMapMarker {
  id: string;
  name: string;
  x: number;
  z: number;
}

export interface FriendInfo {
  id: string;
  name: string;
  bikeModel: BikeModelType;
  online: boolean;
  roomId: string | null;
}

export interface RoomMemberInfo {
  playerId: string;
  name: string;
  bikeModel: BikeModelType;
}

export interface RoomInfo {
  roomId: string;
  hostId: string;
  players: RoomMemberInfo[];
}

export interface RemotePlayerState {
  playerId: string;
  name: string;
  x: number;
  y: number;
  z: number;
  heading: number;
  wheelieRad: number;
  leanAngle: number;
  steerAngle: number;
  speedMs: number;
  isOnFoot: boolean;
  playerX: number;
  playerY: number;
  playerZ: number;
  playerHeading: number;
  playerSpeed: number;
  engineOn: boolean;
  braking: boolean;
  customization: BikeCustomization;
  updatedAt: number;
}

export interface GameTelemetry {
  x: number;
  y: number;
  z: number;
  heading: number;
  speedKmh: number;
  rpm: number;
  gear: number; // 0 = N, 1..5
  engineOn: boolean;
  cranking: boolean;
  wheelieDeg: number;
  leanDeg: number;
  isWheelieing: boolean;
  isScraping: boolean;
  crashed: boolean;
  currentGrauScore: number;
  bestGrauScore: number;
  totalGrauDistM: number;
  zone: string;
  weather: WeatherCondition;
  timeOfDay: number; // 0..1 (0.25 = dawn, 0.5 = noon, 0.75 = sunset, 0/1 = midnight)
  timePhase: DayTimePhase;
  clockLabel: string;
  gripFactor: number;
  cameraMode: 'chase' | 'hood' | 'far';
  isOnFoot: boolean;
  nearMoto: boolean;
  nearHouseDoor: boolean;
  houseDoorOpen: boolean;
  insideHouse: boolean;
  activeMission: ActiveMissionState | null;
  missionTargetPos: { x: number; z: number } | null;
  enemyPositions: Array<{ x: number; z: number; kind: 'police' | 'racer' }>;
  remotePlayers: RemoteMapMarker[];
}

export interface PlayerProgress {
  money: number;
  xp: number;
  level: number;
  completedMissions: string[];
  ownedModels: BikeModelType[];
  ownedColors: string[];
  ownedTires: TireType[];
  ownedExhausts: ExhaustType[];
  ownedHandlebars: HandlebarType[];
  ownedTailBars: TailBarType[];
  customization: BikeCustomization;
}
