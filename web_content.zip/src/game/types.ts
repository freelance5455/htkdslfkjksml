/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Direction = 'UP' | 'RIGHT' | 'DOWN' | 'LEFT';

export interface Point {
  x: number;
  y: number;
}

export type DifficultyTier =
  | 'Easy'
  | 'Normal'
  | 'Medium'
  | 'Hard'
  | 'Very Hard'
  | 'Expert'
  | 'Master'
  | 'Insane'
  | 'Ultimate'
  | 'Custom'
  | 'Endless';

export interface ArrowConfig {
  id: string;
  x: number; // Head X in grid coordinates
  y: number; // Head Y in grid coordinates
  dir: Direction;
  path?: Point[]; // Connected orthogonal grid cells from tail [0] to head [last]
  length?: number; // Legacy optional multiplier
}

export interface ArrowEntity {
  id: string;
  x: number;
  y: number;
  dir: Direction;
  path: Point[]; // Normalized non-empty grid path from tail to head
  length: number;
  state: 'idle' | 'flying' | 'blocked' | 'escaped';
  slideDistance: number; // Distance slid along path in grid units during escape
  slideSpeed: number; // Current escape speed in grid units/sec
  shakeTime: number; // remaining shake ms
  isHinted: boolean;
  alpha: number;
}

export interface LevelData {
  id: string | number;
  levelNumber: number;
  title: string;
  difficulty: DifficultyTier;
  gridWidth: number;
  gridHeight: number;
  arrows: ArrowConfig[];
  boundaryPath?: Point[]; // Polygon points in grid coordinates retaining drawn outline
  isCustomDrawn?: boolean; // True for user-drawn custom levels to render outline
  shapeType?:
    | 'freehand'
    | 'circle'
    | 'square'
    | 'triangle'
    | 'star'
    | 'heart'
    | 'leaf'
    | 'diamond'
    | 'fortress'
    | 'cloud'
    | 'crescent'
    | 'shield'
    | 'hourglass'
    | 'crown';
}

export interface CustomLevel extends LevelData {
  createdAt: number;
  stars: number;
}

export interface LevelProgress {
  stars: number;
  mistakes: number;
  completedAt: number;
}

export interface GameSettings {
  sound: boolean;
  soundVolume: number; // 0 - 100
  music: boolean;
  musicVolume: number; // 0 - 100
  haptics: boolean;
  showGrid: boolean;
}

export interface SaveData {
  currentLevel: number;
  completedLevels: Record<string, LevelProgress>;
  coins: number;
  hearts: number;
  customLevels: CustomLevel[];
  settings: GameSettings;
  editorUnlocked: boolean;
}

export interface PuzzleComplexityMetrics {
  solvable: boolean;
  arrowCount: number;
  totalCells: number;
  avgPathLength: number;
  totalTurns: number;
  avgTurnsPerArrow: number;
  blockedInitially: number;
  blockedRatio: number;
  dependencyEdges: number;
  waveDepth: number;
  complexityScore: number;
  solution: string[];
}

export type ScreenState =
  | 'HOME'
  | 'PLAYING'
  | 'LEVEL_SELECT'
  | 'DRAWING'
  | 'MY_LEVELS'
  | 'SETTINGS';
