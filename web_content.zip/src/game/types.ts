export type ProtagonistId = 'michael' | 'franklin' | 'trevor';

export type QualityTier = 'pc-high' | 'mobile-balanced' | 'mobile-eco';

export type AtlasTileId =
  | 'asphalt_road'
  | 'road_lane_yellow'
  | 'road_crosswalk'
  | 'sidewalk_concrete'
  | 'skyscraper_glass'
  | 'skyscraper_stone'
  | 'mansion_stucco'
  | 'storefront_luxury'
  | 'desert_sand'
  | 'airfield_runway'
  | 'cargo_steel'
  | 'water_tile'
  | 'grass_park'
  | 'foliage_palm'
  | 'brick_southside'
  | 'metal_trim';

export interface ProtagonistProfile {
  id: ProtagonistId;
  name: string;
  nickname: string;
  role: string;
  district: string;
  accentColor: string;
  suitColor: number;
  shirtColor: number;
  skinColor: number;
  hairColor: number;
  specialName: string;
  specialDesc: string;
  vehicleLabel: string;
  vehicleColor: number;
  unlockRequirement: string;
  spawnPos: [number, number, number];
}

export const PROTAGONISTS: Record<ProtagonistId, ProtagonistProfile> = {
  michael: {
    id: 'michael',
    name: 'Michael De Santa',
    nickname: 'M',
    role: 'Retired Bank Robber',
    district: 'Rockford Hills',
    accentColor: '#38bdf8',
    suitColor: 0x1e293b,
    shirtColor: 0xf8fafc,
    skinColor: 0xd9a882,
    hairColor: 0x4b4642,
    specialName: 'Bullet Time',
    specialDesc: 'Slows combat time & sharpens gun accuracy for 7s.',
    vehicleLabel: 'Obey Tailgater',
    vehicleColor: 0x141820,
    unlockRequirement: 'Complete Mission 2: Complications',
    spawnPos: [-110, 0, -105],
  },
  franklin: {
    id: 'franklin',
    name: 'Franklin Clinton',
    nickname: 'F',
    role: 'Repo Driver & Wheelman',
    district: 'Strawberry · South LS',
    accentColor: '#22c55e',
    suitColor: 0x15803d,
    shirtColor: 0x111827,
    skinColor: 0x7c4921,
    hairColor: 0x141414,
    specialName: 'Driving Focus',
    specialDesc: 'Razor-sharp handling, nitro acceleration & drift grip for 7s.',
    vehicleLabel: 'Bravado Buffalo S',
    vehicleColor: 0xf8fafc,
    unlockRequirement: 'Unlocked from start',
    spawnPos: [-35, 0, 95],
  },
  trevor: {
    id: 'trevor',
    name: 'Trevor Philips',
    nickname: 'T',
    role: 'Smuggler & Desert Pilot',
    district: 'Sandy Shores · Blaine County',
    accentColor: '#f97316',
    suitColor: 0x991b1b,
    shirtColor: 0xe7e5e4,
    skinColor: 0xe0b38d,
    hairColor: 0x574233,
    specialName: 'Red Mist Rage',
    specialDesc: '2x weapon damage & 70% incoming damage reduction for 7s.',
    vehicleLabel: 'Canis Bodhi 4x4',
    vehicleColor: 0x991b1b,
    unlockRequirement: 'Complete Mission 3: The Jewel Store Job',
    spawnPos: [130, 0, -135],
  },
};

export interface MissionStage {
  id: string;
  instruction: string;
  type: 'goto' | 'steal_vehicle' | 'collect_loot' | 'eliminate' | 'escape_wanted';
  targetPos: [number, number, number];
  radius: number;
  countTarget?: number;
  triggerWanted?: number;
  dialogueSpeaker?: string;
  dialogueLine?: string;
}

export interface MissionDef {
  id: string;
  number: number;
  title: string;
  act: string;
  protagonist: ProtagonistId;
  requiredMissionId?: string;
  unlocksCharacter?: ProtagonistId;
  rewardCash: number;
  isSnowFlashback?: boolean;
  summary: string;
  startPos: [number, number, number];
  stages: MissionStage[];
}

export interface RadarBlip {
  x: number;
  z: number;
  kind: 'mission' | 'police' | 'vehicle' | 'loot' | 'ally';
  color: string;
}

export interface AtlasMetrics {
  atlasResolution: number;
  tileCount: number;
  tileSizePx: number;
  gutterPx: number;
  drawCalls: number;
  triangles: number;
  geometries: number;
  textures: number;
  fps: number;
  qualityTier: QualityTier;
  pixelRatio: number;
  isSoftwareGl: boolean;
}

export interface HudSnapshot {
  protagonist: ProtagonistId;
  unlocked: ProtagonistId[];
  cash: Record<ProtagonistId, number>;
  health: number;
  armor: number;
  specialCharge: number;
  specialActive: boolean;
  wantedLevel: number;
  wantedCooldown: number;
  inVehicle: boolean;
  vehicleName: string;
  speedKmh: number;
  canEnterVehicle: boolean;
  nearVehicleName: string;
  ammo: number;
  districtName: string;
  activeMissionId: string | null;
  activeStageIndex: number;
  missionObjective: string;
  missionProgressText: string;
  completedMissions: string[];
  newlyUnlockedCharacter: ProtagonistId | null;
  dialogue: {speaker: string; text: string; color: string} | null;
  banner: {title: string; subtitle: string; reward?: string} | null;
  cameraMode: 'chase' | 'hood' | 'cinematic';
  playerX: number;
  playerZ: number;
  playerHeading: number;
  radarBlips: RadarBlip[];
  atlasMetrics: AtlasMetrics;
  wasted: boolean;
}

export interface PortableSaveData {
  version: number;
  savedAt: string;
  protagonist: ProtagonistId;
  unlocked: ProtagonistId[];
  cash: Record<ProtagonistId, number>;
  completedMissions: string[];
  qualityTier: QualityTier;
}

export interface TouchInputState {
  moveX: number;
  moveY: number;
  sprint: boolean;
  attack: boolean;
  gas: boolean;
  brake: boolean;
  handbrake: boolean;
  cameraDeltaX: number;
  cameraDeltaY: number;
}

export function getDistrictAt(x: number, z: number): string {
  if (x > 60 && z < -45) return 'Sandy Shores · Blaine County';
  if (x < -55 && z < -45) return 'Rockford Hills · Vinewood';
  if (x > 55 && z > 60) return 'Port of Los Santos · Docks';
  if (x < -75 && z > 20) return 'Vespucci Beach';
  if (z > 65) return 'Strawberry · South Los Santos';
  return 'Pillbox Hill · Downtown LS';
}
