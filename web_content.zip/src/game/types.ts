export type WeaponType = 'ar' | 'shotgun' | 'sniper' | 'pistol';

export interface WeaponDef {
  id: WeaponType;
  name: string;
  category: string;
  damage: number;
  fireRate: number; // shots per second
  magazineSize: number;
  reloadTime: number; // seconds
  range: number;
  bulletSpeed: number;
  spread: number;
  zoomFov: number; // FOV when ADS
  recoil: number;
  color: string;
}

export interface InventoryWeapon {
  id: WeaponType;
  currentAmmo: number;
  reserveAmmo: number;
}

export type LootType = 'weapon_ar' | 'weapon_shotgun' | 'weapon_sniper' | 'medkit' | 'gloowall' | 'ammo_ar' | 'ammo_sg' | 'ammo_sniper' | 'vest' | 'mushroom';

export interface LootItem {
  id: string;
  type: LootType;
  x: number;
  y: number;
  z: number;
  name: string;
  amount: number;
  mesh?: any;
}

export interface GlooWallInstance {
  id: string;
  x: number;
  y: number;
  z: number;
  rotationY: number;
  health: number;
  maxHealth: number;
  mesh: any;
  createdAt: number;
}

export interface BotEntity {
  id: string;
  name: string;
  x: number;
  y: number;
  z: number;
  rotationY: number;
  health: number;
  maxHealth: number;
  weapon: WeaponType;
  isDead: boolean;
  targetX: number;
  targetZ: number;
  state: 'roam' | 'loot' | 'attack' | 'flee_zone';
  attackCooldown: number;
  reactionTimer: number;
  mesh: any;
  animTime: number;
  isMoving: boolean;
  velocity: { x: number; y: number; z: number };
}

export interface SafeZone {
  currentCenterX: number;
  currentCenterZ: number;
  currentRadius: number;
  targetCenterX: number;
  targetCenterZ: number;
  targetRadius: number;
  shrinkTimer: number;
  shrinkDuration: number;
  isShrinking: boolean;
  phase: number;
  totalPhases: number;
  damagePerSec: number;
}

export interface KillFeedEntry {
  id: string;
  killer: string;
  victim: string;
  weapon: string;
  isHeadshot: boolean;
  isPlayerKiller: boolean;
  isPlayerVictim: boolean;
  timestamp: number;
}

export interface GameStats {
  kills: number;
  damageDealt: number;
  survivalTime: number;
  headshots: number;
  shotsFired: number;
  shotsHit: number;
  gloowallsPlaced: number;
  rank: number;
  totalPlayers: number;
  isVictory: boolean;
}
