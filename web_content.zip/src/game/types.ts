export type GraphicsPreset = 'low' | 'medium' | 'high';
export type QualityLevel = 'low' | 'medium' | 'high';
export type CameraMode = 'third' | 'first';

export type BiomeId =
  | 'emerald_forest'
  | 'mystic_woods'
  | 'snow_peaks'
  | 'sunlit_coast'
  | 'arcane_glade'
  | 'volcanic_ridge'
  | 'desert_dunes'
  | 'misty_marsh';

export type WeatherKind = 'clear' | 'mist' | 'rain' | 'storm' | 'snow';

export interface AudioSettings {
  masterVolume: number;
  musicVolume: number;
  sfxVolume: number;
  ambientVolume: number;
  monsterVolume: number;
  muted: boolean;
}

export interface GraphicsSettings {
  preset: GraphicsPreset;
  textureQuality: QualityLevel;
  shadowQuality: 'off' | 'low' | 'medium' | 'high';
  drawDistance: number;
  viewDistanceMeters: number;
  effectsQuality: QualityLevel;
  foliageDensity: number;
  renderScale: number;
  maxFps: 30 | 60;
}

export type Rarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
export type ItemCategory = 'weapon' | 'armor' | 'consumable' | 'material';
export type EquipSlot =
  | 'mainHand'
  | 'offHand'
  | 'helmet'
  | 'chest'
  | 'gloves'
  | 'boots'
  | 'accessory';

export type ItemIconKind =
  | 'sword'
  | 'axe'
  | 'bow'
  | 'staff'
  | 'shield'
  | 'helmet'
  | 'armor'
  | 'gloves'
  | 'boots'
  | 'ring'
  | 'potion_hp'
  | 'potion_mp'
  | 'food'
  | 'water'
  | 'wood'
  | 'stone'
  | 'ore'
  | 'crystal'
  | 'rune'
  | 'bone'
  | 'skull';

export interface ItemStats {
  attack?: number;
  defense?: number;
  magic?: number;
  maxHp?: number;
  maxMana?: number;
  speedBonus?: number;
}

export interface ConsumableEffect {
  hp?: number;
  mana?: number;
  stamina?: number;
  hunger?: number;
  thirst?: number;
  energy?: number;
  tempDelta?: number;
}

export interface ItemDefinition {
  id: string;
  nameAr: string;
  descriptionAr: string;
  category: ItemCategory;
  rarity: Rarity;
  icon: ItemIconKind;
  tintHex: string;
  equipSlot?: EquipSlot;
  stats?: ItemStats;
  consumable?: ConsumableEffect;
  stackable: boolean;
  valueGold: number;
}

export interface InventoryEntry {
  itemId: string;
  quantity: number;
}

export type EquipmentState = Record<EquipSlot, string | null>;

export interface SurvivalStats {
  hunger: number;
  thirst: number;
  temperature: number;
  rest: number;
}

export type ElementId =
  | 'fire'
  | 'water'
  | 'ice'
  | 'lightning'
  | 'wind'
  | 'earth'
  | 'dark'
  | 'light'
  | 'nature'
  | 'poison'
  | 'metal'
  | 'sound'
  | 'gravity'
  | 'time'
  | 'soul'
  | 'blood'
  | 'moon'
  | 'sun'
  | 'void'
  | 'crystal'
  | 'astral'
  | 'chaos'
  | 'life'
  | 'death'
  | 'dream'
  | 'aether';

export type AbilityKind = 'attack' | 'heavy' | 'defense' | 'control' | 'ultimate';

export interface ElementAbilityDef {
  id: string;
  nameAr: string;
  kind: AbilityKind;
  descriptionAr: string;
  manaCost: number;
  cooldownSec: number;
  power: number;
  unlockMastery: number;
}

export interface ElementSkillNode {
  id: string;
  nameAr: string;
  descriptionAr: string;
  costShards: number;
  minMastery: number;
  powerBonusPct?: number;
  manaSavePct?: number;
  cdReductionPct?: number;
  radiusBonusPct?: number;
}

export interface ElementDefinition {
  id: ElementId;
  nameAr: string;
  colorHex: string;
  accentHex: number;
  strongAgainst: ElementId[];
  weakAgainst: ElementId[];
  unlockCostShards: number;
  abilities: [
    ElementAbilityDef,
    ElementAbilityDef,
    ElementAbilityDef,
    ElementAbilityDef,
    ElementAbilityDef,
  ];
}

export interface ElementProgress {
  unlocked: boolean;
  masteryLevel: number;
  xp: number;
  skillNodes?: Record<string, boolean>;
}

export interface FusionDefinition {
  id: string;
  nameAr: string;
  descriptionAr: string;
  elements: [ElementId, ElementId];
  colorHex: string;
  accentHex: number;
  manaCost: number;
  cooldownSec: number;
  power: number;
  minMastery: number;
  isSecret?: boolean;
}

export interface ComputedPlayerStats {
  attack: number;
  defense: number;
  magic: number;
  maxHp: number;
  maxMana: number;
  maxStamina: number;
  speedMultiplier: number;
}

export type EntityCategory = 'creature' | 'monster' | 'boss';
export type EntityRank = 'common' | 'rare' | 'elite' | 'legendary' | 'boss';
export type EntityArchetype =
  | 'quadruped'
  | 'humanoid'
  | 'skeleton'
  | 'golem'
  | 'winged'
  | 'dragon'
  | 'serpent'
  | 'wisp'
  | 'slime';

export type EntityModelStyle =
  | 'deer'
  | 'stag'
  | 'rabbit'
  | 'fox'
  | 'wolf'
  | 'panther'
  | 'boar'
  | 'sheep'
  | 'goat'
  | 'otter'
  | 'tortoise'
  | 'crab'
  | 'scorpion'
  | 'spider'
  | 'beetle'
  | 'frog'
  | 'hawk'
  | 'owl'
  | 'moth'
  | 'bat'
  | 'gargoyle'
  | 'harpy'
  | 'thunderbird'
  | 'serpent'
  | 'wyrm'
  | 'salamander'
  | 'shark'
  | 'jellyfish'
  | 'golem'
  | 'treant'
  | 'titan'
  | 'crystal_golem'
  | 'wisp'
  | 'reaper'
  | 'djinn'
  | 'slime'
  | 'warrior'
  | 'mage'
  | 'knight'
  | 'mummy'
  | 'skeleton'
  | 'dragon'
  | 'bone_dragon'
  | 'void_stalker';

export type SkeletonVariant =
  | 'warrior'
  | 'archer'
  | 'mage'
  | 'armored'
  | 'giant'
  | 'swift'
  | 'guard'
  | 'rare'
  | 'commander';

export type EntityTemperament = 'peaceful' | 'neutral' | 'aggressive' | 'ranged';

export interface EntityTemplateDef {
  id: string;
  nameAr: string;
  category: EntityCategory;
  rank?: EntityRank;
  archetype: EntityArchetype;
  modelStyle?: EntityModelStyle;
  skeletonVariant?: SkeletonVariant;
  temperament: EntityTemperament;
  biomeIds: BiomeId[];
  level: number;
  maxHp: number;
  attack: number;
  speed: number;
  scale: number;
  primaryHex: number;
  secondaryHex: number;
  glowHex: number;
  weakness: ElementId;
  resistance?: ElementId;
  drops: Array<{ itemId: string; chance: number; qty: number }>;
  xpReward: number;
  goldReward: number;
  shardReward: number;
  summonManaCost: number;
  soulPower?: number;
  summonDurationSec?: number;
  summonCooldownSec?: number;
  summonRole?: 'tank' | 'dps' | 'ranged' | 'support';
  evolvesTo?: string;
  evolveBiome?: BiomeId;
  abilities?: string[];
  isAquatic?: boolean;
  isAerial?: boolean;
  isSubterranean?: boolean;
  descriptionAr: string;
}

export interface OverheadNameplate {
  uid: string;
  nameAr: string;
  level: number;
  rank: EntityRank;
  category: EntityCategory;
  hp: number;
  displayHp: number;
  trailHp: number;
  maxHp: number;
  phase?: 1 | 2;
  isSummon: boolean;
  isRebel?: boolean;
  isTargeted: boolean;
  screenX: number;
  screenY: number;
  scale: number;
  opacity: number;
}

export type NpcRole = 'villager' | 'merchant' | 'blacksmith' | 'healer' | 'quest' | 'guard';

export interface NpcDefinition {
  id: string;
  nameAr: string;
  role: NpcRole;
  titleAr: string;
  greetingAr: string;
  x: number;
  z: number;
  robeHex: number;
  accentHex: number;
}

export interface QuestDefinition {
  id: string;
  titleAr: string;
  descriptionAr: string;
  targetType: 'kill_monsters' | 'clear_dungeon' | 'defeat_boss';
  targetCount: number;
  rewardGold: number;
  rewardShards: number;
  rewardItemId: string;
  rewardXp: number;
}

export interface QuestProgress {
  accepted: boolean;
  progress: number;
  completed: boolean;
  claimed: boolean;
}

export interface BestiaryRecord {
  discovered: boolean;
  defeatedCount: number;
  summonUnlocked: boolean;
}

export type LocationKind = 'dungeon' | 'crypt' | 'castle' | 'ruin' | 'cave';
export type LocationSubtype =
  | 'standard'
  | 'abandoned_castle'
  | 'guarded_castle'
  | 'monster_castle'
  | 'ruined_fort'
  | 'ancient_temple'
  | 'abandoned_village'
  | 'natural_cave'
  | 'ice_cave'
  | 'volcanic_cave'
  | 'crystal_cave'
  | 'abandoned_mine'
  | 'lake_cave';

export interface DungeonPortalInfo {
  id: string;
  nameAr: string;
  kind: LocationKind;
  subtype?: LocationSubtype;
  x: number;
  y: number;
  z: number;
  biomeId: BiomeId;
  level: number;
}

export interface NearbyInteractable {
  kind: 'npc' | 'portal' | 'dungeon_exit' | 'dungeon_chest';
  id: string;
  labelAr: string;
  subLabelAr?: string;
}

export interface ActiveBossHud {
  id: string;
  nameAr: string;
  hp: number;
  maxHp: number;
  phase: 1 | 2;
  activeSkillAr?: string | null;
}

export interface TargetEnemyHud {
  id: string;
  nameAr: string;
  level: number;
  hp: number;
  maxHp: number;
  weakness: ElementId;
  rank?: EntityRank;
  isRare?: boolean;
}

export interface DiscoveredLocation {
  id: string;
  nameAr: string;
  kind: LocationKind | 'village';
  subtype?: LocationSubtype;
  x: number;
  z: number;
  level: number;
}

export interface MapMarker {
  id: string;
  x: number;
  z: number;
  labelAr: string;
  colorHex: string;
}

export interface ActiveSummonEntry {
  uid: string;
  entityId: string;
  nameAr: string;
  role: 'tank' | 'dps' | 'ranged' | 'support';
  rank: EntityRank;
  soulPower: number;
  hp: number;
  maxHp: number;
  remainingSec: number;
  durationSec: number;
  isRebel: boolean;
}

export interface PlayerStateSnapshot {
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  cameraMode: CameraMode;
  level: number;
  xp: number;
  gold: number;
  elementShards: number;
  hp: number;
  maxHp: number;
  mana: number;
  maxMana: number;
  stamina: number;
  maxStamina: number;
  survival: SurvivalStats;
  inventory: InventoryEntry[];
  equipment: EquipmentState;
  elements: Record<ElementId, ElementProgress>;
  equippedElements: [ElementId | null, ElementId | null];
  bestiary: Record<string, BestiaryRecord>;
  activeSummonId: string | null;
  activeSummonIds?: string[];
  summonMasteryLevel?: number;
  summonMasteryXp?: number;
  summonCooldowns?: Record<string, number>;
  skillPoints?: number;
  skillRanks?: Record<string, number>;
  unlockedRealms?: string[];
  quests: Record<string, QuestProgress>;
  monstersKilled: number;
  dungeonsCleared: number;
  bossesDefeated: number;
}

export interface SaveDataV1 {
  version: number;
  seed: number;
  savedAt: number;
  playTimeSeconds: number;
  player: PlayerStateSnapshot;
  discoveredBiomes: BiomeId[];
  discoveredChunks: string[];
  discoveredLocations?: DiscoveredLocation[];
  mapMarkers?: MapMarker[];
  harvestedNodes?: string[];
  clearedDungeons?: string[];
  graphics: GraphicsSettings;
  audio?: AudioSettings;
}

export interface PerfMetrics {
  fps: number;
  frameTimeMs: number;
  drawCalls: number;
  triangles: number;
  geometries: number;
  textures: number;
  activeChunks: number;
  queuedChunks: number;
  biomeId: BiomeId;
  biomeNameAr: string;
  inDungeon: boolean;
  dungeonNameAr?: string;
  weather: WeatherKind;
  timeOfDay: number;
  timeOfDayLabelAr: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  isSwimming: boolean;
  isGrounded: boolean;
  isBlocking: boolean;
  nearbyInteractable: NearbyInteractable | null;
  activeBoss: ActiveBossHud | null;
  targetEnemy: TargetEnemyHud | null;
  activeSummonName: string | null;
  activeSummons?: ActiveSummonEntry[];
  soulPowerUsed?: number;
  soulControlMax?: number;
  activeEventLabelAr?: string | null;
}

export interface BiomeDefinition {
  id: BiomeId;
  nameAr: string;
  ambientTempC: number;
  skyHex: number;
  fogHex: number;
  fogDensity: number;
  groundHex: number;
  groundAltHex: number;
  rockHex: number;
  treeTintHex: number;
  foliageTintHex: number;
  heightScale: number;
  heightBase: number;
  treeDensity: number;
  rockDensity: number;
  grassDensity: number;
  crystalChance: number;
  ruinChance: number;
}

export interface ObstacleCollider {
  x: number;
  z: number;
  radius: number;
  topY: number;
}

export interface HarvestNode {
  id: string;
  x: number;
  y: number;
  z: number;
  kind: 'crystal' | 'crate' | 'herb';
  hp: number;
  maxHp: number;
  rewardItemId: string;
  rewardQty: number;
  shardReward: number;
  meshIndex: number;
}
