export type Phase = 'menu' | 'drop' | 'playing' | 'dying' | 'paused' | 'over';

export interface FeedItem {
  id: number;
  text: string;
  weapon: string;
  tone: 'kill' | 'death' | 'zone' | 'neutral';
  head: boolean;
}

export interface WeaponHud {
  name: string;
  mag: number;
  reserve: number;
  reloading: boolean;
  reloadFrac: number;
  slots: ({ name: string; mag: number } | null)[];
  active: number;
  auto: boolean;
}

export interface HudState {
  phase: Phase;
  hp: number;
  armor: number;
  meds: number;
  alive: number;
  kills: number;
  time: number;
  weapon: WeaponHud | null;
  zone: { inside: boolean; timeLeft: number; shrinking: boolean; radius: number; dps: number; stage: number };
  minimap: { px: number; pz: number; yaw: number; zx: number; zz: number; zr: number; mapR: number };
  prompt: string | null;
  hitTick: number;
  hitHead: boolean;
  dmgTick: number;
  feed: FeedItem[];
  ads: boolean;
  win: boolean;
  dropT: number;
  dropTotal: number;
}

export interface MatchResult {
  win: boolean;
  placement: number;
  kills: number;
  time: number;
  name: string;
}
