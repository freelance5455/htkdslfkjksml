export type BodyStyle = "sport" | "wedge" | "muscle" | "buggy";

export type Skin = {
  id: string;
  name: string;
  blurb: string;
  style: BodyStyle;
  body: string;
  accent: string;
  glass: string;
  stripe: string;
};

export const SKINS: Skin[] = [
  {
    id: "viper",
    name: "أفعى الرمل",
    blurb: "ذهب الصحراء وخطوط فحم",
    style: "sport",
    body: "#e0b15a",
    accent: "#1a1208",
    glass: "#d7ecff",
    stripe: "#1a1208",
  },
  {
    id: "ghost",
    name: "شبح الليل",
    blurb: "هيكل حاد ووهج سيان",
    style: "wedge",
    body: "#14343c",
    accent: "#3ee0c5",
    glass: "#c8fff4",
    stripe: "#3ee0c5",
  },
  {
    id: "ember",
    name: "جمرة",
    blurb: "عضلة حمرا تتنفس نار",
    style: "muscle",
    body: "#c2412d",
    accent: "#ffb088",
    glass: "#ffe1c4",
    stripe: "#2a0d08",
  },
  {
    id: "storm",
    name: "عاصفة",
    blurb: "باغي رملي بعجلات كبيرة",
    style: "buggy",
    body: "#6d7a45",
    accent: "#e8c27a",
    glass: "#d7ecff",
    stripe: "#2c2616",
  },
  {
    id: "bolt",
    name: "فضة البرق",
    blurb: "معدن فضي وخطوط فحم",
    style: "sport",
    body: "#d5d8df",
    accent: "#8ef3ff",
    glass: "#eef6ff",
    stripe: "#2a3140",
  },
  {
    id: "neon",
    name: "ملك النيون",
    blurb: "ماجنتا كهربائي على أسفلت الليل",
    style: "wedge",
    body: "#2a1030",
    accent: "#ff4fa3",
    glass: "#ffd0ea",
    stripe: "#ff4fa3",
  },
];

export function skinById(id: string): Skin {
  return SKINS.find((s) => s.id === id) ?? SKINS[0];
}
