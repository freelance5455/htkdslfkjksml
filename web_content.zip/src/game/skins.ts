export interface Skin {
  id: string;
  name: string;
  tagline: string;
  glove: string;   // main glove color
  glove2: string;  // cuff / secondary
  web: string;     // web / rope color
  hud: string;     // HUD accent
  emblem: string;  // hand emblem color
}

export const SKINS: Skin[] = [
  {
    id: 'classic',
    name: 'CLASSIC',
    tagline: 'The One & Only',
    glove: '#e62839',
    glove2: '#2b46d8',
    web: '#f2f4ff',
    hud: '#ff3b4e',
    emblem: '#101018',
  },
  {
    id: 'symbiote',
    name: 'SYMBIOTE',
    tagline: 'The Black Suit',
    glove: '#15151d',
    glove2: '#33333f',
    web: '#ffffff',
    hud: '#a9adff',
    emblem: '#e8e9f5',
  },
  {
    id: 'iron',
    name: 'IRON SPIDER',
    tagline: 'Powered by Stark',
    glove: '#e0342e',
    glove2: '#f5b31a',
    web: '#ffd84d',
    hud: '#ffb31a',
    emblem: '#20242e',
  },
  {
    id: 'superior',
    name: 'SUPERIOR',
    tagline: 'Red & Black',
    glove: '#d22323',
    glove2: '#141414',
    web: '#ffffff',
    hud: '#ff4b3e',
    emblem: '#f2f4f8',
  },
  {
    id: 'dayone',
    name: 'DAY ONE',
    tagline: 'The White Suit',
    glove: '#eef1f7',
    glove2: '#aab2c8',
    web: '#ffffff',
    hud: '#7fd7ff',
    emblem: '#101018',
  },
];
