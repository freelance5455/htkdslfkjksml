import { Enemy, EnemyType, EnemyAIState, Direction, Building } from '../types/game';
import { sounds } from './audio';

export function createEnemy(
  id: string,
  type: EnemyType,
  x: number,
  y: number
): Enemy {
  let health = 30;
  let damage = 6;
  let speed = 1.0;
  let detectionRange = 110;
  let attackRange = 26;
  let width = 24;
  let height = 24;
  let isHerbivore = false;
  let isAquatic = false;
  let isRare = false;
  let isAggroOnHit = false;
  let displayNameAr = 'كائن بري';
  let drops: { item: any; count: number; chance: number }[] = [];

  switch (type) {
    case 'slime':
      health = 25;
      damage = 6;
      speed = 1.0;
      detectionRange = 100;
      attackRange = 24;
      displayNameAr = 'وحش الوحل (Slime)';
      drops = [{ item: 'fiber', count: 2, chance: 0.8 }];
      break;
    case 'wolf':
      health = 55;
      damage = 14;
      speed = 1.8;
      detectionRange = 170;
      attackRange = 30;
      width = 36;
      height = 28;
      displayNameAr = 'الذئب المفترس (Wolf)';
      drops = [{ item: 'fiber', count: 3, chance: 0.9 }];
      break;
    case 'night_creature':
      health = 80;
      damage = 22;
      speed = 2.0;
      detectionRange = 220;
      attackRange = 34;
      width = 36;
      height = 36;
      displayNameAr = 'كائن الظلام (Night Stalker)';
      drops = [{ item: 'coal', count: 3, chance: 1.0 }];
      break;
    case 'deer':
      health = 40;
      damage = 0;
      speed = 2.4;
      detectionRange = 135;
      width = 32;
      height = 32;
      isHerbivore = true;
      displayNameAr = 'غزال بري (Deer)';
      drops = [{ item: 'apple', count: 2, chance: 0.9 }, { item: 'fiber', count: 2, chance: 0.7 }];
      break;
    case 'golden_deer':
      health = 60;
      damage = 0;
      speed = 3.0;
      detectionRange = 170;
      width = 32;
      height = 32;
      isHerbivore = true;
      isRare = true;
      displayNameAr = 'الغزال الذهبي الأسطوري (Golden Deer)';
      drops = [{ item: 'apple', count: 4, chance: 1.0 }, { item: 'iron', count: 3, chance: 1.0 }];
      break;
    case 'rabbit':
      health = 15;
      damage = 0;
      speed = 2.7;
      detectionRange = 110;
      width = 18;
      height = 18;
      isHerbivore = true;
      displayNameAr = 'أرنب الحقول (Rabbit)';
      drops = [{ item: 'berry', count: 3, chance: 0.9 }];
      break;
    case 'boar':
      health = 55;
      damage = 10;
      speed = 1.5;
      detectionRange = 90;
      attackRange = 26;
      width = 28;
      height = 24;
      isAggroOnHit = true;
      displayNameAr = 'خنزير الغابة (Boar)';
      drops = [{ item: 'berry', count: 2, chance: 0.8 }, { item: 'fiber', count: 2, chance: 0.6 }];
      break;
    case 'wild_boar':
      health = 75;
      damage = 16;
      speed = 2.1;
      detectionRange = 140;
      attackRange = 30;
      width = 32;
      height = 28;
      displayNameAr = 'الخنزير البري الغاضب (Wild Boar)';
      drops = [{ item: 'fiber', count: 3, chance: 0.9 }];
      break;
    case 'goat':
      health = 35;
      damage = 0;
      speed = 1.9;
      detectionRange = 120;
      width = 26;
      height = 26;
      isHerbivore = true;
      displayNameAr = 'ماعز المرتفعات (Mountain Goat)';
      drops = [{ item: 'fiber', count: 3, chance: 0.9 }];
      break;
    case 'chicken':
      health = 12;
      damage = 0;
      speed = 1.4;
      detectionRange = 85;
      width = 16;
      height = 16;
      isHerbivore = true;
      displayNameAr = 'دجاجة برية (Wild Chicken)';
      drops = [{ item: 'berry', count: 1, chance: 0.8 }];
      break;
    case 'duck':
      health = 18;
      damage = 0;
      speed = 1.5;
      detectionRange = 90;
      width = 18;
      height = 18;
      isAquatic = true;
      isHerbivore = true;
      displayNameAr = 'بطة البحيرة (Duck)';
      drops = [{ item: 'fiber', count: 1, chance: 0.7 }];
      break;
    case 'bird':
      health = 10;
      damage = 0;
      speed = 2.0;
      detectionRange = 90;
      width = 16;
      height = 16;
      isHerbivore = true;
      displayNameAr = 'طائر الغابة (Forest Bird)';
      drops = [{ item: 'berry', count: 1, chance: 0.6 }];
      break;
    case 'fish':
      health = 15;
      damage = 0;
      speed = 1.3;
      detectionRange = 60;
      width = 18;
      height = 14;
      isAquatic = true;
      displayNameAr = 'سمكة نهرية (River Fish)';
      drops = [{ item: 'berry', count: 2, chance: 0.9 }];
      break;
    case 'frog':
      health = 14;
      damage = 0;
      speed = 1.4;
      detectionRange = 75;
      width = 16;
      height = 14;
      isAquatic = true;
      displayNameAr = 'ضفدع المستنقع (Swamp Frog)';
      drops = [{ item: 'fiber', count: 1, chance: 0.5 }];
      break;
    case 'bear':
      health = 130;
      damage = 25;
      speed = 1.7;
      detectionRange = 160;
      attackRange = 36;
      width = 44;
      height = 36;
      displayNameAr = 'الدب البري العملاق (Grizzly Bear)';
      drops = [{ item: 'berry', count: 4, chance: 1.0 }, { item: 'fiber', count: 5, chance: 1.0 }];
      break;
    case 'croc':
      health = 95;
      damage = 22;
      speed = 1.8;
      detectionRange = 135;
      attackRange = 32;
      width = 42;
      height = 24;
      isAquatic = true;
      displayNameAr = 'تمساح المستنقع (Swamp Croc)';
      drops = [{ item: 'fiber', count: 4, chance: 1.0 }];
      break;
  }

  return {
    id,
    type,
    x,
    y,
    vx: 0,
    vy: 0,
    health,
    maxHealth: health,
    damage,
    speed,
    detectionRange,
    attackRange,
    attackCooldown: 0,
    state: 'idle',
    stateTimer: Math.random() * 60 + 30,
    patrolTarget: null,
    spawnPoint: { x, y },
    direction: 'down',
    animFrame: 0,
    animTimer: 0,
    hurtTimer: 0,
    width,
    height,
    isHerbivore,
    isAquatic,
    isRare,
    isAggroOnHit,
    displayNameAr,
    drops,
  };
}

export function updateEnemyAI(
  enemy: Enemy,
  playerX: number,
  playerY: number,
  isNight: boolean,
  campfires: Building[],
  onAttackPlayer: (dmg: number) => void
) {
  if (enemy.health <= 0) return;

  if (enemy.attackCooldown > 0) {
    enemy.attackCooldown--;
  }
  if (enemy.hurtTimer > 0) {
    enemy.hurtTimer--;
    enemy.state = 'hurt';
    enemy.x += enemy.vx;
    enemy.y += enemy.vy;
    enemy.vx *= 0.82;
    enemy.vy *= 0.82;
    return;
  }

  // Detect state timer (alert exclamation pause)
  if (enemy.detectTimer && enemy.detectTimer > 0) {
    enemy.detectTimer--;
    enemy.state = 'detect';
    enemy.vx = 0;
    enemy.vy = 0;
    if (enemy.detectTimer <= 0) {
      enemy.state = 'chase';
    }
    return;
  }

  // Animation cycle
  enemy.animTimer++;
  if (enemy.animTimer > 12) {
    enemy.animTimer = 0;
    enemy.animFrame = enemy.animFrame === 0 ? 1 : 0;
  }

  const distToPlayer = Math.hypot(playerX - enemy.x, playerY - enemy.y);

  // Night creature fears campfire light
  let nearestCampfireDist = Infinity;
  let nearestCampfire: Building | null = null;
  if (enemy.type === 'night_creature') {
    for (const b of campfires) {
      if (b.type === 'campfire') {
        const d = Math.hypot(b.tileX * 32 + 16 - enemy.x, b.tileY * 32 + 16 - enemy.y);
        if (d < nearestCampfireDist) {
          nearestCampfireDist = d;
          nearestCampfire = b;
        }
      }
    }
  }

  // Check if night creature is fleeing from campfire
  if (enemy.type === 'night_creature' && nearestCampfire && nearestCampfireDist < 140) {
    enemy.state = 'flee';
    const cfx = nearestCampfire.tileX * 32 + 16;
    const cfy = nearestCampfire.tileY * 32 + 16;
    const angle = Math.atan2(enemy.y - cfy, enemy.x - cfx);
    enemy.vx = Math.cos(angle) * enemy.speed * 1.3;
    enemy.vy = Math.sin(angle) * enemy.speed * 1.3;
    enemy.x += enemy.vx;
    enemy.y += enemy.vy;
    enemy.direction = enemy.vx > 0 ? 'right' : 'left';
    return;
  }

  // Herbivore behavior (Deer, Rabbit, Goat, Chicken, Duck, Bird, Golden Deer, etc.)
  if (enemy.isHerbivore) {
    if (distToPlayer <= enemy.detectionRange) {
      // Alert and flee
      if (enemy.state !== 'flee') {
        enemy.state = 'detect';
        enemy.detectTimer = 18;
      }
      enemy.state = 'flee';
      // Angle strictly AWAY from player
      const angle = Math.atan2(enemy.y - playerY, enemy.x - playerX);
      const fleeMultiplier = enemy.isRare ? 1.5 : 1.3;
      enemy.vx = Math.cos(angle) * (enemy.speed * fleeMultiplier);
      enemy.vy = Math.sin(angle) * (enemy.speed * fleeMultiplier);
      enemy.x += enemy.vx;
      enemy.y += enemy.vy;
      enemy.direction = enemy.vx > 0 ? 'right' : 'left';
      return;
    } else {
      // Wandering, Eating, Drinking, Sleeping
      enemy.stateTimer--;
      if (enemy.stateTimer <= 0) {
        const rand = Math.random();
        if (isNight && rand < 0.6) {
          enemy.state = 'sleep';
          enemy.vx = 0;
          enemy.vy = 0;
          enemy.stateTimer = 180 + Math.random() * 120;
        } else if (rand < 0.35) {
          enemy.state = 'eat'; // Grazing
          enemy.vx = 0;
          enemy.vy = 0;
          enemy.stateTimer = 90 + Math.random() * 60;
        } else if (rand < 0.55) {
          enemy.state = 'drink'; // Drinking
          enemy.vx = 0;
          enemy.vy = 0;
          enemy.stateTimer = 70 + Math.random() * 50;
        } else if (rand < 0.8) {
          enemy.state = 'wander';
          enemy.stateTimer = 120 + Math.random() * 60;
          const radius = 90;
          const angle = Math.random() * Math.PI * 2;
          enemy.patrolTarget = {
            x: enemy.spawnPoint.x + Math.cos(angle) * radius,
            y: enemy.spawnPoint.y + Math.sin(angle) * radius,
          };
        } else {
          enemy.state = 'idle';
          enemy.vx = 0;
          enemy.vy = 0;
          enemy.stateTimer = 60 + Math.random() * 40;
        }
      }

      if (enemy.state === 'wander' && enemy.patrolTarget) {
        const dist = Math.hypot(enemy.patrolTarget.x - enemy.x, enemy.patrolTarget.y - enemy.y);
        if (dist < 8) {
          enemy.state = 'idle';
          enemy.vx = 0;
          enemy.vy = 0;
        } else {
          const angle = Math.atan2(enemy.patrolTarget.y - enemy.y, enemy.patrolTarget.x - enemy.x);
          enemy.vx = Math.cos(angle) * (enemy.speed * 0.5);
          enemy.vy = Math.sin(angle) * (enemy.speed * 0.5);
          enemy.x += enemy.vx;
          enemy.y += enemy.vy;
          enemy.direction = enemy.vx > 0 ? 'right' : 'left';
        }
      }
      return;
    }
  }

  // Neutral Boar behavior: peaceful unless attacked
  if (enemy.type === 'boar' && !enemy.isAggroOnHit) {
    if (distToPlayer <= enemy.detectionRange * 0.5) {
      // Grunts and observes
      enemy.state = 'detect';
      enemy.vx = 0;
      enemy.vy = 0;
      return;
    }
    // Otherwise wanders and eats
    enemy.stateTimer--;
    if (enemy.stateTimer <= 0) {
      enemy.state = Math.random() < 0.5 ? 'eat' : 'wander';
      enemy.stateTimer = 100 + Math.random() * 80;
    }
    return;
  }

  // Predator low-health retreat (Survival instinct)
  if (enemy.health < enemy.maxHealth * 0.25 && enemy.damage > 0) {
    enemy.state = 'flee';
    const angle = Math.atan2(enemy.y - playerY, enemy.x - playerX);
    enemy.vx = Math.cos(angle) * (enemy.speed * 1.2);
    enemy.vy = Math.sin(angle) * (enemy.speed * 1.2);
    enemy.x += enemy.vx;
    enemy.y += enemy.vy;
    enemy.direction = enemy.vx > 0 ? 'right' : 'left';
    return;
  }

  // Standard Predator State transitions (Wolf, Bear, Slime, Croc, Night Creature)
  if (distToPlayer <= enemy.attackRange) {
    enemy.state = 'attack';
    enemy.vx = 0;
    enemy.vy = 0;
    if (enemy.attackCooldown <= 0) {
      enemy.attackCooldown = 50; // frames
      sounds.playMonsterGrowl();
      onAttackPlayer(enemy.damage);
    }
  } else if (distToPlayer <= enemy.detectionRange) {
    // If was in idle/patrol, alert first with 'detect' state
    if (enemy.state === 'idle' || enemy.state === 'patrol' || enemy.state === 'wander') {
      enemy.state = 'detect';
      enemy.detectTimer = 22;
      sounds.playMonsterGrowl();
      return;
    }

    enemy.state = 'chase';
    const angle = Math.atan2(playerY - enemy.y, playerX - enemy.x);
    enemy.vx = Math.cos(angle) * enemy.speed;
    enemy.vy = Math.sin(angle) * enemy.speed;
    enemy.x += enemy.vx;
    enemy.y += enemy.vy;

    // Face player
    if (Math.abs(enemy.vx) > Math.abs(enemy.vy)) {
      enemy.direction = enemy.vx > 0 ? 'right' : 'left';
    } else {
      enemy.direction = enemy.vy > 0 ? 'down' : 'up';
    }
  } else {
    // Patrol / Idle behavior
    enemy.stateTimer--;
    if (enemy.stateTimer <= 0) {
      if (enemy.state === 'idle') {
        enemy.state = 'patrol';
        enemy.stateTimer = Math.random() * 120 + 60;
        // Random patrol point near spawn
        const radius = 90;
        const angle = Math.random() * Math.PI * 2;
        enemy.patrolTarget = {
          x: enemy.spawnPoint.x + Math.cos(angle) * radius,
          y: enemy.spawnPoint.y + Math.sin(angle) * radius,
        };
      } else {
        enemy.state = 'idle';
        enemy.stateTimer = Math.random() * 90 + 45;
        enemy.vx = 0;
        enemy.vy = 0;
        enemy.patrolTarget = null;
      }
    }

    if (enemy.state === 'patrol' && enemy.patrolTarget) {
      const distToTarget = Math.hypot(enemy.patrolTarget.x - enemy.x, enemy.patrolTarget.y - enemy.y);
      if (distToTarget < 6) {
        enemy.state = 'idle';
        enemy.vx = 0;
        enemy.vy = 0;
      } else {
        const angle = Math.atan2(enemy.patrolTarget.y - enemy.y, enemy.patrolTarget.x - enemy.x);
        enemy.vx = Math.cos(angle) * (enemy.speed * 0.6);
        enemy.vy = Math.sin(angle) * (enemy.speed * 0.6);
        enemy.x += enemy.vx;
        enemy.y += enemy.vy;
        enemy.direction = enemy.vx > 0 ? 'right' : 'left';
      }
    }
  }
}
