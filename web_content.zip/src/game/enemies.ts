import * as THREE from 'three';

export interface HostileUnit {
  id: string;
  group: THREE.Group;
  hitMeshes: THREE.Mesh[];
  waypoints: THREE.Vector3[];
  currentWaypoint: number;
  hp: number;
  maxHp: number;
  alive: boolean;
  alerted: boolean;
  fireCooldown: number;
  hoverPhase: number;
  visorMat: THREE.MeshStandardMaterial;
  beaconLight: THREE.PointLight;
  laserLine: THREE.Line;
  laserGeo: THREE.BufferGeometry;
  hitFlashTimer: number;
  zone: string;
}

const _dir = new THREE.Vector3();
const _targetPos = new THREE.Vector3();
const _rayOrigin = new THREE.Vector3();

export function createHostileDrone(
  id: string,
  zone: string,
  waypoints: THREE.Vector3[],
): HostileUnit {
  const group = new THREE.Group();
  group.position.copy(waypoints[0]);

  const armorMat = new THREE.MeshStandardMaterial({
    color: 0x1e2228,
    metalness: 0.82,
    roughness: 0.34,
  });

  const chassisMat = new THREE.MeshStandardMaterial({
    color: 0x101216,
    metalness: 0.35,
    roughness: 0.78,
  });

  const trimMat = new THREE.MeshStandardMaterial({
    color: 0x8a5a18,
    metalness: 0.45,
    roughness: 0.55,
  });

  const visorMat = new THREE.MeshStandardMaterial({
    color: 0xff1f1f,
    emissive: 0xff1f1f,
    emissiveIntensity: 3.4,
    roughness: 0.1,
  });

  // Composite 7-part security combat drone (grounded pivot at bottom-center, hovering at y=1.35)
  const coreGroup = new THREE.Group();
  coreGroup.position.y = 1.35;
  group.add(coreGroup);

  // 1. Armored Upper Carapace
  const carapace = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.28, 0.62), armorMat);
  carapace.castShadow = true;
  carapace.receiveShadow = true;
  coreGroup.add(carapace);

  // 2. Underslung Gyroscopic Gimbal & Weapon Pod
  const gimbal = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.18, 0.24, 12), chassisMat);
  gimbal.position.set(0, -0.22, 0.02);
  gimbal.castShadow = true;
  coreGroup.add(gimbal);

  // 3. Twin Side Thruster Cowls
  [-0.38, 0.38].forEach((xOff) => {
    const cowl = new THREE.Mesh(
      new THREE.CylinderGeometry(0.12, 0.14, 0.34, 12),
      armorMat,
    );
    cowl.position.set(xOff, 0.02, -0.04);
    cowl.castShadow = true;
    coreGroup.add(cowl);

    const intake = new THREE.Mesh(
      new THREE.CylinderGeometry(0.09, 0.09, 0.36, 10),
      trimMat,
    );
    intake.position.set(xOff, 0.02, -0.04);
    coreGroup.add(intake);
  });

  // 4. Optical Sensor Visor Bar
  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.07, 0.06), visorMat);
  visor.position.set(0, 0.03, 0.31);
  coreGroup.add(visor);

  // 5. Twin Suppressor Barrels
  [-0.08, 0.08].forEach((xOff) => {
    const barrel = new THREE.Mesh(
      new THREE.CylinderGeometry(0.022, 0.022, 0.36, 8).rotateX(Math.PI / 2),
      chassisMat,
    );
    barrel.position.set(xOff, -0.22, 0.22);
    coreGroup.add(barrel);
  });

  // 6. Dorsal Antenna
  const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.014, 0.35, 6), chassisMat);
  antenna.position.set(-0.18, 0.28, -0.18);
  coreGroup.add(antenna);

  // 7. Optical Red PointLight casting eerie crimson bounce on wet concrete
  const beaconLight = new THREE.PointLight(0xff2222, 2.8, 7.5, 1.8);
  beaconLight.position.set(0, 0.05, 0.42);
  coreGroup.add(beaconLight);

  // Laser targeter beam
  const laserGeo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(0, 1.38, 0.32),
    new THREE.Vector3(0, 1.38, 4.0),
  ]);
  const laserMat = new THREE.LineBasicMaterial({
    color: 0xff2222,
    transparent: true,
    opacity: 0.42,
  });
  const laserLine = new THREE.Line(laserGeo, laserMat);
  group.add(laserLine);

  const hitMeshes = [carapace, gimbal, visor];
  hitMeshes.forEach((m) => {
    m.userData.hostileId = id;
    m.layers.enable(1); // Raycast layer 1 for crisp hit detection
  });

  return {
    id,
    group,
    hitMeshes,
    waypoints,
    currentWaypoint: 1 % waypoints.length,
    hp: 100,
    maxHp: 100,
    alive: true,
    alerted: false,
    fireCooldown: 1.1 + Math.random() * 0.6,
    hoverPhase: Math.random() * Math.PI * 2,
    visorMat,
    beaconLight,
    laserLine,
    laserGeo,
    hitFlashTimer: 0,
    zone,
  };
}

export function updateHostiles(
  hostiles: HostileUnit[],
  playerPos: THREE.Vector3,
  colliders: THREE.Mesh[],
  raycaster: THREE.Raycaster,
  dt: number,
  onHostileFire: (origin: THREE.Vector3, target: THREE.Vector3, hitPlayer: boolean) => void,
): void {
  for (const unit of hostiles) {
    if (!unit.alive) continue;

    unit.hoverPhase += dt * 2.6;
    const core = unit.group.children[0];
    if (core) {
      core.position.y = 1.35 + Math.sin(unit.hoverPhase) * 0.08;
    }

    if (unit.hitFlashTimer > 0) {
      unit.hitFlashTimer -= dt;
      unit.visorMat.emissive.setHex(0xffffff);
      unit.visorMat.emissiveIntensity = 5.0;
    } else {
      unit.visorMat.emissive.setHex(unit.alerted ? 0xff1111 : 0xff5500);
      unit.visorMat.emissiveIntensity = unit.alerted ? 4.2 : 2.2;
      unit.beaconLight.color.setHex(unit.alerted ? 0xff1818 : 0xff6622);
    }

    // Check line of sight to player
    _rayOrigin.set(unit.group.position.x, 1.38, unit.group.position.z);
    _targetPos.set(playerPos.x, playerPos.y - 0.15, playerPos.z);
    _dir.subVectors(_targetPos, _rayOrigin);
    const dist = _dir.length();

    let hasLos = false;
    if (dist < 24) {
      _dir.normalize();
      raycaster.layers.set(0);
      raycaster.set(_rayOrigin, _dir);
      raycaster.far = dist;
      const hits = raycaster.intersectObjects(colliders, false);
      if (hits.length === 0) {
        hasLos = true;
      }
    }

    if (hasLos) {
      unit.alerted = true;
    }

    if (unit.alerted) {
      // Face player smoothly
      const targetAngle = Math.atan2(
        playerPos.x - unit.group.position.x,
        playerPos.z - unit.group.position.z,
      );
      const currentY = unit.group.rotation.y;
      let diff = targetAngle - currentY;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      unit.group.rotation.y += diff * Math.min(1, dt * 4.5);

      // Slowly stalk toward player if far & has LOS
      if (hasLos && dist > 6.5) {
        unit.group.position.x += _dir.x * 1.65 * dt;
        unit.group.position.z += _dir.z * 1.65 * dt;
      }

      // Update laser sight endpoint
      const posAttr = unit.laserGeo.attributes.position as THREE.BufferAttribute;
      const laserLen = hasLos ? Math.min(dist, 18) : 6.0;
      posAttr.setXYZ(0, 0, 1.38, 0.32);
      posAttr.setXYZ(1, 0, 1.38 - (hasLos ? 0.15 : 0.0), laserLen);
      posAttr.needsUpdate = true;

      // Fire burst periodically when holding line-of-sight
      if (hasLos) {
        unit.fireCooldown -= dt;
        if (unit.fireCooldown <= 0) {
          unit.fireCooldown = 1.35 + Math.random() * 0.85;
          const accuracy = Math.max(0.28, 0.72 - dist * 0.02);
          const hitPlayer = Math.random() < accuracy;
          onHostileFire(_rayOrigin.clone(), _targetPos.clone(), hitPlayer);
        }
      }
    } else {
      // Patrol between waypoints
      const wp = unit.waypoints[unit.currentWaypoint];
      const dx = wp.x - unit.group.position.x;
      const dz = wp.z - unit.group.position.z;
      const wpDist = Math.hypot(dx, dz);

      if (wpDist < 0.35) {
        unit.currentWaypoint = (unit.currentWaypoint + 1) % unit.waypoints.length;
      } else {
        const vx = (dx / wpDist) * 1.5;
        const vz = (dz / wpDist) * 1.5;
        unit.group.position.x += vx * dt;
        unit.group.position.z += vz * dt;

        const patrolYaw = Math.atan2(dx, dz);
        let diff = patrolYaw - unit.group.rotation.y;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        unit.group.rotation.y += diff * Math.min(1, dt * 3.0);
      }

      const posAttr = unit.laserGeo.attributes.position as THREE.BufferAttribute;
      posAttr.setXYZ(0, 0, 1.38, 0.32);
      posAttr.setXYZ(1, 0, 1.25, 5.5);
      posAttr.needsUpdate = true;
    }
  }
}
