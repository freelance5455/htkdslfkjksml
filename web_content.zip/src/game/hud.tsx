import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  BookOpen,
  Cherry,
  Disc,
  Droplets,
  Flame,
  Hammer,
  Hand,
  Heart,
  Leaf,
  Moon,
  Mountain,
  RotateCw,
  Sparkles,
  Sun,
  Sword,
  Trees,
  Volume2,
  VolumeX,
  Wind,
  X,
} from "lucide-react";
import { isMuted, setMuted, sfx, unlockAudio } from "./audio";
import {
  BUILDINGS,
  BUILD_ORDER,
  COST,
  COTTAGE,
  ELEMENT_LABEL,
  ISLAND_R,
  PAL,
  POND,
  QUESTS,
  SPECIES,
  SPECIES_LIST,
  STARTERS,
  clockLabel,
  daylight,
  workMatch,
  type Element,
  type SpeciesId,
} from "./data";
import {
  assignWorker,
  backToTitle,
  begin,
  buildStation,
  catchChance,
  currentQuestOf,
  eatBerry,
  getSim,
  mergePal,
  openMenu,
  restPal,
  saveSim,
  setActive,
} from "./sim";
import { useHud, type Menu } from "./store";

const ICONS: Record<Element, typeof Leaf> = {
  leaf: Leaf,
  tide: Droplets,
  ember: Flame,
  stone: Mountain,
  gust: Wind,
  glow: Sparkles,
};

function useCoarse() {
  const [coarse, setCoarse] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(pointer: coarse)");
    const apply = () => setCoarse(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);
  return coarse;
}

function stagePoint(el: HTMLElement, clientX: number, clientY: number) {
  const stage = el.closest(".game-stage") as HTMLElement | null;
  const host = stage ?? el;
  const rect = host.getBoundingClientRect();
  const rot = Number(host.dataset.rot ?? "0") * (Math.PI / 180);
  const dx = clientX - (rect.left + rect.width / 2);
  const dy = clientY - (rect.top + rect.height / 2);
  const cos = Math.cos(-rot);
  const sin = Math.sin(-rot);
  const lx = dx * cos - dy * sin + host.offsetWidth / 2;
  const ly = dx * sin + dy * cos + host.offsetHeight / 2;
  if (!stage || el === stage) return { x: lx, y: ly };
  const r = el.getBoundingClientRect();
  const ecx = r.left + r.width / 2;
  const ecy = r.top + r.height / 2;
  const ex = ecx - (rect.left + rect.width / 2);
  const ey = ecy - (rect.top + rect.height / 2);
  const ox = ex * cos - ey * sin + host.offsetWidth / 2;
  const oy = ex * sin + ey * cos + host.offsetHeight / 2;
  return { x: lx - (ox - el.offsetWidth / 2), y: ly - (oy - el.offsetHeight / 2) };
}

function Joystick() {
  const base = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  useEffect(() => {
    return () => {
      const sim = getSim();
      sim.input.x = 0;
      sim.input.z = 0;
    };
  }, []);
  function setFrom(clientX: number, clientY: number) {
    const el = base.current;
    if (!el) return;
    const p = stagePoint(el, clientX, clientY);
    const cx = el.offsetWidth / 2;
    const cy = el.offsetHeight / 2;
    let dx = p.x - cx;
    let dy = p.y - cy;
    const max = cx * 0.62;
    const m = Math.hypot(dx, dy) || 1;
    const k = Math.min(1, m / max);
    dx = (dx / m) * k;
    dy = (dy / m) * k;
    setKnob({ x: dx * max, y: dy * max });
    const sim = getSim();
    sim.input.x = dx;
    sim.input.z = -dy;
  }
  return (
    <div
      ref={base}
      className="joy"
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        setFrom(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) setFrom(e.clientX, e.clientY);
      }}
      onPointerUp={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
        setKnob({ x: 0, y: 0 });
        const sim = getSim();
        sim.input.x = 0;
        sim.input.z = 0;
      }}
    >
      <span className="joy-knob" style={{ transform: `translate(${knob.x}px, ${knob.y}px)` }} />
    </div>
  );
}

function HoldButton({
  label,
  field,
  children,
}: {
  label: string;
  field: "attack" | "orb" | "use";
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      className="icon-btn"
      aria-label={label}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        getSim().input[field] = true;
      }}
      onPointerUp={() => {
        getSim().input[field] = false;
      }}
      onPointerCancel={() => {
        getSim().input[field] = false;
      }}
    >
      {children}
    </button>
  );
}

function Minimap() {
  const ref = useRef<HTMLCanvasElement>(null);
  const rev = useHud((s) => s.rev);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const sim = getSim();
    const w = c.width;
    const h = c.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = PAL.mossDeep;
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 2 - 2, 0, Math.PI * 2);
    ctx.fill();
    const scale = (w / 2 - 8) / ISLAND_R;
    const dot = (x: number, z: number, color: string, r: number) => {
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(w / 2 + x * scale, h / 2 + z * scale, r, 0, Math.PI * 2);
      ctx.fill();
    };
    ctx.fillStyle = PAL.tide;
    ctx.beginPath();
    ctx.arc(w / 2 + POND.x * scale, h / 2 + POND.z * scale, POND.r * scale, 0, Math.PI * 2);
    ctx.fill();
    dot(COTTAGE.x, COTTAGE.z, PAL.creamDeep, 3.2);
    for (const p of sim.pals) {
      if (!p.alive) continue;
      dot(p.x, p.z, p.wild ? PAL.amber : PAL.cream, p.wild ? 2.2 : 2.8);
    }
    ctx.save();
    ctx.translate(w / 2 + sim.player.x * scale, h / 2 + sim.player.z * scale);
    ctx.rotate(-sim.player.yaw);
    ctx.fillStyle = PAL.foam;
    ctx.beginPath();
    ctx.moveTo(0, -6);
    ctx.lineTo(4.5, 5);
    ctx.lineTo(-4.5, 5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }, [rev]);
  return <canvas ref={ref} width={160} height={160} className="minimap" aria-hidden />;
}

function Bar({ value, max }: { value: number; max: number }) {
  const k = Math.max(0, Math.min(1, value / max));
  return (
    <span className="bar">
      <span style={{ width: `${k * 100}%` }} />
    </span>
  );
}

function Chip({ icon: Icon, value, label }: { icon: typeof Trees; value: number; label: string }) {
  return (
    <span className="hud-chip" title={label}>
      <Icon aria-hidden size={16} />
      <b>{value}</b>
    </span>
  );
}

function MenuButton({ id, label, icon: Icon }: { id: Menu; label: string; icon: typeof BookOpen }) {
  const open = useHud((s) => s.menu);
  return (
    <button type="button" className={open === id ? "icon-btn on" : "icon-btn"} aria-label={label} onClick={() => openMenu(open === id ? null : id)}>
      <Icon size={18} />
    </button>
  );
}

function TitleCard() {
  const preview = useHud((s) => s.preview);
  const setPreview = useHud((s) => s.setPreview);
  const sim = getSim();
  return (
    <div className="title-card">
      <p className="eyebrow">Lumenrest meadow</p>
      <h1>Palmon</h1>
      <p className="lede">Catch the meadow’s monsters. Raise a village that runs while you wander.</p>
      <div className="starter-row">
        {STARTERS.map((id) => {
          const spec = SPECIES[id];
          const Icon = ICONS[spec.element];
          return (
            <button
              key={id}
              type="button"
              className={preview === id ? "starter on" : "starter"}
              onClick={() => setPreview(id)}
              aria-pressed={preview === id}
            >
              <Icon size={18} />
              <strong>{spec.name}</strong>
              <span>{spec.blurb}</span>
            </button>
          );
        })}
      </div>
      <div className="title-actions">
        {sim.hasSave ? (
          <button type="button" className="btn-ghost" onClick={() => begin("continue")}>
            Continue
          </button>
        ) : null}
        <button
          type="button"
          className="btn-amber"
          onClick={() => {
            unlockAudio();
            begin(sim.hasSave ? "new" : "continue");
          }}
        >
          Start
        </button>
      </div>
      <p className="fine">
        <RotateCw size={14} /> Screen turns itself. W forward, A left, D right. Space strikes, F throws a Palorb, E gathers.
      </p>
    </div>
  );
}

function Panel({ title, children, onClose }: { title: string; children: ReactNode; onClose: () => void }) {
  return (
    <div className="sheet" role="dialog" aria-label={title}>
      <header>
        <h2>{title}</h2>
        <button type="button" className="icon-btn" aria-label="Close" onClick={onClose}>
          <X size={18} />
        </button>
      </header>
      <div className="sheet-body">{children}</div>
    </div>
  );
}

function PartyPanel() {
  const sim = getSim();
  const tamed = sim.pals.filter((p) => p.alive && !p.wild);
  if (!tamed.length) return <p>No Palmons yet.</p>;
  return (
    <ul className="card-list">
      {tamed.map((pal) => {
        const spec = SPECIES[pal.species];
        const Icon = ICONS[spec.element];
        const twin = tamed.some((p) => p.id !== pal.id && p.species === pal.species);
        const status = pal.active ? "Following" : pal.workerPad != null ? "Working" : "Resting in the yard";
        return (
          <li key={pal.id} className="pal-card">
            <div className="pal-top">
              <span className="badge">
                <Icon size={16} />
              </span>
              <div>
                <strong>
                  {spec.name} · Lv {pal.level}
                </strong>
                <p>
                  {ELEMENT_LABEL[spec.element]} · {status}
                </p>
              </div>
            </div>
            <Bar value={pal.hp} max={pal.maxHp} />
            <div className="row-actions">
              <button type="button" className="btn-tiny" onClick={() => setActive(pal.id)}>
                Follow
              </button>
              <button type="button" className="btn-tiny" onClick={() => restPal(pal.id)}>
                Rest
              </button>
              {sim.buildings.map((b) => (
                <button key={b.id} type="button" className="btn-tiny" onClick={() => assignWorker(pal.id, b.pad)}>
                  {BUILDINGS[b.type].name}
                  {workMatch(b.type, spec.element) ? " +" : ""}
                </button>
              ))}
              {twin ? (
                <button type="button" className="btn-tiny" onClick={() => mergePal(pal.id)}>
                  Merge
                </button>
              ) : null}
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function BuildPanel() {
  const sim = getSim();
  return (
    <ul className="card-list">
      {BUILD_ORDER.map((type) => {
        const info = BUILDINGS[type];
        const cost = COST[type];
        const afford =
          sim.resources.wood >= cost.wood && sim.resources.stone >= cost.stone && sim.resources.berry >= cost.berry;
        const plots = PADS_LEFT(sim.buildings.length);
        return (
          <li key={type} className="pal-card">
            <strong>{info.name}</strong>
            <p>{info.blurb}</p>
            <p className="meta">
              Makes {info.makes}. Cost {cost.wood} wood, {cost.stone} stone, {cost.berry} berries.
            </p>
            <button type="button" className="btn-tiny" disabled={!afford || !plots} onClick={() => buildStation(type)}>
              {plots ? (afford ? "Build" : "Need more") : "No plots"}
            </button>
          </li>
        );
      })}
    </ul>
  );
}

function PADS_LEFT(built: number) {
  return built < 4;
}

function CodexPanel() {
  const sim = getSim();
  return (
    <ul className="codex">
      {SPECIES_LIST.map((spec) => {
        const caught = sim.discovered.includes(spec.id as SpeciesId);
        const seen = sim.seen.includes(spec.id);
        const Icon = ICONS[spec.element];
        return (
          <li key={spec.id} className={caught ? "seen" : "unknown"}>
            <Icon size={16} />
            <div>
              <strong>{seen || caught ? spec.name : "Unknown"}</strong>
              <p>{caught ? spec.blurb : seen ? "Seen in the meadow. Not caught." : "Still out there."}</p>
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function HelpPanel() {
  return (
    <div className="help">
      <p>Walk the meadow, weaken a Palmon, then throw a Palorb. Low health catches more easily.</p>
      <p>Ribboned trees, rocks, and bushes are yours to gather. The campfire cooks 3 berries into a Palorb. H eats a berry.</p>
      <p>Build a station and assign a Palmon. A matching element works twice as fast. Two of a kind can merge.</p>
      <p>Keyboard: W A S D move, A is left, D is right. Space attack, F Palorb, E use, Z X orbit, C camera follow. Right-drag looks around.</p>
      <p>The view is a wide PC frame. If you hold the phone upright, the whole meadow turns to stay landscape.</p>
      <button type="button" className="btn-ghost" onClick={() => { saveSim(); backToTitle(); }}>
        Save and leave
      </button>
    </div>
  );
}

export function Hud() {
  const rev = useHud((s) => s.rev);
  const menu = useHud((s) => s.menu);
  const coarse = useCoarse();
  const [mute, setMute] = useState(false);
  void rev;
  const sim = getSim();
  useEffect(() => {
    setMute(isMuted());
  }, []);
  if (sim.mode === "title") return <TitleCard />;

  const quest = currentQuestOf(sim);
  const target = sim.pals.find((p) => p.id === sim.targetId && p.alive);
  const day = daylight(sim.day);
  const active = sim.pals.find((p) => p.alive && !p.wild && p.active);
  const hurt = sim.player.hp < sim.player.maxHp * 0.35;

  return (
    <>
      <div className={hurt ? "vignette vignette-hurt" : "vignette"} />
      <header className="topbar">
        <div className="who">
          <span className="badge" aria-hidden>
            {active ? <ElementIcon element={SPECIES[active.species].element} /> : <Heart size={16} />}
          </span>
          <div>
            <strong>Keeper</strong>
            <Bar value={sim.player.hp} max={sim.player.maxHp} />
          </div>
        </div>
        <div className="quest">
          <span>{quest ? quest.title : "Meadow at peace"}</span>
          <small>{quest ? quest.detail : "Merge, wander, or wait for dusk."}</small>
        </div>
        <div className="resources">
          <Chip icon={Trees} value={sim.resources.wood} label="Wood" />
          <Chip icon={Mountain} value={sim.resources.stone} label="Stone" />
          <Chip icon={Cherry} value={sim.resources.berry} label="Berries" />
          <Chip icon={Disc} value={sim.resources.orb} label="Palorbs" />
          <span className="hud-chip clock">
            {day > 0.35 ? <Sun size={16} /> : <Moon size={16} />}
            <b>{clockLabel(sim.day)}</b>
          </span>
        </div>
      </header>

      {sim.time < sim.toastUntil && sim.toast ? <p className="toast">{sim.toast}</p> : null}
      {sim.time < sim.lineUntil && sim.line ? <p className="line">{sim.line}</p> : null}

      <footer className="bottombar">
        <div className="party">
          {sim.pals
            .filter((p) => p.alive && !p.wild)
            .slice(0, 6)
            .map((p) => (
              <button
                key={p.id}
                type="button"
                className={p.active ? "mini on" : "mini"}
                onClick={() => setActive(p.id)}
                aria-label={SPECIES[p.species].name}
              >
                <ElementIcon element={SPECIES[p.species].element} />
                <small>{p.level}</small>
              </button>
            ))}
        </div>
        <div className="prompt">{sim.prompt ? <span>{coarse ? "Use" : "E"} · {sim.prompt}</span> : <span className="hint">{coarse ? "Stick to walk" : "Right-drag to look · C follow cam"}</span>}</div>
        {target ? (
          <div className="target">
            <strong>{SPECIES[target.species].name}</strong>
            <Bar value={target.hp} max={target.maxHp} />
            <small>Palorb {Math.round(catchChance(target) * 100)}%</small>
          </div>
        ) : (
          <Minimap />
        )}
      </footer>

      <div className="dock">
        <button type="button" className="icon-btn" aria-label={mute ? "Unmute" : "Mute"} onClick={() => {
          const next = !isMuted();
          setMuted(next);
          setMute(next);
          if (!next) {
            unlockAudio();
            sfx("ui");
          }
        }}>
          {mute ? <VolumeX size={18} /> : <Volume2 size={18} />}
        </button>
        <button type="button" className="icon-btn" aria-label="Eat berry" onClick={() => eatBerry()}>
          <Heart size={18} />
        </button>
        <MenuButton id="party" label="Party" icon={Sparkles} />
        <MenuButton id="build" label="Build" icon={Hammer} />
        <MenuButton id="codex" label="Codex" icon={BookOpen} />
        <MenuButton id="help" label="Help" icon={RotateCw} />
      </div>

      {coarse ? (
        <>
          <Joystick />
          <div className="actions">
            <HoldButton label="Attack" field="attack">
              <Sword size={20} />
            </HoldButton>
            <HoldButton label="Palorb" field="orb">
              <Disc size={20} />
            </HoldButton>
            <HoldButton label="Use" field="use">
              <Hand size={20} />
            </HoldButton>
          </div>
        </>
      ) : null}

      {menu ? (
        <Panel title={menu === "party" ? "Palmons" : menu === "build" ? "Build" : menu === "codex" ? "Codex" : "How the meadow works"} onClose={() => openMenu(null)}>
          {menu === "party" ? <PartyPanel /> : null}
          {menu === "build" ? <BuildPanel /> : null}
          {menu === "codex" ? <CodexPanel /> : null}
          {menu === "help" ? <HelpPanel /> : null}
        </Panel>
      ) : null}
    </>
  );
}

function ElementIcon({ element }: { element: Element }) {
  const Icon = ICONS[element];
  return <Icon size={16} />;
}
