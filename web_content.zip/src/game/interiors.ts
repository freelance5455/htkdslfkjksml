// Interior spaces: the luxury villa the player spawns in, plus enterable
// shops / station / mall / garage. Interiors live far from the city so they
// never intersect the exterior world, and are shown by swapping the world out.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { woodTexture, tileTexture } from './textures';
import { makeRng, rand } from './util';

export interface Interior {
  id: string;
  group: THREE.Group;
  colliders: { minX: number; maxX: number; minZ: number; maxZ: number; top: number }[];
  spawn: THREE.Vector3;
  exit: THREE.Vector3;
  lights: THREE.PointLight[];
  /** world position the player returns to when leaving */
  returnTo: THREE.Vector3;
  shopItems?: { id: string; label: string; price: number; kind: string }[];
  kind: string;
}

const M = {
  wall: () => new THREE.MeshStandardMaterial({ color: 0xe6e0d5, roughness: 0.92 }),
  wallAccent: () => new THREE.MeshStandardMaterial({ color: 0xcfc6b6, roughness: 0.9 }),
  darkWall: () => new THREE.MeshStandardMaterial({ color: 0x3b3f46, roughness: 0.9 }),
  wood: () => new THREE.MeshStandardMaterial({ map: woodTexture('#6d4a2c', 5), roughness: 0.6 }),
  woodDark: () => new THREE.MeshStandardMaterial({ map: woodTexture('#4a3020', 4), roughness: 0.55 }),
  marble: () => new THREE.MeshStandardMaterial({ color: 0xe9e7e1, roughness: 0.18, metalness: 0.08 }),
  metal: () => new THREE.MeshStandardMaterial({ color: 0xb9bec6, roughness: 0.25, metalness: 0.92 }),
  darkMetal: () => new THREE.MeshStandardMaterial({ color: 0x2a2d31, roughness: 0.45, metalness: 0.7 }),
  fabric: () => new THREE.MeshStandardMaterial({ color: 0x54606e, roughness: 0.95 }),
  fabricWarm: () => new THREE.MeshStandardMaterial({ color: 0x8a6a4d, roughness: 0.95 }),
  leather: () => new THREE.MeshStandardMaterial({ color: 0x3a2e26, roughness: 0.55 }),
  glass: () =>
    new THREE.MeshStandardMaterial({
      color: 0xa8d4e8,
      roughness: 0.05,
      metalness: 0.6,
      transparent: true,
      opacity: 0.28,
    }),
  plant: () => new THREE.MeshStandardMaterial({ color: 0x2f6b32, roughness: 0.9 }),
  pot: () => new THREE.MeshStandardMaterial({ color: 0x9c6b4a, roughness: 0.8 }),
  lamp: () =>
    new THREE.MeshStandardMaterial({
      color: 0xfff3d6,
      emissive: 0xffdda0,
      emissiveIntensity: 1.4,
      roughness: 0.4,
    }),
  screen: () =>
    new THREE.MeshStandardMaterial({
      color: 0x0a0d12,
      emissive: 0x1a3a5c,
      emissiveIntensity: 0.6,
      roughness: 0.2,
    }),
};

function box(
  parent: THREE.Object3D,
  w: number,
  h: number,
  d: number,
  x: number,
  y: number,
  z: number,
  mat: THREE.Material,
  rot = 0
) {
  const m = new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 2, Math.min(0.06, Math.min(w, h, d) / 2.2)), mat);
  m.position.set(x, y, z);
  m.rotation.y = rot;
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

function cyl(
  parent: THREE.Object3D,
  r1: number,
  r2: number,
  h: number,
  x: number,
  y: number,
  z: number,
  mat: THREE.Material,
  seg = 14
) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, h, seg), mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

function plant(parent: THREE.Object3D, x: number, z: number, scale = 1) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.scale.setScalar(scale);
  cyl(g, 0.24, 0.18, 0.42, 0, 0.21, 0, M.pot());
  cyl(g, 0.05, 0.07, 0.9, 0, 0.85, 0, M.woodDark());
  for (let i = 0; i < 7; i++) {
    const a = (i / 7) * Math.PI * 2;
    const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.34, 8, 6), M.plant());
    leaf.scale.set(1, 0.42, 0.7);
    leaf.position.set(Math.cos(a) * 0.26, 1.1 + Math.sin(i) * 0.16, Math.sin(a) * 0.26);
    leaf.rotation.y = a;
    leaf.castShadow = true;
    g.add(leaf);
  }
  parent.add(g);
}

function rug(parent: THREE.Object3D, w: number, d: number, x: number, z: number, color = 0x6d5642) {
  const m = new THREE.Mesh(
    new THREE.BoxGeometry(w, 0.03, d),
    new THREE.MeshStandardMaterial({ color, roughness: 0.98 })
  );
  m.position.set(x, 0.16, z);
  m.receiveShadow = true;
  parent.add(m);
}

function ceilingLight(parent: THREE.Object3D, x: number, z: number, y = 2.9, intensity = 1) {
  const shade = new THREE.Mesh(
    new THREE.CylinderGeometry(0.28, 0.34, 0.22, 14),
    M.lamp()
  );
  shade.position.set(x, y, z);
  parent.add(shade);
  const l = new THREE.PointLight(0xffd9a8, intensity * 6, 12, 2);
  l.position.set(x, y - 0.15, z);
  parent.add(l);
  return l;
}

/** Luxury villa interior: living room, kitchen, dining, 2 bedrooms, bathroom. */
export function buildLuxuryHouse(): Interior {
  const group = new THREE.Group();
  const colliders: Interior['colliders'] = [];
  const lights: THREE.PointLight[] = [];

  const W = 22;
  const D = 18;
  const H = 3.1;

  // floor
  const floorMat = new THREE.MeshStandardMaterial({
    map: woodTexture('#7d5735', 8),
    roughness: 0.42,
    metalness: 0.05,
  });
  (floorMat.map as THREE.Texture).repeat.set(6, 5);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(W, D), floorMat);
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = 0.15;
  floor.receiveShadow = true;
  group.add(floor);

  // outer walls (door gap on +z side)
  const wallM = M.wall();
  const t = 0.3;
  const wall = (w: number, h: number, d: number, x: number, z: number) =>
    box(group, w, h, d, x, h / 2 + 0.15, z, wallM);
  wall(W, H, t, 0, -D / 2);
  wall(t, H, D, -W / 2, 0);
  wall(t, H, D, W / 2, 0);
  wall(W / 2 - 1.4, H, t, -W / 4 - 0.7, D / 2);
  wall(W / 2 - 1.4, H, t, W / 4 + 0.7, D / 2);
  box(group, W / 2 - 1.4, 0.5, t, -W / 4 - 0.7, H + 0.15 - 0.25, D / 2, wallM);
  box(group, W / 2 - 1.4, 0.5, t, W / 4 + 0.7, H + 0.15 - 0.25, D / 2, wallM);
  colliders.push(
    { minX: -W / 2 - 0.2, maxX: W / 2 + 0.2, minZ: -D / 2 - 0.2, maxZ: -D / 2 + 0.2, top: H },
    { minX: -W / 2 - 0.2, maxX: -W / 2 + 0.2, minZ: -D / 2, maxZ: D / 2, top: H },
    { minX: W / 2 - 0.2, maxX: W / 2 + 0.2, minZ: -D / 2, maxZ: D / 2, top: H }
  );
  colliders.push(
    { minX: -W / 2, maxX: -1.4, minZ: D / 2 - 0.2, maxZ: D / 2 + 0.2, top: H },
    { minX: 1.4, maxX: W / 2, minZ: D / 2 - 0.2, maxZ: D / 2 + 0.2, top: H }
  );

  // interior partitions: living | kitchen (left), hall, bedrooms (right)
  const p1 = box(group, t, H, 9.5, -1.2, H / 2 + 0.15, -4.2, wallM);
  void p1;
  box(group, t, H, 6.2, -1.2, H / 2 + 0.15, 5.6, wallM);
  box(group, 12.4, H, t, 4.9, H / 2 + 0.15, -1.4, wallM);
  colliders.push(
    { minX: -1.35, maxX: -1.05, minZ: -8.95, maxZ: -0.7, top: H },
    { minX: -1.35, maxX: -1.05, minZ: 2.5, maxZ: 8.7, top: H },
    { minX: -1.3, maxX: 11.1, minZ: -1.55, maxZ: -1.25, top: H }
  );

  // big windows on the -z wall (living) and +x wall (bedroom)
  const glassM = M.glass();
  box(group, 9, 2.1, 0.08, -6.2, 1.5, -D / 2 + 0.06, glassM);
  box(group, 0.08, 2.1, 6.5, W / 2 - 0.06, 1.5, 3.2, glassM);
  box(group, 5.4, 2.1, 0.08, 6.2, 1.5, -D / 2 + 0.06, glassM);

  // --- living room ---
  const living = new THREE.Group();
  group.add(living);
  rug(living, 6.4, 4.6, -6.4, -4.6, 0x6a5847);
  // sofa
  const sofa = new THREE.Group();
  sofa.position.set(-6.4, 0, -6.6);
  sofa.rotation.y = 0;
  box(sofa, 3.4, 0.42, 1.05, 0, 0.42, 0, M.fabric());
  box(sofa, 3.4, 0.8, 0.28, 0, 0.85, -0.42, M.fabric());
  box(sofa, 0.3, 0.55, 1.05, -1.6, 0.62, 0, M.fabric());
  box(sofa, 0.3, 0.55, 1.05, 1.6, 0.62, 0, M.fabric());
  [-1.1, 0, 1.1].forEach((cx) => {
    const cush = new THREE.Mesh(new THREE.CapsuleGeometry(0.16, 0.6, 3, 8), M.fabricWarm());
    cush.rotation.z = Math.PI / 2;
    cush.position.set(cx, 0.78, 0.1);
    cush.castShadow = true;
    sofa.add(cush);
  });
  living.add(sofa);
  // coffee table
  box(living, 1.9, 0.09, 1.0, -6.4, 0.6, -4.6, M.marble());
  [-0.8, 0.8].forEach((dx) =>
    [-0.4, 0.4].forEach((dz) =>
      cyl(living, 0.05, 0.05, 0.45, -6.4 + dx, 0.38, -4.6 + dz, M.metal(), 8)
    )
  );
  // TV wall unit
  box(living, 4.2, 0.5, 0.6, -6.2, 0.45, -8.2, M.woodDark());
  box(living, 2.1, 1.2, 0.08, -6.2, 1.75, -8.1, M.screen());
  box(living, 0.4, 0.06, 0.3, -6.2, 1.05, -8.3, M.darkMetal());
  plant(living, -10.2, -8.0, 1.2);
  plant(living, -2.6, -8.0, 0.9);
  // fireplace
  box(living, 2.6, 2.2, 0.35, -10.2, 1.25, -3.6, M.darkWall());
  box(living, 1.6, 1.2, 0.2, -10.2, 0.9, -3.8, M.darkMetal());

  // --- kitchen ---
  const kitchen = new THREE.Group();
  group.add(kitchen);
  const cab = M.wood();
  box(kitchen, 6.4, 0.92, 0.7, -6.2, 0.61, -7.5, cab);
  box(kitchen, 6.4, 0.06, 0.76, -6.2, 1.1, -7.5, M.marble());
  box(kitchen, 3.2, 0.9, 0.68, -6.4, 2.15, -8.2, cab);
  box(kitchen, 2.0, 0.12, 1.9, -6.4, 1.15, 1.6, M.marble());
  box(kitchen, 1.9, 0.85, 1.8, -6.4, 0.58, 1.6, cab);
  cyl(kitchen, 0.24, 0.24, 0.04, -6.4, 1.23, 1.6, M.darkMetal());
  cyl(kitchen, 0.05, 0.05, 0.3, -6.4, 1.35, 1.6, M.metal(), 8);
  // fridge + stove
  box(kitchen, 1.0, 2.1, 0.8, -10.1, 1.2, 4.0, M.metal());
  box(kitchen, 0.9, 0.05, 0.5, -7.0, 1.15, -7.5, M.darkMetal());
  for (let i = 0; i < 4; i++) {
    const burner = cyl(kitchen, 0.14, 0.14, 0.03, -7.32 + (i % 2) * 0.62, 1.19, -7.75 + Math.floor(i / 2) * 0.5, M.darkMetal(), 10);
    void burner;
  }
  // hood
  box(kitchen, 1.4, 0.5, 0.8, -7.0, 2.6, -7.8, M.metal());
  // bar stools
  [-7.6, -5.2].forEach((sx) => {
    cyl(kitchen, 0.06, 0.06, 0.75, sx, 0.55, 2.7, M.metal(), 8);
    cyl(kitchen, 0.22, 0.22, 0.08, sx, 0.95, 2.7, M.leather(), 12);
  });
  // dining table
  box(kitchen, 3.0, 0.12, 1.3, -6.6, 0.82, 5.6, M.wood());
  [-7.6, -5.6].forEach((sx) => {
    [-5.2, -0.1].forEach((sz) => {
      box(kitchen, 0.5, 0.08, 0.5, sx, 0.5, sz, M.woodDark());
      box(kitchen, 0.5, 0.55, 0.08, sx, 0.8, sz + 0.22, M.woodDark());
      [-0.2, 0.2].forEach((dx) =>
        box(kitchen, 0.06, 0.45, 0.06, sx + dx, 0.24, sz, M.darkMetal())
      );
    });
  });
  cyl(kitchen, 0.12, 0.2, 0.4, -6.6, 1.08, 5.6, M.metal(), 12);

  // --- master bedroom ---
  const bed = new THREE.Group();
  bed.position.set(6.6, 0, -5.4);
  group.add(bed);
  box(bed, 2.3, 0.45, 2.5, 0, 0.38, 0, M.woodDark());
  const mattress = box(bed, 2.1, 0.32, 2.3, 0, 0.72, 0, M.fabric());
  void mattress;
  box(bed, 2.15, 0.14, 1.5, 0, 0.94, 0.35, M.fabricWarm());
  box(bed, 2.3, 1.5, 0.16, 0, 1.0, -1.3, M.leather());
  [-0.55, 0.55].forEach((sx) => {
    const p = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 0.5, 4, 10), M.marble());
    p.rotation.z = Math.PI / 2;
    p.position.set(sx, 1.05, -0.85);
    p.castShadow = true;
    bed.add(p);
  });
  [-1.55, 1.55].forEach((sx) => {
    box(bed, 0.6, 0.55, 0.6, sx, 0.42, -1.0, M.woodDark());
    cyl(bed, 0.03, 0.03, 0.35, sx, 0.85, -1.0, M.darkMetal(), 6);
    const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.2, 0.24, 12), M.lamp());
    shade.position.set(sx, 1.12, -1.0);
    bed.add(shade);
    const pl = new THREE.PointLight(0xffd9a0, 2.2, 6, 2);
    pl.position.set(sx, 1.1, -1.0);
    bed.add(pl);
    lights.push(pl);
  });
  // wardrobe
  box(group, 3.0, 2.4, 0.7, 9.6, 1.35, -8.2, M.woodDark());
  // desk
  box(group, 2.2, 0.08, 0.8, 9.2, 0.85, -2.6, M.wood());
  box(group, 0.08, 0.8, 0.7, 10.2, 0.5, -2.6, M.darkMetal());
  box(group, 0.9, 0.55, 0.06, 9.2, 1.2, -2.9, M.screen());
  const chair = new THREE.Group();
  chair.position.set(9.2, 0, -3.5);
  box(chair, 0.6, 0.1, 0.6, 0, 0.5, 0, M.leather());
  box(chair, 0.6, 0.7, 0.1, 0, 0.85, 0.26, M.leather());
  cyl(chair, 0.06, 0.06, 0.45, 0, 0.24, 0, M.darkMetal(), 8);
  group.add(chair);

  // --- second bedroom ---
  box(group, 1.6, 0.42, 2.1, 3.6, 0.36, 5.4, M.woodDark());
  box(group, 1.5, 0.26, 2.0, 3.6, 0.66, 5.4, M.fabric());
  box(group, 1.55, 0.12, 1.2, 3.6, 0.84, 5.8, M.fabricWarm());
  box(group, 1.6, 1.1, 0.12, 3.6, 0.85, 4.3, M.woodDark());
  box(group, 1.2, 1.8, 0.6, 9.8, 1.05, 5.6, M.woodDark());
  plant(group, 2.0, 8.0, 1.0);

  // --- bathroom ---
  const bath = new THREE.Group();
  group.add(bath);
  const tileMat = new THREE.MeshStandardMaterial({
    map: tileTexture('#dfe6e8', '#aab5b8', 6),
    roughness: 0.35,
  });
  box(bath, 3.4, 0.04, 3.2, 7.4, 0.17, 0.6, tileMat);
  box(bath, 1.8, 0.6, 0.85, 6.6, 0.5, 0.6, M.marble());
  cyl(bath, 0.3, 0.3, 0.05, 6.6, 0.82, 0.6, M.metal(), 14);
  cyl(bath, 0.04, 0.04, 0.25, 6.6, 0.95, 0.95, M.metal(), 8);
  box(bath, 0.9, 0.9, 0.55, 9.3, 0.6, 0.9, M.marble());
  cyl(bath, 0.2, 0.16, 0.35, 9.3, 1.22, 0.9, M.marble(), 14);
  box(bath, 1.3, 1.0, 0.06, 9.3, 1.65, 1.25, M.glass());
  // toilet
  cyl(bath, 0.26, 0.22, 0.4, 8.6, 0.4, 2.3, M.marble(), 12);
  box(bath, 0.55, 0.42, 0.22, 8.6, 0.55, 2.6, M.marble());

  // paintings
  const artColors = [0x2b4a6f, 0x6f2b3c, 0x3c6f4a, 0x6f5a2b];
  for (let i = 0; i < 4; i++) {
    const art = new THREE.Mesh(
      new THREE.PlaneGeometry(1.1, 0.8),
      new THREE.MeshStandardMaterial({ color: artColors[i % 4], roughness: 0.9 })
    );
    art.position.set(-1.03, 1.9, -6 + i * 2.4);
    art.rotation.y = Math.PI / 2;
    group.add(art);
  }

  // ceiling
  const ceil = new THREE.Mesh(
    new THREE.PlaneGeometry(W, D),
    new THREE.MeshStandardMaterial({ color: 0xf2eee6, roughness: 0.95 })
  );
  ceil.rotation.x = Math.PI / 2;
  ceil.position.y = H + 0.15;
  ceil.castShadow = true;
  ceil.receiveShadow = true;
  group.add(ceil);

  lights.push(ceilingLight(group, -6.4, -4.4, H - 0.1, 1.2));
  lights.push(ceilingLight(group, -6.4, 4.2, H - 0.1, 1.0));
  lights.push(ceilingLight(group, 6.4, -4.4, H - 0.1, 0.9));
  lights.push(ceilingLight(group, 6.4, 4.4, H - 0.1, 0.9));
  lights.push(ceilingLight(group, 0.4, 0, H - 0.1, 0.7));

  // exit marker near the door
  const exitSign = new THREE.Mesh(
    new THREE.PlaneGeometry(1.6, 0.5),
    new THREE.MeshStandardMaterial({
      color: 0x0f2f18,
      emissive: 0x35d06a,
      emissiveIntensity: 1.2,
    })
  );
  exitSign.position.set(0, 2.5, D / 2 - 0.2);
  exitSign.rotation.y = Math.PI;
  group.add(exitSign);

  return {
    id: 'villa',
    kind: 'villa',
    group,
    colliders,
    spawn: new THREE.Vector3(-6.5, 0.15, -2.5),
    exit: new THREE.Vector3(0, 0.15, D / 2 - 1.2),
    lights,
    returnTo: new THREE.Vector3(-450, 0, -436),
  };
}

/** Generic shop / civic interiors. */
export function buildShopInterior(
  id: string,
  kind: string,
  title: string,
  accent: number
): Interior {
  const group = new THREE.Group();
  const colliders: Interior['colliders'] = [];
  const lights: THREE.PointLight[] = [];
  const rng = makeRng(id.length * 977 + 13);
  const W = kind === 'mall' ? 44 : 18;
  const D = kind === 'mall' ? 34 : 14;
  const H = kind === 'mall' ? 6.5 : 3.4;

  const floorMat = new THREE.MeshStandardMaterial({
    map: tileTexture('#d9d5cc', '#a9a49a', 10),
    roughness: 0.35,
    metalness: 0.05,
  });
  (floorMat.map as THREE.Texture).repeat.set(8, 8);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(W, D), floorMat);
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = 0.05;
  floor.receiveShadow = true;
  group.add(floor);

  const accentMat = new THREE.MeshStandardMaterial({ color: accent, roughness: 0.6 });
  const wallMat = M.wall();
  const mk = (w: number, h: number, d: number, x: number, z: number, mat = wallMat) =>
    box(group, w, h, d, x, h / 2, z, mat);

  mk(W, H, 0.4, 0, -D / 2);
  mk(0.4, H, D, -W / 2, 0);
  mk(0.4, H, D, W / 2, 0);
  mk(W / 2 - 1.5, H, 0.4, -W / 4 - 0.75, D / 2);
  mk(W / 2 - 1.5, H, 0.4, W / 4 + 0.75, D / 2);
  colliders.push(
    { minX: -W / 2 - 0.3, maxX: W / 2 + 0.3, minZ: -D / 2 - 0.3, maxZ: -D / 2 + 0.3, top: H },
    { minX: -W / 2 - 0.3, maxX: -W / 2 + 0.3, minZ: -D / 2, maxZ: D / 2, top: H },
    { minX: W / 2 - 0.3, maxX: W / 2 + 0.3, minZ: -D / 2, maxZ: D / 2, top: H }
  );

  // ceiling
  const ceil = new THREE.Mesh(
    new THREE.PlaneGeometry(W, D),
    new THREE.MeshStandardMaterial({ color: 0xefeee9, roughness: 0.95 })
  );
  ceil.rotation.x = Math.PI / 2;
  ceil.position.y = H;
  ceil.castShadow = true;
  ceil.receiveShadow = true;
  group.add(ceil);

  // shop sign board
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 256;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#14161c';
  ctx.fillRect(0, 0, 1024, 256);
  ctx.fillStyle = '#' + new THREE.Color(accent).getHexString();
  ctx.font = 'bold 92px Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(title, 512, 128);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(Math.min(W * 0.6, 10), 2.2),
    new THREE.MeshStandardMaterial({
      map: tex,
      emissiveMap: tex,
      emissive: 0xffffff,
      emissiveIntensity: 1.2,
    })
  );
  sign.position.set(0, H - 1.4, D / 2 - 0.3);
  sign.rotation.y = Math.PI;
  group.add(sign);

  const shopItems: Interior['shopItems'] = [];

  if (kind === 'phone') {
    box(group, 8, 1.1, 1.0, -4, 0.55, -D / 2 + 0.9, M.woodDark());
    box(group, 8.2, 0.08, 1.2, -4, 1.14, -D / 2 + 0.9, M.marble());
    for (let i = 0; i < 6; i++) {
      const ph = box(group, 0.16, 0.3, 0.02, -7 + i * 1.2, 1.35, -D / 2 + 0.8, M.darkMetal());
      void ph;
      const disp = box(group, 0.3, 0.5, 0.02, -7 + i * 1.2, 1.5, -D / 2 + 0.78, M.screen());
      void disp;
    }
    box(group, 3.2, 2.0, 0.2, 5, 1.2, -D / 2 + 0.3, accentMat);
    for (let i = 0; i < 4; i++) {
      box(group, 0.9, 1.4, 0.9, 4 + i * 1.4, 0.7, 1.5, M.darkMetal());
    }
    shopItems.push(
      { id: 'ammo', label: 'Pistol Ammo x40', price: 120, kind: 'ammo' },
      { id: 'medkit', label: 'Medkit (restore 50 HP)', price: 300, kind: 'food' },
      { id: 'grenade', label: 'Frag Grenade', price: 450, kind: 'weapon' },
      { id: 'smoke', label: 'Smoke Grenade', price: 300, kind: 'weapon' },
      { id: 'sniper', label: 'Vector Sniper', price: 4800, kind: 'weapon' },
      { id: 'rpg', label: 'Skyfire RPG', price: 9000, kind: 'weapon' }
    );
  } else if (kind === 'mod') {
    const lift = new THREE.Group();
    lift.position.set(0, 0, -1);
    group.add(lift);
    box(lift, 6, 0.3, 10, 0, 0.15, 0, M.darkMetal());
    [-2.6, 2.6].forEach((x) => {
      box(lift, 0.4, 4.5, 0.4, x, 2.4, -4.2, M.darkMetal());
      box(lift, 0.4, 4.5, 0.4, x, 2.4, 4.2, M.darkMetal());
    });
    box(lift, 6, 0.4, 0.4, 0, 4.6, -4.2, M.darkMetal());
    box(lift, 6, 0.4, 0.4, 0, 4.6, 4.2, M.darkMetal());
    // toolboxes + tires
    for (let i = 0; i < 5; i++) {
      box(group, 1.4, 1.1, 0.9, -7 + i * 1.6, 0.55, D / 2 - 1.6, accentMat);
    }
    for (let i = 0; i < 6; i++) {
      const t = cyl(group, 0.42, 0.42, 0.28, -7 + i * 0.9, 0.14, 2.5, M.darkMetal(), 14);
      t.rotation.z = Math.PI / 2;
    }
    box(group, 4, 1.1, 1.0, 6, 0.55, -D / 2 + 1, M.woodDark());
    shopItems.push(
      { id: 'paint', label: 'Custom Paint ($400)', price: 400, kind: 'paint' },
      { id: 'engine', label: 'Engine Tune ($1200)', price: 1200, kind: 'engine' },
      { id: 'tires', label: 'Sport Tyres ($600)', price: 600, kind: 'tires' },
      { id: 'plates', label: 'Custom Plate ($250)', price: 250, kind: 'plate' }
    );
  } else if (kind === 'police') {
    // desks, cells, holding area
    for (let i = 0; i < 4; i++) {
      box(group, 3.4, 1.0, 1.2, -6 + i * 4.4, 0.5, -D / 2 + 1.6, M.woodDark());
      box(group, 1.4, 1.2, 0.1, -6 + i * 4.4, 1.5, -D / 2 + 2.1, M.screen());
    }
    const bars: THREE.BufferGeometry[] = [];
    for (let cIdx = 0; cIdx < 4; cIdx++) {
      const cx = -6 + cIdx * 4.4;
      box(group, 0.15, 3.2, 0.15, cx - 1.7, 1.6, D / 2 - 1.6, M.darkMetal());
      box(group, 0.15, 3.2, 0.15, cx + 1.7, 1.6, D / 2 - 1.6, M.darkMetal());
      box(group, 3.4, 0.15, 0.15, cx, 3.1, D / 2 - 1.6, M.darkMetal());
      for (let b = 0; b < 7; b++) {
        const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 3.0, 6), M.darkMetal());
        bar.position.set(cx - 1.5 + b * 0.5, 1.6, D / 2 - 1.6);
        group.add(bar);
      }
      void bars;
    }
    box(group, 6, 3.0, 0.4, 6, 1.5, -D / 2 + 0.2, accentMat);
  } else if (kind === 'mall') {
    // escalators, storefronts, kiosks
    for (let i = 0; i < 6; i++) {
      const sx = -16 + i * 6.4;
      box(group, 4.4, 0.2, 12, sx, 0.12, -4, M.metal());
      for (let s = 0; s < 10; s++) {
        box(group, 4.0, 0.12, 1.0, sx, 0.25 + s * 0.32, -4 - 5 + s * 1.0, M.darkMetal());
      }
      box(group, 0.16, 3.6, 12, sx - 2.1, 1.9, -4, M.glass());
      box(group, 0.16, 3.6, 12, sx + 2.1, 1.9, -4, M.glass());
    }
    const names = ['FASHION', 'ELECTRONICS', 'FOOD HALL', 'CINEMA', 'BOOKS', 'SPORTS'];
    for (let i = 0; i < 6; i++) {
      const sx = -16 + i * 6.4;
      box(group, 5.2, 3.4, 0.3, sx, 1.7, -D / 2 + 0.4, accentMat);
      const nm = names[i % names.length];
      const cc = document.createElement('canvas');
      cc.width = 512;
      cc.height = 128;
      const cx2 = cc.getContext('2d')!;
      cx2.fillStyle = '#' + new THREE.Color(accent).getHexString();
      cx2.fillRect(0, 0, 512, 128);
      cx2.fillStyle = '#101216';
      cx2.font = 'bold 58px Arial';
      cx2.textAlign = 'center';
      cx2.textBaseline = 'middle';
      cx2.fillText(nm, 256, 66);
      const t2 = new THREE.CanvasTexture(cc);
      t2.colorSpace = THREE.SRGBColorSpace;
      const pl = new THREE.Mesh(
        new THREE.PlaneGeometry(4.6, 1.15),
        new THREE.MeshStandardMaterial({ map: t2, emissiveMap: t2, emissive: 0xffffff, emissiveIntensity: 0.8 })
      );
      pl.position.set(sx, 3.6, -D / 2 + 0.6);
      group.add(pl);
    }
    for (let i = 0; i < 8; i++) {
      const kx = rand(rng, -W / 2 + 4, W / 2 - 4);
      const kz = rand(rng, 2, D / 2 - 4);
      box(group, 3.2, 1.1, 2.0, kx, 0.55, kz, M.woodDark());
      box(group, 3.4, 0.1, 2.2, kx, 1.15, kz, accentMat);
    }
    for (let i = 0; i < 10; i++) {
      box(group, 2.4, 0.5, 0.7, rand(rng, -W / 2 + 3, W / 2 - 3), 0.45, rand(rng, 0, D / 2 - 3), M.woodDark());
    }
  } else {
    // generic store: shelves, counter
    for (let i = 0; i < 4; i++) {
      box(group, 4.2, 2.2, 0.6, -W / 2 + 2.6, 1.1, -D / 2 + 3 + i * 3.4, M.woodDark());
      for (let s = 0; s < 3; s++) {
        box(group, 4.0, 0.08, 0.55, -W / 2 + 2.6, 0.6 + s * 0.65, -D / 2 + 3 + i * 3.4, M.metal());
      }
    }
    box(group, 5, 1.1, 1.1, 4, 0.55, 2, M.woodDark());
    box(group, 5.2, 0.08, 1.3, 4, 1.14, 2, M.marble());
  }

  // exit sign
  const exitSign = new THREE.Mesh(
    new THREE.PlaneGeometry(1.6, 0.5),
    new THREE.MeshStandardMaterial({ color: 0x0f2f18, emissive: 0x35d06a, emissiveIntensity: 1.4 })
  );
  exitSign.position.set(0, H - 0.9, D / 2 - 0.25);
  exitSign.rotation.y = Math.PI;
  group.add(exitSign);

  lights.push(ceilingLight(group, -W / 4, -D / 4, H - 0.3, 1.1));
  lights.push(ceilingLight(group, W / 4, -D / 4, H - 0.3, 1.1));
  lights.push(ceilingLight(group, -W / 4, D / 4, H - 0.3, 1.1));
  lights.push(ceilingLight(group, W / 4, D / 4, H - 0.3, 1.1));

  return {
    id,
    kind,
    group,
    colliders,
    spawn: new THREE.Vector3(0, 0.05, D / 2 - 3),
    exit: new THREE.Vector3(0, 0.05, D / 2 - 1.4),
    lights,
    returnTo: new THREE.Vector3(),
    shopItems,
  };
}
