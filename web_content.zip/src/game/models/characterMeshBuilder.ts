/**
 * SPR - Sahil Powerful Run
 * 3D Character Mesh Builder for all 15 Playable Characters
 * Faithfully crafts 3D meshes matching the reference photos:
 * 1: Street Legend (Olive bomber, sherpa hood, afro, baggy cargo, tactical boots)
 * 2: Urban Tech (Orange/brown hoodie, white collar, parted hair, rectangular glasses, goatee)
 * 3: Track Prodigy (White/crimson track jacket, quiff, smartwatch, grey joggers, runners)
 * 4: Nomad Explorer (Camel varsity, messy brown hair, explorer backpack, white high-tops)
 * 5: Neon Tangerine (Tangerine bomber, peace patch, curly locks, silver earrings, orange stripe)
 * 6: Hip-Hop Superstar (Cyan puffer, gold chains/medallion, teal sunglasses, high-fade)
 * 7: Cognac Suede (Cognac suede jacket, leather collar, bald head, goatee stubble)
 * 8: Midnight Shadow (Black beanie, stubble, espresso track jacket with dual white stripes)
 * 9: Tactical Operative (Leather trench, hooded cowl, respirator mask, combat gloves, knee armor)
 * 10: Academy Sprinter (Sky blue polo, messy spiky hair, chino shorts, school backpack, wristbands)
 * 11: Pro Athletic Coach (Split grey/orange hoodie, pompadour, full beard, glasses, compression tights)
 * 12: Cozy Tech Genius (Golden cowl turtleneck, asymmetrical white sleeve, round glasses, cyan pants)
 * 13: Noble Cyber Prince (Regal turquoise vest with gold filigree, braided hawk, pearl earrings)
 * 14: Gesioh Gladiator (Red tank, anime hair, steel pauldron, cyber power gauntlet, martial pants)
 * 15: Gesioh Supreme Champion (Cyan energy hair, arc reactor chest, gold pauldron, twin cyber gauntlets)
 */

import * as THREE from 'three';
import { CharacterDef } from '../constants/characters';
import { textureGenerator } from '../utils/TextureGenerator';

export interface CharacterRig {
  group: THREE.Group;
  characterDef: CharacterDef;
  hips: THREE.Group;
  spine: THREE.Group;
  chest: THREE.Mesh;
  headGroup: THREE.Group;
  leftUpperArm: THREE.Group;
  leftForearm: THREE.Group;
  rightUpperArm: THREE.Group;
  rightForearm: THREE.Group;
  leftThigh: THREE.Group;
  leftShin: THREE.Group;
  rightThigh: THREE.Group;
  rightShin: THREE.Group;
  sprayCanGroup: THREE.Group | null;
  jetpackFireLeft: THREE.Mesh | null;
  jetpackFireRight: THREE.Mesh | null;
  auraMesh: THREE.Mesh | null;
}

export function buildCharacter3DModel(rig: CharacterRig): void {
  const { colorScheme, features } = rig.characterDef;

  // --- BASE MATERIALS ---
  const matSkin = new THREE.MeshStandardMaterial({
    color: colorScheme.skin,
    roughness: 0.72,
    metalness: 0.05,
  });

  const matHair = new THREE.MeshStandardMaterial({
    color: colorScheme.hair,
    roughness: 0.85,
    metalness: 0.08,
  });

  const matVest = new THREE.MeshStandardMaterial({
    color: colorScheme.vest,
    roughness: 0.55,
    metalness: 0.15,
  });

  const matSecondary = new THREE.MeshStandardMaterial({
    color: colorScheme.jacketSecondary || colorScheme.vest,
    roughness: 0.6,
    metalness: 0.1,
  });

  const matHoodie = new THREE.MeshStandardMaterial({
    color: colorScheme.hoodie,
    roughness: 0.8,
    metalness: 0.05,
  });

  const matPants = new THREE.MeshStandardMaterial({
    color: colorScheme.pants,
    roughness: 0.7,
    metalness: 0.08,
  });

  const matShoes = new THREE.MeshStandardMaterial({
    color: colorScheme.shoes,
    roughness: 0.45,
    metalness: 0.18,
  });

  const matSoleGlow = new THREE.MeshBasicMaterial({
    color: colorScheme.soleGlow,
  });

  const matGold = new THREE.MeshStandardMaterial({
    color: colorScheme.gold,
    roughness: 0.25,
    metalness: 0.9,
  });

  const matAccent = new THREE.MeshStandardMaterial({
    color: colorScheme.accent || colorScheme.gold,
    roughness: 0.35,
    metalness: 0.4,
  });

  // ====================================================
  // 1. ROOT HIPS & WAIST
  // ====================================================
  rig.hips = new THREE.Group();
  rig.hips.position.set(0, 1.05, 0);
  rig.group.add(rig.hips);

  const pelvisGeo = new THREE.BoxGeometry(0.52, 0.26, 0.36);
  const pelvisMesh = new THREE.Mesh(pelvisGeo, matPants);
  pelvisMesh.castShadow = true;
  rig.hips.add(pelvisMesh);

  // Character-specific waist belts and sashes
  if (features.outfitStyle === 'gladiator-tank' || features.outfitStyle === 'champion-tank') {
    // Cyber Gladiator / Champion Sash Belt
    const sashGeo = new THREE.CylinderGeometry(0.32, 0.32, 0.12, 14);
    const matSash = new THREE.MeshStandardMaterial({
      color: colorScheme.accent || 0x06b6d4,
      roughness: 0.5,
    });
    const sashMesh = new THREE.Mesh(sashGeo, matSash);
    sashMesh.position.set(0, 0.02, 0);
    rig.hips.add(sashMesh);

    // Round Medallion Buckle
    const buckleGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.04, 12);
    buckleGeo.rotateX(Math.PI / 2);
    const buckleMesh = new THREE.Mesh(buckleGeo, matGold);
    buckleMesh.position.set(0, 0.02, 0.20);
    rig.hips.add(buckleMesh);

    // Hanging sash tails on left hip
    const tailGeo = new THREE.BoxGeometry(0.12, 0.35, 0.04);
    const tailMesh = new THREE.Mesh(tailGeo, matSash);
    tailMesh.position.set(-0.24, -0.15, 0.14);
    tailMesh.rotation.z = 0.15;
    rig.hips.add(tailMesh);
  } else {
    // Standard tactical / casual belt
    const beltGeo = new THREE.BoxGeometry(0.54, 0.07, 0.38);
    const beltMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.4 });
    const beltMesh = new THREE.Mesh(beltGeo, beltMat);
    rig.hips.add(beltMesh);

    const buckleGeo = new THREE.BoxGeometry(0.14, 0.09, 0.40);
    const buckleMesh = new THREE.Mesh(buckleGeo, matGold);
    rig.hips.add(buckleMesh);
  }

  // Crossbody Hip Pouch
  if (features.hasHipPouch) {
    const pouchGroup = new THREE.Group();
    pouchGroup.position.set(0.24, -0.05, 0.16);
    pouchGroup.rotation.y = -0.35;

    const bagGeo = new THREE.BoxGeometry(0.24, 0.16, 0.14);
    const bagMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.6 });
    const bagMesh = new THREE.Mesh(bagGeo, bagMat);
    pouchGroup.add(bagMesh);

    const strapGeo = new THREE.BoxGeometry(0.26, 0.03, 0.04);
    const strapMat = new THREE.MeshBasicMaterial({ color: colorScheme.soleGlow });
    const strapMesh = new THREE.Mesh(strapGeo, strapMat);
    strapMesh.position.set(0, 0.04, 0.06);
    pouchGroup.add(strapMesh);

    rig.hips.add(pouchGroup);
  }

  // ====================================================
  // 2. SPINE & TORSO (JACKET, HOODIE, TANK, SWEATER)
  // ====================================================
  rig.spine = new THREE.Group();
  rig.spine.position.set(0, 0.14, 0);
  rig.hips.add(rig.spine);

  // Inner Torso
  const innerTorsoGeo = new THREE.BoxGeometry(0.64, 0.58, 0.42);
  const innerTorsoMesh = new THREE.Mesh(innerTorsoGeo, matHoodie);
  innerTorsoMesh.position.set(0, 0.32, 0);
  innerTorsoMesh.castShadow = true;
  rig.spine.add(innerTorsoMesh);

  // Outer Vest / Bomber / Jacket Layer
  const vestGeo = new THREE.BoxGeometry(0.68, 0.56, 0.46);

  // Apply custom procedural textures to chest depending on character
  let chestMaterial: THREE.Material | THREE.Material[] = matVest;

  if (features.chestEmblem === 'peace-white') {
    const peaceMat = new THREE.MeshStandardMaterial({
      map: textureGenerator.getPeaceSignPatchTexture('#ffffff'),
      roughness: 0.6,
    });
    chestMaterial = [matVest, matVest, matVest, matVest, peaceMat, matVest];
  } else if (features.chestEmblem === 'peace-orange') {
    const peaceMat = new THREE.MeshStandardMaterial({
      map: textureGenerator.getPeaceSignPatchTexture('#f97316'),
      roughness: 0.6,
    });
    chestMaterial = [matVest, matVest, matVest, matVest, peaceMat, matVest];
  } else if (features.outfitStyle === 'puffer-jacket') {
    const pufferMat = new THREE.MeshStandardMaterial({
      map: textureGenerator.getPufferWithGoldChainTexture(),
      roughness: 0.5,
    });
    chestMaterial = [matVest, matVest, matVest, matVest, pufferMat, matVest];
  } else if (features.outfitStyle === 'tactical-trench') {
    const tacticalMat = new THREE.MeshStandardMaterial({
      map: textureGenerator.getTacticalHarnessTexture(),
      roughness: 0.65,
    });
    chestMaterial = [matVest, matVest, matVest, matVest, tacticalMat, matVest];
  } else if (features.outfitStyle === 'regal-vest') {
    const regalMat = new THREE.MeshStandardMaterial({
      map: textureGenerator.getRegalFiligreeTexture(),
      roughness: 0.45,
    });
    chestMaterial = [matVest, matVest, matVest, matVest, regalMat, matVest];
  }

  rig.chest = new THREE.Mesh(vestGeo, chestMaterial);
  rig.chest.position.set(0, 0.33, 0);
  rig.chest.castShadow = true;
  rig.spine.add(rig.chest);

  // OUTFIT-SPECIFIC DETAILS
  if (features.outfitStyle === 'olive-bomber') {
    // Sherpa fleece lined collar & orange pull toggles
    const fleeceCollarGeo = new THREE.CylinderGeometry(0.26, 0.28, 0.16, 12);
    const fleeceCollar = new THREE.Mesh(fleeceCollarGeo, matSecondary);
    fleeceCollar.position.set(0, 0.64, 0);
    rig.spine.add(fleeceCollar);

    // Hanging orange drawstring cords
    for (let d = -1; d <= 1; d += 2) {
      const cordGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.22, 6);
      const cordMat = new THREE.MeshBasicMaterial({ color: 0xf97316 });
      const cordMesh = new THREE.Mesh(cordGeo, cordMat);
      cordMesh.position.set(d * 0.10, 0.46, 0.24);
      rig.spine.add(cordMesh);
    }
  } else if (features.outfitStyle === 'orange-hoodie') {
    // White shirt collar peeking out + white hem peeking out at bottom
    const whiteCollarGeo = new THREE.BoxGeometry(0.32, 0.06, 0.36);
    const matWhite = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.7 });
    const whiteCollar = new THREE.Mesh(whiteCollarGeo, matWhite);
    whiteCollar.position.set(0, 0.64, 0.04);
    rig.spine.add(whiteCollar);

    // Hem peeking out
    const whiteHemGeo = new THREE.BoxGeometry(0.66, 0.06, 0.44);
    const whiteHem = new THREE.Mesh(whiteHemGeo, matWhite);
    whiteHem.position.set(0, 0.04, 0);
    rig.spine.add(whiteHem);
  } else if (features.outfitStyle === 'polo-shirt') {
    // Polo turned-down collar & placket
    const poloCollarGeo = new THREE.BoxGeometry(0.34, 0.06, 0.36);
    const poloCollar = new THREE.Mesh(poloCollarGeo, matSecondary);
    poloCollar.position.set(0, 0.63, 0.03);
    rig.spine.add(poloCollar);

    const placketGeo = new THREE.BoxGeometry(0.06, 0.22, 0.02);
    const matPlacket = new THREE.MeshStandardMaterial({ color: 0xffffff });
    const placketMesh = new THREE.Mesh(placketGeo, matPlacket);
    placketMesh.position.set(0, 0.50, 0.24);
    rig.spine.add(placketMesh);
  } else if (features.outfitStyle === 'cowl-sweater') {
    // Chunky golden-yellow turtleneck cowl
    const cowlGeo = new THREE.CylinderGeometry(0.27, 0.29, 0.22, 12);
    const cowlMesh = new THREE.Mesh(cowlGeo, matVest);
    cowlMesh.position.set(0, 0.66, 0);
    rig.spine.add(cowlMesh);
  } else if (features.outfitStyle === 'gladiator-tank' || features.outfitStyle === 'champion-tank') {
    // Crossbody leather harness strap
    const harnessStrapGeo = new THREE.BoxGeometry(0.12, 0.70, 0.04);
    harnessStrapGeo.rotateZ(Math.PI / 4.5);
    const matHarness = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.6 });
    const harnessMesh = new THREE.Mesh(harnessStrapGeo, matHarness);
    harnessMesh.position.set(0.04, 0.35, 0.24);
    rig.spine.add(harnessMesh);

    // Blue necklace / energy core
    const necklaceGeo = new THREE.TorusGeometry(0.16, 0.015, 6, 12);
    necklaceGeo.rotateX(Math.PI / 2.2);
    const matNecklace = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      emissive: 0x0284c7,
      emissiveIntensity: 0.6,
    });
    const necklaceMesh = new THREE.Mesh(necklaceGeo, matNecklace);
    necklaceMesh.position.set(0, 0.58, 0.08);
    rig.spine.add(necklaceMesh);

    if (features.outfitStyle === 'champion-tank') {
      // Radiant Arc Reactor chest core
      const arcGeo = new THREE.CylinderGeometry(0.09, 0.09, 0.04, 16);
      arcGeo.rotateX(Math.PI / 2);
      const matArc = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const arcMesh = new THREE.Mesh(arcGeo, matArc);
      arcMesh.position.set(0, 0.36, 0.24);
      rig.spine.add(arcMesh);
    }
  }

  // ====================================================
  // 3. HEAD, FACE, EYEWEAR, FACIAL HAIR & HAIRSTYLE
  // ====================================================
  rig.headGroup = new THREE.Group();
  rig.headGroup.position.set(0, 0.74, 0);
  rig.spine.add(rig.headGroup);

  // Head base
  const headGeo = new THREE.BoxGeometry(0.36, 0.40, 0.38);
  const headMesh = new THREE.Mesh(headGeo, matSkin);
  headMesh.castShadow = true;
  rig.headGroup.add(headMesh);

  // Eyes
  const eyeColor = (features.outfitStyle === 'gladiator-tank' || features.outfitStyle === 'champion-tank' || features.outfitStyle === 'regal-vest')
    ? 0x0284c7 // Glowing piercing blue eyes
    : 0x271c19; // Stylized dark cartoon eyes

  const eyeGeo = new THREE.BoxGeometry(0.08, 0.045, 0.04);
  const eyeMat = new THREE.MeshBasicMaterial({ color: eyeColor });
  const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
  leftEye.position.set(-0.09, 0.02, 0.20);
  rig.headGroup.add(leftEye);

  const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
  rightEye.position.set(0.09, 0.02, 0.20);
  rig.headGroup.add(rightEye);

  // Eyewear / Glasses
  if (features.glasses === 'rectangular' || features.glasses === 'trainer-glasses') {
    const frameMat = new THREE.MeshBasicMaterial({ color: colorScheme.accessories || 0x0f172a });
    const frameGeo = new THREE.BoxGeometry(0.12, 0.07, 0.04);
    
    const leftFrame = new THREE.Mesh(frameGeo, frameMat);
    leftFrame.position.set(-0.10, 0.02, 0.22);
    rig.headGroup.add(leftFrame);

    const rightFrame = new THREE.Mesh(frameGeo, frameMat);
    rightFrame.position.set(0.10, 0.02, 0.22);
    rig.headGroup.add(rightFrame);

    const bridgeGeo = new THREE.BoxGeometry(0.06, 0.02, 0.03);
    const bridgeMesh = new THREE.Mesh(bridgeGeo, frameMat);
    bridgeMesh.position.set(0, 0.03, 0.22);
    rig.headGroup.add(bridgeMesh);
  } else if (features.glasses === 'round-black') {
    const frameMat = new THREE.MeshBasicMaterial({ color: 0x09090b });
    const ringGeo = new THREE.TorusGeometry(0.065, 0.014, 6, 16);
    
    const leftRing = new THREE.Mesh(ringGeo, frameMat);
    leftRing.position.set(-0.10, 0.02, 0.21);
    rig.headGroup.add(leftRing);

    const rightRing = new THREE.Mesh(ringGeo, frameMat);
    rightRing.position.set(0.10, 0.02, 0.21);
    rig.headGroup.add(rightRing);

    const bridgeGeo = new THREE.BoxGeometry(0.06, 0.02, 0.02);
    const bridgeMesh = new THREE.Mesh(bridgeGeo, frameMat);
    bridgeMesh.position.set(0, 0.02, 0.21);
    rig.headGroup.add(bridgeMesh);
  } else if (features.glasses === 'sunglasses-teal') {
    const sunMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const sunGeo = new THREE.BoxGeometry(0.32, 0.09, 0.05);
    const sunMesh = new THREE.Mesh(sunGeo, sunMat);
    sunMesh.position.set(0, 0.02, 0.22);
    rig.headGroup.add(sunMesh);
  }

  // Facial Hair
  if (features.facialHair === 'goatee' || features.facialHair === 'chin-scruff') {
    const goateeGeo = new THREE.BoxGeometry(0.12, 0.10, 0.04);
    const goateeMat = new THREE.MeshStandardMaterial({ color: colorScheme.hair, roughness: 0.9 });
    const goateeMesh = new THREE.Mesh(goateeGeo, goateeMat);
    goateeMesh.position.set(0, -0.16, 0.20);
    rig.headGroup.add(goateeMesh);
  } else if (features.facialHair === 'full-beard') {
    const beardGeo = new THREE.BoxGeometry(0.36, 0.18, 0.24);
    const beardMat = new THREE.MeshStandardMaterial({ color: colorScheme.hair, roughness: 0.9 });
    const beardMesh = new THREE.Mesh(beardGeo, beardMat);
    beardMesh.position.set(0, -0.14, 0.12);
    rig.headGroup.add(beardMesh);
  } else if (features.facialHair === 'stubble') {
    const stubbleGeo = new THREE.BoxGeometry(0.32, 0.10, 0.02);
    const stubbleMat = new THREE.MeshBasicMaterial({ color: 0x271c19 });
    const stubbleMesh = new THREE.Mesh(stubbleGeo, stubbleMat);
    stubbleMesh.position.set(0, -0.14, 0.20);
    rig.headGroup.add(stubbleMesh);
  }

  // Mask
  if (features.mask === 'tactical-respirator') {
    const maskGeo = new THREE.BoxGeometry(0.28, 0.18, 0.16);
    const maskMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.4, metalness: 0.5 });
    const maskMesh = new THREE.Mesh(maskGeo, maskMat);
    maskMesh.position.set(0, -0.10, 0.22);
    rig.headGroup.add(maskMesh);

    // Twin Red Air Intake Valves
    for (let v = -1; v <= 1; v += 2) {
      const valveGeo = new THREE.CylinderGeometry(0.045, 0.045, 0.04, 10);
      valveGeo.rotateX(Math.PI / 2);
      const valveMat = new THREE.MeshBasicMaterial({ color: 0xdc2626 });
      const valveMesh = new THREE.Mesh(valveGeo, valveMat);
      valveMesh.position.set(v * 0.10, -0.10, 0.31);
      rig.headGroup.add(valveMesh);
    }
  }

  // Earrings
  if (features.earrings === 'silver-dangle') {
    for (let e = -1; e <= 1; e += 2) {
      const earGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.10, 6);
      const earMat = new THREE.MeshBasicMaterial({ color: 0xe2e8f0 });
      const earMesh = new THREE.Mesh(earGeo, earMat);
      earMesh.position.set(e * 0.20, -0.06, 0.04);
      rig.headGroup.add(earMesh);
    }
  } else if (features.earrings === 'double-pearl') {
    for (let p = 0; p < 2; p++) {
      const pearlGeo = new THREE.SphereGeometry(0.022, 8, 8);
      const pearlMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc });
      const pearlMesh = new THREE.Mesh(pearlGeo, pearlMat);
      pearlMesh.position.set(0.19, -0.04 - p * 0.05, 0.04);
      rig.headGroup.add(pearlMesh);
    }
  }

  // HAIRSTYLE 3D BUILDER
  const hairGroup = new THREE.Group();
  rig.headGroup.add(hairGroup);

  if (features.hairStyle === 'curly-afro' || features.hairStyle === 'curly-earrings') {
    // Voluminous curly afro crown made of clustered curls
    const crownGeo = new THREE.SphereGeometry(0.24, 12, 10);
    crownGeo.scale(1.15, 0.95, 1.15);
    const crownMesh = new THREE.Mesh(crownGeo, matHair);
    crownMesh.position.set(0, 0.22, 0);
    hairGroup.add(crownMesh);

    // Curly puffs around temples and crown
    const curlOffsets = [
      { x: -0.16, y: 0.18, z: 0.12 },
      { x: 0.16, y: 0.18, z: 0.12 },
      { x: -0.18, y: 0.20, z: -0.08 },
      { x: 0.18, y: 0.20, z: -0.08 },
      { x: 0, y: 0.26, z: -0.10 },
      { x: 0, y: 0.26, z: 0.08 },
    ];
    curlOffsets.forEach((co) => {
      const puffGeo = new THREE.SphereGeometry(0.12, 8, 8);
      const puffMesh = new THREE.Mesh(puffGeo, matHair);
      puffMesh.position.set(co.x, co.y, co.z);
      hairGroup.add(puffMesh);
    });
  } else if (features.hairStyle === 'beanie') {
    // Ribbed knit beanie cap
    const beanieGeo = new THREE.SphereGeometry(0.22, 14, 10);
    beanieGeo.scale(1.05, 1.05, 1.1);
    const beanieMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.85 });
    const beanieMesh = new THREE.Mesh(beanieGeo, beanieMat);
    beanieMesh.position.set(0, 0.18, -0.02);
    hairGroup.add(beanieMesh);

    const rimGeo = new THREE.TorusGeometry(0.21, 0.04, 8, 16);
    rimGeo.rotateX(Math.PI / 2);
    const rimMesh = new THREE.Mesh(rimGeo, beanieMat);
    rimMesh.position.set(0, 0.10, 0);
    hairGroup.add(rimMesh);
  } else if (features.hairStyle === 'hooded-cowl') {
    // Tactical leather hooded cowl draped over head
    const cowlGeo = new THREE.BoxGeometry(0.44, 0.48, 0.44);
    const cowlMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.6 });
    const cowlMesh = new THREE.Mesh(cowlGeo, cowlMat);
    cowlMesh.position.set(0, 0.06, -0.04);
    hairGroup.add(cowlMesh);
  } else if (features.hairStyle === 'swept-quiff' || features.hairStyle === 'pompadour-beard') {
    // Styled pompadour / swept-up quiff
    const baseGeo = new THREE.BoxGeometry(0.38, 0.16, 0.40);
    const baseMesh = new THREE.Mesh(baseGeo, matHair);
    baseMesh.position.set(0, 0.20, -0.02);
    hairGroup.add(baseMesh);

    const quiffGeo = new THREE.BoxGeometry(0.28, 0.16, 0.32);
    quiffGeo.rotateX(-0.25);
    const quiffMesh = new THREE.Mesh(quiffGeo, matHair);
    quiffMesh.position.set(0, 0.28, 0.08);
    hairGroup.add(quiffMesh);
  } else if (features.hairStyle === 'braided-hawk') {
    // Braided faux-hawk with shaved fade undercut
    const mohawkGeo = new THREE.BoxGeometry(0.14, 0.24, 0.44);
    const mohawkMesh = new THREE.Mesh(mohawkGeo, matHair);
    mohawkMesh.position.set(0, 0.24, -0.02);
    hairGroup.add(mohawkMesh);

    // Braided texture ridges on top
    for (let b = -0.16; b <= 0.16; b += 0.08) {
      const braidGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.12, 6);
      braidGeo.rotateZ(Math.PI / 2);
      const braidMesh = new THREE.Mesh(braidGeo, matHair);
      braidMesh.position.set(0, 0.36, b);
      hairGroup.add(braidMesh);
    }
  } else if (features.hairStyle === 'anime-shaggy' || features.hairStyle === 'anime-champion') {
    // Shaggy layered anime hair with face-framing fringe
    const matAnimeHair = features.hairStyle === 'anime-champion'
      ? new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.6 })
      : matHair;

    const baseGeo = new THREE.SphereGeometry(0.24, 12, 10);
    baseGeo.scale(1.05, 0.95, 1.15);
    const baseMesh = new THREE.Mesh(baseGeo, matAnimeHair);
    baseMesh.position.set(0, 0.20, -0.04);
    hairGroup.add(baseMesh);

    // Spiky anime fringe strands
    const spikeOffsets = [
      { x: -0.12, y: 0.16, z: 0.18, rx: 0.4, rz: 0.2 },
      { x: 0.00, y: 0.20, z: 0.20, rx: 0.5, rz: 0.0 },
      { x: 0.12, y: 0.16, z: 0.18, rx: 0.4, rz: -0.2 },
      { x: -0.18, y: 0.14, z: 0.08, rx: 0.2, rz: 0.4 },
      { x: 0.18, y: 0.14, z: 0.08, rx: 0.2, rz: -0.4 },
    ];

    spikeOffsets.forEach((so) => {
      const spikeGeo = new THREE.ConeGeometry(0.06, 0.22, 6);
      spikeGeo.rotateX(Math.PI + so.rx);
      spikeGeo.rotateZ(so.rz);
      const spikeMesh = new THREE.Mesh(spikeGeo, matAnimeHair);
      spikeMesh.position.set(so.x, so.y, so.z);
      hairGroup.add(spikeMesh);
    });

    // Cyan glowing energy hair tips for Champion
    if (features.hairStyle === 'anime-champion') {
      const energyMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      for (let i = 0; i < 3; i++) {
        const energySpike = new THREE.ConeGeometry(0.035, 0.16, 5);
        energySpike.rotateX(Math.PI + 0.3);
        const eMesh = new THREE.Mesh(energySpike, energyMat);
        eMesh.position.set((i - 1) * 0.10, 0.24, 0.16);
        hairGroup.add(eMesh);
      }
    }
  } else if (features.hairStyle === 'bald-beard') {
    // Smooth bald head with slight scalp tint
    const baldCapGeo = new THREE.SphereGeometry(0.20, 12, 10);
    baldCapGeo.scale(1.0, 0.9, 1.05);
    const baldCap = new THREE.Mesh(baldCapGeo, matSkin);
    baldCap.position.set(0, 0.18, -0.02);
    hairGroup.add(baldCap);
  } else {
    // Standard spiky / parted / messy hair
    const hairCapGeo = new THREE.BoxGeometry(0.38, 0.20, 0.40);
    const hairCap = new THREE.Mesh(hairCapGeo, matHair);
    hairCap.position.set(0, 0.20, -0.02);
    hairGroup.add(hairCap);

    for (let s = -1; s <= 1; s++) {
      const clumpGeo = new THREE.BoxGeometry(0.12, 0.08, 0.10);
      const clumpMesh = new THREE.Mesh(clumpGeo, matHair);
      clumpMesh.position.set(s * 0.10, 0.28, 0.08);
      hairGroup.add(clumpMesh);
    }
  }

  // ====================================================
  // 4. ARMS & SLEEVES & POWER GAUNTLETS
  // ====================================================
  const upperArmGeo = new THREE.BoxGeometry(0.18, 0.38, 0.20);
  upperArmGeo.translate(0, -0.19, 0);

  const forearmGeo = new THREE.BoxGeometry(0.16, 0.36, 0.18);
  forearmGeo.translate(0, -0.18, 0);

  const handGeo = new THREE.BoxGeometry(0.12, 0.14, 0.12);
  handGeo.translate(0, -0.42, 0);

  // LEFT ARM
  rig.leftUpperArm = new THREE.Group();
  rig.leftUpperArm.position.set(-0.46, 0.50, 0);
  rig.spine.add(rig.leftUpperArm);

  // Sleeve material: check for asymmetrical sleeve (Cozy Tech Genius Player 12)
  const isPlayer12 = features.outfitStyle === 'cowl-sweater';
  const matLeftSleeve = isPlayer12
    ? new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.7 })
    : (features.outfitStyle === 'polo-shirt' ? matSkin : matVest);

  const leftUpperMesh = new THREE.Mesh(upperArmGeo, matLeftSleeve);
  leftUpperMesh.castShadow = true;
  rig.leftUpperArm.add(leftUpperMesh);

  rig.leftForearm = new THREE.Group();
  rig.leftForearm.position.set(0, -0.38, 0);
  rig.leftUpperArm.add(rig.leftForearm);

  const leftForearmMesh = new THREE.Mesh(forearmGeo, matLeftSleeve);
  leftForearmMesh.castShadow = true;
  rig.leftForearm.add(leftForearmMesh);

  // Left Hand
  const matHand = features.gloves === 'combat-spiked'
    ? new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.4 })
    : matSkin;

  const leftHand = new THREE.Mesh(handGeo, matHand);
  rig.leftForearm.add(leftHand);

  // Wristwatch / Wristband on Left Wrist
  if (features.hasWatch) {
    const watchGeo = new THREE.CylinderGeometry(0.09, 0.09, 0.05, 10);
    const matWatch = new THREE.MeshStandardMaterial({ color: 0x09090b, metalness: 0.8 });
    const watchMesh = new THREE.Mesh(watchGeo, matWatch);
    watchMesh.position.set(0, -0.35, 0);
    rig.leftForearm.add(watchMesh);
  } else if (features.gloves === 'wrist-wrap') {
    const wrapGeo = new THREE.CylinderGeometry(0.09, 0.09, 0.08, 10);
    const matWrap = new THREE.MeshStandardMaterial({ color: 0xffffff });
    const wrapMesh = new THREE.Mesh(wrapGeo, matWrap);
    wrapMesh.position.set(0, -0.34, 0);
    rig.leftForearm.add(wrapMesh);
  }

  // Dual Cyber Gauntlet on Left Arm for Supreme Champion
  if (features.armArmor === 'dual-cyber-gauntlet') {
    const gauntletGeo = new THREE.BoxGeometry(0.20, 0.32, 0.22);
    gauntletGeo.translate(0, -0.16, 0);
    const gauntletMat = new THREE.MeshStandardMaterial({
      map: textureGenerator.getCyberGauntletTexture(true),
      metalness: 0.7,
      roughness: 0.3,
    });
    const gauntletMesh = new THREE.Mesh(gauntletGeo, gauntletMat);
    rig.leftForearm.add(gauntletMesh);
  }

  // RIGHT ARM
  rig.rightUpperArm = new THREE.Group();
  rig.rightUpperArm.position.set(0.46, 0.50, 0);
  rig.spine.add(rig.rightUpperArm);

  const matRightSleeve = features.outfitStyle === 'polo-shirt' ? matSkin : matVest;
  const rightUpperMesh = new THREE.Mesh(upperArmGeo, matRightSleeve);
  rightUpperMesh.castShadow = true;
  rig.rightUpperArm.add(rightUpperMesh);

  rig.rightForearm = new THREE.Group();
  rig.rightForearm.position.set(0, -0.38, 0);
  rig.rightUpperArm.add(rig.rightForearm);

  const rightForearmMesh = new THREE.Mesh(forearmGeo, matRightSleeve);
  rightForearmMesh.castShadow = true;
  rig.rightForearm.add(rightForearmMesh);

  const rightHand = new THREE.Mesh(handGeo, matHand);
  rig.rightForearm.add(rightHand);

  // Cyber Gauntlet on Right Arm (Gesioh Gladiator & Champion)
  if (features.armArmor === 'cyber-gauntlet' || features.armArmor === 'dual-cyber-gauntlet') {
    const isElite = features.armArmor === 'dual-cyber-gauntlet';
    const gauntletGeo = new THREE.BoxGeometry(0.20, 0.32, 0.22);
    gauntletGeo.translate(0, -0.16, 0);
    const gauntletMat = new THREE.MeshStandardMaterial({
      map: textureGenerator.getCyberGauntletTexture(isElite),
      metalness: 0.7,
      roughness: 0.3,
    });
    const gauntletMesh = new THREE.Mesh(gauntletGeo, gauntletMat);
    rig.rightForearm.add(gauntletMesh);
  }

  // Graffiti Spray Can in Right Hand
  if (features.hasSprayCan) {
    rig.sprayCanGroup = new THREE.Group();
    rig.sprayCanGroup.position.set(0, -0.44, 0.06);
    rig.sprayCanGroup.rotation.x = Math.PI / 4;

    const canGeo = new THREE.CylinderGeometry(0.065, 0.065, 0.24, 10);
    const matSpray = new THREE.MeshStandardMaterial({
      color: colorScheme.sprayCan || 0x0284c7,
      roughness: 0.3,
      metalness: 0.6,
    });
    const canMesh = new THREE.Mesh(canGeo, matSpray);
    rig.sprayCanGroup.add(canMesh);

    const tipGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.04, 6);
    const tipMat = new THREE.MeshBasicMaterial({ color: colorScheme.sprayCap || 0xf97316 });
    const tipMesh = new THREE.Mesh(tipGeo, tipMat);
    tipMesh.position.set(0, 0.15, 0);
    rig.sprayCanGroup.add(tipMesh);

    rig.rightForearm.add(rig.sprayCanGroup);
  }

  // ====================================================
  // 5. SHOULDER PAULDRONS / ARMOR
  // ====================================================
  if (features.shoulderArmor) {
    const pauldronGroup = new THREE.Group();
    pauldronGroup.position.set(-0.50, 0.60, 0);

    // Curved steel shoulder pauldron
    const pauldronGeo = new THREE.SphereGeometry(0.18, 12, 10, 0, Math.PI);
    pauldronGeo.rotateZ(Math.PI / 2);
    const matPauldron = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      metalness: 0.9,
      roughness: 0.2,
    });
    const pauldronMesh = new THREE.Mesh(pauldronGeo, matPauldron);
    pauldronGroup.add(pauldronMesh);

    // Gold decorative trim rim
    const goldRimGeo = new THREE.TorusGeometry(0.18, 0.02, 6, 16);
    const goldRim = new THREE.Mesh(goldRimGeo, matGold);
    pauldronGroup.add(goldRim);

    rig.spine.add(pauldronGroup);
  }

  // ====================================================
  // 6. LEGS & PANTS
  // ====================================================
  const thighGeo = new THREE.BoxGeometry(0.22, 0.44, 0.24);
  thighGeo.translate(0, -0.22, 0);

  const shinGeo = new THREE.BoxGeometry(0.20, 0.44, 0.22);
  shinGeo.translate(0, -0.22, 0);

  // Shorts check: exposed skin on shins for khaki shorts
  const isShorts = features.pantsStyle === 'khaki-shorts';
  const shinMaterial = isShorts ? matSkin : matPants;

  // LEFT LEG
  rig.leftThigh = new THREE.Group();
  rig.leftThigh.position.set(-0.20, -0.12, 0);
  rig.hips.add(rig.leftThigh);

  const leftThighMesh = new THREE.Mesh(thighGeo, matPants);
  leftThighMesh.castShadow = true;
  rig.leftThigh.add(leftThighMesh);

  // Cargo pocket / straps on left thigh
  if (features.pantsStyle === 'baggy-cargo' || features.pantsStyle === 'camel-cargos' || features.pantsStyle === 'orange-stripe') {
    const pocketGeo = new THREE.BoxGeometry(0.06, 0.16, 0.16);
    const pocketMesh = new THREE.Mesh(pocketGeo, matPants);
    pocketMesh.position.set(-0.12, -0.22, 0);
    rig.leftThigh.add(pocketMesh);

    // Contrasting side stripe
    if (colorScheme.pantsStripe) {
      const stripeGeo = new THREE.BoxGeometry(0.02, 0.44, 0.04);
      const matStripe = new THREE.MeshBasicMaterial({ color: colorScheme.pantsStripe });
      const stripeMesh = new THREE.Mesh(stripeGeo, matStripe);
      stripeMesh.position.set(-0.115, -0.22, 0);
      rig.leftThigh.add(stripeMesh);
    }
  }

  rig.leftShin = new THREE.Group();
  rig.leftShin.position.set(0, -0.44, 0);
  rig.leftThigh.add(rig.leftShin);

  const leftShinMesh = new THREE.Mesh(shinGeo, shinMaterial);
  leftShinMesh.castShadow = true;
  rig.leftShin.add(leftShinMesh);

  // RIGHT LEG
  rig.rightThigh = new THREE.Group();
  rig.rightThigh.position.set(0.20, -0.12, 0);
  rig.hips.add(rig.rightThigh);

  const rightThighMesh = new THREE.Mesh(thighGeo, matPants);
  rightThighMesh.castShadow = true;
  rig.rightThigh.add(rightThighMesh);

  if (features.pantsStyle === 'baggy-cargo' || features.pantsStyle === 'camel-cargos' || features.pantsStyle === 'orange-stripe') {
    const pocketGeo = new THREE.BoxGeometry(0.06, 0.16, 0.16);
    const pocketMesh = new THREE.Mesh(pocketGeo, matPants);
    pocketMesh.position.set(0.12, -0.22, 0);
    rig.rightThigh.add(pocketMesh);

    if (colorScheme.pantsStripe) {
      const stripeGeo = new THREE.BoxGeometry(0.02, 0.44, 0.04);
      const matStripe = new THREE.MeshBasicMaterial({ color: colorScheme.pantsStripe });
      const stripeMesh = new THREE.Mesh(stripeGeo, matStripe);
      stripeMesh.position.set(0.115, -0.22, 0);
      rig.rightThigh.add(stripeMesh);
    }
  }

  rig.rightShin = new THREE.Group();
  rig.rightShin.position.set(0, -0.44, 0);
  rig.rightThigh.add(rig.rightShin);

  const rightShinMesh = new THREE.Mesh(shinGeo, shinMaterial);
  rightShinMesh.castShadow = true;
  rig.rightShin.add(rightShinMesh);

  // ====================================================
  // 7. SHOES & SNEAKERS & GLOWING LED SOLES & GREAVES
  // ====================================================
  const shoeUpperGeo = new THREE.BoxGeometry(0.22, 0.18, 0.36);
  const soleGeo = new THREE.BoxGeometry(0.23, 0.05, 0.38);
  soleGeo.translate(0, -0.09, 0);

  const treadGeo = new THREE.PlaneGeometry(0.22, 0.36);
  treadGeo.rotateX(Math.PI / 2);
  const matTread = new THREE.MeshStandardMaterial({
    map: textureGenerator.getShoeSoleTexture(),
    roughness: 0.8,
    metalness: 0.1,
  });

  // Left Shoe
  const leftShoeGroup = new THREE.Group();
  leftShoeGroup.position.set(0, -0.44, 0.04);

  const leftShoeUpper = new THREE.Mesh(shoeUpperGeo, matShoes);
  leftShoeUpper.castShadow = true;
  leftShoeGroup.add(leftShoeUpper);

  const leftSoleMesh = new THREE.Mesh(soleGeo, matSoleGlow);
  leftShoeGroup.add(leftSoleMesh);

  const leftTreadMesh = new THREE.Mesh(treadGeo, matTread);
  leftTreadMesh.position.set(0, -0.116, 0);
  leftShoeGroup.add(leftTreadMesh);

  // Armored greaves ankle energy orbs for Gladiator / Champion
  if (features.shoesStyle === 'armored-greaves' || features.shoesStyle === 'champion-greaves') {
    const orbGeo = new THREE.SphereGeometry(0.04, 8, 8);
    const orbMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const orbMesh = new THREE.Mesh(orbGeo, orbMat);
    orbMesh.position.set(-0.12, 0.02, 0);
    leftShoeGroup.add(orbMesh);
  }

  rig.leftShin.add(leftShoeGroup);

  // Right Shoe
  const rightShoeGroup = new THREE.Group();
  rightShoeGroup.position.set(0, -0.44, 0.04);

  const rightShoeUpper = new THREE.Mesh(shoeUpperGeo, matShoes);
  rightShoeUpper.castShadow = true;
  rightShoeGroup.add(rightShoeUpper);

  const rightSoleMesh = new THREE.Mesh(soleGeo, matSoleGlow);
  rightShoeGroup.add(rightSoleMesh);

  const rightTreadMesh = new THREE.Mesh(treadGeo, matTread);
  rightTreadMesh.position.set(0, -0.116, 0);
  rightShoeGroup.add(rightTreadMesh);

  if (features.shoesStyle === 'armored-greaves' || features.shoesStyle === 'champion-greaves') {
    const orbGeo = new THREE.SphereGeometry(0.04, 8, 8);
    const orbMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const orbMesh = new THREE.Mesh(orbGeo, orbMat);
    orbMesh.position.set(0.12, 0.02, 0);
    rightShoeGroup.add(orbMesh);
  }

  rig.rightShin.add(rightShoeGroup);

  // ====================================================
  // 8. BACKPACKS & JETPACK THRUSTERS
  // ====================================================
  if (features.backpackType && features.backpackType !== 'none') {
    const backpackGroup = new THREE.Group();
    backpackGroup.position.set(0, 0.36, -0.24);

    const packBodyGeo = new THREE.BoxGeometry(0.48, 0.54, 0.20);
    const matPackSides = new THREE.MeshStandardMaterial({
      color: colorScheme.backpack || 0x0f172a,
      roughness: 0.8,
    });
    const matPackFace = new THREE.MeshStandardMaterial({
      map: textureGenerator.getBackpackTexture(),
      roughness: 0.6,
      metalness: 0.15,
    });

    const backpackMaterials = [
      matPackSides,
      matPackSides,
      matPackSides,
      matPackSides,
      matPackSides,
      matPackFace,
    ];

    const packMesh = new THREE.Mesh(packBodyGeo, backpackMaterials);
    packMesh.castShadow = true;
    backpackGroup.add(packMesh);

    // Shoulder straps
    for (let s = -1; s <= 1; s += 2) {
      const strapGeo = new THREE.BoxGeometry(0.06, 0.52, 0.05);
      const strapMesh = new THREE.Mesh(strapGeo, matPackSides);
      strapMesh.position.set(s * 0.18, 0.08, 0.14);
      strapMesh.rotation.x = -0.15;
      backpackGroup.add(strapMesh);
    }

    // Rocket Thrusters (for flight powerup mode)
    const nozzleGeo = new THREE.CylinderGeometry(0.07, 0.11, 0.20, 8);
    const matNozzle = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, roughness: 0.2 });
    const leftNozzle = new THREE.Mesh(nozzleGeo, matNozzle);
    leftNozzle.position.set(-0.17, -0.28, 0);
    backpackGroup.add(leftNozzle);

    const rightNozzle = new THREE.Mesh(nozzleGeo, matNozzle);
    rightNozzle.position.set(0.17, -0.28, 0);
    backpackGroup.add(rightNozzle);

    const flameGeo = new THREE.ConeGeometry(0.09, 0.45, 8);
    flameGeo.rotateX(Math.PI);
    const flameMat = new THREE.MeshBasicMaterial({ color: 0x00f5ff, transparent: true, opacity: 0.9 });

    rig.jetpackFireLeft = new THREE.Mesh(flameGeo, flameMat);
    rig.jetpackFireLeft.position.set(-0.17, -0.48, 0);
    rig.jetpackFireLeft.visible = false;
    backpackGroup.add(rig.jetpackFireLeft);

    rig.jetpackFireRight = new THREE.Mesh(flameGeo, flameMat);
    rig.jetpackFireRight.position.set(0.17, -0.48, 0);
    rig.jetpackFireRight.visible = false;
    backpackGroup.add(rig.jetpackFireRight);

    rig.spine.add(backpackGroup);
  }

  // ====================================================
  // 9. HIGH TIER CHAMPION GLOW AURA
  // ====================================================
  if (features.glowAura || rig.characterDef.id >= 14) {
    const auraGeo = new THREE.SphereGeometry(1.25, 16, 16);
    const auraMat = new THREE.MeshBasicMaterial({
      color: colorScheme.glow || colorScheme.soleGlow,
      transparent: true,
      opacity: 0.18,
      wireframe: true,
    });
    rig.auraMesh = new THREE.Mesh(auraGeo, auraMat);
    rig.auraMesh.position.set(0, 1.0, 0);
    rig.group.add(rig.auraMesh);
  }
}
