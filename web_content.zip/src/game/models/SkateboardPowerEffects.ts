/**
 * SPR - Sahil Powerful Run
 * Real-Time 3D Skateboard Power Effects Engine
 * 
 * Implements:
 * 1. Dynamic Swinging Energy Field / Perimeter Ribbon (Real-time 3D wave geometry)
 * 2. Dynamic 3D Crackling Lightning Arcs (real-time jagged line segments that jump along deck)
 * 3. Dynamic 3D Particle Swarm & Sparks (localized halo + trailing sparks around the board)
 * 4. Distinct Effects for Every Skateboard:
 *    - Fire board -> Blazing fire/flame trail & rising embers
 *    - Ice board -> Sub-zero ice/frost trail & crystalline shards
 *    - Thunder board -> Crackling purple/blue lightning & electric arcs
 *    - Neon board -> High-frequency neon plasma ribbon & laser energy
 *    - Lava board -> Molten magma trail & volcanic rock embers
 *    - Galaxy board -> Cosmic stardust particles & orbiting nebula stars
 *    - Dragon board -> Ferocious dragon-fire breath & golden embers
 *    - Rocket board -> Supersonic rocket exhaust, dual rear flame cones, & billowing smoke
 *    - Diamond board -> Sparkling prismatic diamond shards & rainbow crystal glints
 * 5. Dynamic Motion Responsiveness:
 *    - Acceleration: trails lengthen, emission surges
 *    - Jumping: energy field expands downward with anti-grav sparks
 *    - Landing: radial energy shockwave burst
 *    - Lane switching: lateral swinging inertia tilt & spark banking
 *    - Speed boost: intense overdrive brightness & double flame length
 */

import * as THREE from 'three';
import { SkateboardShapeType } from '../constants/skateboards';

export interface SkateboardMotionState {
  isJumping?: boolean;
  isLanding?: boolean;
  isSliding?: boolean;
  isSpeedBoost?: boolean;
  laneSwitchingIntensity?: number; // -1 to +1 (left to right)
  verticalVelocity?: number;
  effectiveSpeed?: number;
}

interface EffectParticle {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  rotSpeed: number;
  life: number;
  maxLife: number;
  baseScale: number;
  colorHex: number;
}

export class SkateboardPowerEffects {
  public group: THREE.Group;
  private shape: SkateboardShapeType;
  private primaryColor: number;
  private secondaryColor: number;

  // 1. Dynamic Energy Ribbon
  private energyRibbonMesh: THREE.Mesh | null = null;
  private ribbonGeom: THREE.BufferGeometry | null = null;
  private ribbonPositions: Float32Array | null = null;
  private ribbonPointCount = 28;

  // 2. Dynamic Lightning Arcs
  private lightningSegments: THREE.LineSegments | null = null;
  private lightningGeom: THREE.BufferGeometry | null = null;
  private lightningPositions: Float32Array | null = null;
  private lightningTimer = 0;
  private maxLightningBolts = 8;

  // 3. Particle System (Sparks, Embers, Ice, Smoke, Cosmic Stars, Gems)
  private particles: EffectParticle[] = [];
  private maxParticles = 36;
  private particleGeomPool: THREE.BufferGeometry[] = [];
  private particleMatPool: THREE.Material[] = [];

  // 4. Dedicated Rocket Exhaust (for Rocket Board)
  private rocketExhaustGroup: THREE.Group | null = null;
  private rocketSmokePuffs: { mesh: THREE.Mesh; life: number; maxLife: number; vy: number; vz: number; baseScale: number }[] = [];
  private rocketFlames: THREE.Mesh[] = [];

  // Animation Timers & Transient States
  private animTime = 0;
  private landingPulse = 0;

  constructor(shape: SkateboardShapeType, primaryColor: number, secondaryColor: number) {
    this.shape = shape;
    this.primaryColor = primaryColor;
    this.secondaryColor = secondaryColor;
    this.group = new THREE.Group();
    this.group.name = 'spr_skateboard_power_effects';

    this.initEnergyRibbon();
    this.initLightningArcs();
    this.initParticles();

    if (this.shape === 'rocket_board') {
      this.initDedicatedRocketExhaust();
    }
  }

  // =========================================================================
  // 1. DYNAMIC SWINGING ENERGY RIBBON
  // =========================================================================
  private initEnergyRibbon() {
    // Elliptical deck perimeter ribbon (Length ~2.1, Width ~0.86, Height ~0.08)
    const count = this.ribbonPointCount;
    const vertices = new Float32Array(count * 2 * 3); // top and bottom edges
    const indices: number[] = [];

    // Pre-calculate baseline perimeter shape
    const halfL = 1.05;
    const halfW = 0.43;

    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      const x = Math.sin(angle) * halfW;
      const z = Math.cos(angle) * halfL;

      // Top edge of ribbon
      vertices[i * 6 + 0] = x;
      vertices[i * 6 + 1] = 0.23;
      vertices[i * 6 + 2] = z;

      // Bottom edge of ribbon
      vertices[i * 6 + 3] = x;
      vertices[i * 6 + 4] = 0.16;
      vertices[i * 6 + 5] = z;

      // Connect triangle quad
      const next = (i + 1) % count;
      const i0 = i * 2;
      const i1 = i * 2 + 1;
      const i2 = next * 2;
      const i3 = next * 2 + 1;

      indices.push(i0, i1, i2);
      indices.push(i2, i1, i3);
    }

    const geom = new THREE.BufferGeometry();
    geom.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
    geom.setIndex(indices);
    geom.computeVertexNormals();

    const mat = new THREE.MeshBasicMaterial({
      color: this.primaryColor,
      transparent: true,
      opacity: 0.65,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
      depthWrite: false,
    });

    const mesh = new THREE.Mesh(geom, mat);
    mesh.name = 'energy_perimeter_ribbon';
    this.group.add(mesh);

    this.energyRibbonMesh = mesh;
    this.ribbonGeom = geom;
    this.ribbonPositions = vertices;
  }

  // =========================================================================
  // 2. REAL-TIME 3D CRACKLING LIGHTNING ARCS
  // =========================================================================
  private initLightningArcs() {
    // 8 dynamic lightning arcs, each with 5 segments (6 vertices -> 10 line vertices)
    const pointsPerBolt = 5;
    const totalVertices = this.maxLightningBolts * pointsPerBolt * 2 * 3;
    const positions = new Float32Array(totalVertices);

    const geom = new THREE.BufferGeometry();
    geom.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    let lightningColor = this.secondaryColor;
    if (this.shape === 'thunder_ride') {
      lightningColor = 0xc084fc; // Vivid violet/purple lightning
    } else if (this.shape === 'electro_blue') {
      lightningColor = 0x38bdf8; // Electric cyan
    } else if (this.shape === 'fire_blaze' || this.shape === 'dragon_fire') {
      lightningColor = 0xfbbf24; // Amber lightning
    } else if (this.shape === 'ice_storm') {
      lightningColor = 0x7dd3fc; // Glacial frost arc
    } else if (this.shape === 'neon_glow') {
      lightningColor = 0x4ade80; // Neon green arc
    } else if (this.shape === 'diamond') {
      lightningColor = 0xe0f2fe; // Diamond light beam
    }

    const mat = new THREE.LineBasicMaterial({
      color: lightningColor,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const lines = new THREE.LineSegments(geom, mat);
    lines.name = 'lightning_arcs';
    this.group.add(lines);

    this.lightningSegments = lines;
    this.lightningGeom = geom;
    this.lightningPositions = positions;

    this.generateLightningBolts(1.0);
  }

  private generateLightningBolts(intensityMultiplier: number) {
    if (!this.lightningPositions || !this.lightningGeom) return;

    const halfL = 1.05;
    const halfW = 0.42;
    const pointsPerBolt = 5;
    let idx = 0;

    for (let b = 0; b < this.maxLightningBolts; b++) {
      // Pick two random points on or near the deck perimeter
      const startAngle = Math.random() * Math.PI * 2;
      const arcSpread = 0.6 + Math.random() * 1.5;
      const endAngle = startAngle + arcSpread;

      const p0 = new THREE.Vector3(
        Math.sin(startAngle) * halfW,
        0.18 + Math.random() * 0.08,
        Math.cos(startAngle) * halfL
      );
      const pEnd = new THREE.Vector3(
        Math.sin(endAngle) * halfW,
        0.18 + Math.random() * 0.08,
        Math.cos(endAngle) * halfL
      );

      let prevPoint = p0;
      for (let s = 1; s <= pointsPerBolt; s++) {
        const t = s / pointsPerBolt;
        const target = new THREE.Vector3().lerpVectors(p0, pEnd, t);

        // Add 3D jagged zigzag displacement
        const jitter = (0.05 + Math.random() * 0.07) * intensityMultiplier;
        if (s < pointsPerBolt) {
          target.x += (Math.random() - 0.5) * jitter * 2;
          target.y += (Math.random() - 0.3) * jitter * 1.8;
          target.z += (Math.random() - 0.5) * jitter * 2;
        }

        // Line segment: prevPoint to target
        this.lightningPositions[idx++] = prevPoint.x;
        this.lightningPositions[idx++] = prevPoint.y;
        this.lightningPositions[idx++] = prevPoint.z;

        this.lightningPositions[idx++] = target.x;
        this.lightningPositions[idx++] = target.y;
        this.lightningPositions[idx++] = target.z;

        prevPoint = target;
      }
    }

    this.lightningGeom.attributes.position.needsUpdate = true;
  }

  // =========================================================================
  // 3. THEME-SPECIFIC PARTICLE SWARM & SPARKS
  // =========================================================================
  private initParticles() {
    // Pre-create shared geometries for maximum performance
    const sparkGeo = new THREE.TetrahedronGeometry(0.035);
    const emberGeo = new THREE.OctahedronGeometry(0.045);
    const gemGeo = new THREE.OctahedronGeometry(0.05);
    this.particleGeomPool.push(sparkGeo, emberGeo, gemGeo);

    // Build 36 initial particle meshes tailored to board theme
    for (let i = 0; i < this.maxParticles; i++) {
      let geo = sparkGeo;
      let color = this.primaryColor;
      let baseScale = 0.8 + Math.random() * 0.6;

      if (this.shape === 'fire_blaze' || this.shape === 'lava_rush' || this.shape === 'dragon_fire') {
        geo = emberGeo;
        color = i % 2 === 0 ? 0xf97316 : (i % 3 === 0 ? 0xef4444 : 0xfacc15);
      } else if (this.shape === 'ice_storm') {
        geo = emberGeo;
        color = i % 2 === 0 ? 0x38bdf8 : 0xe0f2fe;
      } else if (this.shape === 'thunder_ride' || this.shape === 'purple_spark') {
        geo = sparkGeo;
        color = i % 2 === 0 ? 0xa855f7 : 0x38bdf8;
      } else if (this.shape === 'neon_glow') {
        geo = sparkGeo;
        color = i % 2 === 0 ? 0x22c55e : 0x06b6d4;
      } else if (this.shape === 'galaxy') {
        geo = sparkGeo;
        color = i % 2 === 0 ? 0xd8b4fe : 0x38bdf8;
      } else if (this.shape === 'diamond') {
        geo = gemGeo;
        color = i % 3 === 0 ? 0xbae6fd : (i % 2 === 0 ? 0xffffff : 0x38bdf8);
        baseScale = 1.0 + Math.random() * 0.5;
      } else if (this.shape === 'tiger_strike') {
        geo = sparkGeo;
        color = i % 2 === 0 ? 0xf59e0b : 0xd97706;
      }

      const mat = new THREE.MeshBasicMaterial({
        color: color,
        transparent: true,
        opacity: 0.8,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      this.particleMatPool.push(mat);

      const mesh = new THREE.Mesh(geo, mat);
      mesh.visible = false;
      this.group.add(mesh);

      const particle: EffectParticle = {
        mesh,
        vx: 0,
        vy: 0,
        vz: 0,
        rotSpeed: (Math.random() - 0.5) * 12,
        life: 0,
        maxLife: 0.4 + Math.random() * 0.5,
        baseScale,
        colorHex: color,
      };

      // Stagger initial spawn
      particle.life = (i / this.maxParticles) * particle.maxLife;
      this.respawnParticle(particle, 20);
      this.particles.push(particle);
    }
  }

  private respawnParticle(p: EffectParticle, speed: number, isSpeedBoost: boolean = false) {
    p.life = 0;
    p.mesh.visible = true;

    // Spawn around deck rails or wheels
    const side = Math.random() > 0.5 ? 1 : -1;
    const x = side * (0.32 + Math.random() * 0.15);
    const y = 0.10 + Math.random() * 0.18;
    const z = -0.9 + Math.random() * 1.9; // Along deck length

    p.mesh.position.set(x, y, z);

    // Backward trail velocity proportional to speed
    const boostMult = isSpeedBoost ? 1.6 : 1.0;
    p.vz = (2.2 + speed * 0.18 + Math.random() * 1.5) * boostMult; // Drift rearward
    p.vx = side * (0.2 + Math.random() * 0.4);
    p.vy = 0.3 + Math.random() * 0.6; // Slight upward float

    if (this.shape === 'fire_blaze' || this.shape === 'dragon_fire') {
      p.vy = 0.8 + Math.random() * 1.2; // Flame sparks rise faster
    } else if (this.shape === 'ice_storm') {
      p.vy = -0.1 + Math.random() * 0.3; // Frost lingers low
    }

    p.mesh.scale.setScalar(p.baseScale);
  }

  // =========================================================================
  // 4. DEDICATED ROCKET EXHAUST (ROCKET BOARD ONLY)
  // =========================================================================
  private initDedicatedRocketExhaust() {
    this.rocketExhaustGroup = new THREE.Group();
    this.rocketExhaustGroup.name = 'rocket_thruster_power_exhaust';

    const nozzlePositions = [-0.22, 0.22];

    // Supersonic shock diamond cones & afterburner flame tongues
    nozzlePositions.forEach((x) => {
      // 1. Shock Diamond Core (Inner White/Cyan Hot Core)
      const diamondMat = new THREE.MeshBasicMaterial({
        color: 0x67e8f9,
        transparent: true,
        opacity: 0.95,
        blending: THREE.AdditiveBlending,
      });
      const diamondCone = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.55, 8), diamondMat);
      diamondCone.rotation.x = Math.PI / 2;
      diamondCone.position.set(x, 0.20, 1.42);
      this.rocketExhaustGroup!.add(diamondCone);
      this.rocketFlames.push(diamondCone);

      // 2. High-energy Flame Halo
      const haloMat = new THREE.MeshBasicMaterial({
        color: 0xf97316,
        transparent: true,
        opacity: 0.80,
        blending: THREE.AdditiveBlending,
      });
      const haloCone = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.85, 10), haloMat);
      haloCone.rotation.x = Math.PI / 2;
      haloCone.position.set(x, 0.20, 1.58);
      this.rocketExhaustGroup!.add(haloCone);
      this.rocketFlames.push(haloCone);
    });

    // 3. Trailing Smoke & Energy Puffs
    const smokeGeo = new THREE.SphereGeometry(0.07, 6, 6);
    const smokeMat = new THREE.MeshBasicMaterial({
      color: 0xfed7aa,
      transparent: true,
      opacity: 0.65,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    for (let i = 0; i < 14; i++) {
      const puff = new THREE.Mesh(smokeGeo, smokeMat.clone());
      puff.visible = false;
      this.rocketExhaustGroup.add(puff);

      this.rocketSmokePuffs.push({
        mesh: puff,
        life: (i / 14) * 0.45,
        maxLife: 0.45,
        vy: 0.2,
        vz: 6.0,
        baseScale: 0.7 + Math.random() * 0.6,
      });
    }

    this.group.add(this.rocketExhaustGroup);
  }

  public triggerLandingBurst() {
    this.landingPulse = 1.0;
  }

  // =========================================================================
  // 5. ANIMATION LOOP UPDATE (REAL-TIME 3D RESPONSED TO SPEED & MOTION)
  // =========================================================================
  public update(delta: number, speed: number, motion?: SkateboardMotionState) {
    this.animTime += delta;
    const isJumping = motion?.isJumping ?? false;
    const isSliding = motion?.isSliding ?? false;
    const isSpeedBoost = motion?.isSpeedBoost ?? false;
    const laneTilt = motion?.laneSwitchingIntensity ?? 0;

    // Decay landing pulse
    if (this.landingPulse > 0) {
      this.landingPulse = Math.max(0, this.landingPulse - delta * 3.5);
    }

    // 1. UPDATE DYNAMIC SWINGING ENERGY RIBBON
    if (this.ribbonPositions && this.ribbonGeom && this.energyRibbonMesh) {
      const count = this.ribbonPointCount;
      const halfL = 1.05;
      const halfW = 0.43;

      // Amplitude surges during speed boost, landing, and jumping
      let waveAmp = 0.025 + (speed / 30) * 0.015;
      if (isSpeedBoost) waveAmp *= 1.8;
      if (isJumping) waveAmp *= 1.5;
      if (this.landingPulse > 0) waveAmp += this.landingPulse * 0.05;

      const waveSpeed = 12 + (speed / 10) * 4;

      for (let i = 0; i < count; i++) {
        const angle = (i / count) * Math.PI * 2;
        // Lateral swing inertia from lane switching
        const swingX = -laneTilt * 0.12 * Math.sin(angle);
        const x = Math.sin(angle) * halfW + swingX;
        const z = Math.cos(angle) * halfL;

        // Dynamic 3D undulating wave around the rim
        const wave = Math.sin(this.animTime * waveSpeed + i * 0.8) * waveAmp;
        const jumpLift = isJumping ? -0.04 : 0; // Expands downward on jump

        // Top vertex
        this.ribbonPositions[i * 6 + 0] = x;
        this.ribbonPositions[i * 6 + 1] = 0.23 + wave + jumpLift;
        this.ribbonPositions[i * 6 + 2] = z;

        // Bottom vertex
        this.ribbonPositions[i * 6 + 3] = x;
        this.ribbonPositions[i * 6 + 4] = 0.16 - wave * 0.6 + jumpLift;
        this.ribbonPositions[i * 6 + 5] = z;
      }

      this.ribbonGeom.attributes.position.needsUpdate = true;

      // Ribbon opacity pulse
      const mat = this.energyRibbonMesh.material as THREE.MeshBasicMaterial;
      const baseOpacity = isSpeedBoost ? 0.90 : 0.65;
      mat.opacity = baseOpacity + Math.sin(this.animTime * 14) * 0.15;
    }

    // 2. UPDATE REAL-TIME 3D LIGHTNING ARCS
    const lightningInterval = isSpeedBoost ? 0.035 : (this.shape === 'thunder_ride' || this.shape === 'electro_blue' ? 0.045 : 0.075);
    this.lightningTimer += delta;

    if (this.lightningTimer >= lightningInterval) {
      this.lightningTimer = 0;
      const lightningIntensity = (isSpeedBoost ? 1.8 : 1.0) * (1.0 + this.landingPulse * 1.5);
      this.generateLightningBolts(lightningIntensity);
    }

    // 3. UPDATE PARTICLE SWARM & SPARKS
    for (const p of this.particles) {
      p.life += delta;
      if (p.life >= p.maxLife) {
        this.respawnParticle(p, speed, isSpeedBoost);
      }

      // Move particle
      p.mesh.position.x += (p.vx - laneTilt * 0.8) * delta;
      p.mesh.position.y += p.vy * delta;
      p.mesh.position.z += p.vz * delta;

      // Rotate particle in 3D
      p.mesh.rotation.x += p.rotSpeed * delta;
      p.mesh.rotation.y += p.rotSpeed * 1.2 * delta;

      // Scale down over lifetime
      const progress = p.life / p.maxLife;
      const scale = p.baseScale * (1 - progress * 0.85);
      p.mesh.scale.setScalar(Math.max(0.01, scale));

      const pMat = p.mesh.material as THREE.MeshBasicMaterial;
      pMat.opacity = Math.max(0, 0.85 * (1 - progress));
    }

    // 4. UPDATE DEDICATED ROCKET EXHAUST (ROCKET BOARD ONLY)
    if (this.rocketExhaustGroup) {
      const flicker = 1.0 + Math.sin(this.animTime * 35) * 0.35 + Math.cos(this.animTime * 22) * 0.2;
      const boostScale = isSpeedBoost ? 2.1 : 1.2;
      const totalScaleZ = flicker * boostScale;

      for (const flame of this.rocketFlames) {
        flame.scale.set(
          0.85 + Math.sin(this.animTime * 28) * 0.2,
          totalScaleZ,
          0.85 + Math.sin(this.animTime * 28) * 0.2
        );
      }

      // Billowing rocket smoke puffs
      const nozzleX = [-0.22, 0.22];
      for (let i = 0; i < this.rocketSmokePuffs.length; i++) {
        const puff = this.rocketSmokePuffs[i];
        puff.life += delta;
        if (puff.life >= puff.maxLife) {
          puff.life = 0;
          puff.mesh.visible = true;
          const nx = nozzleX[i % 2];
          puff.mesh.position.set(nx + (Math.random() - 0.5) * 0.08, 0.20, 1.45);
          puff.vz = 5.5 + speed * 0.25;
        }

        puff.mesh.position.z += puff.vz * delta;
        puff.mesh.position.y += puff.vy * delta;

        const pProg = puff.life / puff.maxLife;
        const scale = puff.baseScale * (0.8 + pProg * 2.2); // Expands as it billows out
        puff.mesh.scale.setScalar(scale);

        const sMat = puff.mesh.material as THREE.MeshBasicMaterial;
        sMat.opacity = Math.max(0, 0.7 * (1 - pProg));
      }
    }
  }

  public dispose() {
    if (this.ribbonGeom) this.ribbonGeom.dispose();
    if (this.lightningGeom) this.lightningGeom.dispose();

    for (const g of this.particleGeomPool) {
      g.dispose();
    }
    for (const m of this.particleMatPool) {
      m.dispose();
    }

    this.group.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        if (mesh.material) {
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach((m) => m.dispose());
          } else {
            mesh.material.dispose();
          }
        }
      }
    });

    while (this.group.children.length > 0) {
      this.group.remove(this.group.children[0]);
    }
    this.particles = [];
    this.rocketSmokePuffs = [];
    this.rocketFlames = [];
  }
}
