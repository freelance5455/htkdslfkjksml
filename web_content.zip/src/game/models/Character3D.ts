/**
 * SPR - Sahil Powerful Run
 * Hierarchical 3D Stylized Humanoid Character Engine
 * Accurately models the 12 Sahil 3D runner designs:
 * - Signature hairstyles, clothing, glowing sneaker soles, spray can
 * - Integrated 3D Skateboard equipment & riding animations
 * - Player rides ONE SINGLE large 3D skateboard with both feet planted on deck
 */

import * as THREE from 'three';
import { CharacterDef, CHARACTERS } from '../constants';
import { Skateboard3D, BoardSkinDef } from './Skateboard3D';
import { SkateboardPowerEffects, SkateboardMotionState } from './SkateboardPowerEffects';
import { SkateboardDef, SKATEBOARDS } from '../constants/skateboards';
import { buildCharacter3DModel, CharacterRig } from './characterMeshBuilder';

export type AnimationType = 'idle' | 'run' | 'jump' | 'slide' | 'death' | 'victory' | 'skate' | 'rocket_fly';

export class Character3D {
  public group: THREE.Group;
  public characterDef: CharacterDef;
  
  // Skeleton / Limbs hierarchy
  public hips!: THREE.Group;
  public spine!: THREE.Group;
  public chest!: THREE.Mesh;
  public headGroup!: THREE.Group;
  public leftUpperArm!: THREE.Group;
  public leftForearm!: THREE.Group;
  public rightUpperArm!: THREE.Group;
  public rightForearm!: THREE.Group;
  public leftThigh!: THREE.Group;
  public leftShin!: THREE.Group;
  public rightThigh!: THREE.Group;
  public rightShin!: THREE.Group;

  // Single 3D Skateboard (Underneath both feet)
  public skateboard: Skateboard3D | null = null;
  public isSkating: boolean = false;
  public sprayCanGroup: THREE.Group | null = null;

  // Jetpack thrusters & Aura
  public jetpackFireLeft: THREE.Mesh | null = null;
  public jetpackFireRight: THREE.Mesh | null = null;
  public auraMesh: THREE.Mesh | null = null;

  // Animation & Flight state
  public currentAnim: AnimationType = 'idle';
  public flightPitch: number = 0; // 0 = upright standing, 1 = horizontal flying/sleeping pose
  private animTimer: number = 0;
  private runSpeedScale: number = 1.0;
  private deathTumble: number = 0;
  private motionState: SkateboardMotionState = {};

  public setMotionState(state: SkateboardMotionState) {
    this.motionState = state;
  }

  public setFlightPitch(pitch: number) {
    this.flightPitch = Math.max(0, Math.min(1, pitch));
  }

  public triggerSkateboardLanding() {
    this.skateboard?.triggerLandingBurst();
  }

  constructor(characterId: number = 1) {
    this.group = new THREE.Group();
    this.characterDef = CHARACTERS.find((c) => c.id === characterId) || CHARACTERS[0];
    this.buildCharacterMesh();
    this.initSkateboard();
  }

  public setCharacter(characterId: number) {
    const newDef = CHARACTERS.find((c) => c.id === characterId);
    if (!newDef) return;
    this.characterDef = newDef;
    
    // Save current skateboard skin and active state
    const currentSkin = this.skateboard ? this.skateboard.skin : SKATEBOARDS[0].visuals;
    const wasSkating = this.isSkating;

    // Cleanly dispose and remove old children
    this.dispose();
    this.buildCharacterMesh();
    this.initSkateboard(currentSkin);
    this.setSkateboardActive(wasSkating);
  }

  public initSkateboard(initialSkin?: BoardSkinDef | SkateboardDef['visuals'], boardId?: number) {
    if (this.skateboard) {
      this.skateboard.dispose();
      this.group.remove(this.skateboard.group);
      this.skateboard = null;
    }
    const skin = initialSkin || SKATEBOARDS[0].visuals;
    this.skateboard = new Skateboard3D(skin, boardId);
    this.skateboard.group.position.set(0, 0, 0);
    this.skateboard.group.visible = this.isSkating;
    this.group.add(this.skateboard.group);
  }

  public dispose() {
    if (this.skateboard) {
      this.skateboard.dispose();
      this.skateboard = null;
    }

    this.group.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        if (mesh.geometry) {
          mesh.geometry.dispose();
        }
        if (mesh.material) {
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach((m) => m.dispose());
          } else {
            mesh.material.dispose();
          }
        }
      }
      if ((child as THREE.Light).isLight) {
        const light = child as any;
        if (light.shadow && light.shadow.map) {
          light.shadow.map.dispose();
        }
      }
    });

    while (this.group.children.length > 0) {
      this.group.remove(this.group.children[0]);
    }
  }

  public setSkateboardActive(active: boolean) {
    this.isSkating = active;
    if (this.skateboard) {
      this.skateboard.group.visible = active;
    }
    if (active) {
      if (this.currentAnim === 'run' || this.currentAnim === 'idle') {
        this.setAnimation('skate');
      }
    } else {
      if (this.currentAnim === 'skate') {
        this.setAnimation('run');
      }
    }
  }

  public setSkateboardSkin(skin: BoardSkinDef | SkateboardDef['visuals'], boardId?: number) {
    if (this.skateboard) {
      this.skateboard.setSkin(skin, boardId);
    } else {
      this.initSkateboard(skin, boardId);
    }
  }

  private buildCharacterMesh() {
    buildCharacter3DModel(this as unknown as CharacterRig);
  }

  public setAnimation(anim: AnimationType) {
    if (this.currentAnim === anim) return;
    this.currentAnim = anim;
    this.animTimer = 0;
    if (anim === 'death') {
      this.deathTumble = 0;
    }
  }

  public setRunSpeed(speed: number) {
    this.runSpeedScale = Math.max(0.8, Math.min(2.5, speed / 20));
  }

  public setJetpackActive(active: boolean) {
    if (this.jetpackFireLeft && this.jetpackFireRight) {
      this.jetpackFireLeft.visible = active;
      this.jetpackFireRight.visible = active;
      if (active) {
        const s = 0.8 + Math.random() * 0.4;
        this.jetpackFireLeft.scale.set(s, s * (1 + Math.random() * 0.5), s);
        this.jetpackFireRight.scale.set(s, s * (1 + Math.random() * 0.5), s);
      }
    }
  }

  private leftNozzleWorldVec = new THREE.Vector3();
  private rightNozzleWorldVec = new THREE.Vector3();

  public getJetpackLeftNozzleWorldPosition(): THREE.Vector3 {
    if (this.jetpackFireLeft) {
      this.jetpackFireLeft.getWorldPosition(this.leftNozzleWorldVec);
      return this.leftNozzleWorldVec;
    }
    // Fallback if character model has no backpack
    return this.leftNozzleWorldVec.set(
      this.group.position.x - 0.22,
      this.group.position.y + 0.9,
      this.group.position.z + 0.25
    );
  }

  public getJetpackRightNozzleWorldPosition(): THREE.Vector3 {
    if (this.jetpackFireRight) {
      this.jetpackFireRight.getWorldPosition(this.rightNozzleWorldVec);
      return this.rightNozzleWorldVec;
    }
    // Fallback if character model has no backpack
    return this.rightNozzleWorldVec.set(
      this.group.position.x + 0.22,
      this.group.position.y + 0.9,
      this.group.position.z + 0.25
    );
  }

  // --- ANIMATION UPDATE LOOP ---
  public update(delta: number) {
    this.animTimer += delta;
    const t = this.animTimer;

    // Reset default rotations
    if (this.currentAnim !== 'death' && this.currentAnim !== 'rocket_fly') {
      this.group.rotation.x = 0;
      this.group.position.y = 0;
    }

    if (this.auraMesh) {
      this.auraMesh.rotation.y += delta * 1.5;
      this.auraMesh.rotation.x += delta * 0.8;
    }

    // Update skateboard wheels spin & real-time 3D power effects if active
    if (this.skateboard && (this.isSkating || this.currentAnim === 'victory' || this.currentAnim === 'rocket_fly')) {
      this.skateboard.update(delta, this.runSpeedScale * 28, this.motionState);
    }

    switch (this.currentAnim) {
      case 'idle':
        this.animateIdle(t);
        break;
      case 'run':
        this.animateRun(t);
        break;
      case 'jump':
        this.animateJump(t);
        break;
      case 'slide':
        this.animateSlide(t);
        break;
      case 'skate':
        this.animateSkate(t);
        break;
      case 'death':
        this.animateDeath(delta);
        break;
      case 'victory':
        this.animateVictory(t);
        break;
      case 'rocket_fly':
        this.animateRocketFlight(t, delta);
        break;
    }
  }

  private animateIdle(t: number) {
    const breath = Math.sin(t * 2.5);
    this.hips.position.y = 1.05 + breath * 0.03;
    this.spine.rotation.x = 0.05 + breath * 0.02;
    this.spine.rotation.y = 0;
    this.headGroup.rotation.x = -breath * 0.02;
    this.headGroup.rotation.y = Math.sin(t * 1.2) * 0.15;

    // Arms relaxed at sides
    this.leftUpperArm.rotation.x = -0.1 + breath * 0.05;
    this.leftUpperArm.rotation.z = 0.15;
    this.leftForearm.rotation.x = -0.25;

    this.rightUpperArm.rotation.x = -0.1 - breath * 0.05;
    this.rightUpperArm.rotation.z = -0.15;
    this.rightForearm.rotation.x = -0.35;

    // Legs straight
    this.leftThigh.rotation.x = 0;
    this.leftThigh.rotation.z = 0;
    this.leftShin.rotation.x = 0;
    this.rightThigh.rotation.x = 0;
    this.rightThigh.rotation.z = 0;
    this.rightShin.rotation.x = 0;
  }

  private animateRun(t: number) {
    const cycle = t * 14 * this.runSpeedScale;
    const stride = Math.sin(cycle);
    const cosStride = Math.cos(cycle);

    // Torso athletic forward lean and bounce
    this.hips.position.y = 1.05 + Math.abs(cosStride) * 0.08;
    this.spine.rotation.x = 0.22;
    this.spine.rotation.y = stride * 0.14;
    this.headGroup.rotation.x = -0.12;
    this.headGroup.rotation.y = 0;

    // Legs swing
    this.leftThigh.rotation.x = stride * 0.85;
    this.leftThigh.rotation.z = 0;
    this.leftShin.rotation.x = stride > 0 ? stride * 0.9 : 0.1;

    this.rightThigh.rotation.x = -stride * 0.85;
    this.rightThigh.rotation.z = 0;
    this.rightShin.rotation.x = stride < 0 ? -stride * 0.9 : 0.1;

    // Arms pumping
    this.leftUpperArm.rotation.x = -stride * 0.85;
    this.leftUpperArm.rotation.z = 0.2;
    this.leftForearm.rotation.x = -0.7 - Math.max(0, -stride * 0.6);

    this.rightUpperArm.rotation.x = stride * 0.85;
    this.rightUpperArm.rotation.z = -0.2;
    this.rightForearm.rotation.x = -0.7 - Math.max(0, stride * 0.6);
  }

  /**
   * CRITICAL: SINGLE SKATEBOARD RIDING STANCE
   * - One single skateboard underneath BOTH feet
   * - Player stands naturally on the SAME single skateboard
   * - Both feet positioned firmly on the deck
   * - Body upright, athletic, balanced
   * - Left foot forward, right foot rear
   */
  private animateSkate(t: number) {
    const sway = Math.sin(t * 8) * 0.05;

    // Hips positioned at 1.08 so both shoe soles rest directly on the deck top surface (Y ≈ 0.22)
    this.hips.position.y = 1.08;
    this.hips.position.x = 0;
    this.hips.position.z = 0;

    // Torso athletic skateboarding stance, facing three-quarters
    this.spine.rotation.y = 0.42;
    this.spine.rotation.x = 0.09;
    this.spine.rotation.z = sway;

    // Head looking forward down the track
    this.headGroup.rotation.y = -0.38;
    this.headGroup.rotation.x = -0.04;

    // Balanced arms out for dynamic high-speed skate stabilization
    this.leftUpperArm.rotation.x = -0.55;
    this.leftUpperArm.rotation.z = 0.62;
    this.leftUpperArm.rotation.y = 0.18;
    this.leftForearm.rotation.x = -0.35;

    this.rightUpperArm.rotation.x = -0.75;
    this.rightUpperArm.rotation.z = -0.58;
    this.rightUpperArm.rotation.y = -0.18;
    this.rightForearm.rotation.x = -0.45;

    // FRONT FOOT (Left): positioned forward on the deck at Z ≈ -0.36
    this.leftThigh.rotation.x = -0.32;
    this.leftThigh.rotation.z = -0.16;
    this.leftThigh.rotation.y = 0.12;
    this.leftShin.rotation.x = 0.42;

    // REAR FOOT (Right): positioned back on the deck at Z ≈ 0.38
    this.rightThigh.rotation.x = 0.30;
    this.rightThigh.rotation.z = 0.16;
    this.rightThigh.rotation.y = 0.22;
    this.rightShin.rotation.x = 0.48;
  }

  private animateJump(t: number) {
    if (this.isSkating) {
      // Skateboard Ollie / Jump: Player stays on board, knees bent on deck in air!
      this.hips.position.y = 1.02;
      this.spine.rotation.x = 0.16;
      this.spine.rotation.y = 0.42;

      this.leftUpperArm.rotation.x = -1.1;
      this.leftUpperArm.rotation.z = 0.7;
      this.rightUpperArm.rotation.x = -1.1;
      this.rightUpperArm.rotation.z = -0.7;

      this.leftThigh.rotation.x = -0.45;
      this.leftShin.rotation.x = 0.65;
      this.rightThigh.rotation.x = 0.45;
      this.rightShin.rotation.x = 0.70;
      return;
    }

    this.hips.position.y = 1.18;
    this.spine.rotation.x = 0.15;
    this.spine.rotation.y = 0;

    // Arms reaching up for balance
    this.leftUpperArm.rotation.x = -1.2;
    this.leftUpperArm.rotation.z = 0.45;
    this.leftForearm.rotation.x = -0.8;

    this.rightUpperArm.rotation.x = -1.2;
    this.rightUpperArm.rotation.z = -0.45;
    this.rightForearm.rotation.x = -0.8;

    // Tucked knees
    this.leftThigh.rotation.x = 0.85;
    this.leftShin.rotation.x = 1.15;

    this.rightThigh.rotation.x = 0.75;
    this.rightShin.rotation.x = 1.05;
  }

  private animateSlide(t: number) {
    if (this.isSkating) {
      // Skateboard Powerslide / Low Carve: Deep crouch right on the board!
      this.hips.position.y = 0.68;
      this.spine.rotation.x = 0.25;
      this.spine.rotation.y = 0.65;

      this.leftUpperArm.rotation.x = 0.3;
      this.leftUpperArm.rotation.z = 0.8;
      this.rightUpperArm.rotation.x = -0.4;
      this.rightUpperArm.rotation.z = -0.8;

      this.leftThigh.rotation.x = -0.75;
      this.leftShin.rotation.x = 1.1;
      this.rightThigh.rotation.x = 0.65;
      this.rightShin.rotation.x = 1.2;
      return;
    }

    // Low slide posture
    this.hips.position.y = 0.52;
    this.spine.rotation.x = -0.55;
    this.spine.rotation.y = 0;

    this.leftUpperArm.rotation.x = 0.6;
    this.leftUpperArm.rotation.z = 0.6;
    this.leftForearm.rotation.x = -0.3;

    this.rightUpperArm.rotation.x = 0.6;
    this.rightUpperArm.rotation.z = -0.6;
    this.rightForearm.rotation.x = -0.3;

    // Extended front leg
    this.leftThigh.rotation.x = -1.2;
    this.leftShin.rotation.x = 0.15;

    this.rightThigh.rotation.x = 0.8;
    this.rightShin.rotation.x = 1.4;
  }

  private animateDeath(delta: number) {
    this.deathTumble = Math.min(1.0, this.deathTumble + delta * 2.8);
    const ease = 1 - Math.pow(1 - this.deathTumble, 3);

    this.group.rotation.x = -Math.PI / 2 * ease;
    this.group.position.y = -0.75 * ease;

    this.spine.rotation.x = -0.3 * ease;
    this.headGroup.rotation.x = 0.5 * ease;

    this.leftUpperArm.rotation.x = 1.4 * ease;
    this.leftUpperArm.rotation.z = 1.2 * ease;
    this.rightUpperArm.rotation.x = 1.4 * ease;
    this.rightUpperArm.rotation.z = -1.2 * ease;

    this.leftThigh.rotation.x = 0.2 * ease;
    this.leftThigh.rotation.z = 0.4 * ease;
    this.rightThigh.rotation.x = -0.3 * ease;
    this.rightThigh.rotation.z = -0.4 * ease;
  }

  private animateVictory(t: number) {
    const breath = Math.sin(t * 3);
    this.hips.position.y = 1.05 + breath * 0.02;
    this.spine.rotation.x = -0.1;
    this.spine.rotation.y = 0;

    // Right arm high fist pump with spray can
    this.rightUpperArm.rotation.x = -2.7 + Math.sin(t * 6) * 0.25;
    this.rightUpperArm.rotation.z = -0.3;
    this.rightForearm.rotation.x = -0.5;

    // Left hand on hip
    this.leftUpperArm.rotation.x = 0.2;
    this.leftUpperArm.rotation.z = 0.7;
    this.leftForearm.rotation.x = -1.3;

    this.headGroup.rotation.x = -0.2;
    this.headGroup.rotation.y = 0.15;

    this.leftThigh.rotation.z = 0.2;
    this.rightThigh.rotation.z = -0.2;
  }

  /**
   * Master Rocket Flight Posture - Horizontal Sleeping / Superman Flight
   * Lays the player's 3D body horizontally forward with head pointing forward down the track,
   * legs extended naturally backward, arms streamlined, and the skateboard attached underneath.
   */
  private animateRocketFlight(t: number, delta: number) {
    const p = this.flightPitch; // 0 (upright) to 1 (horizontal flying pose)
    const ease = p * p * (3 - 2 * p); // smoothstep curve for intentional, premium transition

    // Subtle aerodynamic hover bobbing and aerodynamic pitch during cruise
    const hoverY = p > 0.75 ? Math.sin(t * 3.8) * 0.055 : 0;
    const hoverPitch = p > 0.75 ? Math.sin(t * 2.2) * 0.022 : 0;

    // 1. ROOT HIPS & WAIST: Smoothly rotate -90 degrees (-PI/2) into horizontal flying pose
    this.hips.position.y = THREE.MathUtils.lerp(1.05, 0.44 + hoverY, ease);
    this.hips.position.z = THREE.MathUtils.lerp(0, 0.06, ease);
    this.hips.rotation.x = THREE.MathUtils.lerp(0, -Math.PI / 2 + hoverPitch, ease);
    this.hips.rotation.y = THREE.MathUtils.lerp(this.hips.rotation.y, 0, delta * 6);
    this.hips.rotation.z = THREE.MathUtils.lerp(this.hips.rotation.z, 0, delta * 6);

    // 2. TORSO & SPINE: Streamlined forward along the flight axis
    this.spine.rotation.x = THREE.MathUtils.lerp(0.08, 0.04, ease);
    this.spine.rotation.y = 0;
    this.spine.rotation.z = 0;

    // 3. HEAD & NECK: Head held up naturally, looking forward down the track (-Z)
    this.headGroup.rotation.x = THREE.MathUtils.lerp(0, Math.PI / 2 - 0.22, ease);
    this.headGroup.rotation.y = Math.sin(t * 1.5) * 0.03 * (1 - ease * 0.6);
    this.headGroup.rotation.z = 0;

    // 4. ARMS: Streamlined supersonic flight posture cutting through the air
    this.leftUpperArm.rotation.x = THREE.MathUtils.lerp(-0.2, -0.15, ease);
    this.leftUpperArm.rotation.y = THREE.MathUtils.lerp(0, 0.06, ease);
    this.leftUpperArm.rotation.z = THREE.MathUtils.lerp(0.15, 0.26, ease);
    this.leftForearm.rotation.x = THREE.MathUtils.lerp(-0.25, -0.10, ease);

    this.rightUpperArm.rotation.x = THREE.MathUtils.lerp(-0.2, -0.15, ease);
    this.rightUpperArm.rotation.y = THREE.MathUtils.lerp(0, -0.06, ease);
    this.rightUpperArm.rotation.z = THREE.MathUtils.lerp(-0.15, -0.26, ease);
    this.rightForearm.rotation.x = THREE.MathUtils.lerp(-0.35, -0.10, ease);

    // 5. LEGS & FEET: Extended naturally backward like high-speed flight
    const flutter = Math.sin(t * 4.2) * 0.025 * ease;
    this.leftThigh.rotation.x = THREE.MathUtils.lerp(0, 0.04 + flutter, ease);
    this.leftThigh.rotation.y = 0;
    this.leftThigh.rotation.z = THREE.MathUtils.lerp(0, 0.05, ease);
    this.leftShin.rotation.x = THREE.MathUtils.lerp(0, 0.06, ease);

    this.rightThigh.rotation.x = THREE.MathUtils.lerp(0, -0.04 - flutter, ease);
    this.rightThigh.rotation.y = 0;
    this.rightThigh.rotation.z = THREE.MathUtils.lerp(0, -0.05, ease);
    this.rightShin.rotation.x = THREE.MathUtils.lerp(0, 0.06, ease);

    // 6. SKATEBOARD: Firmly attached underneath the player, aligned horizontally
    if (this.skateboard) {
      this.skateboard.group.visible = true;
      this.skateboard.group.position.set(0, THREE.MathUtils.lerp(0, 0.20 + hoverY * 0.8, ease), 0);
      this.skateboard.group.rotation.set(0, 0, 0);
    }
  }
}
