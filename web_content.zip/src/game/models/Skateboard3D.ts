/**
 * SPR - Sahil Powerful Run
 * Master 3D Skateboard Engine
 * 
 * Generates 15 Genuinely Distinct 3D Skateboard Geometries:
 * 1. FIRE BLAZE - Normal skateboard shape with serrated flame side wings & fire trail
 * 2. ICE STORM - Faceted ice-crystal shaped deck with protruding frozen shards & ice trail
 * 3. THUNDER RIDE - Angular zigzag lightning-bolt deck with Tesla coils & electric trail
 * 4. NEON GLOW - Futuristic curved cyber-deck with continuous glowing neon tube piping
 * 5. LAVA RUSH - Heavy chunky volcanic rock deck with glowing magma fissures & lava trail
 * 6. WOODEN CLASSIC - Handcrafted teardrop pintail vintage longboard with 7-ply maple woodgrain (FREE/DEFAULT)
 * 7. GALAXY - Futuristic cosmic aero-saucer deck with 3D planetary rings & celestial star orb
 * 8. CAMO FORCE - Military-style rugged armored deck with steel bull-bar roll cage & tow hooks
 * 9. SKULL RIDER - Aggressive gothic batwing deck with 3D sculpted skull nose & spinal column
 * 10. ELECTRO BLUE - Sleek aerodynamic nano-blade deck with dual quantum capacitors & PCB circuits
 * 11. DRAGON FIRE - Dragon-inspired curved deck with 3D dragon head prow & golden horns
 * 12. PURPLE SPARK - Sharp futuristic stealth chevron deck with plasma prism crystals & sparks
 * 13. ROCKET BOARD - SPECIAL EDITION! Aerodynamic rocket nosecone fuselage with DUAL animated rocket thrusters & flames
 * 14. TIGER STRIKE - Aggressive racing skateboard shape with twin saber-tooth tiger fangs & rear spoiler
 * 15. DIAMOND - Premium brilliant-cut crystal diamond deck with glittering facets & rotating gems
 * 
 * CRITICAL REQUIREMENTS:
 * - Single Skateboard: Player stands naturally on ONE single skateboard underneath both feet.
 * - Sized generously (width ~0.76-0.82, length ~1.95-2.15) for stable dual-foot placement.
 * - Authentic 3D wheels, trucks, glowing underglow point light, and animated thrusters/crystals.
 */

import * as THREE from 'three';
import { SkateboardDef, SkateboardShapeType, SKATEBOARDS } from '../constants/skateboards';
import { SkateboardPowerEffects, SkateboardMotionState } from './SkateboardPowerEffects';

export interface BoardSkinDef {
  deckTop: number;
  deckBottom: number;
  deckEdge: number;
  trucks: number;
  wheels: number;
  wheelsGlow?: number;
  underglowColor?: number;
  emissiveIntensity?: number;
  trailType?: string;
  graphicName?: string;
  rarity?: string;
  boardShape?: SkateboardShapeType;
}

export class Skateboard3D {
  public group: THREE.Group;
  public wheels: THREE.Mesh[] = [];
  private wheelSpinAngle: number = 0;
  public underglowLight: THREE.PointLight | null = null;
  public thrusterFlames: THREE.Mesh[] = [];
  public dynamicGlows: THREE.Mesh[] = [];
  public powerEffects: SkateboardPowerEffects | null = null;
  private pulseTimer: number = 0;
  public skin: BoardSkinDef | SkateboardDef['visuals'];
  public boardShape: SkateboardShapeType;
  public boardId: number = 1;

  constructor(skin: BoardSkinDef | SkateboardDef['visuals'], boardId?: number) {
    this.skin = skin;
    this.boardId = boardId || this.detectBoardId(skin);
    this.boardShape = skin.boardShape || this.detectShape(skin, this.boardId);
    this.group = new THREE.Group();
    this.group.name = 'spr_single_skateboard';
    this.buildBoard();
  }

  private detectBoardId(skin: BoardSkinDef | SkateboardDef['visuals']): number {
    if (skin.graphicName) {
      const match = SKATEBOARDS.find(b => b.visuals.graphicName === skin.graphicName || b.name === skin.graphicName);
      if (match) return match.id;
    }
    return 1;
  }

  private detectShape(skin: BoardSkinDef | SkateboardDef['visuals'], id: number): SkateboardShapeType {
    const match = SKATEBOARDS.find(b => b.id === id);
    if (match) return match.visuals.boardShape;
    const shapes: SkateboardShapeType[] = [
      'fire_blaze', 'ice_storm', 'thunder_ride', 'neon_glow', 'lava_rush',
      'wooden_classic', 'galaxy', 'camo_force', 'skull_rider', 'electro_blue',
      'dragon_fire', 'purple_spark', 'rocket_board', 'tiger_strike', 'diamond',
    ];
    return shapes[(id - 1) % shapes.length] || 'fire_blaze';
  }

  public setSkin(skin: BoardSkinDef | SkateboardDef['visuals'], boardId?: number) {
    this.skin = skin;
    if (boardId) this.boardId = boardId;
    this.boardShape = skin.boardShape || this.detectShape(skin, this.boardId);
    this.dispose();
    this.buildBoard();
  }

  public dispose() {
    this.group.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        if (mesh.geometry) {
          mesh.geometry.dispose();
        }
        if (mesh.material) {
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach((m) => m.dispose());
          } else {
            mesh.material.dispose();
          }
        }
      }
      if ((child as THREE.Light).isLight) {
        const light = child as any;
        if (light.shadow && light.shadow.map) {
          light.shadow.map.dispose();
        }
      }
    });

    while (this.group.children.length > 0) {
      this.group.remove(this.group.children[0]);
    }
    if (this.powerEffects) {
      this.powerEffects.dispose();
      this.powerEffects = null;
    }
    this.wheels = [];
    this.thrusterFlames = [];
    this.dynamicGlows = [];
    this.underglowLight = null;
  }

  private buildBoard() {
    const skin = this.skin;
    const emissiveInt = skin.emissiveIntensity ?? 0.6;

    // Deck materials
    const topMat = new THREE.MeshStandardMaterial({
      color: skin.deckTop,
      roughness: 0.88,
      metalness: 0.1,
    });

    const bottomMat = new THREE.MeshStandardMaterial({
      color: skin.deckBottom,
      roughness: 0.35,
      metalness: 0.45,
      emissive: skin.deckBottom,
      emissiveIntensity: emissiveInt * 0.25,
    });

    const edgeMat = new THREE.MeshStandardMaterial({
      color: skin.deckEdge,
      roughness: 0.2,
      metalness: 0.8,
      emissive: skin.deckEdge,
      emissiveIntensity: emissiveInt * 0.8,
    });

    const trucksMat = new THREE.MeshStandardMaterial({
      color: skin.trucks,
      roughness: 0.25,
      metalness: 0.85,
    });

    const wheelMat = new THREE.MeshStandardMaterial({
      color: skin.wheels,
      roughness: 0.2,
      metalness: 0.3,
    });

    const wheelGlowMat = new THREE.MeshBasicMaterial({
      color: skin.wheelsGlow ?? skin.deckEdge,
    });

    // Generate unique 3D shape based on boardShape
    switch (this.boardShape) {
      case 'ice_storm':
        this.buildIceStorm(topMat, bottomMat, edgeMat);
        break;
      case 'thunder_ride':
        this.buildThunderRide(topMat, bottomMat, edgeMat);
        break;
      case 'neon_glow':
        this.buildNeonGlow(topMat, bottomMat, edgeMat);
        break;
      case 'lava_rush':
        this.buildLavaRush(topMat, bottomMat, edgeMat);
        break;
      case 'wooden_classic':
        this.buildWoodenClassic(topMat, bottomMat, edgeMat);
        break;
      case 'galaxy':
        this.buildGalaxy(topMat, bottomMat, edgeMat);
        break;
      case 'camo_force':
        this.buildCamoForce(topMat, bottomMat, edgeMat);
        break;
      case 'skull_rider':
        this.buildSkullRider(topMat, bottomMat, edgeMat);
        break;
      case 'electro_blue':
        this.buildElectroBlue(topMat, bottomMat, edgeMat);
        break;
      case 'dragon_fire':
        this.buildDragonFire(topMat, bottomMat, edgeMat);
        break;
      case 'purple_spark':
        this.buildPurpleSpark(topMat, bottomMat, edgeMat);
        break;
      case 'rocket_board':
        this.buildRocketBoard(topMat, bottomMat, edgeMat);
        break;
      case 'tiger_strike':
        this.buildTigerStrike(topMat, bottomMat, edgeMat);
        break;
      case 'diamond':
        this.buildDiamond(topMat, bottomMat, edgeMat);
        break;
      case 'fire_blaze':
      default:
        this.buildFireBlaze(topMat, bottomMat, edgeMat);
        break;
    }

    // Common Underdeck Hardware: Trucks & Wheels
    this.buildRunningGear(trucksMat, wheelMat, wheelGlowMat);

    // Neon asphalt underglow light
    const underglowHex = skin.underglowColor || skin.wheelsGlow || skin.deckEdge;
    const underglow = new THREE.PointLight(underglowHex, 2.0, 3.8);
    underglow.position.set(0, 0.08, 0);
    this.group.add(underglow);
    this.underglowLight = underglow;

    // Real-Time 3D Skateboard Power Effects Engine (Swinging energy ribbon, lightning arcs, sparks & thruster exhaust)
    this.powerEffects = new SkateboardPowerEffects(
      this.boardShape,
      skin.deckEdge,
      skin.wheelsGlow ?? skin.underglowColor ?? skin.deckEdge
    );
    this.group.add(this.powerEffects.group);
  }

  // =========================================================================
  // 1. FIRE BLAZE (Normal street skateboard with serrated flame side wings)
  // =========================================================================
  private buildFireBlaze(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    // Main street deck
    const mainDeck = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.04, 1.45), [
      edgeMat, edgeMat, topMat, bottomMat, edgeMat, edgeMat
    ]);
    mainDeck.position.set(0, 0.20, 0);
    mainDeck.castShadow = true;
    deckGroup.add(mainDeck);

    // Trident Flame-cut Kick Nose
    const nose = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.038, 0.38), topMat);
    nose.position.set(0, 0.24, -0.86);
    nose.rotation.x = -0.22;
    deckGroup.add(nose);

    // Flared Kick Tail
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.70, 0.038, 0.35), topMat);
    tail.position.set(0, 0.23, 0.85);
    tail.rotation.x = 0.20;
    deckGroup.add(tail);

    // Serrated Flame Blade Wings on both sides
    const flameMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0xf97316,
      emissiveIntensity: 0.9,
      roughness: 0.3,
    });

    [-1, 1].forEach((side) => {
      for (let i = -2; i <= 2; i++) {
        const wing = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.22, 4), flameMat);
        wing.rotation.z = side * (Math.PI / 2 + 0.3);
        wing.rotation.y = side * 0.2;
        wing.position.set(side * 0.43, 0.20, i * 0.26);
        deckGroup.add(wing);
      }
    });

    // Flaming Crown grip tape emblem
    const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 0.008, 5), edgeMat);
    crown.position.set(0, 0.223, -0.15);
    deckGroup.add(crown);

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 2. ICE STORM (Faceted Ice-Crystal Deck with Protruding Shards & Frost)
  // =========================================================================
  private buildIceStorm(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    const crystalMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.15,
      metalness: 0.6,
      emissive: 0x38bdf8,
      emissiveIntensity: 0.7,
      transparent: true,
      opacity: 0.92,
    });

    // Faceted hexagonal ice crystal deck
    const deckCenter = new THREE.Mesh(new THREE.CylinderGeometry(0.40, 0.40, 0.045, 6), crystalMat);
    deckCenter.rotation.y = Math.PI / 6;
    deckCenter.scale.set(0.95, 1.0, 2.2);
    deckCenter.position.set(0, 0.20, 0);
    deckGroup.add(deckCenter);

    // Sharp Spearhead Crystal Nose
    const noseCone = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.55, 4), crystalMat);
    noseCone.rotation.x = -Math.PI / 2;
    noseCone.position.set(0, 0.22, -1.05);
    deckGroup.add(noseCone);

    // Faceted Prism Tail Wedge
    const tailCone = new THREE.Mesh(new THREE.ConeGeometry(0.35, 0.45, 4), crystalMat);
    tailCone.rotation.x = Math.PI / 2;
    tailCone.position.set(0, 0.22, 1.02);
    deckGroup.add(tailCone);

    // 8 Protruding Sharp Ice Crystal Shards along perimeter
    [-1, 1].forEach((side) => {
      [-0.6, -0.2, 0.2, 0.6].forEach((zPos, idx) => {
        const shard = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.26, 4), edgeMat);
        shard.rotation.z = side * (Math.PI / 2 + 0.25);
        shard.rotation.x = (idx % 2 === 0 ? 0.3 : -0.3);
        shard.position.set(side * 0.44, 0.20, zPos);
        deckGroup.add(shard);
        this.dynamicGlows.push(shard);
      });
    });

    // Sub-zero frost crystal emblem on grip
    const frostRombus = new THREE.Mesh(new THREE.OctahedronGeometry(0.10), edgeMat);
    frostRombus.scale.set(1.5, 0.2, 1.5);
    frostRombus.position.set(0, 0.23, 0);
    deckGroup.add(frostRombus);

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 3. THUNDER RIDE (Angular Zigzag Lightning-Bolt Deck with Tesla Coils)
  // =========================================================================
  private buildThunderRide(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    // Central lightning body
    const mainDeck = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.04, 1.4), [
      edgeMat, edgeMat, topMat, bottomMat, edgeMat, edgeMat
    ]);
    mainDeck.position.set(0, 0.20, 0);
    deckGroup.add(mainDeck);

    // Stepped Sawtooth Lightning Flanks
    const boltMat = new THREE.MeshStandardMaterial({
      color: 0x9333ea,
      emissive: 0xc084fc,
      emissiveIntensity: 0.9,
      roughness: 0.2,
    });

    [-1, 1].forEach((side) => {
      // 3 zigzag stepped chevron wings on each side
      [-0.45, 0.0, 0.45].forEach((zPos, i) => {
        const step = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.04, 0.28), boltMat);
        step.position.set(side * (0.42 + i * 0.04), 0.20, zPos);
        step.rotation.y = side * 0.35;
        deckGroup.add(step);
      });
    });

    // Twin-Forked Lightning Nose
    [-0.18, 0.18].forEach((x) => {
      const prong = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.038, 0.45), boltMat);
      prong.position.set(x, 0.23, -0.92);
      prong.rotation.x = -0.2;
      prong.rotation.y = (x > 0 ? 0.15 : -0.15);
      deckGroup.add(prong);
    });

    // Split Lightning Tail
    [-0.16, 0.16].forEach((x) => {
      const prong = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.038, 0.40), boltMat);
      prong.position.set(x, 0.23, 0.88);
      prong.rotation.x = 0.2;
      deckGroup.add(prong);
    });

    // Copper Tesla Induction Coils on sides
    const copperMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.9,
      roughness: 0.2,
      emissive: 0xd97706,
      emissiveIntensity: 0.5,
    });

    [-1, 1].forEach((side) => {
      const coil = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.5, 12), copperMat);
      coil.rotation.x = Math.PI / 2;
      coil.position.set(side * 0.38, 0.17, 0);
      deckGroup.add(coil);
    });

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 4. NEON GLOW (Futuristic Curved Hourglass Cyber-Deck with Light Pipes)
  // =========================================================================
  private buildNeonGlow(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    // Curved Hourglass Cyber Body: 3 interconnected rounded segments
    const waist = new THREE.Mesh(new THREE.BoxGeometry(0.64, 0.038, 0.6), topMat);
    waist.position.set(0, 0.20, 0);
    deckGroup.add(waist);

    const frontBulge = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.038, 0.55), topMat);
    frontBulge.position.set(0, 0.205, -0.5);
    deckGroup.add(frontBulge);

    const rearBulge = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.038, 0.55), topMat);
    rearBulge.position.set(0, 0.205, 0.5);
    deckGroup.add(rearBulge);

    // Swept Cyber-Blade Nose
    const cyberNose = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.036, 16, 1, false, 0, Math.PI), bottomMat);
    cyberNose.rotation.x = -Math.PI / 2;
    cyberNose.position.set(0, 0.22, -0.82);
    deckGroup.add(cyberNose);

    // Continuous Glowing Neon Tube Light-Piping along rails
    const tubeMat = new THREE.MeshBasicMaterial({ color: 0x4ade80 });
    [-1, 1].forEach((side) => {
      const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.8, 8), tubeMat);
      tube.rotation.x = Math.PI / 2;
      tube.position.set(side * 0.40, 0.21, 0);
      deckGroup.add(tube);
    });

    // Cyberpunk Rear Light-Diffuser Fins
    [-0.25, 0.25].forEach((x) => {
      const fin = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.12, 0.35), tubeMat);
      fin.position.set(x, 0.24, 0.90);
      fin.rotation.x = 0.25;
      deckGroup.add(fin);
    });

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 5. LAVA RUSH (Heavy Volcanic Rock Slab Deck with Glowing Magma Fissures)
  // =========================================================================
  private buildLavaRush(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    const rockMat = new THREE.MeshStandardMaterial({
      color: 0x262626,
      roughness: 0.95,
      metalness: 0.1,
    });

    const magmaMat = new THREE.MeshStandardMaterial({
      color: 0xea580c,
      emissive: 0xf97316,
      emissiveIntensity: 1.2,
      roughness: 0.2,
    });

    // Heavy Chunky Basalt Rock Slab (Height 0.065m vs normal 0.038m)
    const slab = new THREE.Mesh(new THREE.BoxGeometry(0.80, 0.065, 1.55), rockMat);
    slab.position.set(0, 0.20, 0);
    deckGroup.add(slab);

    // Heavy blunt stone nose bumper
    const stoneNose = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.07, 0.35), rockMat);
    stoneNose.position.set(0, 0.22, -0.88);
    stoneNose.rotation.x = -0.15;
    deckGroup.add(stoneNose);

    // Heavy stone tail block
    const stoneTail = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.07, 0.35), rockMat);
    stoneTail.position.set(0, 0.22, 0.88);
    stoneTail.rotation.x = 0.15;
    deckGroup.add(stoneTail);

    // 5 Glowing Magma Fissure Trenches cut into the rock
    [-0.5, -0.25, 0.0, 0.25, 0.5].forEach((z, i) => {
      const fissure = new THREE.Mesh(new THREE.BoxGeometry(0.65 - (i % 2) * 0.15, 0.015, 0.04), magmaMat);
      fissure.position.set((i % 2 === 0 ? 0.04 : -0.04), 0.235, z);
      fissure.rotation.y = (i % 2 === 0 ? 0.15 : -0.15);
      deckGroup.add(fissure);
    });

    // Molten Magma Side Plates
    [-1, 1].forEach((side) => {
      const sideFissure = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 1.2), magmaMat);
      sideFissure.position.set(side * 0.405, 0.20, 0);
      deckGroup.add(sideFissure);
    });

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 6. WOODEN CLASSIC (Traditional Wooden Teardrop Pintail Longboard - FREE)
  // =========================================================================
  private buildWoodenClassic(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    const woodTopMat = new THREE.MeshStandardMaterial({
      color: 0x92400e, // Rich amber maple woodgrain
      roughness: 0.65,
      metalness: 0.05,
    });

    const woodEdgeMat = new THREE.MeshStandardMaterial({
      color: 0xfef08a, // 7-ply birch laminated ply edge
      roughness: 0.5,
      metalness: 0.1,
    });

    // Authentic surfboard pintail longboard: Broad midsection narrowing to tapered pintail
    const midSection = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.036, 1.1), [
      woodEdgeMat, woodEdgeMat, woodTopMat, woodTopMat, woodEdgeMat, woodEdgeMat
    ]);
    midSection.position.set(0, 0.20, -0.1);
    deckGroup.add(midSection);

    // Broad rounded cruiser nose
    const nose = new THREE.Mesh(new THREE.CylinderGeometry(0.37, 0.37, 0.036, 16, 1, false, 0, Math.PI), woodTopMat);
    nose.rotation.x = -Math.PI / 2;
    nose.position.set(0, 0.21, -0.68);
    deckGroup.add(nose);

    // Tapered teardrop pintail (narrowing towards rear)
    const pintail = new THREE.Mesh(new THREE.ConeGeometry(0.36, 0.85, 4), woodTopMat);
    pintail.rotation.x = Math.PI / 2;
    pintail.rotation.y = Math.PI / 4;
    pintail.position.set(0, 0.21, 0.85);
    deckGroup.add(pintail);

    // Center Mahogany Racing Stringer Line down entire length
    const stringerMat = new THREE.MeshStandardMaterial({
      color: 0x451a03,
      roughness: 0.4,
    });
    const stringer = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.038, 2.0), stringerMat);
    stringer.position.set(0, 0.202, 0);
    deckGroup.add(stringer);

    // Vintage Golden Heritage Crown Emblem
    const badge = new THREE.Mesh(new THREE.CircleGeometry(0.12, 16), edgeMat);
    badge.rotation.x = -Math.PI / 2;
    badge.position.set(0, 0.222, -0.2);
    deckGroup.add(badge);

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 7. GALAXY (Futuristic Cosmic Aero-Saucer Deck with 3D Planetary Rings)
  // =========================================================================
  private buildGalaxy(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    // Cosmic Saucer Wing Body
    const wingDeck = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.038, 24), topMat);
    wingDeck.scale.set(0.9, 1.0, 2.1);
    wingDeck.position.set(0, 0.20, 0);
    deckGroup.add(wingDeck);

    // Swept side aero pods
    [-1, 1].forEach((side) => {
      const pod = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.2, 12), edgeMat);
      pod.rotation.x = Math.PI / 2;
      pod.position.set(side * 0.42, 0.20, 0);
      deckGroup.add(pod);
    });

    // 3D Planetary Ring Arches (Torus ring circling deck waist)
    const ringMat = new THREE.MeshStandardMaterial({
      color: 0xd8b4fe,
      emissive: 0xc084fc,
      emissiveIntensity: 0.8,
      metalness: 0.8,
      roughness: 0.2,
    });
    const planetRing = new THREE.Mesh(new THREE.TorusGeometry(0.48, 0.022, 8, 32), ringMat);
    planetRing.rotation.x = Math.PI / 3;
    planetRing.rotation.y = 0.3;
    planetRing.position.set(0, 0.22, 0);
    deckGroup.add(planetRing);

    // Floating Celestial Star Crystal in center
    const starOrb = new THREE.Mesh(new THREE.OctahedronGeometry(0.09), ringMat);
    starOrb.position.set(0, 0.26, -0.1);
    deckGroup.add(starOrb);
    this.dynamicGlows.push(starOrb);

    // Dual Cosmic Ion Thruster Pods at rear
    [-0.2, 0.2].forEach((x) => {
      const thruster = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 0.25, 12), edgeMat);
      thruster.rotation.x = Math.PI / 2;
      thruster.position.set(x, 0.19, 0.95);
      deckGroup.add(thruster);
    });

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 8. CAMO FORCE (Military Tactical Armored Deck with Steel Bull-Bar)
  // =========================================================================
  private buildCamoForce(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    // Heavy Armored Chamfered Deck
    const armorDeck = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.045, 1.5), topMat);
    armorDeck.position.set(0, 0.20, 0);
    deckGroup.add(armorDeck);

    // Heavy Tubular Steel Roll-Cage Bull-Bar Bumper on Nose
    const steelMat = new THREE.MeshStandardMaterial({
      color: 0x3f6212,
      metalness: 0.9,
      roughness: 0.3,
    });

    const bullBar = new THREE.Mesh(new THREE.TorusGeometry(0.36, 0.035, 8, 16, Math.PI), steelMat);
    bullBar.rotation.x = -Math.PI / 2;
    bullBar.position.set(0, 0.24, -0.85);
    deckGroup.add(bullBar);

    // Bull-bar center uprights
    [-0.18, 0.18].forEach((x) => {
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.18, 8), steelMat);
      post.position.set(x, 0.22, -0.82);
      deckGroup.add(post);
    });

    // Riveted Side Armor Skirts with Hex Bolt Studs
    [-1, 1].forEach((side) => {
      const skirt = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.08, 1.3), edgeMat);
      skirt.position.set(side * 0.41, 0.18, 0);
      deckGroup.add(skirt);

      // 4 hex rivets per side
      [-0.45, -0.15, 0.15, 0.45].forEach((z) => {
        const rivet = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.015, 6), steelMat);
        rivet.rotation.z = Math.PI / 2;
        rivet.position.set(side * 0.435, 0.18, z);
        deckGroup.add(rivet);
      });
    });

    // Tactical Rear Tow Hooks
    [-0.2, 0.2].forEach((x) => {
      const hook = new THREE.Mesh(new THREE.TorusGeometry(0.04, 0.015, 8, 12), steelMat);
      hook.position.set(x, 0.18, 0.88);
      deckGroup.add(hook);
    });

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 9. SKULL RIDER (Aggressive Dark Batwing Deck with 3D Sculpted Skull Nose)
  // =========================================================================
  private buildSkullRider(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    // Dark batwing silhouette deck
    const mainDeck = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.04, 1.4), topMat);
    mainDeck.position.set(0, 0.20, 0);
    deckGroup.add(mainDeck);

    // Flared Bone Spur Fins on sides
    const boneMat = new THREE.MeshStandardMaterial({
      color: 0xd4d4d8,
      roughness: 0.4,
      metalness: 0.3,
    });

    [-1, 1].forEach((side) => {
      [-0.4, 0.0, 0.4].forEach((zPos, i) => {
        const spur = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.20, 4), boneMat);
        spur.rotation.z = side * (Math.PI / 2 + 0.35);
        spur.rotation.y = -side * 0.3;
        spur.position.set(side * 0.42, 0.20, zPos);
        deckGroup.add(spur);
      });
    });

    // 3D Sculpted Skull Relief on Front Nose
    const skullGroup = new THREE.Group();
    const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 12), boneMat);
    cranium.scale.set(1.1, 0.85, 1.0);
    skullGroup.add(cranium);

    const maxilla = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.10, 0.12), boneMat);
    maxilla.position.set(0, -0.07, -0.04);
    skullGroup.add(maxilla);

    // Glowing Blood-Red Eye Sockets
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    [-0.055, 0.055].forEach((x) => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.028, 8, 8), eyeMat);
      eye.position.set(x, 0.01, -0.12);
      skullGroup.add(eye);
    });

    skullGroup.position.set(0, 0.28, -0.85);
    skullGroup.rotation.x = -0.25;
    deckGroup.add(skullGroup);

    // Segmented Spinal Vertebrae Column running down grip tape
    for (let i = -3; i <= 3; i++) {
      const vertebra = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.015, 0.09), boneMat);
      vertebra.position.set(0, 0.222, i * 0.16);
      deckGroup.add(vertebra);
    }

    // Dual Bone Exhaust Pipes at tail
    [-0.2, 0.2].forEach((x) => {
      const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.35, 12), edgeMat);
      pipe.rotation.x = Math.PI / 2 - 0.2;
      pipe.position.set(x, 0.22, 0.92);
      deckGroup.add(pipe);
    });

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 10. ELECTRO BLUE (Sleek Aerodynamic Nano-Blade with Quantum Capacitors)
  // =========================================================================
  private buildElectroBlue(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    // Sharp nano-blade deck with chisel nose
    const bladeDeck = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.038, 1.45), topMat);
    bladeDeck.position.set(0, 0.20, 0);
    deckGroup.add(bladeDeck);

    // Aerodynamic Chisel Nose
    const chiselNose = new THREE.Mesh(new THREE.ConeGeometry(0.37, 0.45, 4), edgeMat);
    chiselNose.rotation.x = -Math.PI / 2;
    chiselNose.rotation.y = Math.PI / 4;
    chiselNose.position.set(0, 0.21, -0.92);
    deckGroup.add(chiselNose);

    // Dual Blue Quantum Capacitor Cylinders with Copper Coils
    const capMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      emissive: 0x38bdf8,
      emissiveIntensity: 0.8,
      metalness: 0.8,
      roughness: 0.2,
    });

    [-1, 1].forEach((side) => {
      const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.8, 12), capMat);
      cap.rotation.x = Math.PI / 2;
      cap.position.set(side * 0.40, 0.21, 0);
      deckGroup.add(cap);

      // Gold PCB Circuit Traces
      const traceMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
      const trace = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.005, 0.9), traceMat);
      trace.position.set(side * 0.28, 0.222, 0);
      deckGroup.add(trace);
    });

    // Central Microchip Processor on grip tape
    const chipMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      emissive: 0x38bdf8,
      emissiveIntensity: 0.6,
      metalness: 0.9,
    });
    const chip = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.015, 0.18), chipMat);
    chip.position.set(0, 0.223, 0);
    deckGroup.add(chip);

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 11. DRAGON FIRE (Dragon-Inspired Curved Deck with 3D Dragon Head Prow)
  // =========================================================================
  private buildDragonFire(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    // Serpentine curved body
    const mainDeck = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.04, 1.45), topMat);
    mainDeck.position.set(0, 0.20, 0);
    deckGroup.add(mainDeck);

    // Scalloped Dragon-Scale Armor Shingles on flanks
    const scaleMat = new THREE.MeshStandardMaterial({
      color: 0xc2410c,
      emissive: 0xf59e0b,
      emissiveIntensity: 0.6,
      roughness: 0.3,
    });

    [-1, 1].forEach((side) => {
      for (let i = -3; i <= 3; i++) {
        const shingle = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.16, 3), scaleMat);
        shingle.rotation.z = side * Math.PI / 2;
        shingle.rotation.x = 0.2;
        shingle.position.set(side * 0.42, 0.20, i * 0.20);
        deckGroup.add(shingle);
      }
    });

    // 3D Sculpted Dragon Head Prow on Nose
    const dragonHead = new THREE.Group();
    const snout = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.14, 0.38), scaleMat);
    dragonHead.add(snout);

    // Twin Golden Horns
    const hornMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, metalness: 0.9, roughness: 0.2 });
    [-0.10, 0.10].forEach((x) => {
      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.28, 6), hornMat);
      horn.rotation.x = -0.6;
      horn.rotation.z = (x > 0 ? 0.3 : -0.3);
      horn.position.set(x, 0.12, 0.06);
      dragonHead.add(horn);
    });

    // Glowing Ember Nostrils
    const emberMat = new THREE.MeshBasicMaterial({ color: 0xf97316 });
    [-0.06, 0.06].forEach((x) => {
      const nostril = new THREE.Mesh(new THREE.SphereGeometry(0.02, 6, 6), emberMat);
      nostril.position.set(x, 0.02, -0.18);
      dragonHead.add(nostril);
    });

    dragonHead.position.set(0, 0.28, -0.88);
    dragonHead.rotation.x = -0.22;
    deckGroup.add(dragonHead);

    // Flared Dragon Tail Fin
    const tailFin = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.55, 3), scaleMat);
    tailFin.rotation.x = Math.PI / 2;
    tailFin.position.set(0, 0.24, 0.95);
    deckGroup.add(tailFin);

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 12. PURPLE SPARK (Sharp Stealth Chevron Deck with Plasma Prism Crystals)
  // =========================================================================
  private buildPurpleSpark(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    // Stealth Chevron / Dagger-Arrowhead Body
    const stealthDeck = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.038, 1.4), topMat);
    stealthDeck.position.set(0, 0.20, 0);
    deckGroup.add(stealthDeck);

    // Sharp Needle Stealth Nose
    const needleNose = new THREE.Mesh(new THREE.ConeGeometry(0.37, 0.65, 4), edgeMat);
    needleNose.rotation.x = -Math.PI / 2;
    needleNose.rotation.y = Math.PI / 4;
    needleNose.position.set(0, 0.21, -1.0);
    deckGroup.add(needleNose);

    // Dual Angled Rear Stealth Stabilizer Strakes
    const strakeMat = new THREE.MeshStandardMaterial({
      color: 0x9333ea,
      emissive: 0xc084fc,
      emissiveIntensity: 0.8,
      metalness: 0.7,
      roughness: 0.2,
    });

    [-1, 1].forEach((side) => {
      const strake = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.16, 0.5), strakeMat);
      strake.position.set(side * 0.41, 0.25, 0.7);
      strake.rotation.z = side * -0.3;
      strake.rotation.x = 0.2;
      deckGroup.add(strake);
    });

    // 3 Elevated Purple Plasma Prism Crystals (Octahedrons)
    [-0.35, 0.0, 0.35].forEach((z) => {
      const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(0.08), strakeMat);
      crystal.position.set(0, 0.27, z);
      deckGroup.add(crystal);
      this.dynamicGlows.push(crystal);
    });

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 13. ROCKET BOARD (SPECIAL EDITION - AERODYNAMIC ROCKET BODY + DUAL AFTERBURNERS)
  // =========================================================================
  private buildRocketBoard(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    // Rocket Fuselage Body (Aerodynamic contoured skateboard platform)
    const fuselage = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.045, 1.45), [
      edgeMat, edgeMat, topMat, bottomMat, edgeMat, edgeMat
    ]);
    fuselage.position.set(0, 0.20, 0);
    deckGroup.add(fuselage);

    // Prominent Aerodynamic Rocket Nosecone at Front
    const rocketMat = new THREE.MeshStandardMaterial({
      color: 0xdc2626, // Red rocket racing nose
      metalness: 0.8,
      roughness: 0.25,
      emissive: 0xef4444,
      emissiveIntensity: 0.4,
    });

    const nosecone = new THREE.Mesh(new THREE.ConeGeometry(0.39, 0.65, 16), rocketMat);
    nosecone.rotation.x = -Math.PI / 2;
    nosecone.position.set(0, 0.215, -1.02);
    deckGroup.add(nosecone);

    // Delta Swept Canards / Wings on Flanks
    const wingMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      metalness: 0.85,
      roughness: 0.2,
    });

    [-1, 1].forEach((side) => {
      const wing = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.02, 0.8), wingMat);
      wing.position.set(side * 0.50, 0.20, 0.1);
      wing.rotation.y = side * -0.25;
      deckGroup.add(wing);
    });

    // Vertical Dorsal Stabilizer Fin
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.22, 0.45), rocketMat);
    fin.position.set(0, 0.32, 0.7);
    deckGroup.add(fin);

    // =======================================================================
    // TWO PROMINENT ROCKET BOOSTER ENGINES AT REAR
    // =======================================================================
    const turbineMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      metalness: 0.95,
      roughness: 0.2,
    });

    const nozzleMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      emissive: 0xf97316,
      emissiveIntensity: 1.0,
      metalness: 0.9,
    });

    const flameOuterMat = new THREE.MeshBasicMaterial({
      color: 0xf97316,
      transparent: true,
      opacity: 0.85,
    });

    const flameInnerMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.95,
    });

    [-0.22, 0.22].forEach((x) => {
      // 1. Heavy Rocket Turbine Housing
      const turbine = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.55, 16), turbineMat);
      turbine.rotation.x = Math.PI / 2;
      turbine.position.set(x, 0.20, 0.85);
      deckGroup.add(turbine);

      // 2. Rocket Exhaust Nozzle Cone
      const nozzle = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.18, 16, 1, true), nozzleMat);
      nozzle.rotation.x = -Math.PI / 2;
      nozzle.position.set(x, 0.20, 1.15);
      deckGroup.add(nozzle);

      // 3. Glowing Combustion Chamber Ring
      const glowRing = new THREE.Mesh(new THREE.TorusGeometry(0.09, 0.02, 8, 16), nozzleMat);
      glowRing.position.set(x, 0.20, 1.14);
      deckGroup.add(glowRing);

      // 4. ANIMATED ROCKET AFTERBURNER FLAMES
      // Outer Orange Rocket Flame
      const outerFlame = new THREE.Mesh(new THREE.ConeGeometry(0.10, 0.65, 12), flameOuterMat);
      outerFlame.rotation.x = Math.PI / 2;
      outerFlame.position.set(x, 0.20, 1.48);
      deckGroup.add(outerFlame);
      this.thrusterFlames.push(outerFlame);

      // Inner Supersonic Blue Plasma Core
      const innerFlame = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.45, 8), flameInnerMat);
      innerFlame.rotation.x = Math.PI / 2;
      innerFlame.position.set(x, 0.20, 1.38);
      deckGroup.add(innerFlame);
      this.thrusterFlames.push(innerFlame);
    });

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 14. TIGER STRIKE (Aggressive Racing Beast Deck with Twin Saber Fangs & Spoiler)
  // =========================================================================
  private buildTigerStrike(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    // Muscular predatory racing body
    const mainDeck = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.04, 1.45), topMat);
    mainDeck.position.set(0, 0.20, 0);
    deckGroup.add(mainDeck);

    // TWIN CURVED SABER-TOOTH TIGER FANGS extending from front nose
    const fangMat = new THREE.MeshStandardMaterial({
      color: 0xfef08a,
      roughness: 0.2,
      metalness: 0.4,
      emissive: 0xfbbf24,
      emissiveIntensity: 0.3,
    });

    [-0.24, 0.24].forEach((x) => {
      const fang = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.42, 8), fangMat);
      fang.rotation.x = -Math.PI / 2 + 0.2;
      fang.rotation.z = (x > 0 ? 0.15 : -0.15);
      fang.position.set(x, 0.21, -0.96);
      deckGroup.add(fang);
    });

    // Aerodynamic Racing Sponsons on flanks
    [-1, 1].forEach((side) => {
      const sponson = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.038, 0.9), edgeMat);
      sponson.position.set(side * 0.44, 0.20, 0);
      deckGroup.add(sponson);
    });

    // AERODYNAMIC DUAL-TIER RACING SPOILER / WING MOUNTED ON TAIL
    const spoilerMat = new THREE.MeshStandardMaterial({
      color: 0x1c1917,
      metalness: 0.8,
      roughness: 0.3,
    });

    // Spoiler wing plate
    const wingPlate = new THREE.Mesh(new THREE.BoxGeometry(0.88, 0.025, 0.22), spoilerMat);
    wingPlate.position.set(0, 0.36, 0.86);
    wingPlate.rotation.x = 0.15;
    deckGroup.add(wingPlate);

    // Spoiler upright mounts
    [-0.25, 0.25].forEach((x) => {
      const strut = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.16, 8), edgeMat);
      strut.position.set(x, 0.28, 0.84);
      deckGroup.add(strut);
    });

    // Tiger Stripe grip tape decals
    const stripeMat = new THREE.MeshBasicMaterial({ color: 0x000000 });
    [-0.3, -0.1, 0.1, 0.3].forEach((z, i) => {
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.45 - (i % 2) * 0.1, 0.005, 0.04), stripeMat);
      stripe.position.set(0, 0.222, z);
      stripe.rotation.y = (i % 2 === 0 ? 0.25 : -0.25);
      deckGroup.add(stripe);
    });

    this.group.add(deckGroup);
  }

  // =========================================================================
  // 15. DIAMOND (Premium Brilliant-Cut Crystal Gemstone Deck with Shimmering Facets)
  // =========================================================================
  private buildDiamond(topMat: THREE.Material, bottomMat: THREE.Material, edgeMat: THREE.Material) {
    const deckGroup = new THREE.Group();

    const diamondMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.1,
      metalness: 0.8,
      emissive: 0x38bdf8,
      emissiveIntensity: 0.9,
      transparent: true,
      opacity: 0.9,
    });

    const platinumMat = new THREE.MeshStandardMaterial({
      color: 0xe0f2fe,
      roughness: 0.1,
      metalness: 0.95,
      emissive: 0xbae6fd,
      emissiveIntensity: 0.5,
    });

    // Multi-Faceted Brilliant-Cut Gemstone Deck (Octagonal diamond prism)
    const gemDeck = new THREE.Mesh(new THREE.CylinderGeometry(0.40, 0.40, 0.045, 8), diamondMat);
    gemDeck.scale.set(0.95, 1.0, 2.2);
    gemDeck.position.set(0, 0.20, 0);
    deckGroup.add(gemDeck);

    // Faceted Crystal Arrowhead Nose
    const gemNose = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.55, 8), diamondMat);
    gemNose.rotation.x = -Math.PI / 2;
    gemNose.position.set(0, 0.21, -1.02);
    deckGroup.add(gemNose);

    // Faceted Gemstone Tail Wedge
    const gemTail = new THREE.Mesh(new THREE.ConeGeometry(0.35, 0.45, 8), diamondMat);
    gemTail.rotation.x = Math.PI / 2;
    gemTail.position.set(0, 0.21, 1.0);
    deckGroup.add(gemTail);

    // Row of 3D Octahedron Diamond Crystals along center spine
    [-0.4, -0.15, 0.1, 0.35].forEach((z) => {
      const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.07), platinumMat);
      gem.position.set(0, 0.27, z);
      deckGroup.add(gem);
      this.dynamicGlows.push(gem);
    });

    // Platinum Beveled Edge Trim
    [-1, 1].forEach((side) => {
      const trim = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 1.8), platinumMat);
      trim.position.set(side * 0.40, 0.21, 0);
      deckGroup.add(trim);
    });

    this.group.add(deckGroup);
  }

  // =========================================================================
  // RUNNING GEAR: Trucks, Axles, 4 Large Urethane Wheels & Hubs
  // =========================================================================
  private buildRunningGear(trucksMat: THREE.Material, wheelMat: THREE.Material, wheelGlowMat: THREE.Material) {
    const truckZPositions = [-0.62, 0.62];

    truckZPositions.forEach((z) => {
      // Baseplate
      const baseplate = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.04, 0.24), trucksMat);
      baseplate.position.set(0, 0.165, z);
      this.group.add(baseplate);

      // Kingpin hanger / pivot
      const hanger = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.10, 8), trucksMat);
      hanger.position.set(0, 0.125, z);
      this.group.add(hanger);

      // Axle bar
      const axle = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.024, 0.88, 12), trucksMat);
      axle.rotation.z = Math.PI / 2;
      axle.position.set(0, 0.10, z);
      this.group.add(axle);
    });

    // 4 Distinct Wheels
    const wheelRadius = 0.11;
    const wheelWidth = 0.09;
    const wheelPositions = [
      { x: -0.42, y: 0.10, z: -0.62 },
      { x: 0.42, y: 0.10, z: -0.62 },
      { x: -0.42, y: 0.10, z: 0.62 },
      { x: 0.42, y: 0.10, z: 0.62 },
    ];

    const wheelGeo = new THREE.CylinderGeometry(wheelRadius, wheelRadius, wheelWidth, 20);
    wheelGeo.rotateZ(Math.PI / 2);

    const rimGeo = new THREE.TorusGeometry(wheelRadius * 0.72, 0.016, 8, 16);
    rimGeo.rotateY(Math.PI / 2);

    const hubGeo = new THREE.CylinderGeometry(wheelRadius * 0.35, wheelRadius * 0.35, wheelWidth * 1.05, 12);
    hubGeo.rotateZ(Math.PI / 2);

    wheelPositions.forEach((pos) => {
      const wheelMesh = new THREE.Mesh(wheelGeo, wheelMat);
      wheelMesh.castShadow = true;
      wheelMesh.position.set(pos.x, pos.y, pos.z);

      // Rim glow ring
      const rim = new THREE.Mesh(rimGeo, wheelGlowMat);
      wheelMesh.add(rim);

      // Chrome hubcap
      const hub = new THREE.Mesh(hubGeo, trucksMat);
      wheelMesh.add(hub);

      this.group.add(wheelMesh);
      this.wheels.push(wheelMesh);
    });
  }

  public triggerLandingBurst() {
    this.powerEffects?.triggerLandingBurst();
  }

  // =========================================================================
  // ANIMATION LOOP UPDATE: Dynamic Wheel Spin, Thruster Flames & Gem Oscillations
  // =========================================================================
  public update(delta: number, speed: number, motion?: SkateboardMotionState) {
    // 1. Spin wheels proportional to runner speed
    const spinDelta = speed * delta * 7.5;
    this.wheelSpinAngle += spinDelta;

    for (const w of this.wheels) {
      w.rotation.x = this.wheelSpinAngle;
    }

    // 2. Animated Rocket Thruster / Afterburner Flame Flicker
    this.pulseTimer += delta * 16;
    if (this.thrusterFlames.length > 0) {
      const pulse = 0.85 + Math.sin(this.pulseTimer) * 0.30;
      const lengthFlicker = 1.0 + Math.cos(this.pulseTimer * 1.8) * 0.35;
      for (const flame of this.thrusterFlames) {
        flame.scale.set(pulse, lengthFlicker, pulse);
      }
    }

    // 3. Dynamic Crystal / Gem Shimmer & Oscillation
    if (this.dynamicGlows.length > 0) {
      const crystalPulse = 1.0 + Math.sin(this.pulseTimer * 0.6) * 0.12;
      for (const g of this.dynamicGlows) {
        g.scale.set(crystalPulse, crystalPulse, crystalPulse);
        g.rotation.y += delta * 1.5;
      }
    }

    // 4. Subtle Carving Roll Sway
    this.group.rotation.z = Math.sin(Date.now() * 0.006) * 0.03;

    // 5. Update Real-Time 3D Skateboard Power Effects (Swinging ribbon, lightning arcs, sparks)
    if (this.powerEffects) {
      this.powerEffects.update(delta, speed, motion);
    }
  }
}
