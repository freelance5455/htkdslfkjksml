import * as THREE from 'three';
import { BossDef } from '../types/gameTypes';
import { getTerrainHeight } from '../world/TerrainMath';

function addBossEyes(parent: THREE.Object3D, xOffset: number, y: number, z: number, radius: number, color: string) {
  const mat = new THREE.MeshStandardMaterial({
    color,
    emissive: color,
    emissiveIntensity: 1.8,
    roughness: 0.1,
  });
  for (const s of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(radius, 10, 10), mat);
    eye.position.set(s * xOffset, y, z);
    parent.add(eye);
  }
}

export function buildBossModel(def: BossDef): THREE.Group {
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  root.userData.body = body;
  root.userData.wings = [] as THREE.Object3D[];
  root.userData.limbs = [] as THREE.Object3D[];
  root.userData.weapon = null as THREE.Object3D | null;
  root.userData.aura = null as THREE.Object3D | null;

  const pMat = new THREE.MeshStandardMaterial({ color: def.primaryColor, roughness: 0.45, metalness: 0.35 });
  const aMat = new THREE.MeshStandardMaterial({
    color: def.accentColor,
    emissive: def.accentColor,
    emissiveIntensity: 0.72,
    roughness: 0.25,
    metalness: 0.45,
  });
  const metalMat = new THREE.MeshStandardMaterial({ color: '#eab308', metalness: 0.88, roughness: 0.18 });
  const darkIron = new THREE.MeshStandardMaterial({ color: '#1e293b', metalness: 0.85, roughness: 0.25 });
  const ivory = new THREE.MeshStandardMaterial({ color: '#fef3c7', roughness: 0.45 });

  // Ground runic boss aura ring
  const auraRing = new THREE.Mesh(
    new THREE.RingGeometry(2.6, 3.15, 32),
    new THREE.MeshBasicMaterial({
      color: def.accentColor,
      transparent: true,
      opacity: 0.42,
      side: THREE.DoubleSide,
    })
  );
  auraRing.rotation.x = -Math.PI / 2;
  auraRing.position.y = 0.08;
  root.add(auraRing);
  root.userData.aura = auraRing;

  if (def.id === 'boss_red_dragon' || def.id === 'boss_ice_dragon') {
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(1.3, 3.6, 12, 16), pMat);
    torso.rotation.x = Math.PI / 2;
    torso.position.y = 2.7;
    body.add(torso);

    // Armored belly scales
    for (let i = -2; i <= 2; i++) {
      const scalePlate = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.32, 0.72), aMat);
      scalePlate.position.set(0, 1.82, i * 0.78);
      body.add(scalePlate);
    }

    // Dorsal spine ridge spikes
    for (let i = 0; i < 8; i++) {
      const spine = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.72, 5), aMat);
      spine.position.set(0, 4.15 - i * 0.08, 1.9 - i * 0.65);
      spine.rotation.x = -0.35;
      body.add(spine);
    }

    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.92, 2.5, 12), pMat);
    neck.position.set(0, 4.25, 2.25);
    neck.rotation.x = 0.46;
    body.add(neck);

    // Dragon head + snout + articulated jaw + glowing breath core
    const head = new THREE.Mesh(new THREE.BoxGeometry(1.22, 0.85, 1.55), pMat);
    head.position.set(0, 5.45, 3.25);
    body.add(head);

    const snout = new THREE.Mesh(new THREE.BoxGeometry(0.86, 0.52, 1.05), pMat);
    snout.position.set(0, 5.38, 4.35);
    body.add(snout);

    const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.28, 1.15), darkIron);
    jaw.position.set(0, 4.92, 4.15);
    jaw.rotation.x = 0.18;
    body.add(jaw);

    const breathCore = new THREE.Mesh(new THREE.SphereGeometry(0.28, 10, 10), aMat);
    breathCore.position.set(0, 5.15, 4.35);
    body.add(breathCore);

    addBossEyes(body, 0.42, 5.64, 3.9, 0.14, def.accentColor);

    for (const s of [-1, 1]) {
      const fang = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.36, 5), ivory);
      fang.rotation.x = Math.PI;
      fang.position.set(s * 0.26, 5.12, 4.72);
      body.add(fang);

      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.2, 1.55, 7), aMat);
      horn.position.set(s * 0.5, 6.22, 2.85);
      horn.rotation.x = -0.52;
      horn.rotation.z = s * -0.2;
      body.add(horn);

      const cheekHorn = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.72, 5), metalMat);
      cheekHorn.position.set(s * 0.65, 5.32, 2.7);
      cheekHorn.rotation.z = s * -1.1;
      body.add(cheekHorn);

      // Multi-spar swept dragon wing
      const wingPivot = new THREE.Group();
      wingPivot.position.set(s * 1.15, 3.55, 0.5);

      const innerArm = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, 2.6, 8), pMat);
      innerArm.rotation.z = Math.PI / 2;
      innerArm.position.set(s * 1.3, 0.35, 0.4);
      wingPivot.add(innerArm);

      const outerArm = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.16, 2.9, 8), pMat);
      outerArm.rotation.z = Math.PI / 2;
      outerArm.position.set(s * 3.7, 0.42, -0.15);
      outerArm.rotation.y = s * -0.25;
      wingPivot.add(outerArm);

      const innerMem = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.08, 2.2), aMat);
      innerMem.position.set(s * 1.4, 0.2, -0.55);
      wingPivot.add(innerMem);

      const outerMem = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.07, 1.75), aMat);
      outerMem.position.set(s * 3.85, 0.22, -0.85);
      outerMem.rotation.y = s * -0.28;
      wingPivot.add(outerMem);

      for (let f = 0; f < 3; f++) {
        const finger = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.03, 2.2, 6), darkIron);
        finger.rotation.x = Math.PI / 2;
        finger.rotation.z = s * (0.25 + f * 0.35);
        finger.position.set(s * (2.5 + f * 0.9), 0.28, -0.65);
        wingPivot.add(finger);
      }

      body.add(wingPivot);
      root.userData.wings.push(wingPivot);
    }

    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.68, 4.4, 8), pMat);
    tail.rotation.x = -Math.PI / 2.2;
    tail.position.set(0, 2.1, -3.7);
    body.add(tail);

    const tailTip = new THREE.Mesh(new THREE.OctahedronGeometry(0.55, 0), aMat);
    tailTip.position.set(0, 1.65, -5.85);
    body.add(tailTip);

    for (const [lx, lz] of [[-1.02, 1.35], [1.02, 1.35], [-1.02, -1.35], [1.02, -1.35]]) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.28, 2.05, 8), pMat);
      leg.position.set(lx, 1.02, lz);
      body.add(leg);
      const claw = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.28, 0.72), darkIron);
      claw.position.set(lx, 0.14, lz + 0.18);
      body.add(claw);
      root.userData.limbs.push(leg);
    }
  } else if (def.id === 'boss_forest_king') {
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(1.18, 1.88, 4.9, 12), pMat);
    trunk.position.y = 2.45;
    body.add(trunk);

    const heartCrystal = new THREE.Mesh(new THREE.OctahedronGeometry(0.75, 0), aMat);
    heartCrystal.position.set(0, 3.1, 1.15);
    body.add(heartCrystal);

    addBossEyes(body, 0.42, 4.35, 1.05, 0.14, '#fde047');

    // Antler crown
    for (const s of [-1, 1]) {
      const antler = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.22, 2.2, 6), pMat);
      antler.position.set(s * 0.95, 5.8, 0.35);
      antler.rotation.z = s * -0.45;
      body.add(antler);
    }

    // Multi-layered ancient canopy
    const canopy1 = new THREE.Mesh(new THREE.DodecahedronGeometry(2.55, 1), aMat);
    canopy1.position.y = 5.65;
    body.add(canopy1);
    const canopy2 = new THREE.Mesh(new THREE.DodecahedronGeometry(1.75, 1), pMat);
    canopy2.position.set(0.9, 6.45, -0.4);
    body.add(canopy2);

    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const rootLeg = new THREE.Mesh(new THREE.ConeGeometry(0.48, 2.4, 6), pMat);
      rootLeg.position.set(Math.cos(a) * 1.55, 0.78, Math.sin(a) * 1.55);
      rootLeg.rotation.z = Math.cos(a) * 0.42;
      body.add(rootLeg);
    }
    for (const s of [-1, 1]) {
      const armPivot = new THREE.Group();
      armPivot.position.set(s * 1.65, 3.8, 0.2);
      const branchArm = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.46, 3.2, 8), pMat);
      branchArm.position.set(s * 0.45, -1.2, 0.25);
      branchArm.rotation.z = s * 0.25;
      armPivot.add(branchArm);
      const fist = new THREE.Mesh(new THREE.DodecahedronGeometry(0.65, 0), aMat);
      fist.position.set(s * 0.75, -2.75, 0.45);
      armPivot.add(fist);
      body.add(armPivot);
      root.userData.limbs.push(armPivot);
      if (s === 1) root.userData.weapon = armPivot;
    }
  } else if (def.id === 'boss_ghost_queen') {
    const gown = new THREE.Mesh(
      new THREE.ConeGeometry(1.5, 4.4, 14, 1, true),
      new THREE.MeshStandardMaterial({
        color: def.primaryColor,
        emissive: def.primaryColor,
        emissiveIntensity: 0.25,
        transparent: true,
        opacity: 0.88,
        side: THREE.DoubleSide,
      })
    );
    gown.position.y = 2.25;
    body.add(gown);

    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.74, 1.7, 10), pMat);
    torso.position.y = 3.9;
    body.add(torso);

    const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.35, 0), aMat);
    core.position.set(0, 4.0, 0.55);
    body.add(core);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.52, 14, 14), aMat);
    head.position.y = 5.15;
    body.add(head);

    addBossEyes(body, 0.18, 5.2, 0.45, 0.08, '#ffffff');

    const crown = new THREE.Mesh(new THREE.ConeGeometry(0.42, 0.85, 6), metalMat);
    crown.position.y = 5.85;
    body.add(crown);

    const halo = new THREE.Mesh(new THREE.TorusGeometry(1.38, 0.09, 8, 28), aMat);
    halo.position.set(0, 4.85, -0.4);
    body.add(halo);
    root.userData.wings.push(halo);

    for (const s of [-1, 1]) {
      const armPivot = new THREE.Group();
      armPivot.position.set(s * 0.75, 4.4, 0.15);
      const arm = new THREE.Mesh(new THREE.ConeGeometry(0.24, 2.0, 6), aMat);
      arm.position.set(s * 0.45, -0.6, 0.25);
      arm.rotation.z = s * 0.55;
      armPivot.add(arm);
      body.add(armPivot);
      root.userData.limbs.push(armPivot);
      if (s === 1) root.userData.weapon = armPivot;
    }
  } else {
    // Titan, Skeleton King, Goblin King, Lord of Darkness
    const s = def.id === 'boss_ancient_titan' || def.id === 'boss_lord_of_darkness' ? 1.38 : 1.18;
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(1.02 * s, 0.78 * s, 2.4 * s, 12), pMat);
    torso.position.y = 2.65 * s;
    body.add(torso);

    const chestPlate = new THREE.Mesh(new THREE.BoxGeometry(2.05 * s, 1.48 * s, 1.24 * s), darkIron);
    chestPlate.position.y = 2.95 * s;
    body.add(chestPlate);

    const chestSigil = new THREE.Mesh(new THREE.OctahedronGeometry(0.48 * s, 0), aMat);
    chestSigil.position.set(0, 3.0 * s, 0.66 * s);
    body.add(chestSigil);

    // Tattered war cape
    const cape = new THREE.Mesh(new THREE.BoxGeometry(1.9 * s, 3.1 * s, 0.12), aMat);
    cape.position.set(0, 2.15 * s, -0.82 * s);
    cape.rotation.x = 0.18;
    body.add(cape);

    const head = new THREE.Mesh(
      def.id === 'boss_skeleton_king'
        ? new THREE.SphereGeometry(0.44 * s, 12, 10)
        : new THREE.BoxGeometry(0.76 * s, 0.78 * s, 0.76 * s),
      def.id === 'boss_skeleton_king' ? ivory : pMat
    );
    head.position.y = 4.3 * s;
    body.add(head);

    addBossEyes(body, 0.18 * s, 4.35 * s, 0.38 * s, 0.08 * s, def.accentColor);

    const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.58 * s, 0.48 * s, 0.48 * s, 8), metalMat);
    crown.position.y = 4.82 * s;
    body.add(crown);

    for (const side of [-1, 1]) {
      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.14 * s, 0.95 * s, 6), aMat);
      horn.position.set(side * 0.45 * s, 5.0 * s, 0);
      horn.rotation.z = side * -0.45;
      body.add(horn);
    }

    if (def.id === 'boss_lord_of_darkness') {
      for (const side of [-1, 1]) {
        const wp = new THREE.Group();
        wp.position.set(side * 1.1, 3.6 * s, -0.55);
        const wing = new THREE.Mesh(new THREE.BoxGeometry(3.8, 1.8, 0.14), aMat);
        wing.position.x = side * 1.9;
        wing.rotation.z = side * 0.32;
        wp.add(wing);
        const spar = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.18, 4.0, 6), darkIron);
        spar.rotation.z = Math.PI / 2;
        spar.position.set(side * 1.9, 0.6, 0.08);
        wp.add(spar);
        body.add(wp);
        root.userData.wings.push(wp);
      }
    }

    for (const side of [-1, 1]) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.36 * s, 0.32 * s, 1.8 * s, 10), darkIron);
      leg.position.set(side * 0.54 * s, 0.9 * s, 0);
      body.add(leg);
      root.userData.limbs.push(leg);

      // Spiked Pauldron
      const pauldron = new THREE.Mesh(new THREE.SphereGeometry(0.54 * s, 10, 8), darkIron);
      pauldron.position.set(side * 1.28 * s, 3.58 * s, 0);
      body.add(pauldron);
      const pSpike = new THREE.Mesh(new THREE.ConeGeometry(0.14 * s, 0.72 * s, 5), aMat);
      pSpike.position.set(side * 1.48 * s, 4.1 * s, 0);
      pSpike.rotation.z = side * -0.4;
      body.add(pSpike);

      const armPivot = new THREE.Group();
      armPivot.position.set(side * 1.28 * s, 3.45 * s, 0);
      const armMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.28 * s, 0.24 * s, 1.85 * s, 8), pMat);
      armMesh.position.y = -0.92 * s;
      armPivot.add(armMesh);
      body.add(armPivot);
      root.userData.limbs.push(armPivot);

      if (side === 1) {
        const wpnGroup = new THREE.Group();
        wpnGroup.position.set(0, -1.7 * s, 0.25);
        wpnGroup.rotation.x = Math.PI / 2.5;
        if (def.id === 'boss_goblin_king') {
          const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 2.8, 8), darkIron);
          shaft.position.y = 1.2;
          wpnGroup.add(shaft);
          const head = new THREE.Mesh(new THREE.BoxGeometry(1.05, 0.95, 1.1), aMat);
          head.position.y = 2.45;
          wpnGroup.add(head);
        } else {
          const blade = new THREE.Mesh(new THREE.BoxGeometry(0.32, 3.6, 0.14), metalMat);
          blade.position.y = 1.8;
          wpnGroup.add(blade);
          const coreBlade = new THREE.Mesh(new THREE.BoxGeometry(0.12, 3.2, 0.18), aMat);
          coreBlade.position.y = 1.8;
          wpnGroup.add(coreBlade);
          const guard = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.18, 0.25), darkIron);
          guard.position.y = 0.2;
          wpnGroup.add(guard);
        }
        armPivot.add(wpnGroup);
        root.userData.weapon = armPivot;
      }
    }
  }

  root.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) o.castShadow = true;
  });
  return root;
}

export function animateBossModel(model: THREE.Group, time: number, isAttacking: boolean) {
  const wings = (model.userData.wings as THREE.Object3D[]) || [];
  const limbs = (model.userData.limbs as THREE.Object3D[]) || [];
  const weapon = model.userData.weapon as THREE.Object3D | null;
  const aura = model.userData.aura as THREE.Object3D | null;

  wings.forEach((w, idx) => {
    const s = idx % 2 === 0 ? -1 : 1;
    w.rotation.z = s * Math.sin(time * 5.5) * 0.42;
  });

  limbs.forEach((l, idx) => {
    if (l === weapon) return;
    l.rotation.x = Math.sin(time * 4 + idx * Math.PI) * 0.28;
  });

  if (weapon) {
    weapon.rotation.x = isAttacking ? -Math.abs(Math.sin(time * 14)) * 1.45 : Math.sin(time * 2) * 0.14;
  }

  if (aura) {
    aura.rotation.z = time * 0.9;
  }
}

export function buildBossArena(def: BossDef): THREE.Group {
  const group = new THREE.Group();
  const baseY = getTerrainHeight(def.arenaX, def.arenaZ);
  group.position.set(def.arenaX, baseY, def.arenaZ);

  const floorMat = new THREE.MeshStandardMaterial({
    color: def.primaryColor,
    roughness: 0.78,
    metalness: 0.18,
  });
  const ringMat = new THREE.MeshStandardMaterial({
    color: def.accentColor,
    emissive: def.accentColor,
    emissiveIntensity: 0.45,
    roughness: 0.3,
  });

  const floor = new THREE.Mesh(new THREE.CylinderGeometry(def.arenaRadius, def.arenaRadius + 2.2, 0.42, 32), floorMat);
  floor.position.y = 0.05;
  floor.receiveShadow = true;
  group.add(floor);

  const runeRing = new THREE.Mesh(new THREE.TorusGeometry(def.arenaRadius - 1.5, 0.38, 8, 56), ringMat);
  runeRing.rotation.x = Math.PI / 2;
  runeRing.position.y = 0.32;
  group.add(runeRing);

  const innerRing = new THREE.Mesh(new THREE.TorusGeometry(def.arenaRadius * 0.45, 0.18, 6, 40), ringMat);
  innerRing.rotation.x = Math.PI / 2;
  innerRing.position.y = 0.3;
  group.add(innerRing);

  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2;
    const px = Math.cos(angle) * (def.arenaRadius - 1.5);
    const pz = Math.sin(angle) * (def.arenaRadius - 1.5);
    const pillar = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.45, 8.8, 8), floorMat);
    pillar.position.set(px, 4.4, pz);
    pillar.castShadow = true;
    group.add(pillar);

    const cap = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.5, 2.6), floorMat);
    cap.position.set(px, 8.85, pz);
    group.add(cap);

    const brazier = new THREE.Mesh(new THREE.OctahedronGeometry(0.95, 0), ringMat);
    brazier.position.set(px, 9.7, pz);
    group.add(brazier);
  }

  return group;
}
