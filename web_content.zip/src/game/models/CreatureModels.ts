import * as THREE from 'three';
import { CreatureDef } from '../types/gameTypes';

export function buildCreatureModel(def: CreatureDef): THREE.Group {
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  root.userData.body = body;
  root.userData.wings = [] as THREE.Object3D[];
  root.userData.legs = [] as THREE.Object3D[];

  const mainMat = new THREE.MeshStandardMaterial({ color: def.primaryColor, roughness: 0.65 });
  const accentMat = new THREE.MeshStandardMaterial({
    color: def.accentColor,
    emissive: def.accentColor,
    emissiveIntensity: def.id === 'air_jellyfish' || def.id === 'crystal_fox' || def.id === 'royal_stag' || def.id === 'moon_horse' || def.id === 'magical_butterflies' ? 0.55 : 0.08,
    roughness: 0.35,
  });

  switch (def.id) {
    case 'royal_stag': {
      const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.35, 0.9, 8, 12), mainMat);
      torso.rotation.x = Math.PI / 2;
      torso.position.y = 1.05;
      body.add(torso);
      const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.22, 0.65, 8), mainMat);
      neck.position.set(0, 1.45, 0.45);
      neck.rotation.x = 0.45;
      body.add(neck);
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.24, 0.45), mainMat);
      head.position.set(0, 1.78, 0.72);
      body.add(head);
      // Glowing branching antlers
      for (const s of [-1, 1]) {
        const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.04, 0.72, 6), accentMat);
        beam.position.set(s * 0.2, 2.1, 0.64);
        beam.rotation.z = s * -0.45;
        beam.rotation.x = -0.25;
        body.add(beam);
        const tine = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.03, 0.38, 6), accentMat);
        tine.position.set(s * 0.34, 2.25, 0.72);
        tine.rotation.z = s * -0.1;
        body.add(tine);
      }
      for (const [lx, lz] of [[-0.2, 0.4], [0.2, 0.4], [-0.2, -0.4], [0.2, -0.4]]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.04, 0.95, 6), mainMat);
        leg.position.set(lx, 0.48, lz);
        body.add(leg);
        root.userData.legs.push(leg);
      }
      break;
    }

    case 'giant_eagle': {
      const torso = new THREE.Mesh(new THREE.ConeGeometry(0.32, 1.1, 10), mainMat);
      torso.rotation.x = Math.PI / 2;
      torso.position.y = 0.8;
      body.add(torso);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 10), accentMat);
      head.position.set(0, 0.92, 0.62);
      body.add(head);
      const beak = new THREE.Mesh(
        new THREE.ConeGeometry(0.08, 0.24, 6),
        new THREE.MeshStandardMaterial({ color: '#f59e0b', roughness: 0.4 })
      );
      beak.rotation.x = Math.PI / 2;
      beak.position.set(0, 0.88, 0.86);
      body.add(beak);
      for (const s of [-1, 1]) {
        const wingPivot = new THREE.Group();
        wingPivot.position.set(s * 0.25, 0.86, 0.1);
        const inner = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.07, 0.52), mainMat);
        inner.position.x = s * 0.55;
        wingPivot.add(inner);
        const outer = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.05, 0.35), accentMat);
        outer.position.set(s * 1.35, 0, -0.08);
        wingPivot.add(outer);
        body.add(wingPivot);
        root.userData.wings.push(wingPivot);
      }
      break;
    }

    case 'crystal_fox': {
      const torso = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.34, 0.85), mainMat);
      torso.position.y = 0.48;
      body.add(torso);
      const head = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.4, 6), mainMat);
      head.rotation.x = Math.PI / 2;
      head.position.set(0, 0.66, 0.56);
      body.add(head);
      for (const s of [-1, 1]) {
        const ear = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.22, 4), accentMat);
        ear.position.set(s * 0.11, 0.86, 0.45);
        body.add(ear);
      }
      const tail = new THREE.Mesh(new THREE.OctahedronGeometry(0.24, 0), accentMat);
      tail.scale.set(0.7, 0.7, 1.8);
      tail.position.set(0, 0.58, -0.65);
      tail.rotation.x = 0.35;
      body.add(tail);
      root.userData.tail = tail;
      for (const [lx, lz] of [[-0.13, 0.3], [0.13, 0.3], [-0.13, -0.3], [0.13, -0.3]]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.035, 0.42, 6), mainMat);
        leg.position.set(lx, 0.21, lz);
        body.add(leg);
        root.userData.legs.push(leg);
      }
      break;
    }

    case 'rock_turtle': {
      const shell = new THREE.Mesh(new THREE.SphereGeometry(0.78, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.52), mainMat);
      shell.scale.set(1, 0.72, 1.2);
      shell.position.y = 0.36;
      body.add(shell);
      const mossCap = new THREE.Mesh(new THREE.DodecahedronGeometry(0.32, 0), accentMat);
      mossCap.position.set(0.12, 0.88, -0.05);
      body.add(mossCap);
      const boulder = new THREE.Mesh(new THREE.DodecahedronGeometry(0.24, 0), mainMat);
      boulder.position.set(-0.22, 0.82, 0.15);
      body.add(boulder);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 8), accentMat);
      head.position.set(0, 0.46, 0.96);
      body.add(head);
      for (const [lx, lz] of [[-0.5, 0.5], [0.5, 0.5], [-0.5, -0.5], [0.5, -0.5]]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 0.36, 8), accentMat);
        leg.position.set(lx, 0.18, lz);
        body.add(leg);
        root.userData.legs.push(leg);
      }
      break;
    }

    case 'magical_butterflies': {
      for (let i = 0; i < 4; i++) {
        const bGroup = new THREE.Group();
        const angle = (i / 4) * Math.PI * 2;
        bGroup.position.set(Math.cos(angle) * 0.6, 0.8 + (i % 2) * 0.35, Math.sin(angle) * 0.6);
        const core = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.22, 6), mainMat);
        core.rotation.x = Math.PI / 2;
        bGroup.add(core);
        for (const s of [-1, 1]) {
          const wing = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.02, 0.22), i % 2 === 0 ? mainMat : accentMat);
          wing.position.x = s * 0.14;
          bGroup.add(wing);
          root.userData.wings.push(wing);
        }
        body.add(bGroup);
      }
      break;
    }

    case 'mountain_goat': {
      const torso = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.45, 0.88), mainMat);
      torso.position.y = 0.66;
      body.add(torso);
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.26, 0.34), mainMat);
      head.position.set(0, 0.98, 0.52);
      body.add(head);
      for (const s of [-1, 1]) {
        const horn = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.035, 6, 10, Math.PI * 0.8), accentMat);
        horn.rotation.y = Math.PI / 2;
        horn.position.set(s * 0.11, 1.15, 0.44);
        body.add(horn);
      }
      for (const [lx, lz] of [[-0.14, 0.3], [0.14, 0.3], [-0.14, -0.3], [0.14, -0.3]]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.045, 0.46, 6), accentMat);
        leg.position.set(lx, 0.23, lz);
        body.add(leg);
        root.userData.legs.push(leg);
      }
      break;
    }

    case 'small_dragon': {
      const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 0.65, 8, 10), mainMat);
      torso.rotation.x = Math.PI / 2;
      torso.position.y = 0.85;
      body.add(torso);
      const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.18, 0.42, 8), mainMat);
      neck.position.set(0, 1.1, 0.42);
      neck.rotation.x = 0.4;
      body.add(neck);
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.22, 0.38), mainMat);
      head.position.set(0, 1.32, 0.64);
      body.add(head);
      for (const s of [-1, 1]) {
        const horn = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.22, 5), accentMat);
        horn.position.set(s * 0.09, 1.46, 0.55);
        horn.rotation.x = -0.4;
        body.add(horn);
        const wingPivot = new THREE.Group();
        wingPivot.position.set(s * 0.22, 1.0, 0.05);
        const wing = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.03, 0.45), accentMat);
        wing.position.x = s * 0.38;
        wingPivot.add(wing);
        body.add(wingPivot);
        root.userData.wings.push(wingPivot);
      }
      const tail = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.72, 6), mainMat);
      tail.rotation.x = -Math.PI / 2.2;
      tail.position.set(0, 0.78, -0.68);
      body.add(tail);
      break;
    }

    case 'moon_horse': {
      const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.36, 1.05, 8, 12), mainMat);
      torso.rotation.x = Math.PI / 2;
      torso.position.y = 1.15;
      body.add(torso);
      const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.25, 0.75, 8), mainMat);
      neck.position.set(0, 1.56, 0.55);
      neck.rotation.x = 0.45;
      body.add(neck);
      const mane = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.72, 0.2), accentMat);
      mane.position.set(0, 1.62, 0.42);
      mane.rotation.x = 0.45;
      body.add(mane);
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.26, 0.52), mainMat);
      head.position.set(0, 1.88, 0.85);
      head.rotation.x = 0.25;
      body.add(head);
      const tail = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.75, 8), accentMat);
      tail.position.set(0, 1.0, -0.82);
      tail.rotation.x = 0.45;
      body.add(tail);
      for (const [lx, lz] of [[-0.22, 0.48], [0.22, 0.48], [-0.22, -0.48], [0.22, -0.48]]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.06, 0.98, 8), mainMat);
        leg.position.set(lx, 0.49, lz);
        body.add(leg);
        root.userData.legs.push(leg);
      }
      break;
    }

    case 'river_otter': {
      const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.18, 0.65, 6, 10), mainMat);
      torso.rotation.x = Math.PI / 2;
      torso.position.y = 0.25;
      body.add(torso);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 8), accentMat);
      head.position.set(0, 0.34, 0.45);
      body.add(head);
      const tail = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.55, 6), mainMat);
      tail.rotation.x = -Math.PI / 2;
      tail.position.set(0, 0.22, -0.62);
      body.add(tail);
      break;
    }

    case 'air_jellyfish': {
      const bellMat = new THREE.MeshStandardMaterial({
        color: def.primaryColor,
        emissive: def.accentColor,
        emissiveIntensity: 0.65,
        transparent: true,
        opacity: 0.82,
        roughness: 0.2,
      });
      const bell = new THREE.Mesh(new THREE.SphereGeometry(0.55, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), bellMat);
      bell.position.y = 1.65;
      body.add(bell);
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        const tendril = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.01, 1.15, 6), accentMat);
        tendril.position.set(Math.cos(a) * 0.26, 1.05, Math.sin(a) * 0.26);
        body.add(tendril);
        root.userData.legs.push(tendril);
      }
      break;
    }
  }

  root.scale.setScalar(def.scale);
  root.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = true;
    }
  });
  return root;
}

export function animateCreatureModel(model: THREE.Group, def: CreatureDef, time: number, isMoving: boolean) {
  const wings = model.userData.wings as THREE.Object3D[];
  const legs = model.userData.legs as THREE.Object3D[];
  const body = model.userData.body as THREE.Group;

  if (def.flies && wings.length > 0) {
    wings.forEach((w, idx) => {
      const side = idx % 2 === 0 ? -1 : 1;
      w.rotation.z = side * Math.sin(time * 9 + idx * 0.3) * 0.55;
    });
    body.position.y = Math.sin(time * 3.2) * 0.25 + (def.id === 'giant_eagle' ? 0 : 0.3);
  } else if (def.id === 'air_jellyfish') {
    body.position.y = Math.sin(time * 2.1) * 0.35;
    legs.forEach((t, idx) => {
      t.rotation.x = Math.sin(time * 3 + idx) * 0.18;
    });
  } else {
    const swing = isMoving ? 0.5 : 0.05;
    legs.forEach((leg, idx) => {
      const sign = idx % 2 === 0 ? 1 : -1;
      leg.rotation.x = Math.sin(time * 9) * swing * sign;
    });
  }
}
