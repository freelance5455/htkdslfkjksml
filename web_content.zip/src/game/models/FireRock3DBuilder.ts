import * as THREE from 'three';

/**
 * Premium 3D Fire Rock / Rocket Rock Obstacle Builder
 *
 * A natural, jagged, cracked volcanic meteorite rock with real-time 3D fire,
 * glowing magma fissures, smoke puffs, and flying embers.
 */
export class FireRock3DBuilder {
  private static rockMat: THREE.MeshStandardMaterial | null = null;
  private static magmaMat: THREE.MeshStandardMaterial | null = null;
  private static crystalMat: THREE.MeshStandardMaterial | null = null;
  private static flameCoreMat: THREE.MeshBasicMaterial | null = null;
  private static flameMidMat: THREE.MeshBasicMaterial | null = null;
  private static flameOuterMat: THREE.MeshBasicMaterial | null = null;
  private static smokeMat: THREE.MeshBasicMaterial | null = null;
  private static emberMat: THREE.MeshBasicMaterial | null = null;

  public static initMaterials() {
    if (!this.rockMat) {
      this.rockMat = new THREE.MeshStandardMaterial({
        color: 0x27272a, // Dark Basalt Charcoal
        roughness: 0.88,
        metalness: 0.15,
        flatShading: true,
      });

      this.magmaMat = new THREE.MeshStandardMaterial({
        color: 0xf97316, // Molten Magma Orange
        emissive: 0xe11d48, // Radiant Lava Crimson
        emissiveIntensity: 0.85,
        roughness: 0.4,
        metalness: 0.2,
      });

      this.crystalMat = new THREE.MeshStandardMaterial({
        color: 0x991b1b, // Obsidian Garnet Red
        roughness: 0.18,
        metalness: 0.8,
        flatShading: true,
      });

      this.flameCoreMat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
      });

      this.flameMidMat = new THREE.MeshBasicMaterial({
        color: 0xfde047, // Radiant Golden Yellow
        transparent: true,
        opacity: 0.9,
      });

      this.flameOuterMat = new THREE.MeshBasicMaterial({
        color: 0xf97316, // Blazing Orange
        transparent: true,
        opacity: 0.75,
      });

      this.smokeMat = new THREE.MeshBasicMaterial({
        color: 0x52525b,
        transparent: true,
        opacity: 0.45,
      });

      this.emberMat = new THREE.MeshBasicMaterial({
        color: 0xfacc15,
      });
    }
  }

  public static createFireRock(): THREE.Group {
    this.initMaterials();

    const group = new THREE.Group();
    group.name = 'fire_rock_obstacle';

    // 1. COMPOUND NATURAL ROCK SHAPE (Multiple overlapping faceted geometries)
    const mainRockGeo = new THREE.DodecahedronGeometry(1.3, 1);
    const mainRock = new THREE.Mesh(mainRockGeo, this.rockMat!);
    mainRock.name = 'rock_core';
    mainRock.position.set(0, 1.45, 0);
    mainRock.scale.set(1.15, 1.0, 1.25);
    mainRock.rotation.set(0.3, 0.4, -0.2);
    mainRock.castShadow = true;
    mainRock.receiveShadow = true;
    group.add(mainRock);

    // Subsidiary Craggy Boulder Facets
    const facetGeo1 = new THREE.IcosahedronGeometry(0.85, 0);
    const facet1 = new THREE.Mesh(facetGeo1, this.rockMat!);
    facet1.position.set(0.7, 1.2, 0.5);
    facet1.rotation.set(0.5, 0.2, 0.7);
    facet1.castShadow = true;
    group.add(facet1);

    const facetGeo2 = new THREE.IcosahedronGeometry(0.75, 0);
    const facet2 = new THREE.Mesh(facetGeo2, this.rockMat!);
    facet2.position.set(-0.65, 1.35, -0.4);
    facet2.rotation.set(-0.4, 0.6, -0.3);
    facet2.castShadow = true;
    group.add(facet2);

    const facetGeo3 = new THREE.DodecahedronGeometry(0.65, 0);
    const facet3 = new THREE.Mesh(facetGeo3, this.rockMat!);
    facet3.position.set(0.2, 2.1, -0.3);
    facet3.rotation.set(0.2, -0.5, 0.4);
    facet3.castShadow = true;
    group.add(facet3);

    // 2. GLOWING MAGMA FISSURES & CRACKED VEINS
    const fissurePositions = [
      [0, 1.4, 1.0, 0.1, 0.8, 0.15],
      [-0.5, 1.6, 0.8, 0.12, 0.6, 0.12],
      [0.6, 1.3, -0.6, 0.15, 0.7, 0.1],
      [-0.7, 1.5, 0.2, 0.1, 0.75, 0.12],
      [0.1, 1.9, 0.6, 0.12, 0.5, 0.12],
    ];

    fissurePositions.forEach(([fx, fy, fz, sx, sy, sz], idx) => {
      const fissureGeo = new THREE.BoxGeometry(sx, sy, sz);
      const fissure = new THREE.Mesh(fissureGeo, this.magmaMat!);
      fissure.name = `magma_crack_${idx}`;
      fissure.position.set(fx, fy, fz);
      fissure.rotation.set(fx * 1.5, fy * 0.8, fz * 2.1);
      group.add(fissure);
    });

    // 3. JAGGED OBSIDIAN CRYSTAL SPIKES
    const crystalGeo = new THREE.ConeGeometry(0.25, 0.8, 5);
    const crystalPositions = [
      [-0.4, 2.2, 0.2, 0.3, 0.2, -0.4],
      [0.45, 2.15, -0.2, -0.4, -0.1, 0.5],
      [0.1, 2.35, 0.3, 0.1, 0.5, 0.2],
    ];

    crystalPositions.forEach(([cx, cy, cz, rx, ry, rz]) => {
      const crystal = new THREE.Mesh(crystalGeo, this.crystalMat!);
      crystal.position.set(cx, cy, cz);
      crystal.rotation.set(rx, ry, rz);
      crystal.castShadow = true;
      group.add(crystal);
    });

    // 4. VOLCANIC THRUSTER EXHAUST NOZZLE AT BOTTOM / REAR
    const nozzleGeo = new THREE.CylinderGeometry(0.48, 0.75, 0.65, 12, 1, true);
    const nozzleMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.9,
      metalness: 0.5,
      side: THREE.DoubleSide,
    });
    const nozzle = new THREE.Mesh(nozzleGeo, nozzleMat);
    nozzle.position.set(0, 0.55, -0.35);
    nozzle.rotation.x = -0.35; // Angled backward thrust
    group.add(nozzle);

    // 5. ANIMATED REAL-TIME 3D FIRE PLUME (Outer, Mid, Core)
    const fireOuterGeo = new THREE.ConeGeometry(0.65, 1.8, 10);
    fireOuterGeo.rotateX(Math.PI); // Point flame downward
    const fireOuter = new THREE.Mesh(fireOuterGeo, this.flameOuterMat!);
    fireOuter.name = 'flame_outer';
    fireOuter.position.set(0, -0.4, -0.55);
    group.add(fireOuter);

    const fireMidGeo = new THREE.ConeGeometry(0.42, 1.4, 10);
    fireMidGeo.rotateX(Math.PI);
    const fireMid = new THREE.Mesh(fireMidGeo, this.flameMidMat!);
    fireMid.name = 'flame_mid';
    fireMid.position.set(0, -0.25, -0.5);
    group.add(fireMid);

    const fireCoreGeo = new THREE.ConeGeometry(0.24, 0.9, 8);
    fireCoreGeo.rotateX(Math.PI);
    const fireCore = new THREE.Mesh(fireCoreGeo, this.flameCoreMat!);
    fireCore.name = 'flame_core';
    fireCore.position.set(0, -0.15, -0.45);
    group.add(fireCore);

    // 6. VOLCANIC SMOKE & EMBER PARTICLES (Pre-allocated pool of 8 particles)
    const particleGroup = new THREE.Group();
    particleGroup.name = 'particle_group';

    const smokeGeo = new THREE.DodecahedronGeometry(0.22, 0);
    for (let i = 0; i < 5; i++) {
      const smoke = new THREE.Mesh(smokeGeo, this.smokeMat!);
      smoke.name = `smoke_${i}`;
      smoke.position.set(
        (Math.random() - 0.5) * 0.6,
        -0.8 - i * 0.4,
        -0.6 - i * 0.4
      );
      smoke.scale.setScalar(0.8 + i * 0.3);
      particleGroup.add(smoke);
    }

    const emberGeo = new THREE.DodecahedronGeometry(0.08, 0);
    for (let j = 0; j < 6; j++) {
      const ember = new THREE.Mesh(emberGeo, this.emberMat!);
      ember.name = `ember_${j}`;
      ember.position.set(
        (Math.random() - 0.5) * 0.8,
        -0.3 - j * 0.3,
        -0.4 - j * 0.35
      );
      particleGroup.add(ember);
    }
    group.add(particleGroup);

    // 7. WARM PULSING VOLCANIC LIGHT
    const light = new THREE.PointLight(0xff6600, 2.5, 9);
    light.name = 'fire_light';
    light.position.set(0, 0.4, -0.4);
    group.add(light);

    return group;
  }

  /**
   * Updates real-time 3D flame motion, smoke billowing, and leaping embers
   */
  public static animateFireRock(group: THREE.Group, delta: number, elapsed: number) {
    // 1. Flame flicker and stretch
    const flameOuter = group.getObjectByName('flame_outer');
    const flameMid = group.getObjectByName('flame_mid');
    const flameCore = group.getObjectByName('flame_core');

    const flicker = 1.0 + Math.sin(elapsed * 24) * 0.15 + Math.cos(elapsed * 38) * 0.1;
    const pulseY = 1.0 + Math.sin(elapsed * 18) * 0.25;

    if (flameOuter) {
      flameOuter.scale.set(flicker, pulseY * 1.15, flicker);
      flameOuter.rotation.z = Math.sin(elapsed * 12) * 0.08;
    }
    if (flameMid) {
      flameMid.scale.set(flicker * 0.95, pulseY * 1.05, flicker * 0.95);
      flameMid.rotation.z = -Math.sin(elapsed * 15) * 0.08;
    }
    if (flameCore) {
      flameCore.scale.set(1, pulseY * 0.95, 1);
    }

    // 2. Magma cracks pulsing emission
    const crackGlow = 0.7 + Math.sin(elapsed * 8) * 0.3;
    for (let i = 0; i < 5; i++) {
      const crack = group.getObjectByName(`magma_crack_${i}`) as THREE.Mesh;
      if (crack && crack.material) {
        (crack.material as THREE.MeshStandardMaterial).emissiveIntensity = crackGlow;
      }
    }

    // 3. Smoke puffs drift rearward & rise
    for (let i = 0; i < 5; i++) {
      const smoke = group.getObjectByName(`smoke_${i}`);
      if (smoke) {
        smoke.position.z -= delta * 3.5;
        smoke.position.y += delta * 0.8;
        smoke.position.x += Math.sin(elapsed * 4 + i) * delta * 0.5;
        smoke.scale.multiplyScalar(1.0 + delta * 0.8);

        // Reset smoke loop
        if (smoke.position.z < -3.2) {
          smoke.position.set((Math.random() - 0.5) * 0.5, -0.6, -0.4);
          smoke.scale.setScalar(0.7 + Math.random() * 0.3);
        }
      }
    }

    // 4. Embers leaping & flickering
    for (let j = 0; j < 6; j++) {
      const ember = group.getObjectByName(`ember_${j}`);
      if (ember) {
        ember.position.z -= delta * 5.0;
        ember.position.y += (Math.random() - 0.4) * delta * 2.0;
        ember.position.x += (Math.random() - 0.5) * delta * 1.5;

        // Reset ember loop
        if (ember.position.z < -2.8) {
          ember.position.set(
            (Math.random() - 0.5) * 0.6,
            -0.2 - Math.random() * 0.4,
            -0.3
          );
        }
      }
    }

    // 5. Point light pulse
    const light = group.getObjectByName('fire_light') as THREE.PointLight;
    if (light) {
      light.intensity = 2.2 + Math.sin(elapsed * 16) * 0.8;
    }
  }
}
