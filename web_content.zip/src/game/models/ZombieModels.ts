import * as THREE from 'three';

export type ZombieAppearance = 'civilian' | 'worker' | 'military' | 'police' | 'survivor';
export type ZombieType = 'walker' | 'runner' | 'brute' | 'crawler';

export interface ZombieRig {
  root: THREE.Group;
  head: THREE.Group;
  torso: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftForearm: THREE.Group;
  rightForearm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftFoot: THREE.Group;
  rightFoot: THREE.Group;
  appearance: ZombieAppearance;
  type: ZombieType;
  height: number;
  radius: number;
}

export class ZombieModels {
  // Shared realistic PBR materials
  private static skinDecayed = new THREE.MeshStandardMaterial({
    color: 0x5a6858,
    roughness: 0.85,
    metalness: 0.05,
  });

  private static skinBloodied = new THREE.MeshStandardMaterial({
    color: 0x6e4e4e,
    roughness: 0.8,
    metalness: 0.05,
  });

  private static eyeAmberGlow = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
  private static teethBone = new THREE.MeshStandardMaterial({ color: 0xd4d4d8, roughness: 0.6 });

  // Clothing materials
  private static clothesCivilianShirt = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.9 });
  private static clothesCivilianPants = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.9 });

  private static clothesWorkerVest = new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.7 });
  private static workerHelmetMat = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.4, metalness: 0.2 });

  private static clothesMilitaryCamo = new THREE.MeshStandardMaterial({ color: 0x3f4f35, roughness: 0.85 });
  private static militaryHelmetMat = new THREE.MeshStandardMaterial({ color: 0x272e22, roughness: 0.6, metalness: 0.3 });

  private static clothesPoliceNavy = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.8 });
  private static policeBadgeMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, metalness: 0.9, roughness: 0.2 });

  private static clothesSurvivorJacket = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.85 });
  private static leatherBootsMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.7 });

  // Create human-proportioned detailed anatomical head
  private static createHead(skinMat: THREE.Material, appearance: ZombieAppearance): THREE.Group {
    const headGroup = new THREE.Group();

    // Cranium / Skull
    const cranium = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.26, 0.24), skinMat);
    cranium.position.y = 0.13;
    cranium.castShadow = true;
    headGroup.add(cranium);

    // Brow Ridge & Sunken Eye Sockets
    const brow = new THREE.Mesh(new THREE.BoxGeometry(0.23, 0.05, 0.08), skinMat);
    brow.position.set(0, 0.18, 0.11);
    headGroup.add(brow);

    // Glowing Eerie Eyes
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.024, 6, 6), this.eyeAmberGlow);
    eyeL.position.set(-0.06, 0.14, 0.13);
    headGroup.add(eyeL);

    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.024, 6, 6), this.eyeAmberGlow);
    eyeR.position.set(0.06, 0.14, 0.13);
    headGroup.add(eyeR);

    // Jaw with visible teeth
    const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.09, 0.16), skinMat);
    jaw.position.set(0, 0.04, 0.08);
    headGroup.add(jaw);

    const teeth = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.03, 0.04), this.teethBone);
    teeth.position.set(0, 0.08, 0.15);
    headGroup.add(teeth);

    // Headwear based on appearance
    if (appearance === 'worker') {
      // Hardhat
      const hat = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.16, 0.12, 8), this.workerHelmetMat);
      hat.position.set(0, 0.28, 0.02);
      hat.castShadow = true;
      headGroup.add(hat);
      const brim = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.02, 0.32), this.workerHelmetMat);
      brim.position.set(0, 0.23, 0.05);
      headGroup.add(brim);
    } else if (appearance === 'military') {
      // Kevlar Helmet
      const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6, 0, Math.PI * 2, 0, Math.PI * 0.55), this.militaryHelmetMat);
      helmet.position.set(0, 0.17, 0.01);
      helmet.castShadow = true;
      headGroup.add(helmet);
    } else if (appearance === 'police') {
      // Police Peak Cap
      const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.14, 0.07, 8), this.clothesPoliceNavy);
      cap.position.set(0, 0.27, 0.02);
      cap.castShadow = true;
      headGroup.add(cap);
      const visor = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.015, 0.1), this.leatherBootsMat);
      visor.position.set(0, 0.24, 0.14);
      headGroup.add(visor);
    } else if (appearance === 'survivor') {
      // Bloodied head bandage
      const bandage = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.06, 0.25), this.teethBone);
      bandage.position.set(0, 0.21, 0);
      headGroup.add(bandage);
    }

    return headGroup;
  }

  // Create human-proportioned torso with clothing layers
  private static createTorso(appearance: ZombieAppearance): THREE.Group {
    const torsoGroup = new THREE.Group();

    let shirtMat = this.clothesCivilianShirt;
    if (appearance === 'worker') shirtMat = this.clothesCivilianShirt;
    else if (appearance === 'military') shirtMat = this.clothesMilitaryCamo;
    else if (appearance === 'police') shirtMat = this.clothesPoliceNavy;
    else if (appearance === 'survivor') shirtMat = this.clothesSurvivorJacket;

    // Chest / Upper Torso
    const chest = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.38, 0.26), shirtMat);
    chest.position.y = 0.46;
    chest.castShadow = true;
    torsoGroup.add(chest);

    // Abdomen / Lower Torso
    const abdomen = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.28, 0.24), shirtMat);
    abdomen.position.y = 0.16;
    abdomen.castShadow = true;
    torsoGroup.add(abdomen);

    // Tactical Gear / Vest overlays
    if (appearance === 'worker') {
      // Hi-Vis safety vest
      const vest = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.4, 0.28), this.clothesWorkerVest);
      vest.position.y = 0.45;
      vest.castShadow = true;
      torsoGroup.add(vest);
      // Silver reflective stripe
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.51, 0.05, 0.29), this.teethBone);
      stripe.position.y = 0.44;
      torsoGroup.add(stripe);
    } else if (appearance === 'military') {
      // Ballistic vest with pouches
      const vest = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.42, 0.29), this.militaryHelmetMat);
      vest.position.y = 0.45;
      vest.castShadow = true;
      torsoGroup.add(vest);
      // Chest pouches
      const pouch = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.12, 0.08), this.clothesMilitaryCamo);
      pouch.position.set(0, 0.38, 0.18);
      torsoGroup.add(pouch);
    } else if (appearance === 'police') {
      // Duty belt and gold badge
      const badge = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.1, 0.02), this.policeBadgeMat);
      badge.position.set(0.12, 0.52, 0.14);
      torsoGroup.add(badge);
      const belt = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.08, 0.26), this.leatherBootsMat);
      belt.position.y = 0.03;
      torsoGroup.add(belt);
    } else if (appearance === 'survivor') {
      // Shoulder ammo bandolier
      const bandolier = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.52, 0.28), this.leatherBootsMat);
      bandolier.rotation.z = -0.45;
      bandolier.position.set(0, 0.42, 0.02);
      torsoGroup.add(bandolier);
    }

    return torsoGroup;
  }

  // Create human arm with shoulder, upper arm, elbow, forearm, and articulated hand
  private static createArm(skinMat: THREE.Material, appearance: ZombieAppearance): {
    upperArm: THREE.Group;
    forearm: THREE.Group;
  } {
    const upperArm = new THREE.Group();
    const forearm = new THREE.Group();

    let sleeveMat = this.clothesCivilianShirt;
    if (appearance === 'military') sleeveMat = this.clothesMilitaryCamo;
    else if (appearance === 'police') sleeveMat = this.clothesPoliceNavy;
    else if (appearance === 'survivor') sleeveMat = this.clothesSurvivorJacket;

    // Upper Arm / Bicep
    const bicep = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.32, 0.12), sleeveMat);
    bicep.position.y = -0.16;
    bicep.castShadow = true;
    upperArm.add(bicep);

    // Forearm attached at elbow
    forearm.position.y = -0.32;

    const lowerArm = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.3, 0.1), skinMat);
    lowerArm.position.y = -0.15;
    lowerArm.castShadow = true;
    forearm.add(lowerArm);

    // Hand with palm & fingers
    const palm = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.11, 0.04), skinMat);
    palm.position.set(0, -0.34, 0);
    palm.castShadow = true;
    forearm.add(palm);

    // Fingers claw
    const fingers = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.07, 0.03), skinMat);
    fingers.position.set(0, -0.41, 0.02);
    fingers.rotation.x = 0.3;
    forearm.add(fingers);

    upperArm.add(forearm);
    return { upperArm, forearm };
  }

  // Create human leg with thigh, knee, calf, and boot
  private static createLeg(appearance: ZombieAppearance): {
    upperLeg: THREE.Group;
    foot: THREE.Group;
  } {
    const upperLeg = new THREE.Group();
    const foot = new THREE.Group();

    let pantsMat = this.clothesCivilianPants;
    if (appearance === 'military') pantsMat = this.clothesMilitaryCamo;
    else if (appearance === 'police') pantsMat = this.clothesPoliceNavy;
    else if (appearance === 'worker') pantsMat = this.clothesCivilianPants;

    // Thigh
    const thigh = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.42, 0.16), pantsMat);
    thigh.position.y = -0.21;
    thigh.castShadow = true;
    upperLeg.add(thigh);

    // Calf
    const calf = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.4, 0.14), pantsMat);
    calf.position.y = -0.6;
    calf.castShadow = true;
    upperLeg.add(calf);

    // Boot / Foot
    foot.position.set(0, -0.84, 0.04);
    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.12, 0.24), this.leatherBootsMat);
    boot.position.y = 0.06;
    boot.castShadow = true;
    foot.add(boot);

    upperLeg.add(foot);
    return { upperLeg, foot };
  }

  // Factory function to build human zombie with chosen appearance
  static buildHumanoidZombie(appearance: ZombieAppearance, type: ZombieType = 'walker'): ZombieRig {
    const root = new THREE.Group();
    root.name = `zombie_${appearance}_${type}`;

    const skinMat = type === 'runner' ? this.skinBloodied : this.skinDecayed;

    // Pelvis
    const pelvis = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.16, 0.22), this.clothesCivilianPants);
    pelvis.position.y = 0.88;
    pelvis.castShadow = true;
    root.add(pelvis);

    // Torso
    const torso = this.createTorso(appearance);
    torso.position.y = 0.94;
    root.add(torso);

    // Head
    const head = this.createHead(skinMat, appearance);
    head.position.set(0, 1.62, 0.02);
    root.add(head);

    // Arms
    const leftArmData = this.createArm(skinMat, appearance);
    leftArmData.upperArm.position.set(-0.31, 1.56, 0);
    root.add(leftArmData.upperArm);

    const rightArmData = this.createArm(skinMat, appearance);
    rightArmData.upperArm.position.set(0.31, 1.56, 0);
    root.add(rightArmData.upperArm);

    // Legs
    const leftLegData = this.createLeg(appearance);
    leftLegData.upperLeg.position.set(-0.14, 0.86, 0);
    root.add(leftLegData.upperLeg);

    const rightLegData = this.createLeg(appearance);
    rightLegData.upperLeg.position.set(0.14, 0.86, 0);
    root.add(rightLegData.upperLeg);

    return {
      root,
      head,
      torso,
      leftArm: leftArmData.upperArm,
      rightArm: rightArmData.upperArm,
      leftForearm: leftArmData.forearm,
      rightForearm: rightArmData.forearm,
      leftLeg: leftLegData.upperLeg,
      rightLeg: rightLegData.upperLeg,
      leftFoot: leftLegData.foot,
      rightFoot: rightLegData.foot,
      appearance,
      type,
      height: 1.8,
      radius: 0.45,
    };
  }

  // Heavy Armored Brute Juggernaut
  static buildBrute(): ZombieRig {
    const rig = this.buildHumanoidZombie('military', 'brute');
    rig.root.scale.set(1.22, 1.18, 1.25);
    rig.height = 2.15;
    rig.radius = 0.65;
    return rig;
  }

  // Crawling Torso Zombie
  static buildCrawler(): ZombieRig {
    const rig = this.buildHumanoidZombie('civilian', 'crawler');
    rig.root.position.y = 0.25;
    rig.torso.rotation.x = Math.PI / 2.3;
    rig.head.position.set(0, 0.45, 0.35);
    rig.leftLeg.visible = false;
    rig.rightLeg.visible = false;
    rig.height = 0.65;
    rig.radius = 0.45;
    return rig;
  }

  // Pick balanced zombie model appearance
  static buildZombie(type: ZombieType): ZombieRig {
    if (type === 'brute') return this.buildBrute();
    if (type === 'crawler') return this.buildCrawler();

    const appearances: ZombieAppearance[] = ['civilian', 'worker', 'military', 'police', 'survivor'];
    const chosen = appearances[Math.floor(Math.random() * appearances.length)];
    return this.buildHumanoidZombie(chosen, type);
  }
}
