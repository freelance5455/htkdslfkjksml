/**
 * SPR - Sahil Powerful Run
 * Dual-Engine Rocket Flight Propulsion System & Particle Pool
 *
 * Provides real-time physical rocket propulsion during the 32-second flight sequence:
 * - Mounts a physical, high-detail 3D rocket to the scene / player
 * - TWO separate engine exhausts with multi-layered procedural flame meshes:
 *   - Bright white/blue-hot inner core
 *   - Intense yellow middle flame cone
 *   - Roaring orange outer exhaust plume
 * - Procedural particle pools:
 *   - Fiery spark/ember particles
 *   - Smoke puff trail particles
 *   - High-intensity orange engine point light illuminating player & environment
 * - Smooth throttle-up on launch, cruise hovering, and smooth touchdown
 */

import * as THREE from 'three';
import { Rocket3DBuilder } from './Rocket3DBuilder';

interface FlameParticle {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  baseScale: number;
  active: boolean;
}

export class RocketFlightSystem {
  public group: THREE.Group;
  public rocketGroup: THREE.Group;

  // Dual engine nozzles & flame cones
  private flameCoreLeft!: THREE.Mesh;
  private flameCoreRight!: THREE.Mesh;
  private flameMidLeft!: THREE.Mesh;
  private flameMidRight!: THREE.Mesh;
  private flameOuterLeft!: THREE.Mesh;
  private flameOuterRight!: THREE.Mesh;

  // Dual engine lighting
  private engineLightLeft!: THREE.PointLight;
  private engineLightRight!: THREE.PointLight;

  // Particle pools
  private sparks: FlameParticle[] = [];
  private smokePuffs: FlameParticle[] = [];
  private sparkGeo!: THREE.BufferGeometry;
  private sparkMat!: THREE.MeshBasicMaterial;
  private smokeGeo!: THREE.BufferGeometry;
  private smokeMat!: THREE.MeshBasicMaterial;

  private thrustIntensity: number = 0; // 0 to 1
  private animClock: number = 0;
  private tempVecL = new THREE.Vector3();
  private tempVecR = new THREE.Vector3();

  constructor(scene?: THREE.Scene) {
    this.group = new THREE.Group();
    this.group.name = 'rocket_flight_propulsion_system';
    this.group.visible = false;

    // 1. Build Physical 3D Rocket
    this.rocketGroup = Rocket3DBuilder.buildFull3DRocketMesh({ isItemPickup: false });
    this.rocketGroup.scale.set(0.9, 0.9, 0.9);
    // Orient rocket horizontally forward along the track
    this.rocketGroup.rotation.x = -Math.PI / 14;
    this.group.add(this.rocketGroup);

    this.initFlames();
    this.initLights();
    this.initParticlePools();

    if (scene) {
      scene.add(this.group);
    }
  }

  private initFlames() {
    // Multi-layered flame geometries for both engines (nozzle offsets X = -0.114 and +0.114)
    const xOffsets = [-0.114, 0.114];

    // Inner Core (White Hot)
    const coreGeo = new THREE.ConeGeometry(0.065, 0.65, 10);
    coreGeo.rotateX(Math.PI);
    const coreMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.95 });

    // Mid Flame (Golden Yellow)
    const midGeo = new THREE.ConeGeometry(0.12, 1.1, 10);
    midGeo.rotateX(Math.PI);
    const midMat = new THREE.MeshBasicMaterial({ color: 0xfde047, transparent: true, opacity: 0.88 });

    // Outer Plume (Vibrant Orange-Red)
    const outerGeo = new THREE.ConeGeometry(0.19, 1.6, 10);
    outerGeo.rotateX(Math.PI);
    const outerMat = new THREE.MeshBasicMaterial({ color: 0xf97316, transparent: true, opacity: 0.75 });

    // Left Engine Flames
    this.flameCoreLeft = new THREE.Mesh(coreGeo, coreMat);
    this.flameCoreLeft.position.set(xOffsets[0], -0.95, 0);
    this.rocketGroup.add(this.flameCoreLeft);

    this.flameMidLeft = new THREE.Mesh(midGeo, midMat);
    this.flameMidLeft.position.set(xOffsets[0], -1.15, 0);
    this.rocketGroup.add(this.flameMidLeft);

    this.flameOuterLeft = new THREE.Mesh(outerGeo, outerMat);
    this.flameOuterLeft.position.set(xOffsets[0], -1.38, 0);
    this.rocketGroup.add(this.flameOuterLeft);

    // Right Engine Flames
    this.flameCoreRight = new THREE.Mesh(coreGeo, coreMat);
    this.flameCoreRight.position.set(xOffsets[1], -0.95, 0);
    this.rocketGroup.add(this.flameCoreRight);

    this.flameMidRight = new THREE.Mesh(midGeo, midMat);
    this.flameMidRight.position.set(xOffsets[1], -1.15, 0);
    this.rocketGroup.add(this.flameMidRight);

    this.flameOuterRight = new THREE.Mesh(outerGeo, outerMat);
    this.flameOuterRight.position.set(xOffsets[1], -1.38, 0);
    this.rocketGroup.add(this.flameOuterRight);
  }

  private initLights() {
    this.engineLightLeft = new THREE.PointLight(0xf97316, 2.5, 6.0);
    this.engineLightLeft.position.set(-0.15, -0.8, 0);
    this.rocketGroup.add(this.engineLightLeft);

    this.engineLightRight = new THREE.PointLight(0xfacc15, 2.5, 6.0);
    this.engineLightRight.position.set(0.15, -0.8, 0);
    this.rocketGroup.add(this.engineLightRight);
  }

  private initParticlePools() {
    this.sparkGeo = new THREE.DodecahedronGeometry(0.045, 0);
    this.sparkMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });

    for (let i = 0; i < 24; i++) {
      const mesh = new THREE.Mesh(this.sparkGeo, this.sparkMat);
      mesh.visible = false;
      this.group.add(mesh);
      this.sparks.push({
        mesh,
        vx: 0,
        vy: 0,
        vz: 0,
        life: 0,
        maxLife: 0.35,
        baseScale: 1.0,
        active: false,
      });
    }

    this.smokeGeo = new THREE.DodecahedronGeometry(0.16, 0);
    this.smokeMat = new THREE.MeshBasicMaterial({
      color: 0x64748b,
      transparent: true,
      opacity: 0.45,
    });

    for (let i = 0; i < 24; i++) {
      const mesh = new THREE.Mesh(this.smokeGeo, this.smokeMat);
      mesh.visible = false;
      this.group.add(mesh);
      this.smokePuffs.push({
        mesh,
        vx: 0,
        vy: 0,
        vz: 0,
        life: 0,
        maxLife: 0.6,
        baseScale: 1.0,
        active: false,
      });
    }
  }

  public setThrust(intensity: number) {
    this.thrustIntensity = Math.max(0, Math.min(1, intensity));
    const active = this.thrustIntensity > 0.01;
    this.group.visible = active;

    const lightInt = this.thrustIntensity * 3.2;
    this.engineLightLeft.intensity = lightInt;
    this.engineLightRight.intensity = lightInt;
  }

  public reset() {
    this.setThrust(0);
    this.group.visible = false;
    for (const s of this.sparks) {
      s.active = false;
      s.mesh.visible = false;
    }
    for (const p of this.smokePuffs) {
      p.active = false;
      p.mesh.visible = false;
    }
  }

  public update(
    delta: number,
    active: boolean,
    playerXOrLeftPos: number | THREE.Vector3,
    playerYOrRightPos?: number | THREE.Vector3,
    playerZOrSpeed?: number,
    rollZ: number = 0,
    flightPitch: number = 1.0
  ) {
    if (!active) {
      this.setThrust(0);
      this.group.visible = false;
      return;
    }

    this.setThrust(1.0);
    this.group.visible = true;
    this.animClock += delta * 24;

    // Position the rocket right at the player / skateboard tail
    if (typeof playerXOrLeftPos === 'number') {
      const px = playerXOrLeftPos;
      const py = (playerYOrRightPos as number) ?? 0;
      const pz = playerZOrSpeed ?? 0;
      
      // Interpolate rocket mount position from upright standing to horizontal flying pose
      const targetY = THREE.MathUtils.lerp(py + 0.95, py + 0.28, flightPitch);
      const targetZ = THREE.MathUtils.lerp(pz + 0.18, pz + 0.36, flightPitch);
      this.rocketGroup.position.set(px, targetY, targetZ);

      // Rocket pitch aligns with player's horizontal flight pose (-PI/14 upright to -PI/2 horizontal forward)
      const pitch = THREE.MathUtils.lerp(-Math.PI / 14, -Math.PI / 2, flightPitch);
      this.rocketGroup.rotation.set(pitch, 0, rollZ);
      this.rocketGroup.scale.set(0.9, 0.9, 0.9);
    } else {
      const leftPos = playerXOrLeftPos;
      const rightPos = (playerYOrRightPos as THREE.Vector3) || leftPos;
      this.rocketGroup.position.set(
        (leftPos.x + rightPos.x) * 0.5,
        (leftPos.y + rightPos.y) * 0.5 + 0.2,
        (leftPos.z + rightPos.z) * 0.5 + 0.1
      );
      this.rocketGroup.rotation.set(-Math.PI / 2, 0, rollZ);
    }

    // 1. Procedural Flame Flicker & Jitter
    const flickerL = 0.88 + Math.sin(this.animClock * 1.8) * 0.14 + (Math.random() - 0.5) * 0.08;
    const flickerR = 0.88 + Math.cos(this.animClock * 1.9) * 0.14 + (Math.random() - 0.5) * 0.08;

    const scaleL = this.thrustIntensity * flickerL;
    const scaleR = this.thrustIntensity * flickerR;

    this.flameCoreLeft.scale.set(scaleL, scaleL * 1.1, scaleL);
    this.flameMidLeft.scale.set(scaleL, scaleL * 1.25, scaleL);
    this.flameOuterLeft.scale.set(scaleL, scaleL * 1.4, scaleL);

    this.flameCoreRight.scale.set(scaleR, scaleR * 1.1, scaleR);
    this.flameMidRight.scale.set(scaleR, scaleR * 1.25, scaleR);
    this.flameOuterRight.scale.set(scaleR, scaleR * 1.4, scaleR);

    // Update dynamic engine lighting
    const lightInt = this.thrustIntensity * (2.8 + Math.random() * 0.8);
    this.engineLightLeft.intensity = lightInt;
    this.engineLightRight.intensity = lightInt;

    // 2. Emit Sparks & Smoke Puffs from both engine nozzles using nozzle world coordinates
    this.flameCoreLeft.getWorldPosition(this.tempVecL);
    this.flameCoreRight.getWorldPosition(this.tempVecR);

    if (Math.random() < this.thrustIntensity * 0.85) {
      this.spawnParticleAt('spark', this.tempVecL);
      this.spawnParticleAt('spark', this.tempVecR);
    }
    if (Math.random() < this.thrustIntensity * 0.65) {
      this.spawnParticleAt('smoke', this.tempVecL);
      this.spawnParticleAt('smoke', this.tempVecR);
    }

    // 3. Update Sparks Pool
    for (const s of this.sparks) {
      if (!s.active) continue;
      s.life += delta;
      if (s.life >= s.maxLife) {
        s.active = false;
        s.mesh.visible = false;
        continue;
      }
      s.mesh.position.x += s.vx * delta;
      s.mesh.position.y += s.vy * delta;
      s.mesh.position.z += s.vz * delta;

      const progress = s.life / s.maxLife;
      const curScale = s.baseScale * (1 - progress);
      s.mesh.scale.set(curScale, curScale, curScale);
    }

    // 4. Update Smoke Puffs Pool
    for (const p of this.smokePuffs) {
      if (!p.active) continue;
      p.life += delta;
      if (p.life >= p.maxLife) {
        p.active = false;
        p.mesh.visible = false;
        continue;
      }
      p.mesh.position.x += p.vx * delta;
      p.mesh.position.y += p.vy * delta;
      p.mesh.position.z += p.vz * delta;

      const progress = p.life / p.maxLife;
      const curScale = p.baseScale * (0.8 + progress * 2.2);
      p.mesh.scale.set(curScale, curScale, curScale);
    }
  }

  private spawnParticleAt(type: 'spark' | 'smoke', nozzlePos: THREE.Vector3) {
    const list = type === 'spark' ? this.sparks : this.smokePuffs;
    const item = list.find((p) => !p.active);
    if (!item) return;

    item.active = true;
    item.life = 0;
    item.mesh.visible = true;

    item.mesh.position.set(
      nozzlePos.x + (Math.random() - 0.5) * 0.05,
      nozzlePos.y + (Math.random() - 0.5) * 0.05,
      nozzlePos.z + (Math.random() - 0.5) * 0.05
    );

    if (type === 'spark') {
      item.maxLife = 0.25 + Math.random() * 0.2;
      item.baseScale = 0.6 + Math.random() * 0.6;
      item.vx = (Math.random() - 0.5) * 1.6;
      item.vy = (Math.random() - 0.5) * 1.6;
      item.vz = 5.5 + Math.random() * 3.5;
    } else {
      item.maxLife = 0.45 + Math.random() * 0.35;
      item.baseScale = 0.7 + Math.random() * 0.7;
      item.vx = (Math.random() - 0.5) * 1.2;
      item.vy = (Math.random() - 0.5) * 1.2;
      item.vz = 4.0 + Math.random() * 2.5;
    }
  }

  public destroy() {
    this.dispose();
  }

  public dispose() {
    this.reset();
    this.sparkGeo?.dispose();
    this.sparkMat?.dispose();
    this.smokeGeo?.dispose();
    this.smokeMat?.dispose();
    this.engineLightLeft?.dispose();
    this.engineLightRight?.dispose();
    if (this.group.parent) {
      this.group.parent.remove(this.group);
    }
  }
}
