import * as THREE from 'three';
import { EnemyDef } from '../types/gameTypes';

function addGlowingEyes(
  parent: THREE.Object3D,
  xOffset: number,
  y: number,
  z: number,
  radius: number,
  color: string
) {
  const eyeMat = new THREE.MeshStandardMaterial({
    color,
    emissive: color,
    emissiveIntensity: 1.4,
    roughness: 0.15,
  });
  for (const s of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(radius, 8, 8), eyeMat);
    eye.position.set(s * xOffset, y, z);
    parent.add(eye);
  }
}

function addFangs(
  parent: THREE.Object3D,
  xSpread: number,
  y: number,
  z: number,
  size: number,
  mat: THREE.Material
) {
  for (const s of [-1, 1]) {
    const fang = new THREE.Mesh(new THREE.ConeGeometry(size * 0.4, size * 1.6, 5), mat);
    fang.rotation.x = Math.PI;
    fang.position.set(s * xSpread, y, z);
    parent.add(fang);
  }
}

function addJointedLeg(
  parent: THREE.Object3D,
  x: number,
  y: number,
  z: number,
  upperLen: number,
  lowerLen: number,
  thickness: number,
  upperMat: THREE.Material,
  lowerMat: THREE.Material
): THREE.Group {
  const hip = new THREE.Group();
  hip.position.set(x, y, z);

  const thigh = new THREE.Mesh(
    new THREE.CylinderGeometry(thickness, thickness * 0.82, upperLen, 7),
    upperMat
  );
  thigh.position.y = -upperLen * 0.5;
  hip.add(thigh);

  const knee = new THREE.Mesh(new THREE.SphereGeometry(thickness * 0.95, 7, 7), lowerMat);
  knee.position.y = -upperLen;
  hip.add(knee);

  const shin = new THREE.Mesh(
    new THREE.CylinderGeometry(thickness * 0.8, thickness * 0.65, lowerLen, 7),
    lowerMat
  );
  shin.position.y = -upperLen - lowerLen * 0.5;
  hip.add(shin);

  const foot = new THREE.Mesh(
    new THREE.BoxGeometry(thickness * 1.9, thickness * 0.9, thickness * 2.5),
    lowerMat
  );
  foot.position.set(0, -upperLen - lowerLen, thickness * 0.45);
  hip.add(foot);

  parent.add(hip);
  return hip;
}

function addDetailedWing(
  parent: THREE.Object3D,
  side: -1 | 1,
  x: number,
  y: number,
  z: number,
  span: number,
  chord: number,
  sparMat: THREE.Material,
  membraneMat: THREE.Material,
  feathered: boolean
): THREE.Group {
  const pivot = new THREE.Group();
  pivot.position.set(side * x, y, z);

  const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.06, span * 0.55, 6), sparMat);
  arm.rotation.z = Math.PI / 2;
  arm.position.set(side * span * 0.27, 0.04, 0.08);
  pivot.add(arm);

  const claw = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.16, 5), sparMat);
  claw.rotation.x = Math.PI / 2;
  claw.position.set(side * span * 0.52, 0.06, 0.16);
  pivot.add(claw);

  if (feathered) {
    for (let i = 0; i < 4; i++) {
      const feather = new THREE.Mesh(
        new THREE.BoxGeometry(span * 0.26, 0.03, chord * (1 - i * 0.14)),
        i % 2 === 0 ? membraneMat : sparMat
      );
      feather.position.set(side * (span * 0.18 + i * span * 0.21), -0.02, -chord * 0.25 - i * 0.03);
      feather.rotation.y = side * (-0.12 * i);
      pivot.add(feather);
    }
  } else {
    const innerMem = new THREE.Mesh(new THREE.BoxGeometry(span * 0.52, 0.025, chord), membraneMat);
    innerMem.position.set(side * span * 0.26, 0, -chord * 0.35);
    pivot.add(innerMem);

    const outerMem = new THREE.Mesh(new THREE.BoxGeometry(span * 0.48, 0.02, chord * 0.78), membraneMat);
    outerMem.position.set(side * span * 0.72, -0.03, -chord * 0.28);
    outerMem.rotation.y = side * -0.22;
    pivot.add(outerMem);

    for (let f = 0; f < 3; f++) {
      const finger = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.015, chord * 0.85, 5), sparMat);
      finger.rotation.x = Math.PI / 2;
      finger.rotation.z = side * (0.25 + f * 0.28);
      finger.position.set(side * (span * 0.5 + f * span * 0.16), 0, -chord * 0.25);
      pivot.add(finger);
    }
  }

  parent.add(pivot);
  return pivot;
}

export function buildEnemyModel(def: EnemyDef): THREE.Group {
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  root.userData.body = body;
  root.userData.limbs = [] as THREE.Object3D[];
  root.userData.wings = [] as THREE.Object3D[];
  root.userData.attackArm = null as THREE.Object3D | null;

  const isMetallic =
    def.archetype.includes('armor') ||
    def.archetype.includes('war_machine') ||
    def.archetype.includes('construct') ||
    def.archetype.includes('knight') ||
    def.archetype.includes('sentinel') ||
    def.archetype === 'beetle';

  const pMat = new THREE.MeshStandardMaterial({
    color: def.primaryColor,
    roughness: isMetallic ? 0.42 : 0.68,
    metalness: isMetallic ? 0.45 : 0.08,
  });
  const sMat = new THREE.MeshStandardMaterial({
    color: def.secondaryColor,
    roughness: isMetallic ? 0.28 : 0.74,
    metalness: isMetallic ? 0.72 : 0.12,
  });
  const aMat = new THREE.MeshStandardMaterial({
    color: def.accentColor,
    emissive: def.accentColor,
    emissiveIntensity: def.flies || def.ranged || def.teleports ? 0.65 : 0.24,
    roughness: 0.28,
    metalness: 0.35,
  });
  const boneIvoryMat = new THREE.MeshStandardMaterial({ color: '#f5f5f4', roughness: 0.55 });
  const darkMetalMat = new THREE.MeshStandardMaterial({ color: '#334155', metalness: 0.82, roughness: 0.24 });
  const eyeColor = def.accentColor || '#ef4444';

  const arch = def.archetype;

  if (arch === 'spider') {
    const abdomen = new THREE.Mesh(new THREE.SphereGeometry(0.46, 12, 10), pMat);
    abdomen.scale.set(1.05, 0.85, 1.38);
    abdomen.position.set(0, 0.62, -0.42);
    body.add(abdomen);

    // Venom pattern bands on abdomen
    for (let i = 0; i < 3; i++) {
      const band = new THREE.Mesh(new THREE.TorusGeometry(0.38 - i * 0.07, 0.035, 6, 12), aMat);
      band.position.set(0, 0.68, -0.22 - i * 0.22);
      body.add(band);
    }

    const thorax = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 10), sMat);
    thorax.scale.set(1.0, 0.82, 1.12);
    thorax.position.set(0, 0.56, 0.26);
    body.add(thorax);

    // 4-eye cluster
    addGlowingEyes(body, 0.1, 0.64, 0.52, 0.055, eyeColor);
    addGlowingEyes(body, 0.18, 0.58, 0.46, 0.035, eyeColor);

    // Curved fangs
    addFangs(body, 0.11, 0.44, 0.55, 0.14, aMat);

    // 8 articulated two-segment spider legs
    for (const s of [-1, 1]) {
      for (let i = 0; i < 4; i++) {
        const legPivot = new THREE.Group();
        legPivot.position.set(s * 0.26, 0.52, -0.2 + i * 0.19);
        const femur = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.032, 0.5, 6), sMat);
        femur.position.set(s * 0.24, 0.14, 0);
        femur.rotation.z = s * -1.05;
        legPivot.add(femur);

        const tibia = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.018, 0.65, 6), pMat);
        tibia.position.set(s * 0.52, -0.18, 0);
        tibia.rotation.z = s * 0.28;
        legPivot.add(tibia);

        body.add(legPivot);
        root.userData.limbs.push(legPivot);
      }
    }
  } else if (arch === 'scorpion') {
    const carapace = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.34, 0.95), pMat);
    carapace.position.set(0, 0.48, 0.05);
    body.add(carapace);

    const headPlate = new THREE.Mesh(new THREE.SphereGeometry(0.28, 10, 8), sMat);
    headPlate.scale.set(1.1, 0.65, 1.0);
    headPlate.position.set(0, 0.48, 0.56);
    body.add(headPlate);
    addGlowingEyes(body, 0.1, 0.54, 0.76, 0.045, eyeColor);

    // Pincer claws
    for (const s of [-1, 1]) {
      const arm = new THREE.Group();
      arm.position.set(s * 0.38, 0.46, 0.52);
      const forearm = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.06, 0.48, 6), sMat);
      forearm.rotation.x = Math.PI / 2;
      forearm.position.set(s * 0.1, 0, 0.22);
      arm.add(forearm);
      const pincer = new THREE.Mesh(new THREE.DodecahedronGeometry(0.18, 0), pMat);
      pincer.scale.set(0.9, 0.6, 1.35);
      pincer.position.set(s * 0.14, 0, 0.52);
      arm.add(pincer);
      body.add(arm);
      if (s === 1) root.userData.attackArm = arm;
    }

    // Articulated stinger tail curving overhead
    const tailSegs = [
      { y: 0.62, z: -0.52, rx: -0.5 },
      { y: 0.94, z: -0.72, rx: -1.1 },
      { y: 1.28, z: -0.55, rx: -2.0 },
      { y: 1.44, z: -0.18, rx: -2.65 },
    ];
    for (const seg of tailSegs) {
      const sMesh = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 8), sMat);
      sMesh.position.set(0, seg.y, seg.z);
      body.add(sMesh);
    }
    const stinger = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.34, 6), aMat);
    stinger.rotation.x = Math.PI / 2.2;
    stinger.position.set(0, 1.4, 0.02);
    body.add(stinger);

    for (const s of [-1, 1]) {
      for (let i = 0; i < 4; i++) {
        const legPivot = new THREE.Group();
        legPivot.position.set(s * 0.32, 0.42, -0.26 + i * 0.22);
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.02, 0.55, 6), sMat);
        leg.position.set(s * 0.24, -0.14, 0);
        leg.rotation.z = s * -0.75;
        legPivot.add(leg);
        body.add(legPivot);
        root.userData.limbs.push(legPivot);
      }
    }
  } else if (arch === 'carnivore_plant') {
    const baseBulb = new THREE.Mesh(new THREE.SphereGeometry(0.4, 10, 8), pMat);
    baseBulb.scale.set(1.2, 0.6, 1.2);
    baseBulb.position.y = 0.2;
    body.add(baseBulb);

    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.95, 5), pMat);
      leaf.rotation.z = -Math.PI / 2.2;
      leaf.rotation.y = a;
      leaf.position.set(Math.cos(a) * 0.5, 0.18, -Math.sin(a) * 0.5);
      body.add(leaf);
    }

    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.22, 1.2, 8), pMat);
    stem.position.y = 0.72;
    stem.rotation.x = 0.14;
    body.add(stem);

    // Spined thorns along stem
    for (let i = 0; i < 4; i++) {
      const thorn = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.2, 4), aMat);
      thorn.rotation.z = (i % 2 === 0 ? 1 : -1) * 1.2;
      thorn.position.set((i % 2 === 0 ? 1 : -1) * 0.18, 0.42 + i * 0.22, 0.08);
      body.add(thorn);
    }

    const mawGroup = new THREE.Group();
    mawGroup.position.set(0, 1.38, 0.16);
    const upperJaw = new THREE.Mesh(
      new THREE.SphereGeometry(0.46, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.5),
      sMat
    );
    upperJaw.rotation.x = -0.35;
    mawGroup.add(upperJaw);

    const lowerJaw = new THREE.Mesh(
      new THREE.SphereGeometry(0.44, 12, 8, 0, Math.PI * 2, Math.PI * 0.5, Math.PI * 0.5),
      sMat
    );
    lowerJaw.rotation.x = 0.35;
    mawGroup.add(lowerJaw);

    const nectarCore = new THREE.Mesh(new THREE.OctahedronGeometry(0.2, 0), aMat);
    nectarCore.position.z = 0.22;
    mawGroup.add(nectarCore);

    for (let t = -2; t <= 2; t++) {
      const tooth = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.16, 4), boneIvoryMat);
      tooth.rotation.x = Math.PI;
      tooth.position.set(t * 0.11, 0.05, 0.38);
      mawGroup.add(tooth);
    }
    body.add(mawGroup);
    root.userData.attackArm = mawGroup;
  } else if (arch === 'wolf' || arch === 'panther') {
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.27, 0.85, 8, 12), pMat);
    torso.rotation.x = Math.PI / 2;
    torso.position.y = 0.72;
    body.add(torso);

    // Muscular shoulder chest & ruff
    const chest = new THREE.Mesh(new THREE.SphereGeometry(0.32, 10, 10), sMat);
    chest.scale.set(0.95, 1.05, 1.15);
    chest.position.set(0, 0.76, 0.36);
    body.add(chest);

    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.24, 0.42, 8), pMat);
    neck.position.set(0, 0.94, 0.52);
    neck.rotation.x = 0.52;
    body.add(neck);

    const head = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.24, 0.32), pMat);
    head.position.set(0, 1.05, 0.72);
    body.add(head);

    const snout = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.14, 0.26), sMat);
    snout.position.set(0, 0.99, 0.92);
    body.add(snout);

    addGlowingEyes(body, 0.085, 1.11, 0.86, 0.038, eyeColor);
    addFangs(body, 0.055, 0.91, 0.98, 0.07, boneIvoryMat);

    for (const s of [-1, 1]) {
      const ear = new THREE.Mesh(new THREE.ConeGeometry(0.065, 0.2, 4), aMat);
      ear.position.set(s * 0.1, 1.24, 0.66);
      ear.rotation.z = s * -0.15;
      body.add(ear);
    }

    // Glowing dorsal runes
    for (let i = 0; i < 3; i++) {
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.18, 4), aMat);
      spike.position.set(0, 1.04 - i * 0.03, 0.25 - i * 0.28);
      spike.rotation.x = -0.3;
      body.add(spike);
    }

    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.62, 7), aMat);
    tail.rotation.x = -Math.PI / 2.6;
    tail.position.set(0, 0.76, -0.74);
    body.add(tail);

    for (const [lx, lz] of [[-0.18, 0.36], [0.18, 0.36], [-0.18, -0.38], [0.18, -0.38]]) {
      root.userData.limbs.push(addJointedLeg(body, lx, 0.64, lz, 0.32, 0.32, 0.065, pMat, sMat));
    }
  } else if (arch === 'winged_harpy' || arch === 'bat') {
    const isHarpy = arch === 'winged_harpy';
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.24, 0.56, 8, 10), pMat);
    torso.position.y = 1.25;
    torso.rotation.x = 0.22;
    body.add(torso);

    const chestArmor = new THREE.Mesh(new THREE.SphereGeometry(0.26, 10, 8), sMat);
    chestArmor.position.set(0, 1.38, 0.08);
    body.add(chestArmor);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 10), sMat);
    head.position.set(0, 1.74, 0.18);
    body.add(head);

    addGlowingEyes(body, 0.08, 1.77, 0.35, 0.036, eyeColor);

    if (isHarpy) {
      const beak = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.24, 5), aMat);
      beak.rotation.x = Math.PI / 2;
      beak.position.set(0, 1.72, 0.42);
      body.add(beak);
      const crest = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.34, 5), aMat);
      crest.rotation.x = -0.5;
      crest.position.set(0, 1.96, 0.08);
      body.add(crest);
    } else {
      for (const s of [-1, 1]) {
        const ear = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.28, 4), pMat);
        ear.position.set(s * 0.14, 1.96, 0.14);
        ear.rotation.z = s * -0.25;
        body.add(ear);
      }
      addFangs(body, 0.06, 1.63, 0.36, 0.07, boneIvoryMat);
    }

    for (const s of [-1, 1] as const) {
      const w = addDetailedWing(body, s, 0.2, 1.44, 0.0, 1.35, 0.58, sMat, aMat, isHarpy);
      root.userData.wings.push(w);

      const talonLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.03, 0.5, 6), sMat);
      talonLeg.position.set(s * 0.12, 0.78, -0.05);
      body.add(talonLeg);
    }
  } else if (arch === 'segmented_worm' || arch === 'leech') {
    const count = arch === 'segmented_worm' ? 7 : 5;
    for (let i = 0; i < count; i++) {
      const r = 0.38 - i * 0.038;
      const segGroup = new THREE.Group();
      segGroup.position.set(0, r + 0.04, 0.65 - i * 0.4);
      const seg = new THREE.Mesh(new THREE.SphereGeometry(r, 12, 10), i % 2 === 0 ? pMat : sMat);
      segGroup.add(seg);

      const ring = new THREE.Mesh(new THREE.TorusGeometry(r * 0.92, 0.045, 6, 12), aMat);
      segGroup.add(ring);

      if (i < count - 1) {
        const dorsal = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.22, 4), aMat);
        dorsal.position.y = r + 0.08;
        segGroup.add(dorsal);
      }
      body.add(segGroup);
      root.userData.limbs.push(segGroup);
    }
    const mawRing = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.065, 8, 12), aMat);
    mawRing.position.set(0, 0.42, 0.98);
    body.add(mawRing);
    for (let t = 0; t < 6; t++) {
      const a = (t / 6) * Math.PI * 2;
      const tooth = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.18, 4), boneIvoryMat);
      tooth.position.set(Math.cos(a) * 0.2, 0.42 + Math.sin(a) * 0.2, 1.06);
      tooth.rotation.x = Math.PI / 2;
      body.add(tooth);
    }
  } else if (arch === 'beetle') {
    const shell = new THREE.Mesh(
      new THREE.SphereGeometry(0.58, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.56),
      sMat
    );
    shell.scale.set(0.96, 0.78, 1.28);
    shell.position.y = 0.38;
    body.add(shell);

    const ridge = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.14, 1.25), aMat);
    ridge.position.set(0, 0.78, -0.05);
    body.add(ridge);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 10, 8), pMat);
    head.position.set(0, 0.42, 0.65);
    body.add(head);

    addGlowingEyes(body, 0.14, 0.48, 0.84, 0.045, eyeColor);

    const horn = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.58, 6), aMat);
    horn.rotation.x = Math.PI / 3.1;
    horn.position.set(0, 0.54, 0.95);
    body.add(horn);

    for (const s of [-1, 1]) {
      for (let i = 0; i < 3; i++) {
        root.userData.limbs.push(
          addJointedLeg(body, s * 0.46, 0.38, 0.35 - i * 0.34, 0.22, 0.2, 0.055, pMat, darkMetalMat)
        );
      }
    }
  } else if (arch === 'lizard') {
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.32, 0.95, 8, 10), pMat);
    torso.rotation.x = Math.PI / 2;
    torso.position.y = 0.58;
    body.add(torso);

    // Magma / glowing dorsal plates
    for (let i = 0; i < 5; i++) {
      const fin = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.3, 4), aMat);
      fin.position.set(0, 0.96, 0.4 - i * 0.25);
      fin.rotation.x = -0.25;
      body.add(fin);
    }

    const head = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.24, 0.5), sMat);
    head.position.set(0, 0.74, 0.74);
    body.add(head);
    addGlowingEyes(body, 0.12, 0.8, 0.92, 0.042, eyeColor);
    addFangs(body, 0.09, 0.58, 0.96, 0.08, boneIvoryMat);

    for (const s of [-1, 1]) {
      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.28, 5), aMat);
      horn.rotation.x = -0.5;
      horn.position.set(s * 0.13, 0.92, 0.62);
      body.add(horn);
    }

    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.2, 1.15, 7), sMat);
    tail.rotation.x = -Math.PI / 2;
    tail.position.set(0, 0.48, -1.08);
    body.add(tail);

    for (const [lx, lz] of [[-0.28, 0.38], [0.28, 0.38], [-0.28, -0.38], [0.28, -0.38]]) {
      root.userData.limbs.push(addJointedLeg(body, lx, 0.52, lz, 0.26, 0.26, 0.07, pMat, sMat));
    }
  } else if (arch === 'hydra') {
    const torso = new THREE.Mesh(new THREE.SphereGeometry(0.72, 14, 12), pMat);
    torso.scale.set(1.15, 0.86, 1.35);
    torso.position.y = 0.82;
    body.add(torso);

    // Armored belly scales
    const belly = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.45, 1.25), sMat);
    belly.position.set(0, 0.55, 0.2);
    body.add(belly);

    for (const offset of [-0.46, 0, 0.46]) {
      const neckGroup = new THREE.Group();
      neckGroup.position.set(offset, 1.05, 0.38);

      const neck1 = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.22, 0.72, 8), pMat);
      neck1.position.set(0, 0.34, 0.1);
      neck1.rotation.x = 0.28;
      neck1.rotation.z = -offset * 0.4;
      neckGroup.add(neck1);

      const neck2 = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.15, 0.68, 8), sMat);
      neck2.position.set(offset * 0.22, 0.86, 0.32);
      neck2.rotation.x = 0.55;
      neckGroup.add(neck2);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.24, 0.46), pMat);
      head.position.set(offset * 0.28, 1.12, 0.62);
      neckGroup.add(head);

      addGlowingEyes(neckGroup, 0.1, 1.18, 0.78, 0.04, eyeColor);
      addFangs(neckGroup, 0.08, 0.96, 0.8, 0.08, boneIvoryMat);

      const frill = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.24, 5), aMat);
      frill.rotation.x = -0.7;
      frill.position.set(offset * 0.28, 1.28, 0.46);
      neckGroup.add(frill);

      body.add(neckGroup);
      root.userData.limbs.push(neckGroup);
    }

    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.28, 1.4, 8), sMat);
    tail.rotation.x = -Math.PI / 2.2;
    tail.position.set(0, 0.65, -1.35);
    body.add(tail);

    for (const [lx, lz] of [[-0.5, 0.45], [0.5, 0.45], [-0.5, -0.45], [0.5, -0.45]]) {
      root.userData.limbs.push(addJointedLeg(body, lx, 0.68, lz, 0.34, 0.34, 0.11, pMat, sMat));
    }
  } else if (arch === 'skull_spirit' || arch === 'wisp' || arch === 'phantom') {
    const core = new THREE.Mesh(
      arch === 'skull_spirit' ? new THREE.SphereGeometry(0.36, 12, 12) : new THREE.OctahedronGeometry(0.42, 1),
      pMat
    );
    core.position.y = 1.56;
    body.add(core);

    if (arch === 'skull_spirit' || arch === 'phantom') {
      const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.18, 0.26), boneIvoryMat);
      jaw.position.set(0, 1.24, 0.12);
      body.add(jaw);
      addGlowingEyes(body, 0.11, 1.58, 0.32, 0.055, eyeColor);
    }

    const shroud = new THREE.Mesh(
      new THREE.ConeGeometry(0.48, 1.15, 10, 1, true),
      new THREE.MeshStandardMaterial({
        color: def.secondaryColor,
        emissive: def.secondaryColor,
        emissiveIntensity: 0.3,
        transparent: true,
        opacity: 0.85,
        side: THREE.DoubleSide,
      })
    );
    shroud.position.y = 0.96;
    body.add(shroud);

    const halo = new THREE.Mesh(new THREE.TorusGeometry(0.52, 0.045, 8, 20), aMat);
    halo.position.y = 1.62;
    halo.rotation.x = 0.45;
    body.add(halo);
    root.userData.attackArm = halo;

    for (const s of [-1, 1]) {
      const claw = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.55, 5), aMat);
      claw.rotation.x = Math.PI / 2.2;
      claw.position.set(s * 0.45, 1.32, 0.28);
      body.add(claw);
      root.userData.limbs.push(claw);
    }
  } else if (arch === 'war_machine') {
    const hull = new THREE.Mesh(new THREE.BoxGeometry(1.48, 0.92, 1.9), pMat);
    hull.position.y = 0.92;
    body.add(hull);

    // Armored prow with iron spikes
    const ram = new THREE.Mesh(new THREE.ConeGeometry(0.55, 0.95, 4), darkMetalMat);
    ram.rotation.x = Math.PI / 2;
    ram.rotation.y = Math.PI / 4;
    ram.position.set(0, 0.72, 1.22);
    body.add(ram);

    const furnace = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.45, 0.2), aMat);
    furnace.position.set(0, 0.98, 0.96);
    body.add(furnace);

    const boiler = new THREE.Mesh(new THREE.CylinderGeometry(0.44, 0.48, 1.05, 12), sMat);
    boiler.position.set(0, 1.56, -0.28);
    body.add(boiler);

    for (const sx of [-0.28, 0.28]) {
      const stack = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.12, 0.75, 8), darkMetalMat);
      stack.position.set(sx, 2.25, -0.32);
      body.add(stack);
    }

    const cannonGroup = new THREE.Group();
    cannonGroup.position.set(0, 1.45, 0.42);
    const turretDome = new THREE.Mesh(new THREE.SphereGeometry(0.38, 10, 8), sMat);
    cannonGroup.add(turretDome);
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.2, 1.3, 10), darkMetalMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.04, 0.65);
    cannonGroup.add(barrel);
    const muzzleGlow = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.035, 6, 12), aMat);
    muzzleGlow.position.set(0, 0.04, 1.28);
    cannonGroup.add(muzzleGlow);
    body.add(cannonGroup);
    root.userData.attackArm = cannonGroup;

    for (const [wx, wz] of [[-0.86, 0.65], [0.86, 0.65], [-0.86, -0.65], [0.86, -0.65]]) {
      const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.24, 12), darkMetalMat);
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(wx, 0.42, wz);
      body.add(wheel);
      const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.28, 8), aMat);
      hub.rotation.z = Math.PI / 2;
      hub.position.set(wx, 0.42, wz);
      body.add(hub);
      root.userData.limbs.push(wheel);
    }
  } else if (arch === 'undead_cavalry' || arch === 'goblin_rider') {
    const mountTorso = new THREE.Mesh(new THREE.CapsuleGeometry(0.32, 0.98, 8, 12), sMat);
    mountTorso.rotation.x = Math.PI / 2;
    mountTorso.position.y = 0.98;
    body.add(mountTorso);

    const mountNeck = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.22, 0.56, 8), sMat);
    mountNeck.position.set(0, 1.32, 0.56);
    mountNeck.rotation.x = 0.45;
    body.add(mountNeck);

    const mountHead = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.24, 0.48), sMat);
    mountHead.position.set(0, 1.56, 0.84);
    body.add(mountHead);

    addGlowingEyes(body, 0.1, 1.62, 0.95, 0.036, eyeColor);

    for (const [lx, lz] of [[-0.22, 0.42], [0.22, 0.42], [-0.22, -0.42], [0.22, -0.42]]) {
      root.userData.limbs.push(addJointedLeg(body, lx, 0.86, lz, 0.42, 0.42, 0.065, sMat, darkMetalMat));
    }

    // Rider with helmet, pauldrons & lance
    const riderTorso = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.2, 0.72, 8), pMat);
    riderTorso.position.y = 1.62;
    body.add(riderTorso);

    for (const s of [-1, 1]) {
      const pauldron = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 8), darkMetalMat);
      pauldron.position.set(s * 0.28, 1.9, 0);
      body.add(pauldron);
    }

    const riderHead = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 10), pMat);
    riderHead.position.y = 2.12;
    body.add(riderHead);

    const helmCrest = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.34, 6), aMat);
    helmCrest.position.y = 2.38;
    body.add(helmCrest);

    const lancePivot = new THREE.Group();
    lancePivot.position.set(0.36, 1.85, 0.08);
    const lance = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.055, 1.95, 6), darkMetalMat);
    lance.rotation.x = Math.PI / 2.15;
    lance.position.set(0, -0.1, 0.7);
    lancePivot.add(lance);
    const lanceTip = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.34, 5), aMat);
    lanceTip.rotation.x = Math.PI / 2.15;
    lanceTip.position.set(0, -0.2, 1.68);
    lancePivot.add(lanceTip);
    body.add(lancePivot);
    root.userData.attackArm = lancePivot;
  } else if (arch === 'treant' || arch === 'golem' || arch === 'crystal_entity') {
    const chest = new THREE.Mesh(new THREE.DodecahedronGeometry(0.65, 0), pMat);
    chest.scale.set(1.1, 1.05, 0.9);
    chest.position.y = 1.52;
    body.add(chest);

    // Glowing runic / elemental chest core
    const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.28, 0), aMat);
    core.position.set(0, 1.54, 0.48);
    body.add(core);

    const head = new THREE.Mesh(
      arch === 'crystal_entity' ? new THREE.OctahedronGeometry(0.36, 0) : new THREE.BoxGeometry(0.46, 0.44, 0.44),
      arch === 'crystal_entity' ? aMat : sMat
    );
    head.position.y = 2.25;
    body.add(head);

    addGlowingEyes(body, 0.12, 2.28, 0.24, 0.05, eyeColor);

    if (arch === 'treant') {
      const canopy = new THREE.Mesh(new THREE.DodecahedronGeometry(0.75, 1), sMat);
      canopy.position.set(0, 2.75, -0.1);
      body.add(canopy);
    } else if (arch === 'crystal_entity') {
      for (const s of [-1, 1]) {
        const shard = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.65, 5), aMat);
        shard.position.set(s * 0.56, 2.08, -0.05);
        shard.rotation.z = s * -0.45;
        body.add(shard);
      }
    }

    for (const s of [-1, 1]) {
      const shoulder = new THREE.Mesh(new THREE.DodecahedronGeometry(0.32, 0), sMat);
      shoulder.position.set(s * 0.72, 1.88, 0);
      body.add(shoulder);

      const armPivot = new THREE.Group();
      armPivot.position.set(s * 0.78, 1.82, 0);
      const upperArm = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.6, 0.26), pMat);
      upperArm.position.y = -0.32;
      armPivot.add(upperArm);
      const fist = new THREE.Mesh(new THREE.DodecahedronGeometry(0.28, 0), aMat);
      fist.position.y = -0.82;
      armPivot.add(fist);
      body.add(armPivot);
      root.userData.limbs.push(armPivot);
      if (s === 1) root.userData.attackArm = armPivot;

      root.userData.limbs.push(addJointedLeg(body, s * 0.34, 0.96, 0, 0.48, 0.48, 0.16, pMat, sMat));
    }
  } else {
    // Rich Humanoid Monster Variants: Skeletons, Necromancers, Mummy Mages, Frost Archmages, Hell Warlocks, Demon Knights
    const isSkeleton = arch.includes('skeleton');
    const isGoblin = arch.includes('goblin') || arch === 'hobgoblin';
    const isTroll = arch === 'troll' || arch === 'mire_brute';
    const isArmored = arch.includes('knight') || arch.includes('heavy') || arch.includes('sentinel') || arch.includes('armor');
    const isMage = arch.includes('mage') || arch === 'witch' || arch.includes('shaman') || arch.includes('necromancer') || arch.includes('warlock');

    const torso = new THREE.Mesh(
      new THREE.CylinderGeometry(isTroll ? 0.44 : 0.3, isTroll ? 0.34 : 0.23, isSkeleton ? 0.7 : 0.82, 10),
      isSkeleton ? boneIvoryMat : pMat
    );
    torso.position.y = 1.22;
    body.add(torso);

    // Ribcage / Armor Plates / Leather Straps
    if (isSkeleton) {
      for (let r = 0; r < 3; r++) {
        const rib = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.035, 6, 12), boneIvoryMat);
        rib.rotation.x = Math.PI / 2;
        rib.position.y = 1.12 + r * 0.16;
        body.add(rib);
      }
    } else if (isArmored) {
      const chestPlate = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.56, 0.42), sMat);
      chestPlate.position.y = 1.32;
      body.add(chestPlate);
      const emblem = new THREE.Mesh(new THREE.OctahedronGeometry(0.11, 0), aMat);
      emblem.position.set(0, 1.36, 0.23);
      body.add(emblem);
    } else {
      const sash = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.18, 0.36), sMat);
      sash.position.y = 0.94;
      body.add(sash);
    }

    // Pauldrons on warriors & trolls
    if (isArmored || isTroll || arch === 'hobgoblin' || arch === 'hammer_construct') {
      for (const s of [-1, 1]) {
        const pauldron = new THREE.Mesh(new THREE.SphereGeometry(isTroll ? 0.26 : 0.18, 10, 8), sMat);
        pauldron.position.set(s * (isTroll ? 0.52 : 0.38), 1.56, 0);
        body.add(pauldron);
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.24, 5), aMat);
        spike.position.set(s * (isTroll ? 0.58 : 0.42), 1.75, 0);
        spike.rotation.z = s * -0.45;
        body.add(spike);
      }
    }

    // Head & Distinct Facial Silhouette
    const head = new THREE.Mesh(
      new THREE.SphereGeometry(isTroll ? 0.26 : 0.23, 12, 10),
      isSkeleton ? boneIvoryMat : pMat
    );
    head.position.y = 1.82;
    body.add(head);

    addGlowingEyes(body, 0.085, 1.84, 0.2, 0.042, eyeColor);

    if (isSkeleton) {
      const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.12, 0.22), boneIvoryMat);
      jaw.position.set(0, 1.65, 0.08);
      body.add(jaw);
    } else if (isGoblin) {
      const nose = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.22, 5), pMat);
      nose.rotation.x = Math.PI / 2;
      nose.position.set(0, 1.8, 0.28);
      body.add(nose);
      for (const s of [-1, 1]) {
        const ear = new THREE.Mesh(new THREE.ConeGeometry(0.065, 0.28, 4), pMat);
        ear.rotation.z = s * -1.15;
        ear.position.set(s * 0.28, 1.86, 0);
        body.add(ear);
      }
    } else if (isTroll) {
      for (const s of [-1, 1]) {
        const tusk = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.2, 5), boneIvoryMat);
        tusk.position.set(s * 0.11, 1.72, 0.24);
        tusk.rotation.x = 0.25;
        body.add(tusk);
      }
    }

    // Headgear (Caps, Hats, Helmets, Horns)
    if (arch === 'mushroom_mage') {
      const cap = new THREE.Mesh(new THREE.ConeGeometry(0.58, 0.38, 14), sMat);
      cap.position.y = 2.08;
      body.add(cap);
      const spot = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), aMat);
      spot.position.set(0.22, 2.06, 0.22);
      body.add(spot);
    } else if (arch === 'witch' || arch === 'skeleton_mage') {
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.46, 0.04, 12), sMat);
      brim.position.y = 1.98;
      body.add(brim);
      const hat = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.62, 10), sMat);
      hat.position.y = 2.28;
      body.add(hat);
    } else if (arch === 'skeleton_necromancer' || arch === 'frost_mage' || arch === 'hell_warlock_mage') {
      const hood = new THREE.Mesh(new THREE.ConeGeometry(0.32, 0.56, 8), sMat);
      hood.position.set(0, 2.04, -0.02);
      body.add(hood);
      const halo = new THREE.Mesh(new THREE.TorusGeometry(0.38, 0.035, 6, 16), aMat);
      halo.position.set(0, 1.98, -0.18);
      body.add(halo);
      if (arch === 'hell_warlock_mage') {
        for (const s of [-1, 1]) {
          const horn = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.36, 5), aMat);
          horn.position.set(s * 0.16, 2.1, 0.04);
          horn.rotation.z = s * -0.4;
          body.add(horn);
        }
      }
    } else if (arch === 'mummy_mage') {
      // Pharaoh headdress & gold sun disk
      const nemes = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.44, 0.38), sMat);
      nemes.position.set(0, 1.88, -0.04);
      body.add(nemes);
      const sunDisk = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.03, 6, 14), aMat);
      sunDisk.position.set(0, 2.18, 0.04);
      body.add(sunDisk);
    } else if (arch === 'demon_knight') {
      const helm = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.28, 0.36, 10), sMat);
      helm.position.y = 1.88;
      body.add(helm);
      for (const s of [-1, 1]) {
        const horn = new THREE.Mesh(new THREE.ConeGeometry(0.075, 0.44, 6), aMat);
        horn.position.set(s * 0.2, 2.12, 0.02);
        horn.rotation.z = s * -0.52;
        body.add(horn);
      }
    } else if (arch === 'goblin_shaman') {
      for (const s of [-1, 1]) {
        const horn = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.34, 5), boneIvoryMat);
        horn.position.set(s * 0.16, 2.08, 0);
        horn.rotation.z = s * -0.4;
        body.add(horn);
      }
    } else if (isArmored) {
      const helm = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.27, 0.34, 10), sMat);
      helm.position.y = 1.88;
      body.add(helm);
      const crest = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.28, 0.38), aMat);
      crest.position.y = 2.12;
      body.add(crest);
    } else if (arch === 'hobgoblin') {
      const mohawk = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.28, 0.34), aMat);
      mohawk.position.y = 2.08;
      body.add(mohawk);
    }

    // Cape / Robe / Backpack
    if (isMage || arch.includes('assassin') || arch.includes('knight')) {
      const cape = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.95, 0.05), sMat);
      cape.position.set(0, 1.15, -0.25);
      cape.rotation.x = 0.15;
      body.add(cape);
    } else if (arch === 'goblin_engineer' || arch === 'goblin_bomber') {
      const pack = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.45, 0.26), darkMetalMat);
      pack.position.set(0, 1.28, -0.28);
      body.add(pack);
    }

    // Jointed Legs
    for (const s of [-1, 1]) {
      root.userData.limbs.push(
        addJointedLeg(
          body,
          s * (isTroll ? 0.24 : 0.15),
          0.84,
          0,
          0.42,
          0.42,
          isTroll ? 0.12 : 0.075,
          isSkeleton ? boneIvoryMat : pMat,
          sMat
        )
      );
    }

    // Left Arm + Shield / Offhand
    const leftArm = new THREE.Group();
    leftArm.position.set(isTroll ? -0.52 : -0.36, 1.48, 0);
    const lSleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.065, 0.56, 7), isSkeleton ? boneIvoryMat : pMat);
    lSleeve.position.y = -0.28;
    leftArm.add(lSleeve);
    body.add(leftArm);
    root.userData.limbs.push(leftArm);

    if (isArmored) {
      const shield = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.72, 0.52), sMat);
      shield.position.set(-0.1, -0.38, 0.14);
      leftArm.add(shield);
      const boss = new THREE.Mesh(new THREE.SphereGeometry(0.11, 8, 8), aMat);
      boss.position.set(-0.14, -0.38, 0.14);
      leftArm.add(boss);
    } else if (arch === 'goblin_assassin') {
      const offBlade = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.52, 4), aMat);
      offBlade.rotation.x = Math.PI / 2;
      offBlade.position.set(0, -0.55, 0.25);
      leftArm.add(offBlade);
    }

    // Right Attack Arm + Bespoke Weapon
    const weaponPivot = new THREE.Group();
    weaponPivot.position.set(isTroll ? 0.52 : 0.36, 1.48, 0.06);
    const rSleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.07, 0.56, 7), isSkeleton ? boneIvoryMat : pMat);
    rSleeve.position.y = -0.28;
    weaponPivot.add(rSleeve);

    const wHand = new THREE.Group();
    wHand.position.set(0, -0.52, 0.12);
    wHand.rotation.x = Math.PI / 2.3;

    if (arch === 'goblin_bomber') {
      const bomb = new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 10), darkMetalMat);
      wHand.add(bomb);
      const fuse = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), aMat);
      fuse.position.y = 0.24;
      wHand.add(fuse);
    } else if (isMage) {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.045, 1.5, 7), sMat);
      pole.position.y = 0.4;
      wHand.add(pole);
      const orb = new THREE.Mesh(new THREE.OctahedronGeometry(0.16, 0), aMat);
      orb.position.y = 1.22;
      wHand.add(orb);
    } else if (arch === 'skeleton_archer') {
      const stave = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.035, 6, 14, Math.PI * 1.1), sMat);
      stave.rotation.z = -Math.PI * 0.55;
      stave.position.y = 0.2;
      wHand.add(stave);
    } else if (arch === 'hammer_construct' || isTroll) {
      const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 1.15, 7), sMat);
      handle.position.y = 0.45;
      wHand.add(handle);
      const hammerHead = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.28, 0.52), aMat);
      hammerHead.position.y = 0.98;
      wHand.add(hammerHead);
    } else if (arch === 'goblin_axe') {
      const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, 0.9, 6), sMat);
      handle.position.y = 0.35;
      wHand.add(handle);
      const axeBlade = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.28, 0.06), darkMetalMat);
      axeBlade.position.set(0.12, 0.72, 0);
      wHand.add(axeBlade);
    } else {
      // Runed Sword / Spear / Dagger
      const len = arch === 'spear_sentinel' ? 1.55 : arch === 'goblin_assassin' ? 0.55 : 0.98;
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.08, len, 0.035), darkMetalMat);
      blade.position.y = len * 0.5 + 0.1;
      wHand.add(blade);
      const edgeGlow = new THREE.Mesh(new THREE.BoxGeometry(0.025, len * 0.85, 0.045), aMat);
      edgeGlow.position.y = len * 0.5 + 0.1;
      wHand.add(edgeGlow);
      const guard = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.05, 0.08), aMat);
      guard.position.y = 0.1;
      wHand.add(guard);
    }

    weaponPivot.add(wHand);
    body.add(weaponPivot);
    root.userData.attackArm = weaponPivot;
  }

  root.scale.setScalar(def.scale);
  root.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = true;
    }
  });
  return root;
}

export function animateEnemyModel(
  model: THREE.Group,
  def: EnemyDef,
  time: number,
  isMoving: boolean,
  isAttacking: boolean
) {
  const limbs = model.userData.limbs as THREE.Object3D[];
  const wings = model.userData.wings as THREE.Object3D[];
  const body = model.userData.body as THREE.Group;
  const arm = model.userData.attackArm as THREE.Object3D | null;

  if (def.flies && wings.length > 0) {
    wings.forEach((w, i) => {
      const side = i % 2 === 0 ? -1 : 1;
      w.rotation.z = side * Math.sin(time * 12) * 0.62;
    });
    body.position.y = Math.sin(time * 4) * 0.25 + 0.55;
  } else if (def.flies) {
    body.position.y = Math.sin(time * 3.5) * 0.32 + 0.45;
  } else if (isMoving) {
    limbs.forEach((l, i) => {
      l.rotation.x = Math.sin(time * 10 + i * Math.PI) * 0.58;
    });
    body.position.y = Math.abs(Math.sin(time * 10)) * 0.06;
  } else {
    limbs.forEach((l) => {
      l.rotation.x = Math.sin(time * 1.8) * 0.04;
    });
    body.position.y = Math.sin(time * 2.2) * 0.02;
  }

  if (arm) {
    arm.rotation.x = isAttacking ? -Math.abs(Math.sin(time * 18)) * 1.35 : Math.sin(time * 2.2) * 0.1;
  }
}
