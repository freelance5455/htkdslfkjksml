import * as THREE from 'three';

export type WeaponSkin = 'tactical' | 'urban' | 'desert' | 'arctic' | 'outbreak' | 'blackout' | 'industrial';

export interface WeaponDef {
  id: string;
  name: string;
  type: 'rifle' | 'shotgun' | 'pistol' | 'sniper' | 'smg' | 'lmg' | 'dmr' | 'revolver' | 'raygun';
  damage: number;
  fireRate: number; // shots per second
  magSize: number;
  maxAmmo: number;
  reloadTime: number; // seconds
  recoilKick: number;
  recoilClimb: number;
  spread: number;
  pellets?: number;
  adsFov: number;
  adsOffset: THREE.Vector3;
  hipOffset: THREE.Vector3;
  description: string;
  skin?: WeaponSkin;
}

export const WEAPON_REGISTRY: Record<string, WeaponDef> = {
  rifle: {
    id: 'rifle',
    name: 'AR-16 Valkyrie',
    type: 'rifle',
    damage: 52,
    fireRate: 9.8,
    magSize: 30,
    maxAmmo: 180,
    reloadTime: 1.8,
    recoilKick: 0.038,
    recoilClimb: 0.032,
    spread: 0.022,
    adsFov: 48,
    adsOffset: new THREE.Vector3(0, -0.19, -0.42),
    hipOffset: new THREE.Vector3(0.24, -0.25, -0.48),
    description: 'Select-fire assault rifle with high precision and balanced recoil.',
  },
  ar2: {
    id: 'ar2',
    name: 'KBAR-32 Phantom',
    type: 'rifle',
    damage: 48,
    fireRate: 11.2,
    magSize: 35,
    maxAmmo: 210,
    reloadTime: 1.65,
    recoilKick: 0.035,
    recoilClimb: 0.030,
    spread: 0.020,
    adsFov: 46,
    adsOffset: new THREE.Vector3(0, -0.185, -0.40),
    hipOffset: new THREE.Vector3(0.23, -0.24, -0.46),
    description: 'High-cyclic bullpup rifle with reflex optic and superior handling.',
  },
  shotgun: {
    id: 'shotgun',
    name: 'Striker-12 Combat',
    type: 'shotgun',
    damage: 28,
    pellets: 8,
    fireRate: 1.8,
    magSize: 8,
    maxAmmo: 48,
    reloadTime: 2.2,
    recoilKick: 0.085,
    recoilClimb: 0.065,
    spread: 0.08,
    adsFov: 58,
    adsOffset: new THREE.Vector3(0, -0.21, -0.40),
    hipOffset: new THREE.Vector3(0.22, -0.26, -0.46),
    description: 'Devastating close-range tactical scattergun.',
  },
  smg: {
    id: 'smg',
    name: 'Spectre-X PDW',
    type: 'smg',
    damage: 34,
    fireRate: 13.5,
    magSize: 40,
    maxAmmo: 240,
    reloadTime: 1.5,
    recoilKick: 0.032,
    recoilClimb: 0.028,
    spread: 0.038,
    adsFov: 52,
    adsOffset: new THREE.Vector3(0, -0.185, -0.38),
    hipOffset: new THREE.Vector3(0.22, -0.24, -0.44),
    description: 'Ultra-fast cycling compact submachine gun for close quarters.',
  },
  smg2: {
    id: 'smg2',
    name: 'Vector-9 Cyclone',
    type: 'smg',
    damage: 30,
    fireRate: 15.5,
    magSize: 32,
    maxAmmo: 224,
    reloadTime: 1.4,
    recoilKick: 0.026,
    recoilClimb: 0.024,
    spread: 0.032,
    adsFov: 50,
    adsOffset: new THREE.Vector3(0, -0.18, -0.36),
    hipOffset: new THREE.Vector3(0.21, -0.23, -0.42),
    description: 'Super-V recoil mitigation system for pinpoint laser CQB fire.',
  },
  pistol: {
    id: 'pistol',
    name: 'Apex-9 Tactical',
    type: 'pistol',
    damage: 42,
    fireRate: 5.2,
    magSize: 15,
    maxAmmo: 90,
    reloadTime: 1.3,
    recoilKick: 0.028,
    recoilClimb: 0.022,
    spread: 0.016,
    adsFov: 55,
    adsOffset: new THREE.Vector3(0, -0.18, -0.38),
    hipOffset: new THREE.Vector3(0.20, -0.22, -0.42),
    description: 'Rapid semi-automatic sidearm with lightning fast handling.',
  },
  revolver: {
    id: 'revolver',
    name: 'Magnum-44 Enforcer',
    type: 'revolver',
    damage: 135,
    fireRate: 2.2,
    magSize: 6,
    maxAmmo: 42,
    reloadTime: 2.0,
    recoilKick: 0.075,
    recoilClimb: 0.060,
    spread: 0.012,
    adsFov: 52,
    adsOffset: new THREE.Vector3(0, -0.18, -0.38),
    hipOffset: new THREE.Vector3(0.20, -0.22, -0.42),
    description: 'Heavy caliber six-shot hand cannon delivering devastating stopping power.',
  },
  sniper: {
    id: 'sniper',
    name: 'Recon-50 Anti-Materiel',
    type: 'sniper',
    damage: 320,
    fireRate: 1.1,
    magSize: 5,
    maxAmmo: 30,
    reloadTime: 2.8,
    recoilKick: 0.12,
    recoilClimb: 0.09,
    spread: 0.003,
    adsFov: 20,
    adsOffset: new THREE.Vector3(0, -0.20, -0.36),
    hipOffset: new THREE.Vector3(0.24, -0.26, -0.52),
    description: 'High caliber precision anti-materiel sniper rifle with high-power optic.',
  },
  dmr: {
    id: 'dmr',
    name: 'Shadow-338 DMR',
    type: 'dmr',
    damage: 120,
    fireRate: 3.2,
    magSize: 12,
    maxAmmo: 72,
    reloadTime: 2.2,
    recoilKick: 0.055,
    recoilClimb: 0.045,
    spread: 0.008,
    adsFov: 32,
    adsOffset: new THREE.Vector3(0, -0.19, -0.38),
    hipOffset: new THREE.Vector3(0.23, -0.25, -0.48),
    description: 'Designated marksman rifle bridging high damage and rapid semi-auto follow-ups.',
  },
  lmg: {
    id: 'lmg',
    name: 'Titan-75 Havoc',
    type: 'lmg',
    damage: 46,
    fireRate: 10.5,
    magSize: 75,
    maxAmmo: 300,
    reloadTime: 3.4,
    recoilKick: 0.045,
    recoilClimb: 0.038,
    spread: 0.035,
    adsFov: 50,
    adsOffset: new THREE.Vector3(0, -0.21, -0.44),
    hipOffset: new THREE.Vector3(0.26, -0.27, -0.50),
    description: 'Heavy drum-fed light machine gun for continuous horde suppression.',
  },
  raygun: {
    id: 'raygun',
    name: 'ZX-1 Quantum Ray Gun',
    type: 'raygun',
    damage: 260,
    fireRate: 3.6,
    magSize: 20,
    maxAmmo: 160,
    reloadTime: 2.0,
    recoilKick: 0.024,
    recoilClimb: 0.018,
    spread: 0.005,
    adsFov: 48,
    adsOffset: new THREE.Vector3(0, -0.18, -0.38),
    hipOffset: new THREE.Vector3(0.20, -0.22, -0.42),
    description: 'Original directed plasma energy weapon with glowing chamber and radial blast damage.',
  },
};

export class WeaponModels {
  // Shared realistic tactical materials
  private static gunSteelMat = new THREE.MeshStandardMaterial({
    color: 0x22262a,
    metalness: 0.88,
    roughness: 0.26,
  });

  private static gunDarkMetalMat = new THREE.MeshStandardMaterial({
    color: 0x141618,
    metalness: 0.9,
    roughness: 0.32,
  });

  private static gunPolymerMat = new THREE.MeshStandardMaterial({
    color: 0x1a1c1e,
    roughness: 0.65,
    metalness: 0.12,
  });

  private static rubberGripMat = new THREE.MeshStandardMaterial({
    color: 0x0f1113,
    roughness: 0.85,
    metalness: 0.05,
  });

  private static opticGlassMat = new THREE.MeshStandardMaterial({
    color: 0x064e3b,
    transparent: true,
    opacity: 0.45,
    roughness: 0.1,
    metalness: 0.9,
  });

  private static holoGlowMat = new THREE.MeshBasicMaterial({
    color: 0x22c55e, // Illuminated bright tactical green
  });

  private static redDotGlowMat = new THREE.MeshBasicMaterial({
    color: 0xef4444, // Crisp red reticle dot
  });

  private static sleeveMat = new THREE.MeshStandardMaterial({
    color: 0x3b4737, // Spec-ops olive sleeve
    roughness: 0.8,
  });

  private static gloveMat = new THREE.MeshStandardMaterial({
    color: 0x18181b, // Carbon knuckle tactical glove
    roughness: 0.65,
    metalness: 0.2,
  });

  // Attach realistic first person hands/arms rig
  static attachArms(weaponGroup: THREE.Group) {
    const armsGroup = new THREE.Group();
    armsGroup.name = 'fps_arms';

    // Right Arm (Holding main grip)
    const rightArm = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.055, 0.36, 8), this.sleeveMat);
    rightArm.position.set(0.065, -0.22, 0.14);
    rightArm.rotation.set(Math.PI / 4, 0, -Math.PI / 10);
    armsGroup.add(rightArm);

    // Right Glove with textured wrist & knuckle plate
    const rightHand = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.07, 0.08), this.gloveMat);
    rightHand.position.set(0.035, -0.11, 0.05);
    rightHand.rotation.set(0.2, 0.1, -0.2);
    armsGroup.add(rightHand);

    // Left Arm (Supporting forend/rail)
    const leftArm = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.055, 0.42, 8), this.sleeveMat);
    leftArm.position.set(-0.15, -0.22, -0.06);
    leftArm.rotation.set(Math.PI / 3.4, 0.2, Math.PI / 5);
    armsGroup.add(leftArm);

    // Left Glove
    const leftHand = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.07, 0.08), this.gloveMat);
    leftHand.position.set(-0.065, -0.08, -0.17);
    armsGroup.add(leftHand);

    weaponGroup.add(armsGroup);
  }

  // Helper to add top Picatinny Rail
  private static addPicatinnyRail(group: THREE.Group, length: number, y: number, z: number) {
    const railBase = new THREE.Mesh(new THREE.BoxGeometry(0.024, 0.012, length), this.gunDarkMetalMat);
    railBase.position.set(0, y, z);
    group.add(railBase);
  }

  // --- 1. AR-16 Valkyrie Tactical Rifle ---
  static createRifle(): { model: THREE.Group; mag: THREE.Mesh; muzzlePos: THREE.Vector3 } {
    const group = new THREE.Group();

    // Upper & Lower Receiver
    const upperRec = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.065, 0.28), this.gunSteelMat);
    upperRec.position.set(0, 0.02, 0);
    group.add(upperRec);

    const lowerRec = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.055, 0.22), this.gunSteelMat);
    lowerRec.position.set(0, -0.03, 0.02);
    group.add(lowerRec);

    // Fluted Barrel
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.015, 0.38, 12), this.gunSteelMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.02, -0.32);
    group.add(barrel);

    // M-LOK Rail Handguard
    const handguard = new THREE.Mesh(new THREE.BoxGeometry(0.052, 0.062, 0.26), this.gunPolymerMat);
    handguard.position.set(0, 0.02, -0.23);
    group.add(handguard);

    // Aggressive Muzzle Brake
    const muzzle = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.028, 0.06), this.gunDarkMetalMat);
    muzzle.position.set(0, 0.02, -0.52);
    group.add(muzzle);

    // Picatinny top rail
    this.addPicatinnyRail(group, 0.32, 0.058, -0.04);

    // Holographic Optic with glass & reticle
    const holoHood = new THREE.Mesh(new THREE.BoxGeometry(0.046, 0.052, 0.08), this.gunDarkMetalMat);
    holoHood.position.set(0, 0.09, -0.02);
    group.add(holoHood);

    const holoGlass = new THREE.Mesh(new THREE.PlaneGeometry(0.038, 0.038), this.opticGlassMat);
    holoGlass.position.set(0, 0.09, -0.02);
    group.add(holoGlass);

    const reticle = new THREE.Mesh(new THREE.RingGeometry(0.003, 0.007, 8), this.holoGlowMat);
    reticle.position.set(0, 0.09, -0.025);
    group.add(reticle);

    // Ergonomic Textured Pistol Grip
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.12, 0.055), this.rubberGripMat);
    grip.position.set(0, -0.095, 0.08);
    grip.rotation.x = 0.26;
    group.add(grip);

    // Curved Ribbed Magazine (Detachable for reload animation)
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.18, 0.085), this.gunPolymerMat);
    mag.position.set(0, -0.11, -0.04);
    mag.rotation.x = -0.15;
    mag.name = 'magazine';
    group.add(mag);

    // Adjustable Tactical Crane Stock
    const bufferTube = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.22, 10), this.gunSteelMat);
    bufferTube.rotation.x = Math.PI / 2;
    bufferTube.position.set(0, 0.01, 0.22);
    group.add(bufferTube);

    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.046, 0.12, 0.18), this.gunPolymerMat);
    stock.position.set(0, -0.01, 0.28);
    group.add(stock);

    this.attachArms(group);

    return {
      model: group,
      mag,
      muzzlePos: new THREE.Vector3(0, 0.02, -0.56),
    };
  }

  // --- 2. Striker-12 Combat Shotgun ---
  static createShotgun(): { model: THREE.Group; mag: THREE.Mesh; muzzlePos: THREE.Vector3 } {
    const group = new THREE.Group();

    // Heavy Aluminum Receiver
    const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.095, 0.34), this.gunSteelMat);
    receiver.position.set(0, 0, 0);
    group.add(receiver);

    // Heavy 12-Gauge Barrel
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.42, 12), this.gunSteelMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.02, -0.34);
    group.add(barrel);

    // Magazine Tube under barrel
    const magTube = new THREE.Mesh(new THREE.CylinderGeometry(0.017, 0.017, 0.38, 10), this.gunDarkMetalMat);
    magTube.rotation.x = Math.PI / 2;
    magTube.position.set(0, -0.025, -0.32);
    group.add(magTube);

    // Tactical Ribbed Pump Forend (Animated)
    const pump = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.18, 12), this.rubberGripMat);
    pump.rotation.x = Math.PI / 2;
    pump.position.set(0, -0.015, -0.28);
    pump.name = 'magazine';
    group.add(pump);

    // Pistol Grip
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.12, 0.06), this.rubberGripMat);
    grip.position.set(0, -0.09, 0.09);
    grip.rotation.x = 0.25;
    group.add(grip);

    // Solid Fixed Tactical Stock with Rubber Pad
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.048, 0.12, 0.24), this.gunPolymerMat);
    stock.position.set(0, -0.025, 0.26);
    group.add(stock);

    // Ghost Ring Sights
    const frontSight = new THREE.Mesh(new THREE.BoxGeometry(0.008, 0.02, 0.01), this.gunDarkMetalMat);
    frontSight.position.set(0, 0.05, -0.52);
    group.add(frontSight);

    const rearSight = new THREE.Mesh(new THREE.TorusGeometry(0.012, 0.003, 6, 12), this.gunDarkMetalMat);
    rearSight.position.set(0, 0.06, 0.05);
    group.add(rearSight);

    this.attachArms(group);

    return {
      model: group,
      mag: pump,
      muzzlePos: new THREE.Vector3(0, 0.02, -0.56),
    };
  }

  // --- 3. Apex-9 Tactical Pistol ---
  static createPistol(): { model: THREE.Group; mag: THREE.Mesh; muzzlePos: THREE.Vector3 } {
    const group = new THREE.Group();

    // Serrated Slide
    const slide = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.046, 0.22), this.gunSteelMat);
    slide.position.set(0, 0.03, -0.02);
    group.add(slide);

    // Ejection Port cutout
    const ejectPort = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.02, 0.05), this.gunDarkMetalMat);
    ejectPort.position.set(0.015, 0.04, -0.01);
    group.add(ejectPort);

    // Polymer Frame with accessory rail
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.04, 0.19), this.gunPolymerMat);
    frame.position.set(0, 0, -0.02);
    group.add(frame);

    // Textured Pistol Grip
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.12, 0.056), this.rubberGripMat);
    grip.position.set(0, -0.07, 0.04);
    grip.rotation.x = 0.22;
    group.add(grip);

    // Magazine Baseplate
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.033, 0.11, 0.049), this.gunDarkMetalMat);
    mag.position.set(0, -0.08, 0.04);
    mag.rotation.x = 0.22;
    mag.name = 'magazine';
    group.add(mag);

    // Tritium Night Sights (Green dots)
    const frontDot = new THREE.Mesh(new THREE.SphereGeometry(0.003, 6, 6), this.holoGlowMat);
    frontDot.position.set(0, 0.058, -0.12);
    group.add(frontDot);

    const rearL = new THREE.Mesh(new THREE.SphereGeometry(0.003, 6, 6), this.holoGlowMat);
    rearL.position.set(-0.01, 0.058, 0.08);
    group.add(rearL);

    const rearR = new THREE.Mesh(new THREE.SphereGeometry(0.003, 6, 6), this.holoGlowMat);
    rearR.position.set(0.01, 0.058, 0.08);
    group.add(rearR);

    this.attachArms(group);

    return {
      model: group,
      mag,
      muzzlePos: new THREE.Vector3(0, 0.03, -0.16),
    };
  }

  // --- 4. Recon-50 Heavy Sniper Rifle ---
  static createSniper(): { model: THREE.Group; mag: THREE.Mesh; muzzlePos: THREE.Vector3 } {
    const group = new THREE.Group();

    // Heavy Monolithic Receiver
    const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.09, 0.42), this.gunSteelMat);
    receiver.position.set(0, 0, 0);
    group.add(receiver);

    // Long Fluted Bull Barrel
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.02, 0.7, 12), this.gunSteelMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.01, -0.52);
    group.add(barrel);

    // Multi-port Heavy Muzzle Brake
    const muzzle = new THREE.Mesh(new THREE.BoxGeometry(0.044, 0.044, 0.11), this.gunDarkMetalMat);
    muzzle.position.set(0, 0.01, -0.88);
    group.add(muzzle);

    // High-Power Telescopic Sniper Scope
    const scopeTube = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.32, 12), this.gunDarkMetalMat);
    scopeTube.rotation.x = Math.PI / 2;
    scopeTube.position.set(0, 0.088, -0.05);
    group.add(scopeTube);

    const scopeBell = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.02, 0.09, 12), this.gunDarkMetalMat);
    scopeBell.rotation.x = Math.PI / 2;
    scopeBell.position.set(0, 0.088, -0.22);
    group.add(scopeBell);

    const scopeEyepiece = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.02, 0.06, 12), this.gunDarkMetalMat);
    scopeEyepiece.rotation.x = Math.PI / 2;
    scopeEyepiece.position.set(0, 0.088, 0.12);
    group.add(scopeEyepiece);

    // Heavy Box Magazine
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.15, 0.09), this.gunDarkMetalMat);
    mag.position.set(0, -0.1, -0.02);
    mag.name = 'magazine';
    group.add(mag);

    // Precision Stock with Adjustable Cheek Riser
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.14, 0.34), this.gunPolymerMat);
    stock.position.set(0, -0.02, 0.34);
    group.add(stock);

    const cheekRiser = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.03, 0.12), this.rubberGripMat);
    cheekRiser.position.set(0, 0.06, 0.32);
    group.add(cheekRiser);

    this.attachArms(group);

    return {
      model: group,
      mag,
      muzzlePos: new THREE.Vector3(0, 0.01, -0.94),
    };
  }

  // --- 5. Spectre-X Submachine Gun ---
  static createSMG(): { model: THREE.Group; mag: THREE.Mesh; muzzlePos: THREE.Vector3 } {
    const group = new THREE.Group();

    // Compact Receiver
    const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.048, 0.082, 0.28), this.gunSteelMat);
    receiver.position.set(0, 0, 0);
    group.add(receiver);

    // Short Threaded Barrel
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.014, 0.22, 10), this.gunDarkMetalMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.005, -0.22);
    group.add(barrel);

    // Micro Red Dot Sight
    const dotMount = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.036, 0.06), this.gunDarkMetalMat);
    dotMount.position.set(0, 0.06, -0.02);
    group.add(dotMount);

    const dotReticle = new THREE.Mesh(new THREE.SphereGeometry(0.004, 6, 6), this.redDotGlowMat);
    dotReticle.position.set(0, 0.064, -0.02);
    group.add(dotReticle);

    // Angled Foregrip
    const foregrip = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.08, 0.05), this.rubberGripMat);
    foregrip.position.set(0, -0.06, -0.16);
    foregrip.rotation.x = -0.3;
    group.add(foregrip);

    // Extended High-Cap Stick Magazine
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.22, 0.05), this.gunPolymerMat);
    mag.position.set(0, -0.13, -0.02);
    mag.rotation.x = -0.1;
    mag.name = 'magazine';
    group.add(mag);

    // Collapsible Skeleton Stock
    const stockRodL = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.24, 6), this.gunDarkMetalMat);
    stockRodL.rotation.x = Math.PI / 2;
    stockRodL.position.set(-0.02, 0, 0.22);
    group.add(stockRodL);

    const stockRodR = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.24, 6), this.gunDarkMetalMat);
    stockRodR.rotation.x = Math.PI / 2;
    stockRodR.position.set(0.02, 0, 0.22);
    group.add(stockRodR);

    const buttpad = new THREE.Mesh(new THREE.BoxGeometry(0.044, 0.1, 0.02), this.rubberGripMat);
    buttpad.position.set(0, -0.02, 0.34);
    group.add(buttpad);

    this.attachArms(group);

    return {
      model: group,
      mag,
      muzzlePos: new THREE.Vector3(0, 0.005, -0.34),
    };
  }

  // --- 6. Magnum-44 Enforcer (Heavy Hand Cannon) ---
  static createRevolver(): { model: THREE.Group; mag: THREE.Mesh; muzzlePos: THREE.Vector3 } {
    const group = new THREE.Group();

    // Solid Heavy Frame
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.065, 0.18), this.gunSteelMat);
    frame.position.set(0, 0.02, 0);
    group.add(frame);

    // 6-Shot Fluted Cylinder (Animated reload pivot)
    const cylinder = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.08, 12), this.gunDarkMetalMat);
    cylinder.rotation.x = Math.PI / 2;
    cylinder.position.set(0, 0.02, -0.04);
    cylinder.name = 'magazine';
    group.add(cylinder);

    // Heavy Bull Barrel with Ventilated Rib
    const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.048, 0.24), this.gunSteelMat);
    barrel.position.set(0, 0.035, -0.2);
    group.add(barrel);

    // Front Ramp Sight
    const frontSight = new THREE.Mesh(new THREE.BoxGeometry(0.006, 0.015, 0.02), this.redDotGlowMat);
    frontSight.position.set(0, 0.068, -0.3);
    group.add(frontSight);

    // Rubber Combat Grip
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.13, 0.06), this.rubberGripMat);
    grip.position.set(0, -0.08, 0.06);
    grip.rotation.x = 0.28;
    group.add(grip);

    // Hammer
    const hammer = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.03, 0.03), this.gunDarkMetalMat);
    hammer.position.set(0, 0.06, 0.08);
    group.add(hammer);

    this.attachArms(group);

    return {
      model: group,
      mag: cylinder,
      muzzlePos: new THREE.Vector3(0, 0.035, -0.32),
    };
  }

  // --- 7. Titan-75 Havoc (Heavy Suppression LMG) ---
  static createLMG(): { model: THREE.Group; mag: THREE.Mesh; muzzlePos: THREE.Vector3 } {
    const group = new THREE.Group();

    // Heavy Box Receiver
    const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.11, 0.42), this.gunSteelMat);
    receiver.position.set(0, 0.02, 0);
    group.add(receiver);

    // Heavy Fluted Barrel with Heat Fins
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.025, 0.55, 12), this.gunDarkMetalMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.03, -0.46);
    group.add(barrel);

    // Top Carry Handle
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.08, 0.22), this.gunPolymerMat);
    handle.position.set(0, 0.12, -0.15);
    group.add(handle);

    // 75-Round Drum Magazine
    const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.12, 16), this.gunDarkMetalMat);
    drum.rotation.z = Math.PI / 2;
    drum.position.set(-0.06, -0.12, -0.04);
    drum.name = 'magazine';
    group.add(drum);

    // Heavy Bipod (Folded)
    const bipodL = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.28, 6), this.gunSteelMat);
    bipodL.position.set(-0.04, -0.06, -0.42);
    bipodL.rotation.x = Math.PI / 4;
    group.add(bipodL);

    const bipodR = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.28, 6), this.gunSteelMat);
    bipodR.position.set(0.04, -0.06, -0.42);
    bipodR.rotation.x = Math.PI / 4;
    group.add(bipodR);

    // Heavy Fixed Stock
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.14, 0.28), this.gunPolymerMat);
    stock.position.set(0, -0.01, 0.34);
    group.add(stock);

    // Grip
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.13, 0.065), this.rubberGripMat);
    grip.position.set(0, -0.09, 0.1);
    grip.rotation.x = 0.25;
    group.add(grip);

    this.attachArms(group);

    return {
      model: group,
      mag: drum,
      muzzlePos: new THREE.Vector3(0, 0.03, -0.74),
    };
  }

  // --- 8. Shadow-338 DMR (Designated Marksman Rifle) ---
  static createDMR(): { model: THREE.Group; mag: THREE.Mesh; muzzlePos: THREE.Vector3 } {
    const group = new THREE.Group();

    // Sleek Monolithic Receiver
    const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.08, 0.38), this.gunSteelMat);
    receiver.position.set(0, 0.01, 0);
    group.add(receiver);

    // Precision Threaded Barrel
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.018, 0.52, 12), this.gunDarkMetalMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.02, -0.42);
    group.add(barrel);

    // Mid-Power DMR Scope
    const scope = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.26, 12), this.gunDarkMetalMat);
    scope.rotation.x = Math.PI / 2;
    scope.position.set(0, 0.08, -0.06);
    group.add(scope);

    const reticle = new THREE.Mesh(new THREE.RingGeometry(0.003, 0.008, 8), this.holoGlowMat);
    reticle.position.set(0, 0.08, -0.19);
    group.add(reticle);

    // 12-Round Box Magazine
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.16, 0.08), this.gunPolymerMat);
    mag.position.set(0, -0.11, -0.04);
    mag.rotation.x = -0.1;
    mag.name = 'magazine';
    group.add(mag);

    // Tactical Marksman Stock
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.048, 0.12, 0.26), this.gunPolymerMat);
    stock.position.set(0, -0.01, 0.3);
    group.add(stock);

    // Grip
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.12, 0.055), this.rubberGripMat);
    grip.position.set(0, -0.08, 0.08);
    grip.rotation.x = 0.26;
    group.add(grip);

    this.attachArms(group);

    return {
      model: group,
      mag,
      muzzlePos: new THREE.Vector3(0, 0.02, -0.68),
    };
  }

  // --- 9. ZX-1 Quantum Ray Gun (Original Sci-Fi Weapon - Requirement 13 & 14) ---
  static createRayGun(): { model: THREE.Group; mag: THREE.Mesh; muzzlePos: THREE.Vector3 } {
    const group = new THREE.Group();

    // Futuristic White/Chrome Chassis
    const chassisMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, metalness: 0.85, roughness: 0.2 });
    const brassMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, metalness: 0.9, roughness: 0.25 });
    const plasmaMat = new THREE.MeshBasicMaterial({ color: 0x10b981 });

    const body = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.09, 0.26), chassisMat);
    body.position.set(0, 0.02, 0);
    group.add(body);

    // Glowing Central Energy Chamber
    const chamber = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.14, 12), plasmaMat);
    chamber.rotation.x = Math.PI / 2;
    chamber.position.set(0, 0.035, -0.02);
    group.add(chamber);

    const plasmaLight = new THREE.PointLight(0x10b981, 1.8, 4);
    plasmaLight.position.set(0, 0.035, -0.02);
    group.add(plasmaLight);

    // Forward Emitter Barrel with 3 Concentric Brass Rings
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.26, 12), chassisMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.035, -0.22);
    group.add(barrel);

    [-0.14, -0.22, -0.30].forEach((rz, i) => {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.028 - i * 0.003, 0.005, 8, 16), brassMat);
      ring.position.set(0, 0.035, rz);
      group.add(ring);
    });

    // Removable Plasma Energy Cell (Battery)
    const battery = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.12, 10), new THREE.MeshStandardMaterial({ color: 0x059669, emissive: 0x10b981, emissiveIntensity: 0.5 }));
    battery.position.set(0, -0.08, 0.04);
    battery.name = 'magazine';
    group.add(battery);

    // Grip
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.12, 0.055), this.rubberGripMat);
    grip.position.set(0, -0.07, 0.05);
    grip.rotation.x = 0.25;
    group.add(grip);

    // Sights
    const sight = new THREE.Mesh(new THREE.RingGeometry(0.004, 0.009, 8), plasmaMat);
    sight.position.set(0, 0.08, -0.06);
    group.add(sight);

    this.attachArms(group);

    return {
      model: group,
      mag: battery,
      muzzlePos: new THREE.Vector3(0, 0.035, -0.36),
    };
  }

  // Factory function supporting custom weapon skins (Requirement 25)
  static buildWeapon(type: string, skin: WeaponSkin = 'tactical'): { model: THREE.Group; mag: THREE.Mesh; muzzlePos: THREE.Vector3 } {
    let built: { model: THREE.Group; mag: THREE.Mesh; muzzlePos: THREE.Vector3 };
    switch (type) {
      case 'shotgun':
        built = this.createShotgun();
        break;
      case 'pistol':
        built = this.createPistol();
        break;
      case 'revolver':
        built = this.createRevolver();
        break;
      case 'raygun':
        built = this.createRayGun();
        break;
      case 'sniper':
        built = this.createSniper();
        break;
      case 'dmr':
        built = this.createDMR();
        break;
      case 'lmg':
        built = this.createLMG();
        break;
      case 'smg':
      case 'smg2':
        built = this.createSMG();
        break;
      case 'ar2':
      case 'rifle':
      default:
        built = this.createRifle();
        break;
    }

    if (skin !== 'tactical') {
      let tintColor = 0xffffff;
      if (skin === 'urban') tintColor = 0x64748b;
      else if (skin === 'desert') tintColor = 0xd4a373;
      else if (skin === 'arctic') tintColor = 0xe0f2fe;
      else if (skin === 'outbreak') tintColor = 0x84cc16;
      else if (skin === 'blackout') tintColor = 0xca8a04;
      else if (skin === 'industrial') tintColor = 0xf97316;

      built.model.traverse(child => {
        if (child instanceof THREE.Mesh && child.name !== 'fps_arms') {
          if (child.material && child.material !== this.holoGlowMat && child.material !== this.redDotGlowMat) {
            const mat = (child.material as THREE.MeshStandardMaterial).clone();
            mat.color.setHex(tintColor);
            child.material = mat;
          }
        }
      });
    }

    return built;
  }
}
