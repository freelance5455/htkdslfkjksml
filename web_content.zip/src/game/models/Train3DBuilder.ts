import * as THREE from 'three';

export type TrainColorVariant = 'red' | 'yellow' | 'blue';

interface TrainColorPalette {
  primary: number;
  secondary: number;
  accent: number;
  darkTrim: number;
  windshieldTint: number;
  markerLight: number;
  name: string;
}

const TRAIN_PALETTES: Record<TrainColorVariant, TrainColorPalette> = {
  red: {
    name: 'Crimson Express',
    primary: 0xbe123c, // Deep Metallic Crimson Red
    secondary: 0xf8fafc, // Pearl White Aerodynamic Stripes
    accent: 0xe11d48, // Bright Crimson Highlight
    darkTrim: 0x1e293b, // Dark Charcoal Underbody & Skirts
    windshieldTint: 0x0f172a, // Deep Tinted Cockpit Glass
    markerLight: 0xf59e0b, // Amber Marker Lights
  },
  yellow: {
    name: 'Sunburst Metro',
    primary: 0xeab308, // Industrial Vibrant Signal Yellow
    secondary: 0x0f172a, // Hazard Black Transit Stripes
    accent: 0xfacc15, // Bright Sunburst Highlight
    darkTrim: 0x18181b, // Matte Anthracite Skirts & Bogies
    windshieldTint: 0x1e293b, // Dark Tinted Glass
    markerLight: 0xf97316, // Orange Safety Lights
  },
  blue: {
    name: 'Cobalt Coastline',
    primary: 0x0284c7, // Metallic Oceanic Cobalt Blue
    secondary: 0x38bdf8, // Electric Sky Cyan Racing Stripe
    accent: 0x0ea5e9, // High-Speed Cyan Trim
    darkTrim: 0x0f172a, // Deep Navy Underbody
    windshieldTint: 0x082f49, // Coastal Aquamarine Cockpit Tint
    markerLight: 0x38bdf8, // Ice Blue Projector Markers
  },
};

/**
 * High-Quality Real 3D Train Builder
 *
 * Replaces flat/simple box trains with fully-realized 3D commuter & bullet train locomotives.
 * Exactly adheres to railway track gauge:
 * - Lane Center: X = 0 (or -3.2 / +3.2 in world space)
 * - Steel Rails: X = -0.72 and X = +0.72
 * - Wheel Centers: X = -0.72 and X = +0.72 (flanged wheels sitting directly on the rails)
 * - Wheel Rail Contact: Y = 0.10 (rail top)
 * - Car Floor / Chassis: Y = 0.58
 * - Total Height: Y = 3.65 (Roof height)
 * - Length: 15.8 meters (Depth along Z)
 */
export class Train3DBuilder {
  private static sharedGeos: Map<string, THREE.BufferGeometry> = new Map();
  private static sharedMats: Map<string, THREE.Material> = new Map();

  private static getGeo(key: string, factory: () => THREE.BufferGeometry): THREE.BufferGeometry {
    if (!this.sharedGeos.has(key)) {
      this.sharedGeos.set(key, factory());
    }
    return this.sharedGeos.get(key)!;
  }

  private static getMat<T extends THREE.Material>(key: string, factory: () => T): T {
    if (!this.sharedMats.has(key)) {
      this.sharedMats.set(key, factory());
    }
    return this.sharedMats.get(key)! as T;
  }

  public static createTrain(variant: TrainColorVariant): THREE.Group {
    const palette = TRAIN_PALETTES[variant];
    const group = new THREE.Group();
    group.name = `train_${variant}`;

    // --- MATERIALS ---
    const bodyMat = this.getMat(`train_body_${variant}`, () => new THREE.MeshStandardMaterial({
      color: palette.primary,
      roughness: 0.32,
      metalness: 0.65,
    }));

    const stripeMat = this.getMat(`train_stripe_${variant}`, () => new THREE.MeshStandardMaterial({
      color: palette.secondary,
      roughness: 0.28,
      metalness: 0.5,
    }));

    const darkTrimMat = this.getMat('train_dark_trim', () => new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.65,
      metalness: 0.7,
    }));

    const roofMat = this.getMat('train_roof_metal', () => new THREE.MeshStandardMaterial({
      color: 0x64748b,
      roughness: 0.55,
      metalness: 0.5,
    }));

    const glassMat = this.getMat(`train_glass_${variant}`, () => new THREE.MeshStandardMaterial({
      color: palette.windshieldTint,
      roughness: 0.1,
      metalness: 0.9,
    }));

    const interiorGlowMat = this.getMat('train_interior_glow', () => new THREE.MeshBasicMaterial({
      color: 0xfef08a,
    }));

    const headlightGlowMat = this.getMat('train_headlight_glow', () => new THREE.MeshBasicMaterial({
      color: 0xfffbeb,
    }));

    const markerLightMat = this.getMat(`train_marker_${variant}`, () => new THREE.MeshBasicMaterial({
      color: palette.markerLight,
    }));

    const steelWheelMat = this.getMat('train_wheel_steel', () => new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.4,
      metalness: 0.85,
    }));

    const chromeMat = this.getMat('train_chrome', () => new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.15,
      metalness: 0.95,
    }));

    // --- 1. MAIN CAR BODY (Width: 2.44m, Height: 2.7m, Length: 15.6m) ---
    // Body sits above undercarriage: Y center at 2.05m
    const bodyGeo = this.getGeo('train_main_body', () => new THREE.BoxGeometry(2.44, 2.7, 15.4));
    const mainBody = new THREE.Mesh(bodyGeo, bodyMat);
    mainBody.position.set(0, 2.02, 0);
    mainBody.castShadow = true;
    mainBody.receiveShadow = true;
    group.add(mainBody);

    // Dynamic horizontal aerodynamic racing livery stripes along flanks
    const stripeSideGeo = this.getGeo('train_stripe_side', () => new THREE.BoxGeometry(2.48, 0.28, 15.4));
    const sideStripe = new THREE.Mesh(stripeSideGeo, stripeMat);
    sideStripe.position.set(0, 1.62, 0);
    group.add(sideStripe);

    const thinStripeGeo = this.getGeo('train_thin_stripe', () => new THREE.BoxGeometry(2.47, 0.08, 15.4));
    const thinStripe = new THREE.Mesh(thinStripeGeo, stripeMat);
    thinStripe.position.set(0, 2.85, 0);
    group.add(thinStripe);

    // --- 2. STREAMLINED FRONT CABIN (Facing +Z towards runner) ---
    // Aerodynamic wedge nose
    const noseGeo = this.getGeo('train_nose_wedge', () => {
      const geo = new THREE.CylinderGeometry(1.22, 1.22, 2.7, 16, 1, false, 0, Math.PI);
      geo.rotateZ(-Math.PI / 2);
      geo.rotateY(Math.PI / 2);
      geo.scale(1.0, 1.0, 0.65);
      return geo;
    });
    const noseWedge = new THREE.Mesh(noseGeo, bodyMat);
    noseWedge.position.set(0, 2.02, 7.7);
    noseWedge.castShadow = true;
    group.add(noseWedge);

    // Front windshield visor & raked cockpit glass
    const windshieldGeo = this.getGeo('train_windshield', () => new THREE.BoxGeometry(2.1, 0.95, 0.25));
    const windshield = new THREE.Mesh(windshieldGeo, glassMat);
    windshield.position.set(0, 2.45, 8.05);
    windshield.rotation.x = -0.15; // Slanted aerodynamic angle
    group.add(windshield);

    // Windshield frame & chrome wipers
    const wiperGeo = this.getGeo('train_wiper', () => new THREE.BoxGeometry(0.04, 0.6, 0.04));
    const wiperLeft = new THREE.Mesh(wiperGeo, chromeMat);
    wiperLeft.position.set(-0.45, 2.4, 8.16);
    wiperLeft.rotation.z = 0.25;
    group.add(wiperLeft);

    const wiperRight = new THREE.Mesh(wiperGeo, chromeMat);
    wiperRight.position.set(0.45, 2.4, 8.16);
    wiperRight.rotation.z = 0.25;
    group.add(wiperRight);

    // Front LED Route Display Board ("SPR TRANSIT")
    const routeSignGeo = this.getGeo('train_route_sign', () => new THREE.BoxGeometry(1.4, 0.22, 0.06));
    const routeSign = new THREE.Mesh(routeSignGeo, darkTrimMat);
    routeSign.position.set(0, 3.12, 8.0);
    group.add(routeSign);

    const routeTextGlowGeo = this.getGeo('train_route_text', () => new THREE.BoxGeometry(1.2, 0.12, 0.08));
    const routeText = new THREE.Mesh(routeTextGlowGeo, markerLightMat);
    routeText.position.set(0, 3.12, 8.01);
    group.add(routeText);

    // Heavy Cowcatcher / Front Impact Pilot Cowling
    const cowcatcherGeo = this.getGeo('train_cowcatcher', () => new THREE.BoxGeometry(2.35, 0.5, 0.6));
    const cowcatcher = new THREE.Mesh(cowcatcherGeo, darkTrimMat);
    cowcatcher.position.set(0, 0.72, 8.0);
    group.add(cowcatcher);

    // Heavy front central coupler hitch
    const couplerGeo = this.getGeo('train_coupler', () => new THREE.BoxGeometry(0.35, 0.25, 0.6));
    const coupler = new THREE.Mesh(couplerGeo, steelWheelMat);
    coupler.position.set(0, 0.55, 8.35);
    group.add(coupler);

    // Dual High-Beam Projector Headlights
    const headlightCasingGeo = this.getGeo('train_headlight_casing', () => new THREE.CylinderGeometry(0.24, 0.24, 0.15, 16));
    headlightCasingGeo.rotateX(Math.PI / 2);
    const headlightLensGeo = this.getGeo('train_headlight_lens', () => new THREE.CylinderGeometry(0.2, 0.2, 0.18, 16));
    headlightLensGeo.rotateX(Math.PI / 2);

    [-0.78, 0.78].forEach((hx) => {
      const casing = new THREE.Mesh(headlightCasingGeo, chromeMat);
      casing.position.set(hx, 1.25, 8.1);
      group.add(casing);

      const lens = new THREE.Mesh(headlightLensGeo, headlightGlowMat);
      lens.position.set(hx, 1.25, 8.12);
      group.add(lens);
    });

    // Dual Top Marker Lights
    const markerGeo = this.getGeo('train_marker_light', () => new THREE.BoxGeometry(0.12, 0.08, 0.1));
    [-0.85, 0.85].forEach((mx) => {
      const marker = new THREE.Mesh(markerGeo, markerLightMat);
      marker.position.set(mx, 3.25, 7.95);
      group.add(marker);
    });

    // --- 3. PASSENGER WINDOWS & DOORS WITH 3D DEPTH ---
    // Recessed tinted windows along left and right sides
    const windowGeo = this.getGeo('train_window_panel', () => new THREE.BoxGeometry(0.06, 0.72, 1.25));
    const windowFrameGeo = this.getGeo('train_window_frame', () => new THREE.BoxGeometry(0.07, 0.82, 1.35));
    const windowZPositions = [-5.6, -3.8, -2.0, 0.5, 2.3, 4.1, 5.9];

    windowZPositions.forEach((wz) => {
      [-1.21, 1.21].forEach((wx) => {
        // Frame
        const frame = new THREE.Mesh(windowFrameGeo, darkTrimMat);
        frame.position.set(wx, 2.22, wz);
        group.add(frame);

        // Tinted Glass
        const glass = new THREE.Mesh(windowGeo, glassMat);
        glass.position.set(wx * 1.01, 2.22, wz);
        group.add(glass);

        // Interior warm glow slice (visible from outside)
        const glow = new THREE.Mesh(windowGeo, interiorGlowMat);
        glow.scale.set(0.2, 0.8, 0.85);
        glow.position.set(wx * 0.96, 2.22, wz);
        group.add(glow);
      });
    });

    // Passenger Entry Doors with Yellow Safety Step
    const doorFrameGeo = this.getGeo('train_door_frame', () => new THREE.BoxGeometry(2.49, 1.9, 1.2));
    const doorStepGeo = this.getGeo('train_door_step', () => new THREE.BoxGeometry(2.54, 0.1, 1.2));
    const doorStepMat = this.getMat('train_door_step_mat', () => new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      roughness: 0.5,
    }));

    [-0.75, -6.8].forEach((dz) => {
      const doorCut = new THREE.Mesh(doorFrameGeo, darkTrimMat);
      doorCut.position.set(0, 1.62, dz);
      group.add(doorCut);

      const step = new THREE.Mesh(doorStepGeo, doorStepMat);
      step.position.set(0, 0.7, dz);
      group.add(step);
    });

    // --- 4. DETAILED 3D ROOF & HVAC PODS ---
    // Aerodynamic curved roof canopy
    const roofCurvedGeo = this.getGeo('train_roof_curved', () => {
      const geo = new THREE.CylinderGeometry(1.22, 1.22, 15.4, 16, 1, false, 0, Math.PI);
      geo.rotateZ(-Math.PI / 2);
      geo.scale(1.0, 0.38, 1.0);
      return geo;
    });
    const roof = new THREE.Mesh(roofCurvedGeo, roofMat);
    roof.position.set(0, 3.37, 0);
    roof.castShadow = true;
    roof.receiveShadow = true;
    group.add(roof);

    // Anti-slip roof running board / vaulting walkway (player can run on roof!)
    const roofWalkwayGeo = this.getGeo('train_roof_walkway', () => new THREE.BoxGeometry(1.4, 0.06, 15.0));
    const roofWalkway = new THREE.Mesh(roofWalkwayGeo, darkTrimMat);
    roofWalkway.position.set(0, 3.82, 0);
    roofWalkway.receiveShadow = true;
    group.add(roofWalkway);

    // Rooftop Climate Control / HVAC Pods with exhaust louvers
    const hvacGeo = this.getGeo('train_hvac_pod', () => new THREE.BoxGeometry(1.6, 0.32, 2.6));
    const hvacGrilleGeo = this.getGeo('train_hvac_grille', () => new THREE.BoxGeometry(1.3, 0.04, 0.8));

    [-3.5, 3.5].forEach((hz) => {
      const hvac = new THREE.Mesh(hvacGeo, darkTrimMat);
      hvac.position.set(0, 3.94, hz);
      hvac.castShadow = true;
      group.add(hvac);

      const grille = new THREE.Mesh(hvacGrilleGeo, chromeMat);
      grille.position.set(0, 4.11, hz);
      group.add(grille);
    });

    // Aerodynamic Antenna / Pantograph Frame
    const pantographGeo = this.getGeo('train_pantograph_base', () => new THREE.BoxGeometry(0.8, 0.15, 1.2));
    const panto = new THREE.Mesh(pantographGeo, chromeMat);
    panto.position.set(0, 3.9, -1.0);
    group.add(panto);

    // --- 5. UNDERCARRIAGE, STEEL BOGIES & FLANGED WHEELS ON TRACK RAILS ---
    // Central underbelly battery / air compressor boxes
    const underbellyBoxGeo = this.getGeo('train_underbelly_box', () => new THREE.BoxGeometry(1.9, 0.45, 4.5));
    const underbelly = new THREE.Mesh(underbellyBoxGeo, darkTrimMat);
    underbelly.position.set(0, 0.45, 0);
    underbelly.castShadow = true;
    group.add(underbelly);

    // Dual cylindrical air reservoirs
    const airTankGeo = this.getGeo('train_air_tank', () => {
      const geo = new THREE.CylinderGeometry(0.18, 0.18, 2.4, 12);
      geo.rotateX(Math.PI / 2);
      return geo;
    });
    [-0.65, 0.65].forEach((tx) => {
      const tank = new THREE.Mesh(airTankGeo, chromeMat);
      tank.position.set(tx, 0.42, 0);
      group.add(tank);
    });

    // Two 2-Axle Heavy Steel Bogie Trucks (Front at Z = 5.0, Rear at Z = -5.0)
    const bogieFrameGeo = this.getGeo('train_bogie_frame', () => new THREE.BoxGeometry(1.7, 0.22, 2.6));
    const axleRodGeo = this.getGeo('train_axle_rod', () => {
      const geo = new THREE.CylinderGeometry(0.06, 0.06, 1.5, 8);
      geo.rotateZ(Math.PI / 2);
      return geo;
    });

    // Flanged Solid Steel Train Wheel (Radius: 0.32m, sits on rail top at y = 0.10)
    // Wheel center is at Y = 0.42!
    // Exact rail track positions: X = -0.72 and X = +0.72!
    const wheelTreadGeo = this.getGeo('train_wheel_tread', () => {
      const geo = new THREE.CylinderGeometry(0.32, 0.32, 0.16, 16);
      geo.rotateZ(Math.PI / 2);
      return geo;
    });
    const wheelFlangeGeo = this.getGeo('train_wheel_flange', () => {
      const geo = new THREE.CylinderGeometry(0.36, 0.36, 0.04, 16);
      geo.rotateZ(Math.PI / 2);
      return geo;
    });

    const bogieZCenters = [5.0, -5.0];
    bogieZCenters.forEach((bz) => {
      // Bogie bolster & side frames
      const bogie = new THREE.Mesh(bogieFrameGeo, darkTrimMat);
      bogie.position.set(0, 0.52, bz);
      bogie.castShadow = true;
      group.add(bogie);

      // Two axles per bogie truck (-0.9m and +0.9m from bogie center)
      [-0.9, 0.9].forEach((axleOffset) => {
        const az = bz + axleOffset;

        // Axle connecting left and right wheels
        const axle = new THREE.Mesh(axleRodGeo, steelWheelMat);
        axle.position.set(0, 0.42, az);
        group.add(axle);

        // Left Wheel on Left Rail (X = -0.72)
        const leftWheel = new THREE.Mesh(wheelTreadGeo, steelWheelMat);
        leftWheel.position.set(-0.72, 0.42, az);
        group.add(leftWheel);

        const leftFlange = new THREE.Mesh(wheelFlangeGeo, steelWheelMat);
        leftFlange.position.set(-0.79, 0.42, az); // Flange sits inside rail
        group.add(leftFlange);

        // Right Wheel on Right Rail (X = +0.72)
        const rightWheel = new THREE.Mesh(wheelTreadGeo, steelWheelMat);
        rightWheel.position.set(0.72, 0.42, az);
        group.add(rightWheel);

        const rightFlange = new THREE.Mesh(wheelFlangeGeo, steelWheelMat);
        rightFlange.position.set(0.79, 0.42, az); // Flange sits inside rail
        group.add(rightFlange);
      });
    });

    return group;
  }
}
