import * as THREE from 'three';

export interface CharacterDef {
  id: string;
  name: string;
  role: string;
  perk: string;
  perkDesc: string;
  color: string;
  stats: {
    speed: number;
    health: number;
    handling: number;
    armor: number;
  };
}

export const CHARACTERS: CharacterDef[] = [
  {
    id: 'specter',
    name: 'SPECTER',
    role: 'Black-Ops Infiltrator',
    perk: 'Adrenaline Surge',
    perkDesc: '+15% Sprint Speed & quieter movement',
    color: '#06b6d4',
    stats: { speed: 95, health: 80, handling: 90, armor: 70 },
  },
  {
    id: 'vanguard',
    name: 'VANGUARD',
    role: 'Heavy Assault Juggernaut',
    perk: 'Blast Plating',
    perkDesc: '+50 Max Armor and 25% explosive resistance',
    color: '#f97316',
    stats: { speed: 70, health: 100, handling: 75, armor: 100 },
  },
  {
    id: 'ghost',
    name: 'GHOST',
    role: 'Spec-Ops Marksman',
    perk: 'Sleight of Hand',
    perkDesc: '+25% Faster Reload & instant ADS transition',
    color: '#a855f7',
    stats: { speed: 85, health: 85, handling: 100, armor: 75 },
  },
  {
    id: 'phoenix',
    name: 'PHOENIX',
    role: 'Combat Field Medic',
    perk: 'Bio-Regen',
    perkDesc: 'Rapid passive health regeneration and survival stim',
    color: '#ef4444',
    stats: { speed: 85, health: 90, handling: 85, armor: 85 },
  },
];

export class CharacterModels {
  static createCharacterMesh(charId: string): THREE.Group {
    const group = new THREE.Group();

    let primaryColor = 0x1e293b;
    let vestColor = 0x0f172a;
    let accentColor = 0x06b6d4;

    if (charId === 'vanguard') {
      primaryColor = 0x3f4f35; // Olive camo
      vestColor = 0x1f2937;
      accentColor = 0xf97316; // Orange blast plates
    } else if (charId === 'ghost') {
      primaryColor = 0x27272a; // Urban stealth grey
      vestColor = 0x18181b;
      accentColor = 0xa855f7; // Purple spec-ops
    } else if (charId === 'phoenix') {
      primaryColor = 0x334155;
      vestColor = 0x475569;
      accentColor = 0xef4444; // Medic red
    }

    const suitMat = new THREE.MeshStandardMaterial({ color: primaryColor, roughness: 0.75 });
    const vestMat = new THREE.MeshStandardMaterial({ color: vestColor, roughness: 0.5, metalness: 0.2 });
    const accentMat = new THREE.MeshStandardMaterial({ color: accentColor, roughness: 0.4 });
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xdfb194, roughness: 0.6 });

    // Torso (tactical shirt)
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.65, 0.28), suitMat);
    torso.position.y = 1.15;
    torso.castShadow = true;
    group.add(torso);

    // Ballistic Vest
    const vest = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.45, 0.32), vestMat);
    vest.position.set(0, 1.2, 0.01);
    vest.castShadow = true;
    group.add(vest);

    // Tactical Accent / Badge
    const badge = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.12, 0.04), accentMat);
    badge.position.set(0.12, 1.25, 0.17);
    group.add(badge);

    // Head
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.3, 0.28), skinMat);
    head.position.set(0, 1.65, 0);
    head.castShadow = true;
    group.add(head);

    // Tactical Helmet / Cap
    const helmet = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.16, 0.32), vestMat);
    helmet.position.set(0, 1.8, 0);
    group.add(helmet);

    // NVG / Goggles
    const goggles = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.06, 0.1), accentMat);
    goggles.position.set(0, 1.7, 0.16);
    group.add(goggles);

    // Arms
    const armGeo = new THREE.BoxGeometry(0.14, 0.65, 0.14);
    const leftArm = new THREE.Mesh(armGeo, suitMat);
    leftArm.position.set(-0.35, 1.15, 0);
    leftArm.castShadow = true;
    group.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, suitMat);
    rightArm.position.set(0.35, 1.15, 0);
    rightArm.castShadow = true;
    group.add(rightArm);

    // Legs
    const legGeo = new THREE.BoxGeometry(0.18, 0.85, 0.18);
    const leftLeg = new THREE.Mesh(legGeo, suitMat);
    leftLeg.position.set(-0.16, 0.42, 0);
    leftLeg.castShadow = true;
    group.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, suitMat);
    rightLeg.position.set(0.16, 0.42, 0);
    rightLeg.castShadow = true;
    group.add(rightLeg);

    return group;
  }
}
