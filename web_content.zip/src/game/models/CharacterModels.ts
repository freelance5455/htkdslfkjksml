import * as THREE from 'three';
import { PlayerAppearance, WeaponCategory } from '../types/gameTypes';

export interface HumanoidRig {
  group: THREE.Group;
  body: THREE.Group;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  weaponAnchor: THREE.Group;
  shieldAnchor: THREE.Group;
}

export function buildWeaponMesh(category: WeaponCategory, colorHex: string): THREE.Group {
  const g = new THREE.Group();
  const metal = new THREE.MeshStandardMaterial({
    color: colorHex,
    metalness: 0.78,
    roughness: 0.22,
  });
  const handleMat = new THREE.MeshStandardMaterial({
    color: '#5c3317',
    metalness: 0.1,
    roughness: 0.85,
  });
  const goldMat = new THREE.MeshStandardMaterial({
    color: '#eab308',
    metalness: 0.85,
    roughness: 0.25,
  });

  if (category === 'Sword' || category === 'Greatsword') {
    const scaleLen = category === 'Greatsword' ? 1.45 : 1.0;
    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, 0.26, 8), handleMat);
    grip.position.y = 0.1;
    g.add(grip);

    const guard = new THREE.Mesh(new THREE.BoxGeometry(0.28 * scaleLen, 0.045, 0.07), goldMat);
    guard.position.y = 0.24;
    g.add(guard);

    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.08 * scaleLen, 0.85 * scaleLen, 0.025), metal);
    blade.position.y = 0.24 + 0.42 * scaleLen;
    blade.castShadow = true;
    g.add(blade);

    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.055 * scaleLen, 0.18, 4), metal);
    tip.rotation.y = Math.PI / 4;
    tip.position.y = 0.24 + 0.85 * scaleLen + 0.08;
    g.add(tip);
  } else if (category === 'Dagger') {
    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.18, 8), handleMat);
    grip.position.y = 0.08;
    g.add(grip);
    const guard = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.03, 0.05), goldMat);
    guard.position.y = 0.18;
    g.add(guard);
    const blade = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.48, 4), metal);
    blade.position.y = 0.42;
    g.add(blade);
  } else if (category === 'Axe') {
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.042, 1.05, 8), handleMat);
    shaft.position.y = 0.45;
    g.add(shaft);
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.24, 0.08), metal);
    head.position.set(0.12, 0.85, 0);
    g.add(head);
    const edge = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.04, 8, 1, false, 0, Math.PI), metal);
    edge.rotation.x = Math.PI / 2;
    edge.position.set(0.24, 0.85, 0);
    g.add(edge);
  } else if (category === 'Bow') {
    const stave = new THREE.Mesh(
      new THREE.TorusGeometry(0.55, 0.03, 8, 18, Math.PI * 1.15),
      handleMat
    );
    stave.rotation.z = -Math.PI * 0.58;
    stave.position.set(0, 0.3, 0.15);
    g.add(stave);
    const string = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 1.05, 4), metal);
    string.position.set(0, 0.3, -0.05);
    g.add(string);
  } else if (category === 'Staff') {
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.042, 1.55, 8), handleMat);
    pole.position.y = 0.65;
    g.add(pole);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.02, 8, 16), goldMat);
    ring.position.y = 1.48;
    g.add(ring);
    const orb = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.1, 0),
      new THREE.MeshStandardMaterial({
        color: colorHex,
        emissive: colorHex,
        emissiveIntensity: 0.9,
        roughness: 0.15,
      })
    );
    orb.position.y = 1.48;
    g.add(orb);
  } else if (category === 'Shield') {
    const face = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.3, 0.06, 12), metal);
    face.rotation.x = Math.PI / 2;
    g.add(face);
    const boss = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 8), goldMat);
    boss.position.z = 0.05;
    g.add(boss);
  }

  return g;
}

export function buildHumanoidRig(
  appearance: PlayerAppearance,
  weaponCategory: WeaponCategory = 'Sword',
  weaponColor = '#cbd5e1',
  hasShield = false
): HumanoidRig {
  const group = new THREE.Group();
  const body = new THREE.Group();
  group.add(body);

  const skinMat = new THREE.MeshStandardMaterial({ color: appearance.skinColor, roughness: 0.65 });
  const tunicMat = new THREE.MeshStandardMaterial({ color: appearance.tunicColor, roughness: 0.78 });
  const armorMat = new THREE.MeshStandardMaterial({ color: appearance.armorColor, metalness: 0.65, roughness: 0.32 });
  const hairMat = new THREE.MeshStandardMaterial({ color: appearance.hairColor, roughness: 0.7 });
  const bootMat = new THREE.MeshStandardMaterial({ color: '#3b2313', roughness: 0.85 });

  // Legs (pivot at hip y = 0.85)
  const makeLeg = (x: number) => {
    const legPivot = new THREE.Group();
    legPivot.position.set(x, 0.85, 0);
    const thigh = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.095, 0.45, 8), tunicMat);
    thigh.position.y = -0.22;
    thigh.castShadow = true;
    legPivot.add(thigh);
    const boot = new THREE.Mesh(new THREE.CylinderGeometry(0.095, 0.11, 0.42, 8), bootMat);
    boot.position.y = -0.63;
    boot.castShadow = true;
    legPivot.add(boot);
    body.add(legPivot);
    return legPivot;
  };
  const leftLeg = makeLeg(-0.14);
  const rightLeg = makeLeg(0.14);

  // Torso
  const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.2, 0.72, 10), tunicMat);
  torso.position.y = 1.22;
  torso.castShadow = true;
  body.add(torso);

  const chestplate = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.44, 0.32), armorMat);
  chestplate.position.y = 1.32;
  chestplate.castShadow = true;
  body.add(chestplate);

  const belt = new THREE.Mesh(
    new THREE.CylinderGeometry(0.22, 0.22, 0.1, 10),
    new THREE.MeshStandardMaterial({ color: '#78350f', roughness: 0.8 })
  );
  belt.position.y = 0.96;
  body.add(belt);

  // Accessories
  if (appearance.accessory === 'cape') {
    const cape = new THREE.Mesh(
      new THREE.BoxGeometry(0.46, 0.92, 0.05),
      new THREE.MeshStandardMaterial({ color: '#991b1b', roughness: 0.85 })
    );
    cape.position.set(0, 1.08, -0.21);
    cape.rotation.x = 0.12;
    body.add(cape);
  } else if (appearance.accessory === 'quiver') {
    const quiver = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.05, 0.55, 8), bootMat);
    quiver.position.set(0.14, 1.28, -0.22);
    quiver.rotation.z = -0.35;
    body.add(quiver);
  } else if (appearance.accessory === 'wings_charm') {
    const wingMat = new THREE.MeshStandardMaterial({
      color: '#fde047',
      emissive: '#f59e0b',
      emissiveIntensity: 0.35,
      metalness: 0.6,
      roughness: 0.25,
    });
    for (const s of [-1, 1]) {
      const w = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.22, 0.04), wingMat);
      w.position.set(s * 0.28, 1.42, -0.2);
      w.rotation.z = s * 0.35;
      body.add(w);
    }
  }

  // Head
  const head = new THREE.Group();
  head.position.set(0, 1.66, 0);
  body.add(head);

  const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.21, 14, 12), skinMat);
  cranium.position.y = 0.16;
  cranium.castShadow = true;
  head.add(cranium);

  // Eyes
  const eyeMat = new THREE.MeshStandardMaterial({
    color: appearance.faceStyle === 'mystic' ? '#38bdf8' : '#0f172a',
    emissive: appearance.faceStyle === 'mystic' ? '#38bdf8' : '#000000',
    emissiveIntensity: appearance.faceStyle === 'mystic' ? 0.7 : 0,
  });
  for (const s of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 6), eyeMat);
    eye.position.set(s * 0.075, 0.17, 0.185);
    head.add(eye);
  }

  // Hair styles
  if (appearance.hairStyle === 'short') {
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.58), hairMat);
    hair.position.y = 0.18;
    head.add(hair);
  } else if (appearance.hairStyle === 'long') {
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.225, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.6), hairMat);
    hair.position.y = 0.18;
    head.add(hair);
    const backHair = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.42, 0.16), hairMat);
    backHair.position.set(0, 0.02, -0.15);
    head.add(backHair);
  } else if (appearance.hairStyle === 'ponytail') {
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.58), hairMat);
    hair.position.y = 0.18;
    head.add(hair);
    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.38, 8), hairMat);
    tail.position.set(0, 0.1, -0.25);
    tail.rotation.x = -0.5;
    head.add(tail);
  } else if (appearance.hairStyle === 'hooded') {
    const hood = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.42, 10), tunicMat);
    hood.position.set(0, 0.25, -0.02);
    head.add(hood);
  } else if (appearance.hairStyle === 'crown') {
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), hairMat);
    hair.position.y = 0.18;
    head.add(hair);
    const crown = new THREE.Mesh(
      new THREE.CylinderGeometry(0.18, 0.16, 0.1, 8),
      new THREE.MeshStandardMaterial({ color: '#eab308', metalness: 0.9, roughness: 0.2 })
    );
    crown.position.y = 0.34;
    head.add(crown);
  }

  // Arms
  const makeArm = (x: number) => {
    const armPivot = new THREE.Group();
    armPivot.position.set(x, 1.5, 0);
    const pauldron = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 8), armorMat);
    armPivot.add(pauldron);
    const sleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.075, 0.55, 8), tunicMat);
    sleeve.position.y = -0.28;
    sleeve.castShadow = true;
    armPivot.add(sleeve);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), skinMat);
    hand.position.y = -0.56;
    armPivot.add(hand);
    body.add(armPivot);
    return armPivot;
  };
  const leftArm = makeArm(-0.32);
  const rightArm = makeArm(0.32);

  const weaponAnchor = new THREE.Group();
  weaponAnchor.position.set(0, -0.56, 0.06);
  weaponAnchor.rotation.x = Math.PI / 2.2;
  weaponAnchor.add(buildWeaponMesh(weaponCategory, weaponColor));
  rightArm.add(weaponAnchor);

  const shieldAnchor = new THREE.Group();
  shieldAnchor.position.set(-0.08, -0.45, 0.1);
  shieldAnchor.rotation.y = -Math.PI / 2;
  if (hasShield) {
    shieldAnchor.add(buildWeaponMesh('Shield', '#64748b'));
  }
  leftArm.add(shieldAnchor);

  return { group, body, head, leftArm, rightArm, leftLeg, rightLeg, weaponAnchor, shieldAnchor };
}

export function animateHumanoid(
  rig: HumanoidRig,
  time: number,
  speedRatio: number,
  isAttacking: boolean,
  attackProgress: number,
  isSwimming: boolean,
  isMounted: boolean
) {
  if (isMounted) {
    rig.leftLeg.rotation.x = -0.55;
    rig.leftLeg.rotation.z = 0.35;
    rig.rightLeg.rotation.x = -0.55;
    rig.rightLeg.rotation.z = -0.35;
    rig.body.position.y = 0.68;
  } else {
    rig.leftLeg.rotation.z = 0;
    rig.rightLeg.rotation.z = 0;
    const stride = Math.sin(time * 10) * 0.65 * speedRatio;
    rig.leftLeg.rotation.x = isSwimming ? Math.sin(time * 8) * 0.45 : stride;
    rig.rightLeg.rotation.x = isSwimming ? -Math.sin(time * 8) * 0.45 : -stride;
    rig.body.position.y = isSwimming ? -0.35 : Math.abs(Math.sin(time * 10)) * 0.05 * speedRatio;
  }

  rig.leftArm.rotation.x = isSwimming
    ? -1.2 + Math.sin(time * 7) * 0.5
    : -Math.sin(time * 10) * 0.55 * speedRatio;

  if (isAttacking) {
    const swing = Math.sin(attackProgress * Math.PI) * 1.9;
    rig.rightArm.rotation.x = -0.4 - swing;
    rig.rightArm.rotation.z = -0.25 * Math.sin(attackProgress * Math.PI);
  } else {
    rig.rightArm.rotation.x = isSwimming
      ? -1.2 - Math.sin(time * 7) * 0.5
      : Math.sin(time * 10) * 0.55 * speedRatio;
    rig.rightArm.rotation.z = 0;
  }
}
