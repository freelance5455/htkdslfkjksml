import * as THREE from 'three';

/**
 * High-Performance Pooled Particle System for the 30–40s Fire Rock Air Sequence
 *
 * Creates a powerful, billowing fire, smoke, and spark jet propulsion trail
 * behind the airborne player. Optimized with zero runtime garbage collection.
 */
export class AirborneFlightParticles {
  private scene: THREE.Scene;
  private group: THREE.Group;

  // Particle Pools
  private fireParticles: THREE.Mesh[] = [];
  private smokeParticles: THREE.Mesh[] = [];
  private sparkParticles: THREE.Mesh[] = [];
  private shockRings: THREE.Mesh[] = [];

  private fireMat: THREE.MeshBasicMaterial;
  private smokeMat: THREE.MeshBasicMaterial;
  private sparkMat: THREE.MeshBasicMaterial;
  private ringMat: THREE.MeshBasicMaterial;

  private elapsed: number = 0;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.group = new THREE.Group();
    this.group.name = 'airborne_flight_trail';
    this.group.visible = false;
    this.scene.add(this.group);

    // Shared Materials
    this.fireMat = new THREE.MeshBasicMaterial({
      color: 0xf97316,
      transparent: true,
      opacity: 0.85,
    });

    this.smokeMat = new THREE.MeshBasicMaterial({
      color: 0x64748b,
      transparent: true,
      opacity: 0.35,
    });

    this.sparkMat = new THREE.MeshBasicMaterial({
      color: 0xfef08a,
    });

    this.ringMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.6,
      side: THREE.DoubleSide,
    });

    this.initPools();
  }

  private initPools() {
    // 1. Fire cones / spheres (12 elements)
    const fireGeo = new THREE.DodecahedronGeometry(0.35, 1);
    for (let i = 0; i < 14; i++) {
      const p = new THREE.Mesh(fireGeo, this.fireMat);
      p.visible = false;
      this.fireParticles.push(p);
      this.group.add(p);
    }

    // 2. Smoke puffs (18 elements)
    const smokeGeo = new THREE.DodecahedronGeometry(0.55, 0);
    for (let i = 0; i < 18; i++) {
      const s = new THREE.Mesh(smokeGeo, this.smokeMat);
      s.visible = false;
      this.smokeParticles.push(s);
      this.group.add(s);
    }

    // 3. Electric sparks (16 elements)
    const sparkGeo = new THREE.BoxGeometry(0.1, 0.1, 0.1);
    for (let i = 0; i < 16; i++) {
      const sp = new THREE.Mesh(sparkGeo, this.sparkMat);
      sp.visible = false;
      this.sparkParticles.push(sp);
      this.group.add(sp);
    }

    // 4. Supersonic energy rings (4 elements)
    const ringGeo = new THREE.RingGeometry(0.4, 0.7, 16);
    for (let i = 0; i < 4; i++) {
      const r = new THREE.Mesh(ringGeo, this.ringMat);
      r.visible = false;
      this.shockRings.push(r);
      this.group.add(r);
    }
  }

  public setActive(active: boolean) {
    this.group.visible = active;
    if (!active) {
      this.fireParticles.forEach((p) => (p.visible = false));
      this.smokeParticles.forEach((p) => (p.visible = false));
      this.sparkParticles.forEach((p) => (p.visible = false));
      this.shockRings.forEach((p) => (p.visible = false));
    }
  }

  public update(delta: number, playerPos: THREE.Vector3, speed: number) {
    if (!this.group.visible) return;

    this.elapsed += delta;

    // Anchor group close to player base / thruster position
    const originX = playerPos.x;
    const originY = playerPos.y + 0.3; // Below player feet / board
    const originZ = playerPos.z + 0.6; // Slightly behind player

    // Update Fire Billowing Stream
    const fireCount = this.fireParticles.length;
    for (let i = 0; i < fireCount; i++) {
      const p = this.fireParticles[i];
      p.visible = true;
      const phase = (this.elapsed * 12 + i * 0.4) % fireCount;
      const progress = phase / fireCount; // 0 to 1

      // Trails behind along +Z
      p.position.set(
        originX + Math.sin(this.elapsed * 18 + i) * 0.25,
        originY - progress * 0.6 + Math.cos(this.elapsed * 14 + i) * 0.15,
        originZ + progress * 4.5
      );

      const s = (1 - progress * 0.7) * (0.8 + Math.random() * 0.35);
      p.scale.set(s, s, s * 1.5);
    }

    // Update Expanding Smoke Cloud Trail
    const smokeCount = this.smokeParticles.length;
    for (let j = 0; j < smokeCount; j++) {
      const s = this.smokeParticles[j];
      s.visible = true;
      const phase = (this.elapsed * 8 + j * 0.55) % smokeCount;
      const progress = phase / smokeCount;

      s.position.set(
        originX + Math.sin(j * 1.5 + this.elapsed * 4) * (0.4 + progress * 1.2),
        originY + progress * 0.8 + Math.cos(j * 2.1) * 0.3,
        originZ + 1.2 + progress * 9.0
      );

      const scale = 0.5 + progress * 2.2;
      s.scale.set(scale, scale, scale);
    }

    // Update Sparks
    const sparkCount = this.sparkParticles.length;
    for (let k = 0; k < sparkCount; k++) {
      const sp = this.sparkParticles[k];
      sp.visible = true;
      const progress = ((this.elapsed * 18 + k * 0.7) % sparkCount) / sparkCount;

      sp.position.set(
        originX + (Math.sin(k * 3.3 + this.elapsed * 10) - 0.5) * (0.6 + progress * 1.6),
        originY + (Math.cos(k * 4.1 + this.elapsed * 8) - 0.5) * (0.6 + progress * 1.2),
        originZ + progress * 6.0
      );
      sp.rotation.x += delta * 15;
      sp.rotation.y += delta * 20;
    }

    // Update Shock Rings
    const ringCount = this.shockRings.length;
    for (let r = 0; r < ringCount; r++) {
      const ring = this.shockRings[r];
      ring.visible = true;
      const progress = ((this.elapsed * 4 + r) % ringCount) / ringCount;

      ring.position.set(originX, originY, originZ + progress * 7.5);
      const ringScale = 0.8 + progress * 3.2;
      ring.scale.set(ringScale, ringScale, 1);
    }
  }

  public dispose() {
    this.setActive(false);
    this.fireMat.dispose();
    this.smokeMat.dispose();
    this.sparkMat.dispose();
    this.ringMat.dispose();

    while (this.group.children.length > 0) {
      const child = this.group.children[0] as THREE.Mesh;
      if (child.geometry) child.geometry.dispose();
      this.group.remove(child);
    }
    this.scene.remove(this.group);
  }
}
