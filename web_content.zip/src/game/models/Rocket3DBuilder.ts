/**
 * SPR - Sahil Powerful Run
 * Master 3D Rocket Power-up Builder & Dual Flame Engine
 *
 * Fully modeled physical Three.js 3D Rocket:
 * - Aerodynamic tapered rocket fuselage / body
 * - Pointed nosecone with red/white telemetry tip
 * - Sleek swept side stabilizing fins (quad fins)
 * - Metallic panel seams & rivets
 * - Rear engine mounting ring
 * - TWO distinct physical rear rocket nozzles
 * - Dual glowing engine cores
 * - Powerful procedural multi-layered flame meshes (inner hot white core, mid orange/yellow, outer flame)
 * - Real-time animated exhaust plume with dedicated point lights
 */

import * as THREE from 'three';

export class Rocket3DBuilder {
  private static bodyMat: THREE.MeshStandardMaterial | null = null;
  private static noseMat: THREE.MeshStandardMaterial | null = null;
  private static stripeMat: THREE.MeshStandardMaterial | null = null;
  private static finMat: THREE.MeshStandardMaterial | null = null;
  private static nozzleMat: THREE.MeshStandardMaterial | null = null;
  private static nozzleInteriorMat: THREE.MeshStandardMaterial | null = null;
  private static flameCoreMat: THREE.MeshBasicMaterial | null = null;
  private static flameMidMat: THREE.MeshBasicMaterial | null = null;
  private static flameOuterMat: THREE.MeshBasicMaterial | null = null;
  private static sparkMat: THREE.MeshBasicMaterial | null = null;
  private static podMat: THREE.MeshBasicMaterial | null = null;

  public static initMaterials() {
    if (!this.bodyMat) {
      // Titanium / White Aerodynamic Metallic Fuselage
      this.bodyMat = new THREE.MeshStandardMaterial({
        color: 0xf1f5f9,
        metalness: 0.85,
        roughness: 0.22,
      });

      // Rocket Scarlet Nosecone
      this.noseMat = new THREE.MeshStandardMaterial({
        color: 0xef4444,
        emissive: 0x991b1b,
        emissiveIntensity: 0.35,
        metalness: 0.7,
        roughness: 0.25,
      });

      // Racing Cyan / Gold Racing Stripe
      this.stripeMat = new THREE.MeshStandardMaterial({
        color: 0x06b6d4,
        emissive: 0x0891b2,
        emissiveIntensity: 0.4,
        metalness: 0.6,
        roughness: 0.2,
      });

      // Carbon-fiber Composite Swept Fins
      this.finMat = new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        emissive: 0x0f172a,
        emissiveIntensity: 0.2,
        metalness: 0.9,
        roughness: 0.2,
      });

      // Heavy Heat-resistant Inconel Rocket Nozzles
      this.nozzleMat = new THREE.MeshStandardMaterial({
        color: 0x334155,
        metalness: 0.92,
        roughness: 0.18,
      });

      // Incandescent Nozzle Throat
      this.nozzleInteriorMat = new THREE.MeshStandardMaterial({
        color: 0xf59e0b,
        emissive: 0xf97316,
        emissiveIntensity: 1.0,
        roughness: 0.3,
        metalness: 0.5,
      });

      // Multi-layer procedural flames:
      this.flameCoreMat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.95,
      });

      this.flameMidMat = new THREE.MeshBasicMaterial({
        color: 0xfde047, // Intense Yellow
        transparent: true,
        opacity: 0.9,
      });

      this.flameOuterMat = new THREE.MeshBasicMaterial({
        color: 0xf97316, // Roaring Orange
        transparent: true,
        opacity: 0.75,
      });

      this.sparkMat = new THREE.MeshBasicMaterial({
        color: 0xfacc15,
      });

      // Pulsing holographic beacon diamond
      this.podMat = new THREE.MeshBasicMaterial({
        color: 0x38bdf8,
        wireframe: true,
        transparent: true,
        opacity: 0.3,
      });
    }
  }

  /**
   * Creates a standalone premium 3D Rocket Power-up (for the railway track)
   * Includes holographic hover ring, rotating beacon, dual engine nozzles, and subtle idle glow
   */
  public static createTrackRocketPowerUp(): THREE.Group {
    this.initMaterials();

    const group = new THREE.Group();
    group.name = 'track_rocket_powerup';

    // Outer rotating beacon crystal
    const podGeo = new THREE.OctahedronGeometry(1.2, 0);
    const pod = new THREE.Mesh(podGeo, this.podMat!);
    pod.name = 'rocket_beacon_pod';
    group.add(pod);

    // Glowing ground projection disk
    const ringGeo = new THREE.RingGeometry(0.5, 0.9, 24);
    ringGeo.rotateX(-Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.45,
      side: THREE.DoubleSide,
    });
    const groundRing = new THREE.Mesh(ringGeo, ringMat);
    groundRing.position.set(0, -0.65, 0);
    group.add(groundRing);

    // Physical 3D Rocket Model tilted slightly forward for dynamic presentation
    const rocketMesh = this.buildFull3DRocketMesh({ isItemPickup: true });
    rocketMesh.name = 'rocket_core_mesh';
    rocketMesh.position.set(0, 0, 0);
    rocketMesh.scale.set(0.9, 0.9, 0.9);
    rocketMesh.rotation.x = -Math.PI / 6; // Angled launch posture
    group.add(rocketMesh);

    return group;
  }

  /**
   * Builds the comprehensive physical 3D Rocket model with fuselage, nosecone, fins, and TWO rear engine nozzles
   */
  public static buildFull3DRocketMesh(options: { isItemPickup?: boolean } = {}): THREE.Group {
    this.initMaterials();

    const rocket = new THREE.Group();
    rocket.name = 'physical_3d_rocket';

    // 1. MAIN CYLINDRICAL AERODYNAMIC FUSELAGE
    // Top radius 0.22, Bottom radius 0.26, Length 1.05
    const bodyGeo = new THREE.CylinderGeometry(0.22, 0.26, 1.05, 16);
    const bodyMesh = new THREE.Mesh(bodyGeo, this.bodyMat!);
    bodyMesh.castShadow = true;
    bodyMesh.receiveShadow = true;
    rocket.add(bodyMesh);

    // 2. RACING ACCENT STRIPE RINGS
    const stripeGeo = new THREE.CylinderGeometry(0.245, 0.252, 0.16, 16);
    const stripeMesh = new THREE.Mesh(stripeGeo, this.stripeMat!);
    stripeMesh.position.set(0, 0.12, 0);
    rocket.add(stripeMesh);

    const stripe2Geo = new THREE.CylinderGeometry(0.23, 0.235, 0.08, 16);
    const stripe2Mesh = new THREE.Mesh(stripe2Geo, this.noseMat!);
    stripe2Mesh.position.set(0, -0.22, 0);
    rocket.add(stripe2Mesh);

    // 3. SHARP POINTED NOSECONE
    const noseGeo = new THREE.ConeGeometry(0.22, 0.55, 16);
    const noseMesh = new THREE.Mesh(noseGeo, this.noseMat!);
    noseMesh.position.set(0, 0.8, 0);
    noseMesh.castShadow = true;
    rocket.add(noseMesh);

    // Telemetry Sensor Needle
    const needleGeo = new THREE.CylinderGeometry(0.02, 0.03, 0.22, 8);
    const needleMat = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.95 });
    const needleMesh = new THREE.Mesh(needleGeo, needleMat);
    needleMesh.position.set(0, 1.15, 0);
    rocket.add(needleMesh);

    // 4. FOUR SWEPT AERODYNAMIC STABILIZING FINS
    const finShape = new THREE.Shape();
    finShape.moveTo(0, 0);
    finShape.lineTo(0.35, -0.32);
    finShape.lineTo(0.32, -0.48);
    finShape.lineTo(0, -0.42);
    finShape.closePath();

    const extrudeSettings = { depth: 0.03, bevelEnabled: true, bevelSegments: 2, steps: 1, bevelSize: 0.01, bevelThickness: 0.01 };
    const finGeo = new THREE.ExtrudeGeometry(finShape, extrudeSettings);
    finGeo.center();

    for (let i = 0; i < 4; i++) {
      const fin = new THREE.Mesh(finGeo, this.finMat!);
      fin.position.set(0, -0.26, 0);
      fin.rotation.y = (i * Math.PI) / 2;
      fin.translateOnAxis(new THREE.Vector3(1, 0, 0), 0.22);
      fin.castShadow = true;
      rocket.add(fin);
    }

    // 5. REAR ENGINE MOUNT DECK
    const mountDeckGeo = new THREE.CylinderGeometry(0.26, 0.28, 0.12, 16);
    const mountDeck = new THREE.Mesh(mountDeckGeo, this.nozzleMat!);
    mountDeck.position.set(0, -0.58, 0);
    rocket.add(mountDeck);

    // 6. TWO DISTINCT REAR ROCKET ENGINE NOZZLES
    // Left engine nozzle (X = -0.12) & Right engine nozzle (X = +0.12)
    const nozzleLeft = this.createEngineNozzle(-0.12);
    nozzleLeft.name = 'engine_nozzle_left';
    rocket.add(nozzleLeft);

    const nozzleRight = this.createEngineNozzle(0.12);
    nozzleRight.name = 'engine_nozzle_right';
    rocket.add(nozzleRight);

    // If this is for track pickup, add smaller animated idle flames
    if (options.isItemPickup) {
      const idleFlameGeo = new THREE.ConeGeometry(0.06, 0.28, 8);
      idleFlameGeo.rotateX(Math.PI);

      const idleFlameL = new THREE.Mesh(idleFlameGeo, this.flameOuterMat!);
      idleFlameL.position.set(-0.12, -0.88, 0);
      idleFlameL.name = 'idle_flame_left';
      rocket.add(idleFlameL);

      const idleFlameR = new THREE.Mesh(idleFlameGeo, this.flameOuterMat!);
      idleFlameR.position.set(0.12, -0.88, 0);
      idleFlameR.name = 'idle_flame_right';
      rocket.add(idleFlameR);
    }

    return rocket;
  }

  /**
   * Helper to build a detailed single rocket nozzle with interior incandescent glow
   */
  private static createEngineNozzle(xOffset: number): THREE.Group {
    const nozzleGroup = new THREE.Group();
    nozzleGroup.position.set(xOffset, -0.66, 0);

    // Bell-shaped nozzle exterior (flaring outward)
    // Top radius 0.08, Bottom radius 0.13, Height 0.22
    const bellGeo = new THREE.CylinderGeometry(0.08, 0.13, 0.22, 12, 1, true);
    const bellMesh = new THREE.Mesh(bellGeo, this.nozzleMat!);
    bellMesh.castShadow = true;
    nozzleGroup.add(bellMesh);

    // Nozzle Throat Ring
    const throatGeo = new THREE.TorusGeometry(0.085, 0.02, 8, 12);
    throatGeo.rotateX(Math.PI / 2);
    const throatMesh = new THREE.Mesh(throatGeo, this.nozzleMat!);
    throatMesh.position.set(0, 0.1, 0);
    nozzleGroup.add(throatMesh);

    // Glowing combustion chamber disc inside the nozzle
    const coreDiscGeo = new THREE.CircleGeometry(0.075, 12);
    coreDiscGeo.rotateX(-Math.PI / 2);
    const coreDisc = new THREE.Mesh(coreDiscGeo, this.nozzleInteriorMat!);
    coreDisc.position.set(0, 0.08, 0);
    nozzleGroup.add(coreDisc);

    return nozzleGroup;
  }
}
