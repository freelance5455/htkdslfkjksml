/**
 * High-Fidelity Three.js 3D Runner Engine for Subway Mom Runner 3D.
 * Authentic Subway Surfers styling: steel rails, wooden sleepers, realistic commuter trains,
 * rubber speed bumps, overhead railway gantries, graffiti decals, and diverse 3D hero & vehicle models.
 */

import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { CharacterItem, HoverboardItem, BackpackItem, LevelConfig, ActivePowerups } from '../types/game';
import { HEROES_54, getHeroById } from './characterData';
import { VehicleItem } from './itemsData';
import { soundSystem } from './soundSystem';

// Pre-allocated math helpers to ensure 0 GC allocations in the render loop
const _vec3 = new THREE.Vector3();
const _color = new THREE.Color();

// Lane coordinates (-2.6, 0, 2.6)
export const LANES = [-2.6, 0, 2.6];

export interface EngineCallbacks {
  onScoreUpdate: (score: number, coins: number, distance: number) => void;
  onPowerupCollect: (type: 'magnet' | 'multiplier' | 'jetpack' | 'sneakers' | 'hoverboard') => void;
  onCrash: (obstacleType: string) => void;
  onWinLevel: () => void;
  onMomDistanceChange: (distance: number) => void;
}

interface Obstacle {
  mesh: THREE.Group;
  lane: number;
  z: number;
  type: 'subway_train' | 'speed_bump' | 'barrier_high' | 'barrier_low' | 'traffic_cones';
  boundingRadius: number;
  height: number;
  length: number;
  allowJumpOver: boolean;
  allowSlideUnder: boolean;
  isTrain?: boolean;
  trainSpeed?: number;
  cleared?: boolean;
}

interface Coin {
  mesh: THREE.Group;
  lane: number;
  z: number;
  y: number;
  collected: boolean;
}

interface PowerupPickup {
  mesh: THREE.Group;
  lane: number;
  z: number;
  y: number;
  type: 'magnet' | 'multiplier' | 'jetpack' | 'sneakers' | 'hoverboard';
  collected: boolean;
}

interface TrackChunk {
  group: THREE.Group;
  zStart: number;
  zEnd: number;
}

export class ThreeEngine {
  private container: HTMLElement;
  private callbacks: EngineCallbacks;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private isSoftwareGl = false;
  private frameId = 0;
  private clock = new THREE.Clock();

  // Simulation state
  private isRunning = false;
  private isPaused = false;
  private distanceRun = 0;
  private score = 0;
  private coins = 0;
  private baseSpeed = 22.0;
  private currentSpeed = 22.0;
  private targetSpeedMultiplier = 1.0;

  // Safe respawn & invulnerability shield
  private invulnerabilityTimer = 0;
  private shieldMesh: THREE.Mesh | null = null;

  // Player physics
  private playerLane = 1; // 0, 1, 2 (LANES[1] = 0)
  private playerX = 0;
  private playerTargetX = 0;
  private playerY = 0;
  private playerVelocityY = 0;
  private isJumping = false;
  private isSliding = false;
  private slideTimer = 0;
  private onTrainRoof = false;

  // Mom (The Chaser)
  private momGroup!: THREE.Group;
  private momDistance = 22.0; // Starts with safe distance
  private momMaxDistance = 24.0;
  private momMinDistance = 2.5;
  private momStumbleTimer = 0;
  private momX = 0;

  // 2nd Player (Multiplayer)
  private peerGroup: THREE.Group | null = null;
  private peerActive = false;
  private peerTargetX = 0;
  private peerTargetZ = 0;
  private peerTargetY = 0;

  // 3D Subject hierarchies
  private playerGroup!: THREE.Group;
  private playerBodyParts: Record<string, THREE.Object3D> = {};
  private vehicleMesh: THREE.Group | null = null;
  private backpackMesh: THREE.Group | null = null;
  private activePowerups: ActivePowerups = {
    magnet: 0,
    multiplier: 0,
    jetpack: 0,
    sneakers: 0,
    hoverboard: false
  };

  // Pools & Track
  private chunks: TrackChunk[] = [];
  private obstacles: Obstacle[] = [];
  private coinsList: Coin[] = [];
  private powerupsList: PowerupPickup[] = [];
  private particleGroup!: THREE.Group;
  private particles: Array<{ mesh: THREE.Mesh; vx: number; vy: number; vz: number; life: number; maxLife: number }> = [];

  // Active configurations
  private currentLevelConfig!: LevelConfig;
  private currentCharacter!: CharacterItem;
  private currentBoard!: HoverboardItem;
  private currentBackpack!: BackpackItem;

  // Visual effects
  private cameraShake = 0;
  private hitstopTimer = 0;

  constructor(
    container: HTMLElement,
    callbacks: EngineCallbacks,
    character: CharacterItem,
    board: HoverboardItem,
    backpack: BackpackItem,
    levelConfig: LevelConfig
  ) {
    this.container = container;
    this.callbacks = callbacks;
    this.currentCharacter = character;
    this.currentBoard = board;
    this.currentBackpack = backpack;
    this.currentLevelConfig = levelConfig;

    this.initThree();
    this.buildPlayer();
    this.buildMom();
    this.buildPeerPlaceholder();
    this.spawnInitialTrack(true); // Initial clean track with safe distance

    window.addEventListener('resize', this.onResize);
  }

  private initThree() {
    this.isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.2;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(this.currentLevelConfig.skyColor);
    // Horizon Fog matching atmosphere
    this.scene.fog = new THREE.Fog(this.currentLevelConfig.fogColor, 45, 160);

    // Studio Environment Reflections
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Camera setup - Dynamic third-person runner view
    this.camera = new THREE.PerspectiveCamera(65, width / height, 0.1, 240);
    this.camera.position.set(0, 5.0, -7.8);
    this.camera.lookAt(0, 1.8, 12);

    // Warm Key Light + Shadows
    const keyLight = new THREE.DirectionalLight(0xfff5e6, 1.4);
    keyLight.position.set(20, 32, 15);
    if (!this.isSoftwareGl) {
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 85;
      keyLight.shadow.camera.left = -18;
      keyLight.shadow.camera.right = 18;
      keyLight.shadow.camera.top = 25;
      keyLight.shadow.camera.bottom = -12;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    this.scene.add(keyLight);

    // Cool Sky / Ground Fill Light
    const hemiLight = new THREE.HemisphereLight(0x93c5fd, 0x334155, 0.75);
    hemiLight.position.set(0, 50, 0);
    this.scene.add(hemiLight);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    this.scene.add(ambientLight);

    // Particle root
    this.particleGroup = new THREE.Group();
    this.scene.add(this.particleGroup);
  }

  private onResize = () => {
    if (!this.container || !this.renderer || !this.camera) return;
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  // --- Subway Surfers Track Chunk Spawner ---

  private createSubwayTrackChunk(zStart: number, zEnd: number): TrackChunk {
    const group = new THREE.Group();
    const length = zEnd - zStart;
    const zCenter = (zStart + zEnd) / 2;

    // 1. Gravel Ballast & Asphalt Track Bed
    const bedGeo = new THREE.PlaneGeometry(11.2, length);
    const bedMat = new THREE.MeshStandardMaterial({
      color: 0x1f2937, // Dark ballast gravel
      roughness: 0.9,
      metalness: 0.1
    });
    const bed = new THREE.Mesh(bedGeo, bedMat);
    bed.rotation.x = -Math.PI / 2;
    bed.position.set(0, 0, zCenter);
    bed.receiveShadow = !this.isSoftwareGl;
    group.add(bed);

    // 2. Three Parallel Railway Tracks (قضبان السكك الحديدية المعدنية والعارضات الخشبية)
    const railMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8, // Steel silver
      roughness: 0.25,
      metalness: 0.95
    });
    const sleeperMat = new THREE.MeshStandardMaterial({
      color: 0x451a03, // Dark treated wood / concrete
      roughness: 0.85
    });

    LANES.forEach((laneX) => {
      // 2 Steel Rails per lane (left and right of lane center)
      [-0.65, 0.65].forEach((railOffset) => {
        const railGeo = new THREE.BoxGeometry(0.08, 0.12, length);
        const rail = new THREE.Mesh(railGeo, railMat);
        rail.position.set(laneX + railOffset, 0.08, zCenter);
        rail.castShadow = !this.isSoftwareGl;
        group.add(rail);
      });

      // Wooden / Concrete Sleepers (Cross-ties) spaced every 1.8 units
      const numSleepers = Math.floor(length / 1.8);
      for (let s = 0; s < numSleepers; s++) {
        const sleeperGeo = new THREE.BoxGeometry(1.65, 0.06, 0.35);
        const sleeper = new THREE.Mesh(sleeperGeo, sleeperMat);
        sleeper.position.set(laneX, 0.03, zStart + s * 1.8 + 0.9);
        sleeper.receiveShadow = !this.isSoftwareGl;
        group.add(sleeper);
      }
    });

    // 3. Sidewalks, Safety Walls, and Kerbs with Warning Yellow Stripes
    const kerbMat = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.6 });
    const sidewalkMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.9 });

    [-6.3, 6.3].forEach((xSide) => {
      // Elevated safety sidewalk
      const sideGeo = new THREE.BoxGeometry(3.2, 0.4, length);
      const sidewalk = new THREE.Mesh(sideGeo, sidewalkMat);
      sidewalk.position.set(xSide, 0.2, zCenter);
      sidewalk.receiveShadow = !this.isSoftwareGl;
      group.add(sidewalk);

      // Yellow/black safety curb edge
      const kerbGeo = new THREE.BoxGeometry(0.4, 0.45, length);
      const kerb = new THREE.Mesh(kerbGeo, kerbMat);
      kerb.position.set(xSide > 0 ? 4.9 : -4.9, 0.22, zCenter);
      group.add(kerb);
    });

    // 4. Detailed City Scenery: Buildings, Overpass Bridges, Streetlamps, Graffiti Decals
    const buildingColors = [0xef4444, 0x3b82f6, 0xf59e0b, 0x10b981, 0x8b5cf6, 0x06b6d4, 0xe2e8f0, 0xf43f5e];
    const numBuildings = Math.floor(length / 16);

    for (let i = 0; i < numBuildings; i++) {
      const bZ = zStart + i * 16 + 8;

      [-10.5, 10.5].forEach((bX) => {
        const bGroup = new THREE.Group();
        const bHeight = 12 + ((i * 5 + Math.abs(bX * 3)) % 14);
        const bWidth = 6.0;
        const bDepth = 13.5;
        const bColor = buildingColors[(i + Math.floor(Math.abs(bX))) % buildingColors.length];

        // Building Block
        const bGeo = new THREE.BoxGeometry(bWidth, bHeight, bDepth);
        const bMat = new THREE.MeshStandardMaterial({
          color: bColor,
          roughness: 0.7,
          metalness: 0.15
        });
        const building = new THREE.Mesh(bGeo, bMat);
        building.position.set(0, bHeight / 2, 0);
        building.castShadow = !this.isSoftwareGl;
        building.receiveShadow = !this.isSoftwareGl;
        bGroup.add(building);

        // Rows of Glass Windows
        const winGeo = new THREE.PlaneGeometry(1.0, 1.4);
        const winMat = new THREE.MeshStandardMaterial({
          color: 0x38bdf8,
          roughness: 0.2,
          metalness: 0.8
        });
        const floors = Math.floor(bHeight / 2.8);
        for (let f = 1; f < floors; f++) {
          for (let w = -1; w <= 1; w++) {
            const win = new THREE.Mesh(winGeo, winMat);
            win.position.set(bX > 0 ? -bWidth / 2 - 0.02 : bWidth / 2 + 0.02, f * 2.6 + 0.6, w * 3.0);
            win.rotation.y = bX > 0 ? -Math.PI / 2 : Math.PI / 2;
            bGroup.add(win);
          }
        }

        // Storefront Canopy / Awning (مظلة ملونة)
        const awningGeo = new THREE.BoxGeometry(1.6, 0.2, 4.2);
        const awningMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.5 });
        const awning = new THREE.Mesh(awningGeo, awningMat);
        awning.position.set(bX > 0 ? -bWidth / 2 - 0.7 : bWidth / 2 + 0.7, 3.2, 0);
        bGroup.add(awning);

        // Graffiti Art Decal Signboard on Wall
        const posterGeo = new THREE.PlaneGeometry(3.2, 2.0);
        const posterMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
        const poster = new THREE.Mesh(posterGeo, posterMat);
        poster.position.set(bX > 0 ? -bWidth / 2 - 0.03 : bWidth / 2 + 0.03, 5.5, 0);
        poster.rotation.y = bX > 0 ? -Math.PI / 2 : Math.PI / 2;
        bGroup.add(poster);

        // Rooftop Water Tank or Antenna
        const tankGeo = new THREE.CylinderGeometry(0.7, 0.7, 1.4, 8);
        const tankMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.8 });
        const tank = new THREE.Mesh(tankGeo, tankMat);
        tank.position.set(0, bHeight + 0.7, 0);
        bGroup.add(tank);

        bGroup.position.set(bX, 0, bZ);
        group.add(bGroup);
      });
    }

    // Overhead Railway Signal Gantry (جسر إشارات المترو المعلق فوق المسارات الثلاثة)
    if (Math.abs(zCenter) % 48 < 24) {
      const gantry = this.createSubwayGantry();
      gantry.position.set(0, 0, zCenter);
      group.add(gantry);
    }

    this.scene.add(group);
    return { group, zStart, zEnd };
  }

  /**
   * Railway Signal Gantry: Steel arch spanning all 3 lanes with traffic signals
   */
  private createSubwayGantry(): THREE.Group {
    const gantry = new THREE.Group();
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, roughness: 0.3 });

    // Left and Right Towers
    [-5.0, 5.0].forEach((tx) => {
      const towerGeo = new THREE.CylinderGeometry(0.18, 0.22, 6.0, 8);
      const tower = new THREE.Mesh(towerGeo, steelMat);
      tower.position.set(tx, 3.0, 0);
      gantry.add(tower);
    });

    // Horizontal Beam
    const beamGeo = new THREE.BoxGeometry(10.6, 0.35, 0.5);
    const beam = new THREE.Mesh(beamGeo, steelMat);
    beam.position.set(0, 5.8, 0);
    gantry.add(beam);

    // 3 Signal Traffic Lights (one over each lane)
    const signalBoxGeo = new THREE.BoxGeometry(0.6, 1.1, 0.3);
    const signalBoxMat = new THREE.MeshStandardMaterial({ color: 0x0f172a });
    const greenLightMat = new THREE.MeshBasicMaterial({ color: 0x22c55e });
    const redLightMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });

    LANES.forEach((lx, idx) => {
      const box = new THREE.Mesh(signalBoxGeo, signalBoxMat);
      box.position.set(lx, 5.2, 0);
      gantry.add(box);

      const light = new THREE.Mesh(
        new THREE.SphereGeometry(0.16, 8, 8),
        idx === 1 ? greenLightMat : redLightMat
      );
      light.position.set(lx, 5.2, -0.18);
      gantry.add(light);
    });

    return gantry;
  }

  // --- Initial Track Setup with Safe Runway ---

  private spawnInitialTrack(isCleanSafeRun = true) {
    let currentZ = -15;
    for (let i = 0; i < 6; i++) {
      const nextZ = currentZ + 40;
      const chunk = this.createSubwayTrackChunk(currentZ, nextZ);
      this.chunks.push(chunk);

      // Safe Runway: Do NOT spawn obstacles in the first 2 chunks (first ~65m)
      if (!isCleanSafeRun || i >= 2) {
        this.populateChunkWithSubwayObstacles(currentZ, nextZ);
      }
      currentZ = nextZ;
    }
  }

  // --- Obstacle Population with Proper Spacing and Safe Lanes ---

  private populateChunkWithSubwayObstacles(zStart: number, zEnd: number) {
    // Generous obstacle spacing (28 to 36 meters between vehicles)
    const stepZ = 30;

    for (let z = zStart + 8; z < zEnd - 6; z += stepZ) {
      // Pick 1 or at most 2 blocked lanes, ensuring AT LEAST ONE 100% CLEAR LANE
      const freeLane = Math.floor(Math.random() * 3);
      const blockedLanes = [0, 1, 2].filter((l) => l !== freeLane);

      // Decide obstacle types
      const primaryLane = blockedLanes[0];
      const r = Math.random();

      if (r < 0.45) {
        // Authentic Subway Commuter Train!
        this.spawnSubwayTrain(primaryLane, z);
      } else if (r < 0.70) {
        // Striped Rubber Speed Bump (مطبات واقعية)
        this.spawnSpeedBump(primaryLane, z);
      } else if (r < 0.88) {
        // High Signal Bar (Slide under)
        this.spawnHighBarricade(primaryLane, z);
      } else {
        // Low Construction Barrier (Jump over)
        this.spawnLowBarrier(primaryLane, z);
      }

      // Safe Coin Rows in open lane or on train roof!
      const coinY = (r < 0.45 && Math.random() > 0.4) ? 3.6 : 0.85;
      this.spawnCoinRow(freeLane, z - 10, coinY, 5);

      // Chance for powerup
      if (Math.random() < 0.28) {
        this.spawnPowerupPickup(freeLane, z + 6);
      }
    }
  }

  // --- 1. Subway Train 3D Model (قطار صبواي المترو الواقعي) ---

  private spawnSubwayTrain(lane: number, z: number) {
    const group = new THREE.Group();
    const x = LANES[lane];
    const trainLength = 9.2;
    const trainWidth = 2.2;
    const trainHeight = 2.85;

    // Train Body (Red & Silver Commuter Train)
    const bodyGeo = new THREE.BoxGeometry(trainWidth, trainHeight, trainLength);
    const trainColors = [0xdc2626, 0x2563eb, 0x16a34a, 0x475569];
    const bodyColor = trainColors[Math.floor(Math.random() * trainColors.length)];
    const bodyMat = new THREE.MeshStandardMaterial({
      color: bodyColor,
      roughness: 0.35,
      metalness: 0.6
    });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.y = trainHeight / 2 + 0.35;
    body.castShadow = !this.isSoftwareGl;
    group.add(body);

    // Front Aerodynamic Nose / Cowcatcher
    const noseGeo = new THREE.BoxGeometry(trainWidth * 0.95, trainHeight * 0.85, 1.2);
    const noseMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.3 });
    const nose = new THREE.Mesh(noseGeo, noseMat);
    nose.position.set(0, trainHeight / 2 + 0.35, -trainLength / 2 - 0.5);
    group.add(nose);

    // Front Windshield (زجاج كابينة القيادة)
    const windshieldGeo = new THREE.PlaneGeometry(1.8, 0.9);
    const glassMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1, metalness: 0.95 });
    const windshield = new THREE.Mesh(windshieldGeo, glassMat);
    windshield.position.set(0, trainHeight / 2 + 0.8, -trainLength / 2 - 1.11);
    windshield.rotation.y = Math.PI;
    group.add(windshield);

    // Front Twin Headlights (كشافات أمامية قوية)
    const lightMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
    [-0.7, 0.7].forEach((lx) => {
      const headlight = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 8), lightMat);
      headlight.position.set(lx, 1.0, -trainLength / 2 - 1.12);
      group.add(headlight);
    });

    // Side Passenger Windows and Doors
    const sideWinGeo = new THREE.PlaneGeometry(1.4, 0.8);
    for (let w = -3; w <= 3; w += 2) {
      [-trainWidth / 2 - 0.02, trainWidth / 2 + 0.02].forEach((wx) => {
        const win = new THREE.Mesh(sideWinGeo, glassMat);
        win.position.set(wx, trainHeight / 2 + 0.5, w);
        win.rotation.y = wx > 0 ? Math.PI / 2 : -Math.PI / 2;
        group.add(win);
      });
    }

    // Ribbed Walkable Roof (سطح القطار للركض عليه!)
    const roofWalkGeo = new THREE.PlaneGeometry(trainWidth * 0.9, trainLength * 0.95);
    const roofWalkMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.85, metalness: 0.4 });
    const roofWalk = new THREE.Mesh(roofWalkGeo, roofWalkMat);
    roofWalk.rotation.x = -Math.PI / 2;
    roofWalk.position.set(0, trainHeight + 0.36, 0);
    group.add(roofWalk);

    // Roof Vents & Antennas
    const ventGeo = new THREE.CylinderGeometry(0.25, 0.25, 0.3, 8);
    const ventMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8 });
    [-2.2, 0, 2.2].forEach((vz) => {
      const vent = new THREE.Mesh(ventGeo, ventMat);
      vent.position.set(0, trainHeight + 0.5, vz);
      group.add(vent);
    });

    // Steel Wheels and Undercarriage Bogies
    const wheelGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.22, 12);
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.9, roughness: 0.4 });
    [
      [-0.95, 0.35, -3.0],
      [0.95, 0.35, -3.0],
      [-0.95, 0.35, 3.0],
      [0.95, 0.35, 3.0]
    ].forEach(([wx, wy, wz]) => {
      const wheel = new THREE.Mesh(wheelGeo, wheelMat);
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(wx, wy, wz);
      group.add(wheel);
    });

    // Contact shadow
    const shadowGeo = new THREE.PlaneGeometry(2.6, trainLength + 1.2);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.45,
      depthWrite: false
    });
    const shadow = new THREE.Mesh(shadowGeo, shadowMat);
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.02;
    group.add(shadow);

    group.position.set(x, 0, z);
    this.scene.add(group);

    this.obstacles.push({
      mesh: group,
      lane,
      z,
      type: 'subway_train',
      boundingRadius: 1.6,
      height: trainHeight + 0.36,
      length: trainLength,
      allowJumpOver: true, // Can land and run on top!
      allowSlideUnder: false,
      isTrain: true
    });
  }

  // --- 2. Striped Rubber Speed Bump (مطبات واقعية) ---

  private spawnSpeedBump(lane: number, z: number) {
    const group = new THREE.Group();
    const x = LANES[lane];
    const bumpWidth = 2.4;
    const bumpLength = 1.4;
    const bumpHeight = 0.32;

    // Curved rubber hump
    const bumpGeo = new THREE.CylinderGeometry(bumpHeight, bumpHeight, bumpWidth, 12, 1, false, 0, Math.PI);
    const bumpMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.85 });
    const bump = new THREE.Mesh(bumpGeo, bumpMat);
    bump.rotation.z = Math.PI / 2;
    bump.position.set(0, 0, 0);
    group.add(bump);

    // Yellow Chevron Safety Stripes (خطوط تحذيرية صفراء متناوبة)
    const stripeMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
    [-0.8, -0.4, 0, 0.4, 0.8].forEach((sx) => {
      const stripeGeo = new THREE.PlaneGeometry(0.18, bumpLength * 0.9);
      const stripe = new THREE.Mesh(stripeGeo, stripeMat);
      stripe.rotation.x = -Math.PI / 2;
      stripe.position.set(sx, 0.22, 0);
      group.add(stripe);
    });

    group.position.set(x, 0, z);
    this.scene.add(group);

    this.obstacles.push({
      mesh: group,
      lane,
      z,
      type: 'speed_bump',
      boundingRadius: 1.2,
      height: bumpHeight,
      length: bumpLength,
      allowJumpOver: true,
      allowSlideUnder: false
    });
  }

  // --- 3. Overhead High Barricade (Slide under!) ---

  private spawnHighBarricade(lane: number, z: number) {
    const group = new THREE.Group();
    const x = LANES[lane];

    // Two steel support posts
    const postMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.7, roughness: 0.3 });
    [-1.05, 1.05].forEach((px) => {
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2.6, 8), postMat);
      post.position.set(px, 1.3, 0);
      group.add(post);
    });

    // High overhead danger board (لوحة تحذيرية صفراء وسوداء عالية)
    const boardGeo = new THREE.BoxGeometry(2.3, 0.95, 0.14);
    const boardMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.4 });
    const board = new THREE.Mesh(boardGeo, boardMat);
    board.position.set(0, 2.15, 0);
    board.castShadow = !this.isSoftwareGl;
    group.add(board);

    // Caution stripes texture
    const cautionStripeGeo = new THREE.PlaneGeometry(2.1, 0.4);
    const cautionMat = new THREE.MeshBasicMaterial({ color: 0xdc2626 });
    const cautionStripe = new THREE.Mesh(cautionStripeGeo, cautionMat);
    cautionStripe.position.set(0, 2.15, -0.08);
    cautionStripe.rotation.y = Math.PI;
    group.add(cautionStripe);

    group.position.set(x, 0, z);
    this.scene.add(group);

    this.obstacles.push({
      mesh: group,
      lane,
      z,
      type: 'barrier_high',
      boundingRadius: 1.2,
      height: 2.6,
      length: 0.5,
      allowJumpOver: false,
      allowSlideUnder: true // MUST slide under!
    });
  }

  // --- 4. Low Construction Barrier (Jump over) ---

  private spawnLowBarrier(lane: number, z: number) {
    const group = new THREE.Group();
    const x = LANES[lane];

    // Wooden A-frame stands
    const legMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.8 });
    [-0.95, 0.95].forEach((lx) => {
      const leg1 = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.0, 0.12), legMat);
      leg1.position.set(lx, 0.5, 0);
      leg1.rotation.z = 0.25;
      group.add(leg1);

      const leg2 = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.0, 0.12), legMat);
      leg2.position.set(lx, 0.5, 0);
      leg2.rotation.z = -0.25;
      group.add(leg2);
    });

    // Red & white barrier board
    const plankMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.5 });
    const plank = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.35, 0.08), plankMat);
    plank.position.set(0, 0.75, 0);
    plank.castShadow = !this.isSoftwareGl;
    group.add(plank);

    // Flashing hazard lamp on top
    const lampMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 8), lampMat);
    lamp.position.set(0, 1.05, 0);
    group.add(lamp);

    group.position.set(x, 0, z);
    this.scene.add(group);

    this.obstacles.push({
      mesh: group,
      lane,
      z,
      type: 'barrier_low',
      boundingRadius: 1.1,
      height: 0.9,
      length: 0.4,
      allowJumpOver: true,
      allowSlideUnder: false
    });
  }

  // --- Collectible Coins and Powerups ---

  private spawnCoinRow(lane: number, zCenter: number, y: number, count: number) {
    const x = LANES[lane];
    for (let i = 0; i < count; i++) {
      const z = zCenter + i * 2.2;
      const coinGroup = new THREE.Group();

      const coinGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.1, 16);
      const coinMat = new THREE.MeshStandardMaterial({
        color: 0xfacc15,
        metalness: 0.95,
        roughness: 0.15
      });
      const coin = new THREE.Mesh(coinGeo, coinMat);
      coin.rotation.z = Math.PI / 2;
      coinGroup.add(coin);

      coinGroup.position.set(x, y, z);
      this.scene.add(coinGroup);

      this.coinsList.push({
        mesh: coinGroup,
        lane,
        z,
        y,
        collected: false
      });
    }
  }

  private spawnPowerupPickup(lane: number, z: number) {
    const types: Array<'magnet' | 'multiplier' | 'jetpack' | 'sneakers' | 'hoverboard'> = [
      'magnet',
      'multiplier',
      'jetpack',
      'sneakers',
      'hoverboard'
    ];
    const type = types[Math.floor(Math.random() * types.length)];
    const x = LANES[lane];
    const y = 1.1;

    const group = new THREE.Group();
    const colors: Record<string, number> = {
      magnet: 0xef4444,
      multiplier: 0x3b82f6,
      jetpack: 0xf59e0b,
      sneakers: 0x10b981,
      hoverboard: 0xa855f7
    };

    const orb = new THREE.Mesh(
      new THREE.BoxGeometry(0.75, 0.75, 0.75),
      new THREE.MeshStandardMaterial({ color: colors[type], metalness: 0.8, roughness: 0.2 })
    );
    group.add(orb);

    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(0.6, 0.07, 8, 16),
      new THREE.MeshBasicMaterial({ color: 0xffffff })
    );
    ring.rotation.x = Math.PI / 2;
    group.add(ring);

    group.position.set(x, y, z);
    this.scene.add(group);

    this.powerupsList.push({
      mesh: group,
      lane,
      z,
      y,
      type,
      collected: false
    });
  }

  // --- Dynamic Player 3D Character Model (4 Distinct Styles: Standard, Superhero, Monster, Robot) ---

  private buildPlayer() {
    this.playerGroup = new THREE.Group();
    const heroSpec = getHeroById(this.currentCharacter.id);
    const c = heroSpec.colors;
    const style = heroSpec.modelStyle;

    // 1. Torso / Jacket / Armor
    const torsoGeo = new THREE.BoxGeometry(style === 'monster' ? 0.95 : 0.75, 0.95, 0.45);
    const torsoMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(c.shirt),
      roughness: style === 'robot' ? 0.2 : 0.6,
      metalness: style === 'robot' || style === 'superhero' ? 0.6 : 0.1
    });
    const torso = new THREE.Mesh(torsoGeo, torsoMat);
    torso.position.y = 1.35;
    torso.castShadow = !this.isSoftwareGl;
    this.playerGroup.add(torso);
    this.playerBodyParts.torso = torso;

    // Superhero Cape or Emblem
    if (style === 'superhero') {
      const capeGeo = new THREE.PlaneGeometry(0.7, 1.1);
      const capeMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(c.accessory || '#dc2626'), roughness: 0.6 });
      const cape = new THREE.Mesh(capeGeo, capeMat);
      cape.position.set(0, 1.25, -0.28);
      cape.rotation.x = 0.2;
      this.playerGroup.add(cape);
    }

    // 2. Head
    const headGeo = new THREE.SphereGeometry(style === 'monster' ? 0.45 : 0.38, 16, 16);
    const skinMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(c.skin),
      roughness: 0.8
    });
    const head = new THREE.Mesh(headGeo, skinMat);
    head.position.y = 2.12;
    head.castShadow = !this.isSoftwareGl;
    this.playerGroup.add(head);
    this.playerBodyParts.head = head;

    // Monster Horns or Superhero Mask or Cap
    if (style === 'monster') {
      // Dual horns
      const hornGeo = new THREE.ConeGeometry(0.12, 0.4, 8);
      const hornMat = new THREE.MeshStandardMaterial({ color: 0x1f2937 });
      [-0.22, 0.22].forEach((hx) => {
        const horn = new THREE.Mesh(hornGeo, hornMat);
        horn.position.set(hx, 2.5, 0);
        horn.rotation.z = hx > 0 ? -0.3 : 0.3;
        this.playerGroup.add(horn);
      });
    } else if (style === 'superhero') {
      // Lightning mask / visor
      const maskGeo = new THREE.BoxGeometry(0.65, 0.18, 0.35);
      const maskMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(c.accessory || '#fbbf24') });
      const mask = new THREE.Mesh(maskGeo, maskMat);
      mask.position.set(0, 2.15, 0.25);
      this.playerGroup.add(mask);
    } else {
      // Standard Cap or Headphones
      const capGeo = new THREE.CylinderGeometry(0.4, 0.42, 0.22, 12);
      const capMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(c.accessory || c.hair), roughness: 0.5 });
      const cap = new THREE.Mesh(capGeo, capMat);
      cap.position.y = 2.32;
      this.playerGroup.add(cap);

      const brimGeo = new THREE.BoxGeometry(0.5, 0.05, 0.35);
      const brim = new THREE.Mesh(brimGeo, capMat);
      brim.position.set(0, 2.25, 0.45);
      this.playerGroup.add(brim);
    }

    // 3. Limbs (Arms & Legs)
    const armGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.75, 8);
    const armMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(c.shirt), roughness: 0.6 });
    const leftArm = new THREE.Mesh(armGeo, armMat);
    leftArm.position.set(style === 'monster' ? -0.65 : -0.52, 1.35, 0);
    this.playerGroup.add(leftArm);
    this.playerBodyParts.leftArm = leftArm;

    const rightArm = new THREE.Mesh(armGeo, armMat);
    rightArm.position.set(style === 'monster' ? 0.65 : 0.52, 1.35, 0);
    this.playerGroup.add(rightArm);
    this.playerBodyParts.rightArm = rightArm;

    const legGeo = new THREE.CylinderGeometry(0.14, 0.12, 0.85, 8);
    const legMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(c.pants), roughness: 0.7 });
    const leftLeg = new THREE.Mesh(legGeo, legMat);
    leftLeg.position.set(-0.24, 0.5, 0);
    this.playerGroup.add(leftLeg);
    this.playerBodyParts.leftLeg = leftLeg;

    const rightLeg = new THREE.Mesh(legGeo, legMat);
    rightLeg.position.set(0.24, 0.5, 0);
    this.playerGroup.add(rightLeg);
    this.playerBodyParts.rightLeg = rightLeg;

    // Shoes
    const shoeGeo = new THREE.BoxGeometry(0.22, 0.18, 0.38);
    const shoeMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(c.shoes), roughness: 0.4 });
    const leftShoe = new THREE.Mesh(shoeGeo, shoeMat);
    leftShoe.position.set(-0.24, 0.09, 0.06);
    this.playerGroup.add(leftShoe);

    const rightShoe = new THREE.Mesh(shoeGeo, shoeMat);
    rightShoe.position.set(0.24, 0.09, 0.06);
    this.playerGroup.add(rightShoe);

    // 4. Temporary Invulnerability Safe Respawn Shield (Bubble)
    const shieldGeo = new THREE.SphereGeometry(1.6, 16, 16);
    const shieldMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.35,
      wireframe: true
    });
    this.shieldMesh = new THREE.Mesh(shieldGeo, shieldMat);
    this.shieldMesh.position.y = 1.2;
    this.shieldMesh.visible = false;
    this.playerGroup.add(this.shieldMesh);

    // Vehicle & Backpack
    this.updateVehicleMesh();
    this.updateBackpackMesh();

    // Contact shadow beneath player
    const shadowGeo = new THREE.PlaneGeometry(1.3, 1.9);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.45,
      depthWrite: false
    });
    const shadow = new THREE.Mesh(shadowGeo, shadowMat);
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.02;
    this.playerGroup.add(shadow);

    this.playerGroup.position.set(0, 0, 0);
    this.scene.add(this.playerGroup);
  }

  // --- Dynamic Rideable Vehicles 3D (Hoverbike, Mini Kart, Scooter, Rocket, Carpet, Skateboard) ---

  private updateVehicleMesh() {
    if (this.vehicleMesh) {
      this.playerGroup.remove(this.vehicleMesh);
      this.vehicleMesh = null;
    }

    const vGroup = new THREE.Group();
    const board = this.currentBoard as VehicleItem;
    const vType = board.vehicleType || 'board';
    const primaryColor = new THREE.Color(board.primaryColor);

    if (vType === 'bike') {
      // Hoverbike: Aerodynamic body, handlebars, and glowing thruster
      const frame = new THREE.Mesh(
        new THREE.BoxGeometry(0.5, 0.3, 1.6),
        new THREE.MeshStandardMaterial({ color: primaryColor, metalness: 0.8, roughness: 0.2 })
      );
      frame.position.y = 0.25;
      vGroup.add(frame);

      // Handlebars
      const handle = new THREE.Mesh(
        new THREE.CylinderGeometry(0.04, 0.04, 0.7, 8),
        new THREE.MeshStandardMaterial({ color: 0x111827 })
      );
      handle.rotation.z = Math.PI / 2;
      handle.position.set(0, 0.55, 0.4);
      vGroup.add(handle);

      // Twin turbine thrusters
      [-0.28, 0.28].forEach((bx) => {
        const turbine = new THREE.Mesh(
          new THREE.CylinderGeometry(0.12, 0.14, 0.6, 8),
          new THREE.MeshBasicMaterial({ color: 0x60a5fa })
        );
        turbine.rotation.x = Math.PI / 2;
        turbine.position.set(bx, 0.2, -0.6);
        vGroup.add(turbine);
      });

    } else if (vType === 'kart') {
      // Mini Cyber Kart: Chassis, bumper, steering wheel, wide wheels
      const chassis = new THREE.Mesh(
        new THREE.BoxGeometry(1.2, 0.25, 1.8),
        new THREE.MeshStandardMaterial({ color: primaryColor, metalness: 0.7, roughness: 0.3 })
      );
      chassis.position.y = 0.2;
      vGroup.add(chassis);

      // Steering wheel
      const wheel = new THREE.Mesh(
        new THREE.TorusGeometry(0.18, 0.03, 6, 12),
        new THREE.MeshStandardMaterial({ color: 0x111827 })
      );
      wheel.position.set(0, 0.45, 0.35);
      vGroup.add(wheel);

      // 4 Wide wheels
      [-0.65, 0.65].forEach((wx) => {
        [-0.6, 0.6].forEach((wz) => {
          const w = new THREE.Mesh(
            new THREE.CylinderGeometry(0.2, 0.2, 0.16, 10),
            new THREE.MeshStandardMaterial({ color: 0x09090b })
          );
          w.rotation.z = Math.PI / 2;
          w.position.set(wx, 0.2, wz);
          vGroup.add(w);
        });
      });

    } else if (vType === 'scooter') {
      // E-Scooter: Standing deck, upright handlebar stem, headlight
      const deck = new THREE.Mesh(
        new THREE.BoxGeometry(0.35, 0.08, 1.4),
        new THREE.MeshStandardMaterial({ color: primaryColor })
      );
      deck.position.y = 0.12;
      vGroup.add(deck);

      const stem = new THREE.Mesh(
        new THREE.CylinderGeometry(0.04, 0.04, 1.0, 8),
        new THREE.MeshStandardMaterial({ color: 0x1e293b })
      );
      stem.position.set(0, 0.6, 0.55);
      vGroup.add(stem);

    } else if (vType === 'carpet') {
      // Undulating Magic Carpet
      const carpet = new THREE.Mesh(
        new THREE.BoxGeometry(1.1, 0.05, 1.8),
        new THREE.MeshStandardMaterial({ color: primaryColor, roughness: 0.7 })
      );
      carpet.position.y = 0.15;
      vGroup.add(carpet);

      // Gold tassels at corners
      const tasselMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
      [
        [-0.55, 0.1, -0.9],
        [0.55, 0.1, -0.9],
        [-0.55, 0.1, 0.9],
        [0.55, 0.1, 0.9]
      ].forEach(([tx, ty, tz]) => {
        const tassel = new THREE.Mesh(new THREE.SphereGeometry(0.08, 6, 6), tasselMat);
        tassel.position.set(tx, ty, tz);
        vGroup.add(tassel);
      });

    } else {
      // Classic Skateboard with 4 rolling wheels
      const boardMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.65, 0.08, 1.7),
        new THREE.MeshStandardMaterial({ color: primaryColor, metalness: 0.6, roughness: 0.3 })
      );
      boardMesh.position.y = 0.14;
      vGroup.add(boardMesh);

      // Underside glow strip
      const glow = new THREE.Mesh(
        new THREE.PlaneGeometry(0.45, 1.5),
        new THREE.MeshBasicMaterial({ color: new THREE.Color(board.trailColor) })
      );
      glow.rotation.x = Math.PI / 2;
      glow.position.y = 0.08;
      vGroup.add(glow);
    }

    vGroup.visible = this.activePowerups.hoverboard;
    this.vehicleMesh = vGroup;
    this.playerGroup.add(this.vehicleMesh);
  }

  private updateBackpackMesh() {
    if (this.backpackMesh) {
      this.playerGroup.remove(this.backpackMesh);
      this.backpackMesh = null;
    }

    const bGroup = new THREE.Group();
    const isJet = this.currentBackpack.isJetpack;
    const color = new THREE.Color(this.currentBackpack.primaryColor);

    if (isJet) {
      // Dual rocket cylinders
      [-0.18, 0.18].forEach((tx) => {
        const tank = new THREE.Mesh(
          new THREE.CylinderGeometry(0.14, 0.14, 0.65, 8),
          new THREE.MeshStandardMaterial({ color, metalness: 0.8, roughness: 0.2 })
        );
        tank.position.set(tx, 1.45, -0.32);
        bGroup.add(tank);
      });
    } else {
      // Satchel / school bag
      const bag = new THREE.Mesh(
        new THREE.BoxGeometry(0.55, 0.6, 0.26),
        new THREE.MeshStandardMaterial({ color, roughness: 0.7 })
      );
      bag.position.set(0, 1.4, -0.32);
      bGroup.add(bag);
    }

    this.backpackMesh = bGroup;
    this.playerGroup.add(this.backpackMesh);
  }

  // --- Mom (ماما) 3D Model with Slippers ---

  private buildMom() {
    this.momGroup = new THREE.Group();

    // Abaya / Dress Body
    const dress = new THREE.Mesh(
      new THREE.CylinderGeometry(0.55, 0.95, 1.5, 12),
      new THREE.MeshStandardMaterial({ color: 0x7c3aed, roughness: 0.8 })
    );
    dress.position.y = 1.0;
    dress.castShadow = !this.isSoftwareGl;
    this.momGroup.add(dress);

    // Head with Scarf (حجاب وردي)
    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.44, 14, 14),
      new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.7 })
    );
    head.position.y = 2.0;
    this.momGroup.add(head);

    // Face & Glasses
    const face = new THREE.Mesh(
      new THREE.SphereGeometry(0.28, 10, 10),
      new THREE.MeshStandardMaterial({ color: 0xf3b793, roughness: 0.85 })
    );
    face.position.set(0, 1.95, 0.25);
    this.momGroup.add(face);

    // Waving Right Arm with The Flying Slipper (الشبشب السحري)
    const rightArmGroup = new THREE.Group();
    rightArmGroup.position.set(0.65, 1.4, 0);

    const arm = new THREE.Mesh(
      new THREE.CylinderGeometry(0.12, 0.12, 0.8, 8),
      new THREE.MeshStandardMaterial({ color: 0x7c3aed })
    );
    arm.position.y = 0.35;
    rightArmGroup.add(arm);

    const slipper = new THREE.Mesh(
      new THREE.BoxGeometry(0.25, 0.1, 0.6),
      new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.3 })
    );
    slipper.position.set(0, 0.75, 0.2);
    slipper.rotation.x = 0.6;
    rightArmGroup.add(slipper);

    this.momGroup.add(rightArmGroup);

    // Shadow
    const momShadow = new THREE.Mesh(
      new THREE.PlaneGeometry(1.6, 2.0),
      new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.4, depthWrite: false })
    );
    momShadow.rotation.x = -Math.PI / 2;
    momShadow.position.y = 0.02;
    this.momGroup.add(momShadow);

    this.momGroup.position.set(0, 0, -this.momDistance);
    this.scene.add(this.momGroup);
  }

  // --- Multiplayer Companion ---

  private buildPeerPlaceholder() {
    this.peerGroup = new THREE.Group();
    const body = new THREE.Mesh(
      new THREE.BoxGeometry(0.7, 0.9, 0.4),
      new THREE.MeshStandardMaterial({ color: 0x3b82f6, roughness: 0.6 })
    );
    body.position.y = 1.3;
    this.peerGroup.add(body);

    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.35, 12, 12),
      new THREE.MeshStandardMaterial({ color: 0xf8d5c2 })
    );
    head.position.y = 2.05;
    this.peerGroup.add(head);

    this.peerGroup.visible = false;
    this.scene.add(this.peerGroup);
  }

  public updatePeerPosition(x: number, y: number, z: number, active: boolean) {
    if (!this.peerGroup) return;
    this.peerActive = active;
    this.peerGroup.visible = active;
    this.peerTargetX = x;
    this.peerTargetY = y;
    this.peerTargetZ = z;
  }

  // --- Controls & Safe Restart ---

  public start(isRestart = false) {
    this.isRunning = true;
    this.isPaused = false;
    this.clock.start();

    // Reset player position
    this.playerLane = 1;
    this.playerX = 0;
    this.playerTargetX = 0;
    this.playerY = 0;
    this.playerVelocityY = 0;
    this.isJumping = false;
    this.isSliding = false;
    this.onTrainRoof = false;

    // Safe respawn parameters:
    // Mom starts far back at safe distance
    this.momDistance = 22.0;
    this.momStumbleTimer = 0;

    // Safe Invulnerability Grace Period (3.5 seconds)
    if (isRestart) {
      this.invulnerabilityTimer = 3.5;
      if (this.shieldMesh) this.shieldMesh.visible = true;

      // Clean out obstacles directly in front
      for (let i = this.obstacles.length - 1; i >= 0; i--) {
        if (this.obstacles[i].mesh.position.z < 65) {
          this.scene.remove(this.obstacles[i].mesh);
          this.obstacles.splice(i, 1);
        }
      }
    } else {
      this.invulnerabilityTimer = 2.0;
    }

    soundSystem.startMusic(this.targetSpeedMultiplier);
    this.tick();
  }

  public pause() {
    this.isPaused = true;
    soundSystem.stopMusic();
  }

  public resume() {
    this.isPaused = false;
    this.clock.start();
    soundSystem.startMusic(this.targetSpeedMultiplier);
  }

  public moveLeft() {
    if (!this.isRunning || this.isPaused) return;
    if (this.playerLane > 0) {
      this.playerLane--;
      this.playerTargetX = LANES[this.playerLane];
      soundSystem.playLaneSwitch();
    }
  }

  public moveRight() {
    if (!this.isRunning || this.isPaused) return;
    if (this.playerLane < 2) {
      this.playerLane++;
      this.playerTargetX = LANES[this.playerLane];
      soundSystem.playLaneSwitch();
    }
  }

  public jump() {
    if (!this.isRunning || this.isPaused) return;
    const baseHeight = this.onTrainRoof ? 3.2 : 0;
    if (!this.isJumping && this.playerY <= baseHeight + 0.08) {
      this.isJumping = true;
      const jumpPower = this.activePowerups.sneakers > 0 ? 15.0 : 11.0;
      this.playerVelocityY = jumpPower;
      soundSystem.playJump();
    }
  }

  public slide() {
    if (!this.isRunning || this.isPaused) return;
    if (this.isJumping) {
      this.playerVelocityY = -15.0; // Fast fall
    }
    this.isSliding = true;
    this.slideTimer = 0.75;
    soundSystem.playSlide();
  }

  public toggleHoverboard() {
    if (!this.isRunning || this.isPaused) return;
    this.activePowerups.hoverboard = !this.activePowerups.hoverboard;
    if (this.vehicleMesh) {
      this.vehicleMesh.visible = this.activePowerups.hoverboard;
    }
    if (this.activePowerups.hoverboard) {
      soundSystem.playHoverboard();
      this.spawnParticleBurst(this.playerX, 0.2, 0, 16, 0xef4444);
    }
  }

  public applyConfig(character: CharacterItem, board: HoverboardItem, backpack: BackpackItem, level: LevelConfig) {
    this.currentCharacter = character;
    this.currentBoard = board;
    this.currentBackpack = backpack;
    this.currentLevelConfig = level;

    this.scene.background = new THREE.Color(level.skyColor);
    if (this.scene.fog) {
      this.scene.fog.color.setHex(level.fogColor);
    }

    // Rebuild player with new hero style
    this.scene.remove(this.playerGroup);
    this.buildPlayer();
  }

  // --- Main 60fps Loop & Physics ---

  private tick = () => {
    if (!this.isRunning) return;

    if (!this.isPaused) {
      const rawDt = this.clock.getDelta();
      const dt = Math.min(rawDt, 0.05);

      if (this.hitstopTimer > 0) {
        this.hitstopTimer -= dt;
      } else {
        this.updateSimulation(dt);
      }
    }

    this.renderer.render(this.scene, this.camera);

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 60);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private updateSimulation(dt: number) {
    // 1. Safe Invulnerability Countdown
    if (this.invulnerabilityTimer > 0) {
      this.invulnerabilityTimer -= dt;
      if (this.shieldMesh) {
        this.shieldMesh.visible = true;
        this.shieldMesh.rotation.y += 0.04;
      }
    } else if (this.shieldMesh) {
      this.shieldMesh.visible = false;
    }

    // 2. Speed Calculation
    const speedBonus = 1 + (this.currentCharacter.speedBonus / 100);
    const boardBonus = this.activePowerups.hoverboard ? this.currentBoard.speedMultiplier : 1.0;
    this.currentSpeed = this.baseSpeed * speedBonus * boardBonus * this.targetSpeedMultiplier;

    const deltaZ = this.currentSpeed * dt;
    this.distanceRun += deltaZ;
    this.score += Math.floor(deltaZ * (this.activePowerups.multiplier > 0 ? 2 : 1) * 2);

    // Win condition check
    if (this.distanceRun >= this.currentLevelConfig.targetDistance && this.coins >= this.currentLevelConfig.targetCoins) {
      this.callbacks.onWinLevel();
      return;
    }

    // 3. Smooth Player X Transition
    this.playerX = THREE.MathUtils.damp(this.playerX, this.playerTargetX, 15, dt);

    // 4. Player Jump & Gravity Physics with Train Roof support
    const targetFloorY = this.onTrainRoof ? 3.2 : 0;
    const gravity = -32.0;

    if (this.isJumping || this.playerY > targetFloorY) {
      this.playerVelocityY += gravity * dt;
      this.playerY += this.playerVelocityY * dt;

      if (this.playerY <= targetFloorY) {
        this.playerY = targetFloorY;
        this.playerVelocityY = 0;
        this.isJumping = false;
      }
    } else if (this.playerY < targetFloorY) {
      // Step up smoothly onto roof if within height
      this.playerY = THREE.MathUtils.damp(this.playerY, targetFloorY, 12, dt);
    }

    // 5. Sliding crouch scale
    if (this.isSliding) {
      this.slideTimer -= dt;
      this.playerGroup.scale.set(1.0, 0.48, 1.25);
      if (this.slideTimer <= 0) {
        this.isSliding = false;
        this.playerGroup.scale.set(1.0, 1.0, 1.0);
      }
    } else {
      this.playerGroup.scale.set(1.0, 1.0, 1.0);
    }

    this.playerGroup.position.set(this.playerX, this.playerY, 0);

    // Running animation
    const runCycle = (Date.now() / 1000) * (this.currentSpeed * 0.45);
    if (this.playerBodyParts.leftLeg && this.playerBodyParts.rightLeg) {
      if (this.isJumping) {
        this.playerBodyParts.leftLeg.rotation.x = -0.5;
        this.playerBodyParts.rightLeg.rotation.x = 0.4;
      } else if (!this.activePowerups.hoverboard) {
        this.playerBodyParts.leftLeg.rotation.x = Math.sin(runCycle) * 0.7;
        this.playerBodyParts.rightLeg.rotation.x = -Math.sin(runCycle) * 0.7;
      } else {
        this.playerBodyParts.leftLeg.rotation.x = 0.1;
        this.playerBodyParts.rightLeg.rotation.x = -0.2;
      }
    }

    // 6. Mom (ماما) Dynamics
    if (this.momStumbleTimer > 0) {
      this.momStumbleTimer -= dt;
      this.momDistance = Math.max(this.momMinDistance, this.momDistance - 4.5 * dt);
    } else {
      this.momDistance = Math.min(this.momMaxDistance, this.momDistance + 1.2 * dt);
    }

    this.momX = THREE.MathUtils.damp(this.momX, this.playerTargetX, 6.0, dt);
    this.momGroup.position.set(this.momX, 0, -this.momDistance);

    // Mom arm swing
    const momCycle = (Date.now() / 1000) * 12;
    const momRightArm = this.momGroup.children[3];
    if (momRightArm) {
      momRightArm.rotation.x = Math.sin(momCycle) * 0.8 + 0.3;
    }

    const momRatio = (this.momDistance - this.momMinDistance) / (this.momMaxDistance - this.momMinDistance);
    this.callbacks.onMomDistanceChange(Math.max(0, Math.min(1, momRatio)));

    // 7. Active Powerup Timers
    if (this.activePowerups.magnet > 0) this.activePowerups.magnet -= dt;
    if (this.activePowerups.multiplier > 0) this.activePowerups.multiplier -= dt;
    if (this.activePowerups.jetpack > 0) {
      this.activePowerups.jetpack -= dt;
      this.playerY = 6.2; // Fly in the sky!
    }
    if (this.activePowerups.sneakers > 0) this.activePowerups.sneakers -= dt;

    // 8. Move Track Chunks and Obstacles toward camera
    this.updateTrackChunks(deltaZ);
    this.updateObstacles(deltaZ);
    this.updateCoins(deltaZ);
    this.updatePowerupPickups(deltaZ);
    this.updateParticles(dt);

    // 9. Multiplayer Peer Interpolation
    if (this.peerGroup && this.peerActive) {
      this.peerGroup.position.x = THREE.MathUtils.damp(this.peerGroup.position.x, this.peerTargetX, 8, dt);
      this.peerGroup.position.y = THREE.MathUtils.damp(this.peerGroup.position.y, this.peerTargetY, 8, dt);
      this.peerGroup.position.z = THREE.MathUtils.damp(this.peerGroup.position.z, this.peerTargetZ, 8, dt);
    }

    // 10. Dynamic Camera Follow
    let camShakeX = 0;
    let camShakeY = 0;
    if (this.cameraShake > 0) {
      this.cameraShake -= dt * 2.5;
      camShakeX = (Math.random() - 0.5) * this.cameraShake * 0.35;
      camShakeY = (Math.random() - 0.5) * this.cameraShake * 0.35;
    }

    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, this.playerX * 0.65 + camShakeX, 8, dt);
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, 4.8 + this.playerY * 0.4 + camShakeY, 8, dt);
    this.camera.position.z = -7.4;
    this.camera.lookAt(this.playerX * 0.4, 1.8 + this.playerY * 0.3, 14);

    this.callbacks.onScoreUpdate(this.score, this.coins, Math.floor(this.distanceRun));
  }

  // --- Track Chunk Recycling ---

  private updateTrackChunks(deltaZ: number) {
    this.chunks.forEach((chunk) => {
      chunk.group.position.z -= deltaZ;
    });

    if (this.chunks.length > 0 && this.chunks[0].group.position.z < -45) {
      const oldChunk = this.chunks.shift()!;
      this.scene.remove(oldChunk.group);

      const lastChunk = this.chunks[this.chunks.length - 1];
      const newZStart = lastChunk ? lastChunk.group.position.z + 40 : 120;
      const newZEnd = newZStart + 40;

      const newChunk = this.createSubwayTrackChunk(newZStart, newZEnd);
      this.chunks.push(newChunk);
      this.populateChunkWithSubwayObstacles(newZStart, newZEnd);
    }
  }

  // --- Obstacle Collision & Roof Running ---

  private updateObstacles(deltaZ: number) {
    let standingOnRoof = false;

    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      const obs = this.obstacles[i];
      obs.mesh.position.z -= deltaZ;

      const dz = obs.mesh.position.z;
      const halfLen = obs.length / 2;
      const dx = Math.abs(obs.mesh.position.x - this.playerX);

      // Check if player is on the roof of a train
      if (obs.isTrain && dx < 1.1 && dz > -halfLen && dz < halfLen) {
        if (this.playerY >= obs.height - 0.25) {
          standingOnRoof = true;
        }
      }

      // Proximity Collision Check
      if (dx < 1.1 && dz > -halfLen && dz < halfLen + 0.4) {
        let isHit = false;

        if (this.invulnerabilityTimer > 0) {
          // Immune during safe respawn grace period!
          isHit = false;
        } else if (obs.type === 'subway_train') {
          // Front or side crash if not on roof
          if (this.playerY < obs.height - 0.25) {
            isHit = true;
          }
        } else if (obs.type === 'barrier_high') {
          // Must slide under!
          if (!this.isSliding) {
            isHit = true;
          }
        } else if (obs.type === 'speed_bump') {
          // Speed bump stumble if running on ground
          if (this.playerY < 0.35 && !this.activePowerups.hoverboard) {
            // Speed bump causes a stumble and brings Mom closer without fatal crash!
            if (!obs.cleared) {
              obs.cleared = true;
              this.momStumbleTimer = 1.2;
              soundSystem.playSlide();
            }
          }
        } else if (obs.type === 'barrier_low') {
          // Low barrier jump over
          if (this.playerY < 0.8) {
            isHit = true;
          }
        }

        if (isHit && !obs.cleared) {
          obs.cleared = true;
          this.handlePlayerCollision(obs.type);
          return;
        }
      }

      // Despawn passed obstacle
      if (obs.mesh.position.z < -25) {
        this.scene.remove(obs.mesh);
        this.obstacles.splice(i, 1);
      }
    }

    this.onTrainRoof = standingOnRoof;
  }

  private handlePlayerCollision(obstacleType: string) {
    // Hoverboard protects player by breaking!
    if (this.activePowerups.hoverboard) {
      this.activePowerups.hoverboard = false;
      if (this.vehicleMesh) this.vehicleMesh.visible = false;
      this.cameraShake = 0.8;
      soundSystem.playCrash();
      this.spawnParticleBurst(this.playerX, 1.0, 0, 25, 0xf59e0b);
      this.momStumbleTimer = 1.0;
      return;
    }

    // Fatal crash
    soundSystem.playCrash();
    this.cameraShake = 1.2;
    this.hitstopTimer = 0.08;
    this.spawnParticleBurst(this.playerX, 1.2, 0, 35, 0xef4444);

    this.isRunning = false;
    soundSystem.stopMusic();
    this.callbacks.onCrash(obstacleType);
  }

  // --- Coins & Magnetism ---

  private updateCoins(deltaZ: number) {
    const magnetActive = this.activePowerups.magnet > 0;

    for (let i = this.coinsList.length - 1; i >= 0; i--) {
      const coin = this.coinsList[i];
      coin.mesh.position.z -= deltaZ;
      coin.mesh.rotation.y += 0.05;

      // Magnet pull toward player
      if (magnetActive && Math.abs(coin.mesh.position.z) < 14) {
        coin.mesh.position.x = THREE.MathUtils.damp(coin.mesh.position.x, this.playerX, 10, 0.03);
        coin.mesh.position.y = THREE.MathUtils.damp(coin.mesh.position.y, this.playerY + 1.0, 10, 0.03);
      }

      const dz = Math.abs(coin.mesh.position.z);
      const dx = Math.abs(coin.mesh.position.x - this.playerX);
      const dy = Math.abs(coin.mesh.position.y - this.playerY);

      if (dz < 1.2 && dx < 1.1 && dy < 1.8 && !coin.collected) {
        coin.collected = true;
        this.coins++;
        this.score += 25 * (this.activePowerups.multiplier > 0 ? 2 : 1);
        soundSystem.playCoin();
        this.spawnParticleBurst(coin.mesh.position.x, coin.mesh.position.y, coin.mesh.position.z, 6, 0xfacc15);

        this.scene.remove(coin.mesh);
        this.coinsList.splice(i, 1);
        continue;
      }

      if (coin.mesh.position.z < -15) {
        this.scene.remove(coin.mesh);
        this.coinsList.splice(i, 1);
      }
    }
  }

  // --- Powerups ---

  private updatePowerupPickups(deltaZ: number) {
    for (let i = this.powerupsList.length - 1; i >= 0; i--) {
      const p = this.powerupsList[i];
      p.mesh.position.z -= deltaZ;
      p.mesh.rotation.y += 0.04;

      const dz = Math.abs(p.mesh.position.z);
      const dx = Math.abs(p.mesh.position.x - this.playerX);
      const dy = Math.abs(p.mesh.position.y - this.playerY);

      if (dz < 1.3 && dx < 1.1 && dy < 1.8 && !p.collected) {
        p.collected = true;
        soundSystem.playPowerup();
        this.spawnParticleBurst(p.mesh.position.x, p.mesh.position.y, p.mesh.position.z, 20, 0x38bdf8);

        if (p.type === 'magnet') this.activePowerups.magnet = 14;
        if (p.type === 'multiplier') this.activePowerups.multiplier = 16;
        if (p.type === 'jetpack') this.activePowerups.jetpack = 9;
        if (p.type === 'sneakers') this.activePowerups.sneakers = 15;
        if (p.type === 'hoverboard') {
          this.activePowerups.hoverboard = true;
          if (this.vehicleMesh) this.vehicleMesh.visible = true;
        }

        this.callbacks.onPowerupCollect(p.type);
        this.scene.remove(p.mesh);
        this.powerupsList.splice(i, 1);
        continue;
      }

      if (p.mesh.position.z < -15) {
        this.scene.remove(p.mesh);
        this.powerupsList.splice(i, 1);
      }
    }
  }

  // --- Particles ---

  private spawnParticleBurst(x: number, y: number, z: number, count: number, color: number) {
    const geo = new THREE.SphereGeometry(0.08, 6, 6);
    const mat = new THREE.MeshBasicMaterial({ color });

    for (let i = 0; i < count; i++) {
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x, y, z);
      this.particleGroup.add(mesh);

      const angle = Math.random() * Math.PI * 2;
      const speed = 2.0 + Math.random() * 4.5;
      this.particles.push({
        mesh,
        vx: Math.cos(angle) * speed,
        vy: 2.0 + Math.random() * 4.0,
        vz: Math.sin(angle) * speed,
        life: 0.5 + Math.random() * 0.4,
        maxLife: 0.9
      });
    }
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      p.vy -= 12.0 * dt;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;

      const scale = Math.max(0.01, p.life / p.maxLife);
      p.mesh.scale.set(scale, scale, scale);

      if (p.life <= 0) {
        this.particleGroup.remove(p.mesh);
        this.particles.splice(i, 1);
      }
    }
  }

  public getActivePowerups(): ActivePowerups {
    return { ...this.activePowerups };
  }

  public dispose() {
    this.isRunning = false;
    window.removeEventListener('resize', this.onResize);
    if (this.frameId) {
      cancelAnimationFrame(this.frameId);
      clearTimeout(this.frameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
      if (this.renderer.domElement && this.renderer.domElement.parentNode) {
        this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
      }
    }
  }
}
