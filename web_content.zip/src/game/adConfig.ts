/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Centralized Google AdMob & Web Ad Configuration for ARROW MASTER.
 *
 * Keep TEST IDs completely separate from PRODUCTION IDs so you can test
 * safely during development and switch to live AdMob IDs before publishing.
 */

export type AdEnvironment = 'test' | 'production';

export interface AdMobUnitConfig {
  readonly androidAppId: string;
  readonly appOpenAdUnitId: string;
  readonly rewardedAdUnitId: string;
}

/**
 * Official Google AdMob Test IDs for Android.
 * Safe for development, emulator testing, and QA without invalid traffic risk.
 */
export const TEST_ADMOB_CONFIG: AdMobUnitConfig = {
  androidAppId: 'ca-app-pub-3940256099942544~3347511713',
  appOpenAdUnitId: 'ca-app-pub-3940256099942544/9257395921',
  rewardedAdUnitId: 'ca-app-pub-3940256099942544/5224354917',
};

/**
 * Production Google AdMob IDs placeholder.
 * Replace these values with your verified AdMob Console IDs and set
 * AD_ENVIRONMENT = 'production' (or VITE_ADMOB_ENV=production) before release.
 */
export const PROD_ADMOB_CONFIG: AdMobUnitConfig = {
  androidAppId: 'ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY',
  appOpenAdUnitId: 'ca-app-pub-XXXXXXXXXXXXXXXX/AAAAAAAAAA',
  rewardedAdUnitId: 'ca-app-pub-XXXXXXXXXXXXXXXX/BBBBBBBBBB',
};

/**
 * Active AdMob environment selector. Defaults to 'test' for safe development.
 */
export const AD_ENVIRONMENT: AdEnvironment =
  typeof import.meta !== 'undefined' &&
  (import.meta as unknown as { env?: Record<string, string | undefined> }).env?.VITE_ADMOB_ENV ===
    'production'
    ? 'production'
    : 'test';

export function getActiveAdMobConfig(env: AdEnvironment = AD_ENVIRONMENT): AdMobUnitConfig {
  return env === 'production' ? PROD_ADMOB_CONFIG : TEST_ADMOB_CONFIG;
}

/**
 * Website (browser) advertising adapter configuration.
 * Disabled by default; never renders fake/simulated ads in the browser.
 * Only connect a real approved web ad SDK here if publishing web monetization.
 */
export const WEB_AD_CONFIG = {
  enabled: false,
  rewardedPlacementTag: '',
} as const;

/**
 * Frequency, session gating, and player-protection policies.
 */
export const AD_POLICY = {
  /** Show the first App Open Ad only after the player has launched the game a few times. */
  minSessionsBeforeFirstAppOpenAd: 3,
  /** Minimum interval between App Open Ads (4 minutes) to avoid annoyance. */
  appOpenCooldownMs: 4 * 60 * 1000,
  /** Maximum time splash waits for an already-ready App Open Ad check. */
  splashAdCheckTimeoutMs: 1200,
  /** Maximum extra hearts granted per single game-over event via Rewarded Ad. */
  maxExtraHeartsPerGameOver: 1,
  /** Maximum extra-heart revives permitted per single level attempt. */
  maxRevivesPerAttempt: 1,
} as const;
