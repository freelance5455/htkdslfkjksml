export type WeaponType = 'knife' | 'pistol' | 'smg' | 'rifle' | 'sniper' | 'shotgun' | 'lmg' | 'grenade';

export interface WeaponDef {
  id: string;
  name: string;
  en: string;
  type: WeaponType;
  slot: 0 | 1 | 2 | 3; // 0 primary, 1 secondary, 2 knife, 3 grenade
  damage: number;
  fireRate: number; // shots / sec
  mag: number;
  reserve: number;
  reload: number;
  spread: number; // radians base
  moveSpread: number;
  recoil: number; // radians pitch kick
  range: number;
  pellets?: number;
  auto: boolean;
  price: number;
  unlock: number; // coins (0 = free)
  scope?: number; // zoomed fov
  speedMul: number;
  snd: { f: number; d: number; n: number; boom: number };
  len: number; // model length
  armorPen: number;
}

export const WEAPONS: WeaponDef[] = [
  { id: 'knife', name: 'چاقو کارامبیت', en: 'KARAMBIT', type: 'knife', slot: 2, damage: 55, fireRate: 2.2, mag: 0, reserve: 0, reload: 0, spread: 0, moveSpread: 0, recoil: 0, range: 2.3, auto: true, price: 0, unlock: 0, speedMul: 1.12, snd: { f: 0, d: 0, n: 0, boom: 0 }, len: 0.3, armorPen: 1 },
  { id: 'glock', name: 'گلاک ۱۸', en: 'GLOCK-18', type: 'pistol', slot: 1, damage: 28, fireRate: 6.5, mag: 20, reserve: 120, reload: 2.0, spread: 0.012, moveSpread: 0.03, recoil: 0.018, range: 60, auto: false, price: 200, unlock: 0, speedMul: 1.05, snd: { f: 900, d: 0.12, n: 0.7, boom: 0.5 }, len: 0.22, armorPen: 0.47 },
  { id: 'usp', name: 'یو‌اس‌پی صدا‌خفه‌کن', en: 'USP-S', type: 'pistol', slot: 1, damage: 35, fireRate: 5.5, mag: 12, reserve: 72, reload: 2.1, spread: 0.008, moveSpread: 0.025, recoil: 0.02, range: 70, auto: false, price: 200, unlock: 0, speedMul: 1.05, snd: { f: 1800, d: 0.07, n: 0.3, boom: 0.15 }, len: 0.32, armorPen: 0.5 },
  { id: 'deagle', name: 'دیزرت ایگل', en: 'DESERT EAGLE', type: 'pistol', slot: 1, damage: 63, fireRate: 2.6, mag: 7, reserve: 35, reload: 2.2, spread: 0.01, moveSpread: 0.06, recoil: 0.06, range: 90, auto: false, price: 700, unlock: 800, speedMul: 1.0, snd: { f: 420, d: 0.25, n: 1, boom: 1 }, len: 0.28, armorPen: 0.93 },
  { id: 'mp5', name: 'ام‌پی ۵', en: 'MP5-SD', type: 'smg', slot: 0, damage: 26, fireRate: 12, mag: 30, reserve: 120, reload: 2.4, spread: 0.018, moveSpread: 0.025, recoil: 0.012, range: 55, auto: true, price: 1500, unlock: 0, speedMul: 1.0, snd: { f: 1300, d: 0.08, n: 0.5, boom: 0.3 }, len: 0.55, armorPen: 0.6 },
  { id: 'p90', name: 'پی ۹۰', en: 'P90', type: 'smg', slot: 0, damage: 24, fireRate: 14, mag: 50, reserve: 100, reload: 3.0, spread: 0.022, moveSpread: 0.025, recoil: 0.01, range: 50, auto: true, price: 2350, unlock: 1200, speedMul: 1.0, snd: { f: 1100, d: 0.08, n: 0.6, boom: 0.35 }, len: 0.5, armorPen: 0.69 },
  { id: 'nova', name: 'شاتگان نووا', en: 'NOVA', type: 'shotgun', slot: 0, damage: 22, fireRate: 1.1, mag: 8, reserve: 32, reload: 3.0, spread: 0.07, moveSpread: 0.02, recoil: 0.08, range: 25, pellets: 9, auto: false, price: 1050, unlock: 0, speedMul: 0.95, snd: { f: 300, d: 0.35, n: 1, boom: 1.2 }, len: 0.75, armorPen: 0.5 },
  { id: 'famas', name: 'فاماس', en: 'FAMAS', type: 'rifle', slot: 0, damage: 30, fireRate: 11, mag: 25, reserve: 90, reload: 3.1, spread: 0.01, moveSpread: 0.05, recoil: 0.016, range: 90, auto: true, price: 2050, unlock: 1500, speedMul: 0.92, snd: { f: 700, d: 0.12, n: 0.8, boom: 0.6 }, len: 0.62, armorPen: 0.7 },
  { id: 'ak47', name: 'کلاشینکف AK-47', en: 'AK-47', type: 'rifle', slot: 0, damage: 36, fireRate: 10, mag: 30, reserve: 90, reload: 2.5, spread: 0.008, moveSpread: 0.06, recoil: 0.022, range: 110, auto: true, price: 2700, unlock: 0, speedMul: 0.9, snd: { f: 520, d: 0.16, n: 1, boom: 0.85 }, len: 0.8, armorPen: 0.78 },
  { id: 'm4a1', name: 'ام‌۴‌اِی‌۱', en: 'M4A4', type: 'rifle', slot: 0, damage: 33, fireRate: 11, mag: 30, reserve: 90, reload: 3.0, spread: 0.007, moveSpread: 0.05, recoil: 0.017, range: 110, auto: true, price: 3100, unlock: 2500, speedMul: 0.92, snd: { f: 650, d: 0.13, n: 0.9, boom: 0.7 }, len: 0.78, armorPen: 0.7 },
  { id: 'scout', name: 'اسکات SSG', en: 'SSG 08', type: 'sniper', slot: 0, damage: 88, fireRate: 1.3, mag: 10, reserve: 40, reload: 3.4, spread: 0.002, moveSpread: 0.05, recoil: 0.05, range: 200, auto: false, price: 1700, unlock: 2000, scope: 22, speedMul: 1.0, snd: { f: 380, d: 0.3, n: 1, boom: 1.1 }, len: 0.95, armorPen: 0.85 },
  { id: 'awp', name: 'تک‌تیرانداز AWP', en: 'AWP', type: 'sniper', slot: 0, damage: 115, fireRate: 0.7, mag: 5, reserve: 30, reload: 3.6, spread: 0.0015, moveSpread: 0.12, recoil: 0.1, range: 250, auto: false, price: 4750, unlock: 4000, scope: 14, speedMul: 0.82, snd: { f: 220, d: 0.5, n: 1, boom: 1.6 }, len: 1.05, armorPen: 0.97 },
  { id: 'm249', name: 'مسلسل M249', en: 'M249', type: 'lmg', slot: 0, damage: 32, fireRate: 12, mag: 100, reserve: 200, reload: 5.0, spread: 0.02, moveSpread: 0.07, recoil: 0.014, range: 100, auto: true, price: 5200, unlock: 5000, speedMul: 0.8, snd: { f: 480, d: 0.15, n: 1, boom: 0.9 }, len: 0.9, armorPen: 0.8 },
  { id: 'he', name: 'نارنجک انفجاری', en: 'HE GRENADE', type: 'grenade', slot: 3, damage: 98, fireRate: 1, mag: 1, reserve: 0, reload: 0, spread: 0, moveSpread: 0, recoil: 0, range: 7, auto: false, price: 300, unlock: 0, speedMul: 1.05, snd: { f: 0, d: 0, n: 0, boom: 0 }, len: 0.1, armorPen: 0.6 },
];

export const W: Record<string, WeaponDef> = Object.fromEntries(WEAPONS.map(w => [w.id, w]));

export const TYPE_FA: Record<WeaponType, string> = {
  knife: 'سلاح سرد', pistol: 'کلت', smg: 'مسلسل دستی', rifle: 'تفنگ تهاجمی', sniper: 'تک‌تیرانداز', shotgun: 'شاتگان', lmg: 'مسلسل سنگین', grenade: 'نارنجک',
};

export const ARMS_RACE = ['glock', 'usp', 'deagle', 'mp5', 'p90', 'nova', 'famas', 'm4a1', 'ak47', 'm249', 'scout', 'awp', 'knife'];

export const SKIN_PRESETS: { name: string; skin: { c1: string; c2: string; c3: string; metal: boolean; pattern: 'solid' | 'stripes' | 'camo' | 'tiger' | 'digital' | 'hex' } }[] = [
  { name: 'کلاسیک', skin: { c1: '#3a3d42', c2: '#1c1d20', c3: '#5a4632', metal: false, pattern: 'solid' } },
  { name: 'ببر آبی', skin: { c1: '#1d7fe0', c2: '#f08a1c', c3: '#2a2a2a', metal: false, pattern: 'tiger' } },
  { name: 'آسیموف', skin: { c1: '#f2f2f2', c2: '#ff5a1f', c3: '#1a1a1a', metal: false, pattern: 'stripes' } },
  { name: 'صحرایی', skin: { c1: '#c8a46a', c2: '#7a5a32', c3: '#3b2a18', metal: false, pattern: 'camo' } },
  { name: 'زمستانی', skin: { c1: '#ffffff', c2: '#1e88ff', c3: '#111111', metal: false, pattern: 'digital' } },
  { name: 'طلایی', skin: { c1: '#ffcc33', c2: '#b8860b', c3: '#3a2a10', metal: true, pattern: 'solid' } },
  { name: 'اژدها', skin: { c1: '#b80f0f', c2: '#1a1a1a', c3: '#ffcc00', metal: true, pattern: 'hex' } },
  { name: 'جنگلی', skin: { c1: '#4b5d2a', c2: '#1f2a12', c3: '#2a1f12', metal: false, pattern: 'camo' } },
  { name: 'نئون', skin: { c1: '#16f2b3', c2: '#7a1cff', c3: '#0b0b0b', metal: true, pattern: 'digital' } },
];
