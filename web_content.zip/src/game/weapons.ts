export type WeaponId = 'pistol' | 'smg' | 'ar' | 'shotgun' | 'sniper';
export type AmmoType = 'light' | 'heavy' | 'shell';

export interface WeaponDef {
  id: WeaponId;
  name: string;
  ammo: AmmoType;
  mag: number;
  dmg: number;
  rate: number;
  reload: number;
  spread: number;
  range: number;
  auto: boolean;
  pellets: number;
  recoil: number;
  len: number;
  color: number;
  sound: 'pistol' | 'smg' | 'ar' | 'shotgun' | 'sniper';
}

export const WEAPONS: Record<WeaponId, WeaponDef> = {
  pistol: { id: 'pistol', name: 'Pistol 9', ammo: 'light', mag: 12, dmg: 24, rate: 0.3, reload: 1.3, spread: 0.012, range: 90, auto: false, pellets: 1, recoil: 0.5, len: 0.32, color: 0x3a3f47, sound: 'pistol' },
  smg: { id: 'smg', name: 'SMG-9', ammo: 'light', mag: 30, dmg: 17, rate: 0.075, reload: 1.8, spread: 0.03, range: 70, auto: true, pellets: 1, recoil: 0.35, len: 0.5, color: 0x2f4a33, sound: 'smg' },
  ar: { id: 'ar', name: 'Rifle AK', ammo: 'heavy', mag: 30, dmg: 26, rate: 0.11, reload: 2.2, spread: 0.02, range: 160, auto: true, pellets: 1, recoil: 0.6, len: 0.78, color: 0x6b4a2e, sound: 'ar' },
  shotgun: { id: 'shotgun', name: 'Shotgun 12', ammo: 'shell', mag: 6, dmg: 14, rate: 0.85, reload: 2.6, spread: 0.07, range: 40, auto: false, pellets: 7, recoil: 1.0, len: 0.8, color: 0x4a3d2d, sound: 'shotgun' },
  sniper: { id: 'sniper', name: 'Sniper 50', ammo: 'heavy', mag: 5, dmg: 96, rate: 1.3, reload: 2.8, spread: 0.002, range: 400, auto: false, pellets: 1, recoil: 1.2, len: 1.05, color: 0x1f2a33, sound: 'sniper' },
};

export const WEAPON_IDS = Object.keys(WEAPONS) as WeaponId[];
export const AMMO_PACK: Record<AmmoType, number> = { light: 60, heavy: 40, shell: 12 };
export const RESERVE_CAP: Record<AmmoType, number> = { light: 200, heavy: 120, shell: 48 };
export const AMMO_LABEL: Record<AmmoType, string> = { light: 'Light', heavy: 'Heavy', shell: 'Shell' };
