// Small math / random helpers shared across the game.

export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smoothstep = (t: number) => t * t * (3 - 2 * t);
export const damp = (a: number, b: number, lambda: number, dt: number) =>
  lerp(a, b, 1 - Math.exp(-lambda * dt));
export const TAU = Math.PI * 2;

export function angleLerp(a: number, b: number, t: number) {
  let d = ((b - a + Math.PI) % TAU + TAU) % TAU - Math.PI;
  return a + d * t;
}

export function angleDiff(a: number, b: number) {
  return ((b - a + Math.PI) % TAU + TAU) % TAU - Math.PI;
}

/** Deterministic 32 bit PRNG (mulberry32) so the world is identical each load. */
export function makeRng(seed: number) {
  let t = seed >>> 0;
  return function rng() {
    t += 0x6d2b79f5;
    let x = t;
    x = Math.imul(x ^ (x >>> 15), x | 1);
    x ^= x + Math.imul(x ^ (x >>> 7), x | 61);
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

export type Rng = () => number;

export const rand = (rng: Rng, a: number, b: number) => a + rng() * (b - a);
export const randInt = (rng: Rng, a: number, b: number) => Math.floor(a + rng() * (b - a + 1));
export const pick = <T,>(rng: Rng, arr: T[]) => arr[Math.floor(rng() * arr.length) % arr.length];
export const chance = (rng: Rng, p: number) => rng() < p;

export function dist2(ax: number, az: number, bx: number, bz: number) {
  const dx = ax - bx;
  const dz = az - bz;
  return dx * dx + dz * dz;
}

export function formatClock(hours: number) {
  const h = Math.floor(hours) % 24;
  const m = Math.floor((hours % 1) * 60);
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
}

export function formatMoney(v: number) {
  return '$' + Math.floor(v).toLocaleString('en-US');
}

export function formatDuration(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s
    .toString()
    .padStart(2, '0')}`;
}
