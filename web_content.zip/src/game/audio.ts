class SoundSynthesizer {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private volume: number = 0.5;

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
  }

  public getVolume(): number {
    return this.volume;
  }

  // Play a synthesized sound effect
  public play(name: string, pitchVariation: number = 0.08) {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const masterGain = this.ctx.createGain();
    masterGain.gain.setValueAtTime(this.volume, t);
    masterGain.connect(this.ctx.destination);

    const pitchMod = 1.0 + (Math.random() * 2 - 1) * pitchVariation;

    switch (name) {
      case 'slash': {
        // Crisp weapon slash
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(420 * pitchMod, t);
        osc.frequency.exponentialRampToValueAtTime(110 * pitchMod, t + 0.12);
        gain.gain.setValueAtTime(0.35, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.12);
        break;
      }

      case 'heavy_slash': {
        // Greatsword heavy impact
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(220 * pitchMod, t);
        osc.frequency.exponentialRampToValueAtTime(45 * pitchMod, t + 0.25);
        gain.gain.setValueAtTime(0.6, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.25);
        break;
      }

      case 'blunt_hit': {
        // Hammer impact / Stun
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(150 * pitchMod, t);
        osc.frequency.exponentialRampToValueAtTime(30 * pitchMod, t + 0.2);
        gain.gain.setValueAtTime(0.7, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.2);
        break;
      }

      case 'bow_fire': {
        // Arrow release twang
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(580 * pitchMod, t);
        osc.frequency.exponentialRampToValueAtTime(260 * pitchMod, t + 0.14);
        gain.gain.setValueAtTime(0.28, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.14);
        break;
      }

      case 'lance_poke': {
        // Metal pierce
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(340 * pitchMod, t);
        osc.frequency.exponentialRampToValueAtTime(140 * pitchMod, t + 0.1);
        gain.gain.setValueAtTime(0.25, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.1);
        break;
      }

      case 'guard_block': {
        // Metallic shield clatter
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(800 * pitchMod, t);
        osc.frequency.exponentialRampToValueAtTime(200 * pitchMod, t + 0.18);
        gain.gain.setValueAtTime(0.4, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.18);
        break;
      }

      case 'dodge_roll': {
        // Whoosh sound
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(160, t);
        osc.frequency.linearRampToValueAtTime(320, t + 0.08);
        osc.frequency.linearRampToValueAtTime(90, t + 0.2);
        gain.gain.setValueAtTime(0.2, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.2);
        break;
      }

      case 'monster_roar': {
        // Deep primal beast roar
        const osc = this.ctx.createOscillator();
        const osc2 = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc2.type = 'sawtooth';
        osc.frequency.setValueAtTime(110 * pitchMod, t);
        osc.frequency.linearRampToValueAtTime(180 * pitchMod, t + 0.3);
        osc.frequency.exponentialRampToValueAtTime(50 * pitchMod, t + 0.7);

        osc2.frequency.setValueAtTime(85 * pitchMod, t);
        osc2.frequency.linearRampToValueAtTime(130 * pitchMod, t + 0.3);
        osc2.frequency.exponentialRampToValueAtTime(40 * pitchMod, t + 0.7);

        gain.gain.setValueAtTime(0.5, t);
        gain.gain.linearRampToValueAtTime(0.65, t + 0.25);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.75);

        osc.connect(gain);
        osc2.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc2.start(t);
        osc.stop(t + 0.75);
        osc2.stop(t + 0.75);
        break;
      }

      case 'part_break': {
        // Dramatic metallic break chime & shatter
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(587.33, t); // D5
        osc.frequency.setValueAtTime(880, t + 0.1); // A5
        gain.gain.setValueAtTime(0.5, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.45);
        break;
      }

      case 'potion': {
        // Chug / healing shimmer
        const notes = [261.63, 329.63, 392.0, 523.25]; // C E G C
        notes.forEach((freq, idx) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, t + idx * 0.08);
          gain.gain.setValueAtTime(0.2, t + idx * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.08 + 0.2);
          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(t + idx * 0.08);
          osc.stop(t + idx * 0.08 + 0.2);
        });
        break;
      }

      case 'gather': {
        // Crisp item pickup chime
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, t); // C5
        osc.frequency.exponentialRampToValueAtTime(659.25, t + 0.12); // E5
        gain.gain.setValueAtTime(0.25, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.18);
        break;
      }

      case 'victory': {
        // Regal fanfare stinger
        const fanfare = [
          { f: 440, delay: 0, dur: 0.15 },
          { f: 440, delay: 0.15, dur: 0.15 },
          { f: 440, delay: 0.3, dur: 0.15 },
          { f: 554.37, delay: 0.45, dur: 0.35 },
          { f: 659.25, delay: 0.8, dur: 0.5 },
        ];
        fanfare.forEach((n) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(n.f, t + n.delay);
          gain.gain.setValueAtTime(0.4, t + n.delay);
          gain.gain.exponentialRampToValueAtTime(0.001, t + n.delay + n.dur);
          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(t + n.delay);
          osc.stop(t + n.delay + n.dur);
        });
        break;
      }

      case 'defeat': {
        // Somber low stinger
        const notes = [220, 207.65, 196.0, 185.0];
        notes.forEach((freq, idx) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(freq, t + idx * 0.25);
          gain.gain.setValueAtTime(0.35, t + idx * 0.25);
          gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.25 + 0.4);
          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(t + idx * 0.25);
          osc.stop(t + idx * 0.25 + 0.4);
        });
        break;
      }

      case 'player_hurt': {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(140, t);
        osc.frequency.exponentialRampToValueAtTime(60, t + 0.18);
        gain.gain.setValueAtTime(0.45, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.18);
        break;
      }

      case 'demon_mode': {
        // Dual blades burst activation
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(300, t);
        osc.frequency.linearRampToValueAtTime(700, t + 0.2);
        gain.gain.setValueAtTime(0.3, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.25);
        break;
      }

      case 'ui_click': {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, t);
        gain.gain.setValueAtTime(0.12, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(t);
        osc.stop(t + 0.05);
        break;
      }

      default:
        break;
    }
  }
}

export const sound = new SoundSynthesizer();
