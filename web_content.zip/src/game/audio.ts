class SoundEngine {
  private ctx: AudioContext | null = null;
  private muted = false;

  public isMuted(): boolean {
    return this.muted;
  }

  public setMuted(val: boolean): void {
    this.muted = val;
  }

  public toggleMute(): boolean {
    this.muted = !this.muted;
    return this.muted;
  }

  private ensureContext(): AudioContext | null {
    if (this.muted) return null;
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private tone(
    freqStart: number,
    freqEnd: number,
    duration: number,
    type: OscillatorType,
    volume: number,
    delay = 0
  ): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20, freqStart), now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), now + duration);

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(volume, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  private noise(duration: number, filterFreq: number, volume: number): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const sampleCount = Math.floor(ctx.sampleRate * duration);
    const buffer = ctx.createBuffer(1, sampleCount, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < sampleCount; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / sampleCount);
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = filterFreq;
    filter.Q.value = 1.4;

    const gain = ctx.createGain();
    const now = ctx.currentTime;
    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    source.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    source.start(now);
  }

  public playJump(): void {
    this.tone(180, 420, 0.11, 'triangle', 0.12);
  }

  public playDoubleJump(): void {
    this.tone(260, 620, 0.14, 'sine', 0.14);
    this.tone(420, 780, 0.09, 'triangle', 0.08, 0.03);
  }

  public playWallJump(): void {
    this.tone(220, 520, 0.1, 'triangle', 0.12);
    this.noise(0.06, 1600, 0.08);
  }

  public playDash(): void {
    this.noise(0.14, 1900, 0.14);
    this.tone(520, 140, 0.15, 'sawtooth', 0.09);
  }

  public playSlide(): void {
    this.noise(0.15, 950, 0.09);
  }

  public playGrapple(): void {
    this.tone(440, 980, 0.09, 'square', 0.07);
    this.tone(720, 1280, 0.11, 'sine', 0.1, 0.04);
  }

  public playSlash(overdrive = false): void {
    this.noise(0.09, overdrive ? 2600 : 2100, 0.15);
    this.tone(overdrive ? 680 : 480, 160, 0.09, 'sawtooth', 0.07);
  }

  public playHit(heavy = false): void {
    this.tone(heavy ? 140 : 190, 50, heavy ? 0.16 : 0.1, 'sawtooth', heavy ? 0.18 : 0.13);
    this.noise(0.07, 1400, 0.13);
  }

  public playPogo(): void {
    this.tone(360, 920, 0.12, 'triangle', 0.14);
    this.tone(720, 1180, 0.09, 'sine', 0.09, 0.02);
  }

  public playDamage(): void {
    this.tone(150, 48, 0.24, 'sawtooth', 0.2);
    this.tone(95, 40, 0.26, 'square', 0.12);
    this.noise(0.16, 650, 0.16);
  }

  public playHeal(): void {
    this.tone(440, 660, 0.14, 'sine', 0.11);
    this.tone(660, 880, 0.18, 'sine', 0.11, 0.07);
    this.tone(880, 1175, 0.24, 'triangle', 0.1, 0.14);
  }

  public playPickup(): void {
    this.tone(523, 659, 0.12, 'triangle', 0.12);
    this.tone(659, 1046, 0.22, 'sine', 0.12, 0.08);
  }

  public playAbilityUnlock(): void {
    const notes = [392, 523.25, 659.25, 783.99, 1046.5];
    notes.forEach((n, idx) => {
      this.tone(n, n * 1.02, 0.22, 'triangle', 0.12, idx * 0.07);
    });
  }

  public playTerminal(): void {
    this.tone(330, 495, 0.16, 'sine', 0.1);
    this.tone(495, 660, 0.22, 'sine', 0.1, 0.09);
  }

  public playBossWarning(): void {
    this.tone(110, 75, 0.45, 'sawtooth', 0.16);
    this.tone(116, 78, 0.45, 'sawtooth', 0.14, 0.12);
  }

  public playVictory(): void {
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5];
    notes.forEach((n, idx) => {
      this.tone(n, n, 0.32, 'sine', 0.13, idx * 0.1);
    });
  }
}

export const soundEngine = new SoundEngine();
