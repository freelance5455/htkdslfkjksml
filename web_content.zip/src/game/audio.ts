// Procedural Web Audio API sound synthesizer — zero external audio dependencies

export class TacticalAudio {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private ambientGain: GainNode | null = null;
  private ambientStarted = false;
  private enabled = true;
  private noiseBuffer: AudioBuffer | null = null;

  public setEnabled(val: boolean): void {
    this.enabled = val;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(val ? 0.72 : 0.0, this.ctx.currentTime, 0.04);
    }
  }

  public init(): void {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') {
        void this.ctx.resume();
      }
      return;
    }

    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    this.ctx = new AudioCtx();
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = this.enabled ? 0.72 : 0.0;
    this.masterGain.connect(this.ctx.destination);

    // Pre-generate 2 seconds of white noise for gunfire, footsteps, and room tails
    const sampleRate = this.ctx.sampleRate;
    const length = sampleRate * 2;
    this.noiseBuffer = this.ctx.createBuffer(1, length, sampleRate);
    const data = this.noiseBuffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    this.startAmbientHum();
  }

  private startAmbientHum(): void {
    if (!this.ctx || !this.masterGain || this.ambientStarted) return;
    this.ambientStarted = true;

    this.ambientGain = this.ctx.createGain();
    this.ambientGain.gain.value = 0.08;
    this.ambientGain.connect(this.masterGain);

    // Low industrial transformer drone (54 Hz + 108 Hz)
    const osc1 = this.ctx.createOscillator();
    osc1.type = 'sawtooth';
    osc1.frequency.value = 54;

    const osc2 = this.ctx.createOscillator();
    osc2.type = 'sine';
    osc2.frequency.value = 108.5;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 140;

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(this.ambientGain);

    osc1.start();
    osc2.start();

    // Subtle filtered ventilation air rush
    if (this.noiseBuffer) {
      const air = this.ctx.createBufferSource();
      air.buffer = this.noiseBuffer;
      air.loop = true;

      const bp = this.ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.value = 380;
      bp.Q.value = 1.4;

      const airGain = this.ctx.createGain();
      airGain.gain.value = 0.045;

      air.connect(bp);
      bp.connect(airGain);
      airGain.connect(this.masterGain);
      air.start();
    }
  }

  public playGunshot(): void {
    if (!this.enabled || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const t = this.ctx.currentTime;

    // 1. Sharp supersonic crack
    const crack = this.ctx.createBufferSource();
    crack.buffer = this.noiseBuffer;
    const crackFilter = this.ctx.createBiquadFilter();
    crackFilter.type = 'bandpass';
    crackFilter.frequency.setValueAtTime(2200, t);
    crackFilter.frequency.exponentialRampToValueAtTime(420, t + 0.14);
    crackFilter.Q.value = 0.7;

    const crackGain = this.ctx.createGain();
    crackGain.gain.setValueAtTime(0.95, t);
    crackGain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);

    crack.connect(crackFilter);
    crackFilter.connect(crackGain);
    crackGain.connect(this.masterGain);
    crack.start(t);
    crack.stop(t + 0.2);

    // 2. Chest-thump low transient
    const thump = this.ctx.createOscillator();
    thump.type = 'triangle';
    thump.frequency.setValueAtTime(145, t);
    thump.frequency.exponentialRampToValueAtTime(38, t + 0.09);

    const thumpGain = this.ctx.createGain();
    thumpGain.gain.setValueAtTime(0.7, t);
    thumpGain.gain.exponentialRampToValueAtTime(0.001, t + 0.11);

    thump.connect(thumpGain);
    thumpGain.connect(this.masterGain);
    thump.start(t);
    thump.stop(t + 0.12);

    // 3. Concrete corridor echo tail
    const tail = this.ctx.createBufferSource();
    tail.buffer = this.noiseBuffer;
    const tailFilter = this.ctx.createBiquadFilter();
    tailFilter.type = 'lowpass';
    tailFilter.frequency.setValueAtTime(950, t + 0.04);
    tailFilter.frequency.exponentialRampToValueAtTime(180, t + 0.65);

    const tailGain = this.ctx.createGain();
    tailGain.gain.setValueAtTime(0.001, t);
    tailGain.gain.linearRampToValueAtTime(0.24, t + 0.05);
    tailGain.gain.exponentialRampToValueAtTime(0.001, t + 0.72);

    tail.connect(tailFilter);
    tailFilter.connect(tailGain);
    tailGain.connect(this.masterGain);
    tail.start(t);
    tail.stop(t + 0.75);
  }

  public playEmptyClick(): void {
    if (!this.enabled || !this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.setValueAtTime(1100, t);
    osc.frequency.exponentialRampToValueAtTime(320, t + 0.025);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.18, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.03);

    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.035);
  }

  public playFlashlightClick(): void {
    if (!this.enabled || !this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1800, t);
    osc.frequency.exponentialRampToValueAtTime(650, t + 0.022);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.22, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.028);

    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.03);
  }

  public playReload(): void {
    if (!this.enabled || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const t = this.ctx.currentTime;
    const clicks = [0.05, 0.45, 0.85, 1.02];
    clicks.forEach((offset, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = idx >= 2 ? 'sawtooth' : 'triangle';
      osc.frequency.setValueAtTime(idx >= 2 ? 780 : 420, t + offset);
      osc.frequency.exponentialRampToValueAtTime(180, t + offset + 0.045);

      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.22, t + offset);
      g.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.05);

      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(t + offset);
      osc.stop(t + offset + 0.06);
    });
  }

  public playFootstep(sprinting: boolean): void {
    if (!this.enabled || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = sprinting ? 320 + Math.random() * 140 : 210 + Math.random() * 90;
    filter.Q.value = 1.6;

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(sprinting ? 0.22 : 0.12, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.085);

    src.connect(filter);
    filter.connect(g);
    g.connect(this.masterGain);
    src.start(t);
    src.stop(t + 0.09);
  }

  public playImpactSpark(isHostile: boolean): void {
    if (!this.enabled || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = isHostile ? 'sawtooth' : 'sine';
    osc.frequency.setValueAtTime(isHostile ? 980 : 1600, t);
    osc.frequency.exponentialRampToValueAtTime(isHostile ? 220 : 440, t + 0.08);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(isHostile ? 0.28 : 0.16, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.09);

    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.1);
  }

  public playObjectivePickup(): void {
    if (!this.enabled || !this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;
    const freqs = [587.33, 880.0, 1174.66];
    freqs.forEach((f, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = f;

      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.001, t + idx * 0.07);
      g.gain.linearRampToValueAtTime(0.18, t + idx * 0.07 + 0.015);
      g.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.07 + 0.25);

      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(t + idx * 0.07);
      osc.stop(t + idx * 0.07 + 0.26);
    });
  }

  public playDamageHit(): void {
    if (!this.enabled || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(110, t);
    osc.frequency.exponentialRampToValueAtTime(34, t + 0.22);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.55, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.24);

    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.25);
  }

  public dispose(): void {
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
    }
  }
}
