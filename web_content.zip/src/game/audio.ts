export const S = { sound: true, vib: true, shake: true, hq: !(typeof matchMedia !== 'undefined' && matchMedia('(pointer:coarse)').matches), q: 1 };
try { Object.assign(S, JSON.parse(localStorage.getItem('sw_set2') || '{}')); } catch { /* ignore */ }
export function saveS() { S.q = S.hq ? 1 : 0.5; try { localStorage.setItem('sw_set2', JSON.stringify({ sound: S.sound, vib: S.vib, shake: S.shake, hq: S.hq })); } catch { /* ignore */ } }
saveS();

let ctx: AudioContext | null = null; let noiseBuf: AudioBuffer | null = null; let budget = 0; let lastT = 0;
function ac() {
  if (!ctx) { try { ctx = new (window.AudioContext || (window as any).webkitAudioContext)(); } catch { return null; } }
  if (ctx.state === 'suspended') ctx.resume();
  if (!noiseBuf) { noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate); const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; }
  return ctx;
}
export function unlockAudio() { ac(); }
function noise(vol: number, dur: number, f0: number, f1: number) {
  const c = ac(); if (!c) return; const s = c.createBufferSource(); s.buffer = noiseBuf!; const fl = c.createBiquadFilter(); fl.type = 'lowpass';
  fl.frequency.setValueAtTime(f0, c.currentTime); fl.frequency.exponentialRampToValueAtTime(f1, c.currentTime + dur);
  const g = c.createGain(); g.gain.setValueAtTime(vol, c.currentTime); g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + dur);
  s.connect(fl); fl.connect(g); g.connect(c.destination); s.start(); s.stop(c.currentTime + dur);
}
function tone(f0: number, f1: number, vol: number, dur: number, type: OscillatorType = 'square') {
  const c = ac(); if (!c) return; const o = c.createOscillator(); o.type = type; o.frequency.setValueAtTime(f0, c.currentTime); o.frequency.exponentialRampToValueAtTime(f1, c.currentTime + dur);
  const g = c.createGain(); g.gain.setValueAtTime(vol, c.currentTime); g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + dur); o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime + dur);
}
export function sfx(k: string, vol = 1) {
  if (!S.sound) return; const now = performance.now(); if (now - lastT > 100) { budget = 0; lastT = now; } if (++budget > 6) return;
  switch (k) {
    case 'boom': noise(0.5 * vol, 0.7, 900, 60); tone(90, 30, 0.35 * vol, 0.5, 'sine'); break;
    case 'big': noise(0.7 * vol, 1.1, 700, 40); tone(70, 25, 0.5 * vol, 0.9, 'sine'); break;
    case 'bullet': noise(0.07 * vol, 0.07, 4000, 800); break;
    case 'arrow': noise(0.05 * vol, 0.12, 5000, 2500); break;
    case 'shell': noise(0.3 * vol, 0.25, 1800, 200); tone(180, 50, 0.2 * vol, 0.2); break;
    case 'rocket': noise(0.2 * vol, 0.5, 2500, 300); break;
    case 'click': tone(700, 500, 0.08, 0.06); break;
    case 'ok': tone(500, 900, 0.1, 0.12, 'triangle'); break;
    case 'bad': tone(200, 120, 0.12, 0.15); break;
    case 'win': tone(400, 800, 0.15, 0.5, 'triangle'); break;
  }
}
export function vibrate(ms: number) { if (S.vib && navigator.vibrate) { try { navigator.vibrate(ms); } catch { /* ignore */ } } }
