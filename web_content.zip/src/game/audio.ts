export type AudioBus = ReturnType<typeof createAudio>;

export function createAudio() {
  let ctx: AudioContext | null = null;
  let muted = false;
  let engine: { osc: OscillatorNode; gain: GainNode } | null = null;

  function ac() {
    if (!ctx) ctx = new AudioContext();
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  }

  function noiseBurst(dur: number, freq: number, gainV: number, type: BiquadFilterType) {
    if (muted || !ctx) return;
    const c = ctx;
    const n = c.createBuffer(1, Math.max(1, Math.floor(c.sampleRate * dur)), c.sampleRate);
    const data = n.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    const src = c.createBufferSource();
    src.buffer = n;
    const f = c.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    const g = c.createGain();
    g.gain.value = gainV;
    src.connect(f);
    f.connect(g);
    g.connect(c.destination);
    src.start();
  }

  function tone(freq: number, dur: number, type: OscillatorType, gainV: number, slide = 0) {
    if (muted || !ctx) return;
    const c = ctx;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, c.currentTime);
    const destF = Math.max(40, freq + slide);
    if (slide) o.frequency.exponentialRampToValueAtTime(destF, c.currentTime + dur);
    g.gain.setValueAtTime(gainV, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + dur);
    o.connect(g);
    g.connect(c.destination);
    o.start();
    o.stop(c.currentTime + dur + 0.02);
  }

  return {
    unlock() {
      try {
        ac();
      } catch {
        /* autoplay */
      }
    },
    toggle() {
      muted = !muted;
      if (muted && engine) engine.gain.gain.value = 0;
      return !muted;
    },
    soundOn() {
      return !muted;
    },
    rifle() {
      noiseBurst(0.05, 2400, 0.16, "bandpass");
      tone(160, 0.04, "square", 0.03);
    },
    cannon() {
      noiseBurst(0.26, 220, 0.42, "lowpass");
      tone(96, 0.28, "sine", 0.18, -50);
    },
    boom() {
      noiseBurst(0.34, 160, 0.38, "lowpass");
      tone(64, 0.26, "sine", 0.12, -24);
    },
    hit() {
      tone(1280, 0.045, "square", 0.045);
    },
    hurt() {
      tone(128, 0.12, "sawtooth", 0.05);
    },
    empty() {
      tone(210, 0.04, "square", 0.035);
    },
    reload() {
      tone(420, 0.06, "sine", 0.04);
    },
    wave() {
      tone(523, 0.09, "triangle", 0.06);
    },
    engine(amount: number) {
      if (!ctx || muted) {
        if (engine) engine.gain.gain.value = 0;
        return;
      }
      const c = ctx;
      if (!engine) {
        const osc = c.createOscillator();
        const gain = c.createGain();
        const f = c.createBiquadFilter();
        osc.type = "sawtooth";
        osc.frequency.value = 46;
        gain.gain.value = 0;
        f.type = "lowpass";
        f.frequency.value = 160;
        osc.connect(f);
        f.connect(gain);
        gain.connect(c.destination);
        osc.start();
        engine = { osc, gain };
      }
      const target = Math.max(0, Math.min(0.07, amount));
      engine.gain.gain.setTargetAtTime(target, c.currentTime, 0.08);
      engine.osc.frequency.setTargetAtTime(40 + amount * 80, c.currentTime, 0.08);
    },
    dispose() {
      try {
        void ctx?.close();
      } catch {
        /* already closed */
      }
      ctx = null;
      engine = null;
    },
  };
}
