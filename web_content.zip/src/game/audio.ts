let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let muted = false;

function context() {
  if (ctx) return ctx;
  const AC =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AC) return null;
  ctx = new AC();
  master = ctx.createGain();
  master.gain.value = muted ? 0 : 0.18;
  master.connect(ctx.destination);
  return ctx;
}

export function unlockAudio() {
  const audio = context();
  if (audio && audio.state === "suspended") void audio.resume();
}

export function resumeAudio() {
  if (ctx && ctx.state === "suspended") void ctx.resume();
}

export function setAudioMuted(next: boolean) {
  muted = next;
  if (!ctx || !master) return;
  master.gain.setTargetAtTime(next ? 0 : 0.18, ctx.currentTime, 0.02);
}

function tone(freq: number, when: number, dur: number, type: OscillatorType, gain: number) {
  if (!ctx || !master) return;
  const osc = ctx.createOscillator();
  const amp = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, when);
  amp.gain.setValueAtTime(0.0001, when);
  amp.gain.exponentialRampToValueAtTime(gain, when + 0.015);
  amp.gain.exponentialRampToValueAtTime(0.0001, when + dur);
  osc.connect(amp);
  amp.connect(master);
  osc.start(when);
  osc.stop(when + dur + 0.02);
  osc.onended = () => {
    osc.disconnect();
    amp.disconnect();
  };
}

export type Sfx = "tick" | "note" | "fail" | "open" | "hint";

export function playSfx(kind: Sfx) {
  const audio = context();
  if (!audio || !master || muted || audio.state !== "running") return;
  const t = audio.currentTime + 0.01;
  if (kind === "tick") tone(740, t, 0.05, "sine", 0.2);
  if (kind === "note") tone(520, t, 0.09, "triangle", 0.18);
  if (kind === "hint") {
    tone(494, t, 0.1, "sine", 0.16);
    tone(740, t + 0.09, 0.12, "sine", 0.14);
  }
  if (kind === "fail") tone(140, t, 0.16, "square", 0.08);
  if (kind === "open") {
    tone(392, t, 0.12, "triangle", 0.18);
    tone(494, t + 0.1, 0.12, "triangle", 0.18);
    tone(587, t + 0.2, 0.18, "triangle", 0.16);
    tone(784, t + 0.32, 0.28, "sine", 0.14);
  }
}
