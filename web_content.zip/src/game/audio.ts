/** Короткие синтетические звуки. Без файлов, контекст открывается жестом. */

export class Sound {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private sfx: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  enabled = true;
  volume = 0.7;
  private voices = 0;
  private lastShot = 0;

  unlock() {
    const Ctx =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    if (!this.ctx) {
      this.ctx = new Ctx({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.sfx = this.ctx.createGain();
      this.sfx.connect(this.master);
      this.master.connect(this.ctx.destination);
      const n = this.ctx.createBuffer(1, Math.floor(this.ctx.sampleRate * 0.25), this.ctx.sampleRate);
      const d = n.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      this.noise = n;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    this.apply();
  }

  setVolume(v: number) {
    this.volume = Math.max(0, Math.min(1, v));
    this.apply();
  }

  private apply() {
    if (!this.master || !this.ctx) return;
    const g = this.enabled ? this.volume * this.volume : 0;
    this.master.gain.setTargetAtTime(g, this.ctx.currentTime, 0.02);
  }

  setEnabled(on: boolean) {
    this.enabled = on;
    this.apply();
  }

  private can() {
    return Boolean(this.ctx && this.sfx && this.enabled && this.volume > 0.01 && this.voices < 16);
  }

  private tone(freq: number, dur: number, type: OscillatorType, gain: number, slide = 0) {
    if (!this.can() || !this.ctx || !this.sfx) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(this.sfx);
    o.start(t);
    o.stop(t + dur + 0.02);
    this.voices++;
    o.onended = () => {
      this.voices = Math.max(0, this.voices - 1);
      o.disconnect();
      g.disconnect();
    };
  }

  private burst(dur: number, gain: number, freq: number) {
    if (!this.can() || !this.ctx || !this.sfx || !this.noise) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(freq, t);
    filter.Q.value = 0.7;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filter);
    filter.connect(g);
    g.connect(this.sfx);
    src.start(t);
    src.stop(t + dur + 0.02);
    this.voices++;
    src.onended = () => {
      this.voices = Math.max(0, this.voices - 1);
      src.disconnect();
      filter.disconnect();
      g.disconnect();
    };
  }

  ui() {
    this.tone(520, 0.06, "sine", 0.05);
  }

  order() {
    this.tone(340, 0.07, "triangle", 0.045, 80);
  }

  shot() {
    const now = performance.now();
    if (now - this.lastShot < 70) return;
    this.lastShot = now;
    this.burst(0.09, 0.08, 900 + Math.random() * 600);
    this.tone(180 + Math.random() * 40, 0.05, "square", 0.02);
  }

  capture() {
    this.tone(392, 0.12, "sine", 0.06, 80);
    this.tone(523, 0.18, "triangle", 0.05, 60);
  }

  lost() {
    this.tone(220, 0.2, "sawtooth", 0.03, -80);
  }

  warn() {
    this.tone(160, 0.16, "square", 0.04);
  }

  win() {
    this.tone(392, 0.14, "sine", 0.06);
    this.tone(494, 0.16, "sine", 0.05);
    this.tone(587, 0.28, "triangle", 0.06);
  }

  defeat() {
    this.tone(196, 0.28, "triangle", 0.05, -60);
    this.tone(146, 0.36, "sine", 0.04, -30);
  }

  resumeOnFocus() {
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  close() {
    void this.ctx?.close();
    this.ctx = null;
  }
}
