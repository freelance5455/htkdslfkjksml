export class EngineAudio {
  private ctx: AudioContext | null = null;
  private osc: OscillatorNode | null = null;
  private grind: OscillatorNode | null = null;
  private gain: GainNode | null = null;
  private grindGain: GainNode | null = null;
  private filter: BiquadFilterNode | null = null;
  muted = false;

  unlock(): void {
    if (!this.ctx) {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      osc.type = "sawtooth";
      const grind = ctx.createOscillator();
      grind.type = "square";
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 420;
      const gain = ctx.createGain();
      const grindGain = ctx.createGain();
      gain.gain.value = 0.0001;
      grindGain.gain.value = 0.0001;
      osc.connect(filter);
      filter.connect(gain);
      grind.connect(grindGain);
      gain.connect(ctx.destination);
      grindGain.connect(ctx.destination);
      osc.start();
      grind.start();
      this.ctx = ctx;
      this.osc = osc;
      this.grind = grind;
      this.gain = gain;
      this.grindGain = grindGain;
      this.filter = filter;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(muted: boolean): void {
    this.muted = muted;
    if (muted && this.gain && this.grindGain && this.ctx) {
      const t = this.ctx.currentTime;
      this.gain.gain.setTargetAtTime(0.0001, t, 0.05);
      this.grindGain.gain.setTargetAtTime(0.0001, t, 0.05);
    }
  }

  update(speed: number, drift: boolean, boost: boolean): void {
    if (!this.ctx || !this.osc || !this.grind || !this.gain || !this.grindGain || !this.filter) return;
    const t = this.ctx.currentTime;
    const s = Math.abs(speed);
    const freq = 48 + s * 2.4 + (boost ? 28 : 0);
    this.osc.frequency.setTargetAtTime(freq, t, 0.08);
    this.grind.frequency.setTargetAtTime(30 + s * 1.4, t, 0.08);
    this.filter.frequency.setTargetAtTime(boost ? 1400 : 520 + s * 18, t, 0.1);
    const vol = this.muted ? 0.0001 : Math.min(0.045, 0.008 + s * 0.0009);
    this.gain.gain.setTargetAtTime(vol, t, 0.08);
    const g = this.muted || !drift ? 0.0001 : Math.min(0.03, 0.012 + s * 0.0004);
    this.grindGain.gain.setTargetAtTime(g, t, 0.05);
  }

  dispose(): void {
    void this.ctx?.close();
    this.ctx = null;
  }
}
