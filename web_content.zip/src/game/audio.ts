class GameAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private ambientStarted = false;
  muted = false;

  private ensure(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (!this.ctx) {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return null;
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.65;
      this.master.connect(this.ctx.destination);
      const length = Math.floor(this.ctx.sampleRate * 1.2);
      const buffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
      this.noise = buffer;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(muted ? 0 : 0.65, this.ctx.currentTime, 0.08);
    }
  }

  unlock() {
    this.ensure();
  }

  startAmbient() {
    const ctx = this.ensure();
    if (!ctx || !this.master || !this.noise || this.ambientStarted) return;
    this.ambientStarted = true;
    const source = ctx.createBufferSource();
    source.buffer = this.noise;
    source.loop = true;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 420;
    const gain = ctx.createGain();
    gain.gain.value = 0.045;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.11;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 0.025;
    lfo.connect(lfoGain).connect(gain.gain);
    source.connect(filter).connect(gain).connect(this.master);
    source.start();
    lfo.start();
  }

  private noiseBurst(duration: number, gainValue: number, filterFreq: number, type: BiquadFilterType = "lowpass") {
    const ctx = this.ensure();
    if (!ctx || !this.master || !this.noise) return;
    const now = ctx.currentTime;
    const source = ctx.createBufferSource();
    source.buffer = this.noise;
    source.playbackRate.value = 0.8 + Math.random() * 0.4;
    const filter = ctx.createBiquadFilter();
    filter.type = type;
    filter.frequency.setValueAtTime(filterFreq, now);
    filter.frequency.exponentialRampToValueAtTime(Math.max(80, filterFreq * 0.2), now + duration);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(gainValue, now + 0.006);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    source.connect(filter).connect(gain).connect(this.master);
    source.start(now);
    source.stop(now + duration + 0.02);
  }

  private tone(freq: number, duration: number, volume: number, type: OscillatorType = "sine", endFreq?: number) {
    const ctx = this.ensure();
    if (!ctx || !this.master) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    if (endFreq) osc.frequency.exponentialRampToValueAtTime(endFreq, now + duration);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(gain).connect(this.master);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  shot() {
    this.noiseBurst(0.34, 0.5, 3400);
    this.noiseBurst(0.5, 0.18, 900);
    this.tone(105, 0.28, 0.3, "sine", 42);
  }

  hit() {
    this.tone(880, 0.09, 0.11, "triangle", 1320);
    setTimeout(() => this.tone(560, 0.12, 0.07, "sine"), 60);
  }

  miss() {
    this.noiseBurst(0.16, 0.06, 1100, "bandpass");
  }

  dry() {
    this.tone(220, 0.05, 0.08, "square");
  }

  reload() {
    setTimeout(() => this.noiseBurst(0.05, 0.1, 2200, "bandpass"), 80);
    setTimeout(() => this.tone(300, 0.05, 0.08, "square"), 760);
    setTimeout(() => this.noiseBurst(0.06, 0.12, 1600, "bandpass"), 1420);
  }

  ui() {
    this.tone(640, 0.045, 0.035, "sine", 760);
  }

  complete(success: boolean) {
    if (success) {
      [392, 494, 587, 784].forEach((f, i) => setTimeout(() => this.tone(f, 0.7, 0.07, "sine"), i * 130));
    } else {
      [294, 247, 196].forEach((f, i) => setTimeout(() => this.tone(f, 0.8, 0.06, "sine"), i * 180));
    }
  }
}

export const sound = new GameAudio();
