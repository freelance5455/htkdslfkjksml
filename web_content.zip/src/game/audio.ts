/* Synthesised street-food soundscape — no external audio assets. */

type Ctx = AudioContext;

class Sfx {
  ctx: Ctx | null = null;
  master: GainNode | null = null;
  ambBus: GainNode | null = null;
  noiseBuf: AudioBuffer | null = null;
  muted = false;
  private ambTimer: number | null = null;
  private ambNodes: AudioNode[] = [];

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    try {
      const AC: typeof AudioContext =
        window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AC();
      this.ctx = ctx;
      const master = ctx.createGain();
      master.gain.value = this.muted ? 0 : 0.9;
      master.connect(ctx.destination);
      this.master = master;
      const amb = ctx.createGain();
      amb.gain.value = 0;
      amb.connect(master);
      this.ambBus = amb;

      const len = Math.floor(ctx.sampleRate * 2);
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = buf.getChannelData(0);
      let last = 0;
      for (let i = 0; i < len; i++) {
        const w = Math.random() * 2 - 1;
        last = (last + 0.02 * w) / 1.02;
        d[i] = last * 3.2;
      }
      this.noiseBuf = buf;
    } catch {
      this.ctx = null;
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.05);
    }
    try {
      localStorage.setItem("sft_muted", m ? "1" : "0");
    } catch {
      /* ignore */
    }
  }

  loadMuted() {
    try {
      this.muted = localStorage.getItem("sft_muted") === "1";
    } catch {
      this.muted = false;
    }
  }

  private t() {
    return this.ctx ? this.ctx.currentTime : 0;
  }

  private tone(
    freq: number,
    dur: number,
    type: OscillatorType = "sine",
    vol = 0.22,
    delay = 0,
    slideTo?: number,
  ) {
    const ctx = this.ctx;
    if (!ctx || !this.master) return;
    const t0 = this.t() + delay;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(40, slideTo), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + Math.min(0.02, dur * 0.3));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(this.master);
    o.start(t0);
    o.stop(t0 + dur + 0.05);
  }

  private noise(dur: number, vol: number, freq: number, type: BiquadFilterType = "bandpass", delay = 0, q = 1) {
    const ctx = this.ctx;
    if (!ctx || !this.master || !this.noiseBuf) return;
    const t0 = this.t() + delay;
    const s = ctx.createBufferSource();
    s.buffer = this.noiseBuf;
    s.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(freq, t0);
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    s.connect(f);
    f.connect(g);
    g.connect(this.master);
    s.start(t0);
    s.stop(t0 + dur + 0.05);
  }

  /** ingredient tap — pentatonic pluck that climbs with the recipe step */
  tap(step: number) {
    const scale = [523.25, 587.33, 659.25, 783.99, 880, 1046.5];
    const f = scale[Math.min(scale.length - 1, step)];
    this.tone(f, 0.13, "triangle", 0.2);
    this.tone(f * 2, 0.07, "sine", 0.08);
    this.noise(0.06, 0.06, 2400, "bandpass", 0, 2);
  }

  error() {
    this.tone(150, 0.28, "sawtooth", 0.16, 0, 70);
    this.noise(0.2, 0.12, 380, "lowpass");
  }

  complete() {
    [659.25, 830.6, 987.77].forEach((f, i) => this.tone(f, 0.18, "triangle", 0.18, i * 0.055));
    this.noise(0.3, 0.06, 3200, "highpass", 0.05);
  }

  coin(big = false) {
    this.tone(1174.66, 0.09, "square", 0.1);
    this.tone(1567.98, big ? 0.3 : 0.16, "square", 0.09, 0.06);
    if (big) [2093, 2637, 3136].forEach((f, i) => this.tone(f, 0.22, "sine", 0.07, 0.12 + i * 0.06));
  }

  /** rickshaw ting-ting */
  bell() {
    this.tone(2100, 0.35, "triangle", 0.07);
    this.tone(2640, 0.3, "triangle", 0.05, 0.09);
  }

  angry() {
    this.tone(320, 0.35, "sawtooth", 0.14, 0, 110);
    this.noise(0.3, 0.1, 700, "lowpass");
  }

  whoosh() {
    this.noise(0.26, 0.09, 900, "bandpass", 0, 0.8);
  }

  click() {
    this.tone(420, 0.05, "square", 0.06);
  }

  levelUp() {
    [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((f, i) =>
      this.tone(f, 0.3, "triangle", 0.16, i * 0.075),
    );
  }

  fail() {
    [440, 370, 294, 220].forEach((f, i) => this.tone(f, 0.42, "sawtooth", 0.13, i * 0.14));
  }

  fanfare() {
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => this.tone(f, 0.35, "square", 0.11, i * 0.1));
    this.tone(1318.5, 0.7, "triangle", 0.14, 0.45);
    this.noise(0.5, 0.07, 5000, "highpass", 0.45);
  }

  dhol() {
    this.tone(120, 0.22, "sine", 0.28, 0, 55);
    this.noise(0.14, 0.14, 1800, "bandpass", 0, 1.2);
    this.tone(150, 0.18, "sine", 0.2, 0.16, 70);
  }

  /** ambient street loop: crowd murmur + occasional horn/bell */
  ambient(on: boolean) {
    const ctx = this.ctx;
    if (!ctx || !this.ambBus) return;
    if (this.ambTimer !== null) {
      window.clearTimeout(this.ambTimer);
      this.ambTimer = null;
    }
    this.ambNodes.forEach((n) => {
      try {
        (n as OscillatorNode).stop?.();
        n.disconnect();
      } catch {
        /* ignore */
      }
    });
    this.ambNodes = [];
    this.ambBus.gain.setTargetAtTime(on && !this.muted ? 0.5 : 0, ctx.currentTime, 0.6);
    if (!on || !this.noiseBuf) return;

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 520;
    const g = ctx.createGain();
    g.gain.value = 0.3;
    src.connect(lp);
    lp.connect(g);
    g.connect(this.ambBus);
    src.start();
    this.ambNodes.push(src, lp, g);

    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.13;
    const lfoG = ctx.createGain();
    lfoG.gain.value = 130;
    lfo.connect(lfoG);
    lfoG.connect(lp.frequency);
    lfo.start();
    this.ambNodes.push(lfo, lfoG);

    const chirp = () => {
      if (!this.ambBus) return;
      const r = Math.random();
      if (r < 0.45) this.bell();
      else if (r < 0.72) this.tone(392 + Math.random() * 120, 0.4, "sawtooth", 0.025, 0, 300);
      else this.noise(0.5, 0.02, 200 + Math.random() * 300, "bandpass", 0, 0.6);
      this.ambTimer = window.setTimeout(chirp, 3200 + Math.random() * 5200);
    };
    this.ambTimer = window.setTimeout(chirp, 1600);
  }

  pauseAmbient(paused: boolean) {
    if (!this.ctx || !this.ambBus) return;
    this.ambBus.gain.setTargetAtTime(paused || this.muted ? 0 : 0.5, this.ctx.currentTime, 0.2);
  }
}

export const sfx = new Sfx();
