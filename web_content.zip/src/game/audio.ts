// Tiny procedural SFX synth built on the Web Audio API.
class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  muted = false;

  unlock() {
    if (!this.ctx) {
      try {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 0.5;
        this.master.connect(this.ctx.destination);
        const len = this.ctx.sampleRate * 0.5;
        this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
        const d = this.noiseBuf.getChannelData(0);
        for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      } catch {
        this.ctx = null;
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') void this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.5, this.ctx.currentTime, 0.02);
    }
  }

  private tone(
    freq: number,
    dur: number,
    opts: { type?: OscillatorType; vol?: number; slideTo?: number; delay?: number; attack?: number } = {},
  ) {
    if (!this.ctx || !this.master || this.muted) return;
    const { type = 'sine', vol = 0.3, slideTo, delay = 0, attack = 0.005 } = opts;
    const t0 = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g).connect(this.master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }

  private noise(dur: number, opts: { vol?: number; freq?: number; q?: number; delay?: number; type?: BiquadFilterType } = {}) {
    if (!this.ctx || !this.master || !this.noiseBuf || this.muted) return;
    const { vol = 0.25, freq = 1200, q = 0.8, delay = 0, type = 'bandpass' } = opts;
    const t0 = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    f.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t0);
    src.stop(t0 + dur + 0.02);
  }

  coin(streak = 0) {
    const base = 880 * Math.pow(1.0595, Math.min(streak, 12));
    this.tone(base, 0.09, { type: 'square', vol: 0.08 });
    this.tone(base * 1.5, 0.16, { type: 'square', vol: 0.08, delay: 0.06 });
  }

  correct() {
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((n, i) => this.tone(n, 0.28, { type: 'triangle', vol: 0.22, delay: i * 0.07 }));
    this.tone(1568, 0.5, { type: 'sine', vol: 0.12, delay: 0.3 });
    this.noise(0.4, { vol: 0.08, freq: 5000, q: 0.5, delay: 0.25, type: 'highpass' });
  }

  wrong() {
    this.tone(220, 0.35, { type: 'sawtooth', vol: 0.18, slideTo: 70 });
    this.tone(233, 0.35, { type: 'square', vol: 0.1, slideTo: 60 });
    this.noise(0.25, { vol: 0.2, freq: 400, q: 0.6 });
  }

  hit() {
    this.noise(0.2, { vol: 0.35, freq: 250, q: 0.5, type: 'lowpass' });
    this.tone(90, 0.25, { type: 'sine', vol: 0.35, slideTo: 40 });
  }

  jump() {
    this.tone(320, 0.14, { type: 'sine', vol: 0.18, slideTo: 640 });
  }

  land() {
    this.tone(120, 0.08, { type: 'sine', vol: 0.15, slideTo: 60 });
  }

  swipe() {
    this.noise(0.06, { vol: 0.12, freq: 2200, q: 1 });
  }

  boost() {
    this.noise(0.45, { vol: 0.14, freq: 900, q: 0.4, type: 'highpass' });
    this.tone(200, 0.4, { type: 'sine', vol: 0.1, slideTo: 900 });
  }

  combo(level: number) {
    const base = 660 + level * 60;
    this.tone(base, 0.12, { type: 'triangle', vol: 0.16 });
    this.tone(base * 1.25, 0.18, { type: 'triangle', vol: 0.16, delay: 0.08 });
  }

  life() {
    [659, 880, 1319].forEach((n, i) => this.tone(n, 0.3, { type: 'sine', vol: 0.18, delay: i * 0.09 }));
  }

  gameover() {
    [440, 392, 349, 262].forEach((n, i) => this.tone(n, 0.5, { type: 'triangle', vol: 0.2, delay: i * 0.18 }));
    this.tone(131, 1.2, { type: 'sawtooth', vol: 0.08, delay: 0.6 });
  }

  start() {
    [392, 523, 659, 784].forEach((n, i) => this.tone(n, 0.2, { type: 'square', vol: 0.08, delay: i * 0.06 }));
    this.noise(0.5, { vol: 0.1, freq: 1500, q: 0.4, type: 'highpass' });
  }

  click() {
    this.tone(700, 0.05, { type: 'square', vol: 0.06 });
  }
}

export const audio = new AudioEngine();
