type EngineNodes = {
  o1: OscillatorNode;
  o2: OscillatorNode;
  filter: BiquadFilterNode;
  gain: GainNode;
};

export type Sfx = {
  unlock: () => void;
  engine: (speed: number, throttle: number, on: boolean) => void;
  gun: (kind: string) => void;
  step: () => void;
  reload: () => void;
  door: () => void;
  crash: (intensity: number) => void;
  horn: () => void;
  siren: () => void;
  scream: () => void;
  hurt: () => void;
  chime: () => void;
  explode: () => void;
  skid: () => void;
  thunder: () => void;
  radio: (station: number, step: number) => void;
};

export function createSfx(): Sfx {
  let ctx: AudioContext | null = null;
  let master: GainNode | null = null;
  let noise: AudioBuffer | null = null;
  let eng: EngineNodes | null = null;
  let lastSkid = 0;

  function unlock() {
    if (typeof window === "undefined") return;
    if (!ctx) {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return;
      ctx = new Ctor();
      master = ctx.createGain();
      master.gain.value = 0.42;
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -16;
      comp.ratio.value = 6;
      master.connect(comp);
      comp.connect(ctx.destination);
      const len = ctx.sampleRate;
      noise = ctx.createBuffer(1, len, ctx.sampleRate);
      const data = noise.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      const o1 = ctx.createOscillator();
      const o2 = ctx.createOscillator();
      o1.type = "sawtooth";
      o1.frequency.value = 40;
      o2.type = "square";
      o2.frequency.value = 20;
      const mix = ctx.createGain();
      mix.gain.value = 0.5;
      o1.connect(mix);
      o2.connect(mix);
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 520;
      filter.Q.value = 2.2;
      mix.connect(filter);
      const gain = ctx.createGain();
      gain.gain.value = 0;
      filter.connect(gain);
      gain.connect(master);
      o1.start();
      o2.start();
      eng = { o1, o2, filter, gain };
    }
    if (ctx.state === "suspended") void ctx.resume();
  }

  function tone(freq: number, dur: number, type: OscillatorType, vol: number, slide?: number) {
    if (!ctx || !master) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(Math.max(1, freq), t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(1, slide), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  function burst(dur: number, freq: number, q: number, vol: number) {
    if (!ctx || !master || !noise) return;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = noise;
    const filter = ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = freq;
    filter.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filter);
    filter.connect(g);
    g.connect(master);
    src.start(t);
    src.stop(t + dur + 0.02);
  }

  return {
    unlock,
    engine(speed, throttle, on) {
      if (!eng || !ctx) return;
      const t = ctx.currentTime;
      if (!on) {
        eng.gain.gain.setTargetAtTime(0.0001, t, 0.12);
        return;
      }
      const s = Math.abs(speed);
      const hz = 38 + s * 2.4 + Math.abs(throttle) * 18;
      eng.o1.frequency.setTargetAtTime(hz, t, 0.05);
      eng.o2.frequency.setTargetAtTime(hz * 0.5, t, 0.05);
      eng.filter.frequency.setTargetAtTime(420 + Math.min(1600, s * 30), t, 0.08);
      eng.gain.gain.setTargetAtTime(0.035 + Math.min(0.1, s * 0.003), t, 0.08);
    },
    gun(kind) {
      if (kind === "pistol") {
        burst(0.08, 1400, 1.4, 0.2);
        tone(200, 0.08, "sine", 0.16, 60);
      } else if (kind === "smg") {
        burst(0.04, 2000, 2, 0.12);
        tone(240, 0.04, "sine", 0.08, 80);
      } else if (kind === "rpg") {
        burst(0.32, 280, 0.6, 0.34);
        tone(90, 0.4, "sawtooth", 0.22, 24);
      } else {
        burst(0.2, 680, 0.8, 0.28);
        tone(140, 0.18, "sawtooth", 0.16, 40);
      }
    },
    step() {
      burst(0.04, 420 + Math.random() * 220, 3, 0.06);
    },
    reload() {
      burst(0.03, 2400, 4, 0.05);
      window.setTimeout(() => burst(0.04, 1700, 4, 0.07), 160);
      window.setTimeout(() => burst(0.05, 2800, 5, 0.05), 360);
    },
    door() {
      burst(0.1, 480, 1.4, 0.14);
      tone(90, 0.1, "square", 0.08, 40);
    },
    crash(intensity) {
      const i = Math.max(0, Math.min(1, intensity));
      burst(0.16 + i * 0.28, 380, 0.7, Math.min(0.34, 0.08 + i * 0.22));
      tone(100, 0.16 + i * 0.25, "sawtooth", Math.min(0.16, 0.05 + i * 0.1), 32);
    },
    horn() {
      if (!ctx || !master) return;
      const t = ctx.currentTime;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.06, t);
      g.gain.setValueAtTime(0.06, t + 0.28);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.4);
      g.connect(master);
      for (const f of [196, 262]) {
        const o = ctx.createOscillator();
        o.type = "square";
        o.frequency.value = f;
        o.connect(g);
        o.start(t);
        o.stop(t + 0.42);
      }
    },
    siren() {
      tone(740, 0.28, "sawtooth", 0.018, 520);
      window.setTimeout(() => tone(520, 0.28, "sawtooth", 0.018, 740), 300);
    },
    scream() {
      const base = 560 + Math.random() * 280;
      tone(base, 0.22, "sawtooth", 0.04, base + 180);
    },
    hurt() {
      tone(180, 0.14, "sine", 0.1, 55);
    },
    chime() {
      tone(660, 0.12, "sine", 0.08, 880);
      window.setTimeout(() => tone(880, 0.14, "sine", 0.08, 1320), 130);
    },
    explode() {
      burst(0.45, 220, 0.45, 0.36);
      tone(70, 0.5, "sawtooth", 0.18, 22);
    },
    skid() {
      const n = performance.now();
      if (n - lastSkid < 140) return;
      lastSkid = n;
      burst(0.12, 900, 2.4, 0.05);
    },
    thunder() {
      burst(0.7, 90, 0.4, 0.22);
      tone(50, 0.6, "sine", 0.08, 30);
    },
    radio(station, step) {
      if (station <= 0) return;
      const bases = [0, 110, 98, 87];
      const pats = [
        [],
        [0, 7, 3, 10, 0, 3, 7, 12],
        [0, 3, 7, 10, 12, 10, 7, 3],
        [0, 0, 5, 7, 10, 7, 3, 0],
      ];
      const pat = pats[station] ?? pats[1]!;
      const note = pat[step % pat.length] ?? 0;
      const freq = (bases[station] ?? 110) * Math.pow(2, note / 12);
      tone(freq, station === 3 ? 0.22 : 0.16, station === 2 ? "sine" : "triangle", 0.035);
      if (step % 2 === 0) tone(freq / 2, 0.18, "sine", 0.02);
    },
  };
}
