import type { ExhaustType, WeatherCondition } from './types';

export class MotoAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private engineOsc: OscillatorNode | null = null;
  private subOsc: OscillatorNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private engineGain: GainNode | null = null;

  private rainGain: GainNode | null = null;
  private rainSource: AudioBufferSourceNode | null = null;

  private muted = false;
  private started = false;
  private exhaustType: ExhaustType = 'original';
  private lastLimiterPop = 0;

  public init(): void {
    if (this.started) {
      if (this.ctx && this.ctx.state === 'suspended') {
        void this.ctx.resume();
      }
      return;
    }

    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    try {
      const ctx = new AudioCtx();
      this.ctx = ctx;

      const master = ctx.createGain();
      master.gain.value = this.muted ? 0 : 0.35;
      master.connect(ctx.destination);
      this.masterGain = master;

      // 160cc single-cylinder 4-stroke exhaust oscillator pair
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 340;
      filter.Q.value = 3.2;

      const engGain = ctx.createGain();
      engGain.gain.value = 0;

      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.value = 26;

      const sub = ctx.createOscillator();
      sub.type = 'triangle';
      sub.frequency.value = 13;

      osc.connect(filter);
      sub.connect(filter);
      filter.connect(engGain);
      engGain.connect(master);

      osc.start();
      sub.start();

      this.engineOsc = osc;
      this.subOsc = sub;
      this.engineFilter = filter;
      this.engineGain = engGain;

      // Procedural rain noise buffer
      const bufferSize = ctx.sampleRate * 2;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const rainSrc = ctx.createBufferSource();
      rainSrc.buffer = noiseBuffer;
      rainSrc.loop = true;

      const rainFilter = ctx.createBiquadFilter();
      rainFilter.type = 'bandpass';
      rainFilter.frequency.value = 1450;
      rainFilter.Q.value = 0.7;

      const rainGain = ctx.createGain();
      rainGain.gain.value = 0;

      rainSrc.connect(rainFilter);
      rainFilter.connect(rainGain);
      rainGain.connect(master);
      rainSrc.start();

      this.rainSource = rainSrc;
      this.rainGain = rainGain;
      this.started = true;
    } catch {
      // Ignore audio block until user interaction
    }
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(muted ? 0 : 0.35, this.ctx.currentTime, 0.05);
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public setExhaustType(exhaust: ExhaustType): void {
    this.exhaustType = exhaust;
  }

  public playStarterCrank(): void {
    this.init();
    if (!this.ctx || !this.masterGain) return;

    const now = this.ctx.currentTime;
    for (let i = 0; i < 4; i++) {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(165 + i * 12, now + i * 0.11);
      osc.frequency.exponentialRampToValueAtTime(110, now + i * 0.11 + 0.08);
      g.gain.setValueAtTime(0.14, now + i * 0.11);
      g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.11 + 0.09);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now + i * 0.11);
      osc.stop(now + i * 0.11 + 0.095);
    }
  }

  public playHorn(): void {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(420, now);
    g.gain.setValueAtTime(0.18, now);
    g.gain.setValueAtTime(0.18, now + 0.15);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.25);
  }

  public playCrash(): void {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(130, now);
    osc.frequency.exponentialRampToValueAtTime(34, now + 0.28);
    g.gain.setValueAtTime(0.4, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.32);
  }

  public playMissionSuccess(): void {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.08);
      g.gain.setValueAtTime(0.18, now + idx * 0.08);
      g.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.24);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now + idx * 0.08);
      osc.stop(now + idx * 0.08 + 0.26);
    });
  }

  public update(
    rpm: number,
    engineOn: boolean,
    throttle: boolean,
    speedKmh: number,
    weather: WeatherCondition,
    isScraping: boolean
  ): void {
    if (!this.started || !this.ctx || !this.engineOsc || !this.subOsc || !this.engineFilter || !this.engineGain || !this.rainGain) {
      return;
    }

    const now = this.ctx.currentTime;

    if (!engineOn) {
      this.engineGain.gain.setTargetAtTime(0, now, 0.06);
    } else {
      // Single cylinder firing frequency: (RPM / 60) / 2 * harmonics
      const baseHz = Math.max(16, (rpm / 60) * 0.65);
      let exhaustBoost = 1;
      let filterHz = 280 + (rpm / 10000) * 900;

      if (this.exhaustType === 'dore') {
        exhaustBoost = 1.28;
        filterHz += 260;
      } else if (this.exhaustType === 'trioval') {
        exhaustBoost = 1.18;
        filterHz += 180;
      } else if (this.exhaustType === 'direto') {
        exhaustBoost = 1.45;
        filterHz += 520;
      }

      // Rev limiter "corte de giro" at ~140 km/h or >9600 RPM
      let limiterJitter = 1;
      if (speedKmh >= 138.5 || rpm > 9550) {
        if (now - this.lastLimiterPop > 0.065) {
          this.lastLimiterPop = now;
        }
        limiterJitter = Math.sin(now * 85) > 0 ? 1.08 : 0.72;
      }

      this.engineOsc.frequency.setTargetAtTime(baseHz * 1.95 * limiterJitter, now, 0.03);
      this.subOsc.frequency.setTargetAtTime(baseHz * 0.98 * limiterJitter, now, 0.03);
      this.engineFilter.frequency.setTargetAtTime(
        filterHz + (throttle ? 240 : 0) + (isScraping ? 300 : 0),
        now,
        0.04
      );

      const loadGain = (0.09 + (throttle ? 0.085 : 0.02) + (rpm / 10000) * 0.07) * exhaustBoost;
      this.engineGain.gain.setTargetAtTime(Math.min(0.28, loadGain), now, 0.04);
    }

    const targetRain = weather === 'chuva' ? 0.14 : 0;
    this.rainGain.gain.setTargetAtTime(targetRain, now, 0.35);
  }

  public dispose(): void {
    try {
      this.engineOsc?.stop();
      this.subOsc?.stop();
      this.rainSource?.stop();
      void this.ctx?.close();
    } catch {
      // Ignore cleanup errors
    }
    this.started = false;
  }
}
