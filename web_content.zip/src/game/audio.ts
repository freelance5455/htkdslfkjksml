export class GameAudio {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  sfx: GainNode | null = null;
  music: GainNode | null = null;
  sfxVol = 0.7;
  musicVol = 0.35;
  muted = false;
  private musicTimer = 0;
  private hum: OscillatorNode | null = null;
  private humGain: GainNode | null = null;

  unlock(): void {
    if (!this.ctx) {
      const C = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new C({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.sfx = this.ctx.createGain();
      this.music = this.ctx.createGain();
      this.sfx.connect(this.master);
      this.music.connect(this.master);
      this.master.connect(this.ctx.destination);
      this.applyVol();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    this.startHum();
  }

  applyVol(): void {
    if (!this.master || !this.sfx || !this.music || !this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.muted ? 0 : 1, t, 0.02);
    this.sfx.gain.setTargetAtTime(this.sfxVol * this.sfxVol, t, 0.02);
    this.music.gain.setTargetAtTime(this.musicVol * this.musicVol * 0.45, t, 0.04);
  }

  private startHum(): void {
    if (!this.ctx || !this.music || this.hum) return;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = 92;
    g.gain.value = 0.04;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 240;
    osc.connect(f);
    f.connect(g);
    g.connect(this.music);
    osc.start();
    this.hum = osc;
    this.humGain = g;
  }

  beep(freq: number, dur = 0.08, type: OscillatorType = "square", gain = 0.08): void {
    if (!this.ctx || !this.sfx) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.value = freq * (0.97 + Math.random() * 0.06);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(this.sfx);
    o.start(t);
    o.stop(t + dur + 0.02);
    o.onended = () => {
      o.disconnect();
      g.disconnect();
    };
  }

  noise(dur = 0.12, gain = 0.05): void {
    if (!this.ctx || !this.sfx) return;
    const n = this.ctx.createBuffer(1, this.ctx.sampleRate * dur, this.ctx.sampleRate);
    const d = n.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
    const src = this.ctx.createBufferSource();
    src.buffer = n;
    const g = this.ctx.createGain();
    g.gain.value = gain;
    const f = this.ctx.createBiquadFilter();
    f.type = "highpass";
    f.frequency.value = 400;
    src.connect(f);
    f.connect(g);
    g.connect(this.sfx);
    src.start();
    src.onended = () => {
      src.disconnect();
      g.disconnect();
      f.disconnect();
    };
  }

  register(): void {
    this.beep(880, 0.07, "square", 0.07);
    setTimeout(() => this.beep(1320, 0.09, "square", 0.06), 70);
  }
  scan(): void {
    this.beep(1400, 0.04, "square", 0.05);
  }
  coin(): void {
    this.beep(980, 0.08, "triangle", 0.07);
    setTimeout(() => this.beep(1320, 0.12, "triangle", 0.06), 80);
  }
  error(): void {
    this.beep(220, 0.14, "sawtooth", 0.05);
  }
  chime(): void {
    this.beep(523, 0.1, "sine", 0.05);
    setTimeout(() => this.beep(659, 0.12, "sine", 0.045), 90);
  }
  step(): void {
    this.noise(0.05, 0.03);
  }
  trash(): void {
    this.noise(0.1, 0.06);
  }

  tickMusic(dt: number): void {
    this.musicTimer += dt;
    if (this.musicTimer < 2.4) return;
    this.musicTimer = 0;
    if (!this.ctx || !this.music) return;
    const notes = [262, 330, 392, 330, 294, 392, 440, 392];
    const n = notes[Math.floor(Math.random() * notes.length)] ?? 330;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = "sine";
    o.frequency.value = n / 2;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.035, t + 0.04);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
    o.connect(g);
    g.connect(this.music);
    o.start(t);
    o.stop(t + 1);
  }

  dispose(): void {
    try {
      this.hum?.stop();
      this.hum?.disconnect();
      void this.ctx?.close();
    } catch {
      /* ignore */
    }
    this.ctx = null;
    this.hum = null;
  }
}
