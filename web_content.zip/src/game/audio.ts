type Bus = {
  ctx: AudioContext;
  master: GainNode;
  sfx: GainNode;
};

function noiseBuffer(ctx: AudioContext, seconds: number): AudioBuffer {
  const n = Math.floor(ctx.sampleRate * seconds);
  const buf = ctx.createBuffer(1, n, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < n; i++) data[i] = Math.random() * 2 - 1;
  return buf;
}

export class GameAudio {
  private bus: Bus | null = null;
  private noise: AudioBuffer | null = null;
  private muted = false;
  private lastStep = 0;

  unlock() {
    if (!this.bus) {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new Ctor({ latencyHint: "interactive" });
      const master = ctx.createGain();
      const sfx = ctx.createGain();
      sfx.gain.value = 0.9;
      master.gain.value = this.muted ? 0 : 0.7;
      sfx.connect(master);
      master.connect(ctx.destination);
      this.bus = { ctx, master, sfx };
      this.noise = noiseBuffer(ctx, 0.4);
    }
    if (this.bus.ctx.state === "suspended") {
      void this.bus.ctx.resume();
    }
  }

  resume() {
    if (this.bus?.ctx.state === "suspended") void this.bus.ctx.resume();
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (!this.bus) return;
    this.bus.master.gain.setTargetAtTime(muted ? 0 : 0.7, this.bus.ctx.currentTime, 0.02);
  }

  private env(gain: GainNode, peak: number, attack: number, decay: number) {
    if (!this.bus) return;
    const t = this.bus.ctx.currentTime;
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(peak, t + attack);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
  }

  gunshot() {
    const bus = this.bus;
    if (!bus || !this.noise) return;
    const t = bus.ctx.currentTime;
    const src = bus.ctx.createBufferSource();
    src.buffer = this.noise;
    src.playbackRate.value = 0.9 + Math.random() * 0.25;
    const filter = bus.ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(2400, t);
    filter.frequency.exponentialRampToValueAtTime(280, t + 0.14);
    const g = bus.ctx.createGain();
    this.env(g, 0.9, 0.004, 0.16);
    src.connect(filter);
    filter.connect(g);
    g.connect(bus.sfx);
    src.start(t);
    src.stop(t + 0.2);

    const osc = bus.ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.setValueAtTime(130 + Math.random() * 20, t);
    osc.frequency.exponentialRampToValueAtTime(38, t + 0.18);
    const og = bus.ctx.createGain();
    this.env(og, 0.55, 0.003, 0.18);
    osc.connect(og);
    og.connect(bus.sfx);
    osc.start(t);
    osc.stop(t + 0.22);
  }

  empty() {
    const bus = this.bus;
    if (!bus) return;
    const t = bus.ctx.currentTime;
    const osc = bus.ctx.createOscillator();
    osc.type = "square";
    osc.frequency.value = 190;
    const g = bus.ctx.createGain();
    this.env(g, 0.12, 0.001, 0.05);
    osc.connect(g);
    g.connect(bus.sfx);
    osc.start(t);
    osc.stop(t + 0.06);
  }

  reload() {
    const bus = this.bus;
    if (!bus) return;
    const t = bus.ctx.currentTime;
    for (let i = 0; i < 3; i++) {
      const osc = bus.ctx.createOscillator();
      osc.type = "triangle";
      osc.frequency.value = 420 - i * 70;
      const g = bus.ctx.createGain();
      const start = t + i * 0.09;
      g.gain.setValueAtTime(0.0001, start);
      g.gain.exponentialRampToValueAtTime(0.18, start + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, start + 0.08);
      osc.connect(g);
      g.connect(bus.sfx);
      osc.start(start);
      osc.stop(start + 0.1);
    }
  }

  hit() {
    const bus = this.bus;
    if (!bus || !this.noise) return;
    const t = bus.ctx.currentTime;
    const src = bus.ctx.createBufferSource();
    src.buffer = this.noise;
    const filter = bus.ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 900;
    const g = bus.ctx.createGain();
    this.env(g, 0.35, 0.002, 0.08);
    src.connect(filter);
    filter.connect(g);
    g.connect(bus.sfx);
    src.start(t);
    src.stop(t + 0.1);
  }

  hurt() {
    const bus = this.bus;
    if (!bus) return;
    const t = bus.ctx.currentTime;
    const osc = bus.ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(180, t);
    osc.frequency.exponentialRampToValueAtTime(70, t + 0.22);
    const g = bus.ctx.createGain();
    this.env(g, 0.18, 0.01, 0.22);
    const filter = bus.ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 500;
    osc.connect(filter);
    filter.connect(g);
    g.connect(bus.sfx);
    osc.start(t);
    osc.stop(t + 0.25);
  }

  groan() {
    const bus = this.bus;
    if (!bus) return;
    const t = bus.ctx.currentTime;
    const osc = bus.ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(90 + Math.random() * 40, t);
    osc.frequency.exponentialRampToValueAtTime(55, t + 0.5);
    const filter = bus.ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 280;
    const g = bus.ctx.createGain();
    this.env(g, 0.1, 0.04, 0.45);
    osc.connect(filter);
    filter.connect(g);
    g.connect(bus.sfx);
    osc.start(t);
    osc.stop(t + 0.55);
  }

  kill() {
    const bus = this.bus;
    if (!bus) return;
    const t = bus.ctx.currentTime;
    const osc = bus.ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.setValueAtTime(70, t);
    osc.frequency.exponentialRampToValueAtTime(32, t + 0.28);
    const g = bus.ctx.createGain();
    this.env(g, 0.28, 0.01, 0.28);
    osc.connect(g);
    g.connect(bus.sfx);
    osc.start(t);
    osc.stop(t + 0.3);
  }

  wave() {
    const bus = this.bus;
    if (!bus) return;
    const t = bus.ctx.currentTime;
    const osc = bus.ctx.createOscillator();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(220, t);
    osc.frequency.exponentialRampToValueAtTime(330, t + 0.35);
    const g = bus.ctx.createGain();
    this.env(g, 0.16, 0.02, 0.4);
    osc.connect(g);
    g.connect(bus.sfx);
    osc.start(t);
    osc.stop(t + 0.42);
  }

  footstep(now: number) {
    if (now - this.lastStep < 0.38) return;
    this.lastStep = now;
    const bus = this.bus;
    if (!bus || !this.noise) return;
    const t = bus.ctx.currentTime;
    const src = bus.ctx.createBufferSource();
    src.buffer = this.noise;
    src.playbackRate.value = 0.5 + Math.random() * 0.2;
    const filter = bus.ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 500;
    const g = bus.ctx.createGain();
    this.env(g, 0.08, 0.005, 0.07);
    src.connect(filter);
    filter.connect(g);
    g.connect(bus.sfx);
    src.start(t);
    src.stop(t + 0.09);
  }
}
