import { STORAGE_KEYS } from './constants';
import type { WeaponId } from './weapons';
import { WEAPONS } from './weapons';

const VOLUME = 0.5;

/** Synthesized sound effects (Web Audio). No asset files: gunshots, hits, pickups, zone warnings. */
export class Sfx {
  private ctx: AudioContext | null = null;
  private out: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private lastShot = 0;
  enabled: boolean;

  constructor() {
    let muted = false;
    try {
      muted = localStorage.getItem(STORAGE_KEYS.muted) === '1';
    } catch {
      /* storage unavailable */
    }
    this.enabled = !muted;
  }

  unlock() {
    if (!this.ctx) {
      const AC =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      const ctx = new AC();
      const out = ctx.createGain();
      out.gain.value = this.enabled ? VOLUME : 0;
      out.connect(ctx.destination);
      const len = ctx.sampleRate;
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      this.ctx = ctx;
      this.out = out;
      this.noise = buf;
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume();
  }

  setEnabled(on: boolean) {
    this.enabled = on;
    try {
      localStorage.setItem(STORAGE_KEYS.muted, on ? '0' : '1');
    } catch {
      /* ignore */
    }
    if (this.out && this.ctx) this.out.gain.setTargetAtTime(on ? VOLUME : 0, this.ctx.currentTime, 0.02);
  }

  private ready(): boolean {
    return !!this.ctx && !!this.out && !!this.noise && this.enabled && this.ctx.state === 'running';
  }

  private tone(type: OscillatorType, f0: number, f1: number, delay: number, dur: number, vol: number) {
    if (!this.ready()) return;
    const ctx = this.ctx!;
    const t = ctx.currentTime + delay;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(this.out!);
    o.start(t);
    o.stop(t + dur + 0.03);
  }

  private burst(delay: number, dur: number, vol: number, f0: number, f1: number) {
    if (!this.ready()) return;
    const ctx = this.ctx!;
    const t = ctx.currentTime + delay;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    const flt = ctx.createBiquadFilter();
    flt.type = 'lowpass';
    flt.frequency.setValueAtTime(f0, t);
    flt.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(flt);
    flt.connect(g);
    g.connect(this.out!);
    src.start(t, Math.random() * 0.5);
    src.stop(t + dur + 0.02);
  }

  /** gain 0..1 lets distant shots be quieter. */
  shot(id: WeaponId, gain = 1) {
    const now = this.ctx?.currentTime ?? 0;
    const sound = WEAPONS[id].sound;
    if (sound !== 'sniper' && now - this.lastShot < 0.03) return;
    this.lastShot = now;
    const g = Math.max(0.05, Math.min(1, gain));
    switch (sound) {
      case 'pistol':
        this.burst(0, 0.12, 0.35 * g, 2600, 300);
        this.tone('square', 220, 90, 0, 0.06, 0.05 * g);
        break;
      case 'smg':
        this.burst(0, 0.07, 0.3 * g, 2200, 400);
        this.tone('square', 260, 110, 0, 0.04, 0.04 * g);
        break;
      case 'ar':
        this.burst(0, 0.1, 0.4 * g, 2400, 300);
        this.tone('sawtooth', 150, 60, 0, 0.09, 0.05 * g);
        break;
      case 'shotgun':
        this.burst(0, 0.24, 0.6 * g, 1800, 150);
        this.tone('sine', 110, 35, 0, 0.25, 0.25 * g);
        break;
      case 'sniper':
        this.burst(0, 0.35, 0.6 * g, 1400, 90);
        this.tone('sine', 90, 30, 0, 0.4, 0.3 * g);
        break;
    }
  }

  reload() {
    this.tone('square', 1400, 1400, 0, 0.03, 0.06);
    this.tone('square', 900, 900, 0.28, 0.03, 0.06);
  }

  hitConfirm(head: boolean) {
    if (head) {
      this.tone('triangle', 1400, 1800, 0, 0.08, 0.15);
      this.tone('triangle', 1800, 2200, 0.06, 0.08, 0.12);
    } else {
      this.tone('triangle', 900, 700, 0, 0.06, 0.1);
    }
  }

  hurt() {
    this.tone('sawtooth', 240, 60, 0, 0.25, 0.14);
    this.burst(0, 0.15, 0.2, 800, 200);
  }

  pickup() {
    [660, 880, 1100].forEach((f, i) => this.tone('triangle', f, f * 1.01, i * 0.05, 0.1, 0.12));
  }

  heal() {
    [520, 660, 780].forEach((f, i) => this.tone('sine', f, f * 1.02, i * 0.08, 0.16, 0.12));
  }

  zoneWarn() {
    this.tone('square', 660, 660, 0, 0.15, 0.06);
  }

  win() {
    [523, 659, 784, 1046].forEach((f, i) => this.tone('square', f, f, i * 0.12, 0.3, 0.07));
  }

  lose() {
    this.tone('sawtooth', 330, 55, 0, 0.9, 0.16);
  }

  start() {
    [392, 523, 659].forEach((f, i) => this.tone('square', f, f, i * 0.07, 0.12, 0.05));
  }
}
