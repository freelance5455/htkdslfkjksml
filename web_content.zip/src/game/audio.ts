/* ============================================================
   MEME SURVIVORS — procedural Web Audio engine
   Chiptune music sequencer + synthesized SFX. No assets.
   ============================================================ */

type SfxName =
  | 'shoot_blaster' | 'shoot_shotgun' | 'shoot_laser' | 'shoot_plasma'
  | 'shoot_rocket' | 'shoot_dual' | 'shoot_tesla' | 'shoot_homing'
  | 'hit' | 'kill' | 'xp' | 'levelup' | 'pick' | 'hurt' | 'explode'
  | 'boss_roar' | 'warn' | 'jump' | 'dash' | 'click' | 'heal' | 'wave' | 'victory' | 'gameover';

const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

/* Song A — bouncy happy loop (C–G–Am–F), 64 sixteenths */
const LEAD_A = [
  72, 0, 76, 0, 79, 0, 76, 0, 81, 0, 79, 0, 76, 0, 72, 0,
  74, 0, 78, 0, 81, 0, 78, 0, 83, 0, 81, 0, 78, 0, 74, 0,
  76, 0, 79, 0, 84, 0, 81, 0, 79, 0, 76, 0, 72, 0, 76, 0,
  77, 0, 81, 0, 84, 0, 86, 0, 84, 0, 81, 0, 77, 0, 81, 0,
];
const BASS_ROOT_A = [36, 43, 45, 41]; // C2 G2 A2 F2

/* Song B — boss battle (A minor, driving), 64 sixteenths */
const LEAD_B = [
  69, 0, 72, 69, 0, 76, 0, 75, 76, 0, 72, 0, 69, 0, 68, 69,
  70, 0, 74, 70, 0, 77, 0, 76, 77, 0, 74, 0, 70, 0, 69, 0,
  69, 0, 72, 69, 0, 76, 0, 79, 80, 0, 79, 76, 0, 75, 76, 0,
  74, 0, 77, 74, 0, 78, 0, 77, 76, 0, 74, 71, 0, 68, 0, 69,
];
const BASS_ROOT_B = [33, 33, 29, 31]; // A1 A1 F1 G1

export class AudioEngine {
  ctx: AudioContext | null = null;
  private master!: GainNode;
  private sfxG!: GainNode;
  private musG!: GainNode;
  private noiseBuf!: AudioBuffer;
  muted = false;
  musicVol = 0.6; sfxVol = 0.8;
  mode: 'off' | 'normal' | 'boss' = 'off';
  private step = 0;
  private nextT = 0;
  private timer = 0;
  private xpPitch = 0;
  private xpReset = 0;

  init() {
    if (this.ctx) { this.ctx.resume(); return; }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AC();
    this.master = this.ctx.createGain(); this.master.connect(this.ctx.destination);
    this.sfxG = this.ctx.createGain(); this.sfxG.connect(this.master);
    this.musG = this.ctx.createGain(); this.musG.connect(this.master);
    this.applyVolumes();
    // noise buffer
    const len = this.ctx.sampleRate * 1;
    this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.nextT = this.ctx.currentTime + 0.1;
    this.timer = window.setInterval(() => this.schedule(), 40);
  }
  applyVolumes() {
    if (!this.ctx) return;
    this.master.gain.value = this.muted ? 0 : 1;
    this.sfxG.gain.value = this.sfxVol * 0.9;
    this.musG.gain.value = this.musicVol * 0.42;
  }
  setVolumes(music: number, sfx: number, muted: boolean) {
    this.musicVol = music; this.sfxVol = sfx; this.muted = muted; this.applyVolumes();
  }
  setMode(m: 'off' | 'normal' | 'boss') { this.mode = m; this.step = 0; }

  /* ---------- chiptune sequencer ---------- */
  private schedule() {
    if (!this.ctx || this.mode === 'off' || this.muted) return;
    const bpm = this.mode === 'boss' ? 156 : 138;
    const stepDur = 60 / bpm / 4;
    while (this.nextT < this.ctx.currentTime + 0.14) {
      this.playStep(this.step, this.nextT, stepDur);
      this.nextT += stepDur;
      this.step = (this.step + 1) % 64;
    }
  }
  private tone(freq: number, t: number, dur: number, type: OscillatorType, vol: number, dest?: AudioNode, slideTo?: number) {
    if (!this.ctx) return;
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(dest || this.sfxG);
    o.start(t); o.stop(t + dur + 0.02);
  }
  private noise(t: number, dur: number, vol: number, from: number, to: number, type: BiquadFilterType = 'lowpass') {
    if (!this.ctx) return;
    const s = this.ctx.createBufferSource(); s.buffer = this.noiseBuf; s.loop = true;
    const f = this.ctx.createBiquadFilter(); f.type = type;
    f.frequency.setValueAtTime(from, t); f.frequency.exponentialRampToValueAtTime(Math.max(30, to), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f); f.connect(g); g.connect(this.sfxG);
    s.start(t); s.stop(t + dur + 0.02);
  }
  private playStep(s: number, t: number, dur: number) {
    const boss = this.mode === 'boss';
    const lead = boss ? LEAD_B : LEAD_A;
    const roots = boss ? BASS_ROOT_B : BASS_ROOT_A;
    const bar = Math.floor(s / 16), six = s % 16;
    const n = lead[s];
    if (n) this.tone(mtof(n), t, dur * 1.7, 'square', boss ? 0.16 : 0.13, this.musG);
    const root = roots[bar];
    if (six % 4 === 0) this.tone(mtof(root), t, dur * 2.4, 'triangle', 0.3, this.musG);
    if (six === 8) this.tone(mtof(root + 7), t, dur * 2, 'triangle', 0.24, this.musG);
    if (six === 12) this.tone(mtof(root + (boss ? 3 : 12)), t, dur * 1.6, 'triangle', 0.2, this.musG);
    // drums
    if (six % 8 === 0) this.drum('kick', t);
    if (six === 8 && bar % 2 === 1) this.drum('kick', t);
    if (six === 4 || six === 12) this.drum('snare', t);
    if (six % 2 === 0) this.drum('hat', t, six % 4 === 0 ? 0.05 : 0.03);
  }
  private drum(kind: 'kick' | 'snare' | 'hat', t: number, v = 1) {
    if (!this.ctx) return;
    if (kind === 'kick') this.tone(120, t, 0.12, 'sine', 0.5 * v, this.musG, 40);
    else if (kind === 'snare') this.noiseDrum(t, 0.09, 0.14 * v, 1800);
    else this.noiseDrum(t, 0.03, 0.08 * v, 7000, 'highpass');
  }
  private noiseDrum(t: number, dur: number, vol: number, freq: number, type: BiquadFilterType = 'bandpass') {
    if (!this.ctx) return;
    const s = this.ctx.createBufferSource(); s.buffer = this.noiseBuf; s.loop = true;
    const f = this.ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f); f.connect(g); g.connect(this.musG);
    s.start(t); s.stop(t + dur + 0.02);
  }

  /* ---------- SFX ---------- */
  sfx(name: SfxName) {
    if (!this.ctx || this.muted) return;
    const t = this.ctx.currentTime;
    switch (name) {
      case 'shoot_blaster': this.tone(920, t, 0.07, 'square', 0.22, this.sfxG, 420); break;
      case 'shoot_shotgun': this.noise(t, 0.14, 0.3, 3000, 400); this.tone(220, t, 0.1, 'square', 0.2, this.sfxG, 90); break;
      case 'shoot_laser': this.tone(1600, t, 0.09, 'sawtooth', 0.16, this.sfxG, 260); break;
      case 'shoot_plasma': this.tone(200, t, 0.2, 'triangle', 0.3, this.sfxG, 60); this.noise(t, 0.12, 0.12, 800, 200); break;
      case 'shoot_rocket': this.noise(t, 0.28, 0.26, 2200, 300); break;
      case 'shoot_dual': this.tone(1250, t, 0.05, 'square', 0.16, this.sfxG, 750); break;
      case 'shoot_tesla': this.noise(t, 0.07, 0.2, 6000, 2400, 'highpass'); this.tone(2100, t, 0.05, 'square', 0.1, this.sfxG, 1200); break;
      case 'shoot_homing': this.tone(480, t, 0.1, 'triangle', 0.2, this.sfxG, 960); break;
      case 'hit': this.noise(t, 0.05, 0.18, 1500, 500); this.tone(190, t, 0.045, 'square', 0.14, this.sfxG, 120); break;
      case 'kill': this.tone(420, t, 0.16, 'square', 0.2, this.sfxG, 60); this.noise(t, 0.08, 0.14, 2200, 600); break;
      case 'xp': {
        const dt = this.ctx.currentTime;
        this.xpPitch = dt - this.xpReset < 0.9 ? Math.min(this.xpPitch + 1, 11) : 0;
        this.xpReset = dt;
        this.tone(620 * Math.pow(1.059, this.xpPitch), t, 0.07, 'sine', 0.11, this.sfxG, 900 * Math.pow(1.059, this.xpPitch));
        break;
      }
      case 'levelup': [72, 76, 79, 84].forEach((n, i) => this.tone(mtof(n), t + i * 0.08, 0.16, 'square', 0.18, this.sfxG)); break;
      case 'pick': this.tone(660, t, 0.07, 'square', 0.16, this.sfxG); this.tone(990, t + 0.08, 0.12, 'square', 0.16, this.sfxG); break;
      case 'hurt': this.tone(150, t, 0.2, 'sawtooth', 0.24, this.sfxG, 55); this.noise(t, 0.12, 0.18, 900, 200); break;
      case 'explode': this.noise(t, 0.38, 0.4, 1600, 90); this.tone(70, t, 0.3, 'sine', 0.34, this.sfxG, 30); break;
      case 'boss_roar': this.tone(95, t, 0.55, 'sawtooth', 0.32, this.sfxG, 42); this.noise(t, 0.4, 0.2, 700, 150); this.tone(140, t + 0.1, 0.4, 'square', 0.14, this.sfxG, 60); break;
      case 'warn': this.tone(660, t, 0.09, 'square', 0.18, this.sfxG); this.tone(660, t + 0.13, 0.09, 'square', 0.18, this.sfxG); break;
      case 'jump': this.tone(280, t, 0.1, 'square', 0.12, this.sfxG, 620); break;
      case 'dash': this.noise(t, 0.14, 0.14, 3000, 800, 'highpass'); break;
      case 'click': this.tone(1000, t, 0.04, 'square', 0.14, this.sfxG); break;
      case 'heal': [64, 69, 72].forEach((n, i) => this.tone(mtof(n), t + i * 0.07, 0.14, 'triangle', 0.16, this.sfxG)); break;
      case 'wave': this.tone(440, t, 0.09, 'square', 0.14, this.sfxG); this.tone(587, t + 0.1, 0.14, 'square', 0.14, this.sfxG); break;
      case 'victory': [72, 76, 79, 84, 79, 84].forEach((n, i) => this.tone(mtof(n), t + i * 0.1, 0.22, 'square', 0.16, this.sfxG)); break;
      case 'gameover': [60, 58, 55, 48].forEach((n, i) => this.tone(mtof(n), t + i * 0.22, 0.3, 'triangle', 0.2, this.sfxG)); break;
    }
  }
  destroy() { if (this.timer) clearInterval(this.timer); this.ctx?.close(); }
}
