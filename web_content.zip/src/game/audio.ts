let ctx: AudioContext | null = null;
let noiseBuf: AudioBuffer | null = null;

export function initAudio() {
  if (ctx) {
    if (ctx.state === 'suspended') void ctx.resume();
    return;
  }
  try {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC();
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.4, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  } catch {
    ctx = null;
  }
}

export function playHit(strength: number, enabled: boolean) {
  if (!enabled || !ctx || !noiseBuf) return;
  const t = ctx.currentTime;
  const vol = Math.min(1, 0.15 + strength * 0.12);
  const src = ctx.createBufferSource();
  src.buffer = noiseBuf;
  const filt = ctx.createBiquadFilter();
  filt.type = 'lowpass';
  filt.frequency.value = 500 + strength * 250;
  const g = ctx.createGain();
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
  src.connect(filt).connect(g).connect(ctx.destination);
  src.start(t);
  src.stop(t + 0.2);

  const o = ctx.createOscillator();
  const og = ctx.createGain();
  o.type = 'sine';
  o.frequency.setValueAtTime(140, t);
  o.frequency.exponentialRampToValueAtTime(45, t + 0.15);
  og.gain.setValueAtTime(vol * 0.9, t);
  og.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
  o.connect(og).connect(ctx.destination);
  o.start(t);
  o.stop(t + 0.2);
}

export function playBlip(freq: number, enabled: boolean, dur = 0.08, type: OscillatorType = 'square') {
  if (!enabled || !ctx) return;
  const t = ctx.currentTime;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.setValueAtTime(0.07, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  o.connect(g).connect(ctx.destination);
  o.start(t);
  o.stop(t + dur + 0.02);
}

export function vibrate(ms: number, enabled: boolean) {
  if (!enabled) return;
  try {
    navigator.vibrate?.(ms);
  } catch {
    /* ignore */
  }
}
