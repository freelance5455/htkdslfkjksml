export type AudioBus = ReturnType<typeof createAudio>;

export function createAudio() {
  let ctx: AudioContext | null = null;
  let volume = 0.45;
  let muted = false;
  let siren: OscillatorNode | null = null;
  let sirenGain: GainNode | null = null;
  let engine: OscillatorNode | null = null;
  let engineGain: GainNode | null = null;
  let sirenOn = false;

  const ac = () => {
    if (!ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
    }
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  };

  const master = () => {
    const c = ac();
    const g = c.createGain();
    g.gain.value = muted ? 0 : volume;
    g.connect(c.destination);
    return { c, g };
  };

  const tone = (freq: number, dur: number, type: OscillatorType, gain: number, slide = 0) => {
    if (muted) return;
    try {
      const { c, g } = master();
      const o = c.createOscillator();
      o.type = type;
      o.frequency.value = freq;
      if (slide) o.frequency.linearRampToValueAtTime(Math.max(40, freq + slide), c.currentTime + dur);
      g.gain.value = gain * (muted ? 0 : volume);
      g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + dur);
      o.connect(g);
      o.start();
      o.stop(c.currentTime + dur + 0.02);
    } catch {
      /* autoplay */
    }
  };

  return {
    unlock() {
      try {
        ac();
      } catch {
        /* ignore */
      }
    },
    setVolume(v: number) {
      volume = Math.max(0, Math.min(1, v));
      if (sirenGain) sirenGain.gain.value = sirenOn && !muted ? 0.03 * volume : 0;
      if (engineGain) engineGain.gain.value = muted ? 0 : engineGain.gain.value;
    },
    setMuted(m: boolean) {
      muted = m;
      if (sirenGain) sirenGain.gain.value = sirenOn && !muted ? 0.03 * volume : 0;
    },
    get volume() {
      return volume;
    },
    get muted() {
      return muted;
    },
    blip() {
      tone(660, 0.07, "square", 0.04);
    },
    gun(kind: string) {
      if (kind === "shotgun") tone(140, 0.18, "sawtooth", 0.08, -80);
      else if (kind === "sniper") tone(90, 0.22, "square", 0.07, -40);
      else if (kind === "jade") tone(320, 0.05, "square", 0.035, -120);
      else tone(520, 0.06, "square", 0.04, -200);
    },
    boom() {
      tone(70, 0.4, "sawtooth", 0.1, -50);
    },
    hit() {
      tone(180, 0.08, "triangle", 0.05, -60);
    },
    cash() {
      tone(880, 0.08, "square", 0.04);
      setTimeout(() => tone(1180, 0.1, "square", 0.04), 70);
    },
    radioNote(freq: number, bass: boolean) {
      tone(freq, bass ? 0.18 : 0.12, bass ? "triangle" : "square", bass ? 0.05 : 0.025);
    },
    ensureEngine() {
      if (engine || muted) return;
      try {
        const c = ac();
        engine = c.createOscillator();
        engine.type = "sawtooth";
        engine.frequency.value = 50;
        engineGain = c.createGain();
        engineGain.gain.value = 0;
        const f = c.createBiquadFilter();
        f.type = "lowpass";
        f.frequency.value = 240;
        engine.connect(f);
        f.connect(engineGain);
        engineGain.connect(c.destination);
        engine.start();
      } catch {
        /* ignore */
      }
    },
    engine(speed: number, on: boolean) {
      if (!engine || !engineGain || !ctx) return;
      const target = on && !muted ? Math.min(0.05, 0.012 + Math.abs(speed) * 0.0012) * (volume / 0.45) : 0;
      engineGain.gain.setTargetAtTime(target, ctx.currentTime, 0.08);
      engine.frequency.setTargetAtTime(48 + Math.abs(speed) * 3.2, ctx.currentTime, 0.08);
    },
    siren(on: boolean) {
      sirenOn = on;
      if (on && !siren) {
        try {
          const c = ac();
          siren = c.createOscillator();
          siren.type = "sawtooth";
          siren.frequency.value = 680;
          sirenGain = c.createGain();
          sirenGain.gain.value = muted ? 0 : 0.03 * volume;
          siren.connect(sirenGain);
          sirenGain.connect(c.destination);
          siren.start();
          const lfo = () => {
            if (!siren || !ctx) return;
            siren.frequency.setValueAtTime(Math.sin(ctx.currentTime * 8) > 0 ? 760 : 520, ctx.currentTime);
          };
          const id = window.setInterval(lfo, 180);
          siren.onended = () => window.clearInterval(id);
        } catch {
          /* ignore */
        }
      }
      if (sirenGain && ctx) sirenGain.gain.setTargetAtTime(on && !muted ? 0.028 * volume : 0, ctx.currentTime, 0.1);
    },
    close() {
      try {
        siren?.stop();
        engine?.stop();
        void ctx?.close();
      } catch {
        /* ignore */
      }
      siren = null;
      engine = null;
      ctx = null;
    },
  };
}
