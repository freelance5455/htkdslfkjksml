let ctx: AudioContext | null = null;
let master: GainNode | null = null;

function context(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const AC =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AC) return null;
  if (!ctx) {
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.2;
    master.connect(ctx.destination);
  }
  return ctx;
}

export function unlockAudio() {
  const audio = context();
  if (audio && audio.state === "suspended") void audio.resume();
}

export function setMuted(muted: boolean) {
  if (!master) context();
  if (master) master.gain.value = muted ? 0 : 0.2;
}

function tone(
  freq: number,
  dur: number,
  type: OscillatorType,
  gain: number,
  delay = 0,
  slideTo?: number,
) {
  const audio = context();
  if (!audio || !master) return;
  const osc = audio.createOscillator();
  const amp = audio.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, audio.currentTime + delay);
  if (slideTo) {
    osc.frequency.exponentialRampToValueAtTime(
      Math.max(40, slideTo),
      audio.currentTime + delay + dur,
    );
  }
  amp.gain.setValueAtTime(gain, audio.currentTime + delay);
  amp.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + delay + dur);
  osc.connect(amp);
  amp.connect(master);
  osc.start(audio.currentTime + delay);
  osc.stop(audio.currentTime + delay + dur + 0.02);
}

function noise(dur: number, gain: number) {
  const audio = context();
  if (!audio || !master) return;
  const length = Math.floor(audio.sampleRate * dur);
  const buffer = audio.createBuffer(1, length, audio.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
  const src = audio.createBufferSource();
  src.buffer = buffer;
  const amp = audio.createGain();
  const filter = audio.createBiquadFilter();
  filter.type = "highpass";
  filter.frequency.value = 900;
  amp.gain.value = gain;
  src.connect(filter);
  filter.connect(amp);
  amp.connect(master);
  src.start();
}

export function playSfx(name: string) {
  const audio = context();
  if (!audio) return;
  const wobble = 0.94 + Math.random() * 0.12;
  switch (name) {
    case "shoot":
      noise(0.06, 0.15);
      tone(520 * wobble, 0.09, "triangle", 0.18, 0, 240);
      break;
    case "pop":
      tone(660 * wobble, 0.12, "sine", 0.22, 0, 880);
      tone(990 * wobble, 0.08, "triangle", 0.08);
      break;
    case "pop-big":
      tone(520, 0.14, "triangle", 0.22, 0, 1040);
      tone(780, 0.16, "sine", 0.16, 0.04, 1240);
      break;
    case "fall":
      tone(420, 0.18, "sine", 0.12, 0, 180);
      break;
    case "drop":
      tone(180, 0.16, "sine", 0.2, 0, 90);
      break;
    case "stick":
      tone(300, 0.05, "sine", 0.08);
      break;
    case "swap":
      tone(540, 0.06, "sine", 0.1);
      break;
    case "win":
      tone(523, 0.12, "triangle", 0.18, 0);
      tone(659, 0.12, "triangle", 0.18, 0.1);
      tone(784, 0.22, "triangle", 0.2, 0.2);
      break;
    case "lose":
      tone(392, 0.18, "sine", 0.16, 0, 262);
      tone(220, 0.28, "triangle", 0.14, 0.12);
      break;
    default:
      break;
  }
}
