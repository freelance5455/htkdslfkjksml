/**
 * Procedural sound effects synthesised with the Web Audio API.
 * No external assets → works offline and in a single-file build.
 */

interface ToneOpts {
  f: number;
  f2?: number;
  d: number;
  v: number;
  t?: number;
  type?: OscillatorType;
  a?: number;
}

class SoundManager {
  enabled = true;
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;

  setEnabled(v: boolean): void {
    this.enabled = v;
    if (v) this.unlock();
    else this.ctx?.suspend().catch(() => undefined);
  }

  /** Must be called from a user gesture (pointerdown / click). */
  unlock(): void {
    if (!this.enabled) return;
    try {
      if (!this.ctx) {
        const AC =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.55;
        this.master.connect(this.ctx.destination);
      }
      if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => undefined);
    } catch {
      this.ctx = null;
    }
  }

  suspend(): void {
    this.ctx?.suspend().catch(() => undefined);
  }

  resume(): void {
    if (this.enabled) this.unlock();
  }

  private get ready(): boolean {
    return this.enabled && !!this.ctx && !!this.master && this.ctx.state === 'running';
  }

  private tone(o: ToneOpts): void {
    if (!this.ready) return;
    const ctx = this.ctx!;
    const now = ctx.currentTime + (o.t ?? 0);
    const osc = ctx.createOscillator();
    osc.type = o.type ?? 'sine';
    osc.frequency.setValueAtTime(o.f, now);
    if (o.f2) osc.frequency.exponentialRampToValueAtTime(o.f2, now + o.d);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(o.v, now + (o.a ?? 0.006));
    g.gain.exponentialRampToValueAtTime(0.0001, now + o.d);
    osc.connect(g);
    g.connect(this.master!);
    osc.start(now);
    osc.stop(now + o.d + 0.03);
  }

  private noise(d: number, v: number, t = 0, freq = 1600, q = 0.8): void {
    if (!this.ready) return;
    const ctx = this.ctx!;
    if (!this.noiseBuf) {
      const len = Math.floor(ctx.sampleRate * 0.5);
      this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      const data = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    }
    const now = ctx.currentTime + t;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = freq;
    filter.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(v, now);
    g.gain.exponentialRampToValueAtTime(0.0001, now + d);
    src.connect(filter);
    filter.connect(g);
    g.connect(this.master!);
    src.start(now);
    src.stop(now + d + 0.02);
  }

  pickup(): void {
    this.tone({ f: 520, f2: 820, d: 0.09, v: 0.12, type: 'triangle' });
  }

  drop(): void {
    this.tone({ f: 170, f2: 70, d: 0.14, v: 0.45 });
    this.noise(0.05, 0.18, 0, 1800, 0.6);
  }

  invalid(): void {
    this.tone({ f: 190, f2: 120, d: 0.1, v: 0.18, type: 'triangle' });
    this.tone({ f: 150, f2: 95, d: 0.12, v: 0.16, type: 'triangle', t: 0.09 });
  }

  click(): void {
    this.tone({ f: 980, f2: 720, d: 0.05, v: 0.1, type: 'triangle' });
  }

  appear(): void {
    this.tone({ f: 380, f2: 680, d: 0.09, v: 0.07, type: 'triangle' });
  }

  clear(lines: number, combo: number): void {
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98];
    const n = Math.min(notes.length, 2 + lines);
    const k = 1 + Math.min(combo, 10) * 0.025;
    for (let i = 0; i < n; i++) {
      this.tone({ f: notes[i] * k, d: 0.3, v: 0.16, type: 'triangle', t: i * 0.055 });
      this.tone({ f: (notes[i] * k) / 2, d: 0.25, v: 0.08, type: 'sine', t: i * 0.055 });
    }
    this.noise(0.28, 0.1, 0, 2600, 0.5);
    if (lines >= 3) this.tone({ f: 130, f2: 60, d: 0.3, v: 0.4 });
  }

  combo(level: number): void {
    const base = [1567.98, 1975.53, 2349.32];
    const k = 1 + Math.min(level, 12) * 0.02;
    base.forEach((f, i) => this.tone({ f: f * k, d: 0.14, v: 0.09, type: 'sine', t: 0.12 + i * 0.06 }));
  }

  praise(): void {
    [523.25, 659.25, 783.99].forEach((f) =>
      this.tone({ f, d: 0.55, v: 0.07, type: 'triangle', t: 0.08, a: 0.03 })
    );
  }

  gameOver(): void {
    const seq = [392, 329.63, 261.63, 196];
    seq.forEach((f, i) =>
      this.tone({ f, f2: f * 0.97, d: 0.42, v: 0.18, type: 'triangle', t: i * 0.24, a: 0.02 })
    );
    this.tone({ f: 98, f2: 60, d: 1.1, v: 0.2, t: seq.length * 0.24 });
  }

  record(): void {
    const seq = [523.25, 659.25, 783.99, 1046.5];
    seq.forEach((f, i) => {
      const last = i === seq.length - 1;
      this.tone({ f, d: last ? 0.9 : 0.3, v: 0.16, type: 'triangle', t: i * 0.13, a: 0.01 });
      this.tone({ f: f / 2, d: last ? 0.9 : 0.3, v: 0.08, type: 'sine', t: i * 0.13, a: 0.01 });
    });
    this.noise(0.6, 0.08, 0.4, 3000, 0.4);
  }
}

export const sound = new SoundManager();
