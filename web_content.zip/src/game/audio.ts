export class GameAudio {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  sfx: GainNode | null = null;
  ambience: GainNode | null = null;
  muted = false;
  volume = 0.7;
  private crowd: AudioBufferSourceNode | null = null;
  private crowdGain: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;

  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.sfx = this.ctx.createGain();
      this.ambience = this.ctx.createGain();
      this.sfx.connect(this.master);
      this.ambience.connect(this.master);
      this.master.connect(this.ctx.destination);
      this.applyVolume();
      this.noiseBuf = this.makeNoise(1.5);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    this.startCrowd();
  }

  resume() {
    if (this.ctx?.state === "suspended") void this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    this.applyVolume();
  }

  setVolume(v: number) {
    this.volume = v;
    this.applyVolume();
  }

  private applyVolume() {
    if (!this.master) return;
    const g = this.muted ? 0 : this.volume * this.volume;
    this.master.gain.setTargetAtTime(g, this.ctx!.currentTime, 0.03);
  }

  private makeNoise(seconds: number) {
    const ctx = this.ctx!;
    const n = Math.floor(ctx.sampleRate * seconds);
    const buf = ctx.createBuffer(1, n, ctx.sampleRate);
    const d = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < n; i++) {
      const white = Math.random() * 2 - 1;
      last = (last + 0.02 * white) / 1.02;
      d[i] = last * 3.5;
    }
    return buf;
  }

  private startCrowd() {
    if (!this.ctx || !this.ambience || !this.noiseBuf || this.crowd) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 900;
    this.crowdGain = this.ctx.createGain();
    this.crowdGain.gain.value = 0.08;
    src.connect(filter);
    filter.connect(this.crowdGain);
    this.crowdGain.connect(this.ambience);
    src.start();
    this.crowd = src;
  }

  setExcitement(v: number) {
    if (!this.crowdGain || !this.ctx) return;
    this.crowdGain.gain.setTargetAtTime(0.06 + v * 0.22, this.ctx.currentTime, 0.25);
  }

  private tone(freq: number, dur: number, type: OscillatorType, gain: number, delay = 0) {
    if (!this.ctx || !this.sfx) return;
    const t0 = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(this.sfx);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }

  private noiseBurst(dur: number, gain: number, freq = 1200) {
    if (!this.ctx || !this.sfx || !this.noiseBuf) return;
    const t0 = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = freq;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.sfx);
    src.start(t0);
    src.stop(t0 + dur + 0.02);
  }

  kick(power = 0.6) {
    this.noiseBurst(0.12, 0.18 + power * 0.2, 700 + power * 400);
    this.tone(90 + power * 40, 0.16, "sine", 0.22 + power * 0.15);
  }

  pass() {
    this.noiseBurst(0.08, 0.12, 900);
    this.tone(140, 0.1, "sine", 0.12);
  }

  whistle() {
    this.tone(1480, 0.22, "sine", 0.12);
    this.tone(1480, 0.18, "sine", 0.1, 0.28);
  }

  longWhistle() {
    this.tone(1420, 0.7, "sine", 0.12);
  }

  goal() {
    this.setExcitement(1);
    this.tone(392, 0.18, "triangle", 0.14);
    this.tone(523, 0.2, "triangle", 0.12, 0.12);
    this.tone(659, 0.35, "triangle", 0.14, 0.24);
    this.noiseBurst(0.4, 0.22, 500);
  }

  save() {
    this.noiseBurst(0.1, 0.16, 400);
    this.tone(70, 0.12, "sine", 0.18);
  }

  ui() {
    this.tone(660, 0.06, "sine", 0.06);
  }

  catchBall() {
    this.noiseBurst(0.06, 0.08, 500);
  }
}
