type Scene = "menu" | "play" | "quiet";

export class ChirpAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private wind: AudioBufferSourceNode | null = null;
  private windGain: GainNode | null = null;
  private pads: { osc: OscillatorNode; gain: GainNode }[] = [];
  private timer = 0;
  private nextNote = 0;
  private noteIndex = 0;
  private scene: Scene = "quiet";
  private pendingScene: Scene = "menu";
  private musicOn = true;
  private soundOn = true;
  private volume = 0.85;
  private windWanted = false;
  private lastFlap = 0;
  private wantClick = false;
  private scheduling = false;

  unlock() {
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    if (!this.ctx) {
      this.ctx = new AC({ latencyHint: "interactive" });
      this.buildGraph();
    }
    if (this.ctx.state === "suspended") {
      void this.ctx.resume().then(() => this.flush());
    } else {
      this.flush();
    }
  }

  onVisible() {
    if (this.ctx && this.ctx.state === "suspended") {
      void this.ctx.resume().then(() => this.flush());
    }
  }

  apply(opts: { soundOn: boolean; musicOn: boolean; volume: number }) {
    this.soundOn = opts.soundOn;
    this.musicOn = opts.musicOn;
    this.volume = opts.volume;
    this.applyGains();
    if (!this.musicOn) this.stopMusic();
    else if (this.ctx?.state === "running") this.applyScene(this.pendingScene);
    this.syncWind();
  }

  setVolume(v: number) {
    this.volume = Math.min(1, Math.max(0, v));
    this.applyGains();
  }

  setSoundOn(on: boolean) {
    this.soundOn = on;
    this.applyGains();
    this.syncWind();
  }

  setMusicOn(on: boolean) {
    this.musicOn = on;
    if (!on) this.stopMusic();
    else this.applyScene(this.pendingScene);
    this.applyGains();
  }

  syncScene(scene: Scene) {
    this.pendingScene = scene;
    if (!this.ctx || this.ctx.state !== "running") return;
    this.applyScene(scene);
  }

  setWind(on: boolean) {
    this.windWanted = on;
    this.syncWind();
  }

  click() {
    this.wantClick = true;
    if (this.sfxReady()) {
      this.wantClick = false;
      this.blip(880, 0.045, 0.12, "sine");
    }
  }

  flap() {
    if (!this.sfxReady() || !this.ctx) return;
    const now = this.ctx.currentTime;
    if (now - this.lastFlap < 0.07) return;
    this.lastFlap = now;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(620 + Math.random() * 40, now);
    osc.frequency.exponentialRampToValueAtTime(1240, now + 0.08);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.2, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.1);
    osc.connect(gain);
    gain.connect(this.sfxBus!);
    osc.start(now);
    osc.stop(now + 0.11);
    this.noiseBurst(now, 900, 0.08, 0.06);
    osc.onended = () => {
      osc.disconnect();
      gain.disconnect();
    };
  }

  score() {
    if (!this.sfxReady() || !this.ctx) return;
    const now = this.ctx.currentTime;
    this.tone(784, now, 0.09, 0.14, "triangle");
    this.tone(1174, now + 0.07, 0.12, 0.16, "triangle");
  }

  hit(kind: "pipe" | "ground") {
    if (!this.sfxReady() || !this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "sine";
    const start = kind === "ground" ? 180 : 240;
    osc.frequency.setValueAtTime(start, now);
    osc.frequency.exponentialRampToValueAtTime(55, now + 0.22);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(kind === "ground" ? 0.32 : 0.26, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.28);
    osc.connect(gain);
    gain.connect(this.sfxBus!);
    osc.start(now);
    osc.stop(now + 0.3);
    this.noiseBurst(now, kind === "ground" ? 180 : 320, 0.22, 0.18);
    osc.onended = () => {
      osc.disconnect();
      gain.disconnect();
    };
  }

  over() {
    if (!this.sfxReady() || !this.ctx) return;
    const now = this.ctx.currentTime;
    [523, 392, 311].forEach((f, i) => this.tone(f, now + i * 0.12, 0.16, 0.12, "triangle"));
  }

  dispose() {
    this.stopMusic();
    this.stopWind();
    window.clearTimeout(this.timer);
    void this.ctx?.close();
    this.ctx = null;
  }

  private flush() {
    if (this.wantClick && this.sfxReady()) {
      this.wantClick = false;
      this.blip(880, 0.045, 0.12, "sine");
    }
    this.applyScene(this.pendingScene);
    this.syncWind();
  }

  private buildGraph() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    this.master = ctx.createGain();
    this.musicBus = ctx.createGain();
    this.sfxBus = ctx.createGain();
    this.musicBus.connect(this.master);
    this.sfxBus.connect(this.master);
    this.master.connect(ctx.destination);
    const seconds = 2;
    this.noise = ctx.createBuffer(1, Math.floor(ctx.sampleRate * seconds), ctx.sampleRate);
    const data = this.noise.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    this.applyGains();
  }

  private applyGains() {
    if (!this.ctx || !this.master || !this.musicBus || !this.sfxBus) return;
    const now = this.ctx.currentTime;
    const master = this.volume * this.volume;
    this.master.gain.setTargetAtTime(master, now, 0.02);
    this.sfxBus.gain.setTargetAtTime(this.soundOn ? 1 : 0, now, 0.02);
    this.musicBus.gain.setTargetAtTime(this.musicOn ? 1 : 0, now, 0.03);
  }

  private sfxReady() {
    return Boolean(this.soundOn && this.ctx && this.ctx.state === "running" && this.sfxBus);
  }

  private applyScene(scene: Scene) {
    if (!this.ctx || this.ctx.state !== "running") return;
    if (!this.musicOn) {
      this.scene = scene;
      this.stopMusic();
      return;
    }
    if (scene === "quiet") {
      this.scene = scene;
      this.stopMusic();
      return;
    }
    if (this.scene === scene && this.scheduling) return;
    this.scene = scene;
    this.stopMusic();
    this.startPad(scene);
    this.noteIndex = 0;
    this.nextNote = this.ctx.currentTime + 0.05;
    this.scheduling = true;
    this.schedule();
  }

  private startPad(scene: Scene) {
    if (!this.ctx || !this.musicBus) return;
    const freqs = scene === "menu" ? [196, 247, 392] : [174, 220, 262];
    const now = this.ctx.currentTime;
    for (const f of freqs) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = f;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.setTargetAtTime(scene === "menu" ? 0.018 : 0.012, now, 0.4);
      osc.connect(gain);
      gain.connect(this.musicBus);
      osc.start();
      this.pads.push({ osc, gain });
    }
  }

  private schedule = () => {
    if (!this.scheduling || !this.ctx || !this.musicBus) return;
    const pattern = this.scene === "play" ? PLAY_NOTES : MENU_NOTES;
    const step = this.scene === "play" ? 0.58 : 0.42;
    const horizon = this.ctx.currentTime + 0.35;
    while (this.nextNote < horizon) {
      const freq = pattern[this.noteIndex % pattern.length]!;
      this.tone(freq, this.nextNote, 0.34, this.scene === "play" ? 0.05 : 0.07, "triangle", true);
      this.nextNote += step;
      this.noteIndex++;
    }
    this.timer = window.setTimeout(this.schedule, 120);
  };

  private stopMusic() {
    this.scheduling = false;
    window.clearTimeout(this.timer);
    const ctx = this.ctx;
    const pads = this.pads;
    this.pads = [];
    if (!ctx) return;
    const now = ctx.currentTime;
    for (const pad of pads) {
      try {
        pad.gain.gain.setTargetAtTime(0.0001, now, 0.05);
        pad.osc.stop(now + 0.2);
      } catch {
        /* already stopped */
      }
    }
  }

  private syncWind() {
    if (!this.ctx || this.ctx.state !== "running") return;
    if (this.windWanted && this.soundOn) this.ensureWind();
    else this.stopWind();
  }

  private ensureWind() {
    if (this.wind || !this.ctx || !this.noise || !this.sfxBus) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    src.loop = true;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = 480;
    filter.Q.value = 0.55;
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.0001, this.ctx.currentTime);
    gain.gain.setTargetAtTime(0.04, this.ctx.currentTime, 0.35);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxBus);
    src.start();
    this.wind = src;
    this.windGain = gain;
  }

  private stopWind() {
    const wind = this.wind;
    const gain = this.windGain;
    this.wind = null;
    this.windGain = null;
    if (!wind || !this.ctx || !gain) return;
    gain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.05);
    window.setTimeout(() => {
      try {
        wind.stop();
      } catch {
        /* already stopped */
      }
    }, 180);
  }

  private blip(freq: number, dur: number, amp: number, type: OscillatorType) {
    if (!this.ctx) return;
    this.tone(freq, this.ctx.currentTime, dur, amp, type);
  }

  private tone(
    freq: number,
    when: number,
    dur: number,
    amp: number,
    type: OscillatorType,
    music = false,
  ) {
    if (!this.ctx) return;
    const bus = music ? this.musicBus : this.sfxBus;
    if (!bus) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, when);
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, amp), when + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    osc.connect(gain);
    gain.connect(bus);
    osc.start(when);
    osc.stop(when + dur + 0.02);
    osc.onended = () => {
      osc.disconnect();
      gain.disconnect();
    };
  }

  private noiseBurst(when: number, highpass: number, dur: number, amp: number) {
    if (!this.ctx || !this.noise || !this.sfxBus) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "highpass";
    filter.frequency.value = highpass;
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(amp, when);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxBus);
    src.start(when);
    src.stop(when + dur);
    src.onended = () => {
      src.disconnect();
      filter.disconnect();
      gain.disconnect();
    };
  }
}

const MENU_NOTES = [262, 330, 392, 494, 392, 330, 294, 330];
const PLAY_NOTES = [220, 262, 330, 262, 196, 247, 294, 262];
