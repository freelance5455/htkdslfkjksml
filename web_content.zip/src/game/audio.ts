import type { ArenaId } from "./types";

export type SfxName =
  | "swing_light"
  | "swing_heavy"
  | "hit_light"
  | "hit_heavy"
  | "block"
  | "dodge"
  | "special"
  | "charge"
  | "round"
  | "victory"
  | "defeat"
  | "ui"
  | "ko";

/**
 * All audio is synthesized at runtime with the Web Audio API.
 * No audio files, no network requests, works fully offline.
 */
export class AudioManager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private musicTimer: number | null = null;
  private nextStepTime = 0;
  private step = 0;
  private theme: ArenaId = "olympus";
  private musicOn = false;
  private volume = 0.8;
  private muted = false;
  private droneNodes: { osc: OscillatorNode; lfo: OscillatorNode }[] = [];

  get ready() {
    return this.ctx !== null;
  }

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    try {
      const Ctor: typeof AudioContext =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return;
      const ctx = new Ctor();
      this.ctx = ctx;
      this.master = ctx.createGain();
      this.master.gain.value = this.muted ? 0 : this.volume;
      this.master.connect(ctx.destination);
      this.sfxBus = ctx.createGain();
      this.sfxBus.gain.value = 0.9;
      this.sfxBus.connect(this.master);
      this.musicBus = ctx.createGain();
      this.musicBus.gain.value = 0.5;
      this.musicBus.connect(this.master);

      const len = Math.floor(ctx.sampleRate * 1.5);
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      this.noise = buf;
    } catch {
      this.ctx = null;
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : this.volume, this.ctx.currentTime, 0.05);
    }
  }

  setVolume(v: number) {
    this.volume = Math.max(0, Math.min(1, v));
    if (this.master && this.ctx && !this.muted) {
      this.master.gain.setTargetAtTime(this.volume, this.ctx.currentTime, 0.05);
    }
  }

  private tone(
    freq: number,
    type: OscillatorType,
    dur: number,
    gain: number,
    opts: {
      slideTo?: number;
      delay?: number;
      attack?: number;
      filter?: number;
      filterTo?: number;
      detune?: number;
      bus?: GainNode | null;
    } = {}
  ) {
    const ctx = this.ctx;
    if (!ctx) return;
    const t0 = ctx.currentTime + (opts.delay ?? 0);
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (opts.slideTo !== undefined) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, opts.slideTo), t0 + dur);
    }
    if (opts.detune) osc.detune.value = opts.detune;
    const g = ctx.createGain();
    const attack = opts.attack ?? 0.005;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    let node: AudioNode = g;
    if (opts.filter) {
      const f = ctx.createBiquadFilter();
      f.type = "lowpass";
      f.frequency.setValueAtTime(opts.filter, t0);
      if (opts.filterTo) f.frequency.exponentialRampToValueAtTime(opts.filterTo, t0 + dur);
      g.connect(f);
      node = f;
    }
    osc.connect(g);
    node.connect(opts.bus ?? this.sfxBus ?? ctx.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  private burst(
    dur: number,
    gain: number,
    filterType: BiquadFilterType,
    freq: number,
    freqTo?: number,
    delay = 0,
    q = 1
  ) {
    const ctx = this.ctx;
    if (!ctx || !this.noise) return;
    const t0 = ctx.currentTime + delay;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    src.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = filterType;
    f.Q.value = q;
    f.frequency.setValueAtTime(freq, t0);
    if (freqTo) f.frequency.exponentialRampToValueAtTime(Math.max(40, freqTo), t0 + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.sfxBus ?? ctx.destination);
    src.start(t0);
    src.stop(t0 + dur + 0.05);
  }

  play(name: SfxName) {
    if (!this.ctx) return;
    if (this.ctx.state === "suspended") void this.ctx.resume();
    switch (name) {
      case "swing_light":
        this.burst(0.16, 0.16, "bandpass", 2400, 700, 0, 1.4);
        break;
      case "swing_heavy":
        this.burst(0.34, 0.26, "lowpass", 1400, 260, 0, 0.8);
        this.tone(120, "sine", 0.3, 0.12, { slideTo: 60 });
        break;
      case "hit_light":
        this.tone(190, "sine", 0.16, 0.4, { slideTo: 70 });
        this.burst(0.12, 0.3, "highpass", 1200, 500);
        break;
      case "hit_heavy":
        this.tone(130, "sine", 0.42, 0.55, { slideTo: 38 });
        this.tone(70, "triangle", 0.5, 0.3, { slideTo: 30 });
        this.burst(0.3, 0.4, "lowpass", 2200, 300);
        break;
      case "block":
        this.tone(1180, "square", 0.12, 0.12, { slideTo: 820 });
        this.tone(1720, "triangle", 0.18, 0.1, { slideTo: 1400 });
        this.burst(0.14, 0.22, "highpass", 3000, 1600);
        break;
      case "dodge":
        this.burst(0.24, 0.16, "bandpass", 500, 1800, 0, 2);
        break;
      case "charge":
        this.tone(90, "sawtooth", 0.7, 0.14, { slideTo: 420, filter: 300, filterTo: 2400 });
        break;
      case "special":
        this.tone(110, "sawtooth", 0.55, 0.22, { slideTo: 880, filter: 400, filterTo: 5000 });
        this.tone(55, "sine", 0.8, 0.4, { slideTo: 28, delay: 0.35 });
        this.burst(0.6, 0.35, "lowpass", 3200, 200, 0.32);
        break;
      case "round":
        this.tone(98, "sine", 1.4, 0.35, { slideTo: 92 });
        this.tone(196, "sine", 1.1, 0.16, { slideTo: 190 });
        this.tone(294, "triangle", 0.9, 0.08, { slideTo: 288 });
        this.burst(0.5, 0.12, "lowpass", 900, 200);
        break;
      case "ko":
        this.tone(70, "sine", 1.6, 0.5, { slideTo: 26 });
        this.burst(0.9, 0.35, "lowpass", 1600, 120);
        break;
      case "victory": {
        const notes = [293.66, 349.23, 440, 587.33, 880];
        notes.forEach((n, i) =>
          this.tone(n, "triangle", 0.9, 0.16, { delay: i * 0.13, attack: 0.02 })
        );
        this.tone(146.83, "sine", 1.8, 0.2, { delay: 0.1 });
        break;
      }
      case "defeat": {
        const notes = [220, 196, 174.61, 146.83];
        notes.forEach((n, i) => this.tone(n, "triangle", 0.8, 0.14, { delay: i * 0.16 }));
        break;
      }
      case "ui":
        this.tone(660, "triangle", 0.07, 0.08, { slideTo: 880 });
        break;
    }
  }

  startMusic(theme: ArenaId) {
    this.init();
    if (!this.ctx || this.musicOn) {
      this.theme = theme;
      return;
    }
    this.theme = theme;
    this.musicOn = true;
    this.step = 0;
    this.nextStepTime = this.ctx.currentTime + 0.1;
    this.musicTimer = window.setInterval(() => this.schedule(), 120);
    this.drone();
  }

  private drone() {
    const ctx = this.ctx;
    if (!ctx || !this.musicBus) return;
    const base = this.theme === "olympus" ? 73.42 : 65.41;
    [1, 1.5, 2.005].forEach((mult, i) => {
      const osc = ctx.createOscillator();
      osc.type = i === 2 ? "triangle" : "sawtooth";
      osc.frequency.value = base * mult;
      osc.detune.value = (i - 1) * 7;
      const f = ctx.createBiquadFilter();
      f.type = "lowpass";
      f.frequency.value = 320;
      f.Q.value = 1.2;
      const g = ctx.createGain();
      g.gain.value = 0.035 / (i + 1);
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.07 + i * 0.03;
      const lg = ctx.createGain();
      lg.gain.value = 0.012;
      lfo.connect(lg);
      lg.connect(g.gain);
      osc.connect(f);
      f.connect(g);
      g.connect(this.musicBus!);
      osc.start();
      lfo.start();
      this.droneNodes.push({ osc, lfo });
    });
  }

  private schedule() {
    const ctx = this.ctx;
    if (!ctx || !this.musicBus) return;
    const spb = 60 / 76 / 2; // eighth notes at 76bpm
    if (this.nextStepTime < ctx.currentTime - 0.4) this.nextStepTime = ctx.currentTime + 0.08;
    while (this.nextStepTime < ctx.currentTime + 0.35) {
      const s = this.step % 32;
      const t = this.nextStepTime;
      const scale =
        this.theme === "olympus" ? [293.66, 349.23, 392, 440, 523.25] : [261.63, 311.13, 349.23, 392, 466.16];
      const motif = [0, 2, 4, 3, 2, 0, 1, 2, 4, 3, 2, 1, 0, 2, 3, 4];
      if (s % 4 === 0) {
        // low pulse
        this.musicNote(55, "sine", 0.55, 0.16, t, 40);
        this.burstAt(0.12, 0.05, "lowpass", 500, t);
      }
      if (s % 8 === 4) {
        this.musicNote(82.4, "sine", 0.4, 0.1, t, 55);
      }
      if (s % 2 === 0) {
        const n = scale[motif[(s / 2) % motif.length] % scale.length];
        this.musicNote(n, "triangle", 0.5, 0.055, t, n * 0.98);
        this.musicNote(n * 2, "sine", 0.3, 0.02, t + 0.01, n * 1.98);
      }
      if (s === 0) this.musicNote(scale[0] / 2, "sine", 2.2, 0.05, t, scale[0] / 2);
      this.nextStepTime += spb;
      this.step++;
    }
  }

  private musicNote(freq: number, type: OscillatorType, dur: number, gain: number, at: number, slide: number) {
    const ctx = this.ctx;
    if (!ctx || !this.musicBus) return;
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, at);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, slide), at + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, at);
    g.gain.exponentialRampToValueAtTime(gain, at + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    osc.connect(g);
    g.connect(this.musicBus);
    osc.start(at);
    osc.stop(at + dur + 0.05);
  }

  private burstAt(dur: number, gain: number, type: BiquadFilterType, freq: number, at: number) {
    const ctx = this.ctx;
    if (!ctx || !this.noise || !this.musicBus) return;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, at);
    g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.musicBus);
    src.start(at);
    src.stop(at + dur + 0.02);
  }

  stopMusic() {
    if (this.musicTimer !== null) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
    this.droneNodes.forEach(({ osc, lfo }) => {
      try {
        osc.stop();
        lfo.stop();
        osc.disconnect();
        lfo.disconnect();
      } catch {
        /* already stopped */
      }
    });
    this.droneNodes = [];
    this.musicOn = false;
  }

  dispose() {
    this.stopMusic();
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
    }
  }
}
