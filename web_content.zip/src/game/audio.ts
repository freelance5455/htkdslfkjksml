type Bus = { ctx: AudioContext; master: GainNode; sfx: GainNode; music: GainNode };

let bus: Bus | null = null;
let muted = false;
let drone: { o1: OscillatorNode; o2: OscillatorNode; g: GainNode } | null = null;

function ensure(): Bus | null {
  if (typeof window === "undefined") return null;
  if (bus) return bus;
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AC) return null;
  const ctx = new AC({ latencyHint: "interactive" });
  const master = ctx.createGain();
  const sfx = ctx.createGain();
  const music = ctx.createGain();
  master.gain.value = muted ? 0 : 0.7;
  sfx.gain.value = 0.9;
  music.gain.value = 0.55;
  sfx.connect(master);
  music.connect(master);
  master.connect(ctx.destination);
  bus = { ctx, master, sfx, music };
  return bus;
}

export function unlockAudio() {
  const b = ensure();
  if (!b) return;
  if (b.ctx.state === "suspended") void b.ctx.resume();
}

export function setMuted(next: boolean) {
  muted = next;
  if (!bus) return;
  bus.master.gain.setTargetAtTime(next ? 0 : 0.7, bus.ctx.currentTime, 0.04);
}

export function isMuted() {
  return muted;
}

function beep(freq: number, dur: number, type: OscillatorType, gain: number, slide = 0) {
  const b = ensure();
  if (!b || muted) return;
  const t = b.ctx.currentTime;
  const o = b.ctx.createOscillator();
  const g = b.ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g);
  g.connect(b.sfx);
  o.start(t);
  o.stop(t + dur + 0.02);
}

export function sfxScan() {
  beep(880, 0.18, "sine", 0.08, 420);
  beep(1320, 0.12, "triangle", 0.04, 200);
}

export function sfxCollect() {
  beep(740, 0.1, "sine", 0.07, 520);
  beep(1180, 0.16, "triangle", 0.05);
}

export function sfxWarp() {
  beep(140, 0.55, "sawtooth", 0.05, 900);
  beep(90, 0.4, "sine", 0.06, 200);
}

export function sfxWarn() {
  beep(180, 0.22, "square", 0.04);
}

export function sfxRank() {
  beep(520, 0.16, "sine", 0.07, 200);
  beep(780, 0.22, "triangle", 0.05, 280);
}

export function sfxDiscover() {
  beep(660, 0.2, "sine", 0.07, 340);
  beep(990, 0.28, "triangle", 0.045);
}

export function startDrone() {
  const b = ensure();
  if (!b || drone) return;
  const o1 = b.ctx.createOscillator();
  const o2 = b.ctx.createOscillator();
  const g = b.ctx.createGain();
  o1.type = "sine";
  o2.type = "triangle";
  o1.frequency.value = 42;
  o2.frequency.value = 63;
  g.gain.value = 0.0001;
  o1.connect(g);
  o2.connect(g);
  g.connect(b.music);
  o1.start();
  o2.start();
  g.gain.setTargetAtTime(0.022, b.ctx.currentTime, 0.6);
  drone = { o1, o2, g };
}

export function stopDrone() {
  if (!drone || !bus) return;
  const { o1, o2, g } = drone;
  drone = null;
  g.gain.setTargetAtTime(0.0001, bus.ctx.currentTime, 0.2);
  window.setTimeout(() => {
    try {
      o1.stop();
      o2.stop();
    } catch {
      /* already stopped */
    }
  }, 400);
}

export function pulseDrone(nearDanger: number) {
  if (!drone || !bus) return;
  const target = 0.018 + nearDanger * 0.04;
  drone.g.gain.setTargetAtTime(target, bus.ctx.currentTime, 0.15);
  drone.o1.frequency.setTargetAtTime(42 + nearDanger * 28, bus.ctx.currentTime, 0.2);
}
