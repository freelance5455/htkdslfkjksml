/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;

  private soundEnabled: boolean = true;
  private sfxVolume: number = 85; // 0..100
  private musicEnabled: boolean = true;
  private musicVolume: number = 65; // 0..100
  private hapticsEnabled: boolean = true;

  private musicInterval: number | null = null;
  private musicStep: number = 0;
  private isUnlocked: boolean = false;

  constructor() {
    this.setupUnlockListeners();
  }

  private setupUnlockListeners() {
    const unlock = () => {
      if (this.isUnlocked) return;
      const ctx = this.ensureContext();
      if (ctx) {
        if (ctx.state === 'suspended') {
          ctx.resume().then(() => {
            this.isUnlocked = true;
            if (this.musicEnabled && this.musicVolume > 0) {
              this.startMusic();
            }
          }).catch(() => {});
        } else {
          this.isUnlocked = true;
          if (this.musicEnabled && this.musicVolume > 0) {
            this.startMusic();
          }
        }
      }
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('pointerdown', unlock, { passive: true });
      window.addEventListener('touchstart', unlock, { passive: true });
      window.addEventListener('keydown', unlock, { passive: true });
    }
  }

  private ensureContext(): AudioContext | null {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.musicGain = this.ctx.createGain();
        this.sfxGain = this.ctx.createGain();

        this.musicGain.connect(this.ctx.destination);
        this.sfxGain.connect(this.ctx.destination);

        this.applyMusicGainImmediate();
        this.applySfxGainImmediate();
      }
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    return this.ctx;
  }

  private getEffectiveMusicGain(): number {
    if (!this.musicEnabled || this.musicVolume <= 0) return 0;
    // Scale gently for comfortable ambient listening (max ~0.35 gain at 100%)
    return (this.musicVolume / 100) * 0.35;
  }

  private getEffectiveSfxGain(): number {
    if (!this.soundEnabled || this.sfxVolume <= 0) return 0;
    return this.sfxVolume / 100;
  }

  private applyMusicGainImmediate() {
    if (!this.ctx || !this.musicGain) return;
    const now = this.ctx.currentTime;
    this.musicGain.gain.cancelScheduledValues(now);
    this.musicGain.gain.setTargetAtTime(this.getEffectiveMusicGain(), now, 0.02);
  }

  private applySfxGainImmediate() {
    if (!this.ctx || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    this.sfxGain.gain.cancelScheduledValues(now);
    this.sfxGain.gain.setTargetAtTime(this.getEffectiveSfxGain(), now, 0.01);
  }

  // --- Independent Music Controls ---

  public setMusicEnabled(enabled: boolean) {
    this.musicEnabled = enabled;
    this.applyMusicGainImmediate();
    if (enabled && this.musicVolume > 0) {
      if (this.isUnlocked) {
        this.startMusic();
      }
    } else {
      this.stopMusic();
    }
  }

  public isMusicEnabled(): boolean {
    return this.musicEnabled;
  }

  public setMusicVolume(volume: number) {
    this.musicVolume = Math.max(0, Math.min(100, volume));
    this.applyMusicGainImmediate();
    if (this.musicEnabled && this.musicVolume > 0 && this.isUnlocked) {
      this.startMusic();
    } else if (this.musicVolume <= 0) {
      this.stopMusic();
    }
  }

  public getMusicVolume(): number {
    return this.musicVolume;
  }

  // --- Independent Sound Effects Controls ---

  public setSoundEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
    this.applySfxGainImmediate();
  }

  public isSoundEnabled(): boolean {
    return this.soundEnabled;
  }

  public setSfxVolume(volume: number) {
    this.sfxVolume = Math.max(0, Math.min(100, volume));
    this.applySfxGainImmediate();
  }

  public getSfxVolume(): number {
    return this.sfxVolume;
  }

  // --- Haptics Control ---

  public setHapticsEnabled(enabled: boolean) {
    this.hapticsEnabled = enabled;
  }

  public isHapticsSupported(): boolean {
    return typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function';
  }

  public vibrate(pattern: number | number[]) {
    if (!this.hapticsEnabled || !this.isHapticsSupported()) return;
    try {
      navigator.vibrate(pattern);
    } catch {
      // Ignore browser blocks
    }
  }

  // --- Sound Effect Generators (routed strictly to this.sfxGain) ---

  public playClick() {
    if (!this.soundEnabled || this.sfxVolume <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const now = ctx.currentTime;

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(620, now);
    osc.frequency.exponentialRampToValueAtTime(180, now + 0.04);

    gain.gain.setValueAtTime(0.14, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.045);
  }

  public playTap() {
    if (!this.soundEnabled || this.sfxVolume <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const now = ctx.currentTime;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(460, now);
    osc.frequency.exponentialRampToValueAtTime(340, now + 0.055);

    gain.gain.setValueAtTime(0.16, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.055);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.06);
  }

  public playEscape(combo: number = 0) {
    if (!this.soundEnabled || this.sfxVolume <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const now = ctx.currentTime;
    const pitchOffset = Math.min(combo * 36, 280);

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(520 + pitchOffset, now);
    osc.frequency.exponentialRampToValueAtTime(980 + pitchOffset, now + 0.2);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.25);

    const whooshOsc = ctx.createOscillator();
    const whooshFilter = ctx.createBiquadFilter();
    const whooshGain = ctx.createGain();

    whooshOsc.type = 'triangle';
    whooshOsc.frequency.setValueAtTime(170, now);
    whooshOsc.frequency.exponentialRampToValueAtTime(45, now + 0.18);

    whooshFilter.type = 'bandpass';
    whooshFilter.frequency.setValueAtTime(800, now);
    whooshFilter.frequency.exponentialRampToValueAtTime(2200, now + 0.14);
    whooshFilter.Q.value = 2;

    whooshGain.gain.setValueAtTime(0.1, now);
    whooshGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

    whooshOsc.connect(whooshFilter);
    whooshFilter.connect(whooshGain);
    whooshGain.connect(this.sfxGain);

    whooshOsc.start(now);
    whooshOsc.stop(now + 0.2);
  }

  public playBlocked() {
    this.vibrate([40, 30, 40]);
    if (!this.soundEnabled || this.sfxVolume <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(145, now);
    osc.frequency.exponentialRampToValueAtTime(72, now + 0.14);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.15);
  }

  public playHint() {
    if (!this.soundEnabled || this.sfxVolume <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const now = ctx.currentTime;
    const freqs = [784, 987.77, 1174.66];

    freqs.forEach((f, idx) => {
      if (!this.sfxGain) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const delay = idx * 0.06;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, now + delay);

      gain.gain.setValueAtTime(0, now + delay);
      gain.gain.linearRampToValueAtTime(0.12, now + delay + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.34);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now + delay);
      osc.stop(now + delay + 0.35);
    });
  }

  public playStar(starIndex: number = 0) {
    if (!this.soundEnabled || this.sfxVolume <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const now = ctx.currentTime;
    const notes = [659.25, 783.99, 1046.5];
    const f = notes[starIndex % notes.length];

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(f, now);
    osc.frequency.exponentialRampToValueAtTime(f * 1.5, now + 0.24);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.3);
  }

  public playVictory() {
    this.vibrate([60, 40, 80]);
    if (!this.soundEnabled || this.sfxVolume <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const now = ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.51];

    notes.forEach((freq, i) => {
      if (!this.sfxGain) return;
      const noteTime = now + i * 0.095;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = i === notes.length - 1 ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(freq, noteTime);

      gain.gain.setValueAtTime(0, noteTime);
      gain.gain.linearRampToValueAtTime(0.18, noteTime + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.52);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(noteTime);
      osc.stop(noteTime + 0.55);
    });
  }

  public playGameOver() {
    this.vibrate([80, 60, 120]);
    if (!this.soundEnabled || this.sfxVolume <= 0) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const now = ctx.currentTime;
    const notes = [392.0, 349.23, 311.13, 261.63];

    notes.forEach((freq, i) => {
      if (!this.sfxGain) return;
      const noteTime = now + i * 0.15;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, noteTime);

      gain.gain.setValueAtTime(0, noteTime);
      gain.gain.linearRampToValueAtTime(0.12, noteTime + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.34);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(noteTime);
      osc.stop(noteTime + 0.36);
    });
  }

  // --- Ambient Background Music (routed strictly to this.musicGain) ---

  public startMusic() {
    if (!this.musicEnabled || this.musicVolume <= 0) return;
    if (this.musicInterval !== null) return; // Strictly prevent duplicate loops

    const ctx = this.ensureContext();
    if (!ctx || !this.musicGain) return;

    const chords = [
      [261.63, 329.63, 392.0, 493.88], // Cmaj7
      [220.0, 261.63, 329.63, 392.0], // Am7
      [174.61, 220.0, 261.63, 329.63], // Fmaj7
      [196.0, 246.94, 293.66, 349.23], // G7
    ];

    const playChordStep = () => {
      if (!this.musicEnabled || this.musicVolume <= 0 || !this.ctx || !this.musicGain) return;
      if (this.ctx.state !== 'running') return;

      const now = this.ctx.currentTime;
      const currentChord = chords[this.musicStep % chords.length];
      this.musicStep++;

      currentChord.forEach((freq) => {
        if (!this.ctx || !this.musicGain) return;
        const osc = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(560, now);

        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.08, now + 0.45);
        gain.gain.exponentialRampToValueAtTime(0.0005, now + 3.85);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        osc.start(now);
        osc.stop(now + 3.9);
      });
    };

    playChordStep();
    this.musicInterval = window.setInterval(playChordStep, 4000);
  }

  public stopMusic() {
    if (this.musicInterval !== null) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
  }

  public pauseForAd() {
    if (this.ctx && this.ctx.state === 'running') {
      this.ctx.suspend().catch(() => {});
    }
  }

  public resumeAfterAd() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().then(() => {
        this.applyMusicGainImmediate();
        this.applySfxGainImmediate();
      }).catch(() => {});
    }
  }
}

export const sound = new SoundEngine();
