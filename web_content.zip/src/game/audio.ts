// ============================================================
// DEEP DIG — procedural audio designer (WebAudio synthesis)
// ============================================================
import type { SoundKind, Rarity } from "./data";

type NoiseOpts = {
  dur: number; type?: BiquadFilterType; f0: number; f1?: number; q?: number;
  gain?: number; attack?: number; delay?: number;
};
type ToneOpts = {
  f: number; f1?: number; dur: number; type?: OscillatorType; gain?: number; attack?: number; delay?: number; vib?: number;
};

class AudioSys {
  ctx: AudioContext | null = null;
  master!: GainNode;
  sfx!: GainNode;
  amb!: GainNode;
  noiseBuf!: AudioBuffer;
  vol = { master: 0.8, sfx: 1, ambient: 0.7 };
  ambStops: (() => void)[] = [];
  ambTimer: number | null = null;
  ambKind = "";
  lastStep = 0;

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") this.ctx.resume();
      return;
    }
    try {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      if (!AC) return;
      const ctx = new AC();
      this.ctx = ctx;
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -14;
      comp.ratio.value = 4;
      this.master = ctx.createGain();
      this.sfx = ctx.createGain();
      this.amb = ctx.createGain();
      this.sfx.connect(this.master);
      this.amb.connect(this.master);
      this.master.connect(comp);
      comp.connect(ctx.destination);
      const len = ctx.sampleRate * 2;
      this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.applyVolumes();
      if (this.ambKind) {
        const k = this.ambKind;
        this.ambKind = "";
        this.startAmbient(k);
      }
    } catch (e) {
      console.warn("audio init failed", e);
    }
  }

  setVolumes(v: { master: number; sfx: number; ambient: number }) {
    this.vol = { ...v };
    this.applyVolumes();
  }
  private applyVolumes() {
    if (!this.ctx) return;
    this.master.gain.value = this.vol.master;
    this.sfx.gain.value = this.vol.sfx;
    this.amb.gain.value = this.vol.ambient * 0.9;
  }

  // ---------- primitives ----------
  noise(o: NoiseOpts, dest?: AudioNode) {
    const c = this.ctx;
    if (!c) return;
    const t = c.currentTime + (o.delay || 0);
    const src = c.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = c.createBiquadFilter();
    f.type = o.type || "bandpass";
    f.frequency.setValueAtTime(o.f0, t);
    if (o.f1) f.frequency.exponentialRampToValueAtTime(Math.max(20, o.f1), t + o.dur);
    f.Q.value = o.q ?? 0.8;
    const g = c.createGain();
    const peak = o.gain ?? 0.4;
    const at = o.attack ?? 0.005;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + at);
    g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    src.connect(f);
    f.connect(g);
    g.connect(dest || this.sfx);
    src.start(t, Math.random() * 1.5);
    src.stop(t + o.dur + 0.05);
  }
  tone(o: ToneOpts, dest?: AudioNode) {
    const c = this.ctx;
    if (!c) return;
    const t = c.currentTime + (o.delay || 0);
    const osc = c.createOscillator();
    osc.type = o.type || "sine";
    osc.frequency.setValueAtTime(o.f, t);
    if (o.f1) osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.f1), t + o.dur);
    const g = c.createGain();
    const peak = o.gain ?? 0.2;
    const at = o.attack ?? 0.004;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + at);
    g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    if (o.vib) {
      const l = c.createOscillator();
      l.frequency.value = 6;
      const lg = c.createGain();
      lg.gain.value = o.vib;
      l.connect(lg);
      lg.connect(osc.frequency);
      l.start(t);
      l.stop(t + o.dur + 0.05);
    }
    osc.connect(g);
    g.connect(dest || this.sfx);
    osc.start(t);
    osc.stop(t + o.dur + 0.05);
  }

  // ---------- gameplay sounds ----------
  dig(kind: SoundKind) {
    switch (kind) {
      case "dry":
        this.noise({ dur: 0.28, f0: 2200, f1: 700, q: 0.7, gain: 0.5 });
        this.tone({ f: 120, f1: 60, dur: 0.14, gain: 0.25 });
        break;
      case "wet":
        this.noise({ type: "lowpass", dur: 0.34, f0: 900, f1: 300, q: 1.2, gain: 0.6, attack: 0.012 });
        this.tone({ f: 220, f1: 80, dur: 0.2, gain: 0.22 });
        break;
      case "compact":
        this.noise({ dur: 0.16, f0: 1400, f1: 600, q: 1.5, gain: 0.55 });
        this.tone({ f: 140, f1: 70, dur: 0.12, gain: 0.3 });
        break;
      case "clay":
        this.noise({ type: "lowpass", dur: 0.3, f0: 520, f1: 200, q: 1.5, gain: 0.7, attack: 0.02 });
        this.tone({ f: 160, f1: 55, dur: 0.24, gain: 0.3 });
        break;
      case "gravel":
        for (let i = 0; i < 6; i++)
          this.noise({ type: "highpass", dur: 0.05, f0: 2500 + Math.random() * 2500, q: 1, gain: 0.35, delay: i * 0.035 + Math.random() * 0.02 });
        this.noise({ type: "lowpass", dur: 0.3, f0: 500, gain: 0.35 });
        break;
      case "rock":
        this.tone({ f: 900, f1: 600, dur: 0.1, type: "triangle", gain: 0.2 });
        this.noise({ type: "highpass", dur: 0.1, f0: 3500, gain: 0.4 });
        this.tone({ f: 90, f1: 50, dur: 0.16, gain: 0.35 });
        break;
      case "mineral":
        this.tone({ f: 1400, f1: 1300, dur: 0.35, gain: 0.12 });
        this.tone({ f: 2100, dur: 0.25, gain: 0.07, delay: 0.01 });
        this.noise({ type: "highpass", dur: 0.12, f0: 4000, gain: 0.3 });
        this.tone({ f: 100, f1: 55, dur: 0.16, gain: 0.3 });
        break;
    }
  }
  swing() {
    this.noise({ type: "bandpass", dur: 0.22, f0: 600, f1: 1800, q: 0.6, gain: 0.12, attack: 0.08 });
  }
  sandFall() {
    this.noise({ type: "highpass", dur: 0.55, f0: 3200, q: 0.5, gain: 0.22, attack: 0.05 });
    this.noise({ type: "bandpass", dur: 0.4, f0: 1500, f1: 800, gain: 0.15, delay: 0.08 });
  }
  step(running: boolean, kind: SoundKind) {
    const now = performance.now();
    if (now - this.lastStep < 120) return;
    this.lastStep = now;
    const f = kind === "wet" ? 500 : kind === "rock" || kind === "gravel" ? 1800 : 1100;
    this.noise({ type: "lowpass", dur: 0.09, f0: f, q: 0.7, gain: running ? 0.2 : 0.13 });
  }
  jump() {
    this.noise({ type: "lowpass", dur: 0.12, f0: 900, gain: 0.15 });
  }
  land() {
    this.noise({ type: "lowpass", dur: 0.16, f0: 700, f1: 250, gain: 0.3 });
  }
  discover(r: Rarity) {
    const notes: Record<Rarity, number[]> = {
      common: [659, 880],
      uncommon: [659, 880, 1109],
      rare: [523, 659, 784, 1047, 1319],
      legendary: [392, 523, 659, 784, 1047, 1319, 1568],
    };
    const n = notes[r];
    const step = r === "legendary" ? 0.11 : 0.08;
    n.forEach((f, i) => {
      this.tone({ f, dur: 0.5, type: r === "common" ? "triangle" : "sine", gain: 0.16, delay: i * step, vib: r === "legendary" ? 4 : 0 });
      if (r === "rare" || r === "legendary") this.tone({ f: f * 2, dur: 0.4, gain: 0.05, delay: i * step + 0.02 });
    });
    if (r === "rare" || r === "legendary") {
      this.noise({ type: "highpass", dur: 0.9, f0: 5000, gain: 0.12, attack: 0.2, delay: 0.1 });
    }
    if (r === "legendary") {
      [196, 247, 294].forEach((f) => this.tone({ f, dur: 1.8, type: "triangle", gain: 0.12, attack: 0.15, delay: 0.3 }));
    }
  }
  pickup(kind: "coin" | "gem" | "other") {
    if (kind === "coin") {
      this.tone({ f: 1318, dur: 0.1, type: "square", gain: 0.07 });
      this.tone({ f: 1760, dur: 0.25, type: "square", gain: 0.07, delay: 0.07 });
    } else if (kind === "gem") {
      this.tone({ f: 2093, dur: 0.6, gain: 0.12, vib: 8 });
      this.tone({ f: 2637, dur: 0.5, gain: 0.08, delay: 0.06 });
    } else {
      this.tone({ f: 700, f1: 1100, dur: 0.14, type: "triangle", gain: 0.14 });
      this.noise({ type: "lowpass", dur: 0.12, f0: 1500, gain: 0.15 });
    }
  }
  ui() {
    this.tone({ f: 620, f1: 820, dur: 0.07, type: "triangle", gain: 0.12 });
  }
  back() {
    this.tone({ f: 520, f1: 380, dur: 0.08, type: "triangle", gain: 0.1 });
  }
  open() {
    this.noise({ type: "bandpass", dur: 0.2, f0: 400, f1: 1500, gain: 0.12, attack: 0.05 });
    this.tone({ f: 440, f1: 660, dur: 0.12, type: "triangle", gain: 0.08 });
  }
  error() {
    this.tone({ f: 200, f1: 150, dur: 0.18, type: "square", gain: 0.08 });
  }
  equip() {
    this.noise({ type: "highpass", dur: 0.1, f0: 3000, gain: 0.25 });
    this.tone({ f: 900, f1: 1300, dur: 0.12, type: "triangle", gain: 0.1, delay: 0.05 });
  }
  buy() {
    this.tone({ f: 880, dur: 0.1, type: "triangle", gain: 0.15 });
    this.tone({ f: 1175, dur: 0.1, type: "triangle", gain: 0.15, delay: 0.09 });
    this.tone({ f: 1568, dur: 0.3, type: "triangle", gain: 0.15, delay: 0.18 });
  }
  sell(total: number) {
    const n = Math.min(10, 3 + Math.floor(Math.log10(total + 1) * 2));
    for (let i = 0; i < n; i++) {
      this.tone({ f: 1800 + Math.random() * 900, dur: 0.12, type: "square", gain: 0.05, delay: i * 0.06 });
      this.noise({ type: "highpass", dur: 0.05, f0: 5000, gain: 0.12, delay: i * 0.06 });
    }
    this.tone({ f: 1046, dur: 0.12, type: "triangle", gain: 0.15, delay: n * 0.06 });
    this.tone({ f: 1568, dur: 0.5, type: "triangle", gain: 0.15, delay: n * 0.06 + 0.1 });
  }
  achievement() {
    [784, 988, 1175, 1568].forEach((f, i) => this.tone({ f, dur: 0.3, type: "triangle", gain: 0.12, delay: i * 0.08 }));
  }
  levelUp() {
    [523, 659, 784, 1047, 784, 1047, 1319].forEach((f, i) => this.tone({ f, dur: 0.3, type: "triangle", gain: 0.14, delay: i * 0.09 }));
  }
  detector(freq: number, tier: number) {
    this.tone({ f: freq, dur: 0.09, type: "sine", gain: 0.13 });
    this.tone({ f: freq * 2, dur: 0.07, type: "triangle", gain: 0.03 });
    if (tier >= 3) this.tone({ f: freq * 1.5, dur: 0.1, type: "sine", gain: 0.11, delay: 0.11 });
    if (tier === 2) this.tone({ f: freq * 1.25, dur: 0.08, type: "sine", gain: 0.08, delay: 0.1 });
  }
  scanTick() {
    this.tone({ f: 180, dur: 0.04, type: "triangle", gain: 0.03 });
  }
  detectorToggle(on: boolean) {
    this.tone({ f: on ? 400 : 700, f1: on ? 900 : 300, dur: 0.18, type: "square", gain: 0.05 });
  }

  // ---------- ambience ----------
  private loopNoise(type: BiquadFilterType, freq: number, gain: number, lfoHz = 0, lfoDepth = 0, q = 0.7) {
    const c = this.ctx!;
    const src = c.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = c.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    f.Q.value = q;
    const g = c.createGain();
    g.gain.value = gain;
    src.connect(f);
    f.connect(g);
    g.connect(this.amb);
    src.start();
    const stops: (() => void)[] = [() => src.stop()];
    if (lfoHz > 0) {
      const l = c.createOscillator();
      l.frequency.value = lfoHz;
      const lg = c.createGain();
      lg.gain.value = lfoDepth;
      l.connect(lg);
      lg.connect(g.gain);
      l.start();
      stops.push(() => l.stop());
    }
    this.ambStops.push(() => stops.forEach((s) => s()));
  }
  private loopTone(freq: number, gain: number, lfoHz: number, lfoDepth: number) {
    const c = this.ctx!;
    const o = c.createOscillator();
    o.type = "sine";
    o.frequency.value = freq;
    const g = c.createGain();
    g.gain.value = gain;
    o.connect(g);
    g.connect(this.amb);
    o.start();
    const l = c.createOscillator();
    l.frequency.value = lfoHz;
    const lg = c.createGain();
    lg.gain.value = lfoDepth;
    l.connect(lg);
    lg.connect(g.gain);
    l.start();
    this.ambStops.push(() => {
      o.stop();
      l.stop();
    });
  }
  private bird(base: number) {
    const n = 2 + Math.floor(Math.random() * 3);
    for (let i = 0; i < n; i++)
      this.tone({ f: base * (1 + Math.random() * 0.3), f1: base * (1.4 + Math.random() * 0.5), dur: 0.09, gain: 0.05, delay: i * 0.13 }, this.amb);
  }
  startAmbient(kind: string) {
    if (this.ambKind === kind && this.ctx) return;
    this.stopAmbient();
    this.ambKind = kind;
    if (!this.ctx) return;
    switch (kind) {
      case "beach":
        this.loopNoise("lowpass", 700, 0.1, 0.11, 0.08, 0.5);
        this.loopNoise("highpass", 2500, 0.025, 0.13, 0.02);
        this.loopNoise("bandpass", 300, 0.03, 0.05, 0.02);
        break;
      case "desert":
        this.loopNoise("bandpass", 500, 0.09, 0.07, 0.06, 0.6);
        this.loopNoise("highpass", 3000, 0.012, 0.1, 0.01);
        break;
      case "tropical":
        this.loopNoise("lowpass", 600, 0.07, 0.1, 0.05, 0.5);
        this.loopNoise("bandpass", 5000, 0.012, 0.3, 0.008, 4);
        break;
      case "dig":
        this.loopNoise("bandpass", 400, 0.05, 0.06, 0.03, 0.5);
        break;
      case "crystal":
        this.loopTone(110, 0.05, 0.13, 0.03);
        this.loopTone(165.5, 0.035, 0.09, 0.025);
        this.loopTone(220.4, 0.02, 0.17, 0.015);
        this.loopNoise("bandpass", 2000, 0.01, 0.2, 0.006, 3);
        break;
    }
    this.ambTimer = window.setInterval(() => {
      if (!this.ctx) return;
      const r = Math.random();
      if (kind === "beach" && r < 0.18) {
        this.tone({ f: 1700, f1: 1100, dur: 0.35, gain: 0.04, vib: 40 }, this.amb);
        this.tone({ f: 1800, f1: 1200, dur: 0.3, gain: 0.035, delay: 0.4, vib: 40 }, this.amb);
      } else if (kind === "tropical" && r < 0.45) this.bird(2200 + Math.random() * 1200);
      else if (kind === "desert" && r < 0.08) this.noise({ type: "bandpass", dur: 2.5, f0: 300, f1: 900, gain: 0.08, attack: 1 }, this.amb);
      else if (kind === "dig" && r < 0.12) {
        this.tone({ f: 1500, f1: 1450, dur: 0.15, gain: 0.04, type: "triangle" }, this.amb);
        this.tone({ f: 1100, dur: 0.1, gain: 0.03, type: "triangle", delay: 0.2 }, this.amb);
      } else if (kind === "crystal" && r < 0.4) {
        const pent = [523, 587, 659, 784, 880, 1047, 1175];
        this.tone({ f: pent[Math.floor(Math.random() * pent.length)], dur: 1.6, gain: 0.04, attack: 0.02 }, this.amb);
      }
    }, 1400);
  }
  stopAmbient() {
    this.ambStops.forEach((s) => {
      try {
        s();
      } catch {
        /* ignore */
      }
    });
    this.ambStops = [];
    if (this.ambTimer) clearInterval(this.ambTimer);
    this.ambTimer = null;
    this.ambKind = "";
  }
}

export const audio = new AudioSys();
if (typeof window !== "undefined") {
  const unlock = () => audio.init();
  window.addEventListener("pointerdown", unlock, { passive: true });
  window.addEventListener("keydown", unlock);
  window.addEventListener("touchend", unlock, { passive: true });
}
