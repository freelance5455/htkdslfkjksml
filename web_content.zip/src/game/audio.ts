// Fully procedural audio (no external assets)
export class Sfx {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  noise: AudioBuffer | null = null;
  enabled = true;
  started = false;

  init() {
    if (this.started) { this.ctx?.resume(); return; }
    try {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.enabled ? 0.8 : 0;
      this.master.connect(this.ctx.destination);
      const len = this.ctx.sampleRate * 2;
      this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noise.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.started = true;
      this.ambience();
    } catch { /* audio unavailable */ }
  }

  setEnabled(v: boolean) {
    this.enabled = v;
    if (this.master) this.master.gain.value = v ? 0.8 : 0;
  }

  private ambience() {
    const c = this.ctx!;
    const src = c.createBufferSource();
    src.buffer = this.noise; src.loop = true;
    const hp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 900;
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 7000;
    const g = c.createGain(); g.gain.value = 0.09;
    src.connect(hp); hp.connect(lp); lp.connect(g); g.connect(this.master!);
    src.start();
    // dark drone
    for (const [f, v] of [[55, 0.05], [82.4, 0.03], [110.5, 0.015]] as const) {
      const o = c.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f;
      const lf = c.createBiquadFilter(); lf.type = 'lowpass'; lf.frequency.value = 220;
      const og = c.createGain(); og.gain.value = v;
      const lfo = c.createOscillator(); lfo.frequency.value = 0.07 + f / 2000;
      const lg = c.createGain(); lg.gain.value = v * 0.6;
      lfo.connect(lg); lg.connect(og.gain);
      o.connect(lf); lf.connect(og); og.connect(this.master!);
      o.start(); lfo.start();
    }
  }

  private nz(dur: number, f0: number, f1: number, vol: number, type: BiquadFilterType = 'bandpass', q = 1, delay = 0) {
    if (!this.ctx || !this.enabled) return;
    const c = this.ctx, t = c.currentTime + delay;
    const s = c.createBufferSource(); s.buffer = this.noise;
    const f = c.createBiquadFilter(); f.type = type; f.Q.value = q;
    f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + dur * 0.2);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(this.master!);
    s.start(t, Math.random()); s.stop(t + dur + 0.05);
  }

  private tone(f0: number, f1: number, dur: number, vol: number, type: OscillatorType = 'sine', delay = 0) {
    if (!this.ctx || !this.enabled) return;
    const c = this.ctx, t = c.currentTime + delay;
    const o = c.createOscillator(); o.type = type;
    o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(this.master!);
    o.start(t); o.stop(t + dur + 0.05);
  }

  whoosh(heavy: boolean) { this.nz(heavy ? 0.32 : 0.2, 500, heavy ? 2400 : 3200, heavy ? 0.35 : 0.22, 'bandpass', 1.2); }
  hit(heavy: boolean) {
    this.tone(heavy ? 140 : 190, 45, heavy ? 0.28 : 0.18, heavy ? 0.9 : 0.6, 'sine');
    this.nz(heavy ? 0.22 : 0.14, 2600, 300, heavy ? 0.7 : 0.45, 'lowpass', 0.7);
  }
  block() { this.tone(900, 500, 0.12, 0.25, 'triangle'); this.nz(0.1, 3000, 1200, 0.3, 'bandpass', 3); }
  parry() { this.tone(1500, 1100, 0.35, 0.3, 'triangle'); this.tone(2250, 1800, 0.3, 0.15, 'sine', 0.01); this.nz(0.12, 5000, 2000, 0.3, 'highpass'); }
  dodge() { this.nz(0.22, 1500, 400, 0.18, 'bandpass', 0.8); }
  thud() { this.tone(90, 35, 0.35, 0.8, 'sine'); this.nz(0.25, 900, 120, 0.5, 'lowpass'); }
  crack() { this.nz(0.3, 3500, 400, 0.6, 'bandpass', 0.6); this.tone(120, 60, 0.2, 0.4, 'square'); }
  ko() { this.tone(180, 30, 1.2, 0.9, 'sawtooth'); this.nz(0.9, 1200, 80, 0.6, 'lowpass'); }
  thunder() { this.nz(2.4, 380, 50, 0.9, 'lowpass', 0.5); }
  click() { this.tone(660, 440, 0.07, 0.15, 'square'); }
  bell() { this.tone(520, 520, 0.9, 0.22, 'triangle'); this.tone(1040, 1040, 0.6, 0.1, 'sine'); }
  special() { this.tone(200, 900, 0.4, 0.3, 'sawtooth'); }
}

export const sfx = new Sfx();
