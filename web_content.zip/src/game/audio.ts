/**
 * Tiny procedural audio engine — no asset files, everything is synthesised
 * with the WebAudio API so the game stays a single self contained page.
 */

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let osc: OscillatorNode | null = null;
let engineGain: GainNode | null = null;
let engineFilter: BiquadFilterNode | null = null;

function initAudio() {
  if (ctx) return;
  try {
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.55;
    master.connect(ctx.destination);
  } catch {
    ctx = null;
  }
}

export function resumeAudio() {
  initAudio();
  try {
    if (ctx && ctx.state === "suspended") void ctx.resume();
  } catch {
    /* ignore */
  }
}

export function startEngine() {
  initAudio();
  if (!ctx || !master) return;
  try {
    if (ctx.state === "suspended") void ctx.resume();
    stopEngine();
    osc = ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.value = 58;
    engineFilter = ctx.createBiquadFilter();
    engineFilter.type = "lowpass";
    engineFilter.frequency.value = 420;
    engineFilter.Q.value = 3;
    engineGain = ctx.createGain();
    engineGain.gain.value = 0.0001;
    osc.connect(engineFilter);
    engineFilter.connect(engineGain);
    engineGain.connect(master);
    osc.start();
    engineGain.gain.setTargetAtTime(0.11, ctx.currentTime, 0.5);
  } catch {
    /* ignore */
  }
}

export function updateEngine(speed: number, boosting: boolean) {
  if (!ctx || !osc || !engineGain || !engineFilter) return;
  try {
    const t = ctx.currentTime;
    osc.frequency.setTargetAtTime(
      52 + speed * 3.4 + (boosting ? 45 : 0),
      t,
      0.12,
    );
    engineFilter.frequency.setTargetAtTime(
      280 + speed * 26 + (boosting ? 700 : 0),
      t,
      0.15,
    );
    engineGain.gain.setTargetAtTime(boosting ? 0.2 : 0.1, t, 0.2);
  } catch {
    /* ignore */
  }
}

export function stopEngine() {
  try {
    if (osc) {
      osc.stop();
      osc.disconnect();
    }
  } catch {
    /* ignore */
  }
  osc = null;
  engineGain = null;
  engineFilter = null;
}

export function blip(
  freq: number,
  duration = 0.14,
  type: OscillatorType = "sine",
  volume = 0.16,
) {
  initAudio();
  if (!ctx || !master) return;
  try {
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(
      freq * 1.6,
      ctx.currentTime + duration,
    );
    g.gain.setValueAtTime(volume, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
    o.connect(g);
    g.connect(master);
    o.start();
    o.stop(ctx.currentTime + duration + 0.02);
  } catch {
    /* ignore */
  }
}

export function crashSound() {
  initAudio();
  if (!ctx || !master) return;
  try {
    const length = Math.floor(ctx.sampleRate * 0.7);
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, 2.2);
    }
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 1200;
    const gain = ctx.createGain();
    gain.gain.value = 0.5;
    src.connect(filter);
    filter.connect(gain);
    gain.connect(master);
    src.start();
  } catch {
    /* ignore */
  }
}
