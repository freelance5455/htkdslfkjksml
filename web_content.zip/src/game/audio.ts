import type { Sfx } from "@/game/types";

let ctx: AudioContext | null = null;
let noise: AudioBuffer | null = null;

function context(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const AC = window.AudioContext;
  if (!AC) return null;
  if (!ctx) ctx = new AC();
  return ctx;
}

function noiseBuffer(ac: AudioContext): AudioBuffer {
  if (noise && noise.sampleRate === ac.sampleRate) return noise;
  const length = Math.floor(ac.sampleRate * 0.4);
  const buffer = ac.createBuffer(1, length, ac.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
  noise = buffer;
  return buffer;
}

export function unlockAudio() {
  const ac = context();
  if (ac && ac.state === "suspended") void ac.resume();
}

function tone(
  ac: AudioContext,
  freq: number,
  dur: number,
  type: OscillatorType,
  gain: number,
  slide = 0,
) {
  const osc = ac.createOscillator();
  const g = ac.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, ac.currentTime);
  if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), ac.currentTime + dur);
  g.gain.setValueAtTime(gain, ac.currentTime);
  g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + dur);
  osc.connect(g);
  g.connect(ac.destination);
  osc.start();
  osc.stop(ac.currentTime + dur + 0.02);
}

function burst(ac: AudioContext, dur: number, gain: number) {
  const src = ac.createBufferSource();
  src.buffer = noiseBuffer(ac);
  const filter = ac.createBiquadFilter();
  filter.type = "highpass";
  filter.frequency.value = 800;
  const g = ac.createGain();
  g.gain.setValueAtTime(gain, ac.currentTime);
  g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + dur);
  src.connect(filter);
  filter.connect(g);
  g.connect(ac.destination);
  src.start();
  src.stop(ac.currentTime + dur);
}

export function playSfx(name: Sfx) {
  const ac = context();
  if (!ac || ac.state !== "running") return;
  switch (name) {
    case "shoot":
      tone(ac, 880, 0.045, "square", 0.025, 220);
      break;
    case "hit":
      tone(ac, 240, 0.05, "square", 0.02, -80);
      break;
    case "explode":
      burst(ac, 0.18, 0.05);
      tone(ac, 180, 0.16, "sawtooth", 0.03, -120);
      break;
    case "hurt":
      burst(ac, 0.22, 0.06);
      tone(ac, 110, 0.24, "sawtooth", 0.04, -70);
      break;
    case "pickup":
      tone(ac, 660, 0.07, "square", 0.03);
      tone(ac, 880, 0.08, "square", 0.028);
      tone(ac, 1180, 0.1, "square", 0.026);
      break;
    case "wave":
      tone(ac, 440, 0.12, "triangle", 0.03, 220);
      break;
    case "boss":
      tone(ac, 98, 0.35, "sawtooth", 0.04, -40);
      tone(ac, 196, 0.28, "square", 0.02, 80);
      break;
    default:
      break;
  }
}
