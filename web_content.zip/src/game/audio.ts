/* Tiny procedural sound kit — no audio files, all synthesized on demand. */

export class AudioKit {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  muted = false;

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    try {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return;
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.32;
      this.master.connect(this.ctx.destination);
      const len = Math.floor(this.ctx.sampleRate * 0.5);
      this.noiseBuffer = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const data = this.noiseBuffer.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    } catch {
      this.ctx = null;
    }
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(muted ? 0 : 0.32, this.ctx.currentTime, 0.03);
    }
  }

  private tone(
    freq: number,
    duration: number,
    opts: { type?: OscillatorType; gain?: number; slideTo?: number; delay?: number } = {},
  ) {
    if (!this.ctx || !this.master || this.muted) return;
    const { type = "sine", gain = 0.2, slideTo, delay = 0 } = opts;
    const t0 = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(30, freq), t0);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(30, slideTo), t0 + duration);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + Math.min(0.02, duration * 0.3));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
    osc.connect(g);
    g.connect(this.master);
    osc.start(t0);
    osc.stop(t0 + duration + 0.03);
  }

  private hiss(duration: number, gain: number, freq: number, delay = 0) {
    if (!this.ctx || !this.master || !this.noiseBuffer || this.muted) return;
    const t0 = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(freq, t0);
    filter.frequency.exponentialRampToValueAtTime(Math.max(120, freq * 0.32), t0 + duration);
    filter.Q.value = 0.9;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
    src.connect(filter);
    filter.connect(g);
    g.connect(this.master);
    src.start(t0);
    src.stop(t0 + duration + 0.02);
  }

  pickup(combo: number) {
    const step = Math.min(combo, 6);
    const scale = [523.25, 587.33, 659.25, 783.99, 880, 1046.5, 1174.66];
    this.tone(scale[step - 1] ?? 523.25, 0.16, { type: "triangle", gain: 0.16 });
    this.tone((scale[step - 1] ?? 523.25) * 2, 0.09, { type: "sine", gain: 0.06, delay: 0.035 });
  }

  slash() {
    this.hiss(0.18, 0.16, 2200);
    this.tone(180, 0.1, { type: "sawtooth", gain: 0.05, slideTo: 100 });
  }

  hit() {
    this.tone(105, 0.16, { type: "square", gain: 0.1, slideTo: 58 });
    this.hiss(0.12, 0.1, 900);
  }

  hurt() {
    this.tone(160, 0.34, { type: "sawtooth", gain: 0.14, slideTo: 60 });
    this.hiss(0.22, 0.08, 500);
  }

  dash() {
    this.hiss(0.26, 0.12, 1500);
    this.tone(260, 0.2, { type: "sine", gain: 0.05, slideTo: 540 });
  }

  shrine() {
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) =>
      this.tone(f, 0.6, { type: "sine", gain: 0.1, delay: i * 0.07 }),
    );
  }

  cycle() {
    [392, 523.25, 659.25, 783.99, 1046.5].forEach((f, i) =>
      this.tone(f, 0.7, { type: "triangle", gain: 0.12, delay: i * 0.09 }),
    );
  }

  heal() {
    this.tone(440, 0.18, { type: "sine", gain: 0.1 });
    this.tone(660, 0.22, { type: "sine", gain: 0.08, delay: 0.08 });
  }

  deny() {
    this.tone(140, 0.1, { type: "square", gain: 0.05 });
  }

  death() {
    [440, 349.23, 261.63, 174.61].forEach((f, i) =>
      this.tone(f, 0.55, { type: "triangle", gain: 0.13, delay: i * 0.12 }),
    );
    this.hiss(0.8, 0.1, 340, 0.1);
  }

  spawn() {
    this.tone(90, 0.4, { type: "sine", gain: 0.08, slideTo: 48 });
  }

  dispose() {
    if (this.ctx) {
      void this.ctx.close().catch(() => undefined);
      this.ctx = null;
    }
  }
}
