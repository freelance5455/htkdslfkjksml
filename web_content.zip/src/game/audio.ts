// Procedural sound effects via WebAudio — no asset files required.

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  muted = false;
  private lastMoan = 0;

  constructor() {
    try {
      this.muted = localStorage.getItem('zs_muted') === '1';
    } catch {
      /* ignore */
    }
  }

  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.55;
      this.master.connect(this.ctx.destination);
      // 1s of white noise reused by many effects
      const len = this.ctx.sampleRate;
      this.noiseBuffer = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuffer.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    try {
      localStorage.setItem('zs_muted', m ? '1' : '0');
    } catch {
      /* ignore */
    }
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.55, this.ctx.currentTime, 0.02);
    }
  }

  private noise(duration: number, gain: number, filterType: BiquadFilterType, freqStart: number, freqEnd: number, q = 1) {
    if (!this.ctx || !this.master || !this.noiseBuffer) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = true;
    const filt = this.ctx.createBiquadFilter();
    filt.type = filterType;
    filt.frequency.setValueAtTime(freqStart, t);
    filt.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t + duration);
    filt.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    src.connect(filt).connect(g).connect(this.master);
    src.start(t);
    src.stop(t + duration + 0.02);
  }

  private tone(freqStart: number, freqEnd: number, duration: number, gain: number, type: OscillatorType = 'sine', delay = 0) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freqStart, t);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t + duration);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    osc.connect(g).connect(this.master);
    osc.start(t);
    osc.stop(t + duration + 0.02);
  }

  shot() {
    if (!this.ctx) return;
    this.noise(0.35, 0.9, 'lowpass', 6000, 200, 0.7);
    this.noise(0.08, 0.5, 'highpass', 2000, 4000);
    this.tone(160, 40, 0.3, 0.8, 'sine');
    this.tone(90, 30, 0.5, 0.5, 'triangle');
  }

  bolt() {
    this.noise(0.04, 0.35, 'bandpass', 2500, 1800, 3);
    this.noise(0.05, 0.3, 'bandpass', 1500, 900, 3);
    this.tone(900, 400, 0.05, 0.15, 'square', 0.12);
  }

  empty() {
    this.noise(0.03, 0.4, 'bandpass', 3000, 2000, 4);
    this.tone(1200, 600, 0.04, 0.2, 'square');
  }

  reloadStart() {
    this.noise(0.06, 0.4, 'bandpass', 1200, 600, 3);
    this.tone(500, 200, 0.08, 0.2, 'square');
  }

  reloadEnd() {
    this.noise(0.05, 0.45, 'bandpass', 2000, 1200, 3);
    this.tone(700, 1100, 0.06, 0.25, 'square', 0.03);
  }

  hit() {
    this.noise(0.15, 0.6, 'lowpass', 1200, 200);
    this.tone(220, 60, 0.15, 0.4, 'triangle');
  }

  headshot() {
    this.noise(0.25, 0.8, 'lowpass', 2500, 150);
    this.tone(1600, 2200, 0.12, 0.25, 'sine');
    this.tone(180, 50, 0.25, 0.6, 'triangle');
  }

  miss() {
    this.noise(0.12, 0.3, 'bandpass', 800, 300, 1.5);
  }

  damage() {
    this.noise(0.5, 0.9, 'lowpass', 900, 100);
    this.tone(120, 35, 0.6, 0.7, 'sawtooth');
    this.tone(60, 25, 0.7, 0.5, 'square');
  }

  moan(force = false) {
    if (!this.ctx || !this.master) return;
    const now = this.ctx.currentTime;
    if (!force && now - this.lastMoan < 1.6) return;
    this.lastMoan = now;
    const t = now;
    const base = 70 + Math.random() * 50;
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(base, t);
    osc.frequency.linearRampToValueAtTime(base * 1.3, t + 0.4);
    osc.frequency.linearRampToValueAtTime(base * 0.8, t + 1.1);
    const lfo = this.ctx.createOscillator();
    lfo.frequency.value = 6;
    const lfoG = this.ctx.createGain();
    lfoG.gain.value = 8;
    lfo.connect(lfoG).connect(osc.frequency);
    const filt = this.ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.frequency.value = 500;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.12, t + 0.25);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.2);
    osc.connect(filt).connect(g).connect(this.master);
    osc.start(t);
    lfo.start(t);
    osc.stop(t + 1.3);
    lfo.stop(t + 1.3);
  }

  combo(level: number) {
    const f = 500 + level * 120;
    this.tone(f, f * 1.5, 0.12, 0.2, 'square');
    this.tone(f * 1.5, f * 2, 0.15, 0.15, 'square', 0.08);
  }

  ui() {
    this.tone(800, 1200, 0.06, 0.15, 'square');
  }

  gameOver() {
    this.tone(300, 60, 1.2, 0.5, 'sawtooth');
    this.tone(200, 40, 1.4, 0.4, 'triangle', 0.1);
    this.noise(1.0, 0.4, 'lowpass', 800, 80);
  }
}

export const audio = new AudioEngine();
