/* Tiny WebAudio synth for juicy game SFX — no assets needed. */
let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let muted = localStorage.getItem("wildcycle_muted") === "1";

function ensure() {
  if (!ctx) {
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = muted ? 0 : 0.5;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") ctx.resume();
  return ctx;
}

export function unlockAudio() {
  ensure();
}

export function setMuted(m: boolean) {
  muted = m;
  localStorage.setItem("wildcycle_muted", m ? "1" : "0");
  if (master && ctx) master.gain.setTargetAtTime(m ? 0 : 0.5, ctx.currentTime, 0.02);
}

export function isMuted() {
  return muted;
}

function tone(
  freq: number,
  dur: number,
  type: OscillatorType = "sine",
  vol = 0.3,
  slideTo?: number,
  delay = 0
) {
  const c = ensure();
  if (!c || !master) return;
  const t0 = c.currentTime + delay;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t0);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(30, slideTo), t0 + dur);
  g.gain.setValueAtTime(vol, t0);
  g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
  o.connect(g).connect(master);
  o.start(t0);
  o.stop(t0 + dur + 0.02);
}

function noise(dur: number, vol = 0.25, freq = 1200, delay = 0) {
  const c = ensure();
  if (!c || !master) return;
  const t0 = c.currentTime + delay;
  const len = Math.max(1, Math.floor(c.sampleRate * dur));
  const buf = c.createBuffer(1, len, c.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const src = c.createBufferSource();
  src.buffer = buf;
  const f = c.createBiquadFilter();
  f.type = "bandpass";
  f.frequency.value = freq;
  f.Q.value = 0.8;
  const g = c.createGain();
  g.gain.setValueAtTime(vol, t0);
  g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
  src.connect(f).connect(g).connect(master);
  src.start(t0);
}

export const sfx = {
  lunge() {
    noise(0.14, 0.18, 900);
    tone(300, 0.12, "triangle", 0.1, 140);
  },
  hit() {
    noise(0.08, 0.3, 500);
    tone(180, 0.09, "square", 0.12, 90);
  },
  kill(combo = 1) {
    noise(0.1, 0.25, 700);
    tone(420 + combo * 60, 0.1, "triangle", 0.25);
    tone(630 + combo * 90, 0.16, "triangle", 0.22, undefined, 0.06);
  },
  ambush() {
    tone(520, 0.09, "triangle", 0.25);
    tone(780, 0.1, "triangle", 0.25, undefined, 0.07);
    tone(1040, 0.18, "triangle", 0.22, undefined, 0.14);
  },
  hurt() {
    noise(0.18, 0.35, 250);
    tone(140, 0.22, "sawtooth", 0.2, 60);
  },
  evolve() {
    [262, 330, 392, 523, 659, 784].forEach((f, i) =>
      tone(f, 0.35, "triangle", 0.22, undefined, i * 0.09)
    );
    noise(0.6, 0.12, 2000, 0.1);
  },
  alert() {
    tone(880, 0.07, "square", 0.08, 660);
  },
  gameOver() {
    [330, 262, 208, 156].forEach((f, i) => tone(f, 0.4, "sawtooth", 0.14, undefined, i * 0.18));
  },
  victory() {
    [523, 659, 784, 1047, 784, 1047, 1319].forEach((f, i) =>
      tone(f, 0.4, "triangle", 0.2, undefined, i * 0.13)
    );
  },
  click() {
    tone(600, 0.06, "triangle", 0.15, 400);
  },
  splash() {
    noise(0.2, 0.15, 600);
  },
};