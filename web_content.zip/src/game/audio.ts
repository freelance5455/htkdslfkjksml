// Fully synthesized audio (WebAudio) so there are no external sound assets.
import { clamp } from './util';

export class AudioEngine {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  private engineOsc: OscillatorNode[] = [];
  private engineGain: GainNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private rainGain: GainNode | null = null;
  private rainSrc: AudioBufferSourceNode | null = null;
  private windGain: GainNode | null = null;
  private windSrc: AudioBufferSourceNode | null = null;
  private sirenOsc: OscillatorNode | null = null;
  private sirenGain: GainNode | null = null;
  private sirenLfo: OscillatorNode | null = null;
  enabled = true;
  volume = 0.7;

  init() {
    if (this.ctx) return;
    const Ctor = (window as any).AudioContext || (window as any).webkitAudioContext;
    if (!Ctor) return;
    const ctx: AudioContext = new Ctor();
    this.ctx = ctx;
    const master = ctx.createGain();
    this.master = master;
    master.gain.value = this.volume;
    master.connect(ctx.destination);
  }

  resume() {
    this.init();
    const c = this.ctx;
    if (c && c.state === 'suspended') void c.resume();
  }

  setVolume(v: number) {
    this.volume = clamp(v, 0, 1);
    if (this.master) this.master.gain.value = this.volume;
  }

  private noiseBuffer(dur = 1) {
    const ctx = this.ctx!;
    const len = Math.floor(ctx.sampleRate * dur);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    return buf;
  }

  private env(gain: GainNode, peak: number, attack: number, decay: number) {
    const t = this.ctx!.currentTime;
    gain.gain.cancelScheduledValues(t);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0001, peak), t + attack);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
  }

  shot(type: 'pistol' | 'rifle' | 'sniper' | 'rpg' = 'pistol') {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const g = ctx.createGain();
    const filt = ctx.createBiquadFilter();
    filt.type = 'lowpass';
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer(0.5);
    filt.connect(g);
    g.connect(this.master);
    const cfg = {
      pistol: { peak: 0.5, attack: 0.002, decay: 0.16, cut: 2600 },
      rifle: { peak: 0.42, attack: 0.002, decay: 0.1, cut: 3600 },
      sniper: { peak: 0.75, attack: 0.001, decay: 0.5, cut: 1800 },
      rpg: { peak: 0.6, attack: 0.005, decay: 0.4, cut: 1200 },
    }[type];
    filt.frequency.setValueAtTime(cfg.cut, ctx.currentTime);
    filt.frequency.exponentialRampToValueAtTime(300, ctx.currentTime + cfg.decay);
    this.env(g, cfg.peak, cfg.attack, cfg.decay);
    src.start();
    src.stop(ctx.currentTime + cfg.decay + 0.05);
    // low body thump
    const osc = ctx.createOscillator();
    const og = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(type === 'sniper' ? 140 : 190, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(45, ctx.currentTime + 0.2);
    this.env(og, cfg.peak * 0.7, 0.002, 0.2);
    osc.connect(og);
    og.connect(this.master);
    osc.start();
    osc.stop(ctx.currentTime + 0.3);
  }

  explosion() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer(1.4);
    const filt = ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.frequency.setValueAtTime(1400, ctx.currentTime);
    filt.frequency.exponentialRampToValueAtTime(90, ctx.currentTime + 1.1);
    const g = ctx.createGain();
    filt.connect(g);
    g.connect(this.master);
    this.env(g, 0.9, 0.005, 1.2);
    src.start();
    src.stop(ctx.currentTime + 1.4);
    const osc = ctx.createOscillator();
    const og = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(90, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(28, ctx.currentTime + 0.8);
    this.env(og, 0.8, 0.005, 0.8);
    osc.connect(og);
    og.connect(this.master);
    osc.start();
    osc.stop(ctx.currentTime + 1);
  }

  hit() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx || !this.master) return;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(900, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(180, this.ctx.currentTime + 0.12);
    this.env(g, 0.16, 0.003, 0.12);
    osc.connect(g);
    g.connect(this.master);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.2);
  }

  footstep(running = false) {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer(0.15);
    const f = ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = 380 + Math.random() * 260;
    const g = ctx.createGain();
    f.connect(g);
    g.connect(this.master);
    this.env(g, running ? 0.16 : 0.09, 0.004, running ? 0.1 : 0.14);
    src.start();
    src.stop(ctx.currentTime + 0.2);
  }

  beep(freq = 880, dur = 0.09, type: OscillatorType = 'sine', vol = 0.16) {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx || !this.master) return;
    const osc = this.ctx!.createOscillator();
    const g = this.ctx!.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    this.env(g, vol, 0.005, dur);
    osc.connect(g);
    g.connect(this.master);
    osc.start();
    osc.stop(this.ctx.currentTime + dur + 0.05);
  }

  click() {
    this.beep(520, 0.05, 'triangle', 0.08);
  }
  pickup() {
    this.beep(660, 0.08, 'sine', 0.14);
    setTimeout(() => this.beep(990, 0.1, 'sine', 0.12), 70);
  }
  notify() {
    this.beep(880, 0.06, 'sine', 0.1);
    setTimeout(() => this.beep(1320, 0.12, 'sine', 0.09), 90);
  }
  error() {
    this.beep(180, 0.18, 'sawtooth', 0.1);
  }

  horn(kind: 'car' | 'truck' = 'car') {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const base = kind === 'car' ? 370 : 210;
    const g = ctx.createGain();
    g.connect(this.master);
    this.env(g, 0.16, 0.01, kind === 'car' ? 0.5 : 0.9);
    [1, 1.5].forEach((m, i) => {
      const o = ctx.createOscillator();
      o.type = 'square';
      o.frequency.value = base * m;
      const og = ctx.createGain();
      og.gain.value = i === 0 ? 0.7 : 0.3;
      o.connect(og);
      og.connect(g);
      o.start();
      o.stop(ctx.currentTime + 1);
    });
  }

  /** Continuous vehicle engine. rpm 0..1 */
  setEngine(active: boolean, rpm = 0.2, load = 0) {
    this.init();
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    if (active && !this.engineGain) {
      this.engineGain = ctx.createGain();
      this.engineGain.gain.value = 0;
      this.engineFilter = ctx.createBiquadFilter();
      this.engineFilter.type = 'lowpass';
      this.engineFilter.frequency.value = 900;
      this.engineFilter.connect(this.engineGain);
      this.engineGain.connect(this.master);
      this.engineOsc = [];
      [1, 2.01, 0.5].forEach((mult, i) => {
        const o = ctx.createOscillator();
        o.type = i === 2 ? 'square' : 'sawtooth';
        o.frequency.value = 60 * mult;
        const og = ctx.createGain();
        og.gain.value = i === 0 ? 0.6 : i === 1 ? 0.22 : 0.12;
        o.connect(og);
        og.connect(this.engineFilter!);
        o.start();
        this.engineOsc.push(o);
      });
    }
    if (!this.engineGain) return;
    const t = ctx.currentTime;
    const base = 42 + rpm * 165;
    this.engineOsc.forEach((o, i) => {
      const mult = i === 0 ? 1 : i === 1 ? 2.01 : 0.5;
      o.frequency.setTargetAtTime(base * mult, t, 0.06);
    });
    this.engineFilter!.frequency.setTargetAtTime(500 + rpm * 2400 + load * 400, t, 0.1);
    this.engineGain.gain.setTargetAtTime(active ? 0.1 + load * 0.12 + rpm * 0.05 : 0, t, 0.15);
  }

  setRain(intensity: number) {
    this.init();
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    if (!this.rainGain) {
      this.rainGain = ctx.createGain();
      this.rainGain.gain.value = 0;
      const filt = ctx.createBiquadFilter();
      filt.type = 'highpass';
      filt.frequency.value = 700;
      filt.connect(this.rainGain);
      this.rainGain.connect(this.master);
      this.rainSrc = ctx.createBufferSource();
      this.rainSrc.buffer = this.noiseBuffer(2);
      this.rainSrc.loop = true;
      this.rainSrc.connect(filt);
      this.rainSrc.start();
    }
    this.rainGain.gain.setTargetAtTime(clamp(intensity, 0, 1) * 0.16, ctx.currentTime, 0.6);
  }

  setWind(intensity: number) {
    this.init();
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    if (!this.windGain) {
      this.windGain = ctx.createGain();
      this.windGain.gain.value = 0;
      const filt = ctx.createBiquadFilter();
      filt.type = 'lowpass';
      filt.frequency.value = 420;
      filt.connect(this.windGain);
      this.windGain.connect(this.master);
      this.windSrc = ctx.createBufferSource();
      this.windSrc.buffer = this.noiseBuffer(3);
      this.windSrc.loop = true;
      this.windSrc.connect(filt);
      this.windSrc.start();
    }
    this.windGain.gain.setTargetAtTime(clamp(intensity, 0, 1) * 0.09, ctx.currentTime, 0.9);
  }

  setSiren(active: boolean) {
    this.init();
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    if (active && !this.sirenOsc) {
      this.sirenGain = ctx.createGain();
      this.sirenGain.gain.value = 0;
      this.sirenGain.connect(this.master);
      this.sirenOsc = ctx.createOscillator();
      this.sirenOsc.type = 'sawtooth';
      this.sirenOsc.frequency.value = 700;
      this.sirenLfo = ctx.createOscillator();
      this.sirenLfo.type = 'sine';
      this.sirenLfo.frequency.value = 0.7;
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = 260;
      this.sirenLfo.connect(lfoGain);
      lfoGain.connect(this.sirenOsc.frequency);
      this.sirenOsc.connect(this.sirenGain);
      this.sirenOsc.start();
      this.sirenLfo.start();
    }
    if (this.sirenGain)
      this.sirenGain.gain.setTargetAtTime(active ? 0.07 : 0, ctx.currentTime, 0.4);
  }
}

export const audio = new AudioEngine();
