/** Procedural 4-cylinder: lope, exhaust, overrun crackle. No samples. */

export class CarAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private engineGain: GainNode | null = null;
  private noiseGain: GainNode | null = null;
  private roadGain: GainNode | null = null;
  private windGain: GainNode | null = null;
  private lpf: BiquadFilterNode | null = null;
  private noiseBand: BiquadFilterNode | null = null;
  private sub: OscillatorNode | null = null;
  private saw: OscillatorNode | null = null;
  private harm: OscillatorNode | null = null;
  private subG: GainNode | null = null;
  private sawG: GainNode | null = null;
  private harmG: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private alive = false;
  private muted = false;
  private lastPop = 0;
  private wantVol = 1;

  resume() {
    if (!this.ctx) this.build();
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    this.pushMaster();
  }

  private pushMaster() {
    if (!this.ctx || !this.master) return;
    const v = this.muted ? 0 : this.wantVol;
    this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.03);
  }

  private build() {
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AC({ latencyHint: "interactive" });
    this.ctx = ctx;

    const master = ctx.createGain();
    master.gain.value = 0.9;
    master.connect(ctx.destination);
    this.master = master;

    const engineGain = ctx.createGain();
    engineGain.gain.value = 0.0001;
    this.engineGain = engineGain;

    const lpf = ctx.createBiquadFilter();
    lpf.type = "lowpass";
    lpf.frequency.value = 420;
    lpf.Q.value = 0.7;
    this.lpf = lpf;

    const shaper = ctx.createWaveShaper();
    shaper.curve = distort(2.4);
    shaper.oversample = "2x";

    const sub = ctx.createOscillator();
    sub.type = "sine";
    sub.frequency.value = 28;
    const subG = ctx.createGain();
    subG.gain.value = 0.55;
    sub.connect(subG);
    subG.connect(shaper);
    this.sub = sub;
    this.subG = subG;

    const saw = ctx.createOscillator();
    saw.type = "sawtooth";
    saw.frequency.value = 55;
    const sawG = ctx.createGain();
    sawG.gain.value = 0.22;
    saw.connect(sawG);
    sawG.connect(shaper);
    this.saw = saw;
    this.sawG = sawG;

    const harm = ctx.createOscillator();
    harm.type = "triangle";
    harm.frequency.value = 110;
    const harmG = ctx.createGain();
    harmG.gain.value = 0.08;
    harm.connect(harmG);
    harmG.connect(shaper);
    this.harm = harm;
    this.harmG = harmG;

    shaper.connect(lpf);
    lpf.connect(engineGain);
    engineGain.connect(master);

    const noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const data = noiseBuf.getChannelData(0);
    let b0 = 0;
    let b1 = 0;
    let b2 = 0;
    for (let i = 0; i < data.length; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.997 * b0 + 0.003 * white;
      b1 = 0.96 * b1 + 0.04 * white;
      b2 = 0.7 * b2 + 0.3 * white;
      data[i] = (b1 * 0.7 + b2 * 0.3) * 1.6;
    }
    this.noiseBuf = noiseBuf;

    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuf;
    noise.loop = true;
    const noiseBand = ctx.createBiquadFilter();
    noiseBand.type = "bandpass";
    noiseBand.frequency.value = 280;
    noiseBand.Q.value = 0.65;
    const noiseGain = ctx.createGain();
    noiseGain.gain.value = 0.0001;
    noise.connect(noiseBand);
    noiseBand.connect(noiseGain);
    noiseGain.connect(master);
    noise.start();
    this.noiseBand = noiseBand;
    this.noiseGain = noiseGain;

    const road = ctx.createBufferSource();
    road.buffer = noiseBuf;
    road.loop = true;
    const roadF = ctx.createBiquadFilter();
    roadF.type = "bandpass";
    roadF.frequency.value = 180;
    roadF.Q.value = 0.45;
    const roadGain = ctx.createGain();
    roadGain.gain.value = 0;
    road.connect(roadF);
    roadF.connect(roadGain);
    roadGain.connect(master);
    road.start();
    this.roadGain = roadGain;

    const wind = ctx.createBufferSource();
    wind.buffer = noiseBuf;
    wind.loop = true;
    const windF = ctx.createBiquadFilter();
    windF.type = "highpass";
    windF.frequency.value = 700;
    const windGain = ctx.createGain();
    windGain.gain.value = 0;
    wind.connect(windF);
    windF.connect(windGain);
    windGain.connect(master);
    wind.start();
    this.windGain = windGain;

    sub.start();
    saw.start();
    harm.start();
    this.alive = true;
  }

  update(rpm: number, throttle: number, speed: number, overrun: number, edge: number) {
    if (!this.alive || !this.ctx || !this.saw || !this.sub || !this.harm) return;
    const t = this.ctx.currentTime;
    const firing = Math.max(16, (rpm / 60) * 2);
    this.sub.frequency.setTargetAtTime(firing * 0.5, t, 0.04);
    this.saw.frequency.setTargetAtTime(firing, t, 0.035);
    this.harm.frequency.setTargetAtTime(firing * 2.02, t, 0.04);

    const load = 0.35 + throttle * 0.9;
    this.sawG?.gain.setTargetAtTime(0.14 + throttle * 0.16, t, 0.05);
    this.subG?.gain.setTargetAtTime(0.45 + (1 - throttle) * 0.2, t, 0.05);
    this.harmG?.gain.setTargetAtTime(0.04 + throttle * 0.09, t, 0.05);

    const cutoff = 260 + throttle * 2400 + (rpm / 7000) * 1600 + overrun * 400;
    this.lpf?.frequency.setTargetAtTime(Math.min(5200, cutoff), t, 0.045);

    const vol = (0.07 + throttle * 0.16 + (rpm / 7000) * 0.1) * (0.85 + load * 0.15);
    this.engineGain?.gain.setTargetAtTime(vol, t, 0.04);

    const nVol = 0.015 + throttle * 0.07 + overrun * 0.05 + (rpm / 7000) * 0.02;
    this.noiseGain?.gain.setTargetAtTime(nVol, t, 0.05);
    this.noiseBand?.frequency.setTargetAtTime(220 + throttle * 900 + overrun * 700, t, 0.05);

    const sp = Math.max(0, speed);
    this.roadGain?.gain.setTargetAtTime(Math.min(0.12, sp * 0.004 + edge * 0.05), t, 0.08);
    this.windGain?.gain.setTargetAtTime(Math.min(0.07, sp * sp * 0.00004), t, 0.1);
  }

  /** strengths drained by caller after. */
  pops(strengths: number[]) {
    if (!this.alive || !this.ctx || !this.noiseBuf || !this.master || strengths.length === 0) return;
    const now = this.ctx.currentTime;
    let when = Math.max(now + 0.012, this.lastPop + 0.038);
    const n = Math.min(4, strengths.length);
    for (let i = 0; i < n; i++) {
      this.burst(when, strengths[i] ?? 0.4);
      when += 0.04 + Math.random() * 0.075;
    }
    this.lastPop = when;
  }

  click() {
    if (!this.alive || !this.ctx || !this.master) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = "square";
    o.frequency.setValueAtTime(140, t);
    o.frequency.exponentialRampToValueAtTime(48, t + 0.07);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.12, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.09);
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 500;
    o.connect(f);
    f.connect(g);
    g.connect(this.master);
    o.start(t);
    o.stop(t + 0.1);
  }

  private burst(when: number, strength: number) {
    if (!this.ctx || !this.master || !this.noiseBuf) return;
    const ctx = this.ctx;
    const s = Math.max(0.15, Math.min(1.3, strength));
    const dur = 0.055 + Math.random() * 0.06;
    const freq = 90 + Math.random() * 80;

    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.setValueAtTime(freq * (1.4 + Math.random() * 0.6), when);
    osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq * 0.45), when + dur);
    const og = ctx.createGain();
    og.gain.setValueAtTime(0.0001, when);
    og.gain.exponentialRampToValueAtTime(0.16 * s, when + 0.008);
    og.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    osc.connect(og);
    og.connect(this.master);
    osc.start(when);
    osc.stop(when + dur + 0.02);

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.setValueAtTime(900 + Math.random() * 1800, when);
    bp.frequency.exponentialRampToValueAtTime(280, when + dur);
    bp.Q.value = 0.8;
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.0001, when);
    ng.gain.exponentialRampToValueAtTime(0.22 * s, when + 0.005);
    ng.gain.exponentialRampToValueAtTime(0.0001, when + dur * 0.85);
    src.connect(bp);
    bp.connect(ng);
    ng.connect(this.master);
    const offset = Math.random() * (this.noiseBuf.duration - dur - 0.05);
    src.start(when, offset, dur);

    src.onended = () => {
      src.disconnect();
      bp.disconnect();
      ng.disconnect();
      osc.disconnect();
      og.disconnect();
    };
  }

  dispose() {
    this.alive = false;
    if (this.ctx) void this.ctx.close();
    this.ctx = null;
  }
}

function distort(amount: number) {
  const n = 256;
  const curve = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const x = (i / (n - 1)) * 2 - 1;
    curve[i] = Math.tanh(x * amount);
  }
  return curve;
}
