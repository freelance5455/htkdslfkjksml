// Procedural audio engine: every sound is synthesised at runtime (no external assets).
import type { SoundProfile } from './data/weapons';
import { store } from './save';

type Vec = { x: number; y: number; z: number };

class AudioSystem {
  ctx: AudioContext | null = null;
  master!: GainNode; music!: GainNode; sfx!: GainNode; dialogue!: GainNode;
  private noise!: AudioBuffer;
  private voices = 0;
  private readonly MAX_VOICES = 28;
  private musicNodes: AudioNode[] = [];
  private musicTimer: number | null = null;
  private ambientNodes: AudioNode[] = [];
  private lastPlay: Record<string, number> = {};

  /** Must be called from a user gesture */
  unlock() {
    if (!this.ctx) {
      try {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.ctx = new AC();
        this.master = this.ctx.createGain(); this.master.connect(this.ctx.destination);
        const comp = this.ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
        comp.connect(this.master);
        this.music = this.ctx.createGain(); this.music.connect(comp);
        this.sfx = this.ctx.createGain(); this.sfx.connect(comp);
        this.dialogue = this.ctx.createGain(); this.dialogue.connect(comp);
        const len = this.ctx.sampleRate * 1.5;
        this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
        const d = this.noise.getChannelData(0);
        for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
        this.applyVolumes();
        store.subscribe(() => this.applyVolumes());
      } catch (e) { console.warn('Audio unavailable', e); this.ctx = null; return; }
    }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
  }

  applyVolumes() {
    if (!this.ctx) return;
    const a = store.settings.audio, t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(a.master, t, 0.05);
    this.music.gain.setTargetAtTime(a.music * 0.55, t, 0.05);
    this.sfx.gain.setTargetAtTime(a.sfx, t, 0.05);
    this.dialogue.gain.setTargetAtTime(a.dialogue, t, 0.05);
  }

  setListener(pos: Vec, fwd: Vec) {
    if (!this.ctx) return;
    const l = this.ctx.listener; const t = this.ctx.currentTime;
    if (l.positionX) {
      l.positionX.setValueAtTime(pos.x, t); l.positionY.setValueAtTime(pos.y, t); l.positionZ.setValueAtTime(pos.z, t);
      l.forwardX.setValueAtTime(fwd.x, t); l.forwardY.setValueAtTime(fwd.y, t); l.forwardZ.setValueAtTime(fwd.z, t);
      l.upX.setValueAtTime(0, t); l.upY.setValueAtTime(1, t); l.upZ.setValueAtTime(0, t);
    } else {
      (l as unknown as { setPosition: (x: number, y: number, z: number) => void }).setPosition(pos.x, pos.y, pos.z);
    }
  }

  private take(dur: number, throttleKey?: string, minGap = 0) {
    if (!this.ctx || this.ctx.state !== 'running') return false;
    if (this.voices >= this.MAX_VOICES) return false;
    if (throttleKey) {
      const now = this.ctx.currentTime;
      if (now - (this.lastPlay[throttleKey] ?? -1) < minGap) return false;
      this.lastPlay[throttleKey] = now;
    }
    this.voices++;
    setTimeout(() => { this.voices = Math.max(0, this.voices - 1); }, dur * 1000 + 50);
    return true;
  }

  /** Output node: spatial panner when pos given, otherwise direct to bus */
  private out(bus: GainNode, pos?: Vec): AudioNode {
    if (!pos || !this.ctx) return bus;
    const p = this.ctx.createPanner();
    p.panningModel = 'equalpower'; p.distanceModel = 'inverse'; p.refDistance = 4; p.maxDistance = 400; p.rolloffFactor = 1.1;
    if (p.positionX) { p.positionX.value = pos.x; p.positionY.value = pos.y; p.positionZ.value = pos.z; }
    else (p as unknown as { setPosition: (x: number, y: number, z: number) => void }).setPosition(pos.x, pos.y, pos.z);
    p.connect(bus);
    return p;
  }

  private noiseBurst(dest: AudioNode, t: number, dur: number, gain: number, type: BiquadFilterType, freq: number, q = 0.7, freqEnd?: number) {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource(); src.buffer = this.noise;
    src.playbackRate.value = 0.8 + Math.random() * 0.4;
    const f = ctx.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(freq, t); f.Q.value = q;
    if (freqEnd) f.frequency.exponentialRampToValueAtTime(freqEnd, t + dur);
    const g = ctx.createGain(); g.gain.setValueAtTime(gain, t); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    src.connect(f); f.connect(g); g.connect(dest);
    src.start(t, Math.random() * 0.8); src.stop(t + dur + 0.02);
  }
  private tone(dest: AudioNode, t: number, dur: number, gain: number, type: OscillatorType, f0: number, f1?: number, attack = 0.002) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1) o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(gain, t + attack); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g); g.connect(dest); o.start(t); o.stop(t + dur + 0.02);
  }

  /** Weapon-specific gunshot: each weapon's SoundProfile yields a distinct report */
  shot(p: SoundProfile, suppressed: boolean, pos?: Vec, volume = 1) {
    const dur = suppressed ? 0.18 : 0.25 + p.tail * 0.35;
    if (!this.take(dur, pos ? undefined : 'pshot', 0.03)) return;
    const ctx = this.ctx!, t = ctx.currentTime, o = this.out(this.sfx, pos);
    const v = volume * (pos ? 1.4 : 0.9);
    if (suppressed) {
      this.noiseBurst(o, t, 0.09, 0.5 * v, 'bandpass', 1800 * p.pitch, 1.2);
      this.tone(o, t, 0.08, 0.35 * v, 'triangle', 220 * p.pitch, 60);
      this.noiseBurst(o, t + 0.01, 0.05, 0.25 * v, 'highpass', 4000);
      return;
    }
    this.noiseBurst(o, t, 0.05 + p.crack * 0.03, 0.9 * p.crack * v, 'highpass', 2500 * p.pitch, 0.5);
    this.noiseBurst(o, t, 0.12 + p.body * 0.08, 0.8 * p.body * v, 'lowpass', 2600 * p.pitch, 0.9, 300);
    this.tone(o, t, 0.12 + p.body * 0.06, 0.9 * p.body * v, 'sine', 130 * p.pitch, 38);
    this.noiseBurst(o, t + 0.03, 0.2 + p.tail * 0.4, 0.22 * p.tail * v, 'lowpass', 900, 0.5, 200);
  }
  click() { if (!this.take(0.06, 'click', 0.08)) return; const t = this.ctx!.currentTime; this.tone(this.sfx, t, 0.04, 0.3, 'square', 1800, 900); this.noiseBurst(this.sfx, t, 0.03, 0.2, 'highpass', 5000); }
  reload(stage: number) {
    if (!this.take(0.15)) return; const t = this.ctx!.currentTime;
    if (stage === 0) { this.noiseBurst(this.sfx, t, 0.08, 0.35, 'bandpass', 1200, 3); this.tone(this.sfx, t, 0.06, 0.2, 'square', 500, 300); }
    else if (stage === 1) { this.noiseBurst(this.sfx, t, 0.1, 0.45, 'bandpass', 2200, 4); this.tone(this.sfx, t + 0.02, 0.05, 0.3, 'square', 900, 600); }
    else { this.noiseBurst(this.sfx, t, 0.07, 0.5, 'bandpass', 3000, 5); this.tone(this.sfx, t, 0.05, 0.3, 'triangle', 1400, 700); this.noiseBurst(this.sfx, t + 0.08, 0.06, 0.4, 'bandpass', 2500, 5); }
  }
  footstep(surface: number, pos?: Vec, vol = 1) {
    if (!this.take(0.12, pos ? undefined : 'step', 0.15)) return; const t = this.ctx!.currentTime; const o = this.out(this.sfx, pos);
    this.noiseBurst(o, t, 0.09, 0.22 * vol, 'lowpass', surface === 1 ? 900 : 1600, 1.4, 200);
    this.tone(o, t, 0.05, 0.12 * vol, 'sine', 90, 50);
  }
  jump() { if (!this.take(0.15)) return; const t = this.ctx!.currentTime; this.noiseBurst(this.sfx, t, 0.12, 0.25, 'bandpass', 700, 1); }
  land(h: number) { if (!this.take(0.2, 'land', 0.1)) return; const t = this.ctx!.currentTime; const v = Math.min(1, 0.3 + h * 0.1); this.noiseBurst(this.sfx, t, 0.15, 0.4 * v, 'lowpass', 600, 1, 120); this.tone(this.sfx, t, 0.12, 0.4 * v, 'sine', 80, 40); }
  hit(head: boolean, kill: boolean) {
    if (!this.take(0.25, 'hit', 0.03)) return; const t = this.ctx!.currentTime;
    if (kill) { this.tone(this.sfx, t, 0.18, 0.35, 'triangle', 900, 1400); this.tone(this.sfx, t + 0.06, 0.25, 0.3, 'triangle', 1400, 1800); }
    else if (head) { this.tone(this.sfx, t, 0.12, 0.35, 'triangle', 2400, 2200); this.noiseBurst(this.sfx, t, 0.05, 0.25, 'highpass', 6000); }
    else { this.noiseBurst(this.sfx, t, 0.05, 0.35, 'bandpass', 3500, 2); this.tone(this.sfx, t, 0.04, 0.15, 'square', 1600, 1200); }
  }
  impact(pos: Vec, metal: boolean) {
    if (!this.take(0.1, 'imp', 0.04)) return; const t = this.ctx!.currentTime; const o = this.out(this.sfx, pos);
    if (metal) this.tone(o, t, 0.15, 0.2, 'triangle', 2600 + Math.random() * 800, 1800);
    this.noiseBurst(o, t, 0.07, 0.3, 'bandpass', metal ? 4000 : 1500, 1.5);
  }
  hurt() { if (!this.take(0.3, 'hurt', 0.12)) return; const t = this.ctx!.currentTime; this.noiseBurst(this.sfx, t, 0.2, 0.5, 'lowpass', 500, 1, 100); this.tone(this.sfx, t, 0.2, 0.35, 'sine', 70, 35); }
  whiz(pos: Vec) { if (!this.take(0.2, 'whiz', 0.12)) return; const t = this.ctx!.currentTime; const o = this.out(this.sfx, pos); this.noiseBurst(o, t, 0.15, 0.35, 'bandpass', 3500, 6, 1500); }
  pickup() { if (!this.take(0.25, 'pick', 0.1)) return; const t = this.ctx!.currentTime; this.tone(this.sfx, t, 0.08, 0.25, 'square', 660); this.tone(this.sfx, t + 0.07, 0.12, 0.25, 'square', 990); }
  deny() { if (!this.take(0.25, 'deny', 0.3)) return; const t = this.ctx!.currentTime; this.tone(this.sfx, t, 0.15, 0.2, 'square', 220, 180); }
  heal() { if (!this.take(0.4)) return; const t = this.ctx!.currentTime; this.tone(this.sfx, t, 0.35, 0.18, 'sine', 400, 800); this.noiseBurst(this.sfx, t, 0.3, 0.15, 'bandpass', 3000, 2); }
  plate() { if (!this.take(0.3)) return; const t = this.ctx!.currentTime; this.noiseBurst(this.sfx, t, 0.15, 0.5, 'bandpass', 1200, 3); this.tone(this.sfx, t + 0.05, 0.2, 0.3, 'triangle', 300, 200); }
  crate() { if (!this.take(0.5)) return; const t = this.ctx!.currentTime; this.noiseBurst(this.sfx, t, 0.3, 0.4, 'lowpass', 1500, 2, 300); this.tone(this.sfx, t + 0.1, 0.4, 0.2, 'triangle', 520, 1040); }
  ui(kind: 'hover' | 'select' | 'back' = 'select') {
    if (!this.take(0.12, 'ui' + kind, 0.04)) return; const t = this.ctx!.currentTime;
    if (kind === 'hover') this.tone(this.sfx, t, 0.04, 0.06, 'sine', 1800);
    else if (kind === 'back') this.tone(this.sfx, t, 0.08, 0.15, 'triangle', 700, 400);
    else { this.tone(this.sfx, t, 0.06, 0.15, 'triangle', 900, 1300); this.noiseBurst(this.sfx, t, 0.04, 0.1, 'highpass', 5000); }
  }
  zoneWarn() { if (!this.take(0.5, 'zone', 1.2)) return; const t = this.ctx!.currentTime; this.tone(this.sfx, t, 0.4, 0.15, 'sawtooth', 300, 200); }
  stinger(win: boolean | 'start') {
    if (!this.take(2.5)) return; const t = this.ctx!.currentTime; const bus = this.music;
    const notes = win === 'start' ? [196, 247, 294, 392] : win ? [262, 330, 392, 523, 659] : [220, 207, 185, 147];
    notes.forEach((f, i) => { this.tone(bus, t + i * 0.16, 1.4, 0.3, 'sawtooth', f); this.tone(bus, t + i * 0.16, 1.4, 0.2, 'triangle', f / 2); });
    this.noiseBurst(bus, t, 1.5, 0.3, 'lowpass', 400, 1, 60);
  }
  /** Announcer (dialogue bus) — uses speech synthesis when available, plus a radio squelch */
  announce(text: string) {
    if (this.ctx && this.take(0.2)) { const t = this.ctx.currentTime; this.noiseBurst(this.dialogue, t, 0.12, 0.25, 'bandpass', 2000, 2); this.tone(this.dialogue, t + 0.1, 0.06, 0.15, 'square', 1200); }
    try {
      const vol = store.settings.audio.dialogue * store.settings.audio.master;
      if (!('speechSynthesis' in window) || vol <= 0.01) return;
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text); u.volume = vol; u.rate = 1.05; u.pitch = 0.7;
      speechSynthesis.speak(u);
    } catch { /* speech unavailable */ }
  }

  // ---------------- music & ambience ----------------
  startMusic(kind: 'menu' | 'game') {
    this.stopMusic();
    if (!this.ctx) return;
    const ctx = this.ctx; const out = ctx.createGain(); out.gain.value = 0; out.connect(this.music);
    out.gain.linearRampToValueAtTime(kind === 'menu' ? 0.7 : 0.25, ctx.currentTime + 3);
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = kind === 'menu' ? 900 : 500; lp.connect(out);
    const chords = [[55, 82.4, 110, 130.8], [43.65, 87.3, 103.8, 130.8], [49, 73.4, 98, 116.5], [41.2, 82.4, 98, 123.5]];
    const oscs: OscillatorNode[] = [];
    for (let i = 0; i < 4; i++) {
      const o = ctx.createOscillator(); o.type = i === 0 ? 'sawtooth' : 'triangle'; o.frequency.value = chords[0][i];
      const g = ctx.createGain(); g.gain.value = i === 0 ? 0.12 : 0.08; o.connect(g); g.connect(lp); o.start(); oscs.push(o);
      const lfo = ctx.createOscillator(); lfo.frequency.value = 0.1 + i * 0.07; const lg = ctx.createGain(); lg.gain.value = 1.5; lfo.connect(lg); lg.connect(o.detune); lfo.start();
      this.musicNodes.push(o, lfo);
    }
    let step = 0;
    const tick = () => {
      if (!this.ctx) return; step++;
      const ch = chords[Math.floor(step / 8) % chords.length]; const t = ctx.currentTime;
      oscs.forEach((o, i) => o.frequency.setTargetAtTime(ch[i], t, 0.4));
      if (kind === 'menu' || step % 2 === 0) {
        // war drum pulse
        const g = ctx.createGain(); g.gain.setValueAtTime(step % 4 === 0 ? 0.5 : 0.22, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.5); g.connect(out);
        const o = ctx.createOscillator(); o.frequency.setValueAtTime(70, t); o.frequency.exponentialRampToValueAtTime(35, t + 0.4); o.connect(g); o.start(t); o.stop(t + 0.5);
      }
    };
    this.musicTimer = window.setInterval(tick, 500);
    this.musicNodes.push(out, lp);
  }
  stopMusic() {
    if (this.musicTimer) { clearInterval(this.musicTimer); this.musicTimer = null; }
    this.musicNodes.forEach(n => { try { (n as OscillatorNode).stop?.(); } catch { /* */ } try { n.disconnect(); } catch { /* */ } });
    this.musicNodes = [];
  }
  startAmbient(kind: 'wind' | 'city' | 'range') {
    this.stopAmbient();
    if (!this.ctx) return;
    const ctx = this.ctx;
    const src = ctx.createBufferSource(); src.buffer = this.noise; src.loop = true;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = kind === 'wind' ? 400 : kind === 'city' ? 250 : 600; f.Q.value = 0.6;
    const g = ctx.createGain(); g.gain.value = kind === 'range' ? 0.04 : 0.09;
    const lfo = ctx.createOscillator(); lfo.frequency.value = 0.08; const lg = ctx.createGain(); lg.gain.value = 180; lfo.connect(lg); lg.connect(f.frequency); lfo.start();
    src.connect(f); f.connect(g); g.connect(this.sfx); src.start();
    this.ambientNodes.push(src, lfo, f, g);
  }
  stopAmbient() {
    this.ambientNodes.forEach(n => { try { (n as AudioBufferSourceNode).stop?.(); } catch { /* */ } try { n.disconnect(); } catch { /* */ } });
    this.ambientNodes = [];
  }
  suspendGame(paused: boolean) {
    if (!this.ctx) return;
    this.sfx.gain.setTargetAtTime(paused ? store.settings.audio.sfx * 0.25 : store.settings.audio.sfx, this.ctx.currentTime, 0.1);
  }
}

export const audio = new AudioSystem();
