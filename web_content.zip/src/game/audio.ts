// ──────────────────────────────────────────────────────────────
// Синтезированные звуки через Web Audio API (без файлов —
// мгновенная загрузка и работа офлайн на любом Android)
// ──────────────────────────────────────────────────────────────

type Wave = OscillatorType;

export class SoundFX {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  enabled = true;

  /** Разблокировка аудио по первому касанию (требование Android/Chrome) */
  unlock(): void {
    this.ensure();
  }

  private ensure(): AudioContext | null {
    if (!this.enabled) return null;
    if (!this.ctx) {
      try {
        const AC =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext })
            .webkitAudioContext;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.9;
        this.master.connect(this.ctx.destination);
      } catch {
        return null;
      }
    }
    if (this.ctx.state === "suspended") {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  private tone(
    freq: number,
    delay: number,
    dur: number,
    type: Wave,
    vol: number,
    endFreq?: number
  ): void {
    const ctx = this.ensure();
    if (!ctx || !this.master) return;
    const t0 = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (endFreq) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(endFreq, 1), t0 + dur);
    }
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(gain);
    gain.connect(this.master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  /** Взяли фигуру в руку */
  pick(): void {
    this.tone(480, 0, 0.08, "sine", 0.22, 720);
  }

  /** Фигура поставлена на поле */
  place(): void {
    this.tone(210, 0, 0.09, "triangle", 0.5, 150);
    this.tone(340, 0, 0.05, "sine", 0.18);
  }

  /** Нельзя поставить */
  invalid(): void {
    this.tone(170, 0, 0.11, "sawtooth", 0.12, 110);
  }

  /** Очистка линий — восходящий перезвон, тем ярче, чем больше линий */
  clear(lines: number): void {
    const notes = [523.25, 659.25, 783.99, 987.77, 1174.66, 1396.91];
    const n = Math.min(lines + 1, notes.length);
    for (let i = 0; i < n; i++) {
      this.tone(notes[i], i * 0.055, 0.22, "triangle", 0.32);
      this.tone(notes[i] * 2, i * 0.055, 0.12, "sine", 0.1);
    }
  }

  /** Комбо-искры */
  combo(n: number): void {
    const base = 660 + Math.min(n, 8) * 70;
    this.tone(base, 0.0, 0.1, "sine", 0.22, base * 1.25);
    this.tone(base * 1.33, 0.07, 0.1, "sine", 0.2);
    this.tone(base * 1.66, 0.14, 0.16, "sine", 0.22);
  }

  /** Поле полностью очищено */
  allClear(): void {
    const chord = [523.25, 659.25, 783.99, 1046.5];
    chord.forEach((f, i) => {
      this.tone(f, i * 0.07, 0.4, "triangle", 0.3);
    });
    this.tone(1568, 0.3, 0.5, "sine", 0.18);
  }

  /** Конец игры — мягкое нисхождение */
  gameOver(): void {
    const notes = [392, 329.63, 261.63, 196];
    notes.forEach((f, i) => {
      this.tone(f, i * 0.16, 0.3, "triangle", 0.26);
    });
  }

  /** Клик по кнопке */
  button(): void {
    this.tone(640, 0, 0.05, "square", 0.08, 500);
  }
}

/** Лёгкая вибрация (если поддерживается устройством) */
export function vibrate(pattern: number | number[]): void {
  try {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      navigator.vibrate(pattern);
    }
  } catch {
    /* не критично */
  }
}
