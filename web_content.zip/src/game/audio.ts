let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let pad: OscillatorNode | null = null;
let muted = false;
let loaded = false;

function ensureMute() {
  if (loaded) return;
  loaded = true;
  try {
    muted = localStorage.getItem("palmon-mute") === "1";
  } catch {
    muted = false;
  }
}

function context() {
  ensureMute();
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = muted ? 0 : 0.9;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

export function isMuted() {
  ensureMute();
  return muted;
}

export function setMuted(next: boolean) {
  ensureMute();
  muted = next;
  try {
    localStorage.setItem("palmon-mute", next ? "1" : "0");
  } catch {
    /* ignore */
  }
  if (master) master.gain.value = next ? 0 : 0.9;
}

export function unlockAudio() {
  const ac = context();
  if (!pad && master) {
    const filter = ac.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 420;
    const g = ac.createGain();
    g.gain.value = 0.03;
    pad = ac.createOscillator();
    pad.type = "sine";
    pad.frequency.value = 196;
    const fifth = ac.createOscillator();
    fifth.type = "triangle";
    fifth.frequency.value = 294;
    const g2 = ac.createGain();
    g2.gain.value = 0.012;
    pad.connect(g).connect(filter).connect(master);
    fifth.connect(g2).connect(filter);
    pad.start();
    fifth.start();
  }
}

export function resumeAudio() {
  if (ctx && ctx.state === "suspended") void ctx.resume();
}

function tone(freq: number, dur: number, type: OscillatorType, gain: number, delay = 0, slide = 0) {
  if (muted) return;
  const ac = context();
  if (!master) return;
  const t = ac.currentTime + delay;
  const o = ac.createOscillator();
  const g = ac.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(master);
  o.start(t);
  o.stop(t + dur + 0.02);
}

export type Sfx = "hit" | "hurt" | "catch" | "fail" | "throw" | "gather" | "build" | "ui" | "heal" | "faint";

export function sfx(kind: Sfx) {
  if (kind === "hit") tone(520, 0.08, "square", 0.05);
  else if (kind === "hurt") tone(140, 0.16, "sawtooth", 0.04, 0, -60);
  else if (kind === "throw") tone(640, 0.12, "sine", 0.05, 0, 180);
  else if (kind === "catch") {
    tone(523, 0.12, "triangle", 0.06);
    tone(659, 0.14, "triangle", 0.05, 0.1);
    tone(784, 0.22, "sine", 0.05, 0.2);
  } else if (kind === "fail") {
    tone(392, 0.12, "square", 0.04);
    tone(262, 0.18, "square", 0.035, 0.1);
  } else if (kind === "gather") tone(740, 0.07, "sine", 0.045);
  else if (kind === "build") {
    tone(349, 0.14, "triangle", 0.05);
    tone(440, 0.18, "triangle", 0.04, 0.08);
  } else if (kind === "heal") tone(880, 0.16, "sine", 0.04);
  else if (kind === "faint") tone(220, 0.2, "triangle", 0.04, 0, -80);
  else tone(660, 0.05, "sine", 0.04);
}
