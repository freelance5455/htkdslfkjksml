let ctx: AudioContext | null = null;
let muted = false;
let stepBuf: AudioBuffer | null = null;

export function setMuted(next: boolean) {
  muted = next;
}

export function isMuted() {
  return muted;
}

export function unlockAudio() {
  const AC =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AC) return;
  if (!ctx) ctx = new AC();
  if (ctx.state === "suspended") void ctx.resume();
}

export function resumeAudio() {
  if (ctx && ctx.state === "suspended") void ctx.resume();
}

function tone(freq: number, when: number, dur: number, type: OscillatorType, gain: number) {
  if (!ctx || muted) return;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, when);
  g.gain.setValueAtTime(0.0001, when);
  g.gain.exponentialRampToValueAtTime(gain, when + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
  o.connect(g);
  g.connect(ctx.destination);
  o.start(when);
  o.stop(when + dur + 0.02);
}

export function playCollect() {
  if (!ctx || muted) return;
  const now = ctx.currentTime;
  tone(784, now, 0.12, "triangle", 0.06);
  tone(1046, now + 0.06, 0.14, "triangle", 0.05);
  tone(1568, now + 0.12, 0.18, "sine", 0.04);
}

export function playWin() {
  if (!ctx || muted) return;
  const now = ctx.currentTime;
  [523, 659, 784, 1046].forEach((freq, i) => {
    tone(freq, now + i * 0.09, 0.28, "triangle", 0.07);
  });
  tone(784, now + 0.42, 0.4, "sine", 0.05);
}

export function playStep() {
  if (!ctx || muted) return;
  if (!stepBuf) {
    const dur = 0.045;
    stepBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * dur), ctx.sampleRate);
    const data = stepBuf.getChannelData(0);
    for (let i = 0; i < data.length; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    }
  }
  const src = ctx.createBufferSource();
  src.buffer = stepBuf;
  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = 420 + Math.random() * 180;
  const g = ctx.createGain();
  g.gain.value = 0.035;
  src.connect(filter);
  filter.connect(g);
  g.connect(ctx.destination);
  src.start();
  src.playbackRate.value = 0.9 + Math.random() * 0.25;
}
