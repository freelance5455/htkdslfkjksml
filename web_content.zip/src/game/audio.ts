/* Tiny procedural WebAudio SFX engine — no assets, all synthesized. */

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let noiseBuf: AudioBuffer | null = null;
let muted = false;

function ac(): AudioContext {
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.55;
    master.connect(ctx.destination);
  }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

function getNoise(c: AudioContext): AudioBuffer {
  if (!noiseBuf) {
    noiseBuf = c.createBuffer(1, c.sampleRate, c.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  return noiseBuf;
}

function blip(freq: number, dur: number, type: OscillatorType, vol: number, slideTo?: number, delay = 0) {
  if (muted) return;
  try {
    const c = ac();
    const t0 = c.currentTime + delay;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (slideTo !== undefined) o.frequency.linearRampToValueAtTime(Math.max(30, slideTo), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(vol, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(master!);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  } catch { /* ignore */ }
}

function noise(dur: number, f0: number, f1: number, vol: number, type: BiquadFilterType, delay = 0) {
  if (muted) return;
  try {
    const c = ac();
    const t0 = c.currentTime + delay;
    const src = c.createBufferSource();
    src.buffer = getNoise(c);
    src.loop = true;
    const f = c.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(f0, t0);
    f.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t0 + dur);
    f.Q.value = type === 'bandpass' ? 1.2 : 0.6;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(vol, t0 + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f);
    f.connect(g);
    g.connect(master!);
    src.start(t0);
    src.stop(t0 + dur + 0.03);
  } catch { /* ignore */ }
}

export const sfx = {
  unlock() {
    try { ac(); } catch { /* ignore */ }
  },
  setMuted(m: boolean) { muted = m; },
  isMuted() { return muted; },

  ui()      { blip(880, 0.05, 'square', 0.14); },
  punchHit(){ noise(0.08, 900, 120, 0.55, 'lowpass'); blip(150, 0.09, 'triangle', 0.5, 60); },
  punchMiss(){ noise(0.13, 500, 2600, 0.16, 'bandpass'); },
  webShot() { blip(1300, 0.09, 'sine', 0.3, 260); noise(0.06, 2000, 5000, 0.1, 'highpass'); },
  webHit()  { blip(560, 0.14, 'triangle', 0.36, 180); noise(0.05, 3000, 800, 0.14, 'bandpass'); },
  hurt()    { blip(220, 0.28, 'sawtooth', 0.45, 52); noise(0.2, 800, 90, 0.4, 'lowpass'); },
  enemyDie(){ blip(320, 0.2, 'square', 0.3, 90); noise(0.16, 1400, 200, 0.3, 'lowpass'); },
  wave()    { blip(392, 0.09, 'square', 0.22); blip(587, 0.12, 'square', 0.22, undefined, 0.11); },
  clear()   { blip(523, 0.09, 'square', 0.2); blip(659, 0.09, 'square', 0.2, undefined, 0.09); blip(784, 0.16, 'square', 0.22, undefined, 0.18); },
  over()    { blip(392, 0.16, 'sawtooth', 0.26, undefined, 0); blip(294, 0.16, 'sawtooth', 0.26, undefined, 0.18); blip(196, 0.4, 'sawtooth', 0.28, 98, 0.36); },
  combo(n: number) { blip(600 + Math.min(n, 10) * 80, 0.06, 'square', 0.16); },
};
