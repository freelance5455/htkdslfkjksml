let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let musicGain: GainNode | null = null;
let sfxGain: GainNode | null = null;
let timer: number | null = null;
let step = 0;
let currentTheme = "village";
let enabled = true;

const SCALES: Record<string, number[]> = {
  village: [0, 2, 3, 5, 7, 8, 10],
  town: [0, 2, 3, 5, 7, 8, 11],
  castle: [0, 1, 3, 5, 7, 8, 10],
  crypt: [0, 1, 3, 5, 6, 8, 10],
  wild: [0, 2, 3, 5, 7, 9, 10],
  tavern: [0, 2, 4, 5, 7, 9, 11],
  water: [0, 2, 4, 7, 9, 11, 14],
};
const ROOTS: Record<string, number> = {
  village: 196,
  town: 220,
  castle: 174,
  crypt: 146,
  wild: 164,
  tavern: 233,
  water: 147,
};

export function initAudio() {
  if (ctx) return;
  try {
    ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    master = ctx.createGain();
    master.gain.value = enabled ? 0.5 : 0;
    master.connect(ctx.destination);
    musicGain = ctx.createGain();
    musicGain.gain.value = 0.28;
    musicGain.connect(master);
    sfxGain = ctx.createGain();
    sfxGain.gain.value = 0.6;
    sfxGain.connect(master);
  } catch {
    ctx = null;
  }
}

export function setMuted(m: boolean) {
  enabled = !m;
  if (master && ctx) master.gain.setTargetAtTime(enabled ? 0.5 : 0, ctx.currentTime, 0.1);
}

export const isMuted = () => !enabled;

function note(freq: number, dur: number, type: OscillatorType, vol: number, when = 0, detune = 0) {
  if (!ctx || !musicGain) return;
  const t = ctx.currentTime + when;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.value = freq;
  o.detune.value = detune;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g);
  g.connect(musicGain);
  o.start(t);
  o.stop(t + dur + 0.05);
}

function playPhrase() {
  if (!ctx) return;
  const scale = SCALES[currentTheme] ?? SCALES.village;
  const root = ROOTS[currentTheme] ?? 196;
  const beat = 0.42;

  // drone pad
  const padDur = beat * 8;
  const t = ctx.currentTime;
  const o1 = ctx.createOscillator();
  const o2 = ctx.createOscillator();
  const filt = ctx.createBiquadFilter();
  const g = ctx.createGain();
  o1.type = "sawtooth";
  o2.type = "sawtooth";
  o1.frequency.value = root / 2;
  o2.frequency.value = (root / 2) * 1.005;
  filt.type = "lowpass";
  filt.frequency.setValueAtTime(400, t);
  filt.frequency.linearRampToValueAtTime(900, t + padDur * 0.5);
  filt.frequency.linearRampToValueAtTime(400, t + padDur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(0.12, t + 0.6);
  g.gain.linearRampToValueAtTime(0.0001, t + padDur);
  o1.connect(filt);
  o2.connect(filt);
  filt.connect(g);
  g.connect(musicGain!);
  o1.start(t);
  o2.start(t);
  o1.stop(t + padDur + 0.1);
  o2.stop(t + padDur + 0.1);

  // melodic line
  const pattern = [0, 2, 4, 3, 5, 4, 2, 1];
  for (let i = 0; i < 8; i++) {
    const deg = pattern[(step + i) % pattern.length];
    const f = root * Math.pow(2, scale[deg % scale.length] / 12) * (deg >= 7 ? 2 : 1);
    note(f, beat * 0.9, currentTheme === "tavern" ? "triangle" : "square", 0.05, i * beat);
    if (i % 2 === 0) note(f / 2, beat * 1.4, "triangle", 0.035, i * beat, 6);
  }
  step = (step + 3) % 8;
}

export function setTheme(theme: string) {
  if (currentTheme === theme) return;
  currentTheme = theme;
}

export function startMusic() {
  if (!ctx) return;
  if (timer !== null) return;
  playPhrase();
  timer = window.setInterval(playPhrase, 3400);
}

export function stopMusic() {
  if (timer !== null) {
    clearInterval(timer);
    timer = null;
  }
}

function blip(freq: number, dur: number, type: OscillatorType, vol: number, slide = 0) {
  if (!ctx || !sfxGain) return;
  const t = ctx.currentTime;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t + dur);
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g);
  g.connect(sfxGain);
  o.start(t);
  o.stop(t + dur + 0.02);
}

export const sfx = {
  click: () => blip(660, 0.07, "square", 0.18, -120),
  hover: () => blip(880, 0.03, "sine", 0.06),
  good: () => {
    blip(523, 0.12, "triangle", 0.2);
    blip(659, 0.12, "triangle", 0.18);
    window.setTimeout(() => blip(784, 0.22, "triangle", 0.2), 110);
  },
  bad: () => {
    blip(220, 0.18, "sawtooth", 0.18, -80);
    window.setTimeout(() => blip(160, 0.3, "sawtooth", 0.16, -50), 130);
  },
  coin: () => {
    blip(1046, 0.07, "square", 0.14);
    window.setTimeout(() => blip(1568, 0.1, "square", 0.12), 60);
  },
  step: () => blip(120 + Math.random() * 30, 0.05, "sine", 0.05, -40),
  portal: () => {
    blip(300, 0.3, "sine", 0.16, 700);
  },
  talk: () => blip(440 + Math.random() * 120, 0.04, "square", 0.05),
  power: () => {
    blip(392, 0.2, "triangle", 0.18);
    window.setTimeout(() => blip(587, 0.25, "triangle", 0.16), 130);
    window.setTimeout(() => blip(784, 0.4, "triangle", 0.14), 260);
  },
};
