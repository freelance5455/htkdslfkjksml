class AudioSys {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  noiseBuf: AudioBuffer | null = null;
  volume = 0.8;

  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.volume;
      const comp = this.ctx.createDynamicsCompressor();
      comp.threshold.value = -12;
      this.master.connect(comp);
      comp.connect(this.ctx.destination);
      const len = this.ctx.sampleRate * 1.5;
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    } catch { /* no audio */ }
  }

  setVolume(v: number) { this.volume = v; if (this.master) this.master.gain.value = v; }

  private out(vol: number, pan = 0) {
    const ctx = this.ctx!;
    const g = ctx.createGain();
    g.gain.value = vol;
    if (pan !== 0 && ctx.createStereoPanner) {
      const p = ctx.createStereoPanner();
      p.pan.value = Math.max(-1, Math.min(1, pan));
      g.connect(p); p.connect(this.master!);
    } else g.connect(this.master!);
    return g;
  }

  private noise(dest: AudioNode, t: number, dur: number, type: BiquadFilterType, freq: number, q = 1, vol = 1, decay = 4) {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = ctx.createBiquadFilter();
    f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f); f.connect(g); g.connect(dest);
    src.start(t, Math.random() * 0.5); src.stop(t + dur + 0.05);
    void decay;
  }

  private tone(dest: AudioNode, t: number, dur: number, f0: number, f1: number, type: OscillatorType = 'sine', vol = 1) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(dest);
    o.start(t); o.stop(t + dur + 0.05);
  }

  shot(s: { f: number; d: number; n: number; boom: number }, vol = 1, pan = 0) {
    if (!this.ctx || !s.f) return;
    const t = this.ctx.currentTime;
    const o = this.out(vol, pan);
    this.noise(o, t, s.d, 'bandpass', s.f * 2.2, 0.8, 0.9 * s.n);
    this.noise(o, t, s.d * 1.8, 'lowpass', s.f, 0.7, 0.7);
    if (s.boom > 0) this.tone(o, t, s.d * 1.5, 140 * (s.f / 600), 38, 'sine', 0.9 * s.boom);
    this.noise(o, t + 0.01, s.d * 3.5, 'lowpass', 500, 0.5, 0.12 * s.boom);
  }

  knife() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(0.6);
    const ctx = this.ctx;
    const src = ctx.createBufferSource(); src.buffer = this.noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 3;
    f.frequency.setValueAtTime(800, t); f.frequency.exponentialRampToValueAtTime(4000, t + 0.15);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.001, t); g.gain.linearRampToValueAtTime(0.7, t + 0.05); g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
    src.connect(f); f.connect(g); g.connect(o); src.start(t); src.stop(t + 0.25);
  }

  click(vol = 0.4) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(vol);
    this.tone(o, t, 0.04, 2400, 1200, 'square', 0.25);
    this.noise(o, t, 0.05, 'highpass', 3000, 1, 0.4);
  }

  reload(dur: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(0.5);
    this.noise(o, t + 0.1, 0.06, 'bandpass', 1800, 4, 0.8);
    this.tone(o, t + 0.1, 0.05, 900, 500, 'square', 0.15);
    this.noise(o, t + dur * 0.55, 0.08, 'bandpass', 1200, 4, 0.9);
    this.noise(o, t + dur * 0.85, 0.05, 'bandpass', 2500, 5, 0.9);
    this.tone(o, t + dur * 0.85, 0.04, 1500, 800, 'square', 0.2);
  }

  step(vol = 0.25, pan = 0) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(vol, pan);
    this.noise(o, t, 0.09, 'lowpass', 600 + Math.random() * 300, 1, 0.7);
  }

  hit() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(0.5);
    this.noise(o, t, 0.08, 'bandpass', 900, 2, 0.8);
    this.tone(o, t, 0.06, 300, 120, 'sine', 0.5);
  }

  headshot() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(0.5);
    this.tone(o, t, 0.25, 1600, 1500, 'triangle', 0.5);
    this.noise(o, t, 0.06, 'highpass', 4000, 1, 0.6);
  }

  hurt() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(0.6);
    this.tone(o, t, 0.18, 220, 90, 'sawtooth', 0.35);
    this.noise(o, t, 0.12, 'lowpass', 700, 1, 0.6);
  }

  explosion(vol = 1, pan = 0) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(vol, pan);
    this.noise(o, t, 1.4, 'lowpass', 900, 0.7, 1.2);
    this.noise(o, t, 0.25, 'bandpass', 2500, 0.6, 0.8);
    this.tone(o, t, 1.0, 90, 25, 'sine', 1.2);
  }

  zombie(vol = 0.4, pan = 0) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(vol, pan);
    const ctx = this.ctx;
    const osc = ctx.createOscillator(); osc.type = 'sawtooth';
    const base = 70 + Math.random() * 40;
    osc.frequency.setValueAtTime(base, t);
    osc.frequency.linearRampToValueAtTime(base * 0.7, t + 0.7);
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 500; f.Q.value = 2;
    const lfo = ctx.createOscillator(); lfo.frequency.value = 9; const lg = ctx.createGain(); lg.gain.value = 25; lfo.connect(lg); lg.connect(osc.frequency);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.001, t); g.gain.linearRampToValueAtTime(0.6, t + 0.1); g.gain.exponentialRampToValueAtTime(0.001, t + 0.8);
    osc.connect(f); f.connect(g); g.connect(o);
    osc.start(t); lfo.start(t); osc.stop(t + 0.85); lfo.stop(t + 0.85);
  }

  beep(f = 880, d = 0.12, vol = 0.3) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(vol);
    this.tone(o, t, d, f, f, 'square', 0.3);
  }

  ui() { this.click(0.25); }

  buy() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(0.4);
    this.tone(o, t, 0.08, 1200, 1200, 'triangle', 0.4);
    this.tone(o, t + 0.08, 0.12, 1800, 1800, 'triangle', 0.4);
  }

  unlock() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(0.5);
    [523, 659, 784, 1046].forEach((f, i) => this.tone(o, t + i * 0.09, 0.3, f, f, 'triangle', 0.4));
  }

  error() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.out(0.4);
    this.tone(o, t, 0.25, 180, 140, 'square', 0.3);
  }
}

export const audio = new AudioSys();
