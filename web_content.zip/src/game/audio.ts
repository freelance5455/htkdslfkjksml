/**
 * Tiny procedural audio kit for the night run.
 * Everything is synthesised in the browser — no asset downloads, no autoplay.
 */

type Ctx = AudioContext & { _vanta?: boolean };

class SoundKit {
  private ctx: Ctx | null = null;
  private master: GainNode | null = null;
  private engineGain: GainNode | null = null;
  private engineOsc: OscillatorNode | null = null;
  private engineSub: OscillatorNode | null = null;
  private muted = true;

  get isMuted() {
    return this.muted;
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(muted ? 0 : 0.5, this.ctx.currentTime, 0.05);
    }
    if (muted) this.stopEngine();
  }

  private ensure(): Ctx | null {
    if (typeof window === "undefined") return null;
    if (!this.ctx) {
      const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      try {
        this.ctx = new AC() as Ctx;
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 0.5;
        this.master.connect(this.ctx.destination);
      } catch {
        return null;
      }
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  startEngine() {
    const ctx = this.ensure();
    if (!ctx || !this.master || this.engineOsc || this.muted) return;
    try {
      const gain = ctx.createGain();
      gain.gain.value = 0.0001;
      gain.gain.setTargetAtTime(0.055, ctx.currentTime, 0.4);
      gain.connect(this.master);

      const osc = ctx.createOscillator();
      osc.type = "sawtooth";
      osc.frequency.value = 62;

      const sub = ctx.createOscillator();
      sub.type = "triangle";
      sub.frequency.value = 31;

      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 320;
      filter.Q.value = 3;

      osc.connect(filter);
      sub.connect(filter);
      filter.connect(gain);
      osc.start();
      sub.start();

      this.engineOsc = osc;
      this.engineSub = sub;
      this.engineGain = gain;
    } catch {
      /* audio is a bonus, never a blocker */
    }
  }

  updateEngine(speedKmh: number, active: boolean) {
    if (!this.ctx || !this.engineOsc || !this.engineSub || !this.engineGain) return;
    const t = this.ctx.currentTime;
    const rev = Math.min(1, Math.max(0, (speedKmh - 80) / 140));
    const freq = 54 + rev * 92;
    try {
      this.engineOsc.frequency.setTargetAtTime(freq, t, 0.08);
      this.engineSub.frequency.setTargetAtTime(freq / 2, t, 0.1);
      this.engineGain.gain.setTargetAtTime(active ? 0.05 + rev * 0.04 : 0.0001, t, 0.15);
    } catch {
      /* noop */
    }
  }

  stopEngine() {
    if (!this.ctx) return;
    try {
      this.engineGain?.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.08);
      const osc = this.engineOsc;
      const sub = this.engineSub;
      this.engineOsc = null;
      this.engineSub = null;
      this.engineGain = null;
      window.setTimeout(() => {
        try {
          osc?.stop();
          sub?.stop();
        } catch {
          /* already stopped */
        }
      }, 240);
    } catch {
      /* noop */
    }
  }

  private tone(freq: number, duration: number, type: OscillatorType, volume = 0.12, slideTo?: number) {
    const ctx = this.ensure();
    if (!ctx || !this.master || this.muted) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, ctx.currentTime + duration);
      gain.gain.setValueAtTime(volume, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(this.master);
      osc.start();
      osc.stop(ctx.currentTime + duration + 0.02);
    } catch {
      /* noop */
    }
  }

  blip() {
    this.tone(880, 0.1, "sine", 0.09, 1320);
  }

  spark() {
    this.tone(1180, 0.09, "triangle", 0.08, 1760);
    window.setTimeout(() => this.tone(1560, 0.08, "sine", 0.05), 55);
  }

  nearMiss() {
    this.tone(520, 0.14, "square", 0.035, 900);
  }

  levelUp() {
    [523, 659, 784].forEach((f, i) => window.setTimeout(() => this.tone(f, 0.24, "triangle", 0.06), i * 90));
  }

  hit() {
    const ctx = this.ensure();
    if (!ctx || !this.master || this.muted) return;
    try {
      const length = Math.floor(ctx.sampleRate * 0.4);
      const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < length; i += 1) {
        data[i] = (Math.random() * 2 - 1) * (1 - i / length) ** 2;
      }
      const src = ctx.createBufferSource();
      src.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 900;
      const gain = ctx.createGain();
      gain.gain.value = 0.28;
      src.connect(filter);
      filter.connect(gain);
      gain.connect(this.master);
      src.start();
    } catch {
      /* noop */
    }
    this.tone(90, 0.35, "sawtooth", 0.14, 40);
  }

  crash() {
    this.hit();
    this.tone(220, 0.8, "sawtooth", 0.12, 55);
    this.stopEngine();
  }

  start() {
    this.ensure();
    this.tone(330, 0.16, "triangle", 0.07, 440);
    window.setTimeout(() => this.tone(440, 0.2, "triangle", 0.07, 660), 180);
  }
}

export const sound = new SoundKit();
