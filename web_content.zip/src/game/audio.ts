let audioCtx: AudioContext | null = null;
let master: GainNode | null = null;
let noiseBuffer: AudioBuffer | null = null;
let soundEnabled = true;

export function setSoundEnabled(enabled: boolean) {
  soundEnabled = enabled;
  if (master && audioCtx) {
    master.gain.setTargetAtTime(enabled ? 0.5 : 0, audioCtx.currentTime, 0.02);
  }
}

export function unlockAudio() {
  const ctx = ensure();
  if (ctx && ctx.state === "suspended") {
    void ctx.resume();
  }
}

function ensure(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (audioCtx) {
    if (audioCtx.state === "suspended") void audioCtx.resume();
    return audioCtx;
  }
  try {
    const Ctor =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    audioCtx = new Ctor();
    master = audioCtx.createGain();
    master.gain.value = soundEnabled ? 0.5 : 0;
    master.connect(audioCtx.destination);
    const length = Math.floor(audioCtx.sampleRate * 0.4);
    noiseBuffer = audioCtx.createBuffer(1, length, audioCtx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < length; i += 1) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / length);
    }
    return audioCtx;
  } catch {
    return null;
  }
}

function tone(
  freq: number,
  duration: number,
  type: OscillatorType = "sine",
  volume = 0.18,
  delay = 0,
  endFreq?: number,
) {
  if (!soundEnabled) return;
  const ctx = ensure();
  if (!ctx || !master) return;
  try {
    const start = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20, freq), start);
    if (endFreq) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), start + duration);
    }
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.001, volume), start + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    osc.connect(gain);
    gain.connect(master);
    osc.start(start);
    osc.stop(start + duration + 0.02);
  } catch {
    /* audio is a nice-to-have */
  }
}

function noise(duration = 0.12, volume = 0.12, filterFreq = 1800) {
  if (!soundEnabled) return;
  const ctx = ensure();
  if (!ctx || !master || !noiseBuffer) return;
  try {
    const source = ctx.createBufferSource();
    source.buffer = noiseBuffer;
    const filter = ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = filterFreq;
    filter.Q.value = 0.8;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(volume, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
    source.connect(filter);
    filter.connect(gain);
    gain.connect(master);
    source.start();
    source.stop(ctx.currentTime + duration);
  } catch {
    /* ignore */
  }
}

export const sfx = {
  click() {
    tone(520, 0.06, "triangle", 0.09, 0, 700);
  },
  smash(combo = 0) {
    const step = Math.min(combo, 14);
    noise(0.11, 0.13, 1500 + step * 90);
    tone(220 + step * 26, 0.12, "triangle", 0.12, 0, 130 + step * 12);
  },
  gem() {
    tone(880, 0.12, "sine", 0.12);
    tone(1320, 0.16, "sine", 0.09, 0.06);
  },
  bounce() {
    tone(170, 0.22, "sine", 0.2, 0, 64);
    noise(0.16, 0.1, 420);
  },
  finish() {
    [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.28, "triangle", 0.12, i * 0.09));
    noise(0.4, 0.06, 2600);
  },
  coin() {
    tone(1046, 0.08, "square", 0.06);
    tone(1568, 0.12, "square", 0.05, 0.05);
  },
  error() {
    tone(150, 0.16, "sawtooth", 0.08, 0, 110);
  },
};

export function haptic(pattern: number | number[], enabled: boolean) {
  if (!enabled) return;
  try {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      navigator.vibrate(pattern);
    }
  } catch {
    /* ignore */
  }
}
