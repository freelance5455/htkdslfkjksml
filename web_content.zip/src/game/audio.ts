type Bus = { ctx: AudioContext; master: GainNode; music: GainNode; sfx: GainNode };

let bus: Bus | null = null;
let musicTimer: number | null = null;
let act = 1;
let musicOn = true;
let volumes = { master: 0.85, music: 0.55, sfx: 0.7 };

function ensure(): Bus | null {
  if (typeof window === "undefined") return null;
  if (bus) return bus;
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AC) return null;
  const ctx = new AC({ latencyHint: "interactive" });
  const master = ctx.createGain();
  const music = ctx.createGain();
  const sfx = ctx.createGain();
  music.connect(master);
  sfx.connect(master);
  master.connect(ctx.destination);
  bus = { ctx, master, music, sfx };
  applyVolumes();
  return bus;
}

function applyVolumes() {
  if (!bus) return;
  const t = bus.ctx.currentTime;
  bus.master.gain.setTargetAtTime(volumes.master * volumes.master, t, 0.04);
  bus.music.gain.setTargetAtTime(volumes.music * volumes.music * (musicOn ? 1 : 0), t, 0.08);
  bus.sfx.gain.setTargetAtTime(volumes.sfx * volumes.sfx, t, 0.04);
}

export function unlockAudio() {
  const b = ensure();
  if (!b) return;
  if (b.ctx.state === "suspended") void b.ctx.resume();
}

export function setAudioVolumes(next: { master?: number; music?: number; sfx?: number }) {
  volumes = { ...volumes, ...next };
  applyVolumes();
}

export function setMusicEnabled(on: boolean) {
  musicOn = on;
  applyVolumes();
}

function tone(freq: number, dur: number, type: OscillatorType, gain: number, dest: GainNode, slide?: number) {
  const b = ensure();
  if (!b) return;
  const t = b.ctx.currentTime;
  const osc = b.ctx.createOscillator();
  const g = b.ctx.createGain();
  const filter = b.ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = Math.min(2400, freq * 4);
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq * slide), t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(filter);
  filter.connect(g);
  g.connect(dest);
  osc.start(t);
  osc.stop(t + dur + 0.05);
  osc.onended = () => {
    osc.disconnect();
    filter.disconnect();
    g.disconnect();
  };
}

export function sfx(kind: "ui" | "pickup" | "solve" | "star" | "page" | "whoosh" | "error" | "soft") {
  const b = ensure();
  if (!b) return;
  switch (kind) {
    case "ui":
      tone(620, 0.08, "sine", 0.05, b.sfx);
      break;
    case "pickup":
      tone(440, 0.18, "sine", 0.07, b.sfx);
      tone(660, 0.28, "triangle", 0.04, b.sfx);
      break;
    case "solve":
      tone(220, 0.5, "sine", 0.06, b.sfx, 2);
      tone(330, 0.7, "triangle", 0.04, b.sfx);
      break;
    case "star":
      tone(880, 0.4, "sine", 0.05, b.sfx, 1.4);
      break;
    case "page":
      tone(180, 0.12, "triangle", 0.03, b.sfx, 0.7);
      break;
    case "whoosh":
      tone(140, 0.4, "sawtooth", 0.02, b.sfx, 0.4);
      break;
    case "error":
      tone(140, 0.16, "square", 0.03, b.sfx, 0.8);
      break;
    case "soft":
      tone(320, 0.22, "sine", 0.03, b.sfx);
      break;
  }
}

const ACT_VOICING: Record<number, number[]> = {
  1: [110, 164.81, 196],
  2: [98, 146.83, 220, 261.63],
  3: [87, 130.81, 196, 246.94],
  4: [82, 123, 185, 247],
  5: [73, 110, 175, 233],
  6: [65, 98, 147, 220, 311],
  7: [55, 82, 138, 207],
  8: [98, 147, 196, 294],
  9: [87, 130, 174, 261],
  10: [65, 98, 130, 196],
};

function playPad() {
  const b = bus;
  if (!b || !musicOn) return;
  const notes = ACT_VOICING[act] ?? ACT_VOICING[1];
  const n = notes[Math.floor(Math.random() * notes.length)]!;
  const dur = act >= 8 ? 4.8 : act >= 5 ? 3.2 : 2.6;
  const type: OscillatorType = act >= 8 ? "sine" : act >= 5 ? "triangle" : "sine";
  const g = act === 10 ? 0.028 : act >= 7 ? 0.034 : 0.04;
  tone(n, dur, type, g, b.music, act === 7 ? 0.92 : 1.02);
  if (act === 10 && Math.random() > 0.6) {
    tone(n * 2, dur * 0.5, "sine", 0.012, b.music);
  }
}

export function startMusic(nextAct: number) {
  act = nextAct;
  unlockAudio();
  if (musicTimer != null) window.clearInterval(musicTimer);
  playPad();
  const interval = nextAct >= 8 ? 2800 : nextAct >= 5 ? 2200 : 1800;
  musicTimer = window.setInterval(playPad, interval);
}

export function stopMusic() {
  if (musicTimer != null) {
    window.clearInterval(musicTimer);
    musicTimer = null;
  }
}

export function musicForAct(next: number) {
  if (act !== next) startMusic(next);
  else act = next;
}

export function playNotes(freqs: number[], gap = 0.32) {
  const b = ensure();
  if (!b) return;
  freqs.forEach((f, i) => {
    window.setTimeout(() => tone(f, 0.28, "sine", 0.08, b.sfx), i * gap * 1000);
  });
}

export function resumeAudio() {
  if (!bus) return;
  if (bus.ctx.state === "suspended") void bus.ctx.resume();
}
