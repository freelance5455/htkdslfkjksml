/** Tiny synthesized cues. Unlocked from the start gesture. */

export class Sfx {
  private ctx: AudioContext | null = null;
  muted = false;

  unlock() {
    if (typeof window === "undefined") return;
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    if (!this.ctx) this.ctx = new AC();
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  private tone(freq: number, dur: number, type: OscillatorType, gain: number, delay = 0) {
    if (!this.ctx || this.muted || gain <= 0) return;
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const amp = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    amp.gain.setValueAtTime(0.0001, t);
    amp.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), t + 0.018);
    amp.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(amp);
    amp.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  click() {
    this.tone(540, 0.07, "sine", 0.04);
  }

  pickup() {
    this.tone(620, 0.1, "sine", 0.06);
    this.tone(930, 0.14, "triangle", 0.045, 0.05);
  }

  bump() {
    this.tone(78, 0.09, "triangle", 0.05);
    this.tone(140, 0.05, "sine", 0.02, 0.01);
  }

  step() {
    const f = 120 + Math.random() * 36;
    this.tone(f, 0.045, "sine", 0.018);
  }

  near() {
    this.tone(784, 0.12, "sine", 0.02);
    this.tone(988, 0.16, "sine", 0.016, 0.08);
  }

  win() {
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => {
      this.tone(f, 0.28, "sine", 0.06, i * 0.09);
      this.tone(f * 2, 0.18, "triangle", 0.02, i * 0.09 + 0.02);
    });
  }
}
