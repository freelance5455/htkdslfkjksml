type SoundName =
  | "pulse"
  | "smg"
  | "pistol"
  | "shotgun"
  | "sniper"
  | "rocket"
  | "hit"
  | "headshot"
  | "kill"
  | "hurt"
  | "explosion"
  | "reload"
  | "empty"
  | "jump"
  | "pickup"
  | "click"
  | "throw"
  | "vehicle"
  | "death";

export class AudioManager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private reverb: ConvolverNode | null = null;
  private noise: AudioBuffer | null = null;
  private musicTimer: number | null = null;
  private step = 0;
  private sfxVolume = 0.75;
  private musicVolume = 0.35;

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return;
    this.ctx = new Ctor();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.9;
    this.compressor = this.ctx.createDynamicsCompressor();
    this.compressor.threshold.value = -18;
    this.compressor.knee.value = 22;
    this.compressor.ratio.value = 6;
    this.compressor.attack.value = 0.003;
    this.compressor.release.value = 0.24;
    this.master.connect(this.compressor);
    this.compressor.connect(this.ctx.destination);
    this.sfxBus = this.ctx.createGain();
    this.sfxBus.gain.value = this.sfxVolume;
    this.sfxBus.connect(this.master);
    this.musicBus = this.ctx.createGain();
    this.musicBus.gain.value = this.musicVolume;
    this.musicBus.connect(this.master);

    // short, cheap plate reverb for weapon tails
    const seconds = 0.55;
    const impulse = this.ctx.createBuffer(2, Math.floor(this.ctx.sampleRate * seconds), this.ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const data = impulse.getChannelData(ch);
      for (let i = 0; i < data.length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 2.6);
      }
    }
    this.reverb = this.ctx.createConvolver();
    this.reverb.buffer = impulse;
    const reverbGain = this.ctx.createGain();
    reverbGain.gain.value = 0.16;
    const send = this.ctx.createGain();
    send.gain.value = 0.1;
    this.sfxBus.connect(send);
    send.connect(this.reverb);
    this.reverb.connect(reverbGain);
    reverbGain.connect(this.master);

    const length = Math.floor(this.ctx.sampleRate * 0.5);
    const buffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
    this.noise = buffer;
  }

  setVolumes(sfx: number, music: number) {
    this.sfxVolume = sfx;
    this.musicVolume = music;
    if (this.sfxBus && this.ctx) this.sfxBus.gain.setTargetAtTime(sfx, this.ctx.currentTime, 0.05);
    if (this.musicBus && this.ctx) this.musicBus.gain.setTargetAtTime(music, this.ctx.currentTime, 0.1);
  }

  private tone(freq: number, dur: number, type: OscillatorType, gain: number, slideTo?: number, delay = 0) {
    if (!this.ctx || !this.sfxBus) return;
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g);
    g.connect(this.sfxBus);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  private burst(dur: number, gain: number, filterFreq: number, type: BiquadFilterType = "lowpass", delay = 0) {
    if (!this.ctx || !this.sfxBus || !this.noise) return;
    const t = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    const filter = this.ctx.createBiquadFilter();
    filter.type = type;
    filter.frequency.setValueAtTime(filterFreq, t);
    filter.frequency.exponentialRampToValueAtTime(Math.max(80, filterFreq * 0.25), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filter);
    filter.connect(g);
    g.connect(this.sfxBus);
    src.start(t);
    src.stop(t + dur + 0.02);
  }

  play(name: SoundName) {
    if (!this.ctx) return;
    switch (name) {
      case "pulse":
        this.tone(520, 0.09, "square", 0.09, 180);
        this.burst(0.06, 0.12, 2400);
        break;
      case "smg":
        this.tone(680, 0.055, "square", 0.055, 260);
        this.burst(0.045, 0.08, 3000);
        break;
      case "pistol":
        this.tone(300, 0.11, "sawtooth", 0.11, 90);
        this.burst(0.09, 0.16, 1800);
        break;
      case "shotgun":
        this.burst(0.24, 0.32, 1600);
        this.tone(110, 0.18, "sawtooth", 0.16, 50);
        break;
      case "sniper":
        this.tone(1400, 0.16, "sawtooth", 0.12, 120);
        this.burst(0.2, 0.2, 3200, "highpass");
        break;
      case "rocket":
        this.burst(0.35, 0.2, 900);
        this.tone(180, 0.3, "sawtooth", 0.1, 60);
        break;
      case "hit":
        this.tone(1050, 0.05, "square", 0.06, 1300);
        break;
      case "headshot":
        this.tone(1560, 0.09, "triangle", 0.1, 2100);
        this.tone(780, 0.06, "square", 0.05, 1200);
        break;
      case "kill":
        this.tone(660, 0.1, "triangle", 0.12);
        this.tone(990, 0.14, "triangle", 0.1, undefined, 0.07);
        break;
      case "hurt":
        this.tone(140, 0.16, "sawtooth", 0.12, 70);
        this.burst(0.12, 0.12, 500);
        break;
      case "explosion":
        this.burst(0.55, 0.4, 700);
        this.tone(70, 0.5, "sine", 0.25, 30);
        break;
      case "reload":
        this.tone(320, 0.04, "square", 0.05);
        this.tone(240, 0.05, "square", 0.05, undefined, 0.12);
        break;
      case "empty":
        this.tone(180, 0.04, "square", 0.04);
        break;
      case "jump":
        this.tone(300, 0.1, "sine", 0.06, 520);
        break;
      case "pickup":
        this.tone(520, 0.08, "triangle", 0.1);
        this.tone(780, 0.1, "triangle", 0.09, undefined, 0.07);
        this.tone(1040, 0.12, "triangle", 0.08, undefined, 0.14);
        break;
      case "click":
        this.tone(420, 0.04, "square", 0.04, 300);
        break;
      case "throw":
        this.burst(0.12, 0.08, 1200, "bandpass");
        break;
      case "vehicle":
        this.tone(90, 0.35, "sawtooth", 0.12, 160);
        break;
      case "death":
        this.tone(300, 0.5, "sawtooth", 0.1, 60);
        break;
    }
  }

  startMusic() {
    if (!this.ctx || this.musicTimer !== null) return;
    const chords = [
      [220, 277.18, 329.63],
      [196, 246.94, 293.66],
      [174.61, 220, 261.63],
      [196, 246.94, 329.63],
    ];
    const bass = [110, 98, 87.31, 98];
    this.step = 0;
    const tick = () => {
      if (!this.ctx || !this.musicBus) return;
      const t = this.ctx.currentTime;
      const bar = Math.floor(this.step / 8) % 4;
      const chord = chords[bar];
      if (this.step % 8 === 0) {
        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.type = "triangle";
        osc.frequency.value = bass[bar];
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.16, t + 0.08);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 1.6);
        osc.connect(g);
        g.connect(this.musicBus);
        osc.start(t);
        osc.stop(t + 1.7);
      }
      const note = chord[this.step % chord.length] * (this.step % 8 >= 4 ? 2 : 1);
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = "square";
      osc.frequency.value = note;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.035, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
      osc.connect(g);
      g.connect(this.musicBus);
      osc.start(t);
      osc.stop(t + 0.24);
      this.step++;
    };
    tick();
    this.musicTimer = window.setInterval(tick, 250);
  }

  stopMusic() {
    if (this.musicTimer !== null) {
      window.clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }

  dispose() {
    this.stopMusic();
    if (this.ctx) void this.ctx.close();
    this.ctx = null;
  }
}

export const audio = new AudioManager();
