import type { Lock } from "./types";

export type Attempt = {
  code: string;
  word: string;
  order: string[];
  dials: number[];
  pick: string | null;
  signal: string[];
};

export function emptyAttempt(lock: Lock): Attempt {
  return {
    code: "",
    word: "",
    order: [],
    dials: lock.kind === "dials" ? lock.dials.map(() => 0) : [],
    pick: null,
    signal: [],
  };
}

export function isCorrect(lock: Lock, attempt: Attempt): boolean {
  switch (lock.kind) {
    case "code":
      return attempt.code === lock.answer;
    case "word":
      return attempt.word.toUpperCase().replace(/[^A-Z]/g, "") === lock.answer;
    case "order":
      return (
        attempt.order.length === lock.answer.length &&
        attempt.order.every((id, i) => id === lock.answer[i])
      );
    case "dials":
      return lock.dials.every((dial, i) => dial.options[attempt.dials[i] ?? -1] === lock.answer[i]);
    case "pick":
      return attempt.pick === lock.answer;
    case "signal":
      return (
        attempt.signal.length === lock.answer.length &&
        attempt.signal.every((id, i) => id === lock.answer[i])
      );
    default:
      return false;
  }
}
