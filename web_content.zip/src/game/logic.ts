export type Shot = "straight" | "cover" | "pull" | "sweep" | "loft" | "block";
export type Length = "yorker" | "full" | "good" | "short" | "bouncer";
export type Line = "off" | "middle" | "leg";
export type Kind = "pace" | "swing" | "spin";

export interface Delivery {
  length: Length;
  line: Line;
  kind: Kind;
  bowler: string;
}

export interface BallResult {
  runs: number;
  wicket: boolean;
  how: string;
  text: string;
  timing: "perfect" | "good" | "ok" | "miss";
  shot: Shot | null;
}

export const SHOTS: { id: Shot; ps: string; en: string }[] = [
  { id: "straight", ps: "سټریټ", en: "Drive" },
  { id: "cover", ps: "کور", en: "Cover" },
  { id: "pull", ps: "پل", en: "Pull" },
  { id: "sweep", ps: "سویپ", en: "Sweep" },
  { id: "loft", ps: "شپږ", en: "Loft" },
  { id: "block", ps: "دفاع", en: "Block" },
];

export const LENGTHS: { id: Length; ps: string }[] = [
  { id: "yorker", ps: "یارکر" },
  { id: "full", ps: "فل" },
  { id: "good", ps: "ښه" },
  { id: "short", ps: "لنډ" },
  { id: "bouncer", ps: "بانسر" },
];

export const LINES: { id: Line; ps: string }[] = [
  { id: "off", ps: "آف" },
  { id: "middle", ps: "منځ" },
  { id: "leg", ps: "لیګ" },
];

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function rollDelivery(rng: () => number, overIndex: number, bowlers: string[]): Delivery {
  const bowler = bowlers[overIndex % bowlers.length] ?? "بالر";
  const spin = overIndex % 4 === 2;
  const r = rng();
  const length: Length =
    r < 0.14 ? "yorker" : r < 0.4 ? "full" : r < 0.72 ? "good" : r < 0.9 ? "short" : "bouncer";
  const lineRoll = rng();
  const line: Line = lineRoll < 0.38 ? "off" : lineRoll < 0.72 ? "middle" : "leg";
  const kind: Kind = spin ? "spin" : rng() < 0.45 ? "swing" : "pace";
  return { length, line, kind, bowler };
}

export function judgeTiming(timingError: number): BallResult["timing"] {
  const a = Math.abs(timingError);
  if (a < 0.055) return "perfect";
  if (a < 0.11) return "good";
  if (a < 0.2) return "ok";
  return "miss";
}

function fit(shot: Shot, d: Delivery): number {
  let s = 0.45;
  if (shot === "block") return d.length === "bouncer" ? 0.35 : 0.85;
  if (shot === "loft") {
    if (d.length === "short" || d.length === "good") s = 0.9;
    else if (d.length === "full") s = 0.62;
    else if (d.length === "bouncer") s = 0.55;
    else s = 0.18;
  } else if (shot === "pull") {
    if (d.length === "short" || d.length === "bouncer") s = d.line === "off" ? 0.45 : 0.92;
    else if (d.length === "good") s = 0.5;
    else s = 0.22;
  } else if (shot === "sweep") {
    if (d.kind === "spin" && (d.length === "full" || d.length === "good") && d.line !== "off") s = 0.9;
    else if (d.length === "yorker") s = 0.15;
    else s = 0.4;
  } else if (shot === "cover") {
    if ((d.length === "full" || d.length === "good") && d.line !== "leg") s = 0.88;
    else if (d.length === "short") s = 0.35;
    else s = 0.5;
  } else if (shot === "straight") {
    if (d.length === "full" || d.length === "yorker" || d.length === "good") s = d.line === "leg" ? 0.55 : 0.86;
    else s = 0.4;
  }
  return s;
}

export function aiReply(d: Delivery, rng: () => number, level: "easy" | "normal" | "hard"): { shot: Shot; err: number } {
  const order: Shot[] = ["straight", "cover", "pull", "sweep", "loft", "block"];
  let best: Shot = "block";
  let bestFit = -1;
  for (const s of order) {
    const f = fit(s, d) + rng() * (level === "hard" ? 0.05 : 0.25);
    if (f > bestFit) {
      bestFit = f;
      best = s;
    }
  }
  if (level === "easy" && rng() < 0.35) best = order[Math.floor(rng() * order.length)];
  const spread = level === "hard" ? 0.12 : level === "normal" ? 0.22 : 0.36;
  return { shot: best, err: (rng() - 0.48) * spread };
}

function pickRuns(shot: Shot, grade: BallResult["timing"], match: number, rng: () => number): number {
  const boost = match > 0.75 ? 1 : match > 0.5 ? 0.65 : 0.35;
  const roll = rng();
  if (grade === "miss") return roll < 0.15 ? 1 : 0;
  if (shot === "block") return grade === "perfect" && roll < 0.25 ? 1 : 0;
  if (shot === "loft") {
    if (grade === "perfect" && boost > 0.6) return roll < 0.78 ? 6 : 4;
    if (grade === "good") return roll < 0.45 * boost + 0.15 ? 6 : roll < 0.7 ? 4 : 2;
    if (grade === "ok") return roll < 0.35 ? 4 : roll < 0.6 ? 2 : 1;
    return roll < 0.2 ? 2 : 0;
  }
  if (grade === "perfect") {
    if (roll < 0.15 * boost) return 6;
    if (roll < 0.72) return 4;
    return roll < 0.88 ? 2 : 1;
  }
  if (grade === "good") {
    if (roll < 0.42 * boost) return 4;
    if (roll < 0.7) return 2;
    return roll < 0.85 ? 1 : 0;
  }
  if (roll < 0.22) return 2;
  if (roll < 0.55) return 1;
  return 0;
}

function wicketHow(shot: Shot | null, d: Delivery, rng: () => number): string {
  const r = rng();
  if (!shot || shot === "block" || d.length === "yorker") return r < 0.7 ? "بولډ" : "LBW";
  if (shot === "loft" || shot === "pull") return r < 0.75 ? "کیچ" : "بولډ";
  if (r < 0.45) return "کیچ";
  if (r < 0.75) return "LBW";
  return "بولډ";
}

function blurb(runs: number, wicket: boolean, how: string, shot: Shot | null, grade: BallResult["timing"]): string {
  if (wicket) {
    if (how === "بولډ") return "اوټ! سټمپونه مات شول.";
    if (how === "کیچ") return "اوټ! فیلډر کیچ ونیوه.";
    return "اوټ! LBW.";
  }
  if (runs === 6) return grade === "perfect" ? "شپږ! بال له لوبغالي ووت." : "شپږ!";
  if (runs === 4) return "څلور! پولې ته ورسېد.";
  if (runs === 2) return "دوه منډې.";
  if (runs === 1) return "یوه منډه.";
  if (!shot) return "شاټ ونه شو.";
  if (shot === "block") return "دفاع.";
  return "ډاټ بال.";
}

export function resolveBall(
  d: Delivery,
  shot: Shot | null,
  timingError: number | null,
  rng: () => number,
): BallResult {
  if (shot == null || timingError == null) {
    const bowled = (d.length === "yorker" || d.length === "full") && d.line !== "off" && rng() < (d.length === "yorker" ? 0.55 : 0.22);
    if (bowled) return { runs: 0, wicket: true, how: "بولډ", text: "شاټ نشته — بولډ.", timing: "miss", shot: null };
    return { runs: 0, wicket: false, how: "", text: "شاټ ونه شو.", timing: "miss", shot: null };
  }
  const grade = judgeTiming(timingError);
  const match = fit(shot, d);
  let wicketP = 0.02;
  if (grade === "miss") wicketP = 0.62;
  else if (grade === "ok") wicketP = 0.16 + (1 - match) * 0.28;
  else if (grade === "good") wicketP = 0.04 + (1 - match) * 0.2;
  else wicketP = 0.012 + (1 - match) * 0.08;
  if (shot === "block" && grade !== "miss") wicketP *= 0.35;
  if (d.length === "yorker" && shot === "loft") wicketP = Math.max(wicketP, grade === "perfect" ? 0.12 : 0.45);
  if (rng() < wicketP) {
    const how = wicketHow(shot, d, rng);
    return { runs: 0, wicket: true, how, text: blurb(0, true, how, shot, grade), timing: grade, shot };
  }
  let runs = pickRuns(shot, grade, match, rng);
  if (grade === "miss") runs = 0;
  return { runs, wicket: false, how: "", text: blurb(runs, false, "", shot, grade), timing: grade, shot };
}

export interface Innings {
  runs: number;
  wickets: number;
  balls: number;
  striker: number;
  nonStriker: number;
  nextBatter: number;
  scores: number[];
  ballsFaced: number[];
  fours: number;
  sixes: number;
  extras: number;
  recent: string[];
  bowlerBalls: number[];
  bowlerRuns: number[];
  bowlerWkts: number[];
}

export function freshInnings(): Innings {
  return {
    runs: 0,
    wickets: 0,
    balls: 0,
    striker: 0,
    nonStriker: 1,
    nextBatter: 2,
    scores: Array(11).fill(0),
    ballsFaced: Array(11).fill(0),
    fours: 0,
    sixes: 0,
    extras: 0,
    recent: [],
    bowlerBalls: [0, 0, 0, 0],
    bowlerRuns: [0, 0, 0, 0],
    bowlerWkts: [0, 0, 0, 0],
  };
}

export function applyBall(inn: Innings, result: BallResult): Innings {
  const next: Innings = {
    ...inn,
    scores: inn.scores.slice(),
    ballsFaced: inn.ballsFaced.slice(),
    recent: inn.recent.slice(),
    bowlerBalls: inn.bowlerBalls.slice(),
    bowlerRuns: inn.bowlerRuns.slice(),
    bowlerWkts: inn.bowlerWkts.slice(),
  };
  const bidx = Math.floor(next.balls / 6) % 4;
  next.bowlerBalls[bidx] += 1;
  if (result.wicket) {
    next.wickets += 1;
    next.ballsFaced[next.striker] += 1;
    next.bowlerWkts[bidx] += 1;
    next.recent.push("W");
    if (next.wickets < 10) {
      next.striker = next.nextBatter;
      next.nextBatter += 1;
    }
  } else {
    next.runs += result.runs;
    next.scores[next.striker] += result.runs;
    next.ballsFaced[next.striker] += 1;
    next.bowlerRuns[bidx] += result.runs;
    if (result.runs === 4) next.fours += 1;
    if (result.runs === 6) next.sixes += 1;
    next.recent.push(String(result.runs));
    if (result.runs % 2 === 1) {
      const s = next.striker;
      next.striker = next.nonStriker;
      next.nonStriker = s;
    }
  }
  next.balls += 1;
  if (next.recent.length > 12) next.recent = next.recent.slice(-12);
  if (next.balls % 6 === 0) {
    const s = next.striker;
    next.striker = next.nonStriker;
    next.nonStriker = s;
  }
  return next;
}

export function simulateInnings(
  overs: number,
  seed: number,
  bowlers: string[],
  level: "easy" | "normal" | "hard",
): { runs: number; wickets: number } {
  const rng = mulberry32(seed);
  const max = overs * 6;
  let runs = 0;
  let wickets = 0;
  for (let i = 0; i < max && wickets < 10; i++) {
    const d = rollDelivery(rng, Math.floor(i / 6), bowlers);
    const ai = aiReply(d, rng, level);
    const res = resolveBall(d, ai.shot, ai.err, rng);
    if (res.wicket) wickets += 1;
    else runs += res.runs;
  }
  return { runs, wickets };
}

export const CONTACT_AT = 0.74;
export const BALL_SECONDS = 1.35;

export function overBallLabel(balls: number): string {
  return `${Math.floor(balls / 6)}.${balls % 6}`;
}

export function bowlersOf(players: string[]): string[] {
  return players.slice(7, 11);
}
