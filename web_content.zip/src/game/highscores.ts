export interface HighScore {
  name: string;
  score: number;
  kills: number;
  headshots: number;
  time: number; // seconds survived
  date: number; // timestamp
}

const KEY = 'zs_highscores_v1';
export const MAX_SCORES = 10;

export function loadHighScores(): HighScore[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as HighScore[];
    if (!Array.isArray(parsed)) return [];
    return parsed.slice(0, MAX_SCORES);
  } catch {
    return [];
  }
}

export function saveHighScores(list: HighScore[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(list.slice(0, MAX_SCORES)));
  } catch {
    /* ignore */
  }
}

export function qualifies(list: HighScore[], score: number): boolean {
  if (score <= 0) return false;
  if (list.length < MAX_SCORES) return true;
  return score > list[list.length - 1].score;
}

/** Inserts an entry and returns the new list plus the index it landed at. */
export function insertHighScore(list: HighScore[], entry: HighScore): { list: HighScore[]; index: number } {
  const next = [...list, entry].sort((a, b) => b.score - a.score || b.kills - a.kills).slice(0, MAX_SCORES);
  const index = next.indexOf(entry);
  saveHighScores(next);
  return { list: next, index };
}

export function getLastName(): string {
  try {
    return localStorage.getItem('zs_lastname') || 'ACE';
  } catch {
    return 'ACE';
  }
}

export function setLastName(name: string) {
  try {
    localStorage.setItem('zs_lastname', name);
  } catch {
    /* ignore */
  }
}

export function formatTime(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}
