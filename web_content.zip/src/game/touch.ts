import { useEffect, useRef } from 'react'
import type * as React from 'react'
import { ACTION_BTN, JOYSTICK } from './config'

export type TouchControlState = {
  /** Normalized stick direction (-1..1). */
  dirX: number
  dirY: number
  /** Action button currently held. */
  actionHeld: boolean
  /** Rising edge of action this frame — consumed by update. */
  actionPressed: boolean
  joyActive: boolean
  joyOriginX: number
  joyOriginY: number
  joyKnobX: number
  joyKnobY: number
  btnPressed: boolean
}

function empty(): TouchControlState {
  return {
    dirX: 0,
    dirY: 0,
    actionHeld: false,
    actionPressed: false,
    joyActive: false,
    joyOriginX: 0,
    joyOriginY: 0,
    joyKnobX: 0,
    joyKnobY: 0,
    btnPressed: false,
  }
}

type Zone = 'joy' | 'btn' | null

/**
 * Dual-touch: left half = virtual stick, right half = action button.
 * Also exposes keyboard WASD/arrows + Space/Enter as fallback.
 */
export function useTouchControls(sizeRef: React.MutableRefObject<{ w: number; h: number }>) {
  const touchRef = useRef<TouchControlState>(empty())
  const pointers = useRef<Map<number, Zone>>(new Map())
  const keys = useRef<Set<string>>(new Set())
  const prevAction = useRef(false)

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      keys.current.add(e.code)
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) {
        e.preventDefault()
      }
    }
    const up = (e: KeyboardEvent) => keys.current.delete(e.code)
    const blur = () => keys.current.clear()
    window.addEventListener('keydown', down, { passive: false })
    window.addEventListener('keyup', up)
    window.addEventListener('blur', blur)
    return () => {
      window.removeEventListener('keydown', down)
      window.removeEventListener('keyup', up)
      window.removeEventListener('blur', blur)
    }
  }, [])

  const btnCenter = () => {
    const { w, h } = sizeRef.current
    return {
      x: w - ACTION_BTN.margin - ACTION_BTN.r - 8,
      y: h - ACTION_BTN.margin - ACTION_BTN.r - 24,
    }
  }

  const inBtn = (x: number, y: number) => {
    const c = btnCenter()
    const dx = x - c.x
    const dy = y - c.y
    return dx * dx + dy * dy <= (ACTION_BTN.r + 18) ** 2
  }

  const applyJoy = (ox: number, oy: number, x: number, y: number) => {
    const t = touchRef.current
    let dx = x - ox
    let dy = y - oy
    const max = JOYSTICK.baseR
    const len = Math.hypot(dx, dy) || 1
    if (len > max) {
      dx = (dx / len) * max
      dy = (dy / len) * max
    }
    t.joyKnobX = ox + dx
    t.joyKnobY = oy + dy
    let nx = dx / max
    let ny = dy / max
    const mag = Math.hypot(nx, ny)
    if (mag < JOYSTICK.dead) {
      t.dirX = 0
      t.dirY = 0
    } else {
      const scale = Math.min(1, (mag - JOYSTICK.dead) / (1 - JOYSTICK.dead))
      t.dirX = (nx / mag) * scale
      t.dirY = (ny / mag) * scale
    }
  }

  const releaseZone = (zone: Zone) => {
    const t = touchRef.current
    if (zone === 'joy') {
      t.joyActive = false
      t.dirX = 0
      t.dirY = 0
    } else if (zone === 'btn') {
      t.btnPressed = false
      t.actionHeld = false
    }
  }

  const handlers = {
    onPointerDown: (e: React.PointerEvent<HTMLElement>) => {
      const r = e.currentTarget.getBoundingClientRect()
      const x = e.clientX - r.left
      const y = e.clientY - r.top
      const { w } = sizeRef.current
      let zone: Zone = null

      if (inBtn(x, y) || x > w * 0.62) {
        zone = 'btn'
        touchRef.current.btnPressed = true
        touchRef.current.actionHeld = true
      } else {
        zone = 'joy'
        const t = touchRef.current
        t.joyActive = true
        t.joyOriginX = x
        t.joyOriginY = y
        applyJoy(x, y, x, y)
      }
      pointers.current.set(e.pointerId, zone)
      e.currentTarget.setPointerCapture?.(e.pointerId)
    },
    onPointerMove: (e: React.PointerEvent<HTMLElement>) => {
      const zone = pointers.current.get(e.pointerId)
      if (!zone) return
      const r = e.currentTarget.getBoundingClientRect()
      const x = e.clientX - r.left
      const y = e.clientY - r.top
      if (zone === 'joy') {
        const t = touchRef.current
        applyJoy(t.joyOriginX, t.joyOriginY, x, y)
      }
    },
    onPointerUp: (e: React.PointerEvent<HTMLElement>) => {
      const zone = pointers.current.get(e.pointerId)
      pointers.current.delete(e.pointerId)
      if (zone) releaseZone(zone)
    },
    onPointerCancel: (e: React.PointerEvent<HTMLElement>) => {
      const zone = pointers.current.get(e.pointerId)
      pointers.current.delete(e.pointerId)
      if (zone) releaseZone(zone)
    },
  }

  /** Call once per frame before update; merges keyboard + touch, computes action edge. */
  const sample = (): TouchControlState => {
    const t = touchRef.current
    let dx = t.dirX
    let dy = t.dirY
    const k = keys.current
    if (k.has('ArrowLeft') || k.has('KeyA')) dx = -1
    if (k.has('ArrowRight') || k.has('KeyD')) dx = 1
    if (k.has('ArrowUp') || k.has('KeyW')) dy = -1
    if (k.has('ArrowDown') || k.has('KeyS')) dy = 1
    // normalize diagonals for keyboard
    const len = Math.hypot(dx, dy)
    if (len > 1) {
      dx /= len
      dy /= len
    }

    const keyAction = k.has('Space') || k.has('Enter') || k.has('KeyE')
    const held = t.actionHeld || keyAction
    t.actionPressed = held && !prevAction.current
    prevAction.current = held
    t.actionHeld = held
    // expose merged dirs without mutating stick visual
    return {
      ...t,
      dirX: dx,
      dirY: dy,
      actionHeld: held,
      actionPressed: t.actionPressed,
    }
  }

  return { touchRef, handlers, sample, btnCenter }
}
