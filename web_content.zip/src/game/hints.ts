/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Pure per-level Hint Reward System state & helpers for ARROW MASTER.
 * Ensures:
 * - Exactly 1 free hint per level attempt
 * - Unlimited repeated rewarded hints (strictly +1 per completed rewarded ad)
 * - Clean reset whenever starting/restarting/changing levels
 */

export interface LevelHintState {
  levelAttemptId: string;
  freeHintUsed: boolean;
  extraHintsAvailable: number;
  rewardSeq: number;
}

export type HintAvailability =
  | { canUseNow: true; source: 'free' | 'extra' }
  | { canUseNow: false; reason: 'requires_rewarded_ad' };

export function createFreshHintState(levelNumber: number): LevelHintState {
  const randomSuffix = Math.random().toString(36).slice(2, 8);
  return {
    levelAttemptId: `lv${levelNumber}_${Date.now()}_${randomSuffix}`,
    freeHintUsed: false,
    extraHintsAvailable: 0,
    rewardSeq: 0,
  };
}

export function checkHintAvailability(state: LevelHintState): HintAvailability {
  if (!state.freeHintUsed) {
    return { canUseNow: true, source: 'free' };
  }
  if (state.extraHintsAvailable > 0) {
    return { canUseNow: true, source: 'extra' };
  }
  return { canUseNow: false, reason: 'requires_rewarded_ad' };
}

export function consumeAvailableHint(state: LevelHintState): {
  consumed: boolean;
  source: 'free' | 'extra' | null;
} {
  if (!state.freeHintUsed) {
    state.freeHintUsed = true;
    return { consumed: true, source: 'free' };
  }
  if (state.extraHintsAvailable > 0) {
    state.extraHintsAvailable -= 1;
    return { consumed: true, source: 'extra' };
  }
  return { consumed: false, source: null };
}

export function grantRewardedHint(state: LevelHintState): number {
  state.extraHintsAvailable += 1;
  return state.extraHintsAvailable;
}

export function nextHintRewardEventId(state: LevelHintState): string {
  state.rewardSeq += 1;
  return `hint_${state.levelAttemptId}_${state.rewardSeq}`;
}
