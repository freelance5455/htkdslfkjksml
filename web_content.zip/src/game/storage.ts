/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CustomLevel, GameSettings, SaveData } from './types';

const STORAGE_KEY = 'arrow_master_save_v1';

export const DEFAULT_SETTINGS: GameSettings = {
  sound: true,
  soundVolume: 85,
  music: true,
  musicVolume: 65,
  haptics: true,
  showGrid: false,
};

const defaultSaveData: SaveData = {
  currentLevel: 1,
  completedLevels: {},
  coins: 0,
  hearts: 3,
  customLevels: [],
  settings: { ...DEFAULT_SETTINGS },
  editorUnlocked: false,
};

export class StorageManager {
  private data: SaveData;

  constructor() {
    this.data = this.load();
  }

  public getData(): SaveData {
    return this.data;
  }

  private load(): SaveData {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        return {
          ...defaultSaveData,
          settings: { ...DEFAULT_SETTINGS },
        };
      }
      const parsed = JSON.parse(raw);
      const parsedSettings = parsed.settings || {};
      return {
        ...defaultSaveData,
        ...parsed,
        settings: {
          ...DEFAULT_SETTINGS,
          ...parsedSettings,
          soundVolume:
            typeof parsedSettings.soundVolume === 'number'
              ? Math.max(0, Math.min(100, parsedSettings.soundVolume))
              : DEFAULT_SETTINGS.soundVolume,
          musicVolume:
            typeof parsedSettings.musicVolume === 'number'
              ? Math.max(0, Math.min(100, parsedSettings.musicVolume))
              : DEFAULT_SETTINGS.musicVolume,
          showGrid:
            typeof parsedSettings.showGrid === 'boolean'
              ? parsedSettings.showGrid
              : DEFAULT_SETTINGS.showGrid,
        },
      };
    } catch {
      return {
        ...defaultSaveData,
        settings: { ...DEFAULT_SETTINGS },
      };
    }
  }

  public save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
    } catch (err) {
      console.warn('Failed to save to localStorage:', err);
    }
  }

  public completeLevel(levelId: string | number, stars: number, mistakes: number) {
    const key = String(levelId);
    const existing = this.data.completedLevels[key];
    const bestStars = existing ? Math.max(existing.stars, stars) : stars;
    const bestMistakes = existing ? Math.min(existing.mistakes, mistakes) : mistakes;

    this.data.completedLevels[key] = {
      stars: bestStars,
      mistakes: bestMistakes,
      completedAt: Date.now(),
    };

    const coinReward = 15 + stars * 5;
    this.data.coins += coinReward;

    const num = typeof levelId === 'number' ? levelId : parseInt(key, 10);
    if (!isNaN(num)) {
      if (num >= 10) {
        this.data.editorUnlocked = true;
      }
      if (num === this.data.currentLevel) {
        this.data.currentLevel = num + 1;
      }
    }

    this.save();
  }

  public isLevelUnlocked(levelNumber: number): boolean {
    if (levelNumber === 1) return true;
    return !!this.data.completedLevels[String(levelNumber - 1)];
  }

  public isEditorUnlocked(): boolean {
    return this.data.editorUnlocked || this.data.completedLevels['10'] !== undefined;
  }

  public unlockEditorCheat() {
    this.data.editorUnlocked = true;
    this.save();
  }

  public getNextCustomLevelNumber(): number {
    let maxNum = 10;
    for (const lvl of this.data.customLevels) {
      if (typeof lvl.levelNumber === 'number' && lvl.levelNumber > maxNum) {
        maxNum = lvl.levelNumber;
      }
    }
    return maxNum + 1;
  }

  public getCustomLevelByNumber(levelNumber: number): CustomLevel | undefined {
    return this.data.customLevels.find((lvl) => lvl.levelNumber === levelNumber);
  }

  public addCustomLevel(customLevel: CustomLevel) {
    this.data.customLevels = this.data.customLevels.filter((lvl) => lvl.id !== customLevel.id);
    this.data.customLevels.unshift(customLevel);
    this.save();
  }

  public deleteCustomLevel(id: string | number) {
    this.data.customLevels = this.data.customLevels.filter((lvl) => String(lvl.id) !== String(id));
    delete this.data.completedLevels[String(id)];
    this.save();
  }

  public updateSettings(settings: Partial<GameSettings>) {
    this.data.settings = { ...this.data.settings, ...settings };
    this.save();
  }

  public resetSettings() {
    this.data.settings = { ...DEFAULT_SETTINGS };
    this.save();
  }

  public resetProgress() {
    const keptSettings = { ...this.data.settings };
    this.data = {
      ...defaultSaveData,
      settings: keptSettings,
    };
    this.save();
  }
}

export const storage = new StorageManager();
