import { STORAGE_KEYS } from './constants';

export interface Stats {
  matches: number;
  wins: number;
  kills: number;
  bestKills: number;
}

const EMPTY: Stats = { matches: 0, wins: 0, kills: 0, bestKills: 0 };

export function loadStats(): Stats {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.stats);
    if (!raw) return { ...EMPTY };
    const v = JSON.parse(raw) as Partial<Stats>;
    return {
      matches: Number(v.matches) || 0,
      wins: Number(v.wins) || 0,
      kills: Number(v.kills) || 0,
      bestKills: Number(v.bestKills) || 0,
    };
  } catch {
    return { ...EMPTY };
  }
}

export function recordMatch(kills: number, win: boolean) {
  const s = loadStats();
  s.matches += 1;
  if (win) s.wins += 1;
  s.kills += kills;
  s.bestKills = Math.max(s.bestKills, kills);
  try {
    localStorage.setItem(STORAGE_KEYS.stats, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

export function sanitizeName(raw: string): string {
  return raw
    .replace(/[^A-Za-z0-9 _-]/g, '')
    .replace(/\s+/g, ' ')
    .slice(0, 14);
}

export function loadName(): string {
  try {
    return sanitizeName(localStorage.getItem(STORAGE_KEYS.name) ?? '').trim() || 'Survivor';
  } catch {
    return 'Survivor';
  }
}

export function saveName(name: string) {
  try {
    localStorage.setItem(STORAGE_KEYS.name, name);
  } catch {
    /* ignore */
  }
}
