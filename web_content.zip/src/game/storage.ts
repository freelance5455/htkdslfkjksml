// ──────────────────────────────────────────────────────────────
// LocalStorage: рекорд, настройка звука и сохранение партии
// ──────────────────────────────────────────────────────────────

const KEY_BEST = "bp8_best";
const KEY_SOUND = "bp8_sound";
const KEY_SAVE = "bp8_save_v1";

export interface SavedPiece {
  shapeIdx: number;
  color: number;
  used: boolean;
}

export interface SavedGame {
  board: number[]; // 64 значения, -1 = пусто, иначе индекс цвета
  score: number;
  combo: number;
  pieces: SavedPiece[];
}

function read(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function write(key: string, value: string): void {
  try {
    localStorage.setItem(key, value);
  } catch {
    /* приватный режим — игнорируем */
  }
}

export function getBestScore(): number {
  const v = parseInt(read(KEY_BEST) ?? "0", 10);
  return Number.isFinite(v) && v > 0 ? v : 0;
}

export function setBestScore(score: number): void {
  write(KEY_BEST, String(score));
}

export function getSoundEnabled(): boolean {
  return read(KEY_SOUND) !== "0";
}

export function setSoundEnabled(on: boolean): void {
  write(KEY_SOUND, on ? "1" : "0");
}

export function saveGame(state: SavedGame): void {
  write(KEY_SAVE, JSON.stringify(state));
}

export function clearSavedGame(): void {
  try {
    localStorage.removeItem(KEY_SAVE);
  } catch {
    /* ок */
  }
}

export function loadGame(maxShapeIdx: number): SavedGame | null {
  const raw = read(KEY_SAVE);
  if (!raw) return null;
  try {
    const data = JSON.parse(raw) as SavedGame;
    if (
      !Array.isArray(data.board) ||
      data.board.length !== 64 ||
      !Array.isArray(data.pieces) ||
      data.pieces.length !== 3 ||
      typeof data.score !== "number"
    ) {
      return null;
    }
    for (const p of data.pieces) {
      if (
        typeof p.shapeIdx !== "number" ||
        p.shapeIdx < 0 ||
        p.shapeIdx >= maxShapeIdx ||
        typeof p.color !== "number"
      ) {
        return null;
      }
    }
    return data;
  } catch {
    return null;
  }
}
