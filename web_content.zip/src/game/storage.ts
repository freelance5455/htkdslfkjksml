import type { HighScoreEntry } from './types';

const KEY_SCORES = 'wordrush.highscores.v1';
const KEY_NAME = 'wordrush.name';
const KEY_MUTED = 'wordrush.muted';
export const MAX_SCORES = 10;

function safeGet(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function safeSet(key: string, value: string) {
  try {
    localStorage.setItem(key, value);
  } catch {
    /* storage unavailable (private mode etc.) */
  }
}

export function loadScores(): HighScoreEntry[] {
  const raw = safeGet(KEY_SCORES);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as HighScoreEntry[];
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((e) => e && typeof e.score === 'number')
      .sort((a, b) => b.score - a.score)
      .slice(0, MAX_SCORES);
  } catch {
    return [];
  }
}

/** Saves the entry and returns its rank (0-based) or -1 if it didn't make the table. */
export function saveScore(entry: HighScoreEntry): { scores: HighScoreEntry[]; rank: number } {
  const scores = loadScores();
  scores.push(entry);
  scores.sort((a, b) => b.score - a.score || a.date - b.date);
  const trimmed = scores.slice(0, MAX_SCORES);
  safeSet(KEY_SCORES, JSON.stringify(trimmed));
  const rank = trimmed.findIndex((e) => e === entry);
  return { scores: trimmed, rank };
}

export function getBestScore(): number {
  const s = loadScores();
  return s.length ? s[0].score : 0;
}

export function loadName(): string {
  return (safeGet(KEY_NAME) || 'YOU').slice(0, 10);
}

export function saveName(name: string) {
  safeSet(KEY_NAME, name.slice(0, 10));
}

export function loadMuted(): boolean {
  return safeGet(KEY_MUTED) === '1';
}

export function saveMuted(m: boolean) {
  safeSet(KEY_MUTED, m ? '1' : '0');
}
