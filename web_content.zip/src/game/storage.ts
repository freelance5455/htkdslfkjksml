import { STORAGE_KEYS } from './constants';

export type QualityPref = 'auto' | 'low' | 'high';

export interface Settings {
  sound: boolean;
  haptics: boolean;
  quality: QualityPref;
}

export interface SaveData {
  version: number;
  board: number[];
  pieces: Array<number | null>;
  score: number;
  combo: number;
  movesSinceClear: number;
}

export interface Stats {
  games: number;
  lines: number;
  maxCombo: number;
}

const SAVE_VERSION = 1;

function read<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

function write(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage may be unavailable (private mode) – ignore */
  }
}

function remove(key: string): void {
  try {
    localStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}

const DEFAULT_SETTINGS: Settings = { sound: true, haptics: true, quality: 'auto' };

export const storage = {
  getBest(): number {
    const v = read<number>(STORAGE_KEYS.best);
    return typeof v === 'number' && isFinite(v) ? v : 0;
  },
  setBest(v: number): void {
    write(STORAGE_KEYS.best, Math.max(0, Math.round(v)));
  },

  getSettings(): Settings {
    const s = read<Partial<Settings>>(STORAGE_KEYS.settings);
    return { ...DEFAULT_SETTINGS, ...(s ?? {}) };
  },
  setSettings(s: Settings): void {
    write(STORAGE_KEYS.settings, s);
  },

  getSave(): SaveData | null {
    const s = read<SaveData>(STORAGE_KEYS.save);
    if (!s || s.version !== SAVE_VERSION) return null;
    if (!Array.isArray(s.board) || s.board.length !== 64 || !Array.isArray(s.pieces)) return null;
    return s;
  },
  setSave(s: Omit<SaveData, 'version'>): void {
    write(STORAGE_KEYS.save, { ...s, version: SAVE_VERSION });
  },
  clearSave(): void {
    remove(STORAGE_KEYS.save);
  },

  getAutoTier(): string | null {
    const v = read<string>(STORAGE_KEYS.autoTier);
    return typeof v === 'string' ? v : null;
  },
  setAutoTier(t: string): void {
    write(STORAGE_KEYS.autoTier, t);
  },

  getStats(): Stats {
    const s = read<Partial<Stats>>(STORAGE_KEYS.stats);
    return { games: 0, lines: 0, maxCombo: 0, ...(s ?? {}) };
  },
  setStats(s: Stats): void {
    write(STORAGE_KEYS.stats, s);
  },
};
