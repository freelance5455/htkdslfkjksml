import { useEffect, useState } from "react";
import { Canvas } from "@react-three/fiber";
import * as THREE from "three";
import { resumeAudio, unlockAudio } from "./audio";
import { Hud } from "./hud";
import { World } from "./scene";
import { getSim, installProbe, openMenu } from "./sim";
import { useHud } from "./store";

export function Game() {
  const [vp, setVp] = useState(() => ({
    w: window.innerWidth,
    h: window.innerHeight,
  }));

  useEffect(() => {
    installProbe();
    const read = () => setVp({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener("resize", read);
    window.addEventListener("orientationchange", read);
    const onKey = (e: KeyboardEvent) => {
      const t = e.target;
      if (t instanceof HTMLElement && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) return;
      if (e.code === "Space" || e.code.startsWith("Arrow")) e.preventDefault();
      const sim = getSim();
      if (e.type === "keydown") {
        sim.keys.add(e.code);
        if (e.code === "KeyC" && !e.repeat && sim.mode === "play") {
          sim.autoCam = !sim.autoCam;
          sim.toast = sim.autoCam ? "Camera follows you" : "Camera free — right-drag or Z / X";
          sim.toastUntil = sim.time + 2.4;
          useHud.getState().bump();
        }
        if (e.code === "Escape" && !e.repeat && sim.mode === "play") {
          openMenu(useHud.getState().menu ? null : "help");
        }
      } else sim.keys.delete(e.code);
    };
    const clear = () => getSim().keys.clear();
    window.addEventListener("keydown", onKey);
    window.addEventListener("keyup", onKey);
    window.addEventListener("blur", clear);
    const vis = () => {
      if (document.visibilityState === "visible") resumeAudio();
    };
    document.addEventListener("visibilitychange", vis);
    return () => {
      window.removeEventListener("resize", read);
      window.removeEventListener("orientationchange", read);
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("keyup", onKey);
      window.removeEventListener("blur", clear);
      document.removeEventListener("visibilitychange", vis);
    };
  }, []);

  const portrait = vp.h > vp.w + 30;
  const rot = portrait ? 90 : 0;

  return (
    <div className="game-root">
      <div
        className="game-stage"
        data-rot={rot}
        style={{
          width: portrait ? vp.h : vp.w,
          height: portrait ? vp.w : vp.h,
          transform: `translate(-50%, -50%) rotate(${rot}deg)`,
        }}
        onContextMenu={(e) => e.preventDefault()}
        onPointerDown={() => unlockAudio()}
      >
        <Canvas
          className="game-canvas"
          shadows
          dpr={[1, 1.6]}
          camera={{ fov: 40, near: 0.1, far: 220, position: [0, 9, 14] }}
          gl={{ antialias: true, alpha: false, toneMapping: THREE.NoToneMapping, powerPreference: "high-performance" }}
        >
          <World />
        </Canvas>
        <div className="hud-layer">
          <Hud />
        </div>
      </div>
    </div>
  );
}
