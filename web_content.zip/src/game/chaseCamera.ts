import * as THREE from 'three'
import { CONFIG } from './config'
import { groundHeight } from './terrain'

/**
 * Third-person camera that trails the aircraft from behind. Direction, up vector and position are
 * smoothed separately (exponential, frame-rate independent): the camera lags gently through manoeuvres,
 * banks only part of the way with the aircraft, widens its field of view with speed and never dips
 * under the terrain.
 */
const WORLD_UP = new THREE.Vector3(0, 1, 0)

export class ChaseCamera {
  readonly camera = new THREE.PerspectiveCamera(CONFIG.camera.fov, 16 / 9, 1, 7000)
  private readonly dir = new THREE.Vector3(0, 0, -1)
  private readonly up = new THREE.Vector3(0, 1, 0)
  private readonly desired = new THREE.Vector3()
  private readonly target = new THREE.Vector3()
  private readonly tmp = new THREE.Vector3()
  /** Camera shake amplitude in metres (0 disables). */
  shake = 0
  reducedMotion = false

  /** Jump straight to the follow position (run start, respawn). */
  snap(position: THREE.Vector3, forward: THREE.Vector3, up: THREE.Vector3): void {
    this.dir.copy(forward)
    this.up.copy(WORLD_UP).lerp(up, 0.3).normalize()
    this.place(position, 1, 0)
  }

  update(dt: number, position: THREE.Vector3, forward: THREE.Vector3, up: THREE.Vector3, speed01: number, time: number): void {
    const k = 1 - Math.exp(-CONFIG.camera.follow * dt)
    const kp = 1 - Math.exp(-CONFIG.camera.follow * 1.7 * dt)
    this.dir.lerp(forward, k).normalize()
    this.tmp.copy(WORLD_UP).lerp(up, 0.3).normalize()
    this.up.lerp(this.tmp, k).normalize()
    this.place(position, kp, speed01)
    this.applyShake(time, speed01)
  }

  private place(position: THREE.Vector3, kp: number, speed01: number): void {
    const dist = CONFIG.camera.distance * (1 + 0.1 * speed01)
    this.desired.copy(position).addScaledVector(this.dir, -dist).addScaledVector(this.up, CONFIG.camera.height)
    if (kp >= 1) this.camera.position.copy(this.desired)
    else this.camera.position.lerp(this.desired, kp)
    const floor = groundHeight(this.camera.position.x, this.camera.position.z) + 6
    if (this.camera.position.y < floor) this.camera.position.y = floor
    this.target.copy(position).addScaledVector(this.dir, 26)
    this.camera.up.copy(this.up)
    this.camera.lookAt(this.target)
    const fov = CONFIG.camera.fov + speed01 * 9
    if (Math.abs(this.camera.fov - fov) > 0.05) {
      this.camera.fov = fov
      this.camera.updateProjectionMatrix()
    }
  }

  private applyShake(time: number, speed01: number): void {
    if (this.reducedMotion) return
    const amp = this.shake + speed01 * 0.05
    if (amp <= 0.001) return
    this.camera.position.x += Math.sin(time * 41.3) * amp
    this.camera.position.y += Math.sin(time * 37.1 + 1.7) * amp
    this.camera.position.z += Math.sin(time * 29.7 + 4.1) * amp
  }

  /** Free orbit around a point (title screen and crash replay). */
  orbit(center: THREE.Vector3, radius: number, angle: number, elevation: number): void {
    this.camera.position.set(
      center.x + Math.sin(angle) * Math.cos(elevation) * radius,
      center.y + Math.sin(elevation) * radius,
      center.z + Math.cos(angle) * Math.cos(elevation) * radius,
    )
    const floor = groundHeight(this.camera.position.x, this.camera.position.z) + 4
    if (this.camera.position.y < floor) this.camera.position.y = floor
    this.camera.up.copy(WORLD_UP)
    this.camera.lookAt(center)
    if (Math.abs(this.camera.fov - 52) > 0.05) {
      this.camera.fov = 52
      this.camera.updateProjectionMatrix()
    }
  }
}
