// World & match tuning. All distances are metres, times are seconds.
export const MAP_RADIUS = 110;
export const WATER_LEVEL = 0;

export const PLAYER_RADIUS = 0.36;
export const WALK_SPEED = 4.4;
export const SPRINT_SPEED = 7.4;
export const ADS_SPEED_MUL = 0.55;
export const GRAVITY = 22;
export const JUMP_V = 7.5;
export const MOUSE_SENS = 0.0024;
export const DROP_TIME = 4.5;

export const BOT_COUNT = 15;
export const PLAYER_MAX_HP = 100;
export const MAX_MEDS = 5;
export const MED_HEAL = 50;

/** Safe-zone schedule: wait, then shrink to `radius` over `shrink` seconds. `dps` applies outside. */
export const ZONE_PHASES = [
  { wait: 40, shrink: 30, radius: 62, dps: 1 },
  { wait: 28, shrink: 24, radius: 36, dps: 3 },
  { wait: 22, shrink: 18, radius: 18, dps: 6 },
  { wait: 16, shrink: 14, radius: 6, dps: 10 },
];

export const STORAGE_KEYS = {
  name: 'jyrex-fire:name',
  stats: 'jyrex-fire:stats:v1',
  muted: 'jyrex-fire:muted',
} as const;
