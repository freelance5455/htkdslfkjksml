/**
 * SPR - Sahil Powerful Run
 * Game Constants & 15 Stylized 3D Character Definitions
 */

export * from './constants/characters';
export { type BoardSkinDef } from './models/Skateboard3D';

export const GAME_CONFIG = {
  // Lane positions (3 distinct running lanes)
  LANES: [-3.2, 0, 3.2],
  LANE_SWITCH_SPEED: 18, // units per second
  
  // Player motion & Progressive Speed Scaling
  INITIAL_SPEED: 14, // Smooth starting speed
  MAX_SPEED: 34,    // Reasonable, thrilling yet playable maximum speed
  SPEED_INCREMENT: 0.15, // Smooth gradual increment
  JUMP_FORCE: 16.5,
  GRAVITY: -42,
  SLIDE_DURATION: 0.85, // seconds
  
  // Track & Coastal Railway Environment
  SEGMENT_LENGTH: 50,
  VISIBLE_SEGMENTS: 7,
  FOG_DENSITY: 0.003, // Crisp tropical coastal daylight haze
  FOG_COLOR: 0x93c5fd, // Vibrant coastal sky haze
  SKY_COLOR: 0x0284c7, // Radiant daytime azure sky
  
  // Power-up durations in seconds
  POWERUP_DURATIONS: {
    magnet: 10,
    rocket: 32, // Master 30-34s Rocket Flight duration (target 32s)
    shield: 15,
    doubleCoins: 12,
    speedBoost: 6,
  },

  // Skateboard duration & recharge
  SKATEBOARD_DURATION: 25, // seconds
  
  // Scoring
  SCORE_PER_METER: 1,
  COIN_SCORE: 10,
};

export type PowerUpType = 'magnet' | 'rocket' | 'shield' | 'doubleCoins' | 'speedBoost';

export type ObstacleType = 
  | 'train'
  | 'barricade'
  | 'woodenCrates'
  | 'jumpRamp'
  | 'overheadSignal'
  | 'fire'
  | 'tree'
  | 'rock'
  | 'fireRock'
  | 'rollingBoulder'
  | 'spikeTrap'
  | 'brokenBridge'
  | 'dangerZone';
