// ──────────────────────────────────────────────────────────────
// Глобальные константы игры + адаптация под DPI и слабые девайсы
// ──────────────────────────────────────────────────────────────

const rawDpr = typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1;
const cores =
  typeof navigator !== "undefined" ? navigator.hardwareConcurrency || 4 : 4;
const deviceMemory =
  typeof navigator !== "undefined"
    ? (navigator as unknown as { deviceMemory?: number }).deviceMemory
    : undefined;

/** Слабое устройство: меньше частиц, ниже разрешение рендера */
export const IS_LOW_END =
  cores <= 4 || (deviceMemory !== undefined && deviceMemory <= 3);

/** Кап разрешения: мощные — до 2x, слабые — до 1.35x (нет лагов) */
export const DPR = Math.min(Math.max(rawDpr, 1), IS_LOW_END ? 1.35 : 2);

/** Переводит дизайнерские единицы (макет 540×960) в пиксели рендера */
export const u = (n: number): number => Math.round(n * DPR);

export const GAME_W = u(540);
export const GAME_H = u(960);

export const GRID = 8;
export const CELL = u(57);
export const BOARD_W = CELL * GRID;
export const BOARD_X = Math.round((GAME_W - BOARD_W) / 2);
export const BOARD_Y = u(222);

export const TRAY_Y = u(802);
export const TRAY_SLOTS_X = [u(98), u(270), u(442)];
export const TRAY_SCALE = 0.42;
/** Насколько фигура поднимается над пальцем при перетаскивании */
export const LIFT = u(84);

/** Палитра блоков (основной цвет) */
export const COLORS: number[] = [
  0xff5e7a, // красно-розовый
  0xff9f43, // оранжевый
  0xffd93d, // жёлтый
  0x37d67a, // зелёный
  0x2fc8c8, // бирюзовый
  0x4aa8ff, // синий
  0x8f6bff, // фиолетовый
  0xff6bd6, // розовый
];

export const UI = {
  bgTop: 0x1d2a55,
  bgMid: 0x121a33,
  bgBottom: 0x0c1226,
  boardPanel: 0x1a2650,
  boardBorder: 0x2c3c78,
  cellEmpty: 0x0e1736,
  slot: 0x16214a,
  textMain: "#ffffff",
  textSoft: "#9fb0e8",
  gold: "#ffd93d",
};

export const FONT = 'Arial, "Helvetica Neue", Helvetica, sans-serif';
