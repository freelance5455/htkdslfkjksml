/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CharacterDef, Mission } from '../types/game';

export const TRACK_LANES = [-2.8, 0, 2.8] as const;

export const GAME_PHYSICS = {
  BASE_SPEED: 20,
  MAX_SPEED: 38,
  SPEED_ACCEL: 0.12, // increase in speed per second
  LANE_SWITCH_SPEED: 16,
  JUMP_VELOCITY: 14,
  SUPER_JUMP_VELOCITY: 20.5,
  GRAVITY: 42,
  SLIDE_DURATION: 0.72,
  NORMAL_HEIGHT: 1.8,
  SLIDE_HEIGHT: 0.75,
  JETPACK_HEIGHT: 7.2,
  JETPACK_DURATION: 8.5,
  SNEAKERS_DURATION: 11,
  MAGNET_DURATION: 11,
  MAGNET_RADIUS: 16,
  MULTIPLIER_DURATION: 12,
  CHUNK_LENGTH: 54,
  ACTIVE_CHUNKS: 8,
};

export const CHARACTERS: CharacterDef[] = [
  {
    id: 'jake',
    name: 'Dash Jake',
    tagline: 'The fearless subway graffiti artist',
    cost: 0,
    unlocked: true,
    colors: {
      skin: 0xf5cda4,
      shirt: 0xd32f2f, // Red hoodie
      pants: 0x1e3a8a, // Blue denim
      shoes: 0xffffff, // White kicks
      hat: 0xb71c1c,   // Deep red cap
      hair: 0x3e2723,  // Brown
      accent: 0xfbbf24, // Gold accents
    },
    bonusStat: 'Default All-Rounder',
  },
  {
    id: 'tricky',
    name: 'Skater Maya',
    tagline: 'High-jumping parkour prodigy',
    cost: 150,
    unlocked: false,
    colors: {
      skin: 0xffd2a6,
      shirt: 0x06b6d4, // Cyan windbreaker
      pants: 0x374151, // Charcoal cargo pants
      shoes: 0xec4899, // Hot pink skate sneakers
      hat: 0xd946ef,   // Magenta beanie
      hair: 0x111827,  // Dark hair
      accent: 0xa855f7, // Neon purple
    },
    bonusStat: '+15% Jump Duration',
  },
  {
    id: 'rex',
    name: 'Cyber Rex',
    tagline: 'Futuristic speedrunner from Neo-City',
    cost: 400,
    unlocked: false,
    colors: {
      skin: 0xe0ac69,
      shirt: 0x18181b, // Matte black techwear
      pants: 0x27272a, // Slate combat pants
      shoes: 0x10b981, // Emerald neon shoes
      hat: 0x0f172a,   // Tech visor helmet
      hair: 0x06b6d4,  // Cyan cyber streaks
      accent: 0x10b981, // High-vis cyber green
    },
    bonusStat: '+20% Magnet Range',
  },
];

export const INITIAL_MISSIONS: Mission[] = [
  {
    id: 'm1',
    title: 'Coin Harvester',
    description: 'Collect 100 coins in a single run',
    target: 100,
    progress: 0,
    completed: false,
    claimed: false,
    rewardCoins: 50,
    type: 'coins_single',
  },
  {
    id: 'm2',
    title: 'Railway Marathon',
    description: 'Reach 1,000 meters in a single run',
    target: 1000,
    progress: 0,
    completed: false,
    claimed: false,
    rewardCoins: 75,
    type: 'distance_single',
  },
  {
    id: 'm3',
    title: 'Hurdle Master',
    description: 'Jump over 10 railway barriers',
    target: 10,
    progress: 0,
    completed: false,
    claimed: false,
    rewardCoins: 60,
    type: 'jump_barriers',
  },
  {
    id: 'm4',
    title: 'Limbo Legend',
    description: 'Slide under 6 overhead sign barriers',
    target: 6,
    progress: 0,
    completed: false,
    claimed: false,
    rewardCoins: 60,
    type: 'slide_obstacles',
  },
  {
    id: 'm5',
    title: 'Power Surge',
    description: 'Collect 3 power-ups in one run',
    target: 3,
    progress: 0,
    completed: false,
    claimed: false,
    rewardCoins: 80,
    type: 'collect_powerups',
  },
  {
    id: 'm6',
    title: 'Score Hunter',
    description: 'Achieve a score of 10,000 points',
    target: 10000,
    progress: 0,
    completed: false,
    claimed: false,
    rewardCoins: 100,
    type: 'score_single',
  },
];
