// Core tunables for Word Rush
export const CAM = 3.0; // camera distance behind the player (world units)
export const HIT_Z = 0.35; // z offset ahead of the player where collisions resolve
export const BASE_SPEED = 11;
export const SPEED_PER_LEVEL = 0.95;
export const MAX_SPEED = 30;
export const ATTRACT_SPEED = 9;
export const BOOST_AMOUNT = 7;
export const BOOST_TIME = 1.3;
export const JUMP_V = 7.6;
export const GRAVITY = 24;
export const FAST_FALL_G = 70;
export const MAX_LIVES = 3;
export const COIN_VALUE = 20;
export const ANSWER_VALUE = 200;
export const MAX_COMBO = 8;
export const HURDLE_HEIGHT = 0.55;
export const INVULN_TIME = 1.1;

export const FONT_DISPLAY = "'Cinzel', 'Georgia', serif";
export const FONT_BODY = "'Nunito', 'Segoe UI', sans-serif";

export const PALETTE = {
  skyTop: '#120a2a',
  skyMid: '#3b1f63',
  skyLow: '#b8456a',
  skyHorizon: '#ffb06a',
  sun: '#ffe9a6',
  farHills: '#4a2a5e',
  city: '#2c1a44',
  groundNear: '#d7ab66',
  groundFar: '#f0bf84',
  roadA: '#8c6a44',
  roadB: '#97744b',
  roadEdge: '#5a3d26',
  roadEdgeLight: '#e6c78a',
  laneDash: '#efdcae',
  gold: '#f5c542',
  goldDark: '#c8961d',
  goldLight: '#fff1b8',
  parchment: '#f8e9c9',
  parchmentDark: '#e3c894',
  ink: '#3a2412',
  correct: '#3ddc97',
  correctDark: '#1f9e68',
  wrong: '#ff4d5e',
  wrongDark: '#b8202f',
  robe: '#2f6fe4',
  robeDark: '#1f4fb0',
  tunic: '#f1f5ff',
  sash: '#e2463a',
  skin: '#f3c79c',
  hair: '#3a2417',
  stone: '#9a8d7a',
  stoneDark: '#5f554a',
  wood: '#8b5a2b',
  woodDark: '#5a3a1a',
  palm: '#2f7d4f',
  palmDark: '#1f5a38',
  trunk: '#8a5a33',
};
