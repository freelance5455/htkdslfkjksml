import { DifficultyMode, Friend, SchoolStage } from './types';

export interface AssetDef {
  id: string;
  name: string;
  icon: string;
  cost: number;
  dailyUpkeep?: number;
  dailyRevenue?: number;
  description: string;
  category: 'housing' | 'vehicle' | 'business' | 'tech';
}

export const ASSETS: Record<string, AssetDef> = {
  phone: {
    id: 'phone',
    name: 'هاتف ذكي حديث',
    icon: '📱',
    cost: 3200,
    description: 'يفتح فرص عمل حر إلكتروني ويزيد أرباح العمل الحر 20%',
    category: 'tech'
  },
  laptop: {
    id: 'laptop',
    name: 'لابتوب احترافي',
    icon: '💻',
    cost: 8500,
    description: 'ضروري لوظائف البرمجة والعمل التقني ذو الدخل المرتفع',
    category: 'tech'
  },
  bike: {
    id: 'bike',
    name: 'موتوسيكل توصيل سريع',
    icon: '🛵',
    cost: 16000,
    dailyUpkeep: 25,
    description: 'يرفع دخل التوصيل اليومي بنسبة 45% (مع مصاريف بنزين خفيفة)',
    category: 'vehicle'
  },
  car: {
    id: 'car',
    name: 'سيارة عائلية اقتصادية',
    icon: '🚗',
    cost: 140000,
    dailyUpkeep: 60,
    description: 'راحة في المشاوير، زيادة 15% في دخل الشغل، وسعادة أسرية',
    category: 'vehicle'
  },
  luxcar: {
    id: 'luxcar',
    name: 'سيارة فاخرة',
    icon: '🏎️',
    cost: 650000,
    dailyUpkeep: 220,
    description: 'هيبة ومكانة اجتماعية مرموقة، سمعة +2 ومزاج مرتفع دائماً',
    category: 'vehicle'
  },
  flat: {
    id: 'flat',
    name: 'شقة إيجار مستقلة',
    icon: '🏢',
    cost: 4500,
    dailyUpkeep: 95,
    description: 'تأمين 4500 ج.م وإيجار يومي 95 ج.م. استقلال عن بيت العائلة',
    category: 'housing'
  },
  home: {
    id: 'home',
    name: 'شقة تمليك 3 غرف',
    icon: '🏠',
    cost: 260000,
    description: 'راحة وأمان بدون إيجار يومي، شرط أساسي لزواج مستقر',
    category: 'housing'
  },
  villa: {
    id: 'villa',
    name: 'فيلا مستقلة بحديقة',
    icon: '🏰',
    cost: 1200000,
    dailyUpkeep: 150,
    description: 'قمة الرفاهية والراحة والاستقرار لعائلتك، نوم وصحة ممتازة',
    category: 'housing'
  },
  business: {
    id: 'business',
    name: 'محل تجاري صغير',
    icon: '🏪',
    cost: 75000,
    dailyRevenue: 280,
    dailyUpkeep: 90,
    description: 'مشروع تجاري يوفر صافي ربح يومي مستقر (~190 ج.م)',
    category: 'business'
  },
  workshop: {
    id: 'workshop',
    name: 'ورشة إنتاج وتصنيع',
    icon: '⚙️',
    cost: 190000,
    dailyRevenue: 680,
    dailyUpkeep: 220,
    description: 'استثمار متوسط يدر أرباحاً ممتازة يومياً (~460 ج.م)',
    category: 'business'
  }
};

export const DIFFICULTY_FACTORS: Record<DifficultyMode, {
  name: string;
  payMultiplier: number;
  costMultiplier: number;
  crimeRiskMultiplier: number;
  energyDrainMultiplier: number;
}> = {
  realistic: {
    name: 'واقعي ومتوازن (موصى به)',
    payMultiplier: 1.0,
    costMultiplier: 1.0,
    crimeRiskMultiplier: 1.0,
    energyDrainMultiplier: 1.0,
  },
  survival: {
    name: 'تحدي كفاح شديد (صعب جداً)',
    payMultiplier: 0.8,
    costMultiplier: 1.25,
    crimeRiskMultiplier: 1.35,
    energyDrainMultiplier: 1.2,
  },
  relaxed: {
    name: 'مريح وهادئ',
    payMultiplier: 1.3,
    costMultiplier: 0.85,
    crimeRiskMultiplier: 0.7,
    energyDrainMultiplier: 0.8,
  }
};

export const SCHOOL_STAGES: Record<SchoolStage, {
  label: string;
  minAge: number;
  icon: string;
  baseCost: number;
}> = {
  nursery: { label: 'حضانة وروضة أطفال', minAge: 2, icon: '🧸', baseCost: 35 },
  primary: { label: 'مدرسة ابتدائية', minAge: 6, icon: '🎒', baseCost: 55 },
  preparatory: { label: 'مدرسة إعدادية', minAge: 11, icon: '📐', baseCost: 75 },
  secondary: { label: 'مدرسة ثانوية', minAge: 14, icon: '🔬', baseCost: 95 },
  university: { label: 'جامعة وتخصص علمي', minAge: 18, icon: '🎓', baseCost: 140 },
  graduated: { label: 'تخرج ومهنة مستقلة', minAge: 22, icon: '💼', baseCost: 0 }
};

export const GANG_RANKS = [
  'خارج عالم الظلام',
  'صبي ومراقب حي',
  'منفذ موثوق',
  'مخطط عمليات (ذراع أيمن)',
  'زعيم شبكة الحي'
];

export const INITIAL_FRIENDS: Friend[] = [
  {
    id: 'ramy',
    name: 'رامي مهران',
    avatar: '👨🏻‍🦱',
    role: 'صديق الطفولة الوفي',
    closeness: 55,
    loyalty: 85,
    description: 'صديق عمرك، يساندك دائماً في الأوقات الصعبة ويقرضك مالاً عند الشدائد.',
    perk: 'سند مالي ومعنوي في الشدائد'
  },
  {
    id: 'hossam',
    name: 'حسام البدري',
    avatar: '🧔🏻‍♂️',
    role: 'رائد أعمال ومستثمر',
    closeness: 30,
    loyalty: 60,
    description: 'تاجر شاطر يمتلك علاقات واسعة، يشاركك فرص استثمار وأفكار مشاريع مربحة.',
    perk: 'فرص بيزنس واستشارات استثمار'
  },
  {
    id: 'dr_mahmoud',
    name: 'د. محمود توفيق',
    avatar: '👨🏻‍⚕️',
    role: 'طبيب عام وجار العائلة',
    closeness: 40,
    loyalty: 75,
    description: 'طبيب محترم يعتني بصحتك وصحة أسرتك ويقدم استشارات ورعاية طبية بخصم خاص.',
    perk: 'رعاية صحية وتخفيض تكاليف العلاج'
  },
  {
    id: 'captain_tarek',
    name: 'كابتن طارق',
    avatar: '🏋️‍♂️',
    role: 'مدرب لياقة بدنية',
    closeness: 35,
    loyalty: 70,
    description: 'بطل كمال أجسام ومدربك في الجيم، يحفزك ويعطيك برامج تمرين تضاعف اكتساب طاقتك.',
    perk: 'تسريع مضاعفة طاقة ولياقة الجيم'
  }
];
