/** Core design constants. All visual sizes are expressed in "design units"
 *  for a 720x1280 reference screen and multiplied by the layout unit `u`. */

export const GRID = 8;
export const DESIGN_W = 720;
export const DESIGN_H = 1280;

/** Cell pitch (block + gap) in design units. */
export const CELL = 80;
/** Gap between neighbouring blocks. */
export const CELL_GAP = 6;
/** Inner padding of the board panel. */
export const BOARD_PAD = 16;
/** Scale of pieces resting in the tray. */
export const TRAY_SCALE = 0.56;
/** Size of a block texture frame in pixels (source resolution). */
export const BLOCK_TEX = 144;

/** Texture atlas key (everything is drawn procedurally into one canvas). */
export const TEX = 'ui';

export const COLOR = {
  RED: 0,
  ORANGE: 1,
  YELLOW: 2,
  GREEN: 3,
  TEAL: 4,
  BLUE: 5,
  PURPLE: 6,
  PINK: 7,
} as const;

/** Block base colours (Block Blast-like candy palette). */
export const PALETTE: number[] = [
  0xf0505c, // red
  0xf98a3c, // orange
  0xf7c948, // yellow
  0x5fcf63, // green
  0x3fcbc6, // teal
  0x4c8ff5, // blue
  0x9c6cf3, // purple
  0xef6bc6, // pink
];

export const GRAY_BLOCK = 0x5b6479;

export const THEME = {
  bgTop: '#2a3a70',
  bgBottom: '#141b38',
  board: 0x1a2447,
  cell: 0x2f3e6e,
  cellDark: 0x28355d,
  text: '#ffffff',
  gold: '#ffd14d',
  goldHex: 0xffd14d,
  muted: '#9aa6cf',
  green: ['#6ee26f', '#3fb84a'],
  greenEdge: '#2b8a35',
  blue: ['#6aa8ff', '#3b7ae6'],
  blueEdge: '#2a56b0',
  orange: ['#ffb65c', '#f08a2c'],
  orangeEdge: '#b9601a',
  red: ['#ff7b7b', '#e8505b'],
  redEdge: '#b03440',
  dark: ['#3b4a7c', '#2d3a66'],
  darkEdge: '#1e2848',
  panel: '#202c55',
  panelBorder: '#3b4b85',
};

export const DEPTH = {
  BG: 0,
  BOARD: 1,
  CELLS: 2,
  BLOCKS: 4,
  GHOST: 5,
  FLASH: 6,
  PARTICLES: 7,
  TRAY: 8,
  DRAG: 9,
  POPUP: 10,
  HUD: 12,
  OVERLAY: 50,
};

export const STORAGE_KEYS = {
  best: 'blockblast.best',
  settings: 'blockblast.settings',
  save: 'blockblast.save',
  autoTier: 'blockblast.autoTier',
  stats: 'blockblast.stats',
};
