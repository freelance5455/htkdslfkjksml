import type { CarKind, MissionDef, ModeId, WeaponId } from "@/game/types";

export const TIPS = [
  "Jack a ride with F. Park it like you paid for it.",
  "Stars cool off when you break line of sight and lay low.",
  "Bahia Bay's ring road is the long way home. Use it.",
  "Civilians remember gunfire. Cops remember faces.",
  "The vault pays a daily street cut. Collect it.",
  "Z cycles the radio. Every stolen car has taste.",
  "Heists want a clean exit, not a louder gun.",
  "Armor eats the first mistake. Buy it before you need it.",
  "Crouch with C. Grenades are G. Don't waste either.",
  "Properties save your skin. Hospitals charge more than pride.",
];

export const MODES: { id: ModeId; kicker: string; title: string; map: string; blurb: string }[] = [
  { id: "freeroam", kicker: "CLASSIC", title: "Free Roam", map: "Bahia Bay", blurb: "Open city. Your heat, your clock." },
  { id: "story", kicker: "STORY", title: "First Blood", map: "County of Rico", blurb: "Dante Reyes against Vega and Voss." },
  { id: "heist", kicker: "HEIST", title: "Pacific Reserve", map: "Downtown", blurb: "Crack the bank. Leave richer or in cuffs." },
  { id: "race", kicker: "RACE", title: "Ring Run", map: "Ring Road", blurb: "Two laps. Traffic is not a suggestion." },
  { id: "heat", kicker: "HEAT", title: "Five-Star", map: "Citywide", blurb: "Start loud. End invisible." },
  { id: "turf", kicker: "TURF", title: "Foundry War", map: "East Industrial", blurb: "Calderón crew holds the sheds. Take them." },
];

export type Outfit = {
  id: string;
  name: string;
  price: number;
  skin: string;
  hair: string;
  top: string;
  bottom: string;
  shoes: string;
  sleeves: boolean;
  shades: boolean;
};

export const OUTFITS: Outfit[] = [
  { id: "darkfire", name: "Street King", price: 0, skin: "#6b4632", hair: "#ececec", top: "#141414", bottom: "#1c1c1c", shoes: "#f4f4f4", sleeves: false, shades: true },
  { id: "linen", name: "Vice Linen", price: 1800, skin: "#6b4632", hair: "#1a1a1a", top: "#f3efe4", bottom: "#e4d2a8", shoes: "#c4553a", sleeves: true, shades: true },
  { id: "calderon", name: "Calderón Red", price: 2400, skin: "#8a5a3c", hair: "#2a1a14", top: "#8f1d2c", bottom: "#1a1a1a", shoes: "#111", sleeves: true, shades: false },
  { id: "night", name: "Black Tie", price: 4200, skin: "#6b4632", hair: "#111", top: "#0e0e10", bottom: "#0e0e10", shoes: "#111", sleeves: true, shades: true },
  { id: "medic", name: "Undercover Scrub", price: 900, skin: "#c48a62", hair: "#4a3428", top: "#f4f7fb", bottom: "#d9e2ea", shoes: "#f4f4f4", sleeves: true, shades: false },
  { id: "hills", name: "Hill Leather", price: 3100, skin: "#5c3828", hair: "#c4a574", top: "#3a2a22", bottom: "#2a3142", shoes: "#1a1a1a", sleeves: true, shades: true },
];

export type WeaponDef = {
  id: WeaponId;
  name: string;
  price: number;
  dmg: number;
  rate: number;
  mag: number;
  spread: number;
  range: number;
  auto: boolean;
  pellets?: number;
};

export const WEAPONS: WeaponDef[] = [
  { id: "fists", name: "Fists", price: 0, dmg: 22, rate: 0.42, mag: 0, spread: 0, range: 2.4, auto: false },
  { id: "pistol", name: "Service Pistol", price: 0, dmg: 18, rate: 0.28, mag: 12, spread: 0.025, range: 70, auto: false },
  { id: "jade", name: "Jade SMG", price: 4500, dmg: 11, rate: 0.08, mag: 30, spread: 0.055, range: 52, auto: true },
  { id: "shotgun", name: "Breacher", price: 6200, dmg: 12, rate: 0.72, mag: 6, spread: 0.12, range: 26, auto: false, pellets: 6 },
  { id: "rifle", name: "Carbine", price: 12000, dmg: 26, rate: 0.11, mag: 30, spread: 0.012, range: 120, auto: true },
  { id: "sniper", name: "Longshot", price: 18000, dmg: 90, rate: 1.05, mag: 5, spread: 0.002, range: 190, auto: false },
];

export type CarDef = {
  id: string;
  name: string;
  kind: CarKind;
  price: number;
  color: string;
};

export const CARS: CarDef[] = [
  { id: "veto", name: "Veto GT", kind: "sport", price: 0, color: "#161616" },
  { id: "issi", name: "Issi", kind: "sedan", price: 0, color: "#d9d3c7" },
  { id: "taxi", name: "City Taxi", kind: "taxi", price: 2000, color: "#f5c400" },
  { id: "sultan", name: "Sultan", kind: "sport", price: 9000, color: "#c23b3b" },
  { id: "sand", name: "Sandking", kind: "suv", price: 14000, color: "#2f4a34" },
  { id: "bike", name: "Nightbike", kind: "bike", price: 3200, color: "#1c1c1c" },
  { id: "van", name: "Rumpo", kind: "van", price: 4800, color: "#3d4c6b" },
  { id: "truck", name: "Hauler", kind: "truck", price: 11000, color: "#8a5a32" },
];

export const CAR_SPEC: Record<CarKind, { len: number; wid: number; hei: number; wheelR: number; max: number; accel: number; turn: number; wheels: 2 | 4 }> = {
  sedan: { len: 4.5, wid: 1.85, hei: 1.45, wheelR: 0.36, max: 32, accel: 16, turn: 1.85, wheels: 4 },
  sport: { len: 4.35, wid: 1.9, hei: 1.15, wheelR: 0.36, max: 42, accel: 22, turn: 2.15, wheels: 4 },
  suv: { len: 4.9, wid: 2.05, hei: 1.85, wheelR: 0.42, max: 30, accel: 13, turn: 1.55, wheels: 4 },
  taxi: { len: 4.5, wid: 1.85, hei: 1.5, wheelR: 0.36, max: 30, accel: 15, turn: 1.8, wheels: 4 },
  cop: { len: 4.6, wid: 1.9, hei: 1.5, wheelR: 0.36, max: 38, accel: 20, turn: 2.0, wheels: 4 },
  van: { len: 5.3, wid: 2.05, hei: 2.2, wheelR: 0.4, max: 26, accel: 11, turn: 1.45, wheels: 4 },
  truck: { len: 6.6, wid: 2.3, hei: 2.5, wheelR: 0.48, max: 24, accel: 9, turn: 1.25, wheels: 4 },
  bike: { len: 2.15, wid: 0.55, hei: 1.15, wheelR: 0.34, max: 40, accel: 24, turn: 2.55, wheels: 2 },
};

export type PropDef = { id: string; name: string; at: string; price: number; blurb: string };

export const PROPS: PropDef[] = [
  { id: "garage", name: "Hill Garage", at: "garage", price: 12000, blurb: "Respawn, heal, and respray." },
  { id: "condo", name: "Bay Condo", at: "condo", price: 28000, blurb: "Beach savehouse. Clean towels, dirty money." },
  { id: "shed", name: "Dock Shed", at: "warehouse", price: 18000, blurb: "Industrial stash. Cops hate the driveway." },
];

export const PASS = [
  { xp: 0, label: "Street boots", cash: 500, gems: 0 },
  { xp: 80, label: "Pocket gems", cash: 0, gems: 20 },
  { xp: 180, label: "Side hustle", cash: 2500, gems: 0 },
  { xp: 320, label: "Jade cache", cash: 0, gems: 40 },
  { xp: 480, label: "Armor fund", cash: 5000, gems: 10 },
  { xp: 700, label: "Condo keys vibe", cash: 8000, gems: 0 },
  { xp: 980, label: "City legend", cash: 4000, gems: 60 },
  { xp: 1300, label: "Darkfire plaque", cash: 15000, gems: 40 },
];

export const RING = [
  { x: 0, z: -300 },
  { x: 300, z: -300 },
  { x: 300, z: 0 },
  { x: 300, z: 300 },
  { x: 0, z: 300 },
  { x: -300, z: 300 },
  { x: -300, z: 0 },
  { x: -300, z: -300 },
];

export const MALL_LOOP = [
  { x: 0, z: -130 },
  { x: 130, z: -130 },
  { x: 130, z: 130 },
  { x: 0, z: 130 },
  { x: -130, z: 130 },
  { x: -130, z: 0 },
];

export const MISSIONS: MissionDef[] = [
  { id: "m1", name: "First Night", chapter: "Story", difficulty: 1, reward: 2500, xp: 80, blurb: "Vega's man is on the pier with a photo of Captain Voss.", steps: [{ kind: "goto", at: "pier", r: 14, text: "Drive to the pier. Don't wreck the introduction." }] },
  { id: "m2", name: "Picture of Voss", chapter: "Story", difficulty: 1, reward: 1800, xp: 70, unlockAfter: "m1", blurb: "Case the precinct without earning a star.", steps: [{ kind: "goto", at: "police", r: 12, text: "Roll past Central Precinct." }, { kind: "hold", at: "police", r: 14, time: 4, text: "Hold still. Get the photo." }] },
  { id: "m3", name: "Corner Tax", chapter: "Story", difficulty: 2, reward: 4000, xp: 90, unlockAfter: "m2", blurb: "Nino's owes the crew. Collect, then breathe.", steps: [{ kind: "goto", at: "pizza", r: 12, text: "Get to Nino Pizza." }, { kind: "hold", at: "pizza", r: 14, time: 5, text: "Empty the register." }, { kind: "survive", stars: 2, time: 25, text: "Lose two stars." }] },
  { id: "m4", name: "North Garage", chapter: "Story", difficulty: 1, reward: 1500, xp: 60, unlockAfter: "m3", blurb: "The hill garage is for sale. Look at it like you belong.", steps: [{ kind: "goto", at: "garage", r: 12, text: "Drive up to Hill Garage." }] },
  { id: "m5", name: "Pizza Run", chapter: "Side", difficulty: 1, reward: 2200, xp: 50, blurb: "Three drops. The cheese is a lie. The cash isn't.", steps: [{ kind: "goto", at: "pizza", r: 12, text: "Pick up at Nino's." }, { kind: "goto", at: "mall", r: 12, text: "Drop at Bahia Mall." }, { kind: "goto", at: "condo", r: 12, text: "Last box: Bay Condo." }] },
  { id: "m6", name: "Taxi Shift", chapter: "Side", difficulty: 1, reward: 2000, xp: 50, blurb: "Fare from the hospital to the beach. Meter's broken. You're not.", steps: [{ kind: "goto", at: "hospital", r: 12, text: "Pick up the fare at County General." }, { kind: "goto", at: "beach", r: 14, text: "Drop them on Bahia Beach." }] },
  { id: "m7", name: "The Jade Deal", chapter: "Story", difficulty: 2, reward: 6000, xp: 100, unlockAfter: "m4", rewardWeapon: "jade", blurb: "A green SMG with your name on the receiver.", steps: [{ kind: "goto", at: "warehouse", r: 12, text: "Collect the case at Dock Shed." }, { kind: "goto", at: "pier", r: 14, text: "Hand it off on the pier." }] },
  { id: "m8", name: "Captain's Cut", chapter: "Story", difficulty: 3, reward: 5000, xp: 110, unlockAfter: "m7", blurb: "Voss wants a conversation. You want distance.", steps: [{ kind: "goto", at: "police", r: 12, text: "Brush the precinct so they see you." }, { kind: "survive", stars: 3, time: 30, text: "Shake a three-star tail." }] },
  { id: "m9", name: "Mall Rush", chapter: "Race", difficulty: 2, reward: 3000, xp: 70, blurb: "Downtown loop. Short, mean, public.", steps: [{ kind: "race", points: MALL_LOOP, laps: 2, text: "Mall loop — two laps." }] },
  { id: "m10", name: "Ring Run", chapter: "Race", difficulty: 3, reward: 7000, xp: 120, blurb: "The full ring. Twice. Sand on the south edge is a trap.", steps: [{ kind: "race", points: RING, laps: 2, text: "Ring road — two laps." }] },
  { id: "m11", name: "Foundry Turf", chapter: "Turf", difficulty: 3, reward: 5500, xp: 100, blurb: "Calderón's night shift doesn't punch out.", steps: [{ kind: "goto", at: "foundry", r: 16, text: "Enter the foundry." }, { kind: "eliminate", count: 5, text: "Drop five of the crew." }] },
  { id: "m12", name: "Clinic Run", chapter: "Side", difficulty: 2, reward: 2800, xp: 60, blurb: "Somebody's bleeding in the hills. The hospital doesn't do house calls.", steps: [{ kind: "goto", at: "hills", r: 14, text: "Reach West Hills." }, { kind: "goto", at: "hospital", r: 12, text: "Get them to County General. Fast." }] },
  { id: "m13", name: "Bank Scout", chapter: "Heist", difficulty: 1, reward: 1500, xp: 40, unlockAfter: "m3", blurb: "Walk the block. Learn the exits before the masks.", steps: [{ kind: "goto", at: "bank", r: 12, text: "Scout Pacific Reserve." }, { kind: "goto", at: "downtown", r: 14, text: "Check the downtown escape." }] },
  { id: "m14", name: "Pacific Reserve", chapter: "Heist", difficulty: 4, reward: 25000, xp: 180, unlockAfter: "m13", blurb: "Multi-stage: door, vault, disappear.", steps: [{ kind: "goto", at: "bank", r: 12, text: "Hit Pacific Reserve." }, { kind: "hold", at: "bank", r: 14, time: 8, text: "Drill the vault. Don't flinch." }, { kind: "goto", at: "garage", r: 14, text: "Stash the take at Hill Garage." }] },
  { id: "m15", name: "Betrayal at the Pier", chapter: "Story", difficulty: 3, reward: 8000, xp: 130, unlockAfter: "m8", blurb: "Vega paid the cops to be early.", steps: [{ kind: "goto", at: "pier", r: 14, text: "Show up anyway." }, { kind: "survive", stars: 3, time: 28, text: "Survive the setup." }] },
  { id: "m16", name: "Condo Keys", chapter: "Side", difficulty: 1, reward: 2000, xp: 40, blurb: "Look at the condo like a civilian. Then decide.", steps: [{ kind: "goto", at: "condo", r: 12, text: "Visit Bay Condo." }] },
  { id: "m17", name: "Undercover", chapter: "Side", difficulty: 3, reward: 4500, xp: 80, blurb: "A cop car gets you through the east gate. Briefly.", steps: [{ kind: "goto", at: "police", r: 12, text: "Find a black-and-white." }, { kind: "goto", at: "east", r: 14, text: "Cross into East Industrial." }] },
  { id: "m18", name: "Sniper Alley", chapter: "Side", difficulty: 3, reward: 9000, xp: 90, rewardWeapon: "sniper", blurb: "The long gun is in a case at the airfield.", steps: [{ kind: "goto", at: "airport", r: 14, text: "Reach Bay Airfield." }, { kind: "hold", at: "airport", r: 16, time: 4, text: "Pop the case." }] },
  { id: "m19", name: "Beach Brawl", chapter: "Turf", difficulty: 2, reward: 3500, xp: 70, blurb: "They brought the fight to the sand. Rude.", steps: [{ kind: "goto", at: "beach", r: 16, text: "Get to the beach." }, { kind: "eliminate", count: 4, text: "Finish the beach crew." }] },
  { id: "m20", name: "Five-Star Funeral", chapter: "Heat", difficulty: 5, reward: 12000, xp: 160, blurb: "Make the whole county look for you. Then vanish.", steps: [{ kind: "survive", stars: 4, time: 40, text: "Outlast a four-star search." }] },
  { id: "m21", name: "Casino Night", chapter: "Side", difficulty: 1, reward: 2600, xp: 50, blurb: "Marisol Vega's room is above the Golden Cage. Smile at the cameras.", steps: [{ kind: "goto", at: "casino", r: 12, text: "Enter the Golden Cage block." }, { kind: "hold", at: "casino", r: 14, time: 6, text: "Work the room." }] },
  { id: "m22", name: "Haul", chapter: "Side", difficulty: 2, reward: 4200, xp: 70, blurb: "A truck, a gas stop, a shed. Boring until it isn't.", steps: [{ kind: "goto", at: "gas", r: 12, text: "Fuel at Rico Fuel." }, { kind: "goto", at: "warehouse", r: 12, text: "Deliver to Dock Shed." }] },
  { id: "m23", name: "Hills Ambush", chapter: "Story", difficulty: 3, reward: 7000, xp: 120, unlockAfter: "m15", blurb: "The scenic route has a Calderón checkpoint.", steps: [{ kind: "goto", at: "hills", r: 14, text: "Take the west hills road." }, { kind: "eliminate", count: 4, text: "Clear the checkpoint." }] },
  { id: "m24", name: "Vega's Ledger", chapter: "Heist", difficulty: 2, reward: 6500, xp: 90, unlockAfter: "m14", blurb: "Three drops of her private bookkeeping.", steps: [{ kind: "goto", at: "casino", r: 12, text: "Ledger page at the casino." }, { kind: "goto", at: "mall", r: 12, text: "Second page, Bahia Mall." }, { kind: "goto", at: "condo", r: 12, text: "Last page is in the condo district." }] },
  { id: "m25", name: "Dock Shed", chapter: "Side", difficulty: 1, reward: 1800, xp: 40, blurb: "See the shed. Imagine it with your name on the bay door.", steps: [{ kind: "goto", at: "warehouse", r: 12, text: "Scope Dock Shed." }] },
  { id: "m26", name: "Final Approach", chapter: "Story", difficulty: 2, reward: 5000, xp: 80, unlockAfter: "m23", blurb: "The plane is a rumor. The runway is real.", steps: [{ kind: "goto", at: "airport", r: 14, text: "Reach the airfield." }, { kind: "hold", at: "airport", r: 16, time: 5, text: "Wait for the flare." }] },
  { id: "m27", name: "Showdown", chapter: "Story", difficulty: 5, reward: 20000, xp: 200, unlockAfter: "m26", blurb: "Vega, the crew, and whatever Voss sends after.", steps: [{ kind: "goto", at: "foundry", r: 16, text: "She'll be at the foundry." }, { kind: "eliminate", count: 6, text: "End the crew." }, { kind: "survive", stars: 4, time: 25, text: "Leave before the funeral is yours." }] },
  { id: "m28", name: "Street Photos", chapter: "Side", difficulty: 1, reward: 2400, xp: 60, blurb: "Four districts. One camera. Zero heroics.", steps: [{ kind: "goto", at: "downtown", r: 14, text: "Downtown." }, { kind: "goto", at: "beach", r: 14, text: "Beach." }, { kind: "goto", at: "hills", r: 14, text: "Hills." }, { kind: "goto", at: "north", r: 14, text: "North residences." }] },
  { id: "m29", name: "Park Bench", chapter: "Side", difficulty: 1, reward: 800, xp: 30, blurb: "Sometimes the job is sitting still in Marigold Park.", steps: [{ kind: "goto", at: "park", r: 12, text: "Find the park." }, { kind: "hold", at: "park", r: 14, time: 5, text: "Sit with it." }] },
  { id: "m30", name: "Credits", chapter: "Story", difficulty: 1, reward: 3000, xp: 40, unlockAfter: "m27", blurb: "Drive the ring once, slow, like the city is yours.", steps: [{ kind: "race", points: RING, laps: 1, text: "Victory lap. One clean ring." }] },
];

export const CREW = [
  { name: "Rio Santos", role: "Wheelman", line: "I don't do sirens. I do gaps." },
  { name: "Nia Cole", role: "Gun", line: "You point. I disagree with people." },
  { name: "Father Jun", role: "Fixer", line: "The precinct has a price. Everyone does." },
];

export const RADIO = [
  { id: "neon", name: "NEON FM", genre: "Electronic" },
  { id: "west", name: "WEST COAST", genre: "Hip-hop" },
  { id: "ridge", name: "ROCK RIDGE", genre: "Rock" },
  { id: "candy", name: "POP CANDY", genre: "Pop" },
  { id: "talk", name: "BAY TALK", genre: "Talk" },
];

export const DISPATCH = [
  "Dispatch: shots reported, Bahia downtown.",
  "All units, black sport, silver-haired driver. Approach hot.",
  "Air unit is up. Do not lose him in the hills.",
  "Precinct wants this one breathing. Mostly.",
  "Spike the ring road. He's a creature of habit.",
];
