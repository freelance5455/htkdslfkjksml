import type { CookId, Ing } from "./types";

export type Recipe = {
  id: string;
  name: string;
  ings: Ing[];
  price: number;
  minDay: number;
};

export const RECIPES: Recipe[] = [
  { id: "classic", name: "Classic wrap", ings: ["bread", "meat", "veg"], price: 15, minDay: 1 },
  { id: "saucy", name: "Saucy wrap", ings: ["bread", "meat", "sauce"], price: 16, minDay: 1 },
  { id: "cheesy", name: "Cheesy wrap", ings: ["bread", "meat", "cheese"], price: 22, minDay: 2 },
  { id: "garden", name: "Garden wrap", ings: ["bread", "veg", "cheese", "sauce"], price: 20, minDay: 2 },
  { id: "loaded", name: "Loaded wrap", ings: ["bread", "meat", "meat", "veg", "sauce"], price: 35, minDay: 3 },
  { id: "deluxe", name: "Deluxe feast", ings: ["bread", "meat", "cheese", "veg", "sauce", "meat"], price: 50, minDay: 4 },
];

export const ING_LABEL: Record<Ing, string> = {
  bread: "Bread",
  meat: "Meat",
  veg: "Veg",
  cheese: "Cheese",
  sauce: "Sauce",
};

export const COOK: Record<CookId, { ing: Ing; dur: number; label: string; take: string; start: string }> = {
  grill: { ing: "meat", dur: 2.05, label: "Grill", take: "Take meat", start: "Grill meat" },
  chop: { ing: "veg", dur: 1.15, label: "Chop", take: "Take veg", start: "Chop veg" },
  oven: { ing: "cheese", dur: 1.65, label: "Oven", take: "Take cheese", start: "Bake cheese" },
};

export const CUSTOMERS: { name: string; shirt: number; hair: number }[] = [
  { name: "Noor", shirt: 0x3d7ea6, hair: 0x2a2118 },
  { name: "Leo", shirt: 0xc46b4a, hair: 0x4a3428 },
  { name: "Mina", shirt: 0x3f8f6b, hair: 0x1c1a17 },
  { name: "Sam", shirt: 0x7a4e74, hair: 0x6b4a2a },
  { name: "Joy", shirt: 0x2f8f8a, hair: 0x3a2418 },
  { name: "Theo", shirt: 0xc4922a, hair: 0x241810 },
  { name: "Amina", shirt: 0xb5523a, hair: 0x1a120c },
  { name: "Rio", shirt: 0x3d6ea8, hair: 0x503828 },
];

export const ING_HEX: Record<Ing, number> = {
  bread: 0xe6c48a,
  meat: 0x8a4030,
  veg: 0x3f8f5a,
  cheese: 0xf0c14a,
  sauce: 0xd64545,
};

export function recipesForDay(day: number): Recipe[] {
  const list = RECIPES.filter((r) => r.minDay <= day);
  return list.length > 0 ? list : [RECIPES[0] as Recipe];
}

export function dayGoal(day: number): number {
  return 30 + (day - 1) * 28;
}

export function daySeconds(day: number): number {
  return Math.min(120, 90 + (day - 1) * 5);
}

export function patienceSeconds(day: number): number {
  return Math.max(14, 26 - (day - 1) * 1.4);
}
