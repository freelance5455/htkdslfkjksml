/** Карта, сценарии и тексты «Точек фронта». Абстрактная партия, не хроника. */

export type Lang = "ru" | "en";
export type Kind = "light" | "heavy";
export type FactionId = 0 | 1 | 2 | 3;
export type OwnerId = -1 | FactionId;
export type Diff = 0 | 1 | 2;
export type WinMode = "eliminate" | "capture" | "hold";

export const WORLD_W = 3200;
export const WORLD_H = 2000;

export const BALANCE = {
  light: { hp: 46, dps: 12.5, speed: 98, range: 18, r: 5.1 },
  heavy: { hp: 170, dps: 22.5, speed: 50, range: 22, r: 8.5 },
  cost: { light: 1, heavy: 3 } as Record<Kind, number>,
  use: { light: 1, heavy: 2 } as Record<Kind, number>,
  incomeBase: 0.085,
  incomePerLevel: 0.042,
  starveCut: 9.2,
  starveHungry: 3.0,
  captureRadius: 54,
  defendRadius: 66,
  stillDelay: 1.15,
  stillTaken: 0.72,
  cityVision: 300,
  unitVision: 168,
};

export interface CityDef {
  id: string;
  name: Record<Lang, string>;
  x: number;
  y: number;
  level: number;
  supply: number;
}

export const CITIES: CityDef[] = [
  { id: "kyiv", name: { ru: "Киев", en: "Kyiv" }, x: 460, y: 620, level: 3, supply: 8 },
  { id: "mykolaiv", name: { ru: "Николаев", en: "Mykolaiv" }, x: 340, y: 1320, level: 1, supply: 5 },
  { id: "kherson", name: { ru: "Херсон", en: "Kherson" }, x: 760, y: 1560, level: 2, supply: 6 },
  { id: "dnipro", name: { ru: "Днепр", en: "Dnipro" }, x: 1120, y: 980, level: 2, supply: 7 },
  { id: "zaporizhzhia", name: { ru: "Запорожье", en: "Zaporizhzhia" }, x: 1160, y: 1300, level: 2, supply: 6 },
  { id: "kharkiv", name: { ru: "Харьков", en: "Kharkiv" }, x: 1580, y: 300, level: 2, supply: 7 },
  { id: "kramatorsk", name: { ru: "Краматорск", en: "Kramatorsk" }, x: 1960, y: 460, level: 1, supply: 5 },
  { id: "bakhmut", name: { ru: "Бахмут", en: "Bakhmut" }, x: 2140, y: 680, level: 1, supply: 5 },
  { id: "pokrovsk", name: { ru: "Покровск", en: "Pokrovsk" }, x: 1780, y: 860, level: 1, supply: 5 },
  { id: "donetsk", name: { ru: "Донецк", en: "Donetsk" }, x: 2360, y: 960, level: 3, supply: 8 },
  { id: "luhansk", name: { ru: "Луганск", en: "Luhansk" }, x: 2700, y: 520, level: 2, supply: 7 },
  { id: "volnovakha", name: { ru: "Волноваха", en: "Volnovakha" }, x: 2140, y: 1160, level: 1, supply: 5 },
  { id: "mariupol", name: { ru: "Мариуполь", en: "Mariupol" }, x: 2320, y: 1460, level: 2, supply: 6 },
  { id: "berdiansk", name: { ru: "Бердянск", en: "Berdiansk" }, x: 1960, y: 1580, level: 1, supply: 5 },
  { id: "melitopol", name: { ru: "Мелитополь", en: "Melitopol" }, x: 1560, y: 1560, level: 1, supply: 5 },
];

export const CITY_BY_ID: Record<string, CityDef> = Object.fromEntries(CITIES.map((c) => [c.id, c]));

export const RIVER: [number, number][] = [
  [700, 0],
  [780, 200],
  [860, 420],
  [980, 680],
  [1100, 900],
  [1120, 1000],
  [1340, 1140],
  [1160, 1300],
  [980, 1460],
  [800, 1580],
  [640, 1760],
  [500, 2000],
];

export const ROADS: [string, string][] = [
  ["kyiv", "dnipro"],
  ["kyiv", "mykolaiv"],
  ["mykolaiv", "kherson"],
  ["kherson", "melitopol"],
  ["kherson", "zaporizhzhia"],
  ["dnipro", "zaporizhzhia"],
  ["dnipro", "kharkiv"],
  ["dnipro", "pokrovsk"],
  ["zaporizhzhia", "melitopol"],
  ["zaporizhzhia", "pokrovsk"],
  ["kharkiv", "kramatorsk"],
  ["kramatorsk", "bakhmut"],
  ["kramatorsk", "luhansk"],
  ["bakhmut", "pokrovsk"],
  ["bakhmut", "donetsk"],
  ["pokrovsk", "donetsk"],
  ["pokrovsk", "volnovakha"],
  ["donetsk", "luhansk"],
  ["donetsk", "volnovakha"],
  ["volnovakha", "mariupol"],
  ["mariupol", "berdiansk"],
  ["melitopol", "berdiansk"],
  ["donetsk", "mariupol"],
];

export const FORESTS = [
  { x: 1720, y: 230, rx: 400, ry: 170 },
  { x: 2080, y: 640, rx: 250, ry: 155 },
  { x: 620, y: 900, rx: 260, ry: 190 },
  { x: 1460, y: 690, rx: 150, ry: 110 },
];

export const HILLS = [
  { x: 2240, y: 900, rx: 340, ry: 210 },
  { x: 1420, y: 1140, rx: 160, ry: 110 },
];

export const SEAS: [number, number][][] = [
  [
    [0, 2000],
    [0, 1780],
    [260, 1720],
    [520, 1800],
    [860, 1920],
    [980, 2000],
  ],
  [
    [1480, 2000],
    [1480, 1900],
    [1860, 1860],
    [2200, 1780],
    [2620, 1720],
    [3200, 1700],
    [3200, 2000],
  ],
];

export const FACTIONS: {
  id: FactionId;
  color: string;
  soft: string;
  ink: string;
  name: Record<Lang, string>;
  sub: Record<Lang, string>;
}[] = [
  {
    id: 0,
    color: "#e23d3d",
    soft: "rgba(226,61,61,0.5)",
    ink: "#2a0c0c",
    name: { ru: "Красные", en: "Red" },
    sub: { ru: "Восток", en: "East" },
  },
  {
    id: 1,
    color: "#3c7fe6",
    soft: "rgba(60,127,230,0.5)",
    ink: "#071426",
    name: { ru: "Синие", en: "Blue" },
    sub: { ru: "Запад", en: "West" },
  },
  {
    id: 2,
    color: "#2fbf6a",
    soft: "rgba(47,191,106,0.48)",
    ink: "#062414",
    name: { ru: "Зелёные", en: "Green" },
    sub: { ru: "Север", en: "North" },
  },
  {
    id: 3,
    color: "#e0a23a",
    soft: "rgba(224,162,58,0.5)",
    ink: "#241a08",
    name: { ru: "Янтарные", en: "Amber" },
    sub: { ru: "Юг", en: "South" },
  },
];

export interface Spawn {
  city: string;
  owner: FactionId;
  kind: Kind;
  n: number;
}

export interface Scenario {
  id: string;
  title: Record<Lang, string>;
  brief: Record<Lang, string>;
  objective: Record<Lang, string>;
  win: WinMode;
  capture: string[];
  holdSec: number;
  loseIfCityFalls: string[];
  player: FactionId;
  factions: FactionId[];
  fog: boolean;
  points: [number, number, number, number];
  owners: Record<string, OwnerId>;
  spawns: Spawn[];
  ai: Diff;
  tutorial: boolean;
  campaign: boolean;
  world: boolean;
}

export interface Achievement {
  id: string;
  name: Record<Lang, string>;
  desc: Record<Lang, string>;
}

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: "first_blood",
    name: { ru: "Первая искра", en: "First spark" },
    desc: { ru: "Уничтожить вражескую точку.", en: "Destroy an enemy dot." },
  },
  {
    id: "city_taken",
    name: { ru: "Первый узел", en: "First node" },
    desc: { ru: "Захватить город.", en: "Capture a city." },
  },
  {
    id: "ten_cities",
    name: { ru: "Десять узлов", en: "Ten nodes" },
    desc: { ru: "Захватить 10 городов за всё время.", en: "Capture 10 cities in total." },
  },
  {
    id: "no_loss",
    name: { ru: "Чистая линия", en: "Clean line" },
    desc: { ru: "Победить, не потеряв ни одного своего города.", en: "Win without losing a city." },
  },
  {
    id: "encircle",
    name: { ru: "Котёл", en: "Pocket" },
    desc: { ru: "Дождаться, пока окружённая точка противника погаснет.", en: "An encircled enemy dot starves out." },
  },
  {
    id: "campaign",
    name: { ru: "Семь рубежей", en: "Seven lines" },
    desc: { ru: "Пройти всю кампанию.", en: "Finish the campaign." },
  },
  {
    id: "capital",
    name: { ru: "До столицы", en: "To the capital" },
    desc: { ru: "Продвинуть линию фронта до конца.", en: "Push the world front all the way." },
  },
  {
    id: "swarm",
    name: { ru: "Рой", en: "Swarm" },
    desc: { ru: "Иметь 36 лёгких точек одновременно.", en: "Field 36 lights at once." },
  },
  {
    id: "heavies",
    name: { ru: "Кулак", en: "Fist" },
    desc: { ru: "Иметь 8 тяжёлых точек одновременно.", en: "Field 8 heavies at once." },
  },
  {
    id: "veteran",
    name: { ru: "Ветеран карты", en: "Map veteran" },
    desc: { ru: "Сыграть 10 боёв.", en: "Fight 10 battles." },
  },
];

const T = (ru: string, en: string): Record<Lang, string> => ({ ru, en });

export function autoSpawns(owners: Record<string, OwnerId>): Spawn[] {
  const spawns: Spawn[] = [];
  const best = new Map<number, CityDef>();
  for (const [id, owner] of Object.entries(owners)) {
    if (owner < 0) continue;
    const side = owner as FactionId;
    const city = CITY_BY_ID[id];
    if (!city) continue;
    spawns.push({ city: id, owner: side, kind: "light", n: 2 });
    const prev = best.get(side);
    if (!prev || city.level > prev.level) best.set(side, city);
  }
  for (const [owner, city] of best) {
    spawns.push({ city: city.id, owner: owner as FactionId, kind: "heavy", n: 1 });
    spawns.push({ city: city.id, owner: owner as FactionId, kind: "light", n: 1 });
  }
  return spawns;
}

function scenario(partial: Omit<Scenario, "capture" | "holdSec" | "loseIfCityFalls" | "tutorial" | "campaign" | "world" | "points"> & {
  capture?: string[];
  holdSec?: number;
  loseIfCityFalls?: string[];
  tutorial?: boolean;
  campaign?: boolean;
  world?: boolean;
  points?: [number, number, number, number];
}): Scenario {
  return {
    capture: [],
    holdSec: 0,
    loseIfCityFalls: [],
    tutorial: false,
    campaign: false,
    world: false,
    points: [5, 5, 5, 5],
    ...partial,
  };
}

export const CAMPAIGN: Scenario[] = [
  scenario({
    id: "c1",
    campaign: true,
    tutorial: true,
    title: T("Удержать Донецк", "Hold Donetsk"),
    brief: T(
      "Первый рубеж. Синие идут с запада. Город кормит армию: не отдавайте Донецк и бейте их, пока подходят подкрепления.",
      "First line. Blue is coming from the west. The city feeds the army — do not give up Donetsk.",
    ),
    objective: T("Продержаться 2 минуты или уничтожить синих.", "Hold for 2 minutes or destroy Blue."),
    win: "hold",
    holdSec: 100,
    loseIfCityFalls: ["donetsk"],
    player: 0,
    factions: [0, 1],
    fog: false,
    ai: 0,
    points: [6, 1, 0, 0],
    owners: { donetsk: 0, volnovakha: 1, pokrovsk: 1, bakhmut: -1 },
    spawns: [
      { city: "donetsk", owner: 0, kind: "light", n: 4 },
      { city: "donetsk", owner: 0, kind: "heavy", n: 1 },
      { city: "volnovakha", owner: 1, kind: "light", n: 2 },
      { city: "pokrovsk", owner: 1, kind: "light", n: 2 },
    ],
  }),
  scenario({
    id: "c2",
    campaign: true,
    title: T("Три узла", "Three nodes"),
    brief: T(
      "Вокруг Донецка нейтральные городки. Кто стоит в городе дольше — тот и берёт его. Синие сидят в Покровске.",
      "Neutral towns ring Donetsk. Whoever holds the square takes the city. Blue sits in Pokrovsk.",
    ),
    objective: T("Взять Волноваху, Бахмут и Мариуполь.", "Take Volnovakha, Bakhmut and Mariupol."),
    win: "capture",
    capture: ["volnovakha", "bakhmut", "mariupol"],
    player: 0,
    factions: [0, 1],
    fog: false,
    ai: 0,
    points: [5, 3, 0, 0],
    owners: { donetsk: 0, luhansk: 0, mariupol: -1, volnovakha: -1, bakhmut: -1, pokrovsk: 1 },
    spawns: [
      { city: "donetsk", owner: 0, kind: "light", n: 4 },
      { city: "donetsk", owner: 0, kind: "heavy", n: 1 },
      { city: "luhansk", owner: 0, kind: "light", n: 3 },
      { city: "pokrovsk", owner: 1, kind: "light", n: 3 },
    ],
  }),
  scenario({
    id: "c3",
    campaign: true,
    title: T("Чаща у Бахмута", "Bakhmut thicket"),
    brief: T(
      "Лес режет тяжёлые точки: они медленные и бьют слабо. Лёгкие здесь дома. Не ведите кулак в чащу.",
      "Forest punishes heavies: they crawl and hit weakly. Lights belong here. Do not march a fist into the trees.",
    ),
    objective: T("Взять Бахмут и Краматорск.", "Take Bakhmut and Kramatorsk."),
    win: "capture",
    capture: ["bakhmut", "kramatorsk"],
    player: 0,
    factions: [0, 1],
    fog: false,
    ai: 1,
    points: [6, 4, 0, 0],
    owners: { donetsk: 0, luhansk: 0, bakhmut: 1, kramatorsk: 1, kharkiv: -1 },
    spawns: [
      { city: "donetsk", owner: 0, kind: "light", n: 5 },
      { city: "luhansk", owner: 0, kind: "light", n: 3 },
      { city: "bakhmut", owner: 1, kind: "heavy", n: 2 },
      { city: "bakhmut", owner: 1, kind: "light", n: 2 },
      { city: "kramatorsk", owner: 1, kind: "light", n: 3 },
    ],
  }),
  scenario({
    id: "c4",
    campaign: true,
    title: T("Дорога к морю", "Road to the sea"),
    brief: T(
      "Южный коридор. Мариуполь кормит синих. Обойдите по степи или бейте в лоб — но следите, чтобы свои не ушли без снабжения.",
      "The southern corridor. Mariupol feeds Blue. Flank across the steppe or punch through — but do not outrun supply.",
    ),
    objective: T("Взять Мариуполь.", "Take Mariupol."),
    win: "capture",
    capture: ["mariupol"],
    player: 0,
    factions: [0, 1],
    fog: false,
    ai: 1,
    points: [5, 4, 0, 0],
    owners: { donetsk: 0, volnovakha: 0, mariupol: 1, berdiansk: 1, melitopol: -1 },
    spawns: [
      { city: "volnovakha", owner: 0, kind: "light", n: 4 },
      { city: "volnovakha", owner: 0, kind: "heavy", n: 1 },
      { city: "donetsk", owner: 0, kind: "light", n: 2 },
      { city: "mariupol", owner: 1, kind: "light", n: 3 },
      { city: "mariupol", owner: 1, kind: "heavy", n: 1 },
      { city: "berdiansk", owner: 1, kind: "light", n: 2 },
    ],
  }),
  scenario({
    id: "c5",
    campaign: true,
    title: T("Переправа", "The crossing"),
    brief: T(
      "Река почти стена. Вброд точки ползут и гибнут. Ищите мосты у Днепра, Запорожья и Херсона — по дороге через воду идут быстро.",
      "The river is almost a wall. Fording is slow and lethal. Use the bridges at Dnipro, Zaporizhzhia and Kherson.",
    ),
    objective: T("Взять Запорожье.", "Take Zaporizhzhia."),
    win: "capture",
    capture: ["zaporizhzhia"],
    player: 0,
    factions: [0, 1],
    fog: false,
    ai: 1,
    points: [6, 5, 0, 0],
    owners: { mariupol: 0, melitopol: 0, berdiansk: 0, zaporizhzhia: 1, dnipro: 1, kherson: 1 },
    spawns: [
      { city: "melitopol", owner: 0, kind: "light", n: 4 },
      { city: "melitopol", owner: 0, kind: "heavy", n: 1 },
      { city: "mariupol", owner: 0, kind: "light", n: 3 },
      { city: "berdiansk", owner: 0, kind: "light", n: 2 },
      { city: "zaporizhzhia", owner: 1, kind: "light", n: 3 },
      { city: "zaporizhzhia", owner: 1, kind: "heavy", n: 1 },
      { city: "dnipro", owner: 1, kind: "light", n: 3 },
      { city: "kherson", owner: 1, kind: "light", n: 2 },
    ],
  }),
  scenario({
    id: "c6",
    campaign: true,
    title: T("Два фронта", "Two fronts"),
    brief: T(
      "Синие давят с запада, зелёные — с севера. Туман скрывает точки вне обзора городов и отрядов. Держите Донецк и бейте по очереди.",
      "Blue pushes from the west, Green from the north. Fog hides dots outside vision. Hold Donetsk and hit one front at a time.",
    ),
    objective: T("Взять Покровск и Краматорск. Не отдайте Донецк.", "Take Pokrovsk and Kramatorsk. Do not lose Donetsk."),
    win: "capture",
    capture: ["pokrovsk", "kramatorsk"],
    loseIfCityFalls: ["donetsk"],
    player: 0,
    factions: [0, 1, 2],
    fog: true,
    ai: 2,
    points: [6, 4, 4, 0],
    owners: { donetsk: 0, bakhmut: 0, pokrovsk: 1, dnipro: 1, luhansk: 2, kramatorsk: 2 },
    spawns: [
      { city: "donetsk", owner: 0, kind: "light", n: 4 },
      { city: "donetsk", owner: 0, kind: "heavy", n: 1 },
      { city: "bakhmut", owner: 0, kind: "light", n: 3 },
      { city: "pokrovsk", owner: 1, kind: "light", n: 4 },
      { city: "dnipro", owner: 1, kind: "light", n: 2 },
      { city: "luhansk", owner: 2, kind: "light", n: 3 },
      { city: "luhansk", owner: 2, kind: "heavy", n: 1 },
      { city: "kramatorsk", owner: 2, kind: "light", n: 2 },
    ],
  }),
  scenario({
    id: "c7",
    campaign: true,
    title: T("Кольцо столицы", "Ring around the capital"),
    brief: T(
      "Полная карта. Запад держит Киев за рекой. Тяжёлые хороши в степи и на холмах, лёгкие — в лесу и в городе. Берите мосты, потом столицу.",
      "The full map. The west holds Kyiv behind the river. Heavies like open ground; lights like woods and streets. Take the bridges, then the capital.",
    ),
    objective: T("Взять Киев.", "Take Kyiv."),
    win: "capture",
    capture: ["kyiv"],
    player: 0,
    factions: [0, 1],
    fog: false,
    ai: 2,
    points: [8, 8, 0, 0],
    owners: {
      donetsk: 0,
      luhansk: 0,
      mariupol: 0,
      melitopol: 0,
      zaporizhzhia: 0,
      bakhmut: 0,
      volnovakha: 0,
      kyiv: 1,
      dnipro: 1,
      kharkiv: 1,
      kherson: 1,
      mykolaiv: 1,
      kramatorsk: 1,
      pokrovsk: 1,
      berdiansk: -1,
    },
    spawns: autoSpawns({
      donetsk: 0,
      luhansk: 0,
      mariupol: 0,
      melitopol: 0,
      zaporizhzhia: 0,
      bakhmut: 0,
      volnovakha: 0,
      kyiv: 1,
      dnipro: 1,
      kharkiv: 1,
      kherson: 1,
      mykolaiv: 1,
      kramatorsk: 1,
      pokrovsk: 1,
    }),
  }),
];

const WORLD_DEFS: {
  title: Record<Lang, string>;
  brief: Record<Lang, string>;
  objective: Record<Lang, string>;
  win: WinMode;
  capture: string[];
  owners: Record<string, OwnerId>;
  factions: FactionId[];
}[] = [
  {
    title: T("Сектор: Донбасс", "Sector: Donbas"),
    brief: T("Восточный край линии. Возьмите нейтральные городки раньше синих.", "Eastern edge of the line. Take the neutral towns before Blue."),
    objective: T("Лишить синих всех городов сектора.", "Strip Blue of every city in the sector."),
    win: "eliminate",
    capture: [],
    factions: [0, 1],
    owners: { donetsk: 0, luhansk: 0, volnovakha: -1, bakhmut: 1, pokrovsk: 1, mariupol: -1 },
  },
  {
    title: T("Сектор: Азов", "Sector: Azov"),
    brief: T("Южный берег. Мариуполь — ключ коридора.", "The southern shore. Mariupol is the key to the corridor."),
    objective: T("Взять Мариуполь и Мелитополь.", "Take Mariupol and Melitopol."),
    win: "capture",
    capture: ["mariupol", "melitopol"],
    factions: [0, 1],
    owners: { volnovakha: 0, berdiansk: 0, mariupol: 1, melitopol: -1, zaporizhzhia: -1 },
  },
  {
    title: T("Сектор: Запорожье", "Sector: Zaporizhzhia"),
    brief: T("Мост через реку. Не переправляйтесь вброд всей армией.", "The bridge over the river. Do not ford with the whole army."),
    objective: T("Взять Запорожье.", "Take Zaporizhzhia."),
    win: "capture",
    capture: ["zaporizhzhia"],
    factions: [0, 1],
    owners: { melitopol: 0, berdiansk: 0, mariupol: 0, zaporizhzhia: 1, dnipro: 1 },
  },
  {
    title: T("Сектор: Харьков", "Sector: Kharkiv"),
    brief: T("Северный лес. Лёгкие точки пройдут там, где тяжёлые завязнут.", "Northern forest. Lights go where heavies bog down."),
    objective: T("Взять Харьков.", "Take Kharkiv."),
    win: "capture",
    capture: ["kharkiv"],
    factions: [0, 1],
    owners: { bakhmut: 0, kramatorsk: 0, pokrovsk: -1, kharkiv: 1 },
  },
  {
    title: T("Сектор: Днепр", "Sector: Dnipro"),
    brief: T("Речная линия. Контроль моста решает снабжение.", "The river line. The bridge decides supply."),
    objective: T("Взять Днепр.", "Take Dnipro."),
    win: "capture",
    capture: ["dnipro"],
    factions: [0, 1],
    owners: { zaporizhzhia: 0, pokrovsk: 0, dnipro: 1, kherson: 1, melitopol: -1 },
  },
  {
    title: T("Сектор: Столица", "Sector: Capital"),
    brief: T("Последний переход. Киев за рекой.", "The last crossing. Kyiv is behind the river."),
    objective: T("Взять Киев.", "Take Kyiv."),
    win: "capture",
    capture: ["kyiv"],
    factions: [0, 1],
    owners: { dnipro: 0, kharkiv: 0, zaporizhzhia: 0, kyiv: 1, mykolaiv: 1, kherson: 1 },
  },
];

export function worldScenario(index: number): Scenario {
  const i = Math.max(0, Math.min(WORLD_DEFS.length - 1, index));
  const d = WORLD_DEFS[i]!;
  return scenario({
    id: `world-${i}`,
    world: true,
    title: d.title,
    brief: d.brief,
    objective: d.objective,
    win: d.win,
    capture: d.capture,
    player: 0,
    factions: d.factions,
    fog: i >= 4,
    ai: i >= 4 ? 2 : i >= 2 ? 1 : 0,
    points: [6, 5, 5, 5],
    owners: d.owners,
    spawns: autoSpawns(d.owners),
  });
}

export function skirmishScenario(ffa: 2 | 3 | 4, player: FactionId, fog: boolean): Scenario {
  const owners: Record<string, OwnerId> = {
    kyiv: 1,
    mykolaiv: 1,
    kherson: 1,
    dnipro: 1,
    luhansk: 0,
    donetsk: 0,
    mariupol: 0,
    volnovakha: 0,
    kharkiv: -1,
    kramatorsk: -1,
    bakhmut: -1,
    pokrovsk: -1,
    zaporizhzhia: -1,
    melitopol: -1,
    berdiansk: -1,
  };
  const factions: FactionId[] = [0, 1];
  if (ffa >= 3) {
    owners.kharkiv = 2;
    owners.kramatorsk = 2;
    factions.push(2);
  }
  if (ffa >= 4) {
    owners.melitopol = 3;
    owners.berdiansk = 3;
    owners.zaporizhzhia = 3;
    factions.push(3);
  }
  const names =
    ffa === 2
      ? T("Стычка", "Skirmish")
      : ffa === 3
        ? T("Трое на карте", "Three on the map")
        : T("Все против всех", "Free for all");
  return scenario({
    id: `skirmish-${ffa}`,
    title: names,
    brief: T(
      "Полная стилизованная карта. Нейтральные города в центре не принадлежат никому, пока в них не постоит армия. Снабжение решает, сколько точек может жить.",
      "The full stylized map. Neutral towns belong to whoever stands in them. Supply decides how many dots can live.",
    ),
    objective: T("Захватить все города противников.", "Take every enemy city."),
    win: "eliminate",
    player,
    factions,
    fog,
    ai: 1,
    points: [5, 5, 5, 5],
    owners,
    spawns: autoSpawns(owners),
  });
}

export function templateScenario(): Scenario {
  return skirmishScenario(2, 0, false);
}

export function lex(lang: Lang) {
  const ru = lang === "ru";
  return {
    title: ru ? "Точки фронта" : "Front Dots",
    kicker: ru ? "Линия · снабжение · манёвр" : "Line · supply · maneuver",
    tagline: ru
      ? "Минималистичная стратегия. Красные — восток, синие — запад. Города с знакомыми именами, правила — про точки, а не про сводки."
      : "A minimalist real-time strategy. Red is east, blue is west. Familiar city names, rules about dots — not headlines.",
    skirmish: ru ? "Стычка 1 на 1" : "Skirmish 1v1",
    ffa: ru ? "Все против всех" : "Free for all",
    campaign: ru ? "Кампания" : "Campaign",
    world: ru ? "Линия фронта" : "Front line",
    help: ru ? "Как играть" : "How to play",
    settings: ru ? "Настройки" : "Settings",
    achievements: ru ? "Достижения" : "Achievements",
    editor: ru ? "Редактор" : "Editor",
    continue: ru ? "Продолжить бой" : "Continue battle",
    back: ru ? "Назад" : "Back",
    fight: ru ? "В бой" : "Fight",
    resume: ru ? "Вернуться" : "Resume",
    toMenu: ru ? "В меню" : "Main menu",
    retry: ru ? "Ещё раз" : "Retry",
    next: ru ? "Дальше" : "Next",
    replay: ru ? "Повтор боя" : "Replay",
    replayTitle: ru ? "Повтор" : "Replay",
    exitReplay: ru ? "Закрыть повтор" : "Close replay",
    pause: ru ? "Пауза" : "Pause",
    march: ru ? "Марш" : "March",
    marching: ru ? "Укажите точку" : "Tap a point",
    stop: ru ? "Стоп" : "Stop",
    cancelQ: ru ? "Отмена" : "Cancel",
    light: ru ? "Лёгкая · 1" : "Light · 1",
    heavy: ru ? "Тяжёлая · 3" : "Heavy · 3",
    victory: ru ? "Рубеж взят" : "Line taken",
    defeat: ru ? "Рубеж оставлен" : "Line lost",
    kills: ru ? "Уничтожено" : "Destroyed",
    losses: ru ? "Потеряно" : "Lost",
    citiesTaken: ru ? "Городов взято" : "Cities taken",
    battleTime: ru ? "Время" : "Time",
    starved: ru ? "Без снабжения" : "Starved",
    easy: ru ? "Мягкий" : "Easy",
    normal: ru ? "Ровный" : "Normal",
    hard: ru ? "Жёсткий" : "Hard",
    fog: ru ? "Туман войны" : "Fog of war",
    sound: ru ? "Звук" : "Sound",
    volume: ru ? "Громкость" : "Volume",
    language: ru ? "Язык" : "Language",
    record: ru ? "Запоминать повтор" : "Record replay",
    difficulty: ru ? "Сложность ИИ" : "AI difficulty",
    side: ru ? "Ваша сторона" : "Your side",
    players: ru ? "Стороны" : "Sides",
    three: ru ? "Три стороны" : "Three sides",
    four: ru ? "Четыре стороны" : "Four sides",
    objective: ru ? "Задача" : "Objective",
    briefing: ru ? "Сводка" : "Briefing",
    locked: ru ? "Закрыто" : "Locked",
    cleared: ru ? "Пройдено" : "Cleared",
    supply: ru ? "Снабжение" : "Supply",
    neutral: ru ? "Нейтральный" : "Neutral",
    level: ru ? "ур." : "lv.",
    queue: ru ? "Очередь" : "Queue",
    garrison: ru ? "В городе" : "In the city",
    selected: ru ? "Выбрано" : "Selected",
    hintIdle: ru
      ? "Тап по городу — производство. Тап по точке — выбор. На телефоне нажмите «Марш», затем точку на карте."
      : "Tap a city to build. Tap a dot to select. On a phone, press March, then a point on the map.",
    hintMarch: ru ? "Тапните по карте, городу или врагу." : "Tap the map, a city, or an enemy.",
    cityTaken: ru ? "Город взят" : "City taken",
    cityLost: ru ? "Город потерян" : "City lost",
    armyCut: ru ? "Армия окружена" : "Army encircled",
    supplyLow: ru ? "Снабжения не хватает" : "Supply is short",
    achGet: ru ? "Достижение" : "Achievement",
    skip: ru ? "Пропустить обучение" : "Skip tutorial",
    nextTip: ru ? "Дальше" : "Next",
    gotIt: ru ? "Понятно" : "Got it",
    worldBlurb: ru
      ? "Победы сдвигают линию на запад, поражения — обратно. Прогресс хранится на этом устройстве."
      : "Wins push the line west, losses pull it back. Progress stays on this device.",
    worldDone: ru ? "Линия пройдена." : "The line is through.",
    worldFight: ru ? "Бой этого сектора" : "Fight this sector",
    sector: ru ? "Сектор" : "Sector",
    editorHelp: ru
      ? "Сценарий — JSON. Поля: title, brief, objective (объекты ru/en), win (eliminate | capture | hold), capture, holdSec, loseIfCityFalls, player (0–3), factions, fog, points [4 числа], owners {город: -1|0|1|2|3}, spawns [{city, owner, kind, n}], ai (0–2)."
      : "A scenario is JSON. Fields: title, brief, objective ({ru,en}), win (eliminate|capture|hold), capture, holdSec, loseIfCityFalls, player (0–3), factions, fog, points [4], owners {city: -1|0|1|2|3}, spawns [{city, owner, kind, n}], ai (0–2).",
    template: ru ? "Шаблон" : "Template",
    validate: ru ? "Проверить" : "Check",
    saveSc: ru ? "Сохранить" : "Save",
    play: ru ? "Играть" : "Play",
    del: ru ? "Удалить" : "Delete",
    saved: ru ? "Сохранённые" : "Saved",
    okJson: ru ? "Сценарий читается." : "Scenario looks valid.",
    badJson: ru ? "Не удалось прочитать сценарий." : "Could not read the scenario.",
    noBattle: ru ? "Нет сохранённого повтора." : "No replay saved.",
    speed: ru ? "Скорость" : "Speed",
    units: ru ? "Точки" : "Dots",
    enc: ru ? "окруж." : "cut off",
    helpBody: ru
      ? [
          "Две основные стороны — красные точки востока и синие точки запада. В режиме «все против всех» к ним добавляются зелёные и янтарные. Это абстрактная партия на стилизованной карте региона, а не реконструкция реальных операций.",
          "Тап по своей точке выбирает её. Рамкой на компьютере можно взять пачку (потяните левой кнопкой по пустой земле). Правый клик — сразу марш. На телефоне: выбрали отряд, нажали «Марш», тапнули куда идти. Щипок — масштаб, одним пальцем тяните карту.",
          "Город производит очки. Лёгкая точка стоит 1 и готовится быстро: она шустрая и в лесу даже сильнее. Тяжёлая стоит 3: много здоровья, медленная, в лесу почти бесполезна, на степи и холмах — кулак.",
          "Каждый город кормит ограниченное число точек (лёгкая ест 1, тяжёлая — 2). Лишние голодают. Если враги перерезали путь к вашему городу, отряд окружён и тает очень быстро. Стоять на месте пару секунд — небольшая броня.",
          "Бой сам: точки ранят друг друга, когда соприкасаются. Чтобы взять город, убейте защитников внутри кольца и постойте в нём. Реку лучше переходить по дороге-мосту у Днепра, Запорожья и Херсона.",
          "Клавиши: пробел — пауза, 1 и 2 — производство, M — марш, WASD — сдвиг карты, колёсико — масштаб. Геймпад: левый стик двигает карту, правый — прицел, A — приказ, Start — пауза.",
        ]
      : [
          "Two main sides: red dots of the east and blue dots of the west. Free-for-all adds green and amber. This is an abstract match on a stylized regional map, not a reconstruction of real operations.",
          "Tap your dot to select it. On a computer, drag the left button across empty ground to box-select. Right click marches at once. On a phone: select, press March, tap the destination. Pinch to zoom, one finger pans.",
          "Cities mint points. A light costs 1 and trains fast — quick, and even stronger in forest. A heavy costs 3: lots of health, slow, nearly useless in woods, a fist on open ground and hills.",
          "Each city feeds a limited number of dots (a light eats 1, a heavy eats 2). Extras starve. If enemies cut the path back to your city, the squad is encircled and melts. Standing still for a couple of seconds adds a little armor.",
          "Combat is automatic when dots touch. To take a city, kill the defenders inside the ring and stand there. Cross the river on the road-bridges at Dnipro, Zaporizhzhia and Kherson.",
          "Keys: space pauses, 1 and 2 build, M arms march, WASD pans, wheel zooms. Gamepad: left stick pans, right stick aims, A orders, Start pauses.",
        ],
    tut: ru
      ? [
          "Это Донецк — ваш город, красное кольцо. Он даёт очки и кормит точки.",
          "Нажмите на Донецк, затем «Лёгкая · 1». Так появляется быстрая точка.",
          "Нажмите на новую красную точку, чтобы выбрать её.",
          "Нажмите «Марш» и тапните по нейтральному Бахмуту или по земле рядом. На компьютере можно просто кликнуть правой кнопкой.",
          "Дальше точки дерутся сами, если соприкоснутся. Не уводите их далеко от города без дороги снабжения — окружённые гаснут. Обучение можно закрыть.",
        ]
      : [
          "This is Donetsk — your city, the red ring. It mints points and feeds dots.",
          "Tap Donetsk, then Light · 1. That trains a fast dot.",
          "Tap the new red dot to select it.",
          "Press March and tap neutral Bakhmut or the ground nearby. On a computer you can just right-click.",
          "Dots fight on their own when they touch. Do not march them far from a city without a supply path — encircled ones fade. You can close the lesson.",
        ],
  };
}
