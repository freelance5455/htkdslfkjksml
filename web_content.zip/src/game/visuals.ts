import * as THREE from "three";
import type { Celestial } from "./types";

const TAU = Math.PI * 2;

function seeded(seed: number) {
  let s = (seed >>> 0) || 1;
  return () => {
    s ^= s << 13;
    s ^= s >>> 17;
    s ^= s << 5;
    return ((s >>> 0) % 1000000) / 1000000;
  };
}

function gauss(rand: () => number) {
  let u = Math.max(1e-5, rand());
  let v = Math.max(1e-5, rand());
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(TAU * v);
}

function getMorph(g: Celestial) {
  return g.morphology ?? {
    dust: 0.55,
    starburst: 0.3,
    asymmetry: 0.12,
    clumpy: 0.18,
    ring: 0,
    tails: 0,
    companions: 0,
    jet: 0,
  };
}

export function makeGlowTexture(size = 64) {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const g = c.getContext("2d");
  if (!g) throw new Error("2d");
  const grd = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grd.addColorStop(0, "rgba(255,255,255,1)");
  grd.addColorStop(0.2, "rgba(255,255,255,.92)");
  grd.addColorStop(0.55, "rgba(255,255,255,.22)");
  grd.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function disposeObject(obj: THREE.Object3D) {
  obj.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (mesh.geometry) mesh.geometry.dispose();
    const mat = (o as THREE.Mesh).material;
    if (!mat) return;
    if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
    else mat.dispose();
  });
}

export function makeStarfield(count: number, radius: number) {
  const rand = seeded(0x8f5a91 + count);
  const pos = new Float32Array(count * 3);
  const col = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const z = rand() * 2 - 1;
    const a = rand() * TAU;
    const s = Math.sqrt(1 - z * z);
    const r = radius * (0.45 + rand() * 0.55);
    const k = i * 3;
    pos[k] = r * s * Math.cos(a);
    pos[k + 1] = r * z * 0.72;
    pos[k + 2] = r * s * Math.sin(a);
    const cool = rand();
    const hot = Math.pow(rand(), 4);
    col[k] = 0.62 + cool * 0.22 + hot * 0.16;
    col[k + 1] = 0.68 + cool * 0.18 + hot * 0.08;
    col[k + 2] = 0.82 + (1 - cool) * 0.13 + hot * 0.05;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  return geo;
}

export function makeGalaxyGeometry(g: Celestial, count: number) {
  const P = new Float32Array(count * 3);
  const C = new Float32Array(count * 3);
  const c1 = new THREE.Color(g.colorA);
  const c2 = new THREE.Color(g.colorB);
  const mix = new THREE.Color();
  const rand = seeded(g.seed ?? (g.id + 1) * 7919);
  const m = getMorph(g);
  let i = 0;

  const put = (x: number, y: number, z: number, t: number, bright = 1) => {
    if (i >= count) return;
    const k = i * 3;
    const jitter = 0.92 + rand() * 0.2;
    P[k] = x * jitter;
    P[k + 1] = y;
    P[k + 2] = z * jitter;
    mix.copy(c1).lerp(c2, Math.max(0, Math.min(1, t)));
    const b = Math.max(0.2, bright);
    C[k] = mix.r * b;
    C[k + 1] = mix.g * b;
    C[k + 2] = mix.b * b;
    i++;
  };

  const radius = g.radius;
  const thick = Math.max(0.01, g.thick);
  const arms = Math.max(2, g.arms);
  const spin = g.spin;
  const bulge = g.bulge;
  const asym = m.asymmetry;
  const clumpy = m.clumpy;
  const starburst = m.starburst;

  if (g.kind === "elliptical") {
    while (i < count) {
      const q = radius * 0.62 * Math.pow(rand(), 1.65);
      const z = (rand() * 2 - 1) * q;
      const a = rand() * TAU;
      const xy = Math.sqrt(Math.max(0, q * q - z * z));
      const lops = 1 + asym * 0.13 * Math.sin(a * 2.0 + g.id);
      put(xy * Math.cos(a) * lops, z * 0.82, xy * Math.sin(a), Math.pow(rand(), 0.7), 0.72 + rand() * 0.55);
      if (m.ring > 0.2 && rand() < m.ring * 0.18 && i < count) {
        const rr = radius * (0.66 + rand() * 0.18);
        put(rr * Math.cos(a), gauss(rand) * thick * 0.22, rr * Math.sin(a), 0.8, 0.72);
      }
    }
  } else if (g.kind === "ring" || m.ring > 0.55) {
    const ringRatio = 0.75 + rand() * 0.08;
    while (i < Math.floor(count * 0.78)) {
      const a = rand() * TAU;
      let rr = radius * ringRatio * (1 + gauss(rand) * (0.03 + m.clumpy * 0.025));
      rr += Math.sin(a * (5 + g.id % 4)) * radius * 0.02 * asym;
      put(rr * Math.cos(a), gauss(rand) * thick * radius * 0.14, rr * Math.sin(a), 0.55 + rand() * 0.4, 0.88 + rand() * 0.42);
    }
    while (i < count) {
      const s = radius * (0.06 + 0.26 * Math.pow(rand(), 1.35));
      const a = rand() * TAU;
      const z = gauss(rand) * s * 0.55;
      put(s * Math.cos(a), z, s * Math.sin(a), rand() * 0.35, 0.55 + rand() * 0.55);
    }
  } else if (g.kind === "irregular") {
    const clumps = Math.max(5, Math.round(5 + clumpy * 8));
    const anchors = Array.from({ length: clumps }, (_, k) => {
      const a = rand() * TAU;
      const rr = radius * (0.18 + rand() * 0.5);
      return {
        x: Math.cos(a) * rr * (1 + asym * 0.4 * (rand() - 0.5)),
        y: gauss(rand) * radius * 0.28,
        z: Math.sin(a) * rr,
        s: radius * (0.07 + rand() * (0.1 + starburst * 0.16)),
      };
    });
    while (i < count) {
      const a = anchors[i % anchors.length];
      const hot = rand() < starburst * 0.34;
      put(a.x + gauss(rand) * a.s, a.y + gauss(rand) * a.s * 0.5, a.z + gauss(rand) * a.s, hot ? 0.95 : rand(), 0.7 + rand() * 0.6 + (hot ? 0.25 : 0));
    }
  } else if (g.kind === "interact") {
    const mainN = Math.floor(count * 0.68);
    const companionN = Math.floor(count * 0.18);
    const tailN = count - mainN - companionN;
    generateSpiral(mainN, 0, 0, 0, 1, arms, radius, spin, bulge, thick, 1, asym, clumpy, starburst, put, rand);
    generateSpiral(companionN, radius * 1.35, radius * 0.15, -radius * 0.6, 0.48, Math.max(2, arms - 1), radius, spin * 1.2, 0.35, thick * 1.2, 1, asym, clumpy, starburst, put, rand);
    for (let k = 0; k < tailN && i < count; k++) {
      const u = k / Math.max(1, tailN - 1);
      const x = radius * (1 + u * 2.2) + gauss(rand) * radius * (0.08 + 0.1 * u);
      const z = radius * (0.5 + u * 0.8) * (u * 0.65 + 0.18) + gauss(rand) * radius * 0.11;
      const y = gauss(rand) * radius * (0.08 + u * 0.18);
      put(x, y, z, 0.35 + u * 0.45, 0.45 + rand() * 0.45);
    }
  } else {
    generateSpiral(count, 0, 0, 0, 1, arms, radius, spin, bulge, thick, g.kind === "barred", asym, clumpy, starburst, put, rand);
  }

  if (i < count) {
    while (i < count) {
      const s = radius * 0.12 * Math.pow(rand(), 1.8);
      put(gauss(rand) * s, gauss(rand) * s * 0.55, gauss(rand) * s, rand(), 1.05 + rand() * 0.25);
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(P, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(C, 3));
  geo.computeBoundingSphere();
  return geo;
}

function generateSpiral(
  n: number,
  ox: number,
  oy: number,
  oz: number,
  scale: number,
  arms: number,
  radius: number,
  spin: number,
  bulge: number,
  thick: number,
  bar: boolean,
  asym: number,
  clumpy: number,
  starburst: number,
  put: (x: number, y: number, z: number, t: number, bright?: number) => void,
  rand: () => number,
) {
  for (let k = 0; k < n; k++) {
    const u = rand();
    if (u < bulge * 0.75) {
      const s = radius * scale * 0.34 * Math.pow(rand(), 1.55);
      const a = rand() * TAU;
      put(ox + s * Math.cos(a), oy + gauss(rand) * s * 0.55, oz + s * Math.sin(a), 0.08, 0.95 + rand() * 0.35);
      continue;
    }
    const r = radius * scale * Math.pow(rand(), 0.72);
    const arm = Math.floor(rand() * arms);
    const winding = spin * 2.0 * Math.log(1 + (r / Math.max(0.1, radius * scale)) * 5);
    const armAngle = arm * TAU / arms;
    let a = armAngle + winding + gauss(rand) * (0.09 + (1 - r / Math.max(0.01, radius * scale)) * 0.12);
    if (bar && r < radius * scale * 0.3) {
      const bx = rand() < 0.5 ? 0 : Math.PI;
      a = bx + gauss(rand) * 0.1;
    }
    const lopsided = 1 + asym * 0.15 * Math.cos(a * 2 + 1.7);
    const clump = Math.max(0.05, 1 - clumpy * 0.35 * Math.abs(Math.sin(a * 4 + r * 1.3)));
    const rr = r * (0.86 + clump * 0.18) * lopsided;
    const z = gauss(rand) * thick * radius * scale * (0.13 + 0.42 * rr / Math.max(0.1, radius * scale));
    const hot = rand() < starburst * 0.14 && rr > radius * scale * 0.25;
    put(ox + rr * Math.cos(a), oy + z, oz + rr * Math.sin(a), Math.min(1, rr / Math.max(0.01, radius * scale)), 0.7 + rand() * 0.35 + (hot ? 0.35 : 0));
  }
}

export function makeDustGeometry(g: Celestial, count: number) {
  const P = new Float32Array(count * 3);
  const C = new Float32Array(count * 3);
  const rand = seeded((g.seed ?? g.id + 11) ^ 0xabc123);
  const radius = g.radius;
  const m = getMorph(g);
  let i = 0;
  const put = (x: number, y: number, z: number, alpha: number) => {
    const k = i * 3;
    P[k] = x; P[k + 1] = y; P[k + 2] = z;
    C[k] = 0.12 * alpha;
    C[k + 1] = 0.09 * alpha;
    C[k + 2] = 0.07 * alpha;
    i++;
  };
  while (i < count) {
    const r = radius * (0.2 + 0.78 * Math.pow(rand(), 0.72));
    const arm = Math.floor(rand() * Math.max(2, g.arms));
    const a = arm * TAU / Math.max(2, g.arms) + g.spin * 2.0 * Math.log(1 + r * 1.8) + gauss(rand) * (0.035 + (1 - r / radius) * 0.11);
    const lane = 0.1 + (1 - r / radius) * 0.25;
    const y = gauss(rand) * radius * lane * Math.max(0.02, g.thick) * (0.2 + m.dust);
    const rr = r * (1 + gauss(rand) * 0.018);
    put(rr * Math.cos(a), y, rr * Math.sin(a), 0.4 + 0.6 * m.dust);
    if (m.dust < 0.2 && rand() < 0.5) i--;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(P, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(C, 3));
  return geo;
}

export function makeHIIField(g: Celestial, count: number) {
  const P = new Float32Array(count * 3);
  const C = new Float32Array(count * 3);
  const rand = seeded((g.seed ?? g.id + 31) ^ 0x8912e1);
  const c1 = new THREE.Color(g.colorB);
  const c2 = new THREE.Color(g.colorA);
  const mix = new THREE.Color();
  const m = getMorph(g);
  let i = 0;
  while (i < count) {
    const r = g.radius * (0.18 + Math.pow(rand(), 0.7) * 0.85);
    const a = rand() * TAU;
    const arm = Math.floor(rand() * Math.max(2, g.arms));
    const spiral = arm * TAU / Math.max(2, g.arms) + g.spin * 2 * Math.log(1 + r / Math.max(0.1, g.radius) * 4);
    const ang = spiral + gauss(rand) * 0.15;
    const p = rand() < m.clumpy ? 0.0 : 0.25;
    P[i * 3] = r * Math.cos(ang) + gauss(rand) * g.radius * 0.028;
    P[i * 3 + 1] = gauss(rand) * g.radius * (g.thick * 0.25 + p);
    P[i * 3 + 2] = r * Math.sin(ang) + gauss(rand) * g.radius * 0.028;
    mix.copy(c1).lerp(c2, rand());
    const b = 0.75 + m.starburst * 0.9 + rand() * 0.35;
    C[i * 3] = mix.r * b; C[i * 3 + 1] = mix.g * b; C[i * 3 + 2] = mix.b * b;
    i++;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(P, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(C, 3));
  return geo;
}

export function makeDimensionField(count = 1800) {
  const pos = new Float32Array(count * 3);
  const base = new Float32Array(count * 4);
  const rand = seeded(0x5d13e5);
  for (let i = 0; i < count; i++) {
    const u = rand() * 2 - 1;
    const a = rand() * TAU;
    const b = rand() * TAU;
    const s = Math.sqrt(Math.max(0, 1 - u * u));
    const r = 24 + rand() * 44;
    const j = i * 4;
    base[j] = s * Math.cos(a);
    base[j + 1] = s * Math.sin(a);
    base[j + 2] = u;
    base[j + 3] = b;
    pos[i * 3] = base[j] * r;
    pos[i * 3 + 1] = base[j + 1] * r;
    pos[i * 3 + 2] = base[j + 2] * r;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("aBase", new THREE.BufferAttribute(base, 4));
  return geo;
}

export function makeShip() {
  const g = new THREE.Group();
  const hullMat = new THREE.MeshBasicMaterial({ color: 0xc9d4e2 });
  const accentMat = new THREE.MeshBasicMaterial({ color: 0x9ec4e8 });
  const darkMat = new THREE.MeshBasicMaterial({ color: 0x1a222c });
  const bodyGeo = new THREE.ConeGeometry(0.22, 1.15, 6);
  bodyGeo.rotateX(Math.PI / 2);
  const body = new THREE.Mesh(bodyGeo, hullMat);
  body.position.z = 0.12;
  g.add(body);
  const cabin = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), accentMat);
  cabin.position.set(0, 0.08, 0.05);
  g.add(cabin);
  const wingGeo = new THREE.BoxGeometry(1.15, 0.04, 0.28);
  const wings = new THREE.Mesh(wingGeo, darkMat);
  wings.position.z = 0.22;
  g.add(wings);
  const fin = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.32, 0.22), darkMat);
  fin.position.set(0, 0.2, 0.28);
  g.add(fin);
  const engine = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), new THREE.MeshBasicMaterial({ color: 0xa8d7ff }));
  engine.position.z = 0.72;
  engine.name = "engine";
  g.add(engine);
  g.traverse((o) => { o.frustumCulled = false; });
  return g;
}

const BH_V = `
varying vec2 vUv;
void main(){
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0);
}
`;
const BH_F = `
uniform float uTime;
uniform vec3 uHot;
uniform vec3 uCool;
varying vec2 vUv;
float hash21(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }
void main(){
  vec2 p = vUv - .5;
  float r = length(p)*2.;
  float a = atan(p.y,p.x);
  float horizon = 1.0-smoothstep(.17,.30,r);
  float ring = smoothstep(.28,.33,r) * (1.0-smoothstep(.63,.95,r));
  float inner = smoothstep(.33,.43,r);
  float fil = .5+.5*sin(a*18.0-r*17.0-uTime*3.3);
  float turbul = hash21(vUv*80.+uTime*.18);
  vec3 disk = mix(uCool,uHot, .45+.4*fil);
  disk *= .65 + .35*turbul;
  float glow = smoothstep(.82,.18,r)*.17;
  float alpha = ring*.95 + glow + inner*.10;
  vec3 col = disk*ring + mix(uHot,uCool,.5)*glow;
  col *= 1.15;
  col *= 1.0-horizon*.98;
  if(alpha<.01) discard;
  gl_FragColor = vec4(col, clamp(alpha,0.0,.98));
}
`;

export function makeBlackHole(body: Celestial) {
  const g = new THREE.Group();
  const scale = 0.65 + body.radius * 0.22;
  const hole = new THREE.Mesh(
    new THREE.SphereGeometry(0.58 * scale, 24, 16),
    new THREE.MeshBasicMaterial({ color: 0x000000 }),
  );
  hole.renderOrder = 2;
  g.add(hole);

  const mat = new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uHot: { value: new THREE.Color(body.colorA) },
      uCool: { value: new THREE.Color(body.colorB) },
    },
    vertexShader: BH_V,
    fragmentShader: BH_F,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    toneMapped: false,
    side: THREE.DoubleSide,
  });
  const disk = new THREE.Mesh(new THREE.PlaneGeometry(4.8 * scale, 4.8 * scale), mat);
  disk.name = "disk";
  disk.rotation.x = Math.PI / 2.4;
  disk.renderOrder = 3;
  g.add(disk);

  const photon = new THREE.Mesh(
    new THREE.TorusGeometry(0.63 * scale, 0.08 * scale, 10, 64),
    new THREE.MeshBasicMaterial({ color: body.colorA, transparent: true, opacity: 0.62, depthWrite: false, blending: THREE.AdditiveBlending }),
  );
  photon.rotation.x = Math.PI / 2;
  photon.renderOrder = 4;
  g.add(photon);

  const jetGeo = new THREE.ConeGeometry(0.14 * scale, 3.8 * scale, 12);
  const jetMat = new THREE.MeshBasicMaterial({ color: body.colorB, transparent: true, opacity: 0.12, depthWrite: false, blending: THREE.AdditiveBlending });
  const jet = new THREE.Mesh(jetGeo, jetMat);
  jet.position.y = 1.65 * scale;
  jet.rotation.x = 0;
  jet.name = "jet";
  g.add(jet);

  const glow = new THREE.Sprite(
    new THREE.SpriteMaterial({ color: body.colorB, transparent: true, opacity: 0.22, depthWrite: false, blending: THREE.AdditiveBlending }),
  );
  glow.scale.setScalar(6.5 * scale);
  g.add(glow);
  return g;
}

export function makeCoreSprite(color: number, tex: THREE.Texture) {
  const mat = new THREE.SpriteMaterial({
    map: tex,
    color,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    opacity: 0.52,
  });
  const s = new THREE.Sprite(mat);
  s.scale.setScalar(6);
  s.renderOrder = 1;
  return s;
}

export const POINT_MAT_PARAMS = {
  size: 0.09,
  vertexColors: true,
  transparent: true,
  depthWrite: false,
  blending: THREE.AdditiveBlending,
  opacity: 0.88,
  sizeAttenuation: true,
} as const;
