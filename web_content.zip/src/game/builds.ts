import { World, WORLD_SIZE } from "./world";

export type BuildKind = "mansion" | "bungalow" | "highway";

const AIR = 0;
const STONE = 3;
const WATER = 5;
const LOG = 6;
const LEAVES = 7;
const PLANKS = 8;
const GLASS = 9;
const BRICK = 10;
const COBBLE = 11;
const ASPHALT = 12;
const WHITE = 13;
const SLATE = 14;
const GOLD = 15;

function box(
  w: World,
  x0: number,
  y0: number,
  z0: number,
  x1: number,
  y1: number,
  z1: number,
  id: number,
) {
  for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) {
    for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) {
      for (let z = Math.min(z0, z1); z <= Math.max(z0, z1); z++) {
        w.set(x, y, z, id);
      }
    }
  }
}

function groundLevel(w: World, x: number, z: number, fallback: number) {
  if (x < 0 || z < 0 || x >= WORLD_SIZE || z >= WORLD_SIZE) return fallback;
  return w.heightAt(x, z);
}

/* ------------------------------------------------------------------ */
/*  MODERN MANSION — two floors, brick pillars, glass, slate roof, pool */
/* ------------------------------------------------------------------ */
function mansion(w: World, cx: number, cz: number) {
  const y0 = groundLevel(w, cx, cz, 22);
  const X = 12;
  const Z = 9;

  box(w, cx - X - 2, y0 - 6, cz - Z - 2, cx + X + 2, y0 + 20, cz + Z + 2, AIR);

  // level pad + foundation
  box(w, cx - X - 1, y0 - 4, cz - Z - 1, cx + X + 1, y0 - 1, cz + Z + 1, COBBLE);
  box(w, cx - X, y0, cz - Z, cx + X, y0, cz + Z, PLANKS);

  // ground floor walls
  box(w, cx - X, y0 + 1, cz - Z, cx + X, y0 + 5, cz - Z, WHITE);
  box(w, cx - X, y0 + 1, cz + Z, cx + X, y0 + 5, cz + Z, WHITE);
  box(w, cx - X, y0 + 1, cz - Z, cx - X, y0 + 5, cz + Z, WHITE);
  box(w, cx + X, y0 + 1, cz - Z, cx + X, y0 + 5, cz + Z, WHITE);

  // brick pillars
  for (let px = cx - X; px <= cx + X; px += 6) {
    box(w, px, y0 + 1, cz - Z, px, y0 + 9, cz - Z, BRICK);
    box(w, px, y0 + 1, cz + Z, px, y0 + 9, cz + Z, BRICK);
  }
  for (let pz = cz - Z; pz <= cz + Z; pz += 9) {
    box(w, cx - X, y0 + 1, pz, cx - X, y0 + 9, pz, BRICK);
    box(w, cx + X, y0 + 1, pz, cx + X, y0 + 9, pz, BRICK);
  }

  // ground floor windows
  for (let x = cx - X + 2; x <= cx + X - 2; x++) {
    if ((x - cx + 12) % 6 === 2) {
      box(w, x, y0 + 2, cz - Z, x, y0 + 4, cz - Z, GLASS);
      box(w, x, y0 + 2, cz + Z, x, y0 + 4, cz + Z, GLASS);
    }
  }
  for (let z = cz - Z + 2; z <= cz + Z - 2; z++) {
    if ((z - cz + 9) % 6 === 2) {
      box(w, cx - X, y0 + 2, z, cx - X, y0 + 4, z, GLASS);
      box(w, cx + X, y0 + 2, z, cx + X, y0 + 4, z, GLASS);
    }
  }

  // doorway
  box(w, cx - 1, y0 + 1, cz + Z, cx + 1, y0 + 4, cz + Z, AIR);
  box(w, cx - 1, y0 + 1, cz + Z - 1, cx + 1, y0 + 4, cz + Z - 1, AIR);

  // second floor slab + walls
  box(w, cx - X, y0 + 6, cz - Z, cx + X, y0 + 6, cz + Z, PLANKS);
  box(w, cx - X, y0 + 7, cz - Z, cx + X, y0 + 11, cz - Z, WHITE);
  box(w, cx - X, y0 + 7, cz + Z, cx + X, y0 + 11, cz + Z, WHITE);
  box(w, cx - X, y0 + 7, cz - Z, cx - X, y0 + 11, cz + Z, WHITE);
  box(w, cx + X, y0 + 7, cz - Z, cx + X, y0 + 11, cz + Z, WHITE);
  for (let x = cx - X + 2; x <= cx + X - 2; x++) {
    if ((x - cx + 12) % 6 === 2) {
      box(w, x, y0 + 8, cz - Z, x, y0 + 10, cz - Z, GLASS);
      box(w, x, y0 + 8, cz + Z, x, y0 + 10, cz + Z, GLASS);
    }
  }

  // stepped slate roof
  box(w, cx - X - 1, y0 + 12, cz - Z - 1, cx + X + 1, y0 + 12, cz + Z + 1, SLATE);
  box(w, cx - X + 3, y0 + 13, cz - Z + 3, cx + X - 3, y0 + 13, cz + Z - 3, SLATE);
  box(w, cx - X + 7, y0 + 14, cz - Z + 6, cx + X - 7, y0 + 14, cz + Z - 6, SLATE);

  // balcony over the entrance
  box(w, cx - 7, y0 + 6, cz + Z + 1, cx + 7, y0 + 6, cz + Z + 3, PLANKS);
  box(w, cx - 7, y0 + 7, cz + Z + 3, cx + 7, y0 + 7, cz + Z + 3, WHITE);
  box(w, cx - 7, y0 + 7, cz + Z + 1, cx - 7, y0 + 7, cz + Z + 3, WHITE);
  box(w, cx + 7, y0 + 7, cz + Z + 1, cx + 7, y0 + 7, cz + Z + 3, WHITE);

  // driveway + garden path
  box(w, cx - 2, y0 - 1, cz + Z + 1, cx + 2, y0 - 1, cz + Z + 12, COBBLE);

  // pool with white rim
  box(w, cx - 10, y0 - 1, cz + Z + 6, cx - 3, y0 - 1, cz + Z + 11, WHITE);
  box(w, cx - 9, y0 - 3, cz + Z + 7, cx - 4, y0 - 1, cz + Z + 10, WATER);
  box(w, cx - 9, y0 - 3, cz + Z + 7, cx - 4, y0 - 2, cz + Z + 10, WATER);

  // hedges
  for (let x = cx - 11; x <= cx + 11; x += 4) {
    box(w, x, y0, cz - Z - 3, x + 1, y0 + 1, cz - Z - 3, LEAVES);
  }
}

/* ------------------------------------------------------------------ */
/*  CLASSIC BUNGALOW — planks, porch, chimney, sloped slate roof        */
/* ------------------------------------------------------------------ */
function bungalow(w: World, cx: number, cz: number) {
  const y0 = groundLevel(w, cx, cz, 22);
  const X = 8;
  const Z = 6;

  box(w, cx - X - 2, y0 - 6, cz - Z - 2, cx + X + 2, y0 + 16, cz + Z + 6, AIR);
  box(w, cx - X - 1, y0 - 4, cz - Z - 1, cx + X + 1, y0 - 1, cz + Z + 1, COBBLE);
  box(w, cx - X, y0, cz - Z, cx + X, y0, cz + Z, PLANKS);

  // walls
  box(w, cx - X, y0 + 1, cz - Z, cx + X, y0 + 5, cz - Z, PLANKS);
  box(w, cx - X, y0 + 1, cz + Z, cx + X, y0 + 5, cz + Z, PLANKS);
  box(w, cx - X, y0 + 1, cz - Z, cx - X, y0 + 5, cz + Z, PLANKS);
  box(w, cx + X, y0 + 1, cz - Z, cx + X, y0 + 5, cz + Z, PLANKS);

  // windows + door
  for (let x = cx - X + 2; x <= cx + X - 2; x += 4) {
    box(w, x, y0 + 2, cz - Z, x + 1, y0 + 4, cz - Z, GLASS);
  }
  box(w, cx - 6, y0 + 2, cz + Z, cx - 5, y0 + 4, cz + Z, GLASS);
  box(w, cx + 4, y0 + 2, cz + Z, cx + 5, y0 + 4, cz + Z, GLASS);
  box(w, cx - 1, y0 + 1, cz + Z, cx + 1, y0 + 4, cz + Z, AIR);

  // sloped slate roof
  for (let i = 0; i <= 3; i++) {
    box(
      w,
      cx - X - 1 + i * 2,
      y0 + 6 + i,
      cz - Z - 1 + i,
      cx + X + 1 - i * 2,
      y0 + 6 + i,
      cz + Z + 1 - i,
      SLATE,
    );
  }

  // chimney
  box(w, cx + 4, y0 + 6, cz - 3, cx + 5, y0 + 12, cz - 2, BRICK);

  // porch with log posts and canopy
  box(w, cx - 4, y0, cz + Z + 1, cx + 4, y0, cz + Z + 3, PLANKS);
  box(w, cx - 4, y0 + 1, cz + Z + 3, cx - 4, y0 + 5, cz + Z + 3, LOG);
  box(w, cx + 4, y0 + 1, cz + Z + 3, cx + 4, y0 + 5, cz + Z + 3, LOG);
  box(w, cx - 5, y0 + 6, cz + Z, cx + 5, y0 + 6, cz + Z + 4, SLATE);

  // path + flowerbed
  box(w, cx - 1, y0 - 1, cz + Z + 4, cx + 1, y0 - 1, cz + Z + 12, COBBLE);
  for (let x = cx - 7; x <= cx + 7; x += 3) {
    box(w, x, y0, cz - Z - 2, x + 1, y0 + 1, cz - Z - 2, LEAVES);
  }
}

/* ------------------------------------------------------------------ */
/*  HIGHWAY — four lanes, lane markings, guard rails, lamp posts        */
/* ------------------------------------------------------------------ */
function highway(w: World, cx: number, cz: number) {
  const level = groundLevel(w, cx, cz, 22);
  const startX = Math.max(1, cx - 52);
  const endX = Math.min(WORLD_SIZE - 2, cx + 52);

  for (let x = startX; x <= endX; x++) {
    // solid causeway down to the terrain
    for (let dz = -8; dz <= 8; dz++) {
      const z = cz + dz;
      if (z < 1 || z >= WORLD_SIZE - 1) continue;
      const g = groundLevel(w, x, z, level);
      for (let y = Math.min(g, level); y <= level - 1; y++) {
        w.set(x, y, z, y === level - 1 ? COBBLE : STONE);
      }
      box(w, x, level, z, x, level, z, ASPHALT);
    }
    // lane markings
    box(w, x, level, cz - 6, x, level, cz - 6, WHITE);
    box(w, x, level, cz + 6, x, level, cz + 6, WHITE);
    if (x % 3 === 0) box(w, x, level, cz, x, level, cz, GOLD);
    if (x % 4 === 0) {
      box(w, x, level, cz - 3, x, level, cz - 3, WHITE);
      box(w, x, level, cz + 3, x, level, cz + 3, WHITE);
    }
    // guard rails
    box(w, x, level + 1, cz - 7, x, level + 1, cz - 7, WHITE);
    box(w, x, level + 1, cz + 7, x, level + 1, cz + 7, WHITE);

    // lamp posts
    if ((x - startX) % 18 === 4) {
      box(w, x, level + 1, cz - 8, x, level + 6, cz - 8, LOG);
      box(w, x, level + 6, cz - 7, x, level + 6, cz - 6, GOLD);
      box(w, x, level + 1, cz + 8, x, level + 6, cz + 8, LOG);
      box(w, x, level + 6, cz + 6, x, level + 6, cz + 7, GOLD);
    }
  }
}

export function buildStructure(
  world: World,
  kind: BuildKind,
  cx: number,
  cz: number,
): { x: number; y: number; z: number } {
  const gx = Math.max(16, Math.min(WORLD_SIZE - 17, Math.round(cx)));
  const gz = Math.max(16, Math.min(WORLD_SIZE - 17, Math.round(cz)));
  if (kind === "mansion") mansion(world, gx, gz);
  else if (kind === "bungalow") bungalow(world, gx, gz);
  else highway(world, gx, gz);
  return { x: gx, y: world.heightAt(gx, gz), z: gz };
}
