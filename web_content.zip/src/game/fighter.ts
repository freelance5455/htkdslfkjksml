import * as THREE from 'three';
import { applyPose, buildFighter, type FighterId, type Rig } from './character';
import {
  BLOCK, GUARD, HIT_HEAVY, HIT_LIGHT, KEYS, KNOCK_KEYS, P, WIN_ADA, WIN_LEON, buildMoves, samplePose,
  type Move, type MoveSet, type Pose,
} from './anim';

export interface FighterDef {
  id: FighterId;
  name: string;
  dmg: number;
  atkSpeed: number;
  walk: number;
  run: number;
  regen: number;
  dodgeDist: number;
}

export const DEFS: Record<FighterId, FighterDef> = {
  leon: { id: 'leon', name: 'LEON S. KENNEDY', dmg: 1.12, atkSpeed: 1.0, walk: 2.2, run: 4.1, regen: 20, dodgeDist: 2.1 },
  ada: { id: 'ada', name: 'ADA WONG', dmg: 1.0, atkSpeed: 1.14, walk: 2.5, run: 4.7, regen: 25, dodgeDist: 2.6 },
};

export type FState = 'idle' | 'block' | 'attack' | 'dodge' | 'hit' | 'knock' | 'dead' | 'win';

export interface Ctl {
  mx: number; mz: number; run: boolean;
  punch: boolean; heavy: boolean; kick: boolean; special: boolean; dodge: boolean; block: boolean;
}
export const newCtl = (): Ctl => ({ mx: 0, mz: 0, run: false, punch: false, heavy: false, kick: false, special: false, dodge: false, block: false });

export class Fighter {
  id: FighterId;
  def: FighterDef;
  rig: Rig;
  moves: MoveSet;
  pos = new THREE.Vector3();
  yaw = 0;
  kvel = new THREE.Vector3();
  vel = new THREE.Vector3();
  hp = 100;
  stamina = 100;
  special = 0;
  state: FState = 'idle';
  st = 0;
  move: Move | null = null;
  moveT = 0;
  hitDone = false;
  landed = false;
  atkId = 0;
  buffer: string | null = null;
  bufT = 0;
  chainBtn = '';
  chainN = 0;
  chainT = 9;
  pendingN = 0;
  blockT = 0;
  invuln = 0;
  counterT = 0;
  stun = 0;
  combo = 0;
  comboT = 0;
  flinch = 0;
  stamDelay = 0;
  stamFlash = 0;
  dmgMul = 1;
  hitSide = 1;
  heavyHit = false;
  dodgeDir = new THREE.Vector3();
  dodgeLx = 0;
  dodgeLz = -1;
  cur: Pose = { ...GUARD };
  tmp: Pose = { ...GUARD };
  tgt: Pose = { ...GUARD };
  phase = 0;
  animT = Math.random() * 10;
  winPhase = 0;

  constructor(id: FighterId) {
    this.id = id;
    this.def = DEFS[id];
    this.rig = buildFighter(id);
    this.moves = buildMoves(id);
  }

  reset(x: number, z: number, yaw: number) {
    this.pos.set(x, 0, z);
    this.yaw = yaw;
    this.kvel.set(0, 0, 0);
    this.vel.set(0, 0, 0);
    this.hp = 100;
    this.stamina = 100;
    this.special = 0;
    this.state = 'idle';
    this.st = 0;
    this.move = null;
    this.buffer = null;
    this.invuln = 0;
    this.counterT = 0;
    this.combo = 0;
    this.comboT = 0;
    this.chainT = 9;
    this.flinch = 0;
    this.stamDelay = 0;
    Object.assign(this.cur, GUARD);
  }

  point(limb: Move['limb'], out: THREE.Vector3) {
    const o = limb === 'lh' ? this.rig.lHand : limb === 'rh' ? this.rig.rHand : limb === 'lf' ? this.rig.lF : this.rig.rF;
    return o.getWorldPosition(out);
  }

  // ---- procedural animation ----
  private loco(t: number, out: Pose, dt: number) {
    const sp = this.vel.length();
    Object.assign(out, GUARD);
    const fx = Math.sin(this.yaw), fz = Math.cos(this.yaw);
    const fwd = (this.vel.x * fx + this.vel.z * fz);
    const dirSign = fwd < -0.3 ? -1 : 1;
    if (sp > 0.15) {
      const run = sp > this.def.walk * 1.35;
      const rate = run ? 1.35 : 1.7;
      this.phase += sp * rate * dt;
      const s = Math.sin(this.phase * 2), c = Math.cos(this.phase * 2);
      if (run) {
        out.cr = 0.3 + 0.08 * Math.abs(c);
        out.tx = 0.38; out.ty = 0.1 * c; out.ry = -0.1;
        out.lhx = -s * 1.0 * dirSign; out.rhx = s * 1.0 * dirSign;
        out.lkx = 0.5 + 0.9 * Math.max(0, c * dirSign); out.rkx = 0.5 + 0.9 * Math.max(0, -c * dirSign);
        out.lhz = 0.05; out.rhz = -0.05;
        out.lsx = -0.6 + s * 0.9; out.rsx = -0.6 - s * 0.9;
        out.lsz = 0.1; out.rsz = -0.1;
        out.lex = -1.6; out.rex = -1.6;
        out.by = -0.02 + 0.03 * Math.abs(s);
        out.hx = -0.25;
      } else {
        out.cr = 0.22 + 0.05 * Math.abs(c);
        out.lhx = GUARD.lhx - s * 0.6 * dirSign; out.rhx = GUARD.rhx + s * 0.6 * dirSign;
        out.lkx = GUARD.lkx + 0.55 * Math.max(0, c * dirSign); out.rkx = GUARD.rkx + 0.55 * Math.max(0, -c * dirSign);
        out.by = 0.015 * Math.abs(s);
        out.ty = GUARD.ty + 0.06 * s;
      }
    } else {
      const b = Math.sin(t * 3.1);
      out.cr += b * 0.03;
      out.tx += b * 0.012;
      out.lsx += Math.sin(t * 3.1 + 1) * 0.03;
      out.rsx += Math.sin(t * 3.1 + 2) * 0.03;
      out.lhx += b * 0.02; out.rhx -= b * 0.02;
    }
  }

  animate(dt: number, t: number, hitStopped: boolean) {
    this.animT = t;
    const o = this.tgt;
    let k = 14;
    switch (this.state) {
      case 'idle': this.loco(t, o, dt); k = 13; break;
      case 'block':
        Object.assign(o, BLOCK);
        if (this.flinch > 0) { o.tx += 0.18; o.cr += 0.1; o.lsx += 0.1; }
        k = 20; break;
      case 'attack':
        samplePose(this.move!.keys, this.moveT, o);
        k = 48; break;
      case 'dodge': {
        const lx = this.dodgeLx, lz = this.dodgeLz;
        Object.assign(o, P({
          cr: 0.62, tx: lz < 0 ? -0.2 : 0.5, bx: 0.5 * lz, bz: -0.55 * lx, by: -0.1, hx: -0.15,
          lsx: -0.5, lsz: 0.8, rsx: -0.5, rsz: -0.8, lex: -0.9, rex: -0.9,
          lhx: -0.7 * Math.max(0, lz) - 0.2, rhx: 0.3, lhz: 0.2 + 0.4 * Math.max(0, lx), rhz: -0.2 + 0.4 * Math.min(0, lx),
          lkx: 0.5, rkx: 0.4,
        }));
        k = 30; break;
      }
      case 'hit': {
        Object.assign(o, this.heavyHit ? HIT_HEAVY : HIT_LIGHT);
        o.ty *= this.hitSide; o.tz = 0.15 * this.hitSide;
        k = 36; break;
      }
      case 'knock':
        samplePose(KNOCK_KEYS, this.st, o); k = 40; break;
      case 'dead':
        samplePose(KNOCK_KEYS, Math.min(this.st, 0.9), o); k = 40; break;
      case 'win': {
        const base = this.id === 'leon' ? WIN_LEON : WIN_ADA;
        Object.assign(o, base);
        const b = Math.sin(this.st * 4);
        o.cr += b * 0.03;
        if (this.id === 'leon') { o.rsx += b * 0.15; } else { o.hy += Math.sin(this.st * 1.5) * 0.15; o.lsz += b * 0.1; }
        k = 9; break;
      }
    }
    if (!hitStopped) {
      const f = 1 - Math.exp(-k * dt);
      const c = this.cur;
      for (const key of KEYS) c[key] += (o[key] - c[key]) * f;
    }
    // hit flinch jitter
    applyPose(this.rig, this.cur);
    this.rig.root.position.set(this.pos.x, 0, this.pos.z);
    this.rig.root.rotation.y = this.yaw;
  }

  normaliseSpin() {
    this.cur.bs = 0; this.cur.bx = 0;
  }
}
