import { Humanoid, type Outfit } from './humanoid';
import { WEAPONS, type AmmoType, type WeaponId } from './weapons';
import { RESERVE_CAP } from './weapons';

export interface Slot {
  id: WeaponId | null;
  mag: number;
}

/** Shared base for the player and bots: body, health, inventory and reloads. */
export class Fighter {
  readonly body: Humanoid;
  x = 0;
  y = 0;
  z = 0;
  yaw = 0;
  pitch = 0;
  hp = 100;
  armor = 0;
  armorLv: 0 | 1 | 2 = 0;
  meds = 0;
  alive = true;
  kills = 0;
  slots: Slot[] = [
    { id: null, mag: 0 },
    { id: null, mag: 0 },
  ];
  active = 0;
  reserve: Record<AmmoType, number> = { light: 0, heavy: 0, shell: 0 };
  fireCd = 0;
  reloadT = 0;
  hurtT = 0;

  constructor(
    readonly id: number,
    readonly name: string,
    outfit: Outfit,
  ) {
    this.body = new Humanoid(outfit);
  }

  get weapon(): WeaponId | null {
    return this.slots[this.active].id;
  }

  get slot(): Slot {
    return this.slots[this.active];
  }

  get reloading(): boolean {
    return this.reloadT > 0;
  }

  refreshBody() {
    this.body.setWeapon(this.weapon);
    this.body.setArmor(this.armor > 0);
  }

  tick(dt: number) {
    this.fireCd = Math.max(0, this.fireCd - dt);
    this.hurtT = Math.max(0, this.hurtT - dt);
    if (this.reloadT > 0) {
      this.reloadT -= dt;
      if (this.reloadT <= 0) {
        this.reloadT = 0;
        this.finishReload();
      }
    }
  }

  startReload(): boolean {
    const w = this.weapon;
    if (!w || this.reloadT > 0) return false;
    const def = WEAPONS[w];
    if (this.slot.mag >= def.mag || this.reserve[def.ammo] <= 0) return false;
    this.reloadT = def.reload;
    return true;
  }

  private finishReload() {
    const w = this.weapon;
    if (!w) return;
    const def = WEAPONS[w];
    const take = Math.min(def.mag - this.slot.mag, this.reserve[def.ammo]);
    this.slot.mag += take;
    this.reserve[def.ammo] -= take;
  }

  addAmmo(type: AmmoType, n: number) {
    this.reserve[type] = Math.min(RESERVE_CAP[type], this.reserve[type] + n);
  }

  /** Makes the given slot active and cancels any reload in progress. */
  setActive(i: number) {
    if (i === this.active) return;
    this.active = i;
    this.reloadT = 0;
    this.fireCd = 0.25;
    this.refreshBody();
  }

  /** Copies the simulation position/yaw onto the 3D body. */
  sync() {
    const r = this.body.root;
    r.position.set(this.x, this.y, this.z);
    r.rotation.y = this.yaw;
  }
}
