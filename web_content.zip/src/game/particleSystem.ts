export interface Particle {
  active: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
  maxLife: number;
  alpha: number;
  decay: number;
  shape: 'circle' | 'square' | 'line' | 'star';
  angle: number;
  spin: number;
}

export class ParticlePool {
  private particles: Particle[];
  private maxParticles: number;
  private nextIndex: number = 0;

  constructor(maxParticles: number = 600) {
    this.maxParticles = maxParticles;
    this.particles = new Array(maxParticles);
    for (let i = 0; i < maxParticles; i++) {
      this.particles[i] = {
        active: false,
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        color: '#ffffff',
        size: 3,
        life: 0,
        maxLife: 1,
        alpha: 1,
        decay: 1,
        shape: 'circle',
        angle: 0,
        spin: 0,
      };
    }
  }

  public spawn(
    x: number,
    y: number,
    vx: number,
    vy: number,
    color: string,
    size: number,
    maxLife: number,
    shape: 'circle' | 'square' | 'line' | 'star' = 'circle',
    spin: number = 0
  ) {
    const p = this.particles[this.nextIndex];
    this.nextIndex = (this.nextIndex + 1) % this.maxParticles;

    p.active = true;
    p.x = x;
    p.y = y;
    p.vx = vx;
    p.vy = vy;
    p.color = color;
    p.size = size;
    p.life = maxLife;
    p.maxLife = maxLife;
    p.alpha = 1.0;
    p.decay = 1.0 / maxLife;
    p.shape = shape;
    p.angle = Math.random() * Math.PI * 2;
    p.spin = spin;
  }

  public burst(
    x: number,
    y: number,
    count: number,
    color: string,
    speed: number = 120,
    size: number = 3.5,
    life: number = 0.4
  ) {
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.4;
      const spd = speed * (0.6 + Math.random() * 0.8);
      const vx = Math.cos(angle) * spd;
      const vy = Math.sin(angle) * spd;
      this.spawn(x, y, vx, vy, color, size * (0.7 + Math.random() * 0.6), life * (0.8 + Math.random() * 0.4));
    }
  }

  public slashArc(
    startX: number,
    startY: number,
    angle: number,
    range: number,
    color: string = '#fef08a'
  ) {
    const count = 12;
    for (let i = 0; i < count; i++) {
      const arc = angle - 0.7 + (1.4 * i) / count;
      const dist = range * (0.6 + (i / count) * 0.4);
      const px = startX + Math.cos(arc) * dist;
      const py = startY + Math.sin(arc) * dist;
      this.spawn(
        px,
        py,
        Math.cos(arc) * 30,
        Math.sin(arc) * 30,
        color,
        4,
        0.25,
        'line',
        arc
      );
    }
  }

  public update(dt: number) {
    for (let i = 0; i < this.maxParticles; i++) {
      const p = this.particles[i];
      if (!p.active) continue;

      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
        continue;
      }

      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= 0.95;
      p.vy *= 0.95;
      p.angle += p.spin * dt;
      p.alpha = Math.max(0, p.life / p.maxLife);
    }
  }

  public render(ctx: CanvasRenderingContext2D, cameraX: number, cameraY: number) {
    ctx.save();
    for (let i = 0; i < this.maxParticles; i++) {
      const p = this.particles[i];
      if (!p.active) continue;

      const screenX = p.x - cameraX;
      const screenY = p.y - cameraY;

      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      ctx.strokeStyle = p.color;

      if (p.shape === 'circle') {
        ctx.beginPath();
        ctx.arc(screenX, screenY, p.size * (0.5 + p.alpha * 0.5), 0, Math.PI * 2);
        ctx.fill();
      } else if (p.shape === 'line') {
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        const len = p.size * 2.5;
        ctx.moveTo(screenX - Math.cos(p.angle) * len, screenY - Math.sin(p.angle) * len);
        ctx.lineTo(screenX + Math.cos(p.angle) * len, screenY + Math.sin(p.angle) * len);
        ctx.stroke();
      } else if (p.shape === 'square') {
        ctx.fillRect(screenX - p.size / 2, screenY - p.size / 2, p.size, p.size);
      } else if (p.shape === 'star') {
        ctx.fillRect(screenX - 1, screenY - p.size, 2, p.size * 2);
        ctx.fillRect(screenX - p.size, screenY - 1, p.size * 2, 2);
      }
    }
    ctx.restore();
  }

  public clear() {
    for (let i = 0; i < this.maxParticles; i++) {
      this.particles[i].active = false;
    }
  }
}
