/**
 * Vector Map Data & Geographic Projection Math
 * Equirectangular world map projection (width: 2000, height: 1000)
 */

export const MAP_WIDTH = 2000;
export const MAP_HEIGHT = 1000;

/**
 * Project latitude & longitude to canvas/SVG coordinates (0..2000, 0..1000)
 */
export function projectLatLng(lat: number, lng: number): { x: number; y: number } {
  // Normalize lng from -180..180 to 0..MAP_WIDTH
  const x = ((lng + 180) / 360) * MAP_WIDTH;
  // Normalize lat from -90..90 to MAP_HEIGHT..0
  const y = ((90 - lat) / 180) * MAP_HEIGHT;
  return { x, y };
}

/**
 * Inverse project from map coordinates back to LatLng
 */
export function inverseProject(x: number, y: number): { lat: number; lng: number } {
  const lng = (x / MAP_WIDTH) * 360 - 180;
  const lat = 90 - (y / MAP_HEIGHT) * 180;
  return { lat, lng };
}

/**
 * Curvature calculation for great-circle flight arcs
 * Returns SVG path quadratic or cubic bezier definition
 */
export function getFlightArcPath(
  p1: { x: number; y: number },
  p2: { x: number; y: number }
): { path: string; midPoint: { x: number; y: number }; length: number } {
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const dist = Math.hypot(dx, dy);

  // Normal vector perpendicular to flight direction, pulling upward/arc
  const nx = -dy / (dist || 1);
  const ny = dx / (dist || 1);

  // Flight arc bulge height proportional to distance
  const arcHeight = Math.min(120, Math.max(25, dist * 0.18));

  // Determine arc direction so it bows northwards in the northern hemisphere
  const arcSign = (p1.y + p2.y) / 2 < MAP_HEIGHT * 0.5 ? -1 : 1;
  const cx = (p1.x + p2.x) / 2 + nx * arcHeight * arcSign;
  const cy = (p1.y + p2.y) / 2 + ny * arcHeight * arcSign;

  const path = `M ${p1.x.toFixed(1)} ${p1.y.toFixed(1)} Q ${cx.toFixed(1)} ${cy.toFixed(1)} ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`;
  return { path, midPoint: { x: cx, y: cy }, length: dist };
}

/**
 * Position of aircraft along the quadratic bezier curve at progress t (0..1)
 */
export function getArcPosition(
  p1: { x: number; y: number },
  p2: { x: number; y: number },
  t: number
): { x: number; y: number; angle: number } {
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const dist = Math.hypot(dx, dy);

  const nx = -dy / (dist || 1);
  const ny = dx / (dist || 1);
  const arcHeight = Math.min(120, Math.max(25, dist * 0.18));
  const arcSign = (p1.y + p2.y) / 2 < MAP_HEIGHT * 0.5 ? -1 : 1;

  const cx = (p1.x + p2.x) / 2 + nx * arcHeight * arcSign;
  const cy = (p1.y + p2.y) / 2 + ny * arcHeight * arcSign;

  // Bezier formula B(t) = (1-t)^2 P0 + 2(1-t)t P1 + t^2 P2
  const oneMinusT = 1 - t;
  const x = oneMinusT * oneMinusT * p1.x + 2 * oneMinusT * t * cx + t * t * p2.x;
  const y = oneMinusT * oneMinusT * p1.y + 2 * oneMinusT * t * cy + t * t * p2.y;

  // Tangent derivative B'(t) = 2(1-t)(P1-P0) + 2t(P2-P1)
  const tx = 2 * oneMinusT * (cx - p1.x) + 2 * t * (p2.x - cx);
  const ty = 2 * oneMinusT * (cy - p1.y) + 2 * t * (p2.y - cy);
  const angle = (Math.atan2(ty, tx) * 180) / Math.PI;

  return { x, y, angle };
}

/**
 * World continent and boundary polygons simplified for smooth rendering and high-contrast B&W style.
 * Coordinates are equirectangular projected [x, y].
 */
export interface ContinentOutline {
  id: string;
  name: string;
  path: string;
}

// Crisp, stylized continent polygons for world map in 2000x1000 space
export const WORLD_CONTINENTS: ContinentOutline[] = [
  // North America (including USA & Canada)
  {
    id: 'north-america',
    name: 'North America',
    path: `
      M 370 125 
      L 480 145 L 530 180 L 590 195 L 635 235 L 590 280 L 610 320 
      L 580 340 L 595 380 L 530 405 L 500 460 L 460 480 L 410 470 
      L 350 420 L 305 385 L 290 320 L 260 300 L 255 240 L 285 200 
      L 330 160 Z
    `
  },
  // Greenland
  {
    id: 'greenland',
    name: 'Greenland',
    path: `
      M 690 90 L 780 100 L 795 160 L 730 210 L 670 180 L 665 125 Z
    `
  },
  // South America
  {
    id: 'south-america',
    name: 'South America',
    path: `
      M 530 470 
      L 580 490 L 670 520 L 730 570 L 750 630 L 700 700 L 660 780 
      L 620 880 L 585 860 L 595 780 L 575 700 L 525 610 L 490 530 
      L 505 480 Z
    `
  },
  // Europe
  {
    id: 'europe',
    name: 'Europe',
    path: `
      M 940 180 
      L 1000 170 L 1070 160 L 1100 200 L 1090 260 L 1060 300 L 1010 310 
      L 980 330 L 950 320 L 920 350 L 890 330 L 880 290 L 920 260 
      L 930 210 Z
    `
  },
  // British Isles
  {
    id: 'british-isles',
    name: 'United Kingdom',
    path: `
      M 915 220 L 935 210 L 945 240 L 925 260 L 905 245 Z
    `
  },
  // Africa
  {
    id: 'africa',
    name: 'Africa',
    path: `
      M 930 350 
      L 1030 355 L 1110 375 L 1190 440 L 1220 480 L 1180 540 L 1140 600 
      L 1100 680 L 1060 760 L 1010 740 L 980 650 L 940 550 L 880 480 
      L 865 420 L 895 375 Z
    `
  },
  // Asia
  {
    id: 'asia',
    name: 'Asia',
    path: `
      M 1100 150 
      L 1250 140 L 1400 130 L 1550 150 L 1680 180 L 1750 220 L 1700 280 
      L 1650 310 L 1600 370 L 1550 430 L 1490 480 L 1410 470 L 1350 400 
      L 1290 410 L 1230 460 L 1180 410 L 1170 340 L 1130 310 L 1110 240 
      L 1120 180 Z
    `
  },
  // Japan
  {
    id: 'japan',
    name: 'Japan',
    path: `
      M 1720 280 L 1760 300 L 1780 340 L 1750 380 L 1720 350 L 1715 310 Z
    `
  },
  // Australia & New Zealand
  {
    id: 'australia',
    name: 'Australia',
    path: `
      M 1600 650 
      L 1700 640 L 1780 670 L 1820 740 L 1800 810 L 1720 830 L 1640 820 
      L 1570 760 L 1560 700 Z
    `
  },
  {
    id: 'new-zealand',
    name: 'New Zealand',
    path: `
      M 1890 810 L 1930 830 L 1900 890 L 1870 860 Z
    `
  }
];

// USA Mainland focus coordinates box (for auto-focus / recenter)
export const USA_BOUNDS = {
  minX: 250,
  maxX: 650,
  minY: 180,
  maxY: 460,
  centerX: 380,
  centerY: 300,
  defaultZoom: 3.2
};

// Custom badge & label offsets to avoid clustering in dense metropolitan areas
export const CITY_LABEL_OFFSETS: Record<string, { badgeX: number; badgeY: number; textX: number; textY: number }> = {
  sfo: { badgeX: -42, badgeY: -14, textX: -40, textY: 8 }, // San Francisco to top-left
  lax: { badgeX: 10, badgeY: 10, textX: 20, textY: 26 },    // Los Angeles to bottom-right
  las: { badgeX: 10, badgeY: -16, textX: 10, textY: 14 },
  sea: { badgeX: -40, badgeY: 4, textX: -36, textY: 20 },
  yvr: { badgeX: -40, badgeY: -16, textX: -36, textY: -4 },
  ord: { badgeX: -38, badgeY: -14, textX: -34, textY: 8 },
  jfk: { badgeX: 8, badgeY: -14, textX: 8, textY: 8 },
  yyz: { badgeX: 8, badgeY: -22, textX: 8, textY: -6 },
  cdg: { badgeX: 8, badgeY: 10, textX: 8, textY: 22 },
  fra: { badgeX: 8, badgeY: -16, textX: 8, textY: -4 },
  lhr: { badgeX: -40, badgeY: -14, textX: -36, textY: 6 }
};
