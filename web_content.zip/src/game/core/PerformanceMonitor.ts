export interface PerformanceMetrics {
  fps: number;
  frameTime: number; // in ms
  activeZombies: number;
  drawCalls: number;
  triangles: number;
  memoryMB: number;
  isThrottled: boolean;
}

export class PerformanceMonitor {
  private lastTime = performance.now();
  private frameCount = 0;
  private accumTime = 0;

  public metrics: PerformanceMetrics = {
    fps: 60,
    frameTime: 16.6,
    activeZombies: 0,
    drawCalls: 0,
    triangles: 0,
    memoryMB: 0,
    isThrottled: false,
  };

  public onMetricsUpdate?: (m: PerformanceMetrics) => void;
  public onAutoDegrade?: () => void;

  private spikeCount = 0;

  update(activeZombies: number, info?: { render: { calls: number; triangles: number } }) {
    const now = performance.now();
    const deltaMs = now - this.lastTime;
    this.lastTime = now;

    this.frameCount++;
    this.accumTime += deltaMs;

    this.metrics.frameTime = Math.round(deltaMs * 10) / 10;
    this.metrics.activeZombies = activeZombies;

    if (info) {
      this.metrics.drawCalls = info.render.calls;
      this.metrics.triangles = info.render.triangles;
    }

    // Check memory if performance.memory is supported in browser
    if ((performance as any).memory) {
      this.metrics.memoryMB = Math.round((performance as any).memory.usedJSHeapSize / (1024 * 1024));
    }

    // Frame-time spike detector
    if (deltaMs > 34) { // Below ~30 FPS
      this.spikeCount++;
      if (this.spikeCount > 15) {
        this.metrics.isThrottled = true;
        if (this.onAutoDegrade) this.onAutoDegrade();
        this.spikeCount = 0;
      }
    } else {
      this.spikeCount = Math.max(0, this.spikeCount - 1);
    }

    // Emit metrics every 0.5s
    if (this.accumTime >= 500) {
      this.metrics.fps = Math.round((this.frameCount * 1000) / this.accumTime);
      this.frameCount = 0;
      this.accumTime = 0;

      if (this.onMetricsUpdate) {
        this.onMetricsUpdate({ ...this.metrics });
      }
    }
  }
}
