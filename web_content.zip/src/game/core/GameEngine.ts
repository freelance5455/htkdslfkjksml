import * as THREE from 'three';
import { CollisionSystem } from '../physics/CollisionSystem';
import { MapBuilder } from '../map/MapBuilder';
import { NavigationSystem } from '../ai/NavigationSystem';
import { PlayerController } from '../player/PlayerController';
import { WeaponSystem } from '../weapons/WeaponSystem';
import { ZombieManager } from '../zombies/ZombieManager';
import { ObjectPool } from './ObjectPool';
import { PerformanceMonitor, PerformanceMetrics } from './PerformanceMonitor';
import { BarricadeAndDoorSystem } from '../map/BarricadeAndDoorSystem';
import { SkyAndEnvironment } from '../environment/SkyAndEnvironment';
import { BurningVehiclesSystem } from '../environment/BurningVehiclesSystem';
import { DifficultyManager } from '../difficulty/DifficultyManager';
import { MAP_CATALOG } from '../map/MapRegistry';
import { sound } from '../../audio/SoundEngine';

export type TimeOfDay = 'day' | 'evening' | 'night';
export type QualityPreset = 'low' | 'medium' | 'high' | 'very_high' | 'ultra' | 'custom';

export interface GraphicsSettings {
  preset: QualityPreset;
  resolutionScale: number; // 0.5 - 1.0
  shadowQuality: 'off' | 'low' | 'medium' | 'high' | 'ultra';
  shadowDistance: 'low' | 'medium' | 'high';
  lightingQuality: 'low' | 'medium' | 'high' | 'ultra';
  reflectionQuality: 'off' | 'low' | 'medium' | 'high';
  waterQuality: 'low' | 'medium' | 'high' | 'ultra';
  cloudQuality: 'low' | 'medium' | 'high';
  volumetricEffects: 'off' | 'low' | 'high';
  ambientOcclusion: 'off' | 'low' | 'high';
  particleQuality: 'low' | 'medium' | 'high';
  viewDistance: 'low' | 'medium' | 'high' | 'ultra';
  antiAliasing: 'off' | 'low' | 'high';
  dynamicResolution: boolean;
  fpsLimit: number; // 30 | 40 | 60 | 90 | 120
  shadows: boolean;
  particles: boolean;
  fogDensity: number;
}

export interface KillFeedItem {
  id: string;
  text: string;
  points: number;
  xp: number;
  time: number;
}

export class GameEngine {
  public container: HTMLElement;
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;

  // Subsystems
  public collision: CollisionSystem;
  public mapBuilder: MapBuilder;
  public nav: NavigationSystem;
  public player: PlayerController;
  public weapons: WeaponSystem;
  public zombies: ZombieManager;
  public pool: ObjectPool;
  public perfMonitor: PerformanceMonitor;
  public barricadesAndDoors: BarricadeAndDoorSystem;
  public sky: SkyAndEnvironment;
  public burningVehicles: BurningVehiclesSystem;

  // Economy & XP
  public xp = 0;
  public killFeed: KillFeedItem[] = [];
  public recentKillsInStreak = 0;
  private streakResetTimer = 0;

  // Environment & Lighting
  public timeOfDay: TimeOfDay = 'evening';
  private sunLight!: THREE.DirectionalLight;
  private ambientLight!: THREE.AmbientLight;
  private hemiLight!: THREE.HemisphereLight;

  // Atmosphere & Particles
  private emberParticles: THREE.Points | null = null;
  private emberGeo: THREE.BufferGeometry | null = null;

  // Performance settings (First launch defaults to Low - 360p)
  public graphics: GraphicsSettings = {
    preset: 'low',
    resolutionScale: 0.5, // 360p on Low
    shadowQuality: 'low',
    shadowDistance: 'low',
    lightingQuality: 'medium',
    reflectionQuality: 'low',
    waterQuality: 'low',
    cloudQuality: 'medium',
    volumetricEffects: 'low',
    ambientOcclusion: 'low',
    particleQuality: 'low',
    viewDistance: 'medium',
    antiAliasing: 'low',
    dynamicResolution: true,
    fpsLimit: 60,
    shadows: true,
    particles: true,
    fogDensity: 0.005,
  };

  // State
  private isRunning = false;
  private animationFrameId = 0;
  private lastTime = 0;
  public isPaused = false;
  public currentMapId = 'suburban';

  // Callbacks
  public onMetricsUpdate?: (m: PerformanceMetrics) => void;
  public onKillFeedUpdate?: (items: KillFeedItem[]) => void;
  public onXPUpdate?: (xp: number) => void;

  constructor(container: HTMLElement) {
    this.container = container;

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0f172a);
    this.scene.fog = new THREE.FogExp2(0x0f172a, this.graphics.fogDensity);

    // 2. Camera (far plane 500m for horizon terrain and sky dome)
    this.camera = new THREE.PerspectiveCamera(
      75,
      container.clientWidth / container.clientHeight,
      0.1,
      500
    );
    this.scene.add(this.camera);

    // 3. Renderer with antialiasing
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      stencil: false,
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    container.appendChild(this.renderer.domElement);

    // 4. Collision & Physics
    this.collision = new CollisionSystem();

    // 5. Global Object Pool (Zero GC allocation during gameplay)
    this.pool = new ObjectPool(this.scene);

    // 6. Performance Monitor & Telemetry
    this.perfMonitor = new PerformanceMonitor();
    this.perfMonitor.onMetricsUpdate = (m) => {
      if (this.onMetricsUpdate) this.onMetricsUpdate(m);
    };
    this.perfMonitor.onAutoDegrade = () => {
      if (this.renderer.shadowMap.enabled && this.graphics.preset !== 'low') {
        this.renderer.shadowMap.enabled = false;
      }
    };

    // 7. Map Builder (Always build active map immediately so environment exists)
    this.mapBuilder = new MapBuilder(this.scene, this.collision);
    this.mapBuilder.buildMap(this.currentMapId);

    // 8. Barricade & Working Door System
    this.barricadesAndDoors = new BarricadeAndDoorSystem(this.scene, this.collision);
    this.initMapBarricadesAndDoors();

    // 9. Navigation System (Pre-allocated arrays)
    this.nav = new NavigationSystem(this.collision);

    // 10. Player Controller (Positioned at map spawn)
    this.player = new PlayerController(this.camera, this.collision);
    this.player.position.copy(this.mapBuilder.playerSpawn);
    this.player.reset(this.player.stats.characterId, this.mapBuilder.playerSpawn);

    // 11. Weapon System
    this.weapons = new WeaponSystem(this.camera, this.collision, this.pool);

    // 12. Zombie Manager
    this.zombies = new ZombieManager(
      this.scene,
      this.collision,
      this.nav,
      this.mapBuilder.zombieSpawnPoints,
      this.pool
    );
    this.zombies.barricadeSystem = this.barricadesAndDoors;

    // 13. Sky, Sun, Moon & Animated Clouds
    this.sky = new SkyAndEnvironment(this.scene);

    // 14. Additive Burning Vehicles & Fire System (Requirement 16)
    this.burningVehicles = new BurningVehiclesSystem(this.scene);
    this.initBurningVehicles();

    // Setup base lighting & time of day
    this.setupLighting();
    this.setTimeOfDay('evening');
    this.createAtmosphericEmbers();

    // Start render loop immediately
    this.start();

    // Wire callbacks
    this.zombies.onPlayerHurt = (dmg) => {
      if (this.isPaused) return; // Requirement 26: Player must not take damage while paused
      this.player.takeDamage(dmg);
      if (this.player.stats.health < 70 && !this.player.stats.isDead && Math.random() < 0.35) {
        sound.playCharacterVoice('low_health');
      }
    };

    this.zombies.onZombieKilled = (_zombie, isHeadshot, points) => {
      const earnedXP = isHeadshot ? 50 : 30;
      this.player.addPoints(points);
      this.addXP(earnedXP);
      this.player.stats.kills++;
      if (isHeadshot) this.player.stats.headshots++;
      this.player.notifyStats();

      // Kill Streak processing
      this.recentKillsInStreak++;
      this.streakResetTimer = 3.5;
      if (this.recentKillsInStreak === 3) {
        sound.speakAnnouncement("Triple Kill!");
      } else if (this.recentKillsInStreak === 5) {
        sound.speakAnnouncement("Kill streak!");
      } else if (this.recentKillsInStreak === 10) {
        sound.speakAnnouncement("Rampage! Unstoppable!");
      }

      // Add to kill feed
      this.addKillFeed(isHeadshot ? 'HEADSHOT ELIMINATION' : 'ZOMBIE ELIMINATED', points, earnedXP);

      const m = MAP_CATALOG.find(item => item.id === this.currentMapId);
      if (m) {
        const best = parseInt(localStorage.getItem(m.bestWaveKey) || '0', 10);
        if (this.zombies.currentWave > best) {
          localStorage.setItem(m.bestWaveKey, this.zombies.currentWave.toString());
        }
      }
    };

    this.zombies.onWaveChange = (w, intermission) => {
      if (intermission) {
        sound.speakAnnouncement("Wave complete!");
        this.addXP(100);
      } else {
        sound.speakAnnouncement(`Wave ${w}! Survive!`);
      }
    };

    // Grenade & Melee wiring
    this.player.onGrenadeExplode = (pos, radius, dmg) => {
      this.zombies.applyAreaDamage(pos, radius, dmg);
      const flash = new THREE.PointLight(0xf97316, 8, 16);
      flash.position.copy(pos);
      this.scene.add(flash);
      setTimeout(() => this.scene.remove(flash), 150);
    };

    this.player.onMeleeHit = (pos, dmg) => {
      this.zombies.applyMeleeDamage(pos, 2.5, dmg);
    };

    window.addEventListener('resize', this.onResize);
  }

  public isInitialized = false;

  // Asynchronous phased asset initialization (Requirement 2 & 3)
  async initAssetsAsync(onProgress?: (stage: string, pct: number) => void): Promise<void> {
    if (this.isInitialized) {
      onProgress?.('INITIALIZING...', 20);
      await new Promise(r => setTimeout(r, 40));
      onProgress?.('LOADING ENVIRONMENT...', 50);
      await new Promise(r => setTimeout(r, 40));
      onProgress?.('LOADING WEAPONS...', 75);
      await new Promise(r => setTimeout(r, 40));
      onProgress?.('READY', 100);
      return;
    }

    // STAGE 1: INITIALIZING...
    onProgress?.('INITIALIZING...', 14);
    await new Promise(r => setTimeout(r, 450));

    // STAGE 2: LOADING ENVIRONMENT...
    onProgress?.('LOADING ENVIRONMENT...', 34);
    this.mapBuilder.buildMap(this.currentMapId);
    this.initMapBarricadesAndDoors();
    await new Promise(r => setTimeout(r, 650));

    // STAGE 3: LOADING CHARACTERS...
    onProgress?.('LOADING CHARACTERS...', 54);
    this.player.position.copy(this.mapBuilder.playerSpawn);
    this.player.reset(this.player.stats.characterId, this.mapBuilder.playerSpawn);
    await new Promise(r => setTimeout(r, 550));

    // STAGE 4: LOADING WEAPONS...
    onProgress?.('LOADING WEAPONS...', 74);
    this.weapons.equipWeapon(this.weapons.activeWeapon.def.id);
    await new Promise(r => setTimeout(r, 550));

    // STAGE 5: LOADING ZOMBIE SYSTEM...
    onProgress?.('LOADING ZOMBIE SYSTEM...', 88);
    this.nav = new NavigationSystem(this.collision);
    this.zombies.setSpawnPoints(this.mapBuilder.zombieSpawnPoints);
    this.zombies.setDifficulty(DifficultyManager.get());
    await new Promise(r => setTimeout(r, 650));

    // STAGE 6: OPTIMIZING...
    onProgress?.('OPTIMIZING...', 98);
    this.createAtmosphericEmbers();
    this.setTimeOfDay('evening');
    this.start();
    await new Promise(r => setTimeout(r, 550));

    // STAGE 7: READY
    onProgress?.('READY', 100);
    await new Promise(r => setTimeout(r, 400));
    this.isInitialized = true;
  }

  // Setup default barricades and doors on current map
  private initMapBarricadesAndDoors() {
    this.barricadesAndDoors.clear();

    // Default barricadable windows on map
    this.barricadesAndDoors.addBarricade('barricade_1', new THREE.Vector3(-14, 0, -18), 0);
    this.barricadesAndDoors.addBarricade('barricade_2', new THREE.Vector3(14, 0, -18), 0);
    this.barricadesAndDoors.addBarricade('barricade_3', new THREE.Vector3(0, 0, -32), 0);

    // Default functional door at building entrance
    this.barricadesAndDoors.addDoor('door_main', new THREE.Vector3(0, 0, -10), 0);
  }

  // Requirement 16: Additive burning vehicles with animated fire & smoke
  private initBurningVehicles() {
    this.burningVehicles.clear();
    if (this.currentMapId === 'suburban') {
      this.burningVehicles.addBurningEffect(-15, 0.6, -8);
      this.burningVehicles.addBurningEffect(14, 0.8, 1.5);
    } else if (this.currentMapId === 'military') {
      this.burningVehicles.addBurningEffect(-16, 0.9, -6);
    } else if (this.currentMapId === 'night_city') {
      this.burningVehicles.addBurningEffect(-3, 1.6, -4);
      this.burningVehicles.addBurningEffect(-12, 0.8, 10);
    } else if (this.currentMapId === 'desert_outpost') {
      this.burningVehicles.addBurningEffect(-10, 0.9, 12);
    } else if (this.currentMapId === 'flooded_suburb') {
      this.burningVehicles.addBurningEffect(-8, 0.6, 12);
    } else if (this.currentMapId === 'factory') {
      this.burningVehicles.addBurningEffect(-6, 0.6, 18);
    } else if (this.currentMapId === 'hospital') {
      this.burningVehicles.addBurningEffect(12, 1.1, 18);
    }
  }

  addXP(amount: number) {
    this.xp += amount;
    if (this.onXPUpdate) this.onXPUpdate(this.xp);
  }

  addKillFeed(text: string, points: number, xp: number) {
    const item: KillFeedItem = {
      id: `kill_${Date.now()}_${Math.random()}`,
      text,
      points,
      xp,
      time: performance.now(),
    };
    this.killFeed.unshift(item);
    if (this.killFeed.length > 5) this.killFeed.pop();
    if (this.onKillFeedUpdate) this.onKillFeedUpdate([...this.killFeed]);
  }

  loadMap(mapId: string) {
    this.currentMapId = mapId;
    this.zombies.clearAllZombies();
    this.pool.clear();

    this.mapBuilder.buildMap(mapId);
    this.initMapBarricadesAndDoors();
    this.initBurningVehicles();

    this.nav = new NavigationSystem(this.collision);
    this.zombies = new ZombieManager(
      this.scene,
      this.collision,
      this.nav,
      this.mapBuilder.zombieSpawnPoints,
      this.pool
    );
    this.zombies.setDifficulty(DifficultyManager.get());
    this.zombies.barricadeSystem = this.barricadesAndDoors;

    this.zombies.onPlayerHurt = (dmg) => {
      if (this.isPaused) return;
      this.player.takeDamage(dmg);
    };

    this.zombies.onZombieKilled = (_zombie, isHeadshot, points) => {
      const earnedXP = isHeadshot ? 50 : 30;
      this.player.addPoints(points);
      this.addXP(earnedXP);
      this.player.stats.kills++;
      if (isHeadshot) this.player.stats.headshots++;
      this.player.notifyStats();

      this.recentKillsInStreak++;
      this.streakResetTimer = 3.5;
      if (this.recentKillsInStreak === 3) sound.speakAnnouncement("Triple Kill!");
      else if (this.recentKillsInStreak === 5) sound.speakAnnouncement("Kill streak!");

      this.addKillFeed(isHeadshot ? 'HEADSHOT ELIMINATION' : 'ZOMBIE ELIMINATED', points, earnedXP);

      const m = MAP_CATALOG.find(item => item.id === this.currentMapId);
      if (m) {
        const best = parseInt(localStorage.getItem(m.bestWaveKey) || '0', 10);
        if (this.zombies.currentWave > best) {
          localStorage.setItem(m.bestWaveKey, this.zombies.currentWave.toString());
        }
      }
    };

    this.player.position.copy(this.mapBuilder.playerSpawn);
    this.player.reset(this.player.stats.characterId, this.mapBuilder.playerSpawn);

    const mapInfo = MAP_CATALOG.find(m => m.id === mapId);
    if (mapInfo) {
      this.setTimeOfDay(mapInfo.defaultTime);
    }
  }

  // Pre-flight Map Validation (Requirement 16: Never load into a black void)
  verifyMapLoaded(expectedMapId: string): { success: boolean; errors: string[] } {
    const errors: string[] = [];

    if (this.currentMapId !== expectedMapId) {
      errors.push(`Loaded map mismatch: expected ${expectedMapId}, got ${this.currentMapId}`);
    }

    if (this.mapBuilder.mapMeshesCount < 15) {
      errors.push(`Insufficient map geometry: only ${this.mapBuilder.mapMeshesCount} meshes loaded`);
    }

    if (this.collision.getColliders().length < 10) {
      errors.push('Collision boundaries not generated');
    }

    if (!this.mapBuilder.playerSpawn) {
      errors.push('Player spawn point missing');
    }

    if (this.mapBuilder.zombieSpawnPoints.length < 3) {
      errors.push('Zombie spawn locations missing');
    }

    if (!this.ambientLight || this.ambientLight.intensity < 0.2) {
      errors.push('Map lighting under-illuminated');
    }

    if (errors.length > 0) {
      console.warn('[Map Validation Failed]', errors);
      // Auto recovery: force re-run buildMap
      this.mapBuilder.buildMap(expectedMapId);
      this.setTimeOfDay(MAP_CATALOG.find(m => m.id === expectedMapId)?.defaultTime || 'evening');
      return { success: false, errors };
    }

    return { success: true, errors: [] };
  }

  private setupLighting() {
    this.ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    this.scene.add(this.ambientLight);

    this.hemiLight = new THREE.HemisphereLight(0xffffff, 0x334155, 0.5);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff7ed, 1.5);
    this.sunLight.position.set(30, 45, 25);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.width = 1024;
    this.sunLight.shadow.mapSize.height = 1024;
    this.sunLight.shadow.camera.near = 0.5;
    this.sunLight.shadow.camera.far = 120;
    const d = 45;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.0005;
    this.scene.add(this.sunLight);
  }

  setTimeOfDay(time: TimeOfDay) {
    this.timeOfDay = time;
    if (this.sky) this.sky.setTimeOfDay(time);

    if (time === 'day') {
      this.scene.background = new THREE.Color(0x38bdf8); // Sky blue
      this.scene.fog = new THREE.FogExp2(0x93c5fd, 0.002);
      this.ambientLight.color.setHex(0xffffff);
      this.ambientLight.intensity = 0.9;
      this.hemiLight.color.setHex(0xffffff);
      this.hemiLight.groundColor.setHex(0x475569);
      this.hemiLight.intensity = 0.75;
      this.sunLight.color.setHex(0xfffbeb);
      this.sunLight.intensity = 2.4;
      this.sunLight.position.set(45, 75, 40);

      for (const lamp of this.mapBuilder.streetLamps) {
        lamp.light.intensity = 0.3;
      }
    } else if (time === 'evening') {
      this.scene.background = new THREE.Color(0x431407); // Sunset amber
      this.scene.fog = new THREE.FogExp2(0x7c2d12, 0.003);
      this.ambientLight.color.setHex(0xfdba74);
      this.ambientLight.intensity = 0.8;
      this.hemiLight.color.setHex(0xfdba74);
      this.hemiLight.groundColor.setHex(0x27272a);
      this.hemiLight.intensity = 0.65;
      this.sunLight.color.setHex(0xf97316);
      this.sunLight.intensity = 2.0;
      this.sunLight.position.set(65, 35, 45);

      for (const lamp of this.mapBuilder.streetLamps) {
        lamp.light.intensity = 1.8;
      }
    } else if (time === 'night') {
      // Clear moonlit night with strong ambient illumination so environment is clearly visible
      this.scene.background = new THREE.Color(0x0f172a); // Slate navy (never pitch black!)
      this.scene.fog = new THREE.FogExp2(0x1e293b, 0.004);
      this.ambientLight.color.setHex(0x94a3b8);
      this.ambientLight.intensity = 0.7; // Bright readable ambient light
      this.hemiLight.color.setHex(0x60a5fa);
      this.hemiLight.groundColor.setHex(0x18181b);
      this.hemiLight.intensity = 0.6;
      this.sunLight.color.setHex(0x38bdf8); // Moonlight
      this.sunLight.intensity = 1.6;
      this.sunLight.position.set(-45, 70, -40);

      for (const lamp of this.mapBuilder.streetLamps) {
        lamp.light.intensity = 2.8;
      }
    }
  }

  private createAtmosphericEmbers() {
    const particleCount = 120;
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 80;
      positions[i * 3 + 1] = Math.random() * 12;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 80;
    }

    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.emberGeo = geo;

    const mat = new THREE.PointsMaterial({
      color: 0xf97316,
      size: 0.16,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
    });

    this.emberParticles = new THREE.Points(geo, mat);
    this.scene.add(this.emberParticles);
  }

  applyGraphics(settings: Partial<GraphicsSettings>) {
    this.graphics = { ...this.graphics, ...settings };

    // Apply Preset defaults if a preset was chosen
    if (settings.preset) {
      const p = settings.preset;
      if (p === 'low') {
        this.graphics.resolutionScale = 0.5; // 360p on Low
        this.graphics.shadowQuality = 'low';
        this.graphics.shadowDistance = 'low';
        this.graphics.lightingQuality = 'medium';
        this.graphics.reflectionQuality = 'low';
        this.graphics.waterQuality = 'low';
        this.graphics.cloudQuality = 'medium';
        this.graphics.volumetricEffects = 'low';
        this.graphics.ambientOcclusion = 'low';
        this.graphics.particleQuality = 'low';
        this.graphics.viewDistance = 'medium';
        this.graphics.antiAliasing = 'off';
        this.graphics.fpsLimit = 60;
        this.graphics.fogDensity = 0.005;
      } else if (p === 'medium') {
        this.graphics.resolutionScale = 0.7; // 480p on Medium
        this.graphics.shadowQuality = 'medium';
        this.graphics.shadowDistance = 'medium';
        this.graphics.lightingQuality = 'medium';
        this.graphics.reflectionQuality = 'medium';
        this.graphics.waterQuality = 'medium';
        this.graphics.cloudQuality = 'medium';
        this.graphics.volumetricEffects = 'medium' as any;
        this.graphics.ambientOcclusion = 'low';
        this.graphics.particleQuality = 'medium';
        this.graphics.viewDistance = 'medium';
        this.graphics.antiAliasing = 'low';
        this.graphics.fpsLimit = 60;
        this.graphics.fogDensity = 0.004;
      } else if (p === 'high') {
        this.graphics.resolutionScale = 0.85; // 720p on High
        this.graphics.shadowQuality = 'high';
        this.graphics.shadowDistance = 'medium';
        this.graphics.lightingQuality = 'high';
        this.graphics.reflectionQuality = 'medium';
        this.graphics.waterQuality = 'high';
        this.graphics.cloudQuality = 'high';
        this.graphics.volumetricEffects = 'high';
        this.graphics.ambientOcclusion = 'high';
        this.graphics.particleQuality = 'high';
        this.graphics.viewDistance = 'high';
        this.graphics.antiAliasing = 'high';
        this.graphics.fpsLimit = 60;
        this.graphics.fogDensity = 0.012;
      } else if (p === 'very_high' || p === 'ultra') {
        this.graphics.resolutionScale = 1.0;
        this.graphics.shadowQuality = 'ultra';
        this.graphics.shadowDistance = 'high';
        this.graphics.lightingQuality = 'ultra';
        this.graphics.reflectionQuality = 'high';
        this.graphics.waterQuality = 'ultra';
        this.graphics.cloudQuality = 'high';
        this.graphics.volumetricEffects = 'high';
        this.graphics.ambientOcclusion = 'high';
        this.graphics.particleQuality = 'high';
        this.graphics.viewDistance = 'ultra';
        this.graphics.antiAliasing = 'high';
        this.graphics.fpsLimit = 120;
        this.graphics.fogDensity = 0.008;
      }
    }

    // 1. Resolution Scale
    const ratio = Math.max(0.5, Math.min(2.0, window.devicePixelRatio * this.graphics.resolutionScale));
    this.renderer.setPixelRatio(ratio);

    // 2. Shadows Quality & Distance
    if (this.graphics.shadowQuality === 'off') {
      this.renderer.shadowMap.enabled = false;
      this.sunLight.castShadow = false;
    } else {
      this.renderer.shadowMap.enabled = true;
      this.sunLight.castShadow = true;

      if (this.graphics.shadowQuality === 'low') {
        this.renderer.shadowMap.type = THREE.BasicShadowMap;
        this.sunLight.shadow.mapSize.set(512, 512);
      } else if (this.graphics.shadowQuality === 'medium') {
        this.renderer.shadowMap.type = THREE.PCFShadowMap;
        this.sunLight.shadow.mapSize.set(1024, 1024);
      } else if (this.graphics.shadowQuality === 'high') {
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.sunLight.shadow.mapSize.set(1024, 1024);
      } else {
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.sunLight.shadow.mapSize.set(2048, 2048);
      }

      const distD = this.graphics.shadowDistance === 'low' ? 25 : this.graphics.shadowDistance === 'medium' ? 45 : 65;
      this.sunLight.shadow.camera.left = -distD;
      this.sunLight.shadow.camera.right = distD;
      this.sunLight.shadow.camera.top = distD;
      this.sunLight.shadow.camera.bottom = -distD;
      this.sunLight.shadow.camera.updateProjectionMatrix();
    }

    // 3. View Distance & Fog
    const viewFar = this.graphics.viewDistance === 'low' ? 90 : this.graphics.viewDistance === 'medium' ? 150 : this.graphics.viewDistance === 'high' ? 220 : 320;
    this.camera.far = viewFar;
    this.camera.updateProjectionMatrix();

    if (this.scene.fog) {
      (this.scene.fog as THREE.FogExp2).density = this.graphics.fogDensity;
    }

    // 4. Sky, Rays & Clouds
    if (this.sky) {
      const p = this.graphics.preset === 'ultra' ? 'very_high' : this.graphics.preset;
      this.sky.updateQuality(p);
      if (this.graphics.volumetricEffects === 'off') {
        this.sky.sunGlow.visible = false;
        this.sky.moonGlow.visible = false;
      }
    }

    this.onResize();
  }

  // Handle interaction with nearest station, barricade, or door
  interactWithNearest(): boolean {
    const pPos = this.player.position;

    // 1. Check Barricade Repair
    const repair = this.barricadesAndDoors.repairNearestBarricade(pPos);
    if (repair.success) {
      this.player.addPoints(repair.points);
      this.addXP(repair.xp);
      this.addKillFeed('BARRICADE REPAIRED', repair.points, repair.xp);
      if (Math.random() < 0.6) {
        sound.playCharacterVoice('barricade_repair');
      }
      return true;
    }

    // 2. Check Interactive Door
    if (this.barricadesAndDoors.toggleNearestDoor(pPos)) {
      return true;
    }

    // 3. Check Wall Buy / Mystery Box / Ammo Crate
    for (const ent of this.mapBuilder.interactiveEntities) {
      const d = pPos.distanceTo(ent.position);
      if (d <= ent.radius) {
        if (this.player.spendPoints(ent.cost)) {
          sound.playBuySound();
          if (ent.type === 'ammocrate') {
            this.weapons.refillAmmo();
            this.player.stats.grenades = Math.min(4, this.player.stats.grenades + 2);
            this.player.notifyStats();
          } else if (ent.id === 'wallbuy_shotgun') {
            this.weapons.setWeapon('primary', 'shotgun');
          } else if (ent.id === 'wallbuy_sniper') {
            this.weapons.setWeapon('primary', 'sniper');
          } else if (ent.id === 'wallbuy_smg') {
            this.weapons.setWeapon('primary', 'smg');
          } else if (ent.type === 'mysterybox') {
            const pool = ['rifle', 'ar2', 'shotgun', 'smg', 'smg2', 'revolver', 'sniper', 'dmr', 'lmg', 'raygun'];
            const chosen = pool[Math.floor(Math.random() * pool.length)];

            // Physical animated box opening (Requirement 11 & 12)
            if (this.mapBuilder.mysteryBoxLid) {
              this.mapBuilder.mysteryBoxLid.rotation.x = -Math.PI / 2.2;
            }

            this.weapons.setWeapon('primary', chosen);
            if (chosen === 'raygun') {
              sound.speakAnnouncement("Quantum Ray Gun acquired!");
            }

            setTimeout(() => {
              if (this.mapBuilder.mysteryBoxLid) {
                this.mapBuilder.mysteryBoxLid.rotation.x = 0;
              }
            }, 5000);
          }
          if (Math.random() < 0.7) {
            sound.playCharacterVoice('buy_weapon');
          }
          return true;
        } else {
          sound.playDryFire();
          return false;
        }
      }
    }
    return false;
  }

  private onResize = () => {
    if (!this.container) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.lastTime = performance.now();
    this.animate();
  }

  stop() {
    this.isRunning = false;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
  }

  private animate = () => {
    if (!this.isRunning) return;
    this.animationFrameId = requestAnimationFrame(this.animate);

    const now = performance.now();
    const delta = Math.min((now - this.lastTime) / 1000, 0.05);
    this.lastTime = now;

    // Requirement 26: GAMEPLAY MUST PAUSE COMPLETELY
    if (!this.isPaused) {
      this.player.update(delta, this.mapBuilder.interactiveEntities, this.scene);

      const isMoving = this.player.isPlayerMoving();
      const isSprinting = this.player.isPlayerSprinting();
      this.weapons.update(delta, isMoving, isSprinting);

      this.zombies.update(delta, this.player.position);
      this.barricadesAndDoors.update(delta, this.player.position);

      this.pool.update(delta);
      if (this.sky) this.sky.update(delta);
      if (this.burningVehicles) this.burningVehicles.update(delta);

      // Streak timer decay
      if (this.streakResetTimer > 0) {
        this.streakResetTimer -= delta;
        if (this.streakResetTimer <= 0) {
          this.recentKillsInStreak = 0;
        }
      }

      // Kill feed expiration
      if (this.killFeed.length > 0) {
        const fresh = this.killFeed.filter(item => now - item.time < 3500);
        if (fresh.length !== this.killFeed.length) {
          this.killFeed = fresh;
          if (this.onKillFeedUpdate) this.onKillFeedUpdate([...this.killFeed]);
        }
      }

      if (this.emberGeo && this.emberParticles) {
        const positions = this.emberGeo.attributes.position.array as Float32Array;
        for (let i = 0; i < positions.length; i += 3) {
          positions[i + 1] += delta * 0.8;
          positions[i] += Math.sin(now * 0.001 + i) * delta * 0.4;
          if (positions[i + 1] > 12) {
            positions[i + 1] = 0.2;
          }
        }
        this.emberGeo.attributes.position.needsUpdate = true;
      }
    }

    this.renderer.render(this.scene, this.camera);
    this.perfMonitor.update(this.zombies.zombies.filter(z => !z.isDead).length, this.renderer.info);
  };

  destroy() {
    this.stop();
    window.removeEventListener('resize', this.onResize);
    this.pool.destroy();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
  }
}
