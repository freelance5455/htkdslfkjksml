import * as THREE from 'three';

// Reusable Shared Geometries and Materials
const bloodGeo = new THREE.BoxGeometry(0.07, 0.07, 0.07);
const bloodMat = new THREE.MeshBasicMaterial({ color: 0x991b1b });

const shellGeo = new THREE.CylinderGeometry(0.008, 0.008, 0.035, 6);
const shellMat = new THREE.MeshStandardMaterial({ color: 0xeab308, metalness: 0.9, roughness: 0.2 });

const smokeGeo = new THREE.DodecahedronGeometry(0.08, 0);
const smokeMat = new THREE.MeshBasicMaterial({
  color: 0xcccccc,
  transparent: true,
  opacity: 0.45,
  depthWrite: false,
});

export interface PooledParticle {
  mesh: THREE.Mesh;
  velocity: THREE.Vector3;
  life: number;
  maxLife: number;
  active: boolean;
  type: 'blood' | 'shell' | 'smoke';
  rotSpeed?: THREE.Vector3;
}

export class ObjectPool {
  private scene: THREE.Scene;

  // Pools
  private bloodPool: PooledParticle[] = [];
  private shellPool: PooledParticle[] = [];
  private smokePool: PooledParticle[] = [];

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.initPools();
  }

  private initPools() {
    // 1. Blood particles (120 pooled items)
    for (let i = 0; i < 120; i++) {
      const mesh = new THREE.Mesh(bloodGeo, bloodMat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.bloodPool.push({
        mesh,
        velocity: new THREE.Vector3(),
        life: 0,
        maxLife: 0.6,
        active: false,
        type: 'blood',
      });
    }

    // 2. Shell casings (35 pooled items)
    for (let i = 0; i < 35; i++) {
      const mesh = new THREE.Mesh(shellGeo, shellMat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.shellPool.push({
        mesh,
        velocity: new THREE.Vector3(),
        rotSpeed: new THREE.Vector3(),
        life: 0,
        maxLife: 1.2,
        active: false,
        type: 'shell',
      });
    }

    // 3. Smoke puffs (30 pooled items)
    for (let i = 0; i < 30; i++) {
      const mesh = new THREE.Mesh(smokeGeo, smokeMat.clone());
      mesh.visible = false;
      this.scene.add(mesh);
      this.smokePool.push({
        mesh,
        velocity: new THREE.Vector3(),
        life: 0,
        maxLife: 0.5,
        active: false,
        type: 'smoke',
      });
    }
  }

  // Spawn blood burst without allocations
  spawnBlood(pos: THREE.Vector3, count: number = 8) {
    let spawned = 0;
    for (let i = 0; i < this.bloodPool.length && spawned < count; i++) {
      const p = this.bloodPool[i];
      if (!p.active) {
        p.active = true;
        p.life = 0.4 + Math.random() * 0.3;
        p.maxLife = p.life;
        p.mesh.position.copy(pos);
        p.mesh.visible = true;
        p.mesh.scale.setScalar(0.8 + Math.random() * 0.6);

        p.velocity.set(
          (Math.random() - 0.5) * 3.5,
          Math.random() * 2.5 + 0.8,
          (Math.random() - 0.5) * 3.5
        );
        spawned++;
      }
    }
  }

  // Spawn shell casing without allocations
  spawnShell(pos: THREE.Vector3, dir: THREE.Vector3) {
    for (let i = 0; i < this.shellPool.length; i++) {
      const s = this.shellPool[i];
      if (!s.active) {
        s.active = true;
        s.life = 1.0;
        s.maxLife = 1.0;
        s.mesh.position.copy(pos);
        s.mesh.visible = true;

        s.velocity.copy(dir);
        if (s.rotSpeed) {
          s.rotSpeed.set(
            (Math.random() - 0.5) * 16,
            (Math.random() - 0.5) * 16,
            (Math.random() - 0.5) * 16
          );
        }
        break;
      }
    }
  }

  // Spawn smoke puff at weapon barrel
  spawnSmoke(pos: THREE.Vector3, dir: THREE.Vector3) {
    for (let i = 0; i < this.smokePool.length; i++) {
      const sm = this.smokePool[i];
      if (!sm.active) {
        sm.active = true;
        sm.life = 0.45;
        sm.maxLife = 0.45;
        sm.mesh.position.copy(pos);
        sm.mesh.visible = true;
        sm.mesh.scale.setScalar(0.4);
        (sm.mesh.material as THREE.MeshBasicMaterial).opacity = 0.4;

        sm.velocity.copy(dir).multiplyScalar(1.2).add(new THREE.Vector3(0, 0.4, 0));
        break;
      }
    }
  }

  // Update all pooled particles efficiently
  update(delta: number) {
    // 1. Blood
    for (let i = 0; i < this.bloodPool.length; i++) {
      const b = this.bloodPool[i];
      if (b.active) {
        b.life -= delta;
        if (b.life <= 0) {
          b.active = false;
          b.mesh.visible = false;
        } else {
          b.velocity.y -= 12 * delta; // Gravity
          b.mesh.position.addScaledVector(b.velocity, delta);
        }
      }
    }

    // 2. Shells
    for (let i = 0; i < this.shellPool.length; i++) {
      const s = this.shellPool[i];
      if (s.active) {
        s.life -= delta;
        if (s.life <= 0) {
          s.active = false;
          s.mesh.visible = false;
        } else {
          s.velocity.y -= 9.8 * delta;
          s.mesh.position.addScaledVector(s.velocity, delta);
          if (s.rotSpeed) {
            s.mesh.rotation.x += s.rotSpeed.x * delta;
            s.mesh.rotation.y += s.rotSpeed.y * delta;
            s.mesh.rotation.z += s.rotSpeed.z * delta;
          }
        }
      }
    }

    // 3. Smoke
    for (let i = 0; i < this.smokePool.length; i++) {
      const sm = this.smokePool[i];
      if (sm.active) {
        sm.life -= delta;
        if (sm.life <= 0) {
          sm.active = false;
          sm.mesh.visible = false;
        } else {
          sm.mesh.position.addScaledVector(sm.velocity, delta);
          const progress = 1 - sm.life / sm.maxLife;
          sm.mesh.scale.setScalar(0.4 + progress * 1.2);
          (sm.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.45 * (1 - progress));
        }
      }
    }
  }

  clear() {
    for (const b of this.bloodPool) {
      b.active = false;
      b.mesh.visible = false;
    }
    for (const s of this.shellPool) {
      s.active = false;
      s.mesh.visible = false;
    }
    for (const sm of this.smokePool) {
      sm.active = false;
      sm.mesh.visible = false;
    }
  }

  destroy() {
    this.clear();
    for (const b of this.bloodPool) this.scene.remove(b.mesh);
    for (const s of this.shellPool) this.scene.remove(s.mesh);
    for (const sm of this.smokePool) this.scene.remove(sm.mesh);
    this.bloodPool = [];
    this.shellPool = [];
    this.smokePool = [];
  }
}
