import { CONTRACT, EXTEND, HOLD, RELAX, JOINT_IDS, PART_INDEX } from './physics';

export interface Preset {
  id: string;
  label: string;
  icon: string;
  desc: string;
  map: Record<string, number>;
  all?: number;
}

const C = CONTRACT;
const E = EXTEND;

export const PRESETS: Preset[] = [
  { id: 'hold', label: 'Hold', icon: '🧍', desc: 'Lock every joint', map: {}, all: HOLD },
  { id: 'relax', label: 'Ragdoll', icon: '🫠', desc: 'Relax every joint', map: {}, all: RELAX },
  { id: 'lunge', label: 'Lunge', icon: '🏃', desc: 'Push off & lean forward', map: { thighR: C, shinR: C, thighL: E, shinL: E, footL: E, abs: C } },
  { id: 'punch', label: 'Punch', icon: '👊', desc: 'Straight punch with the near arm', map: { uarmR: C, farmR: E, abs: C, chest: E } },
  { id: 'hook', label: 'Hook', icon: '🥊', desc: 'Swing both arms forward', map: { uarmR: C, farmR: E, uarmL: C, farmL: E, abs: C } },
  { id: 'kick', label: 'Kick', icon: '🦵', desc: 'Front kick with the near leg', map: { thighR: C, shinR: E, footR: E, abs: E, chest: E } },
  { id: 'crouch', label: 'Crouch', icon: '🧎', desc: 'Bend the legs', map: { thighR: C, thighL: C, shinR: C, shinL: C, footR: C, footL: C } },
  { id: 'jump', label: 'Jump', icon: '⬆️', desc: 'Explode the legs upward', map: { thighR: E, thighL: E, shinR: E, shinL: E, footR: E, footL: E } },
  { id: 'guard', label: 'Guard', icon: '🛡️', desc: 'Raise arms to protect the head', map: { uarmR: C, uarmL: C, farmR: C, farmL: C } },
];

export function presetStates(p: Preset): number[] {
  const arr: number[] = [];
  for (let i = 0; i < 20; i++) arr[i] = HOLD;
  if (p.all !== undefined) for (const i of JOINT_IDS) arr[i] = p.all;
  for (const [id, st] of Object.entries(p.map)) arr[PART_INDEX[id]] = st;
  return arr;
}
