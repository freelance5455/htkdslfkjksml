import * as THREE from 'three';

export interface CollisionBox {
  id: string;
  min: THREE.Vector3;
  max: THREE.Vector3;
  type: 'wall' | 'building' | 'fence' | 'vehicle' | 'prop' | 'barrier' | 'boundary' | 'stair' | 'floor';
  isWalkable?: boolean;
  isStair?: boolean;
}

export interface RayHit {
  distance: number;
  point: THREE.Vector3;
  normal: THREE.Vector3;
  collider?: CollisionBox;
}

export class CollisionSystem {
  private colliders: CollisionBox[] = [];
  private mapBounds = { minX: -65, maxX: 65, minZ: -65, maxZ: 65 };

  clear() {
    this.colliders = [];
  }

  addBox(
    id: string,
    center: THREE.Vector3,
    size: THREE.Vector3,
    type: CollisionBox['type'] = 'wall',
    isWalkable = false,
    isStair = false
  ) {
    const half = size.clone().multiplyScalar(0.5);
    this.colliders.push({
      id,
      min: center.clone().sub(half),
      max: center.clone().add(half),
      type,
      isWalkable: isWalkable || type === 'floor' || type === 'stair',
      isStair: isStair || type === 'stair',
    });
  }

  addBounds(minX: number, maxX: number, minZ: number, maxZ: number) {
    this.mapBounds = { minX, maxX, minZ, maxZ };
    const h = 12;
    const thickness = 2;

    // North wall
    this.addBox('bound_north', new THREE.Vector3((minX + maxX) / 2, h / 2, minZ - thickness / 2), new THREE.Vector3(maxX - minX + 8, h, thickness), 'boundary');
    // South wall
    this.addBox('bound_south', new THREE.Vector3((minX + maxX) / 2, h / 2, maxZ + thickness / 2), new THREE.Vector3(maxX - minX + 8, h, thickness), 'boundary');
    // West wall
    this.addBox('bound_west', new THREE.Vector3(minX - thickness / 2, h / 2, (minZ + maxZ) / 2), new THREE.Vector3(thickness, h, maxZ - minZ + 8), 'boundary');
    // East wall
    this.addBox('bound_east', new THREE.Vector3(maxX + thickness / 2, h / 2, (minZ + maxZ) / 2), new THREE.Vector3(thickness, h, maxZ - minZ + 8), 'boundary');
  }

  getColliders(): readonly CollisionBox[] {
    return this.colliders;
  }

  removeBox(id: string) {
    this.colliders = this.colliders.filter(b => b.id !== id);
  }

  hasBox(id: string): boolean {
    return this.colliders.some(b => b.id === id);
  }

  // Resolves movement for a cylinder/capsule collider with radius & height
  resolveMovement(
    currentPos: THREE.Vector3,
    desiredMove: THREE.Vector3,
    radius: number = 0.45,
    height: number = 1.8,
    maxStepHeight: number = 0.4
  ): { position: THREE.Vector3; grounded: boolean; collided: boolean } {
    let collided = false;
    const newPos = currentPos.clone();

    // 1. Enforce map boundary clamping
    newPos.x = Math.max(this.mapBounds.minX + radius, Math.min(this.mapBounds.maxX - radius, newPos.x));
    newPos.z = Math.max(this.mapBounds.minZ + radius, Math.min(this.mapBounds.maxZ - radius, newPos.z));

    if (desiredMove.lengthSq() < 0.000001) {
      const groundY = this.getGroundHeight(newPos.x, newPos.z, newPos.y);
      const grounded = Math.abs(newPos.y - groundY) < 0.1;
      return { position: newPos, grounded, collided: false };
    }

    const footY = currentPos.y;
    const headY = currentPos.y + height;

    // 2. Resolve X movement with solid sliding
    if (Math.abs(desiredMove.x) > 0.00001) {
      const testX = newPos.x + desiredMove.x;
      let blockedX = false;

      for (const box of this.colliders) {
        // Only solid non-walkable colliders block lateral movement
        if (box.isWalkable && !box.isStair && box.max.y <= footY + maxStepHeight) {
          continue; // Step onto floors/slabs
        }

        // Allow stepping up stairs
        if (box.isStair && footY + maxStepHeight >= box.max.y) {
          continue;
        }

        // Vertical overlap check
        if (headY > box.min.y && footY + maxStepHeight < box.max.y) {
          if (
            testX + radius > box.min.x &&
            testX - radius < box.max.x &&
            newPos.z + radius > box.min.z &&
            newPos.z - radius < box.max.z
          ) {
            blockedX = true;
            collided = true;
            if (desiredMove.x > 0) {
              newPos.x = box.min.x - radius - 0.001;
            } else {
              newPos.x = box.max.x + radius + 0.001;
            }
            break;
          }
        }
      }

      if (!blockedX) {
        newPos.x = testX;
      }
    }

    // 3. Resolve Z movement with solid sliding
    if (Math.abs(desiredMove.z) > 0.00001) {
      const testZ = newPos.z + desiredMove.z;
      let blockedZ = false;

      for (const box of this.colliders) {
        if (box.isWalkable && !box.isStair && box.max.y <= footY + maxStepHeight) {
          continue;
        }

        if (box.isStair && footY + maxStepHeight >= box.max.y) {
          continue;
        }

        if (headY > box.min.y && footY + maxStepHeight < box.max.y) {
          if (
            newPos.x + radius > box.min.x &&
            newPos.x - radius < box.max.x &&
            testZ + radius > box.min.z &&
            testZ - radius < box.max.z
          ) {
            blockedZ = true;
            collided = true;
            if (desiredMove.z > 0) {
              newPos.z = box.min.z - radius - 0.001;
            } else {
              newPos.z = box.max.z + radius + 0.001;
            }
            break;
          }
        }
      }

      if (!blockedZ) {
        newPos.z = testZ;
      }
    }

    // 4. Ground Height calculation
    const groundY = this.getGroundHeight(newPos.x, newPos.z, newPos.y);
    const grounded = Math.abs(newPos.y - groundY) < 0.12;

    return { position: newPos, grounded, collided };
  }

  // Get exact walkable ground height at coordinate
  getGroundHeight(x: number, z: number, currentY: number = 0): number {
    let groundY = 0; // Default terrain level

    for (const box of this.colliders) {
      // ONLY walkable colliders (floors, sidewalks, stairs, slabs) can be stood upon!
      if (!box.isWalkable && !box.isStair) continue;

      if (
        x >= box.min.x - 0.05 &&
        x <= box.max.x + 0.05 &&
        z >= box.min.z - 0.05 &&
        z <= box.max.z + 0.05
      ) {
        // Can only step on ground if player's feet are within step height or above
        if (currentY + 0.5 >= box.max.y) {
          if (box.max.y > groundY) {
            groundY = box.max.y;
          }
        }
      }
    }

    return groundY;
  }

  // Raycast against all collision boxes (for bullets and line-of-sight checks)
  raycast(ray: THREE.Ray, maxDistance: number = 100): RayHit | null {
    let closestHit: RayHit | null = null;
    let closestDist = maxDistance;

    const hitPoint = new THREE.Vector3();
    const box3 = new THREE.Box3();

    for (const box of this.colliders) {
      box3.set(box.min, box.max);
      if (ray.intersectBox(box3, hitPoint)) {
        const dist = ray.origin.distanceTo(hitPoint);
        if (dist < closestDist) {
          closestDist = dist;
          const normal = new THREE.Vector3();
          const eps = 0.05;
          if (Math.abs(hitPoint.x - box.min.x) < eps) normal.set(-1, 0, 0);
          else if (Math.abs(hitPoint.x - box.max.x) < eps) normal.set(1, 0, 0);
          else if (Math.abs(hitPoint.y - box.min.y) < eps) normal.set(0, -1, 0);
          else if (Math.abs(hitPoint.y - box.max.y) < eps) normal.set(0, 1, 0);
          else if (Math.abs(hitPoint.z - box.min.z) < eps) normal.set(0, 0, -1);
          else if (Math.abs(hitPoint.z - box.max.z) < eps) normal.set(0, 0, 1);
          else normal.set(0, 1, 0);

          closestHit = {
            distance: dist,
            point: hitPoint.clone(),
            normal,
            collider: box,
          };
        }
      }
    }

    return closestHit;
  }

  isObstructed(from: THREE.Vector3, to: THREE.Vector3): boolean {
    const dir = to.clone().sub(from);
    const dist = dir.length();
    if (dist < 0.1) return false;
    dir.normalize();
    const ray = new THREE.Ray(from, dir);
    const hit = this.raycast(ray, dist - 0.1);
    return hit !== null;
  }

  testMapCollision(): { totalColliders: number; passed: boolean; details: string } {
    if (this.colliders.length < 15) {
      return {
        totalColliders: this.colliders.length,
        passed: false,
        details: 'Too few colliders registered for full map.',
      };
    }

    for (const b of this.colliders) {
      if (b.min.x >= b.max.x || b.min.y >= b.max.y || b.min.z >= b.max.z) {
        return {
          totalColliders: this.colliders.length,
          passed: false,
          details: `Inverted collider detected: ${b.id}`,
        };
      }
    }

    return {
      totalColliders: this.colliders.length,
      passed: true,
      details: `Map collision integrity verified with ${this.colliders.length} solid boundaries.`,
    };
  }
}
