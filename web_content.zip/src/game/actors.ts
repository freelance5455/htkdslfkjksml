import * as THREE from "three";
import { CAR_SPEC, type Outfit } from "@/game/content";
import type { CarKind } from "@/game/types";

export function toonGradient() {
  const c = document.createElement("canvas");
  c.width = 4;
  c.height = 1;
  const g = c.getContext("2d");
  if (!g) return new THREE.CanvasTexture(c);
  ["#3a3a3a", "#8a8a8a", "#d0d0d0", "#ffffff"].forEach((col, i) => {
    g.fillStyle = col;
    g.fillRect(i, 0, 1, 1);
  });
  const tex = new THREE.CanvasTexture(c);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function disposeTree(obj: THREE.Object3D) {
  const geos = new Set<THREE.BufferGeometry>();
  const mats = new Set<THREE.Material>();
  obj.traverse((child) => {
    const mesh = child as THREE.Mesh;
    if (mesh.geometry && !geos.has(mesh.geometry)) {
      geos.add(mesh.geometry);
      mesh.geometry.dispose();
    }
    const mat = mesh.material;
    const list = Array.isArray(mat) ? mat : mat ? [mat] : [];
    for (const m of list) {
      if (!mats.has(m)) {
        mats.add(m);
        m.dispose();
      }
    }
  });
}

export type Rig = {
  root: THREE.Group;
  bob: THREE.Group;
  armL: THREE.Mesh;
  armR: THREE.Mesh;
  legL: THREE.Mesh;
  legR: THREE.Mesh;
  shade: THREE.Group;
  mats: {
    skin: THREE.MeshStandardMaterial;
    top: THREE.MeshStandardMaterial;
    bottom: THREE.MeshStandardMaterial;
    shoes: THREE.MeshStandardMaterial;
    hair: THREE.MeshStandardMaterial;
  };
};

function limb(w: number, h: number, d: number, mat: THREE.Material) {
  const geo = new THREE.BoxGeometry(w, h, d);
  geo.translate(0, -h / 2, 0);
  return new THREE.Mesh(geo, mat);
}

export function makeRig(): Rig {
  const mats = {
    skin: new THREE.MeshStandardMaterial({ color: "#6b4632", roughness: 0.72, metalness: 0.02 }),
    top: new THREE.MeshStandardMaterial({ color: "#141414", roughness: 0.78, metalness: 0.04 }),
    bottom: new THREE.MeshStandardMaterial({ color: "#1c1c1c", roughness: 0.8, metalness: 0.02 }),
    shoes: new THREE.MeshStandardMaterial({ color: "#f4f4f4", roughness: 0.45, metalness: 0.08 }),
    hair: new THREE.MeshStandardMaterial({ color: "#ececec", roughness: 0.55, metalness: 0.12 }),
  };
  const root = new THREE.Group();
  const bob = new THREE.Group();
  root.add(bob);

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.62, 0.24), mats.top);
  torso.position.set(0, 1.22, 0);
  const hip = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.22, 0.22), mats.bottom);
  hip.position.set(0, 0.86, 0);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.16, 14, 12), mats.skin);
  head.position.set(0, 1.68, 0);
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.165, 12, 10), mats.hair);
  hair.scale.set(1, 0.72, 1);
  hair.position.set(0, 1.8, 0);
  const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.06, 0.06), mats.skin);
  jaw.position.set(0, 1.56, 0.12);

  const armL = limb(0.13, 0.58, 0.13, mats.skin);
  const armR = limb(0.13, 0.58, 0.13, mats.skin);
  armL.position.set(-0.34, 1.48, 0);
  armR.position.set(0.34, 1.48, 0);
  const legL = limb(0.16, 0.74, 0.16, mats.bottom);
  const legR = limb(0.16, 0.74, 0.16, mats.bottom);
  legL.position.set(-0.12, 0.78, 0);
  legR.position.set(0.12, 0.78, 0);
  const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.1, 0.3), mats.shoes);
  const shoeR = shoeL.clone();
  shoeL.position.set(0, -0.74, 0.05);
  shoeR.position.set(0, -0.74, 0.05);
  legL.add(shoeL);
  legR.add(shoeR);

  const shade = new THREE.Group();
  const glass = new THREE.MeshStandardMaterial({ color: "#1a1c22", roughness: 0.15, metalness: 0.4 });
  const frame = new THREE.MeshStandardMaterial({ color: "#111", roughness: 0.4, metalness: 0.6 });
  for (const s of [-1, 1]) {
    const lens = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.06, 0.02), glass);
    lens.position.set(s * 0.07, 1.7, 0.15);
    shade.add(lens);
  }
  const bridge = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.025, 0.02), frame);
  bridge.position.set(0, 1.7, 0.15);
  shade.add(bridge);

  const gun = new THREE.Group();
  const jade = new THREE.MeshStandardMaterial({ color: "#178a66", metalness: 0.62, roughness: 0.32, emissive: "#064436", emissiveIntensity: 0.45 });
  const dark = new THREE.MeshStandardMaterial({ color: "#121212", roughness: 0.5, metalness: 0.4 });
  const gold = new THREE.MeshStandardMaterial({ color: "#e1b04a", metalness: 0.7, roughness: 0.3 });
  const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.09, 0.78), jade);
  const stock = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.12, 0.22), dark);
  stock.position.set(0, -0.02, -0.32);
  const mag = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.2, 0.08), dark);
  mag.position.set(0, -0.14, 0.02);
  const trim = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.03, 0.18), gold);
  trim.position.set(0, 0.05, 0.12);
  gun.add(barrel, stock, mag, trim);
  gun.position.set(0.16, 1.22, 0.28);
  gun.rotation.set(-1.15, 0.15, 0.4);

  bob.add(torso, hip, head, hair, jaw, armL, armR, legL, legR, shade, gun);
  return { root, bob, armL, armR, legL, legR, shade, mats };
}

export function applyOutfit(rig: Rig, o: Outfit) {
  rig.mats.skin.color.set(o.skin);
  rig.mats.top.color.set(o.top);
  rig.mats.bottom.color.set(o.bottom);
  rig.mats.shoes.color.set(o.shoes);
  rig.mats.hair.color.set(o.hair);
  rig.armL.material = o.sleeves ? rig.mats.top : rig.mats.skin;
  rig.armR.material = o.sleeves ? rig.mats.top : rig.mats.skin;
  rig.shade.visible = o.shades;
}

export function makeCar(kind: CarKind, color: string) {
  const spec = CAR_SPEC[kind];
  const g = new THREE.Group();
  const paint = new THREE.MeshStandardMaterial({ color, metalness: kind === "sport" ? 0.72 : 0.45, roughness: 0.35 });
  const glass = new THREE.MeshStandardMaterial({ color: "#b9e2ff", metalness: 0.15, roughness: 0.05, transparent: true, opacity: 0.5 });
  const dark = new THREE.MeshStandardMaterial({ color: "#161616", roughness: 0.55, metalness: 0.3 });
  const lamp = new THREE.MeshStandardMaterial({ color: "#fff6d8", emissive: "#fff1c2", emissiveIntensity: 0.7 });
  const bodyH = spec.hei * 0.48;
  const body = new THREE.Mesh(new THREE.BoxGeometry(spec.wid, bodyH, spec.len), paint);
  body.position.y = spec.wheelR + bodyH * 0.35;
  g.add(body);
  if (kind !== "bike") {
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(spec.wid * 0.78, spec.hei * 0.38, spec.len * 0.46), glass);
    cabin.position.set(0, body.position.y + bodyH * 0.55, -spec.len * 0.06);
    g.add(cabin);
  }
  if (kind === "sport" || kind === "bike") {
    const stripe = new THREE.Mesh(
      new THREE.BoxGeometry(kind === "bike" ? 0.08 : spec.wid * 0.16, 0.05, spec.len * 0.9),
      new THREE.MeshStandardMaterial({ color: "#178a66", emissive: "#0a4a38", emissiveIntensity: 0.5, metalness: 0.4, roughness: 0.35 }),
    );
    stripe.position.y = body.position.y + bodyH * 0.52;
    g.add(stripe);
  }
  for (const s of [-1, 1]) {
    if (kind === "bike" && s === 1) continue;
    const h = new THREE.Mesh(new THREE.BoxGeometry(kind === "bike" ? 0.12 : 0.24, 0.12, 0.08), lamp);
    h.position.set(s * spec.wid * 0.32, body.position.y, spec.len * 0.5);
    h.name = "head";
    g.add(h);
  }
  if (kind === "cop") {
    const y = body.position.y + bodyH * 0.95;
    const bar = new THREE.Mesh(new THREE.BoxGeometry(spec.wid * 0.62, 0.1, 0.28), dark);
    bar.position.y = y;
    g.add(bar);
    const redM = new THREE.MeshStandardMaterial({ color: "#ff2d2d", emissive: "#ff2d2d", emissiveIntensity: 1 });
    const blueM = new THREE.MeshStandardMaterial({ color: "#3a78ff", emissive: "#3a78ff", emissiveIntensity: 1 });
    const red = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.1, 0.22), redM);
    const blue = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.1, 0.22), blueM);
    red.position.set(-0.28, y, 0);
    blue.position.set(0.28, y, 0);
    red.name = "sirenR";
    blue.name = "sirenB";
    g.add(red, blue);
  }
  if (kind === "taxi") {
    const sign = new THREE.Mesh(
      new THREE.BoxGeometry(0.46, 0.14, 0.16),
      new THREE.MeshStandardMaterial({ color: "#f5b301", emissive: "#f5b301", emissiveIntensity: 0.45 }),
    );
    sign.position.y = body.position.y + bodyH * 1.05;
    g.add(sign);
  }
  const wheelGeo = new THREE.CylinderGeometry(spec.wheelR, spec.wheelR, kind === "bike" ? 0.16 : 0.26, 8);
  wheelGeo.rotateZ(Math.PI / 2);
  const rubber = new THREE.MeshStandardMaterial({ color: "#1b1b1b", roughness: 0.85, metalness: 0.05 });
  const spots: [number, number][] =
    spec.wheels === 2
      ? [
          [0, spec.len * 0.32],
          [0, -spec.len * 0.32],
        ]
      : [
          [spec.wid / 2 - 0.02, spec.len * 0.32],
          [-spec.wid / 2 + 0.02, spec.len * 0.32],
          [spec.wid / 2 - 0.02, -spec.len * 0.32],
          [-spec.wid / 2 + 0.02, -spec.len * 0.32],
        ];
  for (const [x, z] of spots) {
    const w = new THREE.Mesh(wheelGeo.clone(), rubber);
    w.position.set(x, spec.wheelR, z);
    w.name = "wheel";
    g.add(w);
  }
  wheelGeo.dispose();
  g.userData.kind = kind;
  return g;
}

export function makeTreeGeo() {
  const trunk = new THREE.CylinderGeometry(0.22, 0.32, 1.3, 6);
  trunk.translate(0, 0.65, 0);
  const a = new THREE.SphereGeometry(1.05, 8, 6);
  a.translate(0, 1.85, 0);
  const b = new THREE.SphereGeometry(0.72, 7, 5);
  b.translate(0.55, 2.15, 0.2);
  const c = new THREE.SphereGeometry(0.6, 7, 5);
  c.translate(-0.45, 2.05, -0.15);
  const paint = (geo: THREE.BufferGeometry, color: THREE.Color) => {
    const n = geo.getAttribute("position").count;
    const arr = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      arr[i * 3] = color.r;
      arr[i * 3 + 1] = color.g;
      arr[i * 3 + 2] = color.b;
    }
    geo.setAttribute("color", new THREE.BufferAttribute(arr, 3));
    return geo;
  };
  return [paint(trunk, new THREE.Color("#6b3e26")), paint(a, new THREE.Color("#3ea84a")), paint(b, new THREE.Color("#7ed36a")), paint(c, new THREE.Color("#2f8f3a"))];
}

export function makeLampGeo() {
  const pole = new THREE.CylinderGeometry(0.08, 0.1, 3.2, 6);
  pole.translate(0, 1.6, 0);
  const head = new THREE.BoxGeometry(0.55, 0.16, 0.28);
  head.translate(0, 3.25, 0.2);
  return [pole, head];
}
