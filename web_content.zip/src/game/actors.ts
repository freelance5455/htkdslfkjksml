import * as THREE from "three";
import type { Plant } from "@/game/plants";

export type Limbs = {
  legL: THREE.Group;
  legR: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
};

export type FarmerRig = {
  group: THREE.Group;
  limbs: Limbs;
};

const matCache = new Map<string, THREE.MeshStandardMaterial>();

function sharedMat(color: number, roughness: number, emissive = 0): THREE.MeshStandardMaterial {
  const key = `${color}:${roughness}:${emissive}`;
  let m = matCache.get(key);
  if (!m) {
    m = new THREE.MeshStandardMaterial({
      color,
      roughness,
      metalness: 0.02,
      emissive: emissive ? color : 0x000000,
      emissiveIntensity: emissive,
    });
    matCache.set(key, m);
  }
  return m;
}

function limb(geo: THREE.BufferGeometry, material: THREE.Material, x: number, y: number, parent: THREE.Group) {
  const pivot = new THREE.Group();
  pivot.position.set(x, y, 0);
  const mesh = new THREE.Mesh(geo, material);
  mesh.position.y = -0.28;
  mesh.castShadow = true;
  pivot.add(mesh);
  parent.add(pivot);
  return pivot;
}

export function makeFarmer(shirt: number): FarmerRig {
  const group = new THREE.Group();
  const skin = sharedMat(0xf0c7a0, 0.72);
  const cloth = sharedMat(shirt, 0.74);
  const pants = sharedMat(0x3d4a38, 0.86);
  const hat = sharedMat(0xd8a04a, 0.62);
  const dark = sharedMat(0x2a2118, 0.5);

  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.3, 0.42, 4, 8), cloth);
  body.position.y = 1.12;
  body.castShadow = true;
  group.add(body);

  const bib = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.42, 0.22), pants);
  bib.position.set(0, 1.02, 0.06);
  bib.castShadow = true;
  group.add(bib);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.25, 16, 12), skin);
  head.position.y = 1.68;
  head.castShadow = true;
  group.add(head);

  const eyeGeo = new THREE.SphereGeometry(0.032, 8, 6);
  const e1 = new THREE.Mesh(eyeGeo, dark);
  const e2 = new THREE.Mesh(eyeGeo, dark);
  e1.position.set(-0.08, 1.72, 0.2);
  e2.position.set(0.08, 1.72, 0.2);
  group.add(e1, e2);

  const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.045, 18), hat);
  brim.position.y = 1.92;
  brim.castShadow = true;
  const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.22, 0.2, 12), hat);
  crown.position.y = 2.04;
  crown.castShadow = true;
  group.add(brim, crown);

  const legGeo = new THREE.CapsuleGeometry(0.09, 0.34, 3, 6);
  const armGeo = new THREE.CapsuleGeometry(0.065, 0.3, 3, 6);
  const limbs: Limbs = {
    legL: limb(legGeo, pants, -0.13, 0.76, group),
    legR: limb(legGeo, pants, 0.13, 0.76, group),
    armL: limb(armGeo, cloth, -0.38, 1.32, group),
    armR: limb(armGeo, cloth, 0.38, 1.32, group),
  };

  return { group, limbs };
}

export function poseFarmer(limbs: Limbs, gait: number, moving: boolean, riding: boolean) {
  if (riding) {
    limbs.legL.rotation.x = 1.15;
    limbs.legR.rotation.x = 1.15;
    limbs.armL.rotation.x = -0.85;
    limbs.armR.rotation.x = -0.85;
    limbs.armL.rotation.z = 0.25;
    limbs.armR.rotation.z = -0.25;
    return;
  }
  limbs.armL.rotation.z = 0;
  limbs.armR.rotation.z = 0;
  if (!moving) {
    limbs.legL.rotation.x = 0;
    limbs.legR.rotation.x = 0;
    limbs.armL.rotation.x = 0;
    limbs.armR.rotation.x = 0;
    return;
  }
  const s = Math.sin(gait);
  limbs.legL.rotation.x = s * 0.75;
  limbs.legR.rotation.x = -s * 0.75;
  limbs.armL.rotation.x = -s * 0.55;
  limbs.armR.rotation.x = s * 0.55;
}

export function makeBike(): { group: THREE.Group; wheels: THREE.Group[] } {
  const group = new THREE.Group();
  const frame = sharedMat(0x1f7a45, 0.35);
  frame.metalness = 0.45;
  const metal = sharedMat(0xc5ced6, 0.28);
  metal.metalness = 0.75;
  const rubber = sharedMat(0x1a1e18, 0.92);
  const seatM = sharedMat(0x2a241c, 0.8);

  const wheels: THREE.Group[] = [];
  const addWheel = (z: number) => {
    const spin = new THREE.Group();
    spin.position.set(0, 0.52, z);
    const tire = new THREE.Mesh(new THREE.TorusGeometry(0.48, 0.075, 8, 20), rubber);
    tire.rotation.y = Math.PI / 2;
    tire.castShadow = true;
    spin.add(tire);
    for (let i = 0; i < 5; i++) {
      const spoke = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.86, 0.02), metal);
      spoke.rotation.x = (i * Math.PI) / 5;
      spin.add(spoke);
    }
    group.add(spin);
    wheels.push(spin);
  };
  addWheel(0.85);
  addWheel(-0.85);

  const tube = (len: number, x: number, y: number, z: number, rx = 0) => {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, len, 8), frame);
    m.position.set(x, y, z);
    m.rotation.x = rx;
    m.castShadow = true;
    group.add(m);
  };
  tube(1.7, 0, 0.82, 0, Math.PI / 2);
  tube(0.7, 0, 1.05, 0.55, 0.5);
  tube(0.65, 0, 1.02, -0.45, -0.4);

  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.55, 8), metal);
  stem.position.set(0, 1.2, 0.78);
  stem.rotation.x = 0.25;
  group.add(stem);
  const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.62, 8), metal);
  bar.rotation.z = Math.PI / 2;
  bar.position.set(0, 1.42, 0.86);
  group.add(bar);

  const seat = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.06, 0.32), seatM);
  seat.position.set(0, 1.18, -0.38);
  group.add(seat);
  return { group, wheels };
}

export function makeLabel(text: string): THREE.Sprite {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 64;
  const g = canvas.getContext("2d");
  if (g) {
    g.fillStyle = "rgba(20,32,22,0.78)";
    g.beginPath();
    g.roundRect(8, 8, 240, 48, 16);
    g.fill();
    g.fillStyle = "#f4efe2";
    g.font = "700 28px Nunito, sans-serif";
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.fillText(text.slice(0, 16), 128, 34);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
  sprite.position.y = 2.45;
  sprite.scale.set(1.7, 0.42, 1);
  return sprite;
}

function addMesh(group: THREE.Group, mesh: THREE.Mesh) {
  mesh.castShadow = true;
  group.add(mesh);
}

export function buildCrop(plant: Plant, stage: number): THREE.Group {
  const group = new THREE.Group();
  const leaf = sharedMat(stage === 1 ? 0x6fbf62 : 0x2f8a3c, 0.8);
  const stem = sharedMat(0x3d8f45, 0.72);
  const fruit = sharedMat(plant.color, 0.42, stage === 3 ? 0.22 : 0);

  if (stage === 1) {
    for (let i = 0; i < 4; i++) {
      const s = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.32, 5), leaf);
      s.position.set((i % 2) * 0.36 - 0.18, 0.22, Math.floor(i / 2) * 0.36 - 0.18);
      addMesh(group, s);
    }
    return group;
  }

  const ripe = stage === 3;

  if (plant.kind === "stalk") {
    const h = ripe ? 1.45 : 0.85;
    for (let i = 0; i < 5; i++) {
      const s = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.05, h, 5), stem);
      s.position.set((i - 2) * 0.22, h / 2 + 0.08, (i % 2) * 0.16 - 0.08);
      addMesh(group, s);
      if (ripe) {
        const head = new THREE.Mesh(new THREE.SphereGeometry(0.11, 8, 6), fruit);
        head.scale.y = 1.45;
        head.position.set(s.position.x, h + 0.08, s.position.z);
        addMesh(group, head);
      }
    }
  } else if (plant.kind === "root") {
    const top = new THREE.Mesh(new THREE.ConeGeometry(0.34, ripe ? 0.7 : 0.42, 7), leaf);
    top.position.y = 0.4;
    addMesh(group, top);
    if (ripe) {
      const root = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.42, 6), fruit);
      root.position.set(0.22, 0.18, 0.08);
      root.rotation.z = Math.PI;
      addMesh(group, root);
    }
  } else if (plant.kind === "flower") {
    const h = ripe ? 1.35 : 0.75;
    const st = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.055, h, 6), stem);
    st.position.y = h / 2 + 0.05;
    addMesh(group, st);
    const bloom = new THREE.Mesh(new THREE.SphereGeometry(ripe ? 0.22 : 0.12, 10, 8), fruit);
    bloom.position.y = h + 0.12;
    addMesh(group, bloom);
    if (ripe) {
      const petal = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.05, 10), fruit);
      petal.position.y = h + 0.02;
      addMesh(group, petal);
      const heart = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), sharedMat(0x6b3a16, 0.5));
      heart.position.y = h + 0.16;
      addMesh(group, heart);
    }
  } else if (plant.kind === "fruit") {
    const p = new THREE.Mesh(new THREE.SphereGeometry(ripe ? 0.62 : 0.32, 12, 10), fruit);
    p.position.y = ripe ? 0.48 : 0.28;
    p.scale.y = 0.82;
    addMesh(group, p);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 6), leaf);
    cap.position.y = ripe ? 0.95 : 0.5;
    addMesh(group, cap);
  } else {
    const bush = new THREE.Mesh(new THREE.SphereGeometry(ripe ? 0.52 : 0.34, 10, 8), leaf);
    bush.position.y = 0.42;
    addMesh(group, bush);
    if (ripe) {
      for (let i = 0; i < 5; i++) {
        const f = new THREE.Mesh(new THREE.SphereGeometry(0.11, 8, 6), fruit);
        const a = (i / 5) * Math.PI * 2;
        f.position.set(Math.cos(a) * 0.32, 0.48 + (i % 2) * 0.12, Math.sin(a) * 0.32);
        addMesh(group, f);
      }
    }
  }

  if (plant.id === "corn" && ripe) {
    const ear = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.28, 3, 6), fruit);
    ear.position.set(0.15, 0.7, 0.1);
    ear.rotation.z = 0.4;
    addMesh(group, ear);
  }
  if (plant.id === "blueberry" && group.children[0]) {
    group.children[0].position.y = 0.35;
  }
  return group;
}

export function disposeObject(obj: THREE.Object3D) {
  obj.traverse((child) => {
    if (child instanceof THREE.Mesh) child.geometry.dispose();
  });
}
