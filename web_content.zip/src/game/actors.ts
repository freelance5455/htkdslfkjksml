import * as THREE from "three";

export type CarKind = "sedan" | "sports" | "suv" | "van" | "moto";

export type WheelRig = { steer: THREE.Group; spin: THREE.Group; front: boolean };

export type CarRig = {
  group: THREE.Group;
  paint: THREE.MeshPhysicalMaterial;
  wheels: WheelRig[];
  spin: number;
  tails: THREE.MeshStandardMaterial[];
  heads: THREE.MeshStandardMaterial[];
  spots: THREE.SpotLight[];
  siren: THREE.MeshStandardMaterial[];
};

export type LimbSet = { legs: THREE.Group[]; arms: THREE.Group[] };

export type Preset = {
  name: string;
  skin: number;
  hair: number;
  shirt: number;
  pants: number;
  shoes: number;
  hairStyle: "buzz" | "recede" | "bald" | "cap";
  glasses?: number;
  beard?: number;
  hat?: number;
};

export const PRESETS: Preset[] = [
  { name: "MICHAEL", skin: 0xe0b08a, hair: 0x4a3424, shirt: 0x8ea4be, pants: 0x2c3544, shoes: 0x1a1e24, hairStyle: "recede", glasses: 0x1a1e24, beard: 0x3a2a1c },
  { name: "FRANKLIN", skin: 0x8a5638, hair: 0x141414, shirt: 0xdeded8, pants: 0x242a36, shoes: 0xe8e8e8, hairStyle: "buzz", beard: 0x141414 },
  { name: "TREVOR", skin: 0xd4a07a, hair: 0x8a6840, shirt: 0xcfc8b4, pants: 0x6a5a40, shoes: 0x2a241c, hairStyle: "bald", beard: 0x8a6840 },
  { name: "LAMAR", skin: 0x6e4328, hair: 0x111111, shirt: 0x3a3e4a, pants: 0x1e222c, shoes: 0xe4e4e4, hairStyle: "cap", hat: 0xb03038 },
  { name: "OFFICER", skin: 0xc48a62, hair: 0x2a2018, shirt: 0x1e2c4a, pants: 0x151c2c, shoes: 0x121418, hairStyle: "cap", hat: 0x1a243c, glasses: 0x10141c },
];

const SPEC: Record<CarKind, { w: number; h: number; l: number; cw: number; ch: number; cl: number; cz: number; wr: number; wz: number; wx: number; hl: number }> = {
  sedan: { w: 1.86, h: 0.58, l: 4.35, cw: 1.55, ch: 0.48, cl: 2.05, cz: -0.18, wr: 0.36, wz: 1.4, wx: 0.92, hl: 0.95 },
  sports: { w: 1.96, h: 0.46, l: 4.5, cw: 1.48, ch: 0.36, cl: 1.65, cz: -0.42, wr: 0.38, wz: 1.45, wx: 0.98, hl: 1.15 },
  suv: { w: 2.02, h: 0.84, l: 4.55, cw: 1.84, ch: 0.7, cl: 2.45, cz: -0.08, wr: 0.44, wz: 1.48, wx: 1.02, hl: 0.9 },
  van: { w: 2.05, h: 0.98, l: 5.0, cw: 1.9, ch: 0.82, cl: 3.15, cz: -0.32, wr: 0.4, wz: 1.6, wx: 1.02, hl: 0.7 },
  moto: { w: 0.55, h: 0.5, l: 2.25, cw: 0.4, ch: 0.35, cl: 0.6, cz: 0.05, wr: 0.34, wz: 0.78, wx: 0, hl: 0.4 },
};

let tireMat: THREE.MeshStandardMaterial | null = null;
let hubMat: THREE.MeshStandardMaterial | null = null;
let glassMat: THREE.MeshPhysicalMaterial | null = null;
let trimMat: THREE.MeshStandardMaterial | null = null;
let blackMat: THREE.MeshStandardMaterial | null = null;
let chromeMat: THREE.MeshStandardMaterial | null = null;
let tireGeo: THREE.CylinderGeometry | null = null;
let hubGeo: THREE.CylinderGeometry | null = null;

function shared() {
  tireMat ??= new THREE.MeshStandardMaterial({ color: 0x111113, roughness: 0.95 });
  hubMat ??= new THREE.MeshStandardMaterial({ color: 0xb7bac2, roughness: 0.28, metalness: 0.85 });
  glassMat ??= new THREE.MeshPhysicalMaterial({
    color: 0x9eb4c6,
    roughness: 0.05,
    metalness: 0.55,
    transparent: true,
    opacity: 0.42,
    envMapIntensity: 1.2,
  });
  trimMat ??= new THREE.MeshStandardMaterial({ color: 0x1a1c22, roughness: 0.55, metalness: 0.35 });
  blackMat ??= new THREE.MeshStandardMaterial({ color: 0x0c0d11, roughness: 0.6 });
  chromeMat ??= new THREE.MeshStandardMaterial({ color: 0xd5d8e0, roughness: 0.18, metalness: 1 });
  tireGeo ??= new THREE.CylinderGeometry(1, 1, 0.24, 16);
  hubGeo ??= new THREE.CylinderGeometry(0.55, 0.55, 0.26, 12);
  return { tireMat, hubMat, glassMat, trimMat, blackMat, chromeMat, tireGeo, hubGeo };
}

function wheel(x: number, y: number, z: number, radius: number, front: boolean, parent: THREE.Group): WheelRig {
  const { tireMat: tire, hubMat: hub, tireGeo: tg, hubGeo: hg } = shared();
  const steer = new THREE.Group();
  steer.position.set(x, y, z);
  const spin = new THREE.Group();
  steer.add(spin);
  const tread = new THREE.Mesh(tg, tire);
  tread.scale.set(radius, 1, radius);
  tread.rotation.z = Math.PI / 2;
  tread.castShadow = true;
  const cap = new THREE.Mesh(hg, hub);
  cap.scale.set(radius, 1, radius);
  cap.rotation.z = Math.PI / 2;
  spin.add(tread, cap);
  parent.add(steer);
  return { steer, spin, front };
}

export function createCar(color: number, kind: CarKind, police = false): CarRig {
  const s = SPEC[kind];
  const { glassMat: glass, trimMat: trim, blackMat: black, chromeMat: chrome } = shared();
  const group = new THREE.Group();
  group.rotation.order = "YXZ";
  const paint = new THREE.MeshPhysicalMaterial({
    color,
    roughness: kind === "sports" ? 0.16 : 0.28,
    metalness: 0.72,
    clearcoat: 1,
    clearcoatRoughness: 0.06,
    envMapIntensity: 1.15,
  });
  const body = new THREE.Mesh(new THREE.BoxGeometry(s.w, s.h, s.l), paint);
  body.position.y = 0.55;
  body.castShadow = true;
  const hood = new THREE.Mesh(new THREE.BoxGeometry(s.w * 0.96, s.h * 0.42, s.hl), paint);
  hood.position.set(0, 0.55 + s.h * 0.32, s.l / 2 - s.hl / 2 - 0.02);
  hood.castShadow = true;
  const trunk = new THREE.Mesh(new THREE.BoxGeometry(s.w * 0.96, s.h * 0.5, 0.72), paint);
  trunk.position.set(0, 0.55 + s.h * 0.18, -s.l / 2 + 0.4);
  trunk.castShadow = true;
  group.add(body, hood, trunk);

  if (kind !== "moto") {
    const cab = new THREE.Mesh(new THREE.BoxGeometry(s.cw, s.ch, s.cl), paint);
    cab.position.set(0, 0.55 + s.h / 2 + s.ch / 2 - 0.04, s.cz);
    cab.castShadow = true;
    group.add(cab);
    const pane = new THREE.BoxGeometry(s.cw * 0.92, s.ch * 0.78, 0.06);
    const wind = new THREE.Mesh(pane, glass);
    wind.position.set(0, 0.55 + s.h / 2 + s.ch * 0.45, s.cz + s.cl / 2);
    wind.rotation.x = -0.42;
    const rear = new THREE.Mesh(pane, glass);
    rear.position.set(0, 0.55 + s.h / 2 + s.ch * 0.42, s.cz - s.cl / 2);
    rear.rotation.x = 0.4;
    group.add(wind, rear);
    for (const side of [-1, 1]) {
      const sw = new THREE.Mesh(new THREE.BoxGeometry(0.05, s.ch * 0.62, s.cl * 0.78), glass);
      sw.position.set(side * s.cw / 2, 0.55 + s.h / 2 + s.ch * 0.35, s.cz);
      const mirror = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.08, 0.1), trim);
      mirror.position.set(side * (s.cw / 2 + 0.08), 0.55 + s.h / 2 + s.ch * 0.7, s.cz + s.cl / 2 - 0.1);
      group.add(sw, mirror);
    }
    if (kind === "sports") {
      const wing = new THREE.Mesh(new THREE.BoxGeometry(s.w * 0.86, 0.06, 0.28), trim);
      wing.position.set(0, 0.55 + s.h + s.ch * 0.2, -s.l / 2 + 0.35);
      group.add(wing);
    }
  }

  const wheels: WheelRig[] = [];
  const posts = kind === "moto" ? [[0, s.wz], [0, -s.wz]] : [[-s.wx, s.wz], [s.wx, s.wz], [-s.wx, -s.wz], [s.wx, -s.wz]];
  posts.forEach(([x, z], idx) => {
    wheels.push(wheel(x!, s.wr, z!, s.wr, z! > 0, group));
    void idx;
  });

  const tails: THREE.MeshStandardMaterial[] = [];
  const heads: THREE.MeshStandardMaterial[] = [];
  const headMat = new THREE.MeshStandardMaterial({ color: 0xfff6dd, emissive: 0xfff1c4, emissiveIntensity: 0.8 });
  const tailMat = new THREE.MeshStandardMaterial({ color: 0xff2028, emissive: 0xff1a22, emissiveIntensity: 0.7 });
  heads.push(headMat);
  tails.push(tailMat);
  for (const x of kind === "moto" ? [0] : [-0.55, 0.55]) {
    const hl = new THREE.Mesh(new THREE.BoxGeometry(kind === "moto" ? 0.28 : 0.36, 0.16, 0.08), headMat);
    hl.position.set(x, 0.58, s.l / 2 + 0.02);
    const tl = new THREE.Mesh(new THREE.BoxGeometry(kind === "moto" ? 0.22 : 0.32, 0.14, 0.08), tailMat);
    tl.position.set(x, 0.58, -s.l / 2 - 0.02);
    group.add(hl, tl);
  }
  const grille = new THREE.Mesh(new THREE.BoxGeometry(s.w * 0.55, 0.16, 0.06), black);
  grille.position.set(0, 0.48, s.l / 2 + 0.03);
  const bumper = new THREE.Mesh(new THREE.BoxGeometry(s.w * 0.98, 0.12, 0.16), chrome);
  bumper.position.set(0, 0.32, s.l / 2 + 0.02);
  group.add(grille, bumper);

  if (police) {
    const bar = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.12, 0.32), trim);
    bar.position.set(0, 0.55 + s.h + s.ch + 0.02, -0.05);
    const red = new THREE.MeshStandardMaterial({ color: 0xff2030, emissive: 0xff0000, emissiveIntensity: 1.2 });
    const blue = new THREE.MeshStandardMaterial({ color: 0x2244ff, emissive: 0x1133ff, emissiveIntensity: 1.2 });
    const rl = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.14, 0.26), red);
    rl.position.set(-0.28, 0.55 + s.h + s.ch + 0.12, -0.05);
    const bl = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.14, 0.26), blue);
    bl.position.set(0.28, 0.55 + s.h + s.ch + 0.12, -0.05);
    group.add(bar, rl, bl);
    tails.push(red, blue);
  }

  return { group, paint, wheels, spin: 0, tails, heads, spots: [], siren: police ? tails.splice(tails.length - 2, 2) : [] };
}

export function attachBeams(rig: CarRig) {
  if (rig.spots.length) return;
  for (const x of [-0.45, 0.45]) {
    const target = new THREE.Object3D();
    target.position.set(x, 0.35, 16);
    const spot = new THREE.SpotLight(0xfff3d4, 0, 48, 0.48, 0.6, 1.3);
    spot.position.set(x, 0.72, 2.05);
    spot.target = target;
    rig.group.add(spot, target);
    rig.spots.push(spot);
  }
}

const geos = {
  head: new THREE.SphereGeometry(0.15, 14, 12),
  jaw: new THREE.SphereGeometry(0.11, 10, 8),
  ear: new THREE.SphereGeometry(0.035, 6, 5),
  nose: new THREE.ConeGeometry(0.028, 0.07, 6),
  eye: new THREE.SphereGeometry(0.028, 8, 6),
  pup: new THREE.SphereGeometry(0.013, 6, 6),
  mouth: new THREE.BoxGeometry(0.055, 0.012, 0.01),
  hair: new THREE.SphereGeometry(0.16, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2.05),
  torso: new THREE.CylinderGeometry(0.2, 0.16, 0.52, 10),
  hip: new THREE.BoxGeometry(0.34, 0.16, 0.2),
  uArm: new THREE.CapsuleGeometry(0.055, 0.2, 3, 6),
  lArm: new THREE.CapsuleGeometry(0.048, 0.18, 3, 6),
  hand: new THREE.BoxGeometry(0.08, 0.09, 0.06),
  thigh: new THREE.CapsuleGeometry(0.08, 0.26, 3, 6),
  shin: new THREE.CapsuleGeometry(0.062, 0.26, 3, 6),
  shoe: new THREE.BoxGeometry(0.12, 0.07, 0.24),
  blob: new THREE.CircleGeometry(0.42, 14),
};

const skinCache = new Map<number, THREE.MeshStandardMaterial>();
const clothCache = new Map<number, THREE.MeshStandardMaterial>();

function matte(color: number, cache: Map<number, THREE.MeshStandardMaterial>, rough: number) {
  let m = cache.get(color);
  if (!m) {
    m = new THREE.MeshStandardMaterial({ color, roughness: rough });
    cache.set(color, m);
  }
  return m;
}

export function createCharacter(p: Preset): THREE.Group {
  const g = new THREE.Group();
  const skin = matte(p.skin, skinCache, 0.72);
  const shirt = matte(p.shirt, clothCache, 0.78);
  const pants = matte(p.pants + 1, clothCache, 0.86);
  const hair = matte(p.hair, clothCache, 0.9);
  const shoe = matte(p.shoes + 3, clothCache, 0.8);
  const eyeW = matte(0xf4f4f4, clothCache, 0.4);
  const pup = matte(0x111111, clothCache, 0.35);
  const mouth = matte(0x6a3030, clothCache, 0.8);

  const head = new THREE.Mesh(geos.head, skin);
  head.position.y = 1.68;
  head.castShadow = true;
  g.add(head);
  const jaw = new THREE.Mesh(geos.jaw, skin);
  jaw.position.set(0, 1.58, 0.01);
  jaw.scale.set(1.02, 0.78, 1);
  g.add(jaw);
  for (const s of [-1, 1]) {
    const ear = new THREE.Mesh(geos.ear, skin);
    ear.position.set(s * 0.145, 1.68, 0);
    g.add(ear);
    const eye = new THREE.Mesh(geos.eye, eyeW);
    eye.position.set(s * 0.055, 1.71, 0.12);
    const pupil = new THREE.Mesh(geos.pup, pup);
    pupil.position.set(s * 0.055, 1.71, 0.142);
    g.add(eye, pupil);
  }
  const nose = new THREE.Mesh(geos.nose, skin);
  nose.position.set(0, 1.66, 0.145);
  nose.rotation.x = Math.PI / 2;
  g.add(nose);
  const lip = new THREE.Mesh(geos.mouth, mouth);
  lip.position.set(0, 1.58, 0.13);
  g.add(lip);

  if (p.glasses) {
    const gm = matte(p.glasses, clothCache, 0.2);
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.045, 0.02), gm);
    frame.position.set(0, 1.71, 0.145);
    g.add(frame);
  }
  if (p.beard) {
    const bm = matte(p.beard, clothCache, 0.95);
    const beard = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 8, 0, Math.PI * 2, Math.PI * 0.55, Math.PI * 0.45), bm);
    beard.position.set(0, 1.54, 0.04);
    g.add(beard);
  }
  if (p.hairStyle === "buzz") {
    const h = new THREE.Mesh(geos.hair, hair);
    h.position.y = 1.7;
    h.scale.set(1.02, 0.72, 1.02);
    g.add(h);
  } else if (p.hairStyle === "recede") {
    const h = new THREE.Mesh(geos.hair, hair);
    h.position.y = 1.69;
    h.scale.set(1.0, 0.85, 1.02);
    g.add(h);
  }
  if (p.hairStyle === "cap" && p.hat) {
    const hm = matte(p.hat, clothCache, 0.75);
    const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 0.1, 10), hm);
    crown.position.y = 1.84;
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.025, 12), hm);
    brim.position.y = 1.79;
    g.add(crown, brim);
  }

  const torso = new THREE.Mesh(geos.torso, shirt);
  torso.position.y = 1.2;
  torso.scale.set(1, 1, 0.82);
  torso.castShadow = true;
  const hip = new THREE.Mesh(geos.hip, pants);
  hip.position.y = 0.9;
  hip.castShadow = true;
  g.add(torso, hip);

  const arms: THREE.Group[] = [];
  const legs: THREE.Group[] = [];
  for (const s of [-1, 1]) {
    const arm = new THREE.Group();
    arm.position.set(s * 0.24, 1.42, 0);
    const ua = new THREE.Mesh(geos.uArm, shirt);
    ua.position.y = -0.16;
    ua.castShadow = true;
    const la = new THREE.Mesh(geos.lArm, skin);
    la.position.y = -0.38;
    const hand = new THREE.Mesh(geos.hand, skin);
    hand.position.y = -0.54;
    arm.add(ua, la, hand);
    g.add(arm);
    arms.push(arm);

    const leg = new THREE.Group();
    leg.position.set(s * 0.09, 0.86, 0);
    const th = new THREE.Mesh(geos.thigh, pants);
    th.position.y = -0.18;
    th.castShadow = true;
    const sh = new THREE.Mesh(geos.shin, pants);
    sh.position.y = -0.46;
    const sc = new THREE.Mesh(geos.shoe, shoe);
    sc.position.set(0, -0.66, 0.03);
    sc.castShadow = true;
    leg.add(th, sh, sc);
    g.add(leg);
    legs.push(leg);
  }
  const blob = new THREE.Mesh(
    geos.blob,
    new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.28, depthWrite: false }),
  );
  blob.rotation.x = -Math.PI / 2;
  blob.position.y = 0.02;
  g.add(blob);
  g.userData.limbs = { legs, arms } satisfies LimbSet;
  return g;
}

export function limbsOf(group: THREE.Group): LimbSet {
  return group.userData.limbs as LimbSet;
}

export function createHeli() {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x1a2744, roughness: 0.45, metalness: 0.4 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x10141c, roughness: 0.5, metalness: 0.5 });
  const body = new THREE.Mesh(new THREE.SphereGeometry(1.15, 12, 10), bodyMat);
  body.scale.set(1.15, 0.72, 2.1);
  body.castShadow = true;
  const tail = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.22, 2.4), bodyMat);
  tail.position.set(0, 0.15, -2.3);
  const fin = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.7, 0.45), dark);
  fin.position.set(0, 0.45, -3.35);
  const skidMat = new THREE.MeshStandardMaterial({ color: 0x22262e, metalness: 0.6, roughness: 0.4 });
  for (const x of [-0.7, 0.7]) {
    const skid = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.06, 2.1), skidMat);
    skid.position.set(x, -0.95, 0.1);
    const strut = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.45, 0.05), skidMat);
    strut.position.set(x, -0.7, 0.2);
    group.add(skid, strut);
  }
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.35, 6), dark);
  mast.position.y = 0.95;
  const mainRotor = new THREE.Group();
  mainRotor.position.y = 1.15;
  for (const rot of [0, Math.PI / 2]) {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.04, 0.18), dark);
    blade.rotation.y = rot;
    mainRotor.add(blade);
  }
  const tailRotor = new THREE.Group();
  tailRotor.position.set(0.2, 0.45, -3.35);
  for (const rot of [0, Math.PI / 2]) {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.03, 0.1), dark);
    blade.rotation.z = rot;
    tailRotor.add(blade);
  }
  const glass = new THREE.Mesh(
    new THREE.SphereGeometry(0.55, 10, 8),
    new THREE.MeshPhysicalMaterial({ color: 0x9eb8cc, transparent: true, opacity: 0.45, roughness: 0.05, metalness: 0.4 }),
  );
  glass.position.set(0, 0.15, 0.85);
  glass.scale.set(1.1, 0.7, 0.8);
  group.add(body, tail, fin, mast, mainRotor, tailRotor, glass);
  return { group, mainRotor, tailRotor };
}
