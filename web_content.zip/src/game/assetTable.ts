/**
 * Explicit asset table. Runtime media is stored in project storage; these stable addresses are the
 * ones registered in `assets.lock.json` by the asset sync.
 */
export const ASSETS = {
  /** The player's aircraft (supplied model "pampa.glb", textures optimised to 2048², Meshopt geometry). */
  aircraft: '/manus-storage/game/sha256/3a9c638e2b871558f06bd2bf59536877bcf8d52917d3c804115fe65b7067a973.glb',
} as const
