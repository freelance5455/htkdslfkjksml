import * as THREE from 'three';
import {
  createRangoliRugTexture,
  createTeakWoodTexture,
  createFloorTileTexture,
  createFamilyPortraitTexture,
  createTVScreenTexture,
} from './proceduralTextures';

export interface BoxCollider {
  min: THREE.Vector3;
  max: THREE.Vector3;
}

export interface HouseWorld {
  group: THREE.Group;
  colliders: BoxCollider[];
  interactableSpots: {
    id: string;
    label: string;
    position: THREE.Vector3;
    hint: string;
  }[];
}

export function buildIndianFamilyHouse(): HouseWorld {
  const root = new THREE.Group();
  root.name = 'Family_House_World';

  const colliders: BoxCollider[] = [];
  const interactableSpots: { id: string; label: string; position: THREE.Vector3; hint: string }[] = [];

  const addCollider = (box: THREE.Box3) => {
    colliders.push({ min: box.min.clone(), max: box.max.clone() });
  };

  // Shared Procedural Textures & Materials
  const floorTileTex = createFloorTileTexture();
  const woodTex = createTeakWoodTexture();
  const rangoliTex = createRangoliRugTexture();
  const portraitTex = createFamilyPortraitTexture();
  const tvScreenTex = createTVScreenTexture();

  const floorMat = new THREE.MeshStandardMaterial({
    map: floorTileTex,
    roughness: 0.35,
    metalness: 0.1,
  });

  const wallMat = new THREE.MeshStandardMaterial({
    color: 0xfffbeb, // warm ivory / cream plaster
    roughness: 0.85,
  });

  const wallAccentMat = new THREE.MeshStandardMaterial({
    color: 0xfef3c7, // gentle gold accent
    roughness: 0.8,
  });

  const woodMat = new THREE.MeshStandardMaterial({
    map: woodTex,
    roughness: 0.6,
    metalness: 0.15,
  });

  const sofaFabricMat = new THREE.MeshStandardMaterial({
    color: 0x0369a1, // royal peacock blue upholstery
    roughness: 0.85,
  });

  const cushionMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b, // warm marigold yellow cushions
    roughness: 0.75,
  });

  const grassMat = new THREE.MeshStandardMaterial({
    color: 0x4d7c0f, // rich garden lawn green
    roughness: 0.9,
  });

  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xd97706,
    metalness: 0.8,
    roughness: 0.25,
  });

  const terracottaMat = new THREE.MeshStandardMaterial({
    color: 0xb45309,
    roughness: 0.75,
  });

  // ==========================================
  // 1. FLOORS & FOUNDATION
  // ==========================================
  // Indoor Main Floor (Living Room + Kitchen + Study)
  const indoorFloorGeo = new THREE.BoxGeometry(32, 0.4, 16);
  const indoorFloor = new THREE.Mesh(indoorFloorGeo, floorMat);
  indoorFloor.position.set(0, -0.2, 8);
  indoorFloor.receiveShadow = true;
  root.add(indoorFloor);

  // Courtyard & Garden Floor (Outdoor Green Lawn)
  const gardenFloorGeo = new THREE.BoxGeometry(36, 0.4, 16);
  const gardenFloor = new THREE.Mesh(gardenFloorGeo, grassMat);
  gardenFloor.position.set(0, -0.2, -8);
  gardenFloor.receiveShadow = true;
  root.add(gardenFloor);

  // Stone paver path leading from courtyard to house entrance
  const pathGeo = new THREE.BoxGeometry(3.6, 0.42, 14);
  const pathMat = new THREE.MeshStandardMaterial({ color: 0xd6d3d1, roughness: 0.8 });
  const stonePath = new THREE.Mesh(pathGeo, pathMat);
  stonePath.position.set(0, -0.19, -7);
  stonePath.receiveShadow = true;
  root.add(stonePath);

  // ==========================================
  // 2. WALLS & ROOM SEPARATORS
  // ==========================================
  // Back Wall (Living Room south wall)
  const backWall = new THREE.Mesh(new THREE.BoxGeometry(32, 3.8, 0.4), wallMat);
  backWall.position.set(0, 1.9, 16);
  backWall.receiveShadow = true;
  root.add(backWall);
  addCollider(new THREE.Box3().setFromObject(backWall));

  // Left Outer Wall (West)
  const leftWall = new THREE.Mesh(new THREE.BoxGeometry(0.4, 3.8, 16), wallMat);
  leftWall.position.set(-16, 1.9, 8);
  leftWall.receiveShadow = true;
  root.add(leftWall);
  addCollider(new THREE.Box3().setFromObject(leftWall));

  // Right Outer Wall (East)
  const rightWall = new THREE.Mesh(new THREE.BoxGeometry(0.4, 3.8, 16), wallMat);
  rightWall.position.set(16, 1.9, 8);
  rightWall.receiveShadow = true;
  root.add(rightWall);
  addCollider(new THREE.Box3().setFromObject(rightWall));

  // Front Wall with grand archway to garden (Z = 0)
  // Left wing
  const frontLeft = new THREE.Mesh(new THREE.BoxGeometry(13.6, 3.8, 0.4), wallAccentMat);
  frontLeft.position.set(-9.2, 1.9, 0);
  frontLeft.castShadow = true;
  frontLeft.receiveShadow = true;
  root.add(frontLeft);
  addCollider(new THREE.Box3().setFromObject(frontLeft));

  // Right wing
  const frontRight = new THREE.Mesh(new THREE.BoxGeometry(13.6, 3.8, 0.4), wallAccentMat);
  frontRight.position.set(9.2, 1.9, 0);
  frontRight.castShadow = true;
  frontRight.receiveShadow = true;
  root.add(frontRight);
  addCollider(new THREE.Box3().setFromObject(frontRight));

  // Grand Indian Arch Header above entrance doorway
  const archHeader = new THREE.Mesh(new THREE.BoxGeometry(5.2, 1.0, 0.45), woodMat);
  archHeader.position.set(0, 3.3, 0);
  root.add(archHeader);

  // Entrance carved wooden pillars
  const pillarGeo = new THREE.CylinderGeometry(0.22, 0.26, 3.8, 16);
  const pillarL = new THREE.Mesh(pillarGeo, woodMat);
  pillarL.position.set(-2.4, 1.9, 0);
  pillarL.castShadow = true;
  root.add(pillarL);
  addCollider(new THREE.Box3().setFromObject(pillarL));

  const pillarR = new THREE.Mesh(pillarGeo, woodMat);
  pillarR.position.set(2.4, 1.9, 0);
  pillarR.castShadow = true;
  root.add(pillarR);
  addCollider(new THREE.Box3().setFromObject(pillarR));

  // Interior Room Dividers (Kitchen on West, Study on East, with arched openings)
  // Kitchen divider (X = -6)
  const kitchenWallA = new THREE.Mesh(new THREE.BoxGeometry(0.3, 3.8, 5.5), wallMat);
  kitchenWallA.position.set(-6, 1.9, 13.25);
  root.add(kitchenWallA);
  addCollider(new THREE.Box3().setFromObject(kitchenWallA));

  const kitchenWallB = new THREE.Mesh(new THREE.BoxGeometry(0.3, 3.8, 5.5), wallMat);
  kitchenWallB.position.set(-6, 1.9, 2.75);
  root.add(kitchenWallB);
  addCollider(new THREE.Box3().setFromObject(kitchenWallB));

  // Study divider (X = 6)
  const studyWallA = new THREE.Mesh(new THREE.BoxGeometry(0.3, 3.8, 5.5), wallMat);
  studyWallA.position.set(6, 1.9, 13.25);
  root.add(studyWallA);
  addCollider(new THREE.Box3().setFromObject(studyWallA));

  const studyWallB = new THREE.Mesh(new THREE.BoxGeometry(0.3, 3.8, 5.5), wallMat);
  studyWallB.position.set(6, 1.9, 2.75);
  root.add(studyWallB);
  addCollider(new THREE.Box3().setFromObject(studyWallB));

  // Courtyard Perimeter Garden Walls (North, West, East)
  const gardenNorthWall = new THREE.Mesh(new THREE.BoxGeometry(36, 2.4, 0.4), terracottaMat);
  gardenNorthWall.position.set(0, 1.2, -16);
  root.add(gardenNorthWall);
  addCollider(new THREE.Box3().setFromObject(gardenNorthWall));

  const gardenWestWall = new THREE.Mesh(new THREE.BoxGeometry(0.4, 2.4, 16), terracottaMat);
  gardenWestWall.position.set(-18, 1.2, -8);
  root.add(gardenWestWall);
  addCollider(new THREE.Box3().setFromObject(gardenWestWall));

  const gardenEastWall = new THREE.Mesh(new THREE.BoxGeometry(0.4, 2.4, 16), terracottaMat);
  gardenEastWall.position.set(18, 1.2, -8);
  root.add(gardenEastWall);
  addCollider(new THREE.Box3().setFromObject(gardenEastWall));

  // ==========================================
  // 3. LIVING ROOM (Center)
  // ==========================================
  // Rangoli Mandala Carpet in center
  const rugGeo = new THREE.PlaneGeometry(5.2, 5.2);
  const rugMat = new THREE.MeshStandardMaterial({
    map: rangoliTex,
    roughness: 0.9,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const rangoliRug = new THREE.Mesh(rugGeo, rugMat);
  rangoliRug.rotation.x = -Math.PI / 2;
  rangoliRug.position.set(0, 0.02, 8);
  root.add(rangoliRug);

  // Large Family Sofa (3-seater with armrests and cushions)
  const sofaGroup = new THREE.Group();
  sofaGroup.position.set(0, 0, 12);

  // Sofa Base & Seat
  const sofaSeat = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.48, 1.4), sofaFabricMat);
  sofaSeat.position.set(0, 0.4, 0);
  sofaSeat.castShadow = true;
  sofaSeat.receiveShadow = true;
  sofaGroup.add(sofaSeat);

  // Sofa Backrest
  const sofaBack = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.8, 0.35), sofaFabricMat);
  sofaBack.position.set(0, 0.9, 0.52);
  sofaBack.castShadow = true;
  sofaGroup.add(sofaBack);

  // Sofa Armrests (Left & Right)
  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.65, 1.4), sofaFabricMat);
  armL.position.set(-2.2, 0.6, 0);
  const armR = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.65, 1.4), sofaFabricMat);
  armR.position.set(2.2, 0.6, 0);
  sofaGroup.add(armL, armR);

  // Warm Yellow Cushions
  const c1 = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.5, 0.2), cushionMat);
  c1.position.set(-1.2, 0.8, 0.4);
  c1.rotation.y = 0.15;
  const c2 = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.5, 0.2), cushionMat);
  c2.position.set(1.2, 0.8, 0.4);
  c2.rotation.y = -0.15;
  sofaGroup.add(c1, c2);

  root.add(sofaGroup);
  addCollider(new THREE.Box3().setFromObject(sofaGroup));

  // Wooden Coffee Table
  const coffeeTable = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.42, 1.2), woodMat);
  coffeeTable.position.set(0, 0.21, 8);
  coffeeTable.castShadow = true;
  coffeeTable.receiveShadow = true;
  root.add(coffeeTable);
  addCollider(new THREE.Box3().setFromObject(coffeeTable));

  // TV Entertainment Unit on North-Living Wall
  const tvUnit = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.7, 0.8), woodMat);
  tvUnit.position.set(0, 0.35, 4.4);
  tvUnit.castShadow = true;
  root.add(tvUnit);
  addCollider(new THREE.Box3().setFromObject(tvUnit));

  // TV Screen
  const tvScreen = new THREE.Mesh(
    new THREE.BoxGeometry(3.0, 1.7, 0.12),
    new THREE.MeshStandardMaterial({
      map: tvScreenTex,
      roughness: 0.2,
      metalness: 0.3,
    })
  );
  tvScreen.position.set(0, 1.8, 4.4);
  tvScreen.castShadow = true;
  root.add(tvScreen);

  // Big "OUR HAPPY FAMILY" Wall Portrait on South Wall above Sofa
  const familyFrame = new THREE.Mesh(
    new THREE.BoxGeometry(3.6, 2.2, 0.08),
    new THREE.MeshStandardMaterial({
      map: portraitTex,
      roughness: 0.3,
    })
  );
  familyFrame.position.set(0, 2.4, 15.75);
  root.add(familyFrame);

  // Diya Lamp Stand (Traditional Indian Brass Samai)
  const diyaStand = new THREE.Group();
  diyaStand.position.set(-3.2, 0, 14.2);
  const diyaStem = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.12, 1.4, 12), brassMat);
  diyaStem.position.y = 0.7;
  const diyaBowl = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.1, 0.12, 12), brassMat);
  diyaBowl.position.y = 1.4;
  const flame = new THREE.Mesh(
    new THREE.ConeGeometry(0.06, 0.16, 8),
    new THREE.MeshBasicMaterial({ color: 0xfbbf24 })
  );
  flame.position.y = 1.54;
  diyaStand.add(diyaStem, diyaBowl, flame);
  root.add(diyaStand);
  addCollider(new THREE.Box3().setFromObject(diyaStand));

  // ==========================================
  // 4. KITCHEN & DINING ROOM (West Wing)
  // ==========================================
  // L-Shaped Kitchen Counter
  const kitchenCounterMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.2 }); // black granite
  const counterMain = new THREE.Mesh(new THREE.BoxGeometry(5.4, 0.9, 1.2), kitchenCounterMat);
  counterMain.position.set(-11, 0.45, 14.8);
  counterMain.castShadow = true;
  root.add(counterMain);
  addCollider(new THREE.Box3().setFromObject(counterMain));

  // Gas Stove with 3 burners & brass knobs
  const stove = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.14, 0.8), new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.7 }));
  stove.position.set(-11, 0.97, 14.8);
  root.add(stove);

  // Refrigerator (Chic Indian mint cream)
  const fridge = new THREE.Mesh(
    new THREE.BoxGeometry(1.3, 2.4, 1.2),
    new THREE.MeshStandardMaterial({ color: 0xe0f2fe, metalness: 0.4, roughness: 0.3 })
  );
  fridge.position.set(-14.8, 1.2, 14.8);
  fridge.castShadow = true;
  root.add(fridge);
  addCollider(new THREE.Box3().setFromObject(fridge));

  // Kitchen Upper Shelf (Spice rack)
  const spiceShelf = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.12, 0.5), woodMat);
  spiceShelf.position.set(-11, 2.1, 15.6);
  root.add(spiceShelf);

  // Dining Table with 4 Chairs
  const diningTable = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.82, 1.8), woodMat);
  diningTable.position.set(-11, 0.41, 6.5);
  diningTable.castShadow = true;
  root.add(diningTable);
  addCollider(new THREE.Box3().setFromObject(diningTable));

  // Fruit bowl on dining table
  const fruitBowl = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.15, 0.16, 12), brassMat);
  fruitBowl.position.set(-11, 0.9, 6.5);
  root.add(fruitBowl);

  // Dining Chairs
  const chairGeo = new THREE.BoxGeometry(0.5, 0.85, 0.5);
  const chairMat = new THREE.MeshStandardMaterial({ color: 0x9a3412, roughness: 0.7 });
  const chairPositions: [number, number, number][] = [
    [-11, 0.42, 5.0],
    [-11, 0.42, 8.0],
    [-12.8, 0.42, 6.5],
    [-9.2, 0.42, 6.5],
  ];
  chairPositions.forEach(([cx, cy, cz]) => {
    const chair = new THREE.Mesh(chairGeo, chairMat);
    chair.position.set(cx, cy, cz);
    chair.castShadow = true;
    root.add(chair);
    addCollider(new THREE.Box3().setFromObject(chair));
  });

  // ==========================================
  // 5. STUDY & KIDS ROOM (East Wing)
  // ==========================================
  // Wooden Study Desk (Dad's study / Ayush homework corner)
  const studyDesk = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.85, 1.4), woodMat);
  studyDesk.position.set(11, 0.42, 14.8);
  studyDesk.castShadow = true;
  root.add(studyDesk);
  addCollider(new THREE.Box3().setFromObject(studyDesk));

  // Study Bookshelf with colorful books
  const bookshelf = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.6, 0.6), woodMat);
  bookshelf.position.set(14.8, 1.3, 11);
  bookshelf.castShadow = true;
  root.add(bookshelf);
  addCollider(new THREE.Box3().setFromObject(bookshelf));

  // Colorful Kids Bunk Bed
  const bedGroup = new THREE.Group();
  bedGroup.position.set(11, 0, 5.5);
  const bedFrame = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.8, 3.6), woodMat);
  bedFrame.position.set(0, 0.9, 0);
  const mattressLower = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.25, 3.2), new THREE.MeshStandardMaterial({ color: 0x38bdf8 }));
  mattressLower.position.set(0, 0.45, 0);
  const mattressUpper = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.25, 3.2), new THREE.MeshStandardMaterial({ color: 0xf43f5e }));
  mattressUpper.position.set(0, 1.55, 0);
  bedGroup.add(bedFrame, mattressLower, mattressUpper);
  bedGroup.castShadow = true;
  root.add(bedGroup);
  addCollider(new THREE.Box3().setFromObject(bedGroup));

  // Toy Box
  const toyBox = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.6, 0.8), new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.5 }));
  toyBox.position.set(8.5, 0.3, 9.5);
  toyBox.castShadow = true;
  root.add(toyBox);
  addCollider(new THREE.Box3().setFromObject(toyBox));

  // ==========================================
  // 6. COURTYARD & GARDEN (Outdoor)
  // ==========================================
  // Sacred Tulsi Planter (Traditional Vrindavan Pedestal in center-left garden)
  const tulsiGroup = new THREE.Group();
  tulsiGroup.position.set(-6, 0, -8);

  const tulsiPedestal = new THREE.Mesh(
    new THREE.CylinderGeometry(0.48, 0.58, 0.95, 8),
    new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.85 })
  );
  tulsiPedestal.position.y = 0.475;
  tulsiPedestal.castShadow = true;

  const tulsiPot = new THREE.Mesh(
    new THREE.CylinderGeometry(0.42, 0.35, 0.4, 8),
    terracottaMat
  );
  tulsiPot.position.y = 1.15;

  const tulsiFoliage = new THREE.Mesh(
    new THREE.SphereGeometry(0.38, 12, 12),
    new THREE.MeshStandardMaterial({ color: 0x166534, roughness: 0.9 })
  );
  tulsiFoliage.position.y = 1.5;

  tulsiGroup.add(tulsiPedestal, tulsiPot, tulsiFoliage);
  root.add(tulsiGroup);
  addCollider(new THREE.Box3().setFromObject(tulsiGroup));

  // Traditional Indian Wooden Swing (Jhoola with carved teak seat & brass chains)
  const jhoolaGroup = new THREE.Group();
  jhoolaGroup.position.set(6, 0, -8);

  // A-Frame Wooden Pillars
  const framePillarMat = woodMat;
  const pillarGeoA = new THREE.CylinderGeometry(0.1, 0.12, 2.8, 8);
  const lp1 = new THREE.Mesh(pillarGeoA, framePillarMat);
  lp1.position.set(-1.6, 1.4, -0.6);
  lp1.rotation.x = 0.2;
  const lp2 = new THREE.Mesh(pillarGeoA, framePillarMat);
  lp2.position.set(-1.6, 1.4, 0.6);
  lp2.rotation.x = -0.2;

  const rp1 = new THREE.Mesh(pillarGeoA, framePillarMat);
  rp1.position.set(1.6, 1.4, -0.6);
  rp1.rotation.x = 0.2;
  const rp2 = new THREE.Mesh(pillarGeoA, framePillarMat);
  rp2.position.set(1.6, 1.4, 0.6);
  rp2.rotation.x = -0.2;

  const topBeam = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 3.6, 8), framePillarMat);
  topBeam.position.set(0, 2.7, 0);
  topBeam.rotation.z = Math.PI / 2;

  // Hanging Seat
  const swingSeat = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.1, 0.8), woodMat);
  swingSeat.position.set(0, 0.6, 0);

  // Brass Chains
  const chainL = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 2.0, 6), brassMat);
  chainL.position.set(-0.9, 1.65, 0);
  const chainR = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 2.0, 6), brassMat);
  chainR.position.set(0.9, 1.65, 0);

  jhoolaGroup.add(lp1, lp2, rp1, rp2, topBeam, swingSeat, chainL, chainR);
  jhoolaGroup.castShadow = true;
  root.add(jhoolaGroup);
  addCollider(new THREE.Box3().setFromObject(jhoolaGroup));

  // Flowering Marigold Bushes in Garden (Composite 4 parts: stem + leaves + orange/yellow flowers)
  const bushPositions: [number, number, number][] = [
    [-12, 0, -12],
    [-8, 0, -14],
    [-3, 0, -13],
    [3, 0, -13],
    [10, 0, -14],
    [13, 0, -11],
    [-14, 0, -5],
    [14, 0, -5],
  ];

  const leafMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.85 });
  const marigoldMat1 = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.6 });
  const marigoldMat2 = new THREE.MeshStandardMaterial({ color: 0xe11d48, roughness: 0.6 });

  bushPositions.forEach(([bx, by, bz], idx) => {
    const bush = new THREE.Group();
    bush.position.set(bx, by, bz);

    const foliage = new THREE.Mesh(new THREE.SphereGeometry(0.65 + (idx % 3) * 0.1, 10, 10), leafMat);
    foliage.position.y = 0.55;
    foliage.castShadow = true;
    bush.add(foliage);

    // Cute marigold flowers
    for (let f = 0; f < 5; f++) {
      const flower = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 6), f % 2 === 0 ? marigoldMat1 : marigoldMat2);
      const angle = (f * Math.PI * 2) / 5;
      flower.position.set(Math.cos(angle) * 0.5, 0.6 + Math.sin(angle) * 0.2, Math.sin(angle) * 0.5);
      bush.add(flower);
    }

    root.add(bush);
    addCollider(new THREE.Box3().setFromObject(bush));
  });

  // ==========================================
  // 7. ROOFTOP TERRACE & STAIRCASE (Upstairs)
  // ==========================================
  // Staircase leading from Garden East side to Rooftop
  // 8 steps
  const stepMat = new THREE.MeshStandardMaterial({ color: 0x78716c, roughness: 0.7 });
  for (let s = 0; s < 8; s++) {
    const step = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.45 * (s + 1), 1.0), stepMat);
    step.position.set(15, 0.225 * (s + 1), 0 - s * 0.9);
    step.receiveShadow = true;
    step.castShadow = true;
    root.add(step);
    addCollider(new THREE.Box3().setFromObject(step));
  }

  // Rooftop Slab (above Living Room & Study, Y = 3.8)
  const roofSlab = new THREE.Mesh(
    new THREE.BoxGeometry(32, 0.35, 16),
    new THREE.MeshStandardMaterial({ color: 0xc2410c, roughness: 0.7 }) // terracotta roof tiles
  );
  roofSlab.position.set(0, 3.8, 8);
  roofSlab.receiveShadow = true;
  root.add(roofSlab);
  // Add collider for the roof platform itself so Ayush can stand on it!
  addCollider(new THREE.Box3(new THREE.Vector3(-16, 3.6, 0), new THREE.Vector3(16, 4.0, 16)));

  // Rooftop Parapet Wall (safety edge railing)
  const parapetMat = terracottaMat;
  const parapetSouth = new THREE.Mesh(new THREE.BoxGeometry(32, 0.9, 0.3), parapetMat);
  parapetSouth.position.set(0, 4.25, 16);
  root.add(parapetSouth);
  addCollider(new THREE.Box3().setFromObject(parapetSouth));

  const parapetWest = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.9, 16), parapetMat);
  parapetWest.position.set(-16, 4.25, 8);
  root.add(parapetWest);
  addCollider(new THREE.Box3().setFromObject(parapetWest));

  const parapetNorth = new THREE.Mesh(new THREE.BoxGeometry(28, 0.9, 0.3), parapetMat);
  parapetNorth.position.set(-2, 4.25, 0);
  root.add(parapetNorth);
  addCollider(new THREE.Box3().setFromObject(parapetNorth));

  // Rooftop Overhead Water Tank (Sintex style black cylindrical water tank)
  const waterTank = new THREE.Mesh(
    new THREE.CylinderGeometry(1.1, 1.1, 1.8, 16),
    new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.4 })
  );
  waterTank.position.set(-12, 4.9, 12);
  waterTank.castShadow = true;
  root.add(waterTank);
  addCollider(new THREE.Box3().setFromObject(waterTank));

  // Clothesline with colorful waving laundry cloths on Rooftop
  const linePillar1 = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.8, 8), brassMat);
  linePillar1.position.set(-6, 4.8, 6);
  const linePillar2 = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.8, 8), brassMat);
  linePillar2.position.set(4, 4.8, 6);
  root.add(linePillar1, linePillar2);

  const clothesLine = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 10, 6), brassMat);
  clothesLine.position.set(-1, 5.5, 6);
  clothesLine.rotation.z = Math.PI / 2;
  root.add(clothesLine);

  // Colorful laundry clothes (Kurta, Sari, T-shirt)
  const clothColors = [0xef4444, 0x3b82f6, 0x10b981, 0xf59e0b];
  clothColors.forEach((color, i) => {
    const cloth = new THREE.Mesh(
      new THREE.PlaneGeometry(0.8, 1.1),
      new THREE.MeshStandardMaterial({ color, roughness: 0.8, side: THREE.DoubleSide })
    );
    cloth.position.set(-4 + i * 2.2, 4.9, 6);
    cloth.rotation.y = 0.1;
    root.add(cloth);
  });

  // Indian Flying Kite (Patang) propped on the parapet
  const kiteMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.5 });
  const kite = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.8, 0.02), kiteMat);
  kite.position.set(2, 4.6, 15.8);
  kite.rotation.z = Math.PI / 4;
  kite.rotation.x = 0.2;
  root.add(kite);

  return { group: root, colliders, interactableSpots };
}
