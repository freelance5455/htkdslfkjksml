/** All tunables for Lago Dourado — edit here, not scattered in update/render. */

export const WORLD = {
  w: 360,
  h: 640,
} as const

export const PLAYER = {
  speed: 120,
  radius: 14,
  // Start on the path, safely above the lake.
  startX: 178,
  startY: 330,
  drawSize: 68,
} as const

/** Zones in world coordinates, matched to the 360×640 game map. */
export const ZONES = {
  /**
   * The lake shoreline is irregular, so a rectangle is not enough:
   * waterPolygon describes the visible water area clockwise.
   */
  waterPolygon: [
    { x: 86, y: 365 },
    { x: 148, y: 358 },
    { x: 202, y: 365 },
    { x: 238, y: 385 },
    { x: 276, y: 398 },
    { x: 310, y: 425 },
    { x: 336, y: 455 },
    { x: 360, y: 455 },
    { x: 360, y: 640 },
    { x: 0, y: 640 },
    { x: 0, y: 500 },
    { x: 40, y: 485 },
    { x: 58, y: 450 },
    { x: 62, y: 415 },
  ] as const,

  /** Wooden dock: it sits over the lake but is solid and walkable. */
  dock: { x: 205, y: 360, w: 105, h: 140 },

  /** Land strip at the lake edge where the fishing action is allowed. */
  shore: { x: 150, y: 345, w: 95, h: 55 },

  /** Market stall interact zone (awning on the right). */
  stall: { x: 230, y: 150, w: 100, h: 90 },

  /** Soft walk bounds (keep player on the actual map). */
  land: { x: 18, y: 70, w: 324, h: 540 },
} as const

export const FISHING = {
  biteDelayMin: 0.7,
  biteDelayMax: 1.6,
  barSpeed: 1.35, // cycles per second across the bar
  /** Green window half-width as fraction of bar (0.5 = full). */
  windowByBait: [0.22, 0.28, 0.34] as const,
  /** Chance weights [common, rare, legend] by bait tier 0..2 */
  weightsByBait: [
    [0.78, 0.2, 0.02],
    [0.55, 0.35, 0.1],
    [0.3, 0.45, 0.25],
  ] as const,
} as const

export const ECONOMY = {
  startGold: 15,
  startBait: 5,
  baitCost: [0, 12, 28] as const, // upgrade to tier 1 / 2
  fishValue: { common: 6, rare: 16, legend: 45 } as const,
  maxBait: 20,
} as const

export const FISH_META = {
  common: { key: 'fish_common', label: 'Peixe Azul', color: '#6ec6ff' },
  rare: { key: 'fish_rare', label: 'Peixe Dourado', color: '#f4a261' },
  legend: { key: 'fish_legend', label: 'Peixe Lenda', color: '#c77dff' },
} as const

export type FishKind = keyof typeof FISH_META

export const PALETTE = {
  sky: '#173a6a',
  grass: '#817d37',
  dirt: '#65402a',
  amber: '#d78f56',
  lake: '#445d69',
  uiBg: 'rgba(20, 24, 32, 0.72)',
  uiBorder: '#d78f56',
  text: '#fff8e7',
  textDim: '#c9b896',
  green: '#7dce82',
  red: '#e76f51',
  gold: '#f4d35e',
} as const

export const JOYSTICK = {
  baseR: 52,
  knobR: 24,
  margin: 18,
  dead: 0.18,
} as const

export const ACTION_BTN = {
  r: 40,
  margin: 22,
} as const

export const STORAGE_KEY = 'lago-dourado-v1'
