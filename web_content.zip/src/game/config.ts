/**
 * All gameplay tuning in one place. Units: metres, seconds, radians.
 * Tests read the same values so rule changes stay covered.
 */
export const DEFAULT_CONFIG = {
  flight: {
    /** Speed with the throttle fully closed / fully open (m/s). */
    minSpeed: 42,
    maxSpeed: 150,
    /** Below this speed the nose drops and control fades (m/s). */
    stallSpeed: 30,
    /** How quickly the speed follows the throttle (1/s). */
    accel: 0.55,
    /** Extra speed gained diving / lost climbing (m/s² per unit of slope). */
    energy: 26,
    /** Maximum pitch rate at full stick (rad/s). */
    pitchRate: 1.1,
    /** Maximum roll rate at full stick (rad/s). */
    rollRate: 2.5,
    /** Heading change per second for a 90° bank (rad/s). */
    turnRate: 0.85,
    /** Automatic wing levelling when the stick is released (1/s). */
    levelling: 1.5,
    /** Highest altitude before the engine fades out (m). */
    ceiling: 2500,
  },
  camera: {
    distance: 27,
    height: 7.5,
    follow: 6.5,
    fov: 64,
  },
  rings: {
    radius: 38,
    spacing: 560,
    points: 100,
    perfectBonus: 50,
  },
  world: {
    /** Chunk edge in metres. */
    chunk: 640,
    /** Metres above the terrain where each run starts. */
    startHeight: 260,
  },
} as const

// Gameplay always reads active values here. Source defaults remain immutable for
// Tweak Reset and Save with Manus; Apply never writes source or local storage.
type MutableConfig<T> = { -readonly [K in keyof T]: T[K] extends number ? number : T[K] extends object ? MutableConfig<T[K]> : T[K] }
export const CONFIG: MutableConfig<typeof DEFAULT_CONFIG> = structuredClone(DEFAULT_CONFIG)
