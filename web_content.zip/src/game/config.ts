// ── Tunables for Polvo Pintor ──

export const GAME_NAME = 'Polvo Pintor'
export const HS_KEY = 'polvo-pintor-highscore'

export const PALETTE = {
  ink: '#5c332b',
  paint: '#ff6bcb',
  paintAlt: '#5ce1ff',
  paintGold: '#ffd56b',
  stain: '#3d1a5c',
  hud: '#fff4e0',
  hudDim: '#c9a88a',
  danger: '#ff4d6d',
  good: '#7dffb3',
  overlay: 'rgba(42, 22, 18, 0.72)',
  barBg: 'rgba(0,0,0,0.45)',
  canvasBase: '#fffff3',
} as const

export const POLVO_SIZE = 72
export const BRUSH_RADIUS = 26
export const STAIN_SIZE = 52
export const STAIN_RADIUS = 30

/** Offscreen paint buffer resolution (lower = faster coverage check). */
export const PAINT_COLS = 72
export const PAINT_ROWS = 128

export const FAIL_COVERAGE = 0.18
export const START_COVERAGE_GRACE = 10 // seconds before fail can trigger

export const SCORE_PER_CELL = 1
export const COMBO_STEP = 18 // cells painted in a streak before combo++
export const MAX_COMBO = 8

export const STAIN_BASE_INTERVAL = 2.0
export const STAIN_MIN_INTERVAL = 0.5
export const STAIN_RAMP = 0.9 // every minute

export const TRAUMA_STAIN = 0.25
export const TRAUMA_DEATH = 0.7
export const TRAUMA_COMBO = 0.12

export const INK_COLORS = [PALETTE.paint, PALETTE.paintAlt, PALETTE.paintGold] as const
export const COLOR_CYCLE_EVERY = 12 // seconds
