// Pixel Art Generator and Sprite Cache
// Pure pixel-perfect Canvas-rendered sprite sheets matching Nature TileMegaPack and retro 16-bit aesthetic.

import { Direction, ItemId } from '../types/game';

type CanvasImage = HTMLCanvasElement;

export interface SpriteAssetInfo {
  id: string;
  name: string;
  category: 'player' | 'tiles' | 'environment' | 'enemies' | 'items' | 'structures';
  width: number;
  height: number;
  frames: number;
  usedInGame: boolean;
  canvas: CanvasImage;
}

class SpriteRegistry {
  private cache: Map<string, CanvasImage> = new Map();
  public assetList: SpriteAssetInfo[] = [];

  // Helper to create an offscreen canvas with imageSmoothing disabled
  public createCanvas(w: number, h: number): [CanvasImage, CanvasRenderingContext2D] {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    return [c, ctx];
  }

  // Draw pixel grid from ascii / color map
  private drawPixelMatrix(
    ctx: CanvasRenderingContext2D,
    matrix: string[],
    colorMap: Record<string, string>,
    scale: number = 2,
    offsetX: number = 0,
    offsetY: number = 0
  ) {
    for (let y = 0; y < matrix.length; y++) {
      const row = matrix[y];
      for (let x = 0; x < row.length; x++) {
        const char = row[x];
        const color = colorMap[char];
        if (color && color !== 'transparent') {
          ctx.fillStyle = color;
          ctx.fillRect(offsetX + x * scale, offsetY + y * scale, scale, scale);
        }
      }
    }
  }

  public init() {
    if (this.assetList.length > 0) return; // already initialized

    this.initTiles();
    this.initEnvironment();
    this.initPlayer();
    this.initEnemies();
    this.initItems();
    this.initStructures();
  }

  // TILES (32x32)
  private initTiles() {
    // 1. Grass Tile
    const [grassCanvas, gCtx] = this.createCanvas(32, 32);
    gCtx.fillStyle = '#4f8a28';
    gCtx.fillRect(0, 0, 32, 32);
    // Subtle pixel blade highlights
    gCtx.fillStyle = '#5ca330';
    [[4,4], [12,8], [24,6], [8,18], [20,22], [28,26], [14,28]].forEach(([x, y]) => {
      gCtx.fillRect(x, y, 2, 4);
      gCtx.fillRect(x + 1, y - 1, 2, 3);
    });
    gCtx.fillStyle = '#3f7220';
    [[6,12], [18,14], [26,16], [2,24], [16,6]].forEach(([x, y]) => {
      gCtx.fillRect(x, y, 3, 2);
    });
    this.registerAsset('tile_grass', 'Grass Tile', 'tiles', 32, 32, 1, grassCanvas);

    // 2. Dense Grass / Dark Meadow Tile
    const [denseGrass, dgCtx] = this.createCanvas(32, 32);
    dgCtx.fillStyle = '#396d1b';
    dgCtx.fillRect(0, 0, 32, 32);
    dgCtx.fillStyle = '#488722';
    [[2, 6], [16, 4], [24, 12], [8, 20], [22, 26]].forEach(([x, y]) => {
      dgCtx.fillRect(x, y, 4, 3);
    });
    dgCtx.fillStyle = '#2b5214';
    [[10, 10], [20, 18], [6, 26], [28, 6]].forEach(([x, y]) => {
      dgCtx.fillRect(x, y, 3, 3);
    });
    this.registerAsset('tile_grass_dense', 'Dense Grass', 'tiles', 32, 32, 1, denseGrass);

    // 3. Dirt / Earth Path Tile
    const [dirtCanvas, dCtx] = this.createCanvas(32, 32);
    dCtx.fillStyle = '#7a5230';
    dCtx.fillRect(0, 0, 32, 32);
    dCtx.fillStyle = '#8f6139';
    [[3, 5], [14, 11], [22, 4], [9, 21], [25, 23], [16, 27]].forEach(([x, y]) => {
      dCtx.fillRect(x, y, 3, 3);
    });
    dCtx.fillStyle = '#5e3e23';
    [[8, 8], [19, 15], [5, 27], [27, 10], [12, 18]].forEach(([x, y]) => {
      dCtx.fillRect(x, y, 3, 2);
    });
    this.registerAsset('tile_dirt', 'Dirt Path', 'tiles', 32, 32, 1, dirtCanvas);

    // 4. Sand Tile
    const [sandCanvas, sCtx] = this.createCanvas(32, 32);
    sCtx.fillStyle = '#d9b66c';
    sCtx.fillRect(0, 0, 32, 32);
    sCtx.fillStyle = '#ecd18e';
    [[4, 6], [18, 10], [10, 24], [26, 18], [22, 28]].forEach(([x, y]) => {
      sCtx.fillRect(x, y, 3, 2);
    });
    sCtx.fillStyle = '#be9d52';
    [[12, 14], [24, 6], [6, 18], [16, 26]].forEach(([x, y]) => {
      sCtx.fillRect(x, y, 2, 2);
    });
    this.registerAsset('tile_sand', 'Sand Shore', 'tiles', 32, 32, 1, sandCanvas);

    // 5. Water Tile (Animated 4 frames in 128x32 strip with rich waves, glints, and foam)
    const [waterCanvas, wCtx] = this.createCanvas(128, 32);
    for (let f = 0; f < 4; f++) {
      const ox = f * 32;
      // Deep base water
      wCtx.fillStyle = '#1e6091';
      wCtx.fillRect(ox, 0, 32, 32);

      // Midtone water current
      wCtx.fillStyle = '#2978b5';
      wCtx.fillRect(ox, 2, 32, 28);

      // Wave shifting highlights
      wCtx.fillStyle = '#489fd9';
      const offset = f * 7;
      wCtx.fillRect(ox + ((4 + offset) % 32), 6, 10, 2);
      wCtx.fillRect(ox + ((18 + offset) % 32), 14, 11, 2);
      wCtx.fillRect(ox + ((2 + offset) % 32), 22, 9, 2);

      // Sharp white/cyan specular wave crest glints
      wCtx.fillStyle = '#dbeafe';
      wCtx.fillRect(ox + ((7 + offset) % 32), 5, 4, 1);
      wCtx.fillRect(ox + ((21 + offset) % 32), 13, 5, 1);
      wCtx.fillRect(ox + ((5 + offset) % 32), 21, 3, 1);

      // Deep water crest shadow
      wCtx.fillStyle = '#184e77';
      wCtx.fillRect(ox + ((9 + offset) % 32), 8, 8, 2);
      wCtx.fillRect(ox + ((22 + offset) % 32), 16, 8, 2);
      wCtx.fillRect(ox + ((8 + offset) % 32), 24, 6, 2);
    }
    this.registerAsset('tile_water', 'Water (Animated 4F)', 'tiles', 32, 32, 4, waterCanvas);

    // 6. Deep Water Tile
    const [deepWater, dwCtx] = this.createCanvas(32, 32);
    dwCtx.fillStyle = '#174773';
    dwCtx.fillRect(0, 0, 32, 32);
    dwCtx.fillStyle = '#1f598e';
    dwCtx.fillRect(4, 8, 12, 3);
    dwCtx.fillRect(16, 20, 10, 3);
    this.registerAsset('tile_deep_water', 'Deep Abyss Water', 'tiles', 32, 32, 1, deepWater);

    // 7. Stone Path / Cobblestone
    const [cobble, cCtx] = this.createCanvas(32, 32);
    cCtx.fillStyle = '#5a5e66';
    cCtx.fillRect(0, 0, 32, 32);
    cCtx.fillStyle = '#7a7e87';
    [[2, 2, 12, 10], [16, 2, 14, 8], [2, 14, 10, 14], [14, 12, 16, 10], [14, 24, 16, 6]].forEach(([x, y, w, h]) => {
      cCtx.fillRect(x, y, w, h);
    });
    cCtx.fillStyle = '#3e4147';
    cCtx.strokeRect(2.5, 2.5, 11, 9);
    cCtx.strokeRect(16.5, 2.5, 13, 7);
    this.registerAsset('tile_stone_path', 'Cobblestone Road', 'tiles', 32, 32, 1, cobble);

    // 8. Cave Floor
    const [caveFloor, cfCtx] = this.createCanvas(32, 32);
    cfCtx.fillStyle = '#222329';
    cfCtx.fillRect(0, 0, 32, 32);
    cfCtx.fillStyle = '#32343d';
    [[4, 6], [18, 14], [10, 24], [24, 20]].forEach(([x, y]) => {
      cfCtx.fillRect(x, y, 4, 3);
    });
    this.registerAsset('tile_cave_floor', 'Cave Dungeon Floor', 'tiles', 32, 32, 1, caveFloor);
  }

  // ENVIRONMENT / RESOURCE NODES
  private initEnvironment() {
    // 1. Oak Tree (48 x 64) - Lush rounded leafy canopy with trunk
    const [oakTree, otCtx] = this.createCanvas(48, 64);
    // Tree shadow
    otCtx.fillStyle = 'rgba(0, 0, 0, 0.28)';
    otCtx.beginPath();
    otCtx.ellipse(24, 58, 18, 6, 0, 0, Math.PI * 2);
    otCtx.fill();
    // Trunk
    otCtx.fillStyle = '#5a3d1f';
    otCtx.fillRect(20, 36, 8, 22);
    otCtx.fillStyle = '#7a532d';
    otCtx.fillRect(22, 36, 4, 22);
    otCtx.fillStyle = '#3d2813';
    otCtx.fillRect(19, 54, 3, 5);
    otCtx.fillRect(26, 54, 4, 5);
    // Foliage layers (3D round pixel puffs)
    otCtx.fillStyle = '#255e1b'; // Dark shadow leaves
    otCtx.beginPath();
    otCtx.arc(24, 24, 20, 0, Math.PI * 2);
    otCtx.fill();
    otCtx.fillStyle = '#3c8524'; // Midtone leaves
    otCtx.beginPath();
    otCtx.arc(22, 22, 18, 0, Math.PI * 2);
    otCtx.fill();
    otCtx.fillStyle = '#55ad32'; // Highlight leaves
    otCtx.beginPath();
    otCtx.arc(18, 18, 12, 0, Math.PI * 2);
    otCtx.fill();
    otCtx.beginPath();
    otCtx.arc(28, 16, 10, 0, Math.PI * 2);
    otCtx.fill();
    // Light top tips
    otCtx.fillStyle = '#7be04a';
    otCtx.fillRect(14, 10, 6, 4);
    otCtx.fillRect(26, 12, 5, 3);
    this.registerAsset('tree_oak', 'Oak Tree', 'environment', 48, 64, 1, oakTree);

    // 2. Pine Tree (40 x 60) - Triangular Conifer
    const [pineTree, ptCtx] = this.createCanvas(40, 60);
    // Shadow
    ptCtx.fillStyle = 'rgba(0, 0, 0, 0.28)';
    ptCtx.beginPath();
    ptCtx.ellipse(20, 56, 14, 5, 0, 0, Math.PI * 2);
    ptCtx.fill();
    // Trunk
    ptCtx.fillStyle = '#4a2f18';
    ptCtx.fillRect(17, 44, 6, 14);
    // Layer 3 (bottom broad)
    ptCtx.fillStyle = '#1a472a';
    ptCtx.beginPath();
    ptCtx.moveTo(4, 46);
    ptCtx.lineTo(20, 32);
    ptCtx.lineTo(36, 46);
    ptCtx.fill();
    ptCtx.fillStyle = '#2d6a3f';
    ptCtx.beginPath();
    ptCtx.moveTo(8, 44);
    ptCtx.lineTo(20, 32);
    ptCtx.lineTo(32, 44);
    ptCtx.fill();
    // Layer 2 (middle)
    ptCtx.fillStyle = '#1a472a';
    ptCtx.beginPath();
    ptCtx.moveTo(8, 34);
    ptCtx.lineTo(20, 20);
    ptCtx.lineTo(32, 34);
    ptCtx.fill();
    ptCtx.fillStyle = '#2d6a3f';
    ptCtx.beginPath();
    ptCtx.moveTo(11, 32);
    ptCtx.lineTo(20, 20);
    ptCtx.lineTo(29, 32);
    ptCtx.fill();
    // Layer 1 (top tip)
    ptCtx.fillStyle = '#1a472a';
    ptCtx.beginPath();
    ptCtx.moveTo(12, 22);
    ptCtx.lineTo(20, 6);
    ptCtx.lineTo(28, 22);
    ptCtx.fill();
    ptCtx.fillStyle = '#408754';
    ptCtx.beginPath();
    ptCtx.moveTo(15, 20);
    ptCtx.lineTo(20, 8);
    ptCtx.lineTo(25, 20);
    ptCtx.fill();
    this.registerAsset('tree_pine', 'Pine Tree', 'environment', 40, 60, 1, pineTree);

    // 3. Birch Tree (36 x 60) - White trunk with black markings
    const [birchTree, btCtx] = this.createCanvas(36, 60);
    // Shadow
    btCtx.fillStyle = 'rgba(0, 0, 0, 0.25)';
    btCtx.beginPath();
    btCtx.ellipse(18, 56, 12, 5, 0, 0, Math.PI * 2);
    btCtx.fill();
    // Slender white trunk
    btCtx.fillStyle = '#dedede';
    btCtx.fillRect(16, 28, 4, 28);
    btCtx.fillStyle = '#222';
    btCtx.fillRect(16, 34, 3, 2);
    btCtx.fillRect(17, 42, 3, 2);
    btCtx.fillRect(16, 50, 4, 2);
    // Canopy
    btCtx.fillStyle = '#457a2c';
    btCtx.beginPath();
    btCtx.ellipse(18, 18, 14, 16, 0, 0, Math.PI * 2);
    btCtx.fill();
    btCtx.fillStyle = '#6ab840';
    btCtx.beginPath();
    btCtx.ellipse(16, 15, 11, 12, 0, 0, Math.PI * 2);
    btCtx.fill();
    btCtx.fillStyle = '#8ce851';
    btCtx.fillRect(12, 8, 6, 4);
    btCtx.fillRect(16, 12, 5, 4);
    this.registerAsset('tree_birch', 'Birch Tree', 'environment', 36, 60, 1, birchTree);

    // 4. Stone Boulder (32 x 32)
    const [rockCanvas, rCtx] = this.createCanvas(32, 32);
    rCtx.fillStyle = 'rgba(0, 0, 0, 0.28)';
    rCtx.beginPath();
    rCtx.ellipse(16, 26, 14, 5, 0, 0, Math.PI * 2);
    rCtx.fill();
    // Rock body
    rCtx.fillStyle = '#4f555e';
    rCtx.beginPath();
    rCtx.ellipse(16, 18, 13, 10, 0, 0, Math.PI * 2);
    rCtx.fill();
    rCtx.fillStyle = '#78828f';
    rCtx.beginPath();
    rCtx.ellipse(14, 15, 10, 7, 0, 0, Math.PI * 2);
    rCtx.fill();
    rCtx.fillStyle = '#9eaaba';
    rCtx.fillRect(9, 11, 6, 3);
    rCtx.fillRect(12, 14, 4, 3);
    this.registerAsset('rock', 'Stone Boulder', 'environment', 32, 32, 1, rockCanvas);

    // 5. Iron Ore Rock (32 x 32) - Rock with metallic orange/gold veins
    const [ironRock, irCtx] = this.createCanvas(32, 32);
    irCtx.drawImage(rockCanvas, 0, 0);
    // Iron ore veins
    irCtx.fillStyle = '#d47833';
    irCtx.fillRect(8, 14, 4, 3);
    irCtx.fillRect(18, 12, 5, 3);
    irCtx.fillRect(14, 19, 4, 3);
    irCtx.fillStyle = '#f5ab62';
    irCtx.fillRect(9, 14, 2, 2);
    irCtx.fillRect(19, 12, 2, 2);
    this.registerAsset('rock_iron', 'Iron Ore Vein', 'environment', 32, 32, 1, ironRock);

    // 6. Coal Rock (32 x 32) - Rock with deep glossy black chunks
    const [coalRock, crCtx] = this.createCanvas(32, 32);
    crCtx.drawImage(rockCanvas, 0, 0);
    crCtx.fillStyle = '#1c1c1f';
    crCtx.fillRect(10, 13, 5, 4);
    crCtx.fillRect(18, 16, 4, 4);
    crCtx.fillRect(12, 20, 5, 3);
    crCtx.fillStyle = '#3a3a42';
    crCtx.fillRect(11, 14, 2, 2);
    crCtx.fillRect(19, 17, 2, 2);
    this.registerAsset('rock_coal', 'Coal Rock Deposit', 'environment', 32, 32, 1, coalRock);

    // 7. Berry Bush (32 x 32)
    const [berryBush, bbCtx] = this.createCanvas(32, 32);
    bbCtx.fillStyle = 'rgba(0, 0, 0, 0.25)';
    bbCtx.beginPath();
    bbCtx.ellipse(16, 25, 12, 5, 0, 0, Math.PI * 2);
    bbCtx.fill();
    // Bush greenery
    bbCtx.fillStyle = '#1f5922';
    bbCtx.beginPath();
    bbCtx.arc(16, 16, 12, 0, Math.PI * 2);
    bbCtx.fill();
    bbCtx.fillStyle = '#328237';
    bbCtx.beginPath();
    bbCtx.arc(14, 14, 10, 0, Math.PI * 2);
    bbCtx.fill();
    // Purple/blue berries
    bbCtx.fillStyle = '#7a288a';
    [[8, 12], [14, 8], [20, 11], [11, 18], [18, 17], [23, 16]].forEach(([x, y]) => {
      bbCtx.beginPath();
      bbCtx.arc(x, y, 2.5, 0, Math.PI * 2);
      bbCtx.fill();
    });
    bbCtx.fillStyle = '#c762db';
    [[8, 11], [14, 7], [20, 10], [18, 16]].forEach(([x, y]) => {
      bbCtx.fillRect(x, y, 1.5, 1.5);
    });
    this.registerAsset('bush_berry', 'Wild Berry Bush', 'environment', 32, 32, 1, berryBush);

    // 8. Flowers Patch (24 x 24)
    const [flowerCanvas, flCtx] = this.createCanvas(24, 24);
    flCtx.fillStyle = '#3b872b';
    flCtx.fillRect(6, 12, 2, 6);
    flCtx.fillRect(14, 10, 2, 8);
    flCtx.fillRect(18, 14, 2, 6);
    // Flower petals (red, yellow, cyan)
    flCtx.fillStyle = '#e83838';
    flCtx.fillRect(4, 9, 6, 5);
    flCtx.fillStyle = '#fce303';
    flCtx.fillRect(13, 7, 5, 5);
    flCtx.fillStyle = '#03c2fc';
    flCtx.fillRect(17, 11, 5, 5);
    this.registerAsset('flower', 'Wildflowers', 'environment', 24, 24, 1, flowerCanvas);
  }

  // PLAYER SPRITES: 4 Directions x (Idle, Walk 2F, Attack, Hurt, Death)
  private initPlayer() {
    const directions: Direction[] = ['down', 'up', 'left', 'right'];

    // Player color palette
    const P_SKIN = '#ffd1a4';
    const P_HAIR = '#4a2f18';
    const P_SHIRT = '#2b6cb0'; // Blue tunic
    const P_PANTS = '#2d3748'; // Charcoal trousers
    const P_BOOTS = '#744210'; // Brown leather boots
    const P_BELT = '#b7791f';

    directions.forEach((dir) => {
      // 1. Idle (24 x 32)
      const [idleCanvas, iCtx] = this.createCanvas(24, 32);
      // Shadow
      iCtx.fillStyle = 'rgba(0, 0, 0, 0.3)';
      iCtx.beginPath();
      iCtx.ellipse(12, 30, 8, 3, 0, 0, Math.PI * 2);
      iCtx.fill();

      // Hair & Head
      iCtx.fillStyle = P_HAIR;
      iCtx.fillRect(7, 4, 10, 6);
      iCtx.fillStyle = P_SKIN;
      iCtx.fillRect(7, 8, 10, 8);

      // Eyes based on direction
      if (dir === 'down') {
        iCtx.fillStyle = '#1a202c';
        iCtx.fillRect(9, 11, 2, 2);
        iCtx.fillRect(13, 11, 2, 2);
      } else if (dir === 'left') {
        iCtx.fillStyle = '#1a202c';
        iCtx.fillRect(7, 11, 2, 2);
      } else if (dir === 'right') {
        iCtx.fillStyle = '#1a202c';
        iCtx.fillRect(15, 11, 2, 2);
      } else if (dir === 'up') {
        // Back of head, full hair
        iCtx.fillStyle = P_HAIR;
        iCtx.fillRect(7, 6, 10, 10);
      }

      // Torso / Tunic
      iCtx.fillStyle = P_SHIRT;
      iCtx.fillRect(6, 16, 12, 8);
      // Belt
      iCtx.fillStyle = P_BELT;
      iCtx.fillRect(6, 23, 12, 2);

      // Arms
      iCtx.fillStyle = P_SKIN;
      if (dir === 'left') {
        iCtx.fillRect(5, 17, 3, 6);
      } else if (dir === 'right') {
        iCtx.fillRect(16, 17, 3, 6);
      } else {
        iCtx.fillRect(4, 17, 3, 6);
        iCtx.fillRect(17, 17, 3, 6);
      }

      // Legs
      iCtx.fillStyle = P_PANTS;
      iCtx.fillRect(7, 25, 4, 4);
      iCtx.fillRect(13, 25, 4, 4);

      // Boots
      iCtx.fillStyle = P_BOOTS;
      iCtx.fillRect(7, 29, 4, 3);
      iCtx.fillRect(13, 29, 4, 3);

      this.registerAsset(`player_${dir}_idle`, `Player Idle ${dir}`, 'player', 24, 32, 1, idleCanvas);

      // 2. Walk Frame 1 & Frame 2
      const [walkCanvas, wCtx] = this.createCanvas(48, 32); // 2 frames side-by-side
      // Frame 1: left leg forward
      wCtx.drawImage(idleCanvas, 0, 0);
      wCtx.fillStyle = P_BOOTS;
      wCtx.fillRect(6, 28, 4, 4);
      wCtx.fillRect(14, 26, 4, 4);

      // Frame 2: right leg forward
      wCtx.drawImage(idleCanvas, 24, 0);
      wCtx.fillStyle = P_BOOTS;
      wCtx.fillRect(24 + 8, 26, 4, 4);
      wCtx.fillRect(24 + 14, 28, 4, 4);

      this.registerAsset(`player_${dir}_walk`, `Player Walk ${dir} (2F)`, 'player', 24, 32, 2, walkCanvas);

      // 3. RUN / SPRINT Frames (48 x 32) - 2 Frames: high stride, leaning posture, pumping arms
      const [runCanvas, rnCtx] = this.createCanvas(48, 32);
      const leanX = dir === 'right' ? 3 : dir === 'left' ? -3 : 0;
      // Run Frame 1: Extended stride forward
      rnCtx.save();
      rnCtx.translate(leanX, 0);
      rnCtx.drawImage(idleCanvas, 0, 0);
      rnCtx.restore();
      // Emphasize dynamic sprinting legs
      rnCtx.fillStyle = P_BOOTS;
      if (dir === 'left' || dir === 'right') {
        rnCtx.fillRect(leanX + 3, 27, 6, 5);
        rnCtx.fillRect(leanX + 15, 25, 6, 4);
      } else {
        rnCtx.fillRect(leanX + 5, 28, 4, 4);
        rnCtx.fillRect(leanX + 15, 24, 4, 4);
      }

      // Run Frame 2: High stride alternate
      rnCtx.save();
      rnCtx.translate(24 + leanX, 0);
      rnCtx.drawImage(idleCanvas, 0, 0);
      rnCtx.restore();
      rnCtx.fillStyle = P_BOOTS;
      if (dir === 'left' || dir === 'right') {
        rnCtx.fillRect(24 + leanX + 15, 27, 6, 5);
        rnCtx.fillRect(24 + leanX + 3, 25, 6, 4);
      } else {
        rnCtx.fillRect(24 + leanX + 15, 28, 4, 4);
        rnCtx.fillRect(24 + leanX + 5, 24, 4, 4);
      }
      this.registerAsset(`player_${dir}_run`, `Player Run ${dir} (2F)`, 'player', 24, 32, 2, runCanvas);

      // 4. SWIM Frames (48 x 32) - 2 Frames: Torso visible, legs submerged, swimming arm strokes
      const [swimCanvas, swCtx] = this.createCanvas(48, 32);
      for (let sf = 0; sf < 2; sf++) {
        const sox = sf * 24;
        // Head & upper shoulders
        swCtx.fillStyle = P_HAIR;
        swCtx.fillRect(sox + 7, 6, 10, 6);
        swCtx.fillStyle = P_SKIN;
        swCtx.fillRect(sox + 7, 10, 10, 6);

        if (dir === 'down') {
          swCtx.fillStyle = '#1a202c';
          swCtx.fillRect(sox + 9, 13, 2, 2);
          swCtx.fillRect(sox + 13, 13, 2, 2);
        } else if (dir === 'left') {
          swCtx.fillStyle = '#1a202c';
          swCtx.fillRect(sox + 7, 13, 2, 2);
        } else if (dir === 'right') {
          swCtx.fillStyle = '#1a202c';
          swCtx.fillRect(sox + 15, 13, 2, 2);
        }

        // Tunic top visible
        swCtx.fillStyle = P_SHIRT;
        swCtx.fillRect(sox + 7, 16, 10, 4);

        // Swimming arms extending
        swCtx.fillStyle = P_SKIN;
        if (sf === 0) {
          // Outstretched stroke
          swCtx.fillRect(sox + 3, 14, 4, 4);
          swCtx.fillRect(sox + 17, 14, 4, 4);
        } else {
          // Tucked pulling stroke
          swCtx.fillRect(sox + 4, 18, 4, 3);
          swCtx.fillRect(sox + 16, 18, 4, 3);
        }

        // Surrounding water ring around waist
        swCtx.fillStyle = 'rgba(37, 99, 235, 0.7)';
        swCtx.beginPath();
        swCtx.ellipse(sox + 12, 21, 10, 4, 0, 0, Math.PI * 2);
        swCtx.fill();

        // Water ripple foam edge
        swCtx.strokeStyle = '#bfdbfe';
        swCtx.lineWidth = 1.5;
        swCtx.stroke();

        // Splash droplet
        swCtx.fillStyle = '#ffffff';
        swCtx.fillRect(sox + (sf === 0 ? 4 : 18), 19, 2, 2);
      }
      this.registerAsset(`player_${dir}_swim`, `Player Swim ${dir} (2F)`, 'player', 24, 32, 2, swimCanvas);

      // 5. SWIM IDLE Frame (24 x 32) - Floating in water
      const [swimIdleCanvas, siCtx] = this.createCanvas(24, 32);
      siCtx.fillStyle = P_HAIR;
      siCtx.fillRect(7, 7, 10, 6);
      siCtx.fillStyle = P_SKIN;
      siCtx.fillRect(7, 11, 10, 6);
      if (dir === 'down') {
        siCtx.fillStyle = '#1a202c';
        siCtx.fillRect(9, 14, 2, 2);
        siCtx.fillRect(13, 14, 2, 2);
      } else if (dir === 'left') {
        siCtx.fillStyle = '#1a202c';
        siCtx.fillRect(7, 14, 2, 2);
      } else if (dir === 'right') {
        siCtx.fillStyle = '#1a202c';
        siCtx.fillRect(15, 14, 2, 2);
      }
      siCtx.fillStyle = P_SHIRT;
      siCtx.fillRect(7, 17, 10, 3);
      siCtx.fillStyle = 'rgba(37, 99, 235, 0.7)';
      siCtx.beginPath();
      siCtx.ellipse(12, 22, 9, 3.5, 0, 0, Math.PI * 2);
      siCtx.fill();
      siCtx.strokeStyle = '#bfdbfe';
      siCtx.lineWidth = 1.5;
      siCtx.stroke();
      this.registerAsset(`player_${dir}_swim_idle`, `Player Swim Idle ${dir}`, 'player', 24, 32, 1, swimIdleCanvas);

      // 6. Attack Swing Frame
      const [atkCanvas, aCtx] = this.createCanvas(32, 32);
      aCtx.drawImage(idleCanvas, 4, 0);
      // Weapon swing arc
      aCtx.fillStyle = '#cbd5e0';
      if (dir === 'right' || dir === 'down') {
        aCtx.fillRect(20, 12, 10, 3);
        aCtx.fillRect(24, 8, 6, 3);
      } else {
        aCtx.fillRect(2, 12, 10, 3);
        aCtx.fillRect(2, 8, 6, 3);
      }
      // 7. Dodge Roll Frame
      const [dodgeCanvas, ddCtx] = this.createCanvas(24, 24);
      ddCtx.fillStyle = 'rgba(0, 0, 0, 0.3)';
      ddCtx.beginPath();
      ddCtx.ellipse(12, 21, 8, 3, 0, 0, Math.PI * 2);
      ddCtx.fill();
      // Curled body roll
      ddCtx.fillStyle = P_SHIRT;
      ddCtx.beginPath();
      ddCtx.arc(12, 12, 9, 0, Math.PI * 2);
      ddCtx.fill();
      ddCtx.fillStyle = P_HAIR;
      ddCtx.fillRect(7, 6, 8, 5);
      ddCtx.fillStyle = P_BOOTS;
      ddCtx.fillRect(13, 14, 5, 4);
      this.registerAsset(`player_${dir}_dodge`, `Player Dodge ${dir}`, 'player', 24, 24, 1, dodgeCanvas);
    });

    // Hurt Frame
    const [hurtCanvas, hCtx] = this.createCanvas(24, 32);
    const downIdle = this.get('player_down_idle');
    if (downIdle) hCtx.drawImage(downIdle, 0, 0);
    hCtx.fillStyle = 'rgba(239, 68, 68, 0.55)'; // Red tint
    hCtx.fillRect(0, 0, 24, 32);
    this.registerAsset('player_hurt', 'Player Hurt Flash', 'player', 24, 32, 1, hurtCanvas);

    // Death Frame (Fallen player)
    const [deathCanvas, dCtx] = this.createCanvas(32, 24);
    dCtx.fillStyle = 'rgba(0,0,0,0.3)';
    dCtx.beginPath();
    dCtx.ellipse(16, 18, 14, 5, 0, 0, Math.PI * 2);
    dCtx.fill();
    dCtx.fillStyle = P_SHIRT;
    dCtx.fillRect(6, 8, 14, 8);
    dCtx.fillStyle = P_SKIN;
    dCtx.fillRect(20, 7, 7, 7);
    dCtx.fillStyle = P_HAIR;
    dCtx.fillRect(22, 6, 6, 5);
    dCtx.fillStyle = P_PANTS;
    dCtx.fillRect(2, 9, 6, 6);
    this.registerAsset('player_death', 'Player Death Pose', 'player', 32, 24, 1, deathCanvas);
  }

  // ENEMIES: Slime, Wolf, Night Creature
  private initEnemies() {
    // 1. SLIME (24 x 24) - Bouncy jelly with cute angry face
    const [slimeCanvas, sCtx] = this.createCanvas(48, 24); // 2 frames: normal & squashed
    // Shadow frame 1
    sCtx.fillStyle = 'rgba(0, 0, 0, 0.28)';
    sCtx.beginPath();
    sCtx.ellipse(12, 20, 9, 3, 0, 0, Math.PI * 2);
    sCtx.fill();
    // Green Slime body
    sCtx.fillStyle = '#22c55e';
    sCtx.beginPath();
    sCtx.ellipse(12, 12, 10, 8, 0, 0, Math.PI * 2);
    sCtx.fill();
    sCtx.fillStyle = '#4ade80'; // Highlight
    sCtx.beginPath();
    sCtx.ellipse(9, 8, 4, 3, 0, 0, Math.PI * 2);
    sCtx.fill();
    // Eyes
    sCtx.fillStyle = '#0f172a';
    sCtx.fillRect(8, 11, 2, 3);
    sCtx.fillRect(14, 11, 2, 3);
    sCtx.fillStyle = '#fff';
    sCtx.fillRect(8, 11, 1, 1);
    sCtx.fillRect(14, 11, 1, 1);

    // Frame 2: Squashed bounce
    const ox = 24;
    sCtx.fillStyle = 'rgba(0, 0, 0, 0.28)';
    sCtx.beginPath();
    sCtx.ellipse(ox + 12, 21, 11, 3, 0, 0, Math.PI * 2);
    sCtx.fill();
    sCtx.fillStyle = '#22c55e';
    sCtx.beginPath();
    sCtx.ellipse(ox + 12, 14, 12, 6, 0, 0, Math.PI * 2);
    sCtx.fill();
    sCtx.fillStyle = '#0f172a';
    sCtx.fillRect(ox + 8, 13, 2, 2);
    sCtx.fillRect(ox + 14, 13, 2, 2);
    this.registerAsset('enemy_slime', 'Forest Slime (2F)', 'enemies', 24, 24, 2, slimeCanvas);

    // 2. WOLF (36 x 28) - Grey predatory canine with glowing yellow eyes
    const [wolfCanvas, wCtx] = this.createCanvas(36, 28);
    // Shadow
    wCtx.fillStyle = 'rgba(0, 0, 0, 0.3)';
    wCtx.beginPath();
    wCtx.ellipse(18, 24, 14, 4, 0, 0, Math.PI * 2);
    wCtx.fill();
    // Body
    wCtx.fillStyle = '#64748b';
    wCtx.fillRect(8, 10, 18, 10);
    // Head & snout
    wCtx.fillStyle = '#475569';
    wCtx.fillRect(22, 6, 10, 8);
    wCtx.fillRect(30, 9, 4, 4); // Snout
    // Ears
    wCtx.fillStyle = '#334155';
    wCtx.fillRect(23, 3, 3, 4);
    // Glowing predatory eyes
    wCtx.fillStyle = '#eab308';
    wCtx.fillRect(27, 8, 2, 2);
    // Legs
    wCtx.fillStyle = '#475569';
    wCtx.fillRect(10, 19, 3, 6);
    wCtx.fillRect(15, 19, 3, 6);
    wCtx.fillRect(21, 19, 3, 6);
    wCtx.fillRect(25, 19, 3, 6);
    // Tail
    wCtx.fillStyle = '#64748b';
    wCtx.fillRect(4, 12, 5, 3);
    this.registerAsset('enemy_wolf', 'Wild Wolf', 'enemies', 36, 28, 1, wolfCanvas);

    // 3. NIGHT CREATURE (36 x 36) - Dark demonic shadow with glowing crimson eyes & claws
    const [nightCanvas, ncCtx] = this.createCanvas(36, 36);
    ncCtx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ncCtx.beginPath();
    ncCtx.ellipse(18, 32, 12, 4, 0, 0, Math.PI * 2);
    ncCtx.fill();
    // Smoky aura body
    ncCtx.fillStyle = '#1e102e';
    ncCtx.beginPath();
    ncCtx.arc(18, 18, 12, 0, Math.PI * 2);
    ncCtx.fill();
    // Horns
    ncCtx.fillStyle = '#4c1d95';
    ncCtx.fillRect(11, 4, 3, 6);
    ncCtx.fillRect(22, 4, 3, 6);
    // Spooky Wings/Claws
    ncCtx.fillStyle = '#2e1065';
    ncCtx.fillRect(4, 14, 6, 12);
    ncCtx.fillRect(26, 14, 6, 12);
    // Glowing Blood Eyes
    ncCtx.fillStyle = '#ef4444';
    ncCtx.fillRect(13, 15, 3, 3);
    ncCtx.fillRect(20, 15, 3, 3);
    this.registerAsset('enemy_night_creature', 'Night Stalker', 'enemies', 36, 36, 1, nightCanvas);

    // 4. Enemy Alert Exclamation Icon (16 x 16)
    const [alertCanvas, alCtx] = this.createCanvas(16, 16);
    alCtx.fillStyle = '#ef4444';
    alCtx.beginPath();
    alCtx.arc(8, 8, 7, 0, Math.PI * 2);
    alCtx.fill();
    alCtx.strokeStyle = '#ffffff';
    alCtx.lineWidth = 1.5;
    alCtx.stroke();
    alCtx.fillStyle = '#ffffff';
    alCtx.fillRect(7, 4, 2, 5);
    alCtx.fillRect(7, 10, 2, 2);
    this.registerAsset('enemy_alert', 'Alert Exclamation', 'enemies', 16, 16, 1, alertCanvas);

    // 5. Enemy Attack Slash effect (24 x 24)
    const [slashCanvas, slCtx] = this.createCanvas(24, 24);
    slCtx.strokeStyle = '#f87171';
    slCtx.lineWidth = 2.5;
    slCtx.beginPath();
    slCtx.arc(12, 12, 9, -Math.PI * 0.25, Math.PI * 0.6);
    slCtx.stroke();
    slCtx.strokeStyle = '#ffffff';
    slCtx.lineWidth = 1.5;
    slCtx.beginPath();
    slCtx.arc(12, 12, 7, -Math.PI * 0.15, Math.PI * 0.5);
    slCtx.stroke();
    this.registerAsset('enemy_attack_slash', 'Claw Slash Arc', 'enemies', 24, 24, 1, slashCanvas);

    // 6. DEER (32 x 32)
    const [deerCanvas, dCtx] = this.createCanvas(32, 32);
    dCtx.fillStyle = 'rgba(0,0,0,0.25)';
    dCtx.beginPath();
    dCtx.ellipse(16, 28, 12, 3.5, 0, 0, Math.PI * 2);
    dCtx.fill();
    // Body & neck
    dCtx.fillStyle = '#b45309';
    dCtx.fillRect(8, 12, 16, 10);
    dCtx.fillRect(18, 6, 8, 8);
    // Head & snout
    dCtx.fillRect(22, 4, 8, 6);
    dCtx.fillStyle = '#451a03';
    dCtx.fillRect(28, 7, 2, 2); // nose
    dCtx.fillStyle = '#1e293b';
    dCtx.fillRect(25, 5, 2, 2); // eye
    // Antlers
    dCtx.fillStyle = '#78350f';
    dCtx.fillRect(22, 1, 2, 4);
    dCtx.fillRect(20, 2, 4, 1);
    dCtx.fillRect(24, 1, 3, 1);
    // White spots & belly
    dCtx.fillStyle = '#fef3c7';
    dCtx.fillRect(10, 18, 12, 3);
    dCtx.fillRect(11, 14, 2, 2);
    dCtx.fillRect(15, 13, 2, 2);
    // Legs
    dCtx.fillStyle = '#92400e';
    dCtx.fillRect(10, 22, 2, 8);
    dCtx.fillRect(14, 22, 2, 8);
    dCtx.fillRect(18, 22, 2, 8);
    dCtx.fillRect(22, 22, 2, 8);
    // Tail
    dCtx.fillStyle = '#fef3c7';
    dCtx.fillRect(6, 13, 3, 3);
    this.registerAsset('enemy_deer', 'Wild Deer', 'enemies', 32, 32, 1, deerCanvas);

    // 7. GOLDEN DEER (32 x 32)
    const [gDeerCanvas, gdCtx] = this.createCanvas(32, 32);
    gdCtx.fillStyle = 'rgba(234, 179, 8, 0.35)';
    gdCtx.beginPath();
    gdCtx.ellipse(16, 28, 13, 4, 0, 0, Math.PI * 2);
    gdCtx.fill();
    // Golden Body
    gdCtx.fillStyle = '#f59e0b';
    gdCtx.fillRect(8, 12, 16, 10);
    gdCtx.fillRect(18, 6, 8, 8);
    gdCtx.fillRect(22, 4, 8, 6);
    gdCtx.fillStyle = '#78350f';
    gdCtx.fillRect(28, 7, 2, 2);
    gdCtx.fillStyle = '#0f172a';
    gdCtx.fillRect(25, 5, 2, 2);
    // Radiant Golden Antlers
    gdCtx.fillStyle = '#fde047';
    gdCtx.fillRect(22, 0, 2, 5);
    gdCtx.fillRect(19, 1, 6, 2);
    gdCtx.fillRect(24, 0, 4, 1);
    // Golden Shimmer Belly
    gdCtx.fillStyle = '#fef08a';
    gdCtx.fillRect(10, 18, 12, 3);
    gdCtx.fillRect(12, 14, 2, 2);
    gdCtx.fillRect(16, 13, 2, 2);
    // Legs
    gdCtx.fillStyle = '#d97706';
    gdCtx.fillRect(10, 22, 2, 8);
    gdCtx.fillRect(14, 22, 2, 8);
    gdCtx.fillRect(18, 22, 2, 8);
    gdCtx.fillRect(22, 22, 2, 8);
    this.registerAsset('enemy_golden_deer', 'Mythic Golden Deer', 'enemies', 32, 32, 1, gDeerCanvas);

    // 8. RABBIT (18 x 18)
    const [rabCanvas, rbCtx] = this.createCanvas(18, 18);
    rbCtx.fillStyle = 'rgba(0,0,0,0.2)';
    rbCtx.beginPath();
    rbCtx.ellipse(9, 16, 7, 2, 0, 0, Math.PI * 2);
    rbCtx.fill();
    // Body & Head
    rbCtx.fillStyle = '#d97706';
    rbCtx.beginPath();
    rbCtx.ellipse(8, 12, 6, 4, 0, 0, Math.PI * 2);
    rbCtx.fill();
    rbCtx.fillStyle = '#b45309';
    rbCtx.beginPath();
    rbCtx.arc(12, 9, 4, 0, Math.PI * 2);
    rbCtx.fill();
    // Tall Ears
    rbCtx.fillStyle = '#d97706';
    rbCtx.fillRect(10, 2, 2, 6);
    rbCtx.fillRect(13, 3, 2, 5);
    rbCtx.fillStyle = '#f472b6';
    rbCtx.fillRect(11, 3, 1, 4);
    // Eye & nose
    rbCtx.fillStyle = '#0f172a';
    rbCtx.fillRect(13, 8, 1, 1);
    rbCtx.fillStyle = '#fff';
    rbCtx.fillRect(3, 11, 3, 3); // Fluffy tail
    this.registerAsset('enemy_rabbit', 'Wild Rabbit', 'enemies', 18, 18, 1, rabCanvas);

    // 9. BOAR (28 x 24)
    const [boarCanvas, bCtx] = this.createCanvas(28, 24);
    bCtx.fillStyle = 'rgba(0,0,0,0.3)';
    bCtx.beginPath();
    bCtx.ellipse(14, 21, 10, 3, 0, 0, Math.PI * 2);
    bCtx.fill();
    // Stout Body
    bCtx.fillStyle = '#573010';
    bCtx.fillRect(5, 7, 16, 11);
    // Mane bristle
    bCtx.fillStyle = '#291807';
    bCtx.fillRect(6, 5, 14, 2);
    // Snout
    bCtx.fillStyle = '#78350f';
    bCtx.fillRect(18, 10, 7, 6);
    bCtx.fillStyle = '#291807';
    bCtx.fillRect(23, 11, 2, 3); // nostrils
    // White Tusks
    bCtx.fillStyle = '#ffffff';
    bCtx.fillRect(20, 14, 2, 3);
    // Red eye
    bCtx.fillStyle = '#dc2626';
    bCtx.fillRect(18, 9, 2, 2);
    // Legs
    bCtx.fillStyle = '#291807';
    bCtx.fillRect(7, 18, 3, 4);
    bCtx.fillRect(11, 18, 3, 4);
    bCtx.fillRect(15, 18, 3, 4);
    this.registerAsset('enemy_boar', 'Wild Boar', 'enemies', 28, 24, 1, boarCanvas);

    // 10. WILD BOAR (32 x 28) - Fierce aggressive tusker
    const [wBoarCanvas, wbCtx] = this.createCanvas(32, 28);
    wbCtx.fillStyle = 'rgba(0,0,0,0.35)';
    wbCtx.beginPath();
    wbCtx.ellipse(16, 25, 12, 3, 0, 0, Math.PI * 2);
    wbCtx.fill();
    wbCtx.fillStyle = '#1c1917';
    wbCtx.fillRect(5, 8, 18, 13);
    wbCtx.fillStyle = '#7f1d1d'; // Spiky red ridge
    wbCtx.fillRect(6, 5, 16, 3);
    wbCtx.fillStyle = '#292524';
    wbCtx.fillRect(20, 11, 9, 8);
    // Long Tusks
    wbCtx.fillStyle = '#ffffff';
    wbCtx.fillRect(25, 15, 3, 4);
    wbCtx.fillRect(27, 13, 2, 3);
    wbCtx.fillStyle = '#ef4444'; // Glowing red eyes
    wbCtx.fillRect(21, 10, 2, 2);
    wbCtx.fillStyle = '#0c0a09';
    wbCtx.fillRect(7, 21, 3, 5);
    wbCtx.fillRect(12, 21, 3, 5);
    wbCtx.fillRect(17, 21, 3, 5);
    this.registerAsset('enemy_wild_boar', 'Fierce Tusker', 'enemies', 32, 28, 1, wBoarCanvas);

    // 11. GOAT (26 x 26)
    const [goatCanvas, gtCtx] = this.createCanvas(26, 26);
    gtCtx.fillStyle = 'rgba(0,0,0,0.25)';
    gtCtx.beginPath();
    gtCtx.ellipse(13, 23, 9, 3, 0, 0, Math.PI * 2);
    gtCtx.fill();
    gtCtx.fillStyle = '#e2e8f0';
    gtCtx.fillRect(6, 8, 13, 9);
    gtCtx.fillRect(14, 5, 7, 7);
    // Curved Horns
    gtCtx.fillStyle = '#78350f';
    gtCtx.fillRect(14, 1, 3, 4);
    gtCtx.fillRect(11, 2, 4, 2);
    // Eyes & beard
    gtCtx.fillStyle = '#1e293b';
    gtCtx.fillRect(17, 7, 2, 2);
    gtCtx.fillStyle = '#cbd5e1';
    gtCtx.fillRect(17, 12, 3, 3); // goatee
    // Legs
    gtCtx.fillStyle = '#94a3b8';
    gtCtx.fillRect(8, 17, 2, 7);
    gtCtx.fillRect(11, 17, 2, 7);
    gtCtx.fillRect(14, 17, 2, 7);
    gtCtx.fillRect(17, 17, 2, 7);
    this.registerAsset('enemy_goat', 'Mountain Goat', 'enemies', 26, 26, 1, goatCanvas);

    // 12. CHICKEN (16 x 16)
    const [chkCanvas, chCtx] = this.createCanvas(16, 16);
    chCtx.fillStyle = 'rgba(0,0,0,0.2)';
    chCtx.beginPath();
    chCtx.ellipse(8, 14, 6, 2, 0, 0, Math.PI * 2);
    chCtx.fill();
    // Body & Head
    chCtx.fillStyle = '#f8fafc';
    chCtx.beginPath();
    chCtx.arc(7, 9, 5, 0, Math.PI * 2);
    chCtx.fill();
    chCtx.fillStyle = '#dc2626'; // Comb
    chCtx.fillRect(8, 2, 3, 3);
    // Yellow beak
    chCtx.fillStyle = '#f59e0b';
    chCtx.fillRect(12, 7, 3, 2);
    chCtx.fillStyle = '#0f172a';
    chCtx.fillRect(10, 6, 1, 1);
    // Feet
    chCtx.fillStyle = '#d97706';
    chCtx.fillRect(6, 13, 2, 2);
    chCtx.fillRect(9, 13, 2, 2);
    this.registerAsset('enemy_chicken', 'Wild Chicken', 'enemies', 16, 16, 1, chkCanvas);

    // 13. DUCK (18 x 18)
    const [duckCanvas, dkCtx] = this.createCanvas(18, 18);
    dkCtx.fillStyle = 'rgba(0,0,0,0.2)';
    dkCtx.beginPath();
    dkCtx.ellipse(9, 15, 7, 2.5, 0, 0, Math.PI * 2);
    dkCtx.fill();
    // Chestnut Body
    dkCtx.fillStyle = '#78350f';
    dkCtx.fillRect(4, 9, 10, 6);
    // Green Emerald Head
    dkCtx.fillStyle = '#15803d';
    dkCtx.beginPath();
    dkCtx.arc(12, 7, 4, 0, Math.PI * 2);
    dkCtx.fill();
    // White collar
    dkCtx.fillStyle = '#ffffff';
    dkCtx.fillRect(10, 10, 4, 1);
    // Orange Beak
    dkCtx.fillStyle = '#ea580c';
    dkCtx.fillRect(15, 6, 3, 2);
    dkCtx.fillStyle = '#0f172a';
    dkCtx.fillRect(13, 5, 1, 1);
    this.registerAsset('enemy_duck', 'Lake Duck', 'enemies', 18, 18, 1, duckCanvas);

    // 14. BIRD (16 x 16)
    const [birdCanvas, bdCtx] = this.createCanvas(16, 16);
    bdCtx.fillStyle = '#2563eb'; // Azure Blue
    bdCtx.beginPath();
    bdCtx.arc(8, 8, 5, 0, Math.PI * 2);
    bdCtx.fill();
    bdCtx.fillStyle = '#1d4ed8';
    bdCtx.fillRect(3, 8, 4, 4); // wing
    bdCtx.fillStyle = '#f59e0b';
    bdCtx.fillRect(12, 7, 3, 2); // beak
    bdCtx.fillStyle = '#0f172a';
    bdCtx.fillRect(10, 6, 1, 1);
    this.registerAsset('enemy_bird', 'Forest Bird', 'enemies', 16, 16, 1, birdCanvas);

    // 15. FISH (18 x 14)
    const [fishCanvas, fsCtx] = this.createCanvas(18, 14);
    fsCtx.fillStyle = '#06b6d4';
    fsCtx.beginPath();
    fsCtx.ellipse(8, 7, 6, 4, 0, 0, Math.PI * 2);
    fsCtx.fill();
    // Tail fin
    fsCtx.fillStyle = '#0891b2';
    fsCtx.beginPath();
    fsCtx.moveTo(2, 7);
    fsCtx.lineTo(0, 3);
    fsCtx.lineTo(0, 11);
    fsCtx.closePath();
    fsCtx.fill();
    fsCtx.fillStyle = '#ffffff';
    fsCtx.fillRect(11, 5, 2, 2);
    fsCtx.fillStyle = '#0f172a';
    fsCtx.fillRect(12, 5, 1, 1);
    this.registerAsset('enemy_fish', 'River Trout', 'enemies', 18, 14, 1, fishCanvas);

    // 16. FROG (16 x 14)
    const [frogCanvas, frCtx] = this.createCanvas(16, 14);
    frCtx.fillStyle = 'rgba(0,0,0,0.2)';
    frCtx.beginPath();
    frCtx.ellipse(8, 12, 6, 2, 0, 0, Math.PI * 2);
    frCtx.fill();
    frCtx.fillStyle = '#22c55e';
    frCtx.beginPath();
    frCtx.ellipse(8, 8, 5, 4, 0, 0, Math.PI * 2);
    frCtx.fill();
    // Bulging Eyes
    frCtx.fillStyle = '#15803d';
    frCtx.fillRect(4, 3, 3, 3);
    frCtx.fillRect(9, 3, 3, 3);
    frCtx.fillStyle = '#fbbf24';
    frCtx.fillRect(5, 4, 1, 1);
    frCtx.fillRect(10, 4, 1, 1);
    // Legs
    frCtx.fillStyle = '#16a34a';
    frCtx.fillRect(2, 8, 2, 4);
    frCtx.fillRect(12, 8, 2, 4);
    this.registerAsset('enemy_frog', 'Swamp Frog', 'enemies', 16, 14, 1, frogCanvas);

    // 17. BEAR (44 x 36) - Enormous Grizzly
    const [bearCanvas, brCtx] = this.createCanvas(44, 36);
    brCtx.fillStyle = 'rgba(0,0,0,0.35)';
    brCtx.beginPath();
    brCtx.ellipse(22, 32, 17, 4, 0, 0, Math.PI * 2);
    brCtx.fill();
    // Massive Body & Hump
    brCtx.fillStyle = '#3e2311';
    brCtx.fillRect(8, 10, 26, 16);
    brCtx.fillRect(12, 7, 16, 5); // shoulder hump
    // Head & Muzzle
    brCtx.fillStyle = '#543118';
    brCtx.fillRect(28, 12, 12, 12);
    brCtx.fillStyle = '#78431f';
    brCtx.fillRect(34, 16, 7, 7); // Muzzle
    brCtx.fillStyle = '#18181b';
    brCtx.fillRect(38, 17, 3, 3); // Black nose
    // Ears
    brCtx.fillStyle = '#3e2311';
    brCtx.fillRect(29, 9, 3, 4);
    // Eye
    brCtx.fillStyle = '#dc2626';
    brCtx.fillRect(33, 14, 2, 2);
    // Thick Legs & Claws
    brCtx.fillStyle = '#2b170a';
    brCtx.fillRect(11, 24, 6, 9);
    brCtx.fillRect(24, 24, 6, 9);
    brCtx.fillStyle = '#f8fafc';
    brCtx.fillRect(11, 32, 6, 2); // Claws
    brCtx.fillRect(24, 32, 6, 2);
    this.registerAsset('enemy_bear', 'Grizzly Bear', 'enemies', 44, 36, 1, bearCanvas);

    // 18. CROC (42 x 24)
    const [crocCanvas, crCtx] = this.createCanvas(42, 24);
    crCtx.fillStyle = 'rgba(0,0,0,0.3)';
    crCtx.beginPath();
    crCtx.ellipse(21, 20, 18, 3, 0, 0, Math.PI * 2);
    crCtx.fill();
    // Armored Low Body
    crCtx.fillStyle = '#365314';
    crCtx.fillRect(6, 10, 24, 7);
    // Spikes/Ridges
    crCtx.fillStyle = '#1a2e05';
    for (let s = 8; s < 28; s += 4) {
      crCtx.fillRect(s, 8, 2, 3);
    }
    // Long Jaws & Snout
    crCtx.fillStyle = '#4d7c0f';
    crCtx.fillRect(26, 11, 14, 5);
    crCtx.fillStyle = '#ffffff';
    crCtx.fillRect(30, 16, 2, 2); // teeth
    crCtx.fillRect(35, 16, 2, 2);
    // Eyes
    crCtx.fillStyle = '#eab308';
    crCtx.fillRect(28, 9, 2, 2);
    // Tail
    crCtx.fillStyle = '#365314';
    crCtx.fillRect(1, 12, 6, 3);
    this.registerAsset('enemy_croc', 'Swamp Crocodile', 'enemies', 42, 24, 1, crocCanvas);
  }

  // ITEMS & INVENTORY ICONS (24 x 24)
  private initItems() {
    const drawItem = (id: ItemId, name: string, drawFn: (ctx: CanvasRenderingContext2D) => void) => {
      const [c, ctx] = this.createCanvas(24, 24);
      drawFn(ctx);
      this.registerAsset(`item_${id}`, name, 'items', 24, 24, 1, c);
    };

    // Wood
    drawItem('wood', 'Wood Log', (ctx) => {
      ctx.fillStyle = '#78350f';
      ctx.fillRect(4, 7, 16, 10);
      ctx.fillStyle = '#b45309';
      ctx.fillRect(6, 8, 12, 8);
      ctx.fillStyle = '#d97706';
      ctx.fillRect(16, 9, 3, 6);
    });

    // Stone
    drawItem('stone', 'Stone Chunk', (ctx) => {
      ctx.fillStyle = '#475569';
      ctx.beginPath();
      ctx.ellipse(12, 12, 8, 6, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(9, 9, 4, 3);
    });

    // Fiber
    drawItem('fiber', 'Plant Fiber', (ctx) => {
      ctx.strokeStyle = '#15803d';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(5, 18);
      ctx.bezierCurveTo(10, 4, 14, 20, 19, 6);
      ctx.stroke();
      ctx.strokeStyle = '#86efac';
      ctx.beginPath();
      ctx.moveTo(7, 16);
      ctx.bezierCurveTo(11, 7, 15, 17, 18, 9);
      ctx.stroke();
    });

    // Coal
    drawItem('coal', 'Coal', (ctx) => {
      ctx.fillStyle = '#18181b';
      ctx.fillRect(6, 6, 12, 12);
      ctx.fillStyle = '#3f3f46';
      ctx.fillRect(8, 8, 4, 4);
    });

    // Iron
    drawItem('iron', 'Iron Ore', (ctx) => {
      ctx.fillStyle = '#d97706';
      ctx.fillRect(6, 8, 12, 8);
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(7, 9, 10, 3);
    });

    // Berry
    drawItem('berry', 'Wild Berry', (ctx) => {
      ctx.fillStyle = '#a855f7';
      ctx.beginPath();
      ctx.arc(10, 14, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(15, 13, 4.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(11, 6, 2, 4);
    });

    // Apple
    drawItem('apple', 'Red Apple', (ctx) => {
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.arc(12, 14, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#15803d';
      ctx.fillRect(11, 5, 2, 4);
      ctx.fillStyle = '#f87171';
      ctx.fillRect(9, 10, 3, 3);
    });

    // Cooked Berry
    drawItem('cooked_berry', 'Cooked Berry', (ctx) => {
      ctx.fillStyle = '#581c87';
      ctx.beginPath();
      ctx.arc(12, 13, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#e879f9';
      ctx.fillRect(10, 10, 4, 3);
    });

    // Cooked Apple
    drawItem('cooked_apple', 'Baked Apple', (ctx) => {
      ctx.fillStyle = '#9a3412';
      ctx.beginPath();
      ctx.arc(12, 14, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fb923c';
      ctx.fillRect(9, 10, 5, 4);
    });

    // Wooden Axe
    drawItem('wooden_axe', 'Wooden Axe', (ctx) => {
      ctx.fillStyle = '#78350f'; // Handle
      ctx.fillRect(6, 14, 12, 3);
      ctx.fillStyle = '#92400e'; // Blade
      ctx.fillRect(14, 6, 6, 8);
    });

    // Stone Axe
    drawItem('stone_axe', 'Stone Axe', (ctx) => {
      ctx.fillStyle = '#78350f';
      ctx.fillRect(5, 15, 14, 3);
      ctx.fillStyle = '#64748b'; // Stone Blade
      ctx.fillRect(14, 5, 7, 9);
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(18, 6, 2, 7);
    });

    // Stone Pickaxe
    drawItem('stone_pickaxe', 'Stone Pickaxe', (ctx) => {
      ctx.fillStyle = '#78350f';
      ctx.fillRect(6, 14, 12, 3);
      ctx.fillStyle = '#64748b';
      // Pick curved head
      ctx.beginPath();
      ctx.arc(16, 7, 8, Math.PI, Math.PI * 2);
      ctx.lineWidth = 3;
      ctx.strokeStyle = '#64748b';
      ctx.stroke();
    });

    // Wooden Sword
    drawItem('wooden_sword', 'Wooden Sword', (ctx) => {
      ctx.fillStyle = '#78350f'; // Grip
      ctx.fillRect(5, 17, 4, 4);
      ctx.fillStyle = '#b45309'; // Guard
      ctx.fillRect(8, 14, 3, 7);
      ctx.fillStyle = '#d97706'; // Blade
      ctx.fillRect(10, 6, 10, 4);
    });

    // Torch
    drawItem('torch', 'Torch', (ctx) => {
      ctx.fillStyle = '#78350f';
      ctx.fillRect(6, 12, 10, 4);
      ctx.fillStyle = '#ea580c';
      ctx.fillRect(15, 8, 6, 6);
      ctx.fillStyle = '#facc15';
      ctx.fillRect(16, 9, 3, 4);
    });

    // Campfire Item
    drawItem('campfire', 'Campfire', (ctx) => {
      ctx.fillStyle = '#475569';
      ctx.fillRect(5, 15, 14, 4);
      ctx.fillStyle = '#78350f';
      ctx.fillRect(7, 12, 10, 4);
      ctx.fillStyle = '#f97316';
      ctx.fillRect(9, 7, 6, 6);
      ctx.fillStyle = '#fde047';
      ctx.fillRect(11, 8, 2, 3);
    });

    // Chest Item
    drawItem('chest', 'Storage Chest', (ctx) => {
      ctx.fillStyle = '#78350f';
      ctx.fillRect(4, 5, 16, 14);
      ctx.fillStyle = '#92400e';
      ctx.fillRect(6, 7, 12, 10);
      ctx.fillStyle = '#eab308';
      ctx.fillRect(10, 10, 4, 3); // Latch
    });

    // Wood Wall Item
    drawItem('wood_wall', 'Wood Wall', (ctx) => {
      ctx.fillStyle = '#78350f';
      ctx.fillRect(4, 4, 16, 16);
      ctx.fillStyle = '#92400e';
      ctx.fillRect(6, 6, 12, 12);
      ctx.strokeStyle = '#451a03';
      ctx.strokeRect(6, 6, 12, 12);
    });

    // Wood Floor Item
    drawItem('wood_floor', 'Wood Floor', (ctx) => {
      ctx.fillStyle = '#b45309';
      ctx.fillRect(4, 4, 16, 16);
      ctx.fillStyle = '#78350f';
      ctx.fillRect(4, 9, 16, 1);
      ctx.fillRect(4, 14, 16, 1);
    });

    // Wood Door Item
    drawItem('wood_door', 'Wood Door', (ctx) => {
      ctx.fillStyle = '#78350f';
      ctx.fillRect(6, 3, 12, 18);
      ctx.fillStyle = '#92400e';
      ctx.fillRect(8, 5, 8, 14);
      ctx.fillStyle = '#facc15';
      ctx.fillRect(13, 11, 2, 2);
    });
  }

  // STRUCTURES IN-GAME (32 x 32)
  private initStructures() {
    // 1. Campfire (with animated fire strip)
    const [campfireCanvas, cfCtx] = this.createCanvas(128, 32); // 4 animated fire frames
    for (let f = 0; f < 4; f++) {
      const ox = f * 32;
      // Stone ring
      cfCtx.fillStyle = '#64748b';
      cfCtx.beginPath();
      cfCtx.arc(ox + 16, 20, 12, 0, Math.PI * 2);
      cfCtx.fill();
      cfCtx.fillStyle = '#334155';
      cfCtx.beginPath();
      cfCtx.arc(ox + 16, 20, 8, 0, Math.PI * 2);
      cfCtx.fill();
      // Wooden logs criss-crossed
      cfCtx.fillStyle = '#78350f';
      cfCtx.fillRect(ox + 9, 18, 14, 4);
      // Flame animation
      cfCtx.fillStyle = '#ea580c';
      const flicker = (f % 2 === 0 ? 0 : 2);
      cfCtx.beginPath();
      cfCtx.ellipse(ox + 16, 15 - flicker, 6, 9 + flicker, 0, 0, Math.PI * 2);
      cfCtx.fill();
      cfCtx.fillStyle = '#facc15';
      cfCtx.beginPath();
      cfCtx.ellipse(ox + 16, 16 - flicker, 3, 6 + flicker, 0, 0, Math.PI * 2);
      cfCtx.fill();
    }
    this.registerAsset('structure_campfire', 'Campfire In-Game', 'structures', 32, 32, 4, campfireCanvas);

    // 2. Chest (Closed and Open 64 x 32)
    const [chestCanvas, chCtx] = this.createCanvas(64, 32);
    // Closed
    chCtx.fillStyle = '#78350f';
    chCtx.fillRect(4, 6, 24, 20);
    chCtx.fillStyle = '#92400e';
    chCtx.fillRect(6, 8, 20, 16);
    chCtx.fillStyle = '#eab308';
    chCtx.fillRect(14, 15, 4, 4);
    // Open
    chCtx.fillStyle = '#78350f';
    chCtx.fillRect(36, 12, 24, 14);
    chCtx.fillStyle = '#451a03'; // inside dark
    chCtx.fillRect(38, 14, 20, 10);
    chCtx.fillStyle = '#92400e'; // lid tilted back
    chCtx.fillRect(36, 4, 24, 7);
    this.registerAsset('structure_chest', 'Storage Chest In-Game', 'structures', 32, 32, 2, chestCanvas);

    // 3. Wooden Wall
    const [wallCanvas, wCtx] = this.createCanvas(32, 32);
    wCtx.fillStyle = '#5c2b09';
    wCtx.fillRect(0, 0, 32, 32);
    wCtx.fillStyle = '#854111';
    wCtx.fillRect(2, 2, 28, 28);
    wCtx.fillStyle = '#451a03';
    wCtx.fillRect(2, 10, 28, 2);
    wCtx.fillRect(2, 20, 28, 2);
    wCtx.fillRect(14, 2, 2, 28);
    this.registerAsset('structure_wood_wall', 'Wooden Wall Structure', 'structures', 32, 32, 1, wallCanvas);

    // 4. Wooden Floor
    const [floorCanvas, flCtx] = this.createCanvas(32, 32);
    flCtx.fillStyle = '#b45309';
    flCtx.fillRect(0, 0, 32, 32);
    flCtx.fillStyle = '#78350f';
    flCtx.fillRect(0, 8, 32, 1);
    flCtx.fillRect(0, 16, 32, 1);
    flCtx.fillRect(0, 24, 32, 1);
    this.registerAsset('structure_wood_floor', 'Wooden Floor Planks', 'structures', 32, 32, 1, floorCanvas);

    // 5. Wooden Door (Closed & Open)
    const [doorCanvas, dCtx] = this.createCanvas(64, 32);
    // Closed
    dCtx.fillStyle = '#5c2b09';
    dCtx.fillRect(2, 2, 28, 28);
    dCtx.fillStyle = '#854111';
    dCtx.fillRect(4, 4, 24, 24);
    dCtx.fillStyle = '#facc15';
    dCtx.fillRect(22, 14, 3, 3);
    // Open
    dCtx.fillStyle = '#3e1c05';
    dCtx.fillRect(34, 2, 8, 28);
    this.registerAsset('structure_wood_door', 'Wooden Door (Closed/Open)', 'structures', 32, 32, 2, doorCanvas);
  }

  private registerAsset(
    id: string,
    name: string,
    category: SpriteAssetInfo['category'],
    width: number,
    height: number,
    frames: number,
    canvas: CanvasImage
  ) {
    this.cache.set(id, canvas);
    this.assetList.push({
      id,
      name,
      category,
      width,
      height,
      frames,
      usedInGame: true,
      canvas,
    });
  }

  private replaceAsset(id: string, name: string, category: SpriteAssetInfo['category'], width: number, height: number, frames: number, canvas: CanvasImage) {
    this.cache.set(id, canvas);
    const existing = this.assetList.find((asset) => asset.id === id);
    if (existing) {
      Object.assign(existing, { name, category, width, height, frames, usedInGame: true, canvas });
    } else {
      this.assetList.push({ id, name, category, width, height, frames, usedInGame: true, canvas });
    }
  }

  private loadImage(src: string): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error(`Unable to load asset: ${src}`));
      image.src = src;
    });
  }

  private cropAtlas(image: HTMLImageElement, sx: number, sy: number, sw: number, sh: number, dw = sw, dh = sh): CanvasImage {
    const [canvas, ctx] = this.createCanvas(dw, dh);
    ctx.drawImage(image, sx, sy, sw, sh, 0, 0, dw, dh);
    // The supplied atlases use white as a display grid/background; remove only near-white pixels
    // so props keep their crisp silhouettes when rendered over the game world.
    const pixels = ctx.getImageData(0, 0, dw, dh);
    for (let i = 0; i < pixels.data.length; i += 4) {
      if (pixels.data[i] > 247 && pixels.data[i + 1] > 247 && pixels.data[i + 2] > 247) pixels.data[i + 3] = 0;
    }
    ctx.putImageData(pixels, 0, 0);
    return canvas;
  }

  /** Load supplied pixel-art atlases into the same runtime cache used by gameplay. */
  public async loadProvidedAssets(): Promise<void> {
    if (this.cache.get('provided_assets_loaded')) return;
    this.init();

    const [nature, medieval] = await Promise.all([
      this.loadImage('/assets/Nature_TileMegaPack.png'),
      this.loadImage('/assets/MediavelFree.png'),
    ]);

    // Real 32px crops from Nature TileMegaPack.
    this.replaceAsset('tile_grass', 'Nature atlas grass', 'tiles', 32, 32, 1, this.cropAtlas(nature, 0, 0, 32, 32));
    this.replaceAsset('tile_grass_dense', 'Nature atlas dense grass', 'tiles', 32, 32, 1, this.cropAtlas(nature, 0, 32, 32, 32));
    this.replaceAsset('tile_sand', 'Nature atlas beach', 'tiles', 32, 32, 1, this.cropAtlas(nature, 352, 0, 32, 32));
    this.replaceAsset('tile_water', 'Nature atlas animated water', 'tiles', 128, 32, 4, this.cropAtlas(nature, 384, 64, 128, 32));
    this.replaceAsset('tree_oak', 'Nature atlas broad tree', 'environment', 48, 64, 1, this.cropAtlas(nature, 0, 128, 64, 64, 48, 64));
    this.replaceAsset('rock', 'Nature atlas boulder', 'environment', 32, 32, 1, this.cropAtlas(nature, 128, 128, 32, 32));
    this.replaceAsset('bush_berry', 'Nature atlas berry bush', 'environment', 32, 32, 1, this.cropAtlas(nature, 416, 128, 32, 32));
    this.replaceAsset('structure_wood_floor', 'Nature atlas bridge plank', 'structures', 32, 32, 1, this.cropAtlas(nature, 352, 256, 32, 32));

    // Real player frames from the supplied MedievalFree atlas.
    const playerIdle = this.cropAtlas(medieval, 0, 32, 32, 32);
    const playerWalk = this.createCanvas(64, 32)[0];
    const walkCtx = playerWalk.getContext('2d')!;
    walkCtx.imageSmoothingEnabled = false;
    walkCtx.drawImage(medieval, 0, 64, 32, 32, 0, 0, 32, 32);
    walkCtx.drawImage(medieval, 32, 64, 32, 32, 32, 0, 32, 32);
    for (const direction of ['down', 'up', 'left', 'right'] as const) {
      this.replaceAsset(`player_${direction}_idle`, 'MedievalFree hero idle', 'player', 32, 32, 1, playerIdle);
      this.replaceAsset(`player_${direction}_walk`, 'MedievalFree hero walk', 'player', 32, 32, 2, playerWalk);
      this.replaceAsset(`player_${direction}_run`, 'MedievalFree hero run', 'player', 32, 32, 2, playerWalk);
    }
    this.replaceAsset('player_death', 'MedievalFree hero death', 'player', 32, 32, 1, this.cropAtlas(medieval, 0, 160, 32, 32));
    this.replaceAsset('player_down_swim', 'MedievalFree hero swim', 'player', 32, 32, 2, this.cropAtlas(medieval, 320, 160, 64, 32));

    const iconFiles: Partial<Record<ItemId, string>> = {
      wooden_axe: 'axe.png', stone_pickaxe: 'pickaxe.png', wooden_sword: 'sword.png',
      torch: 'torch.png', wood: 'log.png', stone: 'iron_armor.png',
    };
    await Promise.all(Object.entries(iconFiles).map(async ([item, file]) => {
      try {
        const icon = await this.loadImage(`/assets/rpg_icons_free/${file}`);
        this.replaceAsset(`item_${item}`, `Provided RPG icon: ${item}`, 'items', 24, 24, 1, this.cropAtlas(icon, 0, 0, 24, 24));
      } catch {
        // Keep the generated fallback if an optional matching icon is unavailable.
      }
    }));

    this.cache.set('provided_assets_loaded', document.createElement('canvas'));
  }

  public get(id: string): CanvasImage | null {
    if (!this.cache.has(id)) {
      this.init();
    }
    return this.cache.get(id) || null;
  }
}

export const sprites = new SpriteRegistry();
