import {
  CLOVER_HOLD_SECONDS,
  Clover,
  MapTheme,
  PlayerState,
  RainbowNpc,
  TILE_PX,
  Train,
  TrainStyle,
} from './types';

function hash2D(x: number, y: number): number {
  let h = (x * 374761393 + y * 668265263) | 0;
  h = ((h ^ (h >> 13)) * 1274126177) | 0;
  return ((h ^ (h >> 16)) >>> 0) / 4294967295;
}

export function drawTileBackground(
  ctx: CanvasRenderingContext2D,
  col: number,
  row: number,
  px: number,
  py: number
): void {
  const isTrack = col === 1 || col === 2 || col === 4 || col === 5;
  const r = hash2D(col, row);
  const r2 = hash2D(col + 17, row * 3 + 5);

  if (!isTrack) {
    // Lush grassy safe verge or countryside embankment
    const baseShade = (col === 0 || col === 3 || col === 6)
      ? (r > 0.5 ? '#4e8f3f' : '#478639')
      : (r > 0.65 ? '#3e7732' : r > 0.3 ? '#468238' : '#376b2d');
    ctx.fillStyle = baseShade;
    ctx.fillRect(px, py, TILE_PX, TILE_PX);

    // Subtle grass pixel blades
    ctx.fillStyle = '#62a84f';
    if (r > 0.25) {
      const gx = px + Math.floor(r * 16) + 2;
      const gy = py + Math.floor(r2 * 16) + 3;
      ctx.fillRect(gx, gy, 1, 2);
      ctx.fillRect(gx + 2, gy + 1, 1, 1);
    }
    if (r2 > 0.45) {
      const gx = px + Math.floor(r2 * 15) + 4;
      const gy = py + Math.floor(r * 15) + 4;
      ctx.fillStyle = '#336129';
      ctx.fillRect(gx, gy, 2, 1);
    }

    // Occasional tiny wildflowers on grass strips
    if (r > 0.84) {
      const fx = px + 5 + Math.floor(r2 * 12);
      const fy = py + 5 + Math.floor(r * 12);
      ctx.fillStyle = r2 > 0.5 ? '#f4f7ec' : '#fde047';
      ctx.fillRect(fx, fy, 2, 2);
      ctx.fillStyle = '#ca8a04';
      ctx.fillRect(fx, fy, 1, 1);
    }

    // Gravel curb border next to tracks for safe columns (0, 3, 6)
    if (col === 0 || col === 3) {
      ctx.fillStyle = '#2c5425';
      ctx.fillRect(px + TILE_PX - 1, py, 1, TILE_PX);
    }
    if (col === 3 || col === 6) {
      ctx.fillStyle = '#2c5425';
      ctx.fillRect(px, py, 1, TILE_PX);
    }

    // Countryside props outside the 7-column corridor
    if (col < 0 || col >= 7) {
      drawCountrysideProp(ctx, col, row, px, py, r, r2);
    }
    return;
  }

  // Railway track tile: gravel ballast bed
  ctx.fillStyle = '#5a6065';
  ctx.fillRect(px, py, TILE_PX, TILE_PX);

  // Outer ballast shoulder shading
  ctx.fillStyle = '#474c51';
  ctx.fillRect(px, py, 2, TILE_PX);
  ctx.fillRect(px + TILE_PX - 2, py, 2, TILE_PX);

  // Speckles of gravel
  for (let i = 0; i < 6; i++) {
    const sr = hash2D(col * 13 + i, row * 29 + i);
    const sx = px + 3 + Math.floor(sr * (TILE_PX - 6));
    const sy = py + ((i * 4 + Math.floor(sr * 5)) % TILE_PX);
    ctx.fillStyle = i % 2 === 0 ? '#747b82' : '#4a4f54';
    ctx.fillRect(sx, sy, 1, 1);
  }

  // Wooden sleepers (ties) — 3 sleepers per 24px tile (every 8px)
  for (let sy = 2; sy < TILE_PX; sy += 8) {
    ctx.fillStyle = '#4b2e17';
    ctx.fillRect(px + 2, py + sy, TILE_PX - 4, 3);
    ctx.fillStyle = '#6d4525';
    ctx.fillRect(px + 3, py + sy, TILE_PX - 6, 2);
    ctx.fillStyle = '#382110';
    ctx.fillRect(px + 2, py + sy + 2, TILE_PX - 4, 1);
  }

  // Steel rails (left rail at +5, right rail at +17)
  // Shadow
  ctx.fillStyle = '#2d3339';
  ctx.fillRect(px + 6, py, 1, TILE_PX);
  ctx.fillRect(px + 18, py, 1, TILE_PX);
  // Rail body
  ctx.fillStyle = '#8e99a3';
  ctx.fillRect(px + 5, py, 2, TILE_PX);
  ctx.fillRect(px + 17, py, 2, TILE_PX);
  // Specular glint
  ctx.fillStyle = '#d3dde6';
  ctx.fillRect(px + 5, py, 1, TILE_PX);
  ctx.fillRect(px + 17, py, 1, TILE_PX);
}

function drawCountrysideProp(
  ctx: CanvasRenderingContext2D,
  col: number,
  row: number,
  px: number,
  py: number,
  r: number,
  r2: number
): void {
  // Wooden trackside fence along col -1 and col 7
  if (col === -1) {
    ctx.fillStyle = '#5a3c22';
    ctx.fillRect(px + TILE_PX - 3, py, 1, TILE_PX);
    if (Math.abs(row) % 2 === 0) {
      ctx.fillStyle = '#7c5331';
      ctx.fillRect(px + TILE_PX - 4, py + 8, 3, 5);
    }
    // Overhead catenary pole every 5 rows
    if (((row % 5) + 5) % 5 === 0) {
      ctx.fillStyle = '#475569';
      ctx.fillRect(px + TILE_PX - 6, py + 4, 3, 14);
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(px + TILE_PX - 5, py + 4, 1, 14);
    }
  } else if (col === 7) {
    ctx.fillStyle = '#5a3c22';
    ctx.fillRect(px + 2, py, 1, TILE_PX);
    if (Math.abs(row) % 2 === 0) {
      ctx.fillStyle = '#7c5331';
      ctx.fillRect(px + 1, py + 8, 3, 5);
    }
    // Japanese kilometer marker post every 8 rows
    if (((row % 8) + 8) % 8 === 2) {
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(px + 5, py + 10, 2, 8);
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(px + 4, py + 6, 5, 6);
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(px + 5, py + 8, 3, 1);
      ctx.fillRect(px + 5, py + 10, 2, 1);
    }
  } else if (r > 0.72) {
    // Lush pixel pine / shrub / bamboo cluster further out
    if (r2 > 0.45) {
      // Pine tree
      const cx = px + 12;
      const cy = py + 14;
      ctx.fillStyle = '#1c3820';
      ctx.fillRect(cx - 2, cy + 2, 4, 5);
      ctx.fillStyle = '#5c3c22';
      ctx.fillRect(cx - 1, cy + 1, 2, 5);

      ctx.fillStyle = '#1f4d28';
      ctx.fillRect(cx - 6, cy - 2, 12, 4);
      ctx.fillRect(cx - 5, cy - 6, 10, 4);
      ctx.fillRect(cx - 3, cy - 9, 6, 3);
      ctx.fillStyle = '#2e6f38';
      ctx.fillRect(cx - 5, cy - 3, 10, 2);
      ctx.fillRect(cx - 4, cy - 7, 8, 2);
      ctx.fillRect(cx - 2, cy - 10, 4, 2);
    } else {
      // Soft pixel bush + wild clover patch
      const bx = px + 6;
      const by = py + 10;
      ctx.fillStyle = '#24522a';
      ctx.fillRect(bx, by + 2, 11, 5);
      ctx.fillRect(bx + 2, by, 7, 2);
      ctx.fillStyle = '#387d3e';
      ctx.fillRect(bx + 1, by + 1, 8, 3);
    }
  }
}

export function drawTrackWarningOverlay(
  ctx: CanvasRenderingContext2D,
  col: number,
  screenX: number,
  canvasHeight: number,
  train: Train,
  timeSec: number
): void {
  const blink = Math.floor(timeSec * 10) % 2 === 0;
  // Subtle rail warning tint down the column
  ctx.fillStyle = blink ? 'rgba(239, 68, 68, 0.16)' : 'rgba(250, 204, 21, 0.11)';
  ctx.fillRect(screenX + 2, 0, TILE_PX - 4, canvasHeight);

  // Shimmering rail highlight
  ctx.fillStyle = blink ? '#facc15' : '#ef4444';
  ctx.fillRect(screenX + 5, 0, 1, canvasHeight);
  ctx.fillRect(screenX + 17, 0, 1, canvasHeight);

  // Fumikiri blinker housing at the entry edge (top if moving down, bottom if moving up)
  const isFromTop = train.direction === -1;
  const edgeY = isFromTop ? 6 : canvasHeight - 24;

  // Black & yellow hazard backing box
  ctx.fillStyle = '#111827';
  ctx.fillRect(screenX + 2, edgeY, TILE_PX - 4, 18);
  ctx.fillStyle = '#facc15';
  ctx.fillRect(screenX + 3, edgeY + 1, TILE_PX - 6, 1);
  ctx.fillRect(screenX + 3, edgeY + 16, TILE_PX - 6, 1);

  // Alternating red lamps
  ctx.fillStyle = blink ? '#ef4444' : '#7f1d1d';
  ctx.fillRect(screenX + 5, edgeY + 4, 5, 4);
  ctx.fillStyle = !blink ? '#ef4444' : '#7f1d1d';
  ctx.fillRect(screenX + 14, edgeY + 4, 5, 4);

  // Bright core dot
  ctx.fillStyle = '#fef08a';
  if (blink) {
    ctx.fillRect(screenX + 7, edgeY + 5, 1, 2);
  } else {
    ctx.fillRect(screenX + 16, edgeY + 5, 1, 2);
  }

  // Directional pixel chevron arrow
  const arrowY = edgeY + 11;
  const cx = screenX + 12;
  ctx.fillStyle = blink ? '#facc15' : '#f8fafc';
  if (isFromTop) {
    // Down arrow
    ctx.fillRect(cx - 3, arrowY, 6, 1);
    ctx.fillRect(cx - 2, arrowY + 1, 4, 1);
    ctx.fillRect(cx - 1, arrowY + 2, 2, 1);
  } else {
    // Up arrow
    ctx.fillRect(cx - 1, arrowY, 2, 1);
    ctx.fillRect(cx - 2, arrowY + 1, 4, 1);
    ctx.fillRect(cx - 3, arrowY + 2, 6, 1);
  }
  void col;
}

export function drawClover(
  ctx: CanvasRenderingContext2D,
  clover: Clover,
  px: number,
  py: number,
  timeSec: number,
  isStandingOn: boolean
): void {
  // Blink gently if about to wilt (last 3 seconds and not currently being collected)
  const remainingLife = clover.maxAge - clover.age;
  if (!isStandingOn && remainingLife < 3.0) {
    if (Math.floor(timeSec * 8) % 2 === 0) {
      ctx.globalAlpha = 0.45;
    }
  }

  // Sprout pop scale during first 0.25s
  const sproutT = Math.min(1, clover.age / 0.25);
  const cx = Math.round(px + TILE_PX / 2);
  const cy = Math.round(py + TILE_PX / 2) + 1;
  const sway = Math.round(Math.sin(timeSec * 3.2 + clover.swayOffset));

  // Soft ground highlight circle when active or golden
  if (isStandingOn || clover.kind === 'golden') {
    ctx.fillStyle = clover.kind === 'golden' ? 'rgba(250, 204, 21, 0.28)' : 'rgba(74, 222, 128, 0.26)';
    ctx.fillRect(px + 4, py + 4, TILE_PX - 8, TILE_PX - 8);
  }

  if (sproutT > 0.2) {
    const isGold = clover.kind === 'golden';
    const outline = isGold ? '#713f12' : '#14532d';
    const body = isGold ? '#facc15' : '#22c55e';
    const light = isGold ? '#fef08a' : '#86efac';

    // Stem
    ctx.fillStyle = outline;
    ctx.fillRect(cx, cy + 2, 2, 5);
    ctx.fillStyle = body;
    ctx.fillRect(cx, cy + 2, 1, 4);

    // Three-leaf clover silhouette (Top leaf, Left leaf, Right leaf)
    // Dark outline pass
    ctx.fillStyle = outline;
    // Top leaf outline
    ctx.fillRect(cx - 3 + sway, cy - 6, 6, 5);
    // Left leaf outline
    ctx.fillRect(cx - 7 + sway, cy - 2, 6, 5);
    // Right leaf outline
    ctx.fillRect(cx + 1 + sway, cy - 2, 6, 5);

    // Main leaf fill
    ctx.fillStyle = body;
    ctx.fillRect(cx - 2 + sway, cy - 5, 4, 3);
    ctx.fillRect(cx - 6 + sway, cy - 1, 4, 3);
    ctx.fillRect(cx + 2 + sway, cy - 1, 4, 3);

    // Leaf highlights
    ctx.fillStyle = light;
    ctx.fillRect(cx - 1 + sway, cy - 5, 2, 1);
    ctx.fillRect(cx - 5 + sway, cy - 1, 2, 1);
    ctx.fillRect(cx + 3 + sway, cy - 1, 2, 1);

    // Tiny center node
    ctx.fillStyle = outline;
    ctx.fillRect(cx - 1 + sway, cy, 2, 1);

    // MARAU ambient pixel sparkle glint
    const glintPhase = Math.floor(timeSec * 5 + clover.swayOffset * 3) % 4;
    if (glintPhase === 0) {
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(cx - 6, cy - 6, 1, 1);
      ctx.fillRect(cx + 5, cy + 3, 1, 1);
    } else if (glintPhase === 2) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(cx + 5, cy - 6, 1, 1);
      ctx.fillRect(cx - 6, cy + 3, 1, 1);
    }
  }

  ctx.globalAlpha = 1;

  // Draw crisp 3.0s collection gauge directly around/above the clover when player stands on it
  if (clover.collectProgress > 0) {
    const ratio = Math.min(1, clover.collectProgress / CLOVER_HOLD_SECONDS);
    const barW = 18;
    const barX = px + 3;
    const barY = py - 5;

    // Frame
    ctx.fillStyle = '#09130c';
    ctx.fillRect(barX - 1, barY - 1, barW + 2, 5);
    ctx.fillStyle = '#1e3324';
    ctx.fillRect(barX, barY, barW, 3);

    const fillW = Math.max(1, Math.round(barW * ratio));
    ctx.fillStyle = ratio > 0.72 ? '#facc15' : '#4ade80';
    ctx.fillRect(barX, barY, fillW, 3);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(barX, barY, fillW, 1);
  }
}

export function drawPlayer(
  ctx: CanvasRenderingContext2D,
  player: PlayerState,
  px: number,
  py: number,
  timeSec: number
): void {
  const cx = Math.round(px + TILE_PX / 2);
  const cy = Math.round(py + TILE_PX / 2) + 2;

  // Ground shadow
  const shadowShrink = Math.round(player.hopZ * 0.4);
  ctx.fillStyle = 'rgba(10, 20, 14, 0.45)';
  ctx.fillRect(cx - 6 + shadowShrink, cy + 6, Math.max(4, 12 - shadowShrink * 2), 3);

  ctx.save();
  const drawX = cx;
  const drawY = Math.round(cy - player.hopZ);
  ctx.translate(drawX, drawY);
  ctx.scale(player.squashX, player.squashY);

  const bob = player.collectPose
    ? Math.round(Math.sin(timeSec * 12) * 1)
    : player.isMoving
      ? 0
      : Math.round(Math.sin(timeSec * 4) * 0.6);

  // Feet / brown boots
  const stepSwing = player.isMoving ? 2 : 0;
  ctx.fillStyle = '#29170b';
  ctx.fillRect(-5, 3 + bob - stepSwing, 4, 4);
  ctx.fillRect(1, 3 + bob + stepSwing, 4, 4);
  ctx.fillStyle = '#6f4324';
  ctx.fillRect(-4, 4 + bob - stepSwing, 2, 2);
  ctx.fillRect(2, 4 + bob + stepSwing, 2, 2);

  // Cute outfit (dark green traveler tunic & cream collar)
  ctx.fillStyle = '#13261b';
  ctx.fillRect(-5, -2 + bob, 10, 6);
  ctx.fillStyle = '#2d6a4f';
  ctx.fillRect(-4, -1 + bob, 8, 4);
  ctx.fillStyle = '#40916c';
  ctx.fillRect(-3, -1 + bob, 6, 2);

  // Hands (raised happily when collecting clover!)
  ctx.fillStyle = '#ffd5b3';
  if (player.collectPose) {
    ctx.fillRect(-7, -3 + bob, 2, 2);
    ctx.fillRect(5, -3 + bob, 2, 2);
  } else {
    ctx.fillRect(-6, 0 + bob, 2, 2);
    ctx.fillRect(4, 0 + bob, 2, 2);
  }

  // Face / Head
  ctx.fillStyle = '#171e18';
  ctx.fillRect(-5, -8 + bob, 10, 7);
  ctx.fillStyle = '#ffd5b3';
  ctx.fillRect(-4, -7 + bob, 8, 5);

  // Rosy cheeks
  ctx.fillStyle = '#f28482';
  ctx.fillRect(-4, -4 + bob, 2, 1);
  ctx.fillRect(2, -4 + bob, 2, 1);

  // Eyes (X X if knocked out, happy ^_^ if collecting, cute dots otherwise)
  ctx.fillStyle = '#171e18';
  if (player.knockedOut) {
    ctx.fillRect(-3, -6 + bob, 1, 1);
    ctx.fillRect(-2, -5 + bob, 1, 1);
    ctx.fillRect(2, -6 + bob, 1, 1);
    ctx.fillRect(1, -5 + bob, 1, 1);
  } else if (player.collectPose) {
    ctx.fillRect(-3, -5 + bob, 2, 1);
    ctx.fillRect(1, -5 + bob, 2, 1);
  } else {
    const eyeShift = player.facing === 'LEFT' ? -1 : player.facing === 'RIGHT' ? 1 : 0;
    ctx.fillRect(-3 + eyeShift, -6 + bob, 2, 2);
    ctx.fillRect(1 + eyeShift, -6 + bob, 2, 2);
    // Eye sparkle
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(-3 + eyeShift, -6 + bob, 1, 1);
    ctx.fillRect(1 + eyeShift, -6 + bob, 1, 1);
  }

  // White chin strap
  ctx.fillStyle = '#f4f7ec';
  ctx.fillRect(-3, -3 + bob, 1, 2);
  ctx.fillRect(2, -3 + bob, 1, 2);

  // VIETNAMESE FLAG CONICAL HAT (Nón Lá) — iconic Red & Yellow Star!
  const hatY = bob + Math.round(player.hatOffsetY);
  // Dark outline cone
  ctx.fillStyle = '#4a0c0a';
  ctx.fillRect(-9, -7 + hatY, 18, 2);
  ctx.fillRect(-7, -9 + hatY, 14, 2);
  ctx.fillRect(-5, -11 + hatY, 10, 2);
  ctx.fillRect(-3, -13 + hatY, 6, 2);
  ctx.fillRect(-1, -14 + hatY, 2, 1);

  // Vibrant Flag Red fill (#da251d)
  ctx.fillStyle = '#da251d';
  ctx.fillRect(-8, -7 + hatY, 16, 1);
  ctx.fillRect(-6, -9 + hatY, 12, 2);
  ctx.fillRect(-4, -11 + hatY, 8, 2);
  ctx.fillRect(-2, -13 + hatY, 4, 2);

  // Deeper red brim underside / rim highlight
  ctx.fillStyle = '#a61b15';
  ctx.fillRect(-8, -6 + hatY, 16, 1);
  ctx.fillStyle = '#ef4444';
  ctx.fillRect(-3, -12 + hatY, 2, 2);

  // Bright Golden-Yellow 5-point pixel star centered on the conical hat!
  ctx.fillStyle = '#facc15';
  ctx.fillRect(0, -12 + hatY, 1, 1); // top point
  ctx.fillRect(-2, -11 + hatY, 5, 1); // arms
  ctx.fillRect(-1, -10 + hatY, 3, 1); // core
  ctx.fillRect(-2, -9 + hatY, 1, 1); // left leg
  ctx.fillRect(2, -9 + hatY, 1, 1); // right leg
  ctx.fillStyle = '#fef08a';
  ctx.fillRect(0, -11 + hatY, 1, 1); // star center shine

  // Dizzy stars on knockout
  if (player.knockedOut) {
    const spin = timeSec * 7;
    const sx1 = Math.round(Math.cos(spin) * 7);
    const sx2 = Math.round(Math.cos(spin + Math.PI) * 7);
    ctx.fillStyle = '#fde047';
    ctx.fillRect(sx1, -16, 2, 2);
    ctx.fillRect(sx2, -15, 2, 2);
  }

  ctx.restore();
}

interface TrainPalette {
  body: string;
  bodyShade: string;
  roof: string;
  stripe: string;
  stripeAccent: string;
  nose: string;
}

const TRAIN_PALETTES: Record<TrainStyle, TrainPalette> = {
  yamanote: {
    body: '#cbd5e1',
    bodyShade: '#94a3b8',
    roof: '#475569',
    stripe: '#65a30d',
    stripeAccent: '#a3e635',
    nose: '#334155',
  },
  chuo: {
    body: '#dc2626',
    bodyShade: '#991b1b',
    roof: '#451a1a',
    stripe: '#fef3c7',
    stripeAccent: '#facc15',
    nose: '#7f1d1d',
  },
  shinkansen: {
    body: '#f8fafc',
    bodyShade: '#cbd5e1',
    roof: '#94a3b8',
    stripe: '#2563eb',
    stripeAccent: '#60a5fa',
    nose: '#f8fafc',
  },
  dryellow: {
    body: '#facc15',
    bodyShade: '#ca8a04',
    roof: '#854d0e',
    stripe: '#1e3a8a',
    stripeAccent: '#3b82f6',
    nose: '#facc15',
  },
  city_tram: {
    body: '#15803d',
    bodyShade: '#166534',
    roof: '#cbd5e1',
    stripe: '#fef3c7',
    stripeAccent: '#facc15',
    nose: '#14532d',
  },
  twelve_bus: {
    body: '#dc2626',
    bodyShade: '#991b1b',
    roof: '#f8fafc',
    stripe: '#facc15',
    stripeAccent: '#fef08a',
    nose: '#7f1d1d',
  },
  metro_12: {
    body: '#334155',
    bodyShade: '#1e293b',
    roof: '#64748b',
    stripe: '#f97316',
    stripeAccent: '#facc15',
    nose: '#0f172a',
  },
};

export function drawTrain(
  ctx: CanvasRenderingContext2D,
  train: Train,
  screenX: number,
  noseScreenY: number,
  tailScreenY: number
): void {
  const pal = TRAIN_PALETTES[train.style];
  const topY = Math.round(Math.min(noseScreenY, tailScreenY));
  const bottomY = Math.round(Math.max(noseScreenY, tailScreenY));
  const totalH = bottomY - topY;
  if (totalH <= 0) return;

  const x = screenX + 2;
  const w = TILE_PX - 4; // 20px wide train centered on 24px track

  // Ground cast shadow along right side
  ctx.fillStyle = 'rgba(10, 16, 12, 0.35)';
  ctx.fillRect(x + w, topY + 2, 3, totalH - 2);

  // Train dark outer chassis
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(x, topY, w, totalH);

  // Main car body
  ctx.fillStyle = pal.body;
  ctx.fillRect(x + 1, topY + 1, w - 2, totalH - 2);

  // Side shading
  ctx.fillStyle = pal.bodyShade;
  ctx.fillRect(x + w - 3, topY + 1, 2, totalH - 2);

  // Roof ridge along center
  ctx.fillStyle = pal.roof;
  ctx.fillRect(x + 5, topY + 2, w - 10, totalH - 4);

  // Signature Japanese livery stripes along both sides
  ctx.fillStyle = pal.stripe;
  ctx.fillRect(x + 1, topY + 2, 3, totalH - 4);
  ctx.fillRect(x + w - 4, topY + 2, 3, totalH - 4);
  ctx.fillStyle = pal.stripeAccent;
  ctx.fillRect(x + 2, topY + 2, 1, totalH - 4);

  // Car couplers & passenger windows every 12px along length
  for (let wy = topY + 10; wy < bottomY - 10; wy += 12) {
    // Windows on left & right sides
    ctx.fillStyle = '#fef08a';
    ctx.fillRect(x + 2, wy, 2, 5);
    ctx.fillRect(x + w - 4, wy, 2, 5);

    // Roof AC / vent units
    ctx.fillStyle = '#64748b';
    ctx.fillRect(x + 7, wy, 6, 4);
    ctx.fillStyle = '#94a3b8';
    ctx.fillRect(x + 8, wy + 1, 4, 2);

    // Coupler gap every ~36px (car divider)
    if ((wy - topY) % 36 < 12) {
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(x + 1, wy - 3, w - 2, 2);
    }
  }

  // Front nose & headlights (leading edge based on direction)
  const isMovingDown = train.direction === -1;
  const frontY = isMovingDown ? bottomY - 9 : topY + 1;
  const rearY = isMovingDown ? topY + 1 : bottomY - 5;

  // Cab windshield
  ctx.fillStyle = pal.nose;
  ctx.fillRect(x + 2, frontY, w - 4, 8);
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(x + 4, frontY + (isMovingDown ? 2 : 3), w - 8, 3);
  ctx.fillStyle = '#38bdf8';
  ctx.fillRect(x + 5, frontY + (isMovingDown ? 2 : 3), 3, 1);

  // Bright yellow headlights + light cone beam
  const lightY = isMovingDown ? bottomY - 2 : topY;
  ctx.fillStyle = '#fef08a';
  ctx.fillRect(x + 3, lightY, 3, 2);
  ctx.fillRect(x + w - 6, lightY, 3, 2);

  // Soft headlight beam onto track ahead
  ctx.fillStyle = 'rgba(254, 240, 138, 0.22)';
  if (isMovingDown) {
    ctx.fillRect(x + 1, bottomY, w - 2, 16);
  } else {
    ctx.fillRect(x + 1, topY - 16, w - 2, 16);
  }

  // Red tail lamps on rear car
  ctx.fillStyle = '#ef4444';
  ctx.fillRect(x + 3, rearY + 1, 2, 2);
  ctx.fillRect(x + w - 5, rearY + 1, 2, 2);

  // Stamp crisp "12" emblem on Twelve City vehicles
  if (train.style === 'city_tram' || train.style === 'twelve_bus' || train.style === 'metro_12') {
    const midY = Math.round((topY + bottomY) / 2) - 3;
    if (totalH > 24) {
      drawPixelTwelve(ctx, x + 6, midY, '#facc15', '#0f172a');
    }
  }
}

/**
 * Draws a crisp 7x5 pixel-art "12" badge (with optional backing plate).
 */
export function drawPixelTwelve(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  fg: string,
  bg?: string
): void {
  if (bg) {
    ctx.fillStyle = bg;
    ctx.fillRect(x - 1, y - 1, 9, 7);
  }
  ctx.fillStyle = fg;
  // Digit "1" (2px wide)
  ctx.fillRect(x, y + 1, 1, 1);
  ctx.fillRect(x + 1, y, 1, 5);
  ctx.fillRect(x, y + 4, 3, 1);

  // Digit "2" (3px wide at x+4)
  ctx.fillRect(x + 4, y, 3, 1);
  ctx.fillRect(x + 6, y + 1, 1, 1);
  ctx.fillRect(x + 4, y + 2, 3, 1);
  ctx.fillRect(x + 4, y + 3, 1, 1);
  ctx.fillRect(x + 4, y + 4, 3, 1);
}

export function drawCityTileBackground(
  ctx: CanvasRenderingContext2D,
  col: number,
  row: number,
  px: number,
  py: number,
  timeSec: number
): void {
  const isTrack = col === 1 || col === 2 || col === 4 || col === 5;
  const r = hash2D(col, row);
  const r2 = hash2D(col + 31, row * 7 + 11);

  if (isTrack) {
    // Twelve City express tramway / street lane
    ctx.fillStyle = '#2d333b';
    ctx.fillRect(px, py, TILE_PX, TILE_PX);

    // Subtle cobblestone / asphalt texture
    ctx.fillStyle = '#383f48';
    ctx.fillRect(px + 2, py + 2, TILE_PX - 4, TILE_PX - 4);
    if (r > 0.45) {
      ctx.fillStyle = '#242930';
      ctx.fillRect(px + 4 + Math.floor(r2 * 10), py + 4 + Math.floor(r * 12), 2, 1);
    }

    // Center dashed lane paint (yellow/cream)
    if (Math.abs(row) % 2 === 0) {
      ctx.fillStyle = '#eab308';
      ctx.fillRect(px + 11, py + 5, 2, 12);
    }

    // Embedded steel street-tram rails
    ctx.fillStyle = '#64748b';
    ctx.fillRect(px + 5, py, 2, TILE_PX);
    ctx.fillRect(px + 17, py, 2, TILE_PX);
    ctx.fillStyle = '#cbd5e1';
    ctx.fillRect(px + 5, py, 1, TILE_PX);
    ctx.fillRect(px + 17, py, 1, TILE_PX);
    return;
  }

  // Non-track pedestrian sidewalk / city plaza (cols 0, 3, 6) or flanking Twelve City blocks
  if (col >= 0 && col < 7) {
    // Urban pavement with green planter accents
    ctx.fillStyle = r > 0.5 ? '#5b646e' : '#535c66';
    ctx.fillRect(px, py, TILE_PX, TILE_PX);

    // Paving stone grid lines
    ctx.fillStyle = '#404750';
    ctx.fillRect(px, py + 11, TILE_PX, 1);
    ctx.fillRect(px + 11, py, 1, TILE_PX);

    // Curb borders next to tram lanes
    if (col === 0 || col === 3) {
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(px + TILE_PX - 2, py, 2, TILE_PX);
    }
    if (col === 3 || col === 6) {
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(px, py, 2, TILE_PX);
    }

    // Tiny green urban tree/shrub planters or "12" sidewalk tiles occasionally
    if (r > 0.86) {
      // Cute brown planter box with green bush
      ctx.fillStyle = '#5c3c22';
      ctx.fillRect(px + 6, py + 7, 12, 10);
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(px + 7, py + 6, 10, 8);
      ctx.fillStyle = '#86efac';
      ctx.fillRect(px + 8, py + 7, 4, 3);
    } else if (r < 0.14) {
      // Stamped "12" street medallion on plaza stone
      drawPixelTwelve(ctx, px + 8, py + 14, '#94a3b8');
    }
    return;
  }

  // Flanking Twelve City buildings (col < 0 and col >= 7)
  const buildingSeed = hash2D(col, Math.floor(row / 2));
  const paletteIdx = Math.floor(buildingSeed * 4);
  const wallColors = ['#6b4432', '#475569', '#52525b', '#3b5249'];
  const shadeColors = ['#4d2f21', '#334155', '#3f3f46', '#283832'];
  const trimColors = ['#a16207', '#94a3b8', '#71717a', '#65a30d'];

  const wall = wallColors[paletteIdx];
  const shade = shadeColors[paletteIdx];
  const trim = trimColors[paletteIdx];

  // Building base & alley border
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(px, py, TILE_PX, TILE_PX);

  // Sidewalk curb right adjacent to corridor (col -1 right edge, col 7 left edge)
  if (col === -1) {
    ctx.fillStyle = '#64748b';
    ctx.fillRect(px + TILE_PX - 5, py, 5, TILE_PX);
    ctx.fillStyle = wall;
    ctx.fillRect(px + 1, py + 1, TILE_PX - 6, TILE_PX - 2);
    ctx.fillStyle = trim;
    ctx.fillRect(px + 1, py + 1, TILE_PX - 6, 2);

    // Prominent "12" building sign or neon billboard!
    const blink = Math.floor(timeSec * 2 + row) % 2 === 0;
    if (Math.abs(row) % 2 === 0) {
      drawPixelTwelve(
        ctx,
        px + 5,
        py + 8,
        blink ? '#fef08a' : '#facc15',
        '#111827'
      );
      // Glowing little shop window below
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(px + 4, py + 16, 10, 4);
    } else {
      // Rooftop / facade windows + mini "12"
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(px + 4, py + 5, 4, 5);
      ctx.fillRect(px + 11, py + 5, 4, 5);
      drawPixelTwelve(ctx, px + 5, py + 14, '#ef4444', '#f8fafc');
    }
    return;
  }

  if (col === 7) {
    ctx.fillStyle = '#64748b';
    ctx.fillRect(px, py, 5, TILE_PX);
    ctx.fillStyle = wall;
    ctx.fillRect(px + 5, py + 1, TILE_PX - 6, TILE_PX - 2);
    ctx.fillStyle = trim;
    ctx.fillRect(px + 5, py + 1, TILE_PX - 6, 2);

    const blink = Math.floor(timeSec * 2 + row) % 2 === 0;
    if (Math.abs(row) % 2 === 1) {
      drawPixelTwelve(
        ctx,
        px + 9,
        py + 8,
        blink ? '#38bdf8' : '#facc15',
        '#0f172a'
      );
      ctx.fillStyle = '#fde047';
      ctx.fillRect(px + 8, py + 16, 10, 4);
    } else {
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(px + 8, py + 5, 4, 5);
      ctx.fillRect(px + 15, py + 5, 4, 5);
      drawPixelTwelve(ctx, px + 9, py + 14, '#facc15', '#7f1d1d');
    }
    return;
  }

  // Outer cityscape buildings with bold "12" billboards & lit windows
  ctx.fillStyle = wall;
  ctx.fillRect(px + 1, py + 1, TILE_PX - 2, TILE_PX - 2);
  ctx.fillStyle = shade;
  ctx.fillRect(px + TILE_PX - 4, py + 1, 3, TILE_PX - 2);
  ctx.fillStyle = trim;
  ctx.fillRect(px + 1, py + 1, TILE_PX - 2, 2);

  if (r > 0.35) {
    // Large high-contrast "12" sign on outer building
    const isAlt = r2 > 0.5;
    drawPixelTwelve(
      ctx,
      px + 8,
      py + 9,
      isAlt ? '#facc15' : '#ffffff',
      isAlt ? '#0f172a' : '#b91c1c'
    );
    ctx.fillStyle = '#fef08a';
    ctx.fillRect(px + 4, py + 17, 5, 3);
    ctx.fillRect(px + 14, py + 17, 5, 3);
  } else {
    // Classic apartment windows
    ctx.fillStyle = r2 > 0.3 ? '#fef08a' : '#334155';
    ctx.fillRect(px + 4, py + 6, 5, 5);
    ctx.fillRect(px + 13, py + 6, 5, 5);
    ctx.fillStyle = r > 0.2 ? '#fef08a' : '#1e293b';
    ctx.fillRect(px + 4, py + 14, 5, 5);
    ctx.fillRect(px + 13, py + 14, 5, 5);
  }
}

const RAINBOW_COLORS = [
  '#ef4444', // Red
  '#f97316', // Orange
  '#facc15', // Yellow
  '#22c55e', // Green
  '#06b6d4', // Cyan
  '#3b82f6', // Blue
  '#a855f7', // Violet
];

export function drawRainbowNpc(
  ctx: CanvasRenderingContext2D,
  npc: RainbowNpc,
  px: number,
  py: number,
  timeSec: number
): void {
  const cx = Math.round(px + TILE_PX / 2);
  const cy = Math.round(py + TILE_PX / 2) + 2;

  // Ground shadow
  ctx.fillStyle = 'rgba(10, 20, 14, 0.45)';
  ctx.fillRect(cx - 5, cy + 6, 10, 3);

  const stride = Math.round(Math.sin(npc.animPhase * 14) * 2);
  const bounce = Math.abs(Math.round(Math.sin(npc.animPhase * 14)));
  const shift = Math.floor(timeSec * 8);

  ctx.save();
  ctx.translate(cx, cy - bounce);

  // Sprinting legs / sneakers
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(-4, 3 - Math.max(0, stride), 3, 4);
  ctx.fillRect(1, 3 + Math.min(0, stride), 3, 4);
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(-4, 6 - Math.max(0, stride), 3, 1);
  ctx.fillRect(1, 6 + Math.min(0, stride), 3, 1);

  // Sporty jacket torso
  ctx.fillStyle = '#111827';
  ctx.fillRect(-5, -2, 10, 6);
  ctx.fillStyle = '#312e81';
  ctx.fillRect(-4, -1, 8, 4);
  // Rainbow chest stripe
  ctx.fillStyle = RAINBOW_COLORS[(shift + 2) % RAINBOW_COLORS.length];
  ctx.fillRect(-3, 0, 6, 1);

  // Pumping arms
  ctx.fillStyle = '#ffd5b3';
  ctx.fillRect(-7, -1 + stride, 2, 3);
  ctx.fillRect(5, -1 - stride, 2, 3);

  // Head
  ctx.fillStyle = '#111827';
  ctx.fillRect(-5, -8, 10, 7);
  ctx.fillStyle = '#ffd5b3';
  ctx.fillRect(-4, -7, 8, 5);

  // Cheeky eyes / smug grin
  ctx.fillStyle = '#111827';
  const eyeY = npc.direction === 1 ? -6 : -5;
  ctx.fillRect(-3, eyeY, 2, 2);
  ctx.fillRect(1, eyeY, 2, 2);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(-3, eyeY, 1, 1);
  ctx.fillRect(1, eyeY, 1, 1);
  // Cheeky smirk
  ctx.fillStyle = '#be123c';
  ctx.fillRect(-1, -3, 3, 1);

  // 7-COLOR RAINBOW HAIR (flowing pixel mane!)
  // Dark hair outline
  ctx.fillStyle = '#090d16';
  ctx.fillRect(-7, -13, 14, 6);
  ctx.fillRect(-8, -11, 2, 6);
  ctx.fillRect(6, -11, 2, 6);

  // 7 distinct rainbow vertical/layered bands across hair crown
  for (let i = 0; i < 7; i++) {
    const colColor = RAINBOW_COLORS[(i + shift) % 7];
    ctx.fillStyle = colColor;
    const bx = -7 + i * 2;
    const wave = ((i + Math.floor(timeSec * 6)) % 2 === 0) ? 0 : -1;
    ctx.fillRect(bx, -12 + wave, 2, 5);
  }
  // Flowing side locks
  ctx.fillStyle = RAINBOW_COLORS[0];
  ctx.fillRect(-7, -8, 2, 3);
  ctx.fillStyle = RAINBOW_COLORS[6];
  ctx.fillRect(5, -8, 2, 3);

  ctx.restore();
}

export function drawMapTransitionOverlay(
  ctx: CanvasRenderingContext2D,
  viewW: number,
  viewH: number,
  progress: number, // 0 -> 1
  targetMap: MapTheme
): void {
  // Triangle wave: 0 -> 1 at 0.5 -> 0 at 1.0
  const intensity = progress < 0.5 ? progress * 2 : (1 - progress) * 2;
  const blockSize = 12;
  const cols = Math.ceil(viewW / blockSize);
  const rows = Math.ceil(viewH / blockSize);

  const tileColor = targetMap === 'TWELVE_CITY' ? '#1e293b' : '#143322';
  const accentColor = targetMap === 'TWELVE_CITY' ? '#facc15' : '#4ade80';

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      // Staggered diagonal pixel-wipe threshold
      const diag = (c / cols + r / rows) * 0.5;
      if (intensity > diag * 0.85) {
        ctx.fillStyle = (c + r) % 7 === 0 ? accentColor : tileColor;
        ctx.globalAlpha = Math.min(0.92, intensity * 1.15);
        ctx.fillRect(c * blockSize, r * blockSize, blockSize, blockSize);
      }
    }
  }
  ctx.globalAlpha = 1;

  // Crisp announcement banner near center during mid-wipe
  if (intensity > 0.35) {
    const label = targetMap === 'TWELVE_CITY' ? 'CITY TWEENS' : '36 AREA';
    const bw = 112;
    const bh = 22;
    const bx = Math.round((viewW - bw) / 2);
    const by = Math.round((viewH - bh) / 2);

    ctx.fillStyle = '#09130c';
    ctx.fillRect(bx - 2, by - 2, bw + 4, bh + 4);
    ctx.fillStyle = targetMap === 'TWELVE_CITY' ? '#1e293b' : '#172b1e';
    ctx.fillRect(bx, by, bw, bh);
    ctx.fillStyle = accentColor;
    ctx.fillRect(bx, by, bw, 2);
    ctx.fillRect(bx, by + bh - 2, bw, 2);

    ctx.font = 'bold 9px monospace';
    ctx.textAlign = 'center';
    ctx.fillStyle = accentColor;
    ctx.fillText(label, Math.round(viewW / 2), by + 14);
  }
}

