import * as THREE from "three";
import { mulberry32 } from "./noise";

export type Dir = "back" | "front" | "side";
export interface Frame {
  tex: THREE.Texture;
  aspect: number;
}
export interface SpriteSet {
  idle: Record<Dir, Frame[]>;
  walk: Record<Dir, Frame[]>;
}

const W = 32, H = 48;
const C = {
  hairD: "#1a1216", hair: "#2b1f25", hairL: "#44333b",
  skin: "#c9a38c", skinD: "#9f7b69",
  shirt: "#b3a28f", shirtD: "#877664",
  jacket: "#33262a", jacketL: "#4a383b",
  pants: "#19131a", pantsL: "#2c2329", patch: "#9a7472", patchD: "#6e4e50",
  belt: "#473630", buckle: "#9c8b70",
  boot: "#473b37", bootL: "#6d5e56", sole: "#221a19",
  cr: "#9d3ade", crL: "#d27cff", crH: "#f6d6ff", crD: "#5b1a8c",
  eye: "#ee8bff", eyeW: "#d9d2d2", out: "#0e090c",
};

type Ctx = CanvasRenderingContext2D;
function rect(c: Ctx, x: number, y: number, w: number, h: number, col: string) {
  c.fillStyle = col;
  c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}
function px(c: Ctx, x: number, y: number, col: string) {
  c.fillStyle = col;
  c.fillRect(Math.round(x), Math.round(y), 1, 1);
}

function spike(c: Ctx, x0: number, y0: number, dx: number, dy: number, len: number, thick = 2) {
  const l = Math.hypot(dx, dy) || 1;
  dx /= l; dy /= l;
  for (let i = 0; i < len; i++) {
    const x = x0 + dx * i, y = y0 + dy * i;
    const w = thick * (1 - i / (len + 0.5));
    if (w >= 1.4) {
      rect(c, x, y, 2, 2, C.cr);
      px(c, x, y, C.crL);
    } else px(c, x, y, i === len - 1 ? C.crH : C.crL);
  }
}

function crystalArm(c: Ctx, side: number, cx: number, top: number, bottom: number, seed: number, big = 1) {
  const r = mulberry32(seed);
  for (let y = top; y <= bottom; y++) {
    const w = 4 + (y > top + 3 ? 1 : 0) + (y > bottom - 4 ? 1 : 0);
    const x0 = cx - w / 2;
    rect(c, x0, y, w, 1, (y + seed) % 3 === 0 ? C.crD : C.cr);
    px(c, side < 0 ? x0 : x0 + w - 1, y, C.crD);
    if ((y * 7 + seed) % 5 === 0) px(c, cx, y, C.crL);
  }
  const n = Math.round(6 * big);
  for (let k = 0; k < n; k++) {
    const y = top + 1 + k * ((bottom - top - 2) / n) + r() * 1.5;
    const len = 3 + Math.floor(r() * 3 * big);
    spike(c, cx + side * 2, y, side * (0.8 + r() * 0.5), -0.7 + r() * 1.1, len, 2);
  }
  // shoulder spikes up
  spike(c, cx, top, side * 0.4, -1, 4 + Math.floor(r() * 2), 2);
  spike(c, cx + side * 2, top + 1, side * 0.9, -0.8, 4, 2);
  // claws
  for (let k = 0; k < 3; k++) spike(c, cx - 1 + k, bottom, side * 0.35 * (k - 0.5), 1, 3, 1);
  for (let k = 0; k < 4; k++) px(c, cx - 2 + r() * 4, top + 2 + r() * (bottom - top - 4), C.crH);
}

function headCrystal(c: Ctx, x: number, y: number, side: number) {
  spike(c, x, y + 6, side * 0.5, -1, 6, 2);
  spike(c, x, y + 5, side * 1, -0.6, 5, 2);
  spike(c, x, y + 7, side * 1, 0.1, 4, 2);
  spike(c, x - side, y + 3, side * 0.2, -1, 4, 1);
  rect(c, x - (side > 0 ? 1 : 0), y + 3, 2, 6, C.cr);
  px(c, x, y + 4, C.crH);
}

function legs(c: Ctx, phase: number, view: "back" | "front") {
  // phase 0/2 neutral, 1 = left leg forward, 3 = right leg forward
  const liftL = phase === 1 ? (view === "back" ? 2 : -1) : phase === 3 ? (view === "back" ? -1 : 2) : 0;
  const liftR = phase === 3 ? (view === "back" ? 2 : -1) : phase === 1 ? (view === "back" ? -1 : 2) : 0;
  const leg = (x: number, lift: number, patchY: number) => {
    const bot = 46 - lift;
    rect(c, x, 29, 5, bot - 29 - 6, C.pants);
    rect(c, x + (view === "back" ? 3 : 0), 30, 1, bot - 36, C.pantsL);
    rect(c, x + 1, patchY, 2, 2, C.patch);
    px(c, x + 1, patchY + 1, C.patchD);
    // boot
    rect(c, x, bot - 7, 5, 7, C.boot);
    for (let yy = bot - 6; yy < bot - 1; yy += 2) rect(c, x, yy, 5, 1, C.bootL);
    rect(c, x - (view === "front" ? 0 : 0), bot - 1, 5, 2, C.sole);
  };
  leg(10.5, liftL, 33);
  leg(16.5, liftR, 37);
  rect(c, 14.5, 28, 3, 3, C.pants);
}

function drawBack(c: Ctx, phase: number, bob: number, swing: number) {
  legs(c, phase, "back");
  const y = bob;
  // torso
  rect(c, 10, 15 + y, 12, 13, C.jacket);
  rect(c, 12, 15 + y, 8, 11, C.shirt);
  rect(c, 12, 22 + y, 8, 2, C.shirtD);
  px(c, 14, 18 + y, C.shirtD); px(c, 17, 20 + y, C.shirtD);
  rect(c, 11, 15 + y, 1, 12, C.jacketL);
  rect(c, 10, 26 + y, 12, 3, C.pants);
  rect(c, 10, 27 + y, 12, 1, C.belt);
  rect(c, 15, 27 + y, 2, 1, C.buckle);
  // neck
  rect(c, 14, 13 + y, 4, 2, C.skinD);
  // head (hair)
  rect(c, 10, 3 + y, 12, 11, C.hair);
  rect(c, 11, 2 + y, 10, 1, C.hair);
  rect(c, 9, 5 + y, 1, 7, C.hair);
  rect(c, 22, 5 + y, 1, 7, C.hair);
  for (let i = 0; i < 5; i++) rect(c, 11 + i * 2, 4 + y + (i % 2), 1, 7, C.hairL);
  rect(c, 10, 12 + y, 12, 2, C.hairD);
  px(c, 12, 1 + y, C.hair); px(c, 16, 1 + y, C.hair); px(c, 19, 1 + y, C.hair); px(c, 14, 0 + y, C.hairD);
  headCrystal(c, 21, 1 + y, 1);
  // arms
  crystalArm(c, -1, 7.5, 15 + y - swing, 30 + y - swing, 11);
  crystalArm(c, 1, 24.5, 15 + y + swing, 30 + y + swing, 29);
}

function drawFront(c: Ctx, phase: number, bob: number, swing: number) {
  legs(c, phase, "front");
  const y = bob;
  rect(c, 10, 15 + y, 12, 13, C.jacket);
  rect(c, 13, 15 + y, 6, 11, C.shirt);
  rect(c, 13, 20 + y, 6, 1, C.shirtD);
  px(c, 15, 17 + y, C.skin); px(c, 16, 18 + y, C.skin); px(c, 14, 23 + y, C.shirtD);
  // diagonal strap
  for (let i = 0; i < 9; i++) px(c, 11 + i, 15 + y + i, C.belt);
  rect(c, 10, 26 + y, 12, 3, C.pants);
  rect(c, 10, 27 + y, 12, 1, C.belt);
  rect(c, 15, 26 + y, 2, 3, C.buckle);
  // neck & face
  rect(c, 14, 13 + y, 4, 2, C.skinD);
  rect(c, 11, 5 + y, 10, 9, C.skin);
  rect(c, 11, 12 + y, 10, 1, C.skinD);
  px(c, 13, 9 + y, C.eyeW); px(c, 14, 9 + y, C.eyeW); px(c, 13, 10 + y, "#3a3033");
  px(c, 18, 9 + y, C.eye); px(c, 19, 9 + y, C.crH); px(c, 18, 10 + y, C.cr);
  rect(c, 15, 12 + y, 2, 1, C.skinD);
  // hair
  rect(c, 10, 2 + y, 12, 4, C.hair);
  rect(c, 9, 4 + y, 2, 8, C.hair);
  rect(c, 21, 4 + y, 2, 6, C.hair);
  rect(c, 11, 6 + y, 3, 2, C.hair); px(c, 12, 8 + y, C.hair);
  rect(c, 15, 6 + y, 2, 1, C.hair);
  for (let i = 0; i < 4; i++) px(c, 11 + i * 3, 3 + y, C.hairL);
  px(c, 12, 1 + y, C.hair); px(c, 17, 1 + y, C.hair); px(c, 20, 1 + y, C.hair);
  headCrystal(c, 20, 1 + y, 1);
  crystalArm(c, -1, 7.5, 15 + y + swing, 30 + y + swing, 29, 0.8);
  crystalArm(c, 1, 24.5, 15 + y - swing, 30 + y - swing, 11, 1.1);
}

function drawSide(c: Ctx, phase: number, bob: number, swing: number) {
  const y = bob;
  const stride = phase === 1 ? 3 : phase === 3 ? -3 : 0;
  const leg = (x: number, col: string, lift: number) => {
    const bot = 46 - lift;
    rect(c, x, 29, 5, bot - 36, col);
    rect(c, x, bot - 7, 5, 6, C.boot);
    rect(c, x, bot - 5, 6, 1, C.bootL);
    rect(c, x, bot - 3, 6, 1, C.bootL);
    rect(c, x, bot - 1, 7, 2, C.sole);
    px(c, x + 1, 34, C.patch);
  };
  // far leg
  leg(13.5 - stride, "#110d12", stride !== 0 ? 1 : 0);
  // far arm
  crystalArm(c, -1, 14 - swing, 15 + y, 29 + y, 5, 0.6);
  rect(c, 12, 15 + y, 9, 13, C.jacket);
  rect(c, 16, 15 + y, 4, 10, C.shirt);
  rect(c, 12, 26 + y, 9, 3, C.pants);
  rect(c, 12, 27 + y, 9, 1, C.belt);
  leg(14.5 + stride, C.pants, 0);
  // head
  rect(c, 15, 13 + y, 3, 2, C.skinD);
  rect(c, 12, 3 + y, 10, 10, C.hair);
  rect(c, 18, 6 + y, 4, 7, C.skin);
  rect(c, 21, 8 + y, 1, 2, C.skin);
  px(c, 20, 8 + y, C.eye);
  rect(c, 18, 4 + y, 5, 3, C.hair);
  px(c, 22, 7 + y, C.hair);
  for (let i = 0; i < 3; i++) px(c, 13 + i * 2, 2 + y, C.hair);
  px(c, 11, 5 + y, C.hair); px(c, 11, 8 + y, C.hairD);
  for (let i = 0; i < 3; i++) rect(c, 13 + i * 2, 5 + y, 1, 6, C.hairL);
  headCrystal(c, 14, 0 + y, -1);
  // near arm (crystal)
  crystalArm(c, 1, 17 + swing, 15 + y, 30 + y, 29, 0.9);
}

function outline(cv: HTMLCanvasElement) {
  const c = cv.getContext("2d")!;
  const img = c.getImageData(0, 0, W, H);
  const d = img.data;
  const out = new Uint8ClampedArray(d);
  for (let y = 0; y < H; y++)
    for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4;
      if (d[i + 3] > 0) continue;
      let n = false;
      for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const xx = x + ox, yy = y + oy;
        if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
        if (d[((yy * W + xx) * 4) + 3] > 0) n = true;
      }
      if (n) { out[i] = 14; out[i + 1] = 9; out[i + 2] = 12; out[i + 3] = 255; }
    }
  c.putImageData(new ImageData(out, W, H), 0, 0);
}

function tex(cv: HTMLCanvasElement | HTMLImageElement): THREE.Texture {
  const t = cv instanceof HTMLCanvasElement ? new THREE.CanvasTexture(cv) : new THREE.Texture(cv);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.colorSpace = THREE.NoColorSpace;
  t.needsUpdate = true;
  return t;
}

function makeFrame(draw: (c: Ctx) => void): Frame {
  const cv = document.createElement("canvas");
  cv.width = W;
  cv.height = H;
  const c = cv.getContext("2d")!;
  draw(c);
  outline(cv);
  return { tex: tex(cv), aspect: W / H };
}

export function buildProceduralSprites(): SpriteSet {
  const fns: Record<Dir, typeof drawBack> = { back: drawBack, front: drawFront, side: drawSide };
  const set: SpriteSet = { idle: { back: [], front: [], side: [] }, walk: { back: [], front: [], side: [] } };
  (Object.keys(fns) as Dir[]).forEach((d) => {
    const f = fns[d];
    set.idle[d].push(makeFrame((c) => f(c, 0, 0, 0)));
    set.idle[d].push(makeFrame((c) => f(c, 0, 1, 0)));
    for (let p = 0; p < 4; p++) {
      const bob = p % 2 === 1 ? 1 : 0;
      const swing = p === 1 ? 1 : p === 3 ? -1 : 0;
      set.walk[d].push(makeFrame((c) => f(c, p, bob, swing)));
    }
  });
  return set;
}

function loadImg(url: string): Promise<HTMLImageElement | null> {
  return new Promise((res) => {
    const im = new Image();
    im.onload = () => res(im);
    im.onerror = () => res(null);
    im.src = url;
  });
}

/**
 * Optional: place your own sprite frames in /public/sprites/ to replace the procedural character:
 *  back_idle.png, back_walk1..6.png, front_idle.png, front_walk1..6.png, side_idle.png, side_walk1..6.png
 */
export async function loadCustomSprites(set: SpriteSet) {
  const base = (import.meta as any).env?.BASE_URL ?? "/";
  const dirs: Dir[] = ["back", "front", "side"];
  for (const d of dirs) {
    const idle = await loadImg(`${base}sprites/${d}_idle.png`);
    if (!idle) continue;
    const fr = (im: HTMLImageElement): Frame => ({ tex: tex(im), aspect: im.width / im.height });
    set.idle[d] = [fr(idle)];
    const walk: Frame[] = [];
    for (let i = 1; i <= 6; i++) {
      const im = await loadImg(`${base}sprites/${d}_walk${i}.png`);
      if (im) walk.push(fr(im));
    }
    if (walk.length) set.walk[d] = walk;
    else set.walk[d] = [fr(idle)];
  }
}
