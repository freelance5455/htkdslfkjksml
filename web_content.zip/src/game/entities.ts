// ═══════════════════════════════════════════════════════════════
// DARK GHOUL V2 — الكيانات: اللاعب، القتال، الباركور، الأعداء، المهمات
// ═══════════════════════════════════════════════════════════════
import * as THREE from "three";
import { CharacterDef, EnemyType, Line, MISSIONS, MissionDef } from "./data";
import { AudioEngine, clamp, damp, angDamp } from "./systems";
import {
  Rig, RigState, buildHumanoid, buildKagune, buildCivilian, animateRig,
  updateKagune, setKaguneEyes, makeGlowTexture, KaguneRig,
} from "./characters";
import { Col, WorldHandles } from "./world";

// ─────────────── سياق مشترك ───────────────
export interface Stats {
  power: number; range: number; dodgeIF: number; leech: number;
  rcMax: number; ult: boolean; speedMul: number; defMul: number;
}
export interface Ctx {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  world: WorldHandles;
  audio: AudioEngine;
  particles: ParticleSystem;
  stats: Stats;
  flags: Set<string>;
  addShake(m: number): void;
  notify(msg: string, kind?: "info" | "warn" | "good"): void;
  dialogue(lines: Line[], after?: (choice?: string) => void): void;
  onKill(tag: string): void;
  onCollect(kind: string): void;
  onPlayerHit(): void;
  onDeath(): void;
  player: Player;
  enemies: Enemy[];
  projectiles: Projectile[];
  pickups: Pickup[];
  time: number;
}

export interface InputFrame {
  mx: number; mz: number; sprint: boolean;
  jump: boolean; attack: boolean; heavy: boolean; dodge: boolean;
  skill: boolean; transform: boolean; block: boolean; interact: boolean; lock: boolean;
}

// ─────────────── فيزياء ───────────────
export function collideMove(pos: THREE.Vector3, r: number, feetY: number, colliders: Col[]): { col: Col | null; nx: number; nz: number } {
  let hitCol: Col | null = null, nx = 0, nz = 0, best = 1e9;
  for (const c of colliders) {
    if (c.h <= feetY + 0.32) continue;
    const dx = pos.x - c.x, dz = pos.z - c.z;
    const px = c.hx + r - Math.abs(dx), pz = c.hz + r - Math.abs(dz);
    if (px > 0 && pz > 0) {
      if (px < pz) {
        const s = dx > 0 ? 1 : -1;
        pos.x += px * s;
        if (px < best) { best = px; hitCol = c; nx = s; nz = 0; }
      } else {
        const s = dz > 0 ? 1 : -1;
        pos.z += pz * s;
        if (pz < best) { best = pz; hitCol = c; nx = 0; nz = s; }
      }
    }
  }
  return { col: hitCol, nx, nz };
}
export function supportHeight(x: number, z: number, feetY: number, colliders: Col[]): number {
  let h = 0;
  for (const c of colliders) {
    if (Math.abs(x - c.x) <= c.hx && Math.abs(z - c.z) <= c.hz && c.h <= feetY + 0.45 && c.h > h) h = c.h;
  }
  return h;
}
export function insideBuilding(x: number, y: number, z: number, colliders: Col[]): boolean {
  for (const c of colliders) {
    if (Math.abs(x - c.x) < c.hx && Math.abs(z - c.z) < c.hz && y < c.h) return true;
  }
  return false;
}

// ─────────────── جسيمات ───────────────
interface Burst { pts: THREE.Points; vel: Float32Array; life: number; maxLife: number; grav: number }
export class ParticleSystem {
  scene: THREE.Scene;
  list: Burst[] = [];
  tex: THREE.CanvasTexture;
  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.tex = makeGlowTexture("#ffffff", 64);
  }
  burst(pos: THREE.Vector3, color: number, n: number, speed: number, life: number, size: number, grav = -5, flat = false) {
    if (this.list.length > 14) return;
    const P = new Float32Array(n * 3), V = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      P.set([pos.x, pos.y, pos.z], i * 3);
      const a = Math.random() * Math.PI * 2;
      const b = flat ? 0.15 : (Math.random() - 0.5) * 2;
      const sp = speed * (0.4 + Math.random() * 0.8);
      V.set([Math.cos(a) * sp * (flat ? 1 : 0.8), Math.abs(b) * sp * (flat ? 0.4 : 1) + (flat ? 1 : speed * 0.25), Math.sin(a) * sp * (flat ? 1 : 0.8)], i * 3);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(P, 3));
    const m = new THREE.PointsMaterial({
      color, size, map: this.tex, transparent: true, opacity: 0.95,
      blending: THREE.AdditiveBlending, depthWrite: false,
    });
    const pts = new THREE.Points(g, m);
    pts.frustumCulled = false;
    this.scene.add(pts);
    this.list.push({ pts, vel: V, life, maxLife: life, grav });
  }
  update(dt: number) {
    for (let i = this.list.length - 1; i >= 0; i--) {
      const b = this.list[i];
      b.life -= dt;
      if (b.life <= 0) {
        this.scene.remove(b.pts);
        b.pts.geometry.dispose();
        (b.pts.material as THREE.Material).dispose();
        this.list.splice(i, 1);
        continue;
      }
      const arr = (b.pts.geometry.getAttribute("position") as THREE.BufferAttribute).array as Float32Array;
      for (let j = 0; j < arr.length; j += 3) {
        b.vel[j + 1] += b.grav * dt;
        arr[j] += b.vel[j] * dt; arr[j + 1] += b.vel[j + 1] * dt; arr[j + 2] += b.vel[j + 2] * dt;
        if (arr[j + 1] < 0.05) { arr[j + 1] = 0.05; b.vel[j + 1] *= -0.3; }
      }
      (b.pts.geometry.getAttribute("position") as THREE.BufferAttribute).needsUpdate = true;
      (b.pts.material as THREE.PointsMaterial).opacity = 0.95 * (b.life / b.maxLife);
    }
  }
}

// ─────────────── مقذوفات وملتقطات ───────────────
export interface Projectile {
  mesh: THREE.Mesh; vel: THREE.Vector3; life: number; dmg: number; friendly: boolean;
}
export function fireProjectile(ctx: Ctx, from: THREE.Vector3, dir: THREE.Vector3, speed: number, dmg: number, friendly: boolean, color = 0xff2038) {
  const mesh = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.85, 5),
    new THREE.MeshStandardMaterial({ color: 0x1a0408, emissive: color, emissiveIntensity: 3 }));
  mesh.position.copy(from);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
  ctx.scene.add(mesh);
  ctx.projectiles.push({ mesh, vel: dir.clone().normalize().multiplyScalar(speed), life: 2.4, dmg, friendly });
}

export interface Pickup { mesh: THREE.Object3D; kind: "crystal" | "cell"; t: number; baseY: number }
export function spawnPickup(ctx: Ctx, pos: THREE.Vector3, kind: "crystal" | "cell") {
  const crystal = kind === "crystal";
  const m = new THREE.Mesh(new THREE.OctahedronGeometry(crystal ? 0.34 : 0.22),
    new THREE.MeshStandardMaterial({ color: 0x20060c, emissive: crystal ? 0xff2d55 : 0xff8844, emissiveIntensity: 2.6, roughness: 0.2, metalness: 0.5 }));
  m.position.copy(pos);
  const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: makeGlowTexture(crystal ? "#ff2d55" : "#ff8844"), transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false }));
  glow.scale.setScalar(crystal ? 2.2 : 1.4);
  m.add(glow);
  ctx.scene.add(m);
  ctx.pickups.push({ mesh: m, kind, t: Math.random() * 6, baseY: pos.y });
}

// ─────────────── اللاعب ───────────────
export class Player {
  rig: Rig; kagune: KaguneRig; def: CharacterDef;
  vel = new THREE.Vector3();
  yaw = Math.PI; camYaw = 0; camPitch = 0.32; camDist = 6.5;
  grounded = true; groundY = 0;
  climbing = { on: false, col: null as Col | null, nx: 0, nz: 0 };
  hp: number; hpMax: number; rc = 55; stamina = 100;
  kaguneOn = false; transformT = -1; transforming = false;
  attack: { kind: string; t: number; dur: number; hitDone: boolean } | null = null;
  comboStep = 0; comboTimer = 0; comboCount = 0; comboShowT = 0;
  dodgeT = 0; dodgeDir = new THREE.Vector3(); invulnT = 0; blockHold = false;
  lockTarget: Enemy | null = null;
  skillCd = 0; dead = false; deadT = 0; flinchT = 0;
  interactPrompt: string | null = null; interactAction: (() => void) | null = null;
  stepT = 0;
  constructor(def: CharacterDef, scene: THREE.Scene, pos: THREE.Vector3, hpMax: number) {
    this.def = def;
    this.rig = buildHumanoid(def);
    this.rig.root.position.copy(pos);
    scene.add(this.rig.root);
    this.kagune = buildKagune(def.kaguneType, this.rig, 1);
    this.hpMax = hpMax; this.hp = hpMax;
    setKaguneEyes(this.rig, false);
  }
  get pos() { return this.rig.root.position; }

  applySkills(owned: Set<string>) {
    const p = this.def.id === "daisuke" ? "dai" : this.def.id === "hollow" ? "hol" : this.def.id;
    this.kagune = this.kagune; // no-op keep
    void p; void owned;
  }

  startAttack(kind: string, dur: number) {
    this.attack = { kind, t: 0, dur, hitDone: false };
  }

  dealArcDamage(ctx: Ctx, range: number, dmg: number, arcDeg: number, knock: number, heavy = false) {
    let hits = 0;
    const fwd = new THREE.Vector3(Math.sin(this.rig.root.rotation.y), 0, Math.cos(this.rig.root.rotation.y));
    for (const e of ctx.enemies) {
      if (e.dead) continue;
      if (Math.abs(e.pos.y - this.pos.y) > 2.6) continue;
      const to = e.pos.clone().sub(this.pos); to.y = 0;
      const d = to.length();
      if (d > range + e.spec.scale * 0.6) continue;
      to.normalize();
      if (fwd.dot(to) < Math.cos((arcDeg / 2) * Math.PI / 180) && d > 1.4) continue;
      e.takeHit(ctx, dmg, to, knock, heavy);
      hits++;
    }
    return hits;
  }

  useSkill(ctx: Ctx) {
    if (this.skillCd > 0 || !this.kaguneOn) return;
    const st = ctx.stats;
    const mult = st.ult ? 2 : 1, rad = st.ult ? 1.5 : 1;
    this.skillCd = 6;
    this.startAttack("skill", 0.6);
    this.kagune.strikeT = 0;
    const type = this.def.kaguneType;
    const fwd = new THREE.Vector3(Math.sin(this.rig.root.rotation.y), 0, Math.cos(this.rig.root.rotation.y));
    const from = this.pos.clone().add(new THREE.Vector3(0, 1.4, 0)).add(fwd.clone().multiplyScalar(0.6));
    if (type === "blade" || type === "hybrid") {
      ctx.audio.whoosh();
      const n = type === "hybrid" ? 7 : 6;
      for (let i = 0; i < n; i++) {
        const a = ((i - (n - 1) / 2) * 0.16);
        const dir = fwd.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), a);
        dir.y = 0.06;
        fireProjectile(ctx, from, dir, 26, 15 * st.power * mult, true);
      }
      ctx.particles.burst(from, 0xff2038, 16, 5, 0.4, 0.25);
    } else if (type === "wing") {
      ctx.audio.slash(); ctx.addShake(0.4);
      const hits = this.dealArcDamage(ctx, 5.5 * rad, 24 * st.power * mult, 360, 7, true);
      ctx.particles.burst(this.pos.clone().add(new THREE.Vector3(0, 1, 0)), 0xd21f3c, 40, 9, 0.6, 0.3, -2, true);
      if (hits) ctx.audio.hit(1.3);
    } else if (type === "tail") {
      ctx.audio.whoosh();
      this.pos.add(fwd.clone().multiplyScalar(6.5));
      const hit = this.dealArcDamage(ctx, 3.4 * rad, 22 * st.power * mult, 360, 5);
      ctx.particles.burst(this.pos.clone().add(new THREE.Vector3(0, 1, 0)), 0xff2038, 30, 8, 0.5, 0.26, -2, true);
      if (hit) ctx.audio.hit(1.2);
    } else if (type === "armor") {
      ctx.audio.boom(); ctx.addShake(0.5);
      const hits = this.dealArcDamage(ctx, 3.6 * rad, 30 * st.power * mult, 120, 10, true);
      ctx.particles.burst(from, 0xff5a1f, 26, 7, 0.5, 0.3);
      if (hits) ctx.audio.hit(1.4);
    } else {
      // monster
      ctx.audio.roar(); ctx.addShake(0.8);
      const hits = this.dealArcDamage(ctx, 8 * rad, 20 * st.power * mult, 360, 8, true);
      ctx.particles.burst(this.pos.clone().add(new THREE.Vector3(0, 1.2, 0)), 0xd21f3c, 70, 13, 0.8, 0.4, -3, true);
      if (hits) ctx.audio.hit(1.6);
    }
    if (st.ult) ctx.notify(st.ult ? "الانفجار الأحمر!" : "", "good");
  }

  takeDamage(ctx: Ctx, dmg: number, fromPos: THREE.Vector3 | null) {
    if (this.dead || this.invulnT > 0 || this.transforming) return;
    let d = dmg / (1 + ctx.stats.defMul * 0.07);
    if (this.blockHold && this.stamina > 5) {
      d *= 0.25; this.stamina = Math.max(0, this.stamina - dmg * 1.1);
      ctx.audio.hit(0.5);
    } else {
      this.flinchT = 0.35;
      ctx.audio.hit(1);
    }
    if (this.kaguneOn) d *= 0.9;
    this.hp -= d;
    this.rc = Math.min(ctx.stats.rcMax, this.rc + d * 0.7);
    ctx.onPlayerHit();
    ctx.addShake(0.25);
    if (fromPos) {
      const away = this.pos.clone().sub(fromPos); away.y = 0; away.normalize();
      this.vel.add(away.multiplyScalar(3.5));
    }
    if (this.hp <= 0) {
      this.hp = 0; this.dead = true; this.deadT = 0;
      ctx.onDeath();
    }
  }

  respawn(ctx: Ctx) {
    const cafe = ctx.world.anchors["cafe"][0];
    this.pos.set(cafe.x, 0, cafe.z);
    this.hp = this.hpMax; this.rc = 50; this.dead = false; this.deadT = 0;
    this.kaguneOn = false; this.transforming = false; this.transformT = -1;
    this.kagune.emerge = 0;
    setKaguneEyes(this.rig, false);
    this.vel.set(0, 0, 0);
    this.rig.root.rotation.set(0, Math.PI, 0);
  }

  update(dt: number, inp: InputFrame, ctx: Ctx) {
    const st = ctx.stats;
    if (this.dead) {
      this.deadT += dt;
      animateRig(this.rig, this.rigState(0), dt, ctx.time);
      return;
    }
    // سينمائية التحول
    if (this.transforming) {
      this.transformT += dt / 1.9;
      this.kagune.emerge = clamp(this.transformT, 0, 1);
      this.kagune.blackM.emissiveIntensity = 0.5 + this.transformT * 1.6;
      if (this.transformT >= 1) {
        this.transforming = false;
        this.kaguneOn = true;
        ctx.notify("هيئة الكاغوني مكتملة — القوة تحررت", "good");
      }
      animateRig(this.rig, this.rigState(0), dt, ctx.time);
      updateKagune(this.kagune, dt, ctx.time, false);
      return;
    }
    this.invulnT -= dt; this.skillCd -= dt; this.flinchT = Math.max(0, this.flinchT - dt * 2);
    this.comboTimer -= dt; if (this.comboTimer <= 0) this.comboStep = 0;
    this.comboShowT -= dt;
    const moving = Math.hypot(inp.mx, inp.mz) > 0.12;

    // ── اتجاه الحركة نسبةً للكاميرا ──
    const cy = this.camYaw;
    const F = new THREE.Vector3(-Math.sin(cy), 0, -Math.cos(cy));
    const R = new THREE.Vector3(Math.cos(cy), 0, -Math.sin(cy));
    const wish = F.multiplyScalar(inp.mz).add(R.multiplyScalar(inp.mx));
    const wishLen = Math.min(1, wish.length());
    if (wishLen > 0.001) wish.normalize();
    const sprint = inp.sprint || wishLen > 0.82;

    // ── التحول ──
    if (inp.transform && !this.kaguneOn && !this.transforming && this.rc < 30) {
      ctx.notify("مقياس RC غير كافٍ — تحتاج 30 على الأقل (يُشحن بالقتال)", "warn");
    }
    if (inp.transform && !this.kaguneOn && this.rc >= 30 && !this.climbing.on) {
      this.transforming = true; this.transformT = 0;
      setKaguneEyes(this.rig, true);
      ctx.audio.transform();
      ctx.addShake(0.6);
      ctx.particles.burst(this.pos.clone().add(new THREE.Vector3(0, 1, 0)), 0xd21f3c, 60, 10, 1, 0.35, 2);
      ctx.particles.burst(this.pos.clone().add(new THREE.Vector3(0, 0.4, 0)), 0x30060f, 40, 6, 1.2, 0.5, 4);
    }
    if (this.kaguneOn) {
      const drain = 5.2 / (st.rcMax / 100);
      this.rc -= drain * dt;
      if (this.rc <= 0 || (inp.transform && this.rc < ctx.stats.rcMax - 5)) {
        this.kaguneOn = false;
        setKaguneEyes(this.rig, false);
        ctx.notify("تبدد الكاغوني — استعد طاقة RC", "warn");
      }
    } else if (this.kagune.emerge > 0) {
      this.kagune.emerge = Math.max(0, this.kagune.emerge - dt * 1.4);
    }

    // ── المراوغة ──
    if (inp.dodge && this.dodgeT <= -0.25 && this.stamina > 16 && !this.climbing.on) {
      this.dodgeT = 0.3;
      this.invulnT = st.dodgeIF;
      this.stamina -= 16;
      this.dodgeDir.copy(moving ? wish : F.clone().negate());
      ctx.audio.whoosh();
      ctx.particles.burst(this.pos.clone().add(new THREE.Vector3(0, 0.3, 0)), 0x666c78, 10, 3, 0.35, 0.2, -1, true);
    }
    if (this.dodgeT > -0.3) this.dodgeT -= dt;

    // ── الهجوم ──
    if (this.attack) {
      this.attack.t += dt / this.attack.dur;
      if (!this.attack.hitDone && this.attack.t >= 0.42) {
        this.attack.hitDone = true;
        const kind = this.attack.kind;
        if (kind.startsWith("l")) {
          const dmg = (kind === "l2" ? 15 : 9) * st.power * (this.kaguneOn ? 1.55 : 1);
          const hits = this.dealArcDamage(ctx, this.kaguneOn ? 4.6 * st.range : 2.4, dmg, 100, kind === "l2" ? 5 : 2.5);
          if (hits) { ctx.audio.hit(1); ctx.addShake(0.16); this.comboCount++; this.comboShowT = 2.2; this.rc = Math.min(st.rcMax, this.rc + 3 * hits); this.leech(ctx, dmg * hits); }
          else ctx.audio.slash();
          if (this.kaguneOn) this.kagune.strikeT = 0;
        } else if (kind === "heavy") {
          const dmg = 26 * st.power * (this.kaguneOn ? 1.7 : 1);
          const hits = this.dealArcDamage(ctx, this.kaguneOn ? 5.4 * st.range : 3, dmg, 130, 7, true);
          ctx.addShake(0.45);
          if (hits) { ctx.audio.hit(1.5); this.comboCount += 2; this.comboShowT = 2.5; this.rc = Math.min(st.rcMax, this.rc + 5 * hits); this.leech(ctx, dmg * hits); }
          else { ctx.audio.slash(); ctx.audio.boom(); }
          if (this.kaguneOn) this.kagune.strikeT = 0;
        }
      }
      if (this.attack.t >= 1) this.attack = null;
    } else {
      if (inp.attack && !this.climbing.on) {
        const kind = this.kaguneOn ? "kagune" : ["l0", "l1", "l2"][this.comboStep % 3];
        this.comboStep++;
        this.comboTimer = 1;
        this.startAttack(this.kaguneOn ? "kagune" : kind, this.kaguneOn ? 0.5 : 0.42);
        if (this.kaguneOn) { this.kagune.strikeT = 0; ctx.audio.slash(); }
      } else if (inp.heavy && !this.climbing.on) {
        this.startAttack("heavy", 0.78);
        ctx.audio.whoosh();
      } else if (inp.skill) {
        if (!this.kaguneOn && this.skillCd <= 0) ctx.notify("مهارة الكاغوني تتطلب التحول أولاً", "warn");
        this.useSkill(ctx);
      }
    }

    // ── قفل الهدف ──
    if (inp.lock) {
      let best: Enemy | null = null, bd = 17;
      for (const e of ctx.enemies) {
        if (e.dead) continue;
        const d = e.pos.distanceTo(this.pos);
        if (d < bd) { bd = d; best = e; }
      }
      this.lockTarget = best;
      if (best) ctx.notify("تم قفل الهدف", "info");
    }
    if (this.lockTarget && this.lockTarget.dead) this.lockTarget = null;
    if (this.lockTarget) {
      const dx = this.lockTarget.pos.x - this.pos.x, dz = this.lockTarget.pos.z - this.pos.z;
      this.camYaw = angDamp(this.camYaw, Math.atan2(dx, dz), 5, dt);
    }

    // ── الحركة الأفقية ──
    const spdBase = this.kaguneOn ? 10.2 : sprint ? 8.4 : 4.7;
    const spd = spdBase * st.speedMul * (this.attack && this.grounded ? 0.25 : 1) * (this.blockHold ? 0.4 : 1);
    let tvx = wish.x * wishLen * spd, tvz = wish.z * wishLen * spd;
    if (this.dodgeT > 0) { tvx = this.dodgeDir.x * 15; tvz = this.dodgeDir.z * 15; }
    const l = this.dodgeT > 0 ? 2 : 11;
    this.vel.x = damp(this.vel.x, tvx, l, dt);
    this.vel.z = damp(this.vel.z, tvz, l, dt);

    // مواجهة النموذج
    if (moving && !this.attack) {
      const target = this.lockTarget
        ? Math.atan2(this.lockTarget.pos.x - this.pos.x, this.lockTarget.pos.z - this.pos.z)
        : Math.atan2(wish.x, wish.z);
      this.rig.root.rotation.y = angDamp(this.rig.root.rotation.y, target, 12, dt);
    }

    // ── الجاذبية والقفز ──
    const wasGrounded = this.grounded;
    let fallSpeed = 0;
    if (!this.climbing.on) {
      this.vel.y -= 23 * dt;
      if (inp.jump && this.grounded && this.stamina > 8) {
        this.vel.y = 8.6 * (this.kaguneOn ? 1.12 : 1);
        this.stamina -= 9;
        this.grounded = false;
        ctx.audio.step(false);
      }
    }

    // تكامل الموضع
    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;
    const BOUND = 232;
    this.pos.x = clamp(this.pos.x, -BOUND, BOUND);
    this.pos.z = clamp(this.pos.z, -BOUND, BOUND);

    // التصادم الأفقي
    const hit = collideMove(this.pos, 0.55, this.pos.y, ctx.world.colliders);

    // ── التسلق والباركور ──
    const pushingWall = hit.col && moving && (-(hit.nx * wish.x + hit.nz * wish.z) > 0.35);
    if (!this.climbing.on && pushingWall && hit.col && hit.col.h > this.pos.y + 1.6 && this.stamina > 6 && (!this.grounded || inp.jump || inp.mz > 0.6)) {
      this.climbing = { on: true, col: hit.col, nx: hit.nx, nz: hit.nz };
      this.vel.y = 0;
    }
    if (this.climbing.on) {
      const c = this.climbing.col!;
      this.stamina -= 11 * dt;
      // التصاق بالجدار: أعد التصادم بنصف قطر أكبر
      collideMove(this.pos, 0.62, this.pos.y - 0.2, ctx.world.colliders);
      const up = inp.mz, side = inp.mx;
      this.vel.y = up * 3.6 + (this.kaguneOn ? 0.8 : 0);
      // حركة جانبية على طول الجدار
      const tx = -this.climbing.nz, tz = this.climbing.nx;
      this.pos.x += tx * side * 2.8 * dt;
      this.pos.z += tz * side * 2.8 * dt;
      this.pos.y += this.vel.y * dt;
      // واجه الجدار
      this.rig.root.rotation.y = angDamp(this.rig.root.rotation.y, Math.atan2(-this.climbing.nx, -this.climbing.nz), 10, dt);
      // اعتلاء السطح
      if (this.pos.y + 0.25 > c.h) {
        this.pos.y = c.h; this.climbing.on = false; this.grounded = true; this.groundY = c.h;
        ctx.notify("وصلت إلى السطح", "info");
      }
      // قفزة من الجدار
      if (inp.jump) {
        this.climbing.on = false;
        this.vel.y = 7.6;
        this.vel.x = this.climbing.nx * 6.5;
        this.vel.z = this.climbing.nz * 6.5;
      }
      if (this.stamina <= 0 || (!moving && this.vel.y <= 0.01 && up >= -0.1 && Math.abs(up) < 0.1 && this.stamina < 30)) {
        // لا شيء — البقاء متاح طالما هناك قدرة
      }
      if (this.stamina <= 0) this.climbing.on = false;
      if (this.pos.y < 0) this.climbing.on = false;
    } else {
      this.pos.y += this.vel.y * dt;
      // دعم الأرضية (الأرض + الأسطح)
      const sup = supportHeight(this.pos.x, this.pos.z, this.pos.y, ctx.world.colliders);
      if (this.pos.y <= sup + 0.001 && this.vel.y <= 0) {
        fallSpeed = -this.vel.y;
        this.pos.y = sup; this.vel.y = 0; this.grounded = true; this.groundY = sup;
      } else if (this.pos.y > sup + 0.05) {
        this.grounded = false;
      }
      if (wasGrounded && !this.grounded) { /* بدأ السقوط */ }
    }
    // ضرر السقوط
    if (this.grounded && fallSpeed > 17 && !this.kaguneOn) {
      this.takeDamage(ctx, (fallSpeed - 16) * 2.2, null);
      ctx.addShake(0.5);
    }

    // ── الطاقة ──
    const regen = this.climbing.on ? 0 : sprint && moving ? -6 : 14;
    this.stamina = clamp(this.stamina + regen * dt, 0, 100);
    if (!this.kaguneOn) this.rc = Math.min(st.rcMax, this.rc + 0.9 * dt);

    // خطوات
    if (this.grounded && moving) {
      this.stepT += dt * (sprint ? 2.4 : 1.6);
      if (this.stepT > 1) { this.stepT = 0; ctx.audio.step(Math.random() < 0.5); }
    }

    // ── التحريك ──
    const mv = moving ? clamp(wishLen * (sprint ? 1 : 0.62), 0, 1) : 0;
    this.kagune.active = this.kaguneOn;
    animateRig(this.rig, this.rigState(mv, sprint), dt, ctx.time);
    updateKagune(this.kagune, dt, ctx.time, moving);
    this.kagune.blackM.emissiveIntensity = damp(this.kagune.blackM.emissiveIntensity, this.kaguneOn ? 1.2 : 0.5, 4, dt);
  }

  leech(ctx: Ctx, dealt: number) {
    if (ctx.stats.leech > 0) this.hp = Math.min(this.hpMax, this.hp + dealt * ctx.stats.leech);
  }

  rigState(mv: number, run = false): RigState {
    return {
      mv, run, grounded: this.grounded, vy: this.vel.y,
      climbing: this.climbing.on,
      attack: this.attack ? { kind: this.attack.kind, p: this.attack.t } : null,
      block: this.blockHold && this.grounded,
      kagune: this.kaguneOn,
      dead: this.dead ? this.deadT : 0,
      flinch: this.flinchT,
    };
  }
}

// ─────────────── الأعداء ───────────────
export interface EnemySpec {
  type: EnemyType; hp: number; dmg: number; spd: number; aggro: number;
  range: number; ranged: boolean; xp: number; scale: number; boss: boolean;
  jacket: number; pants: number; skin: number; hair: number;
  kagune?: string;
}
const SPECS: Record<string, EnemySpec> = {
  thug: { type: "thug", hp: 42, dmg: 8, spd: 3.4, aggro: 15, range: 2.2, ranged: false, xp: 14, scale: 1, boss: false, jacket: 0x2c2620, pants: 0x1c1a18, skin: 0xc9a184, hair: 0x171412 },
  runner: { type: "runner", hp: 30, dmg: 6, spd: 6.6, aggro: 18, range: 2, ranged: false, xp: 16, scale: 0.95, boss: false, jacket: 0x30161c, pants: 0x141014, skin: 0xd9b39a, hair: 0x24181c },
  armored: { type: "armored", hp: 95, dmg: 13, spd: 2.3, aggro: 14, range: 2.5, ranged: false, xp: 28, scale: 1.12, boss: false, jacket: 0x33383f, pants: 0x24272c, skin: 0xc9a184, hair: 0x2a2c30 },
  ghoul: { type: "ghoul", hp: 75, dmg: 11, spd: 4.2, aggro: 19, range: 2.6, ranged: true, xp: 32, scale: 1, boss: false, jacket: 0x1d1016, pants: 0x120c10, skin: 0xd4b096, hair: 0x1a0e12, kagune: "tail" },
  hunter: { type: "hunter", hp: 62, dmg: 14, spd: 3.6, aggro: 22, range: 15, ranged: true, xp: 30, scale: 1, boss: false, jacket: 0x20262f, pants: 0x181d24, skin: 0xd9b39a, hair: 0x23262c },
  boss_genji: { type: "boss_genji", hp: 460, dmg: 16, spd: 3.9, aggro: 40, range: 3.4, ranged: true, xp: 170, scale: 1.14, boss: true, jacket: 0x242c3a, pants: 0x1a202a, skin: 0xc9a184, hair: 0x3a3e46 },
  boss_mura: { type: "boss_mura", hp: 720, dmg: 19, spd: 4.6, aggro: 50, range: 4.2, ranged: true, xp: 260, scale: 1.1, boss: true, jacket: 0xd9d4cc, pants: 0x2a2a30, skin: 0xe6ddd6, hair: 0xd8d8de, kagune: "monster" },
  informant: { type: "informant", hp: 20, dmg: 0, spd: 5.4, aggro: 0, range: 0, ranged: false, xp: 0, scale: 0.95, boss: false, jacket: 0x3a3f2e, pants: 0x26291f, skin: 0xd9b39a, hair: 0x2c2418 },
};

export class Enemy {
  rig: Rig; spec: EnemySpec; kagune: KaguneRig | null = null;
  hp: number; maxHp: number;
  state: "idle" | "chase" | "windup" | "strike" | "recover" | "stagger" | "dead" = "idle";
  t = 0; cd = 1 + Math.random() * 2; windupDur = 0.55;
  deadT = 0; tag = ""; phase = 1; specialCd = 6;
  bar: THREE.Group; barFg: THREE.Mesh;
  vel = new THREE.Vector3();
  flashRing: THREE.Mesh | null = null;
  constructor(spec: EnemySpec, x: number, z: number, scene: THREE.Scene) {
    this.spec = spec;
    this.rig = buildHumanoid(null, { jacket: spec.jacket, pants: spec.pants, skin: spec.skin, hair: spec.hair });
    this.rig.root.position.set(x, 0, z);
    this.rig.root.scale.setScalar(spec.scale * (this.rig.def ? this.rig.def.scale : 1) || spec.scale);
    scene.add(this.rig.root);
    if (spec.kagune) {
      this.kagune = buildKagune(spec.kagune, this.rig, spec.kagune === "monster" ? 1 : 0.75);
      this.kagune.emerge = spec.type === "boss_mura" ? 1 : 0;
      this.kagune.active = spec.type === "boss_mura";
      if (spec.type === "boss_mura") setKaguneEyes(this.rig, true);
    }
    this.hp = spec.hp; this.maxHp = spec.hp;
    // شريط الصحة
    this.bar = new THREE.Group();
    const bg = new THREE.Mesh(new THREE.PlaneGeometry(spec.boss ? 1.6 : 0.95, 0.1),
      new THREE.MeshBasicMaterial({ color: 0x0a0c10, transparent: true, opacity: 0.85, depthTest: false }));
    this.barFg = new THREE.Mesh(new THREE.PlaneGeometry(spec.boss ? 1.56 : 0.9, 0.06),
      new THREE.MeshBasicMaterial({ color: spec.boss ? 0xff2d55 : 0xc23b52, depthTest: false }));
    bg.renderOrder = 10; this.barFg.renderOrder = 11;
    this.bar.add(bg); this.bar.add(this.barFg);
    this.bar.position.y = 2.15 * spec.scale;
    this.rig.root.add(this.bar);
    if (spec.boss) this.bar.visible = false; // الزعماء لهم شريط في الواجهة
  }
  get pos() { return this.rig.root.position; }
  get dead() { return this.state === "dead"; }

  takeHit(ctx: Ctx, dmg: number, dir: THREE.Vector3, knock: number, heavy = false) {
    if (this.dead) return;
    const red = this.spec.type === "armored" ? 0.5 : 1;
    this.hp -= dmg * red;
    this.rig.flashT = 0.22;
    this.state = "stagger";
    this.t = heavy ? 0.55 : 0.3;
    this.vel.add(dir.clone().multiplyScalar(knock * (this.spec.boss ? 0.15 : 1)));
    ctx.particles.burst(this.pos.clone().add(new THREE.Vector3(0, 1.3, 0)), 0xd21f3c, heavy ? 16 : 8, 5, 0.4, 0.22);
    if (this.hp <= 0) this.die(ctx);
  }

  die(ctx: Ctx) {
    this.state = "dead"; this.deadT = 0;
    ctx.audio.boom();
    ctx.particles.burst(this.pos.clone().add(new THREE.Vector3(0, 1, 0)), 0xff2038, this.spec.boss ? 90 : 34, this.spec.boss ? 12 : 7, 0.9, 0.32, -3);
    spawnPickup(ctx, this.pos.clone().add(new THREE.Vector3(0, 0.8, 0)), "cell");
    if (this.spec.boss) {
      spawnPickup(ctx, this.pos.clone().add(new THREE.Vector3(1, 0.8, 0)), "crystal");
      ctx.addShake(1);
    }
    ctx.onKill(this.tag || this.spec.type);
  }

  update(dt: number, ctx: Ctx) {
    const p = ctx.player;
    if (this.state === "dead") {
      this.deadT += dt;
      this.rig.root.rotation.x = damp(this.rig.root.rotation.x, -Math.PI / 2, 5, dt);
      this.rig.root.position.y = -this.deadT * 0.4;
      this.rig.allMats.forEach((m) => { m.transparent = true; m.opacity = Math.max(0, 1 - this.deadT); });
      return this.deadT > 1.4;
    }
    const dx = p.pos.x - this.pos.x, dz = p.pos.z - this.pos.z;
    const dist = Math.hypot(dx, dz);
    this.cd -= dt; this.specialCd -= dt;

    // مراحل الزعماء
    if (this.spec.boss) {
      const frac = this.hp / this.maxHp;
      if (this.phase === 1 && frac < 0.62) {
        this.phase = 2;
        this.spec = { ...this.spec, spd: this.spec.spd * 1.35 };
        ctx.notify(this.spec.type === "boss_genji" ? "جينجي: «الكوينكي — الإطلاق الثاني!»" : "موراساكي: «دعني أريك الوحش الحقيقي!»", "warn");
        ctx.audio.roar();
        if (this.kagune && this.kagune.emerge < 1) { this.kagune.emerge = 1; setKaguneEyes(this.rig, true); }
        ctx.addShake(0.7);
      } else if (this.phase === 2 && frac < 0.3) {
        this.phase = 3;
        this.spec = { ...this.spec, dmg: this.spec.dmg * 1.35, spd: this.spec.spd * 1.25 };
        ctx.notify("المرحلة الأخيرة — أطلق العنان!", "warn");
        ctx.audio.roar(); ctx.addShake(0.9);
        ctx.particles.burst(this.pos.clone().add(new THREE.Vector3(0, 1.2, 0)), 0xd21f3c, 60, 11, 1, 0.4, 2);
      }
      // هجمات خاصة
      if (this.specialCd <= 0 && dist < 14 && this.state === "chase") {
        this.specialCd = this.phase >= 2 ? 5 : 8;
        if (this.spec.type === "boss_genji") {
          // موجة صدمية
          ctx.audio.boom();
          ctx.addShake(0.6);
          const ring = new THREE.Mesh(new THREE.TorusGeometry(0.8, 0.12, 6, 32),
            new THREE.MeshBasicMaterial({ color: 0x5f8fd9, transparent: true, opacity: 0.9 }));
          ring.rotation.x = Math.PI / 2;
          ring.position.copy(this.pos).add(new THREE.Vector3(0, 0.3, 0));
          ctx.scene.add(ring);
          let rt = 0, hitDone = false;
          const anim = () => {
            rt += 0.016;
            ring.scale.setScalar(1 + rt * 14);
            (ring.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.9 - rt * 1.4);
            if (!hitDone && rt > 0.32 && !p.dead && p.grounded && Math.hypot(p.pos.x - this.pos.x, p.pos.z - this.pos.z) < 6.4) {
              hitDone = true; p.takeDamage(ctx, this.spec.dmg * 1.2, this.pos);
            }
            if (rt < 0.7) requestAnimationFrame(anim);
            else { ctx.scene.remove(ring); ring.geometry.dispose(); }
          };
          anim();
        } else {
          // عاصفة شظايا
          ctx.audio.whoosh();
          const n = this.phase >= 3 ? 14 : 10;
          for (let i = 0; i < n; i++) {
            const a = (i / n) * Math.PI * 2;
            fireProjectile(ctx, this.pos.clone().add(new THREE.Vector3(0, 1.5, 0)),
              new THREE.Vector3(Math.cos(a), 0.08, Math.sin(a)), 14, this.spec.dmg * 0.7, false);
          }
        }
      }
    }

    switch (this.state) {
      case "idle":
        if (dist < this.spec.aggro && !p.dead && this.spec.type !== "informant") {
          this.state = "chase";
          if (this.kagune && this.spec.type !== "boss_mura") { this.kagune.emerge = 1; setKaguneEyes(this.rig, true); }
        }
        break;
      case "chase": {
        const toP = new THREE.Vector3(dx, 0, dz).normalize();
        let mvx = 0, mvz = 0;
        if (dist > (this.spec.ranged ? 11 : this.spec.range * 0.7)) { mvx = toP.x; mvz = toP.z; }
        else if (this.spec.ranged && dist < 6.5) { mvx = -toP.x; mvz = -toP.z; }
        this.pos.x += mvx * this.spec.spd * dt;
        this.pos.z += mvz * this.spec.spd * dt;
        collideMove(this.pos, 0.5, 0, ctx.world.colliders);
        this.pos.y = supportHeight(this.pos.x, this.pos.z, this.pos.y + 2, ctx.world.colliders);
        this.rig.root.rotation.y = angDamp(this.rig.root.rotation.y, Math.atan2(dx, dz), 8, dt);
        const movingE = Math.hypot(mvx, mvz) > 0.1;
        this.rig.animPhase += dt * (4 + this.spec.spd);
        animateRig(this.rig, {
          mv: movingE ? clamp(this.spec.spd / 7, 0.4, 1) : 0, run: this.spec.spd > 5, grounded: true, vy: 0,
          climbing: false, attack: null, block: false, kagune: !!this.kagune && this.kagune.emerge >= 1, dead: 0, flinch: 0,
        }, dt, ctx.time);
        if (this.kagune) updateKagune(this.kagune, dt, ctx.time, movingE);
        if (this.cd <= 0) {
          if (!this.spec.ranged && dist < this.spec.range + 0.4) { this.state = "windup"; this.t = 0; this.windupDur = this.spec.boss ? 0.62 : 0.5; }
          else if (this.spec.ranged && dist < this.spec.range) { this.state = "windup"; this.t = 0; this.windupDur = this.spec.boss ? 0.7 : 0.75; }
        }
        break;
      }
      case "windup": {
        this.t += dt;
        const q = this.t / this.windupDur;
        animateRig(this.rig, {
          mv: 0, run: false, grounded: true, vy: 0, climbing: false,
          attack: { kind: "heavy", p: q * 0.44 }, block: false,
          kagune: !!this.kagune && this.kagune.emerge >= 1, dead: 0, flinch: 0,
        }, dt, ctx.time);
        if (this.kagune) { this.kagune.strikeT = q * 0.3; updateKagune(this.kagune, dt, ctx.time, false); }
        if (this.t >= this.windupDur) {
          this.state = "strike"; this.t = 0;
          if (this.spec.ranged) {
            ctx.audio.slash();
            const from = this.pos.clone().add(new THREE.Vector3(0, 1.5, 0));
            const dir = p.pos.clone().add(new THREE.Vector3(0, 1.1, 0)).sub(from).normalize();
            if (this.spec.boss) {
              for (let i = -1; i <= 1; i++) fireProjectile(ctx, from, dir.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), i * 0.18), 18, this.spec.dmg * 0.8, false, 0x5f8fd9);
            } else {
              fireProjectile(ctx, from, dir, this.spec.type === "hunter" ? 22 : 16, this.spec.dmg, false, this.spec.type === "hunter" ? 0x5f8fd9 : 0xff2038);
            }
            if (this.kagune) this.kagune.strikeT = 0;
          } else {
            ctx.audio.slash();
            if (this.kagune) this.kagune.strikeT = 0;
            if (dist < this.spec.range + 0.9) {
              p.takeDamage(ctx, this.spec.dmg, this.pos);
            }
          }
        }
        break;
      }
      case "strike":
        this.t += dt;
        if (this.t > 0.22) { this.state = "recover"; this.t = 0; this.cd = this.spec.boss ? 1.1 : 1.7 + Math.random(); }
        break;
      case "recover":
        this.t += dt;
        animateRig(this.rig, { mv: 0, run: false, grounded: true, vy: 0, climbing: false, attack: { kind: "heavy", p: 0.6 + this.t }, block: false, kagune: !!this.kagune && this.kagune.emerge >= 1, dead: 0, flinch: 0 }, dt, ctx.time);
        if (this.t > 0.4) this.state = "chase";
        break;
      case "stagger":
        this.t -= dt;
        this.pos.x += this.vel.x * dt; this.pos.z += this.vel.z * dt;
        this.vel.multiplyScalar(Math.exp(-6 * dt));
        collideMove(this.pos, 0.5, 0, ctx.world.colliders);
        animateRig(this.rig, { mv: 0, run: false, grounded: true, vy: 0, climbing: false, attack: null, block: false, kagune: !!this.kagune && this.kagune.emerge >= 1, dead: 0, flinch: 0.8 }, dt, ctx.time);
        if (this.t <= 0) this.state = "chase";
        break;
      default: break;
    }
    // شريط الصحة يواجه الكاميرا
    if (this.bar.visible) {
      this.bar.lookAt(ctx.camera.position);
      const frac = clamp(this.hp / this.maxHp, 0, 1);
      this.barFg.scale.x = Math.max(0.001, frac);
      this.barFg.position.x = -(1 - frac) * (this.spec.boss ? 0.78 : 0.45);
    }
    return false;
  }
}

export function spawnEnemy(ctx: Ctx, type: EnemyType, x: number, z: number, tag: string, y = 0): Enemy {
  const spec = { ...SPECS[type] };
  const e = new Enemy(spec, x, z, ctx.scene);
  e.pos.y = y;
  e.tag = tag;
  ctx.enemies.push(e);
  return e;
}

// ─────────────── المدنيون ───────────────
export interface Npc {
  g: THREE.Group; state: "walk" | "idle" | "flee";
  target: THREE.Vector3; wait: number; speed: number; t: number; informant?: boolean;
}
export function spawnNpc(ctx: Ctx, informant = false): Npc {
  const jackets = [0x33404e, 0x4e3b3b, 0x3b4e40, 0x4a4536, 0x39364e, 0x555a62];
  const g = buildCivilian(
    jackets[Math.floor(Math.random() * jackets.length)],
    0x22242a, 0xd0a98c, [0x141210, 0x2a2018, 0x3a2c20, 0x101418][Math.floor(Math.random() * 4)]
  );
  const road = -216 + 24 + Math.floor(Math.random() * 9) * 48;
  const along = (Math.random() - 0.5) * 380;
  const horiz = Math.random() < 0.5;
  g.position.set(horiz ? along : road + (Math.random() < 0.5 ? -5 : 5), 0, horiz ? road + (Math.random() < 0.5 ? -5 : 5) : along);
  ctx.scene.add(g);
  return {
    g, state: "walk", target: new THREE.Vector3(g.position.x + (Math.random() - 0.5) * 60, 0, g.position.z + (Math.random() - 0.5) * 60),
    wait: 0, speed: informant ? 5.4 : 1.5, t: Math.random() * 9, informant,
  };
}
export function updateNpc(n: Npc, dt: number, ctx: Ctx) {
  n.t += dt;
  const p = ctx.player;
  const dp = Math.hypot(p.pos.x - n.g.position.x, p.pos.z - n.g.position.z);
  const scared = !p.dead && (p.kaguneOn ? dp < 14 : dp < 6 && p.attack);
  if (scared && !n.informant) n.state = "flee";
  if (n.state === "flee" && !scared) n.state = "walk";
  let spd = n.speed;
  if (n.state === "idle") {
    n.wait -= dt;
    if (n.wait <= 0) {
      n.state = "walk";
      n.target.set(n.g.position.x + (Math.random() - 0.5) * 70, 0, n.g.position.z + (Math.random() - 0.5) * 70);
      n.target.x = clamp(n.target.x, -210, 210); n.target.z = clamp(n.target.z, -210, 210);
    }
  } else {
    if (n.state === "flee") {
      n.target.set(n.g.position.x * 2 - p.pos.x, 0, n.g.position.z * 2 - p.pos.z);
      spd = 5.2;
    }
    const dx = n.target.x - n.g.position.x, dz = n.target.z - n.g.position.z;
    const d = Math.hypot(dx, dz);
    if (d < 2) { n.state = "idle"; n.wait = 1.5 + Math.random() * 4; }
    else {
      n.g.position.x += (dx / d) * spd * dt;
      n.g.position.z += (dz / d) * spd * dt;
      n.g.rotation.y = angDamp(n.g.rotation.y, Math.atan2(dx, dz), 6, dt);
    }
  }
  const moving = n.state !== "idle";
  n.g.position.y = moving ? Math.abs(Math.sin(n.t * (spd > 3 ? 11 : 6))) * 0.05 : 0;
  n.g.rotation.z = moving ? Math.sin(n.t * 6) * 0.04 : 0;
  void ctx;
}

// ─────────────── مدير المهمات ───────────────
export class MissionManager {
  ctx: Ctx;
  storyIdx: number;
  done: Set<string>;
  cur: MissionDef | null = null;
  side: MissionDef | null = null;
  phase: "talk" | "active" | "waiting" | "over" = "waiting";
  sidePhase: "talk" | "active" | "over" = "over";
  killCount = 0; sideKillCount = 0; collectCount = 0;
  visitedRoofs: boolean[] = [false, false, false];
  crystalsSpawned = false;
  informant: Npc | null = null;
  beaconMeshes: THREE.Object3D[] = [];
  constructor(ctx: Ctx, storyIdx: number, done: string[]) {
    this.ctx = ctx;
    this.storyIdx = storyIdx;
    this.done = new Set(done);
    const story = MISSIONS.filter((m) => m.kind === "story");
    this.cur = this.storyIdx < story.length ? story[this.storyIdx] : null;
  }
  storyDone() { return !this.cur; }
  markers(): { x: number; z: number; c: string }[] {
    const out: { x: number; z: number; c: string }[] = [];
    const pts = this.objectivePoints(this.cur, this.phase, this.visitedRoofs);
    for (const pt of pts) out.push({ x: pt.x, z: pt.z, c: "#e0455e" });
    if (this.side && this.sidePhase === "active") {
      for (const pt of this.objectivePoints(this.side, this.sidePhase, null)) out.push({ x: pt.x, z: pt.z, c: "#ffb02e" });
    }
    return out;
  }
  objectivePoints(m: MissionDef | null, phase: string, roofs: boolean[] | null): { x: number; z: number; h: number }[] {
    if (!m || phase !== "active") return [];
    const A = this.ctx.world.anchors;
    const o = m.objective;
    if (o.kind === "reach" && o.at) {
      const list = A[o.at] || [];
      if (o.at === "roofs" && roofs) return list.filter((_, i) => !roofs[i]);
      return list;
    }
    if (o.kind === "kill" || o.kind === "boss") {
      // موقع آخر مجموعة أعداء
      const alive = this.ctx.enemies.filter((e) => !e.dead && (o.tag === "any" || e.tag === o.tag));
      if (alive.length) return alive.slice(0, 1).map((e) => ({ x: e.pos.x, z: e.pos.z, h: 0 }));
    }
    if (o.kind === "catch" && this.informant) return [{ x: this.informant.g.position.x, z: this.informant.g.position.z, h: 0 }];
    return [];
  }
  startCurrent() {
    if (!this.cur) { this.phase = "over"; return; }
    this.phase = "talk";
    const m = this.cur;
    this.killCount = 0; this.collectCount = 0; this.visitedRoofs = [false, false, false];
    this.ctx.dialogue(m.before, () => {
      if (m.spawns) {
        for (const s of m.spawns) {
          const anchors = this.ctx.world.anchors[s.at] || [{ x: 0, z: 0, h: 0 }];
          for (let i = 0; i < s.count; i++) {
            const a = anchors[0];
            const e = spawnEnemy(this.ctx, s.type, a.x + (Math.random() - 0.5) * 8, a.z + (Math.random() - 0.5) * 8, m.objective.tag || "", a.h);
            if (s.type === "informant") { e.state = "idle"; }
          }
        }
      }
      if (m.objective.kind === "catch") {
        const a = (this.ctx.world.anchors[m.objective.at || "park"] || [{ x: -192, z: -192, h: 0 }])[0];
        this.informant = spawnNpc(this.ctx, true);
        this.informant.g.position.set(a.x, 0, a.z);
      }
      this.phase = "active";
      this.ctx.notify(`مهمة: ${m.title}`, "info");
    });
  }
  startSide(id: string) {
    const m = MISSIONS.find((x) => x.id === id);
    if (!m || this.done.has(id) || (this.side && this.side.id === id)) return;
    this.side = m;
    this.sidePhase = "talk";
    this.sideKillCount = 0;
    if (id === "s1" && !this.crystalsSpawned) {
      this.crystalsSpawned = true;
      const rects = this.ctx.world.rects.filter((r) => r.hx < 12);
      for (let i = 0; i < 12; i++) {
        const r = rects[(i * 7 + 3) % rects.length];
        const h = this.ctx.world.colliders.find((c) => c.x === r.x && c.z === r.z);
        if (h) spawnPickup(this.ctx, new THREE.Vector3(r.x, h.h + 0.7, r.z), "crystal");
      }
    }
    this.ctx.dialogue(m.before, () => {
      this.sidePhase = "active";
      this.ctx.notify(`مهمة جانبية: ${m.title}`, "info");
    });
  }
  onKill(tag: string) {
    if (this.phase === "active" && this.cur) {
      const o = this.cur.objective;
      if ((o.kind === "kill" || o.kind === "boss") && (o.tag === "any" || o.tag === tag)) {
        this.killCount++;
        if (this.killCount >= (o.count || 1)) this.complete(this.cur, false);
      }
    }
    if (this.sidePhase === "active" && this.side) {
      const o = this.side.objective;
      if (o.kind === "kill" && o.tag === "any") {
        this.sideKillCount++;
        if (this.sideKillCount >= (o.count || 1)) this.complete(this.side, true);
      }
    }
  }
  onCollect(kind: string) {
    if (kind !== "crystal") return;
    if (this.sidePhase === "active" && this.side && this.side.objective.kind === "collect") {
      this.collectCount++;
      if (this.collectCount >= (this.side.objective.count || 10)) this.complete(this.side, true);
    }
  }
  update(dt: number) {
    const p = this.ctx.player;
    if (p.dead) return;
    void dt;
    if (this.phase === "active" && this.cur) {
      const o = this.cur.objective;
      if (o.kind === "reach" && o.at) {
        const list = this.ctx.world.anchors[o.at] || [];
        if (o.at === "roofs") {
          let all = true;
          list.forEach((a, i) => {
            const d = Math.hypot(a.x - p.pos.x, a.z - p.pos.z);
            if (!this.visitedRoofs[i] && d < (o.radius || 4) && Math.abs(p.pos.y - a.h) < 2.2) {
              this.visitedRoofs[i] = true;
              this.ctx.notify(`منارة ${list.filter((_, j) => this.visitedRoofs[j]).length}/${list.length}`, "good");
              this.ctx.audio.pickup();
            }
            if (!this.visitedRoofs[i]) all = false;
          });
          if (all && list.length) this.complete(this.cur, false);
        } else {
          const a = list[0];
          if (a && Math.hypot(a.x - p.pos.x, a.z - p.pos.z) < (o.radius || 5) && Math.abs(p.pos.y - a.h) < 3) {
            this.complete(this.cur, false);
          }
        }
      }
      if (o.kind === "catch" && this.informant) {
        const d = Math.hypot(this.informant.g.position.x - p.pos.x, this.informant.g.position.z - p.pos.z);
        if (d < 2.4) this.complete(this.cur, false);
      }
    }
  }
  complete(m: MissionDef, isSide: boolean) {
    if (isSide) this.sidePhase = "over"; else this.phase = "talk";
    this.ctx.dialogue(m.after, (choice) => {
      if (choice) this.ctx.flags.add(choice);
      this.done.add(m.id);
      if (isSide) this.side = null;
      else this.storyIdx++;
      (this.ctx as any).reward?.(m.xp, m.cells, m.unlock);
      this.ctx.notify(`+${m.xp} خبرة  •  +${m.cells} خلية RC`, "good");
      this.ctx.audio.pickup();
      if (m.unlock) this.ctx.notify(`شخصية جديدة انضمت: ${m.unlock === "yuki" ? "يوكي شيروغاني" : m.unlock === "sora" ? "سورا أكاباني" : "الأجوف"}`, "good");
      if (m.id === "m6") {
        const end = ["end_bridge", "end_veil", "end_human"].find((f) => this.ctx.flags.has(f)) || "end_bridge";
        (this.ctx as any).onEnding(end);
        this.phase = "over";
        return;
      }
      if (!isSide) {
        const story = MISSIONS.filter((x) => x.kind === "story");
        this.cur = this.storyIdx < story.length ? story[this.storyIdx] : null;
        this.saveHook();
        setTimeout(() => this.startCurrent(), 600);
      } else this.saveHook();
    });
  }
  saveHook: () => void = () => { };
}

// ─────────────── الحليف رين ───────────────
export class Ally {
  rig: Rig; kagune: KaguneRig; cd = 0;
  constructor(scene: THREE.Scene, x: number, z: number) {
    this.rig = buildHumanoid(null, { jacket: 0x2a2119, pants: 0x1c1814, skin: 0xc9a184, hair: 0x2c2c34 });
    this.rig.root.position.set(x, 0, z);
    scene.add(this.rig.root);
    this.kagune = buildKagune("blade", this.rig, 0.8);
    this.kagune.emerge = 1;
    this.kagune.active = true;
    setKaguneEyes(this.rig, true, 0xc9a86a);
  }
  get pos() { return this.rig.root.position; }
  update(dt: number, ctx: Ctx) {
    const p = ctx.player;
    this.cd -= dt;
    let target: Enemy | null = null, bd = 13;
    for (const e of ctx.enemies) {
      if (e.dead) continue;
      const d = e.pos.distanceTo(this.pos);
      if (d < bd) { bd = d; target = e; }
    }
    let moving = false;
    if (target) {
      const dx = target.pos.x - this.pos.x, dz = target.pos.z - this.pos.z;
      const d = Math.hypot(dx, dz);
      this.rig.root.rotation.y = angDamp(this.rig.root.rotation.y, Math.atan2(dx, dz), 10, dt);
      if (d > 2.4) {
        this.pos.x += (dx / d) * 6 * dt; this.pos.z += (dz / d) * 6 * dt;
        collideMove(this.pos, 0.5, 0, ctx.world.colliders);
        moving = true;
      } else if (this.cd <= 0) {
        this.cd = 1.15;
        this.kagune.strikeT = 0;
        ctx.audio.slash();
        target.takeHit(ctx, 20, new THREE.Vector3(dx / d, 0, dz / d), 2);
        ctx.particles.burst(target.pos.clone().add(new THREE.Vector3(0, 1.3, 0)), 0xc9a86a, 10, 5, 0.35, 0.24);
      }
    } else {
      const dx = p.pos.x - this.pos.x, dz = p.pos.z - this.pos.z;
      const d = Math.hypot(dx, dz);
      if (d > 4.5) {
        this.pos.x += (dx / d) * 7 * dt; this.pos.z += (dz / d) * 7 * dt;
        collideMove(this.pos, 0.5, 0, ctx.world.colliders);
        this.rig.root.rotation.y = angDamp(this.rig.root.rotation.y, Math.atan2(dx, dz), 10, dt);
        moving = true;
      }
    }
    this.pos.y = supportHeight(this.pos.x, this.pos.z, this.pos.y + 2, ctx.world.colliders);
    this.rig.animPhase += dt * 9;
    animateRig(this.rig, { mv: moving ? 0.8 : 0, run: true, grounded: true, vy: 0, climbing: false, attack: null, block: false, kagune: true, dead: 0, flinch: 0 }, dt, ctx.time);
    updateKagune(this.kagune, dt, ctx.time, moving);
  }
}

// ─────────────── منارات المهمات ───────────────
export function makeBeacon(color: number): THREE.Group {
  const g = new THREE.Group();
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.7, 24, 10, 1, true),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
  beam.position.y = 12;
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.3, 0.1, 6, 24),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.85 }));
  ring.rotation.x = Math.PI / 2; ring.position.y = 0.3;
  const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.4),
    new THREE.MeshStandardMaterial({ color: 0x10040a, emissive: color, emissiveIntensity: 2.5 }));
  gem.position.y = 2.2;
  g.add(beam); g.add(ring); g.add(gem);
  return g;
}
