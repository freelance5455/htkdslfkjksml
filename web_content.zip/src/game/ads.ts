/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  AD_ENVIRONMENT,
  AD_POLICY,
  AdEnvironment,
  getActiveAdMobConfig,
  WEB_AD_CONFIG,
} from './adConfig';
import { sound } from './audio';

const AD_STATE_STORAGE_KEY = 'arrow_master_ad_state_v1';

export interface PersistedAdState {
  launchCount: number;
  lastAppOpenShownAt: number;
}

export type RewardedAdStatus =
  | 'rewarded'
  | 'dismissed_without_reward'
  | 'failed'
  | 'unavailable'
  | 'busy';

export interface RewardedAdOutcome {
  status: RewardedAdStatus;
  granted: boolean;
  rewardAmount: number;
  message?: string;
}

export interface AppOpenOutcome {
  shown: boolean;
  reason: string;
}

export interface ConsentStatusResult {
  canRequestAds: boolean;
  privacyOptionsRequired: boolean;
}

interface NativeArrowMasterAdsPlugin {
  initialize(options: {
    environment: AdEnvironment;
    appOpenAdUnitId: string;
    rewardedAdUnitId: string;
    minSessionsBeforeAppOpen: number;
    appOpenCooldownMs: number;
  }): Promise<ConsentStatusResult>;
  setGameplayActive(options: { active: boolean }): Promise<void>;
  isAppOpenAdReady(): Promise<{ ready: boolean }>;
  showAppOpenIfReady(options: {
    launchCount: number;
    lastShownAt: number;
    minSessions: number;
    cooldownMs: number;
  }): Promise<AppOpenOutcome>;
  preloadRewardedAd(): Promise<{ loaded: boolean }>;
  showRewardedAd(options: { eventId: string }): Promise<{
    status: 'rewarded' | 'dismissed_without_reward' | 'failed' | 'unavailable';
    rewardAmount: number;
    message?: string;
  }>;
  getConsentStatus(): Promise<ConsentStatusResult>;
  openPrivacyOptions(): Promise<ConsentStatusResult>;
}

interface CapacitorWindow extends Window {
  Capacitor?: {
    isNativePlatform?: () => boolean;
    getPlatform?: () => string;
    Plugins?: {
      ArrowMasterAds?: NativeArrowMasterAdsPlugin;
    };
  };
}

/**
 * Pure gating predicate for App Open Ads (used both at runtime and in unit tests).
 */
export function canShowAppOpenAdNow(params: {
  launchCount: number;
  lastShownAt: number;
  nowMs: number;
  isGameplayActive: boolean;
  canRequestAds: boolean;
  minSessions?: number;
  cooldownMs?: number;
}): { allowed: boolean; reason: string } {
  const minSessions = params.minSessions ?? AD_POLICY.minSessionsBeforeFirstAppOpenAd;
  const cooldownMs = params.cooldownMs ?? AD_POLICY.appOpenCooldownMs;

  if (!params.canRequestAds) {
    return { allowed: false, reason: 'consent_not_ready' };
  }
  if (params.isGameplayActive) {
    return { allowed: false, reason: 'gameplay_active' };
  }
  if (params.launchCount < minSessions) {
    return { allowed: false, reason: 'below_min_sessions' };
  }
  if (params.lastShownAt > 0 && params.nowMs - params.lastShownAt < cooldownMs) {
    return { allowed: false, reason: 'cooldown_active' };
  }
  return { allowed: true, reason: 'eligible' };
}

/**
 * Pure reward validation helper ensuring hearts are ONLY awarded upon official
 * rewarded callback confirmation and at most once per unique game-over event.
 */
export function resolveRewardGrant(params: {
  eventId: string;
  sdkStatus: 'rewarded' | 'dismissed_without_reward' | 'failed' | 'unavailable';
  sdkRewardAmount: number;
  grantedEventIds: Set<string>;
  message?: string;
}): RewardedAdOutcome {
  if (!params.eventId || params.grantedEventIds.has(params.eventId)) {
    return {
      status: 'busy',
      granted: false,
      rewardAmount: 0,
      message: 'Extra heart already claimed for this attempt.',
    };
  }

  if (params.sdkStatus === 'rewarded' && params.sdkRewardAmount >= 1) {
    params.grantedEventIds.add(params.eventId);
    return {
      status: 'rewarded',
      granted: true,
      rewardAmount: 1,
    };
  }

  if (params.sdkStatus === 'dismissed_without_reward') {
    return {
      status: 'dismissed_without_reward',
      granted: false,
      rewardAmount: 0,
      message:
        params.message ||
        'Watch the full video ad to earn 1 extra heart.',
    };
  }

  if (params.sdkStatus === 'unavailable') {
    return {
      status: 'unavailable',
      granted: false,
      rewardAmount: 0,
      message:
        params.message ||
        'No video ad is available right now. Please try again in a moment.',
    };
  }

  return {
    status: 'failed',
    granted: false,
    rewardAmount: 0,
    message:
      params.message ||
      'Unable to load the video ad right now. Please check your connection and try again.',
  };
}

class AdManager {
  private initialized = false;
  private initPromise: Promise<void> | null = null;
  private isGameplayActive = false;
  private isRewardedInFlight = false;
  private canRequestAds = false;
  private privacyOptionsRequired = false;
  private grantedEventIds = new Set<string>();
  private state: PersistedAdState = {
    launchCount: 0,
    lastAppOpenShownAt: 0,
  };

  private getNativePlugin(): NativeArrowMasterAdsPlugin | null {
    if (typeof window === 'undefined') return null;
    const cap = (window as CapacitorWindow).Capacitor;
    const isNative = Boolean(cap?.isNativePlatform?.());
    if (!isNative) return null;
    return cap?.Plugins?.ArrowMasterAds ?? null;
  }

  public isNativeAndroid(): boolean {
    if (typeof window === 'undefined') return false;
    const cap = (window as CapacitorWindow).Capacitor;
    return Boolean(cap?.isNativePlatform?.() && (cap?.getPlatform?.() ?? 'android') === 'android');
  }

  public isPrivacyOptionsRequired(): boolean {
    return this.privacyOptionsRequired && Boolean(this.getNativePlugin());
  }

  private loadState(): PersistedAdState {
    if (typeof localStorage === 'undefined') {
      return { launchCount: 0, lastAppOpenShownAt: 0 };
    }
    try {
      const raw = localStorage.getItem(AD_STATE_STORAGE_KEY);
      if (!raw) return { launchCount: 0, lastAppOpenShownAt: 0 };
      const parsed = JSON.parse(raw) as Partial<PersistedAdState>;
      return {
        launchCount: typeof parsed.launchCount === 'number' && parsed.launchCount >= 0 ? parsed.launchCount : 0,
        lastAppOpenShownAt:
          typeof parsed.lastAppOpenShownAt === 'number' && parsed.lastAppOpenShownAt >= 0
            ? parsed.lastAppOpenShownAt
            : 0,
      };
    } catch {
      return { launchCount: 0, lastAppOpenShownAt: 0 };
    }
  }

  private saveState() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(AD_STATE_STORAGE_KEY, JSON.stringify(this.state));
    } catch {
      // Ignore storage quota errors gracefully
    }
  }

  public async initialize(): Promise<void> {
    if (this.initialized) return;
    if (this.initPromise) return this.initPromise;

    this.initPromise = (async () => {
      this.state = this.loadState();
      this.state.launchCount += 1;
      this.saveState();

      const plugin = this.getNativePlugin();
      if (plugin) {
        try {
          const config = getActiveAdMobConfig(AD_ENVIRONMENT);
          const consent = await plugin.initialize({
            environment: AD_ENVIRONMENT,
            appOpenAdUnitId: config.appOpenAdUnitId,
            rewardedAdUnitId: config.rewardedAdUnitId,
            minSessionsBeforeAppOpen: AD_POLICY.minSessionsBeforeFirstAppOpenAd,
            appOpenCooldownMs: AD_POLICY.appOpenCooldownMs,
          });
          this.canRequestAds = Boolean(consent?.canRequestAds);
          this.privacyOptionsRequired = Boolean(consent?.privacyOptionsRequired);

          if (this.canRequestAds) {
            void plugin.preloadRewardedAd().catch(() => {});
          }
        } catch {
          this.canRequestAds = false;
        }
      } else {
        // Browser environment: no native Android AdMob SDK. Keep web disabled unless real web SDK configured.
        this.canRequestAds = WEB_AD_CONFIG.enabled;
        this.privacyOptionsRequired = false;
      }

      this.initialized = true;
    })();

    return this.initPromise;
  }

  public setGameplayActive(active: boolean) {
    this.isGameplayActive = active;
    const plugin = this.getNativePlugin();
    if (plugin) {
      void plugin.setGameplayActive({ active }).catch(() => {});
    }
    if (active) {
      this.preloadRewardedAd();
    }
  }

  public preloadRewardedAd() {
    const plugin = this.getNativePlugin();
    if (!plugin || !this.canRequestAds) return;
    void plugin.preloadRewardedAd().catch(() => {});
  }

  /**
   * Attempts to show a preloaded App Open Ad during the splash screen.
   * Never blocks or stalls the player if no ad is ready or consent/gating prevents it.
   */
  public async tryShowSplashAppOpenAd(): Promise<AppOpenOutcome> {
    const plugin = this.getNativePlugin();
    if (!plugin) {
      // Browser environment never shows fake App Open Ads.
      await this.initialize();
      return { shown: false, reason: 'web_no_native_sdk' };
    }

    // Bound initialization wait so player is never stuck on splash if UMP/network is slow
    await Promise.race([
      this.initialize(),
      new Promise<void>((resolve) => {
        window.setTimeout(resolve, AD_POLICY.splashAdCheckTimeoutMs);
      }),
    ]);

    const gate = canShowAppOpenAdNow({
      launchCount: this.state.launchCount,
      lastShownAt: this.state.lastAppOpenShownAt,
      nowMs: Date.now(),
      isGameplayActive: this.isGameplayActive,
      canRequestAds: this.canRequestAds,
    });

    if (!gate.allowed) {
      return { shown: false, reason: gate.reason };
    }

    // Fast readiness check before committing to displaying an ad
    const readyCheck = await Promise.race([
      plugin.isAppOpenAdReady().catch(() => ({ ready: false })),
      new Promise<{ ready: boolean }>((resolve) => {
        window.setTimeout(() => resolve({ ready: false }), 350);
      }),
    ]);

    if (!readyCheck.ready) {
      return { shown: false, reason: 'not_ready' };
    }

    sound.pauseForAd();
    try {
      const result = await plugin.showAppOpenIfReady({
        launchCount: this.state.launchCount,
        lastShownAt: this.state.lastAppOpenShownAt,
        minSessions: AD_POLICY.minSessionsBeforeFirstAppOpenAd,
        cooldownMs: AD_POLICY.appOpenCooldownMs,
      });
      if (result.shown) {
        this.state.lastAppOpenShownAt = Date.now();
        this.saveState();
      }
      return result;
    } catch {
      return { shown: false, reason: 'error' };
    } finally {
      sound.resumeAfterAd();
    }
  }

  /**
   * Shared single-flight rewarded ad execution used by both Extra Heart and Hint systems.
   * Grants reward ONLY when Google AdMob's official reward callback confirms completion.
   */
  private async runRewardedAd(
    eventId: string,
    webUnavailableMessage: string,
    nativeUnavailableMessage: string
  ): Promise<RewardedAdOutcome> {
    if (this.isRewardedInFlight) {
      return {
        status: 'busy',
        granted: false,
        rewardAmount: 0,
        message: 'Ad request is already in progress.',
      };
    }

    if (this.grantedEventIds.has(eventId)) {
      return {
        status: 'busy',
        granted: false,
        rewardAmount: 0,
        message: 'Reward has already been claimed for this ad.',
      };
    }

    this.isRewardedInFlight = true;
    try {
      await this.initialize();
      const plugin = this.getNativePlugin();

      if (!plugin) {
        // Website/AI Studio preview runtime without native AdMob SDK: NEVER fake an ad.
        return {
          status: 'unavailable',
          granted: false,
          rewardAmount: 0,
          message: webUnavailableMessage,
        };
      }

      if (!this.canRequestAds) {
        return {
          status: 'unavailable',
          granted: false,
          rewardAmount: 0,
          message: nativeUnavailableMessage,
        };
      }

      sound.pauseForAd();
      try {
        const sdkResult = await plugin.showRewardedAd({ eventId });
        return resolveRewardGrant({
          eventId,
          sdkStatus: sdkResult.status,
          sdkRewardAmount: sdkResult.rewardAmount,
          grantedEventIds: this.grantedEventIds,
          message: sdkResult.message,
        });
      } finally {
        sound.resumeAfterAd();
        void plugin.preloadRewardedAd().catch(() => {});
      }
    } catch {
      return {
        status: 'failed',
        granted: false,
        rewardAmount: 0,
        message: 'Ad is not available. Please try again.',
      };
    } finally {
      this.isRewardedInFlight = false;
    }
  }

  /**
   * Shows a Rewarded Video Ad for 1 Extra Heart.
   * Grants a heart ONLY when Google AdMob's official reward callback confirms it.
   */
  public async showRewardedExtraHeartAd(eventId: string): Promise<RewardedAdOutcome> {
    return this.runRewardedAd(
      eventId,
      'Video ads require the Android app with Google AdMob active. You can restart this level or return to the menu.',
      'Ad consent is required before loading video ads. Please check Privacy Options in Settings or retry.'
    );
  }

  /**
   * Shows a Rewarded Video Ad for 1 Extra Hint.
   * Grants 1 hint ONLY when Google AdMob's official reward callback confirms it.
   */
  public async showRewardedHintAd(eventId: string): Promise<RewardedAdOutcome> {
    const outcome = await this.runRewardedAd(
      eventId,
      'Ad is not available. Please try again. (Browser preview: Rewarded video ads require the Android APK with Google AdMob.)',
      'Ad is not available. Please try again.'
    );

    if (!outcome.granted && (outcome.status === 'failed' || outcome.status === 'unavailable')) {
      const isPreviewMsg = outcome.message?.includes('Browser preview:');
      return {
        ...outcome,
        message: isPreviewMsg ? outcome.message : 'Ad is not available. Please try again.',
      };
    }

    return outcome;
  }

  public async openPrivacyOptions(): Promise<ConsentStatusResult> {
    const plugin = this.getNativePlugin();
    if (!plugin) {
      return {
        canRequestAds: this.canRequestAds,
        privacyOptionsRequired: false,
      };
    }
    try {
      const updated = await plugin.openPrivacyOptions();
      this.canRequestAds = Boolean(updated?.canRequestAds);
      this.privacyOptionsRequired = Boolean(updated?.privacyOptionsRequired);
      if (this.canRequestAds) {
        this.preloadRewardedAd();
      }
      return updated;
    } catch {
      return {
        canRequestAds: this.canRequestAds,
        privacyOptionsRequired: this.privacyOptionsRequired,
      };
    }
  }
}

export const adManager = new AdManager();
