import { Sim, HOLD, CONTRACT, EXTEND, RELAX, JOINT_IDS, TURN_STEPS, PART_INDEX as P } from './physics';
import { PRESETS, presetStates } from './presets';

export type Difficulty = 'easy' | 'normal' | 'hard';

const SAMPLES: Record<Difficulty, number> = { easy: 3, normal: 12, hard: 22 };
const NOISE: Record<Difficulty, number> = { easy: 30, normal: 6, hard: 0 };

export interface BotMove {
  states: number[];
  grip: [boolean, boolean];
}

function candidate(blocked: boolean[]): BotMove {
  const states: number[] = new Array(20).fill(HOLD);
  const r = Math.random();
  if (r < 0.55) {
    const p = PRESETS[Math.floor(Math.random() * PRESETS.length)];
    const base = presetStates(p);
    const rate = Math.random() < 0.5 ? 0.0 : 0.15;
    for (const i of JOINT_IDS) {
      states[i] = Math.random() < rate ? Math.floor(Math.random() * 4) : base[i];
    }
    // sometimes combine with a second preset
    if (Math.random() < 0.4) {
      const q = presetStates(PRESETS[Math.floor(Math.random() * PRESETS.length)]);
      for (const i of JOINT_IDS) if (q[i] !== HOLD && Math.random() < 0.5) states[i] = q[i];
    }
  } else if (r < 0.6) {
    // plain hold
  } else {
    for (const i of JOINT_IDS) {
      const x = Math.random();
      states[i] = x < 0.4 ? HOLD : x < 0.6 ? CONTRACT : x < 0.8 ? EXTEND : RELAX;
    }
  }
  for (const i of JOINT_IDS) if (blocked[i]) states[i] = RELAX;
  const grip: [boolean, boolean] = [Math.random() < 0.35, Math.random() < 0.35];
  return { states, grip };
}

const REACH_PARTS = [P.handR, P.handL, P.footR, P.footL, P.shinR, P.shinL];
const TARGET_PARTS = [P.head, P.chest, P.abs, 0];

export function planBot(live: Sim, scratch: Sim, meIdx: number, diff: Difficulty): BotMove {
  const opIdx = 1 - meIdx;
  const snap = live.snapshot();
  const broken = live.fighters.map((f) => f.broken.slice());
  const blocked = live.fighters[meIdx].broken;
  let best: BotMove | null = null;
  let bestScore = -Infinity;

  // always consider "do nothing"
  const n = SAMPLES[diff];
  for (let k = 0; k < n; k++) {
    const cand = candidate(blocked);
    scratch.restore(snap, broken);
    const me = scratch.fighters[meIdx];
    const op = scratch.fighters[opIdx];
    const d0me = me.damage;
    const d0op = op.damage;
    for (const i of JOINT_IDS) {
      me.state[i] = cand.states[i];
      op.state[i] = HOLD;
    }
    me.grip = [cand.grip[0], cand.grip[1]];
    scratch.beginTurn();
    for (let s = 0; s < TURN_STEPS; s++) scratch.step();
    // follow-through: keep every joint locked for a moment to see if we keep our balance
    scratch.beginTurn();
    for (const i of JOINT_IDS) {
      me.state[i] = HOLD;
      op.state[i] = HOLD;
    }
    for (let s = 0; s < 14; s++) scratch.step();
    scratch.events.length = 0;

    let score = (op.damage - d0op) * 1.0 - (me.damage - d0me) * 1.2;
    const mp = me.bodies[0].getPosition();
    const opp = op.bodies[0].getPosition();
    score -= Math.max(0, Math.abs(mp.x - opp.x) - 1.1) * 6;
    let md = 9;
    for (const a of REACH_PARTS) {
      const pa = me.bodies[a].getPosition();
      for (const b of TARGET_PARTS) {
        const pb = op.bodies[b].getPosition();
        md = Math.min(md, Math.hypot(pa.x - pb.x, pa.y - pb.y));
      }
    }
    score -= md * 5;
    score += Math.min(me.bodies[P.head].getPosition().y, 1.75) * 22;
    score += Math.min(me.bodies[0].getPosition().y, 1.0) * 10;
    score += NOISE[diff] * Math.random();
    if (score > bestScore) {
      bestScore = score;
      best = cand;
    }
  }
  return best!;
}
