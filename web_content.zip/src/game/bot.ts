import { PLAYER_RADIUS, SPRINT_SPEED, WALK_SPEED } from './constants';
import { Fighter } from './fighter';
import type { Outfit } from './humanoid';
import type { World } from './world';
import type { Zone } from './zone';
import { WEAPONS } from './weapons';

export interface BotEnv {
  world: World;
  zone: Zone;
  fighters: Fighter[];
  hasLOS(ax: number, ay: number, az: number, bx: number, by: number, bz: number): boolean;
  fire(shooter: Bot, tx: number, ty: number, tz: number, accuracy: number): void;
  nearestLoot(bot: Bot, maxD: number): { x: number; z: number } | null;
}

const angleTo = (dx: number, dz: number) => Math.atan2(-dx, -dz);

function lerpAngle(a: number, b: number, t: number): number {
  let d = b - a;
  d = ((d + Math.PI) % (Math.PI * 2)) - Math.PI;
  return a + d * t;
}

/** Computer-controlled opponent: loots, roams, fights and escapes the zone. */
export class Bot extends Fighter {
  state: 'roam' | 'loot' | 'fight' | 'zone' = 'roam';
  aggro: Fighter | null = null;
  private goalX = 0;
  private goalZ = 0;
  private goalT = 0;
  private target: Fighter | null = null;
  private retarget = 0;
  private strafe = 1;
  private strafeT = 0;
  private skill: number;

  constructor(id: number, name: string, outfit: Outfit) {
    super(id, name, outfit);
    this.skill = (Math.random() - 0.5) * 0.12;
  }

  update(dt: number, env: BotEnv) {
    if (!this.alive) return;
    const zone = env.zone;

    this.retarget -= dt;
    if (this.retarget <= 0) {
      this.retarget = 0.4 + Math.random() * 0.3;
      this.target = this.findTarget(env);
    }
    this.strafeT -= dt;
    if (this.strafeT <= 0) {
      this.strafeT = 0.8 + Math.random() * 1.2;
      this.strafe = Math.random() < 0.5 ? -1 : 1;
    }

    let gx = 0;
    let gz = 0;
    let moving = false;
    let speed = WALK_SPEED;
    let aimAt: Fighter | null = null;

    if (!zone.contains(this.x, this.z, 2)) {
      this.state = 'zone';
      gx = zone.cx;
      gz = zone.cz;
      moving = true;
      speed = SPRINT_SPEED;
    } else if (this.target && this.weapon) {
      this.state = 'fight';
      aimAt = this.target;
      const t = this.target;
      const dx = t.x - this.x;
      const dz = t.z - this.z;
      const d = Math.max(0.01, Math.hypot(dx, dz));
      const fx = dx / d;
      const fz = dz / d;
      // Strafe across the line of fire, close in when far, back off when too close.
      let mx = -fz * this.strafe * 0.9;
      let mz = fx * this.strafe * 0.9;
      const range = WEAPONS[this.weapon].range;
      if (d > range * 0.5) {
        mx += fx;
        mz += fz;
      } else if (d < 9) {
        mx -= fx;
        mz -= fz;
      }
      gx = this.x + mx;
      gz = this.z + mz;
      moving = true;
      speed = WALK_SPEED * 0.9;

      const eyeY = this.y + 1.55;
      const tgtY = t.y + 1.2;
      const pitch = Math.atan2(tgtY - eyeY, d);
      this.pitch = pitch;

      if (this.fireCd <= 0 && !this.reloading) {
        if (this.slot.mag <= 0) {
          this.startReload();
        } else if (env.hasLOS(this.x, eyeY, this.z, t.x, t.y + 1.5, t.z)) {
          const acc = Math.min(0.8, Math.max(0.22, 0.62 - d * 0.0035 + this.skill));
          env.fire(this, t.x, t.y + 1.2, t.z, acc);
        }
      }
    } else if (!this.weapon || (this.slot.mag === 0 && this.reserve.light + this.reserve.heavy + this.reserve.shell === 0)) {
      this.state = 'loot';
      const spot = env.nearestLoot(this, 60);
      if (spot) {
        gx = spot.x;
        gz = spot.z;
        moving = true;
      } else {
        moving = this.roam(env, (x, z) => {
          gx = x;
          gz = z;
        });
      }
      speed = SPRINT_SPEED * 0.8;
    } else {
      this.state = 'roam';
      this.goalT -= dt;
      const reached = Math.hypot(this.goalX - this.x, this.goalZ - this.z) < 1.5;
      if (this.goalT <= 0 || reached) {
        this.pickRoamGoal(zone);
      }
      gx = this.goalX;
      gz = this.goalZ;
      moving = true;
      if (this.slot.mag === 0 && this.reserve[WEAPONS[this.weapon].ammo] > 0) this.startReload();
    }

    if (!this.target || this.state !== 'fight') this.pitch *= 0.9;

    let vx = 0;
    let vz = 0;
    if (moving) {
      const dx = gx - this.x;
      const dz = gz - this.z;
      const d = Math.hypot(dx, dz);
      if (d > 0.2) {
        vx = (dx / d) * speed;
        vz = (dz / d) * speed;
      }
    }
    this.x += vx * dt;
    this.z += vz * dt;
    [this.x, this.z] = env.world.resolve(this.x, this.z, PLAYER_RADIUS, this.y);
    this.y = env.world.groundAt(this.x, this.z);

    // Face the target when fighting, otherwise the direction of travel.
    let desired = this.yaw;
    if (aimAt) desired = angleTo(aimAt.x - this.x, aimAt.z - this.z);
    else if (vx !== 0 || vz !== 0) desired = angleTo(vx, vz);
    this.yaw = lerpAngle(this.yaw, desired, Math.min(1, dt * 8));

    this.body.update(dt, Math.min(1, Math.hypot(vx, vz) / SPRINT_SPEED), aimAt !== null, this.pitch);
  }

  private roam(env: BotEnv, set: (x: number, z: number) => void): boolean {
    this.goalT -= 0.0;
    const zone = env.zone;
    if (Math.hypot(this.goalX - this.x, this.goalZ - this.z) < 1.5 || this.goalT <= 0) {
      this.pickRoamGoal(zone);
    }
    set(this.goalX, this.goalZ);
    return true;
  }

  private pickRoamGoal(zone: Zone) {
    const a = Math.random() * Math.PI * 2;
    const r = Math.sqrt(Math.random()) * Math.max(10, zone.r * 0.8);
    this.goalX = zone.cx + Math.cos(a) * r;
    this.goalZ = zone.cz + Math.sin(a) * r;
    this.goalT = 8 + Math.random() * 8;
  }

  private findTarget(env: BotEnv): Fighter | null {
    const eyeY = this.y + 1.55;
    if (this.aggro && this.aggro.alive && Math.hypot(this.aggro.x - this.x, this.aggro.z - this.z) < 80) {
      return this.aggro;
    }
    let best: Fighter | null = null;
    let bestD = 55;
    for (const f of env.fighters) {
      if (f === this || !f.alive) continue;
      const d = Math.hypot(f.x - this.x, f.z - this.z);
      if (d >= bestD) continue;
      if (env.hasLOS(this.x, eyeY, this.z, f.x, f.y + 1.5, f.z)) {
        best = f;
        bestD = d;
      }
    }
    return best;
  }
}
