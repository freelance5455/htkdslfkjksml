// ============================================================
// DEEP DIG — location environments (3D environment artist)
// All static decor is merged into a handful of meshes per location.
// ============================================================
import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import type { LocationDef } from "./data";
import { M, mesh, getEnv } from "./treasureModels";
import { mulberry32, smoothstep, clamp, type Terrain } from "./terrain";

export class Batch {
  parts: THREE.BufferGeometry[] = [];
  private m = new THREE.Matrix4();
  private q = new THREE.Quaternion();
  private e = new THREE.Euler();
  private p = new THREE.Vector3();
  private s = new THREE.Vector3();
  add(geo: THREE.BufferGeometry, color: number, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = sx, sz = sx) {
    const g = geo.index ? geo.toNonIndexed() : geo.clone();
    g.deleteAttribute("uv");
    this.e.set(rx, ry, rz);
    this.q.setFromEuler(this.e);
    this.m.compose(this.p.set(x, y, z), this.q, this.s.set(sx, sy, sz));
    g.applyMatrix4(this.m);
    const n = g.attributes.position.count;
    const c = new Float32Array(n * 3);
    const col = new THREE.Color(color);
    const k = 0.9 + Math.random() * 0.2;
    for (let i = 0; i < n; i++) {
      c[i * 3] = col.r * k;
      c[i * 3 + 1] = col.g * k;
      c[i * 3 + 2] = col.b * k;
    }
    g.setAttribute("color", new THREE.BufferAttribute(c, 3));
    this.parts.push(g);
  }
  limb(a: THREE.Vector3, b: THREE.Vector3, r0: number, r1: number, color: number, seg = 7) {
    const dir = b.clone().sub(a);
    const len = dir.length();
    const geo = new THREE.CylinderGeometry(r1, r0, len, seg, 1);
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
    const e = new THREE.Euler().setFromQuaternion(q);
    const mid = a.clone().add(b).multiplyScalar(0.5);
    this.add(geo, color, mid.x, mid.y, mid.z, e.x, e.y, e.z);
  }
  build(mat: THREE.Material, shadow = true): THREE.Mesh | null {
    if (!this.parts.length) return null;
    const g = mergeGeometries(this.parts, false);
    this.parts.forEach((p) => p.dispose());
    this.parts = [];
    const m = new THREE.Mesh(g, mat);
    m.castShadow = shadow;
    m.receiveShadow = true;
    return m;
  }
}

const rockGeos: THREE.BufferGeometry[] = [];
function rockGeo(i: number) {
  if (rockGeos[i]) return rockGeos[i];
  const g = new THREE.IcosahedronGeometry(1, 1);
  const p = g.attributes.position;
  for (let k = 0; k < p.count; k++) {
    const x = p.getX(k), y = p.getY(k), z = p.getZ(k);
    const h = Math.sin(x * 12.9 + i * 3.1) * 43758.5 + Math.sin(y * 78.2 + z * 37.7 + i) * 12345.6;
    const f = 0.82 + (h - Math.floor(h)) * 0.36;
    p.setXYZ(k, x * f, y * f * 0.8, z * f);
  }
  g.computeVertexNormals();
  rockGeos[i] = g;
  return g;
}

export interface Collider {
  x: number;
  z: number;
  r: number;
}
export interface Scenery {
  group: THREE.Group;
  colliders: Collider[];
  merchant: THREE.Group;
  stationPos: THREE.Vector3;
  front: THREE.Vector3;
  update: (dt: number, t: number) => void;
  dispose: () => void;
}

const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);

export function buildScenery(loc: LocationDef, terrain: Terrain, seed: number): Scenery {
  const rnd = mulberry32(seed + 77);
  const solid = new Batch();
  const leaf = new Batch();
  const glow = new Batch();
  const colliders: Collider[] = [];
  const group = new THREE.Group();
  const sx = loc.station.x, sz = loc.station.z;
  const wl = loc.water ? loc.water.level : -99;
  const at = (x: number, z: number) => terrain.origAt(x, z);
  const free = (x: number, z: number, r: number) => {
    if (Math.hypot(x - sx, z - sz) < 7 + r) return false;
    if (Math.hypot(x - loc.spawn.x, z - loc.spawn.z) < 4 + r) return false;
    if (at(x, z) < wl + 0.45) return false;
    for (const c of colliders) if (Math.hypot(c.x - x, c.z - z) < c.r + r + 0.4) return false;
    return true;
  };
  const spot = (minR: number, maxR: number, r: number) => {
    for (let i = 0; i < 40; i++) {
      const a = rnd() * Math.PI * 2, d = minR + rnd() * (maxR - minR);
      const x = Math.cos(a) * d, z = Math.sin(a) * d;
      if (Math.abs(x) < 28 && Math.abs(z) < 28 && free(x, z, r)) return [x, z] as const;
    }
    return null;
  };
  const rock = (x: number, z: number, s: number, color: number, col = true) => {
    const y = at(x, z);
    solid.add(rockGeo(Math.floor(rnd() * 5)), color, x, y + s * 0.15, z, 0, rnd() * 6, 0, s * (0.9 + rnd() * 0.5), s * 0.8, s * (0.9 + rnd() * 0.4));
    if (col && s > 0.6) colliders.push({ x, z, r: s * 0.85 });
  };
  const palm = (x: number, z: number, s = 1) => {
    const base = at(x, z) - 0.1;
    const lean = (rnd() - 0.5) * 1.4, dirA = rnd() * 6.28;
    const H = (4.5 + rnd() * 2.2) * s;
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 7; i++) {
      const t = i / 7;
      pts.push(V(x + Math.cos(dirA) * lean * t * t * 2, base + t * H, z + Math.sin(dirA) * lean * t * t * 2));
    }
    for (let i = 0; i < 7; i++) solid.limb(pts[i], pts[i + 1], 0.2 * s * (1 - i * 0.07), 0.2 * s * (1 - (i + 1) * 0.07), i % 2 ? 0x8a6a45 : 0x7a5c3a, 7);
    const top = pts[7];
    for (let k = 0; k < 10; k++) {
      const geo = new THREE.PlaneGeometry(0.7, 3.4, 2, 7);
      geo.rotateX(-Math.PI / 2);
      geo.translate(0, 0, 1.7);
      const p = geo.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const zz = p.getZ(i) / 3.4;
        p.setY(i, -zz * zz * 1.9 * s + Math.abs(p.getX(i)) * 0.35);
        p.setX(i, p.getX(i) * (1 - zz * 0.75));
      }
      geo.computeVertexNormals();
      leaf.add(geo, rnd() < 0.5 ? 0x2f8a3a : 0x3a9a40, top.x, top.y, top.z, (rnd() - 0.5) * 0.3, (k / 10) * 6.28 + rnd() * 0.3, 0, s);
    }
    for (let k = 0; k < 3; k++) solid.add(new THREE.SphereGeometry(0.17 * s, 7, 6), 0x5a3e1e, top.x + Math.cos(k * 2.1) * 0.25, top.y - 0.25, top.z + Math.sin(k * 2.1) * 0.25);
    colliders.push({ x, z, r: 0.35 * s });
  };
  const column = (x: number, z: number, h: number, broken: boolean, color: number) => {
    const y = at(x, z) - 0.15;
    solid.add(new THREE.BoxGeometry(1.5, 0.3, 1.5), color, x, y + 0.15, z, 0, 0, 0);
    solid.add(new THREE.CylinderGeometry(0.5, 0.58, h, 12), color, x, y + 0.3 + h / 2, z);
    if (!broken) {
      solid.add(new THREE.BoxGeometry(1.4, 0.3, 1.4), color, x, y + 0.45 + h, z);
      solid.add(new THREE.CylinderGeometry(0.62, 0.5, 0.2, 12), color, x, y + 0.3 + h - 0.05, z);
    } else {
      solid.add(new THREE.CylinderGeometry(0.42, 0.5, 0.5, 6), color, x + 0.2, y + 0.3 + h + 0.15, z, 0.3, 0, 0.2);
    }
    colliders.push({ x, z, r: 0.75 });
  };
  const wallRun = (x: number, z: number, len: number, rot: number, color: number) => {
    const n = Math.floor(len / 1.2);
    for (let i = 0; i < n; i++) {
      const d = (i - n / 2) * 1.2;
      const wx = x + Math.cos(rot) * d, wz = z - Math.sin(rot) * d;
      const h = 0.6 + rnd() * 1.6;
      solid.add(new THREE.BoxGeometry(1.15, h, 0.9), color, wx, at(wx, wz) - 0.2 + h / 2, wz, 0, rot + (rnd() - 0.5) * 0.06, 0);
      colliders.push({ x: wx, z: wz, r: 0.7 });
    }
  };
  const crate = (x: number, z: number, s: number, col = true) => {
    const y = at(x, z);
    const r = rnd() * 6;
    solid.add(new THREE.BoxGeometry(s, s, s), 0x9b7040, x, y + s / 2 - 0.05, z, 0, r, 0);
    solid.add(new THREE.BoxGeometry(s * 1.04, s * 0.12, s * 1.04), 0x5a3e20, x, y + s * 0.2, z, 0, r, 0);
    solid.add(new THREE.BoxGeometry(s * 1.04, s * 0.12, s * 1.04), 0x5a3e20, x, y + s * 0.8, z, 0, r, 0);
    if (col) colliders.push({ x, z, r: s * 0.7 });
  };
  const barrel = (x: number, z: number) => {
    const y = at(x, z);
    solid.add(new THREE.CylinderGeometry(0.4, 0.35, 0.9, 10), 0x7a4e2a, x, y + 0.4, z);
    for (const hy of [0.15, 0.65]) solid.add(new THREE.CylinderGeometry(0.42, 0.42, 0.05, 10), 0x2c2c30, x, y + hy, z);
    colliders.push({ x, z, r: 0.45 });
  };
  const umbrella = (x: number, z: number, c1: number, c2: number) => {
    const y = at(x, z);
    solid.add(new THREE.CylinderGeometry(0.03, 0.03, 2.4, 6), 0xdddddd, x, y + 1.1, z, 0.12, 0, 0.1);
    for (let i = 0; i < 8; i++)
      solid.add(new THREE.ConeGeometry(1.5, 0.55, 8, 1, true, (i * Math.PI) / 4, Math.PI / 4), i % 2 ? c1 : c2, x - 0.12, y + 2.3, z + 0.1, 0.12, 0, 0.1);
    colliders.push({ x, z, r: 0.3 });
  };
  const cactus = (x: number, z: number, s: number) => {
    const y = at(x, z) - 0.1;
    const gcol = 0x4f8a3c;
    solid.add(new THREE.CapsuleGeometry(0.3 * s, 2.2 * s, 4, 8), gcol, x, y + 1.3 * s, z);
    if (rnd() < 0.8) {
      solid.add(new THREE.CapsuleGeometry(0.17 * s, 0.7 * s, 4, 6), gcol, x + 0.55 * s, y + 1.45 * s, z, 0, 0, Math.PI / 2);
      solid.add(new THREE.CapsuleGeometry(0.17 * s, 0.8 * s, 4, 6), gcol, x + 0.85 * s, y + 1.9 * s, z);
    }
    if (rnd() < 0.7) {
      solid.add(new THREE.CapsuleGeometry(0.15 * s, 0.5 * s, 4, 6), gcol, x - 0.5 * s, y + 1.1 * s, z, 0, 0, Math.PI / 2);
      solid.add(new THREE.CapsuleGeometry(0.15 * s, 0.7 * s, 4, 6), gcol, x - 0.75 * s, y + 1.5 * s, z);
    }
    colliders.push({ x, z, r: 0.5 * s });
  };
  const spire = (x: number, z: number, h: number, color: number, tilt = 0.15, lowY = 0) => {
    const y = at(x, z) - 0.2 + lowY;
    const rx = (rnd() - 0.5) * tilt * 2, rz = (rnd() - 0.5) * tilt * 2;
    const w = h * 0.16;
    glow.add(new THREE.CylinderGeometry(w, w * 1.15, h, 6), color, x, y + h / 2, z, rx, rnd() * 6, rz);
    glow.add(new THREE.ConeGeometry(w, h * 0.35, 6), color, x + Math.sin(rz) * -h * 0.58, y + h + h * 0.12, z + Math.sin(rx) * h * 0.58, rx, rnd() * 6, rz);
  };
  const bush = (x: number, z: number, s: number) => {
    const y = at(x, z);
    for (let i = 0; i < 4; i++) solid.add(new THREE.IcosahedronGeometry(0.5 * s, 1), i % 2 ? 0x2e7d32 : 0x3b8f3d, x + (rnd() - 0.5) * 0.7 * s, y + 0.3 * s + rnd() * 0.3, z + (rnd() - 0.5) * 0.7 * s);
  };
  const hill = (x: number, z: number, r: number, h: number, color: number) => {
    solid.add(new THREE.SphereGeometry(1, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), color, x, loc.farY - 0.3, z, 0, rnd() * 3, 0, r, h, r * 0.7);
  };

  // ---------------- per-location decor ----------------
  switch (loc.id) {
    case "beach": {
      for (let i = 0; i < 6; i++) {
        const p = spot(14, 28, 1);
        if (p && p[1] < 6) palm(p[0], p[1], 0.9 + rnd() * 0.3);
      }
      for (let i = 0; i < 3; i++) palm(-26 + i * 3, -24 + rnd() * 3, 1.1);
      for (let i = 0; i < 4; i++) palm(14 + i * 3.5, -26 + rnd() * 2, 1.1);
      umbrella(-6, -12, 0xe53935, 0xffffff);
      umbrella(5, -14, 0x1e88e5, 0xffffff);
      umbrella(-16, 6, 0xffb300, 0xffffff);
      for (let i = 0; i < 14; i++) {
        const p = spot(6, 28, 1.2);
        if (p) rock(p[0], p[1], 0.4 + rnd() * 1.1, 0x8a8480);
      }
      for (let i = 0; i < 4; i++) {
        const p = spot(5, 24, 1);
        if (p) solid.add(new THREE.CylinderGeometry(0.15, 0.2, 2.6, 7), 0x9b8467, p[0], at(p[0], p[1]) + 0.1, p[1], 0, rnd() * 6, Math.PI / 2 + 0.05);
      }
      // lifeguard tower
      const lx = 18, lz = 2;
      for (const [dx, dz] of [[-0.8, -0.8], [0.8, -0.8], [-0.8, 0.8], [0.8, 0.8]]) solid.limb(V(lx + dx * 1.4, at(lx, lz) - 0.2, lz + dz * 1.4), V(lx + dx * 0.9, at(lx, lz) + 2.6, lz + dz * 0.9), 0.1, 0.08, 0xf0efe9);
      solid.add(new THREE.BoxGeometry(2.4, 0.15, 2.4), 0xf0efe9, lx, at(lx, lz) + 2.6, lz);
      solid.add(new THREE.BoxGeometry(2.8, 0.15, 2.8), 0xe53935, lx, at(lx, lz) + 4.1, lz);
      for (const [dx, dz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) solid.add(new THREE.CylinderGeometry(0.05, 0.05, 1.5, 5), 0xf0efe9, lx + dx * 1.1, at(lx, lz) + 3.35, lz + dz * 1.1);
      colliders.push({ x: lx, z: lz, r: 1.8 });
      // sandcastle
      const cx = 8, cz = 10, cy = at(cx, cz);
      solid.add(new THREE.CylinderGeometry(0.9, 1.1, 0.8, 10), 0xd7bd84, cx, cy + 0.3, cz);
      for (const [dx, dz] of [[-0.7, 0], [0.7, 0], [0, 0.7], [0, -0.7]]) solid.add(new THREE.CylinderGeometry(0.22, 0.28, 1.0, 8), 0xd7bd84, cx + dx, cy + 0.7, cz + dz);
      solid.add(new THREE.ConeGeometry(0.4, 0.7, 8), 0xd7bd84, cx, cy + 1.2, cz);
      colliders.push({ x: cx, z: cz, r: 1.2 });
      // surfboard & buoy
      solid.add(new THREE.CapsuleGeometry(0.22, 2, 4, 8), 0xff7043, -20, at(-20, -3) + 1.0, -3, 0.2, 0.4, 0.1, 1, 1, 0.25);
      colliders.push({ x: -20, z: -3, r: 0.5 });
      crate(-16, -14, 0.9);
      barrel(-17.2, -13.2);
      hill(-60, -70, 40, 14, 0x6c8f5d);
      hill(70, -60, 50, 18, 0x7d9a69);
      break;
    }
    case "desert": {
      // ruined temple
      const sand = 0xc9a56a;
      for (let i = 0; i < 6; i++) column(-14 + i * 3.4, -18, 3.5 + rnd() * 1.5, i % 3 === 1, sand);
      for (let i = 0; i < 4; i++) column(-12 + i * 3.4, -23, 2.5 + rnd() * 3, i % 2 === 0, sand);
      wallRun(-2, -26, 14, 0, 0xbf9b60);
      // arch
      const ax = 14, az = 6;
      column(ax - 2.2, az, 4.6, false, sand);
      column(ax + 2.2, az, 4.6, false, sand);
      solid.add(new THREE.BoxGeometry(6.4, 1.1, 1.5), 0xbd995c, ax, at(ax, az) + 5.4, az);
      solid.add(new THREE.BoxGeometry(1.2, 0.6, 1.2), 0xbd995c, ax + 1, at(ax, az) + 6.3, az);
      // obelisk
      const ox = -18, oz = 10;
      solid.add(new THREE.CylinderGeometry(0.6, 0.95, 7, 4), 0xc7a368, ox, at(ox, oz) + 3.3, oz, 0, Math.PI / 4, 0.04);
      solid.add(new THREE.ConeGeometry(0.62, 0.9, 4), 0xe0b94f, ox + 0.1, at(ox, oz) + 7.2, oz, 0, Math.PI / 4, 0.04);
      colliders.push({ x: ox, z: oz, r: 1.1 });
      // fallen columns
      for (let i = 0; i < 3; i++) {
        const p = spot(8, 26, 1.5);
        if (p) {
          solid.add(new THREE.CylinderGeometry(0.5, 0.5, 3 + rnd() * 2, 10), sand, p[0], at(p[0], p[1]) + 0.2, p[1], 0, rnd() * 6, Math.PI / 2);
          colliders.push({ x: p[0], z: p[1], r: 1.4 });
        }
      }
      for (let i = 0; i < 9; i++) {
        const p = spot(8, 28, 1);
        if (p) cactus(p[0], p[1], 0.8 + rnd() * 0.7);
      }
      for (let i = 0; i < 12; i++) {
        const p = spot(6, 28, 1);
        if (p) rock(p[0], p[1], 0.4 + rnd() * 1.0, 0x8f6b4c);
      }
      // camels' bones & tent
      solid.add(new THREE.ConeGeometry(2.0, 2.2, 4), 0xe9dcc0, 18, at(18, -14) + 1.0, -14, 0, 0.8, 0);
      colliders.push({ x: 18, z: -14, r: 1.8 });
      hill(-70, 40, 45, 16, 0xcf8742);
      hill(60, 70, 60, 20, 0xc77a3a);
      hill(0, -90, 70, 22, 0xd08944);
      hill(90, -20, 50, 18, 0xc47838);
      break;
    }
    case "tropical": {
      for (let i = 0; i < 22; i++) {
        const p = spot(8, 22, 1.2);
        if (p) palm(p[0], p[1], 0.9 + rnd() * 0.5);
      }
      for (let i = 0; i < 12; i++) {
        const p = spot(6, 22, 1);
        if (p) bush(p[0], p[1], 0.9 + rnd() * 0.8);
      }
      for (let i = 0; i < 10; i++) {
        const p = spot(5, 22, 1);
        if (p) rock(p[0], p[1], 0.4 + rnd() * 0.9, 0x7a7872);
      }
      // wrecked ship hull
      const wx = 13, wz = 8, wy = at(wx, wz);
      for (let i = 0; i < 9; i++) {
        const t = i / 8 - 0.5;
        const wd = 2.6 * (1 - Math.abs(t) * 0.9);
        solid.add(new THREE.BoxGeometry(0.3, 2.2, wd), 0x6b4a2c, wx + t * 6, wy + 0.6 + Math.abs(t) * 1.4, wz, 0, 0, 0.15 * -t);
        solid.add(new THREE.BoxGeometry(0.25, 2, 0.15), 0x59391e, wx + t * 6, wy + 1.0 + Math.abs(t) * 1.4, wz + wd / 2, 0.3, 0, 0);
        solid.add(new THREE.BoxGeometry(0.25, 2, 0.15), 0x59391e, wx + t * 6, wy + 1.0 + Math.abs(t) * 1.4, wz - wd / 2, -0.3, 0, 0);
      }
      solid.add(new THREE.CylinderGeometry(0.15, 0.2, 6.5, 7), 0x5b3e22, wx - 0.5, wy + 3.2, wz, 0, 0, 0.25);
      leaf.add(new THREE.PlaneGeometry(2.4, 2.4), 0xddd4b8, wx + 0.7, wy + 4.2, wz + 0.1, 0, 0, 0.25);
      colliders.push({ x: wx, z: wz, r: 2.0 }, { x: wx - 2.5, z: wz, r: 1.4 }, { x: wx + 2.5, z: wz, r: 1.4 });
      for (let i = 0; i < 4; i++) barrel(-8 + i * 0.8, 15 + (i % 2) * 0.7);
      // tiki torches
      for (let i = 0; i < 6; i++) {
        const p = spot(7, 20, 0.6);
        if (p) {
          solid.add(new THREE.CylinderGeometry(0.06, 0.08, 2.0, 6), 0x6b4a2c, p[0], at(p[0], p[1]) + 0.9, p[1]);
          glow.add(new THREE.ConeGeometry(0.14, 0.4, 6), 0xff8a2a, p[0], at(p[0], p[1]) + 2.1, p[1]);
          colliders.push({ x: p[0], z: p[1], r: 0.2 });
        }
      }
      hill(-45, -55, 25, 12, 0x2f7a3c);
      hill(55, 40, 20, 9, 0x2f7a3c);
      break;
    }
    case "dig": {
      // survey grid
      for (let gx = -2; gx <= 2; gx++)
        for (let gz = -2; gz <= 2; gz++) {
          const x = gx * 7, z = gz * 7;
          if (!free(x, z, 0.3) || (Math.abs(gx) < 2 && Math.abs(gz) < 2 && (gx + gz) % 2)) continue;
          solid.add(new THREE.BoxGeometry(0.1, 0.9, 0.1), gx === 0 || gz === 0 ? 0xe8e3d2 : 0xc94b3a, x, at(x, z) + 0.4, z);
        }
      for (let i = 0; i < 3; i++) {
        const p = spot(14, 27, 3);
        if (p) {
          solid.add(new THREE.ConeGeometry(2.0, 2.2, 4), i % 2 ? 0xe9dcc0 : 0x5b7a5a, p[0], at(p[0], p[1]) + 1.0, p[1], 0, 0.8, 0);
          colliders.push({ x: p[0], z: p[1], r: 1.8 });
        }
      }
      for (let i = 0; i < 5; i++) {
        const p = spot(7, 26, 1);
        if (p) crate(p[0], p[1], 0.8 + rnd() * 0.5);
      }
      for (let i = 0; i < 4; i++) {
        const p = spot(7, 26, 1);
        if (p) barrel(p[0], p[1]);
      }
      for (let i = 0; i < 5; i++) {
        const p = spot(10, 27, 1.5);
        if (p) column(p[0], p[1], 1.5 + rnd() * 2.5, rnd() < 0.6, 0xb9a88a);
      }
      wallRun(-5, -22, 12, 0.2, 0xa8977a);
      wallRun(21, -2, 9, 1.5, 0xa8977a);
      for (let i = 0; i < 12; i++) {
        const p = spot(8, 28, 1);
        if (p) rock(p[0], p[1], 0.4 + rnd() * 1.0, 0x7d7468);
      }
      // sieve frame
      const sv = spot(8, 20, 1.5);
      if (sv) {
        solid.add(new THREE.BoxGeometry(1.4, 0.05, 1.0), 0x8a6a3c, sv[0], at(sv[0], sv[1]) + 0.9, sv[1], 0.3, 0.4, 0);
        for (const dx of [-0.6, 0.6]) solid.add(new THREE.CylinderGeometry(0.04, 0.04, 1.0, 5), 0x6b4a2c, sv[0] + dx, at(sv[0], sv[1]) + 0.45, sv[1] + 0.4);
        colliders.push({ x: sv[0], z: sv[1], r: 0.9 });
      }
      hill(-70, 30, 40, 10, 0xa89270);
      hill(50, -80, 55, 14, 0xa88f6a);
      break;
    }
    case "crystal": {
      const cols = [0xb06bff, 0x5de0ff, 0xff7bd5, 0x6bffc4, 0x8f8bff];
      for (let i = 0; i < 16; i++) {
        const p = spot(10, 27, 1);
        if (p) {
          const c = cols[Math.floor(rnd() * cols.length)];
          const n = 3 + Math.floor(rnd() * 3);
          for (let k = 0; k < n; k++) spire(p[0] + (rnd() - 0.5) * 1.2, p[1] + (rnd() - 0.5) * 1.2, 1.2 + rnd() * 3.2, c, 0.35);
          colliders.push({ x: p[0], z: p[1], r: 1.1 });
        }
      }
      for (let i = 0; i < 12; i++) {
        const p = spot(6, 28, 1);
        if (p) rock(p[0], p[1], 0.4 + rnd() * 1.1, 0x4a4378);
      }
      // giant spires on the rim
      for (let i = 0; i < 18; i++) {
        const a = (i / 18) * 6.28 + rnd() * 0.3, d = 30 + rnd() * 25;
        spire(Math.cos(a) * d, Math.sin(a) * d, 8 + rnd() * 14, cols[i % cols.length], 0.25, loc.farY - at(Math.cos(a) * d, Math.sin(a) * d));
      }
      hill(0, -90, 60, 25, 0x3a3270);
      hill(-80, 40, 50, 20, 0x453a80);
      hill(80, 30, 50, 22, 0x3a2f6e);
      break;
    }
  }

  // ---------------- merchant station ----------------
  const station = new THREE.Group();
  const front = V(-sx, 0, -sz).normalize();
  station.position.set(sx, at(sx, sz), sz);
  station.rotation.y = Math.atan2(front.x, front.z);
  const st = new Batch();
  const wood = 0x8a5a30, dark = 0x5a3a1e;
  for (const [dx, dz] of [[-1.5, -0.9], [1.5, -0.9], [-1.5, 0.9], [1.5, 0.9]]) st.add(new THREE.CylinderGeometry(0.07, 0.08, 2.6, 7), wood, dx, 1.3, dz);
  st.add(new THREE.BoxGeometry(3.1, 0.95, 0.9), dark, 0, 0.5, 0.6);
  st.add(new THREE.BoxGeometry(3.3, 0.1, 1.1), 0xb98650, 0, 1.0, 0.6);
  st.add(new THREE.BoxGeometry(3.2, 0.1, 0.1), wood, 0, 2.55, -0.9);
  const acc = new THREE.Color(loc.accent).getHex();
  for (let i = 0; i < 8; i++) st.add(new THREE.BoxGeometry(0.4, 0.07, 2.5), i % 2 ? 0xf3efe2 : acc, -1.4 + i * 0.4, 2.65 - 0.15, 0.05, 0.28, 0, 0);
  st.add(new THREE.BoxGeometry(3.1, 0.9, 0.06), 0x6b4a2c, 0, 1.2, -0.95);
  for (let i = 0; i < 3; i++) st.add(new THREE.BoxGeometry(2.8, 0.05, 0.4), 0x7a5230, 0, 0.5 + i * 0.5, -0.8);
  st.add(new THREE.BoxGeometry(0.7, 0.7, 0.7), 0x9b7040, 2.1, 0.35, 0.1, 0, 0.3, 0);
  st.add(new THREE.BoxGeometry(0.55, 0.55, 0.55), 0x8a6238, 2.15, 0.98, 0.1, 0, 0.7, 0);
  st.add(new THREE.CylinderGeometry(0.35, 0.3, 0.8, 9), 0x7a4e2a, -2.1, 0.4, 0.2);
  for (let i = 0; i < 3; i++) st.add(new THREE.SphereGeometry(0.34, 8, 6), 0xc9b48a, -2.0 + i * 0.5, 0.25, 0.9 + (i % 2) * 0.4, 0, 0, 0, 1, 0.8, 1);
  // scale on counter
  st.add(new THREE.CylinderGeometry(0.2, 0.25, 0.04, 10), 0xb0a090, -0.9, 1.07, 0.6);
  st.add(new THREE.BoxGeometry(0.06, 0.4, 0.06), 0xb0a090, -0.9, 1.25, 0.6);
  st.add(new THREE.BoxGeometry(0.6, 0.04, 0.04), 0xb0a090, -0.9, 1.45, 0.6);
  // coin stack
  for (let i = 0; i < 6; i++) st.add(new THREE.CylinderGeometry(0.1, 0.1, 0.03, 12), 0xffc933, 0.9, 1.08 + i * 0.03, 0.55);
  // signpost
  st.add(new THREE.CylinderGeometry(0.06, 0.06, 3.6, 6), wood, 2.6, 1.8, 1.4);
  const stMesh = st.build(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.85, flatShading: false, side: THREE.DoubleSide }));
  if (stMesh) station.add(stMesh);
  // lantern
  const lant = mesh(new THREE.SphereGeometry(0.12, 8, 6), new THREE.MeshStandardMaterial({ color: 0xffd27a, emissive: 0xffa630, emissiveIntensity: 1.4 }), 1.4, 2.3, 0.2);
  station.add(lant);
  // sign label
  const lc = document.createElement("canvas");
  lc.width = 512;
  lc.height = 160;
  const g2 = lc.getContext("2d")!;
  g2.fillStyle = "#4a2f18";
  g2.beginPath();
  g2.roundRect(4, 4, 504, 152, 28);
  g2.fill();
  g2.strokeStyle = "#e8b95a";
  g2.lineWidth = 8;
  g2.stroke();
  g2.fillStyle = "#ffe29a";
  g2.font = "bold 62px 'Lilita One', Arial Black, sans-serif";
  g2.textAlign = "center";
  g2.fillText("TREASURE", 256, 78);
  g2.font = "bold 44px 'Lilita One', Arial Black, sans-serif";
  g2.fillText("BUYER  ·  SHOP", 256, 130);
  const lt = new THREE.CanvasTexture(lc);
  lt.colorSpace = THREE.SRGBColorSpace;
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(2.3, 0.72), new THREE.MeshStandardMaterial({ map: lt, roughness: 0.8, side: THREE.DoubleSide }));
  sign.position.set(2.6, 3.45, 1.45);
  sign.rotation.y = -0.2;
  station.add(sign);
  // merchant NPC
  const merchant = new THREE.Group();
  merchant.position.set(0, 0, -0.35);
  const robe = M(0x9c2f4a, { rough: 0.85 });
  const skin = M(0xc58b60, { rough: 0.8 });
  merchant.add(mesh(new THREE.CylinderGeometry(0.26, 0.38, 1.1, 12), robe, 0, 0.55, 0));
  merchant.add(mesh(new THREE.SphereGeometry(0.3, 12, 8), robe, 0, 1.18, 0).translateY(0.0));
  const head = new THREE.Group();
  head.position.set(0, 1.62, 0);
  head.add(mesh(new THREE.SphereGeometry(0.2, 14, 10), skin));
  head.add(mesh(new THREE.CylinderGeometry(0.2, 0.17, 0.32, 12), M(0xf1ead6, { rough: 0.9 }), 0, 0.2, 0));
  head.add(mesh(new THREE.SphereGeometry(0.2, 12, 8), M(0xf1ead6, { rough: 0.9 }), 0, 0.36, 0));
  head.add(mesh(new THREE.TorusGeometry(0.08, 0.02, 6, 10, Math.PI), M(0x2a1a10), 0, -0.07, 0.18, 0, 0, Math.PI));
  for (const s of [-1, 1]) head.add(mesh(new THREE.SphereGeometry(0.025, 6, 6), M(0x111111), s * 0.07, 0.04, 0.18));
  head.add(mesh(new THREE.SphereGeometry(0.035, 6, 6), skin, 0, -0.01, 0.2));
  merchant.add(head);
  merchant.userData.head = head;
  for (const s of [-1, 1]) merchant.add(mesh(new THREE.CapsuleGeometry(0.07, 0.4, 4, 8), robe, s * 0.34, 0.95, 0.25, 1.1, 0, s * 0.2));
  station.add(merchant);
  group.add(station);
  colliders.push({ x: sx + front.z * 0, z: sz, r: 1.9 });
  const sideV = V(front.z, 0, -front.x);
  colliders.push({ x: sx + sideV.x * 1.4, z: sz + sideV.z * 1.4, r: 1.3 }, { x: sx - sideV.x * 1.4, z: sz - sideV.z * 1.4, r: 1.3 });
  const stationPos = V(sx, at(sx, sz), sz);

  const stdMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, flatShading: true, envMap: getEnv(), envMapIntensity: 0.25 });
  const leafMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.8, side: THREE.DoubleSide });
  const glowMat = new THREE.MeshStandardMaterial({
    vertexColors: true, roughness: 0.15, metalness: 0.1, flatShading: true, emissive: new THREE.Color(0x5a2aa0), emissiveIntensity: 0.9, envMap: getEnv(), envMapIntensity: 1.4,
  });
  for (const [b, m] of [[solid, stdMat], [leaf, leafMat], [glow, glowMat]] as [Batch, THREE.Material][]) {
    const me = b.build(m);
    if (me) group.add(me);
  }

  const update = (_dt: number, t: number) => {
    merchant.position.y = Math.sin(t * 2) * 0.008;
    head.rotation.y = Math.sin(t * 0.6) * 0.25;
    (lant.material as THREE.MeshStandardMaterial).emissiveIntensity = 1.2 + Math.sin(t * 7) * 0.15;
  };
  return {
    group, colliders, merchant, stationPos, front, update,
    dispose: () => {
      group.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.isMesh) m.geometry.dispose();
      });
      lt.dispose();
      group.removeFromParent();
    },
  };
}

// ---------------- Sky / water / far land ----------------
export interface Env {
  group: THREE.Group;
  update: (dt: number, t: number, camPos: THREE.Vector3) => void;
  dispose: () => void;
}
export function buildEnv(loc: LocationDef, sandTex: THREE.Texture, terrain: Terrain): Env {
  const group = new THREE.Group();
  const sunDir = new THREE.Vector3(...loc.sun.dir).normalize();
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(400, 24, 16),
    new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false,
      uniforms: {
        top: { value: new THREE.Color(loc.sky.top) }, hor: { value: new THREE.Color(loc.sky.horizon) },
        sunDir: { value: sunDir }, sunCol: { value: new THREE.Color(loc.sun.color) },
      },
      vertexShader: `varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
      fragmentShader: `varying vec3 vP; uniform vec3 top; uniform vec3 hor; uniform vec3 sunDir; uniform vec3 sunCol;
        void main(){
          float h = clamp(vP.y, -0.2, 1.0);
          vec3 c = mix(hor, top, pow(max(h,0.0), 0.55));
          float s = max(dot(normalize(vP), sunDir), 0.0);
          c += sunCol * (pow(s, 600.0) * 3.0 + pow(s, 12.0) * 0.28);
          c = mix(c, hor * 0.95, smoothstep(0.0, -0.2, vP.y));
          gl_FragColor = vec4(c, 1.0);
        }`,
    })
  );
  sky.renderOrder = -10;
  group.add(sky);

  // clouds
  const cc = document.createElement("canvas");
  cc.width = 256;
  cc.height = 128;
  const cg = cc.getContext("2d")!;
  for (let i = 0; i < 14; i++) {
    const x = 50 + Math.random() * 156, y = 50 + Math.random() * 30, r = 22 + Math.random() * 26;
    const gr = cg.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, "rgba(255,255,255,0.55)");
    gr.addColorStop(1, "rgba(255,255,255,0)");
    cg.fillStyle = gr;
    cg.fillRect(0, 0, 256, 128);
  }
  const ct = new THREE.CanvasTexture(cc);
  ct.colorSpace = THREE.SRGBColorSpace;
  const clouds = new THREE.Group();
  const rr = mulberry32(loc.id.length * 31);
  for (let i = 0; i < loc.clouds; i++) {
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: ct, transparent: true, opacity: 0.8, depthWrite: false, fog: false, color: new THREE.Color(loc.sky.horizon).lerp(new THREE.Color(0xffffff), 0.6) }));
    const a = rr() * 6.28, d = 220 + rr() * 80;
    sp.position.set(Math.cos(a) * d, 60 + rr() * 60, Math.sin(a) * d);
    sp.scale.set(120 + rr() * 80, 60 + rr() * 30, 1);
    clouds.add(sp);
  }
  group.add(clouds);

  // far land slabs
  const slabMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(loc.surface[0]).multiplyScalar(0.92), map: sandTex, roughness: 1 });
  const mk = (x0: number, x1: number, z0: number, z1: number) => {
    const w = x1 - x0, d = z1 - z0;
    const g = new THREE.PlaneGeometry(w, d);
    g.rotateX(-Math.PI / 2);
    const uv = g.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * w * 0.9, uv.getY(i) * d * 0.9);
    const m = new THREE.Mesh(g, slabMat);
    m.position.set((x0 + x1) / 2, loc.farY - 0.03, (z0 + z1) / 2);
    m.receiveShadow = true;
    group.add(m);
  };
  const B = 400, E = 30;
  if (loc.farSides.includes("n")) mk(-B, B, -B, -E);
  if (loc.farSides.includes("s")) mk(-B, B, E, B);
  if (loc.farSides.includes("w")) mk(-B, -E, -E, E);
  if (loc.farSides.includes("e")) mk(E, B, -E, E);

  // water
  let water: THREE.Mesh | null = null;
  let wtex: THREE.CanvasTexture | null = null;
  if (loc.water) {
    const wc = document.createElement("canvas");
    wc.width = wc.height = 256;
    const wg = wc.getContext("2d")!;
    wg.fillStyle = "#808080";
    wg.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 220; i++) {
      const x = Math.random() * 256, y = Math.random() * 256, r = 6 + Math.random() * 20;
      const gr = wg.createRadialGradient(x, y, 0, x, y, r);
      const b = Math.random() < 0.5 ? 255 : 0;
      gr.addColorStop(0, `rgba(${b},${b},${b},0.35)`);
      gr.addColorStop(1, `rgba(${b},${b},${b},0)`);
      wg.fillStyle = gr;
      wg.fillRect(x - r, y - r, r * 2, r * 2);
    }
    wtex = new THREE.CanvasTexture(wc);
    wtex.wrapS = wtex.wrapT = THREE.RepeatWrapping;
    wtex.repeat.set(70, 70);
    // sea mask: outer ocean slabs + inner cells only where the ORIGINAL terrain is below sea level
    const pos: number[] = [], uvs: number[] = [], idx: number[] = [];
    const quad = (x0: number, z0: number, x1: number, z1: number) => {
      const b = pos.length / 3;
      for (const [x, z] of [[x0, z0], [x1, z0], [x0, z1], [x1, z1]]) {
        pos.push(x, 0, z);
        uvs.push((x + 450) / 900, (z + 450) / 900);
      }
      idx.push(b, b + 2, b + 1, b + 1, b + 2, b + 3);
    };
    const O = 450, T = 30;
    quad(-O, -O, O, -T); quad(-O, T, O, O); quad(-O, -T, -T, T); quad(T, -T, O, T);
    const lv = loc.water.level + 0.3, st = 2;
    for (let j = 0; j < 200; j += st)
      for (let i = 0; i < 200; i += st) {
        const o = terrain.orig;
        const k = j * 201 + i;
        if (Math.min(o[k], o[k + st], o[k + st * 201], o[k + st * 201 + st]) < lv)
          quad(i * 0.3 - 30, j * 0.3 - 30, (i + st) * 0.3 - 30, (j + st) * 0.3 - 30);
      }
    const wgeo = new THREE.BufferGeometry();
    wgeo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    wgeo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
    wgeo.setIndex(idx);
    wgeo.computeVertexNormals();
    water = new THREE.Mesh(
      wgeo,      new THREE.MeshStandardMaterial({
        color: loc.water.color, transparent: true, opacity: loc.water.opacity, roughness: 0.12, metalness: 0.15,
        bumpMap: wtex, bumpScale: 2.5, envMap: getEnv(), envMapIntensity: 1.3,
      })
    );
    water.position.y = loc.water.level;
    water.renderOrder = 1;
    group.add(water);
  }

  return {
    group,
    update: (_dt, t, cam) => {
      sky.position.copy(cam);
      clouds.position.set(cam.x, 0, cam.z);
      clouds.rotation.y = t * 0.004;
      if (water && wtex) {
        wtex.offset.set(t * 0.012, t * 0.007);
        water.position.y = loc.water!.level + Math.sin(t * 0.8) * 0.03;
      }
    },
    dispose: () => {
      group.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.isMesh) m.geometry.dispose();
      });
      ct.dispose();
      wtex?.dispose();
      group.removeFromParent();
    },
  };
}

export { clamp, smoothstep };
