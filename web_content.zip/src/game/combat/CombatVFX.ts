import * as THREE from 'three';
import { ElementType } from '../types/gameTypes';

interface Projectile {
  mesh: THREE.Object3D;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  damage: number;
  element: ElementType | 'physical';
  radius: number;
  fromPlayer: boolean;
  spellId?: string;
  onHit?: (pos: THREE.Vector3) => void;
}

interface BurstEffect {
  mesh: THREE.Object3D;
  life: number;
  maxLife: number;
  growSpeed: number;
  spinSpeed?: number;
  fallSpeed?: number;
  targetY?: number;
}

export class CombatVFXManager {
  private scene: THREE.Scene;
  public projectiles: Projectile[] = [];
  private bursts: BurstEffect[] = [];
  private shieldGroup: THREE.Group | null = null;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
  }

  public spawnProjectile(opts: {
    origin: THREE.Vector3;
    dir: THREE.Vector3;
    speed: number;
    damage: number;
    element: ElementType | 'physical';
    radius: number;
    fromPlayer: boolean;
    spellId?: string;
  }) {
    const colorMap: Record<string, string> = {
      fire: '#f97316',
      ice: '#7dd3fc',
      water: '#38bdf8',
      lightning: '#fde047',
      physical: '#e2e8f0',
    };
    const col = colorMap[opts.element] || '#ffffff';
    const geo =
      opts.element === 'ice'
        ? new THREE.ConeGeometry(0.22, 0.9, 6)
        : opts.element === 'physical'
          ? new THREE.CylinderGeometry(0.04, 0.04, 0.9, 6)
          : new THREE.SphereGeometry(0.32, 10, 8);
    const mat = new THREE.MeshStandardMaterial({
      color: col,
      emissive: col,
      emissiveIntensity: opts.element === 'physical' ? 0.2 : 1.3,
      roughness: 0.2,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(opts.origin);
    if (opts.element === 'ice' || opts.element === 'physical') {
      mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), opts.dir.clone().normalize());
    }
    this.scene.add(mesh);

    this.projectiles.push({
      mesh,
      vx: opts.dir.x * opts.speed,
      vy: opts.dir.y * opts.speed,
      vz: opts.dir.z * opts.speed,
      life: 2.2,
      damage: opts.damage,
      element: opts.element,
      radius: opts.radius,
      fromPlayer: opts.fromPlayer,
      spellId: opts.spellId,
    });
  }

  public spawnSlashArc(pos: THREE.Vector3, yaw: number, color = '#fde68a') {
    const mat = new THREE.MeshBasicMaterial({
      color,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
    });
    const ring = new THREE.Mesh(new THREE.RingGeometry(1.1, 2.2, 16, 1, -Math.PI * 0.45, Math.PI * 0.9), mat);
    ring.position.set(pos.x, pos.y + 1.25, pos.z);
    ring.rotation.x = -Math.PI / 2;
    ring.rotation.z = yaw - Math.PI / 2;
    this.scene.add(ring);
    this.bursts.push({ mesh: ring, life: 0.22, maxLife: 0.22, growSpeed: 3.5 });
  }

  public spawnRingBurst(pos: THREE.Vector3, color: string, maxRadius: number, duration = 0.55) {
    const mat = new THREE.MeshBasicMaterial({
      color,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
    });
    const torus = new THREE.Mesh(new THREE.TorusGeometry(1, 0.22, 8, 24), mat);
    torus.rotation.x = Math.PI / 2;
    torus.position.set(pos.x, pos.y + 0.6, pos.z);
    this.scene.add(torus);
    this.bursts.push({
      mesh: torus,
      life: duration,
      maxLife: duration,
      growSpeed: maxRadius / duration,
      spinSpeed: 4,
    });
  }

  public spawnIceSpikes(pos: THREE.Vector3) {
    const group = new THREE.Group();
    group.position.copy(pos);
    const mat = new THREE.MeshStandardMaterial({
      color: '#bae6fd',
      emissive: '#0284c7',
      emissiveIntensity: 0.6,
      transparent: true,
      opacity: 0.9,
      roughness: 0.15,
    });
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * Math.PI * 2;
      const dist = i === 0 ? 0 : 2.1;
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.45, 3.4, 5), mat);
      spike.position.set(Math.cos(a) * dist, 1.5, Math.sin(a) * dist);
      spike.rotation.z = (Math.random() - 0.5) * 0.25;
      group.add(spike);
    }
    this.scene.add(group);
    this.bursts.push({ mesh: group, life: 1.05, maxLife: 1.05, growSpeed: 0.35 });
  }

  public spawnMeteor(targetPos: THREE.Vector3) {
    const mat = new THREE.MeshStandardMaterial({
      color: '#ff5500',
      emissive: '#fb923c',
      emissiveIntensity: 1.5,
      roughness: 0.3,
    });
    const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(1.75, 0), mat);
    rock.position.set(targetPos.x, targetPos.y + 24, targetPos.z);
    this.scene.add(rock);
    this.bursts.push({
      mesh: rock,
      life: 0.75,
      maxLife: 0.75,
      growSpeed: 0,
      fallSpeed: 32,
      targetY: targetPos.y,
    });
  }

  public spawnLightningPillar(targetPos: THREE.Vector3) {
    const mat = new THREE.MeshBasicMaterial({
      color: '#fef08a',
      transparent: true,
      opacity: 0.95,
    });
    const bolt = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.55, 22, 6), mat);
    bolt.position.set(targetPos.x, targetPos.y + 11, targetPos.z);
    this.scene.add(bolt);
    this.bursts.push({ mesh: bolt, life: 0.32, maxLife: 0.32, growSpeed: 0.5 });
  }

  public spawnChainBeam(from: THREE.Vector3, to: THREE.Vector3) {
    const dist = from.distanceTo(to);
    if (dist < 0.2) return;
    const mat = new THREE.MeshBasicMaterial({ color: '#fde047', transparent: true, opacity: 0.95 });
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, dist, 5), mat);
    beam.position.copy(from).lerp(to, 0.5);
    beam.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), to.clone().sub(from).normalize());
    this.scene.add(beam);
    this.bursts.push({ mesh: beam, life: 0.28, maxLife: 0.28, growSpeed: 0 });
  }

  public setFrozenShield(active: boolean, playerPos: THREE.Vector3, time: number) {
    if (active) {
      if (!this.shieldGroup) {
        this.shieldGroup = new THREE.Group();
        const shardMat = new THREE.MeshStandardMaterial({
          color: '#7dd3fc',
          emissive: '#0284c7',
          emissiveIntensity: 0.75,
          transparent: true,
          opacity: 0.8,
        });
        for (let i = 0; i < 6; i++) {
          const a = (i / 6) * Math.PI * 2;
          const shard = new THREE.Mesh(new THREE.OctahedronGeometry(0.32, 0), shardMat);
          shard.position.set(Math.cos(a) * 1.45, 1.15, Math.sin(a) * 1.45);
          this.shieldGroup.add(shard);
        }
        this.scene.add(this.shieldGroup);
      }
      this.shieldGroup.position.copy(playerPos);
      this.shieldGroup.rotation.y = time * 2.8;
    } else if (this.shieldGroup) {
      this.scene.remove(this.shieldGroup);
      this.shieldGroup = null;
    }
  }

  public update(dt: number) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= dt;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;
      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.projectiles.splice(i, 1);
      }
    }

    for (let i = this.bursts.length - 1; i >= 0; i--) {
      const b = this.bursts[i];
      b.life -= dt;
      if (b.growSpeed > 0) {
        b.mesh.scale.addScalar(b.growSpeed * dt);
      }
      if (b.spinSpeed) {
        b.mesh.rotation.z += b.spinSpeed * dt;
      }
      if (b.fallSpeed && b.targetY !== undefined) {
        b.mesh.position.y = Math.max(b.targetY, b.mesh.position.y - b.fallSpeed * dt);
      }
      b.mesh.traverse((o) => {
        const m = (o as THREE.Mesh).material;
        if (m && !Array.isArray(m) && m.transparent) {
          m.opacity = Math.max(0, b.life / b.maxLife);
        }
      });
      if (b.life <= 0) {
        if (b.fallSpeed && b.targetY !== undefined) {
          this.spawnRingBurst(new THREE.Vector3(b.mesh.position.x, b.targetY, b.mesh.position.z), '#f97316', 9, 0.55);
        }
        this.scene.remove(b.mesh);
        this.bursts.splice(i, 1);
      }
    }
  }

  public removeProjectileAt(idx: number) {
    const p = this.projectiles[idx];
    if (p) {
      this.scene.remove(p.mesh);
      this.projectiles.splice(idx, 1);
    }
  }
}
