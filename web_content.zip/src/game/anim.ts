// Pose-based procedural animation data + move tables
export type Pose = Record<string, number>;

// Conventions (all pivots use Euler order YXZ, character faces +Z, character's LEFT is +X):
//  x = swing (negative = forward for arms/legs), z = abduction (left +, right -), y = sweep
export const KEYS = [
  'ry', 'cr', 'tx', 'ty', 'tz', 'hx', 'hy',
  'lsx', 'lsy', 'lsz', 'lex', 'rsx', 'rsy', 'rsz', 'rex',
  'lhx', 'lhy', 'lhz', 'lkx', 'rhx', 'rhy', 'rhz', 'rkx',
  'lfx', 'rfx', 'bx', 'bz', 'bs', 'by',
] as const;

const zero = (): Pose => {
  const o: Pose = {};
  for (const k of KEYS) o[k] = 0;
  return o;
};

export const GUARD: Pose = {
  ...zero(),
  ry: -0.35, cr: 0.25, tx: 0.1, ty: 0.3, hy: 0.05,
  lsx: -1.0, lsz: 0.12, lex: -1.9,
  rsx: -0.85, rsz: -0.12, rex: -2.0,
  lhx: -0.35, lhz: 0.08, lkx: 0.1,
  rhx: 0.3, rhz: -0.1, rkx: 0.15,
};

export const P = (o: Pose, base: Pose = GUARD): Pose => ({ ...base, ...o });

export const smooth = (x: number) => x * x * (3 - 2 * x);

export function samplePose(keys: [number, Pose][], t: number, out: Pose) {
  if (t <= keys[0][0]) {
    Object.assign(out, keys[0][1]);
    return;
  }
  const last = keys[keys.length - 1];
  if (t >= last[0]) {
    Object.assign(out, last[1]);
    return;
  }
  let i = 0;
  while (i < keys.length - 2 && t > keys[i + 1][0]) i++;
  const a = keys[i], b = keys[i + 1];
  const f = smooth((t - a[0]) / (b[0] - a[0]));
  for (const k of KEYS) out[k] = a[1][k] + (b[1][k] - a[1][k]) * f;
}

export interface Move {
  id: string;
  name: string;
  keys: [number, Pose][];
  dur: number;
  hit: [number, number];
  cancel: number;
  dmg: number;
  reach: number;
  arc: number;
  kb: number;
  stun: number;
  kd?: boolean;
  cost: number;
  lunge?: [number, number, number];
  heavy?: boolean;
  special?: boolean;
  limb: 'lh' | 'rh' | 'lf' | 'rf';
}

export type MoveSet = Record<string, Move>;

// ---------- Static poses ----------
export const BLOCK = P({
  cr: 0.38, tx: 0.22, ty: 0.15, hx: 0.25,
  lsx: -1.25, lsy: -0.5, lsz: 0.0, lex: -2.5,
  rsx: -1.25, rsy: 0.5, rsz: 0.0, rex: -2.5,
});

export const HIT_LIGHT = P({
  cr: 0.3, tx: -0.3, ty: 0.35, hx: -0.4, ry: -0.2,
  lsx: -0.6, lsz: 0.4, lex: -1.2, rsx: -0.5, rsz: -0.4, rex: -1.1,
});

export const HIT_HEAVY = P({
  cr: 0.4, tx: -0.65, ty: 0.5, hx: -0.6, bx: -0.2, ry: -0.1,
  lsx: -0.2, lsz: 0.9, lex: -0.5, rsx: -0.1, rsz: -0.9, rex: -0.4,
  lhx: -0.2, rhx: 0.3,
});

const LIE = P({
  by: -0.8, bx: -1.5708, cr: 0, tx: 0, ty: 0, ry: 0, hx: -0.15,
  lsx: -0.1, lsz: 0.7, lex: -0.4, rsx: -0.2, rsz: -0.8, rex: -0.3,
  lhx: -0.1, lhz: 0.15, lkx: 0.25, rhx: -0.25, rhz: -0.25, rkx: 0.1,
});

export const KNOCK_KEYS: [number, Pose][] = [
  [0, HIT_HEAVY],
  [0.2, P({ ...HIT_HEAVY, bx: -0.9, by: -0.3, lsz: 1.2, rsz: -1.2, lhx: -0.5, rhx: 0.5, cr: 0.2 })],
  [0.45, LIE],
  [1.25, LIE],
  [1.55, P({ ...LIE, bx: -0.95, by: -0.6, tx: 0.7, lhx: -0.9, lkx: 1.5, rhx: -0.7, rkx: 1.3, lsx: 0.2, rsx: 0.2, lsz: 0.4, rsz: -0.4, lex: -0.2, rex: -0.2 })],
  [1.85, P({ cr: 0.85, tx: 0.55, ty: 0, ry: 0, lsx: -0.9, lex: -0.8, rsx: -0.5, rex: -1.0, lhx: -0.3, rhx: 0.2 })],
  [2.1, GUARD],
];
export const KNOCK_DUR = 2.1;
export const DEAD_T = 0.5;

export const WIN_LEON = P({
  cr: 0.05, tx: -0.05, ty: 0, ry: 0, hx: -0.15,
  rsx: -2.9, rsz: -0.25, rex: -0.4, lsx: -0.1, lsz: 0.25, lex: -0.5,
  lhx: -0.1, rhx: 0.1,
});
export const WIN_ADA = P({
  cr: 0.08, tx: -0.08, ty: 0, ry: -0.2, hx: -0.1, hy: 0.25, tz: 0.12,
  rsx: -0.4, rsz: -0.5, rex: -1.8, lsx: -2.4, lsz: 0.3, lex: -0.6,
  lhx: -0.3, lhz: 0.15, rhx: 0.25, rhz: -0.1,
});

// ---------- Moves ----------
export function buildMoves(id: 'leon' | 'ada'): MoveSet {
  const leon = id === 'leon';

  const lp1: Move = {
    id: 'lp1', name: 'Jab', dur: 0.34, hit: [0.1, 0.19], cancel: 0.2, dmg: 6, reach: 1.4, arc: 0.75,
    kb: 0.25, stun: 0.34, cost: 5, limb: 'lh',
    keys: [
      [0, GUARD],
      [0.06, P({ lsx: -0.9, lex: -2.3, ty: 0.15, tx: 0.12 })],
      [0.12, P({ lsx: -1.52, lsz: 0.02, lex: -0.12, ty: 0.65, tx: 0.2, ry: -0.2 })],
      [0.19, P({ lsx: -1.52, lsz: 0.02, lex: -0.15, ty: 0.65, tx: 0.2, ry: -0.2 })],
      [0.34, GUARD],
    ],
  };
  const lp2: Move = {
    id: 'lp2', name: 'Cross', dur: 0.4, hit: [0.11, 0.2], cancel: 0.23, dmg: 7, reach: 1.45, arc: 0.75,
    kb: 0.35, stun: 0.36, cost: 6, limb: 'rh',
    keys: [
      [0, GUARD],
      [0.07, P({ rsx: -0.7, rex: -2.3, ty: 0.5, tx: 0.12, cr: 0.3 })],
      [0.13, P({ rsx: -1.55, rsz: -0.02, rex: -0.1, ty: -0.55, tx: 0.25, ry: 0.0, cr: 0.3 })],
      [0.2, P({ rsx: -1.55, rsz: -0.02, rex: -0.1, ty: -0.55, tx: 0.25, ry: 0.0, cr: 0.3 })],
      [0.4, GUARD],
    ],
  };

  const lp3: Move = leon
    ? {
        id: 'lp3', name: 'Uppercut', dur: 0.6, hit: [0.2, 0.3], cancel: 0.42, dmg: 10, reach: 1.4, arc: 0.7,
        kb: 1.9, stun: 0.5, kd: true, cost: 9, limb: 'rh', lunge: [0.1, 0.24, 3.2],
        keys: [
          [0, GUARD],
          [0.12, P({ cr: 0.75, tx: 0.35, ty: 0.6, rsx: 0.4, rex: -0.7, rsz: -0.1, ry: -0.1 })],
          [0.24, P({ cr: 0.2, tx: -0.12, ty: -0.7, rsx: -2.7, rex: -0.5, by: 0.05, ry: 0.2 })],
          [0.34, P({ cr: 0.2, tx: -0.12, ty: -0.7, rsx: -2.7, rex: -0.5, by: 0.05, ry: 0.2 })],
          [0.6, GUARD],
        ],
      }
    : {
        id: 'lp3', name: 'High Kick', dur: 0.62, hit: [0.2, 0.32], cancel: 0.44, dmg: 10, reach: 1.7, arc: 0.7,
        kb: 1.9, stun: 0.5, kd: true, cost: 9, limb: 'lf',
        keys: [
          [0, GUARD],
          [0.1, P({ lhx: -0.9, lkx: 1.5, cr: 0.3, tx: 0.0 })],
          [0.24, P({ lhx: -2.25, lkx: 0.1, tx: -0.55, cr: 0.12, lsx: -0.3, rsx: -0.5, rsz: -0.8, lsz: 0.8, rex: -0.8, lex: -0.8, lfx: 0.5 })],
          [0.36, P({ lhx: -2.25, lkx: 0.1, tx: -0.55, cr: 0.12, lsx: -0.3, rsx: -0.5, rsz: -0.8, lsz: 0.8, rex: -0.8, lex: -0.8, lfx: 0.5 })],
          [0.62, GUARD],
        ],
      };

  const hp: Move = leon
    ? {
        id: 'hp', name: 'Overhand', dur: 0.72, hit: [0.29, 0.39], cancel: 0.52, dmg: 15, reach: 1.55, arc: 0.8,
        kb: 1.3, stun: 0.55, cost: 15, heavy: true, limb: 'rh', lunge: [0.2, 0.34, 2.6],
        keys: [
          [0, GUARD],
          [0.2, P({ rsx: 0.5, rsy: -0.3, rex: -1.7, ty: 0.95, tx: 0.1, cr: 0.45, lsx: -1.2 })],
          [0.31, P({ rsx: -1.65, rsy: 0.0, rex: -0.1, ty: -0.9, tx: 0.5, cr: 0.35, lsx: -0.6, lsz: 0.5 })],
          [0.42, P({ rsx: -1.65, rsy: 0.0, rex: -0.1, ty: -0.9, tx: 0.5, cr: 0.35, lsx: -0.6, lsz: 0.5 })],
          [0.72, GUARD],
        ],
      }
    : {
        id: 'hp', name: 'Elbow Strike', dur: 0.66, hit: [0.26, 0.36], cancel: 0.48, dmg: 14, reach: 1.5, arc: 0.8,
        kb: 1.3, stun: 0.55, cost: 14, heavy: true, limb: 'rh', lunge: [0.16, 0.32, 3.2],
        keys: [
          [0, GUARD],
          [0.18, P({ rsx: -0.6, rsy: -0.6, rex: -2.6, ty: 0.8, tx: 0.2, cr: 0.5, lsx: -1.3 })],
          [0.28, P({ rsx: -1.5, rsy: 0.35, rex: -2.55, ty: -0.85, tx: 0.45, cr: 0.4, lsx: -0.8 })],
          [0.4, P({ rsx: -1.5, rsy: 0.35, rex: -2.55, ty: -0.85, tx: 0.45, cr: 0.4, lsx: -0.8 })],
          [0.66, GUARD],
        ],
      };

  const k1: Move = {
    id: 'k1', name: 'Front Kick', dur: 0.52, hit: [0.19, 0.29], cancel: 0.34, dmg: 9, reach: leon ? 1.7 : 1.8, arc: 0.7,
    kb: 0.8, stun: 0.4, cost: 9, limb: 'rf',
    keys: [
      [0, GUARD],
      [0.1, P({ rhx: -0.9, rkx: 1.7, tx: 0.0, cr: 0.32 })],
      [0.21, P({ rhx: -1.55, rkx: 0.08, tx: -0.3, cr: 0.2, lsx: -1.2, rfx: 0.2 })],
      [0.3, P({ rhx: -1.55, rkx: 0.08, tx: -0.3, cr: 0.2, lsx: -1.2, rfx: 0.2 })],
      [0.52, GUARD],
    ],
  };

  const k2: Move = leon
    ? {
        id: 'k2', name: 'Roundhouse', dur: 0.7, hit: [0.25, 0.35], cancel: 0.5, dmg: 12, reach: 1.75, arc: 0.9,
        kb: 2.0, stun: 0.5, kd: true, cost: 12, heavy: true, limb: 'lf',
        keys: [
          [0, GUARD],
          [0.14, P({ lhx: -0.9, lkx: 1.7, lhy: -0.4, lhz: 0.3, tz: -0.2, cr: 0.3 })],
          [0.27, P({ lhx: -1.45, lhy: 0.7, lhz: 0.2, lkx: 0.15, tz: -0.6, ry: 0.6, cr: 0.2, lsx: -0.5, lsz: 0.8 })],
          [0.37, P({ lhx: -1.45, lhy: 0.7, lhz: 0.2, lkx: 0.15, tz: -0.6, ry: 0.6, cr: 0.2, lsx: -0.5, lsz: 0.8 })],
          [0.7, GUARD],
        ],
      }
    : {
        id: 'k2', name: 'Heel Spin Kick', dur: 0.78, hit: [0.3, 0.42], cancel: 0.58, dmg: 12, reach: 1.85, arc: 1.0,
        kb: 2.0, stun: 0.5, kd: true, cost: 12, heavy: true, limb: 'rf', lunge: [0.2, 0.4, 1.8],
        keys: [
          [0, GUARD],
          [0.16, P({ cr: 0.5, tx: 0.3, bs: 0, rsx: -0.6, lsx: -0.6 })],
          [0.36, P({ cr: 0.3, tx: 0.1, bs: -3.9, rhx: -1.3, rhy: -0.3, rkx: 0.15, rhz: -0.35, lsx: -0.3, lsz: 0.9, rsx: -0.3, rsz: -0.9, tz: 0.2 })],
          [0.46, P({ cr: 0.3, tx: 0.1, bs: -6.2832, rhx: -1.2, rkx: 0.2, lsz: 0.7, rsz: -0.7, lsx: -0.5, rsx: -0.5 })],
          [0.78, P({ ...GUARD, bs: -6.2832 })],
        ],
      };

  const sp: Move = leon
    ? {
        id: 'sp', name: 'Rushing Roundhouse', dur: 1.1, hit: [0.4, 0.6], cancel: 99, dmg: 26, reach: 1.95, arc: 1.1,
        kb: 3.2, stun: 0.6, kd: true, cost: 15, heavy: true, special: true, limb: 'rf', lunge: [0.18, 0.55, 5.2],
        keys: [
          [0, GUARD],
          [0.22, P({ cr: 0.55, tx: 0.3, rsx: -0.4, lsx: -0.5, ry: -0.7 })],
          [0.38, P({ cr: 0.3, tx: 0.15, bs: -3.2, rhx: -1.35, rhy: -0.3, rkx: 0.2, rhz: -0.4, lsz: 0.9, rsz: -0.9, lsx: -0.3, rsx: -0.3 })],
          [0.56, P({ cr: 0.3, tx: 0.1, bs: -6.2832, rhx: -1.35, rhy: 0.2, rkx: 0.15, rhz: -0.3, lsz: 0.8, rsz: -0.8, lsx: -0.3, rsx: -0.3 })],
          [0.78, P({ ...GUARD, cr: 0.5, bs: -6.2832 })],
          [1.1, P({ ...GUARD, bs: -6.2832 })],
        ],
      }
    : {
        id: 'sp', name: 'Aerial Axe Flip', dur: 1.15, hit: [0.42, 0.62], cancel: 99, dmg: 24, reach: 2.0, arc: 1.1,
        kb: 3.2, stun: 0.6, kd: true, cost: 15, heavy: true, special: true, limb: 'rf', lunge: [0.2, 0.6, 4.6],
        keys: [
          [0, GUARD],
          [0.2, P({ cr: 0.7, tx: 0.4, lsx: 0.4, rsx: 0.4, lsz: 0.4, rsz: -0.4, ry: 0 })],
          [0.36, P({ by: 0.55, bx: 2.4, cr: 0.1, tx: 0, ty: 0, ry: 0, lsx: -2.5, rsx: -2.5, lex: -0.3, rex: -0.3, lhx: -0.6, lkx: 0.9, rhx: -2.1, rkx: 0.1 })],
          [0.52, P({ by: 0.65, bx: 4.4, cr: 0.1, tx: 0, ty: 0, ry: 0, lsx: -2.5, rsx: -2.5, lex: -0.3, rex: -0.3, lhx: -0.5, lkx: 0.9, rhx: -2.3, rkx: 0.05 })],
          [0.7, P({ by: 0.2, bx: 6.2832, cr: 0.5, tx: 0.2, ty: 0, ry: 0, rhx: -1.0, rkx: 0.9, lhx: -0.8, lkx: 1.0 })],
          [0.88, P({ ...GUARD, cr: 0.7, bx: 6.2832, tx: 0.4 })],
          [1.15, P({ ...GUARD, bx: 6.2832 })],
        ],
      };

  return { lp1, lp2, lp3, hp, k1, k2, sp };
}

export const CHAINS: Record<string, string[]> = {
  punch: ['lp1', 'lp2', 'lp3'],
  heavy: ['hp'],
  kick: ['k1', 'k2'],
  special: ['sp'],
};
