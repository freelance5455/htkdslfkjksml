import { exportSave } from "../save";
import { BoneBtn, GhostBtn, Label, Panel, Shell, TopBar } from "../components/Shell";
import { useGame } from "../store";
import { useState } from "react";

export function Settings() {
  const save = useGame((s) => s.save);
  const go = useGame((s) => s.go);
  const setSettings = useGame((s) => s.setSettings);
  const importJson = useGame((s) => s.importJson);
  const wipe = useGame((s) => s.wipe);
  const toast = useGame((s) => s.toast);
  const [paste, setPaste] = useState("");

  return (
    <Shell bg="hall">
      <TopBar
        left={
          <div>
            <Label>System</Label>
            <h1 className="font-display text-3xl font-semibold">Settings</h1>
          </div>
        }
        right={<GhostBtn onClick={() => go("menu")}>Menu</GhostBtn>}
      />
      <div className="flex-1 overflow-y-auto p-4">
        <Panel className="max-w-xl space-y-5">
          <label className="block">
            <Label>Master</Label>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={save.settings.master}
              onChange={(e) => setSettings({ master: Number(e.target.value) })}
              className="mt-2 w-full"
            />
          </label>
          <label className="block">
            <Label>Effects</Label>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={save.settings.sfx}
              onChange={(e) => setSettings({ sfx: Number(e.target.value) })}
              className="mt-2 w-full"
            />
          </label>
          <label className="flex items-center justify-between gap-3 text-sm">
            Low memory mode
            <input
              type="checkbox"
              checked={save.settings.lowMemory}
              onChange={(e) => setSettings({ lowMemory: e.target.checked })}
            />
          </label>
          <label className="flex items-center justify-between gap-3 text-sm">
            Screen shake
            <input
              type="checkbox"
              checked={save.settings.shake}
              onChange={(e) => setSettings({ shake: e.target.checked })}
            />
          </label>
          <label className="flex items-center justify-between gap-3 text-sm">
            Reduced motion
            <input
              type="checkbox"
              checked={save.settings.reducedMotion}
              onChange={(e) => setSettings({ reducedMotion: e.target.checked })}
            />
          </label>
          <div className="flex flex-wrap gap-2">
            <BoneBtn
              onClick={async () => {
                await navigator.clipboard.writeText(exportSave(save));
              }}
            >
              Copy save
            </BoneBtn>
            <GhostBtn onClick={wipe}>Clear progress</GhostBtn>
          </div>
          <label className="block">
            <Label>Import save JSON</Label>
            <textarea
              value={paste}
              onChange={(e) => setPaste(e.target.value)}
              className="mt-2 h-24 w-full border border-line bg-elevated p-2 text-xs text-fg"
            />
          </label>
          <GhostBtn onClick={() => importJson(paste)}>Import</GhostBtn>
          {toast && <p className="text-xs text-muted">{toast}</p>}
          <p className="text-xs text-subtle">Progress stores on this device. Refresh keeps the campaign.</p>
        </Panel>
      </div>
    </Shell>
  );
}
