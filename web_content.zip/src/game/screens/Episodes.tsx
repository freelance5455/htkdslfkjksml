import { episodeMeta } from "../data/episodes";
import { BoneBtn, GhostBtn, Label, Shell, TopBar } from "../components/Shell";
import { useGame } from "../store";
import { cn } from "@/lib/utils";

export function Episodes() {
  const save = useGame((s) => s.save);
  const go = useGame((s) => s.go);
  const start = useGame((s) => s.startEpisode);
  const list = episodeMeta();

  return (
    <Shell bg="outpost">
      <TopBar
        left={
          <div>
            <Label>Chapter 1</Label>
            <h1 className="font-display text-3xl font-semibold">Episodes</h1>
          </div>
        }
        right={<GhostBtn onClick={() => go("menu")}>Menu</GhostBtn>}
      />
      <div className="flex-1 overflow-y-auto px-4 py-4 sm:px-6">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((ep) => {
            const locked = ep.id > save.unlockedEpisode;
            const done = save.completed.includes(ep.id);
            return (
              <button
                key={ep.id}
                type="button"
                disabled={locked}
                onClick={() => start(ep.id)}
                className={cn(
                  "border border-line bg-surface/85 p-4 text-left transition-colors duration-150",
                  locked ? "opacity-40" : "hover:border-line-strong",
                )}
                style={{ borderRadius: 14 }}
              >
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-[11px] uppercase tracking-[0.16em] text-muted">
                    {String(ep.id).padStart(2, "0")} · {ep.kind}
                  </span>
                  <span className="text-[11px] uppercase tracking-wider text-subtle">
                    {locked ? "Locked" : done ? "Complete" : "Open"}
                  </span>
                </div>
                <p className="mt-2 font-display text-xl font-semibold">{ep.title}</p>
                <p className="mt-1 text-xs text-muted">{ep.location}</p>
              </button>
            );
          })}
        </div>
        <div className="py-6">
          <BoneBtn onClick={() => start(save.currentEpisode)}>Resume current</BoneBtn>
        </div>
      </div>
    </Shell>
  );
}
