import { BoneBtn, GhostBtn, Label, Shell } from "../components/Shell";
import { useGame } from "../store";

const ITEMS = [
  { id: "continue", label: "Continue" },
  { id: "new", label: "New Game" },
  { id: "episodes", label: "Episodes" },
  { id: "squad", label: "Squad" },
  { id: "archive", label: "Archive" },
  { id: "settings", label: "Settings" },
] as const;

export function Menu() {
  const save = useGame((s) => s.save);
  const go = useGame((s) => s.go);
  const newGame = useGame((s) => s.newGame);
  const continueGame = useGame((s) => s.continueGame);
  const toast = useGame((s) => s.toast);

  return (
    <Shell bg="hall">
      <div className="flex flex-1 flex-col justify-between px-5 py-8 sm:px-10 sm:py-10">
        <div>
          <Label>Mayonin Chronicles</Label>
          <h1 className="mt-2 font-display text-5xl font-semibold tracking-tight text-fg sm:text-7xl">
            MAYONIN
          </h1>
          <p className="mt-3 max-w-md text-sm leading-relaxed text-muted">
            Connect · Build · Fight. Arden and the squad stand on the edge of a waiting world.
          </p>
        </div>

        <nav className="mt-10 grid max-w-sm gap-2">
          {ITEMS.map((item) => {
            const disabled = item.id === "continue" && !save.hasSave;
            return item.id === "new" ? (
              <BoneBtn key={item.id} onClick={newGame} className="w-full justify-center">
                {item.label}
              </BoneBtn>
            ) : (
              <GhostBtn
                key={item.id}
                disabled={disabled}
                className="w-full justify-start"
                onClick={() => {
                  if (item.id === "continue") continueGame();
                  else go(item.id as "episodes" | "squad" | "archive" | "settings");
                }}
              >
                {item.label}
              </GhostBtn>
            );
          })}
        </nav>

        <p className="mt-8 text-xs tracking-wide text-subtle">
          Manager Lv {save.managerLevel}
          {save.hasSave ? ` · Episode ${String(save.currentEpisode).padStart(2, "0")}` : " · No save"}
          {toast ? ` · ${toast}` : ""}
        </p>
      </div>
    </Shell>
  );
}
