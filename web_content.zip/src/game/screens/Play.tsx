import { CHAR_BY_ID } from "../data/characters";
import { DISC_BY_ID } from "../data/discoveries";
import { Portrait } from "../components/Portrait";
import { CinematicScene } from "../components/CinematicScene";
import { BoneBtn, GhostBtn, Label, Panel, Shell, TopBar } from "../components/Shell";
import { useGame } from "../store";
import type { Emotion } from "../types";
import { useEffect } from "react";
import { playVoice } from "../audio";

export function Play() {
  const play = useGame((s) => s.play);
  const save = useGame((s) => s.save);
  const go = useGame((s) => s.go);
  const advance = useGame((s) => s.advance);
  const choose = useGame((s) => s.choose);
  const explore = useGame((s) => s.explore);
  if (!play) return null;
  const stage = play.episode.stages[play.stageIndex];
  const ep = play.episode;

  return (
    <Shell bg={ep.bg}>
      <TopBar
        left={
          <div>
            <Label>
              Episode {String(ep.id).padStart(2, "0")} · {ep.kind}
            </Label>
            <h1 className="font-display text-2xl font-semibold sm:text-3xl">{ep.title}</h1>
          </div>
        }
        right={<GhostBtn onClick={() => go("menu")}>Menu</GhostBtn>}
      />
      <div className="flex flex-1 flex-col justify-end p-4 sm:p-6">
        {stage.type === "dialogue" && (
          <Dialogue
            speaker={stage.lines[play.lineIndex].speaker}
            emotion={stage.lines[play.lineIndex].emotion}
            text={stage.lines[play.lineIndex].text}
            page={`${play.lineIndex + 1}/${stage.lines.length}`}
            onNext={advance}
            background={ep.bg}
            participants={[...new Set(stage.lines.map((l) => l.speaker))].slice(0, 2)}
          />
        )}
        {stage.type === "cinematic" && (
          <CinematicScene background={stage.cinematic.background} onComplete={advance} />
        )}
        {stage.type === "choice" && (
          <Panel className="max-w-2xl">
            <Label>Decision</Label>
            <p className="mt-2 font-display text-2xl">{stage.prompt}</p>
            {play.choiceTaken ? (
              <div className="mt-4">
                <p className="text-sm leading-relaxed text-muted">
                  {stage.options.find((o) => o.id === play.choiceTaken)?.text}
                </p>
                <BoneBtn className="mt-4" onClick={advance}>
                  Continue
                </BoneBtn>
              </div>
            ) : (
              <div className="mt-4 grid gap-2">
                {stage.options.map((o) => (
                  <GhostBtn key={o.id} className="h-auto min-h-11 py-3 text-left" onClick={() => choose(o.id)}>
                    {o.label}
                  </GhostBtn>
                ))}
              </div>
            )}
          </Panel>
        )}
        {stage.type === "explore" && (
          <Panel className="max-w-2xl">
            <Label>{stage.location}</Label>
            <p className="mt-2 text-sm leading-relaxed">{stage.intro}</p>
            <div className="mt-4 grid gap-2 sm:grid-cols-2">
              {stage.nodes.map((n) => (
                <GhostBtn
                  key={n.id}
                  disabled={play.exploreUsed.includes(n.id)}
                  className="h-auto min-h-14 flex-col items-start py-3 text-left"
                  onClick={() => explore(n.id)}
                >
                  <span>{n.label}</span>
                  <span className="text-xs font-normal text-muted">{n.hint}</span>
                </GhostBtn>
              ))}
            </div>
            {play.exploreText && <p className="mt-4 text-sm leading-relaxed text-fg/90">{play.exploreText}</p>}
            <BoneBtn className="mt-4" onClick={advance} disabled={play.exploreUsed.length === 0}>
              Move on
            </BoneBtn>
          </Panel>
        )}
        {stage.type === "battle" && (
          <Panel className="max-w-xl">
            <Label>Engagement</Label>
            <h2 className="mt-1 font-display text-3xl">{stage.battle.title}</h2>
            <p className="mt-2 text-sm text-muted">
              {stage.battle.enemies.map((e) => `${e.variant} ${e.base.replace("-", " ")}`).join(" · ")}
            </p>
            <BoneBtn className="mt-5" onClick={advance}>
              Enter the field
            </BoneBtn>
          </Panel>
        )}
        {stage.type === "discovery" && (
          <Panel className="max-w-xl">
            <Label>New discovery</Label>
            <h2 className="mt-1 font-display text-3xl">{DISC_BY_ID[stage.discoveryId]?.name ?? stage.discoveryId}</h2>
            <p className="mt-3 text-sm leading-relaxed">{stage.text}</p>
            <BoneBtn className="mt-5" onClick={advance}>
              Add to Archive
            </BoneBtn>
          </Panel>
        )}
        {stage.type === "recruit" && (
          <Panel className="max-w-xl">
            <Label>New ally</Label>
            <h2 className="mt-1 font-display text-3xl">{CHAR_BY_ID[stage.characterId]?.name}</h2>
            <p className="mt-3 text-sm leading-relaxed">{stage.text}</p>
            <BoneBtn className="mt-5" onClick={advance}>
              Add to Squad
            </BoneBtn>
          </Panel>
        )}
        {stage.type === "reward" && (
          <Panel className="max-w-xl">
            <Label>After-action</Label>
            <h2 className="mt-1 font-display text-3xl">Recorded</h2>
            <ul className="mt-3 space-y-1 text-sm text-muted">
              <li>XP {stage.reward.xp}</li>
              <li>Marks {stage.reward.currency}</li>
              <li>Manager XP {stage.reward.managerXp}</li>
              {stage.reward.ally && <li>Ally: {CHAR_BY_ID[stage.reward.ally]?.name}</li>}
              {stage.reward.discovery && <li>Discovery: {DISC_BY_ID[stage.reward.discovery]?.name}</li>}
              {stage.reward.special && <li>Arden Special: {stage.reward.special}</li>}
            </ul>
            <p className="mt-2 text-xs text-subtle">Manager Lv {save.managerLevel}</p>
            <BoneBtn className="mt-5" onClick={advance}>
              Continue
            </BoneBtn>
          </Panel>
        )}
      </div>
    </Shell>
  );
}

function Dialogue({
  speaker,
  emotion,
  text,
  page,
  onNext,
  background,
  participants,
}: {
  speaker: string;
  emotion: Emotion;
  text: string;
  page: string;
  onNext: () => void;
  background: "hall" | "outpost" | "vault";
  participants: string[];
}) {
  const ch = Object.values(CHAR_BY_ID).find((c) => c.name === speaker);
  useEffect(() => {
    if (ch?.id) playVoice(ch.id);
    else if (speaker.toLowerCase().includes("father")) playVoice("father");
  }, [speaker, ch?.id]);
  const bgMap = { hall: "/game/bg/hall.jpg", outpost: "/game/bg/outpost.jpg", vault: "/game/bg/vault.jpg" };
  return (
    <button type="button" onClick={onNext} className="mayonin-dialogue-scene" style={{ backgroundImage: `url(${bgMap[background]})` }}>
      <div className="mayonin-scene-vignette" />
      <div className="mayonin-scene-figures">
        {participants.map((name, i) => {
          const pc = Object.values(CHAR_BY_ID).find((c) => c.name === name);
          const isActive = name === speaker;
          return (
            <div key={`${name}-${i}`} className={`mayonin-scene-figure ${i === 0 ? "left" : "right"} ${isActive ? "active" : "quiet"}`}>
              <Portrait name={name} mark={pc?.mark ?? name.slice(0, 1)} color={pc?.color ?? "#6b2424"} size="lg" emotion={isActive ? emotion : "calm"} />
              <span>{name}</span>
            </div>
          );
        })}
        {participants.length === 1 && <div className="mayonin-empty-actor" />}
      </div>
      <div className="mayonin-scene-dialogue-box">
        <div className="mayonin-dialogue-name">{speaker}</div>
        <div className="mayonin-dialogue-text">{text}</div>
        <div className="mayonin-dialogue-meta">{emotion.toUpperCase()} · {page} · TAP</div>
      </div>
    </button>
  );
}
