import { CHARACTERS } from "../data/characters";
import { ARCHIVE_CATEGORIES, DISCOVERIES } from "../data/discoveries";
import { ENEMIES, VARIANTS } from "../data/enemies";
import { GhostBtn, Label, Panel, Shell, TopBar } from "../components/Shell";
import { useGame } from "../store";
import { useState } from "react";
import type { DiscoveryDef } from "../types";

export function Archive() {
  const save = useGame((s) => s.save);
  const go = useGame((s) => s.go);
  const [cat, setCat] = useState<(typeof ARCHIVE_CATEGORIES)[number]>("characters");
  const discs = DISCOVERIES.filter((d) => d.category === cat);

  return (
    <Shell bg="vault">
      <TopBar
        left={
          <div>
            <Label>Records</Label>
            <h1 className="font-display text-3xl font-semibold">Archive</h1>
          </div>
        }
        right={<GhostBtn onClick={() => go("menu")}>Menu</GhostBtn>}
      />
      <div className="flex-1 overflow-y-auto p-4">
        <div className="flex gap-2 overflow-x-auto pb-3">
          {ARCHIVE_CATEGORIES.map((c) => (
            <GhostBtn key={c} className={cat === c ? "border-bone" : ""} onClick={() => setCat(c)}>
              {c}
            </GhostBtn>
          ))}
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          {discs.map((d) => (
            <Entry key={d.id} d={d} known={save.discoveries.includes(d.id)} />
          ))}
          {cat === "allies" &&
            CHARACTERS.filter((c) => c.playable).map((c) => (
              <Panel key={c.id}>
                <Label>{save.recruited.includes(c.id) ? "Ally" : "Unknown"}</Label>
                <h2 className="mt-1 font-display text-2xl">{save.recruited.includes(c.id) ? c.name : "[ UNKNOWN ]"}</h2>
                {save.recruited.includes(c.id) && <p className="mt-2 text-sm text-muted">{c.lore}</p>}
              </Panel>
            ))}
          {cat === "enemies" &&
            ENEMIES.map((e) => {
              const known = save.enemyVariants.some((k) => k.startsWith(e.id));
              return (
                <Panel key={e.id}>
                  <Label>{known ? e.classification : "Unlogged"}</Label>
                  <h2 className="mt-1 font-display text-2xl">{known ? e.name : "[ UNKNOWN ]"}</h2>
                  {known && (
                    <>
                      <p className="mt-2 text-sm text-muted">{e.lore}</p>
                      <p className="mt-2 text-xs text-subtle">Weakness: {e.weakness}</p>
                      <p className="text-xs text-subtle">
                        Variants:{" "}
                        {save.enemyVariants
                          .filter((k) => k.startsWith(e.id))
                          .map((k) => VARIANTS[k.split(":")[1] as keyof typeof VARIANTS]?.label ?? k)
                          .join(", ") || "Standard"}
                      </p>
                    </>
                  )}
                </Panel>
              );
            })}
          {cat === "abilities" &&
            CHARACTERS.filter((c) => save.recruited.includes(c.id) || c.id === "arden" || c.id === "seraphine").flatMap((c) =>
              c.abilities.map((a) => (
                <Panel key={a.id}>
                  <Label>{c.name}</Label>
                  <h2 className="font-display text-2xl">{a.name}</h2>
                  <p className="mt-1 text-sm text-muted">{a.desc}</p>
                </Panel>
              )),
            )}
          {cat === "powers" &&
            CHARACTERS.filter((c) => save.recruited.includes(c.id) || c.id === "arden" || c.id === "seraphine").map((c) => (
              <Panel key={c.power.id}>
                <Label>{c.name}</Label>
                <h2 className="font-display text-2xl">{c.power.name}</h2>
                <p className="mt-1 text-sm italic text-muted">“{c.power.voice}”</p>
                <p className="mt-2 text-sm text-muted">{c.power.desc}</p>
              </Panel>
            ))}
        </div>
      </div>
    </Shell>
  );
}

function Entry({ d, known }: { d: DiscoveryDef; known: boolean }) {
  return (
    <Panel>
      <Label>{known ? `Episode ${String(d.episode).padStart(2, "0")}` : "Sealed"}</Label>
      <h2 className="mt-1 font-display text-2xl">{known ? d.name : "[ UNKNOWN ]"}</h2>
      {known ? (
        <>
          <p className="mt-2 text-sm leading-relaxed text-fg/90">{d.lore}</p>
          <p className="mt-2 text-xs text-muted">Effects: {d.effects}</p>
        </>
      ) : (
        <p className="mt-2 text-sm text-muted">Not yet recorded.</p>
      )}
    </Panel>
  );
}
