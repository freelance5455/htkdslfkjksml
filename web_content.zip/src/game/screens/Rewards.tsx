import { BoneBtn, Label, Panel, Shell } from "../components/Shell";
import { useGame } from "../store";

export function Rewards() {
  const save = useGame((s) => s.save);
  const toast = useGame((s) => s.toast);
  const go = useGame((s) => s.go);
  return (
    <Shell bg="hall">
      <div className="flex flex-1 items-center justify-center p-6">
        <Panel className="max-w-md">
          <Label>Autosaved</Label>
          <h1 className="mt-1 font-display text-4xl font-semibold">Episode complete</h1>
          <p className="mt-3 text-sm leading-relaxed text-muted">{toast}</p>
          <ul className="mt-4 space-y-1 text-sm text-muted">
            <li>Manager Lv {save.managerLevel}</li>
            <li>Marks {save.currency}</li>
            <li>Unlocked through {String(save.unlockedEpisode).padStart(2, "0")}</li>
            <li>Discoveries {save.discoveries.length}</li>
          </ul>
          <div className="mt-5 flex gap-2">
            <BoneBtn onClick={() => go("episodes")}>Episodes</BoneBtn>
            <button
              type="button"
              className="h-11 border border-line px-4 text-sm"
              onClick={() => go("menu")}
            >
              Menu
            </button>
          </div>
        </Panel>
      </div>
    </Shell>
  );
}
