import { CHAR_BY_ID, CHARACTERS } from "../data/characters";
import { ITEM_BY_ID } from "../data/discoveries";
import { Portrait } from "../components/Portrait";
import { BoneBtn, GhostBtn, Label, Panel, Shell, TopBar } from "../components/Shell";
import { useGame } from "../store";
import { useState } from "react";
import type { Formation } from "../types";

const FORMS: Formation[] = ["front", "middle", "rear"];

export function Squad() {
  const save = useGame((s) => s.save);
  const go = useGame((s) => s.go);
  const rest = useGame((s) => s.restSquad);
  const setFormation = useGame((s) => s.setFormation);
  const equip = useGame((s) => s.equip);
  const toast = useGame((s) => s.toast);
  const [sel, setSel] = useState(save.recruited[0] ?? "rook");
  const ch = CHAR_BY_ID[sel];
  const fs = save.fighters[sel];
  if (!ch || !fs) return null;

  return (
    <Shell bg="hall">
      <TopBar
        left={
          <div>
            <Label>Ashline</Label>
            <h1 className="font-display text-3xl font-semibold">Squad</h1>
          </div>
        }
        right={<GhostBtn onClick={() => go("menu")}>Menu</GhostBtn>}
      />
      <div className="grid flex-1 gap-3 overflow-y-auto p-4 lg:grid-cols-[220px_1fr]">
        <div className="flex gap-2 overflow-x-auto lg:flex-col">
          {save.recruited.map((id) => {
            const c = CHAR_BY_ID[id];
            if (!c) return null;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setSel(id)}
                className="flex min-w-40 items-center gap-2 border border-line bg-surface/80 p-2 text-left"
                style={{ borderRadius: 8, borderColor: sel === id ? "var(--color-bone)" : undefined }}
              >
                <Portrait name={c.name} mark={c.mark} color={c.color} size="sm" />
                <span>
                  <span className="block text-sm font-medium">{c.name}</span>
                  <span className="block text-[11px] uppercase tracking-wider text-muted">{c.role}</span>
                </span>
              </button>
            );
          })}
        </div>
        <Panel>
          <div className="flex flex-wrap items-start gap-4">
            <Portrait name={ch.name} mark={ch.mark} color={ch.color} size="lg" />
            <div className="min-w-0 flex-1">
              <h2 className="font-display text-3xl font-semibold">{ch.name}</h2>
              <p className="text-sm text-muted">
                {ch.role} · {ch.weapon} · Lv {fs.level} · Trust {fs.trust}
              </p>
              <p className="mt-3 text-sm leading-relaxed text-fg/90">{ch.lore}</p>
              <p className="mt-2 text-sm italic text-muted">{ch.personality}</p>
            </div>
          </div>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div>
              <Label>Abilities</Label>
              <ul className="mt-2 space-y-2">
                {ch.abilities.map((a) => (
                  <li key={a.id} className="border border-line p-2" style={{ borderRadius: 8 }}>
                    <p className="text-sm font-medium">{a.name}</p>
                    <p className="text-xs text-muted">{a.desc}</p>
                  </li>
                ))}
                <li className="border border-line p-2" style={{ borderRadius: 8 }}>
                  <p className="text-sm font-medium">{ch.power.name}</p>
                  <p className="text-xs text-muted">“{ch.power.voice}”</p>
                </li>
              </ul>
            </div>
            <div>
              <Label>Formation</Label>
              <div className="mt-2 flex gap-2">
                {FORMS.map((f) => (
                  <GhostBtn key={f} className={fs.formation === f ? "border-bone" : ""} onClick={() => setFormation(sel, f)}>
                    {f}
                  </GhostBtn>
                ))}
              </div>
              <Label>Equipment</Label>
              <div className="mt-2 space-y-2">
                {(["weapon", "artifact", "utility", "defensive"] as const).map((slot) => (
                  <label key={slot} className="block text-xs text-muted">
                    {slot}
                    <select
                      className="mt-1 h-10 w-full border border-line bg-elevated px-2 text-sm text-fg"
                      value={fs.equipment[slot] ?? ""}
                      onChange={(e) => equip(sel, slot, e.target.value || undefined)}
                    >
                      <option value="">None</option>
                      {save.inventory.map((it) => {
                        const def = ITEM_BY_ID[it.id];
                        if (!def || (def.slot !== slot && def.slot !== "material")) return null;
                        if (def.slot === "material") return null;
                        return (
                          <option key={it.id} value={it.id}>
                            {def.name}
                          </option>
                        );
                      })}
                    </select>
                  </label>
                ))}
              </div>
              <p className="mt-4 text-xs text-subtle">
                Overload drawback: {ch.overloadDrawback}
              </p>
            </div>
          </div>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <BoneBtn onClick={rest}>Rest line (15 marks)</BoneBtn>
            <span className="text-xs text-muted">Marks {save.currency}{toast ? ` · ${toast}` : ""}</span>
          </div>
          <p className="mt-4 text-xs text-subtle">
            Mentors and commanders: {CHARACTERS.filter((c) => !c.playable).map((c) => c.name).join(", ")} — present when the story requires them.
          </p>
        </Panel>
      </div>
    </Shell>
  );
}
