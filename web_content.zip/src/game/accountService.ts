import { User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { SKIN_MAP } from './skins';
import { FriendRecord, PlayerProfile, PublicPlayerProfile, SkinId } from './types';

const STORAGE_PLAYER_CODE_KEY = 'rk_player_code_v1';
const STORAGE_LOCAL_FRIENDS_KEY = 'rk_local_friends_v1';

function generatePlayerCode(): string {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  let suffix = '';
  for (let i = 0; i < 6; i++) {
    suffix += chars[Math.floor(Math.random() * chars.length)];
  }
  return `RK${suffix}`;
}

export function normalizePlayerCode(raw: string): string {
  return raw.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

export function formatPlayerCodeDisplay(code: string): string {
  const clean = normalizePlayerCode(code);
  if (clean.length === 8 && clean.startsWith('RK')) {
    return `RK-${clean.slice(2)}`;
  }
  return clean;
}

export function getOrCreateLocalPlayerCode(): string {
  try {
    const existing = localStorage.getItem(STORAGE_PLAYER_CODE_KEY);
    if (existing && /^RK[0-9A-Z]{6}$/.test(existing)) {
      return existing;
    }
    const created = generatePlayerCode();
    localStorage.setItem(STORAGE_PLAYER_CODE_KEY, created);
    return created;
  } catch {
    return generatePlayerCode();
  }
}

export function saveLocalPlayerCode(code: string): void {
  const clean = normalizePlayerCode(code);
  if (!/^RK[0-9A-Z]{6}$/.test(clean)) return;
  try {
    localStorage.setItem(STORAGE_PLAYER_CODE_KEY, clean);
  } catch {
    // Ignore storage errors
  }
}

export function loadLocalFriends(): FriendRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_LOCAL_FRIENDS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as FriendRecord[]) : [];
  } catch {
    return [];
  }
}

export function saveLocalFriends(friends: FriendRecord[]): void {
  try {
    localStorage.setItem(STORAGE_LOCAL_FRIENDS_KEY, JSON.stringify(friends));
  } catch {
    // Ignore storage errors
  }
}

function safeSkinId(raw: unknown): SkinId {
  if (typeof raw === 'string' && raw in SKIN_MAP) {
    return raw as SkinId;
  }
  return 'kurdish_sun';
}

function clampString(raw: string, fallback: string, maxLen: number): string {
  const trimmed = raw.trim().slice(0, maxLen);
  return trimmed.length > 0 ? trimmed : fallback;
}

export async function ensureCloudAccount(
  user: User,
  localState: {
    displayName: string;
    skinId: SkinId;
    profile: PlayerProfile;
    bestMass: number;
    currentRoom: string;
    online: boolean;
  }
): Promise<{
  publicProfile: PublicPlayerProfile;
  mergedXp: number;
  mergedUnlockedSkins: SkinId[];
}> {
  const playerPath = `players/${user.uid}`;
  const privatePath = `usersPrivate/${user.uid}`;
  const safeName = clampString(
    localState.displayName || user.displayName || 'Player',
    'Player',
    24
  );

  let existingPlayerData: Record<string, unknown> | null = null;
  try {
    const snap = await getDoc(doc(db, 'players', user.uid));
    if (snap.exists()) {
      existingPlayerData = snap.data() as Record<string, unknown>;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, playerPath);
  }

  let existingPrivateData: Record<string, unknown> | null = null;
  try {
    const privSnap = await getDoc(doc(db, 'usersPrivate', user.uid));
    if (privSnap.exists()) {
      existingPrivateData = privSnap.data() as Record<string, unknown>;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, privatePath);
  }

  if (existingPlayerData) {
    const cloudCode =
      typeof existingPlayerData.playerCode === 'string'
        ? existingPlayerData.playerCode
        : getOrCreateLocalPlayerCode();
    saveLocalPlayerCode(cloudCode);

    const cloudCoins = Math.max(
      localState.profile.coins,
      Number(existingPlayerData.coins) || 0
    );
    const cloudDna = Math.max(
      localState.profile.dna,
      Number(existingPlayerData.dna) || 0
    );
    const cloudLevel = Math.max(
      localState.profile.level,
      Number(existingPlayerData.level) || 1
    );
    const cloudScore = Math.max(
      localState.profile.score,
      Number(existingPlayerData.score) || 0
    );
    const cloudBest = Math.max(
      localState.bestMass,
      Number(existingPlayerData.bestMass) || 0
    );
    const cloudSkins = Array.isArray(existingPrivateData?.unlockedSkins)
      ? Array.from(
          new Set([
            ...localState.profile.unlockedSkins,
            ...(existingPrivateData.unlockedSkins as SkinId[]),
          ])
        ).slice(0, 50)
      : localState.profile.unlockedSkins;
    const cloudXp = Math.max(
      localState.profile.xp,
      Number(existingPrivateData?.xp) || 0
    );

    const publicProfile: PublicPlayerProfile = {
      uid: user.uid,
      playerCode: cloudCode,
      displayName: safeName,
      skinId: localState.skinId,
      level: cloudLevel,
      score: cloudScore,
      bestMass: cloudBest,
      coins: cloudCoins,
      dna: cloudDna,
      online: localState.online,
      currentRoom: localState.currentRoom.slice(0, 24),
    };

    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'players', user.uid), {
        displayName: publicProfile.displayName,
        skinId: publicProfile.skinId,
        level: publicProfile.level,
        score: publicProfile.score,
        bestMass: publicProfile.bestMass,
        coins: publicProfile.coins,
        dna: publicProfile.dna,
        online: publicProfile.online,
        currentRoom: publicProfile.currentRoom,
        updatedAt: serverTimestamp(),
      });
      batch.set(
        doc(db, 'playerCodes', cloudCode),
        {
          uid: user.uid,
          playerCode: cloudCode,
          displayName: publicProfile.displayName,
          skinId: publicProfile.skinId,
          level: publicProfile.level,
          bestMass: publicProfile.bestMass,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
      batch.set(
        doc(db, 'usersPrivate', user.uid),
        {
          uid: user.uid,
          email: (user.email || 'user@rk.gar.io').slice(0, 160),
          xp: cloudXp,
          unlockedSkins: cloudSkins,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, playerPath);
    }

    return {
      publicProfile,
      mergedXp: cloudXp,
      mergedUnlockedSkins: cloudSkins,
    };
  }

  // First-time cloud account creation — pick an unused playerCode
  let chosenCode = getOrCreateLocalPlayerCode();
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      const codeSnap = await getDoc(doc(db, 'playerCodes', chosenCode));
      if (!codeSnap.exists()) break;
      chosenCode = generatePlayerCode();
    } catch {
      break;
    }
  }
  saveLocalPlayerCode(chosenCode);

  const publicProfile: PublicPlayerProfile = {
    uid: user.uid,
    playerCode: chosenCode,
    displayName: safeName,
    skinId: localState.skinId,
    level: Math.max(1, localState.profile.level),
    score: Math.max(0, localState.profile.score),
    bestMass: Math.max(0, localState.bestMass),
    coins: Math.max(0, localState.profile.coins),
    dna: Math.max(0, localState.profile.dna),
    online: localState.online,
    currentRoom: localState.currentRoom.slice(0, 24),
  };

  try {
    const batch = writeBatch(db);
    batch.set(doc(db, 'players', user.uid), {
      ...publicProfile,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'playerCodes', chosenCode), {
      uid: user.uid,
      playerCode: chosenCode,
      displayName: publicProfile.displayName,
      skinId: publicProfile.skinId,
      level: publicProfile.level,
      bestMass: publicProfile.bestMass,
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'usersPrivate', user.uid), {
      uid: user.uid,
      email: (user.email || 'user@rk.gar.io').slice(0, 160),
      xp: Math.max(0, localState.profile.xp),
      unlockedSkins: localState.profile.unlockedSkins.slice(0, 50),
      updatedAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, playerPath);
  }

  return {
    publicProfile,
    mergedXp: localState.profile.xp,
    mergedUnlockedSkins: localState.profile.unlockedSkins,
  };
}

export async function syncCloudProfile(
  user: User,
  playerCode: string,
  state: {
    displayName: string;
    skinId: SkinId;
    profile: PlayerProfile;
    bestMass: number;
    currentRoom: string;
    online: boolean;
  }
): Promise<void> {
  if (!/^RK[0-9A-Z]{6}$/.test(playerCode)) return;
  const safeName = clampString(state.displayName || user.displayName || 'Player', 'Player', 24);
  const playerPath = `players/${user.uid}`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'players', user.uid), {
      displayName: safeName,
      skinId: state.skinId,
      level: Math.max(1, state.profile.level),
      score: Math.max(0, state.profile.score),
      bestMass: Math.max(0, state.bestMass),
      coins: Math.max(0, state.profile.coins),
      dna: Math.max(0, state.profile.dna),
      online: state.online,
      currentRoom: state.currentRoom.slice(0, 24),
      updatedAt: serverTimestamp(),
    });
    batch.update(doc(db, 'playerCodes', playerCode), {
      displayName: safeName,
      skinId: state.skinId,
      level: Math.max(1, state.profile.level),
      bestMass: Math.max(0, state.bestMass),
      updatedAt: serverTimestamp(),
    });
    batch.update(doc(db, 'usersPrivate', user.uid), {
      email: (user.email || 'user@rk.gar.io').slice(0, 160),
      xp: Math.max(0, state.profile.xp),
      unlockedSkins: state.profile.unlockedSkins.slice(0, 50),
      updatedAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, playerPath);
  }
}

export async function lookupCloudPlayerByCode(
  rawCode: string
): Promise<PublicPlayerProfile | null> {
  const code = normalizePlayerCode(rawCode);
  if (!/^RK[0-9A-Z]{6}$/.test(code)) return null;

  const lookupPath = `playerCodes/${code}`;
  try {
    const codeSnap = await getDoc(doc(db, 'playerCodes', code));
    if (!codeSnap.exists()) return null;
    const codeData = codeSnap.data() as Record<string, unknown>;
    const targetUid = typeof codeData.uid === 'string' ? codeData.uid : '';
    if (!targetUid) return null;

    const playerSnap = await getDoc(doc(db, 'players', targetUid));
    if (!playerSnap.exists()) {
      return {
        uid: targetUid,
        playerCode: code,
        displayName: String(codeData.displayName || 'Player'),
        skinId: safeSkinId(codeData.skinId),
        level: Number(codeData.level) || 1,
        score: 0,
        bestMass: Number(codeData.bestMass) || 0,
        coins: 0,
        dna: 0,
        online: false,
        currentRoom: '',
      };
    }
    const p = playerSnap.data() as Record<string, unknown>;
    return {
      uid: targetUid,
      playerCode: String(p.playerCode || code),
      displayName: String(p.displayName || 'Player'),
      skinId: safeSkinId(p.skinId),
      level: Number(p.level) || 1,
      score: Number(p.score) || 0,
      bestMass: Number(p.bestMass) || 0,
      coins: Number(p.coins) || 0,
      dna: Number(p.dna) || 0,
      online: Boolean(p.online),
      currentRoom: String(p.currentRoom || ''),
    };
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, lookupPath);
  }
}

export async function fetchCloudFriends(uid: string): Promise<FriendRecord[]> {
  const path = `friendships/${uid}/list`;
  try {
    const snap = await getDocs(
      query(collection(db, 'friendships', uid, 'list'), where('ownerUid', '==', uid))
    );
    return snap.docs.map((d) => {
      const data = d.data() as Record<string, unknown>;
      return {
        friendUid: String(data.friendUid || d.id),
        playerCode: String(data.playerCode || ''),
        displayName: String(data.displayName || 'Player'),
        skinId: safeSkinId(data.skinId),
        level: Number(data.level) || 1,
      };
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

export async function addCloudFriend(uid: string, friend: FriendRecord): Promise<void> {
  if (uid === friend.friendUid) return;
  const path = `friendships/${uid}/list/${friend.friendUid}`;
  try {
    await setDoc(doc(db, 'friendships', uid, 'list', friend.friendUid), {
      ownerUid: uid,
      friendUid: friend.friendUid,
      playerCode: normalizePlayerCode(friend.playerCode),
      displayName: clampString(friend.displayName, 'Player', 24),
      skinId: friend.skinId,
      level: Math.max(1, friend.level),
      addedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function removeCloudFriend(uid: string, friendUid: string): Promise<void> {
  const path = `friendships/${uid}/list/${friendUid}`;
  try {
    await deleteDoc(doc(db, 'friendships', uid, 'list', friendUid));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function claimPendingCloudGrants(
  uid: string
): Promise<{ coins: number; dna: number }> {
  const path = 'currencyGrants';
  let totalCoins = 0;
  let totalDna = 0;
  try {
    const q = query(
      collection(db, 'currencyGrants'),
      where('targetUid', '==', uid),
      where('claimed', '==', false)
    );
    const snap = await getDocs(q);
    for (const grantDoc of snap.docs) {
      const data = grantDoc.data() as Record<string, unknown>;
      const c = Number(data.coins) || 0;
      const d = Number(data.dna) || 0;
      await updateDoc(doc(db, 'currencyGrants', grantDoc.id), {
        claimed: true,
        claimedAt: serverTimestamp(),
      });
      totalCoins += c;
      totalDna += d;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
  return { coins: totalCoins, dna: totalDna };
}

export async function adminFetchAllCloudPlayers(): Promise<PublicPlayerProfile[]> {
  const path = 'players';
  try {
    const snap = await getDocs(collection(db, 'players'));
    return snap.docs.map((d) => {
      const p = d.data() as Record<string, unknown>;
      return {
        uid: String(p.uid || d.id),
        playerCode: String(p.playerCode || ''),
        displayName: String(p.displayName || 'Player'),
        skinId: safeSkinId(p.skinId),
        level: Number(p.level) || 1,
        score: Number(p.score) || 0,
        bestMass: Number(p.bestMass) || 0,
        coins: Number(p.coins) || 0,
        dna: Number(p.dna) || 0,
        online: Boolean(p.online),
        currentRoom: String(p.currentRoom || ''),
      };
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

export async function adminCreateCloudGrant(
  adminUid: string,
  targetUid: string,
  targetCode: string,
  coins: number,
  dna: number
): Promise<void> {
  const grantId = `grant_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const path = `currencyGrants/${grantId}`;
  try {
    await setDoc(doc(db, 'currencyGrants', grantId), {
      targetUid,
      targetCode: normalizePlayerCode(targetCode),
      coins: Math.max(0, Math.round(coins)),
      dna: Math.max(0, Math.round(dna)),
      claimed: false,
      grantedByUid: adminUid,
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}
