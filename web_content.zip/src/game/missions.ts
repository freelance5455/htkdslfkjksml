import * as THREE from 'three';
import { createMoto160, type MotoRig } from './motoModel';
import { groundHeightAt } from './world';
import type { ActiveMissionState, BikeCustomization, MissionDefinition } from './types';

export const MISSION_CATALOG: MissionDefinition[] = [
  {
    id: 'entrega_centro',
    type: 'entrega',
    title: 'Entrega Expressa no Centro',
    description: 'Leve a encomenda da Casa Principal até a Praça do Obelisco no Centro da Cidade antes do tempo acabar.',
    rewardMoney: 450,
    rewardXp: 140,
    timeLimitSec: 55,
    checkpoints: [
      { x: 290, z: -70, label: 'Praça do Obelisco (Centro)' },
      { x: 7, z: -10, label: 'Voltar para Casa Principal' },
    ],
  },
  {
    id: 'entrega_morro',
    type: 'entrega',
    title: 'Delivery na Favela do Morro',
    description: 'Suba as ladeiras da Favela Morro da Vitória para entregar peças de moto na laje do ponto alto.',
    rewardMoney: 550,
    rewardXp: 175,
    timeLimitSec: 65,
    checkpoints: [
      { x: -240, z: -210, label: 'Topo da Favela Morro da Vitória' },
    ],
  },
  {
    id: 'tempo_avenida',
    type: 'tempo',
    title: 'Contra o Relógio · Reta 140',
    description: 'Cruze todos os portais da Avenida Central ao Centro e retorne em menos de 60 segundos.',
    rewardMoney: 620,
    rewardXp: 210,
    timeLimitSec: 60,
    checkpoints: [
      { x: 160, z: 0, label: 'Portal 1 · Entrada do Centro' },
      { x: 380, z: 0, label: 'Portal 2 · Final da Avenida' },
      { x: 240, z: -140, label: 'Portal 3 · Cruzamento Norte' },
      { x: 40, z: 0, label: 'Chegada · Próximo à Casa' },
    ],
  },
  {
    id: 'grau_mestre',
    type: 'grau',
    title: 'Desafio do Grau 160',
    description: 'Empine a moto por 95 metros acumulados (mantendo o equilíbrio no freio traseiro) sem cair!',
    rewardMoney: 500,
    rewardXp: 190,
    targetWheelieDistM: 95,
    timeLimitSec: 65,
  },
  {
    id: 'racha_npc',
    type: 'racha',
    title: 'Racha Contra Piloto Rival',
    description: 'Dispute uma corrida até o final do Centro contra o piloto rival de 160cc preparada!',
    rewardMoney: 780,
    rewardXp: 260,
    timeLimitSec: 55,
    racerStart: { x: 24, z: 4, heading: -Math.PI / 2 },
    checkpoints: [
      { x: 390, z: 0, label: 'Linha de Chegada · Centro Leste' },
    ],
  },
  {
    id: 'fuga_policia',
    type: 'policia',
    title: 'Fuga da Polícia',
    description: 'Despiste a viatura moto-patrulha pelas avenidas e vielas durante 35 segundos sem ser cercado!',
    rewardMoney: 950,
    rewardXp: 320,
    policeDurationSec: 35,
  },
];

export class MissionDirector {
  public active: ActiveMissionState | null = null;
  private beaconGroup: THREE.Group;
  private beaconRing: THREE.Mesh;
  private beaconBeam: THREE.Mesh;

  private enemyRig: MotoRig | null = null;
  private enemyX = 0;
  private enemyZ = 0;
  private enemyHeading = 0;
  private enemySpeed = 0;
  private scene: THREE.Scene;

  constructor(scene: THREE.Scene, baseCustom: BikeCustomization) {
    this.scene = scene;
    void baseCustom;

    this.beaconGroup = new THREE.Group();
    this.beaconGroup.visible = false;

    this.beaconRing = new THREE.Mesh(
      new THREE.RingGeometry(2.6, 3.6, 28),
      new THREE.MeshBasicMaterial({ color: 0xf59e0b, side: THREE.DoubleSide, transparent: true, opacity: 0.85 })
    );
    this.beaconRing.rotation.x = -Math.PI / 2;
    this.beaconRing.position.y = 0.14;
    this.beaconGroup.add(this.beaconRing);

    this.beaconBeam = new THREE.Mesh(
      new THREE.CylinderGeometry(1.1, 2.2, 36, 16, 1, true),
      new THREE.MeshBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.24, side: THREE.DoubleSide, depthWrite: false })
    );
    this.beaconBeam.position.y = 18;
    this.beaconGroup.add(this.beaconBeam);

    scene.add(this.beaconGroup);
  }

  public startMission(def: MissionDefinition, playerX: number, playerZ: number, baseCustom: BikeCustomization): void {
    this.clearEnemy();
    this.active = {
      def,
      startedAt: performance.now(),
      elapsedSec: 0,
      currentCheckpointIndex: 0,
      wheelieDistanceM: 0,
      wheelieHoldSec: 0,
      policeCaughtTimer: 0,
      racerProgress: 0,
      racerFinished: false,
      status: 'active',
    };

    if (def.type === 'racha') {
      this.enemyRig = createMoto160(baseCustom, { isRacer: true });
      this.enemyX = playerX + 6;
      this.enemyZ = playerZ + 4;
      this.enemyHeading = -Math.PI / 2;
      this.enemySpeed = 0;
      this.scene.add(this.enemyRig.root);
    } else if (def.type === 'policia') {
      this.enemyRig = createMoto160(baseCustom, { isPolice: true });
      this.enemyX = playerX - 38;
      this.enemyZ = playerZ + 20;
      this.enemyHeading = 0;
      this.enemySpeed = 16;
      this.scene.add(this.enemyRig.root);
    }
  }

  public cancelMission(): void {
    this.active = null;
    this.beaconGroup.visible = false;
    this.clearEnemy();
  }

  private clearEnemy(): void {
    if (this.enemyRig) {
      this.scene.remove(this.enemyRig.root);
      this.enemyRig = null;
    }
  }

  public update(
    dt: number,
    playerX: number,
    playerZ: number,
    playerSpeedMs: number,
    isWheelieing: boolean,
    crashed: boolean,
    nightFactor: number,
    elapsedSecGlobal: number,
    onComplete: (def: MissionDefinition) => void,
    onFail: (def: MissionDefinition, reason: string) => void
  ): {
    targetPos: { x: number; z: number } | null;
    enemies: Array<{ x: number; z: number; kind: 'police' | 'racer' }>;
  } {
    if (!this.active || this.active.status !== 'active') {
      this.beaconGroup.visible = false;
      return { targetPos: null, enemies: [] };
    }

    const state = this.active;
    const def = state.def;
    state.elapsedSec += dt;

    let targetPos: { x: number; z: number } | null = null;
    const enemies: Array<{ x: number; z: number; kind: 'police' | 'racer' }> = [];

    // 1. Checkpoints (Entrega, Tempo, Racha)
    if (def.checkpoints && def.checkpoints.length > 0) {
      const cp = def.checkpoints[state.currentCheckpointIndex];
      if (cp) {
        targetPos = { x: cp.x, z: cp.z };
        const gy = groundHeightAt(cp.x, cp.z);
        this.beaconGroup.visible = true;
        this.beaconGroup.position.set(cp.x, gy, cp.z);
        this.beaconRing.scale.setScalar(1 + Math.sin(elapsedSecGlobal * 5) * 0.12);

        const dist = Math.hypot(playerX - cp.x, playerZ - cp.z);
        if (dist < 8.5) {
          if (state.currentCheckpointIndex + 1 < def.checkpoints.length) {
            state.currentCheckpointIndex++;
          } else {
            state.status = 'completed';
            this.beaconGroup.visible = false;
            this.clearEnemy();
            onComplete(def);
            return { targetPos: null, enemies: [] };
          }
        }
      }
    } else {
      this.beaconGroup.visible = false;
    }

    // 2. Grau Mission
    if (def.type === 'grau') {
      if (crashed) {
        state.status = 'failed';
        state.failReason = 'Você caiu durante o desafio do grau!';
        onFail(def, state.failReason);
        return { targetPos: null, enemies: [] };
      }
      if (isWheelieing) {
        state.wheelieDistanceM += Math.abs(playerSpeedMs) * dt;
        state.wheelieHoldSec += dt;
      }
      if (def.targetWheelieDistM && state.wheelieDistanceM >= def.targetWheelieDistM) {
        state.status = 'completed';
        onComplete(def);
        return { targetPos: null, enemies: [] };
      }
    }

    // 3. Racha vs NPC Rider
    if (def.type === 'racha' && this.enemyRig && def.checkpoints?.[0]) {
      const goal = def.checkpoints[0];
      const dx = goal.x - this.enemyX;
      const dz = goal.z - this.enemyZ;
      const distToGoal = Math.hypot(dx, dz);
      const targetAngle = Math.atan2(-dx, -dz);
      this.enemyHeading = targetAngle;
      this.enemySpeed = THREE.MathUtils.damp(this.enemySpeed, 31.5, 1.8, dt); // ~113 km/h rival
      this.enemyX += -Math.sin(this.enemyHeading) * this.enemySpeed * dt;
      this.enemyZ += -Math.cos(this.enemyHeading) * this.enemySpeed * dt;
      const ey = groundHeightAt(this.enemyX, this.enemyZ);
      this.enemyRig.root.position.set(this.enemyX, ey, this.enemyZ);
      this.enemyRig.root.rotation.set(0, this.enemyHeading, 0);
      this.enemyRig.updateAnimation({
        wheelSpinDelta: (this.enemySpeed * dt) / 0.255,
        steerAngle: 0,
        wheelieRad: state.elapsedSec < 2.5 ? 0.25 : 0,
        speedKmh: this.enemySpeed * 3.6,
        throttle: true,
        braking: false,
        nightFactor,
        timeSec: elapsedSecGlobal,
      });
      enemies.push({ x: this.enemyX, z: this.enemyZ, kind: 'racer' });

      if (distToGoal < 8) {
        state.status = 'failed';
        state.failReason = 'O piloto rival cruzou a linha de chegada primeiro!';
        this.clearEnemy();
        this.beaconGroup.visible = false;
        onFail(def, state.failReason);
        return { targetPos: null, enemies: [] };
      }
    }

    // 4. Police Chase Survival
    if (def.type === 'policia' && this.enemyRig) {
      const dx = playerX - this.enemyX;
      const dz = playerZ - this.enemyZ;
      const dist = Math.hypot(dx, dz);
      const desiredHeading = Math.atan2(-dx, -dz);
      // Smooth turn
      let diff = desiredHeading - this.enemyHeading;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      this.enemyHeading += THREE.MathUtils.clamp(diff, -2.5 * dt, 2.5 * dt);

      const targetSpd = dist > 45 ? 34.5 : 28.5;
      this.enemySpeed = THREE.MathUtils.damp(this.enemySpeed, targetSpd, 2.2, dt);
      this.enemyX += -Math.sin(this.enemyHeading) * this.enemySpeed * dt;
      this.enemyZ += -Math.cos(this.enemyHeading) * this.enemySpeed * dt;

      const ey = groundHeightAt(this.enemyX, this.enemyZ);
      this.enemyRig.root.position.set(this.enemyX, ey, this.enemyZ);
      this.enemyRig.root.rotation.set(0, this.enemyHeading, 0);
      this.enemyRig.updateAnimation({
        wheelSpinDelta: (this.enemySpeed * dt) / 0.255,
        steerAngle: THREE.MathUtils.clamp(diff, -0.35, 0.35),
        wheelieRad: 0,
        speedKmh: this.enemySpeed * 3.6,
        throttle: true,
        braking: false,
        nightFactor,
        timeSec: elapsedSecGlobal,
      });
      enemies.push({ x: this.enemyX, z: this.enemyZ, kind: 'police' });

      if (dist < 4.5 && playerSpeedMs < 8) {
        state.policeCaughtTimer += dt;
        if (state.policeCaughtTimer > 2.2) {
          state.status = 'failed';
          state.failReason = 'A polícia cercou sua moto!';
          this.clearEnemy();
          onFail(def, state.failReason);
          return { targetPos: null, enemies: [] };
        }
      } else {
        state.policeCaughtTimer = Math.max(0, state.policeCaughtTimer - dt);
      }

      if (def.policeDurationSec && state.elapsedSec >= def.policeDurationSec) {
        state.status = 'completed';
        this.clearEnemy();
        onComplete(def);
        return { targetPos: null, enemies: [] };
      }
    }

    // 5. Timeout check
    if (def.timeLimitSec && state.elapsedSec >= def.timeLimitSec) {
      state.status = 'failed';
      state.failReason = 'O tempo da missão acabou!';
      this.clearEnemy();
      this.beaconGroup.visible = false;
      onFail(def, state.failReason);
      return { targetPos: null, enemies: [] };
    }

    return { targetPos, enemies };
  }

  public dispose(): void {
    this.clearEnemy();
    this.scene.remove(this.beaconGroup);
    this.beaconRing.geometry.dispose();
    (this.beaconRing.material as THREE.Material).dispose();
    this.beaconBeam.geometry.dispose();
    (this.beaconBeam.material as THREE.Material).dispose();
  }
}
