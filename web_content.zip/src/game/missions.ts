import type { MissionDef } from "./types";
import { TOTAL_BODIES } from "./catalog";

export const MISSIONS: MissionDef[] = [
  {
    id: "awaken",
    title: "Awaken the Atlas",
    text: "Throttle toward a glowing system and scan it at close range.",
    xp: 50,
    goal: 1,
    kind: "scan",
  },
  {
    id: "core",
    title: "Into the Core",
    text: "Dive inside a galaxy (under 8 units) and complete a core scan.",
    xp: 90,
    goal: 1,
    kind: "dive",
  },
  {
    id: "horizon",
    title: "Event Horizon",
    text: "Scan a black hole. Keep hull above zero — gravity will pull you in.",
    xp: 140,
    goal: 1,
    kind: "bh",
  },
  {
    id: "survey",
    title: "Deep-Space Survey",
    text: "Chart 5 different celestial objects on the atlas.",
    xp: 180,
    goal: 5,
    kind: "discover",
  },
  {
    id: "samples",
    title: "Stellar Harvest",
    text: "Fly through 8 orbiting stellar samples to collect them.",
    xp: 160,
    goal: 8,
    kind: "samples",
  },
  {
    id: "pilot",
    title: "Atlas Pilot",
    text: "Warp to 3 different systems using the catalog.",
    xp: 200,
    goal: 3,
    kind: "warp",
  },
  {
    id: "atlas",
    title: "Build the Atlas",
    text: "Discover 12 objects. The atlas is taking shape.",
    xp: 320,
    goal: 12,
    kind: "discover12",
  },
  {
    id: "master",
    title: "Atlas Master",
    text: "Chart every galaxy and black hole in the atlas.",
    xp: 600,
    goal: TOTAL_BODIES,
    kind: "all",
  },
];

export const RANKS = [
  { name: "CADET", xp: 0 },
  { name: "SCOUT", xp: 80 },
  { name: "PILOT", xp: 200 },
  { name: "EXPLORER", xp: 400 },
  { name: "NAVIGATOR", xp: 700 },
  { name: "CARTOGRAPHER", xp: 1100 },
  { name: "VOIDWALKER", xp: 1700 },
  { name: "ATLAS MASTER", xp: 2500 },
] as const;

export function rankFor(xp: number) {
  let current: (typeof RANKS)[number] = RANKS[0];
  for (const r of RANKS) {
    if (xp >= r.xp) current = r;
  }
  const i = RANKS.indexOf(current);
  const next = i >= 0 ? (RANKS[i + 1] ?? null) : null;
  return { current, next };
}
