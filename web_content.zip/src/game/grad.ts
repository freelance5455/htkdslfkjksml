import * as THREE from "three";

const data = new Uint8Array([48, 42, 38, 255, 168, 160, 150, 255, 255, 252, 248, 255]);

export const GRAD = new THREE.DataTexture(data, 3, 1);
GRAD.magFilter = THREE.NearestFilter;
GRAD.minFilter = THREE.NearestFilter;
GRAD.generateMipmaps = false;
GRAD.colorSpace = THREE.NoColorSpace;
GRAD.needsUpdate = true;
