import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { MAPS, parseMap, CELL, type Box, type ParsedMap, type MapDef } from './maps';
import { getTex, flashTexture, dotTexture, holeTexture, markerTexture, type TexName } from './textures';
import { W, ARMS_RACE, type WeaponDef } from './weapons';
import { buildGun, buildChar, type CharModel, type GunModel } from './models';
import { audio } from './audio';
import { DEFAULT_SKIN, type Save, type Difficulty } from './store';

export type ModeId = 'classic' | 'deathmatch' | 'zombie' | 'knives' | 'sniper' | 'armsrace';

export const MODES: { id: ModeId; name: string; en: string; desc: string; icon: string }[] = [
  { id: 'classic', name: 'کلاسیک', en: 'CLASSIC', desc: 'ضدتروریست در برابر تروریست – دور به دور با خرید اسلحه', icon: '🎯' },
  { id: 'deathmatch', name: 'مسابقه مرگ', en: 'DEATHMATCH', desc: 'همه علیه همه – زنده شدن سریع', icon: '💀' },
  { id: 'zombie', name: 'حالت زامبی', en: 'ZOMBIE', desc: 'از ۱۰ موج زامبی‌های گرسنه جان سالم به در ببر', icon: '🧟' },
  { id: 'knives', name: 'نبرد چاقو', en: 'KNIVES', desc: 'فقط چاقو! تیمی تا ۲۵ کشته', icon: '🔪' },
  { id: 'sniper', name: 'تک‌تیرانداز', en: 'SNIPER', desc: 'فقط AWP و دیزرت ایگل – تیمی', icon: '🔭' },
  { id: 'armsrace', name: 'مسابقه اسلحه', en: 'ARMS RACE', desc: 'با هر کشتن اسلحه جدید – اول کسی که با چاقو بکشد برنده است', icon: '🏆' },
];

interface Rules { teams: boolean; respawn: boolean; rounds: boolean; limit: number; time: number; buy: 'money' | 'free' | 'none' }
const RULES: Record<ModeId, Rules> = {
  classic: { teams: true, respawn: false, rounds: true, limit: 5, time: 115, buy: 'money' },
  deathmatch: { teams: false, respawn: true, rounds: false, limit: 25, time: 300, buy: 'free' },
  zombie: { teams: true, respawn: false, rounds: false, limit: 10, time: 0, buy: 'money' },
  knives: { teams: true, respawn: true, rounds: false, limit: 25, time: 300, buy: 'none' },
  sniper: { teams: true, respawn: true, rounds: false, limit: 30, time: 300, buy: 'none' },
  armsrace: { teams: false, respawn: true, rounds: false, limit: ARMS_RACE.length, time: 600, buy: 'none' },
};

export interface GameConfig { mapId: string; mode: ModeId; bots: number; difficulty: Difficulty; team: 'ct' | 't' }

export interface KillEntry { id: number; killer: string; victim: string; weapon: string; hs: boolean; kc: string; vc: string; t: number; me: boolean }
export interface ScoreRow { name: string; team: string; color: string; kills: number; deaths: number; alive: boolean; me: boolean; score: number }

export interface HudState {
  hp: number; armor: number; helmet: boolean; money: number;
  weaponId: string; weaponName: string; mag: number; res: number; grenades: number;
  slots: (string | null)[]; curSlot: number;
  reload: number; scoped: boolean; aiming: boolean; spread: number;
  timer: number; phase: string; round: number;
  scoreA: number; scoreB: number; labelA: string; labelB: string; colorA: string; colorB: string;
  aliveA: number; aliveB: number;
  killfeed: KillEntry[];
  center: { text: string; sub: string; color: string; key: number } | null;
  dead: boolean; respawnIn: number; canBuy: boolean; buyMode: 'money' | 'free' | 'none';
  hitT: number; hitHead: boolean; killT: number; dmgT: number; dmgDir: number;
  fps: number; mode: ModeId; wave: number; armsLevel: number; armsTotal: number;
  rows: ScoreRow[]; crouch: boolean; spectating: string;
  streak: number; streakT: number;
}

export interface MatchResult { win: boolean | null; title: string; kills: number; deaths: number; hs: number; coins: number; xp: number; mode: ModeId; map: string; score: string }

export interface EngineCallbacks {
  onHud(h: HudState): void;
  onEnd(r: MatchResult): void;
  onPause(): void;
  onBuyToggle(): void;
  onScoreboard(show: boolean): void;
}

interface Brain {
  model: CharModel;
  marker: THREE.Sprite | null;
  target: Ent | null; visible: boolean;
  lastSeen: THREE.Vector3 | null; lastSeenT: number;
  reaction: number; nextShot: number; burst: number; reloadT: number;
  path: { x: number; z: number }[]; pathT: number; pathGoal: string;
  goal: { x: number; z: number } | null;
  strafe: number; strafeT: number;
  stuckT: number; lastPos: THREE.Vector3;
  thinkT: number; alertT: number;
  walk: number; deadT: number; groanT: number; attackT: number;
  zombie: boolean; speed: number;
}

interface Ent {
  id: number; name: string; team: string; isPlayer: boolean; color: string;
  pos: THREE.Vector3; vel: THREE.Vector3; yaw: number; pitch: number;
  hp: number; maxHp: number; armor: number; helmet: boolean; alive: boolean;
  kills: number; deaths: number; hs: number; money: number;
  onGround: boolean; crouch: boolean; radius: number; height: number;
  respawnT: number; spottedT: number;
  weapons: (string | null)[]; ammo: Record<string, { mag: number; res: number }>; cur: number; grenades: number;
  armsLevel: number;
  bot: Brain | null;
}

interface Grenade { mesh: THREE.Mesh; pos: THREE.Vector3; vel: THREE.Vector3; t: number; owner: Ent }

const GRAV = 22;
const STEP = 0.5;
const BOT_NAMES = ['عقاب', 'گرگ', 'شاهین', 'پلنگ', 'طوفان', 'صاعقه', 'ببر', 'کبرا', 'سایه', 'روباه', 'شیر', 'عقرب', 'رعد', 'آرش', 'رستم', 'کاوه', 'سهراب', 'بهرام', 'نادر', 'تهمتن', 'سیمرغ', 'اژدها'];
const FFA_COLORS = ['#7a2a8a', '#2a7a6a', '#8a6a1a', '#3a3a8a', '#8a2a3a', '#4a7a2a', '#6a4a2a', '#2a5a8a', '#8a4a6a', '#5a5a5a', '#1a6a4a', '#7a3a1a'];
const REACT: Record<Difficulty, number> = { easy: 0.9, normal: 0.55, hard: 0.32, pro: 0.2 };
const ACC: Record<Difficulty, number> = { easy: 0.22, normal: 0.36, hard: 0.5, pro: 0.64 };
const HSCH: Record<Difficulty, number> = { easy: 0.06, normal: 0.13, hard: 0.22, pro: 0.32 };
const TEAM_COL: Record<string, string> = { ct: '#5aa9ff', t: '#ff9a3a', z: '#7dff3a', p: '#ffd000' };

/* ---------- particles ---------- */
class Particles {
  max: number; n = 0;
  pos: Float32Array; col: Float32Array; size: Float32Array; alpha: Float32Array;
  vel: Float32Array; life: Float32Array; maxLife: Float32Array; grav: Float32Array; grow: Float32Array; a0: Float32Array;
  geo: THREE.BufferGeometry; points: THREE.Points; mat: THREE.ShaderMaterial;
  constructor(max: number, additive: boolean) {
    this.max = max;
    this.pos = new Float32Array(max * 3); this.col = new Float32Array(max * 3);
    this.size = new Float32Array(max); this.alpha = new Float32Array(max);
    this.vel = new Float32Array(max * 3); this.life = new Float32Array(max); this.maxLife = new Float32Array(max);
    this.grav = new Float32Array(max); this.grow = new Float32Array(max); this.a0 = new Float32Array(max);
    this.geo = new THREE.BufferGeometry();
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    this.geo.setAttribute('color', new THREE.BufferAttribute(this.col, 3));
    this.geo.setAttribute('size', new THREE.BufferAttribute(this.size, 1));
    this.geo.setAttribute('alpha', new THREE.BufferAttribute(this.alpha, 1));
    this.mat = new THREE.ShaderMaterial({
      uniforms: { map: { value: dotTexture() }, uScale: { value: 500 } },
      vertexShader: `attribute float size; attribute float alpha; attribute vec3 color; varying vec3 vC; varying float vA; uniform float uScale;
        void main(){ vC=color; vA=alpha; vec4 mv=modelViewMatrix*vec4(position,1.0); gl_PointSize = size*uScale/max(0.1,-mv.z); gl_Position=projectionMatrix*mv; }`,
      fragmentShader: `uniform sampler2D map; varying vec3 vC; varying float vA;
        void main(){ vec4 t=texture2D(map, gl_PointCoord); float a=t.a*vA; if(a<0.01) discard; gl_FragColor=vec4(vC*t.rgb, a); }`,
      transparent: true, depthWrite: false,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
    });
    this.points = new THREE.Points(this.geo, this.mat);
    this.points.frustumCulled = false;
  }
  spawn(x: number, y: number, z: number, vx: number, vy: number, vz: number, life: number, size: number, r: number, g: number, b: number, grav = 9, a = 1, grow = 0) {
    const i = this.n; this.n = (this.n + 1) % this.max;
    this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z;
    this.vel[i * 3] = vx; this.vel[i * 3 + 1] = vy; this.vel[i * 3 + 2] = vz;
    this.col[i * 3] = r; this.col[i * 3 + 1] = g; this.col[i * 3 + 2] = b;
    this.life[i] = life; this.maxLife[i] = life; this.size[i] = size; this.grav[i] = grav; this.a0[i] = a; this.alpha[i] = a; this.grow[i] = grow;
  }
  update(dt: number) {
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) { if (this.alpha[i] !== 0) this.alpha[i] = 0; continue; }
      this.life[i] -= dt;
      this.vel[i * 3 + 1] -= this.grav[i] * dt;
      const drag = 1 - Math.min(1, dt * 1.5);
      this.vel[i * 3] *= drag; this.vel[i * 3 + 2] *= drag;
      this.pos[i * 3] += this.vel[i * 3] * dt;
      this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt;
      this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      if (this.pos[i * 3 + 1] < 0.03) { this.pos[i * 3 + 1] = 0.03; this.vel[i * 3 + 1] *= -0.2; this.vel[i * 3] *= 0.5; this.vel[i * 3 + 2] *= 0.5; }
      this.size[i] += this.grow[i] * dt;
      const k = Math.max(0, this.life[i] / this.maxLife[i]);
      this.alpha[i] = this.a0[i] * Math.min(1, k * 2.5);
    }
    this.geo.attributes.position.needsUpdate = true;
    this.geo.attributes.color.needsUpdate = true;
    this.geo.attributes.size.needsUpdate = true;
    this.geo.attributes.alpha.needsUpdate = true;
  }
}

/* ---------- Engine ---------- */
export class Engine {
  canvas: HTMLCanvasElement;
  cfg: GameConfig; save: Save; cb: EngineCallbacks; rules: Rules; map: MapDef; pm: ParsedMap;
  renderer: THREE.WebGLRenderer; scene: THREE.Scene; camera: THREE.PerspectiveCamera;
  vmScene: THREE.Scene; vmCam: THREE.PerspectiveCamera; vmRoot: THREE.Group; vmGun: GunModel | null = null; vmCache = new Map<string, GunModel>();
  flash: THREE.Sprite; flashT = 0; worldLight: THREE.PointLight;
  sky: THREE.Mesh;
  boxes: Box[] = [];
  ents: Ent[] = []; player!: Ent;
  fx: Particles; fxAdd: Particles;
  tracers: { m: THREE.Mesh; t: number }[] = []; tracerI = 0;
  decals: THREE.Mesh[] = []; decalI = 0;
  grenadesL: Grenade[] = [];
  snow: THREE.Points | null = null;
  input = { moveX: 0, moveY: 0, fire: false, jump: false };
  keys = new Set<string>();
  running = true; paused = false; raf = 0; last = 0; time = 0;
  // player weapon state
  nextFire = 0; reloadT = 0; reloadDur = 0; drawT = 0; spray = 0; lastShot = 0; knifeT = 0; throwT = 0; aiming = false; prevSlot = 1;
  kick = 0; kickYaw = 0; vmKick = 0; shake = 0; bob = 0; stepAcc = 0; swayX = 0; swayY = 0;
  // game state
  phase = 'live'; timer = 0; round = 0; scores: Record<string, number> = { ct: 0, t: 0 }; teamKills: Record<string, number> = { ct: 0, t: 0 };
  buyEnd = 0; wave = 0; spawnLeft = 0; spawnT = 0; zombiePool: Ent[] = [];
  killfeed: KillEntry[] = []; kfId = 0; center: HudState['center'] = null; centerUntil = 0; centerKey = 0;
  hitT = -10; hitHead = false; killT = -10; dmgT = -10; dmgDir = 0; streak = 0; streakT = -10;
  hudT = 0; fps = 60; fpsAcc = 0; fpsN = 0; radarCtx: CanvasRenderingContext2D | null = null; radarFrame = 0;
  spectate: Ent | null = null; overT = 0; ended = false;
  stats = { kills: 0, deaths: 0, hs: 0 };
  isTouch: boolean;
  uiOpen = false;
  tmpV = new THREE.Vector3(); tmpV2 = new THREE.Vector3();
  baseFov: number;
  private listeners: [EventTarget, string, EventListener, AddEventListenerOptions?][] = [];

  constructor(canvas: HTMLCanvasElement, cfg: GameConfig, save: Save, cb: EngineCallbacks) {
    this.canvas = canvas; this.cfg = cfg; this.save = save; this.cb = cb;
    this.rules = RULES[cfg.mode];
    this.map = MAPS.find(m => m.id === cfg.mapId) || MAPS[0];
    this.pm = parseMap(this.map);
    this.isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    const q = save.settings.quality;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: q !== 'low', powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, q === 'high' ? 2 : q === 'med' ? 1.25 : 0.8));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = q !== 'low';
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.autoClear = false;
    this.baseFov = save.settings.fov;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(this.baseFov, 1, 0.05, 600);
    this.camera.rotation.order = 'YXZ';
    this.vmScene = new THREE.Scene();
    this.vmCam = new THREE.PerspectiveCamera(62, 1, 0.01, 10);
    this.vmRoot = new THREE.Group();
    this.vmScene.add(this.vmRoot);
    const fm = new THREE.SpriteMaterial({ map: flashTexture(), blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, transparent: true });
    this.flash = new THREE.Sprite(fm); this.flash.visible = false; this.flash.renderOrder = 10;
    this.worldLight = new THREE.PointLight('#ffb050', 0, 12, 2);
    this.scene.add(this.worldLight);
    this.fx = new Particles(700, false);
    this.fxAdd = new Particles(500, true);
    this.scene.add(this.fx.points, this.fxAdd.points);
    this.sky = this.buildSky();
    this.buildWorld();
    this.buildPools();
    audio.init();
    audio.setVolume(save.settings.volume);
    this.setupEntities();
    this.bindInput();
    this.resize();
    this.startMode();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  /* ================= WORLD ================= */
  buildSky() {
    const th = this.map.theme;
    const sunDir = new THREE.Vector3(0.45, 0.75, 0.35).normalize();
    const mat = new THREE.ShaderMaterial({
      uniforms: { top: { value: new THREE.Color(th.skyTop) }, bottom: { value: new THREE.Color(th.skyBottom) }, sunDir: { value: sunDir }, sunCol: { value: new THREE.Color(th.sun) } },
      vertexShader: `varying vec3 vW; void main(){ vec4 w=modelMatrix*vec4(position,1.0); vW=w.xyz; gl_Position=projectionMatrix*viewMatrix*w; }`,
      fragmentShader: `uniform vec3 top; uniform vec3 bottom; uniform vec3 sunDir; uniform vec3 sunCol; varying vec3 vW;
        void main(){ vec3 d=normalize(vW-cameraPosition); float h=d.y; vec3 c=mix(bottom, top, pow(clamp(h,0.0,1.0),0.55)); if(h<0.0) c=bottom*0.92;
        float s=max(dot(d,sunDir),0.0); c+=sunCol*(pow(s,600.0)*3.0+pow(s,12.0)*0.25); gl_FragColor=vec4(c,1.0); }`,
      side: THREE.BackSide, depthWrite: false, fog: false,
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(400, 24, 16), mat);
    sky.renderOrder = -10;
    this.scene.add(sky);
    return sky;
  }

  buildWorld() {
    const th = this.map.theme;
    const pm = this.pm;
    const W_ = pm.w * CELL, H_ = pm.h * CELL;
    this.scene.fog = new THREE.Fog(th.fog, th.fogNear, th.fogFar);
    const hemi = new THREE.HemisphereLight(th.hemiSky, th.hemiGround, th.hemiI);
    this.scene.add(hemi);
    const sun = new THREE.DirectionalLight(th.sun, th.sunI);
    sun.position.set(W_ / 2 + 40, 70, H_ / 2 + 30);
    sun.target.position.set(W_ / 2, 0, H_ / 2);
    this.scene.add(sun, sun.target);
    const q = this.save.settings.quality;
    if (q !== 'low') {
      sun.castShadow = true;
      const s = Math.max(W_, H_) * 0.75;
      sun.shadow.camera.left = -s; sun.shadow.camera.right = s; sun.shadow.camera.top = s; sun.shadow.camera.bottom = -s;
      sun.shadow.camera.near = 10; sun.shadow.camera.far = 200;
      sun.shadow.mapSize.set(q === 'high' ? 2048 : 1024, q === 'high' ? 2048 : 1024);
      sun.shadow.bias = -0.0005;
      sun.shadow.normalBias = 0.04;
    }
    // vm lights
    this.vmScene.add(new THREE.HemisphereLight(th.hemiSky, th.hemiGround, 1.3));
    const vl = new THREE.DirectionalLight(th.sun, 1.6); vl.position.set(1, 2, 1); this.vmScene.add(vl);

    // floor
    const floorTex = getTex(th.floor).clone();
    floorTex.needsUpdate = true;
    const fs = Math.max(W_, H_) + 80;
    floorTex.repeat.set(fs / 4, fs / 4);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(fs, fs), new THREE.MeshStandardMaterial({ map: floorTex, roughness: 0.95 }));
    floor.rotation.x = -Math.PI / 2; floor.position.set(W_ / 2, 0, H_ / 2);
    floor.receiveShadow = true;
    this.scene.add(floor);

    // boxes merged per texture
    this.boxes = pm.boxes;
    const groups = new Map<TexName, THREE.BufferGeometry[]>();
    for (const b of pm.boxes) {
      const w = b.maxX - b.minX, h = b.maxY - b.minY, d = b.maxZ - b.minZ;
      const geo = new THREE.BoxGeometry(w, h, d);
      const uv = geo.attributes.uv as THREE.BufferAttribute;
      const isCrate = b.kind === 'crate';
      const sc = isCrate ? 0 : b.kind === 'container' ? 3 : 3.2;
      const dims: [number, number][] = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
      for (let f = 0; f < 6; f++) {
        const [uw, vh] = dims[f];
        for (let i = f * 4; i < f * 4 + 4; i++) {
          if (isCrate) continue;
          uv.setXY(i, uv.getX(i) * uw / sc, uv.getY(i) * vh / sc);
        }
      }
      geo.translate((b.minX + b.maxX) / 2, (b.minY + b.maxY) / 2, (b.minZ + b.maxZ) / 2);
      if (!groups.has(b.tex)) groups.set(b.tex, []);
      groups.get(b.tex)!.push(geo);
    }
    groups.forEach((geos, tex) => {
      const merged = mergeGeometries(geos, false);
      const metal = tex === 'container' || tex === 'containerRed' || tex === 'metal';
      const mesh = new THREE.Mesh(merged!, new THREE.MeshStandardMaterial({ map: getTex(tex), roughness: metal ? 0.6 : 0.92, metalness: metal ? 0.35 : 0 }));
      mesh.castShadow = true; mesh.receiveShadow = true;
      this.scene.add(mesh);
      geos.forEach(g => g.dispose());
    });

    // clouds
    if (this.map.id !== 'maze') {
      const cm = new THREE.SpriteMaterial({ map: dotTexture(), color: '#ffffff', transparent: true, opacity: 0.55, fog: false, depthWrite: false });
      for (let i = 0; i < 16; i++) {
        const s = new THREE.Sprite(cm);
        const a = Math.random() * Math.PI * 2, r = 120 + Math.random() * 180;
        s.position.set(W_ / 2 + Math.cos(a) * r, 60 + Math.random() * 60, H_ / 2 + Math.sin(a) * r);
        s.scale.set(60 + Math.random() * 80, 18 + Math.random() * 20, 1);
        s.renderOrder = -5;
        this.scene.add(s);
      }
    }
    // weather
    if (th.snow || th.dust) {
      const n = th.snow ? 1500 : 350;
      const pos = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) { pos[i * 3] = Math.random() * W_; pos[i * 3 + 1] = Math.random() * 20; pos[i * 3 + 2] = Math.random() * H_; }
      const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const m = new THREE.PointsMaterial({ color: th.snow ? '#ffffff' : '#e8d2a0', size: th.snow ? 0.12 : 0.06, map: dotTexture(), transparent: true, depthWrite: false, opacity: th.snow ? 0.9 : 0.6 });
      this.snow = new THREE.Points(g, m);
      this.snow.frustumCulled = false;
      this.scene.add(this.snow);
    }
  }

  buildPools() {
    const tg = new THREE.BoxGeometry(0.02, 0.02, 1);
    tg.translate(0, 0, -0.5);
    const tm = new THREE.MeshBasicMaterial({ color: '#ffe9a0', transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
    for (let i = 0; i < 24; i++) {
      const m = new THREE.Mesh(tg, tm.clone()); m.visible = false; m.frustumCulled = false;
      this.scene.add(m); this.tracers.push({ m, t: 0 });
    }
    const dg = new THREE.PlaneGeometry(0.16, 0.16);
    const dm = new THREE.MeshBasicMaterial({ map: holeTexture(), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4 });
    for (let i = 0; i < 80; i++) {
      const m = new THREE.Mesh(dg, dm); m.visible = false; this.scene.add(m); this.decals.push(m);
    }
  }

  /* ================= ENTITIES ================= */
  newEnt(name: string, team: string, isPlayer: boolean, color: string): Ent {
    return {
      id: this.ents.length, name, team, isPlayer, color,
      pos: new THREE.Vector3(), vel: new THREE.Vector3(), yaw: 0, pitch: 0,
      hp: 100, maxHp: 100, armor: 0, helmet: false, alive: true,
      kills: 0, deaths: 0, hs: 0, money: 1000,
      onGround: true, crouch: false, radius: 0.36, height: 1.8,
      respawnT: 0, spottedT: -10,
      weapons: [null, null, 'knife', null], ammo: {}, cur: 2, grenades: 0, armsLevel: 0, bot: null,
    };
  }

  makeBrain(kind: 'ct' | 't' | 'z' | 'ffa', tint?: string, zombie = false): Brain {
    const model = buildChar(kind, 0.7, tint);
    this.scene.add(model.group);
    return {
      model, marker: null, target: null, visible: false, lastSeen: null, lastSeenT: -100,
      reaction: 0, nextShot: 0, burst: 0, reloadT: 0, path: [], pathT: 0, pathGoal: '', goal: null,
      strafe: 1, strafeT: 0, stuckT: 0, lastPos: new THREE.Vector3(), thinkT: Math.random() * 0.2, alertT: 0,
      walk: Math.random() * 6, deadT: 0, groanT: Math.random() * 3, attackT: 0, zombie, speed: 4.6,
    };
  }

  setupEntities() {
    const m = this.cfg.mode;
    const names = [...BOT_NAMES].sort(() => Math.random() - 0.5);
    const pTeam = m === 'zombie' ? 'ct' : this.rules.teams ? this.cfg.team : 'p';
    this.player = this.newEnt(this.save.name || 'شما', pTeam, true, '#ffd000');
    this.ents.push(this.player);
    const nb = m === 'zombie' ? 2 : Math.max(1, this.cfg.bots);
    for (let i = 0; i < nb; i++) {
      let team: string; let kind: 'ct' | 't' | 'ffa'; let tint: string | undefined;
      if (m === 'zombie') { team = 'ct'; kind = 'ct'; }
      else if (this.rules.teams) {
        // balance: player team gets floor((nb+1)/2)-1 allies
        const allies = Math.floor((nb + 1) / 2) - 1;
        team = i < allies ? pTeam : (pTeam === 'ct' ? 't' : 'ct');
        kind = team as 'ct' | 't';
      } else { team = 'b' + i; kind = 'ffa'; tint = FFA_COLORS[i % FFA_COLORS.length]; }
      const e = this.newEnt(names[i % names.length], team, false, tint || TEAM_COL[team] || '#ccc');
      e.bot = this.makeBrain(kind, tint);
      if (this.rules.teams && team === pTeam) {
        const mk = new THREE.Sprite(new THREE.SpriteMaterial({ map: markerTexture(TEAM_COL[team]), depthTest: false, transparent: true }));
        mk.scale.set(0.35, 0.35, 1); mk.position.y = 2.25; mk.renderOrder = 998;
        e.bot.model.group.add(mk); e.bot.marker = mk;
      }
      this.ents.push(e);
    }
  }

  isEnemy(a: Ent, b: Ent) { return a !== b && a.team !== b.team; }
  def(e: Ent): WeaponDef { return W[e.weapons[e.cur] || 'knife']; }

  giveWeapon(e: Ent, id: string) {
    const d = W[id];
    if (d.type === 'grenade') { e.grenades = Math.min(2, e.grenades + 1); e.weapons[3] = 'he'; return; }
    e.weapons[d.slot] = id;
    e.ammo[id] = { mag: d.mag, res: d.reserve };
  }

  loadout(e: Ent, fresh: boolean) {
    const m = this.cfg.mode;
    const owned = (id: string) => this.save.owned.includes(id) || this.save.mods.allUnlocked;
    const prim = owned(this.save.primary) ? this.save.primary : 'ak47';
    const sec = owned(this.save.secondary) ? this.save.secondary : 'glock';
    if (fresh) { e.weapons = [null, null, 'knife', null]; e.ammo = {}; e.grenades = 0; }
    switch (m) {
      case 'classic':
        if (fresh) this.giveWeapon(e, e.isPlayer ? sec : (e.team === 'ct' ? 'usp' : 'glock'));
        else for (const id of e.weapons) if (id && W[id].mag) e.ammo[id] = { mag: W[id].mag, res: W[id].reserve };
        break;
      case 'deathmatch':
        if (e.isPlayer) { this.giveWeapon(e, prim); this.giveWeapon(e, sec); }
        else { this.giveWeapon(e, ['ak47', 'm4a1', 'mp5', 'awp', 'famas', 'p90', 'nova', 'm249'][Math.floor(Math.random() * 8)]); this.giveWeapon(e, 'deagle'); }
        this.giveWeapon(e, 'he');
        break;
      case 'zombie':
        if (e.isPlayer) { this.giveWeapon(e, prim); this.giveWeapon(e, sec); this.giveWeapon(e, 'he'); this.giveWeapon(e, 'he'); }
        else if (!e.bot?.zombie) { this.giveWeapon(e, Math.random() < 0.5 ? 'm4a1' : 'ak47'); this.giveWeapon(e, 'usp'); }
        break;
      case 'knives': break;
      case 'sniper': this.giveWeapon(e, 'awp'); this.giveWeapon(e, 'deagle'); break;
      case 'armsrace': {
        const id = ARMS_RACE[Math.min(e.armsLevel, ARMS_RACE.length - 1)];
        e.weapons = [null, null, 'knife', null]; e.ammo = {};
        if (id !== 'knife') this.giveWeapon(e, id);
        break;
      }
    }
    e.cur = e.weapons[0] ? 0 : e.weapons[1] ? 1 : 2;
    if (e.isPlayer) this.onSwitch();
  }

  spawnPos(e: Ent): { x: number; z: number } {
    const pm = this.pm;
    let list: { x: number; z: number }[];
    if (!this.rules.teams || (this.rules.respawn && this.cfg.mode !== 'zombie' && this.round > 0 && false)) {
      // FFA: pick spot far from enemies
      const cands = [...pm.ct, ...pm.t, ...pm.open];
      let best = cands[0], bd = -1;
      for (let k = 0; k < 14; k++) {
        const c = cands[Math.floor(Math.random() * cands.length)];
        let md = 1e9;
        for (const o of this.ents) if (o !== e && o.alive) md = Math.min(md, Math.hypot(o.pos.x - c.x, o.pos.z - c.z));
        if (md > bd) { bd = md; best = c; }
      }
      return best;
    }
    if (e.team === 'z') list = pm.t;
    else if (this.cfg.mode === 'zombie') list = pm.ct;
    else list = e.team === 'ct' ? pm.ct : pm.t;
    const s = list[Math.floor(Math.random() * list.length)];
    return { x: s.x + (Math.random() - 0.5) * 1.6, z: s.z + (Math.random() - 0.5) * 1.6 };
  }

  respawn(e: Ent, fresh: boolean) {
    const s = this.spawnPos(e);
    e.pos.set(s.x, 0, s.z); e.vel.set(0, 0, 0);
    e.hp = e.maxHp; e.alive = true; e.crouch = false;
    const cx = this.pm.w * CELL / 2, cz = this.pm.h * CELL / 2;
    e.yaw = Math.atan2(-(cx - s.x), -(cz - s.z));
    e.pitch = 0;
    if (this.cfg.mode !== 'classic') { e.armor = this.cfg.mode === 'zombie' && !e.isPlayer ? 100 : this.cfg.mode === 'deathmatch' ? 100 : 0; e.helmet = e.armor > 0; }
    if (e.bot) {
      const b = e.bot;
      b.model.group.visible = true; b.model.body.rotation.set(0, 0, 0); b.model.body.position.set(0, 0, 0);
      b.target = null; b.visible = false; b.lastSeen = null; b.path = []; b.goal = null; b.deadT = 0; b.reloadT = 0;
      b.lastPos.copy(e.pos);
      b.model.group.position.copy(e.pos);
    }
    if (!e.bot?.zombie) this.loadout(e, fresh);
    if (e.isPlayer) { this.reloadT = 0; this.aiming = false; this.spectate = null; }
  }

  /* ================= MODES ================= */
  startMode() {
    const m = this.cfg.mode;
    this.round = 0;
    if (this.rules.rounds) { this.startRound(); return; }
    if (m === 'zombie') {
      this.player.money = 1500;
      for (const e of this.ents) this.respawn(e, true);
      this.wave = 0; this.nextWave();
      return;
    }
    for (const e of this.ents) this.respawn(e, true);
    this.phase = 'live';
    this.timer = this.rules.time;
    this.showCenter(MODES.find(x => x.id === m)!.name, m === 'armsrace' ? 'با هر کشتن اسلحه بعدی را بگیر' : 'نبرد شروع شد!', '#ffd000', 2.5);
    audio.beep(660, 0.15); setTimeout(() => audio.beep(990, 0.25), 180);
  }

  startRound() {
    this.round++;
    for (const e of this.ents) {
      const fresh = this.round === 1 || !e.alive;
      if (this.round === 1) { e.money = 1000; e.armor = 0; e.helmet = false; }
      if (!e.alive) { e.armor = 0; e.helmet = false; }
      this.respawn(e, fresh);
      if (e.bot) this.botBuy(e);
    }
    this.phase = 'freeze'; this.timer = 3;
    this.buyEnd = this.time + 20;
    this.showCenter(`دور ${this.faN(this.round)}`, 'زمان خرید – آماده شوید', '#ffd000', 2.8);
    audio.beep(520, 0.1);
  }

  botBuy(e: Ent) {
    if (e.money >= 4750 && Math.random() < 0.2) { this.giveWeapon(e, 'awp'); e.money -= 4750; }
    else if (e.money >= 2700) { const id = e.team === 'ct' ? (Math.random() < 0.6 ? 'm4a1' : 'famas') : 'ak47'; this.giveWeapon(e, id); e.money -= W[id].price; }
    else if (e.money >= 1500 && Math.random() < 0.7) { const id = Math.random() < 0.5 ? 'mp5' : 'nova'; this.giveWeapon(e, id); e.money -= W[id].price; }
    if (e.money >= 1000 && e.armor < 50) { e.armor = 100; e.helmet = true; e.money -= 1000; }
    e.cur = e.weapons[0] ? 0 : 1;
  }

  nextWave() {
    this.wave++;
    if (this.wave > this.rules.limit) { this.endMatch(true, 'از همه موج‌ها جان سالم به در بردی!'); return; }
    this.phase = 'break'; this.timer = this.wave === 1 ? 6 : 10;
    for (const e of this.ents) if (!e.bot?.zombie && !e.alive && !e.isPlayer) this.respawn(e, true);
    this.showCenter(`موج ${this.faN(this.wave)}`, this.wave === 1 ? 'زامبی‌ها در راه‌اند... آماده شو' : 'وقت خرید – موج بعدی نزدیک است', '#7dff3a', 3);
  }

  spawnZombie() {
    let z = this.zombiePool.find(e => !e.alive && e.bot && e.bot.deadT > 3);
    if (!z) {
      z = this.newEnt('زامبی', 'z', false, '#7dff3a');
      z.bot = this.makeBrain('z', undefined, true);
      this.ents.push(z); this.zombiePool.push(z);
    }
    const boss = this.wave >= 5 && Math.random() < 0.08;
    z.maxHp = Math.round((80 + this.wave * 20) * (boss ? 4 : 1));
    z.bot!.speed = Math.min(6.8, 3.4 + this.wave * 0.25) * (boss ? 0.8 : 1);
    z.bot!.model.group.scale.setScalar(boss ? 1.35 : 1);
    z.name = boss ? 'زامبی غول' : 'زامبی';
    z.armor = 0;
    this.respawn(z, true);
  }

  updateMode(dt: number) {
    const m = this.cfg.mode;
    if (this.phase === 'over') {
      this.overT -= dt;
      if (this.overT <= 0 && !this.ended) { this.ended = true; this.finish(); }
      return;
    }
    if (m === 'classic') {
      if (this.phase === 'freeze') { this.timer -= dt; if (this.timer <= 0) { this.phase = 'live'; this.timer = this.rules.time; audio.beep(990, 0.2); } }
      else if (this.phase === 'live') {
        this.timer -= dt;
        const ctA = this.ents.filter(e => e.team === 'ct' && e.alive).length;
        const tA = this.ents.filter(e => e.team === 't' && e.alive).length;
        if (ctA === 0) this.endRound('t');
        else if (tA === 0) this.endRound('ct');
        else if (this.timer <= 0) this.endRound('ct');
      } else if (this.phase === 'roundEnd') {
        this.timer -= dt;
        if (this.timer <= 0) {
          if (this.scores.ct >= this.rules.limit || this.scores.t >= this.rules.limit) {
            const w = this.scores.ct >= this.rules.limit ? 'ct' : 't';
            this.endMatch(w === this.player.team, w === this.player.team ? 'تیم شما برنده مسابقه شد!' : 'تیم شما شکست خورد');
          } else this.startRound();
        }
      }
      if (!this.player.alive && this.phase !== 'roundEnd') {
        if (!this.spectate || !this.spectate.alive) this.spectate = this.ents.find(e => e.alive && e.team === this.player.team) || this.ents.find(e => e.alive) || null;
      }
      return;
    }
    if (m === 'zombie') {
      if (this.phase === 'break') { this.timer -= dt; if (this.timer <= 0) { this.phase = 'wave'; this.spawnLeft = 6 + this.wave * 4; audio.zombie(0.8); } }
      else if (this.phase === 'wave') {
        this.spawnT -= dt;
        const alive = this.ents.filter(e => e.team === 'z' && e.alive).length;
        if (this.spawnLeft > 0 && this.spawnT <= 0 && alive < 12 + this.wave) { this.spawnZombie(); this.spawnLeft--; this.spawnT = Math.max(0.35, 1.2 - this.wave * 0.08); }
        if (this.spawnLeft === 0 && alive === 0) { this.player.money += 1000 + this.wave * 200; this.nextWave(); }
      }
      if (!this.player.alive) this.endMatch(false, `در موج ${this.faN(this.wave)} شکست خوردی`);
      return;
    }
    // respawn modes
    this.timer -= dt;
    for (const e of this.ents) {
      if (!e.alive) { e.respawnT -= dt; if (e.respawnT <= 0) this.respawn(e, true); }
    }
    if (this.rules.teams) {
      if (this.teamKills.ct >= this.rules.limit || this.teamKills.t >= this.rules.limit || this.timer <= 0) {
        const w = this.teamKills.ct === this.teamKills.t ? null : this.teamKills.ct > this.teamKills.t ? 'ct' : 't';
        this.endMatch(w === null ? null : w === this.player.team, w === null ? 'مساوی!' : w === this.player.team ? 'تیم شما برنده شد!' : 'تیم شما باخت');
      }
    } else {
      const top = [...this.ents].filter(e => !e.bot?.zombie).sort((a, b) => (m === 'armsrace' ? b.armsLevel - a.armsLevel : b.kills - a.kills))[0];
      const reached = m === 'armsrace' ? top.armsLevel >= ARMS_RACE.length : top.kills >= this.rules.limit;
      if (reached || this.timer <= 0) this.endMatch(top.isPlayer, top.isPlayer ? 'شما نفر اول شدید! 🏆' : `${top.name} برنده شد`);
    }
  }

  endRound(w: string) {
    this.phase = 'roundEnd'; this.timer = 4.5;
    this.scores[w]++;
    for (const e of this.ents) e.money = Math.min(16000, e.money + (e.team === w ? 3250 : 1400));
    const mine = w === this.player.team;
    this.showCenter(w === 'ct' ? 'ضدتروریست‌ها برنده شدند' : 'تروریست‌ها برنده شدند', mine ? 'آفرین! دور را بردید' : 'این دور را باختید', TEAM_COL[w], 4);
    if (mine) audio.unlock(); else audio.error();
  }

  endMatch(win: boolean | null, title: string) {
    if (this.phase === 'over') return;
    this.phase = 'over'; this.overT = 3.5;
    this.showCenter(win === null ? 'مساوی' : win ? 'پیروزی!' : 'شکست', title, win ? '#ffd000' : win === null ? '#ddd' : '#ff4a4a', 4);
    if (win) audio.unlock(); else audio.error();
    this.aiming = false;
    this.input.fire = false;
  }

  finish() {
    const win = this.lastWin();
    const k = this.stats.kills;
    const coins = k * 15 + this.stats.hs * 5 + (win ? 250 : 60) + (this.cfg.mode === 'zombie' ? this.wave * 30 : 0);
    const xp = k * 50 + (win ? 400 : 100);
    const sc = this.rules.rounds ? `${this.scores.ct} - ${this.scores.t}` : this.rules.teams && this.cfg.mode !== 'zombie' ? `${this.teamKills.ct} - ${this.teamKills.t}` : this.cfg.mode === 'zombie' ? `موج ${this.wave}` : `${k}`;
    this.cb.onEnd({ win, title: this.center?.sub || '', kills: k, deaths: this.stats.deaths, hs: this.stats.hs, coins, xp, mode: this.cfg.mode, map: this.map.name, score: sc });
  }

  lastWin(): boolean | null {
    const c = this.center?.text;
    return c === 'پیروزی!' ? true : c === 'مساوی' ? null : false;
  }

  showCenter(text: string, sub: string, color: string, dur: number) {
    this.center = { text, sub, color, key: ++this.centerKey };
    this.centerUntil = this.time + dur;
  }

  faN(n: number) { return String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[+d]); }

  /* ================= PHYSICS ================= */
  moveEnt(e: Ent, dx: number, dz: number, dt: number) {
    e.pos.x += dx; e.pos.z += dz;
    const r = e.radius;
    const top = e.pos.y + e.height;
    for (let it = 0; it < 2; it++) {
      for (const b of this.boxes) {
        if (b.maxY <= e.pos.y + STEP || b.minY >= top) continue;
        const cx = Math.max(b.minX, Math.min(e.pos.x, b.maxX));
        const cz = Math.max(b.minZ, Math.min(e.pos.z, b.maxZ));
        const ddx = e.pos.x - cx, ddz = e.pos.z - cz;
        const d2 = ddx * ddx + ddz * ddz;
        if (d2 >= r * r) continue;
        if (d2 > 1e-9) {
          const d = Math.sqrt(d2); const push = r - d + 0.001;
          e.pos.x += ddx / d * push; e.pos.z += ddz / d * push;
        } else {
          const pl = e.pos.x - b.minX, pr = b.maxX - e.pos.x, pb = e.pos.z - b.minZ, pf = b.maxZ - e.pos.z;
          const mn = Math.min(pl, pr, pb, pf);
          if (mn === pl) e.pos.x = b.minX - r; else if (mn === pr) e.pos.x = b.maxX + r; else if (mn === pb) e.pos.z = b.minZ - r; else e.pos.z = b.maxZ + r;
        }
      }
    }
    e.vel.y -= GRAV * dt;
    e.pos.y += e.vel.y * dt;
    let ground = 0;
    const rr = r * 0.85;
    for (const b of this.boxes) {
      if (b.maxY > e.pos.y + STEP) continue;
      if (b.maxY <= ground) continue;
      const cx = Math.max(b.minX, Math.min(e.pos.x, b.maxX));
      const cz = Math.max(b.minZ, Math.min(e.pos.z, b.maxZ));
      if ((e.pos.x - cx) ** 2 + (e.pos.z - cz) ** 2 < rr * rr) ground = b.maxY;
    }
    if (e.pos.y <= ground) { e.pos.y = ground; if (e.vel.y < 0) e.vel.y = 0; e.onGround = true; }
    else e.onGround = e.pos.y - ground < 0.05;
  }

  rayWorld(o: THREE.Vector3, d: THREE.Vector3, maxT: number): { t: number; n: THREE.Vector3; b: Box | null } | null {
    let best = maxT; let bn: THREE.Vector3 | null = null; let bb: Box | null = null;
    if (d.y < -1e-6) { const t = -o.y / d.y; if (t > 0 && t < best) { best = t; bn = new THREE.Vector3(0, 1, 0); bb = null; } }
    const ix = 1 / d.x, iy = 1 / d.y, iz = 1 / d.z;
    for (const b of this.boxes) {
      let t1 = (b.minX - o.x) * ix, t2 = (b.maxX - o.x) * ix;
      let tmin = Math.min(t1, t2), tmax = Math.max(t1, t2); let axis = 0;
      t1 = (b.minY - o.y) * iy; t2 = (b.maxY - o.y) * iy;
      let a = Math.min(t1, t2); tmax = Math.min(tmax, Math.max(t1, t2));
      if (a > tmin) { tmin = a; axis = 1; }
      t1 = (b.minZ - o.z) * iz; t2 = (b.maxZ - o.z) * iz;
      a = Math.min(t1, t2); tmax = Math.min(tmax, Math.max(t1, t2));
      if (a > tmin) { tmin = a; axis = 2; }
      if (tmax < 0 || tmin > tmax || tmin > best || tmin < 0) continue;
      best = tmin; bb = b;
      bn = axis === 0 ? new THREE.Vector3(-Math.sign(d.x), 0, 0) : axis === 1 ? new THREE.Vector3(0, -Math.sign(d.y), 0) : new THREE.Vector3(0, 0, -Math.sign(d.z));
    }
    return bn ? { t: best, n: bn, b: bb } : null;
  }

  visible(a: THREE.Vector3, b: THREE.Vector3) {
    const d = this.tmpV2.copy(b).sub(a); const len = d.length(); d.divideScalar(len);
    return !this.rayWorld(a, d, len - 0.1);
  }

  rayEnt(o: THREE.Vector3, d: THREE.Vector3, e: Ent): { t: number; part: 'head' | 'body' | 'leg' } | null {
    const h = e.isPlayer && e.crouch ? 1.2 : e.height * (e.bot ? e.bot.model.group.scale.y : 1);
    const hy = e.pos.y + h - 0.15;
    const ocx = o.x - e.pos.x, ocy = o.y - hy, ocz = o.z - e.pos.z;
    const hr = 0.17 * (h / 1.8);
    const bq = ocx * d.x + ocy * d.y + ocz * d.z;
    const c = ocx * ocx + ocy * ocy + ocz * ocz - hr * hr;
    const disc = bq * bq - c;
    let headT = Infinity;
    if (disc > 0) { const t = -bq - Math.sqrt(disc); if (t > 0) headT = t; }
    const w = 0.28 * (h / 1.8);
    const mn = [e.pos.x - w, e.pos.y, e.pos.z - w], mx = [e.pos.x + w, e.pos.y + h - 0.3, e.pos.z + w];
    const oo = [o.x, o.y, o.z], dd = [d.x, d.y, d.z];
    let tmin = 0, tmax = Infinity;
    for (let i = 0; i < 3; i++) {
      const inv = 1 / dd[i];
      let t1 = (mn[i] - oo[i]) * inv, t2 = (mx[i] - oo[i]) * inv;
      if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
      tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
    }
    const bodyT = tmin <= tmax ? tmin : Infinity;
    if (headT === Infinity && bodyT === Infinity) return null;
    if (headT <= bodyT + 0.05) return { t: headT, part: 'head' };
    const y = o.y + d.y * bodyT;
    return { t: bodyT, part: y < e.pos.y + 0.85 * (h / 1.8) ? 'leg' : 'body' };
  }

  /* ================= INPUT ================= */
  on(t: EventTarget, ev: string, fn: EventListener, opt?: AddEventListenerOptions) { t.addEventListener(ev, fn, opt); this.listeners.push([t, ev, fn, opt]); }

  bindInput() {
    this.on(window, 'resize', () => this.resize());
    this.on(window, 'keydown', (ev) => {
      const e = ev as KeyboardEvent;
      if (e.code === 'Tab') { e.preventDefault(); this.cb.onScoreboard(true); }
      if (this.paused || this.uiOpen) { if (e.code === 'KeyB') this.cb.onBuyToggle(); return; }
      this.keys.add(e.code);
      if (e.code === 'Space') this.input.jump = true;
      if (e.code === 'KeyR') this.reload();
      if (e.code === 'Digit1') this.switchSlot(0);
      if (e.code === 'Digit2') this.switchSlot(1);
      if (e.code === 'Digit3') this.switchSlot(2);
      if (e.code === 'Digit4' || e.code === 'KeyG') this.switchSlot(3);
      if (e.code === 'KeyQ') this.switchSlot(this.prevSlot);
      if (e.code === 'KeyB') this.cb.onBuyToggle();
      if (e.code === 'ControlLeft' || e.code === 'KeyC') this.player.crouch = true;
    });
    this.on(window, 'keyup', (ev) => {
      const e = ev as KeyboardEvent;
      this.keys.delete(e.code);
      if (e.code === 'Tab') this.cb.onScoreboard(false);
      if (e.code === 'ControlLeft' || e.code === 'KeyC') this.player.crouch = false;
    });
    if (!this.isTouch) {
      this.on(this.canvas, 'click', () => { if (!this.paused && !this.uiOpen && document.pointerLockElement !== this.canvas) this.canvas.requestPointerLock?.(); });
      this.on(document, 'pointerlockchange', () => {
        if (document.pointerLockElement !== this.canvas) { this.input.fire = false; if (!this.uiOpen && !this.paused && this.phase !== 'over') this.cb.onPause(); }
      });
      this.on(document, 'mousemove', (ev) => {
        const e = ev as MouseEvent;
        if (document.pointerLockElement === this.canvas) this.look(e.movementX, e.movementY);
      });
      this.on(this.canvas, 'mousedown', (ev) => {
        const e = ev as MouseEvent;
        if (document.pointerLockElement !== this.canvas) return;
        if (e.button === 0) this.input.fire = true;
        if (e.button === 2) this.toggleAim();
      });
      this.on(window, 'mouseup', (ev) => { if ((ev as MouseEvent).button === 0) this.input.fire = false; });
      this.on(this.canvas, 'contextmenu', (e) => e.preventDefault());
      this.on(this.canvas, 'wheel', (ev) => {
        const dir = (ev as WheelEvent).deltaY > 0 ? 1 : -1;
        let s = this.player.cur;
        for (let i = 0; i < 4; i++) { s = (s + dir + 4) % 4; if (this.player.weapons[s]) { this.switchSlot(s); break; } }
      }, { passive: true });
    }
  }

  lockPointer() { if (!this.isTouch) this.canvas.requestPointerLock?.(); }

  setUiOpen(v: boolean) {
    this.uiOpen = v;
    if (v) { this.input.fire = false; if (document.pointerLockElement) document.exitPointerLock(); }
  }

  setPaused(v: boolean) {
    this.paused = v;
    this.input.fire = false;
    if (v && document.pointerLockElement) { this.uiOpen = true; document.exitPointerLock(); setTimeout(() => (this.uiOpen = false), 50); }
  }

  look(dx: number, dy: number) {
    if (this.paused || !this.player.alive || this.phase === 'over') return;
    const zoom = this.camera.fov / this.baseFov;
    const s = 0.0024 * this.save.settings.sens * zoom;
    this.player.yaw -= dx * s;
    this.player.pitch -= dy * s;
    this.player.pitch = Math.max(-1.5, Math.min(1.5, this.player.pitch));
    this.swayX += dx * 0.00025; this.swayY += dy * 0.00025;
  }

  resize() {
    const w = this.canvas.clientWidth || window.innerWidth, h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    this.vmCam.aspect = w / h; this.vmCam.updateProjectionMatrix();
    this.updatePScale();
  }

  updatePScale() {
    const hpx = this.renderer.domElement.height;
    const s = hpx / (2 * Math.tan(THREE.MathUtils.degToRad(this.camera.fov) / 2));
    this.fx.mat.uniforms.uScale.value = s; this.fxAdd.mat.uniforms.uScale.value = s;
  }

  /* ================= PLAYER ACTIONS ================= */
  switchSlot(s: number) {
    const p = this.player;
    if (!p.alive || !p.weapons[s] || s === p.cur) return;
    if (s === 3 && p.grenades <= 0) return;
    this.prevSlot = p.cur;
    p.cur = s;
    this.onSwitch();
  }

  onSwitch() {
    this.reloadT = 0; this.drawT = 0.45; this.aiming = false; this.spray = 0; this.knifeT = 0; this.throwT = 0;
    const id = this.player.weapons[this.player.cur] || 'knife';
    if (this.vmGun) this.vmRoot.remove(this.vmGun.group);
    let g = this.vmCache.get(id);
    if (!g) {
      const skin = this.save.skins[id] || DEFAULT_SKIN;
      g = buildGun(W[id], skin, true, this.player.team === 't' ? '#6b5a3a' : '#2f3d55');
      this.vmCache.set(id, g);
    }
    this.vmGun = g;
    this.vmRoot.add(g.group);
    g.muzzle.add(this.flash);
    audio.click(0.3);
  }

  toggleAim() {
    const d = this.def(this.player);
    if (d.type === 'knife' || d.type === 'grenade') return;
    this.aiming = !this.aiming;
    if (d.scope) audio.click(0.2);
  }

  jump() { this.input.jump = true; }
  toggleCrouch() { this.player.crouch = !this.player.crouch; }

  reload() {
    const p = this.player; const d = this.def(p);
    if (!d.mag || this.reloadT > 0 || !p.alive) return;
    const a = p.ammo[d.id]; if (!a) return;
    if (a.mag >= d.mag || (a.res <= 0 && !this.save.mods.infAmmo)) return;
    if (this.save.mods.noReload) { this.finishReload(); return; }
    this.reloadT = d.reload; this.reloadDur = d.reload; this.aiming = false;
    audio.reload(d.reload);
  }

  finishReload() {
    const p = this.player; const d = this.def(p); const a = p.ammo[d.id];
    if (!a) return;
    const need = d.mag - a.mag;
    if (this.save.mods.infAmmo) { a.mag = d.mag; return; }
    const take = Math.min(need, a.res); a.mag += take; a.res -= take;
  }

  canBuy() {
    if (!this.player.alive || this.rules.buy === 'none') return false;
    if (this.cfg.mode === 'classic') return this.time < this.buyEnd && this.phase !== 'over';
    if (this.cfg.mode === 'zombie') return this.phase === 'break';
    return true;
  }

  buy(id: string): boolean {
    const p = this.player;
    if (!this.canBuy()) return false;
    const free = this.rules.buy === 'free' || this.save.mods.infMoney;
    const price = id === 'armor' ? 650 : id === 'armorh' ? 1000 : W[id]?.price ?? 0;
    if (!free && p.money < price) { audio.error(); return false; }
    if (id === 'armor') { if (p.armor >= 100) return false; p.armor = 100; }
    else if (id === 'armorh') { if (p.armor >= 100 && p.helmet) return false; p.armor = 100; p.helmet = true; }
    else {
      const d = W[id];
      if (d.type === 'grenade' && p.grenades >= 2) return false;
      this.giveWeapon(p, id);
      if (d.type !== 'grenade') { p.cur = d.slot; this.onSwitch(); }
    }
    if (!free) p.money -= price;
    audio.buy();
    return true;
  }

  /* ================= PLAYER UPDATE ================= */
  updatePlayer(dt: number) {
    const p = this.player;
    if (!p.alive) return;
    const mods = this.save.mods;
    const frozen = this.phase === 'freeze' || this.phase === 'over';
    let mx = this.input.moveX, my = this.input.moveY;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) my += 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) my -= 1;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) mx -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) mx += 1;
    const ml = Math.hypot(mx, my); if (ml > 1) { mx /= ml; my /= ml; }
    const d = this.def(p);
    const walk = this.keys.has('ShiftLeft');
    let speed = 6.4 * d.speedMul * (p.crouch ? 0.45 : 1) * (walk ? 0.5 : 1) * (this.aiming ? (d.scope ? 0.5 : 0.75) : 1) * (mods.speed ? 1.8 : 1);
    if (frozen) speed = 0;
    const s = Math.sin(p.yaw), c = Math.cos(p.yaw);
    const wx = (-s * my + c * mx) * speed, wz = (-c * my - s * mx) * speed;
    const acc = p.onGround ? 12 : 2.5;
    p.vel.x += (wx - p.vel.x) * Math.min(1, acc * dt);
    p.vel.z += (wz - p.vel.z) * Math.min(1, acc * dt);
    if (this.input.jump && p.onGround && !frozen) { p.vel.y = mods.highJump ? 14 : 8; p.onGround = false; audio.step(0.3); }
    this.input.jump = false;
    const wasAir = !p.onGround;
    this.moveEnt(p, p.vel.x * dt, p.vel.z * dt, dt);
    if (wasAir && p.onGround) { audio.step(0.4); this.shake = Math.max(this.shake, 0.15); }
    const hs = Math.hypot(p.vel.x, p.vel.z);
    if (p.onGround && hs > 1) {
      this.bob += hs * dt * 1.35;
      this.stepAcc += hs * dt;
      if (this.stepAcc > (p.crouch || walk ? 99 : 2.3)) { this.stepAcc = 0; audio.step(0.18); }
    } else this.bob += (Math.round(this.bob / Math.PI) * Math.PI - this.bob) * Math.min(1, dt * 6);
    this.updatePlayerWeapon(dt, frozen);
    // spot enemies for radar
    if (Math.floor(this.time * 5) !== Math.floor((this.time - dt) * 5)) {
      const eye = this.tmpV.set(p.pos.x, p.pos.y + 1.6, p.pos.z).clone();
      for (const e of this.ents) {
        if (!e.alive || !this.isEnemy(p, e)) continue;
        const dx = e.pos.x - p.pos.x, dz = e.pos.z - p.pos.z;
        const ang = Math.atan2(-dx, -dz) - p.yaw;
        const a = Math.atan2(Math.sin(ang), Math.cos(ang));
        if (Math.abs(a) < 0.9 && this.visible(eye, new THREE.Vector3(e.pos.x, e.pos.y + 1.4, e.pos.z))) e.spottedT = this.time;
      }
    }
  }

  updatePlayerWeapon(dt: number, frozen: boolean) {
    const p = this.player; const d = this.def(p); const mods = this.save.mods;
    if (this.drawT > 0) this.drawT -= dt;
    if (this.knifeT > 0) this.knifeT -= dt;
    if (this.throwT > 0) { this.throwT -= dt; if (this.throwT <= 0 && p.cur === 3 && p.grenades <= 0) this.switchSlot(p.weapons[0] ? 0 : p.weapons[1] ? 1 : 2); }
    if (this.reloadT > 0) { this.reloadT -= dt; if (this.reloadT <= 0) this.finishReload(); }
    if (this.time - this.lastShot > 0.25) this.spray = Math.max(0, this.spray - dt * 12);
    if (!this.input.fire || frozen || this.drawT > 0 || this.reloadT > 0 || this.time < this.nextFire) return;
    const rate = d.fireRate * (mods.rapidFire ? 2 : 1);
    this.nextFire = this.time + 1 / rate;
    if (d.type === 'knife') { this.knifeAttack(p); return; }
    if (d.type === 'grenade') { if (p.grenades > 0) this.throwGrenade(); this.nextFire = this.time + 1; return; }
    const a = p.ammo[d.id];
    if (!a || a.mag <= 0) {
      audio.click(0.4); this.nextFire = this.time + 0.25;
      if (a && (a.res > 0 || mods.infAmmo)) this.reload();
      return;
    }
    this.shoot(d);
    if (!mods.infAmmo) a.mag--;
    if (a.mag <= 0 && (a.res > 0 || mods.infAmmo)) setTimeout(() => this.reload(), 150);
    if (d.scope && this.aiming) { this.aiming = false; const t = this.nextFire; setTimeout(() => { if (this.nextFire === t && this.def(this.player).id === d.id && this.player.alive) this.aiming = true; }, Math.min(1000, 1000 / rate)); }
  }

  shoot(d: WeaponDef) {
    const p = this.player; const mods = this.save.mods;
    const cam = this.camera;
    const origin = cam.position.clone();
    const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(cam.quaternion);
    const hs = Math.hypot(p.vel.x, p.vel.z);
    let spread = d.spread + Math.min(1, hs / 6) * d.moveSpread + (p.onGround ? 0 : 0.08) + Math.min(this.spray, 10) * (d.type === 'rifle' || d.type === 'smg' || d.type === 'lmg' ? 0.0035 : 0);
    if (p.crouch) spread *= 0.65;
    if (d.scope && !this.aiming) spread += 0.07;
    if (!d.scope && this.aiming) spread *= 0.6;
    if (mods.noRecoil) spread = d.pellets ? d.spread * 0.6 : 0;
    // aim assist
    if (mods.aimAssist) {
      let best: Ent | null = null, ba = 0.14;
      for (const e of this.ents) {
        if (!e.alive || !this.isEnemy(p, e)) continue;
        const tp = new THREE.Vector3(e.pos.x, e.pos.y + (e.height - 0.2) * (e.bot?.model.group.scale.y || 1), e.pos.z);
        const dir = tp.clone().sub(origin).normalize();
        const ang = dir.angleTo(fwd);
        if (ang < ba && this.visible(origin, tp)) { ba = ang; best = e; }
      }
      if (best) fwd.set(best.pos.x, best.pos.y + (best.height - 0.2) * (best.bot?.model.group.scale.y || 1), best.pos.z).sub(origin).normalize();
    }
    const muzzleW = cam.localToWorld(new THREE.Vector3(0.16, -0.14, -0.6));
    const pellets = d.pellets || 1;
    let anyHit = false, head = false;
    for (let i = 0; i < pellets; i++) {
      const dir = fwd.clone();
      if (spread > 0) {
        const right = new THREE.Vector3(1, 0, 0).applyQuaternion(cam.quaternion);
        const up = new THREE.Vector3(0, 1, 0).applyQuaternion(cam.quaternion);
        const a = Math.random() * Math.PI * 2, r = Math.sqrt(Math.random()) * spread;
        dir.addScaledVector(right, Math.cos(a) * r).addScaledVector(up, Math.sin(a) * r).normalize();
      }
      const res = this.traceShot(p, origin, dir, d, i === 0 || pellets < 4);
      if (res.hit) { anyHit = true; if (res.head) head = true; }
      if (i < 3) this.addTracer(this.aiming && d.scope ? origin.clone().addScaledVector(dir, 0.5) : muzzleW, res.end);
    }
    if (anyHit) { this.hitT = this.time; this.hitHead = head; head ? audio.headshot() : audio.hit(); }
    // fx
    audio.shot(d.snd, 0.9);
    this.flashT = 0.05;
    this.flash.material.rotation = Math.random() * Math.PI;
    const fs = d.type === 'sniper' || d.type === 'shotgun' ? 0.3 : d.id === 'usp' || d.id === 'mp5' ? 0.08 : 0.2;
    this.flash.scale.setScalar(fs * (0.8 + Math.random() * 0.4));
    this.worldLight.position.copy(muzzleW);
    this.worldLight.intensity = d.id === 'usp' || d.id === 'mp5' ? 0.5 : 3;
    const rec = mods.noRecoil ? 0 : d.recoil * (1 + Math.min(this.spray, 8) * 0.12);
    this.kick += rec;
    this.kickYaw += mods.noRecoil ? 0 : (Math.random() - 0.5) * rec * (this.spray > 4 ? 1.4 : 0.5);
    this.vmKick = Math.min(1, this.vmKick + (d.type === 'sniper' || d.type === 'shotgun' ? 1 : 0.5));
    this.spray++;
    this.lastShot = this.time;
    for (let i = 0; i < 2; i++) this.fx.spawn(muzzleW.x, muzzleW.y, muzzleW.z, fwd.x * 1.5 + (Math.random() - 0.5), fwd.y * 1.5 + 0.5, fwd.z * 1.5 + (Math.random() - 0.5), 0.6, 0.15, 0.7, 0.7, 0.7, -0.5, 0.25, 0.5);
    // alert nearby bots
    for (const e of this.ents) if (e.bot && e.alive && this.isEnemy(e, p) && e.pos.distanceTo(p.pos) < (d.id === 'usp' ? 8 : 35)) { e.bot.lastSeen = p.pos.clone(); e.bot.lastSeenT = this.time; e.bot.alertT = 1.5; }
    p.spottedT = this.time;
  }

  traceShot(shooter: Ent, o: THREE.Vector3, dir: THREE.Vector3, d: WeaponDef, decal: boolean) {
    const wall = this.rayWorld(o, dir, d.range);
    let maxT = wall ? wall.t : d.range;
    let target: Ent | null = null; let part: 'head' | 'body' | 'leg' = 'body';
    for (const e of this.ents) {
      if (!e.alive || !this.isEnemy(shooter, e)) continue;
      const h = this.rayEnt(o, dir, e);
      if (h && h.t < maxT) { maxT = h.t; target = e; part = h.part; }
    }
    const end = o.clone().addScaledVector(dir, maxT);
    if (target) {
      const falloff = Math.max(0.5, 1 - maxT / (d.range * 1.6));
      const mult = part === 'head' ? 4 : part === 'leg' ? 0.75 : 1;
      let dmg = d.damage * mult * falloff;
      if (this.save.mods.oneShot && shooter.isPlayer) dmg = 9999;
      this.damage(target, dmg, shooter, d, part === 'head');
      this.blood(end, dir, part === 'head' ? 18 : 10);
      return { hit: true, head: part === 'head', end };
    }
    if (wall) this.impact(end, wall.n, wall.b ? wall.b.tex : this.map.theme.floor, decal);
    return { hit: false, head: false, end };
  }

  knifeAttack(attacker: Ent) {
    if (attacker.isPlayer) { this.knifeT = 0.35; audio.knife(); }
    const fwd = new THREE.Vector3(-Math.sin(attacker.yaw), 0, -Math.cos(attacker.yaw));
    let best: Ent | null = null, bd = 2.4;
    for (const e of this.ents) {
      if (!e.alive || !this.isEnemy(attacker, e)) continue;
      const dx = e.pos.x - attacker.pos.x, dz = e.pos.z - attacker.pos.z, dy = e.pos.y - attacker.pos.y;
      const dist = Math.hypot(dx, dz);
      if (dist > bd || Math.abs(dy) > 1.5) continue;
      if ((dx * fwd.x + dz * fwd.z) / (dist || 1) < 0.55) continue;
      best = e; bd = dist;
    }
    if (best) {
      const back = Math.cos(best.yaw - attacker.yaw) > 0.5;
      let dmg = back ? 180 : 55 + Math.random() * 10;
      if (this.save.mods.oneShot && attacker.isPlayer) dmg = 9999;
      this.damage(best, dmg, attacker, W.knife, false);
      const p = new THREE.Vector3(best.pos.x, best.pos.y + 1.3, best.pos.z);
      this.blood(p, fwd, 14);
      if (attacker.isPlayer) { this.hitT = this.time; this.hitHead = back; audio.hit(); }
    }
  }

  throwGrenade() {
    const p = this.player;
    p.grenades--;
    if (p.grenades <= 0) p.weapons[3] = null;
    this.throwT = 0.5;
    const cam = this.camera;
    const dir = new THREE.Vector3(0, 0, -1).applyQuaternion(cam.quaternion);
    dir.y += 0.15; dir.normalize();
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 6), new THREE.MeshStandardMaterial({ color: '#3c4a2a', roughness: 0.6 }));
    mesh.castShadow = true;
    const pos = cam.position.clone().addScaledVector(dir, 0.6);
    mesh.position.copy(pos);
    this.scene.add(mesh);
    this.grenadesL.push({ mesh, pos, vel: dir.multiplyScalar(17).add(new THREE.Vector3(p.vel.x * 0.5, 0, p.vel.z * 0.5)), t: 1.7, owner: p });
    audio.knife();
  }

  updateGrenades(dt: number) {
    for (let i = this.grenadesL.length - 1; i >= 0; i--) {
      const g = this.grenadesL[i];
      g.t -= dt;
      g.vel.y -= GRAV * dt;
      const np = g.pos.clone().addScaledVector(g.vel, dt);
      const inBox = (x: number, y: number, z: number) => this.boxes.some(b => x > b.minX && x < b.maxX && y > b.minY && y < b.maxY && z > b.minZ && z < b.maxZ);
      if (inBox(np.x, g.pos.y, g.pos.z)) { g.vel.x *= -0.45; np.x = g.pos.x; }
      if (inBox(np.x, g.pos.y, np.z)) { g.vel.z *= -0.45; np.z = g.pos.z; }
      if (inBox(np.x, np.y, np.z)) { g.vel.y *= -0.35; np.y = g.pos.y; g.vel.x *= 0.7; g.vel.z *= 0.7; }
      if (np.y < 0.08) { np.y = 0.08; g.vel.y *= -0.35; g.vel.x *= 0.7; g.vel.z *= 0.7; }
      g.pos.copy(np); g.mesh.position.copy(np);
      g.mesh.rotation.x += dt * 8;
      if (g.t <= 0) { this.explode(g); this.scene.remove(g.mesh); g.mesh.geometry.dispose(); this.grenadesL.splice(i, 1); }
    }
  }

  explode(g: Grenade) {
    const o = g.pos.clone(); o.y += 0.3;
    const R = 7.5;
    for (const e of this.ents) {
      if (!e.alive) continue;
      if (e !== g.owner && !this.isEnemy(g.owner, e)) continue;
      const c = new THREE.Vector3(e.pos.x, e.pos.y + 1, e.pos.z);
      const d = c.distanceTo(o);
      if (d > R || !this.visible(o, c)) continue;
      let dmg = W.he.damage * (1 - d / R);
      if (e === g.owner) dmg *= 0.5;
      if (e.isPlayer && this.save.mods.god) continue;
      this.damage(e, dmg, g.owner, W.he, false);
    }
    for (let i = 0; i < 45; i++) {
      const a = Math.random() * Math.PI * 2, u = Math.random() * 2 - 0.2, s = 3 + Math.random() * 6;
      this.fxAdd.spawn(o.x, o.y, o.z, Math.cos(a) * s, u * s * 0.8 + 2, Math.sin(a) * s, 0.4 + Math.random() * 0.4, 0.8 + Math.random() * 0.8, 1, 0.55 + Math.random() * 0.3, 0.15, -1, 1, 2);
    }
    for (let i = 0; i < 30; i++) {
      const a = Math.random() * Math.PI * 2, s = 1 + Math.random() * 3;
      const gr = 0.25 + Math.random() * 0.15;
      this.fx.spawn(o.x, o.y + Math.random(), o.z, Math.cos(a) * s, 1 + Math.random() * 2, Math.sin(a) * s, 1.5 + Math.random() * 1.5, 1.2, gr, gr, gr, -0.4, 0.55, 2.2);
    }
    for (let i = 0; i < 20; i++) {
      const a = Math.random() * Math.PI * 2, s = 6 + Math.random() * 8;
      this.fx.spawn(o.x, o.y, o.z, Math.cos(a) * s, 3 + Math.random() * 8, Math.sin(a) * s, 1.2, 0.08, 0.15, 0.12, 0.1, 18, 1, 0);
    }
    this.worldLight.position.copy(o); this.worldLight.intensity = 25; this.worldLight.distance = 25;
    setTimeout(() => (this.worldLight.distance = 12), 200);
    const dist = o.distanceTo(this.player.pos);
    this.shake = Math.max(this.shake, Math.max(0, 1.2 - dist / 20));
    audio.explosion(Math.max(0.2, 1 - dist / 60), this.panFor(o));
  }

  damage(t: Ent, amount: number, from: Ent, wd: WeaponDef, head: boolean) {
    if (!t.alive || this.phase === 'over') return;
    if (t.isPlayer && this.save.mods.god) { this.dmgT = this.time; this.dmgDir = this.dirTo(from.pos); return; }
    let hp = amount;
    if (t.armor > 0 && (!head || t.helmet)) {
      hp = amount * (0.5 + wd.armorPen * 0.5);
      t.armor = Math.max(0, t.armor - amount * 0.35);
    }
    t.hp -= hp;
    if (t.bot) {
      t.bot.lastSeen = from.pos.clone(); t.bot.lastSeenT = this.time; t.bot.alertT = 2;
      if (!t.bot.visible) t.bot.reaction = Math.min(t.bot.reaction, REACT[this.cfg.difficulty] * 0.5);
    }
    if (t.isPlayer) {
      this.dmgT = this.time; this.dmgDir = this.dirTo(from.pos);
      this.shake = Math.max(this.shake, 0.25); this.kick += 0.02; audio.hurt();
    }
    if (t.hp <= 0) this.kill(t, from, wd, head);
  }

  dirTo(p: THREE.Vector3) {
    const pl = this.player;
    const a = Math.atan2(-(p.x - pl.pos.x), -(p.z - pl.pos.z)) - pl.yaw;
    return Math.atan2(Math.sin(a), Math.cos(a));
  }

  panFor(p: THREE.Vector3) { return -Math.sin(this.dirTo(p)) * 0.8; }

  kill(t: Ent, k: Ent, wd: WeaponDef, head: boolean) {
    t.alive = false; t.hp = 0; t.deaths++;
    t.respawnT = this.cfg.mode === 'deathmatch' || this.cfg.mode === 'armsrace' ? 3 : 4;
    if (k !== t) {
      k.kills++; if (head) k.hs++;
      if (this.rules.teams && this.cfg.mode !== 'zombie' && this.teamKills[k.team] !== undefined) this.teamKills[k.team]++;
      const bonus = this.cfg.mode === 'zombie' ? 150 : wd.type === 'knife' ? 1500 : wd.type === 'sniper' ? 100 : wd.type === 'smg' ? 600 : wd.type === 'shotgun' ? 900 : 300;
      k.money = Math.min(this.cfg.mode === 'zombie' ? 50000 : 16000, k.money + bonus);
      if (this.cfg.mode === 'armsrace') {
        if (wd.id === ARMS_RACE[Math.min(k.armsLevel, ARMS_RACE.length - 1)] || wd.type === 'knife') {
          k.armsLevel++;
          if (k.armsLevel < ARMS_RACE.length && k.alive) { this.loadout(k, true); if (k.isPlayer) audio.unlock(); }
        }
      }
    }
    const tc = t.team === 'z' ? TEAM_COL.z : this.rules.teams ? TEAM_COL[t.team] : t.color;
    const kc = k.team === 'z' ? TEAM_COL.z : this.rules.teams ? TEAM_COL[k.team] : k.color;
    this.killfeed.push({ id: ++this.kfId, killer: k.name, victim: t.name, weapon: wd.en, hs: head, kc: k.isPlayer ? '#ffd000' : kc, vc: t.isPlayer ? '#ffd000' : tc, t: this.time, me: k.isPlayer || t.isPlayer });
    if (this.killfeed.length > 6) this.killfeed.shift();
    if (k.isPlayer && t !== k) {
      this.stats.kills++; if (head) this.stats.hs++;
      this.killT = this.time;
      this.streak = this.time - this.streakT < 4 ? this.streak + 1 : 1;
      this.streakT = this.time;
    }
    if (t.isPlayer) {
      this.stats.deaths++;
      this.aiming = false; this.input.fire = false; this.reloadT = 0;
      this.streak = 0;
      if (this.rules.respawn) this.showCenter('کشته شدی', `توسط ${k.name} با ${wd.name}`, '#ff4a4a', 2.5);
    }
    if (t.bot) { t.bot.deadT = 0; if (t.bot.zombie) audio.zombie(0.5, this.panFor(t.pos)); }
  }

  /* ================= BOTS ================= */
  cellOf(x: number, z: number) { return { cx: Math.floor(x / CELL), cz: Math.floor(z / CELL) }; }

  findPath(sx: number, sz: number, tx: number, tz: number): { x: number; z: number }[] {
    const pm = this.pm; const w = pm.w, h = pm.h;
    const s = this.cellOf(sx, sz); let t = this.cellOf(tx, tz);
    const ok = (x: number, z: number) => x >= 0 && z >= 0 && x < w && z < h && pm.walk[z][x];
    if (!ok(t.cx, t.cz)) {
      let found = false;
      for (let r = 1; r < 4 && !found; r++) for (let dz = -r; dz <= r && !found; dz++) for (let dx = -r; dx <= r && !found; dx++) if (ok(t.cx + dx, t.cz + dz)) { t = { cx: t.cx + dx, cz: t.cz + dz }; found = true; }
      if (!found) return [];
    }
    const prev = new Int32Array(w * h).fill(-1);
    const start = s.cz * w + s.cx, goal = t.cz * w + t.cx;
    const q = [start]; prev[start] = start;
    let head = 0;
    while (head < q.length) {
      const cur = q[head++];
      if (cur === goal) break;
      const cx = cur % w, cz = (cur / w) | 0;
      const nb = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, 1], [1, -1], [-1, -1]];
      for (const [dx, dz] of nb) {
        const nx = cx + dx, nz = cz + dz;
        if (!ok(nx, nz)) continue;
        if (dx && dz && (!ok(cx + dx, cz) || !ok(cx, cz + dz))) continue;
        const ni = nz * w + nx;
        if (prev[ni] !== -1) continue;
        prev[ni] = cur; q.push(ni);
      }
    }
    if (prev[goal] === -1) return [];
    const path: { x: number; z: number }[] = [];
    let c = goal;
    while (c !== start) { path.push({ x: (c % w) * CELL + CELL / 2, z: ((c / w) | 0) * CELL + CELL / 2 }); c = prev[c]; }
    path.reverse();
    return path;
  }

  pickGoal(b: Ent): { x: number; z: number } {
    const pm = this.pm;
    if (this.cfg.mode === 'zombie' && !b.bot!.zombie) {
      const p = this.player;
      return { x: p.pos.x + (Math.random() - 0.5) * 6, z: p.pos.z + (Math.random() - 0.5) * 6 };
    }
    if (this.rules.teams && Math.random() < 0.6) {
      const list = b.team === 'ct' ? pm.t : pm.ct;
      return list[Math.floor(Math.random() * list.length)];
    }
    return pm.open[Math.floor(Math.random() * pm.open.length)];
  }

  botPerceive(b: Ent) {
    const br = b.bot!;
    const eye = new THREE.Vector3(b.pos.x, b.pos.y + 1.6, b.pos.z);
    let best: Ent | null = null, bd = Infinity, vis = false;
    for (const e of this.ents) {
      if (!e.alive || !this.isEnemy(b, e)) continue;
      if (br.zombie && e.team === 'z') continue;
      const dx = e.pos.x - b.pos.x, dz = e.pos.z - b.pos.z;
      const d = Math.hypot(dx, dz);
      if (d > (br.zombie ? 200 : 75)) continue;
      const ang = Math.atan2(-dx, -dz) - b.yaw;
      const a = Math.abs(Math.atan2(Math.sin(ang), Math.cos(ang)));
      const v = this.visible(eye, new THREE.Vector3(e.pos.x, e.pos.y + (e.isPlayer && e.crouch ? 1.0 : 1.4), e.pos.z));
      if (br.zombie) { if (d < bd) { bd = d; best = e; vis = v; } continue; }
      if (!v) continue;
      if (a > 1.25 && d > 7 && br.alertT <= 0) continue;
      if (d < bd) { bd = d; best = e; vis = true; }
    }
    if (best) {
      if (br.target !== best || !br.visible) br.reaction = REACT[this.cfg.difficulty] * (0.7 + Math.random() * 0.6);
      br.target = best; br.visible = vis;
      if (vis) { br.lastSeen = best.pos.clone(); br.lastSeenT = this.time; if (!this.rules.teams || b.team === this.player.team || this.cfg.mode === 'zombie') { /* allied spotting */ } if (b.team === this.player.team) best.spottedT = this.time; }
    } else { br.visible = false; if (br.target && !br.target.alive) br.target = null; }
  }

  updateBot(b: Ent, dt: number) {
    const br = b.bot!; const m = br.model;
    if (!b.alive) {
      br.deadT += dt;
      const k = Math.min(1, br.deadT / 0.45);
      m.body.rotation.x = k * k * Math.PI / 2 * (br.zombie ? -1 : 1);
      m.body.position.y = k * 0.15;
      if (br.deadT > (this.rules.respawn ? 2.8 : br.zombie ? 2.5 : 999)) m.group.visible = false;
      if (br.marker) br.marker.visible = false;
      return;
    }
    if (br.marker) br.marker.visible = true;
    const frozen = this.phase === 'freeze' || this.phase === 'over' || this.phase === 'break' && !br.zombie && false;
    br.thinkT -= dt; br.alertT -= dt;
    if (br.thinkT <= 0) { br.thinkT = 0.15 + Math.random() * 0.1; this.botPerceive(b); }
    const d = this.def(b);
    let mvx = 0, mvz = 0; let faceYaw: number | null = null;
    const tgt = br.target && br.target.alive ? br.target : null;
    let speed = br.zombie ? br.speed : 4.8 * d.speedMul;

    if (br.zombie) {
      if (tgt) {
        const dx = tgt.pos.x - b.pos.x, dz = tgt.pos.z - b.pos.z; const dist = Math.hypot(dx, dz);
        if (dist < 1.3) {
          faceYaw = Math.atan2(-dx, -dz);
          br.attackT -= dt;
          if (br.attackT <= 0) {
            br.attackT = 0.85;
            this.damage(tgt, 9 + this.wave * 1.2, b, W.knife, false);
            if (tgt.isPlayer) this.blood(new THREE.Vector3(tgt.pos.x, tgt.pos.y + 1.3, tgt.pos.z), new THREE.Vector3(dx, 0, dz).normalize(), 6);
            m.armL.rotation.x = -2.2; m.armR.rotation.x = -2.2;
          }
        } else if (br.visible && dist < 18) { mvx = dx / dist; mvz = dz / dist; }
        else { const v = this.follow(b, tgt.pos.x, tgt.pos.z, dt); mvx = v.x; mvz = v.z; }
      }
      br.groanT -= dt;
      if (br.groanT <= 0) { br.groanT = 3 + Math.random() * 5; const dd = b.pos.distanceTo(this.player.pos); if (dd < 30) audio.zombie(0.35 * (1 - dd / 30), this.panFor(b.pos)); }
      m.armL.rotation.x += (-1.45 - m.armL.rotation.x) * dt * 5; m.armR.rotation.x += (-1.35 - m.armR.rotation.x) * dt * 5;
    } else if (tgt && br.visible) {
      const dx = tgt.pos.x - b.pos.x, dz = tgt.pos.z - b.pos.z; const dist = Math.hypot(dx, dz);
      faceYaw = Math.atan2(-dx, -dz);
      br.reaction -= dt;
      if (d.type === 'knife') {
        mvx = dx / dist; mvz = dz / dist; speed *= 1.1;
        if (dist < 2 && this.time >= br.nextShot && br.reaction <= 0) {
          br.nextShot = this.time + 1 / d.fireRate;
          if (Math.random() < 0.7) { const savedYaw = b.yaw; b.yaw = faceYaw; this.knifeAttack(b); b.yaw = savedYaw; }
          if (b.pos.distanceTo(this.player.pos) < 15) audio.knife();
        }
      } else {
        br.strafeT -= dt;
        if (br.strafeT <= 0) { br.strafeT = 0.6 + Math.random() * 1.4; br.strafe = Math.random() < 0.25 ? 0 : Math.random() < 0.5 ? -1 : 1; }
        const px = -dz / dist, pz = dx / dist;
        const still = d.type === 'sniper' ? 0 : 1;
        mvx = px * br.strafe * still; mvz = pz * br.strafe * still;
        if (dist > d.range * 0.6) { mvx += dx / dist; mvz += dz / dist; }
        else if (dist < 4 && d.type !== 'shotgun') { mvx -= dx / dist * 0.6; mvz -= dz / dist * 0.6; }
        speed *= 0.6;
        this.botFire(b, tgt, dist, Math.hypot(mvx, mvz) > 0.1);
      }
    } else {
      // navigate
      let gx: number, gz: number;
      if (br.lastSeen && this.time - br.lastSeenT < 6) { gx = br.lastSeen.x; gz = br.lastSeen.z; if (Math.hypot(gx - b.pos.x, gz - b.pos.z) < 1.5) br.lastSeen = null; }
      else {
        if (!br.goal || Math.hypot(br.goal.x - b.pos.x, br.goal.z - b.pos.z) < 2) br.goal = this.pickGoal(b);
        gx = br.goal.x; gz = br.goal.z;
      }
      if (this.cfg.mode === 'zombie' && Math.hypot(this.player.pos.x - b.pos.x, this.player.pos.z - b.pos.z) < 5 && !br.lastSeen) { mvx = 0; mvz = 0; }
      else { const v = this.follow(b, gx, gz, dt); mvx = v.x; mvz = v.z; }
      if (br.reloadT > 0) speed *= 0.8;
    }
    if (br.reloadT > 0) { br.reloadT -= dt; if (br.reloadT <= 0) { const a = b.ammo[d.id]; if (a) a.mag = d.mag; } }
    if (frozen) { mvx = 0; mvz = 0; }
    const ml = Math.hypot(mvx, mvz);
    if (ml > 1) { mvx /= ml; mvz /= ml; }
    b.vel.x += (mvx * speed - b.vel.x) * Math.min(1, dt * 8);
    b.vel.z += (mvz * speed - b.vel.z) * Math.min(1, dt * 8);
    this.moveEnt(b, b.vel.x * dt, b.vel.z * dt, dt);
    if (faceYaw === null && ml > 0.1) faceYaw = Math.atan2(-mvx, -mvz);
    if (faceYaw !== null) {
      let diff = faceYaw - b.yaw; diff = Math.atan2(Math.sin(diff), Math.cos(diff));
      b.yaw += diff * Math.min(1, dt * (br.zombie ? 6 : 9));
    }
    // stuck
    br.stuckT += dt;
    if (br.stuckT > 1.2) {
      if (ml > 0.3 && br.lastPos.distanceTo(b.pos) < 0.6) { br.goal = this.pm.open[Math.floor(Math.random() * this.pm.open.length)]; br.path = []; br.lastSeen = null; }
      br.lastPos.copy(b.pos); br.stuckT = 0;
    }
    // anim
    const hs = Math.hypot(b.vel.x, b.vel.z);
    br.walk += hs * dt * 2.4;
    const amp = Math.min(1, hs / 3) * 0.7;
    m.legL.rotation.x = Math.sin(br.walk) * amp; m.legR.rotation.x = -Math.sin(br.walk) * amp;
    m.body.position.y = Math.abs(Math.sin(br.walk)) * 0.04 * amp;
    m.group.position.copy(b.pos);
    m.group.rotation.y = b.yaw;
    const wh = this.save.mods.wallhack && this.isEnemy(this.player, b);
    if (m.xray[0].visible !== wh) for (const x of m.xray) x.visible = wh;
    if (m.gun) { const L = d.len; m.gun.scale.z = d.type === 'knife' ? 0.4 : Math.max(0.4, L / 0.7); m.gun.position.z = -0.35 - L * 0.3; }
    // footsteps
    if (hs > 2 && Math.floor(br.walk / Math.PI) !== Math.floor((br.walk - hs * dt * 2.4) / Math.PI)) {
      const dd = b.pos.distanceTo(this.player.pos);
      if (dd < 16) audio.step(0.12 * (1 - dd / 16), this.panFor(b.pos));
    }
  }

  follow(b: Ent, tx: number, tz: number, dt: number) {
    const br = b.bot!;
    br.pathT -= dt;
    const key = Math.floor(tx / CELL) + ',' + Math.floor(tz / CELL);
    if (br.pathT <= 0 || br.pathGoal !== key) { br.path = this.findPath(b.pos.x, b.pos.z, tx, tz); br.pathT = 1.2 + Math.random() * 0.5; br.pathGoal = key; }
    while (br.path.length && Math.hypot(br.path[0].x - b.pos.x, br.path[0].z - b.pos.z) < 0.9) br.path.shift();
    const n = br.path[0] || { x: tx, z: tz };
    const dx = n.x - b.pos.x, dz = n.z - b.pos.z; const d = Math.hypot(dx, dz) || 1;
    return { x: dx / d, z: dz / d };
  }

  botFire(b: Ent, t: Ent, dist: number, moving: boolean) {
    const br = b.bot!; const d = this.def(b);
    if (br.reaction > 0 || br.reloadT > 0 || this.time < br.nextShot || this.phase === 'freeze' || this.phase === 'over') return;
    const a = b.ammo[d.id];
    if (!a || a.mag <= 0) { br.reloadT = d.reload; return; }
    const diff = this.cfg.difficulty;
    const rateMul = diff === 'easy' ? 0.5 : diff === 'normal' ? 0.7 : diff === 'hard' ? 0.85 : 1;
    br.nextShot = this.time + 1 / (d.fireRate * rateMul);
    br.burst++;
    if (d.auto && br.burst > 3 + Math.random() * 5) { br.burst = 0; br.nextShot += 0.25 + Math.random() * 0.4; }
    a.mag--;
    if (a.mag <= 0) br.reloadT = d.reload;
    let acc = ACC[diff] * Math.max(0.15, 1 - dist / (d.range * 1.1));
    if (d.type === 'sniper') acc = ACC[diff] * 1.4;
    if (d.type === 'shotgun') acc = dist < 8 ? 0.75 : dist < 16 ? 0.35 : 0.08;
    if (moving) acc *= 0.7;
    const tHs = Math.hypot(t.vel.x, t.vel.z);
    if (tHs > 2) acc *= 0.75;
    if (t.isPlayer && t.crouch) acc *= 0.85;
    const from = new THREE.Vector3(b.pos.x, b.pos.y + 1.4, b.pos.z);
    const tp = new THREE.Vector3(t.pos.x, t.pos.y + 1.2, t.pos.z);
    const hit = Math.random() < Math.min(0.92, acc);
    const end = tp.clone();
    if (hit) {
      const head = Math.random() < HSCH[diff];
      const fall = Math.max(0.5, 1 - dist / (d.range * 1.6));
      const pel = d.pellets ? Math.max(1, Math.round(d.pellets * (1 - dist / d.range))) : 1;
      this.damage(t, d.damage * pel * (head ? 4 : 1) * fall * (t.isPlayer ? 0.85 : 1), b, d, head);
      if (!t.isPlayer) this.blood(tp, tp.clone().sub(from).normalize(), 6);
    } else {
      end.x += (Math.random() - 0.5) * 2.4; end.y += (Math.random() - 0.3) * 1.6; end.z += (Math.random() - 0.5) * 2.4;
      const dir = end.clone().sub(from).normalize();
      const w = this.rayWorld(from, dir, 80);
      if (w) { end.copy(from).addScaledVector(dir, w.t); if (end.distanceTo(this.camera.position) < 40) this.impact(end, w.n, w.b ? w.b.tex : this.map.theme.floor, true); }
      else end.copy(from).addScaledVector(dir, 60);
    }
    const gunPos = from.clone().add(new THREE.Vector3(-Math.sin(b.yaw) * 0.7, -0.1, -Math.cos(b.yaw) * 0.7));
    this.addTracer(gunPos, end);
    this.fxAdd.spawn(gunPos.x, gunPos.y, gunPos.z, 0, 0, 0, 0.05, 0.5, 1, 0.8, 0.4, 0, 1, 0);
    const dd = b.pos.distanceTo(this.player.pos);
    audio.shot(d.snd, Math.max(0.05, 0.75 * (1 - dd / 90)), this.panFor(b.pos));
    if (dd < 45) b.spottedT = this.time;
  }

  separate() {
    const ents = this.ents;
    for (let i = 0; i < ents.length; i++) {
      const a = ents[i]; if (!a.alive) continue;
      for (let j = i + 1; j < ents.length; j++) {
        const b = ents[j]; if (!b.alive) continue;
        const dx = b.pos.x - a.pos.x, dz = b.pos.z - a.pos.z;
        const rr = a.radius + b.radius;
        const d2 = dx * dx + dz * dz;
        if (d2 >= rr * rr || d2 < 1e-6 || Math.abs(a.pos.y - b.pos.y) > 1.5) continue;
        const d = Math.sqrt(d2); const push = (rr - d) / 2;
        const nx = dx / d, nz = dz / d;
        a.pos.x -= nx * push; a.pos.z -= nz * push; b.pos.x += nx * push; b.pos.z += nz * push;
      }
    }
  }

  /* ================= FX ================= */
  addTracer(a: THREE.Vector3, b: THREE.Vector3) {
    const tr = this.tracers[this.tracerI = (this.tracerI + 1) % this.tracers.length];
    const len = a.distanceTo(b);
    if (len < 1) return;
    tr.m.position.copy(a);
    tr.m.lookAt(b);
    tr.m.scale.set(1, 1, len);
    tr.m.visible = true; tr.t = 0.07;
    (tr.m.material as THREE.MeshBasicMaterial).opacity = 0.9;
  }

  impact(p: THREE.Vector3, n: THREE.Vector3, tex: TexName, decal: boolean) {
    for (let i = 0; i < 5; i++) this.fxAdd.spawn(p.x, p.y, p.z, n.x * 3 + (Math.random() - 0.5) * 4, n.y * 3 + Math.random() * 3, n.z * 3 + (Math.random() - 0.5) * 4, 0.2 + Math.random() * 0.15, 0.06, 1, 0.8, 0.4, 14, 1, 0);
    const col = tex === 'sand' || tex === 'sandstone' || tex === 'plaster' ? [0.85, 0.72, 0.5] : tex === 'crate' ? [0.55, 0.4, 0.22] : tex === 'snow' || tex === 'snowWall' ? [0.95, 0.97, 1] : tex === 'grass' ? [0.4, 0.5, 0.25] : tex === 'brick' ? [0.6, 0.3, 0.22] : [0.6, 0.6, 0.6];
    for (let i = 0; i < 4; i++) this.fx.spawn(p.x, p.y, p.z, n.x * 1.5 + (Math.random() - 0.5), n.y * 1.5 + Math.random() * 0.8, n.z * 1.5 + (Math.random() - 0.5), 0.6 + Math.random() * 0.4, 0.2, col[0], col[1], col[2], 1.5, 0.6, 0.6);
    if (decal) {
      const d = this.decals[this.decalI = (this.decalI + 1) % this.decals.length];
      d.position.copy(p).addScaledVector(n, 0.012);
      d.lookAt(p.clone().add(n));
      d.rotateZ(Math.random() * 6);
      d.visible = true;
    }
  }

  blood(p: THREE.Vector3, dir: THREE.Vector3, n: number) {
    for (let i = 0; i < n; i++) {
      const s = 1 + Math.random() * 3;
      this.fx.spawn(p.x, p.y, p.z, dir.x * s + (Math.random() - 0.5) * 2, Math.random() * 2.5, dir.z * s + (Math.random() - 0.5) * 2, 0.4 + Math.random() * 0.4, 0.07 + Math.random() * 0.1, 0.55, 0.02, 0.02, 9, 1, 0.1);
    }
    this.fx.spawn(p.x, p.y, p.z, 0, 0.2, 0, 0.35, 0.35, 0.5, 0.03, 0.03, 0, 0.6, 1.2);
  }

  /* ================= LOOP ================= */
  loop = () => {
    if (!this.running) return;
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    let dt = (now - this.last) / 1000; this.last = now;
    this.fpsAcc += dt; this.fpsN++;
    if (this.fpsAcc > 0.5) { this.fps = Math.round(this.fpsN / this.fpsAcc); this.fpsAcc = 0; this.fpsN = 0; }
    dt = Math.min(dt, 0.05);
    if (!this.paused) this.update(dt);
    this.render();
  };

  update(dt: number) {
    this.time += dt;
    this.updateMode(dt);
    this.updatePlayer(dt);
    for (const e of this.ents) if (e.bot) this.updateBot(e, dt);
    this.separate();
    this.updateGrenades(dt);
    this.fx.update(dt); this.fxAdd.update(dt);
    for (const t of this.tracers) if (t.m.visible) { t.t -= dt; (t.m.material as THREE.MeshBasicMaterial).opacity = Math.max(0, t.t / 0.07) * 0.9; if (t.t <= 0) t.m.visible = false; }
    if (this.worldLight.intensity > 0) this.worldLight.intensity = Math.max(0, this.worldLight.intensity - dt * (this.worldLight.intensity > 5 ? 60 : 50));
    if (this.snow) {
      const pos = this.snow.geometry.attributes.position as THREE.BufferAttribute;
      const arr = pos.array as Float32Array; const sn = this.map.theme.snow;
      for (let i = 0; i < arr.length; i += 3) {
        arr[i + 1] -= dt * (sn ? 2 : 0.15); arr[i] += dt * (sn ? Math.sin(this.time + i) * 0.4 : 0.6);
        if (arr[i + 1] < 0) arr[i + 1] = 20;
        if (arr[i] > this.pm.w * CELL) arr[i] = 0;
      }
      pos.needsUpdate = true;
    }
    this.updateCamera(dt);
    this.updateViewmodel(dt);
    this.hudT -= dt;
    if (this.hudT <= 0) { this.hudT = 0.07; this.cb.onHud(this.hud()); }
  }

  updateCamera(dt: number) {
    const p = this.player; const cam = this.camera; const d = this.def(p);
    this.kick *= Math.exp(-dt * 7); this.kickYaw *= Math.exp(-dt * 7);
    if (this.kick > 0.0001) { const rec = this.kick * dt * 6; p.pitch = Math.min(1.5, p.pitch + rec * 0.5); }
    this.shake *= Math.exp(-dt * 6);
    if (p.alive) {
      const eyeH = p.crouch ? 1.15 : 1.62;
      const curY = cam.position.y;
      const targetY = p.pos.y + eyeH + Math.abs(Math.sin(this.bob)) * 0.045 - 0.02;
      cam.position.set(p.pos.x, Math.abs(curY - targetY) > 1.5 ? targetY : curY + (targetY - curY) * Math.min(1, dt * 18), p.pos.z);
      cam.rotation.set(p.pitch + this.kick * 0.6 + (Math.random() - 0.5) * this.shake * 0.05, p.yaw + this.kickYaw + (Math.random() - 0.5) * this.shake * 0.05, Math.sin(this.bob) * 0.004);
    } else if (this.spectate && this.spectate.alive && !this.rules.respawn) {
      const s = this.spectate;
      const back = new THREE.Vector3(Math.sin(s.yaw) * 3, 2.3, Math.cos(s.yaw) * 3);
      cam.position.lerp(s.pos.clone().add(back), Math.min(1, dt * 6));
      cam.lookAt(s.pos.x, s.pos.y + 1.4, s.pos.z);
    } else {
      cam.position.y += (p.pos.y + 0.35 - cam.position.y) * Math.min(1, dt * 4);
      cam.rotation.z += (0.5 - cam.rotation.z) * Math.min(1, dt * 3);
    }
    let fov = this.baseFov;
    if (p.alive && this.aiming) fov = d.scope ? d.scope : this.baseFov * 0.8;
    if (Math.abs(cam.fov - fov) > 0.05) { cam.fov += (fov - cam.fov) * Math.min(1, dt * (d.scope ? 30 : 14)); cam.updateProjectionMatrix(); this.updatePScale(); }
    this.sky.position.copy(cam.position);
  }

  updateViewmodel(dt: number) {
    const p = this.player; const d = this.def(p); const vm = this.vmRoot;
    vm.visible = p.alive && !(this.aiming && d.scope && this.camera.fov < this.baseFov * 0.6) && this.phase !== 'over';
    if (!vm.visible) { this.flash.visible = false; return; }
    const hip = d.type === 'pistol' ? [0.15, -0.16, -0.34] : d.type === 'knife' ? [0.17, -0.2, -0.33] : d.type === 'grenade' ? [0.16, -0.18, -0.3] : [0.17, -0.17, -0.36];
    const aimP = d.type === 'pistol' ? [0, -0.105, -0.3] : [0, -0.11, -0.3];
    const ads = this.aiming && !d.scope ? 1 : 0;
    const tx = hip[0] + (aimP[0] - hip[0]) * ads, ty = hip[1] + (aimP[1] - hip[1]) * ads, tz = hip[2] + (aimP[2] - hip[2]) * ads;
    const moveAmt = Math.min(1, Math.hypot(p.vel.x, p.vel.z) / 6) * (ads ? 0.25 : 1);
    this.swayX *= Math.exp(-dt * 8); this.swayY *= Math.exp(-dt * 8);
    this.vmKick *= Math.exp(-dt * 12);
    let x = tx + Math.sin(this.bob) * 0.012 * moveAmt - this.swayX * 0.5;
    let y = ty - Math.abs(Math.cos(this.bob)) * 0.01 * moveAmt + this.swayY * 0.5;
    let z = tz + this.vmKick * 0.06;
    let rx = this.vmKick * 0.12, ry = this.swayX * 2, rz = this.swayX * 1.5;
    if (this.drawT > 0) { const k = this.drawT / 0.45; y -= k * k * 0.25; rx -= k * 0.8; }
    if (this.reloadT > 0) { const k = 1 - this.reloadT / this.reloadDur; const s = Math.sin(Math.min(1, k) * Math.PI); y -= s * 0.08; rx -= s * 0.5; rz += s * 0.35; if (this.vmGun?.mag) this.vmGun.mag.position.y += 0; }
    if (this.knifeT > 0) { const k = 1 - this.knifeT / 0.35; const s = Math.sin(k * Math.PI); x -= s * 0.12; z -= s * 0.1; ry += s * 1.0; rz -= s * 0.6; rx -= s * 0.3; }
    if (this.throwT > 0) { const k = 1 - this.throwT / 0.5; y -= Math.sin(k * Math.PI) * 0.1; z -= k * 0.15; rx += k * 1.2; }
    if (!p.onGround) y += 0.015;
    if (p.crouch) { x -= 0.01; rz += 0.05; }
    vm.position.x += (x - vm.position.x) * Math.min(1, dt * 22);
    vm.position.y += (y - vm.position.y) * Math.min(1, dt * 22);
    vm.position.z += (z - vm.position.z) * Math.min(1, dt * 30);
    vm.rotation.set(rx, ry, rz);
    if (this.flashT > 0) { this.flashT -= dt; this.flash.visible = true; } else this.flash.visible = false;
  }

  render() {
    const r = this.renderer;
    r.clear();
    r.render(this.scene, this.camera);
    r.clearDepth();
    r.render(this.vmScene, this.vmCam);
    this.radarFrame++;
    if (this.radarCtx && this.radarFrame % 2 === 0) this.drawRadar(this.radarCtx);
  }

  /* ================= HUD ================= */
  hud(): HudState {
    const p = this.player; const d = this.def(p); const a = p.ammo[d.id];
    const m = this.cfg.mode;
    let scoreA = 0, scoreB = 0, labelA = '', labelB = '', colorA = TEAM_COL.ct, colorB = TEAM_COL.t;
    let aliveA = 0, aliveB = 0;
    if (this.rules.teams && m !== 'zombie') {
      const src = this.rules.rounds ? this.scores : this.teamKills;
      scoreA = src.ct; scoreB = src.t; labelA = 'ضدتروریست'; labelB = 'تروریست';
      aliveA = this.ents.filter(e => e.team === 'ct' && e.alive).length; aliveB = this.ents.filter(e => e.team === 't' && e.alive).length;
    } else if (m === 'zombie') {
      scoreA = this.wave; scoreB = this.ents.filter(e => e.team === 'z' && e.alive).length + this.spawnLeft;
      labelA = 'موج'; labelB = 'زامبی'; colorB = TEAM_COL.z;
      aliveA = this.ents.filter(e => e.team === 'ct' && e.alive).length; aliveB = scoreB;
    } else {
      const sorted = [...this.ents].sort((x, y) => m === 'armsrace' ? y.armsLevel - x.armsLevel : y.kills - x.kills);
      const lead = sorted[0];
      scoreA = m === 'armsrace' ? p.armsLevel : p.kills; scoreB = m === 'armsrace' ? lead.armsLevel : lead.kills;
      labelA = 'شما'; labelB = lead.isPlayer ? 'نفر اول' : lead.name; colorA = '#ffd000'; colorB = '#ff5a5a';
    }
    if (this.center && this.time > this.centerUntil) this.center = null;
    const rows: ScoreRow[] = this.ents.filter(e => !e.bot?.zombie).map(e => ({
      name: e.name, team: e.team, color: e.isPlayer ? '#ffd000' : this.rules.teams ? TEAM_COL[e.team] : e.color,
      kills: e.kills, deaths: e.deaths, alive: e.alive, me: e.isPlayer, score: m === 'armsrace' ? e.armsLevel : e.kills * 2 + e.hs,
    })).sort((x, y) => y.score - x.score);
    const hs = Math.hypot(p.vel.x, p.vel.z);
    let spread = d.spread + Math.min(1, hs / 6) * d.moveSpread + (p.onGround ? 0 : 0.08) + Math.min(this.spray, 10) * 0.003;
    if (this.save.mods.noRecoil) spread = 0;
    return {
      hp: Math.max(0, Math.ceil(p.hp)), armor: Math.ceil(p.armor), helmet: p.helmet, money: this.save.mods.infMoney ? 99999 : p.money,
      weaponId: d.id, weaponName: d.name, mag: a ? a.mag : 0, res: a ? a.res : 0, grenades: p.grenades,
      slots: [...p.weapons], curSlot: p.cur,
      reload: this.reloadT > 0 ? 1 - this.reloadT / this.reloadDur : -1,
      scoped: this.aiming && !!d.scope && this.camera.fov < this.baseFov * 0.6, aiming: this.aiming, spread,
      timer: Math.max(0, this.timer), phase: this.phase, round: this.round,
      scoreA, scoreB, labelA, labelB, colorA, colorB, aliveA, aliveB,
      killfeed: this.killfeed.filter(k => this.time - k.t < 7).map(k => ({ ...k })),
      center: this.center,
      dead: !p.alive, respawnIn: this.rules.respawn ? Math.max(0, p.respawnT) : -1,
      canBuy: this.canBuy(), buyMode: this.rules.buy,
      hitT: this.hitT, hitHead: this.hitHead, killT: this.killT, dmgT: this.dmgT, dmgDir: this.dmgDir,
      fps: this.fps, mode: m, wave: this.wave, armsLevel: p.armsLevel, armsTotal: ARMS_RACE.length,
      rows, crouch: p.crouch, spectating: !p.alive && this.spectate ? this.spectate.name : '',
      streak: this.streak, streakT: this.streakT,
    };
  }

  setRadar(c: HTMLCanvasElement | null) { this.radarCtx = c ? c.getContext('2d') : null; }

  drawRadar(ctx: CanvasRenderingContext2D) {
    const S = ctx.canvas.width; const p = this.player;
    const R = 32; const sc = S / (R * 2);
    ctx.clearRect(0, 0, S, S);
    ctx.save();
    ctx.beginPath(); ctx.arc(S / 2, S / 2, S / 2 - 1, 0, Math.PI * 2); ctx.clip();
    ctx.fillStyle = 'rgba(10,14,12,0.72)'; ctx.fillRect(0, 0, S, S);
    ctx.translate(S / 2, S / 2);
    ctx.rotate(p.yaw);
    ctx.scale(sc, sc);
    const cx = this.spectate && !p.alive ? this.spectate.pos.x : p.pos.x, cz = this.spectate && !p.alive ? this.spectate.pos.z : p.pos.z;
    for (const b of this.boxes) {
      if (b.maxX < cx - R * 1.5 || b.minX > cx + R * 1.5 || b.maxZ < cz - R * 1.5 || b.minZ > cz + R * 1.5) continue;
      ctx.fillStyle = b.kind === 'crate' || b.kind === 'container' ? 'rgba(170,140,90,0.75)' : b.kind === 'low' ? 'rgba(150,150,150,0.6)' : 'rgba(200,200,190,0.85)';
      ctx.fillRect(b.minX - cx, b.minZ - cz, b.maxX - b.minX, b.maxZ - b.minZ);
    }
    for (const e of this.ents) {
      if (!e.alive || e.isPlayer) continue;
      const enemy = this.isEnemy(p, e);
      if (enemy && this.time - e.spottedT > 1.5 && !this.save.mods.wallhack) continue;
      ctx.fillStyle = enemy ? (e.team === 'z' ? '#7dff3a' : '#ff3b3b') : TEAM_COL[e.team] || '#5aa9ff';
      ctx.beginPath(); ctx.arc(e.pos.x - cx, e.pos.z - cz, 1.1, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
    // player arrow
    ctx.save(); ctx.translate(S / 2, S / 2);
    ctx.fillStyle = '#ffd000'; ctx.strokeStyle = '#000'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(0, -8); ctx.lineTo(6, 6); ctx.lineTo(0, 3); ctx.lineTo(-6, 6); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(S / 2, S / 2, S / 2 - 2, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.font = 'bold 11px sans-serif'; ctx.textAlign = 'center';
    ctx.save(); ctx.translate(S / 2, S / 2); ctx.rotate(p.yaw); ctx.fillText('N', 0, -S / 2 + 13); ctx.restore();
  }

  dispose() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    for (const [t, ev, fn, opt] of this.listeners) t.removeEventListener(ev, fn, opt);
    if (document.pointerLockElement) document.exitPointerLock();
    this.scene.traverse(o => { const m = o as THREE.Mesh; if (m.geometry) m.geometry.dispose(); });
    this.renderer.dispose();
  }
}
