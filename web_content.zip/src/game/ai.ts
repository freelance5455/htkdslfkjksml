import * as THREE from 'three';
import type { World } from './world';
import type { DifficultyDef, ModeId } from './data/content';
import { type WeaponDef } from './data/weapons';
import { buildSoldier, animateSoldier, type SoldierRefs, type SoldierColors } from './models';

export interface Actor {
  id: number; team: number; name: string; pos: THREE.Vector3; vel: THREE.Vector3; height: number;
  alive: boolean; health: number; maxHealth: number; armor: number; isPlayer: boolean; lastFiredAt: number; crouching: boolean; kills: number;
}
export interface Noise { x: number; y: number; z: number; radius: number; time: number; team: number }
export interface AIContext {
  world: World; time: number; actors: Actor[]; diff: DifficultyDef; mode: ModeId; patrol: THREE.Vector3[]; noises: Noise[];
  zone: { x: number; z: number; r: number } | null;
  botFire(bot: Bot, ox: number, oy: number, oz: number, dx: number, dy: number, dz: number): void;
  budget: { paths: number; cover: number };
  onFootstep(bot: Bot): void;
}

type State = 'patrol' | 'investigate' | 'engage' | 'search' | 'cover' | 'retreat';
const tmpV = new THREE.Vector3(), tmpA = new THREE.Vector3(), tmpB = new THREE.Vector3();
let nextId = 100;

export class Bot implements Actor {
  id = nextId++; isPlayer = false; team: number; name: string;
  pos = new THREE.Vector3(); vel = new THREE.Vector3(); height = 1.8; alive = true; health = 100; maxHealth = 100; armor = 0; lastFiredAt = -10; crouching = false; kills = 0;
  weapon: WeaponDef; mag: number; reloadT = 0; fireCD = 0; burstLeft = 0; burstPause = 0;
  state: State = 'patrol'; target: Actor | null = null; targetVisible = false; lastKnown = new THREE.Vector3(); lastSeen = -100;
  reactionT = 0; settle = 2.5; perceiveT = Math.random() * 0.2; stateT = 0; strafeDir = 1; strafeT = 0;
  path: { x: number; z: number }[] | null = null; pathGoal = new THREE.Vector3(); repathT = 0; stuckT = 0; lastPos = new THREE.Vector3();
  coverPt: THREE.Vector3 | null = null; lastDamage = -100; medkits = 2; deadT = 0; yaw = 0; aimPitch = 0; phase = 0; stepT = 0;
  ground = { onGround: true }; refs: SoldierRefs; lastNoise = 0; hitFlash = 0; respawnAt = 0; home: THREE.Vector3 | null = null;

  constructor(team: number, name: string, weapon: WeaponDef, colors: SoldierColors, scene: THREE.Scene, health: number) {
    this.team = team; this.name = name; this.weapon = weapon; this.mag = weapon.mag; this.health = this.maxHealth = health;
    this.refs = buildSoldier(colors); scene.add(this.refs.root);
  }
  get eye() { return tmpA.set(this.pos.x, this.pos.y + this.height - 0.15, this.pos.z); }
  get headY() { return this.pos.y + this.height - 0.14; }

  spawn(p: THREE.Vector3) {
    this.pos.copy(p); this.vel.set(0, 0, 0); this.alive = true; this.health = this.maxHealth; this.armor = 0; this.deadT = 0;
    this.state = 'patrol'; this.target = null; this.path = null; this.mag = this.weapon.mag; this.reloadT = 0; this.coverPt = null;
    this.refs.root.visible = true; this.yaw = Math.random() * Math.PI * 2; this.medkits = 2; this.home = p.clone();
  }

  /** Called when damaged — reveals approximate attacker direction */
  onDamaged(from: Actor | null, time: number) {
    this.lastDamage = time; this.hitFlash = 0.15;
    if (from && from.team !== this.team) {
      if (!this.target || !this.targetVisible) {
        this.target = from; this.lastKnown.copy(from.pos).add(tmpV.set((Math.random() - 0.5) * 4, 0, (Math.random() - 0.5) * 4));
        if (this.state !== 'engage') { this.state = 'search'; this.stateT = 0; this.path = null; }
        this.yaw = Math.atan2(-(from.pos.x - this.pos.x), -(from.pos.z - this.pos.z));
      }
    }
  }
  alert(p: THREE.Vector3) {
    if (this.state === 'engage' || this.state === 'cover' || this.state === 'retreat') return;
    this.state = 'investigate'; this.lastKnown.copy(p); this.path = null; this.stateT = 0;
  }

  update(dt: number, ctx: AIContext) {
    const r = this.refs;
    if (!this.alive) { this.deadT += dt; animateSoldier(r, 0, 0, 0, 0, this.deadT); if (this.deadT > 6) r.root.visible = false; return; }
    this.stateT += dt; this.fireCD -= dt; this.hitFlash = Math.max(0, this.hitFlash - dt);
    if (this.reloadT > 0) { this.reloadT -= dt; if (this.reloadT <= 0) this.mag = this.weapon.mag; }
    this.perceiveT -= dt;
    if (this.perceiveT <= 0) { this.perceiveT = 0.14 + Math.random() * 0.1; this.perceive(ctx); }
    this.hear(ctx);

    // regen / heal when safe
    if (ctx.time - this.lastDamage > 4 && this.health < this.maxHealth) {
      if (ctx.mode !== 'br') this.health = Math.min(this.maxHealth, this.health + 12 * dt);
      else if (this.medkits > 0 && this.health < 50 && this.state !== 'engage') { this.medkits--; this.health = this.maxHealth; }
    }

    let speed = 0; let goal: THREE.Vector3 | null = null; let faceTarget = false;
    const d = ctx.diff;
    const lowHp = this.health < this.maxHealth * 0.35;
    switch (this.state) {
      case 'patrol': {
        speed = 2.6;
        if (!this.path || this.path.length === 0 || this.stateT > 25) {
          const pts = ctx.patrol; const p = pts[Math.floor(Math.random() * pts.length)];
          if (p) this.setGoal(p, ctx); this.stateT = 0;
        }
        goal = this.pathGoal; break;
      }
      case 'investigate': speed = 4.2; goal = this.lastKnown; if (this.pos.distanceTo(this.lastKnown) < 2 || this.stateT > 15) { this.state = 'search'; this.stateT = 0; } break;
      case 'search': {
        speed = 3.4; goal = this.lastKnown;
        if (this.pos.distanceTo(this.lastKnown) < 2.5) { this.lastKnown.x += (Math.random() - 0.5) * 14; this.lastKnown.z += (Math.random() - 0.5) * 14; this.path = null; }
        if (this.stateT > 10) { this.state = 'patrol'; this.target = null; this.path = null; this.stateT = 0; }
        break;
      }
      case 'engage': {
        if (!this.target || !this.target.alive) { this.target = null; this.state = 'search'; this.stateT = 0; break; }
        faceTarget = true;
        if (!this.targetVisible && ctx.time - this.lastSeen > 0.8) { this.state = 'search'; this.stateT = 0; this.path = null; break; }
        if ((lowHp || (this.reloadT > 0 && Math.random() < 0.02)) && ctx.budget.cover > 0 && this.stateT > 0.8) {
          ctx.budget.cover--; const c = this.findCover(ctx, this.target, lowHp ? 16 : 9);
          if (c) { this.coverPt = c; this.state = lowHp ? 'retreat' : 'cover'; this.stateT = 0; this.setGoal(c, ctx); break; }
        }
        // strafe & range keeping
        const pref = { AR: 20, SMG: 11, SG: 6, LMG: 24, MR: 32, SR: 45, PISTOL: 12 }[this.weapon.category];
        const toT = tmpB.subVectors(this.target.pos, this.pos); toT.y = 0; const dist = toT.length(); toT.normalize();
        this.strafeT -= dt; if (this.strafeT <= 0) { this.strafeDir = Math.random() > 0.5 ? 1 : -1; this.strafeT = 0.8 + Math.random() * 1.6; }
        const fwd = dist > pref * 1.3 ? 1 : dist < pref * 0.6 ? -0.7 : 0;
        const mvx = toT.x * fwd + -toT.z * this.strafeDir * 0.8, mvz = toT.z * fwd + toT.x * this.strafeDir * 0.8;
        if (!this.targetVisible) { goal = this.lastKnown; speed = 3.8; }
        else {
          const tx = this.pos.x + mvx * 1.2, tz = this.pos.z + mvz * 1.2;
          if (!ctx.world.walkable(tx, tz)) this.strafeDir *= -1;
          const ml = Math.hypot(mvx, mvz) || 1; const sp = this.reloadT > 0 ? 2.2 : 2.6;
          this.vel.x = THREE.MathUtils.lerp(this.vel.x, (mvx / ml) * sp * Math.min(1, ml), Math.min(1, dt * 6));
          this.vel.z = THREE.MathUtils.lerp(this.vel.z, (mvz / ml) * sp * Math.min(1, ml), Math.min(1, dt * 6));
          speed = -1; // manual velocity
        }
        this.tryShoot(dt, ctx);
        break;
      }
      case 'cover': case 'retreat': {
        speed = 4.8; goal = this.coverPt; if (this.target) faceTarget = this.targetVisible;
        if (this.coverPt && this.pos.distanceTo(this.coverPt) < 1.2) {
          speed = 0; this.crouching = true;
          if (this.mag < this.weapon.mag * 0.5 && this.reloadT <= 0) this.reloadT = this.weapon.reload * 1.1;
          const wait = this.state === 'retreat' ? 4 : 1.8;
          if (this.stateT > wait && this.reloadT <= 0) { this.crouching = false; this.state = this.target ? 'engage' : 'search'; this.stateT = 0; }
        }
        if (this.targetVisible) this.tryShoot(dt, ctx);
        if (this.stateT > 9) { this.state = 'search'; this.stateT = 0; this.crouching = false; }
        break;
      }
    }
    if (this.state !== 'cover' && this.state !== 'retreat') this.crouching = false;

    // Battle royale: move inside the safe zone
    if (ctx.zone && this.state !== 'engage') {
      const dz = Math.hypot(this.pos.x - ctx.zone.x, this.pos.z - ctx.zone.z);
      if (dz > ctx.zone.r * 0.85) {
        const k = (ctx.zone.r * 0.5) / Math.max(1, dz);
        tmpV.set(ctx.zone.x + (this.pos.x - ctx.zone.x) * k, 0, ctx.zone.z + (this.pos.z - ctx.zone.z) * k);
        if (!this.path || this.pathGoal.distanceTo(tmpV) > 10) this.setGoal(tmpV.clone(), ctx);
        goal = this.pathGoal; speed = 4.6;
      }
    }

    // path following
    if (speed > 0 && goal) {
      if (this.pathGoal.distanceToSquared(goal) > 4 || !this.path) this.setGoal(goal, ctx);
      const wp = this.path && this.path[0];
      if (wp) {
        const dx = wp.x - this.pos.x, dz = wp.z - this.pos.z; const dl = Math.hypot(dx, dz);
        if (dl < 0.9) this.path!.shift();
        else { this.vel.x = THREE.MathUtils.lerp(this.vel.x, (dx / dl) * speed, Math.min(1, dt * 8)); this.vel.z = THREE.MathUtils.lerp(this.vel.z, (dz / dl) * speed, Math.min(1, dt * 8)); }
      } else { this.vel.x *= 0.8; this.vel.z *= 0.8; }
    } else if (speed === 0) { this.vel.x *= 0.7; this.vel.z *= 0.7; }

    // stuck detection
    this.repathT -= dt;
    if (this.repathT <= 0) {
      this.repathT = 1;
      if (this.pos.distanceTo(this.lastPos) < 0.3 && Math.hypot(this.vel.x, this.vel.z) > 0.5) { this.stuckT++; this.path = null; if (this.stuckT > 2) { this.vel.x = (Math.random() - 0.5) * 6; this.vel.z = (Math.random() - 0.5) * 6; this.stuckT = 0; } }
      else this.stuckT = 0;
      this.lastPos.copy(this.pos);
    }
    this.height = this.crouching ? 1.25 : 1.8;
    ctx.world.moveCharacter(this.pos, this.vel, 0.38, this.height, dt, this.ground);

    // facing
    let wantYaw = this.yaw;
    if (faceTarget && this.target) { wantYaw = Math.atan2(-(this.target.pos.x - this.pos.x), -(this.target.pos.z - this.pos.z)); const dy = this.target.pos.y + 1.2 - (this.pos.y + 1.5); this.aimPitch = Math.atan2(dy, Math.hypot(this.target.pos.x - this.pos.x, this.target.pos.z - this.pos.z)); }
    else if (Math.hypot(this.vel.x, this.vel.z) > 0.5) { wantYaw = Math.atan2(-this.vel.x, -this.vel.z); this.aimPitch *= 0.9; }
    let dyaw = wantYaw - this.yaw; while (dyaw > Math.PI) dyaw -= Math.PI * 2; while (dyaw < -Math.PI) dyaw += Math.PI * 2;
    this.yaw += dyaw * Math.min(1, dt * (4 + (130 - d.fov) * -0.02 + (1 - d.reaction) * 6));

    // animation + footsteps
    const sp = Math.hypot(this.vel.x, this.vel.z);
    this.phase += sp * dt * 2.4;
    r.root.position.copy(this.pos); r.root.rotation.y = this.yaw;
    animateSoldier(r, this.phase, sp, this.aimPitch, this.crouching ? 1 : 0, 0);
    this.stepT -= dt * sp; if (this.stepT <= 0) { this.stepT = 1.6; if (sp > 1) ctx.onFootstep(this); }
  }

  private setGoal(g: THREE.Vector3, ctx: AIContext) {
    this.pathGoal.copy(g);
    if (ctx.world.gridLine(this.pos.x, this.pos.z, g.x, g.z)) { this.path = [{ x: g.x, z: g.z }]; return; }
    if (ctx.budget.paths <= 0) { this.path = this.path ?? [{ x: g.x, z: g.z }]; return; }
    ctx.budget.paths--;
    this.path = ctx.world.findPath(this.pos.x, this.pos.z, g.x, g.z) ?? [{ x: g.x, z: g.z }];
  }

  private perceive(ctx: AIContext) {
    const d = ctx.diff; const eye = tmpA.set(this.pos.x, this.pos.y + this.height - 0.15, this.pos.z);
    let best: Actor | null = null; let bestD = Infinity;
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw); const cosHalf = Math.cos(THREE.MathUtils.degToRad(d.fov / 2));
    for (const a of ctx.actors) {
      if (!a.alive || a.team === this.team || a === (this as Actor)) continue;
      const dx = a.pos.x - this.pos.x, dz = a.pos.z - this.pos.z; const dist = Math.hypot(dx, dz);
      const range = d.vision * (a.crouching ? 0.7 : 1) * (a === this.target ? 1.3 : 1);
      if (dist > range) continue;
      const dot = (dx * fx + dz * fz) / Math.max(0.01, dist);
      const flashed = ctx.time - a.lastFiredAt < 0.4 && dist < range * 0.8;
      if (dot < cosHalf && dist > 4 && !flashed && a !== this.target) continue;
      tmpV.set(a.pos.x, a.pos.y + a.height * 0.75, a.pos.z);
      if (!ctx.world.lineOfSight(eye, tmpV)) { tmpV.y = a.pos.y + a.height - 0.12; if (!ctx.world.lineOfSight(eye, tmpV)) continue; }
      if (dist < bestD) { bestD = dist; best = a; }
    }
    const was = this.targetVisible;
    if (best) {
      if (best !== this.target || !was) {
        if (best !== this.target || ctx.time - this.lastSeen > 2) { this.reactionT = d.reaction * (0.8 + Math.random() * 0.5); this.settle = 2.5; }
        this.target = best;
        // alert nearby squadmates (basic coordination)
        for (const o of ctx.actors) if (o instanceof Bot && o !== this && o.alive && o.team === this.team && o.pos.distanceTo(this.pos) < 28) o.alert(best.pos);
      }
      this.targetVisible = true; this.lastSeen = ctx.time; this.lastKnown.copy(best.pos);
      if (this.state === 'patrol' || this.state === 'investigate' || this.state === 'search') { this.state = 'engage'; this.stateT = 0; }
    } else this.targetVisible = false;
  }

  private hear(ctx: AIContext) {
    if (this.state === 'engage' && this.targetVisible) return;
    for (let i = ctx.noises.length - 1; i >= 0; i--) {
      const n = ctx.noises[i]; if (n.time <= this.lastNoise) break;
      if (n.team === this.team) continue;
      const dist = Math.hypot(n.x - this.pos.x, n.z - this.pos.z);
      if (dist < n.radius) { // investigates approximate position, never exact
        const err = dist * 0.15; tmpV.set(n.x + (Math.random() - 0.5) * err, n.y, n.z + (Math.random() - 0.5) * err);
        this.alert(tmpV.clone()); break;
      }
    }
    if (ctx.noises.length) this.lastNoise = ctx.noises[ctx.noises.length - 1].time;
  }

  private tryShoot(dt: number, ctx: AIContext) {
    const t = this.target; if (!t || !this.targetVisible) return;
    if (this.reactionT > 0) { this.reactionT -= dt * 1.0; return; }
    this.settle = Math.max(1, this.settle - dt * 1.5);
    if (this.reloadT > 0) return;
    if (this.mag <= 0) { this.reloadT = this.weapon.reload * 1.1; return; }
    if (this.burstPause > 0) { this.burstPause -= dt; return; }
    if (this.fireCD > 0) return;
    const w = this.weapon;
    this.fireCD = Math.max(60 / w.rpm, w.mode === 'semi' ? 0.22 : w.mode === 'bolt' ? 1.2 : 0);
    if (this.burstLeft <= 0) this.burstLeft = w.mode === 'auto' ? 3 + Math.floor(Math.random() * 6) : 1 + Math.floor(Math.random() * 3);
    this.burstLeft--; if (this.burstLeft <= 0) this.burstPause = 0.25 + Math.random() * 0.6 + (w.mode === 'semi' ? 0.3 : 0);
    this.mag--; this.lastFiredAt = ctx.time;
    const o = tmpA.set(this.pos.x, this.pos.y + this.height - 0.35, this.pos.z);
    const dist = o.distanceTo(t.pos);
    const aimY = Math.random() < 0.12 ? t.pos.y + t.height - 0.12 : t.pos.y + t.height * 0.62;
    const dir = tmpB.set(t.pos.x - o.x, aimY - o.y, t.pos.z - o.z).normalize();
    const tSpeed = Math.hypot(t.vel.x, t.vel.z), mySpeed = Math.hypot(this.vel.x, this.vel.z);
    const errDeg = ctx.diff.aimError * this.settle * (1 + tSpeed * 0.1) * (1 + mySpeed * 0.08) * (dist > w.range ? 1.25 : 1) * (t.crouching ? 1.15 : 1);
    const e = THREE.MathUtils.degToRad(errDeg);
    dir.x += (Math.random() - 0.5) * 2 * e; dir.y += (Math.random() - 0.5) * 2 * e * 0.8; dir.z += (Math.random() - 0.5) * 2 * e; dir.normalize();
    for (let p = 0; p < w.pellets; p++) {
      const s = w.pellets > 1 ? THREE.MathUtils.degToRad(w.spreadHip) : 0;
      ctx.botFire(this, o.x, o.y, o.z, dir.x + (Math.random() - 0.5) * s, dir.y + (Math.random() - 0.5) * s, dir.z + (Math.random() - 0.5) * s);
    }
  }

  private findCover(ctx: AIContext, threat: Actor, maxR: number): THREE.Vector3 | null {
    const te = tmpV.set(threat.pos.x, threat.pos.y + 1.5, threat.pos.z).clone();
    let best: THREE.Vector3 | null = null; let bestScore = Infinity;
    for (const rad of [3, 6, maxR]) for (let k = 0; k < 10; k++) {
      const a = (k / 10) * Math.PI * 2 + Math.random() * 0.3;
      const x = this.pos.x + Math.cos(a) * rad, z = this.pos.z + Math.sin(a) * rad;
      if (!ctx.world.walkable(x, z)) continue;
      const y = ctx.world.ground(x, z);
      const p = new THREE.Vector3(x, y + 1.0, z);
      if (ctx.world.lineOfSight(te, p)) continue;
      const score = rad + (p.distanceTo(te) < 6 ? 20 : 0);
      if (score < bestScore) { bestScore = score; best = new THREE.Vector3(x, y, z); }
    }
    return best;
  }

  dispose(scene: THREE.Scene) { scene.remove(this.refs.root); }
}
