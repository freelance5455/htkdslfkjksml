import { UNITS, BLD, ERAS, FACS, POW, fmOf, trainList, POP_CAP } from './data';
import type { World, Player, Ent } from './world';

const SEQ = ['rax', 'tow', 'fac', 'rax', 'air', 'tow', 'fac', 'air', 'tow', 'rax', 'fac', 'tow'];

export function aiTick(w: World, p: Player, dt: number) {
  p.aiT -= dt; if (p.aiT > 0) return; p.aiT = 1.1 - p.ai * 0.2;
  const fm = fmOf(p.fac), f = FACS[p.fac], era = ERAS[w.era];
  const my = w.byOwner(p.idx);
  const hq = my.find(e => e.t === 'hq'); if (!hq) return;
  const wks = my.filter(e => UNITS[e.t]?.cls === 'wk');
  const army = my.filter(e => !e.b && !e.mine && UNITS[e.t].cls !== 'wk');
  const count = (t: string) => my.filter(e => e.t === t).length;

  // workers
  const wantW = [6, 8, 10][p.ai] ?? 8; const wq = hq.q.length;
  if (wks.length + wq < wantW && wq < 2) {
    const c = Math.round(UNITS[era.wk].cost * fm.cost); if (p.res >= c) w.exec(p.idx, { k: 'train', b: hq.id, u: era.wk });
  }

  // building
  const unf = my.filter(e => e.b && e.cons < 1);
  if (unf.length === 0 && wks.length) {
    const have: Record<string, number> = {}; let next = '';
    for (const t of SEQ) {
      if (!era.bn[t]) continue; if (t === 'air' && !f.air.length) continue;
      have[t] = (have[t] || 0) + 1; if (count(t) < have[t]) { next = t; break; }
    }
    if (next && p.res >= Math.round(BLD[next].cost * fm.cost) + 60) {
      for (let k = 0; k < 14; k++) {
        const a = w.rnd() * Math.PI * 2, r = 13 + w.rnd() * 18 + (next === 'tow' ? 8 : 0);
        const x = hq.x + Math.cos(a) * r, z = hq.z + Math.sin(a) * r;
        if (!w.canPlace(next, x, z, p.idx)) {
          let bw: Ent | null = null, bd = 1e9; for (const u of wks) { const d = Math.hypot(u.x - x, u.z - z); if (d < bd) { bd = d; bw = u; } }
          if (bw) w.exec(p.idx, { k: 'build', t: next, x, z, ids: [bw.id] }); break;
        }
      }
    }
  } else if (unf.length) {
    for (const b of unf) {
      if (!wks.some(u => u.bid === b.id && u.ord === 5) && wks.length) {
        let bw: Ent | null = null, bd = 1e9; for (const u of wks) { const d = Math.hypot(u.x - b.x, u.z - b.z); if (d < bd) { bd = d; bw = u; } }
        if (bw) w.exec(p.idx, { k: 'help', b: b.id, ids: [bw.id] });
      }
    }
  }

  // training
  for (const b of my) {
    if (!b.b || b.cons < 1 || b.t === 'hq' || b.t === 'tow' || b.q.length >= 2) continue;
    const list = trainList(p.fac, b.t); if (!list.length) continue;
    const afford = list.filter(u => p.res >= Math.round(UNITS[u].cost * fm.cost));
    if (!afford.length || p.pop + b.q.length >= POP_CAP) continue;
    // keep some anti-air if enemy has air
    const pick = afford[Math.floor(w.rnd() * afford.length)];
    w.exec(p.idx, { k: 'train', b: b.id, u: pick });
  }

  // defense
  const hit = my.find(e => e.b && w.time - e.lastHit < 4);
  if (hit && army.length) {
    for (const u of army) if (u.ord === 0 || u.ord === 2 && !u.auto) w.exec(p.idx, { k: 'amove', ids: [u.id], x: hit.x, z: hit.z });
  }

  // attack waves
  const enemies = w.players.filter(q => q.alive && q.idx !== p.idx);
  if (enemies.length) {
    let target: Ent | null = null, td = 1e9;
    w.ents.forEach(e => { if (e.t === 'hq' && e.hp > 0 && e.own !== p.idx && w.players[e.own].alive) { const d = Math.hypot(e.x - hq.x, e.z - hq.z); if (d < td) { td = d; target = e; } } });
    if (target) {
      const tg = target as Ent; p.waveT -= 1.1;
      if (!p.attacking && army.length >= p.waveSize && p.waveT <= 0) {
        p.attacking = true; p.atkX = tg.x; p.atkZ = tg.z;
        w.exec(p.idx, { k: 'amove', ids: army.map(u => u.id), x: tg.x, z: tg.z });
        p.waveSize += 3 + p.ai; p.waveT = 45;
        useAIPowers(w, p, army, tg);
      } else if (p.attacking) {
        // reinforce idle
        const idle = army.filter(u => u.ord === 0);
        if (idle.length) w.exec(p.idx, { k: 'amove', ids: idle.map(u => u.id), x: tg.x, z: tg.z });
        if (army.length < 3) p.attacking = false;
      }
    }
  }
  // powers when fighting
  if (army.length > 5) useAIPowers(w, p, army, null);
}

function useAIPowers(w: World, p: Player, army: Ent[], tg: Ent | null) {
  const f = FACS[p.fac];
  f.pw.forEach((pid, i) => {
    if (p.pcd[i] > 0) return; const pw = POW[pid];
    if (pw.t === 'heal') { const hp = army.reduce((s, e) => s + e.hp / e.mhp, 0) / army.length; if (hp < 0.6) w.exec(p.idx, { k: 'pow', i }); }
    else if (pw.t === 'buff') { if (tg || army.some(e => w.time - e.lastHit < 3)) w.exec(p.idx, { k: 'pow', i }); }
    else {
      // target: nearest enemy to army centre
      const cx = army.reduce((s, e) => s + e.x, 0) / army.length, cz = army.reduce((s, e) => s + e.z, 0) / army.length;
      let best: Ent | null = null, bd = 1e9; w.ents.forEach(e => { if (e.own >= 0 && e.own !== p.idx && e.hp > 0 && !e.mine) { const d = Math.hypot(e.x - cx, e.z - cz); if (d < bd) { bd = d; best = e; } } });
      if (best && (bd < 60 || tg)) { const b = best as Ent; w.exec(p.idx, { k: 'pow', i, x: b.x, z: b.z }); }
    }
  });
}
