import { newCtl, type Ctl, type Fighter } from './fighter';

export type Difficulty = 'easy' | 'normal' | 'hard';

interface Cfg {
  react: number; defend: number; dodge: number; aggr: number; think: number; chain: number; dmg: number; speed: number; special: number; punish: number;
}

const CFG: Record<Difficulty, Cfg> = {
  easy: { react: 0.5, defend: 0.22, dodge: 0.15, aggr: 0.3, think: 0.95, chain: 0.2, dmg: 0.75, speed: 0.8, special: 0.25, punish: 0.0 },
  normal: { react: 0.26, defend: 0.5, dodge: 0.3, aggr: 0.55, think: 0.55, chain: 0.5, dmg: 1.0, speed: 0.95, special: 0.55, punish: 0.35 },
  hard: { react: 0.12, defend: 0.82, dodge: 0.4, aggr: 0.82, think: 0.3, chain: 0.85, dmg: 1.2, speed: 1.0, special: 0.9, punish: 0.8 },
};

export class AI {
  cfg: Cfg;
  think = 0.5;
  mode: 'approach' | 'circle' | 'retreat' | 'attack' = 'approach';
  circleDir = 1;
  defendIn = -1;
  defendType: 'block' | 'dodge' = 'block';
  blockHold = 0;
  seenAtk = -1;
  chainPressed = false;
  lastMoveId = '';
  lastPunish = 0;

  constructor(public diff: Difficulty) {
    this.cfg = CFG[diff];
  }

  get dmgMul() { return this.cfg.dmg; }

  update(dt: number, me: Fighter, foe: Fighter, active: boolean): Ctl {
    const ctl = newCtl();
    if (!active) return ctl;
    const c = this.cfg;
    const dx = foe.pos.x - me.pos.x, dz = foe.pos.z - me.pos.z;
    const d = Math.hypot(dx, dz) || 0.001;
    const nx = dx / d, nz = dz / d;
    this.lastPunish -= dt;

    // --- reactive defence ---
    if (foe.atkId !== this.seenAtk) {
      this.seenAtk = foe.atkId;
      if (foe.state === 'attack' && foe.move && d < foe.move.reach + 1.0 && Math.random() < c.defend) {
        this.defendIn = c.react * (0.6 + Math.random() * 0.8);
        this.defendType = Math.random() < c.dodge ? 'dodge' : 'block';
      }
    }
    if (this.defendIn >= 0) {
      this.defendIn -= dt;
      if (this.defendIn < 0) {
        if (this.defendType === 'dodge') {
          ctl.dodge = true;
          // sidestep / back-step
          const s = Math.random() < 0.5 ? 1 : -1;
          ctl.mx = -nz * s - nx * 0.4; ctl.mz = nx * s - nz * 0.4;
        } else this.blockHold = 0.45 + Math.random() * 0.45;
      }
    }
    if (this.blockHold > 0) {
      this.blockHold -= dt;
      if (me.state === 'idle' || me.state === 'block') {
        ctl.block = true;
        return ctl;
      }
    }

    // --- decision making ---
    this.think -= dt;
    if (this.think <= 0 && (me.state === 'idle' || me.state === 'block')) {
      this.think = c.think * (0.6 + Math.random() * 0.8);
      this.circleDir = Math.random() < 0.5 ? 1 : -1;
      if (d > 2.6) this.mode = Math.random() < 0.2 ? 'circle' : 'approach';
      else if (Math.random() < c.aggr) this.mode = 'attack';
      else this.mode = Math.random() < 0.5 ? 'retreat' : 'circle';
      if (foe.state === 'knock' || foe.state === 'dead') this.mode = 'approach';
    }

    // punish whiffs / recovery
    if (
      me.state === 'idle' && foe.state === 'attack' && foe.move && foe.moveT > foe.move.hit[1] &&
      d < 1.9 && this.lastPunish <= 0 && Math.random() < c.punish * dt * 6
    ) {
      this.lastPunish = 1.2;
      this.pickAttack(ctl, me, d);
      return ctl;
    }

    const walkTo = (sx: number, sz: number, run = false) => { ctl.mx = sx; ctl.mz = sz; ctl.run = run; };

    // chain follow-ups while attacking
    if (me.state === 'attack' && me.move) {
      if (me.move.id !== this.lastMoveId) { this.lastMoveId = me.move.id; this.chainPressed = false; }
      if (!this.chainPressed && me.landed && me.moveT > me.move.cancel * 0.7 && Math.random() < c.chain * dt * 9) {
        this.chainPressed = true;
        this.pickAttack(ctl, me, d, true);
      }
      return ctl;
    }

    switch (this.mode) {
      case 'approach': walkTo(nx, nz, d > 4.2); if (d < 1.7) this.mode = 'attack'; break;
      case 'circle': walkTo(-nz * this.circleDir + nx * (d > 2.4 ? 0.5 : -0.1), nx * this.circleDir + nz * (d > 2.4 ? 0.5 : -0.1)); break;
      case 'retreat': walkTo(-nx, -nz); if (d > 3.6) this.mode = 'approach'; break;
      case 'attack':
        if (d > 1.65) walkTo(nx, nz, d > 3.5);
        else if (me.state === 'idle' && foe.state !== 'knock') {
          this.pickAttack(ctl, me, d);
          this.mode = Math.random() < 0.5 ? 'retreat' : 'circle';
          this.think = 0.15 + Math.random() * 0.3 * c.think;
        }
        break;
    }
    if (me.stamina < 25 && this.mode === 'attack') this.mode = 'retreat';
    return ctl;
  }

  pickAttack(ctl: Ctl, me: Fighter, d: number, follow = false) {
    const c = this.cfg;
    if (me.special >= 100 && d < 2.4 && Math.random() < c.special && !follow) { ctl.special = true; return; }
    const r = Math.random();
    if (d > 1.55) { if (r < 0.7) ctl.kick = true; else ctl.heavy = true; return; }
    if (r < 0.5) ctl.punch = true;
    else if (r < 0.75) ctl.kick = true;
    else ctl.heavy = true;
  }
}
