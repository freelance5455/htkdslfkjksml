/**
 * Flight Logic, Database, and Idle Economy Calculations
 */

export interface Livery {
  id: string;
  name: string;
  description: string;
  isHoliday?: boolean;
  image?: string;
  fuselageColor: string;
  wingColor: string;
  accentColor: string;
  badge: string;
  unlockCondition: string;
}

export const AVAILABLE_LIVERIES: Livery[] = [
  {
    id: 'default',
    name: 'Titanium Tactical',
    description: 'Standard issue monochrome livery engineered for global commercial transit.',
    fuselageColor: '#f4f4f5',
    wingColor: '#a1a1aa',
    accentColor: '#ffffff',
    badge: 'STANDARD',
    unlockCondition: 'Unlocked by default'
  },
  {
    id: 'christmas',
    name: 'Christmas Flight skin 2026',
    description: 'Festive Christmas airframe with Santa hat radome, decorated evergreen tree, white reindeer and snowflake wings, and candy-striped jet engines.',
    image: '/assets/aistudio/file_00000000eaf88211a0090db038da8bda_6d662669.png',
    isHoliday: true,
    fuselageColor: '#dc2626',
    wingColor: '#16a34a',
    accentColor: '#f59e0b',
    badge: '🎄 CHRISTMAS 2026',
    unlockCondition: 'Special seasonal mystery code'
  }
];

export const LIVERY_MAP: Map<string, Livery> = new Map(
  AVAILABLE_LIVERIES.map(l => [l.id, l])
);

export interface AirportCity {
  id: string;
  name: string;
  code: string;
  stateOrRegion?: string;
  country: string;
  countryCode: string;
  continent: string;
  lat: number;
  lng: number;
  unlockCost: number;
  tier: number; // 1: regional, 2: major, 3: intercontinental
  description: string;
}

export interface Plane {
  id: string;
  name: string;
  fromCityId: string;
  toCityId: string;
  progress: number; // 0 to 1
  isReturning: boolean;
  status: 'flying' | 'landed' | 'idle';
  totalFlightsCompleted: number;
  totalEarnings: number;
  liveryId?: string;
}

export interface RouteStat {
  flights: number;
  grossRevenue: number;
  fuelCost: number;
  netProfit: number;
  passengers: number;
  distanceKm: number;
}

export interface FlightEvent {
  id: string;
  title: string;
  description: string;
  multiplier: number;
  type: 'revenue' | 'speed' | 'fuel';
  expiresAt: number;
}

export interface GameState {
  airlineName: string;
  userId: string | null;
  userEmail: string | null;
  userAvatar: string | null;
  cash: number;
  totalEarned: number;
  totalFuelCost: number;
  totalPassengersCarried: number;
  totalDistanceFlownKm: number;
  fuelMarketIndex: number;
  unlockedCityIds: string[];
  airportLevels: Record<string, number>; // cityId -> level (1-5)
  speedLevel: number;
  moneyMakerLevel: number;
  fleetCount: number;
  capacityLevel: number;
  planes: Plane[];
  lastSavedTimestamp: number;
  soundEnabled: boolean;
  autoPilot: boolean;
  selectedPlaneId: string | null;
  selectedCityId: string | null;
  unlockedLiveryIds: string[];
  redeemedCodes: string[];
  routeStats: Record<string, RouteStat>;
  activeEvent: FlightEvent | null;
}

export const INITIAL_CITIES: AirportCity[] = [
  // --- NORTH AMERICA (USA) ---
  {
    id: 'sfo',
    name: 'San Francisco',
    code: 'SFO',
    stateOrRegion: 'California',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 37.6213,
    lng: -122.3790,
    unlockCost: 0, // STARTER UNLOCKED
    tier: 1,
    description: 'Golden Gate Gateway. Bay Area tech and coastal hub.'
  },
  {
    id: 'lax',
    name: 'Los Angeles',
    code: 'LAX',
    stateOrRegion: 'California',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 33.9416,
    lng: -118.4085,
    unlockCost: 0, // STARTER UNLOCKED
    tier: 1,
    description: 'Pacific Coast Mega-Hub. Entertainment and commerce capital.'
  },
  {
    id: 'las',
    name: 'Las Vegas',
    code: 'LAS',
    stateOrRegion: 'Nevada',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 36.0840,
    lng: -115.1537,
    unlockCost: 280,
    tier: 1,
    description: 'Desert oasis and high-volume tourism terminal.'
  },
  {
    id: 'sea',
    name: 'Seattle',
    code: 'SEA',
    stateOrRegion: 'Washington',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 47.4502,
    lng: -122.3088,
    unlockCost: 650,
    tier: 1,
    description: 'Pacific Northwest aviation cradle and maritime gateway.'
  },
  {
    id: 'den',
    name: 'Denver',
    code: 'DEN',
    stateOrRegion: 'Colorado',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 39.8561,
    lng: -104.6737,
    unlockCost: 1400,
    tier: 2,
    description: 'Mile High continental crossroads beneath the Rocky Mountains.'
  },
  {
    id: 'dfw',
    name: 'Dallas',
    code: 'DFW',
    stateOrRegion: 'Texas',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 32.8998,
    lng: -97.0403,
    unlockCost: 2800,
    tier: 2,
    description: 'Southern transit titan connecting East and West corridors.'
  },
  {
    id: 'ord',
    name: 'Chicago',
    code: 'ORD',
    stateOrRegion: 'Illinois',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 41.9742,
    lng: -87.9073,
    unlockCost: 5500,
    tier: 2,
    description: 'Great Lakes commercial hub with premier passenger volume.'
  },
  {
    id: 'atl',
    name: 'Atlanta',
    code: 'ATL',
    stateOrRegion: 'Georgia',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 33.6407,
    lng: -84.4277,
    unlockCost: 9500,
    tier: 3,
    description: 'Hartsfield-Jackson: historically the world’s busiest passenger airport.'
  },
  {
    id: 'mia',
    name: 'Miami',
    code: 'MIA',
    stateOrRegion: 'Florida',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 25.7959,
    lng: -80.2870,
    unlockCost: 14500,
    tier: 2,
    description: 'Tropical gateway to the Caribbean, Latin America, and South Atlantic.'
  },
  {
    id: 'jfk',
    name: 'New York',
    code: 'JFK',
    stateOrRegion: 'New York',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 40.6413,
    lng: -73.7781,
    unlockCost: 22000,
    tier: 3,
    description: 'Global financial nexus and primary transatlantic springboard.'
  },
  {
    id: 'bos',
    name: 'Boston',
    code: 'BOS',
    stateOrRegion: 'Massachusetts',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 42.3656,
    lng: -71.0096,
    unlockCost: 31000,
    tier: 2,
    description: 'Historic New England academic and tech corridor airport.'
  },
  {
    id: 'hnl',
    name: 'Honolulu',
    code: 'HNL',
    stateOrRegion: 'Hawaii',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 21.3187,
    lng: -157.9224,
    unlockCost: 45000,
    tier: 2,
    description: 'Pacific mid-ocean paradise connection.'
  },
  {
    id: 'anc',
    name: 'Anchorage',
    code: 'ANC',
    stateOrRegion: 'Alaska',
    country: 'United States',
    countryCode: 'USA',
    continent: 'North America',
    lat: 61.1744,
    lng: -149.9964,
    unlockCost: 65000,
    tier: 2,
    description: 'Sub-arctic polar route cargo and intercontinental passenger stop.'
  },

  // --- CANADA ---
  {
    id: 'yvr',
    name: 'Vancouver',
    code: 'YVR',
    stateOrRegion: 'British Columbia',
    country: 'Canada',
    countryCode: 'CAN',
    continent: 'North America',
    lat: 49.1967,
    lng: -123.1815,
    unlockCost: 90000,
    tier: 2,
    description: 'Coastal Canadian gateway across the North Pacific.'
  },
  {
    id: 'yyz',
    name: 'Toronto',
    code: 'YYZ',
    stateOrRegion: 'Ontario',
    country: 'Canada',
    countryCode: 'CAN',
    continent: 'North America',
    lat: 43.6777,
    lng: -79.6248,
    unlockCost: 120000,
    tier: 2,
    description: 'Largest Canadian airport and commercial lifeline.'
  },
  {
    id: 'yul',
    name: 'Montreal',
    code: 'YUL',
    stateOrRegion: 'Quebec',
    country: 'Canada',
    countryCode: 'CAN',
    continent: 'North America',
    lat: 45.4706,
    lng: -73.7408,
    unlockCost: 160000,
    tier: 2,
    description: 'Francophone cultural capital and transatlantic gateway.'
  },

  // --- MEXICO & CENTRAL AMERICA ---
  {
    id: 'mex',
    name: 'Mexico City',
    code: 'MEX',
    stateOrRegion: 'Federal District',
    country: 'Mexico',
    countryCode: 'MEX',
    continent: 'North America',
    lat: 19.4361,
    lng: -99.0719,
    unlockCost: 210000,
    tier: 2,
    description: 'High-altitude mega-metropolis of Mesoamerica.'
  },
  {
    id: 'cun',
    name: 'Cancun',
    code: 'CUN',
    stateOrRegion: 'Quintana Roo',
    country: 'Mexico',
    countryCode: 'MEX',
    continent: 'North America',
    lat: 21.0365,
    lng: -86.8771,
    unlockCost: 270000,
    tier: 2,
    description: 'Riviera Maya tourism magnet and Caribbean transfer point.'
  },
  {
    id: 'pty',
    name: 'Panama City',
    code: 'PTY',
    country: 'Panama',
    countryCode: 'PAN',
    continent: 'Central America',
    lat: 9.0714,
    lng: -79.3835,
    unlockCost: 350000,
    tier: 3,
    description: 'Tocumen: The revered Hub of the Americas bridging North and South.'
  },

  // --- SOUTH AMERICA ---
  {
    id: 'bog',
    name: 'Bogota',
    code: 'BOG',
    country: 'Colombia',
    countryCode: 'COL',
    continent: 'South America',
    lat: 4.7016,
    lng: -74.1469,
    unlockCost: 450000,
    tier: 2,
    description: 'El Dorado: Andean crossroads connecting South and Central America.'
  },
  {
    id: 'lim',
    name: 'Lima',
    code: 'LIM',
    country: 'Peru',
    countryCode: 'PER',
    continent: 'South America',
    lat: -12.0219,
    lng: -77.1143,
    unlockCost: 580000,
    tier: 2,
    description: 'Jorge Chavez: Pacific Rim South American gateway.'
  },
  {
    id: 'gru',
    name: 'Sao Paulo',
    code: 'GRU',
    country: 'Brazil',
    countryCode: 'BRA',
    continent: 'South America',
    lat: -23.4356,
    lng: -46.4731,
    unlockCost: 750000,
    tier: 3,
    description: 'Guarulhos: Financial and industrial heart of South America.'
  },
  {
    id: 'gig',
    name: 'Rio de Janeiro',
    code: 'GIG',
    country: 'Brazil',
    countryCode: 'BRA',
    continent: 'South America',
    lat: -22.8089,
    lng: -43.2436,
    unlockCost: 950000,
    tier: 2,
    description: 'Galeao: World-famous coastal capital beneath Sugarloaf Mountain.'
  },
  {
    id: 'eze',
    name: 'Buenos Aires',
    code: 'EZE',
    country: 'Argentina',
    countryCode: 'ARG',
    continent: 'South America',
    lat: -34.8222,
    lng: -58.5358,
    unlockCost: 1200000,
    tier: 3,
    description: 'Ministro Pistarini: Southern Cone cosmopolitan hub.'
  },
  {
    id: 'scl',
    name: 'Santiago',
    code: 'SCL',
    country: 'Chile',
    countryCode: 'CHL',
    continent: 'South America',
    lat: -33.3930,
    lng: -70.7858,
    unlockCost: 1500000,
    tier: 2,
    description: 'Arturo Merino Benitez: Pacific Andean western terminal.'
  },

  // --- EUROPE ---
  {
    id: 'dub',
    name: 'Dublin',
    code: 'DUB',
    country: 'Ireland',
    countryCode: 'IRL',
    continent: 'Europe',
    lat: 53.4264,
    lng: -6.2499,
    unlockCost: 1850000,
    tier: 2,
    description: 'Emerald Isle springboard with preclearance transatlantic traffic.'
  },
  {
    id: 'lhr',
    name: 'London',
    code: 'LHR',
    country: 'United Kingdom',
    countryCode: 'GBR',
    continent: 'Europe',
    lat: 51.4700,
    lng: -0.4543,
    unlockCost: 2300000,
    tier: 3,
    description: 'Heathrow: Historic air transport capital of Europe.'
  },
  {
    id: 'cdg',
    name: 'Paris',
    code: 'CDG',
    country: 'France',
    countryCode: 'FRA',
    continent: 'Europe',
    lat: 49.0097,
    lng: 2.5479,
    unlockCost: 2850000,
    tier: 3,
    description: 'Roissy Charles de Gaulle: Heart of continental Europe.'
  },
  {
    id: 'ams',
    name: 'Amsterdam',
    code: 'AMS',
    country: 'Netherlands',
    countryCode: 'NLD',
    continent: 'Europe',
    lat: 52.3105,
    lng: 4.7683,
    unlockCost: 3500000,
    tier: 3,
    description: 'Schiphol: Master single-terminal transit nexus below sea level.'
  },
  {
    id: 'fra',
    name: 'Frankfurt',
    code: 'FRA',
    country: 'Germany',
    countryCode: 'DEU',
    continent: 'Europe',
    lat: 50.0379,
    lng: 8.5622,
    unlockCost: 4300000,
    tier: 3,
    description: 'Central Europe transit powerhouse and cargo heavy-lifter.'
  },
  {
    id: 'muc',
    name: 'Munich',
    code: 'MUC',
    country: 'Germany',
    countryCode: 'DEU',
    continent: 'Europe',
    lat: 48.3537,
    lng: 11.7860,
    unlockCost: 5200000,
    tier: 2,
    description: 'Bavarian high-tech precision terminal.'
  },
  {
    id: 'zrh',
    name: 'Zurich',
    code: 'ZRH',
    country: 'Switzerland',
    countryCode: 'CHE',
    continent: 'Europe',
    lat: 47.4582,
    lng: 8.5555,
    unlockCost: 6200000,
    tier: 2,
    description: 'Alpine banking nexus renowned for immaculate Swiss punctuality.'
  },
  {
    id: 'mad',
    name: 'Madrid',
    code: 'MAD',
    country: 'Spain',
    countryCode: 'ESP',
    continent: 'Europe',
    lat: 40.4839,
    lng: -3.5680,
    unlockCost: 7400000,
    tier: 3,
    description: 'Barajas: Architectural masterpiece connecting Europe and Latin America.'
  },
  {
    id: 'fco',
    name: 'Rome',
    code: 'FCO',
    country: 'Italy',
    countryCode: 'ITA',
    continent: 'Europe',
    lat: 41.8003,
    lng: 12.2389,
    unlockCost: 8800000,
    tier: 2,
    description: 'Fiumicino Leonardo da Vinci: Mediterranean historic capital.'
  },
  {
    id: 'ist',
    name: 'Istanbul',
    code: 'IST',
    country: 'Turkey',
    countryCode: 'TUR',
    continent: 'Europe',
    lat: 41.2753,
    lng: 28.7519,
    unlockCost: 10500000,
    tier: 3,
    description: 'Colossal intercontinental gateway directly straddling Europe and Asia.'
  },

  // --- MIDDLE EAST ---
  {
    id: 'dxb',
    name: 'Dubai',
    code: 'DXB',
    country: 'United Arab Emirates',
    countryCode: 'ARE',
    continent: 'Middle East',
    lat: 25.2532,
    lng: 55.3657,
    unlockCost: 12500000,
    tier: 3,
    description: 'World crossroads with round-the-clock long-haul widebody flights.'
  },
  {
    id: 'doh',
    name: 'Doha',
    code: 'DOH',
    country: 'Qatar',
    countryCode: 'QAT',
    continent: 'Middle East',
    lat: 25.2731,
    lng: 51.6081,
    unlockCost: 15000000,
    tier: 3,
    description: 'Hamad: 5-star oasis terminal connecting East, West, North, and South.'
  },
  {
    id: 'ruh',
    name: 'Riyadh',
    code: 'RUH',
    country: 'Saudi Arabia',
    countryCode: 'SAU',
    continent: 'Middle East',
    lat: 24.9576,
    lng: 46.6988,
    unlockCost: 18000000,
    tier: 2,
    description: 'King Khalid: Arabian Peninsula continental capital.'
  },

  // --- ASIA ---
  {
    id: 'del',
    name: 'Delhi',
    code: 'DEL',
    country: 'India',
    countryCode: 'IND',
    continent: 'Asia',
    lat: 28.5562,
    lng: 77.1000,
    unlockCost: 21500000,
    tier: 3,
    description: 'Indira Gandhi: Massive South Asian demographic corridor.'
  },
  {
    id: 'bom',
    name: 'Mumbai',
    code: 'BOM',
    country: 'India',
    countryCode: 'IND',
    continent: 'Asia',
    lat: 19.0896,
    lng: 72.8656,
    unlockCost: 25500000,
    tier: 2,
    description: 'Chhatrapati Shivaji: Commercial and Bollywood financial center.'
  },
  {
    id: 'bkk',
    name: 'Bangkok',
    code: 'BKK',
    country: 'Thailand',
    countryCode: 'THA',
    continent: 'Asia',
    lat: 13.6900,
    lng: 100.7501,
    unlockCost: 30000000,
    tier: 3,
    description: 'Suvarnabhumi: Southeast Asian golden land transit jewel.'
  },
  {
    id: 'sin',
    name: 'Singapore',
    code: 'SIN',
    country: 'Singapore',
    countryCode: 'SGP',
    continent: 'Asia',
    lat: 1.3644,
    lng: 103.9915,
    unlockCost: 35500000,
    tier: 3,
    description: 'Changi: Universally acclaimed world standard in passenger hospitality.'
  },
  {
    id: 'kul',
    name: 'Kuala Lumpur',
    code: 'KUL',
    country: 'Malaysia',
    countryCode: 'MYS',
    continent: 'Asia',
    lat: 2.7456,
    lng: 101.7072,
    unlockCost: 41500000,
    tier: 2,
    description: 'Aeropolis in the forest bridging Malacca and South China seas.'
  },
  {
    id: 'hkg',
    name: 'Hong Kong',
    code: 'HKG',
    country: 'Hong Kong SAR',
    countryCode: 'HKG',
    continent: 'Asia',
    lat: 22.3080,
    lng: 113.9185,
    unlockCost: 48500000,
    tier: 3,
    description: 'Chek Lap Kok: Built upon reclaimed land, world cargo leader.'
  },
  {
    id: 'tpe',
    name: 'Taipei',
    code: 'TPE',
    country: 'Taiwan',
    countryCode: 'TWN',
    continent: 'Asia',
    lat: 25.0797,
    lng: 121.2342,
    unlockCost: 56500000,
    tier: 2,
    description: 'Taoyuan: High-tech semiconductor island crossroads.'
  },
  {
    id: 'pvg',
    name: 'Shanghai',
    code: 'PVG',
    country: 'China',
    countryCode: 'CHN',
    continent: 'Asia',
    lat: 31.1443,
    lng: 121.8083,
    unlockCost: 65500000,
    tier: 3,
    description: 'Pudong: Yangtze River Delta global export titan.'
  },
  {
    id: 'pek',
    name: 'Beijing',
    code: 'PEK',
    country: 'China',
    countryCode: 'CHN',
    continent: 'Asia',
    lat: 40.0799,
    lng: 116.6031,
    unlockCost: 76000000,
    tier: 3,
    description: 'Capital International: Continental Asian northern gate.'
  },
  {
    id: 'icn',
    name: 'Seoul',
    code: 'ICN',
    country: 'South Korea',
    countryCode: 'KOR',
    continent: 'Asia',
    lat: 37.4602,
    lng: 126.4407,
    unlockCost: 88000000,
    tier: 3,
    description: 'Incheon: Ultra-modern East Asian Pacific hub.'
  },
  {
    id: 'hnd',
    name: 'Tokyo',
    code: 'HND',
    country: 'Japan',
    countryCode: 'JPN',
    continent: 'Asia',
    lat: 35.5494,
    lng: 139.7798,
    unlockCost: 102000000,
    tier: 3,
    description: 'Haneda: Downtown Tokyo bay titan operating at peak precision.'
  },

  // --- OCEANIA ---
  {
    id: 'per',
    name: 'Perth',
    code: 'PER',
    country: 'Australia',
    countryCode: 'AUS',
    continent: 'Oceania',
    lat: -31.9403,
    lng: 115.9668,
    unlockCost: 118000000,
    tier: 2,
    description: 'Western Australia gateway directly facing the Indian Ocean.'
  },
  {
    id: 'syd',
    name: 'Sydney',
    code: 'SYD',
    country: 'Australia',
    countryCode: 'AUS',
    continent: 'Oceania',
    lat: -33.9399,
    lng: 151.1753,
    unlockCost: 136000000,
    tier: 3,
    description: 'Kingsford Smith: Southern Cross gateway spanning Botany Bay.'
  },
  {
    id: 'mel',
    name: 'Melbourne',
    code: 'MEL',
    country: 'Australia',
    countryCode: 'AUS',
    continent: 'Oceania',
    lat: -37.6690,
    lng: 144.8410,
    unlockCost: 156000000,
    tier: 2,
    description: 'Tullamarine: Victoria cultural capital connecting the Tasman.'
  },
  {
    id: 'akl',
    name: 'Auckland',
    code: 'AKL',
    country: 'New Zealand',
    countryCode: 'NZL',
    continent: 'Oceania',
    lat: -37.0082,
    lng: 174.7850,
    unlockCost: 180000000,
    tier: 2,
    description: 'City of Sails: Deep South Pacific and Polynesian crossroads.'
  },

  // --- AFRICA ---
  {
    id: 'cmn',
    name: 'Casablanca',
    code: 'CMN',
    country: 'Morocco',
    countryCode: 'MAR',
    continent: 'Africa',
    lat: 33.3675,
    lng: -7.5899,
    unlockCost: 208000000,
    tier: 2,
    description: 'Mohammed V: North African gateway between Atlantic and Maghreb.'
  },
  {
    id: 'cai',
    name: 'Cairo',
    code: 'CAI',
    country: 'Egypt',
    countryCode: 'EGY',
    continent: 'Africa',
    lat: 30.1219,
    lng: 31.4056,
    unlockCost: 240000000,
    tier: 3,
    description: 'Nile crossroads connecting Africa, the Levant, and the Mediterranean.'
  },
  {
    id: 'nbo',
    name: 'Nairobi',
    code: 'NBO',
    country: 'Kenya',
    countryCode: 'KEN',
    continent: 'Africa',
    lat: -1.3192,
    lng: 36.9278,
    unlockCost: 278000000,
    tier: 2,
    description: 'Jomo Kenyatta: East African savannah and safari hub.'
  },
  {
    id: 'jnb',
    name: 'Johannesburg',
    code: 'JNB',
    country: 'South Africa',
    countryCode: 'ZAF',
    continent: 'Africa',
    lat: -26.1367,
    lng: 28.2411,
    unlockCost: 320000000,
    tier: 3,
    description: 'OR Tambo: Highveld gateway of Southern Africa.'
  },
  {
    id: 'cpt',
    name: 'Cape Town',
    code: 'CPT',
    country: 'South Africa',
    countryCode: 'ZAF',
    continent: 'Africa',
    lat: -33.9715,
    lng: 18.6021,
    unlockCost: 370000000,
    tier: 2,
    description: 'Table Mountain coastal terminal where Atlantic and Indian oceans meet.'
  }
];

export const CITY_MAP: Map<string, AirportCity> = new Map(
  INITIAL_CITIES.map(c => [c.id, c])
);

/**
 * Great-circle distance between two coordinates in kilometers using Haversine formula
 */
export function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

/**
 * Straight line interpolation between two LatLng points
 * Returns exact coordinates along the straight flight corridor at progress t (0..1)
 */
export function interpolateLatLng(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
  t: number
): { lat: number; lng: number } {
  return {
    lat: lat1 + (lat2 - lat1) * t,
    lng: lng1 + (lng2 - lng1) * t
  };
}

/**
 * Initial bearing from point 1 to point 2 in degrees (0 = North, 90 = East, 180 = South, 270 = West)
 */
export function calculateBearing(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const y = (lng2 - lng1);
  const x = (lat2 - lat1);
  // Math.atan2 in screen/map plane: (y is east/west, x is north/south)
  // angle in standard aviation navigation (0 is North / UP, clockwise):
  const rad = Math.atan2(y, x);
  const deg = (rad * 180) / Math.PI;
  return (deg + 360) % 360;
}

/**
 * Calculate flight duration in seconds based on distance and speed level
 */
export function calculateFlightDuration(distanceKm: number, speedLevel: number): number {
  // Base speed is around 800 km/h in game time scale
  // With scaling, a short flight (SFO-LAX ~ 550km) takes ~8-12 seconds initially,
  // making idle progress fast, active, and satisfying!
  const speedMultiplier = 1 + (speedLevel - 1) * 0.28;
  const baseSeconds = 5 + (distanceKm / 400) * 4;
  return Math.max(3.5, baseSeconds / speedMultiplier);
}

/**
 * Passenger capacity based on plane capacity level
 */
export function getPassengerCapacity(capacityLevel: number): number {
  // Starts with small regional 30 passengers, scales up
  return Math.round(30 * Math.pow(1.35, capacityLevel - 1));
}

/**
 * Name of aircraft tier based on capacity level
 */
export function getAircraftTierName(capacityLevel: number): string {
  if (capacityLevel <= 2) return 'Twin-Turboprop Regional';
  if (capacityLevel <= 5) return 'Twinjet Cruiser (ERJ-175)';
  if (capacityLevel <= 9) return 'Boeing 737 Next-Gen';
  if (capacityLevel <= 14) return 'Boeing 787 Dreamliner';
  if (capacityLevel <= 20) return 'Airbus A350 Ultra';
  return 'Concorde II Supersonic';
}

/**
 * Calculate detailed flight economics (Revenue, Fuel Burn, Operational Profit, Passengers)
 */
export interface FlightFinancials {
  grossRevenue: number;
  fuelCost: number;
  netProfit: number;
  passengers: number;
}

export function calculateFlightFinancials(
  distanceKm: number,
  moneyMakerLevel: number,
  capacityLevel: number,
  fromAirportLevel = 1,
  toAirportLevel = 1,
  fuelMarketIndex = 1.0,
  eventMultiplier = 1.0
): FlightFinancials {
  const baseFare = 12;
  const distancePay = distanceKm * 0.024;
  const passengers = getPassengerCapacity(capacityLevel);
  const moneyMakerMultiplier = 1 + (moneyMakerLevel - 1) * 0.28;
  const airportMultiplier = 1 + (fromAirportLevel - 1) * 0.12 + (toAirportLevel - 1) * 0.12;

  const grossRevenue = Math.round(
    (baseFare + distancePay) * (passengers / 30) * moneyMakerMultiplier * airportMultiplier * eventMultiplier
  );

  // Dynamic aviation fuel cost scaling with flight length & aircraft weight
  const baseFuelPerKm = 0.007;
  const fuelCost = Math.round(
    Math.max(2, distanceKm * baseFuelPerKm * (passengers / 30) * fuelMarketIndex)
  );

  const netProfit = Math.max(3, grossRevenue - fuelCost);

  return {
    grossRevenue,
    fuelCost,
    netProfit,
    passengers
  };
}

/**
 * Calculate earnings for completing a flight (Rebalanced for satisfying idle grind)
 */
export function calculateFlightRevenue(
  distanceKm: number,
  moneyMakerLevel: number,
  capacityLevel: number,
  fromAirportLevel = 1,
  toAirportLevel = 1
): number {
  return calculateFlightFinancials(
    distanceKm,
    moneyMakerLevel,
    capacityLevel,
    fromAirportLevel,
    toAirportLevel
  ).netProfit;
}

/**
 * Calculate Airline Prestige Rating (1.0 to 5.0 Stars) based on real operations
 */
export function calculateAirlineRating(state: GameState): {
  stars: number;
  title: string;
  continentsCount: number;
  unlockedAirportsCount: number;
} {
  const continents = new Set<string>();
  state.unlockedCityIds.forEach(id => {
    const c = CITY_MAP.get(id);
    if (c) continents.add(c.continent);
  });

  const airportsScore = Math.min(2.0, state.unlockedCityIds.length * 0.06);
  const fleetScore = Math.min(1.5, state.planes.length * 0.3);
  const continentsScore = Math.min(1.0, continents.size * 0.2);
  const techScore = Math.min(0.5, (state.speedLevel + state.moneyMakerLevel + state.capacityLevel) * 0.03);

  const stars = Math.min(5.0, Math.max(1.0, Math.round((airportsScore + fleetScore + continentsScore + techScore + 0.5) * 2) / 2));

  let title = 'Regional Startup';
  if (stars >= 4.5) title = 'Global Megacarrier';
  else if (stars >= 4.0) title = 'International Flagship';
  else if (stars >= 3.0) title = 'Continental Titan';
  else if (stars >= 2.0) title = 'National Carrier';

  return {
    stars,
    title,
    continentsCount: continents.size,
    unlockedAirportsCount: state.unlockedCityIds.length
  };
}

/**
 * Upgrade Cost Calculations (Rebalanced for meaningful progression grind)
 */
export function getSpeedUpgradeCost(level: number): number {
  return Math.round(60 * Math.pow(1.36, level - 1));
}

export function getMoneyMakerUpgradeCost(level: number): number {
  return Math.round(75 * Math.pow(1.38, level - 1));
}

export function getCapacityUpgradeCost(level: number): number {
  return Math.round(180 * Math.pow(1.48, level - 1));
}

export function getNewPlaneCost(currentPlanesCount: number): number {
  return Math.round(350 * Math.pow(2.4, currentPlanesCount - 1));
}

export function getAirportUpgradeCost(currentAirportLevel: number, cityTier: number): number {
  return Math.round(450 * cityTier * Math.pow(1.9, currentAirportLevel - 1));
}

/**
 * Calculate offline earnings when player returns
 */
export function calculateOfflineEarnings(
  lastSavedTimestamp: number,
  currentState: GameState
): { offlineEarnings: number; elapsedSeconds: number } {
  const now = Date.now();
  const elapsedMs = Math.max(0, now - lastSavedTimestamp);
  const elapsedSeconds = Math.min(8 * 3600, Math.floor(elapsedMs / 1000)); // Cap at 8 hours

  if (elapsedSeconds < 10 || currentState.planes.length === 0) {
    return { offlineEarnings: 0, elapsedSeconds };
  }

  // Calculate earning rate of all actively assigned planes
  let totalPerSecond = 0;
  for (const plane of currentState.planes) {
    const fromCity = CITY_MAP.get(plane.fromCityId);
    const toCity = CITY_MAP.get(plane.toCityId);
    if (!fromCity || !toCity) continue;

    const dist = calculateDistance(fromCity.lat, fromCity.lng, toCity.lat, toCity.lng);
    const duration = calculateFlightDuration(dist, currentState.speedLevel);
    const fromLevel = currentState.airportLevels[fromCity.id] || 1;
    const toLevel = currentState.airportLevels[toCity.id] || 1;
    const rev = calculateFlightRevenue(
      dist,
      currentState.moneyMakerLevel,
      currentState.capacityLevel,
      fromLevel,
      toLevel
    );

    totalPerSecond += rev / duration;
  }

  // 65% efficiency during offline idle
  const offlineEarnings = Math.round(totalPerSecond * elapsedSeconds * 0.65);
  return { offlineEarnings, elapsedSeconds };
}

/**
 * Livery and Promo Code Redemption Helper
 */
export interface RedeemResult {
  success: boolean;
  message: string;
  liveryId?: string;
  bonusCash?: number;
}

export function redeemPromoCode(rawCode: string, state: GameState): RedeemResult {
  const code = rawCode.trim().toLowerCase();
  if (!code) {
    return { success: false, message: 'Please enter a secret promo code.' };
  }

  const redeemed = state.redeemedCodes || [];
  if (redeemed.includes(code)) {
    return { success: false, message: `Code has already been redeemed!` };
  }

  // CHRISTMAS CODE REQUESTED BY USER: Winter26
  if (code === 'winter26' || code === 'chris26') {
    return {
      success: true,
      message: '🎄 Merry Christmas! You unlocked the "Christmas Flight skin 2026" + $150 Winter Bonus Cash!',
      liveryId: 'christmas',
      bonusCash: 150
    };
  }

  return {
    success: false,
    message: `Invalid code. Check your spelling and try again!`
  };
}

/**
 * Initial starter state
 */
export function getInitialGameState(): GameState {
  return {
    airlineName: 'Pacific Horizon Airways',
    userId: null,
    userEmail: null,
    userAvatar: null,
    cash: 25, // Humble startup seed - player earns every upgrade!
    totalEarned: 0,
    totalFuelCost: 0,
    totalPassengersCarried: 0,
    totalDistanceFlownKm: 0,
    fuelMarketIndex: 1.0,
    unlockedCityIds: ['sfo', 'lax'], // Starter 2 cities: San Francisco and California (LAX)!
    airportLevels: {
      sfo: 1,
      lax: 1
    },
    speedLevel: 1,
    moneyMakerLevel: 1,
    fleetCount: 1,
    capacityLevel: 1,
    planes: [
      {
        id: 'plane-1',
        name: 'Aero 01',
        fromCityId: 'sfo',
        toCityId: 'lax',
        progress: 0.1,
        isReturning: false,
        status: 'flying',
        totalFlightsCompleted: 0,
        totalEarnings: 0,
        liveryId: 'default'
      }
    ],
    lastSavedTimestamp: Date.now(),
    soundEnabled: true,
    autoPilot: true,
    selectedPlaneId: 'plane-1',
    selectedCityId: 'sfo',
    unlockedLiveryIds: ['default'],
    redeemedCodes: [],
    routeStats: {},
    activeEvent: null
  };
}

/**
 * Storage helpers
 */
const STORAGE_KEY = 'aero_idle_save_v1';

export function loadSavedGameState(): GameState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return getInitialGameState();
    const parsed = JSON.parse(raw);
    if (!parsed.unlockedCityIds || !parsed.unlockedCityIds.includes('sfo')) {
      return getInitialGameState();
    }
    const initial = getInitialGameState();
    return {
      ...initial,
      ...parsed,
      airlineName: parsed.airlineName || initial.airlineName,
      unlockedLiveryIds: Array.isArray(parsed.unlockedLiveryIds) && parsed.unlockedLiveryIds.length > 0
        ? parsed.unlockedLiveryIds
        : ['default'],
      redeemedCodes: Array.isArray(parsed.redeemedCodes)
        ? parsed.redeemedCodes
        : [],
      planes: (parsed.planes || initial.planes).map((p: Plane) => ({
        ...p,
        liveryId: p.liveryId || 'default'
      })),
      routeStats: parsed.routeStats || {},
      lastSavedTimestamp: Date.now()
    };
  } catch {
    return getInitialGameState();
  }
}

export function saveGameState(state: GameState): void {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({
        ...state,
        lastSavedTimestamp: Date.now()
      })
    );
  } catch (e) {
    console.error('Failed to save game state', e);
  }
}

export function clearSavedGameState(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.error('Failed to clear game state', e);
  }
}
