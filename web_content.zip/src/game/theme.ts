export type Theme = {
  sky0: string;
  sky1: string;
  sky2: string;
  sun: string;
  sunCore: string;
  cloud: string;
  hillFar: string;
  hillNear: string;
  grass: string;
  grassDark: string;
  dirt: string;
  dirtDark: string;
  pipe: string;
  pipeDark: string;
  pipeLite: string;
  lip: string;
  star: number;
  sunX: number;
  sunY: number;
  night: number;
};

export const THEMES: Theme[] = [
  {
    sky0: "#8ec8f5",
    sky1: "#f6d7a8",
    sky2: "#f3b98a",
    sun: "#ffe7a3",
    sunCore: "#fffaf0",
    cloud: "#fff7ee",
    hillFar: "#8fb89a",
    hillNear: "#3f8f62",
    grass: "#3e9a5c",
    grassDark: "#2d7a48",
    dirt: "#d7b07a",
    dirtDark: "#8d6843",
    pipe: "#2f9d74",
    pipeDark: "#14634a",
    pipeLite: "#8ae6c8",
    lip: "#1f7a58",
    star: 0,
    sunX: 0.78,
    sunY: 0.16,
    night: 0,
  },
  {
    sky0: "#4a3278",
    sky1: "#e36b4a",
    sky2: "#ffb067",
    sun: "#ffd0a1",
    sunCore: "#fff1d4",
    cloud: "#ffd0b8",
    hillFar: "#7a4e72",
    hillNear: "#8a4458",
    grass: "#6d8f45",
    grassDark: "#4e6b32",
    dirt: "#c48b62",
    dirtDark: "#7a4e38",
    pipe: "#2a8f6a",
    pipeDark: "#124c3c",
    pipeLite: "#7ddec0",
    lip: "#1b654c",
    star: 0.15,
    sunX: 0.5,
    sunY: 0.58,
    night: 0.15,
  },
  {
    sky0: "#0e1730",
    sky1: "#1b2c5c",
    sky2: "#3d527f",
    sun: "#f4f0dd",
    sunCore: "#ffffff",
    cloud: "#c9d4ea",
    hillFar: "#1a2744",
    hillNear: "#243456",
    grass: "#1d4d4a",
    grassDark: "#143834",
    dirt: "#3a4658",
    dirtDark: "#232a38",
    pipe: "#1f8f86",
    pipeDark: "#0c3d45",
    pipeLite: "#7ee0d2",
    lip: "#146860",
    star: 1,
    sunX: 0.8,
    sunY: 0.14,
    night: 1,
  },
];

function mixHex(a: string, b: string, t: number): string {
  const pa = Number.parseInt(a.slice(1), 16);
  const pb = Number.parseInt(b.slice(1), 16);
  const r = Math.round(((pa >> 16) & 255) + (((pb >> 16) & 255) - ((pa >> 16) & 255)) * t);
  const g = Math.round(((pa >> 8) & 255) + (((pb >> 8) & 255) - ((pa >> 8) & 255)) * t);
  const bl = Math.round((pa & 255) + ((pb & 255) - (pa & 255)) * t);
  return `rgb(${r}, ${g}, ${bl})`;
}

function mixTheme(a: Theme, b: Theme, t: number): Theme {
  const m = (x: string, y: string) => mixHex(x, y, t);
  const n = (x: number, y: number) => x + (y - x) * t;
  return {
    sky0: m(a.sky0, b.sky0),
    sky1: m(a.sky1, b.sky1),
    sky2: m(a.sky2, b.sky2),
    sun: m(a.sun, b.sun),
    sunCore: m(a.sunCore, b.sunCore),
    cloud: m(a.cloud, b.cloud),
    hillFar: m(a.hillFar, b.hillFar),
    hillNear: m(a.hillNear, b.hillNear),
    grass: m(a.grass, b.grass),
    grassDark: m(a.grassDark, b.grassDark),
    dirt: m(a.dirt, b.dirt),
    dirtDark: m(a.dirtDark, b.dirtDark),
    pipe: m(a.pipe, b.pipe),
    pipeDark: m(a.pipeDark, b.pipeDark),
    pipeLite: m(a.pipeLite, b.pipeLite),
    lip: m(a.lip, b.lip),
    star: n(a.star, b.star),
    sunX: n(a.sunX, b.sunX),
    sunY: n(a.sunY, b.sunY),
    night: n(a.night, b.night),
  };
}

/** index wraps across morning → sunset → night. */
export function sampleTheme(indexFloat: number): Theme {
  const n = THEMES.length;
  const wrapped = ((indexFloat % n) + n) % n;
  const i0 = Math.floor(wrapped) % n;
  const i1 = (i0 + 1) % n;
  return mixTheme(THEMES[i0]!, THEMES[i1]!, wrapped - Math.floor(wrapped));
}
