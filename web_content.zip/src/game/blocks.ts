export const TILE = 16;
export const GRID = 4;

export const B = {
  AIR: 0,
  GRASS: 1,
  DIRT: 2,
  STONE: 3,
  LOG: 4,
  LEAVES: 5,
  SAND: 6,
  PLANKS: 7,
  WATER: 8,
  BRICK: 9,
  GLASS: 10,
  COBBLE: 11,
} as const;

export interface BlockDef {
  name: string;
  /** [top, bottom, side] tile indexes in atlas */
  tiles: [number, number, number];
  opaque: boolean;
  solid: boolean;
  color: string;
}

export const DEFS: BlockDef[] = [
  { name: 'Воздух', tiles: [0, 0, 0], opaque: false, solid: false, color: '#000000' },
  { name: 'Трава', tiles: [0, 2, 1], opaque: true, solid: true, color: '#5f9f35' },
  { name: 'Земля', tiles: [2, 2, 2], opaque: true, solid: true, color: '#866043' },
  { name: 'Камень', tiles: [3, 3, 3], opaque: true, solid: true, color: '#7d7d7d' },
  { name: 'Бревно', tiles: [5, 5, 4], opaque: true, solid: true, color: '#66512f' },
  { name: 'Листва', tiles: [6, 6, 6], opaque: true, solid: true, color: '#347826' },
  { name: 'Песок', tiles: [7, 7, 7], opaque: true, solid: true, color: '#dbcf8e' },
  { name: 'Доски', tiles: [8, 8, 8], opaque: true, solid: true, color: '#a08250' },
  { name: 'Вода', tiles: [9, 9, 9], opaque: false, solid: false, color: '#2860c8' },
  { name: 'Кирпич', tiles: [10, 10, 10], opaque: true, solid: true, color: '#96463a' },
  { name: 'Стекло', tiles: [11, 11, 11], opaque: false, solid: true, color: '#c8e6f0' },
  { name: 'Булыжник', tiles: [12, 12, 12], opaque: true, solid: true, color: '#6e6e6e' },
];

export const HOTBAR: number[] = [
  B.GRASS,
  B.DIRT,
  B.STONE,
  B.COBBLE,
  B.LOG,
  B.PLANKS,
  B.BRICK,
  B.GLASS,
  B.SAND,
  B.LEAVES,
];

function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type Px = [number, number, number, number];

export function createAtlasCanvas(): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = c.height = TILE * GRID;
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(1337);

  const v = (base: number[], amt: number): Px => {
    const k = (rnd() - 0.5) * amt;
    return [base[0] + k, base[1] + k, base[2] + k, 255];
  };

  const paint = (tile: number, fn: (x: number, y: number) => Px) => {
    const tx = (tile % GRID) * TILE;
    const ty = Math.floor(tile / GRID) * TILE;
    const img = ctx.createImageData(TILE, TILE);
    for (let y = 0; y < TILE; y++) {
      for (let x = 0; x < TILE; x++) {
        const p = fn(x, y);
        const i = (y * TILE + x) * 4;
        img.data[i] = p[0];
        img.data[i + 1] = p[1];
        img.data[i + 2] = p[2];
        img.data[i + 3] = p[3];
      }
    }
    ctx.putImageData(img, tx, ty);
  };

  const GRASS = [95, 159, 53];
  const DIRT = [134, 96, 67];

  // 0 grass top
  paint(0, () => v(GRASS, 34));
  // 1 grass side
  const jag = Array.from({ length: TILE }, () => 3 + Math.floor(rnd() * 3));
  paint(1, (x, y) => (y < jag[x] ? v(GRASS, 34) : v(DIRT, 30)));
  // 2 dirt
  paint(2, () => (rnd() < 0.1 ? v([105, 75, 52], 20) : v(DIRT, 26)));
  // 3 stone
  paint(3, () => (rnd() < 0.08 ? v([100, 100, 100], 10) : v([125, 125, 125], 30)));
  // 4 log side
  const colVar = Array.from({ length: TILE }, () => (rnd() - 0.5) * 28);
  paint(4, (x) => {
    const k = (rnd() - 0.5) * 10 + colVar[x];
    return [102 + k, 81 + k, 50 + k, 255];
  });
  // 5 log top
  paint(5, (x, y) => {
    const d = Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5));
    if (d > 6.5) return v([95, 75, 45], 14);
    return Math.floor(d) % 2 ? v([150, 120, 74], 10) : v([172, 140, 88], 10);
  });
  // 6 leaves
  paint(6, () => (rnd() < 0.25 ? v([30, 85, 28], 20) : v([54, 125, 40], 40)));
  // 7 sand
  paint(7, () => v([219, 207, 142], 18));
  // 8 planks
  paint(8, (x, y) => {
    const row = Math.floor(y / 4);
    if (y % 4 === 3) return v([110, 85, 50], 10);
    if (x === (row % 2 ? 11 : 4)) return v([130, 102, 62], 8);
    return v([166, 134, 84], 16);
  });
  // 9 water
  paint(9, () => {
    const p = v([40, 95, 205], 20);
    p[3] = 175;
    return p;
  });
  // 10 brick
  paint(10, (x, y) => {
    const row = Math.floor(y / 4);
    const mortar = y % 4 === 3 || (x + (row % 2) * 4) % 8 === 0;
    return mortar ? v([185, 180, 170], 12) : v([152, 72, 56], 34);
  });
  // 11 glass
  paint(11, (x, y) => {
    if (x === 0 || y === 0 || x === TILE - 1 || y === TILE - 1) return [210, 235, 245, 255];
    if (x === y && x >= 2 && x <= 5) return [255, 255, 255, 200];
    if (x === y + 1 && x >= 3 && x <= 5) return [255, 255, 255, 140];
    return [190, 225, 245, 45];
  });
  // 12 cobblestone
  paint(12, (x, y) => {
    const row = Math.floor(y / 5);
    const off = (row % 2) * 2;
    const col = Math.floor((x + off) / 5);
    const edge = (x + off) % 5 === 0 || y % 5 === 0;
    if (edge) return v([80, 80, 80], 10);
    const h = Math.abs((Math.sin(col * 12.9898 + row * 78.233) * 43758.5453) % 1);
    const b = 100 + h * 50;
    return v([b, b, b], 14);
  });

  return c;
}

export function makeIcons(atlas: HTMLCanvasElement): Record<number, string> {
  const icons: Record<number, string> = {};
  const S = 64;
  const k = 36;
  const s = k / TILE;
  const p0x = S / 2;
  const p0y = (S - 1.5 * k) / 2;
  const c30 = 0.866;

  for (const id of HOTBAR) {
    const def = DEFS[id];
    const cv = document.createElement('canvas');
    cv.width = cv.height = S;
    const ctx = cv.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;

    const tile = (t: number) => ({
      sx: (t % GRID) * TILE,
      sy: Math.floor(t / GRID) * TILE,
    });

    // top
    let t = tile(def.tiles[0]);
    ctx.setTransform(c30 * s, 0.5 * s, -c30 * s, 0.5 * s, p0x, p0y);
    ctx.drawImage(atlas, t.sx, t.sy, TILE, TILE, 0, 0, TILE, TILE);
    // left
    t = tile(def.tiles[2]);
    ctx.setTransform(c30 * s, 0.5 * s, 0, s, p0x - c30 * k, p0y + 0.5 * k);
    ctx.drawImage(atlas, t.sx, t.sy, TILE, TILE, 0, 0, TILE, TILE);
    ctx.fillStyle = 'rgba(0,0,0,0.28)';
    ctx.fillRect(0, 0, TILE, TILE);
    // right
    ctx.setTransform(c30 * s, -0.5 * s, 0, s, p0x, p0y + k);
    ctx.drawImage(atlas, t.sx, t.sy, TILE, TILE, 0, 0, TILE, TILE);
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillRect(0, 0, TILE, TILE);

    icons[id] = cv.toDataURL();
  }
  return icons;
}
