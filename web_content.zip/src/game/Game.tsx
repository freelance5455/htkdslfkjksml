import { useEffect, useLayoutEffect, useMemo, useRef, useSyncExternalStore } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { CELL, COLS, ROWS, WALL_H, WALL_T } from "@/game/maze";
import { Hud } from "@/game/Hud";
import {
  attachInput,
  attachProbe,
  detachInput,
  frameSim,
  getSnap,
  lockLook,
  session,
  subscribe,
} from "@/game/session";

const GEM_COLORS = ["#e36b4a", "#e39b2b", "#f08a5d"];
const FLOWER = ["#e36b4a", "#e39b2b", "#f6f1e6"];

function hash(n: number) {
  const s = Math.sin(n * 127.1) * 43758.5453;
  return s - Math.floor(s);
}

function updateCamera(camera: THREE.PerspectiveCamera, t: number) {
  if (session.phase === "menu") {
    const cx = (COLS * CELL) / 2;
    const cz = (ROWS * CELL) / 2;
    const ang = session.reduce ? 0.7 : t * 0.15;
    const rad = COLS * CELL * 0.82;
    camera.position.set(cx + Math.sin(ang) * rad, 16.2, cz + Math.cos(ang) * rad);
    camera.lookAt(cx, 0.2, cz);
    return;
  }
  const shake = session.reduce ? 0 : session.trauma * session.trauma;
  const sx = (hash(t * 23.1) - 0.5) * 0.14 * shake;
  const sy = (hash(t * 19.4) - 0.5) * 0.09 * shake;
  camera.position.set(session.x + sx, 1.55 + session.bob + sy, session.z);
  camera.rotation.order = "YXZ";
  camera.rotation.y = session.yaw;
  camera.rotation.x = session.pitch;
  camera.rotation.z = (hash(t * 11.2) - 0.5) * 0.025 * shake;
}

function Systems() {
  const camera = useThree((s) => s.camera) as THREE.PerspectiveCamera;
  useFrame((state, delta) => {
    frameSim(delta);
    updateCamera(camera, state.clock.elapsedTime);
  });
  return null;
}

function Sun() {
  const ref = useRef<THREE.DirectionalLight>(null);
  useLayoutEffect(() => {
    const light = ref.current;
    if (!light) return;
    light.target.position.set((COLS * CELL) / 2, 0, (ROWS * CELL) / 2);
    light.parent?.add(light.target);
  }, []);
  const cx = (COLS * CELL) / 2;
  const cz = (ROWS * CELL) / 2;
  return (
    <directionalLight
      ref={ref}
      position={[cx + 14, 24, cz + 8]}
      intensity={2.35}
      color="#fff6e4"
      castShadow
      shadow-mapSize-width={1024}
      shadow-mapSize-height={1024}
      shadow-camera-near={1}
      shadow-camera-far={70}
      shadow-camera-left={-26}
      shadow-camera-right={26}
      shadow-camera-top={26}
      shadow-camera-bottom={-26}
      shadow-bias={-0.0006}
      shadow-normalBias={0.045}
    />
  );
}

function Hedges() {
  const body = useRef<THREE.InstancedMesh>(null);
  const lip = useRef<THREE.InstancedMesh>(null);
  const walls = session.walls;
  useLayoutEffect(() => {
    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    const b = body.current;
    const l = lip.current;
    if (!b || !l) return;
    const greens = ["#27684c", "#2f7a58", "#347f5c", "#245e44"];
    const lips = ["#59b084", "#6dbe96", "#48a078", "#7ec8a4"];
    walls.forEach((w, i) => {
      const sx = w.maxX - w.minX;
      const sz = w.maxZ - w.minZ;
      const x = (w.minX + w.maxX) / 2;
      const z = (w.minZ + w.maxZ) / 2;
      dummy.rotation.set(0, 0, 0);
      dummy.position.set(x, WALL_H / 2, z);
      dummy.scale.set(sx, WALL_H, sz);
      dummy.updateMatrix();
      b.setMatrixAt(i, dummy.matrix);
      color.set(greens[i % greens.length]!);
      b.setColorAt(i, color);
      dummy.position.set(x, WALL_H - 0.08, z);
      dummy.scale.set(sx + 0.05, 0.22, sz + 0.05);
      dummy.updateMatrix();
      l.setMatrixAt(i, dummy.matrix);
      color.set(lips[i % lips.length]!);
      l.setColorAt(i, color);
    });
    b.instanceMatrix.needsUpdate = true;
    l.instanceMatrix.needsUpdate = true;
    if (b.instanceColor) b.instanceColor.needsUpdate = true;
    if (l.instanceColor) l.instanceColor.needsUpdate = true;
  }, [walls]);

  if (!walls.length) return null;
  return (
    <group>
      <instancedMesh ref={body} args={[undefined, undefined, walls.length]} castShadow receiveShadow>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial roughness={0.94} metalness={0} flatShading />
      </instancedMesh>
      <instancedMesh ref={lip} args={[undefined, undefined, walls.length]} castShadow>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial roughness={0.86} metalness={0} flatShading />
      </instancedMesh>
    </group>
  );
}

function Floors() {
  const ref = useRef<THREE.InstancedMesh>(null);
  useLayoutEffect(() => {
    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    const mesh = ref.current;
    if (!mesh) return;
    const tile = CELL - WALL_T - 0.2;
    const colors = ["#f4e7ce", "#ead8b2", "#f8efe0", "#e4cfa4"];
    let i = 0;
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        dummy.rotation.set(0, 0, 0);
        dummy.position.set((c + 0.5) * CELL, 0.03, (r + 0.5) * CELL);
        dummy.scale.set(tile, 0.06, tile);
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);
        color.set(colors[(c * 3 + r * 5) % colors.length]!);
        mesh.setColorAt(i, color);
        i += 1;
      }
    }
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }, []);
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, COLS * ROWS]} receiveShadow>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial roughness={1} metalness={0} />
    </instancedMesh>
  );
}

function Trees() {
  const trunks = useRef<THREE.InstancedMesh>(null);
  const tops = useRef<THREE.InstancedMesh>(null);
  useLayoutEffect(() => {
    const dummy = new THREE.Object3D();
    const trunk = trunks.current;
    const top = tops.current;
    if (!trunk || !top) return;
    session.trees.forEach((t, i) => {
      dummy.rotation.set(0, 0, 0);
      dummy.position.set(t.x, t.h * 0.22, t.z);
      dummy.scale.set(1, t.h * 0.46, 1);
      dummy.updateMatrix();
      trunk.setMatrixAt(i, dummy.matrix);
      dummy.position.set(t.x, t.h * 0.78, t.z);
      dummy.scale.set(t.r, t.h * 0.72, t.r);
      dummy.updateMatrix();
      top.setMatrixAt(i, dummy.matrix);
    });
    trunk.instanceMatrix.needsUpdate = true;
    top.instanceMatrix.needsUpdate = true;
  }, []);
  const n = session.trees.length;
  if (!n) return null;
  return (
    <group>
      <instancedMesh ref={trunks} args={[undefined, undefined, n]} castShadow>
        <cylinderGeometry args={[0.11, 0.16, 1, 5]} />
        <meshStandardMaterial color="#6b422c" roughness={0.92} flatShading />
      </instancedMesh>
      <instancedMesh ref={tops} args={[undefined, undefined, n]} castShadow>
        <coneGeometry args={[1, 1, 6]} />
        <meshStandardMaterial color="#2f7a58" roughness={0.88} flatShading />
      </instancedMesh>
    </group>
  );
}

function Flowers() {
  return (
    <group>
      {session.flowers.map((f, i) => (
        <group key={i} position={[f.x, 0, f.z]}>
          <mesh position={[0, 0.16, 0]} castShadow>
            <cylinderGeometry args={[0.025, 0.04, 0.32, 5]} />
            <meshStandardMaterial color="#2c6b4c" roughness={0.9} flatShading />
          </mesh>
          <mesh position={[0, 0.36, 0]} castShadow>
            <coneGeometry args={[0.15, 0.22, 5]} />
            <meshStandardMaterial
              color={FLOWER[f.kind] ?? "#e36b4a"}
              emissive={FLOWER[f.kind] ?? "#e36b4a"}
              emissiveIntensity={0.12}
              roughness={0.55}
              flatShading
            />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function Gems() {
  const refs = useRef<Array<THREE.Mesh | null>>([]);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    for (let i = 0; i < session.gems.length; i++) {
      const mesh = refs.current[i];
      if (!mesh) continue;
      const live = !session.got[i];
      mesh.visible = live;
      if (!live) continue;
      mesh.position.y = session.reduce ? 0.82 : 0.8 + Math.sin(t * 2 + i * 0.7) * 0.1;
      mesh.rotation.y = session.reduce ? 0.6 : t * 1.2 + i;
    }
  });
  return (
    <group>
      {session.gems.map((g, i) => (
        <mesh
          key={`${session.seed}-${i}`}
          ref={(el: THREE.Mesh | null) => {
            refs.current[i] = el;
          }}
          position={[g.x, 0.82, g.z]}
          castShadow
        >
          <octahedronGeometry args={[0.26, 0]} />
          <meshStandardMaterial
            color={GEM_COLORS[i % GEM_COLORS.length]}
            emissive={GEM_COLORS[i % GEM_COLORS.length]}
            emissiveIntensity={0.62}
            roughness={0.28}
            flatShading
          />
        </mesh>
      ))}
    </group>
  );
}

function Lantern() {
  const gem = useRef<THREE.Mesh>(null);
  useFrame(({ clock }) => {
    if (!gem.current || session.reduce) return;
    const t = clock.elapsedTime;
    gem.current.position.y = 1.62 + Math.sin(t * 1.8) * 0.07;
    gem.current.rotation.y = t * 0.7;
  });
  return (
    <group position={[session.exitX, 0, session.exitZ]}>
      <mesh position={[-0.62, 0.72, 0]} castShadow>
        <boxGeometry args={[0.12, 1.44, 0.12]} />
        <meshStandardMaterial color="#6b422c" roughness={0.86} flatShading />
      </mesh>
      <mesh position={[0.62, 0.72, 0]} castShadow>
        <boxGeometry args={[0.12, 1.44, 0.12]} />
        <meshStandardMaterial color="#6b422c" roughness={0.86} flatShading />
      </mesh>
      <mesh position={[0, 1.46, 0]} castShadow>
        <boxGeometry args={[1.4, 0.1, 0.12]} />
        <meshStandardMaterial color="#6b422c" roughness={0.86} flatShading />
      </mesh>
      <mesh ref={gem} position={[0, 1.62, 0]}>
        <octahedronGeometry args={[0.24, 0]} />
        <meshStandardMaterial
          color="#ffe7a8"
          emissive="#e39b2b"
          emissiveIntensity={1.35}
          roughness={0.22}
          flatShading
        />
      </mesh>
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.05, 0]}>
        <ringGeometry args={[0.42, 0.62, 6]} />
        <meshStandardMaterial color="#e39b2b" emissive="#e39b2b" emissiveIntensity={0.45} roughness={0.45} />
      </mesh>
      <pointLight position={[0, 1.7, 0]} color="#ffc14d" intensity={16} distance={9} decay={2} />
    </group>
  );
}

function Fireflies() {
  const positions = useMemo(() => new Float32Array(session.flies.length * 3), []);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    return g;
  }, [positions]);
  useEffect(() => () => geo.dispose(), [geo]);
  const mat = useMemo(() => {
    const m = new THREE.PointsMaterial({
      color: "#ffe08a",
      size: 7,
      sizeAttenuation: false,
      transparent: true,
      opacity: 0.9,
      depthWrite: false,
    });
    return m;
  }, []);
  useEffect(() => () => mat.dispose(), [mat]);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    session.flies.forEach((f, i) => {
      positions[i * 3] = f.x + Math.cos(t * 0.6 + f.phase) * 0.22;
      positions[i * 3 + 1] = f.y + (session.reduce ? 0 : Math.sin(t * 1.5 + f.phase) * 0.16);
      positions[i * 3 + 2] = f.z + Math.sin(t * 0.45 + f.phase) * 0.22;
    });
    const attr = geo.getAttribute("position") as THREE.BufferAttribute;
    attr.needsUpdate = true;
  });
  return <points geometry={geo} material={mat} />;
}

function Bursts() {
  const mesh = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const color = useMemo(() => new THREE.Color(), []);
  useFrame(() => {
    const m = mesh.current;
    if (!m) return;
    const list = session.particles;
    for (let i = 0; i < 72; i++) {
      const p = list[i];
      if (p) {
        dummy.position.set(p.x, p.y, p.z);
        const s = Math.max(0.04, (p.life / p.max) * 0.16);
        dummy.scale.setScalar(s);
        dummy.rotation.set(0, 0, 0);
        color.setHex(p.color);
      } else {
        dummy.position.set(0, -8, 0);
        dummy.scale.setScalar(0.001);
        color.setHex(0xe39b2b);
      }
      dummy.updateMatrix();
      m.setMatrixAt(i, dummy.matrix);
      m.setColorAt(i, color);
    }
    m.instanceMatrix.needsUpdate = true;
    if (m.instanceColor) m.instanceColor.needsUpdate = true;
  });
  return (
    <instancedMesh ref={mesh} args={[undefined, undefined, 72]}>
      <octahedronGeometry args={[1, 0]} />
      <meshStandardMaterial emissive="#e39b2b" emissiveIntensity={0.9} roughness={0.35} flatShading />
    </instancedMesh>
  );
}

function World() {
  const span = Math.max(COLS, ROWS) * CELL + 16;
  return (
    <>
      <color attach="background" args={["#f6d8b0"]} />
      <fog attach="fog" args={["#f6d8b0", 18, 52]} />
      <hemisphereLight args={["#fff1dc", "#87b56e", 0.72]} />
      <ambientLight intensity={0.28} color="#fff8ee" />
      <Sun />
      <mesh rotation-x={-Math.PI / 2} position={[(COLS * CELL) / 2, -0.04, (ROWS * CELL) / 2]} receiveShadow>
        <planeGeometry args={[span, span]} />
        <meshStandardMaterial color="#a9cf96" roughness={1} />
      </mesh>
      <Floors />
      <Hedges />
      <Trees />
      <Flowers />
      <Gems />
      <Lantern />
      <Fireflies />
      <Bursts />
      <Systems />
    </>
  );
}

export function Game({ touch }: { touch: boolean }) {
  const snap = useSyncExternalStore(subscribe, getSnap, getSnap);
  return (
    <div
      className="game-root relative h-dvh w-full touch-none overflow-hidden bg-sky text-ink"
      onPointerDown={(e) => {
        if (touch || session.phase !== "play") return;
        if ((e.target as HTMLElement).closest("button")) return;
        if (document.pointerLockElement === session.canvas) return;
        lockLook();
      }}
    >
      <Canvas
        className="absolute inset-0 h-full w-full"
        shadows
        dpr={[1, 1.7]}
        camera={{ fov: 74, near: 0.08, far: 90, position: [18, 16, 30] }}
        gl={{ antialias: true, alpha: false, powerPreference: "high-performance" }}
        onCreated={({ gl }) => {
          gl.setClearColor("#f6d8b0");
          gl.toneMapping = THREE.ACESFilmicToneMapping;
          gl.toneMappingExposure = 1.06;
          session.canvas = gl.domElement;
        }}
      >
        <World key={snap.seed} />
      </Canvas>
      <Hud touch={touch} />
    </div>
  );
}

export function mountInput() {
  attachInput();
  attachProbe();
  return () => detachInput();
}
