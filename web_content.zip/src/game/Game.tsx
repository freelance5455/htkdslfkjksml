import { useEffect, useRef, useState } from "react";
import { House, Pause, Play, RotateCcw, Volume2, VolumeX } from "lucide-react";
import { playSfx, unlockAudio } from "@/game/audio";
import { draw } from "@/game/draw";
import { loadMuted, loadScores, qualifies, saveMuted, saveScore, type ScoreEntry } from "@/game/scores";
import { createSim, pauseRun, resumeRun, startRun, step, toTitle, togglePause } from "@/game/sim";
import type { Input, Phase, Sim, Sprites } from "@/game/types";
import { H, W } from "@/game/types";

function fmt(n: number) {
  return n.toLocaleString("en-US");
}

export function Game() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  const simRef = useRef<Sim | null>(null);
  const keysRef = useRef<Set<string>>(new Set());
  const injectedRef = useRef<Set<string>>(new Set());
  const pointerRef = useRef({ hovering: false, touch: false, px: W / 2, py: H - 150 });
  const spritesRef = useRef<Sprites>({});
  const mutedRef = useRef(false);
  const nameRef = useRef<HTMLInputElement>(null);

  const [phase, setPhase] = useState<Phase>("title");
  const [snap, setSnap] = useState({ score: 0, wave: 1 });
  const [scores, setScores] = useState<ScoreEntry[]>([]);
  const [muted, setMuted] = useState(false);
  const [name, setName] = useState("");
  const [saved, setSaved] = useState(false);
  const [boardOpen, setBoardOpen] = useState(false);

  useEffect(() => {
    setScores(loadScores());
    const m = loadMuted();
    setMuted(m);
    mutedRef.current = m;
  }, []);

  useEffect(() => {
    if (phase === "over") nameRef.current?.focus();
  }, [phase]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const frame = frameRef.current;
    if (!canvas || !frame) return;

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const sim = createSim(reduce);
    simRef.current = sim;
    sim.sfx = (name) => {
      if (!mutedRef.current) playSfx(name);
    };
    sim.onChange = () => {
      setPhase(sim.phase);
      setSnap({ score: sim.score, wave: sim.wave });
      if (sim.phase === "over") {
        setSaved(false);
        setName("");
        setBoardOpen(false);
      }
    };

    const sprites: Sprites = {};
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      sprites.player = img;
      spritesRef.current = { ...sprites };
    };
    img.src = "/sprites/player.png";

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = Math.max(1, Math.round(rect.width * dpr));
      canvas.height = Math.max(1, Math.round(rect.height * dpr));
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const toWorld = (clientX: number, clientY: number) => {
      const rect = canvas.getBoundingClientRect();
      return {
        x: ((clientX - rect.left) / rect.width) * W,
        y: ((clientY - rect.top) / rect.height) * H,
      };
    };

    const menuTarget = (target: EventTarget | null) =>
      target instanceof Element && !!target.closest("button, input, a, textarea, .overlay");

    const onPointerDown = (e: PointerEvent) => {
      if (menuTarget(e.target)) {
        pointerRef.current.hovering = false;
        return;
      }
      unlockAudio();
      const p = toWorld(e.clientX, e.clientY);
      pointerRef.current.hovering = true;
      pointerRef.current.touch = e.pointerType !== "mouse";
      pointerRef.current.px = p.x;
      pointerRef.current.py = p.y;
    };
    const onPointerMove = (e: PointerEvent) => {
      if (menuTarget(e.target)) return;
      if (e.pointerType === "touch" && e.buttons === 0) return;
      const p = toWorld(e.clientX, e.clientY);
      pointerRef.current.hovering = true;
      pointerRef.current.touch = e.pointerType !== "mouse";
      pointerRef.current.px = p.x;
      pointerRef.current.py = p.y;
    };
    const onPointerUp = (e: PointerEvent) => {
      if (e.pointerType !== "mouse") pointerRef.current.hovering = false;
    };
    const onPointerLeave = (e: PointerEvent) => {
      if (e.pointerType === "mouse") pointerRef.current.hovering = false;
    };

    const typing = (target: EventTarget | null) =>
      target instanceof HTMLElement &&
      (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable);

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (typing(e.target)) return;
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"].includes(e.code)) {
        e.preventDefault();
      }
      keysRef.current.add(e.code);
      if (e.code === "Enter" && sim.phase === "title") {
        unlockAudio();
        startRun(sim);
      }
      if ((e.code === "Escape" || e.code === "KeyP") && (sim.phase === "playing" || sim.phase === "paused")) {
        e.preventDefault();
        togglePause(sim);
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keysRef.current.delete(e.code);
    };
    const onBlur = () => {
      keysRef.current.clear();
    };
    const onVis = () => {
      if (document.hidden && sim.phase === "playing") pauseRun(sim);
      if (!document.hidden) unlockAudio();
    };

    frame.addEventListener("pointerdown", onPointerDown);
    frame.addEventListener("pointermove", onPointerMove);
    frame.addEventListener("pointerup", onPointerUp);
    frame.addEventListener("pointercancel", onPointerUp);
    frame.addEventListener("pointerleave", onPointerLeave);
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    document.addEventListener("visibilitychange", onVis);

    window.__controlsTest = {
      getYaw: () => -Math.PI / 2,
      getSpeed: () => Math.hypot(sim.player.vx, sim.player.vy),
      getX: () => sim.player.x,
      getY: () => sim.player.y,
      setKeys: (codes) => {
        injectedRef.current = new Set(codes);
      },
    };
    window.__game = {
      getPhase: () => sim.phase,
      getScore: () => sim.score,
      getLives: () => sim.lives,
      getWave: () => sim.wave,
      getMulti: () => sim.player.multi,
      getShield: () => sim.player.shield,
      getSpeedT: () => sim.player.speedT,
    };

    let raf = 0;
    let last = performance.now();
    let acc = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      acc += dt;
      let guard = 0;
      while (acc >= 1 / 60 && guard++ < 5) {
        step(sim, 1 / 60, readInput(keysRef.current, injectedRef.current, pointerRef.current));
        acc -= 1 / 60;
      }
      const ctx = canvas.getContext("2d");
      if (ctx) draw(ctx, sim, spritesRef.current);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      frame.removeEventListener("pointerdown", onPointerDown);
      frame.removeEventListener("pointermove", onPointerMove);
      frame.removeEventListener("pointerup", onPointerUp);
      frame.removeEventListener("pointercancel", onPointerUp);
      frame.removeEventListener("pointerleave", onPointerLeave);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
      document.removeEventListener("visibilitychange", onVis);
      delete window.__controlsTest;
      delete window.__game;
    };
  }, []);

  const sim = () => simRef.current;

  const start = () => {
    unlockAudio();
    const s = sim();
    if (s) startRun(s);
  };
  const pause = () => {
    const s = sim();
    if (s) pauseRun(s);
  };
  const resume = () => {
    const s = sim();
    if (s) resumeRun(s);
  };
  const restart = () => {
    unlockAudio();
    const s = sim();
    if (s) startRun(s);
  };
  const title = () => {
    const s = sim();
    if (s) toTitle(s);
  };
  const toggleMute = () => {
    setMuted((m) => {
      const next = !m;
      mutedRef.current = next;
      saveMuted(next);
      return next;
    });
  };
  const submit = () => {
    if (saved) return;
    const next = saveScore(name, snap.score, snap.wave);
    setScores(next);
    setSaved(true);
  };

  const onBoard = qualifies(snap.score, scores) && !saved;

  return (
    <div className="shell">
      <aside className="rail">
        <p className="kicker">Arcade sortie</p>
        <h1 className="wordmark">Lumen Raid</h1>
        <p className="lede">
          Hold the lane. Waves roll down the starfield — spread fire, a shield, and a speed boost are the only favors out here.
        </p>
        <ul className="legend">
          <li>
            <i className="swatch swatch-dart" /> Darts dive in packs
          </li>
          <li>
            <i className="swatch swatch-weaver" /> Weavers drift on a sine
          </li>
          <li>
            <i className="swatch swatch-gun" /> Gunships track and fire
          </li>
          <li>
            <i className="swatch swatch-boss" /> A dreadnought every fifth wave
          </li>
        </ul>
        <p className="help">WASD or arrows to fly. Move the pointer to take the stick — a direction key grabs it back. Weapons fire on their own. P or Esc pauses.</p>
      </aside>

      <div className="stage">
        <div className="frame" ref={frameRef} role="application" aria-label="Lumen Raid playfield">
          <canvas ref={canvasRef} aria-hidden="true" />
          {phase === "playing" ? (
            <button type="button" className="icon-btn pause-btn" onClick={pause} aria-label="Pause">
              <Pause size={18} />
            </button>
          ) : null}
          <button
            type="button"
            className="icon-btn mute-btn"
            onClick={toggleMute}
            aria-label={muted ? "Unmute" : "Mute"}
            aria-pressed={muted}
          >
            {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
          </button>

          {phase === "title" ? (
            <div className="overlay">
              <div className="panel">
                <p className="kicker">Sortie ready</p>
                <h1>Lumen Raid</h1>
                <p className="help">
                  Top-down waves, three lives, and pods for spread shot, shield, and speed. Your best runs stay on this device.
                </p>
                <button type="button" className="btn btn-primary btn-block" onClick={start}>
                  <Play size={16} /> Start
                </button>
                <p className="help">Keys: WASD or arrows. Pointer: drag, or just move it. Guns fire automatically.</p>
                <div className="inline-board">
                  <p className="kicker">High scores</p>
                  <Board entries={scores.slice(0, boardOpen ? 10 : 3)} />
                  {scores.length > 3 ? (
                    <button type="button" className="btn" onClick={() => setBoardOpen((v) => !v)}>
                      {boardOpen ? "Top three" : "Full board"}
                    </button>
                  ) : null}
                </div>
              </div>
            </div>
          ) : null}

          {phase === "paused" ? (
            <div className="overlay">
              <div className="panel">
                <p className="kicker">Holding</p>
                <h2>Paused</h2>
                <p className="help">
                  Wave {snap.wave} · {fmt(snap.score)}
                </p>
                <div className="actions">
                  <button type="button" className="btn btn-primary" onClick={resume}>
                    <Play size={16} /> Resume
                  </button>
                  <button type="button" className="btn" onClick={restart}>
                    <RotateCcw size={16} /> Restart
                  </button>
                  <button type="button" className="btn" onClick={title}>
                    <House size={16} /> Title
                  </button>
                </div>
                <p className="kicker">High scores</p>
                <Board entries={scores} />
                <p className="help">Esc or P resumes.</p>
              </div>
            </div>
          ) : null}

          {phase === "over" ? (
            <div className="overlay">
              <div className="panel">
                <p className="kicker">{snap.score > 0 && snap.score >= (scores[0]?.score ?? 0) ? "New record" : "Shot down"}</p>
                <h2>Run over</h2>
                <p className="score-hero">{fmt(snap.score)}</p>
                <p className="help">Reached wave {snap.wave}</p>
                {onBoard ? (
                  <form
                    className="form-row"
                    onSubmit={(e) => {
                      e.preventDefault();
                      submit();
                    }}
                  >
                    <label className="visually-hidden" htmlFor="pilot-name">
                      Pilot name
                    </label>
                    <input
                      id="pilot-name"
                      ref={nameRef}
                      className="field"
                      value={name}
                      maxLength={16}
                      placeholder="Pilot name"
                      autoComplete="off"
                      spellCheck={false}
                      onChange={(e) => setName(e.target.value)}
                    />
                    <button type="submit" className="btn btn-primary">
                      Save
                    </button>
                  </form>
                ) : saved ? (
                  <p className="help">Logged on the board.</p>
                ) : (
                  <p className="help">{snap.score <= 0 ? "No score to log." : "Outside the top ten."}</p>
                )}
                <div className="actions">
                  <button type="button" className="btn btn-primary" onClick={restart}>
                    <RotateCcw size={16} /> Again
                  </button>
                  <button type="button" className="btn" onClick={title}>
                    <House size={16} /> Title
                  </button>
                </div>
                <p className="kicker">High scores</p>
                <Board entries={scores} />
              </div>
            </div>
          ) : null}
        </div>
      </div>

      <aside className="rail rail-right">
        <p className="kicker">High scores</p>
        <h2 className="wordmark">Board</h2>
        <Board entries={scores} />
        <p className="lede">Ten pilots. This browser only — no account, no cloud.</p>
      </aside>
    </div>
  );
}

function Board({ entries }: { entries: ScoreEntry[] }) {
  if (!entries.length) return <p className="empty">No pilots logged yet.</p>;
  return (
    <ol className="board">
      {entries.map((e, i) => (
        <li key={`${e.at}-${e.name}-${i}`}>
          <span className="rank">{i + 1}</span>
          <span className="who">
            {e.name}
            <span className="rank"> · W{e.wave}</span>
          </span>
          <span className="pts">{fmt(e.score)}</span>
        </li>
      ))}
    </ol>
  );
}

function readInput(
  keys: Set<string>,
  injected: Set<string>,
  pointer: { hovering: boolean; touch: boolean; px: number; py: number },
): Input {
  const has = (code: string) => keys.has(code) || injected.has(code);
  const left = has("KeyA") || has("ArrowLeft");
  const right = has("KeyD") || has("ArrowRight");
  const up = has("KeyW") || has("ArrowUp");
  const down = has("KeyS") || has("ArrowDown");
  const keying = left || right || up || down;
  return {
    mode: keying ? "keys" : pointer.hovering ? "pointer" : "idle",
    left,
    right,
    up,
    down,
    px: pointer.px,
    py: pointer.py,
    touch: pointer.touch,
  };
}
