import type { AABB, Vec2 } from "./types";

export class NavGrid {
  cell: number;
  ox: number;
  oz: number;
  cols: number;
  rows: number;
  walk: Uint8Array;

  constructor(minX: number, minZ: number, maxX: number, maxZ: number, cell = 0.7) {
    this.cell = cell;
    this.ox = minX;
    this.oz = minZ;
    this.cols = Math.max(4, Math.ceil((maxX - minX) / cell));
    this.rows = Math.max(4, Math.ceil((maxZ - minZ) / cell));
    this.walk = new Uint8Array(this.cols * this.rows);
    this.walk.fill(1);
  }

  stamp(boxes: AABB[], pad = 0.15): void {
    for (const b of boxes) {
      const x0 = Math.max(0, Math.floor((b.minX - pad - this.ox) / this.cell));
      const z0 = Math.max(0, Math.floor((b.minZ - pad - this.oz) / this.cell));
      const x1 = Math.min(this.cols - 1, Math.floor((b.maxX + pad - this.ox) / this.cell));
      const z1 = Math.min(this.rows - 1, Math.floor((b.maxZ + pad - this.oz) / this.cell));
      for (let z = z0; z <= z1; z++) {
        for (let x = x0; x <= x1; x++) this.walk[z * this.cols + x] = 0;
      }
    }
  }

  world(i: number, j: number): Vec2 {
    return { x: this.ox + (i + 0.5) * this.cell, z: this.oz + (j + 0.5) * this.cell };
  }

  cellAt(x: number, z: number): { i: number; j: number } {
    return {
      i: Math.max(0, Math.min(this.cols - 1, Math.floor((x - this.ox) / this.cell))),
      j: Math.max(0, Math.min(this.rows - 1, Math.floor((z - this.oz) / this.cell))),
    };
  }

  isWalk(i: number, j: number): boolean {
    if (i < 0 || j < 0 || i >= this.cols || j >= this.rows) return false;
    return this.walk[j * this.cols + i] === 1;
  }

  nearestWalk(x: number, z: number): Vec2 {
    const c = this.cellAt(x, z);
    if (this.isWalk(c.i, c.j)) return { x, z };
    let best = 99;
    let bi = c.i;
    let bj = c.j;
    for (let r = 1; r < 8; r++) {
      for (let dj = -r; dj <= r; dj++) {
        for (let di = -r; di <= r; di++) {
          if (!this.isWalk(c.i + di, c.j + dj)) continue;
          const d = Math.abs(di) + Math.abs(dj);
          if (d < best) {
            best = d;
            bi = c.i + di;
            bj = c.j + dj;
          }
        }
      }
      if (best < 99) break;
    }
    return this.world(bi, bj);
  }

  find(sx: number, sz: number, tx: number, tz: number): Vec2[] {
    const a = this.cellAt(sx, sz);
    const b = this.cellAt(tx, tz);
    if (!this.isWalk(a.i, a.j)) {
      const n = this.nearestWalk(sx, sz);
      Object.assign(a, this.cellAt(n.x, n.z));
    }
    if (!this.isWalk(b.i, b.j)) {
      const n = this.nearestWalk(tx, tz);
      Object.assign(b, this.cellAt(n.x, n.z));
    }
    const start = a.j * this.cols + a.i;
    const goal = b.j * this.cols + b.i;
    if (start === goal) return [{ x: tx, z: tz }];

    const cols = this.cols;
    const n = cols * this.rows;
    const came = new Int32Array(n).fill(-1);
    const gScore = new Float32Array(n).fill(1e9);
    const open: number[] = [start];
    gScore[start] = 0;
    const gi = goal % cols;
    const gj = (goal / cols) | 0;

    const h = (idx: number) => {
      const i = idx % cols;
      const j = (idx / cols) | 0;
      const dx = Math.abs(i - gi);
      const dz = Math.abs(j - gj);
      return dx + dz + (Math.SQRT2 - 2) * Math.min(dx, dz);
    };

    let found = false;
    let guard = 0;
    while (open.length && guard++ < 4000) {
      let best = 0;
      let bf = 1e9;
      for (let k = 0; k < open.length; k++) {
        const idx = open[k]!;
        const f = gScore[idx]! + h(idx);
        if (f < bf) {
          bf = f;
          best = k;
        }
      }
      const cur = open.splice(best, 1)[0]!;
      if (cur === goal) {
        found = true;
        break;
      }
      const ci = cur % cols;
      const cj = (cur / cols) | 0;
      for (let dj = -1; dj <= 1; dj++) {
        for (let di = -1; di <= 1; di++) {
          if (!di && !dj) continue;
          const ni = ci + di;
          const nj = cj + dj;
          if (!this.isWalk(ni, nj)) continue;
          if (di && dj && (!this.isWalk(ci + di, cj) || !this.isWalk(ci, cj + dj))) continue;
          const nidx = nj * cols + ni;
          const step = di && dj ? Math.SQRT2 : 1;
          const ng = gScore[cur]! + step;
          if (ng < gScore[nidx]!) {
            gScore[nidx] = ng;
            came[nidx] = cur;
            if (!open.includes(nidx)) open.push(nidx);
          }
        }
      }
    }

    if (!found) return [{ x: tx, z: tz }];
    const rev: Vec2[] = [{ x: tx, z: tz }];
    let c = goal;
    while (c !== start && c !== -1) {
      rev.push(this.world(c % cols, (c / cols) | 0));
      c = came[c]!;
    }
    rev.reverse();
    return simplify(rev);
  }
}

function simplify(path: Vec2[]): Vec2[] {
  if (path.length < 3) return path;
  const out: Vec2[] = [path[0]!];
  for (let i = 1; i < path.length - 1; i++) {
    const a = out[out.length - 1]!;
    const b = path[i]!;
    const c = path[i + 1]!;
    const abx = b.x - a.x;
    const abz = b.z - a.z;
    const bcx = c.x - b.x;
    const bcz = c.z - b.z;
    const cross = abx * bcz - abz * bcx;
    if (Math.abs(cross) > 0.04) out.push(b);
  }
  out.push(path[path.length - 1]!);
  return out;
}
