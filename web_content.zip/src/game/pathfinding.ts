import { Point, TileType } from '../types/game';

export function isWalkable(grid: TileType[][], gx: number, gy: number): boolean {
  if (gy < 0 || gy >= grid.length || gx < 0 || gx >= grid[0].length) {
    return false;
  }
  // 0 is FLOOR, 2 is PORTAL. Both are walkable. 1 is WALL.
  return grid[gy][gx] !== 1;
}

export function findPath(
  grid: TileType[][],
  start: Point,
  target: Point,
  maxSteps = 1200
): Point[] {
  if (start.x === target.x && start.y === target.y) {
    return [start];
  }

  if (!isWalkable(grid, target.x, target.y) || !isWalkable(grid, start.x, start.y)) {
    return [];
  }

  const queue: Point[] = [start];
  const cameFrom = new Map<string, Point | null>();
  cameFrom.set(`${start.x},${start.y}`, null);

  const targetKey = `${target.x},${target.y}`;
  let found = false;
  let steps = 0;

  const dirs: Point[] = [
    { x: 0, y: -1 },
    { x: 1, y: 0 },
    { x: 0, y: 1 },
    { x: -1, y: 0 },
  ];

  while (queue.length > 0 && steps < maxSteps) {
    steps++;
    const current = queue.shift()!;
    const curKey = `${current.x},${current.y}`;

    if (curKey === targetKey) {
      found = true;
      break;
    }

    for (const dir of dirs) {
      const nx = current.x + dir.x;
      const ny = current.y + dir.y;
      const nextKey = `${nx},${ny}`;

      if (isWalkable(grid, nx, ny) && !cameFrom.has(nextKey)) {
        cameFrom.set(nextKey, current);
        queue.push({ x: nx, y: ny });
      }
    }
  }

  if (!found) {
    return [];
  }

  // Reconstruct path
  const path: Point[] = [];
  let curr: Point | null = target;
  while (curr !== null) {
    path.unshift(curr);
    const currPoint: Point = curr;
    const lookupKey = `${currPoint.x},${currPoint.y}`;
    curr = cameFrom.get(lookupKey) ?? null;
  }

  return path;
}

// Line of sight check between two points using ray-stepping
export function hasLineOfSight(
  grid: TileType[][],
  p1: Point,
  p2: Point,
  tileSize: number,
  maxDistancePx = 550
): boolean {
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const dist = Math.hypot(dx, dy);

  if (dist > maxDistancePx) {
    return false;
  }
  if (dist < 1) {
    return true;
  }

  // Step along the ray in increments of 1/3 tile size to avoid skipping corners
  const stepSize = tileSize * 0.35;
  const steps = Math.ceil(dist / stepSize);
  const stepX = dx / steps;
  const stepY = dy / steps;

  for (let i = 1; i < steps; i++) {
    const checkX = Math.floor((p1.x + stepX * i) / tileSize);
    const checkY = Math.floor((p1.y + stepY * i) / tileSize);

    if (!isWalkable(grid, checkX, checkY)) {
      return false; // wall blocks view
    }
  }

  return true;
}

export function getDistance(a: Point, b: Point): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}
