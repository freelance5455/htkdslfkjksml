export type MusicTrackId =
  | 'none'
  | 'menu'
  | 'forest'
  | 'cyber'
  | 'frozen'
  | 'volcanic'
  | 'shadow'
  | 'celestial'
  | 'boss';

export type SfxId =
  | 'slash1'
  | 'slash2'
  | 'slash3'
  | 'jump'
  | 'doubleJump'
  | 'dash'
  | 'hitEnemy'
  | 'critHit'
  | 'playerHurt'
  | 'skillCast'
  | 'ultimateCast'
  | 'bossWarning'
  | 'checkpoint'
  | 'coin'
  | 'secretChest'
  | 'victory'
  | 'defeat'
  | 'uiClick'
  | 'heroUnlock'
  | 'potion';

interface TrackPattern {
  tempoMs: number;
  wave: OscillatorType;
  bassWave: OscillatorType;
  notes: number[];
  bassNotes: number[];
  filterFreq: number;
}

const TRACK_PATTERNS: Record<Exclude<MusicTrackId, 'none'>, TrackPattern> = {
  menu: {
    tempoMs: 360,
    wave: 'triangle',
    bassWave: 'sine',
    notes: [293.66, 349.23, 440.0, 523.25, 587.33, 523.25, 440.0, 392.0],
    bassNotes: [146.83, 146.83, 130.81, 130.81, 116.54, 116.54, 130.81, 146.83],
    filterFreq: 1600,
  },
  forest: {
    tempoMs: 310,
    wave: 'sine',
    bassWave: 'triangle',
    notes: [329.63, 392.0, 440.0, 493.88, 587.33, 493.88, 440.0, 392.0],
    bassNotes: [164.81, 164.81, 196.0, 196.0, 146.83, 146.83, 164.81, 164.81],
    filterFreq: 1900,
  },
  cyber: {
    tempoMs: 210,
    wave: 'sawtooth',
    bassWave: 'sawtooth',
    notes: [329.63, 0, 392.0, 493.88, 329.63, 440.0, 392.0, 293.66],
    bassNotes: [82.41, 82.41, 98.0, 98.0, 110.0, 110.0, 73.42, 82.41],
    filterFreq: 1150,
  },
  frozen: {
    tempoMs: 380,
    wave: 'sine',
    bassWave: 'sine',
    notes: [523.25, 659.25, 783.99, 987.77, 783.99, 659.25, 587.33, 493.88],
    bassNotes: [130.81, 130.81, 164.81, 164.81, 146.83, 146.83, 123.47, 130.81],
    filterFreq: 2400,
  },
  volcanic: {
    tempoMs: 240,
    wave: 'sawtooth',
    bassWave: 'triangle',
    notes: [220.0, 233.08, 293.66, 220.0, 329.63, 293.66, 233.08, 196.0],
    bassNotes: [110.0, 110.0, 116.54, 110.0, 98.0, 98.0, 110.0, 82.41],
    filterFreq: 950,
  },
  shadow: {
    tempoMs: 290,
    wave: 'triangle',
    bassWave: 'sawtooth',
    notes: [261.63, 311.13, 392.0, 415.3, 523.25, 415.3, 392.0, 311.13],
    bassNotes: [130.81, 130.81, 103.83, 103.83, 98.0, 98.0, 116.54, 123.47],
    filterFreq: 1400,
  },
  celestial: {
    tempoMs: 300,
    wave: 'triangle',
    bassWave: 'sine',
    notes: [440.0, 554.37, 659.25, 880.0, 830.61, 659.25, 587.33, 659.25],
    bassNotes: [110.0, 138.59, 164.81, 220.0, 185.0, 164.81, 146.83, 164.81],
    filterFreq: 2300,
  },
  boss: {
    tempoMs: 175,
    wave: 'sawtooth',
    bassWave: 'sawtooth',
    notes: [293.66, 349.23, 293.66, 440.0, 466.16, 440.0, 349.23, 329.63],
    bassNotes: [73.42, 73.42, 87.31, 73.42, 77.78, 73.42, 65.41, 69.3],
    filterFreq: 1350,
  },
};

class SoundEngine {
  private ctx: AudioContext | null = null;
  private musicVolume = 0.45;
  private sfxVolume = 0.7;
  private currentTrack: MusicTrackId = 'none';
  private loopTimer: number | null = null;
  private stepIndex = 0;

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        try {
          this.ctx = new AudioCtx();
        } catch {
          return null;
        }
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public unlockAudio() {
    this.ensureContext();
  }

  public setVolumes(musicVol: number, sfxVol: number) {
    this.musicVolume = Math.max(0, Math.min(1, musicVol));
    this.sfxVolume = Math.max(0, Math.min(1, sfxVol));
  }

  public playMusic(track: MusicTrackId) {
    if (this.currentTrack === track && this.loopTimer !== null) return;
    this.stopMusic();
    this.currentTrack = track;
    if (track === 'none') return;

    const pattern = TRACK_PATTERNS[track];
    this.stepIndex = 0;

    const tick = () => {
      if (this.currentTrack !== track) return;
      if (this.musicVolume > 0.01) {
        const ctx = this.ensureContext();
        if (ctx && ctx.state === 'running') {
          this.playMusicStep(ctx, pattern, this.stepIndex);
        }
      }
      this.stepIndex = (this.stepIndex + 1) % pattern.notes.length;
      this.loopTimer = window.setTimeout(tick, pattern.tempoMs);
    };

    tick();
  }

  public stopMusic() {
    if (this.loopTimer !== null) {
      clearTimeout(this.loopTimer);
      this.loopTimer = null;
    }
    this.currentTrack = 'none';
  }

  private playMusicStep(ctx: AudioContext, pattern: TrackPattern, idx: number) {
    const now = ctx.currentTime;
    const note = pattern.notes[idx];
    const bass = pattern.bassNotes[idx];
    const dur = (pattern.tempoMs / 1000) * 0.92;

    if (note > 0) {
      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();
      osc.type = pattern.wave;
      osc.frequency.setValueAtTime(note, now);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(pattern.filterFreq, now);

      const peak = 0.065 * this.musicVolume;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(peak, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + dur + 0.02);
    }

    if (bass > 0 && idx % 2 === 0) {
      const bOsc = ctx.createOscillator();
      const bGain = ctx.createGain();
      bOsc.type = pattern.bassWave;
      bOsc.frequency.setValueAtTime(bass, now);
      const bPeak = 0.055 * this.musicVolume;
      bGain.gain.setValueAtTime(0.0001, now);
      bGain.gain.linearRampToValueAtTime(bPeak, now + 0.03);
      bGain.gain.exponentialRampToValueAtTime(0.0001, now + dur * 1.8);
      bOsc.connect(bGain);
      bGain.connect(ctx.destination);
      bOsc.start(now);
      bOsc.stop(now + dur * 1.85);
    }
  }

  public playSfx(id: SfxId) {
    if (this.sfxVolume <= 0.01) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const v = this.sfxVolume;

    const tone = (
      freqStart: number,
      freqEnd: number,
      dur: number,
      type: OscillatorType = 'sine',
      vol = 0.14,
      delay = 0
    ) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freqStart, now + delay);
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), now + delay + dur);
      g.gain.setValueAtTime(0.0001, now + delay);
      g.gain.linearRampToValueAtTime(vol * v, now + delay + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, now + delay + dur);
      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(now + delay);
      osc.stop(now + delay + dur + 0.02);
    };

    switch (id) {
      case 'slash1':
        tone(520, 170, 0.11, 'sawtooth', 0.12);
        break;
      case 'slash2':
        tone(640, 210, 0.12, 'sawtooth', 0.13);
        break;
      case 'slash3':
        tone(780, 140, 0.18, 'sawtooth', 0.17);
        tone(390, 190, 0.18, 'triangle', 0.12);
        break;
      case 'jump':
        tone(240, 520, 0.12, 'sine', 0.11);
        break;
      case 'doubleJump':
        tone(380, 780, 0.14, 'triangle', 0.12);
        break;
      case 'dash':
        tone(440, 130, 0.15, 'triangle', 0.14);
        break;
      case 'hitEnemy':
        tone(190, 75, 0.09, 'square', 0.12);
        break;
      case 'critHit':
        tone(880, 320, 0.14, 'sawtooth', 0.15);
        tone(1180, 590, 0.12, 'triangle', 0.11, 0.02);
        break;
      case 'playerHurt':
        tone(180, 65, 0.18, 'sawtooth', 0.17);
        break;
      case 'skillCast':
        tone(360, 880, 0.22, 'triangle', 0.15);
        tone(540, 1100, 0.18, 'sine', 0.11, 0.05);
        break;
      case 'ultimateCast':
        tone(220, 880, 0.35, 'sawtooth', 0.18);
        tone(440, 1320, 0.35, 'triangle', 0.15, 0.07);
        break;
      case 'bossWarning':
        tone(540, 420, 0.22, 'sawtooth', 0.16, 0);
        tone(540, 420, 0.22, 'sawtooth', 0.16, 0.26);
        break;
      case 'checkpoint':
        tone(440, 554.37, 0.18, 'triangle', 0.13, 0);
        tone(554.37, 659.25, 0.2, 'triangle', 0.14, 0.12);
        tone(659.25, 880, 0.28, 'sine', 0.15, 0.24);
        break;
      case 'coin':
        tone(987.77, 1318.5, 0.11, 'sine', 0.1);
        break;
      case 'secretChest':
        [523.25, 659.25, 783.99, 1046.5].forEach((n, i) =>
          tone(n, n * 1.02, 0.2, 'triangle', 0.14, i * 0.09)
        );
        break;
      case 'victory':
        [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((n, i) =>
          tone(n, n * 1.01, 0.28, 'triangle', 0.16, i * 0.11)
        );
        break;
      case 'defeat':
        [392, 349.23, 311.13, 261.63].forEach((n, i) =>
          tone(n, n * 0.96, 0.26, 'sawtooth', 0.13, i * 0.14)
        );
        break;
      case 'heroUnlock':
        [440, 554.37, 659.25, 880, 1108.73, 1318.5].forEach((n, i) =>
          tone(n, n * 1.03, 0.25, 'triangle', 0.16, i * 0.08)
        );
        break;
      case 'potion':
        tone(420, 760, 0.2, 'sine', 0.14);
        tone(620, 960, 0.18, 'triangle', 0.11, 0.08);
        break;
      case 'uiClick':
        tone(660, 820, 0.06, 'sine', 0.08);
        break;
    }
  }
}

export const soundEngine = new SoundEngine();
