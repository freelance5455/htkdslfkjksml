/**
 * SPR - Sahil Powerful Run
 * 3D Obstacle System with Object Pooling & Precise Collision Detection
 * Directly matching the SPR Coastal Railway Reference World:
 * - Commuter Subway Train (Streamlined Silver/Blue with headlights & red stripe)
 * - Red & White Diagonal Striped Road Barricade
 * - Wooden Cargo Crates with X-Bracing
 * - Yellow & Black Chevron Booster Jump Ramp (onto train roofs!)
 * - Overhead Railway Signal Gantry (requires slide)
 * - Plus legacy obstacles for backwards compatibility
 */

import * as THREE from 'three';
import { GAME_CONFIG, ObstacleType } from '../constants';
import { textureGenerator } from '../utils/TextureGenerator';
import { Train3DBuilder, TrainColorVariant } from '../models/Train3DBuilder';
import { FireRock3DBuilder } from '../models/FireRock3DBuilder';
import { soundManager } from '../audio/SoundManager';

export interface ObstacleInstance {
  type: ObstacleType;
  group: THREE.Group;
  lane: number; // 0 (left), 1 (mid), 2 (right) or -1 for multi-lane
  laneX: number;
  z: number;
  width: number;
  height: number;
  depth: number;
  needsJump: boolean;
  needsSlide: boolean;
  isRolling?: boolean;
  rollSpeed?: number;
  isPendulum?: boolean;
  pendulumAngle?: number;
  isRamp?: boolean;
  isTrain?: boolean;
  trainVariant?: TrainColorVariant;
  isMovingTrain?: boolean;
  trainSpeed?: number;
  hasHonked?: boolean;
  isFireRock?: boolean;
  active: boolean;
  bbox: THREE.Box3;
}

export class ObstacleManager {
  private scene: THREE.Scene;
  private obstacles: ObstacleInstance[] = [];
  private pool: Map<string, THREE.Group[]> = new Map();
  private elapsedTime: number = 0;

  // Shared Geometries & Materials
  private trainBodyMaterial!: THREE.MeshStandardMaterial;
  private trainFrontMaterial!: THREE.MeshStandardMaterial;
  private trainRoofMaterial!: THREE.MeshStandardMaterial;
  private trainHeadlightMaterial!: THREE.MeshBasicMaterial;
  private barricadeStripeMaterial!: THREE.MeshStandardMaterial;
  private barricadeCapMaterial!: THREE.MeshStandardMaterial;
  private barricadeSteelMaterial!: THREE.MeshStandardMaterial;
  private woodCrateMaterial!: THREE.MeshStandardMaterial;
  private chevronRampMaterial!: THREE.MeshStandardMaterial;
  private signalGantryMaterial!: THREE.MeshStandardMaterial;
  private signalLightMaterial!: THREE.MeshBasicMaterial;

  // Legacy Materials
  private fireMaterial!: THREE.MeshBasicMaterial;
  private rockMaterial!: THREE.MeshStandardMaterial;
  private woodMaterial!: THREE.MeshStandardMaterial;
  private spikeMaterial!: THREE.MeshStandardMaterial;
  private dangerBladeMaterial!: THREE.MeshStandardMaterial;
  private redAccentMaterial!: THREE.MeshBasicMaterial;

  // Cached Geometries
  private trainBodyGeo!: THREE.BufferGeometry;
  private trainFrontGeo!: THREE.BufferGeometry;
  private trainRoofGeo!: THREE.BufferGeometry;
  private trainWheelGeo!: THREE.BufferGeometry;
  private barricadeBoardGeo!: THREE.BufferGeometry;
  private barricadeCapGeo!: THREE.BufferGeometry;
  private barricadeLegGeo!: THREE.BufferGeometry;
  private crateSingleGeo!: THREE.BufferGeometry;
  private rampSlopeGeo!: THREE.BufferGeometry;
  private gantryPostGeo!: THREE.BufferGeometry;
  private gantryBarGeo!: THREE.BufferGeometry;
  private gantryLightGeo!: THREE.BufferGeometry;

  // Legacy Geometries
  private pitGeo!: THREE.BufferGeometry;
  private flameGeos: THREE.BufferGeometry[] = [];
  private logGeo!: THREE.BufferGeometry;
  private rockGeo!: THREE.BufferGeometry;
  private boulderGeo!: THREE.BufferGeometry;
  private crackGeo!: THREE.BufferGeometry;
  private spikeBaseGeo!: THREE.BufferGeometry;
  private spikeGeo!: THREE.BufferGeometry;
  private postGeo!: THREE.BufferGeometry;
  private signGeo!: THREE.BufferGeometry;
  private scaffoldGeo!: THREE.BufferGeometry;
  private bladeGeo!: THREE.BufferGeometry;

  private static tempBoxCenter = new THREE.Vector3();
  private static tempBoxSize = new THREE.Vector3();

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.initMaterials();
    this.initGeometries();
    this.prewarmPool();
  }

  private initMaterials() {
    // 1. Train Materials
    this.trainFrontMaterial = new THREE.MeshStandardMaterial({
      map: textureGenerator.getTrainFrontTexture(),
      roughness: 0.3,
      metalness: 0.7,
    });

    this.trainBodyMaterial = new THREE.MeshStandardMaterial({
      map: textureGenerator.getTrainSideTexture(),
      roughness: 0.35,
      metalness: 0.75,
    });

    this.trainRoofMaterial = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.6,
      metalness: 0.5,
    });

    this.trainHeadlightMaterial = new THREE.MeshBasicMaterial({
      color: 0xfef08a,
    });

    // 2. Barricade Materials
    this.barricadeStripeMaterial = new THREE.MeshStandardMaterial({
      map: textureGenerator.getBarricadeTexture(),
      roughness: 0.5,
      metalness: 0.1,
    });

    this.barricadeCapMaterial = new THREE.MeshStandardMaterial({
      color: 0xdc2626,
      roughness: 0.4,
      metalness: 0.3,
    });

    this.barricadeSteelMaterial = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.6,
      metalness: 0.8,
    });

    // 3. Wooden Crate & Chevron Ramp
    this.woodCrateMaterial = new THREE.MeshStandardMaterial({
      map: textureGenerator.getWoodCrateTexture(),
      roughness: 0.8,
      metalness: 0.1,
    });

    this.chevronRampMaterial = new THREE.MeshStandardMaterial({
      map: textureGenerator.getChevronRampTexture(),
      roughness: 0.4,
      metalness: 0.2,
    });

    // 4. Overhead Signal Gantry
    this.signalGantryMaterial = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.5,
      metalness: 0.7,
    });

    this.signalLightMaterial = new THREE.MeshBasicMaterial({
      color: 0xef4444,
    });

    // 5. Legacy materials
    this.fireMaterial = new THREE.MeshBasicMaterial({ color: 0xff4500 });
    this.rockMaterial = new THREE.MeshStandardMaterial({ color: 0x3f3f46, roughness: 0.9, metalness: 0.2 });
    this.woodMaterial = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.85 });
    this.spikeMaterial = new THREE.MeshStandardMaterial({ color: 0x71717a, roughness: 0.4, metalness: 0.8 });
    this.dangerBladeMaterial = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.3, metalness: 0.9 });
    this.redAccentMaterial = new THREE.MeshBasicMaterial({ color: 0xdc2626 });
  }

  private initGeometries() {
    // 1. Commuter Subway Train (Width: 2.6m, Height: 3.5m, Depth: 16m)
    this.trainBodyGeo = new THREE.BoxGeometry(2.6, 3.2, 15.5);
    this.trainFrontGeo = new THREE.PlaneGeometry(2.6, 3.2);
    this.trainRoofGeo = new THREE.CylinderGeometry(1.4, 1.4, 15.5, 12, 1, false, 0, Math.PI);
    this.trainRoofGeo.rotateZ(-Math.PI / 2);
    this.trainRoofGeo.scale(0.9, 0.35, 1.0);
    this.trainWheelGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.3, 12);
    this.trainWheelGeo.rotateZ(Math.PI / 2);

    // 2. Barricade
    this.barricadeBoardGeo = new THREE.BoxGeometry(2.4, 0.95, 0.16);
    this.barricadeCapGeo = new THREE.BoxGeometry(0.35, 0.45, 0.26);
    this.barricadeLegGeo = new THREE.BoxGeometry(0.12, 1.4, 0.12);

    // 3. Wooden Crate & Ramp
    this.crateSingleGeo = new THREE.BoxGeometry(1.5, 1.4, 1.5);
    
    // Wedge ramp
    const rampWedge = new THREE.BufferGeometry();
    const rw = 1.6 / 2;
    const rh = 1.35;
    const rd = 3.2;
    // prettier-ignore
    const vertices = new Float32Array([
      // Back face
      -rw, 0, 0,    rw, 0, 0,    rw, rh, 0,
      -rw, 0, 0,    rw, rh, 0,  -rw, rh, 0,
      // Ramp slope face
      -rw, rh, 0,   rw, rh, 0,   rw, 0.05, rd,
      -rw, rh, 0,   rw, 0.05, rd, -rw, 0.05, rd,
      // Left triangular face
      -rw, 0, 0,   -rw, rh, 0,  -rw, 0.05, rd,
      // Right triangular face
       rw, 0, 0,    rw, 0.05, rd,  rw, rh, 0,
      // Bottom face
      -rw, 0, 0,   -rw, 0, rd,   rw, 0, rd,
      -rw, 0, 0,    rw, 0, rd,   rw, 0, 0,
    ]);
    rampWedge.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
    rampWedge.computeVertexNormals();
    this.rampSlopeGeo = rampWedge;

    // 4. Overhead Signal Gantry
    this.gantryPostGeo = new THREE.CylinderGeometry(0.12, 0.12, 4.2, 8);
    this.gantryBarGeo = new THREE.BoxGeometry(3.2, 0.4, 0.3);
    this.gantryLightGeo = new THREE.SphereGeometry(0.2, 8, 8);

    // 5. Legacy geometries
    this.pitGeo = new THREE.TorusGeometry(1.2, 0.25, 6, 8);
    this.pitGeo.rotateX(Math.PI / 2);
    for (let i = 0; i < 3; i++) {
      this.flameGeos.push(new THREE.ConeGeometry(0.5 - i * 0.1, 1.6 + i * 0.2, 6));
    }
    this.logGeo = new THREE.CylinderGeometry(0.55, 0.65, 2.8, 8);
    this.logGeo.rotateZ(Math.PI / 2);
    this.rockGeo = new THREE.DodecahedronGeometry(1.3, 0);
    this.boulderGeo = new THREE.SphereGeometry(1.45, 12, 12);
    this.crackGeo = new THREE.BoxGeometry(0.8, 0.1, 0.1);
    this.spikeBaseGeo = new THREE.BoxGeometry(2.4, 0.12, 2.2);
    this.spikeGeo = new THREE.ConeGeometry(0.16, 1.2, 5);
    this.spikeGeo.translate(0, 0.6, 0);
    this.postGeo = new THREE.BoxGeometry(2.8, 0.4, 0.4);
    this.signGeo = new THREE.BoxGeometry(1.2, 0.8, 0.1);
    this.scaffoldGeo = new THREE.CylinderGeometry(0.12, 0.12, 7.5, 6);
    this.bladeGeo = new THREE.BoxGeometry(2.4, 1.2, 0.3);
  }

  private prewarmPool() {
    // 1. High-Quality 3D Train Variants (Red, Yellow, Blue)
    const trainVariants: TrainColorVariant[] = ['red', 'yellow', 'blue'];
    for (const v of trainVariants) {
      const list: THREE.Group[] = [];
      for (let i = 0; i < 2; i++) {
        const grp = Train3DBuilder.createTrain(v);
        grp.visible = false;
        this.scene.add(grp);
        list.push(grp);
      }
      this.pool.set(`train_${v}`, list);
    }

    // 2. 3D Fire Rock Obstacles with animated magma and fire
    const fireRockList: THREE.Group[] = [];
    for (let i = 0; i < 3; i++) {
      const grp = FireRock3DBuilder.createFireRock();
      grp.visible = false;
      this.scene.add(grp);
      fireRockList.push(grp);
    }
    this.pool.set('fireRock', fireRockList);

    const standardTypes: ObstacleType[] = [
      'barricade',
      'woodenCrates',
      'jumpRamp',
      'overheadSignal',
      'fire',
      'tree',
      'rock',
      'rollingBoulder',
      'spikeTrap',
      'brokenBridge',
      'dangerZone',
    ];

    for (const t of standardTypes) {
      const list: THREE.Group[] = [];
      const count = t === 'barricade' || t === 'woodenCrates' ? 5 : 3;
      for (let i = 0; i < count; i++) {
        const grp = this.createObstacleMesh(t);
        grp.visible = false;
        this.scene.add(grp);
        list.push(grp);
      }
      this.pool.set(t, list);
    }
  }

  private getMeshFromPool(type: ObstacleType, trainVariant?: TrainColorVariant): THREE.Group {
    const key = type === 'train' ? `train_${trainVariant || 'red'}` : type;
    const list = this.pool.get(key);
    if (list && list.length > 0) {
      const grp = list.pop()!;
      grp.visible = true;
      return grp;
    }
    const grp = this.createObstacleMesh(type, trainVariant);
    this.scene.add(grp);
    return grp;
  }

  private createObstacleMesh(type: ObstacleType, trainVariant?: TrainColorVariant): THREE.Group {
    if (type === 'train') {
      return Train3DBuilder.createTrain(trainVariant || 'red');
    }
    if (type === 'fireRock') {
      return FireRock3DBuilder.createFireRock();
    }

    const group = new THREE.Group();

    switch (type) {

      case 'barricade': {
        // Construction Barricade with Red/White Stripes & Heavy Red Corner Caps
        const board = new THREE.Mesh(this.barricadeBoardGeo, this.barricadeStripeMaterial);
        board.position.set(0, 0.85, 0);
        board.castShadow = true;
        group.add(board);

        // 4 Corner Hazard Caps with circular reflectors (matching reference image)
        const capPositions: [number, number][] = [
          [-1.15, 1.22],
          [1.15, 1.22],
          [-1.15, 0.48],
          [1.15, 0.48],
        ];
        for (const [cx, cy] of capPositions) {
          const cap = new THREE.Mesh(this.barricadeCapGeo, this.barricadeCapMaterial);
          cap.position.set(cx, cy, 0);
          group.add(cap);

          const studGeo = new THREE.CylinderGeometry(0.1, 0.1, 0.14, 8);
          studGeo.rotateX(Math.PI / 2);
          const stud = new THREE.Mesh(studGeo, this.barricadeCapMaterial);
          stud.position.set(cx, cy, 0.08);
          group.add(stud);
        }

        // Left & Right Steel Legs & Cross Feet
        const leftLeg = new THREE.Mesh(this.barricadeLegGeo, this.barricadeSteelMaterial);
        leftLeg.position.set(-0.95, 0.7, 0);
        leftLeg.castShadow = true;
        group.add(leftLeg);

        const rightLeg = new THREE.Mesh(this.barricadeLegGeo, this.barricadeSteelMaterial);
        rightLeg.position.set(0.95, 0.7, 0);
        rightLeg.castShadow = true;
        group.add(rightLeg);

        const footGeo = new THREE.BoxGeometry(0.2, 0.12, 1.2);
        const leftFoot = new THREE.Mesh(footGeo, this.barricadeSteelMaterial);
        leftFoot.position.set(-0.95, 0.06, 0);
        group.add(leftFoot);

        const rightFoot = new THREE.Mesh(footGeo, this.barricadeSteelMaterial);
        rightFoot.position.set(0.95, 0.06, 0);
        group.add(rightFoot);
        break;
      }

      case 'woodenCrates': {
        // Stacked Wooden Cargo Crates
        const crate1 = new THREE.Mesh(this.crateSingleGeo, this.woodCrateMaterial);
        crate1.position.set(0, 0.7, 0);
        crate1.castShadow = true;
        group.add(crate1);

        // 2nd Crate stacked on top or slightly askew
        const crate2 = new THREE.Mesh(this.crateSingleGeo, this.woodCrateMaterial);
        crate2.position.set(0.04, 2.1, 0.02);
        crate2.rotation.y = 0.08;
        crate2.castShadow = true;
        group.add(crate2);
        break;
      }

      case 'jumpRamp': {
        // Wooden Crate Base with Bright Yellow & Black Chevron Ramp on Top
        const crateBase = new THREE.Mesh(this.crateSingleGeo, this.woodCrateMaterial);
        crateBase.position.set(0, 0.7, -0.6);
        crateBase.castShadow = true;
        group.add(crateBase);

        const slope = new THREE.Mesh(this.rampSlopeGeo, this.chevronRampMaterial);
        slope.position.set(0, 0.02, 1.0);
        slope.castShadow = true;
        group.add(slope);
        break;
      }

      case 'overheadSignal': {
        // Railway Overhead Signal Gantry (requires slide under)
        const leftPost = new THREE.Mesh(this.gantryPostGeo, this.signalGantryMaterial);
        leftPost.position.set(-1.45, 2.1, 0);
        leftPost.castShadow = true;
        group.add(leftPost);

        const rightPost = new THREE.Mesh(this.gantryPostGeo, this.signalGantryMaterial);
        rightPost.position.set(1.45, 2.1, 0);
        rightPost.castShadow = true;
        group.add(rightPost);

        const bar = new THREE.Mesh(this.gantryBarGeo, this.signalGantryMaterial);
        bar.position.set(0, 3.4, 0);
        bar.castShadow = true;
        group.add(bar);

        // Dual Red Warning Lights
        const lightL = new THREE.Mesh(this.gantryLightGeo, this.signalLightMaterial);
        lightL.position.set(-0.6, 3.4, 0.18);
        group.add(lightL);

        const lightR = new THREE.Mesh(this.gantryLightGeo, this.signalLightMaterial);
        lightR.position.set(0.6, 3.4, 0.18);
        group.add(lightR);

        // Lower hazard barrier at clearance 1.35m
        const lowBar = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.25, 0.15), this.barricadeStripeMaterial);
        lowBar.position.set(0, 1.9, 0);
        group.add(lowBar);
        break;
      }

      case 'fire': {
        const pitMesh = new THREE.Mesh(this.pitGeo, this.rockMaterial);
        pitMesh.position.y = 0.15;
        group.add(pitMesh);
        for (let i = 0; i < 3; i++) {
          const cone = new THREE.Mesh(this.flameGeos[i], this.fireMaterial);
          cone.position.set((Math.random() - 0.5) * 0.4, 0.8, (Math.random() - 0.5) * 0.4);
          cone.name = `flame_${i}`;
          group.add(cone);
        }
        break;
      }

      case 'tree': {
        const log = new THREE.Mesh(this.logGeo, this.woodMaterial);
        log.castShadow = true;
        log.name = 'log_mesh';
        group.add(log);
        break;
      }

      case 'rock': {
        const rock = new THREE.Mesh(this.rockGeo, this.rockMaterial);
        rock.scale.set(1.1, 1.4, 1.0);
        rock.position.y = 1.3;
        rock.castShadow = true;
        group.add(rock);
        break;
      }

      case 'rollingBoulder': {
        const boulder = new THREE.Mesh(this.boulderGeo, this.rockMaterial);
        boulder.position.y = 1.45;
        boulder.castShadow = true;
        boulder.name = 'sphere_mesh';
        group.add(boulder);

        const crack = new THREE.Mesh(this.crackGeo, this.redAccentMaterial);
        crack.position.set(0, 1.5, 1.4);
        group.add(crack);
        break;
      }

      case 'spikeTrap': {
        const base = new THREE.Mesh(this.spikeBaseGeo, this.woodMaterial);
        base.position.y = 0.06;
        group.add(base);
        for (let x = -0.8; x <= 0.8; x += 0.8) {
          for (let z = -0.7; z <= 0.7; z += 0.7) {
            const spike = new THREE.Mesh(this.spikeGeo, this.spikeMaterial);
            spike.position.set(x, 0.06, z);
            spike.castShadow = true;
            group.add(spike);
          }
        }
        break;
      }

      case 'brokenBridge': {
        const post = new THREE.Mesh(this.postGeo, this.woodMaterial);
        post.position.y = 1.0;
        post.castShadow = true;
        group.add(post);

        const sign = new THREE.Mesh(this.signGeo, this.redAccentMaterial);
        sign.position.set(0, 1.5, 0);
        group.add(sign);
        break;
      }

      case 'dangerZone': {
        const pendulumArm = new THREE.Mesh(this.scaffoldGeo, this.woodMaterial);
        pendulumArm.position.y = 4.2;
        pendulumArm.name = 'pendulum_arm';
        group.add(pendulumArm);

        const blade = new THREE.Mesh(this.bladeGeo, this.dangerBladeMaterial);
        blade.position.y = 1.2;
        blade.castShadow = true;
        blade.name = 'danger_blade';
        group.add(blade);
        break;
      }
    }

    return group;
  }

  // --- SPAWN OBSTACLES FOR A TRACK SECTION ---
  public spawnObstacle(
    type: ObstacleType,
    laneIndex: number,
    z: number,
    options?: { trainVariant?: TrainColorVariant; isMovingTrain?: boolean; trainSpeed?: number }
  ) {
    const laneX = GAME_CONFIG.LANES[laneIndex];
    let trainVariant: TrainColorVariant | undefined;
    if (type === 'train') {
      const variants: TrainColorVariant[] = ['red', 'yellow', 'blue'];
      trainVariant = options?.trainVariant || variants[Math.floor(Math.random() * variants.length)];
    }

    const group = this.getMeshFromPool(type, trainVariant);

    let width = 2.4;
    let height = 1.8;
    let depth = 2.4;
    let needsJump = false;
    let needsSlide = false;
    let isRolling = false;
    let rollSpeed = 0;
    let isPendulum = false;
    let isRamp = false;
    let isTrain = false;
    let isFireRock = false;
    let isMovingTrain = false;
    let trainSpeed = 0;

    group.position.set(laneX, 0, z);

    switch (type) {
      case 'train':
        isTrain = true;
        width = 2.44;
        height = 3.65;
        depth = 15.6;
        isMovingTrain = options?.isMovingTrain ?? (Math.random() < 0.35);
        trainSpeed = options?.trainSpeed || (8 + Math.random() * 4);
        break;

      case 'fireRock':
        isFireRock = true;
        width = 2.4;
        height = 2.4;
        depth = 2.4;
        break;

      case 'barricade':
        needsJump = true;
        width = 2.4;
        height = 1.35;
        depth = 0.8;
        break;

      case 'woodenCrates':
        width = 1.6;
        height = 2.8;
        depth = 1.6;
        break;

      case 'jumpRamp':
        isRamp = true;
        width = 1.8;
        height = 1.4;
        depth = 3.2;
        break;

      case 'overheadSignal':
        needsSlide = true;
        width = 2.8;
        height = 3.4;
        depth = 1.0;
        break;

      case 'fire':
        needsJump = true;
        height = 1.6;
        break;

      case 'tree': {
        const isSlideLog = Math.random() < 0.45;
        const logMesh = group.getObjectByName('log_mesh');
        if (isSlideLog) {
          needsSlide = true;
          if (logMesh) logMesh.position.y = 1.85;
          height = 2.2;
        } else {
          needsJump = true;
          if (logMesh) logMesh.position.y = 0.55;
          height = 1.2;
        }
        break;
      }

      case 'rock':
        width = 2.2;
        height = 2.2;
        break;

      case 'rollingBoulder':
        isRolling = true;
        rollSpeed = 8 + Math.random() * 4;
        width = 2.8;
        height = 2.8;
        break;

      case 'spikeTrap':
        needsJump = true;
        height = 1.4;
        break;

      case 'brokenBridge':
        needsJump = true;
        height = 1.8;
        break;

      case 'dangerZone':
        isPendulum = true;
        height = 3.0;
        break;
    }

    const bbox = new THREE.Box3();
    ObstacleManager.tempBoxCenter.set(laneX, height / 2, z);
    ObstacleManager.tempBoxSize.set(width * 0.78, height * 0.85, depth * 0.7);
    bbox.setFromCenterAndSize(ObstacleManager.tempBoxCenter, ObstacleManager.tempBoxSize);

    const instance: ObstacleInstance = {
      type,
      group,
      lane: laneIndex,
      laneX,
      z,
      width,
      height,
      depth,
      needsJump,
      needsSlide,
      isRolling,
      rollSpeed,
      isPendulum,
      pendulumAngle: 0,
      isRamp,
      isTrain,
      trainVariant,
      isMovingTrain,
      trainSpeed,
      hasHonked: false,
      isFireRock,
      active: true,
      bbox,
    };

    this.obstacles.push(instance);
  }

  // --- UPDATE ANIMATIONS & RECYCLE ---
  public update(delta: number, playerZ: number) {
    this.elapsedTime += delta;
    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      const obs = this.obstacles[i];
      if (!obs.active) {
        this.removeObstacleAt(i);
        continue;
      }

      let needsBBoxUpdate = false;

      // Real-time Moving Train animation along railway track
      if (obs.isTrain && obs.isMovingTrain && obs.trainSpeed) {
        obs.z += obs.trainSpeed * delta; // Moves towards runner (+Z)
        obs.group.position.z = obs.z;
        needsBBoxUpdate = true;

        // Honk horn when approaching runner
        if (!obs.hasHonked && obs.z > playerZ - 50 && obs.z < playerZ - 10) {
          obs.hasHonked = true;
          soundManager.playTrainHornSound();
        }
      }

      // Real-time 3D Fire Rock flame, embers, and smoke animation
      if (obs.isFireRock) {
        FireRock3DBuilder.animateFireRock(obs.group, delta, this.elapsedTime);
      }

      // Rolling boulder animation
      if (obs.isRolling && obs.rollSpeed) {
        obs.z += obs.rollSpeed * delta;
        obs.group.position.z = obs.z;
        const sphere = obs.group.getObjectByName('sphere_mesh');
        if (sphere) {
          sphere.rotation.x += obs.rollSpeed * delta * 0.8;
        }
        needsBBoxUpdate = true;
      }

      // Pendulum swinging animation
      if (obs.isPendulum) {
        obs.pendulumAngle = (obs.pendulumAngle || 0) + delta * 3.5;
        const swing = Math.sin(obs.pendulumAngle) * 0.8;
        const arm = obs.group.getObjectByName('pendulum_arm');
        const blade = obs.group.getObjectByName('danger_blade');
        if (arm) arm.rotation.z = swing;
        if (blade) blade.position.x = Math.sin(swing) * 3;
        needsBBoxUpdate = true;
      }

      // Fire flicker
      if (obs.type === 'fire') {
        const flame0 = obs.group.getObjectByName('flame_0');
        if (flame0) {
          flame0.scale.y = 0.85 + Math.random() * 0.3;
          flame0.rotation.y += delta * 5;
        }
      }

      // Update Bounding Box only if obstacle moves
      if (needsBBoxUpdate) {
        ObstacleManager.tempBoxCenter.set(obs.group.position.x, obs.height / 2, obs.z);
        ObstacleManager.tempBoxSize.set(obs.width * 0.75, obs.height * 0.85, obs.depth * 0.65);
        obs.bbox.setFromCenterAndSize(ObstacleManager.tempBoxCenter, ObstacleManager.tempBoxSize);
      }

      // Despawn if far behind player
      if (obs.z > playerZ + (obs.isTrain ? 30 : 25)) {
        this.removeObstacleAt(i);
      }
    }
  }

  public removeObstacle(obs: ObstacleInstance) {
    const idx = this.obstacles.indexOf(obs);
    if (idx !== -1) {
      this.removeObstacleAt(idx);
    }
  }

  private removeObstacleAt(index: number) {
    const obs = this.obstacles[index];
    obs.group.visible = false;

    const poolKey = obs.type === 'train' ? `train_${obs.trainVariant || 'red'}` : obs.type;
    if (!this.pool.has(poolKey)) {
      this.pool.set(poolKey, []);
    }
    this.pool.get(poolKey)!.push(obs.group);

    this.obstacles.splice(index, 1);
  }

  /**
   * Safely despawn any obstacles between minZ and maxZ (used for revive and flight landing clearing)
   */
  public clearNearZ(minZ: number, maxZ: number, laneIndex?: number) {
    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      const obs = this.obstacles[i];
      if (obs.z >= minZ && obs.z <= maxZ) {
        if (laneIndex === undefined || obs.lane === laneIndex) {
          this.removeObstacleAt(i);
        }
      }
    }
  }

  /**
   * Finds a completely safe landing lane at targetZ with no trains or obstacles
   */
  public findSafeLandingLane(targetZ: number): number {
    const laneBlocked = [false, false, false];
    for (const obs of this.obstacles) {
      if (!obs.active) continue;
      const halfDepth = (obs.depth || 2.4) / 2 + 12;
      if (Math.abs(obs.z - targetZ) < halfDepth) {
        if (obs.lane >= 0 && obs.lane <= 2) {
          laneBlocked[obs.lane] = true;
        }
      }
    }
    const priority = [1, 0, 2];
    for (const l of priority) {
      if (!laneBlocked[l]) return l;
    }
    this.clearNearZ(targetZ - 18, targetZ + 18, 1);
    return 1;
  }

  // --- COLLISION CHECK WITH PLAYER ---
  public checkPlayerCollision(
    playerBox: THREE.Box3,
    isJumping: boolean,
    isSliding: boolean,
    playerY: number
  ): ObstacleInstance | null {
    for (const obs of this.obstacles) {
      if (!obs.active) continue;

      // Special Train Handling: If player is running on top of train roof (y >= 3.2), no collision!
      if (obs.isTrain && playerY >= 3.2) {
        continue;
      }

      if (obs.bbox.intersectsBox(playerBox)) {
        // Special: Fire Rock Boost Launch!
        if (obs.isFireRock) {
          return obs; // Handled by GameEngine to launch into 30-40s air sequence!
        }

        // Jump ramp contact
        if (obs.isRamp) {
          return obs; // Handled by GameEngine as boost ramp!
        }

        // Jump over jumpable obstacle (barricade, low log, spike trap, broken bridge)
        if (obs.needsJump && isJumping && playerY > 1.15) {
          continue; // Cleared!
        }

        // Slide under overhead obstacle (overheadSignal, high log)
        if (obs.needsSlide && isSliding && playerY < 0.8) {
          continue; // Cleared!
        }

        return obs; // Hit!
      }
    }
    return null;
  }

  public clearAll() {
    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      this.removeObstacleAt(i);
    }
    this.obstacles = [];
  }

  public destroy() {
    this.clearAll();

    // Dispose all pooled groups and meshes
    this.pool.forEach((list) => {
      list.forEach((grp) => {
        this.scene.remove(grp);
      });
    });
    this.pool.clear();

    // Dispose shared geometries
    this.trainBodyGeo?.dispose();
    this.trainFrontGeo?.dispose();
    this.trainRoofGeo?.dispose();
    this.trainWheelGeo?.dispose();
    this.barricadeBoardGeo?.dispose();
    this.barricadeCapGeo?.dispose();
    this.barricadeLegGeo?.dispose();
    this.crateSingleGeo?.dispose();
    this.rampSlopeGeo?.dispose();
    this.gantryPostGeo?.dispose();
    this.gantryBarGeo?.dispose();
    this.gantryLightGeo?.dispose();

    this.pitGeo?.dispose();
    this.flameGeos.forEach((g) => g.dispose());
    this.logGeo?.dispose();
    this.rockGeo?.dispose();
    this.boulderGeo?.dispose();
    this.crackGeo?.dispose();
    this.spikeBaseGeo?.dispose();
    this.spikeGeo?.dispose();
    this.postGeo?.dispose();
    this.signGeo?.dispose();
    this.scaffoldGeo?.dispose();
    this.bladeGeo?.dispose();

    // Dispose shared materials
    this.trainBodyMaterial?.dispose();
    this.trainFrontMaterial?.dispose();
    this.trainRoofMaterial?.dispose();
    this.trainHeadlightMaterial?.dispose();
    this.barricadeStripeMaterial?.dispose();
    this.barricadeCapMaterial?.dispose();
    this.barricadeSteelMaterial?.dispose();
    this.woodCrateMaterial?.dispose();
    this.chevronRampMaterial?.dispose();
    this.signalGantryMaterial?.dispose();
    this.signalLightMaterial?.dispose();

    this.fireMaterial?.dispose();
    this.rockMaterial?.dispose();
    this.woodMaterial?.dispose();
    this.spikeMaterial?.dispose();
    this.dangerBladeMaterial?.dispose();
    this.redAccentMaterial?.dispose();
  }
}
