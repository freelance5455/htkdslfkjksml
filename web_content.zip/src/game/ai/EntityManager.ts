import * as THREE from 'three';
import { BOSSES } from '../config/bosses';
import { CREATURES } from '../config/creatures';
import { ENEMIES, ENEMY_MAP } from '../config/enemies';
import { NPCS } from '../config/questsAndNpcs';
import { REGIONS } from '../config/regions';
import { animateHumanoid, buildHumanoidRig, HumanoidRig } from '../models/CharacterModels';
import { animateCreatureModel, buildCreatureModel } from '../models/CreatureModels';
import { animateEnemyModel, buildEnemyModel } from '../models/EnemyModels';
import { animateBossModel, buildBossModel } from '../models/BossModels';
import { BossDef, CreatureDef, EnemyDef, NpcDef } from '../types/gameTypes';
import { getTerrainHeight, WATER_LEVEL } from '../world/TerrainMath';

export interface HpBarHandle {
  group: THREE.Group;
  fill: THREE.Mesh;
  width: number;
}

const _hpBarBgGeo = new THREE.PlaneGeometry(1, 0.14);
const _hpBarFillGeo = new THREE.PlaneGeometry(0.94, 0.09);
const _hpBarBgMat = new THREE.MeshBasicMaterial({
  color: '#090d16',
  transparent: true,
  opacity: 0.85,
  depthTest: true,
  side: THREE.DoubleSide,
});

function createHpBar(width: number, heightOffset: number, fillColor: string): HpBarHandle {
  const group = new THREE.Group();
  group.position.y = heightOffset;
  group.scale.set(width, 1, 1);

  const bg = new THREE.Mesh(_hpBarBgGeo, _hpBarBgMat);
  group.add(bg);

  const fillMat = new THREE.MeshBasicMaterial({
    color: fillColor,
    depthTest: true,
    side: THREE.DoubleSide,
  });
  const fill = new THREE.Mesh(_hpBarFillGeo, fillMat);
  fill.position.z = 0.01;
  group.add(fill);

  return { group, fill, width };
}

function updateHpBar(bar: HpBarHandle, hp: number, maxHp: number, camQuat: THREE.Quaternion, visible: boolean) {
  bar.group.visible = visible;
  if (!visible) return;
  const ratio = Math.max(0.001, Math.min(1, hp / Math.max(1, maxHp)));
  bar.fill.scale.x = ratio;
  bar.fill.position.x = -(1 - ratio) * 0.47;
  bar.group.quaternion.copy(camQuat);
}

export interface ActiveCreature {
  uid: string;
  def: CreatureDef;
  mesh: THREE.Group;
  hpBar: HpBarHandle;
  x: number;
  y: number;
  z: number;
  homeX: number;
  homeZ: number;
  yaw: number;
  targetX: number;
  targetZ: number;
  wanderTimer: number;
  fleeTimer: number;
  tamed: boolean;
  hp: number;
  maxHp: number;
  dead: boolean;
  respawnTimer: number;
  hitFlash: number;
}

export interface ActiveEnemy {
  uid: string;
  def: EnemyDef;
  mesh: THREE.Group;
  hpBar: HpBarHandle;
  x: number;
  y: number;
  z: number;
  homeX: number;
  homeZ: number;
  yaw: number;
  hp: number;
  maxHp: number;
  cooldown: number;
  slowTimer: number;
  poisonTimer: number;
  burrowTimer: number;
  hitFlash: number;
  respawnTimer: number;
  dead: boolean;
  isTurret?: boolean;
  turretLife?: number;
  floorOverrideY?: number;
}

export interface ActiveBoss {
  def: BossDef;
  mesh: THREE.Group;
  hp: number;
  maxHp: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  phase: 1 | 2 | 3;
  cooldown: number;
  specialTimer: number;
  summonedPhase2: boolean;
  summonedPhase3: boolean;
  defeated: boolean;
  locked: boolean;
  hitFlash: number;
  barrierMesh?: THREE.Mesh;
}

export interface ActiveNpc {
  def: NpcDef;
  rig: HumanoidRig;
  x: number;
  y: number;
  z: number;
  yaw: number;
  targetX: number;
  targetZ: number;
  waitTimer: number;
}

export class EntityManager {
  private scene: THREE.Scene;
  public creatures: ActiveCreature[] = [];
  public enemies: ActiveEnemy[] = [];
  public bosses: ActiveBoss[] = [];
  public npcs: ActiveNpc[] = [];

  constructor(scene: THREE.Scene, defeatedBossIds: string[], tamedCompanion: boolean, tamedMount: boolean, contactShadowTex?: THREE.Texture) {
    this.scene = scene;
    this.spawnAllCreatures(tamedCompanion, tamedMount);
    this.spawnAll40Enemies(contactShadowTex);
    this.spawnLandmarkAndCryptGuards(contactShadowTex);
    this.spawnAll8Bosses(defeatedBossIds);
    this.spawnAllNpcs();
  }

  private spawnAllCreatures(tamedCompanion: boolean, tamedMount: boolean) {
    CREATURES.forEach((def, cIdx) => {
      const reg = REGIONS[def.region];
      const count = def.id === 'moon_horse' || def.id === 'small_dragon' || def.id === 'royal_stag' ? 2 : 3;
      for (let i = 0; i < count; i++) {
        const angle = (cIdx * 1.4 + i * 2.1) % (Math.PI * 2);
        const dist = def.id === 'moon_horse' ? 38 + i * 24 : def.id === 'royal_stag' ? 68 + i * 25 : 42 + i * 38;
        let x = reg.centerX + Math.cos(angle) * dist;
        let z = reg.centerZ + Math.sin(angle) * dist;
        if (def.id === 'river_otter') {
          x = -85 + i * 18;
          z = 22 + i * 26;
        }
        const y = Math.max(WATER_LEVEL + 0.1, getTerrainHeight(x, z));
        const mesh = buildCreatureModel(def);
        mesh.position.set(x, y, z);
        this.scene.add(mesh);

        const hpBar = createHpBar(1.25, 2.35 * def.scale, '#34d399');
        hpBar.group.position.set(x, y + 2.35 * def.scale, z);
        this.scene.add(hpBar.group);

        this.creatures.push({
          uid: `cr_${def.id}_${i}`,
          def,
          mesh,
          hpBar,
          x,
          y,
          z,
          homeX: x,
          homeZ: z,
          yaw: angle,
          targetX: x,
          targetZ: z,
          wanderTimer: Math.random() * 3,
          fleeTimer: 0,
          tamed: (def.id === 'small_dragon' && tamedCompanion && i === 0) || (def.id === 'moon_horse' && tamedMount && i === 0),
          hp: def.hp,
          maxHp: def.hp,
          dead: false,
          respawnTimer: 0,
          hitFlash: 0,
        });
      }
    });
  }

  private attachContactShadow(mesh: THREE.Group, scale: number, contactShadowTex?: THREE.Texture) {
    if (!contactShadowTex) return;
    const shadow = new THREE.Mesh(
      new THREE.PlaneGeometry(1.8 * scale, 1.8 * scale),
      new THREE.MeshBasicMaterial({ map: contactShadowTex, transparent: true, opacity: 0.72, depthWrite: false })
    );
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.04;
    mesh.add(shadow);
  }

  private spawnSpecificEnemy(
    uid: string,
    def: EnemyDef,
    x: number,
    z: number,
    floorOverrideY?: number,
    contactShadowTex?: THREE.Texture
  ) {
    const y = floorOverrideY !== undefined ? floorOverrideY : Math.max(WATER_LEVEL + 0.1, getTerrainHeight(x, z));
    const mesh = buildEnemyModel(def);
    mesh.position.set(x, y, z);
    this.attachContactShadow(mesh, 1.0, contactShadowTex);
    this.scene.add(mesh);

    const barH = (def.flies ? 3.9 : 2.55) * def.scale;
    const hpBar = createHpBar(1.35 * Math.min(1.5, Math.max(0.95, def.scale)), barH, '#ef4444');
    hpBar.group.position.set(x, y + barH, z);
    this.scene.add(hpBar.group);

    this.enemies.push({
      uid,
      def,
      mesh,
      hpBar,
      x,
      y,
      z,
      homeX: x,
      homeZ: z,
      yaw: 0,
      hp: def.hp,
      maxHp: def.hp,
      cooldown: Math.random() * 1.2,
      slowTimer: 0,
      poisonTimer: 0,
      burrowTimer: 0,
      hitFlash: 0,
      respawnTimer: 0,
      dead: false,
      floorOverrideY,
    });
  }

  private spawnAll40Enemies(contactShadowTex?: THREE.Texture) {
    ENEMIES.forEach((def, idx) => {
      const reg = REGIONS[def.region];
      const count = 2;
      for (let copy = 0; copy < count; copy++) {
        const angle = (idx * 0.85 + copy * Math.PI) % (Math.PI * 2);
        const minR = def.region === 'green_forest' ? 78 : 30;
        const dist = minR + ((idx * 17 + copy * 43) % (reg.radius - minR - 25));
        const x = reg.centerX + Math.cos(angle) * dist;
        const z = reg.centerZ + Math.sin(angle) * dist;
        this.spawnSpecificEnemy(`en_${def.id}_${copy}`, def, x, z, undefined, contactShadowTex);
      }
    });
  }

  private spawnLandmarkAndCryptGuards(contactShadowTex?: THREE.Texture) {
    const placements: Array<{ enemyId: string; x: number; z: number; floorY?: number }> = [
      // Castle & Ruin Surface Garrisons
      { enemyId: 'skeleton_warrior', x: 346, z: 292 },
      { enemyId: 'skeleton_necromancer', x: 353, z: 288 },
      { enemyId: 'heavy_goblin_guard', x: 331, z: -42 },
      { enemyId: 'goblin_shaman', x: 339, z: -50 },
      { enemyId: 'frost_archmage', x: -35, z: -472 },
      { enemyId: 'ice_troll', x: -31, z: -460 },
      { enemyId: 'hell_demon_knight', x: 340, z: -352 },
      { enemyId: 'hell_warlock', x: 335, z: -340 },
      { enemyId: 'desert_mummy_mage', x: -490, z: 23 },
      { enemyId: 'desert_scorpion', x: -484, z: 36 },
      { enemyId: 'ruins_guardian', x: -95, z: 452 },
      { enemyId: 'skeleton_warrior', x: 255, z: 272 },
      { enemyId: 'desert_mummy_mage', x: -425, z: -58 },
      // Crypt 1: Cursed Bone Catacombs (1200, 0)
      { enemyId: 'skeleton_warrior', x: 1195, z: 10, floorY: 0 },
      { enemyId: 'skeleton_warrior', x: 1205, z: 4, floorY: 0 },
      { enemyId: 'bone_archer', x: 1194, z: -8, floorY: 0 },
      { enemyId: 'skeleton_necromancer', x: 1200, z: -17, floorY: 0 },
      // Crypt 2: Pharaoh Sun Crypt (1480, 0)
      { enemyId: 'desert_scorpion', x: 1475, z: 11, floorY: 0 },
      { enemyId: 'desert_scorpion', x: 1485, z: 2, floorY: 0 },
      { enemyId: 'desert_mummy_mage', x: 1474, z: -9, floorY: 0 },
      { enemyId: 'desert_mummy_mage', x: 1480, z: -17, floorY: 0 },
      // Crypt 3: Hellfire Abyss Vault (1760, 0)
      { enemyId: 'hell_demon_knight', x: 1755, z: 10, floorY: 0 },
      { enemyId: 'hell_demon_knight', x: 1765, z: 1, floorY: 0 },
      { enemyId: 'hell_warlock', x: 1754, z: -9, floorY: 0 },
      { enemyId: 'hell_warlock', x: 1760, z: -17, floorY: 0 },
    ];
    placements.forEach((p, idx) => {
      const def = ENEMY_MAP[p.enemyId];
      if (!def) return;
      this.spawnSpecificEnemy(`guard_${p.enemyId}_${idx}`, def, p.x, p.z, p.floorY, contactShadowTex);
    });
  }

  public spawnSummonedEnemy(enemyId: string, x: number, z: number) {
    const def = ENEMY_MAP[enemyId];
    if (!def) return;
    const y = Math.max(WATER_LEVEL + 0.1, getTerrainHeight(x, z));
    const mesh = buildEnemyModel(def);
    mesh.position.set(x, y, z);
    this.scene.add(mesh);

    const barH = (def.flies ? 3.9 : 2.55) * def.scale;
    const hpBar = createHpBar(1.3, barH, '#ef4444');
    hpBar.group.position.set(x, y + barH, z);
    this.scene.add(hpBar.group);

    this.enemies.push({
      uid: `sum_${enemyId}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      def,
      mesh,
      hpBar,
      x,
      y,
      z,
      homeX: x,
      homeZ: z,
      yaw: 0,
      hp: Math.round(def.hp * 0.75),
      maxHp: Math.round(def.hp * 0.75),
      cooldown: 0.8,
      slowTimer: 0,
      poisonTimer: 0,
      burrowTimer: 0,
      hitFlash: 0,
      respawnTimer: -1,
      dead: false,
    });
  }

  public spawnGoblinTurret(x: number, z: number) {
    const def = ENEMY_MAP.goblin_engineer;
    const y = Math.max(WATER_LEVEL + 0.1, getTerrainHeight(x, z));
    const g = new THREE.Group();
    const base = new THREE.Mesh(
      new THREE.CylinderGeometry(0.45, 0.65, 0.9, 8),
      new THREE.MeshStandardMaterial({ color: '#52525b', metalness: 0.7, roughness: 0.3 })
    );
    base.position.y = 0.45;
    g.add(base);
    const barrel = new THREE.Mesh(
      new THREE.CylinderGeometry(0.12, 0.14, 1.0, 6),
      new THREE.MeshStandardMaterial({ color: '#ef4444', emissive: '#991b1b', emissiveIntensity: 0.4 })
    );
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.85, 0.45);
    g.add(barrel);
    g.position.set(x, y, z);
    this.scene.add(g);

    const hpBar = createHpBar(1.15, 1.65, '#ef4444');
    hpBar.group.position.set(x, y + 1.65, z);
    this.scene.add(hpBar.group);

    this.enemies.push({
      uid: `turret_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      def: { ...def, name: 'Goblin Turret', ranged: true, speed: 0, attackRange: 15, damage: 12 },
      mesh: g,
      hpBar,
      x,
      y,
      z,
      homeX: x,
      homeZ: z,
      yaw: 0,
      hp: 55,
      maxHp: 55,
      cooldown: 1.0,
      slowTimer: 0,
      poisonTimer: 0,
      burrowTimer: 0,
      hitFlash: 0,
      respawnTimer: -1,
      dead: false,
      isTurret: true,
      turretLife: 18,
    });
  }

  private spawnAll8Bosses(defeatedBossIds: string[]) {
    for (const def of BOSSES) {
      const defeated = defeatedBossIds.includes(def.id);
      const locked = Boolean(def.requiresPreviousBosses && defeatedBossIds.length < def.requiresPreviousBosses);
      const y = getTerrainHeight(def.arenaX, def.arenaZ);
      const mesh = buildBossModel(def);
      mesh.position.set(def.arenaX, y, def.arenaZ);
      mesh.visible = !defeated;
      this.scene.add(mesh);

      let barrierMesh: THREE.Mesh | undefined;
      if (def.requiresPreviousBosses) {
        barrierMesh = new THREE.Mesh(
          new THREE.CylinderGeometry(def.arenaRadius - 1, def.arenaRadius - 1, 14, 24, 1, true),
          new THREE.MeshBasicMaterial({
            color: '#e11d48',
            transparent: true,
            opacity: 0.25,
            side: THREE.DoubleSide,
          })
        );
        barrierMesh.position.set(def.arenaX, y + 7, def.arenaZ);
        barrierMesh.visible = locked;
        this.scene.add(barrierMesh);
      }

      this.bosses.push({
        def,
        mesh,
        hp: defeated ? 0 : def.hp,
        maxHp: def.hp,
        x: def.arenaX,
        y,
        z: def.arenaZ,
        yaw: Math.PI,
        phase: 1,
        cooldown: 1.2,
        specialTimer: 4,
        summonedPhase2: false,
        summonedPhase3: false,
        defeated,
        locked,
        hitFlash: 0,
        barrierMesh,
      });
    }
  }

  public refreshBossLocks(defeatedBossIds: string[]) {
    for (const b of this.bosses) {
      if (b.def.requiresPreviousBosses) {
        b.locked = defeatedBossIds.length < b.def.requiresPreviousBosses;
        if (b.barrierMesh) {
          b.barrierMesh.visible = b.locked;
        }
      }
    }
  }

  private spawnAllNpcs() {
    for (const def of NPCS) {
      const y = getTerrainHeight(def.homeX, def.homeZ);
      const rig = buildHumanoidRig(
        {
          name: def.name,
          hairStyle: def.role === 'Wizard' ? 'hooded' : def.role === 'QuestGiver' ? 'long' : 'short',
          hairColor: def.hairColor,
          skinColor: '#f1c27d',
          faceStyle: 'calm',
          tunicColor: def.robeColor,
          armorColor: def.role === 'Guard' ? '#94a3b8' : def.robeColor,
          accessory: def.role === 'Wizard' ? 'cape' : 'none',
        },
        def.role === 'Wizard' ? 'Staff' : def.role === 'Guard' ? 'Sword' : 'Dagger',
        def.role === 'Wizard' ? '#a855f7' : '#cbd5e1',
        def.role === 'Guard'
      );
      rig.group.position.set(def.homeX, y, def.homeZ);
      this.scene.add(rig.group);
      this.npcs.push({
        def,
        rig,
        x: def.homeX,
        y,
        z: def.homeZ,
        yaw: 0,
        targetX: def.homeX,
        targetZ: def.homeZ,
        waitTimer: Math.random() * 4,
      });
    }
  }

  public updateAll(
    dt: number,
    time: number,
    playerPos: THREE.Vector3,
    camQuat: THREE.Quaternion,
    isMounted: boolean,
    callbacks: {
      onPlayerHit: (dmg: number, source: string, flags?: { slow?: boolean; poison?: boolean }) => void;
      onEnemyProjectile: (origin: THREE.Vector3, dir: THREE.Vector3, dmg: number, colorElement: 'fire' | 'ice' | 'water' | 'lightning') => void;
      onCompanionAttack: (enemy: ActiveEnemy | ActiveBoss, dmg: number) => void;
      onBossSpecial: (boss: ActiveBoss, type: 'summon' | 'nova') => void;
      onOtterGift: (itemId: string) => void;
    }
  ) {
    // 1. Update NPCs
    for (const npc of this.npcs) {
      const distP = Math.hypot(npc.x - playerPos.x, npc.z - playerPos.z);
      npc.rig.group.visible = distP < 130;
      if (!npc.rig.group.visible) continue;

      if (distP < 5.5) {
        npc.yaw = Math.atan2(playerPos.x - npc.x, playerPos.z - npc.z);
        npc.rig.group.rotation.y = npc.yaw;
        animateHumanoid(npc.rig, time, 0, false, 0, false, false);
        continue;
      }

      npc.waitTimer -= dt;
      const dx = npc.targetX - npc.x;
      const dz = npc.targetZ - npc.z;
      const distT = Math.hypot(dx, dz);
      if (distT > 0.6) {
        const spd = 2.0 * dt;
        npc.x += (dx / distT) * spd;
        npc.z += (dz / distT) * spd;
        npc.y = getTerrainHeight(npc.x, npc.z);
        npc.yaw = Math.atan2(dx, dz);
        npc.rig.group.position.set(npc.x, npc.y, npc.z);
        npc.rig.group.rotation.y = npc.yaw;
        animateHumanoid(npc.rig, time, 0.5, false, 0, false, false);
      } else {
        animateHumanoid(npc.rig, time, 0, false, 0, false, false);
        if (npc.waitTimer <= 0) {
          const a = Math.random() * Math.PI * 2;
          const r = Math.random() * npc.def.patrolRadius;
          npc.targetX = npc.def.homeX + Math.cos(a) * r;
          npc.targetZ = npc.def.homeZ + Math.sin(a) * r;
          npc.waitTimer = 3 + Math.random() * 5;
        }
      }
    }

    // 2. Update 10 Peaceful Creatures (with HP, regen, respawn & 3D HP bars)
    for (const cr of this.creatures) {
      if (cr.dead) {
        cr.hpBar.group.visible = false;
        cr.respawnTimer -= dt;
        if (cr.respawnTimer <= 0) {
          cr.dead = false;
          cr.hp = cr.maxHp;
          cr.x = cr.homeX;
          cr.z = cr.homeZ;
          cr.y = Math.max(WATER_LEVEL + 0.1, getTerrainHeight(cr.x, cr.z));
          cr.mesh.position.set(cr.x, cr.y, cr.z);
          cr.mesh.visible = true;
        }
        continue;
      }

      if (cr.def.id === 'moon_horse' && cr.tamed && isMounted) {
        cr.mesh.visible = false;
        cr.hpBar.group.visible = false;
        continue;
      }

      const distP = Math.hypot(cr.x - playerPos.x, cr.z - playerPos.z);
      cr.mesh.visible = distP < 170 || cr.tamed;
      if (!cr.mesh.visible) {
        cr.hpBar.group.visible = false;
        continue;
      }

      if (cr.hitFlash > 0) {
        cr.hitFlash -= dt;
        const pulse = 1 + cr.hitFlash * 0.5;
        cr.mesh.scale.setScalar(cr.def.scale * pulse);
      } else {
        cr.mesh.scale.setScalar(cr.def.scale);
      }

      // Passive HP recovery when peaceful & calm
      if (cr.fleeTimer <= 0 && cr.hp < cr.maxHp) {
        cr.hp = Math.min(cr.maxHp, cr.hp + 3.5 * dt);
      }

      if (cr.def.id === 'small_dragon' && cr.tamed) {
        const followX = playerPos.x - 2.1;
        const followZ = playerPos.z - 2.1;
        const dx = followX - cr.x;
        const dz = followZ - cr.z;
        const distF = Math.hypot(dx, dz);
        if (distF > 1.2) {
          const spd = Math.min(distF * 3, 13) * dt;
          cr.x += (dx / distF) * spd;
          cr.z += (dz / distF) * spd;
          cr.yaw = Math.atan2(dx, dz);
        }
        cr.y = playerPos.y + 2.2 + Math.sin(time * 3) * 0.25;
        cr.mesh.position.set(cr.x, cr.y, cr.z);
        cr.mesh.rotation.y = cr.yaw;
        animateCreatureModel(cr.mesh, cr.def, time, true);

        cr.hpBar.group.position.set(cr.x, cr.y + 1.85 * cr.def.scale, cr.z);
        updateHpBar(cr.hpBar, cr.hp, cr.maxHp, camQuat, distP < 24);

        cr.wanderTimer -= dt;
        if (cr.wanderTimer <= 0) {
          const target = this.enemies.find((e) => !e.dead && Math.hypot(e.x - cr.x, e.z - cr.z) < 18);
          if (target) {
            callbacks.onCompanionAttack(target, 18);
            cr.wanderTimer = 2.2;
          } else {
            cr.wanderTimer = 0.6;
          }
        }
        continue;
      }

      if (cr.def.id === 'giant_eagle') {
        const orbitAngle = time * 0.32;
        cr.x = cr.homeX + Math.cos(orbitAngle) * 42;
        cr.z = cr.homeZ + Math.sin(orbitAngle) * 42;
        cr.y = getTerrainHeight(cr.x, cr.z) + 28;
        cr.yaw = -orbitAngle;
        cr.mesh.position.set(cr.x, cr.y, cr.z);
        cr.mesh.rotation.y = cr.yaw;
        animateCreatureModel(cr.mesh, cr.def, time, true);
        cr.hpBar.group.position.set(cr.x, cr.y + 2.2 * cr.def.scale, cr.z);
        updateHpBar(cr.hpBar, cr.hp, cr.maxHp, camQuat, distP < 42 || cr.hp < cr.maxHp);
        continue;
      }

      if (cr.def.id === 'royal_stag' && distP < 16 && distP > 5) {
        cr.targetX = cr.homeX - 24;
        cr.targetZ = cr.homeZ + 20;
      }

      if (cr.fleeTimer > 0) {
        cr.fleeTimer -= dt;
        const fx = cr.x - playerPos.x;
        const fz = cr.z - playerPos.z;
        const fd = Math.hypot(fx, fz) || 1;
        cr.x += (fx / fd) * cr.def.speed * 1.4 * dt;
        cr.z += (fz / fd) * cr.def.speed * 1.4 * dt;
        cr.yaw = Math.atan2(fx, fz);
      } else {
        cr.wanderTimer -= dt;
        const dx = cr.targetX - cr.x;
        const dz = cr.targetZ - cr.z;
        const d = Math.hypot(dx, dz);
        if (d > 1.0) {
          const spd = cr.def.speed * 0.65 * dt;
          cr.x += (dx / d) * spd;
          cr.z += (dz / d) * spd;
          cr.yaw = Math.atan2(dx, dz);
        } else if (cr.wanderTimer <= 0) {
          const a = Math.random() * Math.PI * 2;
          const r = 6 + Math.random() * 18;
          cr.targetX = cr.homeX + Math.cos(a) * r;
          cr.targetZ = cr.homeZ + Math.sin(a) * r;
          cr.wanderTimer = 3 + Math.random() * 4;
          if (cr.def.id === 'river_otter' && distP < 12 && Math.random() < 0.35) {
            callbacks.onOtterGift('herbs');
          }
        }
      }
      cr.y = Math.max(WATER_LEVEL + 0.05, getTerrainHeight(cr.x, cr.z)) + (cr.def.flies ? 2.2 : 0);
      cr.mesh.position.set(cr.x, cr.y, cr.z);
      cr.mesh.rotation.y = cr.yaw;
      animateCreatureModel(cr.mesh, cr.def, time, true);

      cr.hpBar.group.position.set(cr.x, cr.y + 2.35 * cr.def.scale, cr.z);
      updateHpBar(cr.hpBar, cr.hp, cr.maxHp, camQuat, distP < 28 || cr.hp < cr.maxHp);
    }

    // 3. Update 40 Combat Enemies
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const en = this.enemies[i];
      if (en.dead) {
        en.hpBar.group.visible = false;
        if (en.respawnTimer < 0) {
          this.scene.remove(en.mesh);
          this.scene.remove(en.hpBar.group);
          this.enemies.splice(i, 1);
          continue;
        }
        en.respawnTimer -= dt;
        if (en.respawnTimer <= 0) {
          en.dead = false;
          en.hp = en.maxHp;
          en.x = en.homeX;
          en.z = en.homeZ;
          en.y = en.floorOverrideY !== undefined ? en.floorOverrideY : Math.max(WATER_LEVEL + 0.1, getTerrainHeight(en.x, en.z));
          en.mesh.position.set(en.x, en.y, en.z);
          en.mesh.rotation.z = 0;
          en.mesh.visible = true;
        }
        continue;
      }

      if (en.isTurret && en.turretLife !== undefined) {
        en.turretLife -= dt;
        if (en.turretLife <= 0) {
          en.dead = true;
          en.respawnTimer = -1;
          continue;
        }
      }

      const distP = Math.hypot(en.x - playerPos.x, en.z - playerPos.z);
      en.mesh.visible = distP < 135;
      if (!en.mesh.visible) {
        en.hpBar.group.visible = false;
        continue;
      }

      if (en.hitFlash > 0) {
        en.hitFlash -= dt;
        en.mesh.scale.setScalar(en.def.scale * (1 + en.hitFlash * 0.45));
      } else {
        en.mesh.scale.setScalar(en.def.scale);
      }

      if (en.slowTimer > 0) en.slowTimer -= dt;
      if (en.cooldown > 0) en.cooldown -= dt;

      const speedMult = en.slowTimer > 0 ? 0.5 : 1.0;
      let isMoving = false;
      let isAttacking = false;

      if (distP < en.def.detectionRange) {
        const dx = playerPos.x - en.x;
        const dz = playerPos.z - en.z;
        en.yaw = Math.atan2(dx, dz);

        if (en.def.burrows && distP > 5 && distP < 16 && en.floorOverrideY === undefined) {
          en.burrowTimer += dt;
          en.y = getTerrainHeight(en.x, en.z) - (Math.sin(en.burrowTimer * 4) > 0 ? 0.9 : 0);
        } else {
          en.y = en.floorOverrideY !== undefined ? en.floorOverrideY : Math.max(WATER_LEVEL + 0.1, getTerrainHeight(en.x, en.z));
        }

        if (en.def.teleports && distP > 8 && distP < 18 && en.cooldown <= 0.1 && Math.random() < 0.025) {
          const a = Math.random() * Math.PI * 2;
          en.x = playerPos.x + Math.cos(a) * 3.5;
          en.z = playerPos.z + Math.sin(a) * 3.5;
        }

        if (distP > en.def.attackRange && en.def.speed > 0) {
          const spd = en.def.speed * speedMult * dt;
          en.x += (dx / distP) * spd;
          en.z += (dz / distP) * spd;
          isMoving = true;
        } else if (en.cooldown <= 0) {
          isAttacking = true;
          en.cooldown = en.def.attackCooldown;

          if (en.def.healsAllies) {
            const ally = this.enemies.find((o) => !o.dead && o !== en && o.hp < o.maxHp && Math.hypot(o.x - en.x, o.z - en.z) < 16);
            if (ally) {
              ally.hp = Math.min(ally.maxHp, ally.hp + 25);
            }
          }
          if (en.def.buildsTurrets && this.enemies.filter((e) => e.isTurret).length < 4 && Math.random() < 0.4) {
            this.spawnGoblinTurret(en.x + 2, en.z + 2);
          }

          if (en.def.ranged) {
            const origin = new THREE.Vector3(en.x, en.y + 1.5, en.z);
            const dir = new THREE.Vector3(playerPos.x - en.x, playerPos.y + 1.1 - (en.y + 1.5), playerPos.z - en.z).normalize();
            const elem =
              en.def.region === 'volcano_region' || en.def.region === 'desert_dunes'
                ? 'fire'
                : en.def.region === 'frozen_kingdom' || en.def.group === 'iron_mountains'
                  ? 'ice'
                  : en.def.group === 'ghost_swamp'
                    ? 'water'
                    : 'lightning';
            callbacks.onEnemyProjectile(origin, dir, en.def.damage, elem);
          } else {
            callbacks.onPlayerHit(en.def.damage, en.def.name, {
              slow: en.def.slowsPlayer,
              poison: en.def.poisonsPlayer,
            });
          }
        }
      } else if (en.def.speed > 0 && (en.def.aiStyle === 'patrol' || en.def.aiStyle === 'pack')) {
        const patrolAngle = time * 0.4 + en.def.index;
        const tx = en.homeX + Math.cos(patrolAngle) * 7;
        const tz = en.homeZ + Math.sin(patrolAngle) * 7;
        const dx = tx - en.x;
        const dz = tz - en.z;
        const d = Math.hypot(dx, dz);
        if (d > 0.5) {
          en.x += (dx / d) * en.def.speed * 0.45 * dt;
          en.z += (dz / d) * en.def.speed * 0.45 * dt;
          en.yaw = Math.atan2(dx, dz);
          isMoving = true;
        }
        en.y = en.floorOverrideY !== undefined ? en.floorOverrideY : Math.max(WATER_LEVEL + 0.1, getTerrainHeight(en.x, en.z));
      }

      if (!en.def.burrows || en.floorOverrideY !== undefined) {
        en.y = en.floorOverrideY !== undefined ? en.floorOverrideY : Math.max(WATER_LEVEL + 0.1, getTerrainHeight(en.x, en.z));
      }
      const meshY = en.y + (en.def.flies ? 1.6 : 0);
      en.mesh.position.set(en.x, meshY, en.z);
      en.mesh.rotation.y = en.yaw;
      animateEnemyModel(en.mesh, en.def, time, isMoving, isAttacking || en.cooldown > en.def.attackCooldown * 0.72);

      const barH = (en.def.flies ? 2.8 : 2.55) * en.def.scale;
      en.hpBar.group.position.set(en.x, meshY + barH, en.z);
      updateHpBar(en.hpBar, en.hp, en.maxHp, camQuat, distP < 34 || en.hp < en.maxHp);
    }

    // 4. Update 8 Legendary Bosses
    for (const boss of this.bosses) {
      if (boss.defeated) continue;
      const distP = Math.hypot(boss.x - playerPos.x, boss.z - playerPos.z);
      boss.mesh.visible = distP < 220;
      if (!boss.mesh.visible) continue;

      if (boss.hitFlash > 0) {
        boss.hitFlash -= dt;
        boss.mesh.scale.setScalar(1 + boss.hitFlash * 0.25);
      } else {
        boss.mesh.scale.setScalar(1);
      }

      if (boss.locked) {
        boss.mesh.rotation.y = time * 0.4;
        animateBossModel(boss.mesh, time, false);
        continue;
      }

      const hpRatio = boss.hp / boss.maxHp;
      if (hpRatio < 0.65 && boss.phase < 2) {
        boss.phase = 2;
        if (!boss.summonedPhase2) {
          boss.summonedPhase2 = true;
          callbacks.onBossSpecial(boss, 'summon');
        }
      }
      if (hpRatio < 0.3 && boss.phase < 3) {
        boss.phase = 3;
        if (!boss.summonedPhase3) {
          boss.summonedPhase3 = true;
          callbacks.onBossSpecial(boss, 'summon');
        }
      }

      let bossAttacking = false;
      if (distP < boss.def.arenaRadius + 6) {
        const dx = playerPos.x - boss.x;
        const dz = playerPos.z - boss.z;
        boss.yaw = Math.atan2(dx, dz);
        if (boss.cooldown > 0) boss.cooldown -= dt;
        boss.specialTimer -= dt;

        const moveSpd = boss.def.speed * (boss.phase === 3 ? 1.25 : 1.0);
        if (distP > 4.8) {
          boss.x += (dx / distP) * moveSpd * dt;
          boss.z += (dz / distP) * moveSpd * dt;
        } else if (boss.cooldown <= 0) {
          bossAttacking = true;
          boss.cooldown = boss.phase === 3 ? 1.15 : 1.55;
          callbacks.onPlayerHit(boss.def.damage * (boss.phase === 3 ? 1.25 : 1), boss.def.name);
        }

        if (boss.specialTimer <= 0) {
          bossAttacking = true;
          boss.specialTimer = boss.phase === 3 ? 3.2 : 4.6;
          callbacks.onBossSpecial(boss, 'nova');
          const origin = new THREE.Vector3(boss.x, boss.y + 3.2, boss.z);
          const dir = new THREE.Vector3(playerPos.x - boss.x, playerPos.y + 1 - origin.y, playerPos.z - boss.z).normalize();
          const elem = boss.def.id.includes('red')
            ? 'fire'
            : boss.def.id.includes('ice')
              ? 'ice'
              : boss.def.id.includes('ghost')
                ? 'water'
                : 'lightning';
          callbacks.onEnemyProjectile(origin, dir, boss.def.damage * 1.15, elem);
        }
      } else {
        const dx = boss.def.arenaX - boss.x;
        const dz = boss.def.arenaZ - boss.z;
        const d = Math.hypot(dx, dz);
        if (d > 1.5) {
          boss.x += (dx / d) * boss.def.speed * dt;
          boss.z += (dz / d) * boss.def.speed * dt;
          boss.yaw = Math.atan2(dx, dz);
        }
      }

      boss.y = getTerrainHeight(boss.x, boss.z);
      boss.mesh.position.set(boss.x, boss.y, boss.z);
      boss.mesh.rotation.y = boss.yaw;
      animateBossModel(boss.mesh, time, bossAttacking || boss.cooldown > 1.15);
    }
  }
}
