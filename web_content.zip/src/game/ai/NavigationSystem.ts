import * as THREE from 'three';
import { CollisionSystem } from '../physics/CollisionSystem';

export interface NavNode {
  id: number;
  pos: THREE.Vector3;
  neighbors: number[];
}

export class NavigationSystem {
  private collision: CollisionSystem;
  private nodes: NavNode[] = [];

  // Pre-allocated arrays for A* to eliminate GC allocations
  private gScoreArr = new Float32Array(80);
  private fScoreArr = new Float32Array(80);
  private cameFromArr = new Int16Array(80);
  private inOpenSet = new Uint8Array(80);
  private openSet: number[] = [];

  // Temporary vectors to avoid garbage collection
  private tempFrom = new THREE.Vector3();
  private tempTo = new THREE.Vector3();

  constructor(collision: CollisionSystem) {
    this.collision = collision;
    this.generateNavGraph();
  }

  private generateNavGraph() {
    this.nodes = [];
    let id = 0;

    const addNode = (x: number, y: number, z: number): number => {
      const nodeId = id++;
      this.nodes.push({
        id: nodeId,
        pos: new THREE.Vector3(x, y, z),
        neighbors: [],
      });
      return nodeId;
    };

    // Central crossroad and plaza nodes
    addNode(0, 0, 0);       // 0: Center
    addNode(0, 0, -4);      // 1: North center
    addNode(0, 0, 4);       // 2: South center
    addNode(-4, 0, 0);      // 3: West center
    addNode(4, 0, 0);       // 4: East center

    // Main road nodes (West - East)
    addNode(-14, 0, 0);     // 5
    addNode(-26, 0, 0);     // 6
    addNode(-38, 0, 0);     // 7
    addNode(-46, 0, 0);     // 8: Far west road spawn

    addNode(14, 0, 0);      // 9
    addNode(26, 0, 0);      // 10
    addNode(38, 0, 0);      // 11
    addNode(46, 0, 0);      // 12: Far east road spawn

    // Cross road nodes (North - South)
    addNode(0, 0, -14);     // 13
    addNode(0, 0, -26);     // 14
    addNode(0, 0, -38);     // 15
    addNode(0, 0, -46);     // 16: North spawn

    addNode(0, 0, 14);      // 17
    addNode(0, 0, 26);      // 18
    addNode(0, 0, 38);      // 19
    addNode(0, 0, 46);      // 20: South spawn

    // House A (North-West) navigation
    addNode(-28, 0, -14);   // 21: House A front yard
    addNode(-28, 0.2, -18); // 22: House A front doorway
    addNode(-28, 0.2, -22); // 23: House A front room
    addNode(-26, 0.2, -27); // 24: House A room divider passage
    addNode(-28, 0.2, -31); // 25: House A back doorway
    addNode(-28, 0, -35);   // 26: House A backyard
    addNode(-18, 0, -25);   // 27: House A east alley

    // Command Building (North-East) navigation
    addNode(25, 0, -12);    // 28: Command front yard
    addNode(25, 0.1, -15);  // 29: Command front entrance
    addNode(25, 0.1, -22);  // 30: Command 1st floor interior
    addNode(32, 0.1, -25);  // 31: Command stair base
    addNode(32, 3.6, -18);  // 32: Command 2nd floor stair top
    addNode(25, 3.6, -20);  // 33: Command 2nd floor room
    addNode(25, 3.6, -12);  // 34: Command Balcony
    addNode(16, 0, -22);    // 35: Command west side alley

    // Warehouse (South-West) navigation
    addNode(-26, 0, 11);    // 36: Warehouse front approach
    addNode(-26, 0.1, 13.5);// 37: Warehouse roll-up door entrance
    addNode(-26, 0.1, 20);  // 38: Warehouse interior main bay
    addNode(-20, 0.1, 25);  // 39: Warehouse interior side
    addNode(-15, 0, 24);    // 40: Warehouse east exit door
    addNode(-15, 0, 14);    // 41: Warehouse east alley

    // House B (South-East) navigation
    addNode(26, 0, 12);     // 42: House B front approach
    addNode(26, 0.1, 17.5); // 43: House B front entrance
    addNode(26, 0.1, 24);   // 44: House B interior
    addNode(26, 0.1, 31.5); // 45: House B back entrance
    addNode(26, 0, 36);     // 46: House B backyard / mystery box
    addNode(17, 0, 24);     // 47: House B west alley

    // Preconnect nodes within unobstructed line of sight
    for (let i = 0; i < this.nodes.length; i++) {
      for (let j = i + 1; j < this.nodes.length; j++) {
        const nA = this.nodes[i];
        const nB = this.nodes[j];
        const dist = nA.pos.distanceTo(nB.pos);

        if (dist <= 18) {
          this.tempFrom.copy(nA.pos).add({ x: 0, y: 1.0, z: 0 });
          this.tempTo.copy(nB.pos).add({ x: 0, y: 1.0, z: 0 });

          if (!this.collision.isObstructed(this.tempFrom, this.tempTo)) {
            nA.neighbors.push(nB.id);
            nB.neighbors.push(nA.id);
          }
        }
      }
    }
  }

  // Fast nearest node calculation
  getNearestNode(pos: THREE.Vector3): number {
    let bestId = 0;
    let minDistSq = Infinity;

    for (let i = 0; i < this.nodes.length; i++) {
      const dSq = this.nodes[i].pos.distanceToSquared(pos);
      if (dSq < minDistSq) {
        minDistSq = dSq;
        bestId = i;
      }
    }
    return bestId;
  }

  // High-performance GC-free A* pathfinding
  findPath(startPos: THREE.Vector3, goalPos: THREE.Vector3): THREE.Vector3[] {
    const directDistSq = startPos.distanceToSquared(goalPos);

    // Fast Path 1: If player is within 18m and line of sight is clear, steer straight
    if (directDistSq < 324) { // 18m squared
      this.tempFrom.copy(startPos).add({ x: 0, y: 1.0, z: 0 });
      this.tempTo.copy(goalPos).add({ x: 0, y: 1.0, z: 0 });
      if (!this.collision.isObstructed(this.tempFrom, this.tempTo)) {
        return [goalPos.clone()];
      }
    }

    const startNode = this.getNearestNode(startPos);
    const goalNode = this.getNearestNode(goalPos);

    if (startNode === goalNode) {
      return [goalPos.clone()];
    }

    const nodeCount = this.nodes.length;
    for (let i = 0; i < nodeCount; i++) {
      this.gScoreArr[i] = 1e8;
      this.fScoreArr[i] = 1e8;
      this.cameFromArr[i] = -1;
      this.inOpenSet[i] = 0;
    }

    this.openSet.length = 0;
    this.openSet.push(startNode);
    this.inOpenSet[startNode] = 1;
    this.gScoreArr[startNode] = 0;
    this.fScoreArr[startNode] = this.nodes[startNode].pos.distanceTo(this.nodes[goalNode].pos);

    let iterations = 0;
    const maxIterations = 35; // Cap iterations to prevent any frame hang

    while (this.openSet.length > 0 && iterations++ < maxIterations) {
      let current = this.openSet[0];
      let lowestF = this.fScoreArr[current];
      let currentIdx = 0;

      for (let i = 1; i < this.openSet.length; i++) {
        const id = this.openSet[i];
        const score = this.fScoreArr[id];
        if (score < lowestF) {
          lowestF = score;
          current = id;
          currentIdx = i;
        }
      }

      if (current === goalNode) {
        const path: THREE.Vector3[] = [goalPos.clone()];
        let currId = current;
        while (this.cameFromArr[currId] !== -1) {
          path.unshift(this.nodes[currId].pos.clone());
          currId = this.cameFromArr[currId];
        }
        return path;
      }

      this.openSet.splice(currentIdx, 1);
      this.inOpenSet[current] = 0;
      const currNode = this.nodes[current];

      for (let n = 0; n < currNode.neighbors.length; n++) {
        const neighborId = currNode.neighbors[n];
        const neighbor = this.nodes[neighborId];
        const tentativeG = this.gScoreArr[current] + currNode.pos.distanceTo(neighbor.pos);

        if (tentativeG < this.gScoreArr[neighborId]) {
          this.cameFromArr[neighborId] = current;
          this.gScoreArr[neighborId] = tentativeG;
          const f = tentativeG + neighbor.pos.distanceTo(this.nodes[goalNode].pos);
          this.fScoreArr[neighborId] = f;

          if (this.inOpenSet[neighborId] === 0) {
            this.openSet.push(neighborId);
            this.inOpenSet[neighborId] = 1;
          }
        }
      }
    }

    return [goalPos.clone()];
  }
}
