import * as THREE from 'three';
import { createMoto160, createOnFootPlayer, type MotoRig, type OnFootPlayerRig } from './motoModel';
import { groundNormalAt } from './world';
import type {
  BikeCustomization,
  BikeModelType,
  FriendInfo,
  RemoteMapMarker,
  RemotePlayerState,
  RoomInfo,
  RoomMemberInfo,
} from './types';

export interface PlayerIdentity {
  playerId: string;
  name: string;
  bikeModel: BikeModelType;
}

export async function registerPlayerProfile(
  identity: Partial<PlayerIdentity>
): Promise<{ player: { id: string; name: string; bikeModel: BikeModelType }; friends: FriendInfo[] }> {
  const res = await fetch('/api/social/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(identity),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Erro ao registrar perfil.');
  return data;
}

export async function updateServerProfile(identity: PlayerIdentity): Promise<void> {
  const res = await fetch('/api/social/profile', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(identity),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || 'Erro ao atualizar perfil.');
  }
}

export async function fetchFriends(playerId: string): Promise<FriendInfo[]> {
  const res = await fetch(`/api/social/friends?playerId=${encodeURIComponent(playerId)}`);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Erro ao carregar amigos.');
  return data.friends ?? [];
}

export async function addFriendById(
  playerId: string,
  friendId: string
): Promise<{ added: { id: string; name: string; bikeModel: BikeModelType }; friends: FriendInfo[] }> {
  const res = await fetch('/api/social/friends/add', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ playerId, friendId }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Não foi possível adicionar este amigo.');
  return data;
}

export async function removeFriendById(playerId: string, friendId: string): Promise<FriendInfo[]> {
  const res = await fetch('/api/social/friends/remove', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ playerId, friendId }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Erro ao remover amigo.');
  return data.friends ?? [];
}

export interface MultiplayerEvents {
  onConnectionChange?: (connected: boolean) => void;
  onFriendsUpdated?: (friends: FriendInfo[], notice?: string) => void;
  onRoomJoined?: (room: RoomInfo, remoteStates: RemotePlayerState[], doorOpen: boolean) => void;
  onRoomUpdated?: (room: RoomInfo, eventNotice?: string) => void;
  onRoomLeft?: () => void;
  onRoomError?: (message: string) => void;
  onRemoteState?: (state: RemotePlayerState) => void;
  onRemoteLeft?: (playerId: string) => void;
  onDoorSync?: (open: boolean) => void;
}

export class MultiplayerClient {
  private ws: WebSocket | null = null;
  private identity: PlayerIdentity | null = null;
  private reconnectTimer: number | null = null;
  private intentionalClose = false;
  private events: MultiplayerEvents;
  private currentRoomId: string | null = null;

  constructor(events: MultiplayerEvents) {
    this.events = events;
  }

  setEvents(events: MultiplayerEvents) {
    this.events = events;
  }

  connect(identity: PlayerIdentity) {
    this.identity = identity;
    this.intentionalClose = false;
    this.openSocket();
  }

  updateIdentity(identity: PlayerIdentity) {
    this.identity = identity;
    this.send({
      type: 'profile:update',
      name: identity.name,
      bikeModel: identity.bikeModel,
    });
  }

  isConnected(): boolean {
    return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }

  createRoom() {
    this.send({ type: 'room:create' });
  }

  joinRoom(roomId: string) {
    this.send({ type: 'room:join', roomId });
  }

  leaveRoom() {
    this.currentRoomId = null;
    this.send({ type: 'room:leave' });
  }

  sendPlayerState(state: Omit<RemotePlayerState, 'playerId' | 'name' | 'updatedAt'>) {
    if (!this.currentRoomId) return;
    this.send({ type: 'player:state', state });
  }

  sendDoorState(open: boolean) {
    if (!this.currentRoomId) return;
    this.send({ type: 'world:door', open });
  }

  disconnect() {
    this.intentionalClose = true;
    if (this.reconnectTimer !== null) {
      window.clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.ws?.close();
    this.ws = null;
  }

  private openSocket() {
    if (!this.identity) return;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = `${proto}//${window.location.host}/ws`;
    const ws = new WebSocket(url);
    this.ws = ws;

    ws.onopen = () => {
      this.events.onConnectionChange?.(true);
      if (this.identity) {
        this.send({
          type: 'auth',
          playerId: this.identity.playerId,
          name: this.identity.name,
          bikeModel: this.identity.bikeModel,
        });
      }
      if (this.currentRoomId) {
        this.send({ type: 'room:join', roomId: this.currentRoomId });
      }
    };

    ws.onmessage = (ev) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(String(ev.data)) as Record<string, unknown>;
      } catch {
        return;
      }

      const type = String(msg.type ?? '');
      if (type === 'auth:ok') {
        if (Array.isArray(msg.friends)) {
          this.events.onFriendsUpdated?.(msg.friends as FriendInfo[]);
        }
        return;
      }

      if (type === 'friends:updated') {
        this.events.onFriendsUpdated?.((msg.friends as FriendInfo[]) ?? []);
        return;
      }

      if (type === 'friends:added_you') {
        const byName = String(msg.byName ?? 'Um piloto');
        this.events.onFriendsUpdated?.(
          (msg.friends as FriendInfo[]) ?? [],
          `${byName} adicionou você aos amigos!`
        );
        return;
      }

      if (type === 'room:joined') {
        const room = msg.room as RoomInfo;
        this.currentRoomId = room.roomId;
        this.events.onRoomJoined?.(
          room,
          (msg.remoteStates as RemotePlayerState[]) ?? [],
          Boolean(msg.doorOpen)
        );
        return;
      }

      if (type === 'room:player_joined') {
        const room = msg.room as RoomInfo;
        const p = msg.player as RoomMemberInfo | undefined;
        this.events.onRoomUpdated?.(room, p ? `${p.name} entrou na sala!` : undefined);
        return;
      }

      if (type === 'room:player_left') {
        const pid = String(msg.playerId ?? '');
        const room = msg.room as RoomInfo;
        if (pid) this.events.onRemoteLeft?.(pid);
        this.events.onRoomUpdated?.(room, 'Um piloto saiu da sala.');
        return;
      }

      if (type === 'room:left') {
        this.currentRoomId = null;
        this.events.onRoomLeft?.();
        return;
      }

      if (type === 'room:error') {
        this.events.onRoomError?.(String(msg.message ?? 'Erro na sala.'));
        return;
      }

      if (type === 'room:state') {
        if (msg.state && typeof msg.state === 'object') {
          this.events.onRemoteState?.(msg.state as RemotePlayerState);
        }
        return;
      }

      if (type === 'world:door') {
        this.events.onDoorSync?.(Boolean(msg.open));
      }
    };

    ws.onclose = () => {
      this.events.onConnectionChange?.(false);
      this.ws = null;
      if (!this.intentionalClose) {
        this.reconnectTimer = window.setTimeout(() => {
          this.openSocket();
        }, 1800);
      }
    };
  }

  private send(payload: unknown) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    }
  }
}

function createNameTagSprite(label: string): {
  sprite: THREE.Sprite;
  texture: THREE.CanvasTexture;
  material: THREE.SpriteMaterial;
} {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.clearRect(0, 0, 256, 64);
    ctx.fillStyle = 'rgba(10, 12, 18, 0.78)';
    ctx.beginPath();
    ctx.roundRect(14, 12, 228, 40, 12);
    ctx.fill();
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.75)';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 22px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(label.slice(0, 16), 128, 33);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const material = new THREE.SpriteMaterial({
    map: texture,
    transparent: true,
    depthTest: true,
  });
  const sprite = new THREE.Sprite(material);
  sprite.scale.set(1.9, 0.48, 1);
  return { sprite, texture, material };
}

function lerpAngle(cur: number, target: number, alpha: number): number {
  let diff = target - cur;
  while (diff > Math.PI) diff -= Math.PI * 2;
  while (diff < -Math.PI) diff += Math.PI * 2;
  return cur + diff * alpha;
}

interface RemoteRiderEntry {
  playerId: string;
  name: string;
  moto: MotoRig;
  onFoot: OnFootPlayerRig;
  labelSprite: THREE.Sprite;
  labelTexture: THREE.CanvasTexture;
  labelMaterial: THREE.SpriteMaterial;
  target: RemotePlayerState;
  curX: number;
  curY: number;
  curZ: number;
  curHeading: number;
  curWheelie: number;
  curLean: number;
  curSteer: number;
  curPlayerX: number;
  curPlayerY: number;
  curPlayerZ: number;
  curPlayerHeading: number;
  customHash: string;
}

const _rNorm = new THREE.Vector3();
const _rUp = new THREE.Vector3(0, 1, 0);
const _rSlope = new THREE.Quaternion();
const _rYaw = new THREE.Quaternion();
const _rLean = new THREE.Quaternion();
const _rYAxis = new THREE.Vector3(0, 1, 0);
const _rZAxis = new THREE.Vector3(0, 0, 1);

export class RemotePlayers3DManager {
  private scene: THREE.Scene;
  private riders = new Map<string, RemoteRiderEntry>();
  private markers: RemoteMapMarker[] = [];

  constructor(scene: THREE.Scene) {
    this.scene = scene;
  }

  upsertState(state: RemotePlayerState) {
    const customHash = JSON.stringify(state.customization);
    let entry = this.riders.get(state.playerId);

    if (!entry) {
      const moto = createMoto160(state.customization, { isRemote: true });
      const onFoot = createOnFootPlayer();
      onFoot.group.visible = state.isOnFoot;
      const tag = createNameTagSprite(state.name);
      this.scene.add(moto.root);
      this.scene.add(onFoot.group);
      this.scene.add(tag.sprite);

      entry = {
        playerId: state.playerId,
        name: state.name,
        moto,
        onFoot,
        labelSprite: tag.sprite,
        labelTexture: tag.texture,
        labelMaterial: tag.material,
        target: state,
        curX: state.x,
        curY: state.y,
        curZ: state.z,
        curHeading: state.heading,
        curWheelie: state.wheelieRad,
        curLean: state.leanAngle,
        curSteer: state.steerAngle,
        curPlayerX: state.playerX,
        curPlayerY: state.playerY,
        curPlayerZ: state.playerZ,
        curPlayerHeading: state.playerHeading,
        customHash,
      };
      this.riders.set(state.playerId, entry);
      return;
    }

    if (entry.customHash !== customHash) {
      entry.customHash = customHash;
      entry.moto.applyCustomization(state.customization);
    }

    if (entry.name !== state.name) {
      entry.name = state.name;
      this.scene.remove(entry.labelSprite);
      entry.labelTexture.dispose();
      entry.labelMaterial.dispose();
      const nextTag = createNameTagSprite(state.name);
      entry.labelSprite = nextTag.sprite;
      entry.labelTexture = nextTag.texture;
      entry.labelMaterial = nextTag.material;
      this.scene.add(entry.labelSprite);
    }

    entry.target = state;
  }

  removePlayer(playerId: string) {
    const entry = this.riders.get(playerId);
    if (!entry) return;
    this.scene.remove(entry.moto.root);
    this.scene.remove(entry.onFoot.group);
    this.scene.remove(entry.labelSprite);
    entry.labelTexture.dispose();
    entry.labelMaterial.dispose();
    this.riders.delete(playerId);
  }

  clearAll() {
    for (const pid of Array.from(this.riders.keys())) {
      this.removePlayer(pid);
    }
    this.markers.length = 0;
  }

  update(dt: number, elapsedSec: number, nightFactor: number): RemoteMapMarker[] {
    const alpha = 1 - Math.exp(-12 * dt);
    this.markers.length = 0;

    for (const entry of this.riders.values()) {
      const t = entry.target;
      entry.curX = THREE.MathUtils.lerp(entry.curX, t.x, alpha);
      entry.curY = THREE.MathUtils.lerp(entry.curY, t.y, alpha);
      entry.curZ = THREE.MathUtils.lerp(entry.curZ, t.z, alpha);
      entry.curHeading = lerpAngle(entry.curHeading, t.heading, alpha);
      entry.curWheelie = THREE.MathUtils.lerp(entry.curWheelie, t.wheelieRad, alpha);
      entry.curLean = THREE.MathUtils.lerp(entry.curLean, t.leanAngle, alpha);
      entry.curSteer = THREE.MathUtils.lerp(entry.curSteer, t.steerAngle, alpha);

      entry.curPlayerX = THREE.MathUtils.lerp(entry.curPlayerX, t.playerX, alpha);
      entry.curPlayerY = THREE.MathUtils.lerp(entry.curPlayerY, t.playerY, alpha);
      entry.curPlayerZ = THREE.MathUtils.lerp(entry.curPlayerZ, t.playerZ, alpha);
      entry.curPlayerHeading = lerpAngle(entry.curPlayerHeading, t.playerHeading, alpha);

      groundNormalAt(entry.curX, entry.curZ, _rNorm);
      _rSlope.setFromUnitVectors(_rUp, _rNorm);
      _rYaw.setFromAxisAngle(_rYAxis, entry.curHeading);
      _rLean.setFromAxisAngle(_rZAxis, entry.curLean);

      entry.moto.root.position.set(entry.curX, entry.curY, entry.curZ);
      entry.moto.root.quaternion.copy(_rSlope).multiply(_rYaw).multiply(_rLean);
      entry.moto.rider.root.visible = !t.isOnFoot;

      const speedKmh = Math.abs(t.speedMs) * 3.6;
      entry.moto.updateAnimation({
        wheelSpinDelta: (t.speedMs * dt) / 0.305,
        steerAngle: entry.curSteer,
        wheelieRad: entry.curWheelie,
        speedKmh,
        throttle: Math.abs(t.speedMs) > 1.5,
        braking: t.braking,
        nightFactor,
        timeSec: elapsedSec,
      });

      entry.onFoot.group.visible = t.isOnFoot;
      if (t.isOnFoot) {
        entry.onFoot.group.position.set(entry.curPlayerX, entry.curPlayerY, entry.curPlayerZ);
        entry.onFoot.group.rotation.y = entry.curPlayerHeading;
        entry.onFoot.updateWalkAnimation(t.playerSpeed, elapsedSec, false);
        entry.labelSprite.position.set(entry.curPlayerX, entry.curPlayerY + 2.15, entry.curPlayerZ);
        this.markers.push({ id: entry.playerId, name: entry.name, x: entry.curPlayerX, z: entry.curPlayerZ });
      } else {
        entry.labelSprite.position.set(entry.curX, entry.curY + 2.05, entry.curZ);
        this.markers.push({ id: entry.playerId, name: entry.name, x: entry.curX, z: entry.curZ });
      }
    }

    return this.markers;
  }

  dispose() {
    this.clearAll();
  }
}
