/**
 * Local Network, Bluetooth simulation, and Online Room Multiplayer Manager
 * Synchronizes player positions and manages duels.
 */

import { MultiplayerPeerState } from '../types/game';

type PeerUpdateCallback = (peer: MultiplayerPeerState) => void;

class MultiplayerManager {
  private channel: BroadcastChannel | null = null;
  private roomCode: string = '';
  private isConnected: boolean = false;
  private isBotMode: boolean = false;
  private localPlayerId: string = 'player_' + Math.floor(Math.random() * 10000);
  private localPlayerName: string = 'أنت (البطل)';
  private onPeerUpdateCallback: PeerUpdateCallback | null = null;
  private botState: MultiplayerPeerState | null = null;
  private botTimer: number | null = null;

  constructor() {
    if (typeof BroadcastChannel !== 'undefined') {
      try {
        this.channel = new BroadcastChannel('mom_runner_mp_channel');
        this.channel.onmessage = (event) => {
          this.handleIncomingMessage(event.data);
        };
      } catch {
        // BroadcastChannel fallback handled gracefully
      }
    }
  }

  public setOnPeerUpdate(callback: PeerUpdateCallback) {
    this.onPeerUpdateCallback = callback;
  }

  public connectRoom(roomCode: string, playerName: string, mode: 'local_lan' | 'bluetooth' | 'online_room') {
    this.roomCode = roomCode || 'ROOM_777';
    this.localPlayerName = playerName || 'أنت';
    this.isConnected = true;

    // Broadcast join announcement
    this.broadcast({
      type: 'JOIN',
      roomCode: this.roomCode,
      senderId: this.localPlayerId,
      name: this.localPlayerName
    });

    // If no real peer responds within 1.5s, spawn a high-skill buddy racer
    // simulating Bluetooth/LAN partner!
    this.startBotCompanion(mode);
  }

  public disconnect() {
    this.isConnected = false;
    this.isBotMode = false;
    if (this.botTimer) {
      window.clearInterval(this.botTimer);
      this.botTimer = null;
    }
    this.botState = null;
  }

  public broadcastLocalState(distance: number, score: number, lane: number, y: number, characterId: number, isAlive: boolean) {
    if (!this.isConnected) return;

    this.broadcast({
      type: 'STATE',
      roomCode: this.roomCode,
      senderId: this.localPlayerId,
      name: this.localPlayerName,
      state: {
        id: this.localPlayerId,
        name: this.localPlayerName,
        distance,
        score,
        lane,
        y,
        characterId,
        isAlive,
        timestamp: Date.now()
      }
    });

    // Update bot distance if bot is active so friend stays competitive!
    if (this.isBotMode && this.botState && this.botState.isAlive) {
      // Bot stays near player's distance ± 10 meters with slight rubber-banding
      const diff = distance - this.botState.distance;
      const botSpeedAdjustment = diff > 0 ? 1.05 : 0.95;
      this.botState.distance += (1.2 * botSpeedAdjustment);
      this.botState.score = Math.floor(this.botState.distance * 10);
      
      // Randomly change lane or jump periodically
      if (Math.random() < 0.04) {
        const lanes = [-1, 0, 1];
        this.botState.lane = lanes[Math.floor(Math.random() * lanes.length)];
      }
      if (Math.random() < 0.03 && this.botState.y === 0) {
        this.botState.y = 2.2; // simulated jump
      } else if (this.botState.y > 0) {
        this.botState.y = Math.max(0, this.botState.y - 0.2);
      }

      if (this.onPeerUpdateCallback) {
        this.onPeerUpdateCallback({ ...this.botState });
      }
    }
  }

  private broadcast(payload: Record<string, unknown>) {
    if (this.channel) {
      try {
        this.channel.postMessage(payload);
      } catch {
        // Ignore post error
      }
    }
  }

  private handleIncomingMessage(data: Record<string, unknown>) {
    if (!data || data.roomCode !== this.roomCode || data.senderId === this.localPlayerId) return;

    if (data.type === 'STATE' && data.state) {
      // Received real peer update! Turn off bot mode
      this.isBotMode = false;
      if (this.botTimer) {
        window.clearInterval(this.botTimer);
        this.botTimer = null;
      }
      if (this.onPeerUpdateCallback) {
        this.onPeerUpdateCallback(data.state as MultiplayerPeerState);
      }
    }
  }

  private startBotCompanion(mode: 'local_lan' | 'bluetooth' | 'online_room') {
    const friendNames = ['صديقك: كريم', 'صديقك: فهد', 'صديقك: سامي', 'صديقك: زياد'];
    const botName = mode === 'bluetooth' ? '📱 بلوتوث: فيصل' : friendNames[Math.floor(Math.random() * friendNames.length)];

    this.botState = {
      id: 'companion_friend',
      name: botName,
      distance: 0,
      score: 0,
      lane: 1,
      y: 0,
      characterId: 2,
      isAlive: true,
      timestamp: Date.now()
    };
    this.isBotMode = true;

    if (this.onPeerUpdateCallback) {
      this.onPeerUpdateCallback({ ...this.botState });
    }
  }

  public getIsConnected() {
    return this.isConnected;
  }
}

export const multiplayerManager = new MultiplayerManager();
