import { getHeroById } from '../data/heroesData';
import { getItemById } from '../data/itemsData';
import { HeroStats, SaveData } from '../types/game';

const SAVE_STORAGE_KEY = 'infinity_shadow_realms_v2_save';
const CURRENT_SAVE_VERSION = 2;

export function createDefaultSaveData(): SaveData {
  return {
    version: CURRENT_SAVE_VERSION,
    coins: 180,
    xp: 0,
    playerLevel: 1,
    skillPoints: 1,
    selectedHeroId: 'kaelen',
    unlockedHeroIds: ['kaelen'],
    heroLevels: {
      kaelen: 1,
      lyra: 1,
      akari: 1,
      seraphina: 1,
      ignis: 1,
      aetherion: 1,
    },
    skillUpgrades: {
      attackRank: 0,
      defenseRank: 0,
      healthRank: 0,
      cooldownRank: 0,
      specialRank: 0,
    },
    ownedItemIds: [],
    potionsCount: 2,
    equippedWeaponId: null,
    equippedArmorId: null,
    equippedAccessoryId: null,
    equippedOutfitId: null,
    equippedPetId: null,
    equippedCosmeticId: null,
    unlockedWorldMax: 1,
    completedWorlds: [],
    worldStars: {},
    secretsFoundWorlds: [],
    activeCheckpoint: null,
    statsTracker: {
      enemiesDefeated: 0,
      bossesDefeated: 0,
      maxComboReached: 0,
      coinsEarnedTotal: 180,
      skillUpgradesBought: 0,
    },
    claimedQuestIds: [],
    claimedAchievementIds: [],
    settings: {
      musicVolume: 0.45,
      sfxVolume: 0.75,
      graphicsQuality: 'high',
      showTouchControls: true,
      touchControlScale: 1.0,
    },
  };
}

export function loadSaveData(): SaveData {
  const fallback = createDefaultSaveData();
  if (typeof window === 'undefined') return fallback;

  try {
    const raw = window.localStorage.getItem(SAVE_STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return fallback;

    // Safe deep validation against damaged or partial fields
    const safeUnlocked = Array.isArray(parsed.unlockedHeroIds)
      ? parsed.unlockedHeroIds.filter((x: unknown) => typeof x === 'string')
      : ['kaelen'];
    if (!safeUnlocked.includes('kaelen')) safeUnlocked.unshift('kaelen');

    const safeSelected =
      typeof parsed.selectedHeroId === 'string' && safeUnlocked.includes(parsed.selectedHeroId)
        ? parsed.selectedHeroId
        : 'kaelen';

    return {
      version: CURRENT_SAVE_VERSION,
      coins: typeof parsed.coins === 'number' && parsed.coins >= 0 ? Math.floor(parsed.coins) : fallback.coins,
      xp: typeof parsed.xp === 'number' && parsed.xp >= 0 ? Math.floor(parsed.xp) : 0,
      playerLevel:
        typeof parsed.playerLevel === 'number' && parsed.playerLevel >= 1
          ? Math.floor(parsed.playerLevel)
          : 1,
      skillPoints:
        typeof parsed.skillPoints === 'number' && parsed.skillPoints >= 0
          ? Math.floor(parsed.skillPoints)
          : fallback.skillPoints,
      selectedHeroId: safeSelected,
      unlockedHeroIds: safeUnlocked,
      heroLevels: {
        ...fallback.heroLevels,
        ...(parsed.heroLevels && typeof parsed.heroLevels === 'object' ? parsed.heroLevels : {}),
      },
      skillUpgrades: {
        ...fallback.skillUpgrades,
        ...(parsed.skillUpgrades && typeof parsed.skillUpgrades === 'object'
          ? parsed.skillUpgrades
          : {}),
      },
      ownedItemIds: Array.isArray(parsed.ownedItemIds)
        ? parsed.ownedItemIds.filter((x: unknown) => typeof x === 'string')
        : [],
      potionsCount:
        typeof parsed.potionsCount === 'number' && parsed.potionsCount >= 0
          ? Math.floor(parsed.potionsCount)
          : 2,
      equippedWeaponId:
        typeof parsed.equippedWeaponId === 'string' ? parsed.equippedWeaponId : null,
      equippedArmorId:
        typeof parsed.equippedArmorId === 'string' ? parsed.equippedArmorId : null,
      equippedAccessoryId:
        typeof parsed.equippedAccessoryId === 'string' ? parsed.equippedAccessoryId : null,
      equippedOutfitId:
        typeof parsed.equippedOutfitId === 'string' ? parsed.equippedOutfitId : null,
      equippedPetId: typeof parsed.equippedPetId === 'string' ? parsed.equippedPetId : null,
      equippedCosmeticId:
        typeof parsed.equippedCosmeticId === 'string' ? parsed.equippedCosmeticId : null,
      unlockedWorldMax:
        typeof parsed.unlockedWorldMax === 'number'
          ? Math.max(1, Math.min(6, Math.floor(parsed.unlockedWorldMax)))
          : 1,
      completedWorlds: Array.isArray(parsed.completedWorlds)
        ? parsed.completedWorlds.filter((n: unknown) => typeof n === 'number')
        : [],
      worldStars:
        parsed.worldStars && typeof parsed.worldStars === 'object' ? parsed.worldStars : {},
      secretsFoundWorlds: Array.isArray(parsed.secretsFoundWorlds)
        ? parsed.secretsFoundWorlds.filter((n: unknown) => typeof n === 'number')
        : [],
      activeCheckpoint:
        parsed.activeCheckpoint &&
        typeof parsed.activeCheckpoint === 'object' &&
        typeof parsed.activeCheckpoint.worldId === 'number'
          ? parsed.activeCheckpoint
          : null,
      statsTracker: {
        ...fallback.statsTracker,
        ...(parsed.statsTracker && typeof parsed.statsTracker === 'object'
          ? parsed.statsTracker
          : {}),
      },
      claimedQuestIds: Array.isArray(parsed.claimedQuestIds) ? parsed.claimedQuestIds : [],
      claimedAchievementIds: Array.isArray(parsed.claimedAchievementIds)
        ? parsed.claimedAchievementIds
        : [],
      settings: {
        ...fallback.settings,
        ...(parsed.settings && typeof parsed.settings === 'object' ? parsed.settings : {}),
      },
    };
  } catch {
    return fallback;
  }
}

export function persistSaveData(data: SaveData): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(data));
  } catch {
    // Ignore storage quota errors safely
  }
}

export function xpRequiredForLevel(level: number): number {
  return Math.round(140 * Math.pow(1.32, level - 1));
}

export function applyXpGain(
  save: SaveData,
  xpAmount: number
): { updated: SaveData; levelsGained: number } {
  let xp = save.xp + Math.max(0, Math.round(xpAmount));
  let playerLevel = save.playerLevel;
  let skillPoints = save.skillPoints;
  let levelsGained = 0;

  while (xp >= xpRequiredForLevel(playerLevel)) {
    xp -= xpRequiredForLevel(playerLevel);
    playerLevel += 1;
    skillPoints += 1;
    levelsGained += 1;
  }

  return {
    updated: {
      ...save,
      xp,
      playerLevel,
      skillPoints,
    },
    levelsGained,
  };
}

export function computeEffectiveHeroStats(
  save: SaveData,
  heroId: string = save.selectedHeroId
): HeroStats & { specialBonusMultiplier: number } {
  const hero = getHeroById(heroId);
  const heroLvl = Math.max(1, save.heroLevels[hero.id] || 1);
  const lvlFactor = heroLvl - 1;
  const playerLvlFactor = Math.max(0, save.playerLevel - 1);

  let maxHp =
    hero.baseStats.maxHp +
    lvlFactor * 26 +
    playerLvlFactor * 12 +
    save.skillUpgrades.healthRank * 30;

  let attack =
    hero.baseStats.attack +
    lvlFactor * 5 +
    playerLvlFactor * 2 +
    save.skillUpgrades.attackRank * 5;

  let defense =
    hero.baseStats.defense +
    lvlFactor * 2.5 +
    playerLvlFactor * 1 +
    save.skillUpgrades.defenseRank * 3;

  let critChance = hero.baseStats.critChance;
  let cooldownReduction =
    hero.baseStats.cooldownReduction + save.skillUpgrades.cooldownRank * 0.035;
  let moveSpeed = hero.baseStats.moveSpeed;

  const equippedIds = [
    save.equippedWeaponId,
    save.equippedArmorId,
    save.equippedAccessoryId,
    save.equippedPetId,
  ];

  for (const id of equippedIds) {
    const item = getItemById(id);
    if (item?.statsBonus) {
      maxHp += item.statsBonus.maxHp || 0;
      attack += item.statsBonus.attack || 0;
      defense += item.statsBonus.defense || 0;
      critChance += item.statsBonus.critChance || 0;
      cooldownReduction += item.statsBonus.cooldownReduction || 0;
      moveSpeed += item.statsBonus.moveSpeed || 0;
    }
  }

  return {
    maxHp: Math.round(maxHp),
    attack: Math.round(attack),
    defense: Math.round(defense),
    critChance: Math.min(0.75, critChance),
    cooldownReduction: Math.min(0.5, cooldownReduction),
    moveSpeed: Math.round(moveSpeed),
    specialBonusMultiplier: 1 + save.skillUpgrades.specialRank * 0.12,
  };
}

export function getQuestOrAchievementMetric(save: SaveData, metric: string): number {
  switch (metric) {
    case 'enemiesDefeated':
      return save.statsTracker.enemiesDefeated;
    case 'bossesDefeated':
      return save.statsTracker.bossesDefeated;
    case 'worldsClearedCount':
      return save.completedWorlds.length;
    case 'secretsFoundCount':
      return save.secretsFoundWorlds.length;
    case 'maxComboReached':
      return save.statsTracker.maxComboReached;
    case 'heroesUnlockedCount':
      return save.unlockedHeroIds.length;
    case 'skillUpgradesBought':
      return save.statsTracker.skillUpgradesBought;
    case 'coinsEarnedTotal':
      return save.statsTracker.coinsEarnedTotal;
    case 'playerLevel':
      return save.playerLevel;
    case 'world6Cleared':
      return save.completedWorlds.includes(6) ? 1 : 0;
    case 'mythicUnlocked':
      return save.unlockedHeroIds.includes('aetherion') ? 1 : 0;
    default:
      return 0;
  }
}
