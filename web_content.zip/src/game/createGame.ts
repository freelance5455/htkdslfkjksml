import Phaser from 'phaser';
import { BootScene } from './scenes/BootScene';
import { MenuScene } from './scenes/MenuScene';
import { GameScene } from './scenes/GameScene';
import { storage } from './storage';
import { qualityFor, resolveTier } from './perf';
import { sound } from './audio';
import { haptics } from './haptics';
import type { SafeArea } from './layout';

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** Waits until the web font is usable (or gives up after `timeout` ms). */
async function waitForFont(family: string, timeout: number): Promise<void> {
  if (typeof document === 'undefined' || !('fonts' in document)) return;
  if (navigator.onLine === false) return; // offline: use the system fallback font immediately
  const start = performance.now();
  while (performance.now() - start < timeout) {
    if ((window as unknown as { __fontFail?: number }).__fontFail) return; // stylesheet failed to load
    try {
      const faces = await document.fonts.load(`700 20px "${family}"`);
      if (faces.length > 0) return;
    } catch {
      return;
    }
    await sleep(80);
  }
}

function readSafeArea(): SafeArea {
  try {
    const probe = document.createElement('div');
    probe.style.cssText =
      'position:fixed;top:0;left:0;width:0;height:0;visibility:hidden;pointer-events:none;' +
      'padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)';
    document.body.appendChild(probe);
    const cs = getComputedStyle(probe);
    const top = parseFloat(cs.paddingTop) || 0;
    const bottom = parseFloat(cs.paddingBottom) || 0;
    probe.remove();
    return { top, bottom };
  } catch {
    return { top: 0, bottom: 0 };
  }
}

export async function bootGame(parent: HTMLElement, onReady: () => void): Promise<Phaser.Game> {
  await waitForFont('Fredoka', 2500);

  const settings = storage.getSettings();
  sound.enabled = settings.sound;
  haptics.enabled = settings.haptics;

  const quality = qualityFor(resolveTier(settings.quality));
  let dpr = Math.min(window.devicePixelRatio || 1, quality.dprCap);
  const safe = readSafeArea();

  const dims = () => {
    const w = parent.clientWidth || window.innerWidth;
    const h = parent.clientHeight || window.innerHeight;
    return { w: Math.max(240, Math.round(w * dpr)), h: Math.max(320, Math.round(h * dpr)) };
  };
  const initial = dims();

  const game = new Phaser.Game({
    type: Phaser.AUTO,
    parent,
    width: initial.w,
    height: initial.h,
    backgroundColor: '#1a2342',
    banner: false,
    disableContextMenu: true,
    scale: {
      mode: Phaser.Scale.FIT,
      autoCenter: Phaser.Scale.CENTER_BOTH,
      expandParent: false,
    },
    render: {
      antialias: true,
      antialiasGL: true,
      pixelArt: false,
      roundPixels: false,
      transparent: false,
      powerPreference: 'high-performance',
      batchSize: 4096,
      failIfMajorPerformanceCaveat: false,
    },
    fps: { target: 60, smoothStep: true },
    input: { activePointers: 2, smoothFactor: 0 },
    audio: { noAudio: true },
    scene: [BootScene, MenuScene, GameScene],
  });

  game.registry.set('quality', quality);
  game.registry.set('dpr', dpr);
  game.registry.set('safe', safe);
  game.registry.set('onReady', onReady);

  let raf = 0;
  const resize = () => {
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(() => {
      if (!game.scale) return;
      const s = dims();
      if (s.w !== game.scale.width || s.h !== game.scale.height) {
        game.scale.setGameSize(s.w, s.h);
      }
      game.scale.refresh();
    });
  };

  game.registry.set('setDpr', (d: number) => {
    dpr = Math.max(0.75, d);
    game.registry.set('dpr', dpr);
    resize();
  });

  window.addEventListener('resize', resize);
  window.addEventListener('orientationchange', resize);
  window.visualViewport?.addEventListener('resize', resize);
  // A second pass shortly after boot catches late layout changes (URL bar, keyboard, etc.).
  const lateCheck = window.setTimeout(resize, 600);

  game.events.once(Phaser.Core.Events.DESTROY, () => {
    window.clearTimeout(lateCheck);
    cancelAnimationFrame(raf);
    window.removeEventListener('resize', resize);
    window.removeEventListener('orientationchange', resize);
    window.visualViewport?.removeEventListener('resize', resize);
  });

  return game;
}
