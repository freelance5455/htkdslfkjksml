// ═══════════════════════════════════════════════════════════════
// DARK GHOUL V2 — بناء الشخصيات البشرية + نظام الكاغوني
// ملاحظة: الشخصيات مبنية إجرائياً بهيكل عظمي مفصلي (بديل مؤقت).
// لاستبدالها بنماذج احترافية: استخدم GLTFLoader في buildHumanoid
// مع الحفاظ على نفس نقاط الارتكاز (hips/chest/head/arms/legs).
// ═══════════════════════════════════════════════════════════════
import * as THREE from "three";
import { CharacterDef } from "./data";
import { clamp, damp, lerp } from "./systems";

export interface Rig {
  root: THREE.Group;
  hips: THREE.Group;
  spine: THREE.Group;
  chest: THREE.Group;
  head: THREE.Group;
  armL: THREE.Group; armR: THREE.Group;
  foreL: THREE.Group; foreR: THREE.Group;
  handL: THREE.Group; handR: THREE.Group;
  legL: THREE.Group; legR: THREE.Group;
  shinL: THREE.Group; shinR: THREE.Group;
  eyeMats: THREE.MeshStandardMaterial[];
  allMats: THREE.MeshStandardMaterial[];
  def: CharacterDef | null;
  animPhase: number;
  climbPhase: number;
  flashT: number;
  scale: number;
}

export interface RigState {
  mv: number; run: boolean; grounded: boolean; vy: number;
  climbing: boolean;
  attack: { kind: string; p: number } | null;
  block: boolean; kagune: boolean; dead: number; flinch: number;
}

export function makeGlowTexture(color: string, size = 128): THREE.CanvasTexture {
  const cv = document.createElement("canvas"); cv.width = cv.height = size;
  const g = cv.getContext("2d")!;
  const grad = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grad.addColorStop(0, color);
  grad.addColorStop(0.35, color + "88");
  grad.addColorStop(1, "transparent");
  g.fillStyle = grad; g.fillRect(0, 0, size, size);
  return new THREE.CanvasTexture(cv);
}

function mat(color: number, rough = 0.75, metal = 0.05, extra: any = {}): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal, ...extra });
}
function part(parent: THREE.Object3D, geo: THREE.BufferGeometry, m: THREE.Material, x = 0, y = 0, z = 0): THREE.Mesh {
  const mesh = new THREE.Mesh(geo, m);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  parent.add(mesh);
  return mesh;
}

// ─────────────── بناء إنسان كامل بمفاصل ───────────────
export function buildHumanoid(def: CharacterDef | null, palette?: { jacket: number; pants: number; skin: number; hair: number }): Rig {
  const C = def ? def.colors : { skin: palette!.skin, hair: palette!.hair, jacket: palette!.jacket, pants: palette!.pants, accent: 0x882233 };
  const skinM = mat(C.skin, 0.68, 0.02);
  const hairM = mat(C.hair, 0.85, 0.02);
  const jacketM = mat(C.jacket, 0.8, 0.04);
  const pantsM = mat(C.pants, 0.85, 0.03);
  const shoeM = mat(0x121214, 0.6, 0.1);
  const accentM = mat(C.accent, 0.5, 0.3, { emissive: C.accent, emissiveIntensity: 0.25 });
  const allMats = [skinM, hairM, jacketM, pantsM, shoeM, accentM];

  const root = new THREE.Group();
  const hips = new THREE.Group(); hips.position.y = 0.98; root.add(hips);
  part(hips, new THREE.CapsuleGeometry(0.135, 0.08, 3, 10), pantsM, 0, 0.02, 0);
  // معطف طويل لبعض الشخصيات
  if (def && (def.id === "kuro" || def.id === "yuki" || def.id === "hollow")) {
    part(hips, new THREE.CylinderGeometry(0.15, 0.22, 0.34, 10, 1, true), jacketM, 0, -0.12, 0);
  }

  // الأرجل
  const mkLeg = (side: number) => {
    const leg = new THREE.Group(); leg.position.set(0.1 * side, -0.02, 0); hips.add(leg);
    part(leg, new THREE.CapsuleGeometry(0.062, 0.3, 3, 8), pantsM, 0, -0.19, 0);
    const shin = new THREE.Group(); shin.position.set(0, -0.4, 0); leg.add(shin);
    part(shin, new THREE.CapsuleGeometry(0.05, 0.3, 3, 8), pantsM, 0, -0.2, 0);
    part(shin, new THREE.BoxGeometry(0.09, 0.06, 0.21), shoeM, 0, -0.53, 0.05);
    return { leg, shin };
  };
  const L = mkLeg(-1), R = mkLeg(1);

  // الجذع
  const spine = new THREE.Group(); spine.position.set(0, 0.1, 0); hips.add(spine);
  part(spine, new THREE.CapsuleGeometry(0.15, 0.24, 3, 10), jacketM, 0, 0.17, 0);
  const chest = new THREE.Group(); chest.position.set(0, 0.42, 0); spine.add(chest);
  part(chest, new THREE.CapsuleGeometry(0.155, 0.1, 3, 10), jacketM, 0, 0.02, 0);
  // وشاح/ياقة بلون مميز
  part(chest, new THREE.TorusGeometry(0.1, 0.035, 6, 12), accentM, 0, 0.1, 0.02).rotation.x = Math.PI / 2.3;

  // الذراعان
  const mkArm = (side: number) => {
    const arm = new THREE.Group(); arm.position.set(0.215 * side, 0.05, 0); chest.add(arm);
    part(arm, new THREE.CapsuleGeometry(0.05, 0.22, 3, 8), jacketM, 0, -0.14, 0);
    const fore = new THREE.Group(); fore.position.set(0, -0.3, 0); arm.add(fore);
    part(fore, new THREE.CapsuleGeometry(0.042, 0.18, 3, 8), skinM, 0, -0.12, 0);
    const hand = new THREE.Group(); hand.position.set(0, -0.27, 0); fore.add(hand);
    part(hand, new THREE.SphereGeometry(0.052, 8, 8), skinM, 0, 0, 0);
    return { arm, fore, hand };
  };
  const AL = mkArm(-1), AR = mkArm(1);

  // الرأس والوجه
  const head = new THREE.Group(); head.position.set(0, 0.16, 0); chest.add(head);
  part(head, new THREE.CylinderGeometry(0.045, 0.05, 0.09, 8), skinM, 0, 0.03, 0);
  const skull = part(head, new THREE.SphereGeometry(0.115, 14, 12), skinM, 0, 0.145, 0);
  skull.scale.set(0.94, 1, 0.96);
  const eyeMat = () => new THREE.MeshStandardMaterial({ color: 0xd8d0c8, roughness: 0.2, metalness: 0.1 });
  const eyeMats: THREE.MeshStandardMaterial[] = [];
  [-1, 1].forEach((s) => {
    const em = eyeMat(); eyeMats.push(em);
    part(head, new THREE.SphereGeometry(0.02, 8, 8), em, 0.045 * s, 0.155, 0.095);
    const brow = part(head, new THREE.BoxGeometry(0.048, 0.009, 0.012), hairM, 0.045 * s, 0.19, 0.1);
    brow.rotation.z = -0.12 * s;
  });
  // الأنف (نتوء خفيف)
  part(head, new THREE.ConeGeometry(0.014, 0.035, 5), skinM, 0, 0.13, 0.112).rotation.x = Math.PI / 2;

  // الشعر
  const hairStyle = def ? def.hair : "short";
  const capGeo = new THREE.SphereGeometry(0.123, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.62);
  if (hairStyle === "spiky") {
    part(head, capGeo, hairM, 0, 0.155, -0.008);
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * Math.PI * 1.6 - Math.PI * 0.8;
      const spike = part(head, new THREE.ConeGeometry(0.04, 0.14, 5), hairM, Math.sin(a) * 0.09, 0.25, Math.cos(a) * 0.07 - 0.02);
      spike.rotation.set(Math.cos(a) * 0.7, 0, -Math.sin(a) * 0.7);
    }
  } else if (hairStyle === "long") {
    part(head, capGeo, hairM, 0, 0.155, -0.005);
    part(head, new THREE.CapsuleGeometry(0.09, 0.26, 3, 8), hairM, 0, 0.02, -0.09);
    part(head, new THREE.CapsuleGeometry(0.035, 0.2, 3, 6), hairM, -0.11, 0.06, 0.02);
    part(head, new THREE.CapsuleGeometry(0.035, 0.2, 3, 6), hairM, 0.11, 0.06, 0.02);
  } else if (hairStyle === "wild") {
    part(head, capGeo, hairM, 0, 0.155, -0.005);
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2;
      const tuft = part(head, new THREE.ConeGeometry(0.045, 0.2, 5), hairM, Math.sin(a) * 0.1, 0.2, Math.cos(a) * 0.1 - 0.02);
      tuft.rotation.set(Math.cos(a) * 0.9, 0, -Math.sin(a) * 0.9);
    }
    part(head, new THREE.CapsuleGeometry(0.085, 0.4, 3, 8), hairM, 0, -0.08, -0.09);
  } else if (hairStyle === "hood") {
    const hood = part(head, new THREE.SphereGeometry(0.148, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.65), jacketM, 0, 0.145, -0.015);
    hood.scale.set(1.08, 1.05, 1.1);
    part(head, capGeo, hairM, 0, 0.15, 0.005);
    part(chest, new THREE.TorusGeometry(0.13, 0.05, 6, 12), jacketM, 0, 0.1, -0.04).rotation.x = Math.PI / 2.4;
  } else if (hairStyle === "mask") {
    part(head, capGeo, hairM, 0, 0.155, -0.01);
    part(head, new THREE.CapsuleGeometry(0.08, 0.42, 3, 8), hairM, 0, -0.06, -0.09);
    const maskM = mat(0xe8e4dc, 0.3, 0.05);
    const mask = part(head, new THREE.SphereGeometry(0.121, 14, 10), maskM, 0, 0.15, 0.028);
    mask.scale.set(0.96, 0.9, 0.62);
    allMats.push(maskM);
  } else {
    part(head, capGeo, hairM, 0, 0.155, -0.005);
  }

  const sc = def ? def.scale : 1;
  root.scale.setScalar(sc);

  return {
    root, hips, spine, chest, head,
    armL: AL.arm, armR: AR.arm, foreL: AL.fore, foreR: AR.fore, handL: AL.hand, handR: AR.hand,
    legL: L.leg, legR: R.leg, shinL: L.shin, shinR: R.shin,
    eyeMats, allMats, def, animPhase: Math.random() * 6, climbPhase: 0, flashT: 0, scale: sc,
  };
}

export function setKaguneEyes(rig: Rig, on: boolean, color = 0xff1f3d) {
  rig.eyeMats.forEach((m) => {
    m.color.setHex(on ? 0x0a0407 : 0xd8d0c8);
    m.emissive.setHex(on ? color : 0x000000);
    m.emissiveIntensity = on ? 3 : 0;
  });
}

// مدني مبسّط (أداء عالٍ)
export function buildCivilian(jacket: number, pants: number, skin: number, hair: number): THREE.Group {
  const g = new THREE.Group();
  const jm = mat(jacket, 0.85), pm = mat(pants, 0.85), sm = mat(skin, 0.7), hm = mat(hair, 0.85);
  part(g, new THREE.CylinderGeometry(0.05, 0.06, 0.45, 6), pm, -0.07, 0.24, 0);
  part(g, new THREE.CylinderGeometry(0.05, 0.06, 0.45, 6), pm, 0.07, 0.24, 0);
  part(g, new THREE.CapsuleGeometry(0.14, 0.42, 3, 8), jm, 0, 0.85, 0);
  part(g, new THREE.SphereGeometry(0.1, 10, 8), sm, 0, 1.32, 0);
  part(g, new THREE.SphereGeometry(0.107, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.55), hm, 0, 1.33, -0.005);
  return g;
}

// ─────────────── نظام الكاغوني ───────────────
interface TailDef { n: number; segLen: number; r0: number; baseAng: number; anchor: [number, number, number]; flat?: boolean; cone?: boolean; spikes?: boolean; phase: number }
export interface Tail { bones: THREE.Group[]; n: number; phase: number; baseAng: number; gi0: number }
export interface KaguneRig {
  group: THREE.Group;
  tails: Tail[];
  aura: THREE.Sprite;
  type: string;
  totalSegs: number;
  emerge: number;
  active: boolean;
  strikeT: number; strikeKind: string;
  blackM: THREE.MeshStandardMaterial;
  armorParts?: THREE.Object3D[];
}

function tailDefsFor(type: string, rangeMul: number): TailDef[] {
  const S = rangeMul;
  const lowerL: [number, number, number] = [-0.09, -0.28, -0.13];
  const lowerR: [number, number, number] = [0.09, -0.28, -0.13];
  const shL: [number, number, number] = [-0.17, 0.02, -0.1];
  const shR: [number, number, number] = [0.17, 0.02, -0.1];
  switch (type) {
    case "blade":
      return [
        { n: 6, segLen: 0.42 * S, r0: 0.11, baseAng: -1.15, anchor: shL, cone: true, spikes: true, phase: 0 },
        { n: 6, segLen: 0.42 * S, r0: 0.11, baseAng: -1.15, anchor: shR, cone: true, spikes: true, phase: 2 },
      ];
    case "wing":
      return [
        { n: 8, segLen: 0.44 * S, r0: 0.13, baseAng: -0.9, anchor: shL, flat: true, spikes: true, phase: 0.4 },
        { n: 8, segLen: 0.44 * S, r0: 0.13, baseAng: -0.9, anchor: shR, flat: true, spikes: true, phase: 2.4 },
        { n: 6, segLen: 0.34 * S, r0: 0.08, baseAng: -2.0, anchor: lowerL, phase: 1.2 },
        { n: 6, segLen: 0.34 * S, r0: 0.08, baseAng: -2.0, anchor: lowerR, phase: 3.2 },
      ];
    case "tail":
      return [0, 1, 2, 3, 4].map((i) => ({
        n: 9, segLen: 0.34 * S, r0: 0.075, baseAng: -1.9 - (i - 2) * 0.06,
        anchor: [((i - 2) * 0.055), -0.27, -0.13] as [number, number, number], phase: i * 1.25,
      }));
    case "armor":
      return [
        { n: 5, segLen: 0.4 * S, r0: 0.14, baseAng: -2.1, anchor: [0, -0.3, -0.13], spikes: true, phase: 0.6 },
      ];
    case "monster":
      return [0, 1, 2, 3, 4, 5].map((i) => ({
        n: 8, segLen: 0.52 * S, r0: 0.15, baseAng: -1.5 - (i % 3) * 0.35,
        anchor: [((i - 2.5) * 0.06), -0.24 - (i % 2) * 0.06, -0.14] as [number, number, number], spikes: true, cone: i % 2 === 0, phase: i * 0.9,
      }));
    default: // hybrid
      return [
        { n: 8, segLen: 0.4 * S, r0: 0.09, baseAng: -1.8, anchor: lowerL, spikes: true, phase: 0 },
        { n: 8, segLen: 0.4 * S, r0: 0.09, baseAng: -1.8, anchor: lowerR, spikes: true, phase: 1.7 },
        { n: 6, segLen: 0.4 * S, r0: 0.12, baseAng: -1.05, anchor: shL, cone: true, spikes: true, phase: 0.8 },
        { n: 6, segLen: 0.4 * S, r0: 0.12, baseAng: -1.05, anchor: shR, cone: true, spikes: true, phase: 2.6 },
      ];
  }
}

export function buildKagune(type: string, rig: Rig, rangeMul: number): KaguneRig {
  const group = new THREE.Group();
  rig.chest.add(group);
  const blackM = new THREE.MeshStandardMaterial({ color: 0x0b0609, roughness: 0.35, metalness: 0.4, emissive: 0x30060f, emissiveIntensity: 0.5 });
  const tipM = new THREE.MeshStandardMaterial({ color: 0x22040a, roughness: 0.3, metalness: 0.2, emissive: 0xff1f3d, emissiveIntensity: 2.4 });
  const spikeM = new THREE.MeshStandardMaterial({ color: 0x3d0713, roughness: 0.25, metalness: 0.45, emissive: 0xd21f3c, emissiveIntensity: 1.6 });

  const tails: Tail[] = [];
  let gi = 0;
  for (const td of tailDefsFor(type, rangeMul)) {
    const bones: THREE.Group[] = [];
    let parent: THREE.Object3D = group;
    for (let i = 0; i < td.n; i++) {
      const bone = new THREE.Group();
      if (i === 0) bone.position.set(td.anchor[0], td.anchor[1], td.anchor[2]);
      else bone.position.y = td.segLen;
      parent.add(bone);
      const r = td.r0 * (1 - (i / td.n) * 0.72);
      let seg: THREE.Mesh;
      if (td.cone) {
        seg = new THREE.Mesh(new THREE.ConeGeometry(r * 1.5, td.segLen * 1.12, 5), blackM);
        seg.position.y = td.segLen * 0.5;
      } else {
        seg = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.62, r, td.segLen, 6), blackM);
        seg.position.y = td.segLen * 0.5;
      }
      if (td.flat) seg.scale.set(1.9, 1, 0.28);
      seg.castShadow = true;
      bone.add(seg);
      if (td.spikes && i > 0 && i % 2 === 0) {
        const sp = new THREE.Mesh(new THREE.OctahedronGeometry(r * 1.5), spikeM);
        sp.position.set(0, td.segLen * 0.4, r * 0.8);
        sp.scale.set(0.45, 1.5, 0.45);
        bone.add(sp);
      }
      if (i === td.n - 1) {
        const tip = new THREE.Mesh(new THREE.ConeGeometry(r * 1.1, td.segLen * 0.7, 5), tipM);
        tip.position.y = td.segLen * 0.95;
        bone.add(tip);
      }
      bones.push(bone);
      parent = bone;
    }
    tails.push({ bones, n: td.n, phase: td.phase, baseAng: td.baseAng, gi0: gi });
    gi += td.n;
  }

  // درع الذراع لنوع Armor (يظهر عند التحول فقط)
  let armorParts: THREE.Object3D[] | undefined;
  if (type === "armor") {
    const plateM = blackM;
    const plate = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.42, 0.16), plateM);
    plate.position.set(0, -0.14, 0);
    rig.foreR.add(plate);
    const blade = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.75, 4), tipM);
    blade.position.set(0, -0.28, 0.1); blade.rotation.x = Math.PI / 2.2;
    rig.foreR.add(blade);
    const pauldron = new THREE.Mesh(new THREE.SphereGeometry(0.13, 8, 6, 0, Math.PI * 2, 0, Math.PI * 0.6), plateM);
    pauldron.position.set(0, 0.06, 0);
    rig.armR.add(pauldron);
    plate.visible = blade.visible = pauldron.visible = false;
    armorParts = [plate, blade, pauldron];
    group.visible = false;
  }

  const aura = new THREE.Sprite(new THREE.SpriteMaterial({
    map: makeGlowTexture("#ff2038"), transparent: true, opacity: 0,
    blending: THREE.AdditiveBlending, depthWrite: false,
  }));
  aura.position.y = 1;
  aura.scale.setScalar(2.4);
  rig.root.add(aura);

  return { group, tails, aura, type, totalSegs: gi, emerge: 0, active: false, strikeT: -1, strikeKind: "slash", blackM, armorParts };
}

export function updateKagune(k: KaguneRig, dt: number, t: number, moving: boolean) {
  const show = k.type === "armor" ? k.active : k.emerge > 0.01;
  k.group.visible = show && k.type !== "armor";
  if (k.armorParts) {
    const vis = k.active || k.emerge > 0.55;
    for (const ap of k.armorParts) ap.visible = vis;
  }
  (k.aura.material as THREE.SpriteMaterial).opacity = damp(
    (k.aura.material as THREE.SpriteMaterial).opacity,
    k.active ? 0.4 + Math.sin(t * 7) * 0.12 : 0, 6, dt
  );
  k.aura.scale.setScalar(2.3 + Math.sin(t * 5) * 0.3);

  for (const tail of k.tails) {
    const amp = k.active ? (moving ? 0.2 : 0.11) : 0;
    for (let i = 0; i < tail.n; i++) {
      const bone = tail.bones[i];
      const grow = clamp(k.emerge * (k.totalSegs * 1.5) - (tail.gi0 + i), 0.0001, 1);
      bone.scale.setScalar(grow);
      const base = i === 0 ? tail.baseAng * 0.8 : tail.baseAng * 0.22;
      const wave = Math.sin(t * (2.2 + tail.phase * 0.3) + tail.phase + i * 0.5) * amp * (0.5 + i / tail.n);
      const waveZ = Math.sin(t * 1.6 + tail.phase * 2 + i * 0.62) * amp * 0.6;
      let strike = 0;
      if (k.strikeT >= 0) {
        const sp = clamp(k.strikeT * 1.9 - (tail.gi0 + i) * 0.045, 0, 1);
        strike = Math.sin(sp * Math.PI) * 2.3;
      }
      bone.rotation.x = base + wave + strike;
      bone.rotation.z = waveZ;
    }
  }
  if (k.strikeT >= 0) {
    k.strikeT += dt / 0.55;
    if (k.strikeT > 1) k.strikeT = -1;
  }
}

// ─────────────── التحريك الإجرائي ───────────────
export function animateRig(rig: Rig, s: RigState, dt: number, t: number) {
  const K = 13;
  const P = (g: THREE.Group, x: number, y: number, z: number) => {
    g.rotation.x = damp(g.rotation.x, x, K, dt);
    g.rotation.y = damp(g.rotation.y, y, K, dt);
    g.rotation.z = damp(g.rotation.z, z, K, dt);
  };
  // وميض الإصابة
  if (rig.flashT > 0) {
    rig.flashT -= dt;
    const f = Math.max(0, rig.flashT * 5);
    rig.allMats.forEach((m) => { m.emissive.setHex(0xff3344); m.emissiveIntensity = f; });
  }

  if (s.dead > 0) {
    rig.root.rotation.x = damp(rig.root.rotation.x, -Math.PI / 2, 4, dt);
    rig.hips.position.y = damp(rig.hips.position.y, 0.45, 4, dt);
    return;
  }
  rig.root.rotation.x = damp(rig.root.rotation.x, 0, 6, dt);

  const mv = s.mv;
  let hipY = 0.98;
  // مشي/ركض
  if (mv > 0.03 && s.grounded && !s.attack) {
    rig.animPhase += dt * (5 + mv * 7);
    const sw = Math.sin(rig.animPhase) * 0.72 * mv;
    P(rig.legL, sw, 0, 0.04); P(rig.legR, -sw, 0, -0.04);
    P(rig.shinL, 0.18 * mv + Math.max(0, -Math.sin(rig.animPhase)) * 0.95 * mv, 0, 0);
    P(rig.shinR, 0.18 * mv + Math.max(0, Math.sin(rig.animPhase)) * 0.95 * mv, 0, 0);
    P(rig.armL, -sw * 0.55, 0, 0.1); P(rig.armR, sw * 0.55, 0, -0.1);
    P(rig.foreL, -0.25 * mv, 0, 0); P(rig.foreR, -0.25 * mv, 0, 0);
    P(rig.spine, (s.run ? 0.24 : 0.07) * mv + (s.kagune ? 0.14 : 0), Math.sin(rig.animPhase) * 0.06 * mv, 0);
    P(rig.head, -(s.run ? 0.12 : 0.02) * mv, 0, 0);
    hipY -= Math.abs(Math.cos(rig.animPhase)) * 0.045 * mv;
  } else if (s.grounded && !s.attack) {
    P(rig.legL, 0, 0, 0.05); P(rig.legR, 0, 0, -0.05);
    P(rig.shinL, 0.06, 0, 0); P(rig.shinR, 0.06, 0, 0);
    const br = Math.sin(t * 1.7) * 0.025;
    P(rig.spine, br + (s.kagune ? 0.2 : 0), 0, 0);
    P(rig.armL, 0.06, 0, s.kagune ? 0.42 : 0.14); P(rig.armR, 0.06, 0, s.kagune ? -0.42 : -0.14);
    P(rig.foreL, s.kagune ? -0.5 : -0.12, 0, 0); P(rig.foreR, s.kagune ? -0.5 : -0.12, 0, 0);
    P(rig.head, Math.sin(t * 0.9) * 0.03 - (s.kagune ? 0.12 : 0), Math.sin(t * 0.5) * 0.05, 0);
  }
  if (!s.grounded && !s.climbing) {
    if (s.vy > 1) {
      P(rig.legL, -0.55, 0, 0.1); P(rig.shinL, 1.0, 0, 0);
      P(rig.legR, 0.35, 0, -0.1); P(rig.shinR, 0.55, 0, 0);
      P(rig.armL, -0.8, 0, 0.35); P(rig.armR, -0.8, 0, -0.35);
    } else {
      P(rig.legL, 0.4, 0, 0.08); P(rig.shinL, 0.7, 0, 0);
      P(rig.legR, -0.25, 0, -0.08); P(rig.shinR, 0.35, 0, 0);
      P(rig.armL, -0.35, 0, 0.5); P(rig.armR, -0.35, 0, -0.5);
    }
    P(rig.spine, 0.12, 0, 0);
  }
  if (s.climbing) {
    rig.climbPhase += dt * 7;
    const cp = rig.climbPhase;
    P(rig.armL, -2.8 + Math.sin(cp) * 0.55, 0, 0.25);
    P(rig.armR, -2.8 + Math.sin(cp + Math.PI) * 0.55, 0, -0.25);
    P(rig.foreL, -0.5, 0, 0); P(rig.foreR, -0.5, 0, 0);
    P(rig.legL, 0.6 + Math.sin(cp + Math.PI) * 0.5, 0, 0.15);
    P(rig.legR, 0.6 + Math.sin(cp) * 0.5, 0, -0.15);
    P(rig.shinL, 0.9, 0, 0); P(rig.shinR, 0.9, 0, 0);
    P(rig.spine, 0.22, 0, 0);
    P(rig.head, -0.35, 0, 0);
    hipY = 0.98;
  }
  if (s.block) {
    P(rig.armR, -1.45, 0, -0.3); P(rig.foreR, -1.35, 0, 0);
    P(rig.armL, -1.1, 0, 0.3); P(rig.foreL, -1.5, 0, 0);
    P(rig.spine, 0.14, 0, 0);
  }
  if (s.attack) {
    const p = s.attack.p, w = Math.sin(Math.min(p, 1) * Math.PI);
    const kind = s.attack.kind;
    if (kind === "l0") {
      P(rig.armR, -1.9 * w + 0.15, 0, -1.1 * w);
      P(rig.foreR, -0.7 * w, 0, 0); P(rig.spine, 0.06, -0.55 * w, 0);
    } else if (kind === "l1") {
      P(rig.armL, -1.9 * w + 0.15, 0, 1.1 * w);
      P(rig.foreL, -0.7 * w, 0, 0); P(rig.spine, 0.06, 0.55 * w, 0);
    } else if (kind === "l2") {
      P(rig.spine, 0.1, Math.sin(p * Math.PI) * 2.4, 0);
      P(rig.armR, -0.6 * w, 0, -1.3 * w); P(rig.armL, -0.6 * w, 0, 1.3 * w);
    } else if (kind === "heavy") {
      if (p < 0.45) {
        const q = p / 0.45;
        P(rig.armR, -2.9 * q, 0, -0.25 * q); P(rig.armL, -2.9 * q, 0, 0.25 * q);
        P(rig.foreR, -0.3 * q, 0, 0); P(rig.foreL, -0.3 * q, 0, 0);
        P(rig.spine, -0.3 * q, 0, 0);
      } else {
        const q = (p - 0.45) / 0.55, e = q * q;
        P(rig.armR, lerp(-2.9, 1.15, e), 0, 0); P(rig.armL, lerp(-2.9, 1.15, e), 0, 0);
        P(rig.foreR, -0.35, 0, 0); P(rig.foreL, -0.35, 0, 0);
        P(rig.spine, lerp(-0.3, 0.5, e), 0, 0);
      }
    } else if (kind === "kagune") {
      P(rig.armR, -0.5 * w, 0, -1.0 * w); P(rig.armL, -0.5 * w, 0, 1.0 * w);
      P(rig.spine, 0.16 * w, 0, 0);
    } else if (kind === "skill") {
      P(rig.armR, -1.5 * w, 0, -0.2); P(rig.foreR, -0.5 * w, 0, 0);
      P(rig.spine, 0.2 * w, 0, 0);
    }
  }
  if (s.flinch > 0) {
    rig.spine.rotation.x -= 0.45 * s.flinch;
    rig.head.rotation.x -= 0.4 * s.flinch;
  }
  if (s.kagune && !s.climbing) hipY -= 0.05;
  rig.hips.position.y = damp(rig.hips.position.y, hipY, K, dt);
}
