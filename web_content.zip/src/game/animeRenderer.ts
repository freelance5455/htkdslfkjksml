import {
  BossDef,
  GameItemDef,
  GraphicsQuality,
  HazardDef,
  HeroDef,
  WorldDef,
} from '../types/game';

export type HeroAnimState =
  | 'idle'
  | 'run'
  | 'jump'
  | 'dash'
  | 'attack'
  | 'hurt'
  | 'celebrate'
  | 'skill';

export interface HeroRenderParams {
  x: number;
  y: number; // feet position
  facing: 1 | -1;
  animState: HeroAnimState;
  animTime: number;
  comboStage: 1 | 2 | 3;
  attackProgress: number; // 0..1
  vx: number;
  vy: number;
  hero: HeroDef;
  outfit?: GameItemDef;
  pet?: GameItemDef;
  cosmetic?: GameItemDef;
  invulnFlash: boolean;
  graphics: GraphicsQuality;
}

export function drawParallaxWorld(
  ctx: CanvasRenderingContext2D,
  world: WorldDef,
  camX: number,
  width: number,
  height: number,
  time: number,
  graphics: GraphicsQuality
) {
  // 1. Sky Gradient
  const skyGrad = ctx.createLinearGradient(0, 0, 0, height);
  skyGrad.addColorStop(0, world.skyTop);
  skyGrad.addColorStop(1, world.skyBottom);
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, height);

  // 2. Celestial / Sky Focal Object
  ctx.save();
  if (world.id === 1) {
    // Enchanted Moon
    const mx = width * 0.78 - camX * 0.03;
    const my = 95;
    const moonGlow = ctx.createRadialGradient(mx, my, 12, mx, my, 95);
    moonGlow.addColorStop(0, 'rgba(209, 250, 229, 0.9)');
    moonGlow.addColorStop(0.4, 'rgba(52, 211, 153, 0.25)');
    moonGlow.addColorStop(1, 'rgba(16, 185, 129, 0)');
    ctx.fillStyle = moonGlow;
    ctx.beginPath();
    ctx.arc(mx, my, 95, 0, Math.PI * 2);
    ctx.fill();
  } else if (world.id === 2) {
    // Cyber Hologram Ring
    const mx = width * 0.75 - camX * 0.04;
    ctx.strokeStyle = 'rgba(34, 211, 238, 0.25)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(mx, 110, 62, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(mx, 110, 44, time * 0.6, time * 0.6 + Math.PI * 1.4);
    ctx.stroke();
  } else if (world.id === 3) {
    // Aurora Borealis Wave
    const aurGrad = ctx.createLinearGradient(0, 30, 0, 190);
    aurGrad.addColorStop(0, 'rgba(52, 211, 153, 0)');
    aurGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.22)');
    aurGrad.addColorStop(1, 'rgba(139, 92, 246, 0)');
    ctx.fillStyle = aurGrad;
    ctx.beginPath();
    ctx.moveTo(0, 130);
    for (let x = 0; x <= width; x += 60) {
      ctx.lineTo(x, 100 + Math.sin(x * 0.008 + time * 1.1) * 28);
    }
    ctx.lineTo(width, 210);
    ctx.lineTo(0, 210);
    ctx.closePath();
    ctx.fill();
  } else if (world.id === 4) {
    // Volcanic Sunset Glow
    const sunGlow = ctx.createRadialGradient(width * 0.7, 130, 10, width * 0.7, 130, 140);
    sunGlow.addColorStop(0, 'rgba(251, 146, 60, 0.65)');
    sunGlow.addColorStop(1, 'rgba(124, 45, 18, 0)');
    ctx.fillStyle = sunGlow;
    ctx.fillRect(0, 0, width, 280);
  } else if (world.id === 5) {
    // Crimson Blood Eclipse Moon
    const mx = width * 0.76 - camX * 0.03;
    const my = 105;
    ctx.fillStyle = 'rgba(225, 29, 72, 0.32)';
    ctx.beginPath();
    ctx.arc(mx, my, 74, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#1a0626';
    ctx.beginPath();
    ctx.arc(mx, my, 52, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#f43f5e';
    ctx.lineWidth = 3;
    ctx.stroke();
  } else if (world.id === 6) {
    // Celestial Golden Astrolabe & Infinity Ring
    const mx = width * 0.5;
    const my = 135;
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.26)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(mx, my, 105, time * 0.3, time * 0.3 + Math.PI * 1.6);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(192, 132, 252, 0.25)';
    ctx.beginPath();
    ctx.arc(mx, my, 75, -time * 0.5, -time * 0.5 + Math.PI * 1.5);
    ctx.stroke();
  }
  ctx.restore();

  // 3. Far Parallax Silhouette Layer (All graphics settings)
  const farOffset = -(camX * 0.14) % 320;
  ctx.fillStyle = 'rgba(8, 10, 26, 0.48)';
  for (let x = farOffset - 320; x < width + 320; x += 320) {
    ctx.beginPath();
    ctx.moveTo(x, height);
    if (world.id === 2) {
      // Cyber skyscrapers
      ctx.lineTo(x, 220);
      ctx.lineTo(x + 70, 220);
      ctx.lineTo(x + 70, 165);
      ctx.lineTo(x + 150, 165);
      ctx.lineTo(x + 150, 250);
      ctx.lineTo(x + 240, 250);
      ctx.lineTo(x + 240, 190);
      ctx.lineTo(x + 320, 190);
    } else if (world.id === 5) {
      // Gothic Castle Spires
      ctx.lineTo(x, 260);
      ctx.lineTo(x + 60, 150);
      ctx.lineTo(x + 120, 260);
      ctx.lineTo(x + 200, 125);
      ctx.lineTo(x + 270, 260);
      ctx.lineTo(x + 320, 240);
    } else {
      // Mountains / Canopy Peaks
      ctx.lineTo(x, 270);
      ctx.lineTo(x + 110, 165);
      ctx.lineTo(x + 210, 245);
      ctx.lineTo(x + 280, 185);
      ctx.lineTo(x + 320, 270);
    }
    ctx.lineTo(x + 320, height);
    ctx.closePath();
    ctx.fill();
  }

  // 4. Midground Detailed Parallax Layer (Medium, High, Maximum)
  if (graphics !== 'low') {
    const midOffset = -(camX * 0.32) % 260;
    for (let x = midOffset - 260; x < width + 260; x += 260) {
      if (world.id === 1) {
        // Ancient Rune Trees
        ctx.fillStyle = 'rgba(10, 38, 32, 0.72)';
        ctx.fillRect(x + 65, 160, 34, 300);
        ctx.beginPath();
        ctx.arc(x + 82, 155, 68, 0, Math.PI * 2);
        ctx.fill();
        // Glowing rune on trunk
        ctx.fillStyle = 'rgba(52, 211, 153, 0.35)';
        ctx.fillRect(x + 79, 250, 6, 22);
      } else if (world.id === 2) {
        // Neon Towers with glowing windows
        ctx.fillStyle = 'rgba(15, 18, 42, 0.8)';
        ctx.fillRect(x + 40, 195, 95, 290);
        ctx.fillStyle = 'rgba(34, 211, 238, 0.35)';
        ctx.fillRect(x + 52, 215, 70, 4);
        ctx.fillStyle = 'rgba(192, 132, 252, 0.35)';
        ctx.fillRect(x + 52, 245, 48, 4);
      } else if (world.id === 3) {
        // Ice Crystal Pillars
        ctx.fillStyle = 'rgba(30, 64, 110, 0.55)';
        ctx.beginPath();
        ctx.moveTo(x + 40, 450);
        ctx.lineTo(x + 85, 190);
        ctx.lineTo(x + 130, 450);
        ctx.closePath();
        ctx.fill();
      } else if (world.id === 4) {
        // Volcano Crags with magma vein
        ctx.fillStyle = 'rgba(38, 16, 16, 0.8)';
        ctx.beginPath();
        ctx.moveTo(x + 20, 450);
        ctx.lineTo(x + 95, 210);
        ctx.lineTo(x + 180, 450);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(249, 115, 22, 0.45)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(x + 95, 230);
        ctx.lineTo(x + 108, 360);
        ctx.stroke();
      } else if (world.id === 5) {
        // Cathedral Arches
        ctx.fillStyle = 'rgba(25, 12, 44, 0.78)';
        ctx.fillRect(x + 50, 175, 42, 280);
        ctx.fillStyle = 'rgba(192, 132, 252, 0.25)';
        ctx.beginPath();
        ctx.arc(x + 71, 235, 11, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Celestial Floating Crystal Obelisks
        const bob = Math.sin(time * 1.5 + x) * 8;
        ctx.fillStyle = 'rgba(46, 26, 94, 0.65)';
        ctx.beginPath();
        ctx.moveTo(x + 85, 180 + bob);
        ctx.lineTo(x + 115, 250 + bob);
        ctx.lineTo(x + 85, 330 + bob);
        ctx.lineTo(x + 55, 250 + bob);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(251, 191, 36, 0.4)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
    }
  }
}

export function drawWorldPlatformsAndProps(
  ctx: CanvasRenderingContext2D,
  world: WorldDef,
  camX: number,
  width: number,
  time: number,
  checkpointActivated: boolean,
  secretOpened: boolean
) {
  // Platforms
  for (const p of world.platforms) {
    if (p.x + p.w < camX - 60 || p.x > camX + width + 60) continue;
    const sx = p.x - camX;

    ctx.save();
    if (p.style === 'ground') {
      const grad = ctx.createLinearGradient(0, p.y, 0, p.y + p.h);
      grad.addColorStop(0, world.groundColor);
      grad.addColorStop(1, '#070510');
      ctx.fillStyle = grad;
      ctx.fillRect(sx, p.y, p.w, p.h);

      // Luminous Top Trim
      ctx.fillStyle = world.groundTrim;
      ctx.fillRect(sx, p.y, p.w, 5);

      // Subtle Stone / Tech Grid Details
      ctx.fillStyle = 'rgba(255,255,255,0.05)';
      for (let rx = 20; rx < p.w - 30; rx += 75) {
        ctx.fillRect(sx + rx, p.y + 14, 34, 8);
      }
    } else {
      // Floating / Secret / Bridge Ledge
      const isSecret = p.style === 'secret';
      ctx.fillStyle = isSecret ? '#3b1d5e' : world.groundColor;
      ctx.beginPath();
      ctx.roundRect(sx, p.y, p.w, p.h, 6);
      ctx.fill();

      ctx.fillStyle = isSecret ? '#fbbf24' : world.groundTrim;
      ctx.fillRect(sx + 3, p.y, p.w - 6, 4);
    }
    ctx.restore();
  }

  // Checkpoint Shrine
  const cpScreenX = world.checkpointX - camX;
  if (cpScreenX > -80 && cpScreenX < width + 80) {
    ctx.save();
    const cpY = world.checkpointY;
    // Stone pedestal
    ctx.fillStyle = '#334155';
    ctx.fillRect(cpScreenX - 18, cpY - 12, 36, 12);
    ctx.fillRect(cpScreenX - 10, cpY - 56, 20, 44);
    // Floating Rune Crystal
    const pulse = Math.sin(time * 4) * 4;
    const crystalColor = checkpointActivated ? '#fbbf24' : '#64748b';
    ctx.fillStyle = crystalColor;
    ctx.shadowColor = checkpointActivated ? '#f59e0b' : 'transparent';
    ctx.shadowBlur = checkpointActivated ? 18 : 0;
    ctx.beginPath();
    ctx.moveTo(cpScreenX, cpY - 84 + pulse);
    ctx.lineTo(cpScreenX + 11, cpY - 68 + pulse);
    ctx.lineTo(cpScreenX, cpY - 52 + pulse);
    ctx.lineTo(cpScreenX - 11, cpY - 68 + pulse);
    ctx.closePath();
    ctx.fill();

    ctx.shadowBlur = 0;
    ctx.font = 'bold 10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = checkpointActivated ? '#fde68a' : '#cbd5e1';
    ctx.fillText(checkpointActivated ? 'CHECKPOINT SAVED' : 'CHECKPOINT', cpScreenX, cpY - 94);
    ctx.restore();
  }

  // Secret Treasure Chest
  const chX = world.secretChest.x - camX;
  const chY = world.secretChest.y;
  if (chX > -80 && chX < width + 80) {
    ctx.save();
    ctx.fillStyle = secretOpened ? '#475569' : '#b45309';
    ctx.strokeStyle = '#fde047';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(chX - 18, chY - 26, 36, 26, 5);
    ctx.fill();
    ctx.stroke();

    if (!secretOpened) {
      ctx.fillStyle = '#fde047';
      ctx.fillRect(chX - 4, chY - 16, 8, 8);
      // Sparkle indicator
      const sp = Math.sin(time * 5) * 3;
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('✦ SECRET RELIC ✦', chX, chY - 34 + sp);
    }
    ctx.restore();
  }

  // Boss Gate Portal Marker
  const gateX = world.bossArenaStartX - camX;
  if (gateX > -80 && gateX < width + 80) {
    ctx.save();
    ctx.strokeStyle = world.accentColor;
    ctx.lineWidth = 3;
    ctx.globalAlpha = 0.65;
    ctx.beginPath();
    ctx.moveTo(gateX, 430);
    ctx.lineTo(gateX, 290);
    ctx.stroke();

    ctx.fillStyle = world.accentColor;
    ctx.beginPath();
    ctx.arc(gateX, 284, 8 + Math.sin(time * 4) * 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

export function drawHazards(
  ctx: CanvasRenderingContext2D,
  hazards: HazardDef[],
  camX: number,
  width: number,
  time: number
) {
  for (const h of hazards) {
    if (h.x + h.w < camX - 40 || h.x > camX + width + 40) continue;
    const sx = h.x - camX;
    // Periodic hazards cycle: 2.2s safe -> 1.0s warning -> 1.4s active!
    const cycle = time % 4.6;
    const isWarning = h.periodic ? cycle >= 2.2 && cycle < 3.2 : false;
    const isActive = h.periodic ? cycle >= 3.2 : true;

    ctx.save();
    if (isWarning) {
      ctx.fillStyle = 'rgba(251, 191, 36, 0.35)';
      ctx.fillRect(sx, h.y - 16, h.w, h.h + 16);
      ctx.fillStyle = '#fde047';
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('! CAUTION !', sx + h.w / 2, h.y - 6);
    }

    if (h.type === 'thorns' || h.type === 'icicles' || h.type === 'void_spikes') {
      ctx.fillStyle =
        h.type === 'thorns' ? '#10b981' : h.type === 'icicles' ? '#7dd3fc' : '#c084fc';
      const spikes = Math.max(3, Math.floor(h.w / 14));
      const sw = h.w / spikes;
      for (let i = 0; i < spikes; i++) {
        ctx.beginPath();
        ctx.moveTo(sx + i * sw, h.y + h.h);
        ctx.lineTo(sx + i * sw + sw * 0.5, h.y);
        ctx.lineTo(sx + (i + 1) * sw, h.y + h.h);
        ctx.closePath();
        ctx.fill();
      }
    } else {
      // Periodic energy/lava/arc hazard
      ctx.fillStyle = '#334155';
      ctx.fillRect(sx, h.y + h.h - 6, h.w, 6);
      if (isActive) {
        const col =
          h.type === 'electric_arc'
            ? '#22d3ee'
            : h.type === 'lava_geyser'
            ? '#f97316'
            : '#e879f9';
        ctx.fillStyle = col;
        ctx.globalAlpha = 0.85;
        const jetH = h.type === 'lava_geyser' ? 52 : 28;
        ctx.beginPath();
        ctx.roundRect(sx + 4, h.y + h.h - jetH, h.w - 8, jetH, 6);
        ctx.fill();
      }
    }
    ctx.restore();
  }
}

export function isPeriodicHazardActive(h: HazardDef, time: number): boolean {
  if (!h.periodic) return true;
  const cycle = time % 4.6;
  return cycle >= 3.2;
}

// ============================================================================
// ARTICULATED 2D ANIME HERO CHARACTER RENDERER
// ============================================================================
export function drawAnimeHero(ctx: CanvasRenderingContext2D, p: HeroRenderParams) {
  const {
    x,
    y,
    facing,
    animState,
    animTime,
    comboStage,
    attackProgress,
    hero,
    outfit,
    pet,
    cosmetic,
    invulnFlash,
    graphics,
  } = p;

  const pal = hero.palette;
  const coatPrimary = outfit?.outfitColors?.coatPrimary || pal.coatPrimary;
  const coatSecondary = outfit?.outfitColors?.coatSecondary || pal.coatSecondary;
  const scarfColor = outfit?.outfitColors?.scarfColor || pal.scarfColor;
  const trimGold = outfit?.outfitColors?.trimGold || pal.trimGold;

  // 1. Companion Pet (Floats behind hero!)
  if (pet?.petVisual) {
    drawCompanionPet(ctx, x - facing * 38, y - 48, animTime, facing, pet);
  }

  // 2. Cosmetic Ground / Body Aura
  if (cosmetic?.auraStyle) {
    drawCosmeticAura(ctx, x, y, animTime, cosmetic.auraStyle, graphics);
  }

  if (invulnFlash && Math.floor(animTime * 20) % 2 === 0) {
    ctx.save();
    ctx.globalAlpha = 0.45;
  } else {
    ctx.save();
  }

  // Ground soft shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.36)';
  ctx.beginPath();
  ctx.ellipse(x, y, 18, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  // Compute Rig Kinematics across all 8 animation states
  let bodyBob = 0;
  let bodyTilt = 0;
  let frontLegAngle = 0;
  let backLegAngle = 0;
  let frontArmAngle = 0.25;
  let backArmAngle = -0.2;

  if (animState === 'idle') {
    bodyBob = Math.sin(animTime * 3.4) * 2;
    frontArmAngle = 0.2 + Math.sin(animTime * 3.4) * 0.06;
    backArmAngle = -0.18 - Math.sin(animTime * 3.4) * 0.05;
  } else if (animState === 'run') {
    const stride = animTime * 13;
    bodyBob = Math.abs(Math.sin(stride)) * -3.5;
    bodyTilt = 0.16;
    frontLegAngle = Math.sin(stride) * 0.68;
    backLegAngle = -Math.sin(stride) * 0.68;
    frontArmAngle = -Math.sin(stride) * 0.55;
    backArmAngle = Math.sin(stride) * 0.55;
  } else if (animState === 'jump') {
    bodyTilt = 0.08;
    frontLegAngle = -0.45;
    backLegAngle = 0.35;
    frontArmAngle = -0.5;
    backArmAngle = -0.35;
  } else if (animState === 'dash') {
    bodyTilt = 0.42;
    bodyBob = 4;
    frontLegAngle = -0.55;
    backLegAngle = 0.72;
    frontArmAngle = -0.9;
    backArmAngle = 0.7;
  } else if (animState === 'attack') {
    bodyTilt = 0.22;
    frontLegAngle = 0.42;
    backLegAngle = -0.38;
    if (comboStage === 1) {
      // Overhead downward crescent slash
      frontArmAngle = -1.6 + attackProgress * 2.7;
    } else if (comboStage === 2) {
      // Rising upward cross slash
      frontArmAngle = 1.2 - attackProgress * 2.6;
    } else {
      // 360 Finisher sweep
      frontArmAngle = -1.9 + attackProgress * 3.4;
      bodyBob = -4 * Math.sin(attackProgress * Math.PI);
    }
  } else if (animState === 'skill') {
    bodyBob = -6;
    bodyTilt = -0.08;
    frontArmAngle = -1.35;
    backArmAngle = -0.85;
    frontLegAngle = -0.2;
    backLegAngle = 0.25;
  } else if (animState === 'hurt') {
    bodyTilt = -0.26;
    bodyBob = 2;
    frontArmAngle = -0.6;
    backArmAngle = -0.4;
  } else if (animState === 'celebrate') {
    bodyBob = -Math.abs(Math.sin(animTime * 6)) * 5;
    frontArmAngle = -2.25; // Raising weapon skyward!
    backArmAngle = 0.45;
  }

  ctx.translate(x, y + bodyBob);
  ctx.scale(facing, 1);
  ctx.rotate(bodyTilt);

  // Skill Casting Magic Circle Under Hero
  if (animState === 'skill') {
    ctx.save();
    ctx.strokeStyle = pal.weaponGlow;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.ellipse(0, 2, 32, 9, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  // Mythic Golden Infinity Halo (Aetherion)
  if (pal.hasInfinityHalo) {
    ctx.save();
    ctx.translate(-4, -46);
    ctx.strokeStyle = '#fde047';
    ctx.shadowColor = '#f59e0b';
    ctx.shadowBlur = graphics === 'low' ? 0 : 12;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    for (let t = 0; t <= Math.PI * 2; t += 0.15) {
      const denom = 1 + Math.sin(t) * Math.sin(t);
      const ix = (20 * Math.cos(t)) / denom;
      const iy = (16 * Math.sin(t) * Math.cos(t)) / denom;
      if (t === 0) ctx.moveTo(ix, iy);
      else ctx.lineTo(ix, iy);
    }
    ctx.closePath();
    ctx.stroke();
    ctx.restore();
  }

  // Flowing Anime Scarf / Cape Ribbon (behind torso)
  ctx.save();
  ctx.fillStyle = scarfColor;
  const wave1 = Math.sin(animTime * 9) * 5;
  const wave2 = Math.cos(animTime * 9) * 7;
  const capeLen = animState === 'run' || animState === 'dash' ? 34 : 24;
  ctx.beginPath();
  ctx.moveTo(-4, -39);
  ctx.quadraticCurveTo(-18, -36 + wave1, -capeLen, -24 + wave2);
  ctx.lineTo(-capeLen + 4, -15 + wave2);
  ctx.quadraticCurveTo(-14, -26 + wave1, -2, -31);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // Long Back Hair Layer (for flowing hairstyles before torso)
  if (pal.hairStyle === 'flowing_empress' || pal.hairStyle === 'astral_sovereign') {
    ctx.save();
    ctx.fillStyle = pal.hairMain;
    const hWave = Math.sin(animTime * 6) * 4;
    ctx.beginPath();
    ctx.moveTo(-8, -52);
    ctx.quadraticCurveTo(-22, -36 + hWave, -17, -18 + hWave);
    ctx.lineTo(-4, -22);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  } else if (pal.hairStyle === 'elven_braid') {
    ctx.save();
    ctx.strokeStyle = pal.hairMain;
    ctx.lineWidth = 5;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-7, -48);
    ctx.quadraticCurveTo(-18, -35, -15 + Math.sin(animTime * 7) * 4, -22);
    ctx.stroke();
    ctx.restore();
  }

  // Back Arm (and secondary plasma blade for Akari!)
  ctx.save();
  ctx.translate(-3, -36);
  ctx.rotate(backArmAngle);
  ctx.fillStyle = coatSecondary;
  ctx.beginPath();
  ctx.roundRect(-3, 0, 6, 15, 3);
  ctx.fill();
  ctx.fillStyle = pal.skinTone;
  ctx.beginPath();
  ctx.arc(0, 16, 3, 0, Math.PI * 2);
  ctx.fill();
  if (pal.weaponType === 'dual_plasma') {
    ctx.fillStyle = pal.weaponGlow;
    ctx.fillRect(-2, 14, 18, 3.5);
  }
  ctx.restore();

  // Back Leg
  drawAnimeLeg(ctx, -3, -20, backLegAngle, coatSecondary, coatPrimary, trimGold);

  // Front Leg
  drawAnimeLeg(ctx, 3, -20, frontLegAngle, coatPrimary, coatSecondary, trimGold);

  // Anime Torso Coat & Battle Armor
  ctx.save();
  // Coat tails
  ctx.fillStyle = coatPrimary;
  ctx.beginPath();
  ctx.moveTo(-9, -23);
  ctx.lineTo(-13, -10);
  ctx.lineTo(1, -13);
  ctx.lineTo(10, -11);
  ctx.lineTo(8, -23);
  ctx.closePath();
  ctx.fill();

  // Main upper tunic/breastplate
  ctx.fillStyle = coatPrimary;
  ctx.beginPath();
  ctx.roundRect(-8, -40, 17, 20, 4);
  ctx.fill();

  // Inner chest plate / lapel accent
  ctx.fillStyle = coatSecondary;
  ctx.beginPath();
  ctx.moveTo(-3, -40);
  ctx.lineTo(6, -40);
  ctx.lineTo(4, -23);
  ctx.lineTo(-4, -23);
  ctx.closePath();
  ctx.fill();

  // Belt & Golden Buckle
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(-8, -23, 17, 4);
  ctx.fillStyle = trimGold;
  ctx.fillRect(-1, -23, 5, 4);

  // Collar / Scarf wrap
  ctx.fillStyle = scarfColor;
  ctx.beginPath();
  ctx.roundRect(-7, -42, 15, 5, 2.5);
  ctx.fill();
  ctx.restore();

  // =========================================================================
  // ANIME HEAD, EXPRESSIVE EYES, FACE & HAIRSTYLE
  // =========================================================================
  ctx.save();
  ctx.translate(1, -51);

  // Head base with sculpted anime chin
  ctx.fillStyle = pal.skinTone;
  ctx.beginPath();
  ctx.arc(0, 0, 10.5, 0, Math.PI * 2);
  ctx.fill();

  // Pointed Elven Ear (Lyra)
  if (pal.hasElfEars) {
    ctx.fillStyle = pal.skinTone;
    ctx.beginPath();
    ctx.moveTo(-6, -1);
    ctx.lineTo(-15, -4);
    ctx.lineTo(-7, 4);
    ctx.closePath();
    ctx.fill();
  }

  // Expressive Anime Eye (Side-three-quarter view facing right)
  const isBlinking = animState === 'idle' && Math.sin(animTime * 1.9) > 0.96;
  if (animState === 'hurt') {
    // Wincing >< anime eye
    ctx.strokeStyle = '#1e1b4b';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(2, -2.5);
    ctx.lineTo(6.5, -0.5);
    ctx.lineTo(2, 1.5);
    ctx.stroke();
  } else if (animState === 'celebrate' || isBlinking) {
    // Happy curved ^^ eye / blink
    ctx.strokeStyle = '#1e1b4b';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.arc(4.5, 0, 2.8, Math.PI, 0, false);
    ctx.stroke();
  } else {
    // Full Detailed Anime Eye: Sclera + Colored Iris + Dark Pupil + Starlight Catchlights!
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.ellipse(4.8, -0.4, 3.3, 3.6, 0, 0, Math.PI * 2);
    ctx.fill();

    // Iris
    ctx.fillStyle = pal.eyeColor;
    ctx.beginPath();
    ctx.ellipse(5.3, -0.3, 2.3, 3.1, 0, 0, Math.PI * 2);
    ctx.fill();

    // Pupil
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(5.5, -0.2, 1.2, 0, Math.PI * 2);
    ctx.fill();

    // Upper Eyelash line
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(1.5, -2.8);
    ctx.quadraticCurveTo(5.0, -4.4, 8.2, -2.2);
    ctx.stroke();

    // Dual White Specular Catchlights!
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(4.4, -1.6, 1.0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(6.3, 1.1, 0.55, 0, Math.PI * 2);
    ctx.fill();

    // Expressive Eyebrow
    ctx.strokeStyle = pal.hairMain;
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    if (animState === 'attack' || animState === 'skill' || animState === 'dash') {
      ctx.moveTo(2.0, -5.6);
      ctx.lineTo(7.8, -4.2);
    } else {
      ctx.moveTo(2.0, -5.2);
      ctx.lineTo(7.5, -5.2);
    }
    ctx.stroke();
  }

  // Mouth Expression
  ctx.strokeStyle = '#9f1239';
  ctx.lineWidth = 1.1;
  ctx.beginPath();
  if (animState === 'attack' || animState === 'skill') {
    ctx.fillStyle = '#be123c';
    ctx.arc(6.2, 4.8, 1.6, 0, Math.PI * 2);
    ctx.fill();
  } else if (animState === 'celebrate') {
    ctx.arc(5.8, 4.2, 2.0, 0.1, Math.PI - 0.1, false);
    ctx.stroke();
  } else {
    ctx.moveTo(4.8, 5.0);
    ctx.lineTo(7.4, 4.7);
    ctx.stroke();
  }

  // Sculpted Anime Hair Crown, Bangs & Side-locks
  drawAnimeHairCrown(ctx, pal.hairMain, pal.hairTip, pal.hairStyle);

  // Accessories: Tiara (Seraphina) or Cyber Visor Clip (Akari)
  if (pal.hasTiara) {
    ctx.fillStyle = '#e0f2fe';
    ctx.beginPath();
    ctx.moveTo(2, -10);
    ctx.lineTo(6, -17);
    ctx.lineTo(8, -9);
    ctx.closePath();
    ctx.fill();
  }
  if (pal.hasCyberVisor) {
    ctx.fillStyle = '#22d3ee';
    ctx.fillRect(1, -8, 9, 2.5);
  }

  ctx.restore(); // end head

  // =========================================================================
  // FRONT ARM & SIGNATURE ANIME WEAPON
  // =========================================================================
  ctx.save();
  ctx.translate(2, -36);
  ctx.rotate(frontArmAngle);

  // Pauldron shoulder guard
  ctx.fillStyle = trimGold;
  ctx.beginPath();
  ctx.arc(0, 0, 4.5, Math.PI, 0);
  ctx.fill();

  // Arm sleeve
  ctx.fillStyle = coatPrimary;
  ctx.beginPath();
  ctx.roundRect(-3, 0, 6, 15, 3);
  ctx.fill();

  // Hand
  ctx.fillStyle = pal.skinTone;
  ctx.beginPath();
  ctx.arc(0, 16, 3.2, 0, Math.PI * 2);
  ctx.fill();

  // Weapon held in hand
  drawAnimeWeapon(
    ctx,
    0,
    16,
    pal.weaponType,
    pal.weaponCore,
    pal.weaponGlow,
    trimGold,
    animState === 'attack' || animState === 'skill',
    graphics
  );

  ctx.restore(); // end front arm

  ctx.restore(); // end hero transform
}

function drawAnimeLeg(
  ctx: CanvasRenderingContext2D,
  hipX: number,
  hipY: number,
  angle: number,
  thighColor: string,
  bootColor: string,
  trimColor: string
) {
  ctx.save();
  ctx.translate(hipX, hipY);
  ctx.rotate(angle);
  // Thigh
  ctx.fillStyle = thighColor;
  ctx.beginPath();
  ctx.roundRect(-3.2, 0, 6.4, 11, 2.5);
  ctx.fill();
  // Armored Boot / Greave
  ctx.fillStyle = bootColor;
  ctx.beginPath();
  ctx.roundRect(-3.2, 9, 6.8, 11, 2.5);
  ctx.fill();
  // Boot cuff trim
  ctx.fillStyle = trimColor;
  ctx.fillRect(-3.2, 9, 6.8, 2.2);
  // Foot toe
  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.roundRect(-3, 17, 9.5, 3.8, 2);
  ctx.fill();
  ctx.restore();
}

function drawAnimeHairCrown(
  ctx: CanvasRenderingContext2D,
  mainColor: string,
  tipColor: string,
  style: string
) {
  ctx.fillStyle = mainColor;
  // Upper hair dome
  ctx.beginPath();
  ctx.arc(-1, -3, 11.2, Math.PI * 0.95, Math.PI * 2.08);
  ctx.fill();

  // Front bangs sweeping across forehead
  ctx.beginPath();
  ctx.moveTo(-4, -12);
  ctx.lineTo(9, -9);
  ctx.lineTo(11, -2);
  ctx.lineTo(6, -5);
  ctx.lineTo(3, -1);
  ctx.lineTo(0, -6);
  ctx.closePath();
  ctx.fill();

  // Dynamic Back/Top Spikes based on hero archetype
  if (style === 'spiky_shinobi' || style === 'dragon_wild') {
    const spikeLen = style === 'dragon_wild' ? 18 : 14;
    ctx.beginPath();
    ctx.moveTo(-6, -12);
    ctx.lineTo(-spikeLen, -16);
    ctx.lineTo(-10, -6);
    ctx.lineTo(-spikeLen - 2, -7);
    ctx.lineTo(-9, 1);
    ctx.lineTo(-15, 6);
    ctx.lineTo(-4, 4);
    ctx.closePath();
    ctx.fill();

    // Colored anime hair tips
    ctx.fillStyle = tipColor;
    ctx.beginPath();
    ctx.moveTo(-spikeLen, -16);
    ctx.lineTo(-11, -13);
    ctx.lineTo(-12, -9);
    ctx.closePath();
    ctx.fill();
  } else if (style === 'cyber_bob') {
    // Sleek angled bob side-lock with neon cyan tip
    ctx.beginPath();
    ctx.moveTo(-9, -8);
    ctx.lineTo(-13, 6);
    ctx.lineTo(-3, 7);
    ctx.lineTo(-2, -6);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = tipColor;
    ctx.fillRect(-12, 3, 9, 3.5);
  } else {
    // Side hair framing cheek
    ctx.beginPath();
    ctx.moveTo(-10, -6);
    ctx.lineTo(-12, 7);
    ctx.lineTo(-5, 5);
    ctx.lineTo(-4, -5);
    ctx.closePath();
    ctx.fill();
  }
}

function drawAnimeWeapon(
  ctx: CanvasRenderingContext2D,
  hx: number,
  hy: number,
  type: string,
  coreColor: string,
  glowColor: string,
  trimGold: string,
  isGlowing: boolean,
  graphics: GraphicsQuality
) {
  ctx.save();
  ctx.translate(hx, hy);
  ctx.rotate(0.35);

  if (isGlowing && graphics !== 'low') {
    ctx.shadowColor = glowColor;
    ctx.shadowBlur = 12;
  }

  if (type === 'katana') {
    // Hilt & Tsuba
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(-7, -1.5, 8, 3);
    ctx.fillStyle = trimGold;
    ctx.fillRect(1, -4.5, 2.5, 9);
    // Curved Katana Blade
    ctx.fillStyle = coreColor;
    ctx.beginPath();
    ctx.moveTo(3.5, -1.8);
    ctx.quadraticCurveTo(22, -3.2, 36, -0.5);
    ctx.lineTo(32, 1.8);
    ctx.quadraticCurveTo(18, 0.5, 3.5, 1.5);
    ctx.closePath();
    ctx.fill();
  } else if (type === 'glaive' || type === 'frost_halberd') {
    // Long pole shaft
    ctx.fillStyle = '#334155';
    ctx.fillRect(-14, -1.5, 42, 3);
    // Sweeping Halberd / Glaive Crescent Head
    ctx.fillStyle = glowColor;
    ctx.beginPath();
    ctx.moveTo(24, -2);
    ctx.quadraticCurveTo(38, -10, 44, 0);
    ctx.quadraticCurveTo(36, 9, 24, 3);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = coreColor;
    ctx.fillRect(26, -1.2, 16, 2.4);
  } else if (type === 'dual_plasma') {
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(-4, -2, 8, 4);
    ctx.fillStyle = glowColor;
    ctx.beginPath();
    ctx.moveTo(4, -2.5);
    ctx.lineTo(28, -0.5);
    ctx.lineTo(24, 3);
    ctx.lineTo(4, 2.5);
    ctx.closePath();
    ctx.fill();
  } else if (type === 'phoenix_greatsword') {
    // Heavy Greatsword
    ctx.fillStyle = '#450a0a';
    ctx.fillRect(-9, -2, 10, 4);
    ctx.fillStyle = trimGold;
    ctx.fillRect(1, -7, 4, 14);
    ctx.fillStyle = glowColor;
    ctx.beginPath();
    ctx.moveTo(5, -4.8);
    ctx.lineTo(39, -2.5);
    ctx.lineTo(45, 0);
    ctx.lineTo(39, 2.5);
    ctx.lineTo(5, 4.8);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = coreColor;
    ctx.fillRect(6, -1.6, 33, 3.2);
  } else {
    // Mythic Dimensional Infinity Scythe-Lance
    ctx.fillStyle = '#1e1b4b';
    ctx.fillRect(-16, -1.8, 46, 3.6);
    ctx.strokeStyle = trimGold;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(28, 0, 5.5, 0, Math.PI * 2);
    ctx.stroke();
    // Curved Scythe Crescent
    ctx.fillStyle = glowColor;
    ctx.beginPath();
    ctx.moveTo(28, -2);
    ctx.quadraticCurveTo(38, -22, 16, -26);
    ctx.quadraticCurveTo(28, -14, 24, -2);
    ctx.closePath();
    ctx.fill();
    // Forward Lance Tip
    ctx.fillStyle = coreColor;
    ctx.beginPath();
    ctx.moveTo(31, -2.5);
    ctx.lineTo(47, 0);
    ctx.lineTo(31, 2.5);
    ctx.closePath();
    ctx.fill();
  }

  ctx.restore();
}

function drawCompanionPet(
  ctx: CanvasRenderingContext2D,
  px: number,
  py: number,
  time: number,
  facing: 1 | -1,
  pet: GameItemDef
) {
  const vis = pet.petVisual;
  if (!vis) return;
  const bob = Math.sin(time * 4.5) * 5;
  ctx.save();
  ctx.translate(px, py + bob);
  ctx.scale(facing, 1);

  // Soft spirit glow
  ctx.fillStyle = vis.glowColor;
  ctx.globalAlpha = 0.28;
  ctx.beginPath();
  ctx.arc(0, 0, 13, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;

  // Cute Anime Spirit Pet Body
  ctx.fillStyle = vis.bodyColor;
  ctx.beginPath();
  ctx.arc(0, 0, 8, 0, Math.PI * 2);
  ctx.fill();

  if (vis.species === 'kitsune') {
    // Fox ears & fluffy tail
    ctx.beginPath();
    ctx.moveTo(-5, -5);
    ctx.lineTo(-8, -13);
    ctx.lineTo(-1, -7);
    ctx.moveTo(2, -7);
    ctx.lineTo(6, -13);
    ctx.lineTo(6, -4);
    ctx.fill();
  } else if (vis.species === 'fairy') {
    // Translucent wings
    ctx.fillStyle = 'rgba(167, 243, 208, 0.7)';
    const flap = Math.sin(time * 18) * 3;
    ctx.beginPath();
    ctx.ellipse(-7, -3, 7, 4 + flap * 0.3, -0.4, 0, Math.PI * 2);
    ctx.fill();
  } else {
    // Mini dragon horns & wings
    ctx.fillStyle = vis.glowColor;
    ctx.beginPath();
    ctx.moveTo(-4, -3);
    ctx.lineTo(-13, -10);
    ctx.lineTo(-9, 2);
    ctx.closePath();
    ctx.fill();
  }

  // Cute anime eyes
  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.arc(3.5, -1, 1.4, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

function drawCosmeticAura(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  time: number,
  style: string,
  graphics: GraphicsQuality
) {
  ctx.save();
  if (style === 'golden_runes') {
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.7)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(x, y - 2, 24 + Math.sin(time * 4) * 2, 6, 0, 0, Math.PI * 2);
    ctx.stroke();
  } else if (style === 'shadow_flame') {
    const count = graphics === 'low' ? 2 : 4;
    for (let i = 0; i < count; i++) {
      const ox = Math.sin(time * 4 + i * 1.7) * 15;
      const oy = -((time * 38 + i * 14) % 48);
      ctx.fillStyle = 'rgba(168, 85, 247, 0.55)';
      ctx.beginPath();
      ctx.arc(x + ox, y + oy, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }
  } else {
    // Orbiting Starlight
    for (let i = 0; i < 3; i++) {
      const ang = time * 3 + (i * Math.PI * 2) / 3;
      const sx = x + Math.cos(ang) * 22;
      const sy = y - 28 + Math.sin(ang) * 10;
      ctx.fillStyle = '#fde047';
      ctx.beginPath();
      ctx.arc(sx, sy, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();
}

// ============================================================================
// ENEMY & MULTI-PHASE BOSS RENDERERS
// ============================================================================
export interface EnemyRenderInfo {
  x: number;
  y: number;
  w: number;
  h: number;
  hp: number;
  maxHp: number;
  name: string;
  archetype: string;
  isElite?: boolean;
  facing: 1 | -1;
  hurtTimer: number;
  animTime: number;
  slowTimer: number;
}

export function drawEnemyEntity(ctx: CanvasRenderingContext2D, e: EnemyRenderInfo, camX: number) {
  const sx = e.x - camX;
  const sy = e.y;
  const groundY = Math.max(sy, 430);
  ctx.save();

  // Ground shadow projected cleanly on floor
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.beginPath();
  ctx.ellipse(sx, groundY, e.w * 0.45, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  const isHover =
    e.archetype.includes('drone') ||
    e.archetype.includes('wisp') ||
    e.archetype.includes('wraith') ||
    e.archetype.includes('gargoyle') ||
    e.archetype.includes('seraph');

  const bob = isHover ? Math.sin(e.animTime * 4.5) * 6 : Math.abs(Math.sin(e.animTime * 7)) * -2;

  ctx.translate(sx, sy + bob);
  ctx.scale(e.facing, 1);

  const primary =
    e.hurtTimer > 0
      ? '#ffffff'
      : e.slowTimer > 0
      ? '#60a5fa'
      : e.isElite
      ? '#a855f7'
      : e.archetype.includes('cyber')
      ? '#0e7490'
      : e.archetype.includes('frost') || e.archetype === 'yeti'
      ? '#1d4ed8'
      : e.archetype.includes('magma') || e.archetype.includes('cinder')
      ? '#c2410c'
      : e.archetype.includes('astral') || e.archetype.includes('nebula')
      ? '#4338ca'
      : '#166534';

  const glow =
    e.isElite
      ? '#fbbf24'
      : e.archetype.includes('cyber')
      ? '#22d3ee'
      : e.archetype.includes('magma') || e.archetype.includes('cinder')
      ? '#fb923c'
      : '#34d399';

  if (isHover) {
    // Winged / Drone Floating Creature
    ctx.fillStyle = primary;
    ctx.beginPath();
    ctx.arc(0, -e.h * 0.55, 14, 0, Math.PI * 2);
    ctx.fill();
    // Wings / Rotors
    ctx.fillStyle = glow;
    const wingY = Math.sin(e.animTime * 14) * 5;
    ctx.beginPath();
    ctx.moveTo(-6, -e.h * 0.6);
    ctx.lineTo(-22, -e.h * 0.8 + wingY);
    ctx.lineTo(-14, -e.h * 0.45);
    ctx.closePath();
    ctx.fill();
    // Glowing Eye Core
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(6, -e.h * 0.55, 4, 0, Math.PI * 2);
    ctx.fill();
  } else {
    // Bipedal / Beast Armored Monster
    const h = e.h;
    const w = e.w;
    // Legs
    const stride = Math.sin(e.animTime * 8) * 5;
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(-7 + stride * 0.5, -14, 6, 14);
    ctx.fillRect(3 - stride * 0.5, -14, 6, 14);

    // Armored Torso
    ctx.fillStyle = primary;
    ctx.beginPath();
    ctx.roundRect(-w * 0.42, -h + 10, w * 0.84, h - 22, 7);
    ctx.fill();

    // Horns / Crown for Elites & Beasts
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.moveTo(-4, -h + 12);
    ctx.lineTo(-10, -h);
    ctx.lineTo(2, -h + 10);
    ctx.moveTo(4, -h + 12);
    ctx.lineTo(12, -h - 2);
    ctx.lineTo(9, -h + 12);
    ctx.fill();

    // Fierce Glowing Anime Monster Eye
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.moveTo(3, -h + 21);
    ctx.lineTo(11, -h + 19);
    ctx.lineTo(7, -h + 25);
    ctx.closePath();
    ctx.fill();

    // Weapon / Claw
    ctx.fillStyle = glow;
    ctx.fillRect(w * 0.3, -h * 0.55, 13, 4);
  }

  ctx.restore();

  // Enemy Health Bar above head
  const barW = e.isElite ? 58 : 42;
  const barY = sy - e.h - 14;
  ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
  ctx.fillRect(sx - barW / 2 - 1, barY - 1, barW + 2, 7);
  const pct = Math.max(0, e.hp / e.maxHp);
  ctx.fillStyle = e.isElite ? '#f59e0b' : '#ef4444';
  ctx.fillRect(sx - barW / 2, barY, barW * pct, 5);

  if (e.isElite) {
    ctx.fillStyle = '#fde68a';
    ctx.font = 'bold 9px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`★ ${e.name}`, sx, barY - 4);
  }
}

export function drawBossEntity(
  ctx: CanvasRenderingContext2D,
  bossDef: BossDef,
  x: number,
  y: number,
  facing: 1 | -1,
  phase: number,
  hurtTimer: number,
  animTime: number,
  isChargingAttack: boolean,
  camX: number
) {
  const sx = x - camX;
  const sy = y;
  const bob = Math.sin(animTime * 3.2) * 5;

  ctx.save();
  // Boss Aura Ring on Floor
  ctx.strokeStyle = phase >= 2 ? '#f43f5e' : bossDef.glowColor;
  ctx.lineWidth = phase >= 2 ? 3.5 : 2;
  ctx.beginPath();
  ctx.ellipse(sx, sy, 48 + Math.sin(animTime * 6) * 4, 11, 0, 0, Math.PI * 2);
  ctx.stroke();

  ctx.translate(sx, sy + bob);
  ctx.scale(facing, 1);

  const bodyCol = hurtTimer > 0 ? '#ffffff' : bossDef.primaryColor;
  const accentCol = phase >= 2 ? '#fb7185' : bossDef.glowColor;

  // Giant Sweeping Wings / Mantle
  ctx.fillStyle = bossDef.secondaryColor;
  const wingFlap = Math.sin(animTime * 5) * 10;
  ctx.beginPath();
  ctx.moveTo(-10, -78);
  ctx.lineTo(-62, -118 + wingFlap);
  ctx.lineTo(-48, -42);
  ctx.closePath();
  ctx.fill();

  // Towering Armored Sovereign Body
  ctx.fillStyle = bodyCol;
  ctx.beginPath();
  ctx.roundRect(-28, -102, 56, 86, 12);
  ctx.fill();

  // Chest Core Reactor / Rune Crystal
  ctx.fillStyle = accentCol;
  ctx.beginPath();
  ctx.moveTo(0, -78);
  ctx.lineTo(12, -62);
  ctx.lineTo(0, -46);
  ctx.lineTo(-12, -62);
  ctx.closePath();
  ctx.fill();

  // Boss Head & Crown Horns
  ctx.fillStyle = bodyCol;
  ctx.beginPath();
  ctx.arc(2, -114, 18, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = accentCol;
  ctx.beginPath();
  ctx.moveTo(-8, -126);
  ctx.lineTo(-22, -148);
  ctx.lineTo(0, -130);
  ctx.moveTo(6, -128);
  ctx.lineTo(20, -150);
  ctx.lineTo(14, -124);
  ctx.fill();

  // Glowing Eyes
  ctx.fillStyle = '#fef08a';
  ctx.beginPath();
  ctx.arc(9, -115, 4, 0, Math.PI * 2);
  ctx.fill();

  // Colossal Boss Weapon / Claw Arm
  ctx.save();
  ctx.translate(16, -78);
  ctx.rotate(isChargingAttack ? -0.9 + Math.sin(animTime * 25) * 0.15 : 0.25);
  ctx.fillStyle = accentCol;
  ctx.beginPath();
  ctx.moveTo(0, -6);
  ctx.lineTo(56, -14);
  ctx.lineTo(68, 0);
  ctx.lineTo(52, 12);
  ctx.lineTo(0, 6);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  ctx.restore();

  if (isChargingAttack) {
    ctx.save();
    ctx.fillStyle = '#fde047';
    ctx.font = 'bold 13px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('⚠ LETHAL STRIKE INCOMING! ⚠', sx, sy - 160);
    ctx.restore();
  }
}
