import * as THREE from 'three';
import { buildGun } from './humanoid';
import { AMMO_LABEL, AMMO_PACK, WEAPONS, WEAPON_IDS, type AmmoType, type WeaponId } from './weapons';

export type LootKind =
  | { t: 'weapon'; id: WeaponId }
  | { t: 'ammo'; ammo: AmmoType; n: number }
  | { t: 'med' }
  | { t: 'armor'; level: 1 | 2 };

export interface LootItem {
  id: number;
  kind: LootKind;
  x: number;
  y: number;
  z: number;
  mesh: THREE.Group;
}

const AMMO_TYPES: AmmoType[] = ['light', 'heavy', 'shell'];

export function randomLootKind(): LootKind {
  const r = Math.random();
  if (r < 0.36) return { t: 'weapon', id: WEAPON_IDS[Math.floor(Math.random() * WEAPON_IDS.length)] };
  if (r < 0.66) {
    const ammo = AMMO_TYPES[Math.floor(Math.random() * AMMO_TYPES.length)];
    return { t: 'ammo', ammo, n: AMMO_PACK[ammo] };
  }
  if (r < 0.82) return { t: 'med' };
  return { t: 'armor', level: Math.random() < 0.6 ? 1 : 2 };
}

export function lootName(k: LootKind): string {
  switch (k.t) {
    case 'weapon':
      return WEAPONS[k.id].name;
    case 'ammo':
      return `${AMMO_LABEL[k.ammo]} ammo`;
    case 'med':
      return 'Medkit';
    case 'armor':
      return `Armor Lv.${k.level}`;
  }
}

function kindColor(k: LootKind): number {
  switch (k.t) {
    case 'weapon':
      return { pistol: 0xe5e7eb, smg: 0x22c55e, ar: 0xf59e0b, shotgun: 0xa855f7, sniper: 0xef4444 }[k.id];
    case 'ammo':
      return 0x38bdf8;
    case 'med':
      return 0x4ade80;
    case 'armor':
      return k.level === 2 ? 0xf472b6 : 0x60a5fa;
  }
}

export function buildLootMesh(k: LootKind): THREE.Group {
  const g = new THREE.Group();
  const color = kindColor(k);

  const beam = new THREE.Mesh(
    new THREE.CylinderGeometry(0.06, 0.06, 6, 8, 1, true),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false }),
  );
  beam.position.y = 3;
  g.add(beam);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.42, 0.52, 32),
    new THREE.MeshBasicMaterial({ color, side: THREE.DoubleSide, transparent: true, opacity: 0.9 }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.04;
  g.add(ring);

  const item = new THREE.Group();
  item.position.y = 0.5;
  g.add(item);
  const std = (c: number) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.6, metalness: 0.2 });

  if (k.t === 'weapon') {
    const gun = buildGun(k.id).group;
    gun.rotation.y = 0.7;
    item.add(gun);
  } else if (k.t === 'ammo') {
    item.add(new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.3, 0.36), std(0x3f5a2a)));
    const band = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.06, 0.38), std(color));
    band.position.y = 0.1;
    item.add(band);
  } else if (k.t === 'med') {
    item.add(new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.32, 0.32), std(0xf8fafc)));
    const red1 = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.02, 0.07), std(0xdc2626));
    red1.position.y = 0.17;
    const red2 = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.02, 0.3), std(0xdc2626));
    red2.position.y = 0.17;
    item.add(red1, red2);
  } else {
    item.add(new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.44, 0.3), std(0x1e293b)));
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.08, 0.32), std(color));
    item.add(stripe);
  }
  return g;
}
