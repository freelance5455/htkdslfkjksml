import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { BLOCKS, MAP, ORIGIN, buildCity, roadX, type Aabb, type City } from "./city.ts";
import { MISSIONS } from "./types.ts";

/** Keep these in sync with the player's collision radii in engine.ts (on foot 0.42, car 1.25). */
const FOOT_RADIUS = 0.42;
const CAR_RADIUS = 1.25;
const CELL = 0.5;

function solidsOf(city: City): Aabb[] {
  return [...city.buildings, ...city.blockers];
}

function insideAnySolid(x: number, z: number, solids: Aabb[], margin = 0): boolean {
  return solids.some(
    (b) => x > b.minX - margin && x < b.maxX + margin && z > b.minZ - margin && z < b.maxZ + margin,
  );
}

/** Mirrors the bounds in resolveCircle(): the map edge is solid except the pier. */
function inBounds(x: number, z: number, radius: number): boolean {
  const pierX = roadX(4);
  if (z > ORIGIN + MAP - 8 && Math.abs(x - pierX) < 5.2) {
    return Math.abs(x - pierX) <= 2.5 && z <= ORIGIN + MAP + 16;
  }
  const lo = ORIGIN + 1.5;
  const hi = ORIGIN + MAP - 1.5;
  return x >= lo && x <= hi && z >= lo && z <= hi;
}

function walkable(x: number, z: number, radius: number, solids: Aabb[]): boolean {
  for (const b of solids) {
    const cx = Math.max(b.minX, Math.min(x, b.maxX));
    const cz = Math.max(b.minZ, Math.min(z, b.maxZ));
    const dx = x - cx;
    const dz = z - cz;
    if (dx * dx + dz * dz < radius * radius) return false;
  }
  return inBounds(x, z, radius);
}

/** Flood fill on a grid from `start`. Returns a lookup for reachable points. */
function reachableFrom(start: { x: number; z: number }, radius: number, solids: Aabb[]) {
  const lo = ORIGIN - 30;
  const n = Math.ceil((MAP + 60) / CELL);
  const seen = new Uint8Array(n * n);
  const idx = (i: number, k: number) => k * n + i;
  const toCell = (v: number, o: number) => Math.round((v - o) / CELL);
  const si = toCell(start.x, lo);
  const sk = toCell(start.z, lo);
  const queue = [idx(si, sk)];
  seen[queue[0]] = 1;
  for (let head = 0; head < queue.length; head++) {
    const c = queue[head];
    const i = c % n;
    const k = (c - i) / n;
    for (const [di, dk] of [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ]) {
      const ni = i + di;
      const nk = k + dk;
      if (ni < 0 || nk < 0 || ni >= n || nk >= n) continue;
      const nIdx = idx(ni, nk);
      if (seen[nIdx]) continue;
      if (!walkable(lo + ni * CELL, lo + nk * CELL, radius, solids)) continue;
      seen[nIdx] = 1;
      queue.push(nIdx);
    }
  }
  return (x: number, z: number) => {
    const i = toCell(x, lo);
    const k = toCell(z, lo);
    return i >= 0 && k >= 0 && i < n && k < n && seen[idx(i, k)] === 1;
  };
}

function allSpots(city: City): { name: string; x: number; z: number }[] {
  const s = city.spots;
  return [
    { name: "dock", ...s.dock },
    { name: "hideout", ...s.hideout },
    { name: "safehouse", ...s.safehouse },
    { name: "contact", ...s.contact },
    { name: "armeria", ...s.armeria },
    { name: "hospital", ...s.hospital },
    ...s.race.map((p, i) => ({ name: `race${i}`, ...p })),
    ...s.cash.map((p, i) => ({ name: `cash${i}`, ...p })),
    ...s.meds.map((p, i) => ({ name: `meds${i}`, ...p })),
  ];
}

describe("city generation", () => {
  it("is deterministic (same seed, same city)", () => {
    const a = buildCity();
    const b = buildCity();
    assert.deepEqual(a.buildings, b.buildings);
    assert.deepEqual(a.props, b.props);
  });

  it("has the expected grid size and a building per playable lot", () => {
    const city = buildCity();
    assert.equal(BLOCKS, 7);
    assert.ok(city.buildings.length > 100);
    for (const b of city.buildings) assert.ok(b.h > 0 && b.maxX > b.minX && b.maxZ > b.minZ);
  });

  it("no building overlaps a road strip (roads are where the player drives)", () => {
    const city = buildCity();
    const ROAD_HALF = 6; // ROAD = 12 in city.ts
    const strips: Aabb[] = [];
    for (let i = 0; i <= BLOCKS; i++) {
      strips.push({ minX: roadX(i) - ROAD_HALF, maxX: roadX(i) + ROAD_HALF, minZ: ORIGIN, maxZ: ORIGIN + MAP, h: 0 });
      strips.push({ minX: ORIGIN, maxX: ORIGIN + MAP, minZ: roadX(i) - ROAD_HALF, maxZ: roadX(i) + ROAD_HALF, h: 0 });
    }
    for (const b of city.buildings) {
      const hit = strips.some(
        (r) => b.maxX > r.minX && b.minX < r.maxX && b.maxZ > r.minZ && b.minZ < r.maxZ,
      );
      assert.equal(hit, false, `building at (${b.minX.toFixed(1)}, ${b.minZ.toFixed(1)}) blocks a road`);
    }
  });
});

describe("mission and pickup spots", () => {
  const city = buildCity();
  const solids = solidsOf(city);

  it("no spot sits inside a building or blocker", () => {
    for (const spot of allSpots(city)) {
      assert.equal(insideAnySolid(spot.x, spot.z, solids), false, `${spot.name} is inside a solid`);
    }
  });

  it("every spot can be reached on foot from the spawn point", () => {
    const reach = reachableFrom(city.spots.spawn, FOOT_RADIUS, solids);
    for (const spot of allSpots(city)) {
      assert.ok(reach(spot.x, spot.z), `${spot.name} is unreachable on foot`);
    }
  });

  it("every spot can be reached by car from the spawn point", () => {
    const reach = reachableFrom(city.spots.spawn, CAR_RADIUS, solids);
    for (const spot of allSpots(city)) {
      assert.ok(reach(spot.x, spot.z), `${spot.name} is unreachable by car`);
    }
  });
});

describe("mission data", () => {
  it("mission ids are unique and rewards are positive", () => {
    const ids = MISSIONS.map((m) => m.id);
    assert.equal(new Set(ids).size, ids.length);
    for (const m of MISSIONS) assert.ok(m.reward > 0, `${m.id} reward`);
  });
});
