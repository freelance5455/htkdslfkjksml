import { BoardTile, Direction, LevelConfig } from '../types';
import { getDirectionDelta, verifyLevelSolvable } from './pathSolver';
import { SHAPE_DESIGNS, ShapeTemplate, parseShapeCoordinates } from './shapeDesigns';
import { generateLongArrowLevel } from './longArrowGenerator';

export { generateLongArrowLevel };

const ALL_DIRECTIONS: Direction[] = ['UP', 'DOWN', 'LEFT', 'RIGHT'];

/**
 * Creates a deterministic pseudo-random number generator from a seed
 */
function createPrng(seed: number) {
  let s = Math.abs(seed) || 1;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

/**
 * Procedural symmetrical shape generator for infinite levels beyond the handcrafted 30
 */
function generateProceduralShape(levelNumber: number): ShapeTemplate {
  const prng = createPrng(levelNumber * 7771);
  const size = 11;
  const grid: string[][] = Array.from({ length: size }, () => Array(size).fill('.'));

  const shapeThemes = [
    { name: 'Castle', emoji: '🏰' },
    { name: 'Shield', emoji: '🛡️' },
    { name: 'Dragon', emoji: '🐉' },
    { name: 'Phoenix', emoji: '🦅' },
    { name: 'Emblem', emoji: '⚜️' },
    { name: 'Crystal', emoji: '🔮' },
    { name: 'Compass', emoji: '🧭' },
    { name: 'Fortress', emoji: '🏯' },
    { name: 'Penguin', emoji: '🐧' },
    { name: 'Elephant', emoji: '🐘' },
  ];

  const theme = shapeThemes[(levelNumber - 31) % shapeThemes.length];

  // Generate horizontally symmetrical pixel art
  const mid = Math.floor(size / 2);
  const density = 0.55 + Math.min(0.2, (levelNumber - 30) * 0.005);

  for (let y = 1; y < size - 1; y++) {
    for (let x = 1; x <= mid; x++) {
      if (prng() < density) {
        grid[y][x] = 'X';
        grid[y][size - 1 - x] = 'X'; // Symmetrical reflection
      }
    }
  }

  // Ensure center column connectivity
  for (let y = 2; y < size - 2; y++) {
    if (prng() < 0.75) {
      grid[y][mid] = 'X';
    }
  }

  const pattern = grid.map((row) => row.join(''));
  return {
    id: `proc-${levelNumber}`,
    name: theme.name,
    emoji: theme.emoji,
    gridWidth: size,
    gridHeight: size,
    pattern,
  };
}

/**
 * Peeling Generation Algorithm:
 * Deconstructs the shape from outer boundary inwards, assigning each tile a direction
 * that has NO obstacles to the grid boundary at its moment of peel.
 *
 * This mathematically guarantees 100% solvability in forward gameplay:
 * Outer tiles clear first, progressively revealing interior tiles!
 */
function generateShapeLevelTiles(
  shape: ShapeTemplate,
  seed: number,
  levelNumber: number
): BoardTile[] {
  const rng = createPrng(seed);
  const coords = parseShapeCoordinates(shape.pattern);

  const remaining = new Map<string, { x: number; y: number; id: string }>();
  coords.forEach((c, idx) => {
    remaining.set(`${c.x},${c.y}`, { ...c, id: `tile-${levelNumber}-${idx}` });
  });

  const peeledOrder: { pt: { x: number; y: number; id: string }; direction: Direction }[] = [];

  while (remaining.size > 0) {
    const peelCandidates: {
      pt: { x: number; y: number; id: string };
      clearDirs: Direction[];
    }[] = [];

    for (const [, pt] of remaining.entries()) {
      const clearDirs: Direction[] = [];
      for (const dir of ALL_DIRECTIONS) {
        const { dx, dy } = getDirectionDelta(dir);
        let cx = pt.x + dx;
        let cy = pt.y + dy;
        let hitsRemaining = false;

        while (cx >= 0 && cx < shape.gridWidth && cy >= 0 && cy < shape.gridHeight) {
          if (remaining.has(`${cx},${cy}`)) {
            hitsRemaining = true;
            break;
          }
          cx += dx;
          cy += dy;
        }

        if (!hitsRemaining) {
          clearDirs.push(dir);
        }
      }

      if (clearDirs.length > 0) {
        peelCandidates.push({ pt, clearDirs });
      }
    }

    if (peelCandidates.length === 0) {
      // Fallback: If trapped in a concave corner, release the outermost candidate towards border
      break;
    }

    // Pick a candidate with slight randomization to create natural variety
    const pickIdx = Math.floor(rng() * peelCandidates.length);
    const chosen = peelCandidates[pickIdx];
    const dirIdx = Math.floor(rng() * chosen.clearDirs.length);
    const chosenDir = chosen.clearDirs[dirIdx];

    peeledOrder.push({ pt: chosen.pt, direction: chosenDir });
    remaining.delete(`${chosen.pt.x},${chosen.pt.y}`);
  }

  // Convert peeled list to BoardTile array
  const totalTiles = peeledOrder.length;
  const tiles: BoardTile[] = peeledOrder.map((item, idx) => {
    // Tiles peeled deeper in the process (towards the end of peeledOrder)
    // are interior tiles that emerge later in gameplay.
    const isInterior = idx > totalTiles * 0.7;

    // Introduce Rotator mechanic in later levels (Level 12+) for deep interior tiles
    const isRotator = levelNumber >= 12 && isInterior && rng() < 0.12;

    return {
      id: item.pt.id,
      x: item.pt.x,
      y: item.pt.y,
      type: 'ARROW',
      direction: item.direction,
      isRotator: Boolean(isRotator),
    };
  });

  return tiles;
}

/**
 * Main Level Generator:
 * Generates a complete level representing a recognizable design made of
 * MANY small compact tiles packed closely together.
 */
export function generateLevel(levelNumber: number): LevelConfig {
  const shapeIndex = levelNumber - 1;
  const shape: ShapeTemplate =
    shapeIndex < SHAPE_DESIGNS.length
      ? SHAPE_DESIGNS[shapeIndex]
      : generateProceduralShape(levelNumber);

  const seed = levelNumber * 98765 + 12345;
  const tiles = generateShapeLevelTiles(shape, seed, levelNumber);

  // Verify solvability
  const verify = verifyLevelSolvable(tiles, shape.gridWidth, shape.gridHeight);
  if (!verify.solvable) {
    // If ever any edge-case occurs, re-generate with a perturbed seed
    const altTiles = generateShapeLevelTiles(shape, seed + 999, levelNumber);
    const altTimeLimit = Math.max(60, Math.ceil(altTiles.length * 1.8));
    return {
      id: levelNumber,
      worldId: Math.ceil(levelNumber / 20),
      levelNumber,
      name: `${shape.emoji} ${shape.name}`,
      themeDescription: `Level ${levelNumber} • ${shape.name}`,
      gridWidth: shape.gridWidth,
      gridHeight: shape.gridHeight,
      tiles: altTiles,
      targetMoves: altTiles.length,
      timeLimit: altTimeLimit,
      starThresholds: {
        threeStarMoves: altTiles.length,
        twoStarMoves: Math.ceil(altTiles.length * 1.3),
      },
    };
  }

  const timeLimit = Math.max(60, Math.ceil(tiles.length * 1.8));

  return {
    id: levelNumber,
    worldId: Math.ceil(levelNumber / 20),
    levelNumber,
    name: `${shape.emoji} ${shape.name}`,
    themeDescription: `Level ${levelNumber} • ${shape.name}`,
    gridWidth: shape.gridWidth,
    gridHeight: shape.gridHeight,
    tiles,
    targetMoves: tiles.length,
    timeLimit,
    starThresholds: {
      threeStarMoves: tiles.length,
      twoStarMoves: Math.ceil(tiles.length * 1.3),
    },
  };
}

/**
 * Generates today's special Daily Challenge puzzle with unique seed.
 */
export function generateDailyChallenge(dateStr: string): LevelConfig {
  let hash = 0;
  for (let i = 0; i < dateStr.length; i++) {
    hash = (hash << 5) - hash + dateStr.charCodeAt(i);
    hash |= 0;
  }
  const dateSeed = Math.abs(hash);
  const shapeIdx = dateSeed % SHAPE_DESIGNS.length;
  const shape = SHAPE_DESIGNS[shapeIdx];

  const tiles = generateShapeLevelTiles(shape, dateSeed + 8888, 999);

  return {
    id: 999901,
    worldId: 1,
    levelNumber: 999,
    name: `Daily • ${shape.emoji} ${shape.name}`,
    themeDescription: `Daily Special • ${dateStr}`,
    gridWidth: shape.gridWidth,
    gridHeight: shape.gridHeight,
    tiles,
    targetMoves: tiles.length,
    starThresholds: {
      threeStarMoves: tiles.length,
      twoStarMoves: Math.ceil(tiles.length * 1.3),
    },
  };
}

/**
 * Generates an intensive Hard Challenge puzzle with high tile density.
 */
export function generateHardChallenge(seedNum: number = Date.now()): LevelConfig {
  const hardSeed = Math.abs(seedNum) + 77777;
  // Pick from complex designs (Dragon, Rooster, Cat, Dog, Robot)
  const complexShapes = SHAPE_DESIGNS.filter(
    (s) => s.id === 'rooster' || s.id === 'cat' || s.id === 'dog' || s.id === 'robot' || s.id === 'ghost'
  );
  const shape = complexShapes[hardSeed % complexShapes.length] || SHAPE_DESIGNS[8];

  const tiles = generateShapeLevelTiles(shape, hardSeed, 88);

  return {
    id: 999902,
    worldId: 1,
    levelNumber: 88,
    name: `Hard • ${shape.emoji} ${shape.name}`,
    themeDescription: 'Tactical Mind Challenge • Dense Tiles',
    gridWidth: shape.gridWidth,
    gridHeight: shape.gridHeight,
    tiles,
    targetMoves: tiles.length,
    starThresholds: {
      threeStarMoves: tiles.length,
      twoStarMoves: Math.ceil(tiles.length * 1.3),
    },
  };
}

/**
 * Legacy support for Relax mode.
 */
export function generateRelaxLevel(levelIndex: number): LevelConfig {
  return generateLevel(levelIndex + 5);
}
