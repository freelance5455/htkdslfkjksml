import { CareerPosition, CareerTrack, CareerTier } from './types';

export const CAREER_TRACKS_INFO: Record<CareerTrack, {
  name: string;
  icon: string;
  description: string;
  color: string;
}> = {
  commerce: {
    name: 'التجارة والمبيعات',
    icon: '🏪',
    description: 'إدارة المبيعات والتوريد والتفاوض والترقي من بائع إلى مدير تنفيذي وشريك تجاري',
    color: 'from-amber-500/20 to-orange-500/20 text-amber-400 border-amber-500/30'
  },
  corporate: {
    name: 'الإدارة والأعمال المؤسسية',
    icon: '🏢',
    description: 'تنظيم العمليات والمراسلات وإدارة الموظفين والوصول لمراتب القيادة العليا',
    color: 'from-blue-500/20 to-indigo-500/20 text-blue-400 border-blue-500/30'
  },
  tech: {
    name: 'تكنولوجيا البرمجيات وهندسة النظم',
    icon: '💻',
    description: 'برمجة وبناء حلول رقمية والترقي من مبرمج متدرب إلى رئيس قطاع التكنولوجيا CTO',
    color: 'from-cyan-500/20 to-teal-500/20 text-cyan-400 border-cyan-500/30'
  },
  logistics: {
    name: 'الخدمات اللوجستية والنقل',
    icon: '🛵',
    description: 'إدارة خطوط التوصيل والأسطول والشحن والترقي لمدير لوجستيات عام',
    color: 'from-emerald-500/20 to-green-500/20 text-emerald-400 border-emerald-500/30'
  },
  freelance: {
    name: 'العمل الحر والاستشارات الدولية',
    icon: '🌐',
    description: 'تقديم خدمات رقمية واستشارية والتحول لصاحب وكالة ومستشار معتمد',
    color: 'from-purple-500/20 to-pink-500/20 text-purple-400 border-purple-500/30'
  }
};

export const CAREER_POSITIONS: Record<CareerTrack, Record<CareerTier, CareerPosition>> = {
  // 1. COMMERCE
  commerce: {
    1: {
      id: 'comm_1',
      track: 'commerce',
      tier: 1,
      title: 'بائع ومسؤول واجهة متجر',
      department: 'قسم المبيعات والتجزئة',
      responsibilities: 'استقبال الزبائن، ترتيب البضائع، ومتابعة جرد الرفوف اليومي.',
      minDaysWorked: 0,
      minSkill: 0,
      basePay: 170,
      energyCost: 20,
      hoursRequired: 2.0,
      perkDescription: 'بداية مشوار التجارة واكتساب مهارات الإقناع والتعامل مع الناس.'
    },
    2: {
      id: 'comm_2',
      track: 'commerce',
      tier: 2,
      title: 'مسؤول مبيعات أول وكاشير معتمد',
      department: 'إدارة الفرع والمعاملات المالية',
      responsibilities: 'إغلاق الخزينة اليومية، التعامل مع كبار العملاء، وتقديم عروض التخفيضات.',
      minDaysWorked: 6,
      minSkill: 14,
      basePay: 310,
      energyCost: 22,
      hoursRequired: 2.5,
      perkDescription: 'علاوة مبيعات +15% وثقة متزايدة من أصحاب المتاجر.'
    },
    3: {
      id: 'comm_3',
      track: 'commerce',
      tier: 3,
      title: 'مشرف فرع ومدير ورديات',
      department: 'الإشراف الميداني',
      responsibilities: 'إدارة فريق من 6 موظفين، حل نزاعات الزبائن، والاتفاق مع الموردين.',
      minDaysWorked: 15,
      minSkill: 28,
      basePay: 550,
      energyCost: 24,
      hoursRequired: 3.0,
      requiredCourseId: 'business_mgmt',
      perkDescription: 'صلاحيات إدارية + بونص شهري مستقر + وجبات عمل مجانية.'
    },
    4: {
      id: 'comm_4',
      track: 'commerce',
      tier: 4,
      title: 'مدير مبيعات إقليمي لسلسلة فروع',
      department: 'الإدارة التنفيذية للمبيعات',
      responsibilities: 'تحديد مستهدفات الأرباح، فتح فروع جديدة، ومراقبة الجودة عبر المدينة.',
      minDaysWorked: 28,
      minSkill: 45,
      basePay: 980,
      energyCost: 26,
      hoursRequired: 3.5,
      perkDescription: 'سيارة عمل وسفر دوري وسمعة تجارية مرموقة في السوق.'
    },
    5: {
      id: 'comm_5',
      track: 'commerce',
      tier: 5,
      title: 'شريك تجاري ورئيس العمليات (COO)',
      department: 'مجلس الإدارة والشركاء',
      responsibilities: 'اتخاذ القرارات الاستثمارية الكبرى، إبرام عقود بالملايين، وتوزيع الأرباح.',
      minDaysWorked: 45,
      minSkill: 65,
      basePay: 1850,
      energyCost: 28,
      hoursRequired: 4.0,
      perkDescription: 'حصة أرباح يومية إضافية + نفوذ اجتماعي وسلطة اتخاذ القرار.'
    }
  },

  // 2. CORPORATE & ADMINISTRATION
  corporate: {
    1: {
      id: 'corp_1',
      track: 'corporate',
      tier: 1,
      title: 'سكرتير ومنسق بيانات مساعد',
      department: 'الشؤون الإدارية العامة',
      responsibilities: 'طباعة التقارير، تنظيم جدول المواعيد، وأرشفة ملفات الموظفين.',
      minDaysWorked: 0,
      minSkill: 12,
      basePay: 290,
      energyCost: 20,
      hoursRequired: 2.5,
      perkDescription: 'بيئة عمل مكيفة ومحترمة تتيح بناء شبكة علاقات مكتبية.'
    },
    2: {
      id: 'corp_2',
      track: 'corporate',
      tier: 2,
      title: 'أخصائي شؤون إدارية وتنسيق عقود',
      department: 'إدارة الموارد البشرية والعمليات',
      responsibilities: 'إعداد مسودات العقود الرسمية، مراجعة فواتير الشركات، ومتابعة الحضور.',
      minDaysWorked: 7,
      minSkill: 24,
      basePay: 490,
      energyCost: 22,
      hoursRequired: 3.0,
      perkDescription: 'بدل مواصلات وثقة الإدارة في الملفات الحساسة.'
    },
    3: {
      id: 'corp_3',
      track: 'corporate',
      tier: 3,
      title: 'رئيس قسم العمليات والمشتريات',
      department: 'إدارة سلاسل التوريد واللوجستيات',
      responsibilities: 'التفاوض مع الموردين الكبار، إدارة الميزانية التشغيلية، وتوجيه فريق العمل.',
      minDaysWorked: 16,
      minSkill: 38,
      basePay: 820,
      energyCost: 24,
      hoursRequired: 3.5,
      requiredCourseId: 'business_mgmt',
      perkDescription: 'تأمين طبي عائلي شامل وتسهيلات بنكية.'
    },
    4: {
      id: 'corp_4',
      track: 'corporate',
      tier: 4,
      title: 'مدير تنفيذي للشؤون العامة والإدارة',
      department: 'الإدارة العليا للشركة',
      responsibilities: 'تطوير سياسات العمل، تمثيل الشركة أمام الجهات الرسمية، وتحقيق الأهداف الربحية.',
      minDaysWorked: 30,
      minSkill: 54,
      basePay: 1450,
      energyCost: 26,
      hoursRequired: 4.0,
      requiredCourseId: 'university_degree',
      perkDescription: 'مكتب فاخر ببرج إداري + هيبة اجتماعية + مكافآت سنوية ضخمة.'
    },
    5: {
      id: 'corp_5',
      track: 'corporate',
      tier: 5,
      title: 'نائب الرئيس التنفيذي ومستشار الإدارة العليا',
      department: 'رئاسة مجلس الإدارة',
      responsibilities: 'صياغة استراتيجية الشركة طويلة المدى، قيادة الاندماجات والاستحواذات، والمشورة العليا.',
      minDaysWorked: 48,
      minSkill: 72,
      basePay: 2600,
      energyCost: 28,
      hoursRequired: 4.0,
      perkDescription: 'أعلى راتب إداري بالمدينة + احترام وتقدير الجميع.'
    }
  },

  // 3. TECH & SOFTWARE ENGINEERING
  tech: {
    1: {
      id: 'tech_1',
      track: 'tech',
      tier: 1,
      title: 'مبرمج مبتدئ ومطور واجهات (Junior Dev)',
      department: 'فريق التطوير البرمجي',
      responsibilities: 'إصلاح الأخطاء البرمجية (Bugs)، كتابة مكونات الويب، والتعلم المستمر.',
      minDaysWorked: 0,
      minSkill: 30,
      basePay: 680,
      energyCost: 22,
      hoursRequired: 3.0,
      requiredAssets: ['laptop'],
      perkDescription: 'بداية المسار الرقمي الواعد واكتساب خبرات تقنية متسارعة.'
    },
    2: {
      id: 'tech_2',
      track: 'tech',
      tier: 2,
      title: 'مهندس برمجيات متكامل (Full-Stack Engineer)',
      department: 'هندسة الأنظمة والخدمات السحابية',
      responsibilities: 'بناء قواعد البيانات وتطوير الواجهات الخلفية (APIs) وتحسين أداء التطبيقات.',
      minDaysWorked: 8,
      minSkill: 44,
      basePay: 1200,
      energyCost: 24,
      hoursRequired: 3.5,
      requiredAssets: ['laptop'],
      requiredCourseId: 'coding_bootcamp',
      perkDescription: 'ساعات عمل مرنة مع طلب هائل من شركات البرمجة العالمية.'
    },
    3: {
      id: 'tech_3',
      track: 'tech',
      tier: 3,
      title: 'قائد فريق تقني ومهندس أول (Tech Lead & Senior)',
      department: 'قيادة الفرق الهندسية',
      responsibilities: 'مراجعة أكواد الفريق (Code Review)، تدريب المبرمجين الجدد، وضمان أمان الأنظمة.',
      minDaysWorked: 18,
      minSkill: 60,
      basePay: 2050,
      energyCost: 26,
      hoursRequired: 4.0,
      requiredAssets: ['laptop'],
      perkDescription: 'سمعة تقنية رنانة وحرية العمل عن بُعد مع مكافآت برمجية.'
    },
    4: {
      id: 'tech_4',
      track: 'tech',
      tier: 4,
      title: 'مهندس معماري رئيسي للنظم (Principal Architect)',
      department: 'معمارية النظم والبنية التحتية',
      responsibilities: 'تصميم البنى الضخمة فائقة التحمل للأنظمة المليونية ومنع الاختراقات التقنية.',
      minDaysWorked: 32,
      minSkill: 76,
      basePay: 3400,
      energyCost: 28,
      hoursRequired: 4.0,
      requiredAssets: ['laptop'],
      requiredCourseId: 'university_degree',
      perkDescription: 'استشارات بالساعة برواتب استثنائية وبدلات تكنولوجية عالية.'
    },
    5: {
      id: 'tech_5',
      track: 'tech',
      tier: 5,
      title: 'رئيس قطاع التكنولوجيا (CTO) والتحول الرقمي',
      department: 'القيادة التقنية العليا',
      responsibilities: 'قيادة استراتيجية التكنولوجيا للشركة، الإشراف على الذكاء الاصطناعي، وابتكار المنتجات.',
      minDaysWorked: 50,
      minSkill: 88,
      basePay: 5600,
      energyCost: 30,
      hoursRequired: 4.5,
      requiredAssets: ['laptop'],
      perkDescription: 'القمة المهنية الرقمية: أسرع مسار لبناء ثروة ضخمة بالحلال!'
    }
  },

  // 4. LOGISTICS & TRANSPORT
  logistics: {
    1: {
      id: 'log_1',
      track: 'logistics',
      tier: 1,
      title: 'مندوب توصيل ودليفري سريع',
      department: 'التوزيع والتوصيل الميداني',
      responsibilities: 'استلام الطرود من المطاعم والمحلات وتوصيلها للزبائن بأمان.',
      minDaysWorked: 0,
      minSkill: 0,
      basePay: 140,
      energyCost: 22,
      hoursRequired: 2.0,
      perkDescription: 'كاش يومي فوري مع إكراميات (Tipping) من الزبائن.'
    },
    2: {
      id: 'log_2',
      track: 'logistics',
      tier: 2,
      title: 'كابتن توصيل معتمد وخطوط سريعة',
      department: 'النقل السريع',
      responsibilities: 'تغطية مناطق حيوية شاسعة، نقل طلبيات VIP حساسة، والتنسيق مع المطابخ المركزية.',
      minDaysWorked: 6,
      minSkill: 10,
      basePay: 330,
      energyCost: 24,
      hoursRequired: 2.5,
      requiredAssets: ['bike'],
      requiredCourseId: 'driving_license',
      perkDescription: 'علاوة بنزين وخصم 40% على صيانة الموتوسيكل.'
    },
    3: {
      id: 'log_3',
      track: 'logistics',
      tier: 3,
      title: 'مشرف خطوط توزيع ومسؤول مناديب الحي',
      department: 'إدارة المحطات اللوجستية',
      responsibilities: 'توزيع خطوط السير على 12 مندوباً، متابعة أوقات الوصول، وحل أزمات الطرق.',
      minDaysWorked: 15,
      minSkill: 22,
      basePay: 620,
      energyCost: 24,
      hoursRequired: 3.0,
      perkDescription: 'عمل ميداني وإداري مريح مع مكافآت التزام الخطوط.'
    },
    4: {
      id: 'log_4',
      track: 'logistics',
      tier: 4,
      title: 'مدير محطة شحن وتوزيع مركزية',
      department: 'مستودعات الشحن الإقليمي',
      responsibilities: 'إدارة أسطول الشحن والشاحنات، مراقبة البضائع الواردة، والتنسيق مع الموانئ.',
      minDaysWorked: 27,
      minSkill: 36,
      basePay: 1100,
      energyCost: 26,
      hoursRequired: 3.5,
      perkDescription: 'صلاحيات توظيف السائقين وتخفيضات خاصة على الشحن العائلي.'
    },
    5: {
      id: 'log_5',
      track: 'logistics',
      tier: 5,
      title: 'مدير عام سلاسل الإمداد والنقل العام',
      department: 'الإدارة التنفيذية للوجستيات',
      responsibilities: 'إدارة وتوجيه آلاف الشحنات يومياً، عقد شراكات نقل قومية، وتوسيع الأسطول.',
      minDaysWorked: 42,
      minSkill: 50,
      basePay: 1950,
      energyCost: 28,
      hoursRequired: 4.0,
      perkDescription: 'موقع قيادي حساس في شريان التجارة ودخل يومي ممتاز.'
    }
  },

  // 5. FREELANCE & INTERNATIONAL CONSULTING
  freelance: {
    1: {
      id: 'free_1',
      track: 'freelance',
      tier: 1,
      title: 'مستقل مبتدئ ومقدم خدمات رقمية',
      department: 'منصات العمل الحر',
      responsibilities: 'كتابة محتوى، إدخال بيانات، تصميمات خفيفة، وتنفيذ مهام سريعة.',
      minDaysWorked: 0,
      minSkill: 6,
      basePay: 140,
      energyCost: 18,
      hoursRequired: 2.0,
      requiredAssets: ['phone'],
      perkDescription: 'حرية كاملة في تحديد ساعات العمل من أي مكان.'
    },
    2: {
      id: 'free_2',
      track: 'freelance',
      tier: 2,
      title: 'مستقل محترف ومعتمد (Top-Rated Freelancer)',
      department: 'الخدمات الاحترافية المعتمدة',
      responsibilities: 'تنفيذ مشاريع معقدة لعملاء بالخليج وأوروبا، ترجمة متخصصة، واستشارات تسويقية.',
      minDaysWorked: 7,
      minSkill: 20,
      basePay: 460,
      energyCost: 20,
      hoursRequired: 2.5,
      requiredAssets: ['phone'],
      requiredCourseId: 'language_diploma',
      perkDescription: 'تقييم 5 نجوم دائم وقائمة انتظار من العملاء.'
    },
    3: {
      id: 'free_3',
      track: 'freelance',
      tier: 3,
      title: 'استشاري حلول رقمية ومدير حسابات VIP',
      department: 'الاستشارات الرقمية والتطوير',
      responsibilities: 'تصميم استراتيجيات تسويق وتطوير للمؤسسات والشركات الناشئة بعقود عمل ثابتة.',
      minDaysWorked: 18,
      minSkill: 36,
      basePay: 950,
      energyCost: 22,
      hoursRequired: 3.0,
      requiredAssets: ['laptop'],
      perkDescription: 'عقود احتفاظ شهرية ودخل بالعملة الصعبة.'
    },
    4: {
      id: 'free_4',
      track: 'freelance',
      tier: 4,
      title: 'مؤسس وصاحب وكالة خدمات رقمية مصغرة',
      department: 'وكالات الأعمال الرقمية',
      responsibilities: 'إدارة 5 مستقلين وتوزيع المشاريع عليهم، وتقديم حلول برمجية وتسويقية متكاملة.',
      minDaysWorked: 30,
      minSkill: 52,
      basePay: 1750,
      energyCost: 24,
      hoursRequired: 3.5,
      requiredAssets: ['laptop'],
      requiredCourseId: 'business_mgmt',
      perkDescription: 'أرباح مضاعفة نتيجة إدارة جهود الفريق الحر.'
    },
    5: {
      id: 'free_5',
      track: 'freelance',
      tier: 5,
      title: 'خبير دولي ومستشار معتمد لكبرى المنظمات',
      department: 'بيوت الخبرة العالمية',
      responsibilities: 'تقديم دراسات جدوى كبرى، التحكيم في المسابقات الدولية، وتقديم استشارات استراتيجية.',
      minDaysWorked: 46,
      minSkill: 72,
      basePay: 3200,
      energyCost: 26,
      hoursRequired: 4.0,
      requiredAssets: ['laptop'],
      perkDescription: 'مكانة دولية مرموقة ودخل استثنائي يمنحك الاستقلال المالي التام.'
    }
  }
};
