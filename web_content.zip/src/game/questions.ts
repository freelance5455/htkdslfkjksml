import type { Question, Tier } from './types';

const Q = (
  q: string,
  a: [string, string, string],
  tier: Tier,
  cat: string,
): Question => ({ q, a, c: 0, tier, cat });
// NOTE: the first answer in each tuple is the correct one; answers are shuffled at spawn time.

export const QUESTIONS: Question[] = [
  // ---------- TIER 1 ----------
  Q('Who built the ark?', ['Noah', 'Moses', 'Abraham'], 1, 'Old Testament'),
  Q('Who was swallowed by a great fish?', ['Jonah', 'Peter', 'Elijah'], 1, 'Old Testament'),
  Q('In how many days did God create the world?', ['6', '7', '40'], 1, 'Numbers'),
  Q('Who was the first man?', ['Adam', 'Cain', 'Seth'], 1, 'People'),
  Q('What did David use to defeat Goliath?', ['Sling', 'Sword', 'Spear'], 1, 'Old Testament'),
  Q('Who led Israel out of Egypt?', ['Moses', 'Joshua', 'Aaron'], 1, 'People'),
  Q('Where was Jesus born?', ['Bethlehem', 'Nazareth', 'Jerusalem'], 1, 'Places'),
  Q('How many disciples did Jesus choose?', ['12', '10', '7'], 1, 'Numbers'),
  Q('Who betrayed Jesus?', ['Judas', 'Peter', 'Thomas'], 1, 'New Testament'),
  Q('What is the first book of the Bible?', ['Genesis', 'Exodus', 'Matthew'], 1, 'Books'),
  Q('What is the last book of the Bible?', ['Revelation', 'Jude', 'Acts'], 1, 'Books'),
  Q("Who was thrown into the lions' den?", ['Daniel', 'Joseph', 'Samson'], 1, 'Old Testament'),
  Q('Jesus turned water into what?', ['Wine', 'Bread', 'Oil'], 1, 'Miracles'),
  Q('Who was the strongest man in the Bible?', ['Samson', 'Goliath', 'Saul'], 1, 'People'),
  Q('Which sea did Moses part?', ['Red Sea', 'Dead Sea', 'Galilee'], 1, 'Places'),
  Q('Who baptized Jesus?', ['John', 'Peter', 'James'], 1, 'New Testament'),
  Q('How many plagues struck Egypt?', ['10', '7', '12'], 1, 'Numbers'),
  Q('Jesus fed 5,000 with five loaves and how many fish?', ['2', '5', '7'], 1, 'Miracles'),
  Q("Who was Adam's wife?", ['Eve', 'Sarah', 'Ruth'], 1, 'People'),
  Q('Which bird brought Noah an olive leaf?', ['Dove', 'Eagle', 'Sparrow'], 1, 'Old Testament'),
  Q('Who received the Ten Commandments?', ['Moses', 'Abraham', 'David'], 1, 'Old Testament'),
  Q('Who denied Jesus three times?', ['Peter', 'John', 'Andrew'], 1, 'New Testament'),
  Q('In which garden did Adam and Eve live?', ['Eden', 'Gethsemane', 'Zion'], 1, 'Places'),
  Q('Who was the mother of Jesus?', ['Mary', 'Martha', 'Elizabeth'], 1, 'People'),
  Q("What was Joseph, Mary's husband, by trade?", ['Carpenter', 'Fisherman', 'Shepherd'], 1, 'New Testament'),
  Q('Which disciple walked on water toward Jesus?', ['Peter', 'John', 'Philip'], 1, 'Miracles'),
  Q('Who was sold into slavery by his brothers?', ['Joseph', 'Benjamin', 'Jacob'], 1, 'Old Testament'),
  Q('How many days and nights did it rain in the flood?', ['40', '7', '100'], 1, 'Numbers'),
  Q('What animal did Jesus ride into Jerusalem?', ['Donkey', 'Horse', 'Camel'], 1, 'New Testament'),
  Q('Who was the first king of Israel?', ['Saul', 'David', 'Solomon'], 1, 'People'),
  Q('How many books are in the Bible?', ['66', '39', '72'], 1, 'Numbers'),
  Q('Which brother did Cain kill?', ['Abel', 'Seth', 'Enoch'], 1, 'Old Testament'),
  Q('Which king was famous for his wisdom?', ['Solomon', 'Samuel', 'Saul'], 1, 'People'),
  Q('On which day did Jesus rise from the dead?', ['Third', 'First', 'Seventh'], 1, 'New Testament'),
  Q('Who had a coat of many colors?', ['Joseph', 'Jacob', 'Judah'], 1, 'Old Testament'),
  Q('Where did Jesus grow up?', ['Nazareth', 'Bethlehem', 'Capernaum'], 1, 'Places'),
  Q('What is the shortest verse in the Bible?', ['Jesus wept', 'Pray always', 'Rejoice'], 1, 'Verses'),
  Q('Who was the oldest man in the Bible?', ['Methuselah', 'Noah', 'Adam'], 1, 'People'),
  Q('How many years did Israel wander in the wilderness?', ['40', '20', '70'], 1, 'Numbers'),
  Q("Which city's walls fell after Israel marched around it?", ['Jericho', 'Ai', 'Babylon'], 1, 'Places'),
  Q('Who led Israel after Moses died?', ['Joshua', 'Caleb', 'Aaron'], 1, 'People'),
  Q("Who was Moses' brother?", ['Aaron', 'Joshua', 'Caleb'], 1, 'People'),
  Q("What did Moses' staff turn into?", ['Snake', 'Bird', 'Fire'], 1, 'Miracles'),
  Q('Which queen saved her people from Haman?', ['Esther', 'Ruth', 'Deborah'], 1, 'Old Testament'),
  Q('Which disciple doubted until he saw the risen Jesus?', ['Thomas', 'Philip', 'Andrew'], 1, 'New Testament'),
  Q('Who followed a star to find baby Jesus?', ['Wise men', 'Shepherds', 'Priests'], 1, 'New Testament'),
  Q("Where did Jesus' first miracle take place?", ['A wedding', 'A funeral', 'A temple'], 1, 'Miracles'),
  Q('In which river was Jesus baptized?', ['Jordan', 'Nile', 'Euphrates'], 1, 'Places'),
  Q('How many Gospels are there?', ['4', '3', '5'], 1, 'Books'),
  Q('The wise man built his house on what?', ['Rock', 'Sand', 'Clay'], 1, 'Parables'),
  Q('Who helped the beaten traveler in the parable?', ['Samaritan', 'Priest', 'Levite'], 1, 'Parables'),
  Q('What did the Prodigal Son end up feeding?', ['Pigs', 'Sheep', 'Goats'], 1, 'Parables'),
  Q('How many pieces of silver did Judas receive?', ['30', '12', '50'], 1, 'Numbers'),
  Q('What food fell from heaven in the wilderness?', ['Manna', 'Figs', 'Honey'], 1, 'Old Testament'),
  Q('Which mountain did Moses receive the law on?', ['Sinai', 'Carmel', 'Zion'], 1, 'Places'),
  Q('Who made the golden calf?', ['Aaron', 'Moses', 'Joshua'], 1, 'Old Testament'),
  Q('"The Lord is my shepherd" is from which Psalm?', ['23', '1', '100'], 1, 'Verses'),
  Q('Who was the baby found in a basket among the reeds?', ['Moses', 'Samuel', 'Isaac'], 1, 'Old Testament'),
  Q('Which book comes right after Matthew?', ['Mark', 'Luke', 'John'], 1, 'Books'),
  Q('Where did Jesus pray before His arrest?', ['Gethsemane', 'Eden', 'Bethany'], 1, 'Places'),

  // ---------- TIER 2 ----------
  Q('Who was blinded on the road to Damascus?', ['Saul', 'Barnabas', 'Silas'], 2, 'New Testament'),
  Q('What tree did Zacchaeus climb?', ['Sycamore', 'Olive', 'Fig'], 2, 'New Testament'),
  Q("Who was Abraham's wife?", ['Sarah', 'Rebekah', 'Rachel'], 2, 'People'),
  Q('What did God create on the first day?', ['Light', 'Sun', 'Animals'], 2, 'Old Testament'),
  Q('Which son of David built the temple?', ['Solomon', 'Absalom', 'Nathan'], 2, 'People'),
  Q('Which prophet went to heaven in a whirlwind?', ['Elijah', 'Elisha', 'Isaiah'], 2, 'Old Testament'),
  Q('What did Esau sell for a bowl of stew?', ['Birthright', 'Coat', 'Land'], 2, 'Old Testament'),
  Q("Who interpreted Pharaoh's dreams?", ['Joseph', 'Daniel', 'Moses'], 2, 'Old Testament'),
  Q('Who wrestled with God all night?', ['Jacob', 'Esau', 'Isaac'], 2, 'Old Testament'),
  Q('Who was the mother of Samuel?', ['Hannah', 'Naomi', 'Deborah'], 2, 'People'),
  Q('Which queen visited Solomon?', ['Sheba', 'Vashti', 'Jezebel'], 2, 'People'),
  Q("What was Paul's name before he was Paul?", ['Saul', 'Simon', 'Silas'], 2, 'People'),
  Q('Which sea did Jesus calm with a word?', ['Galilee', 'Red Sea', 'Dead Sea'], 2, 'Miracles'),
  Q("Who was Ruth's mother-in-law?", ['Naomi', 'Orpah', 'Miriam'], 2, 'People'),
  Q("Who was Moses' sister?", ['Miriam', 'Deborah', 'Leah'], 2, 'People'),
  Q("Who was Isaac's father?", ['Abraham', 'Jacob', 'Noah'], 2, 'People'),
  Q('Who was the first Christian martyr?', ['Stephen', 'James', 'Paul'], 2, 'New Testament'),
  Q('Who wrote the book of Revelation?', ['John', 'Paul', 'Peter'], 2, 'Books'),
  Q('Whom did Jesus raise after four days in the tomb?', ['Lazarus', 'Jairus', 'Simon'], 2, 'Miracles'),
  Q('At which tower were languages confused?', ['Babel', 'Babylon', 'Zion'], 2, 'Places'),
  Q('Which animal spoke to Balaam?', ['Donkey', 'Serpent', 'Raven'], 2, 'Old Testament'),
  Q('How many books are in the Old Testament?', ['39', '27', '46'], 2, 'Numbers'),
  Q('How many books are in the New Testament?', ['27', '39', '21'], 2, 'Numbers'),
  Q('Jesus compared faith to which seed?', ['Mustard', 'Wheat', 'Fig'], 2, 'Parables'),
  Q("Who was the Roman governor at Jesus' trial?", ['Pilate', 'Herod', 'Caesar'], 2, 'New Testament'),
  Q("Who carried Jesus' cross?", ['Simon', 'Peter', 'Joseph'], 2, 'New Testament'),
  Q('Where was Jesus crucified?', ['Golgotha', 'Sinai', 'Olivet'], 2, 'Places'),
  Q('Who first saw the risen Jesus?', ['Mary Magdalene', 'Peter', 'John'], 2, 'New Testament'),
  Q('How many days after rising did Jesus ascend?', ['40', '3', '50'], 2, 'Numbers'),
  Q('On which feast day did the Holy Spirit come in Acts?', ['Pentecost', 'Passover', 'Purim'], 2, 'New Testament'),
  Q('Which twin was hairy?', ['Esau', 'Jacob', 'Reuben'], 2, 'People'),
  Q('What instrument did David play for Saul?', ['Harp', 'Trumpet', 'Drum'], 2, 'Old Testament'),
  Q('How did God first speak to Moses?', ['Burning bush', 'A dream', 'A donkey'], 2, 'Old Testament'),
  Q('Samson slew a thousand men with what?', ['Jawbone', 'Sword', 'Club'], 2, 'Old Testament'),
  Q('Who betrayed Samson?', ['Delilah', 'Jezebel', 'Rahab'], 2, 'People'),
  Q('Who hid the spies in Jericho?', ['Rahab', 'Ruth', 'Rachel'], 2, 'Old Testament'),
  Q('Which judge defeated Midian with 300 men?', ['Gideon', 'Samson', 'Barak'], 2, 'Old Testament'),
  Q('Which woman judged Israel?', ['Deborah', 'Jael', 'Hannah'], 2, 'People'),
  Q('How many sons did Jacob have?', ['12', '10', '7'], 2, 'Numbers'),
  Q('Which prophet saw a valley of dry bones?', ['Ezekiel', 'Isaiah', 'Daniel'], 2, 'Old Testament'),
  Q('Who was thrown into the fiery furnace with Meshach?', ['Shadrach', 'Daniel', 'Joseph'], 2, 'Old Testament'),
  Q('Which Gospel writer was a physician?', ['Luke', 'Mark', 'Matthew'], 2, 'Books'),
  Q('Who wrote the book of Acts?', ['Luke', 'Paul', 'Peter'], 2, 'Books'),
  Q('What is the longest chapter in the Bible?', ['Psalm 119', 'Psalm 23', 'Genesis 1'], 2, 'Books'),
  Q('Who was the son of Abraham and Hagar?', ['Ishmael', 'Isaac', 'Jacob'], 2, 'People'),
  Q("Who was Isaac's wife?", ['Rebekah', 'Rachel', 'Leah'], 2, 'People'),
  Q('What did Jacob see in his dream at Bethel?', ['A ladder', 'A chariot', 'A throne'], 2, 'Old Testament'),
  Q('Which prophet anointed both Saul and David?', ['Samuel', 'Nathan', 'Elijah'], 2, 'People'),
  Q("Who was David's closest friend?", ['Jonathan', 'Saul', 'Joab'], 2, 'People'),
  Q('Which king dreamed of a giant statue?', ['Nebuchadnezzar', 'Darius', 'Cyrus'], 2, 'Old Testament'),
  Q('Who rebuilt the walls of Jerusalem?', ['Nehemiah', 'Ezra', 'Haggai'], 2, 'People'),
  Q('How many chapters are in Psalms?', ['150', '100', '119'], 2, 'Numbers'),
  Q('Which prophet was fed by ravens?', ['Elijah', 'Elisha', 'Jonah'], 2, 'Miracles'),
  Q('Who was healed by washing in the Jordan seven times?', ['Naaman', 'Gehazi', 'Job'], 2, 'Miracles'),
  Q('Who lost everything yet stayed faithful to God?', ['Job', 'Jonah', 'Joel'], 2, 'People'),
  Q('Who was released instead of Jesus?', ['Barabbas', 'Barnabas', 'Bartimaeus'], 2, 'New Testament'),
  Q('Which apostle was a tentmaker?', ['Paul', 'Peter', 'James'], 2, 'People'),
  Q('Which apostle was a tax collector?', ['Matthew', 'Luke', 'Mark'], 2, 'People'),
  Q('Who came to Jesus at night to ask questions?', ['Nicodemus', 'Zacchaeus', 'Caiaphas'], 2, 'New Testament'),
  Q('Which piece of armor is "of salvation"?', ['Helmet', 'Shield', 'Belt'], 2, 'Verses'),
  Q('The sword of the Spirit is the what?', ['Word of God', 'Prayer', 'Faith'], 2, 'Verses'),
  Q('Which is the first fruit of the Spirit listed?', ['Love', 'Joy', 'Peace'], 2, 'Verses'),
  Q("Which book tells of Israel's exit from Egypt?", ['Exodus', 'Numbers', 'Judges'], 2, 'Books'),
  Q('Which prophet was told to marry Gomer?', ['Hosea', 'Amos', 'Joel'], 2, 'Old Testament'),
  Q('Who saw handwriting appear on a wall?', ['Belshazzar', 'Cyrus', 'Xerxes'], 2, 'Old Testament'),
  Q('What was the name of the blind beggar Jesus healed?', ['Bartimaeus', 'Barabbas', 'Bartholomew'], 2, 'Miracles'),
  Q('What did Peter find in the mouth of a fish?', ['A coin', 'A pearl', 'A ring'], 2, 'Miracles'),
  Q("Who was Timothy's mentor?", ['Paul', 'Peter', 'John'], 2, 'People'),

  // ---------- TIER 3 ----------
  Q('Where was Paul shipwrecked?', ['Malta', 'Crete', 'Cyprus'], 3, 'Places'),
  Q('Who was the father of John the Baptist?', ['Zechariah', 'Joseph', 'Simeon'], 3, 'People'),
  Q("Who asked Pilate for Jesus' body?", ['Joseph', 'Nicodemus', 'Simon'], 3, 'New Testament'),
  Q('Bathsheba was first married to whom?', ['Uriah', 'Nabal', 'Ahab'], 3, 'People'),
  Q("Who was Jacob's favorite wife?", ['Rachel', 'Leah', 'Bilhah'], 3, 'People'),
  Q('Who was the wife of King Ahab?', ['Jezebel', 'Athaliah', 'Michal'], 3, 'People'),
  Q('Who replaced Judas as an apostle?', ['Matthias', 'Barnabas', 'Silas'], 3, 'New Testament'),
  Q('In which city did believers first get called Christians?', ['Antioch', 'Rome', 'Ephesus'], 3, 'Places'),
  Q('Which island was John on when he wrote Revelation?', ['Patmos', 'Crete', 'Rhodes'], 3, 'Places'),
  Q('How many churches are addressed in Revelation?', ['7', '12', '3'], 3, 'Numbers'),
  Q("Who was Ruth's second husband?", ['Boaz', 'Obed', 'Elimelech'], 3, 'People'),
  Q('What was the name of the king who ordered Daniel into the den?', ['Darius', 'Cyrus', 'Belshazzar'], 3, 'Old Testament'),
  Q('Which prophet was taken to Babylon as a youth?', ['Daniel', 'Jeremiah', 'Amos'], 3, 'People'),
  Q('Who was the mother of John the Baptist?', ['Elizabeth', 'Anna', 'Joanna'], 3, 'People'),
  Q('Which disciple brought the boy with loaves and fish?', ['Andrew', 'Philip', 'James'], 3, 'New Testament'),
  Q('How old was Abraham when Isaac was born?', ['100', '75', '90'], 3, 'Numbers'),
  Q('How many years did Solomon take to build the temple?', ['7', '12', '40'], 3, 'Numbers'),
  Q('Which book comes right after Song of Songs?', ['Isaiah', 'Jeremiah', 'Ezekiel'], 3, 'Books'),
  Q('What is the shortest book in the Old Testament?', ['Obadiah', 'Jonah', 'Haggai'], 3, 'Books'),
  Q('Who was struck dead for lying about a land sale?', ['Ananias', 'Simon', 'Demas'], 3, 'New Testament'),
  Q("Who was Paul's companion on his first journey?", ['Barnabas', 'Silas', 'Timothy'], 3, 'People'),
  Q('Which Old Testament book never mentions God by name?', ['Esther', 'Ruth', 'Job'], 3, 'Books'),
  Q('Who was the priest that raised Samuel?', ['Eli', 'Elkanah', 'Zadok'], 3, 'People'),
  Q("What was the name of Abraham's nephew?", ['Lot', 'Laban', 'Eliezer'], 3, 'People'),
  Q("Which of Jacob's sons was sold by the others?", ['Joseph', 'Reuben', 'Levi'], 3, 'People'),
  Q('Which prophet was commanded to go to Nineveh?', ['Jonah', 'Nahum', 'Micah'], 3, 'Old Testament'),
  Q('Who was the tax collector who hosted Jesus in Jericho?', ['Zacchaeus', 'Levi', 'Matthew'], 3, 'New Testament'),
  Q('How many people were saved on the ark?', ['8', '6', '12'], 3, 'Numbers'),
  Q("What was the name of Moses' wife?", ['Zipporah', 'Miriam', 'Hagar'], 3, 'People'),
  Q("Who was Moses' father-in-law?", ['Jethro', 'Laban', 'Eli'], 3, 'People'),
  Q('Which king wrote much of Ecclesiastes?', ['Solomon', 'David', 'Hezekiah'], 3, 'Books'),
  Q('Where did Elijah defeat the prophets of Baal?', ['Mt. Carmel', 'Mt. Sinai', 'Mt. Nebo'], 3, 'Places'),
  Q('From which mountain did Moses view the Promised Land?', ['Nebo', 'Sinai', 'Hermon'], 3, 'Places'),
  Q('Who was the runaway slave in the letter to Philemon?', ['Onesimus', 'Tychicus', 'Epaphras'], 3, 'People'),
  Q('Who was the seller of purple cloth converted by Paul?', ['Lydia', 'Priscilla', 'Phoebe'], 3, 'People'),
  Q('Which book records the Sermon on the Mount?', ['Matthew', 'Mark', 'John'], 3, 'Books'),
  Q("Which king saw the sun's shadow go back ten steps?", ['Hezekiah', 'Josiah', 'Uzziah'], 3, 'Miracles'),
  Q('How many stones did David pick up to face Goliath?', ['5', '3', '7'], 3, 'Numbers'),
  Q('Who was the first judge of Israel?', ['Othniel', 'Ehud', 'Gideon'], 3, 'People'),
  Q('Which two books are named after women?', ['Ruth & Esther', 'Ruth & Mary', 'Esther & Eve'], 3, 'Books'),
];

/** Draws questions without repeats, weighted by the current level. */
export class QuestionDeck {
  private pools: Record<Tier, Question[]> = { 1: [], 2: [], 3: [] };

  constructor() {
    this.reset();
  }

  reset() {
    this.pools = { 1: [], 2: [], 3: [] };
    for (const t of [1, 2, 3] as Tier[]) this.refill(t);
  }

  private refill(t: Tier) {
    const arr = QUESTIONS.filter((q) => q.tier === t).slice();
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    this.pools[t] = arr;
  }

  draw(level: number): Question {
    let tier: Tier;
    const r = Math.random();
    if (level < 3) tier = 1;
    else if (level < 7) tier = r < 0.55 ? 1 : 2;
    else if (level < 12) tier = r < 0.25 ? 1 : r < 0.75 ? 2 : 3;
    else tier = r < 0.15 ? 1 : r < 0.55 ? 2 : 3;
    if (this.pools[tier].length === 0) this.refill(tier);
    return this.pools[tier].pop() as Question;
  }
}
