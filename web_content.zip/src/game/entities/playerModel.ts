import * as THREE from 'three';
import { EquipmentState } from '../types';

export class PlayerModel {
  public readonly root = new THREE.Group();
  private bodyGroup = new THREE.Group();
  private leftLegPivot = new THREE.Group();
  private rightLegPivot = new THREE.Group();
  private leftArmPivot = new THREE.Group();
  private rightArmPivot = new THREE.Group();
  private capePivot = new THREE.Group();
  private headGroup = new THREE.Group();
  private contactShadow: THREE.Mesh;

  // Dynamic equipment visual nodes
  private tunicMat: THREE.MeshStandardMaterial;
  private cloakMat: THREE.MeshStandardMaterial;
  private chestPlate: THREE.Mesh;
  private chestPlateMat: THREE.MeshStandardMaterial;
  private hoodMesh: THREE.Mesh;
  private visorMesh: THREE.Mesh;
  private steelHelmGroup = new THREE.Group();
  private swordGroup = new THREE.Group();
  private bladeMesh: THREE.Mesh;
  private bladeMat: THREE.MeshStandardMaterial;
  private gemMat: THREE.MeshStandardMaterial;
  private axeHeadMesh: THREE.Mesh;
  private shieldGroup = new THREE.Group();
  private shieldFaceMat: THREE.MeshStandardMaterial;
  private tomeMesh: THREE.Mesh;

  private walkPhase = 0;
  private attackTimer = 0;
  private castTimer = 0;
  private hurtTimer = 0;
  private isBlocking = false;
  private disposables: Array<{ dispose: () => void }> = [];

  constructor() {
    this.tunicMat = new THREE.MeshStandardMaterial({
      color: 0x1e4d6b,
      roughness: 0.82,
      metalness: 0.05,
    });
    this.cloakMat = new THREE.MeshStandardMaterial({
      color: 0x7a1f32,
      roughness: 0.88,
      metalness: 0.02,
      side: THREE.DoubleSide,
    });
    const leatherMat = new THREE.MeshStandardMaterial({
      color: 0x4a3121,
      roughness: 0.68,
      metalness: 0.08,
    });
    this.chestPlateMat = new THREE.MeshStandardMaterial({
      color: 0x9fb0c4,
      roughness: 0.28,
      metalness: 0.86,
    });
    const steelMat = this.chestPlateMat;
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xe6b84c,
      roughness: 0.22,
      metalness: 0.9,
    });
    const skinMat = new THREE.MeshStandardMaterial({
      color: 0xe8be9e,
      roughness: 0.72,
      metalness: 0.0,
    });
    this.gemMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0ea5e9,
      emissiveIntensity: 1.4,
      roughness: 0.2,
      metalness: 0.4,
    });
    this.bladeMat = new THREE.MeshStandardMaterial({
      color: 0xcbd5e1,
      roughness: 0.24,
      metalness: 0.88,
    });
    this.shieldFaceMat = new THREE.MeshStandardMaterial({
      color: 0x78350f,
      roughness: 0.6,
      metalness: 0.2,
    });

    // Soft radial contact shadow under feet
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 64;
    shadowCanvas.height = 64;
    const sctx = shadowCanvas.getContext('2d')!;
    const grad = sctx.createRadialGradient(32, 32, 4, 32, 32, 30);
    grad.addColorStop(0, 'rgba(0,0,0,0.48)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    sctx.fillStyle = grad;
    sctx.fillRect(0, 0, 64, 64);
    const shadowTex = new THREE.CanvasTexture(shadowCanvas);

    const shadowGeo = new THREE.PlaneGeometry(1.15, 1.15);
    shadowGeo.rotateX(-Math.PI / 2);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
    });
    this.contactShadow = new THREE.Mesh(shadowGeo, shadowMat);
    this.contactShadow.position.y = 0.025;
    this.root.add(this.contactShadow);

    this.disposables.push(
      this.tunicMat,
      this.cloakMat,
      leatherMat,
      this.chestPlateMat,
      goldMat,
      skinMat,
      this.gemMat,
      this.bladeMat,
      this.shieldFaceMat,
      shadowTex,
      shadowGeo,
      shadowMat,
    );

    // Legs & Boots
    const thighGeo = new THREE.BoxGeometry(0.22, 0.42, 0.22);
    const bootGeo = new THREE.BoxGeometry(0.25, 0.34, 0.3);
    this.disposables.push(thighGeo, bootGeo);

    const buildLeg = (pivot: THREE.Group, xOffset: number) => {
      pivot.position.set(xOffset, 0.72, 0);
      const thigh = new THREE.Mesh(thighGeo, leatherMat);
      thigh.position.set(0, -0.21, 0);
      const boot = new THREE.Mesh(bootGeo, steelMat);
      boot.position.set(0, -0.55, 0.03);
      thigh.castShadow = true;
      boot.castShadow = true;
      pivot.add(thigh, boot);
      this.bodyGroup.add(pivot);
    };
    buildLeg(this.leftLegPivot, -0.15);
    buildLeg(this.rightLegPivot, 0.15);

    // Torso, Chestplate, Belt
    const torsoGeo = new THREE.BoxGeometry(0.56, 0.68, 0.32);
    const chestPlateGeo = new THREE.BoxGeometry(0.58, 0.38, 0.35);
    const beltGeo = new THREE.BoxGeometry(0.58, 0.11, 0.34);
    const buckleGeo = new THREE.BoxGeometry(0.14, 0.13, 0.06);
    this.disposables.push(torsoGeo, chestPlateGeo, beltGeo, buckleGeo);

    const torso = new THREE.Mesh(torsoGeo, this.tunicMat);
    torso.position.set(0, 1.06, 0);
    torso.castShadow = true;

    this.chestPlate = new THREE.Mesh(chestPlateGeo, this.chestPlateMat);
    this.chestPlate.position.set(0, 1.18, 0);
    this.chestPlate.castShadow = true;

    const belt = new THREE.Mesh(beltGeo, leatherMat);
    belt.position.set(0, 0.76, 0);
    const buckle = new THREE.Mesh(buckleGeo, goldMat);
    buckle.position.set(0, 0.76, 0.17);

    this.bodyGroup.add(torso, this.chestPlate, belt, buckle);

    // Pauldrons
    const pauldronGeo = new THREE.SphereGeometry(0.19, 8, 6, 0, Math.PI * 2, 0, Math.PI * 0.65);
    this.disposables.push(pauldronGeo);
    const leftPauldron = new THREE.Mesh(pauldronGeo, steelMat);
    leftPauldron.position.set(-0.37, 1.37, 0);
    leftPauldron.rotation.z = 0.25;
    const rightPauldron = new THREE.Mesh(pauldronGeo, steelMat);
    rightPauldron.position.set(0.37, 1.37, 0);
    rightPauldron.rotation.z = -0.25;
    this.bodyGroup.add(leftPauldron, rightPauldron);

    // Flowing Cloak
    const capeGeo = new THREE.PlaneGeometry(0.58, 0.96, 1, 2);
    capeGeo.translate(0, -0.48, 0);
    this.disposables.push(capeGeo);
    const cape = new THREE.Mesh(capeGeo, this.cloakMat);
    cape.castShadow = true;
    this.capePivot.position.set(0, 1.36, -0.18);
    this.capePivot.rotation.x = 0.14;
    this.capePivot.add(cape);
    this.bodyGroup.add(this.capePivot);

    // Arms & Gauntlets
    const upperArmGeo = new THREE.BoxGeometry(0.17, 0.34, 0.17);
    const gauntletGeo = new THREE.BoxGeometry(0.19, 0.3, 0.19);
    this.disposables.push(upperArmGeo, gauntletGeo);

    const buildArm = (pivot: THREE.Group, xOffset: number) => {
      pivot.position.set(xOffset, 1.32, 0);
      const upper = new THREE.Mesh(upperArmGeo, this.tunicMat);
      upper.position.set(0, -0.17, 0);
      const gauntlet = new THREE.Mesh(gauntletGeo, steelMat);
      gauntlet.position.set(0, -0.46, 0);
      upper.castShadow = true;
      gauntlet.castShadow = true;
      pivot.add(upper, gauntlet);
      this.bodyGroup.add(pivot);
    };
    buildArm(this.leftArmPivot, -0.39);
    buildArm(this.rightArmPivot, 0.39);

    // Main Hand Weapon Group (Sword or Axe)
    const hiltGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.24, 6);
    const guardGeo = new THREE.BoxGeometry(0.28, 0.05, 0.07);
    const bladeGeo = new THREE.BoxGeometry(0.08, 0.92, 0.03);
    const gemGeo = new THREE.OctahedronGeometry(0.045, 0);
    const axeHeadGeo = new THREE.BoxGeometry(0.32, 0.32, 0.05);
    this.disposables.push(hiltGeo, guardGeo, bladeGeo, gemGeo, axeHeadGeo);

    this.swordGroup.position.set(0, -0.58, 0.12);
    this.swordGroup.rotation.x = Math.PI * 0.42;

    const hilt = new THREE.Mesh(hiltGeo, leatherMat);
    const guard = new THREE.Mesh(guardGeo, goldMat);
    guard.position.y = 0.12;
    this.bladeMesh = new THREE.Mesh(bladeGeo, this.bladeMat);
    this.bladeMesh.position.y = 0.6;
    this.bladeMesh.castShadow = true;
    const gem = new THREE.Mesh(gemGeo, this.gemMat);
    gem.position.set(0, 0.12, 0.045);

    this.axeHeadMesh = new THREE.Mesh(axeHeadGeo, this.bladeMat);
    this.axeHeadMesh.position.set(0.14, 0.85, 0);
    this.axeHeadMesh.rotation.z = 0.35;
    this.axeHeadMesh.visible = false;

    this.swordGroup.add(hilt, guard, this.bladeMesh, gem, this.axeHeadMesh);
    this.rightArmPivot.add(this.swordGroup);

    // Off-hand Shield & Arcane Tome attached to Left Arm
    const shieldBodyGeo = new THREE.BoxGeometry(0.08, 0.56, 0.46);
    const shieldRimGeo = new THREE.BoxGeometry(0.1, 0.62, 0.52);
    const shieldBossGeo = new THREE.SphereGeometry(0.09, 6, 5);
    const tomeGeo = new THREE.BoxGeometry(0.1, 0.34, 0.26);
    this.disposables.push(shieldBodyGeo, shieldRimGeo, shieldBossGeo, tomeGeo);

    this.shieldGroup.position.set(-0.12, -0.44, 0.12);
    const shieldRim = new THREE.Mesh(shieldRimGeo, goldMat);
    const shieldBody = new THREE.Mesh(shieldBodyGeo, this.shieldFaceMat);
    shieldBody.position.x = -0.015;
    const shieldBoss = new THREE.Mesh(shieldBossGeo, steelMat);
    shieldBoss.position.x = -0.06;
    this.shieldGroup.add(shieldRim, shieldBody, shieldBoss);
    this.shieldGroup.visible = false;
    this.leftArmPivot.add(this.shieldGroup);

    this.tomeMesh = new THREE.Mesh(tomeGeo, this.gemMat);
    this.tomeMesh.position.set(-0.08, -0.48, 0.14);
    this.tomeMesh.visible = false;
    this.leftArmPivot.add(this.tomeMesh);

    // Head, Hood, Visor & Optional Full Steel Helm
    const headGeo = new THREE.BoxGeometry(0.36, 0.36, 0.36);
    const hoodGeo = new THREE.ConeGeometry(0.31, 0.36, 6);
    const eyeGeo = new THREE.BoxGeometry(0.08, 0.045, 0.03);
    const visorGeo = new THREE.BoxGeometry(0.38, 0.14, 0.38);
    const crestGeo = new THREE.BoxGeometry(0.08, 0.22, 0.38);
    const domeGeo = new THREE.BoxGeometry(0.4, 0.24, 0.4);
    this.disposables.push(headGeo, hoodGeo, eyeGeo, visorGeo, crestGeo, domeGeo);

    this.headGroup.position.set(0, 1.58, 0);
    const head = new THREE.Mesh(headGeo, skinMat);
    head.castShadow = true;

    this.hoodMesh = new THREE.Mesh(hoodGeo, this.cloakMat);
    this.hoodMesh.position.set(0, 0.24, -0.02);
    this.hoodMesh.castShadow = true;

    this.visorMesh = new THREE.Mesh(visorGeo, steelMat);
    this.visorMesh.position.set(0, 0.09, 0);

    const helmDome = new THREE.Mesh(domeGeo, steelMat);
    helmDome.position.set(0, 0.16, 0);
    const helmCrest = new THREE.Mesh(crestGeo, goldMat);
    helmCrest.position.set(0, 0.32, -0.02);
    this.steelHelmGroup.add(helmDome, helmCrest);
    this.steelHelmGroup.visible = false;

    const eyeL = new THREE.Mesh(eyeGeo, this.gemMat);
    eyeL.position.set(-0.08, 0.02, 0.185);
    const eyeR = new THREE.Mesh(eyeGeo, this.gemMat);
    eyeR.position.set(0.08, 0.02, 0.185);

    this.headGroup.add(head, this.hoodMesh, this.visorMesh, this.steelHelmGroup, eyeL, eyeR);
    this.bodyGroup.add(this.headGroup);

    this.root.add(this.bodyGroup);
  }

  public syncEquipmentVisuals(equipment: EquipmentState): void {
    // 1. Main Hand Weapon
    const main = equipment.mainHand;
    this.swordGroup.visible = Boolean(main);
    this.axeHeadMesh.visible = main === 'ember_axe';
    if (main === 'runic_blade') {
      this.bladeMat.color.setHex(0x67e8f9);
      this.gemMat.color.setHex(0x38bdf8);
      this.gemMat.emissive.setHex(0x0ea5e9);
      this.bladeMesh.scale.set(1.05, 1.08, 1);
    } else if (main === 'ember_axe') {
      this.bladeMat.color.setHex(0xf97316);
      this.gemMat.color.setHex(0xfb923c);
      this.gemMat.emissive.setHex(0xea580c);
      this.bladeMesh.scale.set(0.8, 1.0, 1);
    } else if (main === 'skeleton_king_blade') {
      this.bladeMat.color.setHex(0xf1f5f9);
      this.gemMat.color.setHex(0xe879f9);
      this.gemMat.emissive.setHex(0xc026d3);
      this.bladeMesh.scale.set(1.3, 1.18, 1.1);
    } else {
      this.bladeMat.color.setHex(0xcbd5e1);
      this.gemMat.color.setHex(0x38bdf8);
      this.gemMat.emissive.setHex(0x0ea5e9);
      this.bladeMesh.scale.set(1, 1, 1);
    }

    // 2. Off Hand Shield / Tome
    const off = equipment.offHand;
    this.shieldGroup.visible = off === 'oak_shield' || off === 'bone_plated_shield';
    this.tomeMesh.visible = off === 'arcane_tome';
    if (off === 'bone_plated_shield') {
      this.shieldFaceMat.color.setHex(0xe2e8f0);
    } else {
      this.shieldFaceMat.color.setHex(0x78350f);
    }

    // 3. Helmet
    const helm = equipment.helmet;
    if (helm === 'steel_helm') {
      this.hoodMesh.visible = false;
      this.visorMesh.visible = true;
      this.steelHelmGroup.visible = true;
    } else if (helm === 'ranger_hood') {
      this.hoodMesh.visible = true;
      this.cloakMat.color.setHex(0x166534);
      this.visorMesh.visible = false;
      this.steelHelmGroup.visible = false;
    } else {
      this.hoodMesh.visible = true;
      this.cloakMat.color.setHex(0x7a1f32);
      this.visorMesh.visible = true;
      this.steelHelmGroup.visible = false;
    }

    // 4. Chest Armor
    const chest = equipment.chest;
    if (chest === 'dragon_scale_mail') {
      this.chestPlate.visible = true;
      this.chestPlateMat.color.setHex(0xb91c1c);
      this.tunicMat.color.setHex(0x450a0a);
    } else if (chest === 'traveler_tunic') {
      this.chestPlate.visible = true;
      this.chestPlateMat.color.setHex(0x9fb0c4);
      this.tunicMat.color.setHex(0x1e4d6b);
    } else {
      this.chestPlate.visible = false;
      this.tunicMat.color.setHex(0x334155);
    }
  }

  public setShadowCasting(enabled: boolean): void {
    this.bodyGroup.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        (obj as THREE.Mesh).castShadow = enabled;
      }
    });
  }

  public setFirstPersonHidden(hidden: boolean): void {
    this.bodyGroup.visible = !hidden;
    this.contactShadow.visible = !hidden;
  }

  public setBlocking(blocking: boolean): void {
    this.isBlocking = blocking;
  }

  public triggerAttack(): void {
    this.attackTimer = 0.28;
  }

  public triggerCast(): void {
    this.castTimer = 0.34;
  }

  public triggerHurt(): void {
    this.hurtTimer = 0.22;
  }

  public updateAnimation(
    dt: number,
    horizontalSpeed: number,
    isGrounded: boolean,
    isSwimming: boolean,
    isDashing: boolean,
  ): void {
    const moveFactor = THREE.MathUtils.clamp(horizontalSpeed / 7.5, 0, 1.6);

    if (moveFactor > 0.05) {
      this.walkPhase += dt * (7.5 + moveFactor * 4.5);
    } else {
      this.walkPhase += dt * 2.1;
    }

    if (this.attackTimer > 0) this.attackTimer = Math.max(0, this.attackTimer - dt);
    if (this.castTimer > 0) this.castTimer = Math.max(0, this.castTimer - dt);
    if (this.hurtTimer > 0) this.hurtTimer = Math.max(0, this.hurtTimer - dt);

    const swing =
      isGrounded && !isSwimming ? Math.sin(this.walkPhase) * 0.65 * Math.min(moveFactor, 1.15) : 0;
    const armSwing = isSwimming ? Math.sin(this.walkPhase * 1.4) * 0.9 : swing;

    this.leftLegPivot.rotation.x = THREE.MathUtils.damp(
      this.leftLegPivot.rotation.x,
      isGrounded ? swing : -0.35,
      14,
      dt,
    );
    this.rightLegPivot.rotation.x = THREE.MathUtils.damp(
      this.rightLegPivot.rotation.x,
      isGrounded ? -swing : 0.28,
      14,
      dt,
    );

    if (this.isBlocking) {
      // Raised shield/left-guard stance across front
      this.leftArmPivot.rotation.x = THREE.MathUtils.damp(this.leftArmPivot.rotation.x, -0.95, 16, dt);
      this.leftArmPivot.rotation.z = THREE.MathUtils.damp(this.leftArmPivot.rotation.z, -0.45, 16, dt);
    } else if (this.castTimer > 0) {
      this.leftArmPivot.rotation.x = THREE.MathUtils.damp(this.leftArmPivot.rotation.x, -1.35, 18, dt);
      this.leftArmPivot.rotation.z = THREE.MathUtils.damp(this.leftArmPivot.rotation.z, 0.25, 18, dt);
    } else {
      this.leftArmPivot.rotation.x = THREE.MathUtils.damp(
        this.leftArmPivot.rotation.x,
        isSwimming ? armSwing : -armSwing * 0.85,
        14,
        dt,
      );
      this.leftArmPivot.rotation.z = THREE.MathUtils.damp(this.leftArmPivot.rotation.z, 0, 14, dt);
    }

    if (this.attackTimer > 0) {
      const p = 1 - this.attackTimer / 0.28;
      this.rightArmPivot.rotation.x = -1.6 + p * 2.4;
      this.rightArmPivot.rotation.z = -0.5 + p * 0.9;
    } else if (this.castTimer > 0) {
      this.rightArmPivot.rotation.x = THREE.MathUtils.damp(this.rightArmPivot.rotation.x, -1.4, 18, dt);
      this.rightArmPivot.rotation.z = THREE.MathUtils.damp(this.rightArmPivot.rotation.z, -0.25, 18, dt);
    } else if (this.isBlocking) {
      this.rightArmPivot.rotation.x = THREE.MathUtils.damp(this.rightArmPivot.rotation.x, -0.62, 16, dt);
      this.rightArmPivot.rotation.z = THREE.MathUtils.damp(this.rightArmPivot.rotation.z, 0.25, 16, dt);
    } else {
      this.rightArmPivot.rotation.x = THREE.MathUtils.damp(
        this.rightArmPivot.rotation.x,
        isSwimming ? -armSwing : armSwing * 0.75 - 0.15,
        14,
        dt,
      );
      this.rightArmPivot.rotation.z = THREE.MathUtils.damp(this.rightArmPivot.rotation.z, 0, 14, dt);
    }

    const bobY =
      moveFactor > 0.08 && isGrounded
        ? Math.abs(Math.cos(this.walkPhase)) * 0.06 * Math.min(moveFactor, 1)
        : Math.sin(this.walkPhase) * 0.015;
    this.bodyGroup.position.y = THREE.MathUtils.damp(
      this.bodyGroup.position.y,
      isSwimming ? -0.35 + Math.sin(this.walkPhase) * 0.06 : this.isBlocking ? bobY - 0.06 : bobY,
      12,
      dt,
    );

    const hurtPitch = this.hurtTimer > 0 ? -0.26 * (this.hurtTimer / 0.22) : 0;
    const targetLean =
      hurtPitch + (isDashing ? 0.35 : isSwimming ? 0.55 : this.isBlocking ? 0.08 : moveFactor * 0.14);
    this.bodyGroup.rotation.x = THREE.MathUtils.damp(this.bodyGroup.rotation.x, targetLean, 12, dt);

    const capeTarget =
      0.14 + moveFactor * 0.38 + Math.sin(this.walkPhase * 1.3) * (0.04 + moveFactor * 0.08);
    this.capePivot.rotation.x = THREE.MathUtils.damp(this.capePivot.rotation.x, capeTarget, 10, dt);
  }

  public dispose(): void {
    this.disposables.forEach((d) => d.dispose());
    this.disposables.length = 0;
  }
}

