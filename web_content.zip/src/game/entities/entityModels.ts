import * as THREE from 'three';
import {
  EntityArchetype,
  EntityModelStyle,
  EntityTemplateDef,
  NpcDefinition,
  SkeletonVariant,
} from '../types';

export interface BuiltEntityVisual {
  root: THREE.Group;
  primaryMat: THREE.MeshStandardMaterial;
  limbs: THREE.Object3D[];
  wings: THREE.Object3D[];
  detailParts: THREE.Object3D[];
  head?: THREE.Object3D;
  jaw?: THREE.Object3D;
  tail?: THREE.Object3D;
  segments?: THREE.Object3D[];
  auraRing?: THREE.Object3D;
  disposeMaterials: () => void;
}

function createExtrudedWingGeo(membrane: boolean): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  if (membrane) {
    shape.moveTo(0, 0);
    shape.lineTo(0.45, 0.22);
    shape.lineTo(1.05, 0.34);
    shape.lineTo(1.25, 0.04);
    shape.quadraticCurveTo(0.95, -0.26, 0.76, -0.14);
    shape.quadraticCurveTo(0.48, -0.34, 0.32, -0.16);
    shape.quadraticCurveTo(0.14, -0.28, 0, -0.08);
  } else {
    shape.moveTo(0, 0.05);
    shape.lineTo(0.42, 0.2);
    shape.lineTo(1.08, 0.14);
    shape.lineTo(1.2, -0.06);
    shape.lineTo(0.86, -0.22);
    shape.lineTo(0.42, -0.2);
    shape.lineTo(0, -0.1);
  }
  shape.closePath();
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: 0.045,
    bevelEnabled: true,
    bevelThickness: 0.015,
    bevelSize: 0.015,
    bevelSegments: 1,
  });
  geo.rotateX(Math.PI / 2);
  geo.translate(0, 0.02, 0);
  return geo;
}

function createButterflyWingGeo(): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(0, 0);
  shape.bezierCurveTo(0.3, 0.52, 0.96, 0.48, 0.92, 0.08);
  shape.bezierCurveTo(0.85, -0.16, 0.56, -0.12, 0.48, -0.2);
  shape.bezierCurveTo(0.7, -0.44, 0.32, -0.62, 0, -0.18);
  shape.closePath();
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: 0.03,
    bevelEnabled: false,
  });
  geo.rotateX(Math.PI / 2);
  return geo;
}

function createSwordBladeGeo(): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(-0.055, 0);
  shape.lineTo(0.055, 0);
  shape.lineTo(0.045, 0.72);
  shape.lineTo(0, 0.92);
  shape.lineTo(-0.045, 0.72);
  shape.closePath();
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: 0.026,
    bevelEnabled: true,
    bevelThickness: 0.01,
    bevelSize: 0.01,
    bevelSegments: 1,
  });
  geo.translate(0, 0, -0.013);
  return geo;
}

function createShieldGeo(): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(-0.24, 0.3);
  shape.lineTo(0.24, 0.3);
  shape.lineTo(0.26, -0.04);
  shape.quadraticCurveTo(0.18, -0.32, 0, -0.42);
  shape.quadraticCurveTo(-0.18, -0.32, -0.26, -0.04);
  shape.closePath();
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: 0.06,
    bevelEnabled: true,
    bevelThickness: 0.018,
    bevelSize: 0.016,
    bevelSegments: 1,
  });
  geo.rotateY(Math.PI / 2);
  return geo;
}

function createCurvedHornGeo(): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(-0.07, 0);
  shape.quadraticCurveTo(-0.14, 0.28, 0.04, 0.56);
  shape.quadraticCurveTo(0.08, 0.25, 0.06, 0);
  shape.closePath();
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: 0.08,
    bevelEnabled: true,
    bevelThickness: 0.015,
    bevelSize: 0.015,
    bevelSegments: 1,
  });
  geo.translate(0, 0, -0.04);
  return geo;
}

function createFinGeo(): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(-0.22, 0);
  shape.quadraticCurveTo(-0.04, 0.44, 0.26, 0.52);
  shape.quadraticCurveTo(0.14, 0.22, 0.18, 0);
  shape.closePath();
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: 0.05,
    bevelEnabled: true,
    bevelThickness: 0.01,
    bevelSize: 0.01,
    bevelSegments: 1,
  });
  geo.rotateY(Math.PI / 2);
  return geo;
}

function createBarrelTorsoGeo(): THREE.BufferGeometry {
  const pts = [
    new THREE.Vector2(0.01, -0.5),
    new THREE.Vector2(0.32, -0.44),
    new THREE.Vector2(0.46, -0.12),
    new THREE.Vector2(0.48, 0.2),
    new THREE.Vector2(0.34, 0.46),
    new THREE.Vector2(0.01, 0.5),
  ];
  const geo = new THREE.LatheGeometry(pts, 9);
  geo.rotateX(Math.PI / 2);
  return geo;
}

function createShellDomeGeo(): THREE.BufferGeometry {
  const pts = [
    new THREE.Vector2(0.01, 0.42),
    new THREE.Vector2(0.3, 0.36),
    new THREE.Vector2(0.48, 0.2),
    new THREE.Vector2(0.55, 0.02),
    new THREE.Vector2(0.01, 0.0),
  ];
  return new THREE.LatheGeometry(pts, 10);
}

function createCrystalSpireGeo(): THREE.BufferGeometry {
  const pts = [
    new THREE.Vector2(0.01, 0.55),
    new THREE.Vector2(0.17, 0.22),
    new THREE.Vector2(0.2, -0.25),
    new THREE.Vector2(0.09, -0.5),
    new THREE.Vector2(0.01, -0.5),
  ];
  return new THREE.LatheGeometry(pts, 5);
}

export function inferModelStyle(def: EntityTemplateDef): EntityModelStyle {
  if (def.modelStyle) return def.modelStyle;
  const id = def.id;
  if (def.archetype === 'skeleton') return 'skeleton';
  if (id.includes('stag')) return 'stag';
  if (id.includes('deer') || id.includes('gazelle')) return 'deer';
  if (id.includes('rabbit')) return 'rabbit';
  if (id.includes('fox')) return 'fox';
  if (id.includes('wolf') || id.includes('hound')) return 'wolf';
  if (id.includes('panther') || id.includes('cat')) return 'panther';
  if (id.includes('boar')) return 'boar';
  if (id.includes('sheep')) return 'sheep';
  if (id.includes('goat')) return 'goat';
  if (id.includes('otter')) return 'otter';
  if (id.includes('tortoise')) return 'tortoise';
  if (id.includes('crab')) return 'crab';
  if (id.includes('scorpion')) return 'scorpion';
  if (id.includes('spider')) return 'spider';
  if (id.includes('beetle') || id.includes('scarab')) return 'beetle';
  if (id.includes('frog')) return 'frog';
  if (id.includes('owl')) return 'owl';
  if (id.includes('moth') || id.includes('butterfly')) return 'moth';
  if (id.includes('bat')) return 'bat';
  if (id.includes('gargoyle')) return 'gargoyle';
  if (id.includes('harpy')) return 'harpy';
  if (id.includes('thunderbird')) return 'thunderbird';
  if (id.includes('hawk') || id.includes('gull') || id.includes('eagle')) return 'hawk';
  if (id.includes('shark')) return 'shark';
  if (id.includes('jellyfish')) return 'jellyfish';
  if (id.includes('salamander')) return 'salamander';
  if (id.includes('wyrm') || id.includes('worm')) return 'wyrm';
  if (id.includes('bone_dragon')) return 'bone_dragon';
  if (id.includes('dragon') || id.includes('drake') || id.includes('wyvern') || id.includes('forgotten_god')) {
    return def.archetype === 'winged' ? 'harpy' : 'dragon';
  }
  if (id.includes('ent') || id.includes('treant')) return 'treant';
  if (id.includes('crystal_guardian') || id.includes('crystal_golem') || id.includes('arcane_sentinel')) {
    return 'crystal_golem';
  }
  if (id.includes('titan') || id.includes('magma_king') || id.includes('yeti')) return 'titan';
  if (id.includes('mummy')) return 'mummy';
  if (id.includes('mage') || id.includes('witch') || id.includes('siren') || id.includes('caster')) {
    return 'mage';
  }
  if (id.includes('knight') || id.includes('ice_king') || id.includes('shadow_lord')) return 'knight';
  if (id.includes('void_stalker') || id.includes('shadow_stalker') || id.includes('cosmic')) {
    return 'void_stalker';
  }
  if (id.includes('djinn')) return 'djinn';
  if (id.includes('reaper')) return 'reaper';

  const arch: EntityArchetype = def.archetype;
  if (arch === 'dragon') return 'dragon';
  if (arch === 'serpent') return 'serpent';
  if (arch === 'golem') return 'golem';
  if (arch === 'winged') return 'hawk';
  if (arch === 'wisp') return 'wisp';
  if (arch === 'slime') return 'slime';
  if (arch === 'humanoid') return 'warrior';
  return 'wolf';
}

export class SharedEntityGeometryPool {
  private unitBox = new THREE.BoxGeometry(1, 1, 1);
  private unitSphere = new THREE.SphereGeometry(0.5, 12, 9);
  private unitCone = new THREE.ConeGeometry(0.5, 1, 7);
  private unitCyl = new THREE.CylinderGeometry(0.42, 0.5, 1, 8);
  private taperedLimb = new THREE.CylinderGeometry(0.11, 0.08, 1, 7);
  private unitOct = new THREE.OctahedronGeometry(0.46, 0);
  private unitDodeca = new THREE.DodecahedronGeometry(0.5, 0);
  private eyeGeo = new THREE.SphereGeometry(0.065, 6, 5);
  private spikeGeo = new THREE.ConeGeometry(0.12, 0.44, 5);
  private ringGeo = new THREE.TorusGeometry(0.84, 0.055, 6, 20);
  private shadowDiscGeo = new THREE.CircleGeometry(0.65, 14);

  // Sculpted high-detail shared geometries
  private barrelTorsoGeo = createBarrelTorsoGeo();
  private shellDomeGeo = createShellDomeGeo();
  private crystalSpireGeo = createCrystalSpireGeo();
  private membraneWingGeo = createExtrudedWingGeo(true);
  private featherWingGeo = createExtrudedWingGeo(false);
  private butterflyWingGeo = createButterflyWingGeo();
  private swordBladeGeo = createSwordBladeGeo();
  private shieldGeo = createShieldGeo();
  private curvedHornGeo = createCurvedHornGeo();
  private finGeo = createFinGeo();

  private shadowDiscMat = new THREE.MeshBasicMaterial({
    color: 0x090d16,
    transparent: true,
    opacity: 0.32,
    depthWrite: false,
  });

  public buildCreatureOrMonster(def: EntityTemplateDef, castShadows: boolean): BuiltEntityVisual {
    const root = new THREE.Group();
    const style = inferModelStyle(def);
    const isBoss = def.category === 'boss';

    // Varied material roughness (>= 0.25 difference between adjacent materials)
    const primaryMat = new THREE.MeshStandardMaterial({
      color: def.primaryHex,
      roughness: style === 'slime' || style === 'jellyfish' ? 0.16 : isBoss ? 0.58 : 0.78,
      metalness: style === 'knight' || style === 'crystal_golem' ? 0.35 : 0.08,
      flatShading: style !== 'slime' && style !== 'jellyfish',
      transparent: style === 'slime' || style === 'jellyfish',
      opacity: style === 'slime' ? 0.86 : style === 'jellyfish' ? 0.82 : 1,
    });
    const secondaryMat = new THREE.MeshStandardMaterial({
      color: def.secondaryHex,
      roughness: 0.38,
      metalness: style === 'skeleton' || style === 'knight' || style === 'golem' ? 0.48 : 0.18,
      flatShading: true,
    });
    const darkSocketMat = new THREE.MeshStandardMaterial({
      color: 0x0b1120,
      roughness: 0.92,
      metalness: 0.04,
    });
    const ivoryMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.32,
      metalness: 0.06,
    });
    const glowMat = new THREE.MeshStandardMaterial({
      color: def.glowHex,
      emissive: def.glowHex,
      emissiveIntensity: isBoss ? 1.8 : 1.45,
      roughness: 0.18,
      metalness: 0.1,
    });

    // Grounded Contact Shadow Disc
    const shadowMesh = new THREE.Mesh(this.shadowDiscGeo, this.shadowDiscMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = 0.025;
    shadowMesh.scale.setScalar(style === 'dragon' || style === 'titan' ? 1.65 : 1.05);
    root.add(shadowMesh);

    const limbs: THREE.Object3D[] = [];
    const wings: THREE.Object3D[] = [];
    const detailParts: THREE.Object3D[] = [];
    const segments: THREE.Object3D[] = [];
    let head: THREE.Object3D | undefined;
    let jaw: THREE.Object3D | undefined;
    let tail: THREE.Object3D | undefined;
    let auraRing: THREE.Object3D | undefined;

    const addPart = (
      geo: THREE.BufferGeometry,
      mat: THREE.Material,
      sx: number,
      sy: number,
      sz: number,
      px: number,
      py: number,
      pz: number,
      rx = 0,
      ry = 0,
      rz = 0,
      isDetail = false,
      parent: THREE.Object3D = root,
    ): THREE.Mesh => {
      const m = new THREE.Mesh(geo, mat);
      m.scale.set(sx, sy, sz);
      m.position.set(px, py, pz);
      m.rotation.set(rx, ry, rz);
      m.castShadow = castShadows;
      m.receiveShadow = castShadows;
      parent.add(m);
      if (isDetail) detailParts.push(m);
      return m;
    };

    const addPivot = (px: number, py: number, pz: number, parent: THREE.Object3D = root): THREE.Group => {
      const g = new THREE.Group();
      g.position.set(px, py, pz);
      parent.add(g);
      return g;
    };

    // Helper for quadruped legs with hooves/paws pivoted at hip
    const addQuadrupedLegs = (
      hipX: number,
      hipY: number,
      frontZ: number,
      backZ: number,
      legRadius: number,
      pawMat: THREE.Material = secondaryMat,
    ) => {
      const coords: Array<[number, number]> = [
        [-hipX, frontZ],
        [hipX, frontZ],
        [-hipX, backZ],
        [hipX, backZ],
      ];
      for (const [lx, lz] of coords) {
        const piv = addPivot(lx, hipY, lz);
        addPart(this.taperedLimb, primaryMat, legRadius, hipY, legRadius, 0, -hipY * 0.5, 0, 0, 0, 0, false, piv);
        addPart(this.unitBox, pawMat, legRadius * 1.4, 0.1, legRadius * 1.7, 0, -hipY + 0.05, 0.04, 0, 0, 0, true, piv);
        limbs.push(piv);
      }
    };

    if (style === 'skeleton') {
      const variant: SkeletonVariant = def.skeletonVariant ?? 'warrior';
      const isCaster = variant === 'mage' || variant === 'rare';
      const isCommander = variant === 'commander';
      const isArmored = variant === 'armored' || variant === 'guard' || isCommander;
      const legW = variant === 'giant' ? 1.5 : 1.0;

      // Jointed Bony Legs
      for (const side of [-1, 1]) {
        const legPiv = addPivot(side * 0.15, 0.72, 0);
        addPart(this.taperedLimb, primaryMat, 1.0 * legW, 0.7, 1.0 * legW, 0, -0.35, 0, 0, 0, 0, false, legPiv);
        addPart(this.unitSphere, secondaryMat, 0.14 * legW, 0.12 * legW, 0.14 * legW, 0, -0.35, 0.02, 0, 0, 0, true, legPiv);
        addPart(this.unitBox, secondaryMat, 0.14 * legW, 0.09, 0.26, 0, -0.68, 0.05, 0, 0, 0, true, legPiv);
        limbs.push(legPiv);
      }

      // Pelvis, Spine, 3-tier Curved Ribcage, Clavicle
      addPart(this.unitBox, primaryMat, 0.42, 0.15, 0.24, 0, 0.75, 0);
      addPart(this.unitCyl, primaryMat, 0.14, 0.65, 0.14, 0, 1.08, -0.04);
      addPart(this.barrelTorsoGeo, primaryMat, 0.54, 0.14, 0.42, 0, 1.28, 0.02);
      addPart(this.barrelTorsoGeo, primaryMat, 0.48, 0.11, 0.36, 0, 1.13, 0.02, 0, 0, 0, true);
      addPart(this.barrelTorsoGeo, primaryMat, 0.42, 0.1, 0.32, 0, 0.99, 0.02, 0, 0, 0, true);
      addPart(this.unitBox, primaryMat, 0.74, 0.1, 0.18, 0, 1.42, 0);

      // Sculpted Skull Head Pivot + Hinged Jaw + Eye Sockets
      const headPiv = addPivot(0, 1.54, 0.02);
      head = headPiv;
      addPart(this.unitDodeca, primaryMat, 0.44, 0.42, 0.44, 0, 0.14, 0, 0, 0, 0, false, headPiv);
      addPart(this.unitBox, primaryMat, 0.34, 0.16, 0.24, 0, 0.04, 0.12, 0, 0, 0, false, headPiv);
      const jawPiv = addPivot(0, 0.0, 0.06, headPiv);
      jaw = jawPiv;
      addPart(this.unitBox, primaryMat, 0.26, 0.11, 0.24, 0, -0.05, 0.06, 0, 0, 0, true, jawPiv);
      addPart(this.eyeGeo, darkSocketMat, 1.5, 1.3, 0.8, -0.09, 0.15, 0.2, 0, 0, 0, true, headPiv);
      addPart(this.eyeGeo, darkSocketMat, 1.5, 1.3, 0.8, 0.09, 0.15, 0.2, 0, 0, 0, true, headPiv);
      addPart(this.eyeGeo, glowMat, 0.95, 0.95, 1, -0.09, 0.15, 0.23, 0, 0, 0, true, headPiv);
      addPart(this.eyeGeo, glowMat, 0.95, 0.95, 1, 0.09, 0.15, 0.23, 0, 0, 0, true, headPiv);

      // Variant Armor & Headgear
      if (isArmored) {
        addPart(this.unitBox, secondaryMat, 0.58, 0.38, 0.34, 0, 1.2, 0.02);
        addPart(this.unitDodeca, secondaryMat, 0.3, 0.24, 0.3, -0.42, 1.42, 0, 0, 0, 0.25, true);
        addPart(this.unitDodeca, secondaryMat, 0.3, 0.24, 0.3, 0.42, 1.42, 0, 0, 0, -0.25, true);
      }
      if (variant === 'armored') {
        addPart(this.unitCyl, secondaryMat, 0.46, 0.18, 0.46, 0, 0.28, 0, 0, 0, 0, false, headPiv);
        addPart(this.curvedHornGeo, glowMat, 0.9, 0.9, 0.9, -0.18, 0.3, 0, 0, Math.PI, 0.2, true, headPiv);
        addPart(this.curvedHornGeo, glowMat, 0.9, 0.9, 0.9, 0.18, 0.3, 0, 0, 0, -0.2, true, headPiv);
      } else if (variant === 'mage') {
        addPart(this.unitCone, secondaryMat, 0.58, 0.56, 0.58, 0, 0.5, 0, 0, 0, 0, false, headPiv);
        addPart(this.unitBox, secondaryMat, 0.54, 0.58, 0.28, 0, 1.06, -0.08);
      } else if (variant === 'rare') {
        addPart(this.crystalSpireGeo, glowMat, 0.52, 0.52, 0.52, -0.44, 1.56, 0, 0, 0, 0.2, true);
        addPart(this.crystalSpireGeo, glowMat, 0.52, 0.52, 0.52, 0.44, 1.56, 0, 0, 0, -0.2, true);
        auraRing = addPart(this.ringGeo, glowMat, 0.55, 0.55, 0.55, 0, 2.02, 0, Math.PI / 2, 0, 0, true);
      } else if (isCommander) {
        addPart(this.unitCyl, glowMat, 0.38, 0.16, 0.38, 0, 0.35, 0, 0, 0, 0, false, headPiv);
        addPart(this.spikeGeo, glowMat, 0.75, 0.85, 0.75, -0.14, 0.48, 0.1, 0, 0, 0, true, headPiv);
        addPart(this.spikeGeo, glowMat, 0.75, 0.85, 0.75, 0.14, 0.48, 0.1, 0, 0, 0, true, headPiv);
        addPart(this.unitBox, secondaryMat, 0.68, 0.95, 0.07, 0, 1.0, -0.22, 0.18, 0, 0, true);
        auraRing = addPart(this.ringGeo, glowMat, 1.0, 1.0, 1.0, 0, 0.12, 0, Math.PI / 2, 0, 0, true);
      } else if (variant === 'swift') {
        addPart(this.unitBox, secondaryMat, 0.46, 0.14, 0.36, 0, 1.44, -0.02, 0, 0, 0, true);
        addPart(this.unitBox, secondaryMat, 0.32, 0.52, 0.06, -0.06, 1.24, -0.24, 0.32, 0, 0, true);
      }

      // Pivoted Arms + Weapons
      const lArmPiv = addPivot(-0.4, 1.38, 0);
      const rArmPiv = addPivot(0.4, 1.38, 0);
      addPart(this.taperedLimb, primaryMat, 0.95, 0.56, 0.95, 0, -0.28, 0.04, -0.15, 0, 0, false, lArmPiv);
      addPart(this.taperedLimb, primaryMat, 0.95, 0.56, 0.95, 0, -0.28, 0.08, -0.42, 0, 0, false, rArmPiv);

      if (variant === 'archer') {
        addPart(this.unitCyl, secondaryMat, 0.16, 0.56, 0.16, -0.15, 1.22, -0.22, 0, 0, 0.3, true);
        addPart(this.unitBox, secondaryMat, 0.07, 0.9, 0.09, -0.04, -0.34, 0.28, 0.2, 0, 0, true, lArmPiv);
        addPart(this.unitBox, glowMat, 0.025, 0.84, 0.025, -0.04, -0.34, 0.18, 0.2, 0, 0, true, lArmPiv);
      } else if (variant === 'swift') {
        addPart(this.swordBladeGeo, glowMat, 0.7, 0.52, 0.7, 0, -0.5, 0.14, 1.15, 0, 0, true, lArmPiv);
        addPart(this.swordBladeGeo, glowMat, 0.7, 0.52, 0.7, 0, -0.5, 0.14, 1.15, 0, 0, true, rArmPiv);
      } else if (isCaster) {
        addPart(this.unitCyl, secondaryMat, 0.07, 1.48, 0.07, 0.04, -0.1, 0.28, 0.18, 0, 0, true, rArmPiv);
        addPart(this.crystalSpireGeo, glowMat, 0.52, 0.52, 0.52, 0.04, 0.68, 0.42, 0, 0, 0, true, rArmPiv);
      } else if (variant === 'giant') {
        addPart(this.unitCyl, secondaryMat, 0.09, 1.55, 0.09, 0.04, -0.15, 0.35, 0.75, 0, 0, true, rArmPiv);
        addPart(this.unitBox, glowMat, 0.1, 0.58, 0.38, 0.04, 0.24, 0.65, 0.75, 0, 0, true, rArmPiv);
      } else if (variant === 'guard') {
        addPart(this.unitCyl, secondaryMat, 0.07, 1.75, 0.07, 0.04, 0.0, 0.26, 0.25, 0, 0, true, rArmPiv);
        addPart(this.swordBladeGeo, glowMat, 1.0, 0.55, 1.0, 0.04, 0.85, 0.48, 0.25, 0, 0, true, rArmPiv);
        addPart(this.shieldGeo, secondaryMat, 1.1, 1.35, 1.1, -0.1, -0.35, 0.18, 0, 0, 0, true, lArmPiv);
      } else {
        addPart(this.swordBladeGeo, isCommander ? glowMat : secondaryMat, 1.0, 0.95, 1.0, 0.02, -0.45, 0.24, 1.05, 0, 0, true, rArmPiv);
        addPart(this.shieldGeo, secondaryMat, 0.95, 0.95, 0.95, -0.08, -0.32, 0.14, 0, 0, 0, true, lArmPiv);
      }
      limbs.push(rArmPiv, lArmPiv);
    } else if (style === 'spider') {
      // Cephalothorax + bulbous abdomen + 2 fangs + 5 clustered eyes + 8 articulated two-segment legs
      addPart(this.unitSphere, primaryMat, 0.66, 0.44, 0.64, 0, 0.44, 0.26);
      addPart(this.unitSphere, secondaryMat, 0.96, 0.72, 1.08, 0, 0.56, -0.52);
      addPart(this.crystalSpireGeo, glowMat, 0.4, 0.4, 0.4, 0, 0.92, -0.52, -0.3, 0, 0, true);
      const jawPiv = addPivot(0, 0.34, 0.52);
      jaw = jawPiv;
      addPart(this.spikeGeo, ivoryMat, 0.7, 0.7, 0.7, -0.11, -0.06, 0.05, 0.65, 0, 0, true, jawPiv);
      addPart(this.spikeGeo, ivoryMat, 0.7, 0.7, 0.7, 0.11, -0.06, 0.05, 0.65, 0, 0, true, jawPiv);
      addPart(this.eyeGeo, glowMat, 1.15, 1.15, 1, -0.15, 0.5, 0.54, 0, 0, 0, true);
      addPart(this.eyeGeo, glowMat, 1.15, 1.15, 1, 0.15, 0.5, 0.54, 0, 0, 0, true);
      addPart(this.eyeGeo, glowMat, 0.85, 0.85, 1, 0, 0.56, 0.56, 0, 0, 0, true);
      addPart(this.eyeGeo, glowMat, 0.65, 0.65, 1, -0.08, 0.43, 0.55, 0, 0, 0, true);
      addPart(this.eyeGeo, glowMat, 0.65, 0.65, 1, 0.08, 0.43, 0.55, 0, 0, 0, true);
      for (let i = 0; i < 4; i++) {
        const zOff = 0.36 - i * 0.25;
        for (const side of [-1, 1]) {
          const piv = addPivot(side * 0.28, 0.44, zOff);
          addPart(this.taperedLimb, primaryMat, 0.8, 0.52, 0.8, side * 0.22, 0.06, 0, 0, 0, -side * 1.1, false, piv);
          addPart(this.taperedLimb, secondaryMat, 0.7, 0.58, 0.7, side * 0.48, -0.16, 0, 0, 0, side * 0.32, true, piv);
          limbs.push(piv);
        }
      }
    } else if (style === 'scorpion' || style === 'crab' || style === 'beetle') {
      const isScorpion = style === 'scorpion';
      const isBeetle = style === 'beetle';
      // Domed armored carapace
      addPart(this.shellDomeGeo, primaryMat, isScorpion ? 0.76 : 1.05, isBeetle ? 1.15 : 0.9, isScorpion ? 1.12 : 0.95, 0, 0.26, 0);
      addPart(this.unitBox, secondaryMat, isScorpion ? 0.62 : 0.82, 0.18, 0.78, 0, 0.28, 0);
      addPart(this.eyeGeo, glowMat, 1.1, 1.1, 1, -0.15, 0.44, 0.46, 0, 0, 0, true);
      addPart(this.eyeGeo, glowMat, 1.1, 1.1, 1, 0.15, 0.44, 0.46, 0, 0, 0, true);

      if (!isBeetle) {
        // Articulated heavy pincers
        for (const side of [-1, 1]) {
          const clawPiv = addPivot(side * 0.42, 0.38, 0.42);
          addPart(this.unitBox, secondaryMat, 0.22, 0.16, 0.48, side * 0.1, 0.04, 0.22, 0, -side * 0.35, 0, false, clawPiv);
          addPart(this.unitDodeca, glowMat, 0.28, 0.2, 0.34, side * 0.18, 0.06, 0.48, 0, 0, 0, true, clawPiv);
          limbs.push(clawPiv);
        }
      } else {
        // Beetle golden horn + wing shell ridge
        addPart(this.curvedHornGeo, secondaryMat, 1.1, 1.1, 1.1, 0, 0.42, 0.46, 0.45, Math.PI / 2, 0, true);
      }

      if (isScorpion) {
        // 5-segment curving scorpion tail + glowing venom stinger
        const tailPiv = addPivot(0, 0.42, -0.45);
        tail = tailPiv;
        for (let s = 0; s < 4; s++) {
          const seg = addPivot(0, s * 0.24, -0.18 + s * 0.14, tailPiv);
          addPart(this.unitSphere, s % 2 === 0 ? primaryMat : secondaryMat, 0.26 - s * 0.03, 0.26, 0.26, 0, 0, 0, 0, 0, 0, false, seg);
          segments.push(seg);
        }
        addPart(this.crystalSpireGeo, glowMat, 0.72, 0.72, 0.72, 0, 0.96, 0.38, 1.35, 0, 0, true, tailPiv);
      }

      for (let i = 0; i < 3; i++) {
        const zOff = 0.22 - i * 0.24;
        for (const side of [-1, 1]) {
          const piv = addPivot(side * 0.44, 0.26, zOff);
          addPart(this.taperedLimb, primaryMat, 0.9, 0.42, 0.9, side * 0.18, -0.1, 0, 0, 0, side * 0.65, false, piv);
          limbs.push(piv);
        }
      }
    } else if (style === 'tortoise') {
      addPart(this.shellDomeGeo, primaryMat, 1.05, 1.1, 1.25, 0, 0.26, 0);
      addPart(this.unitDodeca, secondaryMat, 0.72, 0.28, 0.85, 0, 0.56, 0, 0, 0, 0, true);
      const headPiv = addPivot(0, 0.34, 0.62);
      head = headPiv;
      addPart(this.unitSphere, secondaryMat, 0.32, 0.28, 0.42, 0, 0, 0.16, 0, 0, 0, false, headPiv);
      addPart(this.eyeGeo, glowMat, 0.9, 0.9, 1, -0.1, 0.06, 0.32, 0, 0, 0, true, headPiv);
      addPart(this.eyeGeo, glowMat, 0.9, 0.9, 1, 0.1, 0.06, 0.32, 0, 0, 0, true, headPiv);
      addQuadrupedLegs(0.36, 0.28, 0.34, -0.34, 1.4, secondaryMat);
    } else if (style === 'deer' || style === 'stag' || style === 'goat' || style === 'sheep' || style === 'boar' || style === 'rabbit') {
      const isRabbit = style === 'rabbit';
      const isSheep = style === 'sheep';
      const isBoar = style === 'boar';
      const isStag = style === 'stag';
      const isDeer = style === 'deer' || isStag || style === 'goat';

      // Barrel body
      addPart(
        this.barrelTorsoGeo,
        primaryMat,
        isBoar || isSheep ? 0.95 : 0.72,
        isBoar || isSheep ? 0.88 : 0.66,
        isRabbit ? 0.88 : 1.18,
        0,
        isRabbit ? 0.42 : 0.76,
        0,
      );
      if (isSheep) {
        addPart(this.unitDodeca, primaryMat, 0.82, 0.68, 0.86, 0, 0.84, 0.12, 0, 0, 0, true);
        addPart(this.unitDodeca, primaryMat, 0.66, 0.58, 0.66, 0, 0.8, -0.25, 0, 0, 0, true);
      }

      // Head + Ears + Horns/Antlers/Tusks
      const neckY = isRabbit ? 0.55 : isDeer ? 1.1 : 0.88;
      const headPiv = addPivot(0, neckY, isDeer ? 0.52 : 0.46);
      head = headPiv;
      if (isDeer) {
        addPart(this.taperedLimb, primaryMat, 1.5, 0.48, 1.5, 0, -0.14, -0.1, 0.38, 0, 0, false, headPiv);
      }
      addPart(this.unitDodeca, isSheep ? secondaryMat : primaryMat, 0.38, 0.34, 0.42, 0, 0.08, 0.12, 0, 0, 0, false, headPiv);
      addPart(this.unitBox, secondaryMat, 0.22, 0.18, 0.28, 0, 0.04, 0.34, 0, 0, 0, true, headPiv);
      addPart(this.eyeGeo, darkSocketMat, 0.95, 0.95, 0.95, -0.14, 0.14, 0.26, 0, 0, 0, true, headPiv);
      addPart(this.eyeGeo, darkSocketMat, 0.95, 0.95, 0.95, 0.14, 0.14, 0.26, 0, 0, 0, true, headPiv);

      if (isRabbit) {
        addPart(this.unitBox, primaryMat, 0.09, 0.44, 0.12, -0.1, 0.4, 0.06, -0.15, 0, 0.15, true, headPiv);
        addPart(this.unitBox, primaryMat, 0.09, 0.44, 0.12, 0.1, 0.4, 0.06, -0.15, 0, -0.15, true, headPiv);
        addPart(this.unitBox, secondaryMat, 0.05, 0.34, 0.04, -0.1, 0.4, 0.11, -0.15, 0, 0.15, true, headPiv);
        addPart(this.unitBox, secondaryMat, 0.05, 0.34, 0.04, 0.1, 0.4, 0.11, -0.15, 0, -0.15, true, headPiv);
      } else if (isBoar) {
        addPart(this.curvedHornGeo, ivoryMat, 0.55, 0.55, 0.55, -0.14, 0.02, 0.4, 0.7, 0, 0.35, true, headPiv);
        addPart(this.curvedHornGeo, ivoryMat, 0.55, 0.55, 0.55, 0.14, 0.02, 0.4, 0.7, 0, -0.35, true, headPiv);
      } else if (isStag || isDeer) {
        const antlerMat = isStag ? glowMat : secondaryMat;
        addPart(this.curvedHornGeo, antlerMat, 0.95, 1.15, 0.95, -0.12, 0.26, 0.06, -0.2, 0, 0.35, true, headPiv);
        addPart(this.curvedHornGeo, antlerMat, 0.95, 1.15, 0.95, 0.12, 0.26, 0.06, -0.2, 0, -0.35, true, headPiv);
        if (style !== 'goat') {
          addPart(this.spikeGeo, antlerMat, 0.7, 0.7, 0.7, -0.22, 0.52, 0.12, 0.3, 0, 0.65, true, headPiv);
          addPart(this.spikeGeo, antlerMat, 0.7, 0.7, 0.7, 0.22, 0.52, 0.12, 0.3, 0, -0.65, true, headPiv);
        }
      }

      // Tail
      const tailPiv = addPivot(0, isRabbit ? 0.42 : 0.82, -0.54);
      tail = tailPiv;
      addPart(this.unitSphere, secondaryMat, 0.22, 0.22, 0.26, 0, 0.02, -0.08, 0, 0, 0, true, tailPiv);

      addQuadrupedLegs(
        isRabbit ? 0.18 : 0.22,
        isRabbit ? 0.3 : isBoar ? 0.46 : 0.58,
        isRabbit ? 0.24 : 0.38,
        isRabbit ? -0.24 : -0.38,
        isRabbit ? 0.8 : isBoar ? 1.25 : 0.9,
        secondaryMat,
      );
    } else if (style === 'wolf' || style === 'fox' || style === 'panther' || style === 'otter') {
      // Predatory Quadruped: sculpted barrel torso, mane/chest ruff, articulated head + fanged jaw, bushy/long tail
      const isFox = style === 'fox';
      const isOtter = style === 'otter';
      const hipH = isOtter ? 0.34 : 0.52;

      addPart(this.barrelTorsoGeo, primaryMat, isOtter ? 0.66 : 0.76, isOtter ? 0.56 : 0.66, 1.25, 0, hipH + 0.2, 0);
      addPart(this.unitDodeca, secondaryMat, 0.66, 0.54, 0.52, 0, hipH + 0.28, 0.36);

      const headPiv = addPivot(0, hipH + 0.46, 0.58);
      head = headPiv;
      addPart(this.unitDodeca, primaryMat, 0.46, 0.4, 0.46, 0, 0.08, 0.08, 0, 0, 0, false, headPiv);
      addPart(this.unitBox, primaryMat, 0.24, 0.16, 0.3, 0, 0.06, 0.34, 0, 0, 0, true, headPiv); // Upper snout
      const jawPiv = addPivot(0, -0.02, 0.2, headPiv);
      jaw = jawPiv;
      addPart(this.unitBox, secondaryMat, 0.2, 0.09, 0.26, 0, -0.04, 0.12, 0, 0, 0, true, jawPiv);
      if (def.category !== 'creature') {
        addPart(this.spikeGeo, ivoryMat, 0.32, 0.28, 0.32, -0.07, -0.03, 0.22, Math.PI, 0, 0, true, headPiv);
        addPart(this.spikeGeo, ivoryMat, 0.32, 0.28, 0.32, 0.07, -0.03, 0.22, Math.PI, 0, 0, true, headPiv);
      }
      addPart(this.unitCone, secondaryMat, 0.16, 0.26, 0.16, -0.15, 0.34, 0.04, 0, 0, 0.22, true, headPiv);
      addPart(this.unitCone, secondaryMat, 0.16, 0.26, 0.16, 0.15, 0.34, 0.04, 0, 0, -0.22, true, headPiv);
      addPart(this.eyeGeo, glowMat, 1.0, 1.0, 1.0, -0.12, 0.14, 0.28, 0, 0, 0, true, headPiv);
      addPart(this.eyeGeo, glowMat, 1.0, 1.0, 1.0, 0.12, 0.14, 0.28, 0, 0, 0, true, headPiv);

      // Tail (glowing tip on Luminous Fox)
      const tailPiv = addPivot(0, hipH + 0.22, -0.58);
      tail = tailPiv;
      addPart(
        this.unitCone,
        isFox ? glowMat : secondaryMat,
        isFox ? 0.34 : 0.22,
        isFox ? 0.72 : 0.68,
        isFox ? 0.34 : 0.22,
        0,
        0.16,
        -0.32,
        -1.15,
        0,
        0,
        true,
        tailPiv,
      );

      if (def.category !== 'creature') {
        addPart(this.crystalSpireGeo, glowMat, 0.45, 0.48, 0.45, 0, hipH + 0.55, 0.1, -0.3, 0, 0, true);
        addPart(this.crystalSpireGeo, glowMat, 0.38, 0.42, 0.38, 0, hipH + 0.5, -0.2, -0.35, 0, 0, true);
      }

      addQuadrupedLegs(0.24, hipH, 0.4, -0.4, isOtter ? 0.95 : 1.05, secondaryMat);
    } else if (style === 'hawk' || style === 'owl' || style === 'moth' || style === 'bat' || style === 'gargoyle' || style === 'harpy' || style === 'thunderbird') {
      const isMoth = style === 'moth';
      const isBatOrGargoyle = style === 'bat' || style === 'gargoyle' || style === 'harpy';
      const isThunder = style === 'thunderbird';
      const bodyY = isBoss ? 1.55 : 1.32;

      addPart(this.barrelTorsoGeo, primaryMat, 0.66, 0.62, 0.96, 0, bodyY, 0);
      const headPiv = addPivot(0, bodyY + 0.3, 0.44);
      head = headPiv;
      addPart(this.unitSphere, primaryMat, 0.44, 0.42, 0.44, 0, 0, 0, 0, 0, 0, false, headPiv);
      if (isMoth) {
        addPart(this.curvedHornGeo, glowMat, 0.55, 0.65, 0.55, -0.09, 0.22, 0.14, 0.4, 0, 0.35, true, headPiv);
        addPart(this.curvedHornGeo, glowMat, 0.55, 0.65, 0.55, 0.09, 0.22, 0.14, 0.4, 0, -0.35, true, headPiv);
      } else {
        addPart(this.unitCone, isThunder ? glowMat : secondaryMat, 0.22, 0.32, 0.24, 0, -0.04, 0.28, Math.PI * 0.55, 0, 0, true, headPiv);
        if (isBatOrGargoyle || style === 'owl' || isThunder) {
          addPart(this.curvedHornGeo, glowMat, 0.75, 0.85, 0.75, -0.14, 0.2, 0.04, -0.2, 0, 0.35, true, headPiv);
          addPart(this.curvedHornGeo, glowMat, 0.75, 0.85, 0.75, 0.14, 0.2, 0.04, -0.2, 0, -0.35, true, headPiv);
        }
      }
      addPart(this.eyeGeo, glowMat, 1.1, 1.1, 1.1, -0.11, 0.06, 0.19, 0, 0, 0, true, headPiv);
      addPart(this.eyeGeo, glowMat, 1.1, 1.1, 1.1, 0.11, 0.06, 0.19, 0, 0, 0, true, headPiv);

      // Tail Fan
      const tailPiv = addPivot(0, bodyY - 0.06, -0.48);
      tail = tailPiv;
      addPart(this.featherWingGeo, secondaryMat, 0.55, 0.8, 0.6, 0, 0, 0, 0, -Math.PI / 2, 0, true, tailPiv);

      // Shoulder-Pivoted Extruded Wings!
      const wGeo = isMoth
        ? this.butterflyWingGeo
        : isBatOrGargoyle
          ? this.membraneWingGeo
          : this.featherWingGeo;
      const wScale = isBoss ? 1.55 : isMoth ? 1.15 : 1.1;

      const wLeftPiv = addPivot(-0.32, bodyY + 0.12, 0.08);
      const wRightPiv = addPivot(0.32, bodyY + 0.12, 0.08);
      addPart(wGeo, secondaryMat, -wScale, 1, wScale, 0, 0, 0, 0, 0, 0, false, wLeftPiv);
      addPart(wGeo, secondaryMat, wScale, 1, wScale, 0, 0, 0, 0, 0, 0, false, wRightPiv);
      if (isThunder || isMoth) {
        addPart(this.crystalSpireGeo, glowMat, 0.32, 0.45, 0.32, -0.78 * wScale, 0.04, 0, 0, 0, Math.PI / 2, true, wLeftPiv);
        addPart(this.crystalSpireGeo, glowMat, 0.32, 0.45, 0.32, 0.78 * wScale, 0.04, 0, 0, 0, -Math.PI / 2, true, wRightPiv);
      }
      wings.push(wLeftPiv, wRightPiv);

      // Talons
      for (const side of [-1, 1]) {
        const legPiv = addPivot(side * 0.16, bodyY - 0.25, -0.06);
        addPart(this.taperedLimb, secondaryMat, 0.85, 0.36, 0.85, 0, -0.18, 0, 0, 0, 0, true, legPiv);
        limbs.push(legPiv);
      }
      if (isBoss) {
        auraRing = addPart(this.ringGeo, glowMat, 1.15, 1.15, 1.15, 0, 0.14, 0, Math.PI / 2, 0, 0, true);
      }
    } else if (style === 'dragon' || style === 'bone_dragon') {
      const isBone = style === 'bone_dragon';
      // Sculpted Dragon Chest + Glowing Core + Ribbed/Armored Neck + Articulated Fanged Head + Swept Wings + Spiked Tail
      addPart(this.barrelTorsoGeo, primaryMat, 1.05, 0.88, 1.65, 0, 1.0, 0);
      addPart(this.unitOct, glowMat, 0.56, 0.5, 0.56, 0, 0.98, 0.65, 0, 0, 0, true);
      if (isBone) {
        addPart(this.barrelTorsoGeo, secondaryMat, 1.1, 0.16, 0.45, 0, 1.02, 0.25, 0, 0, 0, true);
        addPart(this.barrelTorsoGeo, secondaryMat, 1.02, 0.16, 0.42, 0, 1.02, -0.25, 0, 0, 0, true);
      }

      // Neck & Head Pivot
      addPart(this.taperedLimb, secondaryMat, 2.8, 0.78, 2.8, 0, 1.44, 0.82, 0.42, 0, 0);
      const headPiv = addPivot(0, 1.78, 1.08);
      head = headPiv;
      addPart(this.unitDodeca, primaryMat, 0.56, 0.42, 0.78, 0, 0.08, 0.16, 0, 0, 0, false, headPiv);
      const jawPiv = addPivot(0, -0.06, 0.14, headPiv);
      jaw = jawPiv;
      addPart(this.unitBox, secondaryMat, 0.36, 0.14, 0.52, 0, -0.05, 0.16, 0.1, 0, 0, true, jawPiv);
      addPart(this.spikeGeo, ivoryMat, 0.36, 0.36, 0.36, -0.1, -0.02, 0.42, Math.PI, 0, 0, true, headPiv);
      addPart(this.spikeGeo, ivoryMat, 0.36, 0.36, 0.36, 0.1, -0.02, 0.42, Math.PI, 0, 0, true, headPiv);
      addPart(this.curvedHornGeo, glowMat, 1.25, 1.5, 1.25, -0.18, 0.26, -0.06, -0.45, 0, 0.22, true, headPiv);
      addPart(this.curvedHornGeo, glowMat, 1.25, 1.5, 1.25, 0.18, 0.26, -0.06, -0.45, 0, -0.22, true, headPiv);
      addPart(this.eyeGeo, glowMat, 1.35, 1.35, 1.1, -0.18, 0.14, 0.42, 0, 0, 0, true, headPiv);
      addPart(this.eyeGeo, glowMat, 1.35, 1.35, 1.1, 0.18, 0.14, 0.42, 0, 0, 0, true, headPiv);

      // Dorsal Ridge Spikes
      for (let k = 0; k < 3; k++) {
        addPart(this.crystalSpireGeo, glowMat, 0.65, 0.75, 0.65, 0, 1.45, 0.35 - k * 0.42, -0.28, 0, 0, true);
      }

      // Swept Membrane Wings
      const wLeftPiv = addPivot(-0.44, 1.3, 0.18);
      const wRightPiv = addPivot(0.44, 1.3, 0.18);
      addPart(this.membraneWingGeo, secondaryMat, -1.7, 1.2, 1.55, 0, 0, 0, 0, 0, 0, false, wLeftPiv);
      addPart(this.membraneWingGeo, secondaryMat, 1.7, 1.2, 1.55, 0, 0, 0, 0, 0, 0, false, wRightPiv);
      wings.push(wLeftPiv, wRightPiv);

      // Articulated Spiked Tail
      const tailPiv = addPivot(0, 0.92, -0.82);
      tail = tailPiv;
      addPart(this.unitCone, secondaryMat, 0.48, 1.55, 0.48, 0, -0.06, -0.72, -Math.PI * 0.44, 0, 0, false, tailPiv);
      addPart(this.crystalSpireGeo, glowMat, 0.55, 0.75, 0.55, 0, -0.08, -1.45, -Math.PI * 0.45, 0, 0, true, tailPiv);

      addQuadrupedLegs(0.38, 0.62, 0.5, -0.5, 1.65, secondaryMat);
      if (isBoss) {
        auraRing = addPart(this.ringGeo, glowMat, 1.55, 1.55, 1.55, 0, 0.16, 0, Math.PI / 2, 0, 0, true);
      }
    } else if (style === 'serpent' || style === 'wyrm' || style === 'salamander' || style === 'shark') {
      const isShark = style === 'shark';
      const isSalamander = style === 'salamander';
      const headPiv = addPivot(0, isShark ? 0.72 : 0.78, 0.68);
      head = headPiv;
      addPart(this.unitDodeca, primaryMat, 0.54, 0.42, 0.66, 0, 0, 0.1, 0, 0, 0, false, headPiv);
      const jawPiv = addPivot(0, -0.1, 0.08, headPiv);
      jaw = jawPiv;
      addPart(this.unitBox, secondaryMat, 0.36, 0.12, 0.44, 0, -0.04, 0.16, 0.08, 0, 0, true, jawPiv);
      addPart(this.eyeGeo, glowMat, 1.15, 1.15, 1.0, -0.16, 0.08, 0.32, 0, 0, 0, true, headPiv);
      addPart(this.eyeGeo, glowMat, 1.15, 1.15, 1.0, 0.16, 0.08, 0.32, 0, 0, 0, true, headPiv);

      if (isShark) {
        addPart(this.finGeo, secondaryMat, 1.2, 1.3, 1.2, 0, 0.94, 0.05, 0, 0, 0, true);
      } else if (!isSalamander) {
        addPart(this.unitBox, secondaryMat, 0.84, 0.48, 0.16, 0, 0.74, 0.54, -0.15, 0, 0, true); // Flared hood
      }

      // 4 Sinuous S-wave Segments
      for (let s = 0; s < 4; s++) {
        const seg = addPivot(0, isShark ? 0.64 : 0.42 - s * 0.03, 0.35 - s * 0.46);
        const rad = 0.62 - s * 0.1;
        addPart(
          s === 3 ? this.unitCone : this.unitSphere,
          s % 2 === 0 ? primaryMat : secondaryMat,
          rad,
          rad * 0.85,
          s === 3 ? 0.9 : 0.75,
          0,
          0,
          0,
          s === 3 ? -Math.PI * 0.46 : 0,
          0,
          0,
          false,
          seg,
        );
        segments.push(seg);
        limbs.push(seg);
      }
      if (isSalamander) {
        addQuadrupedLegs(0.32, 0.34, 0.28, -0.35, 0.95, secondaryMat);
      }
      if (isBoss) {
        auraRing = addPart(this.ringGeo, glowMat, 1.25, 1.25, 1.25, 0, 0.14, 0, Math.PI / 2, 0, 0, true);
      }
    } else if (style === 'golem' || style === 'treant' || style === 'titan' || style === 'crystal_golem') {
      const isTreant = style === 'treant';
      const isCrystal = style === 'crystal_golem';

      // Heavy Legs
      for (const side of [-1, 1]) {
        const legPiv = addPivot(side * 0.34, 0.76, 0);
        addPart(this.unitDodeca, secondaryMat, 0.42, 0.76, 0.42, 0, -0.38, 0, 0, 0, 0, false, legPiv);
        limbs.push(legPiv);
      }

      // Broad Craggy Torso + Glowing Rune Heart Core
      addPart(this.unitDodeca, primaryMat, 1.32, 1.15, 0.88, 0, 1.28, 0);
      addPart(this.crystalSpireGeo, glowMat, 0.95, 0.75, 0.55, 0, 1.28, 0.38, 0, 0, 0, true);

      // Shoulder Boulders / Foliage / Crystal Clusters
      for (const side of [-1, 1]) {
        addPart(this.unitDodeca, secondaryMat, 0.54, 0.5, 0.54, side * 0.72, 1.62, 0, 0, 0, -side * 0.25, true);
        if (isCrystal || isBoss) {
          addPart(this.crystalSpireGeo, glowMat, 0.85, 1.0, 0.85, side * 0.65, 1.98, 0, 0, 0, -side * 0.32, true);
        }
      }

      // Monolith Head + Visor Eyes
      const headPiv = addPivot(0, 1.88, 0.04);
      head = headPiv;
      addPart(this.unitDodeca, isTreant ? primaryMat : secondaryMat, 0.54, 0.48, 0.52, 0, 0.12, 0, 0, 0, 0, false, headPiv);
      if (isTreant) {
        addPart(this.unitDodeca, secondaryMat, 1.1, 0.62, 1.05, 0, 0.46, 0, 0, 0, 0, true, headPiv);
      } else {
        addPart(this.crystalSpireGeo, glowMat, 0.8, 1.05, 0.8, 0, 0.5, 0, 0, 0, 0, true, headPiv);
      }
      addPart(this.eyeGeo, glowMat, 1.45, 0.9, 1.0, -0.1, 0.14, 0.25, 0, 0, 0, true, headPiv);
      addPart(this.eyeGeo, glowMat, 1.45, 0.9, 1.0, 0.1, 0.14, 0.25, 0, 0, 0, true, headPiv);

      // Heavy Arms
      for (const side of [-1, 1]) {
        const armPiv = addPivot(side * 0.82, 1.55, 0);
        addPart(this.unitBox, secondaryMat, 0.34, 0.92, 0.34, 0, -0.45, 0.08, 0, 0, 0, false, armPiv);
        addPart(this.unitDodeca, primaryMat, 0.44, 0.38, 0.44, 0, -0.88, 0.1, 0, 0, 0, true, armPiv);
        limbs.push(armPiv);
      }

      if (isBoss) {
        auraRing = addPart(this.ringGeo, glowMat, 1.4, 1.4, 1.4, 0, 0.14, 0, Math.PI / 2, 0, 0, true);
      }
    } else if (style === 'wisp' || style === 'reaper' || style === 'djinn' || style === 'jellyfish') {
      if (style === 'jellyfish') {
        addPart(this.shellDomeGeo, primaryMat, 0.95, 1.25, 0.95, 0, 1.25, 0);
        addPart(this.unitSphere, glowMat, 0.44, 0.38, 0.44, 0, 1.38, 0, 0, 0, 0, true);
        for (let t = 0; t < 4; t++) {
          const ang = (t / 4) * Math.PI * 2;
          const tPiv = addPivot(Math.cos(ang) * 0.26, 1.24, Math.sin(ang) * 0.26);
          addPart(this.taperedLimb, glowMat, 0.7, 0.85, 0.7, 0, -0.42, 0, 0, 0, 0, false, tPiv);
          limbs.push(tPiv);
        }
      } else {
        const core = addPart(this.crystalSpireGeo, glowMat, 0.95, 1.0, 0.95, 0, 1.38, 0);
        const s1 = addPart(this.crystalSpireGeo, secondaryMat, 0.48, 0.65, 0.48, -0.52, 1.38, 0, 0, 0, 0.45);
        const s2 = addPart(this.crystalSpireGeo, secondaryMat, 0.48, 0.65, 0.48, 0.52, 1.38, 0, 0, 0, -0.45);
        if (style === 'reaper' || style === 'djinn') {
          addPart(this.unitCone, primaryMat, 0.68, 1.15, 0.68, 0, 1.22, 0);
          addPart(this.eyeGeo, glowMat, 1.1, 1.1, 1.1, -0.1, 1.54, 0.24, 0, 0, 0, true);
          addPart(this.eyeGeo, glowMat, 1.1, 1.1, 1.1, 0.1, 1.54, 0.24, 0, 0, 0, true);
        }
        wings.push(core, s1, s2);
      }
    } else if (style === 'slime' || style === 'frog') {
      const isFrog = style === 'frog';
      const body = addPart(this.unitSphere, primaryMat, 0.98, 0.76, 0.98, 0, 0.38, 0);
      addPart(this.unitOct, glowMat, 0.44, 0.38, 0.44, 0, 0.38, 0, 0, 0, 0, true);
      addPart(this.eyeGeo, isFrog ? ivoryMat : glowMat, 1.4, 1.4, 1.2, -0.18, isFrog ? 0.66 : 0.44, 0.38, 0, 0, 0, true);
      addPart(this.eyeGeo, isFrog ? ivoryMat : glowMat, 1.4, 1.4, 1.2, 0.18, isFrog ? 0.66 : 0.44, 0.38, 0, 0, 0, true);
      if (isFrog) {
        addPart(this.unitBox, secondaryMat, 0.34, 0.22, 0.44, -0.42, 0.2, -0.18, 0, 0, 0.2, true);
        addPart(this.unitBox, secondaryMat, 0.34, 0.22, 0.44, 0.42, 0.2, -0.18, 0, 0, -0.2, true);
      }
      if (isBoss) {
        addPart(this.unitCyl, glowMat, 0.48, 0.22, 0.48, 0, 0.85, 0, 0, 0, 0, true);
        auraRing = addPart(this.ringGeo, glowMat, 1.15, 1.15, 1.15, 0, 0.12, 0, Math.PI / 2, 0, 0, true);
      }
      limbs.push(body);
    } else {
      // Humanoid Warriors, Mages, Knights, Mummies, Void Stalkers
      const isCaster = style === 'mage';
      const isKnight = style === 'knight';
      const isVoid = style === 'void_stalker';

      for (const side of [-1, 1]) {
        const legPiv = addPivot(side * 0.16, 0.68, 0);
        addPart(this.taperedLimb, secondaryMat, 1.45, 0.68, 1.45, 0, -0.34, 0, 0, 0, 0, false, legPiv);
        addPart(this.unitBox, darkSocketMat, 0.18, 0.1, 0.26, 0, -0.64, 0.04, 0, 0, 0, true, legPiv);
        limbs.push(legPiv);
      }

      // Layered Armor/Robe Torso + Belt + Pauldrons
      addPart(this.barrelTorsoGeo, primaryMat, 0.68, 0.76, 0.48, 0, 1.04, 0);
      addPart(this.unitBox, secondaryMat, 0.66, 0.14, 0.38, 0, 0.78, 0, 0, 0, 0, true);
      addPart(this.unitDodeca, secondaryMat, 0.34, 0.26, 0.34, -0.44, 1.38, 0, 0, 0, 0.28, true);
      addPart(this.unitDodeca, secondaryMat, 0.34, 0.26, 0.34, 0.44, 1.38, 0, 0, 0, -0.28, true);
      if (isVoid || isBoss) {
        addPart(this.unitBox, secondaryMat, 0.68, 0.94, 0.08, 0, 0.96, -0.24, 0.18, 0, 0, true);
      }

      // Head Pivot + Helmet / Wizard Hat / Crown
      const headPiv = addPivot(0, 1.54, 0);
      head = headPiv;
      addPart(this.unitDodeca, primaryMat, 0.44, 0.44, 0.44, 0, 0.12, 0, 0, 0, 0, false, headPiv);
      addPart(this.eyeGeo, glowMat, 1.1, 1.0, 1.0, -0.09, 0.14, 0.2, 0, 0, 0, true, headPiv);
      addPart(this.eyeGeo, glowMat, 1.1, 1.0, 1.0, 0.09, 0.14, 0.2, 0, 0, 0, true, headPiv);

      if (isCaster) {
        addPart(this.unitCone, secondaryMat, 0.64, 0.58, 0.64, 0, 0.48, 0, 0, 0, 0, true, headPiv);
      } else if (isKnight || isBoss) {
        addPart(this.unitCyl, secondaryMat, 0.46, 0.22, 0.46, 0, 0.26, 0, 0, 0, 0, true, headPiv);
        addPart(this.curvedHornGeo, glowMat, 0.9, 1.0, 0.9, -0.18, 0.34, 0, 0, Math.PI, 0.25, true, headPiv);
        addPart(this.curvedHornGeo, glowMat, 0.9, 1.0, 0.9, 0.18, 0.34, 0, 0, 0, -0.25, true, headPiv);
      } else if (isVoid) {
        addPart(this.crystalSpireGeo, glowMat, 0.6, 0.72, 0.6, 0, 0.48, 0, -0.2, 0, 0, true, headPiv);
      }

      // Articulated Arms + Sculpted Weapon
      const lArmPiv = addPivot(-0.44, 1.32, 0);
      const rArmPiv = addPivot(0.44, 1.32, 0);
      addPart(this.taperedLimb, primaryMat, 1.3, 0.6, 1.3, 0, -0.28, 0, 0, 0, 0, false, lArmPiv);
      addPart(this.taperedLimb, secondaryMat, 1.3, 0.6, 1.3, 0, -0.28, 0.06, -0.35, 0, 0, false, rArmPiv);
      if (isCaster) {
        addPart(this.unitCyl, secondaryMat, 0.08, 1.38, 0.08, 0.05, -0.1, 0.28, 0.2, 0, 0, true, rArmPiv);
        addPart(this.crystalSpireGeo, glowMat, 0.54, 0.54, 0.54, 0.05, 0.65, 0.42, 0, 0, 0, true, rArmPiv);
      } else {
        addPart(this.swordBladeGeo, isBoss ? glowMat : secondaryMat, 1.05, 1.0, 1.05, 0.04, -0.44, 0.24, 1.05, 0, 0, true, rArmPiv);
        if (isKnight || isBoss) {
          addPart(this.shieldGeo, secondaryMat, 0.95, 1.05, 0.95, -0.08, -0.32, 0.16, 0, 0, 0, true, lArmPiv);
        }
      }
      limbs.push(rArmPiv, lArmPiv);

      if (isBoss) {
        auraRing = addPart(this.ringGeo, glowMat, 1.2, 1.2, 1.2, 0, 0.14, 0, Math.PI / 2, 0, 0, true);
      }
    }

    root.scale.setScalar(def.scale);

    return {
      root,
      primaryMat,
      limbs,
      wings,
      detailParts,
      head,
      jaw,
      tail,
      segments,
      auraRing,
      disposeMaterials: () => {
        primaryMat.dispose();
        secondaryMat.dispose();
        darkSocketMat.dispose();
        ivoryMat.dispose();
        glowMat.dispose();
      },
    };
  }

  public buildNpc(npc: NpcDefinition, castShadows: boolean): BuiltEntityVisual {
    const root = new THREE.Group();
    const robeMat = new THREE.MeshStandardMaterial({
      color: npc.robeHex,
      roughness: 0.78,
      metalness: 0.08,
    });
    const accentMat = new THREE.MeshStandardMaterial({
      color: npc.accentHex,
      roughness: 0.32,
      metalness: 0.6,
    });
    const skinMat = new THREE.MeshStandardMaterial({
      color: 0xe8be9e,
      roughness: 0.72,
    });

    const shadowMesh = new THREE.Mesh(this.shadowDiscGeo, this.shadowDiscMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = 0.025;
    root.add(shadowMesh);

    const addPart = (
      geo: THREE.BufferGeometry,
      mat: THREE.Material,
      sx: number,
      sy: number,
      sz: number,
      px: number,
      py: number,
      pz: number,
    ) => {
      const m = new THREE.Mesh(geo, mat);
      m.scale.set(sx, sy, sz);
      m.position.set(px, py, pz);
      m.castShadow = castShadows;
      m.receiveShadow = castShadows;
      root.add(m);
      return m;
    };

    const lLeg = addPart(this.unitBox, accentMat, 0.19, 0.6, 0.19, -0.14, 0.3, 0);
    const rLeg = addPart(this.unitBox, accentMat, 0.19, 0.6, 0.19, 0.14, 0.3, 0);
    addPart(this.barrelTorsoGeo, robeMat, 0.6, 0.74, 0.42, 0, 0.96, 0);
    addPart(this.unitDodeca, skinMat, 0.4, 0.4, 0.4, 0, 1.54, 0);
    if (npc.role === 'guard') {
      addPart(this.unitCyl, accentMat, 0.46, 0.24, 0.46, 0, 1.72, 0);
    } else if (npc.role === 'quest') {
      addPart(this.unitCone, accentMat, 0.56, 0.46, 0.56, 0, 1.88, 0);
    } else if (npc.role === 'blacksmith') {
      addPart(this.unitBox, accentMat, 0.5, 0.44, 0.38, 0, 1.0, 0.02);
    }
    const lArm = addPart(this.unitBox, robeMat, 0.16, 0.55, 0.16, -0.37, 0.98, 0);
    const rArm = addPart(this.unitBox, robeMat, 0.16, 0.55, 0.16, 0.37, 0.98, 0);

    const badgeMat = new THREE.MeshBasicMaterial({ color: npc.accentHex });
    const badge = addPart(this.unitCone, badgeMat, 0.22, 0.28, 0.22, 0, 2.25, 0);

    return {
      root,
      primaryMat: robeMat,
      limbs: [lLeg, rLeg, lArm, rArm],
      wings: [badge],
      detailParts: [],
      disposeMaterials: () => {
        robeMat.dispose();
        accentMat.dispose();
        skinMat.dispose();
        badgeMat.dispose();
      },
    };
  }

  public dispose(): void {
    this.unitBox.dispose();
    this.unitSphere.dispose();
    this.unitCone.dispose();
    this.unitCyl.dispose();
    this.taperedLimb.dispose();
    this.unitOct.dispose();
    this.unitDodeca.dispose();
    this.eyeGeo.dispose();
    this.spikeGeo.dispose();
    this.ringGeo.dispose();
    this.shadowDiscGeo.dispose();
    this.shadowDiscMat.dispose();
    this.barrelTorsoGeo.dispose();
    this.shellDomeGeo.dispose();
    this.crystalSpireGeo.dispose();
    this.membraneWingGeo.dispose();
    this.featherWingGeo.dispose();
    this.butterflyWingGeo.dispose();
    this.swordBladeGeo.dispose();
    this.shieldGeo.dispose();
    this.curvedHornGeo.dispose();
    this.finGeo.dispose();
  }
}
