import type { Phase } from "./store";

/** x position of the three lanes */
export const LANES = [-5.3, 0, 5.3] as const;

/** half width of the asphalt */
export const ROAD_HALF = 8;

/** how far the player may leave the road centre line */
export const PLAY_LIMIT = 6.6;

export const ROAD_LENGTH = 480;

export const world = {
  phase: "menu" as Phase,
  /** current speed in world units / second */
  speed: 0,
  /** lateral position of the player car */
  x: 0,
  /** lateral velocity */
  vx: 0,
  distance: 0,
  score: 0,
  pickups: 0,
  bonus: 0,
  nitro: 100,
  boosting: false,
  countdown: 3,
  crashTimer: 0,
  shake: 0,
  elapsed: 0,
  steer: 0,
  scraped: false,
};

// exposed for debugging / automated smoke tests
if (typeof window !== "undefined") {
  (window as unknown as { __world: typeof world }).__world = world;
}

export function resetWorld() {
  world.speed = 0;
  world.x = 0;
  world.vx = 0;
  world.distance = 0;
  world.score = 0;
  world.pickups = 0;
  world.bonus = 0;
  world.nitro = 100;
  world.boosting = false;
  world.countdown = 3;
  world.crashTimer = 0;
  world.shake = 0;
  world.elapsed = 0;
  world.steer = 0;
  world.scraped = false;
}

export function startRun() {
  resetWorld();
  world.phase = "countdown";
}

export function clamp(v: number, min: number, max: number) {
  return Math.min(max, Math.max(min, v));
}
