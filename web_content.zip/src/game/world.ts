import * as THREE from "three";
import { makeFarmer } from "@/game/actors";

export type Collider = { x: number; z: number; r: number };
export type ForageSpawn = { x: number; z: number; mesh: THREE.Group };

export type ValleyWorld = {
  colliders: Collider[];
  forage: ForageSpawn[];
  lamps: THREE.MeshStandardMaterial[];
  sky: THREE.ShaderMaterial;
  skyMesh: THREE.Object3D;
  water: THREE.ShaderMaterial;
  sun: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  fog: THREE.FogExp2;
  clouds: THREE.Object3D[];
  birds: THREE.Object3D[];
  rain: THREE.Points;
  rainPos: Float32Array;
  npcs: THREE.Group[];
};

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function canvasTex(paint: (ctx: CanvasRenderingContext2D, size: number) => void, repeat: number) {
  const size = 256;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("canvas");
  paint(ctx, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  tex.repeat.set(repeat, repeat);
  return tex;
}

function std(color: number, opts: { map?: THREE.Texture; roughness?: number; metalness?: number } = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    map: opts.map,
    roughness: opts.roughness ?? 0.9,
    metalness: opts.metalness ?? 0,
  });
}

function sign(title: string, sub: string, bg: string, fg: string) {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 256;
  const g = canvas.getContext("2d");
  if (g) {
    g.fillStyle = bg;
    g.fillRect(0, 0, 512, 256);
    g.strokeStyle = fg;
    g.lineWidth = 12;
    g.strokeRect(10, 10, 492, 236);
    g.fillStyle = fg;
    g.textAlign = "center";
    g.font = "700 78px Nunito, sans-serif";
    g.fillText(title, 256, 118);
    g.font = "600 36px Nunito, sans-serif";
    g.fillText(sub, 256, 180);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  const mesh = new THREE.Mesh(
    new THREE.PlaneGeometry(3.4, 1.7),
    new THREE.MeshStandardMaterial({ map: tex, roughness: 0.65 }),
  );
  return mesh;
}

export function buildWorld(scene: THREE.Scene): ValleyWorld {
  const rand = rng(20261029);
  const colliders: Collider[] = [];
  const forage: ForageSpawn[] = [];
  const lamps: THREE.MeshStandardMaterial[] = [];
  const npcs: THREE.Group[] = [];

  const grassMap = canvasTex((ctx, s) => {
    ctx.fillStyle = "#2c7a3c";
    ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 1800; i++) {
      ctx.fillStyle = i % 3 === 0 ? "#1d5a2b" : i % 3 === 1 ? "#3d9450" : "#246636";
      const x = rand() * s;
      const y = rand() * s;
      ctx.fillRect(x, y, 2 + rand() * 3, 5 + rand() * 8);
    }
  }, 48);

  const dirtMap = canvasTex((ctx, s) => {
    ctx.fillStyle = "#6a4326";
    ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 900; i++) {
      ctx.fillStyle = rand() > 0.5 ? "#4a2d16" : "#8a5a34";
      ctx.beginPath();
      ctx.arc(rand() * s, rand() * s, 2 + rand() * 5, 0, Math.PI * 2);
      ctx.fill();
    }
  }, 4);

  const stoneMap = canvasTex((ctx, s) => {
    ctx.fillStyle = "#8d8a80";
    ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 40; i++) {
      ctx.fillStyle = rand() > 0.5 ? "#6f6c64" : "#b1aea3";
      ctx.fillRect(rand() * s, rand() * s, 30 + rand() * 50, 18 + rand() * 24);
    }
  }, 6);

  const asphalt = canvasTex((ctx, s) => {
    ctx.fillStyle = "#3c4652";
    ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 1200; i++) {
      ctx.fillStyle = rand() > 0.5 ? "#2a313a" : "#55616e";
      ctx.fillRect(rand() * s, rand() * s, 2, 2);
    }
  }, 18);

  const wood = canvasTex((ctx, s) => {
    ctx.fillStyle = "#8a5a32";
    ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = "#5c3a1e";
    for (let y = 0; y < s; y += 32) ctx.fillRect(0, y, s, 4);
  }, 1);

  const roofTex = canvasTex((ctx, s) => {
    ctx.fillStyle = "#8d3d32";
    ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = "#6e2d26";
    for (let y = 0; y < s; y += 18) ctx.fillRect(0, y, s, 3);
  }, 1);

  const grass = std(0xffffff, { map: grassMap, roughness: 1 });
  const dirt = std(0xffffff, { map: dirtMap, roughness: 1 });
  const stone = std(0xffffff, { map: stoneMap, roughness: 0.85 });
  const roadMat = std(0xffffff, { map: asphalt, roughness: 0.78 });
  const woodMat = std(0xffffff, { map: wood, roughness: 0.8 });
  const roofMat = std(0xffffff, { map: roofTex, roughness: 0.7 });

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(520, 520), grass);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);

  const yard = new THREE.Mesh(new THREE.PlaneGeometry(48, 46), dirt);
  yard.rotation.x = -Math.PI / 2;
  yard.position.set(-18, 0.02, 36);
  yard.receiveShadow = true;
  scene.add(yard);

  const road = new THREE.Mesh(new THREE.PlaneGeometry(12, 250), roadMat);
  road.rotation.x = -Math.PI / 2;
  road.position.set(0, 0.03, -30);
  road.receiveShadow = true;
  scene.add(road);

  const dashGeo = new THREE.BoxGeometry(0.28, 0.02, 1.4);
  const dashMat = std(0xe7d7a4, { roughness: 0.6 });
  const dashes = new THREE.InstancedMesh(dashGeo, dashMat, 28);
  const dummy = new THREE.Object3D();
  for (let i = 0; i < 28; i++) {
    dummy.position.set(0, 0.05, 70 - i * 8);
    dummy.updateMatrix();
    dashes.setMatrixAt(i, dummy.matrix);
  }
  scene.add(dashes);

  const plaza = new THREE.Mesh(new THREE.CircleGeometry(18, 28), stone);
  plaza.rotation.x = -Math.PI / 2;
  plaza.position.set(0, 0.045, -98);
  plaza.receiveShadow = true;
  scene.add(plaza);

  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    uniforms: {
      uTop: { value: new THREE.Color("#6eb6e6") },
      uHor: { value: new THREE.Color("#f3d2a4") },
      uBot: { value: new THREE.Color("#8fbf6a") },
    },
    vertexShader: `
      varying vec3 vPos;
      void main() {
        vPos = position;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      varying vec3 vPos;
      uniform vec3 uTop;
      uniform vec3 uHor;
      uniform vec3 uBot;
      void main() {
        float h = normalize(vPos).y;
        vec3 col = mix(uHor, uTop, smoothstep(0.0, 0.5, h));
        col = mix(uBot, col, smoothstep(-0.2, 0.08, h));
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
  const sky = new THREE.Mesh(new THREE.SphereGeometry(400, 28, 16), skyMat);
  scene.add(sky);

  const fog = new THREE.FogExp2(0xf3d2a4, 0.0065);
  scene.fog = fog;
  scene.background = new THREE.Color(0x8ec8ea);

  const hemi = new THREE.HemisphereLight(0xc5e4ff, 0x3e6a34, 0.78);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff1d6, 1.35);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.near = 2;
  sun.shadow.camera.far = 160;
  const extent = 42;
  sun.shadow.camera.left = -extent;
  sun.shadow.camera.right = extent;
  sun.shadow.camera.top = extent;
  sun.shadow.camera.bottom = -extent;
  sun.shadow.bias = -0.00035;
  sun.shadow.normalBias = 0.035;
  scene.add(sun);
  scene.add(sun.target);

  const waterMat = new THREE.ShaderMaterial({
    transparent: true,
    uniforms: {
      uTime: { value: 0 },
      uColor: { value: new THREE.Color("#2f8fb4") },
    },
    vertexShader: `
      uniform float uTime;
      varying vec2 vUv;
      void main() {
        vUv = uv;
        vec3 p = position;
        p.z += sin(position.x * 0.35 + uTime * 1.4) * 0.18 + cos(position.y * 0.28 + uTime) * 0.12;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 uColor;
      varying vec2 vUv;
      void main() {
        float shine = 0.75 + 0.25 * sin(vUv.x * 40.0 + vUv.y * 18.0);
        gl_FragColor = vec4(uColor * shine, 0.82);
      }
    `,
  });
  const lake = new THREE.Mesh(new THREE.CircleGeometry(15, 28), waterMat);
  lake.rotation.x = -Math.PI / 2;
  lake.position.set(54, 0.2, -6);
  scene.add(lake);
  colliders.push({ x: 54, z: -6, r: 13.2 });

  const reedMat = std(0x2f7a3e, { roughness: 0.8 });
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    const reed = new THREE.Mesh(new THREE.ConeGeometry(0.12, 1.1, 5), reedMat);
    reed.position.set(54 + Math.cos(a) * 14.2, 0.5, -6 + Math.sin(a) * 14.2);
    reed.castShadow = true;
    scene.add(reed);
  }

  const hillMat = std(0x3f8d4c, { roughness: 1 });
  const hills: [number, number, number][] = [
    [-80, 18, 70],
    [90, 22, 40],
    [70, 16, -80],
    [-90, 20, -40],
    [20, 14, -150],
    [-30, 16, 100],
  ];
  for (const [x, s, z] of hills) {
    const h = new THREE.Mesh(new THREE.SphereGeometry(s, 16, 10), hillMat);
    h.position.set(x, -s * 0.45, z);
    h.scale.y = 0.55;
    h.receiveShadow = true;
    scene.add(h);
  }

  const placeBuilding = (
    x: number,
    z: number,
    w: number,
    d: number,
    h: number,
    wall: number,
    awning?: number,
  ) => {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    const box = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), std(wall, { roughness: 0.82 }));
    box.position.y = h / 2;
    box.castShadow = true;
    box.receiveShadow = true;
    group.add(box);
    const roof = new THREE.Mesh(new THREE.ConeGeometry(Math.max(w, d) * 0.72, h * 0.55, 4), roofMat);
    roof.position.y = h + h * 0.22;
    roof.rotation.y = Math.PI / 4;
    roof.castShadow = true;
    group.add(roof);
    const door = new THREE.Mesh(new THREE.BoxGeometry(w * 0.22, h * 0.48, 0.12), std(0x4a3024, { roughness: 0.8 }));
    door.position.set(0, h * 0.24, d / 2 + 0.02);
    group.add(door);
    const winMat = new THREE.MeshStandardMaterial({
      color: 0xf6e3b0,
      emissive: 0xf6e3b0,
      emissiveIntensity: 0.25,
      roughness: 0.3,
    });
    lamps.push(winMat);
    for (const sx of [-w * 0.28, w * 0.28]) {
      const win = new THREE.Mesh(new THREE.BoxGeometry(w * 0.16, h * 0.22, 0.1), winMat);
      win.position.set(sx, h * 0.62, d / 2 + 0.04);
      group.add(win);
    }
    if (awning !== undefined) {
      const aw = new THREE.Mesh(new THREE.BoxGeometry(w * 0.84, 0.12, 1.4), std(awning, { roughness: 0.6 }));
      aw.position.set(0, h * 0.58, d / 2 + 0.7);
      aw.castShadow = true;
      group.add(aw);
    }
    const chimney = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.9, 0.5), std(0x6e5348, { roughness: 0.85 }));
    chimney.position.set(w * 0.25, h + 0.7, 0);
    chimney.castShadow = true;
    group.add(chimney);
    scene.add(group);
    colliders.push({ x, z, r: Math.max(w, d) * 0.46 });
    return group;
  };

  placeBuilding(-14, 66, 7, 6, 3.4, 0xf1e2c8);
  placeBuilding(-50, 28, 11, 7, 4.2, 0x8d4d32);
  placeBuilding(-20, -104, 8, 6.5, 4, 0xf4efe2, 0x1f7a45);
  placeBuilding(20, -104, 8, 6.5, 4, 0xf6e7c4, 0xe2a23a);
  placeBuilding(-38, -82, 7, 6, 3.6, 0xe7d3b4);
  placeBuilding(38, -84, 7, 6, 3.8, 0xd9c4a4);
  placeBuilding(0, -122, 10, 7, 5, 0xf7f1e4);

  const shopSign = sign("SEMENTES", "Barnaby", "#1f7a45", "#f4efe2");
  shopSign.position.set(-20, 4.6, -100.2);
  scene.add(shopSign);
  const marketSign = sign("ATACADO", "Beatriz", "#e2a23a", "#142016");
  marketSign.position.set(20, 4.6, -100.2);
  scene.add(marketSign);
  const townSign = sign("ECOVALLEY", "Cidade", "#142016", "#f4efe2");
  townSign.position.set(0, 3.2, -72);
  scene.add(townSign);
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 3.2, 8), woodMat);
  post.position.set(0, 1.6, -72);
  post.castShadow = true;
  scene.add(post);
  const farmSign = sign("FAZENDA", "Canteiros", "#6a4326", "#f4efe2");
  farmSign.position.set(-6, 2.4, 48);
  scene.add(farmSign);
  const post2 = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 2.4, 8), woodMat);
  post2.position.set(-6, 1.2, 48);
  scene.add(post2);

  const addNpc = (x: number, z: number, shirt: number) => {
    const rig = makeFarmer(shirt);
    rig.group.position.set(x, 0, z);
    rig.group.rotation.y = 0;
    scene.add(rig.group);
    npcs.push(rig.group);
  };
  addNpc(-20, -96.5, 0xc47a32);
  addNpc(20, -96.5, 0xd8a04a);

  const fountainBase = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 2.6, 0.5, 16), stone);
  fountainBase.position.set(0, 0.3, -98);
  fountainBase.castShadow = true;
  fountainBase.receiveShadow = true;
  scene.add(fountainBase);
  const basin = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.6, 0.45, 16), waterMat);
  basin.position.set(0, 0.6, -98);
  scene.add(basin);
  const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.22, 1.4, 8), stone);
  pillar.position.set(0, 1.3, -98);
  scene.add(pillar);
  colliders.push({ x: 0, z: -98, r: 2.6 });

  const trunkGeo = new THREE.CylinderGeometry(0.22, 0.34, 2.1, 6);
  const leafGeo = new THREE.SphereGeometry(1.25, 8, 6);
  const trunkMat = std(0x6b4428, { roughness: 0.95 });
  const leafMat = std(0x2f7d3e, { roughness: 0.85 });
  const TREE_N = 78;
  const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, TREE_N);
  const leaves = new THREE.InstancedMesh(leafGeo, leafMat, TREE_N);
  trunks.castShadow = true;
  leaves.castShadow = true;
  const leafColors = [new THREE.Color("#2f7d3e"), new THREE.Color("#3e9148"), new THREE.Color("#246636"), new THREE.Color("#4f8f3a")];
  let placed = 0;
  const tryTree = (x: number, z: number, scale: number) => {
    if (placed >= TREE_N) return;
    dummy.position.set(x, 1.05 * scale, z);
    dummy.scale.set(scale, scale, scale);
    dummy.rotation.set(0, 0, 0);
    dummy.updateMatrix();
    trunks.setMatrixAt(placed, dummy.matrix);
    dummy.position.set(x, 2.35 * scale, z);
    dummy.scale.set(scale * 1.35, scale * 1.05, scale * 1.35);
    dummy.updateMatrix();
    leaves.setMatrixAt(placed, dummy.matrix);
    leaves.setColorAt(placed, leafColors[placed % leafColors.length]!);
    placed++;
  };
  for (let i = 0; i < 40 && placed < TREE_N; i++) {
    const x = -95 + rand() * 48;
    const z = -30 + rand() * 100;
    tryTree(x, z, 0.85 + rand() * 0.7);
  }
  let guard = 0;
  while (placed < TREE_N && guard < 400) {
    guard++;
    const x = (rand() - 0.5) * 280;
    const z = (rand() - 0.5) * 300 - 10;
    const onRoad = Math.abs(x) < 9 && z < 85 && z > -145;
    const yardHit = x > -42 && x < 4 && z > 8 && z < 72;
    const townHit = Math.abs(x) < 46 && z < -66 && z > -132;
    const lakeHit = Math.hypot(x - 54, z + 6) < 20;
    if (onRoad || yardHit || townHit || lakeHit) continue;
    tryTree(x, z, 0.8 + rand() * 0.9);
  }
  trunks.count = placed;
  leaves.count = placed;
  if (leaves.instanceColor) leaves.instanceColor.needsUpdate = true;
  scene.add(trunks, leaves);

  const tuftGeo = new THREE.ConeGeometry(0.16, 0.45, 4);
  const tuftMat = std(0x3c9a4a, { roughness: 1 });
  const TUFTS = 220;
  const tufts = new THREE.InstancedMesh(tuftGeo, tuftMat, TUFTS);
  for (let i = 0; i < TUFTS; i++) {
    const side = i % 2 === 0 ? -1 : 1;
    const x = side * (7.2 + rand() * 10);
    const z = 75 - rand() * 160;
    dummy.position.set(x, 0.2, z);
    dummy.scale.set(0.7 + rand(), 0.6 + rand() * 0.8, 0.7 + rand());
    dummy.rotation.y = rand() * 3;
    dummy.updateMatrix();
    tufts.setMatrixAt(i, dummy.matrix);
  }
  scene.add(tufts);

  const flowerGeo = new THREE.SphereGeometry(0.12, 6, 5);
  const flowerMat = std(0xffffff, { roughness: 0.6 });
  const FLOWERS = 80;
  const flowers = new THREE.InstancedMesh(flowerGeo, flowerMat, FLOWERS);
  const flowerCols = [new THREE.Color("#e2a23a"), new THREE.Color("#f4efe2"), new THREE.Color("#d4534a"), new THREE.Color("#7ebfdf")];
  for (let i = 0; i < FLOWERS; i++) {
    const side = i % 2 === 0 ? 1 : -1;
    dummy.position.set(side * (6.4 + rand() * 1.2), 0.16, 60 - i * 1.7);
    dummy.scale.setScalar(0.7 + rand() * 0.6);
    dummy.rotation.set(0, 0, 0);
    dummy.updateMatrix();
    flowers.setMatrixAt(i, dummy.matrix);
    flowers.setColorAt(i, flowerCols[i % flowerCols.length]!);
  }
  if (flowers.instanceColor) flowers.instanceColor.needsUpdate = true;
  scene.add(flowers);

  const rockGeo = new THREE.DodecahedronGeometry(0.45, 0);
  const rockMat = std(0x8a877e, { roughness: 0.95 });
  const rocks = new THREE.InstancedMesh(rockGeo, rockMat, 18);
  rocks.castShadow = true;
  for (let i = 0; i < 18; i++) {
    dummy.position.set(-70 + rand() * 30, 0.25, -10 + rand() * 70);
    dummy.scale.set(0.6 + rand(), 0.4 + rand() * 0.5, 0.6 + rand());
    dummy.rotation.set(rand(), rand(), rand());
    dummy.updateMatrix();
    rocks.setMatrixAt(i, dummy.matrix);
  }
  scene.add(rocks);

  const forageMat = new THREE.MeshStandardMaterial({
    color: 0x37c26b,
    emissive: 0x1f7a45,
    emissiveIntensity: 0.35,
    roughness: 0.45,
  });
  for (let i = 0; i < 12; i++) {
    const mesh = new THREE.Group();
    const bush = new THREE.Mesh(new THREE.DodecahedronGeometry(0.55, 0), forageMat);
    bush.position.y = 0.5;
    bush.castShadow = true;
    mesh.add(bush);
    const x = -88 + rand() * 36;
    const z = -15 + rand() * 80;
    mesh.position.set(x, 0, z);
    scene.add(mesh);
    forage.push({ x, z, mesh });
  }

  const postGeo = new THREE.CylinderGeometry(0.08, 0.1, 1.1, 6);
  const railGeo = new THREE.BoxGeometry(2.1, 0.08, 0.08);
  const fenceMat = woodMat;
  const posts = new THREE.InstancedMesh(postGeo, fenceMat, 40);
  const rails = new THREE.InstancedMesh(railGeo, fenceMat, 36);
  let pi = 0;
  let ri = 0;
  const fenceZ = [16, 54];
  for (const z of fenceZ) {
    for (let x = -36; x <= -4; x += 2.2) {
      if (z === 54 && x > -18 && x < -8) continue;
      dummy.position.set(x, 0.55, z);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      if (pi < 40) posts.setMatrixAt(pi++, dummy.matrix);
      if (x < -4 && !(z === 54 && x > -20 && x < -6) && ri < 36) {
        dummy.position.set(x + 1.05, 0.75, z);
        dummy.updateMatrix();
        rails.setMatrixAt(ri++, dummy.matrix);
      }
    }
  }
  posts.count = pi;
  rails.count = ri;
  scene.add(posts, rails);

  const clouds: THREE.Object3D[] = [];
  const cloudMat = new THREE.MeshStandardMaterial({ color: 0xfffaf2, roughness: 1, transparent: true, opacity: 0.92 });
  for (let i = 0; i < 6; i++) {
    const c = new THREE.Group();
    for (let k = 0; k < 4; k++) {
      const p = new THREE.Mesh(new THREE.SphereGeometry(3 + rand() * 3, 8, 6), cloudMat);
      p.position.set(k * 3.2, rand() * 1.2, rand() * 2);
      c.add(p);
    }
    c.position.set(-80 + i * 40, 38 + rand() * 8, -40 + rand() * 80);
    scene.add(c);
    clouds.push(c);
  }

  const birds: THREE.Object3D[] = [];
  const birdMat = std(0x223028, { roughness: 0.6 });
  for (let i = 0; i < 4; i++) {
    const b = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.9, 4), birdMat);
    b.rotation.x = Math.PI / 2;
    scene.add(b);
    birds.push(b);
  }

  const rainCount = 380;
  const rainPos = new Float32Array(rainCount * 3);
  for (let i = 0; i < rainCount; i++) {
    rainPos[i * 3] = (rand() - 0.5) * 36;
    rainPos[i * 3 + 1] = rand() * 16;
    rainPos[i * 3 + 2] = (rand() - 0.5) * 36;
  }
  const rainGeo = new THREE.BufferGeometry();
  rainGeo.setAttribute("position", new THREE.BufferAttribute(rainPos, 3));
  const rain = new THREE.Points(
    rainGeo,
    new THREE.PointsMaterial({ color: 0xd5e7f5, size: 0.07, transparent: true, opacity: 0.55 }),
  );
  rain.visible = false;
  scene.add(rain);

  const lampPosts: [number, number][] = [
    [-8, -80],
    [8, -80],
    [-8, -112],
    [8, -112],
    [-8, 20],
    [8, 8],
  ];
  for (const [x, z] of lampPosts) {
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 3.2, 6), std(0x2c3330, { roughness: 0.5, metalness: 0.4 }));
    pole.position.set(x, 1.6, z);
    pole.castShadow = true;
    const glowMat = new THREE.MeshStandardMaterial({
      color: 0xf6e3b0,
      emissive: 0xf6e3b0,
      emissiveIntensity: 0.4,
    });
    lamps.push(glowMat);
    const glow = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 8), glowMat);
    glow.position.set(x, 3.25, z);
    scene.add(pole, glow);
  }

  const scare = new THREE.Group();
  const poleS = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 2.2, 6), woodMat);
  poleS.position.y = 1.1;
  const arm = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.08, 0.08), woodMat);
  arm.position.y = 1.7;
  const headS = new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 8), std(0xe7c48a, { roughness: 0.7 }));
  headS.position.y = 2.15;
  const hatS = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.06, 10), std(0x1f7a45, { roughness: 0.6 }));
  hatS.position.y = 2.35;
  scare.add(poleS, arm, headS, hatS);
  scare.position.set(-30, 0, 24);
  scene.add(scare);

  return {
    colliders,
    forage,
    lamps,
    sky: skyMat,
    skyMesh: sky,
    water: waterMat,
    sun,
    hemi,
    fog,
    clouds,
    birds,
    rain,
    rainPos,
    npcs,
  };
}

const topC = new THREE.Color();
const horC = new THREE.Color();
const botC = new THREE.Color();
const fogC = new THREE.Color();
const sunC = new THREE.Color();

export function animateWorld(
  world: ValleyWorld,
  dt: number,
  time: number,
  px: number,
  pz: number,
  hour: number,
  rain: boolean,
  camX: number,
  camZ: number,
) {
  const sky = world.sky;
  const night = hour < 5.5 || hour > 19.2;
  const golden = (hour > 16.5 && hour <= 19.2) || (hour >= 5.5 && hour < 8);
  if (rain) {
    topC.set("#6e7e8c");
    horC.set("#b7c0c4");
    botC.set("#6d8a62");
    fogC.set("#b7c3c6");
  } else if (night) {
    topC.set("#14233f");
    horC.set("#3a4e78");
    botC.set("#1c3a32");
    fogC.set("#24344e");
  } else if (golden) {
    topC.set("#6aa4d6");
    horC.set("#f0b56a");
    botC.set("#c4a15a");
    fogC.set("#f0c48a");
  } else {
    topC.set("#6eb6e6");
    horC.set("#d7ecf8");
    botC.set("#8fbf6a");
    fogC.set("#c5e4f4");
  }
  (sky.uniforms.uTop.value as THREE.Color).copy(topC);
  (sky.uniforms.uHor.value as THREE.Color).copy(horC);
  (sky.uniforms.uBot.value as THREE.Color).copy(botC);
  world.fog.color.copy(fogC);
  world.fog.density = rain ? 0.012 : night ? 0.009 : 0.0062;

  const sunHeight = Math.sin(((hour - 6) / 12) * Math.PI);
  const up = Math.max(0.08, sunHeight);
  world.sun.intensity = rain ? 0.35 : night ? 0.18 : 0.55 + up * 0.9;
  world.hemi.intensity = rain ? 0.45 : night ? 0.42 : 0.72;
  sunC.set(night ? "#9bb4ff" : golden ? "#ffc27a" : "#fff1d6");
  world.sun.color.copy(sunC);
  world.sun.position.set(px + 48, 28 + up * 70, pz + (hour < 12 ? -20 : 24));
  world.sun.target.position.set(px, 0, pz);
  world.sun.target.updateMatrixWorld();

  const lampI = night || rain ? 1.5 : golden ? 0.45 : 0.18;
  for (const m of world.lamps) m.emissiveIntensity = lampI;

  (world.water.uniforms.uTime.value as number) = time;
  world.skyMesh.position.x = camX;
  world.skyMesh.position.z = camZ;

  for (let i = 0; i < world.clouds.length; i++) {
    const c = world.clouds[i]!;
    c.position.x += dt * (1.6 + i * 0.25);
    if (c.position.x > 140) c.position.x = -140;
  }
  for (let i = 0; i < world.birds.length; i++) {
    const b = world.birds[i]!;
    const a = time * 0.35 + i * 1.4;
    const rad = 18 + i * 4;
    b.position.set(px + Math.cos(a) * rad, 14 + Math.sin(time * 2 + i) * 1.2, pz + Math.sin(a) * rad * 0.6);
    b.rotation.y = -a;
  }
  for (const n of world.npcs) {
    n.position.y = Math.sin(time * 2 + n.position.x) * 0.05;
  }

  world.rain.visible = rain;
  if (rain) {
    const attr = world.rain.geometry.getAttribute("position") as THREE.BufferAttribute;
    for (let i = 0; i < world.rainPos.length; i += 3) {
      world.rainPos[i + 1]! -= dt * 16;
      if (world.rainPos[i + 1]! < 0) {
        world.rainPos[i] = px + (Math.random() - 0.5) * 34;
        world.rainPos[i + 1] = 12 + Math.random() * 6;
        world.rainPos[i + 2] = pz + (Math.random() - 0.5) * 34;
      }
    }
    attr.needsUpdate = true;
  }
}
