import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

// Block pitch / sizes (world units ~ metres)
export const P = 56;
export const BLOCK = 44;
export const ROAD = 12;
export const LIMIT = 262; // walkable boundary (mountains sit beyond it)
const GRID = 4; // blocks from -4..4 on each axis

export interface Box {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export interface Building {
  x: number;
  z: number;
  w: number;
  d: number;
  h: number;
  kind: 'house' | 'apartment' | 'shop' | 'office';
  name: string;
}

export interface HiddenSpot {
  x: number;
  z: number;
  name: string;
}

export interface WorldData {
  colliders: Box[];
  buildings: Building[];
  coinSpots: { x: number; z: number }[];
  hidden: HiddenSpot[];
  roadXs: number[];
}

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function toLinear(hex: number): [number, number, number] {
  const c = new THREE.Color(hex);
  c.convertSRGBToLinear();
  return [c.r, c.g, c.b];
}

// Collects vertex-coloured geometry and merges it into few draw calls.
class Batch {
  private geos: THREE.BufferGeometry[] = [];
  private verts = 0;
  private out: THREE.Object3D[];
  private mat: THREE.Material;
  private cast: boolean;

  constructor(out: THREE.Object3D[], mat: THREE.Material, cast: boolean) {
    this.out = out;
    this.mat = mat;
    this.cast = cast;
  }

  private add(g: THREE.BufferGeometry, hex: number) {
    const n = g.attributes.position.count;
    if (this.verts + n > 40000) this.flush();
    const [r, gg, b] = toLinear(hex);
    const arr = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      arr[i * 3] = r;
      arr[i * 3 + 1] = gg;
      arr[i * 3 + 2] = b;
    }
    g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
    this.geos.push(g);
    this.verts += n;
  }

  box(w: number, h: number, d: number, x: number, y: number, z: number, hex: number, ry = 0) {
    const g = new THREE.BoxGeometry(w, h, d);
    if (ry) g.rotateY(ry);
    g.translate(x, y, z);
    this.add(g, hex);
  }

  cone(r: number, h: number, seg: number, x: number, y: number, z: number, hex: number, ry = 0) {
    const g = new THREE.ConeGeometry(r, h, seg);
    if (ry) g.rotateY(ry);
    g.translate(x, y, z);
    this.add(g, hex);
  }

  cyl(rt: number, rb: number, h: number, seg: number, x: number, y: number, z: number, hex: number) {
    const g = new THREE.CylinderGeometry(rt, rb, h, seg);
    g.translate(x, y, z);
    this.add(g, hex);
  }

  ico(r: number, x: number, y: number, z: number, hex: number) {
    const g = new THREE.IcosahedronGeometry(r, 0);
    g.translate(x, y, z);
    this.add(g, hex);
  }

  flush() {
    if (this.geos.length === 0) return;
    const merged = mergeGeometries(this.geos, false);
    this.geos = [];
    this.verts = 0;
    if (!merged) return;
    const mesh = new THREE.Mesh(merged, this.mat);
    mesh.castShadow = this.cast;
    mesh.receiveShadow = true;
    this.out.push(mesh);
  }
}

export async function buildWorld(scene: THREE.Scene, onProgress: (p: number) => void): Promise<WorldData> {
  const rng = mulberry32(90210);
  const R = (a: number, b: number) => a + rng() * (b - a);
  const pick = <T,>(arr: T[]): T => arr[Math.floor(rng() * arr.length)];

  const out: THREE.Object3D[] = [];
  const mat = new THREE.MeshLambertMaterial({ vertexColors: true });
  const ground = new Batch(out, mat, false);
  const solid = new Batch(out, mat, true);
  const colliders: Box[] = [];
  const buildings: Building[] = [];
  const coinSpots: { x: number; z: number }[] = [];
  const hidden: HiddenSpot[] = [];

  const roadXs: number[] = [];
  for (let k = -5; k <= 4; k++) roadXs.push((k + 0.5) * P);
  const nearRoad = (v: number) => roadXs.some((r) => Math.abs(v - r) < ROAD / 2 + 2);

  const GRASS = 0x6cbf5b;
  const ROADC = 0x3d4149;
  const SIDEWALK = 0xd8d2c4;
  const PARK = 0x4fa84a;
  const LANE = 0xf4f4f4;

  const flat = (w: number, d: number, top: number, x: number, z: number, hex: number) =>
    ground.box(w, 0.2, d, x, top - 0.1, z, hex);
  const addCollider = (x: number, z: number, w: number, d: number) =>
    colliders.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2 });

  const tree = (x: number, z: number, collide: boolean) => {
    solid.cyl(0.35, 0.45, 3, 6, x, 1.5, z, 0x7a5230);
    solid.ico(2.4, x, 4.0, z, pick([0x3f9a3a, 0x4caf50, 0x2e7d32]));
    if (collide) addCollider(x, z, 0.9, 0.9);
  };

  const WALLS = [0xf6d7a7, 0xf2b8a2, 0xbfe3f2, 0xd9f0b5, 0xe8e1ff, 0xfff1b5, 0xf5f0e6];
  const APT = [0xc9c2b8, 0xb9a8a0, 0xd6c6b0, 0x9aa6b8];
  const OFFICE = [0x7fa6c9, 0x8fb8d6, 0x6e8aa8, 0xa9c4d9];
  const ROOFS = [0xb5483c, 0x7a4b3a, 0x5b6b7a, 0x8c3b2f];
  const AWN = [0xe53935, 0x1e88e5, 0xffb300, 0x43a047, 0x8e24aa];
  const GLASS = 0x9fe3ff;
  const SHOP_NAMES = ['Pixel Burger', 'Blocky Mart', 'Cube Clothes', 'Brick Bakery', 'Voxel Gadgets', 'Stud Barber', 'Lego Lemonade', 'Kart Garage'];
  let shopIdx = 0;

  const addBuilding = (b: Building) => {
    buildings.push(b);
    addCollider(b.x, b.z, b.w, b.d);
    const { x, z, w, d, h } = b;
    const front = z + d / 2 + 0.05;
    if (b.kind === 'house') {
      solid.box(w, h, d, x, h / 2, z, pick(WALLS));
      solid.cone(Math.max(w, d) * 0.72, 3.2, 4, x, h + 1.6, z, pick(ROOFS), Math.PI / 4);
      solid.box(1.8, 3, 0.3, x, 1.5, front, 0x6b4a2b);
      solid.box(2.2, 2, 0.3, x - w * 0.28, 3.4, front, GLASS);
      solid.box(2.2, 2, 0.3, x + w * 0.28, 3.4, front, GLASS);
    } else if (b.kind === 'shop') {
      solid.box(w, h, d, x, h / 2, z, pick(WALLS));
      solid.box(w + 0.6, 0.4, 2.4, x, 4.7, z + d / 2 + 1.0, pick(AWN));
      solid.box(w * 0.85, 2.2, 0.3, x, 2.2, front, GLASS);
      solid.box(w * 0.9, 1.8, 0.4, x, h + 0.9, z, pick(AWN));
    } else {
      const body = b.kind === 'office' ? pick(OFFICE) : pick(APT);
      solid.box(w, h, d, x, h / 2, z, body);
      const floors = Math.max(1, Math.round(h / 3.5));
      for (let f = 0; f < floors; f++) {
        const y = f * 3.5 + 2.2;
        for (let c = -1; c <= 1; c++) solid.box(w * 0.18, 1.6, 0.25, x + c * w * 0.3, y, front, GLASS);
      }
      solid.box(w + 0.4, 0.6, d + 0.4, x, h + 0.3, z, 0x4a4f5a);
    }
  };

  // ---- Ground: grass, roads, lane markings -----------------------------
  flat(1400, 1400, 0, 0, 0, GRASS);
  for (const r of roadXs) {
    flat(ROAD, 540, 0.05, r, 0, ROADC);
    flat(540, ROAD, 0.05, 0, r, ROADC);
  }
  for (const r of roadXs) {
    for (let t = -260; t <= 260; t += 8) {
      if (!nearRoad(t)) {
        flat(0.5, 4, 0.08, r, t, LANE);
        flat(4, 0.5, 0.08, t, r, LANE);
      }
    }
  }

  // ---- Blocks ------------------------------------------------------------
  const PARK_FORCED: [number, number][] = [
    [-3, -3],
    [2, -2],
    [-1, 3],
  ];
  const HIDDEN_NAMES = ['Secret Garden', 'Crystal Pond', 'Rooftop Grotto'];
  const total = (2 * GRID + 1) * (2 * GRID + 1);
  let done = 0;

  for (let i = -GRID; i <= GRID; i++) {
    for (let j = -GRID; j <= GRID; j++) {
      const cx = i * P;
      const cz = j * P;
      const downtown = Math.abs(i) <= 1 && Math.abs(j) <= 1;
      const forcedIdx = PARK_FORCED.findIndex(([a, b]) => a === i && b === j);

      if (forcedIdx >= 0 || (!downtown && rng() < 0.14)) {
        // Park with fountain and trees
        flat(BLOCK, BLOCK, 0.14, cx, cz, PARK);
        solid.cyl(4.2, 4.2, 0.6, 14, cx, 0.3, cz, 0xc9c5bd);
        solid.cyl(3.4, 3.4, 0.2, 14, cx, 0.7, cz, 0x8fdcff);
        addCollider(cx, cz, 8.4, 8.4);
        for (let t = 0; t < 7; t++) {
          const tx = cx + R(-18, 18);
          const tz = cz + R(-18, 18);
          if (Math.hypot(tx - cx, tz - cz) < 7) continue;
          tree(tx, tz, true);
        }
        coinSpots.push({ x: cx + R(-14, 14), z: cz + R(-14, 14) });
        coinSpots.push({ x: cx + R(-14, 14), z: cz + R(-14, 14) });
        if (forcedIdx >= 0) {
          const hx = cx + 9;
          const hz = cz + 9;
          const name = HIDDEN_NAMES[forcedIdx];
          solid.cyl(0.7, 0.7, 14, 8, hx, 7, hz, 0xffe066);
          solid.ico(1.2, hx, 14.6, hz, 0xffffaa);
          hidden.push({ x: hx, z: hz, name });
        }
      } else {
        // City block with four lots
        flat(BLOCK, BLOCK, 0.1, cx, cz, SIDEWALK);
        for (let lx = -1; lx <= 1; lx += 2) {
          for (let lz = -1; lz <= 1; lz += 2) {
            const lotX = cx + lx * 11;
            const lotZ = cz + lz * 11;
            if (rng() < 0.1) {
              tree(lotX, lotZ, false);
              continue;
            }
            let kind: Building['kind'];
            const r = rng();
            if (r < 0.35) kind = 'house';
            else if (r < 0.6) kind = 'apartment';
            else if (r < 0.8) kind = 'shop';
            else kind = downtown ? 'office' : 'apartment';
            if (downtown && kind === 'apartment' && rng() < 0.5) kind = 'office';

            const w = kind === 'house' ? R(9, 11) : kind === 'shop' ? R(11, 14) : R(12, 16);
            const d = kind === 'house' ? R(9, 11) : R(11, 15);
            const h =
              kind === 'house'
                ? R(5, 6.5)
                : kind === 'shop'
                  ? 6
                  : kind === 'apartment'
                    ? Math.floor(R(4, 7)) * 3.5
                    : Math.floor(R(8, 14)) * 3.5;
            const name =
              kind === 'shop'
                ? SHOP_NAMES[shopIdx++ % SHOP_NAMES.length]
                : kind === 'house'
                  ? 'Family Home'
                  : kind === 'office'
                    ? 'City Tower'
                    : 'Apartments';
            addBuilding({ kind, name, x: lotX + R(-1.2, 1.2), z: lotZ + R(-1.2, 1.2), w, d, h });
          }
        }
      }

      done++;
      if (done % 6 === 0) {
        onProgress(done / total);
        await new Promise<void>((resolve) => setTimeout(resolve, 0));
      }
    }
  }

  // ---- Coins along the streets ------------------------------------------
  for (const r of roadXs) {
    for (let n = 0; n < 6; n++) {
      coinSpots.push({ x: r + 3, z: R(-240, 240) });
      coinSpots.push({ x: R(-240, 240), z: r + 3 });
    }
  }

  // ---- Surrounding forest and mountain ring ------------------------------
  for (let n = 0; n < 70; n++) {
    const a = R(0, Math.PI * 2);
    const rad = R(263, 292);
    tree(Math.cos(a) * rad, Math.sin(a) * rad, false);
  }
  for (let n = 0; n < 40; n++) {
    const a = (n / 40) * Math.PI * 2 + R(-0.04, 0.04);
    const rad = R(330, 380);
    const x = Math.cos(a) * rad;
    const z = Math.sin(a) * rad;
    const base = R(45, 75);
    const h = R(90, 170);
    solid.cone(base, h, 6, x, h / 2, z, pick([0x5f7d55, 0x6e7f8a, 0x7a6a5a]));
    solid.cone(base * 0.38, h * 0.32, 6, x, h * 0.84, z, 0xf4f7fb);
  }

  ground.flush();
  solid.flush();
  for (const m of out) scene.add(m);
  onProgress(1);

  return { colliders, buildings, coinSpots, hidden, roadXs };
}
