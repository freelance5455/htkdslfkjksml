import {
  Enemy,
  GrappleNode,
  Hazard,
  PickupItem,
  Platform,
  SectorId,
  SectorMeta,
  SpeedRail,
  UplinkTerminal,
} from './types';

export const SECTORS: Record<SectorId, SectorMeta> = {
  sunken_conduit: {
    id: 'sunken_conduit',
    name: 'Sunken Conduit',
    subtitle: 'Sub-Metro Sector 01',
    bounds: { x: 0, y: 1000, w: 1800, h: 700 },
    color: '#22d3ee',
    mapRect: { x: 165, y: 228, w: 175, h: 97 },
  },
  maglev_spire: {
    id: 'maglev_spire',
    name: 'Maglev Spire',
    subtitle: 'Vertical Ascent Shaft',
    bounds: { x: -1100, y: 200, w: 1100, h: 1500 },
    color: '#a855f7',
    mapRect: { x: 40, y: 120, w: 120, h: 205 },
  },
  relay_skybridge: {
    id: 'relay_skybridge',
    name: 'Relay Skybridge',
    subtitle: 'High-Velocity Transit Span',
    bounds: { x: 1800, y: 900, w: 1900, h: 800 },
    color: '#38bdf8',
    mapRect: { x: 345, y: 225, w: 195, h: 100 },
  },
  cryo_foundry: {
    id: 'cryo_foundry',
    name: 'Cryo-Foundry',
    subtitle: 'Coolant Sump & Pogo Gauntlet',
    bounds: { x: 400, y: 1700, w: 2000, h: 700 },
    color: '#10b981',
    mapRect: { x: 200, y: 332, w: 205, h: 78 },
  },
  data_vault: {
    id: 'data_vault',
    name: 'Data Vault',
    subtitle: 'Restricted Parkour Core',
    bounds: { x: 2400, y: 200, w: 1300, h: 700 },
    color: '#f59e0b',
    mapRect: { x: 395, y: 120, w: 145, h: 100 },
  },
  black_spire: {
    id: 'black_spire',
    name: 'The Black Spire',
    subtitle: 'Sovereign Boss Sanctum',
    bounds: { x: 0, y: 150, w: 2400, h: 750 },
    color: '#f43f5e',
    mapRect: { x: 165, y: 120, w: 225, h: 100 },
  },
  void_foundry: {
    id: 'void_foundry',
    name: 'Void Foundry',
    subtitle: 'Phantom Stalker Sector 07',
    bounds: { x: 3700, y: 900, w: 1800, h: 800 },
    color: '#e879f9',
    mapRect: { x: 545, y: 225, w: 235, h: 100 },
  },
  cryo_abyss: {
    id: 'cryo_abyss',
    name: 'Cryo-Abyss',
    subtitle: 'Sub-Zero Trench Sector 08',
    bounds: { x: 400, y: 2400, w: 2000, h: 750 },
    color: '#34d399',
    mapRect: { x: 200, y: 416, w: 205, h: 74 },
  },
  zenith_apex: {
    id: 'zenith_apex',
    name: 'Zenith Apex',
    subtitle: 'Orbital Citadel Sector 09',
    bounds: { x: 2400, y: -550, w: 2000, h: 750 },
    color: '#fbbf24',
    mapRect: { x: 395, y: 20, w: 230, h: 92 },
  },
};

export interface WorldBlueprint {
  platforms: Platform[];
  hazards: Hazard[];
  rails: SpeedRail[];
  grappleNodes: GrappleNode[];
  terminals: UplinkTerminal[];
  pickups: PickupItem[];
  enemies: Enemy[];
}

export function createWorldBlueprint(): WorldBlueprint {
  const platforms: Platform[] = [
    // =========================================================================
    // 1. SUNKEN CONDUIT (x: 0..1800, y: 1000..1700)
    // =========================================================================
    // Ceiling (leaves exit shaft on far left? no, west wall exit is y:1380..1620)
    { x: 0, y: 1000, w: 1800, h: 40, kind: 'solid', sector: 'sunken_conduit', accent: 'cyan' },
    // Left wall above doorway
    { x: 0, y: 1040, w: 36, h: 320, kind: 'solid', sector: 'sunken_conduit', accent: 'cyan' },
    // Floor left & middle (opening at x: 1280..1460 drops into Cryo-Foundry!)
    { x: 0, y: 1620, w: 1280, h: 80, kind: 'solid', sector: 'sunken_conduit', accent: 'cyan' },
    { x: 1460, y: 1620, w: 340, h: 80, kind: 'solid', sector: 'sunken_conduit', accent: 'cyan' },
    // Right wall above east doorway (doorway y: 1380..1620)
    { x: 1764, y: 1040, w: 36, h: 340, kind: 'solid', sector: 'sunken_conduit', accent: 'cyan' },

    // Starter parkour blocks & slide-under overpass
    { x: 340, y: 1510, w: 150, h: 24, kind: 'oneway', sector: 'sunken_conduit', accent: 'cyan' },
    // Low tunnel ceiling for slide-under laser test (clearance 40px below at y:1580..1620? Wait: y:1510..1580 is 70px, laser at y:1566 leaves 54px -> wait player standing h=40! Let's make beam at y:1582 so standing hits, sliding h=22 passes!)
    { x: 540, y: 1450, w: 220, h: 125, kind: 'solid', sector: 'sunken_conduit', accent: 'magenta' },
    // Upper platforms above slide tunnel
    { x: 840, y: 1380, w: 160, h: 24, kind: 'oneway', sector: 'sunken_conduit', accent: 'cyan' },
    { x: 1080, y: 1240, w: 190, h: 26, kind: 'solid', sector: 'sunken_conduit', accent: 'amber' },
    // Secret Shard alcove top-left of Sunken Conduit (reached via rail jump or pogo)
    { x: 140, y: 1240, w: 240, h: 28, kind: 'solid', sector: 'sunken_conduit', accent: 'amber' },
    { x: 480, y: 1280, w: 160, h: 24, kind: 'oneway', sector: 'sunken_conduit', accent: 'cyan' },
    // Wall-kick pillar near Foundry drop
    { x: 1520, y: 1260, w: 40, h: 260, kind: 'neon_wall', sector: 'sunken_conduit', accent: 'cyan' },

    // =========================================================================
    // 2. MAGLEV SPIRE (x: -1100..0, y: 200..1700) - Vertical Wall-Jump Tower
    // =========================================================================
    // Outer left & ceiling & bottom
    { x: -1100, y: 200, w: 40, h: 1500, kind: 'solid', sector: 'maglev_spire', accent: 'magenta' },
    { x: -1060, y: 200, w: 1060, h: 40, kind: 'solid', sector: 'maglev_spire', accent: 'magenta' },
    { x: -1060, y: 1620, w: 1060, h: 80, kind: 'solid', sector: 'maglev_spire', accent: 'magenta' },
    // Right boundary walls leaving bottom doorway (y: 1360..1620) and summit doorway (y: 300..540)
    { x: -36, y: 540, w: 36, h: 820, kind: 'solid', sector: 'maglev_spire', accent: 'magenta' },
    { x: -36, y: 240, w: 36, h: 60, kind: 'solid', sector: 'maglev_spire', accent: 'magenta' },

    // Entry terrace & stepping platforms
    { x: -420, y: 1490, w: 260, h: 26, kind: 'oneway', sector: 'maglev_spire', accent: 'cyan' },
    { x: -860, y: 1420, w: 280, h: 28, kind: 'solid', sector: 'maglev_spire', accent: 'magenta' },

    // Lower Wall-Jump Chimney (x: -940..-740, width 200px)
    { x: -950, y: 980, w: 38, h: 360, kind: 'neon_wall', sector: 'maglev_spire', accent: 'cyan' },
    { x: -720, y: 1020, w: 38, h: 320, kind: 'neon_wall', sector: 'maglev_spire', accent: 'magenta' },

    // Mid-Spire Uplink Deck (y: 1040)
    { x: -682, y: 1040, w: 420, h: 32, kind: 'solid', sector: 'maglev_spire', accent: 'cyan' },
    { x: -240, y: 920, w: 170, h: 24, kind: 'oneway', sector: 'maglev_spire', accent: 'cyan' },

    // Upper Wall-Jump & Pogo Ascent
    { x: -460, y: 560, w: 36, h: 320, kind: 'neon_wall', sector: 'maglev_spire', accent: 'magenta' },
    { x: -240, y: 520, w: 36, h: 310, kind: 'neon_wall', sector: 'maglev_spire', accent: 'cyan' },
    { x: -690, y: 720, w: 190, h: 24, kind: 'oneway', sector: 'maglev_spire', accent: 'amber' },
    { x: -960, y: 580, w: 200, h: 28, kind: 'solid', sector: 'maglev_spire', accent: 'magenta' },

    // Spire Summit Platform (Phase Dash Pedestal!)
    { x: -920, y: 390, w: 380, h: 32, kind: 'solid', sector: 'maglev_spire', accent: 'cyan' },
    // Bridge to Black Spire (with phase-laser barrier right in front of exit!)
    { x: -420, y: 520, w: 420, h: 30, kind: 'solid', sector: 'maglev_spire', accent: 'magenta' },

    // =========================================================================
    // 3. RELAY SKYBRIDGE (x: 1800..3700, y: 900..1700)
    // =========================================================================
    // Top ceiling with vertical shaft opening (x: 2800..3050) to Data Vault
    { x: 1800, y: 900, w: 1000, h: 40, kind: 'solid', sector: 'relay_skybridge', accent: 'cyan' },
    { x: 3050, y: 900, w: 650, h: 40, kind: 'solid', sector: 'relay_skybridge', accent: 'cyan' },
    // Far east wall split to open doorway (y: 1160..1340) into Sector 07: Void Foundry
    { x: 3660, y: 940, w: 40, h: 220, kind: 'solid', sector: 'relay_skybridge', accent: 'cyan' },
    { x: 3660, y: 1340, w: 40, h: 360, kind: 'solid', sector: 'relay_skybridge', accent: 'cyan' },
    // Bottom floor sections with chasm gaps & Cryo-Foundry east exit (x: 2150..2350)
    { x: 1800, y: 1620, w: 350, h: 80, kind: 'solid', sector: 'relay_skybridge', accent: 'cyan' },
    { x: 2350, y: 1620, w: 380, h: 80, kind: 'solid', sector: 'relay_skybridge', accent: 'cyan' },
    // Bridge islands across main skybridge chasm
    { x: 2040, y: 1470, w: 160, h: 24, kind: 'oneway', sector: 'relay_skybridge', accent: 'cyan' },
    { x: 2440, y: 1380, w: 220, h: 28, kind: 'solid', sector: 'relay_skybridge', accent: 'cyan' },
    { x: 2780, y: 1450, w: 180, h: 26, kind: 'solid', sector: 'relay_skybridge', accent: 'amber' },
    { x: 3080, y: 1390, w: 170, h: 26, kind: 'solid', sector: 'relay_skybridge', accent: 'cyan' },
    // Far East Plaza (Grapple Tether Module)
    { x: 3310, y: 1340, w: 350, h: 40, kind: 'solid', sector: 'relay_skybridge', accent: 'amber' },
    // High return shelf toward Data Vault shaft
    { x: 2560, y: 1120, w: 190, h: 24, kind: 'oneway', sector: 'relay_skybridge', accent: 'cyan' },
    { x: 3080, y: 1120, w: 180, h: 24, kind: 'oneway', sector: 'relay_skybridge', accent: 'cyan' },
    // Abyssal catch floor beneath skybridge so falling damages or bounces instead of void clip
    { x: 2730, y: 1660, w: 930, h: 40, kind: 'solid', sector: 'relay_skybridge', accent: 'magenta' },

    // =========================================================================
    // 4. CRYO-FOUNDRY (x: 400..2400, y: 1700..2400)
    // =========================================================================
    // Ceiling leaving Conduit drop (1280..1460) and Relay east exit (2150..2350)
    { x: 400, y: 1700, w: 880, h: 40, kind: 'solid', sector: 'cryo_foundry', accent: 'emerald' },
    { x: 1460, y: 1700, w: 690, h: 40, kind: 'solid', sector: 'cryo_foundry', accent: 'emerald' },
    { x: 2350, y: 1700, w: 50, h: 40, kind: 'solid', sector: 'cryo_foundry', accent: 'emerald' },
    // Side walls & bottom floor split around drop shaft (x: 1260..1480) into Sector 08: Cryo-Abyss
    { x: 400, y: 1740, w: 40, h: 660, kind: 'solid', sector: 'cryo_foundry', accent: 'emerald' },
    { x: 2360, y: 1740, w: 40, h: 660, kind: 'solid', sector: 'cryo_foundry', accent: 'emerald' },
    { x: 440, y: 2360, w: 820, h: 40, kind: 'solid', sector: 'cryo_foundry', accent: 'emerald' },
    { x: 1480, y: 2360, w: 880, h: 40, kind: 'solid', sector: 'cryo_foundry', accent: 'emerald' },
    { x: 1180, y: 2150, w: 110, h: 22, kind: 'oneway', sector: 'cryo_foundry', accent: 'cyan' },

    // Landing deck under Conduit drop
    { x: 1220, y: 1980, w: 300, h: 30, kind: 'solid', sector: 'cryo_foundry', accent: 'emerald' },
    // Wall-jump column back up to Sunken Conduit
    { x: 1245, y: 1740, w: 34, h: 170, kind: 'neon_wall', sector: 'cryo_foundry', accent: 'cyan' },
    { x: 1460, y: 1740, w: 34, h: 170, kind: 'neon_wall', sector: 'cryo_foundry', accent: 'cyan' },

    // West Pogo-Mine Gauntlet leading to Aero-Thruster (Double Jump)
    { x: 440, y: 2120, w: 300, h: 36, kind: 'solid', sector: 'cryo_foundry', accent: 'cyan' },
    { x: 960, y: 2150, w: 140, h: 24, kind: 'oneway', sector: 'cryo_foundry', accent: 'emerald' },

    // East Coolant Span & Wall-Kick Chimney up to Relay Skybridge
    { x: 1620, y: 2120, w: 210, h: 26, kind: 'solid', sector: 'cryo_foundry', accent: 'emerald' },
    { x: 1940, y: 2040, w: 200, h: 26, kind: 'solid', sector: 'cryo_foundry', accent: 'emerald' },
    { x: 2120, y: 1740, w: 32, h: 220, kind: 'neon_wall', sector: 'cryo_foundry', accent: 'cyan' },
    { x: 2324, y: 1740, w: 36, h: 360, kind: 'neon_wall', sector: 'cryo_foundry', accent: 'emerald' },
    // Secret Integrity Cell ledge top-right of Foundry
    { x: 1660, y: 1860, w: 240, h: 24, kind: 'oneway', sector: 'cryo_foundry', accent: 'amber' },

    // =========================================================================
    // 5. DATA VAULT (x: 2400..3700, y: 200..900)
    // =========================================================================
    // Outer shell leaving bottom shaft (2800..3050), ceiling shaft (2740..2940) to Zenith Apex, and West Black Spire door (y: 340..560)
    { x: 2400, y: 200, w: 340, h: 40, kind: 'solid', sector: 'data_vault', accent: 'amber' },
    { x: 2940, y: 200, w: 760, h: 40, kind: 'solid', sector: 'data_vault', accent: 'amber' },
    { x: 3660, y: 240, w: 40, h: 660, kind: 'solid', sector: 'data_vault', accent: 'amber' },
    { x: 2400, y: 860, w: 400, h: 40, kind: 'solid', sector: 'data_vault', accent: 'amber' },
    { x: 3050, y: 860, w: 610, h: 40, kind: 'solid', sector: 'data_vault', accent: 'amber' },
    { x: 2400, y: 240, w: 36, h: 100, kind: 'solid', sector: 'data_vault', accent: 'amber' },
    { x: 2400, y: 560, w: 36, h: 300, kind: 'solid', sector: 'data_vault', accent: 'amber' },

    // Vault Parkour Platforms
    { x: 2740, y: 740, w: 220, h: 24, kind: 'oneway', sector: 'data_vault', accent: 'amber' },
    { x: 2400, y: 560, w: 320, h: 28, kind: 'solid', sector: 'data_vault', accent: 'amber' },
    { x: 3060, y: 660, w: 200, h: 24, kind: 'oneway', sector: 'data_vault', accent: 'cyan' },
    // Vault Reward Pedestal (Overdrive Arc + Integrity Cell)
    { x: 3340, y: 440, w: 320, h: 34, kind: 'solid', sector: 'data_vault', accent: 'amber' },
    { x: 2940, y: 380, w: 160, h: 22, kind: 'oneway', sector: 'data_vault', accent: 'amber' },
    { x: 2730, y: 290, w: 110, h: 22, kind: 'oneway', sector: 'data_vault', accent: 'cyan' },

    // =========================================================================
    // 6. THE BLACK SPIRE (x: 0..2400, y: 150..900) - Boss Sanctum
    // =========================================================================
    { x: 0, y: 150, w: 2400, h: 40, kind: 'solid', sector: 'black_spire', accent: 'magenta' },
    // West approach doorway (y: 300..540) from Maglev Spire
    { x: 0, y: 190, w: 36, h: 110, kind: 'solid', sector: 'black_spire', accent: 'magenta' },
    { x: 0, y: 540, w: 36, h: 360, kind: 'solid', sector: 'black_spire', accent: 'magenta' },
    // East doorway (y: 340..560) from Data Vault
    { x: 2364, y: 190, w: 36, h: 150, kind: 'solid', sector: 'black_spire', accent: 'magenta' },
    { x: 2364, y: 560, w: 36, h: 340, kind: 'solid', sector: 'black_spire', accent: 'magenta' },
    // Main floor & approach deck
    { x: 0, y: 520, w: 496, h: 32, kind: 'solid', sector: 'black_spire', accent: 'magenta' },
    { x: 520, y: 680, w: 440, h: 32, kind: 'solid', sector: 'black_spire', accent: 'cyan' },
    // Boss Arena Floor (x: 960..2364, y: 780)
    { x: 960, y: 780, w: 1404, h: 120, kind: 'solid', sector: 'black_spire', accent: 'magenta' },
    // Arena side shelves for evasion / pogo setups
    { x: 1100, y: 590, w: 180, h: 22, kind: 'oneway', sector: 'black_spire', accent: 'cyan' },
    { x: 2040, y: 590, w: 180, h: 22, kind: 'oneway', sector: 'black_spire', accent: 'cyan' },
    { x: 2140, y: 560, w: 260, h: 26, kind: 'oneway', sector: 'black_spire', accent: 'amber' },

    // =========================================================================
    // 7. VOID FOUNDRY (x: 3700..5500, y: 900..1700) - Boss: VORTEX-VII (HP 48)
    // =========================================================================
    { x: 3700, y: 900, w: 1800, h: 40, kind: 'solid', sector: 'void_foundry', accent: 'magenta' },
    { x: 5460, y: 940, w: 40, h: 760, kind: 'solid', sector: 'void_foundry', accent: 'magenta' },
    { x: 3700, y: 1340, w: 320, h: 40, kind: 'solid', sector: 'void_foundry', accent: 'cyan' },
    { x: 3700, y: 1660, w: 820, h: 40, kind: 'solid', sector: 'void_foundry', accent: 'magenta' },
    { x: 4080, y: 1410, w: 180, h: 24, kind: 'oneway', sector: 'void_foundry', accent: 'cyan' },
    { x: 4300, y: 1520, w: 220, h: 32, kind: 'solid', sector: 'void_foundry', accent: 'amber' },
    { x: 4020, y: 1120, w: 34, h: 240, kind: 'neon_wall', sector: 'void_foundry', accent: 'magenta' },
    { x: 3850, y: 1180, w: 130, h: 22, kind: 'oneway', sector: 'void_foundry', accent: 'amber' },
    // Boss Arena Floor (x: 4520..5460, y: 1580)
    { x: 4520, y: 1580, w: 940, h: 120, kind: 'solid', sector: 'void_foundry', accent: 'magenta' },
    { x: 4620, y: 1390, w: 170, h: 22, kind: 'oneway', sector: 'void_foundry', accent: 'cyan' },
    { x: 5190, y: 1390, w: 170, h: 22, kind: 'oneway', sector: 'void_foundry', accent: 'cyan' },

    // =========================================================================
    // 8. CRYO-ABYSS (x: 400..2400, y: 2400..3150) - Boss: GLACIER-OMEGA (HP 60)
    // =========================================================================
    { x: 400, y: 2400, w: 40, h: 750, kind: 'solid', sector: 'cryo_abyss', accent: 'emerald' },
    { x: 2360, y: 2400, w: 40, h: 750, kind: 'solid', sector: 'cryo_abyss', accent: 'emerald' },
    { x: 400, y: 3110, w: 2000, h: 40, kind: 'solid', sector: 'cryo_abyss', accent: 'emerald' },
    // Climbable drop shaft walls back to Cryo-Foundry
    { x: 1230, y: 2400, w: 32, h: 240, kind: 'neon_wall', sector: 'cryo_abyss', accent: 'cyan' },
    { x: 1480, y: 2400, w: 32, h: 240, kind: 'neon_wall', sector: 'cryo_abyss', accent: 'emerald' },
    // Upper Landing & Uplink Deck
    { x: 1040, y: 2700, w: 480, h: 32, kind: 'solid', sector: 'cryo_abyss', accent: 'emerald' },
    // West Warden Gauntlet
    { x: 440, y: 2840, w: 540, h: 34, kind: 'solid', sector: 'cryo_abyss', accent: 'cyan' },
    { x: 500, y: 2610, w: 260, h: 24, kind: 'oneway', sector: 'cryo_abyss', accent: 'amber' },
    { x: 960, y: 2880, w: 110, h: 22, kind: 'oneway', sector: 'cryo_abyss', accent: 'cyan' },
    // Lower Tunnel & Boss Arena Floor (x: 440..2360, y: 3020)
    { x: 440, y: 3020, w: 1920, h: 90, kind: 'solid', sector: 'cryo_abyss', accent: 'emerald' },
    { x: 1240, y: 2840, w: 180, h: 22, kind: 'oneway', sector: 'cryo_abyss', accent: 'cyan' },
    { x: 2040, y: 2840, w: 180, h: 22, kind: 'oneway', sector: 'cryo_abyss', accent: 'cyan' },

    // =========================================================================
    // 9. ZENITH APEX (x: 2400..4400, y: -550..200) - Boss: NEXUS-PRIME (HP 76)
    // =========================================================================
    { x: 2400, y: -550, w: 2000, h: 40, kind: 'solid', sector: 'zenith_apex', accent: 'amber' },
    { x: 2400, y: -510, w: 40, h: 710, kind: 'solid', sector: 'zenith_apex', accent: 'amber' },
    { x: 4360, y: -510, w: 40, h: 710, kind: 'solid', sector: 'zenith_apex', accent: 'amber' },
    // Entry Floor split around shaft (x: 2740..2940)
    { x: 2440, y: 160, w: 300, h: 40, kind: 'solid', sector: 'zenith_apex', accent: 'amber' },
    { x: 2940, y: 160, w: 1420, h: 40, kind: 'solid', sector: 'zenith_apex', accent: 'amber' },
    // Climb walls at entry shaft
    { x: 2708, y: -20, w: 32, h: 180, kind: 'neon_wall', sector: 'zenith_apex', accent: 'cyan' },
    { x: 2940, y: -20, w: 32, h: 180, kind: 'neon_wall', sector: 'zenith_apex', accent: 'amber' },
    // West Uplink & High Citadel Approach
    { x: 2440, y: -60, w: 280, h: 32, kind: 'solid', sector: 'zenith_apex', accent: 'amber' },
    { x: 2880, y: 20, w: 200, h: 24, kind: 'oneway', sector: 'zenith_apex', accent: 'cyan' },
    // Boss Arena Floor (x: 3100..4360, y: 80)
    { x: 3100, y: 80, w: 1260, h: 100, kind: 'solid', sector: 'zenith_apex', accent: 'amber' },
    { x: 3220, y: -110, w: 180, h: 22, kind: 'oneway', sector: 'zenith_apex', accent: 'cyan' },
    { x: 4040, y: -110, w: 180, h: 22, kind: 'oneway', sector: 'zenith_apex', accent: 'cyan' },
  ];

  const hazards: Hazard[] = [
    // Sunken Conduit slide-under laser (player stands 1575..1620, slides 1598..1620 -> beam at 1578..1594!)
    { x: 630, y: 1575, w: 18, h: 19, kind: 'laser', phaseable: true },
    // Sunken Conduit spike pit with pogo-able drone above
    { x: 930, y: 1602, w: 140, h: 18, kind: 'spikes', pogoable: true },

    // Maglev Spire phase-laser gate blocking Black Spire shortcut until Phase Dash is unlocked!
    { x: -120, y: 240, w: 22, h: 280, kind: 'laser', phaseable: true },
    // Maglev Spire laser sweepers with slide gaps
    { x: -640, y: 1380, w: 18, h: 18, kind: 'laser', phaseable: true },

    // Relay Skybridge phase-laser & spike hazards
    { x: 2540, y: 1210, w: 20, h: 170, kind: 'laser', phaseable: true },
    { x: 2730, y: 1638, w: 930, h: 22, kind: 'spikes', pogoable: true },

    // Cryo-Foundry coolant acid floor (split around x:1240..1500 drop shaft to Cryo-Abyss)
    { x: 440, y: 2334, w: 800, h: 26, kind: 'acid' },
    { x: 1500, y: 2334, w: 860, h: 26, kind: 'acid' },

    // Data Vault laser walls (Phase Dash through mid-air!)
    { x: 3240, y: 240, w: 20, h: 200, kind: 'laser', phaseable: true },

    // Void Foundry chasm spikes
    { x: 3720, y: 1638, w: 780, h: 22, kind: 'spikes', pogoable: true },
    { x: 4220, y: 940, w: 20, h: 180, kind: 'laser', phaseable: true },

    // Zenith Apex laser gate guarding Integrity alcove
    { x: 2620, y: -260, w: 20, h: 200, kind: 'laser', phaseable: true },
  ];

  const rails: SpeedRail[] = [
    // Sunken Conduit launch rail
    { id: 'rail_conduit_1', x1: 780, y1: 1560, x2: 1140, y2: 1460, color: 'cyan' },
    // Relay Skybridge high-velocity rail
    { id: 'rail_relay_1', x1: 1860, y1: 1560, x2: 2320, y2: 1450, color: 'cyan' },
    { id: 'rail_relay_2', x1: 2790, y1: 1390, x2: 3250, y2: 1310, color: 'amber' },
    // Data Vault rail into laser phase-dash jump
    { id: 'rail_vault_1', x1: 2620, y1: 510, x2: 2980, y2: 430, color: 'amber' },
    // Void Foundry entrance rail
    { id: 'rail_void_1', x1: 3740, y1: 1290, x2: 4010, y2: 1220, color: 'amber' },
    // Cryo-Abyss west rail
    { id: 'rail_abyss_1', x1: 480, y1: 2970, x2: 880, y2: 2900, color: 'cyan' },
    // Zenith Apex approach rail
    { id: 'rail_zenith_1', x1: 2480, y1: 110, x2: 2980, y2: 60, color: 'amber' },
  ];

  const grappleNodes: GrappleNode[] = [
    // Sunken Conduit grapple shortcut above shaft
    { id: 'gn_conduit_1', x: 1370, y: 1140, radius: 14 },
    // Maglev Spire mid-climb boost
    { id: 'gn_spire_1', x: -580, y: 820, radius: 14 },
    // Relay Skybridge chasm chain
    { id: 'gn_relay_1', x: 2340, y: 1220, radius: 14 },
    { id: 'gn_relay_2', x: 2920, y: 1180, radius: 14 },
    { id: 'gn_relay_3', x: 2925, y: 940, radius: 14 },
    // Data Vault aerial chain + Zenith shaft grapple
    { id: 'gn_vault_1', x: 3140, y: 310, radius: 14 },
    { id: 'gn_vault_zenith', x: 2840, y: 240, radius: 14 },
    // Black Spire Boss Arena evasion anchors
    { id: 'gn_boss_1', x: 1360, y: 420, radius: 15 },
    { id: 'gn_boss_2', x: 1940, y: 420, radius: 15 },
    // Void Foundry nodes
    { id: 'gn_void_1', x: 4240, y: 1240, radius: 14 },
    { id: 'gn_void_boss', x: 4990, y: 1230, radius: 15 },
    // Cryo-Abyss shaft & boss node
    { id: 'gn_abyss_shaft', x: 1365, y: 2330, radius: 14 },
    { id: 'gn_abyss_boss', x: 1750, y: 2700, radius: 15 },
    // Zenith Apex boss nodes
    { id: 'gn_zenith_boss_1', x: 3500, y: -250, radius: 15 },
    { id: 'gn_zenith_boss_2', x: 3940, y: -250, radius: 15 },
  ];

  const terminals: UplinkTerminal[] = [
    {
      id: 'uplink_conduit',
      sector: 'sunken_conduit',
      name: 'Conduit Metro Uplink',
      x: 210,
      y: 1620,
    },
    {
      id: 'uplink_spire',
      sector: 'maglev_spire',
      name: 'Spire Mid-Deck Uplink',
      x: -480,
      y: 1040,
    },
    {
      id: 'uplink_sanctum',
      sector: 'black_spire',
      name: 'Black Spire Threshold',
      x: 840,
      y: 680,
    },
    {
      id: 'uplink_vault_gate',
      sector: 'data_vault',
      name: 'Vault Approach Uplink',
      x: 2520,
      y: 560,
    },
    {
      id: 'uplink_void_foundry',
      sector: 'void_foundry',
      name: 'Void Foundry Threshold',
      x: 4410,
      y: 1520,
    },
    {
      id: 'uplink_cryo_abyss',
      sector: 'cryo_abyss',
      name: 'Cryo-Abyss Deep Uplink',
      x: 1290,
      y: 2700,
    },
    {
      id: 'uplink_zenith_apex',
      sector: 'zenith_apex',
      name: 'Zenith Citadel Uplink',
      x: 2560,
      y: -60,
    },
  ];

  const pickups: PickupItem[] = [
    // Major Ability Modules
    {
      id: 'mod_phase_dash',
      kind: 'ability',
      abilityId: 'phase_dash',
      label: 'PHASE DASH MODULE',
      description: 'Press [Shift / K] for an invulnerable blink through lasers & foes. Resets on ground, wall, grapple, or pogo.',
      x: -740,
      y: 350,
      collected: false,
    },
    {
      id: 'mod_grapple_tether',
      kind: 'ability',
      abilityId: 'grapple_tether',
      label: 'GRAPPLE TETHER',
      description: 'Press [C / L / Right-Click] near glowing nodes to slingshot across chasms with preserved momentum.',
      x: 3500,
      y: 1300,
      collected: false,
    },
    {
      id: 'mod_aero_thruster',
      kind: 'ability',
      abilityId: 'aero_thruster',
      label: 'AERO-THRUSTER [DOUBLE JUMP]',
      description: 'Press [Space] again mid-air for a directional booster burst.',
      x: 560,
      y: 2080,
      collected: false,
    },
    {
      id: 'mod_overdrive_arc',
      kind: 'ability',
      abilityId: 'overdrive_arc',
      label: 'OVERDRIVE ARC',
      description: 'Every katana slash emits a piercing cyber-wave and deals +25% blade damage.',
      x: 3500,
      y: 400,
      collected: false,
    },

    // Integrity Cells (+1 Max HP)
    {
      id: 'cell_foundry',
      kind: 'integrity_cell',
      label: 'INTEGRITY CELL',
      description: '+1 Maximum Armor Integrity Pip.',
      x: 1780,
      y: 1825,
      collected: false,
    },
    {
      id: 'cell_vault',
      kind: 'integrity_cell',
      label: 'INTEGRITY CELL',
      description: '+1 Maximum Armor Integrity Pip.',
      x: 3570,
      y: 400,
      collected: false,
    },

    // In-Arena Boss Fight Rest / Repair Relays
    {
      id: 'relay_boss_west',
      kind: 'repair_relay',
      label: 'REPAIR RELAY',
      description: '+2 Integrity & +33 Flux restored',
      x: 1190,
      y: 556,
      collected: false,
    },
    {
      id: 'relay_boss_east',
      kind: 'repair_relay',
      label: 'REPAIR RELAY',
      description: '+2 Integrity & +33 Flux restored',
      x: 2130,
      y: 556,
      collected: false,
    },

    // Integrity Cell & Arena Repair Relays for Void Foundry, Cryo-Abyss, Zenith Apex
    {
      id: 'cell_abyss',
      kind: 'integrity_cell',
      label: 'INTEGRITY CELL',
      description: '+1 Maximum Armor Integrity Pip.',
      x: 560,
      y: 2575,
      collected: false,
    },
    {
      id: 'cell_zenith',
      kind: 'integrity_cell',
      label: 'INTEGRITY CELL',
      description: '+1 Maximum Armor Integrity Pip.',
      x: 2500,
      y: -95,
      collected: false,
    },
    {
      id: 'relay_vortex_west',
      kind: 'repair_relay',
      label: 'REPAIR RELAY',
      description: '+2 Integrity & +33 Flux restored',
      x: 4705,
      y: 1356,
      collected: false,
    },
    {
      id: 'relay_vortex_east',
      kind: 'repair_relay',
      label: 'REPAIR RELAY',
      description: '+2 Integrity & +33 Flux restored',
      x: 5275,
      y: 1356,
      collected: false,
    },
    {
      id: 'relay_glacier_west',
      kind: 'repair_relay',
      label: 'REPAIR RELAY',
      description: '+2 Integrity & +33 Flux restored',
      x: 1330,
      y: 2806,
      collected: false,
    },
    {
      id: 'relay_glacier_east',
      kind: 'repair_relay',
      label: 'REPAIR RELAY',
      description: '+2 Integrity & +33 Flux restored',
      x: 2130,
      y: 2806,
      collected: false,
    },
    {
      id: 'relay_nexus_west',
      kind: 'repair_relay',
      label: 'REPAIR RELAY',
      description: '+2 Integrity & +33 Flux restored',
      x: 3310,
      y: -144,
      collected: false,
    },
    {
      id: 'relay_nexus_east',
      kind: 'repair_relay',
      label: 'REPAIR RELAY',
      description: '+2 Integrity & +33 Flux restored',
      x: 4130,
      y: -144,
      collected: false,
    },

    // 18 Collectible Data Shards (12 original + 6 across the 3 new sectors)
    { id: 'shard_1', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 220, y: 1205, collected: false },
    { id: 'shard_2', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 1170, y: 1205, collected: false },
    { id: 'shard_3', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: -800, y: 1385, collected: false },
    { id: 'shard_4', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: -880, y: 545, collected: false },
    { id: 'shard_5', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: -160, y: 885, collected: false },
    { id: 'shard_6', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 2120, y: 1435, collected: false },
    { id: 'shard_7', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 3160, y: 1085, collected: false },
    { id: 'shard_8', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 1030, y: 2115, collected: false },
    { id: 'shard_9', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 2040, y: 2005, collected: false },
    { id: 'shard_10', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 2590, y: 525, collected: false },
    { id: 'shard_11', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 3020, y: 345, collected: false },
    { id: 'shard_12', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 160, y: 485, collected: false },
    { id: 'shard_13', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 3915, y: 1145, collected: false },
    { id: 'shard_14', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 4160, y: 1375, collected: false },
    { id: 'shard_15', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 700, y: 2575, collected: false },
    { id: 'shard_16', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 640, y: 2985, collected: false },
    { id: 'shard_17', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 2980, y: -15, collected: false },
    { id: 'shard_18', kind: 'shard', label: 'DATA SHARD', description: '+25 Shards', x: 2660, y: 125, collected: false },
  ];

  const enemies: Enemy[] = [
    // Sunken Conduit
    {
      id: 'bot_c1',
      kind: 'patrol_bot',
      sector: 'sunken_conduit',
      x: 420,
      y: 1584,
      w: 30,
      h: 36,
      vx: 75,
      vy: 0,
      hp: 3,
      maxHp: 3,
      spawnX: 420,
      spawnY: 1584,
      patrolMinX: 330,
      patrolMaxX: 520,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0,
      aiPhase: 'patrol',
      telegraphTimer: 0,
    },
    {
      id: 'drone_c1',
      kind: 'hover_sentinel',
      sector: 'sunken_conduit',
      x: 980,
      y: 1490,
      w: 32,
      h: 28,
      vx: 65,
      vy: 0,
      hp: 2,
      maxHp: 2,
      spawnX: 980,
      spawnY: 1490,
      patrolMinX: 880,
      patrolMaxX: 1120,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0,
      aiPhase: 'hover',
      telegraphTimer: 0,
    },

    // Maglev Spire
    {
      id: 'bot_m1',
      kind: 'patrol_bot',
      sector: 'maglev_spire',
      x: -740,
      y: 1384,
      w: 30,
      h: 36,
      vx: 85,
      vy: 0,
      hp: 3,
      maxHp: 3,
      spawnX: -740,
      spawnY: 1384,
      patrolMinX: -850,
      patrolMaxX: -610,
      facing: -1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0,
      aiPhase: 'patrol',
      telegraphTimer: 0,
    },
    {
      id: 'drone_m1',
      kind: 'hover_sentinel',
      sector: 'maglev_spire',
      x: -360,
      y: 1210,
      w: 32,
      h: 28,
      vx: 70,
      vy: 0,
      hp: 2,
      maxHp: 2,
      spawnX: -360,
      spawnY: 1210,
      patrolMinX: -520,
      patrolMaxX: -200,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0,
      aiPhase: 'hover',
      telegraphTimer: 0,
    },
    {
      id: 'mine_m1',
      kind: 'pogo_mine',
      sector: 'maglev_spire',
      x: -590,
      y: 660,
      w: 30,
      h: 30,
      vx: 0,
      vy: 0,
      hp: 99,
      maxHp: 99,
      spawnX: -590,
      spawnY: 660,
      patrolMinX: -590,
      patrolMaxX: -590,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0,
      aiPhase: 'mine',
      telegraphTimer: 0,
    },

    // Relay Skybridge
    {
      id: 'turret_r1',
      kind: 'sniper_turret',
      sector: 'relay_skybridge',
      x: 2560,
      y: 1344,
      w: 34,
      h: 36,
      vx: 0,
      vy: 0,
      hp: 4,
      maxHp: 4,
      spawnX: 2560,
      spawnY: 1344,
      patrolMinX: 2560,
      patrolMaxX: 2560,
      facing: -1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 1.5,
      aiPhase: 'aim',
      telegraphTimer: 0,
    },
    {
      id: 'mine_r1',
      kind: 'pogo_mine',
      sector: 'relay_skybridge',
      x: 2290,
      y: 1380,
      w: 30,
      h: 30,
      vx: 0,
      vy: 0,
      hp: 99,
      maxHp: 99,
      spawnX: 2290,
      spawnY: 1380,
      patrolMinX: 2290,
      patrolMaxX: 2290,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0,
      aiPhase: 'mine',
      telegraphTimer: 0,
    },
    {
      id: 'drone_r1',
      kind: 'hover_sentinel',
      sector: 'relay_skybridge',
      x: 3170,
      y: 1270,
      w: 32,
      h: 28,
      vx: 80,
      vy: 0,
      hp: 3,
      maxHp: 3,
      spawnX: 3170,
      spawnY: 1270,
      patrolMinX: 3020,
      patrolMaxX: 3320,
      facing: -1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0,
      aiPhase: 'hover',
      telegraphTimer: 0,
    },

    // Cryo-Foundry Pogo-Mine Gauntlet!
    {
      id: 'mine_f1',
      kind: 'pogo_mine',
      sector: 'cryo_foundry',
      x: 1140,
      y: 2080,
      w: 32,
      h: 32,
      vx: 0,
      vy: 0,
      hp: 99,
      maxHp: 99,
      spawnX: 1140,
      spawnY: 2080,
      patrolMinX: 1140,
      patrolMaxX: 1140,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0,
      aiPhase: 'mine',
      telegraphTimer: 0,
    },
    {
      id: 'mine_f2',
      kind: 'pogo_mine',
      sector: 'cryo_foundry',
      x: 840,
      y: 2110,
      w: 32,
      h: 32,
      vx: 0,
      vy: 0,
      hp: 99,
      maxHp: 99,
      spawnX: 840,
      spawnY: 2110,
      patrolMinX: 840,
      patrolMaxX: 840,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0,
      aiPhase: 'mine',
      telegraphTimer: 0,
    },
    {
      id: 'bot_f1',
      kind: 'patrol_bot',
      sector: 'cryo_foundry',
      x: 1710,
      y: 2084,
      w: 30,
      h: 36,
      vx: 70,
      vy: 0,
      hp: 3,
      maxHp: 3,
      spawnX: 1710,
      spawnY: 2084,
      patrolMinX: 1630,
      patrolMaxX: 1800,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0,
      aiPhase: 'patrol',
      telegraphTimer: 0,
    },

    // Data Vault
    {
      id: 'turret_v1',
      kind: 'sniper_turret',
      sector: 'data_vault',
      x: 3150,
      y: 624,
      w: 34,
      h: 36,
      vx: 0,
      vy: 0,
      hp: 4,
      maxHp: 4,
      spawnX: 3150,
      spawnY: 624,
      patrolMinX: 3150,
      patrolMaxX: 3150,
      facing: -1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 1.4,
      aiPhase: 'aim',
      telegraphTimer: 0,
    },

    // Black Spire Boss: ARCHON-IX // SOVEREIGN SENTINEL
    {
      id: 'boss_archon',
      kind: 'boss_archon',
      sector: 'black_spire',
      x: 1860,
      y: 684,
      w: 56,
      h: 96,
      vx: 0,
      vy: 0,
      hp: 34,
      maxHp: 34,
      spawnX: 1860,
      spawnY: 684,
      patrolMinX: 1020,
      patrolMaxX: 2260,
      facing: -1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 1.4,
      aiPhase: 'idle',
      telegraphTimer: 0,
      phase2: false,
    },

    // =========================================================================
    // SECTOR 07: VOID FOUNDRY ENEMIES & BOSS (VORTEX-VII, HP 48)
    // =========================================================================
    {
      id: 'stalker_vf1',
      kind: 'dash_stalker',
      sector: 'void_foundry',
      x: 3880,
      y: 1300,
      w: 32,
      h: 40,
      vx: 110,
      vy: 0,
      hp: 4,
      maxHp: 4,
      spawnX: 3880,
      spawnY: 1300,
      patrolMinX: 3730,
      patrolMaxX: 4000,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0.8,
      aiPhase: 'patrol',
      telegraphTimer: 0,
    },
    {
      id: 'orbiter_vf1',
      kind: 'plasma_orbiter',
      sector: 'void_foundry',
      x: 4180,
      y: 1270,
      w: 36,
      h: 32,
      vx: 75,
      vy: 0,
      hp: 4,
      maxHp: 4,
      spawnX: 4180,
      spawnY: 1270,
      patrolMinX: 4070,
      patrolMaxX: 4330,
      facing: -1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 1.6,
      aiPhase: 'hover',
      telegraphTimer: 0,
    },
    {
      id: 'mine_vf1',
      kind: 'pogo_mine',
      sector: 'void_foundry',
      x: 3960,
      y: 1500,
      w: 32,
      h: 32,
      vx: 0,
      vy: 0,
      hp: 99,
      maxHp: 99,
      spawnX: 3960,
      spawnY: 1500,
      patrolMinX: 3960,
      patrolMaxX: 3960,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0,
      aiPhase: 'mine',
      telegraphTimer: 0,
    },
    {
      id: 'boss_vortex',
      kind: 'boss_vortex',
      sector: 'void_foundry',
      x: 5180,
      y: 1484,
      w: 58,
      h: 96,
      vx: 0,
      vy: 0,
      hp: 48,
      maxHp: 48,
      spawnX: 5180,
      spawnY: 1484,
      patrolMinX: 4550,
      patrolMaxX: 5430,
      facing: -1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 1.3,
      aiPhase: 'idle',
      telegraphTimer: 0,
      phase2: false,
    },

    // =========================================================================
    // SECTOR 08: CRYO-ABYSS ENEMIES & BOSS (GLACIER-OMEGA, HP 60)
    // =========================================================================
    {
      id: 'warden_ca1',
      kind: 'shield_warden',
      sector: 'cryo_abyss',
      x: 680,
      y: 2794,
      w: 38,
      h: 46,
      vx: 65,
      vy: 0,
      hp: 6,
      maxHp: 6,
      spawnX: 680,
      spawnY: 2794,
      patrolMinX: 470,
      patrolMaxX: 950,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 1.1,
      aiPhase: 'patrol',
      telegraphTimer: 0,
    },
    {
      id: 'orbiter_ca1',
      kind: 'plasma_orbiter',
      sector: 'cryo_abyss',
      x: 820,
      y: 2560,
      w: 36,
      h: 32,
      vx: 85,
      vy: 0,
      hp: 4,
      maxHp: 4,
      spawnX: 820,
      spawnY: 2560,
      patrolMinX: 540,
      patrolMaxX: 960,
      facing: -1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 1.5,
      aiPhase: 'hover',
      telegraphTimer: 0,
    },
    {
      id: 'stalker_ca1',
      kind: 'dash_stalker',
      sector: 'cryo_abyss',
      x: 780,
      y: 2980,
      w: 32,
      h: 40,
      vx: 115,
      vy: 0,
      hp: 4,
      maxHp: 4,
      spawnX: 780,
      spawnY: 2980,
      patrolMinX: 480,
      patrolMaxX: 1020,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0.9,
      aiPhase: 'patrol',
      telegraphTimer: 0,
    },
    {
      id: 'boss_glacier',
      kind: 'boss_glacier',
      sector: 'cryo_abyss',
      x: 2020,
      y: 2918,
      w: 66,
      h: 102,
      vx: 0,
      vy: 0,
      hp: 60,
      maxHp: 60,
      spawnX: 2020,
      spawnY: 2918,
      patrolMinX: 1170,
      patrolMaxX: 2330,
      facing: -1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 1.3,
      aiPhase: 'idle',
      telegraphTimer: 0,
      phase2: false,
    },

    // =========================================================================
    // SECTOR 09: ZENITH APEX ENEMIES & BOSS (NEXUS-PRIME, HP 76)
    // =========================================================================
    {
      id: 'warden_za1',
      kind: 'shield_warden',
      sector: 'zenith_apex',
      x: 2560,
      y: -106,
      w: 38,
      h: 46,
      vx: 70,
      vy: 0,
      hp: 6,
      maxHp: 6,
      spawnX: 2560,
      spawnY: -106,
      patrolMinX: 2450,
      patrolMaxX: 2700,
      facing: 1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 1.0,
      aiPhase: 'patrol',
      telegraphTimer: 0,
    },
    {
      id: 'stalker_za1',
      kind: 'dash_stalker',
      sector: 'zenith_apex',
      x: 2980,
      y: 120,
      w: 32,
      h: 40,
      vx: 125,
      vy: 0,
      hp: 5,
      maxHp: 5,
      spawnX: 2980,
      spawnY: 120,
      patrolMinX: 2950,
      patrolMaxX: 3090,
      facing: -1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 0.8,
      aiPhase: 'patrol',
      telegraphTimer: 0,
    },
    {
      id: 'orbiter_za1',
      kind: 'plasma_orbiter',
      sector: 'zenith_apex',
      x: 2950,
      y: -80,
      w: 36,
      h: 32,
      vx: 90,
      vy: 0,
      hp: 5,
      maxHp: 5,
      spawnX: 2950,
      spawnY: -80,
      patrolMinX: 2760,
      patrolMaxX: 3070,
      facing: -1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 1.4,
      aiPhase: 'hover',
      telegraphTimer: 0,
    },
    {
      id: 'boss_nexus',
      kind: 'boss_nexus',
      sector: 'zenith_apex',
      x: 4040,
      y: -20,
      w: 64,
      h: 100,
      vx: 0,
      vy: 0,
      hp: 76,
      maxHp: 76,
      spawnX: 4040,
      spawnY: -20,
      patrolMinX: 3130,
      patrolMaxX: 4320,
      facing: -1,
      alive: true,
      hitFlashTimer: 0,
      invulnTimer: 0,
      stateTimer: 1.2,
      aiPhase: 'idle',
      telegraphTimer: 0,
      phase2: false,
    },
  ];

  return {
    platforms,
    hazards,
    rails,
    grappleNodes,
    terminals,
    pickups,
    enemies,
  };
}

export function detectSector(x: number, y: number): SectorId {
  const order: SectorId[] = [
    'zenith_apex',
    'cryo_abyss',
    'void_foundry',
    'black_spire',
    'data_vault',
    'maglev_spire',
    'cryo_foundry',
    'relay_skybridge',
    'sunken_conduit',
  ];
  for (const id of order) {
    const b = SECTORS[id].bounds;
    if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) {
      return id;
    }
  }
  return 'sunken_conduit';
}
