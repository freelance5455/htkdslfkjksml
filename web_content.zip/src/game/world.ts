// ═══════════════════════════════════════════════════════════════
// DARK GHOUL V2 — المدينة المفتوحة: شوارع، أبراج، طقس، ليل/نهار
// ═══════════════════════════════════════════════════════════════
import * as THREE from "three";
import { clamp, lerp } from "./systems";

export interface Col { x: number; z: number; hx: number; hz: number; h: number }
export interface Anchor { x: number; z: number; h: number }

export interface WorldHandles {
  colliders: Col[];
  anchors: Record<string, Anchor[]>;
  rects: { x: number; z: number; hx: number; hz: number }[];
  lampPts: THREE.Vector3[];
  sun: THREE.DirectionalLight;
  moon: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  rainOn: boolean;
  rainT: number;
  setRain(on: boolean): void;
  update(dt: number, dayT: number, px: number, pz: number): number;
  drawMinimap(g: CanvasRenderingContext2D, size: number, px: number, pz: number, yaw: number,
    markers: { x: number; z: number; c: string }[], enemies: { x: number; z: number; boss?: boolean }[]): void;
}

const N = 9, PITCH = 48, BLOCK = 34, HALF = (N * PITCH) / 2;

function cv(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  return [c, c.getContext("2d")!];
}

function buildingMats(rng: () => number, base: string, litP: number) {
  const [c, g] = cv(128, 256);
  const [ce, ge] = cv(128, 256);
  g.fillStyle = base; g.fillRect(0, 0, 128, 256);
  ge.fillStyle = "#000"; ge.fillRect(0, 0, 128, 256);
  const cols = 6, rows = 14;
  for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
    const x = 8 + i * 19, y = 8 + j * 17.5;
    g.fillStyle = "#0a0c10"; g.fillRect(x, y, 13, 11);
    if (rng() < litP) {
      const warm = rng() < 0.72;
      const colr = warm ? "#ffca7a" : "#9fc4ff";
      ge.fillStyle = colr; ge.fillRect(x, y, 13, 11);
      g.fillStyle = warm ? "rgba(255,202,122,0.5)" : "rgba(159,196,255,0.45)";
      g.fillRect(x, y, 13, 11);
    }
  }
  // خطوط أرضيات
  g.fillStyle = "rgba(0,0,0,0.25)";
  for (let j = 0; j <= rows; j++) g.fillRect(0, 5 + j * 17.5, 128, 1.6);
  const map = new THREE.CanvasTexture(c); map.colorSpace = THREE.SRGBColorSpace;
  const em = new THREE.CanvasTexture(ce); em.colorSpace = THREE.SRGBColorSpace;
  return new THREE.MeshStandardMaterial({ map, emissiveMap: em, emissive: 0xffffff, emissiveIntensity: 0, roughness: 0.82, metalness: 0.12 });
}

function groundTexture(): THREE.CanvasTexture {
  const SIZE = HALF * 2 + 40;
  const [c, g] = cv(1024, 1024);
  const W2U = 1024 / SIZE;
  const toPx = (w: number) => (w + SIZE / 2) * W2U;
  g.fillStyle = "#101216"; g.fillRect(0, 0, 1024, 1024);
  // ضجيج أسفلت
  for (let i = 0; i < 9000; i++) {
    g.fillStyle = Math.random() < 0.5 ? "rgba(255,255,255,0.016)" : "rgba(0,0,0,0.05)";
    g.fillRect(Math.random() * 1024, Math.random() * 1024, 2, 2);
  }
  // الشوارع
  for (let i = 0; i < N; i++) {
    const center = -HALF + 24 + i * PITCH; // مركز الشارع
    const p0 = toPx(center - 7);
    g.fillStyle = "#181c22";
    g.fillRect(p0, 0, 14 * W2U, 1024);
    g.fillRect(0, p0, 1024, 14 * W2U);
    // خط متقطع
    g.fillStyle = "rgba(200,170,80,0.3)";
    for (let d = 0; d < 1024; d += 26) {
      g.fillRect(toPx(center) - 1, d, 2, 13);
      g.fillRect(d, toPx(center) - 1, 13, 2);
    }
    // ممرات مشاة عند التقاطعات
    for (let j = 0; j < N; j++) {
      const c2 = -HALF + 24 + j * PITCH;
      g.fillStyle = "rgba(210,215,225,0.16)";
      for (let k = 0; k < 5; k++) {
        g.fillRect(toPx(c2 - 6) + k * 5.5 * W2U, toPx(center - 8), 3 * W2U, 16 * W2U);
        g.fillRect(toPx(center - 8), toPx(c2 - 6) + k * 5.5 * W2U, 16 * W2U, 3 * W2U);
      }
    }
  }
  // أرصفة الكتل
  for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) {
    const bx = (i - (N - 1) / 2) * PITCH, bz = (j - (N - 1) / 2) * PITCH;
    g.fillStyle = "#14171d";
    g.fillRect(toPx(bx - BLOCK / 2), toPx(bz - BLOCK / 2), BLOCK * W2U, BLOCK * W2U);
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function neonTexture(text: string, color: string): THREE.CanvasTexture {
  const [c, g] = cv(256, 96);
  g.fillStyle = "rgba(6,7,10,0.92)"; g.fillRect(0, 0, 256, 96);
  g.strokeStyle = color; g.lineWidth = 4; g.strokeRect(6, 6, 244, 84);
  g.font = "bold 44px sans-serif"; g.textAlign = "center"; g.textBaseline = "middle";
  g.shadowColor = color; g.shadowBlur = 18;
  g.fillStyle = color; g.fillText(text, 128, 50);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function signTexture(lines: string[], color: string): THREE.CanvasTexture {
  const [c, g] = cv(256, 128);
  g.fillStyle = "rgba(8,8,12,0.95)"; g.fillRect(0, 0, 256, 128);
  g.strokeStyle = color; g.lineWidth = 5; g.strokeRect(5, 5, 246, 118);
  g.textAlign = "center"; g.shadowColor = color; g.shadowBlur = 16; g.fillStyle = color;
  g.font = "bold 34px sans-serif";
  lines.forEach((l, i) => g.fillText(l, 128, 48 + i * 42));
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function buildWorld(scene: THREE.Scene, quality: number, rng: () => number): WorldHandles {
  const colliders: Col[] = [];
  const anchors: Record<string, Anchor[]> = {};
  const rects: { x: number; z: number; hx: number; hz: number }[] = [];
  const lampPts: THREE.Vector3[] = [];
  const windowMats: THREE.MeshStandardMaterial[] = [];
  const neonMats: THREE.MeshBasicMaterial[] = [];
  const addAnchor = (k: string, a: Anchor) => { (anchors[k] = anchors[k] || []).push(a); };

  // الأرض
  const groundMat = new THREE.MeshStandardMaterial({ map: groundTexture(), roughness: 0.5, metalness: 0.28 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(HALF * 2 + 40, HALF * 2 + 40), groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);

  // برك ماء عاكسة
  for (let i = 0; i < 16; i++) {
    const road = -HALF + 24 + Math.floor(rng() * N) * PITCH;
    const along = (rng() - 0.5) * 2 * HALF;
    const horiz = rng() < 0.5;
    const p = new THREE.Mesh(new THREE.CircleGeometry(1.6 + rng() * 2.6, 12),
      new THREE.MeshStandardMaterial({ color: 0x0b0e14, roughness: 0.06, metalness: 0.95 }));
    p.rotation.x = -Math.PI / 2;
    p.position.set(horiz ? road + (rng() - 0.5) * 8 : along, 0.02, horiz ? along : road + (rng() - 0.5) * 8);
    scene.add(p);
  }

  const box = (x: number, z: number, w: number, h: number, d: number, m: THREE.Material, col = true) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    mesh.position.set(x, h / 2, z);
    mesh.castShadow = true; mesh.receiveShadow = true;
    scene.add(mesh);
    if (col) { colliders.push({ x, z, hx: w / 2, hz: d / 2, h }); rects.push({ x, z, hx: w / 2, hz: d / 2 }); }
    return mesh;
  };

  // ── المباني ──
  const special: Record<string, (bx: number, bz: number) => void> = {};
  special["1,1"] = (bx, bz) => { // الحديقة
    const grass = new THREE.Mesh(new THREE.PlaneGeometry(BLOCK, BLOCK), new THREE.MeshStandardMaterial({ color: 0x101c14, roughness: 0.95 }));
    grass.rotation.x = -Math.PI / 2; grass.position.set(bx, 0.03, bz); scene.add(grass);
    for (let t = 0; t < 11; t++) {
      const tx = bx + (rng() - 0.5) * 26, tz = bz + (rng() - 0.5) * 26;
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.2, 1.9, 6), new THREE.MeshStandardMaterial({ color: 0x2b2018, roughness: 0.9 }));
      trunk.position.set(tx, 0.95, tz); scene.add(trunk);
      const fol = new THREE.Mesh(new THREE.ConeGeometry(1.3 + rng(), 3.2, 7), new THREE.MeshStandardMaterial({ color: 0x15281d, roughness: 0.9 }));
      fol.position.set(tx, 3.4, tz); fol.castShadow = true; scene.add(fol);
    }
    addAnchor("park", { x: bx, z: bz, h: 0 });
  };
  special["6,1"] = (bx, bz) => { // المستشفى
    box(bx, bz, 26, 26, 18, buildingMats(rng, "#3a4048", 0.5));
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(7, 7),
      new THREE.MeshBasicMaterial({ map: signTexture(["+", "HOSPITAL"], "#ff3b4e"), toneMapped: false }));
    sign.position.set(bx, 20, bz - 9.2); scene.add(sign);
    addAnchor("hospital", { x: bx, z: bz - 13, h: 0 });
  };
  special["2,6"] = (bx, bz) => { // مقهى اللوتس الأسود
    box(bx - 4, bz + 5, 15, 8, 12, new THREE.MeshStandardMaterial({ color: 0x241c18, roughness: 0.8 }));
    const glow = new THREE.Mesh(new THREE.PlaneGeometry(10, 3),
      new THREE.MeshBasicMaterial({ map: neonTexture("珈琲 BLACK LOTUS", "#ffb02e"), toneMapped: false }));
    glow.position.set(bx - 4, 5.6, bz + 5 - 6.15); scene.add(glow);
    neonMats.push(glow.material as THREE.MeshBasicMaterial);
    const door = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 3.4),
      new THREE.MeshStandardMaterial({ color: 0x3a2a14, emissive: 0xffa040, emissiveIntensity: 1.4 }));
    door.position.set(bx - 4, 1.7, bz + 5 - 6.1); scene.add(door);
    addAnchor("cafe", { x: bx - 4, z: bz - 3, h: 0 });
  };
  special["3,6"] = (bx, bz) => { // شقة كورو + منارة أسطح 1
    const b = box(bx, bz, 14, 20, 14, buildingMats(rng, "#22262e", 0.32));
    windowMats.push(b.material as THREE.MeshStandardMaterial);
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(6, 3),
      new THREE.MeshBasicMaterial({ map: neonTexture("アパート", "#7aa2ff"), toneMapped: false }));
    sign.position.set(bx, 8, bz - 7.2); scene.add(sign);
    addAnchor("apartment", { x: bx, z: bz - 9, h: 0 });
    addAnchor("roofs", { x: bx, z: bz, h: 20 });
  };
  special["6,6"] = (bx, bz) => { // مقر القسم الأزرق CCG
    box(bx, bz, 18, 58, 18, buildingMats(rng, "#1d2530", 0.55));
    for (let s = 0; s < 4; s++) {
      const stripe = new THREE.Mesh(new THREE.PlaneGeometry(18.4, 1.2),
        new THREE.MeshStandardMaterial({ color: 0x0a1626, emissive: 0x3d7bff, emissiveIntensity: 1.6 }));
      stripe.position.set(bx, 12 + s * 13, bz - 9.3); scene.add(stripe);
    }
    addAnchor("ccg", { x: bx, z: bz - 13, h: 0 });
  };
  special["4,0"] = (bx, bz) => { // المترو
    box(bx, bz + 10, 9, 3.4, 7, new THREE.MeshStandardMaterial({ color: 0x2a2e34, roughness: 0.7 }));
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(6, 2.6),
      new THREE.MeshBasicMaterial({ map: neonTexture("地下鉄 METRO", "#2dd4bf"), toneMapped: false }));
    sign.position.set(bx, 2.6, bz + 6.4); scene.add(sign);
    addAnchor("subway", { x: bx, z: bz + 5, h: 0 });
  };
  special["7,7"] = (bx, bz) => { // الضريح والتوري
    box(bx + 4, bz + 4, 10, 6, 8, new THREE.MeshStandardMaterial({ color: 0x301c1c, roughness: 0.85 }));
    const red = new THREE.MeshStandardMaterial({ color: 0x8e1f28, roughness: 0.6 });
    [-2.4, 2.4].forEach((dx) => {
      const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.38, 7.4, 8), red);
      pillar.position.set(bx - 6 + dx, 3.7, bz - 6); pillar.castShadow = true; scene.add(pillar);
      colliders.push({ x: bx - 6 + dx, z: bz - 6, hx: 0.5, hz: 0.5, h: 7.4 });
    });
    const beam1 = new THREE.Mesh(new THREE.BoxGeometry(8.4, 0.5, 0.6), red);
    beam1.position.set(bx - 6, 7.3, bz - 6); scene.add(beam1);
    const beam2 = new THREE.Mesh(new THREE.BoxGeometry(6.8, 0.4, 0.5), red);
    beam2.position.set(bx - 6, 6.2, bz - 6); scene.add(beam2);
    addAnchor("shrine", { x: bx - 6, z: bz - 9, h: 0 });
  };
  special["0,4"] = (bx, bz) => { // مستودعات الوشاح الأحمر
    for (let w = 0; w < 3; w++) {
      const wx = bx - 8 + w * 10, wz = bz + (w % 2) * 8 - 4;
      box(wx, wz, 9, 6.5, 13, new THREE.MeshStandardMaterial({ color: 0x2c2622, roughness: 0.9 }));
    }
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(6, 3),
      new THREE.MeshBasicMaterial({ map: neonTexture("倉庫 CARGO", "#ff2d55"), toneMapped: false }));
    sign.position.set(bx, 5, bz - 12); scene.add(sign);
    addAnchor("warehouse", { x: bx + 4, z: bz - 10, h: 0 });
  };
  special["4,4"] = (bx, bz) => { // البرج الأحمر المركزي
    box(bx, bz, 24, 92, 24, buildingMats(rng, "#191420", 0.4));
    for (let s = 0; s < 6; s++) {
      const stripe = new THREE.Mesh(new THREE.PlaneGeometry(24.4, 0.9),
        new THREE.MeshStandardMaterial({ color: 0x1a050a, emissive: 0xd21f3c, emissiveIntensity: 1.9 }));
      stripe.position.set(bx, 8 + s * 15, bz - 12.25); scene.add(stripe);
    }
    addAnchor("tower", { x: bx, z: bz, h: 92 });
    addAnchor("towerBase", { x: bx, z: bz - 16, h: 0 });
  };
  special["5,4"] = (bx, bz) => { // مبنى الحديقة السرية
    box(bx, bz, 16, 26, 14, buildingMats(rng, "#1c2420", 0.25));
    const garden = new THREE.Group();
    for (let f = 0; f < 26; f++) {
      const fl = new THREE.Mesh(new THREE.SphereGeometry(0.22, 6, 5),
        new THREE.MeshStandardMaterial({ color: 0x40101c, emissive: 0xff3d64, emissiveIntensity: 1.7 }));
      fl.position.set(bx + (rng() - 0.5) * 12, 26.25, bz + (rng() - 0.5) * 10);
      garden.add(fl);
    }
    scene.add(garden);
    addAnchor("garden", { x: bx, z: bz, h: 26 });
  };
  special["1,6"] = (bx, bz) => { // منارة أسطح 2
    box(bx, bz, 13, 24, 13, buildingMats(rng, "#26222c", 0.3));
    addAnchor("roofs", { x: bx, z: bz, h: 24 });
  };
  special["2,5"] = (bx, bz) => { // منارة أسطح 3
    box(bx, bz, 12, 16, 12, buildingMats(rng, "#232830", 0.34));
    addAnchor("roofs", { x: bx, z: bz, h: 16 });
  };
  special["8,4"] = (bx, bz) => { // زقاق القتال الأول
    box(bx - 6, bz, 8, 18, 10, buildingMats(rng, "#20242c", 0.3));
    box(bx + 6, bz, 8, 14, 10, buildingMats(rng, "#242028", 0.3));
    addAnchor("alley", { x: bx, z: bz, h: 0 });
  };

  // خامات نوافذ مشتركة (أداء)
  const matCache: THREE.MeshStandardMaterial[] = [];
  const bases = ["#1a1d24", "#22262e", "#171a20", "#262a33"];
  for (let b = 0; b < 4; b++) for (let l = 0; l < 3; l++) matCache.push(buildingMats(rng, bases[b], 0.15 + l * 0.2));
  windowMats.push(...matCache);

  // مبانٍ عشوائية في بقية الكتل
  for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) {
    const key = `${i},${j}`;
    const bx = (i - (N - 1) / 2) * PITCH, bz = (j - (N - 1) / 2) * PITCH;
    if (special[key]) { special[key](bx, bz); continue; }
    const dist = Math.hypot(bx, bz);
    const cf = 1 - clamp(dist / (HALF * 1.05), 0, 1);
    const count = rng() < 0.42 ? 1 : rng() < 0.7 ? 2 : 3;
    for (let b = 0; b < count; b++) {
      const w = count === 1 ? 20 + rng() * 10 : 9 + rng() * 8;
      const d = count === 1 ? 20 + rng() * 10 : 9 + rng() * 8;
      const ox = count === 1 ? 0 : (rng() - 0.5) * (BLOCK - w - 4);
      const oz = count === 1 ? 0 : (rng() - 0.5) * (BLOCK - d - 4);
      const h = 11 + rng() * 16 + cf * cf * 62 * rng();
      const m = matCache[Math.floor(rng() * matCache.length)];
      const mesh = box(bx + ox, bz + oz, w, h, d, m);
      // تفاصيل سطح
      if (h > 26 && rng() < 0.6) {
        const ac = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1, 1.2), new THREE.MeshStandardMaterial({ color: 0x3a4046, roughness: 0.8 }));
        ac.position.set(bx + ox + (rng() - 0.5) * w * 0.5, h + 0.5, bz + oz + (rng() - 0.5) * d * 0.5);
        scene.add(ac);
      }
      if (h > 40 && rng() < 0.5) {
        const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.08, 5, 5), new THREE.MeshStandardMaterial({ color: 0x2c3036 }));
        ant.position.set(bx + ox, h + 2.5, bz + oz); scene.add(ant);
        const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.16, 6, 5),
          new THREE.MeshStandardMaterial({ color: 0x330a10, emissive: 0xff2038, emissiveIntensity: 2.5 }));
        lamp.position.set(bx + ox, h + 5, bz + oz); scene.add(lamp);
      }
      // لافتة نيون
      if (h < 42 && rng() < 0.5) {
        const texts = ["ラーメン", "HOTEL", "BAR", "24H", "居酒屋", "カラオケ", "薬局", "焼肉", "CLUB", "書店"];
        const colors = ["#ff2d55", "#2dd4bf", "#ffb02e", "#ff6ec7", "#7aa2ff"];
        const nm = new THREE.MeshBasicMaterial({
          map: neonTexture(texts[Math.floor(rng() * texts.length)], colors[Math.floor(rng() * colors.length)]),
          toneMapped: false,
        });
        neonMats.push(nm);
        const side = rng() < 0.5 ? 1 : -1;
        const horiz = rng() < 0.5;
        const sign = new THREE.Mesh(new THREE.PlaneGeometry(5.5, 2.4), nm);
        sign.position.set(
          horiz ? bx + ox : bx + ox + side * (w / 2 + 0.08),
          6 + rng() * 5,
          horiz ? bz + oz + side * (d / 2 + 0.08) : bz + oz
        );
        if (horiz) sign.rotation.y = side < 0 ? Math.PI : 0;
        else sign.rotation.y = side < 0 ? -Math.PI / 2 : Math.PI / 2;
        scene.add(sign);
      }
      void mesh;
    }
  }

  // سيارات متوقفة
  const carColors = [0x6e1420, 0x111418, 0x39404a, 0x1e3a44, 0x565c62, 0x2a2438];
  for (let c = 0; c < 18; c++) {
    const road = -HALF + 24 + Math.floor(rng() * N) * PITCH;
    const along = (rng() - 0.5) * 2 * (HALF - 20);
    const horiz = rng() < 0.5;
    const off = (rng() < 0.5 ? -1 : 1) * 4.6;
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.75, 4.3),
      new THREE.MeshStandardMaterial({ color: carColors[Math.floor(rng() * carColors.length)], roughness: 0.25, metalness: 0.7 }));
    body.position.y = 0.62; body.castShadow = true; g.add(body);
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.6, 2.2),
      new THREE.MeshStandardMaterial({ color: 0x0c0f14, roughness: 0.15, metalness: 0.6 }));
    cabin.position.y = 1.25; cabin.position.z = -0.2; g.add(cabin);
    const wheelG = new THREE.CylinderGeometry(0.34, 0.34, 0.24, 8);
    const wheelM = new THREE.MeshStandardMaterial({ color: 0x0a0a0c, roughness: 0.9 });
    [[-0.85, 1.4], [0.85, 1.4], [-0.85, -1.4], [0.85, -1.4]].forEach(([wx, wz]) => {
      const wh = new THREE.Mesh(wheelG, wheelM);
      wh.rotation.z = Math.PI / 2; wh.position.set(wx, 0.34, wz); g.add(wh);
    });
    g.position.set(horiz ? along : road + off, 0, horiz ? road + off : along);
    if (horiz) g.rotation.y = Math.PI / 2;
    scene.add(g);
    colliders.push({ x: g.position.x, z: g.position.z, hx: horiz ? 2.2 : 1.05, hz: horiz ? 1.05 : 2.2, h: 1.3 });
  }

  // أعمدة إنارة
  const lampCounts = [22, 42, 70];
  const lampMax = lampCounts[quality];
  const poleG = new THREE.CylinderGeometry(0.09, 0.12, 5.4, 6);
  const poleM = new THREE.MeshStandardMaterial({ color: 0x23262c, roughness: 0.7, metalness: 0.5 });
  const headM = new THREE.MeshStandardMaterial({ color: 0x554a2a, emissive: 0xffd9a0, emissiveIntensity: 2.2 });
  const glowTex = (() => {
    const c = document.createElement("canvas"); c.width = c.height = 64;
    const g2 = c.getContext("2d")!;
    const gr = g2.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, "rgba(255,217,160,0.9)"); gr.addColorStop(1, "transparent");
    g2.fillStyle = gr; g2.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  })();
  let lamps = 0;
  for (let i = 0; i < N && lamps < lampMax; i++) {
    const road = -HALF + 24 + i * PITCH;
    for (let z = -HALF + 14; z < HALF - 10 && lamps < lampMax; z += 42) {
      const side = lamps % 2 === 0 ? -5.6 : 5.6;
      const pole = new THREE.Mesh(poleG, poleM);
      pole.position.set(road + side, 2.7, z); scene.add(pole);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 6), headM);
      head.position.set(road + side * 0.55, 5.4, z); scene.add(head);
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0.8 }));
      sp.scale.setScalar(2.6); sp.position.copy(head.position); scene.add(sp);
      lampPts.push(head.position.clone());
      lamps++;
    }
  }

  // ── الإضاءة ──
  const sun = new THREE.DirectionalLight(0xffe8cf, 0);
  sun.castShadow = quality === 2;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.left = -60; sun.shadow.camera.right = 60;
  sun.shadow.camera.top = 60; sun.shadow.camera.bottom = -60;
  sun.shadow.camera.far = 300;
  sun.shadow.bias = -0.002;
  scene.add(sun); scene.add(sun.target);
  const moon = new THREE.DirectionalLight(0x6f89c8, 0.45);
  moon.position.set(-50, 70, -30);
  scene.add(moon);
  const hemi = new THREE.HemisphereLight(0x2a3444, 0x0e1016, 0.5);
  scene.add(hemi);

  // ── المطر ──
  const rainCounts = [0, 1000, 2200];
  const rainN = rainCounts[quality];
  let rain: THREE.LineSegments | null = null;
  const rainVel = 36;
  if (rainN > 0) {
    const pos = new Float32Array(rainN * 2 * 3);
    for (let i = 0; i < rainN; i++) {
      const x = (Math.random() - 0.5) * 100, y = Math.random() * 42, z = (Math.random() - 0.5) * 100;
      pos.set([x, y, z, x + 0.06, y - 0.85, z + 0.1], i * 6);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    rain = new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: 0x93a7c4, transparent: true, opacity: 0 }));
    rain.frustumCulled = false;
    scene.add(rain);
  }
  const fog = new THREE.FogExp2(0x070a10, 0.0062);
  scene.fog = fog;
  scene.background = new THREE.Color(0x04060c);

  const skyNight = new THREE.Color(0x04060c);
  const skyDay = new THREE.Color(0x66788e);
  const skyDusk = new THREE.Color(0x33181f);
  const tmp = new THREE.Color();

  let rainOn = false, rainT = 0;

  const w: WorldHandles = {
    colliders, anchors, rects, lampPts, sun, moon, hemi,
    rainOn: false, rainT: 0,
    setRain(on: boolean) { rainOn = on; w.rainOn = on; },
    update(dt, dayT, px, pz) {
      const elev = Math.sin((dayT - 0.25) * Math.PI * 2);
      const dayF = clamp(elev * 1.6, 0, 1);
      const nightF = 1 - dayF;
      const duskF = clamp(1 - Math.abs(elev) * 3.5, 0, 1);
      // الشمس
      const ang = (dayT - 0.25) * Math.PI * 2;
      sun.position.set(px + Math.cos(ang) * 90, Math.max(8, Math.sin(ang) * 110), pz + 45);
      sun.target.position.set(px, 0, pz);
      sun.intensity = dayF * 1.7;
      moon.intensity = nightF * 0.5;
      hemi.intensity = 0.32 + dayF * 0.55;
      tmp.copy(skyNight).lerp(skyDay, dayF).lerp(skyDusk, duskF * 0.55);
      (scene.background as THREE.Color).copy(tmp);
      fog.color.copy(tmp);
      fog.density = 0.0058 + nightF * 0.0012 + rainT * 0.003;
      // النوافذ والنيون ليلاً
      const glow = nightF * (0.85 + rainT * 0.3);
      for (const m of windowMats) m.emissiveIntensity = glow * 1.05;
      for (const m of neonMats) {
        const v = lerp(0.16, 1, nightF);
        m.color.setRGB(v, v, v);
      }
      // المطر
      rainT = damp3(rainT, rainOn ? 1 : 0, 0.8, dt);
      w.rainT = rainT;
      groundMat.roughness = lerp(0.5, 0.14, rainT);
      if (rain) {
        (rain.material as THREE.LineBasicMaterial).opacity = 0.34 * rainT;
        rain.position.set(px, 0, pz);
        if (rainT > 0.02) {
          const arr = (rain.geometry.getAttribute("position") as THREE.BufferAttribute);
          const a = arr.array as Float32Array;
          for (let i = 1; i < a.length; i += 3) {
            a[i] -= rainVel * dt;
            if (a[i] < 0) a[i] += 42;
          }
          arr.needsUpdate = true;
        }
      }
      return nightF;
    },
    drawMinimap(g2, size, px2, pz2, yaw, markers, enemies) {
      const R = 130, s = size / (R * 2);
      g2.clearRect(0, 0, size, size);
      g2.fillStyle = "rgba(7,9,14,0.88)";
      g2.fillRect(0, 0, size, size);
      g2.fillStyle = "#242b3a";
      for (const r of rects) {
        const x = (r.x - px2) * s + size / 2, y = (r.z - pz2) * s + size / 2;
        if (x < -20 || y < -20 || x > size + 20 || y > size + 20) continue;
        g2.fillRect(x - r.hx * s, y - r.hz * s, r.hx * 2 * s, r.hz * 2 * s);
      }
      for (const m of markers) {
        const x = (m.x - px2) * s + size / 2, y = (m.z - pz2) * s + size / 2;
        if (x < 4 || y < 4 || x > size - 4 || y > size - 4) continue;
        g2.fillStyle = m.c;
        g2.save(); g2.translate(x, y); g2.rotate(Math.PI / 4);
        g2.fillRect(-3.4, -3.4, 6.8, 6.8); g2.restore();
      }
      for (const e of enemies) {
        const x = (e.x - px2) * s + size / 2, y = (e.z - pz2) * s + size / 2;
        if (x < 3 || y < 3 || x > size - 3 || y > size - 3) continue;
        g2.fillStyle = e.boss ? "#ff2d55" : "#c23b52";
        g2.beginPath(); g2.arc(x, y, e.boss ? 4.4 : 2.4, 0, Math.PI * 2); g2.fill();
      }
      // اللاعب
      g2.save();
      g2.translate(size / 2, size / 2);
      g2.rotate(yaw);
      g2.fillStyle = "#e8e4dc";
      g2.beginPath(); g2.moveTo(0, -6); g2.lineTo(4.4, 5); g2.lineTo(-4.4, 5); g2.closePath(); g2.fill();
      g2.restore();
      g2.strokeStyle = "rgba(210,31,60,0.55)"; g2.lineWidth = 1.5;
      g2.strokeRect(0.75, 0.75, size - 1.5, size - 1.5);
    },
  };
  return w;
}

function damp3(a: number, b: number, l: number, dt: number) {
  return a + (b - a) * (1 - Math.exp(-l * dt));
}
