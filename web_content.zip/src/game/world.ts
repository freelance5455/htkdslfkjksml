import * as THREE from 'three';

export interface Box { minX: number; minY: number; minZ: number; maxX: number; maxY: number; maxZ: number; metal?: boolean; stamp: number }
export interface RayHit { dist: number; nx: number; ny: number; nz: number; box: Box | null }

const CELL = 8;

export class World {
  boxes: Box[] = [];
  private grid = new Map<number, Box[]>();
  private stamp = 1;
  heightFn: ((x: number, z: number) => number) | null = null;
  bounds = { minX: -100, maxX: 100, minZ: -100, maxZ: 100 };
  // nav grid
  navCell = 1.5; navW = 0; navH = 0; nav: Uint8Array = new Uint8Array(0);

  private key(cx: number, cz: number) { return (cx + 512) * 1024 + (cz + 512); }

  addBox(minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number, metal = false): Box {
    const b: Box = { minX, minY, minZ, maxX, maxY, maxZ, metal, stamp: 0 };
    this.boxes.push(b);
    const x0 = Math.floor(minX / CELL), x1 = Math.floor(maxX / CELL), z0 = Math.floor(minZ / CELL), z1 = Math.floor(maxZ / CELL);
    for (let x = x0; x <= x1; x++) for (let z = z0; z <= z1; z++) {
      const k = this.key(x, z); let arr = this.grid.get(k); if (!arr) { arr = []; this.grid.set(k, arr); } arr.push(b);
    }
    return b;
  }

  ground(x: number, z: number) { return this.heightFn ? this.heightFn(x, z) : 0; }

  /** Boxes overlapping an XZ rectangle (deduplicated) */
  query(minX: number, minZ: number, maxX: number, maxZ: number, out: Box[]) {
    out.length = 0; const s = ++this.stamp;
    const x0 = Math.floor(minX / CELL), x1 = Math.floor(maxX / CELL), z0 = Math.floor(minZ / CELL), z1 = Math.floor(maxZ / CELL);
    for (let x = x0; x <= x1; x++) for (let z = z0; z <= z1; z++) {
      const arr = this.grid.get(this.key(x, z)); if (!arr) continue;
      for (const b of arr) if (b.stamp !== s) { b.stamp = s; if (b.maxX >= minX && b.minX <= maxX && b.maxZ >= minZ && b.minZ <= maxZ) out.push(b); }
    }
    return out;
  }

  /** Ray vs boxes (2D DDA through spatial hash) + terrain. dir must be normalised. */
  raycast(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, maxDist: number): RayHit | null {
    let best: RayHit | null = null; let bestT = maxDist;
    const s = ++this.stamp;
    let cx = Math.floor(ox / CELL), cz = Math.floor(oz / CELL);
    const stepX = dx > 0 ? 1 : -1, stepZ = dz > 0 ? 1 : -1;
    const tDX = Math.abs(dx) < 1e-9 ? Infinity : Math.abs(CELL / dx), tDZ = Math.abs(dz) < 1e-9 ? Infinity : Math.abs(CELL / dz);
    let tMX = Math.abs(dx) < 1e-9 ? Infinity : ((dx > 0 ? (cx + 1) * CELL - ox : ox - cx * CELL) / Math.abs(dx));
    let tMZ = Math.abs(dz) < 1e-9 ? Infinity : ((dz > 0 ? (cz + 1) * CELL - oz : oz - cz * CELL) / Math.abs(dz));
    let tCell = 0;
    for (let iter = 0; iter < 200 && tCell <= bestT; iter++) {
      const arr = this.grid.get(this.key(cx, cz));
      if (arr) for (const b of arr) {
        if (b.stamp === s) continue; b.stamp = s;
        // slab test (allocation-free)
        let tmin = 0, tmax = bestT, nAxis = -1, nSign = 0;
        let ok = true;
        for (let a = 0; a < 3 && ok; a++) {
          const oa = a === 0 ? ox : a === 1 ? oy : oz, da = a === 0 ? dx : a === 1 ? dy : dz;
          const mna = a === 0 ? b.minX : a === 1 ? b.minY : b.minZ, mxa = a === 0 ? b.maxX : a === 1 ? b.maxY : b.maxZ;
          if (Math.abs(da) < 1e-9) { if (oa < mna || oa > mxa) ok = false; continue; }
          const inv = 1 / da; let t1 = (mna - oa) * inv, t2 = (mxa - oa) * inv; let sg = -1;
          if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; sg = 1; }
          if (t1 > tmin) { tmin = t1; nAxis = a; nSign = sg; }
          if (t2 < tmax) tmax = t2;
          if (tmin > tmax) ok = false;
        }
        if (ok && tmin < bestT && nAxis >= 0) {
          bestT = tmin; best = { dist: tmin, nx: nAxis === 0 ? nSign : 0, ny: nAxis === 1 ? nSign : 0, nz: nAxis === 2 ? nSign : 0, box: b };
        }
      }
      if (tMX < tMZ) { tCell = tMX; tMX += tDX; cx += stepX; } else { tCell = tMZ; tMZ += tDZ; cz += stepZ; }
    }
    // terrain
    if (this.heightFn) {
      const step = 1.25; let prevT = 0;
      for (let t = step; t <= bestT + step; t += step) {
        const tt = Math.min(t, bestT); const y = oy + dy * tt;
        if (y < this.heightFn(ox + dx * tt, oz + dz * tt)) {
          let lo = prevT, hi = tt;
          for (let i = 0; i < 6; i++) { const m = (lo + hi) / 2; if (oy + dy * m < this.heightFn(ox + dx * m, oz + dz * m)) hi = m; else lo = m; }
          if (hi < bestT) { bestT = hi; best = { dist: hi, nx: 0, ny: 1, nz: 0, box: null }; }
          break;
        }
        prevT = tt; if (tt >= bestT) break;
      }
    } else if (dy < -1e-6) {
      const t = -oy / dy; if (t > 0 && t < bestT) { bestT = t; best = { dist: t, nx: 0, ny: 1, nz: 0, box: null }; }
    }
    return best;
  }

  lineOfSight(a: THREE.Vector3, b: THREE.Vector3) {
    const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z; const d = Math.hypot(dx, dy, dz); if (d < 0.01) return true;
    const h = this.raycast(a.x, a.y, a.z, dx / d, dy / d, dz / d, d);
    return !h || h.dist >= d - 0.05;
  }

  // ---------------- character movement ----------------
  private tmp: Box[] = [];
  /** Moves a vertical-cylinder character with wall sliding, step-up (0.5m), gravity and ceilings. Returns landing speed or 0. */
  moveCharacter(pos: THREE.Vector3, vel: THREE.Vector3, radius: number, height: number, dt: number, state: { onGround: boolean }): number {
    const STEP = 0.5; let landed = 0;
    const steps = Math.max(1, Math.ceil((Math.hypot(vel.x, vel.z) * dt) / (radius * 0.8)));
    const sdt = dt / steps;
    for (let i = 0; i < steps; i++) {
      pos.x += vel.x * sdt; pos.z += vel.z * sdt;
      this.pushOut(pos, radius, height, STEP);
    }
    // bounds
    pos.x = Math.max(this.bounds.minX + radius, Math.min(this.bounds.maxX - radius, pos.x));
    pos.z = Math.max(this.bounds.minZ + radius, Math.min(this.bounds.maxZ - radius, pos.z));
    // vertical
    vel.y -= 24 * dt;
    const newY = pos.y + vel.y * dt;
    const floor = this.floorAt(pos.x, pos.z, radius * 0.7, pos.y + STEP);
    if (vel.y > 0) {
      const ceil = this.ceilingAt(pos.x, pos.z, radius * 0.7, pos.y + height);
      if (newY + height > ceil) { pos.y = ceil - height; vel.y = 0; } else pos.y = newY;
      state.onGround = false;
    } else if (newY <= floor) {
      if (!state.onGround && vel.y < -2) landed = -vel.y;
      pos.y = floor; vel.y = 0; state.onGround = true;
    } else {
      // stick to ground going down small steps/slopes
      if (state.onGround && pos.y - floor < STEP * 0.9 && vel.y > -4) { pos.y = floor; vel.y = 0; }
      else { pos.y = newY; state.onGround = false; }
    }
    return landed;
  }

  private pushOut(pos: THREE.Vector3, r: number, height: number, step: number) {
    const boxes = this.query(pos.x - r, pos.z - r, pos.x + r, pos.z + r, this.tmp);
    for (const b of boxes) {
      if (b.maxY <= pos.y + step || b.minY >= pos.y + height) continue; // walkable step or overhead
      const cx = Math.max(b.minX, Math.min(pos.x, b.maxX)), cz = Math.max(b.minZ, Math.min(pos.z, b.maxZ));
      let dx = pos.x - cx, dz = pos.z - cz; const d2 = dx * dx + dz * dz;
      if (d2 >= r * r) continue;
      if (d2 > 1e-8) { const d = Math.sqrt(d2); const push = r - d; dx /= d; dz /= d; pos.x += dx * push; pos.z += dz * push; }
      else {
        // centre inside box: push out on the shortest axis
        const l = pos.x - b.minX, rr = b.maxX - pos.x, f = pos.z - b.minZ, bk = b.maxZ - pos.z; const m = Math.min(l, rr, f, bk);
        if (m === l) pos.x = b.minX - r; else if (m === rr) pos.x = b.maxX + r; else if (m === f) pos.z = b.minZ - r; else pos.z = b.maxZ + r;
      }
    }
  }

  floorAt(x: number, z: number, r: number, maxY: number) {
    let f = this.ground(x, z);
    for (const b of this.query(x - r, z - r, x + r, z + r, this.tmp)) if (b.maxY <= maxY && b.maxY > f) f = b.maxY;
    return f;
  }
  ceilingAt(x: number, z: number, r: number, headY: number) {
    let c = Infinity;
    for (const b of this.query(x - r, z - r, x + r, z + r, this.tmp)) if (b.minY >= headY - 0.6 && b.minY < c) c = b.minY;
    return c;
  }

  // ---------------- navigation grid + A* ----------------
  buildNav(cell = 1.5) {
    this.navCell = cell;
    this.navW = Math.ceil((this.bounds.maxX - this.bounds.minX) / cell);
    this.navH = Math.ceil((this.bounds.maxZ - this.bounds.minZ) / cell);
    this.nav = new Uint8Array(this.navW * this.navH);
    const r = 0.35; // agent radius: a cell is blocked if its centre lies inside an obstacle inflated by r
    for (let j = 0; j < this.navH; j++) for (let i = 0; i < this.navW; i++) {
      const x = this.bounds.minX + (i + 0.5) * cell, z = this.bounds.minZ + (j + 0.5) * cell;
      const g = this.ground(x, z);
      let blocked = 0;
      for (const b of this.query(x - r, z - r, x + r, z + r, this.tmp)) {
        if (b.maxY > g + 0.55 && b.minY < g + 1.7 && x > b.minX - r && x < b.maxX + r && z > b.minZ - r && z < b.maxZ + r) { blocked = 1; break; }
      }
      if (!blocked && this.heightFn) {
        const s = Math.abs(this.ground(x + cell, z) - g) + Math.abs(this.ground(x, z + cell) - g);
        if (s > cell * 1.6) blocked = 1;
      }
      this.nav[j * this.navW + i] = blocked;
    }
  }
  toCell(x: number, z: number): [number, number] {
    return [Math.max(0, Math.min(this.navW - 1, Math.floor((x - this.bounds.minX) / this.navCell))), Math.max(0, Math.min(this.navH - 1, Math.floor((z - this.bounds.minZ) / this.navCell)))];
  }
  cellCenter(i: number, j: number) { return { x: this.bounds.minX + (i + 0.5) * this.navCell, z: this.bounds.minZ + (j + 0.5) * this.navCell }; }
  walkable(x: number, z: number) { const [i, j] = this.toCell(x, z); return this.nav[j * this.navW + i] === 0; }
  nearestWalkable(x: number, z: number): { x: number; z: number } {
    const [ci, cj] = this.toCell(x, z);
    for (let r = 0; r < 12; r++) for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) {
      if (Math.max(Math.abs(di), Math.abs(dj)) !== r) continue;
      const i = ci + di, j = cj + dj; if (i < 0 || j < 0 || i >= this.navW || j >= this.navH) continue;
      if (this.nav[j * this.navW + i] === 0) return this.cellCenter(i, j);
    }
    return { x, z };
  }

  private gScore = new Float32Array(0); private came = new Int32Array(0); private closed = new Uint32Array(0); private searchId = 0;
  findPath(sx: number, sz: number, tx: number, tz: number, maxIter = 9000): { x: number; z: number }[] | null {
    const W = this.navW, H = this.navH, N = W * H;
    if (this.gScore.length !== N) { this.gScore = new Float32Array(N); this.came = new Int32Array(N); this.closed = new Uint32Array(N); }
    const sid = ++this.searchId * 2;
    const s = this.nearestWalkable(sx, sz), t = this.nearestWalkable(tx, tz);
    const [si, sj] = this.toCell(s.x, s.z), [ti, tj] = this.toCell(t.x, t.z);
    const start = sj * W + si, goal = tj * W + ti;
    const heap: number[] = [], hf: number[] = [];
    const push = (n: number, f: number) => { heap.push(n); hf.push(f); let i = heap.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (hf[p] <= hf[i]) break; [heap[p], heap[i]] = [heap[i], heap[p]]; [hf[p], hf[i]] = [hf[i], hf[p]]; i = p; } };
    const pop = () => { const top = heap[0]; const ln = heap.pop()!, lf = hf.pop()!; if (heap.length) { heap[0] = ln; hf[0] = lf; let i = 0; for (;;) { const l = i * 2 + 1, r = l + 1; let m = i; if (l < heap.length && hf[l] < hf[m]) m = l; if (r < heap.length && hf[r] < hf[m]) m = r; if (m === i) break; [heap[m], heap[i]] = [heap[i], heap[m]]; [hf[m], hf[i]] = [hf[i], hf[m]]; i = m; } } return top; };
    const h = (n: number) => { const dx = Math.abs((n % W) - ti), dz = Math.abs(Math.floor(n / W) - tj); return Math.max(dx, dz) + 0.414 * Math.min(dx, dz); };
    this.gScore[start] = 0; this.closed[start] = sid; this.came[start] = -1; push(start, h(start));
    let found = false, iter = 0;
    while (heap.length && iter++ < maxIter) {
      const cur = pop();
      if (cur === goal) { found = true; break; }
      if (this.closed[cur] === sid + 1) continue; this.closed[cur] = sid + 1;
      const ci = cur % W, cj = Math.floor(cur / W);
      for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) {
        if (!di && !dj) continue;
        const ni = ci + di, nj = cj + dj; if (ni < 0 || nj < 0 || ni >= W || nj >= H) continue;
        const n = nj * W + ni; if (this.nav[n]) continue;
        if (di && dj && (this.nav[cj * W + ni] || this.nav[nj * W + ci])) continue; // no corner cutting
        const g = this.gScore[cur] + (di && dj ? 1.414 : 1);
        if (this.closed[n] === sid + 1) continue;
        if (this.closed[n] !== sid || g < this.gScore[n]) { this.closed[n] = sid; this.gScore[n] = g; this.came[n] = cur; push(n, g + h(n)); }
      }
    }
    if (!found) return null;
    const pts: { x: number; z: number }[] = [];
    let n = goal; let guard = 0;
    while (n !== -1 && guard++ < 10000) { pts.push(this.cellCenter(n % W, Math.floor(n / W))); if (n === start) break; n = this.came[n]; }
    pts.reverse();
    // string pulling
    const out: { x: number; z: number }[] = [];
    let anchor = pts[0]; let k = 1;
    while (k < pts.length) {
      let far = k;
      for (let m = k; m < Math.min(pts.length, k + 14); m++) if (this.gridLine(anchor.x, anchor.z, pts[m].x, pts[m].z)) far = m;
      out.push(pts[far]); anchor = pts[far]; k = far + 1;
    }
    out.push({ x: tx, z: tz });
    return out;
  }
  gridLine(x0: number, z0: number, x1: number, z1: number) {
    const d = Math.hypot(x1 - x0, z1 - z0); const n = Math.ceil(d / (this.navCell * 0.5));
    for (let i = 1; i < n; i++) { const t = i / n; if (!this.walkable(x0 + (x1 - x0) * t, z0 + (z1 - z0) * t)) return false; }
    return true;
  }
}

// ------------- hitbox ray tests -------------
/** Ray vs sphere; returns t or -1 */
export function raySphere(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, cx: number, cy: number, cz: number, r: number) {
  const lx = ox - cx, ly = oy - cy, lz = oz - cz; const b = lx * dx + ly * dy + lz * dz; const c = lx * lx + ly * ly + lz * lz - r * r;
  const disc = b * b - c; if (disc < 0) return -1; const t = -b - Math.sqrt(disc); return t >= 0 ? t : -1;
}
/** Ray vs vertical cylinder [y0,y1] */
export function rayCylinder(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, cx: number, cz: number, y0: number, y1: number, r: number) {
  const px = ox - cx, pz = oz - cz; const a = dx * dx + dz * dz; if (a < 1e-9) return -1;
  const b = px * dx + pz * dz; const c = px * px + pz * pz - r * r; const disc = b * b - a * c; if (disc < 0) return -1;
  const t = (-b - Math.sqrt(disc)) / a; if (t < 0) return -1; const y = oy + dy * t; if (y < y0 || y > y1) return -1; return t;
}
