import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { WorldZoneInfo } from './types';

export interface ColliderBox {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  maxY: number;
}

export interface TreePhysicsActor {
  index: number;
  x: number;
  y: number;
  z: number;
  rotY: number;
  scaleXZ: number;
  scaleY: number;
  trunkRadius: number;
  canopyRadius: number;
  bendX: number;
  bendZ: number;
  velX: number;
  velZ: number;
  fallen: boolean;
  fallAngle: number;
  fallVel: number;
  fallDirX: number;
  fallDirZ: number;
  lastRustleTime: number;
}

export interface PedestrianActor {
  group: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  x: number;
  z: number;
  startX: number;
  startZ: number;
  endX: number;
  endZ: number;
  t: number;
  dir: 1 | -1;
  speed: number;
}

export interface WorldHandles {
  colliders: ColliderBox[];
  doorCollider: ColliderBox;
  trees: TreePhysicsActor[];
  pedestrians: PedestrianActor[];
  asphaltMaterials: THREE.MeshStandardMaterial[];
  windowMaterials: THREE.MeshStandardMaterial[];
  lampBulbMaterials: THREE.MeshStandardMaterial[];
  lampLights: THREE.PointLight[];
  houseLights: THREE.PointLight[];
  isDoorOpen: () => boolean;
  setDoorOpen: (open: boolean) => void;
  toggleDoor: () => boolean;
  updateHouseDoor: (dt: number) => void;
  triggerTreeImpact: (treeIdx: number, dirX: number, dirZ: number, speedMs: number, isTrunkHit: boolean) => void;
  updateTrees: (dt: number, elapsedSec: number, rainFactor: number, playerX?: number, playerZ?: number) => void;
  updatePedestrians: (dt: number, elapsedSec: number) => void;
  setNightAndRain: (nightFactor: number, rainFactor: number) => void;
  dispose: () => void;
}

export const WORLD_HALF_SIZE = 500; // 1000 x 1000 playable map (-500..+500)

export const HOUSE_DOOR_POS = { x: -2.5, z: -22.65 };
export const HOUSE_INTERIOR_BOUNDS = { minX: -9.15, maxX: 4.15, minZ: -32.15, maxZ: -22.65 };
export const HOUSE_FLOOR_Y = 0.18;

export function isInsideMainHouse(x: number, z: number): boolean {
  return (
    x >= HOUSE_INTERIOR_BOUNDS.minX &&
    x <= HOUSE_INTERIOR_BOUNDS.maxX &&
    z >= HOUSE_INTERIOR_BOUNDS.minZ &&
    z <= HOUSE_INTERIOR_BOUNDS.maxZ
  );
}

// Brazilian street speed bumps (lombadas) along Avenida Central & residential avenues
export const LOMBADA_X_POSITIONS = [-140, -55, 65, 165, 310];

export function groundHeightAt(x: number, z: number): number {
  // Keep Casa Principal, Avenida Central, Norte-Sul, and Centro flat
  const distFromCenterRoad = Math.min(Math.abs(z), Math.abs(x));
  const roadBlend = THREE.MathUtils.smoothstep(distFromCenterRoad, 22, 58);

  // NW Morro (Favela da Vitória)
  const nwDx = (x + 280) / 170;
  const nwDz = (z + 250) / 160;
  const nwR2 = nwDx * nwDx + nwDz * nwDz;
  const nwHill = nwR2 < 1.8 ? Math.exp(-nwR2 * 1.45) * 18.5 : 0;

  // SW Morro (Vila Alta Favela)
  const swDx = (x + 290) / 150;
  const swDz = (z - 270) / 145;
  const swR2 = swDx * swDx + swDz * swDz;
  const swHill = swR2 < 1.8 ? Math.exp(-swR2 * 1.5) * 13.5 : 0;

  // Outer natural ridge near map perimeter
  const edgeDist = Math.max(Math.abs(x), Math.abs(z));
  const rim = edgeDist > 455 ? THREE.MathUtils.smoothstep(edgeDist, 455, 560) * 12 : 0;

  // Speed bump relief along Avenida Central (|z| < 8.5)
  let bump = 0;
  if (Math.abs(z) < 8.5) {
    for (let i = 0; i < LOMBADA_X_POSITIONS.length; i++) {
      const dx = Math.abs(x - LOMBADA_X_POSITIONS[i]);
      if (dx < 1.4) {
        bump = Math.max(bump, Math.cos((dx / 1.4) * (Math.PI / 2)) * 0.19);
      }
    }
  }

  return (nwHill + swHill) * roadBlend + rim + bump;
}

export function groundNormalAt(x: number, z: number, target = new THREE.Vector3()): THREE.Vector3 {
  const eps = 1.5;
  const hL = groundHeightAt(x - eps, z);
  const hR = groundHeightAt(x + eps, z);
  const hD = groundHeightAt(x, z - eps);
  const hU = groundHeightAt(x, z + eps);
  target.set(hL - hR, 2 * eps, hD - hU).normalize();
  return target;
}

export function getZoneInfo(x: number, z: number): WorldZoneInfo {
  if (Math.hypot(x - 0, z + 22) < 42) {
    return { name: 'Casa Principal', subtitle: 'Sua Garagem e Ponto de Partida' };
  }
  if (Math.abs(z) < 20 && Math.abs(x) < 420) {
    return { name: 'Avenida Central', subtitle: 'Reta do Grau · Limite 140 km/h' };
  }
  if (x > 95 && z > -280 && z < 260) {
    return { name: 'Centro da Cidade', subtitle: 'Torres Comerciais e Avenidas' };
  }
  if (x < -90 && z < -60) {
    return { name: 'Favela Morro da Vitória', subtitle: 'Vielas Íngremes e Lajes' };
  }
  if (x < -90 && z > 80) {
    return { name: 'Favela Vila Alta', subtitle: 'Subida do Morro' };
  }
  if (z > 60 && x >= -85 && x <= 380) {
    return { name: 'Bairro Residencial Sul', subtitle: 'Casas e Ruas Arborizadas' };
  }
  return { name: 'Área Perimetral', subtitle: 'Mapa 1000 × 1000m' };
}

function createAsphaltTexture(maxAniso: number): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#272a30';
    ctx.fillRect(0, 0, 256, 256);

    // Subtle tire wear tracks along both lanes
    ctx.fillStyle = 'rgba(15, 17, 21, 0.28)';
    ctx.fillRect(46, 0, 32, 256);
    ctx.fillRect(178, 0, 32, 256);

    for (let i = 0; i < 4800; i++) {
      const v = 30 + Math.floor(Math.random() * 28);
      ctx.fillStyle = `rgb(${v},${v + 1},${v + 4})`;
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 2, 2);
    }
    // Center dashed yellow line
    ctx.fillStyle = '#facc15';
    ctx.fillRect(123, 18, 10, 88);
    ctx.fillRect(123, 146, 10, 88);
    // Crisp white edge lines
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(7, 0, 5, 256);
    ctx.fillRect(244, 0, 5, 256);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAniso;
  return tex;
}

function createTerrainTexture(maxAniso: number): THREE.CanvasTexture {
  const size = 128;
  const cell = 8; // 16x16 crisp Minecraft-inspired grass block mosaic
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (ctx) {
    const grassPalette = [
      '#5bc932',
      '#64d839',
      '#4db828',
      '#72e344',
      '#45a922',
      '#68dc3c',
      '#54c22e',
      '#81eb52',
    ];
    for (let y = 0; y < size; y += cell) {
      for (let x = 0; x < size; x += cell) {
        const idx = Math.floor(Math.random() * grassPalette.length);
        ctx.fillStyle = grassPalette[idx];
        ctx.fillRect(x, y, cell, cell);
      }
    }
    // Crisp pixel grass blade flecks & tiny sunlit highlights
    for (let i = 0; i < 140; i++) {
      const px = Math.floor(Math.random() * 32) * 4;
      const py = Math.floor(Math.random() * 32) * 4;
      ctx.fillStyle = i % 3 === 0 ? '#91f263' : '#3a941d';
      ctx.fillRect(px, py, 4, 4);
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(175, 175);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAniso;
  return tex;
}

function createBrickTexture(maxAniso: number): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 128;
  const ctx = c.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#9c4e36';
    ctx.fillRect(0, 0, 128, 128);
    ctx.fillStyle = '#87412d';
    for (let y = 0; y < 128; y += 16) {
      const offset = (y / 16) % 2 === 0 ? 0 : 16;
      for (let x = -16; x < 128; x += 32) {
        ctx.fillRect(x + offset + 1, y + 1, 29, 13);
      }
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 2);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAniso;
  return tex;
}

function createWindowGridTexture(maxAniso: number): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 512;
  const ctx = c.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 0, 256, 512);
    for (let y = 16; y < 496; y += 32) {
      for (let x = 16; x < 240; x += 38) {
        const lit = Math.random() > 0.35;
        ctx.fillStyle = lit ? '#fde68a' : '#334155';
        ctx.fillRect(x, y, 24, 18);
      }
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAniso;
  return tex;
}

function createSignTexture(text: string, bg: string, fg: string): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 128;
  const ctx = c.getContext('2d');
  if (ctx) {
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, 512, 128);
    ctx.strokeStyle = fg;
    ctx.lineWidth = 6;
    ctx.strokeRect(8, 8, 496, 112);
    ctx.fillStyle = fg;
    ctx.font = 'bold 48px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, 256, 66);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createBarkTexture(maxAniso: number): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#4e3320';
    ctx.fillRect(0, 0, 256, 256);
    for (let x = 0; x < 256; x += 4) {
      const shade = 54 + Math.floor(Math.random() * 44);
      ctx.fillStyle = `rgb(${shade}, ${Math.floor(shade * 0.66)}, ${Math.floor(shade * 0.42)})`;
      ctx.fillRect(x, 0, 3, 256);
    }
    // Deep bark ridges & sunlit highlights
    for (let i = 0; i < 900; i++) {
      ctx.fillStyle = Math.random() > 0.45 ? 'rgba(24,14,8,0.52)' : 'rgba(148,112,78,0.3)';
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 2 + Math.random() * 3, 12 + Math.random() * 28);
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAniso;
  return tex;
}

function createFoliageTexture(maxAniso: number): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d');
  if (ctx) {
    // Rich sunlit botanical leaf canopy
    ctx.fillStyle = '#6ea844';
    ctx.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 2800; i++) {
      const lx = Math.random() * 256;
      const ly = Math.random() * 256;
      const lum = 115 + Math.floor(Math.random() * 140);
      const r = Math.floor(lum * 0.62);
      const g = Math.min(255, Math.floor(lum * 1.02));
      const b = Math.floor(lum * 0.36);
      ctx.fillStyle = `rgb(${r},${g},${b})`;
      ctx.beginPath();
      ctx.ellipse(lx, ly, 4.8 + Math.random() * 5.8, 2.5 + Math.random() * 3.0, Math.random() * Math.PI, 0, Math.PI * 2);
      ctx.fill();
    }
    // Crisp bright sunlit leaf clusters
    for (let i = 0; i < 520; i++) {
      ctx.fillStyle = 'rgba(220, 255, 165, 0.28)';
      ctx.beginPath();
      ctx.ellipse(Math.random() * 256, Math.random() * 256, 3.6, 1.8, Math.random() * Math.PI, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAniso;
  return tex;
}

function createGrassTuftTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 64;
  c.height = 64;
  const ctx = c.getContext('2d');
  if (ctx) {
    ctx.clearRect(0, 0, 64, 64);
    const blades = [
      { x: 10, h: 38, tilt: -5, col: '#48b826' },
      { x: 18, h: 48, tilt: -2, col: '#69df3c' },
      { x: 26, h: 42, tilt: 2, col: '#58cc30' },
      { x: 34, h: 54, tilt: -1, col: '#7ef24d' },
      { x: 42, h: 45, tilt: 3, col: '#5cd135' },
      { x: 50, h: 36, tilt: 5, col: '#46b224' },
    ];
    for (const b of blades) {
      ctx.fillStyle = b.col;
      ctx.beginPath();
      ctx.moveTo(b.x - 3, 64);
      ctx.lineTo(b.x + b.tilt, 64 - b.h);
      ctx.lineTo(b.x + 3, 64);
      ctx.closePath();
      ctx.fill();
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.magFilter = THREE.NearestFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createFlowerTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 64;
  c.height = 64;
  const ctx = c.getContext('2d');
  if (ctx) {
    ctx.clearRect(0, 0, 64, 64);
    // Crisp Minecraft-style green stem + bright blossom head
    ctx.fillStyle = '#47b027';
    ctx.fillRect(28, 30, 8, 34);
    ctx.fillRect(20, 42, 8, 6);
    ctx.fillRect(36, 38, 8, 6);

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(22, 12, 20, 20);
    ctx.fillRect(16, 18, 32, 8);
    ctx.fillRect(26, 8, 12, 28);
    ctx.fillStyle = '#fde047';
    ctx.fillRect(28, 18, 8, 8);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.magFilter = THREE.NearestFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function buildOrganicTreeGeometries(): { trunkGeo: THREE.BufferGeometry; canopyGeo: THREE.BufferGeometry } {
  // 1. Detailed organic trunk: flared buttress roots + slight natural curve + 5 forked primary branches
  const rootFlare = new THREE.CylinderGeometry(0.32, 0.68, 0.88, 10);
  rootFlare.translate(0, 0.44, 0);

  const mainTrunk = new THREE.CylinderGeometry(0.18, 0.34, 3.85, 10);
  mainTrunk.rotateZ(0.03);
  mainTrunk.translate(0.04, 2.15, 0);

  const branch1 = new THREE.CylinderGeometry(0.075, 0.16, 2.25, 7);
  branch1.rotateZ(-0.58);
  branch1.translate(0.68, 3.82, 0.14);

  const branch2 = new THREE.CylinderGeometry(0.07, 0.15, 2.1, 7);
  branch2.rotateZ(0.52);
  branch2.rotateY(1.9);
  branch2.translate(-0.52, 3.7, -0.4);

  const branch3 = new THREE.CylinderGeometry(0.068, 0.14, 2.0, 7);
  branch3.rotateX(0.54);
  branch3.translate(0.12, 3.6, 0.56);

  const branch4 = new THREE.CylinderGeometry(0.06, 0.12, 1.75, 7);
  branch4.rotateX(-0.52);
  branch4.rotateZ(0.24);
  branch4.translate(-0.24, 3.74, -0.54);

  const branch5 = new THREE.CylinderGeometry(0.06, 0.11, 1.5, 6);
  branch5.rotateZ(0.18);
  branch5.translate(-0.08, 4.35, 0.08);

  const trunkGeo =
    mergeGeometries([rootFlare, mainTrunk, branch1, branch2, branch3, branch4, branch5]) ??
    new THREE.CylinderGeometry(0.2, 0.36, 3.6, 10);
  rootFlare.dispose();
  mainTrunk.dispose();
  branch1.dispose();
  branch2.dispose();
  branch3.dispose();
  branch4.dispose();
  branch5.dispose();

  // 2. Lush 12-cluster layered organic canopy with sunlit apex & shaded boughs
  const clusterSpecs: Array<[number, number, number, number]> = [
    [0, 5.65, 0, 1.78],
    [0.15, 6.45, -0.1, 1.25],
    [0.65, 6.0, -0.4, 1.35],
    [-0.65, 5.9, 0.4, 1.32],
    [1.42, 4.65, 0.32, 1.42],
    [-1.34, 4.6, -0.42, 1.38],
    [0.24, 4.5, 1.35, 1.36],
    [-0.36, 4.65, -1.3, 1.32],
    [1.02, 5.25, -1.0, 1.22],
    [-1.05, 5.2, 1.0, 1.22],
    [0.98, 5.3, 0.95, 1.15],
    [-0.95, 5.35, -0.92, 1.15],
  ];
  const clusters: THREE.BufferGeometry[] = [];
  for (const [cx, cy, cz, rad] of clusterSpecs) {
    const g = new THREE.IcosahedronGeometry(rad, 1);
    const pos = g.attributes.position;
    const colors = new Float32Array(pos.count * 3);
    for (let i = 0; i < pos.count; i++) {
      const vx = pos.getX(i);
      const vy = pos.getY(i);
      const vz = pos.getZ(i);
      const wobble = 1 + Math.sin(vx * 3.6 + vy * 3.1) * 0.14 + Math.cos(vz * 4.1) * 0.12;
      const nx = vx * wobble;
      const ny = vy * wobble * 0.85;
      const nz = vz * wobble;
      pos.setXYZ(i, nx, ny, nz);

      const worldY = cy + ny;
      const ao = THREE.MathUtils.clamp(0.56 + ((worldY - 3.4) / 4.2) * 0.56, 0.5, 1.14);
      colors[i * 3] = ao;
      colors[i * 3 + 1] = ao * 1.02;
      colors[i * 3 + 2] = ao * 0.92;
    }
    g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    g.computeVertexNormals();
    g.translate(cx, cy, cz);
    clusters.push(g);
  }
  const canopyGeo = mergeGeometries(clusters) ?? new THREE.DodecahedronGeometry(2.3, 1);
  clusters.forEach((c) => c.dispose());

  return { trunkGeo, canopyGeo };
}

function createPedestrian(
  shirtColor: number,
  pantsColor: number,
  skinColor: number,
  variantIndex = 0
): PedestrianActor {
  const group = new THREE.Group();

  const skinMat = new THREE.MeshStandardMaterial({ color: skinColor, roughness: 0.65 });
  const shirtMat = new THREE.MeshStandardMaterial({ color: shirtColor, roughness: 0.72 });
  const accentStripeMat = new THREE.MeshStandardMaterial({
    color: variantIndex % 2 === 0 ? 0xf8fafc : 0xfacc15,
    roughness: 0.55,
  });
  const pantsMat = new THREE.MeshStandardMaterial({ color: pantsColor, roughness: 0.84 });
  const hairColors = [0x111318, 0x2c1b12, 0x3b2416, 0x18181b];
  const hairMat = new THREE.MeshStandardMaterial({
    color: hairColors[variantIndex % hairColors.length],
    roughness: 0.86,
  });
  const shoeMat = new THREE.MeshStandardMaterial({
    color: variantIndex % 3 === 0 ? 0x18181b : 0xf1f5f9,
    roughness: 0.55,
  });
  const soleMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.5 });
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.5 });

  // Pelvis / Belt waistband
  const belt = new THREE.Mesh(new THREE.CylinderGeometry(0.135, 0.142, 0.075, 10), darkMat);
  belt.position.set(0, 0.94, 0);
  belt.scale.set(1.08, 1, 0.76);
  group.add(belt);

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.145, 0.36, 6, 12), shirtMat);
  torso.position.set(0, 1.16, 0);
  torso.scale.set(1.08, 1, 0.74);
  torso.castShadow = true;
  group.add(torso);

  // Chest stripe / collar detail
  const chestStripe = new THREE.Mesh(new THREE.BoxGeometry(0.29, 0.05, 0.22), accentStripeMat);
  chestStripe.position.set(0, 1.24, 0);
  group.add(chestStripe);

  const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.068, 0.08, 0.05, 10), shirtMat);
  collar.position.set(0, 1.40, 0);
  group.add(collar);

  // Casual backpack or crossbody sling on ~50% of pedestrians
  if (variantIndex % 2 === 0) {
    const bag = new THREE.Mesh(new THREE.BoxGeometry(0.21, 0.26, 0.1), darkMat);
    bag.position.set(0, 1.18, -0.14);
    bag.castShadow = true;
    group.add(bag);
  }

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.125, 14, 12), skinMat);
  head.position.set(0, 1.56, 0);
  head.castShadow = true;
  group.add(head);

  // Expressive eyes + eyebrows
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
  for (const side of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.015, 6, 6), eyeMat);
    eye.position.set(side * 0.044, 1.57, 0.115);
    group.add(eye);
  }

  // Sunglasses on some pedestrians
  if (variantIndex % 3 === 1) {
    const shades = new THREE.Mesh(
      new THREE.BoxGeometry(0.15, 0.032, 0.03),
      new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.85, roughness: 0.12 })
    );
    shades.position.set(0, 1.575, 0.122);
    group.add(shades);
  }

  // Hair styles & Baseball Cap variety
  const hair = new THREE.Mesh(
    new THREE.SphereGeometry(0.132, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.58),
    hairMat
  );
  hair.position.set(0, 1.58, -0.01);
  group.add(hair);

  if (variantIndex % 4 === 0) {
    const capMat = new THREE.MeshStandardMaterial({
      color: variantIndex % 8 === 0 ? 0xdc2626 : 0x1d4ed8,
      roughness: 0.7,
    });
    const capDome = new THREE.Mesh(
      new THREE.SphereGeometry(0.138, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.5),
      capMat
    );
    capDome.position.set(0, 1.59, 0);
    group.add(capDome);
    const capBrim = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.018, 0.12), capMat);
    capBrim.position.set(0, 1.605, 0.125);
    capBrim.rotation.x = 0.12;
    group.add(capBrim);
  }

  const makeLimb = (isArm: boolean, side: -1 | 1): THREE.Group => {
    const pivot = new THREE.Group();
    if (isArm) {
      pivot.position.set(side * 0.195, 1.36, 0);
      const sleeve = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.14, 4, 8), shirtMat);
      sleeve.position.set(0, -0.10, 0);
      pivot.add(sleeve);
      const forearmMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.04, 0.25, 4, 8), skinMat);
      forearmMesh.position.set(0, -0.28, 0);
      forearmMesh.castShadow = true;
      pivot.add(forearmMesh);
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.042, 8, 8), skinMat);
      hand.position.set(0, -0.44, 0);
      pivot.add(hand);
    } else {
      pivot.position.set(side * 0.088, 0.88, 0);
      const legMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.058, 0.56, 5, 8), pantsMat);
      legMesh.position.set(0, -0.35, 0);
      legMesh.castShadow = true;
      pivot.add(legMesh);
      const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.058, 0.175), shoeMat);
      shoe.position.set(0, -0.78, 0.032);
      pivot.add(shoe);
      const sole = new THREE.Mesh(new THREE.BoxGeometry(0.094, 0.02, 0.182), soleMat);
      sole.position.set(0, -0.805, 0.032);
      pivot.add(sole);
    }
    return pivot;
  };

  const leftArm = makeLimb(true, -1);
  const rightArm = makeLimb(true, 1);
  const leftLeg = makeLimb(false, -1);
  const rightLeg = makeLimb(false, 1);

  group.add(leftArm, rightArm, leftLeg, rightLeg);

  return {
    group,
    leftLeg,
    rightLeg,
    leftArm,
    rightArm,
    x: 0,
    z: 0,
    startX: 0,
    startZ: 0,
    endX: 0,
    endZ: 0,
    t: Math.random(),
    dir: 1,
    speed: 1.35 + Math.random() * 0.5,
  };
}

export function buildOpenWorld(scene: THREE.Scene, maxAniso: number, isSoftwareGl: boolean): WorldHandles {
  const worldGroup = new THREE.Group();
  scene.add(worldGroup);

  const colliders: ColliderBox[] = [];
  const asphaltMaterials: THREE.MeshStandardMaterial[] = [];
  const windowMaterials: THREE.MeshStandardMaterial[] = [];
  const lampBulbMaterials: THREE.MeshStandardMaterial[] = [];
  const lampLights: THREE.PointLight[] = [];
  const houseLights: THREE.PointLight[] = [];
  const pedestrians: PedestrianActor[] = [];
  const disposables: Array<{ dispose: () => void }> = [];

  // 1. Procedural 1200x1200 Terrain Mesh (covers 1000x1000 playable + natural horizon skirt)
  const terrainGeo = new THREE.PlaneGeometry(1400, 1400, 72, 72);
  terrainGeo.rotateX(-Math.PI / 2);
  const posAttr = terrainGeo.attributes.position;
  for (let i = 0; i < posAttr.count; i++) {
    const vx = posAttr.getX(i);
    const vz = posAttr.getZ(i);
    posAttr.setY(i, groundHeightAt(vx, vz));
  }
  terrainGeo.computeVertexNormals();
  const terrainTex = createTerrainTexture(maxAniso);
  const terrainMat = new THREE.MeshStandardMaterial({
    map: terrainTex,
    roughness: 0.94,
    metalness: 0.02,
  });
  const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
  terrainMesh.receiveShadow = true;
  worldGroup.add(terrainMesh);
  disposables.push(terrainGeo, terrainTex, terrainMat);

  // 2. Road Network (flat + sloped ramp ribbons)
  const asphaltTex = createAsphaltTexture(maxAniso);
  const roadMatMain = new THREE.MeshStandardMaterial({
    map: asphaltTex,
    roughness: 0.85,
    metalness: 0.08,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  asphaltMaterials.push(roadMatMain);
  disposables.push(asphaltTex, roadMatMain);

  const addFlatRoad = (cx: number, cz: number, width: number, length: number, rotY = 0) => {
    const tex = asphaltTex.clone();
    tex.needsUpdate = true;
    tex.repeat.set(1, Math.max(1, Math.round(length / 18)));
    const mat = roadMatMain.clone();
    mat.map = tex;
    asphaltMaterials.push(mat);

    const geo = new THREE.PlaneGeometry(width, length);
    geo.rotateX(-Math.PI / 2);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(cx, 0.035, cz);
    mesh.rotation.y = rotY;
    mesh.receiveShadow = true;
    worldGroup.add(mesh);
    disposables.push(geo, tex, mat);
  };

  // Avenida Central (East-West) & Norte-Sul
  addFlatRoad(0, 0, 16, 940, Math.PI / 2);
  addFlatRoad(0, 0, 14, 940, 0);

  // Centro da Cidade Road Grid
  addFlatRoad(140, 0, 12, 620, 0);
  addFlatRoad(240, 0, 14, 620, 0);
  addFlatRoad(340, 0, 12, 620, 0);
  addFlatRoad(240, -140, 12, 340, Math.PI / 2);
  addFlatRoad(240, 140, 12, 340, Math.PI / 2);
  addFlatRoad(240, -260, 12, 340, Math.PI / 2);
  addFlatRoad(240, 260, 12, 340, Math.PI / 2);

  // Perimetral Ring Segments
  addFlatRoad(0, -440, 12, 890, Math.PI / 2);
  addFlatRoad(0, 440, 12, 890, Math.PI / 2);
  addFlatRoad(-440, 0, 12, 890, 0);
  addFlatRoad(440, 0, 12, 890, 0);

  // Visual Lombadas (Speed Bumps) on Avenida Central
  const lombadaMat = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.72 });
  const lombadaGeo = new THREE.CylinderGeometry(0.45, 0.9, 15.6, 10, 1, false, 0, Math.PI);
  lombadaGeo.rotateZ(Math.PI / 2);
  lombadaGeo.scale(1, 0.22, 1.35);
  disposables.push(lombadaMat, lombadaGeo);
  for (const lx of LOMBADA_X_POSITIONS) {
    const bumpMesh = new THREE.Mesh(lombadaGeo, lombadaMat);
    bumpMesh.position.set(lx, 0.04, 0);
    bumpMesh.rotation.y = Math.PI / 2;
    bumpMesh.receiveShadow = true;
    worldGroup.add(bumpMesh);
  }

  // Crosswalks (Faixas de Pedestre) & Speed Sign along Avenida Central
  const stripeMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.8 });
  const stripeGeo = new THREE.PlaneGeometry(2.6, 0.75);
  stripeGeo.rotateX(-Math.PI / 2);
  disposables.push(stripeMat, stripeGeo);
  for (const cx of [-20, 20, 140, 240]) {
    for (let s = -5; s <= 5; s += 2) {
      const cw = new THREE.Mesh(stripeGeo, stripeMat);
      cw.position.set(cx, 0.045, s * 1.15);
      worldGroup.add(cw);
    }
  }

  const speedSignTex = createSignTexture('140 KM/H · GRAU', '#fef08a', '#0f172a');
  const speedSignPole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.8, 8), roadMatMain);
  speedSignPole.position.set(16, 1.4, -9.2);
  worldGroup.add(speedSignPole);
  const speedSignBoard = new THREE.Mesh(
    new THREE.BoxGeometry(1.9, 0.72, 0.08),
    new THREE.MeshBasicMaterial({ map: speedSignTex })
  );
  speedSignBoard.position.set(16, 2.55, -9.2);
  speedSignBoard.rotation.y = -Math.PI / 2;
  worldGroup.add(speedSignBoard);
  disposables.push(speedSignTex);

  // 3. CASA PRINCIPAL (Main House at x=0, z=-25, driveway opening to z=0)
  const mainHouse = new THREE.Group();
  mainHouse.position.set(0, 0, -26);
  worldGroup.add(mainHouse);

  const concreteMat = new THREE.MeshStandardMaterial({ color: 0x9ca3af, roughness: 0.9 });
  const mainWallMat = new THREE.MeshStandardMaterial({ color: 0xf1ece1, roughness: 0.8 });
  const trimWallMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.72 });
  const roofMat = new THREE.MeshStandardMaterial({ color: 0x7c2d12, roughness: 0.75 });
  const glassWinMat = new THREE.MeshStandardMaterial({
    color: 0x93c5fd,
    emissive: 0xfbbf24,
    emissiveIntensity: 0.12,
    roughness: 0.15,
    metalness: 0.4,
  });
  windowMaterials.push(glassWinMat);
  disposables.push(concreteMat, mainWallMat, trimWallMat, roofMat, glassWinMat);

  // Driveway apron leading out to Avenida Central
  const driveway = new THREE.Mesh(new THREE.BoxGeometry(10, 0.08, 22), concreteMat);
  driveway.position.set(0, 0.02, 13);
  driveway.receiveShadow = true;
  mainHouse.add(driveway);

  // Raised property yard pad
  const yardPad = new THREE.Mesh(new THREE.BoxGeometry(24, 0.16, 18), concreteMat);
  yardPad.position.set(0, 0.08, 0);
  yardPad.receiveShadow = true;
  mainHouse.add(yardPad);

  // Hollow ground-floor room walls (so the player can open the door and enter inside!)
  const interiorWallMat = new THREE.MeshStandardMaterial({ color: 0xf8f5ef, roughness: 0.85 });
  const floorTileMat = new THREE.MeshStandardMaterial({ color: 0xd6cfc2, roughness: 0.52 });
  const woodFurnMat = new THREE.MeshStandardMaterial({ color: 0x5c3a21, roughness: 0.68 });
  const sofaMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.85 });
  const rugMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.92 });
  const tvScreenMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    emissive: 0x38bdf8,
    emissiveIntensity: 0.45,
    roughness: 0.2,
  });
  const applianceMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.45, roughness: 0.35 });
  disposables.push(interiorWallMat, floorTileMat, woodFurnMat, sofaMat, rugMat, tvScreenMat, applianceMat);

  // Back wall: local z = -6.32 (world -32.32), span x [-9.5..4.5]
  const backWall = new THREE.Mesh(new THREE.BoxGeometry(14.0, 3.8, 0.36), mainWallMat);
  backWall.position.set(-2.5, 2.0, -6.32);
  backWall.castShadow = !isSoftwareGl;
  backWall.receiveShadow = true;
  mainHouse.add(backWall);

  // Left & Right walls
  const leftWall = new THREE.Mesh(new THREE.BoxGeometry(0.36, 3.8, 10.0), mainWallMat);
  leftWall.position.set(-9.32, 2.0, -1.5);
  leftWall.castShadow = !isSoftwareGl;
  leftWall.receiveShadow = true;
  mainHouse.add(leftWall);

  const rightWall = new THREE.Mesh(new THREE.BoxGeometry(0.36, 3.8, 10.0), mainWallMat);
  rightWall.position.set(4.32, 2.0, -1.5);
  rightWall.castShadow = !isSoftwareGl;
  rightWall.receiveShadow = true;
  mainHouse.add(rightWall);

  // Front wall split around doorway [-3.4 .. -1.6] at local z = +3.32 (world -22.68)
  const frontLeftWall = new THREE.Mesh(new THREE.BoxGeometry(6.1, 3.8, 0.36), mainWallMat);
  frontLeftWall.position.set(-6.45, 2.0, 3.32);
  frontLeftWall.castShadow = !isSoftwareGl;
  frontLeftWall.receiveShadow = true;
  mainHouse.add(frontLeftWall);

  const frontRightWall = new THREE.Mesh(new THREE.BoxGeometry(6.1, 3.8, 0.36), mainWallMat);
  frontRightWall.position.set(1.45, 2.0, 3.32);
  frontRightWall.castShadow = !isSoftwareGl;
  frontRightWall.receiveShadow = true;
  mainHouse.add(frontRightWall);

  const frontLintel = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.15, 0.36), mainWallMat);
  frontLintel.position.set(-2.5, 3.32, 3.32);
  mainHouse.add(frontLintel);

  // Interior ceramic floor & ceiling slab
  const interiorFloor = new THREE.Mesh(new THREE.BoxGeometry(13.4, 0.04, 9.4), floorTileMat);
  interiorFloor.position.set(-2.5, 0.17, -1.5);
  interiorFloor.receiveShadow = true;
  mainHouse.add(interiorFloor);

  const interiorCeiling = new THREE.Mesh(new THREE.BoxGeometry(13.8, 0.2, 9.8), interiorWallMat);
  interiorCeiling.position.set(-2.5, 3.82, -1.5);
  mainHouse.add(interiorCeiling);

  // Living room & kitchen interior furniture
  const rug = new THREE.Mesh(new THREE.BoxGeometry(3.8, 0.02, 2.8), rugMat);
  rug.position.set(-5.2, 0.2, -1.4);
  mainHouse.add(rug);

  const sofaBase = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.44, 2.6), sofaMat);
  sofaBase.position.set(-7.6, 0.4, -1.4);
  mainHouse.add(sofaBase);
  const sofaBack = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.55, 2.6), sofaMat);
  sofaBack.position.set(-7.98, 0.72, -1.4);
  mainHouse.add(sofaBack);

  const coffeeTable = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.42, 1.35), woodFurnMat);
  coffeeTable.position.set(-5.7, 0.4, -1.4);
  mainHouse.add(coffeeTable);

  const tvStand = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.62, 0.55), woodFurnMat);
  tvStand.position.set(-5.2, 0.5, -5.65);
  mainHouse.add(tvStand);
  const tvScreen = new THREE.Mesh(new THREE.BoxGeometry(1.55, 0.9, 0.08), tvScreenMat);
  tvScreen.position.set(-5.2, 1.32, -5.7);
  mainHouse.add(tvScreen);

  const kitchenCounter = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.92, 0.8), woodFurnMat);
  kitchenCounter.position.set(2.1, 0.64, -5.6);
  mainHouse.add(kitchenCounter);
  const fridge = new THREE.Mesh(new THREE.BoxGeometry(0.95, 2.05, 0.9), applianceMat);
  fridge.position.set(3.45, 1.2, -4.1);
  mainHouse.add(fridge);

  const bedFrame = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.48, 1.5), woodFurnMat);
  bedFrame.position.set(-7.8, 0.42, -5.1);
  mainHouse.add(bedFrame);
  const mattress = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.24, 1.38), interiorWallMat);
  mattress.position.set(-7.8, 0.72, -5.1);
  mainHouse.add(mattress);

  // Upper 2nd floor exterior block
  const upperBody = new THREE.Mesh(new THREE.BoxGeometry(11, 3.4, 8.5), mainWallMat);
  upperBody.position.set(-3.2, 5.4, -1.5);
  upperBody.castShadow = !isSoftwareGl;
  upperBody.receiveShadow = true;
  mainHouse.add(upperBody);

  // Garage / Oficina Bay for Moto Win
  const garageRoof = new THREE.Mesh(new THREE.BoxGeometry(7.2, 0.35, 9.4), trimWallMat);
  garageRoof.position.set(7.6, 3.55, -0.8);
  garageRoof.castShadow = !isSoftwareGl;
  mainHouse.add(garageRoof);

  const garageBack = new THREE.Mesh(new THREE.BoxGeometry(7.0, 3.5, 0.4), trimWallMat);
  garageBack.position.set(7.6, 1.85, -5.2);
  mainHouse.add(garageBack);

  for (const px of [4.3, 10.9]) {
    const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.4, 3.5, 0.4), trimWallMat);
    pillar.position.set(px, 1.85, 3.5);
    pillar.castShadow = !isSoftwareGl;
    mainHouse.add(pillar);
  }

  // Main pitched roof + water tank
  const mainRoof = new THREE.Mesh(new THREE.ConeGeometry(9.6, 2.5, 4), roofMat);
  mainRoof.position.set(-3.2, 8.3, -1.5);
  mainRoof.rotation.y = Math.PI / 4;
  mainRoof.castShadow = !isSoftwareGl;
  mainHouse.add(mainRoof);

  const waterTank = new THREE.Mesh(
    new THREE.CylinderGeometry(0.75, 0.72, 1.2, 14),
    new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.5 })
  );
  waterTank.position.set(1.2, 4.5, -3.5);
  mainHouse.add(waterTank);

  // Hinged Front Door (opens inward smoothly when clicked!)
  const doorMat = new THREE.MeshStandardMaterial({ color: 0x5b260b, roughness: 0.58 });
  const doorHandleMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9, roughness: 0.2 });
  disposables.push(doorMat, doorHandleMat);

  const doorPivot = new THREE.Group();
  doorPivot.position.set(-3.4, 0.18, 3.32);
  mainHouse.add(doorPivot);

  const doorLeaf = new THREE.Mesh(new THREE.BoxGeometry(1.78, 2.54, 0.12), doorMat);
  doorLeaf.position.set(0.9, 1.27, 0);
  doorLeaf.castShadow = !isSoftwareGl;
  doorPivot.add(doorLeaf);

  const doorFrameTop = new THREE.Mesh(new THREE.BoxGeometry(1.92, 0.12, 0.42), woodFurnMat);
  doorFrameTop.position.set(-2.5, 2.75, 3.32);
  mainHouse.add(doorFrameTop);

  for (const side of [-1, 1]) {
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.05, 0.05), doorHandleMat);
    handle.position.set(1.56, 1.15, side * 0.09);
    doorPivot.add(handle);
  }

  // Front Windows
  for (const wx of [-6.8, -4.6, 0.2, 2.2]) {
    const win = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.3, 0.15), glassWinMat);
    win.position.set(wx, 2.2, 3.55);
    mainHouse.add(win);
  }
  for (const wx of [-6.2, -3.2, -0.2]) {
    const win2 = new THREE.Mesh(new THREE.BoxGeometry(1.5, 1.3, 0.15), glassWinMat);
    win2.position.set(wx, 5.4, 2.8);
    mainHouse.add(win2);
  }

  // Casa Principal Signboard
  const signTex = createSignTexture('CASA PRINCIPAL', '#0f172a', '#f59e0b');
  const signMesh = new THREE.Mesh(
    new THREE.BoxGeometry(5.2, 1.1, 0.2),
    new THREE.MeshBasicMaterial({ map: signTex })
  );
  signMesh.position.set(7.6, 4.3, 3.6);
  mainHouse.add(signMesh);
  disposables.push(signTex);

  // Perimeter low wall (open at driveway center)
  for (const wx of [-8.8, 9.2]) {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(6.8, 1.4, 0.4), mainWallMat);
    wall.position.set(wx, 0.75, 8.8);
    mainHouse.add(wall);
  }

  // Porch & Interior warm lights
  const housePorchLight = new THREE.PointLight(0xffcf75, 0, 28, 1.6);
  housePorchLight.position.set(2, 4.2, -19);
  worldGroup.add(housePorchLight);
  houseLights.push(housePorchLight);

  const houseInteriorLight = new THREE.PointLight(0xffdf9e, 4.5, 22, 1.4);
  houseInteriorLight.position.set(-2.5, 3.3, -27.5);
  worldGroup.add(houseInteriorLight);

  let doorOpen = false;
  let doorAngle = 0;

  const doorCollider: ColliderBox = { minX: -3.45, maxX: -1.55, minZ: -22.92, maxZ: -22.42, maxY: 3.0 };

  // Split house colliders around doorway so interior is freely walkable when door opens!
  colliders.push({ minX: -9.6, maxX: 4.6, minZ: -32.6, maxZ: -32.0, maxY: 9 }); // Back wall
  colliders.push({ minX: -9.6, maxX: -9.0, minZ: -32.6, maxZ: -22.4, maxY: 9 }); // Left wall
  colliders.push({ minX: 4.0, maxX: 4.6, minZ: -32.6, maxZ: -22.4, maxY: 9 }); // Right wall
  colliders.push({ minX: -9.6, maxX: -3.4, minZ: -22.95, maxZ: -22.4, maxY: 9 }); // Front-left wall
  colliders.push({ minX: -1.6, maxX: 4.6, minZ: -22.95, maxZ: -22.4, maxY: 9 }); // Front-right wall
  colliders.push({ minX: 4.5, maxX: 11.5, minZ: -33.0, maxZ: -30.5, maxY: 4 }); // Garage back
  // Interior furniture colliders
  colliders.push({ minX: -8.3, maxX: -7.0, minZ: -28.8, maxZ: -26.0, maxY: 1.5 }); // Sofa
  colliders.push({ minX: -8.9, maxX: -6.7, minZ: -31.9, maxZ: -30.2, maxY: 1.2 }); // Bed
  colliders.push({ minX: 0.7, maxX: 4.0, minZ: -32.0, maxZ: -29.5, maxY: 2.2 }); // Kitchen & fridge

  // 4. CENTRO DA CIDADE (Skyscrapers, Plazas, Streetlamps)
  const winGridTex = createWindowGridTexture(maxAniso);
  const towerGlassMat = new THREE.MeshStandardMaterial({
    map: winGridTex,
    emissiveMap: winGridTex,
    emissive: 0xfde68a,
    emissiveIntensity: 0.08,
    roughness: 0.28,
    metalness: 0.55,
  });
  windowMaterials.push(towerGlassMat);
  disposables.push(winGridTex, towerGlassMat);

  const towerColors = [0x334155, 0x475569, 0x1e293b, 0x64748b, 0x3b4252];
  const towerMats = towerColors.map((col) => new THREE.MeshStandardMaterial({ color: col, roughness: 0.55, metalness: 0.35 }));
  towerMats.forEach((m) => disposables.push(m));

  // City blocks around Centro (x: 115..410, z: -240..240)
  const cityBlockCenters: Array<[number, number]> = [
    [190, -70], [290, -70], [390, -70],
    [190, 70], [290, 70], [390, 70],
    [190, -200], [290, -200], [390, -200],
    [190, 200], [290, 200],
  ];

  cityBlockCenters.forEach(([bx, bz], idx) => {
    // Sidewalk block base
    const sidewalk = new THREE.Mesh(new THREE.BoxGeometry(64, 0.22, 82), concreteMat);
    sidewalk.position.set(bx, 0.11, bz);
    sidewalk.receiveShadow = true;
    worldGroup.add(sidewalk);

    // Plaza monument at (290, -70)
    if (bx === 290 && bz === -70) {
      const ped = new THREE.Mesh(new THREE.CylinderGeometry(4, 5, 2.2, 12), concreteMat);
      ped.position.set(bx, 1.2, bz);
      worldGroup.add(ped);
      const obelisk = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 1.5, 14, 4), towerMats[0]);
      obelisk.position.set(bx, 9, bz);
      obelisk.castShadow = true;
      worldGroup.add(obelisk);
      colliders.push({ minX: bx - 4.5, maxX: bx + 4.5, minZ: bz - 4.5, maxZ: bz + 4.5, maxY: 16 });
      return;
    }

    // 2 Towers per block
    for (let t = 0; t < 2; t++) {
      const tx = bx + (t === 0 ? -13 : 13);
      const tz = bz + ((idx + t) % 2 === 0 ? -14 : 14);
      const w = 18 + ((idx * 5 + t * 7) % 9);
      const d = 18 + ((idx * 3 + t * 11) % 9);
      const h = 24 + ((idx * 13 + t * 17) % 42);

      const core = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), towerMats[(idx + t) % towerMats.length]);
      core.position.set(tx, h / 2 + 0.2, tz);
      core.castShadow = !isSoftwareGl;
      core.receiveShadow = true;
      worldGroup.add(core);

      const facade = new THREE.Mesh(new THREE.BoxGeometry(w + 0.25, h - 2.5, d + 0.25), towerGlassMat);
      facade.position.set(tx, h / 2 + 0.8, tz);
      worldGroup.add(facade);

      colliders.push({
        minX: tx - w / 2,
        maxX: tx + w / 2,
        minZ: tz - d / 2,
        maxZ: tz + d / 2,
        maxY: h,
      });
    }
  });

  // 5. FAVELAS (Morro da Vitória NW & Vila Alta SW) — 130+ stacked brick & colorful laje houses
  const brickTex = createBrickTexture(maxAniso);
  const favelaPalette = [0xc26d4a, 0xd97706, 0x0d9488, 0xe11d48, 0xeab308, 0x9ca3af, 0x2563eb];
  const brickMat = new THREE.MeshStandardMaterial({ map: brickTex, roughness: 0.92 });
  const favelaMats = [brickMat, ...favelaPalette.map((c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.86 }))];
  const favelaWinMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    emissive: 0xfde047,
    emissiveIntensity: 0.1,
    roughness: 0.3,
  });
  windowMaterials.push(favelaWinMat);
  disposables.push(brickTex, ...favelaMats);

  const favelaClusters: Array<{ cx: number; cz: number; count: number; spreadX: number; spreadZ: number }> = [
    { cx: -245, cz: -210, count: 78, spreadX: 145, spreadZ: 135 },
    { cx: -275, cz: 245, count: 55, spreadX: 125, spreadZ: 120 },
  ];

  let seed = 4219;
  const rand = () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296;
    return seed / 4294967296;
  };

  favelaClusters.forEach((cluster) => {
    let placed = 0;
    let attempts = 0;
    while (placed < cluster.count && attempts < cluster.count * 5) {
      attempts++;
      const hx = cluster.cx + (rand() - 0.5) * 2 * cluster.spreadX;
      const hz = cluster.cz + (rand() - 0.5) * 2 * cluster.spreadZ;
      // Leave alleys open along main favela corridors
      if (Math.abs(hx + 240) < 7 || Math.abs(hz + 210) < 7 || Math.abs(hz - 245) < 7) continue;

      const w = 4.6 + rand() * 3.4;
      const d = 4.6 + rand() * 3.4;
      const floors = 1 + Math.floor(rand() * 3);
      const h = floors * 2.9;

      // Check spacing against nearby colliders so houses cluster tightly without awkward overlapping
      const tooClose = colliders.some(
        (c) => hx + w / 2 + 1.4 > c.minX && hx - w / 2 - 1.4 < c.maxX && hz + d / 2 + 1.4 > c.minZ && hz - d / 2 - 1.4 < c.maxZ
      );
      if (tooClose) continue;

      const gy = groundHeightAt(hx, hz);
      const mat = favelaMats[Math.floor(rand() * favelaMats.length)];
      const house = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      house.position.set(hx, gy + h / 2 - 0.3, hz);
      house.castShadow = false;
      house.receiveShadow = true;
      worldGroup.add(house);

      // Concrete laje slab + blue water tank
      const laje = new THREE.Mesh(new THREE.BoxGeometry(w + 0.35, 0.25, d + 0.35), concreteMat);
      laje.position.set(hx, gy + h - 0.2, hz);
      worldGroup.add(laje);

      if (rand() > 0.35) {
        const tank = new THREE.Mesh(
          new THREE.CylinderGeometry(0.55, 0.52, 0.85, 10),
          new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.45 })
        );
        tank.position.set(hx + (rand() - 0.5) * 1.4, gy + h + 0.35, hz + (rand() - 0.5) * 1.4);
        worldGroup.add(tank);
      }

      // Small lit window patch
      const win = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.8, d + 0.12), favelaWinMat);
      win.position.set(hx, gy + 1.6, hz);
      worldGroup.add(win);

      colliders.push({
        minX: hx - w / 2,
        maxX: hx + w / 2,
        minZ: hz - d / 2,
        maxZ: hz + d / 2,
        maxY: gy + h,
      });
      placed++;
    }
  });

  // 6. VÁRIAS CASAS (Residential Houses scattered around South & East-South & West)
  const resWallColors = [0xf8fafc, 0xfef3c7, 0xe0f2fe, 0xfce7f3, 0xdcfce7, 0xfed7aa];
  const resRoofColors = [0x9a3412, 0x7f1d1d, 0x334155, 0xb45309];
  const resWallMats = resWallColors.map((c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.82 }));
  const resRoofMats = resRoofColors.map((c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.78 }));
  disposables.push(...resWallMats, ...resRoofMats);

  const residentialZones: Array<[number, number]> = [
    [-85, 65], [-55, 65], [55, 65], [85, 65],
    [-85, 130], [-55, 130], [55, 130], [85, 130],
    [-85, 200], [-55, 200], [55, 200], [85, 200],
    [-85, 270], [55, 270], [85, 270],
    [-95, -65], [-60, -65], [60, -65], [95, -65],
    [-60, -135], [60, -135], [60, -210], [-60, -210],
    [160, 325], [220, 325], [280, 325], [340, 325],
    [160, -325], [220, -325], [280, -325], [340, -325],
    [-125, -40], [-165, -40], [-210, -40], [-255, -40],
    [-125, 45], [-165, 45], [-210, 45], [-255, 45],
  ];

  residentialZones.forEach(([rx, rz], idx) => {
    const gy = groundHeightAt(rx, rz);
    const w = 9 + (idx % 3) * 1.5;
    const d = 8 + ((idx + 1) % 3) * 1.4;
    const h = 3.4 + (idx % 2) * 1.6;

    const houseGroup = new THREE.Group();
    houseGroup.position.set(rx, gy, rz);
    if (rz < 0) houseGroup.rotation.y = Math.PI;
    worldGroup.add(houseGroup);

    const body = new THREE.Mesh(
      new THREE.BoxGeometry(w, h, d),
      resWallMats[idx % resWallMats.length]
    );
    body.position.set(0, h / 2, 0);
    body.castShadow = false;
    body.receiveShadow = true;
    houseGroup.add(body);

    const roof = new THREE.Mesh(
      new THREE.ConeGeometry(Math.max(w, d) * 0.78, 2.2, 4),
      resRoofMats[idx % resRoofMats.length]
    );
    roof.position.set(0, h + 1.05, 0);
    roof.rotation.y = Math.PI / 4;
    houseGroup.add(roof);

    const win = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.1, d + 0.14), favelaWinMat);
    win.position.set(0, 1.8, 0);
    houseGroup.add(win);

    colliders.push({
      minX: rx - w / 2,
      maxX: rx + w / 2,
      minZ: rz - d / 2,
      maxZ: rz + d / 2,
      maxY: gy + h + 2,
    });
  });

  // 7. STREETLAMPS (along Avenida Central, Norte-Sul, and Centro)
  const poleMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.75, roughness: 0.35 });
  const bulbMat = new THREE.MeshStandardMaterial({
    color: 0xfef3c7,
    emissive: 0xfbbf24,
    emissiveIntensity: 0.2,
    roughness: 0.2,
  });
  lampBulbMaterials.push(bulbMat);
  disposables.push(poleMat, bulbMat);

  const lampCoords: Array<[number, number, boolean]> = [];
  for (let x = -380; x <= 380; x += 65) {
    if (Math.abs(x) < 25) continue;
    lampCoords.push([x, 10.5, Math.abs(x) < 280 && x % 130 === 0]);
    lampCoords.push([x, -10.5, false]);
  }
  for (let z = -340; z <= 340; z += 75) {
    if (Math.abs(z) < 25) continue;
    lampCoords.push([231, z, z % 150 === 0]);
    lampCoords.push([10, z, false]);
  }

  lampCoords.forEach(([lx, lz, addLight]) => {
    const gy = groundHeightAt(lx, lz);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.15, 6.2, 8), poleMat);
    pole.position.set(lx, gy + 3.1, lz);
    worldGroup.add(pole);

    const bulb = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.18, 0.35), bulbMat);
    bulb.position.set(lx, gy + 6.2, lz);
    worldGroup.add(bulb);

    if (addLight && !isSoftwareGl && lampLights.length < 2) {
      const pt = new THREE.PointLight(0xffcf70, 0, 38, 1.7);
      pt.position.set(lx, gy + 5.8, lz);
      worldGroup.add(pt);
      lampLights.push(pt);
    }
  });

  // 8. ÁRVORES REALISTAS COM FÍSICA (240 Árvores Botânicas com Balanço de Vento, Mola de Impacto, Queda e Folhas)
  const treeCount = 240;
  const { trunkGeo, canopyGeo } = buildOrganicTreeGeometries();
  const barkTex = createBarkTexture(maxAniso);
  const foliageTex = createFoliageTexture(maxAniso);

  const trunkMat = new THREE.MeshStandardMaterial({
    map: barkTex,
    roughness: 0.92,
    metalness: 0.02,
  });
  const canopyMat = new THREE.MeshStandardMaterial({
    map: foliageTex,
    color: 0xffffff,
    vertexColors: true,
    roughness: 0.82,
    metalness: 0.02,
  });

  const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
  const canopyInst = new THREE.InstancedMesh(canopyGeo, canopyMat, treeCount);
  trunkInst.castShadow = !isSoftwareGl;
  trunkInst.receiveShadow = true;
  canopyInst.castShadow = !isSoftwareGl;
  canopyInst.receiveShadow = true;

  const trees: TreePhysicsActor[] = [];
  const dummy = new THREE.Object3D();
  const colorTemp = new THREE.Color();
  let tIdx = 0;

  const tryPlaceTree = (tx: number, tz: number) => {
    if (tIdx >= treeCount) return;
    if (Math.abs(tz) < 13 || Math.abs(tx) < 12) return;
    if (Math.abs(tx - 140) < 10 || Math.abs(tx - 240) < 11 || Math.abs(tx - 340) < 10) return;
    if (Math.abs(tx) < 28 && tz > -42 && tz < 12) return;
    const hitBuilding = colliders.some(
      (c) => tx + 2.4 > c.minX && tx - 2.4 < c.maxX && tz + 2.4 > c.minZ && tz - 2.4 < c.maxZ
    );
    if (hitBuilding) return;
    const hitTree = trees.some((tr) => Math.hypot(tr.x - tx, tr.z - tz) < 5.5);
    if (hitTree) return;

    const gy = groundHeightAt(tx, tz);
    const scaleXZ = 0.85 + rand() * 0.34;
    const scaleY = scaleXZ * (0.9 + rand() * 0.24);
    const rotY = rand() * Math.PI * 2;

    dummy.position.set(tx, gy - 0.12, tz);
    dummy.rotation.set(0, rotY, 0);
    dummy.scale.set(scaleXZ, scaleY, scaleXZ);
    dummy.updateMatrix();

    trunkInst.setMatrixAt(tIdx, dummy.matrix);
    canopyInst.setMatrixAt(tIdx, dummy.matrix);

    // Vibrant tropical emerald-lime palette + golden, pink/purple Ipês & Flamboyant
    const treeHueRoll = rand();
    if (treeHueRoll > 0.94) {
      colorTemp.setHSL(0.12 + rand() * 0.03, 0.88, 0.72); // Ipê Amarelo
    } else if (treeHueRoll > 0.89) {
      colorTemp.setHSL(0.84 + rand() * 0.04, 0.72, 0.72); // Ipê Rosa / Roxo
    } else if (treeHueRoll > 0.85) {
      colorTemp.setHSL(0.04 + rand() * 0.03, 0.86, 0.68); // Flamboyant
    } else {
      colorTemp.setHSL(0.26 + rand() * 0.07, 0.62 + rand() * 0.2, 0.6 + rand() * 0.2);
    }
    canopyInst.setColorAt(tIdx, colorTemp);

    trees.push({
      index: tIdx,
      x: tx,
      y: gy - 0.12,
      z: tz,
      rotY,
      scaleXZ,
      scaleY,
      trunkRadius: 0.38 * scaleXZ,
      canopyRadius: 2.35 * scaleXZ,
      bendX: 0,
      bendZ: 0,
      velX: 0,
      velZ: 0,
      fallen: false,
      fallAngle: 0,
      fallVel: 0,
      fallDirX: 1,
      fallDirZ: 0,
      lastRustleTime: -10,
    });
    tIdx++;
  };

  for (let x = -410; x <= 410; x += 28) {
    tryPlaceTree(x, 16);
    tryPlaceTree(x, -16);
  }
  for (let z = -390; z <= 390; z += 34) {
    tryPlaceTree(-16, z);
    tryPlaceTree(16, z);
  }
  while (tIdx < treeCount) {
    const isPerimeter = tIdx < 135;
    let tx: number;
    let tz: number;
    if (isPerimeter) {
      const angle = rand() * Math.PI * 2;
      const dist = 455 + rand() * 45;
      tx = Math.cos(angle) * dist;
      tz = Math.sin(angle) * dist;
    } else {
      tx = (rand() - 0.5) * 860;
      tz = (rand() - 0.5) * 860;
    }
    tryPlaceTree(tx, tz);
  }

  trunkInst.instanceMatrix.needsUpdate = true;
  canopyInst.instanceMatrix.needsUpdate = true;
  if (canopyInst.instanceColor) canopyInst.instanceColor.needsUpdate = true;
  trunkInst.computeBoundingSphere();
  canopyInst.computeBoundingSphere();
  trunkInst.frustumCulled = false;
  canopyInst.frustumCulled = false;
  worldGroup.add(trunkInst, canopyInst);
  disposables.push(trunkGeo, trunkMat, canopyGeo, canopyMat, barkTex, foliageTex);

  // 8B. GRAMA 3D VIVA & FLORES SILVESTRES ESTILO MINECRAFT (Single-Draw Instanced Crossed Blades)
  const tuftQuadA = new THREE.PlaneGeometry(0.68, 0.54);
  tuftQuadA.translate(0, 0.27, 0);
  const tuftQuadB = new THREE.PlaneGeometry(0.68, 0.54);
  tuftQuadB.rotateY(Math.PI / 2);
  tuftQuadB.translate(0, 0.27, 0);
  const crossedTuftGeo = mergeGeometries([tuftQuadA, tuftQuadB]) ?? tuftQuadA.clone();
  tuftQuadA.dispose();
  tuftQuadB.dispose();

  const tuftTex = createGrassTuftTexture();
  const tuftMat = new THREE.MeshStandardMaterial({
    map: tuftTex,
    alphaTest: 0.42,
    side: THREE.DoubleSide,
    roughness: 0.88,
  });

  const tuftCount = 1100;
  const tuftInst = new THREE.InstancedMesh(crossedTuftGeo, tuftMat, tuftCount);
  const flowerTex = createFlowerTexture();
  const flowerMat = new THREE.MeshStandardMaterial({
    map: flowerTex,
    alphaTest: 0.42,
    side: THREE.DoubleSide,
    roughness: 0.8,
  });
  const flowerCount = 260;
  const flowerInst = new THREE.InstancedMesh(crossedTuftGeo, flowerMat, flowerCount);

  const gDummy = new THREE.Object3D();
  const gColor = new THREE.Color();
  let gIdx = 0;
  let fIdx = 0;
  const isOnRoadway = (px: number, pz: number) =>
    Math.abs(pz) < 12.5 ||
    Math.abs(px) < 12.5 ||
    Math.abs(px - 140) < 9.5 ||
    Math.abs(px - 240) < 10.5 ||
    Math.abs(px - 340) < 9.5 ||
    (Math.abs(px) < 25 && pz > -38 && pz < 5);

  for (let attempt = 0; attempt < 4200 && (gIdx < tuftCount || fIdx < flowerCount); attempt++) {
    const gx = (rand() - 0.5) * 680;
    const gz = (rand() - 0.5) * 680;
    if (isOnRoadway(gx, gz)) continue;
    const hitBldg = colliders.some(
      (c) => gx + 0.9 > c.minX && gx - 0.9 < c.maxX && gz + 0.9 > c.minZ && gz - 0.9 < c.maxZ
    );
    if (hitBldg) continue;

    const gy = groundHeightAt(gx, gz);
    const sc = 0.85 + rand() * 0.65;
    gDummy.position.set(gx, gy - 0.04, gz);
    gDummy.rotation.set(0, rand() * Math.PI, 0);
    gDummy.scale.set(sc, sc * (0.85 + rand() * 0.45), sc);
    gDummy.updateMatrix();

    if (gIdx < tuftCount) {
      tuftInst.setMatrixAt(gIdx, gDummy.matrix);
      gColor.setHSL(0.27 + rand() * 0.04, 0.72, 0.72 + rand() * 0.22);
      tuftInst.setColorAt(gIdx, gColor);
      gIdx++;
    } else if (fIdx < flowerCount) {
      flowerInst.setMatrixAt(fIdx, gDummy.matrix);
      const roll = rand();
      gColor.setHex(roll > 0.66 ? 0xffffff : roll > 0.33 ? 0xfef08a : 0xfb7185);
      flowerInst.setColorAt(fIdx, gColor);
      fIdx++;
    }
  }
  tuftInst.count = gIdx;
  flowerInst.count = fIdx;
  tuftInst.instanceMatrix.needsUpdate = true;
  if (tuftInst.instanceColor) tuftInst.instanceColor.needsUpdate = true;
  flowerInst.instanceMatrix.needsUpdate = true;
  if (flowerInst.instanceColor) flowerInst.instanceColor.needsUpdate = true;
  tuftInst.frustumCulled = false;
  flowerInst.frustumCulled = false;
  worldGroup.add(tuftInst, flowerInst);
  disposables.push(crossedTuftGeo, tuftTex, tuftMat, flowerTex, flowerMat);

  // Falling 3D Leaf Particles Pool (bursts off trees on impact / rustle)
  const leafCount = 72;
  const leafPos = new Float32Array(leafCount * 3);
  const leafVel = new Float32Array(leafCount * 3);
  const leafLife = new Float32Array(leafCount);
  for (let i = 0; i < leafCount; i++) {
    leafPos[i * 3 + 1] = -999;
    leafLife[i] = 0;
  }
  const leafGeo = new THREE.BufferGeometry();
  leafGeo.setAttribute('position', new THREE.BufferAttribute(leafPos, 3));
  const leafMat = new THREE.PointsMaterial({
    color: 0x4ade80,
    size: 0.24,
    transparent: true,
    opacity: 0.9,
  });
  const leafPoints = new THREE.Points(leafGeo, leafMat);
  leafPoints.frustumCulled = false;
  worldGroup.add(leafPoints);
  disposables.push(leafGeo, leafMat);

  let leafCursor = 0;
  const spawnLeafBurst = (tx: number, ty: number, tz: number, dirX: number, dirZ: number, amount: number) => {
    for (let k = 0; k < amount; k++) {
      const idx = leafCursor % leafCount;
      leafCursor++;
      leafPos[idx * 3] = tx + (Math.random() - 0.5) * 2.2;
      leafPos[idx * 3 + 1] = ty + 2.6 + Math.random() * 2.4;
      leafPos[idx * 3 + 2] = tz + (Math.random() - 0.5) * 2.2;
      leafVel[idx * 3] = dirX * (2 + Math.random() * 3) + (Math.random() - 0.5) * 3.5;
      leafVel[idx * 3 + 1] = 1.0 + Math.random() * 2.6;
      leafVel[idx * 3 + 2] = dirZ * (2 + Math.random() * 3) + (Math.random() - 0.5) * 3.5;
      leafLife[idx] = 2.4 + Math.random() * 1.2;
    }
    (leafGeo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
  };

  let globalTimeSec = 0;
  const triggerTreeImpact = (treeIdx: number, dirX: number, dirZ: number, speedMs: number, isTrunkHit: boolean) => {
    const tr = trees[treeIdx];
    if (!tr || tr.fallen) return;

    if (!isTrunkHit) {
      // Branch/canopy rustle: gentle impulse + falling leaves
      if (globalTimeSec - tr.lastRustleTime > 0.35) {
        tr.lastRustleTime = globalTimeSec;
        tr.velX += dirZ * 0.45;
        tr.velZ -= dirX * 0.45;
        spawnLeafBurst(tr.x, tr.y, tr.z, dirX, dirZ, 4);
      }
      return;
    }

    // Trunk physical collision!
    spawnLeafBurst(tr.x, tr.y, tr.z, dirX, dirZ, 12);
    if (speedMs >= 18) {
      // High speed collision snaps & topples the tree!
      tr.fallen = true;
      tr.fallDirX = dirX;
      tr.fallDirZ = dirZ;
      tr.fallVel = 1.6 + Math.min(2.5, (speedMs - 18) * 0.14);
    } else {
      // Medium/low speed collision bends trunk & canopy with spring recoil!
      const impulse = Math.min(2.8, 0.8 + speedMs * 0.13);
      tr.velX += dirZ * impulse;
      tr.velZ -= dirX * impulse;
    }
  };

  // Pre-allocated tree transform math objects (zero GC)
  const _tPos = new THREE.Vector3();
  const _tScale = new THREE.Vector3();
  const _tRotY = new THREE.Quaternion();
  const _tTilt = new THREE.Quaternion();
  const _tQuat = new THREE.Quaternion();
  const _tMat4 = new THREE.Matrix4();
  const _tEuler = new THREE.Euler();
  const _tAxis = new THREE.Vector3();
  const _yAxis = new THREE.Vector3(0, 1, 0);

  const updateTrees = (dt: number, elapsedSec: number, rainFactor: number, playerX = 0, playerZ = 0) => {
    globalTimeSec = elapsedSec;
    const windStrength = 0.028 + rainFactor * 0.048;
    const windFreq = 1.45 + rainFactor * 1.1;
    const activeDistSq = 92 * 92;
    let matricesChanged = false;

    for (let i = 0; i < trees.length; i++) {
      const tr = trees[i];
      const dx = tr.x - playerX;
      const dz = tr.z - playerZ;
      const isNear = dx * dx + dz * dz < activeDistSq;
      const isMoving =
        (tr.fallen && tr.fallAngle < 1.46) ||
        Math.abs(tr.velX) > 0.015 ||
        Math.abs(tr.velZ) > 0.015 ||
        Math.abs(tr.bendX) > 0.07 ||
        Math.abs(tr.bendZ) > 0.07;

      if (!isNear && !isMoving) continue;

      if (tr.fallen) {
        if (tr.fallAngle < 1.46) {
          tr.fallVel += 6.2 * dt; // Gravity toppling torque
          tr.fallAngle += tr.fallVel * dt;
          if (tr.fallAngle >= 1.46) {
            tr.fallAngle = 1.46;
            if (Math.abs(tr.fallVel) > 1.2) {
              tr.fallVel = -tr.fallVel * 0.22; // Ground bounce
              spawnLeafBurst(tr.x + tr.fallDirX * 3.5, tr.y - 1.5, tr.z + tr.fallDirZ * 3.5, tr.fallDirX, tr.fallDirZ, 10);
            } else {
              tr.fallVel = 0;
            }
          }
        }
        _tAxis.set(tr.fallDirZ, 0, -tr.fallDirX).normalize();
        _tTilt.setFromAxisAngle(_tAxis, tr.fallAngle);
        _tRotY.setFromAxisAngle(_yAxis, tr.rotY);
        _tQuat.copy(_tTilt).multiply(_tRotY);
      } else {
        const gustX = Math.sin(elapsedSec * windFreq + tr.x * 0.045 + tr.z * 0.03) * windStrength;
        const gustZ = Math.cos(elapsedSec * windFreq * 0.82 + tr.z * 0.05) * windStrength * 0.75;

        const forceX = -28 * (tr.bendX - gustX) - 4.4 * tr.velX;
        const forceZ = -28 * (tr.bendZ - gustZ) - 4.4 * tr.velZ;
        tr.velX += forceX * dt;
        tr.velZ += forceZ * dt;
        tr.bendX += tr.velX * dt;
        tr.bendZ += tr.velZ * dt;

        _tEuler.set(tr.bendX, tr.rotY, tr.bendZ, 'XYZ');
        _tQuat.setFromEuler(_tEuler);
      }

      _tPos.set(tr.x, tr.y, tr.z);
      _tScale.set(tr.scaleXZ, tr.scaleY, tr.scaleXZ);
      _tMat4.compose(_tPos, _tQuat, _tScale);
      trunkInst.setMatrixAt(i, _tMat4);
      canopyInst.setMatrixAt(i, _tMat4);
      matricesChanged = true;
    }

    if (matricesChanged) {
      trunkInst.instanceMatrix.needsUpdate = true;
      canopyInst.instanceMatrix.needsUpdate = true;
    }

    // Update fluttering falling leaves
    let leavesChanged = false;
    for (let i = 0; i < leafCount; i++) {
      if (leafLife[i] > 0) {
        leavesChanged = true;
        leafLife[i] -= dt;
        leafVel[i * 3 + 1] -= 3.6 * dt; // Light leaf gravity
        leafVel[i * 3] += Math.sin(elapsedSec * 5 + i) * 1.4 * dt; // Flutter
        leafPos[i * 3] += leafVel[i * 3] * dt;
        leafPos[i * 3 + 1] += leafVel[i * 3 + 1] * dt;
        leafPos[i * 3 + 2] += leafVel[i * 3 + 2] * dt;
        if (leafLife[i] <= 0) {
          leafPos[i * 3 + 1] = -999;
        }
      }
    }
    if (leavesChanged) {
      (leafGeo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    }
  };

  // 9. BONECOS REALISTAS (26 Articulated Pedestrians across Casa Principal, Centro & Favelas)
  const pedRoutes: Array<[number, number, number, number]> = [
    [-18, 12, 24, 12],
    [15, -14, 52, -14],
    [148, -120, 148, 120],
    [231, -180, 231, 180],
    [249, 180, 249, -180],
    [331, -110, 331, 110],
    [180, 12, 320, 12],
    [180, -12, 320, -12],
    [-235, -180, -235, -260],
    [-265, -210, -205, -210],
    [-260, 240, -210, 240],
    [-70, 50, 70, 50],
    [-70, 120, 70, 120],
  ];

  const shirtPalette = [0xef4444, 0x3b82f6, 0xf59e0b, 0x10b981, 0xf8fafc, 0x8b5cf6];
  const pantsPalette = [0x1e293b, 0x334155, 0x1e3a8a, 0x27272a];
  const skinPalette = [0xc68b63, 0x8d5524, 0xe0ac69, 0x6f4325];

  pedRoutes.forEach(([sx, sz, ex, ez], i) => {
    for (let k = 0; k < 2; k++) {
      const variantIdx = i * 2 + k;
      const actor = createPedestrian(
        shirtPalette[(i + k) % shirtPalette.length],
        pantsPalette[(i + k * 2) % pantsPalette.length],
        skinPalette[(i + k) % skinPalette.length],
        variantIdx
      );
      actor.startX = sx;
      actor.startZ = sz;
      actor.endX = ex;
      actor.endZ = ez;
      actor.t = k * 0.5 + rand() * 0.25;
      actor.dir = k === 0 ? 1 : -1;
      pedestrians.push(actor);
      worldGroup.add(actor.group);
    }
  });

  const updatePedestrians = (dt: number, elapsedSec: number) => {
    for (const p of pedestrians) {
      const dx = p.endX - p.startX;
      const dz = p.endZ - p.startZ;
      const len = Math.max(1, Math.hypot(dx, dz));
      p.t += (p.speed / len) * dt * p.dir;
      if (p.t >= 1) {
        p.t = 1;
        p.dir = -1;
      } else if (p.t <= 0) {
        p.t = 0;
        p.dir = 1;
      }
      p.x = p.startX + dx * p.t;
      p.z = p.startZ + dz * p.t;
      const gy = groundHeightAt(p.x, p.z);
      p.group.position.set(p.x, gy, p.z);
      p.group.rotation.y = Math.atan2(dx * p.dir, dz * p.dir);

      const swing = Math.sin(elapsedSec * p.speed * 4.5 + p.startX) * 0.52;
      p.leftLeg.rotation.x = swing;
      p.rightLeg.rotation.x = -swing;
      p.leftArm.rotation.x = -swing * 0.8;
      p.rightArm.rotation.x = swing * 0.8;
    }
  };

  const setNightAndRain = (nightFactor: number, rainFactor: number) => {
    // Wet asphalt gets glossy & darker in rain!
    for (const mat of asphaltMaterials) {
      mat.roughness = THREE.MathUtils.lerp(0.86, 0.22, rainFactor);
      mat.metalness = THREE.MathUtils.lerp(0.06, 0.28, rainFactor);
      const shade = THREE.MathUtils.lerp(1.0, 0.68, rainFactor);
      mat.color.setRGB(shade, shade, shade);
    }

    // Windows glow brightly at night
    for (const wMat of windowMaterials) {
      wMat.emissiveIntensity = 0.08 + nightFactor * 1.15;
    }

    // Streetlamps & Casa Principal porch light
    for (const bMat of lampBulbMaterials) {
      bMat.emissiveIntensity = 0.15 + nightFactor * 2.2;
    }
    for (const l of lampLights) {
      l.intensity = nightFactor * 26;
    }
    for (const hl of houseLights) {
      hl.intensity = nightFactor * 22;
    }
    houseInteriorLight.intensity = 4.5 + nightFactor * 9.5;
  };

  const updateHouseDoor = (dt: number) => {
    const target = doorOpen ? -Math.PI * 0.56 : 0;
    doorAngle = THREE.MathUtils.damp(doorAngle, target, 8, dt);
    doorPivot.rotation.y = doorAngle;
  };

  return {
    colliders,
    doorCollider,
    trees,
    pedestrians,
    asphaltMaterials,
    windowMaterials,
    lampBulbMaterials,
    lampLights,
    houseLights,
    isDoorOpen: () => doorOpen,
    setDoorOpen: (open: boolean) => {
      doorOpen = open;
    },
    toggleDoor: () => {
      doorOpen = !doorOpen;
      return doorOpen;
    },
    updateHouseDoor,
    triggerTreeImpact,
    updateTrees,
    updatePedestrians,
    setNightAndRain,
    dispose: () => {
      scene.remove(worldGroup);
      disposables.forEach((d) => d.dispose());
    },
  };
}
