import * as THREE from 'three';
import { B, DEFS, GRID } from './blocks';

export const W = 96;
export const H = 48;
export const D = 96;
export const CS = 16;
export const SEA = 19;
export const CX = W / CS;
export const CZ = D / CS;

function hash2(x: number, y: number, seed: number) {
  let h = (Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(seed, 1442695041)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

function vnoise(x: number, y: number, seed: number) {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi, seed);
  const b = hash2(xi + 1, yi, seed);
  const c = hash2(xi, yi + 1, seed);
  const d = hash2(xi + 1, yi + 1, seed);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

function fbm(x: number, y: number, seed: number) {
  let amp = 1;
  let f = 1;
  let sum = 0;
  let norm = 0;
  for (let o = 0; o < 4; o++) {
    sum += vnoise(x * f, y * f, seed + o * 17) * amp;
    norm += amp;
    amp *= 0.5;
    f *= 2;
  }
  return sum / norm;
}

interface FaceDef {
  dir: [number, number, number];
  corners: { pos: [number, number, number]; uv: [number, number] }[];
}

const FACES: FaceDef[] = [
  {
    dir: [-1, 0, 0],
    corners: [
      { pos: [0, 1, 0], uv: [0, 1] },
      { pos: [0, 0, 0], uv: [0, 0] },
      { pos: [0, 1, 1], uv: [1, 1] },
      { pos: [0, 0, 1], uv: [1, 0] },
    ],
  },
  {
    dir: [1, 0, 0],
    corners: [
      { pos: [1, 1, 1], uv: [0, 1] },
      { pos: [1, 0, 1], uv: [0, 0] },
      { pos: [1, 1, 0], uv: [1, 1] },
      { pos: [1, 0, 0], uv: [1, 0] },
    ],
  },
  {
    dir: [0, -1, 0],
    corners: [
      { pos: [1, 0, 1], uv: [1, 0] },
      { pos: [0, 0, 1], uv: [0, 0] },
      { pos: [1, 0, 0], uv: [1, 1] },
      { pos: [0, 0, 0], uv: [0, 1] },
    ],
  },
  {
    dir: [0, 1, 0],
    corners: [
      { pos: [0, 1, 1], uv: [1, 1] },
      { pos: [1, 1, 1], uv: [0, 1] },
      { pos: [0, 1, 0], uv: [1, 0] },
      { pos: [1, 1, 0], uv: [0, 0] },
    ],
  },
  {
    dir: [0, 0, -1],
    corners: [
      { pos: [1, 0, 0], uv: [0, 0] },
      { pos: [0, 0, 0], uv: [1, 0] },
      { pos: [1, 1, 0], uv: [0, 1] },
      { pos: [0, 1, 0], uv: [1, 1] },
    ],
  },
  {
    dir: [0, 0, 1],
    corners: [
      { pos: [0, 0, 1], uv: [0, 0] },
      { pos: [1, 0, 1], uv: [1, 0] },
      { pos: [0, 1, 1], uv: [0, 1] },
      { pos: [1, 1, 1], uv: [1, 1] },
    ],
  },
];

const AO_LEVELS = [0.5, 0.68, 0.84, 1];

interface Buf {
  pos: number[];
  uv: number[];
  col: number[];
  idx: number[];
}

const newBuf = (): Buf => ({ pos: [], uv: [], col: [], idx: [] });

function toGeometry(b: Buf): THREE.BufferGeometry | null {
  if (b.idx.length === 0) return null;
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(b.pos), 3));
  g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(b.uv), 2));
  g.setAttribute('color', new THREE.BufferAttribute(new Float32Array(b.col), 3));
  g.setIndex(new THREE.BufferAttribute(new Uint32Array(b.idx), 1));
  return g;
}

interface ChunkMesh {
  o?: THREE.Mesh;
  t?: THREE.Mesh;
}

export class World {
  data = new Uint8Array(W * H * D);
  edits = new Map<number, number>();
  seed: number;
  group = new THREE.Group();
  private chunks: ChunkMesh[] = new Array(CX * CZ);
  private matO: THREE.MeshBasicMaterial;
  private matT: THREE.MeshBasicMaterial;

  constructor(seed: number, tex: THREE.Texture) {
    this.seed = seed;
    this.matO = new THREE.MeshBasicMaterial({ map: tex, vertexColors: true });
    this.matT = new THREE.MeshBasicMaterial({
      map: tex,
      vertexColors: true,
      transparent: true,
      depthWrite: false,
    });
  }

  setLight(l: number) {
    this.matO.color.setScalar(l);
    this.matT.color.setScalar(l);
  }

  static idx(x: number, y: number, z: number) {
    return (y * D + z) * W + x;
  }

  /** returns STONE outside horizontal bounds / below world (for culling), AIR above */
  get(x: number, y: number, z: number): number {
    if (y < 0) return B.STONE;
    if (y >= H) return B.AIR;
    if (x < 0 || x >= W || z < 0 || z >= D) return B.STONE;
    return this.data[(y * D + z) * W + x];
  }

  /** returns AIR for everything out of bounds */
  peek(x: number, y: number, z: number): number {
    if (y < 0 || y >= H || x < 0 || x >= W || z < 0 || z >= D) return B.AIR;
    return this.data[(y * D + z) * W + x];
  }

  inBounds(x: number, y: number, z: number) {
    return x >= 0 && x < W && y >= 0 && y < H && z >= 0 && z < D;
  }

  solid(x: number, y: number, z: number): boolean {
    if (y < 0) return true;
    if (y >= H) return false;
    if (x < 0 || x >= W || z < 0 || z >= D) return true;
    return DEFS[this.data[(y * D + z) * W + x]].solid;
  }

  topY(x: number, z: number): number {
    for (let y = H - 1; y >= 0; y--) {
      const id = this.data[(y * D + z) * W + x];
      if (id !== B.AIR && id !== B.WATER) return y;
    }
    return 0;
  }

  generate() {
    const { data, seed } = this;
    const heights = new Int32Array(W * D);
    for (let z = 0; z < D; z++) {
      for (let x = 0; x < W; x++) {
        const n = fbm(x * 0.018, z * 0.018, seed);
        const m = fbm(x * 0.007 + 50, z * 0.007 + 50, seed + 11);
        let h = Math.floor(8 + n * 30 + Math.max(0, m - 0.52) * 60);
        h = Math.max(2, Math.min(h, H - 10));
        heights[z * W + x] = h;
        const beach = h <= SEA + 1;
        for (let y = 0; y <= h; y++) {
          let id: number;
          if (y === h) id = beach ? B.SAND : h >= 34 ? B.STONE : B.GRASS;
          else if (y >= h - 3) id = beach ? B.SAND : h >= 34 ? B.STONE : B.DIRT;
          else id = B.STONE;
          data[(y * D + z) * W + x] = id;
        }
        for (let y = h + 1; y <= SEA; y++) data[(y * D + z) * W + x] = B.WATER;
      }
    }

    // trees
    for (let z = 3; z < D - 3; z++) {
      for (let x = 3; x < W - 3; x++) {
        const h = heights[z * W + x];
        if (data[(h * D + z) * W + x] !== B.GRASS) continue;
        if (hash2(x, z, seed + 7) > 0.009) continue;
        const th = 4 + Math.floor(hash2(x, z, seed + 9) * 2);
        for (let y = 1; y <= th; y++) data[((h + y) * D + z) * W + x] = B.LOG;
        for (let dy = th - 2; dy <= th + 1; dy++) {
          const r = dy >= th ? 1 : 2;
          for (let dz = -r; dz <= r; dz++) {
            for (let dx = -r; dx <= r; dx++) {
              if (r === 2 && Math.abs(dx) === 2 && Math.abs(dz) === 2 && hash2(x + dx, z + dz, seed + dy) < 0.6) continue;
              if (dy === th + 1 && Math.abs(dx) + Math.abs(dz) > 1) continue;
              const px = x + dx;
              const py = h + dy;
              const pz = z + dz;
              if (!this.inBounds(px, py, pz)) continue;
              const i = (py * D + pz) * W + px;
              if (data[i] === B.AIR) data[i] = B.LEAVES;
            }
          }
        }
      }
    }
  }

  applyEdits(list: [number, number][]) {
    for (const [i, id] of list) {
      if (i >= 0 && i < this.data.length) {
        this.data[i] = id;
        this.edits.set(i, id);
      }
    }
  }

  findSpawn(): [number, number, number] {
    const cx = W >> 1;
    const cz = D >> 1;
    for (let r = 0; r < 40; r++) {
      for (let dz = -r; dz <= r; dz++) {
        for (let dx = -r; dx <= r; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
          const x = cx + dx;
          const z = cz + dz;
          const y = this.topY(x, z);
          if (y > SEA && this.data[((y + 1) * D + z) * W + x] === B.AIR) return [x + 0.5, y + 1.01, z + 0.5];
        }
      }
    }
    return [cx + 0.5, H - 2, cz + 0.5];
  }

  async buildAll(onProgress: (p: number) => void, isCancelled: () => boolean) {
    const total = CX * CZ;
    let n = 0;
    for (let cz = 0; cz < CZ; cz++) {
      for (let cx = 0; cx < CX; cx++) {
        if (isCancelled()) return;
        this.buildChunk(cx, cz);
        n++;
        onProgress(n / total);
        await new Promise((r) => setTimeout(r, 0));
      }
    }
  }

  setBlock(x: number, y: number, z: number, id: number, record = true) {
    if (!this.inBounds(x, y, z)) return;
    const i = (y * D + z) * W + x;
    if (this.data[i] === id) return;
    this.data[i] = id;
    if (record) this.edits.set(i, id);
    const cx = Math.floor(x / CS);
    const cz = Math.floor(z / CS);
    this.buildChunk(cx, cz);
    const lx = x - cx * CS;
    const lz = z - cz * CS;
    if (lx === 0) this.buildChunk(cx - 1, cz);
    if (lx === CS - 1) this.buildChunk(cx + 1, cz);
    if (lz === 0) this.buildChunk(cx, cz - 1);
    if (lz === CS - 1) this.buildChunk(cx, cz + 1);
  }

  private isOpaque(x: number, y: number, z: number) {
    return DEFS[this.get(x, y, z)].opaque ? 1 : 0;
  }

  buildChunk(cx: number, cz: number) {
    if (cx < 0 || cz < 0 || cx >= CX || cz >= CZ) return;
    const ci = cz * CX + cx;
    const old = this.chunks[ci];
    if (old) {
      if (old.o) {
        this.group.remove(old.o);
        old.o.geometry.dispose();
      }
      if (old.t) {
        this.group.remove(old.t);
        old.t.geometry.dispose();
      }
    }

    const bo = newBuf();
    const bt = newBuf();
    const inv = 1 / GRID;
    const e = 0.002;
    const ao = [0, 0, 0, 0];
    const x0 = cx * CS;
    const z0 = cz * CS;

    for (let y = 0; y < H; y++) {
      for (let z = z0; z < z0 + CS; z++) {
        for (let x = x0; x < x0 + CS; x++) {
          const id = this.data[(y * D + z) * W + x];
          if (id === B.AIR) continue;
          const def = DEFS[id];
          const buf = def.opaque ? bo : bt;

          for (let f = 0; f < 6; f++) {
            const face = FACES[f];
            const nx = x + face.dir[0];
            const ny = y + face.dir[1];
            const nz = z + face.dir[2];
            const nb = this.get(nx, ny, nz);
            if (nb !== B.AIR) {
              const nd = DEFS[nb];
              if (def.opaque) {
                if (nd.opaque) continue;
              } else if (nd.opaque || nb === id) continue;
            }

            const tile = face.dir[1] === 1 ? def.tiles[0] : face.dir[1] === -1 ? def.tiles[1] : def.tiles[2];
            const tu = (tile % GRID) * inv;
            const tv = 1 - (Math.floor(tile / GRID) + 1) * inv;
            const shade = f === 3 ? 1 : f === 2 ? 0.55 : f < 2 ? 0.8 : 0.68;

            const axis = face.dir[0] !== 0 ? 0 : face.dir[1] !== 0 ? 1 : 2;
            const a1 = (axis + 1) % 3;
            const a2 = (axis + 2) % 3;
            const lowerWater = id === B.WATER && this.get(x, y + 1, z) !== B.WATER;

            const base = buf.pos.length / 3;
            for (let i = 0; i < 4; i++) {
              const c = face.corners[i];
              let py = y + c.pos[1];
              if (lowerWater && c.pos[1] === 1) py -= 0.1;
              buf.pos.push(x + c.pos[0], py, z + c.pos[2]);
              buf.uv.push(tu + e * inv + c.uv[0] * (inv - 2 * e * inv), tv + e * inv + c.uv[1] * (inv - 2 * e * inv));

              let level = 3;
              if (def.opaque) {
                const o1 = c.pos[a1] ? 1 : -1;
                const o2 = c.pos[a2] ? 1 : -1;
                const p1 = [nx, ny, nz];
                const p2 = [nx, ny, nz];
                const p3 = [nx, ny, nz];
                p1[a1] += o1;
                p2[a2] += o2;
                p3[a1] += o1;
                p3[a2] += o2;
                const s1 = this.isOpaque(p1[0], p1[1], p1[2]);
                const s2 = this.isOpaque(p2[0], p2[1], p2[2]);
                const s3 = this.isOpaque(p3[0], p3[1], p3[2]);
                level = s1 && s2 ? 0 : 3 - (s1 + s2 + s3);
              }
              ao[i] = level;
              const br = shade * AO_LEVELS[level];
              buf.col.push(br, br, br);
            }

            if (ao[0] + ao[3] > ao[1] + ao[2]) {
              buf.idx.push(base, base + 1, base + 3, base, base + 3, base + 2);
            } else {
              buf.idx.push(base, base + 1, base + 2, base + 2, base + 1, base + 3);
            }
          }
        }
      }
    }

    const entry: ChunkMesh = {};
    const go = toGeometry(bo);
    if (go) {
      entry.o = new THREE.Mesh(go, this.matO);
      this.group.add(entry.o);
    }
    const gt = toGeometry(bt);
    if (gt) {
      entry.t = new THREE.Mesh(gt, this.matT);
      entry.t.renderOrder = 1;
      this.group.add(entry.t);
    }
    this.chunks[ci] = entry;
  }

  dispose() {
    for (const c of this.chunks) {
      if (!c) continue;
      c.o?.geometry.dispose();
      c.t?.geometry.dispose();
    }
    this.matO.dispose();
    this.matT.dispose();
  }
}
