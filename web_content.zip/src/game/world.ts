import { UNITS, BLD, ERAS, FACS, POW, TYPES, TI, fmOf, trainList, POP_CAP, type Era, type FM } from './data';
import { MAPS, type MapDef } from './maps';

export const PI = Math.PI, TAU = Math.PI * 2;
export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export function angDiff(a: number, b: number) { let d = (b - a) % TAU; if (d > PI) d -= TAU; if (d < -PI) d += TAU; return d; }
export function turnTo(a: number, b: number, m: number) { const d = angDiff(a, b); return Math.abs(d) <= m ? b : a + Math.sign(d) * m; }
export function mulberry(a: number) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

export interface PCfg { fac: string; name: string; ai: number }
export interface Cfg { era: Era; map: string; players: PCfg[]; seed: number; local: number }

export interface Ent {
  id: number; t: string; b: boolean; mine: boolean; own: number; x: number; z: number; y: number; rot: number;
  hp: number; mhp: number; sz: number; amt: number;
  ord: number; path: [number, number][] | null; pi: number; gx: number; gz: number; pq: number; tgt: number;
  dstx: number; dstz: number; hasDst: boolean; cd: number; atkT: number; ta: number; mv: boolean; scan: number; rt: number; stk: number;
  carry: number; gs: number; gt: number; mid: number; bid: number; hold: boolean; cons: number; q: { u: string; p: number }[];
  spd: number; dm: number; rng: number; air: boolean; fall: number; hx: number; hz: number; ov: boolean; doom: number; lastHit: number; auto: boolean;
  rx: number; rz: number; rr: number; ph: number; bank: number; seen: number; rly: [number, number];
}
export interface Player {
  idx: number; fac: string; name: string; ai: number; res: number; pop: number; alive: boolean; pcd: number[];
  buffT: number; buffSpd: number; buffDm: number; kills: number; lost: number; made: number;
  aiT: number; waveSize: number; waveT: number; atkX: number; atkZ: number; attacking: boolean;
}

const O_IDLE = 0, O_MOVE = 1, O_AMOVE = 2, O_ATK = 3, O_GATHER = 4, O_BUILD = 5;
const PROJ: Record<string, { s: number }> = {
  bullet: { s: 75 }, arrow: { s: 34 }, shell: { s: 60 }, rocket: { s: 30 }, missile: { s: 38 }, stone: { s: 20 }, arty: { s: 26 }, arcrocket: { s: 24 }, bomb: { s: 0 },
};

export class World {
  role: 'solo' | 'host' | 'client'; cfg: Cfg; map: MapDef; era: Era; half: number; N: number; cs = 2;
  tb: Uint8Array; bb: Uint8Array; ents = new Map<number, Ent>(); nid = 1; players: Player[] = [];
  time = 0; pend: any[] = []; sched: { at: number; fn: () => void }[] = []; evs: any[] = [];
  hn: number; hash: Ent[][]; pathQ: Ent[] = []; over = false; winner = -1; rnd: () => number;
  onEvent?: (ev: any) => void; onMsg?: (pi: number, s: string, bad?: boolean) => void;
  gA: Float32Array; par: Int32Array; stamp: Uint32Array; cl: Uint32Array; st = 1;
  popT = 0;

  constructor(cfg: Cfg, role: 'solo' | 'host' | 'client') {
    this.cfg = cfg; this.role = role; this.map = MAPS[cfg.map]; this.era = cfg.era; this.rnd = mulberry(cfg.seed);
    this.half = this.map.size / 2; this.N = Math.ceil(this.map.size / this.cs);
    const NN = this.N * this.N; this.tb = new Uint8Array(NN); this.bb = new Uint8Array(NN);
    this.gA = new Float32Array(NN); this.par = new Int32Array(NN); this.stamp = new Uint32Array(NN); this.cl = new Uint32Array(NN);
    this.hn = Math.ceil(this.map.size / 10) + 2; this.hash = Array.from({ length: this.hn * this.hn }, () => []);
    this.raster();
    cfg.players.forEach((p, i) => this.players.push({
      idx: i, fac: p.fac, name: p.name, ai: p.ai, res: ERAS[cfg.era].res0, pop: 0, alive: true, pcd: [20, 20],
      buffT: 0, buffSpd: 1, buffDm: 1, kills: 0, lost: 0, made: 0, aiT: 2 + i * 0.4, waveSize: [9, 8, 7][Math.max(0, p.ai)] ?? 8, waveT: 90, atkX: 0, atkZ: 0, attacking: false,
    }));
    if (role !== 'client') this.initial();
  }

  /* ---------- terrain ---------- */
  private raster() {
    const { N, cs, half, map } = this;
    for (let cz = 0; cz < N; cz++) for (let cx = 0; cx < N; cx++) {
      const wx = cx * cs - half + cs / 2, wz = cz * cs - half + cs / 2; let bl = 0;
      for (const r of map.water) if (Math.abs(wx - r.x) < r.w / 2 + 0.6 && Math.abs(wz - r.z) < r.h / 2 + 0.6) bl = 1;
      for (const r of map.rocks) if (Math.hypot(wx - r.x, wz - r.z) < r.r + 0.4) bl = 1;
      for (const r of map.bridges) if (Math.abs(wx - r.x) < r.w / 2 && Math.abs(wz - r.z) < r.h / 2) bl = 0;
      if (cx <= 1 || cz <= 1 || cx >= N - 2 || cz >= N - 2) bl = 1;
      this.tb[cz * N + cx] = bl;
    }
  }
  cell(v: number) { return Math.floor((v + this.half) / this.cs); }
  blockedC(cx: number, cz: number) { if (cx < 0 || cz < 0 || cx >= this.N || cz >= this.N) return true; const i = cz * this.N + cx; return this.tb[i] > 0 || this.bb[i] > 0; }
  blockedAt(x: number, z: number) { return this.blockedC(this.cell(x), this.cell(z)); }
  markB(e: Ent, d: number) {
    const s = e.sz / 2 + 0.3; const x0 = this.cell(e.x - s), x1 = this.cell(e.x + s), z0 = this.cell(e.z - s), z1 = this.cell(e.z + s);
    for (let cz = z0; cz <= z1; cz++) for (let cx = x0; cx <= x1; cx++) if (cx >= 0 && cz >= 0 && cx < this.N && cz < this.N) this.bb[cz * this.N + cx] += d;
  }
  nearestFree(x: number, z: number, R = 12): [number, number] | null {
    const c0 = this.cell(x), r0 = this.cell(z); if (!this.blockedC(c0, r0)) return [x, z];
    for (let r = 1; r <= R; r++) {
      let best: [number, number] | null = null, bd = 1e9;
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
        if (this.blockedC(c0 + dx, r0 + dz)) continue;
        const wx = (c0 + dx) * this.cs - this.half + this.cs / 2, wz = (r0 + dz) * this.cs - this.half + this.cs / 2;
        const d = Math.hypot(wx - x, wz - z); if (d < bd) { bd = d; best = [wx, wz]; }
      }
      if (best) return best;
    }
    return null;
  }
  los(ax: number, az: number, bx: number, bz: number) {
    const d = Math.hypot(bx - ax, bz - az); const n = Math.ceil(d / (this.cs * 0.5));
    for (let i = 1; i < n; i++) { const t = i / n; if (this.blockedAt(ax + (bx - ax) * t, az + (bz - az) * t)) return false; }
    return true;
  }
  astar(sx: number, sz: number, gx: number, gz: number): [number, number][] {
    const N = this.N; const half = this.half, cs = this.cs;
    const fr = this.nearestFree(gx, gz, 14); if (!fr) return [[gx, gz]];
    const exact = fr[0] === gx && fr[1] === gz; gx = fr[0]; gz = fr[1];
    const sc = clamp(this.cell(sx), 0, N - 1), sr = clamp(this.cell(sz), 0, N - 1), gc = this.cell(gx), gr = this.cell(gz);
    const s = sr * N + sc, g = gr * N + gc; if (s === g) return [[gx, gz]];
    const st = ++this.st; const hk: number[] = [], hv: number[] = [];
    const push = (k: number, v: number) => { let i = hk.length; hk.push(k); hv.push(v); while (i > 0) { const p = (i - 1) >> 1; if (hv[p] <= hv[i]) break; [hk[p], hk[i]] = [hk[i], hk[p]]; [hv[p], hv[i]] = [hv[i], hv[p]]; i = p; } };
    const pop = () => {
      const k = hk[0]; const lk = hk.pop()!, lv = hv.pop()!;
      if (hk.length) { hk[0] = lk; hv[0] = lv; let i = 0; for (; ;) { let l = i * 2 + 1, r = l + 1, m = i; if (l < hk.length && hv[l] < hv[m]) m = l; if (r < hk.length && hv[r] < hv[m]) m = r; if (m === i) break; [hk[m], hk[i]] = [hk[i], hk[m]]; [hv[m], hv[i]] = [hv[i], hv[m]]; i = m; } }
      return k;
    };
    const hh = (c: number, r: number) => { const dx = Math.abs(c - gc), dz = Math.abs(r - gr); return (dx + dz) + (1.414 - 2) * Math.min(dx, dz); };
    this.stamp[s] = st; this.gA[s] = 0; this.par[s] = -1; push(s, hh(sc, sr));
    let best = s, bh = hh(sc, sr), it = 0; const DX = [1, -1, 0, 0, 1, 1, -1, -1], DZ = [0, 0, 1, -1, 1, -1, 1, -1];
    while (hk.length && it++ < 9000) {
      const cur = pop(); if (this.cl[cur] === st) continue; this.cl[cur] = st; if (cur === g) { best = g; break; }
      const cx = cur % N, cz = (cur / N) | 0; const h0 = hh(cx, cz); if (h0 < bh) { bh = h0; best = cur; }
      for (let k = 0; k < 8; k++) {
        const nx = cx + DX[k], nz = cz + DZ[k]; if (this.blockedC(nx, nz)) continue;
        if (k >= 4 && (this.blockedC(cx + DX[k], cz) || this.blockedC(cx, cz + DZ[k]))) continue;
        const ni = nz * N + nx; const ng = this.gA[cur] + (k >= 4 ? 1.414 : 1);
        if (this.stamp[ni] !== st || ng < this.gA[ni]) { this.stamp[ni] = st; this.gA[ni] = ng; this.par[ni] = cur; push(ni, ng + hh(nx, nz)); }
      }
    }
    const pts: [number, number][] = []; let c = best;
    while (c !== -1 && c !== s) { pts.push([(c % N) * cs - half + cs / 2, ((c / N) | 0) * cs - half + cs / 2]); c = this.par[c]; }
    pts.reverse(); if (best === g && exact) { if (pts.length) pts[pts.length - 1] = [gx, gz]; }
    const out: [number, number][] = []; let ax = sx, az = sz, i = 0;
    while (i < pts.length) { let j = pts.length - 1; while (j > i && !this.los(ax, az, pts[j][0], pts[j][1])) j--; out.push(pts[j]); ax = pts[j][0]; az = pts[j][1]; i = j + 1; }
    return out.length ? out : [[gx, gz]];
  }

  /* ---------- entities ---------- */
  spawn(t: string, own: number, x: number, z: number, id?: number): Ent {
    const isB = !!BLD[t]; const isMine = t === 'mine'; const p = this.players[own] || this.players[0]; const fm = fmOf(p ? p.fac : '');
    const ud = UNITS[t];
    const e: Ent = {
      id: id ?? this.nid++, t, b: isB, mine: isMine, own, x, z, y: 0, rot: 0, hp: 1, mhp: 1, sz: 0, amt: 0,
      ord: 0, path: null, pi: 0, gx: x, gz: z, pq: 0, tgt: 0, dstx: x, dstz: z, hasDst: false, cd: 0.3, atkT: 9, ta: 0, mv: false, scan: Math.random() * 0.4, rt: 0, stk: 0,
      carry: 0, gs: 0, gt: 0, mid: 0, bid: 0, hold: false, cons: 1, q: [], spd: 0, dm: 1, rng: 0, air: false, fall: 0, hx: x, hz: z, ov: false, doom: 0, lastHit: -99, auto: false,
      rx: x, rz: z, rr: 0, ph: Math.random() * 6, bank: 0, seen: 0, rly: [x, z],
    };
    if (id !== undefined && id >= this.nid) this.nid = id + 1;
    if (isB) { const bd = BLD[t]; e.mhp = bd.hp * fm.hp; e.hp = e.mhp; e.sz = bd.sz; e.dm = t === 'tow' ? fm.tow : 1; e.rng = t === 'tow' ? ERAS[this.era].tw.rng * (fm.rng > 1 ? 1.05 : 1) : 0; this.markB(e, 1); }
    else if (isMine) { e.sz = 4.4; e.amt = 3500; e.hp = 1; e.mhp = 1; this.markB(e, 1); }
    else if (ud) { e.mhp = ud.hp * fm.hp; e.hp = e.mhp; e.spd = ud.spd * fm.spd; e.dm = fm.dmg * (ud.air && ud.cls === 'air' && fm.spd > 1 && this.era === 'ww2' ? 1.2 : 1); e.rng = ud.rng * (ud.rng > 4 ? fm.rng : 1); e.air = !!ud.air; e.y = e.air ? 2 : 0; e.rot = Math.atan2(-x, -z); e.ta = e.rot; }
    this.ents.set(e.id, e); return e;
  }
  private initial() {
    for (const m of this.map.mines) { const e = this.spawn('mine', -1, m.x, m.z); e.amt = m.a; }
    this.players.forEach((_p, i) => {
      const s = this.map.starts[i]; const hq = this.spawn('hq', i, s.x, s.z); hq.rot = Math.atan2(-s.x, -s.z);
      const wk = ERAS[this.era].wk;
      for (let k = 0; k < 5; k++) {
        const a = hq.rot + (k - 2) * 0.45; const sx = s.x + Math.sin(a) * 7.5, sz = s.z + Math.cos(a) * 7.5;
        const f = this.nearestFree(sx, sz, 6) || [sx, sz]; this.spawn(wk, i, f[0], f[1]);
      }
    });
  }
  byOwner(i: number) { const out: Ent[] = []; this.ents.forEach(e => { if (e.own === i && e.hp > 0) out.push(e); }); return out; }
  hcell(v: number) { return clamp(Math.floor((v + this.half) / 10), 0, this.hn - 1); }
  near(x: number, z: number, r: number, fn: (e: Ent) => void) {
    const x0 = this.hcell(x - r), x1 = this.hcell(x + r), z0 = this.hcell(z - r), z1 = this.hcell(z + r);
    for (let cz = z0; cz <= z1; cz++) for (let cx = x0; cx <= x1; cx++) { const l = this.hash[cz * this.hn + cx]; for (let i = 0; i < l.length; i++) fn(l[i]); }
  }
  wpn(e: Ent): any { return e.t === 'tow' ? ERAS[this.era].tw : UNITS[e.t]; }
  canHit(w: any, t: Ent) { if (t.mine) return false; if (t.air) return !!w.aa; return w.gr !== false; }
  emit(ev: any) { this.evs.push(ev); this.onEvent?.(ev); }
  toast(pi: number, s: string, bad = false) { this.onMsg?.(pi, s, bad); }
  popCount(i: number) { return this.players[i].pop; }

  /* ---------- placement ---------- */
  canPlace(t: string, x: number, z: number, own: number): string | null {
    const bd = BLD[t]; if (!bd) return 'نوع غير صالح'; const s = bd.sz / 2 + 0.8;
    if (Math.abs(x) > this.half - 8 || Math.abs(z) > this.half - 8) return 'خارج الخريطة';
    for (let cz = this.cell(z - s); cz <= this.cell(z + s); cz++) for (let cx = this.cell(x - s); cx <= this.cell(x + s); cx++) if (this.blockedC(cx, cz)) return 'المكان مشغول';
    let near = false; this.ents.forEach(e => { if (e.own === own && e.b && e.hp > 0 && Math.hypot(e.x - x, e.z - z) < 48) near = true; });
    if (!near) return 'ابنِ قرب مبانيك';
    return null;
  }

  /* ---------- commands ---------- */
  ownUnits(from: number, ids: number[]) { const o: Ent[] = []; for (const id of ids || []) { const e = this.ents.get(id); if (e && e.own === from && !e.b && !e.mine && e.hp > 0) o.push(e); } return o; }
  reqPath(e: Ent, x: number, z: number) { e.gx = x; e.gz = z; e.path = [[x, z]]; e.pi = 0; if (!e.pq) { e.pq = 1; this.pathQ.push(e); } }
  exec(from: number, c: any) {
    const p = this.players[from]; if (!p || !p.alive || this.over) return;
    switch (c.k) {
      case 'move': case 'amove': {
        const us = this.ownUnits(from, c.ids); const n = us.length; if (!n) break;
        const cols = Math.ceil(Math.sqrt(n)), rows = Math.ceil(n / cols), sp = 2.4;
        us.forEach((e, i) => {
          let tx = c.x, tz = c.z; if (n > 1) { tx += ((i % cols) - (cols - 1) / 2) * sp; tz += (Math.floor(i / cols) - (rows - 1) / 2) * sp; }
          tx = clamp(tx, -this.half + 4, this.half - 4); tz = clamp(tz, -this.half + 4, this.half - 4);
          e.ord = c.k === 'move' ? O_MOVE : O_AMOVE; e.dstx = tx; e.dstz = tz; e.hasDst = true; e.tgt = 0; e.hold = false; e.auto = false; e.hx = tx; e.hz = tz;
          if (!e.air) this.reqPath(e, tx, tz);
        }); break;
      }
      case 'attack': {
        const t = this.ents.get(c.tgt); if (!t || t.own === from || t.hp <= 0 || t.mine) break;
        for (const e of this.ownUnits(from, c.ids)) {
          const d = UNITS[e.t]; if (d.cls === 'wk' || !this.canHit(d, t)) continue;
          e.ord = O_ATK; e.tgt = t.id; e.hasDst = false; e.auto = false; e.hold = false; e.path = null;
        } break;
      }
      case 'gather': {
        const m = this.ents.get(c.tgt); if (!m || !m.mine) break;
        for (const e of this.ownUnits(from, c.ids)) if (UNITS[e.t].cls === 'wk') { e.ord = O_GATHER; e.mid = m.id; e.gs = e.carry > 0 ? 2 : 0; e.hold = false; e.path = null; }
        break;
      }
      case 'help': {
        const b = this.ents.get(c.b); if (!b || b.own !== from || !b.b || b.cons >= 1) break;
        for (const e of this.ownUnits(from, c.ids)) if (UNITS[e.t].cls === 'wk') { e.ord = O_BUILD; e.bid = b.id; e.path = null; e.hold = false; }
        break;
      }
      case 'stop': for (const e of this.ownUnits(from, c.ids)) { e.ord = O_IDLE; e.path = null; e.tgt = 0; e.hold = true; e.hasDst = false; e.hx = e.x; e.hz = e.z; } break;
      case 'train': {
        const b = this.ents.get(c.b); if (!b || b.own !== from || !b.b || b.cons < 1 || b.hp <= 0) break;
        if (!trainList(p.fac, b.t).includes(c.u)) break; if (b.q.length >= 6) { this.toast(from, 'قائمة الإنتاج ممتلئة', true); break; }
        const cost = Math.round(UNITS[c.u].cost * fmOf(p.fac).cost); if (p.res < cost) { this.toast(from, 'الذهب غير كافٍ', true); break; }
        p.res -= cost; b.q.push({ u: c.u, p: 0 }); break;
      }
      case 'cancel': {
        const b = this.ents.get(c.b); if (!b || b.own !== from || !b.q[c.i]) break;
        const it = b.q.splice(c.i, 1)[0]; p.res += Math.round(UNITS[it.u].cost * fmOf(p.fac).cost); break;
      }
      case 'build': {
        const bd = BLD[c.t]; if (!bd || c.t === 'hq' || !ERAS[this.era].bn[c.t]) break;
        if (c.t === 'air' && !FACS[p.fac].air.length) { this.toast(from, 'هذا الجيش بلا سلاح جو', true); break; }
        const cost = Math.round(bd.cost * fmOf(p.fac).cost); if (p.res < cost) { this.toast(from, 'الذهب غير كافٍ', true); break; }
        const err = this.canPlace(c.t, c.x, c.z, from); if (err) { this.toast(from, err, true); break; }
        let ws = this.ownUnits(from, c.ids).filter(e => UNITS[e.t].cls === 'wk');
        if (!ws.length) { let bd2 = 1e9, bw: Ent | null = null; this.ents.forEach(e => { if (e.own === from && !e.b && e.hp > 0 && UNITS[e.t]?.cls === 'wk') { const d = Math.hypot(e.x - c.x, e.z - c.z); if (d < bd2) { bd2 = d; bw = e; } } }); if (bw) ws = [bw]; }
        if (!ws.length) { this.toast(from, 'لا يوجد عمال', true); break; }
        p.res -= cost; const b = this.spawn(c.t, from, c.x, c.z); b.cons = 0.02; b.hp = b.mhp * 0.1; b.rot = 0;
        for (const w of ws) { w.ord = O_BUILD; w.bid = b.id; w.path = null; w.hold = false; }
        break;
      }
      case 'pow': this.usePower(from, c.i, c.x, c.z); break;
    }
  }
  usePower(from: number, i: number, x: number, z: number) {
    const p = this.players[from]; const pid = FACS[p.fac].pw[i]; const pw = POW[pid]; if (!pw) return;
    if (p.pcd[i] > 0) { this.toast(from, 'القدرة قيد التبريد', true); return; }
    p.pcd[i] = pw.cd;
    if (pw.t === 'heal') {
      let k = 0; this.ents.forEach(e => { if (e.own === from && e.hp > 0 && !e.mine && !e.b) { e.hp = Math.min(e.mhp, e.hp + e.mhp * 0.5); if (k++ < 40) this.emit({ k: 'x', x: e.x, y: 1, z: e.z, s: 0.5, f: 'heal' }); } });
    } else if (pw.t === 'buff') {
      p.buffT = pw.time!; p.buffSpd = pw.spd!; p.buffDm = pw.dm!;
      let k = 0; this.ents.forEach(e => { if (e.own === from && !e.b && !e.mine && k++ < 40) this.emit({ k: 'x', x: e.x, y: 1, z: e.z, s: 0.5, f: 'buff' }); });
    } else if (pw.t === 'strike') {
      if (pw.fly) this.emit({ k: 'fly', m: pw.fly, x: x, z: z, a: Math.atan2(-x, -z) + 0.3, d: pw.dur });
      for (let k = 0; k < pw.cnt!; k++) {
        const at = this.time + (k / pw.cnt!) * pw.dur! + this.rnd() * 0.2; const a = this.rnd() * TAU, r = Math.sqrt(this.rnd()) * pw.rad!;
        const tx = x + Math.cos(a) * r, tz = z + Math.sin(a) * r;
        this.sched.push({ at, fn: () => {
          const kind = pw.kind === 'stone' ? 'stone' : pw.kind!; const tt = kind === 'bomb' ? 0.8 : 1.0;
          this.emit({ k: 'p', p: kind === 'arrow' ? 'arrow' : kind, x: kind === 'bomb' ? tx : tx - 14, y: 55, z: kind === 'bomb' ? tz : tz - 10, tx, ty: 0.5, tz, t: tt, rain: 1 });
          this.pend.push({ at: this.time + tt, x: tx, z: tz, y: 0.5, spl: pw.spl, dmg: pw.dmg, own: from, tgt: 0, w: { aa: false, gr: true, vsB: 1 }, ranged: false, bdm: 1 });
        } });
      }
    } else if (pw.t === 'spawn') {
      for (let k = 0; k < pw.cnt!; k++) {
        const a = k * 2.4, r = 1.5 + k * 0.45; const f = this.nearestFree(x + Math.cos(a) * r, z + Math.sin(a) * r, 8); if (!f) continue;
        const e = this.spawn(pw.u!, from, f[0], f[1]); e.fall = pw.fall || 0; if (e.fall) e.y = e.fall; e.hasDst = false;
        if (!e.fall) this.emit({ k: 'x', x: f[0], y: 0.5, z: f[1], s: 0.7, f: 'dust' });
      }
    }
    this.toast(from, pw.n + ' ✔');
  }

  /* ---------- simulation ---------- */
  step(dt: number) {
    if (this.over) return;
    this.time += dt;
    for (const l of this.hash) l.length = 0;
    this.ents.forEach(e => { if (e.hp > 0) this.hash[this.hcell(e.z) * this.hn + this.hcell(e.x)].push(e); });
    for (let i = 0; i < 10 && this.pathQ.length; i++) {
      const e = this.pathQ.shift()!; e.pq = 0; if (e.hp <= 0 || e.air) continue;
      e.path = this.astar(e.x, e.z, e.gx, e.gz); e.pi = 0;
    }
    for (const p of this.players) { p.pop = 0; if (p.buffT > 0) p.buffT -= dt; for (let i = 0; i < p.pcd.length; i++) if (p.pcd[i] > 0) p.pcd[i] -= dt; }
    this.ents.forEach(e => { if (e.hp > 0 && !e.b && !e.mine) { const p = this.players[e.own]; if (p) p.pop++; } });
    this.ents.forEach(e => {
      if (e.hp <= 0 || e.mine) return;
      if (e.doom > 0) { e.doom -= dt; if (e.doom <= 0) { e.hp = 0; return; } }
      if (e.b) this.updBld(e, dt); else this.updUnit(e, dt);
    });
    for (let i = this.sched.length - 1; i >= 0; i--) if (this.sched[i].at <= this.time) { const s = this.sched.splice(i, 1)[0]; s.fn(); }
    for (let i = this.pend.length - 1; i >= 0; i--) if (this.pend[i].at <= this.time) { const h = this.pend.splice(i, 1)[0]; this.applyHit(h); }
    this.reap();
    for (const p of this.players) if (p.ai >= 0 && p.alive) this.aiHook?.(this, p, dt);
    this.checkWin();
  }
  aiHook?: (w: World, p: Player, dt: number) => void;

  private afterTarget(e: Ent) {
    e.tgt = 0; e.auto = false;
    if (e.hasDst) { e.ord = O_AMOVE; if (!e.air) this.reqPath(e, e.dstx, e.dstz); } else e.ord = O_IDLE;
  }
  private follow(e: Ent, dt: number): boolean {
    const path = e.path; if (!path || e.pi >= path.length) return true;
    const p = this.players[e.own]; let wp = path[e.pi]; let dx = wp[0] - e.x, dz = wp[1] - e.z; let d = Math.hypot(dx, dz);
    const step = e.spd * (p.buffT > 0 ? p.buffSpd : 1) * dt;
    if (d <= Math.max(step, 0.35)) { e.pi++; if (e.pi >= path.length) return true; wp = path[e.pi]; dx = wp[0] - e.x; dz = wp[1] - e.z; d = Math.hypot(dx, dz) || 1; }
    const cls = UNITS[e.t].cls; e.rot = turnTo(e.rot, Math.atan2(dx, dz), (cls === 'inf' || cls === 'wk' ? 10 : 4) * dt);
    const ok = this.tryMove(e, e.x + dx / d * step, e.z + dz / d * step); if (!ok) e.stk += dt; else e.stk = 0;
    if (e.stk > 0.8) { e.stk = 0; this.reqPath(e, e.gx, e.gz); }
    e.mv = true; return false;
  }
  private tryMove(e: Ent, nx: number, nz: number) {
    if (!this.blockedAt(nx, nz)) { e.x = nx; e.z = nz; return true; }
    if (!this.blockedAt(nx, e.z)) { e.x = nx; return true; }
    if (!this.blockedAt(e.x, nz)) { e.z = nz; return true; }
    return false;
  }
  private goTo(e: Ent, x: number, z: number, ad: number, dt: number): boolean {
    const dd = Math.hypot(x - e.x, z - e.z); if (dd <= ad) { e.path = null; return true; }
    e.rt -= dt;
    if (!e.path || Math.hypot(e.gx - x, e.gz - z) > 2.5) this.reqPath(e, x, z);
    else if (e.pi >= e.path.length && !e.pq) { if (dd < ad + 3.5) return true; if (e.rt <= 0) { e.rt = 0.8; this.reqPath(e, x, z); } }
    this.follow(e, dt); return false;
  }
  private sep(e: Ent, dt: number) {
    let px = 0, pz = 0;
    this.near(e.x, e.z, 1.6, o => {
      if (o === e || o.b || o.mine || o.air !== e.air) return; const dx = e.x - o.x, dz = e.z - o.z; const d = Math.hypot(dx, dz);
      if (d < 1.5) { if (d < 0.01) { px += Math.random() - 0.5; pz += Math.random() - 0.5; } else { const f = (1.5 - d) / 1.5; px += dx / d * f; pz += dz / d * f; } }
    });
    if (px || pz) this.tryMove(e, e.x + px * dt * 4, e.z + pz * dt * 4);
  }
  acquire(e: Ent, w: any, r: number): Ent | null {
    let best: Ent | null = null, bs = 1e9;
    this.near(e.x, e.z, r + 4, o => {
      if (o.own === e.own || o.hp <= 0 || o.mine) return; if (!this.canHit(w, o)) return;
      const d = Math.hypot(o.x - e.x, o.z - e.z) - (o.b ? o.sz / 2 : 0); if (d > r) return;
      let s = d + (o.b ? (o.t === 'tow' ? -3 : 9) : 0) + (UNITS[o.t]?.cls === 'wk' ? 4 : 0) - (o.air && w.aa ? 2 : 0);
      if (s < bs) { bs = s; best = o; }
    });
    return best;
  }
  private mult(w: any, o: Ent, ranged: boolean) {
    let m = 1; const ud = UNITS[o.t];
    if (ud) { if (w.bon && w.bon[ud.cls]) m *= w.bon[ud.cls]; if (ranged && ud.rdef) m *= ud.rdef; }
    if (o.b) m *= w.vsB ?? 1; return m;
  }
  hurt(o: Ent, amt: number, src: number) {
    if (o.hp <= 0) return; o.hp -= amt; o.lastHit = this.time;
    if (o.hp <= 0 && src >= 0 && this.players[src]) this.players[src].kills++;
  }
  private applyHit(h: any) {
    if (h.spl > 0) {
      this.emit({ k: 'x', x: h.x, y: h.y ?? 0.5, z: h.z, s: Math.max(0.8, h.spl * 0.55), f: 'boom' });
      this.near(h.x, h.z, h.spl + 6, o => {
        if (o.own === h.own || o.hp <= 0 || o.mine) return; if (!this.canHit(h.w, o)) return;
        const dd = Math.hypot(o.x - h.x, o.z - h.z) - (o.b ? o.sz / 2 : 0.5); if (dd >= h.spl) return;
        this.hurt(o, h.dmg * (1 - dd / (h.spl * 1.5)) * this.mult(h.w, o, h.ranged) * (o.b ? h.bdm : 1), h.own);
      });
    } else {
      const t = this.ents.get(h.tgt); if (t && t.hp > 0) this.hurt(t, h.dmg * this.mult(h.w, t, h.ranged) * (t.b ? h.bdm : 1), h.own);
    }
  }
  private fire(e: Ent, t: Ent, w: any) {
    const p = this.players[e.own]; const fm = fmOf(p.fac); const dm = e.dm * (p.buffT > 0 ? p.buffDm : 1);
    e.cd = w.cd; e.atkT = 0;
    const dmg = w.dmg * dm; const proj = w.proj;
    const tx = t.x, tz = t.z, ty = t.air ? t.y : (t.b ? 1.5 : 1.0); const sy = e.air ? e.y : (e.t === 'tow' ? 4 : 1.6);
    if (proj === 'none') { this.pend.push({ at: this.time + 0.18, x: tx, z: tz, y: 1, spl: w.spl || 0, dmg, own: e.own, tgt: t.id, w, ranged: false, bdm: fm.bdm }); return; }
    const dist = Math.hypot(tx - e.x, tz - e.z);
    const tt = proj === 'bomb' ? Math.sqrt(2 * Math.max(1, e.y) / 18) : Math.max(0.06, dist / PROJ[proj].s);
    this.emit({ k: 'p', p: proj, x: e.x + Math.sin(e.rot) * 1.4, y: sy, z: e.z + Math.cos(e.rot) * 1.4, tx, ty, tz, t: tt, spl: w.spl || 0 });
    this.pend.push({ at: this.time + tt, x: tx, z: tz, y: ty, spl: w.spl || 0, dmg, own: e.own, tgt: t.id, w, ranged: true, bdm: fm.bdm });
  }
  private updBld(e: Ent, dt: number) {
    if (e.cons < 1) return;
    const p = this.players[e.own]; const fm = fmOf(p.fac);
    if (e.q.length) {
      const it = e.q[0]; const ud = UNITS[it.u]; it.p += dt / (ud.bt * fm.bt);
      if (it.p >= 1) {
        if (p.pop >= POP_CAP) { it.p = 1; if (!e.mv) { e.mv = true; this.toast(e.own, 'وصلت للحد الأقصى للسكان', true); } }
        else { e.mv = false; e.q.shift(); this.produce(e, ud.id); p.made++; }
      }
    }
    if (e.t === 'tow') {
      e.cd -= dt; e.scan -= dt; const w = ERAS[this.era].tw;
      let t = e.tgt ? this.ents.get(e.tgt) : undefined;
      if (t && (t.hp <= 0 || Math.hypot(t.x - e.x, t.z - e.z) > e.rng + 2)) { t = undefined; e.tgt = 0; }
      if (!t && e.scan <= 0) { e.scan = 0.3; const a = this.acquire(e, w, e.rng); if (a) { t = a; e.tgt = a.id; } }
      if (t) { e.ta = turnTo(e.ta, Math.atan2(t.x - e.x, t.z - e.z), 6 * dt); if (e.cd <= 0 && Math.abs(angDiff(e.ta, Math.atan2(t.x - e.x, t.z - e.z))) < 0.3) { e.rot = e.ta; this.fire(e, t, w); e.rot = 0; } }
    }
  }
  private produce(b: Ent, u: string) {
    const ud = UNITS[u]; const a = Math.atan2(-b.x, -b.z); let sx = b.x, sz = b.z, rot = a;
    if (!ud.air) {
      let ok = false;
      for (let k = 0; k < 12 && !ok; k++) {
        const aa = a + (k % 2 ? 1 : -1) * Math.ceil(k / 2) * 0.55; const r = b.sz / 2 + 2.2;
        sx = b.x + Math.sin(aa) * r; sz = b.z + Math.cos(aa) * r; if (!this.blockedAt(sx, sz)) { ok = true; rot = aa; }
      }
      if (!ok) { const f = this.nearestFree(b.x, b.z, 10); if (f) { sx = f[0]; sz = f[1]; } }
    }
    const e = this.spawn(u, b.own, sx, sz); e.rot = rot;
    const rx = b.x + Math.sin(a) * (b.sz / 2 + 6), rz = b.z + Math.cos(a) * (b.sz / 2 + 6);
    if (ud.air) { e.y = 1; e.hx = rx; e.hz = rz; e.ord = O_MOVE; e.dstx = rx; e.dstz = rz; }
    else if (ud.cls !== 'wk') { e.ord = O_MOVE; e.dstx = rx; e.dstz = rz; this.reqPath(e, rx, rz); }
  }

  private updUnit(e: Ent, dt: number) {
    const d = UNITS[e.t]; const p = this.players[e.own];
    e.cd -= dt; e.atkT += dt; e.mv = false; e.scan -= dt;
    if (e.fall > 0) { e.fall = Math.max(0, e.fall - 12 * dt); e.y = e.fall; if (e.fall === 0) this.emit({ k: 'x', x: e.x, y: 0.4, z: e.z, s: 0.5, f: 'dust' }); return; }
    if (d.air) { this.updAir(e, d, p, dt); return; }
    if (this.blockedAt(e.x, e.z)) { const f = this.nearestFree(e.x, e.z, 8); if (f) { const dx = f[0] - e.x, dz = f[1] - e.z, dd = Math.hypot(dx, dz) || 1; e.x += dx / dd * Math.min(dd, 6 * dt); e.z += dz / dd * Math.min(dd, 6 * dt); } }
    const isWk = d.cls === 'wk';
    switch (e.ord) {
      case O_IDLE:
        if (isWk) { if (!e.hold) this.startWork(e); }
        else if (e.scan <= 0) { e.scan = 0.3; const t = this.acquire(e, d, e.rng + 5); if (t) { e.tgt = t.id; e.ord = O_ATK; e.auto = true; e.hasDst = true; e.dstx = e.x; e.dstz = e.z; } }
        if (!isWk && e.ord === O_IDLE) this.turretIdle(e, dt, d);
        break;
      case O_MOVE:
        if (this.goTo(e, e.dstx, e.dstz, 0.7, dt)) { e.ord = O_IDLE; e.hasDst = false; e.hold = false; }
        break;
      case O_AMOVE:
        if (!isWk && e.scan <= 0) { e.scan = 0.3; const t = this.acquire(e, d, e.rng + 6); if (t) { e.tgt = t.id; e.ord = O_ATK; e.auto = true; break; } }
        if (this.goTo(e, e.dstx, e.dstz, 1.2, dt)) { e.ord = O_IDLE; e.hasDst = false; }
        break;
      case O_ATK: {
        const t = this.ents.get(e.tgt);
        if (!t || t.hp <= 0 || t.own === e.own || !this.canHit(d, t)) { this.afterTarget(e); break; }
        const dx = t.x - e.x, dz = t.z - e.z; const dist = Math.hypot(dx, dz) - (t.b ? t.sz / 2 : 0.5); const aim = Math.atan2(dx, dz);
        if (e.auto && Math.hypot(e.dstx - e.x, e.dstz - e.z) > 30) { this.afterTarget(e); break; }
        if (dist <= e.rng) {
          e.path = null;
          if (d.tur) e.ta = turnTo(e.ta, aim, 5 * dt); else { e.rot = turnTo(e.rot, aim, 9 * dt); e.ta = e.rot; }
          if (e.cd <= 0 && Math.abs(angDiff(d.tur ? e.ta : e.rot, aim)) < 0.25) this.fire(e, t, d);
        } else {
          e.rt -= dt;
          if (!e.path || e.rt <= 0 && Math.hypot(e.gx - t.x, e.gz - t.z) > 3) { e.rt = 0.7; this.reqPath(e, t.x, t.z); }
          this.follow(e, dt); if (d.tur) e.ta = turnTo(e.ta, e.rot, 6 * dt);
        }
        break;
      }
      case O_GATHER: case O_BUILD: this.work(e, dt); break;
    }
    if (e.ord !== O_ATK && d.tur && e.mv) e.ta = turnTo(e.ta, e.rot, 6 * dt);
    this.sep(e, dt);
  }
  private turretIdle(e: Ent, dt: number, d: any) { if (d.tur) e.ta = turnTo(e.ta, e.rot, 3 * dt); }
  private startWork(e: Ent) {
    if (e.carry > 0) { e.ord = O_GATHER; e.gs = 2; return; }
    let bb: Ent | null = null, bd = 40;
    this.ents.forEach(b => { if (b.own === e.own && b.b && b.cons < 1 && b.hp > 0) { const dd = Math.hypot(b.x - e.x, b.z - e.z); if (dd < bd) { bd = dd; bb = b; } } });
    if (bb) { e.ord = O_BUILD; e.bid = (bb as Ent).id; return; }
    const m = this.findMine(e); if (m) { e.ord = O_GATHER; e.mid = m.id; e.gs = 0; }
  }
  private findMine(e: Ent): Ent | null {
    let best: Ent | null = null, bd = 1e9;
    this.ents.forEach(m => { if (m.mine && m.amt > 0) { const d = Math.hypot(m.x - e.x, m.z - e.z); if (d < bd) { bd = d; best = m; } } });
    return best;
  }
  private work(e: Ent, dt: number) {
    const p = this.players[e.own]; const fm = fmOf(p.fac);
    if (e.ord === O_BUILD) {
      const b = this.ents.get(e.bid);
      if (!b || b.hp <= 0 || b.cons >= 1) { e.ord = O_IDLE; return; }
      if (this.goTo(e, b.x, b.z, b.sz / 2 + 2.2, dt)) {
        e.rot = turnTo(e.rot, Math.atan2(b.x - e.x, b.z - e.z), 8 * dt); e.mv = false; e.atkT = 0;
        const inc = dt / (BLD[b.t].bt * fm.bt); b.cons = Math.min(1, b.cons + inc); b.hp = Math.min(b.mhp, b.hp + b.mhp * 0.9 * inc);
        if (b.cons >= 1) { b.cons = 1; this.emit({ k: 'x', x: b.x, y: 1, z: b.z, s: 1, f: 'dust' }); this.toast(b.own, 'اكتمل البناء ✔'); e.ord = O_IDLE; }
      }
      return;
    }
    // gather
    if (e.gs === 0) {
      let m = this.ents.get(e.mid); if (!m || !m.mine || m.amt <= 0) { m = this.findMine(e) || undefined; if (!m) { e.ord = O_IDLE; return; } e.mid = m.id; }
      if (this.goTo(e, m.x, m.z, 3.9, dt)) { e.gs = 1; e.gt = 2.2; }
    } else if (e.gs === 1) {
      const m = this.ents.get(e.mid); if (!m || !m.mine || m.amt <= 0) { e.gs = 0; return; }
      e.gt -= dt; e.atkT = 0; e.rot = turnTo(e.rot, Math.atan2(m.x - e.x, m.z - e.z), 8 * dt);
      if (e.gt <= 0) { const take = Math.min(Math.round(20 * fm.carry), m.amt); m.amt -= take; e.carry = take; e.gs = 2; if (m.amt <= 0) { this.emit({ k: 'x', x: m.x, y: 1, z: m.z, s: 1, f: 'dust' }); this.markB(m, -1); this.ents.delete(m.id); this.emit({ k: 'rm', id: m.id }); } }
    } else {
      let hq: Ent | null = null, bd = 1e9;
      this.ents.forEach(b => { if (b.own === e.own && b.t === 'hq' && b.hp > 0) { const dd = Math.hypot(b.x - e.x, b.z - e.z); if (dd < bd) { bd = dd; hq = b; } } });
      if (!hq) { e.ord = O_IDLE; return; }
      const h = hq as Ent;
      if (this.goTo(e, h.x, h.z, h.sz / 2 + 2.8, dt)) { const mul = p.ai >= 0 ? [0.8, 1, 1.25][p.ai] ?? 1 : 1; p.res += e.carry * mul; e.carry = 0; e.gs = 0; if (!this.ents.get(e.mid)) { const m = this.findMine(e); if (m) e.mid = m.id; else e.ord = O_IDLE; } }
    }
  }

  private updAir(e: Ent, d: any, p: Player, dt: number) {
    const alt = d.fw ? 15 : d.kami ? 9 : 7; e.y += (alt - e.y) * Math.min(1, dt * 1.2);
    const sp = e.spd * (p.buffT > 0 ? p.buffSpd : 1);
    let tgt: Ent | undefined = e.ord === O_ATK ? this.ents.get(e.tgt) : undefined;
    if (e.ord === O_ATK && (!tgt || tgt.hp <= 0 || tgt.own === e.own || !this.canHit(d, tgt))) { tgt = undefined; if (e.hasDst) { e.tgt = 0; e.ord = O_MOVE; } else { e.tgt = 0; e.ord = O_IDLE; } e.auto = false; }
    if (e.ord !== O_ATK && e.ord !== O_MOVE && e.scan <= 0) {
      e.scan = 0.5; const t = this.acquire(e, d, d.fw ? 34 : d.rng + 9); if (t) { e.tgt = t.id; e.ord = O_ATK; e.auto = true; e.hasDst = true; e.dstx = e.hx; e.dstz = e.hz; tgt = t; }
    }
    if (e.ord === O_ATK && tgt) {
      const dx = tgt.x - e.x, dz = tgt.z - e.z; const dist = Math.hypot(dx, dz); const aim = Math.atan2(dx, dz); const diff = angDiff(e.rot, aim);
      if (d.fw) {
        if (e.ov) { if (dist > 28) e.ov = false; } else { e.rot = turnTo(e.rot, aim, 1.9 * dt); if (dist < 12 && Math.abs(diff) > 1.3) e.ov = true; }
        e.x += Math.sin(e.rot) * sp * dt; e.z += Math.cos(e.rot) * sp * dt; e.mv = true;
        if (dist <= e.rng + 1 && Math.abs(diff) < (d.proj === 'bomb' ? 3.2 : 0.3) && e.cd <= 0) { e.cd = d.cd; this.fire(e, tgt, d); }
      } else {
        e.rot = turnTo(e.rot, aim, 4 * dt);
        if (d.kami) {
          e.x += Math.sin(e.rot) * sp * dt; e.z += Math.cos(e.rot) * sp * dt; e.mv = true;
          if (dist < 2) { this.pend.push({ at: this.time, x: e.x, z: e.z, y: 1, spl: d.spl, dmg: d.dmg * e.dm * (p.buffT > 0 ? p.buffDm : 1), own: e.own, tgt: tgt.id, w: d, ranged: false, bdm: fmOf(p.fac).bdm }); e.hp = 0; }
        } else if (dist > e.rng * 0.85) { e.x += Math.sin(aim) * sp * dt; e.z += Math.cos(aim) * sp * dt; e.mv = true; }
        else if (e.cd <= 0 && Math.abs(angDiff(e.rot, aim)) < 0.4) this.fire(e, tgt, d);
      }
    } else {
      const dx = e.hx - e.x, dz = e.hz - e.z; const dd = Math.hypot(dx, dz);
      if (e.ord === O_MOVE || e.ord === O_AMOVE) { e.hx = e.dstx; e.hz = e.dstz; if (dd < (d.fw ? 9 : 1)) { e.ord = O_IDLE; e.hasDst = false; } }
      if (d.fw) {
        if (dd > 18) e.rot = turnTo(e.rot, Math.atan2(dx, dz), 1.9 * dt); else e.rot += (sp / 14) * dt;
        e.x += Math.sin(e.rot) * sp * dt; e.z += Math.cos(e.rot) * sp * dt; e.mv = true;
      } else if (dd > 1) { const step = Math.min(dd, sp * dt); e.rot = turnTo(e.rot, Math.atan2(dx, dz), 4 * dt); e.x += dx / dd * step; e.z += dz / dd * step; e.mv = true; }
    }
    const h = this.half - 3; e.x = clamp(e.x, -h, h); e.z = clamp(e.z, -h, h);
    if (d.fw && (Math.abs(e.x) >= h || Math.abs(e.z) >= h)) e.rot = turnTo(e.rot, Math.atan2(-e.x, -e.z), 3 * dt);
  }

  private reap() {
    const dead: Ent[] = []; this.ents.forEach(e => { if (e.hp <= 0 && !e.mine) dead.push(e); });
    for (const e of dead) {
      this.ents.delete(e.id);
      const ud = UNITS[e.t]; const p = this.players[e.own];
      if (e.b) { this.markB(e, -1); this.emit({ k: 'x', x: e.x, y: 1.5, z: e.z, s: e.sz * 0.45, f: 'big' }); if (p) p.lost++; }
      else { this.emit({ k: 'x', x: e.x, y: e.y + 0.8, z: e.z, s: ud.cls === 'inf' || ud.cls === 'wk' ? 0.4 : ud.air ? 1.1 : 0.9, f: ud.cls === 'inf' || ud.cls === 'wk' ? 'dust' : 'boom' }); if (p) p.lost++; }
      this.emit({ k: 'rm', id: e.id });
    }
    for (const p of this.players) {
      if (!p.alive) continue; let hq = false; this.ents.forEach(e => { if (e.own === p.idx && e.t === 'hq' && e.hp > 0) hq = true; });
      if (!hq) {
        p.alive = false; this.toast(p.idx, 'تم تدمير مقرك!', true);
        this.ents.forEach(e => { if (e.own === p.idx) e.doom = 0.4 + this.rnd() * 5; });
        this.emit({ k: 'elim', i: p.idx });
      }
    }
  }
  private checkWin() {
    const alive = this.players.filter(p => p.alive); const humans = this.players.filter(p => p.alive && p.ai < 0);
    if (alive.length <= 1 || humans.length === 0) { this.over = true; this.winner = alive.length === 1 ? alive[0].idx : humans.length === 0 && alive.length ? alive[0].idx : -1; this.emit({ k: 'end', w: this.winner }); }
  }

  /* ---------- network snapshots ---------- */
  snapshot(): any {
    const u: any[] = [], b: any[] = [], m: any[] = [];
    this.ents.forEach(e => {
      if (e.mine) { m.push([e.id, Math.round(e.amt)]); return; }
      if (e.b) b.push([e.id, TI[e.t], e.own, Math.round(e.x * 10), Math.round(e.z * 10), Math.round(e.hp), Math.round(e.cons * 100), e.q.map(q => TI[q.u]), e.q.length ? Math.round(e.q[0].p * 100) : 0, Math.round(e.ta * 100), e.rot]);
      else u.push([e.id, TI[e.t], e.own, Math.round(e.x * 10), Math.round(e.z * 10), Math.round(e.rot * 100), Math.round(e.hp), Math.round(e.ta * 100), Math.round(e.y * 10), (e.mv ? 1 : 0) | (e.atkT < 0.35 ? 2 : 0)]);
    });
    const evs = this.evs; this.evs = [];
    return { t: 's', tm: Math.round(this.time * 10) / 10, p: this.players.map(p => [Math.round(p.res), p.pop, Math.round(p.pcd[0]), Math.round(p.pcd[1]), Math.round(p.buffT), p.alive ? 1 : 0]), u, b, m, e: evs };
  }
  applySnap(s: any) {
    this.time = s.tm; const seen = ++this.st;
    s.p.forEach((a: any[], i: number) => { const p = this.players[i]; if (!p) return; p.res = a[0]; p.pop = a[1]; p.pcd[0] = a[2]; p.pcd[1] = a[3]; p.buffT = a[4]; p.alive = !!a[5]; });
    const touch = (id: number, t: string, own: number, x: number, z: number) => { let e = this.ents.get(id); if (!e) e = this.spawn(t, own, x, z, id); e.seen = seen; return e; };
    for (const a of s.u) {
      const e = touch(a[0], TYPES[a[1]], a[2], a[3] / 10, a[4] / 10); e.x = a[3] / 10; e.z = a[4] / 10; e.rot = a[5] / 100; e.hp = a[6]; e.ta = a[7] / 100; e.y = a[8] / 10;
      e.mv = !!(a[9] & 1); if (a[9] & 2) e.atkT = 0; else if (e.atkT < 0.2) e.atkT = 9;
    }
    for (const a of s.b) {
      const e = touch(a[0], TYPES[a[1]], a[2], a[3] / 10, a[4] / 10); e.hp = a[5]; e.cons = a[6] / 100; e.q = a[7].map((ti: number, i: number) => ({ u: TYPES[ti], p: i === 0 ? a[8] / 100 : 0 })); e.ta = a[9] / 100;
    }
    for (const a of s.m) { const e = touch(a[0], 'mine', -1, 0, 0); e.amt = a[1]; }
    // mines need positions: they are created from the map on the client
    const gone: Ent[] = []; this.ents.forEach(e => { if (e.seen !== seen && !(e.mine && e.seen === 0)) gone.push(e); });
    for (const e of gone) { if (e.b || e.mine) this.markB(e, -1); this.ents.delete(e.id); }
    for (const ev of s.e) this.onEvent?.(ev);
  }
  initClientMines(ids: number[]) { /* ids order matches map.mines order on host spawn (ids 1..n) */ this.map.mines.forEach((m, i) => { const e = this.spawn('mine', -1, m.x, m.z, ids[i] ?? i + 1); e.amt = m.a; e.seen = 0; }); }
}
export type { FM };
