import * as THREE from "three";
import { TRACK, type TrackData } from "@/game/track";

export type WorldBundle = {
  dispose: () => void;
};

function rng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function asphaltCanvas(): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const g = c.getContext("2d");
  if (!g) return c;
  g.fillStyle = "#2c323a";
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 1800; i++) {
    const v = 30 + Math.floor(Math.random() * 28);
    g.fillStyle = `rgb(${v},${v},${v + 4})`;
    g.fillRect(Math.random() * 256, Math.random() * 256, 2, 2);
  }
  g.fillStyle = "#e8c27a";
  g.fillRect(10, 0, 8, 256);
  g.fillStyle = "#f4efe6";
  g.fillRect(238, 0, 8, 256);
  g.fillStyle = "#f4efe6";
  for (let y = 8; y < 256; y += 40) g.fillRect(124, y, 8, 18);
  return c;
}

function sandCanvas(): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 128;
  const g = c.getContext("2d");
  if (!g) return c;
  g.fillStyle = "#c4a36a";
  g.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 700; i++) {
    const v = 150 + Math.floor(Math.random() * 70);
    g.fillStyle = `rgb(${v},${Math.floor(v * 0.78)},${Math.floor(v * 0.48)})`;
    g.fillRect(Math.random() * 128, Math.random() * 128, 2, 2);
  }
  return c;
}

function skyCanvas(): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = 8;
  c.height = 256;
  const g = c.getContext("2d");
  if (!g) return c;
  const grd = g.createLinearGradient(0, 0, 0, 256);
  grd.addColorStop(0, "#070b14");
  grd.addColorStop(0.42, "#1b2744");
  grd.addColorStop(0.68, "#c46a3a");
  grd.addColorStop(0.82, "#5a342c");
  grd.addColorStop(1, "#14110f");
  g.fillStyle = grd;
  g.fillRect(0, 0, 8, 256);
  return c;
}

function checkerCanvas(): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 16;
  const g = c.getContext("2d");
  if (!g) return c;
  for (let i = 0; i < 16; i++) {
    g.fillStyle = i % 2 ? "#14161c" : "#f4efe6";
    g.fillRect(i * 8, 0, 8, 16);
  }
  return c;
}

function roadGeometry(track: TrackData): THREE.BufferGeometry {
  const N = track.samples.length;
  const half = track.halfRoad;
  const positions: number[] = [];
  const uvs: number[] = [];
  for (let i = 0; i <= N; i++) {
    const s = track.samples[i % N];
    const y = s.y + 0.05;
    positions.push(s.x - s.rx * half, y, s.z - s.rz * half, s.x + s.rx * half, y, s.z + s.rz * half);
    const v = (i === N ? track.length : s.dist) / 14;
    uvs.push(0, v, 1, v);
  }
  const indices: number[] = [];
  for (let i = 0; i < N; i++) {
    const a = i * 2;
    indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

function skirtGeometry(track: TrackData): THREE.BufferGeometry {
  const N = track.samples.length;
  const half = track.halfRoad;
  const positions: number[] = [];
  const indices: number[] = [];
  const pushWall = (sign: number) => {
    const base = positions.length / 3;
    for (let i = 0; i <= N; i++) {
      const s = track.samples[i % N];
      const x = s.x + s.rx * half * sign;
      const z = s.z + s.rz * half * sign;
      positions.push(x, s.y + 0.05, z, x, s.y - 1.15, z);
    }
    for (let i = 0; i < N; i++) {
      const a = base + i * 2;
      if (sign > 0) indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
      else indices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
    }
  };
  pushWall(1);
  pushWall(-1);
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

export function buildWorld(scene: THREE.Scene): WorldBundle {
  const track = TRACK;
  const textures: THREE.Texture[] = [];

  const skyTex = new THREE.CanvasTexture(skyCanvas());
  skyTex.colorSpace = THREE.SRGBColorSpace;
  textures.push(skyTex);
  const skyMat = new THREE.MeshBasicMaterial({ map: skyTex, side: THREE.BackSide, depthWrite: false, fog: false });
  skyMat.toneMapped = false;
  scene.add(new THREE.Mesh(new THREE.SphereGeometry(380, 28, 18), skyMat));

  const starPositions: number[] = [];
  const starRng = rng(9);
  for (let i = 0; i < 180; i++) {
    const th = starRng() * Math.PI * 2;
    const ph = starRng() * 1.1;
    const r = 300;
    starPositions.push(Math.cos(th) * Math.cos(ph) * r, 30 + Math.sin(ph) * r * 0.55, Math.sin(th) * r);
  }
  const starGeo = new THREE.BufferGeometry();
  starGeo.setAttribute("position", new THREE.Float32BufferAttribute(starPositions, 3));
  const starMat = new THREE.PointsMaterial({ color: "#f4efe6", size: 1.5, sizeAttenuation: false, fog: false });
  scene.add(new THREE.Points(starGeo, starMat));

  scene.add(new THREE.HemisphereLight("#ffc2a0", "#2a2420", 0.72));
  scene.add(new THREE.AmbientLight("#243044", 0.35));
  const moon = new THREE.DirectionalLight("#ffe0c2", 2.15);
  moon.position.set(48, 72, 26);
  moon.castShadow = true;
  moon.shadow.mapSize.set(1024, 1024);
  moon.shadow.camera.left = -150;
  moon.shadow.camera.right = 150;
  moon.shadow.camera.top = 120;
  moon.shadow.camera.bottom = -120;
  moon.shadow.camera.near = 10;
  moon.shadow.camera.far = 220;
  moon.shadow.bias = -0.0004;
  moon.shadow.normalBias = 0.05;
  scene.add(moon);
  const fill = new THREE.DirectionalLight("#8fb4ff", 0.55);
  fill.position.set(-40, 24, -18);
  scene.add(fill);

  scene.fog = new THREE.Fog("#3a2c32", 55, 210);
  scene.background = new THREE.Color("#1a140f");

  const sandTex = new THREE.CanvasTexture(sandCanvas());
  sandTex.colorSpace = THREE.SRGBColorSpace;
  sandTex.wrapS = THREE.RepeatWrapping;
  sandTex.wrapT = THREE.RepeatWrapping;
  sandTex.repeat.set(28, 28);
  textures.push(sandTex);
  const ground = new THREE.Mesh(
    new THREE.CircleGeometry(420, 48),
    new THREE.MeshStandardMaterial({ map: sandTex, color: "#c4a36a", roughness: 1, metalness: 0 }),
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -3;
  ground.receiveShadow = true;
  scene.add(ground);

  const roadTex = new THREE.CanvasTexture(asphaltCanvas());
  roadTex.colorSpace = THREE.SRGBColorSpace;
  roadTex.wrapS = THREE.RepeatWrapping;
  roadTex.wrapT = THREE.RepeatWrapping;
  roadTex.anisotropy = 8;
  textures.push(roadTex);
  const road = new THREE.Mesh(
    roadGeometry(track),
    new THREE.MeshStandardMaterial({ map: roadTex, roughness: 0.92, metalness: 0.04 }),
  );
  road.receiveShadow = true;
  scene.add(road);
  const skirt = new THREE.Mesh(
    skirtGeometry(track),
    new THREE.MeshStandardMaterial({ color: "#1c2028", roughness: 0.95, metalness: 0.05 }),
  );
  skirt.receiveShadow = true;
  scene.add(skirt);

  const rand = rng(42);
  const duneMat = new THREE.MeshStandardMaterial({ color: "#d7b273", roughness: 1, metalness: 0 });
  const dunes = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 18, 12), duneMat, 14);
  const dummy = new THREE.Object3D();
  for (let i = 0; i < 14; i++) {
    const s = track.samples[Math.floor(rand() * track.samples.length)];
    const radius = 9 + rand() * 12;
    const side = rand() > 0.5 ? 1 : -1;
    const offset = 24 + rand() * 36;
    dummy.position.set(s.x + s.rx * side * offset, -3 + radius * 0.4, s.z + s.rz * side * offset);
    dummy.scale.set(radius * (0.85 + rand() * 0.4), radius * 0.55, radius);
    dummy.rotation.set(0, rand() * 3, 0);
    dummy.updateMatrix();
    dunes.setMatrixAt(i, dummy.matrix);
  }
  dunes.receiveShadow = true;
  scene.add(dunes);

  const cactusMat = new THREE.MeshStandardMaterial({ color: "#1d3d34", roughness: 0.85 });
  const cacti = new THREE.InstancedMesh(new THREE.ConeGeometry(0.55, 2.4, 7), cactusMat, 36);
  for (let i = 0; i < 36; i++) {
    const s = track.samples[(i * 17) % track.samples.length];
    const side = i % 2 === 0 ? 1 : -1;
    const offset = 16 + rand() * 14;
    dummy.position.set(s.x + s.rx * side * offset, -1.8, s.z + s.rz * side * offset);
    dummy.scale.set(1, 0.8 + rand(), 1);
    dummy.rotation.set(0, 0, 0);
    dummy.updateMatrix();
    cacti.setMatrixAt(i, dummy.matrix);
  }
  scene.add(cacti);

  const rockMat = new THREE.MeshStandardMaterial({ color: "#6d645c", roughness: 0.95 });
  const rocks = new THREE.InstancedMesh(new THREE.DodecahedronGeometry(1, 0), rockMat, 28);
  for (let i = 0; i < 28; i++) {
    const s = track.samples[(i * 23 + 5) % track.samples.length];
    const side = i % 2 === 0 ? -1 : 1;
    const offset = 14 + rand() * 10;
    const sc = 0.5 + rand() * 1.1;
    dummy.position.set(s.x + s.rx * side * offset, -2.4 + sc * 0.3, s.z + s.rz * side * offset);
    dummy.scale.set(sc, sc * 0.7, sc * 1.2);
    dummy.rotation.set(rand(), rand(), rand());
    dummy.updateMatrix();
    rocks.setMatrixAt(i, dummy.matrix);
  }
  scene.add(rocks);

  const trunkMat = new THREE.MeshStandardMaterial({ color: "#6b4a32", roughness: 0.9 });
  const crownMat = new THREE.MeshStandardMaterial({ color: "#1c6844", roughness: 0.8 });
  const trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.18, 0.28, 2.2, 6), trunkMat, 18);
  const crowns = new THREE.InstancedMesh(new THREE.SphereGeometry(0.85, 8, 6), crownMat, 18);
  for (let i = 0; i < 18; i++) {
    const s = track.samples[(i * 19 + 3) % track.samples.length];
    const side = i % 2 === 0 ? 1 : -1;
    const offset = 18 + (i % 4);
    const x = s.x + s.rx * side * offset;
    const z = s.z + s.rz * side * offset;
    dummy.position.set(x, -1.9, z);
    dummy.scale.set(1, 1, 1);
    dummy.rotation.set(0, 0, 0);
    dummy.updateMatrix();
    trunks.setMatrixAt(i, dummy.matrix);
    dummy.position.set(x, -0.4, z);
    dummy.scale.set(1.1, 0.7, 1.1);
    dummy.updateMatrix();
    crowns.setMatrixAt(i, dummy.matrix);
  }
  scene.add(trunks, crowns);

  const mesaMat = new THREE.MeshStandardMaterial({ color: "#2c2430", roughness: 1 });
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    const mesh = new THREE.Mesh(new THREE.ConeGeometry(26, 16, 5), mesaMat);
    mesh.position.set(Math.cos(a) * 210, 2, Math.sin(a) * 210);
    scene.add(mesh);
  }

  const nearCp = (i: number) =>
    track.checkpoints.some((c) => {
      const d = Math.abs(i - c);
      return Math.min(d, track.samples.length - d) < 3;
    });

  let barrierCount = 0;
  for (let i = 0; i < track.samples.length; i += 2) {
    if (!nearCp(i)) barrierCount += 2;
  }
  const barrierMat = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.72, metalness: 0.05 });
  const barriers = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), barrierMat, barrierCount);
  const white = new THREE.Color("#f4efe6");
  const red = new THREE.Color("#c2412d");
  let n = 0;
  for (let i = 0; i < track.samples.length; i += 2) {
    if (nearCp(i)) continue;
    const s = track.samples[i];
    for (const side of [1, -1]) {
      const x = s.x + s.rx * side * (track.wall - 0.15);
      const z = s.z + s.rz * side * (track.wall - 0.15);
      dummy.position.set(x, s.y + 0.38, z);
      dummy.lookAt(x + s.tx, s.y + 0.38, z + s.tz);
      dummy.scale.set(0.42, 0.72, 1.35);
      dummy.updateMatrix();
      barriers.setMatrixAt(n, dummy.matrix);
      barriers.setColorAt(n, (i + side) % 4 === 0 ? white : red);
      n += 1;
    }
  }
  if (barriers.instanceColor) barriers.instanceColor.needsUpdate = true;
  barriers.receiveShadow = true;
  scene.add(barriers);

  const archMat = new THREE.MeshStandardMaterial({
    color: "#12383a",
    emissive: "#3ee0c5",
    emissiveIntensity: 0.9,
    roughness: 0.4,
    metalness: 0.2,
  });
  const checkerTex = new THREE.CanvasTexture(checkerCanvas());
  checkerTex.colorSpace = THREE.SRGBColorSpace;
  checkerTex.magFilter = THREE.NearestFilter;
  textures.push(checkerTex);
  const finishMat = new THREE.MeshStandardMaterial({ map: checkerTex, roughness: 0.6, metalness: 0.05 });
  const pillar = new THREE.BoxGeometry(0.45, 1, 0.45);
  const bar = new THREE.BoxGeometry(1, 0.32, 0.36);
  track.checkpoints.forEach((idx, ci) => {
    const s = track.samples[idx];
    const group = new THREE.Group();
    group.position.set(s.x, s.y, s.z);
    group.rotation.y = Math.atan2(-s.tx, -s.tz) + Math.PI;
    const h = ci === 0 ? 4.3 : 3.35;
    const span = 12.2;
    const mat = ci === 0 ? finishMat : archMat;
    const left = new THREE.Mesh(pillar, mat);
    left.scale.set(1, h, 1);
    left.position.set(-span, h / 2, 0);
    const rightP = new THREE.Mesh(pillar, mat);
    rightP.scale.set(1, h, 1);
    rightP.position.set(span, h / 2, 0);
    const top = new THREE.Mesh(bar, mat);
    top.scale.set(span * 2, 1, 1);
    top.position.set(0, h, 0);
    group.add(left, rightP, top);
    scene.add(group);
  });

  return {
    dispose() {
      for (const t of textures) t.dispose();
      const seenGeo = new Set<THREE.BufferGeometry>();
      const seenMat = new Set<THREE.Material>();
      scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        const points = obj as THREE.Points;
        if (!mesh.isMesh && !points.isPoints) return;
        const geo = mesh.geometry;
        if (geo && !seenGeo.has(geo)) {
          seenGeo.add(geo);
          geo.dispose();
        }
        const mat = mesh.material;
        const mats = Array.isArray(mat) ? mat : mat ? [mat] : [];
        for (const m of mats) {
          if (!seenMat.has(m)) {
            seenMat.add(m);
            m.dispose();
          }
        }
      });
    },
  };
}
