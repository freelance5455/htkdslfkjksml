import * as THREE from 'three';
import { MAP_RADIUS, WATER_LEVEL } from './constants';
import { fbm } from './noise';

/** Axis-aligned solid block (walls, crates). Blocks movement and bullets between y0 and y1. */
export interface Box {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  y0: number;
  y1: number;
}

/** Vertical cylinder obstacle (trees, big rocks). */
export interface Prop {
  x: number;
  z: number;
  r: number;
  h: number;
}

interface Pad {
  x: number;
  z: number;
  r: number;
  h: number;
}

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
const smooth = (a: number, b: number, x: number) => {
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

let pads: Pad[] = [];

function rawHeight(x: number, z: number): number {
  const d = Math.hypot(x, z) / MAP_RADIUS;
  let h = (fbm(x * 0.016 + 21.3, z * 0.016 - 9.1, 5) - 0.42) * 46;
  h += (fbm(x * 0.07, z * 0.07, 2) - 0.5) * 3;
  h += 6 - 8 * d * d;
  return lerp(h, -10, smooth(0.7, 1.02, d));
}

/** Ground height in metres. Flattened pads under buildings keep floors level. */
export function terrainHeight(x: number, z: number): number {
  let h = rawHeight(x, z);
  for (const p of pads) {
    const d = Math.hypot(x - p.x, z - p.z);
    if (d < p.r) h = lerp(p.h, h, smooth(p.r * 0.55, p.r, d));
  }
  return h;
}

export interface Spot {
  x: number;
  y: number;
  z: number;
}

const SHELL = 0.3;
const WALL_H = 3.2;
const DOOR = 1.4;

export class World {
  readonly group = new THREE.Group();
  readonly boxes: Box[] = [];
  readonly props: Prop[] = [];
  readonly lootSpots: Spot[] = [];
  private houses: { x: number; z: number; w: number; d: number; y: number }[] = [];

  constructor() {
    pads = [];
    this.planHouses();
    this.buildTerrain();
    this.buildWater();
    this.buildHouses();
    this.buildCover();
    this.buildTreesAndRocks();
  }

  groundAt(x: number, z: number): number {
    return terrainHeight(x, z);
  }

  private planHouses() {
    let tries = 0;
    while (this.houses.length < 7 && tries++ < 500) {
      const a = Math.random() * Math.PI * 2;
      const r = Math.sqrt(Math.random()) * MAP_RADIUS * 0.7;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      const h = rawHeight(x, z);
      if (h < 3 || h > 20) continue;
      if (this.houses.some((o) => Math.hypot(o.x - x, o.z - z) < 32)) continue;
      const w = 8 + Math.random() * 3;
      const d = 6.5 + Math.random() * 2.5;
      this.houses.push({ x, z, w, d, y: h });
      pads.push({ x, z, r: Math.max(w, d) * 0.75 + 6, h });
    }
  }

  private buildTerrain() {
    const size = (MAP_RADIUS + 14) * 2;
    const seg = 180;
    const geo = new THREE.PlaneGeometry(size, size, seg, seg);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      pos.setY(i, terrainHeight(pos.getX(i), pos.getZ(i)));
    }
    geo.computeVertexNormals();
    const nrm = geo.attributes.normal as THREE.BufferAttribute;

    const colors = new Float32Array(pos.count * 3);
    const c = new THREE.Color();
    const grassA = new THREE.Color('#2c5424');
    const grassB = new THREE.Color('#6b8c3a');
    const dry = new THREE.Color('#8e7d4b');
    const rock = new THREE.Color('#6d6860');
    const sand = new THREE.Color('#d8c48d');
    const dirt = new THREE.Color('#68543a');
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const h = pos.getY(i);
      const slope = 1 - nrm.getY(i);
      c.copy(grassA).lerp(grassB, fbm(x * 0.05 + 3, z * 0.05, 3));
      c.lerp(dry, smooth(0.55, 0.75, fbm(x * 0.03 + 9, z * 0.03, 2)) * 0.5);
      if (fbm(x * 0.12 + 5, z * 0.12 - 2, 2) > 0.62) c.lerp(dirt, 0.45);
      c.lerp(rock, smooth(0.28, 0.5, slope));
      if (h > 26) c.lerp(rock, smooth(26, 30, h));
      c.lerp(sand, 1 - smooth(0.8, 2.2, h));
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.93 }));
    mesh.receiveShadow = true;
    this.group.add(mesh);
  }

  private buildWater() {
    const water = new THREE.Mesh(
      new THREE.CircleGeometry(900, 48),
      new THREE.MeshStandardMaterial({ color: 0x1b5d78, roughness: 0.18, metalness: 0.05, transparent: true, opacity: 0.94 }),
    );
    water.rotation.x = -Math.PI / 2;
    water.position.y = WATER_LEVEL - 0.2;
    this.group.add(water);
  }

  private addBox(minX: number, maxX: number, minZ: number, maxZ: number, y0: number, y1: number, mat: THREE.Material, receiveShadow = true) {
    this.boxes.push({ minX, maxX, minZ, maxZ, y0, y1 });
    const geo = new THREE.BoxGeometry(maxX - minX, y1 - y0, maxZ - minZ);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set((minX + maxX) / 2, (y0 + y1) / 2, (minZ + maxZ) / 2);
    mesh.castShadow = true;
    mesh.receiveShadow = receiveShadow;
    this.group.add(mesh);
  }

  private buildHouses() {
    const wallMats = [
      new THREE.MeshStandardMaterial({ color: 0xd8cfbc, roughness: 0.9 }),
      new THREE.MeshStandardMaterial({ color: 0x8a6a48, roughness: 0.85 }),
      new THREE.MeshStandardMaterial({ color: 0xb9b1a0, roughness: 0.9 }),
    ];
    const floorMat = new THREE.MeshStandardMaterial({ color: 0x5b4a3a, roughness: 0.8 });
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x3b3f46, roughness: 0.7, metalness: 0.2 });

    for (const h of this.houses) {
      const { x: cx, z: cz, w, d, y } = h;
      const mat = wallMats[Math.floor(Math.random() * wallMats.length)];
      const y1 = y + WALL_H;
      // Walls with a door gap on the south side.
      this.addBox(cx - w / 2, cx + w / 2, cz - d / 2, cz - d / 2 + SHELL, y, y1, mat);
      this.addBox(cx - w / 2, cx - w / 2 + SHELL, cz - d / 2 + SHELL, cz + d / 2 - SHELL, y, y1, mat);
      this.addBox(cx + w / 2 - SHELL, cx + w / 2, cz - d / 2 + SHELL, cz + d / 2 - SHELL, y, y1, mat);
      this.addBox(cx - w / 2, cx - DOOR / 2, cz + d / 2 - SHELL, cz + d / 2, y, y1, mat);
      this.addBox(cx + DOOR / 2, cx + w / 2, cz + d / 2 - SHELL, cz + d / 2, y, y1, mat);

      const floor = new THREE.Mesh(new THREE.BoxGeometry(w - SHELL * 2, 0.12, d - SHELL * 2), floorMat);
      floor.position.set(cx, y + 0.06, cz);
      floor.receiveShadow = true;
      this.group.add(floor);

      const roof = new THREE.Mesh(new THREE.BoxGeometry(w + 0.7, 0.35, d + 0.7), roofMat);
      roof.position.set(cx, y1 + 0.17, cz);
      roof.castShadow = true;
      this.group.add(roof);

      this.lootSpots.push({ x: cx - w / 4, y: y + 0.1, z: cz + 0.6 }, { x: cx + w / 4, y: y + 0.1, z: cz - 0.8 });
    }
  }

  private buildCover() {
    const palette = [0xc2410c, 0x0f766e, 0x7c2d12, 0x475569, 0x854d0e, 0x3f6212];
    let placed = 0;
    let tries = 0;
    while (placed < 28 && tries++ < 800) {
      const a = Math.random() * Math.PI * 2;
      const r = Math.sqrt(Math.random()) * MAP_RADIUS * 0.8;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      const h = terrainHeight(x, z);
      if (h < 2.5 || this.inHousePad(x, z, 3)) continue;
      const sx = 1.2 + Math.random() * 1.2;
      const sz = 1.2 + Math.random() * 1.2;
      const hh = 1.0 + Math.random() * 0.7;
      const mat = new THREE.MeshStandardMaterial({ color: palette[Math.floor(Math.random() * palette.length)], roughness: 0.7, metalness: 0.2 });
      this.addBox(x - sx / 2, x + sx / 2, z - sz / 2, z + sz / 2, h, h + hh, mat);
      placed++;
    }
  }

  private inHousePad(x: number, z: number, extra = 0): boolean {
    for (const p of pads) {
      if (Math.hypot(x - p.x, z - p.z) < p.r + extra) return true;
    }
    return false;
  }

  private buildTreesAndRocks() {
    const dummy = new THREE.Object3D();
    const conifers: { x: number; y: number; z: number; s: number }[] = [];
    const broadleafs: { x: number; y: number; z: number; s: number }[] = [];
    let tries = 0;
    while (conifers.length + broadleafs.length < 520 && tries++ < 4000) {
      const a = Math.random() * Math.PI * 2;
      const r = Math.sqrt(Math.random()) * MAP_RADIUS * 0.95;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      const h = terrainHeight(x, z);
      if (h < 2.2 || h > 24) continue;
      if (Math.abs(terrainHeight(x + 1.5, z) - h) + Math.abs(terrainHeight(x, z + 1.5) - h) > 1.6) continue;
      if (this.inHousePad(x, z, 4)) continue;
      if (this.props.some((p) => Math.hypot(p.x - x, p.z - z) < 3)) continue;
      const s = 0.8 + Math.random() * 0.9;
      const tree = { x, y: h, z, s };
      if (Math.random() < 0.6) conifers.push(tree);
      else broadleafs.push(tree);
      this.props.push({ x, z, r: 0.42 * s, h: 6 * s });
    }

    const trunkGeo = new THREE.CylinderGeometry(0.11, 0.17, 1, 6);
    trunkGeo.translate(0, 0.5, 0);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a3626, roughness: 0.95 });
    const all = [...conifers, ...broadleafs];
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, all.length);
    trunks.castShadow = true;
    trunks.receiveShadow = true;
    const trunkH = (i: number) => (i < conifers.length ? 2.2 : 2.6);
    all.forEach((t, i) => {
      dummy.position.set(t.x, t.y, t.z);
      dummy.scale.set(t.s, trunkH(i) * t.s, t.s);
      dummy.rotation.set(0, Math.random() * 6, 0);
      dummy.updateMatrix();
      trunks.setMatrixAt(i, dummy.matrix);
    });
    trunks.instanceMatrix.needsUpdate = true;
    this.group.add(trunks);

    const coniferGeo = new THREE.ConeGeometry(1.4, 4.2, 7);
    coniferGeo.translate(0, 2.1, 0);
    const coniferMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 });
    const coniferMesh = new THREE.InstancedMesh(coniferGeo, coniferMat, conifers.length);
    coniferMesh.castShadow = true;
    conifers.forEach((t, i) => {
      dummy.position.set(t.x, t.y + 2.2 * t.s - 0.5, t.z);
      dummy.scale.setScalar(t.s);
      dummy.rotation.set(0, Math.random() * 6, 0);
      dummy.updateMatrix();
      coniferMesh.setMatrixAt(i, dummy.matrix);
      coniferMesh.setColorAt(i, new THREE.Color().setHSL(0.3 + Math.random() * 0.05, 0.45, 0.16 + Math.random() * 0.08));
    });
    coniferMesh.instanceMatrix.needsUpdate = true;
    if (coniferMesh.instanceColor) coniferMesh.instanceColor.needsUpdate = true;
    this.group.add(coniferMesh);

    const broadGeo = new THREE.IcosahedronGeometry(1.6, 1);
    const broadMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.85, flatShading: true });
    const broadMesh = new THREE.InstancedMesh(broadGeo, broadMat, broadleafs.length);
    broadMesh.castShadow = true;
    broadleafs.forEach((t, i) => {
      dummy.position.set(t.x, t.y + 2.7 * t.s + 0.6, t.z);
      dummy.scale.setScalar(t.s * (0.9 + Math.random() * 0.3));
      dummy.rotation.set(Math.random(), Math.random(), 0);
      dummy.updateMatrix();
      broadMesh.setMatrixAt(i, dummy.matrix);
      broadMesh.setColorAt(i, new THREE.Color().setHSL(0.24 + Math.random() * 0.06, 0.5, 0.22 + Math.random() * 0.1));
    });
    broadMesh.instanceMatrix.needsUpdate = true;
    if (broadMesh.instanceColor) broadMesh.instanceColor.needsUpdate = true;
    this.group.add(broadMesh);

    // Rocks
    const rockCount = 110;
    const rockGeo = new THREE.IcosahedronGeometry(1, 0);
    const rp = rockGeo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < rp.count; i++) {
      const k = 0.8 + Math.random() * 0.4;
      rp.setXYZ(i, rp.getX(i) * k, rp.getY(i) * k * 0.7, rp.getZ(i) * k);
    }
    rockGeo.computeVertexNormals();
    const rockMat = new THREE.MeshStandardMaterial({ color: 0x77736b, roughness: 0.95, flatShading: true });
    const rocks = new THREE.InstancedMesh(rockGeo, rockMat, rockCount);
    rocks.castShadow = true;
    rocks.receiveShadow = true;
    let placed = 0;
    tries = 0;
    while (placed < rockCount && tries++ < 3000) {
      const a = Math.random() * Math.PI * 2;
      const r = Math.sqrt(Math.random()) * MAP_RADIUS * 0.92;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      const h = terrainHeight(x, z);
      if (h < 1.2 || this.inHousePad(x, z, 3)) continue;
      const s = 0.5 + Math.random() * 1.7;
      dummy.position.set(x, h + s * 0.1, z);
      dummy.scale.set(s, s * (0.6 + Math.random() * 0.3), s);
      dummy.rotation.set(Math.random(), Math.random() * 6, Math.random());
      dummy.updateMatrix();
      rocks.setMatrixAt(placed, dummy.matrix);
      if (s > 1.2) this.props.push({ x, z, r: s * 0.85, h: s * 0.9 });
      placed++;
    }
    rocks.count = placed;
    rocks.instanceMatrix.needsUpdate = true;
    this.group.add(rocks);
  }

  /** Random walkable spot on land, away from solid objects. */
  randomLand(): Spot {
    for (let i = 0; i < 400; i++) {
      const a = Math.random() * Math.PI * 2;
      const r = Math.sqrt(Math.random()) * MAP_RADIUS * 0.8;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      const y = terrainHeight(x, z);
      if (y < 2.5) continue;
      if (this.blocked(x, z, PLAYER_CLEAR)) continue;
      return { x, y, z };
    }
    return { x: 0, y: terrainHeight(0, 0), z: 0 };
  }

  private blocked(x: number, z: number, r: number): boolean {
    for (const p of this.props) {
      if (Math.hypot(p.x - x, p.z - z) < p.r + r) return true;
    }
    for (const b of this.boxes) {
      if (x > b.minX - r && x < b.maxX + r && z > b.minZ - r && z < b.maxZ + r) return true;
    }
    return false;
  }

  /** Pushes a circle (radius r at height y) out of props, boxes and the map edge. */
  resolve(x: number, z: number, r: number, y: number): [number, number] {
    for (const p of this.props) {
      const dx = x - p.x;
      const dz = z - p.z;
      const minD = p.r + r;
      const d2 = dx * dx + dz * dz;
      if (d2 < minD * minD && d2 > 1e-8) {
        const d = Math.sqrt(d2);
        const push = minD - d;
        x += (dx / d) * push;
        z += (dz / d) * push;
      }
    }
    for (const b of this.boxes) {
      if (b.y1 < y + 0.25 || b.y0 > y + 1.7) continue;
      const cx = Math.min(Math.max(x, b.minX), b.maxX);
      const cz = Math.min(Math.max(z, b.minZ), b.maxZ);
      const dx = x - cx;
      const dz = z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        if (d2 > 1e-8) {
          const d = Math.sqrt(d2);
          const push = r - d;
          x += (dx / d) * push;
          z += (dz / d) * push;
        } else {
          // Centre inside the box: push out through the nearest face.
          const left = x - b.minX;
          const right = b.maxX - x;
          const back = z - b.minZ;
          const front = b.maxZ - z;
          const m = Math.min(left, right, back, front);
          if (m === left) x = b.minX - r;
          else if (m === right) x = b.maxX + r;
          else if (m === back) z = b.minZ - r;
          else z = b.maxZ + r;
        }
      }
    }
    const lim = MAP_RADIUS * 0.97 - r;
    const d = Math.hypot(x, z);
    if (d > lim) {
      x = (x / d) * lim;
      z = (z / d) * lim;
    }
    return [x, z];
  }

  /**
   * Distance along a ray to the first solid surface (terrain, boxes, props),
   * or `max` if nothing is hit. Direction must be normalized.
   */
  rayHit(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, max: number): number {
    let best = max;
    const ix = Math.abs(dx) < 1e-9 ? 1e9 : 1 / dx;
    const iy = Math.abs(dy) < 1e-9 ? 1e9 : 1 / dy;
    const iz = Math.abs(dz) < 1e-9 ? 1e9 : 1 / dz;

    for (const b of this.boxes) {
      let t1 = (b.minX - ox) * ix;
      let t2 = (b.maxX - ox) * ix;
      let tmin = Math.min(t1, t2);
      let tmax = Math.max(t1, t2);
      t1 = (b.y0 - oy) * iy;
      t2 = (b.y1 - oy) * iy;
      tmin = Math.max(tmin, Math.min(t1, t2));
      tmax = Math.min(tmax, Math.max(t1, t2));
      t1 = (b.minZ - oz) * iz;
      t2 = (b.maxZ - oz) * iz;
      tmin = Math.max(tmin, Math.min(t1, t2));
      tmax = Math.min(tmax, Math.max(t1, t2));
      if (tmax >= tmin && tmin > 0 && tmin < best) best = tmin;
    }

    for (const p of this.props) {
      const fx = ox - p.x;
      const fz = oz - p.z;
      const a = dx * dx + dz * dz;
      if (a < 1e-9) continue;
      const b = 2 * (fx * dx + fz * dz);
      const c = fx * fx + fz * fz - p.r * p.r;
      const disc = b * b - 4 * a * c;
      if (disc < 0) continue;
      const s = Math.sqrt(disc);
      let t = (-b - s) / (2 * a);
      if (t < 0) t = (-b + s) / (2 * a);
      if (t < 0 || t >= best) continue;
      const yHit = oy + dy * t;
      if (yHit <= p.h && yHit >= -0.5) best = t;
    }

    // Terrain: march the ray in coarse steps and detect the first sample below ground.
    const step = 0.5;
    for (let t = step; t < best; t += step) {
      const x = ox + dx * t;
      const y = oy + dy * t;
      const z = oz + dz * t;
      if (y < terrainHeight(x, z)) {
        best = Math.max(0, t - step);
        break;
      }
    }
    return best;
  }

  dispose() {
    this.group.traverse((obj) => {
      const m = obj as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
      const mat = m.material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
      else mat?.dispose();
    });
    pads = [];
  }
}

const PLAYER_CLEAR = 1.2;
