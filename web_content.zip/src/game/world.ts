/* Procedural terrain and prop illustration for سراب. Everything is drawn on
   canvas so the world stays crisp, lightweight and fully offline. */

export const WORLD = { w: 2400, h: 1700 };
export const CAMP = { x: 1180, y: 1035 };
export const OASIS = { x: 690, y: 700, rx: 258, ry: 178 };
export const RIVER = { x: 1745, y: 1385, rx: 155, ry: 86 };
export const RUINS = { x: 1770, y: 505 };
export const ARCH = { x: 1980, y: 1230 };

export const SHRINES = [
  { x: 935, y: 905, name: "ضريح الواحة", short: "الواحة" },
  { x: 1690, y: 635, name: "ضريح الأطلال", short: "الأطلال" },
  { x: 1965, y: 1090, name: "ضريح القوس", short: "القوس" },
] as const;

export type PropKind = "palm" | "rock" | "reed" | "shrub" | "column" | "bones" | "tent" | "pot";

export interface Prop {
  kind: PropKind;
  x: number;
  y: number;
  s: number;
  v: number;
}

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const PALMS: Array<[number, number, number, number]> = [
  [470, 565, 1.18, 0],
  [610, 520, 0.94, 1],
  [838, 515, 1.08, 2],
  [965, 625, 0.86, 3],
  [462, 812, 1.02, 4],
  [566, 900, 0.82, 5],
  [890, 848, 1.16, 6],
  [1005, 962, 0.78, 7],
  [1058, 916, 0.9, 8],
  [1328, 985, 1.06, 9],
  [742, 1305, 0.92, 10],
  [1638, 430, 1.02, 11],
  [1888, 1450, 0.96, 12],
  [1562, 1430, 0.88, 13],
  [283, 1370, 1.0, 14],
  [2105, 690, 0.9, 15],
  [1150, 1460, 1.08, 16],
];

const COLUMNS: Array<[number, number, number]> = [
  [1600, 565, 0.9],
  [1660, 430, 0.7],
  [1900, 585, 1.05],
  [1958, 430, 0.8],
  [1565, 458, 0.62],
];

function inCamp(x: number, y: number, r = 185) {
  return Math.hypot(x - CAMP.x, y - CAMP.y) < r;
}

function nearShrine(x: number, y: number, r = 95) {
  return SHRINES.some((s) => Math.hypot(x - s.x, y - s.y) < r);
}

export function createProps(): Prop[] {
  const props: Prop[] = [];
  PALMS.forEach(([x, y, s, v]) => props.push({ kind: "palm", x, y, s, v }));
  COLUMNS.forEach(([x, y, s], i) => props.push({ kind: "column", x, y, s, v: i }));

  // Camp dressing
  props.push({ kind: "tent", x: CAMP.x - 155, y: CAMP.y + 42, s: 1, v: 0 });
  props.push({ kind: "tent", x: CAMP.x + 158, y: CAMP.y + 26, s: 0.82, v: 1 });
  props.push({ kind: "pot", x: CAMP.x - 74, y: CAMP.y + 78, s: 0.9, v: 0 });
  props.push({ kind: "pot", x: CAMP.x + 82, y: CAMP.y + 70, s: 0.7, v: 1 });

  const rnd = mulberry32(880211);

  for (let i = 0; i < 78; i++) {
    const x = 95 + rnd() * (WORLD.w - 190);
    const y = 100 + rnd() * (WORLD.h - 200);
    if (inCamp(x, y, 215) || nearShrine(x, y, 105)) continue;
    const inOasis = ((x - OASIS.x) / (OASIS.rx + 40)) ** 2 + ((y - OASIS.y) / (OASIS.ry + 30)) ** 2 < 1;
    if (inOasis) continue;
    props.push({
      kind: "rock",
      x,
      y,
      s: 0.45 + rnd() * 0.85,
      v: Math.floor(rnd() * 4),
    });
  }

  for (let i = 0; i < 62; i++) {
    const a = rnd() * Math.PI * 2;
    const x = CAMP.x + Math.cos(a) * (240 + rnd() * 860);
    const y = CAMP.y + Math.sin(a) * (220 + rnd() * 560);
    if (x < 70 || y < 70 || x > WORLD.w - 70 || y > WORLD.h - 70) continue;
    if (nearShrine(x, y, 80) || inCamp(x, y, 200)) continue;
    props.push({ kind: "shrub", x, y, s: 0.6 + rnd() * 0.7, v: Math.floor(rnd() * 3) });
  }

  for (let i = 0; i < 28; i++) {
    const a = (i / 28) * Math.PI * 2;
    const x = OASIS.x + Math.cos(a) * OASIS.rx * (0.98 + rnd() * 0.14);
    const y = OASIS.y + Math.sin(a) * OASIS.ry * (1.02 + rnd() * 0.16);
    props.push({ kind: "reed", x, y, s: 0.7 + rnd() * 0.6, v: Math.floor(rnd() * 3) });
  }

  for (let i = 0; i < 12; i++) {
    const a = rnd() * Math.PI * 2;
    props.push({
      kind: "bones",
      x: RUINS.x + Math.cos(a) * (80 + rnd() * 135),
      y: RUINS.y + Math.sin(a) * (60 + rnd() * 100),
      s: 0.6 + rnd() * 0.5,
      v: Math.floor(rnd() * 2),
    });
  }

  return props;
}

function dune(ctx: CanvasRenderingContext2D, y: number, amp: number, width: number, light: string, shade: string) {
  ctx.beginPath();
  ctx.moveTo(-40, y);
  ctx.bezierCurveTo(WORLD.w * 0.22, y - amp, WORLD.w * 0.42, y + amp, WORLD.w * 0.63, y - amp * 0.35);
  ctx.bezierCurveTo(WORLD.w * 0.82, y - amp * 1.1, WORLD.w * 0.9, y + amp * 0.5, WORLD.w + 60, y - amp * 0.3);
  ctx.strokeStyle = light;
  ctx.lineWidth = width;
  ctx.lineCap = "round";
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-40, y + 5);
  ctx.bezierCurveTo(WORLD.w * 0.22, y - amp + 5, WORLD.w * 0.42, y + amp + 5, WORLD.w * 0.63, y - amp * 0.35 + 5);
  ctx.bezierCurveTo(WORLD.w * 0.82, y - amp * 1.1 + 5, WORLD.w * 0.9, y + amp * 0.5 + 5, WORLD.w + 60, y - amp * 0.3 + 5);
  ctx.strokeStyle = shade;
  ctx.lineWidth = Math.max(1, width * 0.28);
  ctx.stroke();
}

export function createWorldCanvas(): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = WORLD.w;
  canvas.height = WORLD.h;
  const ctx = canvas.getContext("2d")!;
  const rnd = mulberry32(197703);

  // Warm sand base
  const base = ctx.createLinearGradient(0, 0, WORLD.w * 0.4, WORLD.h);
  base.addColorStop(0, "#d9c6a2");
  base.addColorStop(0.45, "#d2bb94");
  base.addColorStop(1, "#c6ab80");
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, WORLD.w, WORLD.h);

  const sun = ctx.createRadialGradient(420, 240, 30, 420, 240, 980);
  sun.addColorStop(0, "rgba(255, 238, 198, 0.34)");
  sun.addColorStop(1, "rgba(255, 238, 198, 0)");
  ctx.fillStyle = sun;
  ctx.fillRect(0, 0, WORLD.w, WORLD.h);

  // Broad dune bands
  const bands = [
    [160, 46, 12, "rgba(248, 232, 201, 0.28)", "rgba(120, 96, 64, 0.1)"],
    [340, 64, 15, "rgba(248, 232, 201, 0.2)", "rgba(120, 96, 64, 0.1)"],
    [540, 50, 11, "rgba(248, 232, 201, 0.24)", "rgba(120, 96, 64, 0.09)"],
    [790, 70, 16, "rgba(248, 232, 201, 0.18)", "rgba(120, 96, 64, 0.08)"],
    [1010, 42, 10, "rgba(248, 232, 201, 0.22)", "rgba(120, 96, 64, 0.1)"],
    [1210, 76, 17, "rgba(248, 232, 201, 0.16)", "rgba(120, 96, 64, 0.08)"],
    [1430, 48, 12, "rgba(248, 232, 201, 0.22)", "rgba(120, 96, 64, 0.1)"],
    [1610, 58, 14, "rgba(248, 232, 201, 0.16)", "rgba(120, 96, 64, 0.08)"],
  ] as const;
  bands.forEach(([y, amp, w, l, s]) => dune(ctx, y, amp, w, l, s));

  // Wind ripples
  ctx.lineCap = "round";
  for (let i = 0; i < 420; i++) {
    const x = rnd() * WORLD.w;
    const y = rnd() * WORLD.h;
    const len = 8 + rnd() * 38;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(x + len * 0.5, y - 2 - rnd() * 3, x + len, y);
    ctx.strokeStyle = rnd() > 0.5 ? "rgba(255, 247, 227, 0.2)" : "rgba(110, 89, 60, 0.1)";
    ctx.lineWidth = 0.8 + rnd() * 1.1;
    ctx.stroke();
  }

  // Darker grit patches
  for (let i = 0; i < 30; i++) {
    const x = rnd() * WORLD.w;
    const y = rnd() * WORLD.h;
    const r = 24 + rnd() * 85;
    const patch = ctx.createRadialGradient(x, y, 2, x, y, r);
    patch.addColorStop(0, "rgba(146, 121, 86, 0.14)");
    patch.addColorStop(1, "rgba(146, 121, 86, 0)");
    ctx.fillStyle = patch;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Trails between landmarks
  const trail = (points: Array<[number, number]>, width: number) => {
    ctx.beginPath();
    ctx.moveTo(points[0][0], points[0][1]);
    for (let i = 1; i < points.length - 1; i++) {
      const midX = (points[i][0] + points[i + 1][0]) / 2;
      const midY = (points[i][1] + points[i + 1][1]) / 2;
      ctx.quadraticCurveTo(points[i][0], points[i][1], midX, midY);
    }
    const last = points[points.length - 1];
    ctx.lineTo(last[0], last[1]);
    ctx.strokeStyle = "rgba(240, 226, 198, 0.34)";
    ctx.lineWidth = width;
    ctx.stroke();
    ctx.strokeStyle = "rgba(130, 106, 74, 0.13)";
    ctx.lineWidth = width * 0.14;
    ctx.setLineDash([2, 10]);
    ctx.stroke();
    ctx.setLineDash([]);
  };
  trail(
    [
      [CAMP.x, CAMP.y],
      [CAMP.x - 110, CAMP.y - 80],
      [SHRINES[0].x + 40, SHRINES[0].y + 60],
      [SHRINES[0].x, SHRINES[0].y],
    ],
    26,
  );
  trail(
    [
      [CAMP.x, CAMP.y],
      [1440, 880],
      [1560, 700],
      [SHRINES[1].x, SHRINES[1].y + 60],
    ],
    24,
  );
  trail(
    [
      [CAMP.x, CAMP.y],
      [1460, 1130],
      [1730, 1190],
      [SHRINES[2].x - 40, SHRINES[2].y + 40],
    ],
    24,
  );

  // Oasis shoreline and water
  const shore = ctx.createRadialGradient(OASIS.x - 40, OASIS.y - 60, 20, OASIS.x, OASIS.y, OASIS.rx + 65);
  shore.addColorStop(0, "rgba(127, 154, 109, 0.5)");
  shore.addColorStop(0.72, "rgba(176, 168, 121, 0.42)");
  shore.addColorStop(1, "rgba(176, 168, 121, 0)");
  ctx.fillStyle = shore;
  ctx.beginPath();
  ctx.ellipse(OASIS.x, OASIS.y, OASIS.rx + 72, OASIS.ry + 65, -0.1, 0, Math.PI * 2);
  ctx.fill();

  const water = ctx.createLinearGradient(OASIS.x - 220, OASIS.y - 140, OASIS.x + 170, OASIS.y + 180);
  water.addColorStop(0, "#3b8f88");
  water.addColorStop(0.46, "#26706f");
  water.addColorStop(1, "#174c53");
  ctx.fillStyle = water;
  ctx.beginPath();
  ctx.ellipse(OASIS.x, OASIS.y, OASIS.rx, OASIS.ry, -0.1, 0, Math.PI * 2);
  ctx.fill();
  // inner pools for organic edge
  [
    [-170, -40, 120, 92],
    [150, 30, 135, 105],
    [-40, 105, 150, 90],
    [70, -105, 145, 80],
  ].forEach(([dx, dy, rx, ry]) => {
    ctx.beginPath();
    ctx.ellipse(OASIS.x + dx, OASIS.y + dy, rx, ry, 0.2, 0, Math.PI * 2);
    ctx.fill();
  });
  // water highlights
  ctx.strokeStyle = "rgba(176, 235, 221, 0.26)";
  ctx.lineWidth = 2;
  for (let i = 0; i < 26; i++) {
    const a = rnd() * Math.PI * 2;
    const d = Math.sqrt(rnd());
    const x = OASIS.x + Math.cos(a) * OASIS.rx * 0.82 * d;
    const y = OASIS.y + Math.sin(a) * OASIS.ry * 0.82 * d;
    ctx.beginPath();
    ctx.moveTo(x - 12, y);
    ctx.quadraticCurveTo(x, y - 3, x + 12, y);
    ctx.stroke();
  }
  const glint = ctx.createRadialGradient(OASIS.x - 90, OASIS.y - 80, 6, OASIS.x - 90, OASIS.y - 80, 190);
  glint.addColorStop(0, "rgba(214, 248, 231, 0.38)");
  glint.addColorStop(1, "rgba(214, 248, 231, 0)");
  ctx.fillStyle = glint;
  ctx.fillRect(OASIS.x - 300, OASIS.y - 280, 600, 560);
  ctx.strokeStyle = "rgba(25, 61, 58, 0.35)";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.ellipse(OASIS.x, OASIS.y, OASIS.rx + 5, OASIS.ry + 5, -0.1, 0, Math.PI * 2);
  ctx.stroke();

  // Southern river pool
  const riverGrad = ctx.createLinearGradient(RIVER.x - 100, RIVER.y - 90, RIVER.x + 120, RIVER.y + 90);
  riverGrad.addColorStop(0, "#458e85");
  riverGrad.addColorStop(1, "#1f585a");
  ctx.fillStyle = riverGrad;
  ctx.beginPath();
  ctx.ellipse(RIVER.x, RIVER.y, RIVER.rx, RIVER.ry, 0.22, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "rgba(162, 195, 144, 0.5)";
  ctx.beginPath();
  ctx.ellipse(RIVER.x, RIVER.y, RIVER.rx + 26, RIVER.ry + 22, 0.22, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = riverGrad;
  ctx.beginPath();
  ctx.ellipse(RIVER.x, RIVER.y, RIVER.rx, RIVER.ry, 0.22, 0, Math.PI * 2);
  ctx.fill();

  // Ruins floor
  const ruinGrad = ctx.createRadialGradient(RUINS.x, RUINS.y, 20, RUINS.x, RUINS.y, 290);
  ruinGrad.addColorStop(0, "rgba(180, 164, 136, 0.9)");
  ruinGrad.addColorStop(0.7, "rgba(170, 152, 123, 0.55)");
  ruinGrad.addColorStop(1, "rgba(170, 152, 123, 0)");
  ctx.fillStyle = ruinGrad;
  ctx.beginPath();
  ctx.arc(RUINS.x, RUINS.y, 300, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "rgba(114, 96, 70, 0.28)";
  ctx.lineWidth = 2;
  for (let ring = 1; ring <= 3; ring++) {
    ctx.beginPath();
    ctx.ellipse(RUINS.x, RUINS.y + 15, 92 * ring, 62 * ring, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
  for (let i = 0; i < 34; i++) {
    const a = rnd() * Math.PI * 2;
    const d = 90 + rnd() * 165;
    const w = 20 + rnd() * 44;
    const h = 10 + rnd() * 18;
    ctx.save();
    ctx.translate(RUINS.x + Math.cos(a) * d, RUINS.y + Math.sin(a) * d * 0.7);
    ctx.rotate(rnd() * Math.PI);
    ctx.fillStyle = rnd() > 0.5 ? "rgba(205, 192, 167, 0.75)" : "rgba(159, 143, 115, 0.6)";
    ctx.fillRect(-w / 2, -h / 2, w, h);
    ctx.restore();
  }

  // Dune arch stones
  const archStone = (x: number, y: number, w: number, h: number, rot = 0) => {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rot);
    ctx.fillStyle = "rgba(84, 62, 42, 0.22)";
    ctx.beginPath();
    ctx.ellipse(4, 8, w * 0.62, h * 0.2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#b09a76";
    ctx.beginPath();
    ctx.roundRect(-w / 2, -h, w, h, 7);
    ctx.fill();
    ctx.fillStyle = "#c9b691";
    ctx.beginPath();
    ctx.roundRect(-w / 2, -h, w, h * 0.45, 7);
    ctx.fill();
    ctx.restore();
  };
  archStone(ARCH.x - 86, ARCH.y + 5, 60, 172, -0.06);
  archStone(ARCH.x + 88, ARCH.y + 5, 62, 180, 0.05);
  archStone(ARCH.x, ARCH.y - 168, 236, 44, 0.01);

  // Camp clearing
  const campGrad = ctx.createRadialGradient(CAMP.x, CAMP.y, 20, CAMP.x, CAMP.y, 265);
  campGrad.addColorStop(0, "rgba(226, 205, 161, 0.95)");
  campGrad.addColorStop(0.65, "rgba(210, 186, 142, 0.45)");
  campGrad.addColorStop(1, "rgba(210, 186, 142, 0)");
  ctx.fillStyle = campGrad;
  ctx.beginPath();
  ctx.arc(CAMP.x, CAMP.y, 265, 0, Math.PI * 2);
  ctx.fill();
  // rug
  ctx.save();
  ctx.translate(CAMP.x + 118, CAMP.y + 92);
  ctx.rotate(-0.12);
  ctx.fillStyle = "rgba(150, 63, 48, 0.62)";
  ctx.beginPath();
  ctx.roundRect(-62, -38, 124, 76, 4);
  ctx.fill();
  ctx.strokeStyle = "rgba(240, 208, 154, 0.5)";
  ctx.lineWidth = 2;
  for (let i = -2; i <= 2; i++) {
    ctx.beginPath();
    ctx.moveTo(-48, i * 13);
    ctx.lineTo(48, i * 13);
    ctx.stroke();
  }
  ctx.strokeStyle = "rgba(240, 208, 154, 0.35)";
  ctx.strokeRect(-54, -30, 108, 60);
  ctx.restore();
  // fire pit
  ctx.fillStyle = "rgba(76, 58, 42, 0.5)";
  ctx.beginPath();
  ctx.ellipse(CAMP.x, CAMP.y, 46, 30, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#6f5741";
  for (let i = 0; i < 11; i++) {
    const a = (i / 11) * Math.PI * 2;
    ctx.beginPath();
    ctx.ellipse(CAMP.x + Math.cos(a) * 44, CAMP.y + Math.sin(a) * 26, 9, 7, a, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = "rgba(43, 35, 29, 0.8)";
  ctx.beginPath();
  ctx.ellipse(CAMP.x, CAMP.y, 30, 19, 0, 0, Math.PI * 2);
  ctx.fill();

  // scattered stones and grass flecks all over
  for (let i = 0; i < 820; i++) {
    const x = rnd() * WORLD.w;
    const y = rnd() * WORLD.h;
    const size = 0.6 + rnd() * 1.8;
    ctx.fillStyle = rnd() > 0.55 ? "rgba(255, 246, 224, 0.36)" : "rgba(112, 92, 64, 0.2)";
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.fill();
  }

  // vignette on terrain edges
  const edge = ctx.createLinearGradient(0, 0, 0, WORLD.h);
  edge.addColorStop(0, "rgba(96, 73, 48, 0.2)");
  edge.addColorStop(0.2, "rgba(96, 73, 48, 0)");
  edge.addColorStop(0.82, "rgba(96, 73, 48, 0)");
  edge.addColorStop(1, "rgba(96, 73, 48, 0.24)");
  ctx.fillStyle = edge;
  ctx.fillRect(0, 0, WORLD.w, WORLD.h);

  return canvas;
}

export function drawProp(
  ctx: CanvasRenderingContext2D,
  prop: Prop,
  time: number,
  drawBehind = false,
) {
  const { x, y, s, v } = prop;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);

  if (prop.kind === "palm") {
    if (!drawBehind) {
      ctx.fillStyle = "rgba(66, 51, 35, 0.2)";
      ctx.beginPath();
      ctx.ellipse(20, 6, 40, 12, -0.25, 0, Math.PI * 2);
      ctx.fill();
    }
    const sway = Math.sin(time * 1.05 + v * 1.7) * 0.035;
    ctx.save();
    ctx.translate(0, 5);
    // trunk
    ctx.beginPath();
    ctx.moveTo(-7, 0);
    ctx.bezierCurveTo(-12, -26, 6, -46, 12, -74);
    ctx.lineTo(21, -73);
    ctx.bezierCurveTo(17, -45, 1, -25, 5, 0);
    ctx.closePath();
    const trunk = ctx.createLinearGradient(-8, 0, 18, 0);
    trunk.addColorStop(0, "#795b3d");
    trunk.addColorStop(0.55, "#9e7b51");
    trunk.addColorStop(1, "#6d5037");
    ctx.fillStyle = trunk;
    ctx.fill();
    ctx.strokeStyle = "rgba(66, 46, 28, 0.4)";
    ctx.lineWidth = 1;
    for (let i = 1; i < 7; i++) {
      const t = i / 7;
      const px = -6 + t * 14;
      const py = -t * 68;
      ctx.beginPath();
      ctx.moveTo(px - 2, py);
      ctx.quadraticCurveTo(px + 5, py + 1, px + 11, py - 1);
      ctx.stroke();
    }
    ctx.translate(16, -77);
    ctx.rotate(sway);
    const fronds = 8;
    for (let i = 0; i < fronds; i++) {
      const a = (i / fronds) * Math.PI * 2 + 0.2;
      const len = 44 + ((i * 17) % 19);
      const dx = Math.cos(a) * len;
      const dy = Math.sin(a) * len * 0.7 + 11;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(dx * 0.55, dy * 0.6 - 14, dx, dy);
      ctx.strokeStyle = i % 3 === 0 ? "#2f5b3e" : "#3f7047";
      ctx.lineWidth = 3.4;
      ctx.lineCap = "round";
      ctx.stroke();
      ctx.strokeStyle = "rgba(142, 176, 112, 0.65)";
      ctx.lineWidth = 1;
      for (let j = 1; j < 5; j++) {
        const t = j / 5;
        const mx = dx * 0.55 * t + dx * 0.45 * t * t;
        const my = (dy * 0.6 - 14) * t + (dy - (dy * 0.6 - 14)) * t * t;
        ctx.beginPath();
        ctx.moveTo(mx, my);
        ctx.lineTo(mx + Math.cos(a + 1.3) * 7, my + Math.sin(a + 1.3) * 7 + 3);
        ctx.stroke();
      }
    }
    ctx.fillStyle = "#75552f";
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(Math.cos(i * 2.1) * 6, Math.sin(i * 2.1) * 4 + 2, 3.1, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  } else if (prop.kind === "rock") {
    ctx.fillStyle = "rgba(68, 53, 36, 0.2)";
    ctx.beginPath();
    ctx.ellipse(3, 3, 19, 7, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    if (v === 0) {
      ctx.moveTo(-17, 1);
      ctx.lineTo(-11, -13);
      ctx.lineTo(2, -18);
      ctx.lineTo(15, -8);
      ctx.lineTo(18, 1);
    } else if (v === 1) {
      ctx.moveTo(-19, 2);
      ctx.lineTo(-8, -16);
      ctx.lineTo(6, -12);
      ctx.lineTo(19, 2);
    } else if (v === 2) {
      ctx.moveTo(-14, 1);
      ctx.lineTo(-10, -9);
      ctx.lineTo(5, -20);
      ctx.lineTo(14, -5);
      ctx.lineTo(16, 2);
    } else {
      ctx.moveTo(-18, 2);
      ctx.lineTo(-4, -20);
      ctx.lineTo(16, -10);
      ctx.lineTo(12, 2);
    }
    ctx.closePath();
    const g = ctx.createLinearGradient(-12, -18, 12, 4);
    g.addColorStop(0, "#c3b198");
    g.addColorStop(1, "#94805f");
    ctx.fillStyle = g;
    ctx.fill();
    ctx.strokeStyle = "rgba(78, 62, 44, 0.25)";
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-8, -3);
    ctx.lineTo(0, -8);
    ctx.lineTo(7, -4);
    ctx.strokeStyle = "rgba(255, 248, 226, 0.35)";
    ctx.lineWidth = 1;
    ctx.stroke();
  } else if (prop.kind === "shrub") {
    const sway = Math.sin(time * 2 + v) * 1.2;
    for (let i = 0; i < 5; i++) {
      const a = -Math.PI / 2 + (i - 2) * 0.32;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(Math.cos(a) * 7 + sway, -9, Math.cos(a) * 12 + sway, -18 - (i % 2) * 5);
      ctx.strokeStyle = i % 2 ? "#7f8452" : "#969359";
      ctx.lineWidth = 1.5;
      ctx.lineCap = "round";
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(93, 86, 48, 0.16)";
    ctx.beginPath();
    ctx.ellipse(0, 1, 10, 3.4, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (prop.kind === "reed") {
    const sway = Math.sin(time * 1.6 + v * 2) * 2.4;
    for (let i = 0; i < 4; i++) {
      const h = 14 + i * 5;
      ctx.beginPath();
      ctx.moveTo(i * 2.5 - 4, 0);
      ctx.quadraticCurveTo(i * 3 + sway, -h * 0.6, i * 4 + sway * 1.5, -h);
      ctx.strokeStyle = i % 2 ? "#7b8b4e" : "#98a25e";
      ctx.lineWidth = 1.5;
      ctx.lineCap = "round";
      ctx.stroke();
      if (i === 3) {
        ctx.fillStyle = "#b9a36a";
        ctx.beginPath();
        ctx.ellipse(i * 4 + sway * 1.5, -h, 2, 5, 0.2, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  } else if (prop.kind === "column") {
    ctx.fillStyle = "rgba(63, 48, 32, 0.22)";
    ctx.beginPath();
    ctx.ellipse(6, 4, 25 * s, 9 * s, 0, 0, Math.PI * 2);
    ctx.fill();
    const h = 74 * s;
    ctx.fillStyle = "#b3a283";
    ctx.beginPath();
    ctx.moveTo(-12, 0);
    ctx.lineTo(-10, -h);
    ctx.lineTo(12, -h - 3);
    ctx.lineTo(13, 2);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "rgba(255, 248, 224, 0.35)";
    ctx.beginPath();
    ctx.moveTo(-10, -h + 4);
    ctx.lineTo(-3, -h + 2);
    ctx.lineTo(-4, -5);
    ctx.lineTo(-9, -2);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#9a8a6d";
    ctx.fillRect(-16, -8, 32, 9);
    ctx.fillStyle = "#c3b293";
    ctx.fillRect(-16, -10, 32, 3);
    ctx.strokeStyle = "rgba(90, 74, 51, 0.35)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, -h + 12);
    ctx.lineTo(1, -10);
    ctx.stroke();
  } else if (prop.kind === "bones") {
    ctx.strokeStyle = "rgba(240, 232, 208, 0.72)";
    ctx.lineWidth = 2.2;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(-10, 0);
    ctx.quadraticCurveTo(0, -5, 11, 0);
    ctx.stroke();
    for (let i = -1; i <= 1; i += 2) {
      ctx.beginPath();
      ctx.arc(-10, i * 2, 2.3, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(240, 232, 208, 0.72)";
      ctx.fill();
    }
  } else if (prop.kind === "tent") {
    ctx.fillStyle = "rgba(64, 46, 29, 0.24)";
    ctx.beginPath();
    ctx.ellipse(10, 4, 74, 18, 0, 0, Math.PI * 2);
    ctx.fill();
    // back panel
    ctx.beginPath();
    ctx.moveTo(-70, 0);
    ctx.lineTo(-6, -78);
    ctx.lineTo(58, 0);
    ctx.closePath();
    const t = ctx.createLinearGradient(-40, -70, 40, 0);
    t.addColorStop(0, "#b4714e");
    t.addColorStop(0.55, "#95573d");
    t.addColorStop(1, "#6d3e2e");
    ctx.fillStyle = t;
    ctx.fill();
    // stripes
    ctx.fillStyle = "rgba(244, 216, 171, 0.74)";
    for (let i = -2; i <= 2; i++) {
      ctx.beginPath();
      ctx.moveTo(i * 14 + 8, -3);
      ctx.lineTo(-6 + i * 3.2, -68);
      ctx.lineTo(-1 + i * 3.2, -66);
      ctx.lineTo(i * 14 + 15, -3);
      ctx.closePath();
      ctx.fill();
    }
    // entrance
    ctx.beginPath();
    ctx.moveTo(-18, 0);
    ctx.quadraticCurveTo(-6, -44, -2, -46);
    ctx.quadraticCurveTo(8, -36, 24, 0);
    ctx.closePath();
    ctx.fillStyle = "#3f2921";
    ctx.fill();
    ctx.strokeStyle = "rgba(255, 238, 204, 0.4)";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    // poles
    ctx.strokeStyle = "#6e5236";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-6, -70);
    ctx.lineTo(-4, -88);
    ctx.moveTo(-72, -2);
    ctx.lineTo(-78, -20);
    ctx.stroke();
    // pennant
    ctx.fillStyle = "#e3b974";
    ctx.beginPath();
    ctx.moveTo(-4, -88);
    ctx.lineTo(22, -82);
    ctx.lineTo(-4, -74);
    ctx.closePath();
    ctx.fill();
  } else if (prop.kind === "pot") {
    ctx.fillStyle = "rgba(60, 45, 29, 0.22)";
    ctx.beginPath();
    ctx.ellipse(1, 1, 12, 4.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#a86144";
    ctx.beginPath();
    ctx.ellipse(0, -9, 8, 11, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#c07d54";
    ctx.beginPath();
    ctx.ellipse(-2, -12, 5, 7, -0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#764a35";
    ctx.beginPath();
    ctx.ellipse(0, -19, 5, 2.4, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

export function drawShrine(
  ctx: CanvasRenderingContext2D,
  shrine: (typeof SHRINES)[number],
  lit: boolean,
  time: number,
  activeGlow: boolean,
) {
  const { x, y } = shrine;
  ctx.save();
  ctx.translate(x, y);

  if (lit) {
    const glow = ctx.createRadialGradient(0, -30, 5, 0, -30, 120 + Math.sin(time * 2) * 8);
    glow.addColorStop(0, "rgba(244, 212, 146, 0.36)");
    glow.addColorStop(0.5, "rgba(227, 185, 116, 0.12)");
    glow.addColorStop(1, "rgba(227, 185, 116, 0)");
    ctx.fillStyle = glow;
    ctx.fillRect(-140, -170, 280, 280);
  }

  // step
  ctx.fillStyle = "rgba(67, 52, 35, 0.26)";
  ctx.beginPath();
  ctx.ellipse(6, 5, 49, 17, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#a1906f";
  ctx.beginPath();
  ctx.roundRect(-38, -9, 76, 16, 4);
  ctx.fill();
  ctx.fillStyle = "#bbaa86";
  ctx.beginPath();
  ctx.roundRect(-32, -16, 64, 11, 4);
  ctx.fill();

  // obelisk
  const stone = ctx.createLinearGradient(-20, -96, 26, 0);
  stone.addColorStop(0, "#d5c5a1");
  stone.addColorStop(0.5, "#b5a27d");
  stone.addColorStop(1, "#8d7b5b");
  ctx.fillStyle = stone;
  ctx.beginPath();
  ctx.moveTo(-22, -12);
  ctx.lineTo(-15, -98);
  ctx.lineTo(0, -115);
  ctx.lineTo(15, -98);
  ctx.lineTo(22, -12);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "rgba(76, 62, 42, 0.32)";
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // glyph
  ctx.save();
  ctx.translate(0, -66);
  ctx.strokeStyle = lit ? "#ffe6ae" : "rgba(65, 84, 74, 0.55)";
  ctx.lineWidth = 2.2;
  ctx.shadowColor = lit ? "rgba(255, 221, 155, 0.9)" : "transparent";
  ctx.shadowBlur = lit ? 14 : 0;
  ctx.beginPath();
  ctx.moveTo(0, -16);
  ctx.lineTo(9, 0);
  ctx.lineTo(0, 16);
  ctx.lineTo(-9, 0);
  ctx.closePath();
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(0, -16);
  ctx.lineTo(0, 16);
  ctx.stroke();
  if (lit) {
    ctx.fillStyle = "rgba(255, 232, 176, 0.8)";
    ctx.beginPath();
    ctx.arc(0, 0, 2.6, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // floating dust / active interaction ring
  if (activeGlow && !lit) {
    const pulse = (Math.sin(time * 3) + 1) / 2;
    ctx.strokeStyle = `rgba(244, 218, 164, ${0.24 + pulse * 0.4})`;
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 7]);
    ctx.lineDashOffset = -time * 18;
    ctx.beginPath();
    ctx.ellipse(0, 8, 62 + pulse * 6, 26 + pulse * 3, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  ctx.restore();
}

export function drawCampfire(ctx: CanvasRenderingContext2D, time: number) {
  const { x, y } = CAMP;
  const flick = Math.sin(time * 9) * 0.08 + Math.sin(time * 13.7) * 0.05;
  const glow = ctx.createRadialGradient(x, y - 6, 4, x, y - 6, 150);
  glow.addColorStop(0, "rgba(255, 199, 108, 0.36)");
  glow.addColorStop(0.4, "rgba(255, 172, 75, 0.13)");
  glow.addColorStop(1, "rgba(255, 172, 75, 0)");
  ctx.fillStyle = glow;
  ctx.fillRect(x - 160, y - 170, 320, 320);

  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(0.5);
  ctx.fillStyle = "#5d432e";
  ctx.beginPath();
  ctx.roundRect(-24, -5, 48, 9, 4);
  ctx.fill();
  ctx.rotate(-1.05);
  ctx.fillStyle = "#73543a";
  ctx.beginPath();
  ctx.roundRect(-23, -4, 46, 8, 4);
  ctx.fill();
  ctx.restore();

  for (let i = 0; i < 3; i++) {
    const w = 14 - i * 3.4;
    const h = 34 - i * 6;
    const sway = Math.sin(time * 7 + i * 2.3) * (3 + i);
    ctx.beginPath();
    ctx.moveTo(x - w / 2, y + 2);
    ctx.quadraticCurveTo(x - w / 2 + sway, y - h * 0.55, x + sway * 0.7, y - h);
    ctx.quadraticCurveTo(x + w / 2 + sway, y - h * 0.4, x + w / 2, y + 2);
    ctx.closePath();
    ctx.fillStyle = i === 0 ? "rgba(233, 116, 55, 0.92)" : i === 1 ? "rgba(250, 172, 78, 0.9)" : "rgba(255, 224, 150, 0.95)";
    ctx.fill();
  }
  ctx.fillStyle = "rgba(255, 244, 203, 0.9)";
  ctx.beginPath();
  ctx.ellipse(x + Math.sin(time * 6) * 2, y - 6 + flick * 8, 3.6, 6.4, 0.2, 0, Math.PI * 2);
  ctx.fill();
}

export function drawWaterRipples(ctx: CanvasRenderingContext2D, time: number) {
  ctx.save();
  ctx.strokeStyle = "rgba(186, 232, 216, 0.28)";
  ctx.lineWidth = 1.6;
  for (let i = 0; i < 7; i++) {
    const t = (time * 0.18 + i / 7) % 1;
    ctx.globalAlpha = (1 - t) * 0.55;
    ctx.beginPath();
    ctx.ellipse(OASIS.x - 60 + i * 30, OASIS.y + 20 + Math.sin(i) * 55, 18 + t * 48, 5 + t * 13, 0.1, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  ctx.strokeStyle = "rgba(192, 237, 221, 0.22)";
  for (let i = 0; i < 5; i++) {
    const t = (time * 0.14 + i / 5) % 1;
    ctx.globalAlpha = (1 - t) * 0.6;
    ctx.beginPath();
    ctx.ellipse(RIVER.x, RIVER.y + 10, 22 + t * 60, 6 + t * 15, 0.22, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}
