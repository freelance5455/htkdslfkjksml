import * as THREE from "three";
import { storeFootprint, PRODUCTS } from "./catalog";
import type { AABB, CheckoutLane, PalletSpot, ProductId, ShelfSlot } from "./types";
import {
  asphaltTex,
  ceilingTex,
  floorTex,
  hexColor,
  metalTex,
  productTex,
  wallTex,
  warehouseFloorTex,
} from "./textures";
import { NavGrid } from "./pathfinding";

export type WorldLayout = {
  group: THREE.Group;
  colliders: AABB[];
  shelves: ShelfSlot[];
  checkouts: CheckoutLane[];
  pallets: PalletSpot[];
  entrance: { x: number; z: number };
  spawn: { x: number; z: number; yaw: number };
  warehouseZone: AABB;
  grid: NavGrid;
  w: number;
  d: number;
  lights: THREE.Light[];
  productBoxes: Map<string, THREE.Group>;
  dirtRoot: THREE.Group;
  banner: THREE.Mesh;
  dispose: () => void;
};

type Mats = {
  floor: THREE.MeshStandardMaterial;
  whFloor: THREE.MeshStandardMaterial;
  wall: THREE.MeshStandardMaterial;
  ceil: THREE.MeshStandardMaterial;
  asphalt: THREE.MeshStandardMaterial;
  metal: THREE.MeshStandardMaterial;
  dark: THREE.MeshStandardMaterial;
  wood: THREE.MeshStandardMaterial;
  glass: THREE.MeshStandardMaterial;
  white: THREE.MeshStandardMaterial;
  accent: THREE.MeshStandardMaterial;
  emit: THREE.MeshStandardMaterial;
  black: THREE.MeshStandardMaterial;
  green: THREE.MeshStandardMaterial;
  products: Map<ProductId, THREE.MeshStandardMaterial>;
};

function box(
  parent: THREE.Object3D,
  mat: THREE.Material,
  w: number,
  h: number,
  d: number,
  x: number,
  y: number,
  z: number,
  colliders?: AABB[],
  collide = false,
): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  if (collide && colliders) {
    colliders.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2 });
  }
  return m;
}

function makeMats(): { mats: Mats; dispose: () => void } {
  const ft = floorTex();
  const wt = wallTex();
  const ct = ceilingTex();
  const at = asphaltTex();
  const mt = metalTex();
  const wh = warehouseFloorTex();
  const products = new Map<ProductId, THREE.MeshStandardMaterial>();
  for (const p of PRODUCTS) {
    const tex = productTex(p.name, hexColor(p.color));
    products.set(
      p.id,
      new THREE.MeshStandardMaterial({ map: tex, roughness: 0.55, metalness: 0.08 }),
    );
  }
  const mats: Mats = {
    floor: new THREE.MeshStandardMaterial({ map: ft, roughness: 0.72, metalness: 0.04 }),
    whFloor: new THREE.MeshStandardMaterial({ map: wh, roughness: 0.85 }),
    wall: new THREE.MeshStandardMaterial({ map: wt, roughness: 0.8 }),
    ceil: new THREE.MeshStandardMaterial({ map: ct, roughness: 0.9 }),
    asphalt: new THREE.MeshStandardMaterial({ map: at, roughness: 0.95 }),
    metal: new THREE.MeshStandardMaterial({ map: mt, roughness: 0.35, metalness: 0.65 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x2a3034, roughness: 0.6 }),
    wood: new THREE.MeshStandardMaterial({ color: 0x8b6914, roughness: 0.7 }),
    glass: new THREE.MeshStandardMaterial({
      color: 0x9ad4e8,
      transparent: true,
      opacity: 0.28,
      roughness: 0.05,
      metalness: 0.2,
    }),
    white: new THREE.MeshStandardMaterial({ color: 0xe8ecef, roughness: 0.45 }),
    accent: new THREE.MeshStandardMaterial({ color: 0x7dcec4, roughness: 0.4 }),
    emit: new THREE.MeshStandardMaterial({
      color: 0xf4f1e6,
      emissive: 0xf4f1e6,
      emissiveIntensity: 0.85,
    }),
    black: new THREE.MeshStandardMaterial({ color: 0x1a1d20, roughness: 0.5 }),
    green: new THREE.MeshStandardMaterial({ color: 0x4a7a3a, roughness: 0.8 }),
    products,
  };
  return {
    mats,
    dispose: () => {
      const list: THREE.Material[] = [
        mats.floor,
        mats.whFloor,
        mats.wall,
        mats.ceil,
        mats.asphalt,
        mats.metal,
        mats.dark,
        mats.wood,
        mats.glass,
        mats.white,
        mats.accent,
        mats.emit,
        mats.black,
        mats.green,
        ...products.values(),
      ];
      for (const m of list) {
        const map = (m as THREE.MeshStandardMaterial).map;
        map?.dispose();
        m.dispose();
      }
      ft.dispose();
      wt.dispose();
      ct.dispose();
      at.dispose();
      mt.dispose();
      wh.dispose();
    },
  };
}

export function buildWorld(
  level: number,
  checkoutsWanted: number,
  existing?: ShelfSlot[],
): WorldLayout {
  const { w, d } = storeFootprint(level);
  const hw = w / 2;
  const hd = d / 2;
  const { mats, dispose: disposeMats } = makeMats();
  const group = new THREE.Group();
  const colliders: AABB[] = [];
  const shelves: ShelfSlot[] = [];
  const checkouts: CheckoutLane[] = [];
  const pallets: PalletSpot[] = [];
  const productBoxes = new Map<string, THREE.Group>();
  const lights: THREE.Light[] = [];
  const geoms: THREE.BufferGeometry[] = [];

  const wallH = 4.2;
  const warehouseDepth = 5.2;
  const whZ0 = -hd;
  const whZ1 = -hd + warehouseDepth;
  const shopZ0 = whZ1 + 0.4;
  const frontZ = hd - 2.2;

  box(group, mats.asphalt, 90, 0.08, 90, 0, -0.06, 0);
  box(group, mats.green, 90, 0.05, 90, 0, -0.04, -20);

  box(group, mats.floor, w, 0.12, d - warehouseDepth, 0, 0, (shopZ0 + hd) / 2 - 0.2);
  box(group, mats.whFloor, w, 0.12, warehouseDepth, 0, 0, (whZ0 + whZ1) / 2);

  const wall = (ww: number, wd: number, x: number, z: number) =>
    box(group, mats.wall, ww, wallH, wd, x, wallH / 2, z, colliders, true);

  wall(w + 0.4, 0.35, 0, -hd);
  wall(0.35, d, -hw, 0);
  wall(0.35, d, hw, 0);
  const doorW = 3.6;
  wall((w - doorW) / 2, 0.28, -hw / 2 - doorW / 4, hd);
  wall((w - doorW) / 2, 0.28, hw / 2 + doorW / 4, hd);
  const glass = box(group, mats.glass, doorW, 3.1, 0.08, 0, 1.65, hd - 0.05);
  glass.castShadow = false;

  const ceil = box(group, mats.ceil, w, 0.12, d, 0, wallH, 0);
  ceil.castShadow = false;

  box(group, mats.dark, w - 0.4, 0.12, 0.2, 0, 0.12, whZ1);

  const sign = box(group, mats.accent, 7.4, 0.9, 0.12, 0, 3.55, hd + 0.2);
  sign.castShadow = false;
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 128;
  const ctx = canvas.getContext("2d");
  if (ctx) {
    ctx.fillStyle = "#0b0f10";
    ctx.fillRect(0, 0, 1024, 128);
    ctx.fillStyle = "#7dcec4";
    ctx.font = "bold 72px Oswald, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("SUPER MARKET X", 512, 64);
  }
  const signTex = new THREE.CanvasTexture(canvas);
  signTex.colorSpace = THREE.SRGBColorSpace;
  const signMat = new THREE.MeshStandardMaterial({
    map: signTex,
    emissive: 0x7dcec4,
    emissiveIntensity: 0.25,
  });
  const banner = new THREE.Mesh(new THREE.PlaneGeometry(7.2, 0.8), signMat);
  banner.position.set(0, 3.55, hd + 0.28);
  group.add(banner);

  for (let x = -hw + 1.6; x < hw - 1; x += 3.2) {
    const fixture = box(group, mats.emit, 2.4, 0.08, 0.5, x, wallH - 0.2, 0);
    fixture.castShadow = false;
    const pl = new THREE.PointLight(0xf2efe4, 2.4, 14, 2);
    pl.position.set(x, wallH - 0.6, 2);
    group.add(pl);
    lights.push(pl);
  }

  const hemi = new THREE.HemisphereLight(0xb8d4e8, 0x3a342c, 0.55);
  group.add(hemi);
  lights.push(hemi);
  const sun = new THREE.DirectionalLight(0xfff2dc, 1.15);
  sun.position.set(18, 28, 12);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.near = 2;
  sun.shadow.camera.far = 70;
  sun.shadow.camera.left = -28;
  sun.shadow.camera.right = 28;
  sun.shadow.camera.top = 28;
  sun.shadow.camera.bottom = -28;
  group.add(sun);
  lights.push(sun);

  const lamp = (x: number, z: number) => {
    box(group, mats.dark, 0.12, 5.2, 0.12, x, 2.6, z);
    const cap = box(group, mats.emit, 0.7, 0.12, 0.7, x, 5.3, z);
    cap.castShadow = false;
  };
  lamp(-hw - 3, hd + 4);
  lamp(hw + 3, hd + 4);
  lamp(-hw - 3, -hd);
  lamp(hw + 3, -hd);

  const tree = (x: number, z: number) => {
    box(group, mats.wood, 0.28, 1.2, 0.28, x, 0.6, z);
    const crown = new THREE.Mesh(new THREE.SphereGeometry(1.1, 10, 8), mats.green);
    crown.position.set(x, 2.1, z);
    crown.castShadow = true;
    group.add(crown);
  };
  tree(-hw - 5, 4);
  tree(hw + 5, 6);
  tree(-hw - 6, -8);
  tree(hw + 6, -6);

  const nCheck = Math.min(4, Math.max(1, checkoutsWanted));
  const checkY = frontZ - 1.1;
  const span = Math.min(w - 6, nCheck * 3.6);
  const startX = -span / 2 + 1.6;
  for (let i = 0; i < nCheck; i++) {
    const x = startX + i * (span / Math.max(1, nCheck - 1 || 1));
    const cx = nCheck === 1 ? 0 : x;
    buildCheckout(group, mats, cx, checkY, colliders);
    const queue: { x: number; z: number }[] = [];
    for (let q = 0; q < 5; q++) queue.push({ x: cx, z: checkY - 1.3 - q * 1.05 });
    checkouts.push({ id: `co${i}`, x: cx, z: checkY, queue });
  }

  const aisleZ0 = shopZ0 + 2.2;
  const aisleZ1 = checkY - 5.2;
  const aisleLen = Math.max(4.5, aisleZ1 - aisleZ0);
  const aisleMid = (aisleZ0 + aisleZ1) / 2;
  const aisleCount = 2 + level;
  const innerW = w - 5.4;
  const spacing = innerW / (aisleCount + 1);

  const prev = existing ?? [];
  let shelfIdx = 0;
  const takeOrMake = (kind: ShelfSlot["kind"], x: number, z: number, rot: number, cap: number): ShelfSlot => {
    const old = prev[shelfIdx];
    const starter = starterProduct(shelfIdx, kind, level);
    const slot: ShelfSlot = old
      ? { ...old, x, z, rot, kind, capacity: cap }
      : {
          id: `sh${shelfIdx}`,
          kind,
          x,
          z,
          rot,
          w: kind === "produce" ? 1.8 : 1.5,
          d: kind === "gondola" ? aisleLen : 1.2,
          productId: starter,
          stock: starter ? Math.floor(cap * 0.7) : 0,
          capacity: cap,
          dirty: 0,
          broken: false,
        };
    shelfIdx++;
    shelves.push(slot);
    return slot;
  };

  for (let a = 0; a < aisleCount; a++) {
    const x = -hw + 2.7 + spacing * (a + 1);
    const slot = takeOrMake("gondola", x, aisleMid, 0, 28);
    const gondola = buildGondola(group, mats, aisleLen, slot);
    productBoxes.set(slot.id, gondola);
    colliders.push({
      minX: x - 0.42,
      maxX: x + 0.42,
      minZ: aisleMid - aisleLen / 2,
      maxZ: aisleMid + aisleLen / 2,
    });
  }

  const fridgeCount = 2 + Math.min(3, level);
  const fridgeZ = shopZ0 + 1.15;
  for (let i = 0; i < fridgeCount; i++) {
    const x = -hw + 2.2 + i * 2.15;
    if (x > hw - 2) break;
    const slot = takeOrMake("fridge", x, fridgeZ, 0, 18);
    const g = buildFridge(group, mats, slot);
    productBoxes.set(slot.id, g);
    colliders.push({ minX: x - 0.85, maxX: x + 0.85, minZ: fridgeZ - 0.45, maxZ: fridgeZ + 0.45 });
  }

  const freezeCount = 1 + Math.min(3, level);
  for (let i = 0; i < freezeCount; i++) {
    const x = hw - 2.4 - i * 2.1;
    const z = aisleMid - aisleLen / 4;
    const slot = takeOrMake("freezer", x, z, 0, 16);
    const g = buildFreezer(group, mats, slot);
    productBoxes.set(slot.id, g);
    colliders.push({ minX: x - 0.85, maxX: x + 0.85, minZ: z - 0.7, maxZ: z + 0.7 });
  }

  const produceCount = 1 + Math.min(2, level);
  for (let i = 0; i < produceCount; i++) {
    const x = -hw + 3.2 + i * 2.4;
    const z = checkY - 3.4;
    const slot = takeOrMake("produce", x, z, 0, 16);
    const g = buildProduce(group, mats, slot);
    productBoxes.set(slot.id, g);
    colliders.push({ minX: x - 0.9, maxX: x + 0.9, minZ: z - 0.7, maxZ: z + 0.7 });
  }

  if (level >= 2) {
    const x = hw - 2.6;
    const z = aisleMid + aisleLen / 4;
    const slot = takeOrMake("rack", x, z, 0, 22);
    const g = buildRack(group, mats, slot);
    productBoxes.set(slot.id, g);
    colliders.push({ minX: x - 0.7, maxX: x + 0.7, minZ: z - 1.2, maxZ: z + 1.2 });
  }

  const palN = 6 + level * 2;
  for (let i = 0; i < palN; i++) {
    const col = i % 6;
    const row = Math.floor(i / 6);
    const x = -hw + 1.8 + col * 2.4;
    const z = whZ0 + 1.4 + row * 1.8;
    pallets.push({ id: `p${i}`, x, z });
    box(group, mats.wood, 1.2, 0.14, 1.0, x, 0.14, z);
  }

  box(group, mats.dark, 1.6, 1.1, 0.7, hw - 1.4, 0.55, whZ1 - 1.2, colliders, true);

  const dirtRoot = new THREE.Group();
  group.add(dirtRoot);

  const grid = new NavGrid(-hw + 0.4, -hd + 0.4, hw - 0.4, hd - 0.4, 0.7);
  grid.stamp(colliders, 0.08);

  const warehouseZone: AABB = { minX: -hw + 0.5, maxX: hw - 0.5, minZ: whZ0 + 0.4, maxZ: whZ1 - 0.2 };

  return {
    group,
    colliders,
    shelves,
    checkouts,
    pallets,
    entrance: { x: 0, z: hd + 0.6 },
    spawn: { x: 0, z: hd - 1.6, yaw: 0 },
    warehouseZone,
    grid,
    w,
    d,
    lights,
    productBoxes,
    dirtRoot,
    banner,
    dispose: () => {
      group.traverse((obj) => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry.dispose();
        }
      });
      for (const g of geoms) g.dispose();
      signTex.dispose();
      signMat.dispose();
      disposeMats();
    },
  };
}

function starterProduct(i: number, kind: ShelfSlot["kind"], level: number): ProductId | null {
  const pool = PRODUCTS.filter((p) => p.shelf === kind && p.unlockLevel <= level);
  if (!pool.length) {
    const any = PRODUCTS.filter((p) => p.unlockLevel <= level);
    return any[i % any.length]?.id ?? "bread";
  }
  return pool[i % pool.length]!.id;
}

function fillProducts(root: THREE.Group, mats: Mats, slot: ShelfSlot, layout: "shelf" | "bin") {
  const wrap = new THREE.Group();
  wrap.name = "stock";
  root.add(wrap);
  const pid = slot.productId;
  if (!pid) return;
  const mat = mats.products.get(pid) ?? mats.white;
  const n = slot.capacity;
  if (layout === "bin") {
    const rows = 3;
    const cols = 4;
    let k = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (k >= n) return;
        const m = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.16, 0.22), mat);
        m.position.set((c - 1.5) * 0.32, 0.55 + r * 0.14, (Math.floor(k / 12) - 0.5) * 0.28);
        m.castShadow = true;
        wrap.add(m);
        k++;
      }
    }
    return;
  }
  const layers = 4;
  const per = Math.ceil(n / layers);
  let k = 0;
  for (let layer = 0; layer < layers; layer++) {
    for (let i = 0; i < per; i++) {
      if (k >= n) return;
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.18, 0.16), mat);
      const along = (i / Math.max(1, per - 1) - 0.5) * (slot.d - 0.5);
      m.position.set(0.12 * (k % 2 === 0 ? 1 : -1), 0.42 + layer * 0.38, along);
      m.castShadow = true;
      wrap.add(m);
      k++;
    }
  }
}

export function syncShelfVisual(slot: ShelfSlot, group: THREE.Group | undefined): void {
  if (!group) return;
  const stock = group.getObjectByName("stock");
  if (!stock) return;
  const vis = Math.round((slot.stock / Math.max(1, slot.capacity)) * stock.children.length);
  stock.children.forEach((c, i) => {
    c.visible = i < vis && !slot.broken;
  });
}

function buildGondola(parent: THREE.Group, mats: Mats, len: number, slot: ShelfSlot): THREE.Group {
  const g = new THREE.Group();
  g.position.set(slot.x, 0, slot.z);
  parent.add(g);
  box(g, mats.metal, 0.78, 0.12, len, 0, 0.12, 0);
  box(g, mats.dark, 0.06, 1.7, len, 0, 0.95, 0);
  for (const y of [0.38, 0.76, 1.14, 1.52]) {
    box(g, mats.metal, 0.72, 0.04, len - 0.1, 0, y, 0);
  }
  fillProducts(g, mats, slot, "shelf");
  return g;
}

function buildFridge(parent: THREE.Group, mats: Mats, slot: ShelfSlot): THREE.Group {
  const g = new THREE.Group();
  g.position.set(slot.x, 0, slot.z);
  parent.add(g);
  box(g, mats.white, 1.6, 2.1, 0.78, 0, 1.05, 0);
  const inner = new THREE.Mesh(
    new THREE.BoxGeometry(1.4, 1.7, 0.08),
    new THREE.MeshStandardMaterial({
      color: 0x9ad4e8,
      transparent: true,
      opacity: 0.22,
      emissive: 0x7ec8e0,
      emissiveIntensity: 0.35,
    }),
  );
  inner.position.set(0, 1.1, 0.4);
  g.add(inner);
  fillProducts(g, mats, slot, "shelf");
  return g;
}

function buildFreezer(parent: THREE.Group, mats: Mats, slot: ShelfSlot): THREE.Group {
  const g = new THREE.Group();
  g.position.set(slot.x, 0, slot.z);
  parent.add(g);
  box(g, mats.white, 1.6, 0.95, 1.2, 0, 0.48, 0);
  const lid = new THREE.Mesh(
    new THREE.BoxGeometry(1.45, 0.05, 1.05),
    new THREE.MeshStandardMaterial({
      color: 0xa8d8ee,
      transparent: true,
      opacity: 0.35,
      emissive: 0x6ec0e0,
      emissiveIntensity: 0.2,
    }),
  );
  lid.position.set(0, 1.0, 0);
  g.add(lid);
  fillProducts(g, mats, slot, "bin");
  return g;
}

function buildProduce(parent: THREE.Group, mats: Mats, slot: ShelfSlot): THREE.Group {
  const g = new THREE.Group();
  g.position.set(slot.x, 0, slot.z);
  parent.add(g);
  box(g, mats.wood, 1.8, 0.7, 1.2, 0, 0.35, 0);
  fillProducts(g, mats, slot, "bin");
  return g;
}

function buildRack(parent: THREE.Group, mats: Mats, slot: ShelfSlot): THREE.Group {
  const g = new THREE.Group();
  g.position.set(slot.x, 0, slot.z);
  parent.add(g);
  box(g, mats.metal, 1.1, 2.2, 2.2, 0, 1.1, 0);
  fillProducts(g, mats, slot, "shelf");
  return g;
}

function buildCheckout(
  parent: THREE.Group,
  mats: Mats,
  x: number,
  z: number,
  colliders: AABB[],
): void {
  box(parent, mats.dark, 2.2, 0.92, 1.15, x, 0.46, z, colliders, true);
  box(parent, mats.black, 1.4, 0.05, 0.45, x - 0.1, 0.94, z);
  box(parent, mats.accent, 0.35, 0.28, 0.28, x + 0.85, 1.12, z - 0.2);
  box(parent, mats.metal, 0.22, 0.9, 0.22, x + 0.9, 0.55, z + 0.4);
}

export function makeCharacter(color: number, scale = 1, apron = false): THREE.Group {
  const g = new THREE.Group();
  g.scale.setScalar(scale);
  const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.55 });
  const skin = new THREE.MeshStandardMaterial({ color: 0xe2c4a8, roughness: 0.6 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x1c1f22, roughness: 0.5 });
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.62, 0.28), bodyMat);
  body.position.y = 0.92;
  body.castShadow = true;
  g.add(body);
  if (apron) {
    const a = new THREE.Mesh(
      new THREE.BoxGeometry(0.36, 0.4, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x7dcec4, roughness: 0.5 }),
    );
    a.position.set(0, 0.82, 0.16);
    g.add(a);
  }
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 10), skin);
  head.position.y = 1.38;
  head.castShadow = true;
  g.add(head);
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.165, 10, 8), dark);
  hair.position.set(0, 1.46, -0.02);
  hair.scale.set(1, 0.7, 1);
  g.add(hair);
  const legGeo = new THREE.BoxGeometry(0.12, 0.42, 0.14);
  const l = new THREE.Mesh(legGeo, dark);
  l.position.set(-0.11, 0.28, 0);
  l.name = "legL";
  l.castShadow = true;
  const r = new THREE.Mesh(legGeo, dark);
  r.position.set(0.11, 0.28, 0);
  r.name = "legR";
  r.castShadow = true;
  g.add(l, r);
  const armGeo = new THREE.BoxGeometry(0.1, 0.42, 0.1);
  const al = new THREE.Mesh(armGeo, bodyMat);
  al.position.set(-0.28, 0.95, 0);
  al.name = "armL";
  const ar = new THREE.Mesh(armGeo, bodyMat);
  ar.position.set(0.28, 0.95, 0);
  ar.name = "armR";
  g.add(al, ar);
  const hold = new THREE.Group();
  hold.name = "hold";
  hold.position.set(0.28, 0.85, 0.28);
  hold.visible = false;
  const crate = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.22, 0.28), new THREE.MeshStandardMaterial({ color: 0xb8894a }));
  hold.add(crate);
  g.add(hold);
  return g;
}
