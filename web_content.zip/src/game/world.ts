import { REGIONS, RegionConfig } from './constants';
import { GatherNode, RegionId, SeveredTailDrop } from './types';

export interface WorldObstacle {
  x: number;
  y: number;
  radius: number;
  type: 'tree' | 'rock' | 'ruin' | 'tent' | 'anvil' | 'lava_vent' | 'ice_spike';
}

export class WorldManager {
  public currentRegion: RegionId = 'settlement';
  public width: number = 2400;
  public height: number = 2400;
  public obstacles: WorldObstacle[] = [];
  public gatherNodes: GatherNode[] = [];
  public severedTails: SeveredTailDrop[] = [];
  public dayNightCycle: number = 0.25; // 0..1 (0.25 = noon, 0.75 = midnight)
  public timeSpeed: number = 0.005; // ~200s per day cycle

  constructor() {
    this.loadRegion('settlement');
  }

  public getRegionConfig(): RegionConfig {
    return REGIONS[this.currentRegion];
  }

  public loadRegion(regionId: RegionId) {
    this.currentRegion = regionId;
    this.obstacles = [];
    this.gatherNodes = [];
    this.severedTails = [];

    // Map size: settlement is compact (1400x1400), wilderness regions are large (2400x2400)
    if (regionId === 'settlement') {
      this.width = 1400;
      this.height = 1400;
      this.generateSettlementLayout();
    } else {
      this.width = 2400;
      this.height = 2400;
      this.generateWildernessLayout(regionId);
    }
  }

  private generateSettlementLayout() {
    // Guild Pavilion Camp Tent
    this.obstacles.push({ x: 600, y: 550, radius: 45, type: 'tent' });
    // Blacksmith Anvil & Forge
    this.obstacles.push({ x: 740, y: 620, radius: 30, type: 'anvil' });
    // Ancient Monument Ruins
    this.obstacles.push({ x: 450, y: 480, radius: 35, type: 'ruin' });

    // Perimeter trees
    for (let i = 0; i < 28; i++) {
      const angle = (Math.PI * 2 * i) / 28;
      const dist = 580 + (i % 3) * 35;
      this.obstacles.push({
        x: 700 + Math.cos(angle) * dist,
        y: 700 + Math.sin(angle) * dist,
        radius: 28,
        type: 'tree',
      });
    }

    // A few decorative trees & rocks inside
    this.obstacles.push({ x: 380, y: 720, radius: 24, type: 'tree' });
    this.obstacles.push({ x: 820, y: 460, radius: 24, type: 'tree' });
    this.obstacles.push({ x: 520, y: 800, radius: 20, type: 'rock' });
    this.obstacles.push({ x: 880, y: 740, radius: 20, type: 'rock' });

    // Starter gather nodes
    this.gatherNodes.push({
      id: 'node_set_1',
      x: 500,
      y: 650,
      type: 'herb',
      respawnTimer: 0,
      isGathered: false,
      items: [{ itemId: 'herb', rate: 1.0, count: 2 }],
    });
    this.gatherNodes.push({
      id: 'node_set_2',
      x: 720,
      y: 480,
      type: 'honey',
      respawnTimer: 0,
      isGathered: false,
      items: [{ itemId: 'honey', rate: 1.0, count: 2 }],
    });
  }

  private generateWildernessLayout(region: RegionId) {
    // Wilderness Camp Tent at safe outpost
    this.obstacles.push({ x: 300, y: 300, radius: 42, type: 'tent' });

    // Seed terrain features based on biome
    const rng = (seed: number) => {
      const x = Math.sin(seed) * 10000;
      return x - Math.floor(x);
    };

    const count = 45;
    for (let i = 0; i < count; i++) {
      const ox = 250 + rng(i * 13.7) * (this.width - 500);
      const oy = 250 + rng(i * 29.3) * (this.height - 500);

      // Keep camp clearing open
      if (Math.hypot(ox - 300, oy - 300) < 180) continue;

      let type: WorldObstacle['type'] = 'tree';
      let radius = 28;

      if (region === 'ember') {
        type = i % 4 === 0 ? 'lava_vent' : i % 2 === 0 ? 'rock' : 'ruin';
        radius = type === 'lava_vent' ? 22 : 26;
      } else if (region === 'frostveil') {
        type = i % 3 === 0 ? 'ice_spike' : i % 2 === 0 ? 'rock' : 'tree';
        radius = type === 'ice_spike' ? 20 : 26;
      } else if (region === 'marsh') {
        type = i % 3 === 0 ? 'ruin' : 'tree';
        radius = 28;
      } else if (region === 'crater') {
        type = i % 2 === 0 ? 'ruin' : 'rock';
        radius = 32;
      } else {
        type = i % 5 === 0 ? 'ruin' : i % 3 === 0 ? 'rock' : 'tree';
        radius = 28;
      }

      this.obstacles.push({ x: ox, y: oy, radius, type });
    }

    // Seed gathering nodes throughout region
    const nodeTypes: GatherNode['type'][] = ['herb', 'ore', 'bone', 'mushroom', 'honey'];
    for (let i = 0; i < 18; i++) {
      const nx = 200 + rng(i * 47.1) * (this.width - 400);
      const ny = 200 + rng(i * 83.9) * (this.height - 400);

      const type = nodeTypes[i % nodeTypes.length];
      let items = [{ itemId: 'herb', rate: 1.0, count: 2 }];

      if (type === 'ore') {
        items = [
          { itemId: 'iron_ore', rate: 0.8, count: 2 },
          { itemId: 'dragonite_ore', rate: 0.35, count: 1 },
        ];
      } else if (type === 'bone') {
        items = [{ itemId: 'monster_bone', rate: 0.9, count: 2 }];
      } else if (type === 'mushroom') {
        items = [{ itemId: 'herb', rate: 0.7, count: 2 }];
      } else if (type === 'honey') {
        items = [{ itemId: 'honey', rate: 1.0, count: 2 }];
      }

      this.gatherNodes.push({
        id: `node_${region}_${i}`,
        x: nx,
        y: ny,
        type,
        respawnTimer: 0,
        isGathered: false,
        items,
      });
    }
  }

  public update(dt: number) {
    // Advance day/night cycle
    this.dayNightCycle = (this.dayNightCycle + dt * this.timeSpeed) % 1.0;

    // Respawn gather nodes
    for (const node of this.gatherNodes) {
      if (node.isGathered) {
        node.respawnTimer -= dt;
        if (node.respawnTimer <= 0) {
          node.isGathered = false;
        }
      }
    }
  }

  // Check collision of an entity against solid world boundaries and obstacles
  public resolveCollision(x: number, y: number, radius: number): { x: number; y: number } {
    let nx = x;
    let ny = y;

    // Boundaries
    const margin = radius + 20;
    nx = Math.max(margin, Math.min(this.width - margin, nx));
    ny = Math.max(margin, Math.min(this.height - margin, ny));

    // Obstacle pushout
    for (const obs of this.obstacles) {
      let dx = nx - obs.x;
      let dy = ny - obs.y;
      let dist = Math.hypot(dx, dy);
      const minDist = obs.radius + radius;

      if (dist < 0.001) {
        dx = 1;
        dy = 0;
        dist = 0.001;
      }

      if (dist < minDist) {
        const overlap = minDist - dist;
        nx += (dx / dist) * overlap;
        ny += (dy / dist) * overlap;
      }
    }

    return { x: nx, y: ny };
  }

  // Render ground grid, biome terrain, environmental objects, and gather nodes
  public render(
    ctx: CanvasRenderingContext2D,
    cameraX: number,
    cameraY: number,
    viewW: number,
    viewH: number
  ) {
    const config = this.getRegionConfig();

    // 1. Background Fill
    ctx.fillStyle = config.groundColor;
    ctx.fillRect(0, 0, viewW, viewH);

    // 2. Tiled Grid / Terrain Texture
    const tileSize = 64;
    const startTileX = Math.floor(cameraX / tileSize) * tileSize;
    const startTileY = Math.floor(cameraY / tileSize) * tileSize;

    ctx.strokeStyle = config.gridColor;
    ctx.lineWidth = 1;
    ctx.beginPath();

    for (let x = startTileX; x <= cameraX + viewW + tileSize; x += tileSize) {
      const sx = x - cameraX;
      ctx.moveTo(sx, 0);
      ctx.lineTo(sx, viewH);
    }
    for (let y = startTileY; y <= cameraY + viewH + tileSize; y += tileSize) {
      const sy = y - cameraY;
      ctx.moveTo(0, sy);
      ctx.lineTo(viewW, sy);
    }
    ctx.stroke();

    // 3. World Bounds Border
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 4;
    ctx.strokeRect(-cameraX, -cameraY, this.width, this.height);

    // 4. Gather Nodes
    for (const node of this.gatherNodes) {
      if (!node.isGathered) {
        const sx = node.x - cameraX;
        const sy = node.y - cameraY;
        if (sx >= -40 && sx <= viewW + 40 && sy >= -40 && sy <= viewH + 40) {
          // Render Gather Node
          ctx.fillStyle = 'rgba(250, 204, 21, 0.25)';
          ctx.beginPath();
          ctx.arc(sx, sy, 16, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle =
            node.type === 'herb'
              ? '#22c55e'
              : node.type === 'ore'
              ? '#38bdf8'
              : node.type === 'honey'
              ? '#f59e0b'
              : '#cbd5e1';
          ctx.fillRect(sx - 6, sy - 6, 12, 12);
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(sx - 2, sy - 2, 4, 4);
        }
      }
    }

    // 5. Severed Tails dropped on ground
    for (const tail of this.severedTails) {
      const sx = tail.x - cameraX;
      const sy = tail.y - cameraY;
      if (sx >= -40 && sx <= viewW + 40 && sy >= -40 && sy <= viewH + 40) {
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.arc(sx, sy, 10, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 10px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(tail.carved ? '✦ CARVED' : '✦ TAIL (E)', sx, sy - 14);
      }
    }
  }

  // Render obstacles sorted by Y for correct isometric depth
  public renderObstacles(
    ctx: CanvasRenderingContext2D,
    cameraX: number,
    cameraY: number,
    viewW: number,
    viewH: number,
    themeColor: string
  ) {
    const visible = this.obstacles.filter((obs) => {
      const sx = obs.x - cameraX;
      const sy = obs.y - cameraY;
      return sx >= -80 && sx <= viewW + 80 && sy >= -80 && sy <= viewH + 80;
    });

    visible.sort((a, b) => a.y - b.y);

    for (const obs of visible) {
      const sx = obs.x - cameraX;
      const sy = obs.y - cameraY;

      ctx.save();
      ctx.translate(sx, sy);

      switch (obs.type) {
        case 'tree': {
          ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
          ctx.beginPath();
          ctx.ellipse(0, 14, 26, 10, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#451a03';
          ctx.fillRect(-6, -2, 12, 18);
          ctx.fillStyle = '#15803d';
          ctx.beginPath();
          ctx.arc(0, -14, 26, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#22c55e';
          ctx.beginPath();
          ctx.arc(-4, -18, 18, 0, Math.PI * 2);
          ctx.fill();
          break;
        }

        case 'tent': {
          ctx.fillStyle = 'rgba(0,0,0,0.3)';
          ctx.beginPath();
          ctx.ellipse(0, 12, 38, 14, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#78350f';
          ctx.beginPath();
          ctx.moveTo(0, -38);
          ctx.lineTo(-38, 12);
          ctx.lineTo(38, 12);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = '#d97706';
          ctx.beginPath();
          ctx.moveTo(0, -38);
          ctx.lineTo(-14, 12);
          ctx.lineTo(14, 12);
          ctx.closePath();
          ctx.fill();
          // Flag
          ctx.fillStyle = '#f59e0b';
          ctx.fillRect(0, -48, 3, 10);
          ctx.fillRect(3, -48, 12, 7);
          break;
        }

        case 'anvil': {
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(-14, -6, 28, 16);
          ctx.fillStyle = '#64748b';
          ctx.fillRect(-18, -14, 36, 10);
          break;
        }

        case 'ruin': {
          ctx.fillStyle = '#334155';
          ctx.fillRect(-18, -26, 36, 36);
          ctx.fillStyle = '#64748b';
          ctx.fillRect(-14, -22, 28, 28);
          ctx.fillStyle = themeColor;
          ctx.fillRect(-10, -12, 4, 14);
          ctx.fillRect(6, -12, 4, 14);
          break;
        }

        case 'rock': {
          ctx.fillStyle = 'rgba(0,0,0,0.25)';
          ctx.beginPath();
          ctx.ellipse(0, 8, 20, 10, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#475569';
          ctx.beginPath();
          ctx.arc(0, 0, 18, 0, Math.PI * 2);
          ctx.fill();
          break;
        }

        case 'lava_vent': {
          ctx.fillStyle = '#7f1d1d';
          ctx.beginPath();
          ctx.arc(0, 0, 18, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#f97316';
          ctx.beginPath();
          ctx.arc(0, 0, 10, 0, Math.PI * 2);
          ctx.fill();
          break;
        }

        case 'ice_spike': {
          ctx.fillStyle = '#38bdf8';
          ctx.beginPath();
          ctx.moveTo(0, -28);
          ctx.lineTo(-12, 10);
          ctx.lineTo(12, 10);
          ctx.closePath();
          ctx.fill();
          break;
        }
      }

      ctx.restore();
    }
  }

  // Draw day/night ambient lighting overlay
  public renderLighting(
    ctx: CanvasRenderingContext2D,
    playerX: number,
    playerY: number,
    cameraX: number,
    cameraY: number,
    viewW: number,
    viewH: number
  ) {
    // 0 = morning, 0.25 = noon, 0.5 = sunset, 0.75 = midnight
    // Darkness reaches peak at midnight (~0.7 darkness)
    const nightFactor = Math.sin(this.dayNightCycle * Math.PI * 2);
    const darkness = Math.max(0, -nightFactor * 0.72);

    if (darkness <= 0.04) return; // Daytime, no lighting overlay needed

    ctx.save();
    const screenPx = playerX - cameraX;
    const screenPy = playerY - cameraY;

    // Radial gradient for torch / lantern light around hunter
    const torchRadius = 140;
    const grad = ctx.createRadialGradient(
      screenPx,
      screenPy,
      25,
      screenPx,
      screenPy,
      torchRadius
    );
    grad.addColorStop(0, 'rgba(0, 0, 0, 0)');
    grad.addColorStop(0.7, `rgba(15, 23, 42, ${darkness * 0.6})`);
    grad.addColorStop(1, `rgba(10, 15, 30, ${darkness})`);

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, viewW, viewH);

    ctx.restore();
  }
}
