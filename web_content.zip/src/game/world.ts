import * as THREE from 'three';
import { BoxCollider, LightingMood, ObjectiveDrive } from './types';
import { ProceduralTextureLibrary } from './textures';
import { HostileUnit, createHostileDrone } from './enemies';

export interface WorldLightRig {
  hemiLight: THREE.HemisphereLight;
  moonKeyLight: THREE.DirectionalLight;
  flareLights: {
    light: THREE.PointLight;
    orb: THREE.Mesh;
    basePos: THREE.Vector3;
    phase: number;
    baseIntensity: number;
  }[];
  bunkerLamps: {
    light: THREE.PointLight;
    emissiveMat: THREE.MeshStandardMaterial;
    baseIntensity: number;
    phase: number;
    flickerRate: number;
  }[];
  hazardLight: THREE.PointLight;
  hazardMesh: THREE.Mesh;
  extractionLight: THREE.PointLight;
  extractionMat: THREE.MeshStandardMaterial;
}

export interface CompoundWorld {
  root: THREE.Group;
  colliders: BoxCollider[];
  raycastSolids: THREE.Mesh[];
  drives: ObjectiveDrive[];
  driveMeshes: Map<string, THREE.Group>;
  hostiles: HostileUnit[];
  extractionZone: THREE.Vector3;
  dustPoints: THREE.Points;
  lightRig: WorldLightRig;
  applyLightingMood: (mood: LightingMood, scene: THREE.Scene) => void;
  update: (dt: number, elapsed: number, extractionReady: boolean) => void;
  getZoneName: (pos: THREE.Vector3) => string;
  dispose: () => void;
}

export function buildCompoundWorld(
  scene: THREE.Scene,
  texLib: ProceduralTextureLibrary,
  isSoftwareGl: boolean,
): CompoundWorld {
  const root = new THREE.Group();
  scene.add(root);

  const colliders: BoxCollider[] = [];
  const raycastSolids: THREE.Mesh[] = [];
  const drives: ObjectiveDrive[] = [];
  const driveMeshes = new Map<string, THREE.Group>();

  // High-fidelity procedural PBR texture sets
  const mudTex = texLib.createWetTrenchMud(22, 22);
  const mudBermsTex = texLib.createWetTrenchMud(6, 2);
  const sandbagTex = texLib.createSandbagBurlap(3, 2);
  const timberTex = texLib.createTimberPlanks(2, 2);
  const rustMetalTex = texLib.createRustedCorrugatedMetal(0x363a3e, 3, 1);
  const concreteTex = texLib.createCinderblockWall(4, 2);
  const diamondTex = texLib.createDiamondPlateSteel(4, 2);
  const hazardTex = texLib.createHazardStripeTexture(4, 1);

  // Calibrated PBR materials
  const mudFloorMat = new THREE.MeshStandardMaterial({
    map: mudTex.map,
    normalMap: mudTex.normalMap,
    normalScale: new THREE.Vector2(1.4, 1.4),
    roughnessMap: mudTex.roughnessMap,
    roughness: 1.0,
    metalness: 0.08,
  });

  const mudBermMat = new THREE.MeshStandardMaterial({
    map: mudBermsTex.map,
    normalMap: mudBermsTex.normalMap,
    normalScale: new THREE.Vector2(1.3, 1.3),
    roughnessMap: mudBermsTex.roughnessMap,
    roughness: 1.0,
    metalness: 0.04,
  });

  const sandbagMat = new THREE.MeshStandardMaterial({
    map: sandbagTex.map,
    normalMap: sandbagTex.normalMap,
    normalScale: new THREE.Vector2(1.4, 1.4),
    roughnessMap: sandbagTex.roughnessMap,
    roughness: 1.0,
    metalness: 0.0,
  });

  const timberMat = new THREE.MeshStandardMaterial({
    map: timberTex.map,
    normalMap: timberTex.normalMap,
    normalScale: new THREE.Vector2(1.2, 1.2),
    roughnessMap: timberTex.roughnessMap,
    roughness: 1.0,
    metalness: 0.02,
  });

  const revetmentMat = new THREE.MeshStandardMaterial({
    map: rustMetalTex.map,
    normalMap: rustMetalTex.normalMap,
    roughnessMap: rustMetalTex.roughnessMap,
    roughness: 1.0,
    metalness: 0.72,
  });

  const concreteBunkerMat = new THREE.MeshStandardMaterial({
    map: concreteTex.map,
    normalMap: concreteTex.normalMap,
    roughnessMap: concreteTex.roughnessMap,
    roughness: 1.0,
    metalness: 0.05,
  });

  const steelMat = new THREE.MeshStandardMaterial({
    color: 0x25282c,
    roughness: 0.44,
    metalness: 0.85,
  });

  const crateMat = new THREE.MeshStandardMaterial({
    color: 0x2f3629,
    roughness: 0.82,
    metalness: 0.14,
  });

  const diamondMat = new THREE.MeshStandardMaterial({
    map: diamondTex.map,
    normalMap: diamondTex.normalMap,
    roughnessMap: diamondTex.roughnessMap,
    roughness: 1.0,
    metalness: 0.8,
  });

  const hazardMat = new THREE.MeshStandardMaterial({
    map: hazardTex,
    roughness: 0.72,
    metalness: 0.1,
  });

  // Helper to place solid earthen berms / revetted trench walls
  function addBermBlock(
    x: number,
    z: number,
    w: number,
    d: number,
    h = 2.05,
    wallStyle: 'revetment' | 'timber' | 'concrete' | 'earth' = 'revetment',
  ): void {
    // Earthen mound base
    const earth = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mudBermMat);
    earth.position.set(x, h / 2, z);
    earth.castShadow = true;
    earth.receiveShadow = true;
    root.add(earth);
    raycastSolids.push(earth);

    // Revetment siding sleeve (slightly inset vertically so sandbags sit cleanly on top)
    if (wallStyle !== 'earth') {
      const skinMat =
        wallStyle === 'revetment'
          ? revetmentMat
          : wallStyle === 'timber'
            ? timberMat
            : concreteBunkerMat;
      const skin = new THREE.Mesh(new THREE.BoxGeometry(w + 0.06, h - 0.18, d + 0.06), skinMat);
      skin.position.set(x, (h - 0.18) / 2, z);
      skin.castShadow = true;
      skin.receiveShadow = true;
      root.add(skin);
      raycastSolids.push(skin);
    }

    // Stacked Sandbag Parapet along top lip (grounded flush on top of berm)
    if (h >= 1.8 && Math.min(w, d) <= 6.5) {
      const sb = new THREE.Mesh(
        new THREE.BoxGeometry(w + 0.14, 0.34, d + 0.14),
        sandbagMat,
      );
      sb.position.set(x, h + 0.16, z);
      sb.castShadow = true;
      sb.receiveShadow = true;
      root.add(sb);
      raycastSolids.push(sb);
    }

    colliders.push({
      minX: x - w / 2,
      maxX: x + w / 2,
      minY: 0,
      maxY: h + 0.4,
      minZ: z - d / 2,
      maxZ: z + d / 2,
    });
  }

  // 1. Continuous Wet Mud Trench Floor (140m x 140m extending into distant fog)
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(140, 140), mudFloorMat);
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  root.add(floor);
  raycastSolids.push(floor);

  // Outer raised battlefield ground plane surrounding the trench network (y = 2.02m, outside +/-25m)
  // Built as 4 wide outer terrain shelves so no empty void or indoor box exists
  const outerGroundSpecs: [number, number, number, number][] = [
    [0, -49, 140, 48], // North battlefield beyond z = -25
    [0, 49, 140, 48], // South battlefield beyond z = 25
    [-49, 0, 48, 50], // West battlefield beyond x = -25
    [49, 0, 48, 50], // East battlefield beyond x = 25
  ];
  for (const [ox, oz, ow, od] of outerGroundSpecs) {
    const shelf = new THREE.Mesh(new THREE.BoxGeometry(ow, 2.02, od), mudBermMat);
    shelf.position.set(ox, 1.01, oz);
    shelf.receiveShadow = true;
    root.add(shelf);
    colliders.push({
      minX: ox - ow / 2,
      maxX: ox + ow / 2,
      minY: 0,
      maxY: 2.2,
      minZ: oz - od / 2,
      maxZ: oz + od / 2,
    });
  }

  // 2. Excavated Zig-Zag Trench Earthworks & Revetment Parapets
  // Outer Trench Perimeter Retaining Walls (keeps player inside +/-25m trench compound)
  addBermBlock(0, -25.2, 50, 2.2, 2.2, 'concrete'); // North command embankment
  addBermBlock(0, 25.2, 50, 2.2, 2.1, 'revetment'); // South staging embankment
  addBermBlock(-25.2, 0, 2.2, 50, 2.1, 'earth'); // West flank earthwork
  addBermBlock(25.2, 0, 2.2, 50, 2.1, 'earth'); // East flank earthwork

  // Staging Approach Trench (x = -3.2..3.2, z = 14..24)
  addBermBlock(-14.2, 19.5, 21.0, 10.0, 2.05, 'revetment');
  addBermBlock(14.2, 19.5, 21.0, 10.0, 2.05, 'timber');

  // Southern Listening Dugout Divider (with central pass-through at x = -2.6..2.6 and east alcove)
  addBermBlock(-13.5, 11.5, 21.0, 2.4, 2.1, 'timber');
  addBermBlock(14.5, 11.5, 19.0, 2.4, 2.1, 'revetment');

  // Central Traverse Island (breaks direct line of fire down center, forces tactical flanking!)
  addBermBlock(0, 1.5, 6.2, 5.4, 2.05, 'revetment');

  // West & East Flank Trench Baffles (forming zig-zag firing bays)
  addBermBlock(-9.8, 3.5, 2.2, 8.2, 2.05, 'timber');
  addBermBlock(-9.8, -7.2, 2.2, 7.6, 2.05, 'revetment');
  addBermBlock(9.8, 3.5, 2.2, 8.2, 2.05, 'revetment');
  addBermBlock(9.8, -7.2, 2.2, 7.6, 2.05, 'timber');

  // West & East Side Bunker Retaining Berms
  addBermBlock(-19.5, -1.5, 5.2, 2.2, 2.05, 'timber');
  addBermBlock(19.5, -1.5, 5.2, 2.2, 2.05, 'revetment');

  // Northern Command Pillbox Wall (with reinforced 6.2m breach doorway at x = 0)
  addBermBlock(-14.2, -14.2, 21.2, 2.6, 2.45, 'concrete');
  addBermBlock(14.2, -14.2, 21.2, 2.6, 2.45, 'concrete');

  // Concrete Pillbox Roof Overhang over North Approach & Extraction Gate (z = -24..-13.5, x = -6..6)
  const pillboxRoof = new THREE.Mesh(new THREE.BoxGeometry(14, 0.55, 11.5), concreteBunkerMat);
  pillboxRoof.position.set(0, 3.45, -19.2);
  pillboxRoof.castShadow = true;
  pillboxRoof.receiveShadow = true;
  root.add(pillboxRoof);
  raycastSolids.push(pillboxRoof);

  // Pillbox Doorway Lintel
  const lintel = new THREE.Mesh(new THREE.BoxGeometry(7.2, 1.1, 2.6), concreteBunkerMat);
  lintel.position.set(0, 3.1, -14.2);
  lintel.castShadow = true;
  root.add(lintel);

  // 3. Wooden Trench Duckboards (lifted 0.03m over mud puddles to prevent Z-fighting)
  function addDuckboardRun(x: number, z: number, length: number, rotY = 0): void {
    const grp = new THREE.Group();
    grp.position.set(x, 0.03, z);
    grp.rotation.y = rotY;

    const plank = new THREE.Mesh(new THREE.BoxGeometry(1.65, 0.06, length), timberMat);
    plank.receiveShadow = true;
    grp.add(plank);

    // Side stringer rails
    [-0.72, 0.72].forEach((sx) => {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.075, length), steelMat);
      rail.position.set(sx, 0.01, 0);
      grp.add(rail);
    });

    root.add(grp);
  }

  addDuckboardRun(0, 19.5, 9.5, 0);
  addDuckboardRun(0, 11.0, 7.5, 0);
  addDuckboardRun(-6.0, 7.2, 9.0, Math.PI / 2);
  addDuckboardRun(6.0, 7.2, 9.0, Math.PI / 2);
  addDuckboardRun(-14.5, -1.5, 14.0, 0);
  addDuckboardRun(14.5, -1.5, 14.0, 0);
  addDuckboardRun(0, -10.5, 12.0, Math.PI / 2);
  addDuckboardRun(0, -17.5, 7.5, 0);

  // 4. Composite Timber Trench Overhead Bracing & Camo Net Frames (3–6 parts each)
  function addTimberArch(x: number, z: number, span = 4.8, rotY = 0): void {
    const arch = new THREE.Group();
    arch.position.set(x, 0, z);
    arch.rotation.y = rotY;

    [-span / 2, span / 2].forEach((px) => {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.2, 2.35, 0.2), timberMat);
      post.position.set(px, 1.175, 0);
      post.castShadow = true;
      arch.add(post);
    });

    const beam = new THREE.Mesh(new THREE.BoxGeometry(span + 0.4, 0.2, 0.24), timberMat);
    beam.position.set(0, 2.35, 0);
    beam.castShadow = true;
    arch.add(beam);

    root.add(arch);
  }

  addTimberArch(0, 21.8, 5.2);
  addTimberArch(0, 16.2, 5.2);
  addTimberArch(-14.5, 4.5, 4.4);
  addTimberArch(14.5, 4.5, 4.4);

  // 5. Composite Sandbag Barricades & Ammo Crates (tactical cover inside trenches)
  function addSandbagBarricade(x: number, z: number, rotY = 0): void {
    const grp = new THREE.Group();
    grp.position.set(x, 0, z);
    grp.rotation.y = rotY;

    const base = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.48, 0.72), sandbagMat);
    base.position.y = 0.24;
    base.castShadow = true;
    base.receiveShadow = true;
    grp.add(base);
    raycastSolids.push(base);

    const top = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.42, 0.56), sandbagMat);
    top.position.y = 0.69;
    top.castShadow = true;
    top.receiveShadow = true;
    grp.add(top);
    raycastSolids.push(top);

    const crate = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.44, 0.48), crateMat);
    crate.position.set(0.65, 0.22, -0.52);
    crate.castShadow = true;
    grp.add(crate);

    root.add(grp);
    const isRot = Math.abs(Math.sin(rotY)) > 0.7;
    const hx = isRot ? 0.45 : 1.18;
    const hz = isRot ? 1.18 : 0.45;
    colliders.push({
      minX: x - hx,
      maxX: x + hx,
      minY: 0,
      maxY: 1.0,
      minZ: z - hz,
      maxZ: z + hz,
    });
  }

  addSandbagBarricade(1.6, 14.5, -0.2);
  addSandbagBarricade(-4.2, 5.5, 0.25);
  addSandbagBarricade(4.8, -4.5, -0.15);
  addSandbagBarricade(-5.5, -9.2, 0.4);
  addSandbagBarricade(2.2, -16.2, 0.0);

  // 6. Composite Anti-Tank Czech Hedgehogs & Concertina Razor Wire Coils along Parapets
  function addCzechHedgehog(x: number, y: number, z: number): void {
    const grp = new THREE.Group();
    grp.position.set(x, y, z);
    const beamGeo = new THREE.BoxGeometry(0.14, 1.5, 0.14);

    const angles: [number, number, number][] = [
      [0.65, 0.4, 0.3],
      [-0.65, -0.4, 0.3],
      [0.0, 0.65, -0.65],
    ];
    for (const [rx, ry, rz] of angles) {
      const beam = new THREE.Mesh(beamGeo, steelMat);
      beam.rotation.set(rx, ry, rz);
      beam.position.y = 0.55;
      beam.castShadow = true;
      grp.add(beam);
    }
    root.add(grp);
  }

  addCzechHedgehog(-4.8, 2.05, 16.5);
  addCzechHedgehog(5.2, 2.05, 13.5);
  addCzechHedgehog(-6.5, 2.05, -13.5);
  addCzechHedgehog(7.2, 2.05, -13.5);
  addCzechHedgehog(-1.8, 0, -2.5);

  // Concertina wire coils along parapet rims
  function addRazorWireRun(x: number, y: number, z: number, count: number, axis: 'x' | 'z'): void {
    const grp = new THREE.Group();
    grp.position.set(x, y, z);
    const ringGeo = new THREE.TorusGeometry(0.32, 0.018, 6, 14);
    for (let i = 0; i < count; i++) {
      const ring = new THREE.Mesh(ringGeo, steelMat);
      const offset = (i - count / 2) * 0.34;
      if (axis === 'x') ring.position.set(offset, 0.32, 0);
      else ring.position.set(0, 0.32, offset);
      ring.rotation.y = i * 0.45;
      ring.rotation.x = 0.25;
      grp.add(ring);
    }
    root.add(grp);
  }

  addRazorWireRun(-4.5, 2.38, 11.5, 8, 'x');
  addRazorWireRun(5.5, 2.38, 11.5, 8, 'x');
  addRazorWireRun(0, 2.38, 1.5, 10, 'x');
  addRazorWireRun(-9.8, 2.38, -7.2, 10, 'z');
  addRazorWireRun(9.8, 2.38, -7.2, 10, 'z');

  // Shattered Tree Stumps on Outer No-Man's-Land Horizon (environmental depth)
  const stumpPositions: [number, number, number][] = [
    [-16, 2.0, -29],
    [14, 2.0, -32],
    [-31, 2.0, -10],
    [32, 2.0, 6],
    [-29, 2.0, 15],
  ];
  for (const [sx, sy, sz] of stumpPositions) {
    const stump = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24, 0.42, 3.4, 7),
      timberMat,
    );
    stump.position.set(sx, sy + 1.6, sz);
    stump.rotation.set((Math.random() - 0.5) * 0.2, Math.random() * Math.PI, (Math.random() - 0.5) * 0.2);
    stump.castShadow = true;
    root.add(stump);
  }

  // 7. Dugout Field Bulkhead Lamps & Distant Drifting Magnesium Flares
  const bunkerLamps: WorldLightRig['bunkerLamps'] = [];

  function addBunkerLamp(
    x: number,
    y: number,
    z: number,
    colorHex: number,
    intensity: number,
    flickerRate = 0,
  ): void {
    const grp = new THREE.Group();
    grp.position.set(x, y, z);

    const cage = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.14, 0.22), steelMat);
    grp.add(cage);

    const bulbMat = new THREE.MeshStandardMaterial({
      color: colorHex,
      emissive: colorHex,
      emissiveIntensity: 3.4,
    });
    const bulb = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.08, 0.14), bulbMat);
    bulb.position.y = -0.05;
    grp.add(bulb);

    const pt = new THREE.PointLight(colorHex, intensity, 13, 1.7);
    pt.position.y = -0.25;
    grp.add(pt);

    root.add(grp);
    bunkerLamps.push({
      light: pt,
      emissiveMat: bulbMat,
      baseIntensity: intensity,
      phase: Math.random() * 10,
      flickerRate,
    });
  }

  addBunkerLamp(0, 2.22, 21.8, 0xffaa44, 6.5, 0.0); // Staging trench entry lamp
  addBunkerLamp(4.2, 2.0, 14.5, 0x8ad4ff, 6.0, 2.4); // South dugout flickering lamp
  addBunkerLamp(-14.5, 2.2, 4.5, 0xff9d3b, 7.5, 1.8); // West flank bunker lamp
  addBunkerLamp(14.5, 2.2, 4.5, 0x8ad4ff, 7.5, 0.0); // East flank comms lamp
  addBunkerLamp(0, 3.05, -17.5, 0xffaa44, 8.0, 0.0); // North pillbox interior

  // Overhead Parachute Magnesium Flares illuminating the open trench craters
  const flareLights: WorldLightRig['flareLights'] = [];
  const flareSpecs: [number, number, number, number][] = [
    [-7.5, 13.5, -3.5, 42.0],
    [9.5, 15.0, -10.5, 38.0],
  ];
  for (const [fx, fy, fz, fInt] of flareSpecs) {
    const orb = new THREE.Mesh(
      new THREE.SphereGeometry(0.24, 12, 12),
      new THREE.MeshBasicMaterial({ color: 0xffe4b5 }),
    );
    orb.position.set(fx, fy, fz);
    root.add(orb);

    const light = new THREE.PointLight(0xffcb85, fInt, 42, 1.35);
    light.position.set(fx, fy, fz);
    root.add(light);

    flareLights.push({
      light,
      orb,
      basePos: new THREE.Vector3(fx, fy, fz),
      phase: Math.random() * Math.PI * 2,
      baseIntensity: fInt,
    });
  }

  // Red Breach Strobe at North Command Pillbox Entrance
  const hazardMount = new THREE.Group();
  hazardMount.position.set(-2.6, 2.65, -13.1);
  const strobeMat = new THREE.MeshStandardMaterial({
    color: 0xff1e1e,
    emissive: 0xff1e1e,
    emissiveIntensity: 4.0,
  });
  const hazardMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.24, 12), strobeMat);
  hazardMount.add(hazardMesh);
  const hazardLight = new THREE.PointLight(0xff2222, 8.0, 12, 1.6);
  hazardLight.position.y = -0.2;
  hazardMount.add(hazardLight);
  root.add(hazardMount);

  // Extraction LZ Pad at North Command Pillbox
  const extractionZone = new THREE.Vector3(0, 0, -21.2);
  const extractionPad = new THREE.Mesh(
    new THREE.CylinderGeometry(2.1, 2.25, 0.08, 24),
    diamondMat,
  );
  extractionPad.position.set(0, 0.04, -21.2);
  root.add(extractionPad);

  const extractionBorder = new THREE.Mesh(
    new THREE.PlaneGeometry(4.4, 0.45),
    hazardMat,
  );
  extractionBorder.rotation.x = -Math.PI / 2;
  extractionBorder.position.set(0, 0.03, -18.5);
  root.add(extractionBorder);

  const extractionMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    emissive: 0xf59e0b,
    emissiveIntensity: 3.0,
  });
  const extractionBeacon = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.22, 0.22), extractionMat);
  extractionBeacon.position.set(0, 3.05, -21.2);
  root.add(extractionBeacon);

  const extractionLight = new THREE.PointLight(0xf59e0b, 8.0, 14, 1.6);
  extractionLight.position.set(0, 2.75, -21.2);
  root.add(extractionLight);

  // 8. Encrypted Field Radio / Intel Terminals (3 Objectives inside Trench Dugouts)
  function addFieldTerminal(id: string, label: string, zone: string, x: number, z: number): void {
    const grp = new THREE.Group();
    grp.position.set(x, 0, z);

    const crate = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.78, 0.72), crateMat);
    crate.position.y = 0.39;
    crate.castShadow = true;
    crate.receiveShadow = true;
    grp.add(crate);

    const radioBox = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.34, 0.4), steelMat);
    radioBox.position.set(0, 0.95, 0);
    grp.add(radioBox);

    const screenMat = new THREE.MeshStandardMaterial({
      color: 0x22d3ee,
      emissive: 0x06b6d4,
      emissiveIntensity: 2.8,
      roughness: 0.15,
    });
    const screen = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.22, 0.04), screenMat);
    screen.position.set(0, 0.96, 0.21);
    grp.add(screen);

    const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.018, 0.85, 6), steelMat);
    antenna.position.set(0.18, 1.48, -0.08);
    grp.add(antenna);

    const glow = new THREE.PointLight(0x22d3ee, 4.5, 6.0, 1.8);
    glow.position.set(0, 1.35, 0.25);
    grp.add(glow);

    root.add(grp);
    drives.push({
      id,
      label,
      zone,
      collected: false,
      position: new THREE.Vector3(x, 1.0, z),
    });
    driveMeshes.set(id, grp);
  }

  addFieldTerminal('drive-1', 'Forward Radio Cipher', 'South Dugout', 4.6, 15.2);
  addFieldTerminal('drive-2', 'Artillery Targeting Log', 'West Flank Trench', -16.5, -5.0);
  addFieldTerminal('drive-3', 'Drone Uplink Blackbox', 'East Comms Trench', 16.5, -5.0);

  // 9. Hostile Recon & Combat Drones patrolling Trench Crossings
  const hostiles: HostileUnit[] = [
    createHostileDrone('drone-1', 'Central Crossing', [
      new THREE.Vector3(-4.5, 0, 7.2),
      new THREE.Vector3(4.5, 0, 7.2),
    ]),
    createHostileDrone('drone-2', 'West Flank Trench', [
      new THREE.Vector3(-14.5, 0, 2.0),
      new THREE.Vector3(-14.5, 0, -9.5),
    ]),
    createHostileDrone('drone-3', 'East Comms Trench', [
      new THREE.Vector3(14.5, 0, -9.5),
      new THREE.Vector3(14.5, 0, 2.0),
    ]),
    createHostileDrone('drone-4', 'North Pillbox Approach', [
      new THREE.Vector3(-5.0, 0, -11.5),
      new THREE.Vector3(5.0, 0, -11.5),
    ]),
  ];
  hostiles.forEach((h) => root.add(h.group));

  // 10. Drifting Rain / Ash Embers catching Flashlight & Flares
  const dustCount = 900;
  const dustPositions = new Float32Array(dustCount * 3);
  for (let i = 0; i < dustCount; i++) {
    dustPositions[i * 3] = (Math.random() - 0.5) * 52;
    dustPositions[i * 3 + 1] = 0.2 + Math.random() * 8.5;
    dustPositions[i * 3 + 2] = (Math.random() - 0.5) * 52;
  }
  const dustGeo = new THREE.BufferGeometry();
  dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
  const dustMat = new THREE.PointsMaterial({
    color: 0xcbd5e1,
    size: 0.045,
    transparent: true,
    opacity: 0.42,
    depthWrite: false,
  });
  const dustPoints = new THREE.Points(dustGeo, dustMat);
  root.add(dustPoints);

  // 11. Global Battlefield Sky & Moon Key Light
  const hemiLight = new THREE.HemisphereLight(0x4b637e, 0x1c1712, 0.48);
  root.add(hemiLight);

  const moonKeyLight = new THREE.DirectionalLight(0xa3c0e0, 0.55);
  moonKeyLight.position.set(16, 26, 12);
  moonKeyLight.castShadow = !isSoftwareGl;
  moonKeyLight.shadow.mapSize.width = 1024;
  moonKeyLight.shadow.mapSize.height = 1024;
  moonKeyLight.shadow.camera.left = -28;
  moonKeyLight.shadow.camera.right = 28;
  moonKeyLight.shadow.camera.top = 28;
  moonKeyLight.shadow.camera.bottom = -28;
  moonKeyLight.shadow.bias = -0.0005;
  moonKeyLight.shadow.normalBias = 0.02;
  root.add(moonKeyLight);

  const lightRig: WorldLightRig = {
    hemiLight,
    moonKeyLight,
    flareLights,
    bunkerLamps,
    hazardLight,
    hazardMesh,
    extractionLight,
    extractionMat,
  };

  function applyLightingMood(mood: LightingMood, targetScene: THREE.Scene): void {
    if (mood === 'flare_night') {
      const bg = new THREE.Color(0x0a0c10);
      targetScene.background = bg;
      targetScene.fog = new THREE.FogExp2(0x0a0c10, 0.036);
      hemiLight.color.setHex(0x4a6484);
      hemiLight.groundColor.setHex(0x211a14);
      hemiLight.intensity = 0.48;
      moonKeyLight.color.setHex(0x9ab8db);
      moonKeyLight.intensity = 0.48;
      flareLights.forEach((f) => {
        f.light.visible = true;
        f.orb.visible = true;
      });
      bunkerLamps.forEach((b) => (b.light.visible = true));
    } else if (mood === 'dawn_mist') {
      const bg = new THREE.Color(0x161f29);
      targetScene.background = bg;
      targetScene.fog = new THREE.FogExp2(0x161f29, 0.042);
      hemiLight.color.setHex(0x88a9cc);
      hemiLight.groundColor.setHex(0x26211c);
      hemiLight.intensity = 0.85;
      moonKeyLight.color.setHex(0xd0e2f5);
      moonKeyLight.intensity = 0.72;
      flareLights.forEach((f) => {
        f.light.visible = true;
        f.orb.visible = true;
      });
      bunkerLamps.forEach((b) => (b.light.visible = true));
    } else {
      // Blackout: pitch-dark night trench lit by weapon light & red breach strobe
      const bg = new THREE.Color(0x030406);
      targetScene.background = bg;
      targetScene.fog = new THREE.FogExp2(0x030406, 0.054);
      hemiLight.color.setHex(0x1a222d);
      hemiLight.groundColor.setHex(0x080706);
      hemiLight.intensity = 0.14;
      moonKeyLight.intensity = 0.12;
      flareLights.forEach((f) => {
        f.light.visible = false;
        f.orb.visible = false;
      });
      bunkerLamps.forEach((b, idx) => {
        const keep = idx === 0;
        b.light.visible = keep;
        b.emissiveMat.emissiveIntensity = keep ? 2.2 : 0.1;
      });
    }
  }

  applyLightingMood('flare_night', scene);

  function update(dt: number, elapsed: number, extractionReady: boolean): void {
    // Flickering dugout bulkhead lights
    for (const bl of bunkerLamps) {
      if (!bl.light.visible) continue;
      if (bl.flickerRate > 0) {
        const n =
          Math.sin(elapsed * 21.0 + bl.phase) *
          Math.sin(elapsed * 47.0 + bl.phase * 1.4);
        const dim = n > 0.66 ? 0.2 : 1.0;
        bl.light.intensity = bl.baseIntensity * dim;
        bl.emissiveMat.emissiveIntensity = 3.4 * dim;
      }
    }

    // Swaying overhead magnesium parachute flares
    for (const fl of flareLights) {
      if (!fl.light.visible) continue;
      const swayX = Math.sin(elapsed * 0.55 + fl.phase) * 1.4;
      const swayZ = Math.cos(elapsed * 0.42 + fl.phase) * 1.1;
      const bobY = Math.sin(elapsed * 0.8 + fl.phase) * 0.45;
      fl.orb.position.set(fl.basePos.x + swayX, fl.basePos.y + bobY, fl.basePos.z + swayZ);
      fl.light.position.copy(fl.orb.position);
      const shimmer = 0.88 + Math.sin(elapsed * 16 + fl.phase) * 0.12;
      fl.light.intensity = fl.baseIntensity * shimmer;
    }

    // Red breach beacon pulse
    const pulse = Math.pow(Math.sin(elapsed * 4.2) * 0.5 + 0.5, 3.0);
    hazardLight.intensity = 1.5 + pulse * 10.0;
    (hazardMesh.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.6 + pulse * 4.2;

    // Extraction LZ beacon
    if (extractionReady) {
      extractionLight.color.setHex(0x10b981);
      extractionMat.color.setHex(0x10b981);
      extractionMat.emissive.setHex(0x10b981);
      extractionLight.intensity = 11.0;
    } else {
      extractionLight.color.setHex(0xf59e0b);
      extractionMat.color.setHex(0xf59e0b);
      extractionMat.emissive.setHex(0xf59e0b);
      extractionLight.intensity = 6.5;
    }

    // Drifting ash/rain particles
    const posAttr = dustPoints.geometry.attributes.position as THREE.BufferAttribute;
    const arr = posAttr.array as Float32Array;
    for (let i = 1; i < arr.length; i += 3) {
      arr[i] -= dt * 0.9;
      if (arr[i] < 0.1) arr[i] = 8.4;
    }
    posAttr.needsUpdate = true;
  }

  function getZoneName(pos: THREE.Vector3): string {
    if (pos.z > 16.0) return 'Staging Approach Trench';
    if (pos.z > 10.5) return 'South Listening Dugout';
    if (pos.z < -14.2) return 'North Command Pillbox';
    if (pos.x < -10.0) return 'West Flank Trench';
    if (pos.x > 10.0) return 'East Comms Trench';
    return 'Forward Crossing & Traverse';
  }

  function dispose(): void {
    root.traverse((obj) => {
      if (obj instanceof THREE.Mesh || obj instanceof THREE.Points || obj instanceof THREE.Line) {
        obj.geometry.dispose();
        if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
        else obj.material.dispose();
      }
    });
  }

  return {
    root,
    colliders,
    raycastSolids,
    drives,
    driveMeshes,
    hostiles,
    extractionZone,
    dustPoints,
    lightRig,
    applyLightingMood,
    update,
    getZoneName,
    dispose,
  };
}
