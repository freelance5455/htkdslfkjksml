import * as THREE from "three";

export const GRID = 6;
export const BLK = 78;
export const RD = 18;
export const WD = GRID * BLK;

export type Collider = { x: number; z: number; w: number; d: number; h: number };
export type Block = { x: number; z: number; w: number; d: number };
export type ShopType = "health" | "ammo" | "garage";

export type Shop = {
  type: ShopType;
  x: number;
  z: number;
  group: THREE.Group;
  ring: THREE.Mesh;
  cd: number;
};

export type Ramp = { x: number; z: number; mesh: THREE.Mesh };

export type City = {
  colliders: Collider[];
  blocks: Block[];
  shops: Shop[];
  ramps: Ramp[];
  nightMats: THREE.MeshStandardMaterial[];
  bulbMat: THREE.MeshStandardMaterial;
  roadMats: THREE.MeshStandardMaterial[];
  beaconMat: THREE.MeshStandardMaterial;
  beaconLight: THREE.PointLight;
};

export function gridPos(i: number) {
  return -WD / 2 + i * BLK;
}

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function collide(x: number, z: number, r: number, colliders: Collider[]) {
  let px = x;
  let pz = z;
  let push = 0;
  for (const b of colliders) {
    if (px < b.x - r || px > b.x + b.w + r || pz < b.z - r || pz > b.z + b.d + r) continue;
    const nx = Math.max(b.x, Math.min(px, b.x + b.w));
    const nz = Math.max(b.z, Math.min(pz, b.z + b.d));
    const dx = px - nx;
    const dz = pz - nz;
    const d2 = dx * dx + dz * dz;
    if (d2 < r * r && d2 > 1e-8) {
      const d = Math.sqrt(d2);
      const k = (r - d) / d;
      px += dx * k;
      pz += dz * k;
      push += r - d;
    } else if (d2 <= 1e-8) {
      const left = px - b.x;
      const right = b.x + b.w - px;
      const top = pz - b.z;
      const bot = b.z + b.d - pz;
      const m = Math.min(left, right, top, bot);
      if (m === left) px = b.x - r;
      else if (m === right) px = b.x + b.w + r;
      else if (m === top) pz = b.z - r;
      else pz = b.z + b.d + r;
      push += r;
    }
  }
  const lim = WD / 2 - 3;
  const bx = px;
  const bz = pz;
  px = Math.max(-lim, Math.min(lim, px));
  pz = Math.max(-lim, Math.min(lim, pz));
  push += Math.abs(px - bx) + Math.abs(pz - bz);
  return { x: px, z: pz, push };
}

export function blocked(x: number, z: number, colliders: Collider[]) {
  for (const b of colliders) {
    if (x > b.x && x < b.x + b.w && z > b.z && z < b.z + b.d) return true;
  }
  return false;
}

function canvasTex(draw: (g: CanvasRenderingContext2D, w: number, h: number) => void, w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const g = c.getContext("2d");
  if (!g) throw new Error("canvas");
  draw(g, w, h);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 4;
  return tex;
}

function speckle(g: CanvasRenderingContext2D, w: number, h: number, rng: () => number, n: number, a: number) {
  for (let i = 0; i < n; i++) {
    const k = rng();
    g.fillStyle = `rgba(${k > 0.5 ? 255 : 0},${k > 0.5 ? 255 : 0},${k > 0.5 ? 255 : 0},${a * rng()})`;
    g.fillRect(rng() * w, rng() * h, 1 + rng() * 2, 1 + rng() * 2);
  }
}

type Facade = { map: THREE.CanvasTexture; glow: THREE.CanvasTexture };

function makeFacade(style: "brick" | "concrete" | "glass" | "stone", variant: number): Facade {
  const rng = mulberry32(400 + variant * 97 + style.length * 13);
  const map = canvasTex((g, w, h) => {
    if (style === "brick") g.fillStyle = "#7c4034";
    else if (style === "concrete") g.fillStyle = "#6a707a";
    else if (style === "glass") g.fillStyle = "#163044";
    else g.fillStyle = "#c3b396";
    g.fillRect(0, 0, w, h);
    if (style === "brick") {
      for (let y = 0; y < h; y += 10) {
        g.fillStyle = y % 20 === 0 ? "#8d4b3c" : "#69362c";
        g.fillRect(0, y, w, 3);
      }
    } else if (style === "concrete") {
      for (let y = 0; y < h; y += 6) {
        g.fillStyle = "rgba(0,0,0,0.08)";
        g.fillRect(0, y, w, 1);
      }
    } else if (style === "stone") {
      for (let y = 0; y < h; y += 14) {
        g.fillStyle = rng() > 0.5 ? "#b5a588" : "#d0c2a6";
        g.fillRect(0, y, w, 12);
      }
    }
    speckle(g, w, h, rng, 180, 0.15);
  }, 128, 256);

  const glow = canvasTex((g, w, h) => {
    g.fillStyle = "#000";
    g.fillRect(0, 0, w, h);
    const cols = style === "glass" ? 6 : 4;
    const rows = 9;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const wx = 8 + c * ((w - 16) / cols);
        const wy = 12 + r * ((h - 20) / rows);
        const ww = style === "glass" ? 16 : 16;
        const wh = style === "glass" ? 18 : 22;
        const lit = rng() > (style === "glass" ? 0.35 : 0.5);
        if (style !== "glass") {
          const ctx = map.image as HTMLCanvasElement;
          const mg = ctx.getContext("2d");
          if (mg) {
            mg.fillStyle = "#0c1016";
            mg.fillRect(wx, wy, ww, wh);
            if (lit) {
              mg.fillStyle = rng() > 0.82 ? "#9fd4ff" : "#ffc98a";
              mg.fillRect(wx + 1, wy + 1, ww - 2, wh - 2);
            }
          }
        } else {
          const ctx = map.image as HTMLCanvasElement;
          const mg = ctx.getContext("2d");
          if (mg) {
            const shade = 0.45 + rng() * 0.55;
            mg.fillStyle = `rgba(${40 * shade},${110 * shade},${160 * shade},1)`;
            mg.fillRect(wx, wy, ww, wh);
            mg.fillStyle = "rgba(220,240,255,0.35)";
            mg.fillRect(wx, wy, ww, 3);
          }
        }
        if (lit) {
          g.fillStyle = rng() > 0.82 ? "#8ec8ff" : "#ffb15a";
          g.fillRect(wx + 1, wy + 1, ww - 2, wh - 2);
        }
      }
    }
    map.needsUpdate = true;
  }, 128, 256);
  return { map, glow };
}

const FACADES: Facade[] = [];
function facade(style: "brick" | "concrete" | "glass" | "stone", variant: number) {
  const key = `${style}:${variant}`;
  let found = FACADES.find((f) => f.map.name === key);
  if (!found) {
    found = makeFacade(style, variant);
    found.map.name = key;
    FACADES.push(found);
  }
  return found;
}

function lay(mesh: THREE.Mesh) {
  mesh.rotation.x = -Math.PI / 2;
  mesh.receiveShadow = true;
  return mesh;
}

export function buildCity(scene: THREE.Scene): City {
  const rng = mulberry32(11);
  const colliders: Collider[] = [];
  const blocks: Block[] = [];
  const nightMats: THREE.MeshStandardMaterial[] = [];
  const shops: Shop[] = [];
  const ramps: Ramp[] = [];

  const ground = lay(
    new THREE.Mesh(
      new THREE.PlaneGeometry(WD + 520, WD + 520),
      new THREE.MeshStandardMaterial({ color: 0x23262c, roughness: 1 }),
    ),
  );
  ground.position.y = 0;
  scene.add(ground);

  const roadTexV = canvasTex((g, w, h) => {
    g.fillStyle = "#17191f";
    g.fillRect(0, 0, w, h);
    speckle(g, w, h, rng, 500, 0.2);
    g.fillStyle = "rgba(210,210,200,0.55)";
    g.fillRect(10, 0, 3, h);
    g.fillRect(w - 13, 0, 3, h);
    g.fillStyle = "#d6b24a";
    for (let y = 8; y < h; y += 36) g.fillRect(w / 2 - 2, y, 4, 18);
  }, 128, 256);
  roadTexV.wrapS = THREE.RepeatWrapping;
  roadTexV.wrapT = THREE.RepeatWrapping;
  const roadTexU = roadTexV.clone();
  roadTexU.center.set(0.5, 0.5);
  roadTexU.rotation = Math.PI / 2;
  roadTexU.needsUpdate = true;
  const segLen = BLK - RD;
  roadTexV.repeat.set(1, segLen / 10);
  roadTexU.repeat.set(segLen / 10, 1);

  const roadMatV = new THREE.MeshStandardMaterial({ map: roadTexV, roughness: 0.92, metalness: 0.04, color: 0xffffff });
  const roadMatH = new THREE.MeshStandardMaterial({ map: roadTexU, roughness: 0.92, metalness: 0.04, color: 0xffffff });

  const cross = canvasTex((g, w, h) => {
    g.fillStyle = "#14161c";
    g.fillRect(0, 0, w, h);
    speckle(g, w, h, rng, 200, 0.18);
    g.fillStyle = "#e6e2d4";
    const stripe = (x: number, y: number, sw: number, sh: number) => g.fillRect(x, y, sw, sh);
    for (let i = 0; i < 5; i++) {
      stripe(18 + i * 18, 8, 10, 22);
      stripe(18 + i * 18, h - 30, 10, 22);
      stripe(8, 18 + i * 18, 22, 10);
      stripe(w - 30, 18 + i * 18, 22, 10);
    }
  }, 256, 256);
  cross.repeat.set(1, 1);
  const ixMat = new THREE.MeshStandardMaterial({ map: cross, roughness: 0.9, metalness: 0.03 });

  for (let i = 0; i <= GRID; i++) {
    for (let j = 0; j <= GRID; j++) {
      const ix = lay(new THREE.Mesh(new THREE.PlaneGeometry(RD + 0.6, RD + 0.6), ixMat));
      ix.position.set(gridPos(i), 0.02, gridPos(j));
      scene.add(ix);
    }
  }
  for (let i = 0; i <= GRID; i++) {
    for (let j = 0; j < GRID; j++) {
      const zc = (gridPos(j) + RD / 2 + gridPos(j + 1) - RD / 2) / 2;
      const v = lay(new THREE.Mesh(new THREE.PlaneGeometry(RD, segLen + 0.4), roadMatV));
      v.position.set(gridPos(i), 0.018, zc);
      scene.add(v);
      const xc = (gridPos(j) + RD / 2 + gridPos(j + 1) - RD / 2) / 2;
      const h = lay(new THREE.Mesh(new THREE.PlaneGeometry(segLen + 0.4, RD), roadMatH));
      h.position.set(xc, 0.018, gridPos(i));
      scene.add(h);
    }
  }

  const sideTex = canvasTex((g, w, h) => {
    g.fillStyle = "#5c616c";
    g.fillRect(0, 0, w, h);
    speckle(g, w, h, mulberry32(3), 300, 0.18);
    g.strokeStyle = "rgba(255,255,255,0.04)";
    for (let i = 0; i < 8; i++) {
      g.strokeRect(8 + (i % 4) * 28, 8 + Math.floor(i / 4) * 28, 24, 24);
    }
  }, 128, 128);
  sideTex.repeat.set(4, 4);
  const sideMat = new THREE.MeshStandardMaterial({ map: sideTex, roughness: 0.95, color: 0xffffff });
  const grassTex = canvasTex((g, w, h) => {
    g.fillStyle = "#2f6a3e";
    g.fillRect(0, 0, w, h);
    const gr = mulberry32(9);
    for (let i = 0; i < 700; i++) {
      g.fillStyle = gr() > 0.5 ? "#266034" : "#3d7d4c";
      g.fillRect(gr() * w, gr() * h, 2, 3);
    }
  }, 128, 128);
  grassTex.repeat.set(5, 5);
  const grassMat = new THREE.MeshStandardMaterial({ map: grassTex, roughness: 1, color: 0xffffff });

  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a3424, roughness: 0.9 });
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x1f6b3a, roughness: 0.85 });
  const leafMat2 = new THREE.MeshStandardMaterial({ color: 0x2e8a4e, roughness: 0.8 });
  const treePos: THREE.Vector3[] = [];
  const acMat = new THREE.MeshStandardMaterial({ color: 0x8d939c, roughness: 0.7, metalness: 0.3 });
  const roofMat = new THREE.MeshStandardMaterial({ color: 0x2c3038, roughness: 0.85 });

  let tallest = 0;
  let beaconPos = new THREE.Vector3(0, 40, 0);

  function addBuilding(cx: number, cz: number, w: number, d: number, core: number) {
    const house = core > 2.15 && rng() < 0.62;
    if (house) {
      const floors = 1 + (rng() < 0.5 ? 1 : 0);
      const h = floors * 3.3;
      const wall = new THREE.Mesh(
        new THREE.BoxGeometry(w, h, d),
        new THREE.MeshStandardMaterial({ color: new THREE.Color().setHSL(0.07, 0.28, 0.45 + rng() * 0.12), roughness: 0.9 }),
      );
      wall.position.set(cx, h / 2, cz);
      wall.castShadow = true;
      wall.receiveShadow = true;
      scene.add(wall);
      const roof = new THREE.Mesh(
        new THREE.ConeGeometry(Math.max(w, d) * 0.72, 2.2, 4),
        new THREE.MeshStandardMaterial({ color: new THREE.Color().setHSL(0.02, 0.45, 0.28), roughness: 0.8 }),
      );
      roof.rotation.y = Math.PI / 4;
      roof.position.set(cx, h + 1.05, cz);
      roof.castShadow = true;
      scene.add(roof);
      const winMat = new THREE.MeshStandardMaterial({
        color: 0xffe0b0,
        emissive: 0xffb060,
        emissiveIntensity: 0.25,
        roughness: 0.25,
      });
      nightMats.push(winMat);
      for (let f = 0; f < floors; f++) {
        for (const s of [-1, 1]) {
          const win = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.05, 0.08), winMat);
          win.position.set(cx + s * w * 0.26, 1.4 + f * 3.1, cz + d / 2 + 0.05);
          scene.add(win);
        }
      }
      colliders.push({ x: cx - w / 2, z: cz - d / 2, w, d, h: h + 2 });
      return h;
    }

    let h = core < 0.8 ? 46 + rng() * 38 : core < 1.6 ? 20 + rng() * 18 : core < 2.3 ? 9 + rng() * 10 : 6 + rng() * 5;
    h = Math.round(h);
    const styles = ["brick", "concrete", "glass", "stone"] as const;
    const style = core < 1.2 ? (rng() < 0.55 ? "glass" : "concrete") : styles[Math.floor(rng() * styles.length)]!;
    const face = facade(style, Math.floor(rng() * 3));
    const map = face.map.clone();
    map.needsUpdate = true;
    map.wrapS = map.wrapT = THREE.RepeatWrapping;
    map.repeat.set(Math.max(1, Math.round(w / 7)), Math.max(1, Math.round(h / 3.3)));
    const glow = face.glow.clone();
    glow.needsUpdate = true;
    glow.wrapS = glow.wrapT = THREE.RepeatWrapping;
    glow.repeat.copy(map.repeat);
    const mat = new THREE.MeshStandardMaterial({
      map,
      emissiveMap: glow,
      emissive: 0xffffff,
      emissiveIntensity: 0.18,
      roughness: style === "glass" ? 0.28 : 0.82,
      metalness: style === "glass" ? 0.55 : 0.06,
      color: new THREE.Color().setHSL(style === "glass" ? 0.58 : 0.08, style === "glass" ? 0.18 : 0.08, 0.72 + rng() * 0.2),
    });
    nightMats.push(mat);

    if (h > 32) {
      const h1 = h * 0.62;
      const lower = new THREE.Mesh(new THREE.BoxGeometry(w, h1, d), mat);
      lower.position.set(cx, h1 / 2, cz);
      lower.castShadow = true;
      lower.receiveShadow = true;
      scene.add(lower);
      const uW = w * 0.68;
      const uD = d * 0.68;
      const upper = new THREE.Mesh(new THREE.BoxGeometry(uW, h - h1, uD), mat);
      upper.position.set(cx, h1 + (h - h1) / 2, cz);
      upper.castShadow = true;
      upper.receiveShadow = true;
      scene.add(upper);
    } else {
      const box = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      box.position.set(cx, h / 2, cz);
      box.castShadow = true;
      box.receiveShadow = true;
      scene.add(box);
    }
    const cap = new THREE.Mesh(new THREE.BoxGeometry(w + 0.4, 0.7, d + 0.4), roofMat);
    cap.position.set(cx, h + 0.3, cz);
    cap.castShadow = true;
    scene.add(cap);
    if (h < 30 && rng() < 0.55) {
      for (let k = 0; k < 2; k++) {
        const ac = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.7, 0.9), acMat);
        ac.position.set(cx + (k - 0.5) * w * 0.35, h + 0.9, cz + (rng() - 0.5) * d * 0.3);
        ac.castShadow = true;
        scene.add(ac);
      }
    }
    if (rng() < 0.3) {
      const words = ["BAR", "GUNS", "MOTEL", "DINER", "CASH", "CLUB", "BAIL", "OPEN"];
      const pal = [
        ["#1a0a10", "#ff4d6a"],
        ["#0c121c", "#8ec8ff"],
        ["#1a1408", "#ffc14a"],
        ["#07140e", "#5ee0a0"],
      ] as const;
      const word = words[Math.floor(rng() * words.length)]!;
      const pair = pal[Math.floor(rng() * pal.length)]!;
      const tex = canvasTex((g, w, h) => {
        g.fillStyle = pair[0];
        g.fillRect(0, 0, w, h);
        g.strokeStyle = pair[1];
        g.lineWidth = 8;
        g.strokeRect(6, 6, w - 12, h - 12);
        g.fillStyle = pair[1];
        g.font = "700 68px Impact, Arial Black, sans-serif";
        g.textAlign = "center";
        g.textBaseline = "middle";
        g.fillText(word, w / 2, h / 2 + 4);
      }, 256, 96);
      tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(Math.min(w * 0.7, 5.2), 1.45), new THREE.MeshBasicMaterial({ map: tex }));
      sign.position.set(cx, Math.min(h * 0.72, h - 1.5), cz + d / 2 + 0.12);
      scene.add(sign);
    }
    colliders.push({ x: cx - w / 2, z: cz - d / 2, w, d, h });
    return h;
  }

  function split(x: number, z: number, w: number, d: number, dep: number, core: number): number {
    if (dep >= 2 || w < 20 || d < 20 || rng() < 0.28) {
      if (w < 8 || d < 8) return 0;
      return addBuilding(x + w / 2, z + d / 2, w * 0.92, d * 0.92, core);
    }
    const gap = 2.2;
    if (w > d) {
      const cut = w * (0.4 + rng() * 0.2);
      return Math.max(split(x, z, cut - gap / 2, d, dep + 1, core), split(x + cut + gap / 2, z, w - cut - gap / 2, d, dep + 1, core));
    }
    const cut = d * (0.4 + rng() * 0.2);
    return Math.max(split(x, z, w, cut - gap / 2, dep + 1, core), split(x, z + cut + gap / 2, w, d - cut - gap / 2, dep + 1, core));
  }

  for (let i = 0; i < GRID; i++) {
    for (let j = 0; j < GRID; j++) {
      const x0 = gridPos(i) + RD / 2;
      const z0 = gridPos(j) + RD / 2;
      const size = BLK - RD;
      const block = { x: x0, z: z0, w: size, d: size };
      blocks.push(block);
      const park = i === 2 && j === 2;
      const pad = lay(new THREE.Mesh(new THREE.PlaneGeometry(size, size), park ? grassMat : sideMat));
      pad.position.set(x0 + size / 2, 0.03, z0 + size / 2);
      scene.add(pad);
      const core = Math.max(Math.abs(i - 2.5), Math.abs(j - 2.5));
      if (park) {
        const fx = x0 + size / 2;
        const fz = z0 + size / 2;
        const basin = new THREE.Mesh(
          new THREE.CylinderGeometry(3.2, 3.4, 0.6, 16),
          new THREE.MeshStandardMaterial({ color: 0xc8c2b6, roughness: 0.6 }),
        );
        basin.position.set(fx, 0.35, fz);
        scene.add(basin);
        const water = new THREE.Mesh(
          new THREE.CylinderGeometry(2.5, 2.5, 0.25, 16),
          new THREE.MeshStandardMaterial({ color: 0x2a6f8a, roughness: 0.15, metalness: 0.4, emissive: 0x123040, emissiveIntensity: 0.4 }),
        );
        water.position.set(fx, 0.7, fz);
        scene.add(water);
        colliders.push({ x: fx - 3.2, z: fz - 3.2, w: 6.4, d: 6.4, h: 1.2 });
        for (let t = 0; t < 10; t++) {
          const ang = (t / 10) * Math.PI * 2;
          treePos.push(new THREE.Vector3(fx + Math.cos(ang) * 12, 0, fz + Math.sin(ang) * 12));
        }
      } else {
        const top = split(x0 + 3.5, z0 + 3.5, size - 7, size - 7, 0, core);
        if (top > tallest) {
          tallest = top;
          beaconPos = new THREE.Vector3(x0 + size / 2, top + 2, z0 + size / 2);
        }
        if (rng() < 0.7) {
          treePos.push(new THREE.Vector3(x0 + 2.4, 0, z0 + 6 + rng() * (size - 12)));
        }
      }
    }
  }

  const trunkGeo = new THREE.CylinderGeometry(0.16, 0.24, 1.6, 5);
  const leafGeo = new THREE.ConeGeometry(1.15, 2.5, 6);
  if (treePos.length) {
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, treePos.length);
    const leaves = new THREE.InstancedMesh(leafGeo, leafMat, treePos.length);
    const leaves2 = new THREE.InstancedMesh(leafGeo, leafMat2, treePos.length);
    const dummy = new THREE.Object3D();
    treePos.forEach((p, idx) => {
      dummy.position.set(p.x, 0.8, p.z);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      trunks.setMatrixAt(idx, dummy.matrix);
      dummy.position.set(p.x, 2.3, p.z);
      dummy.scale.setScalar(0.85 + (idx % 5) * 0.06);
      dummy.updateMatrix();
      leaves.setMatrixAt(idx, dummy.matrix);
      dummy.position.set(p.x, 3.3, p.z);
      dummy.scale.setScalar(0.65);
      dummy.updateMatrix();
      leaves2.setMatrixAt(idx, dummy.matrix);
      colliders.push({ x: p.x - 0.35, z: p.z - 0.35, w: 0.7, d: 0.7, h: 3 });
    });
    scene.add(trunks, leaves, leaves2);
  }

  const poleGeo = new THREE.CylinderGeometry(0.07, 0.1, 5.4, 6);
  const poleMat = new THREE.MeshStandardMaterial({ color: 0x2e323a, roughness: 0.75, metalness: 0.45 });
  const bulbMat = new THREE.MeshStandardMaterial({ color: 0xfff3d2, emissive: 0xffcc80, emissiveIntensity: 0.25 });
  const armGeo = new THREE.BoxGeometry(1.1, 0.08, 0.08);
  const bulbGeo = new THREE.SphereGeometry(0.2, 8, 6);
  for (let i = 0; i <= GRID; i++) {
    for (let j = 0; j <= GRID; j++) {
      if ((i + j) % 2 !== 0) continue;
      const px = gridPos(i) + RD / 2 + 1.1;
      const pz = gridPos(j) + RD / 2 + 1.1;
      const pole = new THREE.Mesh(poleGeo, poleMat);
      pole.position.set(px, 2.7, pz);
      pole.castShadow = true;
      const arm = new THREE.Mesh(armGeo, poleMat);
      arm.position.set(px + 0.4, 5.3, pz);
      const bulb = new THREE.Mesh(bulbGeo, bulbMat);
      bulb.position.set(px + 0.85, 5.15, pz);
      scene.add(pole, arm, bulb);
    }
  }

  const beaconMat = new THREE.MeshStandardMaterial({ color: 0xff3048, emissive: 0xff2030, emissiveIntensity: 2 });
  const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.45, 10, 8), beaconMat);
  beacon.position.copy(beaconPos);
  scene.add(beacon);
  const beaconLight = new THREE.PointLight(0xff3355, 0, 36, 2);
  beaconLight.position.copy(beaconPos);
  scene.add(beaconLight);

  const chevron = canvasTex((g, w, h) => {
    g.fillStyle = "#141414";
    g.fillRect(0, 0, w, h);
    g.fillStyle = "#ff9a1f";
    for (let x = -20; x < w; x += 36) {
      g.beginPath();
      g.moveTo(x, h);
      g.lineTo(x + 18, 0);
      g.lineTo(x + 28, 0);
      g.lineTo(x + 10, h);
      g.fill();
    }
  }, 128, 64);
  const rampMat = new THREE.MeshStandardMaterial({ map: chevron, roughness: 0.6, metalness: 0.1, color: 0xffffff });
  const rampSpots = [
    [0, 58],
    [0, -86],
    [0, 150],
    [96, 0],
  ];
  for (const [x, z] of rampSpots) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(7.5, 0.35, 6.5), rampMat);
    mesh.position.set(x!, 0.55, z!);
    mesh.rotation.x = -0.32;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    scene.add(mesh);
    ramps.push({ x: x!, z: z!, mesh });
  }

  function addShop(i: number, j: number, type: ShopType) {
    const block = blocks[i * GRID + j];
    if (!block) return;
    const x = block.x + 3.2;
    const z = block.z + 3.2;
    const group = new THREE.Group();
    const color = type === "health" ? 0x1f8a56 : type === "ammo" ? 0xc4842a : 0x2a6fbf;
    const body = new THREE.Mesh(
      new THREE.BoxGeometry(2.2, 2.4, 1.6),
      new THREE.MeshStandardMaterial({ color, roughness: 0.55, metalness: 0.15, emissive: color, emissiveIntensity: 0.18 }),
    );
    body.position.y = 1.2;
    body.castShadow = true;
    const label = type === "health" ? "MED" : type === "ammo" ? "AMMO" : "PAINT";
    const tex = canvasTex((g, w, h) => {
      g.fillStyle = "#0d1016";
      g.fillRect(0, 0, w, h);
      g.fillStyle = "#f4f7fb";
      g.font = "700 54px Impact, Arial Black, sans-serif";
      g.textAlign = "center";
      g.textBaseline = "middle";
      g.fillText(label, w / 2, h / 2 + 2);
    }, 256, 96);
    tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.7), new THREE.MeshBasicMaterial({ map: tex }));
    sign.position.set(0, 2.05, 0.82);
    const ringMat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.75 });
    const ring = new THREE.Mesh(new THREE.RingGeometry(1.5, 1.9, 28), ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.05;
    group.add(body, sign, ring);
    group.position.set(x, 0, z);
    scene.add(group);
    colliders.push({ x: x - 1.1, z: z - 0.8, w: 2.2, d: 1.6, h: 2.4 });
    shops.push({ type, x, z, group, ring, cd: 0 });
  }
  addShop(4, 1, "health");
  addShop(1, 4, "ammo");
  addShop(4, 4, "garage");

  for (let k = 0; k < 4; k++) {
    const s = k % 2 === 0 ? -1 : 1;
    const t = k < 2 ? -1 : 1;
    const x = s * (RD / 2 + 1.4);
    const z = t * (RD / 2 + 1.4);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 4.2, 6), poleMat);
    pole.position.set(x, 2.1, z);
    const box = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.9, 0.35), new THREE.MeshStandardMaterial({ color: 0x1a1c22 }));
    box.position.set(x, 4.3, z);
    scene.add(pole, box);
  }

  return { colliders, blocks, shops, ramps, nightMats, bulbMat, roadMats: [roadMatV, roadMatH, ixMat], beaconMat, beaconLight };
}
