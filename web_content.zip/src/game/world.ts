import * as THREE from "three";
import { getTextures, makeSign } from "@/game/textures";
import type { AABB } from "@/game/types";

export type World = {
  colliders: AABB[];
  hitMeshes: THREE.Object3D[];
  spawnPoints: THREE.Vector3[];
  lanterns: THREE.PointLight[];
  dispose: () => void;
};

function aabb(x: number, z: number, w: number, d: number, h: number): AABB {
  return {
    minX: x - w / 2,
    maxX: x + w / 2,
    minY: 0,
    maxY: h,
    minZ: z - d / 2,
    maxZ: z + d / 2,
  };
}

export function buildWorld(scene: THREE.Scene): World {
  const tex = getTextures();
  const colliders: AABB[] = [];
  const hitMeshes: THREE.Object3D[] = [];
  const lanterns: THREE.PointLight[] = [];
  const geos: THREE.BufferGeometry[] = [];
  const mats: THREE.Material[] = [];
  const extras: THREE.Texture[] = [];

  const wood = new THREE.MeshLambertMaterial({ map: tex.wood, color: 0xc4a882 });
  const darkWood = new THREE.MeshLambertMaterial({ map: tex.wood, color: 0x6a513c });
  const plaster = new THREE.MeshLambertMaterial({ map: tex.plaster, color: 0xddd3bf });
  const stone = new THREE.MeshLambertMaterial({ map: tex.stone });
  const dirt = new THREE.MeshLambertMaterial({ map: tex.dirt, color: 0x9a8468 });
  const roof = new THREE.MeshLambertMaterial({ color: 0x3a2a22 });
  const iron = new THREE.MeshLambertMaterial({ map: tex.metal, color: 0x4a4a48 });
  const glow = new THREE.MeshBasicMaterial({ color: 0xffb060 });
  const windowMat = new THREE.MeshBasicMaterial({ color: 0xe09a48 });
  mats.push(wood, darkWood, plaster, stone, dirt, roof, iron, glow, windowMat);

  tex.dirt.repeat.set(18, 18);
  tex.wood.repeat.set(2, 2);

  const track = <T extends THREE.BufferGeometry>(g: T) => {
    geos.push(g);
    return g;
  };

  const box = (w: number, h: number, d: number) => track(new THREE.BoxGeometry(w, h, d));
  const cyl = (rt: number, rb: number, h: number, seg = 8) =>
    track(new THREE.CylinderGeometry(rt, rb, h, seg));

  const addMesh = (
    geo: THREE.BufferGeometry,
    mat: THREE.Material,
    x: number,
    y: number,
    z: number,
    solid?: { w: number; d: number; h: number },
  ) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    m.castShadow = false;
    m.receiveShadow = false;
    scene.add(m);
    hitMeshes.push(m);
    if (solid) colliders.push(aabb(x, z, solid.w, solid.d, solid.h));
    return m;
  };

  scene.background = new THREE.Color(0x100e0c);
  scene.fog = new THREE.FogExp2(0x100e0c, 0.024);

  const hemi = new THREE.HemisphereLight(0xc4cde0, 0x2e2418, 0.72);
  scene.add(hemi);
  const moon = new THREE.DirectionalLight(0xe4ebf5, 0.48);
  moon.position.set(-20, 40, -10);
  scene.add(moon);

  const moonBall = new THREE.Mesh(
    track(new THREE.SphereGeometry(5, 16, 16)),
    new THREE.MeshBasicMaterial({ color: 0xe8ead8 }),
  );
  mats.push(moonBall.material as THREE.Material);
  moonBall.position.set(-48, 56, -70);
  scene.add(moonBall);

  const ground = addMesh(track(new THREE.PlaneGeometry(120, 120)), dirt, 0, 0, 0);
  ground.rotation.x = -Math.PI / 2;
  tex.dirt.wrapS = tex.dirt.wrapT = THREE.RepeatWrapping;

  // Town bounds
  const wallH = 3.2;
  const bound = 24;
  addMesh(box(bound * 2 + 2, wallH, 0.6), darkWood, 0, wallH / 2, -bound, {
    w: bound * 2 + 2,
    d: 0.8,
    h: wallH,
  });
  addMesh(box(bound * 2 + 2, wallH, 0.6), darkWood, 0, wallH / 2, bound, {
    w: bound * 2 + 2,
    d: 0.8,
    h: wallH,
  });
  addMesh(box(0.6, wallH, bound * 2), darkWood, -bound, wallH / 2, 0, {
    w: 0.8,
    d: bound * 2,
    h: wallH,
  });
  addMesh(box(0.6, wallH, bound * 2), darkWood, bound, wallH / 2, 0, {
    w: 0.8,
    d: bound * 2,
    h: wallH,
  });

  const building = (
    x: number,
    z: number,
    w: number,
    d: number,
    h: number,
    mat: THREE.Material,
  ) => {
    addMesh(box(w, h, d), mat, x, h / 2, z, { w, d, h });
    const roofMesh = addMesh(
      track(new THREE.ConeGeometry(Math.max(w, d) * 0.72, 1.6, 4)),
      roof,
      x,
      h + 0.7,
      z,
    );
    roofMesh.rotation.y = Math.PI / 4;
    // windows
    const win = box(0.5, 0.7, 0.08);
    const faces: Array<[number, number, number, number]> = [
      [x, 1.6, z + d / 2 + 0.02, 0],
      [x, 1.6, z - d / 2 - 0.02, Math.PI],
      [x + w / 2 + 0.02, 1.6, z, Math.PI / 2],
      [x - w / 2 - 0.02, 1.6, z, -Math.PI / 2],
    ];
    for (const [wx, wy, wz, rot] of faces) {
      const m = addMesh(win, windowMat, wx, wy, wz);
      m.rotation.y = rot;
    }
  };

  // Church
  building(0, -18.5, 10, 8, 6.2, plaster);
  const steeple = addMesh(box(2.2, 5.5, 2.2), plaster, 0, 9.2, -18.5);
  void steeple;
  const spire = addMesh(track(new THREE.ConeGeometry(1.4, 3.2, 4)), roof, 0, 13.4, -18.5);
  spire.rotation.y = Math.PI / 4;
  const crossV = addMesh(box(0.12, 1.1, 0.12), wood, 0, 15.2, -18.5);
  const crossH = addMesh(box(0.7, 0.12, 0.12), wood, 0, 15.45, -18.5);
  void crossV;
  void crossH;
  const churchSign = makeSign("CHURCH", "#3d3a34", "#ece4d4");
  extras.push(churchSign);
  const csMat = new THREE.MeshBasicMaterial({ map: churchSign });
  mats.push(csMat);
  addMesh(box(2.4, 1.1, 0.08), csMat, 0, 3.4, -14.4);

  // Saloon
  building(16.5, -6, 9, 7, 5.2, darkWood);
  const facade = addMesh(box(9.4, 2.2, 0.3), wood, 16.5, 6.2, -2.55);
  void facade;
  const saloonSign = makeSign("SALOON", "#4a2418", "#e8d7b8");
  extras.push(saloonSign);
  const ssMat = new THREE.MeshBasicMaterial({ map: saloonSign });
  mats.push(ssMat);
  addMesh(box(3.4, 1.3, 0.1), ssMat, 16.5, 4.4, -2.4);

  // Houses
  building(-16.5, -7, 8, 7, 4.4, wood);
  building(-16, 8, 7.5, 6.5, 4.1, darkWood);
  building(16, 9, 8, 7, 4.6, wood);
  building(-7, 18, 8, 6, 4, wood);
  building(6.5, 18.5, 7, 5.5, 3.8, darkWood);

  // Sheriff office
  building(-16.5, -16, 7, 6, 4.2, wood);
  const shSign = makeSign("SHERIFF", "#2c2418", "#d8cbb0");
  extras.push(shSign);
  const shMat = new THREE.MeshBasicMaterial({ map: shSign });
  mats.push(shMat);
  addMesh(box(2.8, 1.1, 0.08), shMat, -16.5, 3.2, -12.9);

  // Gallows
  addMesh(cyl(0.12, 0.14, 4.2, 6), darkWood, -1.4, 2.1, 0);
  addMesh(cyl(0.12, 0.14, 4.2, 6), darkWood, 1.4, 2.1, 0);
  addMesh(box(3.2, 0.22, 0.22), darkWood, 0, 4.2, 0);
  addMesh(box(2.6, 0.16, 2.2), darkWood, 0, 0.1, 0);
  const rope = addMesh(cyl(0.025, 0.025, 1.5, 5), iron, 0, 3.35, 0);
  void rope;
  const noose = addMesh(track(new THREE.TorusGeometry(0.16, 0.025, 6, 10)), iron, 0, 2.5, 0);
  noose.rotation.x = Math.PI / 2;

  // Well
  addMesh(cyl(0.7, 0.78, 0.9, 10), stone, 5.5, 0.45, 5, { w: 1.5, d: 1.5, h: 1.1 });
  addMesh(box(0.1, 1.4, 0.1), darkWood, 5.1, 1.4, 5);
  addMesh(box(0.1, 1.4, 0.1), darkWood, 5.9, 1.4, 5);
  addMesh(box(1.1, 0.1, 0.1), darkWood, 5.5, 2.1, 5);

  // Crates & barrels
  const barrelGeo = cyl(0.32, 0.32, 0.72, 8);
  const crateGeo = box(0.7, 0.7, 0.7);
  const covers: Array<[number, number]> = [
    [-4, 6],
    [-5.2, 6.5],
    [8, -4],
    [9, -3.4],
    [-8, -2],
    [3, -8],
    [11, 4],
    [-10, 4],
  ];
  covers.forEach(([x, z], i) => {
    if (i % 2 === 0) addMesh(barrelGeo, darkWood, x, 0.36, z, { w: 0.7, d: 0.7, h: 0.8 });
    else addMesh(crateGeo, wood, x, 0.35, z, { w: 0.75, d: 0.75, h: 0.75 });
  });

  // Wagon
  addMesh(box(2.8, 0.7, 1.4), wood, -6, 0.7, -8, { w: 2.9, d: 1.5, h: 1.2 });
  addMesh(track(new THREE.TorusGeometry(0.42, 0.08, 6, 10)), darkWood, -7.1, 0.42, -8.7);
  addMesh(track(new THREE.TorusGeometry(0.42, 0.08, 6, 10)), darkWood, -4.9, 0.42, -8.7);
  addMesh(track(new THREE.TorusGeometry(0.42, 0.08, 6, 10)), darkWood, -7.1, 0.42, -7.3);
  addMesh(track(new THREE.TorusGeometry(0.42, 0.08, 6, 10)), darkWood, -4.9, 0.42, -7.3);

  // Graveyard
  const stoneGeo = box(0.35, 0.9, 0.12);
  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 5; col++) {
      const gx = 12 + col * 1.5 + (row % 2) * 0.3;
      const gz = 13 + row * 1.7;
      const head = addMesh(stoneGeo, stone, gx, 0.45, gz, { w: 0.4, d: 0.25, h: 0.9 });
      head.rotation.y = (Math.random() - 0.5) * 0.25;
      head.rotation.z = (Math.random() - 0.5) * 0.12;
    }
  }
  addMesh(box(8.5, 0.9, 0.12), iron, 15, 0.45, 11.6, { w: 8.5, d: 0.2, h: 0.9 });

  // Hitching posts
  for (const [x, z] of [
    [-10, 0],
    [10, -1],
    [-3, 10],
  ] as Array<[number, number]>) {
    addMesh(cyl(0.08, 0.09, 1.2, 6), darkWood, x, 0.6, z);
  }

  // Lantern posts
  const lampPosts: Array<[number, number]> = [
    [-9, -9],
    [9, -9],
    [-9, 9],
    [9, 9],
  ];
  lampPosts.forEach(([x, z], i) => {
    addMesh(cyl(0.08, 0.1, 2.6, 6), darkWood, x, 1.3, z);
    addMesh(track(new THREE.SphereGeometry(0.14, 8, 8)), glow, x, 2.7, z);
    if (i < 4) {
      const light = new THREE.PointLight(0xffb060, 3.1, 16, 2);
      light.position.set(x, 2.7, z);
      scene.add(light);
      lanterns.push(light);
    }
  });

  const spawnPoints = [
    new THREE.Vector3(14, 0, 14),
    new THREE.Vector3(-14, 0, 14),
    new THREE.Vector3(14, 0, -10),
    new THREE.Vector3(-14, 0, -10),
    new THREE.Vector3(0, 0, 18),
    new THREE.Vector3(18, 0, 0),
    new THREE.Vector3(-18, 0, 2),
    new THREE.Vector3(8, 0, 16),
  ];

  return {
    colliders,
    hitMeshes,
    spawnPoints,
    lanterns,
    dispose: () => {
      for (const g of geos) g.dispose();
      for (const m of mats) m.dispose();
      for (const t of extras) t.dispose();
    },
  };
}
