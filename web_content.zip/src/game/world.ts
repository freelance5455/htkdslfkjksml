import * as THREE from 'three';
import {
  buildingFacadeTexture,
  roadTexture,
  dirtRoadTexture,
  sandTexture,
  grassTexture,
  rockTexture,
  houseWallTexture,
  roofTexture,
  cloudTexture,
  leafTexture,
  barkTexture,
  sidewalkTexture,
  fieldTexture,
  billboardTexture,
  groundSplatTexture,
  envReflectionTexture,
  seededRandom,
} from './textures';

export type Quality = 'low' | 'medium' | 'high';
export type Surface = 'asphalt' | 'dirt' | 'grass' | 'sand' | 'water' | 'sidewalk';
export interface Collider { minX: number; maxX: number; minZ: number; maxZ: number; }
export interface TrafficPath { points: THREE.Vector3[]; loop: boolean; speed: number; elevated?: boolean }

export const WORLD = {
  SIZE: 2400,
  MIN_X: -1000,
  MAX_X: 1000,
  MIN_Z: -1000,
  MAX_Z: 610, // water edge
  CITY: { x1: -420, x2: 420, z1: -520, z2: 220 },
  VILLAGE: { x1: 450, x2: 810, z1: -210, z2: 250 },
  FOREST_E: { x1: 430, x2: 1010, z1: -990, z2: -240 },
  FOREST_W: { x1: -1010, x2: -450, z1: -990, z2: -80 },
  BEACH_Z1: 440,
  SEA_Z: 630,
};

export interface WorldBuild {
  colliders: Collider[];
  treeGrid: Map<string, { x: number; z: number; r: number }[]>;
  trafficPaths: TrafficPath[];
  seaMat: THREE.ShaderMaterial;
  clouds: THREE.Sprite[];
  getSurfaceAt: (x: number, z: number) => Surface;
  getGroundHeightAt: (x: number, z: number) => number;
  getRegionAt: (x: number, z: number) => string;
  update: (dt: number, elapsed: number, playerPos: THREE.Vector3) => void;
}

// ---------- noise ----------
function hash2(x: number, y: number): number {
  const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return s - Math.floor(s);
}
function smooth(t: number) { return t * t * (3 - 2 * t); }
function valueNoise(x: number, y: number): number {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const a = hash2(xi, yi);
  const b = hash2(xi + 1, yi);
  const c = hash2(xi, yi + 1);
  const d = hash2(xi + 1, yi + 1);
  const u = smooth(xf);
  const v = smooth(yf);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
function fbm(x: number, y: number, oct = 4): number {
  let v = 0;
  let amp = 0.5;
  let f = 1;
  for (let i = 0; i < oct; i++) {
    v += amp * valueNoise(x * f, y * f);
    amp *= 0.5;
    f *= 2.03;
  }
  return v;
}

// ---------- surface / height helpers (shared) ----------
const CITY_ROADS_X: number[] = [];
for (let x = -400; x <= 400; x += 100) CITY_ROADS_X.push(x);
const CITY_ROADS_Z: number[] = [];
for (let z = -500; z <= 200; z += 100) CITY_ROADS_Z.push(z);

function distToSeg(px: number, pz: number, ax: number, az: number, bx: number, bz: number): number {
  const dx = bx - ax;
  const dz = bz - az;
  const len2 = dx * dx + dz * dz;
  if (len2 === 0) return Math.hypot(px - ax, pz - az);
  let t = ((px - ax) * dx + (pz - az) * dz) / len2;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + t * dx), pz - (az + t * dz));
}

const DIRT_SEGS: [number, number, number, number][] = [
  [420, 0, 620, 20],
  [620, -180, 750, -450],
  [620, 20, 620, -180],
  [500, -200, 800, -200],
  [700, -450, 850, -700],
  [560, -600, 900, -550],
  [-700, -100, -700, -800],
  [-850, -400, -550, -500],
];
const PAVED_SEGS: [number, number, number, number, number][] = [
  // x1,z1,x2,z2,halfWidth
  [-1050, 380, 1050, 380, 11], // coastal highway
  [-460, -560, -460, 280, 9], // ring west
  [460, -560, 460, 280, 9], // ring east
  [-460, -560, 460, -560, 9], // ring north
  [-460, 280, 460, 280, 9], // ring south
  [420, 0, 470, 0, 8], // city to ring east
  [470, 0, 640, 20, 7], // to village
  [640, 20, 640, -180, 6],
];

export function getSurfaceAt(x: number, z: number): Surface {
  if (z > WORLD.SEA_Z - 15) return 'water';
  if (z > WORLD.BEACH_Z1) return 'sand';
  // bridge deck counts as asphalt
  if (Math.abs(z + 150) < 10 && x > -330 && x < 330) return 'asphalt';
  // city grid
  if (x > WORLD.CITY.x1 - 20 && x < WORLD.CITY.x2 + 20 && z > WORLD.CITY.z1 - 20 && z < WORLD.CITY.z2 + 20) {
    for (const rx of CITY_ROADS_X) if (Math.abs(x - rx) < 8 && z > WORLD.CITY.z1 - 10 && z < WORLD.CITY.z2 + 10) return 'asphalt';
    for (const rz of CITY_ROADS_Z) if (Math.abs(z - rz) < 8 && x > WORLD.CITY.x1 - 10 && x < WORLD.CITY.x2 + 10) return 'asphalt';
    return 'sidewalk';
  }
  for (const [ax, az, bx, bz, hw] of PAVED_SEGS) {
    if (distToSeg(x, z, ax, az, bx, bz) < hw) return 'asphalt';
  }
  for (const [ax, az, bx, bz] of DIRT_SEGS) {
    if (distToSeg(x, z, ax, az, bx, bz) < 7) return 'dirt';
  }
  return 'grass';
}

export function getGroundHeightAt(x: number, z: number): number {
  // overpass bridge along z=-150
  if (Math.abs(z + 150) < 9 && x > -330 && x < 330) {
    const H = 8;
    if (x < -260) {
      const t = (x + 330) / 70; // 0..1
      const s = t * t * (3 - 2 * t);
      return H * s;
    } else if (x <= 260) {
      return H;
    } else {
      const t = (330 - x) / 70;
      const s = t * t * (3 - 2 * t);
      return H * s;
    }
  }
  return 0;
}

export function getRegionAt(x: number, z: number): string {
  if (z > WORLD.SEA_Z - 15) return 'دریا';
  if (z > WORLD.BEACH_Z1) return 'ساحل';
  if (x > WORLD.CITY.x1 && x < WORLD.CITY.x2 && z > WORLD.CITY.z1 && z < WORLD.CITY.z2) return 'شهر';
  if (x > WORLD.VILLAGE.x1 && x < WORLD.VILLAGE.x2 && z > WORLD.VILLAGE.z1 && z < WORLD.VILLAGE.z2) return 'روستا';
  if (x > WORLD.FOREST_E.x1 && x < WORLD.FOREST_E.x2 && z > WORLD.FOREST_E.z1 && z < WORLD.FOREST_E.z2) return 'جنگل شرقی';
  if (x > WORLD.FOREST_W.x1 && x < WORLD.FOREST_W.x2 && z > WORLD.FOREST_W.z1 && z < WORLD.FOREST_W.z2) return 'جنگل غربی';
  if (Math.abs(z + 150) < 12 && Math.abs(x) < 340) return 'پل هوایی';
  if (Math.abs(z - 380) < 16) return 'جاده ساحلی';
  if (x > 900 || x < -900 || z < -880) return 'کوهستان';
  return 'حومه';
}

// ============================================================
export async function buildWorld(
  scene: THREE.Scene,
  quality: Quality,
  onProgress?: (p: number, label: string) => void
): Promise<WorldBuild> {
  const prog = (p: number, label: string) => {
    onProgress?.(p, label);
  };
  const tick = () => new Promise<void>((r) => setTimeout(r, 0));

  const colliders: Collider[] = [];
  const treeGrid = new Map<string, { x: number; z: number; r: number }[]>();
  const addTreeCollider = (x: number, z: number, r: number) => {
    const key = `${Math.floor(x / 40)},${Math.floor(z / 40)}`;
    let arr = treeGrid.get(key);
    if (!arr) {
      arr = [];
      treeGrid.set(key, arr);
    }
    arr.push({ x, z, r });
  };
  const addCollider = (cx: number, cz: number, w: number, d: number) => {
    colliders.push({ minX: cx - w / 2, maxX: cx + w / 2, minZ: cz - d / 2, maxZ: cz + d / 2 });
  };

  const rand = seededRandom(20260924);
  const Q = quality === 'low' ? 0 : quality === 'medium' ? 1 : 2;

  // ---------------- LIGHTS / SKY / SUN ----------------
  prog(0.04, 'خورشید و آسمان');
  scene.environment = envReflectionTexture();
  const sunDir = new THREE.Vector3(0.55, 0.75, 0.35).normalize();
  const sun = new THREE.DirectionalLight(0xfff4e0, 2.75);
  sun.position.copy(sunDir).multiplyScalar(300);
  sun.castShadow = quality !== 'low';
  const shadowRes = Q === 2 ? 2048 : Q === 1 ? 1536 : 1024;
  sun.shadow.mapSize.set(shadowRes, shadowRes);
  sun.shadow.camera.near = 10;
  sun.shadow.camera.far = 700;
  const sc = Q === 2 ? 135 : 105;
  sun.shadow.camera.left = -sc;
  sun.shadow.camera.right = sc;
  sun.shadow.camera.top = sc;
  sun.shadow.camera.bottom = -sc;
  sun.shadow.bias = -0.00035;
  sun.shadow.normalBias = 0.4;
  scene.add(sun);
  scene.add(sun.target);

  const hemi = new THREE.HemisphereLight(0xc4def7, 0x5e7d4c, 0.95);
  scene.add(hemi);
  const amb = new THREE.AmbientLight(0xfffaf0, 0.28);
  scene.add(amb);

  // sky dome with gradient + sun disc
  const skyGeo = new THREE.SphereGeometry(3000, 24, 16);
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    uniforms: {
      sunDir: { value: sunDir },
    },
    vertexShader: `
      varying vec3 vDir;
      void main() {
        vDir = normalize(position);
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      varying vec3 vDir;
      uniform vec3 sunDir;
      void main() {
        float h = clamp(vDir.y, -0.1, 1.0);
        vec3 zenith = vec3(0.12, 0.35, 0.75);
        vec3 mid = vec3(0.38, 0.62, 0.92);
        vec3 horizon = vec3(0.82, 0.90, 0.97);
        vec3 col = mix(horizon, mid, smoothstep(0.0, 0.35, h));
        col = mix(col, zenith, smoothstep(0.35, 1.0, h));
        // warm haze near sun
        float s = max(dot(normalize(vDir), normalize(sunDir)), 0.0);
        col += vec3(1.0, 0.85, 0.6) * pow(s, 24.0) * 0.35;
        col += vec3(1.0, 0.95, 0.8) * pow(s, 350.0) * 1.2;
        // sun disc
        col += vec3(1.0, 0.98, 0.9) * smoothstep(0.9993, 0.9997, s) * 2.0;
        // below horizon: sea haze
        if (vDir.y < 0.0) col = mix(col, vec3(0.65, 0.78, 0.86), clamp(-vDir.y * 4.0, 0.0, 1.0));
        gl_FragColor = vec4(col, 1.0);
      }`,
  });
  const sky = new THREE.Mesh(skyGeo, skyMat);
  sky.frustumCulled = false;
  scene.add(sky);

  // sun lens glow sprite
  const glowCanvas = document.createElement('canvas');
  glowCanvas.width = glowCanvas.height = 128;
  const gctx = glowCanvas.getContext('2d')!;
  const gg = gctx.createRadialGradient(64, 64, 4, 64, 64, 64);
  gg.addColorStop(0, 'rgba(255,250,230,1)');
  gg.addColorStop(0.25, 'rgba(255,240,200,0.55)');
  gg.addColorStop(1, 'rgba(255,240,200,0)');
  gctx.fillStyle = gg;
  gctx.fillRect(0, 0, 128, 128);
  const glowTex = new THREE.CanvasTexture(glowCanvas);
  const sunSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, transparent: true, depthWrite: false, fog: false }));
  sunSprite.scale.set(500, 500, 1);
  sunSprite.position.copy(sunDir).multiplyScalar(2600);
  scene.add(sunSprite);

  // clouds
  const cloudTex = cloudTexture();
  const clouds: THREE.Sprite[] = [];
  const cloudCount = Q === 0 ? 10 : Q === 1 ? 15 : 20;
  for (let i = 0; i < cloudCount; i++) {
    const m = new THREE.SpriteMaterial({ map: cloudTex, transparent: true, opacity: 0.75 + rand() * 0.25, depthWrite: false, fog: false });
    const sp = new THREE.Sprite(m);
    const w = 180 + rand() * 320;
    sp.scale.set(w, w * 0.45, 1);
    sp.position.set((rand() - 0.5) * 3600, 320 + rand() * 260, (rand() - 0.5) * 3600);
    sp.userData.speed = 2 + rand() * 4;
    scene.add(sp);
    clouds.push(sp);
  }

  scene.fog = new THREE.Fog(0xc8dcec, Q === 0 ? 250 : 350, Q === 0 ? 1200 : 1700);
  await tick();

  // ---------------- GROUND ----------------
  prog(0.1, 'زمین و نقشه');
  const groundTex = groundSplatTexture();
  const groundMat = new THREE.MeshStandardMaterial({ map: groundTex, roughness: 0.95, metalness: 0.0 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(WORLD.SIZE, WORLD.SIZE, 1, 1), groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);

  // detail overlays: grass tiling patch (blended via second transparent plane? Instead add grass only outside city via vertex alpha is complex.
  // Add subtle tiling detail using a large transparent plane with grass texture at low opacity outside city/beach)
  const grassDetail = grassTexture();
  // mask out city concrete + beach/sea so the green detail only shows on natural ground
  const maskCanvas = document.createElement('canvas');
  maskCanvas.width = maskCanvas.height = 256;
  const mctx = maskCanvas.getContext('2d')!;
  mctx.fillStyle = '#ffffff';
  mctx.fillRect(0, 0, 256, 256);
  mctx.fillStyle = '#000000';
  const mmx = (x: number) => ((x + 1200) / 2400) * 256;
  const mmz = (z: number) => ((z + 1200) / 2400) * 256;
  mctx.fillRect(mmx(WORLD.CITY.x1 - 10), mmz(WORLD.CITY.z1 - 10), mmx(WORLD.CITY.x2 + 10) - mmx(WORLD.CITY.x1 - 10), mmz(WORLD.CITY.z2 + 10) - mmz(WORLD.CITY.z1 - 10));
  mctx.fillRect(0, mmz(425), 256, 256 - mmz(425));
  const grassMask = new THREE.CanvasTexture(maskCanvas);
  const grassOverlayMat = new THREE.MeshStandardMaterial({ map: grassDetail, transparent: true, opacity: 0.5, roughness: 1, depthWrite: false, alphaMap: grassMask });
  const grassOverlay = new THREE.Mesh(new THREE.PlaneGeometry(WORLD.SIZE, WORLD.SIZE), grassOverlayMat);
  grassOverlay.rotation.x = -Math.PI / 2;
  grassOverlay.position.y = 0.02;
  grassOverlay.receiveShadow = true;
  scene.add(grassOverlay);

  // sand overlay with high quality tiling
  const sandTex = sandTexture();
  const sandMat = new THREE.MeshStandardMaterial({ map: sandTex, roughness: 0.9 });
  const sand = new THREE.Mesh(new THREE.PlaneGeometry(2400, 200), sandMat);
  sand.rotation.x = -Math.PI / 2;
  sand.position.set(0, 0.04, 530);
  sand.receiveShadow = true;
  scene.add(sand);

  await tick();

  // ---------------- SEA (animated shader) ----------------
  prog(0.16, 'دریا و موج');
  const seaMat = new THREE.ShaderMaterial({
    transparent: false,
    fog: false,
    uniforms: {
      uTime: { value: 0 },
      sunDir: { value: sunDir },
    },
    vertexShader: `
      uniform float uTime;
      varying vec3 vPos;
      varying float vWave;
      void main() {
        vec3 p = position;
        // plane is rotated; local x,y map to world x,z
        float w1 = sin(p.x * 0.02 + uTime * 1.2) * 0.9;
        float w2 = sin(p.y * 0.035 - uTime * 1.6) * 0.7;
        float w3 = sin((p.x + p.y) * 0.012 + uTime * 0.7) * 1.1;
        float wave = w1 + w2 + w3;
        p.z += wave;
        vWave = wave;
        vPos = (modelMatrix * vec4(p, 1.0)).xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
      }`,
    fragmentShader: `
      uniform float uTime;
      uniform vec3 sunDir;
      varying vec3 vPos;
      varying float vWave;
      void main() {
        float shore = smoothstep(615.0, 700.0, vPos.z); // 0 near shore, 1 deep
        vec3 shallow = vec3(0.25, 0.65, 0.75);
        vec3 mid = vec3(0.08, 0.42, 0.66);
        vec3 deep = vec3(0.02, 0.22, 0.45);
        vec3 col = mix(shallow, mid, smoothstep(0.0, 0.45, shore));
        col = mix(col, deep, smoothstep(0.4, 1.0, shore));
        // moving sparkle ripples
        float r1 = sin(vPos.x * 0.15 + uTime * 2.0 + sin(vPos.z * 0.2 + uTime) * 2.0);
        float r2 = sin(vPos.z * 0.11 - uTime * 1.4 + sin(vPos.x * 0.13) * 2.0);
        float ripple = (r1 + r2) * 0.25 + 0.5;
        col += vec3(0.06, 0.10, 0.12) * ripple;
        // sun glint
        vec3 n = normalize(vec3(r1 * 0.12, 1.0, r2 * 0.12));
        vec3 viewDir = normalize(cameraPosition - vPos);
        vec3 hv = normalize(viewDir + normalize(sunDir));
        float spec = pow(max(dot(n, hv), 0.0), 120.0);
        col += vec3(1.0, 0.95, 0.8) * spec * 1.4;
        // foam near shore
        float foamBand = smoothstep(628.0, 615.0, vPos.z + sin(vPos.x * 0.05 + uTime * 1.8) * 6.0);
        float foamTex = smoothstep(0.4, 0.9, sin(vPos.x * 0.5 + uTime * 2.5) * 0.5 + 0.5) * foamBand;
        col = mix(col, vec3(0.95, 0.97, 0.98), clamp(foamBand * 0.75 + foamTex * 0.3, 0.0, 1.0));
        // wave crest lighten
        col += vec3(0.05) * smoothstep(1.2, 2.4, vWave);
        gl_FragColor = vec4(col, 1.0);
      }`,
  });
  const seaGeo = new THREE.PlaneGeometry(3600, 1150, 90, 30);
  const sea = new THREE.Mesh(seaGeo, seaMat);
  sea.rotation.x = -Math.PI / 2;
  sea.position.set(0, 0.6, 630 + 575);
  scene.add(sea);

  await tick();

  // ---------------- ROADS ----------------
  prog(0.24, 'جاده‌ها و خیابان‌ها');
  const roadGroup = new THREE.Group();
  scene.add(roadGroup);
  const roadMat2 = new THREE.MeshStandardMaterial({ map: roadTexture(2, 11), roughness: 0.9 });
  const roadMat4 = new THREE.MeshStandardMaterial({ map: roadTexture(4, 23), roughness: 0.9 });
  const roadMat6 = new THREE.MeshStandardMaterial({ map: roadTexture(6, 37), roughness: 0.9 });
  const dirtMat = new THREE.MeshStandardMaterial({ map: dirtRoadTexture(5), roughness: 1 });

  function addRoadPlane(cx: number, cz: number, w: number, l: number, mat: THREE.Material, rotY = 0, y = 0.06) {
    const g = new THREE.PlaneGeometry(w, l);
    const m = new THREE.Mesh(g, mat);
    m.rotation.x = -Math.PI / 2;
    m.rotation.z = rotY;
    m.position.set(cx, y, cz);
    m.receiveShadow = true;
    roadGroup.add(m);
    return m;
  }
  function addRoadSeg(ax: number, az: number, bx: number, bz: number, width: number, mat: THREE.Material, y = 0.06) {
    const dx = bx - ax;
    const dz = bz - az;
    const len = Math.hypot(dx, dz);
    const ang = Math.atan2(dx, dz);
    const stdMat = mat as THREE.MeshStandardMaterial;
    const tex = (stdMat.map as THREE.CanvasTexture | null)?.clone();
    let useMat = mat;
    if (tex) {
      tex.needsUpdate = true;
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(1, Math.max(1, Math.round(len / 40)));
      useMat = (mat as THREE.MeshStandardMaterial).clone();
      (useMat as THREE.MeshStandardMaterial).map = tex;
    }
    const g = new THREE.PlaneGeometry(width, len);
    const m = new THREE.Mesh(g, useMat);
    m.rotation.x = -Math.PI / 2;
    m.rotation.z = ang;
    m.position.set((ax + bx) / 2, y, (az + bz) / 2);
    m.receiveShadow = true;
    roadGroup.add(m);
    return m;
  }

  // city grid
  for (const rx of CITY_ROADS_X) {
    const isBridgeLine = false;
    void isBridgeLine;
    const t = roadMat2.map?.clone();
    if (t) {
      t.needsUpdate = true;
      t.wrapS = t.wrapT = THREE.RepeatWrapping;
      t.repeat.set(1, 18);
    }
    const mm = roadMat2.clone();
    if (t) mm.map = t;
    addRoadPlane(rx, (WORLD.CITY.z1 + WORLD.CITY.z2) / 2, 15, WORLD.CITY.z2 - WORLD.CITY.z1 + 30, mm);
  }
  for (const rz of CITY_ROADS_Z) {
    const t = roadMat2.map?.clone();
    if (t) {
      t.needsUpdate = true;
      t.wrapS = t.wrapT = THREE.RepeatWrapping;
      t.repeat.set(1, 22);
    }
    const mm = roadMat2.clone();
    if (t) mm.map = t;
    addRoadPlane((WORLD.CITY.x1 + WORLD.CITY.x2) / 2, rz, 15, WORLD.CITY.x2 - WORLD.CITY.x1 + 30, mm, Math.PI / 2, 0.065);
  }
  // ring highway
  addRoadSeg(-460, -560, -460, 280, 20, roadMat4);
  addRoadSeg(460, -560, 460, 280, 20, roadMat4);
  addRoadSeg(-460, -560, 460, -560, 20, roadMat4);
  addRoadSeg(-460, 280, 460, 280, 20, roadMat4);
  // coastal highway (wide)
  {
    const t = roadMat6.map?.clone();
    if (t) {
      t.needsUpdate = true;
      t.wrapS = t.wrapT = THREE.RepeatWrapping;
      t.repeat.set(1, 52);
    }
    const mm = roadMat6.clone();
    if (t) mm.map = t;
    addRoadPlane(0, 380, 24, 2120, mm, Math.PI / 2, 0.07);
  }
  // connectors
  addRoadSeg(420, 0, 640, 20, 15, roadMat2);
  addRoadSeg(640, 20, 640, -180, 12, roadMat2);
  // dirt roads
  for (const [ax, az, bx, bz] of DIRT_SEGS) addRoadSeg(ax, az, bx, bz, 10, dirtMat, 0.05);

  // sidewalks: instanced slabs per block
  {
    const swTex = sidewalkTexture();
    const swMat = new THREE.MeshStandardMaterial({ map: swTex, roughness: 0.95 });
    const geo = new THREE.PlaneGeometry(1, 1);
    const mats: THREE.Matrix4[] = [];
    const dummy = new THREE.Object3D();
    for (let ix = 0; ix < CITY_ROADS_X.length - 1; ix++) {
      for (let iz = 0; iz < CITY_ROADS_Z.length - 1; iz++) {
        const x1 = CITY_ROADS_X[ix] + 9;
        const x2 = CITY_ROADS_X[ix + 1] - 9;
        const z1 = CITY_ROADS_Z[iz] + 9;
        const z2 = CITY_ROADS_Z[iz + 1] - 9;
        if (x2 - x1 < 10 || z2 - z1 < 10) continue;
        dummy.position.set((x1 + x2) / 2, 0.05, (z1 + z2) / 2);
        dummy.rotation.set(-Math.PI / 2, 0, 0);
        dummy.scale.set(x2 - x1, z2 - z1, 1);
        dummy.updateMatrix();
        mats.push(dummy.matrix.clone());
      }
    }
    const inst = new THREE.InstancedMesh(geo, swMat, mats.length);
    mats.forEach((m, i) => inst.setMatrixAt(i, m));
    inst.receiveShadow = true;
    roadGroup.add(inst);
  }

  // overpass bridge deck (elevated highway over city center at z=-150)
  const bridgeGroup = new THREE.Group();
  scene.add(bridgeGroup);
  {
    const deckMat = new THREE.MeshStandardMaterial({ map: roadTexture(4, 51), roughness: 0.85 });
    if (deckMat.map) {
      deckMat.map = deckMat.map.clone();
      deckMat.map.needsUpdate = true;
      deckMat.map.wrapS = deckMat.map.wrapT = THREE.RepeatWrapping;
      deckMat.map.repeat.set(1, 16);
    }
    // build deck in segments following height profile
    const segLen = 30;
    for (let x = -330; x < 330; x += segLen) {
      const x0 = x;
      const h0 = getGroundHeightAt(x0 + segLen / 2 - 5, -150);
      const h1 = getGroundHeightAt(x0 + segLen / 2 + 5, -150);
      const hAvg = (h0 + h1) / 2;
      const slope = Math.atan2(h1 - h0, 10);
      const deck = new THREE.Mesh(new THREE.BoxGeometry(segLen + 1, 1.2, 20), deckMat);
      deck.position.set(x0 + segLen / 2, hAvg + 0.4, -150);
      deck.rotation.z = slope;
      deck.castShadow = true;
      deck.receiveShadow = true;
      bridgeGroup.add(deck);
      // side rails
      const railMat = new THREE.MeshStandardMaterial({ color: '#7d8aa0', metalness: 0.7, roughness: 0.4 });
      for (const side of [-1, 1]) {
        const rail = new THREE.Mesh(new THREE.BoxGeometry(segLen + 1, 1.0, 0.4), railMat);
        rail.position.set(x0 + segLen / 2, hAvg + 1.6, -150 + side * 9.6);
        rail.rotation.z = slope;
        bridgeGroup.add(rail);
      }
      // under-girder
      const girder = new THREE.Mesh(
        new THREE.BoxGeometry(segLen + 1, 1.6, 2.2),
        new THREE.MeshStandardMaterial({ color: '#4a5261', roughness: 0.7 })
      );
      girder.position.set(x0 + segLen / 2, hAvg - 0.8, -150);
      girder.rotation.z = slope;
      bridgeGroup.add(girder);
    }
    // pillars
    const pillarGeo = new THREE.CylinderGeometry(1.6, 2.0, 1, 10);
    const pillarMat = new THREE.MeshStandardMaterial({ color: '#9aa3b2', roughness: 0.8 });
    const capGeo = new THREE.BoxGeometry(4, 1.4, 22);
    for (let x = -225; x <= 225; x += 50) {
      const h = getGroundHeightAt(x, -150);
      if (h < 2) continue;
      const pillar = new THREE.Mesh(pillarGeo, pillarMat);
      pillar.scale.y = h;
      pillar.position.set(x, h / 2, -150);
      pillar.castShadow = true;
      bridgeGroup.add(pillar);
      const cap = new THREE.Mesh(capGeo, pillarMat);
      cap.position.set(x, h - 0.5, -150);
      cap.castShadow = true;
      bridgeGroup.add(cap);
      addCollider(x, -150, 4, 4);
    }
    // bridge lamps
    const lampPoleMat = new THREE.MeshStandardMaterial({ color: '#2b3340', roughness: 0.6, metalness: 0.5 });
    const lampHeadMat = new THREE.MeshStandardMaterial({ color: '#fff8d8', emissive: '#ffedb0', emissiveIntensity: 0.4 });
    for (let x = -240; x <= 240; x += 40) {
      const h = getGroundHeightAt(x, -150);
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 7, 6), lampPoleMat);
      pole.position.set(x, h + 4.5, -141);
      bridgeGroup.add(pole);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.15, 2.4), lampPoleMat);
      arm.position.set(x, h + 7.8, -142);
      bridgeGroup.add(arm);
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.18, 0.9), lampHeadMat);
      head.position.set(x, h + 7.7, -143);
      bridgeGroup.add(head);
    }
  }

  await tick();

  // ---------------- CITY BUILDINGS ----------------
  prog(0.36, 'ساختمان‌های شهر');
  const facadeStyles = [
    { map: buildingFacadeTexture({ baseColor: '#3a4a63', trimColor: '#1c2433', glassColor1: '#9fc4e8', glassColor2: '#4a739c', floors: 8, cols: 6, seed: 11, style: 0 }), roughness: 0.6, metalness: 0.25 },
    { map: buildingFacadeTexture({ baseColor: '#b8b2a6', trimColor: '#6b655a', glassColor1: '#7fa8c9', glassColor2: '#3d5a78', floors: 6, cols: 5, seed: 22, style: 1 }), roughness: 0.85, metalness: 0 },
    { map: buildingFacadeTexture({ baseColor: '#8f4a3a', trimColor: '#4a2620', glassColor1: '#a8c8e0', glassColor2: '#48657f', floors: 5, cols: 5, seed: 33, style: 2 }), roughness: 0.8, metalness: 0 },
    { map: buildingFacadeTexture({ baseColor: '#2b3547', trimColor: '#d8b25a', glassColor1: '#c8dcf0', glassColor2: '#5a7a9c', floors: 10, cols: 7, seed: 44, style: 3 }), roughness: 0.5, metalness: 0.35 },
    { map: buildingFacadeTexture({ baseColor: '#d8d3c5', trimColor: '#5a6a7a', glassColor1: '#8fb8d8', glassColor2: '#3f5c7a', floors: 7, cols: 6, seed: 55, style: 1 }), roughness: 0.8, metalness: 0 },
    { map: buildingFacadeTexture({ baseColor: '#1f6a72', trimColor: '#102f33', glassColor1: '#b8e0e8', glassColor2: '#3f8a94', floors: 9, cols: 6, seed: 66, style: 0 }), roughness: 0.55, metalness: 0.3 },
  ];
  // Pre-tiled variants per height bucket so tall towers keep correct window proportions
  const facadeMats: THREE.MeshStandardMaterial[][] = facadeStyles.map((s) =>
    [1, 2, 4].map((rep) => {
      const tex = s.map.clone();
      tex.needsUpdate = true;
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(1, rep);
      return new THREE.MeshStandardMaterial({ map: tex, roughness: s.roughness, metalness: s.metalness });
    })
  );
  const pickFacade = (h: number) => {
    const style = facadeMats[Math.floor(rand() * facadeMats.length)];
    return style[h < 28 ? 0 : h < 65 ? 1 : 2];
  };
  const roofCapMat = new THREE.MeshStandardMaterial({ color: '#565b64', roughness: 0.95 });
  const roofBoxMat = new THREE.MeshStandardMaterial({ color: '#7c828c', roughness: 0.9 });

  const roofCapMatrices: THREE.Matrix4[] = [];
  const acMatrices: THREE.Matrix4[] = [];
  const tankMatrices: THREE.Matrix4[] = [];
  const antennaMatrices: THREE.Matrix4[] = [];
  const dummy = new THREE.Object3D();

  const cityGroup = new THREE.Group();
  scene.add(cityGroup);

  // blocks
  for (let ix = 0; ix < CITY_ROADS_X.length - 1; ix++) {
    for (let iz = 0; iz < CITY_ROADS_Z.length - 1; iz++) {
      // skip blocks crossed by bridge? bridge is elevated; allow buildings under it but keep clearance near deck pillars line
      const x1 = CITY_ROADS_X[ix] + 11;
      const x2 = CITY_ROADS_X[ix + 1] - 11;
      const z1 = CITY_ROADS_Z[iz] + 11;
      const z2 = CITY_ROADS_Z[iz + 1] - 11;
      const bw = x2 - x1;
      const bd = z2 - z1;
      if (bw < 18 || bd < 18) continue;
      const cx = (x1 + x2) / 2;
      const cz = (z1 + z2) / 2;
      const distCenter = Math.hypot(cx / 420, cz / 420);

      // decide 1-3 buildings per block
      const nB = rand() > 0.55 ? 2 : 1;
      const slots: [number, number, number, number][] = [];
      if (nB === 1) {
        slots.push([cx, cz, bw * (0.55 + rand() * 0.25), bd * (0.55 + rand() * 0.25)]);
      } else {
        if (bw > bd) {
          slots.push([x1 + bw * 0.26, cz, bw * 0.42, bd * (0.55 + rand() * 0.2)]);
          slots.push([x1 + bw * 0.74, cz, bw * 0.42, bd * (0.55 + rand() * 0.2)]);
        } else {
          slots.push([cx, z1 + bd * 0.26, bw * (0.55 + rand() * 0.2), bd * 0.42]);
          slots.push([cx, z1 + bd * 0.74, bw * (0.55 + rand() * 0.2), bd * 0.42]);
        }
      }

      for (const [bx, bz, w0, d0] of slots) {
        // keep clear of bridge pillars strip
        if (Math.abs(bz + 150) < 16 && Math.abs(bx) < 260) continue;
        const w = Math.max(14, Math.min(52, w0));
        const d = Math.max(14, Math.min(52, d0));
        // height: taller near center + random
        const base = 12 + (1 - Math.min(1, distCenter)) * (Q === 0 ? 55 : 95) + rand() * 28;
        const h = Math.max(10, Math.min(130, base));
        const mat = pickFacade(h);

        // podium
        let podiumH = 0;
        if (h > 45 && rand() > 0.4) {
          podiumH = 7;
          const podium = new THREE.Mesh(new THREE.BoxGeometry(w + 6, podiumH, d + 6), pickFacade(10));
          podium.position.set(bx, podiumH / 2, bz);
          podium.castShadow = true;
          podium.receiveShadow = true;
          cityGroup.add(podium);
        }

        // main tower (with setback for tall)
        if (h > 70 && rand() > 0.35) {
          const h1 = h * 0.55;
          const h2 = h * 0.45;
          const t1 = new THREE.Mesh(new THREE.BoxGeometry(w, h1, d), mat);
          t1.position.set(bx, podiumH + h1 / 2, bz);
          t1.castShadow = true;
          t1.receiveShadow = true;
          cityGroup.add(t1);
          const t2 = new THREE.Mesh(new THREE.BoxGeometry(w * 0.72, h2, d * 0.72), mat);
          t2.position.set(bx + (rand() - 0.5) * w * 0.1, podiumH + h1 + h2 / 2, bz + (rand() - 0.5) * d * 0.1);
          t2.castShadow = true;
          t2.receiveShadow = true;
          cityGroup.add(t2);
          // roof cap on top
          dummy.position.set(t2.position.x, podiumH + h + 0.3, t2.position.z);
          dummy.rotation.set(0, 0, 0);
          dummy.scale.set(w * 0.72 + 0.8, 0.6, d * 0.72 + 0.8);
          dummy.updateMatrix();
          roofCapMatrices.push(dummy.matrix.clone());
          // props on top
          if (rand() > 0.3) {
            dummy.position.set(t2.position.x + (rand() - 0.5) * w * 0.3, podiumH + h + 1.4, t2.position.z);
            dummy.scale.set(3, 2, 3);
            dummy.updateMatrix();
            acMatrices.push(dummy.matrix.clone());
          }
          if (rand() > 0.6) {
            dummy.position.set(t2.position.x, podiumH + h + 3, t2.position.z);
            dummy.scale.set(1, 6, 1);
            dummy.updateMatrix();
            antennaMatrices.push(dummy.matrix.clone());
          }
        } else {
          const tower = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
          tower.position.set(bx, podiumH + h / 2, bz);
          tower.castShadow = true;
          tower.receiveShadow = true;
          cityGroup.add(tower);
          dummy.position.set(bx, podiumH + h + 0.3, bz);
          dummy.rotation.set(0, 0, 0);
          dummy.scale.set(w + 0.8, 0.6, d + 0.8);
          dummy.updateMatrix();
          roofCapMatrices.push(dummy.matrix.clone());
          if (rand() > 0.35) {
            dummy.position.set(bx + (rand() - 0.5) * w * 0.4, podiumH + h + 1.2, bz + (rand() - 0.5) * d * 0.4);
            dummy.scale.set(2.5, 1.8, 2.5);
            dummy.updateMatrix();
            acMatrices.push(dummy.matrix.clone());
          }
          if (rand() > 0.7) {
            dummy.position.set(bx + (rand() - 0.5) * w * 0.4, podiumH + h + 2, bz + (rand() - 0.5) * d * 0.4);
            dummy.scale.set(1.6, 3, 1.6);
            dummy.updateMatrix();
            tankMatrices.push(dummy.matrix.clone());
          }
        }

        // entrance canopy
        if (rand() > 0.4) {
          const canopy = new THREE.Mesh(
            new THREE.BoxGeometry(7, 0.5, 3),
            new THREE.MeshStandardMaterial({ color: '#1f2733', roughness: 0.6 })
          );
          canopy.position.set(bx, 3.4, bz + d / 2 + 1.2);
          cityGroup.add(canopy);
        }

        addCollider(bx, bz, Math.max(w, w + 6) + 1, Math.max(d, d + 6) + 1);
      }
    }
  }

  // instanced roof props
  function addInstanced(geo: THREE.BufferGeometry, mat: THREE.Material, matrices: THREE.Matrix4[], shadow = true) {
    if (matrices.length === 0) return;
    const inst = new THREE.InstancedMesh(geo, mat, matrices.length);
    matrices.forEach((m, i) => inst.setMatrixAt(i, m));
    inst.castShadow = shadow;
    inst.receiveShadow = true;
    cityGroup.add(inst);
  }
  addInstanced(new THREE.BoxGeometry(1, 1, 1), roofCapMat, roofCapMatrices, false);
  addInstanced(new THREE.BoxGeometry(1, 1, 1), roofBoxMat, acMatrices);
  addInstanced(new THREE.CylinderGeometry(0.5, 0.5, 1, 8), new THREE.MeshStandardMaterial({ color: '#8a6f4d', roughness: 0.8 }), tankMatrices);
  addInstanced(new THREE.CylinderGeometry(0.08, 0.12, 1, 6), new THREE.MeshStandardMaterial({ color: '#c33', roughness: 0.6 }), antennaMatrices, false);

  // street lights along city roads (instanced)
  {
    const poleGeo = new THREE.CylinderGeometry(0.14, 0.2, 9, 6);
    const poleMat = new THREE.MeshStandardMaterial({ color: '#232b38', roughness: 0.6, metalness: 0.4 });
    const armGeo = new THREE.BoxGeometry(0.18, 0.18, 3);
    const headGeo = new THREE.BoxGeometry(0.6, 0.22, 1.1);
    const headMat = new THREE.MeshStandardMaterial({ color: '#fdf6d8', emissive: '#ffeeaa', emissiveIntensity: 0.25 });
    const poles: THREE.Matrix4[] = [];
    const arms: THREE.Matrix4[] = [];
    const heads: THREE.Matrix4[] = [];
    for (const rx of CITY_ROADS_X) {
      for (let z = WORLD.CITY.z1; z <= WORLD.CITY.z2; z += 50) {
        if (Math.abs(z + 150) < 14) continue;
        for (const side of [-1, 1]) {
          dummy.position.set(rx + side * 9, 4.5, z);
          dummy.rotation.set(0, 0, 0);
          dummy.scale.set(1, 1, 1);
          dummy.updateMatrix();
          poles.push(dummy.matrix.clone());
          dummy.position.set(rx + side * 7.6, 8.8, z);
          dummy.rotation.set(0, 0, 0);
          dummy.updateMatrix();
          arms.push(dummy.matrix.clone());
          dummy.position.set(rx + side * 6.4, 8.7, z);
          dummy.updateMatrix();
          heads.push(dummy.matrix.clone());
        }
        if (poles.length > (Q === 0 ? 160 : 320)) break;
      }
      if (poles.length > (Q === 0 ? 160 : 320)) break;
    }
    // coastal highway lights
    for (let x = -1000; x <= 1000; x += 80) {
      dummy.position.set(x, 4.5, 394);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      poles.push(dummy.matrix.clone());
      dummy.position.set(x, 8.8, 392);
      dummy.updateMatrix();
      arms.push(dummy.matrix.clone());
      dummy.position.set(x, 8.7, 390.5);
      dummy.updateMatrix();
      heads.push(dummy.matrix.clone());
      if (poles.length > (Q === 0 ? 220 : 420)) break;
    }
    addInstanced(poleGeo, poleMat, poles);
    addInstanced(armGeo, poleMat, arms, false);
    addInstanced(headGeo, headMat, heads, false);
  }

  // billboards
  {
    const bbDefs: [number, number, number, string, string, string][] = [
      [-350, -350, 0.3, 'RALLY X', '#d21f2b', '#7a0f16'],
      [250, 100, -0.2, 'TURBO GP', '#1f5fd2', '#0f2f7a'],
      [0, 300, 0, 'NITRO CUP', '#7a1fd2', '#3a0f7a'],
      [-200, 360, 0.1, 'SPEED WAY', '#0f9a6c', '#075a40'],
      [500, 350, -0.4, 'BEACH RACE', '#d27a1f', '#7a3f0f'],
    ];
    for (const [x, z, ry, text, c1, c2] of bbDefs) {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.6, 12, 8), new THREE.MeshStandardMaterial({ color: '#3a4354' }));
      pole.position.set(x, 6, z);
      pole.castShadow = true;
      cityGroup.add(pole);
      const board = new THREE.Mesh(new THREE.BoxGeometry(16, 8, 0.6), new THREE.MeshStandardMaterial({ map: billboardTexture(text, c1, c2), roughness: 0.6 }));
      board.position.set(x, 15, z);
      board.rotation.y = ry;
      board.castShadow = true;
      cityGroup.add(board);
      addCollider(x, z, 3, 3);
    }
  }

  // traffic signs (stop / direction) instanced-ish
  {
    const signPoleMat = new THREE.MeshStandardMaterial({ color: '#8a93a3', metalness: 0.6, roughness: 0.4 });
    for (let i = 0; i < 16; i++) {
      const rx = CITY_ROADS_X[Math.floor(rand() * CITY_ROADS_X.length)];
      const rz = CITY_ROADS_Z[Math.floor(rand() * CITY_ROADS_Z.length)];
      if (Math.abs(rz + 150) < 14) continue;
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 3.4, 6), signPoleMat);
      pole.position.set(rx + 8.5, 1.7, rz + 8.5);
      cityGroup.add(pole);
      const isStop = rand() > 0.5;
      const signGeo = isStop ? new THREE.CylinderGeometry(0.7, 0.7, 0.1, 8) : new THREE.BoxGeometry(1.2, 0.9, 0.08);
      const sign = new THREE.Mesh(signGeo, new THREE.MeshStandardMaterial({ color: isStop ? '#c81e2b' : '#1f5fd2', roughness: 0.5 }));
      sign.position.set(rx + 8.5, 3.6, rz + 8.5);
      if (isStop) sign.rotation.x = Math.PI / 2;
      else sign.rotation.y = rand() * Math.PI;
      cityGroup.add(sign);
    }
  }

  await tick();

  // ---------------- VILLAGE ----------------
  prog(0.5, 'روستا و خانه‌ها');
  const villageGroup = new THREE.Group();
  scene.add(villageGroup);
  const wallBases = ['#e8dcc4', '#dfc9a8', '#e5e0d2', '#d8c2b2'];
  const roofCols = ['#a83c2a', '#7a4a2a', '#4a5a6a', '#8a2a3a'];
  const wallMats = wallBases.map((c, i) => new THREE.MeshStandardMaterial({ map: houseWallTexture(c, 100 + i), roughness: 0.9 }));
  const roofMats = roofCols.map((c, i) => new THREE.MeshStandardMaterial({ map: roofTexture(c, 200 + i), roughness: 0.85 }));

  // window/door materials
  const winMat = new THREE.MeshStandardMaterial({ color: '#274a68', metalness: 0.6, roughness: 0.3, emissive: '#1a3a55', emissiveIntensity: 0.3 });
  const doorMat = new THREE.MeshStandardMaterial({ color: '#5a3a22', roughness: 0.8 });
  const chimneyMat = new THREE.MeshStandardMaterial({ color: '#8a6a5a', roughness: 0.9 });

  function gableRoofGeo(w: number, d: number, h: number): THREE.BufferGeometry {
    // triangular prism
    const hw = w / 2;
    const hd = d / 2;
    const vertices = new Float32Array([
      // front triangle
      -hw, 0, hd, hw, 0, hd, 0, h, hd,
      // back triangle
      hw, 0, -hd, -hw, 0, -hd, 0, h, -hd,
      // left slope
      -hw, 0, hd, 0, h, hd, 0, h, -hd, -hw, 0, hd, 0, h, -hd, -hw, 0, -hd,
      // right slope
      hw, 0, hd, hw, 0, -hd, 0, h, -hd, hw, 0, hd, 0, h, -hd, 0, h, hd,
      // bottom
      -hw, 0, -hd, hw, 0, -hd, hw, 0, hd, -hw, 0, -hd, hw, 0, hd, -hw, 0, hd,
    ]);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
    geo.computeVertexNormals();
    // simple uvs
    const uv = new Float32Array((vertices.length / 3) * 2);
    for (let i = 0; i < uv.length; i += 2) {
      uv[i] = (i / 2) % 2;
      uv[i + 1] = Math.floor(i / 4) % 2;
    }
    geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    return geo;
  }

  const housePositions: [number, number, number][] = [];
  // village layout: houses along main street x=620 and side lanes
  for (let i = 0; i < 13; i++) {
    const z = -170 + i * 30 + (rand() - 0.5) * 10;
    housePositions.push([585 + (rand() - 0.5) * 14, z, (rand() - 0.5) * 0.3]);
    if (i % 2 === 0) housePositions.push([668 + (rand() - 0.5) * 14, z + 12, (rand() - 0.5) * 0.3 + Math.PI]);
  }
  housePositions.push([540, 120, 0.4], [720, -60, -0.3], [560, -40, 0.2], [730, 140, 2.8]);

  housePositions.forEach(([hx, hz, ry], idx) => {
    const w = 9 + rand() * 5;
    const d = 7 + rand() * 4;
    const h = 3.4 + rand() * 1.4;
    const wall = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wallMats[idx % wallMats.length]);
    wall.position.set(hx, h / 2, hz);
    wall.rotation.y = ry;
    wall.castShadow = true;
    wall.receiveShadow = true;
    villageGroup.add(wall);

    const rh = 2.2 + rand() * 1.4;
    const roof = new THREE.Mesh(gableRoofGeo(w + 1.4, d + 1.4, rh), roofMats[idx % roofMats.length]);
    roof.position.set(hx, h, hz);
    roof.rotation.y = ry;
    roof.castShadow = true;
    villageGroup.add(roof);

    // chimney
    const ch = new THREE.Mesh(new THREE.BoxGeometry(0.9, 2.4, 0.9), chimneyMat);
    ch.position.set(hx + Math.cos(ry) * w * 0.28, h + rh * 0.6, hz - Math.sin(ry) * w * 0.28);
    ch.castShadow = true;
    villageGroup.add(ch);

    // windows + door (front face) — single holder per house
    const front = d / 2 + 0.06;
    const frameMat = new THREE.MeshStandardMaterial({ color: '#f5f0e4', roughness: 0.8 });
    const holder = new THREE.Group();
    holder.position.set(hx, 0, hz);
    holder.rotation.y = ry;
    for (const wx of [-w * 0.28, w * 0.28]) {
      const frame = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.4, 0.08), frameMat);
      frame.position.set(wx, h * 0.55, front);
      holder.add(frame);
      const win = new THREE.Mesh(new THREE.BoxGeometry(1.3, 1.1, 0.1), winMat);
      win.position.set(wx, h * 0.55, front + 0.02);
      holder.add(win);
    }
    const door = new THREE.Mesh(new THREE.BoxGeometry(1.3, 2.3, 0.12), doorMat);
    door.position.set(0, 1.15, front);
    holder.add(door);
    const porch = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.18, 1.6), roofMats[idx % roofMats.length]);
    porch.position.set(0, 2.7, front + 0.7);
    holder.add(porch);
    villageGroup.add(holder);

    addCollider(hx, hz, w + 2, d + 2);
    addTreeCollider(hx, hz, Math.max(w, d) * 0.6);
  });

  // farm fields
  {
    const fieldDefs: [number, number, number, number, string, string][] = [
      [722, 120, 56, 46, '#7a9a3a', '#5a7a2a'],
      [700, 180, 70, 40, '#c8a83a', '#a88a2a'],
      [520, -120, 56, 44, '#6a8a4a', '#4a6a34'],
      [730, -120, 60, 50, '#8a6a3a', '#6a4a2a'],
    ];
    for (const [fx, fz, fw, fd, c1, c2] of fieldDefs) {
      const f = new THREE.Mesh(new THREE.PlaneGeometry(fw, fd), new THREE.MeshStandardMaterial({ map: fieldTexture(c1, c2, Math.floor(fx)), roughness: 1 }));
      f.rotation.x = -Math.PI / 2;
      f.position.set(fx, 0.045, fz);
      f.receiveShadow = true;
      villageGroup.add(f);
      // fence posts
      const fenceMat = new THREE.MeshStandardMaterial({ color: '#6a4a2a', roughness: 0.9 });
      for (let px = -fw / 2; px <= fw / 2; px += 8) {
        for (const side of [-1, 1]) {
          const post = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.2, 0.3), fenceMat);
          post.position.set(fx + px, 0.6, fz + (side * fd) / 2);
          villageGroup.add(post);
        }
      }
    }
    // hay bales
    const hayMat = new THREE.MeshStandardMaterial({ color: '#d8b84a', roughness: 1 });
    for (let i = 0; i < 10; i++) {
      const hay = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 1.6, 10), hayMat);
      hay.rotation.z = Math.PI / 2;
      hay.rotation.y = rand() * Math.PI;
      hay.position.set(540 + rand() * 200, 1.1, -60 + rand() * 220);
      hay.castShadow = true;
      villageGroup.add(hay);
      addCollider(hay.position.x, hay.position.z, 2.5, 2.5);
    }
    // barn
    const barn = new THREE.Mesh(new THREE.BoxGeometry(14, 6, 10), new THREE.MeshStandardMaterial({ color: '#a83226', roughness: 0.85 }));
    barn.position.set(760, 3, 60);
    barn.rotation.y = 0.25;
    barn.castShadow = true;
    villageGroup.add(barn);
    const barnRoof = new THREE.Mesh(gableRoofGeo(15.5, 11.5, 4), new THREE.MeshStandardMaterial({ color: '#d8d3c5', roughness: 0.8 }));
    barnRoof.position.set(760, 6, 60);
    barnRoof.rotation.y = 0.25;
    barnRoof.castShadow = true;
    villageGroup.add(barnRoof);
    addCollider(760, 60, 16, 12);
  }

  await tick();

  // ---------------- FOREST (instanced) ----------------
  prog(0.62, 'جنگل عظیم');
  const barkMat = new THREE.MeshStandardMaterial({ map: barkTexture(), roughness: 1 });
  const pineLeafMat = new THREE.MeshStandardMaterial({ map: leafTexture(), color: '#9fbf8a', roughness: 1 });
  const broadLeafMat = new THREE.MeshStandardMaterial({ map: leafTexture(), color: '#b8d89a', roughness: 1 });

  interface TreeSpot { x: number; z: number; s: number; pine: boolean; rot: number }
  const spots: TreeSpot[] = [];
  const treeTarget = Q === 0 ? 1300 : Q === 1 ? 2300 : 3300;

  function randomInRect(x1: number, z1: number, x2: number, z2: number): [number, number] {
    return [x1 + rand() * (x2 - x1), z1 + rand() * (z2 - z1)];
  }
  let guard = 0;
  while (spots.length < treeTarget && guard < treeTarget * 12) {
    guard++;
    let x = 0;
    let z = 0;
    const pick = rand();
    if (pick < 0.45) [x, z] = randomInRect(WORLD.FOREST_E.x1, WORLD.FOREST_E.z1, WORLD.FOREST_E.x2, WORLD.FOREST_E.z2);
    else if (pick < 0.8) [x, z] = randomInRect(WORLD.FOREST_W.x1, WORLD.FOREST_W.z1, WORLD.FOREST_W.x2, WORLD.FOREST_W.z2);
    else if (pick < 0.9) [x, z] = randomInRect(-900, 300, 900, 420); // roadside band near coast
    else [x, z] = randomInRect(-900, -700, 900, 350); // scattered

    // density noise: clumps
    const n = fbm(x * 0.008, z * 0.008, 3);
    const inForest = (x > WORLD.FOREST_E.x1 && x < WORLD.FOREST_E.x2 && z > WORLD.FOREST_E.z1 && z < WORLD.FOREST_E.z2) ||
      (x > WORLD.FOREST_W.x1 && x < WORLD.FOREST_W.x2 && z > WORLD.FOREST_W.z1 && z < WORLD.FOREST_W.z2);
    if (inForest) {
      if (n < 0.32 && rand() > 0.25) continue;
    } else {
      if (n < 0.45 && rand() > 0.15) continue;
    }
    const surf = getSurfaceAt(x, z);
    if (surf === 'asphalt' || surf === 'water' || surf === 'sand' || surf === 'sidewalk') continue;
    if (Math.hypot(x - 740, z + 620) < 40) continue; // forest pond
    if (x > WORLD.CITY.x1 - 30 && x < WORLD.CITY.x2 + 30 && z > WORLD.CITY.z1 - 30 && z < WORLD.CITY.z2 + 30) continue;
    if (x > WORLD.VILLAGE.x1 - 15 && x < WORLD.VILLAGE.x2 + 15 && z > WORLD.VILLAGE.z1 - 15 && z < WORLD.VILLAGE.z2 + 15) {
      if (rand() > 0.12) continue;
    }
    // keep off farm fields
    if (x > 665 && x < 735 && z > 95 && z < 205) continue;
    // keep off houses (min dist)
    let nearHouse = false;
    for (const [hx, hz] of housePositions) {
      if (Math.hypot(x - hx, z - hz) < 12) { nearHouse = true; break; }
    }
    if (nearHouse) continue;
    if (Math.abs(z - 380) < 20) continue;

    const pine = inForest ? rand() > 0.42 : rand() > 0.6;
    const s = (inForest ? 0.8 : 0.7) + rand() * 0.9;
    spots.push({ x, z, s, pine, rot: rand() * Math.PI * 2 });
    addTreeCollider(x, z, 1.1 * s);
  }

  const forestGroup = new THREE.Group();
  scene.add(forestGroup);
  const pines = spots.filter((t) => t.pine);
  const broads = spots.filter((t) => !t.pine);

  function buildInstanced(
    geo: THREE.BufferGeometry,
    mat: THREE.Material,
    list: TreeSpot[],
    yOff: (s: number) => number,
    scaleFn?: (t: TreeSpot) => [number, number, number]
  ) {
    if (list.length === 0) return;
    const inst = new THREE.InstancedMesh(geo, mat, list.length);
    const d = new THREE.Object3D();
    list.forEach((t, i) => {
      d.position.set(t.x, yOff(t.s), t.z);
      d.rotation.set(0, t.rot, 0);
      const sc = scaleFn ? scaleFn(t) : [t.s, t.s, t.s];
      d.scale.set(sc[0], sc[1], sc[2]);
      d.updateMatrix();
      inst.setMatrixAt(i, d.matrix);
    });
    inst.castShadow = Q === 2;
    inst.receiveShadow = true;
    forestGroup.add(inst);
  }

  // pine trunks + 3 cone layers
  buildInstanced(new THREE.CylinderGeometry(0.28, 0.42, 2.6, 6), barkMat, pines, (s) => 1.3 * s);
  buildInstanced(new THREE.ConeGeometry(2.3, 3.4, 8), pineLeafMat, pines, (s) => 3.4 * s);
  buildInstanced(new THREE.ConeGeometry(1.7, 2.8, 8), pineLeafMat, pines, (s) => 5.2 * s);
  buildInstanced(new THREE.ConeGeometry(1.1, 2.2, 7), pineLeafMat, pines, (s) => 6.8 * s);

  // broadleaf trunks + blobs
  buildInstanced(new THREE.CylinderGeometry(0.3, 0.5, 3.0, 6), barkMat, broads, (s) => 1.5 * s);
  buildInstanced(new THREE.IcosahedronGeometry(2.3, 1), broadLeafMat, broads, (s) => 4.0 * s);
  // second blob offset — encode offset via rotated position trick: use separate loop
  if (broads.length) {
    const blob2 = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1.6, 1), broadLeafMat, broads.length);
    const d = new THREE.Object3D();
    broads.forEach((t, i) => {
      d.position.set(t.x + Math.cos(t.rot) * 1.4 * t.s, 5.2 * t.s, t.z + Math.sin(t.rot) * 1.4 * t.s);
      d.rotation.set(0, t.rot, 0);
      d.scale.set(t.s, t.s * 0.9, t.s);
      d.updateMatrix();
      blob2.setMatrixAt(i, d.matrix);
    });
    blob2.castShadow = Q === 2;
    forestGroup.add(blob2);
  }

  // bushes
  {
    const n = Q === 0 ? 350 : Q === 1 ? 600 : 900;
    const geo = new THREE.IcosahedronGeometry(1, 1);
    const mat = new THREE.MeshStandardMaterial({ map: leafTexture(), color: '#8fb87a', roughness: 1 });
    const inst = new THREE.InstancedMesh(geo, mat, n);
    const d = new THREE.Object3D();
    let placed = 0;
    let g2 = 0;
    while (placed < n && g2 < n * 10) {
      g2++;
      const east = rand() > 0.45;
      const [x, z] = east
        ? randomInRect(WORLD.FOREST_E.x1, WORLD.FOREST_E.z1, WORLD.FOREST_E.x2, WORLD.FOREST_E.z2)
        : randomInRect(WORLD.FOREST_W.x1, WORLD.FOREST_W.z1, WORLD.FOREST_W.x2, WORLD.FOREST_W.z2);
      const surf = getSurfaceAt(x, z);
      if (surf !== 'grass') continue;
      const s = 0.5 + rand() * 1.1;
      d.position.set(x, 0.5 * s, z);
      d.rotation.set(0, rand() * Math.PI, 0);
      d.scale.set(s * (1 + rand() * 0.6), s * 0.75, s * (1 + rand() * 0.6));
      d.updateMatrix();
      inst.setMatrixAt(placed, d.matrix);
      placed++;
    }
    inst.count = placed;
    inst.receiveShadow = true;
    forestGroup.add(inst);
  }

  // rocks
  {
    const n = Q === 0 ? 180 : Q === 1 ? 300 : 450;
    const geo = new THREE.DodecahedronGeometry(1, 0);
    const mat = new THREE.MeshStandardMaterial({ map: rockTexture(), roughness: 0.95 });
    const inst = new THREE.InstancedMesh(geo, mat, n);
    const d = new THREE.Object3D();
    let placed = 0;
    let g2 = 0;
    while (placed < n && g2 < n * 12) {
      g2++;
      let x = 0;
      let z = 0;
      const r = rand();
      if (r < 0.4) [x, z] = randomInRect(WORLD.FOREST_E.x1, WORLD.FOREST_E.z1, WORLD.FOREST_E.x2, WORLD.FOREST_E.z2);
      else if (r < 0.7) [x, z] = randomInRect(WORLD.FOREST_W.x1, WORLD.FOREST_W.z1, WORLD.FOREST_W.x2, WORLD.FOREST_W.z2);
      else if (r < 0.85) [x, z] = randomInRect(-1000, -1000, 1000, -850);
      else [x, z] = randomInRect(-1000, 440, 1000, 600);
      const surf = getSurfaceAt(x, z);
      if (surf === 'asphalt' || surf === 'water' || surf === 'sidewalk') continue;
      const s = 0.4 + rand() * (r > 0.85 ? 1.2 : 1.8);
      d.position.set(x, 0.3 * s, z);
      d.rotation.set(rand() * Math.PI, rand() * Math.PI, rand() * Math.PI);
      d.scale.set(s * (0.7 + rand() * 0.7), s * (0.55 + rand() * 0.5), s * (0.7 + rand() * 0.7));
      d.updateMatrix();
      inst.setMatrixAt(placed, d.matrix);
      if (s > 0.9) addTreeCollider(x, z, s * 0.9);
      placed++;
    }
    inst.count = placed;
    inst.castShadow = true;
    inst.receiveShadow = true;
    forestGroup.add(inst);
  }

  // grass tufts (crossed planes with alpha texture)
  {
    const bladeCanvas = document.createElement('canvas');
    bladeCanvas.width = 64;
    bladeCanvas.height = 64;
    const bctx = bladeCanvas.getContext('2d')!;
    bctx.clearRect(0, 0, 64, 64);
    for (let i = 0; i < 26; i++) {
      const x = 6 + rand() * 52;
      const h = 24 + rand() * 34;
      const lean = (rand() - 0.5) * 14;
      bctx.strokeStyle = ['#4e7d33', '#6a9c48', '#55853a', '#77a952'][Math.floor(rand() * 4)];
      bctx.lineWidth = 2.5;
      bctx.beginPath();
      bctx.moveTo(x, 64);
      bctx.quadraticCurveTo(x + lean * 0.4, 64 - h * 0.6, x + lean, 64 - h);
      bctx.stroke();
    }
    const bladeTex = new THREE.CanvasTexture(bladeCanvas);
    bladeTex.colorSpace = THREE.SRGBColorSpace;
    const n = Q === 0 ? 700 : Q === 1 ? 1400 : 2200;
    const planeGeo = new THREE.PlaneGeometry(2.2, 1.6);
    const mat = new THREE.MeshStandardMaterial({ map: bladeTex, alphaTest: 0.35, side: THREE.DoubleSide, roughness: 1 });
    // two crossed instanced meshes
    const inst1 = new THREE.InstancedMesh(planeGeo, mat, n);
    const inst2 = new THREE.InstancedMesh(planeGeo, mat, n);
    const d = new THREE.Object3D();
    let placed = 0;
    let g2 = 0;
    while (placed < n && g2 < n * 8) {
      g2++;
      let x = 0;
      let z = 0;
      const r = rand();
      if (r < 0.4) [x, z] = randomInRect(WORLD.FOREST_E.x1, WORLD.FOREST_E.z1, WORLD.FOREST_E.x2, WORLD.FOREST_E.z2);
      else if (r < 0.7) [x, z] = randomInRect(WORLD.FOREST_W.x1, WORLD.FOREST_W.z1, WORLD.FOREST_W.x2, WORLD.FOREST_W.z2);
      else [x, z] = randomInRect(-900, -600, 900, 420);
      if (getSurfaceAt(x, z) !== 'grass') continue;
      if (x > WORLD.CITY.x1 - 20 && x < WORLD.CITY.x2 + 20 && z > WORLD.CITY.z1 - 20 && z < WORLD.CITY.z2 + 20) continue;
      const s = 0.7 + rand() * 1.1;
      const rot = rand() * Math.PI;
      d.position.set(x, 0.7 * s, z);
      d.rotation.set(0, rot, 0);
      d.scale.set(s, s, s);
      d.updateMatrix();
      inst1.setMatrixAt(placed, d.matrix);
      d.rotation.set(0, rot + Math.PI / 2, 0);
      d.updateMatrix();
      inst2.setMatrixAt(placed, d.matrix);
      placed++;
    }
    inst1.count = placed;
    inst2.count = placed;
    forestGroup.add(inst1);
    forestGroup.add(inst2);
  }

  // forest pond
  {
    const pondMat = new THREE.MeshStandardMaterial({ color: '#2a7a9a', roughness: 0.15, metalness: 0.6, transparent: true, opacity: 0.9 });
    const pond = new THREE.Mesh(new THREE.CircleGeometry(26, 24), pondMat);
    pond.rotation.x = -Math.PI / 2;
    pond.position.set(740, 0.08, -620);
    forestGroup.add(pond);
    const rim = new THREE.Mesh(new THREE.RingGeometry(26, 32, 24), new THREE.MeshStandardMaterial({ color: '#c8b088', roughness: 1 }));
    rim.rotation.x = -Math.PI / 2;
    rim.position.set(740, 0.06, -620);
    forestGroup.add(rim);
  }

  await tick();

  // ---------------- BEACH PROPS ----------------
  prog(0.74, 'ساحل و دریا');
  const beachGroup = new THREE.Group();
  scene.add(beachGroup);

  // palms (instanced trunks + instanced leaf stars)
  {
    const palmSpots: { x: number; z: number; s: number; rot: number; lean: number }[] = [];
    const nPalm = Q === 0 ? 70 : Q === 1 ? 110 : 150;
    let g2 = 0;
    while (palmSpots.length < nPalm && g2 < nPalm * 20) {
      g2++;
      const x = -1050 + rand() * 2100;
      const z = 445 + rand() * 130;
      if (Math.abs(z - 380) < 22) continue;
      if (getSurfaceAt(x, z) !== 'sand') continue;
      // avoid pier area
      if (Math.abs(x - 120) < 30) continue;
      palmSpots.push({ x, z, s: 0.8 + rand() * 0.7, rot: rand() * Math.PI * 2, lean: (rand() - 0.5) * 0.35 });
      addTreeCollider(x, z, 0.9);
    }
    const trunkGeo = new THREE.CylinderGeometry(0.22, 0.38, 7, 7);
    const trunkMat = new THREE.MeshStandardMaterial({ map: barkTexture(), color: '#c8a888', roughness: 1 });
    const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, palmSpots.length);
    const d = new THREE.Object3D();
    palmSpots.forEach((p, i) => {
      d.position.set(p.x, 3.2 * p.s, p.z);
      d.rotation.set(p.lean, p.rot, p.lean * 0.7);
      d.scale.set(p.s, p.s, p.s);
      d.updateMatrix();
      trunkInst.setMatrixAt(i, d.matrix);
    });
    trunkInst.castShadow = true;
    beachGroup.add(trunkInst);

    // fronds: 7 planes per palm
    const frondShape = new THREE.Shape();
    frondShape.moveTo(0, 0);
    frondShape.quadraticCurveTo(1.6, 0.5, 3.4, -0.4);
    frondShape.quadraticCurveTo(1.6, -0.1, 0, -0.5);
    frondShape.closePath();
    const frondGeo = new THREE.ShapeGeometry(frondShape, 6);
    const frondMat = new THREE.MeshStandardMaterial({ color: '#3f8a3a', roughness: 0.9, side: THREE.DoubleSide });
    const frondsPer = 7;
    const frondInst = new THREE.InstancedMesh(frondGeo, frondMat, palmSpots.length * frondsPer);
    let fi = 0;
    palmSpots.forEach((p) => {
      const topY = 6.6 * p.s;
      for (let f = 0; f < frondsPer; f++) {
        const a = (f / frondsPer) * Math.PI * 2 + p.rot;
        d.position.set(p.x + Math.cos(a) * 0.3, topY, p.z + Math.sin(a) * 0.3);
        d.rotation.set(-0.5 - rand() * 0.3, -a + Math.PI / 2, 0, 'YXZ');
        d.scale.set(p.s, p.s, p.s);
        d.updateMatrix();
        frondInst.setMatrixAt(fi++, d.matrix);
      }
    });
    frondInst.castShadow = Q === 2;
    beachGroup.add(frondInst);

    // coconuts
    const cocoGeo = new THREE.SphereGeometry(0.28, 6, 6);
    const cocoMat = new THREE.MeshStandardMaterial({ color: '#6a4a2a', roughness: 1 });
    const cocoInst = new THREE.InstancedMesh(cocoGeo, cocoMat, palmSpots.length * 2);
    let ci = 0;
    palmSpots.forEach((p) => {
      for (let k = 0; k < 2; k++) {
        d.position.set(p.x + (rand() - 0.5), 6.2 * p.s, p.z + (rand() - 0.5));
        d.rotation.set(0, 0, 0);
        d.scale.set(p.s, p.s, p.s);
        d.updateMatrix();
        cocoInst.setMatrixAt(ci++, d.matrix);
      }
    });
    beachGroup.add(cocoInst);
  }

  // umbrellas + towels
  {
    const umColors = ['#e63946', '#f4a261', '#2a9d8f', '#e9c46a', '#7a5fd2'];
    for (let i = 0; i < (Q === 0 ? 8 : 16); i++) {
      const x = -800 + rand() * 1600;
      const z = 500 + rand() * 70;
      if (Math.abs(x - 120) < 26) continue;
      const col = umColors[i % umColors.length];
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 3, 6), new THREE.MeshStandardMaterial({ color: '#8a7a5a' }));
      pole.position.set(x, 1.5, z);
      beachGroup.add(pole);
      const top = new THREE.Mesh(new THREE.ConeGeometry(2.2, 1.1, 10), new THREE.MeshStandardMaterial({ color: col, roughness: 0.7, side: THREE.DoubleSide }));
      top.position.set(x, 3.2, z);
      top.castShadow = true;
      beachGroup.add(top);
      const towel = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.08, 2.2), new THREE.MeshStandardMaterial({ color: umColors[(i + 2) % umColors.length] }));
      towel.position.set(x + 2.4, 0.12, z + 0.6);
      towel.rotation.y = rand() * Math.PI;
      beachGroup.add(towel);
      addCollider(x, z, 1, 1);
    }
  }

  // pier
  {
    const woodMat = new THREE.MeshStandardMaterial({ color: '#7a5a3a', roughness: 0.9 });
    const pierX = 120;
    addCollider(pierX, 604, 10, 12);
    for (let z = 600; z < 730; z += 6) {
      const plank = new THREE.Mesh(new THREE.BoxGeometry(8, 0.4, 5.2), woodMat);
      plank.position.set(pierX, 2.2, z);
      plank.castShadow = true;
      plank.receiveShadow = true;
      beachGroup.add(plank);
      if (Math.round(z) % 24 === 0) {
        for (const side of [-3.4, 3.4]) {
          const pile = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 5, 8), new THREE.MeshStandardMaterial({ color: '#4a3826' }));
          pile.position.set(pierX + side, 0, z);
          beachGroup.add(pile);
        }
      }
    }
    // rails
    for (const side of [-3.8, 3.8]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.25, 1, 130), woodMat);
      rail.position.set(pierX + side, 3.2, 665);
      beachGroup.add(rail);
    }
    // hut at end
    const hut = new THREE.Mesh(new THREE.BoxGeometry(6, 3.4, 5), new THREE.MeshStandardMaterial({ color: '#e8dcc4', roughness: 0.9 }));
    hut.position.set(pierX, 4.2, 726);
    hut.castShadow = true;
    beachGroup.add(hut);
    const hutRoof = new THREE.Mesh(new THREE.ConeGeometry(4.6, 2.2, 4), new THREE.MeshStandardMaterial({ color: '#a83c2a', roughness: 0.85 }));
    hutRoof.position.set(pierX, 7, 726);
    hutRoof.rotation.y = Math.PI / 4;
    beachGroup.add(hutRoof);
    // boats
    for (const [bx, bz, ry] of [[150, 690, 0.4], [95, 705, -0.3]] as [number, number, number][]) {
      const hull = new THREE.Mesh(new THREE.BoxGeometry(2.6, 1.1, 6), new THREE.MeshStandardMaterial({ color: '#f5f5f5', roughness: 0.6 }));
      hull.position.set(bx, 1.2, bz);
      hull.rotation.y = ry;
      beachGroup.add(hull);
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.3, 6.1), new THREE.MeshStandardMaterial({ color: '#1f5fd2' }));
      stripe.position.set(bx, 1.1, bz);
      stripe.rotation.y = ry;
      beachGroup.add(stripe);
    }
  }

  // lifeguard tower
  {
    const lgMat = new THREE.MeshStandardMaterial({ color: '#e63946', roughness: 0.7 });
    const woodMat = new THREE.MeshStandardMaterial({ color: '#8a6a4a', roughness: 0.9 });
    const lx = -260;
    const lz = 545;
    for (const [ox, oz] of [[-1.4, -1.4], [1.4, -1.4], [-1.4, 1.4], [1.4, 1.4]]) {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.3, 4.4, 0.3), woodMat);
      leg.position.set(lx + ox, 2.2, lz + oz);
      leg.rotation.z = -ox * 0.06;
      beachGroup.add(leg);
    }
    const cab = new THREE.Mesh(new THREE.BoxGeometry(3.6, 2.4, 3.2), lgMat);
    cab.position.set(lx, 5.4, lz);
    cab.castShadow = true;
    beachGroup.add(cab);
    const win = new THREE.Mesh(new THREE.BoxGeometry(3.7, 0.9, 3.3), new THREE.MeshStandardMaterial({ color: '#123', metalness: 0.7, roughness: 0.3 }));
    win.position.set(lx, 5.8, lz);
    beachGroup.add(win);
    const roof = new THREE.Mesh(new THREE.ConeGeometry(3, 1.4, 4), new THREE.MeshStandardMaterial({ color: '#f5f5f5' }));
    roof.position.set(lx, 7.3, lz);
    roof.rotation.y = Math.PI / 4;
    beachGroup.add(roof);
    addCollider(lx, lz, 4, 4);
  }

  // coastal guard rail (sea side)
  {
    const railMat = new THREE.MeshStandardMaterial({ color: '#b8c0cc', metalness: 0.7, roughness: 0.35 });
    const postMat = new THREE.MeshStandardMaterial({ color: '#6a7280', roughness: 0.7 });
    const rail = new THREE.Mesh(new THREE.BoxGeometry(2100, 0.5, 0.25), railMat);
    rail.position.set(0, 1.0, 404);
    beachGroup.add(rail);
    const rail2 = rail.clone();
    rail2.position.y = 0.6;
    beachGroup.add(rail2);
    const postGeo = new THREE.BoxGeometry(0.2, 1.1, 0.2);
    const nPosts = 150;
    const posts = new THREE.InstancedMesh(postGeo, postMat, nPosts);
    const d = new THREE.Object3D();
    for (let i = 0; i < nPosts; i++) {
      d.position.set(-1050 + (i / (nPosts - 1)) * 2100, 0.55, 404);
      d.rotation.set(0, 0, 0);
      d.scale.set(1, 1, 1);
      d.updateMatrix();
      posts.setMatrixAt(i, d.matrix);
    }
    beachGroup.add(posts);
    // rock barriers where the coastal road meets the mountains
    const endRockGeo = new THREE.DodecahedronGeometry(3, 0);
    const endRockMat = new THREE.MeshStandardMaterial({ map: rockTexture(), roughness: 1 });
    for (const ex of [-985, 985]) {
      for (let i = 0; i < 4; i++) {
        const rk = new THREE.Mesh(endRockGeo, endRockMat);
        rk.position.set(ex + (rand() - 0.5) * 14, 1.2, 372 + i * 5.5 + (rand() - 0.5) * 2);
        rk.rotation.set(rand() * 3, rand() * 3, rand() * 3);
        rk.scale.setScalar(0.8 + rand() * 0.8);
        rk.castShadow = true;
        beachGroup.add(rk);
      }
      addCollider(ex, 380, 22, 26);
    }
  }

  await tick();

  // ---------------- MOUNTAINS ----------------
  prog(0.86, 'کوهستان');
  {
    const rockMatTex = rockTexture();
    const mMat = new THREE.MeshStandardMaterial({ map: rockMatTex, vertexColors: true, roughness: 0.95, flatShading: true });

    function ridgeMesh(width: number, depth: number, segW: number, segD: number, maxH: number, seed: number): THREE.BufferGeometry {
      const geo = new THREE.PlaneGeometry(width, depth, segW, segD);
      geo.rotateX(-Math.PI / 2);
      const pos = geo.attributes.position;
      const colors = new Float32Array(pos.count * 3);
      const cRock = new THREE.Color('#7a756e');
      const cDark = new THREE.Color('#4a4642');
      const cSnow = new THREE.Color('#eef2f6');
      const cGreen = new THREE.Color('#5a7a44');
      const cSand = new THREE.Color('#8a7a5a');
      for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i);
        const z = pos.getZ(i);
        // depth factor: 0 inner edge (map side), 1 outer edge (local -Z faces outward)
        const t = THREE.MathUtils.clamp(0.5 - z / depth, 0, 1);
        const ridge = fbm(x * 0.004 + seed, z * 0.006 + seed * 2, 4);
        const peak = Math.pow(Math.max(0, t), 1.4);
        let h = peak * maxH * (0.45 + ridge * 1.1);
        h += Math.sin(x * 0.01 + seed) * 8 * peak;
        // jagged
        h += (fbm(x * 0.02, z * 0.02 + seed, 3) - 0.5) * 30 * peak;
        pos.setY(i, Math.max(0, h));
        // color by height
        const hn = h / maxH;
        const col = new THREE.Color();
        if (hn < 0.12) col.copy(cGreen).lerp(cSand, rand() * 0.4);
        else if (hn < 0.45) col.copy(cRock).lerp(cDark, fbm(x * 0.01, z * 0.01, 2) * 0.7);
        else if (hn < 0.7) col.copy(cDark).lerp(cRock, 0.4);
        else col.copy(cRock).lerp(cSnow, Math.min(1, (hn - 0.7) / 0.18));
        colors[i * 3] = col.r;
        colors[i * 3 + 1] = col.g;
        colors[i * 3 + 2] = col.b;
      }
      geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
      geo.computeVertexNormals();
      return geo;
    }

    const segs = Q === 0 ? 60 : Q === 1 ? 90 : 120;
    // north
    const north = new THREE.Mesh(ridgeMesh(2800, 520, segs, 18, 340, 3), mMat);
    north.position.set(0, 0, -1040 - 200);
    north.receiveShadow = true;
    scene.add(north);
    // west (local -Z rotated to face -X outward)
    const west = new THREE.Mesh(ridgeMesh(2800, 520, segs, 18, 300, 17), mMat);
    west.rotation.y = Math.PI / 2;
    west.position.set(-1040 - 200, 0, 0);
    west.receiveShadow = true;
    scene.add(west);
    // east (local -Z rotated to face +X outward)
    const east = new THREE.Mesh(ridgeMesh(2800, 520, segs, 18, 320, 31), mMat);
    east.rotation.y = -Math.PI / 2;
    east.position.set(1040 + 200, 0, 0);
    east.receiveShadow = true;
    scene.add(east);
    // corners extra peaks
    const peakGeo = new THREE.ConeGeometry(260, 380, 7, 4);
    {
      const p = peakGeo.attributes.position;
      const cols = new Float32Array(p.count * 3);
      const cRock = new THREE.Color('#76716a');
      const cSnow = new THREE.Color('#f2f5f8');
      for (let i = 0; i < p.count; i++) {
        const y = p.getY(i);
        p.setX(i, p.getX(i) * (1 + (fbm(i * 0.3, 7, 2) - 0.5) * 0.5));
        p.setZ(i, p.getZ(i) * (1 + (fbm(i * 0.3, 13, 2) - 0.5) * 0.5));
        const t = (y + 190) / 380;
        const c = cRock.clone().lerp(cSnow, Math.max(0, (t - 0.62) / 0.25));
        cols[i * 3] = c.r;
        cols[i * 3 + 1] = c.g;
        cols[i * 3 + 2] = c.b;
      }
      peakGeo.setAttribute('color', new THREE.BufferAttribute(cols, 3));
      peakGeo.computeVertexNormals();
    }
    const peakMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.95, flatShading: true, map: rockMatTex });
    const cornerPeaks: [number, number, number][] = [
      [-1250, -1250, 1.2], [1250, -1250, 1.35], [-1300, 200, 1.0], [1300, 150, 1.1], [0, -1350, 1.3],
    ];
    for (const [x, z, s] of cornerPeaks) {
      const m = new THREE.Mesh(peakGeo, peakMat);
      m.position.set(x, 150 * s, z);
      m.scale.set(s, s, s);
      m.rotation.y = rand() * Math.PI;
      scene.add(m);
    }
    // sea islands on horizon
    for (const [x, z, s] of [[-700, 1250, 1.4], [500, 1360, 1.8], [1300, 1240, 1.0]] as [number, number, number][]) {
      const isl = new THREE.Mesh(new THREE.ConeGeometry(160 * s, 120 * s, 8), new THREE.MeshStandardMaterial({ color: '#4a6a52', roughness: 1, flatShading: true }));
      isl.position.set(x, 20, z);
      scene.add(isl);
    }
    // interior hills (green)
    const hillMat = new THREE.MeshStandardMaterial({ color: '#5d8142', roughness: 1, flatShading: true });
    for (const [x, z, r, h] of [[-350, -850, 120, 55], [950, -150, 100, 45], [-950, 250, 130, 60]] as [number, number, number, number][]) {
      const hill = new THREE.Mesh(new THREE.ConeGeometry(r, h, 9, 3), hillMat);
      const hp = hill.geometry.attributes.position;
      for (let i = 0; i < hp.count; i++) {
        hp.setX(i, hp.getX(i) * (1 + (fbm(i * 0.5 + x, z, 2) - 0.5) * 0.3));
      }
      hill.geometry.computeVertexNormals();
      hill.position.set(x, h / 2 - 2, z);
      hill.receiveShadow = true;
      scene.add(hill);
      addTreeCollider(x, z, r * 0.75);
    }
  }

  await tick();

  // ---------------- TRAFFIC PATHS ----------------
  prog(0.94, 'مسیرهای ترافیک');
  const trafficPaths: TrafficPath[] = [
    // city outer loop
    {
      loop: true,
      speed: 13,
      points: [
        new THREE.Vector3(-300, 0, -400),
        new THREE.Vector3(300, 0, -400),
        new THREE.Vector3(300, 0, 100),
        new THREE.Vector3(-300, 0, 100),
      ],
    },
    {
      loop: true,
      speed: 11,
      points: [
        new THREE.Vector3(-100, 0, -300),
        new THREE.Vector3(-100, 0, 0),
        new THREE.Vector3(200, 0, 0),
        new THREE.Vector3(200, 0, -300),
      ],
    },
    // ring highway
    {
      loop: true,
      speed: 22,
      points: [
        new THREE.Vector3(-460, 0, -560),
        new THREE.Vector3(460, 0, -560),
        new THREE.Vector3(460, 0, 280),
        new THREE.Vector3(-460, 0, 280),
      ],
    },
    // coastal highway ping-pong
    {
      loop: false,
      speed: 24,
      points: [new THREE.Vector3(-945, 0, 374), new THREE.Vector3(945, 0, 374)],
    },
    {
      loop: false,
      speed: 24,
      points: [new THREE.Vector3(945, 0, 386), new THREE.Vector3(-945, 0, 386)],
    },
    // village
    {
      loop: true,
      speed: 9,
      points: [
        new THREE.Vector3(470, 0, 0),
        new THREE.Vector3(640, 0, 20),
        new THREE.Vector3(640, 0, -180),
        new THREE.Vector3(560, 0, -60),
      ],
    },
    // bridge overpass
    {
      loop: false,
      speed: 20,
      elevated: true,
      points: [new THREE.Vector3(-320, 0, -150), new THREE.Vector3(320, 0, -150)],
    },
    {
      loop: false,
      speed: 20,
      elevated: true,
      points: [new THREE.Vector3(320, 0, -144), new THREE.Vector3(-320, 0, -144)],
    },
  ];
  // lift bridge path points to deck height
  for (const p of trafficPaths) {
    for (const v of p.points) v.y = getGroundHeightAt(v.x, v.z) + 0.15;
  }

  prog(1, 'آماده');

  const update = (dt: number, elapsed: number, playerPos: THREE.Vector3) => {
    seaMat.uniforms.uTime.value = elapsed;
    for (const c of clouds) {
      c.position.x += c.userData.speed * dt;
      if (c.position.x > 2000) c.position.x = -2000;
    }
    // shadow follows player
    sun.position.set(playerPos.x + sunDir.x * 300, sunDir.y * 300, playerPos.z + sunDir.z * 300);
    sun.target.position.set(playerPos.x, 0, playerPos.z);
    sun.target.updateMatrixWorld();
    sky.position.set(playerPos.x, 0, playerPos.z);
    sunSprite.position.set(playerPos.x + sunDir.x * 2600, sunDir.y * 2600, playerPos.z + sunDir.z * 2600);
  };

  return {
    colliders,
    treeGrid,
    trafficPaths,
    seaMat,
    clouds,
    getSurfaceAt,
    getGroundHeightAt,
    getRegionAt,
    update,
  };
}
