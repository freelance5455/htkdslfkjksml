import type { Car } from "../data/game";

export const LANES = 4;
export const MAX_SPEED = 200;
export const LEVEL_STEP = 750;
export const START_SHIELD = 3;

export type Phase = "idle" | "countdown" | "playing" | "paused" | "over";

export type Input = {
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  nitro: boolean;
  pointerX: number | null;
};

export type Layout = {
  w: number;
  h: number;
  roadW: number;
  roadX: number;
  laneW: number;
  carW: number;
  carH: number;
  playerY: number;
};

export type Traffic = {
  id: number;
  x: number;
  y: number;
  lane: number;
  speed: number;
  size: number;
  body: string;
  bodyLight: string;
  passed: boolean;
  hit: boolean;
};

export type Pickup = {
  id: number;
  x: number;
  y: number;
  lane: number;
  phase: number;
};

export type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
};

export type FloatText = {
  x: number;
  y: number;
  life: number;
  max: number;
  text: string;
  color: string;
};

export type World = {
  layout: Layout;
  phase: Phase;
  playerX: number;
  lean: number;
  speed: number;
  distance: number;
  bonus: number;
  shield: number;
  invincible: number;
  nitro: number;
  nitroActive: boolean;
  level: number;
  topSpeed: number;
  roadOffset: number;
  cars: Traffic[];
  pickups: Pickup[];
  particles: Particle[];
  texts: FloatText[];
  spinTimer: number;
  spawnTimer: number;
  pickupTimer: number;
  elapsed: number;
  shake: number;
  flash: number;
  nearMisses: number;
  sparks: number;
  crashed: boolean;
  overTimer: number;
  nextId: number;
};

export type TickEvents = {
  collected: number;
  nearMiss: number;
  hit: number;
  levelUp: number;
  crashed: boolean;
};

export type HudSnapshot = {
  score: number;
  distance: number;
  speed: number;
  topSpeed: number;
  shield: number;
  nitro: number;
  nitroActive: boolean;
  level: number;
  nearMisses: number;
  sparks: number;
  nextMilestone: number;
  crashed: boolean;
};

const TRAFFIC_PALETTE = [
  ["#3c4548", "#5a6568"],
  ["#4a4440", "#6b625b"],
  ["#333a42", "#4d5761"],
  ["#4d3a38", "#71534e"],
  ["#3e4740", "#5c675c"],
  ["#4b4636", "#6c6650"],
];

const randomBetween = (min: number, max: number) => min + Math.random() * (max - min);

export function computeLayout(w: number, h: number): Layout {
  const roadW = w < 520 ? Math.min(w * 0.9, 440) : Math.min(w * 0.72, 660);
  const roadX = (w - roadW) / 2;
  const laneW = roadW / LANES;
  const carW = Math.max(36, Math.min(laneW * 0.68, 82));
  const carH = carW * 1.92;
  return {
    w,
    h,
    roadW,
    roadX,
    laneW,
    carW,
    carH,
    playerY: h - carH * 1.2 - 22,
  };
}

export function createWorld(): World {
  return {
    layout: computeLayout(800, 500),
    phase: "idle",
    playerX: 400,
    lean: 0,
    speed: 118,
    distance: 0,
    bonus: 0,
    shield: START_SHIELD,
    invincible: 0,
    nitro: 55,
    nitroActive: false,
    level: 1,
    topSpeed: 118,
    roadOffset: 0,
    cars: [],
    pickups: [],
    particles: [],
    texts: [],
    spinTimer: 0,
    spawnTimer: 1.1,
    pickupTimer: 2,
    elapsed: 0,
    shake: 0,
    flash: 0,
    nearMisses: 0,
    sparks: 0,
    crashed: false,
    overTimer: 0,
    nextId: 1,
  };
}

export function resizeWorld(world: World, w: number, h: number) {
  const next = computeLayout(w, h);
  const previous = world.layout;
  world.layout = next;
  if (world.cars.length || world.pickups.length || previous.w !== w) {
    world.cars = [];
    world.pickups = [];
  }
  if (world.phase === "idle") {
    world.playerX = next.roadX + next.laneW * 1.5;
    return;
  }
  world.playerX = Math.min(
    next.roadX + next.roadW - next.carW * 0.65,
    Math.max(next.roadX + next.carW * 0.65, world.playerX),
  );
}

export function resetWorld(world: World, car: Car) {
  const layout = world.layout;
  world.phase = "playing";
  world.playerX = layout.roadX + layout.laneW * 1.5;
  world.lean = 0;
  world.speed = 118;
  world.distance = 0;
  world.bonus = 0;
  world.shield = START_SHIELD;
  world.invincible = 0;
  world.nitro = Math.round(48 + car.nitro * 0.14);
  world.nitroActive = false;
  world.level = 1;
  world.topSpeed = 118;
  world.roadOffset = 0;
  world.cars = [];
  world.pickups = [];
  world.particles = [];
  world.texts = [];
  world.spinTimer = 0;
  world.spawnTimer = 1;
  world.pickupTimer = 1.6;
  world.elapsed = 0;
  world.shake = 0;
  world.flash = 0;
  world.nearMisses = 0;
  world.sparks = 0;
  world.crashed = false;
  world.overTimer = 0;
  world.nextId = 1;
}

export function snapshot(world: World): HudSnapshot {
  return {
    score: Math.floor(world.distance * 2 + world.bonus),
    distance: Math.floor(world.distance),
    speed: Math.round(world.speed),
    topSpeed: Math.round(world.topSpeed),
    shield: world.shield,
    nitro: Math.round(world.nitro),
    nitroActive: world.nitroActive,
    level: world.level,
    nearMisses: world.nearMisses,
    sparks: world.sparks,
    nextMilestone: world.level * LEVEL_STEP,
    crashed: world.crashed,
  };
}

function burst(world: World, x: number, y: number, color: string, count = 16, power = 240) {
  for (let i = 0; i < count; i += 1) {
    const angle = Math.random() * Math.PI * 2;
    const velocity = randomBetween(power * 0.25, power);
    world.particles.push({
      x,
      y,
      vx: Math.cos(angle) * velocity,
      vy: Math.sin(angle) * velocity,
      life: randomBetween(0.35, 0.9),
      max: 0.9,
      size: randomBetween(1.5, 4),
      color,
    });
  }
}

function pushText(world: World, x: number, y: number, text: string, color: string) {
  world.texts.push({ x, y, text, color, life: 1.15, max: 1.15 });
}

function spawnTraffic(world: World) {
  const { layout } = world;
  const recent = world.cars.filter((car) => car.y < layout.carH * 4);
  const blocked = new Set<number>();
  recent.forEach((car) => {
    blocked.add(car.lane);
    if (car.lane > 0) blocked.add(car.lane - 1);
    if (car.lane < LANES - 1) blocked.add(car.lane + 1);
  });

  const open: number[] = [];
  for (let lane = 0; lane < LANES; lane += 1) {
    if (!blocked.has(lane)) open.push(lane);
  }
  if (!open.length) return;

  const lane = open[Math.floor(Math.random() * open.length)];
  const palette = TRAFFIC_PALETTE[Math.floor(Math.random() * TRAFFIC_PALETTE.length)];
  const size = randomBetween(0.92, 1.14);
  world.cars.push({
    id: world.nextId++,
    x: layout.roadX + layout.laneW * (lane + 0.5),
    y: -layout.carH * 1.8,
    lane,
    speed: randomBetween(70, 136),
    size,
    body: palette[0],
    bodyLight: palette[1],
    passed: false,
    hit: false,
  });
}

function spawnPickup(world: World) {
  const { layout } = world;
  const lane = Math.floor(Math.random() * LANES);
  const close = world.cars.some((car) => car.lane === lane && car.y > -layout.carH * 2 && car.y < layout.h * 0.55);
  if (close) return;
  world.pickups.push({
    id: world.nextId++,
    lane,
    x: layout.roadX + layout.laneW * (lane + 0.5),
    y: -36,
    phase: Math.random() * Math.PI * 2,
  });
}

export function tickWorld(world: World, input: Input, dt: number, car: Car): TickEvents {
  const events: TickEvents = { collected: 0, nearMiss: 0, hit: 0, levelUp: 0, crashed: false };
  const { layout } = world;

  world.elapsed += dt;
  world.shake = Math.max(0, world.shake - dt * 26);
  world.flash = Math.max(0, world.flash - dt * 1.9);
  world.invincible = Math.max(0, world.invincible - dt);
  world.spinTimer += dt;

  // Particles + floating labels keep moving through every state.
  for (let i = world.particles.length - 1; i >= 0; i -= 1) {
    const p = world.particles[i];
    p.life -= dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vx *= 0.97;
    p.vy *= 0.97;
    if (p.life <= 0) world.particles.splice(i, 1);
  }
  for (let i = world.texts.length - 1; i >= 0; i -= 1) {
    const t = world.texts[i];
    t.life -= dt;
    t.y -= dt * 44;
    if (t.life <= 0) world.texts.splice(i, 1);
  }

  if (world.crashed) {
    world.overTimer -= dt;
    world.speed = Math.max(0, world.speed - dt * 120);
    world.roadOffset += world.speed * dt * 1.4;
    events.crashed = world.overTimer <= 0;
    return events;
  }

  // ---- Steering -------------------------------------------------------
  const desiredPointer = input.pointerX;
  const steerDir = (input.right ? 1 : 0) - (input.left ? 1 : 0);
  const lateral = 400 + car.handling * 3.1;
  const previousX = world.playerX;

  if (desiredPointer !== null) {
    world.playerX += (desiredPointer - world.playerX) * Math.min(1, dt * 13);
  } else if (steerDir !== 0) {
    world.playerX += steerDir * lateral * dt;
  }

  const minX = layout.roadX + layout.carW * 0.62;
  const maxX = layout.roadX + layout.roadW - layout.carW * 0.62;
  world.playerX = Math.min(maxX, Math.max(minX, world.playerX));
  const relMovement = (world.playerX - previousX) / Math.max(dt, 0.001);
  world.lean += (Math.max(-1, Math.min(1, relMovement / (lateral * 0.9))) - world.lean) * Math.min(1, dt * 8);

  // ---- Nitro ------------------------------------------------------------
  const wantsNitro = input.nitro && world.nitro > 1;
  world.nitroActive = wantsNitro;
  if (wantsNitro) {
    world.nitro = Math.max(0, world.nitro - dt * (22 + car.nitro * 0.1));
  } else {
    world.nitro = Math.min(100, world.nitro + dt * 0.8);
  }

  // ---- Speed ------------------------------------------------------------
  const cruise = Math.min(MAX_SPEED, 118 + world.level * 5);
  const target = world.nitroActive ? MAX_SPEED : input.up ? MAX_SPEED : input.down ? 86 : cruise;
  const rate = target < world.speed ? 2.4 : 0.9 + car.accel / 160;
  world.speed += (target - world.speed) * Math.min(1, dt * rate);
  world.speed = Math.max(60, Math.min(MAX_SPEED, world.speed));
  world.topSpeed = Math.max(world.topSpeed, world.speed);

  const nitroMul = world.nitroActive ? 1.14 : 1;
  world.distance += world.speed * 0.278 * dt * nitroMul;
  world.roadOffset += world.speed * dt * 2.5;

  const nextLevel = 1 + Math.floor(world.distance / LEVEL_STEP);
  if (nextLevel > world.level) {
    world.level = nextLevel;
    world.bonus += 250;
    events.levelUp = nextLevel;
    if (world.level % 3 === 0) world.shield = Math.min(START_SHIELD, world.shield + 1);
    pushText(world, layout.w, layout.h * 0.4, `SECTOR ${String(world.level).padStart(2, "0")}`, "#c9fa3c");
  }

  // ---- Traffic -----------------------------------------------------------
  world.spawnTimer -= dt;
  if (world.spawnTimer <= 0) {
    spawnTraffic(world);
    const pace = Math.max(0.42, 1.06 - world.level * 0.05);
    world.spawnTimer = pace * randomBetween(0.78, 1.3);
  }

  const scrollFactor = 3.05;
  for (let i = world.cars.length - 1; i >= 0; i -= 1) {
    const traffic = world.cars[i];
    traffic.y += (world.speed - traffic.speed) * scrollFactor * dt;

    if (traffic.y > layout.h + layout.carH * 2 || traffic.y < -layout.carH * 7) {
      world.cars.splice(i, 1);
      continue;
    }

    const tw = layout.carW * traffic.size;
    const th = tw * 1.92;
    const dx = Math.abs(traffic.x - world.playerX);
    const dy = Math.abs(traffic.y - layout.playerY);

    if (!traffic.hit && world.invincible <= 0 && dx < (layout.carW + tw) * 0.47 && dy < (layout.carH + th) * 0.44) {
      traffic.hit = true;
      world.cars.splice(i, 1);
      world.shield -= 1;
      world.invincible = 1.7;
      world.speed *= 0.6;
      world.shake = 22;
      world.flash = 1;
      world.bonus = Math.max(0, world.bonus - 60);
      burst(world, traffic.x, traffic.y, "#ff8a4d", 22, 300);
      burst(world, world.playerX, layout.playerY - layout.carH / 2, "#ffd27a", 12, 220);
      events.hit += 1;
      if (world.shield <= 0) {
        world.shield = 0;
        world.crashed = true;
        world.overTimer = 1.1;
        world.shake = 34;
        burst(world, world.playerX, layout.playerY, "#ff7a45", 40, 420);
      }
      continue;
    }

    if (!traffic.passed && !traffic.hit && traffic.y > layout.playerY + layout.carH * 0.45) {
      traffic.passed = true;
      const gap = dx - (layout.carW + tw) * 0.47;
      if (gap > 0 && gap < layout.laneW * 0.62) {
        world.nearMisses += 1;
        world.bonus += 40;
        world.nitro = Math.min(100, world.nitro + 7);
        events.nearMiss += 1;
        pushText(world, world.playerX, layout.playerY - 20, "NEAR MISS +40", "#deff70");
      }
    }
  }

  // ---- Charge pickups ----------------------------------------------------
  world.pickupTimer -= dt;
  if (world.pickupTimer <= 0) {
    spawnPickup(world);
    world.pickupTimer = randomBetween(1.2, 2.4);
  }

  for (let i = world.pickups.length - 1; i >= 0; i -= 1) {
    const pickup = world.pickups[i];
    pickup.phase += dt * 3;
    pickup.y += world.speed * scrollFactor * dt * 0.92;

    if (pickup.y > layout.h + 60) {
      world.pickups.splice(i, 1);
      continue;
    }

    const dx = Math.abs(pickup.x - world.playerX);
    const dy = Math.abs(pickup.y - layout.playerY);
    if (dx < Math.max(layout.carW * 0.8, layout.laneW * 0.36) && dy < layout.carH * 0.6) {
      world.pickups.splice(i, 1);
      world.nitro = Math.min(100, world.nitro + 18 + car.nitro * 0.06);
      world.sparks += 1;
      world.bonus += 120;
      events.collected += 1;
      burst(world, pickup.x, pickup.y, "#c9fa3c", 12, 200);
      pushText(world, pickup.x, pickup.y - 10, "+120 CHARGE", "#c9fa3c");
    }
  }

  if (world.crashed) events.crashed = world.overTimer <= 0;
  return events;
}
