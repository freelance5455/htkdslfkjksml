import * as THREE from "three";
import type { Team } from "./types";
import {
  createBarrel,
  createBuilding,
  createCactus,
  createCloud,
  createCrate,
  createCrateStack,
  createFence,
  createFlag,
  createGroundTexture,
  createMountain,
  createPalm,
  createPlaza,
  part,
  roundedGeo,
  toon,
} from "./models";

export interface Obstacle {
  x: number;
  z: number;
  hw: number;
  hd: number;
  height: number;
  destructible?: Destructible;
}

export interface Destructible {
  id: number;
  kind: "crate" | "barrel";
  mesh: THREE.Group;
  obstacle: Obstacle;
  health: number;
  maxHealth: number;
  alive: boolean;
  x: number;
  z: number;
  radius: number;
  explosive: boolean;
}

export interface VehicleSpawn {
  type: "buggy" | "tank";
  team: Team;
  x: number;
  z: number;
  yaw: number;
}

export interface PickupSpawn {
  kind: "health" | "ammo";
  x: number;
  z: number;
}

export interface ArenaData {
  group: THREE.Group;
  obstacles: Obstacle[];
  destructibles: Destructible[];
  spawns: { sun: THREE.Vector3[]; tide: THREE.Vector3[]; dm: THREE.Vector3[] };
  vehicleSpawns: VehicleSpawn[];
  pickupSpawns: PickupSpawn[];
  bounds: number;
}

let nextDestructibleId = 1;

function addDestructible(
  group: THREE.Group,
  obstacles: Obstacle[],
  destructibles: Destructible[],
  mesh: THREE.Group,
  x: number,
  z: number,
  hw: number,
  hd: number,
  height: number,
  kind: "crate" | "barrel",
  health: number,
  explosive = false
) {
  mesh.position.set(x, 0, z);
  mesh.rotation.y = Math.random() * Math.PI;
  group.add(mesh);
  const obstacle: Obstacle = { x, z, hw, hd, height };
  const d: Destructible = {
    id: nextDestructibleId++,
    kind,
    mesh,
    obstacle,
    health,
    maxHealth: health,
    alive: true,
    x,
    z,
    radius: Math.max(hw, hd),
    explosive,
  };
  obstacle.destructible = d;
  obstacles.push(obstacle);
  destructibles.push(d);
}

export function buildArena(): ArenaData {
  const group = new THREE.Group();
  const obstacles: Obstacle[] = [];
  const destructibles: Destructible[] = [];
  const bounds = 44;

  // ground
  const groundTex = createGroundTexture();
  groundTex.wrapS = THREE.RepeatWrapping;
  groundTex.wrapT = THREE.RepeatWrapping;
  groundTex.repeat.set(28, 28);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(150, 150), toon(0xffffff, { map: groundTex }));
  ground.rotation.x = -Math.PI / 2;
  group.add(ground);

  const plaza = createPlaza(13);
  group.add(plaza);

  // perimeter walls
  const wallMat = toon(0xd9b483);
  const trimMat = toon(0xb9814f);
  const wallDefs: [number, number, number, number][] = [
    [0, -bounds, 92, 2.4],
    [0, bounds, 92, 2.4],
    [-bounds, 0, 2.4, 92],
    [bounds, 0, 2.4, 92],
  ];
  for (const [x, z, w, d] of wallDefs) {
    const wall = part(group, roundedGeo(w, 2.6, d, 0.12), wallMat, x, 1.3, z);
    void wall;
    part(group, roundedGeo(w + 0.2, 0.28, d + 0.2, 0.06), trimMat, x, 2.65, z);
  }

  // team flags at opposite ends
  const sunFlag = createFlag(0xffb43c);
  sunFlag.position.set(-6, 0, bounds - 3);
  group.add(sunFlag);
  const tideFlag = createFlag(0x39d6c8);
  tideFlag.position.set(6, 0, -bounds + 3);
  group.add(tideFlag);

  // buildings
  const buildings: { x: number; z: number; w: number; h: number; d: number; wall: string; accent: string; trim: string; variant: number }[] = [
    { x: -29, z: -27, w: 12, h: 7.5, d: 10, wall: "#f2b544", accent: "#e2663f", trim: "#fff1d6", variant: 0 },
    { x: 28, z: -29, w: 13, h: 9, d: 9, wall: "#5fc9bd", accent: "#2b7a8c", trim: "#fff1d6", variant: 1 },
    { x: -31, z: 25, w: 10, h: 6.5, d: 11, wall: "#f08a6a", accent: "#b84a3a", trim: "#ffe6c7", variant: 1 },
    { x: 30, z: 27, w: 12, h: 8, d: 10, wall: "#a99be8", accent: "#6c5bb5", trim: "#fff1d6", variant: 0 },
    { x: 0, z: -34, w: 16, h: 5.5, d: 7, wall: "#f2d06b", accent: "#c98a2e", trim: "#fff8ec", variant: 1 },
  ];
  for (const b of buildings) {
    const mesh = createBuilding(b.w, b.h, b.d, b.wall, b.accent, b.trim, b.variant);
    mesh.position.set(b.x, 0, b.z);
    group.add(mesh);
    obstacles.push({ x: b.x, z: b.z, hw: b.w / 2, hd: b.d / 2, height: b.h });
  }

  // central monument
  const monument = new THREE.Group();
  part(monument, roundedGeo(4.4, 0.5, 4.4, 0.12), toon(0xc9a878), 0, 0.25, 0);
  part(monument, roundedGeo(3.2, 0.5, 3.2, 0.1), toon(0xe8cfa4), 0, 0.7, 0);
  part(monument, roundedGeo(1.2, 3.6, 1.2, 0.16), toon(0xf2b544), 0, 2.6, 0);
  part(monument, roundedGeo(3.0, 0.9, 0.9, 0.14), toon(0xf2b544), 0, 4.0, 0);
  part(monument, roundedGeo(1.5, 0.5, 1.5, 0.08), toon(0xe2663f), 0, 4.6, 0);
  const monumentFlag = createFlag(0x39d6c8);
  monumentFlag.position.set(1.4, 4.2, 0);
  monumentFlag.scale.setScalar(0.7);
  monument.add(monumentFlag);
  group.add(monument);
  obstacles.push({ x: 0, z: 0, hw: 2.2, hd: 2.2, height: 4.8 });

  // cover: crates
  const crateSpots: [number, number, number][] = [
    [-9, -8, 1.3],
    [9, -8, 1.3],
    [-9, 8, 1.3],
    [9, 8, 1.3],
    [-17, 0, 1.1],
    [17, 0, 1.1],
    [-6, -18, 1.2],
    [6, -18, 1.2],
    [-6, 18, 1.2],
    [6, 18, 1.2],
    [-20, -14, 1.0],
    [20, 14, 1.0],
    [-20, 14, 1.0],
    [20, -14, 1.0],
    [0, -24, 1.2],
    [0, 24, 1.2],
  ];
  for (const [x, z, s] of crateSpots) {
    addDestructible(group, obstacles, destructibles, createCrate(s), x, z, s / 2, s / 2, s, "crate", 55);
  }

  // crate clusters
  const stacks: [number, number][] = [
    [-14, -22],
    [14, 22],
    [-24, 6],
    [24, -6],
  ];
  for (const [x, z] of stacks) {
    const stack = createCrateStack();
    stack.position.set(x, 0, z);
    group.add(stack);
    obstacles.push({ x, z, hw: 1.4, hd: 1.4, height: 2.2 });
  }

  // barrels
  const barrelSpots: [number, number][] = [
    [-12, -4],
    [12, 4],
    [-4, 12],
    [4, -12],
    [-22, -8],
    [22, 8],
    [-14, 20],
    [14, -20],
    [0, -15],
    [0, 15],
  ];
  for (const [x, z] of barrelSpots) {
    addDestructible(group, obstacles, destructibles, createBarrel(Math.random() > 0.5 ? "#ef6a4c" : "#f2b544"), x, z, 0.46, 0.46, 1.05, "barrel", 28, true);
  }

  // fences
  const fenceSpots: [number, number, number][] = [
    [-24, -18, 0],
    [24, 18, 0],
    [-24, 18, 0],
    [24, -18, 0],
  ];
  for (const [x, z, rot] of fenceSpots) {
    const fence = createFence(5);
    fence.position.set(x, 0, z);
    fence.rotation.y = rot;
    group.add(fence);
    const horizontal = Math.abs(Math.sin(rot)) < 0.5;
    obstacles.push({ x, z, hw: horizontal ? 2.5 : 0.25, hd: horizontal ? 0.25 : 2.5, height: 1.1 });
  }

  // decorative greenery
  const greenery: [number, number, "palm" | "cactus"][] = [
    [-38, -12, "palm"],
    [38, 12, "palm"],
    [-38, 34, "cactus"],
    [38, -34, "cactus"],
  ];
  for (const [x, z, kind] of greenery) {
    const tree = kind === "palm" ? createPalm() : createCactus();
    tree.position.set(x, 0, z);
    tree.rotation.y = Math.random() * Math.PI;
    group.add(tree);
  }

  // distant scenery
  for (let i = 0; i < 10; i++) {
    const angle = (i / 14) * Math.PI * 2;
    const dist = 78 + Math.random() * 22;
    const mountain = createMountain(10 + Math.random() * 10, 10 + Math.random() * 16, i % 2 === 0 ? 0xc9a878 : 0xb99a78);
    mountain.position.x = Math.cos(angle) * dist;
    mountain.position.z = Math.sin(angle) * dist;
    group.add(mountain);
  }
  for (let i = 0; i < 4; i++) {
    const cloud = createCloud();
    cloud.position.set(-50 + Math.random() * 100, 18 + Math.random() * 12, -50 + Math.random() * 100);
    cloud.scale.setScalar(1.4 + Math.random() * 1.4);
    group.add(cloud);
  }

  // spawn pads
  const padSun = toon(0xffb43c, { emissive: 0xffb43c, emissiveIntensity: 0.15 });
  const padTide = toon(0x39d6c8, { emissive: 0x39d6c8, emissiveIntensity: 0.15 });
  const sunSpawns = [
    new THREE.Vector3(-6, 0, 32),
    new THREE.Vector3(0, 0, 34),
    new THREE.Vector3(6, 0, 32),
    new THREE.Vector3(-12, 0, 28),
    new THREE.Vector3(12, 0, 28),
  ];
  const tideSpawns = [
    new THREE.Vector3(-6, 0, -32),
    new THREE.Vector3(0, 0, -34),
    new THREE.Vector3(6, 0, -32),
    new THREE.Vector3(-12, 0, -28),
    new THREE.Vector3(12, 0, -28),
  ];
  for (const p of sunSpawns) {
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 0.08, 16), padSun);
    pad.position.set(p.x, 0.04, p.z);
    group.add(pad);
  }
  for (const p of tideSpawns) {
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 0.08, 16), padTide);
    pad.position.set(p.x, 0.04, p.z);
    group.add(pad);
  }
  const dmSpawns = [
    ...sunSpawns,
    ...tideSpawns,
    new THREE.Vector3(-20, 0, 0),
    new THREE.Vector3(20, 0, 0),
    new THREE.Vector3(0, 0, -20),
    new THREE.Vector3(0, 0, 20),
  ];

  // vehicle display pads
  const vehicleSpawns: VehicleSpawn[] = [
    { type: "buggy", team: "sun", x: -18, z: 22, yaw: Math.PI * 0.15 },
    { type: "buggy", team: "tide", x: 18, z: -22, yaw: Math.PI * 1.15 },
    { type: "tank", team: "sun", x: 20, z: 22, yaw: Math.PI * 0.85 },
  ];
  for (const v of vehicleSpawns) {
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(2.1, 2.1, 0.06, 18), v.team === "sun" ? padSun : padTide);
    pad.position.set(v.x, 0.03, v.z);
    group.add(pad);
  }

  const pickupSpawns: PickupSpawn[] = [
    { kind: "health", x: -13, z: 0 },
    { kind: "health", x: 13, z: 0 },
    { kind: "health", x: 0, z: -22 },
    { kind: "health", x: 0, z: 22 },
    { kind: "ammo", x: -22, z: 12 },
    { kind: "ammo", x: 22, z: -12 },
    { kind: "ammo", x: -8, z: -26 },
    { kind: "ammo", x: 8, z: 26 },
  ];

  // Double the arena: scale the whole environment and all collision/spawn data.
  const S = 2;
  group.scale.setScalar(S);
  for (const o of obstacles) {
    o.x *= S;
    o.z *= S;
    o.hw *= S;
    o.hd *= S;
    o.height *= S;
  }
  for (const d of destructibles) {
    d.x *= S;
    d.z *= S;
    d.radius *= S;
  }
  const scaledSun = sunSpawns.map((p) => p.clone().multiplyScalar(S));
  const scaledTide = tideSpawns.map((p) => p.clone().multiplyScalar(S));
  const scaledDm = dmSpawns.map((p) => p.clone().multiplyScalar(S));
  const scaledVehicles = vehicleSpawns.map((v) => ({ ...v, x: v.x * S, z: v.z * S }));
  const scaledPickups = pickupSpawns.map((p) => ({ ...p, x: p.x * S, z: p.z * S }));
  return {
    group,
    obstacles,
    destructibles,
    spawns: { sun: scaledSun, tide: scaledTide, dm: scaledDm },
    vehicleSpawns: scaledVehicles,
    pickupSpawns: scaledPickups,
    bounds: bounds * S,
  };
}
