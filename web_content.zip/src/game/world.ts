import {
  MAP_COLS,
  MAP_ROWS,
  TILE_SIZE,
  WORLD_WIDTH,
  WORLD_HEIGHT,
  INITIAL_LAND_PLOTS,
  CAMPFIRE_X,
  CAMPFIRE_Y,
  CAMPFIRE_DEFAULT_RADIUS,
  DEEP_KOCHUBON_MIN_COL,
} from "./constants";
import {
  Tree,
  FarmTile,
  Dog,
  Player,
  GroundDrop,
  LandPlot,
  CampfireData,
  BuildingStructure,
  MonsterDog,
} from "../types";

export type TileType =
  | "grass"
  | "taro_patch"
  | "dirt_path"
  | "water"
  | "farmland"
  | "shop_dock"
  | "bridge"
  | "fence";

export interface GameWorldData {
  tiles: TileType[][];
  trees: Tree[];
  farmTiles: Map<string, FarmTile>;
  dogs: Dog[];
  player: Player;
  groundDrops: GroundDrop[];
  landPlots: LandPlot[];
  campfire: CampfireData;
  structures: BuildingStructure[];
  monster: MonsterDog | null;
}

export function generateWorld(): GameWorldData {
  const tiles: TileType[][] = [];

  for (let r = 0; r < MAP_ROWS; r++) {
    tiles[r] = [];
    for (let c = 0; c < MAP_COLS; c++) {
      tiles[r][c] = "grass";

      // River running through columns 30-32
      if (c >= 30 && c <= 32 && r >= 3 && r <= 32) {
        tiles[r][c] = "water";
      }

      // Wooden Bridges crossing river into Deep Kochubon
      if ((r === 14 || r === 25) && (c === 30 || c === 31 || c === 32)) {
        tiles[r][c] = "bridge";
      }

      // Main Village Dirt Roads
      if (r === 14 && c <= 30) {
        tiles[r][c] = "dirt_path";
      }
      if (c === 16 && r >= 5 && r <= 28) {
        tiles[r][c] = "dirt_path";
      }
      // Campfire clearing road
      if (r === 16 && c >= 16 && c <= 22) {
        tiles[r][c] = "dirt_path";
      }

      // Mustakim permanent shop dock
      if ((c === 28 || c === 29) && r >= 12 && r <= 16) {
        tiles[r][c] = "shop_dock";
      }

      // Village Taro Patches
      const distNW = Math.hypot(c - 7, r - 6);
      const distSW = Math.hypot(c - 7, r - 22);
      if ((distNW < 5.5 || distSW < 5) && tiles[r][c] === "grass") {
        tiles[r][c] = "taro_patch";
      }

      // DEEP KOCHUBON WILDERNESS (Columns 34+): Massive dense, ancient arum forest
      if (c >= DEEP_KOCHUBON_MIN_COL) {
        const taroNoise = Math.sin(c * 0.45) * Math.cos(r * 0.45);
        if (taroNoise > -0.2 && tiles[r][c] === "grass") {
          tiles[r][c] = "taro_patch";
        }
        // Occasional wild wetlands in Deep Kochubon
        if ((c === 47 || c === 48) && (r >= 10 && r <= 14)) {
          tiles[r][c] = "water";
        }
      }
    }
  }

  // Pure survival - no farming!
  const farmTiles = new Map<string, FarmTile>();

  const trees: Tree[] = [];
  let treeId = 1;
  const treePositions = [
    { c: 8, r: 9, type: "taro_giant" },
    { c: 11, r: 10, type: "mango" },
    { c: 13, r: 18, type: "bamboo" },
    { c: 24, r: 10, type: "mango" },
    { c: 27, r: 11, type: "taro_giant" },
    { c: 18, r: 9, type: "sal" },
    { c: 9, r: 16, type: "taro_giant" },
    { c: 5, r: 14, type: "bamboo" },
    { c: 12, r: 21, type: "sal" },
    { c: 22, r: 12, type: "mango" },
    { c: 4, r: 3, type: "taro_giant" },
    { c: 8, r: 2, type: "mango" },
    { c: 12, r: 4, type: "sal" },
    { c: 18, r: 2, type: "bamboo" },
    { c: 22, r: 3, type: "mango" },
    { c: 8, r: 27, type: "sal" },
    { c: 14, r: 28, type: "bamboo" },
    { c: 22, r: 27, type: "mango" },
    { c: 26, r: 28, type: "sal" },
    { c: 36, r: 8, type: "taro_giant" },
    { c: 38, r: 12, type: "mango" },
    { c: 35, r: 18, type: "bamboo" },
    { c: 39, r: 22, type: "sal" },
  ];

  treePositions.forEach((pos) => {
    trees.push({
      id: `tree_${treeId++}`,
      x: pos.c * TILE_SIZE + 8,
      y: pos.r * TILE_SIZE + 4,
      type: pos.type as any,
      hp: 100,
      maxHp: 100,
      state: "mature",
      regrowthTimer: 0,
      maxRegrowthTime: 25,
    });
  });

  // Multiple 10x Enhanced Black Dogs with z-hop
  const dogs: Dog[] = [
    {
      id: "dog_kalu",
      name: "Kalu",
      bengaliName: "কালু (মা কুকুর)",
      x: 11 * TILE_SIZE,
      y: 13 * TILE_SIZE,
      z: 0,
      vz: 0,
      width: 40,
      height: 32,
      speed: 3.3,
      facing: "right",
      state: "follow",
      fearLevel: 0,
      loyalty: 80,
      speechBubble: "তোজো আমার পরম বন্ধু! ❤️",
      bubbleTimer: 3,
      targetX: 11 * TILE_SIZE,
      targetY: 13 * TILE_SIZE,
      wanderTimer: 0,
      isFriend: true,
      color: "#0B1325",
      sizeScale: 1.0,
      tailWagSpeed: 6.0,
      bellyRollTimer: 0,
      digTimer: 0,
    },
    {
      id: "dog_chotu",
      name: "Chotu",
      bengaliName: "ছোটু (কালো ছানা)",
      x: 13 * TILE_SIZE,
      y: 15 * TILE_SIZE,
      z: 0,
      vz: 0,
      width: 28,
      height: 24,
      speed: 3.6,
      facing: "down",
      state: "follow",
      fearLevel: 0,
      loyalty: 90,
      speechBubble: "ঘেউ ঘেউ! তোজো ভাই! 🐾",
      bubbleTimer: 3,
      targetX: 13 * TILE_SIZE,
      targetY: 15 * TILE_SIZE,
      wanderTimer: 0,
      isFriend: true,
      color: "#1E293B",
      sizeScale: 0.72,
      tailWagSpeed: 8.0,
      bellyRollTimer: 0,
      digTimer: 0,
    },
    {
      id: "dog_bagha",
      name: "Bagha",
      bengaliName: "বাঘা (পাহাড়ী কুকুর)",
      x: 8 * TILE_SIZE,
      y: 17 * TILE_SIZE,
      z: 0,
      vz: 0,
      width: 42,
      height: 34,
      speed: 3.1,
      facing: "left",
      state: "wander",
      fearLevel: 0,
      loyalty: 35,
      speechBubble: null,
      bubbleTimer: 0,
      targetX: 8 * TILE_SIZE,
      targetY: 17 * TILE_SIZE,
      wanderTimer: 0,
      isFriend: false,
      color: "#030712",
      sizeScale: 1.1,
      tailWagSpeed: 3.0,
      bellyRollTimer: 0,
      digTimer: 0,
    },
    // 3 MISSING DOGS TRAPPED IN DEEP KOCHUBON WILDERNESS!
    {
      id: "dog_missing_black",
      name: "Black Dog",
      bengaliName: "কালো কুকুর (হারিয়ে যাওয়া ভাই - Black Dog)",
      x: 43 * TILE_SIZE,
      y: 7 * TILE_SIZE,
      z: 0,
      vz: 0,
      width: 38,
      height: 30,
      speed: 3.2,
      facing: "left",
      state: "wander",
      fearLevel: 30,
      loyalty: 40,
      speechBubble: "🆘 আমি গভীর কচুবনে হারিয়ে গেছি! তোজো বাঁচাও!",
      bubbleTimer: 8,
      targetX: 43 * TILE_SIZE,
      targetY: 7 * TILE_SIZE,
      wanderTimer: 2,
      isFriend: false,
      isMissing: true,
      rescued: false,
      furType: "black",
      color: "#070E1A",
      sizeScale: 0.95,
      tailWagSpeed: 3.0,
      bellyRollTimer: 0,
      digTimer: 0,
    },
    {
      id: "dog_missing_white",
      name: "White Dog",
      bengaliName: "সাদা কুকুর (হারিয়ে যাওয়া রূপসী - White Dog)",
      x: 48 * TILE_SIZE,
      y: 18 * TILE_SIZE,
      z: 0,
      vz: 0,
      width: 36,
      height: 28,
      speed: 3.4,
      facing: "down",
      state: "wander",
      fearLevel: 45,
      loyalty: 40,
      speechBubble: "🆘 সাদা কুকুর ভয় পাচ্ছে! দানব কুকুর ডাকছে!",
      bubbleTimer: 8,
      targetX: 48 * TILE_SIZE,
      targetY: 18 * TILE_SIZE,
      wanderTimer: 3,
      isFriend: false,
      isMissing: true,
      rescued: false,
      furType: "white",
      color: "#F8FAFC",
      sizeScale: 0.9,
      tailWagSpeed: 4.0,
      bellyRollTimer: 0,
      digTimer: 0,
    },
    {
      id: "dog_missing_yellow",
      name: "Yellow Dog",
      bengaliName: "হলুদ কুকুর (হারিয়ে যাওয়া সোনা - Yellow Dog)",
      x: 44 * TILE_SIZE,
      y: 29 * TILE_SIZE,
      z: 0,
      vz: 0,
      width: 40,
      height: 32,
      speed: 3.3,
      facing: "right",
      state: "wander",
      fearLevel: 25,
      loyalty: 50,
      speechBubble: "🆘 তোজো ভাই! আমাকে ক্যাম্পফায়ারে নিয়ে চলো!",
      bubbleTimer: 8,
      targetX: 44 * TILE_SIZE,
      targetY: 29 * TILE_SIZE,
      wanderTimer: 2,
      isFriend: false,
      isMissing: true,
      rescued: false,
      furType: "yellow",
      color: "#D97706",
      sizeScale: 1.0,
      tailWagSpeed: 5.0,
      bellyRollTimer: 0,
      digTimer: 0,
    },
  ];

  const player: Player = {
    x: 16 * TILE_SIZE,
    y: 14 * TILE_SIZE,
    z: 0,
    vz: 0,
    isJumping: false,
    isSprinting: false,
    stamina: 100,
    maxStamina: 100,
    walkFrame: 0,
    handAnim: 0,
    width: 32,
    height: 40,
    speed: 3.6,
    facing: "down",
    isMoving: false,
    isActing: false,
    actionTimer: 0,
    actionType: null,
    hp: 100,
    maxHp: 100,
    energy: 100,
    maxEnergy: 100,
    coins: 90,
    equippedSlot: 0,
  };

  // ROBLOX 99 NIGHTS IN THE FOREST: Campfire Base (Lv1 starts compact)
  const campfire: CampfireData = {
    x: CAMPFIRE_X,
    y: CAMPFIRE_Y,
    radius: 175, // Lv1 safe building radius
    level: 1,
    fuel: 100,
    maxRadius: 420,
    logsDeposited: 0,
    logsNeededForNextLevel: 5,
    visibleMapRadius: 280, // Lv1 map vision is short!
  };

  // Initial structures under campfire: Permanent Crafting Table, Torch, and Canine Bed
  const structures: BuildingStructure[] = [
    {
      id: "base_crafting_table",
      type: "crafting_table",
      name: "Campfire Crafting Table",
      bengaliName: "ক্যাম্পফায়ার ক্রাফটিং টেবিল",
      x: CAMPFIRE_X + 54,
      y: CAMPFIRE_Y - 18,
      hp: 200,
      maxHp: 200,
    },
    {
      id: "base_torch_1",
      type: "torch",
      name: "Campfire Light Torch",
      bengaliName: "ক্যাম্পফায়ার মশাল বাতি",
      x: CAMPFIRE_X - 80,
      y: CAMPFIRE_Y - 50,
      hp: 100,
      maxHp: 100,
    },
    {
      id: "base_bed_1",
      type: "dog_bed",
      name: "Cozy Canine Bed",
      bengaliName: "কুকুরদের শোবার আরামদায়ক মাদুর",
      x: CAMPFIRE_X + 60,
      y: CAMPFIRE_Y + 50,
      hp: 100,
      maxHp: 100,
    },
  ];

  // NIGHT MONSTER: KOCHU KHOR KUKUR (কচু খোর কুকুর) in Deep Kochubon
  const monster: MonsterDog = {
    id: "kochu_khor_kukur",
    name: "Kochu Khor Kukur",
    bengaliName: "কচু খোর কুকুর (গভীর কচুবনের দানব)",
    x: 47 * TILE_SIZE,
    y: 14 * TILE_SIZE,
    z: 0,
    vz: 0,
    hp: 250,
    maxHp: 250,
    speed: 2.8,
    facing: "down",
    state: "roam",
    targetX: 47 * TILE_SIZE,
    targetY: 14 * TILE_SIZE,
    growlTimer: 3,
    speechBubble: "🐺 গ্ররর! কচু খাবো আর অন্ধকার ছড়াবো!",
    bubbleTimer: 5,
    attackCooldown: 0,
  };

  const groundDrops: GroundDrop[] = [
    {
      id: "drop_1",
      x: 14 * TILE_SIZE + 10,
      y: 11 * TILE_SIZE + 20,
      item: {
        id: "wood_log",
        name: "Wood Log",
        bengaliName: "কাঠের গুঁড়ি",
        type: "resource",
        description: "Fresh wood collected from the forest.",
        icon: "🪵",
        count: 8,
        value: 4,
      },
      lifespan: 9999,
    },
    {
      id: "drop_2",
      x: 18 * TILE_SIZE + 20,
      y: 12 * TILE_SIZE + 15,
      item: {
        id: "stone_pebble",
        name: "River Stone",
        bengaliName: "নদীর নুড়ি পাথর",
        type: "resource",
        description: "Hard smooth stones for tool crafting.",
        icon: "🪨",
        count: 6,
        value: 3,
      },
      lifespan: 9999,
    },
    {
      id: "drop_3",
      x: 8 * TILE_SIZE + 16,
      y: 10 * TILE_SIZE + 16,
      item: {
        id: "taro_stem",
        name: "Wild Taro Stem",
        bengaliName: "কচু শাক / আঁশ",
        type: "crop",
        description: "Nutritious fiber gathered from Kochubon.",
        icon: "🌿",
        count: 5,
        value: 6,
      },
      lifespan: 9999,
    },
    // Bonus Wood drops near Campfire for Roblox 99 Nights building!
    {
      id: "drop_camp_wood",
      x: CAMPFIRE_X + 40,
      y: CAMPFIRE_Y - 40,
      item: {
        id: "wood_log",
        name: "Camp Timber Logs",
        bengaliName: "ক্যাম্পের শুকনো কাঠ",
        type: "resource",
        description: "Wood logs to refuel campfire and build protective fences.",
        icon: "🪵",
        count: 6,
        value: 5,
      },
      lifespan: 9999,
    },
  ];

  return {
    tiles,
    trees,
    farmTiles,
    dogs,
    player,
    groundDrops,
    landPlots: [...INITIAL_LAND_PLOTS],
    campfire,
    structures,
    monster,
  };
}
