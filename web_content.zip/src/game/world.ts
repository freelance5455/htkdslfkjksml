import * as THREE from "three";
import { mapById, speciesByKey, type HuntingMap, type MapId, type SpeciesKey } from "@/data";

export type WorldMode = "landing" | "hunting";

export interface LoadoutSpec {
  id: string;
  magazine: number;
  reserve: number;
  zoomFov: number;
}

export interface TargetInfo {
  key: SpeciesKey;
  name: string;
  distance: number;
  headshot: boolean;
}

export interface ShotResult {
  hit: boolean;
  species?: SpeciesKey;
  speciesName?: string;
  points?: number;
  distance?: number;
  headshot?: boolean;
}

export interface WorldCallbacks {
  onAmmo: (magazine: number, reserve: number) => void;
  onReload: (active: boolean) => void;
  onShot: (result: ShotResult) => void;
  onEmpty: () => void;
  onTarget: (target: TargetInfo | null) => void;
  onHeading: (degrees: number) => void;
  onAim: (aiming: boolean) => void;
  onSpotted: (species: SpeciesKey[]) => void;
  onFlash?: () => void;
}

export interface WorldApi {
  setMode: (mode: WorldMode) => void;
  setPaused: (paused: boolean) => void;
  setLoadout: (loadout: LoadoutSpec) => void;
  setAim: (aiming: boolean) => void;
  toggleAim: () => boolean;
  fire: () => void;
  reload: () => void;
  setMove: (code: string, active: boolean) => void;
  setMoveAxes: (x: number, y: number) => void;
  setLookSensitivity: (value: number) => void;
  setInfiniteAmmo: (value: boolean) => void;
  setMap: (id: MapId) => void;
  beginWave: (index: number, population: number) => void;
  resetHunt: () => void;
  dispose: () => void;
}

const LAKE = { x: 8, z: -24, r: 25 };
const WATER_Y = -1.35;

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
const smoothstep = (a: number, b: number, x: number) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const easeInOut = (t: number) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);

function heightAt(x: number, z: number): number {
  let h =
    2.4 * Math.sin(x * 0.045) * Math.cos(z * 0.038) +
    1.35 * Math.sin((x + z) * 0.055) +
    0.75 * Math.cos(x * 0.11 - z * 0.07);
  h += 2.6 * Math.exp(-(((x - 2) ** 2 + (z - 72) ** 2) / 4200));

  const d = Math.hypot(x - LAKE.x, z - LAKE.z);
  const inside = 1 - smoothstep(LAKE.r - 4, LAKE.r + 13, d);
  h = lerp(h, -3.7, inside);

  const r = Math.hypot(x * 0.82, z * 0.92);
  h += Math.max(0, r - 100) * 0.24;
  h += 12 * Math.exp(-(((z + 118) / 48) ** 2));
  return h;
}

function rng(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function standard(color: number, extra: Partial<THREE.MeshStandardMaterialParameters> = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.92, metalness: 0.02, flatShading: true, ...extra });
}

function tubeBetween(a: THREE.Vector3, b: THREE.Vector3, radius: number, material: THREE.Material) {
  const dir = new THREE.Vector3().subVectors(b, a);
  const len = Math.max(0.01, dir.length());
  const geo = new THREE.CylinderGeometry(radius * 0.72, radius, len, 5);
  const mesh = new THREE.Mesh(geo, material);
  mesh.position.copy(a).add(b).multiplyScalar(0.5);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
  return mesh;
}

function addPart(
  parent: THREE.Object3D,
  geometry: THREE.BufferGeometry,
  material: THREE.Material,
  position: [number, number, number],
  scale: [number, number, number] = [1, 1, 1],
  part = "body",
) {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(...position);
  mesh.scale.set(...scale);
  mesh.userData.part = part;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function createRuminant(large: boolean) {
  const group = new THREE.Group();
  const fur = standard(large ? 0x6b4d33 : 0x8a6743);
  const pale = standard(large ? 0xc3ad86 : 0xd8c6a3);
  const dark = standard(0x3d2d21);
  const horn = standard(0xd2c3a0);
  const size = large ? 1.32 : 1;

  addPart(group, new THREE.SphereGeometry(1, 12, 9), fur, [0, 1.28, 0], [0.54, 0.58, 1.0]);
  addPart(group, new THREE.SphereGeometry(1, 10, 8), fur, [0, 1.24, -0.66], [0.46, 0.5, 0.5]);
  addPart(group, new THREE.SphereGeometry(1, 9, 7), pale, [0, 1.18, -0.96], [0.22, 0.26, 0.14]);
  addPart(group, new THREE.CylinderGeometry(0.16, 0.27, 0.92, 6), fur, [0, 1.72, 0.62], [1, 1, 1], "neck");
  const neckMesh = group.children[group.children.length - 1] as THREE.Mesh;
  neckMesh.rotation.x = -0.5;
  addPart(group, new THREE.SphereGeometry(0.27, 9, 7), fur, [0, 2.03, 0.88], [0.95, 0.92, 1.24], "head");
  addPart(group, new THREE.SphereGeometry(0.2, 8, 6), pale, [0, 1.95, 1.12], [0.7, 0.6, 0.8], "head");
  addPart(group, new THREE.SphereGeometry(0.045, 6, 4), dark, [0, 1.99, 1.27], [1, 1, 1], "head");

  for (const side of [-1, 1]) {
    const ear = addPart(
      group,
      new THREE.ConeGeometry(0.12, 0.34, 5),
      pale,
      [side * 0.2, 2.22, 0.83],
      [1, 1, 0.55],
      "head",
    );
    ear.rotation.z = side * 0.65;
    ear.rotation.x = 0.16;

    if (large || true) {
      const base = new THREE.Vector3(side * 0.13, 2.18, 0.84);
      const tip = new THREE.Vector3(side * (large ? 0.55 : 0.33), large ? 2.95 : 2.6, large ? 0.55 : 0.7);
      group.add(tubeBetween(base, tip, large ? 0.045 : 0.028, horn));
      group.add(
        tubeBetween(
          new THREE.Vector3(side * (large ? 0.3 : 0.19), large ? 2.5 : 2.35, large ? 0.72 : 0.79),
          new THREE.Vector3(side * (large ? 0.72 : 0.42), large ? 2.8 : 2.48, large ? 0.34 : 0.52),
          large ? 0.032 : 0.022,
          horn,
        ),
      );
      if (large) {
        group.add(
          tubeBetween(
            new THREE.Vector3(side * 0.2, 2.34, 0.8),
            new THREE.Vector3(side * 0.56, 2.62, 0.22),
            0.026,
            horn,
          ),
        );
        group.add(
          tubeBetween(
            new THREE.Vector3(side * 0.45, 2.65, 0.35),
            new THREE.Vector3(side * 0.42, 3.12, 0.63),
            0.024,
            horn,
          ),
        );
      }
    }
  }

  addPart(group, new THREE.ConeGeometry(0.09, 0.36, 5), pale, [0, 1.42, -1.04], [1, 1, 1]);

  const legPivots: THREE.Object3D[] = [];
  const positions: [number, number][] = [
    [-0.29, 0.58],
    [0.29, 0.58],
    [-0.3, -0.58],
    [0.3, -0.58],
  ];
  for (const [x, z] of positions) {
    const pivot = new THREE.Group();
    pivot.position.set(x, 1.08, z);
    const leg = addPart(pivot, new THREE.CylinderGeometry(0.055, 0.075, 1.02, 5), fur, [0, -0.51, 0]);
    leg.castShadow = true;
    addPart(pivot, new THREE.CylinderGeometry(0.06, 0.055, 0.14, 5), dark, [0, -1.02, 0.02]);
    group.add(pivot);
    legPivots.push(pivot);
  }

  group.scale.setScalar(size);
  return { group, legPivots };
}

function createBoar() {
  const group = new THREE.Group();
  const fur = standard(0x4a3b2d);
  const darker = standard(0x32271e);
  const skin = standard(0x8b6a55);
  const bone = standard(0xdfd3b4);

  addPart(group, new THREE.SphereGeometry(1, 11, 8), fur, [0, 0.82, 0], [0.55, 0.55, 1.02]);
  addPart(group, new THREE.SphereGeometry(0.4, 10, 7), fur, [0, 0.98, 0.45], [1, 0.9, 0.6]);
  const head = addPart(group, new THREE.SphereGeometry(0.34, 9, 7), fur, [0, 0.72, 1.0], [1, 0.9, 1.0], "head");
  head.rotation.x = 0.25;
  addPart(group, new THREE.CylinderGeometry(0.16, 0.19, 0.26, 7), skin, [0, 0.6, 1.32], [1, 1, 1], "head").rotation.x = Math.PI / 2;
  for (const side of [-1, 1]) {
    const tusk = addPart(group, new THREE.ConeGeometry(0.035, 0.19, 5), bone, [side * 0.14, 0.55, 1.26], [1, 1, 1], "head");
    tusk.rotation.z = side * -0.45;
    tusk.rotation.x = -0.5;
    const ear = addPart(group, new THREE.ConeGeometry(0.11, 0.24, 4), darker, [side * 0.23, 0.98, 0.98], [1, 1, 1], "head");
    ear.rotation.z = side * 0.4;
    addPart(group, new THREE.SphereGeometry(0.035, 5, 4), darker, [side * 0.2, 0.86, 1.18], [1, 1, 1], "head");
  }
  for (let i = 0; i < 5; i++) {
    const spike = addPart(
      group,
      new THREE.ConeGeometry(0.075, 0.3 + i * 0.02, 4),
      darker,
      [0, 1.08 - i * 0.01, 0.38 - i * 0.19],
      [1, 1, 1],
    );
    spike.rotation.x = -0.35;
  }
  addPart(group, new THREE.ConeGeometry(0.07, 0.34, 4), darker, [0, 0.92, -1.05]).rotation.x = -1.9;

  const legPivots: THREE.Object3D[] = [];
  for (const [x, z] of [
    [-0.3, 0.52],
    [0.3, 0.52],
    [-0.31, -0.58],
    [0.31, -0.58],
  ] as [number, number][]) {
    const pivot = new THREE.Group();
    pivot.position.set(x, 0.66, z);
    addPart(pivot, new THREE.CylinderGeometry(0.075, 0.065, 0.66, 5), darker, [0, -0.33, 0]);
    addPart(pivot, new THREE.CylinderGeometry(0.07, 0.09, 0.12, 5), darker, [0, -0.64, 0.02]);
    group.add(pivot);
    legPivots.push(pivot);
  }
  group.scale.setScalar(1.06);
  return { group, legPivots };
}

function createFox() {
  const group = new THREE.Group();
  const fur = standard(0xa55c30);
  const pale = standard(0xe2d2b6);
  const dark = standard(0x2c241f);

  addPart(group, new THREE.SphereGeometry(1, 10, 8), fur, [0, 0.6, 0], [0.27, 0.29, 0.62]);
  addPart(group, new THREE.SphereGeometry(0.22, 9, 7), fur, [0, 0.79, 0.52], [1, 1, 1.1], "head");
  addPart(group, new THREE.ConeGeometry(0.1, 0.24, 5), pale, [0, 0.72, 0.74], [1, 0.7, 1], "head").rotation.x = Math.PI / 2;
  addPart(group, new THREE.SphereGeometry(0.025, 5, 4), dark, [0, 0.66, 0.86], [1, 1, 1], "head");
  for (const side of [-1, 1]) {
    const ear = addPart(group, new THREE.ConeGeometry(0.1, 0.28, 4), fur, [side * 0.12, 1.0, 0.5], [1, 1, 1], "head");
    ear.rotation.z = side * 0.18;
    addPart(group, new THREE.SphereGeometry(0.026, 5, 4), dark, [side * 0.085, 0.84, 0.7], [1, 1, 1], "head");
  }
  const tail = new THREE.Group();
  tail.position.set(0, 0.62, -0.55);
  tail.rotation.x = 0.85;
  addPart(tail, new THREE.ConeGeometry(0.18, 0.9, 6), fur, [0, -0.32, -0.1], [1, 1, 1]);
  addPart(tail, new THREE.SphereGeometry(0.1, 7, 5), pale, [0, -0.72, -0.1], [1, 1, 1]);
  group.add(tail);

  const legPivots: THREE.Object3D[] = [];
  for (const [x, z] of [
    [-0.15, 0.36],
    [0.15, 0.36],
    [-0.15, -0.36],
    [0.15, -0.36],
  ] as [number, number][]) {
    const pivot = new THREE.Group();
    pivot.position.set(x, 0.46, z);
    addPart(pivot, new THREE.CylinderGeometry(0.04, 0.035, 0.46, 5), dark, [0, -0.23, 0]);
    group.add(pivot);
    legPivots.push(pivot);
  }
  group.scale.setScalar(1.22);
  return { group, legPivots };
}

function createHare() {
  const group = new THREE.Group();
  const fur = standard(0xa8987b);
  const pale = standard(0xded2b8);
  const dark = standard(0x43392e);

  addPart(group, new THREE.SphereGeometry(1, 10, 8), fur, [0, 0.42, 0], [0.26, 0.3, 0.4]);
  addPart(group, new THREE.SphereGeometry(0.18, 9, 7), fur, [0, 0.62, 0.3], [1, 1, 1], "head");
  addPart(group, new THREE.SphereGeometry(0.025, 5, 4), dark, [0, 0.6, 0.47], [1, 1, 1], "head");
  for (const side of [-1, 1]) {
    const ear = addPart(group, new THREE.CapsuleGeometry(0.055, 0.34, 3, 5), pale, [side * 0.09, 0.94, 0.24], [1, 1, 1], "head");
    ear.rotation.z = side * 0.14;
    ear.rotation.x = -0.2;
  }
  addPart(group, new THREE.SphereGeometry(0.11, 6, 5), pale, [0, 0.48, -0.38]);
  const legPivots: THREE.Object3D[] = [];
  for (const [x, z] of [
    [-0.14, 0.2],
    [0.14, 0.2],
    [-0.14, -0.22],
    [0.14, -0.22],
  ] as [number, number][]) {
    const pivot = new THREE.Group();
    pivot.position.set(x, 0.28, z);
    addPart(pivot, new THREE.CylinderGeometry(0.035, 0.03, 0.3, 4), pale, [0, -0.15, 0]);
    group.add(pivot);
    legPivots.push(pivot);
  }
  group.scale.setScalar(1.25);
  return { group, legPivots };
}

function createPheasant() {
  const group = new THREE.Group();
  const copper = standard(0x8e5d39);
  const green = standard(0x33493c);
  const gold = standard(0xc7a364);
  const red = standard(0xa3452e);
  const dark = standard(0x3c332a);

  addPart(group, new THREE.SphereGeometry(1, 10, 8), copper, [0, 0.55, 0], [0.25, 0.3, 0.46]);
  addPart(group, new THREE.SphereGeometry(0.15, 8, 6), green, [0, 0.86, 0.3], [1, 1, 1], "head");
  addPart(group, new THREE.ConeGeometry(0.06, 0.16, 4), gold, [0, 0.86, 0.48], [1, 1, 1], "head").rotation.x = Math.PI / 2;
  addPart(group, new THREE.SphereGeometry(0.055, 6, 5), red, [0, 0.93, 0.24], [1, 1, 1], "head");
  const tail = addPart(group, new THREE.ConeGeometry(0.13, 1.0, 5), copper, [0, 0.65, -0.62], [1, 1, 1]);
  tail.rotation.x = -1.15;
  addPart(group, new THREE.ConeGeometry(0.035, 0.85, 4), dark, [0, 0.66, -0.63]).rotation.x = -1.1;
  for (const side of [-1, 1]) {
    addPart(group, new THREE.CylinderGeometry(0.025, 0.022, 0.32, 4), gold, [side * 0.1, 0.18, 0]);
    addPart(group, new THREE.ConeGeometry(0.03, 0.16, 4), gold, [side * 0.1, 0.1, 0.08]);
  }
  group.scale.setScalar(1.2);
  return { group, legPivots: [] };
}

const SPAWNS: { key: SpeciesKey; x: number; z: number; radius: number }[] = [
  { key: "deer", x: -24, z: 10, radius: 16 },
  { key: "boar", x: -40, z: 38, radius: 11 },
  { key: "fox", x: 18, z: 7, radius: 14 },
  { key: "elk", x: -48, z: -58, radius: 15 },
  { key: "hare", x: 7, z: 54, radius: 8 },
  { key: "deer", x: 34, z: 26, radius: 15 },
  { key: "pheasant", x: 19, z: 64, radius: 7 },
  { key: "boar", x: 26, z: 52, radius: 10 },
  { key: "deer", x: 48, z: -26, radius: 18 },
  { key: "hare", x: -19, z: 57, radius: 9 },
  { key: "fox", x: -14, z: -48, radius: 13 },
  { key: "elk", x: 62, z: -68, radius: 13 },
  { key: "boar", x: -58, z: -14, radius: 12 },
  { key: "hare", x: 45, z: 8, radius: 10 },
  { key: "pheasant", x: -31, z: 30, radius: 8 },
  { key: "deer", x: -62, z: 22, radius: 15 },
  { key: "elk", x: 12, z: -74, radius: 14 },
  { key: "fox", x: 54, z: 38, radius: 12 },
  { key: "boar", x: 62, z: 2, radius: 12 },
  { key: "deer", x: 6, z: 42, radius: 12 },
  { key: "hare", x: -70, z: 48, radius: 10 },
  { key: "elk", x: 28, z: -50, radius: 15 },
  { key: "fox", x: -34, z: -30, radius: 13 },
  { key: "boar", x: -12, z: 24, radius: 10 },
  { key: "deer", x: 70, z: 52, radius: 14 },
  { key: "deer", x: -44, z: -8, radius: 13 },
  { key: "hare", x: 56, z: 18, radius: 9 },
  { key: "pheasant", x: 44, z: -14, radius: 8 },
  { key: "boar", x: 36, z: 70, radius: 10 },
  { key: "deer", x: -8, z: 34, radius: 12 },
  { key: "fox", x: 24, z: -20, radius: 12 },
  { key: "elk", x: 80, z: -30, radius: 14 },
  { key: "boar", x: -76, z: 4, radius: 11 },
  { key: "deer", x: 20, z: 50, radius: 12 },
  { key: "hare", x: -52, z: 62, radius: 9 },
  { key: "pheasant", x: -66, z: 36, radius: 8 },
];

interface Animal {
  key: SpeciesKey;
  group: THREE.Group;
  legPivots: THREE.Object3D[];
  alive: boolean;
  active: boolean;
  deadFor: number;
  hiddenFor: number;
  spawn: THREE.Vector3;
  waypoint: THREE.Vector3;
  heading: number;
  phase: number;
  pauseFor: number;
  fleeFor: number;
  speed: number;
  baseSpeed: number;
  bob: number;
  respawnIn: number;
  initial: boolean;
}

export class HuntingWorld implements WorldApi {
  private canvas: HTMLCanvasElement;
  private callbacks: WorldCallbacks;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private clock = new THREE.Clock();
  private frame = 0;
  private elapsed = 0;
  private disposed = false;
  private resizeObserver?: ResizeObserver;

  private mode: WorldMode = "landing";
  private paused = false;
  private intro = 0;
  private introPos = new THREE.Vector3();
  private introQuat = new THREE.Quaternion();
  private desired = new THREE.Object3D();

  private player = new THREE.Vector3(0, 0, 66);
  private yaw = -0.05;
  private pitch = -0.04;
  private targetYaw = -0.05;
  private targetPitch = -0.04;
  private walkPhase = 0;
  private moving = false;
  private keys = new Set<string>();

  private aiming = false;
  private dragging = false;
  private dragMoved = 0;
  private dragStart = 0;
  private lastPointer = { x: 0, y: 0 };
  private recoil = 0;
  private fireCooldown = 0;
  private reloading = false;
  private reloadTimer = 0;
  private magazine = 5;
  private reserve = 15;
  private loadout: LoadoutSpec = { id: "carbine", magazine: 5, reserve: 15, zoomFov: 19 };

  private animals: Animal[] = [];
  private wavesActive = false;
  private moveAxes = new THREE.Vector2();
  private lookSensitivity = 1;
  private isMobile = false;
  private raycaster = new THREE.Raycaster();
  private targetTimer = 0;
  private spottedTimer = 0;
  private lastTarget = "";
  private lastHeading = -1;
  private lastSpotted = "";

  private weapon = new THREE.Group();
  private muzzle = new THREE.Sprite();
  private muzzleLight = new THREE.PointLight(0xffc27a, 0, 10, 2);
  private muzzleTimer = 0;
  private flashTexture?: THREE.CanvasTexture;
  private water?: THREE.Mesh;
  private birds: { group: THREE.Group; wingL: THREE.Mesh; wingR: THREE.Mesh; radius: number; speed: number; phase: number; height: number }[] = [];
  private dust?: THREE.Points;

  private infiniteAmmo = true;
  private mapId: MapId = "golden";
  private terrainGeometry?: THREE.PlaneGeometry;
  private waterMaterial?: THREE.MeshStandardMaterial;
  private skyUniforms?: Record<string, THREE.IUniform>;
  private sunLight?: THREE.DirectionalLight;
  private hemiLight?: THREE.HemisphereLight;
  private sunSprite?: THREE.Sprite;
  private mountainMats: { material: THREE.MeshStandardMaterial; range: number }[] = [];
  private pineLayers: THREE.InstancedMesh[] = [];
  private pineCount = 0;
  private aspenCrowns?: THREE.InstancedMesh;
  private aspenCount = 0;
  private grassMesh?: THREE.InstancedMesh;
  private grassCount = 0;
  private trailMaterial?: THREE.MeshStandardMaterial;
  private snow?: THREE.Points;
  private snowSpeeds: number[] = [];

  constructor(canvas: HTMLCanvasElement, callbacks: WorldCallbacks) {
    this.canvas = canvas;
    this.callbacks = callbacks;

    this.isMobile = window.innerWidth < 820 || window.matchMedia("(pointer: coarse)").matches;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: !this.isMobile, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, this.isMobile ? 1.4 : 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.06;

    this.camera = new THREE.PerspectiveCamera(55, 1, 0.08, 1200);
    this.camera.rotation.order = "YXZ";
    this.scene.add(this.camera);
    this.scene.fog = new THREE.Fog(0xcbb18e, 75, 335);

    this.buildSky();
    this.buildLights();
    this.buildTerrain();
    this.buildMountains();
    this.buildForest();
    this.buildCamp();
    this.buildAnimals();
    this.buildBirds();
    this.buildDust();
    this.buildWeather();
    this.buildWeapon();
    this.applyMap("golden");

    this.resize();
    this.bindEvents();
    this.emitAmmo();
    this.resetHunt(true);
    this.animate();
  }

  /* ---------------------------------- world --------------------------------- */

  private buildSky() {
    const skyGeo = new THREE.SphereGeometry(560, 32, 20);
    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        zenith: { value: new THREE.Color("#6c8b9a") },
        mid: { value: new THREE.Color("#c9b99c") },
        horizon: { value: new THREE.Color("#f0d3a3") },
        sunDir: { value: new THREE.Vector3(0.42, 0.2, -0.88).normalize() },
        sunColor: { value: new THREE.Color("#ffe3ad") },
      },
      vertexShader: `
        varying vec3 vPos;
        void main() {
          vPos = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vPos;
        uniform vec3 zenith;
        uniform vec3 mid;
        uniform vec3 horizon;
        uniform vec3 sunDir;
        uniform vec3 sunColor;
        void main() {
          vec3 dir = normalize(vPos);
          float h = clamp(dir.y, -0.12, 1.0);
          vec3 col = mix(horizon, mid, smoothstep(0.0, 0.24, h));
          col = mix(col, zenith, smoothstep(0.22, 0.8, h));
          float sun = max(dot(dir, normalize(sunDir)), 0.0);
          col += sunColor * pow(sun, 38.0) * 0.55;
          col += sunColor * pow(sun, 8.0) * 0.10;
          col += horizon * smoothstep(0.22, 0.0, abs(h)) * 0.06;
          gl_FragColor = vec4(col, 1.0);
        }
      `,
    });
    const sky = new THREE.Mesh(skyGeo, skyMat);
    this.skyUniforms = skyMat.uniforms;
    this.scene.add(sky);

    const c = document.createElement("canvas");
    c.width = c.height = 128;
    const ctx = c.getContext("2d");
    if (ctx) {
      const g = ctx.createRadialGradient(64, 64, 2, 64, 64, 64);
      g.addColorStop(0, "rgba(255,246,220,1)");
      g.addColorStop(0.16, "rgba(255,228,172,0.95)");
      g.addColorStop(0.42, "rgba(255,199,126,0.35)");
      g.addColorStop(1, "rgba(255,190,120,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 128, 128);
    }
    const sunTexture = new THREE.CanvasTexture(c);
    const sun = new THREE.Sprite(new THREE.SpriteMaterial({ map: sunTexture, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, fog: false }));
    sun.position.set(215, 108, -430);
    sun.scale.setScalar(145);
    this.sunSprite = sun;
    this.scene.add(sun);

    const cloudMat = new THREE.MeshBasicMaterial({ color: 0xf5e3c6, transparent: true, opacity: 0.34, depthWrite: false, fog: false });
    const random = rng(77);
    for (let i = 0; i < 9; i++) {
      const cloud = new THREE.Group();
      for (let j = 0; j < 4; j++) {
        const puff = new THREE.Mesh(new THREE.SphereGeometry(1, 8, 6), cloudMat);
        puff.position.set(j * 9 - 13 + random() * 6, random() * 3, random() * 7);
        puff.scale.set(14 + random() * 12, 2.2 + random() * 1.8, 4 + random() * 3);
        cloud.add(puff);
      }
      cloud.position.set((random() - 0.5) * 520, 95 + random() * 55, -230 - random() * 170);
      this.scene.add(cloud);
    }
  }

  private buildLights() {
    const hemi = new THREE.HemisphereLight(0xdfe8ea, 0x4c4631, 1.25);
    this.scene.add(hemi);
    const sun = new THREE.DirectionalLight(0xffdcae, 2.35);
    sun.position.set(75, 95, -55);
    sun.castShadow = true;
    sun.shadow.mapSize.set(this.isMobile ? 1024 : 2048, this.isMobile ? 1024 : 2048);
    sun.shadow.camera.near = 1;
    sun.shadow.camera.far = 260;
    sun.shadow.camera.left = -85;
    sun.shadow.camera.right = 85;
    sun.shadow.camera.top = 85;
    sun.shadow.camera.bottom = -85;
    sun.shadow.bias = -0.0007;
    sun.shadow.normalBias = 0.045;
    this.scene.add(sun);
    this.scene.add(sun.target);
    sun.target.position.set(0, 0, 10);

    const fill = new THREE.DirectionalLight(0xa9c4c1, 0.32);
    fill.position.set(-60, 40, 70);
    this.scene.add(fill);
    this.scene.add(new THREE.AmbientLight(0xf0d7ae, 0.16));
    this.hemiLight = hemi;
    this.sunLight = sun;
  }

  private buildTerrain() {
    const size = 460;
    const segments = 150;
    const geo = new THREE.PlaneGeometry(size, size, segments, segments);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position as THREE.BufferAttribute;
    const colors: number[] = [];
    const grassLow = new THREE.Color("#6b7c4b");
    const grassHigh = new THREE.Color("#8a8c5e");
    const sand = new THREE.Color("#a49975");
    const rock = new THREE.Color("#73756b");
    const temp = new THREE.Color();

    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const y = heightAt(x, z);
      pos.setY(i, y);
      const variation = Math.sin(x * 1.7 + z * 0.9) * 0.5 + Math.sin(z * 2.3) * 0.5;
      temp.copy(grassLow).lerp(grassHigh, smoothstep(0, 8, y));
      temp.lerp(sand, smoothstep(0.6, -1.8, y));
      temp.lerp(rock, smoothstep(10, 24, y));
      temp.offsetHSL(variation * 0.006, variation * 0.03, variation * 0.027);
      colors.push(temp.r, temp.g, temp.b);
    }
    geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.98, metalness: 0, flatShading: false });
    const terrain = new THREE.Mesh(geo, mat);
    terrain.receiveShadow = true;
    this.terrainGeometry = geo;
    this.scene.add(terrain);

    const waterGeo = new THREE.CircleGeometry(34, 48);
    waterGeo.rotateX(-Math.PI / 2);
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x748f8b,
      roughness: 0.18,
      metalness: 0.55,
      transparent: true,
      opacity: 0.9,
    });
    this.water = new THREE.Mesh(waterGeo, waterMat);
    this.water.position.set(LAKE.x, WATER_Y, LAKE.z);
    this.water.receiveShadow = true;
    this.waterMaterial = waterMat;
    this.scene.add(this.water);

    const shore = new THREE.Mesh(
      new THREE.RingGeometry(30, 36, 48),
      new THREE.MeshStandardMaterial({ color: 0xa79a76, roughness: 1, transparent: true, opacity: 0.7 }),
    );
    shore.rotation.x = -Math.PI / 2;
    shore.position.set(LAKE.x, WATER_Y + 0.01, LAKE.z);
    this.scene.add(shore);

    const random = rng(41);
    const stoneGeo = new THREE.DodecahedronGeometry(1, 0);
    const stoneMat = standard(0x817f71);
    const stones = new THREE.InstancedMesh(stoneGeo, stoneMat, 75);
    const dummy = new THREE.Object3D();
    for (let i = 0; i < 75; i++) {
      const angle = random() * Math.PI * 2;
      const dist = 32 + random() * 10;
      const x = LAKE.x + Math.cos(angle) * dist;
      const z = LAKE.z + Math.sin(angle) * dist;
      const s = 0.25 + random() * 0.75;
      dummy.position.set(x, heightAt(x, z) + s * 0.25, z);
      dummy.scale.set(s * 1.4, s * 0.7, s);
      dummy.rotation.set(random() * 3, random() * 3, random() * 3);
      dummy.updateMatrix();
      stones.setMatrixAt(i, dummy.matrix);
    }
    stones.castShadow = true;
    stones.receiveShadow = true;
    this.scene.add(stones);
  }

  private buildMountains() {
    const random = rng(23);
    const ranges = [
      { z: -300, color: "#8b9497", height: 105, spread: 480, count: 10 },
      { z: -236, color: "#77817f", height: 82, spread: 420, count: 9 },
      { z: -178, color: "#66715f", height: 58, spread: 360, count: 8 },
    ];
    for (const range of ranges) {
      for (let i = 0; i < range.count; i++) {
        const radius = 42 + random() * 48;
        const h = range.height * (0.5 + random() * 0.85);
        const geo = new THREE.ConeGeometry(radius, h, 5 + Math.floor(random() * 3), 2);
        const mat = new THREE.MeshStandardMaterial({ color: range.color, roughness: 1, flatShading: true });
        this.mountainMats.push({ material: mat, range: ranges.indexOf(range) });
        const mountain = new THREE.Mesh(geo, mat);
        mountain.position.set(
          (i / (range.count - 1) - 0.5) * range.spread + (random() - 0.5) * 30,
          h / 2 - 16,
          range.z - random() * 40,
        );
        mountain.rotation.y = random() * Math.PI;
        mountain.scale.set(1 + random() * 0.4, 1, 1);
        mountain.receiveShadow = true;
        this.scene.add(mountain);
        if (h > range.height * 0.9) {
          const cap = new THREE.Mesh(
            new THREE.ConeGeometry(radius * 0.3, h * 0.3, 5),
            new THREE.MeshStandardMaterial({ color: 0xe8e1d3, roughness: 1, flatShading: true }),
          );
          cap.position.set(mountain.position.x, h - 16 - h * 0.15, mountain.position.z);
          cap.rotation.y = mountain.rotation.y;
          this.scene.add(cap);
        }
      }
    }
  }

  private buildForest() {
    const random = rng(1187);
    const dummy = new THREE.Object3D();
    const pines: { x: number; z: number; y: number; s: number; color: THREE.Color }[] = [];

    let attempts = 0;
    while (pines.length < 190 && attempts < 900) {
      attempts++;
      const x = (random() - 0.5) * 290;
      const z = (random() - 0.5) * 290 - 10;
      const lakeD = Math.hypot(x - LAKE.x, z - LAKE.z);
      if (lakeD < 35) continue;
      const y = heightAt(x, z);
      if (y < 0.1) continue;
      if (z > 46 && Math.abs(x) < 17) continue;
      const s = 0.8 + random() * 1.15;
      const palette = [0x2f4a36, 0x36553c, 0x3d5b40, 0x2a412f, 0x496445];
      pines.push({ x, z, y, s, color: new THREE.Color(palette[Math.floor(random() * palette.length)]) });
    }

    const trunkGeo = new THREE.CylinderGeometry(0.16, 0.28, 2.6, 5);
    const trunkMat = standard(0x5b4531);
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, pines.length);
    const layerGeos = [
      new THREE.ConeGeometry(1, 1, 6),
      new THREE.ConeGeometry(1, 1, 6),
      new THREE.ConeGeometry(1, 1, 6),
    ];
    const foliageMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.95, flatShading: true });
    const layers = layerGeos.map((g) => new THREE.InstancedMesh(g, foliageMat.clone(), pines.length));

    pines.forEach((p, i) => {
      dummy.position.set(p.x, p.y + p.s * 1.3, p.z);
      dummy.scale.set(p.s, p.s, p.s);
      dummy.rotation.set(0, random() * 6.28, 0);
      dummy.updateMatrix();
      trunks.setMatrixAt(i, dummy.matrix);
      const layerSpecs = [
        { r: 1.75, h: 3.4, y: 3.3 },
        { r: 1.3, h: 3.0, y: 5.0 },
        { r: 0.82, h: 2.4, y: 6.4 },
      ];
      layerSpecs.forEach((spec, li) => {
        dummy.position.set(p.x, p.y + spec.y * p.s, p.z);
        dummy.scale.set(spec.r * p.s, spec.h * p.s, spec.r * p.s);
        dummy.updateMatrix();
        layers[li].setMatrixAt(i, dummy.matrix);
        layers[li].setColorAt(i, p.color.clone().offsetHSL(0, 0, li * 0.025));
      });
    });
    trunks.castShadow = true;
    trunks.receiveShadow = true;
    this.scene.add(trunks);
    this.pineLayers = layers;
    this.pineCount = pines.length;
    layers.forEach((layer) => {
      layer.castShadow = true;
      layer.receiveShadow = true;
      this.scene.add(layer);
    });

    // Golden aspens
    const aspens: { x: number; z: number; y: number; s: number; color: THREE.Color }[] = [];
    attempts = 0;
    while (aspens.length < 75 && attempts < 600) {
      attempts++;
      const x = (random() - 0.5) * 220;
      const z = (random() - 0.5) * 200 + 10;
      if (Math.hypot(x - LAKE.x, z - LAKE.z) < 36) continue;
      const y = heightAt(x, z);
      if (y < 0.2) continue;
      if (z > 50 && Math.abs(x) < 14) continue;
      aspens.push({
        x,
        z,
        y,
        s: 0.8 + random() * 0.7,
        color: new THREE.Color([0xbf9a55, 0xc9a45e, 0xa98743, 0xd0ae6c, 0x8f8a4c][Math.floor(random() * 5)]),
      });
    }
    const aspenTrunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.11, 0.17, 4.6, 5), standard(0xb8ab92), aspens.length);
    const aspenCrowns = new THREE.InstancedMesh(
      new THREE.IcosahedronGeometry(1, 1),
      new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.98, flatShading: true }),
      aspens.length,
    );
    aspens.forEach((a, i) => {
      dummy.position.set(a.x, a.y + a.s * 2.2, a.z);
      dummy.scale.set(a.s, a.s, a.s);
      dummy.rotation.set(0, random() * 6.28, 0);
      dummy.updateMatrix();
      aspenTrunks.setMatrixAt(i, dummy.matrix);
      dummy.position.set(a.x, a.y + a.s * 4.5, a.z);
      dummy.scale.set(a.s * 1.55, a.s * 2.1, a.s * 1.55);
      dummy.updateMatrix();
      aspenCrowns.setMatrixAt(i, dummy.matrix);
      aspenCrowns.setColorAt(i, a.color);
    });
    aspenTrunks.castShadow = true;
    aspenCrowns.castShadow = true;
    aspenCrowns.receiveShadow = true;
    this.aspenCrowns = aspenCrowns;
    this.aspenCount = aspens.length;
    this.scene.add(aspenTrunks, aspenCrowns);

    // Meadow grass
    const grass = new THREE.InstancedMesh(
      new THREE.ConeGeometry(0.16, 0.9, 4),
      new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, flatShading: true }),
      window.innerWidth < 760 ? 260 : 620,
    );
    for (let i = 0; i < grass.count; i++) {
      const x = (random() - 0.5) * 170;
      const z = (random() - 0.5) * 170 + 15;
      const y = heightAt(x, z);
      if (y < -0.1) {
        dummy.position.set(x, -20, z);
      } else {
        dummy.position.set(x, y + 0.4, z);
      }
      const s = 0.5 + random() * 0.9;
      dummy.scale.set(s, s, s);
      dummy.rotation.set((random() - 0.5) * 0.3, random() * 6, (random() - 0.5) * 0.3);
      dummy.updateMatrix();
      grass.setMatrixAt(i, dummy.matrix);
      grass.setColorAt(i, new THREE.Color([0x9d9b62, 0xb0a56c, 0x87884f, 0xc0ac75][Math.floor(random() * 4)]));
    }
    this.grassMesh = grass;
    this.grassCount = grass.count;
    this.scene.add(grass);

    // Trail to the lake
    const trailGeo = new THREE.CircleGeometry(1, 10);
    trailGeo.rotateX(-Math.PI / 2);
    const trail = new THREE.InstancedMesh(trailGeo, new THREE.MeshStandardMaterial({ color: 0x988a68, roughness: 1 }), 44);
    for (let i = 0; i < 44; i++) {
      const t = i / 43;
      const x = lerp(0, 22, t) + Math.sin(t * 5.5) * 8;
      const z = lerp(62, 8, t);
      const y = heightAt(x, z);
      dummy.position.set(x, y + 0.04, z);
      const s = 0.55 + Math.sin(t * Math.PI) * 0.5;
      dummy.scale.set(s * 2.2, 1, s);
      dummy.rotation.set(0, t * 2.4, 0);
      dummy.updateMatrix();
      trail.setMatrixAt(i, dummy.matrix);
    }
    trail.receiveShadow = true;
    this.trailMaterial = trail.material as THREE.MeshStandardMaterial;
    this.scene.add(trail);
  }

  private buildCamp() {
    const camp = new THREE.Group();
    const x = -17;
    const z = 56;
    const y = heightAt(x, z);
    camp.position.set(x, y, z);

    const canvasMat = standard(0xa4774a);
    const canvasDark = standard(0x7d5635);
    const tent = new THREE.Group();
    const panelGeo = new THREE.PlaneGeometry(3.4, 2.6);
    const left = new THREE.Mesh(panelGeo, canvasMat);
    left.position.set(-0.85, 1.25, 0);
    left.rotation.y = Math.PI / 2;
    left.rotation.z = 0.55;
    left.castShadow = true;
    const right = new THREE.Mesh(panelGeo, canvasDark);
    right.position.set(0.85, 1.25, 0);
    right.rotation.y = -Math.PI / 2;
    right.rotation.z = -0.55;
    right.castShadow = true;
    tent.add(left, right);
    const flap = new THREE.Mesh(new THREE.CircleGeometry(0.75, 3), standard(0x3a2a1e));
    flap.position.set(0, 0.9, 1.12);
    flap.rotation.x = -0.1;
    tent.add(flap);
    tent.rotation.y = 0.6;
    camp.add(tent);

    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2;
      const stone = new THREE.Mesh(new THREE.DodecahedronGeometry(0.17, 0), standard(0x777468));
      stone.position.set(Math.cos(angle) * 0.78, 0.1, Math.sin(angle) * 0.78);
      stone.castShadow = true;
      camp.add(stone);
    }
    const logMat = standard(0x51402c);
    for (let i = 0; i < 4; i++) {
      const log = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.9, 5), logMat);
      log.rotation.set(Math.PI / 2, (i / 4) * Math.PI, 0);
      log.position.y = 0.16;
      camp.add(log);
    }
    const ember = new THREE.PointLight(0xff8c3d, 1.8, 8, 2);
    ember.position.set(0, 0.4, 0);
    camp.add(ember);
    this.scene.add(camp);
  }

  private createAnimalModel(key: SpeciesKey) {
    switch (key) {
      case "deer":
        return createRuminant(false);
      case "elk":
        return createRuminant(true);
      case "boar":
        return createBoar();
      case "fox":
        return createFox();
      case "hare":
        return createHare();
      case "pheasant":
        return createPheasant();
    }
  }

  private buildAnimals() {
    const random = rng(303);
    for (const spawn of SPAWNS) {
      const model = this.createAnimalModel(spawn.key);
      const group = model.group;
      const y = heightAt(spawn.x, spawn.z);
      group.position.set(spawn.x, y, spawn.z);
      group.rotation.y = random() * Math.PI * 2;
      const bigGame = spawn.key === "deer" || spawn.key === "elk" || spawn.key === "boar";
      group.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          child.castShadow = bigGame && !this.isMobile;
          child.receiveShadow = true;
        }
      });
      const baseSpeed = spawn.key === "hare" ? 1.9 : spawn.key === "fox" ? 1.4 : spawn.key === "boar" ? 0.95 : 0.72 + random() * 0.5;
      const animal: Animal = {
        key: spawn.key,
        group,
        legPivots: model.legPivots,
        alive: true,
        active: true,
        deadFor: 0,
        hiddenFor: 0,
        spawn: new THREE.Vector3(spawn.x, y, spawn.z),
        waypoint: new THREE.Vector3(spawn.x, y, spawn.z),
        heading: group.rotation.y,
        phase: random() * Math.PI * 2,
        pauseFor: random() * 2,
        fleeFor: 0,
        speed: baseSpeed,
        baseSpeed,
        bob: 0,
        respawnIn: 0,
        initial: true,
      };
      group.userData.animal = animal;
      group.traverse((child) => {
        child.userData.animal = animal;
      });
      this.scene.add(group);
      this.animals.push(animal);
    }
  }

  private buildBirds() {
    const mat = new THREE.MeshBasicMaterial({ color: 0x2d3129, side: THREE.DoubleSide, transparent: true, opacity: 0.75, fog: false });
    const wingGeo = new THREE.BufferGeometry();
    wingGeo.setAttribute("position", new THREE.Float32BufferAttribute([0, 0, 0, 1.15, 0.2, 0.38, 0.1, 0, 0.55], 3));
    wingGeo.computeVertexNormals();
    const random = rng(909);
    for (let i = 0; i < 12; i++) {
      const group = new THREE.Group();
      const wingL = new THREE.Mesh(wingGeo, mat);
      const wingR = new THREE.Mesh(wingGeo, mat);
      wingR.scale.x = -1;
      group.add(wingL, wingR);
      const scale = 0.8 + random() * 0.8;
      group.scale.setScalar(scale);
      this.scene.add(group);
      this.birds.push({
        group,
        wingL,
        wingR,
        radius: 34 + random() * 45,
        speed: 0.06 + random() * 0.05,
        phase: random() * Math.PI * 2,
        height: 30 + random() * 24,
      });
    }
  }

  private buildDust() {
    const random = rng(52);
    const count = 240;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (random() - 0.5) * 120;
      positions[i * 3 + 1] = 1 + random() * 22;
      positions[i * 3 + 2] = (random() - 0.5) * 120 + 20;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const c = document.createElement("canvas");
    c.width = c.height = 32;
    const ctx = c.getContext("2d");
    if (ctx) {
      const g = ctx.createRadialGradient(16, 16, 0, 16, 16, 16);
      g.addColorStop(0, "rgba(255,241,214,0.9)");
      g.addColorStop(1, "rgba(255,241,214,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 32, 32);
    }
    const mat = new THREE.PointsMaterial({
      size: 0.24,
      map: new THREE.CanvasTexture(c),
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
      color: 0xffe4b4,
      blending: THREE.AdditiveBlending,
    });
    this.dust = new THREE.Points(geo, mat);
    this.scene.add(this.dust);
  }

  private buildWeather() {
    const random = rng(4141);
    const count = this.isMobile ? 360 : 720;
    const positions = new Float32Array(count * 3);
    this.snowSpeeds = [];
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (random() - 0.5) * 190;
      positions[i * 3 + 1] = 1 + random() * 68;
      positions[i * 3 + 2] = (random() - 0.5) * 190 + 10;
      this.snowSpeeds.push(1.1 + random() * 2.1);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const c = document.createElement("canvas");
    c.width = c.height = 24;
    const ctx = c.getContext("2d");
    if (ctx) {
      const g = ctx.createRadialGradient(12, 12, 0, 12, 12, 12);
      g.addColorStop(0, "rgba(255,255,255,1)");
      g.addColorStop(0.5, "rgba(255,255,255,0.8)");
      g.addColorStop(1, "rgba(255,255,255,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 24, 24);
    }
    const material = new THREE.PointsMaterial({
      size: 0.34,
      map: new THREE.CanvasTexture(c),
      transparent: true,
      opacity: 0.82,
      depthWrite: false,
      color: 0xffffff,
    });
    this.snow = new THREE.Points(geo, material);
    this.snow.visible = false;
    this.scene.add(this.snow);
  }

  /* ------------------------------- environment ------------------------------ */

  private paintTerrain(map: HuntingMap) {
    const geo = this.terrainGeometry;
    if (!geo) return;
    const positions = geo.getAttribute("position") as THREE.BufferAttribute;
    const colorAttr = geo.getAttribute("color") as THREE.BufferAttribute | undefined;
    if (!colorAttr) return;
    const colors = colorAttr.array as Float32Array;
    const low = new THREE.Color(map.terrain.low);
    const high = new THREE.Color(map.terrain.high);
    const shore = new THREE.Color(map.terrain.shore);
    const rock = new THREE.Color(map.terrain.rock);
    const temp = new THREE.Color();
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i);
      const z = positions.getZ(i);
      const y = positions.getY(i);
      const variation = Math.sin(x * 1.7 + z * 0.9) * 0.5 + Math.sin(z * 2.3) * 0.5;
      temp.copy(low).lerp(high, smoothstep(0, 8, y));
      temp.lerp(shore, smoothstep(0.6, -1.8, y));
      temp.lerp(rock, smoothstep(10, 24, y));
      temp.offsetHSL(variation * 0.006, variation * 0.03, variation * 0.027);
      colors[i * 3] = temp.r;
      colors[i * 3 + 1] = temp.g;
      colors[i * 3 + 2] = temp.b;
    }
    colorAttr.needsUpdate = true;
  }

  private paintInstances(mesh: THREE.InstancedMesh | undefined, count: number, palette: string[], lightness = 0.01) {
    if (!mesh) return;
    for (let i = 0; i < count; i++) {
      const color = new THREE.Color(palette[i % palette.length]);
      color.offsetHSL(0, 0, (((i * 17) % 7) - 3) * lightness);
      mesh.setColorAt(i, color);
    }
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }

  private applyMap(id: MapId) {
    this.mapId = id;
    const map = mapById(id);
    const uniforms = this.skyUniforms;
    if (uniforms) {
      (uniforms.zenith.value as THREE.Color).set(map.sky.zenith);
      (uniforms.mid.value as THREE.Color).set(map.sky.mid);
      (uniforms.horizon.value as THREE.Color).set(map.sky.horizon);
      (uniforms.sunColor.value as THREE.Color).set(map.sky.sun);
      const direction = new THREE.Vector3(...map.sun.position).normalize();
      (uniforms.sunDir.value as THREE.Vector3).copy(direction);
    }
    if (this.scene.fog instanceof THREE.Fog) {
      this.scene.fog.color.set(map.fog.color);
      this.scene.fog.near = map.fog.near;
      this.scene.fog.far = map.fog.far;
    }
    if (this.sunLight) {
      this.sunLight.color.set(map.sun.color);
      this.sunLight.intensity = map.sun.intensity;
      this.sunLight.position.set(...map.sun.position);
    }
    if (this.hemiLight) {
      this.hemiLight.color.set(map.hemi.sky);
      this.hemiLight.groundColor.set(map.hemi.ground);
      this.hemiLight.intensity = map.hemi.intensity;
    }
    if (this.sunSprite) {
      (this.sunSprite.material as THREE.SpriteMaterial).color.set(map.sky.sun);
      const pos = new THREE.Vector3(...map.sun.position).normalize().multiplyScalar(460);
      this.sunSprite.position.copy(pos);
    }
    this.renderer.toneMappingExposure = map.sun.exposure;
    if (this.waterMaterial) {
      this.waterMaterial.color.set(map.water.color);
      this.waterMaterial.opacity = map.water.opacity;
      this.waterMaterial.metalness = map.water.metalness;
    }
    if (this.trailMaterial) this.trailMaterial.color.set(map.terrain.shore).offsetHSL(0, -0.04, -0.06);
    this.mountainMats.forEach(({ material, range }) => {
      material.color.set(map.mountains[range] ?? map.mountains[2]);
    });
    this.paintTerrain(map);
    this.paintInstances(this.aspenCrowns, this.aspenCount, map.aspens, 0.012);
    this.paintInstances(this.grassMesh, this.grassCount, map.grass, 0.02);
    this.pineLayers.forEach((layer, layerIndex) => {
      for (let i = 0; i < this.pineCount; i++) {
        const color = new THREE.Color(map.pines[i % map.pines.length]);
        color.offsetHSL(0, 0, (((i * 13) % 7) - 3) * 0.008 + layerIndex * 0.02);
        layer.setColorAt(i, color);
      }
      if (layer.instanceColor) layer.instanceColor.needsUpdate = true;
    });
    if (this.snow) this.snow.visible = map.snow;
    if (this.dust) (this.dust.material as THREE.PointsMaterial).opacity = map.snow ? 0.12 : 0.55;
  }

  private buildWeapon() {
    this.weapon = new THREE.Group();
    const metal = new THREE.MeshStandardMaterial({ color: 0x596159, roughness: 0.4, metalness: 0.45 });
    const darkMetal = new THREE.MeshStandardMaterial({ color: 0x2c332e, roughness: 0.48, metalness: 0.4 });
    const wood = new THREE.MeshStandardMaterial({ color: 0x8a5e35, roughness: 0.52, metalness: 0.04 });
    const woodDark = new THREE.MeshStandardMaterial({ color: 0x6a4528, roughness: 0.56, metalness: 0.03 });
    const glass = new THREE.MeshStandardMaterial({ color: 0x243b3f, roughness: 0.06, metalness: 0.95, emissive: 0x3f6f70, emissiveIntensity: 0.42 });
    const accent = new THREE.MeshStandardMaterial({ color: 0xc9a05c, roughness: 0.35, metalness: 0.85 });

    // receiver, bolt housing and trigger group
    const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.084, 0.1, 0.32), metal);
    receiver.position.set(0, 0.005, 0.015);
    this.weapon.add(receiver);
    const raceway = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.34, 12), darkMetal);
    raceway.rotation.x = Math.PI / 2;
    raceway.position.set(0, 0.045, -0.01);
    this.weapon.add(raceway);
    const triggerGuard = new THREE.Mesh(new THREE.TorusGeometry(0.04, 0.007, 6, 10, Math.PI), metal);
    triggerGuard.rotation.set(0, 0, Math.PI);
    triggerGuard.position.set(0, -0.078, 0.06);
    this.weapon.add(triggerGuard);
    const trigger = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.006, 0.05, 6), accent);
    trigger.position.set(0, -0.06, 0.06);
    this.weapon.add(trigger);

    // stock with comb, grip and recoil pad
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.082, 0.115, 0.4), wood);
    stock.position.set(0, -0.03, 0.35);
    stock.rotation.x = -0.13;
    this.weapon.add(stock);
    const comb = new THREE.Mesh(new THREE.BoxGeometry(0.076, 0.055, 0.24), woodDark);
    comb.position.set(0, 0.03, 0.27);
    this.weapon.add(comb);
    const pad = new THREE.Mesh(new THREE.BoxGeometry(0.086, 0.16, 0.055), darkMetal);
    pad.position.set(0, -0.075, 0.55);
    pad.rotation.x = -0.13;
    this.weapon.add(pad);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.15, 0.085), woodDark);
    grip.position.set(0, -0.1, 0.16);
    grip.rotation.x = 0.18;
    this.weapon.add(grip);

    // fore-end and barrel
    const fore = new THREE.Mesh(new THREE.BoxGeometry(0.078, 0.082, 0.35), wood);
    fore.position.set(0, -0.012, -0.29);
    this.weapon.add(fore);
    const foreTip = new THREE.Mesh(new THREE.BoxGeometry(0.082, 0.05, 0.06), accent);
    foreTip.position.set(0, -0.005, -0.465);
    this.weapon.add(foreTip);
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.0145, 0.021, 0.78, 12), darkMetal);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.028, -0.74);
    this.weapon.add(barrel);
    const brake = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.021, 0.085, 10), metal);
    brake.rotation.x = Math.PI / 2;
    brake.position.set(0, 0.028, -1.13);
    this.weapon.add(brake);
    const brakeSlot = new THREE.Mesh(new THREE.BoxGeometry(0.056, 0.016, 0.03), darkMetal);
    brakeSlot.position.set(0, 0.028, -1.135);
    this.weapon.add(brakeSlot);

    // bolt handle
    const boltArm = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.009, 0.11, 8), metal);
    boltArm.rotation.z = Math.PI / 2;
    boltArm.position.set(0.06, 0.018, 0.07);
    this.weapon.add(boltArm);
    const boltKnob = new THREE.Mesh(new THREE.SphereGeometry(0.022, 10, 8), darkMetal);
    boltKnob.position.set(0.115, 0.018, 0.07);
    this.weapon.add(boltKnob);

    // optic with mounts, objective bell and turret
    for (const z of [-0.09, 0.1]) {
      const mount = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.085, 0.03), darkMetal);
      mount.position.set(0, 0.105, z);
      this.weapon.add(mount);
    }
    const scopeBody = new THREE.Mesh(new THREE.CylinderGeometry(0.043, 0.043, 0.3, 14), darkMetal);
    scopeBody.rotation.x = Math.PI / 2;
    scopeBody.position.set(0, 0.155, 0.0);
    this.weapon.add(scopeBody);
    const objective = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.052, 0.09, 14), metal);
    objective.rotation.x = Math.PI / 2;
    objective.position.set(0, 0.155, -0.185);
    this.weapon.add(objective);
    const ocular = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.05, 0.07, 14), darkMetal);
    ocular.rotation.x = Math.PI / 2;
    ocular.position.set(0, 0.155, 0.175);
    this.weapon.add(ocular);
    const lens = new THREE.Mesh(new THREE.CircleGeometry(0.05, 16), glass);
    lens.position.set(0, 0.155, -0.232);
    lens.rotation.y = Math.PI;
    this.weapon.add(lens);
    const rearLens = new THREE.Mesh(new THREE.CircleGeometry(0.038, 14), glass);
    rearLens.position.set(0, 0.155, 0.212);
    this.weapon.add(rearLens);
    const turret = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.028, 0.035, 10), metal);
    turret.position.set(0, 0.212, 0.0);
    this.weapon.add(turret);
    const sideTurret = new THREE.Mesh(new THREE.CylinderGeometry(0.021, 0.023, 0.03, 10), metal);
    sideTurret.rotation.z = Math.PI / 2;
    sideTurret.position.set(0.052, 0.155, 0.0);
    this.weapon.add(sideTurret);

    this.weapon.position.set(0.3, -0.33, -0.62);
    this.weapon.rotation.set(0.075, 0.13, -0.025);
    this.weapon.scale.setScalar(0.88);
    this.weapon.traverse((child) => {
      child.castShadow = false;
      child.receiveShadow = false;
    });
    this.camera.add(this.weapon);
    this.weapon.visible = false;

    const c = document.createElement("canvas");
    c.width = c.height = 64;
    const ctx = c.getContext("2d");
    if (ctx) {
      const g = ctx.createRadialGradient(32, 32, 1, 32, 32, 32);
      g.addColorStop(0, "rgba(255,255,230,1)");
      g.addColorStop(0.25, "rgba(255,221,150,0.95)");
      g.addColorStop(0.6, "rgba(255,164,75,0.45)");
      g.addColorStop(1, "rgba(255,140,50,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 64, 64);
    }
    this.flashTexture = new THREE.CanvasTexture(c);
    const flashMat = new THREE.SpriteMaterial({ map: this.flashTexture, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, fog: false });
    this.muzzle = new THREE.Sprite(flashMat);
    this.muzzle.position.set(0, 0.028, -1.2);
    this.muzzle.scale.setScalar(0.27);
    this.muzzle.visible = false;
    this.weapon.add(this.muzzle);
    this.muzzleLight.position.set(0.2, -0.1, -0.9);
    this.muzzleLight.intensity = 0;
    this.camera.add(this.muzzleLight);

    const weaponLight = new THREE.PointLight(0xffe6bf, 2.4, 3.4, 2);
    weaponLight.position.set(0.15, 0.05, 0.45);
    this.camera.add(weaponLight);
    const rimLight = new THREE.PointLight(0xa7c9c4, 1.1, 3, 2);
    rimLight.position.set(-0.35, -0.15, -0.2);
    this.camera.add(rimLight);
  }

  /* --------------------------------- events --------------------------------- */

  private bindEvents() {
    this.canvas.addEventListener("pointerdown", this.onPointerDown);
    this.canvas.addEventListener("pointermove", this.onPointerMove);
    this.canvas.addEventListener("pointerup", this.onPointerUp);
    this.canvas.addEventListener("pointercancel", this.onPointerUp);
    this.canvas.addEventListener("contextmenu", this.onContextMenu);
    this.canvas.addEventListener("wheel", this.onWheel, { passive: true });
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(this.canvas);
    window.addEventListener("resize", this.resize);
  }

  private onContextMenu = (e: Event) => e.preventDefault();

  private onWheel = (e: WheelEvent) => {
    if (this.mode !== "hunting" || this.paused) return;
    this.targetPitch = clamp(this.targetPitch - e.deltaY * 0.00015, -0.85, 0.65);
  };

  private onPointerDown = (e: PointerEvent) => {
    if (this.mode !== "hunting" || this.paused) return;
    if (e.pointerType === "mouse" && e.button === 2) {
      this.setAimInternal(!this.aiming);
      return;
    }
    if (e.pointerType === "mouse" && e.button !== 0) return;
    this.dragging = true;
    this.dragMoved = 0;
    this.dragStart = performance.now();
    this.lastPointer = { x: e.clientX, y: e.clientY };
    this.canvas.setPointerCapture(e.pointerId);
  };

  private onPointerMove = (e: PointerEvent) => {
    if (!this.dragging || this.mode !== "hunting" || this.paused) return;
    const dx = e.clientX - this.lastPointer.x;
    const dy = e.clientY - this.lastPointer.y;
    this.lastPointer = { x: e.clientX, y: e.clientY };
    this.dragMoved += Math.abs(dx) + Math.abs(dy);
    const sensitivity = (this.aiming ? 0.00085 : 0.00215) * this.lookSensitivity;
    this.targetYaw -= dx * sensitivity;
    this.targetPitch = clamp(this.targetPitch - dy * sensitivity, -0.85, 0.65);
  };

  private onPointerUp = (e: PointerEvent) => {
    if (!this.dragging) return;
    const quick = performance.now() - this.dragStart < 380;
    const still = this.dragMoved < 7;
    this.dragging = false;
    if (this.mode === "hunting" && !this.paused && quick && still && e.button === 0) {
      this.fire();
    }
  };

  private onKeyDown = (e: KeyboardEvent) => {
    if (this.mode !== "hunting") return;
    const code = e.code;
    if (["KeyW", "KeyA", "KeyS", "KeyD", "Space", "ShiftLeft", "ShiftRight", "KeyR"].includes(code)) {
      if (e.target instanceof HTMLElement && ["INPUT", "TEXTAREA", "SELECT"].includes(e.target.tagName)) return;
      e.preventDefault();
    }
    this.keys.add(code);
    if (code === "Space" && !this.paused) this.fire();
    if (code === "KeyR" && !this.paused) this.reload();
    if ((code === "ShiftLeft" || code === "ShiftRight") && !this.paused) this.setAimInternal(true);
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
    if (e.code === "ShiftLeft" || e.code === "ShiftRight") this.setAimInternal(false);
  };

  private onBlur = () => {
    this.keys.clear();
  };

  private resize = () => {
    const width = Math.max(1, this.canvas.clientWidth || window.innerWidth);
    const height = Math.max(1, this.canvas.clientHeight || window.innerHeight);
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
  };

  /* ---------------------------------- api ---------------------------------- */

  private emitAmmo() {
    this.callbacks.onAmmo(this.magazine, this.reserve);
  }

  private setAimInternal(value: boolean) {
    if (this.aiming === value || this.reloading) return;
    this.aiming = value;
    this.callbacks.onAim(value);
  }

  setMode(mode: WorldMode) {
    if (mode === this.mode) return;
    if (mode === "hunting") {
      this.introPos.copy(this.camera.position);
      this.introQuat.copy(this.camera.quaternion);
      this.intro = 1.15;
      this.mode = "hunting";
      this.targetYaw = this.yaw = -0.04;
      this.targetPitch = this.pitch = -0.06;
      this.weapon.visible = true;
      this.setAimInternal(false);
      this.emitAmmo();
    } else {
      this.mode = "landing";
      this.aiming = false;
      this.dragging = false;
      this.weapon.visible = false;
      this.keys.clear();
      this.callbacks.onAim(false);
    }
  }

  setPaused(paused: boolean) {
    this.paused = paused;
    if (paused) {
      this.keys.clear();
      this.dragging = false;
      this.weapon.visible = false;
    } else if (this.mode === "hunting") {
      this.weapon.visible = !this.aiming;
    }
  }

  setLoadout(loadout: LoadoutSpec) {
    this.loadout = loadout;
    this.magazine = loadout.magazine;
    this.reserve = loadout.reserve;
    this.reloading = false;
    this.emitAmmo();
  }

  setInfiniteAmmo(value: boolean) {
    this.infiniteAmmo = value;
    if (value) {
      this.magazine = this.loadout.magazine;
      this.reserve = this.loadout.reserve;
      this.reloading = false;
      this.callbacks.onReload(false);
    }
    this.emitAmmo();
  }

  setMap(id: MapId) {
    if (this.mapId === id) {
      this.applyMap(id);
      return;
    }
    this.applyMap(id);
  }

  setAim(value: boolean) {
    this.setAimInternal(value);
  }

  toggleAim() {
    this.setAimInternal(!this.aiming);
    return this.aiming;
  }

  setMove(code: string, active: boolean) {
    if (this.mode !== "hunting" || this.paused) return;
    if (active) this.keys.add(code);
    else this.keys.delete(code);
  }

  setMoveAxes(x: number, y: number) {
    this.moveAxes.set(clamp(x, -1, 1), clamp(y, -1, 1));
  }

  setLookSensitivity(value: number) {
    this.lookSensitivity = clamp(value, 0.4, 2.2);
  }

  /**
   * Restore the herd and place a fresh drive around the hunter.
   * Called by the assignment director at the start of each wave.
   */
  beginWave(index: number, population: number) {
    this.wavesActive = true;
    const scaled = this.isMobile ? Math.round(population * 0.72) : population;
    const count = clamp(scaled, 8, this.animals.length);
    const placed: THREE.Vector3[] = [];
    const spread = Math.min(0.5 + index * 0.1, 0.95);
    this.animals.forEach((animal, i) => {
      animal.active = i < count;
      animal.group.visible = animal.active;
      if (!animal.active) {
        animal.alive = false;
        return;
      }
      this.restoreAnimal(animal);
      this.placeAnimal(animal, 26 + (index % 2) * 6, 92, spread, placed);
      animal.speed = animal.baseSpeed * (1 + index * 0.08);
      animal.pauseFor = 0.4 + Math.random() * 2.4;
      animal.fleeFor = 0;
    });
    this.callbacks.onSpotted([]);
    this.lastSpotted = "";
    this.lastTarget = "";
  }

  private restoreAnimal(animal: Animal) {
    animal.alive = true;
    animal.deadFor = 0;
    animal.hiddenFor = 0;
    animal.group.visible = true;
    animal.group.rotation.set(0, Math.random() * Math.PI * 2, 0);
    animal.heading = animal.group.rotation.y;
    animal.phase = Math.random() * Math.PI * 2;
  }

  private placeAnimal(animal: Animal, minDist: number, maxDist: number, spread: number, placed: THREE.Vector3[]) {
    let chosen: THREE.Vector3 | null = null;
    for (let attempt = 0; attempt < 34; attempt++) {
      const angle = this.yaw + (Math.random() - 0.5) * Math.PI * 2 * spread;
      const dist = minDist + Math.random() * (maxDist - minDist);
      const x = clamp(this.player.x - Math.sin(angle) * dist, -92, 92);
      const z = clamp(this.player.z - Math.cos(angle) * dist, -88, 92);
      const y = heightAt(x, z);
      if (y < 0.2) continue;
      if (Math.hypot(x - LAKE.x, z - LAKE.z) < 33) continue;
      const candidate = new THREE.Vector3(x, y, z);
      if (placed.some((point) => point.distanceToSquared(candidate) < 42)) continue;
      chosen = candidate;
      break;
    }
    if (!chosen) {
      const x = clamp(animal.spawn.x + (Math.random() - 0.5) * 6, -88, 88);
      const z = clamp(animal.spawn.z + (Math.random() - 0.5) * 6, -84, 88);
      chosen = new THREE.Vector3(x, heightAt(x, z), z);
    }
    animal.group.position.copy(chosen);
    animal.group.rotation.set(0, Math.random() * Math.PI * 2, 0);
    animal.heading = animal.group.rotation.y;
    const wanderX = clamp(chosen.x + (Math.random() - 0.5) * 18, -90, 90);
    const wanderZ = clamp(chosen.z + (Math.random() - 0.5) * 18, -86, 90);
    animal.waypoint.set(wanderX, heightAt(wanderX, wanderZ), wanderZ);
    placed.push(new THREE.Vector3(chosen.x, 0, chosen.z));
  }

  reload() {
    if (this.mode !== "hunting" || this.paused || this.reloading) return;
    if (this.magazine >= this.loadout.magazine || (this.reserve <= 0 && !this.infiniteAmmo)) return;
    this.reloading = true;
    this.reloadTimer = 1.65;
    this.callbacks.onReload(true);
  }

  fire() {
    if (this.mode !== "hunting" || this.paused) return;
    if (this.reloading || this.fireCooldown > 0) return;
    if (this.magazine <= 0 && !this.infiniteAmmo) {
      this.callbacks.onEmpty();
      this.fireCooldown = 0.3;
      return;
    }
    if (this.infiniteAmmo) {
      this.magazine = this.loadout.magazine;
      this.reserve = this.loadout.reserve;
    } else {
      this.magazine -= 1;
    }
    this.fireCooldown = 0.78;
    this.recoil = 1;
    this.muzzleTimer = 0.075;
    this.muzzle.visible = true;
    this.muzzleLight.intensity = 5;
    this.callbacks.onFlash?.();
    this.emitAmmo();

    this.raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
    this.raycaster.far = 500;
    const aliveGroups = this.animals.filter((a) => a.alive && a.active && a.group.visible).map((a) => a.group);
    const intersections = this.raycaster.intersectObjects(aliveGroups, true);
    const target = intersections.find((hit) => hit.object.visible);
    this.triggerFlee(this.camera.position);

    if (!target) {
      this.callbacks.onShot({ hit: false });
      return;
    }

    let node: THREE.Object3D | null = target.object;
    let part = "body";
    while (node) {
      if (node.userData.part) {
        part = node.userData.part as string;
        break;
      }
      node = node.parent;
    }
    const animal = (target.object.userData.animal as Animal | undefined) ?? (node?.userData.animal as Animal | undefined);
    if (!animal || !animal.alive) {
      this.callbacks.onShot({ hit: false });
      return;
    }
    animal.alive = false;
    animal.deadFor = 0;
    animal.hiddenFor = 0;
    animal.fleeFor = 0;
    const headshot = part === "head";
    const data = speciesByKey[animal.key];
    const distance = target.distance;
    const points = data.points + (headshot ? 60 : 0) + Math.round(distance * 0.35);
    this.callbacks.onShot({
      hit: true,
      species: animal.key,
      speciesName: data.name,
      points,
      distance,
      headshot,
    });
  }

  resetHunt(silent = false) {
    this.player.set(0, 0, 66);
    this.yaw = -0.05;
    this.pitch = -0.07;
    this.targetYaw = -0.05;
    this.targetPitch = -0.07;
    this.magazine = this.loadout.magazine;
    this.reserve = this.loadout.reserve;
    this.reloading = false;
    this.aiming = false;
    this.recoil = 0;
    this.fireCooldown = 0;
    this.reloadTimer = 0;
    this.keys.clear();
    this.moveAxes.set(0, 0);
    this.wavesActive = false;
    const random = rng(5150);
    for (const animal of this.animals) {
      animal.alive = true;
      animal.active = true;
      animal.speed = animal.baseSpeed;
      animal.deadFor = 0;
      animal.hiddenFor = 0;
      animal.fleeFor = 0;
      animal.pauseFor = random() * 2;
      animal.phase = random() * 6;
      animal.group.visible = true;
      animal.group.rotation.set(0, random() * Math.PI * 2, 0);
      const px = animal.spawn.x + (random() - 0.5) * 6;
      const pz = animal.spawn.z + (random() - 0.5) * 6;
      animal.group.position.set(px, heightAt(px, pz), pz);
      animal.heading = animal.group.rotation.y;
      animal.waypoint.copy(animal.group.position);
    }
    this.callbacks.onReload(false);
    this.callbacks.onTarget(null);
    this.callbacks.onSpotted([]);
    if (!silent) this.emitAmmo();
  }

  /* --------------------------------- updates -------------------------------- */

  private triggerFlee(origin: THREE.Vector3) {
    for (const animal of this.animals) {
      if (!animal.alive) continue;
      const d = animal.group.position.distanceTo(origin);
      if (d < 70) {
        animal.fleeFor = 4.5 + Math.random() * 3;
        const away = animal.group.position.clone().sub(this.camera.position).setY(0);
        if (away.lengthSq() < 0.001) away.set(1, 0, 0);
        away.normalize().multiplyScalar(16 + Math.random() * 8);
        const nx = clamp(animal.group.position.x + away.x, -85, 85);
        const nz = clamp(animal.group.position.z + away.z, -85, 90);
        animal.waypoint.set(nx, heightAt(nx, nz), nz);
      }
    }
  }

  private updateLanding(dt: number) {
    const t = this.elapsed;
    const x = 16 + Math.sin(t * 0.07) * 1.7;
    const z = 82 + Math.cos(t * 0.05) * 1.1;
    this.camera.position.set(x, heightAt(x, z) + 6.4 + Math.sin(t * 0.13) * 0.18, z);
    this.camera.lookAt(2 + Math.sin(t * 0.035) * 2.5, 3.4, -52);
    if (Math.abs(this.camera.fov - 53) > 0.01) {
      this.camera.fov += (53 - this.camera.fov) * Math.min(1, dt * 4);
      this.camera.updateProjectionMatrix();
    }
  }

  private updateHunt(dt: number) {
    const aimSpeed = this.aiming ? 0.52 : 1;
    const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    const move = new THREE.Vector3();
    if (this.keys.has("KeyW")) move.add(forward);
    if (this.keys.has("KeyS")) move.sub(forward);
    if (this.keys.has("KeyD")) move.add(right);
    if (this.keys.has("KeyA")) move.sub(right);
    if (Math.abs(this.moveAxes.x) > 0.06 || Math.abs(this.moveAxes.y) > 0.06) {
      move.addScaledVector(forward, this.moveAxes.y);
      move.addScaledVector(right, this.moveAxes.x);
    }
    this.moving = move.lengthSq() > 0.001 && !this.paused;
    if (this.moving) {
      move.normalize().multiplyScalar(dt * 6.2 * aimSpeed * (this.moveAxes.length() > 0.1 ? Math.min(1, this.moveAxes.length()) : 1));
      const nextX = clamp(this.player.x + move.x, -92, 92);
      const nextZ = clamp(this.player.z + move.z, -90, 92);
      if (heightAt(nextX, nextZ) > WATER_Y + 0.25) {
        this.player.x = nextX;
        this.player.z = nextZ;
      }
      this.walkPhase += dt * (this.aiming ? 5 : 8.5);
    } else {
      this.walkPhase += dt * 1.4;
    }

    this.yaw += (this.targetYaw - this.yaw) * Math.min(1, dt * 14);
    this.pitch += (this.targetPitch - this.pitch) * Math.min(1, dt * 14);
    if (this.fireCooldown > 0) this.fireCooldown = Math.max(0, this.fireCooldown - dt);
    if (this.recoil > 0) this.recoil = Math.max(0, this.recoil - dt * 5.5);

    if (this.reloading) {
      this.reloadTimer -= dt;
      if (this.reloadTimer <= 0) {
        const needed = this.loadout.magazine - this.magazine;
        const loaded = this.infiniteAmmo ? needed : Math.min(needed, this.reserve);
        this.magazine += loaded;
        this.reserve = this.infiniteAmmo ? this.loadout.reserve : this.reserve - loaded;
        this.reloading = false;
        this.callbacks.onReload(false);
        this.emitAmmo();
      }
    }

    if (this.muzzleTimer > 0) {
      this.muzzleTimer -= dt;
      if (this.muzzleTimer <= 0) {
        this.muzzle.visible = false;
        this.muzzleLight.intensity = 0;
      }
    }

    const ground = heightAt(this.player.x, this.player.z);
    const bobAmount = this.moving ? 0.055 : 0.013;
    const bob = Math.sin(this.walkPhase) * bobAmount;
    const targetPos = new THREE.Vector3(this.player.x, ground + 1.72 + bob, this.player.z);
    const desiredFov = this.aiming ? this.loadout.zoomFov : 58;
    if (Math.abs(this.camera.fov - desiredFov) > 0.02) {
      this.camera.fov += (desiredFov - this.camera.fov) * Math.min(1, dt * 11);
      this.camera.updateProjectionMatrix();
    }

    this.desired.rotation.order = "YXZ";
    this.desired.rotation.set(this.pitch + this.recoil * 0.045, this.yaw, 0);
    this.desired.updateMatrix();
    const targetQuat = this.desired.quaternion.clone();

    if (this.intro > 0) {
      this.intro = Math.max(0, this.intro - dt);
      const t = easeInOut(1 - this.intro / 1.15);
      this.camera.position.lerpVectors(this.introPos, targetPos, t);
      this.camera.quaternion.slerpQuaternions(this.introQuat, targetQuat, t);
    } else {
      this.camera.position.copy(targetPos);
      this.camera.quaternion.copy(targetQuat);
    }

    this.weapon.visible = !this.aiming && !this.paused;
    const sway = Math.sin(this.elapsed * 1.6) * 0.006 + Math.sin(this.walkPhase * 0.5) * (this.moving ? 0.013 : 0.003);
    const swayY = Math.cos(this.elapsed * 1.2) * 0.004 + Math.abs(Math.sin(this.walkPhase * 0.5)) * (this.moving ? 0.018 : 0.004);
    const reloadDip = this.reloading ? 0.22 : 0;
    const targetWeapon = new THREE.Vector3(0.3 + sway, -0.33 - swayY - reloadDip, -0.62 + this.recoil * 0.1);
    this.weapon.position.lerp(targetWeapon, Math.min(1, dt * 12));
    const recoilRot = this.recoil * 0.13;
    this.weapon.rotation.x += (0.04 + recoilRot + (this.reloading ? 0.22 : 0) - this.weapon.rotation.x) * Math.min(1, dt * 12);
    this.weapon.rotation.z += (-0.03 + (this.reloading ? -0.35 : 0) - this.weapon.rotation.z) * Math.min(1, dt * 8);

    if (Math.floor(this.elapsed * 10) % 2 === 0) {
      const deg = ((-this.yaw * 180) / Math.PI + 360) % 360;
      if (Math.abs(deg - this.lastHeading) > 0.8) {
        this.lastHeading = deg;
        this.callbacks.onHeading(deg);
      }
    }

    this.targetTimer -= dt;
    if (this.targetTimer <= 0) {
      this.targetTimer = 0.12;
      this.detectTarget();
    }
    this.spottedTimer -= dt;
    if (this.spottedTimer <= 0) {
      this.spottedTimer = 0.8;
      this.detectSpotted();
    }
  }

  private detectTarget() {
    this.raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
    this.raycaster.far = 460;
    const groups = this.animals.filter((a) => a.alive && a.active && a.group.visible).map((a) => a.group);
    const hits = this.raycaster.intersectObjects(groups, true);
    const hit = hits[0];
    if (!hit) {
      if (this.lastTarget !== "") {
        this.lastTarget = "";
        this.callbacks.onTarget(null);
      }
      return;
    }
    let node: THREE.Object3D | null = hit.object;
    let part = "body";
    while (node) {
      if (node.userData.part) {
        part = node.userData.part as string;
        break;
      }
      node = node.parent;
    }
    const animal = hit.object.userData.animal as Animal | undefined;
    if (!animal) return;
    const info: TargetInfo = {
      key: animal.key,
      name: speciesByKey[animal.key].name,
      distance: Math.round(hit.distance),
      headshot: part === "head",
    };
    const serial = `${info.key}-${Math.round(info.distance / 5)}-${info.headshot}`;
    if (serial !== this.lastTarget) {
      this.lastTarget = serial;
      this.callbacks.onTarget(info);
    }
  }

  private detectSpotted() {
    const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
    const spotted = new Set<SpeciesKey>();
    for (const animal of this.animals) {
      if (!animal.alive) continue;
      const to = animal.group.position.clone().add(new THREE.Vector3(0, 1, 0)).sub(this.camera.position);
      const dist = to.length();
      if (dist > 175) continue;
      to.normalize();
      if (to.dot(forward) > 0.68) spotted.add(animal.key);
    }
    const list = Array.from(spotted).sort();
    const serial = list.join(",");
    if (serial !== this.lastSpotted) {
      this.lastSpotted = serial;
      this.callbacks.onSpotted(list);
    }
  }

  private updateAnimals(dt: number) {
    for (const animal of this.animals) {
      if (!animal.active) {
        if (animal.group.visible) animal.group.visible = false;
        continue;
      }
      if (!animal.alive) {
        animal.deadFor += dt;
        animal.group.rotation.z = lerp(animal.group.rotation.z, 1.46, Math.min(1, dt * 4));
        animal.group.position.y = lerp(animal.group.position.y, heightAt(animal.group.position.x, animal.group.position.z) + 0.15, Math.min(1, dt * 3));
        if (animal.deadFor > 8) {
          animal.hiddenFor += dt;
          if (animal.group.visible) animal.group.visible = false;
          if (animal.hiddenFor > 16 && !this.wavesActive) {
            const random = Math.random;
            const angle = random() * Math.PI * 2;
            const dist = 55 + random() * 45;
            const nx = clamp(Math.cos(angle) * dist, -88, 88);
            const nz = clamp(Math.sin(angle) * dist - 5, -85, 88);
            animal.group.position.set(nx, heightAt(nx, nz), nz);
            animal.group.rotation.set(0, random() * Math.PI * 2, 0);
            animal.heading = animal.group.rotation.y;
            animal.group.visible = true;
            animal.alive = true;
            animal.deadFor = 0;
            animal.hiddenFor = 0;
            animal.waypoint.copy(animal.group.position);
            animal.pauseFor = 1 + random() * 2;
          }
        }
        continue;
      }

      const distanceToPlayer = animal.group.position.distanceTo(this.camera.position);
      if (distanceToPlayer < 17 && this.mode === "hunting" && animal.fleeFor <= 0 && animal.key !== "boar") {
        animal.fleeFor = 2 + Math.random() * 2;
        const away = animal.group.position.clone().sub(this.camera.position).setY(0).normalize().multiplyScalar(12);
        const nx = clamp(animal.group.position.x + away.x, -88, 88);
        const nz = clamp(animal.group.position.z + away.z, -88, 88);
        animal.waypoint.set(nx, heightAt(nx, nz), nz);
      }

      animal.phase += dt * (2.4 + animal.speed);
      if (animal.pauseFor > 0) {
        animal.pauseFor -= dt;
        animal.bob = Math.sin(this.elapsed * 1.5 + animal.phase) * 0.015;
        animal.group.position.y = heightAt(animal.group.position.x, animal.group.position.z) + Math.max(0, animal.bob);
        this.updateLegs(animal, 0.06, dt);
      } else {
        if (animal.fleeFor > 0) animal.fleeFor -= dt;
        const speed = animal.speed * (animal.fleeFor > 0 ? 2.5 : 1);
        const to = animal.waypoint.clone().sub(animal.group.position).setY(0);
        if (to.length() < 1.2) {
          const angle = Math.random() * Math.PI * 2;
          const radius = 4 + Math.random() * 11;
          const nx = clamp(animal.group.position.x + Math.cos(angle) * radius, -88, 88);
          const nz = clamp(animal.group.position.z + Math.sin(angle) * radius, -88, 88);
          animal.waypoint.set(nx, heightAt(nx, nz), nz);
          if (Math.random() < 0.3 && animal.fleeFor <= 0) animal.pauseFor = 1.5 + Math.random() * 3;
        } else {
          to.normalize();
          const step = Math.min(speed * dt, 0.4);
          const nx = animal.group.position.x + to.x * step;
          const nz = animal.group.position.z + to.z * step;
          if (heightAt(nx, nz) > 0.05) {
            animal.group.position.x = nx;
            animal.group.position.z = nz;
          } else {
            animal.waypoint.set(animal.spawn.x, animal.spawn.z, 0);
          }
          const targetHeading = Math.atan2(to.x, to.z);
          let diff = targetHeading - animal.heading;
          while (diff > Math.PI) diff -= Math.PI * 2;
          while (diff < -Math.PI) diff += Math.PI * 2;
          animal.heading += diff * Math.min(1, dt * 4);
          animal.group.rotation.y = animal.heading;
        }
        animal.group.position.y = heightAt(animal.group.position.x, animal.group.position.z);
        const amp = animal.key === "hare" ? 0.55 : 0.34;
        this.updateLegs(animal, amp, dt);
        if (animal.key === "hare") {
          animal.group.position.y += Math.abs(Math.sin(animal.phase * 1.2)) * 0.22;
        }
      }
    }
  }

  private updateLegs(animal: Animal, amp: number, dt: number) {
    if (animal.legPivots.length === 0) return;
    animal.legPivots.forEach((pivot, i) => {
      const offset = i < 2 ? 0 : Math.PI;
      const target = Math.sin(animal.phase + offset) * amp;
      pivot.rotation.x += (target - pivot.rotation.x) * Math.min(1, dt * 14);
    });
  }

  private updateAmbient(dt: number) {
    const t = this.elapsed;
    if (this.water) {
      this.water.position.y = WATER_Y + Math.sin(t * 0.6) * 0.02;
    }
    if (this.dust) {
      this.dust.rotation.y += dt * 0.005;
      this.dust.position.y = Math.sin(t * 0.15) * 0.6;
    }
    if (this.snow?.visible) {
      const positions = this.snow.geometry.getAttribute("position") as THREE.BufferAttribute;
      for (let i = 0; i < positions.count; i++) {
        const speed = this.snowSpeeds[i] ?? 1.6;
        let y = positions.getY(i) - speed * dt;
        let x = positions.getX(i) + Math.sin(t * 0.5 + i) * dt * 0.25;
        if (y < 0.2) {
          y = 58 + Math.random() * 14;
          x = (Math.random() - 0.5) * 190;
        }
        positions.setY(i, y);
        positions.setX(i, x);
      }
      positions.needsUpdate = true;
    }
    for (const bird of this.birds) {
      const angle = t * bird.speed + bird.phase;
      bird.group.position.set(Math.cos(angle) * bird.radius + 5, bird.height + Math.sin(t * 0.4 + bird.phase) * 2, Math.sin(angle) * bird.radius - 45);
      bird.group.rotation.y = -angle + Math.PI / 2;
      const flap = Math.sin(t * 5 + bird.phase) * 0.55;
      bird.wingL.rotation.z = flap;
      bird.wingR.rotation.z = -flap;
    }
  }

  private animate = () => {
    this.frame = requestAnimationFrame(this.animate);
    if (this.disposed) return;
    const raw = this.clock.getDelta();
    const dt = Math.min(raw, 0.05);
    this.elapsed += dt;

    if (this.mode === "landing") {
      this.updateLanding(dt);
    } else if (!this.paused) {
      this.updateHunt(dt);
    }

    if (this.mode === "landing" || !this.paused) {
      this.updateAnimals(dt);
      this.updateAmbient(dt);
    }
    this.renderer.render(this.scene, this.camera);
  };

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frame);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
    this.canvas.removeEventListener("pointerup", this.onPointerUp);
    this.canvas.removeEventListener("pointercancel", this.onPointerUp);
    this.canvas.removeEventListener("contextmenu", this.onContextMenu);
    this.canvas.removeEventListener("wheel", this.onWheel);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    window.removeEventListener("resize", this.resize);
    this.resizeObserver?.disconnect();
    this.scene.traverse((object) => {
      const mesh = object as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const material = mesh.material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(material)) material.forEach((m) => m.dispose());
      else material?.dispose();
    });
    this.flashTexture?.dispose();
    this.renderer.dispose();
  }
}
