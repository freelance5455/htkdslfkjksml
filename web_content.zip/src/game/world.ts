import * as THREE from "three";
import { ATLAS_COLS, ATLAS_ROWS, TILE, makeAtlasCanvas } from "./textures";

export const WORLD_SIZE = 128;
export const WORLD_HEIGHT = 48;
export const CHUNK = 16;
export const WATER_LEVEL = 18;

export interface BlockDef {
  id: number;
  name: string;
  top: number;
  side: number;
  bottom: number;
  solid: boolean;
  tint: [number, number, number];
  particle: string;
}

const T = (id: number): BlockDef => ({
  id,
  name: "",
  top: 0,
  side: 0,
  bottom: 0,
  solid: true,
  tint: [1, 1, 1],
  particle: "#888888",
});

export const BLOCKS: BlockDef[] = [
  { ...T(0), name: "Air", solid: false, particle: "#000000" },
  { ...T(1), name: "Grass Block", top: 0, side: 1, bottom: 2, particle: "#5f9e3d" },
  { ...T(2), name: "Dirt", top: 2, side: 2, bottom: 2, particle: "#8b5e3c" },
  { ...T(3), name: "Stone", top: 3, side: 3, bottom: 3, particle: "#8a8a8a" },
  { ...T(4), name: "Sand", top: 4, side: 4, bottom: 4, particle: "#e0cf9a" },
  { ...T(5), name: "Water", top: 5, side: 5, bottom: 5, solid: false, particle: "#3a6fd8" },
  { ...T(6), name: "Oak Log", top: 7, side: 6, bottom: 7, particle: "#6b4a2b" },
  { ...T(7), name: "Leaves", top: 8, side: 8, bottom: 8, particle: "#3f7a2f" },
  { ...T(8), name: "Oak Planks", top: 9, side: 9, bottom: 9, particle: "#b0854a" },
  { ...T(9), name: "Glass", top: 10, side: 10, bottom: 10, particle: "#bfe4f5" },
  { ...T(10), name: "Brick", top: 11, side: 11, bottom: 11, particle: "#a24b38" },
  { ...T(11), name: "Cobblestone", top: 12, side: 12, bottom: 12, particle: "#7d7d7d" },
  { ...T(12), name: "Asphalt", top: 13, side: 13, bottom: 13, particle: "#3a3a3e" },
  { ...T(13), name: "White Concrete", top: 14, side: 14, bottom: 14, particle: "#e8e8e8" },
  { ...T(14), name: "Slate Roof", top: 15, side: 15, bottom: 15, particle: "#4a4a58" },
  {
    ...T(15),
    name: "Gold Block",
    top: 14,
    side: 14,
    bottom: 14,
    tint: [1.0, 0.79, 0.29],
    particle: "#e8c24a",
  },
];

export function isSolid(id: number): boolean {
  return id !== 0 && BLOCKS[id] !== undefined && BLOCKS[id].solid;
}

/* ---------------- noise ---------------- */
function hash2(x: number, z: number): number {
  let n = Math.imul(x, 374761393) + Math.imul(z, 668265263);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967295;
}
function smooth(t: number) {
  return t * t * (3 - 2 * t);
}
function valueNoise(x: number, z: number): number {
  const xi = Math.floor(x);
  const zi = Math.floor(z);
  const u = smooth(x - xi);
  const v = smooth(z - zi);
  const a = hash2(xi, zi);
  const b = hash2(xi + 1, zi);
  const c = hash2(xi, zi + 1);
  const d = hash2(xi + 1, zi + 1);
  return a * (1 - u) * (1 - v) + b * u * (1 - v) + c * (1 - u) * v + d * u * v;
}
function fbm(x: number, z: number, oct = 4): number {
  let amp = 1;
  let freq = 1;
  let sum = 0;
  let norm = 0;
  for (let i = 0; i < oct; i++) {
    sum += valueNoise(x * freq, z * freq) * amp;
    norm += amp;
    amp *= 0.5;
    freq *= 2;
  }
  return sum / norm;
}

/* ---------------- world ---------------- */
export class World {
  data: Uint8Array;
  dirty = new Set<string>();

  constructor() {
    this.data = new Uint8Array(WORLD_SIZE * WORLD_HEIGHT * WORLD_SIZE);
  }

  index(x: number, y: number, z: number) {
    return (y * WORLD_SIZE + z) * WORLD_SIZE + x;
  }

  get(x: number, y: number, z: number): number {
    if (y < 0) return 3;
    if (y >= WORLD_HEIGHT || x < 0 || z < 0 || x >= WORLD_SIZE || z >= WORLD_SIZE) return 0;
    return this.data[this.index(x, y, z)];
  }

  set(x: number, y: number, z: number, v: number) {
    if (y < 0 || y >= WORLD_HEIGHT || x < 0 || z < 0 || x >= WORLD_SIZE || z >= WORLD_SIZE)
      return;
    this.data[this.index(x, y, z)] = v;
    const cx = Math.floor(x / CHUNK);
    const cz = Math.floor(z / CHUNK);
    this.dirty.add(`${cx},${cz}`);
    if (x % CHUNK === 0) this.dirty.add(`${cx - 1},${cz}`);
    if (x % CHUNK === CHUNK - 1) this.dirty.add(`${cx + 1},${cz}`);
    if (z % CHUNK === 0) this.dirty.add(`${cx},${cz - 1}`);
    if (z % CHUNK === CHUNK - 1) this.dirty.add(`${cx},${cz + 1}`);
  }

  /** First walkable surface Y at column (skips water/leaves). */
  heightAt(x: number, z: number): number {
    const xi = Math.floor(x);
    const zi = Math.floor(z);
    for (let y = WORLD_HEIGHT - 1; y >= 0; y--) {
      const id = this.get(xi, y, zi);
      if (id !== 0 && id !== 5 && id !== 7) return y + 1;
    }
    return WATER_LEVEL;
  }
}

export function generateWorld(): World {
  const w = new World();
  for (let x = 0; x < WORLD_SIZE; x++) {
    for (let z = 0; z < WORLD_SIZE; z++) {
      const base = fbm(x * 0.011, z * 0.011, 4);
      const detail = fbm(x * 0.055 + 40, z * 0.055 + 40, 2);
      const h = Math.max(4, Math.floor(13 + base * 27 + detail * 5));
      for (let y = 0; y <= Math.max(h, WATER_LEVEL); y++) {
        let id = 0;
        if (y < h - 4) id = 3;
        else if (y < h - 1) id = 2;
        else if (y === h - 1) id = h <= WATER_LEVEL + 1 ? 4 : 1;
        else if (y < WATER_LEVEL) id = 5;
        if (id !== 0) w.data[w.index(x, y, z)] = id;
      }
    }
  }
  // trees
  for (let x = 4; x < WORLD_SIZE - 4; x++) {
    for (let z = 4; z < WORLD_SIZE - 4; z++) {
      const r = hash2(x * 7 + 13, z * 13 + 7);
      if (r < 0.986) continue;
      const h = w.heightAt(x, z);
      if (h <= WATER_LEVEL + 1 || w.get(x, h - 1, z) !== 1) continue;
      const trunk = 4 + Math.floor(hash2(x, z) * 3);
      for (let y = 0; y < trunk; y++) w.data[w.index(x, h + y, z)] = 6;
      const top = h + trunk;
      for (let dx = -2; dx <= 2; dx++) {
        for (let dz = -2; dz <= 2; dz++) {
          for (let dy = -1; dy <= 2; dy++) {
            const dist = Math.abs(dx) + Math.abs(dz) + Math.abs(dy) * 1.4;
            if (dist > 3.6) continue;
            if (dx === 0 && dz === 0 && dy < 1) continue;
            if (w.get(x + dx, top + dy, z + dz) === 0) {
              w.data[w.index(x + dx, top + dy, z + dz)] = 7;
            }
          }
        }
      }
    }
  }
  return w;
}

/* ---------------- meshing ---------------- */
interface Face {
  dir: [number, number, number];
  corners: [number, number, number][];
  shade: number;
  tile: "top" | "side" | "bottom";
}

const FACES: Face[] = [
  {
    dir: [1, 0, 0],
    corners: [
      [1, 1, 1],
      [1, 0, 1],
      [1, 0, 0],
      [1, 1, 0],
    ],
    shade: 0.76,
    tile: "side",
  },
  {
    dir: [-1, 0, 0],
    corners: [
      [0, 1, 0],
      [0, 0, 0],
      [0, 0, 1],
      [0, 1, 1],
    ],
    shade: 0.76,
    tile: "side",
  },
  {
    dir: [0, 1, 0],
    corners: [
      [0, 1, 1],
      [1, 1, 1],
      [1, 1, 0],
      [0, 1, 0],
    ],
    shade: 1.0,
    tile: "top",
  },
  {
    dir: [0, -1, 0],
    corners: [
      [0, 0, 0],
      [1, 0, 0],
      [1, 0, 1],
      [0, 0, 1],
    ],
    shade: 0.5,
    tile: "bottom",
  },
  {
    dir: [0, 0, 1],
    corners: [
      [0, 1, 1],
      [0, 0, 1],
      [1, 0, 1],
      [1, 1, 1],
    ],
    shade: 0.88,
    tile: "side",
  },
  {
    dir: [0, 0, -1],
    corners: [
      [1, 1, 0],
      [1, 0, 0],
      [0, 0, 0],
      [0, 1, 0],
    ],
    shade: 0.88,
    tile: "side",
  },
];

const FACE_UV: [number, number][] = [
  [0, 1],
  [0, 0],
  [1, 0],
  [1, 1],
];

export function buildChunkGeometry(world: World, cx: number, cz: number): THREE.BufferGeometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const colors: number[] = [];
  const indices: number[] = [];

  const x0 = cx * CHUNK;
  const z0 = cz * CHUNK;

  for (let x = x0; x < x0 + CHUNK; x++) {
    for (let z = z0; z < z0 + CHUNK; z++) {
      for (let y = 0; y < WORLD_HEIGHT; y++) {
        const id = world.get(x, y, z);
        if (id === 0) continue;
        const def = BLOCKS[id];
        for (const face of FACES) {
          const nx = x + face.dir[0];
          const ny = y + face.dir[1];
          const nz = z + face.dir[2];
          const neighbour = world.get(nx, ny, nz);
          if (neighbour !== 0 && (neighbour === id || BLOCKS[neighbour]?.solid)) continue;

          const tileIndex =
            face.tile === "top" ? def.top : face.tile === "bottom" ? def.bottom : def.side;
          const col = tileIndex % ATLAS_COLS;
          const row = Math.floor(tileIndex / ATLAS_COLS);
          const u0 = col / ATLAS_COLS + 0.002;
          const u1 = (col + 1) / ATLAS_COLS - 0.002;
          const v0 = 1 - (row + 1) / ATLAS_ROWS + 0.002;
          const v1 = 1 - row / ATLAS_ROWS - 0.002;

          const base = positions.length / 3;
          for (let i = 0; i < 4; i++) {
            const c = face.corners[i];
            positions.push(x + c[0], y + c[1], z + c[2]);
            normals.push(face.dir[0], face.dir[1], face.dir[2]);
            const uv = FACE_UV[i];
            uvs.push(uv[0] === 0 ? u0 : u1, uv[1] === 0 ? v0 : v1);
            colors.push(
              def.tint[0] * face.shade,
              def.tint[1] * face.shade,
              def.tint[2] * face.shade,
            );
          }
          indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
        }
      }
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("normal", new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
  geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  geo.setIndex(indices);
  return geo;
}

export function createAtlasTexture(): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(makeAtlasCanvas());
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  void TILE;
  return tex;
}
