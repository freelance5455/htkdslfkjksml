// Procedural open world: road grid, districts, landmarks, vegetation and street props.
import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { makeRng, rand, randInt, pick, lerp, Rng } from './util';
import {
  asphaltTexture,
  concreteTexture,
  grassTexture,
  facadeTexture,
  leafTexture,
} from './textures';
import { LANDMARKS } from './items';

export const WORLD_SIZE = 1600;
export const BLOCK = 100;
export const ROAD_W = 18;
export const SIDEWALK_W = 5;

export interface Box3ish {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  top: number;
}

export interface Interactable {
  id: string;
  kind: 'enter' | 'mission' | 'pickup' | 'shop' | 'marker';
  x: number;
  z: number;
  label: string;
  radius: number;
  interior?: string;
}

export interface Landmark {
  id: string;
  name: string;
  x: number;
  z: number;
  w: number;
  d: number;
  h: number;
  color: number;
  icon: string;
  interior?: string;
}

export type Quality = 'low' | 'medium' | 'high';

const SHOP_NAMES = [
  'LUMEN COFFEE', 'CITY PHONE', 'VOLT ELECTRONICS', 'MOTO GARAGE', 'SUSHI KOI',
  'BLUE BOTTLE', 'URBAN OUTFITTERS', 'FRESH MART', 'PAWN & SONS', 'GOLD WATCH',
  'NOODLE HOUSE', 'SKY LOUNGE', 'TACOS EL SOL', 'HARDWARE DEPT', 'BOOK NOOK',
  'SUNSET DELI', 'AUTO PARTS', 'GYM ZONE', 'BAKERY 9', 'TECH HUB',
];
const TOWER_NAMES = [
  'AURELIA TOWER', 'NORTHPOINT', 'THE MERIDIAN', 'SKYLINE 12', 'VANTAGE',
  'CRESCENT HOUSE', 'ORION PLAZA', 'HARBOR CENTRE', 'GOLDEN HOUR', 'ZENITH',
];

export class World {
  group = new THREE.Group();
  colliders: Box3ish[] = [];
  private grid = new Map<string, Box3ish[]>();
  private cell = 60;
  landmarks: Landmark[] = [];
  buildingRects: { x: number; z: number; w: number; d: number }[] = [];
  interactables: Interactable[] = [];
  trees: THREE.InstancedMesh[] = [];
  grassMesh: THREE.InstancedMesh | null = null;
  roadMeshes: THREE.Mesh[] = [];
  sidewalkMat!: THREE.MeshStandardMaterial;
  roadMat!: THREE.MeshStandardMaterial;
  streetLampMat!: THREE.MeshStandardMaterial;
  foliageMat!: THREE.MeshStandardMaterial;
  trunkMat!: THREE.MeshStandardMaterial;
  shopSigns: THREE.Mesh[] = [];
  private windowMats: THREE.MeshStandardMaterial[] = [];
  private windMaterials: THREE.MeshStandardMaterial[] = [];
  private emissiveMats: THREE.MeshStandardMaterial[] = [];
  time = 0;

  constructor(public quality: Quality) {
    this.group.name = 'world';
  }

  // ---------------------------------------------------------------- helpers
  private addCollider(minX: number, minZ: number, maxX: number, maxZ: number, top = 8) {
    const b: Box3ish = { minX, maxX, minZ, maxZ, top };
    this.colliders.push(b);
    const i0 = Math.floor(minX / this.cell);
    const i1 = Math.floor(maxX / this.cell);
    const j0 = Math.floor(minZ / this.cell);
    const j1 = Math.floor(maxZ / this.cell);
    for (let i = i0; i <= i1; i++)
      for (let j = j0; j <= j1; j++) {
        const k = i + ',' + j;
        let arr = this.grid.get(k);
        if (!arr) {
          arr = [];
          this.grid.set(k, arr);
        }
        arr.push(b);
      }
  }

  collidersNear(x: number, z: number): Box3ish[] {
    const i = Math.floor(x / this.cell);
    const j = Math.floor(z / this.cell);
    const out: Box3ish[] = [];
    for (let di = -1; di <= 1; di++)
      for (let dj = -1; dj <= 1; dj++) {
        const arr = this.grid.get(i + di + ',' + (j + dj));
        if (arr) out.push(...arr);
      }
    return out;
  }

  district(x: number, z: number) {
    const ax = Math.abs(x);
    const az = Math.abs(z);
    if (az > 430 && ax < 420) return 'Verdant Park';
    if (ax < 330 && az < 330) return 'Solstice Downtown';
    if (ax > 420) return 'Ironside Industrial';
    if (az > 330) return 'Bayview Heights';
    if (ax > 300) return 'Eastgate Commons';
    if (az > 240) return 'Southbank';
    return 'Midtown Crossing';
  }

  // ---------------------------------------------------------------- build
  build() {
    const rng = makeRng(20240613);
    this.buildGround(rng);
    this.buildRoads(rng);
    this.buildBlocks(rng);
    this.buildParks(rng);
    this.buildLandmarks(rng);
    this.buildVegetation(rng);
    this.buildStreetProps(rng);
    this.updateWetness(0);
  }

  private buildGround(rng: Rng) {
    void rng;
    const grass = grassTexture();
    const groundMat = new THREE.MeshStandardMaterial({
      map: grass,
      roughness: 0.96,
      color: 0x9fbb84,
    });
    (groundMat.map as THREE.Texture).repeat.set(220, 220);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(WORLD_SIZE * 2.4, WORLD_SIZE * 2.4), groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.02;
    ground.receiveShadow = true;
    this.group.add(ground);

    // distant hills ring
    const hillMat = new THREE.MeshStandardMaterial({ color: 0x54703f, roughness: 1 });
    const hills: THREE.BufferGeometry[] = [];
    for (let i = 0; i < 90; i++) {
      const ang = (i / 90) * Math.PI * 2 + rng() * 0.05;
      const r = 1150 + rng() * 420;
      const g = new THREE.SphereGeometry(60 + rng() * 130, 8, 6);
      g.scale(1, 0.32 + rng() * 0.3, 1);
      g.translate(Math.sin(ang) * r, -12, Math.cos(ang) * r);
      hills.push(g);
    }
    const hillMesh = new THREE.Mesh(mergeGeometries(hills)!, hillMat);
    hillMesh.receiveShadow = false;
    this.group.add(hillMesh);
  }

  private buildRoads(rng: Rng) {
    void rng;
    const asphalt = asphaltTexture();
    const roadMat = new THREE.MeshStandardMaterial({
      map: asphalt,
      roughness: 0.88,
      metalness: 0.04,
      color: 0xbfbfbf,
    });
    (roadMat.map as THREE.Texture).repeat.set(90, 90);
    this.roadMat = roadMat;

    const marks: THREE.BufferGeometry[] = [];
    const half = WORLD_SIZE / 2;
    for (let i = -8; i <= 8; i++) {
      const p = i * BLOCK;
      const isMain = i % 2 === 0;
      const w = isMain ? ROAD_W + 6 : ROAD_W;
      // road surface
      const g = new THREE.PlaneGeometry(w, WORLD_SIZE);
      g.rotateX(-Math.PI / 2);
      g.translate(p, 0.01, 0);
      const m = new THREE.Mesh(g, roadMat);
      m.receiveShadow = true;
      this.group.add(m);
      this.roadMeshes.push(m);
      const g2 = new THREE.PlaneGeometry(WORLD_SIZE, w);
      g2.rotateX(-Math.PI / 2);
      g2.translate(0, 0.012, p);
      const m2 = new THREE.Mesh(g2, roadMat);
      m2.receiveShadow = true;
      this.group.add(m2);
      this.roadMeshes.push(m2);

      // dashed centre line
      const dashLen = 6;
      for (let d = -half; d < half; d += dashLen * 2) {
        const a = new THREE.PlaneGeometry(0.35, dashLen);
        a.rotateX(-Math.PI / 2);
        a.translate(p, 0.03, d + dashLen / 2);
        marks.push(a);
        const b = new THREE.PlaneGeometry(dashLen, 0.35);
        b.rotateX(-Math.PI / 2);
        b.translate(d + dashLen / 2, 0.031, p);
        marks.push(b);
      }
      // stop lines near intersections
      for (let j = -8; j <= 8; j++) {
        if (j === i) continue;
        const q = j * BLOCK;
        [[q - ROAD_W / 2 - 1.2, 0, 0], [q + ROAD_W / 2 + 1.2, 0, 0]].forEach(() => {});
        const sl = new THREE.PlaneGeometry(w - 1.5, 0.5);
        sl.rotateX(-Math.PI / 2);
        sl.translate(p, 0.032, q - ROAD_W / 2 - 1.4);
        marks.push(sl);
      }
    }
    const markMat = new THREE.MeshStandardMaterial({
      color: 0xf2f2e8,
      roughness: 0.7,
      emissive: 0x222222,
      emissiveIntensity: 0.2,
    });
    const markMesh = new THREE.Mesh(mergeGeometries(marks)!, markMat);
    markMesh.receiveShadow = true;
    this.group.add(markMesh);

    // sidewalks + curbs
    const swGeos: THREE.BufferGeometry[] = [];
    const curbMat = new THREE.MeshStandardMaterial({
      map: concreteTexture('#c9c6be'),
      roughness: 0.9,
    });
    (curbMat.map as THREE.Texture).repeat.set(40, 40);
    this.sidewalkMat = curbMat;
    for (let i = -8; i <= 8; i++) {
      const p = i * BLOCK;
      const off = (ROAD_W + (i % 2 === 0 ? 6 : 0)) / 2 + SIDEWALK_W / 2;
      [-1, 1].forEach((s) => {
        const a = new THREE.BoxGeometry(SIDEWALK_W, 0.22, WORLD_SIZE);
        a.translate(p + s * off, 0.1, 0);
        swGeos.push(a);
        const b = new THREE.BoxGeometry(WORLD_SIZE, 0.22, SIDEWALK_W);
        b.translate(0, 0.1, p + s * off);
        swGeos.push(b);
      });
    }
    const sw = new THREE.Mesh(mergeGeometries(swGeos)!, curbMat);
    sw.receiveShadow = true;
    sw.castShadow = false;
    this.group.add(sw);
  }

  private facadeVariant(i: number) {
    const walls = ['#b9b3a6', '#9ea3a8', '#c2b39c', '#8d9299', '#a89c8f', '#6f7784', '#cfc6b6', '#7d6f63'];
    const seed = 17 + i * 31;
    const { map, emissive } = facadeTexture(walls[i % walls.length], 4, 4, '#0d1219', seed);
    const mat = new THREE.MeshStandardMaterial({
      map,
      emissiveMap: emissive,
      emissive: 0xffffff,
      emissiveIntensity: 0.0,
      roughness: 0.82,
      metalness: 0.02,
    });
    const emat = new THREE.MeshStandardMaterial({
      map: emissive,
      emissive: 0xffffff,
      emissiveIntensity: 1,
      transparent: true,
      opacity: 0.999,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.windowMats.push(mat);
    this.emissiveMats.push(emat);
    return mat;
  }

  private buildBlocks(rng: Rng) {
    const variants = 8;
    const groups: THREE.BufferGeometry[][] = [];
    for (let i = 0; i < variants; i++) groups.push([]);
    const details: THREE.BufferGeometry[] = [];
    const glassGeos: THREE.BufferGeometry[] = [];
    const roofGeos: THREE.BufferGeometry[] = [];
    const awningGeos: THREE.BufferGeometry[] = [];
    const signList: { x: number; z: number; rot: number; name: string; color: string }[] = [];

    const N = 8;
    for (let bi = -N; bi < N; bi++) {
      for (let bj = -N; bj < N; bj++) {
        const cx = bi * BLOCK + BLOCK / 2;
        const cz = bj * BLOCK + BLOCK / 2;
        const d = this.district(cx, cz);
        const half = BLOCK / 2 - ROAD_W / 2 - SIDEWALK_W - 3;
        const inner = half - 2;

        if (d === 'Verdant Park') continue;
        let reserved = false;
        for (const lm of LANDMARKS) {
          if (lm.h > 0 && Math.abs(cx - lm.x) < lm.w / 2 + 26 && Math.abs(cz - lm.z) < lm.d / 2 + 26) {
            reserved = true;
            break;
          }
        }
        if (reserved) continue;

        const count = d === 'Solstice Downtown' ? 1 : d === 'Ironside Industrial' ? 1 : randInt(rng, 1, 3);
        for (let b = 0; b < count; b++) {
          const w = rand(rng, 22, inner * 1.1);
          const dp = rand(rng, 22, inner * 1.1);
          const ox = rand(rng, -inner + w / 2, inner - w / 2);
          const oz = rand(rng, -inner + dp / 2, inner - dp / 2);
          const x = cx + ox;
          const z = cz + oz;

          let h: number;
          let style = 'tower';
          if (d === 'Solstice Downtown') {
            h = rand(rng, 55, 145);
          } else if (d === 'Midtown Crossing' || d === 'Eastgate Commons') {
            h = rand(rng, 20, 58);
          } else if (d === 'Bayview Heights') {
            h = rand(rng, 14, 34);
            style = 'apt';
          } else if (d === 'Ironside Industrial') {
            h = rand(rng, 11, 18);
            style = 'warehouse';
          } else {
            h = rand(rng, 8, 16);
            style = 'house';
          }
          if (b > 0 && d !== 'Solstice Downtown') h = rand(rng, 8, Math.max(10, h * 0.7));

          const variant = randInt(rng, 0, variants - 1);
          const geo = new THREE.BoxGeometry(w, h, dp);
          geo.translate(0, h / 2, 0);
          this.scaleFacadeUV(geo, w, h, dp);
          geo.translate(x, 0, z);
          groups[variant].push(geo);

          // roof details
          const roofY = h;
          if (h > 20) {
            const ac = new THREE.BoxGeometry(rand(rng, 2, 4), rand(rng, 1, 2.2), rand(rng, 2, 4));
            ac.translate(x + rand(rng, -w / 3, w / 3), roofY + 1, z + rand(rng, -dp / 3, dp / 3));
            roofGeos.push(ac);
            const tank = new THREE.CylinderGeometry(1.1, 1.1, 2.4, 10);
            tank.translate(x + rand(rng, -w / 3, w / 3), roofY + 1.2, z + rand(rng, -dp / 3, dp / 3));
            roofGeos.push(tank);
          }
          // parapet
          const par = new THREE.BoxGeometry(w + 0.5, 0.9, dp + 0.5);
          par.translate(x, roofY + 0.35, z);
          roofGeos.push(par);

          // entrance door + awning on the street side
          const towardZ = z > cz ? -1 : 1;
          const towardX = x > cx ? -1 : 1;
          const useZ = Math.abs(towardZ) > 0;
          const doorW = rand(rng, 1.6, 3);
          const doorH = rand(rng, 2.4, 3.4);
          const door = new THREE.BoxGeometry(doorW, doorH, 0.3);
          if (useZ) {
            door.translate(x + rand(rng, -w / 3, w / 3), doorH / 2, z + (towardZ * dp) / 2 + towardZ * 0.06);
          } else {
            door.rotateY(Math.PI / 2);
            door.translate(x + (towardX * w) / 2 + towardX * 0.06, doorH / 2, z + rand(rng, -dp / 3, dp / 3));
          }
          details.push(door);

          if (style === 'house' || style === 'apt') {
            const aw = new THREE.BoxGeometry(rand(rng, 3, 6), 0.18, rand(rng, 2, 3.5));
            const ay = doorH + 0.2;
            if (useZ) {
              aw.translate(x + rand(rng, -w / 3, w / 3), ay, z + (towardZ * dp) / 2 + towardZ * 1.1);
              aw.rotateX(towardZ * 0.12);
            } else {
              aw.rotateY(Math.PI / 2);
              aw.translate(x + (towardX * w) / 2 + towardX * 1.1, ay, z + rand(rng, -dp / 3, dp / 3));
            }
            awningGeos.push(aw);
          }

          // glass curtain wall for towers
          if (style === 'tower' && h > 40) {
            const glass = new THREE.BoxGeometry(w * 0.55, h * 0.92, 0.4);
            glass.translate(x + (towardX * w) / 2 + towardX * 0.1, h * 0.46, z + rand(rng, -dp / 4, dp / 4));
            glassGeos.push(glass);
          }

          if (style === 'house' || style === 'apt' || style === 'tower') {
            signList.push({
              x: x + (useZ ? rand(rng, -w / 3, w / 3) : 0),
              z: z + (useZ ? (towardZ * dp) / 2 + towardZ * 0.2 : rand(rng, -dp / 3, dp / 3)),
              rot: useZ ? (towardZ > 0 ? Math.PI : 0) : towardZ > 0 ? -Math.PI / 2 : Math.PI / 2,
              name: d === 'Solstice Downtown' ? pick(rng, TOWER_NAMES) : pick(rng, SHOP_NAMES),
              color: useZ ? (towardZ > 0 ? '#7fd3ff' : '#ffd27f') : '#ffb0d0',
            });
          }

          this.buildingRects.push({ x, z, w, d: dp });
          this.addCollider(x - w / 2, z - dp / 2, x + w / 2, z + dp / 2, h);
        }
      }
    }

    // merge building shells per facade variant
    for (let i = 0; i < variants; i++) {
      if (!groups[i].length) continue;
      const mat = this.facadeVariant(i);
      const merged = mergeGeometries(groups[i])!;
      const mesh = new THREE.Mesh(merged, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.group.add(mesh);
    }

    const detailMat = new THREE.MeshStandardMaterial({ color: 0x3a3d42, roughness: 0.6, metalness: 0.25 });
    if (details.length) {
      const m = new THREE.Mesh(mergeGeometries(details)!, detailMat);
      m.castShadow = true;
      this.group.add(m);
    }
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x5d8ba8,
      roughness: 0.08,
      metalness: 0.85,
      transparent: true,
      opacity: 0.55,
    });
    if (glassGeos.length) {
      const m = new THREE.Mesh(mergeGeometries(glassGeos)!, glassMat);
      this.group.add(m);
    }
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x6a6d70, roughness: 0.9 });
    if (roofGeos.length) {
      const m = new THREE.Mesh(mergeGeometries(roofGeos)!, roofMat);
      m.castShadow = true;
      m.receiveShadow = true;
      this.group.add(m);
    }
    const awnMat = new THREE.MeshStandardMaterial({ color: 0x8d3b3b, roughness: 0.85 });
    if (awningGeos.length) {
      const m = new THREE.Mesh(mergeGeometries(awningGeos)!, awnMat);
      m.castShadow = true;
      this.group.add(m);
    }

    // shop signage
    signList.forEach((s) => {
      const c = document.createElement('canvas');
      c.width = 512;
      c.height = 128;
      const ctx = c.getContext('2d')!;
      ctx.fillStyle = '#111318';
      ctx.fillRect(0, 0, 512, 128);
      ctx.strokeStyle = s.color;
      ctx.lineWidth = 6;
      ctx.strokeRect(6, 6, 500, 116);
      ctx.fillStyle = s.color;
      ctx.font = 'bold 46px Arial, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(s.name, 256, 66);
      const tex = new THREE.CanvasTexture(c);
      tex.colorSpace = THREE.SRGBColorSpace;
      const m = new THREE.Mesh(
        new THREE.PlaneGeometry(6.4, 1.6),
        new THREE.MeshStandardMaterial({
          map: tex,
          emissiveMap: tex,
          emissive: 0xffffff,
          emissiveIntensity: 0.9,
          roughness: 0.5,
        })
      );
      m.position.set(s.x, 4.4, s.z);
      m.rotation.y = s.rot;
      this.group.add(m);
      this.shopSigns.push(m);
    });
  }

  private scaleFacadeUV(geo: THREE.BufferGeometry, w: number, h: number, d: number) {
    const uv = geo.attributes.uv as THREE.BufferAttribute;
    const arr = uv.array as Float32Array;
    const su = 1 / 13;
    const sv = 1 / 15;
    for (let f = 0; f < 6; f++) {
      const uScale = f === 0 || f === 1 ? d * su : f === 4 || f === 5 ? w * su : 1;
      const vScale = f === 2 || f === 3 ? 1 : h * sv;
      for (let i = 0; i < 4; i++) {
        const idx = f * 4 + i;
        arr[idx * 2] *= uScale;
        arr[idx * 2 + 1] *= vScale;
      }
    }
    uv.needsUpdate = true;
  }

  private buildLandmarks(rng: Rng) {
    const shellMat = new THREE.MeshStandardMaterial({
      map: (() => {
        const t = facadeTexture('#b6b0a4', 4, 4, '#0d1219', 99).map;
        return t;
      })(),
      roughness: 0.78,
    });
    const accentMat = new THREE.MeshStandardMaterial({ color: 0x2f4f80, roughness: 0.6 });
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x8fc4dd,
      roughness: 0.06,
      metalness: 0.8,
      transparent: true,
      opacity: 0.42,
    });
    const markerMat = new THREE.MeshBasicMaterial({
      color: 0x7fe8ff,
      transparent: true,
      opacity: 0.35,
      depthWrite: false,
    });

    for (const lm of LANDMARKS) {
      if (lm.id === 'park') continue;
      const isVilla = lm.id === 'villa';
      const w = lm.w;
      const d = lm.d;
      const h = lm.h;

      // main shell
      const shell = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), shellMat);
      shell.position.set(lm.x, h / 2, lm.z);
      shell.castShadow = true;
      shell.receiveShadow = true;
      this.group.add(shell);
      this.buildingRects.push({ x: lm.x, z: lm.z, w, d });
      this.addCollider(lm.x - w / 2, lm.z - d / 2, lm.x + w / 2, lm.z + d / 2, h);

      // flat roof + parapet
      const roof = new THREE.Mesh(
        new THREE.BoxGeometry(w + 1, 0.8, d + 1),
        new THREE.MeshStandardMaterial({ color: 0x5f6266, roughness: 0.9 })
      );
      roof.position.set(lm.x, h + 0.3, lm.z);
      roof.castShadow = true;
      this.group.add(roof);

      if (isVilla) {
        // luxury villa: glass front, cantilever, garage, pool
        const glassFront = new THREE.Mesh(new THREE.BoxGeometry(w - 3, 2.8, 0.3), glassMat);
        glassFront.position.set(lm.x, 1.9, lm.z + d / 2 + 0.05);
        this.group.add(glassFront);
        const upper = new THREE.Mesh(new THREE.BoxGeometry(w - 6, 3.2, d - 5), shellMat);
        upper.position.set(lm.x - 1, h + 1.9, lm.z - 1);
        upper.castShadow = true;
        this.group.add(upper);
        this.addCollider(lm.x - w / 2 + 3, lm.z - d / 2, lm.x + w / 2 - 3, lm.z + d / 2 - 2.5, h + 3.4);
        // garage
        const garage = new THREE.Mesh(new THREE.BoxGeometry(9, 3.4, 7), shellMat);
        garage.position.set(lm.x + 10, 1.7, lm.z - 2);
        garage.castShadow = true;
        this.group.add(garage);
        this.addCollider(lm.x + 5.5, lm.z - 5.5, lm.x + 14.5, lm.z + 1.5, 3.4);
        const garageDoor = new THREE.Mesh(
          new THREE.BoxGeometry(6.4, 2.6, 0.2),
          new THREE.MeshStandardMaterial({ color: 0x50555c, roughness: 0.5, metalness: 0.4 })
        );
        garageDoor.position.set(lm.x + 10, 1.3, lm.z + 1.55);
        this.group.add(garageDoor);
        // driveway
        const drive = new THREE.Mesh(
          new THREE.PlaneGeometry(9, 22),
          new THREE.MeshStandardMaterial({ color: 0x7c7f84, roughness: 0.85 })
        );
        drive.rotation.x = -Math.PI / 2;
        drive.position.set(lm.x + 10, 0.04, lm.z + 14);
        drive.receiveShadow = true;
        this.group.add(drive);
        // pool
        const pool = new THREE.Mesh(
          new THREE.BoxGeometry(11, 0.4, 6),
          new THREE.MeshStandardMaterial({ color: 0x2e7fa8, roughness: 0.06, metalness: 0.6 })
        );
        pool.position.set(lm.x - 11, 0.25, lm.z - 8);
        this.group.add(pool);
        const poolDeck = new THREE.Mesh(
          new THREE.PlaneGeometry(15, 10),
          new THREE.MeshStandardMaterial({ color: 0xcfc6b2, roughness: 0.8 })
        );
        poolDeck.rotation.x = -Math.PI / 2;
        poolDeck.position.set(lm.x - 11, 0.03, lm.z - 8);
        this.group.add(poolDeck);
        // hedges + garden
        const hedgeMat = new THREE.MeshStandardMaterial({ color: 0x2f5a22, roughness: 1 });
        for (let i = 0; i < 26; i++) {
          const hx = lm.x - 16 + rand(rng, 0, 30);
          const hz = lm.z + d / 2 + rand(rng, 2, 14);
          const hedge = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.5, 1.5), hedgeMat);
          hedge.position.set(hx, 0.75, hz);
          hedge.castShadow = true;
          this.group.add(hedge);
        }
      } else if (lm.id === 'police') {
        const stripe = new THREE.Mesh(new THREE.BoxGeometry(w + 0.2, 1.4, d + 0.2), accentMat);
        stripe.position.set(lm.x, 3.2, lm.z);
        this.group.add(stripe);
        // garage bays
        for (let i = 0; i < 3; i++) {
          const bay = new THREE.Mesh(
            new THREE.BoxGeometry(6, 3.6, 0.3),
            new THREE.MeshStandardMaterial({ color: 0x3a4048, roughness: 0.6 })
          );
          bay.position.set(lm.x - 12 + i * 12, 1.8, lm.z + d / 2 + 0.1);
          this.group.add(bay);
        }
      } else if (lm.id === 'mod') {
        const roller = new THREE.Mesh(
          new THREE.BoxGeometry(10, 4.2, 0.3),
          new THREE.MeshStandardMaterial({ color: 0x3c4147, roughness: 0.55, metalness: 0.4 })
        );
        roller.position.set(lm.x, 2.1, lm.z + d / 2 + 0.1);
        this.group.add(roller);
        const neon = new THREE.Mesh(
          new THREE.BoxGeometry(11, 0.8, 0.4),
          new THREE.MeshStandardMaterial({ color: 0xff6a2a, emissive: 0xff4a10, emissiveIntensity: 2.4 })
        );
        neon.position.set(lm.x, 6.2, lm.z + d / 2 - 0.2);
        this.group.add(neon);
      } else if (lm.id === 'mall') {
        const glassWall = new THREE.Mesh(new THREE.BoxGeometry(w - 6, h - 3, 0.4), glassMat);
        glassWall.position.set(lm.x, (h - 3) / 2, lm.z + d / 2 + 0.1);
        this.group.add(glassWall);
        const canopy = new THREE.Mesh(
          new THREE.BoxGeometry(w + 6, 0.7, 7),
          new THREE.MeshStandardMaterial({ color: 0xd8d4cc, roughness: 0.7 })
        );
        canopy.position.set(lm.x, 5.2, lm.z + d / 2 + 3);
        canopy.castShadow = true;
        this.group.add(canopy);
        for (let i = 0; i < 4; i++) {
          const col = new THREE.Mesh(
            new THREE.CylinderGeometry(0.4, 0.4, 5.2, 10),
            new THREE.MeshStandardMaterial({ color: 0xcfcac0, roughness: 0.6 })
          );
          col.position.set(lm.x - 21 + i * 14, 2.6, lm.z + d / 2 + 6);
          col.castShadow = true;
          this.group.add(col);
        }
      } else if (lm.id === 'phone') {
        const sign = new THREE.Mesh(
          new THREE.BoxGeometry(9, 1.4, 0.4),
          new THREE.MeshStandardMaterial({ color: 0x1f7a45, emissive: 0x18a35c, emissiveIntensity: 1.6 })
        );
        sign.position.set(lm.x, 6.4, lm.z + d / 2 - 0.1);
        this.group.add(sign);
      } else if (lm.id === 'bus') {
        const canopy = new THREE.Mesh(
          new THREE.BoxGeometry(w + 8, 0.6, 16),
          new THREE.MeshStandardMaterial({ color: 0xbfc4c8, roughness: 0.6 })
        );
        canopy.position.set(lm.x, 6.2, lm.z + d / 2 + 4);
        canopy.castShadow = true;
        this.group.add(canopy);
        for (let i = 0; i < 4; i++) {
          const col = new THREE.Mesh(
            new THREE.CylinderGeometry(0.35, 0.35, 6, 10),
            new THREE.MeshStandardMaterial({ color: 0x9aa0a6, roughness: 0.5, metalness: 0.5 })
          );
          col.position.set(lm.x - 15 + i * 10, 3, lm.z + d / 2 + 9);
          this.group.add(col);
        }
      } else if (lm.id === 'hospital') {
        const cross = new THREE.Mesh(
          new THREE.BoxGeometry(3, 0.4, 1.1),
          new THREE.MeshStandardMaterial({ color: 0xe03b3b, emissive: 0xaa2020, emissiveIntensity: 1.4 })
        );
        cross.position.set(lm.x, h + 1.2, lm.z);
        this.group.add(cross);
        const cross2 = new THREE.Mesh(
          new THREE.BoxGeometry(1.1, 0.4, 3),
          new THREE.MeshStandardMaterial({ color: 0xe03b3b, emissive: 0xaa2020, emissiveIntensity: 1.4 })
        );
        cross2.position.set(lm.x, h + 1.2, lm.z);
        this.group.add(cross2);
      }

      // entrance door + glowing marker
      const doorW = isVilla ? 3.2 : lm.id === 'mall' ? 12 : 4.2;
      const doorH = isVilla ? 3.0 : 4.2;
      const door = new THREE.Mesh(
        new THREE.BoxGeometry(doorW, doorH, 0.4),
        new THREE.MeshStandardMaterial({ color: 0x24282e, roughness: 0.5, metalness: 0.3 })
      );
      door.position.set(lm.doorX, doorH / 2, lm.z + d / 2 + 0.1);
      this.group.add(door);
      if (lm.interior) {
        const marker = new THREE.Mesh(
          new THREE.CylinderGeometry(1.6, 1.6, 4.5, 18, 1, true),
          markerMat.clone()
        );
        marker.position.set(lm.doorX, 2.2, lm.z + d / 2 + 2.6);
        this.group.add(marker);
        this.interactables.push({
          id: 'enter-' + lm.id,
          kind: 'enter',
          x: lm.doorX,
          z: lm.z + d / 2 + 2.6,
          label: 'Enter ' + lm.name,
          radius: 3.4,
          interior: lm.interior,
        });
      }

      // parking bays
      const bayMat = new THREE.MeshStandardMaterial({ color: 0x6f7479, roughness: 0.9 });
      const lineMat = new THREE.MeshStandardMaterial({ color: 0xe8e6df, roughness: 0.7 });
      const bays = new THREE.Group();
      for (let i = 0; i < 8; i++) {
        const l = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 5), lineMat);
        l.rotation.x = -Math.PI / 2;
        l.position.set(lm.x - 18 + i * 5, 0.03, lm.z + d / 2 + 12);
        bays.add(l);
      }
      this.group.add(bays);
      const lot = new THREE.Mesh(new THREE.PlaneGeometry(46, 16), bayMat);
      lot.rotation.x = -Math.PI / 2;
      lot.position.set(lm.x, 0.02, lm.z + d / 2 + 11);
      lot.receiveShadow = true;
      this.group.add(lot);
    }
  }

  private buildParks(rng: Rng) {
    // Verdant park: grass field, pond, paths, hedges, playground
    const parkMat = new THREE.MeshStandardMaterial({
      map: grassTexture(),
      roughness: 0.95,
      color: 0x8fb072,
    });
    const field = new THREE.Mesh(new THREE.PlaneGeometry(700, 520), parkMat);
    field.rotation.x = -Math.PI / 2;
    field.position.set(0, 0.03, 640);
    field.receiveShadow = true;
    this.group.add(field);

    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x2f5f78,
      roughness: 0.05,
      metalness: 0.55,
      transparent: true,
      opacity: 0.85,
    });
    const pond = new THREE.Mesh(new THREE.CircleGeometry(70, 32), waterMat);
    pond.rotation.x = -Math.PI / 2;
    pond.position.set(-120, 0.06, 690);
    this.group.add(pond);
    this.pond = pond;

    const pathMat = new THREE.MeshStandardMaterial({ color: 0xb0a894, roughness: 0.95 });
    const pathGeos: THREE.BufferGeometry[] = [];
    for (let i = 0; i < 6; i++) {
      const p = new THREE.PlaneGeometry(9, 640);
      p.rotateX(-Math.PI / 2);
      p.translate(-250 + i * 100, 0.05, 640);
      pathGeos.push(p);
    }
    const pm = new THREE.Mesh(mergeGeometries(pathGeos)!, pathMat);
    pm.receiveShadow = true;
    this.group.add(pm);

    // hedges
    const hedgeMat = new THREE.MeshStandardMaterial({ color: 0x33561f, roughness: 1 });
    const hedges: THREE.BufferGeometry[] = [];
    for (let i = 0; i < 120; i++) {
      const g = new THREE.BoxGeometry(rand(rng, 2, 7), rand(rng, 1, 1.8), rand(rng, 1.4, 3));
      g.translate(rand(rng, -320, 320), 0.9, rand(rng, 430, 860));
      hedges.push(g);
    }
    const hm = new THREE.Mesh(mergeGeometries(hedges)!, hedgeMat);
    hm.castShadow = true;
    this.group.add(hm);
  }

  pond: THREE.Mesh | null = null;

  private buildVegetation(rng: Rng) {
    const treeCount = this.quality === 'low' ? 220 : this.quality === 'medium' ? 520 : 950;
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x53412e, roughness: 0.95 });
    const foliageMat = new THREE.MeshStandardMaterial({
      color: 0x3f6b2c,
      roughness: 0.88,
      map: leafTexture(),
      transparent: false,
    });
    this.trunkMat = trunkMat;
    this.foliageMat = foliageMat;
    this.applyWind(foliageMat, 1.0);

    const trunkGeo = new THREE.CylinderGeometry(0.16, 0.32, 4.2, 7);
    trunkGeo.translate(0, 2.1, 0);
    const trunkMesh = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
    trunkMesh.castShadow = true;
    trunkMesh.receiveShadow = true;

    // branches (merged into one instanced mesh for detail at low cost)
    const branchParts: THREE.BufferGeometry[] = [];
    for (let b = 0; b < 3; b++) {
      const a = (b / 3) * Math.PI * 2 + 0.4;
      const g = new THREE.CylinderGeometry(0.07, 0.14, 1.9, 5);
      g.translate(0, 0.95, 0);
      g.rotateZ(Math.cos(a) * 0.55);
      g.rotateX(Math.sin(a) * 0.55);
      g.translate(Math.cos(a) * 0.35, 2.9, Math.sin(a) * 0.35);
      branchParts.push(g);
    }
    const branchGeo = mergeGeometries(branchParts)!;
    const branchMesh = new THREE.InstancedMesh(branchGeo, trunkMat, treeCount);
    branchMesh.castShadow = true;

    const foliageGeo = new THREE.IcosahedronGeometry(2.1, 1);
    foliageGeo.scale(1, 0.85, 1);
    const foliageMesh = new THREE.InstancedMesh(foliageGeo, foliageMat, treeCount * 2);
    foliageMesh.castShadow = true;
    foliageMesh.receiveShadow = true;

    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const v = new THREE.Vector3();
    const s = new THREE.Vector3();
    let placed = 0;
    let attempts = 0;
    while (placed < treeCount && attempts < treeCount * 30) {
      attempts++;
      const x = rand(rng, -WORLD_SIZE / 2 + 12, WORLD_SIZE / 2 - 12);
      const z = rand(rng, -WORLD_SIZE / 2 + 12, WORLD_SIZE / 2 - 12);
      const d = this.district(x, z);
      // Trees hug sidewalks and parks, avoid roads
      const nearRoad = this.nearRoad(x, z);
      const inPark = d === 'Verdant Park';
      if (!inPark && !nearRoad) continue;
      if (inPark && rng() < 0.5) continue;
      const scale = rand(rng, 0.75, 1.55);
      v.set(x, 0, z);
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rng() * Math.PI * 2);
      s.set(scale, scale * rand(rng, 0.9, 1.25), scale);
      m.compose(v, q, s);
      trunkMesh.setMatrixAt(placed, m);
      branchMesh.setMatrixAt(placed, m);
      // foliage clusters
      const fy = 4.4 * scale;
      for (let k = 0; k < 2; k++) {
        const fx = x + rand(rng, -1.2, 1.2) * scale;
        const fz = z + rand(rng, -1.2, 1.2) * scale;
        v.set(fx, fy + (k === 0 ? 0.6 : -0.5) * scale, fz);
        const fs = scale * (k === 0 ? 1 : 0.72);
        s.set(fs, fs * 0.9, fs);
        m.compose(v, q, s);
        foliageMesh.setMatrixAt(placed * 2 + k, m);
      }
      this.addCollider(x - 0.5, z - 0.5, x + 0.5, z + 0.5, 6);
      placed++;
    }
    trunkMesh.count = placed;
    foliageMesh.count = placed * 2;
    branchMesh.count = placed;
    trunkMesh.instanceMatrix.needsUpdate = true;
    foliageMesh.instanceMatrix.needsUpdate = true;
    branchMesh.instanceMatrix.needsUpdate = true;
    this.group.add(trunkMesh, foliageMesh, branchMesh);
    this.trees.push(trunkMesh, foliageMesh, branchMesh);

    // bushes
    const bushGeo = new THREE.IcosahedronGeometry(0.8, 1);
    bushGeo.scale(1.2, 0.75, 1.2);
    const bushCount = this.quality === 'low' ? 200 : 520;
    const bushMat = new THREE.MeshStandardMaterial({ color: 0x3c6b2b, roughness: 0.95 });
    this.applyWind(bushMat, 0.8);
    const bushMesh = new THREE.InstancedMesh(bushGeo, bushMat, bushCount);
    let bp = 0;
    attempts = 0;
    while (bp < bushCount && attempts < bushCount * 25) {
      attempts++;
      const x = rand(rng, -WORLD_SIZE / 2 + 10, WORLD_SIZE / 2 - 10);
      const z = rand(rng, -WORLD_SIZE / 2 + 10, WORLD_SIZE / 2 - 10);
      if (!this.nearRoad(x, z) && this.district(x, z) !== 'Verdant Park') continue;
      v.set(x, 0.5, z);
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rng() * 6.28);
      const bs = rand(rng, 0.7, 1.5);
      s.set(bs, bs * 0.8, bs);
      m.compose(v, q, s);
      bushMesh.setMatrixAt(bp++, m);
    }
    bushMesh.count = bp;
    bushMesh.castShadow = true;
    this.group.add(bushMesh);

    // rocks
    const rockGeo = new THREE.DodecahedronGeometry(0.5, 0);
    const rockMesh = new THREE.InstancedMesh(
      rockGeo,
      new THREE.MeshStandardMaterial({ color: 0x8b8b86, roughness: 0.95 }),
      260
    );
    for (let i = 0; i < 260; i++) {
      const x = rand(rng, -WORLD_SIZE / 2, WORLD_SIZE / 2);
      const z = rand(rng, -WORLD_SIZE / 2, WORLD_SIZE / 2);
      v.set(x, 0.12, z);
      q.setFromAxisAngle(new THREE.Vector3(rng(), rng(), rng()).normalize(), rng() * 6.28);
      const rs = rand(rng, 0.4, 1.6);
      s.set(rs, rs * 0.7, rs);
      m.compose(v, q, s);
      rockMesh.setMatrixAt(i, m);
    }
    rockMesh.castShadow = true;
    rockMesh.receiveShadow = true;
    this.group.add(rockMesh);

    // grass tufts (only near the city core for perf)
    if (this.quality !== 'low') {
      const tuftGeo = new THREE.PlaneGeometry(0.7, 0.6);
      tuftGeo.translate(0, 0.3, 0);
      const tuftMat = new THREE.MeshStandardMaterial({
        color: 0x6f9a45,
        roughness: 1,
        side: THREE.DoubleSide,
        alphaTest: 0.4,
        map: leafTexture(),
      });
      this.applyWind(tuftMat, 1.4);
      const tuftCount = this.quality === 'high' ? 9000 : 4000;
      const tufts = new THREE.InstancedMesh(tuftGeo, tuftMat, tuftCount);
      let tp = 0;
      attempts = 0;
      while (tp < tuftCount && attempts < tuftCount * 12) {
        attempts++;
        const x = rand(rng, -WORLD_SIZE / 2, WORLD_SIZE / 2);
        const z = rand(rng, -WORLD_SIZE / 2, WORLD_SIZE / 2);
        if (this.onRoad(x, z)) continue;
        v.set(x, 0, z);
        q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rng() * 6.28);
        s.setScalar(rand(rng, 0.7, 1.6));
        m.compose(v, q, s);
        tufts.setMatrixAt(tp++, m);
      }
      tufts.count = tp;
      tufts.receiveShadow = true;
      this.group.add(tufts);
      this.grassMesh = tufts;
    }
  }

  /** Adds wind sway to instanced vegetation through a patched shader. */
  private applyWind(mat: THREE.MeshStandardMaterial, strength: number) {
    mat.onBeforeCompile = (shader) => {
      shader.uniforms.uTime = { value: 0 };
      shader.uniforms.uWind = { value: 0.5 };
      shader.vertexShader = shader.vertexShader
        .replace(
          '#include <common>',
          '#include <common>\nuniform float uTime;\nuniform float uWind;'
        )
        .replace(
          '#include <begin_vertex>',
          `#include <begin_vertex>
          #ifdef USE_INSTANCING
            vec3 instPos = instanceMatrix[3].xyz;
          #else
            vec3 instPos = vec3(0.0);
          #endif
          float ph = uTime * 1.35 + instPos.x * 0.23 + instPos.z * 0.17;
          float sway = sin(ph) * 0.6 + sin(ph * 2.3 + 1.1) * 0.28;
          float hh = max(transformed.y - 1.2, 0.0);
          transformed.x += sway * uWind * hh * ${(0.05 * strength).toFixed(4)};
          transformed.z += sway * uWind * hh * ${(0.03 * strength).toFixed(4)};`
        );
      mat.userData.shader = shader;
    };
    mat.customProgramCacheKey = () => 'wind' + strength;
    this.windMaterials.push(mat);
  }

  private buildStreetProps(rng: Rng) {
    // street lamps
    const lampGeo: THREE.BufferGeometry[] = [];
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x2c2f33, roughness: 0.5, metalness: 0.7 });
    const lampMat = new THREE.MeshStandardMaterial({
      color: 0xfff0cf,
      emissive: 0xffdd9a,
      emissiveIntensity: 0.2,
      roughness: 0.3,
    });
    this.streetLampMat = lampMat;
    const lampPositions: [number, number, number][] = [];
    for (let i = -8; i <= 8; i++) {
      const p = i * BLOCK;
      for (let d = -7; d <= 7; d++) {
        const q = d * BLOCK + BLOCK / 2;
        if ((i + d) % 2 !== 0) continue;
        lampPositions.push([p + ROAD_W / 2 + 1.6, q, 0]);
        lampPositions.push([p - ROAD_W / 2 - 1.6, q, 0]);
      }
    }
    lampPositions.forEach(([x, z]) => {
      const pole = new THREE.CylinderGeometry(0.1, 0.14, 6.4, 7);
      pole.translate(x, 3.2, z);
      lampGeo.push(pole);
      const arm = new THREE.BoxGeometry(1.5, 0.12, 0.12);
      arm.translate(x - 0.7, 6.3, z);
      lampGeo.push(arm);
      const head = new THREE.BoxGeometry(0.7, 0.2, 0.34);
      head.translate(x - 1.35, 6.16, z);
      lampGeo.push(head);
    });
    const poleMesh = new THREE.Mesh(mergeGeometries(lampGeo)!, poleMat);
    poleMesh.castShadow = true;
    this.group.add(poleMesh);

    const bulbGeo: THREE.BufferGeometry[] = [];
    lampPositions.forEach(([x, z]) => {
      const b = new THREE.PlaneGeometry(0.6, 0.28);
      b.rotateX(Math.PI / 2);
      b.translate(x - 1.35, 6.05, z);
      bulbGeo.push(b);
    });
    const bulbMesh = new THREE.Mesh(mergeGeometries(bulbGeo)!, lampMat);
    this.group.add(bulbMesh);

    // benches, bins, hydrants, mailboxes, planters
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x6b4a2e, roughness: 0.9 });
    const metalMat = new THREE.MeshStandardMaterial({ color: 0x3b4046, roughness: 0.55, metalness: 0.6 });
    const redMat = new THREE.MeshStandardMaterial({ color: 0xa32b22, roughness: 0.6 });
    const props: { geo: THREE.BufferGeometry; mat: THREE.Material }[] = [];
    const push = (g: THREE.BufferGeometry, mat: THREE.Material) => props.push({ geo: g, mat });
    for (let i = -7; i <= 7; i++) {
      for (let j = -7; j <= 7; j++) {
        if ((i + j) % 3 !== 0) continue;
        const x = i * BLOCK + BLOCK / 2 + rand(rng, -30, 30);
        const z = j * BLOCK + BLOCK / 2 + rand(rng, -30, 30);
        if (this.onRoad(x, z)) continue;
        const bench = new THREE.BoxGeometry(1.9, 0.12, 0.5);
        bench.translate(x, 0.6, z);
        push(bench.clone(), woodMat);
        const back = new THREE.BoxGeometry(1.9, 0.5, 0.1);
        back.translate(x, 0.9, z - 0.2);
        push(back, woodMat);
        const leg = new THREE.BoxGeometry(0.12, 0.6, 0.5);
        [-0.8, 0.8].forEach((lx) => {
          const l = leg.clone();
          l.translate(x + lx, 0.3, z);
          push(l, metalMat);
        });
        const bin = new THREE.CylinderGeometry(0.34, 0.3, 0.9, 10);
        bin.translate(x + rand(rng, 3, 7), 0.45, z + rand(rng, -2, 2));
        push(bin, metalMat);
        const hyd = new THREE.CylinderGeometry(0.16, 0.2, 0.75, 8);
        hyd.translate(x - rand(rng, 4, 8), 0.38, z + rand(rng, -2, 2));
        push(hyd, redMat);
        const box = new THREE.BoxGeometry(0.5, 0.8, 0.32);
        box.translate(x + rand(rng, -8, 8), 0.9, z + rand(rng, -8, 8));
        push(box, metalMat);
      }
    }
    const byMat = new Map<THREE.Material, THREE.BufferGeometry[]>();
    props.forEach((p) => {
      let arr = byMat.get(p.mat);
      if (!arr) {
        arr = [];
        byMat.set(p.mat, arr);
      }
      arr.push(p.geo);
    });
    byMat.forEach((arr, mat) => {
      const mesh = new THREE.Mesh(mergeGeometries(arr)!, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.group.add(mesh);
    });

    // traffic lights at intersections
    const traffic: THREE.BufferGeometry[] = [];
    for (let i = -7; i <= 7; i++) {
      for (let j = -7; j <= 7; j++) {
        if ((i + j) % 2 !== 0) continue;
        const x = i * BLOCK + BLOCK / 2;
        const z = j * BLOCK + BLOCK / 2;
        const off = ROAD_W / 2 + 1.4;
        [[-1, -1], [1, 1]].forEach(([sx, sz]) => {
          const pole = new THREE.CylinderGeometry(0.09, 0.11, 4.4, 6);
          pole.translate(x + sx * off, 2.2, z + sz * off);
          traffic.push(pole);
          const box = new THREE.BoxGeometry(0.4, 1.1, 0.34);
          box.translate(x + sx * off, 4.3, z + sz * off);
          traffic.push(box);
        });
      }
    }
    const tm = new THREE.Mesh(mergeGeometries(traffic)!, metalMat);
    tm.castShadow = true;
    this.group.add(tm);
  }

  // ---------------------------------------------------------------- queries
  onRoad(x: number, z: number) {
    const nx = Math.abs(((x + BLOCK / 2) % BLOCK + BLOCK) % BLOCK - BLOCK / 2);
    const nz = Math.abs(((z + BLOCK / 2) % BLOCK + BLOCK) % BLOCK - BLOCK / 2);
    const half = ROAD_W / 2 + (Math.round(x / BLOCK) % 2 === 0 ? 3 : 0);
    return nx < half || nz < half;
  }

  nearRoad(x: number, z: number) {
    const nx = Math.abs(((x + BLOCK / 2) % BLOCK + BLOCK) % BLOCK - BLOCK / 2);
    const nz = Math.abs(((z + BLOCK / 2) % BLOCK + BLOCK) % BLOCK - BLOCK / 2);
    return nx < ROAD_W / 2 + SIDEWALK_W + 3 || nz < ROAD_W / 2 + SIDEWALK_W + 3;
  }

  /** Nearest point on the road network (used by traffic AI). */
  snapToRoad(x: number, z: number): [number, number] {
    const nx = Math.round(x / BLOCK) * BLOCK;
    const nz = Math.round(z / BLOCK) * BLOCK;
    const dx = Math.abs(x - nx);
    const dz = Math.abs(z - nz);
    if (dx < dz) return [nx + Math.sign(x - nx) * 3, z];
    return [x, nz + Math.sign(z - nz) * 3];
  }

  updateWetness(w: number) {
    const roadRough = lerp(0.88, 0.12, w);
    const roadMetal = lerp(0.04, 0.55, w);
    this.roadMeshes.forEach((m) => {
      (m.material as THREE.MeshStandardMaterial).roughness = roadRough;
      (m.material as THREE.MeshStandardMaterial).metalness = roadMetal;
      (m.material as THREE.MeshStandardMaterial).color.setHex(
        w > 0.4 ? 0x9a9a9a : 0xbfbfbf
      );
    });
    if (this.pond) {
      const pm = this.pond.material as THREE.MeshStandardMaterial;
      pm.roughness = lerp(0.05, 0.02, w);
      pm.metalness = lerp(0.55, 0.7, w);
    }
  }

  setNight(night: number) {
    this.windowMats.forEach((m) => (m.emissiveIntensity = night * 1.35));
    this.emissiveMats.forEach((m) => (m.emissiveIntensity = night * 0.9));
    this.streetLampMat.emissiveIntensity = 0.2 + night * 3.2;
    this.shopSigns.forEach((s) => {
      const m = s.material as THREE.MeshStandardMaterial;
      m.emissiveIntensity = 0.35 + night * 1.6;
    });
  }

  update(dt: number, time: number) {
    void dt;
    this.time = time;
    // gentle wind sway on foliage
    const sway = Math.sin(time * 1.1) * 0.5 + Math.sin(time * 2.3) * 0.2;
    for (const mat of this.windMaterials) {
      const sh = mat.userData.shader;
      if (!sh?.uniforms) continue; // shader not compiled yet
      sh.uniforms.uTime.value = time;
      sh.uniforms.uWind.value = 0.6 + sway * 0.5;
    }
  }
}
