import * as THREE from "three";
import { GeoBuilder } from "./geo";
import { mulberry32 } from "./noise";
import { CaveDef } from "./worldData";
import { Interactable } from "./structures";
import { Collider, circleCol } from "./physics";

export const CELL = 2.5;
const CEIL = 7.5;

export class Cave {
  group = new THREE.Group();
  W: number;
  H: number;
  grid: Uint8Array;
  spawn = { x: 0, z: 0 };
  interactables: Interactable[] = [];
  lights: { x: number; y: number; z: number; color: number }[] = [];
  colliders: Collider[] = [];
  collectibles = new Map<string, THREE.Mesh>();
  secretMesh: THREE.Mesh | null = null;
  secretCell = -1;
  private geos: THREE.BufferGeometry[] = [];
  name: string;

  constructor(def: CaveDef, idx: number, mats: { rock: THREE.Material; glow: THREE.Material; water: THREE.Material; fall: THREE.Material }, collected: Set<string>, opened: Set<string>) {
    this.name = def.name;
    const rnd = mulberry32(def.seed);
    const W = (this.W = def.large ? 44 : 28);
    const H = (this.H = def.large ? 44 : 28);
    let g = new Uint8Array(W * H);
    const ei = Math.floor(W / 2), ej = H - 4;
    const at = (i: number, j: number) => (i < 0 || j < 0 || i >= W || j >= H ? 1 : g[j * W + i]);
    const carve = (ci: number, cj: number, r: number, v = 0) => {
      for (let j = Math.floor(cj - r); j <= cj + r; j++)
        for (let i = Math.floor(ci - r); i <= ci + r; i++)
          if (i > 0 && j > 0 && i < W - 1 && j < H - 1 && (i - ci) ** 2 + (j - cj) ** 2 <= r * r) g[j * W + i] = v;
    };
    let reach = new Uint8Array(W * H);
    for (let attempt = 0; attempt < 8; attempt++) {
      for (let j = 0; j < H; j++)
        for (let i = 0; i < W; i++) {
          const border = i < 2 || j < 2 || i >= W - 2 || j >= H - 2;
          g[j * W + i] = border || rnd() < 0.46 ? 1 : 0;
        }
      carve(ei, ej, 2.6);
      for (let it = 0; it < 5; it++) {
        const n = new Uint8Array(W * H);
        for (let j = 0; j < H; j++)
          for (let i = 0; i < W; i++) {
            let c = 0;
            for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) if (di || dj) c += at(i + di, j + dj);
            const border = i < 1 || j < 1 || i >= W - 1 || j >= H - 1;
            n[j * W + i] = border ? 1 : c > 4 || (c === 4 && g[j * W + i] === 1) ? 1 : 0;
          }
        g = n;
      }
      carve(ei, ej, 2.6);
      carve(ei, ej + 1.5, 1.2);
      // winding tunnel upward to guarantee depth
      let ti = ei, tj = ej;
      while (tj > 5) {
        carve(ti, tj, 1.3);
        tj -= 1;
        ti += Math.round((rnd() - 0.5) * 2.2);
        ti = Math.max(4, Math.min(W - 5, ti));
      }
      reach = this.flood(g, W, H, ei, ej);
      let cnt = 0;
      for (let k = 0; k < W * H; k++) {
        if (g[k] === 0 && !reach[k]) g[k] = 1;
        if (reach[k]) cnt++;
      }
      if (cnt > W * H * 0.25) break;
    }
    // secret chamber
    let chest: [number, number] | null = null;
    for (let t = 0; t < 400 && !chest; t++) {
      const ci = 5 + Math.floor(rnd() * (W - 10)), cj = 5 + Math.floor(rnd() * (H - 14));
      let ok = true;
      for (let j = cj - 4; j <= cj + 4 && ok; j++) for (let i = ci - 4; i <= ci + 4 && ok; i++) if (at(i, j) !== 1) ok = false;
      if (!ok) continue;
      // BFS to reachable
      const prev = new Int32Array(W * H).fill(-1);
      const q = [cj * W + ci];
      prev[q[0]] = q[0];
      let found = -1;
      for (let h = 0; h < q.length && found < 0; h++) {
        const c = q[h];
        const i = c % W, j = Math.floor(c / W);
        for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const ni = i + di, nj = j + dj;
          if (ni < 2 || nj < 2 || ni >= W - 2 || nj >= H - 2) continue;
          const nk = nj * W + ni;
          if (prev[nk] >= 0) continue;
          prev[nk] = c;
          if (reach[nk]) { found = nk; break; }
          q.push(nk);
        }
      }
      if (found < 0) continue;
      const path: number[] = [];
      let c = prev[found];
      while (c !== cj * W + ci) { path.push(c); c = prev[c]; }
      if (path.length < 3) continue;
      carve(ci, cj, 2.4);
      for (let k = 1; k < path.length; k++) g[path[k]] = 0;
      g[path[0]] = 2;
      this.secretCell = path[0];
      chest = [ci, cj];
    }
    // water pools
    const floorCells: number[] = [];
    for (let k = 0; k < W * H; k++) if (g[k] === 0 && reach[k]) floorCells.push(k);
    const pools: number[] = [];
    for (let t = 0; t < 60 && pools.length < (def.large ? 3 : 2); t++) {
      const k = floorCells[Math.floor(rnd() * floorCells.length)];
      const i = k % W, j = Math.floor(k / W);
      if (Math.hypot(i - ei, j - ej) < 7) continue;
      let open = 0;
      for (let dj = -2; dj <= 2; dj++) for (let di = -2; di <= 2; di++) if (at(i + di, j + dj) === 0) open++;
      if (open < 20) continue;
      pools.push(k);
      for (let dj = -2; dj <= 2; dj++)
        for (let di = -2; di <= 2; di++) if (di * di + dj * dj <= 2.6 && at(i + di, j + dj) === 0) g[(j + dj) * W + i + di] = 3;
    }
    this.grid = g;
    this.spawn = { x: (ei + 0.5) * CELL, z: (ej + 1.2) * CELL };

    // ---------- build meshes ----------
    const rock = new GeoBuilder();
    const glow = new GeoBuilder();
    const crystalCol = idx % 2 === 0 ? [0.72, 0.35, 1.0] : [0.35, 0.8, 1.0];
    for (let j = 0; j < H; j++)
      for (let i = 0; i < W; i++) {
        const v = g[j * W + i];
        const x = i * CELL, z = j * CELL;
        const r0 = rnd();
        if (v === 0 || v === 3) {
          const y = v === 3 ? -0.9 : 0;
          const k = 0.85 + r0 * 0.25;
          rock.quad([x, y, z, x, y, z + CELL, x + CELL, y, z + CELL, x + CELL, y, z], 0.27 * k, 0.25 * k, 0.25 * k);
          if (v === 0 && r0 < 0.08) {
            const sx = x + CELL / 2 + (rnd() - 0.5), sz = z + CELL / 2 + (rnd() - 0.5);
            const h = 0.8 + rnd() * 1.8;
            rock.cyl(sx, 0, sz, 0.35 + rnd() * 0.3, 0, h, 6, 0.36, 0.33, 0.32);
            if (Math.hypot(i - ei, j - ej) > 3) this.colliders.push(circleCol(sx, sz, 0.4, h));
          }
          if (r0 > 0.9) rock.cyl(x + CELL / 2, CEIL - 1.5 - rnd() * 1.5, z + CELL / 2, 0.01, 0.4, 3, 6, 0.3, 0.28, 0.28);
          // pool sides
          if (v === 3) {
            for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
              if (at(i + di, j + dj) === 3) continue;
              const x0 = di === 1 ? x + CELL : x, z0 = dj === 1 ? z + CELL : z;
              const x1 = di === 0 ? x0 + CELL : x0, z1 = dj === 0 ? z0 + CELL : z0;
              rock.quad([x0, -0.9, z0, x0, 0, z0, x1, 0, z1, x1, -0.9, z1], 0.22, 0.2, 0.2);
              rock.quad([x1, -0.9, z1, x1, 0, z1, x0, 0, z0, x0, -0.9, z0], 0.22, 0.2, 0.2);
            }
          }
        } else if (v === 1) {
          let edge = false;
          for (let dj = -1; dj <= 1 && !edge; dj++) for (let di = -1; di <= 1; di++) { const n = at(i + di, j + dj); if (n !== 1) { edge = true; break; } }
          if (!edge) continue;
          const h = 5 + r0 * 3;
          const k = 0.8 + rnd() * 0.3;
          rock.box(x + CELL / 2, -1, z + CELL / 2, CELL, h + 1, CELL, 0, 0.3 * k, 0.28 * k, 0.3 * k, 0.9);
          // bulge rocks toward the open space
          for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const n = at(i + di, j + dj);
            if (n === 0 && rnd() < 0.45) {
              rock.blob(x + CELL / 2 + di * 1.1, 0.5 + rnd() * 3, z + CELL / 2 + dj * 1.1, 0.9 + rnd() * 0.7, 0.8 + rnd(), 0.9 + rnd() * 0.7, 0.34 * k, 0.31 * k, 0.32 * k, rnd, 0, 0.3);
              if (rnd() < 0.25) {
                const cx = x + CELL / 2 + di * 1.5, cz = z + CELL / 2 + dj * 1.5;
                for (let c = 0; c < 3; c++)
                  glow.octa(cx + (rnd() - 0.5) * 0.8, 0.3 + rnd() * 0.3, cz + (rnd() - 0.5) * 0.8, 0.12 + rnd() * 0.1, 0.35 + rnd() * 0.4, 0.12 + rnd() * 0.1, crystalCol[0], crystalCol[1], crystalCol[2], rnd() * 3);
                if (this.lights.length < 12 && rnd() < 0.5) this.lights.push({ x: cx, y: 1.2, z: cz, color: idx % 2 === 0 ? 0xa050ff : 0x40c0ff });
              }
            }
          }
        }
      }
    // ceiling
    rock.quad([0, CEIL, 0, W * CELL, CEIL, 0, W * CELL, CEIL, H * CELL, 0, CEIL, H * CELL], 0.1, 0.09, 0.1);

    // exit light
    const mx = (ei + 0.5) * CELL, mz = (H - 1) * CELL;
    glow.quad([mx - 1.8, 0, mz - 0.6, mx - 1.4, 3.6, mz - 0.6, mx + 1.4, 3.6, mz - 0.6, mx + 1.8, 0, mz - 0.6], 0.95, 0.9, 0.75);
    glow.quad([mx + 1.8, 0, mz - 0.6, mx + 1.4, 3.6, mz - 0.6, mx - 1.4, 3.6, mz - 0.6, mx - 1.8, 0, mz - 0.6], 0.95, 0.9, 0.75);
    this.interactables.push({ id: "exit", x: mx, y: 0, z: mz - 2.2, r: 2.6, label: "Sair da caverna", kind: "exit" });

    // collectible crystals
    const clusterGeo = new GeoBuilder();
    const cr = mulberry32(3);
    for (let c = 0; c < 5; c++) {
      const a = (c / 5) * 6.28;
      clusterGeo.octa(Math.cos(a) * 0.35, 0.5 + cr() * 0.4, Math.sin(a) * 0.35, 0.16, 0.55 + cr() * 0.4, 0.16, 1, 1, 1, cr() * 3);
    }
    clusterGeo.octa(0, 0.9, 0, 0.25, 0.95, 0.25, 1, 1, 1, 0.5);
    const cg = clusterGeo.build();
    this.geos.push(cg);
    const cmat = new THREE.MeshBasicMaterial({ vertexColors: true, color: new THREE.Color(crystalCol[0], crystalCol[1], crystalCol[2]) });
    const nCol = def.large ? 7 : 4;
    const cands = floorCells.filter((k) => g[k] === 0);
    for (let c = 0; c < nCol && cands.length; c++) {
      let best = -1, bd = -1;
      for (let t = 0; t < 30; t++) {
        const k = cands[Math.floor(rnd() * cands.length)];
        const i = k % W, j = Math.floor(k / W);
        let d = Math.hypot(i - ei, j - ej);
        for (const m of this.collectibles.values()) d = Math.min(d, Math.hypot(m.position.x / CELL - i, m.position.z / CELL - j) * 1.5);
        if (d > bd) { bd = d; best = k; }
      }
      const id = `crys-${idx}-${c}`;
      if (collected.has(id)) continue;
      const i = best % W, j = Math.floor(best / W);
      const m = new THREE.Mesh(cg, cmat);
      m.position.set((i + 0.5) * CELL, 0, (j + 0.5) * CELL);
      this.group.add(m);
      this.collectibles.set(id, m);
      this.interactables.push({ id, x: m.position.x, y: 0, z: m.position.z, r: 2.0, label: "Coletar cristal", kind: "crystal" });
      this.lights.push({ x: m.position.x, y: 1.5, z: m.position.z, color: idx % 2 === 0 ? 0xb060ff : 0x50d0ff });
    }

    // secret wall & chest
    if (this.secretCell >= 0 && chest) {
      const si = this.secretCell % W, sj = Math.floor(this.secretCell / W);
      const secretId = `secret-${idx}`;
      if (opened.has(secretId)) {
        g[this.secretCell] = 0;
        rock.quad([si * CELL, 0, sj * CELL, si * CELL, 0, (sj + 1) * CELL, (si + 1) * CELL, 0, (sj + 1) * CELL, (si + 1) * CELL, 0, sj * CELL], 0.25, 0.23, 0.23);
      } else {
        const sb = new GeoBuilder();
        sb.box((si + 0.5) * CELL, -1, (sj + 0.5) * CELL, CELL, 8, CELL, 0, 0.42, 0.38, 0.36, 0.9);
        for (let c = 0; c < 6; c++) sb.box((si + 0.5) * CELL + (rnd() - 0.5) * 2.2, 0.5 + rnd() * 3, (sj + 0.5) * CELL + (rnd() - 0.5) * 2.2, 2.62, 0.12, 2.62, rnd(), 0.12, 0.1, 0.1);
        const sg = sb.build();
        this.geos.push(sg);
        this.secretMesh = new THREE.Mesh(sg, mats.rock);
        this.group.add(this.secretMesh);
        // interaction from a reachable neighbour
        let ni = si, nj = sj;
        for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (reach[(sj + dj) * W + si + di]) { ni = si + di; nj = sj + dj; }
        this.interactables.push({ id: secretId, x: (ni + 0.5) * CELL, y: 0, z: (nj + 0.5) * CELL, r: 2.4, label: "Empurrar parede rachada", kind: "secret" });
      }
      const [ci, cj] = chest;
      const cx = (ci + 0.5) * CELL, cz = (cj + 0.5) * CELL;
      const chestId = `chest-${idx}`;
      const opn = collected.has(chestId);
      rock.box(cx, 0, cz, 1.4, 0.8, 0.9, 0.2, 0.5, 0.33, 0.18);
      if (!opn) rock.box(cx, 0.8, cz, 1.45, 0.35, 0.95, 0.2, 0.55, 0.36, 0.2);
      rock.box(cx, 0.35, cz, 1.46, 0.12, 0.96, 0.2, 0.75, 0.62, 0.2);
      for (let c = 0; c < 7; c++) {
        const a = rnd() * 6.28;
        glow.octa(cx + Math.cos(a) * 2, 0.5, cz + Math.sin(a) * 2, 0.25, 0.9 + rnd() * 0.8, 0.25, 1.0, 0.6, 0.95, rnd() * 3);
      }
      this.lights.push({ x: cx, y: 1.5, z: cz, color: 0xff70d0 });
      this.colliders.push(circleCol(cx, cz, 0.8, 1e9));
      if (!opn) this.interactables.push({ id: chestId, x: cx, y: 0, z: cz, r: 2.2, label: "Abrir baú antigo", kind: "chest" });
    }

    // pools: water planes + drip
    for (const k of pools) {
      const i = k % W, j = Math.floor(k / W);
      const cx = (i + 0.5) * CELL, cz = (j + 0.5) * CELL;
      const pg = new THREE.PlaneGeometry(CELL * 5, CELL * 5);
      pg.rotateX(-Math.PI / 2);
      const uv = pg.getAttribute("uv") as THREE.BufferAttribute;
      const pp = pg.getAttribute("position") as THREE.BufferAttribute;
      for (let v = 0; v < uv.count; v++) uv.setXY(v, cx + pp.getX(v), cz + pp.getZ(v));
      pg.setAttribute("aSpeed", new THREE.Float32BufferAttribute(new Array(uv.count).fill(0), 1));
      this.geos.push(pg);
      const wm = new THREE.Mesh(pg, mats.water);
      wm.position.set(cx, -0.2, cz);
      wm.renderOrder = 2;
      this.group.add(wm);
      // drip stream
      const dg = new THREE.BufferGeometry();
      const dp = [-0.25, CEIL, 0, 0.25, CEIL, 0, 0.25, -0.2, 0, -0.25, CEIL, 0, 0.25, -0.2, 0, -0.25, -0.2, 0];
      const du = [0, 0, 1, 0, 1, 8, 0, 0, 1, 8, 0, 8];
      dg.setAttribute("position", new THREE.Float32BufferAttribute(dp, 3));
      dg.setAttribute("uv", new THREE.Float32BufferAttribute(du, 2));
      this.geos.push(dg);
      const dm = new THREE.Mesh(dg, mats.fall);
      dm.position.set(cx + 0.5, 0, cz);
      this.group.add(dm);
      const dm2 = dm.clone();
      dm2.rotation.y = Math.PI / 2;
      this.group.add(dm2);
      this.lights.push({ x: cx, y: 1, z: cz, color: 0x60b0ff });
    }

    const rg = rock.build();
    const gg = glow.build();
    this.geos.push(rg, gg);
    this.group.add(new THREE.Mesh(rg, mats.rock));
    this.group.add(new THREE.Mesh(gg, mats.glow));
  }

  private flood(g: Uint8Array, W: number, H: number, si: number, sj: number) {
    const r = new Uint8Array(W * H);
    const q = [sj * W + si];
    r[q[0]] = 1;
    for (let h = 0; h < q.length; h++) {
      const c = q[h];
      const i = c % W, j = Math.floor(c / W);
      for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const ni = i + di, nj = j + dj;
        if (ni < 0 || nj < 0 || ni >= W || nj >= H) continue;
        const k = nj * W + ni;
        if (r[k] || g[k] === 1) continue;
        r[k] = 1;
        q.push(k);
      }
    }
    return r;
  }

  cellAt(x: number, z: number) {
    const i = Math.floor(x / CELL), j = Math.floor(z / CELL);
    if (i < 0 || j < 0 || i >= this.W || j >= this.H) return 1;
    return this.grid[j * this.W + i];
  }
  solid(x: number, z: number) {
    const c = this.cellAt(x, z);
    return c === 1 || c === 2;
  }
  groundAt(x: number, z: number) {
    return this.cellAt(x, z) === 3 ? -0.9 : 0;
  }
  waterAt(x: number, z: number) {
    return this.cellAt(x, z) === 3 ? -0.2 : -1e9;
  }

  /** push circle out of solid cells */
  resolve(pos: { x: number; z: number }, r: number) {
    const i0 = Math.floor((pos.x - r) / CELL), i1 = Math.floor((pos.x + r) / CELL);
    const j0 = Math.floor((pos.z - r) / CELL), j1 = Math.floor((pos.z + r) / CELL);
    for (let j = j0; j <= j1; j++)
      for (let i = i0; i <= i1; i++) {
        const c = i < 0 || j < 0 || i >= this.W || j >= this.H ? 1 : this.grid[j * this.W + i];
        if (c !== 1 && c !== 2) continue;
        const minx = i * CELL, maxx = minx + CELL, minz = j * CELL, maxz = minz + CELL;
        const qx = Math.max(minx, Math.min(maxx, pos.x)), qz = Math.max(minz, Math.min(maxz, pos.z));
        const dx = pos.x - qx, dz = pos.z - qz;
        const d = Math.sqrt(dx * dx + dz * dz);
        if (d < r) {
          if (d > 1e-5) {
            pos.x = qx + (dx / d) * r;
            pos.z = qz + (dz / d) * r;
          } else {
            // inside: push toward the nearest edge
            const l = pos.x - minx, rr = maxx - pos.x, t = pos.z - minz, b = maxz - pos.z;
            const m = Math.min(l, rr, t, b);
            if (m === l) pos.x = minx - r; else if (m === rr) pos.x = maxx + r; else if (m === t) pos.z = minz - r; else pos.z = maxz + r;
          }
        }
      }
  }

  openSecret() {
    if (this.secretCell >= 0) this.grid[this.secretCell] = 0;
    if (this.secretMesh) {
      this.secretMesh.removeFromParent();
      this.secretMesh = null;
    }
  }

  dispose() {
    this.geos.forEach((g) => g.dispose());
    this.group.removeFromParent();
  }
}
