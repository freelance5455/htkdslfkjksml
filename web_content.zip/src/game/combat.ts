import { ARMORS, MONSTERS, WEAPONS } from './constants';
import {
  ActiveMonsterState,
  ElementType,
  FloatingNumber,
  MonsterPart,
  PlayerStats,
  Projectile,
  WeaponClass,
} from './types';

export interface HitResult {
  damage: number;
  isCrit: boolean;
  partBroken?: MonsterPart;
  tailSevered?: boolean;
  monsterDefeated?: boolean;
}

export class CombatSystem {
  // Calculate total player attack including weapon, skills, and gauge buffs
  public static calculatePlayerAttack(stats: PlayerStats): number {
    const weapon = WEAPONS[stats.equippedWeaponId] || WEAPONS['iron_greatsword'];
    let attack = weapon.attack;

    // Armor skills bonus
    let skillAttackPercent = 0;
    Object.values(stats.equippedArmor).forEach((armorId) => {
      const armor = ARMORS[armorId];
      if (armor) {
        if (armor.skillName.includes('Attack Boost')) {
          skillAttackPercent += 0.15;
        }
      }
    });

    attack *= 1 + skillAttackPercent;

    // Longsword Spirit Gauge Level buff
    if (weapon.weaponClass === 'longsword') {
      if (stats.spiritLevel === 1) attack *= 1.1;
      else if (stats.spiritLevel === 2) attack *= 1.2;
      else if (stats.spiritLevel === 3) attack *= 1.35;
    }

    // Dual Blades Demon Mode buff
    if (weapon.weaponClass === 'dualblades' && stats.demonMode) {
      attack *= 1.25;
    }

    return Math.round(attack);
  }

  // Calculate total player defense including armor and weapon defense bonus
  public static calculatePlayerDefense(stats: PlayerStats): number {
    let defense = 10;
    const weapon = WEAPONS[stats.equippedWeaponId];
    if (weapon) defense += weapon.defenseBonus;

    Object.values(stats.equippedArmor).forEach((armorId) => {
      const armor = ARMORS[armorId];
      if (armor) {
        defense += armor.defense;
        if (armor.skillName.includes('Defense Boost')) {
          defense += 10;
        }
      }
    });

    return defense;
  }

  // Calculate damage dealt to a monster
  public static executeAttackOnMonster(
    stats: PlayerStats,
    monster: ActiveMonsterState,
    attackMultiplier: number = 1.0,
    attackType: string = 'standard',
    hitAngleRelative: number = 0 // angle from monster center to hit
  ): HitResult {
    const def = MONSTERS[monster.defId];
    if (!def || monster.state === 'dead') {
      return { damage: 0, isCrit: false };
    }

    const weapon = WEAPONS[stats.equippedWeaponId] || WEAPONS['iron_greatsword'];
    const baseAttack = this.calculatePlayerAttack(stats);

    // Critical hit check
    let affinity = weapon.affinity;
    Object.values(stats.equippedArmor).forEach((armorId) => {
      const armor = ARMORS[armorId];
      if (armor?.skillName.includes('Critical Eye')) affinity += 15;
    });

    const isCrit = Math.random() * 100 < affinity;
    const critMult = isCrit ? 1.35 : 1.0;

    // Greatsword charge multiplier
    let chargeMult = 1.0;
    if (weapon.weaponClass === 'greatsword' && attackType === 'charge') {
      chargeMult = stats.chargeLevel === 3 ? 3.2 : stats.chargeLevel === 2 ? 2.1 : 1.4;
    }

    // Bow charge & coating
    if (weapon.weaponClass === 'bow') {
      if (stats.chargeLevel === 3) chargeMult = 1.8;
      else if (stats.chargeLevel === 2) chargeMult = 1.4;
      if (stats.bowCoating === 'power') chargeMult *= 1.3;
    }

    // Elemental damage calculation
    let elementMult = 1.0;
    if (weapon.element !== 'none') {
      if (weapon.element === def.weakness) {
        elementMult = 1.6;
      } else if (weapon.element === def.resistance) {
        elementMult = 0.4;
      }
    }
    const elementDmg = weapon.elementDamage * elementMult;

    // Raw damage mitigated by monster defense / broken parts
    const armorBroken = monster.parts.find((p) => p.id === 'armor' || p.id === 'shell')?.broken;
    const defenseFactor = armorBroken ? 0.9 : 0.75;

    let totalDamage = Math.round(
      (baseAttack * attackMultiplier * chargeMult * critMult * defenseFactor + elementDmg) *
        (0.92 + Math.random() * 0.16)
    );
    totalDamage = Math.max(12, totalDamage);

    // Apply damage to monster HP
    monster.hp = Math.max(0, monster.hp - totalDamage);

    // Build Longsword Spirit gauge
    if (weapon.weaponClass === 'longsword') {
      stats.spiritGauge = Math.min(100, stats.spiritGauge + 15);
    }

    // Build Dual Blades demon gauge
    if (weapon.weaponClass === 'dualblades' && !stats.demonMode) {
      stats.demonGauge = Math.min(100, stats.demonGauge + 12);
    }

    // Hammer blunt stun buildup on head hits
    if (weapon.weaponClass === 'hammer') {
      monster.stunBuildup += 25;
      if (monster.stunBuildup >= 100 && monster.state !== 'dead') {
        monster.stunBuildup = 0;
        monster.state = 'exhausted';
        monster.stateTimer = 4.0;
      }
    }

    // Poison status buildup
    if (weapon.element === 'poison' || (weapon.weaponClass === 'bow' && stats.bowCoating === 'poison')) {
      monster.poisonBuildup += 20;
      if (monster.poisonBuildup >= 80 && !monster.isPoisoned) {
        monster.isPoisoned = true;
        monster.poisonTimer = 10.0;
      }
    }

    // Part Damage & Breaking
    let partBroken: MonsterPart | undefined;
    let tailSevered = false;

    // Determine targeted body part by hit angle:
    // Front (-PI/3 to PI/3) hits Horn/Head; Back (2PI/3 to 4PI/3) hits Tail; Sides hit Carapace/Wings
    const normAngle = ((hitAngleRelative % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
    const isFrontHit = normAngle < Math.PI * 0.35 || normAngle > Math.PI * 1.65;
    const isBackHit = normAngle > Math.PI * 0.65 && normAngle < Math.PI * 1.35;

    for (const part of monster.parts) {
      if (part.broken) continue;

      let hitMatchesPart = false;
      if ((part.id === 'horn' || part.id === 'crown' || part.id === 'fangs') && isFrontHit) {
        hitMatchesPart = true;
      } else if (part.severable && isBackHit) {
        hitMatchesPart = true;
      } else if (part.id === 'armor' || part.id === 'shell' || part.id === 'wings' || part.id === 'pincers') {
        hitMatchesPart = true;
      }

      if (hitMatchesPart) {
        part.hp -= totalDamage;
        if (part.hp <= 0) {
          part.hp = 0;
          part.broken = true;
          partBroken = part;

          if (part.severable) {
            part.severed = true;
            tailSevered = true;
          }

          // Stagger monster when a part breaks
          if (monster.state !== 'dead') {
            monster.state = 'stagger';
            monster.stateTimer = 1.8;
          }
        }
        break;
      }
    }

    // Stagger threshold buildup
    monster.staggerBuildup += totalDamage;
    if (monster.staggerBuildup > def.baseHp * 0.22 && monster.state !== 'dead') {
      monster.staggerBuildup = 0;
      if (monster.state !== 'stagger' && monster.state !== 'exhausted') {
        monster.state = 'stagger';
        monster.stateTimer = 1.2;
      }
    }

    // Check enrage threshold (monster enrages when HP drops below 65% and 30%)
    if (
      !monster.enraged &&
      monster.hp < monster.maxHp * 0.65 &&
      monster.state !== 'dead' &&
      monster.stateTimer <= 0
    ) {
      monster.enraged = true;
      monster.enrageTimer = 25.0;
      monster.state = 'roar';
      monster.stateTimer = 1.5;
    }

    // Defeated check
    let monsterDefeated = false;
    if (monster.hp <= 0 && monster.state !== 'dead') {
      monster.state = 'dead';
      monster.stateTimer = 60.0;
      monsterDefeated = true;
    }

    return {
      damage: totalDamage,
      isCrit,
      partBroken,
      tailSevered,
      monsterDefeated,
    };
  }

  // Calculate monster damage to player (factoring guard, i-frames, and elemental defense)
  public static calculateMonsterDamageToPlayer(
    damageMultiplier: number,
    monsterAttack: number,
    element: ElementType,
    stats: PlayerStats,
    isGuarding: boolean
  ): { finalDamage: number; blocked: boolean } {
    const defense = this.calculatePlayerDefense(stats);

    // Guarding with Lance or Greatsword
    const weapon = WEAPONS[stats.equippedWeaponId];
    if (isGuarding && weapon?.weaponClass === 'lance') {
      // Lance reduces damage by 85% and drains stamina
      const blockedDamage = Math.round((monsterAttack * damageMultiplier * 0.15));
      return { finalDamage: Math.max(1, blockedDamage), blocked: true };
    }

    // Physical damage formula: Att / (1 + Def/80)
    let rawDmg = (monsterAttack * damageMultiplier * 80) / (80 + defense);

    // Elemental mitigation from armor
    if (element !== 'none') {
      let res = 0;
      Object.values(stats.equippedArmor).forEach((armorId) => {
        const armor = ARMORS[armorId];
        if (armor) {
          if (element === 'fire') res += armor.fireRes;
          else if (element === 'ice') res += armor.iceRes;
          else if (element === 'thunder') res += armor.thunderRes;
        }
      });
      rawDmg *= 1 - Math.min(0.6, res * 0.01);
    }

    return { finalDamage: Math.max(6, Math.round(rawDmg)), blocked: false };
  }
}
