import { CHAR_BY_ID } from "./data/characters";
import { ENEMY_BY_ID, VARIANTS } from "./data/enemies";
import { mulberry32, roll } from "./rng";
import type {
  AbilityDef,
  AnomalyWeather,
  BattleSpec,
  ClashResult,
  ClashRound,
  Combatant,
  CombatLogLine,
  CombatPhase,
  DamagePop,
  PlannedAction,
  SaveData,
  StatusId,
  VariantKind,
} from "./types";

export interface CombatRuntime {
  title: string;
  phase: CombatPhase;
  round: number;
  allies: Combatant[];
  enemies: Combatant[];
  weather: AnomalyWeather;
  anomaly: number;
  momentum: number;
  selected: { uid: string; abilityId: string } | null;
  plans: Record<string, PlannedAction>;
  enemyPlans: Record<string, PlannedAction>;
  clash: ClashResult | null;
  pops: DamagePop[];
  log: CombatLogLine[];
  banner: string | null;
  voice: string | null;
  specialMenu: boolean;
  powerCinematic: { name: string; voice: string; steps: string[] } | null;
  guard: { uid: string; until: number; result?: "perfect" | "normal" | "miss" } | null;
  bossPhase: number;
  bossPhases: number;
  ardenFights: boolean;
  ardenAwakened: boolean;
  combo: string[];
  usedCommandStrike: boolean;
  usedPower: Record<string, boolean>;
  objects: BattleSpec["objects"];
  seed: number;
  count: number;
  won: boolean;
  deployIds: string[];
}

let popN = 0;
let logN = 0;

function uid(prefix: string, i: number) {
  return `${prefix}-${i}`;
}

function abilityById(defId: string, abilityId: string): AbilityDef | undefined {
  const ch = CHAR_BY_ID[defId];
  if (ch) return ch.abilities.find((a) => a.id === abilityId);
  const en = ENEMY_BY_ID[defId];
  const fromEn = en?.abilities.find((a) => a.id === abilityId);
  if (fromEn) return fromEn;
  for (const v of Object.values(VARIANTS)) {
    if (v.extraAbility?.id === abilityId) return v.extraAbility;
  }
  return undefined;
}

function scaleStat(base: number, mult: number) {
  return Math.max(1, Math.round(base * mult));
}

function makeEnemy(baseId: string, variant: VariantKind, elite: boolean | undefined, index: number, spec: BattleSpec): Combatant {
  const def = ENEMY_BY_ID[baseId];
  const v = VARIANTS[variant];
  const hp = scaleStat(def.maxHp, v.hp) * (spec.bossPhases && baseId === "father" ? 1 : 1);
  return {
    uid: uid("e", index),
    defId: baseId,
    name: elite || variant === "elite" ? `Elite ${def.name}` : variant === "standard" ? def.name : `${v.label} ${def.name}`,
    side: "enemy",
    hp,
    maxHp: hp,
    break: scaleStat(def.breakMax, v.break),
    breakMax: scaleStat(def.breakMax, v.break),
    powerMeter: 0,
    formation: variant === "hunter" || variant === "support" ? "rear" : variant === "guardian" || variant === "armored" ? "front" : "middle",
    level: elite ? 4 : variant === "boss" ? 8 : 2,
    speed: scaleStat(def.speed, v.speed),
    defense: scaleStat(def.defense, v.def),
    clashBonus: scaleStat(def.clashBonus, v.clash),
    statuses: variant === "armored" ? [{ id: "armor-lock", duration: 3, stacks: 1 }] : [],
    variant,
    elite: Boolean(elite || variant === "elite"),
    hiddenClash: baseId === "father",
    acting: null,
    color: def.color,
    mark: def.mark.toUpperCase(),
  };
}

function makeAlly(id: string, save: SaveData, fights: boolean): Combatant | null {
  const def = CHAR_BY_ID[id];
  const fs = save.fighters[id];
  if (!def || !fs) return null;
  const levelBonus = Math.max(0, fs.level - 1);
  const maxHp = def.maxHp + levelBonus * 6 + (fs.equipment.defensive ? 8 : 0);
  const awakened = id === "arden" && (fights || save.flags.arden_awakened);
  return {
    uid: `a-${id}`,
    defId: id,
    name: awakened && id === "arden" ? "Arden (Awakened)" : def.name,
    side: "ally",
    hp: Math.min(fs.hp || maxHp, maxHp),
    maxHp,
    break: 0,
    breakMax: 0,
    powerMeter: 0,
    formation: fs.formation,
    level: fs.level,
    speed: def.speed,
    defense: def.defense + (fs.fatigue ? -2 : 0) + levelBonus,
    clashBonus: def.clashBonus + Math.floor(save.managerLevel / 4) + (fs.fatigue ? -2 : 0),
    statuses: fs.fatigue ? [{ id: "fatigue", duration: 99, stacks: 1 }] : [],
    hiddenClash: awakened && id === "arden",
    acting: null,
    color: def.color,
    mark: def.mark,
    role: def.role,
  };
}

export function startCombat(spec: BattleSpec, save: SaveData): CombatRuntime {
  const deploy = spec.deploy?.length ? spec.deploy : save.recruited.slice(0, 4);
  const allies = deploy
    .map((id) => makeAlly(id, save, Boolean(spec.ardenFights)))
    .filter((x): x is Combatant => Boolean(x))
    .slice(0, 5);
  if (allies.length === 0) {
    const rook = makeAlly("rook", save, false);
    if (rook) allies.push(rook);
  }
  const enemies = spec.enemies.map((e, i) => makeEnemy(e.base, e.variant, e.elite, i, spec));
  const seed = (save.rngSeed + save.rngCount * 17) >>> 0;
  return {
    title: spec.title,
    phase: "brief",
    round: 1,
    allies,
    enemies,
    weather: spec.weather ?? "none",
    anomaly: spec.anomalyStart ?? 10,
    momentum: 0,
    selected: null,
    plans: {},
    enemyPlans: {},
    clash: null,
    pops: [],
    log: [{ id: "l0", text: spec.title, tone: "neutral" }],
    banner: spec.title,
    voice: null,
    specialMenu: false,
    powerCinematic: null,
    guard: null,
    bossPhase: 1,
    bossPhases: spec.bossPhases ?? 1,
    ardenFights: Boolean(spec.ardenFights),
    ardenAwakened: false,
    combo: [],
    usedCommandStrike: false,
    usedPower: {},
    objects: spec.objects,
    seed,
    count: 0,
    won: false,
    deployIds: deploy,
  };
}

function rngOf(c: CombatRuntime) {
  const gen = mulberry32(c.seed + c.count * 97);
  c.count += 1;
  return gen;
}

function living(list: Combatant[]) {
  return list.filter((u) => u.hp > 0);
}

function findUnit(c: CombatRuntime, uid: string) {
  return c.allies.find((a) => a.uid === uid) || c.enemies.find((e) => e.uid === uid);
}

function hasStatus(u: Combatant, id: StatusId) {
  return u.statuses.some((s) => s.id === id && s.duration > 0);
}

function addStatus(u: Combatant, id: StatusId, duration: number, stacks = 1) {
  const existing = u.statuses.find((s) => s.id === id);
  if (existing) {
    existing.duration = Math.max(existing.duration, duration);
    existing.stacks = Math.min(3, existing.stacks + stacks);
  } else u.statuses.push({ id, duration, stacks });
}

function pop(c: CombatRuntime, uid: string, text: string, kind: DamagePop["kind"]) {
  popN += 1;
  c.pops = [...c.pops.slice(-12), { id: `p${popN}`, uid, text, kind }];
}

function log(c: CombatRuntime, text: string, tone: CombatLogLine["tone"] = "neutral") {
  logN += 1;
  c.log = [...c.log.slice(-18), { id: `g${logN}`, text, tone }];
}

function weatherClashMod(w: AnomalyWeather) {
  if (w === "red-storm") return 1;
  if (w === "eclipse") return 1;
  if (w === "silent-rain") return -1;
  return 0;
}

function dmgMod(c: CombatRuntime, attacker: Combatant, defender: Combatant, base: number, tags: string[]) {
  let n = base;
  n += Math.max(0, attacker.level - 1) * 2;
  if (hasStatus(defender, "mark")) n = Math.round(n * 1.2);
  if (hasStatus(defender, "vulnerable")) n = Math.round(n * 1.5);
  if (hasStatus(defender, "shatter")) n = Math.round(n * 1.35);
  if (hasStatus(defender, "armor-lock") && !tags.includes("heavy") && !tags.includes("impact")) n = Math.round(n * 0.45);
  if (hasStatus(attacker, "blood-rush")) n = Math.round(n * 1.2);
  if (c.weather === "gravity-shift" && tags.includes("pierce")) n = Math.round(n * 1.15);
  if (c.weather === "red-storm" && attacker.side === "enemy" && attacker.variant === "corrupted") n = Math.round(n * 1.15);
  n = Math.max(1, n - Math.floor(defender.defense / 4));
  return n;
}

function applyDamage(c: CombatRuntime, target: Combatant, amount: number, kind: DamagePop["kind"]) {
  const shielded = target.statuses.find((s) => s.id === "guard");
  let dmg = amount;
  if (shielded) dmg = Math.max(1, Math.round(dmg * 0.55));
  target.hp = Math.max(0, target.hp - dmg);
  pop(c, target.uid, `${kind === "crit" ? "CRITICAL " : kind === "break" ? "BREAK " : kind === "power" ? "POWER " : "HIT "}${dmg}`, kind);
  if (target.hp <= 0) log(c, `${target.name} falls.`, "good");
  return dmg;
}

function applyHeal(c: CombatRuntime, target: Combatant, amount: number) {
  if (hasStatus(target, "wither")) amount = Math.round(amount * 0.5);
  const n = Math.min(target.maxHp - target.hp, amount);
  target.hp += n;
  pop(c, target.uid, `+${n}`, "heal");
  return n;
}

function applyBreak(c: CombatRuntime, target: Combatant, amount: number) {
  if (target.breakMax <= 0) return;
  target.break = Math.max(0, target.break - amount);
  if (target.break === 0 && !hasStatus(target, "vulnerable")) {
    addStatus(target, "vulnerable", 1);
    pop(c, target.uid, "BREAK", "break");
    log(c, `${target.name} is broken — vulnerable.`, "clash");
  }
}

function pickEnemyAbility(e: Combatant, c: CombatRuntime): AbilityDef {
  const def = ENEMY_BY_ID[e.defId];
  const v = e.variant ? VARIANTS[e.variant] : undefined;
  const pool = [...(def?.abilities ?? [])];
  if (v?.extraAbility) pool.push(v.extraAbility);
  const gen = rngOf(c);
  const allies = living(c.allies);
  if (e.variant === "support" && living(c.enemies).some((x) => x.hp < x.maxHp * 0.6)) {
    const heal = pool.find((a) => a.heal);
    if (heal) return heal;
  }
  if (e.variant === "guardian") {
    const guard = pool.find((a) => a.shield || a.tags.includes("guard"));
    if (guard && living(c.enemies).some((x) => x.hp < x.maxHp * 0.5)) return guard;
  }
  if (e.variant === "hunter") {
    const hunt = pool.find((a) => a.tags.includes("hunt")) ?? pool[0];
    return hunt;
  }
  if (e.variant === "temporal") {
    const temporal = pool.find((a) => a.tags.includes("temporal") || a.status?.id === "delay");
    if (temporal) return temporal;
  }
  if (e.variant === "corrupted" || e.variant === "aberrant") {
    const anomaly = pool.find((a) => a.tags.includes("anomaly") || a.status);
    if (anomaly && c.anomaly >= 40) return anomaly;
  }
  if (e.variant === "armored") {
    const breaker = pool.find((a) => a.break >= 12);
    if (breaker) return breaker;
  }
  return pool[Math.min(pool.length - 1, Math.floor(gen() * pool.length))] ?? pool[0];
}

function pickEnemyTarget(e: Combatant, ability: AbilityDef, c: CombatRuntime): Combatant {
  const allies = living(c.allies);
  const enemies = living(c.enemies);
  if (ability.target === "self") return e;
  if (ability.target === "ally" || ability.target === "all-allies") {
    return enemies.sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp)[0] ?? e;
  }
  if (e.variant === "hunter") {
    const pref = allies.find((a) => a.role === "support" || a.role === "ranged" || a.formation === "rear") ?? allies[0];
    return pref;
  }
  if (e.variant === "guardian") {
    return allies.find((a) => a.formation === "front") ?? allies[0];
  }
  if (e.variant === "temporal") {
    return [...allies].sort((a, b) => b.speed - a.speed)[0] ?? allies[0];
  }
  if (e.variant === "ancient") {
    return [...allies].sort((a, b) => a.level - b.level)[0] ?? allies[0];
  }
  if (e.variant === "ravager" || hasStatus(e, "blood-rush")) {
    return [...allies].sort((a, b) => a.hp - b.hp)[0];
  }
  if (c.momentum >= 8) {
    const high = allies.find((a) => a.role === "duelist") ?? allies[0];
    return high;
  }
  const front = allies.find((a) => a.formation === "front");
  return front ?? allies[0];
}

export function telegraph(c: CombatRuntime): CombatRuntime {
  const next = { ...c, enemyPlans: { ...c.enemyPlans } };
  next.enemyPlans = {};
  for (const e of living(next.enemies)) {
    if (hasStatus(e, "vulnerable") || hasStatus(e, "overload")) continue;
    const ab = pickEnemyAbility(e, next);
    const t = pickEnemyTarget(e, ab, next);
    if (!t) continue;
    next.enemyPlans[e.uid] = {
      actorUid: e.uid,
      abilityId: ab.id,
      targetUid: t.uid,
      power: ab.power,
      clash: ab.clash,
      damage: ab.damage,
      name: ab.name,
    };
  }
  if (next.weather === "time-distortion") {
    log(next, "Time distortion — enemy markers echo.", "clash");
  }
  next.phase = "plan";
  next.banner = "Plan actions — drag an ability onto a target.";
  next.selected = null;
  next.plans = {};
  return next;
}

export function selectAbility(c: CombatRuntime, uid: string, abilityId: string): CombatRuntime {
  return { ...c, selected: { uid, abilityId }, specialMenu: false };
}

export function assignTarget(c: CombatRuntime, targetUid: string): CombatRuntime {
  if (!c.selected) return c;
  const actor = findUnit(c, c.selected.uid);
  if (!actor || actor.hp <= 0) return c;
  const ab = abilityById(actor.defId, c.selected.abilityId);
  if (!ab) return c;
  const target = findUnit(c, targetUid);
  if (!target) return c;
  const allyTarget = target.side === "ally";
  if (ab.target === "enemy" || ab.target === "all-enemies") {
    if (allyTarget) return c;
  } else if (ab.target === "ally" || ab.target === "all-allies" || ab.target === "lowest-ally") {
    if (!allyTarget) return c;
  }
  const plans = { ...c.plans, [actor.uid]: {
    actorUid: actor.uid,
    abilityId: ab.id,
    targetUid,
    power: ab.power,
    clash: ab.clash,
    damage: ab.damage,
    name: ab.name,
  } };
  const combo = [...c.combo, actor.defId].slice(-3);
  return { ...c, plans, selected: null, combo, banner: `${actor.name} → ${ab.name}` };
}

export function clearPlan(c: CombatRuntime, uid: string): CombatRuntime {
  const plans = { ...c.plans };
  delete plans[uid];
  return { ...c, plans };
}

function clashValue(c: CombatRuntime, u: Combatant, action: PlannedAction) {
  const gen = rngOf(c);
  const r = roll(gen, 1, 3);
  let v = action.clash + u.clashBonus + r + weatherClashMod(c.weather);
  if (hasStatus(u, "shock")) v -= 1;
  if (hasStatus(u, "fatigue")) v -= 2;
  if (c.momentum >= 6 && u.side === "ally") v += 1;
  if (u.hiddenClash) v += u.defId === "father" ? 6 : 3;
  return { total: v, roll: r };
}

function runClash(c: CombatRuntime, a: Combatant, pa: PlannedAction, b: Combatant, pb: PlannedAction): { winner: "a" | "b" | "tie"; result: ClashResult } {
  const rounds: ClashRound[] = [];
  let aw = 0;
  let bw = 0;
  const max = 3;
  for (let n = 1; n <= max; n++) {
    const av = clashValue(c, a, pa);
    const bv = clashValue(c, b, pb);
    const winner = av.total > bv.total ? "a" : bv.total > av.total ? "b" : "tie";
    rounds.push({ n, a: av.total, b: bv.total, winner });
    if (winner === "a") aw += 1;
    if (winner === "b") bw += 1;
    if (aw === 2 || bw === 2) break;
  }
  const winner = aw > bw ? "a" : bw > aw ? "b" : "tie";
  return {
    winner,
    result: {
      aName: a.name,
      bName: b.name,
      rounds,
      winner,
      aHidden: a.hiddenClash,
      bHidden: b.hiddenClash,
    },
  };
}

function resolveAction(c: CombatRuntime, actor: Combatant, action: PlannedAction, reduced: boolean) {
  const ab = abilityById(actor.defId, action.abilityId) ?? {
    id: action.abilityId, name: action.name, desc: "", target: "enemy" as const,
    power: action.power, clash: action.clash, break: 8, damage: action.damage, tags: [] as string[],
  };
  const targets: Combatant[] = [];
  if (ab.target === "all-enemies") targets.push(...living(actor.side === "ally" ? c.enemies : c.allies));
  else if (ab.target === "all-allies") targets.push(...living(actor.side === "ally" ? c.allies : c.enemies));
  else if (ab.target === "lowest-ally") {
    const pool = living(actor.side === "ally" ? c.allies : c.enemies);
    targets.push([...pool].sort((a, b) => a.hp - b.hp)[0]);
  } else if (ab.target === "self") targets.push(actor);
  else {
    const t = findUnit(c, action.targetUid);
    if (t && t.hp > 0) targets.push(t);
  }

  let total = 0;
  for (const t of targets) {
    if (ab.heal) applyHeal(c, t, reduced ? Math.round(ab.heal * 0.6) : ab.heal);
    if (ab.shield) addStatus(t, "guard", 1);
    if (ab.damage > 0 && t.uid !== actor.uid) {
      let dmg = dmgMod(c, actor, t, ab.damage, ab.tags);
      if (reduced) dmg = Math.round(dmg * 0.5);
      const crit = ab.finisher && (hasStatus(t, "vulnerable") || hasStatus(t, "mark"));
      if (crit) dmg = Math.round(dmg * 1.8);
      total += applyDamage(c, t, dmg, crit ? "crit" : "hit");
      if (ab.break) applyBreak(c, t, reduced ? Math.round(ab.break * 0.6) : ab.break);
      if (ab.status) addStatus(t, ab.status.id, ab.status.duration, ab.status.stacks ?? 1);
      if (hasStatus(t, "shock") && hasStatus(t, "mark")) {
        addStatus(t, "overload", 1);
        log(c, `Overload on ${t.name}.`, "clash");
      }
      if (hasStatus(t, "frost") && hasStatus(t, "impact")) {
        addStatus(t, "shatter", 1);
        log(c, `Shatter on ${t.name}.`, "clash");
      }
    }
    if (ab.interrupt && t.side !== actor.side) {
      delete (actor.side === "ally" ? c.enemyPlans : c.plans)[t.uid];
      pop(c, t.uid, "INTERRUPT", "break");
    }
  }
  if (ab.id === "sera-wind" || ab.id === "sera-mend") {
    /* heal already applied */
  }
  actor.powerMeter = Math.min(100, actor.powerMeter + 18 + Math.floor(total / 8));
  if (actor.side === "ally") c.momentum = Math.min(12, c.momentum + 1);
  return total;
}

function tickStatuses(list: Combatant[], c: CombatRuntime) {
  for (const u of list) {
    const toxin = u.statuses.find((s) => s.id === "toxin");
    if (toxin && u.hp > 0) applyDamage(c, u, 3 * toxin.stacks, "hit");
    u.statuses = u.statuses
      .map((s) => ({ ...s, duration: s.duration - 1 }))
      .filter((s) => s.duration > 0);
  }
}

function maybeBossPhase(c: CombatRuntime) {
  const father = c.enemies.find((e) => e.defId === "father");
  if (!father || c.bossPhases < 2) return;
  const pct = father.hp / father.maxHp;
  let phase = 1;
  if (pct <= 0.24) phase = 5;
  else if (pct <= 0.42) phase = 4;
  else if (pct <= 0.58) phase = 3;
  else if (pct <= 0.76) phase = 2;
  if (phase === c.bossPhase) return;
  c.bossPhase = phase;
  if (phase === 2) {
    c.weather = "red-storm";
    c.anomaly = Math.min(100, c.anomaly + 25);
    log(c, "The vault distorts. Red energy. Turn order slips.", "bad");
    c.banner = "Phase 2 — Distortion";
  }
  if (phase === 3) {
    log(c, "Resonance answers whether you asked or not.", "clash");
    c.banner = "Phase 3 — Synchronization";
    c.voice = "You still don't understand what is coming.";
  }
  if (phase === 4) {
    c.ardenAwakened = true;
    const arden = c.allies.find((a) => a.defId === "arden");
    if (arden) {
      arden.name = "Arden (Awakened)";
      arden.hiddenClash = true;
      arden.clashBonus += 6;
      arden.maxHp += 30;
      arden.hp = Math.min(arden.maxHp, arden.hp + 40);
      arden.powerMeter = 100;
    } else {
      /* join */
    }
    log(c, "AWAKENING — MAYONIN RESONANCE — BEYOND LIMIT — CLASH ???", "power");
    c.banner = "Awakened Arden — Clash ???";
    c.voice = "This ends here.";
  }
  if (phase === 5) {
    father.clashBonus += 4;
    father.defense += 4;
    c.weather = "eclipse";
    log(c, "He was already Beyond. The awakening only let you see the scale.", "bad");
    c.banner = "Phase 5 — Still above";
  }
}

export function commitRound(c: CombatRuntime): CombatRuntime {
  const next: CombatRuntime = {
    ...c,
    allies: c.allies.map((a) => ({ ...a, statuses: a.statuses.map((s) => ({ ...s })) })),
    enemies: c.enemies.map((e) => ({ ...e, statuses: e.statuses.map((s) => ({ ...s })) })),
    plans: { ...c.plans },
    enemyPlans: { ...c.enemyPlans },
    phase: "resolve",
  };

  const allyActs = Object.values(next.plans);
  const clashPairs: { a: Combatant; pa: PlannedAction; b: Combatant; pb: PlannedAction }[] = [];
  const consumed = new Set<string>();

  for (const pa of allyActs) {
    const actor = findUnit(next, pa.actorUid);
    const target = findUnit(next, pa.targetUid);
    if (!actor || !target) continue;
    const pb = next.enemyPlans[target.uid];
    if (pb && pb.targetUid === actor.uid && !consumed.has(actor.uid) && !consumed.has(target.uid)) {
      clashPairs.push({ a: actor, pa, b: target, pb });
      consumed.add(actor.uid);
      consumed.add(target.uid);
    }
  }

  if (clashPairs.length) {
    const pair = clashPairs[0];
    const { winner, result } = runClash(next, pair.a, pair.pa, pair.b, pair.pb);
    next.clash = result;
    next.phase = "clash";
    next.banner = winner === "a" ? "CLASH WON" : winner === "b" ? "CLASH LOST" : "CLASH TIED";
    if (winner === "a") {
      next.momentum = Math.min(12, next.momentum + 2);
      resolveAction(next, pair.a, pair.pa, false);
      log(next, `${pair.a.name} wins the Clash.`, "good");
    } else if (winner === "b") {
      next.momentum = Math.max(0, next.momentum - 2);
      resolveAction(next, pair.b, pair.pb, false);
      log(next, `${pair.b.name} wins the Clash.`, "bad");
    } else {
      resolveAction(next, pair.a, pair.pa, true);
      resolveAction(next, pair.b, pair.pb, true);
    }
    delete next.plans[pair.a.uid];
    delete next.enemyPlans[pair.b.uid];
  }

  const order = [
    ...living(next.allies).map((u) => ({ u, action: next.plans[u.uid], speed: u.speed + (next.weather === "time-distortion" ? -1 : 0) })),
    ...living(next.enemies).map((u) => ({ u, action: next.enemyPlans[u.uid], speed: u.speed })),
  ]
    .filter((x) => x.action)
    .sort((a, b) => b.speed - a.speed);

  for (const step of order) {
    if (step.u.hp <= 0) continue;
    if (hasStatus(step.u, "overload") || hasStatus(step.u, "vulnerable") && step.u.side === "enemy") continue;
    resolveAction(next, step.u, step.action as PlannedAction, false);
  }

  if (next.combo.join(">") === "mira>rook>vale") {
    const t = living(next.enemies)[0];
    if (t) {
      applyDamage(next, t, 22, "crit");
      log(next, "COMBO FINISHER — Covered Collapse", "power");
      next.banner = "COMBO FINISHER";
    }
  }

  if (next.momentum >= 10) {
    log(next, "MOMENTUM SURGE — next clash +2.", "power");
  }

  next.anomaly = Math.min(100, next.anomaly + (next.weather !== "none" ? 4 : 2));
  if (next.anomaly >= 80 && next.weather === "none") {
    next.weather = "red-storm";
    log(next, "ANOMALY EVENT — Red Storm.", "bad");
  }

  tickStatuses(next.allies, next);
  tickStatuses(next.enemies, next);
  maybeBossPhase(next);

  const alliesAlive = living(next.allies).length > 0;
  const enemiesAlive = living(next.enemies).length > 0;
  if (!enemiesAlive) {
    next.phase = "victory";
    next.won = true;
    next.banner = "Victory";
    return next;
  }
  if (!alliesAlive) {
    next.phase = "defeat";
    next.won = false;
    next.banner = "Defeat";
    return next;
  }
  if (next.phase === "clash") return next;
  next.round += 1;
  next.plans = {};
  next.combo = [];
  next.selected = null;
  return telegraph(next);
}

export function afterClash(c: CombatRuntime): CombatRuntime {
  if (c.phase === "victory" || c.phase === "defeat") return c;
  const next = telegraph({
    ...c,
    clash: null,
    round: c.round + 1,
    plans: {},
    combo: [],
    selected: null,
  });
  next.banner = `Round ${next.round}`;
  return next;
}

export function activatePower(c: CombatRuntime, uid: string): CombatRuntime {
  const actor = findUnit(c, uid);
  if (!actor || actor.side !== "ally" || actor.powerMeter < 100 || c.usedPower[uid]) return c;
  const def = CHAR_BY_ID[actor.defId];
  if (!def) return c;
  const next: CombatRuntime = {
    ...c,
    allies: c.allies.map((a) => ({ ...a, statuses: a.statuses.map((s) => ({ ...s })) })),
    enemies: c.enemies.map((e) => ({ ...e, statuses: e.statuses.map((s) => ({ ...s })) })),
    usedPower: { ...c.usedPower, [uid]: true },
    phase: "power",
  };
  const self = findUnit(next, uid)!;
  self.powerMeter = 0;
  const target = living(next.enemies)[0];
  const steps: string[] = [];
  if (def.power.cinematic === "slam") {
    steps.push("DAMAGE 12", "DAMAGE 27", "DAMAGE 41", "DAMAGE 58", "DAMAGE 76", "DAMAGE 103", "TOTAL DAMAGE 103");
  } else if (def.power.cinematic === "imperial") {
    steps.push("RESONANCE", "CRIMSON EDGE", "IMPACT", `DAMAGE ${def.power.damage}`, "RESONANCE COLLAPSE");
  } else {
    steps.push(def.power.name, `DAMAGE ${def.power.damage}`);
  }
  next.powerCinematic = { name: def.power.name, voice: def.power.voice, steps };
  next.voice = def.power.voice;
  next.banner = def.power.name;
  log(next, `${self.name}: “${def.power.voice}”`, "power");
  if (def.power.damage === 0) {
    for (const a of living(next.allies)) applyHeal(next, a, 22);
  } else if (target) {
    applyDamage(next, target, def.power.damage, "power");
    applyBreak(next, target, def.power.break);
  }
  maybeBossPhase(next);
  const enemiesAlive = living(next.enemies).length > 0;
  if (!enemiesAlive) {
    next.phase = "victory";
    next.won = true;
  }
  return next;
}

export function endPower(c: CombatRuntime): CombatRuntime {
  if (c.phase === "victory" || c.phase === "defeat") return { ...c, powerCinematic: null, voice: null };
  return { ...c, phase: "plan", powerCinematic: null, voice: null };
}

export function ardenSpecial(c: CombatRuntime, id: string, unlocked: string[]): CombatRuntime {
  if (!unlocked.includes(id) && id !== "command-strike") {
    /* allow command-strike if unlocked list contains it */
  }
  if (!unlocked.includes(id)) return c;
  const next: CombatRuntime = {
    ...c,
    allies: c.allies.map((a) => ({ ...a, statuses: a.statuses.map((s) => ({ ...s })) })),
    enemies: c.enemies.map((e) => ({ ...e, statuses: e.statuses.map((s) => ({ ...s })) })),
    specialMenu: false,
    phase: "special",
  };
  if (id === "command-strike") {
    if (next.usedCommandStrike) return c;
    next.usedCommandStrike = true;
    const sequence: string[] = ["ARDEN MARKS TARGET"];
    log(next, "COMMAND STRIKE — Arden gives one order to the entire squad.", "power");
    for (const a of living(next.allies)) {
      const t = living(next.enemies)[0];
      if (!t) break;
      const def = CHAR_BY_ID[a.defId];
      const ab = def?.abilities[0];
      sequence.push(a.name.toUpperCase());
      if (ab && ab.damage) {
        const before = t.hp;
        applyDamage(next, t, Math.round(ab.damage * 0.85), "power");
        const dealt = Math.max(0, before - t.hp);
        log(next, `${a.name} follows through for ${dealt} damage.`, "power");
      }
    }
    next.powerCinematic = {
      name: "COMMAND STRIKE",
      voice: "Move. One opening. Everyone takes it.",
      steps: [...sequence, "COMMAND STRIKE COMPLETE"],
    };
  }
  if (id === "time-fracture") {
    for (const e of living(next.enemies)) addStatus(e, "delay", 1);
    log(next, "TIME FRACTURE — enemies delayed.", "clash");
  }
  if (id === "tactical-shift") {
    for (const a of next.allies) {
      a.formation = a.formation === "front" ? "rear" : a.formation === "rear" ? "middle" : "front";
    }
    log(next, "TACTICAL SHIFT — formation rotated.", "neutral");
  }
  if (id === "void-command") {
    next.anomaly = Math.max(0, next.anomaly - 30);
    for (const e of living(next.enemies)) {
      delete next.enemyPlans[e.uid];
    }
    log(next, "VOID COMMAND — anomaly down, telegraphs cut.", "clash");
  }
  if (id === "reversal") {
    next.momentum = Math.min(12, next.momentum + 6);
    log(next, "REVERSAL — momentum stolen.", "power");
  }
  next.banner = id.replace("-", " ").toUpperCase();
  maybeBossPhase(next);
  if (living(next.enemies).length === 0) {
    next.phase = "victory";
    next.won = true;
  } else if (id === "command-strike") {
    next.phase = "power";
  } else next.phase = "plan";
  return next;
}

export function newVariantKeys(c: CombatRuntime): string[] {
  const keys: string[] = [];
  for (const e of c.enemies) keys.push(`${e.defId}:${e.variant ?? "standard"}`);
  return keys;
}
