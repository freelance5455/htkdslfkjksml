import { CONFIG } from './config'

/** Pure scoring and run-state rules (unit tested). Scene code reports events; this decides the numbers. */
export type RunPhase = 'idle' | 'flying' | 'crashed'

export type RunState = {
  phase: RunPhase
  rings: number
  missed: number
  score: number
  streak: number
  multiplier: number
  /** Metres flown. */
  distance: number
  /** Seconds flown. */
  seconds: number
  /** Highest altitude above sea level reached (m). */
  maxAltitude: number
  cause: 'terrain' | 'water' | null
  /** True when tuning values differ from the shipped defaults, so the result is not a record. */
  unranked: boolean
}

export function createRun(unranked = false): RunState {
  return { phase: 'idle', rings: 0, missed: 0, score: 0, streak: 0, multiplier: 1, distance: 0, seconds: 0, maxAltitude: 0, cause: null, unranked }
}

/** Multiplier grows with consecutive rings: ×1, ×2 after 3, ×3 after 6, ×4 after 9. */
export function multiplierFor(streak: number): number {
  return Math.min(4, 1 + Math.floor(streak / 3))
}

/** Score a ring pass. `centering` is 1 through the middle and 0 at the rim. Returns the points awarded. */
export function applyRingPass(run: RunState, centering: number): { points: number; perfect: boolean } {
  const perfect = centering >= 0.7
  const base = CONFIG.rings.points + (perfect ? CONFIG.rings.perfectBonus : 0)
  const points = base * run.multiplier
  run.rings += 1
  run.streak += 1
  run.score += points
  run.multiplier = multiplierFor(run.streak)
  return { points, perfect }
}

export function applyRingMiss(run: RunState): void {
  run.missed += 1
  run.streak = 0
  run.multiplier = 1
}

export function formatClock(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds))
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}

export function formatDistance(metres: number): string {
  return metres >= 1000 ? `${(metres / 1000).toFixed(1)} km` : `${Math.round(metres)} m`
}

export function isBetter(run: Pick<RunState, 'score' | 'distance'>, best: { score: number; distance: number }): boolean {
  return run.score > best.score || (run.score === best.score && run.distance > best.distance)
}

/** Cardinal letters in Spanish (O = Oeste). */
export function cardinal(heading: number): string {
  const names = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO']
  return names[Math.round((((heading % 360) + 360) % 360) / 45) % 8]
}
