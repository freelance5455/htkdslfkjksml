import { DifficultyLevel } from '../difficulty/DifficultyManager';

export interface ZombieMatchSettings {
  healthMultiplier: number;  // 0.5 - 2.5 (1.0 default)
  damageMultiplier: number;  // 0.5 - 2.5 (1.0 default)
  speedMultiplier: number;   // 0.8 - 1.2 (1.0 default - realistically controlled zombie pace)
  intelligence: 'basic' | 'normal' | 'tactical';
  spawnRate: 'slow' | 'normal' | 'fast';
  zombiesPerWave: number;    // 10 - 45 (24 default)
  specialZombies: boolean;   // Brutes & Runners enabled
  progressiveScaling: boolean;
}

export type AdsBehaviorMode = 'tap' | 'hold' | 'hybrid';

export interface PlayerMatchSettings {
  health: number;            // default 250 HP (150 - 500)
  armor: number;             // default 50 (0 - 150)
  startingWeapon: string;    // 'rifle' | 'shotgun' | 'pistol' | 'sniper' | 'smg'
  startingAmmoMultiplier: number; // 1.0 - 2.0
  movementSpeedMultiplier: number; // 0.8 - 1.3
  autoSprint: boolean;
  slideMechanic: boolean;
  sensitivity: number;
  adsSensitivity: number;
  sniperSensitivity: number;
  opticSensitivity: number;
  adsBehavior: AdsBehaviorMode;
}

export interface MatchConfiguration {
  mapId: string;
  difficulty: DifficultyLevel;
  zombieSettings: ZombieMatchSettings;
  playerSettings: PlayerMatchSettings;
  operatorId: string;
  primaryWeaponId: string;
  secondaryWeaponId: string;
}

export const DEFAULT_ZOMBIE_SETTINGS: Record<DifficultyLevel, ZombieMatchSettings> = {
  easy: {
    healthMultiplier: 0.7,
    damageMultiplier: 0.65,
    speedMultiplier: 0.9,
    intelligence: 'basic',
    spawnRate: 'slow',
    zombiesPerWave: 16,
    specialZombies: true,
    progressiveScaling: true,
  },
  normal: {
    healthMultiplier: 1.0,
    damageMultiplier: 1.0,
    speedMultiplier: 1.0,
    intelligence: 'normal',
    spawnRate: 'normal',
    zombiesPerWave: 24,
    specialZombies: true,
    progressiveScaling: true,
  },
  hard: {
    healthMultiplier: 1.35,
    damageMultiplier: 1.3,
    speedMultiplier: 1.1,
    intelligence: 'tactical',
    spawnRate: 'fast',
    zombiesPerWave: 30,
    specialZombies: true,
    progressiveScaling: true,
  },
  custom: {
    healthMultiplier: 1.0,
    damageMultiplier: 1.0,
    speedMultiplier: 1.0,
    intelligence: 'normal',
    spawnRate: 'normal',
    zombiesPerWave: 24,
    specialZombies: true,
    progressiveScaling: true,
  },
};

export const DEFAULT_PLAYER_SETTINGS: PlayerMatchSettings = {
  health: 250, // Requirement: default 250 HP
  armor: 50,
  startingWeapon: 'rifle',
  startingAmmoMultiplier: 1.0,
  movementSpeedMultiplier: 1.0,
  autoSprint: true,
  slideMechanic: true,
  sensitivity: 1.0,
  adsSensitivity: 0.6,
  sniperSensitivity: 0.45,
  opticSensitivity: 0.55,
  adsBehavior: 'hybrid',
};

const STORAGE_KEY = 'blackout_match_config';

export class MatchSettingsManager {
  private static currentConfig: MatchConfiguration | null = null;

  static get(): MatchConfiguration {
    if (this.currentConfig) return this.currentConfig;

    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        this.currentConfig = JSON.parse(saved);
        return this.currentConfig!;
      }
    } catch {
      // Ignore
    }

    this.currentConfig = {
      mapId: 'suburban',
      difficulty: 'normal',
      zombieSettings: { ...DEFAULT_ZOMBIE_SETTINGS.normal },
      playerSettings: { ...DEFAULT_PLAYER_SETTINGS },
      operatorId: 'specter',
      primaryWeaponId: 'rifle',
      secondaryWeaponId: 'pistol',
    };

    return this.currentConfig;
  }

  static save(cfg: Partial<MatchConfiguration>) {
    const existing = this.get();
    this.currentConfig = { ...existing, ...cfg };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.currentConfig));
    } catch {
      // Ignore
    }
  }

  static applyDifficultyPreset(lvl: DifficultyLevel): ZombieMatchSettings {
    const zSettings = { ...DEFAULT_ZOMBIE_SETTINGS[lvl] };
    this.save({ difficulty: lvl, zombieSettings: zSettings });
    return zSettings;
  }
}
