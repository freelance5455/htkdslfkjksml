export type DeviceProfileType = 'automatic' | 'low_end' | 'medium_end' | 'high_end' | 'flagship';

export interface DeviceProfileConfig {
  profile: DeviceProfileType;
  fpsLimit: number; // 30, 40, 45, 60, 90, 120
  highFpsMode: boolean;
  resolutionScale: number;
  shadowQuality: 'off' | 'low' | 'medium' | 'high' | 'ultra';
  shadowDistance: 'low' | 'medium' | 'high';
  waterQuality: 'low' | 'medium' | 'high' | 'ultra';
  reflectionQuality: 'off' | 'low' | 'medium' | 'high';
  cloudQuality: 'low' | 'medium' | 'high';
  volumetricEffects: 'off' | 'low' | 'high';
  viewDistance: 'low' | 'medium' | 'high' | 'ultra';
}

export const DEVICE_PROFILES: Record<DeviceProfileType, DeviceProfileConfig> = {
  automatic: {
    profile: 'automatic',
    fpsLimit: 60,
    highFpsMode: true,
    resolutionScale: 0.7,
    shadowQuality: 'low',
    shadowDistance: 'low',
    waterQuality: 'medium',
    reflectionQuality: 'low',
    cloudQuality: 'medium',
    volumetricEffects: 'low',
    viewDistance: 'medium',
  },
  low_end: {
    profile: 'low_end',
    fpsLimit: 30,
    highFpsMode: true,
    resolutionScale: 0.5, // 360p
    shadowQuality: 'low',
    shadowDistance: 'low',
    waterQuality: 'low',
    reflectionQuality: 'off',
    cloudQuality: 'low',
    volumetricEffects: 'low',
    viewDistance: 'low',
  },
  medium_end: {
    profile: 'medium_end',
    fpsLimit: 60,
    highFpsMode: false,
    resolutionScale: 0.7, // 480p
    shadowQuality: 'medium',
    shadowDistance: 'medium',
    waterQuality: 'medium',
    reflectionQuality: 'medium',
    cloudQuality: 'medium',
    volumetricEffects: 'low',
    viewDistance: 'medium',
  },
  high_end: {
    profile: 'high_end',
    fpsLimit: 90,
    highFpsMode: false,
    resolutionScale: 0.85, // 720p
    shadowQuality: 'high',
    shadowDistance: 'medium',
    waterQuality: 'high',
    reflectionQuality: 'high',
    cloudQuality: 'high',
    volumetricEffects: 'high',
    viewDistance: 'high',
  },
  flagship: {
    profile: 'flagship',
    fpsLimit: 120,
    highFpsMode: false,
    resolutionScale: 1.0, // Native 1080p
    shadowQuality: 'ultra',
    shadowDistance: 'high',
    waterQuality: 'ultra',
    reflectionQuality: 'high',
    cloudQuality: 'high',
    volumetricEffects: 'high',
    viewDistance: 'ultra',
  },
};

export const PROFILE_EXPLANATIONS: Record<DeviceProfileType, { title: string; desc: string; targetFps: string }> = {
  automatic: {
    title: 'Automatic Detection',
    desc: 'Dynamically scales rendering parameters based on real-time device load.',
    targetFps: 'Target: Stable 60 FPS',
  },
  low_end: {
    title: 'Low-End Android / Budget Hardware',
    desc: 'Optimized for lower-powered devices. Prioritizes stable FPS and responsive controls.',
    targetFps: 'Target: 30–60 FPS (360p Render)',
  },
  medium_end: {
    title: 'Medium-End Hardware',
    desc: 'Balanced visual quality and performance with standard shadows and effects.',
    targetFps: 'Target: 60 FPS (480p–720p Render)',
  },
  high_end: {
    title: 'High-End Hardware',
    desc: 'Enhanced visuals with higher rendering quality, detailed lighting and reflections.',
    targetFps: 'Target: 60–90 FPS (720p–1080p Render)',
  },
  flagship: {
    title: 'Flagship Device / High-End PC',
    desc: 'Maximum supported visual quality and performance with uncapped fidelity.',
    targetFps: 'Target: 90–120 FPS (Native 1080p)',
  },
};

const STORAGE_KEY = 'blackout_persistent_device_profile';

export class DeviceProfileManager {
  private static cachedConfig: DeviceProfileConfig | null = null;

  static get(): DeviceProfileConfig {
    if (this.cachedConfig) return this.cachedConfig;

    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        this.cachedConfig = JSON.parse(saved);
        return this.cachedConfig!;
      }
    } catch {
      // Fallback
    }

    // Default on first launch: low_end (360p) for rock-solid initial performance
    this.cachedConfig = { ...DEVICE_PROFILES.low_end };
    this.save(this.cachedConfig);
    return this.cachedConfig;
  }

  static save(cfg: DeviceProfileConfig) {
    this.cachedConfig = { ...cfg };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
    } catch {
      // Ignore
    }
  }

  static setProfile(type: DeviceProfileType): DeviceProfileConfig {
    const template = DEVICE_PROFILES[type];
    const newConfig = { ...template };
    this.save(newConfig);
    return newConfig;
  }

  static resetToAutomatic(): DeviceProfileConfig {
    return this.setProfile('automatic');
  }
}
