import { getWorld, TOTAL_LEVELS, type World } from "./data";

export type SectorKind = "break" | "gem" | "solid";
export type LayerVariant = "normal" | "glass" | "shield" | "gem";

export type LayerDef = {
  sectors: SectorKind[];
  rot: number;
  speed: number;
  dir: 1 | -1;
  variant: LayerVariant;
};

export type LevelDef = {
  number: number;
  world: World;
  layers: LayerDef[];
  targetTime: number;
  codeName: string;
  isBoss: boolean;
  solidCount: number;
  gemCount: number;
  totalDepth: number;
};

function mulberry32(seed: number) {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

const ADJECTIVES = [
  "Fracture", "Neon", "Rapid", "Silent", "Broken", "Zero", "Hyper", "Midnight",
  "Crystal", "Static", "Lucid", "Rogue", "Prime", "Turbo", "Hollow", "Velvet",
  "Chrome", "Feral", "Solar", "Lunar",
];
const NOUNS = [
  "Drift", "Cascade", "Descent", "Pulse", "Fault", "Orbit", "Spiral", "Shard",
  "Sprint", "Echo", "Current", "Breach", "Rush", "Signature", "Line", "Gate",
  "Theory", "Riot", "Bloom", "Core",
];

export function codeNameFor(level: number): string {
  const a = ADJECTIVES[(level * 7 + 3) % ADJECTIVES.length];
  const b = NOUNS[(level * 11 + 5) % NOUNS.length];
  return `${a} ${b}`;
}

export const clampLevel = (n: number) => Math.min(TOTAL_LEVELS, Math.max(1, Math.round(n || 1)));

export function getLevel(levelNumber: number): LevelDef {
  const number = clampLevel(levelNumber);
  const world = getWorld(number);
  const rng = mulberry32(number * 2654435761 + 97);
  const progress = (number - 1) / (TOTAL_LEVELS - 1);
  const isBoss = number % 100 === 0;
  const isGlass = number % 17 === 0 && !isBoss;
  const isGemRound = number % 13 === 0;
  const isRapid = number % 25 === 0;

  const baseLayers = Math.round(26 + Math.pow(progress, 0.62) * 42);
  const totalDepth = Math.min(
    78,
    baseLayers + (isBoss ? 6 : 0) + (number % 10 === 0 ? 2 : 0),
  );

  const sectorCount = number < 40 ? 10 : number < 600 ? 12 : 14;
  const solidsTarget = Math.max(
    1,
    Math.round(2.4 + progress * 4.6 + (rng() - 0.5) * 1.4) +
      (isBoss ? 2 : 0) -
      (isGlass ? 2 : 0),
  );
  const maxSolids = sectorCount - 4;
  const solidTarget = Math.min(maxSolids, solidsTarget);

  const rotationBase = 15 + progress * 112 + (isRapid ? 22 : 0) + (isBoss ? 18 : 0);

  const layers: LayerDef[] = [];
  let gemTotal = 0;
  let solidTotal = 0;

  for (let i = 0; i < totalDepth; i += 1) {
    const earlyTutorial = number <= 6 && i < Math.ceil(totalDepth * 0.45);
    const sectors: SectorKind[] = new Array(sectorCount).fill("break");

    let solids = earlyTutorial ? 0 : solidTarget;
    if (!earlyTutorial && i % 9 === 8) solids += 1;
    if (isGlass) solids = Math.max(1, solids - 2);
    solids = Math.min(maxSolids, Math.max(0, solids));

    // Scatter unbreakable plates. Occasionally pair them up to create a wall.
    const used = new Set<number>();
    let guard = 0;
    while (used.size < solids && guard < 80) {
      guard += 1;
      const idx = Math.floor(rng() * sectorCount);
      if (used.has(idx)) continue;
      used.add(idx);
      sectors[idx] = "solid";
      if (progress > 0.28 && rng() < 0.32 && used.size < solids) {
        const neighbor = (idx + (rng() < 0.5 ? 1 : sectorCount - 1)) % sectorCount;
        if (!used.has(neighbor)) {
          used.add(neighbor);
          sectors[neighbor] = "solid";
        }
      }
    }

    let gems = 0;
    if (isGemRound) gems = 2;
    else if (!earlyTutorial && rng() < 0.22) gems = 1;
    for (let g = 0; g < gems; g += 1) {
      const slot = Math.floor(rng() * sectorCount);
      if (sectors[slot] === "break") sectors[slot] = "gem";
    }
    gemTotal += gems;
    solidTotal += sectors.filter((s) => s === "solid").length;

    const speedJitter = 0.82 + rng() * 0.5;
    const speed =
      (rotationBase + (i % 4) * 4.5 + (isRapid ? 12 : 0)) * speedJitter;

    layers.push({
      sectors,
      rot: rng() * 360,
      speed: Math.min(210, speed),
      dir: rng() < 0.5 ? 1 : -1,
      variant:
        gems > 0 ? "gem" : solids >= 4 ? "shield" : solids <= 1 ? "glass" : "normal",
    });
  }

  const targetTime = Math.round(totalDepth * (isRapid ? 0.62 : 0.78) + 6);

  return {
    number,
    world,
    layers,
    targetTime,
    codeName: codeNameFor(number),
    isBoss,
    solidCount: solidTotal,
    gemCount: gemTotal,
    totalDepth,
  };
}

export function starsFor(bounces: number): 1 | 2 | 3 {
  if (bounces === 0) return 3;
  if (bounces <= 3) return 2;
  return 1;
}

export function scoreFor(params: {
  layers: number;
  maxCombo: number;
  bounces: number;
  timeSeconds: number;
  targetTime: number;
  stars: number;
}): number {
  const { layers, maxCombo, bounces, timeSeconds, targetTime, stars } = params;
  const smashScore = layers * 100 + maxCombo * 45;
  const timeBonus = Math.max(0, Math.round((targetTime * 2.2 - timeSeconds) * 35));
  const bounceBonus = Math.max(0, 650 - bounces * 90);
  const finishBonus = 500 + stars * 250;
  return Math.round(smashScore + timeBonus + bounceBonus + finishBonus);
}

export function coinRewardFor(stars: number, level: number, bounced: number): number {
  const base = 10 + stars * 6 + Math.floor(level / 25);
  const bouncePenalty = Math.min(base - 2, Math.max(0, bounced - 2) * 2);
  return Math.max(2, base - bouncePenalty);
}

export function levelScoreMultiplier(level: number) {
  return 1 + (level - 1) * 0.035;
}

export function dayKey(date = new Date()): string {
  const y = date.getFullYear();
  const m = `${date.getMonth() + 1}`.padStart(2, "0");
  const d = `${date.getDate()}`.padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function getDailyLevel(date = new Date()): number {
  const key = Number(dayKey(date).replace(/-/g, ""));
  const rng = mulberry32(key * 7919 + 17);
  return 101 + Math.floor(rng() * (TOTAL_LEVELS - 200));
}

export function dailySeed(date = new Date()): string {
  return dayKey(date);
}
