/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ArrowConfig, LevelData, Point } from './types';
import {
  createShapeTemplatePolygon,
  generatePolylineMaze,
  PresetShapeType,
  sampleGridCellsFromPolygon,
} from './generator';
import { getDifficultyProfile, getDifficultyTierForLevel } from './difficulty';
import { validateAndEvaluatePuzzle } from './solver';

function buildShapedCampaignLevel(
  levelNumber: number,
  title: string,
  shape: PresetShapeType,
  gridDim: number,
  seed: number,
  minLength: number,
  maxLength: number,
  turnBias: number
): LevelData {
  const poly = createShapeTemplatePolygon(shape);
  const maskCells: Point[] = sampleGridCellsFromPolygon(poly, gridDim, gridDim);
  const profile = getDifficultyProfile(levelNumber);

  let bestArrows: ArrowConfig[] = [];
  let bestScore = -Infinity;

  for (let attempt = 0; attempt < 16; attempt++) {
    const candidate = generatePolylineMaze(maskCells, {
      seed: seed + attempt * 997,
      minLength,
      maxLength,
      turnBias,
      idPrefix: `lvl${levelNumber}_${attempt}`,
    });

    const check = validateAndEvaluatePuzzle(candidate);
    if (!check.valid || !check.metrics.solvable) continue;

    const m = check.metrics;
    const score =
      m.complexityScore +
      m.blockedRatio * 55 +
      m.waveDepth * 10 +
      m.avgTurnsPerArrow * 20;

    if (score > bestScore) {
      bestScore = score;
      bestArrows = candidate;
    }

    if (
      m.arrowCount >= profile.minArrows &&
      m.blockedRatio >= profile.minBlockedRatio &&
      m.waveDepth >= profile.minWaveDepth &&
      m.complexityScore >= profile.minComplexityScore
    ) {
      break;
    }
  }

  let maxX = 3;
  let maxY = 3;
  for (const a of bestArrows) {
    const pts = a.path || [{ x: a.x, y: a.y }];
    for (const p of pts) {
      if (p.x > maxX) maxX = p.x;
      if (p.y > maxY) maxY = p.y;
    }
  }

  return {
    id: levelNumber,
    levelNumber,
    title,
    difficulty: getDifficultyTierForLevel(levelNumber),
    gridWidth: maxX + 1,
    gridHeight: maxY + 1,
    arrows: bestArrows,
    isCustomDrawn: false,
    shapeType: shape,
  };
}

/**
 * 10 Original, Progressively Challenging Dense Irregular Arrow Maze Levels
 * Levels 1–5: Easy
 * Levels 6–10: Normal
 * (Levels 11–20: Medium, 21–30: Hard, 31–50: Very Hard, 51–100: Expert,
 *  101–500: Master, 501–1000: Insane, 1001+: Ultimate)
 */
export const INITIAL_LEVELS: LevelData[] = [
  buildShapedCampaignLevel(1, 'First Flight', 'shield', 7, 1011, 2, 4, 0.58),
  buildShapedCampaignLevel(2, 'Lunar Arc', 'crescent', 11, 2029, 2, 5, 0.62),
  buildShapedCampaignLevel(3, 'Chrono Path', 'hourglass', 8, 3037, 2, 5, 0.65),
  buildShapedCampaignLevel(4, 'Monarch Knot', 'crown', 9, 4049, 2, 6, 0.66),
  buildShapedCampaignLevel(5, 'Skyline Drift', 'cloud', 9, 5051, 2, 6, 0.68),

  buildShapedCampaignLevel(6, 'Diamond Weave', 'diamond', 12, 6067, 2, 6, 0.72),
  buildShapedCampaignLevel(7, 'Astral Star', 'star', 11, 7079, 2, 7, 0.74),
  buildShapedCampaignLevel(8, 'Crimson Heart', 'heart', 12, 8087, 2, 8, 0.75),
  buildShapedCampaignLevel(9, 'Botanic Vein', 'leaf', 13, 9091, 2, 8, 0.77),
  buildShapedCampaignLevel(10, 'The Grand Citadel', 'fortress', 13, 10103, 2, 9, 0.78),
];

// Validate all 10 initial levels at startup
INITIAL_LEVELS.forEach((level) => {
  const check = validateAndEvaluatePuzzle(level.arrows);
  if (!check.valid || !check.metrics.solvable) {
    console.error(`Level ${level.levelNumber} (${level.title}) failed validation:`, check.reason);
  }
});
