import * as THREE from 'three'

/**
 * Pooled soft-sprite particles (smoke, fire, sparks, vapour trails). One draw call per system.
 * Size is in world metres and attenuates with distance.
 */
export type RGB = readonly [number, number, number]

export type EmitOptions = {
  life: number
  size0: number
  size1: number
  color0: RGB
  color1: RGB
  alpha0: number
  alpha1: number
  gravity?: number
  drag?: number
}

export class Particles {
  readonly points: THREE.Points
  private readonly max: number
  private readonly px: Float32Array
  private readonly vel: Float32Array
  private readonly age: Float32Array
  private readonly life: Float32Array
  private readonly opt: Array<EmitOptions | undefined>
  private readonly geometry = new THREE.BufferGeometry()
  private readonly position: THREE.BufferAttribute
  private readonly color: THREE.BufferAttribute
  private readonly size: THREE.BufferAttribute
  private readonly uniforms = { uScale: { value: 600 } }
  private cursor = 0
  private active = 0

  constructor(max: number, additive: boolean) {
    this.max = max
    this.px = new Float32Array(max * 3)
    this.vel = new Float32Array(max * 3)
    this.age = new Float32Array(max)
    this.life = new Float32Array(max).fill(0)
    this.opt = new Array(max).fill(undefined)
    this.position = new THREE.BufferAttribute(new Float32Array(max * 3), 3)
    this.color = new THREE.BufferAttribute(new Float32Array(max * 4), 4)
    this.size = new THREE.BufferAttribute(new Float32Array(max), 1)
    this.position.setUsage(THREE.DynamicDrawUsage)
    this.color.setUsage(THREE.DynamicDrawUsage)
    this.size.setUsage(THREE.DynamicDrawUsage)
    this.geometry.setAttribute('position', this.position)
    this.geometry.setAttribute('aColor', this.color)
    this.geometry.setAttribute('aSize', this.size)
    this.geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e9)

    const material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: `
        attribute vec4 aColor; attribute float aSize; uniform float uScale; varying vec4 vColor;
        void main() {
          vColor = aColor;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_PointSize = clamp(aSize * uScale / max(-mv.z, 1.0), 0.0, 900.0);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        varying vec4 vColor;
        void main() {
          float d = length(gl_PointCoord - 0.5) * 2.0;
          float a = 1.0 - smoothstep(0.0, 1.0, d);
          gl_FragColor = vec4(vColor.rgb, vColor.a * a * a);
        }`,
      transparent: true,
      depthWrite: false,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
    })
    this.points = new THREE.Points(this.geometry, material)
    this.points.frustumCulled = false
    this.points.renderOrder = additive ? 3 : 2
  }

  /** Call when the viewport or field of view changes: pixels per metre at distance 1. */
  setScale(viewportHeightPx: number, fovDeg: number): void {
    this.uniforms.uScale.value = viewportHeightPx / (2 * Math.tan((fovDeg * Math.PI) / 360))
  }

  get count(): number {
    return this.active
  }

  emit(x: number, y: number, z: number, vx: number, vy: number, vz: number, options: EmitOptions): void {
    const i = this.cursor
    this.cursor = (this.cursor + 1) % this.max
    if (this.life[i] <= 0) this.active += 1
    this.px[i * 3] = x
    this.px[i * 3 + 1] = y
    this.px[i * 3 + 2] = z
    this.vel[i * 3] = vx
    this.vel[i * 3 + 1] = vy
    this.vel[i * 3 + 2] = vz
    this.age[i] = 0
    this.life[i] = options.life
    this.opt[i] = options
  }

  clear(): void {
    this.life.fill(0)
    this.size.array.fill(0)
    this.size.needsUpdate = true
    this.active = 0
  }

  update(dt: number): void {
    const pos = this.position.array as Float32Array
    const col = this.color.array as Float32Array
    const siz = this.size.array as Float32Array
    for (let i = 0; i < this.max; i += 1) {
      const life = this.life[i]
      if (life <= 0) {
        siz[i] = 0
        continue
      }
      const o = this.opt[i]!
      const age = this.age[i] + dt
      if (age >= life) {
        this.life[i] = 0
        siz[i] = 0
        this.active -= 1
        continue
      }
      this.age[i] = age
      const t = age / life
      const drag = Math.exp(-(o.drag ?? 0) * dt)
      this.vel[i * 3] *= drag
      this.vel[i * 3 + 1] = this.vel[i * 3 + 1] * drag + (o.gravity ?? 0) * dt
      this.vel[i * 3 + 2] *= drag
      this.px[i * 3] += this.vel[i * 3] * dt
      this.px[i * 3 + 1] += this.vel[i * 3 + 1] * dt
      this.px[i * 3 + 2] += this.vel[i * 3 + 2] * dt
      pos[i * 3] = this.px[i * 3]
      pos[i * 3 + 1] = this.px[i * 3 + 1]
      pos[i * 3 + 2] = this.px[i * 3 + 2]
      col[i * 4] = o.color0[0] + (o.color1[0] - o.color0[0]) * t
      col[i * 4 + 1] = o.color0[1] + (o.color1[1] - o.color0[1]) * t
      col[i * 4 + 2] = o.color0[2] + (o.color1[2] - o.color0[2]) * t
      // Fade in over the first 12 % of life to avoid popping.
      const fadeIn = Math.min(1, t / 0.12)
      col[i * 4 + 3] = (o.alpha0 + (o.alpha1 - o.alpha0) * t) * fadeIn
      siz[i] = o.size0 + (o.size1 - o.size0) * t
    }
    this.position.needsUpdate = true
    this.color.needsUpdate = true
    this.size.needsUpdate = true
  }
}
