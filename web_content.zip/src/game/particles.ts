export type PKind = "dot" | "coin" | "text" | "ring" | "star" | "steam" | "emoji";

interface P {
  kind: PKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  grav: number;
  spin: number;
  rot: number;
  text?: string;
  drag: number;
}

export class Particles {
  private ps: P[] = [];
  private ctx: CanvasRenderingContext2D | null = null;
  private canvas: HTMLCanvasElement | null = null;
  w = 0;
  h = 0;
  dpr = 1;

  attach(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.resize();
  }

  resize() {
    const c = this.canvas;
    if (!c) return;
    const r = c.getBoundingClientRect();
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.w = Math.max(1, r.width);
    this.h = Math.max(1, r.height);
    c.width = Math.floor(this.w * this.dpr);
    c.height = Math.floor(this.h * this.dpr);
    if (this.ctx) this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
  }

  clear() {
    this.ps.length = 0;
  }

  private push(p: Partial<P> & { x: number; y: number }) {
    if (this.ps.length > 460) this.ps.shift();
    this.ps.push({
      kind: "dot",
      vx: 0,
      vy: 0,
      life: 0,
      max: 1,
      size: 4,
      color: "#ffb627",
      grav: 0,
      spin: 0,
      rot: 0,
      drag: 0.99,
      ...p,
    } as P);
  }

  center(el: Element | null): { x: number; y: number } {
    if (!el || !this.canvas) return { x: this.w / 2, y: this.h / 2 };
    const a = el.getBoundingClientRect();
    const b = this.canvas.getBoundingClientRect();
    return { x: a.left - b.left + a.width / 2, y: a.top - b.top + a.height / 2 };
  }

  sparks(x: number, y: number, color: string, n = 12, power = 190) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = power * (0.35 + Math.random() * 0.8);
      this.push({
        kind: "dot",
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s - 40,
        life: 0,
        max: 0.42 + Math.random() * 0.42,
        size: 2 + Math.random() * 3.6,
        color,
        grav: 620,
        drag: 0.965,
      });
    }
  }

  stars(x: number, y: number, color: string, n = 7) {
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + Math.random();
      this.push({
        kind: "star",
        x,
        y,
        vx: Math.cos(a) * 130,
        vy: Math.sin(a) * 130 - 70,
        life: 0,
        max: 0.7 + Math.random() * 0.3,
        size: 6 + Math.random() * 7,
        color,
        grav: 240,
        spin: (Math.random() - 0.5) * 12,
        drag: 0.98,
      });
    }
  }

  coins(x: number, y: number, n = 10, up = true) {
    for (let i = 0; i < n; i++) {
      const a = -Math.PI / 2 + (Math.random() - 0.5) * (up ? 1.7 : Math.PI * 2);
      const s = 170 + Math.random() * 230;
      this.push({
        kind: "coin",
        x: x + (Math.random() - 0.5) * 16,
        y: y + (Math.random() - 0.5) * 10,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: 0,
        max: 0.85 + Math.random() * 0.45,
        size: 9 + Math.random() * 6,
        color: Math.random() < 0.35 ? "#ff4d8d" : "#ffb627",
        grav: 760,
        spin: (Math.random() - 0.5) * 16,
        drag: 0.995,
      });
    }
  }

  emoji(x: number, y: number, text: string, n = 5) {
    for (let i = 0; i < n; i++) {
      this.push({
        kind: "emoji",
        text,
        x: x + (Math.random() - 0.5) * 30,
        y,
        vx: (Math.random() - 0.5) * 120,
        vy: -110 - Math.random() * 130,
        life: 0,
        max: 1 + Math.random() * 0.5,
        size: 16 + Math.random() * 12,
        color: "#fff",
        grav: 130,
        spin: (Math.random() - 0.5) * 5,
        drag: 0.99,
      });
    }
  }

  steam(x: number, y: number, n = 4) {
    for (let i = 0; i < n; i++) {
      this.push({
        kind: "steam",
        x: x + (Math.random() - 0.5) * 26,
        y,
        vx: (Math.random() - 0.5) * 24,
        vy: -40 - Math.random() * 30,
        life: 0,
        max: 1.1 + Math.random() * 0.7,
        size: 10 + Math.random() * 14,
        color: "rgba(255,243,220,0.5)",
        grav: -12,
        drag: 0.995,
      });
    }
  }

  ring(x: number, y: number, color: string, size = 16, max = 0.5) {
    this.push({ kind: "ring", x, y, life: 0, max, size, color, grav: 0 });
  }

  text(x: number, y: number, text: string, color = "#fff3dc", size = 22, vy = -88) {
    this.push({
      kind: "text",
      text,
      x,
      y,
      vx: 0,
      vy,
      life: 0,
      max: 1.05,
      size,
      color,
      grav: 40,
      drag: 0.985,
    });
  }

  confetti(n = 60, colors: string[] = ["#ffb627", "#ff4d8d", "#17b8a6", "#fff3dc", "#e8384f"]) {
    for (let i = 0; i < n; i++) {
      this.push({
        kind: "dot",
        x: Math.random() * this.w,
        y: -20 - Math.random() * this.h * 0.4,
        vx: (Math.random() - 0.5) * 90,
        vy: 90 + Math.random() * 170,
        life: 0,
        max: 2.6 + Math.random() * 1.6,
        size: 4 + Math.random() * 6,
        color: colors[(Math.random() * colors.length) | 0],
        grav: 24,
        spin: (Math.random() - 0.5) * 10,
        drag: 0.998,
      });
    }
  }

  update(dt: number) {
    const ps = this.ps;
    for (let i = ps.length - 1; i >= 0; i--) {
      const p = ps[i];
      p.life += dt;
      if (p.life >= p.max) {
        ps.splice(i, 1);
        continue;
      }
      p.vy += p.grav * dt;
      p.vx *= p.drag;
      p.vy *= p.drag;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.spin * dt;
    }
  }

  draw() {
    const ctx = this.ctx;
    if (!ctx) return;
    ctx.clearRect(0, 0, this.w, this.h);
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (const p of this.ps) {
      const t = p.life / p.max;
      const alpha = p.kind === "text" ? (t < 0.12 ? t / 0.12 : 1 - Math.pow(t, 3)) : 1 - t * t;
      ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
      switch (p.kind) {
        case "dot": {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillStyle = p.color;
          ctx.fillRect(-p.size / 2, -p.size / 3, p.size, p.size * 0.66);
          ctx.restore();
          break;
        }
        case "coin": {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          const sq = Math.abs(Math.cos(p.life * 9));
          ctx.scale(0.35 + sq * 0.65, 1);
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "rgba(27,16,41,.45)";
          ctx.beginPath();
          ctx.arc(0, 0, p.size * 0.55, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
          break;
        }
        case "star": {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillStyle = p.color;
          ctx.beginPath();
          for (let i = 0; i < 5; i++) {
            const a = (i / 5) * Math.PI * 2 - Math.PI / 2;
            const a2 = a + Math.PI / 5;
            ctx.lineTo(Math.cos(a) * p.size, Math.sin(a) * p.size);
            ctx.lineTo(Math.cos(a2) * p.size * 0.45, Math.sin(a2) * p.size * 0.45);
          }
          ctx.closePath();
          ctx.fill();
          ctx.restore();
          break;
        }
        case "ring": {
          ctx.strokeStyle = p.color;
          ctx.lineWidth = Math.max(1, 6 * (1 - t));
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size + t * 90, 0, Math.PI * 2);
          ctx.stroke();
          break;
        }
        case "steam": {
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (0.5 + t * 1.5), 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case "emoji": {
          ctx.font = `${p.size}px "Hind Siliguri", system-ui, sans-serif`;
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot * 0.15);
          ctx.fillText(p.text || "", 0, 0);
          ctx.restore();
          break;
        }
        case "text": {
          const scale = t < 0.16 ? 0.6 + (t / 0.16) * 0.55 : 1.15 - (t - 0.16) * 0.18;
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.scale(scale, scale);
          ctx.font = `800 ${p.size}px "Baloo Da 2", "Hind Siliguri", system-ui, sans-serif`;
          ctx.lineWidth = Math.max(3, p.size * 0.22);
          ctx.strokeStyle = "rgba(27,16,41,.85)";
          ctx.strokeText(p.text || "", 0, 0);
          ctx.fillStyle = p.color;
          ctx.fillText(p.text || "", 0, 0);
          ctx.restore();
          break;
        }
      }
    }
    ctx.globalAlpha = 1;
  }
}
