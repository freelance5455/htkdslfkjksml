import { Particle, DamageNumber } from '../types/game';

export class ParticleSystem {
  public particles: Particle[] = [];
  public damageNumbers: DamageNumber[] = [];

  public update() {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.life--;
      p.alpha = Math.max(0, p.life / p.maxLife);

      if (p.shape === 'smoke') {
        p.size += 0.05;
        p.vx *= 0.96;
        p.vy *= 0.98;
      } else {
        p.vx *= 0.92;
        p.vy *= 0.92;
      }

      if (p.life <= 0) {
        this.particles.splice(i, 1);
      }
    }

    for (let i = this.damageNumbers.length - 1; i >= 0; i--) {
      const dn = this.damageNumbers[i];
      dn.y -= 0.6;
      dn.life--;
      if (dn.life <= 0) {
        this.damageNumbers.splice(i, 1);
      }
    }
  }

  // Emit wood chips
  public emitWoodChips(x: number, y: number, count: number = 8) {
    const colors = ['#78350f', '#92400e', '#d97706', '#451a03'];
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 2.5 + 1;
      this.particles.push({
        x: x + (Math.random() * 8 - 4),
        y: y + (Math.random() * 8 - 4),
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.2,
        life: 25 + Math.random() * 15,
        maxLife: 40,
        size: Math.random() * 2 + 2,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        shape: 'pixel',
      });
    }
  }

  // Emit stone dust and chips
  public emitStoneChips(x: number, y: number, count: number = 8) {
    const colors = ['#64748b', '#94a3b8', '#cbd5e1', '#334155'];
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 2.2 + 0.8;
      this.particles.push({
        x: x + (Math.random() * 8 - 4),
        y: y + (Math.random() * 8 - 4),
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1,
        life: 20 + Math.random() * 12,
        maxLife: 32,
        size: Math.random() * 2.5 + 2,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        shape: 'pixel',
      });
    }
  }

  // Emit leaves
  public emitLeaves(x: number, y: number, count: number = 6) {
    const colors = ['#22c55e', '#16a34a', '#86efac', '#15803d'];
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 1.5 + 0.5;
      this.particles.push({
        x: x + (Math.random() * 16 - 8),
        y: y + (Math.random() * 16 - 8),
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 0.5,
        life: 30 + Math.random() * 20,
        maxLife: 50,
        size: 3,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        shape: 'leaf',
      });
    }
  }

  // Emit collect sparkles
  public emitSparkles(x: number, y: number, count: number = 6) {
    const colors = ['#fde047', '#38bdf8', '#f472b6', '#4ade80'];
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 1.8 + 0.5;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1,
        life: 25,
        maxLife: 25,
        size: 2.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        shape: 'spark',
      });
    }
  }

  // Emit campfire embers and rising smoke
  public emitCampfire(x: number, y: number) {
    // Ember
    if (Math.random() < 0.4) {
      this.particles.push({
        x: x + (Math.random() * 10 - 5),
        y: y + 2,
        vx: Math.random() * 0.6 - 0.3,
        vy: -(Math.random() * 1.2 + 0.6),
        life: 30 + Math.random() * 15,
        maxLife: 45,
        size: Math.random() * 2 + 1,
        color: Math.random() < 0.6 ? '#f59e0b' : '#ef4444',
        alpha: 1,
        shape: 'spark',
      });
    }
    // Smoke
    if (Math.random() < 0.25) {
      this.particles.push({
        x: x + (Math.random() * 6 - 3),
        y: y - 8,
        vx: Math.random() * 0.4 - 0.2,
        vy: -(Math.random() * 0.6 + 0.4),
        life: 45 + Math.random() * 20,
        maxLife: 65,
        size: 3,
        color: 'rgba(100, 116, 139, 0.45)',
        alpha: 0.6,
        shape: 'smoke',
      });
    }
  }

  // Emit footstep dust
  public emitFootstep(x: number, y: number) {
    this.particles.push({
      x: x + (Math.random() * 4 - 2),
      y: y + (Math.random() * 2 - 1),
      vx: Math.random() * 0.4 - 0.2,
      vy: -(Math.random() * 0.3 + 0.1),
      life: 16,
      maxLife: 16,
      size: 2,
      color: 'rgba(148, 163, 184, 0.6)',
      alpha: 0.6,
      shape: 'pixel',
    });
  }

  // Emit sprint dust trail when running
  public emitSprintDust(x: number, y: number, dirX: number = 0, dirY: number = 0) {
    const colors = ['rgba(180, 150, 110, 0.8)', 'rgba(210, 180, 140, 0.7)', 'rgba(140, 120, 90, 0.7)'];
    for (let i = 0; i < 3; i++) {
      this.particles.push({
        x: x + (Math.random() * 8 - 4),
        y: y + (Math.random() * 4 - 2),
        vx: -dirX * 0.8 + (Math.random() * 0.8 - 0.4),
        vy: -dirY * 0.8 - (Math.random() * 0.6 + 0.2),
        life: 20 + Math.random() * 10,
        maxLife: 30,
        size: Math.random() * 2.5 + 2,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 0.8,
        shape: 'smoke',
      });
    }
  }

  // Emit water splash droplets
  public emitWaterSplash(x: number, y: number, count: number = 6) {
    const colors = ['#60a5fa', '#93c5fd', '#bfdbfe', '#ffffff'];
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 2.2 + 0.8;
      this.particles.push({
        x: x + (Math.random() * 6 - 3),
        y: y + (Math.random() * 4 - 2),
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.2,
        life: 18 + Math.random() * 10,
        maxLife: 28,
        size: Math.random() * 2 + 1.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 0.9,
        shape: 'spark',
      });
    }
  }

  // Emit water concentric expanding ripple
  public emitWaterRipple(x: number, y: number) {
    this.particles.push({
      x,
      y,
      vx: 0,
      vy: 0,
      life: 25,
      maxLife: 25,
      size: 4,
      color: 'rgba(191, 219, 254, 0.7)',
      alpha: 0.7,
      shape: 'circle',
    });
  }

  // Emit hit impact sparks
  public emitHitImpact(x: number, y: number) {
    const colors = ['#ffffff', '#fde047', '#f97316', '#ef4444'];
    for (let i = 0; i < 7; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 3 + 1;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 14 + Math.random() * 8,
        maxLife: 22,
        size: 2.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        shape: 'spark',
      });
    }
  }

  // Floating damage or pickup text
  public addDamageNumber(text: string, x: number, y: number, color: string = '#ef4444') {
    this.damageNumbers.push({
      id: Math.random().toString(),
      text,
      x,
      y,
      color,
      life: 40,
      maxLife: 40,
    });
  }

  // Draw all particles to the world canvas
  public render(ctx: CanvasRenderingContext2D) {
    for (const p of this.particles) {
      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;

      if (p.shape === 'smoke') {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.shape === 'circle') {
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        const rippleRadius = p.size + (1 - p.life / p.maxLife) * 8;
        ctx.ellipse(p.x, p.y, rippleRadius, rippleRadius * 0.45, 0, 0, Math.PI * 2);
        ctx.stroke();
      } else if (p.shape === 'spark') {
        ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
      } else if (p.shape === 'rain') {
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x - 3, p.y + 10);
        ctx.stroke();
      } else {
        ctx.fillRect(p.x, p.y, p.size, p.size);
      }
      ctx.restore();
    }

    // Render floating damage numbers
    for (const dn of this.damageNumbers) {
      ctx.save();
      const alpha = Math.min(1, dn.life / 20);
      ctx.globalAlpha = alpha;
      ctx.font = 'bold 12px "Press Start 2P", monospace';
      ctx.fillStyle = dn.color;
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 2.5;
      ctx.strokeText(dn.text, dn.x, dn.y);
      ctx.fillText(dn.text, dn.x, dn.y);
      ctx.restore();
    }
  }
}

export const particles = new ParticleSystem();
