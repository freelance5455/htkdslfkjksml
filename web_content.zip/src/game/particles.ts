// ============================================================
// DEEP DIG — pooled particle system (no per-frame allocation)
// ============================================================
import * as THREE from "three";

export interface PSpawn {
  x: number; y: number; z: number;
  vx?: number; vy?: number; vz?: number;
  life: number;
  size: number;
  size1?: number;
  r: number; g: number; b: number;
  a?: number;
  gravity?: number;
  drag?: number;
  hard?: boolean;
  ground?: boolean;
}

export class ParticlePool {
  max: number;
  points: THREE.Points;
  geo = new THREE.BufferGeometry();
  pos: Float32Array;
  col: Float32Array;
  size: Float32Array;
  alpha: Float32Array;
  soft: Float32Array;
  vel: Float32Array;
  life: Float32Array;
  maxLife: Float32Array;
  s0: Float32Array;
  s1: Float32Array;
  a0: Float32Array;
  grav: Float32Array;
  drag: Float32Array;
  ground: Uint8Array;
  head = 0;
  mat: THREE.ShaderMaterial;
  groundFn: (x: number, z: number) => number = () => -100;

  constructor(max: number, additive: boolean) {
    this.max = max;
    this.pos = new Float32Array(max * 3);
    this.col = new Float32Array(max * 3);
    this.size = new Float32Array(max);
    this.alpha = new Float32Array(max);
    this.soft = new Float32Array(max);
    this.vel = new Float32Array(max * 3);
    this.life = new Float32Array(max);
    this.maxLife = new Float32Array(max).fill(1);
    this.s0 = new Float32Array(max);
    this.s1 = new Float32Array(max);
    this.a0 = new Float32Array(max);
    this.grav = new Float32Array(max);
    this.drag = new Float32Array(max);
    this.ground = new Uint8Array(max);
    const mk = (a: Float32Array, n: number) => {
      const at = new THREE.BufferAttribute(a, n);
      at.setUsage(THREE.DynamicDrawUsage);
      return at;
    };
    this.geo.setAttribute("position", mk(this.pos, 3));
    this.geo.setAttribute("pcolor", mk(this.col, 3));
    this.geo.setAttribute("psize", mk(this.size, 1));
    this.geo.setAttribute("palpha", mk(this.alpha, 1));
    this.geo.setAttribute("psoft", mk(this.soft, 1));
    this.geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5);
    this.mat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
      uniforms: { uScale: { value: 600 } },
      vertexShader: `
        attribute vec3 pcolor; attribute float psize; attribute float palpha; attribute float psoft;
        varying vec3 vC; varying float vA; varying float vS;
        uniform float uScale;
        void main(){
          vec4 mv = modelViewMatrix * vec4(position,1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = max(psize * uScale / max(-mv.z, 0.1), 0.0);
          vC = pcolor; vA = palpha; vS = psoft;
        }`,
      fragmentShader: `
        varying vec3 vC; varying float vA; varying float vS;
        void main(){
          float d = length(gl_PointCoord - 0.5) * 2.0;
          float a = mix(step(d, 1.0), smoothstep(1.0, 0.15, d), vS) * vA;
          if (a < 0.01) discard;
          gl_FragColor = vec4(vC, a);
        }`,
    });
    this.points = new THREE.Points(this.geo, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = additive ? 6 : 5;
  }

  setScale(v: number) {
    this.mat.uniforms.uScale.value = v;
  }

  emit(p: PSpawn) {
    const i = this.head;
    this.head = (this.head + 1) % this.max;
    this.pos[i * 3] = p.x; this.pos[i * 3 + 1] = p.y; this.pos[i * 3 + 2] = p.z;
    this.vel[i * 3] = p.vx || 0; this.vel[i * 3 + 1] = p.vy || 0; this.vel[i * 3 + 2] = p.vz || 0;
    this.life[i] = this.maxLife[i] = p.life;
    this.s0[i] = p.size;
    this.s1[i] = p.size1 ?? p.size;
    this.col[i * 3] = p.r; this.col[i * 3 + 1] = p.g; this.col[i * 3 + 2] = p.b;
    this.a0[i] = p.a ?? 1;
    this.grav[i] = p.gravity ?? 0;
    this.drag[i] = p.drag ?? 0;
    this.soft[i] = p.hard ? 0 : 1;
    this.ground[i] = p.ground ? 1 : 0;
  }

  update(dt: number) {
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) {
        this.size[i] = 0;
        this.alpha[i] = 0;
        continue;
      }
      this.life[i] -= dt;
      const t = 1 - this.life[i] / this.maxLife[i];
      const i3 = i * 3;
      const dr = Math.max(0, 1 - this.drag[i] * dt);
      this.vel[i3] *= dr;
      this.vel[i3 + 1] = this.vel[i3 + 1] * dr - this.grav[i] * dt;
      this.vel[i3 + 2] *= dr;
      this.pos[i3] += this.vel[i3] * dt;
      this.pos[i3 + 1] += this.vel[i3 + 1] * dt;
      this.pos[i3 + 2] += this.vel[i3 + 2] * dt;
      if (this.ground[i]) {
        const g = this.groundFn(this.pos[i3], this.pos[i3 + 2]);
        if (this.pos[i3 + 1] < g + 0.02) {
          this.pos[i3 + 1] = g + 0.02;
          this.vel[i3] *= 0.2; this.vel[i3 + 1] = 0; this.vel[i3 + 2] *= 0.2;
          this.life[i] = Math.min(this.life[i], 0.25);
        }
      }
      this.size[i] = this.s0[i] + (this.s1[i] - this.s0[i]) * t;
      const fadeIn = Math.min(1, t * 12);
      this.alpha[i] = this.a0[i] * fadeIn * (1 - t * t);
    }
    (this.geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.psize as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.palpha as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.psoft as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.pcolor as THREE.BufferAttribute).needsUpdate = true;
  }

  dispose() {
    this.geo.dispose();
    this.mat.dispose();
  }
}

export class Particles {
  dust = new ParticlePool(520, false);
  glow = new ParticlePool(260, true);
  group = new THREE.Group();
  constructor() {
    this.group.add(this.dust.points, this.glow.points);
  }
  setGround(fn: (x: number, z: number) => number) {
    this.dust.groundFn = fn;
    this.glow.groundFn = fn;
  }
  update(dt: number) {
    this.dust.update(dt);
    this.glow.update(dt);
  }
  setScale(v: number) {
    this.dust.setScale(v);
    this.glow.setScale(v);
  }
}
