export interface Particle {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  gravity: number;
  drag: number;
  shape: 0 | 1 | 2; // 0 circle, 1 rect (confetti), 2 star
  rot: number;
  rotV: number;
  glow: boolean;
}

export class ParticleSystem {
  pool: Particle[] = [];
  private next = 0;

  constructor(max = 420) {
    for (let i = 0; i < max; i++) {
      this.pool.push({
        alive: false, x: 0, y: 0, vx: 0, vy: 0, life: 0, maxLife: 1, size: 3, color: '#fff',
        gravity: 0, drag: 0, shape: 0, rot: 0, rotV: 0, glow: false,
      });
    }
  }

  clear() {
    for (const p of this.pool) p.alive = false;
  }

  emit(opts: {
    x: number; y: number; count: number; speed: number; spread?: number; angle?: number;
    life?: number; size?: number; sizeVar?: number; colors: string[]; gravity?: number; drag?: number;
    shape?: 0 | 1 | 2; glow?: boolean;
  }) {
    const {
      x, y, count, speed, spread = Math.PI * 2, angle = -Math.PI / 2, life = 0.8, size = 4, sizeVar = 2,
      colors, gravity = 300, drag = 0.98, shape = 0, glow = false,
    } = opts;
    for (let i = 0; i < count; i++) {
      const p = this.pool[this.next];
      this.next = (this.next + 1) % this.pool.length;
      const a = angle + (Math.random() - 0.5) * spread;
      const sp = speed * (0.4 + Math.random() * 0.8);
      p.alive = true;
      p.x = x;
      p.y = y;
      p.vx = Math.cos(a) * sp;
      p.vy = Math.sin(a) * sp;
      p.maxLife = life * (0.6 + Math.random() * 0.7);
      p.life = p.maxLife;
      p.size = size + Math.random() * sizeVar;
      p.color = colors[(Math.random() * colors.length) | 0];
      p.gravity = gravity;
      p.drag = drag;
      p.shape = shape;
      p.rot = Math.random() * Math.PI * 2;
      p.rotV = (Math.random() - 0.5) * 12;
      p.glow = glow;
    }
  }

  update(dt: number) {
    for (const p of this.pool) {
      if (!p.alive) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.alive = false;
        continue;
      }
      p.vy += p.gravity * dt;
      p.vx *= p.drag;
      p.vy *= p.drag;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.rotV * dt;
    }
  }

  draw(ctx: CanvasRenderingContext2D) {
    for (const p of this.pool) {
      if (!p.alive) continue;
      const t = p.life / p.maxLife;
      ctx.globalAlpha = Math.min(1, t * 2);
      ctx.fillStyle = p.color;
      const s = p.size * (0.5 + t * 0.5);
      if (p.shape === 0) {
        if (p.glow) {
          ctx.shadowColor = p.color;
          ctx.shadowBlur = 8;
        }
        ctx.beginPath();
        ctx.arc(p.x, p.y, s, 0, Math.PI * 2);
        ctx.fill();
        if (p.glow) ctx.shadowBlur = 0;
      } else if (p.shape === 1) {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillRect(-s, -s * 0.5, s * 2, s);
        ctx.restore();
      } else {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.beginPath();
        for (let i = 0; i < 5; i++) {
          const a = (i * 4 * Math.PI) / 5;
          const px = Math.cos(a) * s;
          const py = Math.sin(a) * s;
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
    }
    ctx.globalAlpha = 1;
  }
}

export interface FloatText {
  alive: boolean;
  x: number;
  y: number;
  vy: number;
  text: string;
  color: string;
  size: number;
  life: number;
  maxLife: number;
  font: string;
  stroke: boolean;
}

export class FloatingTexts {
  pool: FloatText[] = [];
  private next = 0;

  constructor(max = 24) {
    for (let i = 0; i < max; i++) {
      this.pool.push({ alive: false, x: 0, y: 0, vy: 0, text: '', color: '#fff', size: 20, life: 0, maxLife: 1, font: 'sans-serif', stroke: true });
    }
  }

  clear() {
    for (const f of this.pool) f.alive = false;
  }

  add(text: string, x: number, y: number, opts: { color?: string; size?: number; life?: number; vy?: number; font?: string; stroke?: boolean } = {}) {
    const f = this.pool[this.next];
    this.next = (this.next + 1) % this.pool.length;
    f.alive = true;
    f.text = text;
    f.x = x;
    f.y = y;
    f.color = opts.color ?? '#fff';
    f.size = opts.size ?? 22;
    f.maxLife = opts.life ?? 1;
    f.life = f.maxLife;
    f.vy = opts.vy ?? -60;
    f.font = opts.font ?? "'Nunito', sans-serif";
    f.stroke = opts.stroke ?? true;
  }

  update(dt: number) {
    for (const f of this.pool) {
      if (!f.alive) continue;
      f.life -= dt;
      if (f.life <= 0) {
        f.alive = false;
        continue;
      }
      f.y += f.vy * dt;
      f.vy *= 0.96;
    }
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const f of this.pool) {
      if (!f.alive) continue;
      const t = f.life / f.maxLife;
      const pop = t > 0.85 ? 1 + (t - 0.85) * 3 : 1;
      ctx.globalAlpha = Math.min(1, t * 3);
      ctx.font = `900 ${Math.round(f.size * pop)}px ${f.font}`;
      if (f.stroke) {
        ctx.lineWidth = Math.max(3, f.size * 0.18);
        ctx.strokeStyle = 'rgba(30,15,5,0.85)';
        ctx.lineJoin = 'round';
        ctx.strokeText(f.text, f.x, f.y);
      }
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, f.x, f.y);
    }
    ctx.globalAlpha = 1;
  }
}
