import * as THREE from 'three';

export interface Particle {
  mesh: THREE.Object3D;
  velocity: THREE.Vector3;
  life: number;
  maxLife: number;
  scaleDelta: number;
  color?: THREE.Color;
  update: (delta: number) => boolean; // returns false when dead
}

export interface FloatingDamage {
  id: string;
  text: string;
  x: number;
  y: number;
  z: number;
  vy: number;
  opacity: number;
  color: string;
  isCrit: boolean;
}

export class ParticleManager {
  private scene: THREE.Scene;
  private particles: Particle[] = [];
  private sharedGeometries: {
    spark: THREE.BufferGeometry;
    smoke: THREE.BufferGeometry;
    ring: THREE.BufferGeometry;
    cube: THREE.BufferGeometry;
  };

  constructor(scene: THREE.Scene) {
    this.scene = scene;

    this.sharedGeometries = {
      spark: new THREE.TetrahedronGeometry(0.18),
      smoke: new THREE.DodecahedronGeometry(0.35),
      ring: new THREE.RingGeometry(0.4, 0.7, 16),
      cube: new THREE.BoxGeometry(0.2, 0.2, 0.2),
    };
  }

  // Combat Slash Arc
  public spawnSlashArc(position: THREE.Vector3, rotationY: number, colorHex = '#f8fafc') {
    const arcGeo = new THREE.TorusGeometry(1.6, 0.12, 8, 16, Math.PI * 0.7);
    const arcMat = new THREE.MeshBasicMaterial({
      color: colorHex,
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide,
    });
    const arc = new THREE.Mesh(arcGeo, arcMat);
    arc.position.copy(position).add(new THREE.Vector3(0, 1.2, 0));
    arc.rotation.y = rotationY;
    arc.rotation.x = Math.PI / 2 + (Math.random() - 0.5) * 0.4;
    this.scene.add(arc);

    this.particles.push({
      mesh: arc,
      velocity: new THREE.Vector3(Math.sin(rotationY) * 6, 0, Math.cos(rotationY) * 6),
      life: 0,
      maxLife: 0.22,
      scaleDelta: 2.2,
      update: (delta) => {
        arc.position.x += Math.sin(rotationY) * delta * 8;
        arc.position.z += Math.cos(rotationY) * delta * 8;
        arc.scale.multiplyScalar(1 + delta * 3);
        arcMat.opacity -= delta * 4;
        return arcMat.opacity > 0;
      },
    });

    // Sparks at slash
    this.spawnHitSparks(position, colorHex, 8);
  }

  // Hit Sparks
  public spawnHitSparks(pos: THREE.Vector3, colorHex = '#f59e0b', count = 8) {
    for (let i = 0; i < count; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: colorHex, transparent: true, opacity: 1 });
      const spark = new THREE.Mesh(this.sharedGeometries.spark, mat);
      spark.position.copy(pos).add(new THREE.Vector3((Math.random() - 0.5) * 0.4, 1.0 + Math.random() * 0.6, (Math.random() - 0.5) * 0.4));
      this.scene.add(spark);

      const vel = new THREE.Vector3(
        (Math.random() - 0.5) * 8,
        Math.random() * 6 + 2,
        (Math.random() - 0.5) * 8
      );

      this.particles.push({
        mesh: spark,
        velocity: vel,
        life: 0,
        maxLife: 0.35,
        scaleDelta: -0.5,
        update: (dt) => {
          spark.position.addScaledVector(vel, dt);
          vel.y -= 15 * dt; // gravity
          mat.opacity -= dt * 2.8;
          return mat.opacity > 0;
        },
      });
    }
  }

  // Fire Fist / Fireball Eruption
  public spawnFireExplosion(pos: THREE.Vector3, radius = 3.5) {
    const fireColors = ['#f97316', '#ef4444', '#facc15', '#ea580c'];
    for (let i = 0; i < 24; i++) {
      const color = fireColors[Math.floor(Math.random() * fireColors.length)];
      const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.95 });
      const puff = new THREE.Mesh(this.sharedGeometries.smoke, mat);
      puff.position.copy(pos).add(new THREE.Vector3((Math.random() - 0.5) * 0.8, 0.8, (Math.random() - 0.5) * 0.8));
      this.scene.add(puff);

      const speed = 4 + Math.random() * 8;
      const angle = Math.random() * Math.PI * 2;
      const vel = new THREE.Vector3(Math.cos(angle) * speed, Math.random() * 7 + 2, Math.sin(angle) * speed);

      this.particles.push({
        mesh: puff,
        velocity: vel,
        life: 0,
        maxLife: 0.55,
        scaleDelta: 2.5,
        update: (dt) => {
          puff.position.addScaledVector(vel, dt);
          puff.scale.multiplyScalar(1 + dt * 1.5);
          mat.opacity -= dt * 1.8;
          return mat.opacity > 0;
        },
      });
    }
  }

  // Light Beam Piercing Burst
  public spawnLightLaser(from: THREE.Vector3, to: THREE.Vector3) {
    const distance = from.distanceTo(to);
    const beamGeo = new THREE.CylinderGeometry(0.18, 0.18, distance, 8);
    const beamMat = new THREE.MeshBasicMaterial({
      color: '#fef08a',
      transparent: true,
      opacity: 0.95,
    });
    const beam = new THREE.Mesh(beamGeo, beamMat);

    // Orient beam between points
    const midPoint = from.clone().add(to).multiplyScalar(0.5);
    beam.position.copy(midPoint);
    beam.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), to.clone().sub(from).normalize());
    this.scene.add(beam);

    this.particles.push({
      mesh: beam,
      velocity: new THREE.Vector3(),
      life: 0,
      maxLife: 0.18,
      scaleDelta: 0,
      update: (dt) => {
        beamMat.opacity -= dt * 5.5;
        beam.scale.x *= 1.3;
        beam.scale.z *= 1.3;
        return beamMat.opacity > 0;
      },
    });

    this.spawnHitSparks(to, '#fde047', 16);
  }

  // Ice Glacial Wave / Spikes
  public spawnIceSurge(pos: THREE.Vector3, forwardDir: THREE.Vector3) {
    const spikeGeo = new THREE.ConeGeometry(0.4, 2.2, 5);
    const iceMat = new THREE.MeshStandardMaterial({
      color: '#7dd3fc',
      roughness: 0.2,
      metalness: 0.4,
      transparent: true,
      opacity: 0.9,
    });

    for (let i = 0; i < 7; i++) {
      const spike = new THREE.Mesh(spikeGeo, iceMat);
      const offset = forwardDir.clone().multiplyScalar(i * 1.6).add(
        new THREE.Vector3((Math.random() - 0.5) * 1.2, 0, (Math.random() - 0.5) * 1.2)
      );
      spike.position.copy(pos).add(offset);
      spike.position.y = 1.0;
      spike.rotation.x = (Math.random() - 0.5) * 0.4;
      spike.rotation.z = (Math.random() - 0.5) * 0.4;
      this.scene.add(spike);

      this.particles.push({
        mesh: spike,
        velocity: new THREE.Vector3(0, 0, 0),
        life: 0,
        maxLife: 1.2,
        scaleDelta: 0,
        update: (dt) => {
          iceMat.opacity -= dt * 0.8;
          return iceMat.opacity > 0;
        },
      });
    }
  }

  // Buddha Golden Shockwave Ring
  public spawnBuddhaShockwave(pos: THREE.Vector3) {
    const ringGeo = new THREE.RingGeometry(0.5, 1.2, 32);
    const ringMat = new THREE.MeshBasicMaterial({
      color: '#facc15',
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.copy(pos);
    ring.position.y = 0.4;
    this.scene.add(ring);

    this.particles.push({
      mesh: ring,
      velocity: new THREE.Vector3(),
      life: 0,
      maxLife: 0.65,
      scaleDelta: 0,
      update: (dt) => {
        ring.scale.multiplyScalar(1 + dt * 14);
        ringMat.opacity -= dt * 1.4;
        return ringMat.opacity > 0;
      },
    });
  }

  // Geppo / Sky Jump Cloud Ring
  public spawnSkyJumpPuff(pos: THREE.Vector3) {
    const ringGeo = new THREE.RingGeometry(0.3, 0.8, 16);
    const ringMat = new THREE.MeshBasicMaterial({
      color: '#ffffff',
      transparent: true,
      opacity: 0.8,
      side: THREE.DoubleSide,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.copy(pos);
    this.scene.add(ring);

    this.particles.push({
      mesh: ring,
      velocity: new THREE.Vector3(),
      life: 0,
      maxLife: 0.25,
      scaleDelta: 0,
      update: (dt) => {
        ring.scale.multiplyScalar(1 + dt * 10);
        ringMat.opacity -= dt * 3.5;
        return ringMat.opacity > 0;
      },
    });
  }

  // Soru / Flash Step Streak
  public spawnFlashStepStreak(from: THREE.Vector3, to: THREE.Vector3) {
    const dist = from.distanceTo(to);
    const lineGeo = new THREE.CylinderGeometry(0.12, 0.12, dist, 6);
    const lineMat = new THREE.MeshBasicMaterial({
      color: '#38bdf8',
      transparent: true,
      opacity: 0.85,
    });
    const streak = new THREE.Mesh(lineGeo, lineMat);
    streak.position.copy(from).add(to).multiplyScalar(0.5);
    streak.position.y += 1.0;
    streak.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), to.clone().sub(from).normalize());
    this.scene.add(streak);

    this.particles.push({
      mesh: streak,
      velocity: new THREE.Vector3(),
      life: 0,
      maxLife: 0.2,
      scaleDelta: 0,
      update: (dt) => {
        lineMat.opacity -= dt * 4.5;
        return lineMat.opacity > 0;
      },
    });
  }

  // Water Wake Splash
  public spawnWaterSplash(pos: THREE.Vector3) {
    const mat = new THREE.MeshBasicMaterial({ color: '#e0f2fe', transparent: true, opacity: 0.7 });
    for (let i = 0; i < 6; i++) {
      const drop = new THREE.Mesh(this.sharedGeometries.spark, mat);
      drop.position.copy(pos).add(new THREE.Vector3((Math.random() - 0.5) * 1.5, 0.2, (Math.random() - 0.5) * 1.5));
      this.scene.add(drop);

      const vel = new THREE.Vector3((Math.random() - 0.5) * 3, Math.random() * 3 + 1, (Math.random() - 0.5) * 3);

      this.particles.push({
        mesh: drop,
        velocity: vel,
        life: 0,
        maxLife: 0.4,
        scaleDelta: 0,
        update: (dt) => {
          drop.position.addScaledVector(vel, dt);
          vel.y -= 12 * dt;
          mat.opacity -= dt * 2;
          return mat.opacity > 0;
        },
      });
    }
  }

  public update(delta: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      const alive = p.update(delta);
      if (!alive) {
        this.scene.remove(p.mesh);
        if (p.mesh instanceof THREE.Mesh) {
          p.mesh.geometry.dispose();
          if (Array.isArray(p.mesh.material)) {
            p.mesh.material.forEach(m => m.dispose());
          } else {
            p.mesh.material.dispose();
          }
        }
        this.particles.splice(i, 1);
      }
    }
  }

  public clear() {
    this.particles.forEach(p => {
      this.scene.remove(p.mesh);
    });
    this.particles = [];
  }
}
