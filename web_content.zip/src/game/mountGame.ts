import * as THREE from "three";
import { createAudio } from "@/game/audio";
import { BLOCKS, INF_SPAWNS, ISLAND_R, TANK_SPAWNS, type Block } from "@/game/layout";
import type { GameApi, HudSnapshot, PadInput } from "@/game/types";

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setSteer?: (v: number) => void;
      setKeys?: (codes: string[]) => void;
    };
  }
}

type Kind = "inf" | "badtank" | "ptank";

type TankBits = {
  turret: THREE.Group;
  pitch: THREE.Group;
  wheels: THREE.Mesh[];
};

type Actor = {
  kind: Kind;
  x: number;
  z: number;
  yaw: number;
  speed: number;
  hp: number;
  maxHp: number;
  alive: boolean;
  dying: number;
  radius: number;
  cool: number;
  hitFlash: number;
  wanderT: number;
  vspeed: number;
  mesh: THREE.Group;
  shadow: THREE.Mesh;
  mats: THREE.MeshStandardMaterial[];
  legs: [THREE.Group, THREE.Group] | null;
  bits: TankBits | null;
};

type Shell = {
  alive: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  owner: "player" | "enemy";
  skip: Actor | null;
  mesh: THREE.Mesh;
};

type Puff = {
  alive: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  max: number;
  size: number;
  r: number;
  g: number;
  b: number;
  grav: number;
};

const STEP = 1 / 60;
const MAG = 30;
const CANNON_CD = 0.88;
const RIFLE_CD = 0.09;
const SAVE_KEY = "fortpanzer-v1";

const _q = new THREE.Quaternion();
const _dir = new THREE.Vector3();
const _head = new THREE.Vector3();
const _des = new THREE.Vector3();
const _to = new THREE.Vector3();
const _lookT = new THREE.Vector3();
const _muzzle = new THREE.Vector3();
const _col = new THREE.Color();
const _dummy = new THREE.Object3D();

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function dampAngle(cur: number, target: number, lambda: number, dt: number) {
  const diff = Math.atan2(Math.sin(target - cur), Math.cos(target - cur));
  return cur + diff * (1 - Math.exp(-lambda * dt));
}

function radial(x: number, y: number, dz = 0.18) {
  const m = Math.hypot(x, y);
  if (m < dz) return { x: 0, y: 0 };
  const s = (m - dz) / (1 - dz) / m;
  return { x: x * s, y: y * s };
}

function loadBest() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return 0;
    const parsed = JSON.parse(raw) as { v?: number; best?: number };
    if (parsed.v === 1 && typeof parsed.best === "number") return parsed.best;
  } catch {
    /* ignore */
  }
  return 0;
}

function rayAABB(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  b: Block,
  maxT: number,
) {
  const mins = [b.x - b.hw, 0, b.z - b.hd];
  const maxs = [b.x + b.hw, b.h, b.z + b.hd];
  const o = [ox, oy, oz];
  const d = [dx, dy, dz];
  let tmin = 0;
  let tmax = maxT;
  for (let i = 0; i < 3; i++) {
    if (Math.abs(d[i]) < 1e-8) {
      if (o[i] < mins[i] || o[i] > maxs[i]) return null;
    } else {
      let t1 = (mins[i] - o[i]) / d[i];
      let t2 = (maxs[i] - o[i]) / d[i];
      if (t1 > t2) {
        const tmp = t1;
        t1 = t2;
        t2 = tmp;
      }
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmax < tmin) return null;
    }
  }
  return tmin > 0 ? tmin : tmax > 0 ? 0 : null;
}

function raySphere(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  cx: number,
  cy: number,
  cz: number,
  r: number,
) {
  const lx = cx - ox;
  const ly = cy - oy;
  const lz = cz - oz;
  const tca = lx * dx + ly * dy + lz * dz;
  if (tca < 0) return null;
  const d2 = lx * lx + ly * ly + lz * lz - tca * tca;
  const r2 = r * r;
  if (d2 > r2) return null;
  const thc = Math.sqrt(r2 - d2);
  const t = tca - thc;
  return t > 0.08 ? t : null;
}

export function mountGame(
  canvas: HTMLCanvasElement,
  opts: { pad: PadInput; onHud: (h: HudSnapshot) => void },
): GameApi {
  const { pad } = opts;
  const audio = createAudio();
  const textures: THREE.Texture[] = [];

  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: "high-performance",
  });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setClearColor(0x9fd4ff, 1);
  const compact = Math.min(window.innerWidth, window.innerHeight) < 820;
  const shadowSize = compact ? 1024 : 2048;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, compact ? 1.5 : 2));

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0xc5e6ff, 46, 150);
  const camera = new THREE.PerspectiveCamera(68, 1, 0.12, 320);

  const hemi = new THREE.HemisphereLight(0xd2f0ff, 0x6aaf45, 0.78);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff3d4, 2.25);
  sun.position.set(46, 62, 24);
  sun.castShadow = true;
  sun.shadow.mapSize.set(shadowSize, shadowSize);
  const ext = 46;
  const shadowCam = sun.shadow.camera as THREE.OrthographicCamera;
  shadowCam.left = -ext;
  shadowCam.right = ext;
  shadowCam.top = ext;
  shadowCam.bottom = -ext;
  shadowCam.near = 10;
  shadowCam.far = 150;
  shadowCam.updateProjectionMatrix();
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.04;
  scene.add(sun);
  scene.add(sun.target);
  const fill = new THREE.DirectionalLight(0x9ecfff, 0.42);
  fill.position.set(-28, 18, -18);
  scene.add(fill);

  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(240, 28, 16),
    new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      toneMapped: false,
      uniforms: {
        topColor: { value: new THREE.Color("#49b4ff") },
        midColor: { value: new THREE.Color("#b9e4ff") },
        horColor: { value: new THREE.Color("#ffe6c2") },
      },
      vertexShader: `
        varying vec3 vP;
        void main() {
          vP = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vP;
        uniform vec3 topColor;
        uniform vec3 midColor;
        uniform vec3 horColor;
        void main() {
          float h = normalize(vP).y;
          vec3 col = mix(horColor, midColor, smoothstep(0.0, 0.28, h));
          col = mix(col, topColor, smoothstep(0.18, 0.75, h));
          gl_FragColor = vec4(col, 1.0);
        }
      `,
    }),
  );
  scene.add(sky);

  const sunBall = new THREE.Mesh(
    new THREE.SphereGeometry(7, 16, 12),
    new THREE.MeshBasicMaterial({ color: 0xfff4cf, toneMapped: false }),
  );
  sunBall.position.set(90, 74, 36);
  scene.add(sunBall);

  function trackTex(tex: THREE.Texture) {
    textures.push(tex);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return tex;
  }

  function makeGrass() {
    const s = 1024;
    const c = document.createElement("canvas");
    c.width = s;
    c.height = s;
    const g = c.getContext("2d");
    if (!g) return trackTex(new THREE.CanvasTexture(c));
    g.fillStyle = "#3ea338";
    g.fillRect(0, 0, s, s);
    for (let i = 0; i < 80; i++) {
      const x = Math.random() * s;
      const y = Math.random() * s;
      const rad = 28 + Math.random() * 100;
      const grd = g.createRadialGradient(x, y, 2, x, y, rad);
      grd.addColorStop(0, Math.random() > 0.5 ? "rgba(120,210,78,0.5)" : "rgba(30,120,40,0.45)");
      grd.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = grd;
      g.beginPath();
      g.arc(x, y, rad, 0, Math.PI * 2);
      g.fill();
    }
    for (let i = 0; i < 5000; i++) {
      g.fillStyle = i % 2 ? "#62cc4e" : "#2d8630";
      g.fillRect(Math.random() * s, Math.random() * s, 2, 2);
    }
    const flowers = ["#ffd166", "#ff6b9a", "#ffffff", "#ffe08a"];
    for (let i = 0; i < 320; i++) {
      g.fillStyle = flowers[i % flowers.length];
      g.fillRect(Math.random() * s, Math.random() * s, 3, 3);
    }
    g.fillStyle = "rgba(236, 220, 176, 0.62)";
    g.beginPath();
    g.arc(s / 2, s / 2, 78, 0, Math.PI * 2);
    g.fill();
    g.strokeStyle = "rgba(196, 160, 96, 0.9)";
    g.lineWidth = 26;
    g.lineCap = "round";
    g.beginPath();
    g.moveTo(s * 0.5, s * 0.08);
    g.quadraticCurveTo(s * 0.66, s * 0.32, s * 0.5, s * 0.5);
    g.quadraticCurveTo(s * 0.3, s * 0.7, s * 0.5, s * 0.92);
    g.stroke();
    return trackTex(new THREE.CanvasTexture(c));
  }

  function makeFacade(hex: string) {
    const c = document.createElement("canvas");
    c.width = 128;
    c.height = 160;
    const g = c.getContext("2d");
    if (!g) return trackTex(new THREE.CanvasTexture(c));
    g.fillStyle = hex;
    g.fillRect(0, 0, 128, 160);
    g.fillStyle = "rgba(255,255,255,0.07)";
    g.fillRect(0, 0, 128, 16);
    g.fillStyle = "rgba(0,0,0,0.14)";
    g.fillRect(0, 142, 128, 18);
    for (let y = 28; y < 132; y += 36) {
      for (let x = 16; x < 116; x += 32) {
        g.fillStyle = "#dff6ff";
        g.fillRect(x, y, 16, 20);
        g.fillStyle = "rgba(255,255,255,0.55)";
        g.fillRect(x, y, 6, 7);
      }
    }
    return trackTex(new THREE.CanvasTexture(c));
  }

  const water = new THREE.Mesh(
    new THREE.PlaneGeometry(420, 420),
    new THREE.MeshStandardMaterial({ color: 0x2b9fe0, roughness: 0.18, metalness: 0.08 }),
  );
  water.rotation.x = -Math.PI / 2;
  water.position.y = -0.22;
  water.receiveShadow = true;
  scene.add(water);

  const sand = new THREE.Mesh(
    new THREE.CircleGeometry(46, 64),
    new THREE.MeshStandardMaterial({ color: 0xe6c98a, roughness: 0.95 }),
  );
  sand.rotation.x = -Math.PI / 2;
  sand.position.y = -0.02;
  sand.receiveShadow = true;
  scene.add(sand);

  const grass = new THREE.Mesh(
    new THREE.CircleGeometry(40, 64),
    new THREE.MeshStandardMaterial({ map: makeGrass(), roughness: 0.92 }),
  );
  grass.rotation.x = -Math.PI / 2;
  grass.position.y = 0;
  grass.receiveShadow = true;
  scene.add(grass);

  const pond = new THREE.Mesh(
    new THREE.CircleGeometry(4.6, 28),
    new THREE.MeshStandardMaterial({
      color: 0x3ec8ee,
      roughness: 0.12,
      metalness: 0.05,
      transparent: true,
      opacity: 0.78,
    }),
  );
  pond.rotation.x = -Math.PI / 2;
  pond.position.set(-26, 0.045, 8);
  scene.add(pond);
  const foam = new THREE.Mesh(
    new THREE.RingGeometry(4.35, 5.15, 28),
    new THREE.MeshBasicMaterial({ color: 0xf4fbff, transparent: true, opacity: 0.55, depthWrite: false }),
  );
  foam.rotation.x = -Math.PI / 2;
  foam.position.set(-26, 0.05, 8);
  scene.add(foam);

  for (const b of BLOCKS) {
    if (b.crate) {
      const box = new THREE.Mesh(
        new THREE.BoxGeometry(b.hw * 2, b.h, b.hd * 2),
        new THREE.MeshStandardMaterial({ color: b.wall, roughness: 0.84 }),
      );
      box.position.set(b.x, b.h / 2 + 0.02, b.z);
      box.castShadow = true;
      box.receiveShadow = true;
      scene.add(box);
      const band = new THREE.Mesh(
        new THREE.BoxGeometry(b.hw * 2 + 0.06, 0.08, b.hd * 2 + 0.06),
        new THREE.MeshStandardMaterial({ color: b.roof, roughness: 0.7 }),
      );
      band.position.set(b.x, b.h * 0.7, b.z);
      scene.add(band);
      continue;
    }
    const wallH = Math.max(0.8, b.h - 0.42);
    const wall = new THREE.Mesh(
      new THREE.BoxGeometry(b.hw * 2, wallH, b.hd * 2),
      new THREE.MeshStandardMaterial({ map: makeFacade(b.wall), roughness: 0.88 }),
    );
    wall.position.set(b.x, wallH / 2 + 0.02, b.z);
    wall.castShadow = true;
    wall.receiveShadow = true;
    scene.add(wall);
    const roof = new THREE.Mesh(
      new THREE.BoxGeometry(b.hw * 2 + 0.4, 0.46, b.hd * 2 + 0.4),
      new THREE.MeshStandardMaterial({ color: b.roof, roughness: 0.74 }),
    );
    roof.position.set(b.x, wallH + 0.22, b.z);
    roof.castShadow = true;
    roof.receiveShadow = true;
    scene.add(roof);
    if (b.h > 2.4) {
      const door = new THREE.Mesh(
        new THREE.BoxGeometry(0.86, 1.4, 0.08),
        new THREE.MeshStandardMaterial({ color: 0x3a2a22, roughness: 0.8 }),
      );
      door.position.set(b.x, 0.74, b.z + b.hd + 0.02);
      door.castShadow = true;
      scene.add(door);
    }
  }

  const hillMat = new THREE.MeshStandardMaterial({ color: 0x8eb6d2, roughness: 1 });
  const hillGeo = new THREE.ConeGeometry(10, 1, 6);
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2 + 0.2;
    const rr = 72 + (i % 3) * 10;
    const h = 16 + (i % 4) * 8;
    const hill = new THREE.Mesh(hillGeo, hillMat);
    hill.scale.set(1.3 + (i % 3) * 0.35, h, 1.3 + (i % 2) * 0.4);
    hill.position.set(Math.cos(a) * rr, h / 2 - 4, Math.sin(a) * rr);
    scene.add(hill);
  }

  function mulberry32(seed: number) {
    let a = seed;
    return () => {
      a |= 0;
      a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const rnd = mulberry32(19);

  function clearOfBlocks(x: number, z: number, gap: number) {
    if (x * x + z * z > 33 * 33) return false;
    if (Math.abs(x) < 4.2 && z > 6) return false;
    const pdx = x + 26;
    const pdz = z - 8;
    if (pdx * pdx + pdz * pdz < 9 * 9) return false;
    for (const b of BLOCKS) {
      const dx = Math.max(Math.abs(x - b.x) - b.hw, 0);
      const dz = Math.max(Math.abs(z - b.z) - b.hd, 0);
      if (dx * dx + dz * dz < gap * gap) return false;
    }
    return true;
  }

  const trunkGeo = new THREE.CylinderGeometry(0.18, 0.28, 1.45, 6);
  const leafGeo = new THREE.SphereGeometry(1, 8, 6);
  const pineGeo = new THREE.ConeGeometry(1.15, 2.5, 7);
  const trunks = new THREE.InstancedMesh(
    trunkGeo,
    new THREE.MeshStandardMaterial({ color: 0x8d5a34, roughness: 0.92 }),
    34,
  );
  const leaves = new THREE.InstancedMesh(
    leafGeo,
    new THREE.MeshStandardMaterial({ color: 0x3cba4e, roughness: 0.82 }),
    24,
  );
  const pines = new THREE.InstancedMesh(
    pineGeo,
    new THREE.MeshStandardMaterial({ color: 0x217a3a, roughness: 0.84 }),
    10,
  );
  trunks.castShadow = true;
  leaves.castShadow = true;
  pines.castShadow = true;
  let ti = 0;
  let li = 0;
  let pi = 0;
  let guard = 0;
  while (ti < 34 && guard < 700) {
    guard++;
    const a = rnd() * Math.PI * 2;
    const rr = 7 + rnd() * 25;
    const x = Math.cos(a) * rr;
    const z = Math.sin(a) * rr;
    if (!clearOfBlocks(x, z, 2.2)) continue;
    const tall = 0.75 + rnd() * 0.55;
    _dummy.position.set(x, 0.72 * tall, z);
    _dummy.rotation.set(0, rnd() * 6, 0);
    _dummy.scale.set(1, tall, 1);
    _dummy.updateMatrix();
    trunks.setMatrixAt(ti, _dummy.matrix);
    ti++;
    if (li < 24 && rnd() > 0.28) {
      const sc = 0.85 + rnd() * 0.55;
      _dummy.position.set(x, 1.55 + tall, z);
      _dummy.scale.set(sc, sc * 0.85, sc);
      _dummy.rotation.set(0, 0, 0);
      _dummy.updateMatrix();
      leaves.setMatrixAt(li, _dummy.matrix);
      li++;
    } else if (pi < 10) {
      _dummy.position.set(x, 1.85, z);
      _dummy.scale.set(0.85 + rnd() * 0.3, 0.9 + rnd() * 0.4, 0.85);
      _dummy.updateMatrix();
      pines.setMatrixAt(pi, _dummy.matrix);
      pi++;
    }
  }
  trunks.count = ti;
  leaves.count = li;
  pines.count = pi;
  scene.add(trunks, leaves, pines);

  const rockGeo = new THREE.DodecahedronGeometry(0.7, 0);
  const rocks = new THREE.InstancedMesh(
    rockGeo,
    new THREE.MeshStandardMaterial({ color: 0xb7aea2, roughness: 0.95, flatShading: true }),
    12,
  );
  rocks.castShadow = true;
  rocks.receiveShadow = true;
  let ri = 0;
  guard = 0;
  while (ri < 12 && guard < 200) {
    guard++;
    const a = rnd() * Math.PI * 2;
    const rr = 6 + rnd() * 26;
    const x = Math.cos(a) * rr;
    const z = Math.sin(a) * rr;
    if (!clearOfBlocks(x, z, 1.8)) continue;
    _dummy.position.set(x, 0.28, z);
    _dummy.rotation.set(rnd(), rnd(), rnd());
    const sc = 0.45 + rnd() * 0.7;
    _dummy.scale.set(sc * 1.3, sc * 0.7, sc);
    _dummy.updateMatrix();
    rocks.setMatrixAt(ri, _dummy.matrix);
    ri++;
  }
  rocks.count = ri;
  scene.add(rocks);

  const clouds: THREE.Group[] = [];
  const cloudMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1 });
  for (let i = 0; i < 7; i++) {
    const g = new THREE.Group();
    for (let k = 0; k < 3; k++) {
      const puff = new THREE.Mesh(new THREE.SphereGeometry(2.2 + (k % 2), 8, 6), cloudMat);
      puff.position.set(k * 2.4 - 2, (k % 2) * 0.6, 0);
      puff.scale.y = 0.62;
      g.add(puff);
    }
    g.position.set(-40 + i * 16, 24 + (i % 3) * 4, -20 + (i % 4) * 14);
    scene.add(g);
    clouds.push(g);
  }

  const shadowTex = (() => {
    const c = document.createElement("canvas");
    c.width = 64;
    c.height = 64;
    const g = c.getContext("2d");
    if (g) {
      const grd = g.createRadialGradient(32, 32, 4, 32, 32, 32);
      grd.addColorStop(0, "rgba(0,0,0,0.4)");
      grd.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = grd;
      g.fillRect(0, 0, 64, 64);
    }
    return trackTex(new THREE.CanvasTexture(c));
  })();
  const shadowGeo = new THREE.CircleGeometry(1, 16);
  const shadowMat = new THREE.MeshBasicMaterial({
    map: shadowTex,
    transparent: true,
    depthWrite: false,
  });

  function blob(scale: number) {
    const m = new THREE.Mesh(shadowGeo, shadowMat);
    m.rotation.x = -Math.PI / 2;
    m.scale.setScalar(scale);
    m.position.y = 0.04;
    m.renderOrder = 1;
    scene.add(m);
    return m;
  }

  function collectMats(root: THREE.Object3D) {
    const mats: THREE.MeshStandardMaterial[] = [];
    root.traverse((o) => {
      if (o instanceof THREE.Mesh && o.material instanceof THREE.MeshStandardMaterial) {
        o.castShadow = true;
        mats.push(o.material);
      }
    });
    return mats;
  }

  function makeSoldier(primary: number, secondary: number, hairCol: number) {
    const group = new THREE.Group();
    const skin = new THREE.MeshStandardMaterial({ color: 0xffccaa, roughness: 0.7 });
    const cloth = new THREE.MeshStandardMaterial({ color: primary, roughness: 0.62 });
    const pants = new THREE.MeshStandardMaterial({ color: secondary, roughness: 0.75 });
    const hair = new THREE.MeshStandardMaterial({ color: hairCol, roughness: 0.6 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x24262e, roughness: 0.45, metalness: 0.25 });
    const legGeo = new THREE.CapsuleGeometry(0.09, 0.36, 3, 6);
    const legL = new THREE.Group();
    const legR = new THREE.Group();
    legL.position.set(-0.13, 0.78, 0);
    legR.position.set(0.13, 0.78, 0);
    const lMesh = new THREE.Mesh(legGeo, pants);
    lMesh.position.y = -0.28;
    const rMesh = new THREE.Mesh(legGeo, pants);
    rMesh.position.y = -0.28;
    legL.add(lMesh);
    legR.add(rMesh);
    group.add(legL, legR);
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 0.32, 4, 8), cloth);
    torso.position.y = 1.12;
    group.add(torso);
    const pack = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.32, 0.16), dark);
    pack.position.set(0, 1.16, -0.24);
    group.add(pack);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.23, 14, 12), skin);
    head.position.y = 1.62;
    group.add(head);
    const hairM = new THREE.Mesh(new THREE.SphereGeometry(0.21, 12, 8), hair);
    hairM.position.y = 1.74;
    hairM.scale.set(1.02, 0.62, 1.02);
    group.add(hairM);
    const gun = new THREE.Group();
    gun.position.set(0.26, 1.12, 0.12);
    gun.add(new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.1, 0.42), dark));
    const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.035, 0.26), dark);
    barrel.position.z = 0.3;
    gun.add(barrel);
    const magBox = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.12, 0.08), dark);
    magBox.position.set(0, -0.1, -0.02);
    gun.add(magBox);
    group.add(gun);
    scene.add(group);
    return { group, legs: [legL, legR] as [THREE.Group, THREE.Group], mats: collectMats(group) };
  }

  const wheelGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.2, 10);
  wheelGeo.rotateZ(Math.PI / 2);
  const barrelGeo = new THREE.CylinderGeometry(0.075, 0.095, 1.4, 10);
  barrelGeo.rotateX(Math.PI / 2);

  function makeTank(bodyCol: number, accentCol: number) {
    const group = new THREE.Group();
    const body = new THREE.MeshStandardMaterial({ color: bodyCol, roughness: 0.42, metalness: 0.28 });
    const accent = new THREE.MeshStandardMaterial({ color: accentCol, roughness: 0.38, metalness: 0.2 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x1b1e24, roughness: 0.55, metalness: 0.4 });
    const metal = new THREE.MeshStandardMaterial({ color: 0x9aa3ad, roughness: 0.32, metalness: 0.72 });
    const trackGeo = new THREE.BoxGeometry(0.52, 0.46, 2.55);
    const trackL = new THREE.Mesh(trackGeo, dark);
    trackL.position.set(-1.02, 0.32, 0);
    const trackR = new THREE.Mesh(trackGeo, dark);
    trackR.position.set(1.02, 0.32, 0);
    group.add(trackL, trackR);
    const wheels: THREE.Mesh[] = [];
    for (const side of [-1, 1]) {
      for (const z of [-0.78, 0, 0.78]) {
        const w = new THREE.Mesh(wheelGeo, metal);
        w.position.set(side * 1.02, 0.28, z);
        group.add(w);
        wheels.push(w);
      }
    }
    const hull = new THREE.Mesh(new THREE.BoxGeometry(1.62, 0.52, 2.35), body);
    hull.position.y = 0.62;
    group.add(hull);
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(1.64, 0.1, 2.37), accent);
    stripe.position.y = 0.78;
    group.add(stripe);
    const nose = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.28, 0.42), body);
    nose.position.set(0, 0.52, 1.28);
    group.add(nose);
    const turret = new THREE.Group();
    turret.position.y = 0.98;
    const dome = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.68, 0.4, 14), body);
    turret.add(dome);
    const hatch = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.1, 8), accent);
    hatch.position.y = 0.24;
    turret.add(hatch);
    const pitch = new THREE.Group();
    pitch.position.set(0, 0.05, 0.15);
    const barrel = new THREE.Mesh(barrelGeo, metal);
    barrel.position.z = 0.85;
    pitch.add(barrel);
    turret.add(pitch);
    const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.7, 4), dark);
    ant.position.set(-0.28, 0.5, -0.15);
    turret.add(ant);
    group.add(turret);
    scene.add(group);
    return {
      group,
      bits: { turret, pitch, wheels },
      mats: collectMats(group),
    };
  }

  function makeActor(
    kind: Kind,
    mesh: THREE.Group,
    mats: THREE.MeshStandardMaterial[],
    legs: [THREE.Group, THREE.Group] | null,
    bits: TankBits | null,
    radius: number,
    maxHp: number,
  ): Actor {
    return {
      kind,
      x: 0,
      z: 0,
      yaw: 0,
      speed: 0,
      hp: maxHp,
      maxHp,
      alive: false,
      dying: 0,
      radius,
      cool: 1,
      hitFlash: 0,
      wanderT: 1,
      vspeed: 0,
      mesh,
      shadow: blob(kind === "inf" ? 0.7 : 1.7),
      mats,
      legs,
      bits,
    };
  }

  const playerBuilt = makeTank(0xff7a1a, 0xffe14a);
  const playerTank = makeActor("ptank", playerBuilt.group, playerBuilt.mats, null, playerBuilt.bits, 1.52, 340);
  playerTank.alive = true;
  playerTank.x = 0;
  playerTank.z = 26;

  const heroBuilt = makeSoldier(0x3d7eff, 0x1c2744, 0x2a211c);
  const heroLegs = heroBuilt.legs;

  const infantry: Actor[] = INF_SPAWNS.map(() => {
    const s = makeSoldier(0xe23b4a, 0x2c2433, 0x1a1a1a);
    const a = makeActor("inf", s.group, s.mats, s.legs, null, 0.46, 48);
    a.mesh.visible = false;
    a.shadow.visible = false;
    return a;
  });
  const eTanks: Actor[] = TANK_SPAWNS.map(() => {
    const t = makeTank(0x6d4ea3, 0xff4d6a);
    const a = makeActor("badtank", t.group, t.mats, null, t.bits, 1.52, 190);
    a.mesh.visible = false;
    a.shadow.visible = false;
    return a;
  });

  const marker = new THREE.Mesh(
    new THREE.ConeGeometry(0.26, 0.5, 8),
    new THREE.MeshBasicMaterial({ color: 0xffe14a }),
  );
  scene.add(marker);

  const shield = new THREE.Mesh(
    new THREE.RingGeometry(0.85, 1.05, 24),
    new THREE.MeshBasicMaterial({ color: 0x8af0ff, transparent: true, opacity: 0.8, side: THREE.DoubleSide }),
  );
  shield.rotation.x = -Math.PI / 2;
  scene.add(shield);

  const flash = new THREE.PointLight(0xffe2b0, 0, 9, 2);
  scene.add(flash);

  const puffGeo = new THREE.SphereGeometry(1, 5, 4);
  const puffMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.92, depthWrite: false });
  const puffMesh = new THREE.InstancedMesh(puffGeo, puffMat, 160);
  puffMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  puffMesh.frustumCulled = false;
  puffMesh.count = 160;
  scene.add(puffMesh);
  const puffs: Puff[] = Array.from({ length: 160 }, () => ({
    alive: false,
    x: 0,
    y: -20,
    z: 0,
    vx: 0,
    vy: 0,
    vz: 0,
    life: 0,
    max: 1,
    size: 0.1,
    r: 1,
    g: 1,
    b: 1,
    grav: 9,
  }));

  const shells: Shell[] = Array.from({ length: 14 }, () => {
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.16, 8, 6),
      new THREE.MeshBasicMaterial({ color: 0xffe08a }),
    );
    mesh.visible = false;
    scene.add(mesh);
    return {
      alive: false,
      x: 0,
      y: 0,
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      life: 0,
      owner: "player" as const,
      skip: null,
      mesh,
    };
  });

  const circleBuf = Array.from({ length: 8 }, () => ({ x: 0, z: 0, r: 0 }));
  let circleN = 0;

  let phase: HudSnapshot["phase"] = "menu";
  let mode: HudSnapshot["mode"] = "tank";
  const foot = {
    x: 2.6,
    z: 26,
    yaw: 0,
    vx: 0,
    vz: 0,
    hp: 100,
    mag: MAG,
    reload: 0,
  };
  let camYaw = 0;
  let camPitch = -0.08;
  let snapCam = true;
  let menuAng = 0.4;
  let clock = 0;
  let shake = 0;
  let recoil = 0;
  let score = 0;
  let best = loadBest();
  let wave = 1;
  let shieldT = 0;
  let rifleCd = 0;
  let cannonCd = 0;
  let banner = "";
  let bannerT = 0;
  let waveWait = 0;
  let waveArm = false;
  let hitAt = 0;
  let hurtAt = 0;
  let flashT = 0;
  const keys = new Set<string>();
  let qaKeys: Set<string> | null = null;
  let steerOverride: number | null = null;
  const was = new Set<string>();
  let mouseFire = false;
  let rmb = false;
  let doEnter = false;
  let enterUsed = false;
  let mx = 0;
  let my = 0;
  let stickLX = 0;
  let stickLY = 0;
  let gpFire = false;
  let gpEnterWas = false;
  let gpReloadWas = false;
  let gpPauseWas = false;
  let dead = false;
  let acc = 0;
  const camPosS = new THREE.Vector3(18, 14, 28);
  const lookS = new THREE.Vector3(0, 2, 0);
  const shotDir = new THREE.Vector3(0, -0.08, -1);
  const shotOrigin = new THREE.Vector3();
  const blipBuf: HudSnapshot["blips"] = [];

  function held(code: string) {
    return keys.has(code) || (qaKeys?.has(code) ?? false);
  }
  function edge(code: string) {
    return held(code) && !was.has(code);
  }
  function saveBest() {
    if (score > best) {
      best = score;
      try {
        localStorage.setItem(SAVE_KEY, JSON.stringify({ v: 1, best }));
      } catch {
        /* private mode */
      }
    }
  }
  function setFlashMats(mats: THREE.MeshStandardMaterial[], on: boolean) {
    for (const m of mats) {
      m.emissive.setHex(on ? 0xfff4e0 : 0x000000);
      m.emissiveIntensity = on ? 0.85 : 0;
    }
  }
  function hitsWorld(x: number, z: number, r: number) {
    if (x * x + z * z > (ISLAND_R - r) * (ISLAND_R - r)) return true;
    for (const b of BLOCKS) {
      const nx = Math.max(b.x - b.hw, Math.min(x, b.x + b.hw));
      const nz = Math.max(b.z - b.hd, Math.min(z, b.z + b.hd));
      const dx = x - nx;
      const dz = z - nz;
      if (dx * dx + dz * dz < r * r) return true;
    }
    return false;
  }
  function hitsCircles(x: number, z: number, r: number) {
    for (let i = 0; i < circleN; i++) {
      const c = circleBuf[i];
      const dx = x - c.x;
      const dz = z - c.z;
      const rr = r + c.r;
      if (dx * dx + dz * dz < rr * rr) return true;
    }
    return false;
  }
  function fillCircles(self: Actor | null) {
    circleN = 0;
    const push = (x: number, z: number, r: number) => {
      const c = circleBuf[circleN];
      if (!c) return;
      c.x = x;
      c.z = z;
      c.r = r;
      circleN++;
    };
    if (playerTank.alive && self !== playerTank) push(playerTank.x, playerTank.z, playerTank.radius);
    for (const t of eTanks) if (t.alive && t !== self) push(t.x, t.z, t.radius);
  }
  function moveBody(body: { x: number; z: number }, dx: number, dz: number, r: number) {
    const nx = body.x + dx;
    if (!hitsWorld(nx, body.z, r) && !hitsCircles(nx, body.z, r)) body.x = nx;
    const nz = body.z + dz;
    if (!hitsWorld(body.x, nz, r) && !hitsCircles(body.x, nz, r)) body.z = nz;
  }
  function segmentBlocked(x0: number, z0: number, x1: number, z1: number) {
    const dx = x1 - x0;
    const dz = z1 - z0;
    const len = Math.hypot(dx, dz);
    const steps = Math.max(1, Math.ceil(len / 0.55));
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      const x = x0 + dx * t;
      const z = z0 + dz * t;
      for (const b of BLOCKS) {
        if (Math.abs(x - b.x) <= b.hw && Math.abs(z - b.z) <= b.hd) return true;
      }
    }
    return false;
  }
  function pointInBlock(x: number, y: number, z: number) {
    for (const b of BLOCKS) {
      if (y < 0 || y > b.h) continue;
      if (Math.abs(x - b.x) <= b.hw && Math.abs(z - b.z) <= b.hd) return true;
    }
    return false;
  }
  function spawnPuff(
    x: number,
    y: number,
    z: number,
    color: number,
    speed: number,
    size: number,
    life: number,
    grav: number,
  ) {
    const p = puffs.find((item) => !item.alive);
    if (!p) return;
    _col.set(color);
    p.alive = true;
    p.x = x;
    p.y = y;
    p.z = z;
    const a = Math.random() * Math.PI * 2;
    const u = 0.35 + Math.random() * 0.65;
    p.vx = Math.cos(a) * speed * u;
    p.vz = Math.sin(a) * speed * u;
    p.vy = Math.random() * speed;
    p.life = p.max = life * (0.65 + Math.random() * 0.35);
    p.size = size * (0.55 + Math.random() * 0.6);
    p.r = _col.r;
    p.g = _col.g;
    p.b = _col.b;
    p.grav = grav;
  }
  function burst(x: number, y: number, z: number, color: number, n: number, speed: number, size: number, life: number) {
    for (let i = 0; i < n; i++) spawnPuff(x, y, z, color, speed, size, life, 10);
  }
  function explodeFx(x: number, y: number, z: number, color: number, big: boolean) {
    burst(x, y, z, color, big ? 18 : 8, big ? 7 : 4, big ? 0.38 : 0.2, big ? 0.45 : 0.28);
    burst(x, y + 0.2, z, 0xfff1c9, big ? 8 : 3, big ? 5 : 3, 0.16, 0.22);
    if (big) {
      flash.position.set(x, y + 0.4, z);
      flash.intensity = 12;
      flashT = 0.09;
      shake = Math.min(1.25, shake + 0.5);
      audio.boom();
    }
  }
  function tracer(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, color: number) {
    for (let i = 0; i < 4; i++) {
      const t = (i + 0.4) / 4;
      spawnPuff(
        x0 + (x1 - x0) * t,
        y0 + (y1 - y0) * t,
        z0 + (z1 - z0) * t,
        color,
        0.2,
        0.08,
        0.12,
        0,
      );
    }
  }
  function deactivate(u: Actor) {
    u.alive = false;
    u.dying = 0;
    u.mesh.visible = false;
    u.shadow.visible = false;
    u.speed = 0;
  }
  function activate(u: Actor, x: number, z: number, hp: number) {
    u.x = x;
    u.z = z;
    u.yaw = Math.atan2(-x, -z);
    u.speed = 0;
    u.hp = hp;
    u.maxHp = hp;
    u.alive = true;
    u.dying = 0;
    u.cool = 1.1 + Math.random() * 0.6;
    u.hitFlash = 0;
    u.wanderT = 1;
    u.mesh.visible = true;
    u.mesh.scale.setScalar(1);
    u.mesh.rotation.x = 0;
    u.shadow.visible = true;
    setFlashMats(u.mats, false);
  }
  function countAlive() {
    let n = 0;
    for (const u of infantry) if (u.alive) n++;
    for (const u of eTanks) if (u.alive) n++;
    return n;
  }
  function spawnWave(n: number) {
    const infN = Math.min(INF_SPAWNS.length, 3 + n);
    const tankN = Math.min(TANK_SPAWNS.length, 1 + Math.floor((n - 1) / 2));
    const mul = 1 + (n - 1) * 0.16;
    infantry.forEach((u, i) => {
      if (i < infN) {
        const s = INF_SPAWNS[i];
        activate(u, s[0], s[1], Math.round(46 * mul));
      } else deactivate(u);
    });
    eTanks.forEach((u, i) => {
      if (i < tankN) {
        const s = TANK_SPAWNS[i];
        activate(u, s[0], s[1], Math.round(180 * mul));
      } else deactivate(u);
    });
    banner = `Welle ${n}`;
    bannerT = 2.3;
    audio.wave();
  }
  function hurtActive(amount: number) {
    if (shieldT > 0 || phase !== "play" || amount <= 0) return;
    if (mode === "tank" && playerTank.alive) {
      playerTank.hp -= amount;
      playerTank.hitFlash = 0.1;
      if (playerTank.hp <= 0) destroyPlayerTank();
    } else {
      foot.hp -= amount;
      if (foot.hp <= 0) {
        foot.hp = 0;
        phase = "down";
        saveBest();
        explodeFx(foot.x, 1, foot.z, 0xff5a36, true);
      }
    }
    hurtAt = performance.now();
    shake = Math.min(1.2, shake + 0.32);
    audio.hurt();
    push(true);
  }
  function destroyPlayerTank() {
    if (!playerTank.alive) return;
    playerTank.alive = false;
    playerTank.hp = 0;
    playerTank.speed = 0;
    playerTank.dying = 0.45;
    explodeFx(playerTank.x, 0.8, playerTank.z, 0xff7a1a, true);
    banner = "Panzer zerstört";
    bannerT = 2.2;
    if (mode === "tank") {
      mode = "foot";
      foot.vx = 0;
      foot.vz = 0;
      foot.x = playerTank.x + 2.6;
      foot.z = playerTank.z;
      if (hitsWorld(foot.x, foot.z, 0.42)) {
        foot.x = playerTank.x;
        foot.z = playerTank.z + 3;
      }
      snapCam = true;
    }
    push(true);
  }
  function damageActor(u: Actor, amt: number) {
    if (!u.alive || phase !== "play") return;
    u.hp -= amt;
    u.hitFlash = 0.12;
    hitAt = performance.now();
    if (u.hp <= 0) {
      u.alive = false;
      u.dying = 0.48;
      u.speed = 0;
      score += u.kind === "inf" ? 100 : 450;
      if (u.kind === "inf") burst(u.x, 1.1, u.z, 0xff5a36, 12, 5, 0.22, 0.35);
      else explodeFx(u.x, 0.9, u.z, 0xc084fc, true);
      audio.hit();
      saveBest();
    } else audio.hit();
    push(true);
  }
  function detonate(s: Shell) {
    if (!s.alive) return;
    s.alive = false;
    s.mesh.visible = false;
    const big = s.owner === "player";
    explodeFx(s.x, Math.max(0.3, s.y), s.z, big ? 0xffb703 : 0xff6a3d, true);
    const radius = big ? 4.6 : 3.4;
    const base = big ? 96 : 26;
    for (const u of infantry) splashActor(u, s, radius, base);
    for (const u of eTanks) splashActor(u, s, radius, base);
    const px = mode === "tank" ? playerTank.x : foot.x;
    const pz = mode === "tank" ? playerTank.z : foot.z;
    const bodyR = mode === "tank" ? playerTank.radius : 0.5;
    if (mode === "tank" && !playerTank.alive) return;
    const d = Math.hypot(px - s.x, pz - s.z);
    if (d < radius + bodyR) {
      const fall = 1 - d / (radius + bodyR);
      let amt = base * (0.35 + 0.65 * fall);
      if (s.owner === "player") amt *= 0.38;
      hurtActive(amt);
    }
  }
  function splashActor(u: Actor, s: Shell, radius: number, base: number) {
    if (!u.alive || u === s.skip) return;
    const d = Math.hypot(u.x - s.x, u.z - s.z);
    if (d < radius + u.radius) {
      const fall = 1 - d / (radius + u.radius);
      damageActor(u, base * (0.35 + 0.65 * fall));
    }
  }
  function fireShell(owner: "player" | "enemy", skip: Actor | null, dir: THREE.Vector3, ox: number, oy: number, oz: number, speed: number) {
    const s = shells.find((item) => !item.alive);
    if (!s) return;
    s.alive = true;
    s.owner = owner;
    s.skip = skip;
    s.life = 2.6;
    s.x = ox;
    s.y = oy;
    s.z = oz;
    s.vx = dir.x * speed;
    s.vy = dir.y * speed;
    s.vz = dir.z * speed;
    s.mesh.visible = true;
    s.mesh.position.set(ox, oy, oz);
    const mat = s.mesh.material;
    if (mat instanceof THREE.MeshBasicMaterial) mat.color.setHex(owner === "player" ? 0xffe08a : 0xff7a66);
  }
  function tickShell(s: Shell, dt: number) {
    const sub = 2;
    for (let i = 0; i < sub; i++) {
      const h = dt / sub;
      s.x += s.vx * h;
      s.y += s.vy * h;
      s.z += s.vz * h;
      s.vy -= 14 * h;
      if (!s.alive) return;
      if (s.y < 0.2 || pointInBlock(s.x, s.y, s.z)) {
        detonate(s);
        return;
      }
      for (const u of infantry) {
        if (!u.alive) continue;
        if (hitShellActor(s, u, 1.1, 0.55)) return;
      }
      for (const u of eTanks) {
        if (!u.alive) continue;
        if (hitShellActor(s, u, 0.9, u.radius * 0.85)) return;
      }
      if (s.owner === "enemy" && playerTank.alive && mode === "tank") {
        if (hitShellActor(s, playerTank, 0.9, playerTank.radius * 0.9)) return;
      }
    }
    s.life -= dt;
    if (s.life <= 0) detonate(s);
  }
  function hitShellActor(s: Shell, u: Actor, cy: number, r: number) {
    if (u === s.skip) return false;
    const dx = s.x - u.x;
    const dy = s.y - cy;
    const dz = s.z - u.z;
    if (dx * dx + dy * dy + dz * dz < r * r) {
      detonate(s);
      return true;
    }
    return false;
  }
  function hitscan(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, range: number) {
    let bestT = range;
    let unit: Actor | null = null;
    if (dy < -1e-4) {
      const t = -oy / dy;
      if (t > 0 && t < bestT) bestT = t;
    }
    for (const b of BLOCKS) {
      const t = rayAABB(ox, oy, oz, dx, dy, dz, b, bestT);
      if (t !== null && t > 0 && t < bestT) {
        bestT = t;
        unit = null;
      }
    }
    const consider = (u: Actor, cy: number, r: number) => {
      if (!u.alive) return;
      const t = raySphere(ox, oy, oz, dx, dy, dz, u.x, cy, u.z, r);
      if (t !== null && t < bestT) {
        bestT = t;
        unit = u;
      }
    };
    for (const u of infantry) consider(u, 1.15, 0.58);
    for (const u of eTanks) consider(u, 0.9, 1.35);
    return { t: bestT, unit };
  }
  function tryExit() {
    const rx = Math.cos(playerTank.yaw);
    const rz = -Math.sin(playerTank.yaw);
    const fx = -Math.sin(playerTank.yaw);
    const fz = -Math.cos(playerTank.yaw);
    const options = [
      [rx * 2.7, rz * 2.7],
      [-rx * 2.7, -rz * 2.7],
      [-fx * 3.2, -fz * 3.2],
    ];
    for (const [ox, oz] of options) {
      const x = playerTank.x + ox;
      const z = playerTank.z + oz;
      if (!hitsWorld(x, z, 0.42)) {
        foot.x = x;
        foot.z = z;
        foot.vx = 0;
        foot.vz = 0;
        foot.yaw = camYaw;
        mode = "foot";
        snapCam = true;
        return;
      }
    }
  }
  function tryEnter() {
    if (!playerTank.alive) return;
    if (Math.hypot(foot.x - playerTank.x, foot.z - playerTank.z) > 3.35) return;
    mode = "tank";
    foot.vx = 0;
    foot.vz = 0;
    snapCam = true;
  }
  function resetMatch() {
    score = 0;
    wave = 1;
    mode = "tank";
    foot.hp = 100;
    foot.mag = MAG;
    foot.reload = 0;
    foot.vx = 0;
    foot.vz = 0;
    foot.x = 2.6;
    foot.z = 26;
    foot.yaw = 0;
    playerTank.x = 0;
    playerTank.z = 26;
    playerTank.yaw = 0;
    playerTank.speed = 0;
    playerTank.hp = playerTank.maxHp;
    playerTank.alive = true;
    playerTank.dying = 0;
    playerTank.mesh.visible = true;
    playerTank.mesh.scale.setScalar(1);
    playerTank.shadow.visible = true;
    camYaw = 0;
    camPitch = -0.1;
    snapCam = true;
    shieldT = 2.5;
    rifleCd = 0;
    cannonCd = 0;
    waveWait = 0;
    waveArm = false;
    shake = 0;
    for (const s of shells) {
      s.alive = false;
      s.mesh.visible = false;
    }
    spawnWave(1);
  }

  function readPads() {
    mx = pad.moveX;
    my = pad.moveY;
    stickLX = 0;
    stickLY = 0;
    gpFire = false;
    let gpEnter = false;
    let gpReload = false;
    let gpPause = false;
    const list = navigator.getGamepads?.();
    if (list) {
      for (const g of list) {
        if (!g) continue;
        const left = radial(g.axes[0] ?? 0, g.axes[1] ?? 0);
        mx += left.x;
        my += -left.y;
        const right = radial(g.axes[2] ?? 0, g.axes[3] ?? 0);
        stickLX += right.x;
        stickLY += right.y;
        const trigger = g.buttons[7]?.value ?? 0;
        if (trigger > 0.45 || g.buttons[0]?.pressed || g.buttons[5]?.pressed) gpFire = true;
        if (g.buttons[3]?.pressed) gpEnter = true;
        if (g.buttons[2]?.pressed) gpReload = true;
        if (g.buttons[9]?.pressed) gpPause = true;
      }
    }
    if (gpEnter && !gpEnterWas) pad.queueEnter = true;
    if (gpReload && !gpReloadWas) pad.queueReload = true;
    if (gpPause && !gpPauseWas) pad.queuePause = true;
    gpEnterWas = gpEnter;
    gpReloadWas = gpReload;
    gpPauseWas = gpPause;
    if (held("KeyD") || held("ArrowRight")) mx += 1;
    if (held("KeyA") || held("ArrowLeft")) mx -= 1;
    if (held("KeyW") || held("ArrowUp")) my += 1;
    if (held("KeyS") || held("ArrowDown")) my -= 1;
  }

  function wantsFire() {
    return mouseFire || pad.fire || gpFire || held("Space");
  }

  function sim(dt: number) {
    if (phase !== "play") return;
    shieldT = Math.max(0, shieldT - dt);
    bannerT = Math.max(0, bannerT - dt);
    rifleCd = Math.max(0, rifleCd - dt);
    cannonCd = Math.max(0, cannonCd - dt);
    if (foot.reload > 0) {
      foot.reload -= dt;
      if (foot.reload <= 0) {
        foot.reload = 0;
        foot.mag = MAG;
      }
    }
    if (doEnter && !enterUsed) {
      enterUsed = true;
      if (mode === "tank") tryExit();
      else tryEnter();
    }
    if (mode === "tank" && playerTank.alive) {
      // Chase-cam basis: forward = (-sin yaw, 0, -cos yaw). A → steer +1 → +yaw → nose left.
      let steer = -mx;
      let throttle = my;
      if (steerOverride !== null) steer = steerOverride;
      steer = clamp(steer, -1, 1);
      throttle = clamp(throttle, -1, 1);
      if (throttle > 0.05) playerTank.speed = Math.min(16, playerTank.speed + 30 * throttle * dt);
      else if (throttle < -0.05) playerTank.speed = Math.max(-7.5, playerTank.speed - 22 * dt);
      else {
        const f = Math.min(Math.abs(playerTank.speed), 18 * dt);
        playerTank.speed -= Math.sign(playerTank.speed) * f;
        if (Math.abs(playerTank.speed) < 0.04) playerTank.speed = 0;
      }
      const speedFactor = 0.42 + 0.58 * Math.min(1, Math.abs(playerTank.speed) / 8);
      const reverse = playerTank.speed >= -0.15 ? 1 : -1;
      playerTank.yaw += steer * 2.05 * speedFactor * reverse * dt;
      const fx = -Math.sin(playerTank.yaw);
      const fz = -Math.cos(playerTank.yaw);
      fillCircles(playerTank);
      moveBody(playerTank, fx * playerTank.speed * dt, fz * playerTank.speed * dt, playerTank.radius);
      if (Math.abs(playerTank.speed) > 6) {
        for (const u of infantry) {
          if (!u.alive) continue;
          const d = Math.hypot(u.x - playerTank.x, u.z - playerTank.z);
          if (d < playerTank.radius + u.radius * 0.8) damageActor(u, 40);
        }
      }
    } else if (mode === "foot" && foot.hp > 0) {
      const mag = Math.hypot(mx, my);
      const nx = mag > 1 ? mx / mag : mx;
      const ny = mag > 1 ? my / mag : my;
      const sprint = held("ShiftLeft") || held("ShiftRight") || pad.sprint;
      const sp = sprint ? 11.2 : 6.9;
      const fwx = -Math.sin(camYaw);
      const fwz = -Math.cos(camYaw);
      const rtx = Math.cos(camYaw);
      const rtz = -Math.sin(camYaw);
      const wishX = (fwx * ny + rtx * nx) * sp;
      const wishZ = (fwz * ny + rtz * nx) * sp;
      const k = 1 - Math.exp(-14 * dt);
      foot.vx += (wishX - foot.vx) * k;
      foot.vz += (wishZ - foot.vz) * k;
      fillCircles(null);
      const beforeX = foot.x;
      const beforeZ = foot.z;
      moveBody(foot, foot.vx * dt, foot.vz * dt, 0.42);
      if (Math.abs(foot.x - beforeX) < 1e-5) foot.vx = 0;
      if (Math.abs(foot.z - beforeZ) < 1e-5) foot.vz = 0;
      const fspeed = Math.hypot(foot.vx, foot.vz);
      const firing = wantsFire();
      if (fspeed > 0.55 && !firing) foot.yaw = dampAngle(foot.yaw, Math.atan2(-foot.vx, -foot.vz), 14, dt);
      else foot.yaw = dampAngle(foot.yaw, camYaw, 12, dt);
      const drag = Math.min(Math.abs(playerTank.speed), 22 * dt);
      playerTank.speed -= Math.sign(playerTank.speed) * drag;
    }

    const targetX = mode === "tank" ? playerTank.x : foot.x;
    const targetZ = mode === "tank" ? playerTank.z : foot.z;
    for (const u of infantry) simInf(u, dt, targetX, targetZ);
    for (const u of eTanks) simETank(u, dt, targetX, targetZ);
    for (const s of shells) if (s.alive) tickShell(s, dt);
    for (const p of puffs) {
      if (!p.alive) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.alive = false;
        continue;
      }
      p.vy -= p.grav * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      if (p.y < 0.06) {
        p.y = 0.06;
        p.vy *= -0.25;
      }
    }

    const left = countAlive();
    if (left === 0 && !waveArm) {
      waveArm = true;
      waveWait = 2.15;
      score += 220 * wave;
      banner = "Welle geschafft";
      bannerT = 2.15;
      audio.wave();
      saveBest();
    }
    if (waveWait > 0) {
      waveWait -= dt;
      if (waveWait <= 0 && waveArm) {
        waveArm = false;
        wave += 1;
        if (!playerTank.alive) {
          playerTank.alive = true;
          playerTank.hp = playerTank.maxHp * 0.7;
          playerTank.dying = 0;
          playerTank.mesh.visible = true;
          playerTank.shadow.visible = true;
          playerTank.mesh.scale.setScalar(1);
        } else playerTank.hp = Math.min(playerTank.maxHp, playerTank.hp + 100);
        foot.hp = Math.min(100, foot.hp + 30);
        spawnWave(wave);
        shieldT = Math.max(shieldT, 1.4);
      }
    }
  }

  function simInf(u: Actor, dt: number, px: number, pz: number) {
    if (!u.alive) return;
    const dx = px - u.x;
    const dz = pz - u.z;
    const dist = Math.hypot(dx, dz) || 0.0001;
    const see = dist < 27 && !segmentBlocked(u.x, u.z, px, pz);
    let vx = 0;
    let vz = 0;
    if (see) {
      if (dist > 7.5) {
        vx = (dx / dist) * 3.5;
        vz = (dz / dist) * 3.5;
      } else if (dist < 4) {
        vx = (-dz / dist) * 2.5;
        vz = (dx / dist) * 2.5;
      }
      u.cool -= dt;
      if (u.cool <= 0 && dist < 25) {
        u.cool = 0.78 + Math.random() * 0.5;
        tracer(u.x, 1.25, u.z, px, mode === "tank" ? 1.1 : 1.25, pz, 0xff8d7a);
        const accShot = mode === "tank" ? 0.4 : 0.55;
        if (Math.random() < accShot) hurtActive(mode === "tank" ? 7 : 8);
      }
      u.yaw = dampAngle(u.yaw, Math.atan2(-dx, -dz), 8, dt);
    } else {
      u.wanderT -= dt;
      if (u.wanderT <= 0) {
        u.wanderT = 1.4 + Math.random() * 2;
        u.yaw = Math.random() * Math.PI * 2;
      }
      vx = -Math.sin(u.yaw) * 1.7;
      vz = -Math.cos(u.yaw) * 1.7;
    }
    fillCircles(null);
    const bx = u.x;
    const bz = u.z;
    moveBody(u, vx * dt, vz * dt, u.radius);
    u.vspeed = Math.hypot(u.x - bx, u.z - bz) / dt;
  }

  function simETank(u: Actor, dt: number, px: number, pz: number) {
    if (!u.alive) return;
    const dx = px - u.x;
    const dz = pz - u.z;
    const dist = Math.hypot(dx, dz) || 0.0001;
    const desired = Math.atan2(-dx, -dz);
    const diff = Math.atan2(Math.sin(desired - u.yaw), Math.cos(desired - u.yaw));
    u.yaw += clamp(diff, -1.2 * dt, 1.2 * dt);
    if (dist > 18) u.speed = Math.min(7.2, u.speed + 9 * dt);
    else if (dist < 11) u.speed = Math.max(-3.2, u.speed - 11 * dt);
    else u.speed *= Math.max(0, 1 - 3.2 * dt);
    const fx = -Math.sin(u.yaw);
    const fz = -Math.cos(u.yaw);
    fillCircles(u);
    moveBody(u, fx * u.speed * dt, fz * u.speed * dt, u.radius);
    u.cool -= dt;
    if (u.cool <= 0 && dist < 34 && Math.abs(diff) < 0.5 && !segmentBlocked(u.x, u.z, px, pz)) {
      u.cool = 2.35;
      _dir.set(fx, 0.06, fz).normalize();
      fireShell("enemy", u, _dir, u.x + fx * 2.35, 1.15, u.z + fz * 2.35, 30);
    }
    u.vspeed = Math.abs(u.speed);
  }

  function tryFire() {
    if (phase !== "play") return;
    const firing = wantsFire();
    if (!firing) return;
    if (mode === "tank") {
      if (!playerTank.alive || cannonCd > 0) return;
      cannonCd = CANNON_CD;
      _dir.copy(shotDir).normalize();
      _muzzle.set(playerTank.x, 1.35, playerTank.z).addScaledVector(_dir, 2.35);
      fireShell("player", playerTank, _dir, _muzzle.x, _muzzle.y, _muzzle.z, 50);
      audio.cannon();
      shake = Math.min(1, shake + 0.26);
      recoil = 0.028;
      flash.position.copy(_muzzle);
      flash.intensity = 8;
      flashT = 0.05;
      return;
    }
    if (foot.hp <= 0) return;
    if (foot.reload > 0) return;
    if (foot.mag <= 0) {
      foot.reload = 1.25;
      audio.empty();
      audio.reload();
      return;
    }
    if (rifleCd > 0) return;
    rifleCd = RIFLE_CD;
    foot.mag -= 1;
    audio.rifle();
    recoil = 0.011;
    const moving = Math.hypot(foot.vx, foot.vz) > 1.2;
    const sp = moving ? 0.03 : 0.007;
    _dir.copy(shotDir);
    _dir.x += (Math.random() - 0.5) * sp;
    _dir.y += (Math.random() - 0.5) * sp;
    _dir.z += (Math.random() - 0.5) * sp;
    _dir.normalize();
    const hit = hitscan(shotOrigin.x, shotOrigin.y, shotOrigin.z, _dir.x, _dir.y, _dir.z, 78);
    const endX = shotOrigin.x + _dir.x * hit.t;
    const endY = shotOrigin.y + _dir.y * hit.t;
    const endZ = shotOrigin.z + _dir.z * hit.t;
    tracer(shotOrigin.x, shotOrigin.y, shotOrigin.z, endX, endY, endZ, 0xfff0b0);
    spawnPuff(endX, endY, endZ, 0xffe7a8, 2.2, 0.12, 0.16, 4);
    if (hit.unit) damageActor(hit.unit, 17);
    if (foot.mag <= 0) {
      foot.reload = 1.25;
      audio.reload();
    }
  }

  function updateCamera(dt: number) {
    if (phase === "menu") {
      menuAng += dt * 0.15;
      camera.position.set(Math.sin(menuAng) * 34, 15.2, Math.cos(menuAng) * 28 + 8);
      camera.lookAt(0, 2.1, 4);
      return;
    }
    const px = mode === "tank" ? playerTank.x : foot.x;
    const pz = mode === "tank" ? playerTank.z : foot.z;
    const dist = mode === "tank" ? 8.5 : 4.75;
    const camH = mode === "tank" ? 3.2 : 1.82;
    const lookAhead = mode === "tank" ? 12 : 8.2;
    const lookH = mode === "tank" ? 1.5 : 1.38;
    const shoulder = mode === "tank" ? 0 : 0.62;
    const sinY = Math.sin(camYaw);
    const cosY = Math.cos(camYaw);
    const fwdX = -sinY;
    const fwdZ = -cosY;
    const rightX = cosY;
    const rightZ = -sinY;
    const pitch = camPitch;
    const desX = px + sinY * dist + rightX * shoulder;
    const desY = camH + -pitch * dist * 0.85;
    const desZ = pz + cosY * dist + rightZ * shoulder;
    const lookX = px + fwdX * lookAhead + rightX * shoulder * 0.2;
    const lookY = lookH + pitch * lookAhead * 0.75;
    const lookZ = pz + fwdZ * lookAhead + rightZ * shoulder * 0.2;
    _head.set(px, 1.55, pz);
    _des.set(desX, desY, desZ);
    _to.copy(_des).sub(_head);
    const len = _to.length() || 0.001;
    _to.multiplyScalar(1 / len);
    let tHit = len;
    for (const b of BLOCKS) {
      const t = rayAABB(_head.x, _head.y, _head.z, _to.x, _to.y, _to.z, b, len);
      if (t !== null && t > 0.35 && t < tHit) tHit = t;
    }
    _des.copy(_head).addScaledVector(_to, Math.max(0.55, tHit * 0.92));
    _lookT.set(lookX, lookY, lookZ);
    if (snapCam) {
      camPosS.copy(_des);
      lookS.copy(_lookT);
      snapCam = false;
    } else {
      const k = 1 - Math.exp(-14 * dt);
      camPosS.lerp(_des, k);
      lookS.lerp(_lookT, k);
    }
    camera.position.copy(camPosS);
    camera.position.x += Math.sin(clock * 73) * shake * 0.22;
    camera.position.y += Math.cos(clock * 81) * shake * 0.12;
    camera.lookAt(lookS);
    camera.getWorldDirection(shotDir);
    shotOrigin.copy(camera.position).addScaledVector(shotDir, 0.75);
    shake = Math.max(0, shake - dt * 1.5);
  }

  function syncActor(u: Actor, dt: number) {
    if (u.dying > 0 && !u.alive) {
      u.dying -= dt;
      const k = Math.max(0.01, u.dying / 0.48);
      u.mesh.scale.setScalar(k);
      u.mesh.position.y = (1 - k) * 0.8;
      if (u.dying <= 0) {
        u.mesh.visible = false;
        u.shadow.visible = false;
      }
    } else if (u.alive) {
      u.mesh.scale.setScalar(1);
      u.mesh.position.set(u.x, 0, u.z);
      u.mesh.rotation.x = 0;
      u.mesh.rotation.y = u.yaw + Math.PI;
      u.shadow.visible = true;
    }
    u.shadow.position.set(u.x, 0.045, u.z);
    if (u.hitFlash > 0) {
      u.hitFlash -= dt;
      setFlashMats(u.mats, u.hitFlash > 0);
    }
    if (u.legs) {
      const swing = Math.min(0.75, u.vspeed * 0.11);
      u.legs[0].rotation.x = Math.sin(clock * 8 + u.x) * swing;
      u.legs[1].rotation.x = Math.sin(clock * 8 + u.x + Math.PI) * swing;
    }
    if (u.bits && u.alive) {
      for (const w of u.bits.wheels) w.rotation.x -= u.speed * dt * 2.3;
      if (u.kind === "badtank") {
        u.bits.turret.rotation.y = 0;
        u.bits.pitch.rotation.x = 0;
      }
    }
  }

  function syncVisuals(dt: number) {
    syncActor(playerTank, dt);
    if (playerTank.alive && playerTank.bits) {
      if (phase === "menu") playerTank.bits.turret.rotation.y = Math.sin(clock * 0.45) * 0.55;
      else {
        playerTank.bits.turret.rotation.y = camYaw - playerTank.yaw;
        playerTank.bits.pitch.rotation.x = -clamp(camPitch, -0.45, 0.35);
      }
    }
    const showHero = phase === "menu" || (mode === "foot" && foot.hp > 0 && phase !== "down");
    heroBuilt.group.visible = showHero;
    const hx = phase === "menu" ? 2.7 : foot.x;
    const hz = phase === "menu" ? 26 : foot.z;
    const bob = phase === "play" && mode === "foot" ? Math.abs(Math.sin(clock * 9)) * Math.min(0.06, Math.hypot(foot.vx, foot.vz) * 0.01) : 0;
    heroBuilt.group.position.set(hx, bob, hz);
    heroBuilt.group.rotation.y = (phase === "menu" ? -0.6 : foot.yaw) + Math.PI;
    const swing = phase === "play" && mode === "foot" ? Math.min(0.7, Math.hypot(foot.vx, foot.vz) * 0.1) : Math.sin(clock * 1.5) * 0.05;
    heroLegs[0].rotation.x = Math.sin(clock * 8) * swing;
    heroLegs[1].rotation.x = Math.sin(clock * 8 + Math.PI) * swing;
    for (const u of infantry) syncActor(u, dt);
    for (const u of eTanks) syncActor(u, dt);
    for (const s of shells) {
      if (!s.alive) {
        s.mesh.visible = false;
        continue;
      }
      s.mesh.visible = true;
      s.mesh.position.set(s.x, s.y, s.z);
    }
    marker.visible = phase === "play" && mode === "foot" && playerTank.alive;
    marker.position.set(playerTank.x, 3.1 + Math.sin(clock * 3) * 0.15, playerTank.z);
    const sx = mode === "tank" ? playerTank.x : foot.x;
    const sz = mode === "tank" ? playerTank.z : foot.z;
    shield.visible = shieldT > 0 && phase === "play";
    shield.position.set(sx, 0.08, sz);
    shield.scale.setScalar(mode === "tank" ? 2.5 : 1.15);
    let drawn = 0;
    for (const p of puffs) {
      if (!p.alive) continue;
      const sc = Math.max(0.02, p.size * (0.35 + 0.65 * (p.life / p.max)));
      _dummy.position.set(p.x, p.y, p.z);
      _dummy.scale.setScalar(sc);
      _dummy.rotation.set(0, 0, 0);
      _dummy.updateMatrix();
      puffMesh.setMatrixAt(drawn, _dummy.matrix);
      _col.setRGB(p.r, p.g, p.b);
      puffMesh.setColorAt(drawn, _col);
      drawn++;
    }
    for (let i = drawn; i < puffs.length; i++) {
      _dummy.position.set(0, -30, 0);
      _dummy.scale.setScalar(0.001);
      _dummy.rotation.set(0, 0, 0);
      _dummy.updateMatrix();
      puffMesh.setMatrixAt(i, _dummy.matrix);
    }
    puffMesh.instanceMatrix.needsUpdate = true;
    if (puffMesh.instanceColor) puffMesh.instanceColor.needsUpdate = true;
    if (flashT > 0) {
      flashT -= dt;
      if (flashT <= 0) flash.intensity = 0;
    }
    for (let i = 0; i < clouds.length; i++) {
      const c = clouds[i];
      c.position.x += dt * (1.6 + i * 0.35);
      if (c.position.x > 70) c.position.x = -70;
    }
  }

  let lastPush = 0;
  function push(force = false) {
    const now = performance.now();
    if (!force && now - lastPush < 90) return;
    lastPush = now;
    const px = mode === "tank" ? playerTank.x : phase === "menu" ? 0 : foot.x;
    const pz = mode === "tank" ? playerTank.z : phase === "menu" ? 26 : foot.z;
    const py = mode === "tank" ? playerTank.yaw : camYaw;
    blipBuf.length = 0;
    for (const u of infantry) if (u.alive) blipBuf.push({ x: u.x, z: u.z, k: "inf" });
    for (const u of eTanks) if (u.alive) blipBuf.push({ x: u.x, z: u.z, k: "badtank" });
    if ((mode === "foot" || phase === "menu") && playerTank.alive) blipBuf.push({ x: playerTank.x, z: playerTank.z, k: "tank" });
    const near =
      mode === "foot" &&
      playerTank.alive &&
      Math.hypot(foot.x - playerTank.x, foot.z - playerTank.z) < 3.35;
    const snap: HudSnapshot = {
      ready: true,
      phase,
      mode,
      hp: Math.max(0, foot.hp),
      hpMax: 100,
      tankHp: Math.max(0, playerTank.hp),
      tankMax: playerTank.maxHp,
      tankAlive: playerTank.alive,
      mag: foot.mag,
      magMax: MAG,
      reloading: foot.reload > 0,
      cannon: cannonCd <= 0 ? 1 : 1 - cannonCd / CANNON_CD,
      score,
      best,
      wave,
      left: countAlive(),
      banner: bannerT > 0 ? banner : "",
      hit: hitAt,
      hurt: hurtAt,
      nearTank: near,
      x: px,
      z: pz,
      yaw: py,
      blips: blipBuf.slice(),
      shield: shieldT,
    };
    opts.onHud(snap);
  }

  function resize() {
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    if (w < 2 || h < 2) return;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
  }
  resize();
  const ro = new ResizeObserver(() => resize());
  ro.observe(canvas);

  const GAME_KEYS = new Set([
    "KeyW",
    "KeyA",
    "KeyS",
    "KeyD",
    "ArrowUp",
    "ArrowDown",
    "ArrowLeft",
    "ArrowRight",
    "Space",
    "KeyE",
    "KeyR",
    "KeyP",
    "ShiftLeft",
    "ShiftRight",
  ]);

  function onKeyDown(e: KeyboardEvent) {
    keys.add(e.code);
    if (GAME_KEYS.has(e.code)) e.preventDefault();
  }
  function onKeyUp(e: KeyboardEvent) {
    keys.delete(e.code);
  }
  function onBlur() {
    keys.clear();
    mouseFire = false;
    rmb = false;
  }
  function onMouseDown(e: MouseEvent) {
    if (e.button === 0) mouseFire = true;
    if (e.button === 2) rmb = true;
  }
  function onMouseUp(e: MouseEvent) {
    if (e.button === 0) mouseFire = false;
    if (e.button === 2) rmb = false;
  }
  function onMouseMove(e: MouseEvent) {
    if (phase !== "play") return;
    if (document.pointerLockElement === canvas || rmb) {
      pad.lookX += e.movementX;
      pad.lookY += e.movementY;
    }
  }
  function onContext(e: Event) {
    e.preventDefault();
  }
  function tryLock() {
    try {
      const ret = canvas.requestPointerLock();
      if (ret && typeof (ret as Promise<void>).catch === "function") {
        void (ret as Promise<void>).catch(() => undefined);
      }
    } catch {
      /* iframe or unsupported */
    }
  }
  function onVis() {
    if (document.visibilityState === "visible") {
      try {
        void audio.unlock();
      } catch {
        /* ignore */
      }
    } else onBlur();
  }

  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("blur", onBlur);
  window.addEventListener("mouseup", onMouseUp);
  window.addEventListener("mousemove", onMouseMove);
  canvas.addEventListener("mousedown", onMouseDown);
  canvas.addEventListener("contextmenu", onContext);
  document.addEventListener("visibilitychange", onVis);

  playerTank.mesh.position.set(0, 0, 26);
  playerTank.mesh.rotation.y = Math.PI;
  heroBuilt.group.position.set(2.7, 0, 26);

  const probe = {
    getYaw: () => playerTank.yaw,
    getSpeed: () => playerTank.speed,
    setKeys: (codes: string[]) => {
      qaKeys = new Set(codes);
    },
    setSteer: (v: number) => {
      steerOverride = v;
    },
  };
  window.__controlsTest = probe;

  let last = performance.now();
  function frame(now: number) {
    if (dead) return;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    clock += dt;
    readPads();
    camYaw -= pad.lookX * (mode === "tank" ? 0.00205 : 0.00225);
    camPitch -= pad.lookY * (mode === "tank" ? 0.0019 : 0.00215);
    pad.lookX = 0;
    pad.lookY = 0;
    camYaw -= stickLX * 2.15 * dt;
    camPitch -= stickLY * 1.45 * dt;
    camPitch = clamp(camPitch, mode === "tank" ? -0.7 : -0.95, mode === "tank" ? 0.4 : 0.62);
    camPitch += recoil;
    recoil *= Math.exp(-8 * dt);
    doEnter = edge("KeyE") || pad.queueEnter;
    pad.queueEnter = false;
    if (edge("KeyR") || pad.queueReload) {
      pad.queueReload = false;
      if (phase === "play" && mode === "foot" && foot.reload <= 0 && foot.mag < MAG) {
        foot.reload = 1.25;
        audio.reload();
      }
    } else pad.queueReload = false;
    if (pad.queuePause || edge("Escape") || edge("KeyP")) {
      pad.queuePause = false;
      if (phase === "play") phase = "pause";
      else if (phase === "pause") phase = "play";
      push(true);
    } else pad.queuePause = false;
    enterUsed = false;
    acc += dt;
    let steps = 0;
    while (acc >= STEP && steps < 5) {
      sim(STEP);
      acc -= STEP;
      steps++;
    }
    updateCamera(dt);
    tryFire();
    syncVisuals(dt);
    if (phase === "play" && mode === "tank" && playerTank.alive) audio.engine(Math.abs(playerTank.speed) / 16);
    else audio.engine(0);
    push(false);
    renderer.render(scene, camera);
    was.clear();
    const watch = [
      "KeyW",
      "KeyA",
      "KeyS",
      "KeyD",
      "ArrowUp",
      "ArrowDown",
      "ArrowLeft",
      "ArrowRight",
      "KeyE",
      "KeyR",
      "KeyP",
      "Escape",
      "Space",
      "ShiftLeft",
      "ShiftRight",
    ];
    for (const code of watch) if (held(code)) was.add(code);
    requestAnimationFrame(frame);
  }

  requestAnimationFrame(frame);
  push(true);

  function start() {
    audio.unlock();
    resetMatch();
    phase = "play";
    tryLock();
    push(true);
  }
  function togglePause() {
    if (phase === "play") phase = "pause";
    else if (phase === "pause") {
      phase = "play";
      tryLock();
    }
    push(true);
  }
  function dispose() {
    dead = true;
    ro.disconnect();
    window.removeEventListener("keydown", onKeyDown);
    window.removeEventListener("keyup", onKeyUp);
    window.removeEventListener("blur", onBlur);
    window.removeEventListener("mouseup", onMouseUp);
    window.removeEventListener("mousemove", onMouseMove);
    canvas.removeEventListener("mousedown", onMouseDown);
    canvas.removeEventListener("contextmenu", onContext);
    document.removeEventListener("visibilitychange", onVis);
    if (window.__controlsTest === probe) delete window.__controlsTest;
    audio.dispose();
    const dumped = new Set<object>();
    scene.traverse((obj) => {
      if (obj instanceof THREE.Mesh || obj instanceof THREE.InstancedMesh) {
        if (!dumped.has(obj.geometry)) {
          dumped.add(obj.geometry);
          obj.geometry.dispose();
        }
        const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
        for (const m of mats) {
          if (!dumped.has(m)) {
            dumped.add(m);
            m.dispose();
          }
        }
      }
    });
    for (const t of textures) t.dispose();
    renderer.dispose();
  }
  return {
    start,
    togglePause,
    dispose,
    toggleSound: () => audio.toggle(),
    soundOn: () => audio.soundOn(),
  };
}
