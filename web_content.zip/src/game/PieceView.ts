import Phaser from 'phaser';
import { BLOCK_TEX, TEX } from './constants';
import type { Shape } from './shapes';

/** Visual representation of a piece (tray + dragging). Children live in grid-pixel units. */
export class PieceView extends Phaser.GameObjects.Container {
  readonly blocks: Phaser.GameObjects.Image[] = [];
  private readonly shadows: Phaser.GameObjects.Image[] = [];
  homeX = 0;
  homeY = 0;
  slot = 0;

  constructor(
    scene: Phaser.Scene,
    readonly shape: Shape,
    cell: number,
    block: number,
    withShadow: boolean
  ) {
    super(scene, 0, 0);
    const scale = block / BLOCK_TEX;
    const ox = (shape.w - 1) / 2;
    const oy = (shape.h - 1) / 2;

    if (withShadow) {
      for (const [r, c] of shape.cells) {
        const s = scene.add
          .image((c - ox) * cell + block * 0.04, (r - oy) * cell + block * 0.16, TEX, 'flat')
          .setScale(scale * 1.02)
          .setTint(0x000000)
          .setAlpha(0.28)
          .setVisible(false);
        this.shadows.push(s);
        this.add(s);
      }
    }
    for (const [r, c] of shape.cells) {
      const img = scene.add
        .image((c - ox) * cell, (r - oy) * cell, TEX, `block_${shape.color}`)
        .setScale(scale);
      this.blocks.push(img);
      this.add(img);
    }
    scene.add.existing(this);
  }

  setShadowVisible(v: boolean): void {
    for (const s of this.shadows) s.setVisible(v);
  }

  /** Dim pieces that cannot be placed anywhere. */
  setAvailable(v: boolean): void {
    for (const b of this.blocks) b.setAlpha(v ? 1 : 0.4);
  }
}
