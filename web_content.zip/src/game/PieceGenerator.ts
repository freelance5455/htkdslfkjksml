import { Board } from './Board';
import { SHAPES, type Shape } from './shapes';

const SET_SIZE = 3;

/**
 * Weighted random piece generator with the kind of "fairness" the original has:
 * it prefers sets that can actually be placed on the current board and bias
 * towards smaller pieces when the board is crowded.
 */
export class PieceGenerator {
  constructor(private readonly rand: () => number = Math.random) {}

  private pickIndex(weights: number[]): number {
    let total = 0;
    for (const w of weights) total += w;
    let x = this.rand() * total;
    for (let i = 0; i < weights.length; i++) {
      x -= weights[i];
      if (x <= 0) return i;
    }
    return weights.length - 1;
  }

  private weightsFor(board: Board): number[] {
    const fill = board.filledCount() / (board.size * board.size);
    return SHAPES.map((s) => {
      let w = s.weight;
      const n = s.cells.length;
      if (fill > 0.45) {
        const t = (fill - 0.45) / 0.55; // 0..1
        if (n <= 3) w *= 1 + t * 2.2;
        else if (n >= 6) w *= Math.max(0.15, 1 - t * 1.6);
        else if (n === 5) w *= Math.max(0.4, 1 - t * 0.9);
      }
      return w;
    });
  }

  private randomSet(weights: number[]): Shape[] {
    const set: Shape[] = [];
    let guard = 0;
    while (set.length < SET_SIZE && guard++ < 50) {
      const s = SHAPES[this.pickIndex(weights)];
      const dup = set.filter((x) => x.id === s.id).length;
      if (dup >= 2) continue;
      set.push(s);
    }
    while (set.length < SET_SIZE) set.push(SHAPES[this.pickIndex(weights)]);
    return set;
  }

  /** Can all pieces be placed in some order? Budgeted DFS. */
  private canPlaceAll(board: Board, set: Shape[]): boolean {
    let budget = 6000;
    const b = board.clone();
    const used = new Array(set.length).fill(false);
    const dfs = (depth: number): boolean => {
      if (depth === set.length) return true;
      for (let i = 0; i < set.length; i++) {
        if (used[i]) continue;
        used[i] = true;
        const s = set[i];
        for (let r = 0; r <= b.size - s.h; r++) {
          for (let c = 0; c <= b.size - s.w; c++) {
            if (--budget < 0) return true; // give up gracefully: treat as OK
            if (!b.canPlace(s, r, c)) continue;
            b.place(s, r, c, s.color);
            const lines = b.getFullLines();
            const cleared = lines.rows.length || lines.cols.length ? b.clearLines(lines) : [];
            const ok = dfs(depth + 1);
            for (const cell of cleared) b.set(cell.r, cell.c, cell.color);
            b.remove(s, r, c);
            if (ok) return true;
          }
        }
        used[i] = false;
      }
      return false;
    };
    return dfs(0);
  }

  generateSet(board: Board): Shape[] {
    const weights = this.weightsFor(board);
    const anyFits = SHAPES.some((s) => board.canPlaceAnywhere(s));
    const fill = board.filledCount() / (board.size * board.size);

    let fallback: Shape[] | null = null;
    for (let attempt = 0; attempt < 18; attempt++) {
      const set = this.randomSet(weights);
      if (!anyFits) return set;
      const fitting = set.filter((s) => board.canPlaceAnywhere(s)).length;
      if (fitting === 0) continue;
      if (!fallback || fitting === SET_SIZE) fallback = set;
      // Most of the time make sure the whole set is solvable like the original does.
      if (fitting === SET_SIZE && (fill < 0.3 || this.canPlaceAll(board, set))) return set;
      if (attempt > 10 && fitting >= 2) return set;
    }
    if (fallback) return fallback;

    // Force at least one piece that fits.
    const fittingIdx: number[] = [];
    const fittingW: number[] = [];
    SHAPES.forEach((s, i) => {
      if (board.canPlaceAnywhere(s)) {
        fittingIdx.push(i);
        fittingW.push(weights[i]);
      }
    });
    const set = this.randomSet(weights);
    if (fittingIdx.length) {
      set[Math.floor(this.rand() * SET_SIZE)] = SHAPES[fittingIdx[this.pickIndex(fittingW)]];
    }
    return set;
  }
}
