import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { ActiveBoss, ActiveCreature, ActiveEnemy, ActiveNpc, EntityManager } from './ai/EntityManager';
import { SoundEngine } from './audio/SoundEngine';
import { CombatVFXManager } from './combat/CombatVFX';
import { BOSS_MAP } from './config/bosses';
import { ITEMS, ITEM_MAP } from './config/items';
import { ELEMENT_META, SKILL_TREE, SPELL_MAP } from './config/magic';
import { QUEST_MAP } from './config/questsAndNpcs';
import { REGIONS } from './config/regions';
import { buildProceduralTextures, ProceduralTextureSet } from './materials/ProceduralTextures';
import { animateHumanoid, buildHumanoidRig, HumanoidRig } from './models/CharacterModels';
import { buildCreatureModel } from './models/CreatureModels';
import { MultiplayerClient } from './network/MultiplayerClient';
import {
  CameraMode,
  ChatMessage,
  ElementType,
  PlacedStructure,
  PlayerAppearance,
  PlayerStats,
  RegionId,
  RemotePlayer,
  SaveData,
  StructureType,
  WeaponCategory,
  WeatherType,
} from './types/gameTypes';
import { ChestInstance, CryptInterior, CryptPortal } from './world/DungeonAndCastleBuilder';
import { getRegionAt, getTerrainHeight, isClimbableSlope, isLavaAt, WATER_LEVEL, WORLD_RADIUS } from './world/TerrainMath';
import { buildFantasyWorld, ResourceNode, WorldHandles } from './world/WorldBuilder';

export interface HudSnapshot {
  stats: PlayerStats;
  regionId: RegionId;
  regionName: string;
  timeOfDay: number;
  weather: WeatherType;
  cameraMode: CameraMode;
  isSwimming: boolean;
  isClimbing: boolean;
  isMounted: boolean;
  frozenShieldActive: boolean;
  nearbyPrompt: string | null;
  nearbyTargetKind: 'npc' | 'resource' | 'horse' | 'dragon' | 'campfire' | null;
  activeBoss: { id: string; name: string; title: string; hp: number; maxHp: number; phase: number; locked: boolean } | null;
  targetEntity: {
    name: string;
    kind: 'creature' | 'enemy';
    hp: number;
    maxHp: number;
    level?: number;
  } | null;
  spellCooldowns: Record<string, number>;
  position: { x: number; y: number; z: number; yaw: number };
  fpsEntities: {
    creatures: Array<{ x: number; z: number; name: string }>;
    enemies: Array<{ x: number; z: number }>;
    npcs: Array<{ x: number; z: number; name: string }>;
    bosses: Array<{ x: number; z: number; defeated: boolean }>;
  };
}

export interface EngineCallbacks {
  onHudUpdate: (snap: HudSnapshot) => void;
  onStateChange: (data: SaveData) => void;
  onNotification: (msg: string, tone?: 'info' | 'warn' | 'epic') => void;
  onOpenNpc: (npcId: string) => void;
  onStoryEnding: () => void;
  onMultiplayerStatus: (status: 'offline' | 'connecting' | 'online', roomCode: string, players: RemotePlayer[]) => void;
  onChatMessage: (msg: ChatMessage) => void;
}

// Pre-allocated scratch math objects (zero GC in loop)
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _camTarget = new THREE.Vector3();

interface LootDrop {
  id: string;
  itemId: string;
  count: number;
  gold?: number;
  mesh: THREE.Group;
  x: number;
  y: number;
  z: number;
  age: number;
}

export class GameEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private composer: EffectComposer | null = null;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean;
  private isMobileDevice: boolean;
  private textures: ProceduralTextureSet;
  private world: WorldHandles;
  private entities: EntityManager;
  private vfx: CombatVFXManager;
  public sound: SoundEngine;
  public mp: MultiplayerClient;

  private playerRig: HumanoidRig;
  private mountMesh: THREE.Group;
  private remoteRigs = new Map<string, { rig: HumanoidRig; targetPos: THREE.Vector3; targetYaw: number; anim: string }>();
  private lootDrops: LootDrop[] = [];
  private activeCrypt: CryptInterior | null = null;
  private portalCooldown = 0;

  public saveData: SaveData;
  private callbacks: EngineCallbacks;

  private pos = new THREE.Vector3(0, 2, 16);
  private velY = 0;
  private grounded = true;
  private coyoteTimer = 0;
  private jumpBufferTimer = 0;
  private yaw = Math.PI;
  private pitch = 0.28;
  private cameraMode: CameraMode = 'third';
  private sprinting = false;
  private isAttacking = false;
  private attackHeld = false;
  private attackTimer = 0;
  private attackCooldown = 0;
  private dodgeTimer = 0;
  private dodgeCooldown = 0;
  private frozenShieldTimer = 0;
  private slowTimer = 0;
  private poisonTimer = 0;
  private weather: WeatherType = 'clear';
  private weatherTimer = 45;
  private footstepTimer = 0;
  private spellCooldowns: Record<string, number> = {};
  private lastHitTarget: { kind: 'creature' | 'enemy'; uid: string; timer: number } | null = null;

  // Input states
  private keys: Record<string, boolean> = {};
  private joyVec = { x: 0, y: 0 };
  private isMounted = false;
  private isSwimming = false;
  private isClimbing = false;

  // Building preview
  private buildModeType: StructureType | null = null;
  private buildRotation = 0;
  private buildPreviewMesh: THREE.Group | null = null;

  private frameId = 0;
  private clock = new THREE.Clock();
  private hudTimer = 0;
  private autosaveTimer = 0;
  private disposed = false;

  constructor(container: HTMLElement, initialSave: SaveData, callbacks: EngineCallbacks) {
    this.container = container;
    this.saveData = initialSave;
    this.callbacks = callbacks;
    this.isMobileDevice = (navigator.maxTouchPoints || 0) > 0 || window.innerWidth < 900;
    this.pos.set(initialSave.position.x, initialSave.position.y, initialSave.position.z);
    this.yaw = initialSave.position.yaw;

    // Detect Software WebGL
    this.isSoftwareGl = (() => {
      const probe = document.createElement('canvas').getContext('webgl2');
      if (!probe) return true;
      const ext = probe.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
      const gpu = String(probe.getParameter(param));
      probe.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.renderer = new THREE.WebGLRenderer({
      // Mobile GPUs benefit more from a stable render budget than full-screen MSAA.
      antialias: !this.isSoftwareGl && !this.isMobileDevice && initialSave.settings.graphics !== 'Low',
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    this.renderer.setPixelRatio(
      this.getRenderPixelRatio(initialSave.settings.graphics)
    );
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl && initialSave.settings.graphics !== 'Low';
    // PCF is cheaper than PCFSoft on mobile while retaining readable shadows.
    this.renderer.shadowMap.type = this.isMobileDevice ? THREE.PCFShadowMap : THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2('#a8d5e5', 0.0038);

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    const w = container.clientWidth || window.innerWidth;
    const h = container.clientHeight || window.innerHeight;
    this.camera = new THREE.PerspectiveCamera(68, w / h, 0.15, 720);

    this.textures = buildProceduralTextures(this.isSoftwareGl ? 1 : this.renderer.capabilities.getMaxAnisotropy());
    this.world = buildFantasyWorld(this.scene, this.textures, initialSave.settings.graphics);
    for (const s of initialSave.structures) {
      this.world.addPlacedStructure(s);
    }

    this.entities = new EntityManager(
      this.scene,
      initialSave.defeatedBosses,
      initialSave.tamedCompanion,
      initialSave.tamedMount,
      this.textures.contactShadowTex
    );
    this.vfx = new CombatVFXManager(this.scene);
    this.sound = new SoundEngine();
    this.sound.setSettings(
      initialSave.settings.audioEnabled,
      initialSave.settings.musicVolume,
      initialSave.settings.sfxVolume
    );

    if (!this.isSoftwareGl && initialSave.settings.graphics !== 'Low') {
      this.composer = new EffectComposer(this.renderer);
      this.composer.addPass(new RenderPass(this.scene, this.camera));
      this.composer.addPass(new UnrealBloomPass(new THREE.Vector2(w, h), 0.34, 0.45, 0.85));
      this.composer.addPass(new OutputPass());
      // Run post-processing below native resolution on phones; bloom remains visible at a fraction of the cost.
      this.composer.setPixelRatio(this.isMobileDevice ? 0.72 : 1);
    }

    // Build Player Avatar & Mount Horse mesh
    const wItem = initialSave.equipped.weapon ? ITEM_MAP[initialSave.equipped.weapon] : undefined;
    this.playerRig = buildHumanoidRig(
      initialSave.appearance,
      (wItem?.weaponCategory as WeaponCategory) || 'Sword',
      wItem?.color || '#cbd5e1',
      Boolean(initialSave.equipped.shield)
    );
    this.scene.add(this.playerRig.group);

    this.mountMesh = buildCreatureModel({
      id: 'moon_horse',
      name: 'Moon Horse',
      region: 'green_forest',
      behavior: 'rideable_mount',
      description: '',
      hp: 260,
      speed: 14,
      scale: 1.25,
      primaryColor: '#cbd5e1',
      accentColor: '#93c5fd',
    });
    this.mountMesh.visible = false;
    this.scene.add(this.mountMesh);

    this.mp = new MultiplayerClient({
      onStatusChange: (status, roomCode) => {
        this.callbacks.onMultiplayerStatus(status, roomCode, []);
      },
      onPlayersUpdate: (players) => {
        this.syncRemotePlayers(players);
        this.callbacks.onMultiplayerStatus('online', '', players);
      },
      onRemoteAction: (act) => {
        const remote = this.remoteRigs.get(act.id);
        if (!remote) return;
        if (act.action === 'spell' && act.element) {
          const origin = remote.rig.group.position.clone().add(new THREE.Vector3(0, 1.5, 0));
          const dir = new THREE.Vector3(-Math.sin(remote.targetYaw), 0, -Math.cos(remote.targetYaw));
          this.vfx.spawnProjectile({
            origin,
            dir,
            speed: 28,
            damage: 0,
            element: act.element,
            radius: 2,
            fromPlayer: false,
          });
        } else if (act.action === 'attack') {
          this.vfx.spawnSlashArc(remote.rig.group.position, remote.targetYaw, '#93c5fd');
        }
      },
      onChatMessage: (msg) => this.callbacks.onChatMessage(msg),
      onBossSync: (bossId, hp) => {
        const b = this.entities.bosses.find((item) => item.def.id === bossId);
        if (b && !b.defeated) {
          b.hp = Math.min(b.hp, hp);
          if (b.hp <= 0) this.handleBossDefeated(b, true);
        }
      },
      onRemoteStructure: (s) => {
        if (!this.saveData.structures.some((item) => item.id === s.id)) {
          this.saveData.structures.push(s);
          this.world.addPlacedStructure(s);
        }
      },
    });

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.tick();
  }

  private getRenderPixelRatio(quality: 'Low' | 'Medium' | 'High' | 'Ultra'): number {
    if (this.isSoftwareGl || quality === 'Low') return 1;
    const dpr = window.devicePixelRatio || 1;
    if (this.isMobileDevice) {
      // Tuned to keep fill-rate and memory use under control on mid-range Android GPUs.
      const cap = quality === 'Ultra' ? 1.35 : quality === 'High' ? 1.2 : 1.0;
      return Math.min(dpr, cap);
    }
    return Math.min(dpr, quality === 'Ultra' ? 1.75 : 1.5);
  }

  private bindEvents() {
    window.addEventListener('resize', this.onResize);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
  }

  private onResize = () => {
    if (this.disposed) return;
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    this.composer?.setSize(w, h);
  };

  private onKeyDown = (e: KeyboardEvent) => {
    const tag = (e.target as HTMLElement)?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    this.keys[e.code] = true;
    this.sound.init();
    if (e.code === 'Space') {
      e.preventDefault();
      this.jump();
    }
    if (e.code === 'KeyV') this.toggleCameraMode();
    if (e.code === 'KeyE') this.interact();
    if (e.code === 'KeyF') this.performAttack();
    if (e.code === 'KeyQ') this.performDodge();
    if (e.code === 'Digit1') this.castElement('fire');
    if (e.code === 'Digit2') this.castElement('ice');
    if (e.code === 'Digit3') this.castElement('water');
    if (e.code === 'Digit4') this.castElement('lightning');
    if (e.code === 'KeyR' && this.buildModeType) this.rotateBuildPreview();
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;
  };

  // Public Touch & UI Control Methods
  public setJoystickVector(x: number, y: number) {
    this.joyVec.x = THREE.MathUtils.clamp(x, -1, 1);
    this.joyVec.y = THREE.MathUtils.clamp(y, -1, 1);
  }

  public rotateCamera(deltaX: number, deltaY: number) {
    const sens = 0.0045 * this.saveData.settings.cameraSensitivity;
    const ySign = this.saveData.settings.invertY ? -1 : 1;
    this.yaw -= deltaX * sens;
    this.pitch = THREE.MathUtils.clamp(this.pitch + deltaY * sens * ySign, -0.95, 1.15);
  }

  public toggleCameraMode() {
    this.cameraMode = this.cameraMode === 'third' ? 'first' : 'third';
    this.playerRig.group.visible = this.cameraMode === 'third';
  }

  public setSprint(active: boolean) {
    this.sprinting = active;
  }

  public setAttackHeld(active: boolean) {
    this.attackHeld = active;
    if (active) {
      this.performAttack();
    }
  }

  public jump() {
    this.sound.init();
    if (this.isSwimming) {
      this.velY = 6.5;
      return;
    }
    this.jumpBufferTimer = 0.15;
  }

  public performDodge() {
    if (this.dodgeCooldown > 0 || this.saveData.stats.stamina < 20) return;
    this.saveData.stats.stamina -= 20;
    this.dodgeTimer = 0.28;
    this.dodgeCooldown = 1.0;
    this.sound.playJump();
  }

  public rebuildPlayerModel() {
    const prevPos = this.playerRig.group.position.clone();
    const prevRot = this.playerRig.group.rotation.y;
    this.scene.remove(this.playerRig.group);
    const wItem = this.saveData.equipped.weapon ? ITEM_MAP[this.saveData.equipped.weapon] : undefined;
    this.playerRig = buildHumanoidRig(
      this.saveData.appearance,
      (wItem?.weaponCategory as WeaponCategory) || 'Sword',
      wItem?.color || '#cbd5e1',
      Boolean(this.saveData.equipped.shield)
    );
    this.playerRig.group.position.copy(prevPos);
    this.playerRig.group.rotation.y = prevRot;
    this.playerRig.group.visible = this.cameraMode === 'third';
    this.scene.add(this.playerRig.group);
  }

  public updateAppearance(appearance: PlayerAppearance) {
    this.saveData.appearance = appearance;
    this.rebuildPlayerModel();
    this.callbacks.onStateChange({ ...this.saveData });
  }

  public getComputedStats() {
    const s = this.saveData.stats;
    let atk = s.baseStrength;
    let def = s.baseDefense;
    let mag = s.baseMagic;
    let spd = s.baseSpeed;
    for (const itemId of Object.values(this.saveData.equipped)) {
      if (!itemId) continue;
      const item = ITEM_MAP[itemId];
      if (!item) continue;
      atk += item.attackBonus || 0;
      def += item.defenseBonus || 0;
      mag += item.magicBonus || 0;
      spd += item.speedBonus || 0;
    }
    // Skill tree bonuses
    atk += (this.saveData.skillRanks.blade_mastery || 0) * 6;
    def += (this.saveData.skillRanks.iron_skin || 0) * 5;
    spd += (this.saveData.skillRanks.windrunner || 0) * 0.8;
    return { atk, def, mag, spd };
  }

  public performAttack() {
    this.sound.init();
    if (this.attackCooldown > 0) return;
    const wItem = this.saveData.equipped.weapon ? ITEM_MAP[this.saveData.equipped.weapon] : undefined;
    const wCat = wItem?.weaponCategory || 'Sword';
    const { atk } = this.getComputedStats();

    this.isAttacking = true;
    this.attackTimer = 0.28;
    this.attackCooldown = wCat === 'Dagger' ? 0.32 : wCat === 'Greatsword' || wCat === 'Axe' ? 0.62 : 0.45;
    this.sound.playSwordSwing();

    const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    this.mp.sendAction('attack');

    if (wCat === 'Bow') {
      const origin = this.pos.clone().add(new THREE.Vector3(0, 1.45, 0));
      const dir = new THREE.Vector3(
        -Math.sin(this.yaw) * Math.cos(this.pitch),
        -Math.sin(this.pitch) * 0.6 + 0.05,
        -Math.cos(this.yaw) * Math.cos(this.pitch)
      ).normalize();
      this.vfx.spawnProjectile({
        origin,
        dir,
        speed: 38,
        damage: atk * 1.15,
        element: 'physical',
        radius: 1.6,
        fromPlayer: true,
      });
      return;
    }

    // Melee cleave arc
    this.vfx.spawnSlashArc(this.pos, this.yaw, wItem?.color || '#fde68a');
    const range = wCat === 'Greatsword' ? 4.8 : 3.7;
    const hitOrigin = this.pos.clone().addScaledVector(forward, 1.6);

    for (const en of this.entities.enemies) {
      if (en.dead) continue;
      if (Math.hypot(en.x - hitOrigin.x, en.z - hitOrigin.z) <= range && Math.abs(en.y - this.pos.y) < 4.5) {
        this.damageEnemy(en, atk, 'physical');
      }
    }
    for (const b of this.entities.bosses) {
      if (b.defeated || b.locked) continue;
      if (Math.hypot(b.x - hitOrigin.x, b.z - hitOrigin.z) <= range + 2.8) {
        this.damageBoss(b, atk, 'physical');
      }
    }
    for (const cr of this.entities.creatures) {
      if (cr.dead || cr.tamed) continue;
      if (Math.hypot(cr.x - hitOrigin.x, cr.z - hitOrigin.z) <= range + 0.6 && Math.abs(cr.y - this.pos.y) < 4.5) {
        this.damageCreature(cr, atk);
      }
    }
  }

  public castElement(element: ElementType) {
    this.sound.init();
    const spellId = this.saveData.selectedSpells[element];
    const spell = SPELL_MAP[spellId];
    if (!spell) return;

    if ((this.spellCooldowns[spell.id] || 0) > 0) return;
    if (this.saveData.stats.mana < spell.manaCost) {
      this.callbacks.onNotification('Not enough Mana!', 'warn');
      return;
    }

    this.saveData.stats.mana -= spell.manaCost;
    const cdMult = element === 'lightning' ? Math.max(0.65, 1 - (this.saveData.skillRanks.stormcaller || 0) * 0.06) : 1;
    this.spellCooldowns[spell.id] = spell.cooldown * cdMult;
    this.isAttacking = true;
    this.attackTimer = 0.3;
    this.sound.playSpell(element);
    this.mp.sendAction('spell', { element, spellId });

    const { mag } = this.getComputedStats();
    const levelBoost = 1 + ((this.saveData.spellLevels[spell.id] || 1) - 1) * 0.22;
    const skillKey =
      element === 'fire' ? 'pyromancy' : element === 'ice' ? 'cryomancy' : element === 'water' ? 'hydromancy' : 'stormcaller';
    const elemBoost = 1 + (this.saveData.skillRanks[skillKey] || 0) * 0.12;
    const totalPower = (spell.baseDamage + mag * 1.35) * levelBoost * elemBoost;

    const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const targetPoint = this.pos.clone().addScaledVector(forward, Math.min(spell.range, 16));
    targetPoint.y = getTerrainHeight(targetPoint.x, targetPoint.z);

    if (spell.isHeal) {
      this.saveData.stats.hp = Math.min(this.saveData.stats.maxHp, this.saveData.stats.hp + Math.round(totalPower));
      this.poisonTimer = 0;
      this.slowTimer = 0;
      this.vfx.spawnRingBurst(this.pos, '#38bdf8', 5, 0.7);
      this.callbacks.onNotification(`Healing Water restored ${Math.round(totalPower)} HP!`, 'info');
      return;
    }

    if (spell.isShield) {
      this.frozenShieldTimer = 8.0;
      this.callbacks.onNotification('Frozen Shield active (-50% damage taken for 8s)', 'info');
      return;
    }

    if (spell.id === 'fireball' || spell.id === 'ice_projectile' || spell.id === 'water_projectile' || spell.id === 'lightning_bolt') {
      const origin = this.pos.clone().add(new THREE.Vector3(0, 1.5, 0));
      const dir = new THREE.Vector3(
        -Math.sin(this.yaw) * Math.cos(this.pitch),
        -Math.sin(this.pitch) * 0.5,
        -Math.cos(this.yaw) * Math.cos(this.pitch)
      ).normalize();
      this.vfx.spawnProjectile({
        origin,
        dir,
        speed: element === 'lightning' ? 46 : 30,
        damage: totalPower,
        element,
        radius: spell.radius,
        fromPlayer: true,
        spellId: spell.id,
      });
      return;
    }

    if (spell.id === 'meteor_strike') {
      this.vfx.spawnMeteor(targetPoint);
      this.applyAoeDamage(targetPoint, spell.radius, totalPower, 'fire');
      return;
    }

    if (spell.id === 'ice_spikes') {
      this.vfx.spawnIceSpikes(targetPoint);
      this.applyAoeDamage(targetPoint, spell.radius, totalPower, 'ice', true);
      return;
    }

    if (spell.id === 'lightning_storm') {
      for (let i = 0; i < 4; i++) {
        const offset = new THREE.Vector3((Math.random() - 0.5) * 9, 0, (Math.random() - 0.5) * 9);
        const p = targetPoint.clone().add(offset);
        p.y = getTerrainHeight(p.x, p.z);
        this.vfx.spawnLightningPillar(p);
      }
      this.applyAoeDamage(targetPoint, spell.radius, totalPower, 'lightning');
      return;
    }

    if (spell.id === 'chain_lightning') {
      const targets = this.entities.enemies
        .filter((e) => !e.dead && Math.hypot(e.x - this.pos.x, e.z - this.pos.z) <= spell.range)
        .slice(0, 4);
      let prev = this.pos.clone().add(new THREE.Vector3(0, 1.5, 0));
      for (const en of targets) {
        const ep = new THREE.Vector3(en.x, en.y + 1.2, en.z);
        this.vfx.spawnChainBeam(prev, ep);
        this.damageEnemy(en, totalPower, 'lightning');
        prev = ep;
      }
      for (const b of this.entities.bosses) {
        if (!b.defeated && !b.locked && Math.hypot(b.x - this.pos.x, b.z - this.pos.z) <= spell.range) {
          this.vfx.spawnChainBeam(prev, new THREE.Vector3(b.x, b.y + 2.5, b.z));
          this.damageBoss(b, totalPower, 'lightning');
        }
      }
      return;
    }

    // AoE Wave / Explosion / Vortex centered near caster or forward point
    const aoeCenter = spell.id.includes('explosion') ? this.pos : targetPoint;
    this.vfx.spawnRingBurst(aoeCenter, ELEMENT_META[element].color, spell.radius, 0.6);
    this.applyAoeDamage(aoeCenter, spell.radius, totalPower, element, element === 'ice');
  }

  private applyAoeDamage(center: THREE.Vector3, radius: number, dmg: number, element: ElementType, applySlow = false) {
    for (const en of this.entities.enemies) {
      if (en.dead) continue;
      if (Math.hypot(en.x - center.x, en.z - center.z) <= radius + 1.2) {
        if (applySlow) en.slowTimer = 4.5;
        this.damageEnemy(en, dmg, element);
      }
    }
    for (const b of this.entities.bosses) {
      if (b.defeated || b.locked) continue;
      if (Math.hypot(b.x - center.x, b.z - center.z) <= radius + 3.5) {
        this.damageBoss(b, dmg, element);
      }
    }
    for (const cr of this.entities.creatures) {
      if (cr.dead || cr.tamed) continue;
      if (Math.hypot(cr.x - center.x, cr.z - center.z) <= radius + 1.2) {
        this.damageCreature(cr, dmg);
      }
    }
  }

  private damageCreature(cr: ActiveCreature, rawDmg: number) {
    if (cr.tamed || cr.dead) return;
    const finalDmg = Math.max(1, Math.round(rawDmg));
    cr.hp = Math.max(0, cr.hp - finalDmg);
    cr.hitFlash = 0.16;
    cr.fleeTimer = 5.0;
    this.lastHitTarget = { kind: 'creature', uid: cr.uid, timer: 5.0 };
    this.sound.playHit(false);

    if (cr.hp <= 0) {
      cr.dead = true;
      cr.respawnTimer = 35;
      cr.mesh.visible = false;
      cr.hpBar.group.visible = false;
      this.gainXp(15);
      const dropId =
        cr.def.id === 'royal_stag' || cr.def.id === 'crystal_fox' || cr.def.id === 'magical_butterflies' || cr.def.id === 'small_dragon' || cr.def.id === 'air_jellyfish'
          ? 'magic_dust'
          : cr.def.id === 'rock_turtle'
            ? 'herbs'
            : 'raw_meat';
      this.addItem(dropId, 1);
      this.callbacks.onNotification(`${cr.def.name} defeated (+15 XP, +1 ${ITEM_MAP[dropId]?.name || dropId})`, 'info');
      this.callbacks.onStateChange({ ...this.saveData });
    }
  }

  private spawnLootOrb(x: number, y: number, z: number, itemId: string, count: number, gold?: number) {
    const item = ITEM_MAP[itemId];
    const color = item?.color || '#fbbf24';
    const isGear = Boolean(item?.slot || item?.rarity === 'Legendary' || item?.rarity === 'Mythical');
    const g = new THREE.Group();
    g.position.set(x, y, z);

    const orb = new THREE.Mesh(
      isGear ? new THREE.OctahedronGeometry(0.42, 0) : new THREE.SphereGeometry(0.28, 10, 8),
      new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: isGear ? 1.55 : 0.95,
        roughness: 0.2,
      })
    );
    orb.position.y = 0.55;
    g.add(orb);

    if (isGear) {
      const beam = new THREE.Mesh(
        new THREE.CylinderGeometry(0.06, 0.24, 3.2, 8),
        new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.45 })
      );
      beam.position.y = 1.6;
      g.add(beam);
    }

    this.scene.add(g);
    this.lootDrops.push({
      id: `ld_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      itemId,
      count,
      gold,
      mesh: g,
      x,
      y,
      z,
      age: 0,
    });
  }

  private updateLootDrops(dt: number, elapsed: number) {
    for (let i = this.lootDrops.length - 1; i >= 0; i--) {
      const ld = this.lootDrops[i];
      ld.age += dt;
      ld.mesh.rotation.y = elapsed * 2.8;
      ld.mesh.position.y = ld.y + Math.sin(elapsed * 4 + i) * 0.14;

      const dx = this.pos.x - ld.x;
      const dz = this.pos.z - ld.z;
      const dist = Math.hypot(dx, dz);

      if (dist < 6.5 && ld.age > 0.25) {
        const pull = Math.min(14 * dt, dist);
        ld.x += (dx / (dist || 1)) * pull;
        ld.z += (dz / (dist || 1)) * pull;
        ld.mesh.position.x = ld.x;
        ld.mesh.position.z = ld.z;
      }

      if (dist < 1.9 && ld.age > 0.2) {
        this.addItem(ld.itemId, ld.count);
        if (ld.gold) this.saveData.stats.gold += ld.gold;
        const item = ITEM_MAP[ld.itemId];
        const tone = item?.rarity === 'Mythical' || item?.rarity === 'Legendary' || item?.rarity === 'Epic' ? 'epic' : 'info';
        const goldTxt = ld.gold ? ` +${ld.gold} Gold` : '';
        this.callbacks.onNotification(`Looted +${ld.count} ${item?.name || ld.itemId}${goldTxt}`, tone);
        this.scene.remove(ld.mesh);
        this.lootDrops.splice(i, 1);
        this.callbacks.onStateChange({ ...this.saveData });
      }
    }
  }

  private damageEnemy(en: ActiveEnemy, rawDmg: number, element: ElementType | 'physical') {
    let mult = 1;
    if (element !== 'physical') {
      if (en.def.weakness === element) mult = 1.45;
      else if (en.def.resistance === element) mult = 0.65;
    }
    const finalDmg = Math.max(1, Math.round(rawDmg * mult));
    en.hp = Math.max(0, en.hp - finalDmg);
    en.hitFlash = 0.15;
    this.lastHitTarget = { kind: 'enemy', uid: en.uid, timer: 5.0 };
    this.sound.playHit(mult > 1);

    if (en.hp <= 0 && !en.dead) {
      en.dead = true;
      en.respawnTimer = en.respawnTimer < 0 ? -1 : 28;
      en.mesh.visible = false;
      en.hpBar.group.visible = false;
      this.gainXp(en.def.xpReward);
      const goldDrop = Math.max(4, Math.round(en.def.xpReward * 0.35));

      // Guaranteed primary resource drop + secondary loot orbs on the ground!
      let spawned = 0;
      en.def.loot.forEach((drop, idx) => {
        if (idx === 0 || Math.random() <= drop.chance) {
          const angle = idx * 2.1;
          const qty = idx === 0 && Math.random() < 0.4 ? 2 : 1;
          this.spawnLootOrb(
            en.x + Math.cos(angle) * 0.9,
            en.y,
            en.z + Math.sin(angle) * 0.9,
            drop.itemId,
            qty,
            idx === 0 ? goldDrop : undefined
          );
          spawned++;
        }
      });
      if (spawned === 0) {
        this.saveData.stats.gold += goldDrop;
      }
      this.advanceQuestObjective('kill_enemy', en.def.id, 1);
      this.callbacks.onStateChange({ ...this.saveData });
    }
  }

  private damageBoss(b: ActiveBoss, rawDmg: number, element: ElementType | 'physical') {
    const mult = element !== 'physical' && b.def.weakness === element ? 1.4 : 1.0;
    const finalDmg = Math.max(1, Math.round(rawDmg * mult));
    b.hp = Math.max(0, b.hp - finalDmg);
    b.hitFlash = 0.15;
    this.sound.playHit(true);
    this.mp.sendBossHp(b.def.id, b.hp);

    if (b.hp <= 0 && !b.defeated) {
      this.handleBossDefeated(b, false);
    }
  }

  private handleBossDefeated(b: ActiveBoss, fromNetwork: boolean) {
    b.defeated = true;
    b.mesh.visible = false;
    if (!this.saveData.defeatedBosses.includes(b.def.id)) {
      this.saveData.defeatedBosses.push(b.def.id);
    }
    if (!fromNetwork) {
      this.gainXp(b.def.xpReward);
      this.saveData.stats.gold += 350;
      const allDrops: Array<{ itemId: string; count: number }> = [
        ...b.def.rewards.map((itemId) => ({ itemId, count: 1 })),
        ...(b.def.resourceDrops || []),
      ];
      allDrops.forEach((drop, idx) => {
        const a = (idx / Math.max(1, allDrops.length)) * Math.PI * 2;
        const dist = 2.2 + (idx % 2) * 1.4;
        this.spawnLootOrb(b.x + Math.cos(a) * dist, b.y, b.z + Math.sin(a) * dist, drop.itemId, drop.count);
      });
    }
    this.advanceQuestObjective('kill_boss', b.def.id, 1);
    this.entities.refreshBossLocks(this.saveData.defeatedBosses);
    this.callbacks.onNotification(`VICTORY! ${b.def.name} defeated! Legendary gear & resources dropped!`, 'epic');
    if (b.def.id === 'boss_lord_of_darkness') {
      this.callbacks.onStoryEnding();
    }
    this.callbacks.onStateChange({ ...this.saveData });
  }

  public gainXp(amount: number) {
    const s = this.saveData.stats;
    s.xp += amount;
    while (s.xp >= s.xpToNext) {
      s.xp -= s.xpToNext;
      s.level += 1;
      s.xpToNext = Math.round(s.xpToNext * 1.32);
      s.skillPoints += 2;
      s.maxHp += 20;
      s.maxMana += 15;
      s.baseStrength += 2;
      s.baseDefense += 1;
      s.baseMagic += 2;
      s.hp = s.maxHp;
      s.mana = s.maxMana;
      this.sound.playLevelUp();
      this.callbacks.onNotification(`Level Up! Reached Level ${s.level} (+2 Skill Points)`, 'epic');
    }
  }

  public addItem(itemId: string, qty: number) {
    const existing = this.saveData.inventory.find((i) => i.itemId === itemId);
    if (existing) existing.quantity += qty;
    else this.saveData.inventory.push({ itemId, quantity: qty });
    this.advanceQuestObjective('collect_item', itemId, qty);
  }

  public consumeItem(itemId: string, qty: number): boolean {
    const idx = this.saveData.inventory.findIndex((i) => i.itemId === itemId);
    if (idx < 0 || this.saveData.inventory[idx].quantity < qty) return false;
    this.saveData.inventory[idx].quantity -= qty;
    if (this.saveData.inventory[idx].quantity <= 0) {
      this.saveData.inventory.splice(idx, 1);
    }
    return true;
  }

  public getItemCount(itemId: string): number {
    return this.saveData.inventory.find((i) => i.itemId === itemId)?.quantity || 0;
  }

  public advanceQuestObjective(targetType: string, targetId: string, delta: number) {
    let changed = false;
    for (const qp of Object.values(this.saveData.quests)) {
      if (qp.completed) continue;
      const qDef = QUEST_MAP[qp.questId];
      if (!qDef) continue;
      let allDone = true;
      for (const obj of qDef.objectives) {
        if (obj.targetType === targetType && (obj.targetId === targetId || obj.targetId === 'any')) {
          const prev = qp.counts[obj.id] || 0;
          const next = targetType === 'collect_item' ? Math.max(prev, this.getItemCount(obj.targetId)) : Math.min(obj.requiredCount, prev + delta);
          if (next !== prev) {
            qp.counts[obj.id] = next;
            changed = true;
          }
        }
        if ((qp.counts[obj.id] || 0) < obj.requiredCount) {
          allDone = false;
        }
      }
      if (allDone && !qp.completed) {
        qp.completed = true;
        changed = true;
        this.callbacks.onNotification(`Quest Ready to Claim: ${qDef.title}`, 'epic');
      }
    }
    if (changed) this.callbacks.onStateChange({ ...this.saveData });
  }

  private useCryptPortal(portal: CryptPortal) {
    this.portalCooldown = 1.6;
    this.pos.set(portal.targetX, portal.targetY, portal.targetZ);
    this.velY = 0;
    if (portal.isExit) {
      this.activeCrypt = null;
      this.callbacks.onNotification('Returned to the Overworld!', 'info');
    } else {
      this.activeCrypt = this.world.crypts.find((c) => c.id === portal.cryptId) || null;
      if (this.activeCrypt) {
        this.callbacks.onNotification(`Entered ${this.activeCrypt.name}! Beware of Traps & Guardians!`, 'epic');
      }
    }
    this.sound.playSpell('lightning');
  }

  private openChest(ch: ChestInstance) {
    ch.opened = true;
    ch.lidMesh.rotation.x = -1.1;
    this.sound.playLevelUp();
    this.saveData.stats.gold += ch.gold;
    ch.rewards.forEach((r, idx) => {
      const a = idx * 1.8;
      this.spawnLootOrb(ch.x + Math.cos(a) * 1.4, ch.y, ch.z + Math.sin(a) * 1.4, r.itemId, r.count);
    });
    this.callbacks.onNotification(`Opened ${ch.label}! +${ch.gold} Gold & Treasure dropped!`, 'epic');
    this.callbacks.onStateChange({ ...this.saveData });
  }

  public interact() {
    this.sound.init();
    // 1. Check nearby NPCs
    const npc = this.findNearestNpc(5.5);
    if (npc) {
      this.advanceQuestObjective('talk_npc', npc.def.id, 1);
      this.callbacks.onOpenNpc(npc.def.id);
      return;
    }

    // 2. Check nearby Treasure Chests
    const chest = this.findNearestChest(4.6);
    if (chest) {
      this.openChest(chest);
      return;
    }

    // 3. Check nearby Underground Crypt Portals
    const portal = this.findNearestPortal(4.6);
    if (portal) {
      this.useCryptPortal(portal);
      return;
    }

    // 4. Check Moon Horse mount/dismount
    if (this.isMounted) {
      this.isMounted = false;
      this.mountMesh.visible = false;
      const horse = this.entities.creatures.find((c) => c.def.id === 'moon_horse' && c.tamed);
      if (horse) {
        horse.x = this.pos.x + 2;
        horse.z = this.pos.z + 2;
        horse.mesh.visible = true;
      }
      this.callbacks.onNotification('Dismounted Moon Horse.', 'info');
      return;
    }
    const horse = this.findNearestCreature('moon_horse', 6.0);
    if (horse) {
      horse.tamed = true;
      this.saveData.tamedMount = true;
      this.isMounted = true;
      this.mountMesh.visible = true;
      this.advanceQuestObjective('tame_creature', 'any', 1);
      this.callbacks.onNotification('Mounted Moon Horse! High-speed travel active.', 'epic');
      this.callbacks.onStateChange({ ...this.saveData });
      return;
    }

    // 5. Check Small Dragon taming
    const dragon = this.findNearestCreature('small_dragon', 6.5);
    if (dragon && !dragon.tamed) {
      if (this.consumeItem('magic_dust', 1) || this.consumeItem('cooked_meat', 1)) {
        dragon.tamed = true;
        this.saveData.tamedCompanion = true;
        this.advanceQuestObjective('tame_creature', 'any', 1);
        this.sound.playCreatureCall('dragon');
        this.callbacks.onNotification('Tamed Small Dragon companion! It will fly with you and fight!', 'epic');
        this.callbacks.onStateChange({ ...this.saveData });
      } else {
        this.callbacks.onNotification('Need 1 Magic Dust or Cooked Feast to tame Small Dragon.', 'warn');
      }
      return;
    }

    // 6. Gather resource node
    const node = this.findNearestResource(5.2);
    if (node) {
      node.cooldown = 32;
      node.mesh.visible = false;
      const qty = 2 + Math.floor(Math.random() * 2);
      this.addItem(node.itemId, qty);
      this.sound.playHit(false);
      this.callbacks.onNotification(`Gathered +${qty} ${ITEM_MAP[node.itemId]?.name || node.label}`, 'info');
      this.callbacks.onStateChange({ ...this.saveData });
      return;
    }

    // 7. Rest at nearby campfire
    const nearCamp = this.saveData.structures.find(
      (s) => s.type === 'campfire' && Math.hypot(s.x - this.pos.x, s.z - this.pos.z) < 5.5
    );
    if (nearCamp || Math.hypot(this.pos.x, this.pos.z - 4) < 5.5) {
      this.saveData.stats.hp = this.saveData.stats.maxHp;
      this.saveData.stats.mana = this.saveData.stats.maxMana;
      this.saveData.stats.stamina = this.saveData.stats.maxStamina;
      this.callbacks.onNotification('Rested by the warm campfire. Health & Mana restored!', 'info');
      this.callbacks.onStateChange({ ...this.saveData });
    }
  }

  public startBuilding(type: StructureType | null) {
    if (this.buildPreviewMesh) {
      this.scene.remove(this.buildPreviewMesh);
      this.buildPreviewMesh = null;
    }
    this.buildModeType = type;
    if (type) {
      // Lightweight translucent ghost indicator
      const g = new THREE.Group();
      const box = new THREE.Mesh(
        new THREE.BoxGeometry(type === 'wall' ? 5 : 4.5, 2.5, type === 'wall' ? 1 : 4.5),
        new THREE.MeshBasicMaterial({ color: '#38bdf8', wireframe: true })
      );
      box.position.y = 1.25;
      g.add(box);
      this.buildPreviewMesh = g;
      this.scene.add(g);
    }
  }

  public rotateBuildPreview() {
    this.buildRotation += Math.PI / 4;
  }

  public confirmPlacement(): PlacedStructure | null {
    if (!this.buildModeType) return null;
    const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const rawX = this.pos.x + forward.x * 7;
    const rawZ = this.pos.z + forward.z * 7;
    // Grid snapping (2m grid)
    const sx = Math.round(rawX / 2) * 2;
    const sz = Math.round(rawZ / 2) * 2;
    const sy = getTerrainHeight(sx, sz);

    const structure: PlacedStructure = {
      id: `st_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      type: this.buildModeType,
      x: sx,
      y: sy,
      z: sz,
      ry: this.buildRotation,
    };
    this.saveData.structures.push(structure);
    this.world.addPlacedStructure(structure);
    this.mp.sendStructure(structure);
    this.advanceQuestObjective('build_structure', 'any', 1);
    this.startBuilding(null);
    this.callbacks.onStateChange({ ...this.saveData });
    return structure;
  }

  public teleportToRegion(regionId: RegionId) {
    const reg = REGIONS[regionId];
    if (!reg) return;
    this.activeCrypt = null;
    const tx = reg.centerX;
    const tz = reg.centerZ + (regionId === 'green_forest' ? 16 : 0);
    const ty = getTerrainHeight(tx, tz);
    this.pos.set(tx, ty + 0.5, tz);
    this.velY = 0;
  }

  public applySettingsUpdate() {
    const s = this.saveData.settings;
    this.sound.setSettings(s.audioEnabled, s.musicVolume, s.sfxVolume);
    this.renderer.shadowMap.enabled = !this.isSoftwareGl && s.graphics !== 'Low';
    this.renderer.setPixelRatio(this.getRenderPixelRatio(s.graphics));
    if (!this.isSoftwareGl && s.graphics !== 'Low' && !this.composer) {
      const w = this.container.clientWidth || window.innerWidth;
      const h = this.container.clientHeight || window.innerHeight;
      this.composer = new EffectComposer(this.renderer);
      this.composer.addPass(new RenderPass(this.scene, this.camera));
      this.composer.addPass(new UnrealBloomPass(new THREE.Vector2(w, h), 0.34, 0.45, 0.85));
      this.composer.addPass(new OutputPass());
      this.composer.setPixelRatio(this.isMobileDevice ? 0.72 : 1);
    }
  }

  private findNearestChest(radius: number): ChestInstance | null {
    let best: ChestInstance | null = null;
    let bestD = radius;
    for (const c of this.world.chests) {
      if (c.opened) continue;
      const d = Math.hypot(c.x - this.pos.x, c.z - this.pos.z);
      if (d < bestD && Math.abs(c.y - this.pos.y) < 4) {
        bestD = d;
        best = c;
      }
    }
    return best;
  }

  private findNearestPortal(radius: number): CryptPortal | null {
    let best: CryptPortal | null = null;
    let bestD = radius;
    for (const p of this.world.portals) {
      const d = Math.hypot(p.x - this.pos.x, p.z - this.pos.z);
      if (d < bestD && Math.abs(p.y - this.pos.y) < 4.5) {
        bestD = d;
        best = p;
      }
    }
    return best;
  }

  private findNearestNpc(radius: number): ActiveNpc | null {
    let best: ActiveNpc | null = null;
    let bestD = radius;
    for (const n of this.entities.npcs) {
      const d = Math.hypot(n.x - this.pos.x, n.z - this.pos.z);
      if (d < bestD) {
        bestD = d;
        best = n;
      }
    }
    return best;
  }

  private findNearestCreature(id: string, radius: number): ActiveCreature | null {
    let best: ActiveCreature | null = null;
    let bestD = radius;
    for (const c of this.entities.creatures) {
      if (c.def.id !== id) continue;
      const d = Math.hypot(c.x - this.pos.x, c.z - this.pos.z);
      if (d < bestD) {
        bestD = d;
        best = c;
      }
    }
    return best;
  }

  private findNearestResource(radius: number): ResourceNode | null {
    let best: ResourceNode | null = null;
    let bestD = radius;
    for (const r of this.world.resourceNodes) {
      if (r.cooldown > 0) continue;
      const d = Math.hypot(r.x - this.pos.x, r.z - this.pos.z);
      if (d < bestD) {
        bestD = d;
        best = r;
      }
    }
    return best;
  }

  private syncRemotePlayers(players: RemotePlayer[]) {
    const ids = new Set(players.map((p) => p.id));
    for (const [id, entry] of this.remoteRigs.entries()) {
      if (!ids.has(id)) {
        this.scene.remove(entry.rig.group);
        this.remoteRigs.delete(id);
      }
    }
    for (const p of players) {
      let entry = this.remoteRigs.get(p.id);
      if (!entry) {
        const rig = buildHumanoidRig(
          {
            name: p.name,
            hairStyle: 'short',
            hairColor: p.hairColor || '#451a03',
            skinColor: p.skinColor || '#f1c27d',
            faceStyle: 'determined',
            tunicColor: p.armorColor || '#2563eb',
            armorColor: p.armorColor || '#64748b',
            accessory: 'cape',
          },
          (p.weaponType as WeaponCategory) || 'Sword',
          '#cbd5e1',
          false
        );
        this.scene.add(rig.group);
        entry = { rig, targetPos: new THREE.Vector3(p.x, p.y, p.z), targetYaw: p.yaw, anim: p.anim };
        this.remoteRigs.set(p.id, entry);
      } else {
        entry.targetPos.set(p.x, p.y, p.z);
        entry.targetYaw = p.yaw;
        entry.anim = p.anim;
      }
    }
  }

  private tick = () => {
    if (this.disposed) return;

    const dt = Math.min(this.clock.getDelta(), 0.05);
    const elapsed = this.clock.getElapsedTime();

    this.updatePlayer(dt, elapsed);
    this.updateProjectiles(dt);
    this.updateEntities(dt, elapsed);
    this.updateLootDrops(dt, elapsed);
    this.updateRemotePlayers(dt, elapsed);

    this.saveData.timeOfDay = (this.saveData.timeOfDay + dt * 0.09) % 24;
    this.weatherTimer -= dt;
    if (this.weatherTimer <= 0) {
      const reg = getRegionAt(this.pos.x, this.pos.z);
      const options: WeatherType[] =
        reg.weatherBias === 'snow'
          ? ['snow', 'clear', 'wind']
          : reg.weatherBias === 'fog'
            ? ['fog', 'rain', 'clear']
            : reg.weatherBias === 'storm'
              ? ['storm', 'rain', 'clear']
              : ['clear', 'clear', 'rain', 'wind'];
      this.weather = options[Math.floor(Math.random() * options.length)];
      this.weatherTimer = 35 + Math.random() * 40;
    }

    this.world.updateEnvironment(dt, this.saveData.timeOfDay, this.weather, this.pos);
    this.world.updateTrapsAndPortals(dt, elapsed, this.pos, (dmg, source, flags) => this.applyDamageToPlayer(dmg, source, flags));
    this.vfx.update(dt);
    this.vfx.setFrozenShield(this.frozenShieldTimer > 0, this.pos, elapsed);

    // Update build preview
    if (this.buildPreviewMesh && this.buildModeType) {
      const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
      const sx = Math.round((this.pos.x + forward.x * 7) / 2) * 2;
      const sz = Math.round((this.pos.z + forward.z * 7) / 2) * 2;
      this.buildPreviewMesh.position.set(sx, getTerrainHeight(sx, sz), sz);
      this.buildPreviewMesh.rotation.y = this.buildRotation;
    }

    this.updateCamera(dt);
    if (this.composer && !this.isSoftwareGl && this.saveData.settings.graphics !== 'Low') {
      this.composer.render();
    } else {
      this.renderer.render(this.scene, this.camera);
    }

    // Broadcast online player state
    this.mp.sendPlayerState({
      x: this.pos.x,
      y: this.pos.y,
      z: this.pos.z,
      yaw: this.yaw,
      anim: this.isAttacking ? 'attack' : 'move',
      level: this.saveData.stats.level,
      hp: this.saveData.stats.hp,
      maxHp: this.saveData.stats.maxHp,
      weaponType: (this.saveData.equipped.weapon ? ITEM_MAP[this.saveData.equipped.weapon]?.weaponCategory : 'Sword') || 'Sword',
      mounted: this.isMounted,
    });

    // Periodic HUD snapshot (~15 Hz)
    this.hudTimer += dt;
    if (this.hudTimer >= 0.065) {
      this.hudTimer = 0;
      this.emitHudSnapshot();
    }

    // Auto-save every 15s
    this.autosaveTimer += dt;
    if (this.autosaveTimer >= 15) {
      this.autosaveTimer = 0;
      this.saveData.position = { x: this.pos.x, y: this.pos.y, z: this.pos.z, yaw: this.yaw };
      this.callbacks.onStateChange({ ...this.saveData });
    }

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private updatePlayer(dt: number, elapsed: number) {
    const stats = this.saveData.stats;
    if (this.attackCooldown > 0) this.attackCooldown -= dt;
    if (this.attackTimer > 0) {
      this.attackTimer -= dt;
      if (this.attackTimer <= 0) this.isAttacking = false;
    }
    if ((this.keys.KeyF || this.attackHeld) && this.attackCooldown <= 0) {
      this.performAttack();
    }
    if (this.dodgeCooldown > 0) this.dodgeCooldown -= dt;
    if (this.dodgeTimer > 0) this.dodgeTimer -= dt;
    if (this.frozenShieldTimer > 0) this.frozenShieldTimer -= dt;
    if (this.slowTimer > 0) this.slowTimer -= dt;
    if (this.jumpBufferTimer > 0) this.jumpBufferTimer = Math.max(0, this.jumpBufferTimer - dt);
    if (this.lastHitTarget) {
      this.lastHitTarget.timer -= dt;
      if (this.lastHitTarget.timer <= 0) this.lastHitTarget = null;
    }
    if (this.poisonTimer > 0) {
      this.poisonTimer -= dt;
      stats.hp = Math.max(1, stats.hp - 4 * dt);
    }

    for (const k of Object.keys(this.spellCooldowns)) {
      if (this.spellCooldowns[k] > 0) this.spellCooldowns[k] = Math.max(0, this.spellCooldowns[k] - dt);
    }

    // Regen mana & stamina (& optional survival hunger)
    const manaBonus = (this.saveData.skillRanks.arcane_reservoir || 0) * 1.2;
    stats.mana = Math.min(stats.maxMana, stats.mana + (4.5 + manaBonus) * dt);
    stats.stamina = Math.min(stats.maxStamina, stats.stamina + (this.sprinting ? -9 : 14) * dt);
    if (stats.stamina <= 0) this.sprinting = false;

    if (this.saveData.settings.survivalMode) {
      stats.hunger = Math.max(0, stats.hunger - 0.14 * dt);
      if (stats.hunger > 45 && stats.hp < stats.maxHp) {
        stats.hp = Math.min(stats.maxHp, stats.hp + 1.4 * dt);
      } else if (stats.hunger <= 0) {
        stats.hp = Math.max(5, stats.hp - 1.2 * dt);
      }
    } else if (stats.hp < stats.maxHp) {
      stats.hp = Math.min(stats.maxHp, stats.hp + 2.2 * dt);
    }

    // Keyboard + Mobile Joystick combined movement (strictly independent from camera rotation!)
    let inputForward = -this.joyVec.y; // joyY < 0 is UP/FORWARD
    let inputRight = this.joyVec.x; // joyX > 0 is RIGHT
    if (this.keys.KeyW || this.keys.ArrowUp) inputForward += 1;
    if (this.keys.KeyS || this.keys.ArrowDown) inputForward -= 1;
    if (this.keys.KeyD || this.keys.ArrowRight) inputRight += 1;
    if (this.keys.KeyA || this.keys.ArrowLeft) inputRight -= 1;

    const len = Math.hypot(inputForward, inputRight);
    if (len > 1) {
      inputForward /= len;
      inputRight /= len;
    }

    const sprintKey = this.keys.ShiftLeft || this.keys.ShiftRight || this.sprinting;
    const { spd } = this.getComputedStats();
    let moveSpeed = this.isMounted ? 18.5 : sprintKey && stats.stamina > 5 ? spd * 1.45 : spd;
    if (this.dodgeTimer > 0) moveSpeed *= 1.9;
    if (this.slowTimer > 0) moveSpeed *= 0.55;
    if (this.isSwimming) moveSpeed *= 0.7;

    // Camera forward/right basis on XZ plane
    const fwdX = -Math.sin(this.yaw);
    const fwdZ = -Math.cos(this.yaw);
    const rightX = Math.cos(this.yaw);
    const rightZ = -Math.sin(this.yaw);

    const moveX = fwdX * inputForward + rightX * inputRight;
    const moveZ = fwdZ * inputForward + rightZ * inputRight;

    if (this.portalCooldown > 0) this.portalCooldown = Math.max(0, this.portalCooldown - dt);

    const rawNextX = this.pos.x + moveX * moveSpeed * dt;
    const rawNextZ = this.pos.z + moveZ * moveSpeed * dt;
    const nextX = this.activeCrypt ? rawNextX : THREE.MathUtils.clamp(rawNextX, -WORLD_RADIUS + 18, WORLD_RADIUS - 18);
    const nextZ = this.activeCrypt ? rawNextZ : THREE.MathUtils.clamp(rawNextZ, -WORLD_RADIUS + 18, WORLD_RADIUS - 18);

    const hitsAnyObstacle = (cx: number, cz: number): boolean => {
      for (const c of this.world.colliders) {
        if (Math.hypot(cx - c.x, cz - c.z) < c.radius && this.pos.y < c.maxY) {
          return true;
        }
      }
      for (const wb of this.world.wallBoxes) {
        if (cx >= wb.minX && cx <= wb.maxX && cz >= wb.minZ && cz <= wb.maxZ && this.pos.y >= wb.minY && this.pos.y < wb.maxY) {
          return true;
        }
      }
      const finalBoss = this.entities.bosses.find((b) => b.def.id === 'boss_lord_of_darkness');
      if (finalBoss && finalBoss.locked) {
        const distBoss = Math.hypot(cx - finalBoss.def.arenaX, cz - finalBoss.def.arenaZ);
        if (distBoss < finalBoss.def.arenaRadius && Math.hypot(this.pos.x - finalBoss.def.arenaX, this.pos.z - finalBoss.def.arenaZ) >= finalBoss.def.arenaRadius) {
          this.callbacks.onNotification('Dark Barrier Locked! Defeat all 7 Regional Bosses first.', 'warn');
          return true;
        }
      }
      return false;
    };

    // Smooth axis-separated wall sliding so the player slides cleanly along castle/crypt walls & doorways
    if (!hitsAnyObstacle(nextX, this.pos.z)) {
      this.pos.x = nextX;
    }
    if (!hitsAnyObstacle(this.pos.x, nextZ)) {
      this.pos.z = nextZ;
    }

    // Walk-through automatic Crypt Portal trigger
    if (this.portalCooldown <= 0) {
      const walkPortal = this.findNearestPortal(2.0);
      if (walkPortal) {
        this.useCryptPortal(walkPortal);
      }
    }

    // Terrain / Crypt floor, Swimming & Climbing physics
    const groundY = this.activeCrypt ? this.activeCrypt.floorY : getTerrainHeight(this.pos.x, this.pos.z);
    this.isSwimming = !this.activeCrypt && groundY < WATER_LEVEL - 0.35 && this.pos.y <= WATER_LEVEL + 0.35;
    this.isClimbing =
      !this.activeCrypt && !this.isSwimming && !this.isMounted && isClimbableSlope(this.pos.x, this.pos.z) && len > 0.1 && this.velY <= 0;

    if (this.grounded || this.isClimbing) {
      this.coyoteTimer = 0.14;
    } else if (this.coyoteTimer > 0) {
      this.coyoteTimer = Math.max(0, this.coyoteTimer - dt);
    }

    if (this.keys.Space) {
      this.jumpBufferTimer = Math.max(this.jumpBufferTimer, 0.08);
    }

    if (this.isSwimming) {
      if (this.jumpBufferTimer > 0) {
        this.velY = 6.5;
        this.pos.y += this.velY * dt;
        this.jumpBufferTimer = 0;
      } else {
        this.velY = 0;
        this.pos.y = THREE.MathUtils.damp(this.pos.y, WATER_LEVEL - 0.3, 8, dt);
      }
      this.grounded = false;
    } else if (this.jumpBufferTimer > 0 && (this.grounded || this.isClimbing || this.coyoteTimer > 0)) {
      this.velY = 11.2;
      this.grounded = false;
      this.isClimbing = false;
      this.coyoteTimer = 0;
      this.jumpBufferTimer = 0;
      this.pos.y += this.velY * dt;
      this.sound.playJump();
    } else if (this.isClimbing) {
      this.velY = 0;
      this.pos.y = groundY;
      this.grounded = true;
    } else {
      this.velY -= 25 * dt;
      this.pos.y += this.velY * dt;
      if (this.pos.y <= groundY) {
        this.pos.y = groundY;
        this.velY = 0;
        this.grounded = true;
      } else {
        this.grounded = false;
      }
    }

    // Lava hazard check
    if (!this.activeCrypt && isLavaAt(this.pos.x, this.pos.z) && this.pos.y < 10.8) {
      stats.hp = Math.max(1, stats.hp - 22 * dt);
    }

    if (len > 0.08) {
      const targetCharYaw = Math.atan2(moveX, moveZ);
      let diff = targetCharYaw - this.playerRig.group.rotation.y;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      this.playerRig.group.rotation.y += diff * Math.min(1, dt * 12);

      this.footstepTimer -= dt;
      if (this.footstepTimer <= 0 && (this.grounded || this.isSwimming)) {
        this.footstepTimer = this.sprinting ? 0.28 : 0.42;
        this.sound.playFootstep(this.isSwimming);
      }
    }

    this.playerRig.group.position.copy(this.pos);
    animateHumanoid(
      this.playerRig,
      elapsed,
      Math.min(1, len),
      this.isAttacking,
      1 - this.attackTimer / 0.28,
      this.isSwimming,
      this.isMounted
    );

    if (this.isMounted) {
      this.mountMesh.position.copy(this.pos);
      this.mountMesh.rotation.y = this.playerRig.group.rotation.y;
    }

    if (!this.activeCrypt) {
      const region = getRegionAt(this.pos.x, this.pos.z);
      if (!this.saveData.discoveredRegions.includes(region.id)) {
        this.saveData.discoveredRegions.push(region.id);
        this.advanceQuestObjective('visit_region', region.id, 1);
        this.callbacks.onNotification(`Discovered ${region.name}!`, 'epic');
      }

      const nearBoss = this.entities.bosses.find(
        (b) => !b.defeated && !b.locked && Math.hypot(b.x - this.pos.x, b.z - this.pos.z) < b.def.arenaRadius + 10
      );
      if (nearBoss) {
        this.sound.setTheme('boss');
      } else if (region.id === 'green_forest' && Math.hypot(this.pos.x, this.pos.z) < 65) {
        this.sound.setTheme('village');
      } else {
        this.sound.setTheme('explore');
      }
    }
  }

  private updateProjectiles(dt: number) {
    for (let i = this.vfx.projectiles.length - 1; i >= 0; i--) {
      const p = this.vfx.projectiles[i];
      if (p.fromPlayer) {
        let hit = false;
        for (const en of this.entities.enemies) {
          if (en.dead) continue;
          if (Math.hypot(p.mesh.position.x - en.x, p.mesh.position.z - en.z) <= p.radius + 0.6 && Math.abs(p.mesh.position.y - (en.y + 1.1)) < 2.2) {
            this.damageEnemy(en, p.damage, p.element);
            if (p.element === 'ice') en.slowTimer = 3.5;
            hit = true;
            break;
          }
        }
        if (!hit) {
          for (const b of this.entities.bosses) {
            if (b.defeated || b.locked) continue;
            if (Math.hypot(p.mesh.position.x - b.x, p.mesh.position.z - b.z) <= p.radius + 2.5) {
              this.damageBoss(b, p.damage, p.element);
              hit = true;
              break;
            }
          }
        }
        if (!hit) {
          for (const cr of this.entities.creatures) {
            if (cr.dead || cr.tamed) continue;
            if (Math.hypot(p.mesh.position.x - cr.x, p.mesh.position.z - cr.z) <= p.radius + 0.8 && Math.abs(p.mesh.position.y - (cr.y + 1.0)) < 2.2) {
              this.damageCreature(cr, p.damage);
              hit = true;
              break;
            }
          }
        }
        if (hit) {
          this.vfx.spawnRingBurst(p.mesh.position, p.element === 'fire' ? '#f97316' : '#38bdf8', p.radius * 1.4, 0.35);
          this.vfx.removeProjectileAt(i);
        }
      } else {
        // Enemy projectile hitting player
        if (
          Math.hypot(p.mesh.position.x - this.pos.x, p.mesh.position.z - this.pos.z) < 1.3 &&
          Math.abs(p.mesh.position.y - (this.pos.y + 1.1)) < 1.6
        ) {
          this.applyDamageToPlayer(p.damage, 'Enemy Spell');
          this.vfx.removeProjectileAt(i);
        }
      }
    }
    void dt;
  }

  private applyDamageToPlayer(rawDmg: number, source: string, flags?: { slow?: boolean; poison?: boolean }) {
    if (this.dodgeTimer > 0) return; // Invulnerable during dodge roll
    const { def } = this.getComputedStats();
    let dmg = Math.max(2, Math.round(rawDmg - def * 0.45));
    if (this.frozenShieldTimer > 0) dmg = Math.round(dmg * 0.5);
    this.saveData.stats.hp -= dmg;
    if (flags?.slow) this.slowTimer = 3.0;
    if (flags?.poison) this.poisonTimer = 4.0;
    this.sound.playHit(false);

    if (this.saveData.stats.hp <= 0) {
      this.saveData.stats.hp = this.saveData.stats.maxHp;
      this.saveData.stats.mana = this.saveData.stats.maxMana;
      this.activeCrypt = null;
      this.pos.set(0, getTerrainHeight(0, 16) + 0.5, 16);
      this.callbacks.onNotification(`Defeated by ${source}! Revived safely in Oakhearth Village.`, 'warn');
    }
  }

  private updateEntities(dt: number, elapsed: number) {
    this.entities.updateAll(dt, elapsed, this.pos, this.camera.quaternion, this.isMounted, {
      onPlayerHit: (dmg, source, flags) => this.applyDamageToPlayer(dmg, source, flags),
      onEnemyProjectile: (origin, dir, dmg, element) => {
        this.vfx.spawnProjectile({
          origin,
          dir,
          speed: 22,
          damage: dmg,
          element,
          radius: 1.5,
          fromPlayer: false,
        });
      },
      onCompanionAttack: (target, dmg) => {
        if ('def' in target && 'dead' in target) {
          this.vfx.spawnChainBeam(
            this.pos.clone().add(new THREE.Vector3(-1.8, 2.2, -1.8)),
            new THREE.Vector3(target.x, target.y + 1.2, target.z)
          );
          this.damageEnemy(target, dmg, 'fire');
        }
      },
      onBossSpecial: (boss, type) => {
        if (type === 'summon') {
          for (const eid of boss.def.summonEnemyIds) {
            this.entities.spawnSummonedEnemy(eid, boss.x + (Math.random() - 0.5) * 10, boss.z + (Math.random() - 0.5) * 10);
          }
          this.sound.playCreatureCall('boss');
          this.callbacks.onNotification(`${boss.def.name} enters Phase ${boss.phase} and summons reinforcements!`, 'warn');
        } else {
          this.vfx.spawnRingBurst(new THREE.Vector3(boss.x, boss.y + 0.5, boss.z), boss.def.accentColor, 14, 0.7);
        }
      },
      onOtterGift: (itemId) => {
        this.addItem(itemId, 1);
        this.callbacks.onNotification('A friendly River Otter found Healing Herbs for you!', 'info');
      },
    });
  }

  private updateRemotePlayers(dt: number, elapsed: number) {
    for (const entry of this.remoteRigs.values()) {
      entry.rig.group.position.lerp(entry.targetPos, Math.min(1, dt * 12));
      entry.rig.group.rotation.y = entry.targetYaw;
      animateHumanoid(entry.rig, elapsed, 0.8, entry.anim === 'attack', 0.5, false, false);
    }
  }

  private updateCamera(dt: number) {
    if (this.cameraMode === 'first') {
      const eyeY = this.pos.y + (this.isMounted ? 2.35 : 1.72);
      _v1.set(this.pos.x, eyeY, this.pos.z);
      this.camera.position.lerp(_v1, Math.min(1, dt * 24));
      _camTarget.set(
        this.camera.position.x - Math.sin(this.yaw) * Math.cos(this.pitch) * 10,
        this.camera.position.y - Math.sin(this.pitch) * 10,
        this.camera.position.z - Math.cos(this.yaw) * Math.cos(this.pitch) * 10
      );
      this.camera.lookAt(_camTarget);
    } else {
      const dist = this.isMounted ? 8.5 : this.activeCrypt ? 5.2 : 6.6;
      const targetY = this.pos.y + (this.isMounted ? 2.2 : 1.55);
      _camTarget.set(this.pos.x, targetY, this.pos.z);

      const offsetX = Math.sin(this.yaw) * Math.cos(this.pitch) * dist;
      const offsetY = Math.sin(this.pitch) * dist + 1.2;
      const offsetZ = Math.cos(this.yaw) * Math.cos(this.pitch) * dist;

      _v1.set(this.pos.x + offsetX, targetY + offsetY, this.pos.z + offsetZ);
      const minCamY = (this.activeCrypt ? this.activeCrypt.floorY : getTerrainHeight(_v1.x, _v1.z)) + 0.8;
      if (_v1.y < minCamY) _v1.y = minCamY;
      if (this.activeCrypt && _v1.y > this.activeCrypt.floorY + 6.8) {
        _v1.y = this.activeCrypt.floorY + 6.8;
      }

      this.camera.position.lerp(_v1, Math.min(1, dt * 16));
      this.camera.lookAt(_camTarget);
    }
  }

  private emitHudSnapshot() {
    const region = this.activeCrypt ? REGIONS[this.activeCrypt.region] : getRegionAt(this.pos.x, this.pos.z);
    let nearbyPrompt: string | null = null;
    let nearbyTargetKind: HudSnapshot['nearbyTargetKind'] = null;

    const npc = this.findNearestNpc(5.5);
    const chest = this.findNearestChest(4.6);
    const portal = this.findNearestPortal(4.6);
    if (npc) {
      nearbyPrompt = `Talk to ${npc.def.name}`;
      nearbyTargetKind = 'npc';
    } else if (chest) {
      nearbyPrompt = `Open ${chest.label}`;
      nearbyTargetKind = 'resource';
    } else if (portal) {
      nearbyPrompt = portal.label;
      nearbyTargetKind = 'resource';
    } else if (this.isMounted) {
      nearbyPrompt = 'Dismount Moon Horse';
      nearbyTargetKind = 'horse';
    } else if (this.findNearestCreature('moon_horse', 6.0)) {
      nearbyPrompt = 'Ride Moon Horse';
      nearbyTargetKind = 'horse';
    } else {
      const dr = this.findNearestCreature('small_dragon', 6.5);
      if (dr && !dr.tamed) {
        nearbyPrompt = 'Tame Small Dragon';
        nearbyTargetKind = 'dragon';
      } else {
        const res = this.findNearestResource(5.2);
        if (res) {
          nearbyPrompt = `Gather ${res.label}`;
          nearbyTargetKind = 'resource';
        }
      }
    }

    const nearBoss = this.entities.bosses.find(
      (b) => !b.defeated && Math.hypot(b.x - this.pos.x, b.z - this.pos.z) < b.def.arenaRadius + 14
    );

    let targetEntity: HudSnapshot['targetEntity'] = null;
    if (this.lastHitTarget) {
      if (this.lastHitTarget.kind === 'enemy') {
        const en = this.entities.enemies.find((e) => e.uid === this.lastHitTarget?.uid && !e.dead);
        if (en) {
          targetEntity = { name: en.def.name, kind: 'enemy', hp: en.hp, maxHp: en.maxHp, level: Math.max(1, Math.ceil(en.def.index * 0.6)) };
        }
      } else {
        const cr = this.entities.creatures.find((c) => c.uid === this.lastHitTarget?.uid && !c.dead);
        if (cr) {
          targetEntity = { name: cr.def.name, kind: 'creature', hp: cr.hp, maxHp: cr.maxHp };
        }
      }
    }
    if (!targetEntity) {
      let bestDist = 16;
      for (const en of this.entities.enemies) {
        if (en.dead) continue;
        const d = Math.hypot(en.x - this.pos.x, en.z - this.pos.z);
        if (d < bestDist) {
          bestDist = d;
          targetEntity = { name: en.def.name, kind: 'enemy', hp: en.hp, maxHp: en.maxHp, level: Math.max(1, Math.ceil(en.def.index * 0.6)) };
        }
      }
      if (!targetEntity) {
        let crDist = 10;
        for (const cr of this.entities.creatures) {
          if (cr.dead) continue;
          const d = Math.hypot(cr.x - this.pos.x, cr.z - this.pos.z);
          if (d < crDist) {
            crDist = d;
            targetEntity = { name: cr.def.name, kind: 'creature', hp: cr.hp, maxHp: cr.maxHp };
          }
        }
      }
    }

    this.callbacks.onHudUpdate({
      stats: { ...this.saveData.stats },
      regionId: region.id,
      regionName: this.activeCrypt ? `${this.activeCrypt.name} (Crypt)` : region.name,
      timeOfDay: this.saveData.timeOfDay,
      weather: this.weather,
      cameraMode: this.cameraMode,
      isSwimming: this.isSwimming,
      isClimbing: this.isClimbing,
      isMounted: this.isMounted,
      frozenShieldActive: this.frozenShieldTimer > 0,
      nearbyPrompt,
      nearbyTargetKind,
      activeBoss: nearBoss
        ? {
            id: nearBoss.def.id,
            name: nearBoss.def.name,
            title: nearBoss.def.title,
            hp: nearBoss.hp,
            maxHp: nearBoss.maxHp,
            phase: nearBoss.phase,
            locked: nearBoss.locked,
          }
        : null,
      targetEntity,
      spellCooldowns: { ...this.spellCooldowns },
      position: { x: this.pos.x, y: this.pos.y, z: this.pos.z, yaw: this.yaw },
      fpsEntities: {
        creatures: this.entities.creatures.filter((c) => !c.dead).map((c) => ({ x: c.x, z: c.z, name: c.def.name })),
        enemies: this.entities.enemies.filter((e) => !e.dead).map((e) => ({ x: e.x, z: e.z })),
        npcs: this.entities.npcs.map((n) => ({ x: n.x, z: n.z, name: n.def.name })),
        bosses: this.entities.bosses.map((b) => ({ x: b.def.arenaX, z: b.def.arenaZ, defeated: b.defeated })),
      },
    });
  }

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    this.mp.disconnect();
    this.sound.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
