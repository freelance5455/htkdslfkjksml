/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { soundManager } from '../audio/SoundManager';
import {
  createAsphaltTexture,
  createBuildingTexture,
  createConcreteBarrier,
  createExplosiveBarrel,
  createExtractionBeacon,
  createPickupMesh,
  createStreetlight,
  createSurvivorModel,
  createWreckedCar,
  createZombieModel,
  PlayerMeshComponents,
} from './proceduralModels';
import {
  ExplosiveBarrelEntity,
  ObjectiveStep,
  PickupEntity,
  WeaponStats,
  WeaponType,
  ZombieEntity,
} from '../types/game';

// Pre-allocated math objects to avoid GC stutter in 60fps render loop
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _ray = new THREE.Raycaster();

export interface GameEngineCallbacks {
  onHealthChange: (hp: number, maxHp: number, armor: number) => void;
  onAmmoChange: (mag: number, reserve: number, weaponName: string) => void;
  onWeaponChange: (weapon: WeaponStats) => void;
  onObjectiveUpdate: (step: ObjectiveStep, allSteps: ObjectiveStep[]) => void;
  onScoreUpdate: (score: number, kills: number, wave: number) => void;
  onPlayerHit: () => void;
  onVictory: () => void;
  onGameOver: () => void;
  onCompassUpdate: (targetAngle: number, distance: number) => void;
}

export class GameEngine {
  private container: HTMLElement;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private callbacks: GameEngineCallbacks;

  // Animation frame & Clock
  private animFrameId: number | null = null;
  private lastTime: number = 0;
  private isRunning: boolean = false;
  private isPaused: boolean = false;

  // Environment & Level
  private obstacles: THREE.Box3[] = [];
  private barrels: ExplosiveBarrelEntity[] = [];
  private pickups: PickupEntity[] = [];
  private extractionBeacon: THREE.Group | null = null;
  private extractionPos = new THREE.Vector3(0, 0, -85);

  // Player Character
  private playerMesh: PlayerMeshComponents;
  private playerPos = new THREE.Vector3(0, 0, 18);
  private playerVel = new THREE.Vector3(0, 0, 0);
  private playerRotation = 0; // Yaw
  private playerPitch = 0; // Pitch for aiming
  private isAiming = false;
  private isSprinting = false;
  private isRolling = false;
  private rollTimer = 0;
  private rollDir = new THREE.Vector3(0, 0, -1);

  // Player Stats
  private health = 100;
  private maxHealth = 100;
  private armor = 25;
  private stamina = 100;
  private score = 0;
  private kills = 0;
  private wave = 1;
  private isEndless = false;

  // Weapons
  private weapons: Record<WeaponType, WeaponStats> = {
    PISTOL: {
      id: 'PISTOL',
      name: 'Tactical 9mm',
      damage: 32,
      fireRate: 4.5,
      magSize: 15,
      currentMag: 15,
      reserveAmmo: 60,
      maxReserve: 120,
      reloadTime: 1.2,
      range: 45,
      spread: 0.035,
      pellets: 1,
      automatic: false,
    },
    RIFLE: {
      id: 'RIFLE',
      name: 'M4A1 Carbine',
      damage: 26,
      fireRate: 9.5,
      magSize: 30,
      currentMag: 30,
      reserveAmmo: 120,
      maxReserve: 240,
      reloadTime: 1.8,
      range: 75,
      spread: 0.045,
      pellets: 1,
      automatic: true,
    },
    SHOTGUN: {
      id: 'SHOTGUN',
      name: 'Breacher 12G',
      damage: 18,
      fireRate: 1.4,
      magSize: 8,
      currentMag: 8,
      reserveAmmo: 32,
      maxReserve: 64,
      reloadTime: 2.2,
      range: 28,
      spread: 0.12,
      pellets: 7,
      automatic: false,
    },
  };
  private currentWeaponType: WeaponType = 'PISTOL';
  private lastFireTime = 0;
  private isReloading = false;
  private reloadTimer = 0;
  private recoilPitch = 0;

  // Zombies
  private zombies: ZombieEntity[] = [];
  private maxZombies = 24;
  private zombieSpawnTimer = 0;

  // Objectives (Mission: Escape the City)
  private objectives: ObjectiveStep[] = [
    {
      id: 'step_weapon',
      title: 'EQUIP WEAPON CACHE',
      description: 'Locate and equip the tactical supply crate nearby.',
      current: 0,
      target: 1,
      completed: false,
      icon: 'box',
    },
    {
      id: 'step_kill_walkers',
      title: 'CLEAR INFECTED PATROL',
      description: 'Neutralize 5 infected walkers blocking the main road.',
      current: 0,
      target: 5,
      completed: false,
      icon: 'crosshair',
    },
    {
      id: 'step_sample',
      title: 'RETRIEVE RESEARCH VIAL',
      description: 'Acquire the quarantined biochemical sample from the outpost.',
      current: 0,
      target: 1,
      completed: false,
      icon: 'zap',
    },
    {
      id: 'step_extract',
      title: 'REACH EXTRACTION BEACON',
      description: 'Proceed to the helipad extraction zone at the far end of the avenue.',
      current: 0,
      target: 1,
      completed: false,
      icon: 'shield',
    },
  ];
  private currentObjectiveIndex = 0;

  // Input states
  private keys: Record<string, boolean> = {};
  private virtualMove = { x: 0, y: 0 };
  private virtualAim = { x: 0, y: 0 };
  private isPointerLocked = false;
  private touchLookSens = 0.0035;
  private mouseSens = 0.0022;

  // Particles
  private particles: {
    mesh: THREE.Points;
    positions: Float32Array;
    velocities: Float32Array;
    colors: Float32Array;
    count: number;
  } | null = null;

  // Screen shake
  private screenShake = 0;

  constructor(container: HTMLElement, callbacks: GameEngineCallbacks, endlessMode: boolean = false) {
    this.container = container;
    this.callbacks = callbacks;
    this.isEndless = endlessMode;

    // 1. Scene setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x06080d);
    this.scene.fog = new THREE.FogExp2(0x070a10, 0.024);

    // 2. Camera setup
    const aspect = container.clientWidth / (container.clientHeight || 1);
    this.camera = new THREE.PerspectiveCamera(65, aspect, 0.1, 200);

    // 3. Renderer setup
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // 4. Studio Environment Reflection
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    // 5. Lighting Rig
    this.setupLighting();

    // 6. Build City Level & props
    this.buildCityLevel();

    // 7. Spawn Player
    this.playerMesh = createSurvivorModel();
    this.playerMesh.root.position.copy(this.playerPos);
    this.scene.add(this.playerMesh.root);

    // 8. Particle System
    this.initParticles();

    // 9. Initial Entities
    this.spawnInitialPickups();
    this.spawnZombies(4, 'WALKER');

    // 10. Bind Input Listeners
    this.bindEvents();

    // Broadcast initial UI stats
    this.callbacks.onHealthChange(this.health, this.maxHealth, this.armor);
    const curWep = this.weapons[this.currentWeaponType];
    this.callbacks.onAmmoChange(curWep.currentMag, curWep.reserveAmmo, curWep.name);
    this.callbacks.onWeaponChange(curWep);
    this.callbacks.onObjectiveUpdate(this.objectives[this.currentObjectiveIndex], this.objectives);
    this.callbacks.onScoreUpdate(this.score, this.kills, this.wave);

    // Start 60fps game loop
    this.isRunning = true;
    this.lastTime = performance.now();
    this.renderLoop(this.lastTime);
  }

  private setupLighting() {
    // Cool atmospheric sky fill
    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x0f172a, 0.45);
    this.scene.add(hemiLight);

    // Warm Key Directional Light (Moon / distant searchlight)
    const dirLight = new THREE.DirectionalLight(0xffedd5, 1.3);
    dirLight.position.set(25, 45, 20);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 130;
    const d = 40;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.bias = -0.0004;
    dirLight.shadow.normalBias = 0.02;
    this.scene.add(dirLight);

    // Emergency red ambient flare
    const redFlare = new THREE.PointLight(0xef4444, 2.5, 30);
    redFlare.position.set(-6, 3, 5);
    this.scene.add(redFlare);
  }

  private buildCityLevel() {
    // 1. Asphalt Main Street
    const streetTex = createAsphaltTexture();
    streetTex.repeat.set(1, 16);
    const streetGeo = new THREE.PlaneGeometry(18, 190);
    const streetMat = new THREE.MeshStandardMaterial({
      map: streetTex,
      roughness: 0.85,
      metalness: 0.1,
    });
    const street = new THREE.Mesh(streetGeo, streetMat);
    street.rotation.x = -Math.PI / 2;
    street.position.set(0, 0, -10);
    street.receiveShadow = true;
    this.scene.add(street);

    // 2. Sidewalks & Curbs
    const curbMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.9 });
    const leftWalk = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.25, 190), curbMat);
    leftWalk.position.set(-11.25, 0.125, -10);
    leftWalk.receiveShadow = true;
    const rightWalk = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.25, 190), curbMat);
    rightWalk.position.set(11.25, 0.125, -10);
    rightWalk.receiveShadow = true;
    this.scene.add(leftWalk, rightWalk);

    // Level boundaries (Invisible collision boxes)
    this.obstacles.push(
      new THREE.Box3(new THREE.Vector3(-14, 0, -110), new THREE.Vector3(-13, 10, 90)),
      new THREE.Box3(new THREE.Vector3(13, 0, -110), new THREE.Vector3(14, 10, 90)),
      new THREE.Box3(new THREE.Vector3(-15, 0, 32), new THREE.Vector3(15, 10, 35)),
      new THREE.Box3(new THREE.Vector3(-15, 0, -105), new THREE.Vector3(15, 10, -102))
    );

    // 3. Flanking Ruined Skyscrapers
    const bldgTex = createBuildingTexture();
    bldgTex.repeat.set(2, 6);
    const bldgMat = new THREE.MeshStandardMaterial({
      map: bldgTex,
      roughness: 0.7,
      metalness: 0.2,
    });

    const bldgHeights = [32, 45, 28, 52, 38, 48, 30, 42];
    for (let i = 0; i < 8; i++) {
      const zPos = 25 - i * 22;
      const hLeft = bldgHeights[i];
      const hRight = bldgHeights[(i + 3) % 8];

      // Left skyscraper
      const bLeft = new THREE.Mesh(new THREE.BoxGeometry(16, hLeft, 19), bldgMat);
      bLeft.position.set(-21.5, hLeft / 2, zPos);
      bLeft.castShadow = true;
      bLeft.receiveShadow = true;
      this.scene.add(bLeft);

      // Right skyscraper
      const bRight = new THREE.Mesh(new THREE.BoxGeometry(16, hRight, 19), bldgMat);
      bRight.position.set(21.5, hRight / 2, zPos);
      bRight.castShadow = true;
      bRight.receiveShadow = true;
      this.scene.add(bRight);
    }

    // 4. Streetlights along avenue
    for (let z = 20; z >= -90; z -= 30) {
      const lightLeft = createStreetlight();
      lightLeft.position.set(-9, 0, z);
      this.scene.add(lightLeft);

      const lightRight = createStreetlight();
      lightRight.position.set(9, 0, z - 15);
      lightRight.rotation.y = Math.PI;
      this.scene.add(lightRight);
    }

    // 5. Abandoned Vehicles & Roadblocks
    const carPlacements = [
      { x: -3.5, z: 8, rot: 0.2, color: 0x991b1b },
      { x: 4.2, z: -8, rot: -0.6, color: 0x1e3a8a },
      { x: -2.0, z: -28, rot: 1.1, color: 0x374151 },
      { x: 3.8, z: -52, rot: -0.3, color: 0x065f46 },
      { x: -4.0, z: -70, rot: 0.8, color: 0x7c2d12 },
    ];

    carPlacements.forEach((cp) => {
      const car = createWreckedCar(cp.color);
      car.position.set(cp.x, 0, cp.z);
      car.rotation.y = cp.rot;
      this.scene.add(car);

      // Add collision box
      const box = new THREE.Box3();
      box.setFromObject(car);
      this.obstacles.push(box);
    });

    // 6. Concrete barriers
    const barrierPlacements = [
      { x: -5, z: 2, rot: 0.1 },
      { x: 5, z: -20, rot: -0.2 },
      { x: -4, z: -44, rot: 0.4 },
      { x: 4.5, z: -64, rot: -0.1 },
    ];

    barrierPlacements.forEach((bp) => {
      const bar = createConcreteBarrier();
      bar.position.set(bp.x, 0, bp.z);
      bar.rotation.y = bp.rot;
      this.scene.add(bar);

      const box = new THREE.Box3();
      box.setFromObject(bar);
      this.obstacles.push(box);
    });

    // 7. Explosive Barrels
    const barrelPlacements = [
      { x: 2.2, z: 7 },
      { x: -2.5, z: -9 },
      { x: 5.5, z: -29 },
      { x: -5.0, z: -51 },
      { x: 2.0, z: -72 },
    ];

    barrelPlacements.forEach((bp, idx) => {
      const mesh = createExplosiveBarrel();
      mesh.position.set(bp.x, 0, bp.z);
      this.scene.add(mesh);

      const entity: ExplosiveBarrelEntity = {
        id: `barrel_${idx}`,
        mesh,
        position: [bp.x, 0, bp.z],
        health: 25,
        exploded: false,
      };
      this.barrels.push(entity);
    });

    // 8. Extraction Zone Beacon (Far end of street)
    this.extractionBeacon = createExtractionBeacon();
    this.extractionBeacon.position.copy(this.extractionPos);
    this.scene.add(this.extractionBeacon);
  }

  private spawnInitialPickups() {
    // 1. Initial Weapon Cache pickup near player
    this.addPickup('WEAPON_RIFLE', 0, 0, 10);
    // 2. First Ammo crate
    this.addPickup('AMMO', 4.0, 0, 4);
    // 3. Medkit near mid-street
    this.addPickup('MEDKIT', -3.8, 0, -18);
    // 4. Research Sample near the abandoned outpost
    this.addPickup('SAMPLE', 4.5, 0, -42);
    // 5. Heavy Shotgun pickup
    this.addPickup('WEAPON_SHOTGUN', -4.2, 0, -56);
    // 6. Another ammo cache
    this.addPickup('AMMO', 3.5, 0, -68);
    // 7. Emergency Medkit
    this.addPickup('MEDKIT', -2.5, 0, -80);
  }

  private addPickup(type: PickupEntity['type'], x: number, y: number, z: number) {
    const mesh = createPickupMesh(type);
    mesh.position.set(x, y, z);
    this.scene.add(mesh);

    this.pickups.push({
      id: `pickup_${Math.random().toString(36).substring(2, 9)}`,
      type,
      mesh,
      position: [x, y, z],
      collected: false,
      pulseTime: Math.random() * Math.PI * 2,
    });
  }

  public spawnZombies(count: number, type: 'WALKER' | 'RUNNER' | 'BRUTE') {
    for (let i = 0; i < count; i++) {
      if (this.zombies.length >= this.maxZombies) break;

      const z = createZombieModel(type);
      // Spawn ahead of player
      const spawnDist = 18 + Math.random() * 25;
      const angle = (Math.random() - 0.5) * 1.4;
      const sx = Math.sin(this.playerRotation + angle) * spawnDist + this.playerPos.x;
      const sz = Math.cos(this.playerRotation + angle) * spawnDist + this.playerPos.z;

      // Clamp within street
      const clampedX = Math.max(-8, Math.min(8, sx));
      const clampedZ = Math.max(-100, Math.min(28, sz));

      z.root.position.set(clampedX, 0, clampedZ);
      this.scene.add(z.root);

      const baseHp = type === 'BRUTE' ? 220 : type === 'RUNNER' ? 45 : 65;
      const speed = type === 'RUNNER' ? 4.8 : type === 'BRUTE' ? 2.2 : 2.5;
      const damage = type === 'BRUTE' ? 35 : type === 'RUNNER' ? 14 : 18;

      const entity: ZombieEntity = {
        id: `zombie_${Math.random().toString(36).substring(2, 9)}`,
        type,
        mesh: z.root,
        health: baseHp,
        maxHealth: baseHp,
        speed,
        damage,
        attackRange: type === 'BRUTE' ? 2.8 : 1.7,
        attackCooldown: type === 'RUNNER' ? 0.9 : 1.4,
        lastAttackTime: 0,
        state: 'IDLE',
        hitTimer: 0,
        deathTimer: 0,
        rotationY: Math.random() * Math.PI * 2,
        animTime: Math.random() * 10,
        height: type === 'BRUTE' ? 2.5 : 1.8,
      };

      this.zombies.push(entity);
    }
  }

  // --- PARTICLE FX ENGINE ---
  private initParticles() {
    const count = 350;
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      positions[i * 3 + 1] = -999; // inactive
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const mat = new THREE.PointsMaterial({
      size: 0.18,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const mesh = new THREE.Points(geo, mat);
    this.scene.add(mesh);

    this.particles = { mesh, positions, velocities, colors, count };
  }

  public emitParticles(x: number, y: number, z: number, color: THREE.Color, count: number, speed: number) {
    if (!this.particles) return;
    const p = this.particles;

    let emitted = 0;
    for (let i = 0; i < p.count && emitted < count; i++) {
      if (p.positions[i * 3 + 1] < -500) {
        // Inactive slot found
        p.positions[i * 3] = x;
        p.positions[i * 3 + 1] = y;
        p.positions[i * 3 + 2] = z;

        p.velocities[i * 3] = (Math.random() - 0.5) * speed;
        p.velocities[i * 3 + 1] = (Math.random() * 0.8 + 0.2) * speed;
        p.velocities[i * 3 + 2] = (Math.random() - 0.5) * speed;

        p.colors[i * 3] = color.r;
        p.colors[i * 3 + 1] = color.g;
        p.colors[i * 3 + 2] = color.b;

        emitted++;
      }
    }
    p.mesh.geometry.attributes.position.needsUpdate = true;
    p.mesh.geometry.attributes.color.needsUpdate = true;
  }

  private updateParticles(dt: number) {
    if (!this.particles) return;
    const p = this.particles;
    let anyActive = false;

    for (let i = 0; i < p.count; i++) {
      if (p.positions[i * 3 + 1] > -500) {
        p.positions[i * 3] += p.velocities[i * 3] * dt;
        p.positions[i * 3 + 1] += p.velocities[i * 3 + 1] * dt;
        p.positions[i * 3 + 2] += p.velocities[i * 3 + 2] * dt;

        // Gravity
        p.velocities[i * 3 + 1] -= 9.8 * dt;

        // Ground kill
        if (p.positions[i * 3 + 1] <= 0.05) {
          p.positions[i * 3 + 1] = -999;
        } else {
          anyActive = true;
        }
      }
    }

    if (anyActive) {
      p.mesh.geometry.attributes.position.needsUpdate = true;
    }
  }

  // --- WEAPON & BALLISTICS SYSTEM ---
  public fireWeapon() {
    if (this.health <= 0 || this.isRolling) return;
    const wep = this.weapons[this.currentWeaponType];
    const now = performance.now() / 1000;

    if (now - this.lastFireTime < 1 / wep.fireRate) {
      return;
    }

    if (this.isReloading) {
      return;
    }

    if (wep.currentMag <= 0) {
      soundManager.playEmptyClick();
      this.reloadWeapon();
      return;
    }

    // Spend Ammo
    wep.currentMag--;
    this.lastFireTime = now;
    soundManager.playGunshot(this.currentWeaponType);
    this.callbacks.onAmmoChange(wep.currentMag, wep.reserveAmmo, wep.name);

    // Muzzle Flash
    (this.playerMesh.muzzleFlash.material as THREE.MeshBasicMaterial).opacity = 1.0;
    this.playerMesh.muzzleLight.intensity = 4.5;
    setTimeout(() => {
      if (this.playerMesh?.muzzleFlash?.material) {
        (this.playerMesh.muzzleFlash.material as THREE.MeshBasicMaterial).opacity = 0;
        this.playerMesh.muzzleLight.intensity = 0;
      }
    }, 45);

    // Camera recoil kick & screen shake
    this.recoilPitch = wep.id === 'SHOTGUN' ? 0.08 : wep.id === 'RIFLE' ? 0.035 : 0.04;
    this.screenShake = Math.max(this.screenShake, wep.id === 'SHOTGUN' ? 0.25 : 0.12);

    // Ballistic Rays
    for (let i = 0; i < wep.pellets; i++) {
      const spreadX = (Math.random() - 0.5) * wep.spread * (this.isAiming ? 0.5 : 1.0);
      const spreadY = (Math.random() - 0.5) * wep.spread * (this.isAiming ? 0.5 : 1.0);

      // Ray origin at player chest/gun
      _v1.set(this.playerPos.x, 1.4, this.playerPos.z);
      _dir.set(
        -Math.sin(this.playerRotation + spreadX),
        Math.sin(this.playerPitch + spreadY),
        -Math.cos(this.playerRotation + spreadX)
      ).normalize();

      _ray.set(_v1, _dir);
      _ray.far = wep.range;

      // Check hits against zombies
      let hitZombie: ZombieEntity | null = null;
      let minZombieDist = Infinity;

      for (const z of this.zombies) {
        if (z.state === 'DEAD') continue;
        const zPos = z.mesh.position;
        // Bounding cylinder check
        const distToCenter = _ray.ray.distanceToPoint(
          _v2.set(zPos.x, z.height * 0.5, zPos.z)
        );
        if (distToCenter < (z.type === 'BRUTE' ? 1.0 : 0.6)) {
          const d = _v1.distanceTo(zPos);
          if (d < minZombieDist && d <= wep.range) {
            minZombieDist = d;
            hitZombie = z;
          }
        }
      }

      // Check hits against barrels
      for (const b of this.barrels) {
        if (b.exploded) continue;
        const bPos = b.mesh.position;
        if (_ray.ray.distanceToPoint(_v2.set(bPos.x, 0.6, bPos.z)) < 0.55) {
          this.damageBarrel(b, wep.damage);
        }
      }

      if (hitZombie) {
        this.damageZombie(hitZombie, wep.damage);
        // Blood particle burst
        this.emitParticles(
          hitZombie.mesh.position.x,
          1.2,
          hitZombie.mesh.position.z,
          new THREE.Color(0x991b1b),
          8,
          3.5
        );
      } else {
        // Wall spark effect at ray end
        _v2.copy(_v1).addScaledVector(_dir, Math.min(wep.range, 35));
        this.emitParticles(_v2.x, _v2.y, _v2.z, new THREE.Color(0xfef08a), 3, 2.0);
      }
    }
  }

  public reloadWeapon() {
    const wep = this.weapons[this.currentWeaponType];
    if (this.isReloading || wep.currentMag >= wep.magSize || wep.reserveAmmo <= 0) {
      return;
    }
    this.isReloading = true;
    this.reloadTimer = wep.reloadTime;
    soundManager.playReload();
  }

  public switchWeapon(type?: WeaponType) {
    if (this.isReloading) return;
    const types: WeaponType[] = ['PISTOL', 'RIFLE', 'SHOTGUN'];
    if (type) {
      this.currentWeaponType = type;
    } else {
      const idx = types.indexOf(this.currentWeaponType);
      this.currentWeaponType = types[(idx + 1) % types.length];
    }
    const wep = this.weapons[this.currentWeaponType];
    soundManager.playPickup('WEAPON');
    this.callbacks.onWeaponChange(wep);
    this.callbacks.onAmmoChange(wep.currentMag, wep.reserveAmmo, wep.name);
  }

  public dodgeRoll() {
    if (this.isRolling || this.health <= 0 || this.stamina < 25) return;
    this.isRolling = true;
    this.rollTimer = 0.45;
    this.stamina -= 25;

    // Roll in current movement direction or forward
    if (this.playerVel.lengthSq() > 0.1) {
      this.rollDir.copy(this.playerVel).normalize();
    } else {
      this.rollDir.set(-Math.sin(this.playerRotation), 0, -Math.cos(this.playerRotation));
    }
  }

  public toggleAim(isAiming?: boolean) {
    this.isAiming = isAiming !== undefined ? isAiming : !this.isAiming;
  }

  private damageZombie(zombie: ZombieEntity, damage: number) {
    if (zombie.state === 'DEAD') return;
    zombie.health -= damage;
    zombie.hitTimer = 0.15;
    soundManager.playZombieHit();

    if (zombie.health <= 0) {
      zombie.state = 'DEAD';
      zombie.deathTimer = 1.5;
      soundManager.playZombieDeath();

      this.score += zombie.type === 'BRUTE' ? 350 : zombie.type === 'RUNNER' ? 150 : 100;
      this.kills++;
      this.callbacks.onScoreUpdate(this.score, this.kills, this.wave);

      // Check objective progress
      const obj = this.objectives[this.currentObjectiveIndex];
      if (obj && obj.id === 'step_kill_walkers') {
        obj.current++;
        this.callbacks.onObjectiveUpdate(obj, this.objectives);
        if (obj.current >= obj.target) {
          this.advanceObjective();
        }
      }
    }
  }

  private damageBarrel(barrel: ExplosiveBarrelEntity, damage: number) {
    if (barrel.exploded) return;
    barrel.health -= damage;
    if (barrel.health <= 0) {
      barrel.exploded = true;
      this.scene.remove(barrel.mesh);
      soundManager.playExplosion();
      this.screenShake = 0.45;

      const [bx, by, bz] = barrel.position;
      // Fire explosion particles
      this.emitParticles(bx, by + 0.6, bz, new THREE.Color(0xf97316), 40, 7.5);
      this.emitParticles(bx, by + 0.8, bz, new THREE.Color(0xef4444), 30, 6.0);

      // Radial damage to zombies
      for (const z of this.zombies) {
        if (z.state === 'DEAD') continue;
        const dist = z.mesh.position.distanceTo(_v1.set(bx, by, bz));
        if (dist < 6.5) {
          const falloff = 1 - dist / 6.5;
          this.damageZombie(z, 160 * falloff);
        }
      }

      // Damage player if close
      const playerDist = this.playerPos.distanceTo(_v1.set(bx, by, bz));
      if (playerDist < 6.0) {
        this.applyDamageToPlayer(Math.round(45 * (1 - playerDist / 6.0)));
      }
    }
  }

  private applyDamageToPlayer(damage: number) {
    if (this.health <= 0 || this.isRolling) return; // Invincible during roll

    let remainingDmg = damage;
    if (this.armor > 0) {
      const absorbed = Math.min(this.armor, Math.round(damage * 0.6));
      this.armor -= absorbed;
      remainingDmg -= absorbed;
    }

    this.health = Math.max(0, this.health - remainingDmg);
    soundManager.playPlayerHurt();
    this.screenShake = 0.35;
    this.callbacks.onPlayerHit();
    this.callbacks.onHealthChange(this.health, this.maxHealth, this.armor);

    if (this.health <= 0) {
      this.callbacks.onGameOver();
    }
  }

  private advanceObjective() {
    const cur = this.objectives[this.currentObjectiveIndex];
    if (cur) cur.completed = true;
    soundManager.playObjectiveCompleted();

    this.currentObjectiveIndex++;
    if (this.currentObjectiveIndex < this.objectives.length) {
      const next = this.objectives[this.currentObjectiveIndex];
      this.callbacks.onObjectiveUpdate(next, this.objectives);

      // Trigger wave spawns based on mission stage
      if (next.id === 'step_sample') {
        this.spawnZombies(4, 'RUNNER');
      } else if (next.id === 'step_extract') {
        this.spawnZombies(1, 'BRUTE');
        this.spawnZombies(5, 'RUNNER');
      }
    } else {
      // All objectives complete!
      this.callbacks.onVictory();
    }
  }

  // --- 60FPS TICK & SIMULATION ---
  private renderLoop = (time: number) => {
    if (!this.isRunning) return;
    this.animFrameId = requestAnimationFrame(this.renderLoop);

    const rawDt = (time - this.lastTime) / 1000;
    this.lastTime = time;
    const dt = Math.min(rawDt, 0.05); // Clamp dt to prevent physics tunneling

    if (!this.isPaused) {
      this.updateSimulation(dt);
    }

    this.renderer.render(this.scene, this.camera);
  };

  private updateSimulation(dt: number) {
    // 1. Stamina regeneration
    this.stamina = Math.min(100, this.stamina + 18 * dt);

    // 2. Weapon Reloading timer
    if (this.isReloading) {
      this.reloadTimer -= dt;
      if (this.reloadTimer <= 0) {
        this.isReloading = false;
        const wep = this.weapons[this.currentWeaponType];
        const needed = wep.magSize - wep.currentMag;
        const loaded = Math.min(needed, wep.reserveAmmo);
        wep.currentMag += loaded;
        wep.reserveAmmo -= loaded;
        this.callbacks.onAmmoChange(wep.currentMag, wep.reserveAmmo, wep.name);
      }
    }

    // 3. Player Movement & Physics
    this.updatePlayerMovement(dt);

    // 4. Update Camera & Third-Person Follow Rig
    this.updateCamera(dt);

    // 5. Update Pickups & Collision
    this.updatePickups(dt);

    // 6. Update Zombies AI & State Machines
    this.updateZombies(dt);

    // 7. Update Particles
    this.updateParticles(dt);

    // 8. Compass update towards active objective
    this.updateCompass();

    // 9. Endless wave spawning
    if (this.isEndless) {
      this.zombieSpawnTimer += dt;
      if (this.zombieSpawnTimer > 8.0) {
        this.zombieSpawnTimer = 0;
        this.wave++;
        this.spawnZombies(3 + this.wave, this.wave % 3 === 0 ? 'BRUTE' : this.wave % 2 === 0 ? 'RUNNER' : 'WALKER');
        this.callbacks.onScoreUpdate(this.score, this.kills, this.wave);
      }
    }
  }

  private updatePlayerMovement(dt: number) {
    if (this.health <= 0) {
      // Slump to ground
      this.playerMesh.root.rotation.x = THREE.MathUtils.damp(this.playerMesh.root.rotation.x, Math.PI / 2, 8, dt);
      return;
    }

    // Calculate move vector from keyboard + virtual joystick
    let mx = this.virtualMove.x;
    let my = this.virtualMove.y;

    if (this.keys['KeyW'] || this.keys['ArrowUp']) my -= 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) my += 1;
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) mx -= 1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) mx += 1;

    // Normalizing diagonal inputs
    const len = Math.hypot(mx, my);
    if (len > 1.0) {
      mx /= len;
      my /= len;
    }

    this.isSprinting = !!(this.keys['ShiftLeft'] || this.keys['ShiftRight']) && my < -0.2 && !this.isAiming;
    const baseSpeed = this.isAiming ? 2.4 : this.isSprinting ? 6.8 : 4.5;

    if (this.isRolling) {
      this.rollTimer -= dt;
      if (this.rollTimer <= 0) {
        this.isRolling = false;
        this.playerMesh.torso.rotation.x = 0;
      } else {
        // Roll spin animation
        this.playerMesh.torso.rotation.x -= 16 * dt;
        this.playerPos.addScaledVector(this.rollDir, 8.5 * dt);
      }
    } else {
      // Transform local movement by player facing rotation
      const forwardX = -Math.sin(this.playerRotation);
      const forwardZ = -Math.cos(this.playerRotation);
      const rightX = Math.cos(this.playerRotation);
      const rightZ = -Math.sin(this.playerRotation);

      const targetVx = (forwardX * -my + rightX * mx) * baseSpeed;
      const targetVz = (forwardZ * -my + rightZ * mx) * baseSpeed;

      this.playerVel.x = THREE.MathUtils.damp(this.playerVel.x, targetVx, 14, dt);
      this.playerVel.z = THREE.MathUtils.damp(this.playerVel.z, targetVz, 14, dt);

      // Attempt position step with box collision check
      const nextX = this.playerPos.x + this.playerVel.x * dt;
      const nextZ = this.playerPos.z + this.playerVel.z * dt;

      // Bounds clamping
      const clampedX = Math.max(-10.5, Math.min(10.5, nextX));
      const clampedZ = Math.max(-100, Math.min(28, nextZ));

      // Obstacle collision test
      const playerBox = new THREE.Box3(
        new THREE.Vector3(clampedX - 0.4, 0, clampedZ - 0.4),
        new THREE.Vector3(clampedX + 0.4, 1.8, clampedZ + 0.4)
      );

      let collided = false;
      for (const obs of this.obstacles) {
        if (obs.intersectsBox(playerBox)) {
          collided = true;
          break;
        }
      }

      if (!collided) {
        this.playerPos.x = clampedX;
        this.playerPos.z = clampedZ;
      } else {
        this.playerVel.set(0, 0, 0);
      }
    }

    this.playerMesh.root.position.copy(this.playerPos);
    this.playerMesh.root.rotation.y = this.playerRotation;

    // Procedural walk animation
    const speed = this.playerVel.length();
    const walkCycle = performance.now() * 0.008 * (speed > 0.5 ? speed / 4 : 0);

    if (speed > 0.5 && !this.isRolling) {
      this.playerMesh.leftLeg.rotation.x = Math.sin(walkCycle) * 0.55;
      this.playerMesh.rightLeg.rotation.x = -Math.sin(walkCycle) * 0.55;
      this.playerMesh.leftArm.rotation.x = -Math.sin(walkCycle) * 0.45;
      this.playerMesh.root.position.y = Math.abs(Math.sin(walkCycle * 2)) * 0.06;
    } else if (!this.isRolling) {
      this.playerMesh.leftLeg.rotation.x = THREE.MathUtils.damp(this.playerMesh.leftLeg.rotation.x, 0, 10, dt);
      this.playerMesh.rightLeg.rotation.x = THREE.MathUtils.damp(this.playerMesh.rightLeg.rotation.x, 0, 10, dt);
      this.playerMesh.leftArm.rotation.x = THREE.MathUtils.damp(this.playerMesh.leftArm.rotation.x, 0, 10, dt);
      this.playerMesh.root.position.y = 0;
    }

    // Aiming arm & recoil pitch
    this.recoilPitch = THREE.MathUtils.damp(this.recoilPitch, 0, 12, dt);
    this.playerMesh.rightArm.rotation.x = -Math.PI / 2 + this.playerPitch - this.recoilPitch;
    this.playerMesh.torso.rotation.y = this.isAiming ? 0.2 : 0;
  }

  private updateCamera(dt: number) {
    // Screen shake decay
    this.screenShake = THREE.MathUtils.damp(this.screenShake, 0, 8, dt);
    const shakeX = (Math.random() - 0.5) * this.screenShake;
    const shakeY = (Math.random() - 0.5) * this.screenShake;

    // Over-the-shoulder third-person camera offset
    const camDist = this.isAiming ? 2.2 : 3.8;
    const camHeight = this.isAiming ? 1.7 : 2.0;
    const shoulderOffset = this.isAiming ? 0.6 : 0.45;

    const backX = Math.sin(this.playerRotation) * camDist;
    const backZ = Math.cos(this.playerRotation) * camDist;
    const rightX = Math.cos(this.playerRotation) * shoulderOffset;
    const rightZ = -Math.sin(this.playerRotation) * shoulderOffset;

    const targetCamX = this.playerPos.x + backX + rightX + shakeX;
    const targetCamY = this.playerPos.y + camHeight + shakeY;
    const targetCamZ = this.playerPos.z + backZ + rightZ;

    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, targetCamX, 16, dt);
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, targetCamY, 16, dt);
    this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, targetCamZ, 16, dt);

    // Look target
    const lookTargetX = this.playerPos.x - Math.sin(this.playerRotation) * 12;
    const lookTargetY = this.playerPos.y + 1.5 + Math.sin(this.playerPitch) * 10;
    const lookTargetZ = this.playerPos.z - Math.cos(this.playerRotation) * 12;

    this.camera.lookAt(lookTargetX, lookTargetY, lookTargetZ);
  }

  private updatePickups(dt: number) {
    for (const p of this.pickups) {
      if (p.collected) continue;
      p.pulseTime += dt * 3.0;

      // Floating bobbing & rotation animation
      p.mesh.rotation.y += dt * 1.5;
      p.mesh.position.y = p.position[1] + Math.sin(p.pulseTime) * 0.12;

      // Distance to player
      const dist = this.playerPos.distanceTo(
        _v1.set(p.position[0], p.position[1], p.position[2])
      );

      if (dist < 1.6) {
        this.collectPickup(p);
      }
    }

    // Check extraction helipad trigger
    const distToEvac = this.playerPos.distanceTo(this.extractionPos);
    const curObj = this.objectives[this.currentObjectiveIndex];
    if (distToEvac < 4.2 && curObj && curObj.id === 'step_extract') {
      this.advanceObjective();
    }
  }

  private collectPickup(p: PickupEntity) {
    p.collected = true;
    this.scene.remove(p.mesh);

    if (p.type === 'MEDKIT') {
      this.health = Math.min(this.maxHealth, this.health + 50);
      this.armor = Math.min(50, this.armor + 15);
      soundManager.playPickup('MEDKIT');
      this.callbacks.onHealthChange(this.health, this.maxHealth, this.armor);
    } else if (p.type === 'AMMO') {
      for (const key of Object.keys(this.weapons) as WeaponType[]) {
        this.weapons[key].reserveAmmo = Math.min(
          this.weapons[key].maxReserve,
          this.weapons[key].reserveAmmo + this.weapons[key].magSize * 2
        );
      }
      const cur = this.weapons[this.currentWeaponType];
      soundManager.playPickup('AMMO');
      this.callbacks.onAmmoChange(cur.currentMag, cur.reserveAmmo, cur.name);
    } else if (p.type === 'SAMPLE') {
      soundManager.playPickup('SAMPLE');
      const obj = this.objectives[this.currentObjectiveIndex];
      if (obj && obj.id === 'step_sample') {
        obj.current = 1;
        this.advanceObjective();
      }
    } else if (p.type === 'WEAPON_RIFLE') {
      this.currentWeaponType = 'RIFLE';
      soundManager.playPickup('WEAPON');
      const cur = this.weapons['RIFLE'];
      this.callbacks.onWeaponChange(cur);
      this.callbacks.onAmmoChange(cur.currentMag, cur.reserveAmmo, cur.name);

      const obj = this.objectives[this.currentObjectiveIndex];
      if (obj && obj.id === 'step_weapon') {
        obj.current = 1;
        this.advanceObjective();
      }
    } else if (p.type === 'WEAPON_SHOTGUN') {
      this.currentWeaponType = 'SHOTGUN';
      soundManager.playPickup('WEAPON');
      const cur = this.weapons['SHOTGUN'];
      this.callbacks.onWeaponChange(cur);
      this.callbacks.onAmmoChange(cur.currentMag, cur.reserveAmmo, cur.name);
    }
  }

  private updateZombies(dt: number) {
    const now = performance.now() / 1000;

    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];

      if (z.state === 'DEAD') {
        z.deathTimer -= dt;
        // Death slump animation
        z.mesh.rotation.x = THREE.MathUtils.damp(z.mesh.rotation.x, -Math.PI / 2, 8, dt);
        z.mesh.position.y = THREE.MathUtils.damp(z.mesh.position.y, -0.4, 4, dt);
        if (z.deathTimer <= 0) {
          this.scene.remove(z.mesh);
          this.zombies.splice(i, 1);
        }
        continue;
      }

      // Hit flinch reaction
      if (z.hitTimer > 0) {
        z.hitTimer -= dt;
        z.mesh.position.y = THREE.MathUtils.damp(z.mesh.position.y, 0.1, 12, dt);
      }

      const zPos = z.mesh.position;
      const distToPlayer = zPos.distanceTo(this.playerPos);

      // Detection & Agro
      if (distToPlayer < 35 && z.state === 'IDLE') {
        z.state = 'CHASING';
        if (Math.random() > 0.6) {
          soundManager.playZombieGrowl(z.type === 'BRUTE' ? 0.6 : z.type === 'RUNNER' ? 1.4 : 1.0);
        }
      }

      if (z.state === 'CHASING') {
        // Face player
        const dx = this.playerPos.x - zPos.x;
        const dz = this.playerPos.z - zPos.z;
        const targetAngle = Math.atan2(dx, dz);
        z.rotationY = THREE.MathUtils.damp(z.rotationY, targetAngle, 8, dt);
        z.mesh.rotation.y = z.rotationY;

        // Move towards player
        if (distToPlayer > z.attackRange) {
          const moveSpeed = z.speed * (z.hitTimer > 0 ? 0.4 : 1.0);
          zPos.x += Math.sin(z.rotationY) * moveSpeed * dt;
          zPos.z += Math.cos(z.rotationY) * moveSpeed * dt;

          // Clamping
          zPos.x = Math.max(-10, Math.min(10, zPos.x));

          // Shambling animation
          z.animTime += dt * z.speed * 2.2;
          const leftLeg = z.mesh.getObjectByName('leftLeg');
          if (leftLeg) leftLeg.rotation.x = Math.sin(z.animTime) * 0.6;
        } else {
          // In attack range
          z.state = 'ATTACKING';
        }
      } else if (z.state === 'ATTACKING') {
        if (distToPlayer > z.attackRange + 0.8) {
          z.state = 'CHASING';
        } else if (now - z.lastAttackTime > z.attackCooldown) {
          z.lastAttackTime = now;
          soundManager.playZombieAttack();
          this.applyDamageToPlayer(z.damage);
        }
      }
    }
  }

  private updateCompass() {
    let target = this.extractionPos;
    const curObj = this.objectives[this.currentObjectiveIndex];
    if (curObj) {
      if (curObj.id === 'step_weapon') {
        const p = this.pickups.find((item) => item.type === 'WEAPON_RIFLE' && !item.collected);
        if (p) target = _v1.set(p.position[0], p.position[1], p.position[2]);
      } else if (curObj.id === 'step_sample') {
        const p = this.pickups.find((item) => item.type === 'SAMPLE' && !item.collected);
        if (p) target = _v1.set(p.position[0], p.position[1], p.position[2]);
      } else if (curObj.id === 'step_kill_walkers') {
        const closestZombie = this.zombies.find((z) => z.state !== 'DEAD');
        if (closestZombie) target = closestZombie.mesh.position;
      }
    }

    const dx = target.x - this.playerPos.x;
    const dz = target.z - this.playerPos.z;
    const angleToTarget = Math.atan2(dx, dz);
    const relAngle = angleToTarget - this.playerRotation;
    const distance = Math.round(this.playerPos.distanceTo(target));

    this.callbacks.onCompassUpdate(relAngle, distance);
  }

  // --- INPUT BINDINGS ---
  private bindEvents() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.onResize);

    const canvas = this.renderer.domElement;
    canvas.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mousemove', this.onMouseMove);
    window.addEventListener('mouseup', this.onMouseUp);
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  private unbindEvents() {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('mousemove', this.onMouseMove);
    window.removeEventListener('mouseup', this.onMouseUp);
  }

  private onKeyDown = (e: KeyboardEvent) => {
    this.keys[e.code] = true;

    if (e.code === 'KeyR') {
      this.reloadWeapon();
    } else if (e.code === 'Space') {
      e.preventDefault();
      this.dodgeRoll();
    } else if (e.code === 'Digit1') {
      this.switchWeapon('PISTOL');
    } else if (e.code === 'Digit2') {
      this.switchWeapon('RIFLE');
    } else if (e.code === 'Digit3') {
      this.switchWeapon('SHOTGUN');
    } else if (e.code === 'KeyQ') {
      this.switchWeapon();
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;
  };

  private onMouseDown = (e: MouseEvent) => {
    if (e.button === 0) {
      // Left click: Shoot
      this.fireWeapon();
    } else if (e.button === 2) {
      // Right click: Aim down sights
      this.toggleAim(true);
    }
  };

  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 2) {
      this.toggleAim(false);
    }
  };

  private onMouseMove = (e: MouseEvent) => {
    if (document.pointerLockElement === this.renderer.domElement) {
      this.playerRotation -= e.movementX * this.mouseSens;
      this.playerPitch = Math.max(-0.6, Math.min(0.6, this.playerPitch - e.movementY * this.mouseSens));
    }
  };

  public requestPointerLock() {
    this.renderer.domElement.requestPointerLock?.();
  }

  // Virtual Joystick inputs from mobile component
  public setVirtualMove(x: number, y: number) {
    this.virtualMove.x = x;
    this.virtualMove.y = y;
  }

  public applyTouchLookDelta(dx: number, dy: number) {
    this.playerRotation -= dx * this.touchLookSens;
    this.playerPitch = Math.max(-0.6, Math.min(0.6, this.playerPitch - dy * this.touchLookSens));
  }

  public setPaused(paused: boolean) {
    this.isPaused = paused;
  }

  private onResize = () => {
    if (!this.container || !this.renderer || !this.camera) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / (height || 1);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  public dispose() {
    this.isRunning = false;
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
    this.unbindEvents();

    if (this.renderer && this.renderer.domElement && this.renderer.domElement.parentNode) {
      this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
      this.renderer.dispose();
    }
  }
}
