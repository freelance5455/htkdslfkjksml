/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { CharacterId, PowerUpType, RunSummary } from '../types/game';
import { TRACK_LANES, GAME_PHYSICS, CHARACTERS } from './constants';
import { createCharacterModel, CharacterRig } from './proceduralModels';
import { TrackManager, ActiveObstacle, ActiveCollectible } from './trackManager';
import { sounds } from '../audio/SoundEffects';

export interface GameEngineCallbacks {
  onScoreUpdate: (score: number, coins: number, distance: number, multiplier: number) => void;
  onPowerUpUpdate: (activePowerUps: { type: PowerUpType; remaining: number; duration: number }[]) => void;
  onGameOver: (summary: RunSummary) => void;
  onMissionEvent: (type: string, amount: number) => void;
}

export class GameEngine {
  private container: HTMLElement;
  private callbacks: GameEngineCallbacks;

  // Three.js Core
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private clock!: THREE.Clock;
  private trackManager!: TrackManager;
  private characterRig!: CharacterRig;
  private isSoftwareGl: boolean = false;
  private animationFrameId: number = 0;
  private isRunning: boolean = false;
  private isPaused: boolean = false;

  // Lighting
  private dirLight!: THREE.DirectionalLight;

  // Particle systems
  private sparkGroup!: THREE.Group;
  private sparks: { mesh: THREE.Mesh; vx: number; vy: number; vz: number; life: number }[] = [];
  private jetpackFireGroup!: THREE.Group;
  private speedLinesGroup!: THREE.Group;

  // Player State
  private selectedCharacterId: CharacterId = 'jake';
  private lane: number = 1; // 0: Left, 1: Center, 2: Right
  private targetX: number = 0;
  private playerX: number = 0;
  private playerY: number = 0;
  private playerZ: number = 0;
  private vy: number = 0;
  private isGrounded: boolean = true;
  private groundY: number = 0; // Can be 0 on track, or 4.3 on train roof
  private isSliding: boolean = false;
  private slideTimer: number = 0;
  private runAnimTime: number = 0;
  private lastFootstepTime: number = 0;

  // Camera & FX
  private cameraShake: number = 0;
  private hitstopTimer: number = 0;
  private invincibilityTimer: number = 0;

  // Game Stats
  private currentSpeed: number = GAME_PHYSICS.BASE_SPEED;
  private distanceRan: number = 0;
  private coinsCollected: number = 0;
  private baseMultiplier: number = 1;
  private activeMultiplier: number = 1;
  private score: number = 0;

  // Active Power-ups
  private activePowerUps: Map<PowerUpType, { remaining: number; duration: number }> = new Map();

  // Touch & Input Handling
  private touchStartX: number = 0;
  private touchStartY: number = 0;
  private touchStartTime: number = 0;

  constructor(container: HTMLElement, callbacks: GameEngineCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.init();
  }

  private init() {
    // 1. Detect software WebGL
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Renderer
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.appendChild(this.renderer.domElement);

    // 3. Scene & Sunny Day Horizon Fog
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x7dd3fc); // Bright sunny blue sky
    this.scene.fog = new THREE.FogExp2(0x7dd3fc, 0.005); // Soft atmospheric aerial perspective

    // 4. Camera
    this.camera = new THREE.PerspectiveCamera(62, width / height, 0.1, 400);
    this.camera.position.set(0, 3.8, 8);
    this.camera.lookAt(0, 1.8, -10);

    // 5. Studio Environment Reflection
    try {
      const pmrem = new THREE.PMREMGenerator(this.renderer);
      this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
      pmrem.dispose();
    } catch {
      // Fallback
    }

    // 6. Balanced Sunny 3-Point Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0x94a3b8, 1.35);
    this.scene.add(hemiLight);

    this.dirLight = new THREE.DirectionalLight(0xfff7ed, 2.4); // Warm golden sunlight
    this.dirLight.position.set(25, 45, 20);
    this.dirLight.castShadow = !this.isSoftwareGl;
    this.dirLight.shadow.mapSize.width = 1024;
    this.dirLight.shadow.mapSize.height = 1024;
    this.dirLight.shadow.camera.near = 10;
    this.dirLight.shadow.camera.far = 130;
    const shadowD = 24;
    this.dirLight.shadow.camera.left = -shadowD;
    this.dirLight.shadow.camera.right = shadowD;
    this.dirLight.shadow.camera.top = shadowD;
    this.dirLight.shadow.camera.bottom = -shadowD;
    this.dirLight.shadow.bias = -0.0005;
    this.dirLight.shadow.normalBias = 0.02;
    this.scene.add(this.dirLight);
    this.scene.add(this.dirLight.target);

    // 7. Track Manager
    this.trackManager = new TrackManager(this.scene);

    // 8. Player Character Rig
    this.loadCharacter(this.selectedCharacterId);

    // 9. Particle VFX Systems
    this.initVFX();

    // 10. Clock & Events
    this.clock = new THREE.Clock();
    this.bindEvents();

    // Warm shaders
    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    // Initial render
    this.renderer.render(this.scene, this.camera);
  }

  private initVFX() {
    // Coin Sparkles Pool
    this.sparkGroup = new THREE.Group();
    const sparkGeom = new THREE.SphereGeometry(0.12, 6, 6);
    const sparkMat = new THREE.MeshBasicMaterial({ color: 0xfde047 });

    for (let i = 0; i < 30; i++) {
      const spark = new THREE.Mesh(sparkGeom, sparkMat);
      spark.visible = false;
      this.sparkGroup.add(spark);
      this.sparks.push({ mesh: spark, vx: 0, vy: 0, vz: 0, life: 0 });
    }
    this.scene.add(this.sparkGroup);

    // Jetpack Exhaust Flames
    this.jetpackFireGroup = new THREE.Group();
    const flameGeom = new THREE.ConeGeometry(0.12, 0.5, 8);
    const flameMat = new THREE.MeshBasicMaterial({ color: 0xf97316 });
    const flameLeft = new THREE.Mesh(flameGeom, flameMat);
    flameLeft.position.set(-0.18, -0.4, -0.28);
    flameLeft.rotation.x = Math.PI;
    this.jetpackFireGroup.add(flameLeft);

    const flameRight = new THREE.Mesh(flameGeom, flameMat);
    flameRight.position.set(0.18, -0.4, -0.28);
    flameRight.rotation.x = Math.PI;
    this.jetpackFireGroup.add(flameRight);
    this.jetpackFireGroup.visible = false;
    this.characterRig.torso.add(this.jetpackFireGroup);

    // Speed Lines Effect in camera periphery
    this.speedLinesGroup = new THREE.Group();
    const lineGeom = new THREE.CylinderGeometry(0.015, 0.015, 6, 4);
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.25 });
    for (let i = 0; i < 24; i++) {
      const line = new THREE.Mesh(lineGeom, lineMat);
      line.rotation.x = Math.PI / 2;
      line.position.set(
        (Math.random() - 0.5) * 12,
        Math.random() * 6 + 1,
        -Math.random() * 20
      );
      this.speedLinesGroup.add(line);
    }
    this.speedLinesGroup.visible = false;
    this.scene.add(this.speedLinesGroup);
  }

  public loadCharacter(charId: CharacterId) {
    this.selectedCharacterId = charId;
    const def = CHARACTERS.find((c) => c.id === charId) || CHARACTERS[0];

    if (this.characterRig) {
      this.scene.remove(this.characterRig.root);
    }

    this.characterRig = createCharacterModel(def);
    this.characterRig.root.position.set(this.playerX, this.playerY, this.playerZ);
    this.scene.add(this.characterRig.root);

    // Reattach jetpack flames
    if (this.jetpackFireGroup) {
      this.characterRig.torso.add(this.jetpackFireGroup);
    }
  }

  // -------------------------------------------------------------
  // Input Handling: Keyboard & Touch Gestures
  // -------------------------------------------------------------
  private bindEvents() {
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('resize', this.handleResize);

    const dom = this.container;
    dom.addEventListener('touchstart', this.handleTouchStart, { passive: true });
    dom.addEventListener('touchend', this.handleTouchEnd, { passive: true });
    dom.addEventListener('mousedown', this.handleMouseDown);
    dom.addEventListener('mouseup', this.handleMouseUp);
  }

  public unbindEvents() {
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('resize', this.handleResize);

    const dom = this.container;
    dom.removeEventListener('touchstart', this.handleTouchStart);
    dom.removeEventListener('touchend', this.handleTouchEnd);
    dom.removeEventListener('mousedown', this.handleMouseDown);
    dom.removeEventListener('mouseup', this.handleMouseUp);
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    if (!this.isRunning || this.isPaused) return;

    switch (e.code) {
      case 'ArrowLeft':
      case 'KeyA':
        this.moveLeft();
        break;
      case 'ArrowRight':
      case 'KeyD':
        this.moveRight();
        break;
      case 'ArrowUp':
      case 'KeyW':
      case 'Space':
        e.preventDefault();
        this.jump();
        break;
      case 'ArrowDown':
      case 'KeyS':
        e.preventDefault();
        this.slide();
        break;
      case 'Escape':
      case 'KeyP':
        this.togglePause();
        break;
    }
  };

  private handleTouchStart = (e: TouchEvent) => {
    if (e.touches.length > 0) {
      this.touchStartX = e.touches[0].clientX;
      this.touchStartY = e.touches[0].clientY;
      this.touchStartTime = performance.now();
    }
  };

  private handleTouchEnd = (e: TouchEvent) => {
    if (e.changedTouches.length > 0) {
      const dx = e.changedTouches[0].clientX - this.touchStartX;
      const dy = e.changedTouches[0].clientY - this.touchStartY;
      const dt = performance.now() - this.touchStartTime;
      this.processSwipe(dx, dy, dt);
    }
  };

  private handleMouseDown = (e: MouseEvent) => {
    this.touchStartX = e.clientX;
    this.touchStartY = e.clientY;
    this.touchStartTime = performance.now();
  };

  private handleMouseUp = (e: MouseEvent) => {
    const dx = e.clientX - this.touchStartX;
    const dy = e.clientY - this.touchStartY;
    const dt = performance.now() - this.touchStartTime;
    this.processSwipe(dx, dy, dt);
  };

  private processSwipe(dx: number, dy: number, dt: number) {
    if (!this.isRunning || this.isPaused) return;
    const absX = Math.abs(dx);
    const absY = Math.abs(dy);
    const minThreshold = 28;

    if (Math.max(absX, absY) < minThreshold || dt > 600) return;

    if (absX > absY) {
      if (dx < 0) this.moveLeft();
      else this.moveRight();
    } else {
      if (dy < 0) this.jump();
      else this.slide();
    }
  }

  public moveLeft() {
    if (this.lane > 0) {
      this.lane--;
      this.targetX = TRACK_LANES[this.lane];
      sounds.playLaneSwitch();
    }
  }

  public moveRight() {
    if (this.lane < 2) {
      this.lane++;
      this.targetX = TRACK_LANES[this.lane];
      sounds.playLaneSwitch();
    }
  }

  public jump() {
    const hasJetpack = this.activePowerUps.has('jetpack');
    if (hasJetpack) return; // Jetpack controls height

    if (this.isGrounded || this.isSliding) {
      // Cancel slide immediately into jump
      this.isSliding = false;
      this.slideTimer = 0;

      const hasSneakers = this.activePowerUps.has('sneakers');
      this.vy = hasSneakers ? GAME_PHYSICS.SUPER_JUMP_VELOCITY : GAME_PHYSICS.JUMP_VELOCITY;
      this.isGrounded = false;
      sounds.playJump(hasSneakers);
      this.callbacks.onMissionEvent('jump', 1);
    }
  }

  public slide() {
    const hasJetpack = this.activePowerUps.has('jetpack');
    if (hasJetpack) return;

    if (!this.isGrounded) {
      // Fast fall down from jump
      this.vy = -GAME_PHYSICS.GRAVITY * 0.7;
    }

    this.isSliding = true;
    this.slideTimer = GAME_PHYSICS.SLIDE_DURATION;
    sounds.playSlide();
    this.callbacks.onMissionEvent('slide', 1);
  }

  public togglePause() {
    if (!this.isRunning) return;
    this.isPaused = !this.isPaused;
    if (this.isPaused) {
      sounds.stopMusic();
      sounds.stopJetpackHum();
    } else {
      sounds.startMusic();
      if (this.activePowerUps.has('jetpack')) {
        sounds.startJetpackHum();
      }
    }
  }

  private handleResize = () => {
    if (!this.container || !this.renderer || !this.camera) return;
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  // -------------------------------------------------------------
  // Game Lifecycle: Start, Loop, Restart, Game Over
  // -------------------------------------------------------------
  public start(charId?: CharacterId) {
    if (charId) {
      this.loadCharacter(charId);
    }

    this.resetStats();
    this.trackManager.reset();
    this.isRunning = true;
    this.isPaused = false;
    this.clock.start();

    sounds.startMusic();

    cancelAnimationFrame(this.animationFrameId);
    this.tick();
  }

  private resetStats() {
    this.lane = 1;
    this.targetX = TRACK_LANES[1];
    this.playerX = 0;
    this.playerY = 0;
    this.playerZ = 0;
    this.vy = 0;
    this.isGrounded = true;
    this.groundY = 0;
    this.isSliding = false;
    this.slideTimer = 0;
    this.runAnimTime = 0;

    this.currentSpeed = GAME_PHYSICS.BASE_SPEED;
    this.distanceRan = 0;
    this.coinsCollected = 0;
    this.score = 0;
    this.baseMultiplier = 1;
    this.activeMultiplier = 1;

    this.activePowerUps.clear();
    this.cameraShake = 0;
    this.hitstopTimer = 0;
    this.invincibilityTimer = 0;

    // Reset powerup visual cues
    this.characterRig.jetpack.visible = false;
    this.characterRig.superSneakersLeft.visible = false;
    this.characterRig.superSneakersRight.visible = false;
    this.characterRig.shieldBubble.visible = false;
    this.jetpackFireGroup.visible = false;
    this.speedLinesGroup.visible = false;

    this.updatePowerupHUD();
  }

  private tick = () => {
    if (!this.isRunning) return;

    const rawDelta = this.clock.getDelta();
    const delta = Math.min(rawDelta, 0.05); // Clamp to prevent clipping

    if (!this.isPaused) {
      // Hitstop delay for heavy impacts
      if (this.hitstopTimer > 0) {
        this.hitstopTimer -= delta;
      } else {
        this.updatePhysics(delta);
        this.updatePowerUps(delta);
        this.updateObstacleCollisions();
        this.updateCollectibleInteractions(delta);
        this.updateVFX(delta);
      }
    }

    this.updateCamera(delta);
    this.animateCharacter(delta);

    this.renderer.render(this.scene, this.camera);

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.animationFrameId = requestAnimationFrame(this.tick);
    }
  };

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.animationFrameId = window.setTimeout(poll, 5);
      } else {
        gl.deleteSync(sync);
        this.animationFrameId = window.setTimeout(cb, 60);
      }
    };
    this.animationFrameId = window.setTimeout(poll, 5);
  }

  // -------------------------------------------------------------
  // Physics & Player Movement
  // -------------------------------------------------------------
  private updatePhysics(delta: number) {
    // 1. Forward Speed Acceleration
    this.currentSpeed = Math.min(
      GAME_PHYSICS.MAX_SPEED,
      this.currentSpeed + GAME_PHYSICS.SPEED_ACCEL * delta
    );

    // Speed lines visual effect at high speeds
    this.speedLinesGroup.visible = this.currentSpeed > 28;

    // 2. Advance Forward in Z
    const forwardStep = this.currentSpeed * delta;
    this.playerZ -= forwardStep;
    this.distanceRan += forwardStep;

    // 3. Score Accumulation
    const multiplierBoost = this.activePowerUps.has('multiplier') ? 2 : 1;
    this.activeMultiplier = this.baseMultiplier * multiplierBoost;
    this.score += Math.floor(forwardStep * this.activeMultiplier);

    this.callbacks.onScoreUpdate(
      this.score,
      this.coinsCollected,
      Math.floor(this.distanceRan),
      this.activeMultiplier
    );

    // 4. Smooth Lateral Lane Switching
    const laneDelta = this.targetX - this.playerX;
    this.playerX += laneDelta * Math.min(delta * GAME_PHYSICS.LANE_SWITCH_SPEED, 1.0);

    // 5. Vertical Jump & Gravity Physics
    const hasJetpack = this.activePowerUps.has('jetpack');

    if (hasJetpack) {
      // Float at jetpack altitude
      const targetFlightY = GAME_PHYSICS.JETPACK_HEIGHT;
      this.playerY += (targetFlightY - this.playerY) * Math.min(delta * 6.0, 1.0);
      this.vy = 0;
      this.isGrounded = false;
    } else {
      // Standard gravity
      this.playerY += this.vy * delta;
      this.vy -= GAME_PHYSICS.GRAVITY * delta;

      // Check ground landing
      if (this.playerY <= this.groundY) {
        this.playerY = this.groundY;
        this.vy = 0;
        this.isGrounded = true;
      } else {
        this.isGrounded = false;
      }
    }

    // 6. Slide Timer
    if (this.isSliding) {
      this.slideTimer -= delta;
      if (this.slideTimer <= 0) {
        this.isSliding = false;
      }
    }

    // 7. Invincibility recovery timer
    if (this.invincibilityTimer > 0) {
      this.invincibilityTimer -= delta;
      // Blinking opacity
      this.characterRig.root.visible = Math.floor(this.invincibilityTimer * 12) % 2 === 0;
    } else {
      this.characterRig.root.visible = true;
    }

    // 8. Update Rig Root Position
    this.characterRig.root.position.set(this.playerX, this.playerY, this.playerZ);

    // 9. Update Track Manager
    this.trackManager.update(this.playerZ, delta, this.currentSpeed);

    // 10. Update Directional Light target to follow player for consistent shadows
    this.dirLight.position.set(this.playerX + 25, 45, this.playerZ + 20);
    this.dirLight.target.position.set(this.playerX, 0, this.playerZ - 15);
    this.dirLight.target.updateMatrixWorld();
  }

  // -------------------------------------------------------------
  // Power-Ups System
  // -------------------------------------------------------------
  public activatePowerUp(type: PowerUpType) {
    sounds.playPowerUp();
    let duration = 10;

    switch (type) {
      case 'jetpack':
        duration = GAME_PHYSICS.JETPACK_DURATION;
        this.characterRig.jetpack.visible = true;
        this.jetpackFireGroup.visible = true;
        sounds.startJetpackHum();
        // Spawn sky coins along flight path!
        this.trackManager.spawnJetpackSkyCoins(this.playerZ - 10, this.currentSpeed * duration * 0.9);
        break;
      case 'sneakers':
        duration = GAME_PHYSICS.SNEAKERS_DURATION;
        this.characterRig.superSneakersLeft.visible = true;
        this.characterRig.superSneakersRight.visible = true;
        break;
      case 'magnet':
        duration = GAME_PHYSICS.MAGNET_DURATION;
        break;
      case 'multiplier':
        duration = GAME_PHYSICS.MULTIPLIER_DURATION;
        break;
      case 'shield':
        duration = 999; // Stays active until 1 hit
        this.characterRig.shieldBubble.visible = true;
        break;
    }

    this.activePowerUps.set(type, { remaining: duration, duration });
    this.updatePowerupHUD();
    this.callbacks.onMissionEvent('powerup', 1);
  }

  private updatePowerUps(delta: number) {
    const toRemove: PowerUpType[] = [];

    this.activePowerUps.forEach((info, type) => {
      if (type !== 'shield') {
        info.remaining -= delta;
        if (info.remaining <= 0) {
          toRemove.push(type);
        }
      }
    });

    toRemove.forEach((type) => {
      this.activePowerUps.delete(type);
      if (type === 'jetpack') {
        this.characterRig.jetpack.visible = false;
        this.jetpackFireGroup.visible = false;
        sounds.stopJetpackHum();
      } else if (type === 'sneakers') {
        this.characterRig.superSneakersLeft.visible = false;
        this.characterRig.superSneakersRight.visible = false;
      }
    });

    if (toRemove.length > 0 || this.activePowerUps.size > 0) {
      this.updatePowerupHUD();
    }
  }

  private updatePowerupHUD() {
    const list = Array.from(this.activePowerUps.entries()).map(([type, data]) => ({
      type,
      remaining: data.remaining,
      duration: data.duration,
    }));
    this.callbacks.onPowerUpUpdate(list);
  }

  // -------------------------------------------------------------
  // Collision Detection with Obstacles
  // -------------------------------------------------------------
  private updateObstacleCollisions() {
    const obstacles = this.trackManager.getObstacles();
    const hasJetpack = this.activePowerUps.has('jetpack');

    // Player bounding parameters
    const pX = this.playerX;
    const pY = this.playerY;
    const pZ = this.playerZ;
    const playerWidth = 0.8;
    const playerHeight = this.isSliding ? GAME_PHYSICS.SLIDE_HEIGHT : GAME_PHYSICS.NORMAL_HEIGHT;

    // Reset default ground baseline
    let detectedTrainRoofY = 0;

    for (const obs of obstacles) {
      const oPos = obs.mesh.position;
      const distZ = Math.abs(oPos.z - pZ);

      // Warning train horn when oncoming train is near
      if (obs.isMoving && oPos.z < pZ && pZ - oPos.z < 65 && !obs.passed) {
        sounds.playTrainHorn();
        obs.passed = true;
      }

      // Check if player is directly within obstacle's depth footprint
      const halfDepth = (obs.length || 1) / 2;
      const halfWidth = (obs.width || 2) / 2;

      if (distZ <= halfDepth + 0.4) {
        const distX = Math.abs(oPos.x - pX);

        if (distX <= halfWidth + playerWidth / 2 - 0.2) {
          // If flying with Jetpack high above tracks, skip all ground obstacles
          if (hasJetpack && pY > 5.5) {
            continue;
          }

          // Case 1: Train
          if (obs.type === 'train') {
            const trainRoofHeight = 4.3;

            // If player took ramp or jumped on top of the train roof
            if (pY >= trainRoofHeight - 0.35) {
              detectedTrainRoofY = trainRoofHeight;
            } else if (obs.hasRamp && distZ > halfDepth - 2.5 && pZ > oPos.z) {
              // Sliding up front ramp
              const rampProgress = 1 - (pZ - (oPos.z + halfDepth - 2.5)) / 4.8;
              this.groundY = Math.max(0, rampProgress * trainRoofHeight);
              return;
            } else {
              // Direct crash with front or side of train!
              this.handleCrash();
              return;
            }
          }

          // Case 2: Low Barrier (Hurdle)
          else if (obs.type === 'barrier_low') {
            // Jumpable: must be higher than barrier height (1.1)
            if (pY < 1.0) {
              this.handleCrash();
              return;
            }
          }

          // Case 3: High Barrier (Overhead sign)
          else if (obs.type === 'barrier_high') {
            // Slidable: player must be sliding (height <= 1.5) and on ground
            if (!this.isSliding || pY > 0.4) {
              this.handleCrash();
              return;
            }
          }

          // Case 4: Stacked Crates
          else if (obs.type === 'crates') {
            if (pY < 1.05) {
              this.handleCrash();
              return;
            }
          }
        }
      }
    }

    this.groundY = detectedTrainRoofY;
  }

  // -------------------------------------------------------------
  // Collectible Interactions (Coins & Power-up Pickups)
  // -------------------------------------------------------------
  private updateCollectibleInteractions(delta: number) {
    const collectibles = this.trackManager.getCollectibles();
    const hasMagnet = this.activePowerUps.has('magnet');
    const pX = this.playerX;
    const pY = this.playerY + 0.8;
    const pZ = this.playerZ;

    for (const item of collectibles) {
      if (item.collected) continue;

      const iPos = item.mesh.position;
      const dx = pX - iPos.x;
      const dy = pY - iPos.y;
      const dz = pZ - iPos.z;
      const distSq = dx * dx + dy * dy + dz * dz;

      // Magnet attraction
      if (hasMagnet && item.type === 'coin' && distSq < GAME_PHYSICS.MAGNET_RADIUS * GAME_PHYSICS.MAGNET_RADIUS) {
        iPos.x += dx * Math.min(delta * 14.0, 1.0);
        iPos.y += dy * Math.min(delta * 14.0, 1.0);
        iPos.z += dz * Math.min(delta * 14.0, 1.0);
      }

      // Pickup radius test
      const pickupDist = item.type === 'coin' ? 1.4 : 1.8;
      if (distSq < pickupDist * pickupDist) {
        item.collected = true;

        if (item.type === 'coin') {
          sounds.playCoin();
          this.coinsCollected++;
          this.score += 50 * this.activeMultiplier;
          this.spawnCoinSparks(iPos.x, iPos.y, iPos.z);
          this.callbacks.onMissionEvent('coins', 1);
        } else if (item.type === 'powerup_magnet') {
          this.activatePowerUp('magnet');
        } else if (item.type === 'powerup_jetpack') {
          this.activatePowerUp('jetpack');
        } else if (item.type === 'powerup_sneakers') {
          this.activatePowerUp('sneakers');
        } else if (item.type === 'powerup_multiplier') {
          this.activatePowerUp('multiplier');
        }
      }
    }
  }

  private handleCrash() {
    if (this.invincibilityTimer > 0) return;

    // Shield protection
    if (this.activePowerUps.has('shield')) {
      sounds.playShieldBreak();
      this.activePowerUps.delete('shield');
      this.characterRig.shieldBubble.visible = false;
      this.invincibilityTimer = 1.8;
      this.cameraShake = 0.6;
      this.updatePowerupHUD();
      return;
    }

    // Fatal Crash
    sounds.playCrash();
    sounds.stopMusic();
    sounds.stopJetpackHum();
    this.isRunning = false;
    this.cameraShake = 1.2;
    this.hitstopTimer = 0.08;

    // Ragdoll stumble tumble animation
    this.characterRig.root.rotation.x = -Math.PI / 2.5;
    this.characterRig.root.position.y = 0.4;

    const summary: RunSummary = {
      score: this.score,
      coins: this.coinsCollected,
      distance: Math.floor(this.distanceRan),
      multiplier: this.activeMultiplier,
      newHighScore: false,
      completedMissions: [],
    };

    setTimeout(() => {
      this.callbacks.onGameOver(summary);
    }, 450);
  }

  // -------------------------------------------------------------
  // Camera & Visual Polish
  // -------------------------------------------------------------
  private updateCamera(delta: number) {
    const hasJetpack = this.activePowerUps.has('jetpack');

    // Camera follow offsets: dynamically follow player across lanes!
    const camTargetX = this.playerX * 0.95;
    const camTargetY = this.playerY + (hasJetpack ? 4.8 : 3.7);
    const camTargetZ = this.playerZ + 7.4;

    // Responsive exponential smoothing
    this.camera.position.x += (camTargetX - this.camera.position.x) * Math.min(delta * 12.0, 1.0);
    this.camera.position.y += (camTargetY - this.camera.position.y) * Math.min(delta * 8.0, 1.0);
    this.camera.position.z = camTargetZ;

    // Decaying camera shake
    if (this.cameraShake > 0) {
      this.camera.position.x += (Math.random() - 0.5) * this.cameraShake * 0.4;
      this.camera.position.y += (Math.random() - 0.5) * this.cameraShake * 0.4;
      this.cameraShake = Math.max(0, this.cameraShake - delta * 3.5);
    }

    // Dynamic FOV kick on high speed
    const targetFov = hasJetpack ? 70 : 60 + (this.currentSpeed - GAME_PHYSICS.BASE_SPEED) * 0.35;
    this.camera.fov += (targetFov - this.camera.fov) * Math.min(delta * 4.0, 1.0);
    this.camera.updateProjectionMatrix();

    // Look directly ahead of the player in their current lane!
    this.camera.lookAt(this.playerX * 0.95, this.playerY + 1.6, this.playerZ - 14);

    // Update speed lines position relative to camera
    if (this.speedLinesGroup.visible) {
      this.speedLinesGroup.position.set(this.camera.position.x, this.camera.position.y - 1, this.camera.position.z - 8);
    }
  }

  private animateCharacter(delta: number) {
    const rig = this.characterRig;
    const hasJetpack = this.activePowerUps.has('jetpack');

    // Banking roll when changing lanes
    const laneOffset = this.targetX - this.playerX;
    const targetRoll = -laneOffset * 0.12;
    rig.root.rotation.z += (targetRoll - rig.root.rotation.z) * Math.min(delta * 12.0, 1.0);

    if (hasJetpack) {
      // Superman horizontal flight pose forward into -Z
      rig.root.rotation.x = -1.1; // Body pitched horizontally forward
      rig.torso.rotation.x = 0.15;
      rig.head.rotation.x = 0.55; // Head raised looking forward down the track
      rig.leftArm.rotation.x = 2.4; // Arms stretched forward in flight
      rig.rightArm.rotation.x = 2.4;
      rig.leftLeg.rotation.x = -0.2;
      rig.rightLeg.rotation.x = -0.2;
      return;
    }

    if (this.isSliding) {
      // Baseball slide pose: feet sliding forward into -Z, torso tilted back toward camera
      rig.root.rotation.x = 0.5;
      rig.root.position.y = this.playerY + 0.22;
      rig.torso.rotation.x = 0.2;
      rig.head.rotation.x = -0.25;

      rig.leftLeg.rotation.x = 1.35; // Legs extended forward into slide
      rig.rightLeg.rotation.x = 1.25;
      rig.leftShin.rotation.x = -0.15;
      rig.rightShin.rotation.x = -0.15;

      rig.leftArm.rotation.x = -0.8; // Arms balanced behind
      rig.rightArm.rotation.x = -0.8;
      return;
    }

    if (!this.isGrounded) {
      // Dynamic jump pose: tucked knees, arms raised
      rig.root.rotation.x = -0.15; // Athletic forward lean
      rig.leftLeg.rotation.x = 0.75;
      rig.leftShin.rotation.x = -1.0;
      rig.rightLeg.rotation.x = 0.5;
      rig.rightShin.rotation.x = -0.85;

      rig.leftArm.rotation.x = 1.4;
      rig.rightArm.rotation.x = 1.4;
      rig.leftForearm.rotation.x = 0.5;
      rig.rightForearm.rotation.x = 0.5;
      return;
    }

    // Natural running animation loop
    const runFrequency = 14 + (this.currentSpeed - GAME_PHYSICS.BASE_SPEED) * 0.35;
    this.runAnimTime += delta * runFrequency;

    const swing = Math.sin(this.runAnimTime);
    const cosSwing = Math.cos(this.runAnimTime);

    // Torso subtle bob & athletic forward running lean
    rig.root.rotation.x = -0.12;
    rig.torso.position.y = 0.05 * Math.abs(cosSwing);
    rig.torso.rotation.y = swing * 0.08;

    // Legs pendulum swing forward & backward
    rig.leftLeg.rotation.x = swing * 0.85;
    rig.leftShin.rotation.x = Math.min(0, -swing * 1.1);

    rig.rightLeg.rotation.x = -swing * 0.85;
    rig.rightShin.rotation.x = Math.min(0, swing * 1.1);

    // Arms counter-swing
    rig.leftArm.rotation.x = -swing * 0.85;
    rig.leftForearm.rotation.x = 0.6;

    rig.rightArm.rotation.x = swing * 0.85;
    rig.rightForearm.rotation.x = 0.6;

    // Footstep audio triggers
    const now = performance.now();
    if (Math.abs(swing) > 0.92 && now - this.lastFootstepTime > 180) {
      sounds.playFootstep();
      this.lastFootstepTime = now;
    }
  }

  // -------------------------------------------------------------
  // VFX & Sparks Pool
  // -------------------------------------------------------------
  private spawnCoinSparks(x: number, y: number, z: number) {
    for (let i = 0; i < 6; i++) {
      const spark = this.sparks.find((s) => s.life <= 0);
      if (spark) {
        spark.mesh.position.set(x, y, z);
        spark.mesh.visible = true;
        spark.vx = (Math.random() - 0.5) * 6;
        spark.vy = Math.random() * 5 + 2;
        spark.vz = (Math.random() - 0.5) * 6;
        spark.life = 0.35;
      }
    }
  }

  private updateVFX(delta: number) {
    // Animate active sparks
    for (const spark of this.sparks) {
      if (spark.life > 0) {
        spark.life -= delta;
        spark.mesh.position.x += spark.vx * delta;
        spark.mesh.position.y += spark.vy * delta;
        spark.mesh.position.z += spark.vz * delta;
        spark.vy -= 18 * delta; // gravity
        const scale = spark.life / 0.35;
        spark.mesh.scale.set(scale, scale, scale);
        if (spark.life <= 0) {
          spark.mesh.visible = false;
        }
      }
    }
  }

  // -------------------------------------------------------------
  // Cleanup
  // -------------------------------------------------------------
  public dispose() {
    this.isRunning = false;
    cancelAnimationFrame(this.animationFrameId);
    this.unbindEvents();
    sounds.stopMusic();
    sounds.stopJetpackHum();
    if (this.renderer) {
      this.renderer.dispose();
      if (this.renderer.domElement.parentElement) {
        this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
      }
    }
  }
}
