import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { soundManager } from '../audio/soundManager';
import { BossTargetInfo, Enemy, FloatingDamage, FruitType, MinimapData, MinimapObjective, PlayerStats, Quest, WeaponType } from '../types/game';
import { ParticleManager } from './particles';
import {
  CharacterNodes,
  createBoatModel,
  createCharacterModel,
  createDevilFruitModel,
  createIslandEnvironment,
  createNPCModel,
} from './proceduralModels';
import { FRUITS, ISLANDS, QUESTS, WEAPONS } from './worldData';

export interface GameEngineCallbacks {
  onStatsUpdate: (stats: PlayerStats) => void;
  onQuestUpdate: (quest: Quest | null) => void;
  onFloatingDamage: (dmg: FloatingDamage) => void;
  onInteractPrompt: (prompt: string | null, action?: () => void) => void;
  onSkillCooldownUpdate: (cooldowns: Record<string, number>) => void;
  onLevelUpNotice: (level: number) => void;
  onMinimapUpdate: (data: MinimapData) => void;
  onBossTargetUpdate: (target: BossTargetInfo | null) => void;
}

export class GameEngine {
  private container: HTMLElement;
  private callbacks: GameEngineCallbacks;

  // Three.js core
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private clock = new THREE.Clock();
  private frameId = 0;
  private isSoftwareGl = false;

  // Particle System
  private particleManager!: ParticleManager;

  // Player
  private playerGroup = new THREE.Group();
  private playerNodes!: CharacterNodes;
  private playerVelocity = new THREE.Vector3();
  private playerYaw = 0;
  private cameraDistance = 8.5;
  private cameraPitch = 0.35;
  private isGrounded = true;
  private jumpCount = 0;
  private readonly maxJumps = 4; // Sky Leap / Geppo

  // Boat
  private currentBoat: THREE.Group | null = null;
  private isSailing = false;
  private boatSpeed = 0;
  private boatYaw = 0;

  // Water
  private waterMesh!: THREE.Mesh;

  // World Entities
  private enemies: Enemy[] = [];
  private worldFruits: Array<{ type: FruitType; mesh: THREE.Group; position: THREE.Vector3 }> = [];
  private npcs: Array<{ mesh: THREE.Group; role: 'quest' | 'fruit_dealer' | 'boat_dealer'; islandId: string; action: () => void }> = [];

  // Controls input
  private keys: Record<string, boolean> = {};
  private mouseLookActive = false;
  private previousMouseX = 0;
  private previousMouseY = 0;

  // Combat cooldowns & timers
  private attackCombo = 0;
  private lastAttackTime = 0;
  private attackCooldown = 0.35;
  private skillCooldowns: Record<string, number> = { Z: 0, X: 0, C: 0, V: 0, F: 0, Q: 0 };
  private skillMaxCooldowns: Record<string, number> = { Z: 2.5, X: 5.0, C: 7.0, V: 10.0, F: 1.0, Q: 3.0 };
  private observationCooldown = 0;
  private isFlying = false;
  private minimapTimer = 0;
  private engagedBoss: Enemy | null = null;
  private engagedBossTimer = 0;

  // State
  private stats: PlayerStats = {
    level: 1,
    exp: 0,
    maxExp: 100,
    beli: 5000,
    gems: 25,
    statPoints: 0,
    meleeStat: 1,
    defenseStat: 1,
    swordStat: 1,
    fruitStat: 1,
    maxHealth: 100,
    health: 100,
    maxEnergy: 100,
    energy: 100,
    equippedFruit: 'none',
    fruitMastery: 1,
    equippedWeapon: 'combat',
    hasHaki: true,
    hakiActive: false,
    observationActive: false,
    observationDodges: 3,
    maxObservationDodges: 3,
    isBuddhaTransformed: false,
    inventory: [
      { id: 'start_combat', type: 'weapon', itemKey: 'combat', name: 'Brawler Combat' },
    ],
  };

  private activeQuest: Quest | null = null;

  constructor(container: HTMLElement, callbacks: GameEngineCallbacks) {
    this.container = container;
    this.callbacks = callbacks;

    this.loadSavedData();
    this.detectSoftwareGl();
    this.initScene();
    this.setupLighting();
    this.setupEnvironment();
    this.setupPlayer();
    this.setupEnemies();
    this.setupEventListeners();

    this.recalculateDerivedStats();
    this.callbacks.onStatsUpdate({ ...this.stats });
    this.callbacks.onQuestUpdate(this.activeQuest);

    this.startLoop();
  }

  // Check Software WebGL renderer
  private detectSoftwareGl() {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
      if (!gl) {
        this.isSoftwareGl = true;
        return;
      }
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      this.isSoftwareGl = /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    } catch {
      this.isSoftwareGl = true;
    }
  }

  private initScene() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#38bdf8'); // Tropical anime sky
    this.scene.fog = new THREE.FogExp2('#38bdf8', 0.0035);

    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;

    this.camera = new THREE.PerspectiveCamera(65, width / height, 0.2, 1200);

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.innerHTML = '';
    this.container.appendChild(this.renderer.domElement);

    // Studio Environment map via RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    this.particleManager = new ParticleManager(this.scene);
  }

  private setupLighting() {
    // Warm Key Sun Light
    const sunLight = new THREE.DirectionalLight('#fff7ed', 1.8);
    sunLight.position.set(120, 180, 80);
    sunLight.castShadow = !this.isSoftwareGl;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 400;
    const d = 100;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.bias = -0.0005;
    this.scene.add(sunLight);

    // Cool Sky / Turquoise Water Fill
    const hemiLight = new THREE.HemisphereLight('#bae6fd', '#0284c7', 0.85);
    this.scene.add(hemiLight);
  }

  private setupEnvironment() {
    // Vast Ocean Surface
    const waterGeo = new THREE.PlaneGeometry(1600, 1600, 32, 32);
    const waterMat = new THREE.MeshStandardMaterial({
      color: '#0284c7',
      roughness: 0.15,
      metalness: 0.6,
      transparent: true,
      opacity: 0.88,
    });
    this.waterMesh = new THREE.Mesh(waterGeo, waterMat);
    this.waterMesh.rotation.x = -Math.PI / 2;
    this.waterMesh.position.y = 0;
    this.waterMesh.receiveShadow = true;
    this.scene.add(this.waterMesh);

    // Distant Sea floor for depth
    const seaFloorGeo = new THREE.PlaneGeometry(1800, 1800);
    const seaFloorMat = new THREE.MeshBasicMaterial({ color: '#0369a1' });
    const seaFloor = new THREE.Mesh(seaFloorGeo, seaFloorMat);
    seaFloor.rotation.x = -Math.PI / 2;
    seaFloor.position.y = -18;
    this.scene.add(seaFloor);

    // Islands
    ISLANDS.forEach((island) => {
      const islandMesh = createIslandEnvironment(island);
      this.scene.add(islandMesh);

      // Add NPCs on island
      this.setupIslandNPCs(island);
    });

    // Random fruit spawns under trees
    this.spawnWorldFruit('rubber', new THREE.Vector3(12, 5.2, -14));
    this.spawnWorldFruit('flame', new THREE.Vector3(-14, 5.2, 18));
    this.spawnWorldFruit('light', new THREE.Vector3(260, 5.2, 95));
    this.spawnWorldFruit('magma', new THREE.Vector3(-190, 5.2, -230));
  }

  private setupIslandNPCs(island: typeof ISLANDS[0]) {
    // 1. Quest Giver NPC
    const questData = QUESTS.find((q) => q.islandId === island.id);
    if (questData) {
      const questNpc = createNPCModel('quest', questData.npcName);
      questNpc.position.set(island.x + 8, 5.0, island.z + 12);
      this.scene.add(questNpc);
      this.npcs.push({
        mesh: questNpc,
        role: 'quest',
        islandId: island.id,
        action: () => this.handleQuestInteraction(questData),
      });
    }

    // 2. Fruit Dealer NPC
    if (island.hasFruitDealer) {
      const dealer = createNPCModel('fruit_dealer', 'Blox Fruit Dealer');
      dealer.position.set(island.x - 10, 5.0, island.z + 14);
      this.scene.add(dealer);
      this.npcs.push({
        mesh: dealer,
        role: 'fruit_dealer',
        islandId: island.id,
        action: () => (window as any).openFruitDealer?.(),
      });
    }

    // 3. Boat Dealer NPC at docks
    if (island.hasBoatDealer) {
      const boatNpc = createNPCModel('boat_dealer', 'Boat Builder Frank');
      boatNpc.position.set(island.x + 4, 5.0, island.z + island.radius - 4);
      this.scene.add(boatNpc);
      this.npcs.push({
        mesh: boatNpc,
        role: 'boat_dealer',
        islandId: island.id,
        action: () => this.spawnBoatAtDock(island),
      });
    }
  }

  private setupPlayer() {
    this.playerNodes = createCharacterModel({
      isPlayer: true,
      shirtColor: '#dc2626',
      pantsColor: '#0284c7',
      hatType: 'straw_hat',
      faceType: 'hero',
    });
    this.playerGroup.add(this.playerNodes.group);
    this.playerGroup.position.set(0, 5.0, 0); // Start on Starter Island
    this.scene.add(this.playerGroup);

    // Apply equipped weapon
    this.playerNodes.setWeapon(this.stats.equippedWeapon);
  }

  private setupEnemies() {
    // Starter Island Bandits
    for (let i = 0; i < 5; i++) {
      const offsetAngle = (i / 5) * Math.PI * 2;
      const x = Math.cos(offsetAngle) * 32;
      const z = Math.sin(offsetAngle) * 32;
      this.spawnEnemy({
        id: `bandit_${i}`,
        name: 'Island Bandit',
        type: 'bandit',
        level: 5,
        maxHealth: 140,
        health: 140,
        damage: 12,
        bounty: 500,
        expReward: 65,
        beliReward: 450,
        respawnTime: 6,
        spawnPoint: { x, y: 5.0, z },
        position: { x, y: 5.0, z },
        rotationY: Math.random() * Math.PI * 2,
        attackCooldown: 1.2,
        aggroRange: 18,
        attackRange: 2.4,
        state: 'idle',
      });
    }

    // Bandit Leader Boss Buggy
    this.spawnEnemy({
      id: 'bandit_leader_buggy',
      name: 'Bandit Leader Buggy',
      type: 'bandit_leader',
      level: 15,
      maxHealth: 850,
      health: 850,
      damage: 28,
      bounty: 10000,
      expReward: 850,
      beliReward: 3500,
      respawnTime: 14,
      isBoss: true,
      spawnPoint: { x: 0, y: 5.0, z: -40 },
      position: { x: 0, y: 5.0, z: -40 },
      rotationY: 0,
      attackCooldown: 1.5,
      aggroRange: 22,
      attackRange: 3.2,
      state: 'idle',
    });

    // Jungle Island Monkeys & Gorilla King
    for (let i = 0; i < 6; i++) {
      const x = 240 + (Math.random() - 0.5) * 45;
      const z = 80 + (Math.random() - 0.5) * 45;
      this.spawnEnemy({
        id: `monkey_${i}`,
        name: 'Jungle Ape',
        type: 'monkey',
        level: 25,
        maxHealth: 380,
        health: 380,
        damage: 32,
        bounty: 2500,
        expReward: 350,
        beliReward: 1800,
        respawnTime: 8,
        spawnPoint: { x, y: 5.0, z },
        position: { x, y: 5.0, z },
        rotationY: Math.random() * Math.PI * 2,
        attackCooldown: 1.2,
        aggroRange: 16,
        attackRange: 2.4,
        state: 'idle',
      });
    }

    // Gorilla King Boss
    this.spawnEnemy({
      id: 'gorilla_king',
      name: 'Gorilla King',
      type: 'gorilla_king',
      level: 40,
      maxHealth: 2200,
      health: 2200,
      damage: 55,
      bounty: 35000,
      expReward: 3200,
      beliReward: 12000,
      respawnTime: 18,
      isBoss: true,
      spawnPoint: { x: 240, y: 15.0, z: 80 },
      position: { x: 240, y: 15.0, z: 80 },
      rotationY: 0,
      attackCooldown: 1.6,
      aggroRange: 25,
      attackRange: 4.0,
      state: 'idle',
    });

    // Marine Citadel Officers & Vice Admiral Smokey
    for (let i = 0; i < 6; i++) {
      const x = 160 + (Math.random() - 0.5) * 40;
      const z = -260 + (Math.random() - 0.5) * 40;
      this.spawnEnemy({
        id: `marine_${i}`,
        name: 'Marine Soldier',
        type: 'marine_soldier',
        level: 95,
        maxHealth: 1200,
        health: 1200,
        damage: 85,
        bounty: 15000,
        expReward: 2200,
        beliReward: 8500,
        respawnTime: 8,
        spawnPoint: { x, y: 5.0, z },
        position: { x, y: 5.0, z },
        rotationY: Math.random() * Math.PI * 2,
        attackCooldown: 1.2,
        aggroRange: 18,
        attackRange: 2.8,
        state: 'idle',
      });
    }

    // Marine Vice Admiral
    this.spawnEnemy({
      id: 'vice_admiral_smokey',
      name: 'Vice Admiral Smokey',
      type: 'vice_admiral',
      level: 120,
      maxHealth: 5500,
      health: 5500,
      damage: 145,
      bounty: 95000,
      expReward: 12000,
      beliReward: 45000,
      respawnTime: 25,
      isBoss: true,
      spawnPoint: { x: 160, y: 18.0, z: -260 },
      position: { x: 160, y: 18.0, z: -260 },
      rotationY: 0,
      attackCooldown: 1.4,
      aggroRange: 28,
      attackRange: 4.5,
      state: 'idle',
    });
  }

  private spawnEnemy(enemy: Enemy) {
    const isMarine = enemy.type.includes('marine') || enemy.type.includes('admiral');
    const isBoss = !!enemy.isBoss;

    const charNodes = createCharacterModel({
      isPlayer: false,
      shirtColor: isMarine ? '#ffffff' : enemy.isBoss ? '#7f1d1d' : '#451a03',
      pantsColor: isMarine ? '#1e3a8a' : '#1c1917',
      hatType: isMarine ? 'marine_cap' : isBoss ? 'tricorn' : 'bandana',
      faceType: isMarine ? 'marine' : 'bandit',
    });

    if (isBoss) {
      charNodes.group.scale.set(1.5, 1.5, 1.5);
      charNodes.setWeapon('saber');
    } else {
      charNodes.setWeapon(isMarine ? 'katana' : 'combat');
    }

    charNodes.group.position.set(enemy.position.x, enemy.position.y, enemy.position.z);
    this.scene.add(charNodes.group);

    enemy.mesh = charNodes;
    this.enemies.push(enemy);
  }

  private spawnWorldFruit(type: FruitType, position: THREE.Vector3) {
    const fruitModel = createDevilFruitModel(type);
    fruitModel.position.copy(position);
    this.scene.add(fruitModel);
    this.worldFruits.push({ type, mesh: fruitModel, position });
  }

  // Handle Quests
  public handleQuestInteraction(quest: Quest) {
    if (this.stats.level < quest.minLevel) {
      this.callbacks.onInteractPrompt(`Requires Level ${quest.minLevel}! Current Level: ${this.stats.level}`);
      return;
    }

    if (this.activeQuest?.id === quest.id) {
      this.callbacks.onInteractPrompt(`Quest already active! Progress: ${quest.currentCount}/${quest.targetCount}`);
      return;
    }

    this.activeQuest = { ...quest, currentCount: 0, isActive: true };
    soundManager.playQuestComplete();
    this.callbacks.onQuestUpdate(this.activeQuest);
    this.callbacks.onInteractPrompt(`Accepted Quest: "${quest.title}"! Defeat ${quest.targetCount} ${quest.targetEnemyType}`);
  }

  // Boat Spawning
  public spawnBoatAtDock(island: typeof ISLANDS[0]) {
    if (this.currentBoat) {
      this.scene.remove(this.currentBoat);
      this.currentBoat = null;
    }

    const boat = createBoatModel();
    const spawnX = island.x;
    const spawnZ = island.z + island.radius + 18;
    boat.position.set(spawnX, 0.2, spawnZ);
    this.scene.add(boat);
    this.currentBoat = boat;

    soundManager.playQuestComplete();
    this.callbacks.onInteractPrompt('Pirate Sloop spawned! Press F near the boat to Board.');
  }

  // Toggle Board / Unboard Boat
  public toggleBoardBoat() {
    if (this.isSailing) {
      // Disembark
      this.isSailing = false;
      this.playerGroup.position.copy(this.currentBoat!.position);
      this.playerGroup.position.y = 5.0;
      this.playerGroup.visible = true;
      this.callbacks.onInteractPrompt('Disembarked from boat.');
      return;
    }

    if (!this.currentBoat) return;
    const dist = this.playerGroup.position.distanceTo(this.currentBoat.position);
    if (dist < 8.0) {
      this.isSailing = true;
      this.boatYaw = this.playerYaw;
      this.callbacks.onInteractPrompt('Sailing Boat! Steer with WASD. Press F to disembark.');
    }
  }

  // Player Attack (Click or Space/Action)
  public triggerAttack() {
    const now = performance.now() / 1000;
    if (now - this.lastAttackTime < this.attackCooldown) return;
    this.lastAttackTime = now;

    // Check weapon type
    const isSword = this.stats.equippedWeapon !== 'combat';
    if (isSword) {
      soundManager.playSwordSlash();
      this.particleManager.spawnSlashArc(
        this.playerGroup.position,
        this.playerYaw,
        this.stats.equippedWeapon === 'saber' ? '#ef4444' : '#38bdf8'
      );
    } else {
      soundManager.playPunch();
      this.particleManager.spawnHitSparks(this.playerGroup.position, '#f59e0b', 6);
    }

    // Animate arm swing
    this.attackCombo = (this.attackCombo + 1) % 3;
    const swingArm = this.attackCombo % 2 === 0 ? this.playerNodes.rightArm : this.playerNodes.leftArm;
    swingArm.rotation.x = -1.2;
    setTimeout(() => {
      swingArm.rotation.x = 0;
    }, 180);

    // Hit detection cone
    const attackReach = this.stats.isBuddhaTransformed ? 7.5 : isSword ? 4.2 : 3.2;
    const playerPos = this.playerGroup.position;
    const playerFwd = new THREE.Vector3(Math.sin(this.playerYaw), 0, Math.cos(this.playerYaw));

    let baseDamage = WEAPONS[this.stats.equippedWeapon]?.damage || 20;
    // Scale with stat
    if (isSword) {
      baseDamage += this.stats.swordStat * 3.5;
    } else {
      baseDamage += this.stats.meleeStat * 3.2;
    }
    // Haki boost
    if (this.stats.hakiActive) {
      baseDamage *= 1.35;
    }
    // Buddha reach & damage boost
    if (this.stats.isBuddhaTransformed) {
      baseDamage *= 1.4;
    }

    this.enemies.forEach((enemy) => {
      if (enemy.state === 'dead') return;
      const enemyPos = new THREE.Vector3(enemy.position.x, enemy.position.y, enemy.position.z);
      const toEnemy = enemyPos.clone().sub(playerPos);
      const dist = toEnemy.length();

      if (dist <= attackReach) {
        toEnemy.y = 0;
        toEnemy.normalize();
        const dot = playerFwd.dot(toEnemy);
        if (dot > 0.4) {
          // Hit!
          const isCrit = Math.random() < 0.25;
          const finalDamage = Math.round(baseDamage * (isCrit ? 1.75 : 1.0));
          this.damageEnemy(enemy, finalDamage, isCrit);

          if (isSword) soundManager.playSwordHit();
          else soundManager.playPunch();
        }
      }
    });
  }

  // Fruit Ability execution (Z, X, C, V, F)
  public triggerSkill(key: 'Z' | 'X' | 'C' | 'V' | 'F') {
    if (this.stats.equippedFruit === 'none') {
      this.callbacks.onInteractPrompt('No Fruit equipped! Roll or eat a Blox Fruit to unlock powers.');
      return;
    }

    const fruit = FRUITS[this.stats.equippedFruit];
    if (!fruit) return;

    const skill = fruit.skills.find((s) => s.key === key);
    if (!skill) return;

    if (this.stats.fruitMastery < skill.requiredMastery) {
      this.callbacks.onInteractPrompt(`Requires Fruit Mastery Lv. ${skill.requiredMastery}! Current: Lv. ${this.stats.fruitMastery}`);
      return;
    }

    if (this.skillCooldowns[key] > 0) return;

    if (this.stats.energy < skill.energyCost) {
      this.callbacks.onInteractPrompt('Not enough Energy!');
      return;
    }

    // Consume Energy
    this.stats.energy = Math.max(0, this.stats.energy - skill.energyCost);
    this.skillCooldowns[key] = skill.cooldown;
    this.skillMaxCooldowns[key] = skill.cooldown;
    this.callbacks.onSkillCooldownUpdate({ ...this.skillCooldowns });

    // Gain Fruit Mastery EXP
    this.gainFruitMastery(5);

    // Execute power visual & audio
    const pPos = this.playerGroup.position.clone();
    const pFwd = new THREE.Vector3(Math.sin(this.playerYaw), 0, Math.cos(this.playerYaw));

    if (this.stats.equippedFruit === 'flame') {
      soundManager.playFireSkill();
      if (key === 'Z') {
        // Fire Fist
        const impactPos = pPos.clone().add(pFwd.clone().multiplyScalar(12));
        this.particleManager.spawnFireExplosion(impactPos, 4.5);
        this.applyAoeDamage(impactPos, 6.0, skill.damageMultiplier);
      } else if (key === 'X') {
        // Flame Pillar
        const pillarPos = pPos.clone().add(pFwd.clone().multiplyScalar(6));
        this.particleManager.spawnFireExplosion(pillarPos, 8.0);
        this.applyAoeDamage(pillarPos, 8.0, skill.damageMultiplier);
      } else if (key === 'F') {
        // Flame Flight
        this.toggleFlight();
      } else if (key === 'V') {
        // Great Fire Emperor
        const centerPos = pPos.clone().add(pFwd.clone().multiplyScalar(14));
        this.particleManager.spawnFireExplosion(centerPos, 14.0);
        this.applyAoeDamage(centerPos, 14.0, skill.damageMultiplier);
      }
    } else if (this.stats.equippedFruit === 'light') {
      soundManager.playLightSkill();
      if (key === 'Z') {
        // Light Beam
        const beamEnd = pPos.clone().add(pFwd.clone().multiplyScalar(24));
        this.particleManager.spawnLightLaser(pPos.clone().add(new THREE.Vector3(0, 1.4, 0)), beamEnd);
        this.applyAoeDamage(beamEnd, 5.0, skill.damageMultiplier);
      } else if (key === 'X') {
        // Jewels of Light
        for (let i = 0; i < 5; i++) {
          const dropPos = pPos.clone().add(pFwd.clone().multiplyScalar(8 + i * 3)).add(new THREE.Vector3((Math.random() - 0.5) * 6, 0, (Math.random() - 0.5) * 6));
          this.particleManager.spawnLightLaser(dropPos.clone().add(new THREE.Vector3(0, 18, 0)), dropPos);
          this.applyAoeDamage(dropPos, 4.0, skill.damageMultiplier * 0.35);
        }
      } else if (key === 'F') {
        // Light Speed Warp
        this.triggerFlashStep();
      }
    } else if (this.stats.equippedFruit === 'ice') {
      soundManager.playIceSkill();
      if (key === 'Z' || key === 'X') {
        this.particleManager.spawnIceSurge(pPos, pFwd);
        this.applyAoeDamage(pPos.clone().add(pFwd.clone().multiplyScalar(8)), 7.0, skill.damageMultiplier);
      } else if (key === 'F') {
        // Ice Skating glide
        this.playerVelocity.add(pFwd.clone().multiplyScalar(18));
      }
    } else if (this.stats.equippedFruit === 'magma') {
      soundManager.playMagmaSkill();
      const impactPos = pPos.clone().add(pFwd.clone().multiplyScalar(10));
      this.particleManager.spawnFireExplosion(impactPos, 8.0);
      this.applyAoeDamage(impactPos, 9.0, skill.damageMultiplier);
    } else if (this.stats.equippedFruit === 'buddha') {
      if (key === 'V') {
        // Transform
        soundManager.playBuddhaTransform();
        this.stats.isBuddhaTransformed = !this.stats.isBuddhaTransformed;
        this.playerNodes.setBuddha(this.stats.isBuddhaTransformed);
        this.particleManager.spawnBuddhaShockwave(pPos);
        this.callbacks.onInteractPrompt(this.stats.isBuddhaTransformed ? 'Transformed into Golden Buddha!' : 'Returned to human form.');
      } else if (key === 'Z') {
        soundManager.playBuddhaTransform();
        this.particleManager.spawnBuddhaShockwave(pPos);
        this.applyAoeDamage(pPos, 12.0, skill.damageMultiplier);
      }
    } else if (this.stats.equippedFruit === 'rubber') {
      soundManager.playPunch();
      const reach = pPos.clone().add(pFwd.clone().multiplyScalar(10));
      this.particleManager.spawnHitSparks(reach, '#c084fc', 12);
      this.applyAoeDamage(reach, 6.0, skill.damageMultiplier);
    }

    this.callbacks.onStatsUpdate({ ...this.stats });
  }

  // Toggle Flame / Light flight
  private toggleFlight() {
    this.isFlying = !this.isFlying;
    this.callbacks.onInteractPrompt(this.isFlying ? 'Rocket Flight Active! Ascend with Space.' : 'Flight deactivated.');
  }

  // Soru / Flash Step (Q)
  public triggerFlashStep() {
    if (this.skillCooldowns['Q'] > 0) return;
    this.skillCooldowns['Q'] = 3.0;
    this.skillMaxCooldowns['Q'] = 3.0;

    soundManager.playFlashStep();
    const pFwd = new THREE.Vector3(Math.sin(this.playerYaw), 0, Math.cos(this.playerYaw));
    const startPos = this.playerGroup.position.clone();
    const targetPos = startPos.clone().add(pFwd.multiplyScalar(14));

    this.particleManager.spawnFlashStepStreak(startPos, targetPos);
    this.playerGroup.position.copy(targetPos);
  }

  // Haki Aura Toggle (J)
  public toggleHaki() {
    this.stats.hakiActive = !this.stats.hakiActive;
    soundManager.playHakiActivation();
    this.playerNodes.setHaki(this.stats.hakiActive);
    this.callbacks.onStatsUpdate({ ...this.stats });
    this.callbacks.onInteractPrompt(this.stats.hakiActive ? 'Busoshoku Haki (Aura) Active! +35% Damage.' : 'Aura Deactivated.');
  }

  // Observation Haki Toggle (E)
  public toggleObservation() {
    this.stats.observationActive = !this.stats.observationActive;
    soundManager.playHakiActivation();
    if (this.stats.observationActive) {
      this.stats.observationDodges = this.stats.maxObservationDodges;
    }
    this.callbacks.onStatsUpdate({ ...this.stats });
    this.callbacks.onInteractPrompt(this.stats.observationActive ? 'Kenbunshoku Haki Active! Auto-dodges next 3 attacks.' : 'Observation Deactivated.');
  }

  // AoE damage from fruit skills
  private applyAoeDamage(center: THREE.Vector3, radius: number, multiplier: number) {
    const rawDamage = (30 + this.stats.fruitStat * 4.2) * multiplier;
    this.enemies.forEach((enemy) => {
      if (enemy.state === 'dead') return;
      const enemyPos = new THREE.Vector3(enemy.position.x, enemy.position.y, enemy.position.z);
      const dist = enemyPos.distanceTo(center);
      if (dist <= radius) {
        const isCrit = Math.random() < 0.3;
        const dmg = Math.round(rawDamage * (isCrit ? 1.6 : 1.0));
        this.damageEnemy(enemy, dmg, isCrit);
      }
    });
  }

  // Damage an enemy & check death
  private damageEnemy(enemy: Enemy, damage: number, isCrit = false) {
    enemy.health = Math.max(0, enemy.health - damage);

    // Track as active targeted boss if boss or major enemy
    if (enemy.isBoss || enemy.maxHealth >= 400 || !this.engagedBoss) {
      this.engagedBoss = enemy;
      this.engagedBossTimer = 10.0;
    }

    // Floating text
    const enemyHeight = enemy.isBoss ? 2.8 : 2.0;
    this.callbacks.onFloatingDamage({
      id: Math.random().toString(),
      text: isCrit ? `-${damage} CRIT!` : `-${damage}`,
      x: enemy.position.x + (Math.random() - 0.5) * 0.6,
      y: enemy.position.y + enemyHeight,
      z: enemy.position.z + (Math.random() - 0.5) * 0.6,
      vy: isCrit ? 2.2 : 1.6,
      opacity: 1,
      color: isCrit ? '#ef4444' : '#facc15',
      isCrit,
      type: 'outgoing',
      createdAt: performance.now(),
    });

    if (enemy.health <= 0) {
      this.killEnemy(enemy);
    } else {
      enemy.state = 'chase';
    }
  }

  private killEnemy(enemy: Enemy) {
    enemy.state = 'dead';
    enemy.deadTimer = enemy.respawnTime;
    if (enemy.mesh?.group) {
      enemy.mesh.group.visible = false;
    }

    if (this.engagedBoss?.id === enemy.id) {
      this.engagedBossTimer = 2.5; // keep visible as 0 HP / DEFEATED for 2.5s
    }

    soundManager.playQuestComplete();
    this.particleManager.spawnHitSparks(new THREE.Vector3(enemy.position.x, enemy.position.y, enemy.position.z), '#facc15', 18);

    // Reward Exp & Beli
    this.stats.beli += enemy.beliReward;
    this.gainExp(enemy.expReward);

    // Check Quest
    if (this.activeQuest && this.activeQuest.targetEnemyType === enemy.type) {
      this.activeQuest.currentCount++;
      if (this.activeQuest.currentCount >= this.activeQuest.targetCount) {
        // Complete Quest!
        this.completeActiveQuest();
      } else {
        this.callbacks.onQuestUpdate(this.activeQuest);
      }
    }

    this.callbacks.onStatsUpdate({ ...this.stats });
    this.saveData();
  }

  private completeActiveQuest() {
    if (!this.activeQuest) return;
    soundManager.playQuestComplete();
    this.stats.beli += this.activeQuest.rewardBeli;
    this.gainExp(this.activeQuest.rewardExp);

    this.callbacks.onInteractPrompt(`Quest Completed! Earned +${this.activeQuest.rewardBeli.toLocaleString()} Beli and +${this.activeQuest.rewardExp.toLocaleString()} EXP!`);
    this.activeQuest = null;
    this.callbacks.onQuestUpdate(null);
  }

  public gainExp(amount: number) {
    this.stats.exp += amount;
    while (this.stats.exp >= this.stats.maxExp) {
      this.stats.exp -= this.stats.maxExp;
      this.stats.level++;
      this.stats.statPoints += 3;
      this.stats.maxExp = Math.round(this.stats.maxExp * 1.35);

      soundManager.playLevelUp();
      this.callbacks.onLevelUpNotice(this.stats.level);
    }
    this.recalculateDerivedStats();
    this.callbacks.onStatsUpdate({ ...this.stats });
  }

  public gainFruitMastery(amount: number) {
    this.stats.fruitMastery += amount;
    this.callbacks.onStatsUpdate({ ...this.stats });
  }

  public allocateStat(statKey: 'melee' | 'defense' | 'sword' | 'fruit', points = 1) {
    if (this.stats.statPoints < points) return;
    this.stats.statPoints -= points;

    if (statKey === 'melee') this.stats.meleeStat += points;
    else if (statKey === 'defense') this.stats.defenseStat += points;
    else if (statKey === 'sword') this.stats.swordStat += points;
    else if (statKey === 'fruit') this.stats.fruitStat += points;

    this.recalculateDerivedStats();
    this.callbacks.onStatsUpdate({ ...this.stats });
    this.saveData();
  }

  private recalculateDerivedStats() {
    this.stats.maxHealth = 100 + this.stats.defenseStat * 25;
    this.stats.maxEnergy = 100 + this.stats.meleeStat * 20;
    this.stats.health = Math.min(this.stats.health, this.stats.maxHealth);
    this.stats.energy = Math.min(this.stats.energy, this.stats.maxEnergy);
  }

  // Eat fruit from inventory
  public eatFruit(fruitType: FruitType) {
    this.stats.equippedFruit = fruitType;
    this.stats.fruitMastery = 1;
    soundManager.playFruitEat();
    this.callbacks.onStatsUpdate({ ...this.stats });
    this.callbacks.onInteractPrompt(`Ate the ${FRUITS[fruitType]?.name || fruitType}! Powers Unlocked.`);
    this.saveData();
  }

  // Equip weapon
  public equipWeapon(weapon: WeaponType) {
    this.stats.equippedWeapon = weapon;
    this.playerNodes.setWeapon(weapon);
    this.callbacks.onStatsUpdate({ ...this.stats });
    this.saveData();
  }

  // Spin Random Fruit at Dealer
  public spinFruit(): FruitType | null {
    const cost = 25000;
    if (this.stats.beli < cost) {
      this.callbacks.onInteractPrompt(`Need at least 25,000 Beli to spin! You have ${this.stats.beli.toLocaleString()} Beli.`);
      return null;
    }

    this.stats.beli -= cost;
    soundManager.playGachaTick();

    const pool: FruitType[] = ['rubber', 'rubber', 'flame', 'ice', 'light', 'magma', 'buddha'];
    const chosen = pool[Math.floor(Math.random() * pool.length)];

    // Add to inventory
    const fruitData = FRUITS[chosen];
    this.stats.inventory.push({
      id: Math.random().toString(),
      type: 'fruit',
      itemKey: chosen,
      name: fruitData?.name || chosen,
      rarity: fruitData?.rarity,
    });

    this.callbacks.onStatsUpdate({ ...this.stats });
    this.saveData();
    return chosen;
  }

  // Main Loop
  private startLoop() {
    const tick = () => {
      const delta = Math.min(this.clock.getDelta(), 0.1);

      this.updatePlayerMovement(delta);
      this.updateBoat(delta);
      this.updateCamera();
      this.updateEnemies(delta);
      this.updateCooldowns(delta);
      this.updateInteractions();
      this.updateMinimap(delta);
      this.particleManager.update(delta);

      // Animate ocean waves slightly
      if (this.waterMesh) {
        this.waterMesh.rotation.z += delta * 0.02;
      }

      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        this.afterDraw(tick);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    tick();
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 60);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private updatePlayerMovement(delta: number) {
    if (this.isSailing) {
      this.playerGroup.position.copy(this.currentBoat!.position);
      return;
    }

    let moveX = 0;
    let moveZ = 0;

    if (this.keys['KeyW'] || this.keys['ArrowUp']) moveZ += 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) moveZ -= 1;
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) moveX += 1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) moveX -= 1;

    const isMoving = moveX !== 0 || moveZ !== 0;

    if (isMoving) {
      // Calculate world movement vector relative to camera yaw
      const inputAngle = Math.atan2(moveX, moveZ);
      const moveAngle = this.playerYaw + inputAngle;
      const speed = this.isFlying ? 28 : this.stats.isBuddhaTransformed ? 12 : 16;

      this.playerVelocity.x = Math.sin(moveAngle) * speed;
      this.playerVelocity.z = Math.cos(moveAngle) * speed;

      // Animate legs and arms walking
      const walkCycle = Math.sin(performance.now() * 0.012);
      this.playerNodes.leftLeg.rotation.x = walkCycle * 0.6;
      this.playerNodes.rightLeg.rotation.x = -walkCycle * 0.6;
      this.playerNodes.leftArm.rotation.x = -walkCycle * 0.5;
      this.playerNodes.rightArm.rotation.x = walkCycle * 0.5;
    } else {
      this.playerVelocity.x *= 0.8;
      this.playerVelocity.z *= 0.8;
      this.playerNodes.leftLeg.rotation.x = 0;
      this.playerNodes.rightLeg.rotation.x = 0;
      this.playerNodes.leftArm.rotation.x = 0;
      this.playerNodes.rightArm.rotation.x = 0;
    }

    // Flight vs Gravity
    if (this.isFlying) {
      if (this.keys['Space']) {
        this.playerVelocity.y = 12;
      } else if (this.keys['ShiftLeft']) {
        this.playerVelocity.y = -8;
      } else {
        this.playerVelocity.y = 0;
      }
    } else {
      // Gravity
      this.playerVelocity.y -= 32 * delta;
    }

    // Apply movement
    this.playerGroup.position.x += this.playerVelocity.x * delta;
    this.playerGroup.position.y += this.playerVelocity.y * delta;
    this.playerGroup.position.z += this.playerVelocity.z * delta;

    // Ground collision height
    const groundY = this.getGroundHeight(this.playerGroup.position.x, this.playerGroup.position.z);

    if (this.playerGroup.position.y <= groundY) {
      this.playerGroup.position.y = groundY;
      this.playerVelocity.y = 0;
      this.isGrounded = true;
      this.jumpCount = 0;

      // Devil fruit water damage check
      if (groundY <= 0.2 && this.stats.equippedFruit !== 'none' && this.stats.equippedFruit !== 'ice') {
        this.takeDamage(15 * delta, 'Drowning in Sea Water!');
      }
    } else {
      this.isGrounded = false;
    }

    // Regenerate Health & Energy slowly
    this.stats.health = Math.min(this.stats.maxHealth, this.stats.health + 2.5 * delta);
    this.stats.energy = Math.min(this.stats.maxEnergy, this.stats.energy + 8.0 * delta);

    // Orient character model to look forward
    this.playerGroup.rotation.y = this.playerYaw;
  }

  // Jump / Sky Leap (Geppo)
  public triggerJump() {
    if (this.isFlying) return;

    if (this.jumpCount < this.maxJumps) {
      this.jumpCount++;
      this.playerVelocity.y = 14;
      soundManager.playSkyJump();
      this.particleManager.spawnSkyJumpPuff(this.playerGroup.position);
    }
  }

  private updateBoat(delta: number) {
    if (!this.currentBoat || !this.isSailing) return;

    let throttle = 0;
    let steer = 0;

    if (this.keys['KeyW'] || this.keys['ArrowUp']) throttle += 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) throttle -= 0.5;
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) steer += 1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) steer -= 1;

    this.boatYaw += steer * 1.5 * delta;
    this.boatSpeed = THREE.MathUtils.damp(this.boatSpeed, throttle * 22, 2.5, delta);

    this.currentBoat.rotation.y = this.boatYaw;
    this.currentBoat.position.x += Math.sin(this.boatYaw) * this.boatSpeed * delta;
    this.currentBoat.position.z += Math.cos(this.boatYaw) * this.boatSpeed * delta;

    // Rocking boat animation on waves
    this.currentBoat.rotation.z = Math.sin(performance.now() * 0.003) * 0.04;
    this.currentBoat.position.y = 0.2 + Math.sin(performance.now() * 0.004) * 0.15;

    if (Math.abs(this.boatSpeed) > 2) {
      this.particleManager.spawnWaterSplash(this.currentBoat.position);
    }
  }

  private updateCamera() {
    const targetPos = this.isSailing && this.currentBoat
      ? this.currentBoat.position.clone()
      : this.playerGroup.position.clone();

    // Buddha height compensation
    const cameraTargetHeight = this.stats.isBuddhaTransformed ? 3.5 : 1.6;
    targetPos.y += cameraTargetHeight;

    const dist = this.stats.isBuddhaTransformed ? this.cameraDistance * 1.6 : this.cameraDistance;

    const camX = targetPos.x - Math.sin(this.playerYaw) * Math.cos(this.cameraPitch) * dist;
    const camY = targetPos.y + Math.sin(this.cameraPitch) * dist;
    const camZ = targetPos.z - Math.cos(this.playerYaw) * Math.cos(this.cameraPitch) * dist;

    this.camera.position.set(camX, camY, camZ);
    this.camera.lookAt(targetPos);
  }

  private updateEnemies(delta: number) {
    const pPos = this.playerGroup.position;

    this.enemies.forEach((enemy) => {
      if (enemy.state === 'dead') {
        if (enemy.deadTimer !== undefined) {
          enemy.deadTimer -= delta;
          if (enemy.deadTimer <= 0) {
            // Respawn
            enemy.state = 'idle';
            enemy.health = enemy.maxHealth;
            enemy.position.x = enemy.spawnPoint.x;
            enemy.position.y = enemy.spawnPoint.y;
            enemy.position.z = enemy.spawnPoint.z;
            if (enemy.mesh?.group) {
              enemy.mesh.group.position.set(enemy.position.x, enemy.position.y, enemy.position.z);
              enemy.mesh.group.visible = true;
            }
          }
        }
        return;
      }

      const ePos = new THREE.Vector3(enemy.position.x, enemy.position.y, enemy.position.z);
      const toPlayer = pPos.clone().sub(ePos);
      const dist = toPlayer.length();

      if (dist <= enemy.aggroRange) {
        enemy.state = 'chase';
        enemy.rotationY = Math.atan2(toPlayer.x, toPlayer.z);

        if (enemy.isBoss && (!this.engagedBoss || this.engagedBoss.state === 'dead')) {
          this.engagedBoss = enemy;
          this.engagedBossTimer = 7.0;
        }

        if (dist > enemy.attackRange) {
          // Walk toward player
          toPlayer.y = 0;
          toPlayer.normalize();
          const speed = enemy.isBoss ? 8 : 6;
          enemy.position.x += toPlayer.x * speed * delta;
          enemy.position.z += toPlayer.z * speed * delta;
          enemy.position.y = this.getGroundHeight(enemy.position.x, enemy.position.z);
        } else {
          // In attack range!
          enemy.attackCooldown -= delta;
          if (enemy.attackCooldown <= 0) {
            enemy.attackCooldown = 1.4;
            this.enemyAttackPlayer(enemy);
          }
        }
      } else {
        enemy.state = 'idle';
      }

      if (enemy.mesh?.group) {
        enemy.mesh.group.position.set(enemy.position.x, enemy.position.y, enemy.position.z);
        enemy.mesh.group.rotation.y = enemy.rotationY;
      }
    });
  }

  private enemyAttackPlayer(enemy: Enemy) {
    // Check Observation Haki dodge
    if (this.stats.observationActive && this.stats.observationDodges > 0) {
      this.stats.observationDodges--;
      soundManager.playFlashStep();
      this.callbacks.onFloatingDamage({
        id: Math.random().toString(),
        text: 'DODGE!',
        x: this.playerGroup.position.x,
        y: this.playerGroup.position.y + 2.2,
        z: this.playerGroup.position.z,
        vy: 1.8,
        opacity: 1,
        color: '#38bdf8',
        isCrit: false,
        type: 'dodge',
        createdAt: performance.now(),
      });
      if (this.stats.observationDodges <= 0) {
        this.stats.observationActive = false;
        this.callbacks.onInteractPrompt('Observation Haki exhausted!');
      }
      this.callbacks.onStatsUpdate({ ...this.stats });
      return;
    }

    let dmg = enemy.damage;
    // Buddha defense reduction
    if (this.stats.isBuddhaTransformed) {
      dmg *= 0.5;
    }

    this.takeDamage(dmg, `${enemy.name}'s attack`);
  }

  private takeDamage(amount: number, reason = 'Damage') {
    const rounded = Math.round(amount);
    if (rounded <= 0) return;

    this.stats.health = Math.max(0, this.stats.health - amount);
    soundManager.playPunch();

    // Floating text for INCOMING damage on player
    this.callbacks.onFloatingDamage({
      id: Math.random().toString(),
      text: `-${rounded}`,
      x: this.playerGroup.position.x + (Math.random() - 0.5) * 0.5,
      y: this.playerGroup.position.y + (this.stats.isBuddhaTransformed ? 4.2 : 2.2),
      z: this.playerGroup.position.z + (Math.random() - 0.5) * 0.5,
      vy: 1.6,
      opacity: 1,
      color: '#f87171',
      isCrit: false,
      type: 'incoming',
      createdAt: performance.now(),
    });

    if (this.stats.health <= 0) {
      // Respawn at Starter Island
      this.callbacks.onInteractPrompt(`You were defeated by ${reason}! Respawning at Starter Island...`);
      this.playerGroup.position.set(0, 5.0, 0);
      this.stats.health = this.stats.maxHealth;
      this.stats.energy = this.stats.maxEnergy;
      this.isFlying = false;
    }

    this.callbacks.onStatsUpdate({ ...this.stats });
  }

  private updateCooldowns(delta: number) {
    let changed = false;
    Object.keys(this.skillCooldowns).forEach((k) => {
      if (this.skillCooldowns[k] > 0) {
        this.skillCooldowns[k] = Math.max(0, this.skillCooldowns[k] - delta);
        changed = true;
      }
    });
    if (changed) {
      this.callbacks.onSkillCooldownUpdate({ ...this.skillCooldowns });
    }
  }

  private updateInteractions() {
    const pPos = this.playerGroup.position;
    let foundPrompt = false;

    // 1. Check World Fruits on ground
    for (let i = this.worldFruits.length - 1; i >= 0; i--) {
      const f = this.worldFruits[i];
      f.mesh.rotation.y += 0.02;
      const dist = pPos.distanceTo(f.position);
      if (dist < 3.2) {
        foundPrompt = true;
        const fruitInfo = FRUITS[f.type];
        this.callbacks.onInteractPrompt(`Press [E] to Pick Up ${fruitInfo?.name || f.type}!`, () => {
          this.stats.inventory.push({
            id: Math.random().toString(),
            type: 'fruit',
            itemKey: f.type,
            name: fruitInfo?.name || f.type,
            rarity: fruitInfo?.rarity,
          });
          this.scene.remove(f.mesh);
          this.worldFruits.splice(i, 1);
          soundManager.playQuestComplete();
          this.callbacks.onStatsUpdate({ ...this.stats });
          this.saveData();
        });
        break;
      }
    }

    if (foundPrompt) return;

    // 2. Check NPCs
    for (const npc of this.npcs) {
      const dist = pPos.distanceTo(npc.mesh.position);
      if (dist < 4.5) {
        foundPrompt = true;
        const roleLabel = npc.role === 'quest' ? 'Talk to Quest Giver' : npc.role === 'fruit_dealer' ? 'Open Fruit Dealer' : 'Spawn Boat';
        this.callbacks.onInteractPrompt(`Press [E] to ${roleLabel}`, npc.action);
        break;
      }
    }

    if (foundPrompt) return;

    // 3. Check Boat Boarding
    if (this.currentBoat) {
      const dist = pPos.distanceTo(this.currentBoat.position);
      if (dist < 7.0 && !this.isSailing) {
        foundPrompt = true;
        this.callbacks.onInteractPrompt('Press [F] to Board Boat', () => this.toggleBoardBoat());
      }
    }

    if (!foundPrompt) {
      this.callbacks.onInteractPrompt(null);
    }
  }

  private updateMinimap(delta: number) {
    this.minimapTimer += delta;
    if (this.minimapTimer < 0.04) return;
    this.minimapTimer = 0;

    const px = this.playerGroup.position.x;
    const py = this.playerGroup.position.y;
    const pz = this.playerGroup.position.z;

    // Detect current island
    let currentIsland: typeof ISLANDS[0] | null = null;
    for (const island of ISLANDS) {
      const dx = px - island.x;
      const dz = pz - island.z;
      if (Math.sqrt(dx * dx + dz * dz) <= island.radius + 15) {
        currentIsland = island;
        break;
      }
    }

    // Active quest target position
    let questObjective: MinimapObjective | null = null;
    if (this.activeQuest) {
      // Find matching enemy or island
      const enemy = this.enemies.find((e) => e.type === this.activeQuest!.targetEnemyType && e.state !== 'dead')
        || this.enemies.find((e) => e.type === this.activeQuest!.targetEnemyType);

      if (enemy) {
        const dx = enemy.position.x - px;
        const dz = enemy.position.z - pz;
        const dist = Math.round(Math.sqrt(dx * dx + dz * dz));
        questObjective = {
          title: this.activeQuest.title,
          targetType: this.activeQuest.targetEnemyType,
          x: enemy.position.x,
          z: enemy.position.z,
          distance: dist,
        };
      } else {
        const questIsland = ISLANDS.find((i) => i.id === this.activeQuest!.islandId);
        if (questIsland) {
          const dx = questIsland.x - px;
          const dz = questIsland.z - pz;
          questObjective = {
            title: this.activeQuest.title,
            targetType: this.activeQuest.targetEnemyType,
            x: questIsland.x,
            z: questIsland.z,
            distance: Math.round(Math.sqrt(dx * dx + dz * dz)),
          };
        }
      }
    }

    const enemyList = this.enemies.map((e) => ({
      id: e.id,
      x: e.position.x,
      z: e.position.z,
      isBoss: !!e.isBoss,
      isDead: e.state === 'dead',
    }));

    const boatPos = this.currentBoat
      ? { x: this.currentBoat.position.x, z: this.currentBoat.position.z }
      : null;

    this.callbacks.onMinimapUpdate({
      playerPos: { x: px, y: py, z: pz },
      playerYaw: this.playerYaw,
      currentIsland,
      questObjective,
      enemies: enemyList,
      boatPos,
    });

    // Update Boss / Targeted Enemy Health Bar
    if (this.engagedBoss) {
      this.engagedBossTimer -= delta;
      const dx = this.engagedBoss.position.x - px;
      const dz = this.engagedBoss.position.z - pz;
      const dist = Math.sqrt(dx * dx + dz * dz);

      if (dist > 45 || this.engagedBossTimer <= 0) {
        this.engagedBoss = null;
        this.callbacks.onBossTargetUpdate(null);
      } else {
        const bossIsland = ISLANDS.find((i) => {
          const idx = this.engagedBoss!.position.x - i.x;
          const idz = this.engagedBoss!.position.z - i.z;
          return Math.sqrt(idx * idx + idz * idz) <= i.radius + 15;
        });

        this.callbacks.onBossTargetUpdate({
          id: this.engagedBoss.id,
          name: this.engagedBoss.name,
          type: this.engagedBoss.type,
          level: this.engagedBoss.level,
          health: Math.max(0, this.engagedBoss.health),
          maxHealth: this.engagedBoss.maxHealth,
          isBoss: !!this.engagedBoss.isBoss,
          distance: dist,
          islandName: bossIsland?.name,
        });
      }
    } else {
      this.callbacks.onBossTargetUpdate(null);
    }
  }

  private getGroundHeight(x: number, z: number): number {
    for (const island of ISLANDS) {
      const dx = x - island.x;
      const dz = z - island.z;
      const dist = Math.sqrt(dx * dx + dz * dz);

      if (dist <= island.radius) {
        // Height profile on island: higher in center, sandy slope near edge
        const centerFactor = 1.0 - dist / island.radius;
        let baseHeight = 5.0 + centerFactor * 3.5;
        if (island.id === 'volcano_island') baseHeight = 6.0 + centerFactor * 14.0;
        return baseHeight;
      }
    }
    return 0.1; // Ocean water level
  }

  private setupEventListeners() {
    window.addEventListener('keydown', (e) => {
      this.keys[e.code] = true;

      if (e.code === 'KeyQ') this.triggerFlashStep();
      if (e.code === 'KeyJ') this.toggleHaki();
      if (e.code === 'KeyE') {
        // Interaction action or observation haki
        this.toggleObservation();
      }
      if (e.code === 'Space') this.triggerJump();

      // Skills
      if (e.code === 'KeyZ') this.triggerSkill('Z');
      if (e.code === 'KeyX') this.triggerSkill('X');
      if (e.code === 'KeyC') this.triggerSkill('C');
      if (e.code === 'KeyV') this.triggerSkill('V');
      if (e.code === 'KeyF') {
        if (this.isSailing || (this.currentBoat && this.playerGroup.position.distanceTo(this.currentBoat.position) < 7)) {
          this.toggleBoardBoat();
        } else {
          this.triggerSkill('F');
        }
      }
    });

    window.addEventListener('keyup', (e) => {
      this.keys[e.code] = false;
    });

    // Pointer rotation controls
    const dom = this.renderer.domElement;
    dom.addEventListener('mousedown', (e) => {
      if (e.button === 0) {
        // Left click = attack!
        this.triggerAttack();
      }
      if (e.button === 2) {
        // Right click = rotate camera
        this.mouseLookActive = true;
        this.previousMouseX = e.clientX;
        this.previousMouseY = e.clientY;
      }
    });

    window.addEventListener('mouseup', (e) => {
      if (e.button === 2) {
        this.mouseLookActive = false;
      }
    });

    window.addEventListener('contextmenu', (e) => e.preventDefault());

    window.addEventListener('mousemove', (e) => {
      if (!this.mouseLookActive) return;
      const deltaX = e.clientX - this.previousMouseX;
      const deltaY = e.clientY - this.previousMouseY;
      this.previousMouseX = e.clientX;
      this.previousMouseY = e.clientY;

      this.playerYaw += deltaX * 0.005;
      this.cameraPitch = THREE.MathUtils.clamp(this.cameraPitch + deltaY * 0.005, -0.2, 1.1);
    });

    // Wheel zoom
    dom.addEventListener('wheel', (e) => {
      this.cameraDistance = THREE.MathUtils.clamp(this.cameraDistance + e.deltaY * 0.01, 3.5, 20);
    });

    // Touch controls for mobile & Android phones (swipe to rotate camera, pinch to zoom, tap to attack)
    let touchStartDist = 0;
    let lastTouchX = 0;
    let lastTouchY = 0;
    let isTouchDragging = false;
    let touchStartTime = 0;
    let touchMoved = false;

    dom.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) {
        isTouchDragging = true;
        touchMoved = false;
        lastTouchX = e.touches[0].clientX;
        lastTouchY = e.touches[0].clientY;
        touchStartTime = performance.now();
      } else if (e.touches.length === 2) {
        isTouchDragging = false;
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        touchStartDist = Math.sqrt(dx * dx + dy * dy);
      }
    }, { passive: true });

    dom.addEventListener('touchmove', (e) => {
      if (e.touches.length === 1 && isTouchDragging) {
        const deltaX = e.touches[0].clientX - lastTouchX;
        const deltaY = e.touches[0].clientY - lastTouchY;
        lastTouchX = e.touches[0].clientX;
        lastTouchY = e.touches[0].clientY;

        if (Math.abs(deltaX) > 2 || Math.abs(deltaY) > 2) {
          touchMoved = true;
        }

        this.playerYaw += deltaX * 0.006;
        this.cameraPitch = THREE.MathUtils.clamp(this.cameraPitch + deltaY * 0.005, -0.2, 1.1);
      } else if (e.touches.length === 2) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const currentDist = Math.sqrt(dx * dx + dy * dy);
        const diff = touchStartDist - currentDist;
        this.cameraDistance = THREE.MathUtils.clamp(this.cameraDistance + diff * 0.03, 3.5, 20);
        touchStartDist = currentDist;
      }
    }, { passive: true });

    dom.addEventListener('touchend', () => {
      if (isTouchDragging && !touchMoved && performance.now() - touchStartTime < 250) {
        // Quick tap without drag on Android phone = Attack!
        this.triggerAttack();
      }
      isTouchDragging = false;
    });

    // Resize
    window.addEventListener('resize', () => {
      const w = this.container.clientWidth || window.innerWidth;
      const h = this.container.clientHeight || window.innerHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });
  }

  // Touch Virtual Joystick input
  public setVirtualMovement(moveX: number, moveZ: number) {
    this.keys['KeyA'] = moveX < -0.3;
    this.keys['KeyD'] = moveX > 0.3;
    this.keys['KeyW'] = moveZ > 0.3;
    this.keys['KeyS'] = moveZ < -0.3;
  }

  public rotateCameraBy(deltaYaw: number, deltaPitch: number) {
    this.playerYaw += deltaYaw;
    this.cameraPitch = THREE.MathUtils.clamp(this.cameraPitch + deltaPitch, -0.2, 1.1);
  }

  // Save / Load system
  private saveData() {
    try {
      const data = {
        level: this.stats.level,
        exp: this.stats.exp,
        maxExp: this.stats.maxExp,
        beli: this.stats.beli,
        gems: this.stats.gems,
        statPoints: this.stats.statPoints,
        meleeStat: this.stats.meleeStat,
        defenseStat: this.stats.defenseStat,
        swordStat: this.stats.swordStat,
        fruitStat: this.stats.fruitStat,
        equippedFruit: this.stats.equippedFruit,
        fruitMastery: this.stats.fruitMastery,
        equippedWeapon: this.stats.equippedWeapon,
        inventory: this.stats.inventory,
      };
      localStorage.setItem('blox_fruits_3d_save', JSON.stringify(data));
    } catch {
      // Storage unavailable fallback
    }
  }

  private loadSavedData() {
    try {
      const raw = localStorage.getItem('blox_fruits_3d_save');
      if (raw) {
        const loaded = JSON.parse(raw);
        this.stats = { ...this.stats, ...loaded };
      }
    } catch {
      // defaults
    }
  }

  public getStats(): PlayerStats {
    return this.stats;
  }

  public getActiveQuest(): Quest | null {
    return this.activeQuest;
  }

  public projectToScreen(x: number, y: number, z: number): { x: number; y: number; visible: boolean } {
    if (!this.camera || !this.container) return { x: 0, y: 0, visible: false };
    const v = new THREE.Vector3(x, y, z);
    v.project(this.camera);

    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;

    const screenX = (v.x * 0.5 + 0.5) * width;
    const screenY = (-(v.y * 0.5) + 0.5) * height;

    const visible = v.z < 1.0 && screenX >= -80 && screenX <= width + 80 && screenY >= -80 && screenY <= height + 80;
    return { x: screenX, y: screenY, visible };
  }

  public dispose() {
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    this.particleManager.clear();
    this.renderer.dispose();
  }
}
