import * as THREE from 'three';
import { MAP_RADIUS, ZONE_PHASES } from './constants';

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/** The shrinking blue safe zone. Stage -1 = initial wait, stage k = radius of phase k reached. */
export class Zone {
  readonly group = new THREE.Group();
  cx = 0;
  cz = 0;
  r = MAP_RADIUS;
  stage = -1;
  shrinking = false;
  private t = ZONE_PHASES[0].wait;
  private dur = 1;
  private fromR = MAP_RADIUS;
  private toR = MAP_RADIUS;
  private fromX = 0;
  private fromZ = 0;
  private toX = 0;
  private toZ = 0;
  private wall: THREE.Mesh;
  private ring: THREE.Mesh;

  constructor() {
    this.wall = new THREE.Mesh(
      new THREE.CylinderGeometry(1, 1, 80, 96, 1, true),
      new THREE.MeshBasicMaterial({ color: 0x3aa0ff, transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false }),
    );
    this.ring = new THREE.Mesh(
      new THREE.RingGeometry(0.985, 1, 160),
      new THREE.MeshBasicMaterial({ color: 0x9ad8ff, transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false }),
    );
    this.ring.rotation.x = -Math.PI / 2;
    this.group.add(this.wall, this.ring);
    this.apply();
  }

  get timeLeft(): number {
    if (this.shrinking) return Math.max(0, this.dur - this.t);
    return Math.max(0, this.t);
  }

  get dps(): number {
    return this.stage >= 0 ? ZONE_PHASES[this.stage].dps : 0;
  }

  contains(x: number, z: number, margin = 0): boolean {
    return Math.hypot(x - this.cx, z - this.cz) <= this.r - margin;
  }

  update(dt: number) {
    if (!this.shrinking) {
      if (this.stage + 1 >= ZONE_PHASES.length) return;
      this.t -= dt;
      if (this.t <= 0) this.startShrink();
    } else {
      this.t += dt;
      const k = Math.min(1, this.t / this.dur);
      const e = k * k * (3 - 2 * k);
      this.r = lerp(this.fromR, this.toR, e);
      this.cx = lerp(this.fromX, this.toX, e);
      this.cz = lerp(this.fromZ, this.toZ, e);
      if (k >= 1) {
        this.shrinking = false;
        this.stage++;
        this.t = ZONE_PHASES[this.stage + 1]?.wait ?? Infinity;
      }
    }
    this.apply();
  }

  private startShrink() {
    const next = ZONE_PHASES[this.stage + 1];
    this.shrinking = true;
    this.t = 0;
    this.dur = next.shrink;
    this.fromR = this.r;
    this.toR = next.radius;
    this.fromX = this.cx;
    this.fromZ = this.cz;
    // New centre drifts randomly, but stays inside the smaller circle.
    const a = Math.random() * Math.PI * 2;
    const off = Math.sqrt(Math.random()) * Math.max(0, this.fromR - this.toR) * 0.8;
    this.toX = this.cx + Math.cos(a) * off;
    this.toZ = this.cz + Math.sin(a) * off;
  }

  private apply() {
    this.wall.position.set(this.cx, 40, this.cz);
    this.wall.scale.set(this.r, 1, this.r);
    this.ring.position.set(this.cx, 0.35, this.cz);
    this.ring.scale.set(this.r, this.r, 1);
  }
}
