import { Language } from './types';

export interface Translations {
  brand: string;
  subtitle: string;
  nicknameLabel: string;
  nicknamePlaceholder: string;
  defaultPlayerName: string;
  playTypeLabel: string;
  playSolo: string;
  playOnline: string;
  roomLabel: string;
  roomPlaceholder: string;
  globalRoomName: string;
  kurdistanRoomName: string;
  blitzRoomName: string;
  onlineCountSuffix: string;
  connectingText: string;
  connectionLostText: string;
  chooseSkin: string;
  gameMode: string;
  modes: {
    classic: { title: string; desc: string };
    blitz: { title: string; desc: string };
    relaxed: { title: string; desc: string };
  };
  arenaTheme: string;
  themeLight: string;
  themeDark: string;
  showMassLabel: string;
  startGame: string;
  joinOnlineGame: string;
  controlsTitle: string;
  controlMove: string;
  controlMoveKey: string;
  controlSplit: string;
  controlSplitKey: string;
  controlEject: string;
  controlEjectKey: string;
  controlPause: string;
  controlPauseKey: string;
  leaderboard: string;
  mass: string;
  peakMass: string;
  score: string;
  totalScore: string;
  rank: string;
  eaten: string;
  timeAlive: string;
  bestScore: string;
  cellsCount: string;
  splitBtn: string;
  ejectBtn: string;
  fastEjectBtn: string;
  pauseBtn: string;
  leaveBtn: string;
  muteBtn: string;
  unmuteBtn: string;
  pausedTitle: string;
  resumeGame: string;
  restartGame: string;
  backToMenu: string;
  gameOverTitle: string;
  eatenBy: string;
  survivedText: string;
  playAgain: string;
  newRecord: string;
  youLabel: string;
  minimapLabel: string;
  onlineBadge: string;
  shopBtn: string;
  shopTitle: string;
  shopSubtitle: string;
  tabSkins: string;
  tabBoosts: string;
  coinsLabel: string;
  dnaLabel: string;
  levelLabel: string;
  buyBtn: string;
  equipBtn: string;
  equippedLabel: string;
  freeLabel: string;
  activeMatchesLeft: string;
  leveledUpLabel: string;
  rewardsEarnedTitle: string;
  closeBtn: string;
  notEnoughLabel: string;
  boostActiveTag: string;
  zoomLabel: string;
  zoomInLabel: string;
  zoomOutLabel: string;
  zoomResetLabel: string;
  customizeControlsBtn: string;
  customizeTitle: string;
  customizeHint: string;
  showJoystickLabel: string;
  flipLayoutBtn: string;
  resetLayoutBtn: string;
  saveLayoutBtn: string;
  joystickLabel: string;
  gamePassBtn: string;
  gamePassTitle: string;
  gamePassSubtitle: string;
  seasonTimeLeft: string;
  daysShort: string;
  hoursShort: string;
  passTierLabel: string;
  tabPassRewards: string;
  tabPassChallenges: string;
  passFreeTrack: string;
  passPlusTrack: string;
  plusSeasonOneFree: string;
  activatePlusFreeBtn: string;
  plusActiveLabel: string;
  claimBtn: string;
  claimedLabel: string;
  claimAllBtn: string;
  lockedLabel: string;
  challengeStage: string;
  completedLabel: string;
  seasonExclusiveTag: string;
  moreBtn: string;
  lobbySetupTitle: string;
  skinsBtn: string;
  eventBtn: string;
  eventTitle: string;
  eventSubtitle: string;
  tokensLabel: string;
  useTokensPrefix: string;
  dailyTokensBtn: string;
  dailyTokensClaimed: string;
  centerMapBtn: string;
  eventEndsIn: string;
  earnedTokensLabel: string;
  boostsShortLabel: string;
  roomsBtn: string;
  accountBtn: string;
  friendsBtn: string;
  accountTitle: string;
  playerIdLabel: string;
  copyIdBtn: string;
  copiedText: string;
  signInGoogleBtn: string;
  signOutBtn: string;
  cloudSyncedLabel: string;
  guestAccountNote: string;
  searchFriendPlaceholder: string;
  searchBtn: string;
  noPlayersFound: string;
  addFriendBtn: string;
  friendAddedLabel: string;
  removeFriendBtn: string;
  joinRoomBtn: string;
  onlineNowLabel: string;
  offlineLabel: string;
  myFriendsTitle: string;
  findFriendsTitle: string;
  kickedNotice: string;
  receivedGrantNotice: string;
  currentRoomLabel: string;
  bestMassLabel: string;
  ownerMenuBtn: string;
  ownerMenuTitle: string;
  ownerTabSelf: string;
  ownerTabKick: string;
  ownerTabGive: string;
  addSelfCoinsLabel: string;
  addSelfDnaLabel: string;
  boostMyMassLabel: string;
  enterMatchHint: string;
  kickBtn: string;
  kickedSuccessText: string;
  giveCurrencyBtn: string;
  targetPlayerIdPlaceholder: string;
  grantSentText: string;
  livePlayersLabel: string;
  cloudPlayersLabel: string;
  refreshBtn: string;
  customAmountPlaceholder: string;
  massBoostSuccessText: string;
  settingsBtn: string;
  settingsAccountTitle: string;
  emailInputPlaceholder: string;
  signedInAsLabel: string;
  authErrorPopupBlocked: string;
  authErrorGeneric: string;
}

export const TRANSLATIONS: Record<Language, Translations> = {
  ckb: {
    brand: 'Rk.gar.io',
    subtitle: 'ئارێنای خانە زیندووەکان · گەورە ببە و خانە بچووکەکان بخۆ',
    nicknameLabel: 'ناوی خانەکەت',
    nicknamePlaceholder: 'ناوێک بنووسە...',
    defaultPlayerName: 'یاریزان',
    playTypeLabel: 'جۆری یاریکردن',
    playSolo: 'تاکە یاری (بۆت)',
    playOnline: 'ئۆنڵاین (فرە یاریزان)',
    roomLabel: 'ژووری ئۆنڵاین',
    roomPlaceholder: 'ناوی ژوور بنووسە (بۆ نموونە: kurd1)...',
    globalRoomName: 'گشتی',
    kurdistanRoomName: 'کوردستان',
    blitzRoomName: 'خێرا',
    onlineCountSuffix: 'یاریزان',
    connectingText: 'بەستنەوە بە سێرڤەرەوە...',
    connectionLostText: 'پەیوەندی لەگەڵ سێرڤەر پچڕا',
    chooseSkin: 'شێوەی خانە هەڵبژێرە',
    gameMode: 'شێوازی یاری',
    modes: {
      classic: { title: 'کلاسیک', desc: 'هاوسەنگ و ئاسایی' },
      blitz: { title: 'خێرا', desc: 'خێرایی و بارستەی خێراتر' },
      relaxed: { title: 'ئارام', desc: 'بۆتی هێواشتر و بێ فشار' },
    },
    arenaTheme: 'ڕووناکی ئارێنا',
    themeLight: 'ڕووناک',
    themeDark: 'تاریک',
    showMassLabel: 'پیشاندانی بارستە لەسەر خانەکان',
    startGame: 'دەستپێکردنی یاری',
    joinOnlineGame: 'چوونە ناو ئارێنای ئۆنڵاین',
    controlsTitle: 'کۆنترۆڵەکان',
    controlMove: 'جوڵەکردن',
    controlMoveKey: 'ماوس / دەست',
    controlSplit: 'دابەشبوون',
    controlSplitKey: 'Space',
    controlEject: 'هاویشتنی بارستە',
    controlEjectKey: 'W',
    controlPause: 'وەستاندن',
    controlPauseKey: 'Esc',
    leaderboard: 'پێشەنگەکان (Top 5)',
    mass: 'بارستە',
    peakMass: 'زۆرترین بارستە',
    score: 'خاڵ',
    totalScore: 'کۆی خاڵ',
    rank: 'پلە',
    eaten: 'خواردراو',
    timeAlive: 'کات',
    bestScore: 'باشترین تۆمار',
    cellsCount: 'خانەکان',
    splitBtn: 'دابەشبوون',
    ejectBtn: 'هاویشتن',
    fastEjectBtn: 'خێرا',
    pauseBtn: 'وەستان',
    leaveBtn: 'چوونەدەرەوە',
    muteBtn: 'بێدەنگکردن',
    unmuteBtn: 'دەنگکردنەوە',
    pausedTitle: 'یاری وەستێنراوە',
    resumeGame: 'بەردەوامبوون',
    restartGame: 'سەرلەنوێ دەستپێکردن',
    backToMenu: 'گەڕانەوە بۆ پێڕست',
    gameOverTitle: 'یاری تەواوبوو',
    eatenBy: 'خورای لەلایەن',
    survivedText: 'لە ئارێناکەدا خۆڕاگریت کرد',
    playAgain: 'دووبارە یاریکردن',
    newRecord: 'تۆمارێکی نوێ!',
    youLabel: 'تۆ',
    minimapLabel: 'نەخشەی ئارێنا',
    onlineBadge: 'ئۆنڵاین',
    shopBtn: 'شۆپ',
    shopTitle: 'شۆپ و بەرزکردنەوەی لیڤڵ',
    shopSubtitle: 'بە کوین و DNA سکین و بووستی لیڤڵ بکڕە',
    tabSkins: 'سکینەکان',
    tabBoosts: 'بووستی لیڤڵ و خێرایی',
    coinsLabel: 'کوین',
    dnaLabel: 'DNA',
    levelLabel: 'لیڤڵ',
    buyBtn: 'کڕین',
    equipBtn: 'هەڵبژاردن',
    equippedLabel: 'چالاکە',
    freeLabel: 'خۆڕایی',
    activeMatchesLeft: 'یاری ماوە',
    leveledUpLabel: 'لیڤڵت بەرزبووەوە!',
    rewardsEarnedTitle: 'دەستکەوتەکانی ئەم یارییە',
    closeBtn: 'داخستن',
    notEnoughLabel: 'کوین/DNA بەس نییە',
    boostActiveTag: 'بووست چالاکە',
    zoomLabel: 'زۆۆم',
    zoomInLabel: 'گەورەکردن',
    zoomOutLabel: 'بچووککردنەوە',
    zoomResetLabel: 'ئاسایی',
    customizeControlsBtn: 'شوێنی کۆنتڕۆڵەکان',
    customizeTitle: 'ڕێکخستنی شوێنی کۆنتڕۆڵەکان',
    customizeHint: 'هەر کۆنتڕۆڵێک ڕابکێشە بۆ شوێنی دڵخوازت لەسەر شاشەکە',
    showJoystickLabel: 'جۆیستیکی سەر شاشە',
    flipLayoutBtn: 'پێچەوانە',
    resetLayoutBtn: 'ڕێکخستنەوە',
    saveLayoutBtn: 'پاشەکەوتکردن',
    joystickLabel: 'جوڵە',
    gamePassBtn: 'گەیم پاس',
    gamePassTitle: 'گەیم پاسی مانگانە · سیزن ١',
    gamePassSubtitle: 'چاڵنجەکان تەواو بکە و ٥٠ دیاری بکەرەوە',
    seasonTimeLeft: 'کاتی ماوەی سیزن:',
    daysShort: 'ڕۆژ',
    hoursShort: 'کاتژمێر',
    passTierLabel: 'ئاست',
    tabPassRewards: 'دیاریەکان (٥٠ ئاست)',
    tabPassChallenges: 'چاڵنجەکان',
    passFreeTrack: 'Game Pass Free (سادە)',
    passPlusTrack: 'Game Pass Plus (نایاب)',
    plusSeasonOneFree: 'دیاری سیزنی ١: Game Pass Plus بۆ ئەم سیزنە بە خۆڕاییە!',
    activatePlusFreeBtn: 'چالاککردنی خۆڕایی (Plus)',
    plusActiveLabel: 'Plus چالاکە',
    claimBtn: 'وەرگرتن',
    claimedLabel: 'وەرگیرا',
    claimAllBtn: 'وەرگرتنی هەموو',
    lockedLabel: 'داخراوە',
    challengeStage: 'قۆناغ',
    completedLabel: 'تەواوبوو',
    seasonExclusiveTag: 'سیزن ١ · گەیم پاس',
    moreBtn: 'زیاتر',
    lobbySetupTitle: 'ڕێکخستنی یاری و ژوورەکان',
    skinsBtn: 'سکینەکان',
    eventBtn: 'ئیڤێنت',
    eventTitle: 'گەشتی تۆڕی نێکسەس · ئیڤێنت',
    eventSubtitle: 'تۆکنەکان کۆبکەرەوە و ڕێگاکانی نەخشەکە بکەرەوە بۆ وەرگرتنی خەڵاتی نایاب!',
    tokensLabel: 'تۆکن',
    useTokensPrefix: 'تێچوو:',
    dailyTokensBtn: 'دیاری ڕۆژانە (+١٥ تۆکن)',
    dailyTokensClaimed: 'دیاری ئەمڕۆ وەرگیرا',
    centerMapBtn: 'ناوەندکردن',
    eventEndsIn: 'کاتی ماوە:',
    earnedTokensLabel: 'تۆکن',
    boostsShortLabel: 'بووستەکان',
    roomsBtn: 'ژوورەکان',
    accountBtn: 'ئەکاونت',
    friendsBtn: 'هاوڕێیان',
    accountTitle: 'زانیاری ئەکاونت و ناسنامە',
    playerIdLabel: 'ئایدی تایبەت (Player ID)',
    copyIdBtn: 'کۆپیکردن',
    copiedText: 'کۆپی کرا!',
    signInGoogleBtn: 'چوونەژوورەوە بە گووگڵ',
    signOutBtn: 'چوونەدەرەوە لە ئەکاونت',
    cloudSyncedLabel: 'بە هەژماری گووگڵ پاشەکەوت کراوە',
    guestAccountNote: 'بۆ هێشتنەوەی ئامار و هاوڕێکانت بە گووگڵ بچۆ ژوورەوە',
    searchFriendPlaceholder: 'ئایدی (RK-...) یان ناوی هاوڕێ بنووسە...',
    searchBtn: 'گەڕان',
    noPlayersFound: 'هیچ یاریزانێک نەدۆزرایەوە',
    addFriendBtn: 'زیادکردن',
    friendAddedLabel: 'هاوڕێیە',
    removeFriendBtn: 'سڕینەوە',
    joinRoomBtn: 'بڕۆ ژوورەکەی',
    onlineNowLabel: 'ئۆنڵاین',
    offlineLabel: 'ئۆفڵاین',
    myFriendsTitle: 'لیستی هاوڕێکانم',
    findFriendsTitle: 'دۆزینەوەی هاوڕێ',
    kickedNotice: 'لە یارییەکە دەرکرایت لەلایەن خاوەنی یارییەوە.',
    receivedGrantNotice: 'دیاری کوین/DNA لەلایەن خاوەنی یارییەوە بۆت نێردرا!',
    currentRoomLabel: 'ژووری ئێستا',
    bestMassLabel: 'زۆرترین بارستە',
    ownerMenuBtn: 'خاوەن',
    ownerMenuTitle: 'مینوی تایبەتی خاوەنی یاری',
    ownerTabSelf: 'بۆ خۆم',
    ownerTabKick: 'دەرکردن',
    ownerTabGive: 'زیادکردنی پارە',
    addSelfCoinsLabel: 'زیادکردنی کوین بۆ خۆم',
    addSelfDnaLabel: 'زیادکردنی DNA بۆ خۆم',
    boostMyMassLabel: 'زیادکردنی بارستەی خۆم لە یاریدا',
    enterMatchHint: 'بۆ زیادکردنی بارستە سەرەتا بچۆ ناو یارییەکەوە (تاکە یاری یان ئۆنڵاین)',
    kickBtn: 'دەرکردن',
    kickedSuccessText: 'یاریزانەکە دەرکرا!',
    giveCurrencyBtn: 'ناردنی پارە',
    targetPlayerIdPlaceholder: 'ئایدی یاریزان (RK-...) بنووسە یان هەڵبژێرە',
    grantSentText: 'کوین و DNA بە سەرکەوتوویی نێردران!',
    livePlayersLabel: 'یاریزانە ئۆنڵاینەکان',
    cloudPlayersLabel: 'ئەکاونتە تۆمارکراوەکان',
    refreshBtn: 'نوێکردنەوە',
    customAmountPlaceholder: 'بڕ...',
    massBoostSuccessText: 'بارستەکەت زیاد کرا!',
    settingsBtn: 'سێتینگ',
    settingsAccountTitle: 'هەژمار و چوونەژوورەوە بە ئیمەیڵ',
    emailInputPlaceholder: 'ئیمەیڵەکەت بنووسە (بۆ نموونە: name@gmail.com)...',
    signedInAsLabel: 'چوونەژوورەوە بەم هەژمارە:',
    authErrorPopupBlocked: 'پەنجەرەی چوونەژوورەوە لەلایەن براوزەرەوە بلۆک کرا، تکایە ڕێگە بە Popup بدە و دووبارە هەوڵبدە.',
    authErrorGeneric: 'چوونەژوورەوە سەرکەوتوو نەبوو، تکایە دووبارە هەوڵبدە.',
  },
  en: {
    brand: 'Rk.gar.io',
    subtitle: 'Cellular arena · Grow your mass, split smart, rule the petri dish',
    nicknameLabel: 'Cell Name',
    nicknamePlaceholder: 'Enter nickname...',
    defaultPlayerName: 'Player',
    playTypeLabel: 'Play Mode',
    playSolo: 'Solo (Bots)',
    playOnline: 'Online (Multiplayer)',
    roomLabel: 'Online Room',
    roomPlaceholder: 'Enter room name (e.g. kurd1)...',
    globalRoomName: 'Global',
    kurdistanRoomName: 'Kurdistan',
    blitzRoomName: 'Blitz',
    onlineCountSuffix: 'online',
    connectingText: 'Connecting to arena server...',
    connectionLostText: 'Lost connection to server',
    chooseSkin: 'Select Cell Skin',
    gameMode: 'Game Mode',
    modes: {
      classic: { title: 'Classic', desc: 'Balanced arena pace' },
      blitz: { title: 'Blitz', desc: 'Faster speed & richer mass' },
      relaxed: { title: 'Relaxed', desc: 'Gentle bots, chill growth' },
    },
    arenaTheme: 'Arena Surface',
    themeLight: 'Light',
    themeDark: 'Dark',
    showMassLabel: 'Show mass on cells',
    startGame: 'Start Game',
    joinOnlineGame: 'Join Online Arena',
    controlsTitle: 'Controls',
    controlMove: 'Move',
    controlMoveKey: 'Mouse / Touch',
    controlSplit: 'Split',
    controlSplitKey: 'Space',
    controlEject: 'Eject Mass',
    controlEjectKey: 'W',
    controlPause: 'Pause',
    controlPauseKey: 'Esc',
    leaderboard: 'Top 5 Leaderboard',
    mass: 'Mass',
    peakMass: 'Peak Mass',
    score: 'Score',
    totalScore: 'Total Score',
    rank: 'Rank',
    eaten: 'Eaten',
    timeAlive: 'Time',
    bestScore: 'Best Record',
    cellsCount: 'Cells',
    splitBtn: 'Split',
    ejectBtn: 'Eject',
    fastEjectBtn: 'Turbo',
    pauseBtn: 'Pause',
    leaveBtn: 'Leave',
    muteBtn: 'Mute',
    unmuteBtn: 'Unmute',
    pausedTitle: 'Game Paused',
    resumeGame: 'Resume',
    restartGame: 'Restart',
    backToMenu: 'Main Menu',
    gameOverTitle: 'Game Over',
    eatenBy: 'Absorbed by',
    survivedText: 'You survived in the arena',
    playAgain: 'Play Again',
    newRecord: 'New Record!',
    youLabel: 'You',
    minimapLabel: 'Arena minimap',
    onlineBadge: 'Online',
    shopBtn: 'Shop',
    shopTitle: 'Cell Shop & Level Boosts',
    shopSubtitle: 'Unlock skins and level boosts with Coins & DNA',
    tabSkins: 'Skins',
    tabBoosts: 'Level Boosts',
    coinsLabel: 'Coins',
    dnaLabel: 'DNA',
    levelLabel: 'Level',
    buyBtn: 'Buy',
    equipBtn: 'Equip',
    equippedLabel: 'Equipped',
    freeLabel: 'Free',
    activeMatchesLeft: 'matches left',
    leveledUpLabel: 'Level Up!',
    rewardsEarnedTitle: 'Match Rewards',
    closeBtn: 'Close',
    notEnoughLabel: 'Insufficient balance',
    boostActiveTag: 'Boost active',
    zoomLabel: 'Zoom',
    zoomInLabel: 'Zoom In',
    zoomOutLabel: 'Zoom Out',
    zoomResetLabel: 'Reset',
    customizeControlsBtn: 'Control Layout',
    customizeTitle: 'Customize Control Positions',
    customizeHint: 'Drag any control to move it to your preferred spot',
    showJoystickLabel: 'On-Screen Joystick',
    flipLayoutBtn: 'Flip L/R',
    resetLayoutBtn: 'Reset',
    saveLayoutBtn: 'Save',
    joystickLabel: 'Move',
    gamePassBtn: 'Game Pass',
    gamePassTitle: 'Monthly Game Pass · Season 1',
    gamePassSubtitle: 'Complete challenges & unlock 50 rewards',
    seasonTimeLeft: 'Season ends in:',
    daysShort: 'd',
    hoursShort: 'h',
    passTierLabel: 'Tier',
    tabPassRewards: 'Rewards (50 Tiers)',
    tabPassChallenges: 'Challenges',
    passFreeTrack: 'Game Pass Free',
    passPlusTrack: 'Game Pass Plus',
    plusSeasonOneFree: 'Season 1 Special: Game Pass Plus is FREE!',
    activatePlusFreeBtn: 'Activate Plus Free',
    plusActiveLabel: 'Plus Active',
    claimBtn: 'Claim',
    claimedLabel: 'Claimed',
    claimAllBtn: 'Claim All',
    lockedLabel: 'Locked',
    challengeStage: 'Stage',
    completedLabel: 'Completed',
    seasonExclusiveTag: 'Season 1 Pass',
    moreBtn: 'More',
    lobbySetupTitle: 'Arena Setup & Rooms',
    skinsBtn: 'Skins',
    eventBtn: 'Event',
    eventTitle: 'Nexus Expedition · Event',
    eventSubtitle: 'Collect tokens in matches to unlock maze paths and claim epic rewards!',
    tokensLabel: 'Tokens',
    useTokensPrefix: 'Use',
    dailyTokensBtn: 'Daily Gift (+15 Tokens)',
    dailyTokensClaimed: 'Claimed Today',
    centerMapBtn: 'Center',
    eventEndsIn: 'Ends in:',
    earnedTokensLabel: 'Tokens',
    boostsShortLabel: 'Boosts',
    roomsBtn: 'Rooms',
    accountBtn: 'Account',
    friendsBtn: 'Friends',
    accountTitle: 'Account Info & Player ID',
    playerIdLabel: 'Unique Player ID',
    copyIdBtn: 'Copy ID',
    copiedText: 'Copied!',
    signInGoogleBtn: 'Sign in with Google',
    signOutBtn: 'Sign Out',
    cloudSyncedLabel: 'Synced with Google Account',
    guestAccountNote: 'Sign in with Google to save progress & find offline friends',
    searchFriendPlaceholder: 'Enter Player ID (RK-...) or nickname...',
    searchBtn: 'Search',
    noPlayersFound: 'No matching players found',
    addFriendBtn: 'Add Friend',
    friendAddedLabel: 'Friend',
    removeFriendBtn: 'Remove',
    joinRoomBtn: 'Join Room',
    onlineNowLabel: 'Online',
    offlineLabel: 'Offline',
    myFriendsTitle: 'My Friends',
    findFriendsTitle: 'Find Friends',
    kickedNotice: 'You were removed from the arena by the game owner.',
    receivedGrantNotice: 'You received Coins/DNA from the game owner!',
    currentRoomLabel: 'Current Room',
    bestMassLabel: 'Best Mass',
    ownerMenuBtn: 'Owner',
    ownerMenuTitle: 'Owner Exclusive Menu',
    ownerTabSelf: 'For Me',
    ownerTabKick: 'Kick Player',
    ownerTabGive: 'Give Currency',
    addSelfCoinsLabel: 'Add Coins to Myself',
    addSelfDnaLabel: 'Add DNA to Myself',
    boostMyMassLabel: 'Boost My Live Mass',
    enterMatchHint: 'Enter a Solo or Online match first to boost your live mass',
    kickBtn: 'Kick',
    kickedSuccessText: 'Player kicked from the game!',
    giveCurrencyBtn: 'Send Currency',
    targetPlayerIdPlaceholder: 'Enter Player ID (RK-...) or pick below',
    grantSentText: 'Coins & DNA delivered!',
    livePlayersLabel: 'Live Connected Players',
    cloudPlayersLabel: 'Cloud Registered Accounts',
    refreshBtn: 'Refresh',
    customAmountPlaceholder: 'Amount...',
    massBoostSuccessText: 'Your mass has been boosted!',
    settingsBtn: 'Settings',
    settingsAccountTitle: 'Account & Email Sign-In',
    emailInputPlaceholder: 'Enter your email (e.g. name@gmail.com)...',
    signedInAsLabel: 'Signed in as:',
    authErrorPopupBlocked: 'Sign-in popup was blocked by your browser. Please allow popups and try again.',
    authErrorGeneric: 'Sign-in failed. Please try again.',
  },
};
