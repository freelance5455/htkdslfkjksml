import { useEffect, useRef } from "react";
import type { LiveVisual } from "@/game/visual";

export function Pitch3D({ live }: { live: { current: LiveVisual } }) {
  const host = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = host.current;
    if (!el) return;
    let dead = false;
    let cleanup = () => {};

    void import("three").then((THREE) => {
      if (dead || !el) return;
      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, live.current.quality === "low" ? 1 : 1.5));
      renderer.setSize(el.clientWidth, el.clientHeight);
      el.appendChild(renderer.domElement);
      renderer.domElement.style.width = "100%";
      renderer.domElement.style.height = "100%";
      renderer.domElement.style.display = "block";

      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 80);
      camera.position.set(0, 4.2, 11);

      const hemi = new THREE.HemisphereLight(0xd7e6ff, 0x1a3a22, 0.85);
      scene.add(hemi);
      const sun = new THREE.DirectionalLight(0xfff1c9, 1.15);
      sun.position.set(-6, 10, 4);
      scene.add(sun);
      const floodA = new THREE.PointLight(0xfff4d2, 0, 28);
      floodA.position.set(-8, 8, -2);
      const floodB = new THREE.PointLight(0xfff4d2, 0, 28);
      floodB.position.set(8, 8, -2);
      scene.add(floodA, floodB);

      const grass = new THREE.Mesh(
        new THREE.CircleGeometry(18, 40),
        new THREE.MeshStandardMaterial({ color: 0x1b7a38, roughness: 0.95 }),
      );
      grass.rotation.x = -Math.PI / 2;
      scene.add(grass);

      const pitch = new THREE.Mesh(
        new THREE.BoxGeometry(2.2, 0.06, 10),
        new THREE.MeshStandardMaterial({ color: 0xc4a36a, roughness: 0.85 }),
      );
      pitch.position.y = 0.03;
      scene.add(pitch);

      function stumpGroup(z: number) {
        const g = new THREE.Group();
        for (const x of [-0.12, 0, 0.12]) {
          const s = new THREE.Mesh(
            new THREE.CylinderGeometry(0.025, 0.025, 0.7, 8),
            new THREE.MeshStandardMaterial({ color: 0xf4efe4 }),
          );
          s.position.set(x, 0.35, 0);
          g.add(s);
        }
        const bail = new THREE.Mesh(
          new THREE.BoxGeometry(0.32, 0.03, 0.03),
          new THREE.MeshStandardMaterial({ color: 0xe8b84a }),
        );
        bail.position.set(0, 0.72, 0);
        bail.name = "bail";
        g.add(bail);
        g.position.set(0, 0, z);
        return g;
      }
      const near = stumpGroup(4.2);
      const far = stumpGroup(-4.2);
      scene.add(near, far);

      const ball = new THREE.Mesh(
        new THREE.SphereGeometry(0.09, 16, 16),
        new THREE.MeshStandardMaterial({ color: 0xf4efe4, roughness: 0.4 }),
      );
      scene.add(ball);

      const batter = new THREE.Group();
      const body = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.22, 0.55, 4, 8),
        new THREE.MeshStandardMaterial({ color: 0xe8b84a }),
      );
      body.position.y = 0.85;
      const head = new THREE.Mesh(
        new THREE.SphereGeometry(0.16, 12, 12),
        new THREE.MeshStandardMaterial({ color: 0x2a1d05 }),
      );
      head.position.y = 1.4;
      const bat = new THREE.Mesh(
        new THREE.BoxGeometry(0.08, 0.7, 0.18),
        new THREE.MeshStandardMaterial({ color: 0xf3e2b8 }),
      );
      bat.position.set(0.28, 0.9, 0.05);
      batter.add(body, head, bat);
      batter.position.set(0.35, 0, 3.5);
      scene.add(batter);

      const bowler = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.18, 0.5, 4, 8),
        new THREE.MeshStandardMaterial({ color: 0x1d4ed8 }),
      );
      bowler.position.set(0, 0.8, -3.2);
      scene.add(bowler);

      const standMat = new THREE.MeshStandardMaterial({ color: 0x102418 });
      for (const side of [-1, 1]) {
        const stand = new THREE.Mesh(new THREE.BoxGeometry(14, 1.4, 1.2), standMat);
        stand.position.set(side * 8, 0.7, 0);
        scene.add(stand);
      }

      const bg = new THREE.Color("#07111c");
      scene.background = bg;
      let raf = 0;
      const loop = () => {
        const L = live.current;
        const w = el.clientWidth || 1;
        const h = el.clientHeight || 1;
        if (renderer.domElement.width !== Math.floor(w * renderer.getPixelRatio())) {
          camera.aspect = w / Math.max(h, 1);
          camera.updateProjectionMatrix();
          renderer.setSize(w, h, false);
        }
        const night = L.night;
        bg.set(L.sky);
        (grass.material as import("three").MeshStandardMaterial).color.set(L.grass);
        hemi.intensity = night ? 0.45 : 0.9;
        sun.intensity = night ? 0.25 : 1.2;
        floodA.intensity = night ? 18 : 0;
        floodB.intensity = night ? 18 : 0;
        (body.material as import("three").MeshStandardMaterial).color.set(L.batColor);
        (bowler.material as import("three").MeshStandardMaterial).color.set(L.bowlColor);

        const prog = L.delivery ? Math.min(1.15, L.elapsed / L.ballSeconds) : 0;
        const flight = prog < 0.28 ? 0 : Math.min(1, (prog - 0.28) / 0.72);
        const z = -3.1 + flight * 6.7;
        const hop =
          L.length === "bouncer" ? 2.2 : L.length === "short" ? 1.5 : L.length === "yorker" ? 0.35 : 0.9;
        ball.position.set(L.line === "off" ? 0.35 : L.line === "leg" ? -0.35 : 0, 0.15 + Math.sin(flight * Math.PI) * hop, z);
        ball.visible = !!L.delivery && flight > 0 && flight < 1.02;
        bowler.position.z = -4.4 + Math.min(prog / 0.28, 1) * 1.2;
        const swing = L.shot && prog > 0.66 ? 0.8 : 0.15;
        bat.rotation.z = -swing;
        const bail = near.getObjectByName("bail");
        if (bail) {
          const fly = L.wicketFly;
          bail.position.y = 0.72 + fly * 1.4;
          bail.position.x = fly * 0.4;
        }
        if (L.cam === "behind") camera.position.set(0.2, 2.2, 7.2);
        else camera.position.set(7.5, 3.6, 3.2);
        camera.lookAt(0, 0.8, 1);
        clock.t += 0.016;
        renderer.render(scene, camera);
        raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
      cleanup = () => {
        cancelAnimationFrame(raf);
        renderer.dispose();
        renderer.domElement.remove();
      };
    });

    return () => {
      dead = true;
      cleanup();
    };
  }, [live]);

  return <div ref={host} className="h-full w-full overflow-hidden rounded-2xl border border-line" />;
}
