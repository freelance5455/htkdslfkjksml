import * as THREE from "three";
import { shared } from "./materials";

interface Key {
  h: number;
  top: number;
  hor: number;
  sun: number;
  sunI: number;
  hemi: number;
  cloud: number;
}
const KEYS: Key[] = [
  { h: 0, top: 0x070b1e, hor: 0x18203a, sun: 0x7080b8, sunI: 0.28, hemi: 0.32, cloud: 0x2a3050 },
  { h: 4.8, top: 0x0d1330, hor: 0x2a2848, sun: 0x7080b8, sunI: 0.22, hemi: 0.32, cloud: 0x363a5a },
  { h: 6.2, top: 0x32508e, hor: 0xf0a070, sun: 0xffa868, sunI: 0.75, hemi: 0.5, cloud: 0xf0b8a0 },
  { h: 8, top: 0x4a86d0, hor: 0xb6d6ee, sun: 0xfff0d6, sunI: 1.25, hemi: 0.7, cloud: 0xffffff },
  { h: 12.5, top: 0x3a7cd4, hor: 0xc2e2f6, sun: 0xfffaf0, sunI: 1.4, hemi: 0.75, cloud: 0xffffff },
  { h: 16.8, top: 0x4a7ec8, hor: 0xd8d4b8, sun: 0xffe2b0, sunI: 1.15, hemi: 0.68, cloud: 0xfff4e0 },
  { h: 18.4, top: 0x3a4786, hor: 0xf08650, sun: 0xff8a4a, sunI: 0.62, hemi: 0.48, cloud: 0xf09878 },
  { h: 19.8, top: 0x111a40, hor: 0x2e2a52, sun: 0x7080b8, sunI: 0.26, hemi: 0.34, cloud: 0x3a3a5c },
  { h: 24, top: 0x070b1e, hor: 0x18203a, sun: 0x7080b8, sunI: 0.28, hemi: 0.32, cloud: 0x2a3050 },
];

export interface SkyState {
  top: THREE.Color;
  hor: THREE.Color;
  sun: THREE.Color;
  cloud: THREE.Color;
  sunI: number;
  hemi: number;
  sunDir: THREE.Vector3; // actual sun
  lightDir: THREE.Vector3; // sun or moon
  night: number; // 0 day .. 1 night
  day: number;
}

const ca = new THREE.Color(), cb = new THREE.Color();
export function skyAt(hour: number, out: SkyState) {
  let i = 0;
  while (i < KEYS.length - 2 && KEYS[i + 1].h <= hour) i++;
  const a = KEYS[i], b = KEYS[i + 1];
  const t = Math.min(1, Math.max(0, (hour - a.h) / (b.h - a.h)));
  const mix = (x: number, y: number, o: THREE.Color) => o.copy(ca.setHex(x)).lerp(cb.setHex(y), t);
  mix(a.top, b.top, out.top);
  mix(a.hor, b.hor, out.hor);
  mix(a.sun, b.sun, out.sun);
  mix(a.cloud, b.cloud, out.cloud);
  out.sunI = a.sunI + (b.sunI - a.sunI) * t;
  out.hemi = a.hemi + (b.hemi - a.hemi) * t;
  const ang = ((hour - 6) / 12) * Math.PI;
  out.sunDir.set(Math.cos(ang) * 0.85, Math.sin(ang), 0.42).normalize();
  const el = out.sunDir.y;
  out.night = 1 - Math.min(1, Math.max(0, (el + 0.12) / 0.3));
  out.day = 1 - out.night;
  if (el > -0.05) out.lightDir.copy(out.sunDir);
  else out.lightDir.copy(out.sunDir).multiplyScalar(-1);
  if (out.lightDir.y < 0.15) { out.lightDir.y = 0.15; out.lightDir.normalize(); }
  return out;
}

export function newSkyState(): SkyState {
  return {
    top: new THREE.Color(), hor: new THREE.Color(), sun: new THREE.Color(), cloud: new THREE.Color(),
    sunI: 1, hemi: 0.6, sunDir: new THREE.Vector3(), lightDir: new THREE.Vector3(), night: 0, day: 1,
  };
}

export function makeSky() {
  const uniforms = {
    uTop: { value: new THREE.Color() },
    uHor: { value: new THREE.Color() },
    uSunDir: { value: new THREE.Vector3(0, 1, 0) },
    uSunCol: { value: new THREE.Color() },
    uCloud: { value: new THREE.Color() },
    uNight: { value: 0 },
    uTime: shared.uTime,
  };
  const mat = new THREE.ShaderMaterial({
    uniforms,
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    vertexShader: `
      varying vec3 vDir;
      void main(){
        vDir = position;
        vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        gl_Position = p.xyww;
      }`,
    fragmentShader: `
      uniform vec3 uTop; uniform vec3 uHor; uniform vec3 uSunDir; uniform vec3 uSunCol; uniform vec3 uCloud;
      uniform float uNight; uniform float uTime;
      varying vec3 vDir;
      float h3(vec3 p){ p = fract(p*0.3183099 + 0.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
      float h2(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float vn(vec2 p){ vec2 i = floor(p); vec2 f = fract(p); f = f*f*(3.0-2.0*f);
        return mix(mix(h2(i), h2(i+vec2(1.0,0.0)), f.x), mix(h2(i+vec2(0.0,1.0)), h2(i+vec2(1.0,1.0)), f.x), f.y); }
      void main(){
        vec3 d = normalize(vDir);
        float h = d.y;
        vec3 col = mix(uHor, uTop, pow(clamp(h, 0.0, 1.0), 0.55));
        if (h < 0.0) col = mix(uHor, uHor * 0.75, clamp(-h * 5.0, 0.0, 1.0));
        float sd = dot(d, uSunDir);
        float dayK = 1.0 - uNight;
        col += uSunCol * step(0.9988, sd) * dayK * 1.4;
        col += uSunCol * pow(max(sd, 0.0), 40.0) * 0.35 * dayK;
        float md = dot(d, -uSunDir);
        col = mix(col, vec3(0.92, 0.93, 1.0), step(0.9993, md) * uNight);
        col += vec3(0.5, 0.55, 0.8) * pow(max(md, 0.0), 200.0) * 0.4 * uNight;
        vec3 q = floor(d * 170.0);
        float st = h3(q);
        float tw = 0.6 + 0.4 * sin(uTime * 2.0 + st * 60.0);
        col += step(0.9972, st) * uNight * clamp(h * 3.0, 0.0, 1.0) * vec3(0.95) * tw;
        if (h > 0.01) {
          vec2 cp = d.xz / (h + 0.12) * 1.6 + vec2(uTime * 0.006, uTime * 0.002);
          cp = floor(cp * 24.0) / 24.0;
          float c = vn(cp * 1.2) * 0.55 + vn(cp * 2.7 + 4.0) * 0.3 + vn(cp * 6.0) * 0.15;
          float cm = smoothstep(0.52, 0.66, c);
          float edge = smoothstep(0.66, 0.8, c);
          vec3 cc = mix(uCloud * 0.82, uCloud, edge);
          col = mix(col, cc, cm * 0.9 * clamp(h * 6.0, 0.0, 1.0));
        }
        gl_FragColor = vec4(col, 1.0);
      }`,
  });
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(900, 20, 12), mat);
  mesh.frustumCulled = false;
  mesh.renderOrder = -10;
  return { mesh, uniforms };
}
