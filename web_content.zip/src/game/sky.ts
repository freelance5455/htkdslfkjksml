import * as THREE from 'three'

/** Sky colours shared by the dome, the fog and the environment lighting. */
export const SKY = {
  zenith: new THREE.Color(0x2c6db8),
  mid: new THREE.Color(0x6fa6d8),
  horizon: new THREE.Color(0xc4dcec),
  ground: new THREE.Color(0x8a8070),
  sun: new THREE.Vector3(0.62, 0.5, 0.42).normalize(),
}

const SKY_VERT = `
varying vec3 vDir;
void main() {
  vDir = normalize(position);
  vec4 p = modelViewMatrix * vec4(position, 1.0);
  gl_Position = projectionMatrix * p;
  gl_Position.z = gl_Position.w;
}`

const SKY_FRAG = `
uniform vec3 uZenith; uniform vec3 uMid; uniform vec3 uHorizon; uniform vec3 uGround; uniform vec3 uSun;
varying vec3 vDir;
void main() {
  vec3 d = normalize(vDir);
  float up = d.y;
  vec3 col = mix(uHorizon, uMid, smoothstep(0.0, 0.22, up));
  col = mix(col, uZenith, smoothstep(0.18, 0.85, up));
  col = mix(col, uGround, smoothstep(0.0, -0.18, up));
  float s = max(dot(d, uSun), 0.0);
  col += vec3(1.0, 0.86, 0.62) * (pow(s, 8.0) * 0.16 + pow(s, 400.0) * 1.6);
  gl_FragColor = vec4(col, 1.0);
}`

export function createSkyDome(): THREE.Mesh {
  const material = new THREE.ShaderMaterial({
    vertexShader: SKY_VERT,
    fragmentShader: SKY_FRAG,
    uniforms: {
      uZenith: { value: SKY.zenith },
      uMid: { value: SKY.mid },
      uHorizon: { value: SKY.horizon },
      uGround: { value: SKY.ground },
      uSun: { value: SKY.sun },
    },
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
  })
  const dome = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 20), material)
  dome.frustumCulled = false
  dome.renderOrder = -10
  return dome
}

/** Soft cumulus texture painted on a canvas. */
function cloudTexture(): THREE.CanvasTexture {
  const size = 256
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = size
  const g = canvas.getContext('2d')!
  const blobs = 26
  let seed = 7
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647)
  for (let i = 0; i < blobs; i += 1) {
    const x = size * (0.2 + rnd() * 0.6)
    const y = size * (0.42 + rnd() * 0.22)
    const r = size * (0.1 + rnd() * 0.16)
    const grad = g.createRadialGradient(x, y, 0, x, y, r)
    grad.addColorStop(0, 'rgba(255,255,255,0.55)')
    grad.addColorStop(0.6, 'rgba(255,255,255,0.22)')
    grad.addColorStop(1, 'rgba(255,255,255,0)')
    g.fillStyle = grad
    g.fillRect(0, 0, size, size)
  }
  // Flat-ish grey base so clouds have volume.
  const base = g.createLinearGradient(0, size * 0.4, 0, size * 0.75)
  base.addColorStop(0, 'rgba(160,175,195,0)')
  base.addColorStop(1, 'rgba(160,175,195,0.22)')
  g.globalCompositeOperation = 'source-atop'
  g.fillStyle = base
  g.fillRect(0, 0, size, size)
  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  return tex
}

/** A field of cloud sprites that wraps around the player, so the sky is always populated. */
export class Clouds {
  readonly group = new THREE.Group()
  private readonly sprites: THREE.Sprite[] = []
  private readonly span = 7000

  constructor(count: number) {
    const map = cloudTexture()
    for (let i = 0; i < count; i += 1) {
      const material = new THREE.SpriteMaterial({ map, transparent: true, opacity: 0.85, depthWrite: false, fog: false })
      const sprite = new THREE.Sprite(material)
      const w = 700 + Math.random() * 900
      sprite.scale.set(w, w * (0.34 + Math.random() * 0.1), 1)
      sprite.position.set((Math.random() - 0.5) * this.span, 1300 + Math.random() * 700, (Math.random() - 0.5) * this.span)
      this.group.add(sprite)
      this.sprites.push(sprite)
    }
  }

  update(cx: number, cz: number): void {
    const half = this.span / 2
    for (const s of this.sprites) {
      // Wrap each sprite into a square window centred on the camera.
      s.position.x = cx + wrap(s.position.x - cx, half)
      s.position.z = cz + wrap(s.position.z - cz, half)
    }
  }

  /** Show only the first `count` clouds (quality setting). */
  setCount(count: number): void {
    this.sprites.forEach((s, i) => { s.visible = i < count })
  }
}

function wrap(v: number, half: number): number {
  const span = half * 2
  return ((((v + half) % span) + span) % span) - half
}

export function createLights(): THREE.Light[] {
  const hemi = new THREE.HemisphereLight(0xcfe3f5, 0x6a5a44, 0.62)
  const sun = new THREE.DirectionalLight(0xfff0d2, 2.9)
  sun.position.copy(SKY.sun).multiplyScalar(1000)
  return [hemi, sun]
}
