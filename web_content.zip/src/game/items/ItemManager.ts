/**
 * SPR - Sahil Powerful Run
 * 3D Collectible Coins & Power-Up System with Magnet Attraction & Visual Effects
 */

import * as THREE from 'three';
import { GAME_CONFIG, PowerUpType } from '../constants';
import { textureGenerator } from '../utils/TextureGenerator';
import { Rocket3DBuilder } from '../models/Rocket3DBuilder';

export interface CoinInstance {
  mesh: THREE.Mesh;
  lane: number;
  x: number;
  y: number;
  z: number;
  active: boolean;
}

export interface PowerUpInstance {
  type: PowerUpType;
  group: THREE.Group;
  lane: number;
  x: number;
  y: number;
  z: number;
  active: boolean;
}

export class ItemManager {
  private scene: THREE.Scene;
  private coins: CoinInstance[] = [];
  private powerUps: PowerUpInstance[] = [];
  private coinPool: THREE.Mesh[] = [];
  private powerUpPool: Map<PowerUpType, THREE.Group[]> = new Map();

  // Shared Coin Material & Geometry
  private coinGeo!: THREE.CylinderGeometry;
  private coinMaterial!: THREE.MeshStandardMaterial;

  // Power-up Materials & Geometries
  private magnetMat!: THREE.MeshStandardMaterial;
  private rocketMat!: THREE.MeshStandardMaterial;
  private shieldMat!: THREE.MeshStandardMaterial;
  private doubleCoinsMat!: THREE.MeshStandardMaterial;
  private speedBoostMat!: THREE.MeshStandardMaterial;
  private podMat!: THREE.MeshBasicMaterial;

  // Cached Power-up Geometries
  private podGeo!: THREE.BufferGeometry;
  private magnetGeo!: THREE.BufferGeometry;
  private rocketBodyGeo!: THREE.BufferGeometry;
  private rocketNoseGeo!: THREE.BufferGeometry;
  private shieldSphereGeo!: THREE.BufferGeometry;
  private badgeGeo!: THREE.BufferGeometry;
  private arrowGeo!: THREE.BufferGeometry;

  // Active Power-ups state on player
  public activePowerUps: Record<PowerUpType, number> = {
    magnet: 0,
    rocket: 0,
    shield: 0,
    doubleCoins: 0,
    speedBoost: 0,
  };

  private animClock: number = 0;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.initCoinAssets();
    this.initPowerUpAssets();
    this.prewarmPools();
  }

  private initCoinAssets() {
    // Stylized Golden SPR Crown Coin matching reference image
    this.coinGeo = new THREE.CylinderGeometry(0.58, 0.58, 0.14, 20);
    this.coinGeo.rotateX(Math.PI / 2);

    const crownMap = textureGenerator.getCoinCrownTexture();
    this.coinMaterial = new THREE.MeshStandardMaterial({
      color: 0xfffbeb,
      map: crownMap,
      emissive: 0xd97706,
      emissiveIntensity: 0.4,
      metalness: 0.85,
      roughness: 0.25,
    });
  }

  private initPowerUpAssets() {
    this.magnetMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0xb91c1c,
      emissiveIntensity: 0.5,
      metalness: 0.6,
      roughness: 0.3,
    });

    this.rocketMat = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      emissive: 0x0891b2,
      emissiveIntensity: 0.5,
      metalness: 0.7,
      roughness: 0.2,
    });

    this.shieldMat = new THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      emissive: 0x1d4ed8,
      emissiveIntensity: 0.6,
      metalness: 0.5,
      roughness: 0.2,
    });

    this.doubleCoinsMat = new THREE.MeshStandardMaterial({
      color: 0x8b5cf6,
      emissive: 0x6d28d9,
      emissiveIntensity: 0.6,
      metalness: 0.7,
      roughness: 0.2,
    });

    this.speedBoostMat = new THREE.MeshStandardMaterial({
      color: 0xfacc15,
      emissive: 0xeab308,
      emissiveIntensity: 0.8,
      metalness: 0.8,
      roughness: 0.2,
    });

    this.podMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      wireframe: true,
      transparent: true,
      opacity: 0.35,
    });

    // Geometries
    this.podGeo = new THREE.OctahedronGeometry(0.9, 0);
    this.magnetGeo = new THREE.TorusGeometry(0.45, 0.16, 8, 12, Math.PI);
    this.rocketBodyGeo = new THREE.CylinderGeometry(0.2, 0.28, 0.9, 8);
    this.rocketNoseGeo = new THREE.ConeGeometry(0.2, 0.4, 8);
    this.shieldSphereGeo = new THREE.IcosahedronGeometry(0.65, 1);
    this.badgeGeo = new THREE.BoxGeometry(0.6, 0.6, 0.2);
    this.badgeGeo.rotateZ(Math.PI / 4);
    this.arrowGeo = new THREE.ConeGeometry(0.3, 0.5, 4);
    this.arrowGeo.rotateZ(-Math.PI / 2);
  }

  private prewarmPools() {
    // 1. Prewarm coin pool (40 instances)
    for (let i = 0; i < 40; i++) {
      const mesh = new THREE.Mesh(this.coinGeo, this.coinMaterial);
      mesh.castShadow = true;
      mesh.visible = false;
      this.scene.add(mesh);
      this.coinPool.push(mesh);
    }

    // 2. Prewarm power-up pool (3 of each type)
    const types: PowerUpType[] = ['magnet', 'rocket', 'shield', 'doubleCoins', 'speedBoost'];
    for (const t of types) {
      const list: THREE.Group[] = [];
      for (let i = 0; i < 3; i++) {
        const grp = this.createPowerUpMesh(t);
        grp.visible = false;
        this.scene.add(grp);
        list.push(grp);
      }
      this.powerUpPool.set(t, list);
    }
  }

  // --- SPAWN COINS ---
  public spawnCoinLine(laneIndex: number, startZ: number, count: number = 5, y: number = 1.0) {
    const laneX = GAME_CONFIG.LANES[laneIndex];
    const spacing = 3.5;

    for (let i = 0; i < count; i++) {
      const z = startZ - i * spacing;
      this.spawnSingleCoin(laneIndex, laneX, y, z);
    }
  }

  public spawnHighCoinArc(laneIndex: number, startZ: number, count: number = 7) {
    const laneX = GAME_CONFIG.LANES[laneIndex];
    const spacing = 3.2;

    for (let i = 0; i < count; i++) {
      const z = startZ - i * spacing;
      // Arc formula for jumping / flying
      const progress = i / (count - 1);
      const y = 1.0 + Math.sin(progress * Math.PI) * 3.5;
      this.spawnSingleCoin(laneIndex, laneX, y, z);
    }
  }

  /**
   * Spawns high-altitude skyway coin trails for the 32-second 3D Rocket Flight
   * Allows the player to maneuver between lanes while flying in the air to collect aerial rewards!
   */
  public spawnAerialSkywayCoinPath(laneIndex: number, startZ: number, count: number = 6, height: number = 4.8) {
    const laneX = GAME_CONFIG.LANES[laneIndex];
    const spacing = 3.6;

    for (let i = 0; i < count; i++) {
      const z = startZ - i * spacing;
      this.spawnSingleCoin(laneIndex, laneX, height, z);
    }
  }

  private spawnSingleCoin(lane: number, x: number, y: number, z: number) {
    let mesh: THREE.Mesh;
    if (this.coinPool.length > 0) {
      mesh = this.coinPool.pop()!;
      mesh.visible = true;
    } else {
      mesh = new THREE.Mesh(this.coinGeo, this.coinMaterial);
      mesh.castShadow = true;
      this.scene.add(mesh);
    }

    mesh.position.set(x, y, z);

    this.coins.push({
      mesh,
      lane,
      x,
      y,
      z,
      active: true,
    });
  }

  // --- SPAWN POWER-UP ---
  public spawnPowerUp(type: PowerUpType, laneIndex: number, z: number, y: number = 1.4) {
    const laneX = GAME_CONFIG.LANES[laneIndex];
    const group = this.getPowerUpMesh(type);

    group.position.set(laneX, y, z);
    group.visible = true;

    this.powerUps.push({
      type,
      group,
      lane: laneIndex,
      x: laneX,
      y,
      z,
      active: true,
    });
  }

  private getPowerUpMesh(type: PowerUpType): THREE.Group {
    const list = this.powerUpPool.get(type);
    if (list && list.length > 0) {
      const grp = list.pop()!;
      grp.visible = true;
      return grp;
    }

    const group = this.createPowerUpMesh(type);
    this.scene.add(group);
    return group;
  }

  private createPowerUpMesh(type: PowerUpType): THREE.Group {
    const group = new THREE.Group();

    // Floating outer glow crystal/pod using shared geometry and material
    const pod = new THREE.Mesh(this.podGeo, this.podMat);
    pod.name = 'pod_outer';
    group.add(pod);

    switch (type) {
      case 'magnet': {
        const magnet = new THREE.Mesh(this.magnetGeo, this.magnetMat);
        magnet.rotation.z = Math.PI;
        group.add(magnet);
        break;
      }

      case 'rocket': {
        const rocket = Rocket3DBuilder.createTrackRocketPowerUp();
        group.add(rocket);
        break;
      }

      case 'shield': {
        const shieldMesh = new THREE.Mesh(this.shieldSphereGeo, this.shieldMat);
        group.add(shieldMesh);
        break;
      }

      case 'doubleCoins': {
        const badge = new THREE.Mesh(this.badgeGeo, this.doubleCoinsMat);
        group.add(badge);
        break;
      }

      case 'speedBoost': {
        for (let a = -1; a <= 1; a += 2) {
          const arrow = new THREE.Mesh(this.arrowGeo, this.speedBoostMat);
          arrow.position.set(a * 0.25, 0, 0);
          group.add(arrow);
        }
        break;
      }
    }

    return group;
  }

  // --- UPDATE LOOP ---
  public update(
    delta: number,
    playerPos: THREE.Vector3,
    extraMagnet: boolean = false,
    extraCoinMultiplier: number = 1.0
  ): { collectedCoins: number; collectedPowerUp: PowerUpType | null } {
    let collectedCoins = 0;
    let collectedPowerUp: PowerUpType | null = null;
    this.animClock += delta;

    // 1. Tick power-up timers
    for (const key of Object.keys(this.activePowerUps) as PowerUpType[]) {
      if (this.activePowerUps[key] > 0) {
        this.activePowerUps[key] = Math.max(0, this.activePowerUps[key] - delta);
      }
    }

    const hasMagnet = this.activePowerUps.magnet > 0 || extraMagnet;
    const hasDoubleCoins = this.activePowerUps.doubleCoins > 0;
    const baseMultiplier = hasDoubleCoins ? 2 : 1;
    const coinMultiplier = Math.round(baseMultiplier * (extraCoinMultiplier || 1.0));
    const magnetRadiusSq = 256.0; // 16.0^2

    // 2. Update Coins
    for (let i = this.coins.length - 1; i >= 0; i--) {
      const coin = this.coins[i];

      // Rotate coin on Y-axis
      coin.mesh.rotation.y += delta * 4.2;

      const distSq = coin.mesh.position.distanceToSquared(playerPos);

      // Magnet attraction
      if (hasMagnet && distSq < magnetRadiusSq) {
        coin.mesh.position.lerp(playerPos, delta * 12);
      }

      // Check Collection (1.6^2 = 2.56)
      if (distSq < 2.56) {
        // Collected!
        collectedCoins += 1 * coinMultiplier;
        this.removeCoinAt(i);
        continue;
      }

      // Despawn if passed behind player
      if (coin.mesh.position.z > playerPos.z + 20) {
        this.removeCoinAt(i);
      }
    }

    // 3. Update Power-ups
    for (let i = this.powerUps.length - 1; i >= 0; i--) {
      const pu = this.powerUps[i];

      // Floating bob & rotation using continuous clock
      pu.group.rotation.y += delta * 2.5;
      pu.group.position.y = pu.y + Math.sin(this.animClock * 3.0 + pu.z) * 0.25;

      const podOuter = pu.group.getObjectByName('pod_outer');
      if (podOuter) {
        podOuter.rotation.x += delta * 1.5;
        podOuter.rotation.z += delta * 1.2;
      }

      // Check Collection (1.8^2 = 3.24)
      const distSq = pu.group.position.distanceToSquared(playerPos);
      if (distSq < 3.24) {
        // Power-up activated!
        this.activatePowerUp(pu.type);
        collectedPowerUp = pu.type;
        this.removePowerUpAt(i);
        continue;
      }

      // Despawn if passed
      if (pu.group.position.z > playerPos.z + 20) {
        this.removePowerUpAt(i);
      }
    }

    return { collectedCoins, collectedPowerUp };
  }

  public activatePowerUp(type: PowerUpType) {
    this.activePowerUps[type] = GAME_CONFIG.POWERUP_DURATIONS[type];
  }

  public consumeShield(): boolean {
    if (this.activePowerUps.shield > 0) {
      this.activePowerUps.shield = 0;
      return true; // Shield absorbed hit!
    }
    return false;
  }

  private removeCoinAt(index: number) {
    const coin = this.coins[index];
    coin.mesh.visible = false;
    this.coinPool.push(coin.mesh);
    this.coins.splice(index, 1);
  }

  private removePowerUpAt(index: number) {
    const pu = this.powerUps[index];
    pu.group.visible = false;

    if (!this.powerUpPool.has(pu.type)) {
      this.powerUpPool.set(pu.type, []);
    }
    this.powerUpPool.get(pu.type)!.push(pu.group);

    this.powerUps.splice(index, 1);
  }

  public clearAll() {
    for (let i = this.coins.length - 1; i >= 0; i--) {
      this.removeCoinAt(i);
    }
    for (let i = this.powerUps.length - 1; i >= 0; i--) {
      this.removePowerUpAt(i);
    }
    this.coins = [];
    this.powerUps = [];
    for (const key of Object.keys(this.activePowerUps) as PowerUpType[]) {
      this.activePowerUps[key] = 0;
    }
  }

  public destroy() {
    this.clearAll();

    // Dispose pooled coins
    for (const coinMesh of this.coinPool) {
      this.scene.remove(coinMesh);
    }
    this.coinPool = [];

    // Dispose pooled power-ups
    this.powerUpPool.forEach((list) => {
      list.forEach((grp) => {
        this.scene.remove(grp);
      });
    });
    this.powerUpPool.clear();

    // Dispose geometries
    this.coinGeo?.dispose();
    this.podGeo?.dispose();
    this.magnetGeo?.dispose();
    this.rocketBodyGeo?.dispose();
    this.rocketNoseGeo?.dispose();
    this.shieldSphereGeo?.dispose();
    this.badgeGeo?.dispose();
    this.arrowGeo?.dispose();

    // Dispose materials
    this.coinMaterial?.dispose();
    this.magnetMat?.dispose();
    this.rocketMat?.dispose();
    this.shieldMat?.dispose();
    this.doubleCoinsMat?.dispose();
    this.speedBoostMat?.dispose();
    this.podMat?.dispose();
  }
}
