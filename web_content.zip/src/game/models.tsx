import { useMemo } from "react";
import * as THREE from "three";
import { PAL, SPECIES, type SpeciesId } from "./data";
import { GRAD } from "./grad";

function Toon({
  color,
  emit = PAL.ink,
  ei = 0,
}: {
  color: string;
  emit?: string;
  ei?: number;
}) {
  return <meshToonMaterial color={color} gradientMap={GRAD} emissive={emit} emissiveIntensity={ei} />;
}

function Eyes({ y, z, gap, s = 0.07 }: { y: number; z: number; gap: number; s?: number }) {
  return (
    <group position={[0, y, z]}>
      {[-1, 1].map((side) => (
        <group key={side} position={[side * gap, 0, 0]}>
          <mesh>
            <sphereGeometry args={[s, 12, 12]} />
            <meshBasicMaterial color={PAL.cream} />
          </mesh>
          <mesh position={[side * s * 0.2, -s * 0.08, s * 0.7]}>
            <sphereGeometry args={[s * 0.48, 10, 10]} />
            <meshBasicMaterial color={PAL.ink} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

let blobTex: THREE.CanvasTexture | null = null;
function blobTexture() {
  if (blobTex || typeof document === "undefined") return blobTex;
  const c = document.createElement("canvas");
  c.width = 64;
  c.height = 64;
  const g = c.getContext("2d");
  if (!g) return null;
  const grd = g.createRadialGradient(32, 32, 4, 32, 32, 30);
  grd.addColorStop(0, "rgba(28,42,34,0.4)");
  grd.addColorStop(1, "rgba(28,42,34,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  blobTex = new THREE.CanvasTexture(c);
  return blobTex;
}

export function ShadowBlob({ s = 0.55 }: { s?: number }) {
  const tex = blobTexture();
  if (!tex) return null;
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.03, 0]}>
      <circleGeometry args={[s, 16]} />
      <meshBasicMaterial map={tex} transparent depthWrite={false} />
    </mesh>
  );
}

function bodyFor(id: SpeciesId) {
  if (id === "sproutkit") {
    return (
      <group>
        <mesh position={[0, 0.38, 0]} castShadow>
          <capsuleGeometry args={[0.22, 0.28, 4, 10]} />
          <Toon color={PAL.leaf} />
        </mesh>
        <mesh position={[0, 0.32, 0.16]} scale={[0.7, 0.55, 0.4]} castShadow>
          <sphereGeometry args={[0.22, 16, 12]} />
          <Toon color={PAL.cream} />
        </mesh>
        <mesh position={[0, 0.62, 0.16]} castShadow>
          <sphereGeometry args={[0.2, 16, 14]} />
          <Toon color={PAL.leafLite} />
        </mesh>
        <mesh position={[-0.12, 0.84, 0.08]} rotation={[0.2, 0, -0.4]} castShadow>
          <coneGeometry args={[0.08, 0.28, 8]} />
          <Toon color={PAL.leaf} />
        </mesh>
        <mesh position={[0.12, 0.84, 0.08]} rotation={[0.2, 0, 0.4]} castShadow>
          <coneGeometry args={[0.08, 0.28, 8]} />
          <Toon color={PAL.leaf} />
        </mesh>
        <mesh position={[0, 0.95, 0.02]} rotation={[0.4, 0, 0]} castShadow>
          <coneGeometry args={[0.07, 0.22, 6]} />
          <Toon color={PAL.leafLite} />
        </mesh>
        <mesh position={[0, 0.42, -0.28]} rotation={[0.8, 0, 0]} castShadow>
          <capsuleGeometry args={[0.06, 0.22, 3, 8]} />
          <Toon color={PAL.leaf} />
        </mesh>
        <Eyes y={0.66} z={0.32} gap={0.08} s={0.055} />
      </group>
    );
  }
  if (id === "ripplet") {
    return (
      <group>
        <mesh position={[0, 0.36, 0]} castShadow>
          <sphereGeometry args={[0.34, 18, 16]} />
          <Toon color={PAL.tide} />
        </mesh>
        <mesh position={[0, 0.28, 0.12]} scale={[0.72, 0.62, 0.5]} castShadow>
          <sphereGeometry args={[0.28, 16, 12]} />
          <Toon color={PAL.tideLite} />
        </mesh>
        <mesh position={[0, 0.46, -0.28]} rotation={[0.6, 0, 0]} scale={[1.2, 0.45, 0.7]} castShadow>
          <sphereGeometry args={[0.16, 12, 10]} />
          <Toon color={PAL.tide} />
        </mesh>
        <mesh position={[-0.14, 0.62, 0.08]} castShadow>
          <sphereGeometry args={[0.07, 10, 10]} />
          <Toon color={PAL.tide} />
        </mesh>
        <mesh position={[0.14, 0.62, 0.08]} castShadow>
          <sphereGeometry args={[0.07, 10, 10]} />
          <Toon color={PAL.tide} />
        </mesh>
        <Eyes y={0.48} z={0.28} gap={0.1} />
      </group>
    );
  }
  if (id === "emberpup") {
    return (
      <group>
        <mesh position={[0, 0.36, 0]} castShadow>
          <capsuleGeometry args={[0.2, 0.32, 4, 10]} />
          <Toon color={PAL.ember} />
        </mesh>
        <mesh position={[0, 0.58, 0.18]} castShadow>
          <sphereGeometry args={[0.18, 16, 14]} />
          <Toon color={PAL.ember} />
        </mesh>
        <mesh position={[0, 0.52, 0.3]} scale={[0.7, 0.55, 0.55]} castShadow>
          <sphereGeometry args={[0.12, 12, 10]} />
          <Toon color={PAL.cream} />
        </mesh>
        <mesh position={[-0.1, 0.78, 0.12]} rotation={[0.3, 0, -0.3]}>
          <coneGeometry args={[0.06, 0.2, 6]} />
          <Toon color={PAL.glow} emit={PAL.amber} ei={0.7} />
        </mesh>
        <mesh position={[0.1, 0.78, 0.12]} rotation={[0.3, 0, 0.3]}>
          <coneGeometry args={[0.06, 0.2, 6]} />
          <Toon color={PAL.glow} emit={PAL.amber} ei={0.7} />
        </mesh>
        <mesh position={[0, 0.4, -0.32]} rotation={[1.1, 0, 0]}>
          <coneGeometry args={[0.07, 0.24, 6]} />
          <Toon color={PAL.glow} emit={PAL.amber} ei={0.85} />
        </mesh>
        <Eyes y={0.64} z={0.32} gap={0.07} s={0.05} />
      </group>
    );
  }
  if (id === "mossbun") {
    return (
      <group>
        <mesh position={[0, 0.32, 0]} castShadow>
          <sphereGeometry args={[0.3, 16, 14]} />
          <Toon color={PAL.cream} />
        </mesh>
        <mesh position={[0, 0.52, 0]} scale={[1, 0.45, 1]} castShadow>
          <sphereGeometry args={[0.28, 14, 10]} />
          <Toon color={PAL.leaf} />
        </mesh>
        <mesh position={[-0.1, 0.78, 0]} rotation={[0, 0, -0.15]} castShadow>
          <capsuleGeometry args={[0.05, 0.32, 3, 6]} />
          <Toon color={PAL.cream} />
        </mesh>
        <mesh position={[0.1, 0.78, 0]} rotation={[0, 0, 0.15]} castShadow>
          <capsuleGeometry args={[0.05, 0.32, 3, 6]} />
          <Toon color={PAL.cream} />
        </mesh>
        <mesh position={[0, 0.28, -0.22]} castShadow>
          <sphereGeometry args={[0.08, 10, 10]} />
          <Toon color={PAL.creamDeep} />
        </mesh>
        <Eyes y={0.4} z={0.24} gap={0.09} />
      </group>
    );
  }
  if (id === "pebblin") {
    return (
      <group>
        <mesh position={[0, 0.22, 0]} scale={[1.15, 0.55, 0.9]} castShadow>
          <sphereGeometry args={[0.32, 14, 12]} />
          <Toon color={PAL.stone} />
        </mesh>
        <mesh position={[0, 0.38, 0]} scale={[1, 0.7, 0.85]} castShadow>
          <sphereGeometry args={[0.28, 12, 10]} />
          <Toon color={PAL.stoneLite} />
        </mesh>
        {[-0.18, 0, 0.18].map((x) =>
          [-0.12, 0.12].map((z) => (
            <mesh key={`${x}-${z}`} position={[x, 0.08, z]} castShadow>
              <sphereGeometry args={[0.045, 8, 8]} />
              <Toon color={PAL.ink} />
            </mesh>
          )),
        )}
        <mesh position={[-0.08, 0.48, 0.16]} rotation={[-0.6, 0, -0.2]}>
          <cylinderGeometry args={[0.012, 0.012, 0.18, 6]} />
          <Toon color={PAL.ink} />
        </mesh>
        <mesh position={[0.08, 0.48, 0.16]} rotation={[-0.6, 0, 0.2]}>
          <cylinderGeometry args={[0.012, 0.012, 0.18, 6]} />
          <Toon color={PAL.ink} />
        </mesh>
        <Eyes y={0.34} z={0.26} gap={0.1} s={0.045} />
      </group>
    );
  }
  if (id === "breekit") {
    return (
      <group>
        <mesh position={[0, 0.48, 0]} castShadow>
          <sphereGeometry args={[0.22, 16, 14]} />
          <Toon color={PAL.foam} />
        </mesh>
        <mesh position={[0, 0.7, 0.1]} castShadow>
          <sphereGeometry args={[0.14, 14, 12]} />
          <Toon color={PAL.cream} />
        </mesh>
        <mesh position={[0, 0.68, 0.24]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <coneGeometry args={[0.04, 0.12, 6]} />
          <Toon color={PAL.amber} />
        </mesh>
        <group name="wingL" position={[-0.18, 0.52, 0]}>
          <mesh position={[-0.18, 0, 0]} scale={[1.3, 0.18, 0.7]} castShadow>
            <sphereGeometry args={[0.2, 12, 8]} />
            <Toon color={PAL.tideLite} />
          </mesh>
        </group>
        <group name="wingR" position={[0.18, 0.52, 0]}>
          <mesh position={[0.18, 0, 0]} scale={[1.3, 0.18, 0.7]} castShadow>
            <sphereGeometry args={[0.2, 12, 8]} />
            <Toon color={PAL.tideLite} />
          </mesh>
        </group>
        <Eyes y={0.74} z={0.2} gap={0.06} s={0.045} />
      </group>
    );
  }
  if (id === "glimmoth") {
    return (
      <group>
        <mesh position={[0, 0.5, 0]} castShadow>
          <capsuleGeometry args={[0.12, 0.28, 4, 8]} />
          <Toon color={PAL.cream} />
        </mesh>
        <group name="wingL" position={[-0.08, 0.58, 0]}>
          <mesh position={[-0.22, 0.08, 0]} rotation={[0.2, 0.4, 0.5]}>
            <circleGeometry args={[0.28, 3]} />
            <meshBasicMaterial color={PAL.glow} transparent opacity={0.78} side={THREE.DoubleSide} />
          </mesh>
        </group>
        <group name="wingR" position={[0.08, 0.58, 0]}>
          <mesh position={[0.22, 0.08, 0]} rotation={[0.2, -0.4, -0.5]}>
            <circleGeometry args={[0.28, 3]} />
            <meshBasicMaterial color={PAL.amber} transparent opacity={0.78} side={THREE.DoubleSide} />
          </mesh>
        </group>
        <mesh position={[0, 0.78, 0.02]}>
          <sphereGeometry args={[0.06, 10, 10]} />
          <meshBasicMaterial color={PAL.glow} />
        </mesh>
        <Eyes y={0.62} z={0.12} gap={0.06} s={0.04} />
      </group>
    );
  }
  if (id === "thornox") {
    return (
      <group>
        <mesh position={[0, 0.38, 0]} scale={[1.25, 0.8, 0.9]} castShadow>
          <sphereGeometry args={[0.34, 16, 12]} />
          <Toon color={PAL.leaf} />
        </mesh>
        <mesh position={[0, 0.42, 0.36]} castShadow>
          <sphereGeometry args={[0.16, 12, 12]} />
          <Toon color={PAL.leafLite} />
        </mesh>
        <mesh position={[-0.08, 0.36, 0.5]} rotation={[Math.PI / 2, 0, 0.2]} castShadow>
          <coneGeometry args={[0.035, 0.14, 6]} />
          <Toon color={PAL.cream} />
        </mesh>
        <mesh position={[0.08, 0.36, 0.5]} rotation={[Math.PI / 2, 0, -0.2]} castShadow>
          <coneGeometry args={[0.035, 0.14, 6]} />
          <Toon color={PAL.cream} />
        </mesh>
        {[
          [-0.18, 0.62, 0],
          [0.16, 0.66, 0.05],
          [0, 0.64, -0.12],
        ].map((pos) => (
          <mesh key={pos.join(":")} position={pos as [number, number, number]} castShadow>
            <coneGeometry args={[0.05, 0.18, 6]} />
            <Toon color={PAL.mossDeep} />
          </mesh>
        ))}
        <Eyes y={0.5} z={0.48} gap={0.07} s={0.045} />
      </group>
    );
  }
  if (id === "dewdrop") {
    return (
      <group>
        <mesh position={[0, 0.34, 0]}>
          <sphereGeometry args={[0.32, 18, 16]} />
          <meshToonMaterial
            color={PAL.tideLite}
            gradientMap={GRAD}
            transparent
            opacity={0.78}
            emissive={PAL.tide}
            emissiveIntensity={0.25}
          />
        </mesh>
        <mesh position={[0, 0.3, 0]}>
          <sphereGeometry args={[0.16, 12, 12]} />
          <meshBasicMaterial color={PAL.foam} transparent opacity={0.85} />
        </mesh>
        <mesh position={[0, 0.66, 0]}>
          <sphereGeometry args={[0.06, 10, 10]} />
          <Toon color={PAL.tide} />
        </mesh>
        <Eyes y={0.42} z={0.26} gap={0.09} />
      </group>
    );
  }
  return (
    <group>
      <mesh position={[0, 0.34, 0]} castShadow>
        <capsuleGeometry args={[0.16, 0.32, 4, 8]} />
        <Toon color={PAL.ink} />
      </mesh>
      <mesh position={[0, 0.58, 0.14]} castShadow>
        <sphereGeometry args={[0.15, 14, 12]} />
        <Toon color={PAL.ink} />
      </mesh>
      <mesh position={[-0.08, 0.74, 0.08]} rotation={[0, 0, -0.4]} castShadow>
        <coneGeometry args={[0.045, 0.12, 5]} />
        <Toon color={PAL.ink} />
      </mesh>
      <mesh position={[0.08, 0.74, 0.08]} rotation={[0, 0, 0.4]} castShadow>
        <coneGeometry args={[0.045, 0.12, 5]} />
        <Toon color={PAL.ink} />
      </mesh>
      <mesh position={[0.1, 0.48, 0.08]}>
        <sphereGeometry args={[0.035, 8, 8]} />
        <meshBasicMaterial color={PAL.ember} />
      </mesh>
      <mesh position={[-0.06, 0.4, 0.12]}>
        <sphereGeometry args={[0.028, 8, 8]} />
        <meshBasicMaterial color={PAL.amber} />
      </mesh>
      <mesh position={[0, 0.36, -0.28]} rotation={[0.9, 0, 0]}>
        <capsuleGeometry args={[0.035, 0.2, 3, 6]} />
        <Toon color={PAL.ink} />
      </mesh>
      <mesh position={[0, 0.32, -0.42]}>
        <sphereGeometry args={[0.045, 8, 8]} />
        <meshBasicMaterial color={PAL.ember} />
      </mesh>
      <Eyes y={0.62} z={0.26} gap={0.06} s={0.045} />
    </group>
  );
}

export function PalModel({ species }: { species: SpeciesId }) {
  const spec = SPECIES[species];
  const inner = useMemo(() => bodyFor(species), [species]);
  return (
    <group>
      {inner}
      <mesh name="flash">
        <sphereGeometry args={[0.55, 12, 10]} />
        <meshBasicMaterial color={PAL.cream} transparent opacity={0} depthWrite={false} />
      </mesh>
      <group name="hp" position={[0, spec.head, 0]} visible={false}>
        <mesh>
          <planeGeometry args={[0.84, 0.09]} />
          <meshBasicMaterial color={PAL.ink} />
        </mesh>
        <mesh name="fill" position={[0, 0, 0.02]}>
          <planeGeometry args={[0.76, 0.05]} />
          <meshBasicMaterial color={PAL.amber} />
        </mesh>
      </group>
      <ShadowBlob s={0.5} />
    </group>
  );
}

export function PlayerModel() {
  return (
    <group>
      <group name="legL" position={[-0.14, 0.62, 0]}>
        <mesh position={[0, -0.28, 0]} castShadow>
          <capsuleGeometry args={[0.07, 0.26, 3, 8]} />
          <Toon color={PAL.ink} />
        </mesh>
      </group>
      <group name="legR" position={[0.14, 0.62, 0]}>
        <mesh position={[0, -0.28, 0]} castShadow>
          <capsuleGeometry args={[0.07, 0.26, 3, 8]} />
          <Toon color={PAL.ink} />
        </mesh>
      </group>
      <mesh position={[0, 0.86, 0]} castShadow>
        <capsuleGeometry args={[0.2, 0.28, 4, 10]} />
        <Toon color={PAL.moss} />
      </mesh>
      <mesh position={[0, 0.78, -0.16]} castShadow>
        <boxGeometry args={[0.26, 0.3, 0.12]} />
        <Toon color={PAL.wood} />
      </mesh>
      <group name="armL" position={[-0.3, 1.02, 0]}>
        <mesh position={[0, -0.18, 0]} castShadow>
          <capsuleGeometry args={[0.055, 0.22, 3, 6]} />
          <Toon color={PAL.skin} />
        </mesh>
      </group>
      <group name="armR" position={[0.3, 1.02, 0]}>
        <mesh position={[0, -0.18, 0.08]} rotation={[0.6, 0, 0]} castShadow>
          <capsuleGeometry args={[0.055, 0.22, 3, 6]} />
          <Toon color={PAL.skin} />
        </mesh>
        <mesh position={[0, -0.36, 0.18]} rotation={[0.4, 0, 0]} castShadow>
          <cylinderGeometry args={[0.03, 0.045, 0.42, 6]} />
          <Toon color={PAL.woodDark} />
        </mesh>
      </group>
      <mesh position={[0, 1.22, 0]} castShadow>
        <sphereGeometry args={[0.2, 16, 14]} />
        <Toon color={PAL.skin} />
      </mesh>
      <mesh position={[0, 1.34, 0]} scale={[1.05, 0.7, 1.05]} castShadow>
        <sphereGeometry args={[0.2, 14, 10]} />
        <Toon color={PAL.hair} />
      </mesh>
      <mesh position={[0, 1.08, 0]} rotation={[Math.PI / 2.4, 0, 0]}>
        <torusGeometry args={[0.16, 0.045, 8, 14]} />
        <Toon color={PAL.amber} />
      </mesh>
      <mesh position={[0.12, 0.98, 0.12]} rotation={[0.4, 0, 0.4]} castShadow>
        <boxGeometry args={[0.08, 0.22, 0.04]} />
        <Toon color={PAL.amber} />
      </mesh>
      <Eyes y={1.24} z={0.16} gap={0.07} s={0.045} />
      <mesh name="flash">
        <sphereGeometry args={[0.7, 12, 10]} />
        <meshBasicMaterial color={PAL.cream} transparent opacity={0} depthWrite={false} />
      </mesh>
      <ShadowBlob s={0.46} />
    </group>
  );
}

export function KeeperModel() {
  return (
    <group>
      <mesh position={[0, 0.78, 0]} castShadow>
        <capsuleGeometry args={[0.2, 0.36, 4, 8]} />
        <Toon color={PAL.creamDeep} />
      </mesh>
      <mesh position={[0, 1.16, 0]} castShadow>
        <sphereGeometry args={[0.18, 14, 12]} />
        <Toon color={PAL.skin} />
      </mesh>
      <mesh position={[0, 1.28, 0]} castShadow>
        <cylinderGeometry args={[0.22, 0.2, 0.08, 12]} />
        <Toon color={PAL.amber} />
      </mesh>
      <mesh position={[0, 1.34, 0]} castShadow>
        <cylinderGeometry args={[0.34, 0.34, 0.035, 14]} />
        <Toon color={PAL.wood} />
      </mesh>
      <group name="niaArm" position={[0.28, 0.98, 0]}>
        <mesh position={[0.02, -0.16, 0.08]} rotation={[0.8, 0, 0.2]} castShadow>
          <capsuleGeometry args={[0.05, 0.2, 3, 6]} />
          <Toon color={PAL.skin} />
        </mesh>
      </group>
      <Eyes y={1.18} z={0.15} gap={0.06} s={0.04} />
      <ShadowBlob s={0.42} />
    </group>
  );
}

export function HarvestTree() {
  return (
    <group>
      <mesh position={[0, 0.45, 0]} castShadow>
        <cylinderGeometry args={[0.12, 0.16, 0.9, 8]} />
        <Toon color={PAL.wood} />
      </mesh>
      <mesh position={[0, 1.15, 0]} castShadow>
        <sphereGeometry args={[0.48, 14, 12]} />
        <Toon color={PAL.leaf} />
      </mesh>
      <mesh position={[0, 0.7, 0.18]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.2, 0.035, 6, 12]} />
        <meshBasicMaterial color={PAL.amber} />
      </mesh>
    </group>
  );
}

export function HarvestRock() {
  return (
    <group>
      <mesh position={[0, 0.28, 0]} scale={[1.1, 0.7, 1]} castShadow>
        <dodecahedronGeometry args={[0.42, 0]} />
        <Toon color={PAL.stone} />
      </mesh>
      <mesh position={[0.12, 0.55, 0.08]}>
        <octahedronGeometry args={[0.12, 0]} />
        <meshStandardMaterial color={PAL.glow} emissive={PAL.amber} emissiveIntensity={0.7} roughness={0.35} />
      </mesh>
    </group>
  );
}

export function BerryBush() {
  return (
    <group>
      <mesh position={[0, 0.32, 0]} castShadow>
        <sphereGeometry args={[0.38, 14, 12]} />
        <Toon color={PAL.moss} />
      </mesh>
      {[
        [0.16, 0.48, 0.18],
        [-0.14, 0.42, 0.2],
        [0.02, 0.55, 0.08],
        [-0.08, 0.28, 0.26],
      ].map((pos) => (
        <mesh key={pos.join(":")} position={pos as [number, number, number]}>
          <sphereGeometry args={[0.07, 8, 8]} />
          <Toon color={PAL.ember} />
        </mesh>
      ))}
    </group>
  );
}
