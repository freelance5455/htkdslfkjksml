import * as THREE from 'three';

export const BodycamOpticalShader = {
  uniforms: {
    tDiffuse: { value: null as THREE.Texture | null },
    uTime: { value: 0 },
    uDistortion: { value: 0.22 },
    uAberration: { value: 0.0045 },
    uGrain: { value: 0.065 },
    uVignette: { value: 0.55 },
    uOpticalMode: { value: 0 }, // 0 = standard, 1 = lowlight, 2 = ir_night
    uImpactShock: { value: 0 },
    uDamagePulse: { value: 0 },
    uAspect: { value: 16 / 9 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float uTime;
    uniform float uDistortion;
    uniform float uAberration;
    uniform float uGrain;
    uniform float uVignette;
    uniform int uOpticalMode;
    uniform float uImpactShock;
    uniform float uDamagePulse;
    uniform float uAspect;
    varying vec2 vUv;

    float hash12(vec2 p) {
      vec3 p3 = fract(vec3(p.xyx) * 0.1031);
      p3 += dot(p3, p3.yzx + 33.33);
      return fract((p3.x + p3.y) * p3.z);
    }

    vec2 barrelDistort(vec2 uv, float k) {
      vec2 centered = uv - 0.5;
      centered.x *= uAspect;
      float r2 = dot(centered, centered);
      float factor = 1.0 + k * r2 + (k * 0.42) * r2 * r2;
      vec2 warped = centered * factor;
      warped.x /= uAspect;
      return warped + 0.5;
    }

    void main() {
      // Subtle rolling-shutter micro tear during gunfire or impact
      vec2 baseUv = vUv;
      if (uImpactShock > 0.001) {
        float tear = sin(baseUv.y * 42.0 + uTime * 90.0) * 0.0035 * uImpactShock;
        baseUv.x += tear;
      }

      // Barrel fisheye warp (scaled slightly down so corners stay filled cleanly)
      vec2 uv = barrelDistort(baseUv, uDistortion * 0.36);
      // Zoom slightly inward to avoid black border fringes
      uv = (uv - 0.5) * (1.0 - uDistortion * 0.085) + 0.5;

      // Clamp gracefully outside bounds
      if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
        gl_FragColor = vec4(0.01, 0.01, 0.012, 1.0);
        return;
      }

      // Radial lateral chromatic aberration
      vec2 dir = uv - 0.5;
      float dist = length(dir);
      float ca = uAberration * (0.35 + dist * 2.1 + uImpactShock * 1.4);

      float r = texture2D(tDiffuse, uv - dir * ca).r;
      float g = texture2D(tDiffuse, uv).g;
      float b = texture2D(tDiffuse, uv + dir * ca).b;
      vec3 col = vec3(r, g, b);

      // Subtle bodycam lens glare / micro-dust scatter near bright pixels
      float lum = dot(col, vec3(0.2126, 0.7152, 0.0722));
      float speck = smoothstep(0.92, 0.99, hash12(floor(uv * 220.0)));
      col += speck * max(0.0, lum - 0.25) * 0.05;

      // Optical sensor color science
      if (uOpticalMode == 0) {
        // Standard bodycam CMOS: crisp contrast, slight cool shadow / warm highlight split
        col = pow(max(col, vec3(0.0)), vec3(0.96));
        float luma = dot(col, vec3(0.299, 0.587, 0.114));
        col = mix(vec3(luma), col, 0.86);
        col = mix(col, col * vec3(0.95, 0.99, 1.04), smoothstep(0.45, 0.0, luma) * 0.45);
      } else if (uOpticalMode == 1) {
        // Low-Light high-ISO boost: lifted shadows, slightly colder sensor curve
        col = pow(max(col, vec3(0.0)), vec3(0.84)) * 1.18;
        float luma = dot(col, vec3(0.299, 0.587, 0.114));
        col = mix(vec3(luma), col, 0.72);
        col += vec3(0.008, 0.014, 0.018);
      } else {
        // IR Night Gain: crisp monochrome/slate-phosphor night vision
        float luma = dot(col, vec3(0.25, 0.65, 0.10));
        float boosted = pow(max(luma * 1.65, 0.0), 0.78);
        col = vec3(boosted * 0.78, boosted * 1.04, boosted * 0.92);
      }

      // High-ISO CMOS luminance noise (stronger in shadows)
      float shadowFactor = mix(1.45, 0.45, clamp(lum * 1.8, 0.0, 1.0));
      float noise = (hash12(uv * vec2(1280.0, 720.0) + fract(uTime * 37.0) * 193.0) - 0.5);
      float modeGrain = (uOpticalMode == 1) ? 1.45 : (uOpticalMode == 2 ? 1.35 : 1.0);
      col += noise * uGrain * shadowFactor * modeGrain;

      // Very subtle horizontal CMOS scanline shimmer
      float scan = sin(uv.y * 920.0 + uTime * 8.0) * 0.008 * modeGrain;
      col *= (1.0 - scan);

      // Authentic rounded-corner bodycam lens housing vignette
      float vig = smoothstep(0.88, 0.24, dist * (0.95 + uVignette * 0.35));
      col *= mix(1.0, vig, 0.72);

      // Damage pulse edge tint
      if (uDamagePulse > 0.001) {
        float edge = smoothstep(0.28, 0.76, dist);
        col = mix(col, vec3(0.75, 0.04, 0.04), edge * uDamagePulse * 0.65);
      }

      gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
    }
  `,
};
