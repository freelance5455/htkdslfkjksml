import { memo,useMemo,useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { CuboidCollider, RigidBody } from '@react-three/rapier';
import { CanvasTexture, Color, DoubleSide, InstancedMesh, Object3D, SRGBColorSpace, BufferGeometry, Float32BufferAttribute } from 'three';
import type { Footballer,MatchEngine } from './engine';

function turfTexture(){const c=document.createElement('canvas');c.width=1536;c.height=1000;const ctx=c.getContext('2d')!;
 ctx.fillStyle='#2c8243';ctx.fillRect(0,0,1536,1000);for(let i=0;i<12;i++){ctx.fillStyle=i%2?'#338748':'#2a7e41';ctx.fillRect(i*128,0,128,1000);}
 let seed=21;const rnd=()=>{seed=(seed*16807)%2147483647;return(seed-1)/2147483646;};
 for(let i=0;i<17000;i++){ctx.fillStyle=rnd()>.5?'rgba(255,255,255,.027)':'rgba(4,38,18,.065)';ctx.fillRect(rnd()*1536,rnd()*1000,.8+rnd()*2,.7+rnd()*3);}
 const sx=(x:number)=>(x+52.5)/105*1490+23, sz=(z:number)=>(z+34)/68*954+23;
 ctx.strokeStyle='#f0f6ec';ctx.lineWidth=3.2;ctx.strokeRect(sx(-52.5),sz(-34),sx(52.5)-sx(-52.5),sz(34)-sz(-34));
 ctx.beginPath();ctx.moveTo(sx(0),sz(-34));ctx.lineTo(sx(0),sz(34));ctx.stroke();
 ctx.beginPath();ctx.ellipse(sx(0),sz(0),(9.15/105)*1490,(9.15/68)*954,0,0,Math.PI*2);ctx.stroke();
 for(const dir of [-1,1]){const center=dir*52.5;const x=dir*36,xSmall=dir*47;
 ctx.strokeRect(Math.min(sx(center),sx(x)),sz(-20.16),Math.abs(sx(center)-sx(x)),sz(20.16)-sz(-20.16));
 ctx.strokeRect(Math.min(sx(center),sx(xSmall)),sz(-9.16),Math.abs(sx(center)-sx(xSmall)),sz(9.16)-sz(-9.16));
 ctx.fillStyle='#f0f6ec';ctx.beginPath();ctx.ellipse(sx(dir*41.5),sz(0),3,3,0,0,Math.PI*2);ctx.fill();}
 ctx.beginPath();ctx.ellipse(sx(0),sz(0),3,3,0,0,Math.PI*2);ctx.fill();
 const texture=new CanvasTexture(c);texture.colorSpace=SRGBColorSpace;texture.anisotropy=8;return texture;}
function Crowd({quality}:{quality:'Low'|'Medium'|'High'}){const seats=quality==='Low'?900:quality==='Medium'?2100:3800;
 const matrices=useMemo(()=>{const dummy=new Object3D(),color=new Color();const result:{matrix:Float32Array;color:Color}[]=[];let seed=614;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
 for(let i=0;i<seats;i++){const edge=i%4,layer=Math.floor(i/4)%23,k=Math.floor(i/(4*23));const fraction=(k+.4*rnd())/Math.ceil(seats/(4*23));const y=3+layer*.43+rnd()*.25;let x=0,z=0;
 if(edge===0){x=-62+fraction*124;z=-41-layer*.72;}else if(edge===1){x=-62+fraction*124;z=41+layer*.72;}else if(edge===2){x=-62-layer*.72;z=-39+fraction*78;}else{x=62+layer*.72;z=-39+fraction*78;}
 dummy.position.set(x,y,z);dummy.rotation.set(0,rnd()*6.28,0);dummy.scale.set(.68+rnd()*.4,.8+rnd()*.5,.7+rnd()*.35);dummy.updateMatrix();
 const colors=['#d4e2ce','#e8bb76','#26745c','#233e47','#e8e7dd','#c18b54','#5d807f','#d6cfd2'];color.set(colors[Math.floor(rnd()*colors.length)]);result.push({matrix:dummy.matrix.toArray() as unknown as Float32Array,color:color.clone()});}
 return result;},[seats]);
 // Ref callback avoids frame-by-frame object allocation.
 const fill=(instance:InstancedMesh|null)=>{if(!instance)return;const dummy=new Object3D();matrices.forEach((item,i)=>{dummy.matrix.fromArray(item.matrix);instance.setMatrixAt(i,dummy.matrix);instance.setColorAt(i,item.color);});instance.instanceMatrix.needsUpdate=true;if(instance.instanceColor)instance.instanceColor.needsUpdate=true;};
 return <instancedMesh ref={fill} args={[undefined,undefined,seats]} castShadow={false}><sphereGeometry args={[.31,5,4]}/><meshStandardMaterial roughness={.91}/></instancedMesh>;
}
function Goal({side}:{side:-1|1}){const x=side*52.5,back=x+side*2.5;const nodes:number[]=[];const line=(a:[number,number,number],b:[number,number,number])=>nodes.push(...a,...b);
 for(let y=0;y<=2.45;y+=.28){line([x,y,-3.66],[back,y,-3.66]);line([x,y,3.66],[back,y,3.66]);line([back,y,-3.66],[back,y,3.66]);}
 for(let z=-3.66;z<=3.66;z+=.36){line([x,2.45,z],[back,2.45,z]);line([back,0,z],[back,2.45,z]);}
 const geom=useMemo(()=>{const g=new BufferGeometry();g.setAttribute('position',new Float32BufferAttribute(nodes,3));return g;},[]);
 return <group><mesh position={[x,1.25,-3.66]}><cylinderGeometry args={[.07,.07,2.5,10]}/><meshStandardMaterial color="#f6f8f5" metalness={.35}/></mesh>
 <mesh position={[x,1.25,3.66]}><cylinderGeometry args={[.07,.07,2.5,10]}/><meshStandardMaterial color="#f6f8f5" metalness={.35}/></mesh>
 <mesh position={[x,2.5,0]} rotation={[Math.PI/2,0,0]}><cylinderGeometry args={[.07,.07,7.32,10]}/><meshStandardMaterial color="#f6f8f5" metalness={.35}/></mesh>
 <lineSegments geometry={geom}><lineBasicMaterial color="#dae7dd" transparent opacity={.45}/></lineSegments>
 <RigidBody type="fixed" colliders={false}><CuboidCollider args={[.09,1.25,.08]} position={[x,1.25,-3.66]}/><CuboidCollider args={[.09,1.25,.08]} position={[x,1.25,3.66]}/><CuboidCollider args={[.08,.075,3.65]} position={[x,2.5,0]}/></RigidBody></group>;
}
function Seating(){return <group>{[-1,1].map(sign=><group key={sign}>
 <mesh position={[0,1.3,sign*44]}><boxGeometry args={[135,2.6,6]}/><meshStandardMaterial color="#182c2b"/></mesh>
 <mesh position={[0,5.2,sign*54]} rotation={[sign*-.19,0,0]}><boxGeometry args={[135,.35,18]}/><meshStandardMaterial color="#334e4a"/></mesh>
 <mesh position={[0,9.6,sign*67]} rotation={[sign*-.28,0,0]}><boxGeometry args={[138,.4,17]}/><meshStandardMaterial color="#496b63"/></mesh>
 </group>)}{[-1,1].map(sign=><group key={`end${sign}`}>
 <mesh position={[sign*63,1.3,0]}><boxGeometry args={[7,2.6,88]}/><meshStandardMaterial color="#182c2b"/></mesh>
 <mesh position={[sign*74,5,0]} rotation={[0,0,sign*.2]}><boxGeometry args={[20,.5,92]}/><meshStandardMaterial color="#334e4a"/></mesh>
 </group>)}
 {[-1,1].map(sign=><group key={`tier${sign}`}><mesh position={[0,13,sign*79]} rotation={[sign*-.32,0,0]}><boxGeometry args={[142,.6,18]}/><meshStandardMaterial color="#294640"/></mesh></group>)}
 </group>}
function Boards(){const ads=['ULTIMATE FC','THE CLUB SHOP','PLAY YOUR WAY','MATCHDAY','ULTIMATE FC','THE CLUB SHOP'];return <group>
 {[-1,1].map(sign=><group key={sign} position={[0,.9,sign*36.6]}>{Array.from({length:12},(_,i)=><mesh key={i} position={[-48.1+i*8.75,0,0]}><boxGeometry args={[8.7,1.25,.22]}/><meshStandardMaterial color={i%3===0?'#e4f2e6':'#123d36'} emissive={i%3===0?'#0b301b':'#08211e'} emissiveIntensity={.13}/></mesh>)}
 {ads.map((_,i)=><mesh key={`stripe${i}`} position={[-40+i*17,.64,sign*.02]}><boxGeometry args={[8,.04,.25]}/><meshBasicMaterial color="#c2e3c9"/></mesh>)}
 </group>)}
 {[-1,1].map(sign=><mesh key={sign} position={[sign*55.3,.9,0]}><boxGeometry args={[.22,1.3,76]}/><meshStandardMaterial color="#144638"/></mesh>)}
 </group>}
function Floodlights(){return <group>{[-1,1].flatMap(x=>[-1,1].map(z=><group key={`${x}-${z}`} position={[x*66,0,z*53]}>
 <mesh position={[0,13,0]}><cylinderGeometry args={[.19,.29,26,6]}/><meshStandardMaterial color="#a4b3af" metalness={.6}/></mesh>
 <mesh position={[0,26,0]}><boxGeometry args={[7,1.5,.7]}/><meshStandardMaterial color="#eff6ea" emissive="#dde9d5" emissiveIntensity={.65}/></mesh>
 <pointLight position={[0,25,0]} intensity={10} distance={120} decay={2} color="#eaf2e6"/>
 </group>))}</group>}
export const Stadium=memo(function Stadium({graphics}:{graphics:'Low'|'Medium'|'High'}){const texture=useMemo(turfTexture,[]);
 return <group>
 <ambientLight intensity={.85}/><hemisphereLight args={['#f1f8ef','#244b36',1.4]}/><directionalLight position={[-35,74,20]} intensity={2.15} castShadow={graphics==='High'} shadow-mapSize-width={2048} shadow-mapSize-height={2048} shadow-camera-left={-80} shadow-camera-right={80} shadow-camera-top={80} shadow-camera-bottom={-80}/>
 <mesh rotation={[-Math.PI/2,0,0]} position={[0,-.18,0]} receiveShadow><planeGeometry args={[250,230]}/><meshStandardMaterial color="#203b31" roughness={1}/></mesh>
 <mesh rotation={[-Math.PI/2,0,0]} receiveShadow position={[0,-.065,0]}><planeGeometry args={[108,71]}/><meshStandardMaterial map={texture} roughness={1} metalness={0}/></mesh>
 <RigidBody type="fixed" colliders={false}><CuboidCollider args={[115,.1,100]} position={[0,-.18,0]}/></RigidBody>
 <Seating/><Boards/><Goal side={-1}/><Goal side={1}/><Floodlights/><Crowd quality={graphics}/>
 {[-1,1].map(s=><group key={s} position={[-17,.23,s*36.7]}>{Array.from({length:7},(_,i)=><mesh key={i} position={[i*1.05,0,0]}><boxGeometry args={[.8,.33,.8]}/><meshStandardMaterial color="#546d64"/></mesh>)}</group>)}
 </group>;
});
export const FootballAvatar=memo(function FootballAvatar({p,engine}:{p:Footballer;engine:MatchEngine}){
 const group=useRef<import('three').Group>(null);const selectedRing=useRef<import('three').Mesh>(null),selectedArrow=useRef<import('three').Mesh>(null);const leg1=useRef<import('three').Group>(null),leg2=useRef<import('three').Group>(null),arm1=useRef<import('three').Group>(null),arm2=useRef<import('three').Group>(null);
 const team=p.side===0?'#f2f5ef':'#203b3b';const accent=p.side===0?'#126d51':'#dfac55';const skin=['#ad7149','#d2a27e','#e0b38c','#82533d','#f1c5a0'][(p.id*3)%5];
 useFrame(()=>{if(!group.current)return;group.current.position.set(p.x,0,p.z);group.current.rotation.y= -p.face;
 const moving=Math.min(1,Math.hypot(p.vx,p.vz)/7);const swing=Math.sin(p.anim*2.4)*moving*.72;
 if(leg1.current)leg1.current.rotation.z=swing;if(leg2.current)leg2.current.rotation.z=-swing;
 if(arm1.current)arm1.current.rotation.z=-swing*.67;if(arm2.current)arm2.current.rotation.z=swing*.67;const selected=p.side===0&&p.slot===engine.selected;if(selectedRing.current)selectedRing.current.visible=selected;if(selectedArrow.current)selectedArrow.current.visible=selected;});
 return <group ref={group}>
 <mesh position={[0,.035,0]} rotation={[-Math.PI/2,0,0]}><circleGeometry args={[.58,20]}/><meshBasicMaterial color="#071c13" transparent opacity={.16} depthWrite={false}/></mesh>
 <mesh ref={selectedRing} position={[0,.047,0]} rotation={[-Math.PI/2,0,0]}><ringGeometry args={[.63,.78,32]}/><meshBasicMaterial color="#e9f8ac" side={DoubleSide}/></mesh>
 <mesh position={[0,1.25,0]} castShadow><capsuleGeometry args={[.32,.45,4,9]}/><meshStandardMaterial color={team} roughness={.8}/></mesh>
 <mesh position={[.2,1.24,0]}><boxGeometry args={[.12,.65,.49]}/><meshStandardMaterial color={accent}/></mesh>
 <mesh position={[0,.9,0]} castShadow><boxGeometry args={[.62,.27,.59]}/><meshStandardMaterial color={accent}/></mesh>
 <mesh position={[0,1.95,0]} castShadow><sphereGeometry args={[.23,10,8]}/><meshStandardMaterial color={skin} roughness={.9}/></mesh>
 <mesh position={[.17,1.98,0]}><sphereGeometry args={[.09,8,6]}/><meshStandardMaterial color={skin}/></mesh>
 <mesh position={[0,2.13,-.03]}><sphereGeometry args={[.235,10,7,0,6.28,0,1.15]}/><meshStandardMaterial color="#302820"/></mesh>
 {[-1,1].map((s,i)=><group key={s} ref={i===0?leg1:leg2} position={[0,.77,s*.19]}>
 <mesh position={[0,-.25,0]} castShadow><capsuleGeometry args={[.12,.35,4,7]}/><meshStandardMaterial color={skin}/></mesh>
 <mesh position={[0,-.58,0]}><cylinderGeometry args={[.13,.14,.3,7]}/><meshStandardMaterial color={team}/></mesh>
 <mesh position={[.16,-.76,0]}><boxGeometry args={[.43,.14,.24]}/><meshStandardMaterial color={accent}/></mesh></group>)}
 {[-1,1].map((s,i)=><group key={`arm${s}`} ref={i===0?arm1:arm2} position={[0,1.56,s*.4]}>
 <mesh position={[0,-.14,0]}><capsuleGeometry args={[.13,.26,3,7]}/><meshStandardMaterial color={team}/></mesh>
 <mesh position={[0,-.39,0]}><sphereGeometry args={[.12,7,6]}/><meshStandardMaterial color={skin}/></mesh>
 </group>)}
 <mesh ref={selectedArrow} position={[0,2.7,0]} rotation={[Math.PI/2,0,0]}><coneGeometry args={[.28,.37,3]}/><meshBasicMaterial color="#e9f8ac"/></mesh>
 </group>;
});
