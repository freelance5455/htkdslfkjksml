/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ArrowConfig, Direction, LevelData, Point } from './types';
import { DIR_DELTA, validateAndEvaluatePuzzle } from './solver';
import { getDifficultyProfile } from './difficulty';

const DIRECTIONS: Direction[] = ['UP', 'RIGHT', 'DOWN', 'LEFT'];

export type PresetShapeType =
  | 'circle'
  | 'square'
  | 'triangle'
  | 'star'
  | 'heart'
  | 'leaf'
  | 'diamond'
  | 'fortress'
  | 'cloud'
  | 'crescent'
  | 'shield'
  | 'hourglass'
  | 'crown';

/**
 * Deterministic PRNG (Mulberry32) for reproducible campaign & seeded levels
 */
export function createSeededRng(seed: number): () => number {
  let t = seed >>> 0;
  return function () {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Standard 2D Ray-Casting algorithm for point-in-polygon test
 */
export function isPointInPolygon(p: Point, polygon: Point[]): boolean {
  if (polygon.length < 3) return false;
  let inside = false;
  const n = polygon.length;

  for (let i = 0, j = n - 1; i < n; j = i++) {
    const xi = polygon[i].x;
    const yi = polygon[i].y;
    const xj = polygon[j].x;
    const yj = polygon[j].y;

    const intersect =
      yi > p.y !== yj > p.y && p.x < ((xj - xi) * (p.y - yi)) / (yj - yi + 1e-9) + xi;
    if (intersect) inside = !inside;
  }

  return inside;
}

/**
 * Computes bounding box of a point set
 */
export function getPolygonBounds(polygon: Point[]) {
  let minX = Infinity;
  let maxX = -Infinity;
  let minY = Infinity;
  let maxY = -Infinity;

  for (const pt of polygon) {
    if (pt.x < minX) minX = pt.x;
    if (pt.x > maxX) maxX = pt.x;
    if (pt.y < minY) minY = pt.y;
    if (pt.y > maxY) maxY = pt.y;
  }

  return {
    minX,
    maxX,
    minY,
    maxY,
    width: Math.max(1, maxX - minX),
    height: Math.max(1, maxY - minY),
  };
}

/**
 * Computes signed area and perimeter of a closed polygon
 */
function getPolygonMetrics(polygon: Point[]): { area: number; perimeter: number } {
  const n = polygon.length;
  if (n < 3) return { area: 0, perimeter: 0 };

  let areaSum = 0;
  let perimeter = 0;
  for (let i = 0; i < n; i++) {
    const a = polygon[i];
    const b = polygon[(i + 1) % n];
    areaSum += a.x * b.y - b.x * a.y;
    perimeter += Math.hypot(b.x - a.x, b.y - a.y);
  }

  return { area: Math.abs(areaSum) / 2, perimeter };
}

/**
 * Ramer-Douglas-Peucker simplification for closed polygon strokes
 */
export function simplifyPolygon(points: Point[], epsilon: number): Point[] {
  if (points.length <= 4) return points;

  const perpDist = (p: Point, a: Point, b: Point): number => {
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const lenSq = dx * dx + dy * dy;
    if (lenSq < 1e-6) return Math.hypot(p.x - a.x, p.y - a.y);
    const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / lenSq));
    return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
  };

  const rdp = (pts: Point[]): Point[] => {
    if (pts.length < 3) return pts;
    let maxD = 0;
    let idx = 0;
    const first = pts[0];
    const last = pts[pts.length - 1];
    for (let i = 1; i < pts.length - 1; i++) {
      const d = perpDist(pts[i], first, last);
      if (d > maxD) {
        maxD = d;
        idx = i;
      }
    }
    if (maxD > epsilon) {
      const left = rdp(pts.slice(0, idx + 1));
      const right = rdp(pts.slice(idx));
      return [...left.slice(0, -1), ...right];
    }
    return [first, last];
  };

  const clean =
    Math.hypot(points[0].x - points[points.length - 1].x, points[0].y - points[points.length - 1].y) < 10
      ? points.slice(0, -1)
      : points;

  let farIdx = 1;
  let farDist = 0;
  for (let i = 1; i < clean.length; i++) {
    const d = Math.hypot(clean[i].x - clean[0].x, clean[i].y - clean[0].y);
    if (d > farDist) {
      farDist = d;
      farIdx = i;
    }
  }

  const arc1 = rdp(clean.slice(0, farIdx + 1));
  const arc2 = rdp([...clean.slice(farIdx), clean[0]]);
  const combined = [...arc1.slice(0, -1), ...arc2.slice(0, -1)];
  return combined.length >= 3 ? combined : clean;
}

/**
 * Recognizes the geometric shape family of a drawn polygon while preserving its original points
 */
export function recognizeDrawnShape(
  polygon: Point[]
): 'circle' | 'square' | 'triangle' | 'star' | 'heart' | 'freehand' {
  if (polygon.length < 3) return 'freehand';
  const bounds = getPolygonBounds(polygon);
  const diag = Math.hypot(bounds.width, bounds.height);
  const { area, perimeter } = getPolygonMetrics(polygon);
  if (perimeter < 1e-3 || area < 1e-3) return 'freehand';

  const circularity = (4 * Math.PI * area) / (perimeter * perimeter);
  const simplified = simplifyPolygon(polygon, diag * 0.055);
  const vertices = simplified.length;

  if (vertices === 3) return 'triangle';

  const boxFill = area / (bounds.width * bounds.height);
  if (vertices === 4 && boxFill > 0.62) return 'square';

  if (circularity > 0.78 && vertices >= 6) return 'circle';

  if (vertices >= 8 && vertices <= 13 && circularity < 0.58) return 'star';

  if (circularity >= 0.58 && circularity <= 0.77 && vertices >= 5 && vertices <= 9) {
    return 'heart';
  }

  return 'freehand';
}

/**
 * Generates polygon vertices for preset and organic irregular shape templates inside a normalized box.
 */
export function createShapeTemplatePolygon(
  shape: PresetShapeType,
  cx: number = 50,
  cy: number = 50,
  radius: number = 42
): Point[] {
  const points: Point[] = [];

  switch (shape) {
    case 'circle': {
      const steps = 40;
      for (let i = 0; i < steps; i++) {
        const theta = (i / steps) * Math.PI * 2;
        points.push({
          x: cx + Math.cos(theta) * radius,
          y: cy + Math.sin(theta) * radius,
        });
      }
      break;
    }

    case 'square': {
      const r = radius * 0.92;
      points.push({ x: cx - r, y: cy - r });
      points.push({ x: cx + r, y: cy - r });
      points.push({ x: cx + r, y: cy + r });
      points.push({ x: cx - r, y: cy + r });
      break;
    }

    case 'diamond': {
      const r = radius * 1.04;
      points.push({ x: cx, y: cy - r });
      points.push({ x: cx + r, y: cy });
      points.push({ x: cx, y: cy + r });
      points.push({ x: cx - r, y: cy });
      break;
    }

    case 'triangle': {
      points.push({ x: cx, y: cy - radius * 1.05 });
      points.push({ x: cx + radius * 0.98, y: cy + radius * 0.88 });
      points.push({ x: cx - radius * 0.98, y: cy + radius * 0.88 });
      break;
    }

    case 'star': {
      const outerR = radius * 1.06;
      const innerR = radius * 0.6;
      const numPoints = 5;
      for (let i = 0; i < numPoints * 2; i++) {
        const r = i % 2 === 0 ? outerR : innerR;
        const angle = (i * Math.PI) / numPoints - Math.PI / 2;
        points.push({
          x: cx + Math.cos(angle) * r,
          y: cy + Math.sin(angle) * r,
        });
      }
      break;
    }

    case 'heart': {
      const steps = 56;
      for (let i = 0; i < steps; i++) {
        const t = (i / steps) * Math.PI * 2;
        const x = 16 * Math.pow(Math.sin(t), 3);
        const y = -(
          13 * Math.cos(t) -
          5 * Math.cos(2 * t) -
          2 * Math.cos(3 * t) -
          Math.cos(4 * t)
        );
        const scale = radius / 16.0;
        points.push({
          x: cx + x * scale,
          y: cy + (y + 2.1) * scale,
        });
      }
      break;
    }

    case 'leaf': {
      // Tilted organic leaf silhouette with subtle stem tail matching reference visual
      const steps = 36;
      const raw: Point[] = [];
      for (let i = 0; i <= steps; i++) {
        const t = (i / steps) * Math.PI;
        const bulge = Math.sin(t) * (0.9 + 0.14 * Math.sin(t * 2));
        raw.push({
          x: bulge * radius * 0.82,
          y: -Math.cos(t) * radius * 0.96,
        });
      }
      // Subtle stem protrusion at bottom-right
      raw.push({ x: radius * 0.16, y: radius * 1.08 });
      raw.push({ x: -radius * 0.04, y: radius * 1.1 });
      for (let i = steps; i >= 0; i--) {
        const t = (i / steps) * Math.PI;
        const bulge = Math.sin(t) * (0.78 + 0.1 * Math.cos(t * 2));
        raw.push({
          x: -bulge * radius * 0.82,
          y: -Math.cos(t) * radius * 0.96,
        });
      }
      // Slight natural diagonal tilt (-22 deg)
      const angle = -0.38;
      const cosA = Math.cos(angle);
      const sinA = Math.sin(angle);
      for (const p of raw) {
        points.push({
          x: cx + p.x * cosA - p.y * sinA,
          y: cy + p.x * sinA + p.y * cosA,
        });
      }
      break;
    }

    case 'fortress': {
      const r = radius * 0.98;
      const notch = r * 0.34;
      points.push({ x: cx - r, y: cy - r });
      points.push({ x: cx - notch, y: cy - r });
      points.push({ x: cx - notch, y: cy - r + notch * 0.85 });
      points.push({ x: cx + notch, y: cy - r + notch * 0.85 });
      points.push({ x: cx + notch, y: cy - r });
      points.push({ x: cx + r, y: cy - r });
      points.push({ x: cx + r, y: cy + r * 0.6 });
      points.push({ x: cx + r * 0.55, y: cy + r });
      points.push({ x: cx - r * 0.55, y: cy + r });
      points.push({ x: cx - r, y: cy + r * 0.6 });
      break;
    }

    case 'cloud': {
      const lobes = [
        { lx: -0.45, ly: 0.18, r: 0.44 },
        { lx: -0.2, ly: -0.25, r: 0.48 },
        { lx: 0.25, ly: -0.18, r: 0.46 },
        { lx: 0.52, ly: 0.18, r: 0.4 },
      ];
      const steps = 52;
      for (let i = 0; i < steps; i++) {
        const theta = (i / steps) * Math.PI * 2;
        const ux = Math.cos(theta);
        const uy = Math.sin(theta);
        let best = 0.62;
        for (const lobe of lobes) {
          const proj = ux * lobe.lx + uy * lobe.ly;
          const dist = Math.hypot(ux * 0.85 - lobe.lx, uy * 0.85 - lobe.ly);
          const candidate = lobe.r + Math.max(0, proj) * 0.45 + Math.max(0, 0.35 - dist * 0.2);
          if (candidate > best) best = candidate;
        }
        points.push({
          x: cx + ux * radius * Math.min(1.04, best * 1.05),
          y: cy + uy * radius * Math.min(0.95, best * 0.92),
        });
      }
      break;
    }

    case 'crescent': {
      const steps = 28;
      // Outer arc
      for (let i = 0; i <= steps; i++) {
        const a = -Math.PI * 0.78 + (i / steps) * Math.PI * 1.56;
        points.push({
          x: cx + Math.cos(a) * radius * 1.02 - radius * 0.1,
          y: cy + Math.sin(a) * radius * 1.02,
        });
      }
      // Inner carved arc (thick enough for dense multi-turn arrows)
      for (let i = steps; i >= 0; i--) {
        const a = -Math.PI * 0.62 + (i / steps) * Math.PI * 1.24;
        points.push({
          x: cx + radius * 0.42 + Math.cos(a) * radius * 0.52,
          y: cy + Math.sin(a) * radius * 0.64,
        });
      }
      break;
    }

    case 'shield': {
      const r = radius * 0.98;
      points.push({ x: cx - r * 0.9, y: cy - r * 0.82 });
      points.push({ x: cx, y: cy - r * 0.98 });
      points.push({ x: cx + r * 0.9, y: cy - r * 0.82 });
      points.push({ x: cx + r * 0.88, y: cy + r * 0.1 });
      points.push({ x: cx + r * 0.5, y: cy + r * 0.68 });
      points.push({ x: cx, y: cy + r * 1.02 });
      points.push({ x: cx - r * 0.5, y: cy + r * 0.68 });
      points.push({ x: cx - r * 0.88, y: cy + r * 0.1 });
      break;
    }

    case 'hourglass': {
      const r = radius * 0.98;
      points.push({ x: cx - r * 0.92, y: cy - r * 0.95 });
      points.push({ x: cx + r * 0.92, y: cy - r * 0.95 });
      points.push({ x: cx + r * 0.85, y: cy - r * 0.42 });
      points.push({ x: cx + r * 0.34, y: cy });
      points.push({ x: cx + r * 0.85, y: cy + r * 0.42 });
      points.push({ x: cx + r * 0.92, y: cy + r * 0.95 });
      points.push({ x: cx - r * 0.92, y: cy + r * 0.95 });
      points.push({ x: cx - r * 0.85, y: cy + r * 0.42 });
      points.push({ x: cx - r * 0.34, y: cy });
      points.push({ x: cx - r * 0.85, y: cy - r * 0.42 });
      break;
    }

    case 'crown': {
      const r = radius * 0.98;
      points.push({ x: cx - r * 0.95, y: cy - r * 0.72 });
      points.push({ x: cx - r * 0.46, y: cy - r * 0.08 });
      points.push({ x: cx, y: cy - r * 0.92 });
      points.push({ x: cx + r * 0.46, y: cy - r * 0.08 });
      points.push({ x: cx + r * 0.95, y: cy - r * 0.72 });
      points.push({ x: cx + r * 0.88, y: cy + r * 0.86 });
      points.push({ x: cx - r * 0.88, y: cy + r * 0.86 });
      break;
    }
  }

  return points;
}

/**
 * Generates an irregular, non-repeating organic maze silhouette inside a dim x dim grid
 * by combining curved hulls with seeded asymmetrical cutouts and notches.
 * Guarantees at least `minCells` interior cells so high-tier levels meet arrow/complexity targets.
 */
export function createIrregularSilhouetteCells(
  dim: number,
  seed: number,
  minCells: number = 24
): { cells: Point[]; shapeType: LevelData['shapeType'] } {
  const presets: PresetShapeType[] = [
    'heart',
    'leaf',
    'shield',
    'crown',
    'cloud',
    'crescent',
    'hourglass',
    'star',
    'diamond',
    'fortress',
  ];

  let bestCells: Point[] = [];
  let bestShape: LevelData['shapeType'] = 'shield';

  for (let retry = 0; retry < 5; retry++) {
    const rng = createSeededRng((seed + Math.imul(retry, 7919)) >>> 0);
    const usePreset = rng() < 0.52;

    if (usePreset) {
      const idx = Math.floor(rng() * presets.length);
      const shape = presets[idx];
      let poly = createShapeTemplatePolygon(shape);

      if (rng() < 0.5 && (shape === 'leaf' || shape === 'crescent' || shape === 'cloud')) {
        poly = poly.map((p) => ({ x: 100 - p.x, y: p.y }));
      }
      if (rng() < 0.35 && (shape === 'crown' || shape === 'shield' || shape === 'fortress')) {
        poly = poly.map((p) => ({ x: p.x, y: 100 - p.y }));
      }

      const rawCells = sampleGridCellsFromPolygon(poly, dim, dim);
      let finalCells = rawCells;

      if (dim >= 11 && rawCells.length > minCells + 16) {
        const notchCount = dim >= 15 ? 2 : 1;
        const cellSet = new Set(rawCells.map((c) => `${c.x},${c.y}`));
        for (let n = 0; n < notchCount; n++) {
          const edge = rawCells[Math.floor(rng() * rawCells.length)];
          const radius = dim >= 18 ? 2 : 1;
          for (let dx = -radius; dx <= radius; dx++) {
            for (let dy = -radius; dy <= radius; dy++) {
              if (Math.abs(dx) + Math.abs(dy) <= radius) {
                const nx = edge.x + dx;
                const ny = edge.y + dy;
                if (
                  nx === 0 ||
                  nx === dim - 1 ||
                  ny === 0 ||
                  ny === dim - 1 ||
                  !cellSet.has(`${nx - 1},${ny}`) ||
                  !cellSet.has(`${nx + 1},${ny}`)
                ) {
                  cellSet.delete(`${nx},${ny}`);
                }
              }
            }
          }
        }
        const carved: Point[] = [];
        for (const k of cellSet) {
          const [x, y] = k.split(',').map(Number);
          carved.push({ x, y });
        }
        if (carved.length >= minCells) {
          finalCells = carved;
        }
      }

      if (finalCells.length > bestCells.length) {
        bestCells = finalCells;
        bestShape = shape;
      }
      if (finalCells.length >= minCells) {
        return { cells: finalCells, shapeType: shape };
      }
      continue;
    }

    // Procedural radial asymmetric polygon + crisp rectangular cutout pockets
    const numVertices = 12 + Math.floor(rng() * 7);
    const phase = rng() * Math.PI * 2;
    const freqA = 2 + Math.floor(rng() * 3);
    const freqB = 3 + Math.floor(rng() * 3);
    const ampA = 0.09 + rng() * 0.1;
    const ampB = 0.06 + rng() * 0.08;

    const poly: Point[] = [];
    for (let i = 0; i < numVertices; i++) {
      const theta = (i / numVertices) * Math.PI * 2;
      const mod =
        1 +
        ampA * Math.sin(theta * freqA + phase) +
        ampB * Math.cos(theta * freqB - phase * 0.7);
      const rx = Math.max(0.58, Math.min(1.06, mod * 0.94));
      const ry = Math.max(0.58, Math.min(1.06, mod * 0.94));
      poly.push({
        x: 50 + Math.cos(theta) * 46 * rx,
        y: 50 + Math.sin(theta) * 46 * ry,
      });
    }

    let cells = sampleGridCellsFromPolygon(poly, dim, dim);
    const cellSet = new Set(cells.map((c) => `${c.x},${c.y}`));

    const cutouts = dim >= 14 ? 2 : 1;
    for (let c = 0; c < cutouts; c++) {
      const side = Math.floor(rng() * 4);
      const wCut = 1 + Math.floor(rng() * Math.max(2, Math.floor(dim * 0.16)));
      const hCut = 1 + Math.floor(rng() * Math.max(2, Math.floor(dim * 0.16)));
      const offset = Math.floor(rng() * Math.max(1, dim - Math.max(wCut, hCut)));

      for (let i = 0; i < wCut; i++) {
        for (let j = 0; j < hCut; j++) {
          let gx = 0;
          let gy = 0;
          if (side === 0) {
            gx = offset + i;
            gy = j;
          } else if (side === 1) {
            gx = dim - 1 - i;
            gy = offset + j;
          } else if (side === 2) {
            gx = offset + i;
            gy = dim - 1 - j;
          } else {
            gx = i;
            gy = offset + j;
          }
          cellSet.delete(`${gx},${gy}`);
        }
      }
    }

    cells = [];
    for (const k of cellSet) {
      const [x, y] = k.split(',').map(Number);
      cells.push({ x, y });
    }

    if (cells.length > bestCells.length) {
      bestCells = cells;
      bestShape = 'freehand';
    }
    if (cells.length >= minCells) {
      return { cells, shapeType: 'freehand' };
    }
  }

  // Fallback high-capacity organic octagon with corner cutouts if retries stayed compact
  const cellSet = new Set<string>();
  const margin = Math.max(1, Math.floor(dim * 0.18));
  for (let x = 0; x < dim; x++) {
    for (let y = 0; y < dim; y++) {
      const cornerSum =
        (x < margin && y < margin ? margin - x + (margin - y) : 0) +
        (x >= dim - margin && y < margin ? x - (dim - 1 - margin) + (margin - y) : 0) +
        (x < margin && y >= dim - margin ? margin - x + (y - (dim - 1 - margin)) : 0) +
        (x >= dim - margin && y >= dim - margin
          ? x - (dim - 1 - margin) + (y - (dim - 1 - margin))
          : 0);
      if (cornerSum <= margin) {
        cellSet.add(`${x},${y}`);
      }
    }
  }
  const fallback: Point[] = [];
  for (const k of cellSet) {
    const [x, y] = k.split(',').map(Number);
    fallback.push({ x, y });
  }
  return fallback.length >= bestCells.length
    ? { cells: fallback, shapeType: 'freehand' }
    : { cells: bestCells, shapeType: bestShape };
}

export interface PolylineMazeOptions {
  seed?: number;
  minLength?: number;
  maxLength?: number;
  turnBias?: number;
  idPrefix?: string;
}

/**
 * Dense Orthogonal Polyline Maze Generator (Reference-Tuned & Grid-Indexed for 60fps Generation).
 * Partitions `maskCells` into non-overlapping, dense arrow paths mixing:
 * - Long straight horizontal/vertical corridor runners
 * - Sharp 90-degree multi-turn snakes & U-bends
 * - Short compact blocker hooks
 * Uses outside-in peeling so a valid topological escape order is mathematically guaranteed.
 */
export function generatePolylineMaze(
  maskCells: Point[],
  options: PolylineMazeOptions = {}
): ArrowConfig[] {
  const rng = options.seed !== undefined ? createSeededRng(options.seed) : Math.random;
  const minLen = options.minLength ?? 2;
  const maxLen = options.maxLength ?? 9;
  const turnBias = options.turnBias ?? 0.65;
  const prefix = options.idPrefix ?? 'maze';

  if (maskCells.length < 2) return [];

  let minX = Infinity;
  let maxX = -Infinity;
  let minY = Infinity;
  let maxY = -Infinity;

  for (const c of maskCells) {
    const gx = Math.round(c.x);
    const gy = Math.round(c.y);
    if (gx < minX) minX = gx;
    if (gx > maxX) maxX = gx;
    if (gy < minY) minY = gy;
    if (gy > maxY) maxY = gy;
  }

  const width = maxX - minX + 1;
  const height = maxY - minY + 1;
  const totalGrid = width * height;

  // State arrays indexed by (gy - minY) * width + (gx - minX):
  // 0 = empty/outside, 1 = remaining, 2 = peeled
  const state = new Uint8Array(totalGrid);
  const selfStamp = new Int32Array(totalGrid);
  let remainingCount = 0;

  for (const c of maskCells) {
    const gx = Math.round(c.x);
    const gy = Math.round(c.y);
    const idx = (gy - minY) * width + (gx - minX);
    if (state[idx] === 0) {
      state[idx] = 1;
      remainingCount++;
    }
  }

  if (remainingCount < 2) return [];

  const isRayClear = (
    hx: number,
    hy: number,
    dir: Direction
  ): { clear: boolean; hitsPeeled: number } => {
    const { dx, dy } = DIR_DELTA[dir];
    let cx = hx + dx;
    let cy = hy + dy;
    let hitsPeeled = 0;

    while (cx >= minX && cx <= maxX && cy >= minY && cy <= maxY) {
      const s = state[(cy - minY) * width + (cx - minX)];
      if (s === 1) {
        return { clear: false, hitsPeeled: 0 };
      }
      if (s === 2) {
        hitsPeeled++;
      }
      cx += dx;
      cy += dy;
    }

    return { clear: true, hitsPeeled };
  };

  const countRemainingNeighbors = (x: number, y: number, stampId: number = -1): number => {
    let cnt = 0;
    if (x > minX) {
      const idx = (y - minY) * width + (x - 1 - minX);
      if (state[idx] === 1 && selfStamp[idx] !== stampId) cnt++;
    }
    if (x < maxX) {
      const idx = (y - minY) * width + (x + 1 - minX);
      if (state[idx] === 1 && selfStamp[idx] !== stampId) cnt++;
    }
    if (y > minY) {
      const idx = (y - 1 - minY) * width + (x - minX);
      if (state[idx] === 1 && selfStamp[idx] !== stampId) cnt++;
    }
    if (y < maxY) {
      const idx = (y + 1 - minY) * width + (x - minX);
      if (state[idx] === 1 && selfStamp[idx] !== stampId) cnt++;
    }
    return cnt;
  };

  const arrows: ArrowConfig[] = [];
  let arrowIndex = 0;
  let stampCounter = 1;
  let safetyCounter = remainingCount * 3 + 60;

  while (remainingCount > 0 && safetyCounter-- > 0) {
    let bestScore1 = -Infinity;
    let bestScore2 = -Infinity;
    let bestScore3 = -Infinity;

    type Candidate = {
      hx: number;
      hy: number;
      px: number;
      py: number;
      dir: Direction;
      score: number;
    };
    const topCandidates: Candidate[] = [];

    for (let gy = minY; gy <= maxY; gy++) {
      const rowOffset = (gy - minY) * width;
      for (let gx = minX; gx <= maxX; gx++) {
        if (state[rowOffset + (gx - minX)] !== 1) continue;

        for (let dIdx = 0; dIdx < 4; dIdx++) {
          const dir = DIRECTIONS[dIdx];
          const { dx, dy } = DIR_DELTA[dir];
          const px = gx - dx;
          const py = gy - dy;

          if (px < minX || px > maxX || py < minY || py > maxY) continue;
          if (state[(py - minY) * width + (px - minX)] !== 1) continue;

          const { clear, hitsPeeled } = isRayClear(gx, gy, dir);
          if (!clear) continue;

          const deg = countRemainingNeighbors(gx, gy);
          const prevDeg = countRemainingNeighbors(px, py);
          let score = (4 - deg) * 2.1 + (4 - prevDeg) * 1.25;
          if (hitsPeeled > 0) {
            // Reward peeling paths whose rays cross already-peeled arrows -> creates real blocking chains!
            score += 4.0 + Math.min(3, hitsPeeled) * 0.9;
          }
          score += rng() * 2.2;

          if (topCandidates.length < 3 || score > bestScore3) {
            topCandidates.push({ hx: gx, hy: gy, px, py, dir, score });
            topCandidates.sort((a, b) => b.score - a.score);
            if (topCandidates.length > 3) topCandidates.pop();
            bestScore1 = topCandidates[0]?.score ?? -Infinity;
            bestScore2 = topCandidates[1]?.score ?? -Infinity;
            bestScore3 = topCandidates[2]?.score ?? -Infinity;
            void bestScore1;
            void bestScore2;
          }
        }
      }
    }

    if (topCandidates.length === 0) {
      let removedAny = false;
      for (let gy = minY; gy <= maxY; gy++) {
        const rowOffset = (gy - minY) * width;
        for (let gx = minX; gx <= maxX; gx++) {
          const idx = rowOffset + (gx - minX);
          if (state[idx] === 1 && countRemainingNeighbors(gx, gy) === 0) {
            state[idx] = 0;
            remainingCount--;
            removedAny = true;
          }
        }
      }

      if (!removedAny) {
        let placedSingle = false;
        for (let gy = minY; gy <= maxY && !placedSingle; gy++) {
          const rowOffset = (gy - minY) * width;
          for (let gx = minX; gx <= maxX && !placedSingle; gx++) {
            const idx = rowOffset + (gx - minX);
            if (state[idx] !== 1) continue;
            for (const dir of DIRECTIONS) {
              if (isRayClear(gx, gy, dir).clear) {
                state[idx] = 2;
                remainingCount--;
                arrowIndex++;
                arrows.push({
                  id: `${prefix}_${arrowIndex}`,
                  x: gx,
                  y: gy,
                  dir,
                  path: [{ x: gx, y: gy }],
                });
                placedSingle = true;
                break;
              }
            }
          }
        }
        if (!placedSingle) break;
      }
      continue;
    }

    const chosen = topCandidates[Math.floor(rng() * topCandidates.length)];
    const currentStamp = stampCounter++;

    const reversedPath: Point[] = [
      { x: chosen.hx, y: chosen.hy },
      { x: chosen.px, y: chosen.py },
    ];
    selfStamp[(chosen.hy - minY) * width + (chosen.hx - minX)] = currentStamp;
    selfStamp[(chosen.py - minY) * width + (chosen.px - minX)] = currentStamp;

    // Assign a distinct corridor personality so mazes mix long runs, winding snakes, and short blockers
    const roll = rng();
    let mode: 'runner' | 'snake' | 'blocker';
    let targetLen: number;
    let localTurnBias: number;

    if (roll < 0.22) {
      // Long horizontal/vertical runner with occasional 90° bends
      mode = 'runner';
      const boost = Math.max(2, Math.floor(maxLen * 0.25));
      targetLen = Math.max(minLen + 2, maxLen + Math.floor(rng() * boost));
      localTurnBias = Math.max(0.2, turnBias * 0.35);
    } else if (roll < 0.7) {
      // Dense winding 90-degree multi-turn snake
      mode = 'snake';
      targetLen = minLen + 1 + Math.floor(rng() * Math.max(2, maxLen - minLen));
      localTurnBias = Math.min(0.92, turnBias + 0.14);
    } else {
      // Short compact blocker hook
      mode = 'blocker';
      targetLen = minLen + Math.floor(rng() * 3);
      localTurnBias = turnBias;
    }

    let lastStepDir: Direction = chosen.dir;

    while (reversedPath.length < targetLen) {
      const tail = reversedPath[reversedPath.length - 1];
      let bestPick: { pt: Point; stepDir: Direction; weight: number } | null = null;

      for (let dIdx = 0; dIdx < 4; dIdx++) {
        const d = DIRECTIONS[dIdx];
        const { dx, dy } = DIR_DELTA[d];
        const nx = tail.x + dx;
        const ny = tail.y + dy;

        if (nx < minX || nx > maxX || ny < minY || ny > maxY) continue;
        const nIdx = (ny - minY) * width + (nx - minX);
        if (state[nIdx] !== 1 || selfStamp[nIdx] === currentStamp) continue;

        const deg = countRemainingNeighbors(nx, ny, currentStamp);
        const isTurn = d !== lastStepDir;

        // Warnsdorff boundary-hugging keeps remaining interior cohesive
        let weight = (5 - deg) * 2.15;

        if (mode === 'runner') {
          weight += isTurn ? localTurnBias * 2.4 : (1 - localTurnBias) * 5.2;
        } else {
          weight += isTurn ? localTurnBias * 4.6 : (1 - localTurnBias) * 2.8;
        }

        weight += rng() * 1.8;

        if (!bestPick || weight > bestPick.weight) {
          bestPick = { pt: { x: nx, y: ny }, stepDir: d, weight };
        }
      }

      if (!bestPick) break;

      reversedPath.push(bestPick.pt);
      selfStamp[(bestPick.pt.y - minY) * width + (bestPick.pt.x - minX)] = currentStamp;
      lastStepDir = bestPick.stepDir;
    }

    const path = reversedPath.reverse();
    for (const pt of path) {
      const idx = (pt.y - minY) * width + (pt.x - minX);
      if (state[idx] === 1) {
        state[idx] = 2;
        remainingCount--;
      }
    }

    arrowIndex++;
    arrows.push({
      id: `${prefix}_${arrowIndex}`,
      x: chosen.hx,
      y: chosen.hy,
      dir: chosen.dir,
      path,
    });
  }

  return arrows;
}

/**
 * Maps a raw polygon into aspect-preserving grid coordinates [-0.5 .. cols-0.5] x [-0.5 .. rows-0.5]
 * so the rendered boundary outline aligns pixel-for-pixel with the generated grid cells!
 */
export function mapPolygonToGridBoundary(
  polygon: Point[],
  cols: number,
  rows: number
): Point[] {
  const bounds = getPolygonBounds(polygon);
  return polygon.map((pt) => ({
    x: ((pt.x - bounds.minX) / bounds.width) * cols - 0.5,
    y: ((pt.y - bounds.minY) / bounds.height) * rows - 0.5,
  }));
}

/**
 * Samples grid coordinates inside a polygon at a given target resolution
 */
export function sampleGridCellsFromPolygon(
  polygon: Point[],
  cols: number,
  rows: number
): Point[] {
  const bounds = getPolygonBounds(polygon);
  const cellW = bounds.width / cols;
  const cellH = bounds.height / rows;

  const cells: Point[] = [];
  for (let gx = 0; gx < cols; gx++) {
    for (let gy = 0; gy < rows; gy++) {
      const wx = bounds.minX + (gx + 0.5) * cellW;
      const wy = bounds.minY + (gy + 0.5) * cellH;
      if (isPointInPolygon({ x: wx, y: wy }, polygon)) {
        cells.push({ x: gx, y: gy });
      }
    }
  }
  return cells;
}

/**
 * Automatic Puzzle Generator from a drawn or template shape:
 * 1. Preserves the original drawn shape boundary mapped cleanly into grid space (`isCustomDrawn: true`).
 * 2. Computes aspect-preserving interior cells strictly inside the drawn polygon.
 * 3. Generates connected arrow paths inside the shape.
 * 4. Validates every generated puzzle with the Validation Engine, regenerating until valid & solvable.
 */
export function generatePuzzleFromShape(
  rawPolygon: Point[],
  targetArrowCount: number = 14,
  levelNumber: number = 11,
  title?: string,
  shapeType?: LevelData['shapeType'],
  seed?: number
): LevelData {
  const polygon =
    rawPolygon.length >= 3 ? rawPolygon : createShapeTemplatePolygon('circle');

  const detectedShape =
    shapeType && shapeType !== 'freehand' ? shapeType : recognizeDrawnShape(polygon);

  const bounds = getPolygonBounds(polygon);
  const aspect = Math.max(0.45, Math.min(2.2, bounds.width / bounds.height));

  const profile = getDifficultyProfile(levelNumber);
  const baseDim = Math.max(
    8,
    Math.min(18, Math.round(7 + targetArrowCount * 0.28))
  );

  let cols = aspect >= 1 ? baseDim : Math.max(7, Math.round(baseDim * aspect));
  let rows = aspect <= 1 ? baseDim : Math.max(7, Math.round(baseDim / aspect));

  let maskCells = sampleGridCellsFromPolygon(polygon, cols, rows);

  let bump = 0;
  while (maskCells.length < 18 && bump < 4) {
    bump++;
    cols += 2;
    rows += 2;
    maskCells = sampleGridCellsFromPolygon(polygon, cols, rows);
  }

  if (maskCells.length < 6) {
    const fallbackPoly = createShapeTemplatePolygon(
      detectedShape === 'freehand' ? 'circle' : detectedShape
    );
    return generatePuzzleFromShape(
      fallbackPoly,
      targetArrowCount,
      levelNumber,
      title,
      detectedShape,
      seed
    );
  }

  const gridBoundary = mapPolygonToGridBoundary(polygon, cols, rows);

  let bestArrows: ArrowConfig[] = [];
  let bestScore = -1;

  for (let attempt = 0; attempt < 18; attempt++) {
    const attemptSeed = seed !== undefined ? seed + attempt * 997 : undefined;
    const candidate = generatePolylineMaze(maskCells, {
      seed: attemptSeed,
      minLength: 2,
      maxLength: targetArrowCount > 20 ? 8 : 6,
      turnBias: Math.max(0.62, profile.turnBias),
      idPrefix: `gen_${levelNumber}_${attempt}`,
    });

    const validation = validateAndEvaluatePuzzle(candidate);
    if (!validation.valid || !validation.metrics.solvable) {
      continue;
    }

    const m = validation.metrics;
    const countDiff = Math.abs(m.arrowCount - targetArrowCount);
    const score =
      m.complexityScore +
      m.blockedRatio * 40 +
      m.waveDepth * 8 -
      countDiff * 3.0;

    if (score > bestScore) {
      bestScore = score;
      bestArrows = candidate;
    }

    if (
      m.arrowCount >= Math.max(5, Math.floor(targetArrowCount * 0.7)) &&
      m.blockedRatio >= 0.5 &&
      m.waveDepth >= 2
    ) {
      break;
    }
  }

  if (bestArrows.length === 0) {
    const fallback = generatePolylineMaze(maskCells, {
      minLength: 1,
      maxLength: 5,
      idPrefix: `gen_${levelNumber}_fb`,
    });
    const check = validateAndEvaluatePuzzle(fallback);
    if (check.valid) {
      bestArrows = fallback;
    }
  }

  let maxGX = cols - 1;
  let maxGY = rows - 1;
  for (const a of bestArrows) {
    const pts = a.path || [{ x: a.x, y: a.y }];
    for (const p of pts) {
      if (p.x > maxGX) maxGX = p.x;
      if (p.y > maxGY) maxGY = p.y;
    }
  }

  const shapeLabel =
    detectedShape === 'freehand'
      ? 'Custom Shape'
      : detectedShape.charAt(0).toUpperCase() + detectedShape.slice(1);

  return {
    id: `custom_${levelNumber}_${Date.now()}`,
    levelNumber,
    title: title || `${shapeLabel} · Level ${levelNumber}`,
    difficulty: levelNumber > 10 ? profile.tier : 'Custom',
    gridWidth: maxGX + 1,
    gridHeight: maxGY + 1,
    arrows: bestArrows,
    boundaryPath: gridBoundary,
    isCustomDrawn: true,
    shapeType: detectedShape,
  };
}

/**
 * Generates an unlimited progressive endless level for any levelNumber >= 11.
 * Guarantees unique irregular maze silhouettes, non-repeating arrow arrangements,
 * and complexity metrics meeting the 9-tier Progressive Difficulty Engine.
 */
export function generateProceduralLevel(levelNumber: number): LevelData {
  const profile = getDifficultyProfile(levelNumber);
  const dim = profile.gridSize;

  // Unique deterministic seed per level so no two levels repeat
  const baseSeed = (Math.imul(levelNumber + 17, 2654435761) ^ 0x9e3779b9) >>> 0;
  const requiredCells = Math.min(Math.floor(dim * dim * 0.78), profile.minArrows * 4);
  const { cells: maskCells, shapeType } = createIrregularSilhouetteCells(
    dim,
    baseSeed,
    requiredCells
  );

  let bestArrows: ArrowConfig[] = [];
  let bestScore = -Infinity;

  for (let attempt = 0; attempt < 24; attempt++) {
    const candidateSeed = (baseSeed + Math.imul(attempt + 1, 1597334677)) >>> 0;
    const candidate = generatePolylineMaze(maskCells, {
      seed: candidateSeed,
      minLength: profile.minPathLength,
      maxLength: profile.maxPathLength,
      turnBias: profile.turnBias,
      idPrefix: `endless_${levelNumber}_${attempt}`,
    });

    const validation = validateAndEvaluatePuzzle(candidate);
    if (!validation.valid || !validation.metrics.solvable) {
      continue;
    }

    const m = validation.metrics;
    const meetsTargets =
      m.arrowCount >= profile.minArrows &&
      m.blockedRatio >= profile.minBlockedRatio &&
      m.waveDepth >= profile.minWaveDepth &&
      m.avgTurnsPerArrow >= profile.minAvgTurns &&
      m.complexityScore >= profile.minComplexityScore;

    // Score balances complexity score, blocked ratio, wave depth, and soft arrow target range
    const overflowPenalty = Math.max(0, m.arrowCount - profile.maxArrows) * 4;
    const score =
      m.complexityScore +
      m.blockedRatio * 60 +
      m.waveDepth * 12 +
      m.avgTurnsPerArrow * 25 -
      overflowPenalty;

    if (score > bestScore) {
      bestScore = score;
      bestArrows = candidate;
    }

    if (meetsTargets && m.arrowCount <= profile.maxArrows + 12) {
      break;
    }
  }

  // Compute tight grid bounds from generated arrows
  let maxGX = dim - 1;
  let maxGY = dim - 1;
  for (const a of bestArrows) {
    const pts = a.path || [{ x: a.x, y: a.y }];
    for (const p of pts) {
      if (p.x > maxGX) maxGX = p.x;
      if (p.y > maxGY) maxGY = p.y;
    }
  }

  const titles: Record<string, string[]> = {
    heart: ['Ruby Pulse', 'Crimson Echo', 'Valiance Core', 'Heartstrings'],
    leaf: ['Emerald Leaf', 'Botanic Maze', 'Forest Vein', 'Canopy Path'],
    shield: ['Aegis Bastion', 'Paladin Crest', 'Vanguard Seal', 'Royal Shield'],
    crown: ['Sovereign Crest', 'Monarch Spire', 'Gilded Crown', 'Apex Diadem'],
    cloud: ['Nimbus Drift', 'Skyline Cloud', 'Tempest Puff', 'Cumulus Path'],
    crescent: ['Lunar Crescent', 'Eclipse Arc', 'Silver Moon', 'Crescent Tide'],
    hourglass: ['Chrono Glass', 'Temporal Lock', 'Sands of Time', 'Twin Funnel'],
    star: ['Astral Nova', 'Cosmic Beacon', 'Starlight Cross', 'Supernova Core'],
    diamond: ['Prism Cut', 'Sapphire Facet', 'Crystal Lock', 'Diamond Flux'],
    fortress: ['Iron Citadel', 'Bastion Gate', 'Vanguard Keep', 'Titan Maze'],
    freehand: ['Asymmetric Rift', 'Shifted Labyrinth', 'Fractured Maze', 'Organic Knot'],
  };

  const nameList = titles[shapeType || 'freehand'] || titles.freehand;
  const title = nameList[levelNumber % nameList.length];

  return {
    id: levelNumber,
    levelNumber,
    title: `${title} · Lv.${levelNumber}`,
    difficulty: profile.tier,
    gridWidth: maxGX + 1,
    gridHeight: maxGY + 1,
    arrows: bestArrows,
    isCustomDrawn: false,
    shapeType,
  };
}
