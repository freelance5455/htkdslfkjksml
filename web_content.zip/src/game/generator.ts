import { Arrow, Difficulty, Direction, Level, Point } from '../types/game';
import { solveLevel } from './solver';

/**
 * Fast, deterministic 32-bit PRNG (Mulberry32).
 */
export function createRng(seed: number) {
  let s = seed >>> 0;
  return function next(): number {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function getDifficultyForLevel(levelId: number): Difficulty {
  if (levelId <= 10) return 'Beginner';
  if (levelId <= 100) return 'Intermediate';
  if (levelId <= 500) return 'Advanced';
  if (levelId <= 800) return 'Master';
  return 'Ultimate';
}

const DIRECTIONS: Direction[] = ['UP', 'DOWN', 'LEFT', 'RIGHT'];

function getDirVector(dir: Direction): { dx: number; dy: number } {
  switch (dir) {
    case 'UP': return { dx: 0, dy: -1 };
    case 'DOWN': return { dx: 0, dy: 1 };
    case 'LEFT': return { dx: -1, dy: 0 };
    case 'RIGHT': return { dx: 1, dy: 0 };
  }
}

function getOppositeDir(dir: Direction): Direction {
  switch (dir) {
    case 'UP': return 'DOWN';
    case 'DOWN': return 'UP';
    case 'LEFT': return 'RIGHT';
    case 'RIGHT': return 'LEFT';
  }
}

function getPerpendicularDirs(dir: Direction): Direction[] {
  if (dir === 'UP' || dir === 'DOWN') {
    return ['LEFT', 'RIGHT'];
  }
  return ['UP', 'DOWN'];
}

function isRayClear(
  hx: number,
  hy: number,
  dir: Direction,
  occupied: Uint8Array,
  rows: number,
  cols: number
): boolean {
  let x = hx;
  let y = hy;
  const { dx, dy } = getDirVector(dir);

  x += dx;
  y += dy;
  while (x >= 0 && x < cols && y >= 0 && y < rows) {
    if (occupied[y * cols + x] === 1) return false;
    x += dx;
    y += dy;
  }
  return true;
}

/**
 * Computes exact target arrow counts and grid dimensions matching user specification:
 * - Level 1: ~10–20 arrows
 * - Levels 2–10: 20–40 arrows
 * - Levels 11–50: 30–60 arrows
 * - Levels 51–100: 50–80 arrows
 * - Levels 101–500: 70–120 arrows
 * - Levels 501–1000: 100–200 arrows
 */
export function getLevelConfig(levelId: number): {
  targetArrows: number;
  gridCols: number;
  gridRows: number;
  parTimeSec: number;
} {
  const id = Math.max(1, Math.min(1000, Math.floor(levelId)));

  if (id === 1) {
    return { targetArrows: 16, gridCols: 10, gridRows: 12, parTimeSec: 120 };
  } else if (id <= 10) {
    // 20 - 40 arrows
    const ratio = (id - 2) / 8;
    const target = Math.round(20 + ratio * 20);
    const cols = Math.round(11 + ratio * 3);
    const rows = Math.round(13 + ratio * 3);
    return { targetArrows: target, gridCols: cols, gridRows: rows, parTimeSec: 150 };
  } else if (id <= 50) {
    // 30 - 60 arrows
    const ratio = (id - 11) / 39;
    const target = Math.round(30 + ratio * 30);
    const cols = Math.round(14 + ratio * 4);
    const rows = Math.round(16 + ratio * 5);
    return { targetArrows: target, gridCols: cols, gridRows: rows, parTimeSec: 180 };
  } else if (id <= 100) {
    // 50 - 80 arrows
    const ratio = (id - 51) / 49;
    const target = Math.round(50 + ratio * 30);
    const cols = Math.round(18 + ratio * 4);
    const rows = Math.round(21 + ratio * 5);
    return { targetArrows: target, gridCols: cols, gridRows: rows, parTimeSec: 210 };
  } else if (id <= 500) {
    // 70 - 120 arrows
    const ratio = (id - 101) / 399;
    const target = Math.round(70 + ratio * 50);
    const cols = Math.round(22 + ratio * 5);
    const rows = Math.round(26 + ratio * 6);
    return { targetArrows: target, gridCols: cols, gridRows: rows, parTimeSec: 260 };
  } else {
    // Levels 501 - 1000: 100 - 200 arrows
    const ratio = (id - 501) / 499;
    const target = Math.round(100 + ratio * 100);
    const cols = Math.round(27 + ratio * 6);
    const rows = Math.round(32 + ratio * 8);
    return { targetArrows: target, gridCols: cols, gridRows: rows, parTimeSec: 300 };
  }
}

/**
 * Generates an arrow maze level with winding serpentine arrows and guaranteed solvability.
 */
export function generateLevel(levelId: number): Level {
  const clampedId = Math.max(1, Math.min(1000, Math.floor(levelId)));
  const difficulty = getDifficultyForLevel(clampedId);
  const config = getLevelConfig(clampedId);

  let finalArrows: Arrow[] = [];
  let solution: string[] | null = null;
  let attempt = 0;

  while (attempt < 10) {
    const seed = (clampedId * 10007 + attempt * 7919 + 42) >>> 0;
    const rng = createRng(seed);

    const generated = buildReverseWindingMaze(
      config.gridRows,
      config.gridCols,
      config.targetArrows,
      rng
    );

    if (generated && generated.length >= Math.max(10, Math.floor(config.targetArrows * 0.85))) {
      solution = solveLevel(generated, config.gridRows, config.gridCols);
      if (solution !== null && solution.length === generated.length) {
        finalArrows = generated;
        break;
      }
    }
    attempt++;
  }

  // Fallback pattern if random attempt stalls
  if (finalArrows.length === 0) {
    finalArrows = buildStructuredDenseLabyrinth(config.gridRows, config.gridCols, config.targetArrows, clampedId);
    solution = solveLevel(finalArrows, config.gridRows, config.gridCols);
  }

  const optimalMoves = solution ? solution.length : finalArrows.length;

  return {
    id: clampedId,
    gridRows: config.gridRows,
    gridCols: config.gridCols,
    arrows: finalArrows,
    difficulty,
    optimalMoves,
    parTimeSec: config.parTimeSec,
  };
}

/**
 * Builds winding serpentine arrows in reverse escape order.
 */
function buildReverseWindingMaze(
  rows: number,
  cols: number,
  targetCount: number,
  rng: () => number
): Arrow[] {
  const arrows: Arrow[] = [];
  const totalCells = rows * cols;
  const occupied = new Uint8Array(totalCells);

  let arrowId = 1;
  let failures = 0;
  const maxFailures = Math.max(180, targetCount * 3);

  while (arrows.length < targetCount && failures < maxFailures) {
    // Pick candidate empty cells
    const emptyCells: { x: number; y: number }[] = [];
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols; x++) {
        if (occupied[y * cols + x] === 0) {
          emptyCells.push({ x, y });
        }
      }
    }

    if (emptyCells.length === 0) break;

    const cellIdx = Math.floor(rng() * emptyCells.length);
    const { x: hx, y: hy } = emptyCells[cellIdx];

    // Find directions where forward ray is clear
    const validDirs: Direction[] = [];
    for (const d of DIRECTIONS) {
      if (isRayClear(hx, hy, d, occupied, rows, cols)) {
        validDirs.push(d);
      }
    }

    if (validDirs.length === 0) {
      failures++;
      continue;
    }

    const chosenDir = validDirs[Math.floor(rng() * validDirs.length)];

    // Grow the winding body backwards from head
    const bodyPoints: Point[] = [{ x: hx, y: hy }];
    let currX = hx;
    let currY = hy;
    let currentBackDir = getOppositeDir(chosenDir);

    const shapeRoll = rng();
    const maxBends = shapeRoll < 0.35 ? 1 : shapeRoll < 0.75 ? 2 : shapeRoll < 0.92 ? 3 : 4;
    let bends = 0;

    let canGrow = true;
    while (bends < maxBends && canGrow) {
      const segLength = 1 + Math.floor(rng() * 3);
      const { dx, dy } = getDirVector(currentBackDir);
      let stepsTaken = 0;

      for (let s = 0; s < segLength; s++) {
        const nextX = currX + dx;
        const nextY = currY + dy;

        if (
          nextX >= 0 &&
          nextX < cols &&
          nextY >= 0 &&
          nextY < rows &&
          occupied[nextY * cols + nextX] === 0 &&
          !bodyPoints.some((p) => p.x === nextX && p.y === nextY)
        ) {
          currX = nextX;
          currY = nextY;
          bodyPoints.push({ x: currX, y: currY });
          stepsTaken++;
        } else {
          break;
        }
      }

      if (stepsTaken === 0) break;

      const turnOptions = getPerpendicularDirs(currentBackDir);
      currentBackDir = turnOptions[Math.floor(rng() * turnOptions.length)];
      bends++;
    }

    if (bodyPoints.length >= 2) {
      const points = [...bodyPoints].reverse();
      const head = points[points.length - 1];

      for (const p of points) {
        occupied[p.y * cols + p.x] = 1;
      }

      arrows.push({
        id: `arrow_${arrowId++}`,
        points,
        row: head.y,
        col: head.x,
        direction: chosenDir,
      });

      failures = 0;
    } else {
      failures++;
    }
  }

  return arrows;
}

/**
 * High-density fallback pattern if random winding encounters bottlenecks.
 */
function buildStructuredDenseLabyrinth(
  rows: number,
  cols: number,
  targetCount: number,
  seed: number
): Arrow[] {
  const arrows: Arrow[] = [];
  const rng = createRng(seed);
  let id = 1;

  // Perimeter arrows
  for (let x = 0; x < cols && arrows.length < targetCount; x += 2) {
    arrows.push({
      id: `fb_${id++}`,
      points: [
        { x, y: 1 },
        { x, y: 0 },
      ],
      row: 0,
      col: x,
      direction: 'UP',
    });
  }

  for (let x = 1; x < cols && arrows.length < targetCount; x += 2) {
    arrows.push({
      id: `fb_${id++}`,
      points: [
        { x, y: rows - 2 },
        { x, y: rows - 1 },
      ],
      row: rows - 1,
      col: x,
      direction: 'DOWN',
    });
  }

  for (let y = 1; y < rows - 1 && arrows.length < targetCount; y += 2) {
    arrows.push({
      id: `fb_${id++}`,
      points: [
        { x: 1, y },
        { x: 0, y },
      ],
      row: y,
      col: 0,
      direction: 'LEFT',
    });
  }

  for (let y = 2; y < rows - 1 && arrows.length < targetCount; y += 2) {
    arrows.push({
      id: `fb_${id++}`,
      points: [
        { x: cols - 2, y },
        { x: cols - 1, y },
      ],
      row: y,
      col: cols - 1,
      direction: 'RIGHT',
    });
  }

  // Internal L & U shaped arrows
  for (let y = 2; y < rows - 3 && arrows.length < targetCount; y += 3) {
    for (let x = 2; x < cols - 3 && arrows.length < targetCount; x += 3) {
      arrows.push({
        id: `fb_${id++}`,
        points: [
          { x: x + 1, y },
          { x, y },
          { x, y: y + 1 },
        ],
        row: y + 1,
        col: x,
        direction: 'DOWN',
      });
    }
  }

  return arrows;
}

const LEVEL_CACHE = new Map<number, Level>();

export function getLevel(levelId: number): Level {
  if (LEVEL_CACHE.has(levelId)) {
    return LEVEL_CACHE.get(levelId)!;
  }
  const level = generateLevel(levelId);
  LEVEL_CACHE.set(levelId, level);
  return level;
}
