export type RegionId =
  | 'green_forest'
  | 'mountain_region'
  | 'skeleton_kingdom'
  | 'ghost_swamp'
  | 'goblin_kingdom'
  | 'volcano_region'
  | 'frozen_kingdom'
  | 'desert_dunes'
  | 'ancient_lands';

export type ElementType = 'fire' | 'ice' | 'water' | 'lightning';

export type Rarity = 'Common' | 'Uncommon' | 'Rare' | 'Epic' | 'Legendary' | 'Mythical';

export type WeaponCategory =
  | 'Sword'
  | 'Greatsword'
  | 'Dagger'
  | 'Axe'
  | 'Bow'
  | 'Shield'
  | 'Staff';

export type EquipmentSlot =
  | 'weapon'
  | 'shield'
  | 'helmet'
  | 'chest'
  | 'gloves'
  | 'boots'
  | 'ring'
  | 'amulet';

export type ItemCategory =
  | EquipmentSlot
  | 'resource'
  | 'food'
  | 'raw_food'
  | 'potion'
  | 'magic_item'
  | 'building_mat'
  | 'artifact';

export interface ItemDef {
  id: string;
  name: string;
  category: ItemCategory;
  rarity: Rarity;
  description: string;
  slot?: EquipmentSlot;
  weaponCategory?: WeaponCategory;
  attackBonus?: number;
  defenseBonus?: number;
  magicBonus?: number;
  speedBonus?: number;
  healHp?: number;
  healMana?: number;
  restoreHunger?: number;
  value: number;
  color: string;
}

export interface InventoryEntry {
  itemId: string;
  quantity: number;
}

export interface SpellDef {
  id: string;
  name: string;
  element: ElementType;
  tier: 1 | 2 | 3 | 4;
  manaCost: number;
  cooldown: number;
  baseDamage: number;
  range: number;
  radius: number;
  description: string;
  unlockLevel: number;
  isHeal?: boolean;
  isShield?: boolean;
}

export interface SkillNode {
  id: string;
  name: string;
  branch: 'combat' | 'fire' | 'ice' | 'water' | 'lightning' | 'survival';
  description: string;
  maxRank: number;
  costPerRank: number;
  statKey: string;
  bonusPerRank: number;
}

export type CreatureId =
  | 'royal_stag'
  | 'giant_eagle'
  | 'crystal_fox'
  | 'rock_turtle'
  | 'magical_butterflies'
  | 'mountain_goat'
  | 'small_dragon'
  | 'moon_horse'
  | 'river_otter'
  | 'air_jellyfish';

export interface CreatureDef {
  id: CreatureId;
  name: string;
  region: RegionId;
  behavior:
    | 'lead_to_secret'
    | 'soar_high'
    | 'glow_trail'
    | 'river_graze'
    | 'flora_orbit'
    | 'cliff_climb'
    | 'tameable_companion'
    | 'rideable_mount'
    | 'resource_gather'
    | 'cave_float';
  description: string;
  hp: number;
  speed: number;
  scale: number;
  primaryColor: string;
  accentColor: string;
  canTame?: boolean;
  canRide?: boolean;
  flies?: boolean;
  fleesWhenHit?: boolean;
}

export type EnemyRegionGroup =
  | 'shadow_forest'
  | 'iron_mountains'
  | 'skeleton_ruins'
  | 'ghost_swamp'
  | 'goblin_castle';

export type EnemyAIStyle =
  | 'patrol'
  | 'guard'
  | 'hunter'
  | 'pack'
  | 'ambush'
  | 'ranged'
  | 'caster'
  | 'healer'
  | 'builder'
  | 'flying'
  | 'burrower'
  | 'charger'
  | 'stealth';

export interface EnemyDef {
  id: string;
  index: number;
  name: string;
  group: EnemyRegionGroup;
  region: RegionId;
  archetype: string;
  aiStyle: EnemyAIStyle;
  hp: number;
  damage: number;
  speed: number;
  detectionRange: number;
  attackRange: number;
  attackCooldown: number;
  xpReward: number;
  scale: number;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  weakness: ElementType;
  resistance: ElementType;
  loot: Array<{ itemId: string; chance: number }>;
  flies?: boolean;
  ranged?: boolean;
  slowsPlayer?: boolean;
  poisonsPlayer?: boolean;
  healsAllies?: boolean;
  buildsTurrets?: boolean;
  burrows?: boolean;
  teleports?: boolean;
  multiHead?: boolean;
  mounted?: boolean;
}

export interface BossDef {
  id: string;
  order: number;
  name: string;
  title: string;
  region: RegionId;
  arenaX: number;
  arenaZ: number;
  arenaRadius: number;
  hp: number;
  damage: number;
  speed: number;
  xpReward: number;
  primaryColor: string;
  accentColor: string;
  weakness: ElementType;
  summonEnemyIds: string[];
  rewards: string[];
  resourceDrops?: Array<{ itemId: string; count: number }>;
  unlockAbility: string;
  requiresPreviousBosses?: number;
  description: string;
}

export interface RegionDef {
  id: RegionId;
  name: string;
  subtitle: string;
  centerX: number;
  centerZ: number;
  radius: number;
  groundColor: string;
  accentGroundColor: string;
  fogColor: string;
  skyTint: string;
  ambientLightColor: string;
  waterColor: string;
  recommendedLevel: number;
  weatherBias: 'clear' | 'rain' | 'storm' | 'fog' | 'snow' | 'ash';
}

export type QuestType =
  | 'Main'
  | 'Side'
  | 'Exploration'
  | 'Hunting'
  | 'Gathering'
  | 'Boss'
  | 'Rescue'
  | 'Dungeon';

export interface QuestObjective {
  id: string;
  description: string;
  targetType: 'visit_region' | 'kill_enemy' | 'kill_boss' | 'collect_item' | 'talk_npc' | 'tame_creature' | 'build_structure';
  targetId: string;
  requiredCount: number;
}

export interface QuestDef {
  id: string;
  title: string;
  type: QuestType;
  giverNpcId: string;
  description: string;
  objectives: QuestObjective[];
  xpReward: number;
  goldReward: number;
  itemRewards: string[];
  prerequisiteQuestId?: string;
}

export interface QuestProgress {
  questId: string;
  counts: Record<string, number>;
  completed: boolean;
  claimed: boolean;
}

export interface NpcDef {
  id: string;
  name: string;
  role: 'Villager' | 'Merchant' | 'Guard' | 'Blacksmith' | 'Wizard' | 'QuestGiver' | 'Farmer' | 'Traveler';
  region: RegionId;
  homeX: number;
  homeZ: number;
  patrolRadius: number;
  robeColor: string;
  hairColor: string;
  greeting: string;
  questIds: string[];
  shopItemIds?: string[];
}

export interface CraftingRecipe {
  id: string;
  resultItemId: string;
  resultCount: number;
  category: 'Weapons' | 'Armor' | 'Potions' | 'Food' | 'Magic' | 'Building';
  ingredients: Array<{ itemId: string; count: number }>;
  requiresCampfire?: boolean;
}

export type StructureType =
  | 'house'
  | 'wall'
  | 'tower'
  | 'storage'
  | 'workshop'
  | 'farm'
  | 'castle'
  | 'campfire';

export interface BuildingDef {
  type: StructureType;
  name: string;
  description: string;
  cost: Array<{ itemId: string; count: number }>;
  footprint: number;
}

export interface PlacedStructure {
  id: string;
  type: StructureType;
  x: number;
  y: number;
  z: number;
  ry: number;
  owner?: string;
}

export interface PlayerAppearance {
  name: string;
  hairStyle: 'short' | 'long' | 'ponytail' | 'hooded' | 'crown';
  hairColor: string;
  skinColor: string;
  faceStyle: 'determined' | 'calm' | 'scarred' | 'mystic';
  tunicColor: string;
  armorColor: string;
  accessory: 'none' | 'cape' | 'quiver' | 'wings_charm';
}

export type GraphicsQuality = 'Low' | 'Medium' | 'High' | 'Ultra';
export type CameraMode = 'third' | 'first';
export type WeatherType = 'clear' | 'rain' | 'storm' | 'fog' | 'snow' | 'wind';

export interface HudLayoutConfig {
  joystickScale: number;
  buttonsScale: number;
  elementalOffsetY: number;
  showTouchControls: 'auto' | 'always' | 'hidden';
}

export interface GameSettings {
  graphics: GraphicsQuality;
  survivalMode: boolean;
  audioEnabled: boolean;
  musicVolume: number;
  sfxVolume: number;
  invertY: boolean;
  cameraSensitivity: number;
  hudLayout: HudLayoutConfig;
}

export interface PlayerStats {
  level: number;
  xp: number;
  xpToNext: number;
  hp: number;
  maxHp: number;
  mana: number;
  maxMana: number;
  stamina: number;
  maxStamina: number;
  hunger: number;
  maxHunger: number;
  gold: number;
  skillPoints: number;
  baseStrength: number;
  baseDefense: number;
  baseMagic: number;
  baseSpeed: number;
}

export interface SaveData {
  version: number;
  savedAt: number;
  position: { x: number; y: number; z: number; yaw: number };
  stats: PlayerStats;
  appearance: PlayerAppearance;
  equipped: Partial<Record<EquipmentSlot, string>>;
  inventory: InventoryEntry[];
  unlockedSpells: string[];
  spellLevels: Record<string, number>;
  selectedSpells: Record<ElementType, string>;
  skillRanks: Record<string, number>;
  quests: Record<string, QuestProgress>;
  discoveredRegions: RegionId[];
  defeatedBosses: string[];
  tamedCompanion: boolean;
  tamedMount: boolean;
  structures: PlacedStructure[];
  timeOfDay: number;
  settings: GameSettings;
}

export interface RemotePlayer {
  id: string;
  name: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  anim: string;
  level: number;
  hp: number;
  maxHp: number;
  hairColor: string;
  skinColor: string;
  armorColor: string;
  weaponType: string;
  mounted: boolean;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
}
