import * as THREE from "three";
import { buildZombieSprites, ZombieSpriteSet } from "./zombieSprites";
import type { Dir } from "./sprites";
import { iconCanvas } from "./itemIcons";
import { pixelTexture } from "./zombieSprites";
import type { ItemId } from "./items";

export interface ZWorld {
  ground(x: number, z: number, y: number): number;
  water(x: number, z: number): number;
  collide(p: { x: number; y: number; z: number }, r: number): void;
}

interface Zombie {
  mesh: THREE.Mesh;
  mat: THREE.MeshBasicMaterial;
  shadow: THREE.Mesh;
  hpBg: THREE.Sprite;
  hpFg: THREE.Sprite;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  kb: THREE.Vector2;
  hp: number;
  maxHp: number;
  facing: number;
  state: "wander" | "chase" | "attack" | "dead";
  timer: number;
  wdir: number;
  atkT: number;
  atkCd: number;
  hurtT: number;
  stun: number;
  anim: number;
  deadT: number;
  showHp: number;
  lastX: number;
  lastZ: number;
  stuckT: number;
  detour: number;
  speedMul: number;
}

export interface ZUpdateCtx {
  player: THREE.Vector3;
  playerAlive: boolean;
  playerSwimming: boolean;
  camYaw: number;
  light: number;
  night: number;
  world: ZWorld;
  onAttack(dmg: number, fromX: number, fromZ: number): void;
}

export class ZombieManager {
  group = new THREE.Group();
  list: Zombie[] = [];
  private sprites: ZombieSpriteSet;
  private geo: THREE.PlaneGeometry;
  private shadowGeo: THREE.PlaneGeometry;
  private shadowMat: THREE.MeshBasicMaterial;
  private hpBgMat = new THREE.SpriteMaterial({ color: 0x1a0a10, depthTest: true, fog: false });
  private hpFgMat = new THREE.SpriteMaterial({ color: 0xd8354a, depthTest: true, fog: false });
  private tmp = { x: 0, y: 0, z: 0 };

  constructor() {
    this.sprites = buildZombieSprites();
    this.geo = new THREE.PlaneGeometry(1, 1);
    this.geo.translate(0, 0.5, 0);
    const cv = document.createElement("canvas");
    cv.width = cv.height = 16;
    const cx = cv.getContext("2d")!;
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
      const d = Math.hypot(x - 7.5, y - 7.5) / 8;
      if (d < 1) { cx.fillStyle = `rgba(0,0,0,${d < 0.6 ? 0.45 : 0.25})`; cx.fillRect(x, y, 1, 1); }
    }
    this.shadowGeo = new THREE.PlaneGeometry(1.3, 0.9);
    this.shadowGeo.rotateX(-Math.PI / 2);
    this.shadowMat = new THREE.MeshBasicMaterial({ map: pixelTexture(cv), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 });
  }

  get aliveCount() {
    let n = 0;
    for (const z of this.list) if (z.state !== "dead") n++;
    return n;
  }

  spawn(x: number, y: number, z: number, strong = false) {
    const mat = new THREE.MeshBasicMaterial({ map: this.sprites.idle.front[0].tex, alphaTest: 0.5, side: THREE.DoubleSide, fog: true });
    const mesh = new THREE.Mesh(this.geo, mat);
    mesh.rotation.order = "YXZ";
    mesh.renderOrder = 1;
    const shadow = new THREE.Mesh(this.shadowGeo, this.shadowMat);
    const hpBg = new THREE.Sprite(this.hpBgMat);
    const hpFg = new THREE.Sprite(this.hpFgMat);
    hpBg.scale.set(1.1, 0.14, 1);
    hpFg.scale.set(1.0, 0.08, 1);
    hpBg.renderOrder = 7;
    hpFg.renderOrder = 8;
    hpBg.visible = hpFg.visible = false;
    this.group.add(mesh, shadow, hpBg, hpFg);
    const maxHp = strong ? 90 : 60;
    this.list.push({
      mesh, mat, shadow, hpBg, hpFg,
      pos: new THREE.Vector3(x, y, z), vel: new THREE.Vector3(), kb: new THREE.Vector2(),
      hp: maxHp, maxHp, facing: Math.random() * Math.PI * 2, state: "wander",
      timer: Math.random() * 3, wdir: Math.random() * Math.PI * 2, atkT: 0, atkCd: 0, hurtT: 0, stun: 0,
      anim: Math.random() * 4, deadT: 0, showHp: 0, lastX: x, lastZ: z, stuckT: 0, detour: 0,
      speedMul: 0.9 + Math.random() * 0.25,
    });
  }

  private removeAt(i: number) {
    const z = this.list[i];
    z.mat.dispose();
    this.group.remove(z.mesh, z.shadow, z.hpBg, z.hpFg);
    this.list.splice(i, 1);
  }

  clear() {
    for (let i = this.list.length - 1; i >= 0; i--) this.removeAt(i);
  }

  despawnFar(p: THREE.Vector3, dist: number) {
    for (let i = this.list.length - 1; i >= 0; i--) {
      const z = this.list[i];
      if (Math.hypot(z.pos.x - p.x, z.pos.z - p.z) > dist) this.removeAt(i);
    }
  }

  nearest(p: THREE.Vector3, maxD: number) {
    let best: Zombie | null = null, bd = maxD;
    for (const z of this.list) {
      if (z.state === "dead") continue;
      const d = Math.hypot(z.pos.x - p.x, z.pos.z - p.z);
      if (d < bd && Math.abs(z.pos.y - p.y) < 2.5) { bd = d; best = z; }
    }
    return best;
  }

  /** melee hit test; returns hit count and positions of killed zombies */
  hit(origin: THREE.Vector3, facing: number, range: number, dmg: number) {
    const fx = Math.sin(facing), fz = Math.cos(facing);
    const killed: THREE.Vector3[] = [];
    let hits = 0;
    for (const z of this.list) {
      if (z.state === "dead") continue;
      const dx = z.pos.x - origin.x, dz = z.pos.z - origin.z;
      const d = Math.hypot(dx, dz);
      if (d > range || Math.abs(z.pos.y - origin.y) > 2) continue;
      if (d > 0.6 && (dx * fx + dz * fz) / d < 0.25) continue;
      hits++;
      const dealt = dmg * (0.85 + Math.random() * 0.3);
      z.hp -= dealt;
      z.hurtT = 0.18;
      z.stun = 0.35;
      z.atkT = 0;
      z.showHp = 4;
      const k = d > 0.01 ? 1 / d : 0;
      z.kb.set(dx * k * 7, dz * k * 7);
      z.state = "chase";
      if (z.hp <= 0) {
        z.hp = 0;
        z.state = "dead";
        z.deadT = 0;
        killed.push(z.pos.clone());
      }
    }
    return { hits, killed };
  }

  update(dt: number, C: ZUpdateCtx) {
    const P = C.player;
    const aggro = C.night > 0.5 ? 22 : 15;
    for (let i = this.list.length - 1; i >= 0; i--) {
      const z = this.list[i];
      z.hurtT -= dt;
      z.showHp -= dt;
      if (z.state === "dead") {
        z.deadT += dt;
        const fall = Math.min(1, z.deadT / 0.35);
        z.mesh.rotation.z = (z.facing > 0 ? 1 : -1) * fall * 1.45;
        if (z.deadT > 1.3) z.mesh.position.y = z.pos.y - (z.deadT - 1.3) * 0.9;
        else z.mesh.position.y = z.pos.y;
        z.mat.color.setRGB(0.55, 0.35, 0.35).multiplyScalar(C.light);
        z.hpBg.visible = z.hpFg.visible = false;
        z.shadow.visible = z.deadT < 1.3;
        z.mesh.rotation.y = C.camYaw;
        if (z.deadT > 2.2) this.removeAt(i);
        continue;
      }
      const dx = P.x - z.pos.x, dz = P.z - z.pos.z;
      const dist = Math.hypot(dx, dz);
      const seesPlayer = C.playerAlive && dist < aggro && Math.abs(P.y - z.pos.y) < 6;
      z.stun -= dt;
      z.atkCd -= dt;
      let tx = 0, tz = 0, speed = 0;

      if (z.atkT > 0) {
        // attack wind-up
        z.atkT += dt;
        z.facing = Math.atan2(dx, dz);
        if (z.atkT > 0.45 && z.atkT - dt <= 0.45) {
          if (C.playerAlive && dist < 1.75 && Math.abs(P.y - z.pos.y) < 1.6) C.onAttack(9 + Math.floor(Math.random() * 5), z.pos.x, z.pos.z);
        }
        if (z.atkT > 0.75) { z.atkT = 0; z.atkCd = 1.0; }
      } else if (z.stun <= 0) {
        if (seesPlayer) {
          z.state = "chase";
          if (dist < 1.3 && z.atkCd <= 0 && !C.playerSwimming) {
            z.atkT = 0.001;
          } else if (dist > 1.0) {
            let ang = Math.atan2(dx, dz);
            if (z.detour !== 0) ang += z.detour;
            tx = Math.sin(ang); tz = Math.cos(ang);
            speed = (C.night > 0.5 ? 2.9 : 2.4) * z.speedMul;
          }
        } else {
          z.state = "wander";
          z.timer -= dt;
          if (z.timer <= 0) {
            z.timer = 2.5 + Math.random() * 4;
            z.wdir = Math.random() < 0.35 ? -1 : Math.random() * Math.PI * 2;
          }
          if (z.wdir >= 0) { tx = Math.sin(z.wdir); tz = Math.cos(z.wdir); speed = 0.9 * z.speedMul; }
        }
      }

      // separation
      for (const o of this.list) {
        if (o === z || o.state === "dead") continue;
        const ox = z.pos.x - o.pos.x, oz = z.pos.z - o.pos.z;
        const d2 = ox * ox + oz * oz;
        if (d2 < 1.2 && d2 > 1e-4) {
          const d = Math.sqrt(d2);
          tx += (ox / d) * 0.8; tz += (oz / d) * 0.8;
        }
      }

      const k = 1 - Math.exp(-8 * dt);
      z.vel.x += (tx * speed - z.vel.x) * k;
      z.vel.z += (tz * speed - z.vel.z) * k;
      if (speed > 0.1) {
        const tf = Math.atan2(tx, tz);
        let d = tf - z.facing;
        while (d > Math.PI) d -= Math.PI * 2;
        while (d < -Math.PI) d += Math.PI * 2;
        z.facing += d * (1 - Math.exp(-6 * dt));
      }
      let nx = z.pos.x + (z.vel.x + z.kb.x) * dt;
      let nz = z.pos.z + (z.vel.z + z.kb.y) * dt;
      z.kb.multiplyScalar(Math.exp(-7 * dt));
      const W = C.world;
      const t = this.tmp;
      t.x = nx; t.y = z.pos.y; t.z = nz;
      W.collide(t, 0.35);
      nx = t.x; nz = t.z;
      const g = W.ground(nx, nz, z.pos.y);
      const wl = W.water(nx, nz);
      const tooSteep = g - z.pos.y > 1.2;
      if (wl > g + 0.9 || tooSteep) {
        nx = z.pos.x; nz = z.pos.z;
        if (z.state === "wander") z.timer = 0;
      }
      // stuck detection -> detour
      z.stuckT += dt;
      if (z.stuckT > 0.7) {
        const moved = Math.hypot(nx - z.lastX, nz - z.lastZ);
        if (z.state === "chase" && moved < 0.35 && speed > 0) z.detour = z.detour === 0 ? (Math.random() < 0.5 ? 1.2 : -1.2) : 0;
        else if (moved > 0.8) z.detour = 0;
        z.lastX = nx; z.lastZ = nz; z.stuckT = 0;
      }
      z.pos.x = nx; z.pos.z = nz;
      const gy = W.ground(nx, nz, z.pos.y);
      z.pos.y += (gy - z.pos.y) * Math.min(1, dt * 14);
      if (Math.abs(gy - z.pos.y) > 2) z.pos.y = gy;

      // ---- sprite ----
      const camAng = Math.atan2(-Math.sin(C.camYaw), -Math.cos(C.camYaw));
      let diff = z.facing - camAng;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      const ad = Math.abs(diff);
      let dir: Dir = "back", flip = 1;
      if (ad < Math.PI * 0.27) dir = "back";
      else if (ad > Math.PI * 0.73) dir = "front";
      else { dir = "side"; flip = diff < 0 ? 1 : -1; }
      const hs = Math.hypot(z.vel.x, z.vel.z);
      let set = hs > 0.3 ? this.sprites.walk[dir] : this.sprites.idle[dir];
      z.anim += dt * (hs > 0.3 ? hs * 1.2 + 1 : 1.1);
      let idx = Math.floor(z.anim) % set.length;
      if (z.atkT > 0) { set = this.sprites.attack[dir]; idx = z.atkT > 0.45 ? 1 : 0; }
      const fr = set[idx];
      if (z.mat.map !== fr.tex) z.mat.map = fr.tex;
      const h = 2.1;
      z.mesh.scale.set(h * fr.aspect * flip, h, 1);
      z.mesh.position.set(z.pos.x, z.pos.y + (z.atkT > 0.45 ? 0.05 : 0), z.pos.z);
      z.mesh.rotation.set(0, C.camYaw, (hs > 0.3 ? Math.sin(z.anim * Math.PI) * 0.04 : 0) + (z.atkT > 0 ? -0.08 * flip : 0));
      if (z.hurtT > 0) z.mat.color.setRGB(1.6, 0.45, 0.45);
      else z.mat.color.setScalar(C.light * 0.96);
      z.shadow.position.set(z.pos.x, gy + 0.04, z.pos.z);
      z.shadow.visible = true;
      const show = z.showHp > 0 || z.hp < z.maxHp;
      z.hpBg.visible = z.hpFg.visible = show;
      if (show) {
        const r = Math.max(0.02, z.hp / z.maxHp);
        const top = z.pos.y + 2.35;
        z.hpBg.position.set(z.pos.x, top, z.pos.z);
        z.hpFg.position.set(z.pos.x, top, z.pos.z);
        z.hpFg.scale.set(1.0 * r, 0.08, 1);
        z.hpFg.center.set(0.5 / r, 0.5);
      }
    }
  }
}

// ---------------- dropped items ----------------
interface Drop {
  sprite: THREE.Sprite;
  id: ItemId;
  n: number;
  x: number;
  y: number;
  z: number;
  t: number;
  delay: number;
}

export class DropManager {
  group = new THREE.Group();
  list: Drop[] = [];
  private mats = new Map<ItemId, THREE.SpriteMaterial>();

  private mat(id: ItemId) {
    let m = this.mats.get(id);
    if (!m) {
      m = new THREE.SpriteMaterial({ map: pixelTexture(iconCanvas(id)), alphaTest: 0.5, fog: true });
      this.mats.set(id, m);
    }
    return m;
  }

  add(id: ItemId, n: number, x: number, y: number, z: number, delay = 0.4) {
    const sprite = new THREE.Sprite(this.mat(id));
    sprite.scale.set(0.6, 0.6, 1);
    sprite.renderOrder = 1;
    this.group.add(sprite);
    const a = Math.random() * Math.PI * 2, r = 0.3 + Math.random() * 0.6;
    this.list.push({ sprite, id, n, x: x + Math.cos(a) * r, y, z: z + Math.sin(a) * r, t: Math.random() * 6, delay });
  }

  clear() {
    for (const d of this.list) this.group.remove(d.sprite);
    this.list = [];
  }

  update(dt: number, p: THREE.Vector3, light: number, ground: (x: number, z: number, y: number) => number, pickup: (id: ItemId, n: number) => boolean) {
    for (let i = this.list.length - 1; i >= 0; i--) {
      const d = this.list[i];
      d.t += dt;
      d.delay -= dt;
      const g = ground(d.x, d.z, d.y + 1);
      d.y = g;
      d.sprite.position.set(d.x, g + 0.45 + Math.sin(d.t * 3) * 0.1, d.z);
      (d.sprite.material as THREE.SpriteMaterial).color.setScalar(Math.min(1.1, light + 0.1));
      const dist = Math.hypot(d.x - p.x, d.z - p.z);
      if (d.delay <= 0 && dist < 1.5 && Math.abs(p.y - g) < 2) {
        if (pickup(d.id, d.n)) {
          this.group.remove(d.sprite);
          this.list.splice(i, 1);
        }
      } else if (dist > 140 || d.t > 400) {
        this.group.remove(d.sprite);
        this.list.splice(i, 1);
      }
    }
  }
}
