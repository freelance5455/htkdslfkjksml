import * as THREE from "three";
import { resolveCircleAabb } from "@/game/player";
import type { AABB } from "@/game/types";

const MAX = 16;
const RADIUS = 0.36;

type Zombie = {
  alive: boolean;
  x: number;
  z: number;
  hp: number;
  maxHp: number;
  speed: number;
  yaw: number;
  attackCd: number;
  phase: number;
  dying: number;
  flash: number;
  mesh: THREE.Group;
  head: THREE.Object3D;
  armL: THREE.Object3D;
  armR: THREE.Object3D;
  legL: THREE.Object3D;
  legR: THREE.Object3D;
  bodyMat: THREE.MeshLambertMaterial;
  skinMat: THREE.MeshLambertMaterial;
};

export type ZombieHit = {
  index: number;
  head: boolean;
  point: THREE.Vector3;
  zombie: Zombie;
};

const CLOTH = [0x3a3228, 0x2c3328, 0x403028, 0x243028, 0x38302c];
const SKIN = [0x8a8a70, 0x7a7460, 0x6e6a58, 0x90866c];

function makeRig(
  cloth: THREE.MeshLambertMaterial,
  skin: THREE.MeshLambertMaterial,
  geos: THREE.BufferGeometry[],
): Pick<Zombie, "mesh" | "head" | "armL" | "armR" | "legL" | "legR"> {
  const g = new THREE.Group();
  const box = (w: number, h: number, d: number) => {
    const geo = new THREE.BoxGeometry(w, h, d);
    geos.push(geo);
    return geo;
  };

  const torso = new THREE.Mesh(box(0.4, 0.58, 0.24), cloth);
  torso.position.y = 1.08;
  g.add(torso);

  const head = new THREE.Mesh(box(0.24, 0.26, 0.24), skin);
  head.position.y = 1.5;
  head.name = "head";
  g.add(head);

  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x3a0808 });
  const eyeL = new THREE.Mesh(box(0.05, 0.04, 0.04), eyeMat);
  const eyeR = eyeL.clone();
  eyeL.position.set(-0.06, 1.52, 0.12);
  eyeR.position.set(0.06, 1.52, 0.12);
  g.add(eyeL, eyeR);

  const armL = new THREE.Group();
  const armR = new THREE.Group();
  const armMeshL = new THREE.Mesh(box(0.1, 0.52, 0.1), skin);
  const armMeshR = new THREE.Mesh(box(0.1, 0.52, 0.1), skin);
  armMeshL.position.y = -0.22;
  armMeshR.position.y = -0.22;
  armL.add(armMeshL);
  armR.add(armMeshR);
  armL.position.set(-0.26, 1.28, 0);
  armR.position.set(0.26, 1.28, 0);
  g.add(armL, armR);

  const legL = new THREE.Group();
  const legR = new THREE.Group();
  const legMeshL = new THREE.Mesh(box(0.14, 0.7, 0.14), cloth);
  const legMeshR = new THREE.Mesh(box(0.14, 0.7, 0.14), cloth);
  legMeshL.position.y = -0.32;
  legMeshR.position.y = -0.32;
  legL.add(legMeshL);
  legR.add(legMeshR);
  legL.position.set(-0.12, 0.72, 0);
  legR.position.set(0.12, 0.72, 0);
  g.add(legL, legR);

  g.traverse((o) => {
    o.castShadow = false;
  });
  return { mesh: g, head, armL, armR, legL, legR };
}

export class ZombieHorde {
  private pool: Zombie[] = [];
  private geos: THREE.BufferGeometry[] = [];
  private extraMats: THREE.Material[] = [];
  readonly targets: THREE.Object3D[] = [];

  constructor(scene: THREE.Scene) {
    for (let i = 0; i < MAX; i++) {
      const bodyMat = new THREE.MeshLambertMaterial({ color: CLOTH[i % CLOTH.length] });
      const skinMat = new THREE.MeshLambertMaterial({ color: SKIN[i % SKIN.length] });
      const rig = makeRig(bodyMat, skinMat, this.geos);
      rig.mesh.visible = false;
      rig.mesh.userData.zombieIndex = i;
      rig.mesh.traverse((o) => {
        o.userData.zombieIndex = i;
      });
      scene.add(rig.mesh);
      this.targets.push(rig.mesh);
      this.pool.push({
        alive: false,
        x: 0,
        z: 0,
        hp: 0,
        maxHp: 100,
        speed: 1.4,
        yaw: 0,
        attackCd: 0,
        phase: Math.random() * Math.PI * 2,
        dying: 0,
        flash: 0,
        mesh: rig.mesh,
        head: rig.head,
        armL: rig.armL,
        armR: rig.armR,
        legL: rig.legL,
        legR: rig.legR,
        bodyMat,
        skinMat,
      });
    }
  }

  get aliveCount() {
    return this.pool.filter((z) => z.alive).length;
  }

  spawn(x: number, z: number, hp: number, speed: number) {
    const zed = this.pool.find((z) => !z.alive && z.dying <= 0);
    if (!zed) return false;
    zed.alive = true;
    zed.x = x;
    zed.z = z;
    zed.hp = hp;
    zed.maxHp = hp;
    zed.speed = speed;
    zed.yaw = Math.random() * Math.PI * 2;
    zed.attackCd = 0.4;
    zed.dying = 0;
    zed.flash = 0;
    zed.mesh.visible = true;
    zed.mesh.rotation.set(0, zed.yaw, 0);
    zed.mesh.position.set(x, 0, z);
    zed.mesh.scale.set(1, 1, 1);
    zed.bodyMat.emissive.setHex(0x000000);
    zed.skinMat.emissive.setHex(0x000000);
    return true;
  }

  reset() {
    for (const z of this.pool) {
      z.alive = false;
      z.dying = 0;
      z.mesh.visible = false;
    }
  }

  hitFromRay(hit: THREE.Intersection, damageBody: number, damageHead: number): ZombieHit | null {
    const idx = hit.object.userData.zombieIndex as number | undefined;
    if (idx === undefined) return null;
    const z = this.pool[idx];
    if (!z?.alive) return null;
    let obj: THREE.Object3D | null = hit.object;
    let isHead = false;
    while (obj) {
      if (obj.name === "head") {
        isHead = true;
        break;
      }
      obj = obj.parent;
    }
    z.hp -= isHead ? damageHead : damageBody;
    z.flash = 0.09;
    const point = hit.point.clone();
    if (z.hp <= 0) {
      z.alive = false;
      z.dying = 0.85;
    }
    return { index: idx, head: isHead, point, zombie: z };
  }

  update(
    dt: number,
    px: number,
    pz: number,
    colliders: AABB[],
    onBite: (dmg: number) => void,
  ) {
    for (let i = 0; i < this.pool.length; i++) {
      const z = this.pool[i];
      if (z.dying > 0) {
        z.dying -= dt;
        const t = 1 - z.dying / 0.85;
        z.mesh.rotation.x = t * 1.35;
        z.mesh.position.y = -t * 0.15;
        z.mesh.scale.setScalar(1 - t * 0.15);
        if (z.dying <= 0) z.mesh.visible = false;
        continue;
      }
      if (!z.alive) continue;

      if (z.flash > 0) {
        z.flash -= dt;
        const lit = z.flash > 0;
        z.bodyMat.emissive.setHex(lit ? 0x442218 : 0x000000);
        z.skinMat.emissive.setHex(lit ? 0x331808 : 0x000000);
      }

      const dx = px - z.x;
      const dz = pz - z.z;
      const dist = Math.hypot(dx, dz) || 0.001;
      const nx = dx / dist;
      const nz = dz / dist;

      let sepX = 0;
      let sepZ = 0;
      for (let j = 0; j < this.pool.length; j++) {
        if (i === j) continue;
        const o = this.pool[j];
        if (!o.alive) continue;
        const sdx = z.x - o.x;
        const sdz = z.z - o.z;
        const sd = Math.hypot(sdx, sdz);
        if (sd > 0.01 && sd < 0.85) {
          sepX += (sdx / sd) * (0.85 - sd);
          sepZ += (sdz / sd) * (0.85 - sd);
        }
      }

      const lurch = 0.75 + 0.25 * Math.sin(z.phase + performance.now() * 0.004);
      z.x += (nx * z.speed * lurch + sepX * 1.6) * dt;
      z.z += (nz * z.speed * lurch + sepZ * 1.6) * dt;
      for (const box of colliders) {
        const n = resolveCircleAabb(z.x, z.z, RADIUS, box);
        z.x = n.x;
        z.z = n.z;
      }

      z.yaw = Math.atan2(nx, nz);
      z.mesh.position.set(z.x, 0, z.z);
      z.mesh.rotation.y = z.yaw;
      z.phase += dt * z.speed * 3.2;
      const swing = Math.sin(z.phase) * 0.55;
      z.legL.rotation.x = swing;
      z.legR.rotation.x = -swing;
      z.armL.rotation.x = -swing * 0.7 - 0.3;
      z.armR.rotation.x = swing * 0.7 - 0.3;

      if (z.attackCd > 0) z.attackCd -= dt;
      if (dist < 1.2 && z.attackCd <= 0) {
        z.attackCd = 0.85;
        onBite(14);
      }
    }
  }

  knockback(index: number, dirX: number, dirZ: number, amt: number) {
    const z = this.pool[index];
    if (!z?.alive) return;
    z.x += dirX * amt;
    z.z += dirZ * amt;
  }

  dispose() {
    for (const g of this.geos) g.dispose();
    for (const z of this.pool) {
      z.bodyMat.dispose();
      z.skinMat.dispose();
    }
    for (const m of this.extraMats) m.dispose();
  }
}
