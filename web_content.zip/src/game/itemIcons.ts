import type { ItemId } from "./items";

// 16x16 pixel-art icons drawn in the same outlined style as the characters
type Ctx = CanvasRenderingContext2D;
const S = 16;
const OUT = "#0e090c";

function p(c: Ctx, x: number, y: number, col: string, w = 1, h = 1) {
  c.fillStyle = col;
  c.fillRect(x, y, w, h);
}

function outline(cv: HTMLCanvasElement) {
  const c = cv.getContext("2d")!;
  const img = c.getImageData(0, 0, S, S);
  const d = img.data;
  const out = new Uint8ClampedArray(d);
  for (let y = 0; y < S; y++)
    for (let x = 0; x < S; x++) {
      const i = (y * S + x) * 4;
      if (d[i + 3] > 0) continue;
      for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const xx = x + ox, yy = y + oy;
        if (xx < 0 || yy < 0 || xx >= S || yy >= S) continue;
        if (d[(yy * S + xx) * 4 + 3] > 0) {
          out[i] = 14; out[i + 1] = 9; out[i + 2] = 12; out[i + 3] = 255;
          break;
        }
      }
    }
  c.putImageData(new ImageData(out, S, S), 0, 0);
}

const DRAW: Record<ItemId, (c: Ctx) => void> = {
  espada: (c) => {
    // blade diagonal (bottom-left handle -> top-right tip)
    for (let i = 0; i < 9; i++) {
      p(c, 5 + i, 9 - i, "#c89c62");
      p(c, 6 + i, 9 - i, "#a57a45");
      p(c, 5 + i, 8 - i, "#e3c089");
    }
    p(c, 14, 0, "#e3c089");
    // guard
    for (let i = 0; i < 5; i++) p(c, 2 + i, 7 + i, "#6b4424");
    p(c, 3, 8, "#8a5a32"); p(c, 4, 9, "#8a5a32");
    // handle
    p(c, 3, 11, "#4a2e18"); p(c, 2, 12, "#5d3a1f"); p(c, 1, 13, "#4a2e18");
    p(c, 0, 14, "#7a5230", 2, 2);
  },
  maca: (c) => {
    p(c, 4, 5, "#c0282c", 8, 8);
    p(c, 3, 6, "#c0282c", 10, 6);
    p(c, 5, 13, "#8e1a20", 6, 1);
    p(c, 3, 11, "#8e1a20", 1, 1); p(c, 12, 11, "#8e1a20");
    p(c, 10, 7, "#8e1a20", 2, 5);
    p(c, 5, 6, "#f06a5c", 2, 2); p(c, 4, 7, "#f06a5c");
    p(c, 7, 4, "#8e1a20", 2, 1);
    p(c, 8, 1, "#5a3a1e", 1, 4);
    p(c, 9, 2, "#4f9a3a", 3, 1); p(c, 10, 1, "#6fbf4a", 2, 1); p(c, 9, 3, "#3d7a2e", 2, 1);
  },
  frutas: (c) => {
    const b = (x: number, y: number, col: string, hi: string) => {
      p(c, x, y, col, 4, 4); p(c, x - 1, y + 1, col, 6, 2); p(c, x, y - 1 + 1, col);
      p(c, x + 1, y + 1, hi);
    };
    p(c, 7, 1, "#3d7a2e", 1, 5); p(c, 8, 2, "#4f9a3a", 3, 2); p(c, 4, 3, "#4f9a3a", 3, 2);
    b(3, 6, "#6a2a8c", "#b574e0");
    b(9, 6, "#7a1d4a", "#e0689c");
    b(6, 10, "#5b2a90", "#a57ae8");
  },
  pocao: (c) => {
    p(c, 6, 1, "#8a6a4a", 4, 2);
    p(c, 6, 3, "#cfd8e0", 4, 2);
    p(c, 4, 5, "#cfd8e0", 8, 1);
    p(c, 3, 6, "#cfd8e0", 10, 8);
    p(c, 4, 14, "#cfd8e0", 8, 1);
    p(c, 4, 8, "#d2204a", 8, 6);
    p(c, 5, 7, "#d2204a", 6, 1);
    p(c, 4, 13, "#8e1030", 8, 1);
    p(c, 5, 9, "#ff7090", 2, 2);
    p(c, 10, 6, "#ffffff", 1, 2);
  },
  carne: (c) => {
    p(c, 3, 5, "#7a5a3a", 10, 7);
    p(c, 2, 6, "#7a5a3a", 12, 5);
    p(c, 4, 4, "#6a7a3a", 6, 2);
    p(c, 4, 6, "#8e3a2e", 7, 4);
    p(c, 6, 7, "#5e7a2e", 3, 2);
    p(c, 10, 8, "#b04a3a", 2, 1);
    p(c, 12, 9, "#e8e0d0", 3, 2); p(c, 14, 8, "#e8e0d0", 1, 4);
  },
  pano: (c) => {
    p(c, 2, 4, "#6b5e45", 12, 9);
    p(c, 2, 4, "#857656", 12, 2);
    p(c, 2, 8, "#54492f", 12, 1);
    p(c, 3, 13, "#6b5e45", 2, 1); p(c, 7, 13, "#6b5e45", 3, 1); p(c, 12, 13, "#6b5e45", 1, 1);
    p(c, 8, 9, "#7a1d1d", 3, 2); p(c, 9, 11, "#7a1d1d"); p(c, 4, 6, "#7a1d1d", 2, 1);
  },
  osso: (c) => {
    for (let i = 0; i < 8; i++) p(c, 4 + i, 11 - i, "#e8e0d0", 2, 2);
    p(c, 2, 11, "#e8e0d0", 3, 3); p(c, 3, 13, "#e8e0d0", 2, 2); p(c, 1, 12, "#e8e0d0", 2, 2);
    p(c, 11, 2, "#e8e0d0", 3, 3); p(c, 13, 1, "#e8e0d0", 2, 2); p(c, 12, 4, "#e8e0d0", 2, 2);
    for (let i = 0; i < 8; i++) p(c, 5 + i, 12 - i, "#b8ad98");
  },
  atadura: (c) => {
    p(c, 3, 4, "#eeeae0", 10, 9);
    p(c, 2, 5, "#eeeae0", 12, 7);
    p(c, 3, 11, "#c8c2b4", 10, 2);
    p(c, 11, 5, "#c8c2b4", 2, 6);
    p(c, 7, 5, "#d2204a", 2, 6);
    p(c, 5, 7, "#d2204a", 6, 2);
    p(c, 13, 12, "#eeeae0", 2, 2);
  },
};

const cache = new Map<ItemId, HTMLCanvasElement>();
const urls = new Map<ItemId, string>();

export function iconCanvas(id: ItemId): HTMLCanvasElement {
  let cv = cache.get(id);
  if (cv) return cv;
  cv = document.createElement("canvas");
  cv.width = S;
  cv.height = S;
  const c = cv.getContext("2d")!;
  DRAW[id](c);
  outline(cv);
  cache.set(id, cv);
  return cv;
}

export function iconURL(id: ItemId): string {
  let u = urls.get(id);
  if (!u) {
    u = iconCanvas(id).toDataURL();
    urls.set(id, u);
  }
  return u;
}

export { OUT as ICON_OUTLINE };
