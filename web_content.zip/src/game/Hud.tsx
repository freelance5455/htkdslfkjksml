import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { Gem, Timer, Volume2, VolumeX } from "lucide-react";
import { unlockAudio } from "@/game/audio";
import { CELL, COLS, ROWS, WALL_T, cellOf } from "@/game/maze";
import {
  formatTime,
  getSnap,
  groveCode,
  lockLook,
  nudgeLook,
  playAgain,
  resumePlay,
  session,
  startFromMenu,
  subscribe,
  toggleMute,
  type Phase,
} from "@/game/session";

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
}

function drawMinimap(canvas: HTMLCanvasElement) {
  const ctx = canvas.getContext("2d");
  if (!ctx || !session.cells?.length) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const size = canvas.clientWidth;
  if (size < 2) return;
  const px = Math.floor(size * dpr);
  if (canvas.width !== px) {
    canvas.width = px;
    canvas.height = px;
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, size, size);
  roundRect(ctx, 0, 0, size, size, 18);
  ctx.fillStyle = "#f6f1e6";
  ctx.fill();
  ctx.save();
  roundRect(ctx, 0, 0, size, size, 18);
  ctx.clip();

  const pad = 12;
  const scale = (size - pad * 2) / (COLS * CELL);
  const seen = (c: number, r: number) =>
    c >= 0 && r >= 0 && c < COLS && r < ROWS && session.explored[r * COLS + c] === 1;

  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      ctx.fillStyle = seen(c, r) ? "#f3e4c4" : "#243028";
      ctx.fillRect(pad + c * CELL * scale, pad + r * CELL * scale, CELL * scale, CELL * scale);
    }
  }

  ctx.strokeStyle = "#1f6a48";
  ctx.lineWidth = Math.max(3, WALL_T * scale);
  ctx.lineCap = "square";
  ctx.beginPath();
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const cell = session.cells[r * COLS + c]!;
      const x0 = pad + c * CELL * scale;
      const y0 = pad + r * CELL * scale;
      const x1 = x0 + CELL * scale;
      const y1 = y0 + CELL * scale;
      const here = seen(c, r);
      if (cell.n && (here || seen(c, r - 1))) {
        ctx.moveTo(x0, y0);
        ctx.lineTo(x1, y0);
      }
      if (cell.w && (here || seen(c - 1, r))) {
        ctx.moveTo(x0, y0);
        ctx.lineTo(x0, y1);
      }
      if (r === ROWS - 1 && cell.s && here) {
        ctx.moveTo(x0, y1);
        ctx.lineTo(x1, y1);
      }
      if (c === COLS - 1 && cell.e && here) {
        ctx.moveTo(x1, y0);
        ctx.lineTo(x1, y1);
      }
    }
  }
  ctx.stroke();

  if (seen(session.exitC, session.exitR)) {
    const ex = pad + session.exitX * scale;
    const ey = pad + session.exitZ * scale;
    ctx.fillStyle = "#e39b2b";
    ctx.beginPath();
    ctx.moveTo(ex, ey - 5.5);
    ctx.lineTo(ex + 4.5, ey);
    ctx.lineTo(ex, ey + 5.5);
    ctx.lineTo(ex - 4.5, ey);
    ctx.closePath();
    ctx.fill();
  }

  for (let i = 0; i < session.gems.length; i++) {
    if (session.got[i]) continue;
    const g = session.gems[i]!;
    const cell = cellOf(g.x, g.z);
    if (!seen(cell.c, cell.r)) continue;
    ctx.fillStyle = "#e36b4a";
    ctx.beginPath();
    ctx.arc(pad + g.x * scale, pad + g.z * scale, 2.6, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.save();
  ctx.translate(pad + session.x * scale, pad + session.z * scale);
  ctx.rotate(-session.yaw);
  ctx.fillStyle = "#e36b4a";
  ctx.beginPath();
  ctx.moveTo(0, -7.5);
  ctx.lineTo(5, 6);
  ctx.lineTo(0, 3);
  ctx.lineTo(-5, 6);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  ctx.restore();
}

function Minimap() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    let frame = 0;
    const loop = () => {
      frame = requestAnimationFrame(loop);
      if (ref.current) drawMinimap(ref.current);
    };
    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, []);
  return (
    <div className="pointer-events-none w-28 sm:w-44">
      <canvas ref={ref} aria-label="Explored paths" className="aspect-square w-full rounded-3xl shadow-lg" />
      <p className="mx-auto mt-1 w-fit rounded-full bg-cream px-2 py-0.5 text-xs font-extrabold tracking-widest text-ink uppercase">
        Explored
      </p>
    </div>
  );
}

function useClock(phase: Phase) {
  const [ms, setMs] = useState(() => session.timeMs);
  useEffect(() => {
    setMs(session.timeMs);
    if (phase !== "play") return;
    const id = window.setInterval(() => setMs(session.timeMs), 80);
    return () => window.clearInterval(id);
  }, [phase]);
  return ms;
}

function Mark() {
  return (
    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-ink" aria-hidden="true">
      <span className="block h-3.5 w-3.5 rotate-45 rounded-sm bg-gold" />
    </span>
  );
}

function SoundButton() {
  const snap = useSyncExternalStore(subscribe, getSnap, getSnap);
  const Icon = snap.muted ? VolumeX : Volume2;
  return (
    <button
      type="button"
      aria-label={snap.muted ? "Unmute" : "Mute"}
      className="grid h-11 w-11 place-items-center rounded-full bg-cream text-ink shadow-lg"
      onClick={() => {
        unlockAudio();
        toggleMute();
      }}
    >
      <Icon className="size-5" />
    </button>
  );
}

function StartCard({ touch }: { touch: boolean }) {
  const snap = useSyncExternalStore(subscribe, getSnap, getSnap);
  return (
    <div className="rise pointer-events-auto w-full max-w-md rounded-3xl bg-cream px-6 py-7 text-ink shadow-2xl sm:px-8 sm:py-9">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Mark />
          <p className="text-xs font-extrabold tracking-widest text-hedge uppercase">Grove {groveCode(snap.seed)}</p>
        </div>
        <SoundButton />
      </div>
      <h1 className="font-display mt-4 text-4xl leading-none sm:text-5xl">Lantern Grove</h1>
      <p className="mt-3 text-base leading-relaxed text-muted">
        A sunlit hedge maze. Walk the paths, pocket every sunberry, and find the lantern at the end.
      </p>
      <ul className="mt-5 grid gap-2 text-sm">
        <li className="flex items-center justify-between gap-3 rounded-2xl bg-line px-3 py-2.5">
          <span className="font-extrabold">Move</span>
          <span className="text-muted">{touch ? "Left stick" : "WASD or arrows"}</span>
        </li>
        <li className="flex items-center justify-between gap-3 rounded-2xl bg-line px-3 py-2.5">
          <span className="font-extrabold">Look</span>
          <span className="text-muted">{touch ? "Drag the right side" : "Mouse"}</span>
        </li>
        <li className="flex items-center justify-between gap-3 rounded-2xl bg-line px-3 py-2.5">
          <span className="font-extrabold">Hurry</span>
          <span className="text-muted">{touch ? "Run button" : "Hold Shift"}</span>
        </li>
      </ul>
      {snap.bestMs != null && (
        <p className="mt-4 text-sm font-bold text-muted">
          Best lantern <span className="font-display text-ink">{formatTime(snap.bestMs)}</span>
        </p>
      )}
      <button
        type="button"
        className="mt-5 h-12 w-full rounded-full bg-ink text-base font-extrabold text-cream"
        onClick={() => {
          unlockAudio();
          startFromMenu();
          lockLook();
        }}
      >
        Start
      </button>
    </div>
  );
}

function WinCard() {
  const snap = useSyncExternalStore(subscribe, getSnap, getSnap);
  return (
    <div className="rise pointer-events-auto w-full max-w-md rounded-3xl bg-cream px-6 py-7 text-ink shadow-2xl sm:px-8">
      <div className="flex items-center gap-3">
        <Mark />
        <p className="text-xs font-extrabold tracking-widest text-hedge uppercase">Grove {groveCode(snap.seed)}</p>
      </div>
      <h2 className="font-display mt-4 text-4xl leading-none">Lantern found</h2>
      <p className="mt-3 text-base leading-relaxed text-muted">The hedges kept every turn. The grove is yours.</p>
      <p className="font-display mt-5 text-5xl leading-none tabular-nums">{formatTime(snap.timeMs)}</p>
      <div className="mt-4 flex flex-wrap items-center gap-2 text-sm font-extrabold">
        <span className="rounded-full bg-line px-3 py-1.5 text-ink">
          {snap.collected}/{snap.total} sunberries
        </span>
        {snap.isNewBest ? (
          <span className="rounded-full bg-ink px-3 py-1.5 text-gold">New best</span>
        ) : snap.bestMs != null ? (
          <span className="rounded-full bg-line px-3 py-1.5 text-muted">Best {formatTime(snap.bestMs)}</span>
        ) : null}
      </div>
      <button
        type="button"
        className="mt-6 h-12 w-full rounded-full bg-ink text-base font-extrabold text-cream"
        onClick={() => {
          unlockAudio();
          playAgain();
          lockLook();
        }}
      >
        New maze
      </button>
    </div>
  );
}

function PauseCard({ touch }: { touch: boolean }) {
  return (
    <div className="rise pointer-events-auto w-full max-w-sm rounded-3xl bg-cream px-6 py-7 text-ink shadow-2xl">
      <h2 className="font-display text-4xl leading-none">Paused</h2>
      <p className="mt-3 text-sm leading-relaxed text-muted">
        {touch ? "The grove waits. Resume when you are ready." : "Click resume, then look around with the mouse."}
      </p>
      <div className="mt-6 grid gap-2">
        <button
          type="button"
          className="h-12 rounded-full bg-ink text-base font-extrabold text-cream"
          onClick={() => {
            unlockAudio();
            resumePlay();
            lockLook();
          }}
        >
          Resume
        </button>
        <button
          type="button"
          className="h-12 rounded-full bg-line text-base font-extrabold text-ink"
          onClick={() => {
            unlockAudio();
            playAgain();
            lockLook();
          }}
        >
          New maze
        </button>
      </div>
    </div>
  );
}

function ClockPill() {
  const snap = useSyncExternalStore(subscribe, getSnap, getSnap);
  const ms = useClock(snap.phase);
  return (
    <div className="pointer-events-none flex items-center gap-2 rounded-full bg-cream px-3 py-2 text-ink shadow-lg">
      <Timer className="size-4 text-hedge" aria-hidden="true" />
      <span className="font-display text-base leading-none tabular-nums sm:text-lg">
        {formatTime(snap.phase === "play" ? ms : snap.timeMs)}
      </span>
      <span className="mx-1 h-4 w-px bg-line" aria-hidden="true" />
      <Gem className="size-4 text-coral" aria-hidden="true" />
      <span key={snap.collected} className="gem-pop text-sm font-extrabold tabular-nums">
        {snap.collected}/{snap.total}
      </span>
    </div>
  );
}

function Hint() {
  const [show, setShow] = useState(true);
  useEffect(() => {
    const id = window.setTimeout(() => setShow(false), 8000);
    return () => window.clearTimeout(id);
  }, []);
  if (!show) return null;
  return (
    <p className="pointer-events-none absolute bottom-5 left-1/2 -translate-x-1/2 rounded-full bg-cream/90 px-4 py-2 text-xs font-extrabold text-muted">
      WASD move · mouse look · Shift hurry · Esc pause
    </p>
  );
}

function Stick() {
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const origin = useRef<{ x: number; y: number } | null>(null);
  const end = () => {
    origin.current = null;
    setKnob({ x: 0, y: 0 });
    session.touchStrafe = 0;
    session.touchForward = 0;
  };
  return (
    <div
      className="pointer-events-auto absolute bottom-5 left-4 z-10 h-36 w-36 rounded-full border border-ink/15 bg-cream/50"
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        origin.current = { x: e.clientX, y: e.clientY };
      }}
      onPointerMove={(e) => {
        if (!origin.current) return;
        const dx = e.clientX - origin.current.x;
        const dy = e.clientY - origin.current.y;
        const max = 52;
        const mag = Math.hypot(dx, dy) || 1;
        const k = mag > max ? max / mag : 1;
        const x = dx * k;
        const y = dy * k;
        setKnob({ x, y });
        session.touchStrafe = x / max;
        session.touchForward = -y / max;
      }}
      onPointerUp={end}
      onPointerCancel={end}
      aria-label="Move"
      role="application"
    >
      <span
        className="absolute top-1/2 left-1/2 h-14 w-14 rounded-full bg-ink shadow-lg"
        style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
      />
    </div>
  );
}

function LookPad() {
  const last = useRef<{ x: number; y: number } | null>(null);
  const end = () => {
    last.current = null;
  };
  return (
    <div
      className="pointer-events-auto absolute inset-y-0 right-0 z-0 w-1/2"
      aria-label="Look"
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        last.current = { x: e.clientX, y: e.clientY };
      }}
      onPointerMove={(e) => {
        if (!last.current || session.phase !== "play") return;
        const dx = e.clientX - last.current.x;
        const dy = e.clientY - last.current.y;
        last.current = { x: e.clientX, y: e.clientY };
        nudgeLook(dx, dy, 0.0048);
      }}
      onPointerUp={end}
      onPointerCancel={end}
    />
  );
}

export function Hud({ touch }: { touch: boolean }) {
  const snap = useSyncExternalStore(subscribe, getSnap, getSnap);
  const playing = snap.phase === "play" || snap.phase === "pause" || snap.phase === "won";
  return (
    <div className="hud-safe pointer-events-none absolute inset-0 z-10">
      {playing && (
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-2">
            <ClockPill />
            <div className="pointer-events-auto">
              <SoundButton />
            </div>
          </div>
          <Minimap />
        </div>
      )}

      {snap.phase === "play" && (
        <div className="pointer-events-none absolute top-1/2 left-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-ink/80 bg-cream/70" />
      )}

      {snap.phase === "play" && !touch && <Hint />}

      {touch && snap.phase === "play" && (
        <>
          <LookPad />
          <Stick />
          <button
            type="button"
            className="pointer-events-auto absolute right-4 bottom-6 z-10 h-14 min-w-14 rounded-full bg-ink px-4 text-sm font-extrabold text-cream"
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              session.touchSprint = true;
            }}
            onPointerUp={() => {
              session.touchSprint = false;
            }}
            onPointerCancel={() => {
              session.touchSprint = false;
            }}
          >
            Run
          </button>
        </>
      )}

      {snap.phase === "menu" && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center overflow-y-auto bg-ink/35 p-4 pb-24">
          <StartCard touch={touch} />
        </div>
      )}

      {snap.phase === "pause" && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center overflow-y-auto bg-ink/40 p-4 pb-24">
          <PauseCard touch={touch} />
        </div>
      )}

      {snap.phase === "won" && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center overflow-y-auto bg-ink/40 p-4 pb-24">
          <WinCard />
        </div>
      )}
    </div>
  );
}
