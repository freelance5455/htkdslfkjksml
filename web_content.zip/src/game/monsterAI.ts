import { MONSTERS } from './constants';
import { ActiveMonsterState, MonsterAttackDef, MonsterDef } from './types';
import { WorldManager } from './world';

export class MonsterAIManager {
  // Update a monster's state machine each simulation step
  public static updateMonster(
    monster: ActiveMonsterState,
    playerX: number,
    playerY: number,
    dt: number,
    world: WorldManager,
    onTriggerAttack: (monster: ActiveMonsterState, attack: MonsterAttackDef) => void,
    onRoar: (monster: ActiveMonsterState) => void
  ) {
    const def = MONSTERS[monster.defId];
    if (!def) return;

    if (monster.state === 'dead') {
      monster.stateTimer -= dt;
      return;
    }

    // Poison status tick
    if (monster.isPoisoned) {
      monster.poisonTimer -= dt;
      if (Math.random() < 0.05) {
        monster.hp = Math.max(1, monster.hp - 4);
      }
      if (monster.poisonTimer <= 0) {
        monster.isPoisoned = false;
        monster.poisonBuildup = 0;
      }
    }

    // Enrage timer
    if (monster.enraged) {
      monster.enrageTimer -= dt;
      if (monster.enrageTimer <= 0) {
        monster.enraged = false;
      }
    }

    // Distance and angle to player
    const dx = playerX - monster.x;
    const dy = playerY - monster.y;
    const distToPlayer = Math.hypot(dx, dy);
    const angleToPlayer = Math.atan2(dy, dx);

    // Speed multiplier (Enraged gives +30% speed, exhausted gives -40% speed)
    let speed = def.speed;
    if (monster.enraged) speed *= 1.3;
    if (monster.state === 'exhausted') speed *= 0.6;

    // Boss Phase 2 Check (Voidcrown below 50% HP)
    if (def.isFinalBoss && monster.hp < monster.maxHp * 0.5 && monster.variantPhase !== 2) {
      monster.variantPhase = 2;
      monster.enraged = true;
      monster.enrageTimer = 999; // Stays permanently frenzied in Phase 2
      monster.state = 'roar';
      monster.stateTimer = 2.0;
      onRoar(monster);
      return;
    }

    // State Machine
    switch (monster.state) {
      case 'idle': {
        monster.stateTimer -= dt;
        // Check player detection
        const detectRange = monster.enraged ? 450 : 320;
        if (distToPlayer < detectRange) {
          monster.state = 'alert';
          monster.stateTimer = 0.8;
          monster.angle = angleToPlayer;
          onRoar(monster);
        } else if (monster.stateTimer <= 0) {
          // Switch to patrol
          monster.state = 'patrol';
          monster.stateTimer = 3.0 + Math.random() * 4.0;
          monster.angle = Math.random() * Math.PI * 2;
        }
        break;
      }

      case 'patrol': {
        monster.stateTimer -= dt;
        // Move forward gently
        monster.x += Math.cos(monster.angle) * speed * 0.35 * dt;
        monster.y += Math.sin(monster.angle) * speed * 0.35 * dt;

        // Collision pushout
        const res = world.resolveCollision(monster.x, monster.y, def.size * 0.5);
        monster.x = res.x;
        monster.y = res.y;

        // Player detection
        const detectRange = 280;
        if (distToPlayer < detectRange) {
          monster.state = 'alert';
          monster.stateTimer = 0.8;
          monster.angle = angleToPlayer;
          onRoar(monster);
        } else if (monster.stateTimer <= 0) {
          monster.state = 'idle';
          monster.stateTimer = 2.0 + Math.random() * 3.0;
        }
        break;
      }

      case 'alert': {
        monster.stateTimer -= dt;
        monster.angle = angleToPlayer;
        if (monster.stateTimer <= 0) {
          monster.state = 'chase';
        }
        break;
      }

      case 'roar': {
        monster.stateTimer -= dt;
        if (monster.stateTimer <= 0) {
          monster.state = 'chase';
        }
        break;
      }

      case 'chase': {
        // Face player
        monster.angle = angleToPlayer;

        // Check if badly injured and should limp/flee to nest (< 20% HP and not enraged)
        if (monster.hp < monster.maxHp * 0.2 && !monster.enraged && !def.isFinalBoss) {
          monster.state = 'flee';
          monster.stateTimer = 10.0;
          break;
        }

        // Check attack range with available moves
        const availableAttacks = def.attacks.filter((att) => distToPlayer <= att.range * 1.15);

        if (availableAttacks.length > 0 && Math.random() < 0.08) {
          // Select an attack
          const selectedAttack =
            availableAttacks[Math.floor(Math.random() * availableAttacks.length)];
          monster.currentAttack = selectedAttack;
          monster.state = 'windup';
          monster.stateTimer = selectedAttack.windupTime;
          monster.attackTargetX = playerX;
          monster.attackTargetY = playerY;
          break;
        }

        // Pursue player
        const chaseSpeed = speed * (monster.enraged ? 1.25 : 1.0);
        monster.x += Math.cos(monster.angle) * chaseSpeed * dt;
        monster.y += Math.sin(monster.angle) * chaseSpeed * dt;

        // Resolve obstacle collision
        const res = world.resolveCollision(monster.x, monster.y, def.size * 0.55);
        monster.x = res.x;
        monster.y = res.y;

        // If player too far away (> 750px), lose aggro
        if (distToPlayer > 800) {
          monster.state = 'idle';
          monster.stateTimer = 3.0;
        }
        break;
      }

      case 'windup': {
        monster.stateTimer -= dt;
        // Tracking player during early windup
        if (monster.stateTimer > 0.25) {
          monster.angle = angleToPlayer;
          monster.attackTargetX = playerX;
          monster.attackTargetY = playerY;
        }

        if (monster.stateTimer <= 0 && monster.currentAttack) {
          // Execute active attack phase!
          monster.state = 'attacking';
          monster.stateTimer = monster.currentAttack.activeTime;
          onTriggerAttack(monster, monster.currentAttack);
        }
        break;
      }

      case 'attacking': {
        monster.stateTimer -= dt;

        // If attack is a charge/rush move, move monster rapidly forward
        if (monster.currentAttack?.telegraphType === 'charge') {
          const rushSpeed = monster.currentAttack.speed || 240;
          monster.x += Math.cos(monster.angle) * rushSpeed * dt;
          monster.y += Math.sin(monster.angle) * rushSpeed * dt;

          const res = world.resolveCollision(monster.x, monster.y, def.size * 0.55);
          monster.x = res.x;
          monster.y = res.y;
        }

        if (monster.stateTimer <= 0 && monster.currentAttack) {
          monster.state = 'recovery';
          monster.stateTimer = monster.currentAttack.recoveryTime;
        }
        break;
      }

      case 'recovery': {
        monster.stateTimer -= dt;
        if (monster.stateTimer <= 0) {
          monster.currentAttack = null;
          monster.state = 'chase';
        }
        break;
      }

      case 'stagger': {
        monster.stateTimer -= dt;
        // Slight recoil
        monster.x -= Math.cos(monster.angle) * 40 * dt;
        monster.y -= Math.sin(monster.angle) * 40 * dt;
        if (monster.stateTimer <= 0) {
          monster.state = 'chase';
        }
        break;
      }

      case 'exhausted': {
        monster.stateTimer -= dt;
        // Panting in place
        if (monster.stateTimer <= 0) {
          monster.state = 'chase';
        }
        break;
      }

      case 'flee': {
        monster.stateTimer -= dt;
        // Run away from player towards wilderness perimeter/nest
        monster.angle = angleToPlayer + Math.PI; // Run opposite
        const limpSpeed = speed * 0.7;
        monster.x += Math.cos(monster.angle) * limpSpeed * dt;
        monster.y += Math.sin(monster.angle) * limpSpeed * dt;

        const res = world.resolveCollision(monster.x, monster.y, def.size * 0.55);
        monster.x = res.x;
        monster.y = res.y;

        if (monster.stateTimer <= 0 || distToPlayer > 600) {
          monster.state = 'idle';
          monster.stateTimer = 4.0;
        }
        break;
      }
    }
  }
}
