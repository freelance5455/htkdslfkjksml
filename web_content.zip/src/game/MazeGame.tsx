import { useEffect, useRef, useState, type MouseEvent as ReactMouseEvent, type PointerEvent as ReactPointerEvent } from "react";
import { Keyboard, Map, Mouse, Pause, Play, RotateCcw, Shuffle, Sparkles, Volume2, VolumeX } from "lucide-react";
import { MazeEngine, type HudSnapshot } from "@/game/engine";
import { wantsTouchLayout } from "@/game/probe";
import { formatTime } from "@/game/sim";

const INITIAL: HudSnapshot = {
  phase: "menu",
  time: 0,
  collected: 0,
  total: 0,
  best: null,
  seed: 0,
  muted: false,
  newBest: false,
  perfect: false,
};

function SunMark() {
  return (
    <span className="grid size-12 shrink-0 place-items-center rounded-full bg-gold" aria-hidden="true">
      <span className="size-4 rounded-full bg-cream" />
    </span>
  );
}

function Stick({ onChange }: { onChange: (x: number, y: number) => void }) {
  const base = useRef<HTMLDivElement>(null);
  const drag = useRef(false);
  const [knob, setKnob] = useState({ x: 0, y: 0 });

  function fromEvent(e: ReactPointerEvent) {
    const el = base.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const max = r.width / 2;
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    const len = Math.hypot(dx, dy) || 1;
    const clamped = Math.min(max, len);
    dx = (dx / len) * clamped;
    dy = (dy / len) * clamped;
    setKnob({ x: dx, y: dy });
    onChange(dx / max, -dy / max);
  }

  function end() {
    drag.current = false;
    setKnob({ x: 0, y: 0 });
    onChange(0, 0);
  }

  return (
    <div
      ref={base}
      className="absolute bottom-8 left-6 z-20 size-32 rounded-full border border-cream/50 bg-ink/35"
      style={{ touchAction: "none" }}
      onPointerDown={(e) => {
        drag.current = true;
        e.currentTarget.setPointerCapture(e.pointerId);
        e.stopPropagation();
        fromEvent(e);
      }}
      onPointerMove={(e) => {
        if (drag.current) fromEvent(e);
      }}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <span
        className="absolute left-1/2 top-1/2 size-14 rounded-full bg-cream shadow-md"
        style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
      />
    </div>
  );
}

export function MazeGame() {
  const viewRef = useRef<HTMLCanvasElement>(null);
  const mapRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<MazeEngine | null>(null);
  const lookId = useRef<number | null>(null);
  const lookLast = useRef({ x: 0, y: 0 });
  const [hud, setHud] = useState<HudSnapshot>(INITIAL);
  const [touch, setTouch] = useState(false);

  useEffect(() => {
    const canvas = viewRef.current;
    const map = mapRef.current;
    if (!canvas || !map) return;
    const engine = new MazeEngine(canvas, map, setHud);
    engineRef.current = engine;
    window.__controlsTest = {
      getYaw: () => engine.yaw,
      getSpeed: () => engine.speed,
      getPos: () => ({ x: engine.px, z: engine.pz }),
      setKeys: (codes) => engine.setKeys(codes),
    };
    return () => {
      engine.dispose();
      engineRef.current = null;
      delete window.__controlsTest;
    };
  }, []);

  useEffect(() => {
    const apply = () => {
      const on = wantsTouchLayout();
      setTouch(on);
      engineRef.current?.setTouchLayout(on);
    };
    apply();
    window.addEventListener("resize", apply);
    return () => window.removeEventListener("resize", apply);
  }, []);

  function onShellClick(e: ReactMouseEvent) {
    const target = e.target as HTMLElement;
    if (target.closest("button, a")) return;
    if (hud.phase === "play") engineRef.current?.lockPointer();
  }

  const playing = hud.phase === "play" || hud.phase === "paused";
  const seedLabel = hud.seed ? hud.seed.toString(36) : "—";

  return (
    <main
      className="relative h-dvh w-full overflow-hidden bg-sky text-ink"
      onClick={onShellClick}
    >
      <canvas ref={viewRef} className="absolute inset-0 h-full w-full touch-none" />

      {hud.phase === "play" && (
        <div className="pointer-events-none absolute top-1/2 left-1/2 z-10 -translate-x-1/2 -translate-y-1/2">
          <div className="crosshair" />
        </div>
      )}

      {touch && hud.phase === "play" && (
        <div
          className="absolute inset-y-0 right-0 z-10 w-3/5"
          style={{ touchAction: "none" }}
          onPointerDown={(e) => {
            lookId.current = e.pointerId;
            lookLast.current = { x: e.clientX, y: e.clientY };
            e.currentTarget.setPointerCapture(e.pointerId);
          }}
          onPointerMove={(e) => {
            if (lookId.current !== e.pointerId) return;
            const dx = e.clientX - lookLast.current.x;
            const dy = e.clientY - lookLast.current.y;
            lookLast.current = { x: e.clientX, y: e.clientY };
            engineRef.current?.lookBy(dx, dy);
          }}
          onPointerUp={() => {
            lookId.current = null;
          }}
          onPointerCancel={() => {
            lookId.current = null;
          }}
        />
      )}

      <div className={`safe-hud pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between gap-2 ${playing ? "" : "hidden"}`}>
          <div className="pointer-events-auto flex min-w-0 items-center gap-2">
            <button
              type="button"
              aria-label={hud.phase === "paused" ? "เล่นต่อ" : "หยุด"}
              className="grid size-11 shrink-0 place-items-center rounded-full bg-ink text-cream"
              onClick={(e) => {
                e.stopPropagation();
                if (hud.phase === "paused") engineRef.current?.resume();
                else engineRef.current?.pause();
              }}
            >
              {hud.phase === "paused" ? <Play className="size-5" /> : <Pause className="size-5" />}
            </button>
            <div className="chip min-w-0 rounded-full px-3 py-2">
              <p className="truncate font-display text-base leading-none font-semibold tabular-nums">
                {formatTime(hud.time)}
                <span className="text-ink-soft">
                  {" "}
                  · <span key={hud.collected} className="hud-pop inline-block text-ink">{hud.collected}</span>/{hud.total}
                </span>
              </p>
            </div>
            <button
              type="button"
              aria-label={hud.muted ? "เปิดเสียง" : "ปิดเสียง"}
              className="grid size-11 shrink-0 place-items-center rounded-full chip text-ink"
              onClick={(e) => {
                e.stopPropagation();
                engineRef.current?.toggleMute();
              }}
            >
              {hud.muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
            </button>
          </div>

          <div className="chip w-24 shrink-0 overflow-hidden rounded-2xl sm:w-44">
            <div className="flex items-center gap-1 px-2 pt-1.5 text-xs font-bold text-leaf sm:px-3 sm:pt-2">
              <Map className="size-3.5" />
              แผนที่
            </div>
            <canvas ref={mapRef} width={384} height={384} className="aspect-square w-full" />
            <p className="px-2 pb-1.5 text-center text-xs font-semibold text-ink-soft tabular-nums sm:px-3 sm:pb-2">#{seedLabel}</p>
          </div>
        </div>

      {touch && hud.phase === "play" && <Stick onChange={(x, y) => engineRef.current?.setMoveAxis(x, y)} />}

      {hud.phase === "play" && hud.time < 6500 && (
        <p className={`pointer-events-none absolute inset-x-0 z-30 px-4 text-center ${touch ? "bottom-44" : "bottom-6"}`}>
          <span className="chip inline-block rounded-full px-4 py-2 text-sm font-semibold text-ink">
            {touch ? "จอยซ้ายเดิน · ลากฝั่งขวาเพื่อหันมอง" : "WASD เดิน · เมาส์หันมอง · Shift วิ่ง"}
          </span>
        </p>
      )}

      {hud.phase === "menu" && (
        <div className="absolute inset-0 z-40 flex items-center justify-center p-4">
          <section className="panel max-h-full w-full max-w-md overflow-y-auto p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <SunMark />
              <div>
                <p className="text-xs font-bold tracking-widest text-leaf">SUNBLOOM</p>
                <h1 className="font-display text-4xl leading-snug font-bold sm:text-5xl">สวนแสง</h1>
              </div>
            </div>
            <p className="mt-4 text-pretty text-ink-soft">
              เขาวงกตพุ่มไม้โลว์โพลี มุมมองบุคคลที่หนึ่ง เก็บผลแสงระหว่างทาง แล้วเดินเข้าประตูทองเพื่อออกจากสวน
            </p>
            <button
              type="button"
              className="mt-6 flex h-12 w-full items-center justify-center rounded-full bg-leaf text-base font-bold text-cream"
              onClick={() => engineRef.current?.beginFromMenu()}
            >
              เริ่มเดิน
            </button>
            <ul className="mt-6 grid gap-3 text-sm">
              <li className="flex items-center gap-3">
                <Keyboard className="size-5 shrink-0 text-leaf" />
                <span>WASD หรือลูกศรเดิน · Shift วิ่ง · กำแพงจะเลื่อนตัว ไม่ดูดติด</span>
              </li>
              <li className="flex items-center gap-3">
                <Mouse className="size-5 shrink-0 text-leaf" />
                <span>คลิกเพื่อล็อกเมาส์แล้วหันมอง จอสัมผัสใช้จอยกับลากนิ้ว</span>
              </li>
              <li className="flex items-center gap-3">
                <Sparkles className="size-5 shrink-0 text-gold-deep" />
                <span>มินิแมปเปิดเฉพาะทางที่สำรวจแล้ว ไม่จำเป็นต้องเก็บผลแสงครบ</span>
              </li>
            </ul>
            {hud.best && (
              <p className="mt-5 text-sm font-semibold text-ink-soft tabular-nums">
                สถิติที่ดีที่สุด {formatTime(hud.best.ms)} · ผลแสง {hud.best.gems}/{hud.best.total}
              </p>
            )}
          </section>
        </div>
      )}

      {hud.phase === "paused" && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-ink/25 p-4">
          <section className="panel w-full max-w-sm p-6 sm:p-8">
            <h2 className="font-display text-3xl font-bold">พักสายตา</h2>
            <p className="mt-2 text-ink-soft tabular-nums">เวลาเดินไปแล้ว {formatTime(hud.time)}</p>
            <div className="mt-6 grid gap-3">
              <button
                type="button"
                className="flex h-12 items-center justify-center gap-2 rounded-full bg-leaf font-bold text-cream"
                onClick={() => engineRef.current?.resume()}
              >
                <Play className="size-5" />
                เล่นต่อ
              </button>
              <button
                type="button"
                className="flex h-12 items-center justify-center gap-2 rounded-full border border-line bg-cream-2 font-bold"
                onClick={() => engineRef.current?.retry(false)}
              >
                <RotateCcw className="size-5" />
                เริ่มแผนที่นี้ใหม่
              </button>
              <button
                type="button"
                className="flex h-12 items-center justify-center gap-2 rounded-full border border-line bg-cream-2 font-bold"
                onClick={() => engineRef.current?.toMenu()}
              >
                กลับเมนู
              </button>
            </div>
          </section>
        </div>
      )}

      {hud.phase === "won" && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-ink/20 p-4">
          <section className="panel w-full max-w-sm p-6 text-center sm:p-8">
            <p className="text-xs font-bold tracking-widest text-leaf">ทางออก</p>
            <h2 className="mt-1 font-display text-4xl leading-snug font-bold">ออกจากสวนแล้ว</h2>
            <p className="mt-3 font-display text-3xl font-bold tabular-nums">{formatTime(hud.time)}</p>
            <p className="mt-1 font-semibold text-ink-soft tabular-nums">
              ผลแสง {hud.collected}/{hud.total}
              {hud.perfect ? " · เก็บครบ" : ""}
            </p>
            {hud.newBest && (
              <p className="mt-3 inline-block rounded-full bg-gold px-3 py-1 text-sm font-bold text-ink">สถิติใหม่</p>
            )}
            {!hud.newBest && hud.best && (
              <p className="mt-3 text-sm text-ink-soft tabular-nums">สถิติ {formatTime(hud.best.ms)}</p>
            )}
            <div className="mt-6 grid gap-3">
              <button
                type="button"
                className="flex h-12 items-center justify-center gap-2 rounded-full bg-leaf font-bold text-cream"
                onClick={() => engineRef.current?.retry(true)}
              >
                <Shuffle className="size-5" />
                สุ่มเขาวงกตใหม่
              </button>
              <button
                type="button"
                className="flex h-12 items-center justify-center gap-2 rounded-full border border-line bg-cream-2 font-bold"
                onClick={() => engineRef.current?.retry(false)}
              >
                <RotateCcw className="size-5" />
                เล่นแผนที่นี้อีกครั้ง
              </button>
            </div>
          </section>
        </div>
      )}
    </main>
  );
}
