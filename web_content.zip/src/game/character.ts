import * as THREE from 'three';
import type { Appearance } from './types';

export interface Character {
  group: THREE.Group;
  apply: (a: Appearance) => void;
  animate: (dt: number, speed: number, airborne: boolean, t: number) => void;
}

// Blocky low-poly humanoid built from a handful of boxes (cheap to draw).
export function createCharacter(a: Appearance): Character {
  const group = new THREE.Group();
  const lam = (c: number) => new THREE.MeshLambertMaterial({ color: c });
  const mSkin = lam(a.skin);
  const mShirt = lam(a.shirt);
  const mPants = lam(a.pants);
  const mHair = lam(a.hair);
  const mShoe = lam(0x2b2b2e);
  const mEye = lam(0x151515);
  const mBack = lam(0x3b5b8a);
  const mHat = lam(0xe0424b);
  const mGold = lam(0xffc93c);
  const mBeanie = lam(0xff6fb1);

  const mesh = (w: number, h: number, d: number, m: THREE.Material, x = 0, y = 0, z = 0) => {
    const me = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    me.position.set(x, y, z);
    me.castShadow = true;
    return me;
  };
  const pivot = (x: number, y: number, z: number) => {
    const g = new THREE.Group();
    g.position.set(x, y, z);
    return g;
  };

  const legL = pivot(-0.2, 0.95, 0);
  const legR = pivot(0.2, 0.95, 0);
  legL.add(mesh(0.36, 0.9, 0.36, mPants, 0, -0.45, 0), mesh(0.38, 0.16, 0.48, mShoe, 0, -0.98, 0.06));
  legR.add(mesh(0.36, 0.9, 0.36, mPants, 0, -0.45, 0), mesh(0.38, 0.16, 0.48, mShoe, 0, -0.98, 0.06));

  const torso = mesh(0.8, 0.85, 0.45, mShirt, 0, 1.45, 0);

  const armL = pivot(-0.54, 1.8, 0);
  const armR = pivot(0.54, 1.8, 0);
  armL.add(mesh(0.3, 0.85, 0.3, mShirt, 0, -0.42, 0), mesh(0.32, 0.3, 0.32, mSkin, 0, -0.95, 0));
  armR.add(mesh(0.3, 0.85, 0.3, mShirt, 0, -0.42, 0), mesh(0.32, 0.3, 0.32, mSkin, 0, -0.95, 0));

  const head = pivot(0, 2.0, 0);
  const headMesh = mesh(0.62, 0.62, 0.62, mSkin, 0, 0.31, 0);
  const eyeL = mesh(0.1, 0.12, 0.04, mEye, -0.14, 0.36, 0.32);
  const eyeR = mesh(0.1, 0.12, 0.04, mEye, 0.14, 0.36, 0.32);
  const hair = mesh(0.66, 0.22, 0.66, mHair, 0, 0.6, 0);
  const cap = mesh(0.7, 0.12, 0.7, mHat, 0, 0.68, 0);
  const brim = mesh(0.42, 0.04, 0.28, mHat, 0, 0.62, 0.45);
  const beanie = mesh(0.68, 0.26, 0.68, mBeanie, 0, 0.65, 0);
  const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.36, 0.22, 6), mGold);
  crown.position.set(0, 0.75, 0);
  head.add(headMesh, eyeL, eyeR, hair, cap, brim, beanie, crown);

  const backpack = mesh(0.5, 0.62, 0.22, mBack, 0, 1.5, -0.36);

  group.add(legL, legR, torso, armL, armR, head, backpack);

  const apply = (ap: Appearance) => {
    mSkin.color.set(ap.skin);
    mShirt.color.set(ap.shirt);
    mPants.color.set(ap.pants);
    mHair.color.set(ap.hair);
    cap.visible = ap.hat === 'cap';
    brim.visible = ap.hat === 'cap';
    beanie.visible = ap.hat === 'beanie';
    crown.visible = ap.hat === 'crown';
    hair.visible = ap.hat !== 'cap' && ap.hat !== 'beanie';
    backpack.visible = ap.backpack;
  };
  apply(a);

  let phase = 0;
  let amp = 0;
  const animate = (dt: number, speed: number, airborne: boolean, t: number) => {
    const target = Math.min(speed / 6, 1);
    amp += (target - amp) * Math.min(1, dt * 10);
    if (speed > 0.1) phase += dt * speed * 1.7;
    const s = Math.sin(phase) * 0.8 * amp;
    if (airborne) {
      legL.rotation.x += (-0.6 - legL.rotation.x) * 0.25;
      legR.rotation.x += (0.3 - legR.rotation.x) * 0.25;
      armL.rotation.x += (-2.6 - armL.rotation.x) * 0.25;
      armR.rotation.x += (-2.6 - armR.rotation.x) * 0.25;
    } else {
      const idle = Math.sin(t * 2) * 0.05 * (1 - amp);
      legL.rotation.x = s;
      legR.rotation.x = -s;
      armL.rotation.x = -s * 0.9 + idle;
      armR.rotation.x = s * 0.9 - idle;
    }
  };

  return { group, apply, animate };
}
