// Procedurally rigged humanoid characters + the pet dog (CHOP).
// All animation is computed per-frame from joint angles (no external clips).
import * as THREE from 'three';
import { clamp, TAU } from './util';

export type HumanPose =
  | 'idle'
  | 'walk'
  | 'run'
  | 'jump'
  | 'fall'
  | 'sit'
  | 'stand'
  | 'punch'
  | 'shoot'
  | 'drive'
  | 'dead';

export interface HumanOptions {
  shirt?: number;
  pants?: number;
  skin?: number;
  hair?: number;
  height?: number;
  bulk?: number;
  cap?: boolean;
  vest?: boolean;
  female?: boolean;
}

const SKIN = [0xf0c8a0, 0xd9a273, 0xa9714b, 0x7a4b2c, 0x4e2f1c];

function cap(
  r: number,
  h: number,
  mat: THREE.Material,
  seg = 10
) {
  const g = new THREE.CapsuleGeometry(r, h, 3, seg);
  return new THREE.Mesh(g, mat);
}

export class Human {
  group = new THREE.Group();
  joints: Record<string, THREE.Group> = {};
  private mats: THREE.MeshStandardMaterial[] = [];
  private opts: Required<HumanOptions>;
  private pose: HumanPose = 'idle';
  private phase = 0;
  private punchT = 0;
  private shootT = 0;
  private breathe = 0;
  private smooth: Record<string, THREE.Vector3> = {};
  height = 1.82;

  constructor(o: HumanOptions = {}) {
    const rng = Math.random;
    this.opts = {
      shirt: o.shirt ?? 0x2f4f77,
      pants: o.pants ?? 0x23252b,
      skin: o.skin ?? SKIN[Math.floor(rng() * SKIN.length)],
      hair: o.hair ?? 0x2a1d14,
      height: o.height ?? 1.82,
      bulk: o.bulk ?? 1,
      cap: o.cap ?? false,
      vest: o.vest ?? false,
      female: o.female ?? false,
    };

    const skinMat = new THREE.MeshStandardMaterial({
      color: this.opts.skin,
      roughness: 0.72,
      metalness: 0.0,
    });
    const shirtMat = new THREE.MeshStandardMaterial({
      color: this.opts.shirt,
      roughness: 0.85,
    });
    const pantsMat = new THREE.MeshStandardMaterial({
      color: this.opts.pants,
      roughness: 0.9,
    });
    const shoeMat = new THREE.MeshStandardMaterial({ color: 0x14161a, roughness: 0.55 });
    const hairMat = new THREE.MeshStandardMaterial({ color: this.opts.hair, roughness: 0.85 });
    const vestMat = new THREE.MeshStandardMaterial({ color: 0x1d1f24, roughness: 0.7 });
    this.mats.push(skinMat, shirtMat, pantsMat, shoeMat, hairMat, vestMat);

    const s = this.opts.height / 1.82;
    const b = this.opts.bulk;
    const H = (y: number) => y * s;

    // ---- hips ----
    const hips = new THREE.Group();
    hips.position.y = H(0.95);
    this.group.add(hips);
    this.joints.hips = hips;
    const pelvis = new THREE.Mesh(
      new THREE.CapsuleGeometry(H(0.115) * b, H(0.1), 4, 12),
      pantsMat
    );
    pelvis.rotation.z = Math.PI / 2;
    pelvis.scale.set(1, 1, 0.78);
    pelvis.castShadow = true;
    hips.add(pelvis);

    // ---- spine / chest ----
    const spine = new THREE.Group();
    spine.position.y = H(0.1);
    hips.add(spine);
    this.joints.spine = spine;

    const chest = new THREE.Group();
    chest.position.y = H(0.17);
    spine.add(chest);
    this.joints.chest = chest;

    const torso = new THREE.Mesh(
      new THREE.CapsuleGeometry(H(0.145) * b, H(0.24), 5, 14),
      shirtMat
    );
    torso.position.y = H(0.13);
    torso.scale.set(1.12, 1, 0.72);
    torso.castShadow = true;
    chest.add(torso);

    if (this.opts.vest) {
      const vest = new THREE.Mesh(
        new THREE.CapsuleGeometry(H(0.152) * b, H(0.2), 4, 12),
        vestMat
      );
      vest.position.y = H(0.13);
      vest.scale.set(1.15, 1, 0.76);
      vest.castShadow = true;
      chest.add(vest);
    }

    // neck + head
    const neck = new THREE.Group();
    neck.position.y = H(0.3);
    chest.add(neck);
    this.joints.neck = neck;
    const neckMesh = cap(H(0.052), H(0.05), skinMat);
    neckMesh.position.y = H(0.035);
    neck.add(neckMesh);

    const head = new THREE.Group();
    head.position.y = H(0.1);
    neck.add(head);
    this.joints.head = head;
    const headMesh = new THREE.Mesh(new THREE.SphereGeometry(H(0.112), 18, 16), skinMat);
    headMesh.scale.set(0.95, 1.12, 1.02);
    headMesh.castShadow = true;
    head.add(headMesh);
    // jaw / chin
    const jaw = new THREE.Mesh(new THREE.SphereGeometry(H(0.082), 14, 12), skinMat);
    jaw.scale.set(0.92, 0.72, 1.0);
    jaw.position.set(0, -H(0.055), H(0.022));
    head.add(jaw);
    // nose
    const nose = new THREE.Mesh(new THREE.ConeGeometry(H(0.023), H(0.05), 8), skinMat);
    nose.rotation.x = Math.PI / 2;
    nose.position.set(0, -H(0.005), H(0.112));
    head.add(nose);
    // eyes
    const eyeMat = new THREE.MeshStandardMaterial({ color: 0x15181d, roughness: 0.25 });
    [-1, 1].forEach((sx) => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(H(0.019), 8, 8), eyeMat);
      eye.position.set(sx * H(0.042), H(0.022), H(0.094));
      head.add(eye);
    });
    // brows
    const browMat = new THREE.MeshStandardMaterial({ color: this.opts.hair, roughness: 0.9 });
    [-1, 1].forEach((sx) => {
      const brow = new THREE.Mesh(new THREE.BoxGeometry(H(0.05), H(0.008), H(0.012)), browMat);
      brow.position.set(sx * H(0.045), H(0.05), H(0.098));
      brow.rotation.z = sx * 0.12;
      head.add(brow);
    });
    // hair
    const hairMesh = new THREE.Mesh(
      new THREE.SphereGeometry(H(0.118), 16, 14, 0, TAU, 0, Math.PI * 0.58),
      hairMat
    );
    hairMesh.scale.set(0.97, 1.16, 1.02);
    hairMesh.position.y = H(0.012);
    hairMesh.castShadow = true;
    head.add(hairMesh);
    if (this.opts.cap) {
      const capMesh = new THREE.Mesh(
        new THREE.SphereGeometry(H(0.12), 14, 10, 0, TAU, 0, Math.PI * 0.45),
        new THREE.MeshStandardMaterial({ color: this.opts.shirt, roughness: 0.8 })
      );
      capMesh.position.y = H(0.022);
      capMesh.scale.set(1, 0.9, 1);
      head.add(capMesh);
      const brim = new THREE.Mesh(
        new THREE.CylinderGeometry(H(0.12), H(0.12), H(0.012), 14, 1, false, -0.9, 1.8),
        new THREE.MeshStandardMaterial({ color: this.opts.shirt, roughness: 0.8 })
      );
      brim.position.set(0, H(0.055), H(0.05));
      brim.rotation.x = -0.12;
      head.add(brim);
    }

    // ---- arms ----
    const buildArm = (side: number) => {
      const shoulder = new THREE.Group();
      shoulder.position.set(side * H(0.165) * b, H(0.255), 0);
      chest.add(shoulder);
      this.joints[side < 0 ? 'shoulderL' : 'shoulderR'] = shoulder;
      const deltoid = new THREE.Mesh(new THREE.SphereGeometry(H(0.062) * b, 10, 10), shirtMat);
      deltoid.castShadow = true;
      shoulder.add(deltoid);
      const upper = cap(H(0.043) * b, H(0.19), shirtMat);
      upper.position.y = -H(0.115);
      upper.castShadow = true;
      shoulder.add(upper);
      const elbow = new THREE.Group();
      elbow.position.y = -H(0.245);
      shoulder.add(elbow);
      this.joints[side < 0 ? 'elbowL' : 'elbowR'] = elbow;
      const fore = cap(H(0.036) * b, H(0.16), skinMat);
      fore.position.y = -H(0.1);
      fore.castShadow = true;
      elbow.add(fore);
      const hand = new THREE.Group();
      hand.position.y = -H(0.205);
      elbow.add(hand);
      this.joints[side < 0 ? 'handL' : 'handR'] = hand;
      const handMesh = new THREE.Mesh(new THREE.SphereGeometry(H(0.042), 8, 8), skinMat);
      handMesh.scale.set(0.8, 1.05, 0.55);
      hand.add(handMesh);
    };
    buildArm(-1);
    buildArm(1);

    // ---- legs ----
    const buildLeg = (side: number) => {
      const hip = new THREE.Group();
      hip.position.set(side * H(0.085) * b, -H(0.05), 0);
      hips.add(hip);
      this.joints[side < 0 ? 'hipL' : 'hipR'] = hip;
      const thigh = cap(H(0.062) * b, H(0.26), pantsMat);
      thigh.position.y = -H(0.16);
      thigh.castShadow = true;
      hip.add(thigh);
      const knee = new THREE.Group();
      knee.position.y = -H(0.4);
      hip.add(knee);
      this.joints[side < 0 ? 'kneeL' : 'kneeR'] = knee;
      const shin = cap(H(0.05) * b, H(0.26), pantsMat);
      shin.position.y = -H(0.16);
      shin.castShadow = true;
      knee.add(shin);
      const ankle = new THREE.Group();
      ankle.position.y = -H(0.38);
      knee.add(ankle);
      this.joints[side < 0 ? 'footL' : 'footR'] = ankle;
      const foot = new THREE.Mesh(new THREE.BoxGeometry(H(0.085), H(0.06), H(0.2)), shoeMat);
      foot.position.set(0, -H(0.03), H(0.045));
      foot.castShadow = true;
      ankle.add(foot);
    };
    buildLeg(-1);
    buildLeg(1);

    this.group.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.castShadow = true;
        o.receiveShadow = false;
      }
    });
  }

  setPose(p: HumanPose) {
    this.pose = p;
  }
  triggerPunch() {
    this.punchT = 0.001;
  }
  triggerShoot() {
    this.shootT = 0.001;
  }

  private setJoint(name: string, x: number, y = 0, z = 0) {
    const j = this.joints[name];
    if (!j) return;
    const key = name;
    let v = this.smooth[key];
    if (!v) {
      v = new THREE.Vector3();
      this.smooth[key] = v;
    }
    v.set(x, y, z);
    j.rotation.set(x, y, z);
  }

  /** dt-driven animation. speed in m/s */
  update(dt: number, speed: number, grounded = true, extra: any = {}) {
    void grounded;
    const p = this.pose;
    const run = Math.max(speed, 0.001);
    const moving = p === 'walk' || p === 'run';
    const cadence = p === 'run' ? 11.5 : 7.2;
    if (moving) this.phase += dt * cadence * clamp(run / (p === 'run' ? 6.4 : 2.6), 0.35, 1.7);
    else this.phase += dt * 1.2;
    this.breathe += dt;

    if (this.punchT > 0) this.punchT += dt;
    if (this.shootT > 0) this.shootT += dt;

    const ph = this.phase;
    const A = (n: string, x: number, y = 0, z = 0) => this.setJoint(n, x, y, z);

    // default neutral
    A('hips', 0, 0, 0);
    A('spine', 0, 0, 0);
    A('chest', 0, 0, 0);
    A('neck', 0, 0, 0);
    A('head', 0, 0, 0);
    A('shoulderL', 0, 0, 0.12);
    A('shoulderR', 0, 0, -0.12);
    A('elbowL', -0.25, 0, 0);
    A('elbowR', -0.25, 0, 0);
    A('hipL', 0, 0, 0);
    A('hipR', 0, 0, 0);
    A('kneeL', 0, 0, 0);
    A('kneeR', 0, 0, 0);
    A('footL', 0, 0, 0);
    A('footR', 0, 0, 0);

    const bob = Math.sin(ph * 2) * (p === 'run' ? 0.055 : 0.022);
    this.joints.hips.position.y = this.opts.height * (0.95 / 1.82) + bob;
    this.joints.hips.rotation.y = Math.sin(ph) * (p === 'run' ? 0.16 : 0.09);

    if (p === 'idle' || p === 'stand') {
      const br = Math.sin(this.breathe * 1.7) * 0.02;
      A('chest', br, 0, 0);
      A('spine', br * 0.6, 0, 0);
      A('shoulderL', 0, 0, 0.16 + br);
      A('shoulderR', 0, 0, -0.16 - br);
      A('head', -0.03 + Math.sin(this.breathe * 0.9) * 0.03, Math.sin(this.breathe * 0.5) * 0.12, 0);
      A('elbowL', -0.32, 0, 0);
      A('elbowR', -0.32, 0, 0);
    } else if (p === 'walk' || p === 'run') {
      const amp = p === 'run' ? 0.95 : 0.55;
      const s = Math.sin(ph);
      A('hipL', -s * amp, 0, 0);
      A('hipR', s * amp, 0, 0);
      A('kneeL', Math.max(0, -Math.sin(ph - 0.7)) * (p === 'run' ? 1.5 : 0.85) + 0.05, 0, 0);
      A('kneeR', Math.max(0, -Math.sin(ph + Math.PI - 0.7)) * (p === 'run' ? 1.5 : 0.85) + 0.05, 0, 0);
      A('footL', Math.max(0, -s) * 0.35, 0, 0);
      A('footR', Math.max(0, s) * 0.35, 0, 0);
      const armAmp = p === 'run' ? 0.95 : 0.55;
      A('shoulderL', s * armAmp, 0, 0.14);
      A('shoulderR', -s * armAmp, 0, -0.14);
      A('elbowL', -0.45 - Math.max(0, s) * 0.7, 0, 0);
      A('elbowR', -0.45 - Math.max(0, -s) * 0.7, 0, 0);
      A('chest', p === 'run' ? 0.22 : 0.06, 0, 0);
      A('spine', p === 'run' ? 0.1 : 0.03, 0, 0);
      A('head', p === 'run' ? -0.16 : -0.03, 0, 0);
      this.group.position.y += 0;
    } else if (p === 'jump' || p === 'fall') {
      const t = p === 'jump' ? 1 : 0;
      A('hipL', -0.75 * t - 0.1, 0, 0.08);
      A('hipR', -0.35 * t - 0.1, 0, -0.08);
      A('kneeL', 1.1 * t + 0.1, 0, 0);
      A('kneeR', 0.55 * t + 0.1, 0, 0);
      A('shoulderL', -0.6 * t, 0, 0.5 * t + 0.12);
      A('shoulderR', -0.5 * t, 0, -0.5 * t - 0.12);
      A('elbowL', -0.5, 0, 0);
      A('elbowR', -0.5, 0, 0);
      A('chest', -0.12 * t, 0, 0);
    } else if (p === 'sit') {
      A('hipL', -1.5, 0, 0.12);
      A('hipR', -1.5, 0, -0.12);
      A('kneeL', 1.45, 0, 0);
      A('kneeR', 1.45, 0, 0);
      A('footL', 0.2, 0, 0);
      A('footR', 0.2, 0, 0);
      A('chest', 0.06, 0, 0);
      A('head', -0.02, 0, 0);
      A('shoulderL', 0, 0, 0.22);
      A('shoulderR', 0, 0, -0.22);
      A('elbowL', -0.6, 0, 0);
      A('elbowR', -0.6, 0, 0);
      this.joints.hips.position.y = this.opts.height * (0.95 / 1.82) - 0.42;
    } else if (p === 'punch') {
      const t = clamp(this.punchT / 0.45, 0, 1);
      const strike = Math.sin(Math.min(1, t * 1.6) * Math.PI);
      const wind = t < 0.35 ? -0.4 : 0;
      A('shoulderR', -1.35 - strike * 0.25, -0.25 - wind, -0.2);
      A('elbowR', -1.5 + strike * 1.4, 0, 0);
      A('shoulderL', 0.25, 0, 0.5);
      A('elbowL', -1.5, 0, 0);
      A('chest', 0, -0.35 + strike * 0.35, 0);
      A('hipL', 0.1, 0, 0);
      A('hipR', -0.15, 0, 0);
    } else if (p === 'shoot') {
      const t = clamp(this.shootT / 0.4, 0, 1);
      const recoil = Math.exp(-t * 9);
      const aim = extra.aim ?? 0;
      A('shoulderR', -1.5 + recoil * 0.28, 0, -0.12);
      A('elbowR', -0.12 - recoil * 0.2, 0, 0);
      A('shoulderL', -1.35 + recoil * 0.2, 0.35, 0.35);
      A('elbowL', -0.85, 0, 0);
      A('chest', 0, -0.18, 0);
      A('head', 0, -0.1, 0);
      A('hipL', 0, 0, 0);
      A('hipR', 0, 0, 0);
      if (aim > 0.5) {
        A('shoulderL', -1.5, 0.45, 0.3);
        A('elbowL', -0.2, 0, 0);
      }
    } else if (p === 'drive') {
      A('shoulderL', -1.15, 0.42, 0.45);
      A('shoulderR', -1.15, -0.42, -0.45);
      A('elbowL', -0.75, 0, 0);
      A('elbowR', -0.75, 0, 0);
      A('hipL', -1.15, 0, 0.22);
      A('hipR', -1.15, 0, -0.22);
      A('kneeL', 1.25, 0, 0);
      A('kneeR', 1.25, 0, 0);
      A('chest', 0.12, 0, 0);
      A('head', -0.05, 0, 0);
    } else if (p === 'dead') {
      A('hipL', -1.5, 0, 0.3);
      A('hipR', -1.5, 0, -0.3);
      A('kneeL', 0.6, 0, 0);
      A('kneeR', 0.6, 0, 0);
      A('shoulderL', 0.4, 0, 0.9);
      A('shoulderR', 0.4, 0, -0.9);
      A('chest', 0.4, 0, 0);
      A('head', 0.4, 0, 0);
    }
  }

  dispose() {
    this.group.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.geometry.dispose();
      }
    });
    this.mats.forEach((m) => m.dispose());
  }
}

/** CHOP - the player's dog. */
export class Dog {
  group = new THREE.Group();
  private phase = 0;
  private legs: THREE.Group[] = [];
  private tail: THREE.Group;
  private head: THREE.Group;
  private body: THREE.Group;
  private mats: THREE.Material[] = [];

  constructor(color = 0x8d6b4a, dark = 0x4b3524) {
    const fur = new THREE.MeshStandardMaterial({ color, roughness: 0.95 });
    const furDark = new THREE.MeshStandardMaterial({ color: dark, roughness: 0.95 });
    const nose = new THREE.MeshStandardMaterial({ color: 0x1a1a1c, roughness: 0.4 });
    const eye = new THREE.MeshStandardMaterial({ color: 0x14100c, roughness: 0.2 });
    this.mats.push(fur, furDark, nose, eye);

    const body = new THREE.Group();
    body.position.y = 0.42;
    this.group.add(body);
    this.body = body;

    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.15, 0.42, 5, 12), fur);
    torso.rotation.x = Math.PI / 2;
    torso.scale.set(1, 1, 0.92);
    torso.castShadow = true;
    body.add(torso);

    const chest = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 10), fur);
    chest.position.z = 0.2;
    chest.scale.set(1, 1, 0.85);
    chest.castShadow = true;
    body.add(chest);

    const neck = new THREE.Group();
    neck.position.set(0, 0.08, 0.28);
    body.add(neck);
    const head = new THREE.Group();
    head.position.set(0, 0.06, 0.1);
    neck.add(head);
    this.head = head;
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.115, 14, 12), fur);
    skull.scale.set(0.95, 0.95, 1.05);
    skull.castShadow = true;
    head.add(skull);
    const snout = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.1, 4, 10), fur);
    snout.rotation.x = Math.PI / 2;
    snout.position.set(0, -0.035, 0.13);
    snout.scale.set(1, 0.8, 1);
    head.add(snout);
    const noseM = new THREE.Mesh(new THREE.SphereGeometry(0.028, 8, 8), nose);
    noseM.position.set(0, -0.025, 0.19);
    head.add(noseM);
    [-1, 1].forEach((s) => {
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.019, 8, 8), eye);
      e.position.set(s * 0.05, 0.035, 0.09);
      head.add(e);
      const ear = new THREE.Mesh(new THREE.ConeGeometry(0.052, 0.11, 6), furDark);
      ear.position.set(s * 0.075, 0.1, -0.01);
      ear.rotation.z = s * 0.35;
      ear.castShadow = true;
      head.add(ear);
    });

    const legPositions: [number, number][] = [
      [0.1, 0.2],
      [-0.1, 0.2],
      [0.1, -0.2],
      [-0.1, -0.2],
    ];
    legPositions.forEach(([x, z]) => {
      const g = new THREE.Group();
      g.position.set(x, -0.12, z);
      body.add(g);
      const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.038, 0.14, 3, 8), fur);
      upper.position.y = -0.09;
      upper.castShadow = true;
      g.add(upper);
      const lower = new THREE.Group();
      lower.position.y = -0.19;
      g.add(lower);
      const lm = new THREE.Mesh(new THREE.CapsuleGeometry(0.03, 0.12, 3, 8), fur);
      lm.position.y = -0.08;
      lower.add(lm);
      const paw = new THREE.Mesh(new THREE.SphereGeometry(0.042, 8, 6), furDark);
      paw.position.y = -0.15;
      paw.scale.set(1, 0.6, 1.2);
      lower.add(paw);
      this.legs.push(g);
    });

    const tail = new THREE.Group();
    tail.position.set(0, 0.06, -0.33);
    body.add(tail);
    this.tail = tail;
    const t1 = new THREE.Mesh(new THREE.CapsuleGeometry(0.026, 0.16, 3, 8), fur);
    t1.rotation.x = -0.9;
    t1.position.set(0, 0.09, -0.07);
    t1.castShadow = true;
    tail.add(t1);
    const t2 = new THREE.Group();
    t2.position.set(0, 0.17, -0.13);
    tail.add(t2);
    const t2m = new THREE.Mesh(new THREE.CapsuleGeometry(0.02, 0.14, 3, 8), fur);
    t2m.rotation.x = -1.0;
    t2m.position.set(0, 0.07, -0.06);
    t2.add(t2m);
  }

  update(dt: number, speed: number, sitting: boolean) {
    const run = clamp(speed / 5, 0, 1.5);
    this.phase += dt * (2 + run * 9);
    const ph = this.phase;
    this.legs.forEach((g, i) => {
      const off = (i === 0 || i === 3) ? 0 : Math.PI;
      const sw = Math.sin(ph + off) * (0.25 + run * 0.7);
      g.rotation.x = sw;
    });
    this.body.position.y = 0.42 + Math.sin(ph * 2) * 0.012 * (0.4 + run);
    this.body.rotation.x = sitting ? -0.5 : run * 0.08;
    this.tail.rotation.y = Math.sin(ph * 3) * (0.35 + run * 0.3);
    this.tail.rotation.x = sitting ? -0.4 : -0.1;
    this.head.rotation.x = Math.sin(ph * 2 + 1) * 0.06 + (sitting ? 0.2 : 0);
    this.head.rotation.y = Math.sin(ph * 0.8) * 0.12;
  }

  dispose() {
    this.group.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) m.geometry.dispose();
    });
    this.mats.forEach((m) => m.dispose());
  }
}
