import * as THREE from 'three';
import type { Pose } from './anim';

export type FighterId = 'leon' | 'ada';

export interface Rig {
  root: THREE.Group;
  pivot: THREE.Group;
  hips: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  lS: THREE.Group; lE: THREE.Group;
  rS: THREE.Group; rE: THREE.Group;
  lH: THREE.Group; lK: THREE.Group; lF: THREE.Group;
  rH: THREE.Group; rK: THREE.Group; rF: THREE.Group;
  lHand: THREE.Object3D; rHand: THREE.Object3D;
  hipH: number;
  thigh: number;
  materials: THREE.MeshStandardMaterial[];
}

const std = (color: number, rough = 0.7, metal = 0.0, emissive = 0x000000) =>
  new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal, emissive, flatShading: false });

function add<T extends THREE.Object3D>(parent: THREE.Object3D, o: T, x = 0, y = 0, z = 0): T {
  o.position.set(x, y, z);
  parent.add(o);
  return o;
}

function mesh(geo: THREE.BufferGeometry, mat: THREE.Material, shadow = true) {
  const m = new THREE.Mesh(geo, mat);
  m.castShadow = shadow;
  return m;
}

function limb(r0: number, r1: number, len: number, mat: THREE.Material) {
  // tapered limb segment hanging down from the pivot
  const g = new THREE.CylinderGeometry(r0, r1, len - 0.04, 10, 1);
  const m = mesh(g, mat);
  m.position.y = -len / 2;
  const g2 = new THREE.Group();
  g2.add(m);
  const cap = mesh(new THREE.SphereGeometry(r0, 10, 8), mat);
  cap.position.y = 0;
  g2.add(cap);
  const cap2 = mesh(new THREE.SphereGeometry(r1, 10, 8), mat);
  cap2.position.y = -len + 0.02;
  g2.add(cap2);
  return g2;
}

export function buildFighter(id: FighterId): Rig {
  const leon = id === 'leon';
  const mats: THREE.MeshStandardMaterial[] = [];
  const M = (c: number, r = 0.7, m = 0, e = 0) => {
    const x = std(c, r, m, e);
    mats.push(x);
    return x;
  };

  // palette
  const skin = M(leon ? 0xe0b394 : 0xeac3a6, 0.6);
  const hairMat = M(leon ? 0x9a7745 : 0x08080b, leon ? 0.8 : 0.28, leon ? 0 : 0.2);
  const jacket = M(leon ? 0x17191d : 0xb3121d, leon ? 0.75 : 0.45, leon ? 0 : 0.1);
  const jacketDark = M(0x0c0d0f, 0.7);
  const pants = M(leon ? 0x1e2126 : 0x0e0e10, leon ? 0.8 : 0.35, leon ? 0 : 0.1);
  const boots = M(0x0a0a0b, 0.45, 0.15);
  const gear = M(0x3a3d3a, 0.6, 0.3);
  const strap = M(0x2b2a26, 0.8);
  const metal = M(0x9aa0a6, 0.3, 0.8);
  const gloves = M(0x0b0b0d, 0.6);
  const dark = M(0x050505, 0.5);
  const red = M(0xb3121d, 0.4, 0.1);
  const lipMat = M(0xa8101e, 0.3);

  const thigh = leon ? 0.47 : 0.45;
  const shin = leon ? 0.47 : 0.45;
  const footH = leon ? 0.07 : 0.1;
  const hipH = thigh + shin + footH + 0.02;
  const shW = leon ? 0.235 : 0.2;
  const hipW = leon ? 0.105 : 0.095;
  const torsoLen = leon ? 0.5 : 0.46;
  const armU = leon ? 0.3 : 0.27;
  const armL = leon ? 0.28 : 0.25;
  const sc = leon ? 1.0 : 0.97;

  const root = new THREE.Group();
  const pivot = add(root, new THREE.Group(), 0, hipH, 0);
  pivot.rotation.order = 'YXZ';
  const hips = add(pivot, new THREE.Group());
  hips.rotation.order = 'YXZ';
  root.scale.setScalar(sc);

  // pelvis
  const pelvis = add(hips, mesh(new THREE.BoxGeometry(hipW * 3.2, 0.16, 0.2), pants), 0, 0.0, 0);
  pelvis.scale.set(1, 1, 1);
  // belt
  const belt = add(hips, mesh(new THREE.CylinderGeometry(0.175, 0.175, 0.05, 14), leon ? strap : dark), 0, 0.09, 0);
  belt.scale.z = 0.72;
  const buckle = add(hips, mesh(new THREE.BoxGeometry(0.06, 0.045, 0.02), metal), 0, 0.09, 0.13);
  void buckle;

  // ---- legs ----
  function makeLeg(side: 1 | -1) {
    const H = add(hips, new THREE.Group(), side * hipW, -0.02, 0);
    H.rotation.order = 'YXZ';
    const thighMat = pants;
    H.add(limb(leon ? 0.092 : 0.082, leon ? 0.07 : 0.062, thigh, thighMat));
    const K = add(H, new THREE.Group(), 0, -thigh, 0);
    K.rotation.order = 'YXZ';
    K.add(limb(leon ? 0.07 : 0.062, leon ? 0.06 : 0.05, shin, leon ? pants : boots));
    const F = add(K, new THREE.Group(), 0, -shin, 0);
    F.rotation.order = 'YXZ';
    if (leon) {
      // combat boot
      const shaft = add(K, mesh(new THREE.CylinderGeometry(0.072, 0.066, 0.22, 10), boots), 0, -shin + 0.1, 0);
      void shaft;
      const foot = add(F, mesh(new THREE.BoxGeometry(0.115, 0.075, 0.28), boots), 0, -0.035, 0.07);
      void foot;
      add(F, mesh(new THREE.BoxGeometry(0.12, 0.025, 0.3), M(0x2a2a2a, 0.9)), 0, -0.075, 0.07);
      const laces = add(F, mesh(new THREE.BoxGeometry(0.06, 0.02, 0.1), gear), 0, 0.01, 0.09);
      void laces;
    } else {
      // stocking + heeled boot
      const foot = add(F, mesh(new THREE.BoxGeometry(0.085, 0.06, 0.24), boots), 0, -0.05, 0.06);
      foot.rotation.x = 0.5;
      const heel = add(F, mesh(new THREE.ConeGeometry(0.02, 0.1, 6), metal), 0, -0.08, -0.045);
      heel.rotation.x = Math.PI;
      add(F, mesh(new THREE.CylinderGeometry(0.058, 0.052, 0.2, 10), boots), 0, 0.09, -0.005);
    }
    return { H, K, F };
  }
  const L = makeLeg(1);
  const R = makeLeg(-1);

  // ---- torso ----
  const torso = add(hips, new THREE.Group(), 0, 0.1, 0);
  torso.rotation.order = 'YXZ';
  const abdomen = add(torso, mesh(new THREE.CylinderGeometry(0.155, 0.15, 0.3, 14), leon ? jacket : jacketDark), 0, 0.12, 0);
  abdomen.scale.z = 0.72;
  const chest = add(torso, mesh(new THREE.CapsuleGeometry(0.135, leon ? 0.22 : 0.17, 5, 12), jacket), 0, torsoLen - 0.14, 0);
  chest.rotation.z = Math.PI / 2;
  chest.scale.set(1, 1, 0.78);

  if (leon) {
    // jacket hem
    const hem = add(hips, mesh(new THREE.CylinderGeometry(0.19, 0.205, 0.2, 14, 1, true), jacket), 0, 0.0, 0);
    hem.scale.z = 0.75;
    (hem.material as THREE.Material).side = THREE.DoubleSide;
    // collar
    const collar = add(torso, mesh(new THREE.CylinderGeometry(0.1, 0.12, 0.09, 12, 1, true), jacket), 0, torsoLen + 0.02, 0);
    (collar.material as THREE.Material).side = THREE.DoubleSide;
    // tactical chest straps
    for (const s of [1, -1]) {
      const st = add(torso, mesh(new THREE.BoxGeometry(0.055, 0.42, 0.012), strap), s * 0.1, torsoLen - 0.2, 0.108);
      st.rotation.z = -s * 0.12;
    }
    // chest rig pouches + knife
    add(torso, mesh(new THREE.BoxGeometry(0.09, 0.09, 0.045), gear), -0.12, torsoLen - 0.3, 0.12);
    add(torso, mesh(new THREE.BoxGeometry(0.09, 0.09, 0.045), gear), 0.12, torsoLen - 0.3, 0.12);
    const knife = add(torso, mesh(new THREE.BoxGeometry(0.025, 0.14, 0.02), jacketDark), 0.14, torsoLen - 0.13, 0.12);
    knife.rotation.z = 0.35;
    const hilt = add(torso, mesh(new THREE.BoxGeometry(0.035, 0.05, 0.03), metal), 0.17, torsoLen - 0.06, 0.12);
    hilt.rotation.z = 0.35;
    // thigh holster (right leg)
    add(R.H, mesh(new THREE.BoxGeometry(0.06, 0.2, 0.1), jacketDark), -0.075, -0.2, 0.02);
    add(R.H, mesh(new THREE.BoxGeometry(0.1, 0.03, 0.12), strap), 0, -0.14, 0);
    add(hips, mesh(new THREE.BoxGeometry(0.07, 0.1, 0.08), gear), 0.16, 0.0, -0.06);
  } else {
    // red dress with black accents
    const skirt = add(hips, mesh(new THREE.CylinderGeometry(0.17, 0.24, 0.26, 16, 1, true), jacket), 0, -0.1, 0);
    skirt.scale.z = 0.8;
    (skirt.material as THREE.Material).side = THREE.DoubleSide;
    const trim = add(hips, mesh(new THREE.CylinderGeometry(0.236, 0.24, 0.025, 16), dark), 0, -0.225, 0);
    trim.scale.z = 0.8;
    // black corset belt + gadget
    const cor = add(torso, mesh(new THREE.CylinderGeometry(0.14, 0.145, 0.12, 14), dark), 0, 0.12, 0);
    cor.scale.z = 0.72;
    add(hips, mesh(new THREE.BoxGeometry(0.07, 0.09, 0.05), gear), 0.17, 0.0, 0.02);
    add(hips, mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.1, 6), metal), 0.17, 0.07, 0.02);
    // collar/choker + neckline
    add(torso, mesh(new THREE.TorusGeometry(0.052, 0.012, 6, 12), dark), 0, torsoLen + 0.01, 0).rotation.x = Math.PI / 2;
    const sash = add(torso, mesh(new THREE.BoxGeometry(0.03, 0.4, 0.012), dark), 0.05, torsoLen - 0.2, 0.1);
    sash.rotation.z = -0.15;
    // thigh holster
    add(R.H, mesh(new THREE.BoxGeometry(0.05, 0.16, 0.09), dark), -0.07, -0.16, 0.01);
    // stocking top
    add(L.H, mesh(new THREE.CylinderGeometry(0.093, 0.09, 0.04, 10), red), 0, -0.02, 0);
    add(R.H, mesh(new THREE.CylinderGeometry(0.093, 0.09, 0.04, 10), red), 0, -0.02, 0);
  }

  // ---- neck & head ----
  add(torso, mesh(new THREE.CylinderGeometry(0.048, 0.055, 0.1, 10), skin), 0, torsoLen + 0.02, 0);
  const head = add(torso, new THREE.Group(), 0, torsoLen + 0.06, 0);
  head.rotation.order = 'YXZ';
  const skull = add(head, mesh(new THREE.SphereGeometry(0.1, 16, 14), skin), 0, 0.12, 0);
  skull.scale.set(0.92, 1.14, 1.0);
  const jaw = add(head, mesh(new THREE.SphereGeometry(0.075, 12, 10), skin), 0, 0.07, 0.02);
  jaw.scale.set(0.95, 0.9, 0.95);
  add(head, mesh(new THREE.BoxGeometry(0.025, 0.035, 0.03), skin), 0, 0.105, 0.098); // nose
  for (const s of [1, -1]) {
    add(head, mesh(new THREE.SphereGeometry(0.014, 6, 6), dark, false), s * 0.04, 0.13, 0.087);
    const brow = add(head, mesh(new THREE.BoxGeometry(0.045, 0.01, 0.012), leon ? M(0x6e5230) : dark, false), s * 0.04, 0.152, 0.088);
    brow.rotation.z = s * -0.12;
    add(head, mesh(new THREE.SphereGeometry(0.02, 6, 6), skin), s * 0.092, 0.11, 0); // ears
  }
  if (!leon) {
    add(head, mesh(new THREE.BoxGeometry(0.04, 0.012, 0.012), lipMat, false), 0, 0.066, 0.087);
  } else {
    add(head, mesh(new THREE.BoxGeometry(0.035, 0.008, 0.012), M(0xa0705c), false), 0, 0.068, 0.088);
  }

  // hair
  if (leon) {
    const cap = add(head, mesh(new THREE.SphereGeometry(0.108, 16, 12, 0, Math.PI * 2, 0, 1.75), hairMat), 0, 0.135, -0.012);
    cap.scale.set(0.98, 1.1, 1.08);
    const back = add(head, mesh(new THREE.SphereGeometry(0.1, 10, 8), hairMat), 0, 0.12, -0.04);
    back.scale.set(0.95, 1.0, 0.85);
    // swept fringe
    const f1 = add(head, mesh(new THREE.BoxGeometry(0.11, 0.045, 0.08), hairMat), 0.045, 0.205, 0.07);
    f1.rotation.set(-0.5, 0, -0.35);
    const f2 = add(head, mesh(new THREE.BoxGeometry(0.1, 0.04, 0.07), hairMat), -0.045, 0.2, 0.075);
    f2.rotation.set(-0.45, 0, 0.45);
    const f3 = add(head, mesh(new THREE.BoxGeometry(0.05, 0.07, 0.05), hairMat), 0.09, 0.15, 0.05);
    f3.rotation.set(0, 0, -0.2);
    const f4 = add(head, mesh(new THREE.BoxGeometry(0.05, 0.07, 0.05), hairMat), -0.09, 0.15, 0.05);
    f4.rotation.set(0, 0, 0.2);
  } else {
    const cap = add(head, mesh(new THREE.SphereGeometry(0.112, 16, 12, 0, Math.PI * 2, 0, 1.85), hairMat), 0, 0.135, -0.012);
    cap.scale.set(1.0, 1.12, 1.1);
    // bob cut
    const bob = add(head, mesh(new THREE.CylinderGeometry(0.115, 0.125, 0.15, 14, 1, true, Math.PI * 0.35, Math.PI * 1.3), hairMat), 0, 0.075, -0.02);
    bob.rotation.y = Math.PI;
    bob.scale.z = 1.05;
    (bob.material as THREE.Material).side = THREE.DoubleSide;
    for (const s of [1, -1]) {
      const side = add(head, mesh(new THREE.BoxGeometry(0.03, 0.17, 0.15), hairMat), s * 0.1, 0.1, -0.005);
      side.rotation.z = s * -0.08;
    }
    const bangs = add(head, mesh(new THREE.BoxGeometry(0.2, 0.04, 0.06), hairMat), 0.0, 0.2, 0.075);
    bangs.rotation.set(-0.5, 0, -0.12);
    const bangs2 = add(head, mesh(new THREE.BoxGeometry(0.08, 0.06, 0.04), hairMat), 0.07, 0.175, 0.09);
    bangs2.rotation.set(-0.2, 0, -0.5);
  }

  // ---- arms ----
  function makeArm(side: 1 | -1) {
    const S = add(torso, new THREE.Group(), side * shW, torsoLen - 0.06, 0);
    S.rotation.order = 'YXZ';
    const sleeve = leon ? jacket : skin;
    S.add(limb(leon ? 0.062 : 0.048, leon ? 0.052 : 0.04, armU, sleeve));
    const pad = add(S, mesh(new THREE.SphereGeometry(leon ? 0.075 : 0.058, 10, 8), leon ? jacket : red), 0, 0.0, 0);
    void pad;
    const E = add(S, new THREE.Group(), 0, -armU, 0);
    E.rotation.order = 'YXZ';
    E.add(limb(leon ? 0.052 : 0.04, leon ? 0.045 : 0.036, armL, leon ? jacket : gloves));
    const Hd = add(E, new THREE.Group(), 0, -armL, 0);
    add(Hd, mesh(new THREE.SphereGeometry(leon ? 0.052 : 0.042, 10, 8), gloves), 0, -0.02, 0.0);
    add(Hd, mesh(new THREE.CylinderGeometry(0.05, 0.055, 0.04, 8), leon ? gear : gloves), 0, 0.04, 0);
    return { S, E, Hd };
  }
  const LA = makeArm(1);
  const RA = makeArm(-1);

  root.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) o.castShadow = true;
  });

  return {
    root, pivot, hips, torso, head,
    lS: LA.S, lE: LA.E, rS: RA.S, rE: RA.E,
    lH: L.H, lK: L.K, lF: L.F, rH: R.H, rK: R.K, rF: R.F,
    lHand: LA.Hd, rHand: RA.Hd,
    hipH, thigh, materials: mats,
  };
}

export function applyPose(rig: Rig, p: Pose) {
  rig.pivot.position.y = rig.hipH + p.by;
  rig.pivot.rotation.set(p.bx, p.bs, p.bz);
  const drop = 2 * rig.thigh * (1 - Math.cos(p.cr));
  rig.hips.position.y = -drop;
  rig.hips.rotation.y = p.ry;
  rig.torso.rotation.set(p.tx, p.ty, p.tz);
  rig.head.rotation.set(p.hx - p.tx * 0.45, p.hy - p.ty * 0.5, -p.tz * 0.5);

  rig.lS.rotation.set(p.lsx, p.lsy, p.lsz);
  rig.lE.rotation.set(p.lex, 0, 0);
  rig.rS.rotation.set(p.rsx, p.rsy, p.rsz);
  rig.rE.rotation.set(p.rex, 0, 0);

  const ltx = p.lhx - p.cr, lkx = p.lkx + 2 * p.cr;
  const rtx = p.rhx - p.cr, rkx = p.rkx + 2 * p.cr;
  rig.lH.rotation.set(ltx, p.lhy, p.lhz);
  rig.lK.rotation.set(lkx, 0, 0);
  rig.lF.rotation.set(-(ltx + lkx) * 0.85 + p.lfx, 0, 0);
  rig.rH.rotation.set(rtx, p.rhy, p.rhz);
  rig.rK.rotation.set(rkx, 0, 0);
  rig.rF.rotation.set(-(rtx + rkx) * 0.85 + p.rfx, 0, 0);
}
