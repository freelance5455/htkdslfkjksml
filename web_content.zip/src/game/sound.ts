const MUTE_STORAGE_KEY = 'bentonamu_muted';

class RetroSoundEngine {
  private ctx: AudioContext | null = null;
  private muted: boolean = false;
  private lastWarningBeepAt = 0;

  constructor() {
    try {
      this.muted = localStorage.getItem(MUTE_STORAGE_KEY) === '1';
    } catch {
      this.muted = false;
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public toggleMute(): boolean {
    this.muted = !this.muted;
    try {
      localStorage.setItem(MUTE_STORAGE_KEY, this.muted ? '1' : '0');
    } catch {
      // ignore storage errors
    }
    return this.muted;
  }

  public unlock(): void {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  private playTone(
    freqStart: number,
    freqEnd: number,
    duration: number,
    type: OscillatorType,
    gainPeak: number,
    delay = 0
  ): void {
    if (this.muted || !this.ctx || this.ctx.state !== 'running') return;

    const now = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freqStart, now);
    if (freqEnd !== freqStart) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), now + duration);
    }

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(gainPeak, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  public playHop(): void {
    const jitter = 0.94 + Math.random() * 0.12;
    this.playTone(290 * jitter, 460 * jitter, 0.075, 'square', 0.06);
  }

  public playCloverTick(step: number): void {
    // Pentatonic ascending notes for 0.5s, 1.0s, 1.5s, 2.0s, 2.5s
    const scale = [523.25, 587.33, 659.25, 783.99, 880.0];
    const freq = scale[Math.min(scale.length - 1, Math.max(0, step - 1))];
    this.playTone(freq, freq * 1.04, 0.09, 'triangle', 0.1);
  }

  public playCloverCollected(isGolden: boolean): void {
    const notes = isGolden
      ? [659.25, 783.99, 987.77, 1318.51]
      : [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, idx) => {
      this.playTone(freq, freq, 0.11, 'square', 0.085, idx * 0.055);
    });
  }

  public playCrossingWarning(): void {
    const nowMs = performance.now();
    if (nowMs - this.lastWarningBeepAt < 420) return;
    this.lastWarningBeepAt = nowMs;

    // Authentic Japanese fumikiri two-tone bell chime ("kan-kan")
    this.playTone(740, 725, 0.1, 'triangle', 0.075, 0);
    this.playTone(587.33, 575, 0.12, 'triangle', 0.075, 0.14);
  }

  public playTrainWhoosh(): void {
    if (this.muted || !this.ctx || this.ctx.state !== 'running') return;
    const now = this.ctx.currentTime;
    const duration = 0.22;
    const bufferSize = Math.floor(this.ctx.sampleRate * duration);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * 0.6;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(320, now);
    filter.frequency.exponentialRampToValueAtTime(900, now + 0.09);
    filter.frequency.exponentialRampToValueAtTime(220, now + duration);
    filter.Q.value = 1.6;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.09, now + 0.06);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);
    noise.start(now);
  }

  public playCloseCall(): void {
    this.playTone(880, 1174.66, 0.09, 'sine', 0.08, 0);
    this.playTone(1174.66, 1396.91, 0.09, 'sine', 0.07, 0.06);
  }

  public playStart(): void {
    this.unlock();
    const notes = [392.0, 523.25, 659.25];
    notes.forEach((f, i) => this.playTone(f, f, 0.1, 'square', 0.07, i * 0.06));
  }

  public playCrash(): void {
    this.playTone(220, 55, 0.32, 'sawtooth', 0.15, 0);
    this.playTone(150, 42, 0.38, 'square', 0.11, 0.04);
  }

  public playLehauCatch(): void {
    // Humorous retro meme slide + comic sting
    this.playTone(340, 880, 0.14, 'square', 0.11, 0);
    this.playTone(620, 210, 0.22, 'sawtooth', 0.12, 0.12);
    this.playTone(185, 110, 0.28, 'square', 0.11, 0.24);
  }

  public playMapTransform(): void {
    // Crisp 4-note retro warp arpeggio
    const notes = [330, 440, 554.37, 659.25];
    notes.forEach((f, idx) => {
      this.playTone(f, f * 1.06, 0.11, 'triangle', 0.09, idx * 0.055);
    });
  }
}

export const soundEngine = new RetroSoundEngine();
