/**
 * SPR - Sahil Powerful Run
 * High-Performance Procedural Texture Generator
 * Generates lightweight, crisp canvas textures matching the SPR reference world:
 * - Royal Blue & Gold SPR Banner Flags with Lion Crest
 * - Red & White Diagonal Construction Barricades
 * - Wooden Cargo Crates with X-Braces
 * - Yellow & Black Chevron Booster Jump Ramps
 * - Modern Commuter Subway Train (Front & Side)
 * - Red & White Striped Coastal Lighthouse
 * - Golden Royal Crown Coin Insignia
 */

import * as THREE from 'three';

class TextureGenerator {
  private cache: Map<string, THREE.CanvasTexture> = new Map();

  /**
   * Royal Blue Banner Flag with Golden Lion Crest and bold 'SPR'
   */
  public getSPRBannerTexture(): THREE.CanvasTexture {
    const key = 'spr_banner';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Royal Blue Background with gradient
    const grad = ctx.createLinearGradient(0, 0, 256, 512);
    grad.addColorStop(0, '#1e3a8a');
    grad.addColorStop(0.5, '#172554');
    grad.addColorStop(1, '#0f172a');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 512);

    // Golden decorative border
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 10;
    ctx.strokeRect(12, 12, 232, 488);

    ctx.strokeStyle = '#fef08a';
    ctx.lineWidth = 2;
    ctx.strokeRect(20, 20, 216, 472);

    // Crown Icon on Top
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.moveTo(82, 115);
    ctx.lineTo(96, 70);
    ctx.lineTo(128, 92);
    ctx.lineTo(160, 70);
    ctx.lineTo(174, 115);
    ctx.closePath();
    ctx.fill();

    // Crown Golden Trim
    ctx.strokeStyle = '#fef08a';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Crown Jewels
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(128, 98, 6, 0, Math.PI * 2);
    ctx.arc(96, 70, 4, 0, Math.PI * 2);
    ctx.arc(160, 70, 4, 0, Math.PI * 2);
    ctx.fill();

    // Shield/Circle Frame for Lion Crest
    ctx.fillStyle = '#1e3a8a';
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(128, 185, 52, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // White Lion Head Crest (matching reference image bright white crest)
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(128, 185, 42, 0, Math.PI * 2);
    ctx.fill();

    // Lion Mane Details
    ctx.fillStyle = '#ffffff';
    for (let i = 0; i < 14; i++) {
      const angle = (i / 14) * Math.PI * 2;
      const x = 128 + Math.cos(angle) * 44;
      const y = 185 + Math.sin(angle) * 44;
      ctx.beginPath();
      ctx.arc(x, y, 12, 0, Math.PI * 2);
      ctx.fill();
    }

    // Lion Face Inner Features (Royal Blue lines)
    ctx.strokeStyle = '#1e3a8a';
    ctx.lineWidth = 4;
    // Eyes
    ctx.fillStyle = '#1e3a8a';
    ctx.beginPath();
    ctx.arc(114, 176, 5, 0, Math.PI * 2);
    ctx.arc(142, 176, 5, 0, Math.PI * 2);
    ctx.fill();
    // Nose / Muzzle
    ctx.beginPath();
    ctx.moveTo(128, 188);
    ctx.lineTo(121, 200);
    ctx.lineTo(135, 200);
    ctx.closePath();
    ctx.fill();
    // Whisker lines
    ctx.beginPath();
    ctx.moveTo(106, 196); ctx.lineTo(92, 198);
    ctx.moveTo(106, 202); ctx.lineTo(90, 208);
    ctx.moveTo(150, 196); ctx.lineTo(164, 198);
    ctx.moveTo(150, 202); ctx.lineTo(166, 208);
    ctx.stroke();

    // Bold SPR Typography (Large, prominent, pristine white letters)
    ctx.fillStyle = '#ffffff';
    ctx.font = '900 74px "Arial Black", Arial, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = '#000000';
    ctx.shadowBlur = 12;
    ctx.fillText('SPR', 128, 285);

    // Subtitle: SAHIL POWERFUL RUN
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#fde047';
    ctx.font = '800 15px Arial, sans-serif';
    ctx.fillText('SAHIL POWERFUL RUN', 128, 335);

    // Bottom Decorative Ribbon / Tassels
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(25, 470);
    ctx.lineTo(128, 450);
    ctx.lineTo(231, 470);
    ctx.stroke();

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Red & White 45-degree Diagonal Striped Barricade
   */
  public getBarricadeTexture(): THREE.CanvasTexture {
    const key = 'barricade_stripes';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;

    // Clean white background
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 0, 256, 128);

    // Bold red diagonal stripes
    ctx.fillStyle = '#ef4444';
    const stripeWidth = 40;
    for (let x = -128; x < 384; x += stripeWidth * 2) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x + stripeWidth, 0);
      ctx.lineTo(x + stripeWidth + 128, 128);
      ctx.lineTo(x + 128, 128);
      ctx.closePath();
      ctx.fill();
    }

    // Weathered border
    ctx.strokeStyle = '#991b1b';
    ctx.lineWidth = 6;
    ctx.strokeRect(3, 3, 250, 122);

    const tex = new THREE.CanvasTexture(canvas);
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Wooden Cargo Crate with X Cross Bracing
   */
  public getWoodCrateTexture(): THREE.CanvasTexture {
    const key = 'wood_crate';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Base timber planks
    ctx.fillStyle = '#b45309';
    ctx.fillRect(0, 0, 256, 256);

    // Horizontal plank seams
    ctx.fillStyle = '#78350f';
    for (let y = 64; y < 256; y += 64) {
      ctx.fillRect(0, y - 2, 256, 4);
    }

    // Outer border frame
    ctx.fillStyle = '#92400e';
    ctx.fillRect(0, 0, 256, 28);
    ctx.fillRect(0, 228, 256, 28);
    ctx.fillRect(0, 0, 28, 256);
    ctx.fillRect(228, 0, 28, 256);

    // Diagonal Cross Brace (X)
    ctx.strokeStyle = '#78350f';
    ctx.lineWidth = 26;
    ctx.beginPath();
    ctx.moveTo(28, 28);
    ctx.lineTo(228, 228);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(228, 28);
    ctx.lineTo(28, 228);
    ctx.stroke();

    // Rivets / Bolts in corners
    ctx.fillStyle = '#451a03';
    const corners = [
      [14, 14], [242, 14], [14, 242], [242, 242],
      [128, 14], [128, 242], [14, 128], [242, 128]
    ];
    for (const [cx, cy] of corners) {
      ctx.beginPath();
      ctx.arc(cx, cy, 6, 0, Math.PI * 2);
      ctx.fill();
    }

    const tex = new THREE.CanvasTexture(canvas);
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Yellow & Black Forward Chevron Jump Ramp
   */
  public getChevronRampTexture(): THREE.CanvasTexture {
    const key = 'chevron_ramp';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Radiant warning yellow
    ctx.fillStyle = '#eab308';
    ctx.fillRect(0, 0, 256, 256);

    // Black chevron arrows (pointing forward/up)
    ctx.fillStyle = '#0f172a';
    for (let y = 30; y < 240; y += 75) {
      ctx.beginPath();
      ctx.moveTo(40, y + 45);
      ctx.lineTo(128, y);
      ctx.lineTo(216, y + 45);
      ctx.lineTo(196, y + 55);
      ctx.lineTo(128, y + 16);
      ctx.lineTo(60, y + 55);
      ctx.closePath();
      ctx.fill();
    }

    // Outer border
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 12;
    ctx.strokeRect(6, 6, 244, 244);

    const tex = new THREE.CanvasTexture(canvas);
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Train Front Face (Windshield, Headlights, Red Accent, SPR Transit Logo)
   */
  public getTrainFrontTexture(): THREE.CanvasTexture {
    const key = 'train_front';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Train Metallic Silver/Blue Face
    const grad = ctx.createLinearGradient(0, 0, 256, 0);
    grad.addColorStop(0, '#64748b');
    grad.addColorStop(0.5, '#cbd5e1');
    grad.addColorStop(1, '#64748b');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 256);

    // Cab Windshield (Dark Blue Tinted Glass)
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(24, 24, 208, 90);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 3;
    ctx.strokeRect(26, 26, 204, 86);

    // Windshield Center Divider
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(124, 24, 8, 90);

    // Destination Sign: SPR EXPRESS
    ctx.fillStyle = '#0284c7';
    ctx.fillRect(50, 6, 156, 16);
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 11px Arial, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('SPR EXPRESS', 128, 18);

    // Red Safety Stripe Across Middle
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(0, 130, 256, 20);

    // Dual Glowing Headlights
    ctx.fillStyle = '#fef08a';
    ctx.shadowColor = '#facc15';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(52, 180, 16, 0, Math.PI * 2);
    ctx.arc(204, 180, 16, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Headlight Chrome Rings
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(52, 180, 18, 0, Math.PI * 2);
    ctx.arc(204, 180, 18, 0, Math.PI * 2);
    ctx.stroke();

    // Front Coupler / Grill
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(78, 200, 100, 44);
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 2;
    for (let gy = 208; gy < 240; gy += 8) {
      ctx.beginPath();
      ctx.moveTo(82, gy);
      ctx.lineTo(174, gy);
      ctx.stroke();
    }

    const tex = new THREE.CanvasTexture(canvas);
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Train Carriage Side (Passenger Windows, Fluted Stainless Steel, Red Stripe)
   */
  public getTrainSideTexture(): THREE.CanvasTexture {
    const key = 'train_side';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;

    // Stainless Steel Metallic Body
    ctx.fillStyle = '#cbd5e1';
    ctx.fillRect(0, 0, 512, 128);

    // Fluted metal horizontal lines on lower body
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 2;
    for (let y = 75; y < 125; y += 8) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(512, y);
      ctx.stroke();
    }

    // Red Racing Stripe
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(0, 64, 512, 10);

    // Dark Blue Window Band
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 12, 512, 48);

    // 4 Passenger Windows with Blue Glass reflection
    for (let wx = 30; wx < 500; wx += 120) {
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(wx, 16, 80, 40);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.strokeRect(wx, 16, 80, 40);

      // Glass shine
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.beginPath();
      ctx.moveTo(wx + 10, 54);
      ctx.lineTo(wx + 30, 18);
      ctx.lineTo(wx + 45, 18);
      ctx.lineTo(wx + 25, 54);
      ctx.closePath();
      ctx.fill();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Coastal Lighthouse (Alternating Wide Red & White Horizontal Stripes)
   */
  public getLighthouseTexture(): THREE.CanvasTexture {
    const key = 'lighthouse_stripes';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // 5 alternating bands (Red, White, Red, White, Red)
    const bandHeight = 256 / 5;
    for (let i = 0; i < 5; i++) {
      ctx.fillStyle = i % 2 === 0 ? '#dc2626' : '#f8fafc';
      ctx.fillRect(0, i * bandHeight, 128, bandHeight);
    }

    // Subtle stone block lines
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.15)';
    ctx.lineWidth = 1;
    for (let y = 0; y < 256; y += 16) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(128, y);
      ctx.stroke();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Golden SPR Crown Coin Face
   */
  public getCoinCrownTexture(): THREE.CanvasTexture {
    const key = 'coin_crown';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;

    // Golden Coin Ring
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.arc(64, 64, 60, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#fbbf24';
    ctx.beginPath();
    ctx.arc(64, 64, 52, 0, Math.PI * 2);
    ctx.fill();

    // Inner bevel border
    ctx.strokeStyle = '#d97706';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(64, 64, 48, 0, Math.PI * 2);
    ctx.stroke();

    // Crown Icon in Center
    ctx.fillStyle = '#b45309';
    ctx.beginPath();
    ctx.moveTo(36, 80);
    ctx.lineTo(40, 52);
    ctx.lineTo(54, 66);
    ctx.lineTo(64, 46);
    ctx.lineTo(74, 66);
    ctx.lineTo(88, 52);
    ctx.lineTo(92, 80);
    ctx.closePath();
    ctx.fill();

    // Crown highlight
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(64, 46, 4, 0, Math.PI * 2);
    ctx.arc(40, 52, 3, 0, Math.PI * 2);
    ctx.arc(88, 52, 3, 0, Math.PI * 2);
    ctx.fill();

    const tex = new THREE.CanvasTexture(canvas);
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * SPR Golden Lion Crest Backpack Texture
   * Matches the reference image backpack with golden lion crest and bold SPR
   */
  public getBackpackTexture(): THREE.CanvasTexture {
    const key = 'spr_backpack';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Black rugged backpack fabric
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, 256, 256);

    // Subtle fabric texture & perimeter stitching
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 4;
    ctx.strokeRect(12, 12, 232, 232);

    // Center Golden Circle Badge
    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.arc(128, 110, 68, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(128, 110, 66, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = '#fef08a';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(128, 110, 60, 0, Math.PI * 2);
    ctx.stroke();

    // Golden Lion Head Silhouette
    ctx.fillStyle = '#fcd34d';
    // Lion mane tufts
    for (let i = 0; i < 10; i++) {
      const angle = (i / 10) * Math.PI * 2;
      const x = 128 + Math.cos(angle) * 34;
      const y = 100 + Math.sin(angle) * 34;
      ctx.beginPath();
      ctx.arc(x, y, 10, 0, Math.PI * 2);
      ctx.fill();
    }
    // Main lion face
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.arc(128, 100, 28, 0, Math.PI * 2);
    ctx.fill();

    // Lion features (eyes and nose)
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(118, 96, 3.5, 0, Math.PI * 2);
    ctx.arc(138, 96, 3.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(128, 104);
    ctx.lineTo(123, 112);
    ctx.lineTo(133, 112);
    ctx.closePath();
    ctx.fill();

    // Crown on Lion
    ctx.fillStyle = '#fbbf24';
    ctx.beginPath();
    ctx.moveTo(116, 80);
    ctx.lineTo(120, 68);
    ctx.lineTo(128, 74);
    ctx.lineTo(136, 68);
    ctx.lineTo(140, 80);
    ctx.closePath();
    ctx.fill();

    // Bold SPR Typography (Matching Reference Requirement: SPR, not STP)
    ctx.fillStyle = '#fef08a';
    ctx.font = '900 36px Arial, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = '#000000';
    ctx.shadowBlur = 6;
    ctx.fillText('SPR', 128, 142);
    ctx.shadowBlur = 0;

    // Zipper seam detail across lower backpack
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(30, 205);
    ctx.lineTo(226, 205);
    ctx.stroke();

    const tex = new THREE.CanvasTexture(canvas);
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * White Sneaker Sole Tread Texture (grooves & grip patterns)
   */
  public getShoeSoleTexture(): THREE.CanvasTexture {
    const key = 'shoe_sole';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // White rubber sole base
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 0, 128, 256);

    // Tread lines and grip texture
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 4;
    for (let y = 20; y < 240; y += 16) {
      ctx.beginPath();
      ctx.moveTo(16, y);
      ctx.lineTo(64, y + 8);
      ctx.lineTo(112, y);
      ctx.stroke();
    }

    // Outer edge border
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 6;
    ctx.strokeRect(4, 4, 120, 248);

    const tex = new THREE.CanvasTexture(canvas);
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Warm Timber Track Boardwalk Planks (longitudinal floorboards with wood grain & seams)
   */
  public getTrackWoodPlanksTexture(): THREE.CanvasTexture {
    const key = 'track_wood_planks';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Warm golden-brown timber base (matching reference image track planks)
    ctx.fillStyle = '#9e5a2b';
    ctx.fillRect(0, 0, 256, 512);

    // Individual longitudinal wood planks with alternating rich amber/cedar tones
    const plankWidth = 256 / 4;
    const plankTones = ['#a96332', '#8f4f22', '#b76f39', '#9a5728'];
    for (let p = 0; p < 4; p++) {
      ctx.fillStyle = plankTones[p % plankTones.length];
      ctx.fillRect(p * plankWidth + 2, 0, plankWidth - 4, 512);

      // Subtle vertical wood grain lines
      ctx.strokeStyle = 'rgba(69, 26, 3, 0.28)';
      ctx.lineWidth = 1.5;
      for (let g = 0; g < 6; g++) {
        const gx = p * plankWidth + 5 + g * 8 + (p * 3) % 7;
        ctx.beginPath();
        ctx.moveTo(gx, 0);
        ctx.bezierCurveTo(gx + 3, 170, gx - 3, 340, gx, 512);
        ctx.stroke();
      }

      // Fastener nail heads / bolts spaced along planks
      ctx.fillStyle = 'rgba(45, 15, 3, 0.75)';
      for (let ny = 32; ny < 512; ny += 64) {
        ctx.beginPath();
        ctx.arc(p * plankWidth + plankWidth * 0.3, ny, 3.0, 0, Math.PI * 2);
        ctx.arc(p * plankWidth + plankWidth * 0.7, ny, 3.0, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Deep dark seam shadows between planks
    ctx.fillStyle = '#3a1705';
    for (let p = 1; p < 4; p++) {
      ctx.fillRect(p * plankWidth - 2, 0, 4, 512);
    }

    // Outer edge plank border
    ctx.fillRect(0, 0, 3, 512);
    ctx.fillRect(253, 0, 3, 512);

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(3, 8);
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Character 1 & 5: Peace Sign / Graphic Chest Badge
   */
  public getPeacePatchTexture(bgColor: string = '#18181b', symbolColor: string = '#ffffff', ringColor: string = '#f59e0b'): THREE.CanvasTexture {
    const key = `char_peace_${bgColor}_${symbolColor}_${ringColor}`;
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Base background
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, 256, 256);

    // Circular badge
    const cx = 128;
    const cy = 128;
    const r = 88;

    // Outer accent ring
    ctx.strokeStyle = ringColor;
    ctx.lineWidth = 14;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();

    // Inner peace symbol
    ctx.strokeStyle = symbolColor;
    ctx.lineWidth = 18;
    ctx.lineCap = 'round';

    // Center vertical line
    ctx.beginPath();
    ctx.moveTo(cx, cy - r + 10);
    ctx.lineTo(cx, cy + r - 10);
    ctx.stroke();

    // Diagonal left branch
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx - r * 0.7, cy + r * 0.7);
    ctx.stroke();

    // Diagonal right branch
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + r * 0.7, cy + r * 0.7);
    ctx.stroke();

    const tex = new THREE.CanvasTexture(canvas);
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Alias method for getPeacePatchTexture to match character builder calls
   */
  public getPeaceSignPatchTexture(symbolColor: string = '#ffffff', bgColor: string = '#18181b', ringColor: string = '#f59e0b'): THREE.CanvasTexture {
    return this.getPeacePatchTexture(bgColor, symbolColor, ringColor);
  }

  /**
   * Character 6: Cyan Quilted Puffer with Chunky Gold Chain
   */
  public getPufferWithGoldChainTexture(): THREE.CanvasTexture {
    const key = 'char_puffer_gold_chain';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Cyan base
    ctx.fillStyle = '#06b6d4';
    ctx.fillRect(0, 0, 256, 256);

    // Quilted horizontal baffles
    for (let y = 0; y < 256; y += 48) {
      const grad = ctx.createLinearGradient(0, y, 0, y + 48);
      grad.addColorStop(0, 'rgba(255,255,255,0.25)');
      grad.addColorStop(0.5, 'rgba(0,0,0,0)');
      grad.addColorStop(1, 'rgba(0,0,0,0.3)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, y, 256, 48);

      ctx.strokeStyle = '#0891b2';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(256, y);
      ctx.stroke();
    }

    // Chunky gold chain necklace around upper chest
    ctx.strokeStyle = '#facc15';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(128, 40, 75, 0.2, Math.PI - 0.2);
    ctx.stroke();

    // Gold chain links
    ctx.fillStyle = '#f59e0b';
    for (let a = 0.3; a <= Math.PI - 0.3; a += 0.22) {
      const lx = 128 + Math.cos(a) * 75;
      const ly = 40 + Math.sin(a) * 75;
      ctx.beginPath();
      ctx.ellipse(lx, ly, 6, 9, a, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    // Central oversized golden medallion
    ctx.fillStyle = '#e2e8f0';
    ctx.strokeStyle = '#eab308';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(128, 125, 28, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Inner medallion star
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 24px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('★', 128, 126);

    const tex = new THREE.CanvasTexture(canvas);
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Character 9: Tactical Combat Trench with Cross-Straps and Rivets
   */
  public getTacticalHarnessTexture(): THREE.CanvasTexture {
    const key = 'char_tactical_harness';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Distressed black leather
    ctx.fillStyle = '#18181b';
    ctx.fillRect(0, 0, 256, 256);

    // Weathering scratches
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 20; i++) {
      ctx.beginPath();
      ctx.moveTo(Math.random() * 256, Math.random() * 256);
      ctx.lineTo(Math.random() * 256, Math.random() * 256);
      ctx.stroke();
    }

    // Heavy brown leather tactical straps crossing chest
    ctx.strokeStyle = '#451a03';
    ctx.lineWidth = 18;
    ctx.beginPath();
    ctx.moveTo(30, 0);
    ctx.lineTo(226, 256);
    ctx.moveTo(226, 0);
    ctx.lineTo(30, 256);
    ctx.stroke();

    // Strap stitching
    ctx.strokeStyle = '#b45309';
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(34, 0);
    ctx.lineTo(230, 256);
    ctx.moveTo(222, 0);
    ctx.lineTo(26, 256);
    ctx.stroke();
    ctx.setLineDash([]);

    // Silver metal ring buckle at chest intersection
    ctx.fillStyle = '#09090b';
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(128, 128, 24, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Rivets
    const rivets = [
      { x: 50, y: 30 },
      { x: 206, y: 30 },
      { x: 50, y: 226 },
      { x: 206, y: 226 },
    ];
    ctx.fillStyle = '#cbd5e1';
    for (const r of rivets) {
      ctx.beginPath();
      ctx.arc(r.x, r.y, 4.5, 0, Math.PI * 2);
      ctx.fill();
    }

    const tex = new THREE.CanvasTexture(canvas);
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Character 13: Royal Turquoise Vest with Golden Filigree Swirls
   */
  public getRegalFiligreeTexture(): THREE.CanvasTexture {
    const key = 'char_regal_filigree';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Royal Teal background
    ctx.fillStyle = '#0f766e';
    ctx.fillRect(0, 0, 256, 256);

    // Standing collar trim border
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(0, 0, 256, 24);
    ctx.fillStyle = '#fef08a';
    ctx.fillRect(0, 24, 256, 4);

    // Golden filigree swirl patterns
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 4;
    ctx.beginPath();

    // Left lapel scroll
    ctx.arc(60, 90, 30, 0, Math.PI * 1.5, false);
    ctx.arc(60, 150, 25, Math.PI * 1.5, 0, false);
    ctx.arc(60, 200, 20, 0, Math.PI * 1.2, false);

    // Right lapel scroll
    ctx.arc(196, 90, 30, Math.PI, Math.PI * 1.5, true);
    ctx.arc(196, 150, 25, Math.PI * 1.5, Math.PI, true);
    ctx.arc(196, 200, 20, Math.PI, Math.PI * 1.8, false);

    ctx.stroke();

    // Center jewel button
    ctx.fillStyle = '#38bdf8';
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(128, 120, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    const tex = new THREE.CanvasTexture(canvas);
    this.cache.set(key, tex);
    return tex;
  }

  /**
   * Character 14 & 15: Gesioh Gladiator / Champion Energy Plate
   */
  public getCyberGauntletTexture(isElite: boolean = false): THREE.CanvasTexture {
    const key = `char_cyber_gauntlet_${isElite}`;
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Dark titanium armor base
    ctx.fillStyle = isElite ? '#1e1b4b' : '#1e293b';
    ctx.fillRect(0, 0, 256, 256);

    // Steel armor segment seams
    ctx.strokeStyle = isElite ? '#eab308' : '#64748b';
    ctx.lineWidth = 5;
    ctx.strokeRect(10, 10, 236, 236);
    ctx.strokeRect(30, 30, 196, 196);

    // Glowing Power Core (Arc Reactor style)
    const cx = 128;
    const cy = 128;

    // Outer glow
    const grad = ctx.createRadialGradient(cx, cy, 10, cx, cy, 70);
    grad.addColorStop(0, isElite ? '#fef08a' : '#38bdf8');
    grad.addColorStop(0.4, isElite ? '#f59e0b' : '#0284c7');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(cx, cy, 70, 0, Math.PI * 2);
    ctx.fill();

    // Center reactor ring
    ctx.strokeStyle = isElite ? '#facc15' : '#7dd3fc';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(cx, cy, 38, 0, Math.PI * 2);
    ctx.stroke();

    // Inner bright core
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(cx, cy, 20, 0, Math.PI * 2);
    ctx.fill();

    // Circuit trace lines radiating outwards
    ctx.strokeStyle = isElite ? '#fde047' : '#38bdf8';
    ctx.lineWidth = 3;
    for (let a = 0; a < Math.PI * 2; a += Math.PI / 4) {
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * 44, cy + Math.sin(a) * 44);
      ctx.lineTo(cx + Math.cos(a) * 85, cy + Math.sin(a) * 85);
      ctx.stroke();
    }

    const tex = new THREE.CanvasTexture(canvas);
    this.cache.set(key, tex);
    return tex;
  }

  public dispose() {
    this.cache.forEach((tex) => tex.dispose());
    this.cache.clear();
  }
}

export const textureGenerator = new TextureGenerator();
