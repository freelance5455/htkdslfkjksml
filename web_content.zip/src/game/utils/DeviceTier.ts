/**
 * SPR - Sahil Powerful Run
 * Cross-Device Performance Profiler & Automatic Graphics Tier Detector
 * Optimized for Android 8.0+ (Oreo to Android 16+), iPhones, and iPads
 */

import * as THREE from 'three';

export type GraphicsQualitySetting = 'auto' | 'low' | 'medium' | 'high';
export type ConcreteGraphicsTier = 'low' | 'medium' | 'high';

export interface DeviceProfile {
  platform: 'android' | 'ios' | 'desktop';
  isAndroid: boolean;
  isIOS: boolean;
  isMobile: boolean;
  cores: number;
  memoryGB: number;
  gpuRenderer: string;
  gpuVendor: string;
  recommendedTier: ConcreteGraphicsTier;
  summary: string;
}

export interface GraphicsTierConfig {
  tier: ConcreteGraphicsTier;
  pixelRatio: number;
  shadows: boolean;
  shadowMapType: THREE.ShadowMapType;
  shadowMapSize: number;
  particlesCount: number;
  fogDensity: number;
  cameraFar: number;
  visibleSegments: number;
  antialias: boolean;
  description: string;
}

class DeviceTierManager {
  private profile: DeviceProfile | null = null;
  private currentTier: ConcreteGraphicsTier = 'medium';
  private userSetting: GraphicsQualitySetting = 'auto';

  // Rolling FPS Monitoring for dynamic auto-tuning
  private frameTimes: number[] = [];
  private lastFpsCheck: number = performance.now();
  private isAutoDegraded: boolean = false;

  constructor() {
    this.detectDeviceProfile();
  }

  public detectDeviceProfile(): DeviceProfile {
    if (this.profile) return this.profile;

    const ua = typeof navigator !== 'undefined' ? navigator.userAgent.toLowerCase() : '';
    const isAndroid = /android/.test(ua);
    const isIOS =
      /iphone|ipad|ipod/.test(ua) ||
      (typeof navigator !== 'undefined' &&
        navigator.platform === 'MacIntel' &&
        navigator.maxTouchPoints > 1);
    const isMobile = isAndroid || isIOS || /mobile|tablet|phone/.test(ua);
    const platform: 'android' | 'ios' | 'desktop' = isAndroid
      ? 'android'
      : isIOS
      ? 'ios'
      : 'desktop';

    const cores = typeof navigator !== 'undefined' ? navigator.hardwareConcurrency || 4 : 4;
    const memoryGB =
      typeof navigator !== 'undefined' && 'deviceMemory' in navigator
        ? (navigator as { deviceMemory?: number }).deviceMemory || 4
        : isMobile
        ? 4
        : 8;

    // Detect GPU via WebGL debug extension
    let gpuRenderer = 'Standard WebGL';
    let gpuVendor = 'Generic';

    try {
      if (typeof document !== 'undefined') {
        const testCanvas = document.createElement('canvas');
        const gl =
          testCanvas.getContext('webgl') ||
          (testCanvas.getContext('experimental-webgl') as WebGLRenderingContext | null);
        if (gl) {
          const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
          if (debugInfo) {
            gpuRenderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || gpuRenderer;
            gpuVendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) || gpuVendor;
          }
        }
      }
    } catch {
      // Ignore if WebGL query fails
    }

    const gpuLower = gpuRenderer.toLowerCase();

    // Low-end device classification heuristics:
    // - Budget Android chips (Mali-400/450/Txxx/G31/G51/G52, Adreno 3xx/505/506/610/612, PowerVR GE8320/GE8300)
    // - Memory <= 3GB
    // - Cores <= 4 on mobile
    const isLowGpu =
      /mali-4|mali-t|mali-g31|mali-g51|mali-g52|adreno\s*(3|505|506|610|612)|powervr|ge8300|ge8320|mt67/.test(
        gpuLower
      );
    const isLowMemory = memoryGB <= 3;
    const isBudgetMobile = isMobile && (cores <= 4 || isLowMemory || isLowGpu);

    // High-end device classification heuristics:
    // - Desktop with dedicated GPU / Apple Silicon
    // - Flagship phones: Apple A13+, Snapdragon 8 Gen 1/2/3/4 (Adreno 7xx), Adreno 650/660, Mali-G77/G78/G710/G715/G720
    const isHighGpu =
      /apple\s*(a1[3-9]|m[1-4])|adreno\s*(6[4-9]\d|7\d\d)|mali-g7[7-9]|mali-g71[0-9]|geforce|radeon|rtx|gtx/.test(
        gpuLower
      );
    const isFlagship = !isBudgetMobile && (isHighGpu || (!isMobile && cores >= 8) || (isIOS && cores >= 6));

    let recommendedTier: ConcreteGraphicsTier = 'medium';
    if (isBudgetMobile || isLowGpu || memoryGB <= 2) {
      recommendedTier = 'low';
    } else if (isFlagship || (!isMobile && memoryGB >= 6)) {
      recommendedTier = 'high';
    } else {
      recommendedTier = 'medium';
    }

    const summary = `${isAndroid ? 'Android' : isIOS ? 'Apple iOS' : 'Desktop'} • ${cores} Cores • ${
      memoryGB ? `${memoryGB}GB RAM` : 'Optimized'
    } • ${recommendedTier.toUpperCase()} Quality`;

    this.profile = {
      platform,
      isAndroid,
      isIOS,
      isMobile,
      cores,
      memoryGB,
      gpuRenderer,
      gpuVendor,
      recommendedTier,
      summary,
    };

    this.currentTier = recommendedTier;
    return this.profile;
  }

  public getProfile(): DeviceProfile {
    if (!this.profile) return this.detectDeviceProfile();
    return this.profile;
  }

  public setSetting(setting: GraphicsQualitySetting) {
    this.userSetting = setting;
    if (setting === 'auto') {
      this.currentTier = this.getProfile().recommendedTier;
    } else {
      this.currentTier = setting;
    }
  }

  public getSetting(): GraphicsQualitySetting {
    return this.userSetting;
  }

  public getActiveTier(): ConcreteGraphicsTier {
    return this.currentTier;
  }

  public getTierConfig(tier?: ConcreteGraphicsTier): GraphicsTierConfig {
    const active = tier || this.currentTier;
    const dpr = typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1;

    switch (active) {
      case 'low':
        return {
          tier: 'low',
          // Cap pixel ratio to 0.85-1.0 to relieve low-end fill-rate bottlenecks
          pixelRatio: Math.min(dpr, 1.0) * 0.9,
          shadows: false,
          shadowMapType: THREE.BasicShadowMap,
          shadowMapSize: 512,
          particlesCount: 35,
          fogDensity: 0.007,
          cameraFar: 220,
          visibleSegments: 4,
          antialias: false,
          description: 'Optimized for 60 FPS on budget Android & older devices',
        };
      case 'medium':
        return {
          tier: 'medium',
          pixelRatio: Math.min(dpr, 1.15),
          shadows: true,
          shadowMapType: THREE.BasicShadowMap,
          shadowMapSize: 512,
          particlesCount: 110,
          fogDensity: 0.0045,
          cameraFar: 320,
          visibleSegments: 5,
          antialias: true,
          description: 'Balanced performance & visual clarity for most devices',
        };
      case 'high':
      default:
        return {
          tier: 'high',
          pixelRatio: Math.min(dpr, 1.5),
          shadows: true,
          shadowMapType: THREE.PCFShadowMap,
          shadowMapSize: 1024,
          particlesCount: 240,
          fogDensity: 0.0035,
          cameraFar: 420,
          visibleSegments: 6,
          antialias: true,
          description: 'High-definition 3D with PCF shadows & morning sparkles',
        };
    }
  }

  /**
   * Records a frame delta time. If game is running on 'auto' and drops below 35 FPS
   * continuously, auto-adjusts to a lower tier to prevent stuttering.
   */
  public recordFrame(deltaTime: number): ConcreteGraphicsTier | null {
    if (this.userSetting !== 'auto') return null;

    this.frameTimes.push(deltaTime);
    if (this.frameTimes.length > 90) {
      this.frameTimes.shift();
    }

    const now = performance.now();
    if (now - this.lastFpsCheck > 3500 && this.frameTimes.length >= 60) {
      this.lastFpsCheck = now;
      const avgDelta = this.frameTimes.reduce((a, b) => a + b, 0) / this.frameTimes.length;
      const avgFps = 1 / Math.max(0.001, avgDelta);

      // If FPS is below 36 and not at lowest tier yet, degrade graphics for stability
      if (avgFps < 36 && this.currentTier !== 'low') {
        if (this.currentTier === 'high') {
          this.currentTier = 'medium';
        } else if (this.currentTier === 'medium') {
          this.currentTier = 'low';
        }
        this.isAutoDegraded = true;
        return this.currentTier;
      }
    }

    return null;
  }
}

export const deviceTierManager = new DeviceTierManager();
