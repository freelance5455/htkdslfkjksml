import {
  BattleReport,
  SpyReport,
  Territory,
  UnitType,
  Kingdom,
  Resources,
} from '../types/kingdom';
import {
  UNITS_CONFIG,
  CIVILIZATIONS,
  FORMATIONS_CONFIG,
  getHospitalCapacity,
  getTotalWoundedCount,
} from './gameConfig';

export function resolveBattle(
  kingdom: Kingdom,
  targetTerritory: Territory,
  attackerArmy: Partial<Record<UnitType, number>>
): BattleReport {
  const civ = CIVILIZATIONS[kingdom.civilization];
  const formation = FORMATIONS_CONFIG[kingdom.formation || 'balanced'];
  const eq = kingdom.equipment || {
    toledoSteel: 0,
    compositeArmor: 0,
    fireArrows: 0,
    reinforcedShields: 0,
    warhorseBarding: 0,
  };

  // 1. Calculate Attacker Power
  let rawAttackerPower = 0;
  let totalLootCapacity = 0;
  let totalAttackerCount = 0;

  Object.entries(attackerArmy).forEach(([unitKey, count]) => {
    if (!count || count <= 0) return;
    const unit = UNITS_CONFIG[unitKey as UnitType];
    if (unit) {
      let unitAtk = unit.attack;
      if (unit.category === 'infantry') {
        const toledoBonus = eq.toledoSteel * 0.08;
        unitAtk *= 1 + civ.bonuses.infantryBonus + formation.infantryBonus + toledoBonus;
      }
      if (unit.category === 'ranged') {
        const fireBonus = eq.fireArrows * 0.08;
        unitAtk *= 1 + civ.bonuses.archerBonus + formation.rangedBonus + fireBonus;
      }
      if (unit.category === 'cavalry') {
        const bardingBonus = eq.warhorseBarding * 0.10;
        unitAtk *= 1 + civ.bonuses.cavalryBonus + formation.cavalryBonus + bardingBonus;
      }
      if (unit.category === 'siege') {
        const siegeBonus = eq.fireArrows * 0.12;
        unitAtk *= 1 + siegeBonus;
      }
      rawAttackerPower += unitAtk * count;
      totalLootCapacity += unit.lootCapacity * count;
      totalAttackerCount += count;
    }
  });

  // Apply formation loot bonus
  totalLootCapacity = Math.round(totalLootCapacity * (1 + formation.lootBonus));

  // Strategy modifiers
  let strategyAtkMod = 1.0;
  if (kingdom.militaryStrategy === 'offensive') strategyAtkMod = 1.15;
  if (kingdom.militaryStrategy === 'defensive') strategyAtkMod = 0.85;
  if (kingdom.militaryStrategy === 'flank') strategyAtkMod = 1.1;

  // Add random tactics factor (between 0.9 and 1.15)
  const tacticsRoll = 0.9 + Math.random() * 0.25;
  const totalAttackerPower = rawAttackerPower * strategyAtkMod * tacticsRoll;

  // 2. Calculate Defender Power
  let rawDefenderPower = 0;
  let totalDefenderCount = 0;

  Object.entries(targetTerritory.garrison).forEach(([unitKey, count]) => {
    if (!count || count <= 0) return;
    const unit = UNITS_CONFIG[unitKey as UnitType];
    if (unit) {
      rawDefenderPower += unit.defense * count;
      totalDefenderCount += count;
    }
  });

  // Territory wall & fortification bonus
  const wallBonus = 1 + targetTerritory.defenseLevel * 0.12;
  const totalDefenderPower = rawDefenderPower * wallBonus;

  // 3. Determine Outcome
  const victory = totalAttackerPower > totalDefenderPower;

  // 4. Calculate Casualties, Wounded and Dead
  const attackerCasualties: Partial<Record<UnitType, number>> = {};
  const attackerDead: Partial<Record<UnitType, number>> = {};
  const attackerWounded: Partial<Record<UnitType, number>> = {};
  const defenderCasualties: Partial<Record<UnitType, number>> = {};

  const casualtyRatio = victory
    ? Math.min(0.65, totalDefenderPower / (totalAttackerPower * 2.2 + 1))
    : Math.min(0.90, 0.5 + totalDefenderPower / (totalAttackerPower + 1));

  const armorMitigation = Math.min(0.5, eq.compositeArmor * 0.05 + Math.max(-0.15, formation.defenseBonus * 0.5));
  const baseCasualtyRatio = Math.max(0.05, casualtyRatio * (1 - armorMitigation));

  const defenderCasualtyRatio = victory
    ? Math.min(1.0, 0.7 + Math.random() * 0.3)
    : Math.min(0.5, totalAttackerPower / (totalDefenderPower * 2 + 1));

  const hospitalLvl = kingdom.buildings?.hospital || 0;
  const maxHospitalCapacity = getHospitalCapacity(kingdom);
  const currentHospitalWounded = getTotalWoundedCount(kingdom.woundedArmy);
  let availableBeds = Math.max(0, maxHospitalCapacity - currentHospitalWounded);

  // Survival / recovery rate for fallen soldiers:
  // Base chance if hospital built: 15% + (hospitalLvl * 5%) + (medicinalHerbs * 4%)
  let woundedSurvivalRate = 0;
  if (hospitalLvl > 0) {
    woundedSurvivalRate = 0.15 + hospitalLvl * 0.05 + (kingdom.technologies?.medicinalHerbs || 0) * 0.04;
    woundedSurvivalRate = Math.min(0.70, woundedSurvivalRate);
  } else if ((kingdom.technologies?.medicinalHerbs || 0) > 0) {
    woundedSurvivalRate = (kingdom.technologies?.medicinalHerbs || 0) * 0.03;
    availableBeds = 12; // Field triage emergency limit without hospital
  }

  let totalSavedWounded = 0;
  let totalLostSoldiers = 0;

  Object.entries(attackerArmy).forEach(([unitKey, count]) => {
    if (!count || count <= 0) return;
    const unit = UNITS_CONFIG[unitKey as UnitType];
    let unitRatio = baseCasualtyRatio;
    if (unit?.category === 'ranged' && eq.reinforcedShields > 0) {
      unitRatio = Math.max(0.03, unitRatio * (1 - eq.reinforcedShields * 0.06));
    }
    const lost = Math.min(count, Math.round(count * unitRatio));
    if (lost > 0) {
      attackerCasualties[unitKey as UnitType] = lost;
      totalLostSoldiers += lost;

      // Determine how many survive as wounded vs dead
      let wounded = 0;
      if (woundedSurvivalRate > 0 && availableBeds > 0) {
        const potentialWounded = Math.max(0, Math.round(lost * woundedSurvivalRate));
        wounded = Math.min(availableBeds, potentialWounded);
        availableBeds -= wounded;
      }
      const dead = lost - wounded;
      if (wounded > 0) {
        attackerWounded[unitKey as UnitType] = wounded;
        totalSavedWounded += wounded;
      }
      if (dead > 0) {
        attackerDead[unitKey as UnitType] = dead;
      }
    }
  });

  Object.entries(targetTerritory.garrison).forEach(([unitKey, count]) => {
    if (!count || count <= 0) return;
    const lost = Math.min(count, Math.round(count * defenderCasualtyRatio));
    if (lost > 0) {
      defenderCasualties[unitKey as UnitType] = lost;
    }
  });

  // 5. Calculate Loot Captured
  const lootCaptured: Resources = { food: 0, wood: 0, stone: 0, gold: 0 };
  let gloryGained = 0;

  if (victory) {
    gloryGained = targetTerritory.gloryReward;
    let remainingCap = totalLootCapacity;
    const resTypes: (keyof Resources)[] = ['gold', 'food', 'stone', 'wood'];

    // Distribute loot up to available and capacity
    resTypes.forEach((res) => {
      if (remainingCap <= 0) return;
      const available = targetTerritory.loot[res];
      const take = Math.min(available, Math.floor(remainingCap / 4) + (remainingCap % 4));
      lootCaptured[res] = Math.min(available, take);
      remainingCap -= lootCaptured[res];
    });
  } else {
    gloryGained = Math.max(5, Math.floor(targetTerritory.gloryReward * 0.1));
  }

  let summary = victory
    ? `¡Gloriosa victoria en ${targetTerritory.name}! Tus tropas doblegaron las defensas enemigas con una formidable demostración de poder marcial.`
    : `Tus huestes fueron repelidas en las murallas de ${targetTerritory.name}. El general ordenó una retirada táctica tras sufrir severas bajas.`;

  if (totalSavedWounded > 0) {
    summary += ` Gracias a las cuadrillas sanitarias y boticarios, ${totalSavedWounded} soldados heridos fueron rescatados del campo y evacuados al Hospital de Campaña.`;
  } else if (totalLostSoldiers > 0 && hospitalLvl === 0) {
    summary += ` Al no disponer de Hospital de Campaña en el feudo, las bajas no pudieron recibir socorro médico y perecieron en el terreno.`;
  }

  return {
    id: 'bat_' + Date.now().toString(36),
    timestamp: Date.now(),
    targetTerritoryId: targetTerritory.id,
    targetName: targetTerritory.name,
    victory,
    attackerCasualties,
    attackerDead,
    attackerWounded,
    defenderCasualties,
    lootCaptured,
    gloryGained,
    summary,
  };
}

export function resolveEspionage(
  kingdom: Kingdom,
  targetTerritory: Territory
): SpyReport {
  const techBonus = (kingdom.technologies.espionageNetwork || 0) * 0.08;
  const baseSuccessChance = Math.min(0.95, Math.max(0.10, 0.70 + techBonus - targetTerritory.defenseLevel * 0.07));
  const roll = Math.random();
  const success = roll < baseSuccessChance;
  const detected = !success || Math.random() < 0.25;

  if (success) {
    return {
      id: 'spy_' + Date.now().toString(36),
      timestamp: Date.now(),
      targetTerritoryId: targetTerritory.id,
      targetName: targetTerritory.name,
      success: true,
      detected,
      enemyGarrison: { ...targetTerritory.garrison },
      enemyResources: { ...targetTerritory.loot },
      wallLevel: targetTerritory.defenseLevel,
      summary: `Misión cumplida en secreto. El emisario infiltrado trazó los planos de la guarnición y contó las provisiones en las bodegas enemigas.`,
    };
  } else {
    return {
      id: 'spy_' + Date.now().toString(36),
      timestamp: Date.now(),
      targetTerritoryId: targetTerritory.id,
      targetName: targetTerritory.name,
      success: false,
      detected: true,
      summary: `El espía fue descubierto por las patrullas caninas en los fosos exteriores y tuvo que arrojar los mapas al fuego antes de huir.`,
    };
  }
}
