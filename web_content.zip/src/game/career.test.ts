import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createInitialState,
  getCurrentCareerPosition,
  getNextCareerPosition,
  checkPromotionEligibility,
  requestPromotion,
  switchCareerTrack,
  executeCareerShift
} from './engine';

test('initial career state starts at Tier 1 of commerce track', () => {
  const state = createInitialState('محمد', 'أروى');
  assert.equal(state.currentCareerTrack, 'commerce');
  assert.equal(state.currentCareerTier, 1);

  const pos = getCurrentCareerPosition(state);
  assert.equal(pos.tier, 1);
  assert.equal(pos.title, 'بائع ومسؤول واجهة متجر');
  assert.equal(pos.basePay, 170);
});

test('checkPromotionEligibility identifies missing requirements correctly', () => {
  const state = createInitialState('محمد', 'أروى');
  const check = checkPromotionEligibility(state);
  assert.equal(check.eligible, false);
  assert.ok(check.reasonsMissing.length >= 2, 'Should list missing days and missing skill');
});

test('requestPromotion succeeds when requirements are met and increases tier and salary', () => {
  let state = createInitialState('محمد', 'أروى');
  // Meet Tier 2 requirements: 6 days, 14 skill
  state.careerDaysWorked.commerce = 6;
  state.skill = 15;

  const check = checkPromotionEligibility(state);
  assert.equal(check.eligible, true);
  assert.equal(check.nextPos?.tier, 2);

  const res = requestPromotion(state);
  assert.equal(res.success, true);
  assert.equal(res.state.currentCareerTier, 2);
  assert.equal(res.state.job, 'مسؤول مبيعات أول وكاشير معتمد');

  const newPos = getCurrentCareerPosition(res.state);
  assert.equal(newPos.basePay, 310);
  assert.equal(res.state.promotionsCount, 1);
});

test('executeCareerShift increases days worked in track and pays correctly', () => {
  let state = createInitialState('محمد', 'أروى');
  state.energy = 100;
  state.hunger = 80;
  const initialMoney = state.money;

  const shiftRes = executeCareerShift(state);
  assert.equal(shiftRes.success, true);
  assert.equal(shiftRes.state.careerDaysWorked.commerce, 1);
  assert.ok(shiftRes.state.money > initialMoney);
});

test('switchCareerTrack successfully changes track if entry requirements met', () => {
  let state = createInitialState('محمد', 'أروى');
  state.skill = 35;
  state.assets.push('laptop');

  const switchRes = switchCareerTrack(state, 'tech');
  assert.equal(switchRes.success, true);
  assert.equal(switchRes.state.currentCareerTrack, 'tech');
  assert.equal(switchRes.state.currentCareerTier, 1);
  assert.equal(switchRes.state.job, 'مبرمج مبتدئ ومطور واجهات (Junior Dev)');
});
