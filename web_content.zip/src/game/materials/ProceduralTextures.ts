import * as THREE from 'three';

function createCanvas(size = 512): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  return [canvas, ctx];
}

function finalizeTexture(canvas: HTMLCanvasElement, repeat = 1, maxAnisotropy = 4, srgb = true): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.anisotropy = maxAnisotropy;
  tex.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export interface ProceduralTextureSet {
  terrainDetail: THREE.CanvasTexture;
  terrainBump: THREE.CanvasTexture;
  stoneTex: THREE.CanvasTexture;
  stoneBump: THREE.CanvasTexture;
  woodTex: THREE.CanvasTexture;
  barkTex: THREE.CanvasTexture;
  waterTex: THREE.CanvasTexture;
  lavaTex: THREE.CanvasTexture;
  dungeonTileTex: THREE.CanvasTexture;
  sandTex: THREE.CanvasTexture;
  obsidianTex: THREE.CanvasTexture;
  contactShadowTex: THREE.CanvasTexture;
}

export function buildProceduralTextures(maxAnisotropy: number): ProceduralTextureSet {
  // 1. High-resolution Terrain micro-detail + matching bump map
  const [tCanvas, tCtx] = createCanvas(512);
  const [tbCanvas, tbCtx] = createCanvas(512);
  tCtx.fillStyle = '#dcdcdc';
  tCtx.fillRect(0, 0, 512, 512);
  tbCtx.fillStyle = '#808080';
  tbCtx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 6500; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const w = 2 + Math.random() * 6;
    const h = 2 + Math.random() * 6;
    const v = 180 + Math.floor(Math.random() * 72);
    tCtx.fillStyle = `rgb(${v},${v},${v})`;
    tCtx.fillRect(x, y, w, h);

    const b = 90 + Math.floor(Math.random() * 120);
    tbCtx.fillStyle = `rgb(${b},${b},${b})`;
    tbCtx.fillRect(x, y, w, h);
  }
  const terrainDetail = finalizeTexture(tCanvas, 72, maxAnisotropy, true);
  const terrainBump = finalizeTexture(tbCanvas, 72, maxAnisotropy, false);

  // 2. Dressed Castle Stone Masonry + mortar bump map
  const [sCanvas, sCtx] = createCanvas(512);
  const [sbCanvas, sbCtx] = createCanvas(512);
  sCtx.fillStyle = '#334155';
  sCtx.fillRect(0, 0, 512, 512);
  sbCtx.fillStyle = '#252525';
  sbCtx.fillRect(0, 0, 512, 512);
  for (let row = 0; row < 16; row++) {
    const y = row * 32;
    const offset = (row % 2) * 48;
    for (let col = -1; col < 7; col++) {
      const x = col * 96 + offset;
      const shade = 92 + Math.floor(Math.random() * 44);
      sCtx.fillStyle = `rgb(${shade},${shade + 5},${shade + 12})`;
      sCtx.fillRect(x + 2, y + 2, 92, 28);
      sCtx.fillStyle = 'rgba(255,255,255,0.06)';
      sCtx.fillRect(x + 4, y + 4, 88, 5);

      const bShade = 165 + Math.floor(Math.random() * 65);
      sbCtx.fillStyle = `rgb(${bShade},${bShade},${bShade})`;
      sbCtx.fillRect(x + 3, y + 3, 90, 26);
    }
  }
  const stoneTex = finalizeTexture(sCanvas, 3, maxAnisotropy, true);
  const stoneBump = finalizeTexture(sbCanvas, 3, maxAnisotropy, false);

  // 3. Detailed Timber Planks with wood grain
  const [wCanvas, wCtx] = createCanvas(512);
  wCtx.fillStyle = '#78350f';
  wCtx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 16; i++) {
    const y = i * 32;
    const shade = 104 + Math.floor(Math.random() * 34);
    wCtx.fillStyle = `rgb(${shade}, ${Math.floor(shade * 0.54)}, ${Math.floor(shade * 0.22)})`;
    wCtx.fillRect(0, y + 2, 512, 28);
    for (let g = 0; g < 6; g++) {
      wCtx.fillStyle = 'rgba(0,0,0,0.09)';
      wCtx.fillRect(0, y + 4 + g * 4, 512, 1.5);
    }
    wCtx.fillStyle = 'rgba(0,0,0,0.28)';
    wCtx.fillRect(0, y + 30, 512, 2);
  }
  const woodTex = finalizeTexture(wCanvas, 2, maxAnisotropy, true);

  // 4. Bark texture
  const [bCanvas, bCtx] = createCanvas(256);
  bCtx.fillStyle = '#451a03';
  bCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 320; i++) {
    const x = Math.random() * 256;
    const w = 2 + Math.random() * 6;
    bCtx.fillStyle = i % 2 === 0 ? '#2e1002' : '#652a08';
    bCtx.fillRect(x, 0, w, 256);
  }
  const barkTex = finalizeTexture(bCanvas, 2, maxAnisotropy, true);

  // 5. Water ripple & caustic highlights texture
  const [waCanvas, waCtx] = createCanvas(512);
  waCtx.fillStyle = '#1f7fb3';
  waCtx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 240; i++) {
    waCtx.strokeStyle = i % 3 === 0 ? 'rgba(224, 242, 254, 0.42)' : 'rgba(125, 211, 252, 0.28)';
    waCtx.lineWidth = 2;
    waCtx.beginPath();
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    waCtx.arc(x, y, 8 + Math.random() * 28, 0, Math.PI * 1.45);
    waCtx.stroke();
  }
  const waterTex = finalizeTexture(waCanvas, 22, maxAnisotropy, true);

  // 6. Molten Lava crust & glowing cracks
  const [lCanvas, lCtx] = createCanvas(512);
  lCtx.fillStyle = '#dc2626';
  lCtx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 160; i++) {
    lCtx.fillStyle = i % 4 === 0 ? '#fef08a' : i % 4 === 1 ? '#f97316' : i % 4 === 2 ? '#b91c1c' : '#291212';
    lCtx.beginPath();
    lCtx.arc(Math.random() * 512, Math.random() * 512, 8 + Math.random() * 28, 0, Math.PI * 2);
    lCtx.fill();
  }
  const lavaTex = finalizeTexture(lCanvas, 8, maxAnisotropy, true);

  // 7. Ancient Dungeon / Crypt Stone Tile Floor
  const [dCanvas, dCtx] = createCanvas(512);
  dCtx.fillStyle = '#1e2430';
  dCtx.fillRect(0, 0, 512, 512);
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const s = 44 + Math.floor(Math.random() * 24);
      dCtx.fillStyle = `rgb(${s},${s + 4},${s + 12})`;
      dCtx.fillRect(c * 64 + 3, r * 64 + 3, 58, 58);
      dCtx.strokeStyle = 'rgba(148,163,184,0.12)';
      dCtx.strokeRect(c * 64 + 8, r * 64 + 8, 48, 48);
    }
  }
  const dungeonTileTex = finalizeTexture(dCanvas, 4, maxAnisotropy, true);

  // 8. Sandstone / Desert Block Texture
  const [saCanvas, saCtx] = createCanvas(512);
  saCtx.fillStyle = '#c89b54';
  saCtx.fillRect(0, 0, 512, 512);
  for (let row = 0; row < 12; row++) {
    const y = row * 42;
    const offset = (row % 2) * 42;
    for (let col = -1; col < 7; col++) {
      const x = col * 85 + offset;
      const v = 180 + Math.floor(Math.random() * 34);
      saCtx.fillStyle = `rgb(${v},${Math.floor(v * 0.78)},${Math.floor(v * 0.45)})`;
      saCtx.fillRect(x + 2, y + 2, 81, 38);
    }
  }
  const sandTex = finalizeTexture(saCanvas, 3, maxAnisotropy, true);

  // 9. Hell Obsidian Volcanic Brick Texture
  const [obCanvas, obCtx] = createCanvas(512);
  obCtx.fillStyle = '#140c10';
  obCtx.fillRect(0, 0, 512, 512);
  for (let row = 0; row < 12; row++) {
    const y = row * 42;
    const offset = (row % 2) * 42;
    for (let col = -1; col < 7; col++) {
      const x = col * 85 + offset;
      const v = 26 + Math.floor(Math.random() * 22);
      obCtx.fillStyle = `rgb(${v + 12},${v},${v + 8})`;
      obCtx.fillRect(x + 2, y + 2, 81, 38);
    }
  }
  for (let i = 0; i < 24; i++) {
    obCtx.strokeStyle = 'rgba(249, 115, 22, 0.35)';
    obCtx.lineWidth = 2;
    obCtx.beginPath();
    const rx = Math.random() * 512;
    const ry = Math.random() * 512;
    obCtx.moveTo(rx, ry);
    obCtx.lineTo(rx + (Math.random() - 0.5) * 44, ry + (Math.random() - 0.5) * 44);
    obCtx.stroke();
  }
  const obsidianTex = finalizeTexture(obCanvas, 3, maxAnisotropy, true);

  // 10. Radial Contact Shadow
  const [cCanvas, cCtx] = createCanvas(128);
  const grad = cCtx.createRadialGradient(64, 64, 4, 64, 64, 60);
  grad.addColorStop(0, 'rgba(0,0,0,0.68)');
  grad.addColorStop(0.55, 'rgba(0,0,0,0.30)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  cCtx.fillStyle = grad;
  cCtx.fillRect(0, 0, 128, 128);
  const contactShadowTex = new THREE.CanvasTexture(cCanvas);

  return {
    terrainDetail,
    terrainBump,
    stoneTex,
    stoneBump,
    woodTex,
    barkTex,
    waterTex,
    lavaTex,
    dungeonTileTex,
    sandTex,
    obsidianTex,
    contactShadowTex,
  };
}
