/**
 * Game Time & Feudal Calendar System
 * Manages game time ticks, countdowns, offline production calculations,
 * and battle execution schedules for La Conquista Medieval.
 */

export interface ResourceProductionRates {
  foodPerHour: number;
  woodPerHour: number;
  stonePerHour: number;
  goldPerHour: number;
}

export interface StorageCapacities {
  foodMax: number;
  resourcesMax: number;
}

export interface OfflineGainsReport {
  elapsedSeconds: number;
  foodGained: number;
  woodGained: number;
  stoneGained: number;
  goldGained: number;
  foodCapped: boolean;
  resourcesCapped: boolean;
}

/**
 * Formats a duration in seconds into a readable string (e.g. "01h 24m 12s", "03m 45s", or "12s")
 */
export function formatDuration(seconds: number): string {
  if (seconds <= 0) return '0s';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  if (h > 0) {
    return `${h}h ${m.toString().padStart(2, '0')}m ${s.toString().padStart(2, '0')}s`;
  }
  if (m > 0) {
    return `${m}m ${s.toString().padStart(2, '0')}s`;
  }
  return `${s}s`;
}

/**
 * Formats remaining time until a specific target timestamp in milliseconds
 */
export function formatRemainingTime(targetTimestampMs: number): string {
  const remainingMs = targetTimestampMs - Date.now();
  if (remainingMs <= 0) return 'Completado';
  const totalSeconds = Math.ceil(remainingMs / 1000);
  return formatDuration(totalSeconds);
}

/**
 * Checks whether a given timestamp has already passed
 */
export function isTimestampPassed(targetTimestampMs: number): boolean {
  return Date.now() >= targetTimestampMs;
}

/**
 * Calculates remaining seconds until target timestamp
 */
export function getRemainingSeconds(targetTimestampMs: number): number {
  return Math.max(0, Math.ceil((targetTimestampMs - Date.now()) / 1000));
}

/**
 * Calculates offline resource gains when returning to the game
 */
export function calculateOfflineGains(
  lastUpdatedMs: number,
  currentResources: { food: number; wood: number; stone: number; gold: number },
  rates: ResourceProductionRates,
  capacities: StorageCapacities,
  maxOfflineHours: number = 24
): OfflineGainsReport {
  const now = Date.now();
  const rawElapsedMs = Math.max(0, now - lastUpdatedMs);
  const cappedElapsedMs = Math.min(rawElapsedMs, maxOfflineHours * 3600 * 1000);
  const elapsedSeconds = cappedElapsedMs / 1000;
  const elapsedHours = elapsedSeconds / 3600;

  const rawFood = rates.foodPerHour * elapsedHours;
  const rawWood = rates.woodPerHour * elapsedHours;
  const rawStone = rates.stonePerHour * elapsedHours;
  const rawGold = rates.goldPerHour * elapsedHours;

  const newFood = Math.min(capacities.foodMax, currentResources.food + rawFood);
  const newWood = Math.min(capacities.resourcesMax, currentResources.wood + rawWood);
  const newStone = Math.min(capacities.resourcesMax, currentResources.stone + rawStone);
  const newGold = Math.min(capacities.resourcesMax, currentResources.gold + rawGold);

  return {
    elapsedSeconds: Math.round(elapsedSeconds),
    foodGained: Math.round(Math.max(0, newFood - currentResources.food)),
    woodGained: Math.round(Math.max(0, newWood - currentResources.wood)),
    stoneGained: Math.round(Math.max(0, newStone - currentResources.stone)),
    goldGained: Math.round(Math.max(0, newGold - currentResources.gold)),
    foodCapped: newFood >= capacities.foodMax,
    resourcesCapped: newWood >= capacities.resourcesMax || newStone >= capacities.resourcesMax,
  };
}

/**
 * Returns the current feudal epoch label
 */
export function getFeudalCalendarDate(nowMs: number = Date.now()): {
  year: number;
  season: 'Primavera' | 'Verano' | 'Otoño' | 'Invierno';
  label: string;
} {
  const date = new Date(nowMs);
  const month = date.getMonth(); // 0-11
  let season: 'Primavera' | 'Verano' | 'Otoño' | 'Invierno' = 'Primavera';

  if (month >= 2 && month <= 4) season = 'Primavera';
  else if (month >= 5 && month <= 7) season = 'Verano';
  else if (month >= 8 && month <= 10) season = 'Otoño';
  else season = 'Invierno';

  // Game year anchor (1085 AD + years since launch reference)
  const baseYear = 1085;
  const launchYear = 2026;
  const currentYear = date.getFullYear();
  const feudalYear = baseYear + Math.max(0, currentYear - launchYear);

  return {
    year: feudalYear,
    season,
    label: `Año Feudal ${feudalYear} • ${season}`,
  };
}

/**
 * Validates if a scheduled PvP battle is ready for immediate military resolution
 */
export function isBattleReadyForResolution(scheduledTimeMs: number): boolean {
  return Date.now() >= scheduledTimeMs;
}
