import * as THREE from 'three';

// Seeded random for consistent textures
export function seededRandom(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function makeCanvas(w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  return { c, ctx };
}

function toTexture(c: HTMLCanvasElement, repeatX = 1, repeatY = 1): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = THREE.RepeatWrapping;
  t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeatX, repeatY);
  t.anisotropy = 8;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** Lightweight equirectangular environment map for realistic car & glass reflections */
export function envReflectionTexture(): THREE.CanvasTexture {
  const W = 256;
  const H = 128;
  const { c, ctx } = makeCanvas(W, H);
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, '#1e5bb8');
  g.addColorStop(0.32, '#5a9be6');
  g.addColorStop(0.48, '#dbeafe');
  g.addColorStop(0.5, '#f5ebd6');
  g.addColorStop(0.54, '#7c8578');
  g.addColorStop(0.75, '#4b5548');
  g.addColorStop(1, '#2b302c');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);

  // sun highlight in upper hemisphere
  const sg = ctx.createRadialGradient(W * 0.68, H * 0.24, 2, W * 0.68, H * 0.24, 38);
  sg.addColorStop(0, 'rgba(255,252,235,1)');
  sg.addColorStop(0.3, 'rgba(255,235,180,0.65)');
  sg.addColorStop(1, 'rgba(255,235,180,0)');
  ctx.fillStyle = sg;
  ctx.fillRect(0, 0, W, H);

  // soft horizon clouds
  ctx.fillStyle = 'rgba(255,255,255,0.28)';
  for (let i = 0; i < 10; i++) {
    ctx.beginPath();
    ctx.ellipse((i + 0.5) * (W / 10), H * 0.42, 18, 5, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  const t = new THREE.CanvasTexture(c);
  t.mapping = THREE.EquirectangularReflectionMapping;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function noiseOver(ctx: CanvasRenderingContext2D, w: number, h: number, rand: () => number, alpha: number, size = 2) {
  for (let i = 0; i < (w * h) / 90; i++) {
    const x = rand() * w;
    const y = rand() * h;
    const v = Math.floor(rand() * 60) - 30;
    ctx.fillStyle = `rgba(${v > 0 ? '255,255,255' : '0,0,0'},${alpha * rand()})`;
    ctx.fillRect(x, y, size * (0.5 + rand()), size * (0.5 + rand()));
  }
}

/** High quality building facade with windows, frames, balconies */
export function buildingFacadeTexture(opts: {
  baseColor: string;
  trimColor: string;
  glassColor1: string;
  glassColor2: string;
  floors: number;
  cols: number;
  seed: number;
  style: number; // 0 modern glass, 1 concrete, 2 brick, 3 luxury
}): THREE.CanvasTexture {
  const { baseColor, trimColor, glassColor1, glassColor2, floors, cols, seed, style } = opts;
  const W = 384;
  const H = 384;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(seed);

  // base with architectural gradient
  const grad = ctx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, shadeColor(baseColor, 8));
  grad.addColorStop(0.5, baseColor);
  grad.addColorStop(1, shadeColor(baseColor, -20));
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, H);

  // subtle concrete/stone grain
  noiseOver(ctx, W, H, rand, 0.09, 2);

  if (style === 2) {
    // brick courses + vertical joints
    ctx.strokeStyle = 'rgba(0,0,0,0.14)';
    ctx.lineWidth = 1;
    for (let y = 0; y < H; y += 6) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(W, y);
      ctx.stroke();
    }
  }

  const floorH = H / floors;
  const colW = W / cols;

  // vertical pilasters between columns
  for (let col = 0; col <= cols; col++) {
    const px = col * colW;
    ctx.fillStyle = 'rgba(0,0,0,0.14)';
    ctx.fillRect(px - 2, 0, 2, H);
    ctx.fillStyle = 'rgba(255,255,255,0.08)';
    ctx.fillRect(px, 0, 1.5, H);
  }

  for (let f = 0; f < floors; f++) {
    const y = f * floorH;
    // floor slab cornice + shadow
    ctx.fillStyle = 'rgba(0,0,0,0.28)';
    ctx.fillRect(0, y + floorH - 3, W, 3);
    ctx.fillStyle = 'rgba(255,255,255,0.16)';
    ctx.fillRect(0, y, W, 1.5);

    for (let col = 0; col < cols; col++) {
      const x = col * colW;
      const lit = rand();
      const wx = x + colW * 0.16;
      const wy = y + floorH * 0.18;
      const ww = colW * 0.68;
      const wh = floorH * 0.62;

      // recessed window shadow
      ctx.fillStyle = 'rgba(0,0,0,0.4)';
      ctx.fillRect(wx - 3, wy - 3, ww + 6, wh + 6);

      // window frame
      ctx.fillStyle = trimColor;
      ctx.fillRect(wx - 2, wy - 2, ww + 4, wh + 4);

      // glass with sky/interior gradient
      const g = ctx.createLinearGradient(wx, wy, wx + ww, wy + wh);
      if (style === 0) {
        g.addColorStop(0, glassColor1);
        g.addColorStop(0.45, glassColor2);
        g.addColorStop(1, shadeColor(glassColor1, -34));
      } else if (lit > 0.8) {
        g.addColorStop(0, '#fff1c2');
        g.addColorStop(1, '#d69e3a');
      } else {
        g.addColorStop(0, glassColor1);
        g.addColorStop(1, glassColor2);
      }
      ctx.fillStyle = g;
      ctx.fillRect(wx, wy, ww, wh);

      // interior blinds / horizon band inside window
      if (rand() > 0.45) {
        ctx.fillStyle = 'rgba(255,255,255,0.12)';
        ctx.fillRect(wx + 1, wy + 1, ww - 2, wh * (0.2 + rand() * 0.25));
      }

      // crisp glass reflection diagonal
      ctx.fillStyle = 'rgba(255,255,255,0.26)';
      ctx.beginPath();
      ctx.moveTo(wx, wy + wh);
      ctx.lineTo(wx + ww * 0.36, wy);
      ctx.lineTo(wx + ww * 0.54, wy);
      ctx.lineTo(wx + ww * 0.18, wy + wh);
      ctx.closePath();
      ctx.fill();

      // mullions
      ctx.fillStyle = 'rgba(18,22,32,0.88)';
      ctx.fillRect(wx + ww / 2 - 1, wy, 2, wh);
      if (style !== 0) ctx.fillRect(wx, wy + wh / 2 - 1, ww, 2);

      // window sill
      ctx.fillStyle = 'rgba(255,255,255,0.22)';
      ctx.fillRect(wx - 3, wy + wh + 1, ww + 6, 2);

      // balcony for luxury style on some floors
      if (style === 3 && f % 2 === 0 && rand() > 0.35) {
        ctx.fillStyle = 'rgba(15,20,30,0.6)';
        ctx.fillRect(wx - 4, wy + wh + 2, ww + 8, 6);
        ctx.fillStyle = 'rgba(210,225,240,0.42)';
        for (let b = 0; b < 6; b++) ctx.fillRect(wx - 3 + b * (ww / 5), wy + wh + 2, 1.5, 6);
      }

      // AC unit sometimes
      if (style === 1 && rand() > 0.84) {
        ctx.fillStyle = '#cbd5e1';
        ctx.fillRect(wx + ww * 0.1, wy + wh - 7, 12, 6);
        ctx.fillStyle = 'rgba(0,0,0,0.35)';
        ctx.fillRect(wx + ww * 0.1, wy + wh - 7, 12, 1.5);
      }
    }
  }

  // ground floor storefront / lobby band
  ctx.fillStyle = 'rgba(10,12,18,0.88)';
  ctx.fillRect(0, H - floorH * 0.9, W, floorH * 0.9);
  ctx.fillStyle = 'rgba(155,195,235,0.55)';
  for (let col = 0; col < cols; col++) {
    ctx.fillRect(col * colW + 5, H - floorH * 0.76, colW - 10, floorH * 0.58);
  }

  return toTexture(c);
}

function shadeColor(hex: string, amt: number): string {
  const n = hex.replace('#', '');
  const num = parseInt(n.length === 3 ? n.split('').map((c) => c + c).join('') : n, 16);
  let r = (num >> 16) + amt;
  let g = ((num >> 8) & 0xff) + amt;
  let b = (num & 0xff) + amt;
  r = Math.max(0, Math.min(255, r));
  g = Math.max(0, Math.min(255, g));
  b = Math.max(0, Math.min(255, b));
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
}

/** Asphalt road with lane markings. lanes = total lanes. */
export function roadTexture(lanes: number, seed = 1, dashedCenter = true): THREE.CanvasTexture {
  const W = 512;
  const H = 512;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(seed * 7919 + lanes * 131);

  // asphalt base
  const g = ctx.createLinearGradient(0, 0, W, 0);
  g.addColorStop(0, '#2c2f36');
  g.addColorStop(0.15, '#353941');
  g.addColorStop(0.5, '#3e424b');
  g.addColorStop(0.85, '#353941');
  g.addColorStop(1, '#2c2f36');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);

  // fine asphalt aggregate grain
  noiseOver(ctx, W, H, rand, 0.16, 2);

  // subtle shoulder curb strip
  ctx.fillStyle = 'rgba(180,185,192,0.32)';
  ctx.fillRect(0, 0, 6, H);
  ctx.fillRect(W - 6, 0, 6, H);

  // tire wear darker bands per lane
  const laneW = W / lanes;
  for (let i = 0; i < lanes; i++) {
    const cx = i * laneW + laneW / 2;
    const wg = ctx.createLinearGradient(cx - laneW / 2, 0, cx + laneW / 2, 0);
    wg.addColorStop(0, 'rgba(0,0,0,0)');
    wg.addColorStop(0.28, 'rgba(0,0,0,0.24)');
    wg.addColorStop(0.5, 'rgba(255,255,255,0.03)');
    wg.addColorStop(0.72, 'rgba(0,0,0,0.24)');
    wg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = wg;
    ctx.fillRect(i * laneW, 0, laneW, H);
  }

  // edge lines solid white
  ctx.fillStyle = '#ededdf';
  ctx.fillRect(10, 0, 6, H);
  ctx.fillRect(W - 16, 0, 6, H);

  // lane dividers
  for (let i = 1; i < lanes; i++) {
    const x = i * laneW;
    if (i === lanes / 2 && lanes % 2 === 0) {
      // double yellow center with cat-eye reflectors
      ctx.fillStyle = '#e6b422';
      ctx.fillRect(x - 7, 0, 5, H);
      ctx.fillRect(x + 2, 0, 5, H);
      ctx.fillStyle = '#fff6b0';
      for (let y = 16; y < H; y += 64) {
        ctx.fillRect(x - 1.5, y, 3, 6);
      }
    } else if (dashedCenter) {
      ctx.fillStyle = 'rgba(242,242,235,0.92)';
      for (let y = 0; y < H; y += 64) ctx.fillRect(x - 3, y, 6, 36);
    } else {
      ctx.fillStyle = 'rgba(242,242,235,0.88)';
      ctx.fillRect(x - 3, 0, 6, H);
    }
  }

  // cracks & tar seams
  ctx.strokeStyle = 'rgba(15,17,22,0.32)';
  ctx.lineWidth = 1.4;
  for (let i = 0; i < 6; i++) {
    ctx.beginPath();
    let x = rand() * W;
    let y = rand() * H;
    ctx.moveTo(x, y);
    for (let s = 0; s < 6; s++) {
      x += (rand() - 0.5) * 42;
      y += (rand() - 0.5) * 42;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }

  const t = toTexture(c);
  return t;
}

export function dirtRoadTexture(seed = 5): THREE.CanvasTexture {
  const W = 384;
  const H = 384;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(seed * 331 + 7);
  const g = ctx.createLinearGradient(0, 0, W, 0);
  g.addColorStop(0, '#70583f');
  g.addColorStop(0.22, '#8b7150');
  g.addColorStop(0.5, '#997e5b');
  g.addColorStop(0.78, '#8b7150');
  g.addColorStop(1, '#70583f');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  noiseOver(ctx, W, H, rand, 0.22, 3);
  // tire ruts + tread marks
  ctx.fillStyle = 'rgba(55,40,26,0.38)';
  ctx.fillRect(W * 0.22, 0, W * 0.13, H);
  ctx.fillRect(W * 0.65, 0, W * 0.13, H);
  ctx.fillStyle = 'rgba(255,242,215,0.14)';
  ctx.fillRect(W * 0.43, 0, W * 0.14, H);
  // pebbles & gravel
  for (let i = 0; i < 200; i++) {
    ctx.fillStyle = `rgba(${175 + rand() * 45},${155 + rand() * 35},${125 + rand() * 25},${0.5 + rand() * 0.5})`;
    const s = 1 + rand() * 3;
    ctx.beginPath();
    ctx.arc(rand() * W, rand() * H, s, 0, Math.PI * 2);
    ctx.fill();
  }
  return toTexture(c);
}

export function sandTexture(): THREE.CanvasTexture {
  const W = 384;
  const H = 384;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(1234);
  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, '#e6cb94');
  g.addColorStop(0.5, '#e0c28b');
  g.addColorStop(1, '#d9b77e');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  for (let i = 0; i < 8000; i++) {
    const v = rand();
    ctx.fillStyle = v > 0.5 ? `rgba(255,248,225,${0.26 * rand()})` : `rgba(120,90,50,${0.22 * rand()})`;
    ctx.fillRect(rand() * W, rand() * H, 1.5, 1.5);
  }
  // wind ripples
  ctx.strokeStyle = 'rgba(155,125,80,0.2)';
  ctx.lineWidth = 2;
  for (let y = 0; y < H; y += 18) {
    ctx.beginPath();
    for (let x = 0; x <= W; x += 8) ctx.lineTo(x, y + Math.sin((x / W) * Math.PI * 4 + y) * 3.2);
    ctx.stroke();
  }
  const t = toTexture(c, 40, 12);
  return t;
}

export function grassTexture(): THREE.CanvasTexture {
  const W = 384;
  const H = 384;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(99);
  ctx.fillStyle = '#5a8d3c';
  ctx.fillRect(0, 0, W, H);
  for (let i = 0; i < 9000; i++) {
    const greens = ['#4c7b31', '#689b46', '#538338', '#76a850', '#456d2c', '#629445'];
    ctx.fillStyle = greens[Math.floor(rand() * greens.length)];
    ctx.globalAlpha = 0.55 + rand() * 0.45;
    const x = rand() * W;
    const y = rand() * H;
    ctx.fillRect(x, y, 1.6, 2.8 + rand() * 2.5);
  }
  ctx.globalAlpha = 1;
  const t = toTexture(c, 60, 60);
  return t;
}

export function rockTexture(): THREE.CanvasTexture {
  const W = 384;
  const H = 384;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(555);
  ctx.fillStyle = '#6b6f75';
  ctx.fillRect(0, 0, W, H);
  for (let i = 0; i < 1200; i++) {
    const shade = 68 + rand() * 75;
    ctx.fillStyle = `rgb(${shade},${shade + 2},${shade + 6})`;
    ctx.globalAlpha = 0.35 + rand() * 0.42;
    ctx.beginPath();
    ctx.moveTo(rand() * W, rand() * H);
    ctx.lineTo(rand() * W, rand() * H);
    ctx.lineTo(rand() * W, rand() * H);
    ctx.closePath();
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  // strata lines
  ctx.strokeStyle = 'rgba(28,30,35,0.38)';
  for (let i = 0; i < 16; i++) {
    ctx.lineWidth = 1 + rand() * 2.2;
    ctx.beginPath();
    const y = rand() * H;
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(W * 0.3, y + (rand() - 0.5) * 36, W * 0.7, y + (rand() - 0.5) * 36, W, y + (rand() - 0.5) * 24);
    ctx.stroke();
  }
  noiseOver(ctx, W, H, rand, 0.14, 2);
  const t = toTexture(c, 8, 8);
  return t;
}

export function houseWallTexture(base: string, seed: number): THREE.CanvasTexture {
  const W = 256;
  const H = 256;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(seed);
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, W, H);
  noiseOver(ctx, W, H, rand, 0.11, 2);
  // plaster strokes
  ctx.strokeStyle = 'rgba(255,255,255,0.09)';
  for (let i = 0; i < 45; i++) {
    ctx.beginPath();
    ctx.moveTo(rand() * W, rand() * H);
    ctx.lineTo(rand() * W, rand() * H);
    ctx.stroke();
  }
  // stone/brick plinth bottom
  ctx.fillStyle = 'rgba(118,78,58,0.55)';
  ctx.fillRect(0, H - 28, W, 28);
  ctx.fillStyle = 'rgba(0,0,0,0.22)';
  for (let x = 0; x < W; x += 20) ctx.fillRect(x, H - 28, 2, 28);
  return toTexture(c);
}

export function roofTexture(color: string, seed: number): THREE.CanvasTexture {
  const W = 256;
  const H = 256;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(seed);
  ctx.fillStyle = shadeColor(color, -22);
  ctx.fillRect(0, 0, W, H);
  const rows = 12;
  const rh = H / rows;
  for (let r = 0; r < rows; r++) {
    for (let x = 0; x < W; x += 20) {
      const off = r % 2 === 0 ? 0 : 10;
      ctx.fillStyle = r % 2 === 0 ? color : shadeColor(color, -12);
      ctx.fillRect(x + off, r * rh, 18, rh - 1.5);
      ctx.fillStyle = 'rgba(255,255,255,0.18)';
      ctx.fillRect(x + off, r * rh, 18, 2.5);
      ctx.fillStyle = 'rgba(0,0,0,0.32)';
      ctx.fillRect(x + off, r * rh + rh - 2.5, 18, 1.5);
    }
  }
  noiseOver(ctx, W, H, rand, 0.08, 2);
  return toTexture(c);
}

export function cloudTexture(): THREE.CanvasTexture {
  const W = 256;
  const H = 128;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(42);
  ctx.clearRect(0, 0, W, H);
  for (let i = 0; i < 46; i++) {
    const x = W * 0.2 + rand() * W * 0.6;
    const y = H * 0.35 + rand() * H * 0.35;
    const r = 14 + rand() * 26;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, 'rgba(255,255,255,0.85)');
    g.addColorStop(0.6, 'rgba(255,255,255,0.45)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  // bottom shade
  const lg = ctx.createLinearGradient(0, H * 0.55, 0, H);
  lg.addColorStop(0, 'rgba(160,180,205,0)');
  lg.addColorStop(1, 'rgba(140,165,195,0.35)');
  ctx.fillStyle = lg;
  ctx.fillRect(0, H * 0.5, W, H * 0.5);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function leafTexture(): THREE.CanvasTexture {
  const W = 128;
  const H = 128;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(777);
  ctx.clearRect(0, 0, W, H);
  for (let i = 0; i < 900; i++) {
    const greens = ['#2f6b26', '#3d852f', '#4c9a3a', '#275c20', '#5cab45', '#36752a'];
    ctx.fillStyle = greens[Math.floor(rand() * greens.length)];
    ctx.globalAlpha = 0.75 + rand() * 0.25;
    const x = rand() * W;
    const y = rand() * H;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rand() * Math.PI);
    ctx.fillRect(-2, -1, 4 + rand() * 3, 2 + rand() * 2);
    ctx.restore();
  }
  ctx.globalAlpha = 1;
  const t = toTexture(c);
  return t;
}

export function barkTexture(): THREE.CanvasTexture {
  const W = 64;
  const H = 128;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(313);
  ctx.fillStyle = '#5a4230';
  ctx.fillRect(0, 0, W, H);
  for (let x = 0; x < W; x += 4) {
    ctx.fillStyle = rand() > 0.5 ? 'rgba(40,28,18,0.6)' : 'rgba(120,95,70,0.4)';
    ctx.fillRect(x, 0, 2, H);
  }
  noiseOver(ctx, W, H, rand, 0.15, 2);
  return toTexture(c, 1, 2);
}

export function sidewalkTexture(): THREE.CanvasTexture {
  const W = 256;
  const H = 256;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(2024);
  ctx.fillStyle = '#9ea4ad';
  ctx.fillRect(0, 0, W, H);
  noiseOver(ctx, W, H, rand, 0.12, 2);
  ctx.strokeStyle = 'rgba(55,60,68,0.65)';
  ctx.lineWidth = 2.5;
  for (let i = 0; i <= 4; i++) {
    const p = (i / 4) * W;
    ctx.beginPath();
    ctx.moveTo(p, 0);
    ctx.lineTo(p, H);
    ctx.moveTo(0, p);
    ctx.lineTo(W, p);
    ctx.stroke();
  }
  ctx.strokeStyle = 'rgba(255,255,255,0.2)';
  ctx.lineWidth = 1.5;
  for (let i = 0; i < 4; i++) {
    const p = (i / 4) * W + 2;
    ctx.beginPath();
    ctx.moveTo(p, 0);
    ctx.lineTo(p, H);
    ctx.moveTo(0, p);
    ctx.lineTo(W, p);
    ctx.stroke();
  }
  return toTexture(c, 6, 6);
}

export function fieldTexture(color1: string, color2: string, seed: number): THREE.CanvasTexture {
  const W = 128;
  const H = 128;
  const { c, ctx } = makeCanvas(W, H);
  const rand = seededRandom(seed);
  ctx.fillStyle = color1;
  ctx.fillRect(0, 0, W, H);
  for (let y = 0; y < H; y += 6) {
    ctx.fillStyle = (y / 6) % 2 === 0 ? color1 : color2;
    ctx.fillRect(0, y, W, 5);
    ctx.fillStyle = 'rgba(0,0,0,0.15)';
    ctx.fillRect(0, y + 5, W, 1);
  }
  noiseOver(ctx, W, H, rand, 0.12, 2);
  return toTexture(c, 4, 4);
}

export function billboardTexture(text: string, bg1: string, bg2: string): THREE.CanvasTexture {
  const W = 256;
  const H = 128;
  const { c, ctx } = makeCanvas(W, H);
  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, bg1);
  g.addColorStop(1, bg2);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(255,255,255,0.12)';
  for (let i = 0; i < 5; i++) ctx.fillRect(0, i * 28, W, 8);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 34px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = 'rgba(0,0,0,0.5)';
  ctx.shadowBlur = 8;
  ctx.fillText(text, W / 2, H / 2 - 8);
  ctx.font = 'bold 15px Arial';
  ctx.fillStyle = '#ffe45e';
  ctx.fillText('★ RALLY X ★', W / 2, H / 2 + 26);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** Big ground splat texture painting whole world regions */
export function groundSplatTexture(): THREE.CanvasTexture {
  const S = 1024;
  const { c, ctx } = makeCanvas(S, S);
  const rand = seededRandom(9001);

  // map world [-1200,1200] to [0,S]
  const wx = (x: number) => ((x + 1200) / 2400) * S;
  const wz = (z: number) => ((z + 1200) / 2400) * S;

  // base grass
  const base = ctx.createLinearGradient(0, 0, S, S);
  base.addColorStop(0, '#5e8f3f');
  base.addColorStop(0.5, '#679c46');
  base.addColorStop(1, '#5a8a3c');
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, S, S);

  // large noise blotches for natural variation
  for (let i = 0; i < 900; i++) {
    const x = rand() * S;
    const y = rand() * S;
    const r = 8 + rand() * 42;
    const greens = ['rgba(70,110,50,0.25)', 'rgba(110,150,70,0.22)', 'rgba(90,130,60,0.25)', 'rgba(60,95,45,0.22)'];
    ctx.fillStyle = greens[Math.floor(rand() * greens.length)];
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // forest floor darker patches
  const forestRects = [
    [450, -950, 1050, -250],
    [-1050, -950, -450, -100],
  ];
  for (const [x1, z1, x2, z2] of forestRects) {
    ctx.fillStyle = 'rgba(38,72,32,0.55)';
    ctx.fillRect(wx(x1), wz(z1), wx(x2) - wx(x1), wz(z2) - wz(z1));
    for (let i = 0; i < 260; i++) {
      ctx.fillStyle = rand() > 0.5 ? 'rgba(30,60,28,0.4)' : 'rgba(55,95,45,0.35)';
      ctx.beginPath();
      ctx.arc(wx(x1) + rand() * (wx(x2) - wx(x1)), wz(z1) + rand() * (wz(z2) - wz(z1)), 3 + rand() * 10, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // city concrete base
  ctx.fillStyle = '#8d939c';
  ctx.fillRect(wx(-420), wz(-520), wx(420) - wx(-420), wx(220) - wx(-520));
  // city block variation
  for (let i = 0; i < 300; i++) {
    ctx.fillStyle = rand() > 0.5 ? 'rgba(120,128,138,0.35)' : 'rgba(150,156,164,0.3)';
    ctx.fillRect(wx(-420) + rand() * (wx(420) - wx(-420)), wz(-520) + rand() * (wz(220) - wz(-520)), 4 + rand() * 14, 4 + rand() * 14);
  }

  // village ground (lighter meadow + dirt)
  ctx.fillStyle = '#7fa050';
  ctx.fillRect(wx(450), wz(-200), wx(800) - wx(450), wz(240) - wz(-200));
  for (let i = 0; i < 150; i++) {
    ctx.fillStyle = 'rgba(150,125,85,0.3)';
    ctx.beginPath();
    ctx.arc(wx(450) + rand() * (wx(800) - wx(450)), wz(-200) + rand() * (wz(240) - wz(-200)), 3 + rand() * 9, 0, Math.PI * 2);
    ctx.fill();
  }

  // dirt roads: city->village, village->forest
  ctx.strokeStyle = '#8a7150';
  ctx.lineCap = 'round';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.moveTo(wx(420), wz(0));
  ctx.quadraticCurveTo(wx(500), wz(-20), wx(620), wz(20));
  ctx.stroke();
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(wx(620), wz(-180));
  ctx.quadraticCurveTo(wx(700), wz(-300), wx(750), wz(-450));
  ctx.stroke();
  // forest trails
  ctx.strokeStyle = 'rgba(138,113,80,0.8)';
  ctx.lineWidth = 2.5;
  for (let t = 0; t < 6; t++) {
    ctx.beginPath();
    let x = wx(500) + rand() * (wx(950) - wx(500));
    let y = wz(-900) + rand() * 100;
    ctx.moveTo(x, y);
    for (let s = 0; s < 5; s++) {
      x += (rand() - 0.5) * 120;
      y += 60 + rand() * 60;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  // west forest trails
  for (let t = 0; t < 4; t++) {
    ctx.beginPath();
    let x = wx(-950) + rand() * (wx(-550) - wx(-950));
    let y = wz(-850) + rand() * 100;
    ctx.moveTo(x, y);
    for (let s = 0; s < 5; s++) {
      x += (rand() - 0.5) * 100;
      y += 60 + rand() * 60;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }

  // beach sand band
  const sandGrad = ctx.createLinearGradient(0, wz(430), 0, wz(640));
  sandGrad.addColorStop(0, 'rgba(222,192,136,0)');
  sandGrad.addColorStop(0.25, '#ddc08a');
  sandGrad.addColorStop(1, '#e6cf9a');
  ctx.fillStyle = sandGrad;
  ctx.fillRect(0, wz(430), S, wz(640) - wz(430));
  // wet sand near water
  ctx.fillStyle = '#c8a06e';
  ctx.fillRect(0, wz(590), S, wz(640) - wz(590));

  // sea is separate mesh, paint deep blue beyond
  ctx.fillStyle = '#1e6fa8';
  ctx.fillRect(0, wz(640), S, S - wz(640));

  // mountain base rock tint near borders
  const borderGradN = ctx.createLinearGradient(0, 0, 0, wz(-980));
  borderGradN.addColorStop(0, '#6f6a63');
  borderGradN.addColorStop(1, 'rgba(111,106,99,0)');
  ctx.fillStyle = borderGradN;
  ctx.fillRect(0, 0, S, wz(-980));
  // east/west borders
  const bE = ctx.createLinearGradient(wx(980), 0, S, 0);
  bE.addColorStop(0, 'rgba(111,106,99,0)');
  bE.addColorStop(1, '#6f6a63');
  ctx.fillStyle = bE;
  ctx.fillRect(wx(980), 0, S - wx(980), S);
  const bW = ctx.createLinearGradient(0, 0, wx(-980), 0);
  bW.addColorStop(0, '#6f6a63');
  bW.addColorStop(1, 'rgba(111,106,99,0)');
  ctx.fillStyle = bW;
  ctx.fillRect(0, 0, wx(-980), S);

  // fine grain
  noiseOver(ctx, S, S, rand, 0.05, 2);

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}
