import * as THREE from "three";

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function canvasTexture(
  size: number,
  paint: (ctx: CanvasRenderingContext2D, rnd: () => number) => void,
): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const ctx = c.getContext("2d");
  if (!ctx) throw new Error("No 2D context");
  paint(ctx, mulberry32(size * 17 + 91));
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  tex.needsUpdate = true;
  return tex;
}

export type GameTextures = {
  dirt: THREE.CanvasTexture;
  wood: THREE.CanvasTexture;
  plaster: THREE.CanvasTexture;
  stone: THREE.CanvasTexture;
  metal: THREE.CanvasTexture;
};

let cache: GameTextures | null = null;

export function getTextures(): GameTextures {
  if (cache) return cache;
  cache = {
    dirt: canvasTexture(256, (ctx, rnd) => {
      ctx.fillStyle = "#3d3428";
      ctx.fillRect(0, 0, 256, 256);
      for (let i = 0; i < 5200; i++) {
        const n = rnd();
        const r = 70 + n * 55;
        const g = 54 + rnd() * 36;
        const b = 36 + rnd() * 22;
        ctx.fillStyle = `rgba(${r | 0},${g | 0},${b | 0},${0.18 + rnd() * 0.35})`;
        ctx.fillRect(rnd() * 256, rnd() * 256, 1 + rnd() * 3, 1 + rnd() * 2);
      }
    }),
    wood: canvasTexture(256, (ctx, rnd) => {
      ctx.fillStyle = "#5a4330";
      ctx.fillRect(0, 0, 256, 256);
      for (let x = 0; x < 256; x++) {
        const wobble = Math.sin(x * 0.08) * 8;
        ctx.strokeStyle = `rgba(${40 + rnd() * 30},${26 + rnd() * 16},${14 + rnd() * 10},${0.35 + rnd() * 0.25})`;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x + wobble, 256);
        ctx.stroke();
      }
      for (let i = 0; i < 40; i++) {
        ctx.fillStyle = `rgba(20,12,8,${0.15 + rnd() * 0.2})`;
        ctx.fillRect(rnd() * 256, rnd() * 256, 2 + rnd() * 8, 8 + rnd() * 28);
      }
    }),
    plaster: canvasTexture(256, (ctx, rnd) => {
      ctx.fillStyle = "#c9c0ad";
      ctx.fillRect(0, 0, 256, 256);
      for (let i = 0; i < 3000; i++) {
        ctx.fillStyle = `rgba(${180 + rnd() * 40},${170 + rnd() * 30},${150 + rnd() * 20},${0.12 + rnd() * 0.2})`;
        ctx.fillRect(rnd() * 256, rnd() * 256, 1 + rnd() * 2, 1 + rnd() * 2);
      }
    }),
    stone: canvasTexture(256, (ctx, rnd) => {
      ctx.fillStyle = "#6a6560";
      ctx.fillRect(0, 0, 256, 256);
      for (let i = 0; i < 80; i++) {
        const x = rnd() * 256;
        const y = rnd() * 256;
        const w = 18 + rnd() * 40;
        const h = 12 + rnd() * 22;
        ctx.fillStyle = `rgba(${90 + rnd() * 40},${86 + rnd() * 30},${78 + rnd() * 24},0.7)`;
        ctx.fillRect(x, y, w, h);
        ctx.strokeStyle = "rgba(30,28,24,0.35)";
        ctx.strokeRect(x, y, w, h);
      }
    }),
    metal: canvasTexture(128, (ctx, rnd) => {
      ctx.fillStyle = "#3a3a38";
      ctx.fillRect(0, 0, 128, 128);
      for (let i = 0; i < 800; i++) {
        const v = 40 + rnd() * 50;
        ctx.fillStyle = `rgba(${v},${v},${v - 4},0.4)`;
        ctx.fillRect(rnd() * 128, rnd() * 128, 1, 1);
      }
    }),
  };
  return cache;
}

export function disposeTextures() {
  if (!cache) return;
  cache.dirt.dispose();
  cache.wood.dispose();
  cache.plaster.dispose();
  cache.stone.dispose();
  cache.metal.dispose();
  cache = null;
}

export function makeSign(title: string, bg = "#4a3020", fg = "#e6dcc8"): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 128;
  const ctx = c.getContext("2d");
  if (!ctx) throw new Error("No 2D context");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, 256, 128);
  ctx.strokeStyle = "#2a1c12";
  ctx.lineWidth = 8;
  ctx.strokeRect(4, 4, 248, 120);
  ctx.fillStyle = fg;
  ctx.font = "700 42px Palatino, serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(title, 128, 64);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}
