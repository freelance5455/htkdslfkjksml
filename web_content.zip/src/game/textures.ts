import * as THREE from "three";
import type { ArenaId } from "./types";
import { ARENAS } from "./types";

const cache = new Map<string, THREE.Texture>();

function canvas(size: number, h = size): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement("canvas");
  c.width = size;
  c.height = h;
  const ctx = c.getContext("2d");
  if (!ctx) throw new Error("Canvas 2D context unavailable");
  return [c, ctx];
}

function finish(c: HTMLCanvasElement, srgb = true): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  t.needsUpdate = true;
  return t;
}

function noise(ctx: CanvasRenderingContext2D, w: number, h: number, amount: number, alpha: number) {
  for (let i = 0; i < amount; i++) {
    const x = Math.random() * w;
    const y = Math.random() * h;
    const s = Math.random() * 2.4 + 0.4;
    const v = Math.random() > 0.5 ? 255 : 0;
    ctx.fillStyle = `rgba(${v},${v},${v},${Math.random() * alpha})`;
    ctx.fillRect(x, y, s, s);
  }
}

/** Circular arena floor: concentric stone rings, cracks, glowing runes. */
export function floorTextures(arena: ArenaId): { map: THREE.Texture; emissive: THREE.Texture } {
  const key = `floor-${arena}`;
  const hit = cache.get(key);
  if (hit) {
    const em = cache.get(`${key}-em`);
    return { map: hit, emissive: em as THREE.Texture };
  }
  const pal = ARENAS[arena];
  const S = 1024;
  const [c, ctx] = canvas(S);
  const [ec, ectx] = canvas(S);
  const base = new THREE.Color(pal.stone);
  const dark = new THREE.Color(pal.stoneDark);

  ctx.fillStyle = `#${dark.getHexString()}`;
  ctx.fillRect(0, 0, S, S);
  ectx.fillStyle = "#000";
  ectx.fillRect(0, 0, S, S);

  const cx = S / 2;
  const cy = S / 2;

  // radial flagstones
  const rings = [0.16, 0.3, 0.44, 0.58, 0.72, 0.86, 1.0];
  for (let r = 0; r < rings.length - 1; r++) {
    const r0 = rings[r] * cx;
    const r1 = rings[r + 1] * cx;
    const segs = 10 + r * 4;
    for (let s = 0; s < segs; s++) {
      const a0 = (s / segs) * Math.PI * 2 + (r % 2) * 0.08;
      const a1 = ((s + 1) / segs) * Math.PI * 2 - 0.012;
      const shade = 0.72 + Math.random() * 0.4;
      const col = base.clone().multiplyScalar(shade);
      ctx.beginPath();
      ctx.arc(cx, cy, r1 - 2, a0, a1);
      ctx.arc(cx, cy, r0 + 2, a1, a0, true);
      ctx.closePath();
      ctx.fillStyle = `#${col.getHexString()}`;
      ctx.fill();
      ctx.strokeStyle = "rgba(0,0,0,0.45)";
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }
  }

  // cracks
  ctx.strokeStyle = "rgba(0,0,0,0.5)";
  for (let i = 0; i < 46; i++) {
    let x = Math.random() * S;
    let y = Math.random() * S;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineWidth = Math.random() * 2 + 0.5;
    for (let j = 0; j < 5; j++) {
      x += (Math.random() - 0.5) * 90;
      y += (Math.random() - 0.5) * 90;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  noise(ctx, S, S, 9000, 0.12);

  // glowing rune circle
  const rune = new THREE.Color(pal.rune);
  const drawRing = (radius: number, width: number, alpha: number) => {
    ectx.beginPath();
    ectx.arc(cx, cy, radius, 0, Math.PI * 2);
    ectx.strokeStyle = `rgba(${Math.round(rune.r * 255)},${Math.round(rune.g * 255)},${Math.round(
      rune.b * 255
    )},${alpha})`;
    ectx.lineWidth = width;
    ectx.stroke();
  };
  drawRing(cx * 0.9, 7, 0.85);
  drawRing(cx * 0.86, 2, 0.5);
  drawRing(cx * 0.42, 4, 0.7);
  drawRing(cx * 0.2, 3, 0.55);

  // rune glyphs around the ring
  ectx.save();
  ectx.translate(cx, cy);
  for (let i = 0; i < 28; i++) {
    ectx.rotate((Math.PI * 2) / 28);
    ectx.save();
    ectx.translate(cx * 0.93, 0);
    ectx.strokeStyle = `rgba(${Math.round(rune.r * 255)},${Math.round(rune.g * 255)},${Math.round(
      rune.b * 255
    )},0.9)`;
    ectx.lineWidth = 3;
    ectx.beginPath();
    const g = i % 5;
    if (g === 0) {
      ectx.moveTo(-8, -12);
      ectx.lineTo(8, 0);
      ectx.lineTo(-8, 12);
    } else if (g === 1) {
      ectx.moveTo(-7, -12);
      ectx.lineTo(-7, 12);
      ectx.moveTo(7, -12);
      ectx.lineTo(7, 12);
      ectx.moveTo(-7, 0);
      ectx.lineTo(7, 0);
    } else if (g === 2) {
      ectx.arc(0, 0, 9, 0, Math.PI * 1.4);
      ectx.moveTo(0, -12);
      ectx.lineTo(0, 12);
    } else if (g === 3) {
      ectx.moveTo(-8, 10);
      ectx.lineTo(0, -12);
      ectx.lineTo(8, 10);
      ectx.moveTo(-5, 3);
      ectx.lineTo(5, 3);
    } else {
      ectx.moveTo(-8, -10);
      ectx.lineTo(8, -10);
      ectx.lineTo(-8, 10);
      ectx.lineTo(8, 10);
    }
    ectx.stroke();
    ectx.restore();
  }
  ectx.restore();

  // central sigil
  ectx.save();
  ectx.translate(cx, cy);
  ectx.strokeStyle = `rgba(${Math.round(rune.r * 255)},${Math.round(rune.g * 255)},${Math.round(
    rune.b * 255
  )},0.8)`;
  ectx.lineWidth = 4;
  for (let i = 0; i < 3; i++) {
    ectx.beginPath();
    const a = (i / 3) * Math.PI * 2 - Math.PI / 2;
    const a2 = ((i + 1) / 3) * Math.PI * 2 - Math.PI / 2;
    ectx.moveTo(Math.cos(a) * cx * 0.17, Math.sin(a) * cx * 0.17);
    ectx.lineTo(Math.cos(a2) * cx * 0.17, Math.sin(a2) * cx * 0.17);
    ectx.stroke();
  }
  ectx.restore();

  const map = finish(c);
  const emissive = finish(ec);
  cache.set(key, map);
  cache.set(`${key}-em`, emissive);
  return { map, emissive };
}

/** Weathered stone for pillars, statues and steps. */
export function stoneTexture(arena: ArenaId): THREE.Texture {
  const key = `stone-${arena}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const pal = ARENAS[arena];
  const S = 512;
  const [c, ctx] = canvas(S);
  const base = new THREE.Color(pal.stone);
  ctx.fillStyle = `#${base.getHexString()}`;
  ctx.fillRect(0, 0, S, S);
  for (let i = 0; i < 260; i++) {
    const x = Math.random() * S;
    const y = Math.random() * S;
    const r = Math.random() * 26 + 4;
    const shade = 0.55 + Math.random() * 0.6;
    const col = base.clone().multiplyScalar(shade);
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, `rgba(${Math.round(col.r * 255)},${Math.round(col.g * 255)},${Math.round(
      col.b * 255
    )},0.5)`);
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.strokeStyle = "rgba(0,0,0,0.35)";
  for (let i = 0; i < 26; i++) {
    let x = Math.random() * S;
    let y = Math.random() * S;
    ctx.beginPath();
    ctx.moveTo(x, y);
    for (let j = 0; j < 4; j++) {
      x += (Math.random() - 0.5) * 70;
      y += (Math.random() - 0.5) * 70;
      ctx.lineTo(x, y);
    }
    ctx.lineWidth = Math.random() * 1.8 + 0.4;
    ctx.stroke();
  }
  noise(ctx, S, S, 5000, 0.14);
  const t = finish(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  cache.set(key, t);
  return t;
}

export function glowTexture(): THREE.Texture {
  const key = "glow";
  const hit = cache.get(key);
  if (hit) return hit;
  const S = 128;
  const [c, ctx] = canvas(S);
  const g = ctx.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
  g.addColorStop(0, "rgba(255,255,255,1)");
  g.addColorStop(0.25, "rgba(255,255,255,0.75)");
  g.addColorStop(0.6, "rgba(255,255,255,0.18)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  const t = finish(c);
  cache.set(key, t);
  return t;
}

export function flameTexture(): THREE.Texture {
  const key = "flame";
  const hit = cache.get(key);
  if (hit) return hit;
  const S = 128;
  const [c, ctx] = canvas(S);
  const g = ctx.createRadialGradient(S / 2, S * 0.62, 2, S / 2, S * 0.55, S * 0.5);
  g.addColorStop(0, "rgba(255,255,235,1)");
  g.addColorStop(0.25, "rgba(255,214,120,0.9)");
  g.addColorStop(0.55, "rgba(255,120,40,0.45)");
  g.addColorStop(1, "rgba(255,60,0,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.ellipse(S / 2, S * 0.55, S * 0.3, S * 0.46, 0, 0, Math.PI * 2);
  ctx.fill();
  const t = finish(c);
  cache.set(key, t);
  return t;
}

export function bannerTexture(arena: ArenaId): THREE.Texture {
  const key = `banner-${arena}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const pal = ARENAS[arena];
  const W = 256;
  const H = 512;
  const [c, ctx] = canvas(W, H);
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, pal.banner);
  g.addColorStop(1, "#08070a");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  ctx.strokeStyle = "rgba(217,179,106,0.75)";
  ctx.lineWidth = 6;
  ctx.strokeRect(14, 14, W - 28, H - 28);
  ctx.lineWidth = 2;
  ctx.strokeRect(26, 26, W - 52, H - 52);
  // emblem: laurel + rune
  ctx.save();
  ctx.translate(W / 2, H * 0.38);
  ctx.strokeStyle = pal.bannerEmblem;
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.arc(0, 0, 46, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  for (let i = 0; i < 3; i++) {
    const a = (i / 3) * Math.PI * 2 - Math.PI / 2;
    const a2 = ((i + 1) / 3) * Math.PI * 2 - Math.PI / 2;
    ctx.moveTo(Math.cos(a) * 44, Math.sin(a) * 44);
    ctx.lineTo(Math.cos(a2) * 44, Math.sin(a2) * 44);
  }
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(0, -70);
  ctx.lineTo(0, 70);
  ctx.moveTo(-70, 0);
  ctx.lineTo(70, 0);
  ctx.stroke();
  ctx.restore();
  // tattered bottom
  ctx.globalCompositeOperation = "destination-out";
  for (let i = 0; i < 9; i++) {
    const x = (i / 9) * W;
    ctx.beginPath();
    ctx.moveTo(x, H);
    ctx.lineTo(x + W / 18, H - 30 - Math.random() * 40);
    ctx.lineTo(x + W / 9, H);
    ctx.fill();
  }
  ctx.globalCompositeOperation = "source-over";
  noise(ctx, W, H, 1400, 0.1);
  const t = finish(c);
  cache.set(key, t);
  return t;
}

/** Equirectangular gradient used as a cheap local environment map for metals. */
export function environmentTexture(arena: ArenaId): THREE.Texture {
  const key = `env-${arena}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const pal = ARENAS[arena];
  const W = 512;
  const H = 256;
  const [c, ctx] = canvas(W, H);
  const sky = new THREE.Color(pal.sky);
  const fog = new THREE.Color(pal.fog);
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, `#${sky.clone().multiplyScalar(0.5).getHexString()}`);
  g.addColorStop(0.42, `#${fog.getHexString()}`);
  g.addColorStop(0.52, `#${new THREE.Color(pal.stone).multiplyScalar(0.55).getHexString()}`);
  g.addColorStop(0.75, `#${new THREE.Color(pal.stoneDark).getHexString()}`);
  g.addColorStop(1, "#050505");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  // warm/cool light blobs for specular interest
  const blobs: [number, number, number, number][] = [
    [0.18, 0.4, 70, pal.rimA],
    [0.78, 0.42, 80, pal.rimB],
    [0.5, 0.3, 50, pal.sun],
    [0.05, 0.55, 40, pal.trim],
    [0.95, 0.55, 40, pal.trim],
  ];
  for (const [x, y, r, col] of blobs) {
    const c2 = new THREE.Color(col);
    const rg = ctx.createRadialGradient(x * W, y * H, 0, x * W, y * H, r);
    rg.addColorStop(0, `rgba(${Math.round(c2.r * 255)},${Math.round(c2.g * 255)},${Math.round(
      c2.b * 255
    )},0.95)`);
    rg.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = rg;
    ctx.fillRect(0, 0, W, H);
  }
  const t = finish(c);
  t.mapping = THREE.EquirectangularReflectionMapping;
  cache.set(key, t);
  return t;
}

export function disposeTextureCache() {
  cache.forEach((t) => t.dispose());
  cache.clear();
}
