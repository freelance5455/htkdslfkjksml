import * as THREE from "three";

function canvasTex(
  size: number,
  draw: (ctx: CanvasRenderingContext2D, size: number) => void,
  repeat = 1,
): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = size;
  c.height = size;
  const ctx = c.getContext("2d");
  if (!ctx) return new THREE.CanvasTexture(c);
  draw(ctx, size);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat, repeat);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  t.needsUpdate = true;
  return t;
}

export function floorTex(): THREE.CanvasTexture {
  return canvasTex(
    256,
    (ctx, s) => {
      ctx.fillStyle = "#c9c2b4";
      ctx.fillRect(0, 0, s, s);
      const tile = s / 4;
      for (let y = 0; y < 4; y++) {
        for (let x = 0; x < 4; x++) {
          const n = ((x * 17 + y * 31) % 9) - 4;
          ctx.fillStyle = `rgb(${201 + n},${194 + n},${180 + n})`;
          ctx.fillRect(x * tile + 1, y * tile + 1, tile - 2, tile - 2);
        }
      }
      ctx.strokeStyle = "rgba(150,140,128,0.55)";
      ctx.lineWidth = 2;
      for (let i = 0; i <= 4; i++) {
        ctx.beginPath();
        ctx.moveTo(i * tile, 0);
        ctx.lineTo(i * tile, s);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, i * tile);
        ctx.lineTo(s, i * tile);
        ctx.stroke();
      }
    },
    8,
  );
}

export function warehouseFloorTex(): THREE.CanvasTexture {
  return canvasTex(
    256,
    (ctx, s) => {
      ctx.fillStyle = "#8a8680";
      ctx.fillRect(0, 0, s, s);
      for (let i = 0; i < 80; i++) {
        ctx.fillStyle = `rgba(0,0,0,${0.04 + Math.random() * 0.05})`;
        ctx.fillRect(Math.random() * s, Math.random() * s, 8 + Math.random() * 20, 2);
      }
      ctx.strokeStyle = "rgba(200,160,40,0.45)";
      ctx.lineWidth = 6;
      ctx.strokeRect(18, 18, s - 36, s - 36);
    },
    6,
  );
}

export function asphaltTex(): THREE.CanvasTexture {
  return canvasTex(
    256,
    (ctx, s) => {
      ctx.fillStyle = "#2a2c2e";
      ctx.fillRect(0, 0, s, s);
      for (let i = 0; i < 200; i++) {
        ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.05})`;
        ctx.fillRect(Math.random() * s, Math.random() * s, 2, 2);
      }
      ctx.fillStyle = "rgba(210,180,60,0.7)";
      ctx.fillRect(s / 2 - 4, 0, 8, s);
    },
    10,
  );
}

export function wallTex(): THREE.CanvasTexture {
  return canvasTex(
    256,
    (ctx, s) => {
      ctx.fillStyle = "#ece7dc";
      ctx.fillRect(0, 0, s, s);
      ctx.fillStyle = "#d8cfc0";
      ctx.fillRect(0, s * 0.82, s, s * 0.18);
      ctx.fillStyle = "#3a3f42";
      ctx.fillRect(0, s * 0.8, s, 6);
      for (let i = 0; i < 30; i++) {
        ctx.fillStyle = `rgba(0,0,0,${0.015 + Math.random() * 0.02})`;
        ctx.fillRect(Math.random() * s, Math.random() * s * 0.8, 40, 3);
      }
    },
    4,
  );
}

export function ceilingTex(): THREE.CanvasTexture {
  return canvasTex(
    128,
    (ctx, s) => {
      ctx.fillStyle = "#dfe3e6";
      ctx.fillRect(0, 0, s, s);
      ctx.strokeStyle = "#c5ccd0";
      ctx.lineWidth = 3;
      ctx.strokeRect(2, 2, s - 4, s - 4);
    },
    12,
  );
}

export function metalTex(): THREE.CanvasTexture {
  return canvasTex(64, (ctx, s) => {
    const g = ctx.createLinearGradient(0, 0, s, 0);
    g.addColorStop(0, "#8b9298");
    g.addColorStop(0.5, "#c5ccd2");
    g.addColorStop(1, "#8b9298");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, s, s);
  });
}

export function productTex(name: string, hex: string): THREE.CanvasTexture {
  return canvasTex(128, (ctx, s) => {
    ctx.fillStyle = hex;
    ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = "rgba(0,0,0,0.18)";
    ctx.fillRect(0, s * 0.62, s, s * 0.38);
    ctx.fillStyle = "#f4f1ea";
    ctx.font = "bold 18px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(name.slice(0, 10).toUpperCase(), s / 2, s * 0.78);
    ctx.fillStyle = "rgba(255,255,255,0.28)";
    ctx.fillRect(8, 8, s - 16, 10);
  });
}

export function hexColor(n: number): string {
  return `#${n.toString(16).padStart(6, "0")}`;
}
