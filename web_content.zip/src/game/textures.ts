import * as THREE from 'three';

export type TexKey = 'concrete' | 'asphalt' | 'brick' | 'facade' | 'facadeDesert' | 'sand' | 'metal' | 'crate' | 'sandbag' | 'rock' | 'tile' | 'roof' | 'container' | 'grass' | 'target';
const cache = new Map<string, THREE.CanvasTexture>();

function rnd(seed: number) { return () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }; }

function noiseFill(ctx: CanvasRenderingContext2D, s: number, base: [number, number, number], amp: number, r: () => number, count = 1) {
  const img = ctx.createImageData(s, s);
  for (let i = 0; i < s * s; i++) {
    const n = (r() - 0.5) * amp;
    img.data[i * 4] = base[0] + n; img.data[i * 4 + 1] = base[1] + n; img.data[i * 4 + 2] = base[2] + n; img.data[i * 4 + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  for (let k = 0; k < count * 40; k++) {
    ctx.fillStyle = `rgba(${r() > 0.5 ? '0,0,0' : '255,255,255'},${r() * 0.06})`;
    const w = r() * s * 0.3; ctx.beginPath(); ctx.ellipse(r() * s, r() * s, w, w * (0.3 + r()), r() * 3, 0, 7); ctx.fill();
  }
}

function draw(key: TexKey, s: number): HTMLCanvasElement {
  const c = document.createElement('canvas'); c.width = c.height = s;
  const ctx = c.getContext('2d')!; const r = rnd(key.length * 977 + s);
  const u = s / 256;
  switch (key) {
    case 'concrete': noiseFill(ctx, s, [128, 128, 124], 28, r, 2);
      ctx.strokeStyle = 'rgba(0,0,0,0.18)'; ctx.lineWidth = 2 * u; ctx.strokeRect(0, 0, s, s); ctx.beginPath(); ctx.moveTo(0, s / 2); ctx.lineTo(s, s / 2); ctx.stroke(); break;
    case 'asphalt': noiseFill(ctx, s, [52, 54, 56], 26, r, 1);
      for (let i = 0; i < 6; i++) { ctx.strokeStyle = 'rgba(20,20,20,0.5)'; ctx.lineWidth = u; ctx.beginPath(); let x = r() * s, y = r() * s; ctx.moveTo(x, y); for (let j = 0; j < 5; j++) { x += (r() - 0.5) * 40 * u; y += (r() - 0.5) * 40 * u; ctx.lineTo(x, y); } ctx.stroke(); } break;
    case 'brick': ctx.fillStyle = '#5e5a55'; ctx.fillRect(0, 0, s, s);
      for (let y = 0; y < 16; y++) for (let x = 0; x < 8; x++) { const sh = 110 + r() * 50; ctx.fillStyle = `rgb(${sh},${sh * 0.55},${sh * 0.42})`; ctx.fillRect(((x + (y % 2) * 0.5) * 32 - 16) * u, y * 16 * u + u, 30 * u, 14 * u); } break;
    case 'facade': case 'facadeDesert': {
      const desert = key === 'facadeDesert';
      noiseFill(ctx, s, desert ? [176, 150, 112] : [104, 108, 114], 18, r, 1);
      for (let y = 0; y < 2; y++) for (let x = 0; x < 2; x++) {
        const lit = r() > 0.75;
        ctx.fillStyle = desert ? '#3a2e22' : lit ? '#d8c27a' : '#1d2630'; ctx.fillRect((x * 128 + 30) * u, (y * 128 + 34) * u, 68 * u, 64 * u);
        ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect((x * 128 + 30) * u, (y * 128 + 34) * u, 68 * u, 6 * u);
        ctx.fillStyle = desert ? '#9a8260' : '#50555c'; ctx.fillRect((x * 128 + 24) * u, (y * 128 + 98) * u, 80 * u, 6 * u);
      } break; }
    case 'sand': noiseFill(ctx, s, [190, 165, 120], 22, r, 2); break;
    case 'grass': noiseFill(ctx, s, [92, 98, 60], 30, r, 2); break;
    case 'metal': noiseFill(ctx, s, [120, 126, 132], 14, r, 1);
      for (let i = 0; i < s; i += 32 * u) { ctx.fillStyle = 'rgba(0,0,0,0.15)'; ctx.fillRect(i, 0, 2 * u, s); } break;
    case 'container': ctx.fillStyle = '#888'; ctx.fillRect(0, 0, s, s);
      for (let i = 0; i < 16; i++) { ctx.fillStyle = i % 2 ? 'rgba(0,0,0,0.22)' : 'rgba(255,255,255,0.12)'; ctx.fillRect(i * 16 * u, 0, 8 * u, s); }
      ctx.fillStyle = 'rgba(80,40,20,0.25)'; for (let i = 0; i < 20; i++) ctx.fillRect(r() * s, r() * s, r() * 30 * u, r() * 6 * u); break;
    case 'crate': ctx.fillStyle = '#7a5a34'; ctx.fillRect(0, 0, s, s);
      for (let i = 0; i < 8; i++) { const sh = 100 + r() * 40; ctx.fillStyle = `rgb(${sh},${sh * 0.72},${sh * 0.42})`; ctx.fillRect(0, i * 32 * u + u, s, 30 * u); }
      ctx.strokeStyle = '#3b2814'; ctx.lineWidth = 14 * u; ctx.strokeRect(7 * u, 7 * u, s - 14 * u, s - 14 * u); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(s, s); ctx.stroke(); break;
    case 'sandbag': ctx.fillStyle = '#6b6046'; ctx.fillRect(0, 0, s, s);
      for (let y = 0; y < 4; y++) for (let x = 0; x < 3; x++) { const sh = 130 + r() * 30; ctx.fillStyle = `rgb(${sh},${sh * 0.9},${sh * 0.65})`; ctx.beginPath(); ctx.roundRect(((x + (y % 2) * 0.5) * 90 - 40) * u, (y * 64 + 4) * u, 84 * u, 56 * u, 22 * u); ctx.fill(); } break;
    case 'rock': noiseFill(ctx, s, [140, 112, 86], 40, r, 4); break;
    case 'tile': ctx.fillStyle = '#8a8478'; ctx.fillRect(0, 0, s, s);
      for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) { const sh = 140 + r() * 30; ctx.fillStyle = `rgb(${sh},${sh * 0.96},${sh * 0.9})`; ctx.fillRect(x * 64 * u + 2 * u, y * 64 * u + 2 * u, 60 * u, 60 * u); } break;
    case 'roof': noiseFill(ctx, s, [70, 72, 74], 20, r, 2); break;
    case 'target': ctx.fillStyle = '#e8e2d0'; ctx.fillRect(0, 0, s, s);
      for (let i = 5; i > 0; i--) { ctx.fillStyle = i % 2 ? '#c0392b' : '#f5f0e0'; ctx.beginPath(); ctx.arc(s / 2, s / 2, i * 24 * u, 0, 7); ctx.fill(); } break;
  }
  return c;
}

export function getTexture(key: TexKey, quality: number): THREE.CanvasTexture {
  const id = key + quality;
  let t = cache.get(id);
  if (!t) {
    const size = quality === 0 ? 64 : quality === 1 ? 128 : 256;
    t = new THREE.CanvasTexture(draw(key, size));
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = quality === 2 ? 8 : quality === 1 ? 4 : 1;
    t.generateMipmaps = true;
    cache.set(id, t);
  }
  return t;
}

/** Pre-generate all textures for the given quality (used by the real loading screen) */
export async function preloadTextures(quality: number, onProgress: (p: number) => void) {
  const keys: TexKey[] = ['concrete', 'asphalt', 'brick', 'facade', 'facadeDesert', 'sand', 'metal', 'crate', 'sandbag', 'rock', 'tile', 'roof', 'container', 'grass', 'target'];
  for (let i = 0; i < keys.length; i++) {
    getTexture(keys[i], quality);
    onProgress((i + 1) / keys.length);
    await new Promise(r => setTimeout(r, 0));
  }
}
