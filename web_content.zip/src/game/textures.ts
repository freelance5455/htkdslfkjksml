import * as THREE from "three";

function makeCanvas(w: number, h: number) {
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  return canvas;
}

function speckle(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  count: number,
  alpha: number,
  light = true,
) {
  for (let i = 0; i < count; i++) {
    const x = Math.random() * w;
    const y = Math.random() * h;
    const size = Math.random() * 2 + 0.4;
    const v = Math.random() * 40 + 8;
    ctx.fillStyle = light
      ? `rgba(${v + 30},${v + 32},${v + 40},${Math.random() * alpha})`
      : `rgba(0,0,0,${Math.random() * alpha})`;
    ctx.fillRect(x, y, size, size);
  }
}

function finish(canvas: HTMLCanvasElement, repeat: [number, number]) {
  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(repeat[0], repeat[1]);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  return texture;
}

/** asphalt tile — 16x16 world units, dashed lane markers and neon edges */
export function makeRoadTexture() {
  const S = 256;
  const canvas = makeCanvas(S, S);
  const ctx = canvas.getContext("2d")!;

  ctx.fillStyle = "#0e1016";
  ctx.fillRect(0, 0, S, S);
  speckle(ctx, S, S, 4200, 0.22);
  speckle(ctx, S, S, 900, 0.3, false);

  // tyre wear strips
  ctx.fillStyle = "rgba(255,255,255,0.028)";
  [64, 96, 160, 192].forEach((x) => ctx.fillRect(x, 0, 7, S));

  // neon shoulder lines
  ctx.fillStyle = "#63e6ff";
  ctx.fillRect(3, 0, 4, S);
  ctx.fillRect(S - 7, 0, 4, S);
  ctx.fillStyle = "rgba(99,230,255,0.25)";
  ctx.fillRect(7, 0, 3, S);
  ctx.fillRect(S - 10, 0, 3, S);

  // dashed lane dividers
  ctx.fillStyle = "#ffd166";
  for (let y = 0; y < S; y += 64) {
    ctx.fillRect(83, y, 5, 34);
    ctx.fillRect(168, y, 5, 34);
  }

  return finish(canvas, [1, 30]);
}

/** dry sand / gravel ground */
export function makeGroundTexture() {
  const S = 256;
  const canvas = makeCanvas(S, S);
  const ctx = canvas.getContext("2d")!;

  ctx.fillStyle = "#171325";
  ctx.fillRect(0, 0, S, S);
  speckle(ctx, S, S, 6000, 0.18);
  speckle(ctx, S, S, 1500, 0.35, false);

  for (let i = 0; i < 70; i++) {
    const x = Math.random() * S;
    const y = Math.random() * S;
    const r = Math.random() * 5 + 1.5;
    ctx.fillStyle = `rgba(${60 + Math.random() * 40},${50 + Math.random() * 30},${80 + Math.random() * 40},0.35)`;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  return finish(canvas, [26, 26]);
}

/** soft radial glow used for light pools and the neon under-glow */
export function makeGlowTexture(inner = "rgba(255,255,255,1)") {
  const S = 128;
  const canvas = makeCanvas(S, S);
  const ctx = canvas.getContext("2d")!;
  const g = ctx.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
  g.addColorStop(0, inner);
  g.addColorStop(0.35, "rgba(255,255,255,0.35)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

/** soft dark blob used as a fake contact shadow */
export function makeShadowTexture() {
  const S = 128;
  const canvas = makeCanvas(S, S);
  const ctx = canvas.getContext("2d")!;
  const g = ctx.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
  g.addColorStop(0, "rgba(0,0,0,0.75)");
  g.addColorStop(0.6, "rgba(0,0,0,0.35)");
  g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  const texture = new THREE.CanvasTexture(canvas);
  return texture;
}

/** night skyline facade with lit windows */
export function makeBuildingTexture() {
  const S = 128;
  const canvas = makeCanvas(S, S);
  const ctx = canvas.getContext("2d")!;

  ctx.fillStyle = "#0b0d18";
  ctx.fillRect(0, 0, S, S);
  speckle(ctx, S, S, 1200, 0.12);

  const cols = 6;
  const rows = 10;
  const cw = S / cols;
  const rh = S / rows;
  for (let c = 0; c < cols; c++) {
    for (let r = 0; r < rows; r++) {
      const lit = Math.random() > 0.55;
      const x = c * cw + cw * 0.2;
      const y = r * rh + rh * 0.18;
      const w = cw * 0.6;
      const h = rh * 0.5;
      if (lit) {
        const warm = Math.random() > 0.4;
        ctx.fillStyle = warm
          ? `rgba(255,${190 + Math.random() * 50},${120 + Math.random() * 60},0.95)`
          : `rgba(120,${220 + Math.random() * 30},255,0.95)`;
      } else {
        ctx.fillStyle = "rgba(40,60,90,0.35)";
      }
      ctx.fillRect(x, y, w, h);
    }
  }

  return finish(canvas, [1, 2]);
}

/** vertical gradient sky dome */
export function makeSkyTexture() {
  const canvas = makeCanvas(8, 256);
  const ctx = canvas.getContext("2d")!;
  const g = ctx.createLinearGradient(0, 0, 0, 256);
  g.addColorStop(0, "#03040c");
  g.addColorStop(0.42, "#0b1030");
  g.addColorStop(0.68, "#241a52");
  g.addColorStop(0.86, "#5b2a6b");
  g.addColorStop(1, "#b8477a");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 8, 256);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}
