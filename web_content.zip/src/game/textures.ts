import * as THREE from 'three';

export interface PbrTextureSet {
  map: THREE.Texture;
  normalMap: THREE.Texture;
  roughnessMap: THREE.Texture;
  dispose: () => void;
}

// Fast deterministic 2D hash & value noise for crisp tileable procedural textures
function hash2(ix: number, iy: number, period: number, seed: number): number {
  const x = ((ix % period) + period) % period;
  const y = ((iy % period) + period) % period;
  let n = (x * 374761393 + y * 668265263 + seed * 1442695041) | 0;
  n = (n ^ (n >> 13)) * 1274126177;
  n = n ^ (n >> 16);
  return (n >>> 0) / 4294967295;
}

function tileableNoise(u: number, v: number, freq: number, seed: number): number {
  const x = u * freq;
  const y = v * freq;
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const sx = fx * fx * (3 - 2 * fx);
  const sy = fy * fy * (3 - 2 * fy);

  const n00 = hash2(ix, iy, freq, seed);
  const n10 = hash2(ix + 1, iy, freq, seed);
  const n01 = hash2(ix, iy + 1, freq, seed);
  const n11 = hash2(ix + 1, iy + 1, freq, seed);

  const nx0 = n00 + (n10 - n00) * sx;
  const nx1 = n01 + (n11 - n01) * sx;
  return nx0 + (nx1 - nx0) * sy;
}

function fbmTileable(u: number, v: number, baseFreq: number, octaves: number, seed: number): number {
  let sum = 0;
  let amp = 0.5;
  let norm = 0;
  let f = baseFreq;
  for (let i = 0; i < octaves; i++) {
    sum += amp * tileableNoise(u, v, f, seed + i * 31);
    norm += amp;
    amp *= 0.5;
    f *= 2;
  }
  return sum / norm;
}

function buildNormalFromHeight(
  height: Float32Array,
  size: number,
  strength: number,
): THREE.DataTexture {
  const data = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) {
    const ym = (y - 1 + size) % size;
    const yp = (y + 1) % size;
    for (let x = 0; x < size; x++) {
      const xm = (x - 1 + size) % size;
      const xp = (x + 1) % size;

      const hL = height[y * size + xm];
      const hR = height[y * size + xp];
      const hD = height[ym * size + x];
      const hU = height[yp * size + x];

      const dx = (hL - hR) * strength;
      const dy = (hD - hU) * strength;
      const dz = 1.0;
      const len = Math.sqrt(dx * dx + dy * dy + dz * dz);

      const idx = (y * size + x) * 4;
      data[idx] = Math.round(((dx / len) * 0.5 + 0.5) * 255);
      data[idx + 1] = Math.round(((dy / len) * 0.5 + 0.5) * 255);
      data[idx + 2] = Math.round(((dz / len) * 0.5 + 0.5) * 255);
      data[idx + 3] = 255;
    }
  }
  const tex = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.generateMipmaps = true;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  return tex;
}

function configureTexture(
  tex: THREE.Texture,
  repeatX: number,
  repeatY: number,
  anisotropy: number,
  isColor: boolean,
): THREE.Texture {
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.anisotropy = anisotropy;
  tex.colorSpace = isColor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export class ProceduralTextureLibrary {
  private maxAniso: number;
  private sets: PbrTextureSet[] = [];

  constructor(renderer: THREE.WebGLRenderer) {
    this.maxAniso = Math.min(renderer.capabilities.getMaxAnisotropy(), 16);
  }

  public createWetConcreteFloor(repeatX = 10, repeatY = 10): PbrTextureSet {
    const size = 512;
    const albedoData = new Uint8Array(size * size * 4);
    const roughData = new Uint8Array(size * size * 4);
    const height = new Float32Array(size * size);

    for (let y = 0; y < size; y++) {
      const v = y / size;
      for (let x = 0; x < size; x++) {
        const u = x / size;
        const idx = y * size + x;

        const macro = fbmTileable(u, v, 4, 4, 11);
        const grain = fbmTileable(u, v, 32, 3, 73);
        const puddleField = fbmTileable(u, v, 3, 3, 203);

        // Slab expansion joint grid (2x2 slabs per tile)
        const gx = Math.abs(((u * 2) % 1) - 0.5) * 2;
        const gy = Math.abs(((v * 2) % 1) - 0.5) * 2;
        const joint = gx > 0.986 || gy > 0.986 ? 1 : 0;

        // Cracks via ridged noise
        const crackN = Math.abs(fbmTileable(u, v, 8, 3, 317) - 0.5);
        const crack = crackN < 0.014 ? 1.0 - crackN / 0.014 : 0;

        // Wet puddle mask (lower puddles collect water)
        const isWet = puddleField < 0.43;
        const wetness = isWet ? THREE.MathUtils.smoothstep(0.43 - puddleField, 0, 0.14) : 0;

        const h =
          0.55 +
          macro * 0.25 +
          grain * 0.18 -
          joint * 0.45 -
          crack * 0.35 -
          wetness * 0.08;
        height[idx] = h;

        // Base concrete slate tone darkened in wet areas
        const baseLum = (58 + macro * 38 + grain * 22 - joint * 28 - crack * 22) * (1 - wetness * 0.42);
        const cIdx = idx * 4;
        albedoData[cIdx] = Math.max(8, Math.min(255, Math.round(baseLum * 0.94)));
        albedoData[cIdx + 1] = Math.max(9, Math.min(255, Math.round(baseLum * 0.98)));
        albedoData[cIdx + 2] = Math.max(10, Math.min(255, Math.round(baseLum * 1.03)));
        albedoData[cIdx + 3] = 255;

        // Roughness: wet puddles mirror light (0.09 - 0.18), dry concrete is coarse (0.78 - 0.95)
        const rough = THREE.MathUtils.lerp(0.82 + grain * 0.14, 0.08 + grain * 0.08, wetness);
        const rByte = Math.max(15, Math.min(255, Math.round(rough * 255)));
        roughData[cIdx] = rByte;
        roughData[cIdx + 1] = rByte;
        roughData[cIdx + 2] = rByte;
        roughData[cIdx + 3] = 255;
      }
    }

    const map = configureTexture(
      new THREE.DataTexture(albedoData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      true,
    );
    const roughnessMap = configureTexture(
      new THREE.DataTexture(roughData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );
    const normalMap = configureTexture(
      buildNormalFromHeight(height, size, 3.6),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );

    const set: PbrTextureSet = {
      map,
      normalMap,
      roughnessMap,
      dispose: () => {
        map.dispose();
        normalMap.dispose();
        roughnessMap.dispose();
      },
    };
    this.sets.push(set);
    return set;
  }

  public createCinderblockWall(repeatX = 4, repeatY = 2): PbrTextureSet {
    const size = 512;
    const albedoData = new Uint8Array(size * size * 4);
    const roughData = new Uint8Array(size * size * 4);
    const height = new Float32Array(size * size);

    const rows = 8;
    const cols = 4;

    for (let y = 0; y < size; y++) {
      const v = y / size;
      const rowIdx = Math.floor(v * rows);
      const rowFrac = (v * rows) % 1;

      for (let x = 0; x < size; x++) {
        const u = x / size;
        const stagger = (rowIdx % 2) * 0.5;
        const colFrac = ((u * cols + stagger) % 1 + 1) % 1;

        const isMortar = rowFrac < 0.07 || rowFrac > 0.93 || colFrac < 0.04 || colFrac > 0.96;
        const blockNoise = hash2(Math.floor(u * cols + stagger), rowIdx, 64, 55);
        const grime = fbmTileable(u, v, 6, 4, 91);
        const drip = fbmTileable(u * 3, v * 0.4, 8, 3, 145);
        const micro = fbmTileable(u, v, 32, 2, 19);

        // Subtle moisture seepage near base (v near 0 in GL uv or top/bottom)
        const baseDamp = v < 0.25 ? (0.25 - v) * 2.2 : 0;

        const h = isMortar
          ? 0.22 + micro * 0.08
          : 0.65 + blockNoise * 0.08 + micro * 0.14 - grime * 0.06;
        const idx = y * size + x;
        height[idx] = h;

        let lum = isMortar
          ? 44 + micro * 16
          : 74 + blockNoise * 18 + micro * 18 - grime * 26 - drip * 14;
        lum *= 1 - Math.min(0.45, baseDamp * 0.45);

        const cIdx = idx * 4;
        albedoData[cIdx] = Math.max(12, Math.min(255, Math.round(lum * 0.93)));
        albedoData[cIdx + 1] = Math.max(13, Math.min(255, Math.round(lum * 0.97)));
        albedoData[cIdx + 2] = Math.max(14, Math.min(255, Math.round(lum * 1.0)));
        albedoData[cIdx + 3] = 255;

        const rough = isMortar ? 0.95 : Math.max(0.35, 0.88 - baseDamp * 0.4 + micro * 0.08);
        const rByte = Math.round(rough * 255);
        roughData[cIdx] = rByte;
        roughData[cIdx + 1] = rByte;
        roughData[cIdx + 2] = rByte;
        roughData[cIdx + 3] = 255;
      }
    }

    const map = configureTexture(
      new THREE.DataTexture(albedoData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      true,
    );
    const roughnessMap = configureTexture(
      new THREE.DataTexture(roughData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );
    const normalMap = configureTexture(
      buildNormalFromHeight(height, size, 4.2),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );

    const set: PbrTextureSet = {
      map,
      normalMap,
      roughnessMap,
      dispose: () => {
        map.dispose();
        normalMap.dispose();
        roughnessMap.dispose();
      },
    };
    this.sets.push(set);
    return set;
  }

  public createRustedCorrugatedMetal(
    baseHex = 0x3b4852,
    repeatX = 2,
    repeatY = 1,
  ): PbrTextureSet {
    const size = 512;
    const albedoData = new Uint8Array(size * size * 4);
    const roughData = new Uint8Array(size * size * 4);
    const height = new Float32Array(size * size);

    const baseColor = new THREE.Color(baseHex);
    const rustColor = new THREE.Color(0x5c2b16);

    for (let y = 0; y < size; y++) {
      const v = y / size;
      for (let x = 0; x < size; x++) {
        const u = x / size;
        const idx = y * size + x;

        const rib = Math.sin(u * Math.PI * 2 * 14) * 0.5 + 0.5;
        const rustMask = THREE.MathUtils.smoothstep(
          fbmTileable(u, v, 5, 4, 412),
          0.46,
          0.68,
        );
        const scratch = fbmTileable(u * 0.5, v * 4, 16, 2, 88);

        height[idx] = rib * 0.65 + (1 - rustMask) * 0.12 + scratch * 0.1;

        const r = THREE.MathUtils.lerp(baseColor.r, rustColor.r, rustMask) * (0.78 + scratch * 0.35);
        const g = THREE.MathUtils.lerp(baseColor.g, rustColor.g, rustMask) * (0.78 + scratch * 0.35);
        const b = THREE.MathUtils.lerp(baseColor.b, rustColor.b, rustMask) * (0.78 + scratch * 0.35);

        const cIdx = idx * 4;
        albedoData[cIdx] = Math.min(255, Math.round(r * 255));
        albedoData[cIdx + 1] = Math.min(255, Math.round(g * 255));
        albedoData[cIdx + 2] = Math.min(255, Math.round(b * 255));
        albedoData[cIdx + 3] = 255;

        const rough = THREE.MathUtils.lerp(0.34, 0.88, rustMask) - scratch * 0.08;
        const rByte = Math.max(20, Math.min(255, Math.round(rough * 255)));
        roughData[cIdx] = rByte;
        roughData[cIdx + 1] = rByte;
        roughData[cIdx + 2] = rByte;
        roughData[cIdx + 3] = 255;
      }
    }

    const map = configureTexture(
      new THREE.DataTexture(albedoData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      true,
    );
    const roughnessMap = configureTexture(
      new THREE.DataTexture(roughData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );
    const normalMap = configureTexture(
      buildNormalFromHeight(height, size, 3.8),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );

    const set: PbrTextureSet = {
      map,
      normalMap,
      roughnessMap,
      dispose: () => {
        map.dispose();
        normalMap.dispose();
        roughnessMap.dispose();
      },
    };
    this.sets.push(set);
    return set;
  }

  public createDiamondPlateSteel(repeatX = 4, repeatY = 4): PbrTextureSet {
    const size = 256;
    const albedoData = new Uint8Array(size * size * 4);
    const roughData = new Uint8Array(size * size * 4);
    const height = new Float32Array(size * size);

    for (let y = 0; y < size; y++) {
      const v = y / size;
      for (let x = 0; x < size; x++) {
        const u = x / size;
        const idx = y * size + x;

        const gx = (u * 8) % 1;
        const gy = (v * 8) % 1;
        const cell = (Math.floor(u * 8) + Math.floor(v * 8)) % 2;

        // Diamond lug oriented +/- 45 deg
        const cx = gx - 0.5;
        const cy = gy - 0.5;
        const rotX = cell === 0 ? cx + cy : cx - cy;
        const rotY = cell === 0 ? -cx + cy : cx + cy;
        const lug = Math.abs(rotX) < 0.28 && Math.abs(rotY) < 0.09 ? 1 : 0;
        const wear = fbmTileable(u, v, 8, 3, 61);

        height[idx] = 0.4 + lug * 0.45 + wear * 0.08;
        const lum = 68 + lug * 44 + wear * 24;
        const cIdx = idx * 4;
        albedoData[cIdx] = Math.round(lum * 0.95);
        albedoData[cIdx + 1] = Math.round(lum * 0.98);
        albedoData[cIdx + 2] = Math.round(lum * 1.04);
        albedoData[cIdx + 3] = 255;

        const rough = lug ? 0.26 : 0.48 + wear * 0.2;
        const rByte = Math.round(rough * 255);
        roughData[cIdx] = rByte;
        roughData[cIdx + 1] = rByte;
        roughData[cIdx + 2] = rByte;
        roughData[cIdx + 3] = 255;
      }
    }

    const map = configureTexture(
      new THREE.DataTexture(albedoData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      true,
    );
    const roughnessMap = configureTexture(
      new THREE.DataTexture(roughData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );
    const normalMap = configureTexture(
      buildNormalFromHeight(height, size, 3.2),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );

    const set: PbrTextureSet = {
      map,
      normalMap,
      roughnessMap,
      dispose: () => {
        map.dispose();
        normalMap.dispose();
        roughnessMap.dispose();
      },
    };
    this.sets.push(set);
    return set;
  }

  public createHazardStripeTexture(repeatX = 4, repeatY = 1): THREE.Texture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#18181b';
    ctx.fillRect(0, 0, 256, 256);

    ctx.fillStyle = '#d97706';
    for (let i = -256; i < 512; i += 64) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i + 32, 0);
      ctx.lineTo(i - 96, 256);
      ctx.lineTo(i - 128, 256);
      ctx.closePath();
      ctx.fill();
    }

    // Scuffs and grime overlay
    for (let i = 0; i < 1800; i++) {
      ctx.fillStyle = `rgba(10,10,12,${Math.random() * 0.35})`;
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 2 + Math.random() * 5, 2 + Math.random() * 4);
    }

    const tex = new THREE.CanvasTexture(canvas);
    return configureTexture(tex, repeatX, repeatY, this.maxAniso, true);
  }

  public createBrushedGunmetal(): PbrTextureSet {
    const size = 256;
    const albedoData = new Uint8Array(size * size * 4);
    const roughData = new Uint8Array(size * size * 4);
    const height = new Float32Array(size * size);

    for (let y = 0; y < size; y++) {
      const v = y / size;
      const streak = fbmTileable(0.1, v, 32, 2, 701);
      for (let x = 0; x < size; x++) {
        const u = x / size;
        const idx = y * size + x;
        const micro = tileableNoise(u, v, 64, 709) * 0.2 + streak * 0.8;
        height[idx] = micro;

        const lum = 36 + micro * 26;
        const cIdx = idx * 4;
        albedoData[cIdx] = Math.round(lum * 0.96);
        albedoData[cIdx + 1] = Math.round(lum * 0.99);
        albedoData[cIdx + 2] = Math.round(lum * 1.05);
        albedoData[cIdx + 3] = 255;

        const rByte = Math.round((0.22 + micro * 0.16) * 255);
        roughData[cIdx] = rByte;
        roughData[cIdx + 1] = rByte;
        roughData[cIdx + 2] = rByte;
        roughData[cIdx + 3] = 255;
      }
    }

    const map = configureTexture(
      new THREE.DataTexture(albedoData, size, size, THREE.RGBAFormat),
      1,
      1,
      this.maxAniso,
      true,
    );
    const roughnessMap = configureTexture(
      new THREE.DataTexture(roughData, size, size, THREE.RGBAFormat),
      1,
      1,
      this.maxAniso,
      false,
    );
    const normalMap = configureTexture(
      buildNormalFromHeight(height, size, 1.8),
      1,
      1,
      this.maxAniso,
      false,
    );

    const set: PbrTextureSet = {
      map,
      normalMap,
      roughnessMap,
      dispose: () => {
        map.dispose();
        normalMap.dispose();
        roughnessMap.dispose();
      },
    };
    this.sets.push(set);
    return set;
  }

  public createWetTrenchMud(repeatX = 16, repeatY = 16): PbrTextureSet {
    const size = 512;
    const albedoData = new Uint8Array(size * size * 4);
    const roughData = new Uint8Array(size * size * 4);
    const height = new Float32Array(size * size);

    for (let y = 0; y < size; y++) {
      const v = y / size;
      for (let x = 0; x < size; x++) {
        const u = x / size;
        const idx = y * size + x;

        const macro = fbmTileable(u, v, 4, 4, 811);
        const clod = fbmTileable(u, v, 18, 3, 823);
        const grit = tileableNoise(u, v, 64, 839);
        const puddleField = fbmTileable(u, v, 3, 3, 853);

        const isWet = puddleField < 0.44;
        const wetness = isWet ? THREE.MathUtils.smoothstep(0.44 - puddleField, 0, 0.16) : 0;

        const h = 0.5 + macro * 0.25 + clod * 0.22 + grit * 0.08 - wetness * 0.14;
        height[idx] = h;

        const base = (48 + macro * 28 + clod * 16) * (1 - wetness * 0.45);
        const cIdx = idx * 4;
        albedoData[cIdx] = Math.max(10, Math.min(255, Math.round(base * 1.15)));
        albedoData[cIdx + 1] = Math.max(9, Math.min(255, Math.round(base * 0.94)));
        albedoData[cIdx + 2] = Math.max(7, Math.min(255, Math.round(base * 0.76)));
        albedoData[cIdx + 3] = 255;

        const rough = THREE.MathUtils.lerp(0.86 + grit * 0.1, 0.07 + grit * 0.06, wetness);
        const rByte = Math.max(14, Math.min(255, Math.round(rough * 255)));
        roughData[cIdx] = rByte;
        roughData[cIdx + 1] = rByte;
        roughData[cIdx + 2] = rByte;
        roughData[cIdx + 3] = 255;
      }
    }

    const map = configureTexture(
      new THREE.DataTexture(albedoData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      true,
    );
    const roughnessMap = configureTexture(
      new THREE.DataTexture(roughData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );
    const normalMap = configureTexture(
      buildNormalFromHeight(height, size, 4.4),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );

    const set: PbrTextureSet = {
      map,
      normalMap,
      roughnessMap,
      dispose: () => {
        map.dispose();
        normalMap.dispose();
        roughnessMap.dispose();
      },
    };
    this.sets.push(set);
    return set;
  }

  public createSandbagBurlap(repeatX = 3, repeatY = 2): PbrTextureSet {
    const size = 256;
    const albedoData = new Uint8Array(size * size * 4);
    const roughData = new Uint8Array(size * size * 4);
    const height = new Float32Array(size * size);

    for (let y = 0; y < size; y++) {
      const v = y / size;
      const row = Math.floor(v * 6);
      const rowFrac = (v * 6) % 1;
      for (let x = 0; x < size; x++) {
        const u = x / size;
        const idx = y * size + x;
        const stagger = (row % 2) * 0.5;
        const colFrac = ((u * 3 + stagger) % 1 + 1) % 1;

        // Pillow-shaped sandbag bulge
        const bx = Math.sin(colFrac * Math.PI);
        const by = Math.sin(rowFrac * Math.PI);
        const bulge = Math.pow(bx * by, 0.45);

        // Burlap weave
        const weave =
          (Math.sin(u * Math.PI * 2 * 48) * 0.5 + 0.5) * 0.5 +
          (Math.sin(v * Math.PI * 2 * 48) * 0.5 + 0.5) * 0.5;
        const dirt = fbmTileable(u, v, 5, 3, 907);

        height[idx] = bulge * 0.72 + weave * 0.18 + dirt * 0.1;

        const seamShadow = 0.45 + 0.55 * bulge;
        const lum = (96 + weave * 22 - dirt * 34) * seamShadow;
        const cIdx = idx * 4;
        albedoData[cIdx] = Math.min(255, Math.round(lum * 1.08));
        albedoData[cIdx + 1] = Math.min(255, Math.round(lum * 0.98));
        albedoData[cIdx + 2] = Math.min(255, Math.round(lum * 0.78));
        albedoData[cIdx + 3] = 255;

        const rough = 0.88 + weave * 0.08;
        const rByte = Math.min(255, Math.round(rough * 255));
        roughData[cIdx] = rByte;
        roughData[cIdx + 1] = rByte;
        roughData[cIdx + 2] = rByte;
        roughData[cIdx + 3] = 255;
      }
    }

    const map = configureTexture(
      new THREE.DataTexture(albedoData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      true,
    );
    const roughnessMap = configureTexture(
      new THREE.DataTexture(roughData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );
    const normalMap = configureTexture(
      buildNormalFromHeight(height, size, 4.8),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );

    const set: PbrTextureSet = {
      map,
      normalMap,
      roughnessMap,
      dispose: () => {
        map.dispose();
        normalMap.dispose();
        roughnessMap.dispose();
      },
    };
    this.sets.push(set);
    return set;
  }

  public createTimberPlanks(repeatX = 2, repeatY = 2): PbrTextureSet {
    const size = 256;
    const albedoData = new Uint8Array(size * size * 4);
    const roughData = new Uint8Array(size * size * 4);
    const height = new Float32Array(size * size);

    for (let y = 0; y < size; y++) {
      const v = y / size;
      const plankIdx = Math.floor(v * 6);
      const plankFrac = (v * 6) % 1;
      const isGap = plankFrac < 0.08 || plankFrac > 0.92;
      const plankTone = hash2(plankIdx, 1, 32, 955);

      for (let x = 0; x < size; x++) {
        const u = x / size;
        const idx = y * size + x;
        const grain = fbmTileable(u * 0.3, v * 5, 10, 3, 971);
        const mud = THREE.MathUtils.smoothstep(fbmTileable(u, v, 4, 3, 991), 0.5, 0.78);

        height[idx] = isGap ? 0.15 : 0.6 + grain * 0.25 - mud * 0.1;

        const base = (isGap ? 22 : 76 + plankTone * 22 + grain * 26) * (1 - mud * 0.45);
        const cIdx = idx * 4;
        albedoData[cIdx] = Math.min(255, Math.round(base * 1.12));
        albedoData[cIdx + 1] = Math.min(255, Math.round(base * 0.88));
        albedoData[cIdx + 2] = Math.min(255, Math.round(base * 0.65));
        albedoData[cIdx + 3] = 255;

        const rough = isGap ? 0.96 : THREE.MathUtils.lerp(0.82, 0.36, mud);
        const rByte = Math.round(rough * 255);
        roughData[cIdx] = rByte;
        roughData[cIdx + 1] = rByte;
        roughData[cIdx + 2] = rByte;
        roughData[cIdx + 3] = 255;
      }
    }

    const map = configureTexture(
      new THREE.DataTexture(albedoData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      true,
    );
    const roughnessMap = configureTexture(
      new THREE.DataTexture(roughData, size, size, THREE.RGBAFormat),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );
    const normalMap = configureTexture(
      buildNormalFromHeight(height, size, 3.8),
      repeatX,
      repeatY,
      this.maxAniso,
      false,
    );

    const set: PbrTextureSet = {
      map,
      normalMap,
      roughnessMap,
      dispose: () => {
        map.dispose();
        normalMap.dispose();
        roughnessMap.dispose();
      },
    };
    this.sets.push(set);
    return set;
  }

  public disposeAll(): void {
    this.sets.forEach((s) => s.dispose());
    this.sets = [];
  }
}
