// Procedural pixel textures — everything is drawn in canvas so it stays crisp at any zoom.
export const TILE = 16;
export const ATLAS_COLS = 4;
export const ATLAS_ROWS = 4;

type Ctx = CanvasRenderingContext2D;

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function px(ctx: Ctx, x: number, y: number, color: string) {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, 1, 1);
}

function fill(ctx: Ctx, ox: number, oy: number, color: string) {
  ctx.fillStyle = color;
  ctx.fillRect(ox, oy, TILE, TILE);
}

function speckle(
  ctx: Ctx,
  ox: number,
  oy: number,
  palette: string[],
  seed: number,
  count: number,
) {
  const r = rng(seed);
  for (let i = 0; i < count; i++) {
    px(
      ctx,
      ox + Math.floor(r() * TILE),
      oy + Math.floor(r() * TILE),
      palette[Math.floor(r() * palette.length)],
    );
  }
}

/** Each drawer paints into a TILE×TILE cell at (ox,oy). */
const DRAWERS: Array<(ctx: Ctx, ox: number, oy: number) => void> = [
  // 0 grass top
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#5f9e3d");
    speckle(ctx, ox, oy, ["#6cb247", "#548c36", "#79bd52", "#4a7d30"], 11, 110);
  },
  // 1 grass side
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#8b5e3c");
    speckle(ctx, ox, oy, ["#7b5234", "#966843", "#6c482c"], 22, 90);
    const r = rng(23);
    for (let x = 0; x < TILE; x++) {
      const h = 3 + Math.floor(r() * 3);
      for (let y = 0; y < h; y++) {
        px(ctx, ox + x, oy + y, y === 0 ? "#79bd52" : "#5f9e3d");
      }
    }
  },
  // 2 dirt
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#8b5e3c");
    speckle(ctx, ox, oy, ["#7b5234", "#9a6a44", "#6c482c", "#a1724b"], 33, 120);
  },
  // 3 stone
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#8a8a8a");
    speckle(ctx, ox, oy, ["#7c7c7c", "#999999", "#6e6e6e", "#a3a3a3"], 44, 120);
    const r = rng(45);
    for (let i = 0; i < 5; i++) {
      const x = Math.floor(r() * 12);
      const y = Math.floor(r() * 14);
      px(ctx, ox + x, oy + y, "#666666");
      px(ctx, ox + x + 1, oy + y, "#666666");
      px(ctx, ox + x + 1, oy + y + 1, "#666666");
    }
  },
  // 4 sand
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#e0cf9a");
    speckle(ctx, ox, oy, ["#d3c08a", "#ecdbA6".toLowerCase(), "#c9b47c"], 55, 90);
  },
  // 5 water
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#3a6fd8");
    speckle(ctx, ox, oy, ["#4a80e8", "#2f5fc0", "#5b8ef0"], 66, 70);
    const r = rng(67);
    for (let i = 0; i < 6; i++) {
      const y = Math.floor(r() * TILE);
      const x = Math.floor(r() * 10);
      ctx.fillStyle = "#6ba0f5";
      ctx.fillRect(ox + x, oy + y, 4, 1);
    }
  },
  // 6 log side
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#6b4a2b");
    for (let x = 0; x < TILE; x += 3) {
      ctx.fillStyle = x % 6 === 0 ? "#5a3c22" : "#7b5733";
      ctx.fillRect(ox + x, oy, 2, TILE);
    }
    speckle(ctx, ox, oy, ["#4e341d", "#8a6439"], 77, 40);
  },
  // 7 log top
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#8a6439");
    ctx.strokeStyle = "#6b4a2b";
    ctx.lineWidth = 1;
    for (let i = 1; i < 4; i++) {
      ctx.strokeRect(ox + i * 2, oy + i * 2, TILE - i * 4, TILE - i * 4);
    }
    speckle(ctx, ox, oy, ["#7b5733", "#99703f"], 88, 30);
  },
  // 8 leaves
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#3f7a2f");
    speckle(ctx, ox, oy, ["#356b28", "#4d8c39", "#2c5c21", "#5c9c44"], 99, 150);
  },
  // 9 planks
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#b0854a");
    for (let y = 0; y < TILE; y += 4) {
      ctx.fillStyle = "#8c6636";
      ctx.fillRect(ox, oy + y, TILE, 1);
    }
    speckle(ctx, ox, oy, ["#a37a43", "#bd9055"], 111, 60);
  },
  // 10 glass
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#bfe4f5");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(ox, oy, TILE, 1);
    ctx.fillRect(ox, oy, 1, TILE);
    ctx.fillStyle = "#8fc0dc";
    ctx.fillRect(ox, oy + TILE - 1, TILE, 1);
    ctx.fillRect(ox + TILE - 1, oy, 1, TILE);
    ctx.fillRect(ox + 3, oy + 3, 6, 1);
    ctx.fillRect(ox + 3, oy + 3, 1, 6);
  },
  // 11 brick
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#a24b38");
    ctx.fillStyle = "#cbb9a8";
    for (let y = 0; y < TILE; y += 4) ctx.fillRect(ox, oy + y, TILE, 1);
    for (let y = 0; y < TILE; y += 8) {
      for (let x = 0; x < TILE; x += 8) {
        ctx.fillRect(ox + x + ((y / 8) % 2 === 0 ? 0 : 4), oy + y, 1, 4);
      }
    }
    speckle(ctx, ox, oy, ["#93412f", "#b25a45"], 121, 40);
  },
  // 12 cobble
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#7d7d7d");
    const r = rng(133);
    for (let i = 0; i < 18; i++) {
      const x = Math.floor(r() * 13);
      const y = Math.floor(r() * 13);
      const w = 2 + Math.floor(r() * 3);
      ctx.fillStyle = ["#6b6b6b", "#8e8e8e", "#5c5c5c"][Math.floor(r() * 3)];
      ctx.fillRect(ox + x, oy + y, w, w);
    }
  },
  // 13 asphalt
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#3a3a3e");
    speckle(ctx, ox, oy, ["#2e2e32", "#46464b", "#252529"], 144, 120);
  },
  // 14 white concrete
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#e8e8e8");
    speckle(ctx, ox, oy, ["#dcdcdc", "#f2f2f2", "#cfcfcf"], 155, 45);
  },
  // 15 slate roof
  (ctx, ox, oy) => {
    fill(ctx, ox, oy, "#4a4a58");
    for (let y = 0; y < TILE; y += 4) {
      ctx.fillStyle = "#3b3b47";
      ctx.fillRect(ox, oy + y, TILE, 1);
    }
    speckle(ctx, ox, oy, ["#55556a", "#41414d"], 166, 50);
  },
];

let atlasCanvas: HTMLCanvasElement | null = null;

export function makeAtlasCanvas(): HTMLCanvasElement {
  if (atlasCanvas) return atlasCanvas;
  const c = document.createElement("canvas");
  c.width = TILE * ATLAS_COLS;
  c.height = TILE * ATLAS_ROWS;
  const ctx = c.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  DRAWERS.forEach((draw, i) => {
    const ox = (i % ATLAS_COLS) * TILE;
    const oy = Math.floor(i / ATLAS_COLS) * TILE;
    draw(ctx, ox, oy);
  });
  atlasCanvas = c;
  return c;
}

/** Data URL of a single atlas tile — used for hotbar / store icons. */
export function tileIcon(index: number, scale = 4): string {
  const src = makeAtlasCanvas();
  const c = document.createElement("canvas");
  c.width = TILE * scale;
  c.height = TILE * scale;
  const ctx = c.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  const ox = (index % ATLAS_COLS) * TILE;
  const oy = Math.floor(index / ATLAS_COLS) * TILE;
  ctx.drawImage(src, ox, oy, TILE, TILE, 0, 0, c.width, c.height);
  return c.toDataURL();
}

/** Flat tile used as the CSS background of inventory panels. */
export function flatTile(base: string, dots: string[], seed: number): string {
  const c = document.createElement("canvas");
  c.width = TILE;
  c.height = TILE;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, TILE, TILE);
  const r = rng(seed);
  for (let i = 0; i < 70; i++) {
    ctx.fillStyle = dots[Math.floor(r() * dots.length)];
    ctx.fillRect(Math.floor(r() * TILE), Math.floor(r() * TILE), 1, 1);
  }
  return `url(${c.toDataURL()})`;
}

/** Registers the dirt / stone panel backgrounds as CSS custom properties. */
export function installPanelTextures() {
  const root = document.documentElement;
  root.style.setProperty(
    "--dirt-tile",
    flatTile("#2b2118", ["#33271c", "#241a12", "#3b2c1f", "#20170f"], 909),
  );
  root.style.setProperty(
    "--stone-tile",
    flatTile("#4a4a4a", ["#545454", "#3f3f3f", "#5c5c5c", "#383838"], 707),
  );
}
