import Phaser from 'phaser';
import { BLOCK_TEX, GRAY_BLOCK, PALETTE, TEX, THEME } from './constants';

/* ---------- colour helpers ---------- */

export function hexCss(h: number): string {
  return '#' + (h >>> 0).toString(16).padStart(6, '0');
}

export function mix(a: number, b: number, t: number): number {
  const ar = (a >> 16) & 255;
  const ag = (a >> 8) & 255;
  const ab = a & 255;
  const br = (b >> 16) & 255;
  const bg = (b >> 8) & 255;
  const bb = b & 255;
  const r = Math.round(ar + (br - ar) * t);
  const g = Math.round(ag + (bg - ag) * t);
  const bl = Math.round(ab + (bb - ab) * t);
  return (r << 16) | (g << 8) | bl;
}

export const lighten = (h: number, t: number) => mix(h, 0xffffff, t);
export const darken = (h: number, t: number) => mix(h, 0x000000, t);

type Ctx = CanvasRenderingContext2D;

export function roundRectPath(ctx: Ctx, x: number, y: number, w: number, h: number, r: number): void {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.arcTo(x + w, y, x + w, y + rr, rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.arcTo(x + w, y + h, x + w - rr, y + h, rr);
  ctx.lineTo(x + rr, y + h);
  ctx.arcTo(x, y + h, x, y + h - rr, rr);
  ctx.lineTo(x, y + rr);
  ctx.arcTo(x, y, x + rr, y, rr);
  ctx.closePath();
}

/* ---------- block drawing ---------- */

function drawBlock(ctx: Ctx, S: number, base: number): void {
  const r = S * 0.17;
  const light = lighten(base, 0.45);
  const dark = darken(base, 0.34);

  roundRectPath(ctx, 0, 0, S, S, r);
  ctx.fillStyle = hexCss(dark);
  ctx.fill();

  ctx.save();
  roundRectPath(ctx, 0, 0, S, S, r);
  ctx.clip();
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(S, 0);
  ctx.lineTo(0, S);
  ctx.closePath();
  ctx.fillStyle = hexCss(light);
  ctx.fill();
  ctx.restore();

  const inset = S * 0.14;
  const iw = S - inset * 2;
  roundRectPath(ctx, inset, inset, iw, iw, r * 0.55);
  const g = ctx.createLinearGradient(0, inset, 0, inset + iw);
  g.addColorStop(0, hexCss(lighten(base, 0.16)));
  g.addColorStop(1, hexCss(darken(base, 0.08)));
  ctx.fillStyle = g;
  ctx.fill();

  ctx.save();
  roundRectPath(ctx, inset, inset, iw, iw, r * 0.55);
  ctx.clip();
  const gl = ctx.createLinearGradient(0, inset, 0, inset + iw * 0.5);
  gl.addColorStop(0, 'rgba(255,255,255,0.30)');
  gl.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = gl;
  ctx.fillRect(inset, inset, iw, iw * 0.5);
  ctx.restore();
}

function drawCell(ctx: Ctx, S: number): void {
  roundRectPath(ctx, 0, 0, S, S, S * 0.17);
  const g = ctx.createLinearGradient(0, 0, 0, S);
  g.addColorStop(0, hexCss(THEME.cellDark));
  g.addColorStop(1, hexCss(THEME.cell));
  ctx.fillStyle = g;
  ctx.fill();
}

/* ---------- icons (64x64, white) ---------- */

type IconFn = (ctx: Ctx) => void;

const ICONS: Record<string, IconFn> = {
  crown: (ctx) => {
    ctx.beginPath();
    ctx.moveTo(8, 46);
    ctx.lineTo(6, 20);
    ctx.lineTo(20, 31);
    ctx.lineTo(32, 12);
    ctx.lineTo(44, 31);
    ctx.lineTo(58, 20);
    ctx.lineTo(56, 46);
    ctx.closePath();
    ctx.fill();
    roundRectPath(ctx, 8, 49, 48, 8, 3);
    ctx.fill();
  },
  gear: (ctx) => {
    ctx.save();
    ctx.translate(32, 32);
    for (let i = 0; i < 8; i++) {
      ctx.save();
      ctx.rotate((i * Math.PI) / 4);
      roundRectPath(ctx, -6, -29, 12, 14, 3);
      ctx.fill();
      ctx.restore();
    }
    ctx.beginPath();
    ctx.arc(0, 0, 21, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(0, 0, 9, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  },
  pause: (ctx) => {
    roundRectPath(ctx, 14, 12, 13, 40, 4);
    ctx.fill();
    roundRectPath(ctx, 37, 12, 13, 40, 4);
    ctx.fill();
  },
  play: (ctx) => {
    ctx.beginPath();
    ctx.moveTo(20, 12);
    ctx.lineTo(54, 32);
    ctx.lineTo(20, 52);
    ctx.closePath();
    ctx.fill();
  },
  home: (ctx) => {
    ctx.beginPath();
    ctx.moveTo(32, 8);
    ctx.lineTo(58, 32);
    ctx.lineTo(50, 32);
    ctx.lineTo(50, 56);
    ctx.lineTo(38, 56);
    ctx.lineTo(38, 40);
    ctx.lineTo(26, 40);
    ctx.lineTo(26, 56);
    ctx.lineTo(14, 56);
    ctx.lineTo(14, 32);
    ctx.lineTo(6, 32);
    ctx.closePath();
    ctx.fill();
  },
  replay: (ctx) => {
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.arc(32, 34, 20, -Math.PI * 0.35, Math.PI * 1.45);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(36, 4);
    ctx.lineTo(50, 16);
    ctx.lineTo(34, 26);
    ctx.closePath();
    ctx.fill();
  },
  close: (ctx) => {
    ctx.save();
    ctx.translate(32, 32);
    ctx.rotate(Math.PI / 4);
    roundRectPath(ctx, -26, -6, 52, 12, 5);
    ctx.fill();
    roundRectPath(ctx, -6, -26, 12, 52, 5);
    ctx.fill();
    ctx.restore();
  },
  sound_on: (ctx) => {
    ctx.beginPath();
    ctx.moveTo(8, 24);
    ctx.lineTo(20, 24);
    ctx.lineTo(34, 12);
    ctx.lineTo(34, 52);
    ctx.lineTo(20, 40);
    ctx.lineTo(8, 40);
    ctx.closePath();
    ctx.fill();
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.arc(36, 32, 11, -Math.PI / 3, Math.PI / 3);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(36, 32, 20, -Math.PI / 3, Math.PI / 3);
    ctx.stroke();
  },
  sound_off: (ctx) => {
    ctx.beginPath();
    ctx.moveTo(8, 24);
    ctx.lineTo(20, 24);
    ctx.lineTo(34, 12);
    ctx.lineTo(34, 52);
    ctx.lineTo(20, 40);
    ctx.lineTo(8, 40);
    ctx.closePath();
    ctx.fill();
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(42, 24);
    ctx.lineTo(58, 40);
    ctx.moveTo(58, 24);
    ctx.lineTo(42, 40);
    ctx.stroke();
  },
  vib_on: (ctx) => {
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    roundRectPath(ctx, 21, 10, 22, 44, 5);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(12, 20);
    ctx.lineTo(12, 44);
    ctx.moveTo(52, 20);
    ctx.lineTo(52, 44);
    ctx.moveTo(4, 26);
    ctx.lineTo(4, 38);
    ctx.moveTo(60, 26);
    ctx.lineTo(60, 38);
    ctx.stroke();
  },
  vib_off: (ctx) => {
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    roundRectPath(ctx, 21, 10, 22, 44, 5);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(10, 8);
    ctx.lineTo(54, 56);
    ctx.stroke();
  },
  star: (ctx) => {
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const rad = i % 2 === 0 ? 28 : 12;
      const a = -Math.PI / 2 + (i * Math.PI) / 5;
      const x = 32 + Math.cos(a) * rad;
      const y = 34 + Math.sin(a) * rad;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
  },
  trophy: (ctx) => {
    roundRectPath(ctx, 16, 6, 32, 30, 6);
    ctx.fill();
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(14, 18, 8, Math.PI * 0.5, Math.PI * 1.5);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(50, 18, 8, -Math.PI * 0.5, Math.PI * 0.5);
    ctx.stroke();
    ctx.fillRect(28, 34, 8, 12);
    roundRectPath(ctx, 18, 46, 28, 10, 3);
    ctx.fill();
  },
};

/* ---------- atlas builder ---------- */

export function buildTextures(scene: Phaser.Scene): void {
  if (scene.textures.exists(TEX)) return;

  const size = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const frames: Array<{ name: string; x: number; y: number; w: number; h: number }> = [];
  const pad = 4;
  let cx = 0;
  let cy = 0;
  let rowH = 0;

  const draw = (name: string, w: number, h: number, fn: (c: Ctx, w: number, h: number) => void) => {
    if (cx + w + pad > size) {
      cx = 0;
      cy += rowH + pad;
      rowH = 0;
    }
    ctx.save();
    ctx.translate(cx, cy);
    ctx.beginPath();
    ctx.rect(0, 0, w, h);
    ctx.clip();
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#ffffff';
    fn(ctx, w, h);
    ctx.restore();
    frames.push({ name, x: cx, y: cy, w, h });
    cx += w + pad;
    rowH = Math.max(rowH, h);
  };

  const BS = BLOCK_TEX;
  PALETTE.forEach((color, i) => draw(`block_${i}`, BS, BS, (c) => drawBlock(c, BS, color)));
  draw('block_gray', BS, BS, (c) => drawBlock(c, BS, GRAY_BLOCK));
  draw('cell', BS, BS, (c) => drawCell(c, BS));
  draw('flat', BS, BS, (c) => {
    roundRectPath(c, 0, 0, BS, BS, BS * 0.17);
    c.fill();
  });
  draw('white', 16, 16, (c) => c.fillRect(0, 0, 16, 16));
  draw('particle', 28, 28, (c) => {
    roundRectPath(c, 2, 2, 24, 24, 6);
    c.fill();
  });
  draw('circle', 96, 96, (c) => {
    c.beginPath();
    c.arc(48, 48, 46, 0, Math.PI * 2);
    c.fill();
  });
  draw('glow', 160, 160, (c) => {
    const g = c.createRadialGradient(80, 80, 0, 80, 80, 80);
    g.addColorStop(0, 'rgba(255,255,255,1)');
    g.addColorStop(0.35, 'rgba(255,255,255,0.55)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    c.fillStyle = g;
    c.fillRect(0, 0, 160, 160);
  });
  Object.entries(ICONS).forEach(([name, fn]) => draw(`icon_${name}`, 64, 64, (c) => fn(c)));

  const tex = scene.textures.addCanvas(TEX, canvas);
  if (!tex) return;
  for (const f of frames) tex.add(f.name, 0, f.x, f.y, f.w, f.h);

  // Background gradient (stretched to the full screen).
  const bg = scene.textures.createCanvas('bg', 16, 512);
  if (bg) {
    const g = bg.context.createLinearGradient(0, 0, 0, 512);
    g.addColorStop(0, THEME.bgTop);
    g.addColorStop(1, THEME.bgBottom);
    bg.context.fillStyle = g;
    bg.context.fillRect(0, 0, 16, 512);
    bg.refresh();
  }
}

/* ---------- on-demand rounded rectangles (buttons, panels) ---------- */

export interface RoundedOpts {
  /** Darker "3D" edge drawn below the face. */
  edge?: string;
  edgeH?: number;
  border?: string;
  borderW?: number;
}

/** Returns a texture key with a rounded rect of exactly w×h px (cached). */
export function roundedTexture(
  scene: Phaser.Scene,
  w: number,
  h: number,
  radius: number,
  fill: string | string[],
  opts: RoundedOpts = {}
): string {
  w = Math.max(2, Math.round(w));
  h = Math.max(2, Math.round(h));
  const fills = Array.isArray(fill) ? fill : [fill];
  const key = `rr|${w}x${h}|${radius.toFixed(1)}|${fills.join(',')}|${opts.edge ?? ''}|${opts.edgeH ?? 0}|${opts.border ?? ''}|${opts.borderW ?? 0}`;
  if (scene.textures.exists(key)) return key;

  const tex = scene.textures.createCanvas(key, w, h);
  if (!tex) return TEX;
  const ctx = tex.context;
  const edgeH = opts.edge ? Math.round(opts.edgeH ?? 0) : 0;
  const bw = opts.border ? opts.borderW ?? 0 : 0;

  if (edgeH > 0) {
    roundRectPath(ctx, 0, edgeH, w, h - edgeH, radius);
    ctx.fillStyle = opts.edge!;
    ctx.fill();
  }
  roundRectPath(ctx, 0, 0, w, h - edgeH, radius);
  if (fills.length > 1) {
    const g = ctx.createLinearGradient(0, 0, 0, h - edgeH);
    fills.forEach((f, i) => g.addColorStop(i / (fills.length - 1), f));
    ctx.fillStyle = g;
  } else {
    ctx.fillStyle = fills[0];
  }
  ctx.fill();
  if (bw > 0) {
    roundRectPath(ctx, bw / 2, bw / 2, w - bw, h - edgeH - bw, Math.max(1, radius - bw / 2));
    ctx.lineWidth = bw;
    ctx.strokeStyle = opts.border!;
    ctx.stroke();
  }
  tex.refresh();
  return key;
}
