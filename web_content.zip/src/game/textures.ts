import * as THREE from 'three';
import type { SkinColors } from './store';

function rng(seed: number) {
  let s = seed >>> 0;
  return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
}

function canvas(size = 256) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  return [c, c.getContext('2d')!] as const;
}

function noise(ctx: CanvasRenderingContext2D, size: number, amount: number, r: () => number, mono = true) {
  const img = ctx.getImageData(0, 0, size, size);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (r() - 0.5) * amount;
    const n2 = mono ? n : (r() - 0.5) * amount;
    d[i] = Math.max(0, Math.min(255, d[i] + n));
    d[i + 1] = Math.max(0, Math.min(255, d[i + 1] + n2));
    d[i + 2] = Math.max(0, Math.min(255, d[i + 2] + n));
  }
  ctx.putImageData(img, 0, 0);
}

function blotches(ctx: CanvasRenderingContext2D, size: number, count: number, color: string, r: () => number, maxR = 40, alpha = 0.15) {
  ctx.save();
  for (let i = 0; i < count; i++) {
    const x = r() * size, y = r() * size, rad = 5 + r() * maxR;
    const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
    g.addColorStop(0, color);
    g.addColorStop(1, 'transparent');
    ctx.globalAlpha = alpha * (0.4 + r());
    ctx.fillStyle = g;
    for (const ox of [-size, 0, size]) for (const oy of [-size, 0, size]) {
      ctx.save(); ctx.translate(ox, oy); ctx.beginPath(); ctx.arc(x, y, rad, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    }
  }
  ctx.restore();
}

function toTex(c: HTMLCanvasElement, repeat = true) {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
  t.anisotropy = 4;
  t.generateMipmaps = true;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  return t;
}

function blocks(ctx: CanvasRenderingContext2D, size: number, rows: number, cols: number, base: string[], mortar: string, r: () => number, mortarW = 3, bevel = true) {
  ctx.fillStyle = mortar;
  ctx.fillRect(0, 0, size, size);
  const bh = size / rows;
  for (let y = 0; y < rows; y++) {
    const bw = size / cols;
    const off = (y % 2) * bw / 2;
    for (let x = -1; x <= cols; x++) {
      const px = x * bw + off, py = y * bh;
      ctx.fillStyle = base[Math.floor(r() * base.length)];
      ctx.fillRect(px + mortarW / 2, py + mortarW / 2, bw - mortarW, bh - mortarW);
      if (bevel) {
        ctx.fillStyle = 'rgba(255,255,255,0.08)';
        ctx.fillRect(px + mortarW / 2, py + mortarW / 2, bw - mortarW, 2);
        ctx.fillStyle = 'rgba(0,0,0,0.18)';
        ctx.fillRect(px + mortarW / 2, py + bh - mortarW / 2 - 2, bw - mortarW, 2);
      }
    }
  }
}

export type TexName = 'sand' | 'sandstone' | 'brick' | 'stone' | 'concrete' | 'snow' | 'grass' | 'crate' | 'container' | 'containerRed' | 'tiles' | 'metal' | 'darkConcrete' | 'plaster' | 'snowWall';

const cache = new Map<string, THREE.Texture>();

export function getTex(name: TexName): THREE.Texture {
  if (cache.has(name)) return cache.get(name)!;
  const size = 256;
  const [c, ctx] = canvas(size);
  const r = rng(name.length * 977 + name.charCodeAt(0) * 31);
  switch (name) {
    case 'sand': {
      ctx.fillStyle = '#d9b77e'; ctx.fillRect(0, 0, size, size);
      blotches(ctx, size, 40, '#b8925a', r, 50, 0.25);
      blotches(ctx, size, 30, '#ecd3a0', r, 40, 0.25);
      ctx.strokeStyle = 'rgba(150,110,60,0.12)'; ctx.lineWidth = 2;
      for (let i = 0; i < 14; i++) { ctx.beginPath(); const y = r() * size; ctx.moveTo(0, y); ctx.bezierCurveTo(80, y + 10, 170, y - 10, 256, y); ctx.stroke(); }
      noise(ctx, size, 40, r);
      break;
    }
    case 'sandstone': {
      blocks(ctx, size, 6, 3, ['#d4b07a', '#cfa970', '#dbb985', '#c9a067', '#d8b47c'], '#a88656', r, 4);
      blotches(ctx, size, 20, '#8a6a40', r, 30, 0.12);
      noise(ctx, size, 30, r);
      break;
    }
    case 'plaster': {
      ctx.fillStyle = '#e2cfa6'; ctx.fillRect(0, 0, size, size);
      blotches(ctx, size, 30, '#b99a6a', r, 45, 0.2);
      blotches(ctx, size, 10, '#ffffff', r, 30, 0.12);
      noise(ctx, size, 26, r);
      break;
    }
    case 'brick': {
      blocks(ctx, size, 10, 4, ['#8e3b2a', '#9b4430', '#7d3324', '#a24c36', '#87402c'], '#a99a8a', r, 4);
      blotches(ctx, size, 25, '#2a1a10', r, 30, 0.15);
      noise(ctx, size, 34, r);
      break;
    }
    case 'stone': {
      ctx.fillStyle = '#77776f'; ctx.fillRect(0, 0, size, size);
      const rows = 5;
      for (let y = 0; y < rows; y++) {
        let x = -r() * 40;
        while (x < size) {
          const w = 40 + r() * 50; const v = 110 + r() * 50;
          ctx.fillStyle = `rgb(${v},${v},${v - 6})`;
          ctx.fillRect(x + 2, y * (size / rows) + 2, w - 4, size / rows - 4);
          ctx.fillStyle = 'rgba(0,0,0,0.2)'; ctx.fillRect(x + 2, (y + 1) * (size / rows) - 5, w - 4, 3);
          x += w;
        }
      }
      blotches(ctx, size, 25, '#4b5a3a', r, 30, 0.2);
      noise(ctx, size, 40, r);
      break;
    }
    case 'concrete': case 'darkConcrete': {
      ctx.fillStyle = name === 'concrete' ? '#9a9a96' : '#55575a'; ctx.fillRect(0, 0, size, size);
      blotches(ctx, size, 40, '#3a3a3a', r, 40, 0.15);
      blotches(ctx, size, 20, '#c0c0bb', r, 30, 0.1);
      ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 2;
      ctx.strokeRect(1, 1, size - 2, size - 2);
      ctx.beginPath(); ctx.moveTo(0, size / 2); ctx.lineTo(size, size / 2); ctx.stroke();
      noise(ctx, size, 30, r);
      break;
    }
    case 'snow': {
      ctx.fillStyle = '#e9eff6'; ctx.fillRect(0, 0, size, size);
      blotches(ctx, size, 40, '#b9c8da', r, 40, 0.25);
      blotches(ctx, size, 20, '#ffffff', r, 30, 0.4);
      noise(ctx, size, 18, r);
      break;
    }
    case 'snowWall': {
      blocks(ctx, size, 4, 2, ['#8e9399', '#999ea4', '#868b91'], '#6a6e73', r, 4);
      const g = ctx.createLinearGradient(0, 0, 0, 40);
      g.addColorStop(0, 'rgba(255,255,255,0.95)'); g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, size, 40);
      noise(ctx, size, 26, r);
      break;
    }
    case 'grass': {
      ctx.fillStyle = '#5f8a3a'; ctx.fillRect(0, 0, size, size);
      blotches(ctx, size, 40, '#3f6a24', r, 40, 0.3);
      blotches(ctx, size, 30, '#8aa84e', r, 30, 0.25);
      for (let i = 0; i < 1400; i++) {
        const x = r() * size, y = r() * size;
        ctx.strokeStyle = `rgba(${40 + r() * 60},${90 + r() * 80},${20 + r() * 40},0.7)`;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + (r() - 0.5) * 4, y - 3 - r() * 5); ctx.stroke();
      }
      noise(ctx, size, 25, r);
      break;
    }
    case 'crate': {
      ctx.fillStyle = '#8a6236'; ctx.fillRect(0, 0, size, size);
      for (let i = 0; i < 6; i++) {
        ctx.fillStyle = ['#946a3c', '#87602f', '#9b7344', '#80592c'][i % 4];
        ctx.fillRect(0, i * size / 6, size, size / 6 - 2);
        ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(0, (i + 1) * size / 6 - 2, size, 2);
      }
      for (let i = 0; i < 70; i++) { ctx.strokeStyle = 'rgba(60,35,10,0.25)'; ctx.beginPath(); const y = r() * size; ctx.moveTo(0, y); ctx.lineTo(size, y + (r() - 0.5) * 6); ctx.stroke(); }
      const bw = 26;
      ctx.fillStyle = '#6e4b25';
      ctx.fillRect(0, 0, size, bw); ctx.fillRect(0, size - bw, size, bw); ctx.fillRect(0, 0, bw, size); ctx.fillRect(size - bw, 0, bw, size);
      ctx.save(); ctx.translate(size / 2, size / 2); ctx.rotate(Math.PI / 4);
      ctx.fillRect(-size * 0.68, -bw / 2, size * 1.36, bw); ctx.rotate(-Math.PI / 2); ctx.fillRect(-size * 0.68, -bw / 2, size * 1.36, bw);
      ctx.restore();
      ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = 3; ctx.strokeRect(bw, bw, size - 2 * bw, size - 2 * bw); ctx.strokeRect(1, 1, size - 2, size - 2);
      ctx.fillStyle = '#2a2a2a';
      for (const [x, y] of [[13, 13], [size - 13, 13], [13, size - 13], [size - 13, size - 13]]) { ctx.beginPath(); ctx.arc(x, y, 4, 0, 7); ctx.fill(); }
      noise(ctx, size, 26, r);
      break;
    }
    case 'container': case 'containerRed': {
      const base = name === 'container' ? '#2f5f8f' : '#9a3226';
      ctx.fillStyle = base; ctx.fillRect(0, 0, size, size);
      for (let x = 0; x < size; x += 16) {
        ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect(x, 0, 4, size);
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x + 10, 0, 4, size);
      }
      ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(0, 0, size, 10); ctx.fillRect(0, size - 10, size, 10);
      blotches(ctx, size, 25, '#5a3010', r, 20, 0.3);
      ctx.font = 'bold 40px sans-serif'; ctx.fillStyle = 'rgba(255,255,255,0.75)'; ctx.fillText('CR', 30, 80);
      noise(ctx, size, 22, r);
      break;
    }
    case 'tiles': {
      for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
        const v = 150 + r() * 30;
        ctx.fillStyle = `rgb(${v},${v - 8},${v - 20})`;
        ctx.fillRect(x * 32, y * 32, 32, 32);
        ctx.strokeStyle = 'rgba(60,50,40,0.6)'; ctx.strokeRect(x * 32 + 0.5, y * 32 + 0.5, 31, 31);
      }
      blotches(ctx, size, 30, '#6a5a40', r, 30, 0.15);
      noise(ctx, size, 22, r);
      break;
    }
    case 'metal': {
      ctx.fillStyle = '#5a5f66'; ctx.fillRect(0, 0, size, size);
      for (let y = 0; y < size; y += 64) for (let x = 0; x < size; x += 64) {
        ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = 2; ctx.strokeRect(x + 1, y + 1, 62, 62);
        ctx.fillStyle = '#2a2d30'; for (const [a, b] of [[6, 6], [58, 6], [6, 58], [58, 58]]) { ctx.beginPath(); ctx.arc(x + a, y + b, 2.5, 0, 7); ctx.fill(); }
      }
      blotches(ctx, size, 20, '#6a3a1a', r, 20, 0.25);
      noise(ctx, size, 20, r);
      break;
    }
  }
  const t = toTex(c);
  cache.set(name, t);
  return t;
}

/* ---------- Gun skin texture ---------- */
export function skinTexture(s: SkinColors): THREE.Texture {
  const size = 256;
  const [c, ctx] = canvas(size);
  const r = rng(s.c1.charCodeAt(1) * 13 + s.c2.charCodeAt(2) * 7 + s.pattern.length);
  ctx.fillStyle = s.c1; ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = s.c2;
  switch (s.pattern) {
    case 'stripes':
      for (let i = -size; i < size * 2; i += 48) { ctx.save(); ctx.translate(i, 0); ctx.rotate(0.5); ctx.fillRect(0, -50, 16, size * 2); ctx.restore(); }
      break;
    case 'camo':
      for (let i = 0; i < 26; i++) { ctx.beginPath(); const x = r() * size, y = r() * size; ctx.ellipse(x, y, 10 + r() * 30, 6 + r() * 18, r() * 3, 0, 7); ctx.fill(); }
      break;
    case 'tiger':
      ctx.lineWidth = 7; ctx.strokeStyle = s.c2; ctx.lineCap = 'round';
      for (let i = 0; i < 18; i++) {
        const x = r() * size; ctx.beginPath(); ctx.moveTo(x, 0);
        ctx.bezierCurveTo(x + 30 * (r() - .5), size * .3, x + 50 * (r() - .5), size * .6, x + 20 * (r() - .5), size); ctx.stroke();
      }
      break;
    case 'digital':
      for (let i = 0; i < 260; i++) { const sz = 8 * (1 + Math.floor(r() * 2)); ctx.fillRect(Math.floor(r() * 32) * 8, Math.floor(r() * 32) * 8, sz, sz); }
      break;
    case 'hex': {
      ctx.strokeStyle = s.c2; ctx.lineWidth = 3;
      const h = 22;
      for (let y = 0; y < size + h; y += h * 0.87) for (let x = 0; x < size + h; x += h * 1.5) {
        const ox = (Math.round(y / (h * 0.87)) % 2) * h * 0.75;
        ctx.beginPath();
        for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3; ctx.lineTo(x + ox + Math.cos(a) * h / 2, y + Math.sin(a) * h / 2); }
        ctx.closePath(); ctx.stroke();
      }
      break;
    }
    default: break;
  }
  noise(ctx, size, 14, r);
  const t = toTex(c);
  return t;
}

export function flashTexture(): THREE.Texture {
  if (cache.has('__flash')) return cache.get('__flash')!;
  const size = 128;
  const [c, ctx] = canvas(size);
  const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, 'rgba(255,255,230,1)');
  g.addColorStop(0.2, 'rgba(255,220,120,0.9)');
  g.addColorStop(0.5, 'rgba(255,140,30,0.35)');
  g.addColorStop(1, 'rgba(255,100,0,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = 'rgba(255,240,180,0.9)';
  for (let i = 0; i < 6; i++) {
    ctx.save(); ctx.translate(64, 64); ctx.rotate(i * Math.PI / 3);
    ctx.beginPath(); ctx.moveTo(-5, 0); ctx.lineTo(0, -62); ctx.lineTo(5, 0); ctx.fill(); ctx.restore();
  }
  const t = toTex(c, false);
  cache.set('__flash', t);
  return t;
}

export function dotTexture(): THREE.Texture {
  if (cache.has('__dot')) return cache.get('__dot')!;
  const [c, ctx] = canvas(64);
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.4, 'rgba(255,255,255,0.7)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, 64, 64);
  const t = toTex(c, false);
  cache.set('__dot', t);
  return t;
}

export function holeTexture(): THREE.Texture {
  if (cache.has('__hole')) return cache.get('__hole')!;
  const [c, ctx] = canvas(64);
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 30);
  g.addColorStop(0, 'rgba(0,0,0,1)');
  g.addColorStop(0.3, 'rgba(20,15,10,0.9)');
  g.addColorStop(0.6, 'rgba(40,30,20,0.4)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, 64, 64);
  const t = toTex(c, false);
  cache.set('__hole', t);
  return t;
}

export function markerTexture(color: string): THREE.Texture {
  const key = '__mk' + color;
  if (cache.has(key)) return cache.get(key)!;
  const [c, ctx] = canvas(64);
  ctx.fillStyle = color; ctx.strokeStyle = '#000'; ctx.lineWidth = 4;
  ctx.beginPath(); ctx.moveTo(12, 14); ctx.lineTo(52, 14); ctx.lineTo(32, 48); ctx.closePath(); ctx.stroke(); ctx.fill();
  const t = toTex(c, false);
  cache.set(key, t);
  return t;
}
