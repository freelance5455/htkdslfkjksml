// Procedurally generated PBR-ish textures. Everything is painted on 2D canvases at
// runtime so the game has zero external asset dependencies but still shows detail.
import * as THREE from 'three';
import { makeRng } from './util';

const cache = new Map<string, any>();

function canvas(w: number, h = w) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return c;
}

function finish(c: HTMLCanvasElement, repeat = 1, aniso = 4) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat, repeat);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = aniso;
  t.needsUpdate = true;
  return t;
}

/** Speckled noise used by most ground surfaces. */
function speckle(ctx: CanvasRenderingContext2D, w: number, h: number, rng: () => number, count: number, colors: string[], sizeMin = 1, sizeMax = 3) {
  for (let i = 0; i < count; i++) {
    ctx.fillStyle = colors[Math.floor(rng() * colors.length)];
    const s = sizeMin + rng() * (sizeMax - sizeMin);
    ctx.fillRect(rng() * w, rng() * h, s, s);
  }
}

/** Derive a normal map from a grayscale height canvas. */
function normalFromHeight(src: HTMLCanvasElement, strength = 2) {
  const w = src.width;
  const h = src.height;
  const sctx = src.getContext('2d')!;
  const data = sctx.getImageData(0, 0, w, h).data;
  const out = canvas(w, h);
  const octx = out.getContext('2d')!;
  const img = octx.createImageData(w, h);
  const at = (x: number, y: number) => {
    const xx = (x + w) % w;
    const yy = (y + h) % h;
    return data[(yy * w + xx) * 4] / 255;
  };
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const dx = (at(x - 1, y) - at(x + 1, y)) * strength;
      const dy = (at(x, y - 1) - at(x, y + 1)) * strength;
      const len = Math.hypot(dx, dy, 1);
      const i = (y * w + x) * 4;
      img.data[i] = ((dx / len) * 0.5 + 0.5) * 255;
      img.data[i + 1] = ((dy / len) * 0.5 + 0.5) * 255;
      img.data[i + 2] = ((1 / len) * 0.5 + 0.5) * 255;
      img.data[i + 3] = 255;
    }
  }
  octx.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(out);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

function noiseHeight(w: number, h: number, rng: () => number, blobs = 900) {
  const c = canvas(w, h);
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, w, h);
  for (let i = 0; i < blobs; i++) {
    const v = Math.floor(rng() * 255);
    ctx.fillStyle = `rgb(${v},${v},${v})`;
    const r = 1 + rng() * 6;
    ctx.beginPath();
    ctx.arc(rng() * w, rng() * h, r, 0, Math.PI * 2);
    ctx.fill();
  }
  return c;
}

export function asphaltTexture() {
  if (cache.has('asphalt')) return cache.get('asphalt')!;
  const rng = makeRng(11);
  const s = 512;
  const c = canvas(s);
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#2e3033';
  ctx.fillRect(0, 0, s, s);
  speckle(ctx, s, s, rng, 9000, ['#3a3d40', '#26282a', '#43464a', '#1e2022'], 1, 3);
  // faint cracks + patches
  ctx.strokeStyle = 'rgba(20,20,22,0.65)';
  for (let i = 0; i < 26; i++) {
    ctx.lineWidth = 0.6 + rng() * 1.6;
    ctx.beginPath();
    let x = rng() * s;
    let y = rng() * s;
    ctx.moveTo(x, y);
    for (let j = 0; j < 6; j++) {
      x += (rng() - 0.5) * 60;
      y += (rng() - 0.5) * 60;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  const tex = finish(c, 1, 8);
  const height = noiseHeight(s, s, rng, 1400);
  const nrm = normalFromHeight(height, 1.1);
  nrm.repeat.set(1, 1);
  cache.set('asphalt', tex);
  cache.set('asphaltN', nrm);
  return tex;
}

export function asphaltNormal() {
  asphaltTexture();
  return cache.get('asphaltN')!;
}

export function concreteTexture(tint = '#b9b6ae') {
  const key = 'concrete' + tint;
  if (cache.has(key)) return cache.get(key)!;
  const rng = makeRng(23);
  const s = 512;
  const c = canvas(s);
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = tint;
  ctx.fillRect(0, 0, s, s);
  speckle(ctx, s, s, rng, 6000, ['#a8a59d', '#c8c5bd', '#9d9a92'], 1, 4);
  for (let i = 0; i < 14; i++) {
    ctx.fillStyle = 'rgba(120,118,112,0.12)';
    ctx.fillRect(rng() * s, rng() * s, 30 + rng() * 90, 20 + rng() * 70);
  }
  const t = finish(c, 1, 4);
  cache.set(key, t);
  return t;
}

export function grassTexture() {
  if (cache.has('grass')) return cache.get('grass')!;
  const rng = makeRng(77);
  const s = 512;
  const c = canvas(s);
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#3f5f2c';
  ctx.fillRect(0, 0, s, s);
  speckle(ctx, s, s, rng, 20000, ['#4a6f31', '#385426', '#567a38', '#2c441e'], 1, 4);
  for (let i = 0; i < 2500; i++) {
    ctx.strokeStyle = `rgba(${90 + rng() * 60},${120 + rng() * 60},${40 + rng() * 40},0.5)`;
    ctx.lineWidth = 1;
    const x = rng() * s;
    const y = rng() * s;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + (rng() - 0.5) * 4, y - 3 - rng() * 6);
    ctx.stroke();
  }
  const t = finish(c, 1, 8);
  cache.set('grass', t);
  return t;
}

export function soilTexture() {
  if (cache.has('soil')) return cache.get('soil')!;
  const rng = makeRng(91);
  const s = 256;
  const c = canvas(s);
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#5a4632';
  ctx.fillRect(0, 0, s, s);
  speckle(ctx, s, s, rng, 5000, ['#6b543c', '#4a3928', '#71593f'], 1, 4);
  const t = finish(c, 1, 4);
  cache.set('soil', t);
  return t;
}

/** Building facade with window rows. Returns {map, emissive} */
export function facadeTexture(
  wallColor: string,
  cols: number,
  rows: number,
  windowColor = '#10151c',
  seed = 5
) {
  const key = `facade${wallColor}${cols}${rows}${seed}`;
  if (cache.has(key)) return cache.get(key)! as any;
  const rng = makeRng(seed);
  const s = 512;
  const c = canvas(s);
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = wallColor;
  ctx.fillRect(0, 0, s, s);
  speckle(ctx, s, s, rng, 5000, ['rgba(0,0,0,0.05)', 'rgba(255,255,255,0.05)'], 1, 5);
  const e = canvas(s);
  const ectx = e.getContext('2d')!;
  ectx.fillStyle = '#000';
  ectx.fillRect(0, 0, s, s);

  const cw = s / cols;
  const ch = s / rows;
  const pad = cw * 0.22;
  for (let r = 0; r < rows; r++) {
    for (let col = 0; col < cols; col++) {
      const x = col * cw + pad;
      const y = r * ch + ch * 0.22;
      const w = cw - pad * 2;
      const h = ch * 0.56;
      // frame
      ctx.fillStyle = 'rgba(20,20,24,0.55)';
      ctx.fillRect(x - 2, y - 2, w + 4, h + 4);
      ctx.fillStyle = windowColor;
      ctx.fillRect(x, y, w, h);
      // reflection sheen
      const g = ctx.createLinearGradient(x, y, x + w, y + h);
      g.addColorStop(0, 'rgba(180,210,240,0.30)');
      g.addColorStop(0.45, 'rgba(180,210,240,0.05)');
      g.addColorStop(1, 'rgba(0,0,0,0.10)');
      ctx.fillStyle = g;
      ctx.fillRect(x, y, w, h);
      // mullion
      ctx.strokeStyle = 'rgba(30,30,34,0.8)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(x + w / 2, y);
      ctx.lineTo(x + w / 2, y + h);
      ctx.stroke();
      // lit windows (emissive)
      if (rng() < 0.42) {
        const warm = rng() < 0.75;
        ectx.fillStyle = warm
          ? `rgba(${210 + rng() * 40},${170 + rng() * 50},${90 + rng() * 40},1)`
          : `rgba(${120 + rng() * 40},${170 + rng() * 40},${210 + rng() * 40},1)`;
        ectx.fillRect(x, y, w, h);
        ctx.fillStyle = 'rgba(255,225,170,0.25)';
        ctx.fillRect(x, y, w, h);
      }
    }
    // floor separator band
    ctx.fillStyle = 'rgba(0,0,0,0.10)';
    ctx.fillRect(0, r * ch + ch * 0.84, s, ch * 0.06);
  }
  const map = finish(c, 1, 8);
  const emissive = finish(e, 1, 4);
  cache.set(key, { map, emissive });
  return { map, emissive };
}

export function woodTexture(base = '#7a5334', plank = 6) {
  const key = 'wood' + base + plank;
  if (cache.has(key)) return cache.get(key)!;
  const rng = makeRng(303);
  const s = 512;
  const c = canvas(s);
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, s, s);
  const pw = s / plank;
  for (let i = 0; i < plank; i++) {
    const x = i * pw;
    ctx.fillStyle = `rgba(${rng() * 40 - 20 + 60},${rng() * 30 - 15 + 40},${rng() * 25 - 12 + 25},0.35)`;
    ctx.fillRect(x, 0, pw, s);
    // grain
    for (let g = 0; g < 60; g++) {
      ctx.strokeStyle = `rgba(40,25,12,${0.04 + rng() * 0.09})`;
      ctx.lineWidth = 0.6 + rng() * 1.6;
      ctx.beginPath();
      const gx = x + rng() * pw;
      ctx.moveTo(gx, 0);
      let cy = 0;
      while (cy < s) {
        cy += 24;
        ctx.lineTo(gx + (rng() - 0.5) * 5, cy);
      }
      ctx.stroke();
    }
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.fillRect(x, 0, 2, s);
  }
  const t = finish(c, 1, 8);
  cache.set(key, t);
  return t;
}

export function tileTexture(base = '#d8d2c6', grout = '#a39b8e', n = 8) {
  const key = 'tile' + base + n;
  if (cache.has(key)) return cache.get(key)!;
  const rng = makeRng(404);
  const s = 512;
  const c = canvas(s);
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = grout;
  ctx.fillRect(0, 0, s, s);
  const t = s / n;
  for (let y = 0; y < n; y++)
    for (let x = 0; x < n; x++) {
      ctx.fillStyle = base;
      ctx.fillRect(x * t + 1.5, y * t + 1.5, t - 3, t - 3);
      ctx.fillStyle = `rgba(0,0,0,${rng() * 0.05})`;
      ctx.fillRect(x * t + 1.5, y * t + 1.5, t - 3, t - 3);
    }
  const tex = finish(c, 1, 8);
  cache.set(key, tex);
  return tex;
}

/** License plate texture with a background colour and readable text. */
export function plateTexture(text: string, bg: string, fg = '#111') {
  const key = 'plate' + text + bg;
  if (cache.has(key)) return cache.get(key)!;
  const c = canvas(256, 64);
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = 'rgba(0,0,0,0.5)';
  ctx.lineWidth = 4;
  ctx.strokeRect(3, 3, 250, 58);
  ctx.fillStyle = fg;
  ctx.font = 'bold 42px Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, 128, 36);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  cache.set(key, t);
  return t;
}

export function skyGradientTexture() {
  if (cache.has('sky')) return cache.get('sky')!;
  const c = canvas(4, 256);
  const ctx = c.getContext('2d')!;
  const g = ctx.createLinearGradient(0, 0, 0, 256);
  g.addColorStop(0, '#1b3b73');
  g.addColorStop(0.45, '#6ea3d8');
  g.addColorStop(0.75, '#b9d5ea');
  g.addColorStop(1, '#e8e3d6');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 4, 256);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.magFilter = THREE.LinearFilter;
  cache.set('sky', t);
  return t;
}

/** Soft round sprite used for particles / light glows. */
export function glowTexture() {
  if (cache.has('glow')) return cache.get('glow')!;
  const s = 128;
  const c = canvas(s);
  const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.35, 'rgba(255,255,255,0.55)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, s, s);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  cache.set('glow', t);
  return t;
}

export function leafTexture() {
  if (cache.has('leaf')) return cache.get('leaf')!;
  const rng = makeRng(1234);
  const s = 256;
  const c = canvas(s);
  const ctx = c.getContext('2d')!;
  ctx.clearRect(0, 0, s, s);
  for (let i = 0; i < 220; i++) {
    const x = rng() * s;
    const y = rng() * s;
    const r = 4 + rng() * 9;
    const g = 70 + rng() * 60;
    ctx.fillStyle = `rgba(${40 + rng() * 40},${g},${30 + rng() * 30},0.92)`;
    ctx.beginPath();
    ctx.ellipse(x, y, r, r * 0.6, rng() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  cache.set('leaf', t);
  return t;
}

export function disposeTextures() {
  cache.forEach((t: any) => t.dispose?.());
  cache.clear();
}
