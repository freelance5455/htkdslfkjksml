import { GRID } from './constants';
import type { Shape } from './shapes';

export interface Lines {
  rows: number[];
  cols: number[];
}

export interface ClearedCell {
  r: number;
  c: number;
  color: number;
}

/** Pure 8x8 board model. -1 = empty, otherwise colour index. */
export class Board {
  readonly size = GRID;
  cells: Int8Array;

  constructor(data?: ArrayLike<number>) {
    this.cells = new Int8Array(GRID * GRID).fill(-1);
    if (data && data.length === GRID * GRID) {
      for (let i = 0; i < data.length; i++) this.cells[i] = data[i];
    }
  }

  get(r: number, c: number): number {
    return this.cells[r * GRID + c];
  }

  set(r: number, c: number, v: number): void {
    this.cells[r * GRID + c] = v;
  }

  isFilled(r: number, c: number): boolean {
    return this.cells[r * GRID + c] >= 0;
  }

  canPlace(shape: Shape, r: number, c: number): boolean {
    if (r < 0 || c < 0 || r + shape.h > GRID || c + shape.w > GRID) return false;
    for (const [dr, dc] of shape.cells) {
      if (this.cells[(r + dr) * GRID + c + dc] >= 0) return false;
    }
    return true;
  }

  place(shape: Shape, r: number, c: number, color: number): void {
    for (const [dr, dc] of shape.cells) this.cells[(r + dr) * GRID + c + dc] = color;
  }

  remove(shape: Shape, r: number, c: number): void {
    for (const [dr, dc] of shape.cells) this.cells[(r + dr) * GRID + c + dc] = -1;
  }

  canPlaceAnywhere(shape: Shape): boolean {
    for (let r = 0; r <= GRID - shape.h; r++) {
      for (let c = 0; c <= GRID - shape.w; c++) {
        if (this.canPlace(shape, r, c)) return true;
      }
    }
    return false;
  }

  placements(shape: Shape): Array<[number, number]> {
    const out: Array<[number, number]> = [];
    for (let r = 0; r <= GRID - shape.h; r++) {
      for (let c = 0; c <= GRID - shape.w; c++) {
        if (this.canPlace(shape, r, c)) out.push([r, c]);
      }
    }
    return out;
  }

  private rowFull(r: number): boolean {
    const o = r * GRID;
    for (let c = 0; c < GRID; c++) if (this.cells[o + c] < 0) return false;
    return true;
  }

  private colFull(c: number): boolean {
    for (let r = 0; r < GRID; r++) if (this.cells[r * GRID + c] < 0) return false;
    return true;
  }

  getFullLines(): Lines {
    const rows: number[] = [];
    const cols: number[] = [];
    for (let i = 0; i < GRID; i++) {
      if (this.rowFull(i)) rows.push(i);
      if (this.colFull(i)) cols.push(i);
    }
    return { rows, cols };
  }

  /** Lines that would be completed if `shape` were placed at (r, c). */
  previewLines(shape: Shape, r: number, c: number): Lines {
    this.place(shape, r, c, 99);
    const rows: number[] = [];
    const cols: number[] = [];
    const seenR = new Set<number>();
    const seenC = new Set<number>();
    for (const [dr, dc] of shape.cells) {
      const rr = r + dr;
      const cc = c + dc;
      if (!seenR.has(rr)) {
        seenR.add(rr);
        if (this.rowFull(rr)) rows.push(rr);
      }
      if (!seenC.has(cc)) {
        seenC.add(cc);
        if (this.colFull(cc)) cols.push(cc);
      }
    }
    this.remove(shape, r, c);
    rows.sort((a, b) => a - b);
    cols.sort((a, b) => a - b);
    return { rows, cols };
  }

  /** Clears the given lines and returns the cells that were removed. */
  clearLines(lines: Lines): ClearedCell[] {
    const out: ClearedCell[] = [];
    const seen = new Set<number>();
    const take = (r: number, c: number) => {
      const i = r * GRID + c;
      if (seen.has(i)) return;
      seen.add(i);
      const color = this.cells[i];
      if (color >= 0) out.push({ r, c, color });
      this.cells[i] = -1;
    };
    for (const r of lines.rows) for (let c = 0; c < GRID; c++) take(r, c);
    for (const c of lines.cols) for (let r = 0; r < GRID; r++) take(r, c);
    return out;
  }

  filledCount(): number {
    let n = 0;
    for (let i = 0; i < this.cells.length; i++) if (this.cells[i] >= 0) n++;
    return n;
  }

  isEmpty(): boolean {
    return this.filledCount() === 0;
  }

  toArray(): number[] {
    return Array.from(this.cells);
  }

  clone(): Board {
    return new Board(this.cells);
  }
}
