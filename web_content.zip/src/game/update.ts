import {
  ECONOMY,
  FISHING,
  FISH_META,
  PLAYER,
  WORLD,
  ZONES,
} from './config'
import type { TouchControlState } from './touch'
import {
  addCatch,
  basketCount,
  basketValue,
  burst,
  fishLabel,
  pickFish,
  saveBest,
  showToast,
  spawnFloat,
  type GameState,
} from './state'

function inRect(
  x: number,
  y: number,
  r: { x: number; y: number; w: number; h: number },
): boolean {
  return x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h
}

function pointInPolygon(
  x: number,
  y: number,
  polygon: readonly { x: number; y: number }[],
): boolean {
  let inside = false
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i].x
    const yi = polygon[i].y
    const xj = polygon[j].x
    const yj = polygon[j].y
    const intersects =
      yi > y !== yj > y &&
      x < ((xj - xi) * (y - yi)) / (yj - yi) + xi
    if (intersects) inside = !inside
  }
  return inside
}

function nearShore(x: number, y: number): boolean {
  return inRect(x, y, ZONES.shore)
}

function nearStall(x: number, y: number): boolean {
  return inRect(x, y, ZONES.stall)
}

function blocked(x: number, y: number): boolean {
  const L = ZONES.land

  // Keep the whole player body inside the map.
  if (
    x < L.x + PLAYER.radius ||
    x > L.x + L.w - PLAYER.radius ||
    y < L.y + PLAYER.radius ||
    y > L.y + L.h - PLAYER.radius
  ) {
    return true
  }

  // Check the player's body, not only its center, so the feet/body cannot
  // visibly overlap the water at the shoreline.
  const samples = [
    [0, 0],
    [PLAYER.radius, 0],
    [-PLAYER.radius, 0],
    [0, PLAYER.radius],
    [0, -PLAYER.radius],
    [PLAYER.radius * 0.7, PLAYER.radius * 0.7],
    [-PLAYER.radius * 0.7, PLAYER.radius * 0.7],
    [PLAYER.radius * 0.7, -PLAYER.radius * 0.7],
    [-PLAYER.radius * 0.7, -PLAYER.radius * 0.7],
  ]

  for (const [sx, sy] of samples) {
    const px = x + sx
    const py = y + sy

    // The wooden dock is solid even though it crosses the lake.
    if (inRect(px, py, ZONES.dock)) continue

    if (pointInPolygon(px, py, ZONES.waterPolygon)) return true
  }

  return false
}

function updateParticles(state: GameState, dt: number): void {
  for (let i = state.particles.length - 1; i >= 0; i--) {
    const p = state.particles[i]
    p.x += p.vx * dt
    p.y += p.vy * dt
    p.vy += 220 * dt
    p.life -= dt
    if (p.life <= 0) state.particles.splice(i, 1)
  }
  for (let i = state.floats.length - 1; i >= 0; i--) {
    const f = state.floats[i]
    f.y += f.vy * dt
    f.life -= dt
    if (f.life <= 0) state.floats.splice(i, 1)
  }
}

function startFishing(state: GameState): void {
  if (state.bait <= 0) {
    showToast(state, 'Sem isca! Compre no balcão.')
    state.sfx = 'miss'
    return
  }
  state.bait -= 1
  state.phase = 'fishing'
  state.fish.waiting = FISHING.biteDelayMin + Math.random() * (FISHING.biteDelayMax - FISHING.biteDelayMin)
  state.fish.bar = 0.15 + Math.random() * 0.2
  state.fish.barDir = 1
  state.fish.target = pickFish(state.baitTier)
  state.fish.result = 'none'
  state.fish.resultTimer = 0
  state.sfx = 'cast'
  burst(state, state.player.x + 18, state.player.y + 8, '#7ec8e3', 10)
  showToast(state, 'Linha na água…', 1.2)
}

function resolveReel(state: GameState): void {
  const window = FISHING.windowByBait[state.baitTier]
  const center = 0.5
  const hit = Math.abs(state.fish.bar - center) <= window
  if (hit && state.fish.target) {
    const kind = state.fish.target
    addCatch(state, kind)
    state.fish.result = 'ok'
    state.sfx = 'catch'
    state.trauma = Math.min(1, state.trauma + 0.25)
    burst(state, state.player.x, state.player.y - 10, FISH_META[kind].color, 18)
    spawnFloat(state, state.player.x, state.player.y - 24, `+${fishLabel(kind)}!`, FISH_META[kind].color)
    showToast(state, `Pegou ${fishLabel(kind)}!`, 2)
  } else {
    state.fish.result = 'miss'
    state.sfx = 'miss'
    burst(state, state.player.x + 20, state.player.y, '#88aacc', 8)
    spawnFloat(state, state.player.x, state.player.y - 20, 'Escapou…', '#aac')
    showToast(state, 'O peixe escapou!', 1.8)
  }
  state.fish.resultTimer = 1.1
  state.fish.target = null
}

function sellAll(state: GameState): void {
  const value = basketValue(state)
  if (value <= 0) {
    showToast(state, 'Cesta vazia.')
    return
  }
  const n = basketCount(state)
  state.gold += value
  state.basket = []
  state.bestGold = saveBest(state.gold, state.bestGold)
  state.sfx = 'sell'
  state.trauma = Math.min(1, state.trauma + 0.15)
  burst(state, state.player.x, state.player.y - 8, '#f4d35e', 16)
  spawnFloat(state, state.player.x, state.player.y - 28, `+${value} ouro`, '#f4d35e')
  showToast(state, `Vendeu ${n} peixe(s) por ${value} ouro!`)
}

function upgradeBait(state: GameState): void {
  if (state.baitTier >= 2) {
    showToast(state, 'Isca já está no máximo!')
    return
  }
  const next = (state.baitTier + 1) as 0 | 1 | 2
  const cost = ECONOMY.baitCost[next]
  if (state.gold < cost) {
    showToast(state, `Precisa de ${cost} ouro.`)
    state.sfx = 'miss'
    return
  }
  state.gold -= cost
  state.baitTier = next
  state.bait = Math.min(ECONOMY.maxBait, state.bait + 3)
  state.sfx = 'sell'
  burst(state, state.player.x, state.player.y - 8, '#ff8fab', 12)
  showToast(state, `Isca nível ${next + 1}! +3 iscas`)
}

function buyBaitPack(state: GameState): void {
  const cost = 8
  if (state.gold < cost) {
    showToast(state, `Pacote de iscas: ${cost} ouro.`)
    state.sfx = 'miss'
    return
  }
  if (state.bait >= ECONOMY.maxBait) {
    showToast(state, 'Iscas cheias!')
    return
  }
  state.gold -= cost
  state.bait = Math.min(ECONOMY.maxBait, state.bait + 5)
  state.sfx = 'sell'
  showToast(state, '+5 iscas')
}

export function update(state: GameState, input: TouchControlState, dt: number): void {
  state.time += dt
  state.waterPulse += dt
  state.trauma = Math.max(0, state.trauma - 1.6 * dt)
  if (state.toast.life > 0) state.toast.life -= dt
  updateParticles(state, dt)

  // Title: any action starts
  if (state.phase === 'title') {
    // idle bob on title
    state.player.anim += dt
    if (input.actionPressed) {
      state.phase = 'play'
      showToast(state, 'Ande até o lago e pesque!', 2.5)
      state.sfx = 'cast'
    }
    return
  }

  // Fishing mini-game
  if (state.phase === 'fishing') {
    if (state.fish.result !== 'none') {
      state.fish.resultTimer -= dt
      if (state.fish.resultTimer <= 0) {
        state.phase = 'play'
        state.fish.result = 'none'
      }
      return
    }
    if (state.fish.waiting > 0) {
      state.fish.waiting -= dt
      return
    }
    // move bar
    state.fish.bar += state.fish.barDir * FISHING.barSpeed * dt
    if (state.fish.bar >= 1) {
      state.fish.bar = 1
      state.fish.barDir = -1
    } else if (state.fish.bar <= 0) {
      state.fish.bar = 0
      state.fish.barDir = 1
    }
    if (input.actionPressed) resolveReel(state)
    return
  }

  // Free roam
  const dx = input.dirX
  const dy = input.dirY
  const moving = Math.abs(dx) + Math.abs(dy) > 0.01
  state.player.moving = moving
  if (moving) {
    if (dx !== 0) state.player.facing = dx > 0 ? 1 : -1
    state.player.anim += dt * 8
    // Small substeps prevent a fast joystick movement from jumping across
    // the shoreline in a single frame.
    const distance = PLAYER.speed * dt
    const steps = Math.max(1, Math.ceil(distance / (PLAYER.radius * 0.5)))
    const stepX = (dx * distance) / steps
    const stepY = (dy * distance) / steps

    for (let i = 0; i < steps; i++) {
      const nextX = state.player.x + stepX
      if (!blocked(nextX, state.player.y)) state.player.x = nextX

      const nextY = state.player.y + stepY
      if (!blocked(state.player.x, nextY)) state.player.y = nextY
    }
  }

  // Camera follows (world == screen for this small map; still clamp)
  state.cam.x = Math.max(0, Math.min(state.player.x - WORLD.w * 0.5, 0))
  state.cam.y = Math.max(0, Math.min(state.player.y - WORLD.h * 0.45, 0))

  if (!input.actionPressed) return

  if (nearStall(state.player.x, state.player.y)) {
    // Cycle: sell → buy pack → upgrade → sell...
    // Simple: if basket has fish, sell; else if can upgrade and gold enough prefer upgrade; else buy pack
    if (basketCount(state) > 0) sellAll(state)
    else if (state.baitTier < 2 && state.gold >= ECONOMY.baitCost[(state.baitTier + 1) as 1 | 2]) {
      upgradeBait(state)
    } else {
      buyBaitPack(state)
    }
    return
  }

  if (nearShore(state.player.x, state.player.y)) {
    startFishing(state)
    return
  }

  showToast(state, 'Vá ao lago para pescar, ou ao balcão para vender.')
}

export function actionHint(state: GameState): string {
  if (state.phase === 'title') return 'TOCAR'
  if (state.phase === 'fishing') {
    if (state.fish.waiting > 0) return '…'
    if (state.fish.result === 'ok') return '!'
    if (state.fish.result === 'miss') return '×'
    return 'Puxar'
  }
  if (nearStall(state.player.x, state.player.y)) {
    if (basketCount(state) > 0) return 'Vender'
    if (state.baitTier < 2) return 'Melhorar'
    return 'Iscas'
  }
  if (nearShore(state.player.x, state.player.y)) return 'Pescar'
  return 'Ação'
}
