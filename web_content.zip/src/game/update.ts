import type { InputState } from '../engine/input'
import { audio } from '../engine/audio'
import {
  BRUSH_RADIUS,
  COLOR_CYCLE_EVERY,
  COMBO_STEP,
  FAIL_COVERAGE,
  MAX_COMBO,
  PAINT_COLS,
  PAINT_ROWS,
  POLVO_SIZE,
  SCORE_PER_CELL,
  STAIN_BASE_INTERVAL,
  STAIN_MIN_INTERVAL,
  STAIN_RADIUS,
  STAIN_RAMP,
  STAIN_SIZE,
  TRAUMA_COMBO,
  TRAUMA_DEATH,
  TRAUMA_STAIN,
} from './config'
import {
  canFail,
  paintColor,
  resetRun,
  type Floater,
  type GameState,
  type Particle,
  type Stain,
} from './state'

function cellIndex(cx: number, cy: number): number {
  return cy * PAINT_COLS + cx
}

function worldToCell(state: GameState, x: number, y: number): { cx: number; cy: number } {
  const cx = Math.floor((x / state.w) * PAINT_COLS)
  const cy = Math.floor((y / state.h) * PAINT_ROWS)
  return {
    cx: Math.max(0, Math.min(PAINT_COLS - 1, cx)),
    cy: Math.max(0, Math.min(PAINT_ROWS - 1, cy)),
  }
}

function paintAt(state: GameState, x: number, y: number, radius: number): number {
  if (state.w <= 0 || state.h <= 0) return 0
  const cellW = state.w / PAINT_COLS
  const cellH = state.h / PAINT_ROWS
  const rCellsX = Math.ceil(radius / cellW)
  const rCellsY = Math.ceil(radius / cellH)
  const { cx: ocx, cy: ocy } = worldToCell(state, x, y)
  let painted = 0
  for (let dy = -rCellsY; dy <= rCellsY; dy++) {
    for (let dx = -rCellsX; dx <= rCellsX; dx++) {
      const cx = ocx + dx
      const cy = ocy + dy
      if (cx < 0 || cy < 0 || cx >= PAINT_COLS || cy >= PAINT_ROWS) continue
      const wx = (cx + 0.5) * cellW
      const wy = (cy + 0.5) * cellH
      const dist = Math.hypot(wx - x, wy - y)
      if (dist > radius) continue
      const i = cellIndex(cx, cy)
      const prev = state.grid[i]
      if (prev === 1) continue
      if (prev === 2) state.stainedCount--
      state.grid[i] = 1
      state.paintedCount++
      painted++
    }
  }
  return painted
}

function stainAt(state: GameState, x: number, y: number, radius: number): number {
  if (state.w <= 0 || state.h <= 0) return 0
  const cellW = state.w / PAINT_COLS
  const cellH = state.h / PAINT_ROWS
  const rCellsX = Math.ceil(radius / cellW)
  const rCellsY = Math.ceil(radius / cellH)
  const { cx: ocx, cy: ocy } = worldToCell(state, x, y)
  let stained = 0
  for (let dy = -rCellsY; dy <= rCellsY; dy++) {
    for (let dx = -rCellsX; dx <= rCellsX; dx++) {
      const cx = ocx + dx
      const cy = ocy + dy
      if (cx < 0 || cy < 0 || cx >= PAINT_COLS || cy >= PAINT_ROWS) continue
      const wx = (cx + 0.5) * cellW
      const wy = (cy + 0.5) * cellH
      if (Math.hypot(wx - x, wy - y) > radius) continue
      const i = cellIndex(cx, cy)
      const prev = state.grid[i]
      if (prev === 2) continue
      if (prev === 1) state.paintedCount--
      state.grid[i] = 2
      state.stainedCount++
      stained++
    }
  }
  return stained
}

function recomputeCoverage(state: GameState): void {
  state.coverage = state.paintedCount / state.totalCells
}

function burst(state: GameState, x: number, y: number, color: string, n = 10): void {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2
    const sp = 60 + Math.random() * 160
    const p: Particle = {
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp,
      life: 0.45 + Math.random() * 0.25,
      maxLife: 0.7,
      color,
      size: 2 + Math.random() * 3,
    }
    p.maxLife = p.life
    state.particles.push(p)
  }
  if (state.particles.length > 180) state.particles.splice(0, state.particles.length - 180)
}

function floatText(state: GameState, x: number, y: number, text: string, color: string): void {
  const f: Floater = { x, y, text, life: 0.8, maxLife: 0.8, color }
  state.floaters.push(f)
}

function addTrauma(state: GameState, amount: number): void {
  state.trauma = Math.min(1, state.trauma + amount)
}

function spawnStain(state: GameState): void {
  const margin = STAIN_SIZE
  const x = margin + Math.random() * Math.max(1, state.w - margin * 2)
  const y = margin + Math.random() * Math.max(1, state.h - margin * 2)
  // Prefer painting over already-painted cells
  const stain: Stain = {
    x,
    y,
    r: STAIN_RADIUS * (0.85 + Math.random() * 0.35),
    life: 6,
    age: 0,
    flash: 0.15,
  }
  state.stains.push(stain)
  stainAt(state, x, y, stain.r)
  recomputeCoverage(state)
  burst(state, x, y, '#5a2a7a', 14)
  addTrauma(state, TRAUMA_STAIN)
  audio.playSfx('stain', { volume: 0.55, rate: 0.9 + Math.random() * 0.2 })
}

function stainInterval(state: GameState): number {
  const minutes = state.elapsed / 60
  return Math.max(STAIN_MIN_INTERVAL, STAIN_BASE_INTERVAL * Math.pow(STAIN_RAMP, minutes * 4))
}

function endGame(state: GameState): void {
  state.phase = 'ended'
  state.endFlash = 1
  state.freeze = 0.12
  addTrauma(state, TRAUMA_DEATH)
  if (state.score > state.best) {
    state.best = state.score
    try {
      localStorage.setItem('polvo-pintor-highscore', String(state.best))
    } catch {
      // ignore
    }
  }
  audio.playSfx('gameover', { volume: 0.7 })
}

let prevDown = false

export function update(state: GameState, input: InputState, dt: number): void {
  state.titlePulse += dt
  state.displayScore += (state.score - state.displayScore) * Math.min(1, dt * 8)
  state.trauma = Math.max(0, state.trauma - 1.6 * dt)
  if (state.endFlash > 0) state.endFlash = Math.max(0, state.endFlash - dt * 1.5)

  // particles always move (even on title)
  for (let i = state.particles.length - 1; i >= 0; i--) {
    const p = state.particles[i]
    p.x += p.vx * dt
    p.y += p.vy * dt
    p.vy += 280 * dt
    p.life -= dt
    if (p.life <= 0) state.particles.splice(i, 1)
  }
  for (let i = state.floaters.length - 1; i >= 0; i--) {
    const f = state.floaters[i]
    f.y -= 40 * dt
    f.life -= dt
    if (f.life <= 0) state.floaters.splice(i, 1)
  }

  // idle bob for polvo on all phases
  state.polvo.bob += dt * 3

  const tapped = input.pointer.down && !prevDown
  const released = !input.pointer.down && prevDown
  prevDown = input.pointer.down

  if (state.phase === 'title') {
    // idle drift
    const cx = state.w * 0.5
    const cy = state.h * 0.55
    state.polvo.x = cx + Math.sin(state.titlePulse * 0.8) * 18
    state.polvo.y = cy + Math.cos(state.titlePulse * 1.1) * 10
    state.polvo.targetX = state.polvo.x
    state.polvo.targetY = state.polvo.y
    if (tapped && state.ready) {
      resetRun(state)
      audio.playBgm('theme', { volume: 0.38 })
      audio.playSfx('paint', { volume: 0.4 })
    }
    return
  }

  if (state.phase === 'ended') {
    if (tapped) {
      resetRun(state)
      audio.playSfx('paint', { volume: 0.4 })
    }
    return
  }

  // playing
  if (state.freeze > 0) {
    state.freeze -= dt
    return
  }

  state.elapsed += dt
  state.colorTimer += dt
  if (state.colorTimer >= COLOR_CYCLE_EVERY) {
    state.colorTimer = 0
    state.paintColorIdx = (state.paintColorIdx + 1) % 3
    floatText(state, state.w * 0.5, state.h * 0.2, 'NOVA TINTA!', paintColor(state))
    audio.playSfx('combo', { volume: 0.45 })
  }

  // drag follow
  if (input.pointer.down) {
    state.dragging = true
    state.polvo.targetX = input.pointer.x
    state.polvo.targetY = input.pointer.y
  } else if (released) {
    state.dragging = false
    state.comboCells = 0
  }

  // smooth follow
  const follow = Math.min(1, dt * 14)
  state.polvo.x += (state.polvo.targetX - state.polvo.x) * follow
  state.polvo.y += (state.polvo.targetY - state.polvo.y) * follow
  // clamp
  const half = POLVO_SIZE * 0.35
  state.polvo.x = Math.max(half, Math.min(state.w - half, state.polvo.x))
  state.polvo.y = Math.max(half, Math.min(state.h - half, state.polvo.y))

  if (state.dragging) {
    // Stamp along the path so fast swipes don't leave gaps.
    const fromX = state.polvo.x
    const fromY = state.polvo.y
    // polvo already eased toward target this frame; paint between last stamp and now
    let painted = 0
    const last = (state as GameState & { _lastPaintX?: number; _lastPaintY?: number })
    const lx = last._lastPaintX ?? fromX
    const ly = last._lastPaintY ?? fromY
    const dist = Math.hypot(fromX - lx, fromY - ly)
    const steps = Math.max(1, Math.ceil(dist / (BRUSH_RADIUS * 0.45)))
    for (let s = 1; s <= steps; s++) {
      const t = s / steps
      const px = lx + (fromX - lx) * t
      const py = ly + (fromY - ly) * t
      painted += paintAt(state, px, py, BRUSH_RADIUS)
    }
    last._lastPaintX = fromX
    last._lastPaintY = fromY

    if (painted > 0) {
      recomputeCoverage(state)
      state.score += painted * SCORE_PER_CELL * state.combo
      state.comboCells += painted
      if (Math.random() < 0.35) {
        burst(state, state.polvo.x, state.polvo.y, paintColor(state), 4)
      }
      if (state.comboCells >= COMBO_STEP) {
        state.comboCells = 0
        if (state.combo < MAX_COMBO) {
          state.combo++
          floatText(state, state.polvo.x, state.polvo.y - 30, `x${state.combo}`, '#ffd56b')
          addTrauma(state, TRAUMA_COMBO)
          audio.playSfx('combo', { volume: 0.5, rate: 0.95 + state.combo * 0.03 })
        }
      }
      if (Math.random() < 0.08) {
        audio.playSfx('paint', { volume: 0.25, rate: 0.85 + Math.random() * 0.3 })
      }
    }
  } else {
    const last = state as GameState & { _lastPaintX?: number; _lastPaintY?: number }
    last._lastPaintX = undefined
    last._lastPaintY = undefined
  }

  // stains
  state.stainTimer -= dt
  if (state.stainTimer <= 0) {
    spawnStain(state)
    state.stainTimer = stainInterval(state)
  }
  for (let i = state.stains.length - 1; i >= 0; i--) {
    const s = state.stains[i]
    s.age += dt
    s.life -= dt
    if (s.flash > 0) s.flash -= dt
    // keep re-staining while alive (slow seep)
    if (s.age % 0.4 < dt) {
      stainAt(state, s.x, s.y, s.r * 0.85)
      recomputeCoverage(state)
    }
    if (s.life <= 0) state.stains.splice(i, 1)
  }

  // fail check
  if (canFail(state) && state.coverage < FAIL_COVERAGE) {
    endGame(state)
  }
}
