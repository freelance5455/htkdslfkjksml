import { BiomeDefinition, BiomeId } from '../types';
import { fbm2D, ridgedNoise2D } from './noise';

export const WATER_LEVEL = 0.0;

export const BIOMES: Record<BiomeId, BiomeDefinition> = {
  emerald_forest: {
    id: 'emerald_forest',
    nameAr: 'الغابة الزمردية',
    ambientTempC: 22,
    skyHex: 0x7ec8e3,
    fogHex: 0x9bd7d5,
    fogDensity: 0.0052,
    groundHex: 0x3b8c47,
    groundAltHex: 0x2c6f3d,
    rockHex: 0x6b757d,
    treeTintHex: 0x2d7a3e,
    foliageTintHex: 0x4ca64c,
    heightScale: 8.5,
    heightBase: 3.2,
    treeDensity: 1.0,
    rockDensity: 0.45,
    grassDensity: 1.0,
    crystalChance: 0.06,
    ruinChance: 0.14,
  },
  mystic_woods: {
    id: 'mystic_woods',
    nameAr: 'الغابة الغامضة',
    ambientTempC: 16,
    skyHex: 0x32485c,
    fogHex: 0x365261,
    fogDensity: 0.0115,
    groundHex: 0x25574f,
    groundAltHex: 0x1b3c45,
    rockHex: 0x4d596b,
    treeTintHex: 0x194d4a,
    foliageTintHex: 0x2e8279,
    heightScale: 10.0,
    heightBase: 4.0,
    treeDensity: 1.25,
    rockDensity: 0.6,
    grassDensity: 0.85,
    crystalChance: 0.35,
    ruinChance: 0.22,
  },
  snow_peaks: {
    id: 'snow_peaks',
    nameAr: 'القمم الثلجية',
    ambientTempC: -8,
    skyHex: 0xb7d4e8,
    fogHex: 0xcfe4f0,
    fogDensity: 0.0068,
    groundHex: 0xdcebf2,
    groundAltHex: 0x8ea4b5,
    rockHex: 0x6c7a89,
    treeTintHex: 0x2d5e59,
    foliageTintHex: 0xaad0dc,
    heightScale: 24.0,
    heightBase: 9.5,
    treeDensity: 0.45,
    rockDensity: 1.1,
    grassDensity: 0.25,
    crystalChance: 0.28,
    ruinChance: 0.15,
  },
  sunlit_coast: {
    id: 'sunlit_coast',
    nameAr: 'السواحل المشمسة',
    ambientTempC: 26,
    skyHex: 0x6ecbff,
    fogHex: 0xaee4ff,
    fogDensity: 0.0042,
    groundHex: 0xd9c282,
    groundAltHex: 0xc2aa69,
    rockHex: 0x8a8376,
    treeTintHex: 0x459448,
    foliageTintHex: 0x6bbd5b,
    heightScale: 3.4,
    heightBase: 0.5,
    treeDensity: 0.32,
    rockDensity: 0.45,
    grassDensity: 0.4,
    crystalChance: 0.04,
    ruinChance: 0.12,
  },
  arcane_glade: {
    id: 'arcane_glade',
    nameAr: 'المروج السحرية',
    ambientTempC: 20,
    skyHex: 0x5c4b8a,
    fogHex: 0x7661a8,
    fogDensity: 0.0075,
    groundHex: 0x457d6e,
    groundAltHex: 0x5f4e8f,
    rockHex: 0x675b80,
    treeTintHex: 0x4966a3,
    foliageTintHex: 0x8b6fd9,
    heightScale: 9.0,
    heightBase: 4.5,
    treeDensity: 0.72,
    rockDensity: 0.55,
    grassDensity: 0.9,
    crystalChance: 0.85,
    ruinChance: 0.35,
  },
  volcanic_ridge: {
    id: 'volcanic_ridge',
    nameAr: 'المرتفعات البركانية',
    ambientTempC: 41,
    skyHex: 0x4a2521,
    fogHex: 0x612f25,
    fogDensity: 0.0085,
    groundHex: 0x3b3536,
    groundAltHex: 0x5c362c,
    rockHex: 0x2b2526,
    treeTintHex: 0x473832,
    foliageTintHex: 0x78432e,
    heightScale: 18.0,
    heightBase: 7.5,
    treeDensity: 0.15,
    rockDensity: 1.2,
    grassDensity: 0.12,
    crystalChance: 0.4,
    ruinChance: 0.18,
  },
  desert_dunes: {
    id: 'desert_dunes',
    nameAr: 'الكثبان الذهبية',
    ambientTempC: 37,
    skyHex: 0xe8c48b,
    fogHex: 0xe6cb9c,
    fogDensity: 0.0058,
    groundHex: 0xd9a85b,
    groundAltHex: 0xc28944,
    rockHex: 0x996d49,
    treeTintHex: 0x5e8240,
    foliageTintHex: 0x8ca653,
    heightScale: 7.5,
    heightBase: 3.0,
    treeDensity: 0.08,
    rockDensity: 0.55,
    grassDensity: 0.15,
    crystalChance: 0.1,
    ruinChance: 0.25,
  },
  misty_marsh: {
    id: 'misty_marsh',
    nameAr: 'المستنقع الضبابي',
    ambientTempC: 17,
    skyHex: 0x4b5e57,
    fogHex: 0x586e65,
    fogDensity: 0.013,
    groundHex: 0x3c523c,
    groundAltHex: 0x2d3b32,
    rockHex: 0x505953,
    treeTintHex: 0x2f4d36,
    foliageTintHex: 0x4e6b48,
    heightScale: 2.6,
    heightBase: 0.3,
    treeDensity: 0.78,
    rockDensity: 0.35,
    grassDensity: 0.85,
    crystalChance: 0.15,
    ruinChance: 0.2,
  },
};

export function getBiomeIdAt(x: number, z: number, seed: number): BiomeId {
  // Safe scenic spawn area around origin (emerald_forest + nearby coast)
  const distFromOrigin = Math.hypot(x, z);
  if (distFromOrigin < 75) {
    return 'emerald_forest';
  }

  const temp = fbm2D(x * 0.0022 + 12.3, z * 0.0022 - 7.1, seed + 101, 3);
  const moist = fbm2D(x * 0.0022 - 19.7, z * 0.0022 + 3.4, seed + 202, 3);
  const magic = fbm2D(x * 0.0031 + 4.5, z * 0.0031 + 11.2, seed + 303, 2);

  if (magic > 0.38 && distFromOrigin > 110) {
    return 'arcane_glade';
  }
  if (temp < -0.26) {
    return moist > 0.05 ? 'snow_peaks' : 'mystic_woods';
  }
  if (temp > 0.32) {
    return moist < -0.1 ? 'volcanic_ridge' : 'desert_dunes';
  }
  if (moist > 0.28) {
    return temp > 0.05 ? 'sunlit_coast' : 'misty_marsh';
  }
  if (moist < -0.22) {
    return 'mystic_woods';
  }
  return 'emerald_forest';
}

export function getWorldHeight(x: number, z: number, seed: number): number {
  const biomeId = getBiomeIdAt(x, z, seed);
  const b = BIOMES[biomeId];

  const baseNoise = fbm2D(x * 0.0085, z * 0.0085, seed + 17, 4);
  const detailNoise = fbm2D(x * 0.032, z * 0.032, seed + 53, 2) * 1.1;

  let h = b.heightBase + baseNoise * b.heightScale + detailNoise;

  if (biomeId === 'snow_peaks' || biomeId === 'volcanic_ridge') {
    const ridge = ridgedNoise2D(x * 0.009, z * 0.009, seed + 79, 3);
    h += ridge * (biomeId === 'snow_peaks' ? 14 : 9);
  }

  // Create a gentle scenic lake basin near (42, -38) and natural valleys
  const lakeNoise = fbm2D(x * 0.011 + 8.1, z * 0.011 - 4.2, seed + 401, 3);
  if (lakeNoise < -0.34) {
    const depthFactor = (-0.34 - lakeNoise) * 14;
    h -= depthFactor;
  }

  // Flatten gentle spawn clearing around (0, 0)
  const spawnDist = Math.hypot(x, z);
  if (spawnDist < 18) {
    const t = Math.max(0, 1 - spawnDist / 18);
    const targetSpawnH = 3.2;
    h = h * (1 - t * 0.85) + targetSpawnH * (t * 0.85);
  }

  // Gentle plateau for Aetheria Village around (24, 18)
  const villageDist = Math.hypot(x - 24, z - 18);
  if (villageDist < 20) {
    const vt = Math.max(0, 1 - villageDist / 20);
    const smoothVt = vt * vt * (3 - 2 * vt);
    h = h * (1 - smoothVt * 0.92) + 3.4 * (smoothVt * 0.92);
  }

  return h;
}

export function getTerrainSlope(x: number, z: number, seed: number): number {
  const eps = 1.0;
  const hL = getWorldHeight(x - eps, z, seed);
  const hR = getWorldHeight(x + eps, z, seed);
  const hD = getWorldHeight(x, z - eps, seed);
  const hU = getWorldHeight(x, z + eps, seed);
  const dx = (hR - hL) / (2 * eps);
  const dz = (hU - hD) / (2 * eps);
  return Math.hypot(dx, dz);
}
