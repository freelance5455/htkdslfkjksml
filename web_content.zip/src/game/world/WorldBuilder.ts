import * as THREE from 'three';
import { BOSSES } from '../config/bosses';
import { REGIONS } from '../config/regions';
import { ProceduralTextureSet } from '../materials/ProceduralTextures';
import { buildBossArena } from '../models/BossModels';
import { GraphicsQuality, PlacedStructure, StructureType, WeatherType } from '../types/gameTypes';
import {
  buildAllCastlesRuinsAndCrypts,
  CastleAndDungeonBundle,
  ChestInstance,
  CryptInterior,
  CryptPortal,
  TrapInstance,
  WallBox,
} from './DungeonAndCastleBuilder';
import {
  getRegionBlendWeights,
  getRoadFactor,
  getTerrainHeight,
  getTerrainSlope,
  WATER_LEVEL,
  WORLD_RADIUS,
} from './TerrainMath';

export interface ResourceNode {
  id: string;
  itemId: string;
  label: string;
  x: number;
  y: number;
  z: number;
  mesh: THREE.Group;
  cooldown: number;
}

export interface WorldHandles {
  terrainMesh: THREE.Mesh;
  waterMesh: THREE.Mesh;
  lavaMesh: THREE.Mesh;
  waterfallMesh: THREE.Mesh;
  weatherPoints: THREE.Points;
  sunLight: THREE.DirectionalLight;
  hemiLight: THREE.HemisphereLight;
  resourceNodes: ResourceNode[];
  structureGroup: THREE.Group;
  colliders: Array<{ x: number; z: number; radius: number; maxY: number }>;
  wallBoxes: WallBox[];
  traps: TrapInstance[];
  chests: ChestInstance[];
  portals: CryptPortal[];
  crypts: CryptInterior[];
  landmarkPins: Array<{ x: number; z: number; kind: 'castle' | 'ruin' | 'crypt'; label: string }>;
  updateEnvironment: (dt: number, timeOfDay: number, weather: WeatherType, playerPos: THREE.Vector3) => void;
  updateTrapsAndPortals: CastleAndDungeonBundle['updateTrapsAndPortals'];
  addPlacedStructure: (s: PlacedStructure) => void;
}

export function buildStructureMesh(type: StructureType, textures: ProceduralTextureSet): THREE.Group {
  const g = new THREE.Group();
  const stoneMat = new THREE.MeshStandardMaterial({
    map: textures.stoneTex,
    bumpMap: textures.stoneBump,
    bumpScale: 0.06,
    roughness: 0.84,
  });
  const woodMat = new THREE.MeshStandardMaterial({ map: textures.woodTex, roughness: 0.8 });
  const roofMat = new THREE.MeshStandardMaterial({ color: '#7f1d1d', roughness: 0.7 });
  const warmGlow = new THREE.MeshStandardMaterial({
    color: '#fbbf24',
    emissive: '#f59e0b',
    emissiveIntensity: 1.45,
  });

  if (type === 'campfire') {
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(0.24, 0), stoneMat);
      rock.position.set(Math.cos(a) * 0.65, 0.14, Math.sin(a) * 0.65);
      g.add(rock);
    }
    const log1 = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 1.1, 6), woodMat);
    log1.rotation.z = Math.PI / 2;
    log1.rotation.y = 0.5;
    log1.position.y = 0.16;
    g.add(log1);
    const log2 = log1.clone();
    log2.rotation.y = -0.6;
    g.add(log2);
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.32, 0.85, 7), warmGlow);
    flame.position.y = 0.55;
    g.add(flame);
  } else if (type === 'wall') {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(5.2, 3.2, 0.9), stoneMat);
    wall.position.y = 1.6;
    wall.castShadow = true;
    wall.receiveShadow = true;
    g.add(wall);
    for (let x = -2.0; x <= 2.0; x += 1.3) {
      const crenel = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.6, 1.0), stoneMat);
      crenel.position.set(x, 3.5, 0);
      g.add(crenel);
    }
  } else if (type === 'tower') {
    const base = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 2.6, 8.5, 8), stoneMat);
    base.position.y = 4.25;
    base.castShadow = true;
    base.receiveShadow = true;
    g.add(base);
    const deck = new THREE.Mesh(new THREE.CylinderGeometry(2.8, 2.5, 0.7, 8), woodMat);
    deck.position.y = 8.6;
    g.add(deck);
    const roof = new THREE.Mesh(new THREE.ConeGeometry(3.2, 2.8, 8), roofMat);
    roof.position.y = 10.3;
    g.add(roof);
  } else if (type === 'house' || type === 'storage' || type === 'workshop') {
    const w = type === 'house' ? 7.2 : 6.0;
    const d = type === 'house' ? 6.4 : 5.4;
    const h = 3.8;
    const floor = new THREE.Mesh(new THREE.BoxGeometry(w, 0.25, d), stoneMat);
    floor.position.y = 0.12;
    floor.receiveShadow = true;
    g.add(floor);
    const back = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.35), woodMat);
    back.position.set(0, h / 2, -d / 2);
    back.castShadow = true;
    g.add(back);
    for (const s of [-1, 1]) {
      const side = new THREE.Mesh(new THREE.BoxGeometry(0.35, h, d), woodMat);
      side.position.set(s * (w / 2), h / 2, 0);
      side.castShadow = true;
      g.add(side);
      const frontPillar = new THREE.Mesh(new THREE.BoxGeometry(w * 0.26, h, 0.35), woodMat);
      frontPillar.position.set(s * (w * 0.37), h / 2, d / 2);
      frontPillar.castShadow = true;
      g.add(frontPillar);
    }
    const lintel = new THREE.Mesh(new THREE.BoxGeometry(w * 0.48, 0.9, 0.38), woodMat);
    lintel.position.set(0, h - 0.45, d / 2);
    g.add(lintel);
    const roof = new THREE.Mesh(new THREE.ConeGeometry(Math.max(w, d) * 0.78, 2.8, 4), roofMat);
    roof.rotation.y = Math.PI / 4;
    roof.position.y = h + 1.4;
    roof.castShadow = true;
    g.add(roof);
    const lantern = new THREE.Mesh(new THREE.SphereGeometry(0.24, 8, 8), warmGlow);
    lantern.position.set(0, h - 0.45, 0);
    g.add(lantern);
    const prop = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.75, 0.85), type === 'workshop' ? stoneMat : woodMat);
    prop.position.set(-1.3, 0.55, -1.2);
    g.add(prop);
    if (type === 'workshop') {
      const forge = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.3, 1.0), stoneMat);
      forge.position.set(1.5, 0.7, -1.4);
      g.add(forge);
      const embers = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.35, 0.4), warmGlow);
      embers.position.set(1.5, 0.85, -0.95);
      g.add(embers);
    }
  } else if (type === 'farm') {
    const frame = new THREE.Mesh(new THREE.BoxGeometry(5.6, 0.25, 5.6), woodMat);
    frame.position.y = 0.12;
    g.add(frame);
    const cropMat = new THREE.MeshStandardMaterial({ color: '#65a30d', roughness: 0.85 });
    for (let x = -1.8; x <= 1.8; x += 1.2) {
      for (let z = -1.8; z <= 1.8; z += 1.2) {
        const plant = new THREE.Mesh(new THREE.ConeGeometry(0.35, 0.8, 6), cropMat);
        plant.position.set(x, 0.55, z);
        g.add(plant);
      }
    }
  } else if (type === 'castle') {
    // Enterable player-built Fortress Keep with wide archway
    const floor = new THREE.Mesh(new THREE.BoxGeometry(11.5, 0.3, 10.5), stoneMat);
    floor.position.y = 0.12;
    floor.receiveShadow = true;
    g.add(floor);
    const back = new THREE.Mesh(new THREE.BoxGeometry(11.5, 6.2, 0.9), stoneMat);
    back.position.set(0, 3.1, -4.8);
    back.castShadow = true;
    g.add(back);
    for (const s of [-1, 1]) {
      const side = new THREE.Mesh(new THREE.BoxGeometry(0.9, 6.2, 10.5), stoneMat);
      side.position.set(s * 5.3, 3.1, 0);
      side.castShadow = true;
      g.add(side);
      const fWall = new THREE.Mesh(new THREE.BoxGeometry(3.6, 6.2, 0.9), stoneMat);
      fWall.position.set(s * 3.8, 3.1, 4.8);
      fWall.castShadow = true;
      g.add(fWall);
    }
    const lintel = new THREE.Mesh(new THREE.BoxGeometry(4.4, 1.8, 1.0), stoneMat);
    lintel.position.set(0, 5.3, 4.8);
    g.add(lintel);
    for (const [cx, cz] of [[-5.4, -4.8], [5.4, -4.8], [-5.4, 4.8], [5.4, 4.8]]) {
      const turret = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.4, 8.5, 8), stoneMat);
      turret.position.set(cx, 4.25, cz);
      turret.castShadow = true;
      g.add(turret);
      const cap = new THREE.Mesh(new THREE.ConeGeometry(1.6, 2.0, 8), roofMat);
      cap.position.set(cx, 9.5, cz);
      g.add(cap);
    }
  }
  return g;
}

export function buildFantasyWorld(
  scene: THREE.Scene,
  textures: ProceduralTextureSet,
  quality: GraphicsQuality
): WorldHandles {
  const colliders: Array<{ x: number; z: number; radius: number; maxY: number }> = [];

  // 1. 3-Point Atmospheric Lighting Rig (Sky Hemi + Warm Sun + Cool Rim Backlight)
  const hemiLight = new THREE.HemisphereLight('#c7e4ff', '#4b5539', 0.85);
  scene.add(hemiLight);

  const sunLight = new THREE.DirectionalLight('#fff2d6', 1.65);
  sunLight.position.set(120, 180, 90);
  sunLight.castShadow = quality !== 'Low';
  // Smaller shadow maps save substantial GPU bandwidth on phones.
  const shadowSize = quality === 'Ultra' ? 1536 : quality === 'High' ? 1024 : quality === 'Medium' ? 768 : 512;
  sunLight.shadow.mapSize.set(shadowSize, shadowSize);
  sunLight.shadow.camera.near = 10;
  sunLight.shadow.camera.far = 420;
  const d = 115;
  sunLight.shadow.camera.left = -d;
  sunLight.shadow.camera.right = d;
  sunLight.shadow.camera.top = d;
  sunLight.shadow.camera.bottom = -d;
  sunLight.shadow.bias = -0.0004;
  sunLight.shadow.normalBias = 0.035;
  scene.add(sunLight);
  scene.add(sunLight.target);

  const rimLight = new THREE.DirectionalLight('#93c5fd', 0.42);
  rimLight.position.set(-100, 75, -110);
  scene.add(rimLight);
  scene.add(rimLight.target);

  // Warm hearth light at Oakhearth Village center
  const hearthLight = new THREE.PointLight('#fb923c', 3.5, 42, 1.5);
  hearthLight.position.set(0, getTerrainHeight(0, 4) + 2.6, 4);
  scene.add(hearthLight);

  // Custom Atmospheric Sky Dome Shader + Drifting Cloud Layer
  const skyUniforms = {
    topColor: { value: new THREE.Color('#2563eb') },
    horizonColor: { value: new THREE.Color('#bae6fd') },
  };
  const skyDome = new THREE.Mesh(
    new THREE.SphereGeometry(680, 24, 16),
    new THREE.ShaderMaterial({
      uniforms: skyUniforms,
      vertexShader: `
        varying vec3 vWorldPos;
        void main() {
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorldPos = position;
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform vec3 topColor;
        uniform vec3 horizonColor;
        varying vec3 vWorldPos;
        void main() {
          float h = normalize(vWorldPos).y;
          float t = pow(clamp(h, 0.0, 1.0), 0.55);
          gl_FragColor = vec4(mix(horizonColor, topColor, t), 1.0);
        }
      `,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
    })
  );
  scene.add(skyDome);

  // Celestial Sun & Moon Orbs + Drifting Cloud Band
  const sunDisc = new THREE.Mesh(
    new THREE.SphereGeometry(15, 16, 16),
    new THREE.MeshBasicMaterial({ color: '#fef08a', fog: false })
  );
  scene.add(sunDisc);

  const moonDisc = new THREE.Mesh(
    new THREE.SphereGeometry(11, 16, 16),
    new THREE.MeshBasicMaterial({ color: '#e0f2fe', fog: false })
  );
  scene.add(moonDisc);

  const cloudGroup = new THREE.Group();
  const cloudMat = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    roughness: 1,
    transparent: true,
    opacity: 0.72,
    fog: false,
  });
  const clouds: THREE.Group[] = [];
  for (let i = 0; i < 24; i++) {
    const cg = new THREE.Group();
    for (let p = 0; p < 3; p++) {
      const puff = new THREE.Mesh(new THREE.SphereGeometry(9 + p * 2.5, 8, 6), cloudMat);
      puff.scale.set(1.8, 0.45, 1.2);
      puff.position.set((p - 1) * 10, (p % 2) * 2, 0);
      cg.add(puff);
    }
    const ca = (i / 24) * Math.PI * 2;
    const cr = 160 + (i % 5) * 95;
    cg.position.set(Math.cos(ca) * cr, 118 + (i % 4) * 16, Math.sin(ca) * cr);
    cloudGroup.add(cg);
    clouds.push(cg);
  }
  scene.add(cloudGroup);

  // 2. High-Detail Bump-Mapped, Slope & Road-Blended Terrain Mesh
  const segs = quality === 'Low' ? 140 : quality === 'Medium' ? 190 : 240;
  const terrainGeo = new THREE.PlaneGeometry(WORLD_RADIUS * 2, WORLD_RADIUS * 2, segs, segs);
  terrainGeo.rotateX(-Math.PI / 2);

  const posAttr = terrainGeo.attributes.position as THREE.BufferAttribute;
  const colors = new Float32Array(posAttr.count * 3);
  const cTmp = new THREE.Color();
  const cRegion = new THREE.Color();
  const cCliff = new THREE.Color('#57534e');
  const cSnow = new THREE.Color('#eef6fc');
  const cRoad = new THREE.Color('#a88c66');
  const cSand = new THREE.Color('#d2b47c');

  for (let i = 0; i < posAttr.count; i++) {
    const x = posAttr.getX(i);
    const z = posAttr.getZ(i);
    const y = getTerrainHeight(x, z);
    posAttr.setY(i, y);

    const weights = getRegionBlendWeights(x, z);
    cTmp.setRGB(0, 0, 0);
    for (const [rid, w] of Object.entries(weights)) {
      const reg = REGIONS[rid as keyof typeof REGIONS];
      cRegion.set(y > 20 ? reg.accentGroundColor : reg.groundColor);
      cTmp.r += cRegion.r * w;
      cTmp.g += cRegion.g * w;
      cTmp.b += cRegion.b * w;
    }

    const road = getRoadFactor(x, z);
    if (road > 0.05 && y > WATER_LEVEL + 0.3) {
      cTmp.lerp(cRoad, road * 0.75);
    }

    const slope = getTerrainSlope(x, z);
    if (slope > 0.42) {
      cTmp.lerp(cCliff, Math.min(0.84, (slope - 0.42) * 1.4));
    }

    if (y > 28) {
      cTmp.lerp(cSnow, Math.min(0.92, (y - 28) / 14));
    }

    if (y < WATER_LEVEL + 0.65) {
      cTmp.lerp(cSand, y < WATER_LEVEL ? 0.62 : 0.4);
    }

    colors[i * 3] = cTmp.r;
    colors[i * 3 + 1] = cTmp.g;
    colors[i * 3 + 2] = cTmp.b;
  }
  terrainGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  terrainGeo.computeVertexNormals();

  const terrainMat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    map: textures.terrainDetail,
    bumpMap: textures.terrainBump,
    bumpScale: 0.28,
    roughness: 0.86,
    metalness: 0.04,
  });
  const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
  terrainMesh.receiveShadow = true;
  scene.add(terrainMesh);

  // 3. Water, Lava & Animated Waterfall
  const waterMat = new THREE.MeshStandardMaterial({
    color: '#289dd6',
    map: textures.waterTex,
    transparent: true,
    opacity: 0.78,
    roughness: 0.1,
    metalness: 0.28,
  });
  const waterMesh = new THREE.Mesh(new THREE.PlaneGeometry(WORLD_RADIUS * 2.2, WORLD_RADIUS * 2.2), waterMat);
  waterMesh.rotation.x = -Math.PI / 2;
  waterMesh.position.y = WATER_LEVEL;
  scene.add(waterMesh);

  const lavaMat = new THREE.MeshStandardMaterial({
    color: '#ff5500',
    map: textures.lavaTex,
    emissive: '#ff4500',
    emissiveIntensity: 1.25,
    roughness: 0.3,
  });
  const lavaMesh = new THREE.Mesh(new THREE.CircleGeometry(102, 42), lavaMat);
  lavaMesh.rotation.x = -Math.PI / 2;
  lavaMesh.position.set(400, 9.2, -400);
  scene.add(lavaMesh);

  const waterfallMat = new THREE.MeshStandardMaterial({
    color: '#bae6fd',
    map: textures.waterTex,
    emissive: '#38bdf8',
    emissiveIntensity: 0.4,
    transparent: true,
    opacity: 0.86,
    side: THREE.DoubleSide,
  });
  const waterfallMesh = new THREE.Mesh(new THREE.PlaneGeometry(12, 23), waterfallMat);
  waterfallMesh.position.set(-125, 8.8, -55);
  waterfallMesh.rotation.y = 0.45;
  scene.add(waterfallMesh);
  const wfCliff = new THREE.Mesh(
    new THREE.CylinderGeometry(12, 16, 22, 10),
    new THREE.MeshStandardMaterial({ map: textures.stoneTex, bumpMap: textures.stoneBump, bumpScale: 0.1, roughness: 0.9 })
  );
  wfCliff.position.set(-130, 8, -64);
  scene.add(wfCliff);

  // 4. Multi-Tiered Trees (skipping Volcano & Desert; adding Palms + Cacti in Desert!)
  const treeCount = quality === 'Low' ? 220 : quality === 'Medium' ? 360 : quality === 'High' ? 520 : 620;
  const trunkGeo = new THREE.CylinderGeometry(0.32, 0.58, 4.6, 8);
  trunkGeo.translate(0, 2.2, 0);
  const trunkMat = new THREE.MeshStandardMaterial({ map: textures.barkTex, roughness: 0.9 });

  const crownLowerGeo = new THREE.ConeGeometry(2.7, 3.6, 9);
  crownLowerGeo.translate(0, 4.4, 0);
  const crownMidGeo = new THREE.ConeGeometry(2.05, 3.3, 9);
  crownMidGeo.translate(0, 6.2, 0);
  const crownTopGeo = new THREE.ConeGeometry(1.3, 2.8, 9);
  crownTopGeo.translate(0, 7.9, 0);

  const canopyMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.78 });
  const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
  const lowerInst = new THREE.InstancedMesh(crownLowerGeo, canopyMat, treeCount);
  const midInst = new THREE.InstancedMesh(crownMidGeo, canopyMat, treeCount);
  const topInst = new THREE.InstancedMesh(crownTopGeo, canopyMat, treeCount);
  trunkInst.castShadow = quality !== 'Low';
  lowerInst.castShadow = quality !== 'Low';
  midInst.castShadow = quality !== 'Low';

  const dummy = new THREE.Object3D();
  const tint = new THREE.Color();
  let placedTrees = 0;

  for (let attempt = 0; attempt < treeCount * 5 && placedTrees < treeCount; attempt++) {
    const angle = attempt * 2.39996;
    const radius = 52 + ((attempt * 19.7) % (WORLD_RADIUS - 105));
    const tx = Math.cos(angle) * radius;
    const tz = Math.sin(angle) * radius;
    const ty = getTerrainHeight(tx, tz);
    if (ty < WATER_LEVEL + 0.65) continue;
    if (getRoadFactor(tx, tz) > 0.2) continue;
    const reg = getRegionAtName(tx, tz);
    if (reg === 'volcano_region' || reg === 'desert_dunes') continue;
    if (BOSSES.some((b) => Math.hypot(tx - b.arenaX, tz - b.arenaZ) < b.arenaRadius + 7)) continue;

    const sc = 0.82 + ((attempt * 37) % 100) / 200;
    dummy.position.set(tx, ty - 0.18, tz);
    dummy.rotation.set(0, (attempt * 1.1) % (Math.PI * 2), 0);
    dummy.scale.set(sc, sc * (0.9 + (attempt % 5) * 0.09), sc);
    dummy.updateMatrix();
    trunkInst.setMatrixAt(placedTrees, dummy.matrix);
    lowerInst.setMatrixAt(placedTrees, dummy.matrix);
    midInst.setMatrixAt(placedTrees, dummy.matrix);
    topInst.setMatrixAt(placedTrees, dummy.matrix);

    if (reg === 'frozen_kingdom') {
      tint.set('#d8ecf8').lerp(new THREE.Color('#38bdf8'), 0.18);
    } else if (reg === 'ghost_swamp') {
      tint.set('#1f4235');
    } else if (reg === 'skeleton_kingdom' || reg === 'ancient_lands') {
      tint.set('#44403c');
    } else if (reg === 'goblin_kingdom') {
      tint.set('#4d6b28');
    } else {
      tint.set('#228b22').offsetHSL(((attempt % 11) - 5) * 0.014, 0, ((attempt % 7) - 3) * 0.022);
    }
    lowerInst.setColorAt(placedTrees, tint);
    midInst.setColorAt(placedTrees, tint.clone().offsetHSL(0, 0, 0.04));
    topInst.setColorAt(placedTrees, tint.clone().offsetHSL(0, 0, 0.08));
    placedTrees++;
  }
  trunkInst.count = placedTrees;
  lowerInst.count = placedTrees;
  midInst.count = placedTrees;
  topInst.count = placedTrees;
  trunkInst.computeBoundingSphere();
  lowerInst.computeBoundingSphere();
  midInst.computeBoundingSphere();
  topInst.computeBoundingSphere();
  scene.add(trunkInst, lowerInst, midInst, topInst);

  // Grass & Fern Clusters InstancedMesh
  const grassCount = quality === 'Low' ? 180 : quality === 'Medium' ? 360 : quality === 'High' ? 500 : 620;
  const grassGeo = new THREE.ConeGeometry(0.48, 0.72, 5);
  grassGeo.translate(0, 0.36, 0);
  const grassMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.85 });
  const grassInst = new THREE.InstancedMesh(grassGeo, grassMat, grassCount);
  let placedGrass = 0;
  for (let i = 0; i < grassCount * 3 && placedGrass < grassCount; i++) {
    const a = i * 2.39996 + 0.5;
    const r = 20 + ((i * 17.9) % 520);
    const gx = Math.cos(a) * r;
    const gz = Math.sin(a) * r;
    const gy = getTerrainHeight(gx, gz);
    if (gy < WATER_LEVEL + 0.4 || getRoadFactor(gx, gz) > 0.25) continue;
    const reg = getRegionAtName(gx, gz);
    if (reg === 'volcano_region' || reg === 'frozen_kingdom' || reg === 'desert_dunes') continue;
    dummy.position.set(gx, gy - 0.05, gz);
    dummy.rotation.set(0, a, 0);
    dummy.scale.set(1.1 + (i % 3) * 0.25, 0.75 + (i % 4) * 0.2, 1.1);
    dummy.updateMatrix();
    grassInst.setMatrixAt(placedGrass, dummy.matrix);
    grassInst.setColorAt(
      placedGrass,
      tint.set(reg === 'ghost_swamp' ? '#2d6a4f' : '#4d9b36').offsetHSL(0, 0, ((i % 5) - 2) * 0.03)
    );
    placedGrass++;
  }
  grassInst.count = placedGrass;
  grassInst.computeBoundingSphere();
  scene.add(grassInst);

  // Rocks & Basalt Boulders InstancedMesh
  const rockCount = quality === 'Low' ? 100 : quality === 'Medium' ? 180 : quality === 'High' ? 230 : 280;
  const rockGeo = new THREE.DodecahedronGeometry(1.65, 0);
  rockGeo.translate(0, 0.9, 0);
  const rockMat = new THREE.MeshStandardMaterial({
    map: textures.stoneTex,
    bumpMap: textures.stoneBump,
    bumpScale: 0.08,
    roughness: 0.9,
  });
  const rockInst = new THREE.InstancedMesh(rockGeo, rockMat, rockCount);
  let placedRocks = 0;
  for (let i = 0; i < rockCount * 3 && placedRocks < rockCount; i++) {
    const a = i * 1.73;
    const r = 45 + ((i * 29.3) % (WORLD_RADIUS - 85));
    const rx = Math.cos(a) * r;
    const rz = Math.sin(a) * r;
    const ry = getTerrainHeight(rx, rz);
    if (ry < WATER_LEVEL - 0.5 || getRoadFactor(rx, rz) > 0.25) continue;
    if (BOSSES.some((b) => Math.hypot(rx - b.arenaX, rz - b.arenaZ) < b.arenaRadius + 5)) continue;
    const sc = 0.65 + (i % 7) * 0.26;
    dummy.position.set(rx, ry - 0.22, rz);
    dummy.rotation.set(i * 0.3, i * 0.9, 0);
    dummy.scale.set(sc * 1.2, sc * 0.85, sc);
    dummy.updateMatrix();
    rockInst.setMatrixAt(placedRocks, dummy.matrix);
    placedRocks++;
  }
  rockInst.count = placedRocks;
  rockInst.computeBoundingSphere();
  scene.add(rockInst);

  // Flowers InstancedMesh
  const flowerCount = quality === 'Low' ? 100 : quality === 'Medium' ? 180 : quality === 'High' ? 250 : 320;
  const flowerGeo = new THREE.ConeGeometry(0.3, 0.48, 5);
  flowerGeo.rotateX(Math.PI);
  flowerGeo.translate(0, 0.36, 0);
  const flowerMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.45 });
  const flowerInst = new THREE.InstancedMesh(flowerGeo, flowerMat, flowerCount);
  const flowerPalette = ['#f43f5e', '#facc15', '#c084fc', '#38bdf8', '#fb923c'];
  for (let i = 0; i < flowerCount; i++) {
    const a = i * 2.1;
    const r = 14 + ((i * 11.3) % 230);
    const fx = Math.cos(a) * r;
    const fz = Math.sin(a) * r;
    const fy = getTerrainHeight(fx, fz);
    dummy.position.set(fx, Math.max(WATER_LEVEL + 0.1, fy), fz);
    dummy.rotation.set(0, a, 0);
    dummy.scale.setScalar(0.85 + (i % 3) * 0.25);
    dummy.updateMatrix();
    flowerInst.setMatrixAt(i, dummy.matrix);
    flowerInst.setColorAt(i, tint.set(flowerPalette[i % flowerPalette.length]));
  }
  flowerInst.computeBoundingSphere();
  scene.add(flowerInst);

  // Biome Showcase Props:
  // A. Frozen Kingdom Ice Spires & Glacial Arch
  const spireMatIce = new THREE.MeshStandardMaterial({
    color: '#bae6fd',
    emissive: '#0284c7',
    emissiveIntensity: 0.55,
    roughness: 0.14,
    metalness: 0.2,
  });
  for (let i = 0; i < 18; i++) {
    const a = (i / 18) * Math.PI * 2;
    const sx = Math.cos(a) * 105;
    const sz = -520 + Math.sin(a) * 105;
    const sy = getTerrainHeight(sx, sz);
    const spire = new THREE.Mesh(new THREE.ConeGeometry(2.0, 9 + (i % 4) * 2.4, 5), spireMatIce);
    spire.position.set(sx, sy + 4, sz);
    spire.rotation.z = (i % 2 === 0 ? 1 : -1) * 0.14;
    scene.add(spire);
  }

  // B. Hellfire Caldera Obsidian Spikes & Burning Embers
  const obsidianSpireMat = new THREE.MeshStandardMaterial({
    map: textures.obsidianTex,
    color: '#3f1d20',
    emissive: '#dc2626',
    emissiveIntensity: 0.35,
    roughness: 0.42,
    metalness: 0.45,
  });
  for (let i = 0; i < 20; i++) {
    const a = (i / 20) * Math.PI * 2;
    const rx = 400 + Math.cos(a) * (105 + (i % 3) * 24);
    const rz = -400 + Math.sin(a) * (105 + (i % 3) * 24);
    const ry = getTerrainHeight(rx, rz);
    const sp = new THREE.Mesh(new THREE.ConeGeometry(2.2, 11 + (i % 4) * 3, 5), obsidianSpireMat);
    sp.position.set(rx, ry + 5, rz);
    sp.rotation.z = (i % 2 === 0 ? 1 : -1) * 0.2;
    scene.add(sp);
  }

  // C. Scorching Desert Pyramids, Oasis Palm Trees & Cacti
  const pyramidMat = new THREE.MeshStandardMaterial({
    map: textures.sandTex,
    color: '#e6be78',
    roughness: 0.85,
  });
  for (const [px, pz, sz] of [[-565, -75, 16], [-585, 125, 12], [-395, 130, 10]]) {
    const py = getTerrainHeight(px, pz);
    const pyr = new THREE.Mesh(new THREE.ConeGeometry(sz, sz * 1.15, 4), pyramidMat);
    pyr.rotation.y = Math.PI / 4;
    pyr.position.set(px, py + sz * 0.52, pz);
    pyr.castShadow = true;
    scene.add(pyr);
    colliders.push({ x: px, z: pz, radius: sz * 0.65, maxY: py + sz });
  }
  const palmLeafMat = new THREE.MeshStandardMaterial({ color: '#16a34a', roughness: 0.72 });
  for (let i = 0; i < 14; i++) {
    const a = (i / 14) * Math.PI * 2;
    const ox = -415 + Math.cos(a) * 29;
    const oz = 78 + Math.sin(a) * 29;
    const oy = getTerrainHeight(ox, oz);
    if (oy < WATER_LEVEL + 0.2) continue;
    const pg = new THREE.Group();
    pg.position.set(ox, oy, oz);
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.42, 6.2, 6), trunkMat);
    trunk.position.y = 3.1;
    trunk.rotation.z = 0.14;
    pg.add(trunk);
    for (let f = 0; f < 5; f++) {
      const fa = (f / 5) * Math.PI * 2;
      const frond = new THREE.Mesh(new THREE.ConeGeometry(0.55, 2.8, 4), palmLeafMat);
      frond.position.set(-0.4 + Math.cos(fa) * 1.2, 6.0, Math.sin(fa) * 1.2);
      frond.rotation.z = -1.2;
      frond.rotation.y = fa;
      pg.add(frond);
    }
    scene.add(pg);
  }

  // 5. Boss Arenas (all 8)
  for (const boss of BOSSES) {
    scene.add(buildBossArena(boss));
  }

  // 6. Settlements, Extra Village Buildings, Bridges, 6 Castles, 4 Ruins & 3 Underground Crypts
  const structureGroup = new THREE.Group();
  scene.add(structureGroup);

  const castleBundle = buildAllCastlesRuinsAndCrypts(scene, textures);

  const addWorldBuilding = (type: StructureType, x: number, z: number, ry = 0, colliderRadius = 0) => {
    const y = getTerrainHeight(x, z);
    const m = buildStructureMesh(type, textures);
    m.position.set(x, y, z);
    m.rotation.y = ry;
    structureGroup.add(m);
    if (colliderRadius > 0) {
      colliders.push({ x, z, radius: colliderRadius, maxY: y + 12 });
    }
  };

  // Expanded Oakhearth Village (0, 0) with Tavern, Forge, Alchemist, Mage Hall, Barracks & Bridges
  addWorldBuilding('house', -14, -18, 0.4);       // Village Inn
  addWorldBuilding('workshop', -26, 8, 1.57);     // Blacksmith Forge
  addWorldBuilding('house', 22, -16, -0.8);       // Merchant Guildhall
  addWorldBuilding('workshop', -28, -22, 0.9);    // Alchemist Laboratory
  addWorldBuilding('house', 16, 18, -0.5);        // Elder Manor
  addWorldBuilding('storage', -18, 28, 0.25);     // Village Granary
  addWorldBuilding('farm', 29, 25, 0);
  addWorldBuilding('farm', -36, 22, 0.3);
  addWorldBuilding('campfire', 0, 4, 0);
  addWorldBuilding('tower', 34, -28, 0, 2.5);
  addWorldBuilding('tower', -38, -32, 0, 2.5);
  addWorldBuilding('tower', -8, 42, 0, 2.5);
  addWorldBuilding('tower', 8, 42, 0, 2.5);

  // Wooden Bridges spanning the Western River towards the Scorching Desert & Mountains
  for (const [bx, bz, rot] of [[-78, 12, 0.15], [-92, -85, -0.2]]) {
    const bridge = new THREE.Mesh(
      new THREE.BoxGeometry(26, 0.7, 5.2),
      new THREE.MeshStandardMaterial({ map: textures.woodTex, roughness: 0.78 })
    );
    bridge.position.set(bx, WATER_LEVEL + 1.2, bz);
    bridge.rotation.y = rot;
    bridge.receiveShadow = true;
    scene.add(bridge);
  }

  // Mountain Camp & Crystal Cave Entrance (-325, -245)
  addWorldBuilding('campfire', -275, -202, 0);
  addWorldBuilding('storage', -284, -208, 0.7);
  const caveGroup = new THREE.Group();
  const caveY = getTerrainHeight(-325, -245);
  caveGroup.position.set(-325, caveY, -245);
  const caveArch = new THREE.Mesh(
    new THREE.TorusGeometry(6.5, 2.2, 8, 14, Math.PI),
    new THREE.MeshStandardMaterial({ map: textures.stoneTex, roughness: 0.9 })
  );
  caveArch.position.y = 0.5;
  caveGroup.add(caveArch);
  for (let i = 0; i < 6; i++) {
    const cry = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.9, 0),
      new THREE.MeshStandardMaterial({ color: '#38bdf8', emissive: '#0284c7', emissiveIntensity: 0.95 })
    );
    cry.position.set(-3 + i * 1.2, 1.2 + (i % 2), -3 - (i % 3));
    caveGroup.add(cry);
  }
  scene.add(caveGroup);

  // Goblin Kingdom Outpost Towers
  addWorldBuilding('tower', 328, -22, 0, 2.5);
  addWorldBuilding('tower', 372, -22, 0, 2.5);

  // Skeleton Kingdom Watchtower
  addWorldBuilding('tower', 305, 340, 0, 2.5);

  // Ghost Swamp Abandoned Huts (-350, 315)
  addWorldBuilding('house', -348, 312, 1.1);
  addWorldBuilding('storage', -368, 330, -0.5);

  // Frozen Kingdom Outpost Towers (0, -490)
  addWorldBuilding('tower', -26, -495, 0, 2.5);
  addWorldBuilding('tower', 26, -495, 0, 2.5);

  // Ancient Lands Obelisks & Dark Fortress (0, 675)
  addWorldBuilding('castle', 0, 705, Math.PI);
  const obeliskMat = new THREE.MeshStandardMaterial({
    color: '#312e81',
    emissive: '#7c3aed',
    emissiveIntensity: 0.75,
    roughness: 0.3,
  });
  for (const [ox, oz] of [[-24, 560], [24, 560], [-36, 610], [36, 610]]) {
    const oy = getTerrainHeight(ox, oz);
    const ob = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 1.4, 13, 4), obeliskMat);
    ob.position.set(ox, oy + 6.5, oz);
    scene.add(ob);
  }

  // 7. Gatherable Resource Nodes (across all biomes including Desert & Hell!)
  const resourceNodes: ResourceNode[] = [];
  const addResourceNode = (id: string, itemId: string, label: string, x: number, z: number, color: string) => {
    const y = getTerrainHeight(x, z);
    if (y < WATER_LEVEL + 0.2) return;
    const g = new THREE.Group();
    g.position.set(x, y, z);
    const mat = new THREE.MeshStandardMaterial({
      color,
      emissive: itemId === 'crystal' || itemId === 'sun_gem' || itemId === 'obsidian_shard' || itemId === 'herbs' ? color : '#000000',
      emissiveIntensity: itemId === 'crystal' || itemId === 'sun_gem' ? 0.6 : itemId === 'obsidian_shard' ? 0.4 : 0.18,
      roughness: itemId === 'gold' || itemId === 'iron' ? 0.35 : 0.78,
      metalness: itemId === 'gold' || itemId === 'iron' ? 0.65 : 0.05,
    });
    const mesh = new THREE.Mesh(
      itemId === 'crystal' || itemId === 'sun_gem' || itemId === 'obsidian_shard'
        ? new THREE.OctahedronGeometry(0.78, 0)
        : itemId === 'herbs' || itemId === 'wild_berry'
          ? new THREE.SphereGeometry(0.55, 8, 6)
          : new THREE.DodecahedronGeometry(0.85, 0),
      mat
    );
    mesh.position.y = 0.6;
    mesh.castShadow = true;
    g.add(mesh);
    scene.add(g);
    resourceNodes.push({ id, itemId, label, x, y, z, mesh: g, cooldown: 0 });
  };

  for (let i = 0; i < 82; i++) {
    const a = i * 2.4;
    const r = 24 + ((i * 31) % 630);
    const rx = Math.cos(a) * r;
    const rz = Math.sin(a) * r;
    const reg = getRegionAtName(rx, rz);
    if (reg === 'mountain_region') {
      addResourceNode(
        `res_${i}`,
        i % 3 === 0 ? 'crystal' : i % 2 === 0 ? 'iron' : 'gold',
        i % 3 === 0 ? 'Arcane Crystal' : i % 2 === 0 ? 'Iron Vein' : 'Gold Vein',
        rx,
        rz,
        i % 3 === 0 ? '#38bdf8' : i % 2 === 0 ? '#94a3b8' : '#eab308'
      );
    } else if (reg === 'desert_dunes') {
      addResourceNode(
        `res_${i}`,
        i % 2 === 0 ? 'sun_gem' : 'gold',
        i % 2 === 0 ? 'Desert Sun Gem' : 'Desert Gold Vein',
        rx,
        rz,
        '#fbbf24'
      );
    } else if (reg === 'volcano_region') {
      addResourceNode(
        `res_${i}`,
        i % 2 === 0 ? 'obsidian_shard' : 'fire_essence',
        i % 2 === 0 ? 'Obsidian Cluster' : 'Fire Essence Crystal',
        rx,
        rz,
        i % 2 === 0 ? '#991b1b' : '#f97316'
      );
    } else if (reg === 'frozen_kingdom') {
      addResourceNode(`res_${i}`, 'crystal', 'Frost Crystal', rx, rz, '#7dd3fc');
    } else if (reg === 'green_forest' || reg === 'ghost_swamp') {
      const choice = i % 3;
      addResourceNode(
        `res_${i}`,
        choice === 0 ? 'herbs' : choice === 1 ? 'wild_berry' : 'wood',
        choice === 0 ? 'Healing Herbs' : choice === 1 ? 'Wild Berries' : 'Fallen Timber',
        rx,
        rz,
        choice === 0 ? '#22c55e' : choice === 1 ? '#ec4899' : '#92400e'
      );
    } else {
      addResourceNode(`res_${i}`, i % 2 === 0 ? 'stone' : 'iron', i % 2 === 0 ? 'Granite Stone' : 'Iron Ore', rx, rz, i % 2 === 0 ? '#64748b' : '#94a3b8');
    }
  }

  // 8. Dynamic Weather Particles
  const particleCount = quality === 'Low' ? 350 : 900;
  const pGeo = new THREE.BufferGeometry();
  const pPos = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount; i++) {
    pPos[i * 3] = (Math.random() - 0.5) * 90;
    pPos[i * 3 + 1] = Math.random() * 35;
    pPos[i * 3 + 2] = (Math.random() - 0.5) * 90;
  }
  pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
  const pMat = new THREE.PointsMaterial({
    color: '#bae6fd',
    size: 0.25,
    transparent: true,
    opacity: 0.7,
  });
  const weatherPoints = new THREE.Points(pGeo, pMat);
  weatherPoints.frustumCulled = false;
  scene.add(weatherPoints);

  const skyColor = new THREE.Color('#6cb7e8');
  const fogColor = new THREE.Color('#a8d5e5');
  const nightSky = new THREE.Color('#090d1a');

  return {
    terrainMesh,
    waterMesh,
    lavaMesh,
    waterfallMesh,
    weatherPoints,
    sunLight,
    hemiLight,
    resourceNodes,
    structureGroup,
    colliders,
    wallBoxes: castleBundle.wallBoxes,
    traps: castleBundle.traps,
    chests: castleBundle.chests,
    portals: castleBundle.portals,
    crypts: castleBundle.crypts,
    landmarkPins: castleBundle.landmarkPins,
    updateTrapsAndPortals: castleBundle.updateTrapsAndPortals,
    addPlacedStructure: (s: PlacedStructure) => {
      const m = buildStructureMesh(s.type, textures);
      m.position.set(s.x, s.y, s.z);
      m.rotation.y = s.ry;
      structureGroup.add(m);
    },
    updateEnvironment: (dt, timeOfDay, weather, playerPos) => {
      textures.waterTex.offset.y -= dt * 0.28;
      textures.waterTex.offset.x += dt * 0.06;
      textures.lavaTex.offset.y -= dt * 0.08;

      const sunAngle = ((timeOfDay - 6) / 24) * Math.PI * 2;
      const sunElevation = Math.sin(sunAngle);
      const dayFactor = THREE.MathUtils.clamp((sunElevation + 0.18) / 0.75, 0, 1);

      sunLight.position.set(
        playerPos.x + Math.cos(sunAngle) * 120,
        Math.max(18, sunElevation * 160),
        playerPos.z + 70
      );
      sunLight.target.position.copy(playerPos);
      sunLight.target.updateMatrixWorld();

      rimLight.position.set(playerPos.x - 100, 75, playerPos.z - 110);
      rimLight.target.position.copy(playerPos);
      rimLight.target.updateMatrixWorld();

      skyDome.position.copy(playerPos);
      cloudGroup.rotation.y += dt * 0.008;

      sunDisc.position.set(
        playerPos.x + Math.cos(sunAngle) * 320,
        sunElevation * 280,
        playerPos.z - 160
      );
      sunDisc.visible = sunElevation > -0.15;

      moonDisc.position.set(
        playerPos.x - Math.cos(sunAngle) * 320,
        -sunElevation * 280,
        playerPos.z - 160
      );
      moonDisc.visible = sunElevation < 0.15;

      const reg = REGIONS[getRegionAtName(playerPos.x, playerPos.z)];
      skyColor.set(reg.skyTint).lerp(nightSky, 1 - dayFactor);
      fogColor.set(reg.fogColor).lerp(nightSky, (1 - dayFactor) * 0.85);

      if (weather === 'storm') {
        skyColor.lerp(new THREE.Color('#1e293b'), 0.45);
        fogColor.lerp(new THREE.Color('#334155'), 0.4);
      }

      skyUniforms.topColor.value.copy(skyColor).multiplyScalar(0.75);
      skyUniforms.horizonColor.value.copy(fogColor);
      scene.background = skyColor;

      if (scene.fog instanceof THREE.FogExp2) {
        scene.fog.color.copy(fogColor);
        const targetDensity = weather === 'fog' ? 0.0105 : weather === 'storm' ? 0.0062 : 0.0032;
        scene.fog.density = THREE.MathUtils.lerp(scene.fog.density, targetDensity, dt * 1.5);
      }

      sunLight.intensity = 0.26 + dayFactor * 1.45;
      hemiLight.intensity = 0.36 + dayFactor * 0.52;
      hemiLight.color.set(reg.ambientLightColor);

      const showWeather = weather === 'rain' || weather === 'storm' || weather === 'snow' || weather === 'wind';
      weatherPoints.visible = showWeather;
      if (showWeather) {
        pMat.color.set(weather === 'snow' ? '#f8fafc' : weather === 'wind' ? '#a3e635' : '#93c5fd');
        pMat.size = weather === 'snow' ? 0.35 : weather === 'wind' ? 0.28 : 0.22;
        const arr = pGeo.attributes.position.array as Float32Array;
        const fallSpeed = weather === 'snow' ? 5.5 : weather === 'wind' ? 2.5 : 24;
        const driftX = weather === 'wind' ? 14 : weather === 'storm' ? 6 : 1.5;
        for (let i = 0; i < particleCount; i++) {
          arr[i * 3] += driftX * dt;
          arr[i * 3 + 1] -= fallSpeed * dt;
          if (arr[i * 3 + 1] < -2) {
            arr[i * 3] = playerPos.x + (Math.random() - 0.5) * 85;
            arr[i * 3 + 1] = playerPos.y + 24 + Math.random() * 14;
            arr[i * 3 + 2] = playerPos.z + (Math.random() - 0.5) * 85;
          }
        }
        pGeo.attributes.position.needsUpdate = true;
      }

      for (const node of resourceNodes) {
        if (node.cooldown > 0) {
          node.cooldown -= dt;
          if (node.cooldown <= 0) {
            node.mesh.visible = true;
          }
        }
      }
    },
  };
}

function getRegionAtName(x: number, z: number) {
  let best: keyof typeof REGIONS = 'green_forest';
  let bestScore = Infinity;
  for (const r of Object.values(REGIONS)) {
    const d = Math.hypot(x - r.centerX, z - r.centerZ) / r.radius;
    if (d < bestScore) {
      bestScore = d;
      best = r.id;
    }
  }
  return best;
}
