import * as THREE from 'three';
import {
  DungeonPortalInfo,
  GraphicsSettings,
  HarvestNode,
  LocationKind,
  LocationSubtype,
  ObstacleCollider,
} from '../types';
import { BIOMES, getBiomeIdAt, getTerrainSlope, getWorldHeight, WATER_LEVEL } from './biomes';
import { mulberry32 } from './noise';
import { TemplateRegistry } from './templates';

export const CHUNK_SIZE = 48;

interface LoadedChunk {
  key: string;
  cx: number;
  cz: number;
  centerX: number;
  centerZ: number;
  group: THREE.Group;
  bounds: THREE.Box3;
  disposableGeometries: THREE.BufferGeometry[];
  instancedMeshes: THREE.InstancedMesh[];
  foliageMeshes: THREE.InstancedMesh[];
  crateInstancedMesh: THREE.InstancedMesh | null;
  crystalInstancedMesh: THREE.InstancedMesh | null;
  colliders: ObstacleCollider[];
  harvestNodes: HarvestNode[];
  portals: DungeonPortalInfo[];
  locationHints: Array<{ kind: LocationKind; x: number; z: number }>;
  waterfallPositions: Array<{ x: number; z: number }>;
}

export interface HarvestReward {
  nodeId: string;
  x: number;
  y: number;
  z: number;
  kind: HarvestNode['kind'];
  itemId: string;
  quantity: number;
  shardReward: number;
  xpReward: number;
}

const _dummy = new THREE.Object3D();
const _color = new THREE.Color();
const _altColor = new THREE.Color();
const _sandColor = new THREE.Color(0xcfb87c);
const _snowColor = new THREE.Color(0xeaf4fa);
const _frustum = new THREE.Frustum();
const _projScreenMatrix = new THREE.Matrix4();

const VILLAGE_BUILDINGS: Array<{
  type: 'house' | 'tower' | 'lantern';
  x: number;
  z: number;
  ry: number;
  roofColor?: number;
}> = [
  { type: 'house', x: 24, z: 10.5, ry: 0, roofColor: 0x4338ca },
  { type: 'house', x: 14.5, z: 18, ry: Math.PI / 2, roofColor: 0x0f766e },
  { type: 'house', x: 33.5, z: 19, ry: -Math.PI / 2, roofColor: 0x9a3412 },
  { type: 'house', x: 21, z: 27.5, ry: Math.PI, roofColor: 0xbe185d },
  { type: 'tower', x: 16, z: 10, ry: 0 },
  { type: 'tower', x: 32, z: 26, ry: 0 },
  { type: 'lantern', x: 21, z: 14, ry: 0 },
  { type: 'lantern', x: 27, z: 14, ry: Math.PI },
  { type: 'lantern', x: 21, z: 22, ry: 0 },
  { type: 'lantern', x: 27, z: 22, ry: Math.PI },
  { type: 'lantern', x: 15, z: 22, ry: 0 },
];

export const VILLAGE_CAMPFIRE_POS = { x: 20.6, z: 19.4 };
const VILLAGE_WELL_POS = { x: 24.0, z: 20.8 };
const VILLAGE_STALLS: Array<{ x: number; z: number; ry: number; color: number }> = [
  { x: 17.6, z: 22.8, ry: 0.45, color: 0xe11d48 },
  { x: 29.8, z: 14.5, ry: -0.7, color: 0xd97706 },
  { x: 26.8, z: 24.6, ry: Math.PI - 0.3, color: 0x0284c7 },
];

const STARTER_LOCATIONS: Array<{
  wx: number;
  wz: number;
  id: string;
  nameAr: string;
  kind: LocationKind;
  subtype: LocationSubtype;
  level: number;
}> = [
  {
    wx: -18,
    wz: -14,
    id: 'dng_ancient_forest',
    nameAr: 'دنجن الغابة القديمة',
    kind: 'dungeon',
    subtype: 'standard',
    level: 3,
  },
  {
    wx: 42,
    wz: -20,
    id: 'crypt_forgotten',
    nameAr: 'سرداب الظلال المنسي',
    kind: 'crypt',
    subtype: 'standard',
    level: 6,
  },
  {
    wx: -48,
    wz: 32,
    id: 'castle_frontier',
    nameAr: 'قلعة الحراس الشمالية',
    kind: 'castle',
    subtype: 'guarded_castle',
    level: 5,
  },
  {
    wx: 64,
    wz: 44,
    id: 'ruin_sun_temple',
    nameAr: 'معبد الشمس الأثري',
    kind: 'ruin',
    subtype: 'ancient_temple',
    level: 4,
  },
  {
    wx: -34,
    wz: -46,
    id: 'cave_emerald_mine',
    nameAr: 'منجم الزمرد المهجور',
    kind: 'cave',
    subtype: 'abandoned_mine',
    level: 4,
  },
];

export class ChunkManager {
  private scene: THREE.Scene;
  private templates: TemplateRegistry;
  private seed: number;
  private settings: GraphicsSettings;

  private chunks = new Map<string, LoadedChunk>();
  private buildQueue: Array<{ cx: number; cz: number; key: string; distSq: number }> = [];
  private queuedKeys = new Set<string>();
  private discoveredChunkKeys = new Set<string>();
  private harvestedNodeIds = new Set<string>();
  private overworldVisible = true;
  private buildCooldown = 0;

  constructor(
    scene: THREE.Scene,
    templates: TemplateRegistry,
    seed: number,
    settings: GraphicsSettings,
    initialDiscoveredChunks: string[] = [],
    initialHarvestedNodes: string[] = [],
  ) {
    this.scene = scene;
    this.templates = templates;
    this.seed = seed;
    this.settings = settings;
    initialDiscoveredChunks.forEach((k) => this.discoveredChunkKeys.add(k));
    initialHarvestedNodes.forEach((id) => this.harvestedNodeIds.add(id));
  }

  public get activeChunkCount(): number {
    return this.chunks.size;
  }

  public get queuedChunkCount(): number {
    return this.buildQueue.length;
  }

  public getDiscoveredChunks(): string[] {
    return Array.from(this.discoveredChunkKeys);
  }

  public getHarvestedNodes(): string[] {
    return Array.from(this.harvestedNodeIds);
  }

  public setVisible(visible: boolean): void {
    this.overworldVisible = visible;
    this.chunks.forEach((c) => {
      c.group.visible = visible;
    });
  }

  public updateSettings(settings: GraphicsSettings): void {
    const foliageChanged = Math.abs(this.settings.foliageDensity - settings.foliageDensity) > 0.05;
    const shadowChanged = this.settings.shadowQuality !== settings.shadowQuality;
    this.settings = settings;

    if (shadowChanged) {
      const castShadows = settings.shadowQuality !== 'off';
      const receiveShadows = settings.shadowQuality !== 'off';
      this.chunks.forEach((chunk) => {
        chunk.group.traverse((obj) => {
          if ((obj as THREE.Mesh).isMesh) {
            const m = obj as THREE.Mesh;
            if (m.material === this.templates.terrainMaterial) {
              m.receiveShadow = receiveShadows;
            } else if (
              m.material !== this.templates.grassMaterial &&
              m.material !== this.templates.flowerMaterial &&
              m.material !== this.templates.waterMaterial
            ) {
              m.castShadow = castShadows;
              m.receiveShadow = receiveShadows;
            }
          }
        });
      });
    }

    if (foliageChanged) {
      const keys = Array.from(this.chunks.keys());
      for (const key of keys) {
        this.unloadChunk(key);
      }
    }
  }

  public update(
    playerX: number,
    playerZ: number,
    forwardX: number,
    forwardZ: number,
    viewDistanceMeters: number,
    camera: THREE.Camera,
  ): void {
    const pcx = Math.floor(playerX / CHUNK_SIZE + 0.5);
    const pcz = Math.floor(playerZ / CHUNK_SIZE + 0.5);

    // Ensure enough chunks cover viewDistanceMeters cleanly without shrinking the infinite world
    const effectiveChunkRadius = Math.max(
      this.settings.drawDistance,
      Math.ceil(viewDistanceMeters / CHUNK_SIZE),
    );
    const unloadRadius = effectiveChunkRadius + 1;

    this.discoveredChunkKeys.add(`${pcx},${pcz}`);

    for (const [key, chunk] of this.chunks.entries()) {
      const dx = Math.abs(chunk.cx - pcx);
      const dz = Math.abs(chunk.cz - pcz);
      if (dx > unloadRadius || dz > unloadRadius) {
        this.unloadChunk(key);
      }
    }

    this.buildQueue.length = 0;
    this.queuedKeys.clear();

    for (let dz = -effectiveChunkRadius; dz <= effectiveChunkRadius; dz++) {
      for (let dx = -effectiveChunkRadius; dx <= effectiveChunkRadius; dx++) {
        const cx = pcx + dx;
        const cz = pcz + dz;
        const key = `${cx},${cz}`;
        if (!this.chunks.has(key) && !this.queuedKeys.has(key)) {
          const distSq = dx * dx + dz * dz;
          const dot = dx * forwardX + dz * forwardZ;
          const score = distSq - Math.max(0, dot) * 0.5;
          this.buildQueue.push({ cx, cz, key, distSq: score });
          this.queuedKeys.add(key);
        }
      }
    }

    // Async/Staggered Chunk Loading: build max 1 prioritized chunk when cooldown allows
    if (this.buildCooldown > 0) {
      this.buildCooldown--;
    } else if (this.buildQueue.length > 0) {
      this.buildQueue.sort((a, b) => a.distSq - b.distSq);
      const next = this.buildQueue.shift()!;
      this.queuedKeys.delete(next.key);
      this.buildChunk(next.cx, next.cz, next.key);
      this.buildCooldown = this.settings.preset === 'low' ? 2 : 1;
    }

    // True Frustum + Distance Culling + Foliage LOD
    if (this.overworldVisible) {
      camera.updateMatrixWorld();
      _projScreenMatrix.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
      _frustum.setFromProjectionMatrix(_projScreenMatrix);

      const maxChunkVisibleDist = viewDistanceMeters + CHUNK_SIZE * 0.85;
      const foliageLodDist = viewDistanceMeters * 0.65;

      this.chunks.forEach((chunk) => {
        const dist = Math.hypot(chunk.centerX - playerX, chunk.centerZ - playerZ);
        if (dist <= CHUNK_SIZE * 0.9) {
          chunk.group.visible = true;
        } else if (dist > maxChunkVisibleDist) {
          chunk.group.visible = false;
          return;
        } else {
          chunk.group.visible = _frustum.intersectsBox(chunk.bounds);
        }

        if (chunk.group.visible) {
          const showFoliage = dist <= foliageLodDist;
          for (let i = 0; i < chunk.foliageMeshes.length; i++) {
            chunk.foliageMeshes[i].visible = showFoliage;
          }
        }
      });
    }
  }

  public ensureSpawnChunks(playerX: number, playerZ: number): void {
    const pcx = Math.floor(playerX / CHUNK_SIZE + 0.5);
    const pcz = Math.floor(playerZ / CHUNK_SIZE + 0.5);
    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) {
        const cx = pcx + dx;
        const cz = pcz + dz;
        const key = `${cx},${cz}`;
        if (!this.chunks.has(key)) {
          this.buildChunk(cx, cz, key);
        }
      }
    }
  }

  public getNearbyColliders(x: number, z: number, out: ObstacleCollider[]): void {
    out.length = 0;
    const pcx = Math.floor(x / CHUNK_SIZE + 0.5);
    const pcz = Math.floor(z / CHUNK_SIZE + 0.5);
    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) {
        const chunk = this.chunks.get(`${pcx + dx},${pcz + dz}`);
        if (!chunk) continue;
        for (let i = 0; i < chunk.colliders.length; i++) {
          const c = chunk.colliders[i];
          const ddx = c.x - x;
          const ddz = c.z - z;
          if (ddx * ddx + ddz * ddz < 64) {
            out.push(c);
          }
        }
      }
    }
  }

  public getNearbyPortal(x: number, z: number, maxDist = 4.2): DungeonPortalInfo | null {
    let best: DungeonPortalInfo | null = null;
    let bestSq = maxDist * maxDist;
    this.chunks.forEach((chunk) => {
      for (const p of chunk.portals) {
        const dSq = (p.x - x) * (p.x - x) + (p.z - z) * (p.z - z);
        if (dSq < bestSq) {
          bestSq = dSq;
          best = p;
        }
      }
    });
    return best;
  }

  public getNearbyLocationAtmosphere(
    x: number,
    z: number,
  ): { kind: LocationKind | null; dist: number } {
    let bestKind: LocationKind | null = null;
    let bestDist = 42;
    const pcx = Math.floor(x / CHUNK_SIZE + 0.5);
    const pcz = Math.floor(z / CHUNK_SIZE + 0.5);

    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) {
        const chunk = this.chunks.get(`${pcx + dx},${pcz + dz}`);
        if (!chunk) continue;
        for (const h of chunk.locationHints) {
          const d = Math.hypot(h.x - x, h.z - z);
          if (d < bestDist) {
            bestDist = d;
            bestKind = h.kind;
          }
        }
      }
    }
    return { kind: bestKind, dist: bestDist };
  }

  public getNearestWaterfallDist(x: number, z: number): number {
    let best = 999;
    const pcx = Math.floor(x / CHUNK_SIZE + 0.5);
    const pcz = Math.floor(z / CHUNK_SIZE + 0.5);
    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) {
        const chunk = this.chunks.get(`${pcx + dx},${pcz + dz}`);
        if (!chunk) continue;
        for (const wf of chunk.waterfallPositions) {
          const d = Math.hypot(wf.x - x, wf.z - z);
          if (d < best) best = d;
        }
      }
    }
    return best;
  }

  public getCampfirePosition(): { x: number; z: number } {
    return VILLAGE_CAMPFIRE_POS;
  }

  public damageNodesInRadius(
    x: number,
    z: number,
    radius: number,
    damage: number,
    outRewards: HarvestReward[],
  ): number {
    outRewards.length = 0;
    let hits = 0;
    const rSq = radius * radius;
    const pcx = Math.floor(x / CHUNK_SIZE + 0.5);
    const pcz = Math.floor(z / CHUNK_SIZE + 0.5);

    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) {
        const chunk = this.chunks.get(`${pcx + dx},${pcz + dz}`);
        if (!chunk) continue;

        for (let i = 0; i < chunk.harvestNodes.length; i++) {
          const node = chunk.harvestNodes[i];
          if (node.hp <= 0) continue;
          const ddx = node.x - x;
          const ddz = node.z - z;
          if (ddx * ddx + ddz * ddz <= rSq) {
            node.hp -= damage;
            hits++;
            if (node.hp <= 0) {
              this.harvestedNodeIds.add(node.id);
              const targetMesh =
                node.kind === 'crate' ? chunk.crateInstancedMesh : chunk.crystalInstancedMesh;
              if (targetMesh && node.meshIndex >= 0) {
                _dummy.position.set(0, -500, 0);
                _dummy.scale.setScalar(0.0001);
                _dummy.updateMatrix();
                targetMesh.setMatrixAt(node.meshIndex, _dummy.matrix);
                targetMesh.instanceMatrix.needsUpdate = true;
              }
              outRewards.push({
                nodeId: node.id,
                x: node.x,
                y: node.y,
                z: node.z,
                kind: node.kind,
                itemId: node.rewardItemId,
                quantity: node.rewardQty,
                shardReward: node.shardReward,
                xpReward: node.kind === 'crystal' ? 22 : 16,
              });
            }
          }
        }
      }
    }
    return hits;
  }

  private buildChunk(cx: number, cz: number, key: string): void {
    const worldCenterX = cx * CHUNK_SIZE;
    const worldCenterZ = cz * CHUNK_SIZE;
    const segments =
      this.settings.preset === 'low' ? 16 : this.settings.preset === 'medium' ? 24 : 32;

    const group = new THREE.Group();
    group.position.set(worldCenterX, 0, worldCenterZ);
    group.visible = this.overworldVisible;

    const disposableGeometries: THREE.BufferGeometry[] = [];
    const instancedMeshes: THREE.InstancedMesh[] = [];
    const foliageMeshes: THREE.InstancedMesh[] = [];
    const colliders: ObstacleCollider[] = [];
    const harvestNodes: HarvestNode[] = [];
    const portals: DungeonPortalInfo[] = [];
    const locationHints: Array<{ kind: LocationKind; x: number; z: number }> = [];
    const waterfallPositions: Array<{ x: number; z: number }> = [];

    // 1. Terrain geometry
    const terrainGeo = new THREE.PlaneGeometry(CHUNK_SIZE, CHUNK_SIZE, segments, segments);
    terrainGeo.rotateX(-Math.PI / 2);

    const posAttr = terrainGeo.attributes.position;
    const colors = new Float32Array(posAttr.count * 3);
    let minHeight = Infinity;
    let maxHeight = -Infinity;

    for (let i = 0; i < posAttr.count; i++) {
      const lx = posAttr.getX(i);
      const lz = posAttr.getZ(i);
      const wx = worldCenterX + lx;
      const wz = worldCenterZ + lz;
      const wy = getWorldHeight(wx, wz, this.seed);
      posAttr.setY(i, wy);
      if (wy < minHeight) minHeight = wy;
      if (wy > maxHeight) maxHeight = wy;

      const biomeId = getBiomeIdAt(wx, wz, this.seed);
      const biome = BIOMES[biomeId];
      _color.setHex(biome.groundHex);
      _altColor.setHex(biome.groundAltHex);

      const t = THREE.MathUtils.clamp(
        (wy - biome.heightBase) / Math.max(1, biome.heightScale),
        0,
        1,
      );
      _color.lerp(_altColor, t * 0.65);

      const vDist = Math.hypot(wx - 24, wz - 18);
      if (vDist < 14) {
        const vt = 1 - vDist / 14;
        _altColor.setHex(0xb08f62);
        _color.lerp(_altColor, vt * 0.72);
      }

      if (wy < WATER_LEVEL + 1.15) {
        const shoreT = THREE.MathUtils.clamp((WATER_LEVEL + 1.15 - wy) / 1.8, 0, 1);
        _color.lerp(_sandColor, shoreT * 0.85);
      }

      if (wy > 17.5) {
        const snowT = THREE.MathUtils.clamp((wy - 17.5) / 5.0, 0, 1);
        _color.lerp(_snowColor, snowT * 0.9);
      }

      colors[i * 3] = _color.r;
      colors[i * 3 + 1] = _color.g;
      colors[i * 3 + 2] = _color.b;
    }

    terrainGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    terrainGeo.computeVertexNormals();
    terrainGeo.computeBoundingBox();
    terrainGeo.computeBoundingSphere();
    disposableGeometries.push(terrainGeo);

    const terrainMesh = new THREE.Mesh(terrainGeo, this.templates.terrainMaterial);
    terrainMesh.receiveShadow = this.settings.shadowQuality !== 'off';
    terrainMesh.castShadow = false;
    group.add(terrainMesh);

    if (minHeight < WATER_LEVEL + 0.35) {
      const waterGeo = new THREE.PlaneGeometry(CHUNK_SIZE, CHUNK_SIZE, 1, 1);
      waterGeo.rotateX(-Math.PI / 2);
      disposableGeometries.push(waterGeo);
      const waterMesh = new THREE.Mesh(waterGeo, this.templates.waterMaterial);
      waterMesh.position.y = WATER_LEVEL;
      group.add(waterMesh);
    }

    const chunkSeed = (this.seed ^ Math.imul(cx, 73856093) ^ Math.imul(cz, 19349663)) | 0;
    const rand = mulberry32(chunkSeed);
    const centerBiome = BIOMES[getBiomeIdAt(worldCenterX, worldCenterZ, this.seed)];

    const pineTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const oakTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const rockTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const grassTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const bushTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const flowerTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const mushroomTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const cactusTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const crystalTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const crateTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number }> = [];
    const ruinTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number }> = [];
    const houseTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const towerTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number }> = [];
    const lanternTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number }> = [];
    const portalTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number }> = [];

    const castleKeepTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const castleWallTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const castleTowerTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const ruinTempleTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const caveMouthTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const mineSupportTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number }> = [];
    const stallTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number; color: number }> = [];
    const wellTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number }> = [];
    const campfireTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number }> = [];
    const fallenLogTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number }> = [];
    const waterfallTransforms: Array<{ x: number; y: number; z: number; s: number; ry: number }> = [];

    const densityMult = this.settings.foliageDensity;
    const treeAttempts = Math.round(22 * centerBiome.treeDensity * (0.55 + densityMult * 0.45));
    const rockAttempts = Math.round(14 * centerBiome.rockDensity);
    const grassAttempts = Math.round(64 * centerBiome.grassDensity * densityMult);
    const bushAttempts = Math.round(12 * centerBiome.treeDensity * (0.5 + densityMult * 0.5));
    const flowerAttempts = Math.round(22 * centerBiome.grassDensity * densityMult);

    const clearZones: Array<{ x: number; z: number; r: number }> = [
      { x: 0, z: 0, r: 7 },
      { x: 24, z: 18, r: 19 },
    ];
    for (const loc of STARTER_LOCATIONS) {
      clearZones.push({ x: loc.wx, z: loc.wz, r: loc.kind === 'castle' ? 14 : 9 });
    }

    const half = CHUNK_SIZE / 2;

    // Helper to stamp modular exterior structures + entry portal
    const placeLocation = (
      wx: number,
      wz: number,
      portalId: string,
      nameAr: string,
      kind: LocationKind,
      subtype: LocationSubtype,
      level: number,
    ) => {
      const lx = wx - worldCenterX;
      const lz = wz - worldCenterZ;
      if (lx < -half || lx >= half || lz < -half || lz >= half) return;

      const wy = getWorldHeight(wx, wz, this.seed);
      if (wy < WATER_LEVEL + 0.3) return;

      locationHints.push({ kind, x: wx, z: wz });
      clearZones.push({ x: wx, z: wz, r: kind === 'castle' ? 14 : 8 });

      if (kind === 'castle') {
        const tint =
          subtype === 'guarded_castle'
            ? 0x94a3b8
            : subtype === 'abandoned_castle'
              ? 0x64748b
              : 0x475569;
        // Central Keep slightly behind entry gate
        castleKeepTransforms.push({ x: lx, y: wy - 0.15, z: lz - 7.5, s: 1, ry: 0, color: tint });
        colliders.push({ x: wx, z: wz - 7.5, radius: 5.2, topY: wy + 12 });

        // Perimeter Walls (North, West, East) leaving South entrance open for gate portal
        castleWallTransforms.push({ x: lx, y: wy - 0.15, z: lz - 13.0, s: 1, ry: 0, color: tint });
        castleWallTransforms.push({ x: lx - 8.5, y: wy - 0.15, z: lz - 4.0, s: 1, ry: Math.PI / 2, color: tint });
        castleWallTransforms.push({ x: lx + 8.5, y: wy - 0.15, z: lz - 4.0, s: 1, ry: Math.PI / 2, color: tint });
        colliders.push({ x: wx - 8.5, z: wz - 4.0, radius: 1.5, topY: wy + 5.5 });
        colliders.push({ x: wx + 8.5, z: wz - 4.0, radius: 1.5, topY: wy + 5.5 });

        // 4 Corner Bastion Towers
        const corners: Array<[number, number]> = [
          [-8.5, -13.0],
          [8.5, -13.0],
          [-8.5, 2.5],
          [8.5, 2.5],
        ];
        for (const [ox, oz] of corners) {
          castleTowerTransforms.push({ x: lx + ox, y: wy - 0.15, z: lz + oz, s: 1, ry: 0, color: tint });
          colliders.push({ x: wx + ox, z: wz + oz, radius: 2.0, topY: wy + 10 });
        }

        // Gate Entrance Portal at (lx, lz)
        portalTransforms.push({ x: lx, y: wy - 0.05, z: lz, s: 1.05, ry: 0 });
      } else if (kind === 'ruin') {
        const tint = subtype === 'ancient_temple' ? 0xd6c79c : 0x94a3b8;
        ruinTempleTransforms.push({ x: lx, y: wy - 0.15, z: lz - 4.0, s: 1, ry: 0, color: tint });
        colliders.push({ x: wx, z: wz - 4.0, radius: 3.4, topY: wy + 6 });
        ruinTransforms.push({ x: lx - 3.6, y: wy - 0.1, z: lz + 1.5, s: 0.95, ry: 0.3 });
        ruinTransforms.push({ x: lx + 3.6, y: wy - 0.1, z: lz + 1.5, s: 0.85, ry: -0.4 });
        portalTransforms.push({ x: lx, y: wy - 0.05, z: lz, s: 1, ry: 0 });
      } else if (kind === 'cave') {
        const rockTint =
          subtype === 'ice_cave'
            ? 0x7dd3fc
            : subtype === 'volcanic_cave'
              ? 0x44403c
              : subtype === 'crystal_cave'
                ? 0x6d28d9
                : 0x64748b;
        caveMouthTransforms.push({ x: lx, y: wy - 0.15, z: lz - 1.2, s: 1.08, ry: 0, color: rockTint });
        colliders.push({ x: wx - 2.4, z: wz - 1.2, radius: 1.6, topY: wy + 4 });
        colliders.push({ x: wx + 2.4, z: wz - 1.2, radius: 1.6, topY: wy + 4 });
        if (subtype === 'abandoned_mine') {
          mineSupportTransforms.push({ x: lx, y: wy - 0.08, z: lz - 0.8, s: 1, ry: 0 });
          crateTransforms.push({ x: lx + 2.2, y: wy - 0.02, z: lz + 1.4, s: 1, ry: 0.4 });
        }
        portalTransforms.push({ x: lx, y: wy - 0.05, z: lz, s: 0.92, ry: 0 });
      } else {
        portalTransforms.push({ x: lx, y: wy - 0.05, z: lz, s: 1, ry: 0 });
      }

      portals.push({
        id: portalId,
        nameAr,
        kind,
        subtype,
        x: wx,
        y: wy,
        z: wz,
        biomeId: getBiomeIdAt(wx, wz, this.seed),
        level,
      });
    };

    // Place Starter Locations deterministically in their chunks
    for (const loc of STARTER_LOCATIONS) {
      placeLocation(loc.wx, loc.wz, loc.id, loc.nameAr, loc.kind, loc.subtype, loc.level);
    }

    // Procedural Castles, Ruins, Caves, Dungeons & Crypts in outward chunks
    const isSpawnArea = Math.abs(cx) <= 1 && Math.abs(cz) <= 1;
    if (!isSpawnArea) {
      const locRoll = rand();
      const lx = (rand() - 0.5) * 14;
      const lz = (rand() - 0.5) * 14;
      const wx = worldCenterX + lx;
      const wz = worldCenterZ + lz;
      const wy = getWorldHeight(wx, wz, this.seed);
      const slope = getTerrainSlope(wx, wz, this.seed);
      const distLv = Math.max(4, Math.round(Math.hypot(wx, wz) / 28));

      if (wy > WATER_LEVEL + 0.5 && slope < 0.72) {
        if (locRoll < 0.11) {
          const castleTypes: Array<{ st: LocationSubtype; label: string }> = [
            { st: 'abandoned_castle', label: 'قلعة مهجورة' },
            { st: 'guarded_castle', label: 'قلعة الحراس' },
            { st: 'monster_castle', label: 'قلعة الوحوش المحصنة' },
          ];
          const pick = castleTypes[Math.floor(rand() * castleTypes.length)];
          placeLocation(
            wx,
            wz,
            `castle_${key}`,
            `${pick.label} (${centerBiome.nameAr})`,
            'castle',
            pick.st,
            distLv + 2,
          );
        } else if (locRoll < 0.25) {
          const ruinTypes: Array<{ st: LocationSubtype; label: string }> = [
            { st: 'ancient_temple', label: 'معبد أثري قديم' },
            { st: 'ruined_fort', label: 'حصن مهدّم' },
            { st: 'abandoned_village', label: 'قرية أثرية مهجورة' },
          ];
          const pick = ruinTypes[Math.floor(rand() * ruinTypes.length)];
          placeLocation(
            wx,
            wz,
            `ruin_${key}`,
            `${pick.label}`,
            'ruin',
            pick.st,
            distLv,
          );
        } else if (locRoll < 0.42) {
          let st: LocationSubtype = rand() < 0.35 ? 'abandoned_mine' : 'natural_cave';
          let label = st === 'abandoned_mine' ? 'منجم مهجور' : 'كهف طبيعي عميق';
          if (centerBiome.id === 'snow_peaks') {
            st = 'ice_cave';
            label = 'كهف الجليد المتلألئ';
          } else if (centerBiome.id === 'volcanic_ridge') {
            st = 'volcanic_cave';
            label = 'كهف الحمم البركاني';
          } else if (centerBiome.id === 'arcane_glade') {
            st = 'crystal_cave';
            label = 'كهف البلورات السحرية';
          } else if (centerBiome.id === 'sunlit_coast' || centerBiome.id === 'misty_marsh') {
            st = 'lake_cave';
            label = 'كهف البحيرة الجوفية';
          }
          placeLocation(wx, wz, `cave_${key}`, label, 'cave', st, distLv);
        } else if (locRoll < 0.56) {
          const isCrypt = rand() > 0.5;
          placeLocation(
            wx,
            wz,
            `${isCrypt ? 'crypt' : 'dng'}_${key}`,
            isCrypt ? `سرداب ${centerBiome.nameAr}` : `دنجن ${centerBiome.nameAr}`,
            isCrypt ? 'crypt' : 'dungeon',
            'standard',
            distLv + 1,
          );
        }
      }
    }

    const isInsideClearZone = (wx: number, wz: number) => {
      for (let i = 0; i < clearZones.length; i++) {
        const z = clearZones[i];
        const ddx = wx - z.x;
        const ddz = wz - z.z;
        if (ddx * ddx + ddz * ddz < z.r * z.r) return true;
      }
      return false;
    };

    for (let i = 0; i < treeAttempts; i++) {
      const lx = (rand() - 0.5) * (CHUNK_SIZE - 4);
      const lz = (rand() - 0.5) * (CHUNK_SIZE - 4);
      const wx = worldCenterX + lx;
      const wz = worldCenterZ + lz;
      if (isInsideClearZone(wx, wz)) continue;

      const wy = getWorldHeight(wx, wz, this.seed);
      if (wy < WATER_LEVEL + 0.6) continue;
      if (getTerrainSlope(wx, wz, this.seed) > 0.85) continue;

      const b = BIOMES[getBiomeIdAt(wx, wz, this.seed)];
      const scale = 0.8 + rand() * 0.55;
      const ry = rand() * Math.PI * 2;
      if (b.id === 'desert_dunes') {
        cactusTransforms.push({ x: lx, y: wy - 0.05, z: lz, s: scale, ry, color: 0x4d7c0f });
        colliders.push({ x: wx, z: wz, radius: 0.4 * scale, topY: wy + 2.5 * scale });
        continue;
      }
      const isPine = b.id === 'snow_peaks' || b.id === 'mystic_woods' || rand() > 0.45;
      if (isPine) {
        pineTransforms.push({ x: lx, y: wy - 0.08, z: lz, s: scale, ry, color: b.treeTintHex });
      } else {
        oakTransforms.push({ x: lx, y: wy - 0.08, z: lz, s: scale, ry, color: b.foliageTintHex });
      }
      colliders.push({ x: wx, z: wz, radius: 0.48 * scale, topY: wy + 5.5 * scale });
    }

    if (centerBiome.id === 'desert_dunes') {
      for (let i = 0; i < 8; i++) {
        const lx = (rand() - 0.5) * (CHUNK_SIZE - 5);
        const lz = (rand() - 0.5) * (CHUNK_SIZE - 5);
        const wx = worldCenterX + lx;
        const wz = worldCenterZ + lz;
        if (isInsideClearZone(wx, wz)) continue;
        const wy = getWorldHeight(wx, wz, this.seed);
        if (wy > WATER_LEVEL + 0.5) {
          cactusTransforms.push({
            x: lx,
            y: wy - 0.05,
            z: lz,
            s: 0.8 + rand() * 0.6,
            ry: rand() * Math.PI * 2,
            color: 0x65a30d,
          });
        }
      }
    }

    for (let i = 0; i < rockAttempts; i++) {
      const lx = (rand() - 0.5) * (CHUNK_SIZE - 3);
      const lz = (rand() - 0.5) * (CHUNK_SIZE - 3);
      const wx = worldCenterX + lx;
      const wz = worldCenterZ + lz;
      if (isInsideClearZone(wx, wz)) continue;

      const wy = getWorldHeight(wx, wz, this.seed);
      const b = BIOMES[getBiomeIdAt(wx, wz, this.seed)];
      const scale = 0.65 + rand() * 1.15;
      rockTransforms.push({ x: lx, y: wy - 0.15, z: lz, s: scale, ry: rand() * Math.PI * 2, color: b.rockHex });
      colliders.push({ x: wx, z: wz, radius: 0.85 * scale, topY: wy + 1.1 * scale });
    }

    for (let i = 0; i < grassAttempts; i++) {
      const lx = (rand() - 0.5) * (CHUNK_SIZE - 2);
      const lz = (rand() - 0.5) * (CHUNK_SIZE - 2);
      const wx = worldCenterX + lx;
      const wz = worldCenterZ + lz;
      if (Math.hypot(wx - 24, wz - 18) < 13) continue;
      const wy = getWorldHeight(wx, wz, this.seed);
      if (wy < WATER_LEVEL + 0.35) continue;
      if (getTerrainSlope(wx, wz, this.seed) > 1.0) continue;

      const b = BIOMES[getBiomeIdAt(wx, wz, this.seed)];
      grassTransforms.push({
        x: lx,
        y: wy - 0.05,
        z: lz,
        s: 0.75 + rand() * 0.65,
        ry: rand() * Math.PI * 2,
        color: b.foliageTintHex,
      });
    }

    for (let i = 0; i < bushAttempts; i++) {
      const lx = (rand() - 0.5) * (CHUNK_SIZE - 4);
      const lz = (rand() - 0.5) * (CHUNK_SIZE - 4);
      const wx = worldCenterX + lx;
      const wz = worldCenterZ + lz;
      if (isInsideClearZone(wx, wz)) continue;
      const wy = getWorldHeight(wx, wz, this.seed);
      if (wy < WATER_LEVEL + 0.45) continue;
      const b = BIOMES[getBiomeIdAt(wx, wz, this.seed)];
      bushTransforms.push({
        x: lx,
        y: wy - 0.05,
        z: lz,
        s: 0.7 + rand() * 0.6,
        ry: rand() * Math.PI * 2,
        color: b.treeTintHex,
      });
    }

    const flowerPalette = [0xf43f5e, 0xfacc15, 0xc084fc, 0x38bdf8, 0xfb923c];
    for (let i = 0; i < flowerAttempts; i++) {
      const lx = (rand() - 0.5) * (CHUNK_SIZE - 3);
      const lz = (rand() - 0.5) * (CHUNK_SIZE - 3);
      const wx = worldCenterX + lx;
      const wz = worldCenterZ + lz;
      if (Math.hypot(wx - 24, wz - 18) < 13) continue;
      const wy = getWorldHeight(wx, wz, this.seed);
      if (wy < WATER_LEVEL + 0.4) continue;
      const fc = flowerPalette[i % flowerPalette.length];
      flowerTransforms.push({ x: lx, y: wy - 0.02, z: lz, s: 0.8 + rand() * 0.5, ry: rand() * Math.PI * 2, color: fc });
    }

    if (
      centerBiome.id === 'mystic_woods' ||
      centerBiome.id === 'misty_marsh' ||
      centerBiome.id === 'arcane_glade' ||
      centerBiome.id === 'emerald_forest'
    ) {
      const mushCount = centerBiome.id === 'emerald_forest' ? 4 : 9;
      for (let i = 0; i < mushCount; i++) {
        const lx = (rand() - 0.5) * (CHUNK_SIZE - 4);
        const lz = (rand() - 0.5) * (CHUNK_SIZE - 4);
        const wx = worldCenterX + lx;
        const wz = worldCenterZ + lz;
        const wy = getWorldHeight(wx, wz, this.seed);
        if (wy < WATER_LEVEL + 0.35) continue;
        const mc = centerBiome.id === 'arcane_glade' ? 0xc084fc : 0x2dd4bf;
        mushroomTransforms.push({ x: lx, y: wy - 0.02, z: lz, s: 0.8 + rand() * 0.7, ry: rand() * Math.PI * 2, color: mc });
      }
    }

    // Aetheria Village Buildings
    for (const b of VILLAGE_BUILDINGS) {
      const lx = b.x - worldCenterX;
      const lz = b.z - worldCenterZ;
      if (lx >= -half && lx < half && lz >= -half && lz < half) {
        const wy = getWorldHeight(b.x, b.z, this.seed);
        if (b.type === 'house') {
          houseTransforms.push({ x: lx, y: wy - 0.05, z: lz, s: 1, ry: b.ry, color: b.roofColor ?? 0x9b2c2c });
          colliders.push({ x: b.x, z: b.z, radius: 2.8, topY: wy + 5.5 });
        } else if (b.type === 'tower') {
          towerTransforms.push({ x: lx, y: wy - 0.05, z: lz, s: 1, ry: b.ry });
          colliders.push({ x: b.x, z: b.z, radius: 1.85, topY: wy + 8.5 });
        } else {
          lanternTransforms.push({ x: lx, y: wy - 0.05, z: lz, s: 1, ry: b.ry });
        }
      }
    }

    // Living Village Props: Market Stalls, Central Well & Resting Campfire
    for (const s of VILLAGE_STALLS) {
      const lx = s.x - worldCenterX;
      const lz = s.z - worldCenterZ;
      if (lx >= -half && lx < half && lz >= -half && lz < half) {
        const wy = getWorldHeight(s.x, s.z, this.seed);
        stallTransforms.push({ x: lx, y: wy - 0.04, z: lz, s: 1, ry: s.ry, color: s.color });
        colliders.push({ x: s.x, z: s.z, radius: 1.25, topY: wy + 2.5 });
      }
    }
    {
      const wlX = VILLAGE_WELL_POS.x - worldCenterX;
      const wlZ = VILLAGE_WELL_POS.z - worldCenterZ;
      if (wlX >= -half && wlX < half && wlZ >= -half && wlZ < half) {
        const wy = getWorldHeight(VILLAGE_WELL_POS.x, VILLAGE_WELL_POS.z, this.seed);
        wellTransforms.push({ x: wlX, y: wy - 0.04, z: wlZ, s: 1, ry: 0 });
        colliders.push({ x: VILLAGE_WELL_POS.x, z: VILLAGE_WELL_POS.z, radius: 1.2, topY: wy + 3.2 });
      }
      const cfX = VILLAGE_CAMPFIRE_POS.x - worldCenterX;
      const cfZ = VILLAGE_CAMPFIRE_POS.z - worldCenterZ;
      if (cfX >= -half && cfX < half && cfZ >= -half && cfZ < half) {
        const wy = getWorldHeight(VILLAGE_CAMPFIRE_POS.x, VILLAGE_CAMPFIRE_POS.z, this.seed);
        campfireTransforms.push({ x: cfX, y: wy - 0.02, z: cfZ, s: 1, ry: 0 });
        colliders.push({ x: VILLAGE_CAMPFIRE_POS.x, z: VILLAGE_CAMPFIRE_POS.z, radius: 0.72, topY: wy + 1.0 });
      }
    }

    // Fallen Forest Logs
    if (
      centerBiome.id === 'emerald_forest' ||
      centerBiome.id === 'mystic_woods' ||
      centerBiome.id === 'misty_marsh'
    ) {
      const logCount = rand() < 0.7 ? 1 + Math.floor(rand() * 2) : 0;
      for (let i = 0; i < logCount; i++) {
        const lx = (rand() - 0.5) * (CHUNK_SIZE - 8);
        const lz = (rand() - 0.5) * (CHUNK_SIZE - 8);
        const wx = worldCenterX + lx;
        const wz = worldCenterZ + lz;
        if (isInsideClearZone(wx, wz)) continue;
        const wy = getWorldHeight(wx, wz, this.seed);
        if (wy > WATER_LEVEL + 0.5 && getTerrainSlope(wx, wz, this.seed) < 0.45) {
          fallenLogTransforms.push({ x: lx, y: wy - 0.04, z: lz, s: 0.9 + rand() * 0.35, ry: rand() * Math.PI });
          colliders.push({ x: wx, z: wz, radius: 0.9, topY: wy + 0.65 });
        }
      }
    }

    // Scenic Waterfalls on steep slopes above water level
    if (minHeight < WATER_LEVEL + 1.5 && maxHeight > WATER_LEVEL + 4.5) {
      for (let attempt = 0; attempt < 6 && waterfallTransforms.length === 0; attempt++) {
        const lx = (rand() - 0.5) * (CHUNK_SIZE - 10);
        const lz = (rand() - 0.5) * (CHUNK_SIZE - 10);
        const wx = worldCenterX + lx;
        const wz = worldCenterZ + lz;
        if (isInsideClearZone(wx, wz)) continue;
        const wy = getWorldHeight(wx, wz, this.seed);
        const slope = getTerrainSlope(wx, wz, this.seed);
        if (wy > WATER_LEVEL + 2.2 && wy < WATER_LEVEL + 7.2 && slope > 0.52) {
          const hN = getWorldHeight(wx, wz - 2, this.seed);
          const hS = getWorldHeight(wx, wz + 2, this.seed);
          const hW = getWorldHeight(wx - 2, wz, this.seed);
          const hE = getWorldHeight(wx + 2, wz, this.seed);
          const ry = Math.atan2(hW - hE, hN - hS);
          waterfallTransforms.push({ x: lx, y: WATER_LEVEL - 0.2, z: lz, s: 1.0, ry });
          waterfallPositions.push({ x: wx, z: wz });
        }
      }
    }

    // Procedural Outpost / Watchtower in outward chunks without a major structure
    if (!isSpawnArea && portals.length === 0 && rand() < 0.22) {
      const lx = (rand() - 0.5) * 16;
      const lz = (rand() - 0.5) * 16;
      const wx = worldCenterX + lx;
      const wz = worldCenterZ + lz;
      const wy = getWorldHeight(wx, wz, this.seed);
      if (wy > WATER_LEVEL + 0.6 && getTerrainSlope(wx, wz, this.seed) < 0.55) {
        if (rand() < 0.5) {
          houseTransforms.push({ x: lx, y: wy - 0.08, z: lz, s: 0.95, ry: rand() * Math.PI * 2, color: 0x78350f });
          colliders.push({ x: wx, z: wz, radius: 2.6, topY: wy + 5.0 });
        } else {
          towerTransforms.push({ x: lx, y: wy - 0.08, z: lz, s: 0.95, ry: 0 });
          colliders.push({ x: wx, z: wz, radius: 1.8, topY: wy + 8.0 });
        }
      }
    }

    const isSpawnChunk = cx === 0 && cz === 0;

    // Harvestable Elemental Crystals
    const crystalCount = isSpawnChunk
      ? 3
      : rand() < Math.max(0.28, centerBiome.crystalChance)
        ? 1 + Math.floor(rand() * 2)
        : 0;
    for (let i = 0; i < crystalCount; i++) {
      const lx = isSpawnChunk ? -6 + i * 5.5 : (rand() - 0.5) * (CHUNK_SIZE - 8);
      const lz = isSpawnChunk ? -7 - i * 1.5 : (rand() - 0.5) * (CHUNK_SIZE - 8);
      const wx = worldCenterX + lx;
      const wz = worldCenterZ + lz;
      const wy = getWorldHeight(wx, wz, this.seed);
      if (wy < WATER_LEVEL + 0.3) continue;
      const nodeId = `cry_${key}_${i}`;
      if (this.harvestedNodeIds.has(nodeId)) continue;

      const scale = 0.85 + rand() * 0.45;
      const crystalHex =
        centerBiome.id === 'volcanic_ridge'
          ? 0xff6b35
          : centerBiome.id === 'arcane_glade'
            ? 0xc084fc
            : 0x38bdf8;
      const meshIdx = crystalTransforms.length;
      crystalTransforms.push({ x: lx, y: wy - 0.05, z: lz, s: scale, ry: rand() * Math.PI * 2, color: crystalHex });
      harvestNodes.push({
        id: nodeId,
        x: wx,
        y: wy,
        z: wz,
        kind: 'crystal',
        hp: 40,
        maxHp: 40,
        rewardItemId: 'arcane_crystal',
        rewardQty: 1,
        shardReward: 1,
        meshIndex: meshIdx,
      });
    }

    // Harvestable Supply Crates
    const crateCount = isSpawnChunk ? 2 : rand() < 0.45 ? 1 + Math.floor(rand() * 2) : 0;
    const crateLootPool = ['healing_potion', 'mana_potion', 'traveler_ration', 'spring_water', 'iron_ore', 'timber_log'];
    for (let i = 0; i < crateCount; i++) {
      const lx = isSpawnChunk ? 8 + i * 2.2 : (rand() - 0.5) * (CHUNK_SIZE - 10);
      const lz = isSpawnChunk ? -9 + i * 2.0 : (rand() - 0.5) * (CHUNK_SIZE - 10);
      const wx = worldCenterX + lx;
      const wz = worldCenterZ + lz;
      const wy = getWorldHeight(wx, wz, this.seed);
      if (wy < WATER_LEVEL + 0.3) continue;
      const nodeId = `crate_${key}_${i}`;
      if (this.harvestedNodeIds.has(nodeId)) continue;

      const meshIdx = crateTransforms.length;
      crateTransforms.push({ x: lx, y: wy - 0.02, z: lz, s: 1.0, ry: rand() * Math.PI });
      const lootId = crateLootPool[Math.abs(cx * 7 + cz * 13 + i) % crateLootPool.length];
      harvestNodes.push({
        id: nodeId,
        x: wx,
        y: wy,
        z: wz,
        kind: 'crate',
        hp: 30,
        maxHp: 30,
        rewardItemId: lootId,
        rewardQty: 1 + (i % 2),
        shardReward: 0,
        meshIndex: meshIdx,
      });
    }

    // Ambient Stone Pillar Circles
    if (isSpawnChunk || (!isSpawnArea && portals.length === 0 && rand() < centerBiome.ruinChance)) {
      const rx = isSpawnChunk ? 10 : (rand() - 0.5) * (CHUNK_SIZE - 12);
      const rz = isSpawnChunk ? -12 : (rand() - 0.5) * (CHUNK_SIZE - 12);
      const pillarCount = 3 + Math.floor(rand() * 3);
      for (let p = 0; p < pillarCount; p++) {
        const ang = (p / pillarCount) * Math.PI * 2;
        const rad = 3.2;
        const lx = rx + Math.cos(ang) * rad;
        const lz = rz + Math.sin(ang) * rad;
        const wx = worldCenterX + lx;
        const wz = worldCenterZ + lz;
        const wy = getWorldHeight(wx, wz, this.seed);
        if (wy > WATER_LEVEL + 0.4) {
          ruinTransforms.push({ x: lx, y: wy - 0.1, z: lz, s: 0.9 + (p % 2) * 0.12, ry: ang });
          colliders.push({ x: wx, z: wz, radius: 0.7, topY: wy + 4.0 });
        }
      }
    }

    const castShadows = this.settings.shadowQuality !== 'off';
    const receiveShadows = this.settings.shadowQuality !== 'off';

    const addInstanced = (
      geo: THREE.BufferGeometry,
      mat: THREE.Material,
      items: Array<{ x: number; y: number; z: number; s: number; ry: number; color?: number }>,
      allowCast: boolean,
      tintable: boolean,
      isDenseFoliage = false,
    ): THREE.InstancedMesh | null => {
      if (!geo || items.length === 0) return null;
      const im = new THREE.InstancedMesh(geo, mat, items.length);
      im.castShadow = allowCast && castShadows;
      im.receiveShadow = allowCast && receiveShadows;

      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        _dummy.position.set(it.x, it.y, it.z);
        _dummy.rotation.set(0, it.ry, 0);
        _dummy.scale.setScalar(it.s);
        _dummy.updateMatrix();
        im.setMatrixAt(i, _dummy.matrix);

        if (tintable && it.color !== undefined) {
          _color.setHex(it.color);
          const shade = 0.88 + ((i * 37) % 24) / 100;
          _color.multiplyScalar(shade);
          im.setColorAt(i, _color);
        }
      }
      im.instanceMatrix.needsUpdate = true;
      if (im.instanceColor) im.instanceColor.needsUpdate = true;
      im.computeBoundingSphere();
      group.add(im);
      instancedMeshes.push(im);
      if (isDenseFoliage) {
        foliageMeshes.push(im);
      }
      return im;
    };

    addInstanced(this.templates.pineTrunkGeo, this.templates.barkMaterial, pineTransforms, true, false);
    addInstanced(this.templates.pineCanopyGeo, this.templates.foliageMaterial, pineTransforms, true, true);
    addInstanced(this.templates.oakTrunkGeo, this.templates.barkMaterial, oakTransforms, true, false);
    addInstanced(this.templates.oakCanopyGeo, this.templates.foliageMaterial, oakTransforms, true, true);
    addInstanced(this.templates.rockGeo, this.templates.rockMaterial, rockTransforms, true, true);
    addInstanced(this.templates.grassGeo, this.templates.grassMaterial, grassTransforms, false, true, true);
    addInstanced(this.templates.bushGeo, this.templates.foliageMaterial, bushTransforms, true, true);
    addInstanced(this.templates.flowerGeo, this.templates.flowerMaterial, flowerTransforms, false, true, true);
    addInstanced(this.templates.mushroomGeo, this.templates.mushroomMaterial, mushroomTransforms, false, true, true);
    addInstanced(this.templates.cactusGeo, this.templates.foliageMaterial, cactusTransforms, true, true);
    addInstanced(this.templates.ruinGeo, this.templates.ruinMaterial, ruinTransforms, true, false);
    addInstanced(this.templates.houseWallGeo, this.templates.houseWallMaterial, houseTransforms, true, false);
    addInstanced(this.templates.houseRoofGeo, this.templates.houseRoofMaterial, houseTransforms, true, true);
    addInstanced(this.templates.towerGeo, this.templates.ruinMaterial, towerTransforms, true, false);
    addInstanced(this.templates.castleKeepGeo, this.templates.castleStoneMaterial, castleKeepTransforms, true, true);
    addInstanced(this.templates.castleWallGeo, this.templates.castleStoneMaterial, castleWallTransforms, true, true);
    addInstanced(this.templates.castleCornerTowerGeo, this.templates.castleStoneMaterial, castleTowerTransforms, true, true);
    addInstanced(this.templates.ruinTempleGeo, this.templates.ruinMaterial, ruinTempleTransforms, true, true);
    addInstanced(this.templates.caveMouthGeo, this.templates.caveRockMaterial, caveMouthTransforms, true, true);
    addInstanced(this.templates.mineSupportGeo, this.templates.mineWoodMaterial, mineSupportTransforms, true, false);
    addInstanced(this.templates.lanternGeo, this.templates.barkMaterial, lanternTransforms, true, false);
    addInstanced(this.templates.lanternBulbGeo, this.templates.lanternGlowMaterial, lanternTransforms, false, false);
    addInstanced(this.templates.portalArchGeo, this.templates.ruinMaterial, portalTransforms, true, false);
    addInstanced(this.templates.portalCoreGeo, this.templates.portalGlowMaterial, portalTransforms, false, false);
    addInstanced(this.templates.marketStallWoodGeo, this.templates.mineWoodMaterial, stallTransforms, true, false);
    addInstanced(this.templates.marketStallAwningGeo, this.templates.marketAwningMaterial, stallTransforms, true, true);
    addInstanced(this.templates.villageWellGeo, this.templates.ruinMaterial, wellTransforms, true, false);
    addInstanced(this.templates.campfireBaseGeo, this.templates.rockMaterial, campfireTransforms, true, false);
    addInstanced(this.templates.campfireFlameGeo, this.templates.campfireFlameMaterial, campfireTransforms, false, false);
    addInstanced(this.templates.fallenLogGeo, this.templates.barkMaterial, fallenLogTransforms, true, false);
    addInstanced(this.templates.waterfallGeo, this.templates.waterfallMaterial, waterfallTransforms, false, false);

    const crystalInstancedMesh = addInstanced(
      this.templates.crystalGeo,
      this.templates.crystalMaterial,
      crystalTransforms,
      true,
      true,
    );
    const crateInstancedMesh = addInstanced(
      this.templates.crateGeo,
      this.templates.crateMaterial,
      crateTransforms,
      true,
      false,
    );

    const bounds = new THREE.Box3(
      new THREE.Vector3(worldCenterX - half - 4, minHeight - 4, worldCenterZ - half - 4),
      new THREE.Vector3(worldCenterX + half + 4, Math.max(maxHeight + 18, WATER_LEVEL + 18), worldCenterZ + half + 4),
    );

    this.scene.add(group);
    this.chunks.set(key, {
      key,
      cx,
      cz,
      centerX: worldCenterX,
      centerZ: worldCenterZ,
      group,
      bounds,
      disposableGeometries,
      instancedMeshes,
      foliageMeshes,
      crateInstancedMesh,
      crystalInstancedMesh,
      colliders,
      harvestNodes,
      portals,
      locationHints,
      waterfallPositions,
    });
  }

  private unloadChunk(key: string): void {
    const chunk = this.chunks.get(key);
    if (!chunk) return;
    this.scene.remove(chunk.group);
    for (const geo of chunk.disposableGeometries) {
      geo.dispose();
    }
    for (const im of chunk.instancedMeshes) {
      im.dispose();
    }
    this.chunks.delete(key);
  }

  public disposeAll(): void {
    const keys = Array.from(this.chunks.keys());
    for (const key of keys) {
      this.unloadChunk(key);
    }
    this.buildQueue.length = 0;
    this.queuedKeys.clear();
  }
}
