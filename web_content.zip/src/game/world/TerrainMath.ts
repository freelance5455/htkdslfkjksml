import { BOSSES } from '../config/bosses';
import { REGIONS, REGION_LIST } from '../config/regions';
import { RegionDef, RegionId } from '../types/gameTypes';

export const WORLD_RADIUS = 780;
export const WATER_LEVEL = -0.6;

export interface FlatPad {
  x: number;
  z: number;
  radius: number;
  height: number;
}

// Landmark pads so every castle, ruin, and crypt gate sits cleanly on level ground
export const LANDMARK_PADS: FlatPad[] = [
  { x: -165, z: -130, radius: 22, height: 3.0 }, // Oakhearth Royal Castle
  { x: 350, z: 295, radius: 22, height: 3.5 },   // Skeleton Keep
  { x: 335, z: -45, radius: 20, height: 3.0 },   // Goblin War Bastion
  { x: -35, z: -465, radius: 22, height: 8.5 },  // Frozen Ice Citadel
  { x: 340, z: -345, radius: 22, height: 9.0 },  // Hellfire Obsidian Citadel
  { x: -490, z: 30, radius: 24, height: 3.5 },   // Desert Sun Fortress
  // Enterable Ruins
  { x: -120, z: 95, radius: 14, height: 2.2 },   // Sunken Forest Ruins
  { x: -425, z: -60, radius: 14, height: 3.5 },  // Sandstone Desert Ruins
  { x: 255, z: 270, radius: 14, height: 3.0 },   // Bone Ruins
  { x: -95, z: 450, radius: 15, height: 6.5 },   // Ancient Arcane Ruins
  // Underground Crypt Portal Entrances
  { x: 290, z: 390, radius: 12, height: 3.0 },   // Crypt 1: Cursed Bone Catacombs
  { x: -535, z: 115, radius: 12, height: 3.5 },  // Crypt 2: Pharaoh Sun Tomb
  { x: 455, z: -315, radius: 12, height: 7.5 },  // Crypt 3: Hellfire Abyss Crypt
];

function hash2(x: number, z: number): number {
  const s = Math.sin(x * 127.1 + z * 311.7) * 43758.5453123;
  return s - Math.floor(s);
}

function valueNoise(x: number, z: number): number {
  const ix = Math.floor(x);
  const iz = Math.floor(z);
  const fx = x - ix;
  const fz = z - iz;
  const ux = fx * fx * (3 - 2 * fx);
  const uz = fz * fz * (3 - 2 * fz);
  const a = hash2(ix, iz);
  const b = hash2(ix + 1, iz);
  const c = hash2(ix, iz + 1);
  const d = hash2(ix + 1, iz + 1);
  return a + (b - a) * ux + (c - a) * uz + (a - b - c + d) * ux * uz;
}

export function fbm(x: number, z: number, octaves = 4): number {
  let val = 0;
  let amp = 0.5;
  let freq = 1;
  for (let i = 0; i < octaves; i++) {
    val += amp * (valueNoise(x * freq, z * freq) * 2 - 1);
    freq *= 2.02;
    amp *= 0.5;
  }
  return val;
}

export function getRegionAt(x: number, z: number): RegionDef {
  let best = REGIONS.green_forest;
  let bestScore = Infinity;
  for (const r of REGION_LIST) {
    const dx = x - r.centerX;
    const dz = z - r.centerZ;
    const dist = Math.hypot(dx, dz) / r.radius;
    if (dist < bestScore) {
      bestScore = dist;
      best = r;
    }
  }
  return best;
}

export function getRegionBlendWeights(x: number, z: number): Record<RegionId, number> {
  const weights: Record<string, number> = {};
  let sum = 0;
  for (const r of REGION_LIST) {
    const d = Math.hypot(x - r.centerX, z - r.centerZ) / r.radius;
    const w = Math.exp(-d * d * 2.4);
    weights[r.id] = w;
    sum += w;
  }
  for (const key of Object.keys(weights)) {
    weights[key] /= sum || 1;
  }
  return weights as Record<RegionId, number>;
}

/**
 * Computes winding river & oasis channel factor (0 = dry land, 1 = deep water center)
 */
export function getRiverFactor(x: number, z: number): number {
  // Main river curving from NW mountains through Green Forest to Ghost Swamp
  const riverCenterX = -85 + Math.sin(z * 0.012) * 48 - z * 0.18;
  const distMain = Math.abs(x - riverCenterX);
  const mainChannel = Math.max(0, 1 - distMain / 16);

  // Frozen mirror lake near (90, -490)
  const lakeDist = Math.hypot(x - 90, z + 490);
  const lake = Math.max(0, 1 - lakeDist / 58);

  // Swamp lagoon near (-320, 290)
  const swampDist = Math.hypot(x + 320, z - 290);
  const swamp = Math.max(0, 1 - swampDist / 65);

  // Desert Oasis Pool near (-415, 78)
  const oasisDist = Math.hypot(x + 415, z - 78);
  const oasis = Math.max(0, 1 - oasisDist / 26);

  return Math.max(mainChannel, lake, swamp, oasis);
}

export function isLavaAt(x: number, z: number): boolean {
  const distVolcano = Math.hypot(x - 400, z + 400);
  if (distVolcano > 190) return false;
  const lavaRing = Math.abs(distVolcano - 78);
  const channel = Math.abs(x - 400 - Math.sin(z * 0.04) * 20);
  return (lavaRing < 9 && z > -470) || (channel < 7 && z > -400 && z < -250);
}

export function getTerrainHeight(x: number, z: number): number {
  let h = fbm(x * 0.0045, z * 0.0045, 4) * 14 + 2.5;

  // Village flat plateau at Oakhearth (0, 0)
  const distVillage = Math.hypot(x, z);
  if (distVillage < 85) {
    const t = Math.max(0, Math.min(1, (distVillage - 52) / 33));
    const smoothT = t * t * (3 - 2 * t);
    h = 1.6 * (1 - smoothT) + h * smoothT;
  }

  // Mountain Region high peaks (-360, -260)
  const distMtn = Math.hypot(x + 360, z + 260);
  if (distMtn < 210) {
    const k = Math.max(0, 1 - distMtn / 210);
    const ridge = Math.abs(fbm(x * 0.012 + 5, z * 0.012 - 3, 3));
    h += k * k * (26 + ridge * 28);
  }

  // Frozen Kingdom peaks (0, -520)
  const distIce = Math.hypot(x, z + 520);
  if (distIce < 210) {
    const k = Math.max(0, 1 - distIce / 210);
    h += k * k * (18 + Math.abs(fbm(x * 0.01, z * 0.01, 3)) * 18);
  }

  // Volcano / Hellfire Caldera (400, -400)
  const distVolc = Math.hypot(x - 400, z + 400);
  if (distVolc < 195) {
    const k = Math.max(0, 1 - distVolc / 195);
    const rim = Math.exp(-Math.pow((distVolc - 105) / 36, 2)) * 28;
    h += k * 14 + rim;
  }

  // Scorching Desert Dunes (-490, 30)
  const distDesert = Math.hypot(x + 490, z - 30);
  if (distDesert < 195) {
    const k = Math.max(0, 1 - distDesert / 195);
    const dunes = Math.sin(x * 0.045 + z * 0.025) * 4.2 + Math.cos(z * 0.055) * 2.2;
    h = (h * (1 - k * 0.65)) + k * (3.5 + dunes);
  }

  // Ghost Swamp depression (-360, 320)
  const distSwamp = Math.hypot(x + 360, z - 320);
  if (distSwamp < 190) {
    const k = Math.max(0, 1 - distSwamp / 190);
    h = h * (1 - k * 0.75) - k * 1.4;
  }

  // Ancient Lands stepped temple hill (0, 560)
  const distAncient = Math.hypot(x, z - 560);
  if (distAncient < 210) {
    const k = Math.max(0, 1 - distAncient / 210);
    h += k * 12;
  }

  // Carve river channels (except inside village center)
  const river = getRiverFactor(x, z);
  if (river > 0.05 && distVillage > 55) {
    h -= river * 4.8;
  }

  // Flatten Landmark Pads (Castles, Ruins, Crypt Entrances)
  for (const pad of LANDMARK_PADS) {
    const dp = Math.hypot(x - pad.x, z - pad.z);
    const outer = pad.radius + 10;
    if (dp < outer) {
      const t = Math.max(0, Math.min(1, (dp - pad.radius) / 10));
      const smooth = t * t * (3 - 2 * t);
      h = pad.height * (1 - smooth) + h * smooth;
    }
  }

  // Flatten Boss Arenas for clean, fair combat arenas
  for (const boss of BOSSES) {
    const db = Math.hypot(x - boss.arenaX, z - boss.arenaZ);
    const r = boss.arenaRadius + 14;
    if (db < r) {
      const targetH =
        boss.region === 'volcano_region'
          ? 14
          : boss.region === 'frozen_kingdom'
            ? 12
            : boss.region === 'ancient_lands'
              ? 12
              : 2.5;
      const t = Math.max(0, Math.min(1, (db - boss.arenaRadius) / 14));
      const smooth = t * t * (3 - 2 * t);
      h = targetH * (1 - smooth) + h * smooth;
    }
  }

  // Natural outer coastal drop / mountain rim beyond WORLD_RADIUS - 60
  const radial = Math.hypot(x, z);
  if (radial > WORLD_RADIUS - 70) {
    const edge = Math.min(1, (radial - (WORLD_RADIUS - 70)) / 70);
    h -= edge * 14;
  }

  return h;
}

export function getTerrainSlope(x: number, z: number): number {
  const eps = 1.6;
  const hx = (getTerrainHeight(x + eps, z) - getTerrainHeight(x - eps, z)) / (2 * eps);
  const hz = (getTerrainHeight(x, z + eps) - getTerrainHeight(x, z - eps)) / (2 * eps);
  return Math.hypot(hx, hz);
}

export function isClimbableSlope(x: number, z: number): boolean {
  return getTerrainSlope(x, z) > 0.78;
}

/**
 * Returns [0..1] road proximity for scenic dirt/cobblestone trails linking Oakhearth to outer realms
 */
export function getRoadFactor(x: number, z: number): number {
  const distFromCenter = Math.hypot(x, z);
  if (distFromCenter < 22) return 0.75; // Central village square

  const routes: Array<[number, number, number, number]> = [
    [0, 0, 0, 560],     // South Royal Road -> Ancient Lands
    [0, 0, 350, -40],   // East Road -> Goblin Kingdom
    [0, 0, -360, -260], // NW Road -> Iron Mountains
    [0, 0, 0, -490],    // North Road -> Frozen Kingdom
    [0, 0, 330, 330],   // SE Road -> Skeleton Kingdom
    [0, 0, -490, 30],   // West Caravan Road -> Scorching Desert
  ];

  let best = 0;
  for (const [x1, z1, x2, z2] of routes) {
    const dx = x2 - x1;
    const dz = z2 - z1;
    const lenSq = dx * dx + dz * dz;
    const t = Math.max(0, Math.min(1, ((x - x1) * dx + (z - z1) * dz) / lenSq));
    const px = x1 + t * dx + Math.sin(t * Math.PI * 5) * 14;
    const pz = z1 + t * dz + Math.cos(t * Math.PI * 4) * 10;
    const d = Math.hypot(x - px, z - pz);
    if (d < 6.5) {
      best = Math.max(best, 1 - d / 6.5);
    }
  }
  return best;
}
