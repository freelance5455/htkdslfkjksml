import { BOSSES } from '../config/bosses';
import { REGIONS } from '../config/regions';
import { getRegionBlendWeights, getRoadFactor, getTerrainHeight, isLavaAt, LANDMARK_PADS, WATER_LEVEL, WORLD_RADIUS } from './TerrainMath';

let cachedBaseMap: HTMLCanvasElement | null = null;
export const WORLD_MAP_PX = 360;

function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  const n = parseInt(clean, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

const REGION_RGB: Record<string, [number, number, number]> = Object.fromEntries(
  Object.entries(REGIONS).map(([k, v]) => [k, hexToRgb(v.groundColor)])
);

export function getWorldMapCanvas(): HTMLCanvasElement {
  if (cachedBaseMap) return cachedBaseMap;

  const canvas = document.createElement('canvas');
  canvas.width = WORLD_MAP_PX;
  canvas.height = WORLD_MAP_PX;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(WORLD_MAP_PX, WORLD_MAP_PX);
  const data = img.data;

  const span = WORLD_RADIUS * 2;
  const stepWorld = span / WORLD_MAP_PX;

  for (let py = 0; py < WORLD_MAP_PX; py++) {
    const wz = -WORLD_RADIUS + (py + 0.5) * stepWorld;
    for (let px = 0; px < WORLD_MAP_PX; px++) {
      const wx = -WORLD_RADIUS + (px + 0.5) * stepWorld;
      const idx = (py * WORLD_MAP_PX + px) * 4;

      if (isLavaAt(wx, wz)) {
        data[idx] = 249;
        data[idx + 1] = 88;
        data[idx + 2] = 22;
        data[idx + 3] = 255;
        continue;
      }

      const h = getTerrainHeight(wx, wz);
      if (h < WATER_LEVEL) {
        const depth = Math.min(1, (WATER_LEVEL - h) / 4);
        data[idx] = Math.round(32 - depth * 14);
        data[idx + 1] = Math.round(126 - depth * 44);
        data[idx + 2] = Math.round(182 - depth * 40);
        data[idx + 3] = 255;
        continue;
      }

      // Hillshade relief from NW light
      const hx = getTerrainHeight(wx + 6, wz) - h;
      const hz = getTerrainHeight(wx, wz + 6) - h;
      const shade = Math.max(0.68, Math.min(1.28, 1.0 - (hx + hz) * 0.045));

      const weights = getRegionBlendWeights(wx, wz);
      let r = 0;
      let g = 0;
      let b = 0;
      for (const [rid, w] of Object.entries(weights)) {
        const rgb = REGION_RGB[rid];
        r += rgb[0] * w;
        g += rgb[1] * w;
        b += rgb[2] * w;
      }

      if (h > 28) {
        const s = Math.min(0.85, (h - 28) / 14);
        r = r * (1 - s) + 235 * s;
        g = g * (1 - s) + 245 * s;
        b = b * (1 - s) + 252 * s;
      }

      const road = getRoadFactor(wx, wz);
      if (road > 0.1) {
        const t = road * 0.72;
        r = r * (1 - t) + 178 * t;
        g = g * (1 - t) + 148 * t;
        b = b * (1 - t) + 105 * t;
      }

      data[idx] = Math.min(255, Math.max(0, Math.round(r * shade)));
      data[idx + 1] = Math.min(255, Math.max(0, Math.round(g * shade)));
      data[idx + 2] = Math.min(255, Math.max(0, Math.round(b * shade)));
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(img, 0, 0);

  // Subtle contour grid
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.07)';
  ctx.lineWidth = 1;
  for (let i = 1; i < 4; i++) {
    const p = (WORLD_MAP_PX / 4) * i;
    ctx.beginPath();
    ctx.moveTo(p, 0);
    ctx.lineTo(p, WORLD_MAP_PX);
    ctx.moveTo(0, p);
    ctx.lineTo(WORLD_MAP_PX, p);
    ctx.stroke();
  }

  // Castles, Ruins, and Crypt markers
  LANDMARK_PADS.forEach((pad, idx) => {
    const lx = ((pad.x + WORLD_RADIUS) / span) * WORLD_MAP_PX;
    const lz = ((pad.z + WORLD_RADIUS) / span) * WORLD_MAP_PX;
    if (idx < 6) {
      // Castle square
      ctx.fillStyle = '#fbbf24';
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 1.2;
      ctx.fillRect(lx - 3, lz - 3, 6, 6);
      ctx.strokeRect(lx - 3, lz - 3, 6, 6);
    } else if (idx < 10) {
      // Ruin hollow square
      ctx.strokeStyle = '#fdba74';
      ctx.lineWidth = 1.4;
      ctx.strokeRect(lx - 2.5, lz - 2.5, 5, 5);
    } else {
      // Crypt portal triangle
      ctx.fillStyle = '#c084fc';
      ctx.beginPath();
      ctx.moveTo(lx, lz - 3.5);
      ctx.lineTo(lx + 3.2, lz + 2.5);
      ctx.lineTo(lx - 3.2, lz + 2.5);
      ctx.closePath();
      ctx.fill();
    }
  });

  for (const b of BOSSES) {
    const bx = ((b.arenaX + WORLD_RADIUS) / span) * WORLD_MAP_PX;
    const bz = ((b.arenaZ + WORLD_RADIUS) / span) * WORLD_MAP_PX;
    const br = Math.max(3, (b.arenaRadius / span) * WORLD_MAP_PX);
    ctx.strokeStyle = b.accentColor;
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.arc(bx, bz, br, 0, Math.PI * 2);
    ctx.stroke();
  }

  cachedBaseMap = canvas;
  return canvas;
}
