import * as THREE from 'three';
import { ProceduralTextureSet } from '../materials/ProceduralTextures';
import { RegionId } from '../types/gameTypes';
import { getTerrainHeight } from './TerrainMath';

export interface WallBox {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  minY: number;
  maxY: number;
}

export type TrapKind = 'spike' | 'blade' | 'fire_jet' | 'rune';

export interface TrapInstance {
  id: string;
  kind: TrapKind;
  x: number;
  y: number;
  z: number;
  radius: number;
  damage: number;
  phase: number;
  cooldown: number;
  movingPart: THREE.Object3D;
  telegraphMat?: THREE.MeshStandardMaterial;
  slow?: boolean;
  poison?: boolean;
}

export interface ChestInstance {
  id: string;
  label: string;
  x: number;
  y: number;
  z: number;
  opened: boolean;
  lidMesh: THREE.Object3D;
  glowMesh: THREE.Mesh;
  rewards: Array<{ itemId: string; count: number }>;
  gold: number;
}

export interface CryptInterior {
  id: string;
  name: string;
  region: RegionId;
  centerX: number;
  centerZ: number;
  floorY: number;
  halfW: number;
  halfD: number;
  entranceX: number;
  entranceY: number;
  entranceZ: number;
  exitX: number;
  exitZ: number;
  themeColor: string;
}

export interface CryptPortal {
  id: string;
  cryptId: string;
  label: string;
  x: number;
  y: number;
  z: number;
  targetX: number;
  targetY: number;
  targetZ: number;
  isExit: boolean;
  ringMesh: THREE.Mesh;
}

export interface CastleAndDungeonBundle {
  wallBoxes: WallBox[];
  traps: TrapInstance[];
  chests: ChestInstance[];
  portals: CryptPortal[];
  crypts: CryptInterior[];
  landmarkPins: Array<{ x: number; z: number; kind: 'castle' | 'ruin' | 'crypt'; label: string }>;
  updateTrapsAndPortals: (
    dt: number,
    elapsed: number,
    playerPos: THREE.Vector3,
    onTrapHit: (dmg: number, source: string, flags?: { slow?: boolean; poison?: boolean }) => void
  ) => void;
}

function addWallBox(
  parent: THREE.Object3D,
  wallBoxes: WallBox[],
  wx: number,
  wy: number,
  wz: number,
  w: number,
  h: number,
  d: number,
  mat: THREE.Material,
  originX: number,
  originY: number,
  originZ: number,
  castShadow = true
) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  mesh.position.set(wx, wy + h / 2, wz);
  mesh.castShadow = castShadow;
  mesh.receiveShadow = true;
  parent.add(mesh);

  const absX = originX + wx;
  const absY = originY + wy;
  const absZ = originZ + wz;
  wallBoxes.push({
    minX: absX - w / 2 - 0.45,
    maxX: absX + w / 2 + 0.45,
    minZ: absZ - d / 2 - 0.45,
    maxZ: absZ + d / 2 + 0.45,
    minY: absY - 0.5,
    maxY: absY + h,
  });
  return mesh;
}

function createTrap(
  parent: THREE.Object3D,
  traps: TrapInstance[],
  id: string,
  kind: TrapKind,
  localX: number,
  localY: number,
  localZ: number,
  originX: number,
  originY: number,
  originZ: number,
  damage: number,
  phase: number,
  accentColor = '#ef4444'
) {
  const absX = originX + localX;
  const absY = originY + localY;
  const absZ = originZ + localZ;

  const baseMat = new THREE.MeshStandardMaterial({ color: '#1e293b', metalness: 0.75, roughness: 0.35 });
  const telegraphMat = new THREE.MeshStandardMaterial({
    color: accentColor,
    emissive: accentColor,
    emissiveIntensity: 0.45,
    roughness: 0.3,
  });

  if (kind === 'spike') {
    const g = new THREE.Group();
    g.position.set(localX, localY + 0.04, localZ);
    const plate = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.12, 3.0), baseMat);
    g.add(plate);
    const rim = new THREE.Mesh(new THREE.BoxGeometry(3.15, 0.05, 3.15), telegraphMat);
    rim.position.y = -0.02;
    g.add(rim);

    const spikes = new THREE.Group();
    const spikeMat = new THREE.MeshStandardMaterial({ color: '#e2e8f0', metalness: 0.88, roughness: 0.18 });
    for (let sx = -0.95; sx <= 0.95; sx += 0.63) {
      for (let sz = -0.95; sz <= 0.95; sz += 0.63) {
        const sp = new THREE.Mesh(new THREE.ConeGeometry(0.14, 1.55, 5), spikeMat);
        sp.position.set(sx, 0.78, sz);
        spikes.add(sp);
      }
    }
    spikes.position.y = -0.85;
    g.add(spikes);
    parent.add(g);

    traps.push({
      id,
      kind,
      x: absX,
      y: absY,
      z: absZ,
      radius: 1.65,
      damage,
      phase,
      cooldown: 0,
      movingPart: spikes,
      telegraphMat,
    });
  } else if (kind === 'blade') {
    const pivot = new THREE.Group();
    pivot.position.set(localX, localY + 5.6, localZ);
    const rod = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.08, 4.4, 8),
      new THREE.MeshStandardMaterial({ color: '#475569', metalness: 0.8, roughness: 0.25 })
    );
    rod.position.y = -2.2;
    pivot.add(rod);

    const blade = new THREE.Mesh(
      new THREE.BoxGeometry(2.6, 0.72, 0.16),
      new THREE.MeshStandardMaterial({ color: '#f8fafc', metalness: 0.9, roughness: 0.15 })
    );
    blade.position.y = -4.35;
    pivot.add(blade);
    const edge = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.14, 0.2), telegraphMat);
    edge.position.y = -4.68;
    pivot.add(edge);
    parent.add(pivot);

    traps.push({
      id,
      kind,
      x: absX,
      y: absY,
      z: absZ,
      radius: 2.1,
      damage,
      phase,
      cooldown: 0,
      movingPart: pivot,
      telegraphMat,
    });
  } else if (kind === 'fire_jet') {
    const g = new THREE.Group();
    g.position.set(localX, localY + 0.05, localZ);
    const brazier = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 1.05, 0.45, 8), baseMat);
    brazier.position.y = 0.22;
    g.add(brazier);

    const jetMat = new THREE.MeshStandardMaterial({
      color: '#fb923c',
      emissive: '#ff5500',
      emissiveIntensity: 1.8,
      transparent: true,
      opacity: 0.85,
    });
    const flameCone = new THREE.Mesh(new THREE.ConeGeometry(0.95, 3.6, 8), jetMat);
    flameCone.position.y = 2.0;
    g.add(flameCone);
    parent.add(g);

    traps.push({
      id,
      kind,
      x: absX,
      y: absY,
      z: absZ,
      radius: 1.8,
      damage,
      phase,
      cooldown: 0,
      movingPart: flameCone,
      telegraphMat: jetMat,
    });
  } else {
    const rune = new THREE.Mesh(
      new THREE.CylinderGeometry(2.0, 2.0, 0.08, 16),
      telegraphMat
    );
    rune.position.set(localX, localY + 0.05, localZ);
    parent.add(rune);

    traps.push({
      id,
      kind,
      x: absX,
      y: absY,
      z: absZ,
      radius: 2.05,
      damage,
      phase,
      cooldown: 0,
      movingPart: rune,
      telegraphMat,
      slow: accentColor === '#38bdf8',
      poison: accentColor === '#22c55e',
    });
  }
}

function createChest(
  parent: THREE.Object3D,
  chests: ChestInstance[],
  id: string,
  label: string,
  localX: number,
  localY: number,
  localZ: number,
  originX: number,
  originY: number,
  originZ: number,
  rewards: Array<{ itemId: string; count: number }>,
  gold: number,
  trimColor = '#fbbf24'
) {
  const g = new THREE.Group();
  g.position.set(localX, localY, localZ);

  const woodMat = new THREE.MeshStandardMaterial({ color: '#5c2d16', roughness: 0.7 });
  const trimMat = new THREE.MeshStandardMaterial({
    color: trimColor,
    metalness: 0.8,
    roughness: 0.25,
    emissive: trimColor,
    emissiveIntensity: 0.28,
  });

  const base = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.72, 1.0), woodMat);
  base.position.y = 0.36;
  base.castShadow = true;
  g.add(base);

  const band = new THREE.Mesh(new THREE.BoxGeometry(1.56, 0.14, 1.06), trimMat);
  band.position.y = 0.68;
  g.add(band);

  const lidPivot = new THREE.Group();
  lidPivot.position.set(0, 0.72, -0.5);
  const lid = new THREE.Mesh(new THREE.BoxGeometry(1.52, 0.38, 1.02), trimMat);
  lid.position.set(0, 0.19, 0.5);
  lidPivot.add(lid);
  g.add(lidPivot);

  const glowMesh = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.28, 0),
    new THREE.MeshBasicMaterial({ color: trimColor })
  );
  glowMesh.position.set(0, 1.55, 0);
  g.add(glowMesh);

  parent.add(g);

  chests.push({
    id,
    label,
    x: originX + localX,
    y: originY + localY,
    z: originZ + localZ,
    opened: false,
    lidMesh: lidPivot,
    glowMesh,
    rewards,
    gold,
  });
}

function addTorchPillar(
  parent: THREE.Object3D,
  x: number,
  y: number,
  z: number,
  flameColor: string,
  stoneMat: THREE.Material,
  addLight = false
) {
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.24, 2.2, 7), stoneMat);
  post.position.set(x, y + 1.1, z);
  parent.add(post);
  const flame = new THREE.Mesh(
    new THREE.SphereGeometry(0.26, 8, 8),
    new THREE.MeshStandardMaterial({ color: flameColor, emissive: flameColor, emissiveIntensity: 1.8 })
  );
  flame.position.set(x, y + 2.35, z);
  parent.add(flame);
  if (addLight) {
    const pt = new THREE.PointLight(flameColor, 4.5, 22, 1.5);
    pt.position.set(x, y + 2.6, z);
    parent.add(pt);
  }
}

function buildEnterableCastle(
  scene: THREE.Scene,
  textures: ProceduralTextureSet,
  bundle: CastleAndDungeonBundle,
  opts: {
    id: string;
    name: string;
    x: number;
    z: number;
    wallColor: string;
    roofColor: string;
    accentColor: string;
    useObsidian?: boolean;
    useSand?: boolean;
    trapType: TrapKind;
    chestRewards: Array<{ itemId: string; count: number }>;
    chestGold: number;
  }
) {
  const y = getTerrainHeight(opts.x, opts.z);
  const g = new THREE.Group();
  g.position.set(opts.x, y, opts.z);
  scene.add(g);

  const wallMat = new THREE.MeshStandardMaterial({
    color: opts.wallColor,
    map: opts.useObsidian ? textures.obsidianTex : opts.useSand ? textures.sandTex : textures.stoneTex,
    bumpMap: textures.stoneBump,
    bumpScale: 0.08,
    roughness: 0.82,
    metalness: opts.useObsidian ? 0.35 : 0.08,
  });
  const roofMat = new THREE.MeshStandardMaterial({ color: opts.roofColor, roughness: 0.6 });
  const floorMat = new THREE.MeshStandardMaterial({
    color: opts.wallColor,
    map: textures.dungeonTileTex,
    roughness: 0.86,
  });

  // Stone Courtyard Floor (slightly raised 0.16m so grass never pokes inside)
  const floor = new THREE.Mesh(new THREE.BoxGeometry(28, 0.32, 28), floorMat);
  floor.position.y = 0.08;
  floor.receiveShadow = true;
  g.add(floor);

  const wallH = 6.2;
  // North Back Wall
  addWallBox(g, bundle.wallBoxes, 0, 0, -13.5, 28, wallH, 1.4, wallMat, opts.x, y, opts.z);
  // West & East Side Walls
  addWallBox(g, bundle.wallBoxes, -13.5, 0, 0, 1.4, wallH, 28, wallMat, opts.x, y, opts.z);
  addWallBox(g, bundle.wallBoxes, 13.5, 0, 0, 1.4, wallH, 28, wallMat, opts.x, y, opts.z);
  // South Front Wall with WIDE 5.6m Open Gatehouse Archway
  addWallBox(g, bundle.wallBoxes, -8.4, 0, 13.5, 11.2, wallH, 1.4, wallMat, opts.x, y, opts.z);
  addWallBox(g, bundle.wallBoxes, 8.4, 0, 13.5, 11.2, wallH, 1.4, wallMat, opts.x, y, opts.z);
  // Overhead Gatehouse Arch Lintel (high at Y=4.8..7.2 so player walks right underneath!)
  const archLintel = new THREE.Mesh(new THREE.BoxGeometry(6.6, 2.4, 1.8), wallMat);
  archLintel.position.set(0, 6.0, 13.5);
  archLintel.castShadow = true;
  g.add(archLintel);

  // Corner Keep Towers
  for (const [cx, cz] of [[-13.5, -13.5], [13.5, -13.5], [-13.5, 13.5], [13.5, 13.5]]) {
    const tower = new THREE.Mesh(new THREE.CylinderGeometry(2.5, 2.8, 12.5, 8), wallMat);
    tower.position.set(cx, 6.25, cz);
    tower.castShadow = true;
    g.add(tower);
    const spire = new THREE.Mesh(new THREE.ConeGeometry(3.2, 4.4, 8), roofMat);
    spire.position.set(cx, 14.5, cz);
    spire.castShadow = true;
    g.add(spire);
  }

  // Interior Royal Pillars & Throne Altar
  for (const [px, pz] of [[-6.5, -5], [6.5, -5], [-6.5, 4], [6.5, 4]]) {
    addWallBox(g, bundle.wallBoxes, px, 0, pz, 1.4, 6.5, 1.4, wallMat, opts.x, y, opts.z);
  }
  const dais = new THREE.Mesh(new THREE.BoxGeometry(7.2, 0.5, 4.2), floorMat);
  dais.position.set(0, 0.35, -10.0);
  g.add(dais);

  // Banners & Torches framing the Gate and Throne
  addTorchPillar(g, -3.5, 0, 14.8, opts.accentColor, wallMat, false);
  addTorchPillar(g, 3.5, 0, 14.8, opts.accentColor, wallMat, false);
  addTorchPillar(g, -4.5, 0.4, -10.5, opts.accentColor, wallMat, true);
  addTorchPillar(g, 4.5, 0.4, -10.5, opts.accentColor, wallMat, false);

  // Traps guarding the Castle Courtyard!
  createTrap(g, bundle.traps, `${opts.id}_t1`, opts.trapType, 0, 0.22, 6.5, opts.x, y, opts.z, 20, 0, opts.accentColor);
  createTrap(g, bundle.traps, `${opts.id}_t2`, 'spike', -4.2, 0.22, -1.0, opts.x, y, opts.z, 18, 1.4, opts.accentColor);
  createTrap(g, bundle.traps, `${opts.id}_t3`, 'spike', 4.2, 0.22, -1.0, opts.x, y, opts.z, 18, 2.2, opts.accentColor);

  // Treasure Chest on the Castle Dais
  createChest(
    g,
    bundle.chests,
    `${opts.id}_chest`,
    `${opts.name} Royal Chest`,
    0,
    0.6,
    -10.2,
    opts.x,
    y,
    opts.z,
    opts.chestRewards,
    opts.chestGold,
    opts.accentColor
  );

  bundle.landmarkPins.push({ x: opts.x, z: opts.z, kind: 'castle', label: opts.name });
}

function buildEnterableRuin(
  scene: THREE.Scene,
  textures: ProceduralTextureSet,
  bundle: CastleAndDungeonBundle,
  opts: {
    id: string;
    name: string;
    x: number;
    z: number;
    stoneColor: string;
    accentColor: string;
    useSand?: boolean;
    chestRewards: Array<{ itemId: string; count: number }>;
    chestGold: number;
  }
) {
  const y = getTerrainHeight(opts.x, opts.z);
  const g = new THREE.Group();
  g.position.set(opts.x, y, opts.z);
  scene.add(g);

  const stoneMat = new THREE.MeshStandardMaterial({
    color: opts.stoneColor,
    map: opts.useSand ? textures.sandTex : textures.stoneTex,
    bumpMap: textures.stoneBump,
    bumpScale: 0.08,
    roughness: 0.88,
  });

  const floor = new THREE.Mesh(new THREE.CylinderGeometry(10.5, 11, 0.3, 12), stoneMat);
  floor.position.y = 0.08;
  floor.receiveShadow = true;
  g.add(floor);

  // Broken ancient archway ring with open north/south/east/west entries
  for (let i = 0; i < 8; i++) {
    if (i === 0 || i === 4) continue; // Open South & North Walk-in Paths
    const a = (i / 8) * Math.PI * 2 + Math.PI / 2;
    const px = Math.cos(a) * 8.2;
    const pz = Math.sin(a) * 8.2;
    const h = 3.2 + (i % 3) * 1.4;
    addWallBox(g, bundle.wallBoxes, px, 0, pz, 1.5, h, 1.5, stoneMat, opts.x, y, opts.z);
  }
  // Broken fallen lintels and glowing ruin braziers
  addWallBox(g, bundle.wallBoxes, -5.5, 0, -5.5, 4.0, 2.8, 1.1, stoneMat, opts.x, y, opts.z);
  addWallBox(g, bundle.wallBoxes, 5.5, 0, -5.5, 4.0, 3.4, 1.1, stoneMat, opts.x, y, opts.z);
  addTorchPillar(g, -3.2, 0.2, 7.0, opts.accentColor, stoneMat, false);
  addTorchPillar(g, 3.2, 0.2, 7.0, opts.accentColor, stoneMat, false);

  // Ruin Traps!
  createTrap(g, bundle.traps, `${opts.id}_t1`, 'spike', 0, 0.2, 3.8, opts.x, y, opts.z, 16, 0.5, opts.accentColor);
  createTrap(g, bundle.traps, `${opts.id}_t2`, 'rune', 0, 0.2, -3.5, opts.x, y, opts.z, 15, 1.2, opts.accentColor);

  // Ancient Ruin Chest
  createChest(
    g,
    bundle.chests,
    `${opts.id}_chest`,
    `${opts.name} Relic Chest`,
    0,
    0.25,
    0,
    opts.x,
    y,
    opts.z,
    opts.chestRewards,
    opts.chestGold,
    opts.accentColor
  );

  bundle.landmarkPins.push({ x: opts.x, z: opts.z, kind: 'ruin', label: opts.name });
}

function buildCryptEntranceAndInterior(
  scene: THREE.Scene,
  textures: ProceduralTextureSet,
  bundle: CastleAndDungeonBundle,
  opts: {
    id: string;
    name: string;
    region: RegionId;
    entX: number;
    entZ: number;
    chamberX: number;
    chamberZ: number;
    wallColor: string;
    accentColor: string;
    useSand?: boolean;
    useObsidian?: boolean;
    chestRewards: Array<{ itemId: string; count: number }>;
    chestGold: number;
  }
) {
  // A. Surface Crypt Gate Monument
  const entY = getTerrainHeight(opts.entX, opts.entZ);
  const gateGroup = new THREE.Group();
  gateGroup.position.set(opts.entX, entY, opts.entZ);
  scene.add(gateGroup);

  const wallMat = new THREE.MeshStandardMaterial({
    color: opts.wallColor,
    map: opts.useObsidian ? textures.obsidianTex : opts.useSand ? textures.sandTex : textures.stoneTex,
    bumpMap: textures.stoneBump,
    bumpScale: 0.08,
    roughness: 0.85,
  });

  addWallBox(gateGroup, bundle.wallBoxes, -3.2, 0, 0, 1.6, 5.2, 2.4, wallMat, opts.entX, entY, opts.entZ);
  addWallBox(gateGroup, bundle.wallBoxes, 3.2, 0, 0, 1.6, 5.2, 2.4, wallMat, opts.entX, entY, opts.entZ);
  const archTop = new THREE.Mesh(new THREE.BoxGeometry(8.2, 1.8, 2.6), wallMat);
  archTop.position.set(0, 5.8, 0);
  gateGroup.add(archTop);

  // Giant Skull / Sun Relief atop Crypt Arch
  const crest = new THREE.Mesh(
    new THREE.OctahedronGeometry(1.1, 0),
    new THREE.MeshStandardMaterial({ color: opts.accentColor, emissive: opts.accentColor, emissiveIntensity: 0.9 })
  );
  crest.position.set(0, 7.6, 0);
  gateGroup.add(crest);

  addTorchPillar(gateGroup, -4.4, 0, 1.8, opts.accentColor, wallMat, false);
  addTorchPillar(gateGroup, 4.4, 0, 1.8, opts.accentColor, wallMat, false);

  const entPortalMat = new THREE.MeshBasicMaterial({
    color: opts.accentColor,
    transparent: true,
    opacity: 0.72,
    side: THREE.DoubleSide,
  });
  const entPortalMesh = new THREE.Mesh(new THREE.RingGeometry(0.4, 2.2, 24), entPortalMat);
  entPortalMesh.position.set(0, 2.4, 0);
  gateGroup.add(entPortalMesh);

  // B. Enclosed Subterranean Crypt Chamber at isolated chamberX, chamberZ (floorY = 0)
  const floorY = 0;
  const halfW = 18;
  const halfD = 26;
  const chamber = new THREE.Group();
  chamber.position.set(opts.chamberX, floorY, opts.chamberZ);
  scene.add(chamber);

  const tileMat = new THREE.MeshStandardMaterial({
    color: opts.wallColor,
    map: textures.dungeonTileTex,
    roughness: 0.8,
  });

  // Floor & Vaulted Stone Ceiling
  const floorMesh = new THREE.Mesh(new THREE.BoxGeometry(halfW * 2, 0.6, halfD * 2), tileMat);
  floorMesh.position.y = -0.3;
  floorMesh.receiveShadow = true;
  chamber.add(floorMesh);

  const ceilingMesh = new THREE.Mesh(new THREE.BoxGeometry(halfW * 2, 0.8, halfD * 2), wallMat);
  ceilingMesh.position.y = 8.4;
  chamber.add(ceilingMesh);

  // Perimeter Dungeon Walls
  addWallBox(chamber, bundle.wallBoxes, 0, 0, -halfD, halfW * 2, 8.4, 1.4, wallMat, opts.chamberX, floorY, opts.chamberZ, false);
  addWallBox(chamber, bundle.wallBoxes, 0, 0, halfD, halfW * 2, 8.4, 1.4, wallMat, opts.chamberX, floorY, opts.chamberZ, false);
  addWallBox(chamber, bundle.wallBoxes, -halfW, 0, 0, 1.4, 8.4, halfD * 2, wallMat, opts.chamberX, floorY, opts.chamberZ, false);
  addWallBox(chamber, bundle.wallBoxes, halfW, 0, 0, 1.4, 8.4, halfD * 2, wallMat, opts.chamberX, floorY, opts.chamberZ, false);

  // Interior Stone Pillars, Sarcophagi & Torches
  for (let pz = -14; pz <= 14; pz += 9.5) {
    for (const px of [-7.5, 7.5]) {
      addWallBox(chamber, bundle.wallBoxes, px, 0, pz, 1.8, 8.0, 1.8, wallMat, opts.chamberX, floorY, opts.chamberZ, false);
      addTorchPillar(chamber, px * 0.78, 0, pz, opts.accentColor, wallMat, pz === -14 || pz === 5);
    }
  }
  // Sarcophagi along outer aisles
  for (const [sx, sz] of [[-12.5, -6], [12.5, -6], [-12.5, 8], [12.5, 8]]) {
    addWallBox(chamber, bundle.wallBoxes, sx, 0, sz, 2.2, 1.2, 4.0, wallMat, opts.chamberX, floorY, opts.chamberZ, false);
  }

  // Crypt Trap Gauntlet (Spikes + Swinging Pendulum Blades + Fire Jets / Runes!)
  createTrap(chamber, bundle.traps, `${opts.id}_sp1`, 'spike', 0, 0, 12, opts.chamberX, floorY, opts.chamberZ, 20, 0, opts.accentColor);
  createTrap(chamber, bundle.traps, `${opts.id}_bl1`, 'blade', 0, 0, 4, opts.chamberX, floorY, opts.chamberZ, 24, 0.4, opts.accentColor);
  createTrap(chamber, bundle.traps, `${opts.id}_fj1`, 'fire_jet', -4.2, 0, -2, opts.chamberX, floorY, opts.chamberZ, 22, 1.1, opts.accentColor);
  createTrap(chamber, bundle.traps, `${opts.id}_fj2`, 'fire_jet', 4.2, 0, -2, opts.chamberX, floorY, opts.chamberZ, 22, 2.3, opts.accentColor);
  createTrap(chamber, bundle.traps, `${opts.id}_bl2`, 'blade', 0, 0, -9, opts.chamberX, floorY, opts.chamberZ, 26, 1.7, opts.accentColor);
  createTrap(chamber, bundle.traps, `${opts.id}_sp2`, 'spike', 0, 0, -14, opts.chamberX, floorY, opts.chamberZ, 20, 2.0, opts.accentColor);

  // Boss Treasure Chest at the North Crypt Altar
  createChest(
    chamber,
    bundle.chests,
    `${opts.id}_chest`,
    `${opts.name} Vault Chest`,
    0,
    0,
    -21,
    opts.chamberX,
    floorY,
    opts.chamberZ,
    opts.chestRewards,
    opts.chestGold,
    opts.accentColor
  );

  // Exit Portal back to Surface
  const exitPortalMesh = new THREE.Mesh(new THREE.RingGeometry(0.4, 2.2, 24), entPortalMat);
  exitPortalMesh.position.set(0, 2.4, halfD - 2.6);
  chamber.add(exitPortalMesh);

  bundle.crypts.push({
    id: opts.id,
    name: opts.name,
    region: opts.region,
    centerX: opts.chamberX,
    centerZ: opts.chamberZ,
    floorY,
    halfW,
    halfD,
    entranceX: opts.entX,
    entranceY: entY,
    entranceZ: opts.entZ + 4.5,
    exitX: opts.chamberX,
    exitZ: opts.chamberZ + halfD - 2.6,
    themeColor: opts.accentColor,
  });

  // Portal Entry (Surface -> Crypt)
  bundle.portals.push({
    id: `${opts.id}_enter`,
    cryptId: opts.id,
    label: `Enter ${opts.name}`,
    x: opts.entX,
    y: entY,
    z: opts.entZ,
    targetX: opts.chamberX,
    targetY: floorY + 0.5,
    targetZ: opts.chamberZ + halfD - 6.0,
    isExit: false,
    ringMesh: entPortalMesh,
  });

  // Portal Exit (Crypt -> Surface)
  bundle.portals.push({
    id: `${opts.id}_exit`,
    cryptId: opts.id,
    label: `Exit ${opts.name}`,
    x: opts.chamberX,
    y: floorY,
    z: opts.chamberZ + halfD - 2.6,
    targetX: opts.entX,
    targetY: entY + 0.5,
    targetZ: opts.entZ + 5.2,
    isExit: true,
    ringMesh: exitPortalMesh,
  });

  bundle.landmarkPins.push({ x: opts.entX, z: opts.entZ, kind: 'crypt', label: opts.name });
}

export function buildAllCastlesRuinsAndCrypts(
  scene: THREE.Scene,
  textures: ProceduralTextureSet
): CastleAndDungeonBundle {
  const bundle: CastleAndDungeonBundle = {
    wallBoxes: [],
    traps: [],
    chests: [],
    portals: [],
    crypts: [],
    landmarkPins: [],
    updateTrapsAndPortals: (dt, elapsed, playerPos, onTrapHit) => {
      for (const p of bundle.portals) {
        p.ringMesh.rotation.z = elapsed * 1.4;
      }
      for (const ch of bundle.chests) {
        if (!ch.opened) {
          ch.glowMesh.rotation.y = elapsed * 2.2;
          ch.glowMesh.position.y = 1.5 + Math.sin(elapsed * 3) * 0.14;
        } else {
          ch.glowMesh.visible = false;
        }
      }
      for (const t of bundle.traps) {
        if (t.cooldown > 0) t.cooldown = Math.max(0, t.cooldown - dt);
        const dist = Math.hypot(playerPos.x - t.x, playerPos.z - t.z);
        const verticalClear = Math.abs(playerPos.y - t.y) < 1.35;

        if (t.kind === 'spike') {
          const cycle = (elapsed + t.phase) % 3.2;
          const active = cycle > 1.75 && cycle < 2.75;
          const warning = cycle > 1.15 && cycle <= 1.75;
          const targetY = active ? 0.05 : -0.82;
          t.movingPart.position.y = THREE.MathUtils.lerp(t.movingPart.position.y, targetY, Math.min(1, dt * 16));
          if (t.telegraphMat) {
            t.telegraphMat.emissiveIntensity = active ? 1.8 : warning ? 1.1 + Math.sin(elapsed * 22) * 0.5 : 0.25;
          }
          if (active && dist < t.radius && verticalClear && t.cooldown <= 0) {
            t.cooldown = 0.9;
            onTrapHit(t.damage, 'Spike Trap');
          }
        } else if (t.kind === 'blade') {
          const swing = Math.sin(elapsed * 2.5 + t.phase) * 0.95;
          t.movingPart.rotation.z = swing;
          const bladeSweepX = t.x + Math.sin(swing) * 3.8;
          const dBlade = Math.hypot(playerPos.x - bladeSweepX, playerPos.z - t.z);
          if (dBlade < 1.55 && Math.abs(playerPos.y - t.y) < 1.8 && t.cooldown <= 0) {
            t.cooldown = 0.9;
            onTrapHit(t.damage, 'Pendulum Blade');
          }
        } else if (t.kind === 'fire_jet') {
          const cycle = (elapsed + t.phase) % 3.6;
          const active = cycle > 1.8 && cycle < 2.95;
          t.movingPart.visible = active;
          t.movingPart.scale.setScalar(active ? 0.9 + Math.sin(elapsed * 24) * 0.14 : 0.01);
          if (active && dist < t.radius && Math.abs(playerPos.y - t.y) < 2.8 && t.cooldown <= 0) {
            t.cooldown = 0.95;
            onTrapHit(t.damage, 'Fire Brazier Trap');
          }
        } else if (t.kind === 'rune') {
          const cycle = (elapsed + t.phase) % 3.0;
          const pulse = cycle > 1.6 && cycle < 2.4;
          if (t.telegraphMat) {
            t.telegraphMat.emissiveIntensity = pulse ? 2.0 : 0.45 + Math.sin(elapsed * 4) * 0.2;
          }
          if (pulse && dist < t.radius && verticalClear && t.cooldown <= 0) {
            t.cooldown = 1.1;
            onTrapHit(t.damage, 'Cursed Rune Trap', { slow: t.slow, poison: t.poison });
          }
        }
      }
    },
  };

  // =========================================================================
  // 1. SIX ENTERABLE GRAND CASTLES (with Gateways, Traps & Treasure Chests)
  // =========================================================================
  buildEnterableCastle(scene, textures, bundle, {
    id: 'castle_oakhearth',
    name: 'Oakhearth Royal Castle',
    x: -165,
    z: -130,
    wallColor: '#94a3b8',
    roofColor: '#1e40af',
    accentColor: '#fbbf24',
    trapType: 'spike',
    chestRewards: [{ itemId: 'knight_tower_shield', count: 1 }, { itemId: 'iron', count: 5 }, { itemId: 'health_potion', count: 2 }],
    chestGold: 160,
  });

  buildEnterableCastle(scene, textures, bundle, {
    id: 'castle_skeleton',
    name: 'Skeleton Citadel',
    x: 350,
    z: 295,
    wallColor: '#57534e',
    roofColor: '#312e81',
    accentColor: '#c084fc',
    trapType: 'rune',
    chestRewards: [{ itemId: 'necromancer_grimoire_staff', count: 1 }, { itemId: 'ancient_bone', count: 6 }],
    chestGold: 240,
  });

  buildEnterableCastle(scene, textures, bundle, {
    id: 'castle_goblin',
    name: 'Goblin War Bastion',
    x: 335,
    z: -45,
    wallColor: '#78716c',
    roofColor: '#7f1d1d',
    accentColor: '#f59e0b',
    trapType: 'fire_jet',
    chestRewards: [{ itemId: 'obsidian_gauntlets', count: 1 }, { itemId: 'iron', count: 6 }, { itemId: 'gold', count: 3 }],
    chestGold: 210,
  });

  buildEnterableCastle(scene, textures, bundle, {
    id: 'castle_ice',
    name: 'Frozen Ice Citadel',
    x: -35,
    z: -465,
    wallColor: '#bae6fd',
    roofColor: '#0369a1',
    accentColor: '#38bdf8',
    trapType: 'rune',
    chestRewards: [{ itemId: 'frostguard_shield', count: 1 }, { itemId: 'ice_shard', count: 6 }, { itemId: 'crystal', count: 4 }],
    chestGold: 280,
  });

  buildEnterableCastle(scene, textures, bundle, {
    id: 'castle_hellfire',
    name: 'Hellfire Obsidian Citadel',
    x: 340,
    z: -345,
    wallColor: '#451a1a',
    roofColor: '#7f1d1d',
    accentColor: '#ff5500',
    useObsidian: true,
    trapType: 'fire_jet',
    chestRewards: [{ itemId: 'infernal_helm', count: 1 }, { itemId: 'obsidian_shard', count: 5 }, { itemId: 'fire_essence', count: 5 }],
    chestGold: 320,
  });

  buildEnterableCastle(scene, textures, bundle, {
    id: 'castle_desert',
    name: 'Desert Sun Fortress',
    x: -490,
    z: 30,
    wallColor: '#e6c589',
    roofColor: '#b45309',
    accentColor: '#fbbf24',
    useSand: true,
    trapType: 'spike',
    chestRewards: [{ itemId: 'sunfire_blade', count: 1 }, { itemId: 'sun_gem', count: 4 }, { itemId: 'gold', count: 4 }],
    chestGold: 290,
  });

  // =========================================================================
  // 2. FOUR ENTERABLE ANCIENT RUINS (with Broken Arches, Traps & Relic Chests)
  // =========================================================================
  buildEnterableRuin(scene, textures, bundle, {
    id: 'ruin_forest',
    name: 'Sunken Forest Ruins',
    x: -120,
    z: 95,
    stoneColor: '#6b7280',
    accentColor: '#22c55e',
    chestRewards: [{ itemId: 'wind_boots', count: 1 }, { itemId: 'herbs', count: 5 }, { itemId: 'crystal', count: 2 }],
    chestGold: 140,
  });

  buildEnterableRuin(scene, textures, bundle, {
    id: 'ruin_desert',
    name: 'Sandstone Sun Ruins',
    x: -425,
    z: -60,
    stoneColor: '#d4a359',
    accentColor: '#fbbf24',
    useSand: true,
    chestRewards: [{ itemId: 'sun_gem', count: 4 }, { itemId: 'ruby_ring', count: 1 }],
    chestGold: 185,
  });

  buildEnterableRuin(scene, textures, bundle, {
    id: 'ruin_bone',
    name: 'Cursed Bone Ruins',
    x: 255,
    z: 270,
    stoneColor: '#78716c',
    accentColor: '#a855f7',
    chestRewards: [{ itemId: 'ancient_bone', count: 6 }, { itemId: 'shadow_daggers', count: 1 }],
    chestGold: 195,
  });

  buildEnterableRuin(scene, textures, bundle, {
    id: 'ruin_ancient',
    name: 'Ancient Arcane Ruins',
    x: -95,
    z: 450,
    stoneColor: '#4c1d95',
    accentColor: '#c084fc',
    chestRewards: [{ itemId: 'titan_greaves', count: 1 }, { itemId: 'crystal', count: 5 }, { itemId: 'elixir_of_elements', count: 2 }],
    chestGold: 275,
  });

  // =========================================================================
  // 3. THREE ENTERABLE UNDERGROUND CRYPTS / DUNGEONS
  // =========================================================================
  buildCryptEntranceAndInterior(scene, textures, bundle, {
    id: 'crypt_skeleton',
    name: 'Cursed Bone Catacombs',
    region: 'skeleton_kingdom',
    entX: 290,
    entZ: 390,
    chamberX: 1200,
    chamberZ: 0,
    wallColor: '#64748b',
    accentColor: '#a855f7',
    chestRewards: [
      { itemId: 'necromancer_grimoire_staff', count: 1 },
      { itemId: 'ancient_bone', count: 8 },
      { itemId: 'crystal', count: 4 },
    ],
    chestGold: 360,
  });

  buildCryptEntranceAndInterior(scene, textures, bundle, {
    id: 'crypt_desert',
    name: 'Pharaoh Sun Crypt',
    region: 'desert_dunes',
    entX: -535,
    entZ: 115,
    chamberX: 1480,
    chamberZ: 0,
    wallColor: '#d4a359',
    accentColor: '#fbbf24',
    useSand: true,
    chestRewards: [
      { itemId: 'sunfire_blade', count: 1 },
      { itemId: 'sun_gem', count: 5 },
      { itemId: 'gold', count: 5 },
    ],
    chestGold: 420,
  });

  buildCryptEntranceAndInterior(scene, textures, bundle, {
    id: 'crypt_hell',
    name: 'Hellfire Abyss Vault',
    region: 'volcano_region',
    entX: 455,
    entZ: -315,
    chamberX: 1760,
    chamberZ: 0,
    wallColor: '#3b1518',
    accentColor: '#ff4d00',
    useObsidian: true,
    chestRewards: [
      { itemId: 'void_reaper_scythe', count: 1 },
      { itemId: 'hellfire_plate', count: 1 },
      { itemId: 'obsidian_shard', count: 8 },
    ],
    chestGold: 550,
  });

  return bundle;
}
