import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { QualityLevel } from '../types';

function createProceduralCanvasTexture(
  size: number,
  drawFn: (ctx: CanvasRenderingContext2D, size: number) => void,
  isColor = true,
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  drawFn(ctx, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  if (isColor) {
    tex.colorSpace = THREE.SRGBColorSpace;
  }
  tex.needsUpdate = true;
  return tex;
}

function createTerrainAlbedo(size: number): THREE.CanvasTexture {
  return createProceduralCanvasTexture(size, (ctx, s) => {
    ctx.fillStyle = '#e2e4e0';
    ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < s * 12; i++) {
      const x = (Math.sin(i * 12.9898) * 43758.5453) % 1;
      const y = (Math.sin(i * 78.233) * 19341.123) % 1;
      const px = Math.abs(x) * s;
      const py = Math.abs(y) * s;
      const bright = i % 4 === 0 ? 250 : i % 3 === 0 ? 222 : i % 2 === 0 ? 196 : 174;
      ctx.fillStyle = `rgba(${bright},${bright},${bright},0.3)`;
      ctx.fillRect(px, py, 2 + (i % 4), 2 + ((i + 1) % 3));
    }
    // Stylized subtle grass/soil tuft strokes
    ctx.strokeStyle = 'rgba(255,255,255,0.14)';
    ctx.lineWidth = 1.5;
    for (let i = 0; i < s * 1.4; i++) {
      const px = Math.abs((Math.sin(i * 53.1) * 9187) % 1) * s;
      const py = Math.abs((Math.cos(i * 29.3) * 6143) % 1) * s;
      ctx.beginPath();
      ctx.moveTo(px, py);
      ctx.lineTo(px + 2, py - 4);
      ctx.stroke();
    }
  });
}

function createBarkAlbedo(size: number): THREE.CanvasTexture {
  return createProceduralCanvasTexture(size, (ctx, s) => {
    ctx.fillStyle = '#6c4f38';
    ctx.fillRect(0, 0, s, s);
    for (let x = 0; x < s; x += 6) {
      ctx.fillStyle = x % 12 === 0 ? '#4a3322' : '#805f45';
      ctx.fillRect(x, 0, 3, s);
    }
    for (let i = 0; i < s * 2.5; i++) {
      const px = ((Math.sin(i * 17.3) * 9123) % 1) * s;
      const py = ((Math.cos(i * 31.7) * 5131) % 1) * s;
      ctx.fillStyle = i % 3 === 0 ? 'rgba(160, 124, 92, 0.22)' : 'rgba(32, 20, 12, 0.28)';
      ctx.fillRect(Math.abs(px), Math.abs(py), 2, 9);
    }
  });
}

function createStoneAlbedo(size: number): THREE.CanvasTexture {
  return createProceduralCanvasTexture(size, (ctx, s) => {
    ctx.fillStyle = '#9aa1a8';
    ctx.fillRect(0, 0, s, s);
    // Stylized stone blocks / masonry seams
    const rows = 6;
    const cols = 4;
    const rowH = s / rows;
    const colW = s / cols;
    ctx.strokeStyle = 'rgba(40, 48, 56, 0.34)';
    ctx.lineWidth = Math.max(1, s / 96);
    for (let r = 0; r < rows; r++) {
      const y = r * rowH;
      const offset = (r % 2) * (colW * 0.5);
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(s, y);
      ctx.stroke();
      for (let c = 0; c <= cols; c++) {
        const x = (c * colW + offset) % s;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x, y + rowH);
        ctx.stroke();
      }
    }
    for (let i = 0; i < s * 6; i++) {
      const px = Math.abs((Math.sin(i * 41.1) * 3127) % 1) * s;
      const py = Math.abs((Math.cos(i * 19.7) * 7411) % 1) * s;
      const shade = i % 2 === 0 ? 195 : 112;
      ctx.fillStyle = `rgba(${shade},${shade},${shade + 4},0.22)`;
      ctx.fillRect(px, py, 5, 4);
    }
  });
}

function createWaterRippleTexture(size: number): THREE.CanvasTexture {
  return createProceduralCanvasTexture(size, (ctx, s) => {
    ctx.fillStyle = '#228eb8';
    ctx.fillRect(0, 0, s, s);
    ctx.strokeStyle = 'rgba(180, 244, 255, 0.22)';
    ctx.lineWidth = 2;
    for (let y = 8; y < s; y += 16) {
      ctx.beginPath();
      for (let x = 0; x <= s; x += 8) {
        const wave = Math.sin((x / s) * Math.PI * 4 + y * 0.2) * 3;
        if (x === 0) ctx.moveTo(x, y + wave);
        else ctx.lineTo(x, y + wave);
      }
      ctx.stroke();
    }
  });
}

function createWaterfallTexture(size: number): THREE.CanvasTexture {
  return createProceduralCanvasTexture(size, (ctx, s) => {
    const grad = ctx.createLinearGradient(0, 0, s, 0);
    grad.addColorStop(0, '#38bdf8');
    grad.addColorStop(0.5, '#7dd3fc');
    grad.addColorStop(1, '#38bdf8');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, s, s);
    for (let x = 4; x < s; x += 10) {
      ctx.fillStyle = x % 20 === 4 ? 'rgba(255,255,255,0.45)' : 'rgba(224,242,254,0.28)';
      ctx.fillRect(x, 0, 4, s);
    }
    for (let i = 0; i < s * 2; i++) {
      const px = Math.abs((Math.sin(i * 19.7) * 8191) % 1) * s;
      const py = Math.abs((Math.cos(i * 43.3) * 6133) % 1) * s;
      ctx.fillStyle = 'rgba(255,255,255,0.52)';
      ctx.fillRect(px, py, 3, 12);
    }
  });
}

function safeMergeGeometries(parts: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const anyNonIndexed = parts.some((p) => p.index === null);
  const normalized = anyNonIndexed ? parts.map((p) => (p.index !== null ? p.toNonIndexed() : p)) : parts;
  const merged = mergeGeometries(normalized);
  if (merged) return merged;
  return normalized[0] ?? new THREE.BoxGeometry(1, 1, 1);
}

function buildPineTrunkGeo(): THREE.BufferGeometry {
  const trunk = new THREE.CylinderGeometry(0.18, 0.34, 2.8, 7);
  trunk.translate(0, 1.4, 0);
  const root1 = new THREE.BoxGeometry(0.28, 0.45, 0.65);
  root1.translate(0, 0.22, 0);
  const root2 = root1.clone().rotateY(Math.PI / 2);
  return safeMergeGeometries([trunk, root1, root2]);
}

function buildPineCanopyGeo(): THREE.BufferGeometry {
  const c1 = new THREE.ConeGeometry(1.75, 2.4, 7);
  c1.translate(0, 3.1, 0);
  const c2 = new THREE.ConeGeometry(1.38, 2.1, 7);
  c2.translate(0, 4.35, 0);
  const c3 = new THREE.ConeGeometry(0.95, 1.75, 7);
  c3.translate(0, 5.5, 0);
  return mergeGeometries([c1, c2, c3])!;
}

function buildOakTrunkGeo(): THREE.BufferGeometry {
  const trunk = new THREE.CylinderGeometry(0.26, 0.42, 2.5, 7);
  trunk.translate(0, 1.25, 0);
  const b1 = new THREE.CylinderGeometry(0.12, 0.18, 1.2, 6);
  b1.rotateZ(0.55);
  b1.translate(-0.45, 2.35, 0);
  const b2 = new THREE.CylinderGeometry(0.12, 0.18, 1.2, 6);
  b2.rotateZ(-0.52);
  b2.translate(0.45, 2.3, 0.15);
  return mergeGeometries([trunk, b1, b2])!;
}

function buildOakCanopyGeo(): THREE.BufferGeometry {
  const main = new THREE.DodecahedronGeometry(1.55, 0);
  main.scale(1.15, 0.85, 1.15);
  main.translate(0, 3.55, 0);
  const left = new THREE.DodecahedronGeometry(1.05, 0);
  left.translate(-0.95, 3.15, 0.2);
  const right = new THREE.DodecahedronGeometry(1.0, 0);
  right.translate(0.92, 3.25, -0.25);
  return mergeGeometries([main, left, right])!;
}

function buildRockGeo(): THREE.BufferGeometry {
  const geo = new THREE.IcosahedronGeometry(1.0, 0);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const vx = pos.getX(i);
    const vy = pos.getY(i);
    const vz = pos.getZ(i);
    const warp = 0.84 + Math.abs(Math.sin(vx * 3.1 + vz * 2.7)) * 0.28;
    pos.setXYZ(i, vx * warp, Math.max(-0.3, vy * 0.72 * warp), vz * warp);
  }
  geo.computeVertexNormals();
  geo.translate(0, 0.28, 0);
  return geo;
}

function buildGrassClusterGeo(): THREE.BufferGeometry {
  const blade1 = new THREE.ConeGeometry(0.12, 0.75, 4);
  blade1.rotateZ(0.18);
  blade1.translate(-0.1, 0.37, 0);
  const blade2 = new THREE.ConeGeometry(0.11, 0.85, 4);
  blade2.rotateZ(-0.16);
  blade2.translate(0.1, 0.42, 0.08);
  const blade3 = new THREE.ConeGeometry(0.1, 0.65, 4);
  blade3.rotateX(0.2);
  blade3.translate(0, 0.32, -0.1);
  return mergeGeometries([blade1, blade2, blade3])!;
}

function buildBushGeo(): THREE.BufferGeometry {
  const s1 = new THREE.DodecahedronGeometry(0.65, 0);
  s1.translate(0, 0.45, 0);
  const s2 = new THREE.DodecahedronGeometry(0.48, 0);
  s2.translate(-0.42, 0.35, 0.15);
  const s3 = new THREE.DodecahedronGeometry(0.45, 0);
  s3.translate(0.4, 0.34, -0.14);
  return mergeGeometries([s1, s2, s3])!;
}

function buildFlowerGeo(): THREE.BufferGeometry {
  const bloom1 = new THREE.DodecahedronGeometry(0.18, 0);
  bloom1.translate(0, 0.48, 0);
  const bloom2 = new THREE.DodecahedronGeometry(0.14, 0);
  bloom2.translate(0.22, 0.38, 0.14);
  const bloom3 = new THREE.DodecahedronGeometry(0.14, 0);
  bloom3.translate(-0.18, 0.4, -0.12);
  return mergeGeometries([bloom1, bloom2, bloom3])!;
}

function buildMushroomGeo(): THREE.BufferGeometry {
  const stem = new THREE.CylinderGeometry(0.08, 0.12, 0.45, 6);
  stem.translate(0, 0.22, 0);
  const cap = new THREE.ConeGeometry(0.32, 0.24, 7);
  cap.translate(0, 0.52, 0);
  return mergeGeometries([stem, cap])!;
}

function buildCactusGeo(): THREE.BufferGeometry {
  const trunk = new THREE.CylinderGeometry(0.24, 0.28, 2.2, 7);
  trunk.translate(0, 1.1, 0);
  const armL = new THREE.CylinderGeometry(0.15, 0.16, 0.9, 6);
  armL.rotateZ(0.45);
  armL.translate(-0.38, 1.35, 0);
  const armR = new THREE.CylinderGeometry(0.15, 0.16, 0.8, 6);
  armR.rotateZ(-0.45);
  armR.translate(0.36, 1.15, 0);
  return mergeGeometries([trunk, armL, armR])!;
}

function buildCrystalGeo(): THREE.BufferGeometry {
  const main = new THREE.ConeGeometry(0.32, 1.85, 6);
  main.translate(0, 0.92, 0);
  const side1 = new THREE.ConeGeometry(0.2, 1.15, 5);
  side1.rotateZ(0.38);
  side1.translate(-0.34, 0.55, 0.1);
  const side2 = new THREE.ConeGeometry(0.18, 1.0, 5);
  side2.rotateZ(-0.42);
  side2.rotateX(0.25);
  side2.translate(0.3, 0.48, -0.15);
  return mergeGeometries([main, side1, side2])!;
}

function buildRuinPillarGeo(): THREE.BufferGeometry {
  const plinth = new THREE.BoxGeometry(1.4, 0.45, 1.4);
  plinth.translate(0, 0.225, 0);
  const shaft = new THREE.CylinderGeometry(0.45, 0.52, 3.2, 8);
  shaft.translate(0, 2.05, 0);
  const cap = new THREE.BoxGeometry(1.3, 0.38, 1.3);
  cap.translate(0, 3.84, 0);
  return mergeGeometries([plinth, shaft, cap])!;
}

function buildCrateGeo(): THREE.BufferGeometry {
  const body = new THREE.BoxGeometry(0.95, 0.82, 0.95);
  body.translate(0, 0.41, 0);
  const lid = new THREE.BoxGeometry(1.04, 0.16, 1.04);
  lid.translate(0, 0.86, 0);
  return mergeGeometries([body, lid])!;
}

function buildHouseWallGeo(): THREE.BufferGeometry {
  const foundation = new THREE.BoxGeometry(5.6, 0.5, 4.8);
  foundation.translate(0, 0.25, 0);
  const walls = new THREE.BoxGeometry(5.2, 3.2, 4.4);
  walls.translate(0, 2.1, 0);
  const door = new THREE.BoxGeometry(1.1, 2.0, 0.25);
  door.translate(0, 1.3, 2.25);
  const chimney = new THREE.BoxGeometry(0.75, 2.5, 0.75);
  chimney.translate(1.8, 4.3, -1.2);
  return mergeGeometries([foundation, walls, door, chimney])!;
}

function buildHouseRoofGeo(): THREE.BufferGeometry {
  const roof = new THREE.ConeGeometry(4.2, 2.4, 4);
  roof.rotateY(Math.PI / 4);
  roof.scale(1.12, 1.0, 0.98);
  roof.translate(0, 4.85, 0);
  return roof;
}

function buildWatchtowerGeo(): THREE.BufferGeometry {
  const base = new THREE.CylinderGeometry(1.6, 1.9, 6.5, 8);
  base.translate(0, 3.25, 0);
  const top = new THREE.CylinderGeometry(2.05, 1.75, 1.1, 8);
  top.translate(0, 6.9, 0);
  const spire = new THREE.ConeGeometry(2.2, 2.2, 8);
  spire.translate(0, 8.5, 0);
  return mergeGeometries([base, top, spire])!;
}

function buildPortalArchGeo(): THREE.BufferGeometry {
  const base = new THREE.BoxGeometry(4.4, 0.45, 2.2);
  base.translate(0, 0.22, 0);
  const pL = new THREE.BoxGeometry(0.85, 4.2, 1.2);
  pL.translate(-1.55, 2.3, 0);
  const pR = new THREE.BoxGeometry(0.85, 4.2, 1.2);
  pR.translate(1.55, 2.3, 0);
  const lintel = new THREE.BoxGeometry(4.6, 0.95, 1.45);
  lintel.translate(0, 4.65, 0);
  return mergeGeometries([base, pL, pR, lintel])!;
}

function buildLanternGeo(): THREE.BufferGeometry {
  const post = new THREE.CylinderGeometry(0.09, 0.13, 3.0, 6);
  post.translate(0, 1.5, 0);
  const arm = new THREE.BoxGeometry(0.65, 0.1, 0.1);
  arm.translate(0.28, 2.9, 0);
  return mergeGeometries([post, arm])!;
}

// --- Modular Castle, Ruin, Cave & Cloud Geometries ---

function buildCastleKeepGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const plinth = new THREE.BoxGeometry(10.6, 0.8, 10.6);
  plinth.translate(0, 0.4, 0);
  parts.push(plinth);

  const mainKeep = new THREE.BoxGeometry(8.8, 7.6, 8.8);
  mainKeep.translate(0, 4.6, 0);
  parts.push(mainKeep);

  const upperTier = new THREE.BoxGeometry(6.0, 3.8, 6.0);
  upperTier.translate(0, 10.3, 0);
  parts.push(upperTier);

  // Crenellations on main keep top
  for (let i = -3; i <= 3; i += 2) {
    const merlonN = new THREE.BoxGeometry(1.0, 0.85, 0.65);
    merlonN.translate(i * 1.15, 8.8, -4.1);
    parts.push(merlonN);
    const merlonS = new THREE.BoxGeometry(1.0, 0.85, 0.65);
    merlonS.translate(i * 1.15, 8.8, 4.1);
    parts.push(merlonS);
  }
  const spire = new THREE.ConeGeometry(3.4, 3.2, 4);
  spire.rotateY(Math.PI / 4);
  spire.translate(0, 13.8, 0);
  parts.push(spire);

  return mergeGeometries(parts)!;
}

function buildCastleWallGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const wall = new THREE.BoxGeometry(11.0, 4.8, 1.4);
  wall.translate(0, 2.4, 0);
  parts.push(wall);
  for (let i = -4.2; i <= 4.3; i += 2.1) {
    const merlon = new THREE.BoxGeometry(1.1, 0.85, 1.5);
    merlon.translate(i, 5.2, 0);
    parts.push(merlon);
  }
  return mergeGeometries(parts)!;
}

function buildCastleCornerTowerGeo(): THREE.BufferGeometry {
  const base = new THREE.CylinderGeometry(1.75, 2.05, 7.6, 8);
  base.translate(0, 3.8, 0);
  const parapet = new THREE.CylinderGeometry(2.1, 1.85, 1.0, 8);
  parapet.translate(0, 8.0, 0);
  const roof = new THREE.ConeGeometry(2.3, 2.5, 8);
  roof.translate(0, 9.75, 0);
  return mergeGeometries([base, parapet, roof])!;
}

function buildRuinTempleGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const step1 = new THREE.BoxGeometry(8.6, 0.55, 8.6);
  step1.translate(0, 0.28, 0);
  const step2 = new THREE.BoxGeometry(6.8, 0.5, 6.8);
  step2.translate(0, 0.8, 0);
  parts.push(step1, step2);

  const offsets: Array<[number, number, number]> = [
    [-2.5, -2.5, 4.2],
    [2.5, -2.5, 3.6],
    [-2.5, 2.5, 2.9],
    [2.5, 2.5, 4.0],
  ];
  for (const [ox, oz, h] of offsets) {
    const col = new THREE.CylinderGeometry(0.42, 0.48, h, 7);
    col.translate(ox, 1.05 + h * 0.5, oz);
    parts.push(col);
  }
  const lintel = new THREE.BoxGeometry(6.2, 0.75, 1.2);
  lintel.translate(0, 5.4, -2.5);
  parts.push(lintel);

  return mergeGeometries(parts)!;
}

function buildCaveMouthGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const rockL = new THREE.DodecahedronGeometry(2.4, 0);
  rockL.scale(1.1, 1.5, 1.3);
  rockL.translate(-2.4, 1.8, 0);
  const rockR = new THREE.DodecahedronGeometry(2.3, 0);
  rockR.scale(1.1, 1.45, 1.3);
  rockR.translate(2.4, 1.75, 0);
  const brow = new THREE.DodecahedronGeometry(2.8, 0);
  brow.scale(1.65, 0.85, 1.4);
  brow.translate(0, 4.0, -0.3);
  const back = new THREE.DodecahedronGeometry(3.2, 0);
  back.scale(1.5, 1.35, 1.0);
  back.translate(0, 2.3, -2.3);
  parts.push(rockL, rockR, brow, back);
  return mergeGeometries(parts)!;
}

function buildMineSupportGeo(): THREE.BufferGeometry {
  const pL = new THREE.BoxGeometry(0.42, 4.0, 0.42);
  pL.rotateZ(-0.1);
  pL.translate(-1.85, 2.0, 1.2);
  const pR = new THREE.BoxGeometry(0.42, 4.0, 0.42);
  pR.rotateZ(0.1);
  pR.translate(1.85, 2.0, 1.2);
  const beam = new THREE.BoxGeometry(4.6, 0.48, 0.55);
  beam.translate(0, 4.05, 1.2);
  return mergeGeometries([pL, pR, beam])!;
}

function buildCloudGeo(): THREE.BufferGeometry {
  const c1 = new THREE.DodecahedronGeometry(3.8, 0);
  c1.scale(1.8, 0.65, 1.1);
  const c2 = new THREE.DodecahedronGeometry(2.8, 0);
  c2.scale(1.3, 0.75, 1.0);
  c2.translate(-3.6, -0.35, 0.4);
  const c3 = new THREE.DodecahedronGeometry(2.6, 0);
  c3.scale(1.2, 0.7, 1.0);
  c3.translate(3.5, -0.4, -0.3);
  return mergeGeometries([c1, c2, c3])!;
}

function buildMarketStallWoodGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const counter = new THREE.BoxGeometry(2.6, 0.95, 1.1);
  counter.translate(0, 0.48, 0.25);
  parts.push(counter);
  const corners: Array<[number, number]> = [
    [-1.2, -0.45],
    [1.2, -0.45],
    [-1.2, 0.72],
    [1.2, 0.72],
  ];
  for (const [cx, cz] of corners) {
    const post = new THREE.BoxGeometry(0.14, 2.35, 0.14);
    post.translate(cx, 1.18, cz);
    parts.push(post);
  }
  const beam = new THREE.BoxGeometry(2.7, 0.14, 0.14);
  beam.translate(0, 2.32, 0.72);
  parts.push(beam);
  return mergeGeometries(parts)!;
}

function buildMarketStallAwningGeo(): THREE.BufferGeometry {
  const awning = new THREE.BoxGeometry(2.85, 0.12, 1.75);
  awning.rotateX(0.28);
  awning.translate(0, 2.35, 0.12);
  const valance = new THREE.BoxGeometry(2.85, 0.28, 0.08);
  valance.translate(0, 2.04, 0.95);
  return mergeGeometries([awning, valance])!;
}

function buildVillageWellGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const rim = new THREE.CylinderGeometry(1.15, 1.25, 0.95, 8);
  rim.translate(0, 0.48, 0);
  parts.push(rim);
  const postL = new THREE.BoxGeometry(0.16, 2.2, 0.16);
  postL.translate(-0.9, 1.65, 0);
  const postR = new THREE.BoxGeometry(0.16, 2.2, 0.16);
  postR.translate(0.9, 1.65, 0);
  const roof = new THREE.ConeGeometry(1.45, 0.95, 4);
  roof.rotateY(Math.PI / 4);
  roof.translate(0, 3.05, 0);
  parts.push(postL, postR, roof);
  return mergeGeometries(parts)!;
}

function buildCampfireBaseGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    const stone = new THREE.DodecahedronGeometry(0.2, 0);
    stone.scale(1.1, 0.7, 1.0);
    stone.translate(Math.cos(a) * 0.72, 0.1, Math.sin(a) * 0.72);
    parts.push(stone);
  }
  for (let i = 0; i < 3; i++) {
    const log = new THREE.CylinderGeometry(0.08, 0.1, 1.1, 6).toNonIndexed();
    log.rotateZ(Math.PI / 2 - 0.15);
    log.rotateY((i / 3) * Math.PI);
    log.translate(0, 0.16, 0);
    parts.push(log);
  }
  return safeMergeGeometries(parts);
}

function buildCampfireFlameGeo(): THREE.BufferGeometry {
  const f1 = new THREE.ConeGeometry(0.28, 0.8, 6);
  f1.translate(0, 0.45, 0);
  const f2 = new THREE.ConeGeometry(0.18, 0.55, 5);
  f2.translate(-0.14, 0.35, 0.08);
  const f3 = new THREE.ConeGeometry(0.16, 0.5, 5);
  f3.translate(0.14, 0.32, -0.06);
  return mergeGeometries([f1, f2, f3])!;
}

function buildFallenLogGeo(): THREE.BufferGeometry {
  const log = new THREE.CylinderGeometry(0.24, 0.3, 2.9, 7);
  log.rotateZ(Math.PI / 2);
  log.translate(0, 0.22, 0);
  const stub = new THREE.CylinderGeometry(0.09, 0.12, 0.65, 5);
  stub.rotateZ(-0.5);
  stub.translate(-0.55, 0.44, 0.1);
  return mergeGeometries([log, stub])!;
}

function buildWaterfallGeo(): THREE.BufferGeometry {
  const geo = new THREE.PlaneGeometry(3.4, 5.8, 1, 4);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const y = pos.getY(i);
    // Curve slightly forward near the bottom like pouring water
    const norm = (2.9 - y) / 5.8;
    pos.setZ(i, norm * norm * 1.15);
  }
  geo.computeVertexNormals();
  geo.translate(0, 2.5, 0);
  return geo;
}

export class TemplateRegistry {
  public windUniform = { value: 0 };

  public terrainMaterial: THREE.MeshStandardMaterial;
  public waterMaterial: THREE.MeshStandardMaterial;
  public waterfallMaterial: THREE.MeshStandardMaterial;
  public barkMaterial: THREE.MeshStandardMaterial;
  public foliageMaterial: THREE.MeshStandardMaterial;
  public rockMaterial: THREE.MeshStandardMaterial;
  public grassMaterial: THREE.MeshStandardMaterial;
  public flowerMaterial: THREE.MeshStandardMaterial;
  public mushroomMaterial: THREE.MeshStandardMaterial;
  public crystalMaterial: THREE.MeshStandardMaterial;
  public ruinMaterial: THREE.MeshStandardMaterial;
  public crateMaterial: THREE.MeshStandardMaterial;
  public houseWallMaterial: THREE.MeshStandardMaterial;
  public houseRoofMaterial: THREE.MeshStandardMaterial;
  public marketAwningMaterial: THREE.MeshStandardMaterial;
  public campfireFlameMaterial: THREE.MeshStandardMaterial;
  public castleStoneMaterial: THREE.MeshStandardMaterial;
  public caveRockMaterial: THREE.MeshStandardMaterial;
  public mineWoodMaterial: THREE.MeshStandardMaterial;
  public portalGlowMaterial: THREE.MeshStandardMaterial;
  public lanternGlowMaterial: THREE.MeshStandardMaterial;
  public cloudMaterial: THREE.MeshBasicMaterial;

  public pineTrunkGeo: THREE.BufferGeometry;
  public pineCanopyGeo: THREE.BufferGeometry;
  public oakTrunkGeo: THREE.BufferGeometry;
  public oakCanopyGeo: THREE.BufferGeometry;
  public rockGeo: THREE.BufferGeometry;
  public grassGeo: THREE.BufferGeometry;
  public bushGeo: THREE.BufferGeometry;
  public flowerGeo: THREE.BufferGeometry;
  public mushroomGeo: THREE.BufferGeometry;
  public cactusGeo: THREE.BufferGeometry;
  public crystalGeo: THREE.BufferGeometry;
  public ruinGeo: THREE.BufferGeometry;
  public crateGeo: THREE.BufferGeometry;
  public houseWallGeo: THREE.BufferGeometry;
  public houseRoofGeo: THREE.BufferGeometry;
  public towerGeo: THREE.BufferGeometry;
  public castleKeepGeo: THREE.BufferGeometry;
  public castleWallGeo: THREE.BufferGeometry;
  public castleCornerTowerGeo: THREE.BufferGeometry;
  public ruinTempleGeo: THREE.BufferGeometry;
  public caveMouthGeo: THREE.BufferGeometry;
  public mineSupportGeo: THREE.BufferGeometry;
  public cloudGeo: THREE.BufferGeometry;
  public portalArchGeo: THREE.BufferGeometry;
  public portalCoreGeo: THREE.BufferGeometry;
  public lanternGeo: THREE.BufferGeometry;
  public lanternBulbGeo: THREE.BufferGeometry;
  public marketStallWoodGeo: THREE.BufferGeometry;
  public marketStallAwningGeo: THREE.BufferGeometry;
  public villageWellGeo: THREE.BufferGeometry;
  public campfireBaseGeo: THREE.BufferGeometry;
  public campfireFlameGeo: THREE.BufferGeometry;
  public fallenLogGeo: THREE.BufferGeometry;
  public waterfallGeo: THREE.BufferGeometry;

  private textures: THREE.Texture[] = [];

  constructor(quality: QualityLevel, maxAnisotropy: number) {
    const texSize = quality === 'low' ? 128 : quality === 'medium' ? 256 : 512;
    const aniso = quality === 'low' ? 1 : Math.min(maxAnisotropy, quality === 'medium' ? 4 : 8);

    const terrainTex = createTerrainAlbedo(texSize);
    terrainTex.repeat.set(8, 8);
    terrainTex.anisotropy = aniso;

    const barkTex = createBarkAlbedo(texSize);
    barkTex.anisotropy = aniso;

    const stoneTex = createStoneAlbedo(texSize);
    stoneTex.anisotropy = aniso;

    const waterTex = createWaterRippleTexture(texSize);
    waterTex.repeat.set(14, 14);
    waterTex.anisotropy = aniso;

    const waterfallTex = createWaterfallTexture(texSize);
    waterfallTex.repeat.set(1, 2);
    waterfallTex.anisotropy = aniso;

    this.textures.push(terrainTex, barkTex, stoneTex, waterTex, waterfallTex);

    this.terrainMaterial = new THREE.MeshStandardMaterial({
      map: terrainTex,
      vertexColors: true,
      roughness: 0.92,
      metalness: 0.02,
    });

    this.waterMaterial = new THREE.MeshStandardMaterial({
      map: waterTex,
      color: 0x38b6dc,
      roughness: 0.18,
      metalness: 0.25,
      transparent: true,
      opacity: 0.78,
    });

    this.waterfallMaterial = new THREE.MeshStandardMaterial({
      map: waterfallTex,
      color: 0xe0f2fe,
      emissive: 0x0284c7,
      emissiveIntensity: 0.28,
      roughness: 0.15,
      transparent: true,
      opacity: 0.84,
      side: THREE.DoubleSide,
    });

    this.barkMaterial = new THREE.MeshStandardMaterial({
      map: barkTex,
      roughness: 0.9,
      metalness: 0.04,
      flatShading: true,
    });

    const attachWindShader = (mat: THREE.MeshStandardMaterial, amplitude: number) => {
      mat.onBeforeCompile = (shader) => {
        shader.uniforms.uWindTime = this.windUniform;
        shader.vertexShader = 'uniform float uWindTime;\n' + shader.vertexShader;
        shader.vertexShader = shader.vertexShader.replace(
          '#include <begin_vertex>',
          `#include <begin_vertex>
          float wPhase = uWindTime * 2.1;
          #ifdef USE_INSTANCING
            wPhase += instanceMatrix[3][0] * 0.45 + instanceMatrix[3][2] * 0.35;
          #endif
          float wWeight = max(0.0, transformed.y - 0.15);
          transformed.x += sin(wPhase) * ${amplitude.toFixed(3)} * wWeight;
          transformed.z += cos(wPhase * 0.85) * ${(amplitude * 0.7).toFixed(3)} * wWeight;`,
        );
      };
      mat.customProgramCacheKey = () => `wind_${amplitude}`;
    };

    this.foliageMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.76,
      metalness: 0.02,
      flatShading: true,
    });
    attachWindShader(this.foliageMaterial, 0.032);

    this.rockMaterial = new THREE.MeshStandardMaterial({
      map: stoneTex,
      color: 0xffffff,
      roughness: 0.88,
      metalness: 0.08,
      flatShading: true,
    });

    this.grassMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.82,
      metalness: 0.0,
      flatShading: true,
    });
    attachWindShader(this.grassMaterial, 0.11);

    this.flowerMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.65,
      metalness: 0.0,
      flatShading: true,
    });
    attachWindShader(this.flowerMaterial, 0.08);

    this.mushroomMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0x2dd4bf,
      emissiveIntensity: 0.35,
      roughness: 0.55,
      flatShading: true,
    });

    this.crystalMaterial = new THREE.MeshStandardMaterial({
      color: 0x99f6ff,
      emissive: 0x38bdf8,
      emissiveIntensity: 0.65,
      roughness: 0.22,
      metalness: 0.35,
      flatShading: true,
    });

    this.ruinMaterial = new THREE.MeshStandardMaterial({
      map: stoneTex,
      color: 0xcbd5e1,
      roughness: 0.84,
      metalness: 0.1,
      flatShading: true,
    });

    this.crateMaterial = new THREE.MeshStandardMaterial({
      map: barkTex,
      color: 0xd99b52,
      roughness: 0.72,
      metalness: 0.15,
      flatShading: true,
    });

    this.houseWallMaterial = new THREE.MeshStandardMaterial({
      map: stoneTex,
      color: 0xe7dcc8,
      roughness: 0.85,
      metalness: 0.05,
      flatShading: true,
    });

    this.houseRoofMaterial = new THREE.MeshStandardMaterial({
      color: 0x9b2c2c,
      roughness: 0.75,
      metalness: 0.08,
      flatShading: true,
    });

    this.marketAwningMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.72,
      metalness: 0.04,
      flatShading: true,
    });

    this.campfireFlameMaterial = new THREE.MeshStandardMaterial({
      color: 0xfef08a,
      emissive: 0xf97316,
      emissiveIntensity: 1.9,
      roughness: 0.3,
      flatShading: true,
    });

    this.castleStoneMaterial = new THREE.MeshStandardMaterial({
      map: stoneTex,
      color: 0x94a3b8,
      roughness: 0.86,
      metalness: 0.14,
      flatShading: true,
    });

    this.caveRockMaterial = new THREE.MeshStandardMaterial({
      map: stoneTex,
      color: 0x64748b,
      roughness: 0.92,
      metalness: 0.08,
      flatShading: true,
    });

    this.mineWoodMaterial = new THREE.MeshStandardMaterial({
      map: barkTex,
      color: 0x92623a,
      roughness: 0.88,
      metalness: 0.05,
      flatShading: true,
    });

    this.portalGlowMaterial = new THREE.MeshStandardMaterial({
      color: 0xa855f7,
      emissive: 0x9333ea,
      emissiveIntensity: 1.5,
      transparent: true,
      opacity: 0.82,
      side: THREE.DoubleSide,
    });

    this.lanternGlowMaterial = new THREE.MeshStandardMaterial({
      color: 0xfef08a,
      emissive: 0xfbbf24,
      emissiveIntensity: 1.8,
      roughness: 0.2,
    });

    this.cloudMaterial = new THREE.MeshBasicMaterial({
      color: 0xf8fafc,
      transparent: true,
      opacity: 0.72,
    });

    this.pineTrunkGeo = buildPineTrunkGeo();
    this.pineCanopyGeo = buildPineCanopyGeo();
    this.oakTrunkGeo = buildOakTrunkGeo();
    this.oakCanopyGeo = buildOakCanopyGeo();
    this.rockGeo = buildRockGeo();
    this.grassGeo = buildGrassClusterGeo();
    this.bushGeo = buildBushGeo();
    this.flowerGeo = buildFlowerGeo();
    this.mushroomGeo = buildMushroomGeo();
    this.cactusGeo = buildCactusGeo();
    this.crystalGeo = buildCrystalGeo();
    this.ruinGeo = buildRuinPillarGeo();
    this.crateGeo = buildCrateGeo();
    this.houseWallGeo = buildHouseWallGeo();
    this.houseRoofGeo = buildHouseRoofGeo();
    this.towerGeo = buildWatchtowerGeo();
    this.castleKeepGeo = buildCastleKeepGeo();
    this.castleWallGeo = buildCastleWallGeo();
    this.castleCornerTowerGeo = buildCastleCornerTowerGeo();
    this.ruinTempleGeo = buildRuinTempleGeo();
    this.caveMouthGeo = buildCaveMouthGeo();
    this.mineSupportGeo = buildMineSupportGeo();
    this.cloudGeo = buildCloudGeo();
    this.portalArchGeo = buildPortalArchGeo();
    this.portalCoreGeo = new THREE.PlaneGeometry(2.3, 3.8);
    this.portalCoreGeo.translate(0, 2.25, 0);
    this.lanternGeo = buildLanternGeo();
    this.lanternBulbGeo = new THREE.SphereGeometry(0.18, 6, 5);
    this.lanternBulbGeo.translate(0.54, 2.72, 0);
    this.marketStallWoodGeo = buildMarketStallWoodGeo();
    this.marketStallAwningGeo = buildMarketStallAwningGeo();
    this.villageWellGeo = buildVillageWellGeo();
    this.campfireBaseGeo = buildCampfireBaseGeo();
    this.campfireFlameGeo = buildCampfireFlameGeo();
    this.fallenLogGeo = buildFallenLogGeo();
    this.waterfallGeo = buildWaterfallGeo();
  }

  public updateQuality(quality: QualityLevel, maxAnisotropy: number): void {
    const aniso = quality === 'low' ? 1 : Math.min(maxAnisotropy, quality === 'medium' ? 4 : 8);
    for (const tex of this.textures) {
      tex.anisotropy = aniso;
      tex.needsUpdate = true;
    }
  }

  public animateEnvironment(dt: number): void {
    this.windUniform.value += dt;
    const waterTex = this.textures[3];
    if (waterTex) {
      waterTex.offset.x = (waterTex.offset.x + dt * 0.025) % 1;
      waterTex.offset.y = (waterTex.offset.y + dt * 0.015) % 1;
    }
    const waterfallTex = this.textures[4];
    if (waterfallTex) {
      waterfallTex.offset.y = (waterfallTex.offset.y + dt * 1.35) % 1;
    }
  }

  public animateWater(dt: number): void {
    this.animateEnvironment(dt);
  }

  public dispose(): void {
    this.textures.forEach((t) => t.dispose());
    this.terrainMaterial.dispose();
    this.waterMaterial.dispose();
    this.waterfallMaterial.dispose();
    this.barkMaterial.dispose();
    this.foliageMaterial.dispose();
    this.rockMaterial.dispose();
    this.grassMaterial.dispose();
    this.flowerMaterial.dispose();
    this.mushroomMaterial.dispose();
    this.crystalMaterial.dispose();
    this.ruinMaterial.dispose();
    this.crateMaterial.dispose();
    this.houseWallMaterial.dispose();
    this.houseRoofMaterial.dispose();
    this.marketAwningMaterial.dispose();
    this.campfireFlameMaterial.dispose();
    this.castleStoneMaterial.dispose();
    this.caveRockMaterial.dispose();
    this.mineWoodMaterial.dispose();
    this.portalGlowMaterial.dispose();
    this.lanternGlowMaterial.dispose();
    this.cloudMaterial.dispose();

    this.pineTrunkGeo.dispose();
    this.pineCanopyGeo.dispose();
    this.oakTrunkGeo.dispose();
    this.oakCanopyGeo.dispose();
    this.rockGeo.dispose();
    this.grassGeo.dispose();
    this.bushGeo.dispose();
    this.flowerGeo.dispose();
    this.mushroomGeo.dispose();
    this.cactusGeo.dispose();
    this.crystalGeo.dispose();
    this.ruinGeo.dispose();
    this.crateGeo.dispose();
    this.houseWallGeo.dispose();
    this.houseRoofGeo.dispose();
    this.towerGeo.dispose();
    this.castleKeepGeo.dispose();
    this.castleWallGeo.dispose();
    this.castleCornerTowerGeo.dispose();
    this.ruinTempleGeo.dispose();
    this.caveMouthGeo.dispose();
    this.mineSupportGeo.dispose();
    this.cloudGeo.dispose();
    this.portalArchGeo.dispose();
    this.portalCoreGeo.dispose();
    this.lanternGeo.dispose();
    this.lanternBulbGeo.dispose();
    this.marketStallWoodGeo.dispose();
    this.marketStallAwningGeo.dispose();
    this.villageWellGeo.dispose();
    this.campfireBaseGeo.dispose();
    this.campfireFlameGeo.dispose();
    this.fallenLogGeo.dispose();
    this.waterfallGeo.dispose();
  }
}
