import * as THREE from 'three';
import { DungeonPortalInfo, HarvestNode, ObstacleCollider } from '../types';
import { HarvestReward } from './chunkManager';
import { mulberry32 } from './noise';

interface RoomRect {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export interface DungeonChest {
  id: string;
  x: number;
  z: number;
  opened: boolean;
  isSecret?: boolean;
  lidMesh: THREE.Mesh;
  glowMesh: THREE.Mesh;
}

export interface DungeonEnemySpawn {
  x: number;
  z: number;
  isBoss: boolean;
  isFriendlyGuard?: boolean;
}

interface InteriorNodeEntry {
  node: HarvestNode;
  mesh: THREE.Mesh;
}

const ROOMS: RoomRect[] = [
  { minX: -6.5, maxX: 6.5, minZ: -6, maxZ: 6.5 }, // Entrance Hall
  { minX: -3.2, maxX: 3.2, minZ: -18, maxZ: -5.5 }, // Corridor 1
  { minX: -10.5, maxX: 10.5, minZ: -29, maxZ: -17.5 }, // Central Pillar Hall
  { minX: -19, maxX: -10, minZ: -26.5, maxZ: -20 }, // West Alcove
  { minX: 10, maxX: 19, minZ: -26.5, maxZ: -20 }, // East Alcove
  { minX: 12.2, maxX: 17.8, minZ: -20.5, maxZ: -12.5 }, // Secret North-East Alcove
  { minX: -3.4, maxX: 3.4, minZ: -38, maxZ: -28.5 }, // Corridor 2
  { minX: -13.5, maxX: 13.5, minZ: -58, maxZ: -37.5 }, // Boss / Throne / Core Chamber
];

export class DungeonInstance {
  public readonly portal: DungeonPortalInfo;
  public readonly exitPos = { x: 0, z: 4.4 };
  public readonly enemySpawns: DungeonEnemySpawn[] = [];
  public readonly chests: DungeonChest[] = [];
  public readonly bgHex: number;
  public readonly fogHex: number;

  private scene: THREE.Scene;
  private group = new THREE.Group();
  private disposableGeos: THREE.BufferGeometry[] = [];
  private disposableMats: THREE.Material[] = [];
  private colliders: ObstacleCollider[] = [];
  private interiorNodes: InteriorNodeEntry[] = [];
  private portalCore: THREE.Mesh;
  private elapsed = 0;

  constructor(scene: THREE.Scene, portal: DungeonPortalInfo, seed: number, castShadows: boolean) {
    this.scene = scene;
    this.portal = portal;
    const kind = portal.kind;
    const subtype = portal.subtype ?? 'standard';
    const rand = mulberry32(seed ^ (portal.level * 9973) ^ portal.id.length * 131);

    // Theme palette by location kind + subtype
    let floorColor = 0x363b38;
    let wallColor = 0x2b302d;
    let trimColor = 0x57534e;
    let glowColor = 0xf97316;
    let wallH = 5.2;
    let openSky = false;

    if (kind === 'crypt') {
      this.bgHex = 0x0b0e17;
      this.fogHex = 0x141b2d;
      floorColor = 0x262b38;
      wallColor = 0x1a1e29;
      trimColor = 0x475569;
      glowColor = 0x22d3ee;
    } else if (kind === 'castle') {
      this.bgHex = subtype === 'guarded_castle' ? 0x1e293b : 0x151821;
      this.fogHex = subtype === 'guarded_castle' ? 0x2d3a4f : 0x242838;
      floorColor = 0x475569;
      wallColor = 0x334155;
      trimColor = subtype === 'guarded_castle' ? 0x991b1b : 0x64748b;
      glowColor = subtype === 'guarded_castle' ? 0xfbbf24 : 0xa855f7;
      wallH = 6.6;
    } else if (kind === 'ruin') {
      this.bgHex = 0x252d36;
      this.fogHex = 0x455361;
      floorColor = 0x78716c;
      wallColor = 0x57534e;
      trimColor = 0xa8a29e;
      glowColor = 0xfde047;
      wallH = 4.5;
      openSky = true;
    } else if (kind === 'cave') {
      if (subtype === 'ice_cave') {
        this.bgHex = 0x0c1e2e;
        this.fogHex = 0x193952;
        floorColor = 0x3b6884;
        wallColor = 0x264b63;
        trimColor = 0x7dd3fc;
        glowColor = 0x38bdf8;
      } else if (subtype === 'volcanic_cave') {
        this.bgHex = 0x1e0e0b;
        this.fogHex = 0x3a1812;
        floorColor = 0x292120;
        wallColor = 0x1c1917;
        trimColor = 0x57261a;
        glowColor = 0xf97316;
      } else if (subtype === 'crystal_cave') {
        this.bgHex = 0x171029;
        this.fogHex = 0x2c1b4d;
        floorColor = 0x312e59;
        wallColor = 0x211d3d;
        trimColor = 0x7c3aed;
        glowColor = 0xc084fc;
      } else if (subtype === 'lake_cave') {
        this.bgHex = 0x0b1f22;
        this.fogHex = 0x173b3e;
        floorColor = 0x2c4749;
        wallColor = 0x1f3336;
        trimColor = 0x2dd4bf;
        glowColor = 0x2dd4bf;
      } else {
        this.bgHex = 0x141414;
        this.fogHex = 0x262422;
        floorColor = 0x44403c;
        wallColor = 0x292524;
        trimColor = subtype === 'abandoned_mine' ? 0x78350f : 0x57534e;
        glowColor = subtype === 'abandoned_mine' ? 0xfbbf24 : 0x38bdf8;
      }
      wallH = 5.4;
    } else {
      this.bgHex = 0x131918;
      this.fogHex = 0x1e2b27;
    }

    const floorMat = new THREE.MeshStandardMaterial({
      color: floorColor,
      roughness: 0.9,
      metalness: 0.08,
    });
    const wallMat = new THREE.MeshStandardMaterial({
      color: wallColor,
      roughness: 0.86,
      metalness: 0.1,
    });
    const trimMat = new THREE.MeshStandardMaterial({
      color: trimColor,
      roughness: 0.72,
      metalness: 0.22,
    });
    const torchGlowMat = new THREE.MeshBasicMaterial({ color: glowColor });
    const crystalMat = new THREE.MeshStandardMaterial({
      color: glowColor,
      emissive: glowColor,
      emissiveIntensity: 0.7,
      roughness: 0.25,
      metalness: 0.35,
      flatShading: true,
    });
    const chestWoodMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.7 });
    const chestGoldMat = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      roughness: 0.35,
      metalness: 0.75,
    });
    const exitMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.82,
      side: THREE.DoubleSide,
    });

    this.disposableMats.push(
      floorMat,
      wallMat,
      trimMat,
      torchGlowMat,
      crystalMat,
      chestWoodMat,
      chestGoldMat,
      exitMat,
    );

    const addBox = (
      w: number,
      h: number,
      d: number,
      x: number,
      y: number,
      z: number,
      mat: THREE.Material,
      receive = true,
      cast = false,
    ): THREE.Mesh => {
      const geo = new THREE.BoxGeometry(w, h, d);
      this.disposableGeos.push(geo);
      const m = new THREE.Mesh(geo, mat);
      m.position.set(x, y, z);
      m.receiveShadow = receive && castShadows;
      m.castShadow = cast && castShadows;
      this.group.add(m);
      return m;
    };

    // Build floors & roofs (ruins leave partial sky open!)
    for (const r of ROOMS) {
      const w = r.maxX - r.minX;
      const d = r.maxZ - r.minZ;
      const cx = (r.minX + r.maxX) * 0.5;
      const cz = (r.minZ + r.maxZ) * 0.5;
      addBox(w, 0.5, d, cx, -0.25, cz, floorMat, true, false);
      if (!openSky) {
        addBox(w + 1.2, 0.5, d + 1.2, cx, wallH + 0.2, cz, wallMat, false, false);
      } else {
        // Broken stone roof rafters for Ruins
        addBox(w + 0.8, 0.45, 0.9, cx, wallH + 0.1, cz, trimMat, false, false);
      }
    }

    // Royal carpet runner in castles
    if (kind === 'castle') {
      addBox(2.6, 0.06, 56, 0, 0.03, -24, trimMat, true, false);
    }

    // Glowing underground water pool or lava trench in special caves
    if (subtype === 'lake_cave' || subtype === 'volcanic_cave') {
      const poolMat = new THREE.MeshBasicMaterial({
        color: subtype === 'lake_cave' ? 0x0ea5e9 : 0xea580c,
        transparent: true,
        opacity: 0.72,
      });
      this.disposableMats.push(poolMat);
      addBox(8.5, 0.08, 9.0, -7.2, 0.04, -48, poolMat, false, false);
      addBox(8.5, 0.08, 9.0, 7.2, 0.04, -48, poolMat, false, false);
    }

    // Perimeter Wall Segments (including East Alcove passage to Secret NE Alcove!)
    const wallY = wallH * 0.5;
    const wallSegments: Array<[number, number, number, number]> = [
      // Entrance Hall
      [14, 0.9, 0, 6.9],
      [4.2, 0.9, -4.8, -6.2],
      [4.2, 0.9, 4.8, -6.2],
      [0.9, 13, -6.9, 0.2],
      [0.9, 13, 6.9, 0.2],
      // Corridor 1
      [0.9, 12.5, -3.5, -12],
      [0.9, 12.5, 3.5, -12],
      // Central Hall North/South gaps
      [7.8, 0.9, -7.1, -17.6],
      [7.8, 0.9, 7.1, -17.6],
      [7.8, 0.9, -7.1, -29.2],
      [7.8, 0.9, 7.1, -29.2],
      // Central Hall West/East around Alcoves
      [0.9, 4, -10.7, -18.8],
      [0.9, 4, -10.7, -27.8],
      [0.9, 4, 10.7, -18.8],
      [0.9, 4, 10.7, -27.8],
      // West Alcove
      [9.5, 0.9, -14.8, -19.8],
      [9.5, 0.9, -14.8, -26.8],
      [0.9, 7.6, -19.4, -23.3],
      // East Alcove (with doorway north into Secret NE Alcove!)
      [3.0, 0.9, 11.4, -19.8],
      [3.0, 0.9, 18.0, -19.8],
      [9.5, 0.9, 14.8, -26.8],
      [0.9, 7.6, 19.4, -23.3],
      // Secret North-East Alcove
      [0.9, 8.2, 11.9, -16.2],
      [0.9, 8.2, 18.1, -16.2],
      [6.8, 0.9, 15.0, -12.2],
      // Corridor 2
      [0.9, 10, -3.6, -33.2],
      [0.9, 10, 3.6, -33.2],
      // Boss Chamber
      [10.8, 0.9, -8.8, -37.6],
      [10.8, 0.9, 8.8, -37.6],
      [0.9, 21, -13.9, -48],
      [0.9, 21, 13.9, -48],
      [28.5, 0.9, 0, -58.4],
    ];

    for (const [w, d, x, z] of wallSegments) {
      addBox(w, wallH, d, x, wallY, z, wallMat, true, true);
    }

    // Wooden timber arches in abandoned mines
    if (subtype === 'abandoned_mine') {
      for (const tz of [-9, -15, -31, -36]) {
        addBox(0.38, wallH, 0.38, -2.9, wallY, tz, trimMat, false, false);
        addBox(0.38, wallH, 0.38, 2.9, wallY, tz, trimMat, false, false);
        addBox(6.2, 0.42, 0.42, 0, wallH - 0.3, tz, trimMat, false, false);
      }
    }

    // Interior Stone Pillars / Cave Stalagmites (with physical collision)
    const pillarPositions: Array<[number, number]> = [
      [-5.5, -21],
      [5.5, -21],
      [-5.5, -26],
      [5.5, -26],
      [-7.5, -43],
      [7.5, -43],
      [-7.5, -52],
      [7.5, -52],
    ];
    const pillarGeo =
      kind === 'cave'
        ? new THREE.ConeGeometry(0.95, wallH, 6)
        : new THREE.CylinderGeometry(0.68, 0.78, wallH, 8);
    this.disposableGeos.push(pillarGeo);
    for (const [px, pz] of pillarPositions) {
      const p = new THREE.Mesh(pillarGeo, trimMat);
      p.position.set(px, wallY, pz);
      p.castShadow = castShadows;
      p.receiveShadow = castShadows;
      this.group.add(p);
      this.colliders.push({ x: px, z: pz, radius: 0.85, topY: wallH });
    }

    // Atmospheric Torches / Glowing Crystals along the rooms
    const torchPositions: Array<[number, number]> = [
      [-5.8, 3],
      [5.8, 3],
      [-2.8, -10],
      [2.8, -15],
      [-9.5, -23],
      [9.5, -23],
      [15.0, -14],
      [-2.8, -33],
      [2.8, -33],
      [-12.5, -42],
      [12.5, -42],
      [-12.5, -53],
      [12.5, -53],
    ];
    const torchStemGeo = new THREE.BoxGeometry(0.22, 1.4, 0.22);
    const torchBulbGeo = new THREE.OctahedronGeometry(0.28, 0);
    this.disposableGeos.push(torchStemGeo, torchBulbGeo);

    for (const [tx, tz] of torchPositions) {
      const stem = new THREE.Mesh(torchStemGeo, trimMat);
      stem.position.set(tx, 1.6, tz);
      const bulb = new THREE.Mesh(torchBulbGeo, torchGlowMat);
      bulb.position.set(tx, 2.45, tz);
      this.group.add(stem, bulb);
    }

    // Mineable Interior Crystal / Ore Veins (especially rich in Caves & Mines)
    const veinCoords: Array<[number, number]> = [
      [-17.5, -21.2],
      [-17.5, -25.2],
      [17.5, -25.2],
      [-12.0, -47],
      [12.0, -47],
    ];
    const veinGeo = new THREE.ConeGeometry(0.55, 1.75, 6);
    veinGeo.translate(0, 0.85, 0);
    this.disposableGeos.push(veinGeo);
    veinCoords.forEach(([vx, vz], idx) => {
      const mesh = new THREE.Mesh(veinGeo, crystalMat);
      mesh.position.set(vx, 0, vz);
      mesh.rotation.y = idx * 1.1;
      mesh.castShadow = castShadows;
      this.group.add(mesh);
      const rewardItem = subtype === 'abandoned_mine' ? 'iron_ore' : 'arcane_crystal';
      this.interiorNodes.push({
        mesh,
        node: {
          id: `${portal.id}_vein_${idx}`,
          x: vx,
          y: 0,
          z: vz,
          kind: 'crystal',
          hp: 35,
          maxHp: 35,
          rewardItemId: rewardItem,
          rewardQty: subtype === 'abandoned_mine' ? 2 : 1,
          shardReward: kind === 'cave' ? 1 : 0,
          meshIndex: idx,
        },
      });
    });

    const entranceLight = new THREE.PointLight(glowColor, 2.8, 22);
    entranceLight.position.set(0, 3.8, 1);
    const midLight = new THREE.PointLight(glowColor, 3.0, 26);
    midLight.position.set(0, 4.0, -23);
    const bossLight = new THREE.PointLight(kind === 'crypt' ? 0x38bdf8 : 0xf43f5e, 4.2, 34);
    bossLight.position.set(0, 4.4, -48);
    this.group.add(entranceLight, midLight, bossLight);

    // Exit Portal Arch at (0, 0, 4.4)
    addBox(0.55, 3.4, 0.55, -1.5, 1.7, this.exitPos.z, trimMat, true, true);
    addBox(0.55, 3.4, 0.55, 1.5, 1.7, this.exitPos.z, trimMat, true, true);
    addBox(3.6, 0.6, 0.65, 0, 3.55, this.exitPos.z, trimMat, true, true);
    const coreGeo = new THREE.PlaneGeometry(2.4, 3.0);
    this.disposableGeos.push(coreGeo);
    this.portalCore = new THREE.Mesh(coreGeo, exitMat);
    this.portalCore.position.set(0, 1.75, this.exitPos.z);
    this.group.add(this.portalCore);

    // 4 Treasure Chests (West, East, Secret NE Alcove, Boss Chamber)
    const chestCoords: Array<{ id: string; x: number; z: number; ry: number; isSecret?: boolean }> = [
      { id: `${portal.id}_chest_w`, x: -16.8, z: -23.2, ry: Math.PI / 2 },
      { id: `${portal.id}_chest_e`, x: 16.8, z: -23.2, ry: -Math.PI / 2 },
      { id: `${portal.id}_chest_secret`, x: 15.0, z: -13.6, ry: 0, isSecret: true },
      { id: `${portal.id}_chest_boss`, x: 0, z: -55.2, ry: 0 },
    ];
    const baseGeo = new THREE.BoxGeometry(1.15, 0.65, 0.8);
    const lidGeo = new THREE.BoxGeometry(1.2, 0.25, 0.84);
    const chestGlowGeo = new THREE.OctahedronGeometry(0.22, 0);
    this.disposableGeos.push(baseGeo, lidGeo, chestGlowGeo);

    for (const c of chestCoords) {
      const chestGroup = new THREE.Group();
      chestGroup.position.set(c.x, 0, c.z);
      chestGroup.rotation.y = c.ry;

      const base = new THREE.Mesh(baseGeo, chestWoodMat);
      base.position.y = 0.32;
      base.castShadow = castShadows;

      const lid = new THREE.Mesh(lidGeo, chestGoldMat);
      lid.position.y = 0.74;
      lid.castShadow = castShadows;

      const glow = new THREE.Mesh(chestGlowGeo, torchGlowMat);
      glow.position.y = 1.25;

      chestGroup.add(base, lid, glow);
      this.group.add(chestGroup);

      this.chests.push({
        id: c.id,
        x: c.x,
        z: c.z,
        opened: false,
        isSecret: c.isSecret,
        lidMesh: lid,
        glowMesh: glow,
      });
    }

    // Enemy, Guard & Boss Spawns
    if (subtype === 'guarded_castle') {
      // Friendly castle guards at the Entrance Hall, invaders deeper inside the Keep!
      this.enemySpawns.push(
        { x: -3.2, z: -2.0, isBoss: false, isFriendlyGuard: true },
        { x: 3.2, z: -2.0, isBoss: false, isFriendlyGuard: true },
      );
    }

    this.enemySpawns.push(
      { x: 0, z: -12, isBoss: false },
      { x: -3.2 + (rand() - 0.5) * 2, z: -22, isBoss: false },
      { x: 3.2 + (rand() - 0.5) * 2, z: -24.5, isBoss: false },
      { x: -14, z: -23.2, isBoss: false },
      { x: 14, z: -23.2, isBoss: false },
      { x: 15, z: -16.2, isBoss: false },
      { x: 0, z: -33, isBoss: false },
      { x: -5, z: -43, isBoss: false },
      { x: 5, z: -43, isBoss: false },
      { x: 0, z: -49.5, isBoss: true },
    );

    this.scene.add(this.group);
  }

  public damageInteriorNodesInRadius(
    x: number,
    z: number,
    radius: number,
    damage: number,
    outRewards: HarvestReward[],
  ): number {
    outRewards.length = 0;
    let hits = 0;
    const rSq = radius * radius;
    for (const entry of this.interiorNodes) {
      if (entry.node.hp <= 0) continue;
      const dx = entry.node.x - x;
      const dz = entry.node.z - z;
      if (dx * dx + dz * dz <= rSq) {
        entry.node.hp -= damage;
        hits++;
        if (entry.node.hp <= 0) {
          entry.mesh.visible = false;
          outRewards.push({
            nodeId: entry.node.id,
            x: entry.node.x,
            y: 0,
            z: entry.node.z,
            kind: entry.node.kind,
            itemId: entry.node.rewardItemId,
            quantity: entry.node.rewardQty,
            shardReward: entry.node.shardReward,
            xpReward: 20,
          });
        }
      }
    }
    return hits;
  }

  public clampPosition(x: number, z: number, radius: number): { x: number; z: number } {
    let bestX = x;
    let bestZ = z;
    let insideAny = false;

    for (const r of ROOMS) {
      if (
        x >= r.minX + radius &&
        x <= r.maxX - radius &&
        z >= r.minZ + radius &&
        z <= r.maxZ - radius
      ) {
        insideAny = true;
        break;
      }
    }

    if (!insideAny) {
      let bestDistSq = Infinity;
      for (const r of ROOMS) {
        const cx = THREE.MathUtils.clamp(x, r.minX + radius, r.maxX - radius);
        const cz = THREE.MathUtils.clamp(z, r.minZ + radius, r.maxZ - radius);
        const dSq = (x - cx) * (x - cx) + (z - cz) * (z - cz);
        if (dSq < bestDistSq) {
          bestDistSq = dSq;
          bestX = cx;
          bestZ = cz;
        }
      }
    }

    for (const c of this.colliders) {
      const dx = bestX - c.x;
      const dz = bestZ - c.z;
      const minD = radius + c.radius;
      const dSq = dx * dx + dz * dz;
      if (dSq < minD * minD && dSq > 0.00001) {
        const d = Math.sqrt(dSq);
        const push = minD - d;
        bestX += (dx / d) * push;
        bestZ += (dz / d) * push;
      }
    }

    return { x: bestX, z: bestZ };
  }

  public isNearExit(x: number, z: number, maxDist = 2.6): boolean {
    return Math.hypot(x - this.exitPos.x, z - this.exitPos.z) <= maxDist;
  }

  public getNearbyChest(x: number, z: number, maxDist = 2.8): DungeonChest | null {
    for (const c of this.chests) {
      if (!c.opened && Math.hypot(x - c.x, z - c.z) <= maxDist) {
        return c;
      }
    }
    return null;
  }

  public markChestOpened(chest: DungeonChest): void {
    chest.opened = true;
    chest.lidMesh.rotation.x = -0.85;
    chest.lidMesh.position.y = 0.85;
    chest.lidMesh.position.z = -0.22;
    chest.glowMesh.visible = false;
  }

  public update(dt: number): void {
    this.elapsed += dt;
    const mat = this.portalCore.material as THREE.MeshBasicMaterial;
    mat.opacity = 0.7 + Math.sin(this.elapsed * 3.5) * 0.14;
    for (const c of this.chests) {
      if (!c.opened) {
        c.glowMesh.rotation.y += dt * 2.2;
      }
    }
    for (const n of this.interiorNodes) {
      if (n.node.hp > 0) {
        n.mesh.rotation.y += dt * 0.8;
      }
    }
  }

  public dispose(): void {
    this.scene.remove(this.group);
    this.disposableGeos.forEach((g) => g.dispose());
    this.disposableMats.forEach((m) => m.dispose());
  }
}
