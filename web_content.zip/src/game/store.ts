import { create } from "zustand";
import { CATALOG, TOTAL_BODIES } from "./catalog";
import { MISSIONS, rankFor } from "./missions";
import { loadSave, writeSave, type SaveData, DEFAULT_SAVE, clearSave } from "./save";
import { sfxCollect, sfxDiscover, sfxRank, setMuted } from "./audio";
import type { HudState, Marker } from "./types";

const emptyHud = (): HudState => ({
  fps: 60,
  speed: 0,
  hull: 1,
  boost: 1,
  credits: 0,
  xp: 0,
  rank: "CADET",
  xpInto: 0,
  xpSpan: 80,
  discovered: 0,
  total: TOTAL_BODIES,
  samples: 0,
  missionTitle: MISSIONS[0].title,
  missionText: MISSIONS[0].text,
  missionProgress: 0,
  missionGoal: MISSIONS[0].goal,
  nearestName: "—",
  nearestDist: 0,
  nearestKind: "",
  canScan: false,
  scanning: false,
  targetId: null,
  targetName: "None",
  warping: false,
  markers: [],
  toastTitle: "",
  toastText: "",
  toastOn: false,
  phase: "attract",
  muted: false,
  dimension: 0,
  wSlice: 0,
  vPhase: 0,
});

function currentMission(save: SaveData) {
  return MISSIONS.find((m) => !save.completed.includes(m.id)) ?? MISSIONS[MISSIONS.length - 1];
}

function missionProgress(save: SaveData) {
  const m = currentMission(save);
  switch (m.kind) {
    case "scan":
      return Math.min(m.goal, save.scans);
    case "dive":
      return Math.min(m.goal, save.dives);
    case "bh":
      return Math.min(m.goal, save.bhScans);
    case "discover":
    case "discover12":
    case "all":
      return Math.min(m.goal, save.discovered.length);
    case "samples":
      return Math.min(m.goal, save.samples);
    case "warp":
      return Math.min(m.goal, save.warps);
    default:
      return 0;
  }
}

type GameStore = {
  save: SaveData
  hud: HudState
  catalogOpen: boolean
  toastTimer: number
  load: () => void
  persist: () => void
  resetProgress: () => void
  setPhase: (phase: HudState["phase"]) => void
  setCatalogOpen: (open: boolean) => void
  toggleMute: () => void
  patchHud: (partial: Partial<HudState>) => void
  toast: (title: string, text: string) => void
  addXP: (amount: number, reason: string) => void
  discover: (id: number) => boolean
  recordScan: (id: number, dive: boolean, blackHole: boolean) => void
  collectSample: () => void
  recordWarp: () => void
  flushMissions: () => void
};

let persistAt = 0;

export const useGameStore = create<GameStore>((set, get) => ({
  save: { ...DEFAULT_SAVE, discovered: [] },
  hud: emptyHud(),
  catalogOpen: false,
  toastTimer: 0,

  load: () => {
    const save = loadSave();
    setMuted(save.muted);
    set({ save });
    get().flushMissions();
    get().patchHud({
      credits: save.credits,
      xp: save.xp,
      muted: save.muted,
      dimension: 0,
      wSlice: 0,
      vPhase: 0,
      samples: save.samples,
      discovered: save.discovered.length,
    });
  },

  persist: () => {
    writeSave(get().save);
  },

  resetProgress: () => {
    clearSave();
    const save = { ...DEFAULT_SAVE, discovered: [] as string[] };
    set({ save, catalogOpen: false });
    get().flushMissions();
    get().patchHud({
      credits: 0,
      xp: 0,
      samples: 0,
      discovered: 0,
      rank: "CADET",
      xpInto: 0,
      xpSpan: 80,
    });
  },

  setPhase: (phase) => {
    get().patchHud({ phase });
  },

  setCatalogOpen: (open) => set({ catalogOpen: open }),

  toggleMute: () => {
    const save = { ...get().save, muted: !get().save.muted };
    setMuted(save.muted);
    set({ save });
    get().patchHud({ muted: save.muted });
    get().persist();
  },

  patchHud: (partial) => {
    set((s) => ({ hud: { ...s.hud, ...partial } }));
  },

  toast: (title, text) => {
    window.clearTimeout(get().toastTimer);
    const toastTimer = window.setTimeout(() => {
      get().patchHud({ toastOn: false });
    }, 2200);
    set({ toastTimer });
    get().patchHud({ toastTitle: title, toastText: text, toastOn: true });
  },

  addXP: (amount, reason) => {
    const before = rankFor(get().save.xp).current.name;
    const save = {
      ...get().save,
      xp: get().save.xp + amount,
      credits: get().save.credits + Math.max(1, Math.round(amount * 0.35)),
    };
    set({ save });
    const after = rankFor(save.xp).current.name;
    if (after !== before) {
      sfxRank();
      get().toast("RANK UP", after);
    } else {
      get().toast("XP GAINED", `+${amount} · ${reason}`);
    }
    get().flushMissions();
    schedulePersist();
  },

  discover: (id) => {
    const key = String(id);
    if (get().save.discovered.includes(key)) return false;
    const body = CATALOG[id];
    const save = {
      ...get().save,
      discovered: [...get().save.discovered, key],
      xp: get().save.xp + 25,
      credits: get().save.credits + 10,
    };
    set({ save });
    sfxDiscover();
    get().toast("NEW DISCOVERY", body?.name ?? "Unknown object");
    get().flushMissions();
    schedulePersist();
    return true;
  },

  recordScan: (id, dive, blackHole) => {
    const first = get().discover(id);
    const save = {
      ...get().save,
      scans: get().save.scans + 1,
      dives: get().save.dives + (dive ? 1 : 0),
      bhScans: get().save.bhScans + (blackHole ? 1 : 0),
    };
    set({ save });
    if (!first) get().addXP(12, "Rescan");
    else get().flushMissions();
    schedulePersist();
  },

  collectSample: () => {
    const save = {
      ...get().save,
      samples: get().save.samples + 1,
      xp: get().save.xp + 15,
      credits: get().save.credits + 8,
    };
    set({ save });
    sfxCollect();
    get().toast("SAMPLE COLLECTED", `Stellar sample · ${save.samples} held`);
    get().flushMissions();
    schedulePersist();
  },

  recordWarp: () => {
    const save = { ...get().save, warps: get().save.warps + 1 };
    set({ save });
    get().addXP(20, "Warp");
    get().flushMissions();
    schedulePersist();
  },

  flushMissions: () => {
    const save = { ...get().save };
    let gained = 0;
    for (const m of MISSIONS) {
      if (save.completed.includes(m.id)) continue;
      const progress = missionProgress(save);
      if (progress >= m.goal) {
        save.completed = [...save.completed, m.id];
        save.xp += m.xp;
        save.credits += Math.round(m.xp * 0.45);
        gained += m.xp;
        get().toast("MISSION COMPLETE", m.title);
      }
    }
    set({ save });
    const m = currentMission(save);
    const rk = rankFor(save.xp);
    const base = rk.current.xp;
    const top = rk.next ? rk.next.xp : base + 800;
    get().patchHud({
      credits: save.credits,
      xp: save.xp,
      rank: rk.current.name,
      xpInto: save.xp - base,
      xpSpan: top - base,
      discovered: save.discovered.length,
      samples: save.samples,
      missionTitle: m.title,
      missionText: m.text,
      missionProgress: missionProgress(save),
      missionGoal: m.goal,
      phase: save.completed.includes("master") && get().hud.phase === "play" ? "complete" : get().hud.phase,
    });
    if (gained) schedulePersist();
  },
}));

function schedulePersist() {
  const now = performance.now();
  if (now - persistAt < 800) return;
  persistAt = now;
  useGameStore.getState().persist();
}

export function selectMarkers(list: Marker[]) {
  useGameStore.getState().patchHud({ markers: list });
}

export function isDiscovered(id: number) {
  return useGameStore.getState().save.discovered.includes(String(id));
}
