import { create } from "zustand";
import type { Phase } from "@/game/types";

export type GameHud = {
  phase: Phase;
  ready: boolean;
  health: number;
  maxHealth: number;
  ammo: number;
  reserve: number;
  reloading: boolean;
  score: number;
  wave: number;
  kills: number;
  highScore: number;
  bestWave: number;
  hitmarkerAt: number;
  hurtAt: number;
  banner: string;
  muted: boolean;
  sensitivity: number;
  aimAssist: boolean;
  newRecord: boolean;
};

export const useGameStore = create<GameHud>(() => ({
  phase: "title",
  ready: false,
  health: 100,
  maxHealth: 100,
  ammo: 6,
  reserve: 24,
  reloading: false,
  score: 0,
  wave: 1,
  kills: 0,
  highScore: 0,
  bestWave: 0,
  hitmarkerAt: 0,
  hurtAt: 0,
  banner: "",
  muted: false,
  sensitivity: 1,
  aimAssist: true,
  newRecord: false,
}));

export function toggleMuted() {
  useGameStore.setState((s) => ({ muted: !s.muted }));
}
