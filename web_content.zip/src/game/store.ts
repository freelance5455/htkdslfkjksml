import { create } from "zustand";

export type NetStatus = "conectando" | "online" | "solo";
export type WeatherId = "sun" | "rain";

export type ValleyState = {
  ready: boolean;
  playing: boolean;
  name: string;
  coins: number;
  health: number;
  stamina: number;
  hunger: number;
  weather: WeatherId;
  clock: string;
  period: string;
  location: string;
  riding: boolean;
  slot: number;
  seedId: string;
  seeds: Record<string, number>;
  crops: Record<string, number>;
  apples: number;
  prompt: string | null;
  promptLive: boolean;
  modal: null | "shop" | "sell" | "bag";
  peers: number;
  net: NetStatus;
  toast: string | null;
  tip: string;
  goalLabel: string;
  goalAngle: number;
  goalMeters: number;
  sound: boolean;
};

export const valleyStore = create<ValleyState>(() => ({
  ready: false,
  playing: false,
  name: "Oliver",
  coins: 80,
  health: 100,
  stamina: 100,
  hunger: 100,
  weather: "sun",
  clock: "9:00 AM",
  period: "Manhã",
  location: "Minha Fazenda",
  riding: false,
  slot: 1,
  seedId: "wheat",
  seeds: { wheat: 8, carrot: 4, tomato: 2 },
  crops: {},
  apples: 4,
  prompt: null,
  promptLive: false,
  modal: null,
  peers: 0,
  net: "conectando",
  toast: null,
  tip: "Escolha uma semente e plante num canteiro.",
  goalLabel: "Canteiros",
  goalAngle: 0,
  goalMeters: 0,
  sound: true,
}));

