import { create } from "zustand";
import { getLocation } from "@/data/locations";
import { getPuzzle } from "@/data/puzzles";
import { STARS } from "@/data/constellation";
import type { Overlay, QualityLevel, SaveState } from "./types";
import {
  bumpJournal,
  deriveAct,
  deriveFlags,
  fillNames,
  locationUnlocked,
  matchCombination,
  setJournalMin,
} from "./engine";
import {
  clearSave,
  defaultSave,
  loadAdmin,
  loadSave,
  writeSave,
} from "./save";
import { musicForAct, sfx } from "./audio";

type Toast = { id: number; text: string } | null;

interface GameStore extends SaveState {
  hydrated: boolean;
  toast: Toast;
  pendingChoice: {
    prompt: string;
    options: { id: string; label: string; flag: string; text: string }[];
  } | null;
  hintText: string | null;
  puzzleHintCount: Record<string, number>;
  combineSlots: string[];
  adminOpen: boolean;
  hydrate: () => void;
  persist: () => void;
  newGame: () => void;
  continueGame: () => void;
  backToTitle: () => void;
  setOverlay: (o: Overlay) => void;
  travel: (id: string) => void;
  interact: (hotspotId: string) => void;
  closeModal: () => void;
  solvePuzzle: (puzzleId: string) => void;
  addItem: (id: string, silent?: boolean) => void;
  inspect: (id: string | null) => void;
  toggleCombine: (id: string) => void;
  tryCombine: () => void;
  setFlag: (id: string, value?: boolean) => void;
  choose: (optionId: string) => void;
  setResonance: (id: string, value: string) => void;
  setTimeLayer: (layer: SaveState["timeLayer"]) => void;
  listenToStar: () => void;
  setSettings: (partial: Partial<SaveState["settings"]>) => void;
  setQuality: (q: QualityLevel, lock?: boolean) => void;
  setNames: (names: SaveState["names"]) => void;
  showToast: (text: string) => void;
  startCinematic: (id: string) => void;
  advanceCinematic: () => void;
  advanceEnding: () => void;
  finishEnding: () => void;
  openAdmin: () => void;
  closeAdmin: () => void;
  applyImported: (s: SaveState) => void;
  wipe: () => void;
}

let toastSeq = 1;
let persistTimer: ReturnType<typeof setTimeout> | null = null;

function schedulePersist(get: () => GameStore) {
  if (persistTimer) clearTimeout(persistTimer);
  persistTimer = setTimeout(() => {
    const s = get();
    if (!s.hydrated) return;
    if (s.phase === "title") return;
    writeSave(s);
  }, 400);
}

function withDerived(partial: Partial<SaveState>, prev: SaveState): Partial<SaveState> {
  const merged: SaveState = { ...prev, ...partial, flags: { ...prev.flags, ...(partial.flags ?? {}) } };
  if (partial.inventory) merged.inventory = partial.inventory;
  const flags = deriveFlags(merged);
  const act = deriveAct(flags);
  return { ...partial, flags, act };
}

export const useGame = create<GameStore>((set, get) => ({
  ...defaultSave(),
  hydrated: false,
  toast: null,
  pendingChoice: null,
  hintText: null,
  puzzleHintCount: {},
  combineSlots: [],
  adminOpen: false,

  hydrate: () => {
    if (get().hydrated) return;
    const saved = loadSave();
    const admin = loadAdmin();
    if (saved) {
      const flags = deriveFlags(saved);
      set({
        ...saved,
        flags,
        act: deriveAct(flags),
        overlay: "none",
        names: admin.names ?? saved.names,
        hydrated: true,
        phase: saved.phase === "title" ? "title" : "title",
      });
    } else {
      set({
        hydrated: true,
        names: admin.names ?? defaultSave().names,
      });
    }
  },

  persist: () => writeSave(get()),

  newGame: () => {
    const names = get().names;
    const settings = get().settings;
    const next = {
      ...defaultSave(),
      names,
      settings,
      phase: "intro" as const,
      locationId: "seuil",
      flags: { game_started: true, visited_seuil: true },
      discovered: ["seuil"],
      visits: { seuil: 1 },
      journalStage: { j_quete: 0, j_lohen: 0, j_esteban: 0, j_mystere_voix: 0, j_archive_locked: 0 },
      overlay: "dialogue" as const,
      dialogueId: "d_intro",
      hydrated: true,
    };
    set({ ...next, pendingChoice: null, hintText: null, combineSlots: [], cinematicId: null, adminOpen: false });
    writeSave({ ...get() });
    musicForAct(1);
    sfx("soft");
  },

  continueGame: () => {
    const saved = loadSave();
    if (!saved || saved.phase === "title" || !saved.flags.game_started) {
      get().newGame();
      return;
    }
    const flags = deriveFlags(saved);
    set({
      ...saved,
      flags,
      act: deriveAct(flags),
      phase: "reconnect",
      overlay: "none",
      hydrated: true,
      pendingChoice: null,
    });
    sfx("soft");
    window.setTimeout(() => {
      const s = get();
      if (s.phase !== "reconnect") return;
      const phase = saved.phase === "ending" || saved.phase === "credits" ? saved.phase : "playing";
      set({ phase });
      musicForAct(s.act);
    }, 2200);
  },

  backToTitle: () => {
    writeSave(get());
    set({ phase: "title", overlay: "none", adminOpen: false });
  },

  setOverlay: (o) => {
    sfx("ui");
    set({ overlay: o, hintText: o === "none" ? get().hintText : get().hintText });
    if (o === "none") set({ activePuzzle: null, inspectId: null, dialogueId: null });
    schedulePersist(get);
  },

  travel: (id) => {
    const state = get();
    if (!locationUnlocked(id, state) && id !== state.locationId) {
      const loc = getLocation(id);
      if (!loc) return;
      const reachable = getLocation(state.locationId)?.exits.some(
        (e) => e.to === id && (!e.requireFlag || state.flags[e.requireFlag]),
      );
      if (!reachable) {
        get().showToast("Ce lieu n'est pas encore ouvert.");
        return;
      }
    }
    const loc = getLocation(id);
    if (!loc) return;
    sfx("whoosh");
    const visits = { ...state.visits, [id]: (state.visits[id] ?? 0) + 1 };
    const discovered = state.discovered.includes(id) ? state.discovered : [...state.discovered, id];
    const flags = { ...state.flags };
    if (loc.discoverFlag) flags[loc.discoverFlag] = true;
    let journalStage = state.journalStage;
    if (loc.discoverFlag === "visited_seuil") journalStage = setJournalMin(state, "j_seuil", 0);
    if (loc.discoverFlag === "visited_village") journalStage = setJournalMin({ ...state, journalStage }, "j_brumeveil", 0);
    if (loc.discoverFlag === "visited_observatory")
      journalStage = setJournalMin({ ...state, journalStage }, "j_obs", 0);
    if (loc.discoverFlag === "visited_city") journalStage = setJournalMin({ ...state, journalStage }, "j_astraea", 0);
    if (loc.discoverFlag === "visited_sanctuary")
      journalStage = setJournalMin({ ...state, journalStage }, "j_sanctuaire", 0);
    if (loc.discoverFlag === "visited_gates") journalStage = setJournalMin({ ...state, journalStage }, "j_portes", 0);

    const patch = withDerived(
      {
        locationId: id,
        visits,
        discovered,
        flags,
        journalStage,
        overlay: "none",
        timeLayer: "present",
      },
      { ...state, flags, journalStage, visits, discovered },
    );
    set(patch);
    musicForAct((patch.act as number) ?? state.act);
    schedulePersist(get);
  },

  interact: (hotspotId) => {
    const state = get();
    const loc = getLocation(state.locationId);
    const hs = loc?.hotspots.find((h) => h.id === hotspotId);
    if (!hs) return;
    const a = hs.action;
    if (a.type === "examine") {
      sfx("page");
      const flags = { ...state.flags };
      if (a.flag) flags[a.flag] = true;
      let journalStage = state.journalStage;
      if (a.journalId) journalStage = bumpJournal({ ...state, flags }, a.journalId);
      if (a.flag === "examined_chair") {
        const visits = state.visits[state.locationId] ?? 1;
        journalStage = setJournalMin({ ...state, journalStage }, "j_echo_chair", Math.min(2, visits - 1));
      }
      set(
        withDerived(
          { flags, journalStage, overlay: "dialogue", dialogueId: `ex:${hotspotId}` },
          { ...state, flags, journalStage },
        ),
      );
      return;
    }
    if (a.type === "pickup") {
      get().addItem(a.itemId);
      const flags = { ...get().flags, ...(a.flag ? { [a.flag]: true } : {}) };
      set(withDerived({ flags, overlay: "dialogue", dialogueId: `ex:${hotspotId}` }, { ...get(), flags }));
      return;
    }
    if (a.type === "puzzle") {
      sfx("soft");
      set({ overlay: "puzzle", activePuzzle: a.puzzleId });
      return;
    }
    if (a.type === "travel") {
      get().travel(a.to);
      return;
    }
    if (a.type === "dialogue") {
      sfx("page");
      set({ overlay: "dialogue", dialogueId: a.dialogueId });
      return;
    }
    if (a.type === "choice") {
      set({ overlay: "choice", pendingChoice: { prompt: a.prompt, options: a.options } });
      return;
    }
    if (a.type === "portal") {
      sfx("whoosh");
      const next = state.timeLayer === "present" ? "past" : "present";
      get().showToast(next === "past" ? "Le passé se superpose." : "Le présent reprend.");
      set({ timeLayer: next });
      schedulePersist(get);
      return;
    }
    if (a.type === "use") {
      if (!state.inventory.includes(a.itemId)) {
        get().showToast("Une étrange résonance est détectée… mais il manque quelque chose.");
        return;
      }
      sfx("solve");
      const flags = { ...state.flags, [a.flag]: true };
      set(withDerived({ flags, overlay: "dialogue", dialogueId: `ex:${hotspotId}` }, { ...state, flags }));
      return;
    }
    if (a.type === "resonance") {
      set({ overlay: "resonance", dialogueId: a.resonanceId });
      return;
    }
    if (a.type === "cinematic") {
      get().startCinematic(a.cinematicId);
      return;
    }
    if (a.type === "ghost") {
      get().addItem(a.fragmentId);
    }
  },

  closeModal: () => {
    const d = get().dialogueId;
    if (d === "d_intro") {
      set(withDerived({ flags: { ...get().flags, heard_intro: true } }, get()));
    }
    set({ overlay: "none", activePuzzle: null, inspectId: null, dialogueId: null, pendingChoice: null, hintText: null });
    if (get().phase === "intro") set({ phase: "playing" });
    schedulePersist(get);
  },

  solvePuzzle: (puzzleId) => {
    const p = getPuzzle(puzzleId);
    if (!p) return;
    const state = get();
    if (state.solved.includes(puzzleId) && state.flags[p.rewardFlag]) {
      set({ overlay: "none", activePuzzle: null });
      return;
    }
    sfx("solve");
    const flags = { ...state.flags, [p.rewardFlag]: true };
    const solved = state.solved.includes(puzzleId) ? state.solved : [...state.solved, puzzleId];
    let inventory = state.inventory;
    if (p.rewardItem && !inventory.includes(p.rewardItem)) inventory = [...inventory, p.rewardItem];
    if (puzzleId === "p_camp_memoire" && !inventory.includes("souvenir_camp")) {
      inventory = [...inventory, "souvenir_camp"];
      flags.got_souvenir_camp = true;
    }
    if (puzzleId === "p_porte_lien" && !inventory.includes("fragment_lien")) {
      inventory = [...inventory, "fragment_lien"];
    }
    if (puzzleId === "p_obs_anneaux") {
      flags.act4_unlocked = true;
    }
    let journalStage = setJournalMin(state, "j_quete", state.act > 2 ? 1 : 0);
    if (p.rewardFlag === "solved_seuil") {
      journalStage = setJournalMin({ ...state, journalStage }, "j_constellation", 0);
      journalStage = setJournalMin({ ...state, journalStage }, "j_seuil", 1);
    }
    if (p.rewardFlag === "solved_miroir") journalStage = setJournalMin({ ...state, journalStage }, "j_livre", 0);
    if (p.rewardFlag === "seen_clock" || flags.seen_clock)
      journalStage = setJournalMin({ ...state, journalStage }, "j_mystere_heures", 0);

    const patch = withDerived(
      { flags, solved, inventory, journalStage, overlay: "none", activePuzzle: null },
      { ...state, flags, solved, inventory, journalStage },
    );
    set(patch);
    if (p.rewardItem) get().showToast("Une trace s'est attachée à vous.");
    else get().showToast("Quelque chose s'aligne.");
    const unlocked = STARS.filter((s) => (patch.flags as Record<string, boolean>)[s.unlockFlag] && !state.flags[s.unlockFlag]);
    if (unlocked.length) {
      sfx("star");
      get().showToast("Une nouvelle étoile.");
    }
    if (typeof navigator !== "undefined" && state.settings.vibrate && navigator.vibrate) navigator.vibrate(18);
    schedulePersist(get);
  },

  addItem: (id, silent) => {
    const state = get();
    if (state.inventory.includes(id)) return;
    sfx("pickup");
    const inventory = [...state.inventory, id];
    const flags = { ...state.flags, [`has_${id}`]: true };
    const patch = withDerived({ inventory, flags }, { ...state, inventory, flags });
    set(patch);
    if (!silent) get().showToast("Une trace s'est attachée à vous.");
    schedulePersist(get);
  },

  inspect: (id) => set({ inspectId: id, overlay: id ? "inspect" : "inventory" }),

  toggleCombine: (id) => {
    const slots = get().combineSlots;
    if (slots.includes(id)) set({ combineSlots: slots.filter((s) => s !== id) });
    else if (slots.length < 3) set({ combineSlots: [...slots, id] });
  },

  tryCombine: () => {
    const state = get();
    const combo = matchCombination(state.combineSlots);
    if (!combo) {
      sfx("error");
      get().showToast("Rien ne résonne.");
      return;
    }
    if (combo.requireFlag && !state.flags[combo.requireFlag] && !deriveFlags(state)[combo.requireFlag]) {
      sfx("error");
      get().showToast("Pas encore. Trop tôt.");
      return;
    }
    if (state.inventory.includes(combo.outputId)) {
      get().showToast("Déjà assemblé.");
      return;
    }
    sfx("solve");
    const inventory = [...state.inventory, combo.outputId];
    const flags = { ...state.flags, [`has_${combo.outputId}`]: true };
    if (combo.outputId === "cle_seuil") {
      flags.has_cle_seuil = true;
      flags.act8_understood = true;
      flags.act9_unlocked = true;
    }
    const patch = withDerived(
      { inventory, flags },
      { ...state, inventory, flags },
    );
    set({ ...patch, combineSlots: [], overlay: "inventory" });
    get().showToast(combo.outputName);
    schedulePersist(get);
  },

  setFlag: (id, value = true) => {
    const flags = { ...get().flags, [id]: value };
    set(withDerived({ flags }, { ...get(), flags }));
    schedulePersist(get);
  },

  choose: (optionId) => {
    const pending = get().pendingChoice;
    const opt = pending?.options.find((o) => o.id === optionId);
    if (!opt) return;
    const flags = { ...get().flags, [opt.flag]: true, chose_act2: true };
    const choices = { ...get().choices, [get().locationId]: optionId };
    set(
      withDerived(
        { flags, choices, overlay: "dialogue", dialogueId: `choice:${optionId}` },
        { ...get(), flags, choices },
      ),
    );
    set({ pendingChoice: null });
    schedulePersist(get);
  },

  setResonance: (id, value) => {
    const resonances = { ...get().resonances, [id]: value };
    const flags = { ...get().flags, [id]: true, resonance_any: true };
    set(
      withDerived(
        { resonances, flags, overlay: "none", dialogueId: null },
        { ...get(), resonances, flags },
      ),
    );
    get().showToast("La résonance s'est inscrite.");
    schedulePersist(get);
  },

  setTimeLayer: (layer) => set({ timeLayer: layer }),

  listenToStar: () => {
    const state = get();
    const loc = getLocation(state.locationId);
    const puzzleHs = loc?.hotspots.find((h) => h.action.type === "puzzle" && !state.flags[getPuzzle(h.action.type === "puzzle" ? h.action.puzzleId : "")?.rewardFlag ?? ""]);
    const puzzleId =
      state.activePuzzle ??
      (puzzleHs && puzzleHs.action.type === "puzzle" ? puzzleHs.action.puzzleId : null);
    if (!puzzleId) {
      get().showToast("Le ciel se tait. Rien à écouter ici.");
      return;
    }
    const p = getPuzzle(puzzleId);
    if (!p) return;
    const used = state.puzzleHintCount[puzzleId] ?? 0;
    const level = Math.min(2, used);
    const text = p.hints[level]!;
    const puzzleHintCount = { ...state.puzzleHintCount, [puzzleId]: used + 1 };
    const starIntensity = { ...state.starIntensity };
    const first = STARS.find((s) => state.flags[s.unlockFlag]);
    if (first) starIntensity[first.id] = Math.max(0.35, (starIntensity[first.id] ?? 1) - 0.08);
    set({
      puzzleHintCount,
      starIntensity,
      hintText: text,
      overlay: "hints",
      hintsUsed: state.hintsUsed + 1,
    });
    sfx("soft");
    schedulePersist(get);
  },

  setSettings: (partial) => {
    const settings = { ...get().settings, ...partial };
    set({ settings });
    schedulePersist(get);
  },

  setQuality: (q, lock) => {
    const settings = { ...get().settings, quality: q, qualityLocked: lock ?? get().settings.qualityLocked };
    set({ settings });
    schedulePersist(get);
  },

  setNames: (names) => {
    set({ names });
    schedulePersist(get);
  },

  showToast: (text) => {
    const id = toastSeq++;
    set({ toast: { id, text: fillNames(text, get().names) } });
    window.setTimeout(() => {
      if (get().toast?.id === id) set({ toast: null });
    }, 2800);
  },

  startCinematic: (id) => {
    set({ overlay: "cinematic", cinematicId: id, introStep: 0 });
    if (id === "ending") {
      set({ phase: "ending", overlay: "none", flags: { ...get().flags, ending_started: true }, endingStep: 0 });
    }
  },

  advanceCinematic: () => {
    const id = get().cinematicId;
    const step = get().introStep + 1;
    if (id === "false_reveal") {
      if (step >= 6) {
        const flags = { ...get().flags, false_reveal_done: true, act8_unlocked: true, got_absence: true };
        const inventory = get().inventory.includes("fragment_absence")
          ? get().inventory
          : [...get().inventory, "fragment_absence"];
        const patch = withDerived(
          { flags, inventory, overlay: "none", cinematicId: null, locationId: "false_place", introStep: 0 },
          { ...get(), flags, inventory },
        );
        set({
          ...patch,
          discovered: get().discovered.includes("false_place")
            ? get().discovered
            : [...get().discovered, "false_place"],
        });
        get().showToast("Continue.");
        schedulePersist(get);
        return;
      }
      set({ introStep: step });
      return;
    }
    set({ introStep: step, overlay: "none", cinematicId: null });
  },

  advanceEnding: () => {
    const step = get().endingStep + 1;
    set({ endingStep: step });
    if (step === 1) set({ flags: { ...get().flags, archive_unlocked: true } });
  },

  finishEnding: () => {
    set({ phase: "credits", overlay: "none", flags: { ...get().flags, game_finished: true } });
    writeSave(get());
  },

  openAdmin: () => set({ adminOpen: true, overlay: "admin" }),
  closeAdmin: () => set({ adminOpen: false, overlay: "none" }),

  applyImported: (s) => {
    const flags = deriveFlags(s);
    set({ ...s, flags, act: deriveAct(flags), hydrated: true, overlay: "none" });
    writeSave(get());
  },

  wipe: () => {
    clearSave();
    const names = get().names;
    const settings = get().settings;
    set({ ...defaultSave(), names, settings, hydrated: true, phase: "title" });
  },
}));
