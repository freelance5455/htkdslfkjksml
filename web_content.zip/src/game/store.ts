import { useSyncExternalStore } from "react";
import {
  ACHIEVEMENTS, GOAL_TEMPLATES, LOCATIONS, RARITIES, RARITY_INFO, SHOVELS, TREASURES, TREASURE_MAP, UPGRADES,
  levelReward, upgradeCost, xpForLevel, locById,
  type GoalType, type LocId, type Rarity, type TDef,
} from "./data";
import { audio } from "./audio";

// ---------------- Types ----------------
export interface WorldSave {
  seed: number;
  collected: number[];
  terrain: number[];
}
export interface Settings {
  master: number;
  sfx: number;
  ambient: number;
  sens: number;
  invertY: boolean;
  ctrlScale: number;
  ctrlOpacity: number;
  swap: boolean;
  shadows: boolean;
  quality: "auto" | "low" | "med" | "high";
  haptics: boolean;
  showFps: boolean;
}
export interface Goal {
  type: GoalType;
  target: number;
  progress: number;
  reward: number;
  done: boolean;
}
export interface SaveData {
  v: 1;
  coins: number;
  xp: number;
  level: number;
  shovel: string;
  ownedShovels: string[];
  upgrades: Record<string, number>;
  unlocked: LocId[];
  location: LocId;
  inventory: Record<string, number>;
  discovered: Record<string, { count: number; first: number }>;
  history: { id: string; t: number; loc: LocId }[];
  stats: { digs: number; sandDug: number; items: number; coinsEarned: number; maxDepth: number; rare: number; legendary: number };
  achievements: string[];
  claimedTiers: string[];
  daily: { date: string; goals: Goal[] };
  settings: Settings;
  worlds: Partial<Record<LocId, WorldSave>>;
  played: boolean;
}

export type Screen = "menu" | "none" | "pause" | "inventory" | "book" | "shop" | "locations" | "settings" | "goals" | "merchant";

export interface Toast {
  id: number;
  title: string;
  sub?: string;
  color?: string;
  icon?: string;
  rarity?: Rarity;
}
export interface Discovery {
  id: string;
  isNew: boolean;
  key: number;
}

// ---------------- Defaults & persistence ----------------
const KEY = "deepdig.save.v1";

function todayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}
function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function makeDaily(level: number): { date: string; goals: Goal[] } {
  const date = todayKey();
  let h = hashStr(date);
  const rnd = () => {
    h = (Math.imul(h, 1664525) + 1013904223) >>> 0;
    return h / 4294967296;
  };
  const tier = level < 5 ? 0 : level < 10 ? 1 : 2;
  const pool = [...GOAL_TEMPLATES];
  const goals: Goal[] = [];
  for (let i = 0; i < 3; i++) {
    const t = pool.splice(Math.floor(rnd() * pool.length), 1)[0];
    goals.push({ type: t.type, target: t.targets[tier], progress: 0, reward: t.reward[tier], done: false });
  }
  return { date, goals };
}

export function defaultSettings(): Settings {
  return {
    master: 0.8, sfx: 1, ambient: 0.7, sens: 1, invertY: false, ctrlScale: 1, ctrlOpacity: 0.85,
    swap: false, shadows: true, quality: "auto", haptics: true, showFps: false,
  };
}
function defaultSave(): SaveData {
  return {
    v: 1, coins: 0, xp: 0, level: 1, shovel: "wood", ownedShovels: ["wood"],
    upgrades: { power: 0, speed: 0, load: 0, bag: 0, detect: 0, luck: 0 },
    unlocked: ["beach"], location: "beach", inventory: {}, discovered: {}, history: [],
    stats: { digs: 0, sandDug: 0, items: 0, coinsEarned: 0, maxDepth: 0, rare: 0, legendary: 0 },
    achievements: [], claimedTiers: [], daily: makeDaily(1), settings: defaultSettings(), worlds: {}, played: false,
  };
}

function load(): SaveData {
  const base = defaultSave();
  let raw: string | null = null;
  try {
    raw = localStorage.getItem(KEY);
  } catch {
    return base;
  }
  if (!raw) return base;
  try {
    const p = JSON.parse(raw);
    const s: SaveData = {
      ...base, ...p,
      upgrades: { ...base.upgrades, ...(p.upgrades || {}) },
      stats: { ...base.stats, ...(p.stats || {}) },
      settings: { ...base.settings, ...(p.settings || {}) },
      worlds: p.worlds || {},
      inventory: p.inventory || {},
      discovered: p.discovered || {},
    };
    // sanity
    s.inventory = Object.fromEntries(Object.entries(s.inventory).filter(([k, v]) => TREASURE_MAP[k] && typeof v === "number" && v > 0));
    if (!s.ownedShovels.includes("wood")) s.ownedShovels.push("wood");
    if (!s.ownedShovels.includes(s.shovel)) s.shovel = "wood";
    if (!s.unlocked.includes("beach")) s.unlocked.push("beach");
    if (!s.unlocked.includes(s.location)) s.location = "beach";
    if (!s.daily || s.daily.date !== todayKey()) s.daily = makeDaily(s.level);
    return s;
  } catch {
    // Never silently erase: keep a backup of the unreadable save.
    try {
      localStorage.setItem(KEY + ".corrupt." + Date.now(), raw);
    } catch {
      /* ignore */
    }
    return base;
  }
}

export const S: SaveData = load();

// ---------------- Reactive plumbing ----------------
let version = 0;
const subs = new Set<() => void>();
export function emit() {
  version++;
  subs.forEach((f) => f());
}
export function useStore(): number {
  return useSyncExternalStore(
    (f) => {
      subs.add(f);
      return () => subs.delete(f);
    },
    () => version
  );
}

type Handler = (...a: any[]) => void;
const handlers: Record<string, Handler[]> = {};
export const bus = {
  on(name: string, fn: Handler) {
    (handlers[name] ||= []).push(fn);
    return () => {
      handlers[name] = handlers[name].filter((f) => f !== fn);
    };
  },
  emit(name: string, ...a: any[]) {
    (handlers[name] || []).forEach((f) => f(...a));
  },
};

export const ui = {
  screen: "menu" as Screen,
  shopTab: "shovels" as "sell" | "shovels" | "upgrades",
  loading: false,
  toasts: [] as Toast[],
  discovery: null as Discovery | null,
  discoveryQueue: [] as Discovery[],
  levelUp: null as { level: number; reward: number } | null,
  inspect: null as string | null,
  nearMerchant: false,
  interact: "" as "" | "collect" | "sell",
  interactName: "",
  detector: false,
  flash: 0,
  flashColor: "#fff",
  saveFlash: 0,
};
export const hud = {
  depth: 0,
  layer: 0,
  signal: 0,
  signalTier: 0,
  fps: 0,
  digging: false,
  canDig: true,
  digMsg: "",
};

export function setScreen(s: Screen) {
  ui.screen = s;
  if (s !== "none") bus.emit("screen", s);
  emit();
}

// ---------------- Derived stats ----------------
export function curShovel() {
  return SHOVELS.find((s) => s.id === S.shovel) || SHOVELS[0];
}
export function derived() {
  const sh = curShovel();
  const u = S.upgrades;
  return {
    power: sh.power * (1 + 0.12 * (u.power || 0)),
    speed: sh.speed * (1 + 0.07 * (u.speed || 0)),
    radius: sh.radius * (1 + 0.06 * (u.load || 0)),
    bag: 10 + 5 * (u.bag || 0),
    detect: 5 + 1.5 * (u.detect || 0),
    luck: sh.luck * (1 + 0.12 * (u.luck || 0)),
  };
}
export function bagCount(): number {
  let n = 0;
  for (const k in S.inventory) n += S.inventory[k];
  return n;
}
export function bagValue(): number {
  let n = 0;
  for (const k in S.inventory) n += S.inventory[k] * (TREASURE_MAP[k]?.value || 0);
  return n;
}
export function discoveredCount(): number {
  return Object.keys(S.discovered).length;
}

// ---------------- Toasts ----------------
let toastId = 1;
export function toast(title: string, sub?: string, color?: string, rarity?: Rarity) {
  const t: Toast = { id: toastId++, title, sub, color, rarity };
  ui.toasts = [...ui.toasts.slice(-3), t];
  emit();
  setTimeout(() => {
    ui.toasts = ui.toasts.filter((x) => x.id !== t.id);
    emit();
  }, 2600);
}

// ---------------- Persistence ----------------
let dirty = false;
export function markDirty() {
  dirty = true;
}
export function saveNow(): boolean {
  bus.emit("beforeSave");
  try {
    localStorage.setItem(KEY, JSON.stringify(S));
    dirty = false;
    ui.saveFlash = Date.now();
    return true;
  } catch (e) {
    console.warn("save failed", e);
    return false;
  }
}
export function resetAll() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) localStorage.setItem(KEY + ".backup." + Date.now(), raw);
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
  location.reload();
}
export function startAutosave() {
  setInterval(() => {
    if (dirty) saveNow();
  }, 6000);
  const flush = () => {
    if (dirty) saveNow();
  };
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) flush();
  });
  window.addEventListener("pagehide", flush);
}

// ---------------- Progression ----------------
function achStats() {
  return {
    digs: S.stats.digs, sandDug: S.stats.sandDug, items: S.stats.items, coinsEarned: S.stats.coinsEarned,
    maxDepth: S.stats.maxDepth, level: S.level, unlocked: S.unlocked.length, discovered: discoveredCount(),
    rare: S.stats.rare, legendary: S.stats.legendary, shovels: S.ownedShovels.length,
  };
}
export function checkAchievements() {
  const st = achStats();
  for (const a of ACHIEVEMENTS) {
    if (!S.achievements.includes(a.id) && a.check(st)) {
      S.achievements.push(a.id);
      S.coins += a.reward;
      audio.achievement();
      toast("Achievement unlocked!", `${a.name}  +${a.reward} coins`, "#ffd166");
      markDirty();
    }
  }
}
export function addCoins(n: number) {
  S.coins += n;
  markDirty();
}
export function addXP(n: number) {
  S.xp += n;
  while (S.xp >= xpForLevel(S.level)) {
    S.xp -= xpForLevel(S.level);
    S.level++;
    const r = levelReward(S.level);
    S.coins += r;
    ui.levelUp = { level: S.level, reward: r };
    audio.levelUp();
    setTimeout(() => {
      if (ui.levelUp && ui.levelUp.level === S.level) {
        ui.levelUp = null;
        emit();
      }
    }, 3200);
  }
  markDirty();
}
function goalProgress(type: GoalType, amount: number, absolute = false) {
  if (!S.daily || S.daily.date !== todayKey()) S.daily = makeDaily(S.level);
  for (const g of S.daily.goals) {
    if (g.type !== type || g.done) continue;
    g.progress = absolute ? Math.max(g.progress, amount) : g.progress + amount;
    if (g.progress >= g.target) {
      g.done = true;
      g.progress = g.target;
      S.coins += g.reward;
      audio.achievement();
      toast("Daily goal complete!", `+${g.reward} coins`, "#7dd3fc");
    }
  }
}

export function recordDig(volume: number, depth: number) {
  S.stats.digs++;
  S.stats.sandDug += volume;
  if (depth > S.stats.maxDepth) S.stats.maxDepth = depth;
  if (S.stats.digs % 4 === 0) addXP(1);
  goalProgress("digs", 1);
  goalProgress("depth", depth, true);
  if (S.stats.digs % 5 === 0 || S.stats.digs < 3) checkAchievements();
  markDirty();
}

export function pushDiscovery(id: string) {
  const isNew = !S.discovered[id];
  const d: Discovery = { id, isNew, key: Date.now() + Math.random() };
  if (ui.discovery) ui.discoveryQueue.push(d);
  else showDiscovery(d);
  emit();
}
function showDiscovery(d: Discovery) {
  ui.discovery = d;
  const def = TREASURE_MAP[d.id];
  const dur = def.rarity === "legendary" ? 4200 : def.rarity === "rare" ? 3400 : 2600;
  setTimeout(() => {
    if (ui.discovery && ui.discovery.key === d.key) {
      ui.discovery = ui.discoveryQueue.shift() || null;
      if (ui.discovery) showDiscovery(ui.discovery);
      emit();
    }
  }, dur);
}

/** Add a collected treasure to the bag. Returns false if bag is full. */
export function addItem(id: string): boolean {
  const def = TREASURE_MAP[id];
  if (!def) return false;
  if (bagCount() >= derived().bag) {
    audio.error();
    toast("Bag is full!", "Sell items at the merchant or upgrade your bag", "#ff7a7a");
    return false;
  }
  S.inventory[id] = (S.inventory[id] || 0) + 1;
  const wasNew = !S.discovered[id];
  const d = S.discovered[id] || { count: 0, first: Date.now() };
  d.count++;
  S.discovered[id] = d;
  S.history.unshift({ id, t: Date.now(), loc: S.location });
  if (S.history.length > 40) S.history.length = 40;
  S.stats.items++;
  if (def.rarity === "rare") S.stats.rare++;
  if (def.rarity === "legendary") S.stats.legendary++;
  addXP(RARITY_INFO[def.rarity].xp * (wasNew ? 2 : 1));
  goalProgress("items", 1);
  if (def.rarity !== "common") goalProgress("rare", 1);
  checkAchievements();
  markDirty();
  toast(`+ ${def.name}`, wasNew ? "New collection entry!" : `${RARITY_INFO[def.rarity].name} • ${def.value} coins`, RARITY_INFO[def.rarity].color, def.rarity);
  emit();
  return true;
}

// ---------------- Economy ----------------
export function sellItems(ids: string[] | "all", qty?: number): number {
  const list = ids === "all" ? Object.keys(S.inventory) : ids;
  let total = 0;
  let count = 0;
  for (const id of list) {
    const have = S.inventory[id] || 0;
    if (!have) continue;
    const n = qty ? Math.min(qty, have) : have;
    total += n * TREASURE_MAP[id].value;
    count += n;
    if (have - n <= 0) delete S.inventory[id];
    else S.inventory[id] = have - n;
  }
  if (count === 0) return 0;
  S.coins += total;
  S.stats.coinsEarned += total;
  goalProgress("earn", total);
  checkAchievements();
  markDirty();
  audio.sell(total);
  bus.emit("sold", total, count);
  toast(`Sold ${count} item${count > 1 ? "s" : ""}`, `+${total.toLocaleString()} coins`, "#ffd166");
  emit();
  return total;
}
export function buyShovel(id: string): boolean {
  const sh = SHOVELS.find((s) => s.id === id)!;
  if (S.ownedShovels.includes(id) || S.coins < sh.price || S.level < sh.level) {
    audio.error();
    return false;
  }
  S.coins -= sh.price;
  S.ownedShovels.push(id);
  audio.buy();
  toast(`Purchased ${sh.name}`, "Tap EQUIP to use it", "#7dd3fc");
  checkAchievements();
  markDirty();
  emit();
  return true;
}
export function equipShovel(id: string) {
  if (!S.ownedShovels.includes(id)) return;
  S.shovel = id;
  audio.equip();
  bus.emit("equip");
  markDirty();
  emit();
}
export function upgradeLevel(id: string): number {
  return S.upgrades[id] || 0;
}
export function buyUpgrade(id: string): boolean {
  const u = UPGRADES.find((x) => x.id === id)!;
  const lvl = upgradeLevel(id);
  const cost = upgradeCost(u, lvl);
  if (lvl >= u.max || S.coins < cost) {
    audio.error();
    return false;
  }
  S.coins -= cost;
  S.upgrades[id] = lvl + 1;
  audio.buy();
  toast(`${u.name} → Lv ${lvl + 1}`, u.effect(lvl + 1), "#7dd3fc");
  markDirty();
  emit();
  return true;
}
export function canUnlock(id: LocId): boolean {
  const l = locById(id);
  return S.coins >= l.cost && S.level >= l.level;
}
export function unlockLocation(id: LocId): boolean {
  const l = locById(id);
  if (S.unlocked.includes(id)) return true;
  if (!canUnlock(id)) {
    audio.error();
    return false;
  }
  S.coins -= l.cost;
  S.unlocked.push(id);
  audio.buy();
  toast(`Unlocked ${l.name}!`, "Travel there from the map", "#ffd166");
  checkAchievements();
  markDirty();
  emit();
  return true;
}
export function claimTier(r: Rarity): boolean {
  const all = TREASURES.filter((t) => t.rarity === r);
  const key = "tier_" + r;
  if (S.claimedTiers.includes(key) || !all.every((t) => S.discovered[t.id])) return false;
  S.claimedTiers.push(key);
  const bonus = RARITY_INFO[r].bonus;
  S.coins += bonus;
  audio.achievement();
  toast(`${RARITY_INFO[r].name} set complete!`, `+${bonus} coins`, RARITY_INFO[r].color);
  markDirty();
  emit();
  return true;
}
export function tierComplete(r: Rarity): { have: number; total: number } {
  const all = TREASURES.filter((t) => t.rarity === r);
  return { have: all.filter((t) => S.discovered[t.id]).length, total: all.length };
}
export function allRarities() {
  return RARITIES;
}
export function allLocations() {
  return LOCATIONS;
}
export type { TDef };
