import { create } from "zustand";
import {
  activatePower,
  afterClash,
  ardenSpecial,
  assignTarget,
  clearPlan,
  commitRound,
  endPower,
  newVariantKeys,
  selectAbility,
  startCombat,
  telegraph,
  type CombatRuntime,
} from "./combat";
import { CHAR_BY_ID } from "./data/characters";
import { DISC_BY_ID } from "./data/discoveries";
import { getEpisode } from "./data/episodes";
import { defaultFighter, defaultSave, loadSave, persistSave } from "./save";
import type { EpisodeDef, SaveData, ScreenId, Stage } from "./types";
import { setAudioLevels, sfxLib, unlockAudio } from "./audio";

export interface PlayState {
  episode: EpisodeDef;
  stageIndex: number;
  lineIndex: number;
  exploreUsed: string[];
  exploreText: string | null;
  choiceTaken: string | null;
}

interface GameState {
  hydrated: boolean;
  screen: ScreenId;
  save: SaveData;
  play: PlayState | null;
  combat: CombatRuntime | null;
  toast: string | null;
  hydrate: () => void;
  go: (s: ScreenId) => void;
  newGame: () => void;
  continueGame: () => void;
  startEpisode: (id: number) => void;
  advance: () => void;
  choose: (optionId: string) => void;
  explore: (nodeId: string) => void;
  selectAbility: (uid: string, abilityId: string) => void;
  assignTarget: (targetUid: string) => void;
  clearPlan: (uid: string) => void;
  commit: () => void;
  dismissClash: () => void;
  firePower: (uid: string) => void;
  dismissPower: () => void;
  toggleSpecial: () => void;
  fireSpecial: (id: string) => void;
  setSettings: (p: Partial<SaveData["settings"]>) => void;
  restSquad: () => void;
  setFormation: (id: string, f: SaveData["fighters"][string]["formation"]) => void;
  equip: (fighterId: string, slot: "weapon" | "artifact" | "utility" | "defensive", itemId: string | undefined) => void;
  importJson: (json: string) => boolean;
  wipe: () => void;
}

function persist(save: SaveData) {
  return persistSave({ ...save, hasSave: true });
}

function addItem(save: SaveData, id: string, qty: number) {
  const inventory = [...save.inventory];
  const found = inventory.find((i) => i.id === id);
  if (found) found.qty += qty;
  else inventory.push({ id, qty });
  return inventory;
}

function addArchive(save: SaveData, id: string) {
  if (save.discoveries.includes(id)) return save;
  const disc = DISC_BY_ID[id];
  return {
    ...save,
    discoveries: [...save.discoveries, id],
    archive: save.archive.includes(id) ? save.archive : [...save.archive, id],
    flags: {
      ...save.flags,
      ...(id === "time-cracker" ? { time_cracker_found: true } : {}),
      ...(id === "mayonin-sword" ? { mayonin_sword_seen: true } : {}),
      ...(id === "father-file" ? { father_seen: true } : {}),
    },
  };
}

function grantXp(save: SaveData, ids: string[], xp: number) {
  const fighters = { ...save.fighters };
  for (const id of ids) {
    const f = { ...fighters[id] };
    if (!f) continue;
    f.xp += xp;
    while (f.xp >= f.level * 100) {
      f.xp -= f.level * 100;
      f.level += 1;
      const def = CHAR_BY_ID[id];
      if (def) f.hp = def.maxHp + (f.level - 1) * 6;
    }
    fighters[id] = f;
  }
  return fighters;
}

function applyReward(save: SaveData, play: PlayState, combat: CombatRuntime | null) {
  const stage = play.episode.stages[play.stageIndex];
  let next = { ...save };
  if (stage?.type === "reward") {
    const r = stage.reward;
    next.currency += r.currency;
    next.managerXp += r.managerXp;
    while (next.managerXp >= next.managerLevel * 100) {
      next.managerXp -= next.managerLevel * 100;
      next.managerLevel += 1;
    }
    const ids = next.recruited;
    next.fighters = grantXp(next, ids, r.xp);
    if (r.items) for (const it of r.items) next.inventory = addItem(next, it.id, it.qty);
    if (r.discovery) next = addArchive(next, r.discovery);
    if (r.ally && !next.recruited.includes(r.ally)) {
      next.recruited = [...next.recruited, r.ally];
      next.fighters = { ...next.fighters, [r.ally]: next.fighters[r.ally] ?? defaultFighter(r.ally) };
    }
    if (r.special && !next.ardenSpecials.includes(r.special)) {
      next.ardenSpecials = [...next.ardenSpecials, r.special];
    }
  }
  if (combat) {
    for (const key of newVariantKeys(combat)) {
      if (!next.enemyVariants.includes(key)) next.enemyVariants = [...next.enemyVariants, key];
    }
    for (const a of combat.allies) {
      const f = next.fighters[a.defId];
      if (f) next.fighters[a.defId] = { ...f, hp: Math.max(1, a.hp) };
    }
    if (combat.ardenAwakened) next.flags = { ...next.flags, arden_awakened: true };
  }
  return next;
}

function completeEpisode(save: SaveData, id: number): SaveData {
  const completed = save.completed.includes(id) ? save.completed : [...save.completed, id];
  const unlockedEpisode = Math.max(save.unlockedEpisode, Math.min(35, id + 1));
  return persist({
    ...save,
    completed,
    unlockedEpisode,
    currentEpisode: unlockedEpisode,
    flags: { ...save.flags, [`ep${id}_done`]: true },
  });
}

export const useGame = create<GameState>((set, get) => ({
  hydrated: false,
  screen: "boot",
  save: defaultSave(),
  play: null,
  combat: null,
  toast: null,

  hydrate: () => {
    const save = loadSave();
    setAudioLevels(save.settings.master, save.settings.sfx);
    set({ save, hydrated: true, screen: "menu" });
  },

  go: (s) => set({ screen: s, toast: null }),

  newGame: () => {
    unlockAudio();
    const save = persist({ ...defaultSave(), hasSave: true, rngSeed: (Date.now() ^ 0xa5a5a5a5) >>> 0 });
    const ep = getEpisode(1);
    set({
      save,
      combat: null,
      toast: null,
      play: ep
        ? { episode: ep, stageIndex: 0, lineIndex: 0, exploreUsed: [], exploreText: null, choiceTaken: null }
        : null,
      screen: ep ? "play" : "menu",
    });
  },

  continueGame: () => {
    const { save } = get();
    if (!save.hasSave) return;
    set({ screen: "episodes" });
  },

  startEpisode: (id) => {
    unlockAudio();
    const ep = getEpisode(id);
    const { save } = get();
    if (!ep || id > save.unlockedEpisode) return;
    set({
      screen: "play",
      play: { episode: ep, stageIndex: 0, lineIndex: 0, exploreUsed: [], exploreText: null, choiceTaken: null },
      combat: null,
      save: persist({ ...save, currentEpisode: id }),
    });
  },

  advance: () => {
    const { play, save, combat } = get();
    if (!play) return;
    const stage = play.episode.stages[play.stageIndex] as Stage | undefined;
    if (!stage) return;

    if (stage.type === "dialogue") {
      if (play.lineIndex < stage.lines.length - 1) {
        sfxLib.tap();
        set({ play: { ...play, lineIndex: play.lineIndex + 1 } });
        return;
      }
    }

    if (stage.type === "battle" && combat && combat.phase !== "victory" && combat.phase !== "defeat") {
      return;
    }

    if (stage.type === "battle" && !combat) {
      const rt = startCombat(stage.battle, save);
      set({ screen: "combat", combat: telegraph({ ...rt, phase: "brief" }) });
      return;
    }

    let nextSave = save;
    if (stage.type === "discovery") {
      sfxLib.discover();
      nextSave = persist(addArchive(save, stage.discoveryId));
    }
    if (stage.type === "recruit") {
      if (!save.recruited.includes(stage.characterId)) {
        nextSave = persist({
          ...save,
          recruited: [...save.recruited, stage.characterId],
        });
      }
    }
    if (stage.type === "reward") {
      nextSave = persist(applyReward(save, play, combat));
    }

    const nextIndex = play.stageIndex + 1;
    if (nextIndex >= play.episode.stages.length) {
      const done = completeEpisode(nextSave, play.episode.id);
      sfxLib.win();
      set({ save: done, play: null, combat: null, screen: "rewards", toast: `Episode ${String(play.episode.id).padStart(2, "0")} complete.` });
      return;
    }

    const nxt = play.episode.stages[nextIndex];
    set({
      save: nextSave,
      combat: nxt.type === "battle" ? null : combat,
      play: { ...play, stageIndex: nextIndex, lineIndex: 0, exploreUsed: [], exploreText: null, choiceTaken: null },
      screen: nxt.type === "battle" ? "play" : "play",
    });
  },

  choose: (optionId) => {
    const { play, save } = get();
    if (!play) return;
    const stage = play.episode.stages[play.stageIndex];
    if (stage.type !== "choice") return;
    const opt = stage.options.find((o) => o.id === optionId);
    if (!opt) return;
    sfxLib.confirm();
    let next = save;
    if (opt.flag) next = { ...next, flags: { ...next.flags, [opt.flag]: true } };
    if (opt.trust) {
      const f = next.fighters[opt.trust.id];
      if (f) {
        next = {
          ...next,
          fighters: {
            ...next.fighters,
            [opt.trust.id]: { ...f, trust: Math.min(4, Math.max(0, f.trust + opt.trust.delta)) },
          },
        };
      }
    }
    set({ save: persist(next), play: { ...play, choiceTaken: optionId } });
  },

  explore: (nodeId) => {
    const { play, save } = get();
    if (!play) return;
    const stage = play.episode.stages[play.stageIndex];
    if (stage.type !== "explore") return;
    if (play.exploreUsed.includes(nodeId)) return;
    const node = stage.nodes.find((n) => n.id === nodeId);
    if (!node) return;
    sfxLib.tap();
    let nextSave = save;
    if (node.result === "discovery" && node.payload) nextSave = persist(addArchive(save, node.payload));
    if (node.result === "item" && node.payload) nextSave = persist({ ...save, inventory: addItem(save, node.payload, 1) });
    if (node.result === "battle" || ((node.result === "nothing" || node.result === "lore") && Math.random() < 0.15)) {
      const variants = ["standard", "hunter", "armored", "corrupted"] as const;
      const variant = variants[Math.floor(Math.random() * variants.length)];
      const rt = startCombat(
        {
          title: node.result === "battle" ? "Hidden contact" : "Unscripted contact",
          enemies: [{ base: "ruin-stalker", variant }],
          deploy: save.recruited.slice(0, 4),
        },
        save,
      );
      set({
        save: nextSave,
        play: { ...play, exploreUsed: [...play.exploreUsed, nodeId], exploreText: node.result === "battle" ? node.text : "Something moved before the squad could finish investigating." },
        combat: telegraph(rt),
        screen: "combat",
      });
      return;
    }
    set({
      save: nextSave,
      play: { ...play, exploreUsed: [...play.exploreUsed, nodeId], exploreText: node.text },
    });
  },

  selectAbility: (uid, abilityId) => {
    const { combat } = get();
    if (!combat || combat.phase !== "plan") return;
    sfxLib.tap();
    set({ combat: selectAbility(combat, uid, abilityId) });
  },

  assignTarget: (targetUid) => {
    const { combat } = get();
    if (!combat || !combat.selected) return;
    sfxLib.confirm();
    set({ combat: assignTarget(combat, targetUid) });
  },

  clearPlan: (uid) => {
    const { combat } = get();
    if (!combat) return;
    set({ combat: clearPlan(combat, uid) });
  },

  commit: () => {
    const { combat } = get();
    if (!combat || combat.phase !== "plan") return;
    if (Object.keys(combat.plans).length === 0) return;
    sfxLib.clash();
    const next = commitRound(combat);
    set({ combat: next });
  },

  dismissClash: () => {
    const { combat } = get();
    if (!combat) return;
    if (combat.phase === "victory") {
      const playNow = get().play;
      const stage = playNow?.episode.stages[playNow.stageIndex];
      if (stage?.type === "battle") {
        set({ screen: "play" });
        get().advance();
      } else {
        set({ screen: "play", combat: null });
      }
      return;
    }
    if (combat.phase === "defeat") {
      set({ screen: "play", combat: null, toast: "The line broke. Re-enter the engagement." });
      return;
    }
    set({ combat: afterClash(combat) });
  },

  firePower: (uid) => {
    const { combat } = get();
    if (!combat) return;
    sfxLib.power();
    set({ combat: activatePower(combat, uid) });
  },

  dismissPower: () => {
    const { combat } = get();
    if (!combat) return;
    set({ combat: endPower(combat) });
  },

  toggleSpecial: () => {
    const { combat } = get();
    if (!combat) return;
    set({ combat: { ...combat, specialMenu: !combat.specialMenu } });
  },

  fireSpecial: (id) => {
    const { combat, save } = get();
    if (!combat) return;
    sfxLib.power();
    set({ combat: ardenSpecial(combat, id, save.ardenSpecials) });
  },

  setSettings: (p) => {
    const { save } = get();
    const settings = { ...save.settings, ...p };
    setAudioLevels(settings.master, settings.sfx);
    set({ save: persist({ ...save, settings }) });
  },

  restSquad: () => {
    const { save } = get();
    if (save.currency < 15) {
      set({ toast: "Rest costs 15 marks." });
      return;
    }
    const fighters = { ...save.fighters };
    for (const id of save.recruited) {
      const def = CHAR_BY_ID[id];
      const f = fighters[id];
      if (f && def) fighters[id] = { ...f, fatigue: false, hp: def.maxHp + (f.level - 1) * 6 };
    }
    set({ save: persist({ ...save, fighters, currency: save.currency - 15 }), toast: "The line sleeps. Fatigue lifts." });
  },

  setFormation: (id, f) => {
    const { save } = get();
    const cur = save.fighters[id];
    if (!cur) return;
    set({ save: persist({ ...save, fighters: { ...save.fighters, [id]: { ...cur, formation: f } } }) });
  },

  equip: (fighterId, slot, itemId) => {
    const { save } = get();
    const f = save.fighters[fighterId];
    if (!f) return;
    set({
      save: persist({
        ...save,
        fighters: { ...save.fighters, [fighterId]: { ...f, equipment: { ...f.equipment, [slot]: itemId } } },
      }),
    });
  },

  importJson: (json) => {
    try {
      const parsed = JSON.parse(json) as SaveData;
      if (!parsed?.version) return false;
      const save = persist({ ...defaultSave(), ...parsed, hasSave: true });
      set({ save, toast: "Save imported." });
      return true;
    } catch {
      return false;
    }
  },

  wipe: () => {
    const save = persist({ ...defaultSave(), hasSave: false });
    set({ save: { ...save, hasSave: false }, play: null, combat: null, screen: "menu", toast: "Progress cleared." });
  },
}));
