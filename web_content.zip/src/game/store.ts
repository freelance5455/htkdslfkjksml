import { useSyncExternalStore } from 'react';

export type Pattern = 'solid' | 'stripes' | 'camo' | 'tiger' | 'digital' | 'hex';

export interface SkinColors {
  c1: string;
  c2: string;
  c3: string;
  metal: boolean;
  pattern: Pattern;
}

export type Quality = 'low' | 'med' | 'high';
export type Difficulty = 'easy' | 'normal' | 'hard' | 'pro';

export interface Settings {
  sens: number;
  quality: Quality;
  volume: number;
  difficulty: Difficulty;
  bots: number;
  fov: number;
  showFps: boolean;
  leftFire: boolean;
  btnScale: number;
}

export interface Mods {
  code1: boolean;
  code2: boolean;
  code3: boolean;
  infMoney: boolean;
  allUnlocked: boolean;
  god: boolean;
  infAmmo: boolean;
  noReload: boolean;
  oneShot: boolean;
  noRecoil: boolean;
  speed: boolean;
  highJump: boolean;
  wallhack: boolean;
  rapidFire: boolean;
  aimAssist: boolean;
}

export interface Save {
  name: string;
  coins: number;
  xp: number;
  kills: number;
  deaths: number;
  headshots: number;
  matches: number;
  wins: number;
  owned: string[];
  primary: string;
  secondary: string;
  skins: Record<string, SkinColors>;
  settings: Settings;
  mods: Mods;
}

export const DEFAULT_SKIN: SkinColors = { c1: '#3a3d42', c2: '#1c1d20', c3: '#5a4632', metal: false, pattern: 'solid' };

const defaultSave = (): Save => ({
  name: 'سرباز',
  coins: 1500,
  xp: 0,
  kills: 0,
  deaths: 0,
  headshots: 0,
  matches: 0,
  wins: 0,
  owned: ['knife', 'glock', 'usp', 'mp5', 'ak47', 'nova', 'he'],
  primary: 'ak47',
  secondary: 'glock',
  skins: {
    ak47: { c1: '#1d7fe0', c2: '#f08a1c', c3: '#2a2a2a', metal: false, pattern: 'tiger' },
  },
  settings: {
    sens: 1,
    quality: 'med',
    volume: 0.8,
    difficulty: 'normal',
    bots: 9,
    fov: 75,
    showFps: false,
    leftFire: true,
    btnScale: 1,
  },
  mods: {
    code1: false, code2: false, code3: false,
    infMoney: false, allUnlocked: false, god: false, infAmmo: false, noReload: false,
    oneShot: false, noRecoil: false, speed: false, highJump: false, wallhack: false, rapidFire: false, aimAssist: false,
  },
});

const KEY = 'zedteror_save_v1';

function load(): Save {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultSave();
    const d = defaultSave();
    const p = JSON.parse(raw);
    return { ...d, ...p, settings: { ...d.settings, ...(p.settings || {}) }, mods: { ...d.mods, ...(p.mods || {}) }, skins: { ...d.skins, ...(p.skins || {}) } };
  } catch {
    return defaultSave();
  }
}

let state: Save = load();
const listeners = new Set<() => void>();

export function getSave() { return state; }

export function setSave(fn: (s: Save) => Save) {
  state = fn(state);
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* ignore */ }
  listeners.forEach(l => l());
}

export function useSave(): Save {
  return useSyncExternalStore(
    (cb) => { listeners.add(cb); return () => listeners.delete(cb); },
    () => state,
  );
}

export function resetSave() {
  setSave(() => defaultSave());
}

/* ---------------- CHEAT CODES ---------------- */
export interface CodeInfo {
  code: string;
  key: 'code1' | 'code2' | 'code3';
  title: string;
  desc: string[];
  color: string;
}

export const CODES: CodeInfo[] = [
  {
    code: '139113', key: 'code1', title: 'پکیج ثروت بی‌پایان', color: '#ffd000',
    desc: ['۹۹۹٬۹۹۹ سکه', 'باز شدن همه اسلحه‌ها و اسکین‌ها', 'پول نامحدود داخل بازی ($)'],
  },
  {
    code: '139114', key: 'code2', title: 'پکیج نامیرایی', color: '#22d3ee',
    desc: ['جان بی‌نهایت (God Mode)', 'مهمات بی‌نهایت', 'بدون نیاز به خشاب‌گذاری'],
  },
  {
    code: '139115', key: 'code3', title: 'پکیج قدرت مطلق', color: '#ef4444',
    desc: ['کشتن با یک تیر', 'بدون لگد و پخش گلوله', 'سرعت ۲ برابر + پرش بلند', 'دید از پشت دیوار (Wallhack)', 'شلیک سریع + کمک نشانه‌گیری'],
  },
];

export function redeemCode(code: string): CodeInfo | null | 'used' {
  const c = CODES.find(x => x.code === code.trim());
  if (!c) return null;
  if (state.mods[c.key]) return 'used';
  setSave(s => {
    const mods = { ...s.mods, [c.key]: true };
    let coins = s.coins;
    if (c.key === 'code1') { mods.infMoney = true; mods.allUnlocked = true; coins = 999999; }
    if (c.key === 'code2') { mods.god = true; mods.infAmmo = true; mods.noReload = true; }
    if (c.key === 'code3') {
      mods.oneShot = true; mods.noRecoil = true; mods.speed = true; mods.highJump = true;
      mods.wallhack = true; mods.rapidFire = true; mods.aimAssist = true;
    }
    return { ...s, mods, coins };
  });
  return c;
}

export function isFullMod(m: Mods) { return m.code1 && m.code2 && m.code3; }

export function levelFromXp(xp: number) {
  let lvl = 1; let need = 500; let x = xp;
  while (x >= need) { x -= need; lvl++; need = Math.floor(need * 1.15); }
  return { lvl, cur: x, need };
}

export const fa = (n: number | string) => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[+d]);
export const faNum = (n: number) => fa(Math.round(n).toLocaleString('en-US').replace(/,/g, '٬'));
