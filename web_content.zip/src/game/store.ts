import { useSyncExternalStore } from "react";

export type Phase =
  | "menu"
  | "countdown"
  | "playing"
  | "crashed"
  | "gameover";

export interface GameState {
  phase: Phase;
  /** speed in km/h */
  speed: number;
  score: number;
  best: number;
  /** distance in meters */
  distance: number;
  /** 0..100 */
  nitro: number;
  pickups: number;
  boosting: boolean;
  /** countdown number shown in the middle of the screen */
  countdown: number;
  toast: { text: string; id: number } | null;
}

const BEST_KEY = "neon-drive-best";

function loadBest(): number {
  try {
    return Number(localStorage.getItem(BEST_KEY)) || 0;
  } catch {
    return 0;
  }
}

let state: GameState = {
  phase: "menu",
  speed: 0,
  score: 0,
  best: loadBest(),
  distance: 0,
  nitro: 100,
  pickups: 0,
  boosting: false,
  countdown: 3,
  toast: null,
};

const listeners = new Set<() => void>();

export function getState(): GameState {
  return state;
}

export function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function setState(patch: Partial<GameState>) {
  const next = { ...state, ...patch };
  let changed = false;
  for (const key of Object.keys(next) as (keyof GameState)[]) {
    if (next[key] !== state[key]) {
      changed = true;
      break;
    }
  }
  if (!changed) return;
  state = next;
  listeners.forEach((l) => l());
}

export function saveBest(score: number) {
  if (score > state.best) {
    try {
      localStorage.setItem(BEST_KEY, String(score));
    } catch {
      /* ignore */
    }
    setState({ best: score });
  }
}

let toastId = 0;

export function showToast(text: string) {
  toastId += 1;
  setState({ toast: { text, id: toastId } });
}

export function useGame(): GameState {
  return useSyncExternalStore(subscribe, getState, getState);
}
