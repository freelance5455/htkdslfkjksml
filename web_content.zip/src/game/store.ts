import { create } from "zustand";
import type { SpeciesId } from "./data";

export type Menu = null | "party" | "build" | "codex" | "help";

type HudState = {
  rev: number;
  rosterRev: number;
  menu: Menu;
  preview: SpeciesId;
  bump: () => void;
  bumpRoster: () => void;
  setMenu: (menu: Menu) => void;
  setPreview: (id: SpeciesId) => void;
};

export const useHud = create<HudState>((set) => ({
  rev: 0,
  rosterRev: 0,
  menu: null,
  preview: "sproutkit",
  bump: () => set((s) => ({ rev: s.rev + 1 })),
  bumpRoster: () => set((s) => ({ rosterRev: s.rosterRev + 1, rev: s.rev + 1 })),
  setMenu: (menu) => set({ menu }),
  setPreview: (preview) => set({ preview }),
}));
