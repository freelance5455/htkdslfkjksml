import {
  Civilization,
  CivilizationId,
  BuildingType,
  BuildingInfo,
  TechType,
  TechInfo,
  UnitType,
  UnitInfo,
  Kingdom,
  Resources,
  ResourceRates,
  Territory,
  Challenge,
  TacticalFormation,
  EquipmentType,
  EquipmentInfo,
  PopulationHistoryPoint,
} from '../types/kingdom';

export const CIVILIZATIONS: Record<CivilizationId, Civilization> = {
  iberos: {
    id: 'iberos',
    name: 'Íberos',
    motto: 'Honor, resistencia y filo de falcata',
    description:
      'Guerreros indómitos y maestros de la metalurgia hispana. Su infantería ligera y extracción de piedra y oro son legendarias.',
    leaderTitle: 'Caudillo',
    bonuses: {
      foodBonus: 0.05,
      woodBonus: 0.05,
      stoneBonus: 0.15,
      goldBonus: 0.15,
      infantryBonus: 0.15,
      archerBonus: 0.05,
      cavalryBonus: 0.05,
      defenseBonus: 0.1,
    },
    color: '#b45309',
    badge: '🗡️',
  },
  romanos: {
    id: 'romanos',
    name: 'Romanos',
    motto: 'Disciplina, ingeniería y gloria eterna',
    description:
      'Pioneros de la arquitectura monumental, la recaudación imperial y la infantería pesada más disciplinada de la historia.',
    leaderTitle: 'Legado Imperial',
    bonuses: {
      foodBonus: 0.05,
      woodBonus: 0.05,
      stoneBonus: 0.2,
      goldBonus: 0.2,
      infantryBonus: 0.1,
      archerBonus: 0.05,
      cavalryBonus: 0.05,
      defenseBonus: 0.15,
    },
    color: '#b91c1c',
    badge: '🦅',
  },
  godos: {
    id: 'godos',
    name: 'Visigodos',
    motto: 'Furia de hierro y linaje de reyes',
    description:
      'Herederos de la fuerza bélica germánica. Sus herreros producen armas temibles y su caballería e infantería de choque infunden pavor.',
    leaderTitle: 'Rey Guerrero',
    bonuses: {
      foodBonus: 0.1,
      woodBonus: 0.15,
      stoneBonus: 0.05,
      goldBonus: 0.05,
      infantryBonus: 0.2,
      archerBonus: 0.05,
      cavalryBonus: 0.15,
      defenseBonus: 0.05,
    },
    color: '#4338ca',
    badge: '⚔️',
  },
  celtas: {
    id: 'celtas',
    name: 'Celtas',
    motto: 'Espíritu de los bosques y lluvia de flechas',
    description:
      'Hermanados con la naturaleza y los bosques antiguos. Expertos arqueros, agricultores prósperos y maestros de la madera.',
    leaderTitle: 'Archidruida',
    bonuses: {
      foodBonus: 0.2,
      woodBonus: 0.2,
      stoneBonus: 0.05,
      goldBonus: 0.05,
      infantryBonus: 0.05,
      archerBonus: 0.2,
      cavalryBonus: 0.05,
      defenseBonus: 0.1,
    },
    color: '#15803d',
    badge: '🏹',
  },
};

export const BUILDINGS_CONFIG: Record<BuildingType, BuildingInfo> = {
  townHall: {
    type: 'townHall',
    name: 'Castillo y Ayuntamiento',
    description: 'Sede del gobierno del reino. Aumenta la velocidad de construcción general y desbloquea nuevos edificios.',
    category: 'civic',
    icon: 'Castle',
    baseCost: { food: 150, wood: 180, stone: 200, gold: 100 },
    costMultiplier: 1.45,
    baseTimeSeconds: 45,
    timeMultiplier: 1.35,
    effectDescription: (lvl) => `Velocidad de construcción +${lvl * 5}%. Nivel máximo de aldea: ${lvl}`,
  },
  farm: {
    type: 'farm',
    name: 'Campos de Cultivo',
    description: 'Tierras fértiles donde se cultivan cereales para alimentar a la población y sustentar a los ejércitos.',
    category: 'resources',
    icon: 'Wheat',
    baseCost: { food: 40, wood: 60, stone: 30, gold: 15 },
    costMultiplier: 1.32,
    baseTimeSeconds: 20,
    timeMultiplier: 1.25,
    effectDescription: (lvl) => `Producción base: +${lvl * 120} comida/hora`,
  },
  lumberMill: {
    type: 'lumberMill',
    name: 'Aserradero y Bosques',
    description: 'Explotación forestal que provee vigas, leña y madera indispensable para toda edificación y flechas.',
    category: 'resources',
    icon: 'Trees',
    baseCost: { food: 50, wood: 40, stone: 40, gold: 15 },
    costMultiplier: 1.32,
    baseTimeSeconds: 20,
    timeMultiplier: 1.25,
    effectDescription: (lvl) => `Producción base: +${lvl * 110} madera/hora`,
  },
  quarry: {
    type: 'quarry',
    name: 'Cantera de Piedra',
    description: 'Extracción de bloques de sillar para levantar murallas inexpugnables y fortificaciones sólidas.',
    category: 'resources',
    icon: 'Mountain',
    baseCost: { food: 60, wood: 70, stone: 30, gold: 20 },
    costMultiplier: 1.35,
    baseTimeSeconds: 25,
    timeMultiplier: 1.28,
    effectDescription: (lvl) => `Producción base: +${lvl * 95} piedra/hora`,
  },
  goldMine: {
    type: 'goldMine',
    name: 'Mina de Oro',
    description: 'Yacimiento metalífero que llena las arcas reales con lingotes para financiar investigaciones y tropas.',
    category: 'resources',
    icon: 'Coins',
    baseCost: { food: 80, wood: 90, stone: 100, gold: 40 },
    costMultiplier: 1.4,
    baseTimeSeconds: 35,
    timeMultiplier: 1.3,
    effectDescription: (lvl) => `Producción base: +${lvl * 80} oro/hora`,
  },
  warehouse: {
    type: 'warehouse',
    name: 'Almacén Central',
    description: 'Grandes bodegas protegidas para resguardar la madera, la piedra y el oro de la intemperie y saqueos.',
    category: 'infrastructure',
    icon: 'Warehouse',
    baseCost: { food: 70, wood: 100, stone: 80, gold: 30 },
    costMultiplier: 1.35,
    baseTimeSeconds: 30,
    timeMultiplier: 1.25,
    effectDescription: (lvl) => `Capacidad de almacenamiento: ${(lvl + 1) * 3500} recursos`,
  },
  granary: {
    type: 'granary',
    name: 'Granero Real',
    description: 'Silos sellados que impiden la putrefacción del grano, asegurando el sustento en tiempos de asedio.',
    category: 'infrastructure',
    icon: 'Container',
    baseCost: { food: 60, wood: 80, stone: 60, gold: 20 },
    costMultiplier: 1.35,
    baseTimeSeconds: 25,
    timeMultiplier: 1.25,
    effectDescription: (lvl) => `Capacidad de grano: ${(lvl + 1) * 4000} comida`,
  },
  barracks: {
    type: 'barracks',
    name: 'Cuartel Militar',
    description: 'Campo de maniobras y armería donde los aldeanos son instruidos en el arte de la espada y el arco.',
    category: 'military',
    icon: 'Shield',
    baseCost: { food: 120, wood: 140, stone: 100, gold: 60 },
    costMultiplier: 1.38,
    baseTimeSeconds: 40,
    timeMultiplier: 1.3,
    effectDescription: (lvl) => `Velocidad de entrenamiento militar +${lvl * 8}%`,
  },
  university: {
    type: 'university',
    name: 'Universidad y Biblioteca',
    description: 'Centro de sabios, filósofos e ingenieros. Investiga avances científicos, tácticos y económicos.',
    category: 'civic',
    icon: 'GraduationCap',
    baseCost: { food: 150, wood: 160, stone: 150, gold: 120 },
    costMultiplier: 1.42,
    baseTimeSeconds: 50,
    timeMultiplier: 1.32,
    effectDescription: (lvl) => `Desbloquea tecnologías avanzadas y acelera investigaciones un +${lvl * 6}%`,
  },
  wall: {
    type: 'wall',
    name: 'Muralla Defensiva',
    description: 'Cinturón de piedra con aspilleras y fosos que protege la aldea frente a invasores y saqueadores.',
    category: 'military',
    icon: 'BrickWall',
    baseCost: { food: 40, wood: 110, stone: 180, gold: 50 },
    costMultiplier: 1.4,
    baseTimeSeconds: 35,
    timeMultiplier: 1.3,
    effectDescription: (lvl) => `Bonificación defensiva de la guarnición: +${lvl * 10}%`,
  },
  parliament: {
    type: 'parliament',
    name: 'Parlamento del Reino',
    description: 'Cámara de nobles y emisarios. Gestiona diplomacia, tratados de paz, títulos nobiliarios y gloria.',
    category: 'civic',
    icon: 'Crown',
    baseCost: { food: 180, wood: 200, stone: 220, gold: 180 },
    costMultiplier: 1.5,
    baseTimeSeconds: 60,
    timeMultiplier: 1.35,
    effectDescription: (lvl) => `Generación de Puntos de Gloria: +${lvl * 5}/día y bonificación de lealtad`,
  },
  tavern: {
    type: 'tavern',
    name: 'Taberna y Puesto de Espionaje',
    description: 'Punto de encuentro de viajeros, juglares y mercenarios. Permite reclutar espías y contratar mercenarios.',
    category: 'military',
    icon: 'Beer',
    baseCost: { food: 90, wood: 100, stone: 70, gold: 80 },
    costMultiplier: 1.35,
    baseTimeSeconds: 30,
    timeMultiplier: 1.25,
    effectDescription: (lvl) => `Detección de espías enemigos +${lvl * 7}% y oferta de mercenarios`,
  },
  hospital: {
    type: 'hospital',
    name: 'Hospital de Campaña y Botica',
    description: 'Pabellones sanitarios atendidos por médicos y boticarios para acoger a las tropas caídas en combate, curarlas y devolverlas al servicio.',
    category: 'military',
    icon: 'HeartPulse',
    baseCost: { food: 110, wood: 130, stone: 110, gold: 90 },
    costMultiplier: 1.38,
    baseTimeSeconds: 40,
    timeMultiplier: 1.3,
    effectDescription: (lvl) => `Capacidad: ${lvl * 60} camas para heridos. Rescata hasta un ${15 + lvl * 5}% de soldados caídos como convalecientes.`,
  },
  houses: {
    type: 'houses',
    name: 'Casas y Chozas del Pueblo',
    description: 'Viviendas familiares, cobertizos y barriadas comunales. Elevan el límite máximo de población del reino y aceleran la llegada y natalidad de nuevos aldeanos.',
    category: 'infrastructure',
    icon: 'Home',
    baseCost: { food: 50, wood: 70, stone: 40, gold: 20 },
    costMultiplier: 1.30,
    baseTimeSeconds: 20,
    timeMultiplier: 1.25,
    effectDescription: (lvl) => `Capacidad de población: +${lvl * 120} habitantes. Crecimiento demográfico: +${lvl * 12} colonos/hora`,
  },
};

export const TECHNOLOGIES_CONFIG: Record<TechType, TechInfo> = {
  cropRotation: {
    type: 'cropRotation',
    name: 'Rotación Trienal de Cultivos',
    branch: 'economy',
    description: 'Mejora el rendimiento de la tierra alternando leguminosas y barbecho.',
    baseCost: { food: 120, wood: 80, stone: 60, gold: 50 },
    costMultiplier: 1.4,
    baseTimeSeconds: 40,
    effectDescription: (lvl) => `Producción de comida +${lvl * 8}%`,
  },
  ironAxes: {
    type: 'ironAxes',
    name: 'Hachas de Hierro Templado',
    branch: 'economy',
    description: 'Herramientas más duraderas que optimizan la tala y el desbroce.',
    baseCost: { food: 80, wood: 140, stone: 70, gold: 60 },
    costMultiplier: 1.4,
    baseTimeSeconds: 40,
    effectDescription: (lvl) => `Producción de madera +${lvl * 8}%`,
  },
  deepQuarry: {
    type: 'deepQuarry',
    name: 'Técnicas de Cantería Subterránea',
    branch: 'economy',
    description: 'Poleas y calces de hierro para extraer bloques de roca sin resquebrajaduras.',
    baseCost: { food: 90, wood: 100, stone: 150, gold: 70 },
    costMultiplier: 1.4,
    baseTimeSeconds: 45,
    effectDescription: (lvl) => `Producción de piedra +${lvl * 8}%`,
  },
  coinage: {
    type: 'coinage',
    name: 'Acuñación y Comercio Real',
    branch: 'economy',
    description: 'Estandarización de la moneda de oro y control aduanero en ferias locales.',
    baseCost: { food: 100, wood: 120, stone: 120, gold: 180 },
    costMultiplier: 1.45,
    baseTimeSeconds: 50,
    effectDescription: (lvl) => `Ingresos de oro e impuestos +${lvl * 10}%`,
  },
  ironArmor: {
    type: 'ironArmor',
    name: 'Cota de Malla y Escudos Remachados',
    branch: 'military',
    description: 'Protección metálica que reduce el daño recibido por la infantería.',
    baseCost: { food: 140, wood: 90, stone: 160, gold: 120 },
    costMultiplier: 1.42,
    baseTimeSeconds: 60,
    effectDescription: (lvl) => `Defensa de toda la infantería +${lvl * 7}%`,
  },
  compositeBow: {
    type: 'compositeBow',
    name: 'Arcos Compuestos Reforzados',
    branch: 'military',
    description: 'Arcos laminados de madera, cuerno y tendones con mayor alcance y poder de penetración.',
    baseCost: { food: 110, wood: 190, stone: 80, gold: 110 },
    costMultiplier: 1.42,
    baseTimeSeconds: 55,
    effectDescription: (lvl) => `Ataque de unidades a distancia +${lvl * 8}%`,
  },
  horseBreeding: {
    type: 'horseBreeding',
    name: 'Cría de Corceles de Guerra',
    branch: 'military',
    description: 'Caballos seleccionados por su resistencia, velocidad y bravura en combate.',
    baseCost: { food: 220, wood: 140, stone: 90, gold: 170 },
    costMultiplier: 1.45,
    baseTimeSeconds: 70,
    effectDescription: (lvl) => `Velocidad y carga de caballería +${lvl * 8}%`,
  },
  siegeEngines: {
    type: 'siegeEngines',
    name: 'Torsión y Maquinaria de Asedio',
    branch: 'military',
    description: 'Mecanismos de palanca, contrapesos y cuerdas de crin para demoler bastiones enemigos.',
    baseCost: { food: 150, wood: 240, stone: 200, gold: 200 },
    costMultiplier: 1.5,
    baseTimeSeconds: 80,
    effectDescription: (lvl) => `Daño contra murallas y defensas +${lvl * 12}%`,
  },
  espionageNetwork: {
    type: 'espionageNetwork',
    name: 'Red Secreta de Informantes',
    branch: 'defense',
    description: 'Oídos y ojos en los caminos, tabernas y cortes de los reinos vecinos.',
    baseCost: { food: 100, wood: 100, stone: 80, gold: 220 },
    costMultiplier: 1.45,
    baseTimeSeconds: 65,
    effectDescription: (lvl) => `Probabilidad de éxito en misiones de espionaje +${lvl * 9}%`,
  },
  stoneFortification: {
    type: 'stoneFortification',
    name: 'Almenas, Matacanes y Fosos',
    branch: 'defense',
    description: 'Arquitectura militar para resistir asedios prolongados y lluvia de proyectiles.',
    baseCost: { food: 90, wood: 180, stone: 260, gold: 140 },
    costMultiplier: 1.45,
    baseTimeSeconds: 75,
    effectDescription: (lvl) => `Resistencia general del castillo y murallas +${lvl * 10}%`,
  },
  medicinalHerbs: {
    type: 'medicinalHerbs',
    name: 'Herboristería Medicinal y Elixires',
    branch: 'medicine',
    description: 'Bálsamos de árnica, beleño y aguardiente de romero aplicados en primera línea para cauterizar heridas y evitar que los soldados caídos perezcan.',
    baseCost: { food: 120, wood: 90, stone: 70, gold: 110 },
    costMultiplier: 1.4,
    baseTimeSeconds: 45,
    effectDescription: (lvl) => `+${lvl * 4}% de soldados caídos que son evacuados heridos en lugar de morir`,
  },
  fieldSurgery: {
    type: 'fieldSurgery',
    name: 'Cirugía de Campaña y Torniquetes',
    branch: 'medicine',
    description: 'Pinzas de extracción, torniquetes y apósitos limpios que aceleran y abaratan la curación y reincorporación de los soldados convalecientes.',
    baseCost: { food: 140, wood: 100, stone: 90, gold: 150 },
    costMultiplier: 1.42,
    baseTimeSeconds: 50,
    effectDescription: (lvl) => `Reduce el coste de recursos y suministros para sanar heridos un -${lvl * 6}%`,
  },
  battlefieldSanitation: {
    type: 'battlefieldSanitation',
    name: 'Higiene y Lazareto de Guerra',
    branch: 'medicine',
    description: 'Hervido de vendas de lino, desinfección con vinagre y ordenamiento de camillas que expande la capacidad hospitalaria del feudo.',
    baseCost: { food: 130, wood: 120, stone: 100, gold: 130 },
    costMultiplier: 1.4,
    baseTimeSeconds: 50,
    effectDescription: (lvl) => `+${lvl * 15}% de camas disponibles en el Hospital de Campaña`,
  },
};

export const UNITS_CONFIG: Record<UnitType, UnitInfo> = {
  militia: {
    type: 'militia',
    name: 'Miliciano con Lanza',
    category: 'infantry',
    description: 'Tropas reclutadas entre los campesinos. Fáciles y rápidas de armar, efectivas en masa.',
    attack: 14,
    defense: 18,
    speed: 12,
    lootCapacity: 25,
    cost: { food: 35, wood: 25, stone: 10, gold: 5 },
    trainingTimeSeconds: 10,
    upkeepFoodPerHour: 3,
    requiredBuildingLevel: { building: 'barracks', level: 1 },
  },
  swordsman: {
    type: 'swordsman',
    name: 'Espadachín de Vanguardia',
    category: 'infantry',
    description: 'Soldado profesional protegido con cota de escamas y escudo ancho.',
    attack: 32,
    defense: 30,
    speed: 10,
    lootCapacity: 40,
    cost: { food: 65, wood: 35, stone: 30, gold: 25 },
    trainingTimeSeconds: 22,
    upkeepFoodPerHour: 6,
    requiredBuildingLevel: { building: 'barracks', level: 2 },
  },
  archer: {
    type: 'archer',
    name: 'Arquero de Tiro Largo',
    category: 'ranged',
    description: 'Tiradores capaces de oscurecer el cielo con lluvia de saetas antes del choque frontal.',
    attack: 38,
    defense: 14,
    speed: 14,
    lootCapacity: 20,
    cost: { food: 50, wood: 70, stone: 15, gold: 20 },
    trainingTimeSeconds: 20,
    upkeepFoodPerHour: 5,
    requiredBuildingLevel: { building: 'barracks', level: 2 },
  },
  crossbowman: {
    type: 'crossbowman',
    name: 'Ballestero Acorazado',
    category: 'ranged',
    description: 'Disparan virotes de acero capaces de perforar corazas pesadas y escudos de roble.',
    attack: 52,
    defense: 26,
    speed: 9,
    lootCapacity: 30,
    cost: { food: 75, wood: 90, stone: 45, gold: 40 },
    trainingTimeSeconds: 32,
    upkeepFoodPerHour: 8,
    requiredBuildingLevel: { building: 'barracks', level: 4 },
  },
  lightCavalry: {
    type: 'lightCavalry',
    name: 'Jinete Explorador',
    category: 'cavalry',
    description: 'Jinetes ligeros para incursiones rápidas, exploración y persecución de tropas dispersas.',
    attack: 42,
    defense: 24,
    speed: 24,
    lootCapacity: 80,
    cost: { food: 120, wood: 60, stone: 30, gold: 50 },
    trainingTimeSeconds: 35,
    upkeepFoodPerHour: 10,
    requiredBuildingLevel: { building: 'barracks', level: 3 },
  },
  knight: {
    type: 'knight',
    name: 'Caballero Pesado',
    category: 'cavalry',
    description: 'La flor y nata de la nobleza guerrera montada. Devastadora carga con lanza de torneo.',
    attack: 85,
    defense: 70,
    speed: 18,
    lootCapacity: 110,
    cost: { food: 220, wood: 110, stone: 90, gold: 140 },
    trainingTimeSeconds: 60,
    upkeepFoodPerHour: 18,
    requiredBuildingLevel: { building: 'barracks', level: 5 },
  },
  batteringRam: {
    type: 'batteringRam',
    name: 'Ariete de Asalto',
    category: 'siege',
    description: 'Viga de roble protegida por techumbre contra fuego, ideal para derrumbar portones.',
    attack: 110,
    defense: 120,
    speed: 6,
    lootCapacity: 0,
    cost: { food: 100, wood: 300, stone: 150, gold: 80 },
    trainingTimeSeconds: 75,
    upkeepFoodPerHour: 12,
    requiredBuildingLevel: { building: 'barracks', level: 4 },
  },
  catapult: {
    type: 'catapult',
    name: 'Catapulta de Asedio',
    category: 'siege',
    description: 'Lanza proyectiles ígneos y peñascos para desmoronar murallas a distancia de seguridad.',
    attack: 160,
    defense: 50,
    speed: 5,
    lootCapacity: 0,
    cost: { food: 150, wood: 420, stone: 350, gold: 180 },
    trainingTimeSeconds: 100,
    upkeepFoodPerHour: 20,
    requiredBuildingLevel: { building: 'barracks', level: 6 },
  },
  spy: {
    type: 'spy',
    name: 'Espía Silencioso',
    category: 'covert',
    description: 'Maestros del disfraz y la noche. Se infiltran para descubrir tropas, fortines y recursos rivales.',
    attack: 10,
    defense: 10,
    speed: 28,
    lootCapacity: 10,
    cost: { food: 50, wood: 40, stone: 20, gold: 120 },
    trainingTimeSeconds: 25,
    upkeepFoodPerHour: 7,
    requiredBuildingLevel: { building: 'tavern', level: 1 },
  },
};

export const INITIAL_CHALLENGES: Challenge[] = [
  {
    id: 'ch_first_farm',
    title: 'Asegurar la Cosecha',
    description: 'Mejora los Campos de Cultivo al nivel 2 para garantizar el sustento.',
    category: 'construction',
    targetValue: 2,
    currentValue: 1,
    rewardGlory: 50,
    rewardResources: { food: 300, wood: 200, gold: 100 },
    isCompleted: false,
    isClaimed: false,
  },
  {
    id: 'ch_build_houses',
    title: 'Hogares del Feudo',
    description: 'Mejora las Casas y Chozas al nivel 2 para aumentar la capacidad de población y atraer colonos.',
    category: 'construction',
    targetValue: 2,
    currentValue: 1,
    rewardGlory: 60,
    rewardResources: { food: 250, wood: 300, stone: 200, gold: 100 },
    isCompleted: false,
    isClaimed: false,
  },
  {
    id: 'ch_first_barracks',
    title: 'Grito de Armas',
    description: 'Construye y eleva el Cuartel Militar al nivel 2 para entrenar soldados de vanguardia.',
    category: 'military',
    targetValue: 2,
    currentValue: 1,
    rewardGlory: 75,
    rewardResources: { stone: 250, wood: 250, gold: 150 },
    isCompleted: false,
    isClaimed: false,
  },
  {
    id: 'ch_train_army',
    title: 'Guardia del Castillo',
    description: 'Recluta al menos 20 soldados en tu ejército.',
    category: 'military',
    targetValue: 20,
    currentValue: 0,
    rewardGlory: 100,
    rewardResources: { food: 500, gold: 300 },
    isCompleted: false,
    isClaimed: false,
  },
  {
    id: 'ch_first_tech',
    title: 'La Luz del Saber',
    description: 'Investiga al menos una tecnología en la Universidad.',
    category: 'economy',
    targetValue: 1,
    currentValue: 0,
    rewardGlory: 80,
    rewardResources: { wood: 300, stone: 300, gold: 200 },
    isCompleted: false,
    isClaimed: false,
  },
  {
    id: 'ch_conquer_territory',
    title: 'Primera Conquista',
    description: 'Lanza una expedición victoriosa sobre un territorio rebelde en el Mapa.',
    category: 'expansion',
    targetValue: 1,
    currentValue: 0,
    rewardGlory: 150,
    rewardResources: { food: 800, wood: 800, stone: 800, gold: 500 },
    isCompleted: false,
    isClaimed: false,
  },
];

export const INITIAL_TERRITORIES: Territory[] = [
  {
    id: 'ter_1',
    name: 'Valle de los Robles Viejos',
    x: 4,
    y: 3,
    zone: 'Frontera Norte',
    type: 'barbarian',
    defenseLevel: 1,
    garrison: { militia: 15, archer: 8 },
    loot: { food: 500, wood: 650, stone: 200, gold: 150 },
    gloryReward: 60,
    isConquered: false,
    description: 'Bandas de forajidos hostigan a los leñadores en este bosque denso.',
  },
  {
    id: 'ter_2',
    name: 'Ruinas de Calatrava',
    x: 6,
    y: 2,
    zone: 'Tierras Altas',
    type: 'abandoned',
    defenseLevel: 2,
    garrison: { swordsman: 20, crossbowman: 12 },
    loot: { food: 400, wood: 300, stone: 800, gold: 350 },
    gloryReward: 90,
    isConquered: false,
    description: 'Un antiguo fortín visigodo abandonado con ricas canteras de sillar.',
  },
  {
    id: 'ter_3',
    name: 'Minas de Sierra Morena',
    x: 3,
    y: 6,
    zone: 'Cordillera Sur',
    type: 'resource_sanctuary',
    defenseLevel: 3,
    garrison: { swordsman: 30, archer: 25, lightCavalry: 10 },
    loot: { food: 600, wood: 500, stone: 600, gold: 1200 },
    gloryReward: 140,
    isConquered: false,
    description: 'Un enclave minero rebosante de filones de oro custodiado por mercenarios.',
  },
  {
    id: 'ter_4',
    name: 'Fortaleza del Paso del Águila',
    x: 7,
    y: 5,
    zone: 'Paso Estratégico',
    type: 'kingdom',
    defenseLevel: 4,
    garrison: { swordsman: 45, crossbowman: 35, knight: 15, batteringRam: 2 },
    loot: { food: 1200, wood: 1000, stone: 1400, gold: 900 },
    gloryReward: 220,
    isConquered: false,
    ownerName: 'Barón Roderico de Montefrío',
    description: 'Un señor feudal rebelde que exige peaje a todas las caravanas reales.',
  },
  {
    id: 'ter_5',
    name: 'Bastión Negro de Al-Ándalus',
    x: 8,
    y: 8,
    zone: 'Tierras Profundas',
    type: 'kingdom',
    defenseLevel: 5,
    garrison: { swordsman: 80, archer: 60, knight: 35, catapult: 3 },
    loot: { food: 2500, wood: 2000, stone: 2500, gold: 3000 },
    gloryReward: 450,
    isConquered: false,
    ownerName: 'Gran Emir Al-Mansur',
    description: 'La gran plaza fuerte que domina toda la comarca meridional.',
  },
];

export function getBuildingUpgradeCost(type: BuildingType, currentLevel: number): Resources {
  const cfg = BUILDINGS_CONFIG[type];
  const mult = Math.pow(cfg.costMultiplier, currentLevel);
  return {
    food: Math.round(cfg.baseCost.food * mult),
    wood: Math.round(cfg.baseCost.wood * mult),
    stone: Math.round(cfg.baseCost.stone * mult),
    gold: Math.round(cfg.baseCost.gold * mult),
  };
}

export function getBuildingUpgradeTimeSeconds(type: BuildingType, currentLevel: number, townHallLevel: number): number {
  const cfg = BUILDINGS_CONFIG[type];
  const mult = Math.pow(cfg.timeMultiplier, currentLevel);
  const base = cfg.baseTimeSeconds * mult;
  const reduction = 1 / (1 + (townHallLevel - 1) * 0.05);
  return Math.max(5, Math.round(base * reduction));
}

export function getTechUpgradeCost(type: TechType, currentLevel: number): Resources {
  const cfg = TECHNOLOGIES_CONFIG[type];
  const mult = Math.pow(cfg.costMultiplier, currentLevel);
  return {
    food: Math.round(cfg.baseCost.food * mult),
    wood: Math.round(cfg.baseCost.wood * mult),
    stone: Math.round(cfg.baseCost.stone * mult),
    gold: Math.round(cfg.baseCost.gold * mult),
  };
}

export function getTechUpgradeTimeSeconds(type: TechType, currentLevel: number, universityLevel: number): number {
  const cfg = TECHNOLOGIES_CONFIG[type];
  const mult = Math.pow(1.3, currentLevel);
  const base = cfg.baseTimeSeconds * mult;
  const reduction = 1 / (1 + universityLevel * 0.06);
  return Math.max(10, Math.round(base * reduction));
}

export function getMaxStorageCapacity(warehouseLevel: number, granaryLevel: number): { resourcesMax: number; foodMax: number } {
  const resourcesMax = (warehouseLevel + 1) * 3500;
  const foodMax = (granaryLevel + 1) * 4000;
  return { resourcesMax, foodMax };
}

export function getKingdomMaxPopulation(kingdom: Kingdom): number {
  const townHallLvl = kingdom.buildings?.townHall || 1;
  const housesLvl = kingdom.buildings?.houses || 0;
  const granaryLvl = kingdom.buildings?.granary || 1;
  // Town hall provides 150 base + 50 per level
  // Houses provide 120 per level
  // Granary provides 30 per level
  return 150 + townHallLvl * 50 + housesLvl * 120 + granaryLvl * 30;
}

export function getDemographicGrowthRate(kingdom: Kingdom): {
  growthPerHour: number;
  happiness: number;
  isAtCap: boolean;
  maxPopulation: number;
  statusText: string;
} {
  const maxPop = getKingdomMaxPopulation(kingdom);
  const currentPop = kingdom.population || 0;
  const isAtCap = currentPop >= maxPop;

  // Happiness calculation (0 - 100)
  let happiness = 80 - ((kingdom.taxRate || 10) * 0.5);
  if (kingdom.foodLevel === 'feast') happiness += 15;
  else if (kingdom.foodLevel === 'generous') happiness += 8;
  else if (kingdom.foodLevel === 'scant') happiness -= 20;
  happiness = Math.max(10, Math.min(100, Math.round(happiness)));

  // If no food in stock, population cannot grow (famine)
  if ((kingdom.resources?.food || 0) <= 5) {
    return {
      growthPerHour: 0,
      happiness,
      isAtCap: false,
      maxPopulation: maxPop,
      statusText: 'Hambre y desabastecimiento (crecimiento paralizado)',
    };
  }

  if (isAtCap) {
    return {
      growthPerHour: 0,
      happiness,
      isAtCap: true,
      maxPopulation: maxPop,
      statusText: 'Capacidad residencial colmada (amplía Casas y Chozas)',
    };
  }

  // Base growth from settlement and houses
  const housesLvl = kingdom.buildings?.houses || 0;
  const baseGrowth = 8 + housesLvl * 10; // e.g. 18/h at lvl 1; 28/h at lvl 2

  // Happiness multiplier: 55% happiness is 1.0x, 90% is 1.63x, 30% is 0.54x
  const happinessMultiplier = Math.max(0.3, happiness / 55);

  // Civilization bonus: Celtas have +15% demographic fertility
  const civBonus = kingdom.civilization === 'celtas' ? 1.15 : 1.0;

  const finalRate = Math.max(1, Math.round(baseGrowth * happinessMultiplier * civBonus));

  return {
    growthPerHour: finalRate,
    happiness,
    isAtCap: false,
    maxPopulation: maxPop,
    statusText: `+${finalRate} habitantes/hora`,
  };
}

export function getKingdomPopulationHistory(kingdom: Kingdom, monthsCount: number = 6): PopulationHistoryPoint[] {
  const currentPop = Math.floor(kingdom.population || 0);
  const currentCap = getKingdomMaxPopulation(kingdom);
  const currentMil = Object.values(kingdom.army || {}).reduce((acc: number, curr: number) => acc + (curr || 0), 0);
  const currentRecruits = Math.max(0, currentPop - currentMil);
  const currentGrowth = getDemographicGrowthRate(kingdom).growthPerHour;

  const allMonths = [
    'Octubre (1084)',
    'Noviembre (1084)',
    'Diciembre (1084)',
    'Enero (1085)',
    'Febrero (1085)',
    'Marzo (1085)',
    'Abril (1085)',
    'Mayo (1085)',
    'Junio (1085)',
    'Julio (1085)',
    'Agosto (1085)',
    'Septiembre (1085)',
  ];

  const shortMonthLabels = [
    'Oct', 'Nov', 'Dic', 'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep'
  ];

  const selectedLabels = monthsCount === 12
    ? shortMonthLabels
    : shortMonthLabels.slice(shortMonthLabels.length - monthsCount);

  // Progressive growth curves leading smoothly to current numbers
  const count = selectedLabels.length;
  return selectedLabels.map((month, idx) => {
    const isCurrent = idx === count - 1;
    if (isCurrent) {
      return {
        month: `${month} (Actual)`,
        population: currentPop,
        capacity: currentCap,
        military: currentMil,
        recruits: currentRecruits,
        growthRate: currentGrowth,
      };
    }

    // Historical progression factor from founding to current
    const progress = (idx + 1) / count;
    // Logarithmic-like foundation curve
    const popRatio = 0.38 + 0.62 * Math.pow(progress, 1.25);
    const capRatio = 0.50 + 0.50 * Math.pow(progress, 1.1);
    const milRatio = 0.25 + 0.75 * Math.pow(progress, 1.35);

    const pop = Math.max(35, Math.round(currentPop * popRatio));
    const cap = Math.max(pop + 15, Math.round(currentCap * capRatio));
    const mil = Math.max(2, Math.round(currentMil * milRatio));
    const rec = Math.max(0, pop - mil);
    const gr = Math.max(1, Math.round(currentGrowth * (0.4 + 0.6 * progress)));

    return {
      month,
      population: pop,
      capacity: cap,
      military: mil,
      recruits: rec,
      growthRate: gr,
    };
  });
}

export function getHospitalCapacity(kingdom: Kingdom): number {
  const hospitalLvl = kingdom.buildings?.hospital || 0;
  if (hospitalLvl <= 0) return 0;
  const baseBeds = hospitalLvl * 60;
  const sanitationBonus = 1 + (kingdom.technologies?.battlefieldSanitation || 0) * 0.15;
  return Math.round(baseBeds * sanitationBonus);
}

export function getTotalWoundedCount(woundedArmy?: Partial<Record<UnitType, number>>): number {
  if (!woundedArmy) return 0;
  return Object.values(woundedArmy).reduce((acc: number, curr) => acc + (curr || 0), 0);
}

export function getHealingUnitCost(unitType: UnitType, kingdom: Kingdom): Resources {
  const unit = UNITS_CONFIG[unitType];
  if (!unit) return { food: 5, wood: 0, stone: 0, gold: 2 };
  const surgeryLvl = kingdom.technologies?.fieldSurgery || 0;
  const discountMult = Math.max(0.40, 1 - surgeryLvl * 0.06);
  return {
    food: Math.max(1, Math.round(unit.cost.food * 0.25 * discountMult)),
    wood: 0,
    stone: 0,
    gold: Math.max(1, Math.round(unit.cost.gold * 0.25 * discountMult)),
  };
}

export interface FormationInfo {
  id: TacticalFormation;
  name: string;
  description: string;
  advantage: string;
  drawback: string;
  infantryBonus: number;
  rangedBonus: number;
  cavalryBonus: number;
  defenseBonus: number;
  lootBonus: number;
  icon: string;
}

export const FORMATIONS_CONFIG: Record<TacticalFormation, FormationInfo> = {
  balanced: {
    id: 'balanced',
    name: 'Formación Clásica de Línea',
    description: 'Disposición equilibrada de vanguardia de infantería, flancos protegidos y arqueros en retaguardia.',
    advantage: 'Sin debilidades notables frente a ninguna combinación de tropas.',
    drawback: 'Sin bonificaciones extremas de choque.',
    infantryBonus: 0,
    rangedBonus: 0,
    cavalryBonus: 0,
    defenseBonus: 0,
    lootBonus: 0,
    icon: '🛡️',
  },
  wedge: {
    id: 'wedge',
    name: 'Cuña de Choque Puntera',
    description: 'Punta de lanza afilada con la caballería pesada e infantería de choque rompiendo el centro enemigo.',
    advantage: '+25% de penetración y daño de caballería e infantería pesada.',
    drawback: '-15% de defensa frente a fuego concentrado de proyectiles.',
    infantryBonus: 0.15,
    rangedBonus: -0.10,
    cavalryBonus: 0.25,
    defenseBonus: -0.10,
    lootBonus: 0.05,
    icon: '🔺',
  },
  phalanx: {
    id: 'phalanx',
    name: 'Falange y Muro de Escudos',
    description: 'Bosque cerrado de picas y escudos solapados inexpugnable ante asaltos frontales de caballería.',
    advantage: '+30% de defensa general y anulación de cargas.',
    drawback: '-15% de velocidad y menor capacidad de persecución.',
    infantryBonus: 0.10,
    rangedBonus: 0.05,
    cavalryBonus: -0.15,
    defenseBonus: 0.30,
    lootBonus: -0.10,
    icon: '🧱',
  },
  line: {
    id: 'line',
    name: 'Cortina de Hostigamiento y Proyectiles',
    description: 'Despliegue amplio con arqueros y ballesteros disparando andanadas continuas antes del choque.',
    advantage: '+25% de efectividad de proyectiles y desgaste a distancia.',
    drawback: '-15% de defensa si la infantería enemiga alcanza el cuerpo a cuerpo.',
    infantryBonus: -0.10,
    rangedBonus: 0.25,
    cavalryBonus: 0.05,
    defenseBonus: -0.05,
    lootBonus: 0,
    icon: '🏹',
  },
  envelopment: {
    id: 'envelopment',
    name: 'Tenaza y Flancos Envolventes',
    description: 'El centro cede deliberadamente mientras alas rápidas de jinetes rodean y embolsan al adversario.',
    advantage: '+20% de botín capturado y aniquilación de la retaguardia enemiga.',
    drawback: 'Requiere superioridad o paridad numérica para sostener el centro.',
    infantryBonus: -0.05,
    rangedBonus: 0.10,
    cavalryBonus: 0.20,
    defenseBonus: -0.05,
    lootBonus: 0.25,
    icon: '🦅',
  },
};

export const EQUIPMENT_CONFIG: Record<EquipmentType, EquipmentInfo> = {
  toledoSteel: {
    type: 'toledoSteel',
    name: 'Hojas de Acero Toledano',
    category: 'weapons',
    description: 'Espadas y filos forjados con temple al agua del Tajo, capaces de hender cualquier cota de malla.',
    icon: '⚔️',
    cost: { food: 0, wood: 200, stone: 400, gold: 350 },
    costMultiplier: 1.6,
    maxLevel: 5,
    bonusDescription: (lvl) => `+${lvl * 8}% de ataque para toda la infantería (Espadachines y Milicia)`,
  },
  compositeArmor: {
    type: 'compositeArmor',
    name: 'Cotas de Malla Remachada',
    category: 'armor',
    description: 'Armaduras con anillos de acero entrelazados que protegen el torso contra estocadas y tajos directos.',
    icon: '🛡️',
    cost: { food: 0, wood: 150, stone: 500, gold: 400 },
    costMultiplier: 1.6,
    maxLevel: 5,
    bonusDescription: (lvl) => `+${lvl * 8}% de resistencia defensiva y mitigación de bajas para todo el ejército`,
  },
  fireArrows: {
    type: 'fireArrows',
    name: 'Puntas Incendiarias y Fuego Feudal',
    category: 'siege',
    description: 'Estopa impregnada en brea para incendiar empalizadas enemigas, torres de madera y carros de asedio.',
    icon: '🔥',
    cost: { food: 100, wood: 350, stone: 200, gold: 300 },
    costMultiplier: 1.5,
    maxLevel: 5,
    bonusDescription: (lvl) => `+${lvl * 10}% de daño de asedio contra murallas y daño de arqueros`,
  },
  reinforcedShields: {
    type: 'reinforcedShields',
    name: 'Pavés y Escudos Reforzados',
    category: 'armor',
    description: 'Grandes escudos forrados en cuero curtido y planchas de bronce para guarecerse de lluvias de flechas.',
    icon: '🔰',
    cost: { food: 0, wood: 400, stone: 300, gold: 250 },
    costMultiplier: 1.5,
    maxLevel: 5,
    bonusDescription: (lvl) => `-${lvl * 6}% de bajas sufridas ante fuego de proyectiles enemigo`,
  },
  warhorseBarding: {
    type: 'warhorseBarding',
    name: 'Bardas de Guerra y Testeras de Acero',
    category: 'cavalry',
    description: 'Armaduras completas de cuero endurecido y placas articuladas para los corceles de batalla.',
    icon: '🐎',
    cost: { food: 250, wood: 200, stone: 350, gold: 500 },
    costMultiplier: 1.7,
    maxLevel: 5,
    bonusDescription: (lvl) => `+${lvl * 10}% de impacto en carga y supervivencia de la caballería`,
  },
};

export function calculateResourceRates(kingdom: Kingdom): ResourceRates {
  const civ = CIVILIZATIONS[kingdom.civilization];
  const { buildings, technologies, taxRate, foodLevel, workerAllocation } = kingdom;

  let foodBase = (buildings.farm || 1) * 120;
  let woodBase = (buildings.lumberMill || 1) * 110;
  let stoneBase = (buildings.quarry || 1) * 95;
  let goldBase = (buildings.goldMine || 1) * 80;

  // Worker Allocation Modifiers (Baseline is 25% each)
  const alloc = workerAllocation || { farmers: 25, woodcutters: 25, miners: 25, mintWorkers: 25 };
  const workerFoodMult = 1 + (alloc.farmers - 25) * 0.008;
  const workerWoodMult = 1 + (alloc.woodcutters - 25) * 0.008;
  const workerStoneMult = 1 + (alloc.miners - 25) * 0.008;
  const workerGoldMult = 1 + (alloc.mintWorkers - 25) * 0.008;

  const foodTechMult = 1 + (technologies.cropRotation || 0) * 0.08;
  const woodTechMult = 1 + (technologies.ironAxes || 0) * 0.08;
  const stoneTechMult = 1 + (technologies.deepQuarry || 0) * 0.08;
  const goldTechMult = 1 + (technologies.coinage || 0) * 0.10;

  const foodCivMult = 1 + civ.bonuses.foodBonus;
  const woodCivMult = 1 + civ.bonuses.woodBonus;
  const stoneCivMult = 1 + civ.bonuses.stoneBonus;
  const goldCivMult = 1 + civ.bonuses.goldBonus;

  let generalProdMult = 1;
  if (foodLevel === 'scant') generalProdMult = 0.90;
  if (foodLevel === 'generous') generalProdMult = 1.10;
  if (foodLevel === 'feast') generalProdMult = 1.25;

  const taxGoldIncome = (taxRate / 100) * 200 * (buildings.townHall || 1);

  let armyFoodUpkeep = 0;
  Object.entries(kingdom.army).forEach(([unitKey, count]) => {
    const unit = UNITS_CONFIG[unitKey as UnitType];
    if (unit && (count as number) > 0) {
      armyFoodUpkeep += unit.upkeepFoodPerHour * (count as number);
    }
  });

  const foodNet = Math.round(foodBase * foodTechMult * foodCivMult * workerFoodMult * generalProdMult - armyFoodUpkeep);
  const woodNet = Math.round(woodBase * woodTechMult * woodCivMult * workerWoodMult * generalProdMult);
  const stoneNet = Math.round(stoneBase * stoneTechMult * stoneCivMult * workerStoneMult * generalProdMult);
  const goldNet = Math.round((goldBase * goldTechMult * goldCivMult * workerGoldMult + taxGoldIncome) * generalProdMult);

  return {
    foodPerHour: foodNet,
    woodPerHour: woodNet,
    stonePerHour: stoneNet,
    goldPerHour: goldNet,
  };
}

export function createInitialKingdom(name: string, castle: string, civId: CivilizationId): Kingdom {
  return {
    id: 'k_' + Date.now().toString(36),
    kingdomName: name.trim() || 'Reino de Castilla',
    castleName: castle.trim() || 'Castillo de la Mota',
    civilization: civId,
    createdAt: Date.now(),
    lastTickTimestamp: Date.now(),
    gloryPoints: 100,
    seasonNumber: 1,
    resources: {
      food: 800,
      wood: 800,
      stone: 700,
      gold: 500,
    },
    taxRate: 20,
    foodLevel: 'normal',
    warFooting: 'peace',
    militaryStrategy: 'balanced',
    formation: 'balanced',
    equipment: {
      toledoSteel: 0,
      compositeArmor: 0,
      fireArrows: 0,
      reinforcedShields: 0,
      warhorseBarding: 0,
    },
    workerAllocation: {
      farmers: 25,
      woodcutters: 25,
      miners: 25,
      mintWorkers: 25,
    },
    buildings: {
      townHall: 1,
      farm: 1,
      lumberMill: 1,
      quarry: 1,
      goldMine: 1,
      warehouse: 1,
      granary: 1,
      barracks: 1,
      university: 0,
      wall: 1,
      parliament: 0,
      tavern: 1,
      hospital: 0,
      houses: 1,
    },
    technologies: {
      cropRotation: 0,
      ironAxes: 0,
      deepQuarry: 0,
      coinage: 0,
      ironArmor: 0,
      compositeBow: 0,
      horseBreeding: 0,
      siegeEngines: 0,
      espionageNetwork: 0,
      stoneFortification: 0,
      medicinalHerbs: 0,
      fieldSurgery: 0,
      battlefieldSanitation: 0,
    },
    army: {
      militia: 10,
      swordsman: 5,
      archer: 5,
      crossbowman: 0,
      lightCavalry: 2,
      knight: 0,
      batteringRam: 0,
      catapult: 0,
      spy: 1,
    },
    woundedArmy: {
      militia: 0,
      swordsman: 0,
      archer: 0,
      crossbowman: 0,
      lightCavalry: 0,
      knight: 0,
      batteringRam: 0,
      catapult: 0,
      spy: 0,
    },
    constructionQueue: [],
    researchQueue: [],
    trainingQueue: [],
    battleReports: [],
    spyReports: [],
    conqueredTerritories: [],
    claimedChallenges: [],
    population: 180,
  };
}

export const PVP_PRESET_MESSAGES = [
  '¿Te atreves a retarme? 🔴',
  'Mi reino está preparado. 🔴',
  'Buena suerte. 🔴',
  '¿Eso es todo? 🔴',
  'Nos veremos en el campo de batalla. 🔴',
] as const;

export const PVP_PREPARATION_OPTIONS = [
  { hours: 1, label: '1 hora (Urgente - Escaramuza fronteriza)' },
  { hours: 6, label: '6 horas (Preparación rápida)' },
  { hours: 12, label: '12 horas (Medio día feudal)' },
  { hours: 24, label: '24 horas / 1 año (Tiempo estándar de preparación)' },
  { hours: 48, label: '48 horas / 2 años (Gran campaña planeada)' },
] as const;

export function getPlayerMapCoordinates(userId: string): { x: number; y: number } {
  let hash = 0;
  for (let i = 0; i < userId.length; i++) {
    hash = (hash << 5) - hash + userId.charCodeAt(i);
    hash |= 0;
  }
  const abs = Math.abs(hash);
  const x = (abs % 8) + 1;
  const y = (Math.floor(abs / 8) % 8) + 1;
  return { x, y };
}

export function calculateKingdomDistance(x1: number, y1: number, x2: number, y2: number): number {
  const dx = x1 - x2;
  const dy = y1 - y2;
  const rawDist = Math.sqrt(dx * dx + dy * dy);
  return Math.max(5, Math.round(rawDist * 14)); // leguas
}

