import { BuildingDef, CraftingRecipe } from '../types/gameTypes';

export const CRAFTING_RECIPES: CraftingRecipe[] = [
  // Building materials
  {
    id: 'craft_timber_beam',
    resultItemId: 'timber_beam',
    resultCount: 2,
    category: 'Building',
    ingredients: [{ itemId: 'wood', count: 3 }],
  },
  {
    id: 'craft_stone_block',
    resultItemId: 'stone_block',
    resultCount: 2,
    category: 'Building',
    ingredients: [{ itemId: 'stone', count: 3 }],
  },

  // Potions & Food
  {
    id: 'craft_health_potion',
    resultItemId: 'health_potion',
    resultCount: 1,
    category: 'Potions',
    ingredients: [
      { itemId: 'herbs', count: 2 },
      { itemId: 'wild_berry', count: 1 },
    ],
  },
  {
    id: 'craft_mana_potion',
    resultItemId: 'mana_potion',
    resultCount: 1,
    category: 'Potions',
    ingredients: [
      { itemId: 'magic_dust', count: 2 },
      { itemId: 'herbs', count: 1 },
    ],
  },
  {
    id: 'craft_elixir_elements',
    resultItemId: 'elixir_of_elements',
    resultCount: 1,
    category: 'Potions',
    ingredients: [
      { itemId: 'crystal', count: 1 },
      { itemId: 'herbs', count: 3 },
      { itemId: 'magic_dust', count: 2 },
    ],
  },
  {
    id: 'cook_meat',
    resultItemId: 'cooked_meat',
    resultCount: 1,
    category: 'Food',
    requiresCampfire: false,
    ingredients: [
      { itemId: 'raw_meat', count: 1 },
      { itemId: 'wood', count: 1 },
    ],
  },
  {
    id: 'cook_herbal_stew',
    resultItemId: 'herbal_stew',
    resultCount: 1,
    category: 'Food',
    ingredients: [
      { itemId: 'raw_meat', count: 1 },
      { itemId: 'herbs', count: 2 },
      { itemId: 'wild_berry', count: 2 },
    ],
  },

  // Weapons & Armor
  {
    id: 'craft_steel_greatsword',
    resultItemId: 'steel_greatsword',
    resultCount: 1,
    category: 'Weapons',
    ingredients: [
      { itemId: 'iron', count: 4 },
      { itemId: 'wood', count: 2 },
    ],
  },
  {
    id: 'craft_nordic_battleaxe',
    resultItemId: 'nordic_battleaxe',
    resultCount: 1,
    category: 'Weapons',
    ingredients: [
      { itemId: 'iron', count: 4 },
      { itemId: 'stone', count: 2 },
    ],
  },
  {
    id: 'craft_shadow_daggers',
    resultItemId: 'shadow_daggers',
    resultCount: 1,
    category: 'Weapons',
    ingredients: [
      { itemId: 'iron', count: 3 },
      { itemId: 'monster_fang', count: 4 },
      { itemId: 'spirit_essence', count: 1 },
    ],
  },
  {
    id: 'craft_elven_longbow',
    resultItemId: 'elven_longbow',
    resultCount: 1,
    category: 'Weapons',
    ingredients: [
      { itemId: 'wood', count: 5 },
      { itemId: 'harpy_feather', count: 3 },
    ],
  },
  {
    id: 'craft_crystal_archstaff',
    resultItemId: 'crystal_archstaff',
    resultCount: 1,
    category: 'Magic',
    ingredients: [
      { itemId: 'ancient_bark', count: 2 },
      { itemId: 'crystal', count: 3 },
      { itemId: 'magic_dust', count: 4 },
    ],
  },
  {
    id: 'craft_iron_chestplate',
    resultItemId: 'iron_chestplate',
    resultCount: 1,
    category: 'Armor',
    ingredients: [
      { itemId: 'iron', count: 5 },
      { itemId: 'troll_hide', count: 2 },
    ],
  },
  {
    id: 'craft_knight_shield',
    resultItemId: 'knight_tower_shield',
    resultCount: 1,
    category: 'Armor',
    ingredients: [
      { itemId: 'iron', count: 4 },
      { itemId: 'gold', count: 1 },
    ],
  },
  {
    id: 'craft_wind_boots',
    resultItemId: 'wind_boots',
    resultCount: 1,
    category: 'Armor',
    ingredients: [
      { itemId: 'harpy_feather', count: 3 },
      { itemId: 'troll_hide', count: 2 },
    ],
  },
  {
    id: 'craft_ruby_ring',
    resultItemId: 'ruby_ring',
    resultCount: 1,
    category: 'Magic',
    ingredients: [
      { itemId: 'gold', count: 2 },
      { itemId: 'fire_essence', count: 2 },
    ],
  },
  {
    id: 'craft_sunfire_blade',
    resultItemId: 'sunfire_blade',
    resultCount: 1,
    category: 'Weapons',
    ingredients: [
      { itemId: 'sun_gem', count: 3 },
      { itemId: 'gold', count: 4 },
      { itemId: 'fire_essence', count: 3 },
    ],
  },
  {
    id: 'craft_hellfire_plate',
    resultItemId: 'hellfire_plate',
    resultCount: 1,
    category: 'Armor',
    ingredients: [
      { itemId: 'obsidian_shard', count: 4 },
      { itemId: 'dragon_scales', count: 2 },
      { itemId: 'iron', count: 6 },
    ],
  },
];

export const BUILDABLES: BuildingDef[] = [
  {
    type: 'campfire',
    name: 'Campfire',
    description: 'Warm hearth that heals nearby resting travelers and lets you cook food.',
    cost: [
      { itemId: 'wood', count: 3 },
      { itemId: 'stone', count: 2 },
    ],
    footprint: 2.5,
  },
  {
    type: 'wall',
    name: 'Stone Wall',
    description: 'Defensive stone fortification segment.',
    cost: [{ itemId: 'stone', count: 4 }],
    footprint: 5,
  },
  {
    type: 'house',
    name: 'Timber Cottage',
    description: 'Cozy enterable wooden home with hearth.',
    cost: [
      { itemId: 'wood', count: 8 },
      { itemId: 'stone', count: 4 },
    ],
    footprint: 8,
  },
  {
    type: 'storage',
    name: 'Storage Cabin',
    description: 'Reinforced supply shed for expedition gear.',
    cost: [
      { itemId: 'wood', count: 6 },
      { itemId: 'iron', count: 2 },
    ],
    footprint: 6,
  },
  {
    type: 'workshop',
    name: 'Craft Workshop',
    description: 'Field smithy and workbench outpost.',
    cost: [
      { itemId: 'wood', count: 6 },
      { itemId: 'stone', count: 4 },
      { itemId: 'iron', count: 2 },
    ],
    footprint: 7,
  },
  {
    type: 'farm',
    name: 'Herb & Berry Farm',
    description: 'Tended garden plots cultivating herbs and berries.',
    cost: [
      { itemId: 'wood', count: 4 },
      { itemId: 'herbs', count: 2 },
    ],
    footprint: 7,
  },
  {
    type: 'tower',
    name: 'Guard Watchtower',
    description: 'Tall stone lookout tower overlooking the realm.',
    cost: [
      { itemId: 'stone', count: 10 },
      { itemId: 'wood', count: 4 },
    ],
    footprint: 6,
  },
  {
    type: 'castle',
    name: 'Fortress Keep',
    description: 'Grand stone bastion worthy of a realm champion.',
    cost: [
      { itemId: 'stone', count: 18 },
      { itemId: 'wood', count: 10 },
      { itemId: 'iron', count: 4 },
    ],
    footprint: 12,
  },
];
