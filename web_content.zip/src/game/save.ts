import { CATALOG } from "./catalog";

const KEY = "galaxy_atlas_ultra_x_v3";
const LEGACY_KEY = "galaxy_atlas_ultra_x_v2";
const SAVE_VERSION = 3;

export type SaveData = {
  version: number
  xp: number
  credits: number
  discovered: string[]
  completed: string[]
  samples: number
  warps: number
  scans: number
  dives: number
  bhScans: number
  muted: boolean
};

export const DEFAULT_SAVE: SaveData = {
  version: SAVE_VERSION,
  xp: 0,
  credits: 0,
  discovered: [],
  completed: [],
  samples: 0,
  warps: 0,
  scans: 0,
  dives: 0,
  bhScans: 0,
  muted: false,
};

function migrate(raw: Partial<SaveData> & { version?: number }): SaveData {
  const s: SaveData = { ...DEFAULT_SAVE, ...raw, version: raw.version ?? 1 };
  if (s.version < 2) {
    s.version = 2;
  }
  if (s.version < 3) {
    // The atlas expanded from 31 bodies to 119. Re-open the old master mission
    // so an existing save cannot incorrectly report the new atlas as complete.
    s.completed = s.completed.filter((id) => id !== "master");
    s.version = 3;
  }
  s.discovered = Array.isArray(s.discovered)
    ? s.discovered.filter((id) => CATALOG.some((c) => String(c.id) === id))
    : [];
  s.completed = Array.isArray(s.completed) ? s.completed : [];
  s.xp = Number.isFinite(s.xp) ? s.xp : 0;
  s.credits = Number.isFinite(s.credits) ? s.credits : 0;
  s.samples = Number.isFinite(s.samples) ? s.samples : 0;
  s.warps = Number.isFinite(s.warps) ? s.warps : 0;
  s.scans = Number.isFinite(s.scans) ? s.scans : 0;
  s.dives = Number.isFinite(s.dives) ? s.dives : 0;
  s.bhScans = Number.isFinite(s.bhScans) ? s.bhScans : 0;
  s.muted = Boolean(s.muted);
  s.version = SAVE_VERSION;
  return s;
}

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY) ?? localStorage.getItem(LEGACY_KEY);
    if (!raw) return { ...DEFAULT_SAVE, discovered: [] };
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    return migrate(parsed);
  } catch {
    return { ...DEFAULT_SAVE, discovered: [] };
  }
}

export function writeSave(data: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify({ ...data, version: SAVE_VERSION }));
  } catch {
    /* private mode / quota */
  }
}

export function clearSave() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}
