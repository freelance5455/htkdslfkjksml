import { CHARACTERS } from "./data/characters";
import type { FighterSave, SaveData, SettingsState } from "./types";

export const SAVE_KEY = "ashline.save.v1";
export const SAVE_VERSION = 1;

export function defaultSettings(): SettingsState {
  return { master: 0.8, sfx: 0.8, lowMemory: false, shake: true, reducedMotion: false };
}

export function defaultFighter(id: string): FighterSave {
  const ch = CHARACTERS.find((c) => c.id === id);
  const formation = ch?.role === "ranged" || ch?.role === "support" || ch?.role === "assassin" ? "rear"
    : ch?.role === "vanguard" || ch?.role === "defender" || ch?.role === "heavy" ? "front"
    : "middle";
  return {
    id,
    level: 1,
    xp: 0,
    hp: ch?.maxHp ?? 100,
    trust: ch?.startingTrust ?? 0,
    fatigue: false,
    equipment: {},
    formation,
    unlockedAbilities: ch?.abilities.map((a) => a.id) ?? [],
  };
}

export function defaultSave(): SaveData {
  const fighters: Record<string, FighterSave> = {};
  for (const c of CHARACTERS) fighters[c.id] = defaultFighter(c.id);
  return {
    version: SAVE_VERSION,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    hasSave: false,
    currentEpisode: 1,
    unlockedEpisode: 1,
    completed: [],
    fighters,
    recruited: ["rook"],
    managerLevel: 1,
    managerXp: 0,
    currency: 0,
    inventory: [],
    ardenSpecials: [],
    archive: ["ashline", "arden-file"],
    discoveries: ["ashline", "arden-file"],
    enemyVariants: [],
    flags: {},
    world: { anomaly: 0, weather: "none" },
    rngSeed: (Date.now() ^ 0x9e3779b9) >>> 0,
    rngCount: 0,
    settings: defaultSettings(),
  };
}

function migrate(raw: SaveData): SaveData {
  const base = defaultSave();
  const merged: SaveData = {
    ...base,
    ...raw,
    version: SAVE_VERSION,
    fighters: { ...base.fighters, ...raw.fighters },
    settings: { ...base.settings, ...raw.settings },
    flags: { ...base.flags, ...raw.flags },
    world: { ...base.world, ...raw.world },
  };
  return merged;
}

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return defaultSave();
    const parsed = JSON.parse(raw) as SaveData;
    return migrate(parsed);
  } catch {
    return defaultSave();
  }
}

export function persistSave(save: SaveData) {
  const next = { ...save, updatedAt: Date.now() };
  try {
    const prev = localStorage.getItem(SAVE_KEY);
    if (prev) localStorage.setItem(SAVE_KEY + ".bak", prev);
    localStorage.setItem(SAVE_KEY, JSON.stringify(next));
  } catch {
    /* private mode / quota */
  }
  return next;
}

export function exportSave(save: SaveData) {
  return JSON.stringify(save, null, 2);
}

export function importSave(json: string): SaveData | null {
  try {
    const parsed = JSON.parse(json) as SaveData;
    if (!parsed || typeof parsed !== "object") return null;
    return migrate(parsed);
  } catch {
    return null;
  }
}
