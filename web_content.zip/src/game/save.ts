const KEY = "gallows-hollow-save";
const VERSION = 1;

export type SaveData = {
  version: number;
  highScore: number;
  bestWave: number;
};

const EMPTY: SaveData = { version: VERSION, highScore: 0, bestWave: 0 };

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...EMPTY };
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    return {
      version: VERSION,
      highScore: Number(parsed.highScore) || 0,
      bestWave: Number(parsed.bestWave) || 0,
    };
  } catch {
    return { ...EMPTY };
  }
}

export function writeSave(data: SaveData): void {
  try {
    localStorage.setItem(KEY, JSON.stringify({ ...data, version: VERSION }));
  } catch {
    /* private mode / quota */
  }
}

export function recordRun(score: number, wave: number): SaveData {
  const prev = loadSave();
  const next: SaveData = {
    version: VERSION,
    highScore: Math.max(prev.highScore, score),
    bestWave: Math.max(prev.bestWave, wave),
  };
  writeSave(next);
  return next;
}
