import { TEAMS, teamById, type TeamDef } from "./teams";
import { poisson } from "./math";

const KEY = "fc28-save-v1";
const SETTINGS_KEY = "fc28-settings-v1";
const SAVE_VERSION = 1;

export type Difficulty = "amateur" | "pro" | "world";

export type Settings = {
  version: number;
  volume: number;
  muted: boolean;
  shake: boolean;
  autoSwitch: boolean;
  difficulty: Difficulty;
};

export const defaultSettings = (): Settings => ({
  version: SAVE_VERSION,
  volume: 0.7,
  muted: false,
  shake: true,
  autoSwitch: true,
  difficulty: "pro",
});

export function loadSettings(): Settings {
  if (typeof window === "undefined") return defaultSettings();
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return defaultSettings();
    const parsed = JSON.parse(raw) as Partial<Settings>;
    return { ...defaultSettings(), ...parsed, version: SAVE_VERSION };
  } catch {
    return defaultSettings();
  }
}

export function saveSettings(s: Settings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify({ ...s, version: SAVE_VERSION }));
  } catch {
    /* private mode */
  }
}

export type Fixture = {
  homeId: string;
  awayId: string;
  hg: number | null;
  ag: number | null;
};

export type Career = {
  version: number;
  teamId: string;
  week: number;
  fixtures: Fixture[];
};

function roundRobin(ids: string[]): Fixture[] {
  const list = [...ids];
  if (list.length % 2 === 1) list.push("bye");
  const n = list.length;
  const rounds = n - 1;
  const half = n / 2;
  const out: Fixture[] = [];
  const arr = [...list];
  for (let r = 0; r < rounds; r++) {
    for (let i = 0; i < half; i++) {
      const a = arr[i]!;
      const b = arr[n - 1 - i]!;
      if (a !== "bye" && b !== "bye") {
        out.push(r % 2 === 0 ? { homeId: a, awayId: b, hg: null, ag: null } : { homeId: b, awayId: a, hg: null, ag: null });
      }
    }
    const last = arr.pop()!;
    arr.splice(1, 0, last);
  }
  return out;
}

export function newCareer(teamId: string): Career {
  const ids = TEAMS.map((t) => t.id);
  return { version: SAVE_VERSION, teamId, week: 0, fixtures: roundRobin(ids) };
}

export function loadCareer(): Career | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Career;
    if (!parsed.teamId || !parsed.fixtures) return null;
    return { ...parsed, version: SAVE_VERSION };
  } catch {
    return null;
  }
}

export function saveCareer(c: Career) {
  try {
    localStorage.setItem(KEY, JSON.stringify({ ...c, version: SAVE_VERSION }));
  } catch {
    /* ignore */
  }
}

export function clearCareer() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}

export function simScore(home: TeamDef, away: TeamDef): [number, number] {
  const hs = (home.rating + home.attack * 0.4) / 140;
  const as = (away.rating + away.attack * 0.4) / 140;
  return [poisson(1.15 * hs + 0.25), poisson(1.0 * as)];
}

export type TableRow = {
  id: string;
  team: TeamDef;
  p: number;
  w: number;
  d: number;
  l: number;
  gf: number;
  ga: number;
  gd: number;
  pts: number;
};

export function standings(career: Career): TableRow[] {
  const rows = new Map<string, TableRow>();
  for (const t of TEAMS) {
    rows.set(t.id, { id: t.id, team: t, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, gd: 0, pts: 0 });
  }
  for (const f of career.fixtures) {
    if (f.hg === null || f.ag === null) continue;
    const h = rows.get(f.homeId);
    const a = rows.get(f.awayId);
    if (!h || !a) continue;
    h.p++; a.p++;
    h.gf += f.hg; h.ga += f.ag;
    a.gf += f.ag; a.ga += f.hg;
    if (f.hg > f.ag) {
      h.w++; a.l++; h.pts += 3;
    } else if (f.hg < f.ag) {
      a.w++; h.l++; a.pts += 3;
    } else {
      h.d++; a.d++; h.pts += 1; a.pts += 1;
    }
  }
  for (const r of rows.values()) r.gd = r.gf - r.ga;
  return [...rows.values()].sort((a, b) => b.pts - a.pts || b.gd - a.gd || b.gf - a.gf);
}

export function nextUserFixture(career: Career): Fixture | null {
  return (
    career.fixtures.find(
      (f) => f.hg === null && (f.homeId === career.teamId || f.awayId === career.teamId),
    ) ?? null
  );
}

export function applyUserResult(career: Career, hg: number, ag: number): Career {
  const next = structuredClone(career) as Career;
  const fx = next.fixtures.find(
    (f) => f.hg === null && (f.homeId === next.teamId || f.awayId === next.teamId),
  );
  if (fx) {
    fx.hg = hg;
    fx.ag = ag;
  }
  for (const f of next.fixtures) {
    if (f.hg !== null) continue;
    if (f.homeId === next.teamId || f.awayId === next.teamId) continue;
    const [h, a] = simScore(teamById(f.homeId), teamById(f.awayId));
    f.hg = h;
    f.ag = a;
  }
  next.week += 1;
  return next;
}
