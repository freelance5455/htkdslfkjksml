import type { ProductId, SimState } from "./types";
import { PRODUCTS } from "./catalog";

export const SAVE_KEY = "smx-sim-v1";
export const SAVE_VERSION = 1;

const PRODUCT_IDS = PRODUCTS.map((p) => p.id);

function emptyStock(): Record<ProductId, number> {
  const o = {} as Record<ProductId, number>;
  for (const id of PRODUCT_IDS) o[id] = 0;
  return o;
}

function emptyMul(): Record<ProductId, number> {
  const o = {} as Record<ProductId, number>;
  for (const id of PRODUCT_IDS) o[id] = 1;
  return o;
}

function emptyUnlock(): Record<ProductId, boolean> {
  const o = {} as Record<ProductId, boolean>;
  for (const p of PRODUCTS) o[p.id] = p.unlockLevel <= 1;
  return o;
}

export function defaultSim(): SimState {
  const warehouse = emptyStock();
  warehouse.bread = 36;
  warehouse.milk = 32;
  warehouse.eggs = 24;
  warehouse.drinks = 28;
  warehouse.chocolate = 20;
  return {
    version: SAVE_VERSION,
    money: 2800,
    day: 1,
    timeOfDay: 8,
    storeOpen: false,
    storeLevel: 1,
    location: "town",
    rating: 3.6,
    xp: 0,
    warehouse,
    unlocked: emptyUnlock(),
    sellMul: emptyMul(),
    shelves: [],
    staff: [],
    orders: [],
    missions: [],
    event: null,
    cleanliness: 0.92,
    lights: 0,
    decor: 0,
    warehouseCap: 220,
    checkouts: 1,
    player: { x: 0, z: 9.4, yaw: 0, holding: null },
    daily: { revenue: 0, expenses: 0, sold: 0, served: 0, lost: 0 },
    tutorial: 0,
    seenHelp: false,
    settings: { sfx: 0.7, music: 0.35, shake: true, quality: "med" },
    nextCustomer: 1,
    nextStaff: 1,
    nextOrder: 1,
    soldToday: emptyStock(),
    demandMul: emptyMul(),
  };
}

function migrate(raw: SimState): SimState {
  const base = defaultSim();
  const merged: SimState = {
    ...base,
    ...raw,
    version: SAVE_VERSION,
    warehouse: { ...base.warehouse, ...raw.warehouse },
    unlocked: { ...base.unlocked, ...raw.unlocked },
    sellMul: { ...base.sellMul, ...raw.sellMul },
    soldToday: { ...base.soldToday, ...raw.soldToday },
    demandMul: { ...base.demandMul, ...raw.demandMul },
    settings: { ...base.settings, ...raw.settings },
    player: { ...base.player, ...raw.player },
    daily: { ...base.daily, ...raw.daily },
    shelves: raw.shelves ?? [],
    staff: raw.staff ?? [],
    orders: raw.orders ?? [],
    missions: raw.missions ?? [],
  };
  return merged;
}

export function loadSave(): SimState {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return defaultSim();
    const parsed = JSON.parse(raw) as SimState;
    if (!parsed || typeof parsed !== "object") return defaultSim();
    return migrate(parsed);
  } catch {
    return defaultSim();
  }
}

export function writeSave(state: SimState): void {
  try {
    const blob = JSON.stringify(state);
    localStorage.setItem(SAVE_KEY + ":bak", localStorage.getItem(SAVE_KEY) ?? "");
    localStorage.setItem(SAVE_KEY, blob);
  } catch {
    /* private mode / quota */
  }
}

export function clearSave(): void {
  try {
    localStorage.removeItem(SAVE_KEY);
    localStorage.removeItem(SAVE_KEY + ":bak");
  } catch {
    /* ignore */
  }
}
