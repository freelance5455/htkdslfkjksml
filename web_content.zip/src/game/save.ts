import { SaveGameData } from '../types/game';

const SAVE_KEY = 'PIXEL_SURVIVAL_LAST_DAY_SAVE_V1';

export function saveGameToStorage(data: SaveGameData): boolean {
  try {
    const serialized = JSON.stringify(data);
    localStorage.setItem(SAVE_KEY, serialized);
    return true;
  } catch (err) {
    console.error('Failed to save game to localStorage:', err);
    return false;
  }
}

export function loadGameFromStorage(): SaveGameData | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as SaveGameData;
    if (!data || !data.version) return null;
    return data;
  } catch (err) {
    console.error('Failed to load game from localStorage:', err);
    return null;
  }
}

export function hasSavedGameInStorage(): boolean {
  return !!localStorage.getItem(SAVE_KEY);
}

export function clearGameFromStorage() {
  localStorage.removeItem(SAVE_KEY);
}
