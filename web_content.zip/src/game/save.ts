import type { Diff, Lang } from "./content";

export interface SaveData {
  version: 1;
  lang: Lang;
  sound: boolean;
  volume: number;
  difficulty: Diff;
  fog: boolean;
  recordReplay: boolean;
  tutorialDone: boolean;
  campaignUnlocked: number;
  campaignCleared: string[];
  worldFront: number;
  achievements: string[];
  stats: { kills: number; losses: number; cities: number; battles: number; time: number };
  custom: { name: string; raw: string }[];
}

export interface ReplaySnap {
  t: number;
  u: number[];
}

export interface ReplayData {
  title: string;
  duration: number;
  snaps: ReplaySnap[];
  initCities: { id: string; owner: number }[];
  events: { t: number; id: string; owner: number }[];
}

const KEY = "frontdots-v1";
const REPLAY_KEY = "frontdots-replay-v1";

export function defaultSave(): SaveData {
  return {
    version: 1,
    lang: "ru",
    sound: true,
    volume: 0.7,
    difficulty: 1,
    fog: false,
    recordReplay: true,
    tutorialDone: false,
    campaignUnlocked: 0,
    campaignCleared: [],
    worldFront: 0,
    achievements: [],
    stats: { kills: 0, losses: 0, cities: 0, battles: 0, time: 0 },
    custom: [],
  };
}

export class SaveSystem {
  data: SaveData = defaultSave();

  load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as Partial<SaveData>;
      if (!parsed || parsed.version !== 1) return;
      this.data = { ...defaultSave(), ...parsed, stats: { ...defaultSave().stats, ...parsed.stats } };
      if (!Array.isArray(this.data.campaignCleared)) this.data.campaignCleared = [];
      if (!Array.isArray(this.data.achievements)) this.data.achievements = [];
      if (!Array.isArray(this.data.custom)) this.data.custom = [];
      this.data.campaignUnlocked = clampNum(this.data.campaignUnlocked, 0, 7);
      this.data.worldFront = clampNum(this.data.worldFront, 0, 6);
      this.data.difficulty = (this.data.difficulty === 0 || this.data.difficulty === 2 ? this.data.difficulty : 1) as Diff;
      this.data.lang = this.data.lang === "en" ? "en" : "ru";
    } catch {
      this.data = defaultSave();
    }
  }

  persist() {
    try {
      localStorage.setItem(KEY, JSON.stringify(this.data));
    } catch {
      /* квота или приватный режим */
    }
  }

  unlock(id: string): boolean {
    if (this.data.achievements.includes(id)) return false;
    this.data.achievements.push(id);
    this.persist();
    return true;
  }

  saveReplay(replay: ReplayData) {
    try {
      const raw = JSON.stringify(replay);
      if (raw.length > 1_400_000) return;
      localStorage.setItem(REPLAY_KEY, raw);
    } catch {
      /* повтор необязателен */
    }
  }

  loadReplay(): ReplayData | null {
    try {
      const raw = localStorage.getItem(REPLAY_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as ReplayData;
      if (!parsed?.snaps?.length) return null;
      return parsed;
    } catch {
      return null;
    }
  }
}

function clampNum(n: number, a: number, b: number) {
  if (typeof n !== "number" || Number.isNaN(n)) return a;
  return Math.max(a, Math.min(b, n));
}
