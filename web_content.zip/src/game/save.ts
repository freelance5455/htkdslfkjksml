import { WEAPON_MAP, sanitizeAttachments, type AttachConfig, getWeapon, SKINS } from './data/weapons';
import { type ModeId, type Difficulty, levelFromXp, MISSIONS, type StatKey, OPERATORS } from './data/content';

export type Action = 'forward' | 'back' | 'left' | 'right' | 'jump' | 'sprint' | 'crouch' | 'reload' | 'interact' | 'slot1' | 'slot2' | 'heal' | 'plate' | 'inspect' | 'melee';
export const ACTION_LABELS: Record<Action, string> = {
  forward: 'Move Forward', back: 'Move Back', left: 'Strafe Left', right: 'Strafe Right', jump: 'Jump', sprint: 'Sprint',
  crouch: 'Crouch / Slide', reload: 'Reload', interact: 'Interact / Pick Up', slot1: 'Primary Weapon', slot2: 'Secondary Weapon',
  heal: 'Use Medkit', plate: 'Apply Armor Plate', inspect: 'Inspect Weapon', melee: 'Swap Weapon (cycle)',
};
export const DEFAULT_BINDINGS: Record<Action, string> = {
  forward: 'KeyW', back: 'KeyS', left: 'KeyA', right: 'KeyD', jump: 'Space', sprint: 'ShiftLeft', crouch: 'KeyC',
  reload: 'KeyR', interact: 'KeyE', slot1: 'Digit1', slot2: 'Digit2', heal: 'KeyH', plate: 'KeyV', inspect: 'KeyF', melee: 'KeyQ',
};

export type Preset = 'low' | 'medium' | 'high' | 'ultra' | 'custom';
export interface GraphicsSettings {
  preset: Preset; renderScale: number; shadows: number; textures: number; effects: number;
  antialias: boolean; motionBlur: boolean; fpsLimit: number; fov: number; viewDistance: number; dynamicRes: boolean; showFps: boolean;
}
export interface Settings {
  audio: { master: number; music: number; sfx: number; dialogue: number };
  graphics: GraphicsSettings;
  controls: {
    sensitivity: number; adsSensitivity: number; invertY: boolean; touchSensitivity: number;
    touchMode: 'auto' | 'on' | 'off'; leftHanded: boolean; buttonScale: number; buttonOpacity: number;
    fireOffsetX: number; fireOffsetY: number; toggleAds: boolean; bindings: Record<Action, string>;
  };
  gameplay: { damageNumbers: boolean; difficulty: Difficulty; screenShake: number; brZone: boolean };
}

export const PRESETS: Record<Exclude<Preset, 'custom'>, Omit<GraphicsSettings, 'preset' | 'fov' | 'fpsLimit' | 'showFps' | 'motionBlur'>> = {
  low: { renderScale: 0.7, shadows: 0, textures: 0, effects: 0, antialias: false, viewDistance: 140, dynamicRes: true },
  medium: { renderScale: 0.9, shadows: 1, textures: 1, effects: 1, antialias: false, viewDistance: 200, dynamicRes: true },
  high: { renderScale: 1, shadows: 2, textures: 2, effects: 2, antialias: true, viewDistance: 280, dynamicRes: false },
  ultra: { renderScale: 1.25, shadows: 3, textures: 2, effects: 2, antialias: true, viewDistance: 360, dynamicRes: false },
};

export function isTouchDevice() {
  try {
    return typeof window !== 'undefined' && typeof navigator !== 'undefined' && (('ontouchstart' in window) || navigator.maxTouchPoints > 0) && !!window.matchMedia?.('(pointer: coarse)').matches;
  } catch { return false; }
}

/** Recommend a preset from device capabilities (cores, memory, GPU string, touch) */
export function recommendPreset(): { preset: Exclude<Preset, 'custom'>; reason: string } {
  try {
    const cores = navigator.hardwareConcurrency || 4;
    const mem = (navigator as unknown as { deviceMemory?: number }).deviceMemory || 4;
    let gpu = '';
    const c = document.createElement('canvas');
    const gl = c.getContext('webgl2') || c.getContext('webgl');
    if (gl) {
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      gpu = ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : String(gl.getParameter(gl.RENDERER));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
    }
    const mobile = isTouchDevice();
    const strongGpu = /RTX|RX ?[5-9]\d{3}|Radeon Pro|Apple M[1-9]|GeForce GTX 1[0-9]{3}|Arc A/i.test(gpu);
    const weakGpu = /Intel\(R\) (HD|UHD)|Mali-[GT][0-7]\d|Adreno \(TM\) [3-5]\d\d|PowerVR|SwiftShader|llvmpipe/i.test(gpu);
    let preset: Exclude<Preset, 'custom'> = 'medium';
    if (mobile) preset = mem >= 6 && !weakGpu ? 'medium' : 'low';
    else if (strongGpu && cores >= 8) preset = 'ultra';
    else if (!weakGpu && cores >= 6) preset = 'high';
    else if (weakGpu) preset = 'medium';
    return { preset, reason: `${mobile ? 'Mobile' : 'Desktop'} · ${cores} cores · ~${mem}GB · ${gpu ? gpu.slice(0, 48) : 'GPU unknown'}` };
  } catch {
    return { preset: 'medium', reason: 'Detection unavailable' };
  }
}

export function defaultSettings(): Settings {
  const rec = recommendPreset().preset;
  return {
    audio: { master: 0.8, music: 0.5, sfx: 0.9, dialogue: 0.8 },
    graphics: { preset: rec, ...PRESETS[rec], motionBlur: false, fpsLimit: 0, fov: 80, showFps: false },
    controls: {
      sensitivity: 1, adsSensitivity: 0.7, invertY: false, touchSensitivity: 1, touchMode: 'auto', leftHanded: false,
      buttonScale: 1, buttonOpacity: 0.75, fireOffsetX: 0, fireOffsetY: 0, toggleAds: false, bindings: { ...DEFAULT_BINDINGS },
    },
    gameplay: { damageNumbers: true, difficulty: 'regular', screenShake: 1, brZone: true },
  };
}

export interface LoadoutSlot { weapon: string; attachments: AttachConfig; skin: string }
export interface Loadout { name: string; primary: LoadoutSlot; secondary: LoadoutSlot }
export interface ScoreEntry { score: number; mode: ModeId; map: string; kills: number; date: number; result: string }
export interface Stats {
  matches: number; wins: number; kills: number; deaths: number; headshots: number; shots: number; hits: number;
  brWins: number; tdmWins: number; combatWins: number; rangeTargets: number; cratesOpened: number;
  bestAccuracy: number; longestShot: number; weaponsUsed: string[]; playTime: number;
}
export interface Profile {
  name: string; xp: number; operator: string; loadouts: Loadout[]; activeLoadout: number;
  stats: Stats; claimed: string[]; highscores: ScoreEntry[];
}

export function defaultLoadouts(): Loadout[] {
  return [
    { name: 'ASSAULT', primary: { weapon: 'ar01', attachments: { optic: 'opt_dot', grip: 'grip_vert' }, skin: 'default' }, secondary: { weapon: 'p01', attachments: {}, skin: 'default' } },
    { name: 'CQB', primary: { weapon: 'smg01', attachments: { muzzle: 'muz_comp' }, skin: 'default' }, secondary: { weapon: 'sg01', attachments: {}, skin: 'default' } },
    { name: 'RECON', primary: { weapon: 'sr01', attachments: {}, skin: 'default' }, secondary: { weapon: 'p01', attachments: {}, skin: 'default' } },
  ];
}
export function defaultProfile(): Profile {
  return {
    name: 'OPERATOR', xp: 0, operator: 'ghost', loadouts: defaultLoadouts(), activeLoadout: 0, claimed: [], highscores: [],
    stats: { matches: 0, wins: 0, kills: 0, deaths: 0, headshots: 0, shots: 0, hits: 0, brWins: 0, tdmWins: 0, combatWins: 0, rangeTargets: 0, cratesOpened: 0, bestAccuracy: 0, longestShot: 0, weaponsUsed: [], playTime: 0 },
  };
}

// ------------- persistence with integrity checksum (detects corruption; not a security boundary) -------------
const KEY_SETTINGS = 'opshadow.settings.v1';
const KEY_PROFILE = 'opshadow.profile.v1';
function hash(str: string) { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); }
function write(key: string, data: unknown) {
  try { const json = JSON.stringify(data); localStorage.setItem(key, JSON.stringify({ d: json, h: hash(json) })); } catch (e) { console.warn('Save failed', e); }
}
function read<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key); if (!raw) return null;
    const env = JSON.parse(raw) as { d: string; h: string };
    if (typeof env?.d !== 'string' || hash(env.d) !== env.h) { console.warn('Save data invalid — using defaults for', key); return null; }
    return JSON.parse(env.d) as T;
  } catch { return null; }
}

const clamp = (v: unknown, min: number, max: number, def: number) => (typeof v === 'number' && isFinite(v) ? Math.min(max, Math.max(min, v)) : def);
const bool = (v: unknown, def: boolean) => (typeof v === 'boolean' ? v : def);

function mergeSettings(raw: Partial<Settings> | null): Settings {
  const d = defaultSettings();
  if (!raw) return d;
  const a = raw.audio ?? d.audio, g = (raw.graphics ?? {}) as Partial<GraphicsSettings>, c = (raw.controls ?? {}) as Partial<Settings['controls']>, gp = (raw.gameplay ?? {}) as Partial<Settings['gameplay']>;
  const bindings = { ...DEFAULT_BINDINGS };
  if (c.bindings) for (const k of Object.keys(DEFAULT_BINDINGS) as Action[]) if (typeof c.bindings[k] === 'string') bindings[k] = c.bindings[k];
  return {
    audio: { master: clamp(a.master, 0, 1, d.audio.master), music: clamp(a.music, 0, 1, d.audio.music), sfx: clamp(a.sfx, 0, 1, d.audio.sfx), dialogue: clamp(a.dialogue, 0, 1, d.audio.dialogue) },
    graphics: {
      preset: (['low', 'medium', 'high', 'ultra', 'custom'] as Preset[]).includes(g.preset as Preset) ? (g.preset as Preset) : d.graphics.preset,
      renderScale: clamp(g.renderScale, 0.5, 1.5, d.graphics.renderScale), shadows: Math.round(clamp(g.shadows, 0, 3, d.graphics.shadows)),
      textures: Math.round(clamp(g.textures, 0, 2, d.graphics.textures)), effects: Math.round(clamp(g.effects, 0, 2, d.graphics.effects)),
      antialias: bool(g.antialias, d.graphics.antialias), motionBlur: bool(g.motionBlur, false), fpsLimit: [0, 30, 60, 120].includes(g.fpsLimit as number) ? (g.fpsLimit as number) : 0,
      fov: clamp(g.fov, 60, 110, 80), viewDistance: clamp(g.viewDistance, 100, 400, d.graphics.viewDistance), dynamicRes: bool(g.dynamicRes, d.graphics.dynamicRes), showFps: bool(g.showFps, false),
    },
    controls: {
      sensitivity: clamp(c.sensitivity, 0.1, 4, 1), adsSensitivity: clamp(c.adsSensitivity, 0.2, 1.5, 0.7), invertY: bool(c.invertY, false),
      touchSensitivity: clamp(c.touchSensitivity, 0.2, 3, 1), touchMode: (['auto', 'on', 'off'] as const).includes(c.touchMode as 'auto') ? (c.touchMode as 'auto') : 'auto',
      leftHanded: bool(c.leftHanded, false), buttonScale: clamp(c.buttonScale, 0.6, 1.6, 1), buttonOpacity: clamp(c.buttonOpacity, 0.2, 1, 0.75),
      fireOffsetX: clamp(c.fireOffsetX, -150, 150, 0), fireOffsetY: clamp(c.fireOffsetY, -150, 150, 0), toggleAds: bool(c.toggleAds, false), bindings,
    },
    gameplay: {
      damageNumbers: bool(gp.damageNumbers, true), difficulty: (['recruit', 'regular', 'veteran', 'elite'] as Difficulty[]).includes(gp.difficulty as Difficulty) ? (gp.difficulty as Difficulty) : 'regular',
      screenShake: clamp(gp.screenShake, 0, 1.5, 1), brZone: bool(gp.brZone, true),
    },
  };
}

function sanitizeSlot(s: Partial<LoadoutSlot> | undefined, fallback: LoadoutSlot, pistolOnly: boolean): LoadoutSlot {
  const id = s?.weapon && WEAPON_MAP[s.weapon] ? s.weapon : fallback.weapon;
  const def = getWeapon(id);
  if (pistolOnly !== undefined && ((pistolOnly && def.category !== 'PISTOL' && def.category !== 'SG') || (!pistolOnly && def.category === 'PISTOL'))) return fallback;
  return { weapon: id, attachments: sanitizeAttachments(def, s?.attachments), skin: SKINS.some(k => k.id === s?.skin) ? (s!.skin as string) : 'default' };
}

function mergeProfile(raw: Partial<Profile> | null): Profile {
  const d = defaultProfile();
  if (!raw) return d;
  const st = { ...d.stats, ...(raw.stats ?? {}) } as Stats;
  for (const k of Object.keys(d.stats) as (keyof Stats)[]) {
    if (k === 'weaponsUsed') st.weaponsUsed = Array.isArray(st.weaponsUsed) ? st.weaponsUsed.filter(w => typeof w === 'string' && WEAPON_MAP[w]) : [];
    else (st as unknown as Record<string, number>)[k] = clamp(st[k], 0, 1e9, 0);
  }
  const dl = defaultLoadouts();
  const loadouts = dl.map((def, i) => {
    const r = raw.loadouts?.[i];
    return { name: typeof r?.name === 'string' ? r.name.slice(0, 16) : def.name, primary: sanitizeSlot(r?.primary, def.primary, false), secondary: sanitizeSlot(r?.secondary, def.secondary, true) };
  });
  return {
    name: typeof raw.name === 'string' ? raw.name.slice(0, 16) : d.name,
    xp: clamp(raw.xp, 0, 1e8, 0),
    operator: OPERATORS.some(o => o.id === raw.operator) ? (raw.operator as string) : 'ghost',
    loadouts, activeLoadout: Math.round(clamp(raw.activeLoadout, 0, 2, 0)), stats: st,
    claimed: Array.isArray(raw.claimed) ? raw.claimed.filter(c => typeof c === 'string') : [],
    highscores: Array.isArray(raw.highscores) ? raw.highscores.filter(h => h && typeof h.score === 'number').slice(0, 30) : [],
  };
}

// ------------- simple observable store -------------
type Listener = () => void;
class Store {
  settings: Settings = mergeSettings(read<Settings>(KEY_SETTINGS));
  profile: Profile = mergeProfile(read<Profile>(KEY_PROFILE));
  private listeners = new Set<Listener>();
  version = 0;
  subscribe(l: Listener) { this.listeners.add(l); return () => { this.listeners.delete(l); }; }
  private emit() { this.version++; this.listeners.forEach(l => l()); }
  setSettings(fn: (s: Settings) => Settings) { this.settings = mergeSettings(fn(structuredClone(this.settings))); write(KEY_SETTINGS, this.settings); this.emit(); }
  setProfile(fn: (p: Profile) => Profile) { this.profile = mergeProfile(fn(structuredClone(this.profile))); write(KEY_PROFILE, this.profile); this.emit(); }
  resetSettings() { this.settings = defaultSettings(); write(KEY_SETTINGS, this.settings); this.emit(); }
  resetProfile() { this.profile = defaultProfile(); write(KEY_PROFILE, this.profile); this.emit(); }
  get level() { return levelFromXp(this.profile.xp).level; }
}
export const store = new Store();

export function statValue(p: Profile, key: StatKey): number {
  if (key === 'weaponsUsedCount') return p.stats.weaponsUsed.length;
  return (p.stats as unknown as Record<string, number>)[key] ?? 0;
}
export function missionProgress(p: Profile) {
  return MISSIONS.map(m => ({ ...m, value: Math.min(m.target, statValue(p, m.target === 0 ? 'kills' : m.stat)), done: statValue(p, m.stat) >= m.target, claimed: p.claimed.includes(m.id) }));
}

export interface MatchResult {
  mode: ModeId; map: string; victory: boolean; resultText: string; score: number; kills: number; deaths: number; headshots: number;
  shots: number; hits: number; time: number; placement?: number; cratesOpened: number; rangeTargets: number; longestShot: number;
  weaponsWithKills: string[]; teamScore?: [number, number];
}
export interface MatchRewards { xpEarned: number; levelBefore: number; levelAfter: number; newHigh: boolean; rank: number; accuracy: number }

export function applyMatchResult(r: MatchResult): MatchRewards {
  const levelBefore = store.level;
  const accuracy = r.shots > 0 ? Math.round((r.hits / r.shots) * 100) : 0;
  let xp = r.kills * 100 + r.headshots * 40 + Math.round(r.score / 8) + Math.round(r.time / 6);
  if (r.victory) xp += 600;
  if (r.mode === 'br' && r.placement) xp += Math.max(0, 12 - r.placement) * 40;
  xp = Math.max(25, Math.round(xp));
  let rank = -1; let newHigh = false;
  store.setProfile(p => {
    const s = p.stats;
    s.matches++; s.kills += r.kills; s.deaths += r.deaths; s.headshots += r.headshots; s.shots += r.shots; s.hits += r.hits;
    s.cratesOpened += r.cratesOpened; s.rangeTargets += r.rangeTargets; s.playTime += r.time;
    s.longestShot = Math.max(s.longestShot, Math.round(r.longestShot));
    if (r.shots >= 20) s.bestAccuracy = Math.max(s.bestAccuracy, accuracy);
    if (r.victory) { s.wins++; if (r.mode === 'br') s.brWins++; if (r.mode === 'tdm') s.tdmWins++; if (r.mode === 'combat') s.combatWins++; }
    s.weaponsUsed = Array.from(new Set([...s.weaponsUsed, ...r.weaponsWithKills]));
    p.xp += xp;
    const entry: ScoreEntry = { score: Math.round(r.score), mode: r.mode, map: r.map, kills: r.kills, date: Date.now(), result: r.resultText };
    const modeScores = p.highscores.filter(h => h.mode === r.mode);
    const others = p.highscores.filter(h => h.mode !== r.mode);
    modeScores.push(entry); modeScores.sort((a, b) => b.score - a.score);
    const top = modeScores.slice(0, 10);
    rank = top.indexOf(entry);
    newHigh = rank === 0 && entry.score > 0;
    p.highscores = [...others, ...top];
    return p;
  });
  return { xpEarned: xp, levelBefore, levelAfter: store.level, newHigh, rank, accuracy };
}
