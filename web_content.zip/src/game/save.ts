export type RunResult = {
  id: string;
  level: number;
  score: number;
  stars: number;
  time: number;
  bounces: number;
  maxCombo: number;
  date: string;
  daily?: boolean;
};

export type SaveData = {
  version: number;
  name: string;
  coins: number;
  totalScore: number;
  highestLevel: number;
  stars: Record<number, number>;
  bestScore: Record<number, number>;
  bestTime: Record<number, number>;
  skin: string;
  ownedSkins: string[];
  sound: boolean;
  haptics: boolean;
  runs: RunResult[];
  totalSmashes: number;
  totalBounces: number;
  dailyDate: string;
  dailyDone: boolean;
};

export const SAVE_KEY = "stackball.save.v1";

export const defaultSave = (): SaveData => ({
  version: 1,
  name: "You",
  coins: 250,
  totalScore: 0,
  highestLevel: 0,
  stars: {},
  bestScore: {},
  bestTime: {},
  skin: "nova",
  ownedSkins: ["nova"],
  sound: true,
  haptics: true,
  runs: [],
  totalSmashes: 0,
  totalBounces: 0,
  dailyDate: "",
  dailyDone: false,
});

export function loadSave(): SaveData {
  const base = defaultSave();
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return base;
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    return {
      ...base,
      ...parsed,
      stars: { ...(parsed.stars ?? {}) },
      bestScore: { ...(parsed.bestScore ?? {}) },
      bestTime: { ...(parsed.bestTime ?? {}) },
      runs: Array.isArray(parsed.runs) ? parsed.runs.slice(0, 40) : [],
      ownedSkins:
        Array.isArray(parsed.ownedSkins) && parsed.ownedSkins.includes("nova")
          ? parsed.ownedSkins
          : base.ownedSkins,
    };
  } catch {
    return base;
  }
}

export function persistSave(data: SaveData) {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(data));
  } catch {
    /* storage can be unavailable — game still works for this session */
  }
}

export function averageStars(stars: Record<number, number>) {
  const values = Object.values(stars);
  if (!values.length) return 0;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

export function countCleared(stars: Record<number, number>) {
  return Object.keys(stars).length;
}

export function totalStars(stars: Record<number, number>) {
  return Object.values(stars).reduce((a, b) => a + b, 0);
}

export function formatNumber(value: number): string {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(value >= 10_000_000 ? 0 : 1)}M`;
  if (value >= 10_000) return `${Math.round(value / 1000)}K`;
  return Math.round(value).toLocaleString("en-US");
}

export function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return "—";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  const tenths = Math.floor((seconds * 10) % 10);
  if (mins > 0) return `${mins}:${`${secs}`.padStart(2, "0")}`;
  return `${secs}.${tenths}s`;
}

export function formatDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "Recently";
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}
