export const SAVE_VERSION = 1;
const KEY = "fifty-locks-save-v1";

export type Save = {
  version: number;
  /** Next unsolved room, or 51 once the house is open. */
  frontier: number;
  viewing: number;
  elapsedMs: number;
  hints: Record<string, number>;
  seen: string[];
  mute: boolean;
  started: boolean;
};

export function freshSave(): Save {
  return {
    version: SAVE_VERSION,
    frontier: 1,
    viewing: 1,
    elapsedMs: 0,
    hints: {},
    seen: [],
    mute: false,
    started: false,
  };
}

function clamp(n: unknown, min: number, max: number, fallback: number) {
  const v = typeof n === "number" && Number.isFinite(n) ? Math.trunc(n) : fallback;
  return Math.min(max, Math.max(min, v));
}

export function loadSave(): Save {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return freshSave();
    const parsed = JSON.parse(raw) as Partial<Save>;
    if (parsed.version !== SAVE_VERSION) return freshSave();
    const base = freshSave();
    const hints: Record<string, number> = {};
    if (parsed.hints && typeof parsed.hints === "object") {
      for (const [k, v] of Object.entries(parsed.hints)) {
        if (/^\d+$/.test(k) && typeof v === "number" && v > 0) hints[k] = Math.min(3, Math.trunc(v));
      }
    }
    const seen = Array.isArray(parsed.seen)
      ? parsed.seen.filter((s): s is string => typeof s === "string").slice(0, 400)
      : [];
    return {
      ...base,
      frontier: clamp(parsed.frontier, 1, 51, 1),
      viewing: clamp(parsed.viewing, 1, 50, 1),
      elapsedMs: Math.max(0, Number(parsed.elapsedMs) || 0),
      hints,
      seen,
      mute: Boolean(parsed.mute),
      started: Boolean(parsed.started),
    };
  } catch {
    return freshSave();
  }
}

export function writeSave(save: Save) {
  try {
    const next: Save = {
      ...save,
      version: SAVE_VERSION,
      viewing: Math.min(save.viewing, Math.min(save.frontier, 50)),
    };
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* private mode or quota — keep playing in memory */
  }
}

export function formatDuration(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  if (h > 0) return `${h}:${pad(m)}:${pad(s)}`;
  return `${m}:${pad(s)}`;
}
