export type Settings = {
  best: number;
  soundOn: boolean;
  musicOn: boolean;
  volume: number;
};

const KEY = "sky-chirp-v1";

const FALLBACK: Settings = { best: 0, soundOn: true, musicOn: true, volume: 0.85 };

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...FALLBACK };
    const p = JSON.parse(raw) as Partial<Settings>;
    return {
      best: typeof p.best === "number" && p.best >= 0 ? Math.floor(p.best) : 0,
      soundOn: p.soundOn !== false,
      musicOn: p.musicOn !== false,
      volume: typeof p.volume === "number" ? Math.min(1, Math.max(0, p.volume)) : FALLBACK.volume,
    };
  } catch {
    return { ...FALLBACK };
  }
}

export function saveSettings(s: Settings) {
  try {
    localStorage.setItem(KEY, JSON.stringify({ v: 1, ...s }));
  } catch {
    /* private mode */
  }
}
