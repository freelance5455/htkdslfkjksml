import type { SaveState } from "./types";

export const SAVE_KEY = "lost-star-save-v1";
export const ADMIN_KEY = "lost-star-admin-v1";
export const SAVE_VERSION = 1;

export const defaultSettings: SaveState["settings"] = {
  quality: "high",
  qualityLocked: false,
  master: 0.85,
  music: 0.55,
  sfx: 0.7,
  textScale: 1,
  reduceMotion: false,
  vibrate: true,
  contrast: false,
  hudVisible: true,
};

export function defaultSave(): SaveState {
  return {
    version: SAVE_VERSION,
    phase: "title",
    act: 1,
    locationId: "seuil",
    timeLayer: "present",
    overlay: "none",
    activePuzzle: null,
    inspectId: null,
    dialogueId: null,
    cinematicId: null,
    inventory: [],
    flags: {},
    journalStage: {},
    choices: {},
    resonances: {},
    starIntensity: {},
    visits: {},
    hintsUsed: 0,
    discovered: [],
    solved: [],
    secrets: [],
    names: { player: "Lohen", searched: "Esteban" },
    settings: { ...defaultSettings },
    introStep: 0,
    endingStep: 0,
    lastSaveAt: 0,
  };
}

function migrate(raw: SaveState): SaveState {
  const base = defaultSave();
  return {
    ...base,
    ...raw,
    version: SAVE_VERSION,
    settings: { ...base.settings, ...(raw.settings ?? {}) },
    names: { ...base.names, ...(raw.names ?? {}) },
    flags: { ...raw.flags },
    journalStage: { ...raw.journalStage },
    choices: { ...raw.choices },
    resonances: { ...raw.resonances },
    starIntensity: { ...raw.starIntensity },
    visits: { ...raw.visits },
    inventory: Array.isArray(raw.inventory) ? raw.inventory : [],
    discovered: Array.isArray(raw.discovered) ? raw.discovered : [],
    solved: Array.isArray(raw.solved) ? raw.solved : [],
    secrets: Array.isArray(raw.secrets) ? raw.secrets : [],
  };
}

export function loadSave(): SaveState | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SaveState;
    if (!parsed || typeof parsed !== "object") return null;
    return migrate(parsed);
  } catch {
    return null;
  }
}

export function pickSave(state: SaveState): SaveState {
  return {
    version: SAVE_VERSION,
    phase: state.phase === "reconnect" || state.phase === "intro" ? "playing" : state.phase,
    act: state.act,
    locationId: state.locationId,
    timeLayer: state.timeLayer,
    overlay: "none",
    activePuzzle: null,
    inspectId: null,
    dialogueId: null,
    cinematicId: null,
    inventory: state.inventory,
    flags: state.flags,
    journalStage: state.journalStage,
    choices: state.choices,
    resonances: state.resonances,
    starIntensity: state.starIntensity,
    visits: state.visits,
    hintsUsed: state.hintsUsed,
    discovered: state.discovered,
    solved: state.solved,
    secrets: state.secrets,
    names: state.names,
    settings: state.settings,
    introStep: 0,
    endingStep: state.phase === "ending" ? state.endingStep : 0,
    lastSaveAt: Date.now(),
  };
}

export function writeSave(state: SaveState): void {
  if (typeof localStorage === "undefined") return;
  try {
    const blob = pickSave(state);
    const prev = localStorage.getItem(SAVE_KEY);
    if (prev) localStorage.setItem(SAVE_KEY + ":bak", prev);
    localStorage.setItem(SAVE_KEY, JSON.stringify(blob));
  } catch {
    /* ignore */
  }
}

export function clearSave(): void {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.removeItem(SAVE_KEY);
  } catch {
    /* ignore */
  }
}

export function exportSave(state: SaveState): string {
  return JSON.stringify({ ...state, overlay: "none" }, null, 2);
}

export function importSave(json: string): SaveState | null {
  try {
    const parsed = JSON.parse(json) as SaveState;
    return migrate(parsed);
  } catch {
    return null;
  }
}

export type AdminPersist = {
  names?: { player: string; searched: string };
  creditsLine1?: string;
  creditsLine2?: string;
  puzzleAnswers?: Record<string, string[]>;
};

export function loadAdmin(): AdminPersist {
  if (typeof localStorage === "undefined") return {};
  try {
    const raw = localStorage.getItem(ADMIN_KEY);
    return raw ? (JSON.parse(raw) as AdminPersist) : {};
  } catch {
    return {};
  }
}

export function writeAdmin(data: AdminPersist): void {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(ADMIN_KEY, JSON.stringify(data));
  } catch {
    /* ignore */
  }
}
