import { SKINS } from "@/game/skins";
import type { SaveData } from "@/game/types";

export const SAVE_KEY = "nitro-dune-save-v1";

export const DEFAULT_SAVE: SaveData = {
  skin: "viper",
  auto: true,
  mute: false,
  bestLap: 0,
  bestRace: 0,
};

export function readSave(): SaveData {
  if (typeof window === "undefined") return DEFAULT_SAVE;
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return DEFAULT_SAVE;
    const p = JSON.parse(raw) as Partial<SaveData>;
    const skin = typeof p.skin === "string" && SKINS.some((s) => s.id === p.skin) ? p.skin : DEFAULT_SAVE.skin;
    return {
      skin,
      auto: p.auto !== false,
      mute: p.mute === true,
      bestLap: typeof p.bestLap === "number" && p.bestLap > 0 ? p.bestLap : 0,
      bestRace: typeof p.bestRace === "number" && p.bestRace > 0 ? p.bestRace : 0,
    };
  } catch {
    return DEFAULT_SAVE;
  }
}
