export type CrosshairStyle = 'classic' | 'dot' | 'tactical' | 'precision' | 'dynamic' | 'minimal' | 'custom';
export type JoystickMode = 'dynamic' | 'fixed';
export type HUDPresetId = 'default' | 'classic' | 'four_finger' | 'five_finger' | 'minimal';

export interface HUDElementConfig {
  id: string;
  name: string;
  x: number; // percentage of viewport width (0 - 100)
  y: number; // percentage of viewport height (0 - 100)
  scale: number; // 0.6 - 1.8
  opacity: number; // 0.2 - 1.0
  visible: boolean;
}

export interface CrosshairConfig {
  style: CrosshairStyle;
  size: number;
  opacity: number;
  dynamicSpread: boolean;
  color: string;
}

export interface HUDLayoutConfig {
  preset: HUDPresetId;
  joystickMode: JoystickMode;
  crosshair: CrosshairConfig;
  elements: Record<string, HUDElementConfig>;
}

// Preset Definitions with Slide button added and Crosshair removed from movable elements
export const HUD_PRESETS: Record<HUDPresetId, HUDLayoutConfig> = {
  default: {
    preset: 'default',
    joystickMode: 'dynamic',
    crosshair: {
      style: 'tactical',
      size: 26,
      opacity: 0.9,
      dynamicSpread: true,
      color: '#ffffff',
    },
    elements: {
      joystick: { id: 'joystick', name: 'Movement Joystick', x: 12, y: 78, scale: 1.0, opacity: 0.75, visible: true },
      fire: { id: 'fire', name: 'Primary Fire', x: 88, y: 76, scale: 1.15, opacity: 0.9, visible: true },
      ads: { id: 'ads', name: 'Aim Down Sights', x: 77, y: 78, scale: 1.0, opacity: 0.85, visible: true },
      reload: { id: 'reload', name: 'Reload', x: 77, y: 90, scale: 0.95, opacity: 0.85, visible: true },
      jump: { id: 'jump', name: 'Jump', x: 88, y: 90, scale: 0.95, opacity: 0.85, visible: true },
      crouch: { id: 'crouch', name: 'Crouch', x: 69, y: 90, scale: 0.9, opacity: 0.8, visible: true },
      slide: { id: 'slide', name: 'Tactical Slide', x: 69, y: 78, scale: 0.9, opacity: 0.85, visible: true },
      sprint: { id: 'sprint', name: 'Sprint Toggle', x: 12, y: 56, scale: 0.85, opacity: 0.75, visible: true },
      switch_weapon: { id: 'switch_weapon', name: 'Weapon Switch / Ammo', x: 84, y: 60, scale: 1.0, opacity: 0.9, visible: true },
      melee: { id: 'melee', name: 'Quick Knife Melee', x: 60, y: 78, scale: 0.85, opacity: 0.8, visible: true },
      grenade: { id: 'grenade', name: 'Tactical Grenade', x: 52, y: 78, scale: 0.85, opacity: 0.8, visible: true },
      flashlight: { id: 'flashlight', name: 'Tactical Flashlight', x: 60, y: 90, scale: 0.85, opacity: 0.75, visible: true },
      health_bar: { id: 'health_bar', name: 'Health & Armor', x: 14, y: 93, scale: 1.0, opacity: 0.9, visible: true },
      wave_counter: { id: 'wave_counter', name: 'Round Banner', x: 14, y: 7, scale: 1.0, opacity: 0.9, visible: true },
      radar: { id: 'radar', name: 'Tactical Radar', x: 88, y: 8, scale: 1.0, opacity: 0.9, visible: true },
    },
  },

  classic: {
    preset: 'classic',
    joystickMode: 'fixed',
    crosshair: {
      style: 'classic',
      size: 26,
      opacity: 0.85,
      dynamicSpread: true,
      color: '#ffffff',
    },
    elements: {
      joystick: { id: 'joystick', name: 'Movement Joystick', x: 14, y: 76, scale: 1.05, opacity: 0.85, visible: true },
      fire: { id: 'fire', name: 'Primary Fire', x: 86, y: 76, scale: 1.2, opacity: 0.95, visible: true },
      ads: { id: 'ads', name: 'Aim Down Sights', x: 74, y: 76, scale: 1.0, opacity: 0.85, visible: true },
      reload: { id: 'reload', name: 'Reload', x: 86, y: 91, scale: 0.95, opacity: 0.85, visible: true },
      jump: { id: 'jump', name: 'Jump', x: 74, y: 91, scale: 0.95, opacity: 0.85, visible: true },
      crouch: { id: 'crouch', name: 'Crouch', x: 63, y: 91, scale: 0.9, opacity: 0.8, visible: true },
      slide: { id: 'slide', name: 'Tactical Slide', x: 63, y: 76, scale: 0.9, opacity: 0.85, visible: true },
      sprint: { id: 'sprint', name: 'Sprint Toggle', x: 14, y: 56, scale: 0.85, opacity: 0.75, visible: true },
      switch_weapon: { id: 'switch_weapon', name: 'Weapon Switch / Ammo', x: 84, y: 58, scale: 1.0, opacity: 0.9, visible: true },
      melee: { id: 'melee', name: 'Quick Knife Melee', x: 53, y: 76, scale: 0.85, opacity: 0.8, visible: true },
      grenade: { id: 'grenade', name: 'Tactical Grenade', x: 44, y: 76, scale: 0.85, opacity: 0.8, visible: true },
      flashlight: { id: 'flashlight', name: 'Tactical Flashlight', x: 53, y: 91, scale: 0.85, opacity: 0.75, visible: true },
      health_bar: { id: 'health_bar', name: 'Health & Armor', x: 14, y: 93, scale: 1.0, opacity: 0.9, visible: true },
      wave_counter: { id: 'wave_counter', name: 'Round Banner', x: 14, y: 7, scale: 1.0, opacity: 0.9, visible: true },
      radar: { id: 'radar', name: 'Tactical Radar', x: 88, y: 8, scale: 1.0, opacity: 0.9, visible: true },
    },
  },

  four_finger: {
    preset: 'four_finger',
    joystickMode: 'dynamic',
    crosshair: {
      style: 'precision',
      size: 28,
      opacity: 0.95,
      dynamicSpread: false,
      color: '#facc15',
    },
    elements: {
      joystick: { id: 'joystick', name: 'Movement Joystick', x: 14, y: 80, scale: 1.0, opacity: 0.7, visible: true },
      fire: { id: 'fire', name: 'Primary Fire', x: 14, y: 20, scale: 1.25, opacity: 0.95, visible: true },
      ads: { id: 'ads', name: 'Aim Down Sights', x: 86, y: 20, scale: 1.15, opacity: 0.95, visible: true },
      reload: { id: 'reload', name: 'Reload', x: 86, y: 84, scale: 1.0, opacity: 0.85, visible: true },
      jump: { id: 'jump', name: 'Jump', x: 74, y: 84, scale: 1.0, opacity: 0.85, visible: true },
      crouch: { id: 'crouch', name: 'Crouch', x: 63, y: 84, scale: 0.9, opacity: 0.8, visible: true },
      slide: { id: 'slide', name: 'Tactical Slide', x: 63, y: 70, scale: 0.95, opacity: 0.85, visible: true },
      sprint: { id: 'sprint', name: 'Sprint Toggle', x: 26, y: 80, scale: 0.85, opacity: 0.75, visible: true },
      switch_weapon: { id: 'switch_weapon', name: 'Weapon Switch / Ammo', x: 86, y: 64, scale: 0.95, opacity: 0.9, visible: true },
      melee: { id: 'melee', name: 'Quick Knife Melee', x: 74, y: 70, scale: 0.85, opacity: 0.8, visible: true },
      grenade: { id: 'grenade', name: 'Tactical Grenade', x: 52, y: 70, scale: 0.85, opacity: 0.8, visible: true },
      flashlight: { id: 'flashlight', name: 'Tactical Flashlight', x: 52, y: 84, scale: 0.8, opacity: 0.7, visible: true },
      health_bar: { id: 'health_bar', name: 'Health & Armor', x: 14, y: 94, scale: 0.9, opacity: 0.85, visible: true },
      wave_counter: { id: 'wave_counter', name: 'Round Banner', x: 38, y: 7, scale: 1.0, opacity: 0.9, visible: true },
      radar: { id: 'radar', name: 'Tactical Radar', x: 62, y: 7, scale: 0.9, opacity: 0.85, visible: true },
    },
  },

  five_finger: {
    preset: 'five_finger',
    joystickMode: 'dynamic',
    crosshair: {
      style: 'dynamic',
      size: 28,
      opacity: 0.95,
      dynamicSpread: true,
      color: '#38bdf8',
    },
    elements: {
      joystick: { id: 'joystick', name: 'Movement Joystick', x: 12, y: 80, scale: 0.95, opacity: 0.65, visible: true },
      fire: { id: 'fire', name: 'Primary Fire', x: 14, y: 18, scale: 1.25, opacity: 0.95, visible: true },
      ads: { id: 'ads', name: 'Aim Down Sights', x: 86, y: 18, scale: 1.2, opacity: 0.95, visible: true },
      jump: { id: 'jump', name: 'Jump', x: 74, y: 18, scale: 1.0, opacity: 0.85, visible: true },
      reload: { id: 'reload', name: 'Reload', x: 88, y: 82, scale: 1.0, opacity: 0.85, visible: true },
      crouch: { id: 'crouch', name: 'Crouch', x: 76, y: 82, scale: 0.9, opacity: 0.8, visible: true },
      slide: { id: 'slide', name: 'Tactical Slide', x: 76, y: 68, scale: 0.95, opacity: 0.85, visible: true },
      sprint: { id: 'sprint', name: 'Sprint Toggle', x: 24, y: 80, scale: 0.85, opacity: 0.75, visible: true },
      switch_weapon: { id: 'switch_weapon', name: 'Weapon Switch / Ammo', x: 86, y: 62, scale: 0.95, opacity: 0.9, visible: true },
      melee: { id: 'melee', name: 'Quick Knife Melee', x: 65, y: 68, scale: 0.85, opacity: 0.8, visible: true },
      grenade: { id: 'grenade', name: 'Tactical Grenade', x: 55, y: 68, scale: 0.85, opacity: 0.8, visible: true },
      flashlight: { id: 'flashlight', name: 'Tactical Flashlight', x: 65, y: 82, scale: 0.8, opacity: 0.7, visible: true },
      health_bar: { id: 'health_bar', name: 'Health & Armor', x: 14, y: 94, scale: 0.9, opacity: 0.85, visible: true },
      wave_counter: { id: 'wave_counter', name: 'Round Banner', x: 40, y: 7, scale: 0.95, opacity: 0.9, visible: true },
      radar: { id: 'radar', name: 'Tactical Radar', x: 60, y: 7, scale: 0.9, opacity: 0.85, visible: true },
    },
  },

  minimal: {
    preset: 'minimal',
    joystickMode: 'dynamic',
    crosshair: {
      style: 'minimal',
      size: 22,
      opacity: 0.75,
      dynamicSpread: false,
      color: '#ffffff',
    },
    elements: {
      joystick: { id: 'joystick', name: 'Movement Joystick', x: 12, y: 80, scale: 0.85, opacity: 0.4, visible: true },
      fire: { id: 'fire', name: 'Primary Fire', x: 88, y: 78, scale: 1.0, opacity: 0.5, visible: true },
      ads: { id: 'ads', name: 'Aim Down Sights', x: 78, y: 80, scale: 0.9, opacity: 0.5, visible: true },
      reload: { id: 'reload', name: 'Reload', x: 78, y: 92, scale: 0.85, opacity: 0.5, visible: true },
      jump: { id: 'jump', name: 'Jump', x: 88, y: 92, scale: 0.85, opacity: 0.5, visible: true },
      crouch: { id: 'crouch', name: 'Crouch', x: 68, y: 92, scale: 0.8, opacity: 0.45, visible: true },
      slide: { id: 'slide', name: 'Tactical Slide', x: 68, y: 80, scale: 0.8, opacity: 0.45, visible: true },
      sprint: { id: 'sprint', name: 'Sprint Toggle', x: 12, y: 62, scale: 0.8, opacity: 0.45, visible: false },
      switch_weapon: { id: 'switch_weapon', name: 'Weapon Switch / Ammo', x: 86, y: 64, scale: 0.9, opacity: 0.6, visible: true },
      melee: { id: 'melee', name: 'Quick Knife Melee', x: 59, y: 80, scale: 0.75, opacity: 0.45, visible: true },
      grenade: { id: 'grenade', name: 'Tactical Grenade', x: 50, y: 80, scale: 0.75, opacity: 0.45, visible: true },
      flashlight: { id: 'flashlight', name: 'Tactical Flashlight', x: 59, y: 92, scale: 0.75, opacity: 0.4, visible: true },
      health_bar: { id: 'health_bar', name: 'Health & Armor', x: 14, y: 95, scale: 0.85, opacity: 0.7, visible: true },
      wave_counter: { id: 'wave_counter', name: 'Round Banner', x: 14, y: 7, scale: 0.9, opacity: 0.8, visible: true },
      radar: { id: 'radar', name: 'Tactical Radar', x: 88, y: 8, scale: 0.85, opacity: 0.7, visible: true },
    },
  },
};

const STORAGE_KEY = 'blackout_zombies_hud_layout_v2';

export class HUDManager {
  private static currentConfig: HUDLayoutConfig | null = null;

  static load(): HUDLayoutConfig {
    if (this.currentConfig) return this.currentConfig;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        const merged = JSON.parse(JSON.stringify(HUD_PRESETS.default));
        merged.preset = parsed.preset || 'default';
        merged.joystickMode = parsed.joystickMode || 'dynamic';
        if (parsed.crosshair) merged.crosshair = { ...merged.crosshair, ...parsed.crosshair };
        if (parsed.elements) {
          for (const key of Object.keys(parsed.elements)) {
            if (key === 'crosshair') continue; // Requirement 2: Crosshair must NOT be a movable element
            merged.elements[key] = { ...merged.elements[key], ...parsed.elements[key] };
          }
        }
        // Delete crosshair if previously stored as element
        delete merged.elements.crosshair;
        this.currentConfig = merged;
        return merged;
      }
    } catch (e) {
      console.warn('Failed to load HUD config from localStorage', e);
    }

    this.currentConfig = JSON.parse(JSON.stringify(HUD_PRESETS.default));
    return this.currentConfig!;
  }

  static save(config: HUDLayoutConfig) {
    this.currentConfig = JSON.parse(JSON.stringify(config));
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
    } catch (e) {
      console.warn('Failed to save HUD config', e);
    }
  }

  static reset(preset: HUDPresetId = 'default'): HUDLayoutConfig {
    const config = JSON.parse(JSON.stringify(HUD_PRESETS[preset] || HUD_PRESETS.default));
    this.save(config);
    return config;
  }
}
