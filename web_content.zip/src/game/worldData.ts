import { noise2 } from "./noise";

export type V2 = [number, number];

export const WORLD_HALF = 512;
export const CHUNK = 64;
export const CHUNK_RES = 32; // segments per chunk => 2 units per cell
export const CHUNKS_PER_SIDE = (WORLD_HALF * 2) / CHUNK;

/** z position of the northern plateau cliff for a given x */
export function cliffZ(x: number) {
  return -200 + 16 * noise2(x * 0.011, 3.7);
}
/** width of the cliff transition (narrow = sheer wall, wide = gentle ramp) */
export function cliffWidth(x: number) {
  const ramp = Math.min(
    Math.max((x - 70) / 50, 0),
    1
  ) * (1 - Math.min(Math.max((x - 200) / 60, 0), 1));
  return 8 + ramp * 95;
}

export interface MountainDef {
  x: number;
  z: number;
  r: number;
  h: number;
  name: string;
}
export const MOUNTAINS: MountainDef[] = [
  { x: 160, z: -340, r: 120, h: 62, name: "Pico do Norte" },
  { x: 320, z: 255, r: 115, h: 55, name: "Montes do Leste" },
  { x: -350, z: -300, r: 115, h: 60, name: "Serra Oeste" },
  { x: -200, z: -110, r: 55, h: 22, name: "Colina da Floresta" },
  { x: -250, z: 285, r: 60, h: 13, name: "Colina do Templo" },
  { x: 175, z: 105, r: 45, h: 10, name: "Morro Verde" },
];

export type RoadKind = 0 | 1 | 2; // 0 dirt, 1 stone, 2 trail
export interface RoadDef {
  pts: V2[];
  w: number;
  kind: RoadKind;
}

const CZ = (x: number) => cliffZ(x);

export const ROADS: RoadDef[] = [
  // Main east-west road
  { kind: 0, w: 5, pts: [[-380, 30], [-300, 12], [-200, 30], [-120, 15], [-40, 22], [25, 15], [88, 22], [160, 0], [240, -20], [320, -10], [362, -28]] },
  // North road climbing the plateau ramp
  { kind: 0, w: 4.5, pts: [[88, 22], [100, -40], [112, -110], [128, -160], [140, -205], [150, -240], [125, -280], [90, -310], [40, -330], [-40, -340], [-78, -352]] },
  // South road to the big lake
  { kind: 0, w: 4.5, pts: [[88, 22], [70, 90], [80, 150], [110, 210], [118, 245]] },
  // Summit trail
  { kind: 2, w: 2.6, pts: [[150, -240], [180, -262], [168, -290], [188, -312], [172, -330], [160, -340]] },
  // Stone path to the waterfall pool
  { kind: 1, w: 3, pts: [[100, -40], [40, -90], [0, -130], [-16, CZ(-40) + 30]] },
  // Waterfall top trail
  { kind: 2, w: 2.5, pts: [[-40, -340], [-30, -290], [-45, -240], [-58, CZ(-58) - 12]] },
  // Temple stone path
  { kind: 1, w: 3, pts: [[-150, 18], [-170, 100], [-200, 180], [-238, 250], [-250, 268]] },
  // Old bridge trail
  { kind: 2, w: 3, pts: [[72, 85], [40, 80], [-40, 90], [-150, 110], [-172, 104]] },
  // Hidden lagoon trail
  { kind: 2, w: 2, pts: [[-200, 30], [-232, 5], [-262, 28], [-268, 40]] },
  // Western ruins
  { kind: 2, w: 2.5, pts: [[-300, 12], [-312, -25], [-300, -48]] },
  // Western cave trail
  { kind: 2, w: 2.5, pts: [[-300, -48], [-322, -130], [-305, -200], [-310, -246]] },
  // Forest hill trail
  { kind: 2, w: 2.5, pts: [[-120, 15], [-150, -35], [-175, -70], [-190, -95], [-200, -110]] },
  // East road
  { kind: 0, w: 3.5, pts: [[160, 0], [195, 70], [230, 138]] },
  // East cave trail
  { kind: 2, w: 2.5, pts: [[230, 138], [258, 180], [279, 205]] },
  // Camp trail
  { kind: 2, w: 2, pts: [[240, -20], [228, -38]] },
  // Shrine path
  { kind: 1, w: 2.5, pts: [[90, -310], [64, -292]] },
  // Peak cave trail
  { kind: 2, w: 2, pts: [[168, -290], [138, -304]] },
];

export interface RiverDef {
  pts: V2[];
  hw: number[]; // half widths
  levels?: number[];
}
export const WATERFALL_X = -40;
export const RIVERS: RiverDef[] = [
  // Upper river: mountain lake -> cliff edge
  {
    pts: [[-110, -345], [-95, -310], [-80, -280], [-60, -250], [-46, -226], [WATERFALL_X, CZ(WATERFALL_X) - 3]],
    hw: [3, 3.2, 3.5, 3.8, 4, 4.2],
  },
  // Lower river: waterfall pool -> big south lake
  {
    pts: [[WATERFALL_X, CZ(WATERFALL_X) + 16], [-35, -150], [-15, -110], [25, -60], [20, -10], [-10, 50], [-5, 120], [50, 180], [100, 235], [135, 285]],
    hw: [5, 5.5, 6, 6.5, 7, 7, 7.5, 8, 8.5, 9],
  },
];

export interface LakeDef {
  x: number;
  z: number;
  r: number;
  depth: number;
  name: string;
  ducks?: boolean;
  level?: number;
  lilies?: boolean;
  bank?: number;
}
export const LAKES: LakeDef[] = [
  { x: -110, z: -345, r: 28, depth: 4, name: "Lago da Montanha", ducks: true },
  { x: WATERFALL_X, z: CZ(WATERFALL_X) + 16, r: 12, depth: 3.5, name: "Poço da Cachoeira", bank: 4 },
  { x: -275, z: 55, r: 14, depth: 2.5, name: "Lagoa Escondida", lilies: true },
  { x: -160, z: 150, r: 12, depth: 2, name: "Lagoa dos Juncos", lilies: true },
  { x: 262, z: 60, r: 16, depth: 2.5, name: "Lagoa do Prado", ducks: true },
  { x: 330, z: 150, r: 12, depth: 2.5, name: "Lagoa da Encosta" },
  { x: 205, z: -300, r: 10, depth: 2, name: "Lagoa Alta" },
  { x: 140, z: 318, r: 55, depth: 6, name: "Lago Espelho", ducks: true },
];

export type StructType = "house" | "cabin" | "camp" | "ruins" | "temple" | "shrine" | "well" | "farm";
export interface StructDef {
  type: StructType;
  x: number;
  z: number;
  rot: number;
  pad: number;
  seed: number;
}
export const STRUCTS: StructDef[] = [
  { type: "house", x: 68, z: -8, rot: 0, pad: 8, seed: 1 },
  { type: "house", x: 115, z: -5, rot: 0.25, pad: 8, seed: 2 },
  { type: "house", x: 55, z: 50, rot: Math.PI, pad: 8, seed: 3 },
  { type: "house", x: 108, z: 44, rot: Math.PI - 0.2, pad: 8, seed: 4 },
  { type: "well", x: 82, z: 6, rot: 0, pad: 3.5, seed: 5 },
  { type: "farm", x: -120, z: 42, rot: Math.PI, pad: 9, seed: 6 },
  { type: "cabin", x: -55, z: -305, rot: 0.5, pad: 7, seed: 7 },
  { type: "cabin", x: 96, z: 252, rot: Math.PI * 0.85, pad: 7, seed: 8 },
  { type: "camp", x: 225, z: -46, rot: 0.3, pad: 7, seed: 9 },
  { type: "camp", x: -262, z: 22, rot: 2, pad: 5, seed: 10 },
  { type: "ruins", x: -300, z: -62, rot: 0.4, pad: 12, seed: 11 },
  { type: "ruins", x: 232, z: 152, rot: -0.3, pad: 11, seed: 12 },
  { type: "temple", x: -250, z: 285, rot: 0, pad: 14, seed: 13 },
  { type: "shrine", x: 60, z: -286, rot: 0.9, pad: 6, seed: 14 },
];

export interface CaveDef {
  x: number;
  z: number;
  large: boolean;
  name: string;
  seed: number;
  facing?: number;
}
export const CAVES: CaveDef[] = [
  { x: -16, z: CZ(-16) + 6, large: false, name: "Gruta da Cachoeira", seed: 101 },
  { x: 284, z: 212, large: true, name: "Caverna do Leste", seed: 202 },
  { x: -312, z: -254, large: true, name: "Caverna da Serra", seed: 303 },
  { x: 134, z: -306, large: false, name: "Gruta do Pico", seed: 404 },
  { x: -188, z: -96, large: false, name: "Toca da Colina", seed: 505 },
];

export interface ViewpointDef {
  x: number;
  z: number;
  name: string;
}
export const VIEWPOINTS: ViewpointDef[] = [
  { x: 160, z: -340, name: "Mirante do Pico do Norte" },
  { x: -58, z: CZ(-58) - 12, name: "Mirante da Cachoeira" },
  { x: -200, z: -110, name: "Mirante da Colina" },
];

export interface LocationDef {
  name: string;
  x: number;
  z: number;
  r: number;
}
export const LOCATIONS: LocationDef[] = [
  { name: "Vila do Rio", x: 85, z: 20, r: 45 },
  { name: "Cachoeira do Véu", x: WATERFALL_X, z: CZ(WATERFALL_X) + 8, r: 38 },
  { name: "Lago Espelho", x: 140, z: 318, r: 75 },
  { name: "Lagoa Escondida", x: -275, z: 55, r: 26 },
  { name: "Floresta Sombria", x: -250, z: -10, r: 110 },
  { name: "Bosque das Bétulas", x: 270, z: -60, r: 80 },
  { name: "Acampamento do Viajante", x: 225, z: -46, r: 18 },
  { name: "Ruínas da Floresta", x: -300, z: -62, r: 25 },
  { name: "Templo da Ametista", x: -250, z: 285, r: 32 },
  { name: "Pico do Norte", x: 160, z: -340, r: 30 },
  { name: "Colina da Floresta", x: -200, z: -110, r: 22 },
  { name: "Lago da Montanha", x: -110, z: -345, r: 42 },
  { name: "Planalto Norte", x: 20, z: -300, r: 90 },
  { name: "Ruínas do Leste", x: 232, z: 152, r: 24 },
  { name: "Santuário do Planalto", x: 60, z: -286, r: 18 },
  { name: "Cabana do Lago", x: 96, z: 252, r: 20 },
  { name: "Montes do Leste", x: 320, z: 255, r: 70 },
  { name: "Serra Oeste", x: -350, z: -300, r: 70 },
  { name: "Lagoa do Prado", x: 262, z: 60, r: 26 },
  { name: "Ponte Velha", x: -8, z: 86, r: 16 },
  { name: "Fazenda do Oeste", x: -120, z: 42, r: 20 },
  ...CAVES.map((c) => ({ name: c.name, x: c.x, z: c.z, r: 14 })),
];
