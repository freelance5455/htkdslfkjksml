/**
 * Medieval Audio Manager for "La Conquista"
 * Centralized Web Audio API synthesizer for rich medieval soundscapes and feedback.
 */

export type SoundEffectType =
  | 'click'
  | 'build'
  | 'constructionComplete'
  | 'research'
  | 'researchComplete'
  | 'trainingComplete'
  | 'horn'
  | 'victory'
  | 'battleVictory'
  | 'defeat'
  | 'battleDefeat'
  | 'coins'
  | 'heal'
  | 'parliamentMessage'
  | 'decreeEnacted'
  | 'alert';

class MedievalAudioManager {
  private audioCtx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private isEnabled: boolean = true;
  private volume: number = 0.7;

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        const savedEnabled = localStorage.getItem('la_conquista_sound_enabled');
        if (savedEnabled !== null) {
          this.isEnabled = savedEnabled === 'true';
        }
        const savedVol = localStorage.getItem('la_conquista_sound_volume');
        if (savedVol !== null) {
          const parsed = parseFloat(savedVol);
          if (!isNaN(parsed) && parsed >= 0 && parsed <= 1) {
            this.volume = parsed;
          }
        }
      } catch {
        // LocalStorage fallback
      }
    }
  }

  /**
   * Initializes or returns the shared AudioContext.
   */
  private getContext(): { ctx: AudioContext; masterGain: GainNode } | null {
    if (typeof window === 'undefined') return null;
    try {
      if (!this.audioCtx) {
        const AudioCtxClass =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!AudioCtxClass) return null;
        this.audioCtx = new AudioCtxClass();
        this.masterGain = this.audioCtx.createGain();
        this.masterGain.gain.setValueAtTime(this.volume, this.audioCtx.currentTime);
        this.masterGain.connect(this.audioCtx.destination);
      }
      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume().catch(() => {});
      }
      return { ctx: this.audioCtx, masterGain: this.masterGain! };
    } catch {
      return null;
    }
  }

  public getEnabled(): boolean {
    return this.isEnabled;
  }

  public setEnabled(enabled: boolean): void {
    this.isEnabled = enabled;
    try {
      localStorage.setItem('la_conquista_sound_enabled', enabled ? 'true' : 'false');
    } catch {}
  }

  public toggleMute(): boolean {
    this.setEnabled(!this.isEnabled);
    return this.isEnabled;
  }

  public getVolume(): number {
    return this.volume;
  }

  public setVolume(vol: number): void {
    const clamped = Math.max(0, Math.min(1, vol));
    this.volume = clamped;
    if (this.audioCtx && this.masterGain) {
      this.masterGain.gain.setValueAtTime(clamped, this.audioCtx.currentTime);
    }
    try {
      localStorage.setItem('la_conquista_sound_volume', clamped.toString());
    } catch {}
  }

  /**
   * Central sound playback dispatcher.
   */
  public play(type: SoundEffectType): void {
    if (!this.isEnabled) return;
    const contextData = this.getContext();
    if (!contextData) return;
    const { ctx, masterGain } = contextData;
    const now = ctx.currentTime;

    switch (type) {
      case 'constructionComplete':
      case 'build':
        this.synthesizeConstructionComplete(ctx, masterGain, now);
        break;
      case 'battleVictory':
      case 'victory':
        this.synthesizeBattleVictory(ctx, masterGain, now);
        break;
      case 'parliamentMessage':
      case 'decreeEnacted':
        this.synthesizeParliamentMessage(ctx, masterGain, now);
        break;
      case 'battleDefeat':
      case 'defeat':
        this.synthesizeBattleDefeat(ctx, masterGain, now);
        break;
      case 'researchComplete':
      case 'research':
        this.synthesizeResearchComplete(ctx, masterGain, now);
        break;
      case 'trainingComplete':
        this.synthesizeTrainingComplete(ctx, masterGain, now);
        break;
      case 'coins':
        this.synthesizeCoins(ctx, masterGain, now);
        break;
      case 'horn':
        this.synthesizeWarHorn(ctx, masterGain, now);
        break;
      case 'heal':
        this.synthesizeHealing(ctx, masterGain, now);
        break;
      case 'alert':
        this.synthesizeAlert(ctx, masterGain, now);
        break;
      case 'click':
      default:
        this.synthesizeClick(ctx, masterGain, now);
        break;
    }
  }

  private synthesizeConstructionComplete(ctx: AudioContext, dest: GainNode, now: number): void {
    [0, 0.09].forEach((offset, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = i === 0 ? 'triangle' : 'square';
      osc.frequency.setValueAtTime(180 - i * 30, now + offset);
      osc.frequency.exponentialRampToValueAtTime(70, now + offset + 0.08);
      gain.gain.setValueAtTime(0.18, now + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.1);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(now + offset);
      osc.stop(now + offset + 0.1);
    });

    const bellNotes = [261.63, 329.63, 392.0, 523.25, 659.25];
    bellNotes.forEach((freq, idx) => {
      const startTime = now + 0.2 + idx * 0.07;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.12 / (idx + 1), startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.7);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(startTime);
      osc.stop(startTime + 0.7);
    });
  }

  private synthesizeBattleVictory(ctx: AudioContext, dest: GainNode, now: number): void {
    const melody = [
      { freq: 196.0, start: 0, dur: 0.14 },
      { freq: 261.63, start: 0.12, dur: 0.14 },
      { freq: 329.63, start: 0.24, dur: 0.14 },
      { freq: 392.0, start: 0.36, dur: 0.18 },
      { freq: 523.25, start: 0.5, dur: 0.8 },
      { freq: 659.25, start: 0.52, dur: 0.75 },
    ];
    melody.forEach((note) => {
      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(note.freq, now + note.start);
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1200, now + note.start);
      filter.frequency.exponentialRampToValueAtTime(800, now + note.start + note.dur);
      gain.gain.setValueAtTime(0.15, now + note.start);
      gain.gain.exponentialRampToValueAtTime(0.001, now + note.start + note.dur);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(dest);
      osc.start(now + note.start);
      osc.stop(now + note.start + note.dur);
    });
  }

  private synthesizeParliamentMessage(ctx: AudioContext, dest: GainNode, now: number): void {
    const chimes = [587.33, 880.0, 1174.66];
    chimes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const startTime = now + idx * 0.09;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.14, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.6);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(startTime);
      osc.stop(startTime + 0.6);
    });

    const decreeChord = [293.66, 369.99, 440.0];
    decreeChord.forEach((freq) => {
      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();
      const startTime = now + 0.26;
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1000, startTime);
      gain.gain.setValueAtTime(0.1, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.7);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(dest);
      osc.start(startTime);
      osc.stop(startTime + 0.7);
    });
  }

  private synthesizeBattleDefeat(ctx: AudioContext, dest: GainNode, now: number): void {
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.6);
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(600, now);
    gain.gain.setValueAtTime(0.16, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(dest);
    osc.start(now);
    osc.stop(now + 0.65);
  }

  private synthesizeResearchComplete(ctx: AudioContext, dest: GainNode, now: number): void {
    const notes = [329.63, 493.88, 659.25, 987.77, 1318.51];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const startTime = now + idx * 0.08;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.09, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.45);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(startTime);
      osc.stop(startTime + 0.45);
    });
  }

  private synthesizeTrainingComplete(ctx: AudioContext, dest: GainNode, now: number): void {
    [0, 0.08, 0.16].forEach((offset, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(140 + idx * 20, now + offset);
      osc.frequency.exponentialRampToValueAtTime(60, now + offset + 0.07);
      gain.gain.setValueAtTime(0.15, now + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.07);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(now + offset);
      osc.stop(now + offset + 0.07);
    });

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1800, now + 0.2);
    osc.frequency.exponentialRampToValueAtTime(1200, now + 0.35);
    gain.gain.setValueAtTime(0.08, now + 0.2);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
    osc.connect(gain);
    gain.connect(dest);
    osc.start(now + 0.2);
    osc.stop(now + 0.4);
  }

  private synthesizeCoins(ctx: AudioContext, dest: GainNode, now: number): void {
    [0, 0.07, 0.14, 0.21].forEach((delay, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(950 + idx * 210, now + delay);
      gain.gain.setValueAtTime(0.1, now + delay);
      gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.12);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(now + delay);
      osc.stop(now + delay + 0.12);
    });
  }

  private synthesizeWarHorn(ctx: AudioContext, dest: GainNode, now: number): void {
    [
      { freq: 146.83, start: 0, dur: 0.25 },
      { freq: 220.0, start: 0.2, dur: 0.55 },
    ].forEach((note) => {
      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(note.freq, now + note.start);
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(750, now + note.start);
      gain.gain.setValueAtTime(0.14, now + note.start);
      gain.gain.exponentialRampToValueAtTime(0.001, now + note.start + note.dur);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(dest);
      osc.start(now + note.start);
      osc.stop(now + note.start + note.dur);
    });
  }

  private synthesizeHealing(ctx: AudioContext, dest: GainNode, now: number): void {
    const harpNotes = [329.63, 392.0, 493.88, 587.33, 783.99];
    harpNotes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const startTime = now + idx * 0.08;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.09, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.4);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(startTime);
      osc.stop(startTime + 0.4);
    });
  }

  private synthesizeAlert(ctx: AudioContext, dest: GainNode, now: number): void {
    [440, 659.25].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const startTime = now + idx * 0.12;
      osc.type = 'square';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.08, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.2);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(startTime);
      osc.stop(startTime + 0.2);
    });
  }

  private synthesizeClick(ctx: AudioContext, dest: GainNode, now: number): void {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(300, now + 0.04);
    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
    osc.connect(gain);
    gain.connect(dest);
    osc.start(now);
    osc.stop(now + 0.04);
  }
}

export const audioManager = new MedievalAudioManager();
