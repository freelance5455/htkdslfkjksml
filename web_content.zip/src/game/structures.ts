import * as THREE from "three";
import { GeoBuilder } from "./geo";
import { mulberry32 } from "./noise";
import { STRUCTS, CAVES, VIEWPOINTS, LAKES, WATERFALL_X, cliffZ, StructDef } from "./worldData";
import { bridges, bridgeDeck, heightAt, baseHeight, pads, sampleTerrain, newSample } from "./terrain";
import { addStatic, boxCol, circleCol } from "./physics";
import * as V from "./vegetation";

export type InteractKind = "rest" | "cave" | "view" | "lore" | "crystal" | "exit" | "secret" | "chest";
export interface Interactable {
  id: string;
  x: number;
  y: number;
  z: number;
  r: number;
  label: string;
  kind: InteractKind;
  data?: any;
}

export interface Fire {
  x: number;
  y: number;
  z: number;
  mesh: THREE.Group;
}
export interface LightSpot {
  x: number;
  y: number;
  z: number;
  color: number;
  night: boolean;
}

export const LORE: Record<string, [string, string]> = {
  ruinsW: ["Ruínas da Floresta", "Pedras cobertas de musgo formam um antigo salão. Uma inscrição quase apagada diz: \"Onde a água cai, a montanha guarda um segredo\"."],
  ruinsE: ["Ruínas do Leste", "Colunas partidas apontam para as montanhas do leste. Marcas de cristais roxos foram entalhadas em cada pedra, como um mapa das cavernas."],
  temple: ["Templo da Ametista", "O cristal no altar pulsa com uma luz suave. Você sente a mesma energia que corre pelos cristais dos seus braços. Um fragmento se desprende e se junta a você."],
  templeDone: ["Templo da Ametista", "O cristal do altar brilha em silêncio. Ele já compartilhou sua energia com você."],
  shrine: ["Santuário do Planalto", "Uma pequena estátua de pedra observa o vale. Aos seus pés, oferendas de flores secas e uma frase: \"Dos altos, tudo se vê\"."],
  well: ["Poço da Vila", "A água é fresca e cristalina. Moedas antigas brilham no fundo."],
};

const STONE: [number, number, number] = [0.55, 0.53, 0.5];
const MOSS: [number, number, number] = [0.33, 0.45, 0.2];

export interface StructuresResult {
  group: THREE.Group;
  interactables: Interactable[];
  fires: Fire[];
  lights: LightSpot[];
  windowMat: THREE.MeshBasicMaterial;
  caveEntrances: { x: number; y: number; z: number; fx: number; fz: number; idx: number }[];
}

export function buildStructures(structMat: THREE.Material, vegMat: THREE.Material): StructuresResult {
  const b = new GeoBuilder();
  const veg = new GeoBuilder();
  const glow = new GeoBuilder();
  const win = new GeoBuilder();
  const interactables: Interactable[] = [];
  const fires: Fire[] = [];
  const lights: LightSpot[] = [];
  const group = new THREE.Group();
  const caveEntrances: StructuresResult["caveEntrances"] = [];

  const padH = (x: number, z: number) => {
    for (const p of pads) if (Math.abs(p.x - x) < 0.01 && Math.abs(p.z - z) < 0.01) return p.h;
    return heightAt(x, z);
  };

  const fireMat1 = new THREE.MeshBasicMaterial({ color: 0xff8a2a });
  const fireMat2 = new THREE.MeshBasicMaterial({ color: 0xffd860 });
  const coneG = new THREE.ConeGeometry(0.35, 1.0, 5);
  coneG.translate(0, 0.5, 0);

  const addFire = (x: number, y: number, z: number, rnd: () => number) => {
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * Math.PI * 2;
      V.rock(b, x + Math.cos(a) * 0.75, y - 0.1, z + Math.sin(a) * 0.75, 0.28, rnd, false);
    }
    for (let i = 0; i < 3; i++) {
      V.log(b, x, y - 0.2, z, 1.3, (i / 3) * Math.PI, rnd);
    }
    const g = new THREE.Group();
    const f1 = new THREE.Mesh(coneG, fireMat1);
    const f2 = new THREE.Mesh(coneG, fireMat2);
    f2.scale.set(0.6, 0.7, 0.6);
    g.add(f1, f2);
    g.position.set(x, y + 0.15, z);
    group.add(g);
    fires.push({ x, y: y + 1, z, mesh: g });
    lights.push({ x, y: y + 1.2, z, color: 0xff9a40, night: true });
  };

  const L = (s: StructDef, lx: number, lz: number) => {
    const c = Math.cos(s.rot), sn = Math.sin(s.rot);
    return [s.x + lx * c + lz * sn, s.z - lx * sn + lz * c];
  };

  const addWindow = (s: StructDef, lx: number, y: number, lz: number, alongX: boolean) => {
    const [wx, wz] = L(s, lx, lz);
    const rot = s.rot + (alongX ? 0 : Math.PI / 2);
    b.box(wx, y - 0.1, wz, 1.2, 1.1, 0.14, rot, 0.28, 0.2, 0.13);
    win.box(wx, y, wz, 0.9, 0.85, 0.2, rot, 1.0, 0.78, 0.42, 1);
  };

  const house = (s: StructDef, rnd: () => number, farm = false) => {
    const y = padH(s.x, s.z);
    const W = farm ? 9 : 8, D = 6;
    b.box(s.x, y - 1.2, s.z, W + 0.5, 1.6, D + 0.5, s.rot, ...STONE);
    const wallC: [number, number, number] = rnd() < 0.5 ? [0.86, 0.8, 0.67] : [0.8, 0.74, 0.62];
    b.box(s.x, y + 0.4, s.z, W, 3.2, D, s.rot, ...wallC);
    b.box(s.x, y + 1.9, s.z, W + 0.12, 0.25, D + 0.12, s.rot, 0.34, 0.23, 0.14);
    for (const [cx, cz] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
      const [px, pz] = L(s, (cx * W) / 2, (cz * D) / 2);
      b.box(px, y + 0.4, pz, 0.36, 3.2, 0.36, s.rot, 0.34, 0.23, 0.14);
    }
    const roofs: [number, number, number][] = [[0.62, 0.27, 0.19], [0.4, 0.28, 0.22], [0.33, 0.35, 0.42], [0.55, 0.34, 0.2]];
    const rc = roofs[Math.floor(rnd() * roofs.length)];
    b.roof(s.x, y + 3.6, s.z, W + 1.4, D + 1.4, 2.7, s.rot, ...rc);
    const [chx, chz] = L(s, W * 0.28, D * 0.2);
    b.box(chx, y + 3.4, chz, 0.9, 3.2, 0.9, s.rot, 0.5, 0.46, 0.42);
    const [dx, dz] = L(s, 0, -D / 2 - 0.05);
    b.box(dx, y + 0.4, dz, 1.3, 2.2, 0.16, s.rot, 0.3, 0.2, 0.12);
    const [sx, sz] = L(s, 0, -D / 2 - 0.7);
    b.box(sx, y - 0.2, sz, 1.8, 0.45, 1.0, s.rot, ...STONE);
    addWindow(s, -2.5, y + 2.0, -D / 2 - 0.02, true);
    addWindow(s, 2.5, y + 2.0, -D / 2 - 0.02, true);
    addWindow(s, -2.5, y + 2.0, D / 2 + 0.02, true);
    addWindow(s, W / 2 + 0.02, y + 2.0, 0, false);
    // crates & barrel
    const [bx, bz] = L(s, W / 2 + 1.0, -D / 2 + 0.5);
    b.cyl(bx, y, bz, 0.45, 0.45, 1.0, 8, 0.45, 0.3, 0.17);
    addStatic(circleCol(bx, bz, 0.5, y + 1.0));
    const [kx, kz] = L(s, -W / 2 - 0.9, -D / 2 + 0.8);
    b.box(kx, y, kz, 0.9, 0.9, 0.9, s.rot + 0.3, 0.55, 0.4, 0.24);
    addStatic(boxCol(kx, kz, 0.45, 0.45, s.rot + 0.3, y + 0.9));
    addStatic(boxCol(s.x, s.z, W / 2 + 0.2, D / 2 + 0.2, s.rot, y + 8));
    // flower boxes
    for (let i = 0; i < 4; i++) {
      const [fx, fz] = L(s, -3 + i * 2, -D / 2 - 0.5);
      if (Math.abs(-3 + i * 2) < 1) continue;
      V.flower(veg, fx, y, fz, rnd);
      V.bush(veg, fx, y - 0.2, fz, 0.4, rnd, false);
    }
    const [ix, iz] = L(s, 0, -D / 2 - 1.6);
    interactables.push({ id: `rest-${s.seed}`, x: ix, y, z: iz, r: 2.4, label: "Descansar na casa", kind: "rest" });
    lights.push({ x: ix, y: y + 2.5, z: iz, color: 0xffb060, night: true });
    if (farm) {
      // fenced field
      const fw = 16, fd = 12, off = 12;
      const corners = [[-fw / 2, off], [fw / 2, off], [fw / 2, off + fd], [-fw / 2, off + fd]];
      for (let k = 0; k < 4; k++) {
        const [ax, az] = corners[k], [ex, ez] = corners[(k + 1) % 4];
        const len = Math.hypot(ex - ax, ez - az);
        const n = Math.ceil(len / 2);
        for (let i = 0; i <= n; i++) {
          if (k === 0 && Math.abs(ax + ((ex - ax) * i) / n) < 1.5) continue;
          const [px, pz] = L(s, ax + ((ex - ax) * i) / n, az + ((ez - az) * i) / n);
          const py = heightAt(px, pz);
          b.box(px, py - 0.2, pz, 0.2, 1.3, 0.2, s.rot, 0.4, 0.28, 0.16);
        }
        const [mx, mz] = L(s, (ax + ex) / 2, (az + ez) / 2);
        const my = heightAt(mx, mz);
        const rot = s.rot + (k % 2 === 0 ? 0 : Math.PI / 2);
        if (k !== 0) {
          b.box(mx, my + 0.7, mz, len, 0.12, 0.1, rot, 0.5, 0.36, 0.2);
          b.box(mx, my + 0.3, mz, len, 0.12, 0.1, rot, 0.5, 0.36, 0.2);
          addStatic(boxCol(mx, mz, len / 2, 0.15, rot, my + 1.0));
        }
      }
      for (let r = 0; r < 5; r++)
        for (let c = 0; c < 12; c++) {
          const [px, pz] = L(s, -6.5 + c * 1.2, off + 2 + r * 2);
          const py = heightAt(px, pz);
          V.bush(veg, px, py - 0.3, pz, 0.35, rnd, r % 2 === 0);
        }
      const [hx, hz] = L(s, W / 2 + 4, 3);
      b.blob(hx, heightAt(hx, hz) + 0.7, hz, 1.4, 1.1, 1.4, 0.82, 0.7, 0.35, rnd, 0, 0.1);
      addStatic(circleCol(hx, hz, 1.3, heightAt(hx, hz) + 1.6));
    }
  };

  const cabin = (s: StructDef, rnd: () => number) => {
    const y = padH(s.x, s.z);
    const W = 6.5, D = 5;
    b.box(s.x, y - 1, s.z, W + 0.6, 1.3, D + 0.6, s.rot, 0.42, 0.4, 0.38);
    b.box(s.x, y + 0.3, s.z, W, 2.7, D, s.rot, 0.45, 0.3, 0.18);
    for (let i = 0; i < 5; i++) b.box(s.x, y + 0.4 + i * 0.55, s.z, W + 0.2, 0.18, D + 0.2, s.rot, 0.36, 0.23, 0.13);
    b.roof(s.x, y + 3.0, s.z, W + 1.4, D + 1.6, 2.4, s.rot, 0.28, 0.22, 0.16);
    const [chx, chz] = L(s, -W * 0.3, D * 0.1);
    b.box(chx, y + 2.4, chz, 0.8, 3.4, 0.8, s.rot, 0.48, 0.45, 0.42);
    // porch
    const [px, pz] = L(s, 0, -D / 2 - 1.2);
    b.box(px, y - 0.3, pz, W, 0.5, 2.2, s.rot, 0.5, 0.36, 0.22);
    for (const sx of [-1, 1]) {
      const [qx, qz] = L(s, sx * (W / 2 - 0.3), -D / 2 - 2.1);
      b.box(qx, y, qz, 0.25, 2.9, 0.25, s.rot, 0.36, 0.24, 0.14);
    }
    const [dx, dz] = L(s, 0.8, -D / 2 - 0.05);
    b.box(dx, y + 0.3, dz, 1.1, 2.0, 0.14, s.rot, 0.25, 0.16, 0.1);
    addWindow(s, -1.6, y + 1.7, -D / 2 - 0.02, true);
    addWindow(s, W / 2 + 0.02, y + 1.7, 0, false);
    // firewood
    const [wx, wz] = L(s, W / 2 + 0.8, 1.0);
    for (let i = 0; i < 3; i++) V.log(b, wx, y + i * 0.55 - 0.1, wz, 1.8, s.rot + Math.PI / 2, rnd);
    addStatic(boxCol(wx, wz, 0.5, 1.0, s.rot, y + 1.6));
    addStatic(boxCol(s.x, s.z, W / 2 + 0.2, D / 2 + 0.2, s.rot, y + 7));
    const [ix, iz] = L(s, 0, -D / 2 - 1.4);
    interactables.push({ id: `rest-${s.seed}`, x: ix, y, z: iz, r: 2.4, label: "Descansar na cabana", kind: "rest" });
    lights.push({ x: ix, y: y + 2.4, z: iz, color: 0xffb060, night: true });
  };

  const camp = (s: StructDef, rnd: () => number) => {
    const y = padH(s.x, s.z);
    const [tx, tz] = L(s, 0, 2.6);
    const tc: [number, number, number] = rnd() < 0.5 ? [0.72, 0.56, 0.34] : [0.36, 0.46, 0.3];
    b.roof(tx, y - 0.05, tz, 3.4, 2.8, 2.1, s.rot + Math.PI / 2, ...tc);
    b.box(tx, y - 0.1, tz, 2.6, 0.08, 3.2, s.rot, 0.3, 0.25, 0.2);
    addStatic(boxCol(tx, tz, 1.4, 1.7, s.rot, y + 2.1));
    addFire(s.x, y, s.z, rnd);
    for (const a of [0.9, 2.4]) {
      const lx = Math.cos(s.rot + a) * 2.4, lz = Math.sin(s.rot + a) * 2.4;
      V.log(b, s.x + lx, y - 0.05, s.z + lz, 2.0, s.rot + a + Math.PI / 2, rnd);
      addStatic(circleCol(s.x + lx, s.z + lz, 0.6, y + 0.6));
    }
    const [kx, kz] = L(s, 1.8, 2.0);
    b.box(kx, y, kz, 0.6, 0.7, 0.4, s.rot, 0.45, 0.35, 0.22);
    b.box(kx, y + 0.7, kz, 0.4, 0.2, 0.3, s.rot, 0.35, 0.28, 0.2);
    interactables.push({ id: `rest-${s.seed}`, x: s.x, y, z: s.z, r: 2.8, label: "Descansar na fogueira", kind: "rest" });
  };

  const ruins = (s: StructDef, rnd: () => number, lore: string) => {
    const y = padH(s.x, s.z);
    const R = 6;
    for (let i = 0; i < 9; i++) {
      const [fx, fz] = L(s, (rnd() - 0.5) * 10, (rnd() - 0.5) * 10);
      b.box(fx, y - 0.3, fz, 1.6 + rnd(), 0.4, 1.6 + rnd(), s.rot + rnd() * 0.2, 0.5, 0.49, 0.45);
    }
    // perimeter walls
    for (let side = 0; side < 4; side++) {
      for (let k = -2; k <= 2; k++) {
        if (rnd() < 0.3 || (side === 0 && k === 0)) continue;
        const along = k * 2.4;
        const lx = side % 2 === 0 ? along : side === 1 ? R : -R;
        const lz = side % 2 === 0 ? (side === 0 ? -R : R) : along;
        const [wx, wz] = L(s, lx, lz);
        const h = 0.6 + rnd() * (rnd() < 0.3 ? 3.2 : 1.2);
        const rot = s.rot + (side % 2 === 0 ? 0 : Math.PI / 2);
        const k2 = 0.9 + rnd() * 0.15;
        b.box(wx, y - 0.4, wz, 2.4, h + 0.4, 0.8, rot, STONE[0] * k2, STONE[1] * k2, STONE[2] * k2);
        if (rnd() < 0.6) b.box(wx, y + h, wz, 2.0, 0.12, 0.85, rot, ...MOSS);
        addStatic(boxCol(wx, wz, 1.2, 0.4, rot, y + h + (rnd() < 0.6 ? 0.12 : 0)));
      }
    }
    // columns
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const [cx, cz] = L(s, Math.cos(a) * 3.2, Math.sin(a) * 3.2);
      const intact = rnd() < 0.4;
      const h = intact ? 4.5 : 0.8 + rnd() * 2.5;
      b.cyl(cx, y - 0.3, cz, 0.45, 0.42, h + 0.3, 8, 0.72, 0.7, 0.63);
      b.box(cx, y - 0.4, cz, 1.1, 0.5, 1.1, s.rot, 0.62, 0.6, 0.55);
      if (intact) b.box(cx, y + h, cz, 1.1, 0.4, 1.1, s.rot, 0.66, 0.64, 0.58);
      addStatic(circleCol(cx, cz, 0.55, y + h + (intact ? 0.4 : 0)));
    }
    // fallen column
    const [lx2, lz2] = L(s, 1.5, 4.5);
    const ang = s.rot + 0.4;
    V.log(b, lx2, y - 0.1, lz2, 3.5, ang, rnd);
    for (let i = 0; i < 12; i++) V.fern(veg, s.x + (rnd() - 0.5) * 14, y, s.z + (rnd() - 0.5) * 14, 0.7, rnd);
    // inscription stone
    const [ix, iz] = L(s, 0, 0);
    b.box(ix, y - 0.2, iz, 1.4, 1.4, 0.5, s.rot, 0.45, 0.44, 0.42);
    glow.box(ix, y + 0.55, iz, 0.8, 0.12, 0.54, s.rot, 0.55, 0.28, 0.85);
    addStatic(boxCol(ix, iz, 0.7, 0.25, s.rot, y + 1.2));
    interactables.push({ id: `lore-${lore}`, x: ix, y, z: iz, r: 2.6, label: "Examinar inscrição", kind: "lore", data: lore });
  };

  const temple = (s: StructDef, rnd: () => number) => {
    const y = padH(s.x, s.z);
    const tiers = [18, 14, 10];
    tiers.forEach((w, i) => {
      const k = 0.95 - i * 0.03;
      b.box(s.x, y - 1 + i * 1.2, s.z, w, i === 0 ? 2.2 : 1.2, w, s.rot, 0.66 * k, 0.63 * k, 0.56 * k);
      b.box(s.x, y + (i + 1) * 1.2 - 0.05, s.z, w + 0.2, 0.1, w + 0.2, s.rot, 0.56, 0.53, 0.48);
      addStatic(boxCol(s.x, s.z, w / 2, w / 2, s.rot, y + (i + 1) * 1.2));
    });
    for (let i = 0; i < 9; i++) {
      const lz = -11.3 + 0.35 + i * 0.7;
      const [sx, sz] = L(s, 0, lz);
      const top = y + 0.4 * (i + 1);
      b.box(sx, y - 0.6, sz, 4, top - y + 0.6, 0.7, s.rot, 0.7, 0.67, 0.6);
      addStatic(boxCol(sx, sz, 2, 0.35, s.rot, top));
    }
    // statues flanking stairs
    for (const sx of [-1, 1]) {
      const [px, pz] = L(s, sx * 3.2, -10.5);
      b.box(px, y - 0.2, pz, 1.2, 1.4, 1.2, s.rot, 0.5, 0.48, 0.45);
      b.blob(px, y + 2.0, pz, 0.5, 0.9, 0.5, 0.52, 0.5, 0.46, rnd, 0, 0.1);
      b.blob(px, y + 3.0, pz, 0.35, 0.35, 0.35, 0.52, 0.5, 0.46, rnd, 0, 0.1);
      addStatic(boxCol(px, pz, 0.6, 0.6, s.rot, y + 3.5));
    }
    const top = y + 3.6;
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2 + Math.PI / 8;
      const [cx, cz] = L(s, Math.cos(a) * 4.2, Math.sin(a) * 4.2);
      b.cyl(cx, top, cz, 0.42, 0.38, 4, 8, 0.78, 0.75, 0.68);
      b.box(cx, top + 4, cz, 1.0, 0.35, 1.0, s.rot, 0.7, 0.67, 0.6);
      addStatic(circleCol(cx, cz, 0.45, 1e9));
    }
    b.box(s.x, top + 4.3, s.z, 10.4, 0.6, 10.4, s.rot, 0.62, 0.6, 0.54);
    b.cyl(s.x, top + 4.9, s.z, 7.2, 0, 3.2, 4, 0.5, 0.35, 0.5, 0, 0, s.rot + Math.PI / 4);
    // altar
    b.box(s.x, top, s.z, 1.6, 1.0, 1.6, s.rot, 0.5, 0.48, 0.46);
    glow.octa(s.x, top + 2.0, s.z, 0.45, 0.9, 0.45, 0.75, 0.35, 1.0, 0.3);
    glow.octa(s.x + 0.4, top + 1.4, s.z + 0.2, 0.2, 0.4, 0.2, 0.9, 0.55, 1.0, 1);
    addStatic(boxCol(s.x, s.z, 0.8, 0.8, s.rot, top + 1.0));
    lights.push({ x: s.x, y: top + 2, z: s.z, color: 0xb050ff, night: false });
    interactables.push({ id: "temple-altar", x: s.x, y: top, z: s.z - 1.2, r: 2.6, label: "Tocar o cristal", kind: "lore", data: "temple" });
    // overgrowth
    for (let i = 0; i < 10; i++) {
      const a = rnd() * 6.28, d = 9.2 + rnd() * 1.5;
      V.bush(veg, s.x + Math.cos(a) * d, y - 0.2, s.z + Math.sin(a) * d, 0.6 + rnd() * 0.5, rnd, false);
    }
  };

  const shrine = (s: StructDef, rnd: () => number) => {
    const y = padH(s.x, s.z);
    b.box(s.x, y - 0.8, s.z, 5, 1.2, 5, s.rot, 0.6, 0.58, 0.52);
    addStatic(boxCol(s.x, s.z, 2.5, 2.5, s.rot, y + 0.4));
    for (const [cx, cz] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
      const [px, pz] = L(s, cx * 2, cz * 2);
      b.box(px, y + 0.4, pz, 0.45, 3, 0.45, s.rot, 0.7, 0.68, 0.6);
      addStatic(circleCol(px, pz, 0.35, 1e9));
    }
    b.cyl(s.x, y + 3.4, s.z, 3.8, 0, 1.8, 4, 0.55, 0.28, 0.22, 0, 0, s.rot + Math.PI / 4);
    b.box(s.x, y + 0.4, s.z, 0.8, 0.6, 0.8, s.rot, 0.5, 0.48, 0.45);
    b.blob(s.x, y + 1.5, s.z, 0.35, 0.55, 0.35, 0.58, 0.56, 0.52, rnd, 0, 0.1);
    glow.octa(s.x, y + 2.4, s.z, 0.18, 0.18, 0.18, 0.6, 0.85, 1.0);
    for (let i = 0; i < 6; i++) V.flower(veg, s.x + (rnd() - 0.5) * 3.5, y + 0.4, s.z + (rnd() - 0.5) * 3.5, rnd);
    interactables.push({ id: "lore-shrine", x: s.x, y, z: s.z, r: 3.2, label: "Examinar estátua", kind: "lore", data: "shrine" });
  };

  const well = (s: StructDef) => {
    const y = padH(s.x, s.z);
    b.cyl(s.x, y - 0.2, s.z, 1.15, 1.15, 1.1, 10, ...STONE);
    b.cyl(s.x, y + 0.85, s.z, 0.95, 0.95, 0.05, 10, 0.12, 0.22, 0.28);
    for (const sx of [-1, 1]) {
      const [px, pz] = L(s, sx * 1.1, 0);
      b.box(px, y + 0.8, pz, 0.2, 2.0, 0.2, s.rot, 0.4, 0.28, 0.16);
    }
    b.roof(s.x, y + 2.7, s.z, 3.0, 2.2, 1.0, s.rot, 0.55, 0.28, 0.2);
    addStatic(circleCol(s.x, s.z, 1.3, y + 0.9));
    interactables.push({ id: "lore-well", x: s.x, y, z: s.z, r: 2.4, label: "Olhar o poço", kind: "lore", data: "well" });
  };

  for (const s of STRUCTS) {
    const rnd = mulberry32(s.seed * 977);
    if (s.type === "house") house(s, rnd);
    else if (s.type === "farm") house(s, rnd, true);
    else if (s.type === "cabin") cabin(s, rnd);
    else if (s.type === "camp") camp(s, rnd);
    else if (s.type === "ruins") ruins(s, rnd, s.seed === 11 ? "ruinsW" : "ruinsE");
    else if (s.type === "temple") temple(s, rnd);
    else if (s.type === "shrine") shrine(s, rnd);
    else if (s.type === "well") well(s);
  }

  // Village lamp posts
  for (const [x, z] of [[76, 16], [100, 26], [60, 22]] as [number, number][]) {
    const y = heightAt(x, z);
    b.box(x, y - 0.2, z, 0.2, 3.4, 0.2, 0, 0.25, 0.2, 0.18);
    win.box(x, y + 3.1, z, 0.45, 0.5, 0.45, 0, 1, 0.8, 0.45);
    addStatic(circleCol(x, z, 0.25, 1e9));
  }

  // Lake cabin dock
  {
    const s = STRUCTS.find((q) => q.seed === 8)!;
    const lake = LAKES[LAKES.length - 1];
    const dx = lake.x - s.x, dz = lake.z - s.z;
    const l = Math.hypot(dx, dz);
    const ux = dx / l, uz = dz / l;
    let t = 5;
    const smp = newSample();
    for (; t < l; t += 0.5) {
      sampleTerrain(s.x + ux * t, s.z + uz * t, smp);
      if (smp.water > smp.h) break;
    }
    const start = t - 4, end = t + 11;
    const top = lake.level! + 0.7;
    const rot = Math.atan2(-uz, ux);
    const cx = s.x + ux * (start + end) / 2, cz = s.z + uz * (start + end) / 2;
    const len = end - start;
    for (let i = 0; i < len / 0.6; i++) {
      const tt = start + i * 0.6 + 0.3;
      b.box(s.x + ux * tt, top - 0.18, s.z + uz * tt, 0.5, 0.18, 2.4, rot, 0.52 - (i % 2) * 0.05, 0.38, 0.22);
    }
    for (let i = 0; i <= len / 2.5; i++) {
      const tt = start + i * 2.5;
      for (const sd of [-1, 1]) {
        const px = s.x + ux * tt - uz * sd * 1.1, pz = s.z + uz * tt + ux * sd * 1.1;
        b.box(px, lake.level! - 2.5, pz, 0.22, 3.5, 0.22, rot, 0.34, 0.24, 0.14);
      }
    }
    addStatic(boxCol(cx, cz, len / 2, 1.2, rot, top, lake.level! - 3));
    // small boat
    const bx = s.x + ux * (end - 2) - uz * 2.4, bz = s.z + uz * (end - 2) + ux * 2.4;
    b.box(bx, lake.level! - 0.1, bz, 3, 0.45, 1.1, rot, 0.45, 0.3, 0.18);
    b.box(bx, lake.level! + 0.1, bz, 2.4, 0.3, 0.7, rot, 0.32, 0.22, 0.12);
  }

  // Bridges
  for (const br of bridges) {
    const rot = Math.atan2(-br.dz, br.dx);
    const px = -br.dz, pz = br.dx; // perpendicular
    const hw = br.width / 2;
    const step = br.stone ? 1.0 : 0.6;
    const n = Math.ceil((2 * br.half) / step);
    for (let i = 0; i < n; i++) {
      const s = -br.half + (i + 0.5) * (2 * br.half / n);
      const y = bridgeDeck(br, s);
      const x = br.x + br.dx * s, z = br.z + br.dz * s;
      if (br.stone) {
        const k = 0.92 + ((i * 37) % 7) * 0.02;
        b.box(x, y - 1.4, z, 2 * br.half / n + 0.05, 1.4, br.width, rot, 0.58 * k, 0.56 * k, 0.52 * k);
      } else {
        const k = 0.9 + ((i * 13) % 5) * 0.04;
        b.box(x, y - 0.22, z, step * 0.9, 0.22, br.width, rot, 0.5 * k, 0.36 * k, 0.21 * k);
      }
    }
    // supports
    if (!br.stone) {
      for (const s of [-br.half * 0.5, 0, br.half * 0.5]) {
        const y = bridgeDeck(br, s);
        for (const sd of [-1, 1]) {
          const x = br.x + br.dx * s + px * sd * (hw - 0.2), z = br.z + br.dz * s + pz * sd * (hw - 0.2);
          b.box(x, y - 4, z, 0.3, 4, 0.3, rot, 0.34, 0.24, 0.14);
        }
      }
    } else {
      const y = bridgeDeck(br, 0);
      b.box(br.x, y - 5, br.z, 2.4, 4, br.width - 0.2, rot, 0.5, 0.48, 0.45);
    }
    // rails
    const posts = Math.ceil((2 * br.half) / 2);
    for (let i = 0; i <= posts; i++) {
      const s = -br.half + (i * 2 * br.half) / posts;
      const y = bridgeDeck(br, s);
      for (const sd of [-1, 1]) {
        const x = br.x + br.dx * s + px * sd * hw, z = br.z + br.dz * s + pz * sd * hw;
        if (br.stone) b.box(x, y - 0.1, z, 0.5, 1.0, 0.5, rot, 0.5, 0.48, 0.45);
        else b.box(x, y - 0.1, z, 0.18, 1.2, 0.18, rot, 0.36, 0.25, 0.14);
        if (i < posts) {
          const s2 = -br.half + ((i + 1) * 2 * br.half) / posts;
          const y2 = bridgeDeck(br, s2);
          const mx = br.x + br.dx * (s + s2) / 2 + px * sd * hw, mz = br.z + br.dz * (s + s2) / 2 + pz * sd * hw;
          const len = Math.hypot(s2 - s, y2 - y);
          const g = new THREE.Matrix4().makeRotationY(rot).multiply(new THREE.Matrix4().makeRotationZ(Math.atan2(y2 - y, s2 - s)));
          g.setPosition(mx, (y + y2) / 2 + (br.stone ? 0.55 : 0.95), mz);
          b.setTransform(g);
          if (br.stone) b.box(0, -0.2, 0, len, 0.4, 0.4, 0, 0.55, 0.53, 0.5);
          else b.box(0, -0.06, 0, len, 0.12, 0.12, 0, 0.45, 0.32, 0.18);
          b.setTransform(null);
        }
      }
    }
  }

  // Viewpoints: cairn + sign
  VIEWPOINTS.forEach((v, i) => {
    const rnd = mulberry32(800 + i);
    const y = padH(v.x, v.z);
    const ox = v.x + 1.8, oz = v.z + 1.2;
    b.blob(ox, y + 0.35, oz, 0.8, 0.45, 0.8, 0.5, 0.49, 0.46, rnd, 0, 0.15);
    b.blob(ox, y + 0.95, oz, 0.55, 0.35, 0.55, 0.55, 0.53, 0.5, rnd, 0, 0.15);
    b.blob(ox, y + 1.4, oz, 0.35, 0.25, 0.35, 0.6, 0.58, 0.55, rnd, 0, 0.15);
    b.box(v.x - 1.5, y - 0.2, v.z + 1.5, 0.18, 2.6, 0.18, 0, 0.4, 0.28, 0.16);
    b.tri(v.x - 1.5, y + 2.4, v.z + 1.5, v.x - 1.5, y + 1.8, v.z + 1.5, v.x - 0.5, y + 2.1, v.z + 1.5, 0.8, 0.2, 0.2);
    b.tri(v.x - 0.5, y + 2.1, v.z + 1.5, v.x - 1.5, y + 1.8, v.z + 1.5, v.x - 1.5, y + 2.4, v.z + 1.5, 0.7, 0.18, 0.18);
    addStatic(circleCol(ox, oz, 0.8, y + 1.6));
    interactables.push({ id: `view-${i}`, x: v.x, y, z: v.z, r: 3.5, label: "Observar a paisagem", kind: "view", data: v.name });
  });

  // Cave entrances
  CAVES.forEach((c, i) => {
    const rnd = mulberry32(c.seed);
    const y = padH(c.x, c.z);
    const e = 3;
    let gx = baseHeight(c.x + e, c.z) - baseHeight(c.x - e, c.z);
    let gz = baseHeight(c.x, c.z + e) - baseHeight(c.x, c.z - e);
    if (i === 0) { gx = 0; gz = -1; }
    const gl = Math.hypot(gx, gz) || 1;
    const ux = gx / gl, uz = gz / gl; // uphill
    const px = -uz, pz = ux;
    const ex = c.x + ux * 3.2, ez = c.z + uz * 3.2;
    const sc = c.large ? 1.35 : 1;
    const rk = (x: number, yy: number, z: number, sx: number, sy: number, sz: number) =>
      b.blob(x, yy, z, sx, sy, sz, 0.42 + rnd() * 0.06, 0.4 + rnd() * 0.05, 0.38, rnd, 0, 0.25);
    rk(ex + px * 2.6 * sc, y + 1.6 * sc, ez + pz * 2.6 * sc, 1.6 * sc, 2.8 * sc, 2.0 * sc);
    rk(ex - px * 2.6 * sc, y + 1.6 * sc, ez - pz * 2.6 * sc, 1.6 * sc, 2.8 * sc, 2.0 * sc);
    rk(ex + ux * 0.6, y + 4.2 * sc, ez + uz * 0.6, 3.6 * sc, 1.4 * sc, 2.2 * sc);
    rk(ex + ux * 5, y + 3 * sc, ez + uz * 5, 5.5 * sc, 5 * sc, 4.5 * sc);
    rk(ex + ux * 2 + px * 5, y + 1 * sc, ez + uz * 2 + pz * 5, 2.2, 2.4, 2.2);
    rk(ex + ux * 2 - px * 5, y + 1 * sc, ez + uz * 2 - pz * 5, 2.4, 2.0, 2.2);
    // dark opening quad facing downhill
    const w = 1.9 * sc, h = 3.4 * sc;
    const ox = ex - ux * 0.2, oz = ez - uz * 0.2;
    glow.quad([ox - px * w, y - 0.3, oz - pz * w, ox - px * w * 0.8, y + h, oz - pz * w * 0.8, ox + px * w * 0.8, y + h, oz + pz * w * 0.8, ox + px * w, y - 0.3, oz + pz * w], 0.02, 0.015, 0.03);
    glow.quad([ox + px * w, y - 0.3, oz + pz * w, ox + px * w * 0.8, y + h, oz + pz * w * 0.8, ox - px * w * 0.8, y + h, oz - pz * w * 0.8, ox - px * w, y - 0.3, oz - pz * w], 0.02, 0.015, 0.03);
    for (let k = 0; k < 3; k++) {
      const s2 = (k - 1) * 1.6;
      glow.octa(ex + px * s2 * sc - ux * 0.8, y + 0.3, ez + pz * s2 * sc - uz * 0.8, 0.14, 0.35 + rnd() * 0.3, 0.14, 0.7, 0.35, 1.0, rnd());
    }
    addStatic(circleCol(ex + px * 2.6 * sc, ez + pz * 2.6 * sc, 1.5 * sc, 1e9));
    addStatic(circleCol(ex - px * 2.6 * sc, ez - pz * 2.6 * sc, 1.5 * sc, 1e9));
    addStatic(circleCol(ex + ux * 1.2, ez + uz * 1.2, 1.6 * sc, 1e9));
    addStatic(circleCol(ex + ux * 5, ez + uz * 5, 4.5 * sc, 1e9));
    caveEntrances.push({ x: ex - ux * 2.5, y, z: ez - uz * 2.5, fx: -ux, fz: -uz, idx: i });
    interactables.push({ id: `cave-${i}`, x: ex - ux * 1.2, y, z: ez - uz * 1.2, r: 3.0, label: `Entrar: ${c.name}`, kind: "cave", data: i });
    lights.push({ x: ex - ux * 0.8, y: y + 0.8, z: ez - uz * 0.8, color: 0xa050ff, night: false });
  });

  // Waterfall surroundings: rocks at the lip and pool
  {
    const rnd = mulberry32(4242);
    const cz = cliffZ(WATERFALL_X);
    const pool = LAKES[1];
    for (let i = 0; i < 16; i++) {
      const a = Math.PI * 0.1 + (i / 16) * Math.PI * 1.8;
      const d = pool.r * (1.05 + rnd() * 0.25);
      const x = pool.x + Math.cos(a) * d, z = pool.z + Math.sin(a) * d;
      const y = heightAt(x, z);
      const s = 0.7 + rnd() * 1.4;
      V.rock(b, x, y - 0.3, z, s, rnd, rnd() < 0.5);
      if (s > 1) addStatic(circleCol(x, z, s * 0.85, y + s * 0.6));
    }
    for (const sd of [-1, 1]) {
      for (let k = 0; k < 3; k++) {
        const x = WATERFALL_X + sd * (5.5 + k * 1.6), z = cz - 3 - k * 1.2;
        const y = heightAt(x, z);
        V.rock(b, x, y - 0.4, z, 1.2 + rnd(), rnd, true);
      }
    }
    for (let i = 0; i < 18; i++) {
      const a = rnd() * Math.PI * 2;
      const d = pool.r * (1.3 + rnd() * 0.8);
      const x = pool.x + Math.cos(a) * d, z = pool.z + Math.sin(a) * d;
      const y = heightAt(x, z);
      if (rnd() < 0.5) V.fern(veg, x, y, z, 0.9, rnd);
      else V.flower(veg, x, y, z, rnd, 0);
    }
  }

  const structMesh = new THREE.Mesh(b.build(), structMat);
  structMesh.castShadow = true;
  structMesh.receiveShadow = true;
  group.add(structMesh);
  if (veg.count) group.add(new THREE.Mesh(veg.build(true), vegMat));
  const glowMat = new THREE.MeshBasicMaterial({ vertexColors: true });
  group.add(new THREE.Mesh(glow.build(), glowMat));
  const windowMat = new THREE.MeshBasicMaterial({ vertexColors: true });
  group.add(new THREE.Mesh(win.build(), windowMat));
  return { group, interactables, fires, lights, windowMat, caveEntrances };
}
