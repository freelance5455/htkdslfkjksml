import * as THREE from 'three/webgpu';
import { PALETTE } from '../rendering/Palette.ts';
import {
  createPastelMaterial,
  createUnlitPastelFXMaterial,
} from '../rendering/StorybookMaterial.ts';
import {
  rbox,
  rcyl,
  smoothSphere,
  taperedTube,
  extrudeShape,
  transformGeo,
  mergeParts,
} from '../geometry/Sculptor.ts';
import { SparrowMesh, type BirdSpecies, type SparrowPoseInput } from '../entities/SparrowMesh.ts';
import type { SparrowController } from '../entities/SparrowController.ts';
import type { NPCManager } from '../entities/NPCManager.ts';
import {
  COLLISION_GROUP_STATIC,
  createGroundRaycastHit,
  type PhysicsWorld,
} from '../physics/PhysicsWorld.ts';
import type { AcousticSoundtrack } from '../audio/AcousticSoundtrack.ts';
import type { WorldFX } from '../rendering/WorldFX.ts';
import { isInsideAtelier } from '../world/AtelierBounds.ts';

export type HazardThreatType = 'none' | 'cat' | 'eagle' | 'trap' | 'trapper';

export interface DailyHazardQuota {
  day: number;
  activeCats: number;
  activeEagles: number;
  activeTraps: number;
  stalkDuration: number;
  stoopLockDuration: number;
}

export const SEVEN_DAY_QUOTAS: ReadonlyArray<DailyHazardQuota> = [
  { day: 1, activeCats: 1, activeEagles: 1, activeTraps: 2, stalkDuration: 1.25, stoopLockDuration: 1.45 },
  { day: 2, activeCats: 1, activeEagles: 1, activeTraps: 2, stalkDuration: 1.15, stoopLockDuration: 1.35 },
  { day: 3, activeCats: 2, activeEagles: 1, activeTraps: 3, stalkDuration: 1.10, stoopLockDuration: 1.30 },
  { day: 4, activeCats: 2, activeEagles: 2, activeTraps: 3, stalkDuration: 1.05, stoopLockDuration: 1.25 },
  { day: 5, activeCats: 3, activeEagles: 2, activeTraps: 3, stalkDuration: 1.00, stoopLockDuration: 1.20 },
  { day: 6, activeCats: 3, activeEagles: 2, activeTraps: 4, stalkDuration: 0.95, stoopLockDuration: 1.15 },
  { day: 7, activeCats: 3, activeEagles: 2, activeTraps: 4, stalkDuration: 0.90, stoopLockDuration: 1.10 },
];

type CatState = 'patrol' | 'stalk' | 'pounce' | 'cooldown';

interface AlleyCatInstance {
  id: string;
  name: string;
  activeForDay: boolean;
  root: THREE.Group;
  bodyPivot: THREE.Group;
  headPivot: THREE.Group;
  tailPivot: THREE.Group;
  legFL: THREE.Group;
  legFR: THREE.Group;
  legBL: THREE.Group;
  legBR: THREE.Group;
  warningRing: THREE.Mesh;
  position: THREE.Vector3;
  yaw: number;
  waypoints: THREE.Vector3[];
  wpIndex: number;
  state: CatState;
  stateTimer: number;
  pounceStart: THREE.Vector3;
  pounceTarget: THREE.Vector3;
  pounceDuration: number;
  gaitPhase: number;
}

type EagleState = 'soar' | 'lock_on' | 'stoop' | 'recover';

interface SkyEagleInstance {
  id: string;
  activeForDay: boolean;
  root: THREE.Group;
  bodyPivot: THREE.Group;
  wingLeft: THREE.Group;
  wingRight: THREE.Group;
  tailPivot: THREE.Group;
  warningRing: THREE.Mesh;
  orbitCenter: THREE.Vector3;
  orbitRadius: number;
  orbitAltitude: number;
  orbitAngle: number;
  orbitSpeed: number;
  position: THREE.Vector3;
  yaw: number;
  pitch: number;
  bank: number;
  state: EagleState;
  stateTimer: number;
  huntCooldown: number;
  stoopStart: THREE.Vector3;
  stoopTarget: THREE.Vector3;
  stoopDuration: number;
  flapPhase: number;
}

type TrapState = 'armed_captive' | 'rescued_open' | 'inactive';

interface BirdTrapInstance {
  id: string;
  species: BirdSpecies;
  speciesLabel: string;
  blockName: string;
  activeForDay: boolean;
  state: TrapState;
  root: THREE.Group;
  doorPivot: THREE.Group;
  latchPivot: THREE.Group;
  beaconRing: THREE.Mesh;
  baitGroup: THREE.Group;
  captiveBird: SparrowMesh;
  captivePos: THREE.Vector3;
  captiveFlightVel: THREE.Vector3;
  position: THREE.Vector3;
  latchWorldPos: THREE.Vector3;
  baitWorldPos: THREE.Vector3;
  callTimer: number;
  flutterPhase: number;
}

const _down = new THREE.Vector3(0, -1, 0);
const _probeOrigin = new THREE.Vector3();
const _groundHit = createGroundRaycastHit();
const _delta = new THREE.Vector3();
const _sanctuaryDest = new THREE.Vector3(96.0, 115.0, -86.8);
const _captiveHeadLook = new THREE.Vector2(0, 0);

const _captivePoseScratch: SparrowPoseInput = {
  dt: 0.016,
  elapsed: 0,
  mode: 'grounded',
  isBraking: false,
  hopPhase: 0,
  flapTimer: 0,
  bankAngle: 0,
  pitchAngle: 0,
  chirpOpen: 0,
  carryingItem: false,
  headLookLocal: _captiveHeadLook,
};

function buildCatRig(
  coatHex: number,
  bellyHex: number,
  stripeHex: number,
  eyeHex: number,
  mat: THREE.NodeMaterial,
  warningMat: THREE.NodeMaterial
): {
  root: THREE.Group;
  bodyPivot: THREE.Group;
  headPivot: THREE.Group;
  tailPivot: THREE.Group;
  legFL: THREE.Group;
  legFR: THREE.Group;
  legBL: THREE.Group;
  legBR: THREE.Group;
  warningRing: THREE.Mesh;
} {
  const root = new THREE.Group();
  const bodyPivot = new THREE.Group();
  bodyPivot.position.set(0, 0.56, 0);
  root.add(bodyPivot);

  // Supple feline torso + chest bib + tabby back stripes
  const torsoParts: THREE.BufferGeometry[] = [
    transformGeo(smoothSphere(0.36, coatHex, 16, 12, [0.82, 0.78, 1.85]), {
      pos: [0, 0.04, 0],
    }),
    transformGeo(smoothSphere(0.28, bellyHex, 12, 10, [0.76, 0.72, 1.15]), {
      pos: [0, -0.02, 0.28],
    }),
    transformGeo(rbox(0.46, 0.08, 0.14, 0.03, stripeHex), { pos: [0, 0.28, 0.18] }),
    transformGeo(rbox(0.48, 0.08, 0.14, 0.03, stripeHex), { pos: [0, 0.29, -0.06] }),
    transformGeo(rbox(0.44, 0.08, 0.14, 0.03, stripeHex), { pos: [0, 0.27, -0.3] }),
  ];
  const torsoMesh = new THREE.Mesh(mergeParts(torsoParts), mat);
  torsoMesh.castShadow = true;
  torsoMesh.receiveShadow = true;
  bodyPivot.add(torsoMesh);

  // Head + pointed ears + muzzle + glowing eyes
  const headPivot = new THREE.Group();
  headPivot.position.set(0, 0.26, 0.62);
  bodyPivot.add(headPivot);

  const earShape = new THREE.Shape();
  earShape.moveTo(-0.09, 0);
  earShape.lineTo(0.09, 0);
  earShape.lineTo(0, 0.22);
  earShape.closePath();

  const headParts: THREE.BufferGeometry[] = [
    transformGeo(smoothSphere(0.27, coatHex, 16, 12, [1.06, 0.94, 0.96]), {
      pos: [0, 0.04, 0],
    }),
    transformGeo(smoothSphere(0.11, bellyHex, 10, 8, [0.95, 0.78, 0.85]), {
      pos: [-0.07, -0.04, 0.22],
    }),
    transformGeo(smoothSphere(0.11, bellyHex, 10, 8, [0.95, 0.78, 0.85]), {
      pos: [0.07, -0.04, 0.22],
    }),
    transformGeo(smoothSphere(0.048, PALETTE.awningCoral, 8, 6, [1.1, 0.8, 0.9]), {
      pos: [0, 0.01, 0.29],
    }),
  ];

  for (const sx of [-1, 1] as const) {
    headParts.push(
      transformGeo(extrudeShape(earShape, 0.05, 0.015, coatHex, 5), {
        rot: [0.12, sx * 0.18, sx * -0.22],
        pos: [sx * 0.17, 0.21, -0.02],
      }),
      transformGeo(smoothSphere(0.058, eyeHex, 10, 8, [0.9, 1.05, 0.65]), {
        pos: [sx * 0.11, 0.07, 0.22],
      }),
      transformGeo(rbox(0.018, 0.085, 0.02, 0.005, 0x141218), {
        pos: [sx * 0.11, 0.07, 0.255],
      })
    );
  }

  const headMesh = new THREE.Mesh(mergeParts(headParts), mat);
  headMesh.castShadow = true;
  headPivot.add(headMesh);

  // Whipping S-curve feline tail
  const tailPivot = new THREE.Group();
  tailPivot.position.set(0, 0.14, -0.62);
  bodyPivot.add(tailPivot);

  const tailGeo = mergeParts([
    taperedTube(
      [
        [0, 0, 0],
        [0, 0.16, -0.32],
        [0, 0.42, -0.58],
        [0, 0.62, -0.68],
      ],
      0.068,
      0.042,
      coatHex,
      10,
      8
    ),
    transformGeo(smoothSphere(0.048, stripeHex, 8, 6), { pos: [0, 0.63, -0.69] }),
  ]);
  const tailMesh = new THREE.Mesh(tailGeo, mat);
  tailMesh.castShadow = true;
  tailPivot.add(tailMesh);

  // 4 Articulated Legs
  const legGeo = mergeParts([
    transformGeo(rcyl(0.068, 0.085, 0.48, coatHex, 10), { pos: [0, -0.24, 0] }),
    transformGeo(smoothSphere(0.075, bellyHex, 10, 8, [0.95, 0.65, 1.25]), {
      pos: [0, -0.49, 0.03],
    }),
  ]);

  const makeLeg = (x: number, z: number): THREE.Group => {
    const g = new THREE.Group();
    g.position.set(x, -0.05, z);
    const m = new THREE.Mesh(legGeo, mat);
    m.castShadow = true;
    g.add(m);
    bodyPivot.add(g);
    return g;
  };

  const legFL = makeLeg(-0.19, 0.38);
  const legFR = makeLeg(0.19, 0.38);
  const legBL = makeLeg(-0.20, -0.38);
  const legBR = makeLeg(0.20, -0.38);

  // Ground warning ring (visible during stalk/pounce)
  const ringGeo = new THREE.RingGeometry(0.85, 1.12, 28);
  ringGeo.rotateX(-Math.PI * 0.5);
  const warningRing = new THREE.Mesh(ringGeo, warningMat);
  warningRing.position.set(0, 0.06, 0);
  warningRing.visible = false;
  root.add(warningRing);

  return {
    root,
    bodyPivot,
    headPivot,
    tailPivot,
    legFL,
    legFR,
    legBL,
    legBR,
    warningRing,
  };
}

function buildEagleRig(
  mat: THREE.NodeMaterial,
  warningMat: THREE.NodeMaterial
): {
  root: THREE.Group;
  bodyPivot: THREE.Group;
  wingLeft: THREE.Group;
  wingRight: THREE.Group;
  tailPivot: THREE.Group;
  warningRing: THREE.Mesh;
} {
  const root = new THREE.Group();
  const bodyPivot = new THREE.Group();
  root.add(bodyPivot);

  const plumageDark = 0x3b281e;
  const plumageGold = 0x9c6b3b;
  const cereGold = 0xf5b82e;
  const beakDark = 0x221f26;

  // Sculpted raptor torso, golden nape, fierce head, hooked raptor beak & talons
  const bodyParts: THREE.BufferGeometry[] = [
    transformGeo(smoothSphere(0.46, plumageDark, 16, 12, [0.88, 0.78, 1.95]), {
      pos: [0, 0, 0],
    }),
    transformGeo(smoothSphere(0.32, plumageGold, 14, 10, [0.92, 0.88, 1.15]), {
      pos: [0, 0.16, 0.68],
    }),
    // Hooked raptor upper beak
    taperedTube(
      [
        [0, 0.16, 0.96],
        [0, 0.14, 1.18],
        [0, 0.02, 1.28],
      ],
      0.095,
      0.015,
      beakDark,
      10,
      8
    ),
    // Golden cere
    transformGeo(smoothSphere(0.085, cereGold, 10, 8, [1.0, 0.85, 0.8]), {
      pos: [0, 0.18, 0.96],
    }),
    // Golden talons tucked underneath
    transformGeo(rcyl(0.045, 0.06, 0.28, cereGold, 8), {
      rot: [0.35, 0, 0],
      pos: [-0.16, -0.34, -0.12],
    }),
    transformGeo(rcyl(0.045, 0.06, 0.28, cereGold, 8), {
      rot: [0.35, 0, 0],
      pos: [0.16, -0.34, -0.12],
    }),
  ];

  const bodyMesh = new THREE.Mesh(mergeParts(bodyParts), mat);
  bodyMesh.castShadow = true;
  bodyPivot.add(bodyMesh);

  // Broad soaring raptor wings (4.4 SU total span)
  const buildRaptorWing = (side: -1 | 1): THREE.Group => {
    const wg = new THREE.Group();
    wg.position.set(side * 0.34, 0.08, 0.12);

    const wingShape = new THREE.Shape();
    wingShape.moveTo(0, 0.28);
    wingShape.bezierCurveTo(side * 0.85, 0.36, side * 1.65, 0.22, side * 2.15, -0.06);
    wingShape.bezierCurveTo(side * 1.75, -0.42, side * 0.82, -0.48, 0, -0.36);
    wingShape.closePath();

    const wParts: THREE.BufferGeometry[] = [
      transformGeo(extrudeShape(wingShape, 0.045, 0.015, plumageDark, 8), {
        rot: [Math.PI * 0.5, 0, 0],
      }),
    ];

    for (let f = 0; f < 5; f++) {
      wParts.push(
        transformGeo(rbox(0.42, 0.025, 0.09, 0.01, f % 2 === 0 ? beakDark : plumageGold), {
          rot: [0, side * (0.15 + f * 0.12), 0],
          pos: [side * (1.85 - f * 0.12), 0, -0.05 - f * 0.08],
        })
      );
    }

    const wm = new THREE.Mesh(mergeParts(wParts), mat);
    wm.castShadow = true;
    wg.add(wm);
    bodyPivot.add(wg);
    return wg;
  };

  const wingLeft = buildRaptorWing(-1);
  const wingRight = buildRaptorWing(1);

  // Fanned raptor tail
  const tailPivot = new THREE.Group();
  tailPivot.position.set(0, 0.02, -0.78);
  bodyPivot.add(tailPivot);

  const tailParts: THREE.BufferGeometry[] = [];
  for (let i = -3; i <= 3; i++) {
    tailParts.push(
      transformGeo(rbox(0.16, 0.025, 0.72, 0.01, Math.abs(i) === 3 ? plumageGold : plumageDark), {
        rot: [0, i * 0.11, 0],
        pos: [i * 0.08, 0, -0.32],
      })
    );
  }
  const tailMesh = new THREE.Mesh(mergeParts(tailParts), mat);
  tailMesh.castShadow = true;
  tailPivot.add(tailMesh);

  // Projected ground/air warning ring for eagle stoop lock-on
  const ringGeo = new THREE.RingGeometry(1.4, 1.85, 32);
  ringGeo.rotateX(-Math.PI * 0.5);
  const warningRing = new THREE.Mesh(ringGeo, warningMat);
  warningRing.visible = false;

  return { root, bodyPivot, wingLeft, wingRight, tailPivot, warningRing };
}

function buildBaitTrapRig(
  mat: THREE.NodeMaterial,
  beaconMat: THREE.NodeMaterial
): {
  root: THREE.Group;
  doorPivot: THREE.Group;
  latchPivot: THREE.Group;
  beaconRing: THREE.Mesh;
  baitGroup: THREE.Group;
} {
  const root = new THREE.Group();

  // Timber base board & arched brass/wire cage ribs
  const baseParts: THREE.BufferGeometry[] = [
    transformGeo(rbox(1.95, 0.14, 1.65, 0.04, PALETTE.woodOak), {
      pos: [0, 0.07, 0],
    }),
    // Corner posts
    transformGeo(rcyl(0.055, 0.055, 1.25, PALETTE.woodWalnut, 8), { pos: [-0.84, 0.68, -0.7] }),
    transformGeo(rcyl(0.055, 0.055, 1.25, PALETTE.woodWalnut, 8), { pos: [0.84, 0.68, -0.7] }),
    transformGeo(rcyl(0.055, 0.055, 1.25, PALETTE.woodWalnut, 8), { pos: [-0.84, 0.68, 0.7] }),
    transformGeo(rcyl(0.055, 0.055, 1.25, PALETTE.woodWalnut, 8), { pos: [0.84, 0.68, 0.7] }),
    // Top roof beam
    transformGeo(rbox(1.82, 0.09, 1.52, 0.03, PALETTE.woodWalnut), {
      pos: [0, 1.32, 0],
    }),
  ];

  // Brass wire bars along left, right, back, and roof
  for (let i = -3; i <= 3; i++) {
    const x = i * 0.24;
    baseParts.push(
      transformGeo(rcyl(0.022, 0.022, 1.2, PALETTE.brassWarm, 6), { pos: [x, 0.68, -0.7] }),
      transformGeo(rcyl(0.022, 0.022, 1.42, PALETTE.brassWarm, 6), {
        rot: [Math.PI * 0.5, 0, 0],
        pos: [x, 1.32, 0],
      })
    );
  }
  for (let j = -2; j <= 2; j++) {
    const z = j * 0.26;
    baseParts.push(
      transformGeo(rcyl(0.022, 0.022, 1.2, PALETTE.brassWarm, 6), { pos: [-0.84, 0.68, z] }),
      transformGeo(rcyl(0.022, 0.022, 1.2, PALETTE.brassWarm, 6), { pos: [0.84, 0.68, z] })
    );
  }

  const cageMesh = new THREE.Mesh(mergeParts(baseParts), mat);
  cageMesh.castShadow = true;
  cageMesh.receiveShadow = true;
  root.add(cageMesh);

  // Hinged front spring-door (`+Z` side)
  const doorPivot = new THREE.Group();
  doorPivot.position.set(0, 1.28, 0.72);
  root.add(doorPivot);

  const doorParts: THREE.BufferGeometry[] = [
    transformGeo(rbox(1.56, 0.07, 0.07, 0.02, PALETTE.woodWalnut), { pos: [0, -1.12, 0] }),
  ];
  for (let i = -3; i <= 3; i++) {
    doorParts.push(
      transformGeo(rcyl(0.022, 0.022, 1.14, PALETTE.brassWarm, 6), {
        pos: [i * 0.22, -0.57, 0],
      })
    );
  }
  const doorMesh = new THREE.Mesh(mergeParts(doorParts), mat);
  doorMesh.castShadow = true;
  doorPivot.add(doorMesh);

  // Exterior Golden Release Latch on the right side (`+X`) for safe pecking
  const latchPivot = new THREE.Group();
  latchPivot.position.set(0.96, 0.64, 0.35);
  root.add(latchPivot);

  const latchGeo = mergeParts([
    transformGeo(rbox(0.22, 0.16, 0.24, 0.03, PALETTE.brassWarm), { pos: [0, 0, 0] }),
    transformGeo(rcyl(0.04, 0.04, 0.38, PALETTE.goldGlow, 8), {
      rot: [0, 0, -0.55],
      pos: [0.14, 0.14, 0],
    }),
    transformGeo(smoothSphere(0.085, PALETTE.awningCoral, 10, 8), {
      pos: [0.24, 0.28, 0],
    }),
  ]);
  const latchMesh = new THREE.Mesh(latchGeo, mat);
  latchMesh.castShadow = true;
  latchPivot.add(latchMesh);

  // Interior red trigger pad + golden bait crumbs
  const baitGroup = new THREE.Group();
  baitGroup.position.set(0, 0.16, 0.25);
  root.add(baitGroup);

  const baitGeo = mergeParts([
    transformGeo(rcyl(0.26, 0.28, 0.05, PALETTE.tulipCoral, 14), { pos: [0, 0.02, 0] }),
    transformGeo(smoothSphere(0.06, PALETTE.croissantButter, 8, 6), { pos: [-0.08, 0.06, 0.04] }),
    transformGeo(smoothSphere(0.055, PALETTE.goldGlow, 8, 6), { pos: [0.07, 0.06, -0.03] }),
    transformGeo(smoothSphere(0.05, PALETTE.croissantButter, 8, 6), { pos: [0.02, 0.06, 0.08] }),
  ]);
  const baitMesh = new THREE.Mesh(baitGeo, mat);
  baitGroup.add(baitMesh);

  // Pulsing rescue ring around the trap
  const ringGeo = new THREE.RingGeometry(1.18, 1.38, 28);
  ringGeo.rotateX(-Math.PI * 0.5);
  const beaconRing = new THREE.Mesh(ringGeo, beaconMat);
  beaconRing.position.set(0, 0.05, 0);
  root.add(beaconRing);

  return { root, doorPivot, latchPivot, beaconRing, baitGroup };
}

/**
 * Manages the 7-Day Neighborhood Survival & Bird Rescue hazards:
 * - 3 Prowling Alley Cats (`😾`)
 * - 2 Soaring Sky Eagles (`egel`)
 * - 4 Baited Spring-Cage Bird Traps (`🪤`) holding fluttering Captive Songbirds (`birds`)
 * - Patrolling Human Bird Trapper (`human 🪤`) proximity check
 */
export class PredatorAndTrapSystem {
  private readonly group = new THREE.Group();
  private readonly mat: THREE.NodeMaterial;
  private readonly warningMat: THREE.NodeMaterial;
  private readonly rescueRingMat: THREE.NodeMaterial;

  private readonly cats: AlleyCatInstance[] = [];
  private readonly eagles: SkyEagleInstance[] = [];
  private readonly traps: BirdTrapInstance[] = [];

  private currentQuota: DailyHazardQuota = SEVEN_DAY_QUOTAS[0];
  private playerCaptureImmunityTimer = 0;
  private trapperCloseTimer = 0;
  private trapperWarnCooldown = 0;

  private activeThreatType: HazardThreatType = 'none';
  private activeThreatMessage = '';

  public onPlayerCaptured?: (source: HazardThreatType, message: string) => void;
  public onBirdRescued?: (trapId: string, speciesLabel: string, blockName: string, worldPos: THREE.Vector3) => void;

  constructor(
    scene: THREE.Scene,
    private physics: PhysicsWorld,
    private sparrow: SparrowController,
    private npcs: NPCManager,
    private audio: AcousticSoundtrack,
    private fx: WorldFX
  ) {
    scene.add(this.group);
    this.mat = createPastelMaterial({ vertexColors: true, rimStrength: 0.09 });
    this.warningMat = createUnlitPastelFXMaterial(0xe84838, 0.72, false);
    this.rescueRingMat = createUnlitPastelFXMaterial(0xf5c842, 0.68, false);

    this.initAlleyCats();
    this.initSkyEagles();
    this.initBirdTraps();
    this.configureForDay(1);
  }

  private initAlleyCats(): void {
    const catConfigs: Array<{
      id: string;
      name: string;
      coatHex: number;
      bellyHex: number;
      stripeHex: number;
      eyeHex: number;
      waypoints: THREE.Vector3[];
    }> = [
      {
        id: 'cat_bistro_ginger',
        name: 'Ginger Bistro Tabby',
        coatHex: 0xd97236,
        bellyHex: 0xf7e6cf,
        stripeHex: 0x8c3b16,
        eyeHex: 0x52b848,
        waypoints: [
          new THREE.Vector3(-28.0, 0.35, 48.0),
          new THREE.Vector3(-22.0, 0.35, 62.0),
          new THREE.Vector3(-32.0, 0.35, 68.0),
          new THREE.Vector3(-22.0, 0.35, 54.0),
        ],
      },
      {
        id: 'cat_park_tuxedo',
        name: 'Park Tuxedo Cat',
        coatHex: 0x26242b,
        bellyHex: 0xf5f2eb,
        stripeHex: 0x141218,
        eyeHex: 0xf2b632,
        waypoints: [
          new THREE.Vector3(58.0, 0.35, 42.0),
          new THREE.Vector3(72.0, 0.35, 52.0),
          new THREE.Vector3(62.0, 0.35, 66.0),
          new THREE.Vector3(52.0, 0.35, 54.0),
        ],
      },
      {
        id: 'cat_market_marmalade',
        name: 'Market Alley Cat',
        coatHex: 0x786c64,
        bellyHex: 0xe6ddd5,
        stripeHex: 0x3d3530,
        eyeHex: 0x66cc52,
        waypoints: [
          new THREE.Vector3(46.0, 0.35, -58.0),
          new THREE.Vector3(62.0, 0.35, -72.0),
          new THREE.Vector3(40.0, 0.35, -76.0),
          new THREE.Vector3(54.0, 0.35, -62.0),
        ],
      },
    ];

    for (const cfg of catConfigs) {
      const rig = buildCatRig(
        cfg.coatHex,
        cfg.bellyHex,
        cfg.stripeHex,
        cfg.eyeHex,
        this.mat,
        this.warningMat
      );
      const startPos = cfg.waypoints[0].clone();
      rig.root.position.copy(startPos);
      this.group.add(rig.root);

      this.cats.push({
        id: cfg.id,
        name: cfg.name,
        activeForDay: true,
        root: rig.root,
        bodyPivot: rig.bodyPivot,
        headPivot: rig.headPivot,
        tailPivot: rig.tailPivot,
        legFL: rig.legFL,
        legFR: rig.legFR,
        legBL: rig.legBL,
        legBR: rig.legBR,
        warningRing: rig.warningRing,
        position: startPos,
        yaw: 0,
        waypoints: cfg.waypoints,
        wpIndex: 1,
        state: 'patrol',
        stateTimer: 0,
        pounceStart: new THREE.Vector3(),
        pounceTarget: new THREE.Vector3(),
        pounceDuration: 0.42,
        gaitPhase: Math.random() * 6.28,
      });
    }
  }

  private initSkyEagles(): void {
    const eagleSpecs = [
      {
        id: 'eagle_golden_north',
        center: new THREE.Vector3(10.0, 76.0, 12.0),
        radius: 62.0,
        altitude: 76.0,
        speed: 0.24,
        startAngle: 0.4,
      },
      {
        id: 'eagle_imperial_south',
        center: new THREE.Vector3(-16.0, 84.0, -24.0),
        radius: 68.0,
        altitude: 84.0,
        speed: -0.22,
        startAngle: 3.5,
      },
    ];

    for (const spec of eagleSpecs) {
      const rig = buildEagleRig(this.mat, this.warningMat);
      this.group.add(rig.root);
      this.group.add(rig.warningRing);

      const startPos = new THREE.Vector3(
        spec.center.x + Math.cos(spec.startAngle) * spec.radius,
        spec.altitude,
        spec.center.z + Math.sin(spec.startAngle) * spec.radius
      );
      rig.root.position.copy(startPos);

      this.eagles.push({
        id: spec.id,
        activeForDay: true,
        root: rig.root,
        bodyPivot: rig.bodyPivot,
        wingLeft: rig.wingLeft,
        wingRight: rig.wingRight,
        tailPivot: rig.tailPivot,
        warningRing: rig.warningRing,
        orbitCenter: spec.center,
        orbitRadius: spec.radius,
        orbitAltitude: spec.altitude,
        orbitAngle: spec.startAngle,
        orbitSpeed: spec.speed,
        position: startPos,
        yaw: 0,
        pitch: 0,
        bank: 0,
        state: 'soar',
        stateTimer: 0,
        huntCooldown: 9.0 + Math.random() * 5.0,
        stoopStart: new THREE.Vector3(),
        stoopTarget: new THREE.Vector3(),
        stoopDuration: 1.05,
        flapPhase: Math.random() * 6.28,
      });
    }
  }

  private initBirdTraps(): void {
    const trapSpecs: Array<{
      id: string;
      species: BirdSpecies;
      speciesLabel: string;
      blockName: string;
      pos: THREE.Vector3;
      yaw: number;
    }> = [
      {
        id: 'trap_nw_bistro',
        species: 'blue_tit',
        speciesLabel: 'Blue Tit',
        blockName: 'NW Bistro Promenade',
        pos: new THREE.Vector3(-25.0, 0.35, 60.0),
        yaw: 0.35,
      },
      {
        id: 'trap_ne_park',
        species: 'robin',
        speciesLabel: 'European Robin',
        blockName: 'NE Botanical Park',
        pos: new THREE.Vector3(68.0, 0.35, 52.0),
        yaw: -0.65,
      },
      {
        id: 'trap_sw_canal',
        species: 'goldfinch',
        speciesLabel: 'European Goldfinch',
        blockName: 'SW Canal Quay',
        pos: new THREE.Vector3(-64.0, 0.35, -75.5),
        yaw: 0.85,
      },
      {
        id: 'trap_se_market',
        species: 'finch',
        speciesLabel: 'Rose Finch',
        blockName: 'SE Market Square',
        pos: new THREE.Vector3(46.0, 0.35, -66.0),
        yaw: -0.4,
      },
    ];

    for (const spec of trapSpecs) {
      const rig = buildBaitTrapRig(this.mat, this.rescueRingMat);
      const snappedPos = spec.pos.clone();
      _probeOrigin.set(snappedPos.x, snappedPos.y + 3.0, snappedPos.z);
      const gHit = this.physics.raycastGround(
        _probeOrigin,
        _down,
        8.0,
        undefined,
        _groundHit,
        COLLISION_GROUP_STATIC
      );
      if (gHit.hit && gHit.normal.y > 0.6) {
        snappedPos.y = gHit.point.y;
      }

      rig.root.position.copy(snappedPos);
      rig.root.rotation.y = spec.yaw;
      this.group.add(rig.root);

      const captiveBird = new SparrowMesh(spec.species);
      const captivePos = snappedPos.clone();
      captivePos.y += 0.42;
      captiveBird.root.position.copy(captivePos);
      captiveBird.root.rotation.y = spec.yaw;
      this.group.add(captiveBird.root);

      rig.root.updateMatrixWorld(true);
      const latchWorldPos = new THREE.Vector3();
      rig.latchPivot.getWorldPosition(latchWorldPos);
      const baitWorldPos = new THREE.Vector3();
      rig.baitGroup.getWorldPosition(baitWorldPos);

      const trapInst: BirdTrapInstance = {
        id: spec.id,
        species: spec.species,
        speciesLabel: spec.speciesLabel,
        blockName: spec.blockName,
        activeForDay: true,
        state: 'armed_captive',
        root: rig.root,
        doorPivot: rig.doorPivot,
        latchPivot: rig.latchPivot,
        beaconRing: rig.beaconRing,
        baitGroup: rig.baitGroup,
        captiveBird,
        captivePos,
        captiveFlightVel: new THREE.Vector3(),
        position: snappedPos,
        latchWorldPos,
        baitWorldPos,
        callTimer: 2.5 + Math.random() * 3.0,
        flutterPhase: Math.random() * 6.28,
      };

      // Register exterior brass release latch with PhysicsWorld PeckSwitch so F / Click / Mobile Tap frees the captive bird
      this.physics.peckSwitches.push({
        id: `rescue_latch_${spec.id}`,
        position: latchWorldPos,
        radius: 2.35,
        cooldown: 0,
        onPeck: () => {
          this.rescueCaptiveBird(trapInst);
        },
      });

      this.traps.push(trapInst);
    }
  }

  public configureForDay(day: number): DailyHazardQuota {
    const idx = Math.max(0, Math.min(SEVEN_DAY_QUOTAS.length - 1, day - 1));
    const quota = SEVEN_DAY_QUOTAS[idx];
    this.currentQuota = quota;

    for (let i = 0; i < this.cats.length; i++) {
      const cat = this.cats[i];
      cat.activeForDay = i < quota.activeCats;
      cat.root.visible = cat.activeForDay;
      cat.warningRing.visible = false;
      cat.state = 'patrol';
      cat.stateTimer = 0;
      cat.position.copy(cat.waypoints[0]);
      cat.root.position.copy(cat.position);
    }

    for (let i = 0; i < this.eagles.length; i++) {
      const eagle = this.eagles[i];
      eagle.activeForDay = i < quota.activeEagles;
      eagle.root.visible = eagle.activeForDay;
      eagle.warningRing.visible = false;
      eagle.state = 'soar';
      eagle.stateTimer = 0;
      eagle.huntCooldown = 8.0 + i * 5.0;
    }

    for (let i = 0; i < this.traps.length; i++) {
      const trap = this.traps[i];
      trap.activeForDay = i < quota.activeTraps;
      if (trap.activeForDay) {
        trap.state = 'armed_captive';
        trap.root.visible = true;
        trap.doorPivot.rotation.x = 0;
        trap.latchPivot.rotation.z = 0;
        trap.beaconRing.visible = true;
        trap.baitGroup.visible = true;
        trap.captivePos.set(trap.position.x, trap.position.y + 0.42, trap.position.z);
        trap.captiveBird.root.position.copy(trap.captivePos);
        trap.captiveBird.root.visible = true;
      } else {
        trap.state = 'inactive';
        trap.root.visible = false;
        trap.beaconRing.visible = false;
        trap.captiveBird.root.visible = false;
      }
    }

    return quota;
  }

  public getActiveThreat(): { type: HazardThreatType; message: string } {
    return { type: this.activeThreatType, message: this.activeThreatMessage };
  }

  public getNearestArmedTrapPosition(fromPos: THREE.Vector3): THREE.Vector3 | null {
    let best: THREE.Vector3 | null = null;
    let bestDistSq = Infinity;
    for (let i = 0; i < this.traps.length; i++) {
      const t = this.traps[i];
      if (!t.activeForDay || t.state !== 'armed_captive') continue;
      const dSq = t.position.distanceToSquared(fromPos);
      if (dSq < bestDistSq) {
        bestDistSq = dSq;
        best = t.latchWorldPos;
      }
    }
    return best;
  }

  private rescueCaptiveBird(trap: BirdTrapInstance): void {
    if (!trap.activeForDay || trap.state !== 'armed_captive') return;
    trap.state = 'rescued_open';
    trap.doorPivot.rotation.x = -Math.PI * 0.68;
    trap.latchPivot.rotation.z = 0.65;
    trap.beaconRing.visible = false;
    trap.baitGroup.visible = false;

    _delta.subVectors(_sanctuaryDest, trap.captivePos).normalize();
    trap.captiveFlightVel.set(_delta.x * 11.5, 9.5, _delta.z * 11.5);

    this.audio.playBirdRescueFanfare(trap.position);
    this.fx.spawnFeatherBurst(trap.captivePos, 10, 3.4);
    this.fx.spawnBurst(trap.latchWorldPos, 12, true, 4.2);
    this.fx.spawnChirpRing(trap.captivePos, PALETTE.goldGlow, 9.5);

    this.onBirdRescued?.(trap.id, trap.speciesLabel, trap.blockName, trap.position);
  }

  private triggerPlayerCapture(source: HazardThreatType, message: string): void {
    if (this.playerCaptureImmunityTimer > 0) return;
    this.playerCaptureImmunityTimer = 3.2;
    this.activeThreatType = 'none';
    this.activeThreatMessage = '';
    this.onPlayerCaptured?.(source, message);
  }

  private isPlayerUnderCover(pos: THREE.Vector3): boolean {
    if (isInsideAtelier(pos) || this.sparrow.tutorialSafeZone) return true;
    // Raycast upward to see if the sparrow is under an awning, balcony, bridge, or dense tree canopy
    _probeOrigin.set(pos.x, pos.y + 0.4, pos.z);
    const upDir = _down.set(0, 1, 0);
    const roofCheck = this.physics.raycastGround(
      _probeOrigin,
      upDir,
      14.0,
      undefined,
      _groundHit,
      COLLISION_GROUP_STATIC
    );
    _down.set(0, -1, 0);
    return roofCheck.hit;
  }

  public update(dt: number, elapsed: number): void {
    const clamped = Math.min(0.05, dt);
    if (this.playerCaptureImmunityTimer > 0) {
      this.playerCaptureImmunityTimer = Math.max(0, this.playerCaptureImmunityTimer - clamped);
    }
    if (this.trapperWarnCooldown > 0) {
      this.trapperWarnCooldown = Math.max(0, this.trapperWarnCooldown - clamped);
    }

    this.activeThreatType = 'none';
    this.activeThreatMessage = '';

    const playerPos = this.sparrow.position;
    const playerProtected =
      this.sparrow.tutorialSafeZone ||
      isInsideAtelier(playerPos) ||
      this.playerCaptureImmunityTimer > 0;

    this.updateAlleyCats(clamped, elapsed, playerPos, playerProtected);
    this.updateSkyEagles(clamped, elapsed, playerPos, playerProtected);
    this.updateBirdTraps(clamped, elapsed, playerPos, playerProtected);
    this.updateHumanTrapper(clamped, playerPos, playerProtected);
  }

  private updateAlleyCats(
    dt: number,
    elapsed: number,
    playerPos: THREE.Vector3,
    playerProtected: boolean
  ): void {
    for (let i = 0; i < this.cats.length; i++) {
      const cat = this.cats[i];
      if (!cat.activeForDay) continue;

      const distHoriz = Math.hypot(playerPos.x - cat.position.x, playerPos.z - cat.position.z);
      const heightDiff = playerPos.y - cat.position.y;

      if (cat.state === 'patrol') {
        cat.warningRing.visible = false;
        const targetWp = cat.waypoints[cat.wpIndex];
        const dx = targetWp.x - cat.position.x;
        const dz = targetWp.z - cat.position.z;
        const dWp = Math.hypot(dx, dz);

        if (dWp < 0.85) {
          cat.wpIndex = (cat.wpIndex + 1) % cat.waypoints.length;
        } else {
          const speed = 3.8;
          const step = Math.min(dWp, speed * dt);
          cat.position.x += (dx / dWp) * step;
          cat.position.z += (dz / dWp) * step;
          const desiredYaw = Math.atan2(dx, dz);
          let diff = desiredYaw - cat.yaw;
          while (diff > Math.PI) diff -= Math.PI * 2;
          while (diff < -Math.PI) diff += Math.PI * 2;
          cat.yaw += diff * Math.min(1, dt * 8.0);
        }

        // Snap cat to ground
        _probeOrigin.set(cat.position.x, cat.position.y + 2.5, cat.position.z);
        const gHit = this.physics.raycastGround(
          _probeOrigin,
          _down,
          6.0,
          undefined,
          _groundHit,
          COLLISION_GROUP_STATIC
        );
        if (gHit.hit && gHit.normal.y > 0.55) {
          cat.position.y = gHit.point.y;
        }

        cat.gaitPhase += dt * 9.5;
        const swing = Math.sin(cat.gaitPhase) * 0.45;
        cat.legFL.rotation.x = swing;
        cat.legBR.rotation.x = swing;
        cat.legFR.rotation.x = -swing;
        cat.legBL.rotation.x = -swing;
        cat.bodyPivot.position.y = 0.56 + Math.abs(Math.sin(cat.gaitPhase * 2)) * 0.04;
        cat.bodyPivot.rotation.x = 0;
        cat.tailPivot.rotation.y = Math.sin(elapsed * 3.6 + i) * 0.35;

        // Check if player sparrow is low enough & close enough to stalk
        if (!playerProtected && distHoriz < 14.5 && heightDiff >= -1.0 && heightDiff <= 4.2) {
          cat.state = 'stalk';
          cat.stateTimer = this.currentQuota.stalkDuration;
          this.audio.playCatMeowHiss(cat.position);
        }
      } else if (cat.state === 'stalk') {
        if (playerProtected || distHoriz > 18.5 || heightDiff > 5.4) {
          cat.state = 'patrol';
          cat.warningRing.visible = false;
        } else {
          const dx = playerPos.x - cat.position.x;
          const dz = playerPos.z - cat.position.z;
          cat.yaw = Math.atan2(dx, dz);

          // Low crouch + rapid tail wiggle
          cat.bodyPivot.position.y = 0.36;
          cat.bodyPivot.rotation.x = 0.14;
          cat.tailPivot.rotation.y = Math.sin(elapsed * 24.0) * 0.65;
          cat.warningRing.visible = true;
          const pulse = 0.9 + Math.sin(elapsed * 18.0) * 0.16;
          cat.warningRing.scale.setScalar(pulse);

          this.activeThreatType = 'cat';
          this.activeThreatMessage = '😾 Alley Cat stalking! Fly up [SPACE]!';

          cat.stateTimer -= dt;
          if (cat.stateTimer <= 0) {
            cat.state = 'pounce';
            cat.stateTimer = 0;
            cat.pounceStart.copy(cat.position);
            cat.pounceTarget.copy(playerPos);
            const pDist = Math.max(2.5, Math.min(13.5, cat.pounceStart.distanceTo(cat.pounceTarget)));
            cat.pounceDuration = Math.max(0.28, pDist / 25.0);
            this.audio.playCatMeowHiss(cat.position);
          }
        }
      } else if (cat.state === 'pounce') {
        cat.stateTimer += dt;
        const u = Math.min(1, cat.stateTimer / cat.pounceDuration);
        cat.position.lerpVectors(cat.pounceStart, cat.pounceTarget, u);
        cat.position.y += Math.sin(u * Math.PI) * 2.15;
        cat.bodyPivot.position.y = 0.58;
        cat.bodyPivot.rotation.x = (0.5 - u) * 0.65;
        cat.legFL.rotation.x = -0.65;
        cat.legFR.rotation.x = -0.65;
        cat.legBL.rotation.x = 0.65;
        cat.legBR.rotation.x = 0.65;

        this.activeThreatType = 'cat';
        this.activeThreatMessage = '😾 Cat Pounce!';

        if (!playerProtected && cat.position.distanceTo(playerPos) < 1.58) {
          cat.state = 'cooldown';
          cat.stateTimer = 2.4;
          cat.warningRing.visible = false;
          this.triggerPlayerCapture('cat', 'Pounced by a prowling Alley Cat! 😾');
        } else if (u >= 1) {
          cat.state = 'cooldown';
          cat.stateTimer = 1.9;
          cat.warningRing.visible = false;
          this.fx.spawnBurst(cat.position, 5, false, 2.0);
        }
      } else if (cat.state === 'cooldown') {
        cat.warningRing.visible = false;
        cat.bodyPivot.position.y = 0.52;
        cat.bodyPivot.rotation.x = 0;
        cat.stateTimer -= dt;
        if (cat.stateTimer <= 0) {
          cat.state = 'patrol';
        }
      }

      cat.root.position.copy(cat.position);
      cat.root.rotation.y = cat.yaw;
    }
  }

  private updateSkyEagles(
    dt: number,
    elapsed: number,
    playerPos: THREE.Vector3,
    playerProtected: boolean
  ): void {
    for (let i = 0; i < this.eagles.length; i++) {
      const eagle = this.eagles[i];
      if (!eagle.activeForDay) continue;

      if (eagle.state === 'soar') {
        eagle.warningRing.visible = false;
        eagle.orbitAngle += eagle.orbitSpeed * dt;
        const targetX = eagle.orbitCenter.x + Math.cos(eagle.orbitAngle) * eagle.orbitRadius;
        const targetZ = eagle.orbitCenter.z + Math.sin(eagle.orbitAngle) * eagle.orbitRadius;
        const targetY = eagle.orbitAltitude + Math.sin(elapsed * 0.9 + i) * 3.5;

        const dx = targetX - eagle.position.x;
        const dz = targetZ - eagle.position.z;
        eagle.position.set(targetX, targetY, targetZ);
        eagle.yaw = Math.atan2(dx, dz);
        eagle.pitch = 0;
        eagle.bank = eagle.orbitSpeed > 0 ? -0.28 : 0.28;

        eagle.flapPhase += dt * 4.2;
        const flap = Math.sin(eagle.flapPhase) * 0.22;
        eagle.wingLeft.rotation.z = flap;
        eagle.wingRight.rotation.z = -flap;

        eagle.huntCooldown -= dt;
        const distHoriz = Math.hypot(playerPos.x - eagle.position.x, playerPos.z - eagle.position.z);
        const playerExposedHigh =
          !playerProtected &&
          playerPos.y > 12.5 &&
          distHoriz < 74.0 &&
          !this.isPlayerUnderCover(playerPos);

        if (eagle.huntCooldown <= 0 && playerExposedHigh) {
          eagle.state = 'lock_on';
          eagle.stateTimer = this.currentQuota.stoopLockDuration;
          eagle.stoopTarget.copy(playerPos);
          this.audio.playEagleScreech(eagle.position);
        }
      } else if (eagle.state === 'lock_on') {
        // Track player softly during lock-on unless player ducks under cover
        if (playerProtected || this.isPlayerUnderCover(playerPos)) {
          eagle.state = 'recover';
          eagle.stateTimer = 2.2;
          eagle.huntCooldown = 10.0;
          eagle.warningRing.visible = false;
        } else {
          eagle.stoopTarget.lerp(playerPos, Math.min(1, dt * 6.5));
          const dx = eagle.stoopTarget.x - eagle.position.x;
          const dz = eagle.stoopTarget.z - eagle.position.z;
          eagle.yaw = Math.atan2(dx, dz);
          eagle.pitch = 0.45;
          eagle.bank = 0;

          eagle.warningRing.visible = true;
          eagle.warningRing.position.set(
            eagle.stoopTarget.x,
            eagle.stoopTarget.y + 0.15,
            eagle.stoopTarget.z
          );
          const lockFrac = Math.max(0.25, eagle.stateTimer / this.currentQuota.stoopLockDuration);
          eagle.warningRing.scale.setScalar(0.55 + lockFrac * 1.15);

          this.activeThreatType = 'eagle';
          this.activeThreatMessage = '🦅 Sky Eagle locked on! Dive [SHIFT] or duck under cover!';

          eagle.stateTimer -= dt;
          if (eagle.stateTimer <= 0) {
            eagle.state = 'stoop';
            eagle.stateTimer = 0;
            eagle.stoopStart.copy(eagle.position);
            eagle.stoopTarget.copy(playerPos);
            const dist3D = Math.max(12.0, eagle.stoopStart.distanceTo(eagle.stoopTarget));
            eagle.stoopDuration = Math.max(0.52, Math.min(1.25, dist3D / 54.0));
            this.audio.playEagleScreech(eagle.position);
          }
        }
      } else if (eagle.state === 'stoop') {
        eagle.stateTimer += dt;
        const u = Math.min(1, eagle.stateTimer / eagle.stoopDuration);
        eagle.position.lerpVectors(eagle.stoopStart, eagle.stoopTarget, u);

        const dx = eagle.stoopTarget.x - eagle.stoopStart.x;
        const dy = eagle.stoopTarget.y - eagle.stoopStart.y;
        const dz = eagle.stoopTarget.z - eagle.stoopStart.z;
        eagle.yaw = Math.atan2(dx, dz);
        eagle.pitch = -Math.atan2(dy, Math.hypot(dx, dz));
        eagle.bank = 0;
        // Tuck wings partially during high-speed raptor stoop
        eagle.wingLeft.rotation.z = -0.38;
        eagle.wingRight.rotation.z = 0.38;

        eagle.warningRing.visible = true;
        eagle.warningRing.position.set(
          eagle.stoopTarget.x,
          eagle.stoopTarget.y + 0.12,
          eagle.stoopTarget.z
        );
        eagle.warningRing.scale.setScalar(0.55);

        this.activeThreatType = 'eagle';
        this.activeThreatMessage = '🦅 Eagle Stooping! Dive [SHIFT] to evade!';

        // If player is actively diving (`Shift`), the stooping eagle's capture radius is much smaller so diving rewards evasion
        const captureRadius = this.sparrow.isDiving() ? 0.92 : 1.95;
        if (
          !playerProtected &&
          !this.isPlayerUnderCover(playerPos) &&
          eagle.position.distanceTo(playerPos) < captureRadius
        ) {
          eagle.state = 'recover';
          eagle.stateTimer = 3.0;
          eagle.huntCooldown = 13.0;
          eagle.warningRing.visible = false;
          this.triggerPlayerCapture('eagle', 'Swept up by a stooping Sky Eagle! 🦅');
        } else if (u >= 1) {
          eagle.state = 'recover';
          eagle.stateTimer = 2.8;
          eagle.huntCooldown = 11.5 + Math.random() * 4.5;
          eagle.warningRing.visible = false;
          this.fx.spawnBurst(eagle.position, 6, false, 2.8);
        }
      } else if (eagle.state === 'recover') {
        eagle.warningRing.visible = false;
        eagle.orbitAngle += eagle.orbitSpeed * dt;
        const targetX = eagle.orbitCenter.x + Math.cos(eagle.orbitAngle) * eagle.orbitRadius;
        const targetZ = eagle.orbitCenter.z + Math.sin(eagle.orbitAngle) * eagle.orbitRadius;
        eagle.position.x += (targetX - eagle.position.x) * Math.min(1, dt * 2.2);
        eagle.position.z += (targetZ - eagle.position.z) * Math.min(1, dt * 2.2);
        eagle.position.y += (eagle.orbitAltitude - eagle.position.y) * Math.min(1, dt * 1.8);
        eagle.pitch = -0.32;
        eagle.flapPhase += dt * 9.5;
        const flap = Math.sin(eagle.flapPhase) * 0.48;
        eagle.wingLeft.rotation.z = flap;
        eagle.wingRight.rotation.z = -flap;

        eagle.stateTimer -= dt;
        if (eagle.stateTimer <= 0) {
          eagle.state = 'soar';
        }
      }

      eagle.root.position.copy(eagle.position);
      eagle.root.rotation.y = eagle.yaw;
      eagle.bodyPivot.rotation.x = eagle.pitch;
      eagle.bodyPivot.rotation.z = eagle.bank;
    }
  }

  private updateBirdTraps(
    dt: number,
    elapsed: number,
    playerPos: THREE.Vector3,
    playerProtected: boolean
  ): void {
    for (let i = 0; i < this.traps.length; i++) {
      const trap = this.traps[i];
      if (!trap.activeForDay || trap.state === 'inactive') continue;

      if (trap.state === 'armed_captive') {
        // Pulse golden rescue ring
        const pulse = 0.92 + Math.sin(elapsed * 5.2 + i) * 0.1;
        trap.beaconRing.scale.setScalar(pulse);

        // Animate captive songbird hopping & fluttering inside the cage
        trap.flutterPhase += dt * 4.5;
        const hopPhase = (trap.flutterPhase % 1.0);
        _captivePoseScratch.dt = dt;
        _captivePoseScratch.elapsed = elapsed;
        _captivePoseScratch.mode = 'grounded';
        _captivePoseScratch.hopPhase = hopPhase;
        _captivePoseScratch.flapTimer = Math.sin(elapsed * 8.0 + i) > 0.3 ? 0.55 : 0;
        _captivePoseScratch.chirpOpen = trap.callTimer < 0.35 ? 0.85 : 0;
        trap.captiveBird.updatePose(_captivePoseScratch);
        trap.captiveBird.root.rotation.y += Math.sin(elapsed * 2.1 + i) * dt * 1.4;

        // Periodic distress chirp when player is within 38 SU
        const distToPlayer = trap.position.distanceTo(playerPos);
        trap.callTimer -= dt;
        if (trap.callTimer <= 0) {
          trap.callTimer = 3.2 + Math.random() * 2.4;
          if (distToPlayer < 42.0 && !isInsideAtelier(playerPos)) {
            this.audio.playSparrowChirp(false);
            this.fx.spawnChirpRing(trap.captivePos, PALETTE.goldGlow, 5.5);
          }
        }

        // Check if player stepped directly onto the interior red bait snare without pecking the exterior latch
        if (!playerProtected) {
          const distToBait = playerPos.distanceTo(trap.baitWorldPos);
          const distToLatch = playerPos.distanceTo(trap.latchWorldPos);
          if (distToBait < 0.66 && distToLatch > 0.82 && this.sparrow.getPeckPhase() <= 0.05) {
            this.audio.playTrapSnap(trap.position);
            this.triggerPlayerCapture(
              'trap',
              'Snared on a Bird Trap bait pad! 🪤 Peck the outer golden latch to free birds safely!'
            );
          } else if (distToPlayer < 4.5 && this.activeThreatType === 'none') {
            this.activeThreatType = 'trap';
            this.activeThreatMessage = `🪤 Captive ${trap.speciesLabel}! Peck [CLICK / F] the outer gold latch to rescue!`;
          }
        }
      } else if (trap.state === 'rescued_open') {
        // Rescued songbird flies joyfully up toward the Clocktower Sky Sanctuary
        if (trap.captiveBird.root.visible) {
          trap.captivePos.addScaledVector(trap.captiveFlightVel, dt);
          trap.captiveBird.root.position.copy(trap.captivePos);
          trap.captiveBird.root.rotation.y = Math.atan2(
            trap.captiveFlightVel.x,
            trap.captiveFlightVel.z
          );
          _captivePoseScratch.dt = dt;
          _captivePoseScratch.elapsed = elapsed;
          _captivePoseScratch.mode = 'flying';
          _captivePoseScratch.hopPhase = 0;
          _captivePoseScratch.flapTimer = 0.75;
          _captivePoseScratch.chirpOpen = 0.5;
          trap.captiveBird.updatePose(_captivePoseScratch);

          if (trap.captivePos.y > 95.0) {
            trap.captiveBird.root.visible = false;
          }
        }
      }
    }
  }

  private updateHumanTrapper(
    dt: number,
    playerPos: THREE.Vector3,
    playerProtected: boolean
  ): void {
    if (playerProtected) {
      this.trapperCloseTimer = 0;
      return;
    }
    const trapper = this.npcs.humans.get('bird_trapper');
    if (!trapper) return;

    const dx = playerPos.x - trapper.root.position.x;
    const dz = playerPos.z - trapper.root.position.z;
    const distHoriz = Math.hypot(dx, dz);
    const relY = playerPos.y - trapper.root.position.y;

    if (distHoriz < 6.2 && relY >= -0.5 && relY <= 4.5) {
      if (this.activeThreatType === 'none') {
        this.activeThreatType = 'trapper';
        this.activeThreatMessage = '🪤 Human Bird Trapper nearby! Fly high!';
      }
      if (this.trapperWarnCooldown <= 0) {
        this.trapperWarnCooldown = 3.2;
        this.npcs.triggerChefShoo(playerPos);
      }
      if (distHoriz < 2.35 && relY <= 3.2) {
        this.trapperCloseTimer += dt;
        if (this.trapperCloseTimer >= 0.55) {
          this.trapperCloseTimer = 0;
          this.audio.playTrapSnap(trapper.root.position);
          this.triggerPlayerCapture('trapper', 'Netted by the patrolling Human Trapper! 🪤');
        }
      } else {
        this.trapperCloseTimer = Math.max(0, this.trapperCloseTimer - dt * 1.5);
      }
    } else {
      this.trapperCloseTimer = 0;
    }
  }
}
