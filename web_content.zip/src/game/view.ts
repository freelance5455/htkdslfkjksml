import * as THREE from "three";
import {
  MAX_WHEEL,
  REDLINE,
  ROAD_HALF,
  TRACK,
  TRACK_RADIUS,
  TRACK_STRAIGHT,
  type SimState,
} from "./sim";

const EYE = new THREE.Vector3(-0.34, 0.92, 0.16);
const PITCH0 = -0.17;
const WHEEL_C = new THREE.Vector3(-0.34, 0.75, -0.32);
const RIM = 0.172;

const SHOULDER_L = new THREE.Vector3(-0.54, 0.86, 0.16);
const SHOULDER_R = new THREE.Vector3(-0.14, 0.86, 0.16);
const UPPER_LEN = 0.26;
const FORE_LEN = 0.25;

const HIP_L = new THREE.Vector3(-0.48, 0.5, 0.34);
const HIP_R = new THREE.Vector3(-0.2, 0.5, 0.34);
const THIGH = 0.44;
const SHIN = 0.42;

const KNOB0 = new THREE.Vector3(0.18, 0.56, 0.04);

const GATES: Record<number, [number, number]> = {
  0: [0, 0],
  1: [-0.042, -0.055],
  2: [-0.042, 0.055],
  3: [0, -0.055],
  4: [0, 0.055],
  5: [0.042, -0.055],
  6: [0.042, 0.055],
};

type Cross = { t: number; from: number; to: number; dur: number };

type HandRig = {
  side: 1 | -1;
  root: THREE.Group;
  fingers: THREE.Group[][];
  thumb: THREE.Group[];
  home: number;
  angle: number;
  curl: number;
  cross: Cross | null;
  sliding: boolean;
};

const _y = new THREE.Vector3(0, 1, 0);
const _dir = new THREE.Vector3();
const _poleT = new THREE.Vector3();
const _from = new THREE.Vector3();
const _to = new THREE.Vector3();
const _m = new THREE.Matrix4();
const _xAxis = new THREE.Vector3();
const _yAxis = new THREE.Vector3();
const _zAxis = new THREE.Vector3();
const _elbow = new THREE.Vector3();
const _wrist = new THREE.Vector3();
const _pole = new THREE.Vector3();

function damp(cur: number, target: number, dt: number, k: number) {
  return cur + (target - cur) * (1 - Math.exp(-k * dt));
}

function wrapPi(a: number) {
  let x = (a + Math.PI) % (Math.PI * 2);
  if (x < 0) x += Math.PI * 2;
  return x - Math.PI;
}

function placeBone(mesh: THREE.Object3D, from: THREE.Vector3, to: THREE.Vector3, unit: number) {
  _from.copy(from);
  _to.copy(to);
  _dir.subVectors(_to, _from);
  const len = Math.max(0.02, _dir.length());
  mesh.position.copy(_from).add(_to).multiplyScalar(0.5);
  _dir.multiplyScalar(1 / len);
  mesh.quaternion.setFromUnitVectors(_y, _dir);
  mesh.scale.set(1, len / unit, 1);
}

function solveElbow(
  origin: THREE.Vector3,
  target: THREE.Vector3,
  pole: THREE.Vector3,
  lenA: number,
  lenB: number,
  out: THREE.Vector3,
) {
  _dir.subVectors(target, origin);
  let d = _dir.length();
  const max = lenA + lenB - 0.008;
  const min = Math.abs(lenA - lenB) + 0.008;
  if (d > max) {
    _dir.multiplyScalar(max / d);
    d = max;
  } else if (d < min) {
    _dir.multiplyScalar(min / Math.max(d, 1e-4));
    d = min;
  }
  if (d < 1e-4) d = 1e-4;
  _dir.multiplyScalar(1 / d);
  const h = (lenA * lenA - lenB * lenB + d * d) / (2 * d);
  const drop = Math.sqrt(Math.max(0, lenA * lenA - h * h));
  out.copy(origin).addScaledVector(_dir, h);
  _poleT.subVectors(pole, origin);
  const proj = _poleT.dot(_dir);
  _poleT.addScaledVector(_dir, -proj);
  if (_poleT.lengthSq() < 1e-6) _poleT.set(0, 1, 0);
  else _poleT.normalize();
  out.addScaledVector(_poleT, drop);
}

function makeCyl(r: number, len: number, n = 7) {
  const g = new THREE.CylinderGeometry(r, r * 0.92, len, n);
  return g;
}

function createHand(side: 1 | -1, skin: THREE.Material, geos: THREE.BufferGeometry[]): HandRig {
  const root = new THREE.Group();
  const palmG = new THREE.BoxGeometry(0.084, 0.094, 0.028);
  geos.push(palmG);
  const palm = new THREE.Mesh(palmG, skin);
  palm.position.set(0, 0.012, 0);
  root.add(palm);
  const heelG = new THREE.SphereGeometry(0.028, 8, 6);
  geos.push(heelG);
  const heel = new THREE.Mesh(heelG, skin);
  heel.scale.set(1.35, 0.75, 0.7);
  heel.position.set(0, -0.032, 0);
  root.add(heel);

  const fingers: THREE.Group[][] = [];
  const specs = [
    { x: -0.03, y: 0.056, lens: [0.034, 0.026, 0.02], r: 0.011 },
    { x: -0.01, y: 0.062, lens: [0.038, 0.028, 0.02], r: 0.0114 },
    { x: 0.01, y: 0.058, lens: [0.034, 0.026, 0.018], r: 0.0108 },
    { x: 0.029, y: 0.05, lens: [0.026, 0.02, 0.016], r: 0.0094 },
  ];
  for (const s of specs) {
    const pivots: THREE.Group[] = [];
    const anchor = new THREE.Group();
    anchor.position.set(s.x * side, s.y, 0.01);
    root.add(anchor);
    let parent: THREE.Object3D = anchor;
    for (const len of s.lens) {
      const pivot = new THREE.Group();
      parent.add(pivot);
      pivots.push(pivot);
      const geo = makeCyl(s.r, len, 6);
      geo.translate(0, len / 2, 0);
      geos.push(geo);
      pivot.add(new THREE.Mesh(geo, skin));
      const kg = new THREE.SphereGeometry(s.r * 1.08, 6, 5);
      geos.push(kg);
      pivot.add(new THREE.Mesh(kg, skin));
      const next = new THREE.Group();
      next.position.y = len;
      pivot.add(next);
      parent = next;
    }
    fingers.push(pivots);
  }

  const thumbAnchor = new THREE.Group();
  thumbAnchor.position.set(side * -0.04, -0.002, 0.012);
  thumbAnchor.rotation.z = side * -0.85;
  thumbAnchor.rotation.y = side * 0.4;
  root.add(thumbAnchor);
  const thumb: THREE.Group[] = [];
  let tp: THREE.Object3D = thumbAnchor;
  for (const len of [0.034, 0.026]) {
    const pivot = new THREE.Group();
    tp.add(pivot);
    thumb.push(pivot);
    const geo = makeCyl(0.012, len, 6);
    geo.translate(0, len / 2, 0);
    geos.push(geo);
    pivot.add(new THREE.Mesh(geo, skin));
    const next = new THREE.Group();
    next.position.y = len;
    pivot.add(next);
    tp = next;
  }

  return {
    side,
    root,
    fingers,
    thumb,
    home: side * 1.02,
    angle: side * 1.02,
    curl: 1,
    cross: null,
    sliding: false,
  };
}

function applyCurl(h: HandRig, curl: number) {
  const waves = [0.7, 1.15, 0.95];
  h.fingers.forEach((pivots, fi) => {
    const loosen = h.sliding ? 0.08 + fi * 0.07 : 0;
    const c = Math.max(0, curl * (1 - loosen));
    pivots.forEach((p, j) => {
      p.rotation.x = -c * (waves[j] ?? 0.8);
    });
  });
  h.thumb.forEach((p, j) => {
    p.rotation.x = -curl * (j === 0 ? 0.5 : 0.75);
  });
}

function updateGrip(h: HandRig, theta: number, dt: number, recenter: boolean, allowCross: boolean) {
  if (h.cross) {
    h.cross.t += dt;
    const u = Math.min(1, h.cross.t / h.cross.dur);
    const s = u * u * (3 - 2 * u);
    h.angle = h.cross.from + (h.cross.to - h.cross.from) * s;
    h.curl = 1 - Math.sin(u * Math.PI) * 0.88;
    h.sliding = true;
    if (u >= 1) h.cross = null;
    return;
  }
  if (recenter && Math.abs(theta) < 0.55) {
    const v = wrapPi(h.angle - theta);
    const dv = wrapPi(h.home - v);
    const nv = v + dv * Math.min(1, dt * 5);
    h.angle = nv + theta;
    h.curl = damp(h.curl, 1, dt, 8);
    h.sliding = false;
    return;
  }
  const v = wrapPi(h.angle - theta);
  const LIMIT = 2.02;
  if (v > LIMIT || v < -LIMIT) {
    const edge = v > 0 ? LIMIT : -LIMIT;
    const targetA = edge + theta;
    h.angle += (targetA - h.angle) * Math.min(1, dt * 14);
    h.curl = damp(h.curl, 0.4, dt, 10);
    h.sliding = true;
    if (allowCross && Math.abs(theta) > 1.55 && Math.abs(targetA - h.angle) < 0.08) {
      const targetV = h.side * 0.95;
      h.cross = { t: 0, from: h.angle, to: targetV + theta, dur: 0.34 };
    }
  } else {
    h.curl = damp(h.curl, 1, dt, 7);
    h.sliding = false;
  }
}

export type CockpitView = {
  update: (sim: SimState, dt: number) => void;
  resize: () => void;
  render: () => void;
  dispose: () => void;
  renderer: THREE.WebGLRenderer;
};

export function createView(canvas: HTMLCanvasElement): CockpitView {
  const low = Math.min(window.devicePixelRatio || 1, window.innerWidth < 900 ? 1 : 1.35);
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: low <= 1,
    alpha: false,
    powerPreference: "high-performance",
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, low <= 1 ? 1.15 : 1.5));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.setClearColor(0xc9bfb0, 1);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xc9bfb0);
  scene.fog = new THREE.Fog(0xc9bfb0, 36, 168);

  const camera = new THREE.PerspectiveCamera(76, 1, 0.06, 400);
  camera.rotation.order = "YXZ";
  camera.position.copy(EYE);
  camera.rotation.x = PITCH0;

  scene.add(new THREE.HemisphereLight(0xd5e2ef, 0x3a4034, 0.95));
  const sun = new THREE.DirectionalLight(0xffd7a8, 1.35);
  sun.position.set(-30, 22, 18);
  scene.add(sun);
  const fill = new THREE.DirectionalLight(0x8ea6c4, 0.28);
  fill.position.set(18, 10, -24);
  scene.add(fill);

  const geos: THREE.BufferGeometry[] = [];
  const mats: THREE.Material[] = [];
  const mat = (color: number, extra?: THREE.MeshLambertMaterialParameters) => {
    const m = new THREE.MeshLambertMaterial({ color, ...extra });
    mats.push(m);
    return m;
  };

  const plastic = mat(0x1a1d22);
  const leather = mat(0x3d2b24);
  const leatherDark = mat(0x141414);
  const metal = mat(0x8d939c);
  const metalDark = mat(0x5c636c);
  const cloth = mat(0x23262c);
  const skin = mat(0xd7a67c);
  const shoe = mat(0x14120f);
  const rubber = mat(0x2a2a2a);
  const paint = mat(0x243038);
  const glass = mat(0xb9c6d4, { transparent: true, opacity: 0.12, depthWrite: false, side: THREE.DoubleSide });
  const amber = mat(0xe3a23a, { emissive: 0xe3a23a, emissiveIntensity: 0.85 });
  const grass = mat(0x5a684c);
  const asphalt = mat(0xffffff, { vertexColors: true, side: THREE.DoubleSide });
  const concrete = mat(0x8a8178);
  const white = mat(0xe7e1d6, { side: THREE.DoubleSide });
  const coneMat = mat(0xd4543c);

  buildWorld(scene, geos, { grass, asphalt, concrete, white, coneMat, paint });

  const car = new THREE.Group();
  scene.add(car);
  const body = new THREE.Group();
  car.add(body);
  body.add(camera);

  const cabin = new THREE.PointLight(0xffe6c2, 1.15, 2.4, 2);
  cabin.position.set(-0.2, 1.12, 0.05);
  body.add(cabin);

  buildShell(body, geos, { plastic, leather, metal, metalDark, paint, glass, rubber, amber, white });

  const wheel = new THREE.Group();
  wheel.position.copy(WHEEL_C);
  body.add(wheel);
  const torus = new THREE.TorusGeometry(RIM, 0.0155, 8, 28);
  geos.push(torus);
  wheel.add(new THREE.Mesh(torus, leatherDark));
  const gripRing = new THREE.TorusGeometry(RIM, 0.0175, 6, 20);
  geos.push(gripRing);
  const gripMat = mat(0x101114);
  const gripMesh = new THREE.Mesh(gripRing, gripMat);
  gripMesh.scale.set(1, 1, 0.55);
  wheel.add(gripMesh);
  for (const a of [Math.PI, Math.PI * 0.62, -Math.PI * 0.62]) {
    const g = new THREE.BoxGeometry(0.014, RIM * 0.92, 0.01);
    geos.push(g);
    const spoke = new THREE.Mesh(g, metal);
    spoke.position.set(Math.sin(a) * RIM * 0.42, Math.cos(a) * RIM * 0.42, 0);
    spoke.rotation.z = -a;
    wheel.add(spoke);
  }
  const hubG = new THREE.CylinderGeometry(0.045, 0.045, 0.03, 12);
  hubG.rotateX(Math.PI / 2);
  geos.push(hubG);
  const hub = new THREE.Mesh(hubG, plastic);
  wheel.add(hub);
  const capG = new THREE.SphereGeometry(0.022, 10, 8);
  geos.push(capG);
  const cap = new THREE.Mesh(capG, amber);
  cap.position.z = 0.02;
  cap.scale.z = 0.45;
  wheel.add(cap);

  const column = new THREE.Mesh(makeCyl(0.02, 1, 6), metalDark);
  geos.push(column.geometry);
  body.add(column);

  const left = createHand(-1, skin, geos);
  const right = createHand(1, skin, geos);
  body.add(left.root, right.root);

  const armGeo = makeCyl(0.04, 1, 6);
  const foreGeo = makeCyl(0.032, 1, 6);
  geos.push(armGeo, foreGeo);
  const armL = new THREE.Mesh(armGeo, cloth);
  const armR = new THREE.Mesh(armGeo, cloth);
  const foreL = new THREE.Mesh(foreGeo, cloth);
  const foreR = new THREE.Mesh(foreGeo, cloth);
  body.add(armL, armR, foreL, foreR);

  const thighG = makeCyl(0.07, 1, 7);
  const shinG = makeCyl(0.05, 1, 7);
  geos.push(thighG, shinG);
  const thighL = new THREE.Mesh(thighG, cloth);
  const thighR = new THREE.Mesh(thighG, cloth);
  const shinL = new THREE.Mesh(shinG, cloth);
  const shinR = new THREE.Mesh(shinG, cloth);
  body.add(thighL, thighR, shinL, shinR);
  const kneeG = new THREE.SphereGeometry(0.055, 8, 6);
  geos.push(kneeG);
  const kneeL = new THREE.Mesh(kneeG, cloth);
  const kneeR = new THREE.Mesh(kneeG, cloth);
  body.add(kneeL, kneeR);

  function makeFoot() {
    const g = new THREE.Group();
    const shoeG = new THREE.BoxGeometry(0.09, 0.048, 0.22);
    geos.push(shoeG);
    const s = new THREE.Mesh(shoeG, shoe);
    s.position.set(0, -0.02, -0.06);
    g.add(s);
    const toeG = new THREE.BoxGeometry(0.088, 0.032, 0.07);
    geos.push(toeG);
    const toe = new THREE.Mesh(toeG, shoe);
    toe.position.set(0, -0.012, -0.18);
    g.add(toe);
    body.add(g);
    return g;
  }
  const footL = makeFoot();
  const footR = makeFoot();

  function makePedal(x: number, z: number) {
    const pivot = new THREE.Group();
    pivot.position.set(x, 0.2, z);
    const padG = new THREE.BoxGeometry(0.055, 0.12, 0.016);
    geos.push(padG);
    const pad = new THREE.Mesh(padG, rubber);
    pad.position.y = 0.07;
    pivot.add(pad);
    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.08, 0.012), metalDark);
    geos.push(arm.geometry);
    arm.position.y = 0.02;
    pivot.add(arm);
    body.add(pivot);
    return pivot;
  }
  const pedClutch = makePedal(-0.5, -0.5);
  const pedBrake = makePedal(-0.39, -0.52);
  const pedGas = makePedal(-0.27, -0.5);

  const lever = new THREE.Group();
  lever.position.copy(KNOB0);
  const stickG = makeCyl(0.009, 0.16, 6);
  geos.push(stickG);
  const stick = new THREE.Mesh(stickG, metal);
  stick.position.y = 0.08;
  lever.add(stick);
  const knobG = new THREE.SphereGeometry(0.028, 10, 8);
  geos.push(knobG);
  const knob = new THREE.Mesh(knobG, leatherDark);
  knob.position.y = 0.175;
  lever.add(knob);
  body.add(lever);

  const needleG = new THREE.BoxGeometry(0.006, 0.055, 0.004);
  needleG.translate(0, 0.02, 0);
  geos.push(needleG);
  const needle = new THREE.Mesh(needleG, amber);
  needle.position.set(-0.34, 0.7, -0.5);
  body.add(needle);

  const camShake = { x: PITCH0, y: 0, z: 0 };

  function knobOffset(gear: number, out: THREE.Vector3) {
    const g = GATES[gear] ?? GATES[0];
    out.set(KNOB0.x + g[0], KNOB0.y + 0.16, KNOB0.z + g[1]);
    return out;
  }

  function rimBody(angle: number, lift: number, out: THREE.Vector3) {
    const x = Math.sin(angle) * (RIM + 0.012);
    const y = Math.cos(angle) * (RIM + 0.012);
    const theta = wheel.rotation.z;
    const c = Math.cos(theta);
    const s = Math.sin(theta);
    out.set(
      WHEEL_C.x + x * c - y * s,
      WHEEL_C.y + x * s + y * c + lift * 0.07,
      WHEEL_C.z + 0.04 + lift * 0.1,
    );
    return out;
  }

  const vA = new THREE.Vector3();
  const vB = new THREE.Vector3();
  const vC = new THREE.Vector3();
  const rightPos = new THREE.Vector3();
  const leftPos = new THREE.Vector3();
  const rightAnkle = new THREE.Vector3();
  const leftAnkle = new THREE.Vector3();
  const footBlend = new THREE.Vector3(-0.56, 0.34, -0.36);

  function orientOnWheel(h: HandRig, pos: THREE.Vector3) {
    _zAxis.set(pos.x - WHEEL_C.x, pos.y - WHEEL_C.y, 0);
    if (_zAxis.lengthSq() < 1e-6) _zAxis.set(0, 1, 0);
    _zAxis.normalize();
    _yAxis.set(-_zAxis.y, _zAxis.x, -0.22).normalize();
    _xAxis.set(-_zAxis.x * 0.35, -_zAxis.y * 0.35, 0.85).normalize();
    _dir.crossVectors(_yAxis, _xAxis).normalize();
    _yAxis.crossVectors(_xAxis, _dir).normalize();
    _m.makeBasis(_dir, _yAxis, _xAxis);
    h.root.quaternion.setFromRotationMatrix(_m);
    h.root.position.copy(pos);
  }

  function poseArm(
    shoulder: THREE.Vector3,
    wrist: THREE.Vector3,
    poleSide: number,
    upper: THREE.Object3D,
    fore: THREE.Object3D,
  ) {
    _pole.set(shoulder.x + poleSide * 0.28, shoulder.y - 0.22, shoulder.z + 0.12);
    solveElbow(shoulder, wrist, _pole, UPPER_LEN, FORE_LEN, _elbow);
    placeBone(upper, shoulder, _elbow, 1);
    placeBone(fore, _elbow, wrist, 1);
  }

  function poseLeg(
    hip: THREE.Vector3,
    ankle: THREE.Vector3,
    poleX: number,
    thigh: THREE.Object3D,
    shin: THREE.Object3D,
    knee: THREE.Object3D,
    foot: THREE.Group,
    press: number,
    yaw: number,
  ) {
    _pole.set(hip.x + poleX, hip.y + 0.55, hip.z - 0.05);
    solveElbow(hip, ankle, _pole, THIGH, SHIN, _elbow);
    placeBone(thigh, hip, _elbow, 1);
    placeBone(shin, _elbow, ankle, 1);
    knee.position.copy(_elbow);
    foot.position.copy(ankle);
    foot.rotation.set(-0.42 - press * 0.48, yaw, poleX > 0 ? -0.08 : 0.08);
  }

  const release = new THREE.Vector3();
  let haveRelease = false;
  let wasShifting = false;

  function update(sim: SimState, dt: number) {
    car.position.set(sim.x, 0, sim.z);
    car.rotation.y = sim.yaw;

    const tPitch = THREE.MathUtils.clamp(-sim.longG * 0.04, -0.055, 0.06);
    const tRoll = THREE.MathUtils.clamp(-sim.latG * 0.055, -0.07, 0.07);
    body.rotation.x = damp(body.rotation.x, tPitch, dt, 7);
    body.rotation.z = damp(body.rotation.z, tRoll, dt, 7);
    const buzzAmp = (sim.rpm / REDLINE) * (0.25 + sim.throttle * 0.75) * 0.0035;
    const buzz = Math.sin(sim.time * Math.max(8, sim.rpm * 0.012));
    body.position.y = buzz * buzzAmp + Math.sin(sim.time * 46) * sim.edge * 0.007;

    wheel.rotation.z = sim.wheel;
    wheel.rotation.x = buzz * buzzAmp * 2.2;
    vA.copy(WHEEL_C);
    vB.set(WHEEL_C.x, WHEEL_C.y - 0.05, WHEEL_C.z - 0.22);
    placeBone(column, vB, vA, 1);

    const theta = sim.wheel;
    const shifting = !!sim.shift;
    const recenter = Math.abs(sim.steer) < 0.08 && Math.abs(sim.wheelVel) < 0.4;

    if (!shifting) {
      if (wasShifting) {
        right.angle = right.home + theta;
        right.cross = null;
        right.curl = 0.35;
        wasShifting = false;
      }
      haveRelease = false;
      updateGrip(left, theta, dt, recenter, true);
      updateGrip(right, theta, dt, recenter, left.cross == null);
    } else {
      wasShifting = true;
      left.cross = null;
      const v = wrapPi(left.angle - theta);
      const nv = v + wrapPi(-0.15 - v) * Math.min(1, dt * 6);
      left.angle = nv + theta;
      left.curl = damp(left.curl, 1, dt, 8);
      left.sliding = false;
    }

    const liftL = left.cross ? Math.sin(Math.min(1, left.cross.t / left.cross.dur) * Math.PI) : 0;
    rimBody(left.angle, liftL, leftPos);
    orientOnWheel(left, leftPos);
    applyCurl(left, left.curl);
    _wrist.set(0, -0.07, 0.01).applyQuaternion(left.root.quaternion).add(left.root.position);
    poseArm(SHOULDER_L, _wrist, -1, armL, foreL);

    if (!shifting) {
      const liftR = right.cross ? Math.sin(Math.min(1, right.cross.t / right.cross.dur) * Math.PI) : 0;
      rimBody(right.angle, liftR, rightPos);
    } else {
      const sh = sim.shift!;
      const u = Math.min(1, sh.u);
      if (!haveRelease) {
        rimBody(right.angle, 0, release);
        haveRelease = true;
      }
      knobOffset(sh.from, vA);
      knobOffset(sh.to, vB);
      rimBody(right.home + theta * 0.15, 0, vC);
      if (u < 0.22) {
        const s = smooth(u / 0.22);
        rightPos.copy(release).lerp(vA, s);
        rightPos.y += Math.sin(s * Math.PI) * 0.06;
        right.curl = damp(right.curl, 0.12 + s * 0.7, dt, 12);
      } else if (u < 0.58) {
        const s = smooth((u - 0.22) / 0.36);
        rightPos.copy(vA).lerp(vB, s);
        right.curl = damp(right.curl, 0.92, dt, 14);
      } else {
        const s = smooth((u - 0.58) / 0.42);
        rightPos.copy(vB).lerp(vC, s);
        rightPos.y += Math.sin(s * Math.PI) * 0.045;
        right.curl = damp(right.curl, s > 0.45 ? 1 : 0.18, dt, 10);
      }
      right.sliding = u < 0.22 || u > 0.58;
    }

    if (shifting) {
      _yAxis.set(0, -0.85, 0.15).normalize();
      _xAxis.set(0.15, 0.35, 0.85).normalize();
      _dir.crossVectors(_yAxis, _xAxis).normalize();
      _yAxis.crossVectors(_xAxis, _dir).normalize();
      _m.makeBasis(_dir, _yAxis, _xAxis);
      right.root.quaternion.setFromRotationMatrix(_m);
      right.root.position.copy(rightPos);
    } else {
      orientOnWheel(right, rightPos);
    }
    applyCurl(right, right.curl);
    _wrist.set(0, -0.07, 0.01).applyQuaternion(right.root.quaternion).add(right.root.position);
    poseArm(SHOULDER_R, _wrist, 1, armR, foreR);

    const engineShake = buzz * (sim.rpm / REDLINE) * 0.002;
    left.root.position.y += engineShake;
    if (!shifting) right.root.position.y += engineShake;

    const gasPress = sim.throttle;
    const brakePress = sim.brake;
    const clutchPress = shifting ? Math.sin(Math.min(1, sim.shift!.u) * Math.PI) : 0;
    pedGas.rotation.x = -0.15 - gasPress * 0.42;
    pedBrake.rotation.x = -0.15 - brakePress * 0.4;
    pedClutch.rotation.x = -0.15 - clutchPress * 0.4;

    rightAnkle.set(-0.27, 0.36 - gasPress * 0.03, -0.46 - gasPress * 0.02);
    poseLeg(HIP_R, rightAnkle, 0.16, thighR, shinR, kneeR, footR, gasPress, 0.04);

    if (brakePress > 0.05) {
      leftAnkle.set(-0.39, 0.36 - brakePress * 0.03, -0.48 - brakePress * 0.02);
    } else if (clutchPress > 0.05) {
      leftAnkle.set(-0.5, 0.36 - clutchPress * 0.03, -0.44);
    } else {
      leftAnkle.set(-0.56, 0.34, -0.36);
    }
    footBlend.lerp(leftAnkle, 1 - Math.exp(-dt * 10));
    poseLeg(
      HIP_L,
      footBlend,
      -0.18,
      thighL,
      shinL,
      kneeL,
      footL,
      Math.max(brakePress, clutchPress),
      brakePress > 0.05 ? 0.18 : -0.08,
    );

    // shifter visual follows the engaged gate, and the in-between during a shift
    let gx = 0;
    let gz = 0;
    if (sim.shift) {
      const sh = sim.shift;
      const a = GATES[sh.from] ?? GATES[0];
      const b = GATES[sh.to] ?? GATES[0];
      const u = Math.min(1, Math.max(0, (sh.u - 0.22) / 0.36));
      const s = u * u * (3 - 2 * u);
      gx = a[0] + (b[0] - a[0]) * s;
      gz = a[1] + (b[1] - a[1]) * s;
    } else {
      const g = GATES[sim.gear] ?? GATES[0];
      gx = g[0];
      gz = g[1];
    }
    lever.position.set(KNOB0.x + gx, KNOB0.y, KNOB0.z + gz);
    lever.rotation.z = -gx * 1.4;
    lever.rotation.x = gz * 1.2;

    const rpmShown = Math.max(sim.rpm, sim.flare);
    needle.rotation.z = 0.9 - (rpmShown / REDLINE) * 2.1;

    camShake.x = damp(camShake.x, PITCH0 + THREE.MathUtils.clamp(-sim.longG * 0.025, -0.04, 0.045), dt, 6);
    camShake.y = damp(camShake.y, THREE.MathUtils.clamp(sim.wheel / MAX_WHEEL, -1, 1) * 0.07, dt, 4);
    camShake.z = damp(camShake.z, THREE.MathUtils.clamp(-sim.latG * 0.04, -0.05, 0.05), dt, 5);
    camera.rotation.x = camShake.x + buzz * buzzAmp;
    camera.rotation.y = camShake.y;
    camera.rotation.z = camShake.z;
    camera.position.y = EYE.y + buzz * buzzAmp * 0.6;

    const aspect = canvas.clientWidth / Math.max(1, canvas.clientHeight);
    const wantFov = aspect < 1 ? 86 : 76;
    if (Math.abs(camera.fov - wantFov) > 0.5) {
      camera.fov = wantFov;
      camera.updateProjectionMatrix();
    }
  }

  function resize() {
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
  }

  function render() {
    renderer.render(scene, camera);
  }

  function dispose() {
    renderer.setAnimationLoop(null);
    renderer.dispose();
    const geosSeen = new Set<THREE.BufferGeometry>();
    const matsSeen = new Set<THREE.Material>();
    scene.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (mesh.geometry && !geosSeen.has(mesh.geometry)) {
        geosSeen.add(mesh.geometry);
        mesh.geometry.dispose();
      }
      const material = mesh.material as THREE.Material | THREE.Material[] | undefined;
      const list = Array.isArray(material) ? material : material ? [material] : [];
      for (const mm of list) {
        if (!matsSeen.has(mm)) {
          matsSeen.add(mm);
          mm.dispose();
        }
      }
    });
  }

  resize();
  return { update, resize, render, dispose, renderer };
}

function smooth(u: number) {
  const t = Math.max(0, Math.min(1, u));
  return t * t * (3 - 2 * t);
}

function buildShell(
  body: THREE.Group,
  geos: THREE.BufferGeometry[],
  m: {
    plastic: THREE.Material;
    leather: THREE.Material;
    metal: THREE.Material;
    metalDark: THREE.Material;
    paint: THREE.Material;
    glass: THREE.Material;
    rubber: THREE.Material;
    amber: THREE.Material;
    white: THREE.Material;
  },
) {
  const add = (geo: THREE.BufferGeometry, mat: THREE.Material, pos: THREE.Vector3, rot?: THREE.Euler) => {
    geos.push(geo);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(pos);
    if (rot) mesh.rotation.copy(rot);
    body.add(mesh);
    return mesh;
  };

  add(new THREE.BoxGeometry(0.5, 0.08, 0.5), m.leather, new THREE.Vector3(-0.34, 0.44, 0.38));
  const back = add(
    new THREE.BoxGeometry(0.5, 0.62, 0.08),
    m.leather,
    new THREE.Vector3(-0.34, 0.78, 0.62),
  );
  back.rotation.x = -0.32;
  add(new THREE.BoxGeometry(0.08, 0.18, 0.42), m.leather, new THREE.Vector3(-0.58, 0.52, 0.36));
  add(new THREE.BoxGeometry(0.08, 0.18, 0.42), m.leather, new THREE.Vector3(-0.1, 0.52, 0.36));

  add(new THREE.BoxGeometry(1.55, 0.14, 0.42), m.plastic, new THREE.Vector3(-0.05, 0.52, -0.48));
  add(new THREE.BoxGeometry(0.34, 0.16, 0.1), m.plastic, new THREE.Vector3(-0.34, 0.66, -0.52));
  add(new THREE.BoxGeometry(0.22, 0.1, 0.01), m.plastic, new THREE.Vector3(-0.34, 0.7, -0.47));

  // hood + cowl
  const hood = add(new THREE.BoxGeometry(1.5, 0.05, 1.35), m.paint, new THREE.Vector3(0, 0.5, -1.35));
  hood.rotation.x = -0.04;
  add(new THREE.BoxGeometry(1.52, 0.08, 0.12), m.paint, new THREE.Vector3(0, 0.56, -0.72));

  // A pillars
  const pillarGeo = new THREE.BoxGeometry(0.06, 0.55, 0.08);
  const lp = add(pillarGeo, m.plastic, new THREE.Vector3(-0.72, 0.98, -0.28));
  lp.rotation.z = 0.18;
  lp.rotation.x = -0.25;
  const rp = add(pillarGeo.clone(), m.plastic, new THREE.Vector3(0.55, 0.98, -0.32));
  rp.rotation.z = -0.12;
  rp.rotation.x = -0.25;
  geos.push(rp.geometry);

  // windshield
  const wind = add(new THREE.PlaneGeometry(1.35, 0.62), m.glass, new THREE.Vector3(-0.08, 0.98, -0.55));
  wind.rotation.x = -0.32;

  // header rail / roof lip so the cabin has a top edge
  add(new THREE.BoxGeometry(1.5, 0.06, 0.18), m.plastic, new THREE.Vector3(-0.05, 1.28, -0.15));

  // door card left
  add(new THREE.BoxGeometry(0.06, 0.45, 0.7), m.plastic, new THREE.Vector3(-0.78, 0.7, 0.05));
  add(new THREE.BoxGeometry(0.08, 0.05, 0.35), m.leather, new THREE.Vector3(-0.72, 0.58, 0.12));

  // center console
  add(new THREE.BoxGeometry(0.22, 0.12, 0.55), m.plastic, new THREE.Vector3(0.16, 0.46, 0.12));
  const boot = add(new THREE.CylinderGeometry(0.02, 0.055, 0.08, 8), m.leather, new THREE.Vector3(0.18, 0.54, 0.04));
  boot.geometry.translate(0, 0, 0);

  // mirror
  add(new THREE.BoxGeometry(0.22, 0.07, 0.03), m.plastic, new THREE.Vector3(-0.1, 1.16, -0.18));
  add(new THREE.BoxGeometry(0.18, 0.045, 0.01), m.metal, new THREE.Vector3(-0.1, 1.16, -0.195));

  // floor
  add(new THREE.BoxGeometry(1.3, 0.04, 1.1), m.rubber, new THREE.Vector3(-0.15, 0.16, -0.05));

  // cluster ticks
  add(new THREE.BoxGeometry(0.16, 0.003, 0.004), m.white, new THREE.Vector3(-0.34, 0.685, -0.46));
}

function buildWorld(
  scene: THREE.Scene,
  geos: THREE.BufferGeometry[],
  m: {
    grass: THREE.Material;
    asphalt: THREE.Material;
    concrete: THREE.Material;
    white: THREE.Material;
    coneMat: THREE.Material;
    paint: THREE.Material;
  },
) {
  const ground = new THREE.Mesh(new THREE.CircleGeometry(220, 24), m.grass);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = 0;
  geos.push(ground.geometry);
  scene.add(ground);

  const pts = TRACK;
  const n = pts.length;
  const half = ROAD_HALF;
  const pos: number[] = [];
  const col: number[] = [];
  const idx: number[] = [];
  const edgeL: number[] = [];
  const edgeR: number[] = [];
  for (let i = 0; i < n; i++) {
    const prev = pts[(i - 1 + n) % n]!;
    const next = pts[(i + 1) % n]!;
    let tx = next.x - prev.x;
    let tz = next.z - prev.z;
    const len = Math.hypot(tx, tz) || 1;
    tx /= len;
    tz /= len;
    const nx = -tz;
    const nz = tx;
    const p = pts[i]!;
    pos.push(p.x + nx * half, 0.025, p.z + nz * half);
    pos.push(p.x - nx * half, 0.025, p.z - nz * half);
    const shade = 0.34 + ((i * 17) % 7) * 0.012;
    col.push(shade, shade, shade + 0.01, shade, shade, shade + 0.01);
    edgeL.push(p.x + nx * (half - 0.12), 0.03, p.z + nz * (half - 0.12));
    edgeR.push(p.x - nx * (half - 0.12), 0.03, p.z - nz * (half - 0.12));
  }
  for (let i = 0; i < n; i++) {
    const i2 = (i + 1) % n;
    const a = i * 2;
    const b = a + 1;
    const c = i2 * 2;
    const d = c + 1;
    idx.push(a, b, c, b, d, c);
  }
  const roadGeo = new THREE.BufferGeometry();
  roadGeo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  roadGeo.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
  roadGeo.setIndex(idx);
  roadGeo.computeVertexNormals();
  geos.push(roadGeo);
  const road = new THREE.Mesh(roadGeo, m.asphalt);
  scene.add(road);

  const lineMat = m.white;
  const addStrip = (arr: number[], skip: boolean) => {
    const gpos: number[] = [];
    const gidx: number[] = [];
    const count = arr.length / 3;
    for (let i = 0; i < count; i++) {
      const i2 = (i + 1) % count;
      if (skip && i % 2 === 0) continue;
      const ax = arr[i * 3]!;
      const ay = arr[i * 3 + 1]!;
      const az = arr[i * 3 + 2]!;
      const bx = arr[i2 * 3]!;
      const bz = arr[i2 * 3 + 2]!;
      const dx = bx - ax;
      const dz = bz - az;
      const len = Math.hypot(dx, dz) || 1;
      const px = (-dz / len) * 0.045;
      const pz = (dx / len) * 0.045;
      const base = gpos.length / 3;
      gpos.push(ax + px, ay, az + pz, ax - px, ay, az - pz, bx + px, ay, bz + pz, bx - px, ay, bz - pz);
      gidx.push(base, base + 1, base + 2, base + 1, base + 3, base + 2);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(gpos, 3));
    g.setIndex(gidx);
    geos.push(g);
    scene.add(new THREE.Mesh(g, lineMat));
  };
  addStrip(edgeL, false);
  addStrip(edgeR, false);

  // dashed center
  const center: number[] = [];
  for (let i = 0; i < n; i++) {
    const p = pts[i]!;
    center.push(p.x, 0.032, p.z);
  }
  addStrip(center, true);

  // low barriers, sparse
  const barGeo = new THREE.BoxGeometry(0.18, 0.42, 1.15);
  geos.push(barGeo);
  const bars = new THREE.InstancedMesh(barGeo, m.concrete, 48);
  const dummy = new THREE.Object3D();
  let bi = 0;
  for (let i = 0; i < n && bi < 48; i += 4) {
    const p = pts[i]!;
    const nxt = pts[(i + 1) % n]!;
    const tx = nxt.x - p.x;
    const tz = nxt.z - p.z;
    const len = Math.hypot(tx, tz) || 1;
    const nx = -tz / len;
    const nz = tx / len;
    dummy.position.set(p.x + nx * (half + 0.45), 0.21, p.z + nz * (half + 0.45));
    dummy.lookAt(p.x + nx * (half + 0.45) + tx, 0.21, p.z + nz * (half + 0.45) + tz);
    dummy.updateMatrix();
    bars.setMatrixAt(bi++, dummy.matrix);
  }
  bars.count = bi;
  scene.add(bars);

  // infield block so the loop reads
  const block = new THREE.Mesh(new THREE.BoxGeometry(10, 2.2, 16), m.paint);
  block.position.set(0, 1.1, 0);
  geos.push(block.geometry);
  scene.add(block);

  const coneG = new THREE.ConeGeometry(0.16, 0.42, 7);
  geos.push(coneG);
  const cones = new THREE.InstancedMesh(coneG, m.coneMat, 6);
  const spots = [
    [-TRACK_RADIUS + 3.1, 8],
    [-TRACK_RADIUS + 3.1, 4],
    [-TRACK_RADIUS + 3.1, 0],
    [-TRACK_RADIUS - 3.1, 12],
    [-TRACK_RADIUS - 3.1, 2],
    [0, TRACK_STRAIGHT / 2 + TRACK_RADIUS - 2],
  ];
  spots.forEach((s, i) => {
    dummy.position.set(s[0]!, 0.21, s[1]!);
    dummy.rotation.set(0, 0, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    cones.setMatrixAt(i, dummy.matrix);
  });
  scene.add(cones);

  // sky dome
  const skyGeo = new THREE.SphereGeometry(200, 16, 10);
  const skyCol = skyGeo.attributes.position;
  const colors = new Float32Array(skyCol.count * 3);
  const zen = new THREE.Color(0x6d7c8c);
  const hor = new THREE.Color(0xe4d2b8);
  for (let i = 0; i < skyCol.count; i++) {
    const y = skyCol.getY(i);
    const t = THREE.MathUtils.clamp(y / 200, 0, 1);
    const c = hor.clone().lerp(zen, Math.pow(t, 0.65));
    colors[i * 3] = c.r;
    colors[i * 3 + 1] = c.g;
    colors[i * 3 + 2] = c.b;
  }
  skyGeo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
  geos.push(skyGeo);
  const skyMat = new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false });
  scene.add(new THREE.Mesh(skyGeo, skyMat));

  // sun disk
  const sunDisk = new THREE.Mesh(
    new THREE.SphereGeometry(6, 12, 8),
    new THREE.MeshBasicMaterial({ color: 0xffc98a, fog: false }),
  );
  sunDisk.position.set(-70, 18, 40);
  geos.push(sunDisk.geometry);
  scene.add(sunDisk);
}
