// Tiny synthesized sound effects (no audio files -> zero download cost)
let ctx: AudioContext | null = null;
let enabled = true;

export function initAudio() {
  try {
    if (!ctx) ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    ctx.resume();
  } catch { /* ignore */ }
}
export function setSound(on: boolean) {
  enabled = on;
}

function tone(freq: number, dur: number, type: OscillatorType, vol: number, slide = 0) {
  if (!ctx || !enabled) return;
  const t = ctx.currentTime;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq * slide), t + dur);
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(ctx.destination);
  o.start(t);
  o.stop(t + dur);
}

function noise(dur: number, vol: number, freq: number) {
  if (!ctx || !enabled) return;
  const t = ctx.currentTime;
  const len = Math.floor(ctx.sampleRate * dur);
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const s = ctx.createBufferSource();
  s.buffer = buf;
  const f = ctx.createBiquadFilter();
  f.type = "bandpass";
  f.frequency.value = freq;
  const g = ctx.createGain();
  g.gain.value = vol;
  s.connect(f).connect(g).connect(ctx.destination);
  s.start(t);
}

export const sfx = {
  swing: () => noise(0.14, 0.25, 1800),
  hit: () => { tone(140, 0.12, "square", 0.12, 0.5); noise(0.08, 0.3, 600); },
  hurt: () => tone(220, 0.25, "sawtooth", 0.1, 0.45),
  pickup: () => { tone(660, 0.08, "square", 0.06); setTimeout(() => tone(990, 0.1, "square", 0.06), 70); },
  zombieDie: () => tone(110, 0.5, "sawtooth", 0.1, 0.4),
  groan: () => tone(80 + Math.random() * 30, 0.6, "sawtooth", 0.035, 0.7),
  eat: () => { noise(0.06, 0.2, 900); setTimeout(() => noise(0.06, 0.2, 800), 110); },
};
