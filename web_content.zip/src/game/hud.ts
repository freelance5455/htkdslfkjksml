import type { HudSnap } from "./types";

export const initialHud: HudSnap = {
  phase: "menu",
  day: 1,
  money: 0,
  goal: 30,
  timeLeft: 90,
  customerName: "",
  recipeName: "",
  price: 0,
  order: [],
  patience: 1,
  plate: [],
  verb: "Use",
  detail: "",
  canAct: false,
  toast: "",
  toastTone: "info",
  cook: [],
  bestDay: 0,
  bestMoney: 0,
  muted: false,
  customerHere: false,
  hints: true,
  booted: false,
};

let snap: HudSnap = initialHud;
const listeners = new Set<() => void>();

export function getHud(): HudSnap {
  return snap;
}

export function subscribeHud(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function setHud(next: HudSnap): void {
  snap = next;
  for (const listener of listeners) listener();
}
