import { useEffect, useRef, useState, type ReactNode, type RefObject } from "react";
import { Crosshair, Pause, Play, RotateCcw, Shield, Trophy, Volume2, VolumeX } from "lucide-react";
import { BLOCKS, ISLAND_R } from "@/game/layout";
import { emptyPad, initialHud, type BlipKind, type GameApi, type HudSnapshot, type PadInput } from "@/game/types";

export function Fortpanzer() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mapRef = useRef<HTMLCanvasElement>(null);
  const padRef = useRef<PadInput>(emptyPad());
  const apiRef = useRef<GameApi | null>(null);
  const [hud, setHud] = useState<HudSnapshot>(initialHud);
  const [soundOn, setSoundOn] = useState(true);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let gone = false;
    let api: GameApi | null = null;
    void import("@/game/mountGame").then(({ mountGame }) => {
      if (gone || !canvasRef.current) return;
      api = mountGame(canvasRef.current, {
        pad: padRef.current,
        onHud: (next) => setHud({ ...next, blips: next.blips.slice() }),
      });
      apiRef.current = api;
      setSoundOn(api.soundOn());
    });
    return () => {
      gone = true;
      api?.dispose();
      apiRef.current = null;
    };
  }, []);

  useEffect(() => {
    const canvas = mapRef.current;
    if (!canvas || !hud.ready || hud.phase === "menu") return;
    drawMap(canvas, hud);
  }, [hud]);

  const now = Date.now();
  const hitHot = now - hud.hit < 140;
  const hurtHot = now - hud.hurt < 320;
  const low = hud.mode === "foot" && hud.hp > 0 && hud.hp / hud.hpMax < 0.3;
  const playing = hud.phase === "play";

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-ink text-foam select-none">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />

      <div
        className={`hurt-vignette pointer-events-none absolute inset-0 transition-opacity duration-150 ${hurtHot || low ? "opacity-80" : "opacity-0"}`}
      />

      {playing && <CrosshairMark hot={hitHot} />}

      {hud.ready && hud.phase !== "menu" && (
        <Hud hud={hud} mapRef={mapRef} soundOn={soundOn} onSound={() => toggleSound(apiRef, setSoundOn)} onPause={() => apiRef.current?.togglePause()} />
      )}

      {playing && <TouchLayer padRef={padRef} mode={hud.mode} near={hud.nearTank} tankAlive={hud.tankAlive} />}

      {hud.phase === "menu" && (
        <Menu ready={hud.ready} best={hud.best} onStart={() => apiRef.current?.start()} soundOn={soundOn} onSound={() => toggleSound(apiRef, setSoundOn)} />
      )}

      {hud.phase === "pause" && (
        <Overlay
          kicker="Pause"
          title="Kurz verschnaufen"
          body="Der Panzer wartet. Die Insel nicht lange."
          action="Weiter"
          icon={<Play className="h-5 w-5" />}
          onAction={() => apiRef.current?.togglePause()}
        />
      )}

      {hud.phase === "down" && (
        <Overlay
          kicker={`Welle ${hud.wave}`}
          title="Ausgeschaltet"
          body={`Punkte ${hud.score} · Bestwert ${hud.best}`}
          action="Nochmal"
          icon={<RotateCcw className="h-5 w-5" />}
          onAction={() => apiRef.current?.start()}
        />
      )}
    </main>
  );
}

function toggleSound(apiRef: RefObject<GameApi | null>, setSoundOn: (v: boolean) => void) {
  const on = apiRef.current?.toggleSound();
  if (typeof on === "boolean") setSoundOn(on);
}

function Menu({
  ready,
  best,
  onStart,
  soundOn,
  onSound,
}: {
  ready: boolean;
  best: number;
  onStart: () => void;
  soundOn: boolean;
  onSound: () => void;
}) {
  return (
    <div className="absolute inset-0 flex flex-col justify-between p-4 md:p-8">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold tracking-widest text-sun">INSEL-SHOOTER</p>
          <h1 className="font-display text-5xl leading-none text-foam drop-shadow-md md:text-7xl">FORTPANZER</h1>
        </div>
        <SoundButton on={soundOn} onClick={onSound} />
      </div>

      <div className="mx-auto w-full max-w-lg rounded-3xl bg-ink/85 p-5 shadow-xl md:p-6">
        <p className="text-base leading-relaxed text-foam">Zu Fuß feuern, in den Panzer steigen, Wellen überstehen.</p>
        <ul className="mt-4 grid gap-2 text-sm text-muted">
          <li className="flex items-center gap-2">
            <Crosshair className="h-4 w-4 text-sun" />
            WASD, Maus oder Stick. Rechtsklick ziehen zielt ohne Mausfang.
          </li>
          <li className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-sun" />
            Im Panzer: W Gas, S zurück, A links, D rechts. E aussteigen.
          </li>
          <li className="flex items-center gap-2">
            <Trophy className="h-4 w-4 text-sun" />
            Bestwert {best}
          </li>
        </ul>
        <button
          type="button"
          disabled={!ready}
          onClick={onStart}
          className="mt-5 flex h-14 w-full items-center justify-center rounded-2xl bg-sun text-lg font-bold text-ink disabled:opacity-60"
        >
          {ready ? "Start" : "Insel wird aufgebaut"}
        </button>
      </div>
    </div>
  );
}

function Hud({
  hud,
  mapRef,
  soundOn,
  onSound,
  onPause,
}: {
  hud: HudSnapshot;
  mapRef: RefObject<HTMLCanvasElement | null>;
  soundOn: boolean;
  onSound: () => void;
  onPause: () => void;
}) {
  const hpPct = Math.max(0, Math.min(100, (hud.hp / hud.hpMax) * 100));
  const tankPct = Math.max(0, Math.min(100, (hud.tankHp / hud.tankMax) * 100));
  return (
    <div className="pointer-events-none absolute inset-0 p-3 md:p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="w-44 md:w-56">
          <Bar label="Leben" value={hpPct} tone="coral" text={`${Math.ceil(hud.hp)}`} />
          <div className="mt-2">
            <Bar
              label={hud.tankAlive ? "Panzer" : "Panzer zerstört"}
              value={hud.tankAlive ? tankPct : 0}
              tone="sun"
              text={hud.tankAlive ? `${Math.ceil(hud.tankHp)}` : "—"}
            />
          </div>
          {hud.shield > 0 && <p className="mt-1 text-xs font-semibold text-foam">Schutz aktiv</p>}
        </div>
        <div className="flex items-start gap-2">
          <canvas ref={mapRef} width={180} height={180} className="h-24 w-24 rounded-full border-2 border-foam/40 bg-ink/70 md:h-28 md:w-28" />
          <div className="pointer-events-auto flex flex-col gap-2">
            <IconButton label="Pause" onClick={onPause}>
              <Pause className="h-5 w-5" />
            </IconButton>
            <SoundButton on={soundOn} onClick={onSound} />
          </div>
        </div>
      </div>

      <div className="absolute left-1/2 top-3 -translate-x-1/2 text-center">
        <p className="text-xs font-semibold tracking-widest text-muted">WELLE {hud.wave}</p>
        <p className="font-display text-2xl leading-none text-foam">{hud.score}</p>
        {hud.banner && <p className="mt-1 rounded-full bg-ink/80 px-3 py-1 text-sm font-bold text-sun">{hud.banner}</p>}
      </div>

      <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 flex-col items-center gap-1">
        {hud.mode === "tank" ? (
          <>
            <p className="rounded-full bg-ink/75 px-3 py-1 text-xs font-semibold text-foam">Im Panzer · E aussteigen</p>
            <div className="h-2 w-28 overflow-hidden rounded-full bg-ink/80">
              <div className="h-full bg-sun" style={{ width: `${Math.round(hud.cannon * 100)}%` }} />
            </div>
          </>
        ) : (
          <>
            <p className="rounded-full bg-ink/75 px-3 py-1 text-xs font-semibold text-foam">
              {hud.reloading ? "Lädt…" : `Munition ${hud.mag}`}
              {hud.nearTank ? " · E einsteigen" : ""}
            </p>
          </>
        )}
        <p className="hidden text-xs text-foam/80 md:block">Linksklick Feuer · Rechtsklick ziehen zielen · Shift Sprint</p>
      </div>
    </div>
  );
}

function Bar({ label, value, text, tone }: { label: string; value: number; text: string; tone: "sun" | "coral" }) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-xs font-semibold">
        <span className="text-muted">{label}</span>
        <span className="text-foam">{text}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-ink/80">
        <div className={tone === "sun" ? "h-full bg-sun" : "h-full bg-coral"} style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

function CrosshairMark({ hot }: { hot: boolean }) {
  const color = hot ? "bg-coral" : "bg-foam";
  return (
    <div className="pointer-events-none absolute left-1/2 top-1/2 h-8 w-8 -translate-x-1/2 -translate-y-1/2">
      <span className={`absolute left-1/2 top-0 h-2 w-0.5 -translate-x-1/2 ${color}`} />
      <span className={`absolute bottom-0 left-1/2 h-2 w-0.5 -translate-x-1/2 ${color}`} />
      <span className={`absolute left-0 top-1/2 h-0.5 w-2 -translate-y-1/2 ${color}`} />
      <span className={`absolute right-0 top-1/2 h-0.5 w-2 -translate-y-1/2 ${color}`} />
    </div>
  );
}

function Overlay({
  kicker,
  title,
  body,
  action,
  icon,
  onAction,
}: {
  kicker: string;
  title: string;
  body: string;
  action: string;
  icon: ReactNode;
  onAction: () => void;
}) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-ink/55 p-4">
      <div className="w-full max-w-sm rounded-3xl bg-ink p-6 text-center shadow-xl">
        <p className="text-xs font-semibold tracking-widest text-sun">{kicker}</p>
        <h2 className="mt-1 font-display text-4xl text-foam">{title}</h2>
        <p className="mt-2 text-sm text-muted">{body}</p>
        <button
          type="button"
          onClick={onAction}
          className="mt-5 inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-sun px-6 font-bold text-ink"
        >
          {icon}
          {action}
        </button>
      </div>
    </div>
  );
}

function SoundButton({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <IconButton label={on ? "Ton aus" : "Ton an"} onClick={onClick}>
      {on ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
    </IconButton>
  );
}

function IconButton({ label, onClick, children }: { label: string; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="flex h-11 w-11 items-center justify-center rounded-2xl bg-ink/80 text-foam"
    >
      {children}
    </button>
  );
}

function TouchLayer({
  padRef,
  mode,
  near,
  tankAlive,
}: {
  padRef: RefObject<PadInput>;
  mode: HudSnapshot["mode"];
  near: boolean;
  tankAlive: boolean;
}) {
  const look = useRef<{ id: number; x: number; y: number } | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const baseRef = useRef<HTMLDivElement>(null);
  const stickId = useRef<number | null>(null);

  function setStick(clientX: number, clientY: number) {
    const base = baseRef.current;
    if (!base) return;
    const rect = base.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const max = rect.width / 2;
    const mag = Math.hypot(dx, dy) || 1;
    const clamped = Math.min(mag, max);
    dx = (dx / mag) * clamped;
    dy = (dy / mag) * clamped;
    setKnob({ x: dx, y: dy });
    const nx = dx / max;
    const ny = -dy / max;
    const m = Math.hypot(nx, ny);
    const dz = 0.16;
    const pad = padRef.current;
    if (!pad) return;
    if (m < dz) {
      pad.moveX = 0;
      pad.moveY = 0;
      pad.sprint = false;
    } else {
      const s = (m - dz) / (1 - dz) / m;
      pad.moveX = nx * s;
      pad.moveY = ny * s;
      pad.sprint = m > 0.92;
    }
  }

  function clearStick() {
    stickId.current = null;
    setKnob({ x: 0, y: 0 });
    const pad = padRef.current;
    if (!pad) return;
    pad.moveX = 0;
    pad.moveY = 0;
    pad.sprint = false;
  }

  return (
    <div className="touch-controls pointer-events-none absolute inset-0 md:hidden">
      <div
        className="pointer-events-auto absolute top-0 right-0 bottom-28 left-1/2"
        onPointerDown={(e) => {
          look.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
          e.currentTarget.setPointerCapture(e.pointerId);
        }}
        onPointerMove={(e) => {
          if (!look.current || look.current.id !== e.pointerId || !padRef.current) return;
          padRef.current.lookX += e.clientX - look.current.x;
          padRef.current.lookY += e.clientY - look.current.y;
          look.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
        }}
        onPointerUp={() => {
          look.current = null;
        }}
        onPointerCancel={() => {
          look.current = null;
        }}
      />

      <div
        ref={baseRef}
        className="pointer-events-auto absolute bottom-6 left-4 z-20 h-32 w-32 rounded-full border-2 border-foam/50 bg-ink/45"
        onPointerDown={(e) => {
          stickId.current = e.pointerId;
          e.currentTarget.setPointerCapture(e.pointerId);
          setStick(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (stickId.current !== e.pointerId) return;
          setStick(e.clientX, e.clientY);
        }}
        onPointerUp={clearStick}
        onPointerCancel={clearStick}
      >
        <div
          className="absolute left-1/2 top-1/2 h-14 w-14 rounded-full bg-foam/90"
          style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
        />
      </div>

      <div className="pointer-events-auto absolute right-4 bottom-6 z-20 flex items-end gap-3">
        <div className="flex flex-col gap-3">
          <RoundButton
            label={mode === "tank" ? "Aussteigen" : near || tankAlive ? "Panzer" : "Kein Panzer"}
            onPointerDown={() => {
              if (padRef.current) padRef.current.queueEnter = true;
            }}
          >
            <Shield className="h-6 w-6" />
          </RoundButton>
          {mode === "foot" && (
            <RoundButton
              label="Nachladen"
              onPointerDown={() => {
                if (padRef.current) padRef.current.queueReload = true;
              }}
            >
              <RotateCcw className="h-6 w-6" />
            </RoundButton>
          )}
        </div>
        <button
          type="button"
          aria-label="Feuer"
          className="flex h-20 w-20 items-center justify-center rounded-full bg-coral text-sm font-bold text-foam"
          onPointerDown={(e) => {
            e.currentTarget.setPointerCapture(e.pointerId);
            if (padRef.current) padRef.current.fire = true;
          }}
          onPointerUp={() => {
            if (padRef.current) padRef.current.fire = false;
          }}
          onPointerCancel={() => {
            if (padRef.current) padRef.current.fire = false;
          }}
        >
          Feuer
        </button>
      </div>
    </div>
  );
}

function RoundButton({
  label,
  onPointerDown,
  children,
}: {
  label: string;
  onPointerDown: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onPointerDown={(e) => {
        e.stopPropagation();
        onPointerDown();
      }}
      className="flex h-14 w-14 items-center justify-center rounded-full bg-ink/80 text-foam"
    >
      {children}
    </button>
  );
}

const BLIP: Record<BlipKind, string> = {
  inf: "#ff5a36",
  badtank: "#c084fc",
  tank: "#3d7eff",
};

function drawMap(canvas: HTMLCanvasElement, hud: HudSnapshot) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#143024";
  ctx.beginPath();
  ctx.arc(w / 2, h / 2, w / 2 - 2, 0, Math.PI * 2);
  ctx.fill();
  const scale = (w / 2 - 10) / ISLAND_R;
  const toX = (x: number) => w / 2 + x * scale;
  const toY = (z: number) => h / 2 + z * scale;
  ctx.fillStyle = "rgba(255,255,255,0.22)";
  for (const b of BLOCKS) {
    if (b.crate) continue;
    ctx.fillRect(toX(b.x - b.hw), toY(b.z - b.hd), b.hw * 2 * scale, b.hd * 2 * scale);
  }
  for (const blip of hud.blips) {
    ctx.fillStyle = BLIP[blip.k];
    ctx.beginPath();
    ctx.arc(toX(blip.x), toY(blip.z), blip.k === "inf" ? 3.5 : 5, 0, Math.PI * 2);
    ctx.fill();
  }
  const px = toX(hud.x);
  const py = toY(hud.z);
  ctx.fillStyle = "#ffb703";
  ctx.beginPath();
  ctx.arc(px, py, 5, 0, Math.PI * 2);
  ctx.fill();
  const fx = -Math.sin(hud.yaw);
  const fz = -Math.cos(hud.yaw);
  ctx.strokeStyle = "#f4f7fb";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(px, py);
  ctx.lineTo(px + fx * 12, py + fz * 12);
  ctx.stroke();
}
