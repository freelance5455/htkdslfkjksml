// @ts-nocheck
export function boot(root) {
  if (root) { root.setAttribute("dir", "rtl"); root.setAttribute("lang", "fa"); }
  if (!document.getElementById("sr-game-css")) {
    const style = document.createElement("style");
    style.id = "sr-game-css";
    style.textContent = "*{ box-sizing:border-box; -webkit-tap-highlight-color:transparent; }\n#sr-root{ position:fixed; inset:0; width:100%; height:100%; overflow:hidden; background:#020511; font-family:Tahoma,Arial,sans-serif; touch-action:none; color:#fff; }\n#sr-root canvas{ display:block; width:100%; height:100%; }\n#ui{ position:absolute; top:0; right:0; bottom:0; left:0; color:white; pointer-events:none; z-index:10; }\n.hud{ display:flex; justify-content:center; gap:6px; flex-wrap:wrap; padding:54px 8px 8px 8px; }\n.badge{ background:#07132ddd; border:1px solid #40598f; border-radius:12px; padding:7px 10px; font-size:12px; font-weight:bold; transition:transform .15s; }\n.badge.pulse{ transform:scale(1.18); }\n.screen{ position:absolute; top:0; right:0; bottom:0; left:0; display:flex; align-items:center; justify-content:center; background:#020511e8; pointer-events:auto; z-index:20; }\n.panel{ width:94vw; max-width:520px; max-height:min(94vh, calc(var(--vvh, 100vh) - 12px)); overflow:auto; padding:20px; border-radius:24px; background:#09142ff7; border:1px solid #40598f; box-shadow:0 18px 70px #000b; text-align:center; }\nh1{ font-size:34px; margin:0 0 8px; text-shadow:0 0 18px #4d7cffaa; }\nh2{ margin:0 0 14px; }\nh3{ margin:18px 0 8px; }\n.sub{ color:#b9c7eb; line-height:1.8; margin-bottom:13px; font-size:13px; }\nbutton{ border:0; border-radius:13px; padding:11px 15px; margin:4px; background:#315ee8; color:white; font:bold 15px Tahoma; cursor:pointer; transition:transform .1s; }\nbutton:active{ transform:scale(.96); }\nbutton.secondary{ background:#202d50; }\nbutton.reward{ background:#07966a; }\nbutton.ad-btn{ background:linear-gradient(180deg, #ff9900, #cc6600); box-shadow:0 4px 15px rgba(255, 153, 0, 0.3); }\nbutton.premium{ background:linear-gradient(180deg,#c06cff,#7a1fd8); box-shadow:0 4px 15px rgba(192,108,255,.35); }\nbutton:disabled{ opacity:.45; }\n.hidden{ display:none!important; }\n.wallet{ display:flex; justify-content:center; gap:8px; flex-wrap:wrap; margin:8px 0; }\n.wallet span{ background:#111f43; padding:7px 11px; border-radius:12px; }\n.cards{ display:grid; grid-template-columns:1fr 1fr; gap:8px; margin:10px 0; }\n.card{ background:#101d3d; border-radius:14px; padding:10px; margin:7px 0; }\n.row{ display:flex; justify-content:space-between; align-items:center; background:#101d3d; border-radius:13px; padding:9px; margin:7px 0; text-align:right; }\n.small{ color:#aebce2; font-size:12px; }\n.bar{ height:9px; background:#1b2a50; border-radius:10px; overflow:hidden; margin:7px 0; }\n.fill{ height:100%; width:0%; background:#4e80ff; transition:width .25s; }\n#hint{ position:absolute; bottom:16px; left:50%; transform:translateX(-50%); background:#07132ddd; padding:8px 12px; border-radius:12px; font-size:12px; white-space:nowrap; }\n#soundButton{ position:absolute; right:10px; top:10px; pointer-events:auto; padding:8px 11px; margin:0; background:#07122ddd; z-index:25; border-radius:10px; }\n#musicButton{ position:absolute; right:55px; top:10px; pointer-events:auto; padding:8px 11px; margin:0; background:#07122ddd; z-index:25; border-radius:10px; }\n#toast{ position:absolute; top:65px; left:50%; transform:translateX(-50%); background:#0c1837f5; border:1px solid #526da8; padding:10px 15px; border-radius:13px; opacity:0; transition:.2s; pointer-events:none; white-space:normal; width:max-content; max-width:92%; text-align:center; line-height:1.7; z-index:50; }\n.iconCoin{ display:inline-block; width:14px; height:14px; border-radius:50%; background:#ffd447; border:2px solid #fff0a0; vertical-align:-2px; box-shadow:0 0 5px #ffd447; }\n.iconGem{ display:inline-block; width:13px; height:13px; background:#64e7ff; transform:rotate(45deg); vertical-align:-1px; border:1px solid #d7fbff; box-shadow:0 0 6px #64e7ff; }\n.wallet .iconCoin{ background:#ffd447; padding:0; border-radius:50%; }\n.wallet .iconGem{ background:#64e7ff; padding:0; border-radius:0; }\n.grid3{ display:grid; grid-template-columns:repeat(3,1fr); gap:6px; }\n.stat{ background:#101d3d; border-radius:12px; padding:9px; font-size:12px; }\n.skin{ border:1px solid #334c80; border-radius:13px; padding:9px; display:flex; flex-direction:column; align-items:center; text-align:center; gap:2px; }\n.skin > button{ margin-top:4px; width:100%; }\n.skin.active{ border-color:#65eaff; box-shadow:0 0 10px #65eaff44; }\n.skin.locked{ opacity:.55; }\n#adModal{ position:absolute; top:0; right:0; bottom:0; left:0; background:#000000ed; z-index:100; display:flex; flex-direction:column; align-items:center; justify-content:center; color:#fff; text-align:center; }\n.wheelGrid{ display:grid; grid-template-columns:repeat(3,1fr); gap:8px; margin:12px 0; }\n.wheelItem{ background:#101d3d; border:2px solid #334c80; border-radius:14px; padding:14px 6px; font-size:22px; transition:.15s; }\n.wheelItem.spin{ border-color:#ffd447; box-shadow:0 0 14px #ffd44799; transform:scale(1.08); }\n.wheelItem span{ display:block; font-size:11px; color:#b9c7eb; margin-top:4px; }\n.lbRow{ background:#101d3d; border-radius:12px; padding:8px 12px; margin:6px 0; font-size:13px; }\n.lbMain{ display:flex; justify-content:space-between; align-items:center; gap:6px; }\n.lbSub{ text-align:right; color:#9fb4e8; margin-top:3px; font-size:11px; }\n.lbRow b{ color:#ffd447; }\n.modeSelect{ display:flex; justify-content:center; gap:6px; margin-bottom:8px; flex-wrap:wrap; }\n.modeBtn{ background:#162447; border:1px solid #3f5896; border-radius:10px; padding:8px 12px; font-size:12px; cursor:pointer; color:#b9c7eb; }\n.modeBtn.active{ background:#315ee8; color:#fff; border-color:#65eaff; }\n#flashOverlay{ position:fixed; top:0; right:0; bottom:0; left:0; background:#fff; opacity:0; pointer-events:none; z-index:99; transition:opacity 0.1s ease-out; }\n#eventAlert{ position:absolute; top:150px; left:50%; transform:translateX(-50%); background:rgba(255, 30, 0, 0.85); color:#fff; padding:8px 16px; border-radius:20px; font-weight:bold; font-size:14px; border:1px solid #ff8800; text-shadow:0 0 8px #000; z-index:15; }\n#bhAlert{ position:absolute; top:190px; left:50%; transform:translateX(-50%); background:rgba(70, 0, 110, 0.9); color:#fff; padding:8px 16px; border-radius:20px; font-weight:bold; font-size:14px; border:1px solid #a855f7; text-shadow:0 0 8px #000; z-index:15; }\n#rgAlert{ position:absolute; top:230px; left:50%; transform:translateX(-50%); background:rgba(150, 110, 0, 0.9); color:#fff; padding:8px 16px; border-radius:20px; font-weight:bold; font-size:14px; border:1px solid #ffd447; text-shadow:0 0 8px #000; z-index:15; }\n.premiumSkin{ border-color:#ffd447 !important; box-shadow:0 0 12px #ffd44766; }\n.row > div:first-child{ flex:1 1 auto; min-width:0; }\n.fxPrev{ position:relative; display:block; width:100%; min-width:150px; height:58px; border-radius:10px; margin:6px 0; overflow:hidden; border:1px solid rgba(255,255,255,.28); background:linear-gradient(180deg,#050a1e,#0b1638); }\n.fxPrev i,.fxPrev b{ position:absolute; display:block; }\n.fxPrev .hw{ inset:0; }\n.fxPrev .st{ width:2px; height:2px; border-radius:50%; background:#fff; opacity:.8; }\n.fxPrev .ship1{ width:12px; height:12px; border-radius:50%; background:#dfeaff; left:20%; top:23px; box-shadow:0 0 8px #99ccff; }\n.fxPrev .vig{ inset:0; background:radial-gradient(ellipse at center,rgba(0,0,0,0) 45%,rgba(0,0,0,.55) 100%); }\n.fxPrev .tint{ inset:0; }\n.fxPrev .td{ border-radius:50%; top:24px; left:-10%; animation:fxRun 2.2s linear infinite backwards; }\n@keyframes fxRun{ 0%{ left:-10%; } 100%{ left:105%; } }\n.hueAnim{ animation:fxHue 3s linear infinite; }\n@keyframes fxHue{ from{ filter:hue-rotate(0deg); } to{ filter:hue-rotate(360deg); } }\n.fxPrev .jship{ width:12px; height:12px; border-radius:50%; background:#dfeaff; left:calc(50% - 6px); animation:fxJump 1.7s ease-in-out infinite; box-shadow:0 0 8px #99ccff; }\n@keyframes fxJump{ 0%,100%{ top:40px; } 45%{ top:6px; } }\n.fxPrev .jring{ width:26px; height:8px; left:calc(50% - 13px); top:50px; border:2px solid; border-radius:50%; animation:fxRing 1.7s ease-out infinite; opacity:0; }\n@keyframes fxRing{ 0%{ transform:scale(.3); opacity:.9; } 100%{ transform:scale(2.6); opacity:0; } }\n.fxPrev .jp{ width:4px; height:4px; border-radius:50%; left:50%; top:46px; animation:fxBurst 1.7s ease-out infinite; opacity:0; }\n@keyframes fxBurst{ 0%{ transform:translate(0,0); opacity:1; } 60%{ opacity:1; } 100%{ transform:translate(var(--dx),var(--dy)); opacity:0; } }\n.fxPrev .acenter{ width:12px; height:12px; border-radius:50%; background:#dfeaff; left:calc(50% - 6px); top:23px; box-shadow:0 0 8px #99ccff; z-index:2; }\n.fxPrev .aring{ width:30px; height:30px; border-radius:50%; left:calc(50% - 15px); top:14px; border:2px solid rgba(124,246,255,.75); animation:fxPulse 1.6s ease-in-out infinite; }\n@keyframes fxPulse{ 0%,100%{ transform:scale(.8); opacity:.9; } 50%{ transform:scale(1.6); opacity:.2; } }\n.fxPrev .aspin{ width:60px; height:60px; left:calc(50% - 30px); top:-1px; animation:fxSpin 3s linear infinite; }\n@keyframes fxSpin{ to{ transform:rotate(360deg); } }\n.fxPrev .adot{ width:7px; height:7px; border-radius:50%; box-shadow:0 0 8px currentColor; }\n.fxPrev .arb{ width:34px; height:34px; left:calc(50% - 17px); top:12px; border-radius:50%; background:conic-gradient(#ff4d6d,#ffd447,#4dff88,#4dd2ff,#b98bff,#ff4d6d); -webkit-mask:radial-gradient(circle,transparent 11px,#000 12px); mask:radial-gradient(circle,transparent 11px,#000 12px); animation:fxSpin 3s linear infinite; }\n.fxPrev .crown{ left:calc(50% - 9px); top:2px; font-size:15px; z-index:3; }\n.fxPrev .streak{ height:2px; width:26px; left:50%; top:50%; transform-origin:0 50%; background:linear-gradient(90deg,#fff,transparent); animation:fxWarp 1.2s ease-in infinite; opacity:0; }\n@keyframes fxWarp{ 0%{ transform:rotate(var(--a)) translateX(4px) scaleX(.2); opacity:0; } 30%{ opacity:1; } 100%{ transform:rotate(var(--a)) translateX(60px) scaleX(1.6); opacity:0; } }\n.fxPrev .flash{ inset:0; background:#fff; animation:fxFlash 1.6s ease-out infinite; opacity:0; }\n@keyframes fxFlash{ 0%{ opacity:.9; } 35%{ opacity:0; } 100%{ opacity:0; } }\n.fxPrev .pring{ width:14px; height:14px; left:calc(50% - 7px); top:22px; border-radius:50%; border:2px solid; animation:fxPortal 1.8s ease-out infinite; opacity:0; }\n@keyframes fxPortal{ 0%{ transform:scale(.3); opacity:1; } 100%{ transform:scale(4); opacity:0; } }\n.skinPrev{ display:block; margin:2px auto 4px; width:64px; height:64px; }\n.recInput{ width:92%; padding:10px; border-radius:10px; border:1px solid #40598f; background:#0c1837; color:#fff; font:15px Tahoma; text-align:center; margin:6px 0; box-sizing:border-box; -webkit-user-select:text; user-select:text; touch-action:auto; }\n.recArea{ width:100%; height:120px; padding:8px; border-radius:10px; border:1px solid #40598f; background:#0c1837; color:#cfe1ff; font:11px monospace; direction:ltr; text-align:left; box-sizing:border-box; margin:6px 0; word-break:break-all; -webkit-user-select:text; user-select:text; touch-action:auto; }\n.recRow{ display:flex; gap:8px; align-items:center; }\n.recRow .recArea{ flex:1 1 auto; min-width:0; width:auto; }\n.recRow button{ flex:0 0 auto; }\n.groundPrev,.satPrev{ display:block; width:100%; min-width:150px; height:84px; border-radius:10px; margin:6px 0; border:1px solid rgba(255,255,255,0.35); background:#050a1e; box-shadow:0 2px 10px rgba(0,0,0,.35); }\nbutton.iap-btn{ background:linear-gradient(180deg, #2ecc71, #1a7a45); box-shadow:0 4px 15px rgba(46,204,113,.3); }\nbutton.iap-btn.premium{ background:linear-gradient(180deg,#ffd447,#b8860b); color:#1a1400; box-shadow:0 4px 15px rgba(255,212,71,.4); }\n.dailyGrid{ display:grid; grid-template-columns:repeat(7, 1fr); gap:4px; margin:10px 0; }\n.dailyDay{ background:#101d3d; border:1px solid #334c80; border-radius:8px; padding:6px 2px; font-size:10px; text-align:center; }\n.dailyDay.active{ border-color:#ffd447; background:#1d2f5e; box-shadow:0 0 8px #ffd44755; }\n.dailyDay.done{ opacity:0.5; background:#0a1228; }\n#pauseBtn{ position:absolute; left:10px; top:10px; pointer-events:auto; padding:8px 11px; margin:0; background:#07122ddd; z-index:25; border-radius:10px; }\n#settingsFab{ position:absolute; left:55px; top:10px; pointer-events:auto; padding:8px 11px; margin:0; background:#07122ddd; z-index:25; border-radius:10px; }\n.volRow{ display:flex; align-items:center; gap:10px; margin:10px 0; text-align:right; }\n.volRow input[type=range]{ flex:1; }\n.gfxRow{ display:flex; gap:6px; justify-content:center; flex-wrap:wrap; margin:8px 0; }\n.gfxBtn{ background:#162447; border:1px solid #3f5896; border-radius:10px; padding:8px 12px; font-size:12px; color:#b9c7eb; }\n.gfxBtn.active{ background:#315ee8; color:#fff; border-color:#65eaff; }\n#iapBox .panel{ max-width:420px; }\n.switch{ transform:scale(1.2); }\n#sfAlert{ position:absolute; top:270px; left:50%; transform:translateX(-50%); background:rgba(180,80,0,0.9); color:#fff; padding:8px 16px; border-radius:20px; font-weight:bold; font-size:14px; border:1px solid #ffd447; z-index:15; }\n#deathVeil{ position:absolute; inset:0; background:radial-gradient(circle at 50% 60%,rgba(255,80,40,.35),rgba(2,5,17,.72)); opacity:0; pointer-events:none; z-index:18; transition:opacity .25s; }\n#deathVeil.show{ opacity:1; }\n#iceAlert{ position:absolute; top:310px; left:50%; transform:translateX(-50%); background:rgba(20,80,140,0.92); color:#fff; padding:8px 16px; border-radius:20px; font-weight:bold; font-size:14px; border:1px solid #7ad7ff; z-index:15; }\n#tutOverlay .panel{ max-width:440px; }\n.tutCard{ background:#101d3d; border-radius:14px; padding:10px; margin:8px 0; text-align:right; }\n#nickInput{ width:70%; padding:8px 10px; border-radius:10px; border:1px solid #40598f; background:#0c1837; color:#fff; font:15px Tahoma; text-align:center; }\n.ageBadge{ display:inline-block; background:#1d3a1d; border:1px solid #9dffb0; color:#9dffb0; border-radius:8px; padding:2px 8px; font-size:11px; }\n#challengeBox{ background:#101d3d; border:1px solid #65eaff55; border-radius:14px; padding:8px; margin:8px 0; }\n#rateBox{ background:#1d1530; border:1px solid #c06cff; border-radius:14px; padding:10px; margin:8px 0; }\n\n.closeX{ position:sticky; top:0; float:left; width:38px; height:38px; border-radius:50%; padding:0; margin:-8px 0 0 -8px; background:#26335c; border:1px solid #4a5f99; font-size:17px; line-height:36px; z-index:6; }\n#ghostBtn{ position:absolute; right:14px; bottom:22px; width:62px; height:62px; border-radius:50%; padding:0; margin:0; font-size:28px; pointer-events:auto; z-index:24; background:radial-gradient(circle at 35% 30%, #b98cff, #4c1b9a); border:2px solid #d7b3ff; box-shadow:0 0 16px #a56bff99; display:flex; align-items:center; justify-content:center; }\n#ghostBtn.cd{ filter:grayscale(.85) brightness(.6); box-shadow:none; }\n#ghostBtn.on{ border-color:#fff; box-shadow:0 0 22px #fff, 0 0 40px #b98cff; }\n#ghostBtn #ghostCd{ position:absolute; font:bold 22px Tahoma; color:#fff; text-shadow:0 0 6px #000, 0 0 3px #000; }\n.upg{ background:#101d3d; border:1px solid #2d4580; border-radius:14px; padding:10px; margin:8px 0; text-align:right; }\n.upgHead{ display:flex; justify-content:space-between; align-items:center; gap:6px; }\n.pips{ display:flex; gap:3px; margin:8px 0; direction:ltr; }\n.pip{ flex:1; min-width:0; padding:7px 0; margin:0; border-radius:8px; font-size:11px; background:#1b2a50; color:#8ea0cf; border:1px solid #33497f; }\n.pip.own{ background:#25407e; color:#fff; }\n.pip.act{ background:#2f8cff; color:#fff; box-shadow:0 0 8px #2f8cff; border-color:#9fd0ff; }\n.pip.next{ border-color:#ffd447; color:#ffd447; }\n.pip.lock{ opacity:.4; }\n.upgCtl{ display:flex; gap:6px; justify-content:center; align-items:center; flex-wrap:wrap; }\n.upgCtl button{ margin:2px; padding:9px 12px; font-size:13px; }\n.cSec{ margin-top:14px; }\n.cSec h3{ margin:6px 0 6px; }\n.cGrid{ display:grid; grid-template-columns:repeat(2,1fr); gap:8px; }\n.citem{ position:relative; border:2px solid #334c80; border-radius:14px; padding:7px; background:#0e1a38; display:flex; flex-direction:column; align-items:center; text-align:center; gap:3px; min-width:0; }\n.citem canvas{ display:block; width:100%; height:auto; aspect-ratio:320/165; border-radius:10px; background:#050a1e; border:1px solid rgba(255,255,255,.2); }\n.citem.paid{ border-color:#ffd447; box-shadow:0 0 10px #ffd44744; }\n.citem.vipItem{ border-color:#ffd447; }\n.citem.active, .citem.paid.active, .citem.vipItem.active{ border-color:#2f9bff; box-shadow:0 0 14px #2f9bffcc; }\n.citem .nm{ font-weight:bold; font-size:13px; }\n.citem .ds{ font-size:11px; color:#aebce2; min-height:26px; line-height:1.5; }\n.citem .pw{ font-size:11px; color:#9dffb0; line-height:1.4; }\n.citem button{ width:100%; margin:2px 0 0; padding:8px 4px; font-size:13px; }\n.citem button.isActive{ background:#2f9bff; color:#fff; }\n.citem.locked{ opacity:1; }\n.cNote{ color:#65eaff; font-size:12px; margin:4px 0 8px; }\n.pack, .offer{ background:linear-gradient(180deg,#1a1440,#0e1a38); border:2px solid #c06cff; border-radius:16px; padding:10px; margin:10px 0; text-align:right; box-shadow:0 0 14px #c06cff44; }\n.offer{ border-color:#ff9a3d; box-shadow:0 0 16px #ff9a3d55; }\n.pack .pTitle, .offer .pTitle{ font-weight:bold; font-size:15px; display:flex; justify-content:space-between; align-items:center; gap:6px; }\n.pack .disc, .offer .disc{ background:#e2323d; color:#fff; border-radius:9px; padding:2px 8px; font-size:12px; font-weight:bold; white-space:nowrap; }\n.pack ul, .offer ul{ margin:6px 0; padding:0 18px 0 0; font-size:12px; color:#d3dcf5; line-height:1.9; }\n.offer .tm{ color:#ffb36b; font-size:12px; font-weight:bold; }\n.pack button, .offer button{ width:100%; margin:4px 0 0; }\n.recMore{ margin:8px 0; text-align:right; background:#101d3d; border-radius:12px; padding:8px 10px; }\n.recWarn{ background:#3a2410; border:1px solid #ffb347; color:#ffe3b8; border-radius:12px; padding:9px 11px; margin:8px 0; font-size:12.5px; line-height:1.9; text-align:right; }\n.recWarn b{ color:#ffd447; }\n#sr-root.vipTheme .panel{ border:1.5px solid #ffd447; background:linear-gradient(160deg,#1b1506f7,#09142ff7 45%,#1b1506f7); box-shadow:0 18px 70px #000b, 0 0 26px #ffd44744, inset 0 0 22px #ffd44718; }\n#sr-root.vipTheme .panel h2, #sr-root.vipTheme .panel h3{ background:linear-gradient(90deg,#ffe27a,#ffd447,#fff3b0,#ffd447,#ffe27a); background-size:200% 100%; -webkit-background-clip:text; background-clip:text; color:transparent; animation:achShimmer 4s linear infinite; }\n#sr-root.vipTheme #menu .panel h2::before{ content:\"👑 \"; }\n#sr-root.vipTheme .panel button.premium, #sr-root.vipTheme .panel button.reward{ background:linear-gradient(180deg,#ffe27a,#d99a1a); color:#2a1a00; border:1px solid #fff3b0; box-shadow:0 0 12px #ffd44755; }\n#sr-root.vipTheme .panel button.secondary{ border:1px solid #8a6a18; color:#ffe9a0; }\n#sr-root.vipTheme .panel .card, #sr-root.vipTheme .panel .tutCard, #sr-root.vipTheme .panel .stat{ border-color:#7a5c1488; }\n#sr-root.vipTheme .panel .bar .fill{ background:linear-gradient(90deg,#ffd447,#fff3b0); }\n#sr-root.vipTheme .panel .sub{ color:#ffe9a0; }\n.shareGrid{ display:grid; grid-template-columns:1fr 1fr; gap:6px; margin:8px 0; }\n.shareGrid button{ margin:0 !important; width:100%; padding:10px 6px; font-size:14px; }\n#supAddr{ direction:ltr; text-align:center; color:#9dd8ff; user-select:text; -webkit-user-select:text; margin:6px 0; }\n#sr-root input, #sr-root textarea{ -webkit-user-select:text; user-select:text; touch-action:manipulation; font-size:16px; }\n.cxCard{ text-align:right; }\n.cxTiers{ margin-top:6px; }\n.cxTier{ display:flex; justify-content:space-between; align-items:center; gap:6px; background:#0d1733; border-radius:10px; padding:5px 9px; margin:4px 0; font-size:12.5px; }\n.cxTier.done{ opacity:.55; }\n.cxClaim{ padding:3px 10px !important; font-size:12px !important; }\n.achRow{ border:1.5px solid var(--tc,#3b4a78); box-shadow:0 0 10px var(--tg,transparent); }\n.tierChip{ display:inline-block; padding:1px 9px; border-radius:99px; font-size:11px; font-weight:bold; color:#1a1208; background:var(--tc,#888); margin:2px 0; }\n.achRow.t0, .tierChip.t0{ --tc:#cd7f32; --tg:#cd7f3230; }\n.achRow.t1, .tierChip.t1{ --tc:#c9d3e6; --tg:#c9d3e640; }\n.achRow.t2, .tierChip.t2{ --tc:#ffd447; --tg:#ffd44755; }\n.achRow.t3, .tierChip.t3{ --tc:#2af0c0; --tg:#2af0c066; }\n.achRow.t3{ background:linear-gradient(135deg,#0c2a2a,#101d3d) !important; }\n.tierChip.t3{ background:linear-gradient(90deg,#2af0c0,#2ad4ff); }\n.achRow.t4, .achRow.tMax{ border-color:#ff6ad5; box-shadow:0 0 16px #b46cff88; background:linear-gradient(135deg,#2a0f3a,#101d3d) !important; }\n.tierChip.t4, .tierChip.tMax{ color:#fff; background:linear-gradient(90deg,#ff6ad5,#b46cff,#ffd447,#ff6ad5); background-size:200% 100%; animation:achShimmer 2.2s linear infinite; text-shadow:0 0 6px #0008; }\n.achRow.tMax{ border-color:#ffd447; box-shadow:0 0 18px #ffd44788; background:linear-gradient(135deg,#3a2a05,#2a0f3a) !important; }\n@keyframes achShimmer{ 0%{ background-position:0% 50%; } 100%{ background-position:200% 50%; } }\n.bonusCard{ border:2px solid #ffd447 !important; background:linear-gradient(135deg,#2a2208,#1b1640) !important; box-shadow:0 0 14px #ffd44733; }\n.bonusCard.weekly{ border-color:#65eaff !important; background:linear-gradient(135deg,#0a2a33,#1b1640) !important; box-shadow:0 0 14px #65eaff33; }\n#shop .row button{ white-space:nowrap; }\n.supportBox{ background:#0f2a44; border:1px solid #4fc3ff; color:#d8f1ff; border-radius:12px; padding:9px 11px; margin:8px 0; font-size:12.5px; line-height:1.9; text-align:right; }\n#supportAddr{ direction:ltr; text-align:center; color:#9dd8ff; user-select:text; -webkit-user-select:text; margin:2px 0 8px; }\n.statHead{ grid-column:1/-1; text-align:right; font-weight:bold; font-size:14px; color:#ffd447; margin:10px 2px 0; padding-top:6px; border-top:1px solid #243a68; }\n.statHead:first-child{ margin-top:0; border-top:0; padding-top:0; }\n.permTag{ display:block; margin:2px 0 8px; font-size:16px; font-weight:bold; color:#ffd447; text-shadow:0 0 10px #ffb34766; }\n.recMore summary{ cursor:pointer; color:#9fb4e8; font-size:13px; }\n\n#hint:empty{ display:none !important; }\n.chips{ display:flex; gap:6px; overflow-x:auto; padding:6px 2px 8px; margin:2px 0 4px; -webkit-overflow-scrolling:touch; }\n.cGrid{ grid-template-columns:1fr !important; }\n.chip{ flex:0 0 auto; padding:7px 12px; font-size:12px; margin:0; border-radius:20px; background:#1b2a50; border:1px solid #3a5290; white-space:nowrap; }\n";
    document.head.appendChild(style);
  }
  root.innerHTML = "<canvas id=\"game\"></canvas>\n<div id=\"flashOverlay\"></div>\n\n<div id=\"ui\">\n<button id=\"soundButton\">🔊</button>\n<button id=\"musicButton\">🎵</button>\n<button id=\"pauseBtn\" class=\"hidden\">⏸</button>\n<button id=\"ghostBtn\" class=\"hidden\" aria-label=\"حالت روح\">👻<span id=\"ghostCd\"></span></button>\n\n<div class=\"hud\">\n<div class=\"badge\" id=\"badgeCoin\"><span class=\"iconCoin\"></span> <span id=\"coins\">0</span></div>\n<div class=\"badge\" id=\"badgeGem\"><span class=\"iconGem\"></span> <span id=\"gems\">0</span></div>\n<div class=\"badge\">⭐ سطح <span id=\"level\">1</span><span id=\"vipTag\" class=\"hidden\"> 👑</span></div>\n<div class=\"badge\" id=\"badgeScore\">🎯 <span id=\"score\">0</span></div>\n<div class=\"badge\">⚡ <span id=\"speed\">5.0</span></div>\n<div id=\"timerBadge\" class=\"badge hidden\" style=\"background:#b33939;\">⏳ <span id=\"timeLeft\">60</span>s</div>\n<div id=\"comboBadge\" class=\"badge hidden\" style=\"background:#5a1f8a; border-color:#c06cff;\">🔥 زنجیره ×<span id=\"comboVal\">0</span></div>\n<div id=\"magBadge\" class=\"badge hidden\">🧲 <span id=\"magTime\">7.0</span>s</div>\n<div id=\"dashBadge\" class=\"badge hidden\" style=\"background:#cc2200; border-color:#ff5533;\">🔥 سرعت نهایی</div>\n<div id=\"slowBadge\" class=\"badge hidden\" style=\"background:#0088cc; border-color:#00d2ff;\">❄️ آهسته‌سازی زمان</div>\n<div id=\"shieldBadge\" class=\"badge hidden\" style=\"background:#008888; border-color:#00ffff;\">🛡️ سپر ×<span id=\"shieldVal\">1</span></div>\n<div id=\"bhBadge\" class=\"badge hidden\" style=\"background:#3b0764; border-color:#a855f7;\">🕳️ سیاهچاله <span id=\"bhProgress\">0</span>/1000</div>\n<div id=\"rgBadge\" class=\"badge hidden\" style=\"background:#7a5c00; border-color:#ffd447;\">🌟 کهکشان جایزه <span id=\"rgProgress\">0</span>/800</div>\n<div id=\"multBadge\" class=\"badge hidden\" style=\"background:#7a4f00; border-color:#ffe066;\">✨ امتیاز ×2</div>\n<div id=\"showerBadge\" class=\"badge hidden\" style=\"background:#004d66; border-color:#00d2ff;\">🌠 بارش الماسی</div>\n<div id=\"sfBadge\" class=\"badge hidden\" style=\"background:#b33900; border-color:#ffd447;\">☀️ شراره خورشیدی ×۲ امتیاز</div>\n<div id=\"ghostBadge\" class=\"badge hidden\" style=\"background:#3b0764; border-color:#d7b3ff;\">👻 روح</div>\n<div id=\"comboArmorBadge\" class=\"badge hidden\" style=\"background:#1d3a1d; border-color:#9dffb0;\">🔗 زره زنجیره</div>\n<div id=\"iceBadge\" class=\"badge hidden\" style=\"background:#0a3d66; border-color:#7ad7ff;\">❄️ یخ‌زدگی</div>\n<div id=\"starBadge\" class=\"badge hidden\" style=\"background:#1d1530; border-color:#ffd447;\">⭐ صورت‌فلکی <span id=\"starVal\">0</span>/3</div>\n</div>\n\n<div id=\"toast\"></div>\n<div id=\"eventAlert\" class=\"hidden\">☄️ بارش شهابی نزدیک می‌شود!</div>\n<div id=\"bhAlert\" class=\"hidden\">🕳️ یک سیاهچاله در حال نزدیک شدن است!</div>\n<div id=\"rgAlert\" class=\"hidden\">🌟 یک کهکشان جایزه نزدیک می‌شود!</div>\n<div id=\"sfAlert\" class=\"hidden\">☀️ شراره خورشیدی نزدیک است!</div>\n<div id=\"iceAlert\" class=\"hidden\">❄️ یخ‌زدگی کیهانی نزدیک است!</div>\n<div id=\"deathVeil\"></div>\n\n<div id=\"hint\" class=\"hidden\"></div>\n\n<!-- MENU -->\n<section id=\"menu\" class=\"screen\">\n<div class=\"panel\">\n<h1>🚀 دونده فضایی</h1>\n<div class=\"sub\">در میان سیارات و کهکشان بدو و رکورد بزن!</div>\n<div class=\"modeSelect\">\n<button class=\"modeBtn active\" id=\"modeClassic\" onclick=\"setMode('classic')\">♾️ بی‌نهایت</button>\n<button class=\"modeBtn\" id=\"modeTime\" onclick=\"setMode('time')\">⏳ تایم‌اتک</button>\n<button class=\"modeBtn\" id=\"modeHard\" onclick=\"setMode('hard')\">💣 سخت</button>\n<button class=\"modeBtn\" id=\"modeImpossible\" onclick=\"setMode('impossible')\">💀 غیرممکن</button>\n<button class=\"modeBtn\" id=\"modeAurora\" onclick=\"setMode('aurora')\">🌌 شفق ۳۰۰۰🟡</button>\n</div>\n<div id=\"modeDesc\" class=\"sub\" style=\"font-size:11px; color:#ffd447; margin-bottom:8px;\">حالت استاندارد بی‌نهایت</div>\n\n<div class=\"wallet\">\n<span><span class=\"iconCoin\"></span> <b id=\"menuCoins\">0</b></span>\n<span><span class=\"iconGem\"></span> <b id=\"menuGems\">0</b></span>\n<span>⭐ <b id=\"menuLevel\">1</b></span>\n</div>\n<div class=\"small\" id=\"rankTitle\" style=\"color:#ffd447; margin-top:-4px; margin-bottom:8px;\">🎖️ تازه‌وارد</div>\n<div class=\"small\" id=\"pilotName\" style=\"color:#ffd447; margin-top:-2px;\"></div>\n<div class=\"small\" id=\"featuredEventBanner\" style=\"color:#65eaff; margin-top:-4px; margin-bottom:8px;\"></div>\n<div id=\"challengeBox\"><div class=\"small\">🎯 چالش امروز</div><div id=\"challengeText\" class=\"small\" style=\"color:#65eaff;\"></div></div>\n<div id=\"lastRunLine\" class=\"small\" style=\"color:#aebce2; margin-bottom:6px;\"></div>\n<div id=\"bestTodayLine\" class=\"small\" style=\"color:#ffd447; margin-bottom:6px;\"></div>\n\n<div class=\"cards\">\n<div class=\"card\">XP<div class=\"bar\"><div id=\"xpFill\" class=\"fill\"></div></div><span class=\"small\"><span id=\"xpText\">0/100</span></span></div>\n<div class=\"card\">🏆 رکورد<br><b id=\"menuBest\">0</b></div>\n</div>\n\n<button id=\"start\">🚀 شروع بازی</button><br>\n<div id=\"quickShopRow\" style=\"display:flex; gap:6px; justify-content:center; flex-wrap:wrap; margin:4px 0;\">\n<button class=\"secondary\" id=\"quickBuyHeadMenu\" style=\"font-size:11px; padding:7px 9px;\">🚀 150 🟡</button>\n<button class=\"secondary\" id=\"quickBuyShieldMenu\" style=\"font-size:11px; padding:7px 9px;\">🛡️ 300 🟡</button>\n<button class=\"secondary\" id=\"quickBuyMagMenu\" style=\"font-size:11px; padding:7px 9px;\">🧲 220 🟡</button>\n<button class=\"secondary\" id=\"quickBuyComboMenu\" style=\"font-size:11px; padding:7px 9px;\">🔗 180 🟡</button>\n</div>\n<button class=\"ad-btn\" id=\"watchAdGemsMenu\">📺 ۵ 💎 رایگان (۶ بار در روز)</button><div id=\"adGemsHint\" class=\"small\"></div><br>\n\n<button class=\"secondary\" id=\"shopBtn\">🛒 فروشگاه</button>\n<button class=\"secondary\" id=\"customizeBtn\">🎨 شخصی‌سازی</button>\n<button class=\"premium hidden\" id=\"offersBtn\">🔥 پیشنهاد ویژه</button>\n<button class=\"secondary\" id=\"missionsBtn\">📋 مأموریت‌ها</button>\n<button class=\"secondary\" id=\"achBtn\">🏅 دستاوردها</button>\n<button class=\"secondary\" id=\"statsBtn\">📊 آمار</button>\n<button class=\"secondary\" id=\"dailyBtn\">🎁 پاداش روزانه</button><br>\n<button class=\"premium\" id=\"wheelBtn\">🎡 چرخ شانس</button>\n<button class=\"secondary\" id=\"lbBtn\">🏆 رکوردها</button>\n<button class=\"secondary\" id=\"settingsBtn\">⚙️ تنظیمات</button>\n<button class=\"secondary\" id=\"codexBtn\">📖 اطلس کیهانی</button>\n<button class=\"secondary\" id=\"howtoBtn\">❓ راهنما</button>\n<button class=\"secondary\" id=\"aboutBtn\">ℹ️ درباره</button>\n<div id=\"luckyBanner\" class=\"small hidden\" style=\"color:#9dffb0;\"></div>\n</div>\n</section>\n\n<!-- SHOP -->\n<section id=\"shop\" class=\"screen hidden\">\n<div class=\"panel\">\n<button class=\"closeX\" id=\"closeShopX\" aria-label=\"بستن\">✕</button>\n<h2>🛒 فروشگاه فضایی</h2>\n<div id=\"inviteBoxShop\" class=\"hidden\"><div class=\"small\">بازی رو دوست داشتی؟ دوستات رو هم دعوت کن 🎮</div><button class=\"reward inviteBtn\">👥 دعوت از دوستان</button></div><div id=\"rateBoxShop\" class=\"hidden\"><div class=\"small\">از بازی خوشت اومد؟ بهمون امتیاز بده ⭐</div><button class=\"reward rateYesBtn\" id=\"rateYesShop\">⭐ ثبت امتیاز در مایکت</button></div>\n<div class=\"wallet\">\n<span><span class=\"iconCoin\"></span> <b id=\"shopCoins\">0</b></span>\n<span><span class=\"iconGem\"></span> <b id=\"shopGems\">0</b></span>\n</div>\n<button class=\"secondary\" id=\"shopToCustomize\" style=\"width:100%; margin:6px 0 2px;\">🎨 رفتن به شخصی‌سازی</button>\n\n<h3>🚫 حذف تبلیغات</h3>\n<div class=\"row\"><div>🚫 حذف تبلیغات همیشگی<br><span class=\"small\">یک‌بار خرید، تا همیشه. زنده شدن رایگان: ۱ بار در هر دور (با VIP می‌شود ۲ بار). با حذف تبلیغات هر جایزه تبلیغاتی را بدون دیدن تبلیغ و فقط با یک کلیک دریافت کن! <span id=\"noAdsStatus\"></span></span></div><button class=\"iap-btn\" id=\"buyNoAds\">۹۹,۰۰۰ ت</button></div>\n\n<h3>🛠️ ارتقای سفینه</h3>\n<div class=\"small\" style=\"margin-bottom:6px;\">هر ارتقا ۱۰ سطح دارد. سطح فعال را می‌توانی روی هر سطحِ خریداری‌شده جابه‌جا کنی؛ سطح‌ها فقط به ترتیب خریده می‌شوند.</div>\n<div id=\"shipUpgrades\"></div>\n\n<h3>⚙️ آیتم‌های قدرتی</h3>\n<span class=\"permTag\">✨ قدرت‌های همیشگی!</span>\n<div class=\"small\" style=\"margin-bottom:6px;\">هر آیتم را بخر؛ بعد از خرید همان دکمه برای فعال/غیرفعال کردنش استفاده می‌شود.</div>\n<div class=\"row\"><div>⚡ موتور توربو<br><span class=\"small\">XP بیشتر در هر سکه</span></div><button id=\"btnTurbo\">1500</button></div>\n<div class=\"row\"><div>💰 سکه‌ساز دوبل<br><span class=\"small\">هر سکه ۲ برابر حساب می‌شود</span></div><button id=\"btnCoinX2\">155 💎</button></div>\n<div class=\"row\"><div>🍀 شانس جعبه طلایی<br><span class=\"small\">جعبه بیشتر + جایزه بهتر</span></div><button id=\"btnLucky\">98 💎</button></div>\n<div class=\"row\"><div>⏱️ آهنربای طولانی<br><span class=\"small\">افزایش زمان آهنربا به ۱۰ ثانیه</span></div><button id=\"btnLongMag\">2500</button></div>\n<div class=\"row\"><div>🧲 میدان آهنربای وسیع<br><span class=\"small\">شعاع جذب آهنربا ۴۰٪ بیشتر می‌شود</span></div><button id=\"btnMagRange\">4500</button></div>\n<div class=\"row\"><div>🔰 شارژ مجدد سپر<br><span class=\"small\">امکان داشتن تا ۳ سپر همزمان</span></div><button id=\"btnShieldStack\">6500</button></div>\n<div class=\"row\"><div>✨ شانس نوری<br><span class=\"small\">افزایش احتمال برخورد به الماس‌ها</span></div><button id=\"btnGemLuck\">125 💎</button></div>\n<div class=\"row\"><div>🛡️ سپر همیشگی <b style=\"color:#ffd447\">(قدرتمند)</b><br><span class=\"small\">شروع هر بازی با یک سپر دفاعی</span></div><button id=\"btnShield\">12000</button></div>\n<div class=\"row\"><div>🔄 بازسازی سپر <b style=\"color:#ffd447\">(قدرتمند)</b><br><span class=\"small\">اگر سپر نداشته باشی، هر ۲۰ ثانیه یک سپر رایگان می‌گیری</span></div><button id=\"btnShieldRegen\">520 💎</button></div>\n<div class=\"row\"><div>🦘 پرش سه‌گانه <b style=\"color:#c06cff\">(قدرتمند)</b><br><span class=\"small\">یک پرش اضافه در هوا</span></div><button id=\"btnTriple\">260 💎</button></div>\n<div class=\"row\" style=\"border:1px solid #ff6ec7; box-shadow:0 0 12px #ff6ec744;\"><div>🚀 پرش چهارگانه <b style=\"color:#ff6ec7\">(فوق‌العاده قدرتمند!)</b><br><span class=\"small\">دو پرش اضافه در هوا — کنترل کامل آسمان، مخصوص حرفه‌ای‌ها</span></div><button id=\"btnQuad\">850 💎</button></div>\n<div class=\"row\"><div>🛰️ ماهواره جمع‌کن <b style=\"color:#65eaff\">(قدرتمند)</b><br><span class=\"small\">سکه‌های نزدیک رو خودکار جذب می‌کنه، حتی بدون آهنربا</span></div><button id=\"btnAutoCollect\">5000</button></div>\n<div class=\"row\"><div>🍀 شانس فرار <b style=\"color:#00ffcc\">(قدرتمند)</b><br><span class=\"small\">۲۰٪ شانس رد شدن از برخورد بدون از دست دادن سپر</span></div><button id=\"btnDodge\">230 💎</button></div>\n<div class=\"row\"><div>⏳ پاورآپ‌های ماندگار <b style=\"color:#ffd447\">(قدرتمند)</b><br><span class=\"small\">زمان آهسته‌سازی، امتیاز ×۲ و حالت روح ۳۰٪ بیشتر می‌شود</span></div><button id=\"btnPowerDur\">500 💎</button></div>\n<div class=\"row\"><div>🛡️ سپر زنده‌شدن<br><span class=\"small\">وقتی با ویدیو یا الماس زنده می‌شوی، یک سپر هم می‌گیری. بدون این قدرت فقط یک ایمنی کوتاه داری.</span></div><button id=\"btnReviveShieldGem\" class=\"premium\">۱۲۰ 💎</button></div>\n<div class=\"row\"><div>⚡ پاورآپ سریع‌تر<br><span class=\"small\">پاورآپ‌ها بیشتر و زودتر ظاهر می‌شوند</span></div><button id=\"btnFastPower\">3500</button></div>\n<div class=\"row\"><div>🎯 سکه نزدیک‌بود<br><span class=\"small\">هر عبور نزدیک یک سکه اضافه می‌دهد</span></div><button id=\"btnNearMiss\">110 💎</button></div>\n<div class=\"row\"><div>🔗 زنجیره‌ی مقاوم<br><span class=\"small\">هر دور بازی با یک زره زنجیره‌ی رایگان شروع می‌شود</span></div><button id=\"btnComboPerm\">4500</button></div>\n<div class=\"row\"><div>🟡 سکه‌ی طلایی بیشتر<br><span class=\"small\">شانس ظاهر شدن سکه‌های طلایی ۲ برابر می‌شود</span></div><button id=\"btnSuperCoin\">3500</button></div>\n<div class=\"row\"><div>🔒 قفل ضد دزد<br><span class=\"small\">دزدهای فضایی نمی‌توانند سکه‌ات را بدزدند و با برخورد نابود می‌شوند</span></div><button id=\"btnAntiThief\">2600</button></div>\n\n<h3>🎒 تجهیزات یک‌بار مصرف (خرید با سکه)</h3>\n<div class=\"row\"><div>🚀 شروع سریع<br><span class=\"small\">از اول بازی تا آخرِ زمان سرعت نهایی، با سرعت نهایی می‌دوی</span></div><button id=\"buyBoostHead\">150 🟡 <span id=\"cntHead\"></span></button></div>\n<div class=\"row\"><div>🛡️ سپر شروع<br><span class=\"small\">شروع بازی با سپر اضافه</span></div><button id=\"buyBoostShield\">300 🟡 <span id=\"cntShield\"></span></button></div>\n<div class=\"row\"><div>🧲 آهنربای شروع<br><span class=\"small\">۷ ثانیه آهنربای رایگان از ابتدا</span></div><button id=\"buyBoostMag\">220 🟡 <span id=\"cntMag\"></span></button></div>\n<div class=\"row\"><div>🔗 زره زنجیره<br><span class=\"small\">یک‌بار زنجیره را از قطع شدن حفظ می‌کند</span></div><button id=\"buyBoostCombo\">180 🟡 <span id=\"cntCombo\"></span></button></div>\n<div class=\"small\" style=\"margin-top:4px;\">تجهیزات خریداری‌شده خودکار در شروع بازی بعدی مصرف می‌شوند.</div>\n\n<h3>🎫 بلیط رویداد (تجربه‌ی تضمینی در بازی بعدی)</h3>\n<div class=\"row\"><div>🌟 بلیط کهکشان جایزه<br><span class=\"small\">بازی بعدی، کهکشان جایزه تضمینی است</span></div><button id=\"buyTicketRG\">62 💎</button></div>\n<div class=\"row\"><div>🕳️ بلیط سیاهچاله<br><span class=\"small\">بازی بعدی، سیاهچاله مرگ تضمینی است</span></div><button id=\"buyTicketBH\">70 💎</button></div>\n<div class=\"row\"><div>🌠 بلیط بارش الماسی<br><span class=\"small\">بازی بعدی، بارش الماسی تضمینی است</span></div><button id=\"buyTicketDS\">45 💎</button></div>\n<div class=\"row\"><div>❄️ بلیط یخ‌زدگی<br><span class=\"small\">بازی بعدی، یخ‌زدگی کیهانی تضمینی است</span></div><button id=\"buyTicketIce\">40 💎</button></div>\n<div class=\"row\"><div>☀️ بلیط شراره خورشیدی<br><span class=\"small\">بازی بعدی، شراره خورشیدی تضمینی است</span></div><button id=\"buyTicketFlare\">40 💎</button></div>\n\n<h3>💎 خرید بسته‌های الماس (پرداخت درون‌برنامه‌ای)</h3>\n<div class=\"row\"><div>بسته کوچک<br><span class=\"small\">60 💎</span></div><button class=\"iap-btn\" data-price=\"8000\" data-gems=\"60\">۸,۰۰۰ ت</button></div>\n<div class=\"row\"><div>بسته مقدماتی<br><span class=\"small\">200 💎</span></div><button class=\"iap-btn\" data-price=\"24000\" data-gems=\"200\">۲۴,۰۰۰ ت</button></div>\n<div class=\"row\"><div>بسته متوسط<br><span class=\"small\">450 💎</span></div><button class=\"iap-btn\" data-price=\"48000\" data-gems=\"450\">۴۸,۰۰۰ ت</button></div>\n<div class=\"row\"><div>بسته بزرگ <b style=\"color:#ffd447\">(محبوب‌ترین بسته)</b><br><span class=\"small\">1300 💎</span></div><button class=\"iap-btn\" data-price=\"120000\" data-gems=\"1300\">۱۲۰,۰۰۰ ت</button></div>\n<div class=\"row\"><div>بسته ویژه<br><span class=\"small\">3500 💎</span></div><button class=\"iap-btn\" data-price=\"280000\" data-gems=\"3500\">۲۸۰,۰۰۰ ت</button></div>\n<div class=\"row\"><div>بسته افسانه‌ای <b style=\"color:#ffd447\">(بهترین ارزش خرید!)</b><br><span class=\"small\">12000 💎</span></div><button class=\"iap-btn premium\" data-price=\"790000\" data-gems=\"12000\">۷۹۰,۰۰۰ ت</button></div>\n\n<h3>📺 دریافت الماس رایگان</h3>\n<div class=\"row\">\n<div>تماشای تبلیغ<br><span class=\"small\">دریافت ۵ عدد الماس 💎</span></div>\n<button class=\"ad-btn\" id=\"watchAdGemsShop\">تماشا</button>\n</div>\n\n<h3>💱 تبدیل الماس به سکه</h3>\n<div class=\"row\"><div>۵ 💎 به ۲۰۰ 🟡</div><button id=\"ex10\">تبدیل</button></div>\n<div class=\"row\"><div>۲۰ 💎 به ۱۰۰۰ 🟡</div><button id=\"ex50\">تبدیل</button></div>\n<br><button class=\"secondary\" id=\"closeShop\">بازگشت</button>\n</div>\n</section>\n\n<!-- CUSTOMIZE -->\n<section id=\"customize\" class=\"screen hidden\">\n<div class=\"panel\">\n<button class=\"closeX\" id=\"closeCustomizeX\" aria-label=\"بستن\">✕</button>\n<h2>🎨 شخصی‌سازی</h2>\n<div class=\"wallet\">\n<span><span class=\"iconCoin\"></span> <b id=\"custCoins\">0</b></span>\n<span><span class=\"iconGem\"></span> <b id=\"custGems\">0</b></span>\n</div>\n<div class=\"small\" style=\"color:#65eaff; margin:6px 0;\">✨ با گرافیک بالاتر، برخی افکت‌ها بهتر و کامل‌تر دیده می‌شوند. همه‌ی موارد این بخش فقط ظاهری‌اند و روی گیم‌پلی اثری ندارند.</div>\n<div id=\"custBody\"></div>\n<br><button class=\"secondary\" id=\"closeCustomize\">بازگشت</button>\n</div>\n</section>\n\n<!-- OFFERS -->\n<section id=\"offers\" class=\"screen hidden\">\n<div class=\"panel\">\n<button class=\"closeX\" id=\"closeOffersX\" aria-label=\"بستن\">✕</button>\n<h2>🔥 پیشنهادهای ویژه</h2>\n<div class=\"small\" style=\"margin-bottom:8px;\">پیشنهادها زمان‌دار هستند و با گذشت زمان از بین می‌روند. قیمتشان از خرید جداگانه‌ی همان موارد به‌صرفه‌تر است.</div>\n<div id=\"offersBody\"></div>\n<br><button class=\"secondary\" id=\"closeOffers\">بازگشت</button>\n</div>\n</section>\n\n<!-- MISSIONS -->\n<section id=\"missions\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>📋 مأموریت‌های روزانه</h2>\n<div id=\"inviteBoxMissions\" class=\"hidden\"><div class=\"small\">بازی رو دوست داشتی؟ دوستات رو هم دعوت کن 🎮</div><button class=\"reward inviteBtn\">👥 دعوت از دوستان</button></div><div id=\"rateBoxMissions\" class=\"hidden\"><div class=\"small\">از بازی خوشت اومد؟ بهمون امتیاز بده ⭐</div><button class=\"reward rateYesBtn\" id=\"rateYesMissions\">⭐ ثبت امتیاز در مایکت</button></div>\n<div class=\"small\" style=\"color:#ffaa00; margin-bottom:8px;\">⏰ این مأموریت‌ها هر روز جدید می‌شوند!</div>\n<div class=\"card\">🟡 جمع کردن 90 سکه<br><b id=\"m1\">0/90</b><div class=\"bar\"><div id=\"m1bar\" class=\"fill\"></div></div><span class=\"small\">پاداش: 90 سکه + 3 الماس</span><br><button id=\"claimM1\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card\">🏆 رسیدن به 3500 امتیاز<br><b id=\"m2\">0/3500</b><div class=\"bar\"><div id=\"m2bar\" class=\"fill\"></div></div><span class=\"small\">پاداش: 5 الماس</span><br><button id=\"claimM2\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card\">🧲 فعال‌کردن آهنربا 5 بار<br><b id=\"m3\">0/5</b><div class=\"bar\"><div id=\"m3bar\" class=\"fill\"></div></div><span class=\"small\">پاداش: 90 سکه</span><br><button id=\"claimM3\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card\">💫 استفاده از بمب نواختری 4 بار<br><b id=\"m4\">0/4</b><div class=\"bar\"><div id=\"m4bar\" class=\"fill\"></div></div><span class=\"small\">پاداش: 4 الماس</span><br><button id=\"claimM4\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card\">💎 جمع کردن 18 الماس فضایی<br><b id=\"m5\">0/18</b><div class=\"bar\"><div id=\"m5bar\" class=\"fill\"></div></div><span class=\"small\">پاداش: 160 سکه</span><br><button id=\"claimM5\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card\">🦘 پرش کردن 70 بار<br><b id=\"m6\">0/70</b><div class=\"bar\"><div id=\"m6bar\" class=\"fill\"></div></div><span class=\"small\">پاداش: 100 سکه</span><br><button id=\"claimM6\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card\">🎮 انجام 3 بازی امروز<br><b id=\"m7\">0/3</b><div class=\"bar\"><div id=\"m7bar\" class=\"fill\"></div></div><span class=\"small\">پاداش: 3 الماس</span><br><button id=\"claimM7\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card\">🕳️ یک بار وارد سیاهچاله مرگ شو<br><b id=\"m8\">0/1</b><div class=\"bar\"><div id=\"m8bar\" class=\"fill\"></div></div><span class=\"small\">پاداش: 120 سکه</span><br><button id=\"claimM8\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card\">🌟 یک بار کهکشان جایزه رو تجربه کن<br><b id=\"m9\">0/1</b><div class=\"bar\"><div id=\"m9bar\" class=\"fill\"></div></div><span class=\"small\">پاداش: 4 الماس</span><br><button id=\"claimM9\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card\">🔥 زنجیره ۱۵ بساز<br><b id=\"m10\">0/15</b><div class=\"bar\"><div id=\"m10bar\" class=\"fill\"></div></div><span class=\"small\">پاداش: ۸۰ سکه + ۴ الماس</span><br><button id=\"claimM10\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card\">🌌 یک دور شفق قطبی بازی کن<br><b id=\"m11\">0/1</b><div class=\"bar\"><div id=\"m11bar\" class=\"fill\"></div></div><span class=\"small\">پاداش: ۱۵۰ سکه + ۴ الماس</span><br><button id=\"claimM11\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card bonusCard\">🏆 پاداش بزرگ روزانه: همه‌ی ماموریت‌های امروز را کامل کن<br><b id=\"dBonusTxt\">0/11</b><div class=\"bar\"><div id=\"dBonusBar\" class=\"fill\"></div></div><span class=\"small\" id=\"dBonusReward\"></span><br><button id=\"claimDailyBonus\" class=\"reward hidden\">🎁 دریافت پاداش بزرگ</button><div id=\"dBonusDone\" class=\"small hidden\" style=\"color:#9dffb0;\">✅ پاداش بزرگ امروز را گرفتی</div></div>\n<div class=\"card\" style=\"border:1px solid #65eaff;\">📅 ماموریت هفتگی: ۲۰۰,۰۰۰ امتیاز کل این هفته<br><b id=\"wm1\">0/۲۰۰,۰۰۰</b><div class=\"bar\"><div id=\"wm1bar\" class=\"fill\"></div></div><span class=\"small\">پاداش بزرگ: ۳۰۰۰ سکه + ۴۰ الماس</span><br><button id=\"claimWm1\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card\" style=\"border:1px solid #65eaff;\">📅 ماموریت هفتگی: ۲۰۰ بازی این هفته<br><b id=\"wm2\">0/۲۰۰</b><div class=\"bar\"><div id=\"wm2bar\" class=\"fill\"></div></div><span class=\"small\">پاداش بزرگ: ۲۰۰۰ سکه + ۳۰ الماس</span><br><button id=\"claimWm2\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card\" style=\"border:1px solid #65eaff;\">📅 ماموریت هفتگی: در یک دور، در گیم‌مود سخت، به ۱۰,۰۰۰ امتیاز برس<br><b id=\"wm3\">0/۱۰,۰۰۰</b><div class=\"bar\"><div id=\"wm3bar\" class=\"fill\"></div></div><span class=\"small\">پاداش بزرگ: ۲۵۰۰ سکه + ۳۵ الماس</span><br><button id=\"claimWm3\" class=\"reward hidden\">🎁 دریافت</button></div>\n<div class=\"card bonusCard weekly\">🏆 پاداش بزرگ هفتگی: هر سه ماموریت هفتگی را کامل کن<br><b id=\"wBonusTxt\">0/3</b><div class=\"bar\"><div id=\"wBonusBar\" class=\"fill\"></div></div><span class=\"small\" id=\"wBonusReward\"></span><br><button id=\"claimWeeklyBonus\" class=\"reward hidden\">🎁 دریافت پاداش بزرگ</button><div id=\"wBonusDone\" class=\"small hidden\" style=\"color:#9dffb0;\">✅ پاداش بزرگ این هفته را گرفتی</div></div>\n<button class=\"secondary\" id=\"closeMissions\">بازگشت</button>\n</div>\n</section>\n\n<!-- ACHIEVEMENTS -->\n<section id=\"ach\" class=\"screen hidden\"><div class=\"panel\"><h2>🏅 دستاوردها</h2><div id=\"achList\"></div><button class=\"secondary\" id=\"closeAch\">بازگشت</button></div></section>\n\n<!-- STATS -->\n<section id=\"stats\" class=\"screen hidden\"><div class=\"panel\"><h2>📊 آمار فضانورد</h2><div class=\"grid3\" id=\"statsGrid\"></div><button class=\"secondary\" id=\"closeStats\">بازگشت</button></div></section>\n\n<!-- DAILY REWARDS -->\n<section id=\"daily\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>🎁 پاداش روزانه ۷ روزه</h2>\n<div class=\"dailyGrid\" id=\"dailyCalendar\"></div>\n<div id=\"dailyMsg\" class=\"sub\"></div>\n<div class=\"small\" style=\"color:#ffaa00; margin-bottom:10px;\">⚠️ اگر یک روز جوایز را دریافت نکنید، زنجیره روزانه از اول شروع می‌شود! پس از روز هفتم نیز تقویم از روز اول آغاز می‌گردد.</div>\n<button id=\"claimDaily\" class=\"reward\">دریافت پاداش</button><br>\n<button class=\"premium\" id=\"doubleDaily\">📺 دو برابر با تماشای تبلیغ</button>\n<div class=\"row\"><div>🛡️ محافظ زنجیره روزانه<br><span class=\"small\">اگر یک روز جا ماندی، زنجیره صفر نشود</span></div><button id=\"buyStreakShield\">۱۸ 💎</button></div><br>\n<button class=\"secondary\" id=\"closeDaily\">بازگشت</button>\n</div>\n</section>\n\n<!-- WHEEL -->\n<section id=\"wheel\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>🎡 چرخ شانس روزانه</h2>\n<div class=\"sub\" id=\"wheelMsg\">یک بار در روز بچرخان و جایزه رایگان بگیر!</div>\n<div class=\"wheelGrid\" id=\"wheelGrid\"></div>\n<button id=\"spinWheel\" class=\"premium\">🎡 چرخاندن</button><br>\n<button id=\"spinWheelAd\" class=\"ad-btn hidden\">📺 تماشای تبلیغ و یک چرخش دیگر</button><br>\n<button class=\"secondary\" id=\"closeWheel\">بازگشت</button>\n</div>\n</section>\n\n<!-- LEADERBOARD -->\n<section id=\"leaderboard\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>🏆 رکوردها</h2>\n<div id=\"lbList\"></div>\n<button class=\"secondary\" id=\"closeLb\">بازگشت</button>\n</div>\n</section>\n\n<!-- LEVEL UP -->\n<section id=\"levelUp\" class=\"screen hidden\"><div class=\"panel\"><div style=\"font-size:55px\">⭐</div><h2>🎉 ارتقای سطح!</h2><div class=\"sub\">به سطح <b id=\"newLevel\">2</b> رسیدی!</div><div class=\"card\">🎁 پاداش<br><br><span class=\"iconCoin\"></span> 100 + <span class=\"iconGem\"></span> 2</div><button id=\"claimLevel\" class=\"reward\">🎁 دریافت پاداش</button><br><button class=\"premium\" id=\"doubleLevel\">📺 دو برابر با تماشای تبلیغ</button></div></section>\n\n<!-- GAME OVER -->\n<section id=\"over\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>💥 پایان مسیر!</h2>\n<div class=\"sub\">امتیاز: <b id=\"finalScore\">0</b><br>سکه این دور: <span class=\"iconCoin\"></span> <b id=\"finalCoins\">0</b><br>الماس این دور: <span class=\"iconGem\"></span> <b id=\"finalGems\">0</b><br>رکورد: 🏆 <b id=\"best\">0</b></div>\n<div id=\"runRecap\" class=\"small\" style=\"margin-bottom:10px;\"></div>\n\n<div style=\"background:rgba(255,255,255,0.05); padding:10px; border-radius:14px; margin-bottom:12px;\">\n<div style=\"font-size:13px; margin-bottom:5px;\">ادامه بازی از همین امتیاز:</div>\n<button class=\"ad-btn\" id=\"watchAdContinue\">🎬 تماشای تبلیغ و زنده شدن</button>\n<div class=\"small\" style=\"color:#ffd447;\">حذف تبلیغات = ۱ زنده شدن رایگان در هر دور · VIP + حذف تبلیغات = ۲ بار · بعد از آن باید تبلیغ ببینی</div>\n<button class=\"premium\" id=\"gemContinue\">💎 ادامه فوری (۱۵ 💎)</button>\n<button class=\"secondary\" id=\"shareScoreBtn\">📤 اشتراک امتیاز</button>\n<div id=\"continueInfo\" class=\"small\" style=\"color:#ffd447;margin-top:6px;\"></div>\n</div>\n\n<div class=\"small\" style=\"margin-bottom:4px;\">🛍️ خرید سریع برای دور بعد:</div>\n<div style=\"display:flex; gap:6px; justify-content:center; flex-wrap:wrap; margin-bottom:10px;\">\n<button class=\"secondary\" id=\"quickBuyHeadOver\" style=\"font-size:12px; padding:8px 10px;\">🚀 150 🟡</button>\n<button class=\"secondary\" id=\"quickBuyShieldOver\" style=\"font-size:12px; padding:8px 10px;\">🛡️ 300 🟡</button>\n<button class=\"secondary\" id=\"quickBuyMagOver\" style=\"font-size:12px; padding:8px 10px;\">🧲 220 🟡</button>\n<button class=\"secondary\" id=\"quickBuyComboOver\" style=\"font-size:12px; padding:8px 10px;\">🔗 180 🟡</button>\n</div>\n\n<button id=\"again\">🚀 دوباره بازی کن</button><br>\n<button class=\"secondary\" id=\"overShop\">🛒 فروشگاه</button>\n<button class=\"secondary\" id=\"overCustomize\">🎨 شخصی‌سازی</button>\n<button class=\"secondary\" id=\"home\">🏠 منوی اصلی</button>\n<div id=\"inviteBoxOver\" class=\"hidden\"><div class=\"small\">بازی رو دوست داشتی؟ دوستات رو هم دعوت کن 🎮</div><button class=\"reward inviteBtn\">👥 دعوت از دوستان</button></div><div id=\"rateBoxOver\" class=\"hidden\"><div class=\"small\">از بازی خوشت اومد؟ بهمون امتیاز بده ⭐</div><button class=\"reward rateYesBtn\" id=\"rateYesOver\">⭐ ثبت امتیاز در مایکت</button></div>\n</div>\n</section>\n\n\n<section id=\"recCreate\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>🔑 ساخت رمز بازیابی</h2>\n<div class=\"sub\">یک رمز انتخاب کن (حتماً به خاطرش بسپار و جایی هم ذخیره‌اش کن)</div>\n<input id=\"recPassC\" class=\"recInput\" type=\"text\" maxlength=\"40\" autocomplete=\"off\" placeholder=\"رمز بازیابی\">\n<button class=\"reward\" id=\"recMake\">ساخت رمز</button>\n<div id=\"recOutWrap\" class=\"hidden\">\n<div class=\"small\" style=\"color:#9dffb0; margin:8px 0;\">✅ رمز بازیابی و کد انتقال ساخته شد.</div>\n<div class=\"recWarn\">⚠️ <b>کد انتقال از رمز مهم‌تر است!</b> چه بخواهی با گوشی دیگری وارد حسابت شوی و چه بعد از حذف بازی بخواهی حسابت را برگردانی، باید این کد را داشته باشی. همین حالا روی «کپی کردن» بزن و آن را جایی امن ذخیره کن (یادداشت گوشی، پیام‌های ذخیره‌شده‌ی تلگرام و…). رمزی را هم که گذاشتی حتماً یادت بماند و ذخیره‌اش کن؛ بدون کد و رمز، بازیابی ممکن نیست.</div>\n<div class=\"recRow\"><textarea id=\"recOut\" class=\"recArea\" readonly></textarea><button class=\"premium\" id=\"recCopy\">📋 کپی کردن کد انتقال</button></div>\n<div class=\"small\" style=\"margin-top:6px;\">این کد فقط پیشرفتِ تا همین لحظه را در خود دارد. هر وقت پیشرفت زیادی کردی، دوباره «ساخت رمز» را بزن و کد جدید را ذخیره کن.</div>\n</div>\n<button class=\"secondary\" id=\"recBackC\">بازگشت</button>\n</div>\n</section>\n\n<section id=\"recRestore\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>🔑 بازیابی با رمز</h2>\n<div class=\"sub\">رمز بازیابی‌ات را وارد کن</div>\n<input id=\"recPassR\" class=\"recInput\" type=\"text\" maxlength=\"40\" autocomplete=\"off\" placeholder=\"رمز بازیابی\">\n<div id=\"recMsg\" class=\"small\" style=\"color:#ff8a8a; min-height:18px;\"></div>\n<button class=\"reward\" id=\"recDo\">بازیابی حساب</button>\n<details class=\"recMore\" open><summary>📱 بازی را حذف کرده‌ای یا روی گوشی دیگری هستی؟</summary>\n<div class=\"small\" style=\"margin:6px 0;\">کد انتقالی را که ذخیره کرده‌ای اینجا بچسبان؛ بعد رمزت را بزن و بازیابی کن. بدون این کد، بعد از حذف بازی یا روی گوشی دیگر بازیابی ممکن نیست.</div>\n<textarea id=\"recIn\" class=\"recArea\" placeholder=\"کد انتقال\"></textarea>\n<button class=\"secondary\" id=\"recPaste\">📥 چسباندن</button>\n</details>\n<div class=\"small\" style=\"margin-top:6px;\">با بازیابی، پیشرفت فعلی این گوشی با اکانت ذخیره‌شده جایگزین می‌شود.</div>\n<button class=\"secondary\" id=\"recBackR\">بازگشت</button>\n</div>\n</section>\n\n<section id=\"settings\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>تنظیمات</h2>\n<div class=\"volRow\"><span>موسیقی</span><input id=\"musicVol\" type=\"range\" min=\"0\" max=\"100\" value=\"75\"></div>\n<div class=\"volRow\"><span>افکت صوتی</span><input id=\"sfxVol\" type=\"range\" min=\"0\" max=\"100\" value=\"85\"></div>\n<div class=\"sub\" style=\"font-size:17px; font-weight:bold; color:#ffffff; margin-bottom:4px;\">گرافیک بازی:</div>\n<div class=\"gfxRow\">\n<button class=\"gfxBtn\" data-gfx=\"max\">مکس</button>\n<button class=\"gfxBtn\" data-gfx=\"high\">بالا</button>\n<button class=\"gfxBtn\" data-gfx=\"medium\">متوسط</button>\n<button class=\"gfxBtn\" data-gfx=\"low\">پایین</button>\n</div>\n<div class=\"row\"><div>لرزش صفحه</div><input id=\"shakeToggle\" class=\"switch\" type=\"checkbox\" checked></div>\n<div class=\"row\"><div>لرزش لمسی (ویبره)</div><input id=\"hapticToggle\" class=\"switch\" type=\"checkbox\" checked></div>\n<div class=\"sub\">نام فضانورد</div>\n<input id=\"nickInput\" maxlength=\"16\" placeholder=\"نام تو\">\n<button class=\"secondary\" id=\"saveNick\">ذخیره نام</button>\n<div id=\"rateBoxSettings\"><div class=\"small\">از بازی خوشت اومد؟ بهمون امتیاز بده ⭐</div><button class=\"reward\" id=\"rateYesSettings\">⭐ امتیاز دادن به بازی</button></div>\n<div id=\"inviteBoxSettings\"><div class=\"small\">دوستات رو هم به بازی دعوت کن 🎮</div><button class=\"reward inviteBtn\" id=\"inviteSettings\">👥 دعوت از دوستان</button></div>\n<div class=\"sub\">🔑 رمز بازیابی — با گذاشتن یک رمز، هر وقت خواستی حسابت رو برگردون</div>\n<div class=\"recWarn\">⚠️ مهم: بعد از ساخت رمز، یک «کد انتقال» هم ساخته می‌شود. چه بخواهی با گوشی دیگری وارد حسابت شوی و چه بعد از حذف بازی بخواهی حسابت را برگردانی، حتماً به همین کد نیاز داری؛ پس آن را «کپی» کن و جایی امن ذخیره‌اش کن (مثلاً یادداشت‌های گوشی یا پیام‌های ذخیره‌شده‌ی تلگرام). کد از رمز مهم‌تر است، ولی رمزت را هم باید یادت بماند و جایی ذخیره کنی.</div>\n<button class=\"secondary\" id=\"createRecoveryCode\">ساخت رمز بازیابی</button>\n<button class=\"secondary\" id=\"restoreRecoveryCode\">بازیابی با رمز</button>\n<div class=\"sub\" style=\"font-size:16px; font-weight:bold; color:#ffffff; margin-top:10px;\">📨 ارتباط با پشتیبانی</div>\n<div class=\"supportBox\">اگر در بازی به مشکلی برخوردی، ایده یا پیشنهادی برای بهتر شدن بازی داری، یا هر موضوع دیگری هست که دوست داری بگویی، می‌توانی با ما در ارتباط باشی. نظرات و پیشنهادهای شما برای ما ارزشمند است و در بهتر شدن بازی نقش دارد.</div>\n<button class=\"premium\" id=\"supportMail\">📧 ارسال ایمیل به پشتیبانی</button>\n<button class=\"secondary\" id=\"supportCopy\">📋 کپی آدرس ایمیل</button>\n<div class=\"small\" id=\"supportAddr\" data-ascii dir=\"ltr\">erfanfirestar777@gmail.com</div>\n<button class=\"secondary\" id=\"howtoFromSettings\">❓ راهنمای بازی</button>\n<button class=\"secondary\" id=\"aboutFromSettings\">ℹ️ درباره و حریم خصوصی</button>\n<button class=\"secondary\" id=\"closeSettings\">بازگشت</button>\n</div>\n</section>\n<section id=\"pauseMenu\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>مکث</h2>\n<button id=\"resumeBtn\">ادامه</button><br>\n<button class=\"secondary\" id=\"pauseSettings\">تنظیمات</button>\n<button class=\"secondary\" id=\"pauseQuit\">خروج از دور</button>\n</div>\n</section>\n<section id=\"codex\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>اطلس کیهانی</h2><div class=\"small\">رویدادها و رازهایی که کشف کردی؛ با دیدن هر رویداد به تعداد معین، جایزه بگیر</div>\n<div id=\"codexList\"></div>\n<button class=\"secondary\" id=\"closeCodex\">بازگشت</button>\n</div>\n</section>\n<section id=\"iapBox\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2 id=\"iapTitle\">پرداخت</h2>\n<div class=\"sub\" id=\"iapDesc\"></div>\n<button class=\"iap-btn\" id=\"iapConfirm\">خرید از مایکت</button><br>\n<button class=\"secondary\" id=\"iapCancel\">انصراف</button>\n</div>\n</section>\n\n<section id=\"howto\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>❓ راهنمای بازی</h2>\n<div class=\"tutCard\">👆 لمس / کلید Space = پرش<br><span class=\"small\">در هوا دوباره لمس کن تا پرش دوبل بزنی · انگشتت را نگه‌دار تا کمی بلندتر بپری</span></div>\n<div class=\"tutCard\">🟡 سکه جمع کن تا زنجیره بسازی<br><span class=\"small\">زنجیره امتیاز و سرعت کوتاه می‌دهد</span></div>\n<div class=\"tutCard\">🛡️ سپر = یک برخورد رایگان<br>🧲 آهنربا سکه‌ها را جذب می‌کند<br>💫 بمب نواختر موانع جلو را پاک می‌کند</div>\n<div class=\"tutCard\">🌌 شفق قطبی (ورودی ۳۰۰۰ سکه): سکه‌ها، الماس‌ها، جایزه‌ها و پاورآپ‌های بسیار زیادی دارد</div>\n<div class=\"tutCard\">🍀 ساعت شانس (ساعت طلایی)<br><span class=\"small\">وقتی پاداش روزانه را برمی‌داری (یا دوبلش می‌کنی)، یک ساعت فعال می‌شود و در این یک ساعت همه‌ی سکه‌هایی که جمع می‌کنی ۵۰٪ بیشتر حساب می‌شوند. نشانش پایین منو دیده می‌شود.</span></div>\n<div class=\"tutCard\">💀 بعد از مرگ یک ثانیه صبر کن؛ بعد می‌توانی با تبلیغ یا ۱۵ الماس زنده شوی</div>\n<div class=\"tutCard\">⭐ شهاب‌های طلایی را لمس کن — هر ۳ تا یک صورت‌فلکی می‌سازد و آهنربا + الماس می‌دهد</div>\n<button id=\"closeHowto\" class=\"reward\">فهمیدم، بزن بریم</button>\n</div>\n</section>\n<section id=\"about\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>ℹ️ درباره بازی</h2>\n<div class=\"ageBadge\">مناسب همه سنین</div>\n<div class=\"sub\">دونده فضایی نسخه ۸.۰ — بازی آفلاین برای موبایل</div>\n<div class=\"tutCard\" style=\"text-align:right;\">حریم خصوصی: بخش اصلی بازی آفلاین است و پیشرفت و تنظیمات به‌صورت محلی روی دستگاه ذخیره می‌شوند. خریدهای مایکت و تبلیغات جایزه‌ای برای اتصال و پردازش درخواست‌ها به اینترنت و سرویس‌های مربوط نیاز دارند.</div>\n<div class=\"tutCard\" style=\"text-align:right;\">پرداخت‌های درون‌برنامه‌ای فقط از پنجره رسمی مایکت انجام می‌شوند. کالا پس از تأیید نتیجه خرید توسط بخش اندرویدی بازی فعال می‌شود؛ قیمت نهایی را پیش از تأیید در پنجره مایکت بررسی کن.</div>\n<div class=\"tutCard\" style=\"text-align:right;\">تبلیغ جایزه‌ای فقط وقتی پاداش می‌دهد که سرویس تبلیغات، تکمیل موفق تماشا را تأیید کند. در صورت نبود تبلیغ یا قطع اتصال، پاداشی ثبت نمی‌شود.</div>\n<div class=\"tutCard\" style=\"text-align:right;\">ویژگی‌ها: ۵ حالت بازی (بی‌نهایت، تایم‌اتک، سخت، غیرممکن و شفق قطبی)، ۶ رویداد کیهانی (بارش شهابی، شراره خورشیدی، یخ‌زدگی کیهانی، بارش الماسی، سیاهچاله مرگ و کهکشان جایزه)، ماموریت‌های روزانه و هفتگی، دستاوردهای مرحله‌ای، اسکین‌ها، هاله‌ها و افکت‌های متنوع.</div>\n<div class=\"tutCard\" style=\"text-align:right;\">این بازی برای همه سنین مناسب می‌باشد و هیچ محدودیتی ندارد.</div>\n<div class=\"tutCard\" style=\"text-align:right;\">پشتیبانی: پیشرفت روی حساب شما ذخیره می‌شود؛ اما از بخش «رمز بازیابی» در تنظیمات می‌توانی یک رمز بگذاری و یک «کد انتقال» بسازی. اگر بازی را حذف کنی یا بخواهی با گوشی دیگری وارد حسابت شوی، فقط با همان کد انتقال (که حتماً باید جایی ذخیره‌اش کرده باشی) و رمزت حسابت برمی‌گردد. امکان بازیابی با شماره تلفن هم در آینده اضافه خواهد شد.</div>\n<div class=\"tutCard\" style=\"text-align:right;\">نکته گرافیکی: افکت‌های بخش «شخصی‌سازی»، هر چه گرافیک بازی بیشتر و بالاتر باشد، بهتر و کامل‌تر دیده می‌شوند.</div>\n<div class=\"small\">نسخه ۸.۰ · E GAMES · مناسب همه سنین</div>\n<button class=\"secondary\" id=\"closeAbout\">بازگشت</button>\n</div>\n</section>\n<section id=\"shareSheet\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>📤 ارسال برای دوستان</h2>\n<div class=\"small\" style=\"margin-bottom:8px;\">یکی از برنامه‌ها را انتخاب کن؛ متن آماده است:</div>\n<textarea id=\"shareText\" class=\"recArea\" readonly style=\"min-height:120px;\"></textarea>\n<button class=\"premium hidden\" data-share=\"system\" id=\"shareSystemBtn\">📤 همه‌ی برنامه‌های گوشی</button>\n<div class=\"shareGrid\">\n<button class=\"reward\" data-share=\"telegram\">✈️ تلگرام</button>\n<button class=\"reward\" data-share=\"whatsapp\">💬 واتساپ</button>\n<button class=\"reward\" data-share=\"eitaa\">🟠 ایتا</button>\n<button class=\"reward\" data-share=\"bale\">🟢 بله</button>\n<button class=\"reward\" data-share=\"rubika\">🟣 روبیکا</button>\n<button class=\"reward\" data-share=\"splus\">🔵 سروش پلاس</button>\n<button class=\"reward\" data-share=\"shad\">🟡 شاد</button>\n<button class=\"reward\" data-share=\"igap\">🔴 آی‌گپ</button>\n<button class=\"reward\" data-share=\"gap\">⚪ گپ</button>\n<button class=\"secondary\" data-share=\"sms\">✉️ پیامک</button>\n<button class=\"secondary\" data-share=\"mail\">📧 ایمیل</button>\n<button class=\"premium\" data-share=\"copy\">📋 کپی متن</button>\n</div>\n<div class=\"small\" style=\"margin:6px 0;\">برای روبیکا، سروش پلاس، شاد، آی‌گپ و گپ، متن خودکار کپی می‌شود و برنامه (یا سایتِ رسمی‌اش برای نصب و ورود) باز می‌شود؛ متن را در گفتگو «Paste» کن.</div>\n<button class=\"secondary\" id=\"closeShareSheet\">بستن</button>\n</div>\n</section>\n<section id=\"supportSheet\" class=\"screen hidden\">\n<div class=\"panel\">\n<h2>📨 ارتباط با پشتیبانی</h2>\n<div class=\"small\" style=\"margin-bottom:8px;\">یکی از روش‌ها را انتخاب کن؛ پیام آماده است و فقط کافی است متنت را بنویسی:</div>\n<button class=\"premium\" id=\"supMail\">📧 باز کردن برنامه‌ی ایمیل گوشی</button>\n<button class=\"reward\" id=\"supGmail\">🌐 ارسال با Gmail (وب)</button>\n<button class=\"secondary\" id=\"supCopyAddr\">📋 کپی آدرس ایمیل</button>\n<button class=\"secondary\" id=\"supCopyMsg\">📋 کپی پیام آماده</button>\n<div class=\"small\" id=\"supAddr\" data-ascii dir=\"ltr\">erfanfirestar777@gmail.com</div>\n<div class=\"small\" style=\"margin:6px 0;\">اگر برنامه‌ی ایمیل باز نشد، آدرس را کپی کن و از هر برنامه‌ی ایمیلی برایمان بفرست.</div>\n<button class=\"secondary\" id=\"closeSupportSheet\">بستن</button>\n</div>\n</section>\n<!-- MODAL VIDEO AD -->\n<div id=\"adModal\" class=\"hidden\">\n<h3>📺 تبلیغ جایزه‌ای</h3>\n<p style=\"color:#ffaa00;\" id=\"adTimer\">در حال اتصال به سرویس تبلیغات…</p>\n<p class=\"small\">فقط پس از تأیید تکمیل تماشا، پاداش ثبت می‌شود.</p>\n</div>\n\n</div>";




const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
let W = innerWidth, H = innerHeight, DPR = 1;

let playing = false, last = 0, score = 0, runCoins = 0, runGems = 0, speed = 5;
let obstacleT = 0, coinT = 0, powerT = 0, boxT = 0, enemyT = 0, meteorT = 0, shootStarT = 0, gemCoinT = 0;

let obstacles = [], coins = [], gemCoins = [], powers = [], boxes = [], enemies = [], meteors = [], stars = [], planets = [], particlesArr = [], floaters = [], nebulae = [], shootingStars = [];
let player = null, magnetTime = 0, combo = 0, comboTimer = 0, dashTimer = 0, slowTimer = 0;
let shakeTime = 0, shakeMag = 0;

let gameMode = "classic"; // classic, time, hard
let modeTimer = 60;
let currentBiome = "classic"; 
let eventTimer = 0, eventActive = false;

// هماهنگ‌کننده‌ی مشترک رویدادها: جلوگیری از هم‌زمانی و زنجیره‌ی برنامه‌ریزی‌شده‌ی رویدادها.
// هر رویدادی که تمام می‌شود این مهلت را فعال می‌کند تا رویداد بعدی بلافاصله و به‌طور قابل‌پیش‌بینی از راه نرسد؛
// وقوع تصادفیِ پشت‌سرهم بعد از این مهلت اشکالی ندارد.
let eventCooldown = 0;
function anyEventBusy(){
    return eventActive || inBlackHole || blackHoleWarning || inRewardGalaxy || rewardGalaxyWarning ||
           solarFlare || solarWarn || iceStorm || iceWarn || diamondShowerActive;
}
function endEventCooldown(){ eventCooldown = 300; }

// Black hole rare event state
let inBlackHole = false, blackHoleWarning = false, blackHoleWarnT = 0, blackHoleCheckT = 0, blackHoleEntryScore = 0, bhSwirl = 0;

// Reward galaxy rare event state (کهکشان جایزه) - دنیای امن و پر از جایزه
let inRewardGalaxy = false, rewardGalaxyWarning = false, rewardGalaxyWarnT = 0, rewardGalaxyCheckT = 0, rewardGalaxyEntryScore = 0, rgSwirl = 0, pendingGuaranteedRG = false;
let pendingGuaranteedBH = false, pendingGuaranteedDS = false, pendingGuaranteedSF = false;

// Premium "phantom" skin after-image trail
let playerTrail = [];

// Diamond shower (بارش الماسی) - رویداد سبک و پرتکرارتر که مسیر رو با الماس پر می‌کنه
let diamondShowerActive = false, diamondShowerT = 0, diamondShowerCheckT = 0;

// پاورآپ جدید: امتیاز دوبل
let scoreMultTimer = 0;

// Perf: throttle localStorage writes during gameplay instead of writing every single frame
let saveThrottleT = 0;
// Perf: cache background/ground gradients instead of rebuilding every frame
let bgGradCache = { key: null, grad: null }, groundGradCache = { key: null, grad: null };

let soundEnabled = true, musicEnabled = true, audio = null, musicTimer = null, masterGain = null;

function defaultData(){
    return {
        coins:0, gems:0, xp:0, level:1, best:0, bestCoins:0,
        ship:false, turbo:false, shield:false, magnet:false,
        shipOn:false, turboOn:false, shieldOn:false, magnetOn:false,
        m1:0, m2:0, m3:0, m4:0, m5:0, m1Claim:false, m2Claim:false, m3Claim:false, m4Claim:false, m5Claim:false,
        pendingLevels:[], dailyDate:"", dailyClaimed:false, dailyDay:1,
        games:0, totalCoins:0, totalDistance:0, magnetUses:0, boxes:0, enemiesDodged:0, achClaimed:[], skin:"blue", bestCombo:0, novaUses:0,
        shieldPickups:0, ghostUses:0, slowTimeUses:0,
        tripleJump:false, tripleJumpOn:false, coinX2:false, coinX2On:false, luckyBox:false, luckyBoxOn:false,
        longMag:false, shieldStack:false, gemLuck:false,
        skinPurple:false, skinRed:false, skinRainbow:false,
        boostHead:0, boostShield:0, boostMag:0,
        wheelDate:"", wheelClaimed:false, totalGems:0, topScores:[]
    };
}

// ===== سخت‌سازی ذخیره‌سازی در برابر دستکاری/مود ساده =====
// داده دیگر به شکل JSON خوانا در localStorage ذخیره نمی‌شود؛ رمزگذاری سبک + چک‌سام دارد،
// پس ویرایش دستی مقادیر (مثلاً سکه/الماس) از طریق ابزارهای ساده باعث نامعتبرشدن ذخیره می‌شود.
const SEC_KEY = "SR83_x9K_qLm2_orbit";
function xorCipher(str, key){
    let out = "";
    for(let i=0;i<str.length;i++) out += String.fromCharCode(str.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    return out;
}
function simpleHash(str){
    let h = 0;
    for(let i=0;i<str.length;i++){ h = ((h<<5) - h + str.charCodeAt(i)) | 0; }
    return h;
}

/* ===== نسخه ۸.۰: سخت‌سازی ذخیره‌سازی =====
   فرمت جدید: رمزگذاری جریانی با nonce تصادفی (هر ذخیره متفاوت است) + چک‌سام ۵۳ بیتیِ کلیددار.
   فرمت قدیمی فقط برای «مهاجرتِ یک‌باره» خوانده می‌شود و بعد از اولین ذخیره‌ی جدید دیگر پذیرفته نمی‌شود. */
const SEC2 = ["SRv8", "k7Qz", "Lm9x", "Wt3p", "orbit", "Vb2n"].join("~");
function cyrb53(str, seed){
    let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
    for(let i = 0, ch; i < str.length; i++){ ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}
function ksStream(seedStr){
    let a = cyrb53(seedStr, 11) >>> 0;
    return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) & 255; };
}
function randNonce(){ const abc = "abcdefghijklmnopqrstuvwxyz0123456789"; let s = ""; for(let i = 0; i < 10; i++) s += abc[Math.floor(Math.random() * abc.length)]; return s; }
function encodeSave2(obj){
    const json = JSON.stringify(obj);
    const bin = unescape(encodeURIComponent(JSON.stringify({ d: json, c: cyrb53(json + SEC2, 7) })));
    const nonce = randNonce(), ks = ksStream(SEC2 + nonce); let out = "";
    for(let i = 0; i < bin.length; i++) out += String.fromCharCode(bin.charCodeAt(i) ^ ks());
    return "v2." + nonce + "." + btoa(out);
}
function decodeSave2(raw){
    const m = /^v2\.([a-z0-9]{10})\.([A-Za-z0-9+\/=]+)$/.exec(raw); if(!m) return null;
    const bin = atob(m[2]), ks = ksStream(SEC2 + m[1]); let plain = "";
    for(let i = 0; i < bin.length; i++) plain += String.fromCharCode(bin.charCodeAt(i) ^ ks());
    const parsed = JSON.parse(decodeURIComponent(escape(plain)));
    if(!parsed || typeof parsed.d !== "string" || cyrb53(parsed.d + SEC2, 7) !== parsed.c) return null;
    const obj = JSON.parse(parsed.d);
    return (obj && typeof obj === "object" && !Array.isArray(obj)) ? obj : null;
}
function encodeSave(obj){ try { return encodeSave2(obj); } catch(e){ return null; } }
function decodeSave(raw){
    try {
        if(typeof raw !== "string") return null;
        if(raw.slice(0, 3) === "v2.") return decodeSave2(raw);
        // فرمت قدیمی: فقط تا وقتی هنوز هیچ ذخیره‌ی جدیدی نوشته نشده (مهاجرت یک‌باره)
        if(localStorage.getItem("srLegacyOff")) return null;
        const payload = xorCipher(decodeURIComponent(escape(atob(raw))), SEC_KEY);
        const parsed = JSON.parse(payload);
        if(simpleHash(parsed.d + SEC_KEY) !== parsed.c) return null; // دستکاری‌شده یا خراب
        return JSON.parse(parsed.d);
    } catch(e){ return null; }
}
function migrateOldPlainSave(){
    try {
        const old = localStorage.getItem("spaceRunnerV82")||localStorage.getItem("spaceRunnerV81")||localStorage.getItem("spaceRunnerV80")||localStorage.getItem("spaceRunnerV70");
        return old ? JSON.parse(old) : null;
    } catch(e){ return null; }
}
/* ===== کد بازیابی حساب (فشرده‌شده، رمزنگاری‌شده با رمز کاربر) ===== */
function lzwPack(str){
    const dict = new Map();
    for(let i = 0; i < 256; i++) dict.set(String.fromCharCode(i), i);
    let w = "", next = 256; const out = [];
    for(let k = 0; k < str.length; k++){
        const ch = str[k], wc = w + ch;
        if(dict.has(wc)) w = wc;
        else { out.push(dict.get(w)); if(next < 4096) dict.set(wc, next++); w = ch; }
    }
    if(w !== "") out.push(dict.get(w));
    const bytes = [out.length >> 8, out.length & 255];
    for(let i = 0; i < out.length; i += 2){
        const a = out[i], b = (i + 1 < out.length) ? out[i + 1] : 0;
        bytes.push(a >> 4, ((a & 15) << 4) | (b >> 8), b & 255);
    }
    return bytes;
}
function lzwUnpack(bytes){
    const count = (bytes[0] << 8) | bytes[1], codes = [];
    for(let i = 2; i + 2 < bytes.length + 0 && codes.length < count; i += 3){
        const a = (bytes[i] << 4) | (bytes[i + 1] >> 4), b = ((bytes[i + 1] & 15) << 8) | bytes[i + 2];
        codes.push(a); if(codes.length < count) codes.push(b);
    }
    if(!codes.length) throw new Error("empty");
    const dict = [];
    for(let i = 0; i < 256; i++) dict[i] = String.fromCharCode(i);
    let w = dict[codes[0]]; if(w === undefined) throw new Error("bad");
    let out = w;
    for(let i = 1; i < codes.length; i++){
        const k = codes[i]; let entry;
        if(dict[k] !== undefined) entry = dict[k];
        else if(k === dict.length) entry = w + w[0];
        else throw new Error("bad");
        out += entry;
        if(dict.length < 4096) dict.push(w + entry[0]);
        w = entry;
    }
    return out;
}
function recKeyBytes(key){ const b = []; for(let i = 0; i < key.length; i++) b.push(key.charCodeAt(i) & 255, (key.charCodeAt(i) >> 8) & 255); return b; }
function b64urlEncode(bytes){ let bin = ""; for(let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]); return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); }
function b64urlDecode(str){
    let t = str.replace(/-/g, "+").replace(/_/g, "/"); while(t.length % 4) t += "=";
    const bin = atob(t), out = []; for(let i = 0; i < bin.length; i++) out.push(bin.charCodeAt(i)); return out;
}
function generateRecoveryCode(password){
    try {
        const key = password + SEC_KEY, def = defaultData(), slim = {};
        Object.keys(data).forEach(k => { if(JSON.stringify(data[k]) !== JSON.stringify(def[k])) slim[k] = data[k]; });
        const json = JSON.stringify(slim);
        const payload = simpleHash(json + key) + "|" + unescape(encodeURIComponent(json));
        const packed = lzwPack(payload), kb = recKeyBytes(key);
        return "SR3-" + b64urlEncode(packed.map((b, i) => b ^ kb[i % kb.length]));
    } catch(e){ return null; }
}
function restoreFromRecoveryCode(code, password){
    try {
        const key = password + SEC_KEY;
        const clean = String(code).replace(/\s+/g, "").replace(/^SR3-/, "");
        const kb = recKeyBytes(key), bytes = b64urlDecode(clean).map((b, i) => b ^ kb[i % kb.length]);
        const payload = lzwUnpack(bytes), cut = payload.indexOf("|");
        if(cut < 1) return null;
        const chk = payload.slice(0, cut), json = decodeURIComponent(escape(payload.slice(cut + 1)));
        if(String(simpleHash(json + key)) !== chk) return null;
        return Object.assign(defaultData(), JSON.parse(json));
    } catch(e){ return null; }
}
function copyRecoveryText(ta){
    const txt = ta.value, manual = () => toast("کد انتخاب شد؛ انگشتت را نگه دار و «کپی» را بزن");
    const fallback = () => {
        try { ta.focus(); ta.select(); ta.setSelectionRange(0, txt.length); const ok = document.execCommand && document.execCommand("copy"); if(ok) toast("✅ کد کپی شد"); else manual(); } catch(e){ manual(); }
    };
    try {
        if(navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(() => toast("✅ کد کپی شد")).catch(fallback);
        else fallback();
    } catch(e){ fallback(); }
}
function applyTheme(){
    // تم روشن حذف شد؛ بازی همیشه با ظاهر تاریک (سیاهچاله‌ای) اجرا می‌شود
    data.theme = "dark";
    const root = document.getElementById("sr-root");
    if(root) root.removeAttribute("data-theme");
}
async function requestMyketListing(){
    if(nativeBridgeAvailable()){
        try{
            const result = await callSpaceRunnerNative("openMyketListing", {}, 15000);
            if(result.ok === true && result.opened === true){
                data.ratePromptOpened = true; saveData(); updateRateBoxes();
                toast("صفحه دونده فضایی در مایکت باز شد؛ در صورت تمایل امتیاز و نظرت را ثبت کن.");
                return;
            }
            toast("باز کردن صفحه مایکت ناموفق بود؛ دوباره تلاش کن.");
            return;
        }catch(e){ toast("اتصال به مایکت برای باز کردن صفحه برقرار نشد."); return; }
    }
    const packageName = configuredPackageName();
    if(!packageName){
        toast("شناسه بسته اندروید هنوز در تنظیمات نسخه نهایی ثبت نشده است."); return;
    }
    try{
        const appLink = "myket://details?id=" + encodeURIComponent(packageName);
        const webFallback = "https://myket.ir/app/" + encodeURIComponent(packageName);
        data.ratePromptOpened = true; saveData(); updateRateBoxes();
        window.location.href = appLink;
        // اگر برنامه مایکت باز نشد، صفحه وب همان برنامه به‌عنوان مسیر جایگزین باز می‌شود.
        setTimeout(() => {
            if(document.visibilityState === "visible") window.location.href = webFallback;
        }, 1200);
        toast("صفحه بازی در مایکت باز می‌شود؛ امتیاز دلخواهت را ثبت کن.");
    }catch(e){ toast("باز کردن مایکت ناموفق بود."); }
}

function updateRateBoxes(){
    const shouldShow = !data.rated && !data.ratePromptOpened && (data.games||0) >= 6;
    ["rateBoxOver","rateBoxShop","rateBoxMissions"].forEach(id => {
        const n = el(id);
        if(n) n.classList.toggle("hidden", !shouldShow);
    });
    const showInvite = !data.invited && (data.games||0) >= 6;
    ["inviteBoxOver","inviteBoxShop","inviteBoxMissions"].forEach(id => { const n = el(id); if(n) n.classList.toggle("hidden", !showInvite); });
    const inviteSettings = el("inviteBoxSettings"); if(inviteSettings) inviteSettings.classList.remove("hidden");
    const settingsBox = el("rateBoxSettings");
    if(settingsBox){
        const btn = el("rateYesSettings");
        if(btn) btn.textContent = "⭐ امتیاز دادن به بازی";
    }
}

let data;
let lastGoodRaw = null, legacyOffDone = false;
try {
    const raw = localStorage.getItem("spaceRunnerV83");
    if(raw){
        data = decodeSave(raw);
        if(data){ lastGoodRaw = raw; }
        else {   // ذخیره‌ی اصلی خراب یا دستکاری شده؛ تلاش برای بازیابی از آخرین پشتیبانِ سالم
            const bk = localStorage.getItem("spaceRunnerV83b");
            data = bk ? decodeSave(bk) : null;
            if(data) lastGoodRaw = bk; else data = defaultData();
        }
    } else {
        // مهاجرت فقط یک‌بار از نسخه‌های قدیمی (بدون چک‌سام) مجاز است؛ بعد از آن نشانه‌ی مهاجرت ثبت می‌شود
        const alreadyMigrated = localStorage.getItem("srM83");
        data = (alreadyMigrated ? null : migrateOldPlainSave()) || defaultData();
        try {
            localStorage.setItem("srM83", "1");
            localStorage.removeItem("spaceRunnerV82");
            localStorage.removeItem("spaceRunnerV81");
            localStorage.removeItem("spaceRunnerV80");
            localStorage.removeItem("spaceRunnerV70");
        } catch(e){}
    }
} catch(e){
    data = defaultData(); // ذخیره‌سازی خراب بود، برای جلوگیری از کرش با مقدار پیش‌فرض شروع می‌کنیم
}
// پاک‌سازی مقادیر غیرمنطقی (NaN، منفی، یا بسیار بزرگ) که نشانه‌ی دستکاری یا خرابی داده هستند
function sanitizeLoadedData(){
    const caps = { coins:1e9, gems:1e7, totalCoins:1e11, totalGems:1e9, level:1000, best:1e8, games:1e7 };
    Object.keys(caps).forEach(k => {
        const v = data[k];
        if(typeof v !== "number" || !Number.isFinite(v) || v < 0) data[k] = 0;
        else if(v > caps[k]) data[k] = 0;
    });
    if(data.level < 1) data.level = 1;
    // آمار: فقط عددهای معتبر و نامنفی
    if(!data.st || typeof data.st !== "object" || Array.isArray(data.st)) data.st = {};
    Object.keys(data.st).forEach(k => {
        const v = data.st[k];
        if(k === "modeGames" || k === "modeBest"){
            if(!v || typeof v !== "object" || Array.isArray(v)){ data.st[k] = {}; return; }
            Object.keys(v).forEach(m => { if(["classic","time","hard","impossible","aurora"].indexOf(m) < 0 || typeof v[m] !== "number" || !Number.isFinite(v[m]) || v[m] < 0 || v[m] > 1e12) delete v[m]; });
        } else if(typeof v !== "number" || !Number.isFinite(v) || v < 0 || v > 1e12) delete data.st[k];
    });
}
sanitizeLoadedData();

data.m4 = data.m4 || 0; data.m4Claim = data.m4Claim || false;
data.m5 = data.m5 || 0; data.m5Claim = data.m5Claim || false;
data.novaUses = data.novaUses || 0;
data.tripleJump = data.tripleJump || false; data.tripleJumpOn = data.tripleJumpOn || false;
data.coinX2 = data.coinX2 || false; data.coinX2On = data.coinX2On || false;
data.luckyBox = data.luckyBox || false; data.luckyBoxOn = data.luckyBoxOn || false;
data.longMag = data.longMag || false; data.shieldStack = data.shieldStack || false; data.gemLuck = data.gemLuck || false;
data.skinPurple = data.skinPurple || false; data.skinRed = data.skinRed || false; data.skinRainbow = data.skinRainbow || false;
data.boostHead = data.boostHead || 0; data.boostShield = data.boostShield || 0; data.boostMag = data.boostMag || 0;
data.wheelDate = data.wheelDate || ""; data.wheelClaimed = data.wheelClaimed || false; data.wheelAdDone = data.wheelAdDone || false; data.wheelAdCredit = data.wheelAdCredit || 0;
data.totalGems = data.totalGems || 0;
data.topScores = data.topScores || [];
data.dailyDay = data.dailyDay || 1;
data.enemiesDodged = data.enemiesDodged || 0;
data.missionDate = data.missionDate || "";
data.m6 = data.m6 || 0; data.m6Claim = data.m6Claim || false;
data.m7 = data.m7 || 0; data.m7Claim = data.m7Claim || false;
data.m8 = data.m8 || 0; data.m8Claim = data.m8Claim || false;
data.m9 = data.m9 || 0; data.m9Claim = data.m9Claim || false;
data.achTier = data.achTier || {};
data.blackHoleVisits = data.blackHoleVisits || 0;
data.rewardGalaxyVisits = data.rewardGalaxyVisits || 0;
data.guaranteedRewardGalaxy = data.guaranteedRewardGalaxy || false;
// نئونی و طلایی قبلاً رایگان بودند؛ اگر کسی از قبل انتخابشون کرده بود همچنان مالکش می‌ماند (منصفانه برای بازیکن‌های قدیمی)
data.skinGold = (data.skinGold !== undefined) ? data.skinGold : (data.skin === "gold");
data.skinCyan = (data.skinCyan !== undefined) ? data.skinCyan : (data.skin === "cyan");
data.skinNova = data.skinNova || false;
data.skinCosmicKing = data.skinCosmicKing || false;
data.skinPhantom = data.skinPhantom || false;
data.vip = data.vip || false;
data.wheelClaimed2 = data.wheelClaimed2 || false;
data.diamondShowers = data.diamondShowers || 0;
data.autoCollect = data.autoCollect || false; data.autoCollectOn = data.autoCollectOn || false;
data.noAds = data.noAds || false;
data.envFilter = data.envFilter || "none";
data.filterOwned = data.filterOwned || {};
data.trailColor = data.trailColor || "default";
data.trailOwned = data.trailOwned || {};
data.jumpEffect = data.jumpEffect || "default";
data.jumpEffectOwned = data.jumpEffectOwned || {};
data.guaranteedBlackHole = data.guaranteedBlackHole || false;
data.guaranteedDiamondShower = data.guaranteedDiamondShower || false;
data.weeklyDate = data.weeklyDate || "";
data.wm1 = data.wm1 || 0; data.wm1Claim = data.wm1Claim || false;
data.wm2 = data.wm2 || 0; data.wm2Claim = data.wm2Claim || false;
data.wm3 = data.wm3 || 0; data.wm3Claim = data.wm3Claim || false;
data.groundTheme = data.groundTheme || "none";
data.groundThemeOwned = data.groundThemeOwned || {};
data.aura = data.aura || "none";
data.auraOwned = data.auraOwned || {};
data.startFx = data.startFx || "none";
data.startFxOwned = data.startFxOwned || {};
data.dodgeChance = data.dodgeChance || false; data.dodgeChanceOn = data.dodgeChanceOn || false;
data.fastPower = data.fastPower || false; data.fastPowerOn = data.fastPowerOn || false;

const dailyRewards = [
    { coins: 200, gems: 4 },
    { coins: 300, gems: 6 },
    { coins: 400, gems: 6 },
    { coins: 450, gems: 9 },
    { coins: 550, gems: 10 },
    { coins: 650, gems: 13 },
    { coins: 800, gems: 20 }
];

/* فیلترهای رنگی محیط - تجربه‌ی بصری قابل خرید، بدون تاثیر روی گیم‌پلی */
const envFilters = [
    { key:"sunset", name:"طلوع صورتی", icon:"🌅", color:"rgba(255,120,180,0.10)", price:55 },
    { key:"night", name:"شب ارغوانی", icon:"🌌", color:"rgba(130,60,255,0.10)", price:55 },
    { key:"emerald", name:"کهکشان زمردی", icon:"💚", color:"rgba(40,220,140,0.10)", price:55 }
];
/* رنگ دنباله‌ی سفینه - جدا از اسکین، یک لایه‌ی شخصی‌سازی دیگر */
const trailColorDefs = [
    { key:"cyan", name:"دنباله یخی", icon:"🧊", price:48 },
    { key:"pink", name:"دنباله صورتی", icon:"🌸", price:48 },
    { key:"green", name:"دنباله سمی", icon:"☄️", price:48 }
];
/* افکت ذرات هنگام پرش */
const jumpEffectDefs = [
    { key:"ice", name:"یخی", icon:"❄️", price:38 },
    { key:"stars", name:"ستاره‌ای", icon:"⭐", price:38 }
];

/* زمین‌های ویژه - فقط با پرداخت واقعی، صرفاً بصری، خیلی خوشگل! هر کدوم گرادیان و افکت تزئینی مخصوص خودشون رو دارن */
const groundThemes = [
    { key:"ocean", name:"اقیانوس نور", icon:"🌊", price:55000, top:"#001a33", bottom:"#003d5c", glow:"#00d9ff", accent:"#5ce1ff", deco:"ripple" },
    { key:"diamond", name:"الماس", icon:"💎", price:45000, top:"#0d1b2e", bottom:"#1b3a5c", glow:"#bfefff", accent:"#ffffff", deco:"sparkle" },
    { key:"lava", name:"گدازه طلایی", icon:"🌋", price:50000, top:"#3d0f00", bottom:"#661a00", glow:"#ff9500", accent:"#ffd447", deco:"ember" },
    { key:"milkyway", name:"راه شیری", icon:"🌌", price:60000, top:"#1a0a2e", bottom:"#2e1150", glow:"#c78bff", accent:"#ff8bd9", deco:"stars" },
    { key:"garden", name:"باغ بهشتی", icon:"🌸", price:70000, top:"#1a2e1a", bottom:"#2e4a2e", glow:"#ffb6d9", accent:"#9dffb0", deco:"petals" }
];

/* هاله‌ی همراه - افکت بصری دائمی دور سفینه، مستقل از اسکین انتخابی */
const auraDefs = [
    { key:"pulse", name:"هاله ضربان‌دار", icon:"💙", price:62, currency:"gems" },
    { key:"orbit", name:"هاله مداری", icon:"🪐", price:30000, currency:"irl" },
    { key:"rainbow", name:"هاله رنگین‌کمانی", icon:"🌈", price:50000, currency:"irl" }
];

/* افکت ورود به بازی - یک جلوه‌ی کوتاه هنگام زدن دکمه‌ی شروع */
const startFxDefs = [
    { key:"warp", name:"جهش سرعت نور", icon:"🌀", price:62 },
    { key:"flash", name:"فلاش نورانی", icon:"✨", price:48 }
];

function saveData(){
    try{
        const enc = encodeSave(data);
        if(enc){
            if(lastGoodRaw) localStorage.setItem("spaceRunnerV83b", lastGoodRaw);   // پشتیبانِ آخرین ذخیره‌ی سالم
            localStorage.setItem("spaceRunnerV83", enc); lastGoodRaw = enc;
            if(!legacyOffDone){ localStorage.setItem("srLegacyOff", "1"); legacyOffDone = true; }
        }
    }catch(e){}
}
function save(){ saveData(); updateUI(); }
const PRICE = {
    coinX2:210, luckyBox:135, gemLuck:170, tripleJump:340, quadJump:850, dodgeChance:300, nearMiss:110,
    filter:95, trail:68, jumpFx:55, auraPulse:85, startWarp:85, startFlash:68,
    skinPurple:68, skinRed:68, skinRainbow:195, skinComet:95, skinAurora:95, skinNeptune:115, skinSaturn:125,
    ticketBH:95, ticketRG:110, ticketDS:65, ticketIce:55, ticketFlare:55,
    revive:15, doubleDaily:15, doubleLevel:10, streakShield:25,
    auroraEntry:3000
};
const GAME_VERSION = "8.0";   // نسخه‌ی نمایشی/داخلی بازی (کلید ذخیره‌سازی عمداً ثابت مانده تا پیشرفت بازیکن‌ها نپرد)
function el(id){ return document.getElementById(id); }

/* فرمت دستی عدد به تومان فارسی، بدون وابستگی به Intl/toLocaleString (که ممکنه در بعضی وب‌ویوها موجود نباشه) */
function formatDistance(m){
    const meters = Math.floor(m||0);
    const faDigits = ["۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"];
    if(meters < 1000) return faPrice(meters) + " متر";
    const km = (meters/1000).toFixed(1);
    const out = km.toString().split("").map(ch => (ch>="0"&&ch<="9") ? faDigits[+ch] : (ch === "." ? "٫" : ch)).join("");
    return out + " کیلومتر";
}
function faPrice(n){
    const faDigits = ["۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"];
    const withCommas = Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    let out = "";
    for(let i=0;i<withCommas.length;i++){
        const ch = withCommas[i];
        out += (ch >= "0" && ch <= "9") ? faDigits[+ch] : ch;
    }
    return out;
}
function show(id){ el(id).classList.remove("hidden"); }
function hide(id){ el(id).classList.add("hidden"); }

/* پل ارتباطی امنِ وب‌گیم با پوسته‌ی اندروید.
   هیچ خرید یا پاداشی در جاوااسکریپت صرفاً با تایمر تأیید نمی‌شود؛ نتیجه باید از لایه‌ی بومی برگردد. */
let srNativeRequestSeq = 0;
const srNativePending = new Map();
function nativeBridgeAvailable(){
    return !!(window.SpaceRunnerNative && typeof window.SpaceRunnerNative.postMessage === "function");
}
function callSpaceRunnerNative(action, payload, timeoutMs){
    return new Promise((resolve, reject) => {
        if(!nativeBridgeAvailable()){
            const error = new Error("native_bridge_unavailable"); error.code = "NATIVE_BRIDGE_UNAVAILABLE"; reject(error); return;
        }
        const requestId = "sr_" + Date.now().toString(36) + "_" + (++srNativeRequestSeq).toString(36);
        const timeout = Math.max(1000, Number(timeoutMs) || 30000);
        const timer = setTimeout(() => {
            srNativePending.delete(requestId);
            const error = new Error("native_request_timeout"); error.code = "NATIVE_REQUEST_TIMEOUT"; reject(error);
        }, timeout);
        srNativePending.set(requestId, { resolve, reject, timer, action });
        try{
            window.SpaceRunnerNative.postMessage(JSON.stringify({
                protocol: 1,
                requestId,
                action: String(action || ""),
                payload: payload && typeof payload === "object" ? payload : {}
            }));
        }catch(error){
            clearTimeout(timer); srNativePending.delete(requestId);
            error.code = error.code || "NATIVE_POST_FAILED"; reject(error);
        }
    });
}
window.onSpaceRunnerNativeResult = function(requestId, rawResult){
    const pending = srNativePending.get(String(requestId || ""));
    if(!pending) return;
    clearTimeout(pending.timer); srNativePending.delete(String(requestId));
    let result = rawResult;
    if(typeof rawResult === "string"){
        try { result = JSON.parse(rawResult); }
        catch(e){ pending.reject(new Error("native_invalid_json")); return; }
    }
    if(!result || typeof result !== "object") { pending.reject(new Error("native_invalid_result")); return; }
    pending.resolve(result);
};
function storeSku(...parts){
    const clean = parts.map(part => String(part).toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "")).filter(Boolean);
    return "sr_" + clean.join("_");
}
function securePurchaseToken(length = 18){
    const alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
    try{
        const bytes = new Uint8Array(Math.max(12, Math.min(32, length)));
        window.crypto.getRandomValues(bytes);
        return Array.from(bytes, value => alphabet[value % alphabet.length]).join("");
    }catch(e){
        // فقط شناسه‌ی هم‌بستگی است؛ اعتبار خرید در لایه‌ی بومی و امضای مایکت بررسی می‌شود.
        return Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
    }
}
function configuredPackageName(){
    const cfg = window.SPACE_RUNNER_CONFIG && window.SPACE_RUNNER_CONFIG.packageName;
    const meta = document.querySelector('meta[name="space-runner-package"]');
    return String(cfg || (meta && meta.content) || "").trim();
}

function toast(text){
    const box = el("toast");
    box.textContent = text;
    box.style.opacity = 1;
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { box.style.opacity = 0; }, 1500);
}

function flashScreen(){
    const fl = el("flashOverlay");
    fl.style.opacity = 0.4;
    setTimeout(() => { fl.style.opacity = 0; }, 120);
}

function pulse(id){
    const b = el(id);
    if(!b) return;
    b.classList.add("pulse");
    setTimeout(() => b.classList.remove("pulse"), 160);
}

function shake(mag, dur){ shakeMag = Math.max(shakeMag, mag); shakeTime = Math.max(shakeTime, dur); }

function today(){ return new Date().toISOString().slice(0,10); }

function checkDay(){ 
    if(data.dailyDate !== today()){ 
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yStr = yesterday.toISOString().slice(0,10);
        
    if(data.dailyDate !== yStr && data.dailyDate !== ""){
            if(data.streakShield){
                data.streakShield = false;
                toast("🛡️ محافظ زنجیره فعال شد — زنجیره حفظ شد");
            } else {
                data.dailyDay = 1; // Missed a day, reset streak
            }
        }
        data.dailyDate = today();
        data.dailyClaimed = false;
        data.dailyDoubled = false;
        save(); 
    } 
}

function checkWheelDay(){ if(data.wheelDate !== today()){ data.wheelDate = today(); data.wheelClaimed = false; data.wheelClaimed2 = false; data.wheelAdDone = false; save(); } }

/* ================================================================
   جدول مرکزی ماموریت‌ها (هدف، سکه، الماس) — نوار پیشرفت، دکمه‌ی دریافت، متن جایزه و خود جایزه همه از همین جدول می‌آیند
   تا هیچ‌وقت با هم ناهماهنگ نشوند. جایزه‌ی روزانه‌ها کمی بیشتر شد و ماموریت‌های سخت‌تر بیشتر از بقیه جایزه می‌دهند.
   ================================================================ */
const DAILY_DEFS = {
    m1: [90, 120, 3],      // سکه جمع کردن
    m2: [3500, 150, 8],    // رسیدن به امتیاز (سخت‌تر)
    m3: [5, 120, 0],       // آهنربا
    m4: [4, 0, 6],         // بمب نواختر
    m5: [18, 300, 3],      // الماس فضایی (سخت‌تر)
    m6: [70, 130, 0],      // پرش
    m7: [3, 0, 4],         // بازی
    m8: [1, 250, 4],       // سیاهچاله (رویداد تصادفی)
    m9: [1, 150, 8],       // کهکشان جایزه (رویداد کمیاب)
    m10: [15, 150, 6],     // زنجیره‌ی ۱۵
    m11: [1, 700, 6]       // یک دور شفق قطبی (ورودی ۳۰۰۰ سکه دارد)
};
const WEEKLY_DEFS = { wm1: [200000, 3000, 40], wm2: [200, 2000, 30], wm3: [10000, 2500, 35] };
const DAILY_BONUS = { coins: 1000, gems: 25 };     // همه‌ی ماموریت‌های روزانه در همان روز
const WEEKLY_BONUS = { coins: 5000, gems: 60 };    // هر سه ماموریت هفتگی در همان هفته
function rewardText(c, g){ return (c ? faPrice(c) + " سکه" : "") + (c && g ? " + " : "") + (g ? faNum(g) + " الماس" : ""); }
function claimBtnId(k){ return k.charAt(0) === "w" ? "claimWm" + k.slice(2) : "claimM" + k.slice(1); }
function missionDone(k){ const d = DAILY_DEFS[k] || WEEKLY_DEFS[k]; return (data[k] || 0) >= d[0]; }
function dailyDoneCount(){ return Object.keys(DAILY_DEFS).filter(missionDone).length; }
function weeklyDoneCount(){ return Object.keys(WEEKLY_DEFS).filter(missionDone).length; }
function giveReward(c, g){ if(c){ data.coins += c; } if(g) addGems(g); }
function refreshMissionUI(){
    const upd = (defs) => Object.keys(defs).forEach(k => {
        const t = defs[k][0], v = data[k] || 0, e = el(k), b = el(k + "bar"), cb = el(claimBtnId(k));
        if(e) e.textContent = faPrice(Math.min(v, t)) + "/" + faPrice(t);
        if(b) b.style.width = Math.min(100, v / t * 100) + "%";
        if(cb) cb.classList.toggle("hidden", !(v >= t && !data[k + "Claim"]));
    });
    upd(DAILY_DEFS); upd(WEEKLY_DEFS);
    const dn = dailyDoneCount(), dTot = Object.keys(DAILY_DEFS).length, wn = weeklyDoneCount(), wTot = Object.keys(WEEKLY_DEFS).length;
    if(el("dBonusTxt")){ el("dBonusTxt").textContent = faNum(dn) + "/" + faNum(dTot); el("dBonusBar").style.width = (dn / dTot * 100) + "%"; el("claimDailyBonus").classList.toggle("hidden", !(dn >= dTot && !data.dailyBonusClaim)); el("dBonusDone").classList.toggle("hidden", !data.dailyBonusClaim); }
    if(el("wBonusTxt")){ el("wBonusTxt").textContent = faNum(wn) + "/" + faNum(wTot); el("wBonusBar").style.width = (wn / wTot * 100) + "%"; el("claimWeeklyBonus").classList.toggle("hidden", !(wn >= wTot && !data.weeklyBonusClaim)); el("wBonusDone").classList.toggle("hidden", !data.weeklyBonusClaim); }
}
function fillMissionRewardTexts(){
    const put = (defs, label) => Object.keys(defs).forEach(k => { const cb = el(claimBtnId(k)); if(!cb) return; const sp = cb.parentElement.querySelector("span.small"); if(sp) sp.textContent = label + rewardText(defs[k][1], defs[k][2]); });
    put(DAILY_DEFS, "پاداش: "); put(WEEKLY_DEFS, "پاداش بزرگ: ");
    if(el("dBonusReward")) el("dBonusReward").textContent = "🎁 " + rewardText(DAILY_BONUS.coins, DAILY_BONUS.gems);
    if(el("wBonusReward")) el("wBonusReward").textContent = "🎁 " + rewardText(WEEKLY_BONUS.coins, WEEKLY_BONUS.gems);
}
function checkMissionDay(){
    if(data.missionDate !== today()){
        data.missionDate = today();
        data.m1=0; data.m2=0; data.m3=0; data.m4=0; data.m5=0; data.m6=0; data.m7=0; data.m8=0; data.m9=0; data.m10=0; data.m11=0;
        data.m1Claim=false; data.m2Claim=false; data.m3Claim=false; data.m4Claim=false; data.m5Claim=false; data.m6Claim=false; data.m7Claim=false; data.m8Claim=false; data.m9Claim=false; data.m10Claim=false; data.m11Claim=false;
        data.challengeClaimed = false; data.dailyBonusClaim = false;
        save();
    }
}

function getWeekKey(){
    const d = new Date();
    const firstJan = new Date(d.getFullYear(), 0, 1);
    const week = Math.ceil((((d - firstJan) / 86400000) + firstJan.getDay() + 1) / 7);
    return d.getFullYear() + "-W" + week;
}
function checkWeeklyMission(){
    if(data.weeklyDate !== getWeekKey()){
        data.weeklyDate = getWeekKey();
        data.wm1 = 0; data.wm1Claim = false;
        data.wm2 = 0; data.wm2Claim = false;
        data.wm3 = 0; data.wm3Claim = false; data.weeklyBonusClaim = false;
        save();
    }
}
function needXP(){ return 100 + (data.level - 1) * 35; }

function addXP(amount){
    data.xp += amount;
    while(data.xp >= needXP()){
        data.xp -= needXP();
        data.level++;
        data.pendingLevels.push(data.level);
    }
    saveData();
}

function addGems(n){ 
    data.gems += n; 
    data.totalGems += n; 
    saveData(); 
}

function setMode(m){
    gameMode = m; currentBiome = m; bioReset();
    ["modeClassic","modeTime","modeHard","modeImpossible","modeAurora"].forEach(id => { const n=el(id); if(n) n.classList.remove("active"); });
    if(m==="classic") {
        el("modeClassic").classList.add("active");
        el("modeDesc").textContent = "حالت استاندارد بی‌نهایت فضایی";
    }
    if(m==="time") {
        el("modeTime").classList.add("active");
        el("modeDesc").textContent = "⏳ تایم‌اتک (۶۰ ثانیه دوام بیاور و ۳۰۰ سکه + ۵ الماس جایزه بگیر!)";
    }
    if(m==="hard") {
        el("modeHard").classList.add("active");
        el("modeDesc").textContent = "💣 سخت — سرعت بازی خیلی سریع‌تر افزایش می‌یابد";
    }
    if(m==="impossible") {
        const im = el("modeImpossible"); if(im) im.classList.add("active");
        el("modeDesc").textContent = "💀 غیرممکن — فقط برای حرفه‌ای‌های واقعی! سرعتی وحشتناک از همان ثانیه‌ی اول و دشمنان و موانع بیشتر";
    }
    if(m==="aurora") {
        const a = el("modeAurora"); if(a) a.classList.add("active");
        el("modeDesc").textContent = "🌌 شفق قطبی — سکه‌ها، الماس‌ها، جایزه‌ها و پاورآپ‌های بسیار زیادی دارد · ورودی ۳۰۰۰ سکه";
    }
}

async function playAd(rewardCallback, kind){
    const placementId = String(kind || "generic-reward");
    if(typeof rewardCallback !== "function"){ toast("پاداش نامعتبر است"); return; }
    if(adBusy){ toast("درخواست قبلی هنوز در حال انجام است"); return; }
    if(placementId === "gems"){
        checkAdGemDay();
        if((data.adGemsToday || 0) >= 6){ toast("سهمیه امروز تمام شد — ۶ بار در روز"); return; }
    }
    adBusy = true;
    const modal = el("adModal"), status = el("adTimer");
    const finishReward = (wasRealAd) => {
        if(placementId === "gems"){
            checkAdGemDay();
            data.adGemsToday = Math.min(6, (data.adGemsToday || 0) + 1);
        }
        if(wasRealAd) statInc("ads");
        statInc("adRewards");
        saveData();
        updateExtraUI();
        rewardCallback();
    };
    try{
        // حذف تبلیغات فقط پاداش‌های غیرِ ادامه‌ی اجباری را بدون نمایش ویدیو آزاد می‌کند.
        if(hasNoAds() && placementId !== "continue-revive"){
            finishReward(false);
            return;
        }
        if(!nativeBridgeAvailable()){
            toast("تبلیغ واقعی هنوز به نسخه اندرویدی متصل نشده است؛ پاداشی ثبت نشد.");
            return;
        }
        if(modal) modal.classList.remove("hidden");
        if(status) status.textContent = "در حال اتصال به سرویس تبلیغات…";
        const result = await callSpaceRunnerNative("showRewardedAd", { placementId }, 150000);
        if(result.ok === true && result.status === "completed" && result.rewardEarned === true){
            if(modal) modal.classList.add("hidden");
            finishReward(true);
        }else if(result.status === "unavailable" || result.errorCode === "NO_FILL"){
            toast("فعلاً تبلیغی در دسترس نیست؛ بعداً دوباره امتحان کن.");
        }else if(result.status === "cancelled"){
            toast("تبلیغ کامل تماشا نشد؛ پاداشی داده نشد.");
        }else{
            toast("تماشای تبلیغ تأیید نشد؛ پاداشی داده نشد.");
        }
    }catch(error){
        if(error && error.code === "NATIVE_BRIDGE_UNAVAILABLE") toast("سرویس تبلیغات در این نسخه نصب نیست.");
        else if(error && error.code === "NATIVE_REQUEST_TIMEOUT") toast("پاسخ سرویس تبلیغات دریافت نشد؛ پاداشی ثبت نشد.");
        else toast("اتصال به تبلیغات ناموفق بود؛ پاداشی ثبت نشد.");
    }finally{
        if(modal) modal.classList.add("hidden");
        adBusy = false;
        updateExtraUI();
    }
}

/* ===================== AUDIO ===================== */
/* صدا: طبق درخواست کاربر، ولوم آهنگ و افکت‌های صوتی همزمان بالا برده شد */
const SOUND_BOOST = 1.7; // ضریب تقویت روی تک‌تک نت‌ها/افکت‌ها (هم آهنگ هم SFX از همین عبور می‌کنند)

function initAudio(){
    if(!audio){
        audio = new (window.AudioContext || window.webkitAudioContext)();
        masterGain = audio.createGain();
        masterGain.gain.value = 2.2; // تقویت کلی خروجی صدا
        masterGain.connect(audio.destination);
    }
    if(audio.state === "suspended") audio.resume();
    if(musicEnabled) startMusic();
}

function tone(frequency, duration=.09, type="sine", volume=.05){
    if(!soundEnabled || !audio || audio.state !== "running") return;
    volume = volume * SOUND_BOOST;
    try {
        const oscillator = audio.createOscillator();
        const gain = audio.createGain();
        const now = audio.currentTime;
        oscillator.type = type;
        oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(volume, now);
        gain.gain.exponentialRampToValueAtTime(.001, now + duration);
        oscillator.connect(gain);
        gain.connect(masterGain);
        oscillator.start(now);
        oscillator.stop(now + duration);
    } catch(e){}
}

function hat(volume=.03){
    if(!soundEnabled || !audio || audio.state !== "running") return;
    volume = volume * SOUND_BOOST;
    try {
        const bufferSize = audio.sampleRate * 0.03;
        const buffer = audio.createBuffer(1, bufferSize, audio.sampleRate);
        const data0 = buffer.getChannelData(0);
        for(let i=0;i<bufferSize;i++) data0[i] = (Math.random()*2-1) * (1 - i/bufferSize);
        const src = audio.createBufferSource(); src.buffer = buffer;
        const filt = audio.createBiquadFilter(); filt.type = "highpass"; filt.frequency.value = 6000;
        const g = audio.createGain(); g.gain.value = volume;
        src.connect(filt); filt.connect(g); g.connect(masterGain);
        src.start();
    } catch(e){}
}

function kick(volume=.09){
    if(!soundEnabled || !audio || audio.state !== "running") return;
    volume = volume * SOUND_BOOST;
    try {
        const osc = audio.createOscillator(); const gain = audio.createGain();
        const now = audio.currentTime;
        osc.frequency.setValueAtTime(120, now);
        osc.frequency.exponentialRampToValueAtTime(40, now + .12);
        gain.gain.setValueAtTime(volume, now);
        gain.gain.exponentialRampToValueAtTime(.001, now + .16);
        osc.connect(gain); gain.connect(masterGain);
        osc.start(now); osc.stop(now + .18);
    } catch(e){}
}

/* ===== افکت‌های صوتیِ تمیز و زیبا (بدون موج اره‌ایِ بم) ===== */
let sfxNoiseBuf = null;
function sfxVoice(freq, dur, type, vol, o){
    if(!soundEnabled || !audio || audio.state !== "running") return;
    o = o || {};
    try{
        const now = audio.currentTime + (o.delay || 0), osc = audio.createOscillator(), g = audio.createGain();
        vol *= SOUND_BOOST;
        osc.type = type;
        if(o.from){ osc.frequency.setValueAtTime(o.from, now); osc.frequency.exponentialRampToValueAtTime(freq, now + (o.glide || dur * 0.7)); }
        else osc.frequency.setValueAtTime(freq, now);
        let tail = osc;
        if(o.lp){ const f = audio.createBiquadFilter(); f.type = "lowpass"; f.frequency.setValueAtTime(o.lp, now); f.Q.value = 0.8; osc.connect(f); tail = f; }
        g.gain.setValueAtTime(0.0001, now);
        g.gain.linearRampToValueAtTime(vol, now + (o.a || 0.004));
        g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
        tail.connect(g); g.connect(sfxGain || masterGain);
        osc.start(now); osc.stop(now + dur + 0.02);
    }catch(e){}
}
function sfxNoise(dur, ftype, f0, f1, vol, delay){
    if(!soundEnabled || !audio || audio.state !== "running") return;
    try{
        if(!sfxNoiseBuf){
            const n = Math.floor(audio.sampleRate * 1.6);
            sfxNoiseBuf = audio.createBuffer(1, n, audio.sampleRate);
            const d = sfxNoiseBuf.getChannelData(0);
            for(let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
        }
        const now = audio.currentTime + (delay || 0), src = audio.createBufferSource();
        src.buffer = sfxNoiseBuf;
        const f = audio.createBiquadFilter(); f.type = ftype; f.Q.value = 0.9;
        f.frequency.setValueAtTime(f0, now);
        if(f1) f.frequency.exponentialRampToValueAtTime(f1, now + dur);
        const g = audio.createGain(); vol *= SOUND_BOOST;
        g.gain.setValueAtTime(0.0001, now);
        g.gain.linearRampToValueAtTime(vol, now + 0.006);
        g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
        src.connect(f); f.connect(g); g.connect(sfxGain || masterGain);
        src.start(now, Math.random() * 0.4); src.stop(now + dur + 0.02);
    }catch(e){}
}
function sfxThud(v){ sfxVoice(52, .3, "sine", .14 * v, { from:150, glide:.13 }); sfxNoise(.12, "lowpass", 2400, 260, .06 * v); }
function sfxHit(){
    sfxThud(1);
    sfxVoice(220, .35, "triangle", .05, { from:520, glide:.3, lp:1800 });
    sfxNoise(.08, "bandpass", 1800, 900, .045);
}
function sfxZap(){ sfxVoice(520, .17, "sine", .05, { from:2000, glide:.15 }); sfxVoice(1040, .1, "triangle", .02, { from:3000, glide:.09 }); }
function sfxWhoosh(rise, dur, vol){
    sfxNoise(dur, "bandpass", rise ? 300 : 4500, rise ? 4500 : 300, vol);
    sfxVoice(rise ? 880 : 220, dur, "sine", vol * 0.6, { from:(rise ? 220 : 880), glide:dur * 0.9 });
}
function sfxSiren(){ sfxVoice(760, .22, "sine", .05, { from:340, glide:.2 }); sfxVoice(760, .22, "sine", .05, { from:340, glide:.2, delay:.26 }); }
function sfxAlarm(){
    [0, 0.3, 0.6].forEach(d => { sfxVoice(330, .22, "sine", .05, { delay:d }); sfxVoice(247, .22, "triangle", .035, { delay:d + 0.12 }); });
}
function sfxBoom(){ sfxVoice(40, 1.0, "sine", .13, { from:120, glide:.85 }); sfxNoise(.7, "lowpass", 1100, 120, .05); }
function playPowerupSFX(){
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => sfxVoice(f, .3, "sine", .045, { delay:i * 0.055 }));
    sfxNoise(.25, "highpass", 7000, 9000, .012, .1);
}

function playHitSFX(){
    sfxHit();
    shake(12, .3);
    flashScreen();
}



function startMusic(){ /* جایگزین می‌شود با نسخه‌ی موتور حرفه‌ای در پایین */ }

function stopMusic(){ if(musicTimer){ clearInterval(musicTimer); musicTimer = null; } try { proStop(); } catch(e){} }

el("soundButton").onclick = () => {
    soundEnabled = !soundEnabled;
    data.soundOn = soundEnabled;
    el("soundButton").textContent = soundEnabled ? "🔊" : "🔇";
    if(soundEnabled) initAudio(); else applyVolumes();
    saveData();
};
el("musicButton").onclick = () => {
    musicEnabled = !musicEnabled;
    data.musicOn = musicEnabled;
    el("musicButton").textContent = musicEnabled ? "🎵" : "🚫";
    if(musicEnabled) initAudio(); else stopMusic();
    saveData();
};

/* ===================== UI ===================== */
function updateUI(){
    if(root) root.classList.toggle("vipTheme", !!data.vip);   // تم طلایی VIP فقط در منوها (داخل بازی تغییری نمی‌کند)
    checkDay();
    checkMissionDay();
    checkWeeklyMission();
    updateRateBoxes();
    ["coins","menuCoins","shopCoins","custCoins"].forEach(id => el(id).textContent = data.coins);
    ["gems","menuGems","shopGems","custGems"].forEach(id => el(id).textContent = data.gems);
    ["level","menuLevel"].forEach(id => el(id).textContent = data.level);

    el("menuBest").textContent = data.best;
    el("best").textContent = data.best;
    el("xpText").textContent = data.xp + "/" + needXP();
    el("xpFill").style.width = Math.min(100, data.xp / needXP() * 100) + "%";
    el("rankTitle").textContent = "🎖️ " + currentRank();
    el("featuredEventBanner").textContent = "🎯 امروز شانس " + todaysFeaturedEvent().name + " بیشتره!";
    el("vipTag").classList.toggle("hidden", !data.vip);

    refreshMissionUI();

    updateShop(); if(curScreenId === "customize") refreshCustomize(); if(curScreenId === "offers") renderOffers();
    updateAchievements();
    updateStats();
    if(typeof updateExtraUI==='function') updateExtraUI();
}

const REVIVE_SHIELD_GEMS = 120;
const upgradeDefs = [
    ["btnTurbo","turbo",2000,"coins"],
    ["btnCoinX2","coinX2",180,"gems"],
    ["btnLucky","luckyBox",6000,"coins"],
    ["btnLongMag","longMag",200,"gems"],
    ["btnShieldStack","shieldStack",10000,"coins"],
    ["btnGemLuck","gemLuck",7000,"coins"],
    ["btnShield","shield",500,"gems"],
    ["btnTriple","tripleJump",400,"gems"],
    ["btnQuad","quadJump",900,"gems"],
    ["btnAutoCollect","autoCollect",15000,"coins"],
    ["btnDodge","dodgeChance",600,"gems"],
    ["btnFastPower","fastPower",150,"gems"],
    ["btnNearMiss","nearMissCoin",50,"gems"]
];


/* Tiered achievements: هر دستاورد از تازه‌کار تا استاد بازی پیش می‌رود و هر مرحله سخت‌تر از قبلی است */
const tierNames = ["تازه‌کار","کاربلد","حرفه‌ای","بازیکن خفن","استاد بازی"];
/* جایزه‌ی هر مقام: دو مقام اول «سکه‌ی زیاد»، از مقام سوم به بعد «سکه‌ی خیلی زیاد + الماس‌ی زیاد».
   ضریب سختی (ACH_W): دستاورد سخت‌تر/کمیاب‌تر (مثل الماس کل، کهکشان جایزه، رکورد) جایزه‌ی بیشتری دارد. */
const TIER_COINS = [1000, 2500, 6000, 15000, 40000];
const TIER_GEMS = [2, 5, 20, 45, 100];
const ACH_W = { games:1, coins:1, score:1.3, combo:1.3, box:0.9, magnet:0.8, nova:0.9, gem:1.4, dodge:0.9, bh:1.2, rg:1.4, shower:1, ice:1.2, aurora:1.3, stars:1 };
function achReward(key, idx){ const w = ACH_W[key] || 1; return { c: Math.round(TIER_COINS[idx] * w / 50) * 50, g: Math.max(1, Math.round(TIER_GEMS[idx] * w)) }; }

const achievementDefs = [
    { key:"games", icon:"🚀", name:"کاوشگر فضا", unit:"بازی انجام بده", get:() => data.games, tiers:[10,50,150,400,1000], baseCoin:45, baseGem:1 },
    { key:"coins", icon:"🟡", name:"شکارچی سکه", unit:"سکه کل جمع کن", get:() => data.totalCoins, tiers:[500,5000,25000,100000,500000], baseCoin:70, baseGem:1 },
    { key:"score", icon:"🏆", name:"رکوردشکن", unit:"امتیاز بزن", get:() => data.best, tiers:[1000,3000,8000,20000,50000], baseCoin:60, baseGem:2 },
    { key:"combo", icon:"🔥", name:"زنجیره‌ساز", unit:"زنجیره بساز", get:() => data.bestCombo, tiers:[15,40,80,150,300], baseCoin:60, baseGem:1 },
    { key:"box", icon:"🎁", name:"جعبه‌گشا", unit:"جعبه باز کن", get:() => data.boxes, tiers:[10,40,120,300,700], baseCoin:45, baseGem:1 },
    { key:"magnet", icon:"🧲", name:"آهنربا", unit:"بار آهنربا بگیر", get:() => data.magnetUses, tiers:[10,40,120,300,700], baseCoin:45, baseGem:1 },
    { key:"nova", icon:"💫", name:"نابودگر", unit:"بار بمب نواختری بزن", get:() => data.novaUses, tiers:[5,20,60,150,350], baseCoin:60, baseGem:2 },
    { key:"gem", icon:"💎", name:"گنج‌یاب", unit:"الماس کل جمع کن", get:() => data.totalGems, tiers:[50,200,800,3000,10000], baseCoin:30, baseGem:2 },
    { key:"dodge", icon:"👽", name:"جاخالی‌ده", unit:"دشمن رد کن", get:() => data.enemiesDodged, tiers:[20,100,400,1200,3000], baseCoin:45, baseGem:1 },
    { key:"bh", icon:"🕳️", name:"جسور سیاهچاله", unit:"بار وارد سیاهچاله شو", get:() => data.blackHoleVisits, tiers:[2,8,20,45,90], baseCoin:75, baseGem:2 },
    { key:"rg", icon:"🌟", name:"شکارچی کهکشان", unit:"بار کهکشان جایزه رو تجربه کن", get:() => data.rewardGalaxyVisits, tiers:[2,8,20,45,90], baseCoin:75, baseGem:2 },
    { key:"shower", icon:"🌠", name:"بارش‌گیر", unit:"بار بارش الماسی رو تجربه کن", get:() => data.diamondShowers, tiers:[5,20,50,120,250], baseCoin:50, baseGem:1 },
    { key:"ice", icon:"❄️", name:"یخ‌نورد", unit:"بار یخ‌زدگی کیهانی ببین", get:() => data.iceStorms || 0, tiers:[2,8,20,45,90], baseCoin:60, baseGem:2 },
    { key:"aurora", icon:"🌌", name:"شفق‌پیما", unit:"دور شفق قطبی بازی کن", get:() => data.auroraRuns || 0, tiers:[2,10,25,60,120], baseCoin:65, baseGem:2 },
    { key:"stars", icon:"⭐", name:"ستاره‌چین", unit:"صورت‌فلکی کامل کن", get:() => data.starSets || 0, tiers:[3,15,40,100,250], baseCoin:50, baseGem:1 }
];

function updateAchievements(){
    const box = el("achList");
    box.innerHTML = "";
    achievementDefs.forEach(def => {
        const idx = data.achTier[def.key] || 0;
        const maxed = idx >= 5;
        const val = def.get();
        const target = def.tiers[Math.min(idx,4)];
        const tierLabel = tierNames[Math.min(idx,4)];
        const done = !maxed && val >= target;
        const row = document.createElement("div");
        row.className = "row achRow " + (maxed ? "tMax" : "t" + idx);
        if(maxed){
            row.innerHTML = `<div>${def.icon} ${def.name}<br><span class="tierChip tMax">👑 استاد شدی!</span><br><span class="small">(${faPrice(def.tiers[4])} ${def.unit})</span></div><button disabled>👑 کامل</button>`;
        } else {
            const r = achReward(def.key, idx);
            row.innerHTML = `<div>${def.icon} ${def.name}<br><span class="tierChip t${idx}">مقام: ${tierLabel}</span><br><span class="small">${faPrice(target)} ${def.unit}</span><br>${faPrice(Math.min(val,target))}/${faPrice(target)} ${done ? "✅" : "⏳"}</div>
            <button ${done ? "" : "disabled"}>${done ? "🎁 " + faPrice(r.c) + " 🟡 + " + faNum(r.g) + " 💎" : "در حال انجام"}</button>`;
            row.querySelector("button").onclick = () => {
                if(done){
                    data.coins += r.c; addGems(r.g);
                    data.achTier[def.key] = idx + 1; statInc("achTiers");
                    save(); toast("🏅 مقام " + tierLabel + " کامل شد! " + faPrice(r.c) + " سکه + " + faNum(r.g) + " الماس");
                }
            };
        }
        box.appendChild(row);
    });
}


/* ================================================================
   آمار بازی (نسخه ۸.۰)
   همه‌ی شمارنده‌های جدید در data.st ذخیره می‌شوند و هر کدام فقط در «یک» نقطه‌ی مشخصِ بازی افزایش پیدا می‌کنند.
   ================================================================ */
function STS(){ if(!data.st || typeof data.st !== "object" || Array.isArray(data.st)) data.st = {}; return data.st; }
function statInc(k, n){
    const v = (n === undefined) ? 1 : +n; if(!Number.isFinite(v) || v <= 0) return;
    const s = STS(); s[k] = Math.min(1e12, (+s[k] || 0) + v);
}
function statMax(k, v){ v = +v; const s = STS(); if(Number.isFinite(v) && v > (+s[k] || 0)) s[k] = Math.min(1e12, v); }
function statModeInc(mode){ const s = STS(); if(!s.modeGames || typeof s.modeGames !== "object") s.modeGames = {}; s.modeGames[mode] = (+s.modeGames[mode] || 0) + 1; }
function statModeBest(mode, sc){ const s = STS(); if(!s.modeBest || typeof s.modeBest !== "object") s.modeBest = {}; if(sc > (+s.modeBest[mode] || 0)) s.modeBest[mode] = Math.min(1e12, sc); }
let statLastT = 0, runTimeS = 0, runScoreAdded = 0, runCounted = false, runQuit = false;
function statsRunStart(){ statLastT = 0; runTimeS = 0; runScoreAdded = 0; runCounted = false; runQuit = false; statModeInc(gameMode); }
function statTick(){   // زمان واقعیِ بازی (بدون مکث و بدون صفحه‌ی مرگ)
    const now = performance.now();
    if(statLastT && now - statLastT < 250){ const d = (now - statLastT) / 1000; runTimeS += d; statInc("time", d); }
    statLastT = now;
}
function statsFinishRun(won){   // در پایان هر دور (و هر بار مرگ)؛ زنده‌شدن‌های پشت‌سرهم دوبار شمرده نمی‌شوند
    const sc = Math.floor(score), add = Math.max(0, sc - runScoreAdded);
    runScoreAdded += add; statInc("totalScore", add);
    statMax("bestRunTime", runTimeS); statModeBest(gameMode, sc);
    data.bestCoins = Math.max(data.bestCoins || 0, runCoins);
    if(!runCounted){ runCounted = true; statInc("rounds"); if(won) statInc("wins"); }
    if(!won && !runQuit) statInc("deaths");
}
function faDur(sec){
    sec = Math.max(0, Math.floor(sec || 0));
    const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    if(h > 0) return faNum(h) + " ساعت و " + faNum(m) + " دقیقه";
    if(m > 0) return faNum(m) + " دقیقه و " + faNum(s) + " ثانیه";
    return faNum(s) + " ثانیه";
}
function collectionCount(cat){
    const list = CAT_ITEMS[cat].filter(it => it.cur === "coins" || it.cur === "gems" || it.cur === "irl");
    return faNum(list.filter(it => ownsItem(cat, it.key)).length) + " از " + faNum(list.length);
}
function updateStats(){
    const st = STS(), c = x => faPrice(x || 0), rounds = st.rounds || 0;
    const modeNames = { classic:"کلاسیک", time:"تایم‌اتک", hard:"سخت", impossible:"غیرممکن", aurora:"شفق قطبی" };
    const mg = st.modeGames || {}, mb = st.modeBest || {};
    const upOwned = upgradeDefs.filter(d => data[d[1]]).length + (data.reviveShield ? 1 : 0), upTotal = upgradeDefs.length + 1;
    const shipLv = upOwn("jump") + upOwn("bold") + upOwn("dash");
    const packsN = Object.keys(data.packsBought || {}).length;
    const groups = [
        ["🎮 کلیات", [
            ["🎮","بازی‌های شروع‌شده",c(data.games)], ["🏁","دورهای کامل‌شده",c(rounds)], ["⏱️","زمان کل بازی",faDur(st.time)],
            ["🏆","رکورد",c(data.best)], ["📈","میانگین امتیاز هر دور",c(rounds ? Math.round((st.totalScore || 0) / rounds) : 0)], ["⌛","طولانی‌ترین دور",faDur(st.bestRunTime)],
            ["🌌","کل مسافت طی‌شده",formatDistance(data.totalDistance)], ["💀","تعداد باخت‌ها",c(st.deaths)], ["🚪","خروج از دور (منوی توقف)",c(st.quits)],
            ["⏳","پیروزی در تایم‌اتک",c(st.wins)], ["⭐","سطح",c(data.level)], ["🎖️","درجه",currentRank()]
        ]],
        ["🟡 سکه و الماس", [
            ["🟡","سکه‌ی جمع‌شده",c(data.totalCoins)], ["🏅","بیشترین سکه در یک دور",c(data.bestCoins)], ["🟡","سکه‌ی معمولی برداشته‌شده",c(st.coinPick)],
            ["💰","سکه‌ی طلایی برداشته‌شده",c(st.goldCoins)], ["💎","الماس کل",c(data.totalGems)], ["💠","الماس برداشته‌شده از مسیر",c(st.gemPick)],
            ["🛒","سکه‌ی خرج‌شده",c(st.coinsSpent)], ["💸","الماس خرج‌شده",c(st.gemsSpent)], ["😈","سکه‌ی دزدیده‌شده",c(st.stolen)],
            ["🎁","جعبه‌های باز‌شده",c(data.boxes)], ["🎰","جایزه‌ی ویژه‌ی جعبه",c(st.jackpots)]
        ]],
        ["🦘 مهارت و حرکت", [
            ["🦘","تعداد پرش‌ها",c(st.jumps)], ["🚀","پرش‌های هوایی",c(st.airJumps)], ["🔥","بهترین زنجیره",c(data.bestCombo)],
            ["⚡","سرعت فوق‌العاده",c(st.superSpeed)], ["🎯","عبور نزدیک",c(st.nearMiss)], ["🧱","مانع‌های ردشده",c(st.passed)],
            ["👽","دشمن ردشده",c(data.enemiesDodged)], ["⭐","شهاب‌های طلایی",c(st.stars)], ["🌟","صورت‌فلکی کامل",c(data.starSets)]
        ]],
        ["⚡ پاورآپ و دفاع", [
            ["🛡️","سپر گرفته‌شده",c(data.shieldPickups)], ["⚡","بوست ۱۰۰ امتیازی",c(st.pBoost)], ["🧲","آهنربا",c(data.magnetUses)],
            ["💫","بمب نواختری",c(data.novaUses)], ["🕐","کندی زمان",c(data.slowTimeUses)], ["✨","امتیاز ×۲",c(st.pX2)], ["👻","حالت روح",c(data.ghostUses)],
            ["🛡️","حمله‌ی دفع‌شده با سپر",c(st.shieldSaves)], ["😎","جاخالی موفق",c(st.dodgeSaves)], ["🔒","دزد خنثی‌شده",c(st.thiefBlocked)],
            ["😈","سرقت‌های موفق دزد",c(st.thefts)], ["🛰️","نابودی با ماهواره",c(st.satZaps)]
        ]],
        ["❤️ زنده‌شدن و جایزه‌ها", [
            ["❤️","دفعات زنده‌شدن",c(st.revives)], ["🎟️","زنده‌شدن رایگان",c(st.revFree)], ["📺","زنده‌شدن با تبلیغ",c(st.revAd)], ["💎","زنده‌شدن با الماس",c(st.revGem)],
            ["📺","تبلیغ دیده‌شده",c(st.ads)], ["🎁","جایزه‌ی تبلیغاتی گرفته‌شده",c(st.adRewards)], ["📅","جایزه‌ی روزانه گرفته‌شده",c(st.dailyClaims)],
            ["🎡","چرخش چرخ شانس",c(st.spins)], ["🏆","پاداش بزرگ روزانه",c(st.bonusDaily)], ["🏆","پاداش بزرگ هفتگی",c(st.bonusWeekly)], ["🌌","جایزه‌ی اطلس کیهانی",faNum(Object.keys(data.codexClaim || {}).reduce((s, k) => s + (data.codexClaim[k] || 0), 0)) + " از ۳۰"], ["💳","خرید درون‌برنامه‌ای",c(st.purchases)], ["💵","جمع مبلغ خرید (تومان)",c(st.tomanSpent)]
        ]],
        ["🏁 حالت‌های بازی (رکورد)", Object.keys(modeNames).map(m => ["🏁", modeNames[m] + " · " + faNum(mg[m] || 0) + " بازی", c(mb[m])])],
        ["🧰 کلکسیون و پیشرفت", [
            ["🚀","اسکین‌ها",collectionCount("skin")], ["✨","دنباله‌ها",collectionCount("trail")], ["💥","افکت‌های پرش",collectionCount("jump")],
            ["🔮","هاله‌ها",collectionCount("aura")], ["🎬","افکت‌های ورود",collectionCount("start")], ["🌍","زمین‌های ویژه",collectionCount("ground")],
            ["🎞️","فیلترها",collectionCount("filter")], ["🪐","دکور فضایی",collectionCount("decor")], ["🎁","پک‌های خریداری‌شده",c(packsN)],
            ["⚙️","قدرت‌های همیشگی",faNum(upOwned) + " از " + faNum(upTotal)], ["🛠️","سطح ارتقاهای سفینه",faNum(shipLv) + " از ۳۰"],
            ["🏅","مقام دستاورد دریافت‌شده",faNum(Object.keys(data.achTier || {}).reduce((s, k) => s + Math.min(5, +data.achTier[k] || 0), 0)) + " از " + faNum(achievementDefs.length * 5)], ["👑","عضویت VIP",data.vip ? "فعال" : "—"],
            ["🚫","حذف تبلیغات",hasNoAds() ? "فعال" : "—"], ["🛰️","ماهواره‌ی همراه",data.satelliteOwned ? "دارد" : "—"]
        ]]
    ];
    el("statsGrid").innerHTML = groups.map(g => '<div class="statHead">' + g[0] + "</div>" + g[1].map(x => '<div class="stat">' + x[0] + "<br><b>" + x[2] + "</b><br>" + x[1] + "</div>").join("")).join("");
}

/* ===================== WHEEL ===================== */
const wheelPool = [
    { icon:"🟡", label:"100 سکه", apply:() => { data.coins += 100; } },
    { icon:"🟡", label:"250 سکه", apply:() => { data.coins += 250; } },
    { icon:"💎", label:"4 الماس", apply:() => { addGems(4); } },
    { icon:"💎", label:"10 الماس", apply:() => { addGems(10); } },
    { icon:"🛡️", label:"سپر شروع", apply:() => { data.boostShield++; } },
    { icon:"🚀", label:"شروع سریع", apply:() => { data.boostHead++; } },
    { icon:"🧲", label:"آهنربا بوست", apply:() => { data.boostMag++; } },
    { icon:"🎁", label:"سوپر پاداش", apply:() => { data.coins += 300; addGems(5); } },
    { icon:"🌟", label:"کهکشان تضمینی", apply:() => { data.guaranteedRewardGalaxy = true; } }
];

function renderWheelGrid(){
    const g = el("wheelGrid");
    g.innerHTML = wheelPool.map(w => `<div class="wheelItem">${w.icon}<span>${w.label}</span></div>`).join("");
}

function wheelFreeLeft(){ return (data.wheelClaimed ? 0 : 1) + (data.vip && !data.wheelClaimed2 ? 1 : 0); }
let wheelBusy = false;
function openWheel(){
    checkWheelDay(); renderWheelGrid(); openScreen("wheel");
    const free = wheelFreeLeft(), credit = data.wheelAdCredit || 0, adBtn = el("spinWheelAd");
    if(adBtn) adBtn.classList.add("hidden");
    if(free + credit <= 0){
        if(!data.wheelAdDone && adBtn){
            el("wheelMsg").textContent = "چرخش‌های امروز تموم شد — با تماشای تبلیغ یک بار دیگه بچرخون!";
            adBtn.classList.remove("hidden"); adBtn.disabled = false;
        } else {
            el("wheelMsg").textContent = "جایزه‌های امروز رو گرفتی، فردا دوباره سر بزن!";
        }
        el("spinWheel").disabled = true;
    } else {
        el("wheelMsg").textContent = free <= 0 ? "🎬 یک چرخش اضافه (از تماشای تبلیغ) داری!" : (data.vip ? ("👑 عضو VIP: " + (free + credit) + " چرخش امروز باقی مانده!") : "یک بار در روز رایگان بچرخان!");
        el("spinWheel").disabled = false;
    }
}

function wheelSpin(){
    if(wheelBusy) return;
    if(wheelFreeLeft() + (data.wheelAdCredit || 0) <= 0) return;
    wheelBusy = true;
    initAudio();
    const items = [...el("wheelGrid").children];
    const winner = Math.floor(Math.random() * wheelPool.length);
    let ticks = 0, totalTicks = 20 + winner;
    let cur = 0;
    el("spinWheel").disabled = true;
    const spin = setInterval(() => {
        items.forEach(it => it.classList.remove("spin"));
        items[cur].classList.add("spin");
        tone(900 + cur*40, .05, "triangle", .03);
        cur = (cur + 1) % items.length;
        ticks++;
        if(ticks >= totalTicks){
            clearInterval(spin);
            items.forEach(it => it.classList.remove("spin"));
            items[winner].classList.add("spin");
            wheelPool[winner].apply(); statInc("spins");
            // اول چرخش‌های رایگان مصرف می‌شوند، آخر از همه چرخش اضافه‌ی تبلیغ
            if(!data.wheelClaimed){ data.wheelClaimed = true; }
            else if(data.vip && !data.wheelClaimed2){ data.wheelClaimed2 = true; }
            else { data.wheelAdCredit = 0; }
            save();
            tone(880, .25, "triangle", .05);
            toast("🎉 جایزه: " + wheelPool[winner].label);
            wheelBusy = false;
            openWheel();
        }
    }, 90);
}
el("spinWheel").onclick = wheelSpin;
el("spinWheelAd").onclick = () => {
    checkWheelDay();
    if(wheelBusy || wheelFreeLeft() > 0 || (data.wheelAdCredit || 0) > 0 || data.wheelAdDone) return;
    el("spinWheelAd").disabled = true;
    playAd(() => { // جایزه فقط بعد از دیده‌شدن کامل تبلیغ
        data.wheelAdDone = true; data.wheelAdCredit = 1; save();
        openWheel(); wheelSpin();
    }, "wheel");
};

/* ===================== LEADERBOARD ===================== */
function pushScore(){
    data.topScores.push({ score: Math.floor(score), coins: runCoins, gems: runGems, mode: gameMode, date: today() });
    data.topScores.sort((a,b) => b.score - a.score);
    data.topScores = data.topScores.slice(0, 10);
}
function commitFinalScoreIfNeeded(){
    if(scorePushed) return;
    scorePushed = true;
    pushScore();
    saveData();
}

function renderLeaderboard(){
    const box = el("lbList");
    if(!data.topScores.length){ box.innerHTML = '<div class="sub">هنوز رکوردی ثبت نشده. یک دور بازی کن!</div>'; return; }
    const MODE_FA = { classic: "بی‌نهایت", time: "تایم‌اتک", hard: "سخت", impossible: "غیرممکن", aurora: "شفق قطبی" };
    box.innerHTML = data.topScores.map((r,i) => `<div class="lbRow"><div class="lbMain"><span>#${i+1}</span><span>🎯 <b>${r.score}</b></span><span><span class="iconCoin"></span> ${r.coins}</span>${typeof r.gems === "number" ? `<span><span class="iconGem"></span> ${r.gems}</span>` : ""}</div><div class="lbSub">${MODE_FA[r.mode] ? "🎮 حالت: " + MODE_FA[r.mode] + " · " : ""}${r.date}</div></div>`).join("");
}

/* ===================== RESIZE / WORLD ===================== */
function resize(){
    W = innerWidth; H = innerHeight;
    DPR = Math.min(devicePixelRatio || 1, 2);
    canvas.width = W * DPR; canvas.height = H * DPR;
    canvas.style.width = W + "px"; canvas.style.height = H + "px";
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    if(player) player.ground = H * .78;
    makeStars();
    makePlanets();
    makeNebulae();
}


function makeStars(){
    stars = [];
    const layers = [
        { n: 35, rMin:.3, rMax:.9, sMin:.15, sMax:.4, a:.35 },
        { n: 30, rMin:.6, rMax:1.4, sMin:.4, sMax:.9,  a:.55 },
        { n: 20, rMin:1.0, rMax:2.1, sMin:.9, sMax:1.8, a:.85 }
    ];
    layers.forEach((L, depth) => {
        for(let i=0;i<L.n;i++){
            stars.push({
                x: Math.random()*W, y: Math.random()*H,
                r: L.rMin + Math.random()*(L.rMax-L.rMin),
                s: L.sMin + Math.random()*(L.sMax-L.sMin),
                a: L.a, depth, tw: Math.random()*Math.PI*2
            });
        }
    });
}

function makeNebulae(){
    const nb = (typeof BIO !== "undefined" && BIO[gameMode] ? BIO[gameMode] : BIO.classic).neb;
    nebulae = [
        { x: W*0.2, y: H*0.3, r: Math.max(W,H)*0.4, c: nb[0], speed:.02 },
        { x: W*0.75, y: H*0.6, r: Math.max(W,H)*0.35, c: nb[1], speed:.035 },
        { x: W*0.5, y: H*0.15, r: Math.max(W,H)*0.3, c: nb[2], speed:.015 }
    ];
}

function makePlanets(){
    planets = [
        { x: W * 0.8, y: H * 0.22, radius: 52, color1: "#ffb6d9", color2: "#7a3d9e", ring: true, speed: 0.15, rot:0, ph: 0.30 },
        { x: W * 0.25, y: H * 0.42, radius: 30, color1: "#ffc27a", color2: "#c94b2e", ring: false, speed: 0.08, rot:0, ph: 0.78 },
        { x: W * 1.15, y: H * 0.12, radius: 74, color1: "#8fd8ff", color2: "#3a4fc9", ring: true, speed: 0.2, rot:0, ph: 0.05 }
    ];
}

function startGame(){
    initAudio();
    playing = true; score = 0; runCoins = 0; runGems = 0;
    speed = gameMode === "impossible" ? 8 : gameMode === "hard" ? 6.5 : (gameMode === "aurora" ? 4.7 : 5);
    modeTimer = 60; proPos = {}; proPausePos = null;
    currentBiome = gameMode; bioReset();
    eventActive = false; eventTimer = 0; eventCooldown = 0;
    inBlackHole = false; blackHoleWarning = false; blackHoleWarnT = 0; blackHoleCheckT = 0; bhSwirl = 0;
    hide("bhAlert"); hide("bhBadge");
    inRewardGalaxy = false; rewardGalaxyWarning = false; rewardGalaxyWarnT = 0; rewardGalaxyCheckT = 0; rgSwirl = 0;
    hide("rgAlert"); hide("rgBadge");
    playerTrail = [];
    pendingGuaranteedRG = data.guaranteedRewardGalaxy;
    data.guaranteedRewardGalaxy = false;
    pendingGuaranteedBH = data.guaranteedBlackHole;
    data.guaranteedBlackHole = false;
    pendingGuaranteedDS = data.guaranteedDiamondShower;
    data.guaranteedDiamondShower = false;
    pendingGuaranteedSF = data.guaranteedSolarFlare;
    data.guaranteedSolarFlare = false;
    diamondShowerActive = false; diamondShowerT = 0; diamondShowerCheckT = 0;
    hide("showerBadge");
    scoreMultTimer = 0;
    hide("multBadge");
    
    if(gameMode === "time"){
        show("timerBadge");
        el("timeLeft").textContent = modeTimer;
    } else {
        hide("timerBadge");
    }

    obstacleT = 0; coinT = 0; powerT = 0; boxT = 0; enemyT = 0; meteorT = 0; shootStarT = 0; gemCoinT = 0; combo = 0; comboTimer = 0; dashTimer = 0; slowTimer = 0;
    magnetTime = 0;
    obstacles = []; coins = []; gemCoins = []; powers = []; boxes = []; enemies = []; meteors = []; particlesArr = []; cxArr.length = 0; floaters = [];

    let initShields = (data.shieldOn || data.vip) ? 1 : 0;

    player = {
        x: W * .15, y: H * .5, w: 46, h: 60, vy: 0,
        ground: H * .78, jumps: 0, maxJumps: data.quadJumpOn ? 4 : (data.tripleJumpOn ? 3 : 2), 
        shields: initShields, magnet: magnetTime > 0
    };

    if(data.boostHead > 0){ data.boostHead--; dashTimer = dashDur(); toast("🚀 شروع سریع: از اول تا آخرِ سرعت نهایی!"); }
    if(data.boostShield > 0){ data.boostShield--; player.shields++; toast("🛡️ سپر شروع فعال شد"); }
    if(data.boostMag > 0){ data.boostMag--; magnetTime = Math.max(magnetTime, data.longMag ? 10 : 7); player.magnet = true; toast("🧲 آهنربای شروع فعال شد"); }

    checkMissionDay();
    checkWeeklyMission();
    data.m7 = Math.min(3, (data.m7||0) + 1);
    data.wm2 = (data.wm2||0) + 1;
    data.games++; save();
    ["menu","shop","missions","ach","stats","daily","over","levelUp","wheel","leaderboard","settings","pauseMenu","codex","iapBox","howto","about"].forEach(hide);
    show("hint");

    /* افکت ورود به بازی (موتور مشترک شخصی‌سازی) */
    startFxState = null;
    { const sk = data.startFx; if(sk && sk !== "none" && sk !== "default" && STARTFX_DUR[sk]){ startFxState = { key: sk, t0: performance.now() }; cxStartSfx(sk); } }

    last = performance.now();
    rafId = rafId = requestAnimationFrame(loop);
}

function jump(){
    if(playing && player.jumps < player.maxJumps){
        player.vy = -13; player.jumps++;
        const jType = data.jumpEffect === "ice" ? "trailCyan" : data.jumpEffect === "stars" ? "goldtrail" : "flame";
        particles(player.x + 10, player.y + player.h, 6, jType);
        tone(420, .08, "sine", .06);
        setTimeout(() => tone(650, .09, "sine", .04), 35);
        data.m6 = Math.min(70, (data.m6||0) + 1);
    }
}

function obstacle(){
    const h = 40 + Math.random() * 70, w = 30 + Math.random() * 35;
    obstacles.push({ x: W + 40, y: player.ground - h, w, h, type: Math.floor(Math.random() * 3) });
}

function coin(){
    const isSuper = Math.random() < (data.superCoinOn ? 0.08 : 0.04); // ۴٪ شانس سکه‌ی طلایی ویژه (ارزش ۱۰ برابر)
    coins.push({ x: W + 30, y: player.ground - 60 - Math.random() * 150, r: isSuper ? 15 : 12, spin: 0, super: isSuper });
}
function gemCoin(){
    const y = player.ground - 90 - Math.random() * 160;
    gemCoins.push({ x: W + 30, y, r: 11, spin: 0 });
    if(gameMode === "aurora"){
        gemCoins.push({ x: W + 78, y: player.ground - 90 - Math.random() * 160, r: 11, spin: 0 });
        if(Math.random() < 0.35) gemCoins.push({ x: W + 126, y: player.ground - 90 - Math.random() * 160, r: 11, spin: 0 });
    }
}
// کیسه‌ی تصادفیِ عادلانه: در هر ۷ قدرتِ پشت‌سرهم، از هر نوع دقیقاً یکی می‌آید؛
// پس در هیچ رویداد یا لحظه‌ای (مثلاً کهکشان جایزه) نوعی مثل آهن‌ربا بیشتر از بقیه نمی‌آید.
let powerBag = [];
function nextPowerType(){
    if(!powerBag.length){
        powerBag = [0,1,2,3,4,5,6];
        for(let i = powerBag.length - 1; i > 0; i--){
            const j = Math.floor(Math.random() * (i + 1));
            const t = powerBag[i]; powerBag[i] = powerBag[j]; powerBag[j] = t;
        }
    }
    return powerBag.pop();
}
function power(){ powers.push({ x: W + 30, y: player.ground - 80 - Math.random() * 100, type: nextPowerType(), r: 16, spin: 0 }); }
function box(){ boxes.push({ x: W + 30, y: player.ground - 70 - Math.random() * 130, w: 32, h: 32, spin: 0 }); }
function enemy(){ 
    const r = Math.random();
    const type = r < 0.34 ? "sine" : r < 0.67 ? "drone" : "thief";
    enemies.push({ x: W + 40, y: player.ground - 45 - Math.random() * 180, w: 36, h: 26, vy: (Math.random() - .5) * 1.5, type, baseY: player.ground - 80, dodged: false }); 
}
function meteor(){ meteors.push({ x: W + 50, y: Math.random() * H * 0.5, vx: -(6 + Math.random() * 4), vy: 2 + Math.random() * 2, r: 12 }); }
function shootStar(){ shootingStars.push({ x: Math.random()*W*0.6 + W*0.2, y: -20, vx: -4-Math.random()*3, vy: 5+Math.random()*3, life:1 }); }

function hit(a,b){ return (a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y); }

/* جایگزین دستی ctx.roundRect (که در وب‌ویوهای اندروید قدیمی‌تر پشتیبانی نمی‌شود) با arcTo که خیلی قدیمی و همه‌جا پشتیبانی می‌شود */
function roundRectPath(x, y, w, h, r){
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.arcTo(x + w, y, x + w, y + r, r);
    ctx.lineTo(x + w, y + h - r);
    ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
    ctx.lineTo(x + r, y + h);
    ctx.arcTo(x, y + h, x, y + h - r, r);
    ctx.lineTo(x, y + r);
    ctx.arcTo(x, y, x + r, y, r);
    ctx.closePath();
}


function floatText(x, y, text, color){
    floaters.push({ x, y, text: toFaDigits(String(text)), color, life: 1 });
}


/* ===================== پاورآپ‌ها (همه به سبک پاورآپ آهسته‌سازی زمان، هرکدام با ظاهر خودش) ===================== */
function powerBase(c){
    ctx.shadowColor = c.glow; ctx.shadowBlur = gfxLow() ? 5 : (gfxMax() ? 24 : gfxPlus() ? 21 : 18);
    const dg = ctx.createRadialGradient(0, 0, 2, 0, 0, 18);
    dg.addColorStop(0, c.d0); dg.addColorStop(1, c.d1);
    ctx.fillStyle = dg;
    ctx.beginPath(); ctx.arc(0, 0, 17.5, 0, Math.PI * 2); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.lineWidth = 2.6; ctx.strokeStyle = c.rim;
    ctx.beginPath(); ctx.arc(0, 0, 16.5, 0, Math.PI * 2); ctx.stroke();
}
function powerStar4(x, y, r, col){
    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.moveTo(x, y - r); ctx.lineTo(x + r * 0.28, y - r * 0.28); ctx.lineTo(x + r, y); ctx.lineTo(x + r * 0.28, y + r * 0.28);
    ctx.lineTo(x, y + r); ctx.lineTo(x - r * 0.28, y + r * 0.28); ctx.lineTo(x - r, y); ctx.lineTo(x - r * 0.28, y - r * 0.28);
    ctx.closePath(); ctx.fill();
}
function powerEmoji(ch, size){
    ctx.font = size + "px sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillStyle = "#fff"; ctx.fillText(ch, 0, 1);
}
function drawPowers(){
    const now = performance.now();
    powers.forEach(p => {
        ctx.save();
        const pulse = 0.5 + 0.5 * Math.sin(now / 260);
        ctx.translate(p.x, p.y + Math.sin(now / 340 + p.x * 0.013) * 2.2);
        const T = now / 1000;
        if(gfxPlus()){ // هاله‌ی نرم و رنگی دور پاورآپ (فقط گرافیک مکس)
            const cols = ["78,240,192", "255,212,71", "255,93,143", "100,231,255", "159,232,255", "255,224,102", "215,179,255"];
            maxGlow(0, 0, 44 + pulse * 6, cols[p.type] || "255,255,255", 0.45);
        }
        if(p.type === 4){
            // آهسته‌سازی زمان: دیسک سرمه‌ای تیره + حلقه‌ی یخی روشن + استیکر ❄️ ایستاده
            powerBase({ glow:"#9fe8ff", d0:"#1a3f8f", d1:"#050d28", rim:"#c4f6ff" });
            ctx.lineWidth = 1.2; ctx.strokeStyle = "rgba(255,255,255," + (0.3 + 0.45 * pulse) + ")";
            ctx.beginPath(); ctx.arc(0, 0, 12.5, 0, Math.PI * 2); ctx.stroke();
            ctx.fillStyle = "#e8fbff";
            for(let k = 0; k < 4; k++){
                const a = p.spin * 0.8 + k * Math.PI / 2;
                ctx.save(); ctx.translate(Math.cos(a) * 22, Math.sin(a) * 22); ctx.rotate(Math.PI / 4);
                ctx.fillRect(-1.8, -1.8, 3.6, 3.6); ctx.restore();
            }
            powerEmoji("❄️", 17);
        } else if(p.type === 0){
            // سپر: دیسک سبز-آبی تیره + حلقه‌ی نعنایی + شش‌ضلعی چرخان + لوزی‌های مداری
            powerBase({ glow:"#4ef0c0", d0:"#0f6b60", d1:"#031d1f", rim:"#a8ffe9" });
            ctx.lineWidth = 1.6; ctx.strokeStyle = "rgba(168,255,233," + (0.35 + 0.45 * pulse) + ")";
            ctx.beginPath();
            for(let k = 0; k < 6; k++){ const a = p.spin * 0.5 + k * Math.PI / 3; const x = Math.cos(a) * 12.5, y = Math.sin(a) * 12.5; if(k === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y); }
            ctx.closePath(); ctx.stroke();
            ctx.fillStyle = "#c8fff1";
            for(let k = 0; k < 3; k++){
                const a = -p.spin * 0.9 + k * Math.PI * 2 / 3;
                ctx.save(); ctx.translate(Math.cos(a) * 22, Math.sin(a) * 22); ctx.rotate(a + Math.PI / 4);
                ctx.fillRect(-2, -2, 4, 4); ctx.restore();
            }
            powerEmoji("🛡️", 16);
        } else if(p.type === 1){
            // بوست امتیاز: دیسک کهربایی + ستاره‌ی تیغ‌دار برقی + جرقه‌های سریع
            powerBase({ glow:"#ffd447", d0:"#6b4a00", d1:"#1c1200", rim:"#fff0a0" });
            ctx.lineWidth = 1.5; ctx.strokeStyle = "rgba(255,224,102," + (0.45 + 0.4 * pulse) + ")";
            ctx.beginPath();
            for(let k = 0; k < 16; k++){ const a = p.spin * 0.35 + k * Math.PI / 8; const r = k % 2 ? 8.5 : 13.5; const x = Math.cos(a) * r, y = Math.sin(a) * r; if(k === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y); }
            ctx.closePath(); ctx.stroke();
            ctx.strokeStyle = "#fff6c0"; ctx.lineWidth = 1.4;
            for(let k = 0; k < 5; k++){
                const a = p.spin * 1.6 + k * Math.PI * 2 / 5, r1 = 20, r2 = 24 + (k % 2) * 2;
                ctx.beginPath(); ctx.moveTo(Math.cos(a) * r1, Math.sin(a) * r1); ctx.lineTo(Math.cos(a + 0.12) * r2, Math.sin(a + 0.12) * r2); ctx.stroke();
            }
            powerEmoji("⚡", 16);
        } else if(p.type === 2){
            // آهنربا: دیسک زرشکی + دو کمان میدان مغناطیسی قرمز و آبی + قطب‌های مداری
            powerBase({ glow:"#ff5d8f", d0:"#5a1238", d1:"#14040f", rim:"#ffb0cc" });
            ctx.lineWidth = 2.2; ctx.lineCap = "round";
            ctx.strokeStyle = "rgba(255,93,93," + (0.6 + 0.3 * pulse) + ")";
            ctx.beginPath(); ctx.arc(0, 0, 12.5, p.spin * 0.7, p.spin * 0.7 + 1.9); ctx.stroke();
            ctx.strokeStyle = "rgba(93,168,255," + (0.6 + 0.3 * pulse) + ")";
            ctx.beginPath(); ctx.arc(0, 0, 12.5, p.spin * 0.7 + Math.PI, p.spin * 0.7 + Math.PI + 1.9); ctx.stroke();
            ctx.lineCap = "butt";
            for(let k = 0; k < 4; k++){
                const a = -p.spin * 0.8 + k * Math.PI / 2;
                ctx.fillStyle = k % 2 ? "#6fb4ff" : "#ff7070";
                ctx.beginPath(); ctx.arc(Math.cos(a) * 22, Math.sin(a) * 22, 2.3, 0, Math.PI * 2); ctx.fill();
            }
            powerEmoji("🧲", 16);
        } else if(p.type === 3){
            // بمب نواختری: دیسک آبی-بنفش + پرتوهای چرخان + ستاره‌های چهارپر مداری
            powerBase({ glow:"#64e7ff", d0:"#144a8a", d1:"#060a22", rim:"#bff5ff" });
            ctx.lineWidth = 1.4; ctx.strokeStyle = "rgba(190,245,255," + (0.35 + 0.5 * pulse) + ")";
            for(let k = 0; k < 8; k++){
                const a = p.spin * 1.2 + k * Math.PI / 4;
                ctx.beginPath(); ctx.moveTo(Math.cos(a) * 7, Math.sin(a) * 7); ctx.lineTo(Math.cos(a) * (13 + pulse * 2), Math.sin(a) * (13 + pulse * 2)); ctx.stroke();
            }
            for(let k = 0; k < 4; k++){
                const a = -p.spin * 1.1 + k * Math.PI / 2;
                powerStar4(Math.cos(a) * 22, Math.sin(a) * 22, 3.6, "#e4fbff");
            }
            powerEmoji("💫", 17);
        } else if(p.type === 5){
            // امتیاز دوبل: دیسک طلایی + حلقه‌ی خط‌چین چرخان + جرقه‌های چهارپر طلایی
            powerBase({ glow:"#ffe066", d0:"#6b5200", d1:"#1e1600", rim:"#fff2b0" });
            ctx.lineWidth = 1.6; ctx.strokeStyle = "rgba(255,236,150," + (0.45 + 0.4 * pulse) + ")";
            ctx.save(); ctx.rotate(p.spin * 0.6); ctx.setLineDash([3, 4]);
            ctx.beginPath(); ctx.arc(0, 0, 12.5, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
            for(let k = 0; k < 4; k++){
                const a = p.spin * 0.9 + k * Math.PI / 2;
                powerStar4(Math.cos(a) * 22, Math.sin(a) * 22, 3.8, "#fff1a8");
            }
            powerEmoji("✨", 17);
        } else {
            // حالت روح: دیسک بنفش شفاف‌تر + حلقه‌ی موجی + شبح‌های کوچک مداری
            ctx.globalAlpha = 0.93;
            powerBase({ glow:"#d7b3ff", d0:"#3a1a78", d1:"#0c0525", rim:"#e6d0ff" });
            ctx.lineWidth = 1.5; ctx.strokeStyle = "rgba(230,208,255," + (0.4 + 0.45 * pulse) + ")";
            ctx.beginPath();
            for(let k = 0; k <= 48; k++){ const a = k / 48 * Math.PI * 2; const r = 12.2 + Math.sin(a * 6 + T * 4) * 1.8; const x = Math.cos(a) * r, y = Math.sin(a) * r; if(k === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y); }
            ctx.closePath(); ctx.stroke();
            for(let k = 0; k < 3; k++){
                const a = p.spin * 0.8 + k * Math.PI * 2 / 3;
                for(let q = 0; q < 3; q++){
                    ctx.fillStyle = "rgba(235,215,255," + (0.65 - q * 0.2) + ")";
                    ctx.beginPath(); ctx.arc(Math.cos(a - q * 0.28) * 22, Math.sin(a - q * 0.28) * 22, 2.6 - q * 0.6, 0, Math.PI * 2); ctx.fill();
                }
            }
            ctx.globalAlpha = 1;
            powerEmoji("👻", 17);
        }
        ctx.restore();
    });
}

/* ===================== آدم‌فضایی‌ها ===================== */
// آدم‌فضایی قرمز: مهاجم تیغ‌دار و زره‌پوش (آسیب می‌زند)
function drawRedAstro(e, now){
    const flick = 0.5 + 0.5 * Math.sin(now / 55 + e.x);
    ctx.save();
    ctx.translate(e.x + 18, e.y + 13 + Math.sin(now / 260 + e.x * 0.02) * 1.6);
    ctx.rotate(Math.sin(now / 420 + e.y) * 0.08 - 0.14);
    ctx.scale(1.08, 1.08);
    if(gfxPlus()) maxGlow(-2, 0, 46 + flick * 4, "255,42,61", 0.34);
    else if(!gfxLow()){ ctx.shadowColor = "rgba(255,42,61,0.9)"; ctx.shadowBlur = 14; }
    // شعله‌ی جت‌پک
    const fl = 11 + flick * 7;
    let fg = ctx.createLinearGradient(20, 0, 20 + fl, 0);
    fg.addColorStop(0, "rgba(255,200,60,0.95)"); fg.addColorStop(0.5, "rgba(255,110,20,0.75)"); fg.addColorStop(1, "rgba(255,40,0,0)");
    ctx.fillStyle = fg; ctx.beginPath(); ctx.moveTo(20, -3.4); ctx.quadraticCurveTo(20 + fl, 0, 20, 3.4); ctx.closePath(); ctx.fill();
    // جت‌پک
    ctx.fillStyle = "#2b2f3d"; ctx.beginPath(); roundRectPath(11, -9, 10, 17, 3); ctx.fill();
    ctx.fillStyle = "#ff3b4d"; ctx.fillRect(11, -3, 10, 2.4);
    // پاها
    ctx.fillStyle = "#4a0912";
    ctx.beginPath(); roundRectPath(-8, 11, 7, 8, 2.5); ctx.fill(); ctx.beginPath(); roundRectPath(2, 10, 7, 8, 2.5); ctx.fill();
    ctx.fillStyle = "#ff6a3a"; ctx.fillRect(-7.5, 17, 6, 1.6); ctx.fillRect(2.5, 16, 6, 1.6);
    ctx.shadowBlur = 0; ctx.shadowColor = "transparent";
    // بدنه‌ی زره‌دار
    const bg = ctx.createLinearGradient(-10, -4, 12, 14);
    bg.addColorStop(0, "#ff5361"); bg.addColorStop(1, "#8c0f22");
    ctx.fillStyle = bg; ctx.beginPath(); roundRectPath(-10, -4, 22, 18, 6); ctx.fill();
    ctx.strokeStyle = "rgba(40,0,8,0.65)"; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(-9, 4); ctx.lineTo(11, 4); ctx.moveTo(1, -3); ctx.lineTo(1, 13); ctx.stroke();
    ctx.fillStyle = "rgba(255,230,120," + (0.6 + 0.4 * flick) + ")"; ctx.beginPath(); ctx.arc(-4, 1, 2.2, 0, Math.PI * 2); ctx.fill();
    // خارهای شانه
    ctx.fillStyle = "#5a0b17";
    ctx.beginPath(); ctx.moveTo(6, -4); ctx.lineTo(10, -17); ctx.lineTo(13, -3); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(1, -3); ctx.lineTo(3.5, -12); ctx.lineTo(7, -3); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = "#ff8a94"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(10, -17); ctx.lineTo(13, -3); ctx.stroke();
    // بازوی جلو با گلوله‌ی پلاسما
    ctx.strokeStyle = "#a5132b"; ctx.lineWidth = 5; ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(-8, 3); ctx.lineTo(-19, 1); ctx.stroke(); ctx.lineCap = "butt";
    ctx.shadowColor = "#ffb03a"; ctx.shadowBlur = gfxLow() ? 0 : 10;
    ctx.fillStyle = "#ffd25a"; ctx.beginPath(); ctx.arc(-23, 1, 3.6 + flick * 0.8, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#fff6d0"; ctx.beginPath(); ctx.arc(-23, 1, 1.6, 0, Math.PI * 2); ctx.fill();
    ctx.shadowBlur = 0; ctx.shadowColor = "transparent";
    // کلاه‌ایمنی
    const hg = ctx.createRadialGradient(-6, -13, 1, -3, -9, 12);
    hg.addColorStop(0, "#ff7380"); hg.addColorStop(1, "#9c1226");
    ctx.fillStyle = hg; ctx.beginPath(); ctx.arc(-3, -9, 11, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#14010a";
    ctx.beginPath(); ctx.moveTo(-14, -12); ctx.quadraticCurveTo(-3, -17, 7, -9); ctx.lineTo(5, -3); ctx.quadraticCurveTo(-5, -1, -13, -6); ctx.closePath(); ctx.fill();
    ctx.shadowColor = "#ffb020"; ctx.shadowBlur = gfxLow() ? 0 : 8;
    ctx.fillStyle = "#ffcf3a";
    ctx.beginPath(); ctx.moveTo(-11, -9); ctx.lineTo(-5, -7.6); ctx.lineTo(-6, -5); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(1, -9); ctx.lineTo(5.5, -8); ctx.lineTo(3, -5.4); ctx.closePath(); ctx.fill();
    ctx.shadowBlur = 0; ctx.shadowColor = "transparent";
    ctx.fillStyle = "#ff3b4d"; ctx.fillRect(-4, -21, 2, 4);
    ctx.fillStyle = "rgba(255,255,255," + (0.4 + 0.6 * flick) + ")"; ctx.beginPath(); ctx.arc(-3, -22, 1.6, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
}
// آدم‌فضایی سبز: دزد سکه‌ی خمیده با ماسک و کیسه‌ی پر از سکه
function drawThiefAstro(e, now){
    const sway = Math.sin(now / 300 + e.x * 0.02);
    ctx.save();
    ctx.translate(e.x + 18, e.y + 13 + Math.sin(now / 240 + e.x * 0.03) * 2);
    ctx.rotate(sway * 0.1 + 0.1);
    ctx.scale(1.08, 1.08);
    if(gfxPlus()) maxGlow(0, 0, 44, "70,255,140", 0.22);
    else if(!gfxLow()){ ctx.shadowColor = "rgba(70,255,140,0.85)"; ctx.shadowBlur = 12; }
    // دود سبز پشت جت‌پک
    for(let k = 0; k < 3; k++){
        ctx.fillStyle = "rgba(120,255,170," + (0.34 - k * 0.1) + ")";
        ctx.beginPath(); ctx.arc(24 + k * 6 + Math.sin(now / 90 + k) * 1.5, 2 + Math.sin(now / 130 + k * 2) * 2, 4 - k * 0.9, 0, Math.PI * 2); ctx.fill();
    }
    ctx.shadowBlur = 0; ctx.shadowColor = "transparent";
    // کیسه‌ی سکه
    const sg = ctx.createRadialGradient(15, 0, 1, 15, 2, 12);
    sg.addColorStop(0, "#c98a45"); sg.addColorStop(1, "#6b3f16");
    ctx.fillStyle = sg; ctx.beginPath(); ctx.ellipse(16, 3, 9, 10, 0.2, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#4e2d0e"; ctx.beginPath(); ctx.moveTo(12, -5); ctx.lineTo(20, -5); ctx.lineTo(19, -9); ctx.lineTo(13, -9); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = "#e8c15a"; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(11.5, -5.2); ctx.lineTo(20.5, -5.2); ctx.stroke();
    ctx.fillStyle = "#ffd447"; ctx.beginPath(); ctx.arc(16, 3, 3.6, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#a36b00"; ctx.font = "bold 5.5px Tahoma"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText("$", 16, 3.4);
    const sp = (now / 700 + e.x * 0.01) % 1; // سکه‌ی کوچکی که از کیسه می‌افتد
    ctx.globalAlpha = 1 - sp; ctx.fillStyle = "#ffd447"; ctx.beginPath(); ctx.arc(21, 8 + sp * 14, 2.2, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1;
    // پاها (جمع‌شده)
    ctx.fillStyle = "#0d3d25";
    ctx.beginPath(); roundRectPath(-7, 9, 8, 8, 3); ctx.fill(); ctx.beginPath(); roundRectPath(2, 8, 8, 8, 3); ctx.fill();
    // بدنه
    const bg = ctx.createLinearGradient(-9, -4, 10, 13);
    bg.addColorStop(0, "#38d27d"); bg.addColorStop(1, "#0b4a2c");
    ctx.fillStyle = bg; ctx.beginPath(); roundRectPath(-9, -4, 20, 16, 8); ctx.fill();
    ctx.fillStyle = "#06180f"; ctx.fillRect(-9, 6, 20, 3);
    ctx.fillStyle = "#c8ffd9"; ctx.fillRect(-1.2, 6, 3.4, 3);
    // بازوی جلو: دست باز برای دزدی
    ctx.strokeStyle = "#1fae65"; ctx.lineWidth = 4.6; ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(-7, 3); ctx.lineTo(-18, -1); ctx.stroke();
    ctx.fillStyle = "#7dffb1";
    for(let k = -1; k <= 1; k++){ ctx.beginPath(); ctx.arc(-21 - Math.abs(k) * 0.4, -1 + k * 2.6, 1.7, 0, Math.PI * 2); ctx.fill(); }
    ctx.beginPath(); ctx.arc(-19, -1, 2.6, 0, Math.PI * 2); ctx.fill(); ctx.lineCap = "butt";
    // کلاه‌ایمنی با ماسک
    const hg = ctx.createRadialGradient(-5, -14, 1, -2, -9, 12);
    hg.addColorStop(0, "#9bffc4"); hg.addColorStop(1, "#1d9a5a");
    ctx.fillStyle = hg; ctx.beginPath(); ctx.arc(-2, -9, 11, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#06150d"; ctx.beginPath(); ctx.ellipse(-4, -9, 9, 6.6, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#000"; ctx.fillRect(-13, -12, 18, 5.2); // ماسک دزد
    ctx.shadowColor = "#7dffb1"; ctx.shadowBlur = gfxLow() ? 0 : 8; ctx.fillStyle = "#b8ffd8";
    ctx.beginPath(); ctx.ellipse(-8.2, -9.4, 2.3, 1.6, 0, 0, Math.PI * 2); ctx.ellipse(-0.8, -9.4, 2.3, 1.6, 0, 0, Math.PI * 2); ctx.fill();
    ctx.shadowBlur = 0; ctx.shadowColor = "transparent";
    ctx.strokeStyle = "#7dffb1"; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(-4, -6, 3.6, 0.15 * Math.PI, 0.85 * Math.PI); ctx.stroke(); // لبخند موذی
    ctx.fillStyle = "#2a6f48"; ctx.fillRect(-3.4, -21, 2, 3.6); ctx.fillStyle = "#7dffb1"; ctx.beginPath(); ctx.arc(-2.4, -22, 1.5, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
}
function drawEnemies(){
    const now = performance.now();
    enemies.forEach(e => {
        ctx.save();
        if(e.type === "thief"){
            drawThiefAstro(e, now);
        } else if(e.type === "drone"){
            ctx.fillStyle = "#c0c8d8";
            ctx.beginPath(); ctx.arc(e.x+18, e.y+12, 12, 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = "#88f"; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.moveTo(e.x, e.y+12); ctx.lineTo(e.x+36, e.y+12); ctx.stroke();
        } else {
            drawRedAstro(e, now);
        }
        ctx.restore();
    });
}

/* ===================== گرافیک مکس (فقط وقتی «مکس» انتخاب شده) ===================== */
const maxCache = { glow:{}, wh:"", stars:[], dust:[], streaks:[], neb:[], nebKey:"", vig:null, ghosts:[] };
const MAX_BIOME = {
    space:["70,120,255","150,80,255","40,200,255"], ice:["90,220,255","160,200,255","60,160,255"], volcano:["255,110,40","255,60,30","255,180,60"],
    neon:["255,60,200","60,230,255","140,80,255"], crystal:["190,110,255","255,120,220","110,180,255"], golden:["255,200,60","255,150,40","255,230,140"], aurora:["60,255,170","110,160,255","190,90,255"]
};
function maxGlow(x, y, r, rgb, alpha){ // هاله‌ی نرم و درخشان (کش‌شده)
    let c = maxCache.glow[rgb];
    if(!c){
        c = document.createElement("canvas"); c.width = c.height = 64;
        const g = c.getContext("2d"), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
        gr.addColorStop(0, "rgba(" + rgb + ",0.95)"); gr.addColorStop(0.3, "rgba(" + rgb + ",0.4)"); gr.addColorStop(1, "rgba(" + rgb + ",0)");
        g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
        maxCache.glow[rgb] = c;
    }
    const pa = ctx.globalAlpha, pc = ctx.globalCompositeOperation;
    ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = Math.min(1, pa * alpha);
    ctx.drawImage(c, x - r, y - r, r * 2, r * 2);
    ctx.globalAlpha = pa; ctx.globalCompositeOperation = pc;
}
function maxInit(){
    const key = W + "x" + H + (gfxMax() ? "m" : "h");
    if(maxCache.wh !== key){
        maxCache.wh = key; maxCache.stars = []; maxCache.vig = null;
        [[64, 0.05, 0.9], [38, 0.11, 1.5], [16, 0.22, 2.3]].forEach((Ly, li) => {
            for(let i = 0; i < Math.ceil(Ly[0] * (gfxMax() ? 1 : 0.65)); i++) maxCache.stars.push({ x: Math.random() * W, y: Math.random() * H * 0.8, sp: Ly[1] * (0.7 + Math.random() * 0.6), r: Ly[2] * (0.6 + Math.random() * 0.7), tw: Math.random() * 6, layer: li, warm: Math.random() < 0.3 });
        });
        maxCache.dust = [];
        for(let i = 0; i < (gfxMax() ? 9 : 6); i++) maxCache.dust.push({ x: Math.random() * W, y: Math.random() * H, r: 26 + Math.random() * 60, sp: 0.5 + Math.random() * 0.9, a: 0.16 + Math.random() * 0.14, c: i % 3 });
        maxCache.streaks = [];
        for(let i = 0; i < (gfxMax() ? 10 : 7); i++) maxCache.streaks.push({ x: Math.random() * W, y: Math.random() * H * 0.85, len: 60 + Math.random() * 140, sp: 1 + Math.random() * 1.4, a: 0.06 + Math.random() * 0.1 });
    }
    if(maxCache.nebKey !== currentBiome){
        maxCache.nebKey = currentBiome;
        const pal = MAX_BIOME[currentBiome] || MAX_BIOME.classic;
        maxCache.neb = [];
        for(let n = 0; n < 3; n++){
            const c = document.createElement("canvas"); c.width = 440; c.height = 260;
            const g = c.getContext("2d");
            for(let b = 0; b < 6; b++){
                const r = 50 + Math.random() * 55, x = r + Math.random() * (440 - 2 * r), y = r + Math.random() * (260 - 2 * r), col = pal[(n + b) % pal.length];
                const gr = g.createRadialGradient(x, y, 0, x, y, r);
                gr.addColorStop(0, "rgba(" + col + ",0.30)"); gr.addColorStop(0.5, "rgba(" + col + ",0.12)"); gr.addColorStop(1, "rgba(" + col + ",0)");
                g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
            }
            maxCache.neb.push({ c, x: Math.random() * W, y: H * 0.04 + Math.random() * H * 0.42, sp: 0.03 + n * 0.025, s: 1.1 + Math.random() * 0.9 });
        }
    }
}
function maxBackdrop(dt, effSpeed){
    maxInit();
    const pal = MAX_BIOME[currentBiome] || MAX_BIOME.classic, gy = player ? player.ground : H * 0.78;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    maxCache.neb.forEach((n, i) => { // سحابی‌های رنگی چندلایه
        if(playing) n.x -= n.sp * effSpeed * dt;
        const w = 440 * n.s; if(n.x < -w) n.x = W + 40;
        ctx.globalAlpha = 0.8 - i * 0.14;
        ctx.drawImage(n.c, n.x, n.y, w, 260 * n.s);
    });
    ctx.save(); ctx.rotate(-0.28); // نوار راه شیری
    const bg = ctx.createLinearGradient(0, H * 0.12, 0, H * 0.5);
    bg.addColorStop(0, "rgba(" + pal[0] + ",0)"); bg.addColorStop(0.5, "rgba(" + pal[1] + ",0.10)"); bg.addColorStop(1, "rgba(" + pal[0] + ",0)");
    ctx.globalAlpha = 1; ctx.fillStyle = bg; ctx.fillRect(-W, H * 0.12, W * 3, H * 0.38);
    ctx.restore();
    maxCache.stars.forEach(s => { // ستاره‌های سه‌لایه با درخشش
        if(playing){ s.x -= s.sp * effSpeed * dt; if(s.x < -4){ s.x = W + 4; s.y = Math.random() * H * 0.8; } }
        s.tw += 0.05 * dt;
        const a = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(s.tw + s.layer));
        ctx.globalAlpha = a * (s.layer === 0 ? 0.55 : 0.85);
        ctx.fillStyle = s.warm ? "#ffe9c4" : "#dfeaff";
        ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2); ctx.fill();
        if(s.layer === 2){
            maxGlow(s.x, s.y, s.r * 6, s.warm ? "255,220,170" : "170,200,255", 0.4 * a);
            ctx.globalAlpha = 0.5 * a; ctx.fillRect(s.x - s.r * 4.5, s.y - 0.4, s.r * 9, 0.8); ctx.fillRect(s.x - 0.4, s.y - s.r * 4.5, 0.8, s.r * 9);
        }
    });
    ctx.globalAlpha = 1;
    const hz = ctx.createLinearGradient(0, gy - 130, 0, gy); // مه‌ی افق
    hz.addColorStop(0, "rgba(" + pal[0] + ",0)"); hz.addColorStop(1, "rgba(" + pal[0] + ",0.20)");
    ctx.fillStyle = hz; ctx.fillRect(0, gy - 130, W, 130);
    if(playing && effSpeed > 6){ // خطوط سرعت
        const k = Math.min(1, (effSpeed - 6) / 6);
        maxCache.streaks.forEach(s => {
            s.x -= s.sp * effSpeed * dt * 3; if(s.x < -s.len){ s.x = W + 20; s.y = Math.random() * H * 0.85; }
            ctx.globalAlpha = s.a * k; ctx.fillStyle = "#cfe6ff"; ctx.fillRect(s.x, s.y, s.len, 1.2);
        });
    }
    ctx.restore();
    // (سیاره‌ها حالا در skyPlanet و هم‌عمق با دکورها رسم می‌شوند)
    if(!gfxLow()) shootingStars.forEach(s => maxGlow(s.x, s.y, 14, "210,230,255", 0.9)); // سر درخشان شهاب‌ها
}
function maxGround(gy){
    const pal = MAX_BIOME[currentBiome] || MAX_BIOME.classic, t = performance.now();
    ctx.save(); ctx.globalCompositeOperation = "lighter";
    const g = ctx.createLinearGradient(0, gy - 6, 0, gy + 48);
    g.addColorStop(0, "rgba(" + pal[0] + ",0.34)"); g.addColorStop(1, "rgba(" + pal[0] + ",0)");
    ctx.fillStyle = g; ctx.fillRect(0, gy - 6, W, 54);
    ctx.fillStyle = "rgba(255,255,255,0.55)"; ctx.fillRect(0, gy - 1, W, 1.6);
    ctx.fillStyle = "rgba(255,255,255,0.08)";
    for(let i = 0; i < 9; i++){ const L = W + 140, x = (((i * 97 - t * 0.35) % L) + L) % L - 70; ctx.fillRect(x, gy + 5 + (i % 3) * 10, 60 + (i % 4) * 22, 1.6); }
    ctx.restore();
}
function maxPlayerFx(p, px, py){
    const t = performance.now(), gy = p.ground;
    const hgt = Math.max(0, gy - (p.y + p.h)), k = Math.max(0.35, 1 - hgt / 220);
    ctx.save();
    ctx.fillStyle = "rgba(0,0,0," + (0.3 * k) + ")";
    ctx.beginPath(); ctx.ellipse(px, gy + 2, 24 * k, 5 * k, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    if(trailGlowRGB()) maxGlow(px - 4, p.y + p.h * 0.62, 24 + Math.sin(t / 60) * 3, trailGlowRGB(), 0.4);
    if(Math.abs(p.vy) > 3 || dashTimer > 0){ maxCache.ghosts.push({ x: p.x, y: p.y, life: 1 }); }
    maxCache.ghosts.forEach(g => g.life -= 0.12);
    maxCache.ghosts = maxCache.ghosts.filter(g => g.life > 0).slice(-4);
    if(maxCache.ghosts.length){
        ctx.save(); ctx.globalCompositeOperation = "lighter";
        maxCache.ghosts.forEach(g => { ctx.globalAlpha = g.life * 0.10; ctx.fillStyle = "#7cf6ff"; ctx.beginPath(); roundRectPath(g.x + 4, g.y + 4, p.w - 8, p.h - 8, 12); ctx.fill(); });
        ctx.restore();
    }
    if(player.shields > 0){ // حباب سپر با درخشش لبه
        ctx.save();
        const r = 42, sg = ctx.createRadialGradient(px, py, r * 0.55, px, py, r);
        sg.addColorStop(0, "rgba(120,230,255,0)"); sg.addColorStop(1, "rgba(120,230,255,0.38)");
        ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(px, py, r, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.28)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(px, py, r - 3, -2.2, -1.2); ctx.stroke();
        ctx.restore();
    }
}
function drawMaxForeground(){
    maxInit();
    const pal = MAX_BIOME[currentBiome] || MAX_BIOME.classic;
    maxCache.dust.forEach(d => { // غبار و حباب‌های نوری جلوی صحنه
        if(playing){ d.x -= d.sp * 2.4; if(d.x < -d.r){ d.x = W + d.r; d.y = Math.random() * H; } }
        maxGlow(d.x, d.y, d.r, pal[d.c % pal.length], d.a);
    });
    if(!maxCache.vig){
        const g = ctx.createRadialGradient(W / 2, H * 0.55, Math.min(W, H) * 0.35, W / 2, H * 0.55, Math.max(W, H) * 0.78);
        g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, "rgba(0,4,16,0.55)");
        maxCache.vig = g;
    }
    ctx.fillStyle = maxCache.vig; ctx.fillRect(0, 0, W, H);
}


function spawnCoinBurst(){
    for(let i=0; i<8; i++){
        coins.push({ x: W + 40 + i*30, y: player.ground - 80 - Math.sin(i*0.5)*40, r: 12, spin: 0 });
    }
}

function triggerEvent(){
    eventActive = true;
    data.meteorShowers = (data.meteorShowers || 0) + 1;
    show("eventAlert");
    toast("☄️ بارش شهابی!");
    setTimeout(() => { hide("eventAlert"); }, 4000);
    setTimeout(() => { eventActive = false; endEventCooldown(); }, 9000);
}

/* ===================== DIAMOND SHOWER (بارش الماسی) - رویداد سبک و پرتکرار ===================== */
function triggerDiamondShower(){
    diamondShowerActive = true; diamondShowerT = 240; // حدود ۴ ثانیه
    shake(4, .2);
    toast("🌠 بارش الماسی! سریع جمعشون کن!");
    tone(900, .15, "sine", .06);
    setTimeout(() => tone(1200, .15, "sine", .06), 100);
    data.diamondShowers = (data.diamondShowers||0) + 1;
}

/* رویداد ویژه‌ی امروز - بر اساس تاریخ ثابته، هر روز عوض می‌شه، شانس همون رویداد رو یذره بیشتر می‌کنه */
const featuredEventPool = [
    { key:"bh", name:"🕳️ سیاهچاله مرگ" },
    { key:"rg", name:"🌟 کهکشان جایزه" },
    { key:"ds", name:"🌠 بارش الماسی" },
    { key:"sf", name:"☀️ شراره خورشیدی" },
    { key:"ice", name:"❄️ یخ‌زدگی کیهانی" }
];
function todaysFeaturedEvent(){
    const d = new Date();
    const seed = d.getFullYear()*372 + (d.getMonth()+1)*31 + d.getDate();
    return featuredEventPool[seed % featuredEventPool.length];
}

/* ===================== BLACK HOLE (سیاهچاله مرگ) - rare event ===================== */

function startBlackHoleWarning(){
    blackHoleWarning = true; blackHoleWarnT = 0;
    show("bhAlert");
    toast("⚠️ یک سیاهچاله در حال نزدیک شدن است!");
    sfxAlarm();
}

function enterBlackHole(){
    blackHoleWarning = false; hide("bhAlert");
    inBlackHole = true; blackHoleEntryScore = score;
    obstacles = []; enemies = []; meteors = [];
    show("bhBadge");
    shake(18, .5); flashScreen();
    sfxBoom();
    toast("🕳️ به درون سیاهچاله کشیده شدی! جاذبه کمتر شد...");
    data.blackHoleVisits++;
    data.m8 = Math.min(1, (data.m8||0) + 1);
}

function exitBlackHole(){
    inBlackHole = false;
    hide("bhBadge");
    obstacles = []; enemies = []; meteors = [];
    shake(14, .4); flashScreen();
    tone(500, .3, "triangle", .06);
    setTimeout(() => tone(750, .3, "triangle", .05), 150);
    data.coins += 300; addGems(5);
    endEventCooldown();
    toast("🌌 از سیاهچاله خارج شدی! (+300 🟡 +5 💎)");
}

/* ===================== REWARD GALAXY (کهکشان جایزه) - دنیای امن و پر از جایزه ===================== */
const REWARD_GALAXY_TARGET = 800;

function startRewardGalaxyWarning(){
    rewardGalaxyWarning = true; rewardGalaxyWarnT = 0;
    show("rgAlert");
    toast("🌟 یک کهکشان جایزه نزدیک می‌شود!");
    tone(700, .3, "sine", .05);
    setTimeout(() => tone(1000, .3, "sine", .05), 150);
}

function enterRewardGalaxy(){
    rewardGalaxyWarning = false; hide("rgAlert");
    inRewardGalaxy = true; rewardGalaxyEntryScore = score;
    obstacles = []; enemies = []; meteors = [];
    show("rgBadge");
    shake(8, .3); flashScreen();
    tone(600, .15, "sine", .07);
    setTimeout(() => tone(900, .15, "sine", .07), 100);
    setTimeout(() => tone(1300, .25, "triangle", .07), 200);
    toast("🌟 وارد کهکشان جایزه شدی! هیچ خطری نیست، فقط جمع کن!");
    data.rewardGalaxyVisits++;
    data.m9 = Math.min(1, (data.m9||0) + 1);
}

function exitRewardGalaxy(){
    inRewardGalaxy = false;
    hide("rgBadge");
    shake(6, .25); flashScreen();
    tone(500, .2, "triangle", .06);
    setTimeout(() => tone(350, .3, "triangle", .05), 120);
    endEventCooldown();
    toast("🌌 کهکشان جایزه به پایان رسید. برگشتی به مسیر اصلی!");
}

function loop(t){
    if(dying){
        let dt = Math.max(0, Math.min((t - last) / 16.666, 2));
        last = t;
        deathT -= dt / 60;
        if(player){
            player.vy += 0.55 * dt;
            player.y += player.vy * dt;
        }
        if(shakeTime > 0){
            shakeTime -= dt/60;
            if(shakeTime <= 0) shakeMag = 0;
        }
        ctx.save();
        if(shakeTime > 0){
            ctx.translate((Math.random()-.5)*shakeMag, (Math.random()-.5)*shakeMag);
        }
        if(typeof drawBackground==='function') drawBackground(dt, speed);
        if(typeof drawGround==='function') drawGround();
        if(typeof drawPlayer==='function') drawPlayer();
        if(typeof updateParticles==='function') updateParticles(dt);
        if(typeof drawParticles==='function') drawParticles();
        ctx.restore();
        if(deathT <= 0){
            dying = false;
            const v = el("deathVeil"); if(v) v.classList.remove("show");
            finishGameOver(pendingWon);
            return;
        }
        rafId = requestAnimationFrame(loop);
        return;
    }
    if(!playing) return;
    if(typeof paused !== 'undefined' && paused){ last = t; rafId = rafId = requestAnimationFrame(loop); return; }
    let dt = Math.max(0, Math.min((t - last) / 16.666, 2));   // اولین فریم بعد از شروع ممکن است زمانی کمی قبل از last داشته باشد؛ dt هرگز منفی نمی‌شود
    last = t;

    if(slowTimer > 0){
        slowTimer -= dt / 60;
        dt *= 0.5; // slow motion effect
        el("slowBadge").classList.remove("hidden");
    } else {
        el("slowBadge").classList.add("hidden");
    }

    if(gameMode === "time"){
        modeTimer -= (dt*16.666)/1000;
        el("timeLeft").textContent = Math.max(0, Math.ceil(modeTimer));
        if(modeTimer <= 0){
            toast("⌛ پیروزی! زمان به پایان رسید! (+300 🟡 +5 💎)");
            data.coins += 300;
            addGems(5);
            gameOver(true); return;
        }
    }

    // Biomes setup - بایوم بیشتر؛ بایوم فضای طلایی از امتیاز 3000 به بعد تا پایان بازی باقی می‌ماند
    currentBiome = gameMode; bioUpdate(dt);

    let iceMul = (typeof iceStorm !== "undefined" && iceStorm) ? 0.7 : 1;
    let solarMul = (typeof solarFlare !== "undefined" && solarFlare) ? 1.20 : 1;
    let effSpeed = speed * (dashTimer > 0 ? 1.8 : 1) * iceMul * solarMul;
    const scoreMult = (scoreMultTimer > 0 || (typeof solarFlare !== "undefined" && solarFlare)) ? 2 : 1;

    score += .12 * effSpeed * dt * scoreMult;
    const speedCap = gameMode === "impossible" ? 20 : gameMode === "hard" ? 15 : 12;
    const speedBase = gameMode === "impossible" ? 8 : gameMode === "hard" ? 6.5 : 5;
    // منحنی نمایی: سرعت اول تندتر بالا می‌رود و هر چه امتیاز بیشتر شود شیب افزایش کندتر می‌شود،
    // اما هیچ‌وقت کاملاً صاف/ثابت نمی‌ماند تا در امتیازهای بالا هم همیشه کمی چالش تازه حس شود.
    // افزایش سرعت خیلی کندتر از قبل: رسیدن به سرعت نهایی فقط در امتیازهای خیلی بالا اتفاق می‌افتد
    const speedRamp = gameMode === "impossible" ? 7500 : gameMode === "hard" ? 9000 : 11000;
    speed = speedCap - (speedCap - speedBase) * Math.exp(-score / speedRamp);

    if(score < 0) score = 0;
    el("score").textContent = Math.floor(score);
    el("speed").textContent = effSpeed.toFixed(1);

    player.vy += (inBlackHole ? 0.3 : 0.68) * gravScale(dt) * dt;
    player.y += player.vy * dt;

    if(player.y >= player.ground - player.h){
        if(player.vy > 7 && !gfxLow()){ const jk = cxJumpKey(); if(jk) cxEmitJump(cxArr, jk, player.x + player.w / 2, player.ground, true, gfxPlus()); }
        player.y = player.ground - player.h; player.vy = 0; player.jumps = 0; jumpFallScale = 1; jumpApexDone = true;
    }

    { const tk = cxTrailKey(); if(tk) cxEmitTrail(cxArr, tk, player.x + 2, player.y + 40, dt, trailAcc, gfxLow() ? 0.5 : gfxMax() ? 1.25 : 1); }

    /* افکت‌های ذره‌ای اسکین‌های افسانه‌ای */
    if(data.skin === "nova" && Math.random() < 0.35){
        particlesArr.push({ x: player.x+15+(Math.random()*10-5), y: player.y+30+(Math.random()*10-5), vx:(Math.random()-.5)*2, vy:(Math.random()-.5)*2-1, life:1, size:2+Math.random()*3, type:"nova", hue:Math.random()*360 });
    } else if(data.skin === "cosmicking" && Math.random() < 0.3){
        particlesArr.push({ x: player.x-8, y: player.y+50, vx:-1-Math.random(), vy:(Math.random()-.5), life:1, size:2+Math.random()*3, type:"goldtrail" });
    } else if(data.skin === "phantom"){
        playerTrail.push({ x: player.x, y: player.y, life:1 });
        if(playerTrail.length > 6) playerTrail.shift();
    } else if(data.skin === "neptune" && Math.random() < 0.25){
        particlesArr.push({ x: player.x+10+(Math.random()*14-7), y: player.y+40+(Math.random()*14-7), vx:(Math.random()-.5)*1.2, vy:-0.6-Math.random()*0.6, life:1, size:1.5+Math.random()*2, type:"neptunefrost" });
    }
    if(playerTrail.length){
        playerTrail.forEach(t => t.life -= 0.15*dt);
        playerTrail = playerTrail.filter(t => t.life > 0);
    }

    if(magnetTime > 0){
        magnetTime -= dt / 60; player.magnet = true;
        el("magBadge").classList.remove("hidden");
        el("magTime").textContent = Math.max(0, magnetTime).toFixed(1);
    } else {
        player.magnet = false;
        el("magBadge").classList.add("hidden");
    }

    if(dashTimer > 0){
        dashTimer -= dt / 60;
        el("dashBadge").classList.remove("hidden");
    } else {
        el("dashBadge").classList.add("hidden");
    }

    if(player.shields > 0){
        el("shieldBadge").classList.remove("hidden");
        el("shieldVal").textContent = player.shields;
    } else {
        el("shieldBadge").classList.add("hidden");
    }

    el("comboBadge").classList.toggle("hidden", combo < 3);
    el("comboVal").textContent = combo;

    // هماهنگ‌کننده‌ی رویدادها: هیچ رویدادی وقتی رویداد دیگری فعال/در حال هشدار است شروع نمی‌شود،
    // و بعد از پایان هر رویداد یک مهلت کوتاه سپری می‌شود تا رویداد بعدی زنجیره‌ای و قابل‌پیش‌بینی نیاید.
    if(eventCooldown > 0) eventCooldown -= dt;
    const featuredKey = todaysFeaturedEvent().key;

    // بارش شهابی — پرتکرارترین رویداد بازی (کمی کمتر از قبل)
    eventTimer += dt;
    if(eventTimer > 1150 && !anyEventBusy() && eventCooldown <= 0){
        eventTimer = 0;
        if(Math.random() < 0.24) triggerEvent();
    }

    // سیاه‌چاله مرگ — نادرترین رویداد (هم‌رده کهکشان جایزه)
    if(pendingGuaranteedBH && score > 50 && !anyEventBusy() && eventCooldown <= 0){
        pendingGuaranteedBH = false;
        startBlackHoleWarning();
    }
    if(!anyEventBusy() && eventCooldown <= 0 && score > 1000){
        blackHoleCheckT += dt;
        if(blackHoleCheckT > 1900){
            blackHoleCheckT = 0;
            if(Math.random() < (featuredKey === "bh" ? 0.15 : 0.08) || (data.runsSinceBH||0) >= 8) startBlackHoleWarning();
        }
    }
    if(blackHoleWarning){
        blackHoleWarnT += dt;
        if(blackHoleWarnT > 150){ blackHoleWarnT = 0; enterBlackHole(); }
    }
    if(inBlackHole){
        el("bhProgress").textContent = Math.max(0, Math.floor(score - blackHoleEntryScore));
        if(score - blackHoleEntryScore >= 1000){ exitBlackHole(); }
    }

    // کهکشان جایزه — نادرترین رویداد (هم‌رده سیاه‌چاله مرگ)
    if(pendingGuaranteedRG && score > 50 && !anyEventBusy() && eventCooldown <= 0){
        pendingGuaranteedRG = false;
        startRewardGalaxyWarning();
    }
    if(!anyEventBusy() && eventCooldown <= 0 && score > 1000){
        rewardGalaxyCheckT += dt;
        if(rewardGalaxyCheckT > 1900){
            rewardGalaxyCheckT = 0;
            if(Math.random() < (featuredKey === "rg" ? 0.15 : 0.08) || (data.runsSinceRG||0) >= 8) startRewardGalaxyWarning();
        }
    }
    if(rewardGalaxyWarning){
        rewardGalaxyWarnT += dt;
        if(rewardGalaxyWarnT > 130){ rewardGalaxyWarnT = 0; enterRewardGalaxy(); }
    }
    if(inRewardGalaxy){
        el("rgProgress").textContent = Math.max(0, Math.floor(score - rewardGalaxyEntryScore));
        if(score - rewardGalaxyEntryScore >= REWARD_GALAXY_TARGET){ exitRewardGalaxy(); }
    }

    // بارش الماسی — کمیاب‌تر از شراره/یخ‌زدگی، ولی پرتکرارتر از سیاه‌چاله/کهکشان
    if(pendingGuaranteedDS && score > 50 && !anyEventBusy() && eventCooldown <= 0){
        pendingGuaranteedDS = false;
        triggerDiamondShower();
    }
    if(!anyEventBusy() && eventCooldown <= 0 && score > 300){
        diamondShowerCheckT += dt;
        if(diamondShowerCheckT > 1500){
            diamondShowerCheckT = 0;
            if(Math.random() < (featuredKey === "ds" ? 0.20 : 0.11)) triggerDiamondShower();
        }
    }
    if(diamondShowerActive){
        diamondShowerT -= dt;
        if(diamondShowerT <= 0){ diamondShowerActive = false; endEventCooldown(); }
    }
    el("showerBadge").classList.toggle("hidden", !diamondShowerActive);

    // پاورآپ امتیاز دوبل
    if(scoreMultTimer > 0){
        scoreMultTimer -= dt/60;
        el("multBadge").classList.remove("hidden");
    } else {
        el("multBadge").classList.add("hidden");
    }

    if(typeof extraTick === 'function') extraTick(dt, effSpeed);
    obstacleT += dt; coinT += dt; powerT += dt; boxT += dt; enemyT += dt; meteorT += (eventActive ? dt*2 : dt); shootStarT += dt; gemCoinT += dt;

    // در کهکشان جایزه هیچ مانعی وجود ندارد و سکه/الماس/آیتم/جعبه بسیار زیاد و پرشتاب می‌بارد
    const isAur = gameMode === "aurora", isImp = gameMode === "impossible";
    // غیرممکن: کمی موانع و دشمنان بیشتر (سخت: دست‌نخورده، فقط سرعتش زودتر بالا می‌رود)
    if(obstacleT > Math.max(isImp ? 31 : 34, (80 - speed * 2.2) * (isImp ? 0.92 : 1)) && !inRewardGalaxy){ obstacleT = 0; obstacle(); }
    // شفق قطبی: سکه‌ها، جعبه‌ها و پاورآپ‌های خیلی بیشتر
    if(coinT > (inRewardGalaxy ? 8 : (isAur ? 20 : 34))){ coinT = 0; coin(); }
    if(powerT > (inRewardGalaxy ? 90 : (data.fastPowerOn ? 220 : 320) * (isAur ? 0.55 : 1))){ powerT = 0; power(); }
    if(boxT > (inRewardGalaxy ? 130 : (data.luckyBoxOn ? 340 : 480) * (isAur ? 0.5 : 1))){ boxT = 0; box(); }
    if(enemyT > (isImp ? 290 : 380) && score > (isImp ? 380 : 500) && !inRewardGalaxy){ enemyT = 0; enemy(); }
    if(meteorT > (eventActive ? 140 : 550) && score > 800 && !inRewardGalaxy){ meteorT = 0; meteor(); }
    if(shootStarT > 260){ shootStarT = 0; if(Math.random() < .5) shootStar(); }
    if(gemCoinT > (inRewardGalaxy ? 60 : diamondShowerActive ? 25 : gameMode==='aurora' ? 260 : (data.gemLuck ? 520 : 850))){ gemCoinT = 0; gemCoin(); }
    if(gameMode === "time" && Math.random() < 0.05){ particles(Math.random()*W, Math.random()*H*0.6, 1, "coin"); }

    obstacles.forEach(o => o.x -= effSpeed * dt);
    
    // Strict Coin Mechanics: Missing even 1 coin resets streak (Combo)
    coins.forEach(c => {
        if(player.magnet){
            let dx = player.x + player.w/2 - c.x, dy = player.y + player.h/2 - c.y, d = Math.hypot(dx, dy);
            const MR = data.magRangeOn ? 1.4 : 1;
            if(d < 270 * MR && d > 1){
                let f = 1.4 + (270 * MR - d) / 25;
                // کشش همیشه روی حرکت پایه‌ی اسکرول اضافه می‌شه نه جایگزینش، تا سکه هیچ‌وقت عقب نره
                c.x += (dx / d * f - effSpeed) * dt; c.y += dy / d * f * dt;
            } else c.x -= effSpeed * dt;
        } else if(data.autoCollectOn){
            // ماهواره جمع‌کن: شعاع کوچک‌تر و ضعیف‌تر از آهنربا، ولی همیشه فعال
            let dx = player.x + player.w/2 - c.x, dy = player.y + player.h/2 - c.y, d = Math.hypot(dx, dy);
            if(d < 90 && d > 1){
                let f = 1.0 + (90 - d) / 30;
                c.x += (dx / d * f - effSpeed) * dt; c.y += dy / d * f * dt;
            } else c.x -= effSpeed * dt;
        } else c.x -= effSpeed * dt;
        c.spin += .1 * dt;

        if(c.x < -10 && !c.collected && !c.missed){
            c.missed = true;
            if(combo > 0 && !inRewardGalaxy){
                if(typeof comboArmor !== 'undefined' && comboArmor > 0){
                    comboArmor--;
                    floatText(player.x, player.y - 20, "زره زنجیره نجات داد!", "#9dffb0");
                    toast("🔗 زره زنجیره فعال شد");
                } else {
                    combo = 0;
                    floatText(player.x, player.y - 20, "زنجیره قطع شد!", "#ff4444");
                }
            }
        }
    });

    gemCoins.forEach(c => { c.x -= effSpeed * dt; c.spin += .12 * dt; });

    powers.forEach(p => { p.x -= effSpeed * dt; p.spin += .08 * dt; });
    boxes.forEach(b => { b.x -= effSpeed * dt; b.spin += .05 * dt; });
    
    // FIX ENEMY DODGED BUG: Track dodged enemies accurately
    enemies.forEach(e => {
        e.x -= effSpeed * dt; 
        if(e.type === "drone"){
            e.y = e.baseY + Math.sin(score*0.05)*30;
        } else {
            e.y += e.vy * dt;
            if(e.y < 70 || e.y > player.ground - 70) e.vy *= -1;
        }

        if(e.x + e.w < player.x && !e.dodged){
            e.dodged = true;
            data.enemiesDodged++;
            saveData();
        }
    });

    meteors.forEach(m => { m.x += m.vx * dt; m.y += m.vy * dt; });
    shootingStars.forEach(s => {
        s.x += s.vx*dt; s.y += s.vy*dt; s.life -= .01*dt;
        if(!s.got && player && Math.hypot(player.x+23-s.x, player.y+30-s.y) < 42){
            s.got = true; s.life = 0;
            runStars = (runStars||0) + 1; statInc("stars");
            score += 25;
            floatText(s.x, s.y, "⭐ +۲۵", "#ffd447");
            tone(980, .1, "sine", .05);
            haptic(12);
            const sb = el("starBadge"); if(sb){ sb.classList.remove("hidden"); }
            if(el("starVal")) el("starVal").textContent = (runStars % 3) || (runStars ? 3 : 0);
            if(runStars > 0 && runStars % 3 === 0){
                data.starSets = (data.starSets||0) + 1;
                magnetTime = Math.max(magnetTime, 4.5);
                player.magnet = true;
                addGems(1); runGems += 1;
                score += 60;
                toast("✨ صورت‌فلکی کامل! آهنربا + الماس");
                floatText(player.x, player.y-28, "صورت‌فلکی!", "#ffd447");
                if(el("starVal")) el("starVal").textContent = "3";
            }
        }
    });

    obstacles = obstacles.filter(o => o.x > -100);
    coins = coins.filter(c => c.x > -100);
    gemCoins = gemCoins.filter(c => c.x > -100);
    powers = powers.filter(p => p.x > -100);
    boxes = boxes.filter(b => b.x > -100);
    enemies = enemies.filter(e => e.x > -100);
    meteors = meteors.filter(m => m.x > -100 && m.y < H + 50);
    shootingStars = shootingStars.filter(s => s.life > 0 && s.y < H+50);

    ctx.save();
    if(shakeTime > 0){
        shakeTime -= dt/60;
        const sx = (Math.random()-.5) * shakeMag, sy = (Math.random()-.5) * shakeMag;
        ctx.translate(sx, sy);
        if(shakeTime <= 0) shakeMag = 0;
    }

    drawBackground(dt, effSpeed);
    drawGround();
    drawCoins();
    drawGemCoins();
    drawPowers();
    drawBoxes();
    drawEnemies();
    drawMeteors();
    drawObstacles();
    drawPlayerTrail();
    drawPlayer();
    updateParticles(dt);
    drawParticles();
    if(gfxPlus()) drawMaxForeground();
    if(typeof drawOverlays==='function') drawOverlays();
    ctx.restore();

    /* برخوردها با پشته‌سازی سپرها (Stackable Shields) */
    if(dashTimer <= 0 && (typeof ghostTimer==='undefined' || ghostTimer<=0) && (typeof invulnT==='undefined' || invulnT<=0)){
        for(const o of obstacles){
            if(hitP(o)){
                if(data.dodgeChanceOn && Math.random() < 0.20){
                    o.x = -500; statInc("dodgeSaves");
                    floatText(player.x, player.y-20, "😎 جاخالی!", "#00ffcc");
                    tone(500, .1, "sine", .05);
                } else if(player.shields > 0){
                    player.shields--; o.x = -500;
                    particles(player.x, player.y + 30, 20, "hit");
                    playHitSFX();
                    statInc("shieldSaves"); toast(`🛡️ سپر دفاع کرد! (باقی‌مانده: ${player.shields})`);
                } else {
                    particles(player.x, player.y + 30, 30, "hit");
                    playHitSFX();
                    gameOver(); return;
                }
            }
        }

        for(const e of enemies){
            if(hitP(e)){
                if(data.dodgeChanceOn && Math.random() < 0.20){
                    e.x = -500; statInc("dodgeSaves");
                    floatText(player.x, player.y-20, "😎 جاخالی!", "#00ffcc");
                    tone(500, .1, "sine", .05);
                }
                else if(e.type === "thief" && data.antiThiefOn){
                    e.x = -500; particles(player.x, player.y + 30, 10, "hit"); sfxThud(.4);
                    statInc("thiefBlocked"); floatText(player.x, player.y - 20, "🔒 دزد خنثی شد!", "#9dffb0");
                }
                else if(e.type === "thief"){
                    const stolen = Math.min(runCoins, Math.max(5, Math.floor(runCoins * 0.15)));
                    runCoins -= stolen; data.coins = Math.max(0, data.coins - stolen); statInc("thefts"); statInc("stolen", stolen);
                    e.x = -500;
                    particles(player.x, player.y + 30, 10, "hit");
                    sfxThud(.5);
                    floatText(player.x, player.y - 20, "-"+stolen+" 🟡 دزدیده شد!", "#ff8844");
                    toast("😈 دزد سکه چند تا سکه‌ات رو برد!");
                    el("coins").textContent = data.coins;
                }
                else if(player.shields > 0){ 
                    player.shields--; e.x = -500; playHitSFX(); 
                    statInc("shieldSaves"); toast(`🛡️ سپر دشمن را خنثی کرد! (باقی‌مانده: ${player.shields})`); 
                }
                else { playHitSFX(); gameOver(); return; }
            }
        }

        for(const m of meteors){
            if(Math.hypot(player.x + 23 - m.x, player.y + 30 - m.y) < m.r + meteorReach()){
                if(data.dodgeChanceOn && Math.random() < 0.20){
                    m.x = -500; statInc("dodgeSaves");
                    floatText(player.x, player.y-20, "😎 جاخالی!", "#00ffcc");
                    tone(500, .1, "sine", .05);
                } else if(player.shields > 0){ 
                    player.shields--; m.x = -500; playHitSFX(); 
                    statInc("shieldSaves"); toast(`🛡️ سپر شهاب‌سنگ را دفع کرد! (باقی‌مانده: ${player.shields})`); 
                }
                else { playHitSFX(); gameOver(); return; }
            }
        }
    } else {
        obstacles.forEach(o => { if(hit(player, o)){ o.x = -500; particles(o.x, o.y, 10, "flame"); } });
        enemies.forEach(e => { if(hit(player, e)){ e.x = -500; particles(e.x, e.y, 10, "flame"); } });
    }

    /* سکه‌ها */
    for(const c of coins){
        if(!c.collected && Math.hypot(player.x + 23 - c.x, player.y + 30 - c.y) < 34){
            c.collected = true;
            const wasSuper = c.super, cx = c.x, cy = c.y;
            statInc("coinPick"); if(wasSuper) statInc("goldCoins");
            c.x = -500;
            const gain = Math.round((data.coinX2On ? 2 : 1) * ((inBlackHole || inRewardGalaxy) ? 2 : 1) * (data.vip ? 2 : 1) * (wasSuper ? 10 : 1) * ((data.luckyUntil && Date.now() < data.luckyUntil) ? 1.5 : 1) * (iceStorm ? 1.35 : 1));
            runCoins += gain; data.coins += gain; data.totalCoins += gain;
            data.m1 = Math.min(90, data.m1 + 1);
            combo = combo + 1; comboTimer = 120; // زنجیره تا بی‌نهایت ادامه دارد
            data.bestCombo = Math.max(data.bestCombo, combo);
            score += (1 + Math.floor(combo / 5) * .25) * scoreMult;
            addXP(data.turboOn ? 4 : 3);
            particles(c.x, c.y, 8);
            pulse("badgeCoin");
            tone(780 + Math.min(combo,40)*10, .06, "triangle", .05);
            el("coins").textContent = data.coins;
            el("level").textContent = data.level;

            if(wasSuper){
                floatText(cx, cy-20, "💰 سکه‌ی طلایی ویژه! +"+gain, "#ffd447");
                tone(1300, .18, "triangle", .07);
            }

            if(combo % 10 === 0){
                dashTimer = dashDur(); statInc("superSpeed");
                haptic(25);
                floatText(c.x, c.y-20, "🔥 سرعت فوق‌العاده!", "#ff6a2b");
                toast("🔥 سرعت فوق‌العاده زنجیره‌ای! (×"+combo+")");
            } else if(combo === 5 || combo === 15 || combo === 25){
                toast("🔥 زنجیره ×"+combo+"!");
                floatText(c.x, c.y-20, "زنجیره ×"+combo, "#ff9c3d");
            } else if(combo >= 5 && combo % 5 === 0){
                floatText(c.x, c.y-20, "زنجیره ×"+combo, "#ff9c3d");
            }
        }
    }

    for(const g of gemCoins){
        if(Math.hypot(player.x + 23 - g.x, player.y + 30 - g.y) < 32){
            let gx = g.x, gy = g.y;
            g.x = -500;
            const gemGain = (inBlackHole || inRewardGalaxy || gameMode === "aurora") ? 2 : 1;
            addGems(gemGain); runGems += gemGain; statInc("gemPick");
            data.m5 = Math.min(18, (data.m5||0) + gemGain);
            particles(gx, gy, 12, "gem");
            pulse("badgeGem");
            floatText(gx, gy-20, "+"+gemGain+" 💎", "#64e7ff");
            tone(1100, .12, "sine", .05);
            el("gems").textContent = data.gems;
        }
    }

    /* پاورآپ */
    for(const p of powers){
        if(Math.hypot(player.x + 23 - p.x, player.y + 30 - p.y) < 40){
            p.x = -500; particles(p.x, p.y, 12); playPowerupSFX();
            if(p.type === 0){ 
                const maxS = data.shieldStack ? 3 : 1;
                player.shields = Math.min(maxS, player.shields + 1); 
                data.shieldPickups = (data.shieldPickups||0) + 1;
                toast(`🛡️ سپر اضافه شد! (مجموع: ${player.shields})`); 
            }
            else if(p.type === 1){ statInc("pBoost"); score += 100; floatText(p.x,p.y,"+100","#ffcc00"); toast("⚡ +100 امتیاز بوست!"); }
            else if(p.type === 2){ 
                magnetTime = data.longMag ? 10 : 7; 
                player.magnet = true; data.m3 = Math.min(5, data.m3 + 1); data.magnetUses++; toast("🧲 آهنربا فعال شد!"); 
            }
            else if(p.type === 3){
                let cleared = 0;
                obstacles.forEach(o => { if(o.x > player.x){ o.x=-500; cleared++; } });
                enemies.forEach(e => { if(e.x > player.x){ e.x=-500; cleared++; } });
                meteors.forEach(m => { if(m.x > player.x){ m.x=-500; cleared++; } });
                score += 50 + cleared*20;
                data.m4 = Math.min(4, data.m4 + 1); data.novaUses++;
                shake(10,.35);
                particles(W*.5, H*.4, 25, "coin");
                floatText(W*.5, H*.4, "💫 نوا بمب!", "#64e7ff");
                toast("💫 بمب نواختری فعال شد!");
            } else if(p.type === 4){
                slowTimer = 5 * pdMul();
                data.slowTimeUses = (data.slowTimeUses||0) + 1;
                toast("❄️ آهسته‌سازی زمان فعال شد!");
            } else if(p.type === 5){
                statInc("pX2");
                scoreMultTimer = 6 * pdMul();
                floatText(p.x, p.y, "×2 امتیاز", "#ffe066");
                toast("✨ امتیاز دوبل فعال شد!");
            } else if(p.type === 6){
                ghostTimer = 4.5 * pdMul();
                data.ghostUses = (data.ghostUses||0) + 1;
                floatText(p.x, p.y, "روح!", "#d7b3ff");
                toast("👻 حالت روح — از موانع رد شو");
            }
        }
    }

    /* جعبه‌ها */
    for(const b of boxes){
        if(hit(player, b)){
            b.x = -500; data.boxes++; let r = Math.random();
            const gemBoost = data.luckyBoxOn || inRewardGalaxy;
            if(r < 0.03){
                statInc("jackpots");
                data.coins += 300; runCoins += 300; addGems(8);
                floatText(b.x, b.y-10, "🎰 جایزه ویژه!", "#ffd447");
                toast("🎰 جایزه ویژه! +300 سکه +8 الماس");
            }
            else if(r < (gemBoost ? .45 : .60)){ data.coins += (gemBoost?40:25); runCoins += (gemBoost?40:25); toast("🎁 جعبه: +"+(gemBoost?40:25)+" سکه"); }
            else if(r < (gemBoost ? .85 : .88)){ addGems(gemBoost?2:1); toast("🎁 جعبه: +"+(gemBoost?2:1)+" الماس"); }
            else { spawnCoinBurst(); toast("🎁 باران سکه!"); }
            particles(b.x, b.y, 15); tone(900, .13, "triangle", .05);
            el("coins").textContent = data.coins;
            el("gems").textContent = data.gems;
        }
    }

    if(Math.floor(score) > data.best) data.best = Math.floor(score);
    data.m2 = Math.min(3500, Math.max(data.m2||0, Math.floor(score)));

    // Perf: don't hit localStorage every single frame - throttle persistence during gameplay
    saveThrottleT += dt;
    if(saveThrottleT > 45){ saveThrottleT = 0; saveData(); }
    if(particlesArr.length > 300) particlesArr.splice(0, particlesArr.length - 300);

    rafId = requestAnimationFrame(loop);
}


function drawBlackHoleBackground(dt, effSpeed){
    let g = ctx.createRadialGradient(W/2,H/2,0,W/2,H/2,Math.max(W,H)*0.8);
    g.addColorStop(0, "#1a002a"); g.addColorStop(0.5, "#050014"); g.addColorStop(1, "#000000");
    ctx.fillStyle = g; ctx.fillRect(0,0,W,H);

    bhSwirl += 0.01 * dt;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for(let i=0;i<3;i++){
        const rr = Math.max(W,H)*(0.25+i*0.18);
        ctx.save();
        ctx.translate(W/2,H/2); ctx.rotate(bhSwirl*(i%2===0?1:-1)); ctx.translate(-W/2,-H/2);
        const rg = ctx.createRadialGradient(W/2,H/2,rr*0.85,W/2,H/2,rr);
        rg.addColorStop(0, "rgba(150,50,220,0)");
        rg.addColorStop(0.5, `rgba(150,60,255,${0.05+i*0.02})`);
        rg.addColorStop(1, "rgba(150,50,220,0)");
        ctx.fillStyle = rg;
        ctx.beginPath(); ctx.arc(W/2,H/2,rr,0,Math.PI*2); ctx.fill();
        ctx.restore();
    }
    ctx.restore();

    stars.forEach(s => {
        if(playing){ s.x -= s.s * effSpeed * .12 * dt; if(s.x<0){ s.x=W; s.y=Math.random()*H; } }
        s.tw += .06*dt;
        ctx.globalAlpha = s.a * (0.5+0.5*Math.sin(s.tw));
        ctx.fillStyle = "#c68cff";
        ctx.beginPath(); ctx.arc(s.x,s.y,s.r,0,Math.PI*2); ctx.fill();
    });
    ctx.globalAlpha = 1;

    const vg = ctx.createRadialGradient(W/2,H/2,Math.max(W,H)*0.25,W/2,H/2,Math.max(W,H)*0.65);
    vg.addColorStop(0,"rgba(0,0,0,0)"); vg.addColorStop(1,"rgba(0,0,0,0.55)");
    ctx.fillStyle = vg; ctx.fillRect(0,0,W,H);
}


/* ===================== V80 TAIL: render, meta, shop, settings, IAP ===================== */
let paused = false, continuesThisRun = 0, jumpHeld = false;
let coyoteT = 0, jumpBufT = 0, ghostTimer = 0, invulnT = 0;
let solarFlare = false, solarWarn = false, solarT = 0, solarCheckT = 0;
let iceStorm = false, iceWarn = false, iceT = 0, iceCheckT = 0;
let comboArmor = 0, runMaxCombo = 0, runNearMiss = 0, runEvents = 0, runHits = 0;
let rafId = 0, satelliteAng = 0, satelliteZapT = 0, musicGain = null, sfxGain = null;
let lastMilestone = 0, pendingIap = null, pendingIapPrice = 0, pendingIapSku = "", pendingIapType = "", pendingIapPayload = "", groundScroll = 0;
let iapBusy = false, adBusy = false;
let dying = false, deathT = 0, pendingWon = false, gemContinuesThisRun = 0, adContinuesThisRun = 0;
let runDistanceAdded = 0; // هر ۱ امتیاز = ۱ متر؛ هر متر فقط یک‌بار به «کل مسافت» اضافه می‌شود
let scorePushed = false; // تا رکورد فقط یک‌بار و با امتیاز نهاییِ واقعیِ این دور (بعد از تمام‌شدن زنده‌شدن‌ها) ثبت شود
let skipDeathAnim = false, runStars = 0, pendingGuaranteedIce = false;


function hasNoAds(){ return !!(data.noAdsForever || (data.noAdsUntil && Date.now() < data.noAdsUntil)); }
function noAdsDaysLeft(){
    if(!hasNoAds()) return 0;
    return Math.max(0, Math.ceil((data.noAdsUntil - Date.now()) / 86400000));
}
function freeContinuesAllowed(){
    let n = 0;
    if(hasNoAds()) n += 1;
    if(data.vip) n += 1;
    return n;
}
function checkAdGemDay(){
    if(data.adGemDate !== today()){ data.adGemDate = today(); data.adGemsToday = 0; }
}
function adGemsLeft(){ checkAdGemDay(); return Math.max(0, 6 - (data.adGemsToday || 0)); }

function applyVolumes(){
    if(!masterGain || !audio) return;
    // صدای موزیک و افکت‌ها نسبت به قبل به‌طور محسوسی بلندتر شده (کمپرسور از اعوجاج جلوگیری می‌کند)
    const m = musicEnabled ? Math.pow(data.musicVol ?? 0.95, 1.25) * 10.0 : 0;
    const s = soundEnabled ? Math.pow(data.sfxVol ?? 0.95, 1.4) * 5.0 : 0;
    try{
        masterGain.gain.setTargetAtTime(1, audio.currentTime, 0.02);
        if(musicGain) musicGain.gain.setTargetAtTime(m, audio.currentTime, 0.02);
        if(sfxGain) sfxGain.gain.setTargetAtTime(s, audio.currentTime, 0.02);
    }catch(e){}
}

initAudio = function initAudio(){
    if(!audio){
        audio = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: "balanced" }); // بافر بزرگ‌تر = خش و قطع‌وصلیِ کمتر زیر بار
        masterGain = audio.createGain();
        musicGain = audio.createGain();
        sfxGain = audio.createGain();
        musicGain.connect(masterGain);
        sfxGain.connect(masterGain);
        try {
            const comp = audio.createDynamicsCompressor();
            comp.threshold.value = -18; comp.knee.value = 26; comp.ratio.value = 4; comp.attack.value = 0.006; comp.release.value = 0.28; // فشرده‌سازی نرم‌تر = کمتر پمپ و اعوجاج
            const lim = audio.createDynamicsCompressor(); // لیمیتر: قله‌های کیک و افکت‌ها دیگر از ۰ دسی‌بل رد نمی‌شوند
            lim.threshold.value = -3; lim.knee.value = 0; lim.ratio.value = 20; lim.attack.value = 0.001; lim.release.value = 0.1;
            const sat = audio.createWaveShaper(), n = 8192, cv = new Float32Array(n); // نرم‌کننده‌ی نهایی: هرگز برش سخت نداریم
            for(let i = 0; i < n; i++){ const x = i / (n - 1) * 2 - 1, ax = Math.abs(x), k = 0.9; cv[i] = ax < k ? x : Math.sign(x) * (k + (1 - k) * Math.tanh((ax - k) / (1 - k))); }
            sat.curve = cv;
            try { sat.oversample = "4x"; } catch(_){}   // برش نرم با نمونه‌برداری ×۴: بدون آلیاسینگ (یکی از دلایل اصلی «خش»)
            // پاک‌سازی سیگنال قبل از فشرده‌ساز: فرکانس‌های زیرِ شنوایی (که فقط حاشیه‌ی امنِ لیمیتر را می‌خورند) و هیسِ بالای ۱۶ کیلوهرتز
            const hp = audio.createBiquadFilter(); hp.type = "highpass"; hp.frequency.value = 24; hp.Q.value = 0.5;
            const shelf = audio.createBiquadFilter(); shelf.type = "highshelf"; shelf.frequency.value = 8500; shelf.gain.value = -2.2;
            const lp = audio.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 16000; lp.Q.value = 0.5;
            const mk = audio.createGain(); mk.gain.value = 1.08;   // جبران کمی افتِ بلندیِ فشرده‌ساز نرم
            masterGain.connect(hp); hp.connect(shelf); shelf.connect(lp); lp.connect(comp); comp.connect(mk); mk.connect(lim); lim.connect(sat); sat.connect(audio.destination);
        } catch(e){ try { masterGain.disconnect(); } catch(_){} masterGain.connect(audio.destination); }
        applyVolumes();
    }
    if(audio.state === "suspended"){
        try { const p = audio.resume(); if(p && p.catch) p.catch(() => {}); } catch(e){}
    }
    applyVolumes();
    if(musicEnabled) startMusic();
}

tone = function tone(frequency, duration=.09, type="sine", volume=.05, bus="sfx"){
    if(!soundEnabled || !audio || audio.state !== "running") return;
    volume = volume * SOUND_BOOST;
    try{
        const dest = bus === "music" ? (musicGain || masterGain) : (sfxGain || masterGain);
        const now = audio.currentTime;
        let ty = type;
        // موج اره‌ای/مربعیِ بم صدای ناخوشایند («بازی») می‌دهد؛ جایگزین نرم و تمیز
        if((ty === "sawtooth" || ty === "square") && frequency < 170) ty = "triangle";
        const oscillator = audio.createOscillator();
        const gain = audio.createGain();
        oscillator.type = ty;
        oscillator.frequency.value = frequency;
        let tail = oscillator;
        if(ty === "sawtooth" || ty === "square"){
            const lp = audio.createBiquadFilter();
            lp.type = "lowpass"; lp.frequency.value = Math.min(6500, Math.max(1200, frequency * 5)); lp.Q.value = 0.7;
            oscillator.connect(lp); tail = lp;
        }
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.linearRampToValueAtTime(volume, now + 0.004);
        gain.gain.exponentialRampToValueAtTime(.001, now + duration);
        tail.connect(gain);
        gain.connect(dest);
        oscillator.start(now);
        oscillator.stop(now + duration + 0.01);
        if(bus !== "music" && (ty === "sine" || ty === "triangle") && frequency >= 350 && frequency <= 3000){
            // هارمونیک دومِ کوتاه‌تر: صدا را شیشه‌ای و زیباتر می‌کند
            const o2 = audio.createOscillator(), g2 = audio.createGain();
            o2.type = "sine"; o2.frequency.value = frequency * 2;
            g2.gain.setValueAtTime(0.0001, now);
            g2.gain.linearRampToValueAtTime(volume * 0.28, now + 0.003);
            g2.gain.exponentialRampToValueAtTime(.001, now + duration * 0.6);
            o2.connect(g2); g2.connect(dest);
            o2.start(now); o2.stop(now + duration * 0.6 + 0.01);
        }
    }catch(e){}
}

hat = function hat(volume=.03){
    if(!soundEnabled || !audio || audio.state !== "running") return;
    volume = volume * SOUND_BOOST;
    try{
        const bufferSize = audio.sampleRate * 0.03;
        const buffer = audio.createBuffer(1, bufferSize, audio.sampleRate);
        const data0 = buffer.getChannelData(0);
        for(let i=0;i<bufferSize;i++) data0[i] = (Math.random()*2-1) * (1 - i/bufferSize);
        const src = audio.createBufferSource(); src.buffer = buffer;
        const filt = audio.createBiquadFilter(); filt.type = "highpass"; filt.frequency.value = 6000;
        const g = audio.createGain(); g.gain.value = volume;
        src.connect(filt); filt.connect(g); g.connect(sfxGain || masterGain);
        src.start();
    }catch(e){}
}

kick = function kick(volume=.09){
    if(!soundEnabled || !audio || audio.state !== "running") return;
    volume = volume * SOUND_BOOST;
    try{
        const osc = audio.createOscillator(); const gain = audio.createGain();
        const now = audio.currentTime;
        osc.frequency.setValueAtTime(120, now);
        osc.frequency.exponentialRampToValueAtTime(40, now + .12);
        gain.gain.setValueAtTime(volume, now);
        gain.gain.exponentialRampToValueAtTime(.001, now + .16);
        osc.connect(gain); gain.connect(sfxGain || masterGain);
        osc.start(now); osc.stop(now + .18);
    }catch(e){}
}

/* ===================================================================================
   موتور موسیقی حرفه‌ای برای ۳ گیم‌مود: تایم‌اتک، سخت و غیرممکن
   هر کدام آهنگ مستقل، تمپوی مستقل و سازبندی کامل (درام، باس، آرپژ، لید، پد و افکت‌های ریتمیک) دارد.
   قانون مهم صدا: هیچ موج اره‌ای/مربعی زیر ۱۱۰ هرتز وجود ندارد و هر اره‌ای از فیلتر پایین‌گذر رد می‌شود؛
   بم‌ها فقط سینوسی‌اند و همه‌ی نت‌ها شروع/پایان نرم دارند، پس هیچ صدای کثیف و «بازی» تولید نمی‌شود.
   =================================================================================== */
let proTimer = 0, proMode = null, proNext = 0, proStep = 0, proBus = null, proNoiseBuf = null, proRevIn = null, proIR = null;
let proBar = 0, proKickFull = false, proRateT = 0, proRateP = -1, proRate = 0, proPos = {}, proPausePos = null, proLive = [], proIRL = null, proCatchT = null, proHi = 1;
const PRO_RESUME = { classic:1, hard:1, impossible:1, aurora:1, time:1 };
const PRO_OFF = { classic:2.0, galaxy:0.56, impossible:1.45, aurora:0.8, ice:0.83 }; // بینهایت کمی بلندتر تا هم‌سطح تایم‌اتک شود
let proTrans = 0, proDrum = 1, proSt = 0, proSecG = null, proAgc = null, proAn = null, proBuf = null, proPw = 0, proAgDb = 0, proAgcT = 0;
const proMidi = m => 440 * Math.pow(2, (m + proTrans - 69) / 12);
function proNoise(){
    if(!proNoiseBuf){
        const n = Math.floor(audio.sampleRate * 2);
        proNoiseBuf = audio.createBuffer(1, n, audio.sampleRate);
        const d = proNoiseBuf.getChannelData(0);
        for(let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    }
    return proNoiseBuf;
}
function pOut(){ return proBus || musicGain || masterGain; }

function pVoice(freq, when, dur, type, vol, o){
    o = o || {};
    if((type === "sawtooth" || type === "square") && freq >= 200){
        type = "triangle"; o = Object.assign({}, o, { vib:0 });
        if(o.lp) o.lp = Math.min(o.lp, 1800);
        if(!o.pluck) o.a = Math.max(o.a || 0, 0.03);
    }
    if(proCatchT !== null && when < proCatchT){ // بازسازی صداهای کشیده‌ی میزان جاری هنگام ادامه
        const tail = o.r || 0.09, endT = when + dur + (o.pluck ? tail : 0), left = endT - proCatchT;
        if(o.pluck){ const f = left / (dur + tail); if(f < 0.2) return; vol *= f * f; dur = Math.max(0.06, left - tail); }
        else { if(when + dur <= proCatchT + 0.05) return; dur = when + dur - proCatchT; }
        when = proCatchT; o = Object.assign({}, o, { a: Math.min(o.a || 0.01, 0.015) }); delete o.from;
    }
    if(proMode && proMode !== "menu"){
        if(proHi < 1 && freq >= 520){ vol *= proHi; if(proHi < 0.05) return; }
        const now = audio.currentTime; let wp = 0; for(let q = 0; q < proLive.length; q++) if(proLive[q] > now) proLive[wp++] = proLive[q]; proLive.length = wp; // بدون ساختن آرایه‌ی جدید
        if(proLive.length > 56) return; // سقف صداهای هم‌زمان: روان‌تر روی گوشی‌های ضعیف
        proLive.push(when + dur + (o.r || 0.09));
    }
    vol *= SOUND_BOOST;
    const osc = audio.createOscillator(), g = audio.createGain();
    osc.type = type;
    if(o.from){ osc.frequency.setValueAtTime(o.from, when); osc.frequency.exponentialRampToValueAtTime(freq, when + (o.glide || 0.06)); }
    else osc.frequency.setValueAtTime(freq, when);
    if(o.detune) osc.detune.setValueAtTime(o.detune, when);
    let tail = osc;
    if(o.lp){
        const f = audio.createBiquadFilter();
        f.type = "lowpass"; f.Q.value = o.q || 0.8;
        f.frequency.setValueAtTime(o.lp, when);
        if(o.lpTo) f.frequency.exponentialRampToValueAtTime(o.lpTo, when + Math.max(0.03, dur));
        osc.connect(f); tail = f;
    }
    const a = o.a || 0.006, r = o.r || 0.09, end = when + dur + r;
    g.gain.setValueAtTime(0.0001, when);
    g.gain.linearRampToValueAtTime(vol, when + a);
    if(o.pluck) g.gain.exponentialRampToValueAtTime(0.0001, end);
    else { g.gain.setValueAtTime(vol, when + Math.max(a + 0.001, dur)); g.gain.exponentialRampToValueAtTime(0.0001, end); }
    if(o.vib){
        const l = audio.createOscillator(), lg = audio.createGain();
        l.frequency.setValueAtTime(o.vibRate || 5.5, when);
        lg.gain.setValueAtTime(o.vib, when);
        l.connect(lg); lg.connect(osc.detune);
        l.start(when); l.stop(end + 0.03);
    }
    tail.connect(g); g.connect(pOut());
    if(o.rev && proRevIn){ const sg = audio.createGain(); sg.gain.setValueAtTime(o.rev, when); g.connect(sg); sg.connect(proRevIn); }
    osc.start(when); osc.stop(end + 0.03);
}
function pNoise(when, dur, ftype, freq, vol, q, endFreq){
    if(proCatchT !== null && when < proCatchT){ const rem = when + dur - proCatchT; if(rem < 0.4) return; dur = rem; when = proCatchT; endFreq = undefined; }
    vol *= SOUND_BOOST;
    const src = audio.createBufferSource(); src.buffer = proNoise();
    const f = audio.createBiquadFilter();
    f.type = ftype; f.Q.value = q || 0.7;
    f.frequency.setValueAtTime(freq, when);
    if(endFreq) f.frequency.exponentialRampToValueAtTime(endFreq, when + dur);
    const g = audio.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.linearRampToValueAtTime(vol, when + 0.002);
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    src.connect(f); f.connect(g); g.connect(pOut());
    src.start(when, Math.random() * 0.8); src.stop(when + dur + 0.02);
}
function pKick(when, vol){
    const o = audio.createOscillator(), g = audio.createGain(), v = vol * SOUND_BOOST;
    o.type = "sine";
    o.frequency.setValueAtTime(160, when);
    o.frequency.exponentialRampToValueAtTime(46, when + 0.12);
    g.gain.setValueAtTime(0.0001, when);
    g.gain.linearRampToValueAtTime(v, when + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, when + 0.28);
    o.connect(g); g.connect(pOut());
    o.start(when); o.stop(when + 0.3);
    pNoise(when, 0.02, "highpass", 3000, vol * 0.22, 0.7);
}
function pSnare(when, vol){
    pNoise(when, 0.17, "bandpass", 1900, vol, 0.8);
    pVoice(190, when, 0.05, "triangle", vol * 0.7, { pluck:true, a:0.002, r:0.06 });
}
function pClap(when, vol){
    pNoise(when, 0.03, "bandpass", 1400, vol * 0.7, 1.0);
    pNoise(when + 0.012, 0.03, "bandpass", 1400, vol * 0.7, 1.0);
    pNoise(when + 0.026, 0.14, "bandpass", 1400, vol, 1.0);
}
function pHat(when, vol, open){ pNoise(when, open ? 0.22 : 0.045, "highpass", 7200, vol, 0.7); }
function pCrash(when, vol){ pNoise(when, 1.1, "highpass", 4200, vol, 0.6); }
function pRiser(when, dur, vol){
    vol *= SOUND_BOOST;
    const src = audio.createBufferSource(); src.buffer = proNoise(); src.loop = true;
    const f = audio.createBiquadFilter();
    f.type = "bandpass"; f.Q.value = 1.2;
    f.frequency.setValueAtTime(400, when);
    f.frequency.exponentialRampToValueAtTime(7000, when + dur);
    const g = audio.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.linearRampToValueAtTime(vol, when + dur * 0.96);
    g.gain.linearRampToValueAtTime(0.0001, when + dur);
    src.connect(f); f.connect(g); g.connect(pOut());
    src.start(when); src.stop(when + dur + 0.02);
}
function pBoom(when, vol){
    const o = audio.createOscillator(), g = audio.createGain(), v = vol * SOUND_BOOST;
    o.type = "sine";
    o.frequency.setValueAtTime(78, when);
    o.frequency.exponentialRampToValueAtTime(32, when + 0.9);
    g.gain.setValueAtTime(0.0001, when);
    g.gain.linearRampToValueAtTime(v, when + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, when + 1.1);
    o.connect(g); g.connect(pOut());
    o.start(when); o.stop(when + 1.15);
}

/* ---------- ⏳ تایم‌اتک — «مسابقه با زمان»: ۱۴۴ بیپیام، لا مینور، پرانرژی و حماسی + تیک‌تاک ساعت ---------- */
const TA_CH = {
    Am:{ sub:45, saw:57, t:[57,60,64] }, F:{ sub:41, saw:53, t:[53,57,60] },
    C:{ sub:48, saw:60, t:[55,60,64] },  G:{ sub:43, saw:55, t:[55,59,62] },
    E:{ sub:40, saw:52, t:[52,56,59] }
};
const TA_PROG = ["Am","F","C","G","Am","F","C","G","Am","F","C","G","F","G","Am","E"];
const TA_LEAD = [
    [[0,76,3],[3,74,1],[4,72,2],[6,74,2],[8,76,4],[12,81,4]],
    [[0,77,3],[3,76,1],[4,72,4],[8,76,2],[10,77,2],[12,81,2],[14,77,2]],
    [[0,79,3],[3,76,1],[4,72,2],[6,76,2],[8,79,4],[12,84,4]],
    [[0,79,3],[3,74,1],[4,71,2],[6,74,2],[8,79,2],[10,81,2],[12,79,4]],
    [[0,81,2],[2,84,2],[4,81,2],[6,77,2],[8,81,4],[12,77,4]],
    [[0,83,2],[2,79,2],[4,83,2],[6,86,2],[8,83,4],[12,79,4]],
    [[0,84,2],[2,81,2],[4,76,2],[6,81,2],[8,84,4],[12,88,4]],
    [[0,83,2],[2,80,2],[4,76,2],[6,80,2],[8,83,2],[10,80,2],[12,76,4]]
];
const TA_ARP = [0,1,2,3,2,1,2,1, 0,1,2,3,2,3,2,1];
function taStep(i, w, sd){
    const bar = Math.floor(i / 16) % 16, st = i % 16, ch = TA_CH[TA_PROG[bar]], barDur = sd * 16;
    if(st === 0){
        ch.t.forEach(n => [-7, 7].forEach(d => pVoice(proMidi(n), w, barDur * 0.92, "sawtooth", 0.0042, { lp:850, q:0.6, a:0.2, r:0.35, detune:d })));
        if(bar === 0 || bar === 8) pCrash(w, 0.026);
    }
    if(st % 4 === 0) pKick(w, 0.085);
    if(bar % 4 === 3 && st === 15) pKick(w, 0.05);
    if(st === 4 || st === 12){ pSnare(w, 0.045); if(bar >= 8) pClap(w, 0.016); }
    if(st % 4 === 2) pHat(w, 0.016, true); else pHat(w, (st % 2) ? 0.011 : 0.007, false);
    if([0,3,6,8,11,14].indexOf(st) >= 0){
        const dur = sd * (st === 14 ? 1.6 : 2.2), acc = (st === 0 || st === 8);
        pVoice(proMidi(ch.sub), w, dur, "sine", acc ? 0.05 : 0.04, { a:0.008, r:0.07 });
        pVoice(proMidi(ch.saw), w, dur, "sawtooth", acc ? 0.026 : 0.02, { lp:1500, lpTo:420, q:1.1, a:0.004, r:0.06, pluck:true });
    }
    const notes = [ch.t[0] + 12, ch.t[1] + 12, ch.t[2] + 12, ch.t[0] + 24], an = notes[TA_ARP[st]], aV = bar >= 8 ? 0.009 : 0.013;
    pVoice(proMidi(an), w, sd * 0.9, "square", aV, { lp:2800, q:0.7, a:0.003, r:0.04, pluck:true });
    pVoice(proMidi(an), w + sd * 3, sd * 0.9, "square", aV * 0.4, { lp:2000, a:0.003, r:0.04, pluck:true });
    const tickEvery = bar >= 12 ? 2 : 4;
    if(st % tickEvery === 0) pVoice((st % (tickEvery * 2) === 0) ? 2349 : 1760, w, 0.025, "sine", 0.008, { pluck:true, a:0.001, r:0.03 });
    if(bar >= 8){
        TA_LEAD[bar - 8].forEach(nt => {
            if(nt[0] === st){
                const d = nt[2] * sd * 0.92;
                [-8, 8].forEach(dt => pVoice(proMidi(nt[1]), w, d, "sawtooth", 0.0125, { lp:3300, q:1.0, a:0.012, r:0.1, detune:dt, vib:(nt[2] >= 3 ? 12 : 0), vibRate:5.5 }));
            }
        });
    }
    if(bar === 15 && st === 0) pRiser(w, barDur, 0.02);
    if((bar === 7 || bar === 15) && st >= 12) pSnare(w, 0.03 + (st - 12) * 0.012);
}

/* ---------- 💣 سخت — «سقوط»: ۱۲۴ بیپیام، ر مینور، تکنو صنعتی تاریک و دلهره‌آور ---------- */
const HD_CH = {
    Dm:{ sub:38, saw:50, t:[62,65,69] }, Bb:{ sub:46, saw:58, t:[58,62,65] },
    Gm:{ sub:43, saw:55, t:[55,58,62] }, A:{ sub:45, saw:57, t:[57,61,64] }
};
const HD_PROG = ["Dm","Bb","Gm","A","Dm","Bb","Gm","A","Dm","Bb","Gm","A","Bb","Gm","A","A"];
const HD_SYNC = [0,3,6,8,11,14];
function hdStep(i, w, sd){
    const bar = Math.floor(i / 16) % 16, st = i % 16, ch = HD_CH[HD_PROG[bar]], barDur = sd * 16;
    if(st === 0){
        ch.t.forEach(n => [-9, 9].forEach(d => pVoice(proMidi(n - 12), w, barDur * 0.95, "triangle", 0.0065, { lp:640, a:0.35, r:0.45, detune:d })));
        if(bar % 4 === 0) pBoom(w, 0.06);
        if(bar === 8) pCrash(w, 0.022);
        if(bar % 4 === 3){
            pVoice(proMidi(81), w + sd * 8, barDur * 0.45, "sine", 0.008, { a:0.35, r:0.5, vib:18 });
            pVoice(proMidi(87), w + sd * 8, barDur * 0.45, "sine", 0.006, { a:0.35, r:0.5, vib:18 });
        }
    }
    if(st % 4 === 0) pKick(w, 0.1);
    if(bar % 2 === 1 && st === 10) pKick(w, 0.06);
    if(st === 4 || st === 12){ pSnare(w, 0.05); pClap(w, 0.02); }
    if(st % 4 === 2) pHat(w, 0.015, true); else pHat(w, (st % 2) ? 0.011 : 0.007, false);
    if(st % 4 === 2 || (st === 15 && bar % 4 === 3)){
        const d = sd * (st === 15 ? 1 : 2.4);
        pVoice(proMidi(ch.sub), w, d, "sine", 0.052, { a:0.008, r:0.06 });
        pVoice(proMidi(ch.saw), w, d, "sawtooth", 0.027, { lp:1300, lpTo:380, q:1.4, a:0.004, r:0.05, pluck:true });
    }
    if(bar % 2 === 1 && st === 11) [523.25, 811, 1210].forEach((f, k) => pVoice(f, w, 0.08, "sine", 0.008 / (k + 1), { pluck:true, a:0.001, r:0.25 }));
    const hi = HD_SYNC.indexOf(st);
    if(bar >= 8 && hi >= 0){
        const n = ch.t[hi % 3] + (hi >= 3 ? 12 : 0);
        pVoice(proMidi(n), w, sd * 1.4, "sawtooth", 0.011, { lp:1900, lpTo:700, q:1.2, a:0.003, r:0.05, pluck:true });
        pVoice(proMidi(n), w + sd * 3, sd * 1.4, "sawtooth", 0.0045, { lp:1300, a:0.003, r:0.05, pluck:true });
    }
    if(((bar >= 4 && bar < 8) || bar >= 12) && (st === 0 || st === 6 || st === 10)){
        const len = st === 0 ? 5 : 2.2;
        ch.t.forEach(n => [-12, 12].forEach(d => pVoice(proMidi(n + 12), w, sd * len, "sawtooth", 0.0045, { lp:1500, q:0.8, a:0.01, r:0.12, detune:d })));
    }
    if(bar === 15 && st === 0) pRiser(w, barDur, 0.024);
    if((bar === 7 || bar === 15) && st >= 12) pSnare(w, 0.03 + (st - 12) * 0.012);
}

/* ---------- 💀 غیرممکن — «بی‌رحم»: ۱۵۶ بیپیام، می فریژین، گالوپ ۱۶‌تایی، آژیر و کر تاریک ---------- */
const IM_CH = {
    Em:{ sub:40, saw:52, t:[64,67,71] }, F:{ sub:41, saw:53, t:[65,69,72] },
    Bb:{ sub:46, saw:58, t:[70,74,77] }, B:{ sub:47, saw:59, t:[71,75,78] }
};
const IM_PROG = ["Em","F","Em","Bb","Em","F","Em","Bb","Em","F","Em","Bb","Em","F","Bb","B"];
const IM_RIFF = [0,0,null,0, 0,1,null,0, 0,0,null,6, 0,1,null,0];
const IM_LEAD = [
    [[0,76,2],[2,77,2],[4,76,2],[6,70,2],[8,76,2],[10,77,2],[12,82,4]],
    [[0,77,2],[2,76,2],[4,77,2],[6,72,2],[8,77,2],[10,81,2],[12,84,4]],
    [[0,76,2],[2,77,2],[4,76,2],[6,70,2],[8,76,2],[10,77,2],[12,82,4]],
    [[0,82,2],[2,81,2],[4,82,2],[6,77,2],[8,74,4],[12,70,4]],
    [[0,88,2],[2,87,2],[4,88,2],[6,83,2],[8,88,2],[10,86,2],[12,88,4]],
    [[0,77,2],[2,76,2],[4,77,2],[6,72,2],[8,77,2],[10,81,2],[12,77,4]],
    [[0,82,2],[2,81,2],[4,82,2],[6,77,2],[8,82,2],[10,84,2],[12,82,4]],
    [[0,83,2],[2,82,2],[4,83,2],[6,78,2],[8,83,2],[10,87,2],[12,83,2],[14,82,2]]
];
function imStep(i, w, sd){
    const bar = Math.floor(i / 16) % 16, st = i % 16, ch = IM_CH[IM_PROG[bar]], barDur = sd * 16;
    if(st === 0){
        ch.t.forEach(n => [-11, 0, 11].forEach(d => pVoice(proMidi(n - 12), w, barDur * 0.96, "sawtooth", 0.0032, { lp:560, q:0.7, a:0.5, r:0.4, detune:d })));
        if(bar % 4 === 0){ pBoom(w, 0.075); pCrash(w, 0.02); }
    }
    if(bar % 4 === 2 && st === 8) pVoice(proMidi(82), w, sd * 7, "sawtooth", 0.0095, { from:proMidi(76), glide:0.3, lp:2500, q:2, a:0.02, r:0.15, vib:30, vibRate:6 });
    if(st % 4 === 0 || (st === 6 && bar % 2 === 1) || (st === 14 && bar % 4 === 3)) pKick(w, 0.1);
    if(st === 4 || st === 12) pSnare(w, 0.055);
    if(bar % 4 === 3 && st === 15) pSnare(w, 0.04);
    if(st === 10) pHat(w, 0.018, true); else pHat(w, (st % 2) ? 0.013 : 0.008, false);
    const off = IM_RIFF[st];
    if(off !== null){
        const acc = (st % 4 === 0), d = sd * (acc ? 1.5 : 0.9);
        pVoice(proMidi(ch.saw + off), w, d, "sawtooth", acc ? 0.03 : 0.019, { lp:(acc ? 1700 : 900), lpTo:420, q:1.5, a:0.003, r:0.04, pluck:true });
        if(acc) pVoice(proMidi(ch.sub), w, sd * 3, "sine", 0.05, { a:0.006, r:0.06 });
    }
    if(bar >= 8){
        IM_LEAD[bar - 8].forEach(nt => {
            if(nt[0] === st){
                const d = nt[2] * sd * 0.92;
                [-10, 10].forEach(dt => pVoice(proMidi(nt[1]), w, d, "sawtooth", 0.0115, { lp:2700, q:1.3, a:0.006, r:0.07, detune:dt, vib:20, vibRate:6 }));
            }
        });
    }
    if(bar % 8 === 7 && st === 0) pRiser(w, barDur, 0.024);
    if(bar % 8 === 7 && st >= 8) pSnare(w, 0.03 + (st - 8) * 0.006);
}

/* ===================== آهنگ‌های حرفه‌ایِ بقیه‌ی بخش‌ها (منو، بی‌نهایت، شفق قطبی و رویدادها) ===================== */
function pPad(w, notes, dur, vol, o){
    o = o || {};
    notes.forEach(n => (o.dt || [-8, 8]).forEach(d => pVoice(proMidi(n), w, dur, o.type || "triangle", vol,
        { lp:o.lp || 900, q:0.6, a:o.a || 0.4, r:o.r || 0.5, detune:d, rev:o.rev, vib:o.vib, vibRate:o.vibRate })));
}
function pBell(w, m, vol, dur, rev){
    const f = proMidi(m); dur = dur || 0.9;
    pVoice(f, w, 0.01, "sine", vol, { pluck:true, a:0.002, r:dur, rev:rev });
    pVoice(f * 2, w, 0.01, "sine", vol * 0.32, { pluck:true, a:0.002, r:dur * 0.6, rev:rev });
    pVoice(f * 3.01, w, 0.01, "sine", vol * 0.12, { pluck:true, a:0.002, r:dur * 0.35, rev:rev });
}
function pPluck(w, m, vol, dur, o){
    o = o || {};
    pVoice(proMidi(m), w, dur, o.type || "triangle", vol, { pluck:true, lp:o.lp || 2400, q:0.8, a:0.003, r:o.r || 0.12, rev:o.rev, detune:o.detune });
}
function pShake(w, vol){ pNoise(w, 0.03, "highpass", 9000, vol, 0.7); }
function pGong(w, m, vol, dur, rev){
    const f = proMidi(m);
    [[1, 1], [2.76, 0.5], [5.4, 0.25], [8.9, 0.12]].forEach(p => pVoice(f * p[0], w, 0.02, "sine", vol * p[1], { pluck:true, a:0.004, r:dur / (1 + p[0] * 0.15), rev:rev }));
}
function leadAt(table, bar, st, fn){ (table[bar] || []).forEach(nt => { if(nt[0] === st) fn(nt); }); }

/* ---------- 🌙 منو — «آرامش کیهانی»: ۸۴ بیپیام، دو ماژور، پد گرم + آرپژ نرم + زنگ‌های شیشه‌ای ---------- */
const MN_CH = {
    C:{ b:48, pad:[55,59,64,67], arp:[64,67,71,76] }, Am:{ b:45, pad:[55,60,64,71], arp:[60,64,67,71] },
    F:{ b:41, pad:[57,60,64,69], arp:[60,64,65,69] },  G:{ b:43, pad:[59,62,64,67], arp:[62,64,67,71] }
};
const MN_PROG = ["C","Am","F","G","C","Am","F","G","C","Am","F","G","C","Am","F","G"];
const MN_P1 = [[[0,79,4],[6,76,2],[8,74,4],[12,72,4]], [[0,76,4],[6,72,2],[8,76,4],[12,81,4]], [[0,77,4],[6,81,2],[8,79,4],[12,77,4]], [[0,74,4],[6,79,2],[8,76,6]]];
const MN_P2 = [[[0,84,4],[6,79,2],[8,76,4],[12,79,4]], [[0,81,4],[6,76,2],[8,72,4],[12,76,4]], [[0,81,4],[6,77,2],[8,72,4],[12,77,4]], [[0,79,4],[6,74,2],[8,71,4],[12,74,4]]];
const MN_LEAD = [[],[],[],[]].concat(MN_P1, MN_P2, MN_P1);
function mnStep(i, w, sd){
    const bar = Math.floor(i / 16) % 16, st = i % 16, ch = MN_CH[MN_PROG[bar]], barDur = sd * 16;
    if(st === 0){
        pPad(w, ch.pad, barDur * 0.98, 0.009, { lp:800, a:0.5, r:0.7, rev:0.45 });
        pVoice(proMidi(ch.b), w, barDur * 0.45, "sine", 0.07, { a:0.02, r:0.5 });
    }
    if(st === 8) pVoice(proMidi(ch.b), w, sd * 5, "sine", 0.045, { a:0.02, r:0.4 });
    if(st === 0 || st === 8) pKick(w, 0.04);
    if(st % 4 === 2) pShake(w, 0.0055);
    if(st % 2 === 0) pPluck(w, ch.arp[[0,1,2,3,2,1,2,3][st / 2]], bar >= 4 ? 0.017 : 0.021, 0.35, { lp:1900, rev:0.4 });
    leadAt(MN_LEAD, bar, st, nt => pBell(w, nt[1], 0.013, nt[2] * sd * 0.35 + 0.8, 0.6));
    if(bar % 4 === 3 && st === 12) pBell(w, ch.arp[3] + 12, 0.006, 1.4, 0.8);
}

/* ---------- ♾️ بی‌نهایت — «پرواز آرام»: ۹۲ بیپیام، ر ماژور، گرووِ لوفای ملایم با کیبورد و لید نرم ---------- */
const CL_CH = {
    D:{ b:50, st:[54,57,61,66] }, Bm:{ b:47, st:[54,57,62,66] }, G:{ b:43, st:[50,54,59,62] }, A:{ b:45, st:[52,61,64,66] }
};
const CL_PROG = ["D","Bm","G","A","D","Bm","G","A","D","Bm","G","A","D","Bm","G","A"];
const CL_LEAD = [
    [[0,78,4],[4,81,2],[6,78,2],[8,76,4],[12,74,4]], [[0,74,4],[4,78,2],[6,81,2],[8,83,4],[12,81,4]],
    [[0,79,4],[4,83,2],[6,79,2],[8,76,4],[12,74,4]], [[0,81,4],[4,78,2],[6,76,2],[8,73,4],[12,76,4]]
];
function clStep(i, w, sd){
    const bar = Math.floor(i / 16) % 16, st = i % 16, ch = CL_CH[CL_PROG[bar]], barDur = sd * 16, sw = (st % 2) ? sd * 0.12 : 0;
    if(st === 0) pPad(w, ch.st.slice(0, 3), barDur * 0.98, 0.0055, { lp:900, a:0.35, r:0.5, rev:0.35 });
    if(st === 0 || st === 8) pKick(w, 0.05);
    if(st === 4 || st === 12) pSnare(w, 0.02);
    if(st % 2 === 0) pHat(w, (st % 4 === 2) ? 0.009 : 0.005, false);
    if(st % 2 === 1) pShake(w + sw, 0.0042);
    if(st === 0 || st === 7 || st === 10){
        const d = sd * (st === 0 ? 5 : 2.6);
        pVoice(proMidi(ch.b), w, d, "sine", 0.055, { a:0.01, r:0.08 });
        pVoice(proMidi(ch.b + 12), w, d, "triangle", 0.018, { lp:900, a:0.01, r:0.08, pluck:true });
    }
    if(st === 0 || st === 6 || st === 10) ch.st.forEach((n, k) => {
        pVoice(proMidi(n), w + k * 0.012, sd * 1.6, "triangle", 0.0085, { pluck:true, lp:2200, a:0.004, r:0.35, rev:0.3 });
        pVoice(proMidi(n + 12), w + k * 0.012, sd * 1.2, "sine", 0.0035, { pluck:true, a:0.004, r:0.3, rev:0.3 });
    });
    if(bar >= 8) leadAt(CL_LEAD, (bar - 8) % 4, st, nt => {
        const d = Math.min(nt[2] * sd * 0.9, sd * 4);
        pVoice(proMidi(nt[1]), w, d, "triangle", 0.0115, { pluck:true, a:0.006, r:0.5, lp:2300, rev:0.4 });
        pVoice(proMidi(nt[1]) * 2, w, 0.3, "sine", 0.0032, { pluck:true, a:0.004, r:0.2, rev:0.3 });
    });
    if(bar % 4 === 3 && st === 14) pBell(w, ch.st[2] + 24, 0.005, 1.0, 0.6);
}

/* ---------- 🌌 شفق قطبی — «رقص نور»: ۱۳۲ بیپیام، می مینور، ترنس پرانرژی با سوپرسا و زنگ‌های درخشان ---------- */
const AU_CH = {
    Em:{ sub:40, saw:52, t:[64,67,71] }, C:{ sub:48, saw:60, t:[60,64,67] }, G:{ sub:43, saw:55, t:[62,67,71] }, D:{ sub:50, saw:62, t:[62,66,69] }
};
const AU_PROG = ["Em","C","G","D","Em","C","G","D","Em","C","G","D","Em","C","G","D"];
const AU_LEAD = [
    [[0,83,4],[4,86,2],[6,83,2],[8,79,4],[12,83,4]], [[0,84,4],[4,83,2],[6,79,2],[8,76,4],[12,79,4]],
    [[0,86,4],[4,83,2],[6,86,2],[8,79,4],[12,83,4]], [[0,81,4],[4,86,2],[6,81,2],[8,78,4],[12,81,4]]
];
const AU_SHIM = [83, 86, 88, 91, 95];
function auStep(i, w, sd){
    const bar = Math.floor(i / 16) % 16, st = i % 16, ch = AU_CH[AU_PROG[bar]], barDur = sd * 16;
    if(st === 0){
        pPad(w, ch.t, barDur * 0.98, 0.0042, { type:"sawtooth", lp:1100, a:0.25, r:0.4, dt:[-10, 10], rev:0.3 });
        if(bar % 8 === 0) pCrash(w, 0.024);
    }
    if(st % 4 === 0) pKick(w, 0.085);
    if(st === 4 || st === 12){ pClap(w, 0.02); pSnare(w, 0.025); }
    if(st % 4 === 2) pHat(w, 0.014, true); else if(st % 2 === 1) pHat(w, 0.008, false);
    if(st % 4 !== 0){
        const acc = (st % 4 === 2);
        pVoice(proMidi(ch.saw), w, sd * 0.85, "sawtooth", acc ? 0.024 : 0.018, { lp:(acc ? 1300 : 800), lpTo:380, q:1.2, a:0.003, r:0.04, pluck:true });
    } else pVoice(proMidi(ch.sub), w, sd * 3, "sine", 0.05, { a:0.006, r:0.06 });
    const an = [ch.t[0] + 12, ch.t[1] + 12, ch.t[2] + 12, ch.t[0] + 24][[0,1,2,3,2,1,2,3, 0,1,2,3,2,3,2,1][st]], av = bar >= 8 ? 0.006 : 0.008;
    pVoice(proMidi(an), w, sd * 0.9, "sawtooth", av * 1.6, { lp:3600, q:0.7, a:0.003, r:0.05, pluck:true, rev:0.2 });
    if(bar >= 8) leadAt(AU_LEAD, (bar - 8) % 4, st, nt => {
        const d = nt[2] * sd * 0.92;
        pVoice(proMidi(nt[1]), w, d, "sawtooth", 0.015, { lp:4200, q:1.0, a:0.01, r:0.12, vib:(nt[2] >= 4 ? 14 : 0), vibRate:5.5, rev:0.3 });
    });
    if(bar >= 4 && (st === 3 || st === 7 || st === 11 || st === 14)) pBell(w, AU_SHIM[(bar * 7 + st * 3) % AU_SHIM.length], 0.0035, 1.2, 0.7);
    if(bar % 8 === 7 && st === 0) pRiser(w, barDur, 0.022);
    if(bar % 8 === 7 && st >= 8) pSnare(w, 0.025 + (st - 8) * 0.006);
}

/* ---------- 🕳️ سیاه‌چاله مرگ — «افق رویداد»: ۹۲ بیپیام، دو مینور با سوم کوچک و تریتون، ضربان قلب و دلهره ---------- */
const BH_CH = {
    Cm:{ t:[63,67,72], arp:[60,63,67,70] }, Db:{ t:[61,65,68], arp:[61,65,68,72] }, Gb:{ t:[66,70,73], arp:[66,70,73,78] }
};
const BH_PROG = ["Cm","Db","Cm","Gb","Cm","Db","Cm","Gb","Cm","Db","Cm","Gb","Cm","Db","Gb","Gb"];
const BH_OST = [0, 3, 6, 10, 12];
function bhStep(i, w, sd){
    const bar = Math.floor(i / 16) % 16, st = i % 16, ch = BH_CH[BH_PROG[bar]], barDur = sd * 16;
    if(st === 0){
        pVoice(proMidi(36), w, barDur * 0.99, "sine", 0.06, { a:0.6, r:0.6 });
        pVoice(proMidi(48), w, barDur * 0.99, "triangle", 0.016, { lp:520, a:0.6, r:0.6 });
        pPad(w, ch.t, barDur * 0.98, 0.0055, { lp:700, a:0.7, r:0.7, dt:[-14, 14], vib:22, vibRate:0.35, rev:0.6 });
        if(bar % 4 === 0) pGong(w, 72, 0.012, 3.2, 0.8);
        if(bar % 4 === 2) pNoise(w, 2.0, "bandpass", 2200, 0.0045, 3, 1400);
        if(bar % 8 === 0) pBoom(w, 0.07);
    }
    if(st === 0) pKick(w, 0.075);
    if(st === 3) pKick(w, 0.052);
    if(bar >= 4 && st === 8) pKick(w, 0.045);
    if(bar >= 4 && st === 11) pKick(w, 0.03);
    if(bar >= 2 && st % 2 === 0) pVoice(2500, w, 0.02, "sine", (st % 4 === 0) ? 0.008 : 0.005, { pluck:true, a:0.001, r:0.03 });
    const oi = BH_OST.indexOf(st);
    if(oi >= 0) pPluck(w, ch.arp[oi % 4], 0.014, 0.3, { lp:1000, rev:0.5 });
    if(bar % 2 === 1 && st === 6) pVoice(proMidi(80), w, sd * 8, "sine", 0.01, { from:proMidi(88), glide:sd * 8, a:0.3, r:0.5, vib:14, rev:0.7 });
    if(bar >= 8 && bar % 2 === 0 && st === 8) ch.t.forEach(n => [-12, 12].forEach(d => pVoice(proMidi(n), w, sd * 3, "sawtooth", 0.0048, { lp:900, q:0.8, a:0.04, r:0.3, detune:d, rev:0.4 })));
    if(bar % 8 === 7 && st === 0) pRiser(w, barDur, 0.02);
}

/* ---------- 🌟 کهکشان جایزه — «جشن ستارگان»: ۱۲۰ بیپیام، دو ماژور شاد، مالت و زنگ‌های جادویی ---------- */
const RG_CH = {
    C:{ b:48, pad:[64,67,72,76], arp:[72,76,79,84,88] }, G:{ b:43, pad:[62,67,71,74], arp:[71,74,79,83,86] },
    Am:{ b:45, pad:[64,69,72,76], arp:[72,76,81,84,88] }, F:{ b:41, pad:[65,69,72,77], arp:[72,77,81,84,89] }
};
const RG_PROG = ["C","G","Am","F","C","G","F","G","C","G","Am","F","C","G","F","C"];
const RG_LEAD = {
    C:[[0,84,2],[2,79,2],[4,76,2],[6,79,2],[8,84,4],[12,88,4]], G:[[0,83,2],[2,79,2],[4,74,2],[6,79,2],[8,83,4],[12,86,4]],
    Am:[[0,81,2],[2,76,2],[4,72,2],[6,76,2],[8,81,4],[12,84,4]], F:[[0,81,2],[2,77,2],[4,72,2],[6,77,2],[8,81,2],[10,84,2],[12,89,4]]
};
function rgStep(i, w, sd){
    const bar = Math.floor(i / 16) % 16, st = i % 16, key = RG_PROG[bar], ch = RG_CH[key], barDur = sd * 16;
    if(st === 0){
        pPad(w, ch.pad, barDur * 0.98, 0.0048, { lp:1400, a:0.15, r:0.4, rev:0.4 });
        if(bar % 8 === 0) pCrash(w, 0.022);
    }
    if(st % 4 === 0) pKick(w, 0.06);
    if(st === 4 || st === 12) pClap(w, 0.02);
    if(st % 2 === 1) pShake(w, 0.007);
    if(st % 4 === 2) pHat(w, 0.011, true);
    if(st % 2 === 0){
        pVoice(proMidi(ch.b), w, sd * 1.6, "sine", 0.05, { pluck:true, a:0.004, r:0.15 });
        pVoice(proMidi(ch.b + 12), w, sd * 1.4, "triangle", 0.018, { pluck:true, lp:1400, a:0.004, r:0.1 });
    }
    pPluck(w, ch.arp[[0,1,2,3,4,3,2,1, 0,1,2,3,4,3,2,4][st]], 0.009, 0.3, { type:"sine", lp:4000, rev:0.45 });
    (RG_LEAD[key] || []).forEach(nt => {
        if(nt[0] === st){
            pBell(w, nt[1], 0.012, 0.9, 0.5);
            if(nt[2] >= 4) pBell(w, nt[1] + 12, 0.004, 0.7, 0.6);
        }
    });
    if(bar % 4 === 3 && st >= 12) pBell(w, 84 + (st - 12) * 3, 0.007, 0.6, 0.5);
}

/* ---------- ☀️ شراره خورشیدی — «شعله‌ی خورشید»: ۱۴۸ بیپیام، ر مینور حماسی، ضرب سنگین، بوق‌های درخشان و لید قهرمانی ---------- */
const SL_CH = {
    Dm:{ sub:38, saw:50, t:[62,65,69] }, Bb:{ sub:46, saw:58, t:[58,62,65] }, C:{ sub:48, saw:60, t:[60,64,67] }, A:{ sub:45, saw:57, t:[57,61,64] }
};
const SL_PROG = ["Dm","Bb","C","Dm","Dm","Bb","C","A","Dm","Bb","C","Dm","Dm","Bb","C","A"];
const SL_LEAD = {
    Dm:[[0,81,3],[3,84,1],[4,86,4],[8,84,2],[10,81,2],[12,77,4]], Bb:[[0,82,3],[3,86,1],[4,89,4],[8,86,2],[10,82,2],[12,77,4]],
    C:[[0,84,3],[3,88,1],[4,86,4],[8,84,2],[10,79,2],[12,84,4]], A:[[0,85,3],[3,88,1],[4,85,4],[8,81,2],[10,85,2],[12,88,4]]
};
const SL_SYNC = [0,3,6,8,11,14];
function slStep(i, w, sd){
    const bar = Math.floor(i / 16) % 16, st = i % 16, key = SL_PROG[bar], ch = SL_CH[key], barDur = sd * 16;
    if(st === 0){
        pCrash(w, 0.03);
        pPad(w, ch.t, barDur * 0.95, 0.0045, { type:"sawtooth", lp:1200, a:0.1, r:0.3, dt:[-12, 12] });
        if(bar % 4 === 0) pBoom(w, 0.05);
    }
    if(st % 4 === 0) pKick(w, 0.1);
    if(st === 4 || st === 12){ pSnare(w, 0.058); pClap(w, 0.02); }
    if(st % 4 === 2) pHat(w, 0.017, true); else pHat(w, (st % 2) ? 0.012 : 0.008, false);
    if(st % 2 === 0){
        pVoice(proMidi(ch.sub), w, sd * 1.7, "sine", 0.05, { pluck:true, a:0.006, r:0.06 });
        pVoice(proMidi(ch.saw), w, sd * 1.6, "sawtooth", (st % 4 === 0) ? 0.028 : 0.02, { lp:1500, lpTo:450, q:1.2, a:0.003, r:0.04, pluck:true });
    }
    if(SL_SYNC.indexOf(st) >= 0){
        const len = (st === 0 || st === 8) ? 2.2 : 1.2;
        ch.t.forEach(n => [-10, 10].forEach(d => pVoice(proMidi(n + 12), w, sd * len, "sawtooth", 0.0055, { lp:2400, lpTo:1100, q:0.9, a:0.008, r:0.08, detune:d })));
    }
    if(bar >= 4) (SL_LEAD[key] || []).forEach(nt => {
        if(nt[0] === st){
            const d = nt[2] * sd * 0.92;
            pVoice(proMidi(nt[1]), w, d, "sawtooth", 0.012, { lp:3600, q:1.1, a:0.008, r:0.1, detune:-8, vib:(nt[2] >= 3 ? 16 : 0), vibRate:6 });
            pVoice(proMidi(nt[1]), w, d, "square", 0.006, { lp:2800, q:0.9, a:0.008, r:0.1, detune:8 });
        }
    });
    if(bar % 4 === 3 && st === 0) pRiser(w, barDur, 0.022);
    if(bar % 4 === 3 && st >= 12) pSnare(w, 0.03 + (st - 12) * 0.012);
}

/* ---------- ❄️ یخ‌زدگی کیهانی — «بلور یخ»: ۱۰۰ بیپیام، لا مینور با نُهم، زنگ‌های شیشه‌ای، باد سرد و پد بلورین ---------- */
const IC_CH = {
    Am:{ b:45, pad:[57,64,71,76], arp:[81,84,88,91] }, F:{ b:41, pad:[57,64,69,72], arp:[77,81,84,88] },
    C:{ b:48, pad:[55,64,67,71], arp:[79,84,88,91] }, G:{ b:43, pad:[57,62,67,74], arp:[79,83,86,91] }
};
const IC_PROG = ["Am","F","C","G","Am","F","C","G","Am","F","C","G","Am","F","C","G"];
const IC_LEAD = {
    Am:[[0,88,6],[8,84,4],[12,81,4]], F:[[0,84,6],[8,81,4],[12,77,4]], C:[[0,88,4],[6,84,2],[8,79,6]], G:[[0,86,6],[8,83,4],[12,79,4]]
};
function icStep(i, w, sd){
    const bar = Math.floor(i / 16) % 16, st = i % 16, key = IC_PROG[bar], ch = IC_CH[key], barDur = sd * 16;
    if(st === 0){
        pPad(w, ch.pad, barDur * 0.99, 0.006, { type:"sine", lp:3200, a:0.6, r:0.8, dt:[-6, 6], vib:10, vibRate:0.25, rev:0.7 });
        pVoice(proMidi(ch.b), w, barDur * 0.95, "sine", 0.05, { a:0.5, r:0.6 });
        pNoise(w, barDur * 0.9, "bandpass", 700 + (bar % 4) * 250, 0.0055, 2.5, 2400);
    }
    if(st === 0 || st === 8) pKick(w, 0.035);
    if(bar >= 4 && (st === 5 || st === 13)) pNoise(w, 0.012, "highpass", 9500, 0.006, 0.7);
    if(st % 2 === 0){
        const note = ch.arp[[0,1,2,3,2,1,3,2][st / 2]];
        pBell(w, note, 0.011, 1.1, 0.7);
        pBell(w + sd * 3, note, 0.0045, 0.8, 0.7);
    }
    if(bar >= 4) (IC_LEAD[key] || []).forEach(nt => { if(nt[0] === st) pBell(w, nt[1], 0.013, 1.6, 0.8); });
}

const PRO_TRACKS = {
    menu:       { bpm:84,  step:mnStep },
    classic:    { bpm:92,  step:clStep, blk:4 },
    aurora:     { bpm:132, step:auStep, blk:8 },
    time:       { bpm:144, step:taStep, one:{ plan:true, body:41, hold:33, outP:0.94, blk:8 } },
    hard:       { bpm:124, step:hdStep, blk:8 },
    impossible: { bpm:156, step:imStep, blk:8 },
    blackhole:  { bpm:92,  step:bhStep, one:{ body:13, hold:9, outP:0.76, blk:2 } },
    galaxy:     { bpm:120, step:rgStep, one:{ body:11, hold:7, outP:0.69, blk:2 } },
    solar:      { bpm:148, step:slStep, one:{ body:12, hold:8, outP:0.65, blk:2 } },
    ice:        { bpm:100, step:icStep, one:{ body:9, hold:5, outP:0.52, blk:2 } }
};

/* ===== موسیقی: چرخه‌ی ۹۶ میزانی با بخش‌های متنوع (تغییر ریتم/گام/چیدمان) + ولوم یکسان ===== */
const PRO_BARS = 96;
const PRO_PLAN = [
    { b:0, n:16, o:0, t:0, d:1 }, { b:8, n:8, o:0, t:0, d:1 }, { b:0, n:8, o:0, t:3, d:2 },
    { b:0, n:16, o:4, t:3, d:1 }, { b:4, n:8, o:0, t:0, d:3 }, { b:8, n:8, o:4, t:0, d:1 }
];
const PRO_TGT = 0.0008878462; // سطح هدفِ یکسان برای هر ۱۰ آهنگ
const PRO_SG = {"menu":[0.783,0.777,0.776,0.777,0.776,0.777,0.776,0.777,0.666,0.662,0.666,0.662,0.662,0.662,0.662,0.666,0.779,0.778,0.779,0.778,0.777,0.776,0.777,0.776],"classic":[0.91,0.889,0.883,0.89,0.888,0.896,0.89,0.895,0.733,0.733,0.734,0.734,0.734,0.736,0.733,0.736,0.896,0.892,0.891,0.888,0.882,0.89,0.886,0.893],"aurora":[0.542,0.533,0.541,0.539,0.505,0.504,0.534,0.531,0.473,0.471,0.479,0.478,0.472,0.45,0.472,0.478,0.536,0.507,0.539,0.541,0.504,0.506,0.532,0.533],"time":[0.746,0.734,0.734,0.81,0.729,0.848,0.832,1.025,0.655,0.66,0.63],"hard":[0.737,0.698,0.725,0.677,0.715,0.669,0.73,0.664,0.57,0.57,0.612,0.569,0.572,0.609,0.536,0.587,0.687,0.724,0.721,0.711,0.662,0.72,0.664,0.728],"impossible":[0.91,0.867,0.877,0.815,0.826,0.743,0.865,0.795,0.718,0.721,0.731,0.726,0.704,0.676,0.613,0.732,0.874,0.821,0.88,0.885,0.745,0.822,0.801,0.871],"blackhole":[1.073,1.094,1.027,1.038],"galaxy":[0.795,0.886,0.791,0.659],"solar":[0.868,0.979,0.765,0.806],"ice":[0.626,0.615,0.593]};
const proDr = (fn, kind) => (w, v, x) => {
    if(proCatchT !== null) return;
    const d = proDrum, s = proSt;
    if(d === 1) return fn(w, v, x);
    if(d === 0) return;
    if(proMode === "menu"){ // منو: دقیقاً مثل قبل
        if(d === 2){ if(kind === "k" ? s % 8 === 0 : kind === "s" ? s === 8 : s % 4 === 2) fn(w, v, x); return; }
        if(kind === "k" ? s % 8 === 0 : kind === "h" ? s % 4 === 2 : false) fn(w, v * 0.6, x);
        return;
    }
    if((kind === "k" || kind === "s") && proKickFull) return fn(w, v, x); // چهار حالت اصلی: دوپس (کیک) و ک (اسنیر/کلپ) تا آخر آهنگ ثابت می‌مانند
    const odd = proBar % 2; // سایر آهنگ‌ها: نیم‌ریتم و ریتم سبکِ واقعاً متفاوت
    if(d === 2){ if(kind === "k" ? (s === 0 || (odd === 1 && s === 10)) : kind === "s" ? s === 8 : s % 4 === 2) fn(w, v, x); return; }
    if(kind === "k" ? (s === 0 && odd === 0) : kind === "h" ? s % 4 === 2 : false) fn(w, v * 0.6, x);
};
pKick = proDr(pKick, "k"); pSnare = proDr(pSnare, "s"); pClap = proDr(pClap, "s"); pHat = proDr(pHat, "h");
{ const sh0 = pShake, shw = proDr(pShake, "h"); pShake = (w, v, x) => (proMode === "menu" ? sh0(w, v, x) : shw(w, v, x)); }
{ const c = pCrash, r = pRiser, b = pBoom;
  pCrash = (w, v) => { if(proDrum && proCatchT === null) c(w, v); };
  pRiser = (w, d, v) => { if(proDrum && proCatchT === null) r(w, d, proMode === "menu" ? v : v * 0.55); }; // صدای بلندشونده کمی آرام‌تر
  pBoom = (w, v) => { if(proDrum && proCatchT === null) b(w, v); }; }
function proAgcTick(){
    if(!proAn || !proAgc || !audio) return;
    const t = audio.currentTime; if(t - proAgcT < 0.12) return; proAgcT = t;
    proAn.getFloatTimeDomainData(proBuf);
    let s = 0; for(let k = 0; k < 2048; k++) s += proBuf[k] * proBuf[k];
    const p = s / 2048; proPw = proPw ? proPw * 0.96 + p * 0.04 : p;
    if(proPw < 1e-7) return;
    const err = Math.max(-6, Math.min(6, 10 * Math.log10(PRO_TGT * (PRO_OFF[proMode] || 1) / proPw)));
    proAgDb = Math.max(-9, Math.min(9, proAgDb + err * 0.03));
    try { proAgc.gain.setTargetAtTime(Math.pow(10, proAgDb / 20), t, 0.15); } catch(e){}
}
const PRO_VAR = [ { hi:1, d:1 }, { hi:0, d:1 }, { hi:1, d:2 }, { hi:0.45, d:3 } ]; // تنوع هر چند میزان: لایه‌ی بالا + ریتم
function proProg(m){ // پیشرفت واقعی رویداد/حالت (۰ تا ۱) برای هم‌زمانی پایان آهنگ
    try {
        if(m === "time") return 1 - Math.max(0, modeTimer) / 60;
        if(m === "solar") return 1 - Math.max(0, solarT) / 630;
        if(m === "ice") return 1 - Math.max(0, iceT) / 690;
        if(m === "blackhole") return (score - blackHoleEntryScore) / 1000;
        if(m === "galaxy") return (score - rewardGalaxyEntryScore) / REWARD_GALAXY_TARGET;
    } catch(e){}
    return -1;
}
// آهنگ تک‌پخش: همان مواد آهنگ قبلی، با طولِ مدت رویداد + حاشیه‌ی اطمینان، و پایان‌بندی همراه رویداد
function proOne(tr, i, w, sd, key){
    const o = tr.one, nB = o.body, catching = proCatchT !== null;
    let st = i % 16, tb = Math.floor(i / 16);
    if(!catching && st % 4 === 0){ // بررسی در هر ضرب
        const pg = proProg(key); let go = false;
        if(pg >= 0){
            const now = audio.currentTime; // سرعت واقعیِ پیشرفت رویداد (با کندکننده‌ی زمان و افت فریم هم درست کار می‌کند)
            if(proRateP < 0){ proRateP = pg; proRateT = now; }
            else if(now - proRateT >= 0.4){ const r = Math.max(0, (pg - proRateP) / (now - proRateT)); proRate = proRate > 0 ? proRate * 0.6 + r * 0.4 : r; proRateP = pg; proRateT = now; }
            go = proRate > 1e-4 ? (1 - pg) / proRate <= (w - now) + 32 * sd + 0.4 : pg >= o.outP;
        }
        if(go && tb < nB){ i = nB * 16; proStep = i; tb = nB; st = 0; }
        else if(st === 0 && pg >= 0 && !go && tb === nB){ i = o.hold * 16; proStep = i; tb = o.hold; }
    }
    let ib, t = 0, d = 1, hv = 1;
    if(tb < nB){
        if(o.plan){ const pl = PRO_PLAN[Math.floor(tb / 16)], k2 = tb % 16; ib = pl.b + ((k2 + pl.o) % pl.n); t = pl.t; d = pl.d; }
        else ib = Math.min(15, tb);
        const vb = PRO_VAR[Math.floor(tb / o.blk) % 4]; hv = o.plan ? vb.hi : 1; if(d === 1) d = vb.d; // رویدادها: فقط ریتم عوض می‌شود، ملودی همان می‌ماند
    } else if(tb === nB) ib = 15;
    else { ib = 0; if(st > 0) return; if(tb > nB + 1) d = 0; } // ضربه‌ی پایانی، سپس دنباله‌ی آرام تا آخر رویداد
    proTrans = t; proDrum = d; proHi = hv; proSt = st; proBar = tb; proKickFull = false;
    if(!catching && st === 0 && proSecG){
        try {
            const sg = PRO_SG[key], base = (sg && sg[Math.floor(Math.min(tb, nB + 1) / 4)]) || 1;
            proSecG.gain.setTargetAtTime(tb > nB + 1 ? base * 0.5 : base, Math.max(audio.currentTime, w - 0.12), 0.3);
        } catch(e){}
    }
    tr.step(ib * 16 + st, w, sd);
}
function proLong(tr, i, w, sd){
    if(tr.one) return proOne(tr, i, w, sd, proMode);
    const b = Math.floor(i / 16) % PRO_BARS, st = i % 16, sec = Math.floor(b / 16), k = b % 16, p = PRO_PLAN[sec];
    proTrans = p.t; proDrum = p.d; proSt = st; proHi = 1; proBar = b; proKickFull = (proMode !== "menu" && !!tr.blk);
    if(proMode !== "menu" && tr.blk){ const vb = PRO_VAR[Math.floor(b / tr.blk) % 4]; proHi = vb.hi; if(p.d === 1) proDrum = vb.d; }
    if(st === 0 && k % 4 === 0 && proSecG && proCatchT === null){
        const sg = PRO_SG[proMode]; const v = (sg && sg[Math.floor(b / 4)]) || 1;
        try { proSecG.gain.setTargetAtTime(v, Math.max(audio.currentTime, w - 0.12), 0.3); } catch(e){}
    }
    tr.step((p.b + ((k + p.o) % p.n)) * 16 + st, w, sd);
}
// کدام آهنگ الان باید پخش شود؟ (منو، حالت بازی یا رویداد در حال اجرا)
function currentMusicKey(){
    if(!playing) return "menu";
    if(inBlackHole) return "blackhole";
    if(inRewardGalaxy) return "galaxy";
    if(solarFlare) return "solar";
    if(iceStorm) return "ice";
    return PRO_TRACKS[gameMode] ? gameMode : "classic";
}
let audioSleeping = false, audioWasRunning = false;
function proEnsure(mode){
    if(audioSleeping) return;   // وقتی برنامه در پس‌زمینه است موسیقی جدید شروع نمی‌شود
    if(proMode === mode && proTimer) return;
    proStop();
    if(!audio || audio.state !== "running" || !PRO_TRACKS[mode]) return;
    proMode = mode; proStep = 0; proNext = audio.currentTime + 0.08;
    let q0 = 0;
    if(proPausePos && proPausePos.mode === mode) q0 = proPausePos.q; else if(PRO_RESUME[mode] && proPos[mode]) q0 = proPos[mode];
    proPausePos = null; proLive = []; proRateP = -1; proRate = 0;
    proBus = audio.createGain();
    proBus.gain.setValueAtTime(0.0001, audio.currentTime);
    proBus.gain.linearRampToValueAtTime(1, audio.currentTime + (q0 > 0 ? 0.05 : 0.35));
    proSecG = audio.createGain();
    { const sg = PRO_SG[mode]; proSecG.gain.setValueAtTime((sg && sg[0]) || 1, audio.currentTime); }
    proBus.connect(proSecG); proAgc = audio.createGain(); proSecG.connect(proAgc); proAgc.connect(musicGain || masterGain);
    proPw = 0; proAgDb = 0; proAgcT = 0; proAn = null;
    try { // اندازه‌گیری زنده‌ی بلندی (با وزن‌دهی شبیه گوش) برای ولوم کاملاً یکسان بین همه‌ی آهنگ‌ها
        proAn = audio.createAnalyser(); proAn.fftSize = 2048; proBuf = new Float32Array(2048);
        const hp = audio.createBiquadFilter(); hp.type = "highpass"; hp.frequency.value = 150;
        const sh = audio.createBiquadFilter(); sh.type = "highshelf"; sh.frequency.value = 1600; sh.gain.value = 4;
        proAgc.connect(hp); hp.connect(sh); sh.connect(proAn);
    } catch(e){ proAn = null; }
    try {
        if(mode === "menu" && !proIR){
            const len = Math.floor(audio.sampleRate * 1.7);
            proIR = audio.createBuffer(2, len, audio.sampleRate);
            for(let ch = 0; ch < 2; ch++){ const d = proIR.getChannelData(ch); for(let k = 0; k < len; k++) d[k] = (Math.random() * 2 - 1) * Math.pow(1 - k / len, 2.6); }
        }
        if(mode !== "menu" && !proIRL){ const len = Math.floor(audio.sampleRate * 1.1); proIRL = audio.createBuffer(1, len, audio.sampleRate); const d = proIRL.getChannelData(0); for(let k = 0; k < len; k++) d[k] = (Math.random() * 2 - 1) * Math.pow(1 - k / len, 2.8); }
        const conv = audio.createConvolver(); conv.buffer = mode === "menu" ? proIR : proIRL;
        proRevIn = audio.createGain(); proRevIn.gain.setValueAtTime(1, audio.currentTime);
        const revOut = audio.createGain(); revOut.gain.setValueAtTime(0.55, audio.currentTime);
        proRevIn.connect(conv); conv.connect(revOut); revOut.connect(proBus);
    } catch(e){ proRevIn = null; }
    if(q0 > 0.5){ // ادامه دقیقاً از همان لحظه‌ی قطع شدن (با بازسازی صداهای کشیده‌ی میزان جاری)
        const tr0 = PRO_TRACKS[mode], sd0 = 60 / tr0.bpm / 4, s0 = Math.ceil(q0 - 1e-6), b0 = Math.max(0, Math.floor((s0 - 1) / 16) * 16);
        proStep = s0; proCatchT = proNext; proNext = proCatchT + (s0 - q0) * sd0;
        for(let k = b0; k < s0; k++){ try { proLong(tr0, k, proNext - (s0 - k) * sd0, sd0); } catch(e){} }
        proCatchT = null;
    }
    proTimer = setInterval(proPump, 50);
}
function proCurQ(){
    if(!proMode || !audio || !PRO_TRACKS[proMode]) return 0;
    return Math.max(0, proStep - Math.max(0, proNext - audio.currentTime) / (60 / PRO_TRACKS[proMode].bpm / 4));
}
function proPauseSave(){ if(proMode) proPausePos = { mode: proMode, q: proCurQ() }; proStop(); }
function proIsPaused(){ try { return !!(playing && paused); } catch(e){ return false; } }
function proStop(){
    if(proMode && proTimer && PRO_RESUME[proMode]) proPos[proMode] = proCurQ();
    if(proTimer){ clearInterval(proTimer); proTimer = 0; }
    if(proBus && audio){
        const b = proBus;
        try { b.gain.cancelScheduledValues(audio.currentTime); b.gain.setTargetAtTime(0, audio.currentTime, 0.04); } catch(e){}
        const sgn = proSecG, agn = proAgc; setTimeout(() => { try { b.disconnect(); if(sgn) sgn.disconnect(); if(agn) agn.disconnect(); } catch(e){} }, 700);
    }
    proSecG = null; proAgc = null; proAn = null; proBus = null; proMode = null; proRevIn = null;
}
function proPump(){
    if(!audio || !proMode || audio.state !== "running") return;
    if(proIsPaused()){ proPauseSave(); return; }
    const tr = PRO_TRACKS[proMode]; if(!tr) return;
    proAgcTick();
    const sd = 60 / tr.bpm / 4;
    if(proNext < audio.currentTime - 0.12) proNext = audio.currentTime + 0.05;
    let guard = 0;
    while(proNext < audio.currentTime + 0.5 && guard++ < 24){
        try { proLong(tr, proStep, proNext, sd); } catch(e){}
        proNext += sd; proStep++;
    }
}

startMusic = function startMusic(){
    if(musicTimer || !musicEnabled) return;
    musicTimer = setInterval(() => {
        if(!musicEnabled) return;
        if(!audio || audio.state !== "running") return;
        if(playing && paused){ if(proMode) proPauseSave(); return; }
        proEnsure(currentMusicKey());
    }, 120);
}

function currentRank(){
    const lv = data.level | 0;
    if(lv >= 100) return "جاودانه کیهانی";
    if(lv >= 70) return "خدای ستارگان";
    if(lv >= 50) return "فاتح کهکشان";
    if(lv >= 40) return "افسانه کیهان";
    if(lv >= 30) return "امپراتور مدار";
    if(lv >= 22) return "فرمانده کهکشان";
    if(lv >= 16) return "ناخدای ستاره";
    if(lv >= 12) return "خلبان ارشد";
    if(lv >= 8) return "کاوشگر فضا";
    if(lv >= 5) return "فضانورد";
    if(lv >= 3) return "کارآموز مدار";
    return "تازه‌وارد";
}

const ALL_SCREENS = ["recCreate","recRestore","menu","shop","customize","offers","missions","ach","stats","daily","over","levelUp","wheel","leaderboard","settings","pauseMenu","codex","iapBox","howto","about"];

function setSkin(key){
    if(!ownsItem("skin", key)) return;
    data.skin = key; save(); toast("اسکین انتخاب شد");
}
function buySkin(key, flag, price, currency){
    if(currency === "gems"){
        if(data.gems < price){ toast("الماس کافی نیست"); return; }
        data.gems -= price; statInc("gemsSpent", price);
    } else {
        if(data.coins < price){ toast("سکه کافی نیست"); return; }
        data.coins -= price; statInc("coinsSpent", price);
    }
    data[flag] = true; data.skin = key; save(); toast("اسکین جدید مال تو شد!");
}

/* اجرای playAd در بالای فایل فقط از callback تأییدشده‌ی لایه‌ی بومی پاداش می‌دهد. */

function grantRoyalPack(equip){
    data.vip = true;
    data.skinCosmicKing = true;
    data.auraOwned = data.auraOwned || {};
    data.startFxOwned = data.startFxOwned || {};
    data.trailOwned = data.trailOwned || {};
    data.jumpEffectOwned = data.jumpEffectOwned || {};
    data.groundThemeOwned = data.groundThemeOwned || {};
    data.filterOwned = data.filterOwned || {};
    data.auraOwned.royal = true;
    data.startFxOwned.royal = true;
    data.trailOwned.royal = true;
    data.jumpEffectOwned.royal = true;
    data.groundThemeOwned.royal = true;
    data.filterOwned.royal = true;
    data.satellite = true;
    data.satelliteOwned = true;
    if(equip){
        data.skin = "cosmicking";
        data.aura = "royal";
        data.startFx = "royal";
        data.trailColor = "royal";
        data.jumpEffect = "royal";
        data.groundTheme = "royal";
        data.envFilter = "royal";
        data.decorOn = data.decorOn || {}; data.decorOn.sun = true;   // خورشید VIP هم با خرید عضویت روشن می‌شود
    }
}

function openIap(title, desc, price, sku, productType, onOk){
    if(iapBusy) return;
    const safeSku = String(sku || "");
    const safeType = String(productType || "");
    if(!/^sr_[a-z0-9_]+$/.test(safeSku) || !["consumable", "non_consumable"].includes(safeType) || typeof onOk !== "function"){
        toast("شناسه محصول خرید معتبر نیست؛ خرید باز نشد."); return;
    }
    iapReturn = (curScreenId === "customize" || curScreenId === "offers") ? curScreenId : "shop";
    pendingIap = onOk;
    pendingIapPrice = Number(price) || 0;
    pendingIapSku = safeSku;
    pendingIapType = safeType;
    pendingIapPayload = "srp1_" + safeSku + "_" + Date.now().toString(36) + "_" + securePurchaseToken(18);
    el("iapTitle").textContent = title;
    el("iapDesc").textContent = desc + " — قیمت مرجع: " + faPrice(price) + " تومان. تأیید خرید و قیمت نهایی در پنجره رسمی مایکت انجام می‌شود." +
        (nativeBridgeAvailable() ? "" : " برای پرداخت واقعی، نسخه اندرویدیِ متصل به SDK مایکت لازم است.");
    const confirm = el("iapConfirm"); if(confirm){ confirm.textContent = "خرید از مایکت"; confirm.disabled = false; }
    const cancel = el("iapCancel"); if(cancel) cancel.disabled = false;
    openScreen("iapBox");
}
function purchaseVipIAP(){
    openIap("عضویت VIP کیهانی", "پک شاهانه: اسکین پادشاه، هاله تاج، ورود شاهانه، زمین تخت، دنباله و پرش سلطنتی + سکه دوبل + سپر رایگان + ۲ چرخش روزانه", 199000, storeSku("vip", "royal"), "non_consumable", () => {
        grantRoyalPack(true);
        save(); toast("👑 به دربار کیهانی خوش آمدی!");
        openScreen(iapReturn || "shop"); updateUI();
    });
}
function purchaseNoAdsIAP(){
    openIap("حذف تبلیغات همیشگی", "یک‌بار خرید، تا همیشه. زنده شدن رایگان: ۱ بار در هر دور (با VIP می‌شود ۲ بار). جایزه‌های تبلیغاتیِ پشتیبانی‌شده بدون نمایش ویدیو در دسترس می‌مانند.", 99000, storeSku("no", "ads", "forever"), "non_consumable", () => {
        data.noAdsForever = true; data.noAdsUntil = 0; data.noAds = false;
        save(); toast("🚫 تبلیغات برای همیشه حذف شد");
        openScreen(iapReturn || "shop"); updateUI(); updateShop();
    });
}
function purchaseSkinIAP(name, key, price){
    openIap("اسکین " + name, "اسکین ویژه با افکت اختصاصی", price, storeSku("item", "skin", key), "non_consumable", () => {
        data["skin"+name] = true; data.skin = key; save(); toast("اسکین ویژه فعال شد");
        openScreen(iapReturn || "shop"); updateUI();
    });
}
function purchaseGemsIAP(gems, price){
    openIap("بسته الماس", gems + " الماس", price, storeSku("gems", gems, price), "consumable", () => {
        addGems(gems); save(); toast("+" + gems + " الماس");
        openScreen(iapReturn || "shop"); updateUI();
    });
}
function purchaseGroundIAP(key, price, name){
    openIap("زمین " + name, "زمین ویژه فقط بصری — الان خیلی درخشان‌تر از قبل", price, storeSku("item", "ground", key), "non_consumable", () => {
        data.groundThemeOwned[key] = true; data.groundTheme = key; save(); toast("زمین ویژه فعال شد");
        openScreen(iapReturn || "shop"); updateUI();
    });
}
function purchaseAuraIAP(key, price, name){
    openIap("هاله " + name, "هاله همراه با افکت غلیظ‌تر", price, storeSku("item", "aura", key), "non_consumable", () => {
        data.auraOwned[key] = true; data.aura = key; save(); toast("هاله فعال شد");
        openScreen(iapReturn || "shop"); updateUI();
    });
}
async function confirmIapPurchase(){
    if(iapBusy || !pendingIap) return;
    if(!nativeBridgeAvailable()){
        toast("پرداخت انجام نشد: اتصال بومی مایکت در این نسخه وجود ندارد."); return;
    }
    const grant = pendingIap, sku = pendingIapSku, type = pendingIapType, payload = pendingIapPayload, priceHint = pendingIapPrice;
    if(!sku || !payload || !["consumable", "non_consumable"].includes(type)){ toast("اطلاعات خرید ناقص است."); return; }
    const confirm = el("iapConfirm"), cancel = el("iapCancel");
    iapBusy = true;
    if(confirm){ confirm.disabled = true; confirm.textContent = "در انتظار پاسخ مایکت…"; }
    if(cancel) cancel.disabled = true;
    try{
        const result = await callSpaceRunnerNative("purchase", { productId:sku, productType:type, developerPayload:payload, priceHintToman:priceHint }, 180000);
        const needsGrantJournal = type === "consumable" || sku.startsWith("sr_pack_") || sku.startsWith("sr_offer_");
        const valid = result.ok === true && result.status === "purchased" && result.verified === true &&
            result.productId === sku && result.productType === type && result.developerPayload === payload &&
            (type !== "consumable" || result.consumed === true) &&
            (!needsGrantJournal || (typeof result.grantId === "string" && result.grantId.length >= 8));
        if(!valid){
            if(result.status === "pending"){
                toast("خرید ثبت شده اما تحویل در حال تکمیل است؛ وضعیت دوباره همگام می‌شود.");
                await syncNativeEntitlements();
            }else if(result.status === "cancelled") toast("خرید لغو شد؛ چیزی به حساب اضافه نشد.");
            else toast("خرید از مایکت تأیید نشد؛ چیزی به حساب اضافه نشد.");
            return;
        }
        pendingIap = null; pendingIapPrice = 0; pendingIapSku = ""; pendingIapType = ""; pendingIapPayload = "";
        hide("iapBox");
        statInc("purchases");
        const actualPrice = Number(result.priceToman);
        if(Number.isFinite(actualPrice) && actualPrice > 0) statInc("tomanSpent", actualPrice);
        // پاداش‌های یک‌باره (الماس، پک و پیشنهاد) از صفِ قابل‌بازیابیِ لایه بومی تحویل می‌شوند.
        if(needsGrantJournal){
            const journalGrant = { grantId:result.grantId, productId:sku };
            if(!applyPendingNativePurchaseGrant(journalGrant)) throw new Error("native_grant_not_applied");
            if(sku.startsWith("sr_gems_")) toast("✅ بسته الماس به حساب اضافه شد.");
            else if(sku.startsWith("sr_pack_")) toast("🎁 پک خریداری و تحویل شد.");
            else toast("🎁 پیشنهاد خریداری و تحویل شد.");
            if(sku.startsWith("sr_offer_")) openScreen("offers");
            else openScreen(iapReturn || (sku.startsWith("sr_pack_") ? "customize" : "shop"));
            updateUI(); updateExtraUI(); updateOffersBadge();
            await acknowledgeNativePurchaseGrant(journalGrant);
        }else{
            grant();
        }
    }catch(error){
        if(error && error.code === "NATIVE_BRIDGE_UNAVAILABLE") toast("اتصال مایکت در این نسخه در دسترس نیست.");
        else if(error && error.code === "NATIVE_REQUEST_TIMEOUT") toast("پاسخی از مایکت دریافت نشد؛ وضعیت خرید را در مایکت بررسی کن.");
        else toast("ارتباط با مایکت ناموفق بود؛ خریدی ثبت نشد.");
    }finally{
        iapBusy = false;
        if(confirm){ confirm.disabled = false; confirm.textContent = "خرید از مایکت"; }
        if(cancel) cancel.disabled = false;
    }
}

function extraStart(){
    statsRunStart();
    continuesThisRun = 0; gemContinuesThisRun = 0; adContinuesThisRun = 0; scorePushed = false; runDistanceAdded = 0; shieldRegenT = 0; ghostCd = 0;
    paused = false; coyoteT = 0; jumpBufT = 0;
    ghostTimer = 0; invulnT = 1.2; solarFlare = false; solarWarn = false; solarT = 0; solarCheckT = 0;
    iceStorm = false; iceWarn = false; iceT = 0; iceCheckT = 0;
    dying = false; deathT = 0; skipDeathAnim = false; runStars = 0;
    pendingGuaranteedIce = !!data.guaranteedIceStorm;
    data.guaranteedIceStorm = false;
    const v = el("deathVeil"); if(v) v.classList.remove("show");
    el("iceBadge") && el("iceBadge").classList.add("hidden");
    el("iceAlert") && el("iceAlert").classList.add("hidden");
    const sb = el("starBadge"); if(sb){ sb.classList.add("hidden"); if(el("starVal")) el("starVal").textContent = "0"; }
    runMaxCombo = 0; runNearMiss = 0; runEvents = 0; runHits = 0; lastMilestone = 0;
    if(data.boostCombo > 0){ data.boostCombo--; comboArmor = 1; toast("🔗 زره زنجیره فعال شد"); }
    else comboArmor = (data.comboPermOn ? 1 : 0);
    hide("pauseMenu");
    const pb = el("pauseBtn"); if(pb) pb.classList.remove("hidden");
    if(gameMode === "aurora"){
        currentBiome = "aurora";
        data.auroraRuns = (data.auroraRuns||0) + 1;
        toast("🌌 شب شفق! سکه‌ها، الماس‌ها، جعبه‌ها و پاورآپ‌های بسیار زیاد روی مسیر");
    }
}

function extraTick(dt, effSpeed){
    statTick();
    if(player && player.y + player.h < player.ground - 2){
        coyoteT = Math.max(0, coyoteT - dt);
    } else {
        coyoteT = 8;
        if(jumpBufT > 0 && playing){ jumpBufT = 0; jump(); }
    }
    jumpBufT = Math.max(0, jumpBufT - dt);
    if(player.vy < 0 && !jumpHeld) player.vy += 0.38 * dt;
    if(player.y < -6){ player.y = -6; if(player.vy < 0) player.vy = 0; }
    ghostBtnUpdate(dt);
    if(data.shieldRegenOn){
        if(player.shields <= 0){
            shieldRegenT += dt / 60;
            if(shieldRegenT >= 20){ shieldRegenT = 0; player.shields = 1; floatText(player.x, player.y - 20, "🔄 سپر بازسازی شد", "#7cf6ff"); toast("🔄 سپر بازسازی شد"); }
        } else shieldRegenT = 0;
    }

    if(ghostTimer > 0){
        ghostTimer -= dt / 60;
        el("ghostBadge") && el("ghostBadge").classList.remove("hidden");
    } else {
        el("ghostBadge") && el("ghostBadge").classList.add("hidden");
    }
    invulnT = Math.max(0, invulnT - dt / 60);
    satelliteAng += 0.045 * dt;
    if(data.satellite && player){
        satelliteZapT += dt;
        if(satelliteZapT > 150){
            satelliteZapT = 0;
            if(Math.random() < 0.35){
                let target = null, bestDx = Infinity;
                const candidates = [...obstacles, ...enemies, ...meteors];   // موانع، دشمنان (زمینی و هوایی) و شهاب‌سنگ‌ها
                candidates.forEach(o => {
                    const dx = o.x - player.x;
                    if(dx > 0 && dx < 520 && dx < bestDx){ bestDx = dx; target = o; }
                });
                if(target){
                    satZapFx = { tx: target.x + (target.w||24)/2, ty: target.y + (target.h||24)/2, until: performance.now() + 170 };
                    particles(target.x + (target.w||24)/2, target.y + (target.h||24)/2, 18, "flame");
                    floatText(target.x, target.y, "🛰️ نابود شد!", "#cfd8ff");
                    target.x = -600; statInc("satZaps"); if(target.type && target.vy !== undefined) target.dodged = true;
                    sfxZap();
                    shake(4, .15);
                }
            }
        }
    }
    runMaxCombo = Math.max(runMaxCombo, combo);
    groundScroll += effSpeed * dt;

    const featuredKey = todaysFeaturedEvent().key;
    if(pendingGuaranteedSF && score > 50 && !anyEventBusy() && eventCooldown <= 0){
        pendingGuaranteedSF = false;
        solarWarn = true; solarT = 0;
        const a0 = el("sfAlert"); if(a0) a0.classList.remove("hidden");
        toast("☀️ شراره خورشیدی نزدیک است!");
        sfxSiren();
        runEvents++;
    }
    if(!anyEventBusy() && eventCooldown <= 0 && score > 700){
        solarCheckT += dt;
        if(solarCheckT > 1500){
            solarCheckT = 0;
            if(Math.random() < (featuredKey === "sf" ? 0.24 : 0.15)){
                solarWarn = true; solarT = 0;
                const a = el("sfAlert"); if(a) a.classList.remove("hidden");
                toast("☀️ شراره خورشیدی نزدیک است!");
                sfxSiren();
                runEvents++;
            }
        }
    }
    if(solarWarn){
        solarT += dt;
        if(solarT > 110){
            solarWarn = false; solarFlare = true; solarT = 630;
            data.solarFlares = (data.solarFlares || 0) + 1;
            const a = el("sfAlert"); if(a) a.classList.add("hidden");
            el("sfBadge") && el("sfBadge").classList.remove("hidden");
            invulnT = Math.max(invulnT, 2.2);
            toast("☀️ شراره خورشیدی! امتیاز ×۲ ولی مسیر کمی سخت\u200cتر می\u200cشود!");
            shake(8, .3);
        }
    }
    if(solarFlare){
        solarT -= dt;
        if(solarT <= 0){ solarFlare = false; el("sfBadge") && el("sfBadge").classList.add("hidden"); endEventCooldown(); }
    }

    if(pendingGuaranteedIce && score > 50 && !anyEventBusy() && eventCooldown <= 0){
        pendingGuaranteedIce = false;
        iceWarn = true; iceT = 0;
        const a0 = el("iceAlert"); if(a0) a0.classList.remove("hidden");
        toast("❄️ یخ‌زدگی کیهانی نزدیک است!");
        tone(320, .25, "sine", .05);
        runEvents++;
    }
    if(!anyEventBusy() && eventCooldown <= 0 && score > 400){
        iceCheckT += dt;
        if(iceCheckT > 1550){
            iceCheckT = 0;
            if(Math.random() < (featuredKey === "ice" ? 0.24 : 0.15)){
                iceWarn = true; iceT = 0;
                const a = el("iceAlert"); if(a) a.classList.remove("hidden");
                toast("❄️ یخ‌زدگی کیهانی نزدیک است!");
                tone(320, .25, "sine", .05);
                runEvents++;
            }
        }
    }
    if(iceWarn){
        iceT += dt;
        if(iceT > 100){
            iceWarn = false; iceStorm = true; iceT = 690;
            data.iceStorms = (data.iceStorms || 0) + 1;
            const a = el("iceAlert"); if(a) a.classList.add("hidden");
            el("iceBadge") && el("iceBadge").classList.remove("hidden");
            toast("❄️ یخ‌زدگی! مسیر آهسته، سکه بیشتر");
            shake(5, .2);
        }
    }
    if(iceStorm){
        iceT -= dt;
        if(iceT <= 0){ iceStorm = false; el("iceBadge") && el("iceBadge").classList.add("hidden"); endEventCooldown(); }
    }

    if(player.magnet){
        gemCoins.forEach(c => {
            let dx = player.x + player.w/2 - c.x, dy = player.y + player.h/2 - c.y, d = Math.hypot(dx, dy);
            const MRg = data.magRangeOn ? 1.4 : 1;
            if(d < 250 * MRg && d > 1){
                const f = 1.15 + (250 * MRg - d) / 28;
                c.x += (dx / d * f) * dt; c.y += (dy / d * f) * dt;
            }
        });
    }

    obstacles.forEach(o => {
        if(!o.nearChk && o.x + o.w < player.x){
            o.nearChk = true;
            if(o.x < -300) return;          // مانعِ نابودشده (با سپر/ماهواره/نوا) «عبور» یا «نزدیک‌بود» حساب نمی‌شود
            statInc("passed");
            const py = player.y + player.h/2, oy = o.y + o.h/2;
            if(Math.abs(py - oy) < o.h * 0.7 + 36 + upAct("bold") * 3){
                runNearMiss++; statInc("nearMiss");
                score += 10;
                floatText(player.x + 30, player.y - 24, "نزدیک بود! +10", "#9dffb0");
                if(data.nearMissCoinOn){ data.coins += 1; runCoins += 1; }
            }
        }
    });

    const ms = Math.floor(score / 1000) * 1000;
    if(ms >= 1000 && ms > lastMilestone){
        lastMilestone = ms;
        floatText(W*0.5, H*0.28, "🎯 " + ms, "#ffd447");
        toast("مایل‌ستون " + ms + " امتیاز");
        tone(880, .15, "triangle", .05);
    }

    const cap = gfxLow() ? 40 : gfxMax() ? 520 : gfxPlus() ? 420 : 300;
    if(particlesArr.length > cap) particlesArr.splice(0, particlesArr.length - cap);

    el("comboArmorBadge") && el("comboArmorBadge").classList.toggle("hidden", comboArmor <= 0);
}

jump = function jump(){
    if(!playing || paused || !player) return;
    const canCoyote = coyoteT > 0 && player.jumps === 0;
    if(player.jumps < player.maxJumps || canCoyote){
        player.vy = jumpVy(); jumpMarkStart(); player.jumps = Math.min(player.maxJumps, (canCoyote ? 0 : player.jumps) + 1);
        if(canCoyote) player.jumps = 1;
        { const jk = cxJumpKey();
          if(jk){
              cxEmitJump(cxArr, jk, player.x + player.w / 2, player.y + player.h, false, gfxPlus());
              if(jk === "nova" || jk === "void") shake(data.shakeOn === false ? 0 : 2, .1);
              if(jk === "royal") shake(data.shakeOn === false ? 0 : 3, .12);
          } }
        tone(420, .08, "sine", .06);
        setTimeout(() => tone(650, .09, "sine", .04), 35);
        data.m6 = Math.min(70, (data.m6||0) + 1);
        data.m10 = Math.min(15, (data.m10||0) + 0); // jumps not combo
        statInc("jumps"); if(player.jumps >= 2) statInc("airJumps");
    } else {
        jumpBufT = 9;
    }
}

/* ---------- DRAW ---------- */
function drawRewardGalaxyBackground(dt, effSpeed){
    let g = ctx.createRadialGradient(W/2,H/2,0,W/2,H/2,Math.max(W,H)*0.85);
    g.addColorStop(0, "#5a4300"); g.addColorStop(0.45, "#2a1c00"); g.addColorStop(1, "#0a0800");
    ctx.fillStyle = g; ctx.fillRect(0,0,W,H);
    rgSwirl += 0.012 * dt;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for(let i=0;i<4;i++){
        const rr = Math.max(W,H)*(0.18+i*0.16);
        ctx.save();
        ctx.translate(W/2,H/2); ctx.rotate(rgSwirl*(i%2===0?1:-0.7)); ctx.translate(-W/2,-H/2);
        const rg = ctx.createRadialGradient(W/2,H/2,rr*0.82,W/2,H/2,rr);
        rg.addColorStop(0, "rgba(255,200,60,0)");
        rg.addColorStop(0.55, `rgba(255,210,80,${0.06+i*0.03})`);
        rg.addColorStop(1, "rgba(255,160,40,0)");
        ctx.fillStyle = rg;
        ctx.beginPath(); ctx.arc(W/2,H/2,rr,0,Math.PI*2); ctx.fill();
        ctx.restore();
    }
    ctx.restore();
    stars.forEach(s => {
        if(playing){ s.x -= s.s * effSpeed * .1 * dt; if(s.x<0){ s.x=W; s.y=Math.random()*H; } }
        s.tw += .08*dt;
        ctx.globalAlpha = s.a * (0.5+0.5*Math.sin(s.tw));
        ctx.fillStyle = "#ffe9a0";
        ctx.beginPath(); ctx.arc(s.x,s.y,s.r*1.2,0,Math.PI*2); ctx.fill();
    });
    ctx.globalAlpha = 1;
}

function drawBackground(dt, effSpeed){
    if(inBlackHole){ drawBlackHoleBackground(dt, effSpeed); drawEnvFilter(); return; }
    if(inRewardGalaxy){ drawRewardGalaxyBackground(dt, effSpeed); drawEnvFilter(); return; }

    ctx.fillStyle = getBgGradient();
    ctx.fillRect(0,0,W,H);

    paintBiomeDecor(ctx, gameMode, W, H, performance.now(), bioCur ? bioCur.idx : 0, player ? player.ground : H * 0.78);
    if(gameMode === "aurora") paintAuroraCurtains(ctx, W, performance.now()/900);

    if(typeof iceStorm !== "undefined" && iceStorm){
        ctx.fillStyle = "rgba(90,190,255,0.14)";
        ctx.fillRect(0,0,W,H);
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        ctx.fillStyle = "rgba(180,230,255,0.08)";
        for(let i=0;i<8;i++){
            const x = ((performance.now()/30 + i*90) % (W+40)) - 20;
            ctx.fillRect(x, 0, 2, H);
        }
        ctx.restore();
    }

    if(gfxHigh()){
        nebulae.forEach(n => {
            n.x -= n.speed * effSpeed * dt;
            if(n.x < -n.r) n.x = W + n.r;
            const ng = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.r);
            ng.addColorStop(0, `rgba(${n.c},0.16)`);
            ng.addColorStop(1, `rgba(${n.c},0)`);
            ctx.fillStyle = ng;
            ctx.beginPath(); ctx.arc(n.x, n.y, n.r, 0, Math.PI*2); ctx.fill();
        });
    }

    const starList = gfxLow() ? stars.slice(0, 28) : stars;
    starList.forEach(s => {
        if(playing){ s.x -= s.s * effSpeed * .14 * dt; if(s.x<0){ s.x=W; s.y=Math.random()*H*0.78; } }
        s.tw += .06*dt;
        ctx.globalAlpha = Math.max(0, Math.min(1, s.a * (0.45+0.55*Math.sin(s.tw))));
        ctx.fillStyle = "#eaf1ff";
        ctx.beginPath(); ctx.arc(s.x,s.y,s.r,0,Math.PI*2); ctx.fill();
    });
    ctx.globalAlpha = 1;

    skyPaint();   // سیاره‌های پایه + دکورها با ترتیب عمق (همه از راست به چپ)

    if(!gfxLow()){
        shootingStars.forEach(s => {
            ctx.strokeStyle = "rgba(255,255,255,0.7)";
            ctx.lineWidth = 2;
            ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(s.x - s.vx*6, s.y - s.vy*6); ctx.stroke();
        });
    }

    if(solarFlare){
        ctx.fillStyle = "rgba(255,120,20,0.14)";
        ctx.fillRect(0,0,W,H);
    }
    if(eventActive){
        ctx.fillStyle = "rgba(255,60,20,0.06)";
        ctx.fillRect(0,0,W,H);
    }
    drawEnvFilter();
    if(gfxPlus()) maxBackdrop(dt, effSpeed);
}




function drawCoins(){
    coins.forEach(c => {
        if(c.collected) return;
        ctx.save();
        ctx.translate(c.x, c.y);
        if(gfxPlus()) maxGlow(0, 0, (c.r || 12) * 2.8, c.super ? "255,212,71" : "255,204,70", c.super ? 0.55 : 0.32);
        ctx.rotate(c.spin);
        const r = c.r || 12;
        if(c.super){
            ctx.shadowColor = "#ffd447"; ctx.shadowBlur = gfxLow() ? 0 : 16;
            ctx.fillStyle = "#ffe566";
        } else {
            ctx.fillStyle = "#ffd447";
        }
        ctx.beginPath(); ctx.arc(0,0,r,0,Math.PI*2); ctx.fill();
        ctx.fillStyle = "#fff6c2";
        ctx.beginPath(); ctx.arc(-r*0.25,-r*0.25,r*0.45,0,Math.PI*2); ctx.fill();
        ctx.restore();
    });
}

function drawGemCoins(){
    gemCoins.forEach(c => {
        ctx.save();
        ctx.translate(c.x, c.y);
        if(gfxPlus()) maxGlow(0, 0, 30, "100,231,255", 0.45);
        ctx.rotate(c.spin);
        ctx.shadowColor = "#64e7ff"; ctx.shadowBlur = gfxLow() ? 0 : 12;
        ctx.fillStyle = "#64e7ff";
        ctx.beginPath();
        ctx.moveTo(0,-12); ctx.lineTo(10,0); ctx.lineTo(0,12); ctx.lineTo(-10,0); ctx.closePath(); ctx.fill();
        ctx.fillStyle = "#e9ffff";
        ctx.beginPath(); ctx.moveTo(0,-6); ctx.lineTo(5,0); ctx.lineTo(0,6); ctx.lineTo(-5,0); ctx.closePath(); ctx.fill();
        ctx.restore();
    });
}


function drawBoxes(){
    boxes.forEach(b => {
        ctx.save();
        ctx.translate(b.x + 16, b.y + 16);
        if(gfxPlus()) maxGlow(0, 0, 46, "255,200,70", 0.35);
        ctx.rotate(Math.sin(b.spin)*0.2);
        ctx.fillStyle = "#c47a2a";
        ctx.beginPath(); roundRectPath(-16,-16,32,32,6); ctx.fill();
        ctx.fillStyle = "#ffd447";
        ctx.fillRect(-16, -4, 32, 8);
        ctx.fillRect(-4, -16, 8, 32);
        ctx.restore();
    });
}


function drawMeteors(){
    meteors.forEach(m => {
        ctx.save();
        if(gfxPlus()) maxGlow(m.x, m.y, m.r * 4.2, "255,150,70", 0.5);
        ctx.strokeStyle = "rgba(255,140,60,0.6)";
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.lineTo(m.x - m.vx*4, m.y - m.vy*4); ctx.stroke();
        ctx.fillStyle = "#ffb347";
        ctx.beginPath(); ctx.arc(m.x, m.y, m.r, 0, Math.PI*2); ctx.fill();
        ctx.restore();
    });
}

function drawObstacles(){
    obstacles.forEach(o => {
        ctx.save();
        if(gfxPlus()){ ctx.shadowColor = o.type === 0 ? "rgba(155,231,255,0.9)" : o.type === 1 ? "rgba(255,170,90,0.9)" : "rgba(255,90,130,0.9)"; ctx.shadowBlur = 14; }
        if(o.type === 0){
            const g = ctx.createLinearGradient(o.x, o.y, o.x, o.y+o.h);
            g.addColorStop(0, "#9be7ff"); g.addColorStop(1, "#2a6aa5");
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.moveTo(o.x+o.w/2, o.y);
            ctx.lineTo(o.x+o.w, o.y+o.h);
            ctx.lineTo(o.x, o.y+o.h);
            ctx.closePath(); ctx.fill();
        } else if(o.type === 1){
            ctx.fillStyle = "#6b5344";
            ctx.beginPath();
            ctx.moveTo(o.x+4, o.y+o.h);
            ctx.lineTo(o.x+o.w*0.3, o.y+8);
            ctx.lineTo(o.x+o.w*0.7, o.y);
            ctx.lineTo(o.x+o.w, o.y+o.h*0.5);
            ctx.lineTo(o.x+o.w-4, o.y+o.h);
            ctx.closePath(); ctx.fill();
            ctx.fillStyle = "#8a7460";
            ctx.beginPath(); ctx.arc(o.x+o.w*0.45, o.y+o.h*0.45, 6, 0, Math.PI*2); ctx.fill();
        } else {
            ctx.fillStyle = "#ff4466";
            ctx.fillRect(o.x+o.w*0.35, o.y, o.w*0.3, o.h);
            ctx.fillStyle = "#ff88aa";
            ctx.globalAlpha = 0.5 + 0.5*Math.sin(performance.now()/120);
            ctx.fillRect(o.x, o.y+4, o.w, 6);
            ctx.globalAlpha = 1;
        }
        ctx.restore();
    });
}




/* ===== ماهواره‌ی همراه: طراحی زیباتر + پیش‌نمایش + پرتوی لیزری هنگام نابود کردن مانع ===== */
let satZapFx = null;
function paintSatellite(c, sx, sy, ang, sc, vip, tms){
    const depth = Math.sin(ang), k = sc * (1 + 0.16 * depth), gold = !!vip;
    c.save();
    c.translate(sx, sy);
    c.rotate(depth * 0.25);
    c.scale(k, k);
    const hg = c.createRadialGradient(0, 0, 1, 0, 0, 14);
    hg.addColorStop(0, gold ? "rgba(255,226,120,0.55)" : "rgba(150,220,255,0.5)");
    hg.addColorStop(1, "rgba(255,255,255,0)");
    c.fillStyle = hg; c.beginPath(); c.arc(0, 0, 14, 0, Math.PI * 2); c.fill();
    c.strokeStyle = "#9aa6c8"; c.lineWidth = 1; c.beginPath(); c.moveTo(-9, 0); c.lineTo(9, 0); c.stroke();
    [-1, 1].forEach(sd => {
        c.save(); c.translate(sd * 10.5, 0);
        const pg = c.createLinearGradient(-5, -3.5, 5, 3.5);
        pg.addColorStop(0, "#2e6bff"); pg.addColorStop(1, "#122f86");
        c.fillStyle = pg; c.fillRect(-5, -3.5, 10, 7);
        c.strokeStyle = "rgba(190,220,255,0.85)"; c.lineWidth = 0.6;
        c.strokeRect(-5, -3.5, 10, 7);
        c.beginPath(); c.moveTo(-1.7, -3.5); c.lineTo(-1.7, 3.5); c.moveTo(1.7, -3.5); c.lineTo(1.7, 3.5); c.moveTo(-5, 0); c.lineTo(5, 0); c.stroke();
        c.restore();
    });
    const bg = c.createLinearGradient(0, -5, 0, 5);
    if(gold){ bg.addColorStop(0, "#fff0a8"); bg.addColorStop(1, "#c8932a"); } else { bg.addColorStop(0, "#f1f5ff"); bg.addColorStop(1, "#8d9bc4"); }
    c.fillStyle = bg;
    const rx = -5.2, ry = -4.6, rw = 10.4, rh = 9.2, r = 2.6;
    c.beginPath();
    c.moveTo(rx + r, ry); c.lineTo(rx + rw - r, ry); c.quadraticCurveTo(rx + rw, ry, rx + rw, ry + r);
    c.lineTo(rx + rw, ry + rh - r); c.quadraticCurveTo(rx + rw, ry + rh, rx + rw - r, ry + rh);
    c.lineTo(rx + r, ry + rh); c.quadraticCurveTo(rx, ry + rh, rx, ry + rh - r);
    c.lineTo(rx, ry + r); c.quadraticCurveTo(rx, ry, rx + r, ry);
    c.closePath(); c.fill();
    c.strokeStyle = "rgba(40,50,90,0.55)"; c.lineWidth = 0.7; c.stroke();
    c.fillStyle = "#16224f"; c.beginPath(); c.arc(0, 0.4, 2.2, 0, Math.PI * 2); c.fill();
    c.fillStyle = "rgba(160,230,255,0.9)"; c.beginPath(); c.arc(-0.6, -0.2, 0.8, 0, Math.PI * 2); c.fill();
    c.strokeStyle = "#cfd8ff"; c.lineWidth = 0.9;
    c.beginPath(); c.moveTo(0, -4.6); c.lineTo(0, -8); c.stroke();
    c.beginPath(); c.arc(0, -8.4, 2.6, Math.PI * 1.1, Math.PI * 1.9); c.stroke();
    c.fillStyle = (Math.floor(tms / 380) % 2 === 0) ? "#ff5a6a" : "#5aff9a";
    c.beginPath(); c.arc(0, -8.9, 0.95, 0, Math.PI * 2); c.fill();
    c.restore();
}
function drawSatellite(){
    if(!data.satellite || !player) return;
    const px = player.x + 23, py = player.y + 28, tms = performance.now();
    const sx = px + Math.cos(satelliteAng) * 42, sy = py + Math.sin(satelliteAng) * 24;
    ctx.save();
    for(let k = 1; k <= 7; k++){
        const a = satelliteAng - k * 0.17;
        ctx.globalAlpha = 0.28 * (1 - k / 8);
        ctx.fillStyle = data.vip ? "#ffe27a" : "#9fe3ff";
        ctx.beginPath(); ctx.arc(px + Math.cos(a) * 42, py + Math.sin(a) * 24, Math.max(0.6, 2.4 - k * 0.22), 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
    if(satZapFx && tms < satZapFx.until){
        ctx.globalAlpha = Math.min(1, (satZapFx.until - tms) / 170);
        ctx.strokeStyle = "#e6fbff"; ctx.lineWidth = 2.4;
        ctx.shadowColor = "#7ae8ff"; ctx.shadowBlur = gfxLow() ? 0 : 12;
        ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(satZapFx.tx, satZapFx.ty); ctx.stroke();
        ctx.shadowBlur = 0; ctx.globalAlpha = 1;
    }
    paintSatellite(ctx, sx, sy, satelliteAng, 1, data.vip, tms);
    ctx.restore();
}


function drawOverlays(){
    if(startFxState){
        const T = (performance.now() - startFxState.t0) / 1000;
        if(cxStartDone(startFxState.key, T)) startFxState = null;
        else cxStartFx(ctx, startFxState.key, player ? player.x + player.w / 2 : W * 0.2, player ? player.y + player.h / 2 : H * 0.6, T, W, H, gfxPlus());
    }
    if(invulnT > 0){
        ctx.strokeStyle = `rgba(255,255,255,${Math.min(0.5, invulnT)})`;
        ctx.lineWidth = 2;
        ctx.strokeRect(8, 8, W-16, H-16);
    }
}

function haptic(ms){
    if(data.hapticOn === false) return;
    try{ if(navigator.vibrate) navigator.vibrate(ms); }catch(e){}
}

function gameOver(won){
    if(dying) return;
    { const gb = el("ghostBtn"); if(gb) gb.classList.add("hidden"); }
    if(skipDeathAnim){
        skipDeathAnim = false;
        playing = false;
        paused = false;
        const pb = el("pauseBtn"); if(pb) pb.classList.add("hidden");
        hide("hint"); hide("pauseMenu");
        finishGameOver(!!won);
        return;
    }
    dying = true;
    pendingWon = !!won;
    deathT = 1;
    playing = false;
    paused = false;
    const pb = el("pauseBtn"); if(pb) pb.classList.add("hidden");
    hide("hint"); hide("pauseMenu");
    haptic([40, 40, 80]);
    shake(14, .55);
    flashScreen();
    const v = el("deathVeil"); if(v) v.classList.add("show");
    if(player){
        particles(player.x + 20, player.y + 30, 36, "hit");
        player.vy = -7;
    }
    sfxThud(.9);
    setTimeout(() => tone(110, .35, "triangle", .07), 160);
    last = performance.now();
    rafId = requestAnimationFrame(loop);
}

function finishGameOver(won){
    statsFinishRun(!!won);
    if(Math.floor(score) > data.best) data.best = Math.floor(score);
    if(data.bestTodayDate !== today()){ data.bestTodayDate = today(); data.bestToday = 0; }
    data.bestToday = Math.max(data.bestToday||0, Math.floor(score));
    data.wm1 = Math.min(200000, (data.wm1||0) + Math.floor(score));
    if(gameMode === "hard") data.wm3 = Math.max(data.wm3||0, Math.floor(score));
    if(combo >= 15) data.m10 = Math.max(data.m10||0, combo);
    data.lastRun = { score: Math.floor(score), coins: runCoins, gems: runGems, combo: runMaxCombo, mode: gameMode };
    if(gameMode === "aurora") data.m11 = 1;
    data.runsSinceBH = (data.runsSinceBH||0) + (inBlackHole ? 0 : 1);
    data.runsSinceRG = (data.runsSinceRG||0) + (inRewardGalaxy ? 0 : 1);
    if(inBlackHole) data.runsSinceBH = 0;
    if(inRewardGalaxy) data.runsSinceRG = 0;
    {   // مسافت: هر یک امتیاز یک متر. با زنده‌شدن‌های پشت‌سرهم هم هر متر فقط یک‌بار شمرده می‌شود
        const meters = Math.max(0, Math.floor(score) - runDistanceAdded);
        data.totalDistance = (data.totalDistance || 0) + meters;
        runDistanceAdded += meters;
    }
    saveData();
    el("finalScore").textContent = Math.floor(score);
    el("finalCoins").textContent = runCoins;
    el("finalGems").textContent = runGems;
    el("best").textContent = data.best;
    const rec = el("runRecap");
    if(rec){
        rec.innerHTML = `زنجیره: <b>${runMaxCombo}</b> · نزدیک‌بود: <b>${runNearMiss}</b> · رویداد: <b>${runEvents}</b>` +
            (won ? " · ⏳ پیروزی تایم‌اتک" : "");
    }
    checkDailyChallengeEnd();
    updateContinueButtons();
    updateRateBoxes();
    show("over");
    if(!won && (data.games||0) <= 4) toast("💡 می‌توانی با تبلیغ یا ۱۵ الماس ادامه بدهی");
    if(data.pendingLevels && data.pendingLevels.length){
        setTimeout(() => {
            hide("over");
            el("newLevel").textContent = data.pendingLevels[0];
            show("levelUp");
        }, 400);
    }
    save();
}

function updateContinueButtons(){
    const left = Math.max(0, freeContinuesAllowed() - continuesThisRun);
    const info = el("continueInfo");
    const gemLeft = Math.max(0, 2 - gemContinuesThisRun);
    const adLeft = Math.max(0, 3 - adContinuesThisRun);
    if(info){
        let t = left > 0
            ? ("زنده‌شدن رایگان باقی‌مانده این دور: " + left)
            : "زنده‌شدن رایگان این دور تمام شد — تبلیغ یا " + faPrice(PRICE.revive) + " الماس" + ((data.reviveShield && data.reviveShieldOn) ? " (همراه با سپر)" : "");
        t += " · الماس: " + gemLeft + "/۲";
        info.textContent = t;
    }
    const btn = el("watchAdContinue");
    if(btn){
        btn.textContent = left > 0 ? "ادامه رایگان" : (adLeft ? "تماشای تبلیغ و زنده شدن" : "سهمیه تبلیغ این دور تمام");
        btn.disabled = left <= 0 && adLeft <= 0;
    }
    const gbtn = el("gemContinue");
    if(gbtn){
        gbtn.textContent = "💎 ادامه فوری (" + PRICE.revive + " 💎)";
        gbtn.classList.toggle("hidden", gemLeft <= 0);
    }
}

function continueRun(){
    if(!player) return;
    dying = false;
    const v = el("deathVeil"); if(v) v.classList.remove("show");
    playing = true; paused = false;
    continuesThisRun++; statInc("revives");
    invulnT = 2.2;
    const gotShield = !!(data.reviveShield && data.reviveShieldOn);
    if(gotShield) player.shields = Math.max(player.shields, 1);
    obstacles = obstacles.filter(o => o.x > player.x + 180 || o.x < player.x - 40);
    enemies = enemies.filter(e => e.x > player.x + 180 || e.x < player.x - 40);
    meteors = [];
    hide("over"); hide("levelUp");
    show("hint");
    const pb = el("pauseBtn"); if(pb) pb.classList.remove("hidden");
    toast(gotShield ? "زنده شدی! ایمنی کوتاه + 🛡️ سپر" : "زنده شدی! ایمنی کوتاه");
    last = performance.now();
    rafId = requestAnimationFrame(loop);
}

function tryContinueAd(){
    const left = freeContinuesAllowed() - continuesThisRun;
    if(left > 0){ statInc("revFree"); continueRun(); return; }
    if(adContinuesThisRun >= 3){ toast("حداکثر ۳ بار تبلیغ در هر دور"); return; }
    playAd(() => { adContinuesThisRun++; statInc("revAd"); continueRun(); }, "continue-revive");
}

function togglePause(){
    if(!playing) return;
    paused = !paused;
    if(paused){
        show("pauseMenu");
        hide("hint");
    } else {
        hide("pauseMenu");
        hide("settings");
        last = performance.now();
        rafId = requestAnimationFrame(loop);
    }
}

function renderDaily(){
    const box = el("dailyCalendar");
    if(!box) return;
    box.innerHTML = "";
    dailyRewards.forEach((r,i) => {
        const d = document.createElement("div");
        const day = i+1;
        d.className = "dailyDay" + (data.dailyDay===day ? " active" : "") + (day < data.dailyDay ? " done" : "");
        d.innerHTML = `روز ${day}<br>🟡${r.coins}<br>💎${r.gems}`;
        box.appendChild(d);
    });
    const msg = el("dailyMsg");
    if(msg) msg.textContent = data.dailyClaimed ? "امروز جایزه‌ات را گرفتی!" : "پاداش امروز آماده است";
    const b = el("claimDaily"); if(b) b.disabled = !!data.dailyClaimed;
    const dd = el("doubleDaily"); if(dd){
        dd.disabled = !!data.dailyClaimed || !!data.dailyDoubled;
        dd.classList.toggle("hidden", !!data.dailyClaimed || !!data.dailyDoubled);
    }
}

/* ================================================================
   اطلس کیهانی: برای هر رویداد ۵ پله جایزه‌ی «تعداد دفعات دیدن».
   اعداد بر اساس کمیابیِ واقعی هر رویداد حساب شده‌اند (تقریبِ تعداد رویداد در هر دقیقه‌ی بازی):
   سیاهچاله و کهکشان جایزه (کمیاب‌ترین ≈ هر ۶–۷ دقیقه) ← بارش الماسی (≈ هر ۴ دقیقه) ← شراره و یخ‌زدگی (≈ هر ۳ دقیقه) ← بارش شهابی (رایج‌ترین ≈ هر ۱.۵ دقیقه).
   هرچه رویداد کمیاب‌تر، هر بار دیدنش ارزشمندتر؛ پله‌ی آخر هر رویداد حدوداً ۹ تا ۱۳ ساعت بازی می‌خواهد.
   ================================================================ */
const CODEX_EVENTS = [
    { k:"bh", icon:"🕳️", name:"سیاهچاله مرگ", get:() => data.blackHoleVisits || 0, lore:"جاذبه همه چیز را می‌بلعد؛ سکه دوبل است ولی خطر مرگ بالاست.", tiers:[5,15,30,60,100], coins:[500,1000,1800,3200,5500], gems:[10,20,35,60,100] },
    { k:"rg", icon:"🌟", name:"کهکشان جایزه", get:() => data.rewardGalaxyVisits || 0, lore:"هیچ مانعی نیست. فقط جمع کن تا کهکشان تمام شود.", tiers:[5,15,30,60,100], coins:[500,1000,1800,3200,5500], gems:[10,20,35,60,100] },
    { k:"ds", icon:"🌠", name:"بارش الماسی", get:() => data.diamondShowers || 0, lore:"چند ثانیه مسیر پر از الماس می‌شود. سریع باش.", tiers:[10,30,60,120,200], coins:[400,800,1400,2600,4400], gems:[8,16,28,48,80] },
    { k:"ms", icon:"☄️", name:"بارش شهابی", get:() => data.meteorShowers || 0, lore:"شهاب‌سنگ از آسمان می‌بارد؛ پرش‌های دقیق لازم است.", tiers:[20,60,120,250,400], coins:[250,500,900,1600,2700], gems:[5,10,18,30,50] },
    { k:"sf", icon:"☀️", name:"شراره خورشیدی", get:() => data.solarFlares || 0, lore:"امتیاز دوبل می‌شود، ولی سرعت مسیر کمی بیشتر است.", tiers:[10,30,60,120,200], coins:[350,700,1250,2200,3800], gems:[7,14,24,42,70] },
    { k:"is", icon:"❄️", name:"یخ‌زدگی کیهانی", get:() => data.iceStorms || 0, lore:"زمان کش می‌آید و سکه کمی بیشتر می‌ارزد.", tiers:[10,30,60,120,200], coins:[350,700,1250,2200,3800], gems:[7,14,24,42,70] }
];
function codexClaimed(k){ const m = data.codexClaim; return (m && typeof m === "object") ? Math.max(0, Math.min(5, Math.floor(+m[k]) || 0)) : 0; }
function claimCodexTier(k){
    const ev = CODEX_EVENTS.find(e => e.k === k); if(!ev) return;
    const i = codexClaimed(k);
    if(i >= 5 || ev.get() < ev.tiers[i]) return;
    if(!data.codexClaim || typeof data.codexClaim !== "object") data.codexClaim = {};
    data.codexClaim[k] = i + 1; data.coins += ev.coins[i]; addGems(ev.gems[i]); statInc("codexTiers");
    save(); toast("🎁 " + faPrice(ev.coins[i]) + " سکه + " + faNum(ev.gems[i]) + " الماس"); renderCodex(); updateUI();
}
function renderCodex(){
    const box = el("codexList");
    if(!box) return;
    box.innerHTML = CODEX_EVENTS.map(ev => {
        const v = ev.get(), got = codexClaimed(ev.k);
        const rows = ev.tiers.map((t, i) => {
            const done = i < got, can = i === got && v >= t, state = done ? "✅" : (v >= t ? "🎁" : "🔒");
            return `<div class="cxTier ${done ? "done" : ""}"><span>${state} ${faPrice(t)} بار</span><span class="small">${faPrice(ev.coins[i])} 🟡 + ${faNum(ev.gems[i])} 💎</span>${can ? `<button class="reward cxClaim" data-k="${ev.k}">دریافت</button>` : ""}</div>`;
        }).join("");
        return `<div class="card cxCard"><div>${ev.icon} ${ev.name}</div><div class="small">${v ? ("کشف‌شده ×" + faPrice(v) + " — " + ev.lore) : "هنوز ندیدی — بیشتر بازی کن تا کشف شود"}</div><div class="cxTiers">${rows}</div></div>`;
    }).join("");
    box.querySelectorAll(".cxClaim").forEach(b => { b.onclick = () => claimCodexTier(b.dataset.k); });
}

function buyUpgrade(key, price, currency){
    const def = upgradeDefs.find(d => d[1] === key);
    if(def){ price = def[2]; currency = def[3]; }
    else if(key === "reviveShield"){ price = REVIVE_SHIELD_GEMS; currency = "gems"; }
    else return;
    if(data[key]){
        data[key+"On"] = !data[key+"On"];
        save(); toast(data[key+"On"] ? "✅ فعال شد" : "غیرفعال شد"); return;
    }
    if(currency === "gems"){
        if(data.gems < price){ toast("الماس کافی نیست"); return; }
        data.gems -= price; statInc("gemsSpent", price);
    } else {
        if(data.coins < price){ toast("سکه کافی نیست"); return; }
        data.coins -= price; statInc("coinsSpent", price);
    }
    data[key] = true; data[key+"On"] = true;
    save(); toast("✅ خریداری شد و فعال شد");
}

function buyConsumable(key, price){
    if(data.coins < price){ toast("سکه کافی نیست"); return; }
    data.coins -= price; statInc("coinsSpent", price); data[key] = (data[key]||0)+1; save(); toast("خرید شد");
}

function spendGems(n){
    if(data.gems < n){ toast("الماس کافی نیست"); return false; }
    data.gems -= n; statInc("gemsSpent", n); return true;
}

function selectOrBuy(ownedMap, key, selectField, price, irl, irlPrice, irlName){
    data[ownedMap] = data[ownedMap] || {};
    if(data[ownedMap][key] || key === "none" || key === "default"){
        data[selectField] = key; save(); return;
    }
    if(irl){
        const category = ({ filterOwned:"filter", trailOwned:"trail", jumpEffectOwned:"jump", startFxOwned:"start" })[ownedMap] || "item";
        openIap(irlName, "آیتم بصری ویژه", irlPrice, storeSku("item", category, key), "non_consumable", () => {
            data[ownedMap][key] = true; data[selectField] = key; save();
            openScreen(iapReturn || "shop"); updateUI();
        });
        return;
    }
    if(!spendGems(price)) return;
    data[ownedMap][key] = true; data[selectField] = key; save(); toast("فعال شد");
}

function updateExtraUI(){
    checkAdGemDay();
    const ag = el("adGemsHint");
    if(ag) ag.textContent = "باقی‌مانده امروز: " + faPrice(adGemsLeft()) + "/۶";
    const na = el("noAdsStatus");
    if(na) na.textContent = hasNoAds() ? "فعال — همیشگی" : "غیرفعال";
    const mv = el("musicVol"); if(mv) mv.value = Math.round((data.musicVol ?? 0.75)*100);
    const sv = el("sfxVol"); if(sv) sv.value = Math.round((data.sfxVol ?? 0.85)*100);
    document.querySelectorAll(".gfxBtn").forEach(b => b.classList.toggle("active", b.dataset.gfx === gfxLevel()));
    const shakeSw = el("shakeToggle"); if(shakeSw) shakeSw.checked = data.shakeOn !== false;
    if(el("watchAdGemsMenu")) el("watchAdGemsMenu").textContent = "📺 ۵ الماس رایگان (" + faPrice(adGemsLeft()) + "/۶)";
    if(el("watchAdGemsShop")) el("watchAdGemsShop").textContent = adGemsLeft() ? "تماشا ("+faPrice(adGemsLeft())+"/۶)" : "سهمیه امروز تمام";
    const lucky = el("luckyBanner");
    if(lucky){
        if(data.luckyUntil && Date.now() < data.luckyUntil){
            lucky.textContent = "🍀 ساعت شانس فعال — سکه +۵۰٪";
            lucky.classList.remove("hidden");
        } else lucky.classList.add("hidden");
    }
    if(el("cntCombo")) el("cntCombo").textContent = data.boostCombo ? "("+data.boostCombo+")" : "";
    if(el("buySkinComet")){
        el("skinComet") && el("skinComet").classList.toggle("locked", !data.skinComet);
        el("buySkinComet").textContent = data.skinComet ? (data.skin==="comet" ? "✓ فعال" : "انتخاب") : PRICE.skinComet+" 💎";
        el("skinComet") && el("skinComet").classList.toggle("active", data.skin==="comet");
    }
    if(el("buySkinAurora")){
        el("skinAurora") && el("skinAurora").classList.toggle("locked", !data.skinAurora);
        el("buySkinAurora").textContent = data.skinAurora ? (data.skin==="aurora" ? "✓ فعال" : "انتخاب") : PRICE.skinAurora+" 💎";
        el("skinAurora") && el("skinAurora").classList.toggle("active", data.skin==="aurora");
    }
    if(el("buySkinNeptune")){
        el("skinNeptune") && el("skinNeptune").classList.toggle("locked", !data.skinNeptune);
        el("buySkinNeptune").textContent = data.skinNeptune ? (data.skin==="neptune" ? "✓ فعال" : "انتخاب") : PRICE.skinNeptune+" 💎";
        el("skinNeptune") && el("skinNeptune").classList.toggle("active", data.skin==="neptune");
    }
    if(el("buySkinSaturn")){
        el("skinSaturn") && el("skinSaturn").classList.toggle("locked", !data.skinSaturn);
        el("buySkinSaturn").textContent = data.skinSaturn ? (data.skin==="saturn" ? "✓ فعال" : "انتخاب") : PRICE.skinSaturn+" 💎";
        el("skinSaturn") && el("skinSaturn").classList.toggle("active", data.skin==="saturn");
    }
    if(el("buySatellite")) el("buySatellite").textContent = data.satelliteOwned ? (data.satellite ? "فعال ✓" : "غیرفعال") : "۷۰,۰۰۰ ت";
    const nick = el("pilotName");
    if(nick) nick.textContent = data.nickname ? ("فضانورد: " + data.nickname) : "";
    const ni = el("nickInput"); if(ni && document.activeElement !== ni) ni.value = data.nickname || "";
    const ht = el("hapticToggle"); if(ht) ht.checked = data.hapticOn !== false;
    const lastL = el("lastRunLine");
    if(lastL){
        if(data.lastRun && data.lastRun.score) lastL.textContent = "آخرین دور: " + data.lastRun.score + " امتیاز · " + data.lastRun.coins + " سکه" + (typeof data.lastRun.gems === "number" ? " · " + data.lastRun.gems + " الماس" : "");
        else lastL.textContent = "";
    }
    renderChallengeBanner();
    const dd = el("doubleDaily");
    if(dd){
        dd.disabled = !!data.dailyClaimed || !!data.dailyDoubled;
        dd.classList.toggle("hidden", !!data.dailyClaimed || !!data.dailyDoubled);
        dd.textContent = (data.dailyClaimed||data.dailyDoubled) ? "جایزه امروز بسته شد" : "📺 دو برابر با تماشای تبلیغ";
    }
    const ss = el("buyStreakShield");
    if(ss) ss.textContent = data.streakShield ? "✓ فعال" : faPrice(PRICE.streakShield) + " 💎";
    const bt = el("bestTodayLine");
    if(bt){
        if(data.bestTodayDate !== today()){ data.bestTodayDate = today(); data.bestToday = 0; }
        bt.textContent = data.bestToday ? ("بهترین امروز: " + data.bestToday) : "هنوز رکورد امروز نداری";
    }
    const iceTkt = el("buyTicketIce");
    if(iceTkt) iceTkt.textContent = data.guaranteedIceStorm ? "✓ فعال (بازی بعدی)" : PRICE.ticketIce+" 💎";
    const flareTkt = el("buyTicketFlare");
    if(flareTkt) flareTkt.textContent = data.guaranteedSolarFlare ? "✓ فعال (بازی بعدی)" : PRICE.ticketFlare+" 💎";
}

shake = function shake(mag, dur){
    if(data.shakeOn === false) return;
    shakeMag = Math.max(shakeMag, mag); shakeTime = Math.max(shakeTime, dur);
}

resize = function resize(){
    W = innerWidth; H = innerHeight;
    const cap = gfxLow() ? 1 : gfxLevel()==="medium" ? 2 : gfxMax() ? 2.5 : 2.25;
    DPR = Math.min(devicePixelRatio || 1, cap);
    canvas.width = W * DPR; canvas.height = H * DPR;
    canvas.style.width = W + "px"; canvas.style.height = H + "px";
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    if(player) player.ground = H * .78;
    makeStars(); makePlanets(); makeNebulae();
    bgGradCache = { key:null, grad:null }; groundGradCache = { key:null, grad:null };
}

function todaysChallenge(){
    const list = [
        { id:"score800", text:"در یک دور به ۸۰۰ امتیاز برس", check:(r)=>r.score>=800, coins:90, gems:2 },
        { id:"combo12", text:"زنجیره ۱۲ بساز", check:(r)=>r.combo>=12, coins:80, gems:2 },
        { id:"coins18", text:"۱۸ سکه در یک دور جمع کن", check:(r)=>r.coins>=18, coins:70, gems:2 },
        { id:"near8", text:"۸ عبور نزدیک در یک دور", check:(r)=>r.near>=8, coins:80, gems:2 },
        { id:"score1500", text:"به ۱۵۰۰ امتیاز برس", check:(r)=>r.score>=1500, coins:120, gems:3 },
        { id:"combo20", text:"زنجیره ۲۰ بساز", check:(r)=>r.combo>=20, coins:100, gems:3 },
        { id:"noContinue", text:"بدون زنده شدن به ۶۰۰ برس", check:(r)=>r.score>=600 && r.continues===0, coins:85, gems:2 }
    ];
    const d = new Date();
    const idx = (d.getFullYear()*400 + d.getMonth()*40 + d.getDate()) % list.length;
    return list[idx];
}
function renderChallengeBanner(){
    const ch = todaysChallenge();
    const n = el("challengeText");
    if(!n) return;
    if(data.challengeDate !== today()){ data.challengeDate = today(); data.challengeClaimed = false; }
    const rewardTxt = " (جایزه: " + ch.coins + " 🟡 + " + ch.gems + " 💎)";
    n.textContent = data.challengeClaimed ? ("✅ انجام شد: " + ch.text + rewardTxt) : (ch.text + rewardTxt);
}
function checkDailyChallengeEnd(){
    const ch = todaysChallenge();
    if(data.challengeClaimed) return;
    const r = { score: Math.floor(score), coins: runCoins, combo: runMaxCombo, near: runNearMiss, continues: continuesThisRun + gemContinuesThisRun + adContinuesThisRun };
    if(ch.check(r)){
        data.challengeClaimed = true;
        data.coins += ch.coins; addGems(ch.gems);
        toast("🎯 چالش امروز کامل شد! +" + ch.coins + " سکه +" + ch.gems + " الماس");
    }
}



/* ---------- قطع و ادامه‌ی دقیق صدا هنگام خروج از برنامه / خاموش شدن گوشی ----------
   موقعیت موسیقی ذخیره می‌شود (proPauseSave) و کل AudioContext «به‌حالت تعلیق» می‌رود؛ زمانی که برگردی از همان‌جا ادامه می‌یابد. */
function audioSleep(){
    if(audioSleeping) return; audioSleeping = true;
    try { proPauseSave(); } catch(e){}
    try { if(audio && audio.state === "running"){ audioWasRunning = true; audio.suspend(); } } catch(e){}
}
function audioWake(){
    if(!audioSleeping) return;
    const done = () => { audioSleeping = false; audioWasRunning = false; };
    try {
        if(audio && audio.state === "suspended"){ const rp = audio.resume(); if(rp && rp.then) rp.then(done, done); else done(); }
        else done();
    } catch(e){ done(); }
}
function wireAll(){
    const on = (id, fn) => { const n = el(id); if(n) n.onclick = fn; };

    on("start", () => {
        initAudio();
        if(gameMode === "aurora"){
            if(data.coins < PRICE.auroraEntry){ toast("ورودی شفق قطبی ۳۰۰۰ سکه است"); return; }
            data.coins -= PRICE.auroraEntry; statInc("coinsSpent", PRICE.auroraEntry);
            data.m11 = 1;
            saveData();
            toast("ورود به شفق قطبی (−۳۰۰۰ سکه)");
        }
        if(!data.seenTutorial){ data.seenTutorial = true; saveData(); }
        startGame(); extraStart();
    });
    on("shopBtn", () => { updateUI(); openScreen("shop"); });
    on("missionsBtn", () => { updateUI(); openScreen("missions"); });
    on("achBtn", () => { updateUI(); openScreen("ach"); });
    on("statsBtn", () => { updateUI(); openScreen("stats"); });
    on("dailyBtn", () => { checkDay(); renderDaily(); openScreen("daily"); });
    on("wheelBtn", () => openWheel());
    on("lbBtn", () => { renderLeaderboard(); openScreen("leaderboard"); });
    on("settingsBtn", () => { updateExtraUI(); openScreen("settings"); });
    on("codexBtn", () => { renderCodex(); openScreen("codex"); });
    on("howtoBtn", () => openScreen("howto"));
    on("aboutBtn", () => openScreen("about"));
    on("closeHowto", () => { data.seenTutorial = true; saveData(); openScreen("menu"); });
    on("closeAbout", () => openScreen("menu"));
    on("closeShop", () => openScreen("menu"));
    on("closeMissions", () => openScreen("menu"));
    on("closeAch", () => openScreen("menu"));
    on("closeStats", () => openScreen("menu"));
    on("closeDaily", () => openScreen("menu"));
    on("closeWheel", () => openScreen("menu"));
    on("closeLb", () => openScreen("menu"));
    on("closeSettings", () => playing && paused ? openScreen("pauseMenu") : openScreen("menu"));
    on("closeCodex", () => openScreen("menu"));
    on("home", () => { commitFinalScoreIfNeeded(); openScreen("menu"); });
    on("again", () => {
        commitFinalScoreIfNeeded();
        initAudio();
        if(gameMode === "aurora"){
            if(data.coins < PRICE.auroraEntry){ toast("ورودی شفق قطبی ۳۰۰۰ سکه است"); openScreen("menu"); return; }
            data.coins -= PRICE.auroraEntry; statInc("coinsSpent", PRICE.auroraEntry); saveData(); toast("ورود به شفق قطبی (−۳۰۰۰ سکه)");
        }
        startGame(); extraStart();
    });
    on("overShop", () => { commitFinalScoreIfNeeded(); updateUI(); openScreen("shop"); });

    on("pauseBtn", () => togglePause());
    on("resumeBtn", () => togglePause());
    on("pauseSettings", () => { updateExtraUI(); openScreen("settings"); });
    on("pauseQuit", () => { paused = false; skipDeathAnim = true; runQuit = true; statInc("quits"); gameOver(); });

    upgradeDefs.forEach(([id,key,price,currency]) => on(id, () => buyUpgrade(key, price, currency)));
    on("btnReviveShieldGem", () => buyUpgrade("reviveShield", REVIVE_SHIELD_GEMS, "gems"));
    on("buyFilterAurora", () => selectOrBuy("filterOwned","aurora","envFilter",0,true,40000,"فیلتر شفق زنده"));
    on("buyTrailRainbow", () => selectOrBuy("trailOwned","rainbow","trailColor",0,true,30000,"دنباله‌ی رنگین‌کمانی"));
    on("buyJumpNova", () => selectOrBuy("jumpEffectOwned","nova","jumpEffect",0,true,30000,"پرش ابرنواختری"));
    on("buyStartFxPortal", () => selectOrBuy("startFxOwned","portal","startFx",0,true,20000,"پورتال کیهانی"));

    on("buyBoostHead", () => buyConsumable("boostHead", 150));
    on("buyBoostShield", () => buyConsumable("boostShield", 300));
    on("buyBoostMag", () => buyConsumable("boostMag", 220));
    on("buyBoostCombo", () => buyConsumable("boostCombo", 180));

    const qbuy = (id, key, price) => on(id, () => buyConsumable(key, price));
    qbuy("quickBuyHeadMenu","boostHead",150);
    qbuy("quickBuyShieldMenu","boostShield",300);
    qbuy("quickBuyMagMenu","boostMag",220);
    qbuy("quickBuyComboMenu","boostCombo",180);
    qbuy("quickBuyHeadOver","boostHead",150);
    qbuy("quickBuyShieldOver","boostShield",300);
    qbuy("quickBuyMagOver","boostMag",220);
    qbuy("quickBuyComboOver","boostCombo",180);

    on("buyTicketBH", () => { if(data.guaranteedBlackHole) return; if(!spendGems(PRICE.ticketBH)) return; data.guaranteedBlackHole = true; save(); toast("بلیط سیاهچاله"); });
    on("buyTicketRG", () => { if(data.guaranteedRewardGalaxy) return; if(!spendGems(PRICE.ticketRG)) return; data.guaranteedRewardGalaxy = true; save(); toast("بلیط کهکشان"); });
    on("buyTicketDS", () => { if(data.guaranteedDiamondShower) return; if(!spendGems(PRICE.ticketDS)) return; data.guaranteedDiamondShower = true; save(); toast("بلیط بارش"); });
    on("buyTicketIce", () => { if(data.guaranteedIceStorm) return; if(!spendGems(PRICE.ticketIce)) return; data.guaranteedIceStorm = true; save(); toast("بلیط یخ‌زدگی"); });
    on("buyTicketFlare", () => { if(data.guaranteedSolarFlare) return; if(!spendGems(PRICE.ticketFlare)) return; data.guaranteedSolarFlare = true; save(); toast("بلیط شراره خورشیدی"); });

    on("ex10", () => { if(!spendGems(5)) return; data.coins += 200; save(); toast("+200 سکه"); });
    on("ex50", () => { if(!spendGems(20)) return; data.coins += 1000; save(); toast("+1000 سکه"); });

    on("selectFilterNone", () => { data.envFilter = "none"; save(); });
    on("buyFilterSunset", () => selectOrBuy("filterOwned","sunset","envFilter",PRICE.filter));
    on("buyFilterNight", () => selectOrBuy("filterOwned","night","envFilter",PRICE.filter));
    on("buyFilterEmerald", () => selectOrBuy("filterOwned","emerald","envFilter",PRICE.filter));
    on("buyFilterRoyal", () => {
        if(!data.vip){ toast("ویژه پک شاهانه VIP"); return; }
        data.filterOwned.royal = true; data.envFilter = "royal"; save();
    });

    on("selectTrailDefault", () => { data.trailColor = "default"; save(); });
    on("buyTrailCyan", () => selectOrBuy("trailOwned","cyan","trailColor",PRICE.trail));
    on("buyTrailPink", () => selectOrBuy("trailOwned","pink","trailColor",PRICE.trail));
    on("buyTrailGreen", () => selectOrBuy("trailOwned","green","trailColor",PRICE.trail));
    on("buyTrailRoyal", () => {
        if(!data.vip){ toast("ویژه پک شاهانه VIP"); return; }
        data.trailOwned.royal = true; data.trailColor = "royal"; save();
    });

    on("selectJumpDefault", () => { data.jumpEffect = "default"; save(); });
    on("buyJumpIce", () => selectOrBuy("jumpEffectOwned","ice","jumpEffect",PRICE.jumpFx));
    on("buyJumpStars", () => selectOrBuy("jumpEffectOwned","stars","jumpEffect",PRICE.jumpFx));
    on("buyJumpRoyal", () => {
        if(!data.vip){ toast("ویژه پک شاهانه VIP"); return; }
        data.jumpEffectOwned.royal = true; data.jumpEffect = "royal"; save();
    });

    on("selectGroundNone", () => { data.groundTheme = "none"; save(); });
    on("buyGroundOcean", () => data.groundThemeOwned.ocean ? (data.groundTheme="ocean", save()) : purchaseGroundIAP("ocean",50000,"اقیانوس نور"));
    on("buyGroundDiamond", () => data.groundThemeOwned.diamond ? (data.groundTheme="diamond", save()) : purchaseGroundIAP("diamond",50000,"الماسی"));
    on("buyGroundLava", () => data.groundThemeOwned.lava ? (data.groundTheme="lava", save()) : purchaseGroundIAP("lava",60000,"گدازه"));
    on("buyGroundMilkyway", () => data.groundThemeOwned.milkyway ? (data.groundTheme="milkyway", save()) : purchaseGroundIAP("milkyway",55000,"راه شیری"));
    on("buyGroundGarden", () => data.groundThemeOwned.garden ? (data.groundTheme="garden", save()) : purchaseGroundIAP("garden",65000,"باغ بهشتی"));
    on("buyGroundRoyal", () => {
        if(!data.vip){ toast("ویژه پک شاهانه VIP"); return; }
        data.groundThemeOwned.royal = true; data.groundTheme = "royal"; save();
    });

    on("selectAuraNone", () => { data.aura = "none"; save(); });
    on("buyAuraPulse", () => selectOrBuy("auraOwned","pulse","aura",PRICE.auraPulse));
    on("buyAuraOrbit", () => data.auraOwned.orbit ? (data.aura="orbit", save()) : purchaseAuraIAP("orbit",30000,"مداری"));
    on("buyAuraRainbow", () => data.auraOwned.rainbow ? (data.aura="rainbow", save()) : purchaseAuraIAP("rainbow",35000,"رنگین‌کمانی"));
    on("buyAuraRoyal", () => {
        if(!data.vip){ toast("ویژه پک شاهانه VIP"); return; }
        data.auraOwned.royal = true; data.aura = "royal"; save();
    });

    on("selectStartFxNone", () => { data.startFx = "none"; save(); });
    on("buyStartFxWarp", () => selectOrBuy("startFxOwned","warp","startFx",PRICE.startWarp));
    on("buyStartFxFlash", () => selectOrBuy("startFxOwned","flash","startFx",PRICE.startFlash));
    on("buyStartFxRoyal", () => {
        if(!data.vip){ toast("ویژه پک شاهانه VIP"); return; }
        data.startFxOwned.royal = true; data.startFx = "royal"; save();
    });

    on("buySatellite", () => {
        if(data.satelliteOwned){ data.satellite = !data.satellite; save(); return; }
        openIap("ماهواره همراه", "یک ماهواره کوچک دور سفینه می‌چرخد — قدرت: برخی موانع و دشمنان را به طور شانسی نابود می‌کند.", 70000, storeSku("satellite", "companion"), "non_consumable", () => {
            data.satelliteOwned = true; data.satellite = true; save();
            openScreen(iapReturn || "shop"); updateUI();
        });
    });

    on("buySkinComet", () => {
        if(data.skinComet){ setSkin("comet"); return; }
        if(!spendGems(PRICE.skinComet)) return;
        data.skinComet = true; data.skin = "comet"; save(); toast("اسکین شهاب");
    });
    on("buySkinAurora", () => {
        if(data.skinAurora){ setSkin("aurora"); return; }
        if(!spendGems(PRICE.skinAurora)) return;
        data.skinAurora = true; data.skin = "aurora"; save(); toast("اسکین شفق");
    });
    on("buySkinNeptune", () => {
        if(data.skinNeptune){ setSkin("neptune"); return; }
        if(!spendGems(PRICE.skinNeptune)) return;
        data.skinNeptune = true; data.skin = "neptune"; save(); toast("اسکین نپتون");
    });
    on("buySkinSaturn", () => {
        if(data.skinSaturn){ setSkin("saturn"); return; }
        if(!spendGems(PRICE.skinSaturn)) return;
        data.skinSaturn = true; data.skin = "saturn"; save(); toast("اسکین زحل");
    });

    document.querySelectorAll(".iap-btn[data-gems]").forEach(btn => {
        btn.addEventListener("click", () => purchaseGemsIAP(+btn.dataset.gems, +btn.dataset.price));
    });

    on("watchAdGemsMenu", () => playAd(() => { addGems(5); save(); toast("+۵ الماس"); updateUI(); }, "gems"));
    on("watchAdGemsShop", () => playAd(() => { addGems(5); save(); toast("+۵ الماس"); updateUI(); }, "gems"));

    on("watchAdContinue", () => tryContinueAd());
    on("gemContinue", () => {
        if(gemContinuesThisRun >= 2){ toast("حداکثر ۲ بار با الماس در هر دور"); return; }
        if(!spendGems(PRICE.revive)) return;
        gemContinuesThisRun++; statInc("revGem");
        save(); continueRun();
    });

    const claim = (id, ok, give) => on(id, () => { if(!ok()) return; give(); save(); toast("پاداش مأموریت"); updateUI(); });
    Object.keys(DAILY_DEFS).concat(Object.keys(WEEKLY_DEFS)).forEach(k => {
        const d = DAILY_DEFS[k] || WEEKLY_DEFS[k];
        claim(claimBtnId(k), () => (data[k] || 0) >= d[0] && !data[k + "Claim"], () => { data[k + "Claim"] = true; giveReward(d[1], d[2]); });
    });
    on("claimDailyBonus", () => {
        if(data.dailyBonusClaim || dailyDoneCount() < Object.keys(DAILY_DEFS).length) return;
        data.dailyBonusClaim = true; giveReward(DAILY_BONUS.coins, DAILY_BONUS.gems); statInc("bonusDaily");
        save(); toast("🏆 پاداش بزرگ: " + rewardText(DAILY_BONUS.coins, DAILY_BONUS.gems)); updateUI();
    });
    on("claimWeeklyBonus", () => {
        if(data.weeklyBonusClaim || weeklyDoneCount() < Object.keys(WEEKLY_DEFS).length) return;
        data.weeklyBonusClaim = true; giveReward(WEEKLY_BONUS.coins, WEEKLY_BONUS.gems); statInc("bonusWeekly");
        save(); toast("🏆 پاداش بزرگ: " + rewardText(WEEKLY_BONUS.coins, WEEKLY_BONUS.gems)); updateUI();
    });

    on("claimDaily", () => {
        if(data.dailyClaimed) return;
        const r = dailyRewards[(data.dailyDay-1) % 7];
        data.coins += r.coins; addGems(r.gems);
        data.dailyClaimed = true; statInc("dailyClaims");
        data.luckyUntil = Date.now() + 60*60*1000;
        data.dailyDay = data.dailyDay >= 7 ? 1 : data.dailyDay + 1;
        save(); toast("پاداش روزانه + ساعت شانس ۱ ساعته");
        renderDaily(); updateUI();
    });
    on("doubleDaily", () => {
        if(data.dailyClaimed || data.dailyDoubled){ toast("جایزه امروز بسته شده"); return; }
        playAd(() => {
            const r = dailyRewards[(data.dailyDay-1) % 7];
            data.coins += r.coins * 2;
            addGems(r.gems * 2);
            data.dailyClaimed = true;
            data.dailyDoubled = true; statInc("dailyClaims");
            data.luckyUntil = Date.now() + 60*60*1000;
            data.dailyDay = data.dailyDay >= 7 ? 1 : data.dailyDay + 1;
            save(); toast("🎁 جایزه دوبل دریافت شد");
            renderDaily(); updateUI();
        }, "double-daily");
    });
    on("buyStreakShield", () => {
        if(data.streakShield){ toast("محافظ زنجیره از قبل فعاله"); return; }
        if(!spendGems(PRICE.streakShield)) return;
        data.streakShield = true; save(); toast("🛡️ محافظ زنجیره روزانه فعال شد");
    });

    on("claimLevel", () => {
        if(!data.pendingLevels.length) { openScreen("over"); return; }
        data.pendingLevels.shift();
        data.coins += 100; addGems(2); save();
        if(data.pendingLevels.length){ el("newLevel").textContent = data.pendingLevels[0]; }
        else { hide("levelUp"); openScreen("over"); }
        updateUI();
    });
    on("doubleLevel", () => {
        if(!data.pendingLevels.length) { openScreen("over"); return; }
        playAd(() => {
            data.pendingLevels.shift();
            data.coins += 200; addGems(4); save();
            toast("🎁 پاداش سطح دوبل دریافت شد");
            if(data.pendingLevels.length){ el("newLevel").textContent = data.pendingLevels[0]; }
            else { hide("levelUp"); openScreen("over"); }
            updateUI();
        }, "double-level");
    });

    on("iapConfirm", () => { confirmIapPurchase(); });
    on("iapCancel", () => {
        if(iapBusy) return;
        pendingIap = null; pendingIapPrice = 0; pendingIapSku = ""; pendingIapType = ""; pendingIapPayload = "";
        openScreen(iapReturn || "shop");
    });

    const mv = el("musicVol");
    if(mv) mv.oninput = () => { data.musicVol = (+mv.value)/100; applyVolumes(); saveData(); };
    const sv = el("sfxVol");
    if(sv) sv.oninput = () => { data.sfxVol = (+sv.value)/100; applyVolumes(); saveData(); };
    document.querySelectorAll(".gfxBtn").forEach(b => b.onclick = () => { data.gfx = b.dataset.gfx; save(); resize(); updateExtraUI(); toast("گرافیک: " + ({ max:"مکس", high:"بالا", medium:"متوسط", low:"پایین" }[b.dataset.gfx] || b.dataset.gfx)); });
    on("createRecoveryCode", () => { el("recPassC").value = ""; el("recOut").value = ""; hide("recOutWrap"); openScreen("recCreate"); });
    on("restoreRecoveryCode", () => { el("recIn").value = ""; el("recPassR").value = ""; el("recMsg").textContent = ""; openScreen("recRestore"); });
    on("recBackC", () => openScreen("settings"));
    on("recBackR", () => openScreen("settings"));
    on("recMake", () => {
        const pw = (el("recPassC").value || "").trim();
        if(pw.length < 3){ toast("رمز باید حداقل ۳ کاراکتر باشد"); return; }
        const code = generateRecoveryCode(pw);
        if(!code){ toast("ساخت کد انجام نشد، دوباره تلاش کن"); return; }
        el("recOut").value = code; show("recOutWrap");
        data.recoverySet = true; saveData();
        try { el("recOut").focus(); el("recOut").select(); } catch(e){}
        toast("✅ کد بازیابی ساخته شد");
    });
    on("recCopy", () => copyRecoveryText(el("recOut")));
    on("recPaste", () => {
        try { navigator.clipboard.readText().then(t => { el("recIn").value = t || ""; }).catch(() => toast("چسباندن مجاز نیست؛ روی کادر نگه دار و «Paste» را بزن")); }
        catch(e){ toast("چسباندن مجاز نیست؛ روی کادر نگه دار و «Paste» را بزن"); }
    });
    on("recDo", () => {
        const code = (el("recIn").value || "").trim(), pw = (el("recPassR").value || "").trim();
        if(!code){ el("recMsg").textContent = "کد بازیابی اکانت خود را وارد نمایید"; return; }
        if(!pw){ el("recMsg").textContent = "رمز بازیابی را وارد کن"; return; }
        const restored = restoreFromRecoveryCode(code, pw);
        if(!restored){ el("recMsg").textContent = "رمز یا کد اشتباه است"; return; }
        data = restored;
        try { migrateV80(); } catch(e){}
        sanitizeLoadedData(); securityPass();
        saveData(); applyTheme(); updateUI(); updateExtraUI(); openScreen("menu");
        toast("✅ حساب با موفقیت بازیابی شد!");
    });
    const sh = el("shakeToggle");
    if(sh) sh.onchange = () => { data.shakeOn = sh.checked; saveData(); toast(sh.checked ? "✅ لرزش صفحه فعال شد" : "لرزش صفحه غیرفعال شد"); };
    const ht = el("hapticToggle");
    if(ht) ht.onchange = () => { data.hapticOn = ht.checked; saveData(); toast(ht.checked ? "✅ ویبره فعال شد" : "ویبره غیرفعال شد"); };
    on("saveNick", () => {
        const v = (el("nickInput") && el("nickInput").value || "").trim().slice(0,16);
        data.nickname = v; save(); toast(v ? ("سلام " + v) : "نام پاک شد");
    });
    on("howtoFromSettings", () => openScreen("howto"));
    on("aboutFromSettings", () => openScreen("about"));
    on("shareScoreBtn", () => shareRun());
    document.querySelectorAll(".rateYesBtn").forEach(b => b.onclick = () => { requestMyketListing(); });
    on("rateYesSettings", () => { requestMyketListing(); });

    const jumpStart = (e) => {
        if(e.target && e.target.closest && e.target.closest(".screen,button,#soundButton,#musicButton,#pauseBtn,#settingsBtn")) return;
        jumpHeld = true; jump();
    };
    const jumpEnd = () => { jumpHeld = false; };
    canvas.addEventListener("pointerdown", jumpStart);
    addEventListener("pointerup", jumpEnd);
    addEventListener("keydown", (e) => {
        if(e.target && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA")) return;
        if(e.repeat) return;
        if(e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW"){ e.preventDefault(); jumpHeld = true; jump(); }
        if(e.code === "KeyP" || e.code === "Escape") togglePause();
        if(e.code === "KeyM"){ el("soundButton") && el("soundButton").click(); }
    });
    addEventListener("keyup", (e) => {
        if(e.target && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA")) return;
        if(e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") jumpHeld = false;
    });
    addEventListener("visibilitychange", () => {
        if(document.hidden){ saveData(); if(playing && !paused) togglePause(); audioSleep(); }
        else { audioWake(); }
    });
    addEventListener("pagehide", () => { try { saveData(); } catch(e){} audioSleep(); });
    addEventListener("pageshow", () => { audioWake(); });
    document.addEventListener("freeze", () => { audioSleep(); });
    document.addEventListener("resume", () => { audioWake(); });
}

function migrateV80(){
    data.musicVol = data.musicVol ?? 0.75;
    data.sfxVol = data.sfxVol ?? 0.85;
    data.gfx = data.gfx || "high";
    data.shakeOn = data.shakeOn !== false;
    data.adGemDate = data.adGemDate || "";
    data.adGemsToday = data.adGemsToday || 0;
    data.boostCombo = data.boostCombo || 0;
    data.m10 = data.m10 || 0; data.m10Claim = data.m10Claim || false;
    data.nearMissCoin = data.nearMissCoin || false; data.nearMissCoinOn = data.nearMissCoinOn || false;
    data.satellite = data.satellite || false; data.satelliteOwned = data.satelliteOwned || false;
    data.skinComet = data.skinComet || false; data.skinAurora = data.skinAurora || false;
    data.solarFlares = data.solarFlares || 0;
    data.luckyUntil = data.luckyUntil || 0;
    data.filterOwned = data.filterOwned || {};
    data.trailOwned = data.trailOwned || {};
    data.jumpEffectOwned = data.jumpEffectOwned || {};
    data.groundThemeOwned = data.groundThemeOwned || {};
    data.auraOwned = data.auraOwned || {};
    data.startFxOwned = data.startFxOwned || {};
    if(data.noAds || (data.noAdsUntil && data.noAdsUntil > Date.now())){ // خریداران قبلی هم همیشگی می‌شوند
        data.noAdsForever = true; data.noAdsUntil = 0; data.noAds = false;
    }
    if(data.vip){
        data.auraOwned.royal = true; data.startFxOwned.royal = true;
        data.trailOwned.royal = true; data.jumpEffectOwned.royal = true;
        data.groundThemeOwned.royal = true; data.filterOwned.royal = true;
        data.skinCosmicKing = true; data.satelliteOwned = true;
    }
    if(!data.starterGift){
        data.starterGift = true;
        data.coins += 250; data.gems += 8; data.totalGems = (data.totalGems || 0) + 8;
        data.boostShield += 1;
        toast("🎁 هدیه خوش‌آمد: ۲۵۰ سکه، ۸ الماس، ۱ سپر");
    }
    data.hapticOn = data.hapticOn !== false;
    data.nickname = data.nickname || "";
    data.skinNeptune = data.skinNeptune || false;
    data.skinSaturn = data.skinSaturn || false;
    data.iceStorms = data.iceStorms || 0;
    data.runsSinceBH = data.runsSinceBH || 0;
    data.runsSinceRG = data.runsSinceRG || 0;
    data.dailyDoubled = data.dailyDoubled || false;
    data.streakShield = data.streakShield || false;
    data.seenTutorial = data.seenTutorial || false;
    data.rated = data.rated || false;
    data.ratePromptOpened = !!data.ratePromptOpened;
    data.nativeRestoredSkus = Array.isArray(data.nativeRestoredSkus) ? data.nativeRestoredSkus.filter(v => typeof v === "string").slice(-300) : [];
    data.nativeGrantIds = Array.isArray(data.nativeGrantIds) ? data.nativeGrantIds.filter(v => typeof v === "string").slice(-300) : [];
    data.challengeDate = data.challengeDate || "";
    data.challengeClaimed = data.challengeClaimed || false;
    data.m11 = data.m11 || 0; data.m11Claim = data.m11Claim || false;
    data.lastRun = data.lastRun || null;
    data.version = GAME_VERSION;
    data.bestToday = data.bestToday || 0;
    data.bestTodayDate = data.bestTodayDate || "";
    data.guaranteedIceStorm = data.guaranteedIceStorm || false;
    data.guaranteedSolarFlare = data.guaranteedSolarFlare || false;
    data.meteorShowers = data.meteorShowers || 0;
    if(!data.distV2){ data.totalDistance = 0; data.distV2 = true; }
    data.shieldPickups = data.shieldPickups || 0;
    data.ghostUses = data.ghostUses || 0;
    data.slowTimeUses = data.slowTimeUses || 0;
    data.theme = data.theme || "dark";
    data.recoverySet = data.recoverySet || false;
    data.reviveShield = data.reviveShield || false; data.reviveShieldOn = data.reviveShieldOn || false;
    data.auroraRuns = data.auroraRuns || 0;
    data.starSets = data.starSets || 0;
    data.soundOn = data.soundOn !== false;
    data.musicOn = data.musicOn !== false;
    soundEnabled = data.soundOn;
    musicEnabled = data.musicOn;
    const sb = el("soundButton"); if(sb) sb.textContent = soundEnabled ? "🔊" : "🔇";
    const mb = el("musicButton"); if(mb) mb.textContent = musicEnabled ? "🎵" : "🚫";
}

/* ===== پیش‌نمایش بزرگ و متحرک برای همه‌ی افکت‌ها و اسکین‌ها در فروشگاه ===== */
const FX_PREVIEW_MAP = {
    buyFilterSunset:["filter","sunset"], buyFilterNight:["filter","night"], buyFilterEmerald:["filter","emerald"], buyFilterRoyal:["filter","royal"], buyFilterAurora:["filter","aurora"],
    buyTrailCyan:["trail","#00e5ff"], buyTrailPink:["trail","#ff5fc4"], buyTrailGreen:["trail","#4dff88"], buyTrailRoyal:["trail","#ffd447"], buyTrailRainbow:["trail","rainbow"],
    buyJumpIce:["jump","#00e5ff"], buyJumpStars:["jump","#ffd447"], buyJumpRoyal:["jump","#ffd447"], buyJumpNova:["jump","rainbow"],
    buyAuraPulse:["aura","pulse"], buyAuraOrbit:["aura","orbit"], buyAuraRainbow:["aura","rainbow"], buyAuraRoyal:["aura","royal"],
    buyStartFxWarp:["start","warp"], buyStartFxFlash:["start","flash"], buyStartFxRoyal:["start","royal"], buyStartFxPortal:["start","portal"]
};
function phantomPath(tt){ return { x: 33 + Math.sin(tt * 1.5) * 9, y: 34 + Math.sin(tt * 2.7) * 3.5 }; }
/* ===== پیش‌نمایش متحرک زمین‌های ویژه: سفینه روی زمین از چپ به راست می‌دود و دوباره از چپ وارد می‌شود ===== */
let groundPrevTimer = 0;

let skinPrevTimer = 0;

/* ================= سطح‌های گرافیک: پایین / متوسط / بالا (جدید) / مکس ================= */
let gfxForceMax = false;   // در پیش‌نمایش آیتم‌ها همیشه گرافیک «حداکثر» اعمال می‌شود
function gfxLevel(){ if(gfxForceMax) return "max"; const g = data.gfx; return (g === "max" || g === "high" || g === "medium" || g === "low") ? g : "medium"; }
function gfxMax(){ return gfxLevel() === "max"; }
function gfxPlus(){ const g = gfxLevel(); return g === "max" || g === "high"; }   // افکت‌های سطح مکس (در «بالا» با جزئیات کمتر)
function gfxHigh(){ return gfxLevel() !== "low"; }                                // متوسط و بالاتر
function gfxLow(){ return gfxLevel() === "low"; }
function gfxQ(){ const g = gfxLevel(); return g === "max" ? 1 : g === "high" ? 0.6 : g === "medium" ? 0.35 : 0.15; } // ضریب تعداد جزئیات

/* ================= بایوم‌های اختصاصی هر مود ================= */
// هر مود یک بایوم ثابت دارد؛ فقط شدت/تیرگی/روشنی همان رنگ با پیشرفت (امتیاز یا زمان) تغییر می‌کند.
function _hx(h){ return [parseInt(h.slice(1,3),16), parseInt(h.slice(3,5),16), parseInt(h.slice(5,7),16)]; }
const BIO = {
    classic: { // بنفش کهکشانی — با امتیاز
        by:"score", th:[0,600,1500,2600,4000,6000],
        bg:[["#070219","#170a40","#26105a"],["#09021f","#1f0c52","#34167a"],["#0c0328","#2a1068","#451f96"],["#07021a","#200a4d","#331270"],["#110433","#3a1480","#5e26b8"],["#16053c","#4a1a96","#7a30d0"]],
        gr:[["#4a2a9c","#12063a"],["#5a30b0","#150845"],["#6a38c6","#190a52"],["#43238a","#0f0530"],["#7842d6","#1d0b5e"],["#8a4ee6","#220e6c"]],
        neb:["140,80,255","200,100,255","90,60,230"], rgb:"150,90,255" },
    time: { // زرد درخشان خورشیدی — با زمان (۶۰ ثانیه)
        by:"time", th:[0,10,22,36,50],
        bg:[["#2b1900","#5f3c00","#8a5a00"],["#331f00","#734a00","#a86e00"],["#3b2200","#885600","#bd7c00"],["#442300","#965a00","#d28f08"],["#4a2800","#a05d00","#e0a010"]],
        gr:[["#f2b830","#4a2e00"],["#f6c23a","#523300"],["#fbcd45","#5a3800"],["#ffd24f","#623c00"],["#ffd95a","#6a4200"]],
        neb:["255,200,60","255,150,40","255,230,140"], rgb:"255,190,50" },
    hard: { // آبی آسمانی با کمی سفیدیِ بی‌رنگ
        by:"score", th:[0,700,1700,3200,5200,8000],
        bg:[["#061a36","#0e4378","#2f86c4"],["#07203f","#124f8c","#4a9fd6"],["#082644","#1760a3","#6ab4e2"],["#051630","#0c3a69","#3a82b8"],["#0a2a50","#1d6db4","#8cc6ec"],["#0c3058","#2278c2","#a8d6f2"]],
        gr:[["#9fd0ee","#0b2c52"],["#aad6f2","#0e3560"],["#b8e0f6","#123e6c"],["#8cc2e4","#082546"],["#c6e8f8","#164676"],["#d4eefa","#1a4f82"]],
        neb:["120,190,255","225,238,255","90,160,230"], rgb:"140,200,255" },
    impossible: { // نارنجی و قرمزِ تند
        by:"score", th:[0,500,1300,2400,3800,5600],
        bg:[["#1a0200","#560d00","#8e2200"],["#200300","#6a1200","#aa2d00"],["#280400","#7e1700","#c63a00"],["#170200","#4a0b00","#7a1800"],["#2e0500","#901c00","#e04800"],["#350600","#a82200","#f05a08"]],
        gr:[["#ff6a1f","#3a0800"],["#ff7424","#420a00"],["#ff7f2a","#4a0c00"],["#d85010","#300600"],["#ff8a30","#520e00"],["#ff9438","#5a1000"]],
        neb:["255,90,30","255,40,20","255,160,60"], rgb:"255,90,30" },
    aurora: { // سبز ملایم شفقی با کمی سفیدیِ بی‌رنگ
        by:"score", th:[0,600,1500,3000,5000,8000],
        bg:[["#03131a","#0b3a38","#2a6f60"],["#04161d","#104a42","#3a8672"],["#051820","#165a4d","#4d9c86"],["#03101a","#0c3432","#25604f"],["#061c24","#1c6657","#62b09a"],["#08222a","#227363","#7cc4ae"]],
        gr:[["#8fd8c0","#0b3030"],["#9adec8","#0e3a38"],["#a6e4d0","#114240"],["#7cc2ac","#082828"],["#b2eada","#154a47"],["#c0f0e2","#1a5450"]],
        neb:["90,230,180","225,255,245","60,200,150"], rgb:"110,235,190" }
};
Object.keys(BIO).forEach(k => { const b = BIO[k]; b.bgR = b.bg.map(s => s.map(_hx)); b.grR = b.gr.map(s => s.map(_hx)); });
Object.keys(BIO).forEach(k => { MAX_BIOME[k] = BIO[k].neb; });
let bioV = 0, bioCur = null, bioKeyStr = "";
function _lerpRGB(a, b, f){ return [a[0]+(b[0]-a[0])*f, a[1]+(b[1]-a[1])*f, a[2]+(b[2]-a[2])*f]; }
function _rgbStr(c){ return "rgb(" + (c[0]|0) + "," + (c[1]|0) + "," + (c[2]|0) + ")"; }
// موقعیت پیوسته‌ی بایوم: عدد حقیقی بین ۰ و (تعداد مرحله‌ها-۱)
function bioIndexAt(mode, v){
    const b = BIO[mode] || BIO.classic, th = b.th;
    if(!(v > 0)) return 0;
    for(let i = 0; i < th.length - 1; i++){
        if(v < th[i+1]){ const f = (v - th[i]) / (th[i+1] - th[i]); return i + f*f*(3 - 2*f); }
    }
    return th.length - 1;
}
function bioCompute(mode, idx){
    const b = BIO[mode] || BIO.classic, i = Math.min(b.bgR.length - 2, Math.floor(idx)), f = Math.min(1, idx - i);
    const j = idx >= b.bgR.length - 1 ? b.bgR.length - 1 : i + 1, ff = idx >= b.bgR.length - 1 ? 0 : f;
    const bg = [0,1,2].map(k => _rgbStr(_lerpRGB(b.bgR[i][k], b.bgR[j][k], ff)));
    const gr = [0,1].map(k => _rgbStr(_lerpRGB(b.grR[i][k], b.grR[j][k], ff)));
    return { bg, gr, idx };
}
function bioTargetV(){
    if(gameMode === "time") return Math.max(0, 60 - Math.max(0, modeTimer));
    return Math.max(0, score || 0);
}
function bioReset(){ bioV = 0; bioKeyStr = ""; bioCur = bioCompute(gameMode, 0); try { makeNebulae(); } catch(e){} }
function bioUpdate(dt){
    const target = bioTargetV();
    bioV += (target - bioV) * Math.min(1, 0.05 * dt);
    if(Math.abs(target - bioV) < 0.5) bioV = target;
    const idx = bioIndexAt(gameMode, bioV);
    const k = gameMode + ":" + Math.round(idx * 60);
    if(k !== bioKeyStr){ bioKeyStr = k; bioCur = bioCompute(gameMode, idx); }
}
function getBgGradient(){
    if(!bioCur) bioReset();
    const key = gameMode + "_" + bioKeyStr + "_" + W + "_" + H;
    if(bgGradCache.key === key) return bgGradCache.grad;
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, bioCur.bg[0]); g.addColorStop(0.55, bioCur.bg[1]); g.addColorStop(1, bioCur.bg[2]);
    bgGradCache = { key, grad: g };
    return g;
}
// تزئینات اختصاصی هر بایوم (روی گرادیان، زیر ستاره‌ها) — برای بازی و پیش‌نمایش فیلتر مشترک است
function paintBiomeDecor(c, mode, w, h, t, idx, gy){
    paintBiomeHaze(c, mode, w, h, t, idx);
    c.save();
    if(mode === "time"){ // خورشید درخشان گوشه‌ی بالا
        const sx = w * 0.82, sy = h * 0.14, r = Math.min(w, h) * (0.55 + idx * 0.06);
        const g = c.createRadialGradient(sx, sy, 0, sx, sy, r);
        g.addColorStop(0, "rgba(255,240,170,0.55)"); g.addColorStop(0.18, "rgba(255,214,90,0.32)"); g.addColorStop(0.5, "rgba(255,170,40,0.10)"); g.addColorStop(1, "rgba(255,150,30,0)");
        c.fillStyle = g; c.fillRect(0, 0, w, h);
        c.globalCompositeOperation = "lighter";
        c.strokeStyle = "rgba(255,225,130,0.045)"; c.lineWidth = Math.max(6, w * 0.025);
        for(let i = 0; i < 7; i++){
            const a = t * 0.00012 + i * 0.9;
            c.beginPath(); c.moveTo(sx, sy); c.lineTo(sx + Math.cos(a) * r * 1.6, sy + Math.sin(a) * r * 1.6); c.stroke();
        }
    } else if(mode === "hard"){ // رشته‌های ابرِ سفیدِ بی‌رنگ
        c.fillStyle = "rgba(235,246,255,0.075)";
        for(let i = 0; i < 5; i++){
            const x = ((i * w * 0.31 - t * 0.012 * (0.6 + i * 0.15)) % (w + 220) + (w + 220)) % (w + 220) - 110;
            const y = h * (0.12 + i * 0.13);
            c.beginPath(); c.ellipse(x, y, 90 + i * 12, 14 + i * 2, 0, 0, Math.PI * 2); c.fill();
            c.beginPath(); c.ellipse(x + 40, y - 8, 55, 11, 0, 0, Math.PI * 2); c.fill();
        }
        const mg = c.createLinearGradient(0, h * 0.5, 0, h);
        mg.addColorStop(0, "rgba(240,248,255,0)"); mg.addColorStop(1, "rgba(240,248,255," + (0.07 + idx * 0.012) + ")");
        c.fillStyle = mg; c.fillRect(0, h * 0.5, w, h * 0.5);
    } else if(mode === "impossible"){ // خاکستر و اخگرِ بالا‌رونده
        c.globalCompositeOperation = "lighter";
        for(let i = 0; i < 18; i++){
            const sp = 0.02 + (i % 5) * 0.006;
            const x = (i * 97.3 + Math.sin(t * 0.0008 + i) * 22 + w * 10) % w;
            const y = h - ((t * sp + i * 71) % (h * 0.95));
            const a = 0.10 + 0.12 * (1 - (h - y) / h);
            c.fillStyle = "rgba(255," + (110 + (i % 4) * 25) + ",40," + a.toFixed(3) + ")";
            c.beginPath(); c.arc(x, y, 1.2 + (i % 3) * 0.9, 0, Math.PI * 2); c.fill();
        }
        const rg = c.createLinearGradient(0, h * 0.55, 0, h);
        rg.addColorStop(0, "rgba(255,70,20,0)"); rg.addColorStop(1, "rgba(255,70,20," + (0.10 + idx * 0.02) + ")");
        c.fillStyle = rg; c.fillRect(0, h * 0.55, w, h * 0.45);
    } else if(mode === "aurora"){ // مه‌ی سفیدِ بی‌رنگ نزدیک افق
        const mg = c.createLinearGradient(0, h * 0.35, 0, h);
        mg.addColorStop(0, "rgba(235,255,248,0)"); mg.addColorStop(1, "rgba(235,255,248," + (0.07 + idx * 0.014) + ")");
        c.fillStyle = mg; c.fillRect(0, h * 0.35, w, h * 0.65);
    } else { // classic: مه‌ی بنفشِ نرم
        const mg = c.createLinearGradient(0, h * 0.4, 0, h);
        mg.addColorStop(0, "rgba(170,110,255,0)"); mg.addColorStop(1, "rgba(170,110,255," + (0.05 + idx * 0.012) + ")");
        c.fillStyle = mg; c.fillRect(0, h * 0.4, w, h * 0.6);
    }
    c.restore();
}
function paintAuroraCurtains(c, w, t){ // پرده‌های سبز/سفیدِ شفق (بدون بنفش)
    c.save();
    c.globalCompositeOperation = "lighter";
    for(let i = 0; i < 3; i++){
        const ag = c.createLinearGradient(0, 40 + i * 40, w, 180 + i * 50);
        ag.addColorStop(0, "rgba(110,255,200,0)");
        ag.addColorStop(0.4, "rgba(" + (150 + i * 30) + "," + (255 - i * 8) + "," + (215 + i * 14) + "," + (0.08 + i * 0.03) + ")");
        ag.addColorStop(1, "rgba(220,255,240,0)");
        c.fillStyle = ag;
        c.beginPath(); c.moveTo(0, 80 + i * 30);
        for(let x = 0; x <= w; x += 24) c.lineTo(x, 70 + i * 28 + Math.sin(x * 0.01 + t + i) * 28);
        c.lineTo(w, 0); c.lineTo(0, 0); c.fill();
    }
    c.restore();
}

/* ---- تنوع رنگی هر بایوم: مه‌ها و لکه‌های نرمِ هم‌خانواده که آرام جابه‌جا می‌شوند (رنگ اصلی بایوم عوض نمی‌شود) ---- */
const BIO_TONES = {
    classic:    [["60,70,215",0.30],["145,70,235",0.26],["205,175,255",0.15],["175,60,205",0.16],["25,30,110",0.32]],   // نیلی، بنفش، مه‌ی یاسی، ارغوانی، سرمه‌ای تیره
    time:       [["255,205,70",0.20],["255,150,40",0.22],["255,232,140",0.14],["190,110,15",0.28]],                     // زرد، کهربایی، لیمویی روشن، برنزی
    hard:       [["70,165,255",0.22],["120,215,255",0.18],["240,248,255",0.13],["35,95,200",0.28]],                     // آبی آسمانی، فیروزه‌ای روشن، مه‌ی سفید، آبی عمیق
    impossible: [["255,65,28",0.26],["255,135,40",0.22],["200,28,35",0.28],["255,190,70",0.13]],                        // قرمز، نارنجی، سرخ تیره، اخگر
    aurora:     [["70,230,165",0.20],["60,200,195",0.17],["232,255,246",0.12],["140,255,150",0.13]]                     // سبز، سبز-آبی، مه‌ی سفید، سبز روشن
};
function paintBiomeHaze(c, mode, w, h, t, idx){
    const tones = BIO_TONES[mode] || BIO_TONES.classic, s = t / 1000, R = Math.max(w, h);
    const n = gfxLow() ? 0 : (gfxLevel() === "medium" ? Math.min(3, tones.length) : tones.length);
    if(!n) return;
    c.save();
    for(let i = 0; i < n; i++){
        const tn = tones[i], px = w * (0.5 + 0.42 * Math.sin(s * (0.05 + i * 0.013) + i * 1.9)), py = h * (0.30 + 0.28 * Math.cos(s * (0.04 + i * 0.011) + i * 2.3)) + i * h * 0.05;
        const r = R * (0.42 + 0.14 * Math.sin(s * 0.07 + i)), a = tn[1] * (0.55 + 0.45 * Math.sin(s * (0.11 + i * 0.03) + i * 1.1)) * (0.75 + Math.min(5, idx) * 0.06);
        const g = c.createRadialGradient(px, py, 0, px, py, r); g.addColorStop(0, "rgba(" + tn[0] + "," + a.toFixed(3) + ")"); g.addColorStop(1, "rgba(" + tn[0] + ",0)");
        c.fillStyle = g; c.fillRect(px - r, py - r, r * 2, r * 2);
    }
    c.restore();
}

/* ================================================================
   موتور مشترک شخصی‌سازی: اسکین، دنباله، افکت پرش، ذرات
   (بازی و پیش‌نمایش‌ها دقیقاً از همین توابع استفاده می‌کنند)
   ================================================================ */
const CX_TAU = Math.PI * 2;
function cxRnd(a, b){ return a + Math.random() * (b - a); }
function cxPick(a){ return a[(Math.random() * a.length) | 0]; }
function cxHash(i){ const s = Math.sin(i * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); }
function cxEase(k){ k = Math.max(0, Math.min(1, k)); return 1 - (1 - k) * (1 - k); }
function cxRR(c, x, y, w, h, r){
    c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.arcTo(x + w, y, x + w, y + r, r);
    c.lineTo(x + w, y + h - r); c.arcTo(x + w, y + h, x + w - r, y + h, r);
    c.lineTo(x + r, y + h); c.arcTo(x, y + h, x, y + h - r, r);
    c.lineTo(x, y + r); c.arcTo(x, y, x + r, y, r); c.closePath();
}
function cxStar(c, x, y, r, pts, rot){ // ستاره‌ی n پر
    const n = pts || 4; c.beginPath();
    for(let i = 0; i < n * 2; i++){
        const a = (rot || 0) + i * Math.PI / n - Math.PI / 2, rr = i % 2 ? r * 0.42 : r;
        if(i === 0) c.moveTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); else c.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
    }
    c.closePath();
}
function cxHeart(c, x, y, s){
    c.beginPath(); c.moveTo(x, y + s * 0.9);
    c.bezierCurveTo(x - s * 1.4, y + s * 0.1, x - s * 0.8, y - s * 1.0, x, y - s * 0.35);
    c.bezierCurveTo(x + s * 0.8, y - s * 1.0, x + s * 1.4, y + s * 0.1, x, y + s * 0.9); c.closePath();
}
function cxCap(){ return gfxLow() ? 40 : gfxMax() ? 560 : gfxPlus() ? 440 : 320; }

/* ---------- ذرات ---------- */
function cxPush(arr, o){
    if(arr.length > cxCap()) return null;
    if(o.life === undefined) o.life = 1;
    o.type = "cx"; o.rot = o.rot || 0;
    arr.push(o); return o;
}
function cxUpdateList(arr, dt){
    for(const p of arr){
        p.x += p.vx * dt; p.y += p.vy * dt;
        p.vy += (p.g === undefined ? 0.12 : p.g) * dt;
        if(p.drag){ const d = Math.pow(p.drag, dt); p.vx *= d; p.vy *= d; }
        p.life -= (p.dec === undefined ? 0.04 : p.dec) * dt;
        if(p.grow) p.size = Math.max(0.1, p.size + p.grow * dt);
        if(p.vr) p.rot += p.vr * dt;
        if(p.pull){ p.vx += (p.tx - p.x) * p.pull * dt; p.vy += (p.ty - p.y) * p.pull * dt; }
    }
    let j = 0; for(let i = 0; i < arr.length; i++){ if(arr[i].life > 0) arr[j++] = arr[i]; } arr.length = j;
}
function cxColor(p){ return p.col || (p.hue !== undefined ? "hsl(" + (p.hue | 0) + ",95%,65%)" : "#ffffff"); }
function cxDrawList(c, arr, plus){
    if(!arr.length) return;
    c.save();
    for(const p of arr){
        if(p.type !== "cx") continue;
        const a = Math.max(0, Math.min(1, p.life));
        const col = cxColor(p), sz = Math.max(0.2, p.size);
        const sh = p.shape || "ball";
        c.globalAlpha = a * (p.alpha === undefined ? 1 : p.alpha);
        if(sh === "ring"){
            c.strokeStyle = col; c.lineWidth = Math.max(0.8, (p.lw || 3) * (0.4 + a * 0.6));
            c.beginPath(); c.ellipse(p.x, p.y, sz, sz * (p.sq || 0.3), 0, 0, CX_TAU); c.stroke();
        } else if(sh === "star"){
            c.fillStyle = col; cxStar(c, p.x, p.y, sz * 1.5, 4, p.rot); c.fill();
            if(plus){ c.save(); c.globalCompositeOperation = "lighter"; c.globalAlpha = a * 0.25; c.beginPath(); c.arc(p.x, p.y, sz * 2.2, 0, CX_TAU); c.fill(); c.restore(); }
        } else if(sh === "star5"){
            c.fillStyle = col; cxStar(c, p.x, p.y, sz * 1.6, 5, p.rot); c.fill();
        } else if(sh === "spark"){
            c.strokeStyle = col; c.lineWidth = Math.max(1, sz * 0.55); c.lineCap = "round";
            c.beginPath(); c.moveTo(p.x, p.y); c.lineTo(p.x - p.vx * 2.4, p.y - p.vy * 2.4); c.stroke();
        } else if(sh === "bolt"){
            c.strokeStyle = col; c.lineWidth = Math.max(1, sz * 0.5); c.lineCap = "round"; c.lineJoin = "round";
            const L = 11 + sz * 3.2, ang = p.rot, pt = [[p.x, p.y], [p.x + Math.cos(ang) * L * 0.3 + 3, p.y + Math.sin(ang) * L * 0.3 - 4], [p.x + Math.cos(ang) * L * 0.58 - 3, p.y + Math.sin(ang) * L * 0.58 + 3], [p.x + Math.cos(ang) * L, p.y + Math.sin(ang) * L]];
            if(plus){ c.save(); c.globalAlpha = a * 0.28; c.lineWidth = sz * 1.6; c.beginPath(); pt.forEach((q, i) => i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])); c.stroke(); c.restore(); }
            c.beginPath(); pt.forEach((q, i) => i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])); c.stroke();
        } else if(sh === "smoke"){
            c.fillStyle = col; c.globalAlpha = a * (p.alpha === undefined ? 0.5 : p.alpha) * 0.7;
            c.beginPath(); c.arc(p.x, p.y, sz, 0, CX_TAU); c.fill();
        } else if(sh === "bubble"){
            c.strokeStyle = col; c.lineWidth = 1.4; c.beginPath(); c.arc(p.x, p.y, sz, 0, CX_TAU); c.stroke();
            c.globalAlpha = a * 0.28; c.fillStyle = col; c.fill();
        } else if(sh === "shard"){
            c.fillStyle = col; c.save(); c.translate(p.x, p.y); c.rotate(p.rot);
            c.beginPath(); c.moveTo(0, -sz * 1.7); c.lineTo(sz * 0.8, 0); c.lineTo(0, sz * 1.7); c.lineTo(-sz * 0.8, 0); c.closePath(); c.fill(); c.restore();
        } else if(sh === "heart"){
            c.fillStyle = col; cxHeart(c, p.x, p.y, sz * 0.95); c.fill();
        } else if(sh === "petal"){
            c.fillStyle = col; c.save(); c.translate(p.x, p.y); c.rotate(p.rot); c.beginPath(); c.ellipse(0, 0, sz * 1.6, sz * 0.8, 0, 0, CX_TAU); c.fill(); c.restore();
        } else if(sh === "orb"){   // گوی درخشان نرم (جمع‌شونده با نور)
            c.save(); c.globalCompositeOperation = "lighter"; c.fillStyle = col;
            c.globalAlpha = a * 0.22; c.beginPath(); c.arc(p.x, p.y, sz * 2.7, 0, CX_TAU); c.fill();
            c.globalAlpha = a * 0.55; c.beginPath(); c.arc(p.x, p.y, sz * 1.55, 0, CX_TAU); c.fill();
            c.globalAlpha = a; c.fillStyle = "#ffffff"; c.beginPath(); c.arc(p.x, p.y, sz * 0.7, 0, CX_TAU); c.fill(); c.restore();
        } else if(sh === "feather"){   // پر
            c.fillStyle = col; c.save(); c.translate(p.x, p.y); c.rotate(p.rot);
            c.beginPath(); c.moveTo(0, -sz * 2.3); c.quadraticCurveTo(sz * 1.35, -sz * 0.6, 0, sz * 2.3); c.quadraticCurveTo(-sz * 1.35, -sz * 0.6, 0, -sz * 2.3); c.fill();
            c.strokeStyle = "rgba(255,255,255,0.8)"; c.lineWidth = 0.8; c.beginPath(); c.moveTo(0, -sz * 2.1); c.lineTo(0, sz * 2.1); c.stroke(); c.restore();
        } else if(sh === "flame"){   // شعله‌ی اشکی
            c.save(); c.translate(p.x, p.y); c.fillStyle = col;
            c.beginPath(); c.moveTo(0, sz * 1.5); c.quadraticCurveTo(sz * 1.3, sz * 0.3, sz * 0.2, -sz * 1.9); c.quadraticCurveTo(-sz * 0.1, -sz * 0.4, -sz * 0.9, sz * 0.4); c.quadraticCurveTo(-sz * 0.9, sz * 1.2, 0, sz * 1.5); c.fill();
            c.globalAlpha = a * 0.6; c.fillStyle = "#ffe9a0"; c.beginPath(); c.ellipse(0, sz * 0.6, sz * 0.4, sz * 0.7, 0, 0, CX_TAU); c.fill(); c.restore();
        } else if(sh === "beam"){   // ستون نور عمودی
            const hh = p.h || 50, bg = c.createLinearGradient(0, p.y, 0, p.y - hh);
            c.save(); c.globalCompositeOperation = "lighter"; bg.addColorStop(0, col); bg.addColorStop(1, "rgba(255,255,255,0)");
            c.fillStyle = bg; c.fillRect(p.x - sz * 0.5, p.y - hh, sz, hh);
            c.globalAlpha = a * 0.5; c.fillStyle = "#ffffff"; c.fillRect(p.x - sz * 0.14, p.y - hh * 0.8, sz * 0.28, hh * 0.8); c.restore();
        } else if(sh === "wing"){   // جفت بال سفید که از دو طرف باز می‌شود
            c.save(); c.translate(p.x, p.y); c.fillStyle = col; c.strokeStyle = "rgba(255,255,255,0.85)"; c.lineWidth = 1;
            for(let sd = -1; sd <= 1; sd += 2){
                c.save(); c.scale(sd, 1); c.rotate(-0.45 * (1 - a));
                c.beginPath(); c.moveTo(0, 0); c.bezierCurveTo(sz * 0.4, -sz * 0.9, sz * 1.1, -sz * 1.0, sz * 1.8, -sz * 0.5);
                for(let f = 0; f < 4; f++){ const fx = sz * (1.8 - (f + 1) * 0.4), fy = -sz * 0.5 + (f + 1) * sz * 0.22; c.quadraticCurveTo(fx + sz * 0.32, fy + sz * 0.5, fx, fy); }
                c.quadraticCurveTo(sz * 0.1, sz * 0.3, 0, 0); c.closePath(); c.fill(); c.stroke(); c.restore();
            }
            c.restore();
        } else if(sh === "pent"){   // پنتاگرام روی زمین (شیطان)
            c.save(); c.translate(p.x, p.y); c.scale(1, p.sq || 0.3); c.rotate(p.rot); c.strokeStyle = col; c.lineWidth = Math.max(0.8, (p.lw || 2) * (0.4 + a * 0.6));
            c.beginPath(); c.arc(0, 0, sz, 0, CX_TAU); c.stroke();
            c.beginPath(); for(let i = 0; i < 5; i++){ const ang = -Math.PI / 2 + i * 2 * CX_TAU / 5, qx = Math.cos(ang) * sz, qy = Math.sin(ang) * sz; if(i) c.lineTo(qx, qy); else c.moveTo(qx, qy); } c.closePath(); c.stroke(); c.restore();
        } else { // ball
            c.fillStyle = col; c.beginPath(); c.arc(p.x, p.y, sz, 0, CX_TAU); c.fill();
            if(plus && p.glow !== false){ c.save(); c.globalCompositeOperation = "lighter"; c.globalAlpha = a * 0.22; c.beginPath(); c.arc(p.x, p.y, sz * 2.3, 0, CX_TAU); c.fill(); c.restore(); }
        }
    }
    c.globalAlpha = 1;
    c.restore();
}
/* ذرات قدیمیِ رویدادها (برخورد، سکه، الماس…) همان رفتار قبلی را دارند */
function particles(x, y, n, type = "coin"){
    if(gfxPlus()) n = Math.ceil(n * (gfxMax() ? 1.6 : 1.3));
    for(let i = 0; i < n; i++){
        particlesArr.push({ x, y, vx: (Math.random() - .5) * (type === "flame" ? 3 : 5), vy: (Math.random() - .5) * (type === "flame" ? 3 : 5), life: 1, size: 2 + Math.random() * 4, type });
    }
}
const cxArr = [];   // ذرات افکت‌های شخصی‌سازی (دنباله/پرش)
function updateParticles(dt){
    for(const p of particlesArr){ p.x += p.vx * dt; p.y += p.vy * dt; p.vy += .12 * dt; p.life -= .04 * dt; }
    particlesArr = particlesArr.filter(p => p.life > 0);
    cxUpdateList(cxArr, dt);
    floaters.forEach(f => { f.y -= .6 * dt; f.life -= .025 * dt; });
    floaters = floaters.filter(f => f.life > 0);
}
function drawParticles(){
    for(const p of particlesArr){
        ctx.globalAlpha = p.life;
        ctx.fillStyle = p.type === "hit" ? "#ff5d65" : p.type === "flame" ? "#ffaa00" : p.type === "gem" ? "#64e7ff" : p.type === "nova" ? `hsl(${p.hue||0},95%,65%)` : p.type === "goldtrail" ? "#ffd447" : p.type === "neptunefrost" ? "#9fe8ff" : p.type === "trailCyan" ? "#00e5ff" : p.type === "trailPink" ? "#ff5fc4" : p.type === "trailGreen" ? "#4dff88" : "#ffd447";
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill();
        if(gfxPlus()){ ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = p.life * 0.16; ctx.beginPath(); ctx.arc(p.x, p.y, p.size * 2.1, 0, Math.PI * 2); ctx.fill(); ctx.restore(); }
    }
    ctx.globalAlpha = 1;
    cxDrawList(ctx, cxArr, gfxPlus());
    floaters.forEach(f => {
        ctx.globalAlpha = Math.max(0, f.life);
        ctx.fillStyle = f.color || "#fff";
        ctx.font = "bold 16px Tahoma"; ctx.textAlign = "center";
        if(gfxPlus()){ ctx.lineWidth = 3; ctx.strokeStyle = "rgba(0,0,0,0.55)"; ctx.strokeText(f.text, f.x, f.y); }
        ctx.fillText(f.text, f.x, f.y);
    });
    ctx.globalAlpha = 1;
}

/* ---------- دنباله‌ها (گاز خروجی از پشت سفینه که پخش می‌شود و محو می‌شود) ---------- */
const TRAILS = {
    cyan:      { cols:["#00e5ff","#8ff3ff","#d9fbff"], shape:"ball", rate:0.6, size:[2.6,4.8], spd:[1.8,3.9], cone:0.78, dec:0.03, grow:0.025 },
    pink:      { cols:["#ff5fc4","#ff9bdc","#ffd6f0"], shape:"ball", rate:0.6, size:[2.6,4.8], spd:[1.8,3.9], cone:0.78, dec:0.03, grow:0.025 },
    green:     { cols:["#4dff88","#b6ff4d","#19c75f"], shape:"bubble", rate:0.55, size:[2.6,5], spd:[1.6,3.4], cone:0.85, dec:0.026, grow:0.05, rise:-0.08 },
    violet:    { cols:["#b36bff","#d9a8ff","#7a3dff"], shape:"ball", rate:0.6, size:[2.6,4.8], spd:[1.8,3.9], cone:0.78, dec:0.03, grow:0.025 },
    ember:     { cols:["#ffb347","#ff7a1a","#ffe27a"], shape:"spark", rate:0.75, size:[2.8,4.6], spd:[2.6,5.6], cone:0.8, dec:0.045, g:-0.012 },
    stardust:  { layers:[ { cols:["#ffffff","#ffe9a8","#b9d4ff"], shape:"star", rate:0.55, size:[2.2,4], spd:[1.6,3.4], cone:0.85, dec:0.028, vr:0.12 }, { cols:["#ffffff","#ffe9a8"], shape:"orb", rate:0.2, size:[1.4,2.2], spd:[1,2.6], cone:0.9, dec:0.03 } ] },
    smoke:     { cols:["#d7dde8","#aab4c6","#eef2fa"], shape:"smoke", rate:0.5, size:[4.5,7.5], spd:[0.9,2.2], cone:0.55, dec:0.02, grow:0.2, rise:-0.1 },
    blueflame: { cols:["#3d7bff","#7fb2ff","#d4e6ff"], shape:"ball", rate:0.75, size:[3,5.2], spd:[1.6,3.6], cone:0.4, dec:0.05, grow:-0.045, rise:-0.14 },
    rainbow:   { layers:[ { rainbow:true, shape:"ball", rate:1.0, size:[2.8,4.8], spd:[1.5,3.6], cone:0.66, dec:0.03, grow:0.02 }, { rainbow:true, shape:"orb", rate:0.5, size:[2,3.4], spd:[1.2,3.2], cone:0.8, dec:0.034 }, { cols:["#ffffff"], shape:"star", rate:0.5, size:[1.5,2.6], spd:[1,3], cone:0.95, dec:0.024, vr:0.18 }, { rainbow:true, shape:"ball", rate:0.5, size:[1.6,2.6], spd:[3,5.5], cone:0.35, dec:0.05 } ] },
    galaxy:    { layers:[ { cols:["#9a6bff","#5aa8ff","#ff7ad9","#ffffff"], mix:["ball","star"], rate:0.8, size:[2.2,4.4], spd:[1.4,3.4], cone:0.7, dec:0.028, vr:0.1 }, { cols:["#c9a8ff","#8fc4ff","#ff9be8"], shape:"orb", rate:0.34, size:[2,3.6], spd:[1.2,3], cone:0.8, dec:0.03 }, { cols:["#ffffff"], shape:"star", rate:0.4, size:[1.4,2.4], spd:[0.8,2.4], cone:0.95, dec:0.022, vr:0.16 }, { cols:["#6a4aff","#2a1a8a"], shape:"smoke", rate:0.3, size:[5,8], spd:[0.7,1.8], cone:0.5, dec:0.018, grow:0.22 } ] },
    electric:  { layers:[ { cols:["#9fe9ff","#ffffff","#5ac8ff"], shape:"bolt", rate:0.85, size:[2.6,4.4], spd:[2,4.2], cone:0.85, dec:0.06 }, { cols:["#ffffff","#bff3ff"], shape:"orb", rate:0.4, size:[1.6,2.8], spd:[1.2,3], cone:0.9, dec:0.07 }, { cols:["#8fe8ff","#ffffff"], shape:"spark", rate:0.5, size:[1.4,2.4], spd:[3,6], cone:0.7, dec:0.09 } ] },
    volcano:   { layers:[ { cols:["#ff5a1a","#ff9a2a","#ffd24a"], mix:["ball","smoke"], smokeCol:"#4a3a38", rate:0.85, size:[3,5.6], spd:[1.2,3.2], cone:0.68, dec:0.03, grow:0.05, g:-0.01 }, { cols:["#ffd24a","#fff2b0"], shape:"spark", rate:0.5, size:[1.6,2.6], spd:[2.6,5.6], cone:0.8, dec:0.05, g:-0.01 }, { cols:["#ff7a2a","#ffb347"], shape:"orb", rate:0.26, size:[2,3.2], spd:[1.2,3], cone:0.8, dec:0.04, g:-0.03 } ] },
    royal:     { layers:[ { cols:["#ffd447","#fff3b0","#c06cff","#ffffff"], mix:["star","ball"], rate:0.85, size:[2.4,4.6], spd:[1.4,3.4], cone:0.7, dec:0.028, vr:0.1 }, { cols:["#ffe27a","#ffffff"], shape:"orb", rate:0.4, size:[2,3.4], spd:[1.2,3], cone:0.8, dec:0.03 }, { cols:["#c06cff"], shape:"star", rate:0.3, size:[1.6,2.6], spd:[1,2.8], cone:0.9, dec:0.025, vr:0.16 } ] },
    angel:     { layers:[ { cols:["#ffffff","#fff6d8","#dff1ff"], shape:"feather", rate:0.55, size:[2,3.4], spd:[0.9,2.4], cone:0.8, dec:0.02, g:0.03, vr:0.1 }, { cols:["#fff3b0","#ffffff","#ffe27a"], shape:"orb", rate:0.5, size:[1.8,3], spd:[1.2,3], cone:0.7, dec:0.03 }, { cols:["#ffffff","#bfe8ff"], shape:"star", rate:0.4, size:[1.4,2.6], spd:[1,3], cone:0.9, dec:0.024, vr:0.14 }, { cols:["#eaf6ff","#cfe9ff"], shape:"smoke", rate:0.35, size:[5,8], spd:[0.7,1.8], cone:0.5, dec:0.02, grow:0.2, rise:-0.08 }, { cols:["#8fd6ff","#bfe8ff"], shape:"ball", rate:0.3, size:[1.6,2.6], spd:[1.4,3], cone:0.6, dec:0.04 } ] },
    devil:     { layers:[ { cols:["#ff3b1a","#ff7a1a","#ffb347"], shape:"flame", rate:0.65, size:[2.4,4], spd:[1.2,3], cone:0.6, dec:0.04, g:-0.05 }, { cols:["#2a1018","#4a1a28","#1a0a10"], shape:"smoke", rate:0.5, size:[5,8.5], spd:[0.8,2], cone:0.55, dec:0.02, grow:0.22, rise:-0.1 }, { cols:["#ffb347","#ff5a1a"], shape:"spark", rate:0.5, size:[1.6,2.6], spd:[2.6,5.4], cone:0.8, dec:0.05, g:-0.01 }, { cols:["#ff2a2a","#ff6a3a"], shape:"orb", rate:0.28, size:[2,3.2], spd:[1.2,3], cone:0.8, dec:0.034 } ] }
};
function cxTrailKey(){ const k = data.trailColor; return (k && k !== "none" && k !== "default" && TRAILS[k]) ? k : null; }
function trailGlowRGB(){ // رنگ هاله‌ی گرافیک بالا پشت سفینه (فقط وقتی دنباله انتخاب شده)
    const k = cxTrailKey(); if(!k) return null;
    const m = { cyan:"0,229,255", pink:"255,95,196", green:"77,255,136", violet:"179,107,255", ember:"255,140,40", stardust:"255,233,168", smoke:"200,208,222", blueflame:"90,150,255", rainbow:"180,120,255", galaxy:"154,107,255", electric:"120,220,255", volcano:"255,120,30", royal:"255,212,71", angel:"255,240,190", devil:"255,60,40" };
    return m[k] || null;
}
function cxEmitTrail(arr, key, x, y, dt, st, mul){
    const s = TRAILS[key]; if(!s) return;
    const list = s.layers || [s];   // دنباله‌های گران‌تر چند لایه‌ی هم‌زمان دارند (گاز، جرقه، گوی نورانی، ستاره…)
    st.accL = st.accL || [];
    list.forEach((L, i) => {
        st.accL[i] = (st.accL[i] || 0) + L.rate * (mul || 1) * dt;
        let n = 0;
        while(st.accL[i] >= 1 && n < 5){ st.accL[i] -= 1; n++; cxSpawnTrail(arr, L, x, y); }
        if(st.accL[i] > 2) st.accL[i] = 0;
    });
}
function cxSpawnTrail(arr, s, x, y){
    const ang = Math.PI + cxRnd(-s.cone, s.cone), sp = cxRnd(s.spd[0], s.spd[1]);
    let shape = s.shape || "ball", col = s.cols ? cxPick(s.cols) : null, hue;
    if(s.mix){ shape = cxPick(s.mix); if(shape === "smoke" && s.smokeCol) col = s.smokeCol; }
    if(s.rainbow){ hue = ((performance.now() / 10) + cxRnd(0, 70)) % 360; }
    cxPush(arr, { x: x + cxRnd(-1.5, 1.5), y: y + cxRnd(-2, 2), vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp + (s.rise || 0),
        size: cxRnd(s.size[0], s.size[1]), life: 1, dec: s.dec * cxRnd(0.85, 1.2), grow: s.grow || 0, g: s.g || 0, drag: 0.985,
        shape, col, hue, rot: cxRnd(0, 6.28), vr: s.vr ? s.vr * cxRnd(-1, 1) : 0, glow: shape === "ball" || shape === "star" });
}

/* ---------- افکت‌های پرش (انفجار از زیر سفینه) ---------- */
const JUMPS = {
    ice:    { cols:["#bfefff","#7ad7ff","#ffffff"], shape:"shard", n:18, spd:[1.8,5.2], up:1.6, size:[1.8,3.4], ring:"#8fe6ff", ring2:"#e8fbff", dec:0.032, g:0.1 },
    poison: { cols:["#4dff88","#b6ff4d","#19c75f"], shape:"bubble", n:12, spd:[1,3.4], up:2.2, size:[2.4,4.6], ring:"#6bff7a", dec:0.026, g:-0.03, grow:0.05 },
    pink:   { cols:["#ff5fc4","#ff9bdc","#ffd6f0"], shape:"heart", n:10, spd:[1.2,3.6], up:2.4, size:[2.4,4], ring:"#ff8fd2", dec:0.03, g:-0.02 },
    halo:   { cols:["#ffffff","#9fd6ff"], shape:"star", n:9, spd:[1.2,3], up:0.8, size:[1.6,2.8], ring:"#ffffff", ring2:"#7ac4ff", ring3:"#bfe6ff", dec:0.036, g:0.02 },
    spark:  { cols:["#fff6a0","#ffe14a","#ffffff"], shape:"bolt", n:12, spd:[2,5.4], up:1, size:[1.8,3.2], ring:"#ffe14a", ring2:"#ffffff", dec:0.05, g:0.06, extra:[ { cols:["#ffffff","#fff6a0"], shape:"orb", n:6, spd:[1,3], up:1.5, size:[1.6,2.6], dec:0.05, g:0.02 } ] },
    dust:   { cols:["#c8cfdc","#a4adbe","#e8edf6"], shape:"smoke", n:13, spd:[1,3.2], up:0.6, size:[4,7], dec:0.03, g:-0.01, grow:0.22, flat:true },
    nova:   { rainbow:true, shape:"ball", n:20, spd:[2,5.6], up:1.2, size:[2.4,4.6], ring:"rainbow", ring2:"#ffffff", ring3:"#9fd6ff", dec:0.034, g:0.08, beam:{ col:"rainbow", h:100, w:16 }, extra:[ { rainbow:true, shape:"star", n:16, spd:[2.5,6.8], up:1.6, size:[2,3.6], dec:0.03, g:0.05 }, { rainbow:true, shape:"orb", n:10, spd:[1.5,4.2], up:2.4, size:[2,3.4], dec:0.032, g:0.04 } ] },
    volcano:{ cols:["#ff5a1a","#ff9a2a","#ffd24a"], shape:"ball", n:22, spd:[2.2,5.8], up:3.8, size:[2.8,5.4], ring:"#ff7a2a", ring2:"#ffd24a", ring3:"#5a1a08", dec:0.03, g:0.16, smoke:"#4a3a38", beam:{ col:"#ff7a2a", h:90, w:14 }, extra:[ { cols:["#fff2b0","#ffd24a","#ff9a2a"], shape:"spark", n:18, spd:[3.2,7.4], up:4.4, size:[1.6,2.6], dec:0.028, g:0.22 }, { cols:["#ff7a2a","#ffd24a"], shape:"orb", n:8, spd:[1.2,3.6], up:3.2, size:[2,3.2], dec:0.03, g:0.12 }, { cols:["#ff6a1a","#c43a0a"], shape:"flame", n:6, spd:[1,3], up:3, size:[2.4,3.6], dec:0.04, g:-0.02 } ] },
    void:   { cols:["#b58cff","#7a3dff","#e8d8ff"], shape:"ball", n:20, spd:[3.4,5.4], up:0, size:[2.2,4.2], ring:"#9a5cff", ring2:"#e8d8ff", ring3:"#30104a", dec:0.04, g:0, implode:true, beam:{ col:"#9a5cff", h:80, w:12 }, extra:[ { cols:["#ffffff","#e8d8ff"], shape:"star", n:10, spd:[3,6], up:0, size:[1.6,2.8], dec:0.05, g:0 }, { cols:["#b58cff","#7a3dff"], shape:"orb", n:8, spd:[2,4.4], up:0, size:[2,3.4], dec:0.04, g:0, implode:true } ] },
    royal:  { cols:["#ffd447","#fff3b0","#ffffff","#c06cff"], shape:"star", n:16, spd:[1.8,5], up:1.6, size:[2,4], ring:"#ffd447", ring2:"#fff3b0", dec:0.03, g:0.07, beam:{ col:"#ffd447", h:80, w:12 }, extra:[ { cols:["#ffe27a","#ffffff"], shape:"orb", n:8, spd:[1.2,3.6], up:2, size:[2,3.2], dec:0.032, g:0.03 } ] },
    angel:  { cols:["#ffffff","#fff3c0","#dff1ff"], shape:"feather", n:12, spd:[1,3.4], up:2.6, size:[2.2,3.6], ring:"#fff3c0", ring2:"#9fd6ff", ring3:"#ffffff", dec:0.026, g:0.03, beam:{ col:"#fff3c0", h:100, w:16 }, extra:[ { cols:["#fff3c0","#ffffff"], shape:"orb", n:8, spd:[1,3], up:3, size:[2,3.2], dec:0.03, g:0.02 }, { cols:["#ffffff"], shape:"wing", single:{ dy:30 }, size:[15,15], dec:0.04, grow:0.45 } ] },
    devil:  { cols:["#ff3b1a","#ff7a1a","#ffb347"], shape:"flame", n:12, spd:[1.4,4], up:3.4, size:[2.6,4.2], ring:"#ff3b1a", ring2:"#ffb347", ring3:"#3a0010", dec:0.034, g:-0.02, smoke:"#2a1018", beam:{ col:"#ff3b1a", h:100, w:16 }, extra:[ { cols:["#ff3b2a"], shape:"pent", single:{ dy:2, sq:0.3, lw:2.4 }, size:[24,24], dec:0.04, grow:1.5, vr:0.08 }, { cols:["#ffb347","#ff5a1a"], shape:"spark", n:14, spd:[3,7], up:4, size:[1.5,2.4], dec:0.03, g:0.2 }, { cols:["#ff2a2a"], shape:"orb", n:6, spd:[1,3], up:2.5, size:[2,3.2], dec:0.034, g:0.02 } ] }
};
function cxJumpKey(){ const k = data.jumpEffect; return (k && k !== "none" && k !== "default" && JUMPS[k]) ? k : null; }
function cxEmitJump(arr, key, x, y, land, plus, isExtra){
    const s = (typeof key === "string") ? JUMPS[key] : key; if(!s) return;
    if(s.beam && !isExtra){   // ستون نورِ لحظه‌ی پرش
        const bc = s.beam.col === "rainbow" ? "hsl(" + (((performance.now() / 8) | 0) % 360) + ",95%,70%)" : s.beam.col;
        cxPush(arr, { x, y: y - 1, vx: 0, vy: 0, size: s.beam.w * (land ? 0.7 : 1), h: s.beam.h * (land ? 0.6 : 1), life: 1, dec: 0.07, g: 0, shape: "beam", col: bc });
    }
    if(s.extra && !isExtra) s.extra.forEach(e => cxEmitJump(arr, e, x, y, land, plus, true));
    if(s.single){   // یک ذره‌ی بزرگ و ثابت (جفت بال فرشته، پنتاگرام شیطان)
        cxPush(arr, { x, y: y - (s.single.dy || 0), vx: 0, vy: 0, size: cxRnd(s.size[0], s.size[1]) * (land ? 0.7 : 1), grow: s.grow || 0, life: 1, dec: s.dec, g: 0, shape: s.shape, col: s.cols ? cxPick(s.cols) : "#ffffff", sq: s.single.sq, lw: s.single.lw, rot: cxRnd(0, 6.28), vr: s.vr || 0 });
        return;
    }
    const n = Math.max(3, Math.round(s.n * (land ? 0.55 : 1) * (plus ? 1.2 : 1)));
    const mk = (col, hue) => col;
    if(s.ring){
        const col = s.ring === "rainbow" ? "hsl(" + (((performance.now() / 8) | 0) % 360) + ",95%,65%)" : s.ring;
        cxPush(arr, { x, y: y - 1, vx: 0, vy: 0, size: land ? 6 : 8, grow: land ? 1.6 : 2.3, life: 1, dec: 0.055, g: 0, shape: "ring", col, lw: 3, sq: 0.28 });
        if(s.ring2) cxPush(arr, { x, y: y - 1, vx: 0, vy: 0, size: 3, grow: land ? 1.0 : 1.6, life: 1, dec: 0.045, g: 0, shape: "ring", col: s.ring2, lw: 2, sq: 0.28 });
        if(s.ring3) cxPush(arr, { x, y: y - 1, vx: 0, vy: 0, size: 2, grow: land ? 0.7 : 1.1, life: 1, dec: 0.04, g: 0, shape: "ring", col: s.ring3, lw: 4, sq: 0.28 });
    }
    for(let i = 0; i < n; i++){
        let ang, sp = cxRnd(s.spd[0], s.spd[1]), px = x, py = y - 2, vx, vy, extra = {};
        if(s.implode){ const a = cxRnd(0, CX_TAU), r = cxRnd(28, 46); px = x + Math.cos(a) * r; py = y - 6 + Math.sin(a) * r * 0.45; extra = { pull: 0.05, tx: x, ty: y - 6 }; vx = -Math.cos(a) * 1.2; vy = -Math.sin(a) * 0.6; }
        else if(s.flat){ vx = (Math.random() < 0.5 ? -1 : 1) * cxRnd(0.8, sp); vy = -cxRnd(0, 0.8); }
        else { ang = -Math.PI / 2 + cxRnd(-1.25, 1.25); vx = Math.cos(ang) * sp; vy = Math.sin(ang) * sp * 0.8 - (s.up || 0) * 0.5; }
        let shape = s.shape, col = s.cols ? cxPick(s.cols) : null, hue;
        if(s.smoke && i % 4 === 0){ shape = "smoke"; col = s.smoke; }
        if(s.rainbow) hue = ((performance.now() / 8) + i * 22) % 360;
        cxPush(arr, Object.assign({ x: px, y: py, vx, vy, size: cxRnd(s.size[0], s.size[1]) * (shape === "smoke" ? 1.4 : 1.3), life: 1, dec: s.dec * cxRnd(0.85, 1.2), g: s.g, grow: s.grow || (shape === "smoke" ? 0.14 : 0),
            shape, col, hue, rot: cxRnd(0, 6.28), vr: cxRnd(-0.2, 0.2), drag: s.implode ? 0.9 : 0.985 }, extra));
    }
}

/* ---------- اسکین‌ها ---------- */
function cxCrater(c, x, y, r, a){ c.fillStyle = "rgba(60,70,90," + a + ")"; c.beginPath(); c.arc(x, y, r, 0, CX_TAU); c.fill(); c.fillStyle = "rgba(255,255,255,0.35)"; c.beginPath(); c.arc(x - r * 0.25, y - r * 0.25, r * 0.45, 0, CX_TAU); c.fill(); }
const SK = {
    blue:   { n:"کلاسیک", i:"🔵", cur:"free", d:"سفینه‌ی همیشگی و محبوب", pal:()=>({ body:"#3d7eff", dark:"#12306a", visor:"#d6e9ff", accent:"#7eb3ff" }) },
    cyan:   { n:"نئونی", i:"🟦", cur:"coins", price:2000, legacy:"skinCyan", d:"رنگ فیروزه‌ای درخشان", pal:()=>({ body:"#1ad6ff", dark:"#046a80", visor:"#e8ffff", accent:"#9ffffa" }) },
    emerald:{ n:"زمردین", i:"💚", cur:"coins", price:3500, d:"سبز زمردی با نگین روی سینه", pal:()=>({ body:"#22c97a", dark:"#0a5a36", visor:"#d8ffe9", accent:"#7dffc0" }),
        front(c,t){ c.fillStyle = "rgba(220,255,236,0.9)"; c.beginPath(); c.moveTo(23,26); c.lineTo(28,32); c.lineTo(23,40); c.lineTo(18,32); c.closePath(); c.fill(); c.strokeStyle = "rgba(10,90,54,0.7)"; c.lineWidth = 1; c.beginPath(); c.moveTo(18,32); c.lineTo(28,32); c.moveTo(23,26); c.lineTo(23,40); c.stroke(); } },
    copper: { n:"مسی", i:"🟠", cur:"coins", price:4000, d:"فلز مسی با پرچ‌های براق", pal:()=>({ body:"#d9803f", dark:"#6a3210", visor:"#ffe7cc", accent:"#ffb27a" }),
        front(c,t){ c.fillStyle = "rgba(255,226,190,0.85)"; [[12,12],[34,12],[12,30],[34,30]].forEach(p => { c.beginPath(); c.arc(p[0], p[1], 1.6, 0, CX_TAU); c.fill(); }); c.strokeStyle = "rgba(106,50,16,0.5)"; c.lineWidth = 1; c.beginPath(); c.moveTo(12,36); c.lineTo(34,36); c.stroke(); } },
    purple: { n:"کهکشانی", i:"🟣", cur:"gems", price:60, legacy:"skinPurple", d:"بنفش عمیق کهکشانی", pal:()=>({ body:"#b14bff", dark:"#5b0d9a", visor:"#f0d9ff", accent:"#e2a6ff" }) },
    red:    { n:"یاقوتی", i:"🔴", cur:"gems", price:70, legacy:"skinRed", d:"سرخ یاقوتی پرجلا", pal:()=>({ body:"#ff3b5c", dark:"#8a1028", visor:"#ffd0d8", accent:"#ff8da0" }) },
    moon:   { n:"ماه نقره‌ای", i:"🌕", cur:"gems", price:75, d:"سطح نقره‌ای با دهانه‌های ماه", pal:()=>({ body:"#cfd6e2", dark:"#5b6577", visor:"#f7fbff", accent:"#e9eefc" }),
        front(c,t){ cxCrater(c,17,14,3,0.35); cxCrater(c,29,28,2.4,0.3); cxCrater(c,16,32,1.8,0.28); } },
    comet:  { n:"شهاب", i:"☄️", cur:"gems", price:140, legacy:"skinComet", d:"با دُمِ شهابی آتشین پشت سر", pal:()=>({ body:"#ff7a18", dark:"#6a1400", visor:"#ffe0a0", accent:"#ffd447" }),
        back(c,t){
            const f1 = Math.sin(t / 85) * 3.2, f2 = Math.sin(t / 130 + 1.3) * 3.2, f3 = Math.sin(t / 70 + 2.1) * 2.4;
            c.save(); c.globalCompositeOperation = "lighter"; c.lineJoin = "round";
            // دُم بیرونی: مثلثِ خمیده که دقیقاً از پشتِ بدنه (هم‌قد سفینه) شروع می‌شود و باریک می‌شود
            const tipX = -46 + f1, g1 = c.createLinearGradient(11, 30, tipX, 30);
            g1.addColorStop(0, "rgba(255,215,130,0.9)"); g1.addColorStop(0.35, "rgba(255,130,40,0.7)"); g1.addColorStop(1, "rgba(255,50,0,0)");
            c.fillStyle = g1; c.beginPath(); c.moveTo(11, 9); c.quadraticCurveTo(-10, 17 + f2 * 0.4, tipX, 30 + f3 * 0.5); c.quadraticCurveTo(-10, 43 - f2 * 0.4, 11, 51); c.closePath(); c.fill();
            // دُم میانی
            const g2 = c.createLinearGradient(11, 30, -30 + f2, 30); g2.addColorStop(0, "rgba(255,240,190,0.95)"); g2.addColorStop(1, "rgba(255,150,40,0)");
            c.fillStyle = g2; c.beginPath(); c.moveTo(11, 17); c.quadraticCurveTo(-6, 22 + f3 * 0.3, -30 + f2, 30); c.quadraticCurveTo(-6, 38 - f3 * 0.3, 11, 43); c.closePath(); c.fill();
            // هسته‌ی داغ
            const g3 = c.createLinearGradient(11, 30, -14 + f3, 30); g3.addColorStop(0, "rgba(255,255,235,1)"); g3.addColorStop(1, "rgba(255,230,150,0)");
            c.fillStyle = g3; c.beginPath(); c.moveTo(11, 24); c.quadraticCurveTo(0, 27, -14 + f3, 30); c.quadraticCurveTo(0, 33, 11, 36); c.closePath(); c.fill();
            // جرقه‌های کوچک پشتِ دُم
            for(let i = 0; i < 4; i++){ const ph = ((t / 380) + i * 0.25) % 1, sx = -10 - ph * 44, sy = 30 + Math.sin(i * 2.4 + ph * 5) * (6 + ph * 8); c.fillStyle = "rgba(255," + (190 - ph * 80 | 0) + ",70," + (0.75 * (1 - ph)).toFixed(3) + ")"; c.beginPath(); c.arc(sx, sy, 1.6 * (1 - ph * 0.5), 0, CX_TAU); c.fill(); }
            c.restore(); } },
    aurora: { n:"شفق", i:"🌌", cur:"gems", price:110, legacy:"skinAurora", d:"رنگ‌های متحرکِ شفق قطبی", pal:(t)=>({ body:`hsl(${150 + Math.sin(t/900) * 45},80%,62%)`, dark:"#0a3d32", visor:"#e5fff6", accent:"#c78bff" }) },
    neptune:{ n:"نپتون", i:"🪐", cur:"gems", price:95, legacy:"skinNeptune", d:"آبیِ یخیِ نپتون با ذرات بلورین", pal:()=>({ body:"#8fd6ff", dark:"#0d3a66", visor:"#f2feff", accent:"#c8faff" }),
        front(c,t){ for(let i=0;i<3;i++){ const a = t/500 + i*2.1; c.fillStyle = "rgba(255,255,255,0.85)"; cxStar(c, 23 + Math.cos(a)*19, 30 + Math.sin(a)*22, 2.2, 4, a); c.fill(); } } },
    saturn: { n:"زحل", i:"🪐", cur:"gems", price:90, legacy:"skinSaturn", d:"حلقه‌ی واقعی زحل دور سفینه", pal:()=>({ body:"#c9b38a", dark:"#5c4a30", visor:"#fff3da", accent:"#e8d4a8" }),
        back(c,t){ c.save(); c.translate(23,30); c.rotate(-0.32); c.scale(1,0.38); c.strokeStyle = "rgba(230,210,160,0.55)"; c.lineWidth = 7; c.beginPath(); c.arc(0,0,34,Math.PI,CX_TAU); c.stroke(); c.strokeStyle = "rgba(255,245,215,0.85)"; c.lineWidth = 2.5; c.beginPath(); c.arc(0,0,34,Math.PI,CX_TAU); c.stroke(); c.restore(); },
        front(c,t){ c.save(); c.translate(23,30); c.rotate(-0.32); c.scale(1,0.38); c.strokeStyle = "rgba(230,210,160,0.65)"; c.lineWidth = 7; c.beginPath(); c.arc(0,0,34,0,Math.PI); c.stroke(); c.strokeStyle = "rgba(255,248,222,0.95)"; c.lineWidth = 2.5; c.beginPath(); c.arc(0,0,34,0,Math.PI); c.stroke(); c.restore(); } },
    frost:  { n:"ملکه‌ی یخی", i:"🧊", cur:"gems", price:100, d:"بلورهای یخی روی شانه‌ها", pal:()=>({ body:"#bfe9ff", dark:"#3a6a9a", visor:"#ffffff", accent:"#e8fbff" }),
        front(c,t){ c.fillStyle = "rgba(235,252,255,0.95)"; [[8,16,-1],[38,16,1]].forEach(s => { c.beginPath(); c.moveTo(s[0],20); c.lineTo(s[0]+s[2]*6,4); c.lineTo(s[0]+s[2]*10,22); c.closePath(); c.fill(); });
            c.fillStyle = "rgba(160,225,255,0.9)"; c.beginPath(); c.moveTo(19,8); c.lineTo(23,-3); c.lineTo(27,8); c.closePath(); c.fill();
            const tw = 0.5 + 0.5*Math.sin(t/260); c.fillStyle = "rgba(255,255,255," + (0.5+tw*0.5) + ")"; cxStar(c, 31, 14, 3 + tw*1.5, 4, 0); c.fill(); } },
    magma:  { n:"گدازه‌ای", i:"🌋", cur:"gems", price:145, d:"بدنه‌ی تیره با شکاف‌های گدازه", pal:()=>({ body:"#3b1a12", dark:"#140806", visor:"#ffd9a0", accent:"#ff6a1a" }),
        front(c,t){ const p = 0.6 + 0.4*Math.sin(t/220); c.save(); c.globalCompositeOperation = "lighter"; c.strokeStyle = "rgba(255," + (110+p*70|0) + ",30," + (0.6+p*0.4) + ")"; c.lineWidth = 2; c.lineCap = "round";
            c.beginPath(); c.moveTo(14,10); c.lineTo(18,18); c.lineTo(15,26); c.lineTo(20,34); c.moveTo(32,10); c.lineTo(28,20); c.lineTo(31,28); c.lineTo(26,36); c.stroke();
            c.fillStyle = "rgba(255,140,40," + (0.25+p*0.2) + ")"; c.beginPath(); c.ellipse(23,42,13,5,0,0,CX_TAU); c.fill(); c.restore(); } },
    cyber:  { n:"سایبر نئون", i:"🤖", cur:"gems", price:160, d:"خطوط نئونی و ویزور اسکنری", pal:()=>({ body:"#1b1f3a", dark:"#0a0c1c", visor:"#62f5ff", accent:"#ff3ec9" }),
        front(c,t){ c.save(); c.globalCompositeOperation = "lighter"; c.strokeStyle = "rgba(98,245,255,0.9)"; c.lineWidth = 1.4; c.beginPath(); c.moveTo(12,12); c.lineTo(12,34); c.lineTo(16,40); c.moveTo(34,12); c.lineTo(34,34); c.lineTo(30,40); c.stroke();
            c.strokeStyle = "rgba(255,62,201,0.9)"; c.beginPath(); c.moveTo(16,40); c.lineTo(30,40); c.stroke();
            const sy = 14 + ((t/18) % 12); c.fillStyle = "rgba(255,255,255,0.85)"; c.fillRect(15, sy, 16, 1.4); c.restore(); } },
    rainbow:{ n:"رنگین‌کمان", i:"🌈", cur:"gems", price:200, legacy:"skinRainbow", d:"رنگ‌هایی که مدام عوض می‌شوند", pal:(t)=>{ const h = (t/18)%360; return { body:`hsl(${h},90%,58%)`, dark:`hsl(${h},90%,28%)`, visor:"#ffffff", accent:`hsl(${(h+50)%360},90%,70%)` }; } },
    nova:   { n:"ابرنواختر", i:"💥", cur:"irl", price:35000, legacy:"skinNova", d:"درخششِ ابرنواختر و هدفون مشکی", pal:(t)=>{ const s = t/1000, pulse = 0.5+0.5*Math.sin(s*3.2); return { body:`hsl(42,${30+pulse*25}%,${88+pulse*10}%)`, dark:"#2a0a00", visor:"#fffdf2", accent:`hsl(${(s*35)%360},100%,64%)` }; },
        back(c,t){ const s = t/1000, pulse = 0.5+0.5*Math.sin(s*3.2); c.save(); c.globalCompositeOperation = "lighter"; const cg = c.createRadialGradient(23,30,4,23,30,34+pulse*10); const hh = (s*35)%360;
            cg.addColorStop(0, `hsla(${hh},100%,70%,${0.35+pulse*0.25})`); cg.addColorStop(1, "hsla(0,0%,100%,0)"); c.fillStyle = cg; c.beginPath(); c.arc(23,30,34+pulse*10,0,CX_TAU); c.fill(); c.restore(); },
        front(c,t,pal){ c.strokeStyle = pal.accent; c.lineWidth = 2; c.beginPath(); c.arc(23,22,16,0,CX_TAU); c.stroke();
            c.strokeStyle = "#0b0b10"; c.lineWidth = 3.4; c.lineCap = "round"; c.beginPath(); c.arc(23,18,14,Math.PI*1.06,Math.PI*1.94); c.stroke();
            c.fillStyle = "#0b0b10"; c.beginPath(); cxRR(c,5,13,7,13,3); c.fill(); c.beginPath(); cxRR(c,34,13,7,13,3); c.fill();
            c.fillStyle = "#3a3a46"; c.fillRect(7,16,2.6,7); c.fillRect(36.4,16,2.6,7); } },
    sun:    { n:"خورشید", i:"☀️", cur:"irl", price:55000, d:"تاج‌های آتشین خورشیدی دور سفینه", pal:(t)=>({ body:"#ff9a1f", dark:"#8a2c00", visor:"#fffbe0", accent:"#ff4a1a" }),
        back(c,t){ c.save(); c.translate(23,30); c.globalCompositeOperation = "lighter";
            const g = c.createRadialGradient(0,0,6,0,0,44); g.addColorStop(0,"rgba(255,220,90,0.55)"); g.addColorStop(0.5,"rgba(255,150,40,0.25)"); g.addColorStop(1,"rgba(255,120,20,0)"); c.fillStyle = g; c.beginPath(); c.arc(0,0,44,0,CX_TAU); c.fill();
            c.rotate(t/1400); c.fillStyle = "rgba(255,190,60,0.75)"; for(let i=0;i<10;i++){ c.rotate(CX_TAU/10); c.beginPath(); c.moveTo(-3,-25); c.lineTo(0,-25-(i%2?9:15)-Math.sin(t/200+i)*2); c.lineTo(3,-25); c.closePath(); c.fill(); } c.restore(); },
        front(c,t){ const p = 0.5+0.5*Math.sin(t/260); c.save(); c.globalCompositeOperation = "lighter"; const g = c.createRadialGradient(23,34,1,23,34,10+p*3); g.addColorStop(0,"rgba(255,255,220,0.95)"); g.addColorStop(1,"rgba(255,170,40,0)"); c.fillStyle = g; c.beginPath(); c.arc(23,34,10+p*3,0,CX_TAU); c.fill(); c.restore(); } },
    blackhole:{ n:"سیاهچاله", i:"🕳️", cur:"irl", price:55000, d:"دیسک برافزایش چرخان دور سفینه", pal:()=>({ body:"#0a0612", dark:"#000000", visor:"#b58cff", accent:"#7a3dff" }),
        back(c,t){ c.save(); c.translate(23,30); c.rotate(-0.25); c.scale(1,0.34); c.globalCompositeOperation = "lighter";
            const g = c.createRadialGradient(0,0,18,0,0,40); g.addColorStop(0,"rgba(255,170,60,0.0)"); g.addColorStop(0.35,"rgba(255,160,70,0.75)"); g.addColorStop(0.7,"rgba(170,90,255,0.55)"); g.addColorStop(1,"rgba(120,60,255,0)"); c.fillStyle = g; c.beginPath(); c.arc(0,0,40,Math.PI,CX_TAU); c.fill();
            c.strokeStyle = "rgba(255,230,200,0.55)"; c.lineWidth = 2; for(let i=0;i<3;i++){ const a = t/500 + i*2.1; c.beginPath(); c.arc(0,0,30,a,a+0.9); c.stroke(); } c.restore(); },
        front(c,t){ c.save(); c.translate(23,30); c.rotate(-0.25); c.scale(1,0.34); c.globalCompositeOperation = "lighter";
            const g = c.createRadialGradient(0,0,18,0,0,40); g.addColorStop(0,"rgba(255,170,60,0.0)"); g.addColorStop(0.35,"rgba(255,160,70,0.85)"); g.addColorStop(0.7,"rgba(170,90,255,0.6)"); g.addColorStop(1,"rgba(120,60,255,0)"); c.fillStyle = g; c.beginPath(); c.arc(0,0,40,0,Math.PI); c.fill(); c.restore();
            c.strokeStyle = "rgba(200,150,255,0.55)"; c.lineWidth = 1.5; c.beginPath(); c.arc(23,22,11,0,CX_TAU); c.stroke(); } },
    storm:  { n:"طوفان", i:"⛈️", cur:"irl", price:45000, d:"ابر طوفانی، صاعقه‌های زنده و جرقه‌های برقی دور بدنه", pal:(t)=>({ body:"#2b3a6b", dark:"#0f1838", visor: (Math.floor(t/130) % 6 === 0) ? "#ffffff" : "#d8ecff", accent:"#ffe45e" }),
        back(c,t){ c.save(); const fl = (Math.floor(t/110) % 7 === 0) ? 0.5 : 0.0;
            for(let i = 0; i < 5; i++){ const cx = 23 + Math.sin(t/900 + i * 1.7) * 11 + (i - 2) * 7, cy = 5 + (i % 2) * 4 + Math.cos(t/700 + i) * 1.5, rr = 11 - (i % 3) * 1.5;
                const g = c.createRadialGradient(cx, cy, 1, cx, cy, rr); g.addColorStop(0, "rgba(" + (110 + fl * 120 | 0) + "," + (125 + fl * 110 | 0) + "," + (185 + fl * 60 | 0) + ",0.85)"); g.addColorStop(1, "rgba(40,50,95,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, rr, 0, CX_TAU); c.fill(); }
            c.globalCompositeOperation = "lighter"; const rg = c.createRadialGradient(23, 30, 6, 23, 30, 38); rg.addColorStop(0, "rgba(120,170,255,0)"); rg.addColorStop(0.65, "rgba(120,170,255," + (0.14 + fl * 0.2) + ")"); rg.addColorStop(1, "rgba(120,170,255,0)"); c.fillStyle = rg; c.beginPath(); c.arc(23, 30, 38, 0, CX_TAU); c.fill(); c.restore(); },
        front(c,t){ const ph = Math.floor(t/110), on = (ph % 3) === 0, seed = ph * 17;
            c.save(); c.globalCompositeOperation = "lighter"; c.lineJoin = "round"; c.lineCap = "round";
            // صاعقه‌های اصلی از ابر تا شانه‌ها
            const bolts = [[17, 3, 8, 30], [29, 3, 38, 28], [23, 2, 23, 22]];
            bolts.forEach((b, i) => { if(!on && i > 0 && (ph + i) % 3) return; const pts = [[b[0], b[1]]]; const n = 4; for(let k = 1; k < n; k++){ const f = k / n; pts.push([b[0] + (b[2] - b[0]) * f + (cxHash(seed + i * 9 + k) - 0.5) * 9, b[1] + (b[3] - b[1]) * f]); } pts.push([b[2], b[3]]);
                [[5, 0.16], [2.6, 0.45], [1.1, 1]].forEach(L => { c.strokeStyle = (L[1] === 1 ? "rgba(255,255,255," : "rgba(130,190,255,") + (L[1] * (on ? 1 : 0.55)).toFixed(3) + ")"; c.lineWidth = L[0]; c.beginPath(); pts.forEach((p, q) => q ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.stroke(); }); });
            // قوس برقی بین دو بازو
            c.strokeStyle = "rgba(255,240,140," + (0.55 + 0.4 * Math.sin(t / 60)).toFixed(3) + ")"; c.lineWidth = 1.4; c.beginPath(); c.moveTo(9, 36); for(let k = 1; k < 7; k++){ c.lineTo(9 + k * 4.7, 36 + (k % 2 ? -1 : 1) * (2 + cxHash(seed + k) * 4)); } c.lineTo(37, 36); c.stroke();
            // جرقه‌های ریز دور بدنه
            for(let k = 0; k < 6; k++){ const a = cxHash(seed + 40 + k) * CX_TAU, rr = 18 + cxHash(seed + 60 + k) * 7; c.fillStyle = "rgba(200,230,255," + (0.8 * cxHash(seed + 70 + k)).toFixed(3) + ")"; c.beginPath(); c.arc(23 + Math.cos(a) * rr, 30 + Math.sin(a) * rr * 1.05, 0.9 + cxHash(seed + k) * 0.9, 0, CX_TAU); c.fill(); }
            // نور حاشیه
            c.strokeStyle = "rgba(160,205,255,0.55)"; c.lineWidth = 1.2; c.beginPath(); cxRR(c, 10, 8, 26, 28, 10); c.stroke();
            if(on){ c.fillStyle = "rgba(220,240,255,0.22)"; c.beginPath(); cxRR(c, 10, 8, 26, 28, 10); c.fill(); }
            c.restore(); } },
    cosmicking:{ n:"پادشاه کیهانی", i:"👑", cur:"vip", legacy:"skinCosmicKing", d:"تاج طلایی و شنل بنفش سلطنتی", pal:()=>({ body:"#ffd447", dark:"#4a2c00", visor:"#fff4c2", accent:"#c06cff" }),
        back(c,t){ const sw = Math.sin(t/260)*3, sw2 = Math.sin(t/260 + 1)*4;
            c.save(); const g = c.createLinearGradient(14,12,-16,58); g.addColorStop(0,"#9a4dff"); g.addColorStop(1,"#3d0f80"); c.fillStyle = g;
            c.beginPath(); c.moveTo(14,13); c.quadraticCurveTo(0+sw,12,-12+sw,30+sw2*0.3); c.quadraticCurveTo(-18+sw2,46,-10+sw2,59); c.quadraticCurveTo(4,52,14,44); c.closePath(); c.fill();
            c.strokeStyle = "#ffd447"; c.lineWidth = 1.8; c.lineJoin = "round"; c.beginPath(); c.moveTo(14,13); c.quadraticCurveTo(0+sw,12,-12+sw,30+sw2*0.3); c.quadraticCurveTo(-18+sw2,46,-10+sw2,59); c.quadraticCurveTo(4,52,14,44); c.stroke();
            c.strokeStyle = "rgba(255,255,255,0.22)"; c.lineWidth = 1.2; c.beginPath(); c.moveTo(12,20); c.quadraticCurveTo(-2+sw,28,-8+sw2,50); c.moveTo(12,30); c.quadraticCurveTo(2,38,-2+sw2*0.5,53); c.stroke(); c.restore(); },
        front(c,t,pal){ c.fillStyle = "#ffd447"; c.beginPath(); c.moveTo(14,10); c.lineTo(18,0); c.lineTo(23,8); c.lineTo(28,0); c.lineTo(32,10); c.closePath(); c.fill();
            c.fillStyle = "#ff6ec7"; c.beginPath(); c.arc(23,7,1.6,0,CX_TAU); c.fill(); c.fillStyle = pal.accent; c.fillRect(8,38,30,5); } },
    phantom:{ n:"روح فضایی", i:"⚡", cur:"irl", price:80000, legacy:"skinPhantom", pw:"ghost", d:"نیمه‌شفاف و شبح‌وار با هاله‌ی فیروزه‌ای", pal:()=>({ body:"rgba(150,240,255,0.62)", dark:"rgba(40,90,150,0.62)", visor:"rgba(240,255,255,0.97)", accent:"#7cf6ff" }),
        back(c,t){ const p = 0.5 + 0.5 * Math.sin(t / 300); c.save(); c.globalCompositeOperation = "lighter"; const g = c.createRadialGradient(23,32,4,23,32,40); g.addColorStop(0,"rgba(120,240,255," + (0.28 + p * 0.12) + ")"); g.addColorStop(1,"rgba(60,160,255,0)"); c.fillStyle = g; c.beginPath(); c.arc(23,32,40,0,CX_TAU); c.fill();
            c.strokeStyle = "rgba(150,250,255," + (0.35 + p * 0.25) + ")"; c.lineWidth = 1.5; for(let i = 0; i < 3; i++){ const y0 = 52 + i * 3; c.beginPath(); c.moveTo(12 + i * 3, y0); c.quadraticCurveTo(23, y0 + 7 + Math.sin(t / 200 + i) * 3, 34 - i * 3, y0); c.stroke(); } c.restore(); },
        front(c,t){ c.save(); c.strokeStyle = "rgba(190,255,255,0.95)"; c.lineWidth = 1.6; c.lineJoin = "round"; c.beginPath(); cxRR(c, 10, 8, 26, 28, 10); c.stroke(); c.strokeStyle = "rgba(130,230,255,0.8)"; c.lineWidth = 1.3; c.beginPath(); cxRR(c, 8, 22, 30, 28, 8); c.stroke();
            c.fillStyle = "rgba(255,255,255,0.8)"; c.beginPath(); c.ellipse(19, 18, 3, 2.2, -0.4, 0, CX_TAU); c.fill(); c.restore(); } }
};
/* ---------- فرشته و شیطان (نسخه‌ی ۸.۰) ---------- */
SK.angel = { n:"فرشته", i:"😇", cur:"irl", price:70000, d:"بال‌های سفید و پُرپر، حلقه‌ی آبیِ مهربانی بالای سر و عصای زیبای فرشتگان",
    pal:()=>({ body:"#f4f8ff", dark:"#b8c9ea", visor:"#8fd6ff", accent:"#ffe27a" }),
    back(c,t){
        const fl = Math.sin(t / 240) * 0.16;
        c.save(); c.globalCompositeOperation = "lighter";
        const gg = c.createRadialGradient(23, 30, 6, 23, 30, 48); gg.addColorStop(0, "rgba(255,246,210,0.38)"); gg.addColorStop(1, "rgba(255,246,210,0)");
        c.fillStyle = gg; c.beginPath(); c.arc(23, 30, 48, 0, CX_TAU); c.fill(); c.restore();
        const wing = sd => {
            c.save(); c.translate(sd < 0 ? 12 : 34, 27); c.scale(sd, 1);
            for(let layer = 0; layer < 2; layer++){
                for(let i = 0; i < 7; i++){
                    const a = -1.4 + i * 0.33 + fl * (0.6 + i * 0.1), L = (layer ? 20 : 37) - i * (layer ? 1.1 : 2.5);
                    c.save(); c.rotate(a);
                    const g = c.createLinearGradient(0, 0, L, 0); g.addColorStop(0, "#ffffff"); g.addColorStop(1, layer ? "#f2f8ff" : "#b6d4f5");
                    c.fillStyle = g; c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(L * 0.5, -4.4 + layer * 0.9, L, 0); c.quadraticCurveTo(L * 0.5, 4.4 - layer * 0.9, 0, 0); c.fill();
                    c.strokeStyle = "rgba(140,180,225,0.55)"; c.lineWidth = 0.6; c.stroke(); c.restore();
                }
            }
            c.restore();
        };
        wing(-1); wing(1);
    },
    front(c,t){
        const bob = Math.sin(t / 420) * 1.2, pl = 0.7 + 0.3 * Math.sin(t / 300);
        c.save(); c.globalCompositeOperation = "lighter";   // حلقه‌ی آبیِ مهربانی
        c.strokeStyle = "rgba(90,200,255," + (0.35 * pl).toFixed(3) + ")"; c.lineWidth = 6; c.beginPath(); c.ellipse(23, 2 + bob, 11.5, 3.8, 0, 0, CX_TAU); c.stroke();
        c.strokeStyle = "rgba(150,225,255,0.95)"; c.lineWidth = 2.4; c.beginPath(); c.ellipse(23, 2 + bob, 11.5, 3.8, 0, 0, CX_TAU); c.stroke();
        c.strokeStyle = "rgba(255,255,255,0.9)"; c.lineWidth = 1; c.beginPath(); c.ellipse(23, 2 + bob, 11.5, 3.8, 0, Math.PI * 1.1, Math.PI * 1.9); c.stroke(); c.restore();
        c.fillStyle = "#ffe27a"; c.fillRect(8, 38, 30, 3);   // کمربند طلایی
        // چشم‌های مهربان
        [[18.6, 20.4], [27.4, 20.4]].forEach(e => { c.fillStyle = "#1c3a7a"; c.beginPath(); c.ellipse(e[0], e[1], 2.2, 3.1, 0, 0, CX_TAU); c.fill(); c.fillStyle = "#ffffff"; c.beginPath(); c.arc(e[0] - 0.7, e[1] - 1.1, 0.9, 0, CX_TAU); c.fill(); c.beginPath(); c.arc(e[0] + 0.6, e[1] + 0.9, 0.45, 0, CX_TAU); c.fill(); });
        c.strokeStyle = "#1c3a7a"; c.lineWidth = 1; c.beginPath(); c.arc(23, 23.4, 3, 0.25, Math.PI - 0.25); c.stroke();   // لبخند
        c.fillStyle = "rgba(255,150,170,0.55)"; c.beginPath(); c.ellipse(15.4, 24.2, 2, 1.2, 0, 0, CX_TAU); c.ellipse(30.6, 24.2, 2, 1.2, 0, 0, CX_TAU); c.fill();
        // عصای فرشته
        const sx = 43.5;
        const rg = c.createLinearGradient(sx - 1.5, 0, sx + 1.5, 0); rg.addColorStop(0, "#c8932a"); rg.addColorStop(0.5, "#fff0a0"); rg.addColorStop(1, "#b07a1a");
        c.fillStyle = rg; c.fillRect(sx - 1.2, 12, 2.4, 46);
        c.strokeStyle = "#ffe27a"; c.lineWidth = 1.3; c.beginPath(); c.ellipse(sx, 26, 3, 1.6, 0, 0, CX_TAU); c.stroke(); c.beginPath(); c.ellipse(sx, 42, 3, 1.6, 0, 0, CX_TAU); c.stroke();
        c.save(); c.translate(sx, 9);
        for(let sd = -1; sd <= 1; sd += 2){ c.save(); c.scale(sd, 1); c.fillStyle = "#fff"; c.strokeStyle = "rgba(255,226,122,0.9)"; c.lineWidth = 0.8; c.beginPath(); c.moveTo(1.5, 1); c.quadraticCurveTo(6, -6, 11, -5); c.quadraticCurveTo(8, -1, 10, 1); c.quadraticCurveTo(6, 0, 7, 3); c.quadraticCurveTo(3, 2, 1.5, 4); c.closePath(); c.fill(); c.stroke(); c.restore(); }
        c.globalCompositeOperation = "lighter"; const og = c.createRadialGradient(0, 0, 0.5, 0, 0, 8 + pl * 2); og.addColorStop(0, "rgba(255,255,255,1)"); og.addColorStop(0.4, "rgba(130,215,255,0.8)"); og.addColorStop(1, "rgba(100,190,255,0)");
        c.fillStyle = og; c.beginPath(); c.arc(0, 0, 8 + pl * 2, 0, CX_TAU); c.fill(); c.restore();
        c.fillStyle = "#fff"; c.beginPath(); c.arc(sx, 9, 2.4, 0, CX_TAU); c.fill();
        for(let i = 0; i < 3; i++){ const ph = ((t / 900) + i / 3) % 1; c.fillStyle = "rgba(255,246,190," + (0.9 * (1 - ph)).toFixed(2) + ")"; cxStar(c, sx + Math.sin(i * 2.1 + t / 500) * 6, 9 - ph * 12, 1.8 * (1 - ph * 0.4), 4, t / 300 + i); c.fill(); }
    } };
SK.devil = { n:"شیطان", i:"😈", cur:"irl", price:70000, d:"دُم و شاخ شیطانی، بال‌های سیاهِ خفاشی و عصای سه‌سرِ تیز شیطان",
    pal:()=>({ body:"#8a0f22", dark:"#2d0612", visor:"#240510", accent:"#ff3b2a" }),
    back(c,t){
        const fl = Math.sin(t / 230) * 0.15, sw = Math.sin(t / 300) * 3;
        c.save(); c.globalCompositeOperation = "lighter";
        const gg = c.createRadialGradient(23, 30, 6, 23, 30, 48); gg.addColorStop(0, "rgba(255,40,30,0.32)"); gg.addColorStop(1, "rgba(255,40,30,0)");
        c.fillStyle = gg; c.beginPath(); c.arc(23, 30, 48, 0, CX_TAU); c.fill(); c.restore();
        const wing = sd => {
            c.save(); c.translate(sd < 0 ? 12 : 34, 26); c.scale(sd * 0.8, 0.8); c.rotate(-fl);
            const wr = [24, -24], tips = [[41, -24], [46, -5], [38, 12]];
            const g = c.createLinearGradient(0, 0, 44, -10); g.addColorStop(0, "#4a0a1e"); g.addColorStop(1, "#14040c");
            c.fillStyle = g; c.beginPath(); c.moveTo(0, 2); c.lineTo(wr[0], wr[1]);
            tips.forEach((tp, i) => { const pv = i ? tips[i - 1] : wr, mx = (pv[0] + tp[0]) / 2 - 3, my = (pv[1] + tp[1]) / 2 + 4; c.quadraticCurveTo(mx, my, tp[0], tp[1]); });
            c.quadraticCurveTo(24, 14, 6, 14); c.closePath(); c.fill();
            c.strokeStyle = "#8a1830"; c.lineWidth = 1.2; c.lineJoin = "round"; c.beginPath(); c.moveTo(0, 2); c.lineTo(wr[0], wr[1]); tips.forEach(tp => { c.moveTo(wr[0], wr[1]); c.lineTo(tp[0], tp[1]); }); c.stroke();
            c.strokeStyle = "rgba(255,70,50,0.35)"; c.lineWidth = 0.8; c.beginPath(); c.moveTo(wr[0], wr[1]); c.lineTo(10, 12); c.stroke();
            c.restore();
        };
        wing(-1); wing(1);
    },
    front(c,t){
        const pl = 0.7 + 0.3 * Math.sin(t / 220);
        for(let sd = -1; sd <= 1; sd += 2){   // شاخ‌ها
            c.save(); c.translate(sd < 0 ? 14 : 32, 11); c.scale(sd < 0 ? -1 : 1, 1);
            const g = c.createLinearGradient(0, 0, 8, -16); g.addColorStop(0, "#1a0308"); g.addColorStop(0.7, "#7a1020"); g.addColorStop(1, "#ff5a3a");
            c.fillStyle = g; c.beginPath(); c.moveTo(-3, 1); c.quadraticCurveTo(-1, -9, 7, -16); c.quadraticCurveTo(5, -7, 3.4, 1); c.closePath(); c.fill();
            c.strokeStyle = "rgba(255,160,130,0.55)"; c.lineWidth = 0.8; c.beginPath(); c.moveTo(-1.4, -1); c.quadraticCurveTo(0.4, -8, 6, -14); c.stroke(); c.restore();
        }
        c.save(); c.globalCompositeOperation = "lighter";   // چشم‌های خشمگین
        [[-1, 0], [1, 0]].forEach(e => {
            const sd = e[0]; c.save(); c.translate(23, 20); c.scale(sd, 1);
            c.fillStyle = "#ffb347"; c.beginPath(); c.moveTo(-7.4, -3.4); c.lineTo(-1.2, 0.6); c.lineTo(-3, 3.2); c.lineTo(-7.6, 0.4); c.closePath(); c.fill();
            c.fillStyle = "rgba(255,120,30," + (0.45 * pl).toFixed(3) + ")"; c.beginPath(); c.arc(-4.4, 0.2, 5, 0, CX_TAU); c.fill(); c.restore();
        });
        c.restore();
        c.fillStyle = "#fff"; [[20.6, 26.2], [25.4, 26.2]].forEach(f => { c.beginPath(); c.moveTo(f[0] - 1.1, f[1]); c.lineTo(f[0] + 1.1, f[1]); c.lineTo(f[0], f[1] + 3); c.closePath(); c.fill(); });
        c.fillStyle = "#ff3b2a"; c.fillRect(8, 38, 30, 3);
        // دُم: از پشتِ بدنه بیرون می‌آید و جلوی بال‌ها دیده می‌شود (دقیقاً به بدن وصل است)
        const sw = Math.sin(t / 300) * 3;
        c.save(); c.lineCap = "round";
        c.strokeStyle = "#2d0612"; c.lineWidth = 4.4; c.beginPath(); c.moveTo(11, 46); c.bezierCurveTo(-1, 50 + sw * 0.3, -9, 42 + sw, -13, 33 + sw); c.stroke();
        c.strokeStyle = "#c01a2e"; c.lineWidth = 2.8; c.beginPath(); c.moveTo(11, 46); c.bezierCurveTo(-1, 50 + sw * 0.3, -9, 42 + sw, -13, 33 + sw); c.stroke();
        c.fillStyle = "#c01a2e"; c.strokeStyle = "#2d0612"; c.lineWidth = 0.8; c.save(); c.translate(-13, 33 + sw); c.rotate(-1.0 + sw * 0.05); c.beginPath(); c.moveTo(0, -5.2); c.lineTo(5.4, 3); c.lineTo(0, 1.2); c.lineTo(-5.4, 3); c.closePath(); c.fill(); c.stroke(); c.restore();
        c.fillStyle = "#c01a2e"; c.beginPath(); c.arc(11, 46, 3, 0, CX_TAU); c.fill(); c.restore();   // ریشه‌ی دُم روی بدن
        // عصای سه‌سر (سه‌شاخه‌ی تیز)
        const sx = 43.5, sg = c.createLinearGradient(sx - 1.5, 0, sx + 1.5, 0); sg.addColorStop(0, "#2a1a20"); sg.addColorStop(0.5, "#8a6a70"); sg.addColorStop(1, "#1a0e12");
        c.fillStyle = sg; c.fillRect(sx - 1.2, 12, 2.4, 46);
        c.fillStyle = "#ff3b2a"; c.fillRect(sx - 1.6, 30, 3.2, 1.6); c.fillRect(sx - 1.6, 44, 3.2, 1.6);
        c.fillStyle = "#b8b8c4"; c.strokeStyle = "#5a5a68"; c.lineWidth = 0.7;
        c.beginPath(); c.moveTo(sx - 1.6, 14); c.lineTo(sx, -6); c.lineTo(sx + 1.6, 14); c.closePath(); c.fill(); c.stroke();                                                  // شاخ وسط
        c.beginPath(); c.moveTo(sx - 1.6, 15); c.quadraticCurveTo(sx - 8, 14, sx - 7.4, 3); c.lineTo(sx - 9, -4); c.lineTo(sx - 5.6, 2); c.quadraticCurveTo(sx - 4, 9, sx, 12); c.closePath(); c.fill(); c.stroke();     // چپ
        c.beginPath(); c.moveTo(sx + 1.6, 15); c.quadraticCurveTo(sx + 8, 14, sx + 7.4, 3); c.lineTo(sx + 9, -4); c.lineTo(sx + 5.6, 2); c.quadraticCurveTo(sx + 4, 9, sx, 12); c.closePath(); c.fill(); c.stroke();      // راست
        c.save(); c.globalCompositeOperation = "lighter";
        [[sx, -6], [sx - 9, -4], [sx + 9, -4]].forEach((tp, i) => { const fl = 0.6 + 0.4 * Math.sin(t / 130 + i * 2); const g = c.createRadialGradient(tp[0], tp[1], 0, tp[0], tp[1], 5.5); g.addColorStop(0, "rgba(255,200,120," + (0.95 * fl).toFixed(2) + ")"); g.addColorStop(1, "rgba(255,60,20,0)"); c.fillStyle = g; c.beginPath(); c.arc(tp[0], tp[1], 5.5, 0, CX_TAU); c.fill(); });
        c.restore();
    } };

const SK_ORDER = ["blue","cyan","emerald","copper","purple","red","moon","comet","aurora","neptune","saturn","frost","magma","cyber","rainbow","nova","sun","blackhole","storm","cosmicking","phantom","angel","devil"];
function skinPal(key, t){ const d = SK[key] || SK.blue; return d.pal(t); }
function getSkinPalette(sk){ return skinPal(sk || data.skin, performance.now()); }
function isSaturnSkin(){ return data.skin === "saturn"; }
// رسم کامل سفینه در مختصات محلیِ جعبه‌ی ۴۶×۶۰ (برای بازی و پیش‌نمایش یکسان)
/* لایه‌ی کیفیتِ اسکین (نسخه ۸.۰): سکه‌ای ← برقِ عبوری | الماسی ← + حاشیه‌ی درخشان و چشمک | پولی ← + برقِ سریع‌تر، حاشیه‌ی قوی‌تر و ستاره‌های چرخان (هرچه قیمت بالاتر، قوی‌تر) */
const SKIN_NO_TIER = { blue: 1, angel: 1, devil: 1, phantom: 1, cosmicking: 1 };
function skinTierFx(c, key, t, d, pal){
    if(SKIN_NO_TIER[key]) return;
    const tier = d.cur === "coins" ? 1 : d.cur === "gems" ? 2 : d.cur === "irl" ? 3 : 0; if(!tier) return;
    const s = t / 1000, price = d.price || 0, str = tier === 3 ? Math.min(1, price / 60000) : 0;
    c.save(); c.beginPath(); cxRR(c, 10, 8, 26, 28, 10); c.clip();
    const period = tier === 1 ? 3.6 : tier === 2 ? 2.8 : 2.0, ph = (s % period) / period;
    if(ph < 0.42){ const x = 2 + ph / 0.42 * 46, g = c.createLinearGradient(x - 9, 8, x + 9, 36); g.addColorStop(0, "rgba(255,255,255,0)"); g.addColorStop(0.5, "rgba(255,255,255," + (0.2 + tier * 0.07).toFixed(2) + ")"); g.addColorStop(1, "rgba(255,255,255,0)"); c.fillStyle = g; c.fillRect(0, 0, 46, 60); }
    c.restore();
    if(tier >= 2){
        c.save(); c.globalCompositeOperation = "lighter"; const pl = 0.6 + 0.4 * Math.sin(s * 3);
        c.globalAlpha = (tier === 2 ? 0.28 : 0.4 + str * 0.25) * pl; c.strokeStyle = pal.accent; c.lineWidth = tier === 2 ? 2.2 : 3; c.beginPath(); cxRR(c, 8, 6, 30, 32, 11); c.stroke();
        c.globalAlpha = 1; const n = tier === 2 ? 2 : 4;
        for(let i = 0; i < n; i++){ const a = s * (tier === 2 ? 1.1 : 1.6) + i * CX_TAU / n, tw = 0.5 + 0.5 * Math.sin(s * 5 + i * 2); c.fillStyle = "rgba(255,255,255," + (0.55 + 0.4 * tw).toFixed(2) + ")"; cxStar(c, 23 + Math.cos(a) * 26, 26 + Math.sin(a) * 28, 2.2 + tw * 1.6 + str, 4, s * 2 + i); c.fill(); }
        c.restore();
    }
}
function paintShip(c, key, t){
    const d = SK[key] || SK.blue, pal = d.pal(t);
    if(d.back) d.back(c, t, pal);
    c.fillStyle = pal.dark; c.beginPath(); cxRR(c, 8, 22, 30, 28, 8); c.fill();
    c.fillStyle = pal.body; c.beginPath(); cxRR(c, 10, 8, 26, 28, 10); c.fill();
    c.fillStyle = pal.visor; c.beginPath(); c.ellipse(23, 20, 10, 8, 0, 0, CX_TAU); c.fill();
    c.fillStyle = pal.accent; c.fillRect(6, 30, 6, 12); c.fillRect(34, 30, 6, 12);
    if(d.front) d.front(c, t, pal);
    skinTierFx(c, key, t, d, pal);
}

/* ================================================================
   هاله‌ها، افکت ورود، زمین‌های ویژه و فیلترها (مشترک بین بازی و پیش‌نمایش)
   ================================================================ */
/* ---------- هاله‌ها ----------
   pass: 0 = پشت سفینه (قبل از رسم)، 1 = جلوی سفینه (بعد از رسم) */
function cxOrbitPts(c, px, py, t, pass, n, rx, ry, spd, draw, ph0){
    for(let i = 0; i < n; i++){
        const a = t * spd + i * CX_TAU / n + (ph0 || 0), depth = Math.sin(a);
        if((depth > 0 ? 1 : 0) !== pass) continue;
        draw(px + Math.cos(a) * rx, py + depth * ry - 2, depth, i, a);
    }
}
function cxOrbitRing(c, px, py, rx, ry, pass, col, lw){
    c.save(); c.strokeStyle = col; c.lineWidth = lw || 1.2;
    c.beginPath(); if(pass) c.ellipse(px, py - 2, rx, ry, 0, 0, Math.PI); else c.ellipse(px, py - 2, rx, ry, 0, Math.PI, CX_TAU); c.stroke(); c.restore();
}
function cxGlowDot(c, x, y, r, col, plus){
    c.save(); c.globalCompositeOperation = "lighter";
    c.globalAlpha = 0.28; c.fillStyle = col; c.beginPath(); c.arc(x, y, r * 2.4, 0, CX_TAU); c.fill();
    c.globalAlpha = 1; c.beginPath(); c.arc(x, y, r, 0, CX_TAU); c.fill(); c.restore();
}
/* ---------- هاله‌های نسخه‌ی ۸.۰ ----------
   pass = 0: پشت سفینه | pass = 1: جلوی سفینه. قانون کیفیت: گران‌تر = زیباتر. */
const AURA_V8 = {
    flame(c, px, py, s, pass, plus){   // ۱۰۰ الماس: بهترین هاله‌ی الماسی
        if(pass === 0){
            dcGlow(c, px, py + 4, 40, "255,120,30", 0.22);
            for(let i = 0; i < 14; i++){
                const a = i * CX_TAU / 14 + s * 0.8, big = i % 2, fx = px + Math.cos(a) * (30 + big * 3), fy = py + 6 + Math.sin(a) * (21 + big * 2), fl = (big ? 13 : 9) + Math.sin(s * 9 + i * 2) * 4;
                const g = c.createLinearGradient(fx, fy, fx, fy - fl * 2); g.addColorStop(0, "rgba(255,90,20,0.9)"); g.addColorStop(0.6, "rgba(255,170,40,0.6)"); g.addColorStop(1, "rgba(255,230,120,0)");
                c.fillStyle = g; c.beginPath(); c.moveTo(fx - 4, fy); c.quadraticCurveTo(fx - 3, fy - fl, fx, fy - fl * 2); c.quadraticCurveTo(fx + 3, fy - fl, fx + 4, fy); c.closePath(); c.fill();
            }
        } else {
            cxOrbitPts(c, px, py, s, pass, 5, 34, 12, 1.7, (x, y, d, i) => cxGlowDot(c, x, y, 1.6 + d * 0.6, i % 2 ? "#ffd24a" : "#ff8a2a", plus));
        }
    },
    storm(c, px, py, s, pass, plus){   // ۲۵ هزار: ابر تیره، چند رعد و برقِ شاخه‌دار و درخششِ لحظه‌ای
        const ph = Math.floor(s * 7);
        if(pass === 0){
            dcGlow(c, px, py, 44, "70,90,170", 0.22);
            for(let i = 0; i < 10; i++){ const a = s * 0.9 + i * 0.628, cx = px + Math.cos(a) * 29, cy = py + Math.sin(a) * 18, g = c.createRadialGradient(cx, cy, 1, cx, cy, 17);
                g.addColorStop(0, "rgba(120,135,205,0.62)"); g.addColorStop(1, "rgba(60,72,140,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, 16, 0, CX_TAU); c.fill(); }
        } else {
            c.globalCompositeOperation = "lighter"; c.lineJoin = "round"; c.lineCap = "round";
            for(let k = 0; k < 3; k++){
                if((ph + k) % 2 !== 0) continue;
                const ang = ph * 1.7 + k * 2.1, x0 = px + Math.cos(ang) * 42, y0 = py + Math.sin(ang) * 24, pts = [[x0, y0]];
                for(let q = 1; q < 6; q++){ const f = q / 6; pts.push([x0 + (px + Math.cos(ang) * 12 - x0) * f + (cxHash(ph + q + k * 7) - 0.5) * 10, y0 + (py + Math.sin(ang) * 7 - y0) * f + (cxHash(ph + q * 3 + k) - 0.5) * 8]); }
                [[5, 0.18], [2.4, 0.5], [1.1, 1]].forEach(L => { c.strokeStyle = (L[1] === 1 ? "rgba(255,255,255," : "rgba(140,190,255,") + L[1] + ")"; c.lineWidth = L[0]; c.beginPath(); pts.forEach((q, i) => i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])); c.stroke(); });
                const m = pts[3]; c.strokeStyle = "rgba(190,225,255,0.7)"; c.lineWidth = 1; c.beginPath(); c.moveTo(m[0], m[1]); c.lineTo(m[0] + (cxHash(ph + k) - 0.5) * 22, m[1] - 8 + cxHash(ph + k + 5) * 16); c.stroke();   // شاخه‌ی فرعی
                if(k === 0) dcGlow(c, px, py, 46, "190,215,255", 0.2);
            }
        }
    },
    orbit(c, px, py, s, pass, plus){   // ۳۰ هزار: دو مدار متقاطع، گوی‌های نورانی با دُمِ محو، هسته‌ی درخشان
        if(pass === 0){ dcGlow(c, px, py, 40, "110,220,255", 0.16); }
        const rings = [[36, 13, 0, "rgba(150,230,255,0.3)", 1.7, 4, 0], [34, 12, 1.0, "rgba(190,200,255,0.26)", -1.3, 3, 1.5]];
        rings.forEach((R, ri) => {
            c.save(); c.translate(px, py - 2); c.rotate(R[2]);
            c.strokeStyle = R[3]; c.lineWidth = 1.2; c.beginPath(); if(pass) c.ellipse(0, 0, R[0], R[1], 0, 0, Math.PI); else c.ellipse(0, 0, R[0], R[1], 0, Math.PI, CX_TAU); c.stroke();
            for(let i = 0; i < R[5]; i++){
                const a = s * R[4] + i * CX_TAU / R[5] + R[6], depth = Math.sin(a); if((depth > 0 ? 1 : 0) !== pass) continue;
                for(let t = 1; t <= 6; t++){ const a2 = a - t * 0.11 * Math.sign(R[4]), d2 = Math.sin(a2); if((d2 > 0 ? 1 : 0) !== pass) continue; c.globalAlpha = 0.3 * (1 - t / 7); cxGlowDot(c, Math.cos(a2) * R[0], d2 * R[1], 1.9 * (1 - t / 8), ri ? "#c6c2ff" : "#7cf6ff", plus); }
                c.globalAlpha = 1; cxGlowDot(c, Math.cos(a) * R[0], depth * R[1], 3 + depth * 0.9, i === 0 ? "#ffffff" : (ri ? "#b6b2ff" : "#7cf6ff"), plus);
            }
            c.restore();
        });
    },
    plasma(c, px, py, s, pass, plus){   // ۳۵ هزار: چهار گوی پلاسما با دُمِ بلند، جرقه‌های برقی بین گوی‌ها، هسته‌ی تپنده
        const cols = ["#ff4dd8", "#5affff", "#a56bff", "#ffe45e"];
        if(pass === 0){ const pl = 0.7 + 0.3 * Math.sin(s * 4); dcGlow(c, px, py, 42, "180,90,255", 0.2 * pl); dcGlow(c, px, py, 24, "90,255,255", 0.12 * pl); }
        const pos = [];
        for(let i = 0; i < 4; i++){ const a = s * 2.6 + i * CX_TAU / 4, depth = Math.sin(a); pos.push({ a, depth, x: px + Math.cos(a) * 33, y: py + depth * 15 - 2, i }); }
        pos.forEach(P => {
            if((P.depth > 0 ? 1 : 0) !== pass) return;
            c.save(); c.lineCap = "round"; c.strokeStyle = cols[P.i];
            [[0.9, 0.5, 2.2], [0.55, 0.28, 4.4]].forEach(L => { c.globalAlpha = L[1]; c.lineWidth = L[2]; c.beginPath(); c.ellipse(px, py - 2, 33, 15, 0, P.a - L[0] - 0.2, P.a); c.stroke(); });
            c.restore();
            cxGlowDot(c, P.x, P.y, 3.8 + P.depth, cols[P.i], plus);
            if(plus){ c.save(); c.globalCompositeOperation = "lighter"; c.fillStyle = "#ffffff"; c.beginPath(); c.arc(P.x, P.y, 1.5, 0, CX_TAU); c.fill(); c.restore(); }
        });
        if(pass === 1){   // قوس‌های برقی بین گوی‌های روبه‌رو
            const k = Math.floor(s * 9) % 4, A = pos[k], B = pos[(k + 2) % 4];
            if(A.depth > -0.2 && B.depth > -0.2){ c.save(); c.globalCompositeOperation = "lighter"; c.strokeStyle = "rgba(255,255,255,0.65)"; c.lineWidth = 1; c.beginPath(); c.moveTo(A.x, A.y); for(let q = 1; q < 5; q++){ const f = q / 5; c.lineTo(A.x + (B.x - A.x) * f + (cxHash(k + q + Math.floor(s * 9)) - 0.5) * 8, A.y + (B.y - A.y) * f + (cxHash(q * 3 + k) - 0.5) * 6); } c.lineTo(B.x, B.y); c.stroke(); c.restore(); }
        }
    },
    rainbow(c, px, py, s, pass, plus){   // ۳۵ هزار: هاله‌ی رنگین‌کمان، سه مدار با ۱۲ گوی مدام‌رنگ‌عوض‌کن و ستاره‌های درخشان
        if(pass === 0){
            c.save(); c.globalCompositeOperation = "lighter"; c.lineWidth = 5;
            for(let i = 0; i < 8; i++){ const a0 = i * CX_TAU / 8 + s * 0.5; c.strokeStyle = "hsla(" + (((s * 60) + i * 45) % 360 | 0) + ",95%,60%,0.24)"; c.beginPath(); c.ellipse(px, py - 2, 35, 25, 0, a0, a0 + 0.8); c.stroke(); }
            c.restore();
        }
        const rings = [[37, 14, 0, 1.5], [31, 11, 0.8, -1.9], [40, 10, -0.7, 1.1]];
        rings.forEach((R, ri) => {
            c.save(); c.translate(px, py - 2); c.rotate(R[2]);
            c.strokeStyle = "rgba(255,255,255,0.14)"; c.lineWidth = 1; c.beginPath(); if(pass) c.ellipse(0, 0, R[0], R[1], 0, 0, Math.PI); else c.ellipse(0, 0, R[0], R[1], 0, Math.PI, CX_TAU); c.stroke();
            for(let i = 0; i < 3; i++){ const a = s * R[3] + i * CX_TAU / 3, depth = Math.sin(a); if((depth > 0 ? 1 : 0) !== pass) continue; cxGlowDot(c, Math.cos(a) * R[0], depth * R[1], 2.7 + depth * 0.7, "hsl(" + (((s * 80) + (ri * 3 + i) * 40) % 360 | 0) + ",95%,62%)", plus); }
            c.restore();
        });
        if(pass === 1){ const tw = 0.5 + 0.5 * Math.sin(s * 6); c.save(); c.globalCompositeOperation = "lighter"; c.fillStyle = "rgba(255,255,255," + (0.5 + tw * 0.5).toFixed(2) + ")"; cxStar(c, px + Math.cos(s * 1.2) * 38, py - 6 + Math.sin(s * 1.2) * 12, 3 + tw * 2.5, 4, s * 2); c.fill(); c.restore(); }
    },
    royal(c, px, py, s, pass, plus){   // VIP: گران‌ترین هاله
        if(pass === 0){ dcGlow(c, px, py, 44, "255,200,70", 0.26); const g = c.createRadialGradient(px, py, 8, px, py, 38); g.addColorStop(0, "rgba(255,215,90,0)"); g.addColorStop(0.7, "rgba(255,200,70,0.24)"); g.addColorStop(1, "rgba(255,190,60,0)"); c.fillStyle = g; c.beginPath(); c.arc(px, py, 38, 0, CX_TAU); c.fill(); }
        cxOrbitRing(c, px, py, 38, 14, pass, "rgba(255,215,90,0.42)", 1.7);
        cxOrbitRing(c, px, py, 30, 10, pass, "rgba(255,243,176,0.28)", 1.2);
        cxOrbitPts(c, px, py, s, pass, 6, 38, 14, 1.3, (x, y, d, i) => { c.fillStyle = i % 2 ? "#ffd447" : "#fff3b0"; cxStar(c, x, y, 4.2 + d * 1.2, 4, s * 2 + i); c.fill(); });
        cxOrbitPts(c, px, py, s, pass, 4, 30, 10, -1.8, (x, y, d, i) => cxGlowDot(c, x, y, 1.8 + d * 0.5, "#ffe9a0", plus));
    },
    angel(c, px, py, s, pass, plus){   // ۳۵ هزار: حلقه‌ی نورانیِ بالای سر، پرهای مدار، پرتوهای آسمانی و مه‌ی سفید
        const bob = Math.sin(s * 2) * 1.6;
        if(pass === 0){
            dcGlow(c, px, py, 46, "255,246,210", 0.24); dcGlow(c, px, py - 30, 30, "255,232,150", 0.22);
            c.save(); c.globalCompositeOperation = "lighter";
            for(let i = -2; i <= 2; i++){ const g = c.createLinearGradient(px + i * 10, py - 70, px + i * 16, py + 30); g.addColorStop(0, "rgba(255,244,190," + (0.20 - Math.abs(i) * 0.04).toFixed(3) + ")"); g.addColorStop(1, "rgba(255,244,190,0)"); c.fillStyle = g; c.beginPath(); c.moveTo(px + i * 3, py - 70); c.lineTo(px + i * 3 + 5, py - 70); c.lineTo(px + i * 20 + 8, py + 30); c.lineTo(px + i * 20 - 8, py + 30); c.closePath(); c.fill(); }
            c.restore();
            cxOrbitRing(c, px, py, 34, 12, 0, "rgba(255,246,210,0.35)", 1.4);
        } else {
            cxOrbitRing(c, px, py, 34, 12, 1, "rgba(255,246,210,0.35)", 1.4);
            c.save(); c.globalCompositeOperation = "lighter";   // حلقه‌ی نورانی بالای سر
            c.strokeStyle = "rgba(255,226,120,0.35)"; c.lineWidth = 6; c.beginPath(); c.ellipse(px, py - 34 + bob, 12, 4, 0, 0, CX_TAU); c.stroke();
            c.strokeStyle = "rgba(255,246,190,0.95)"; c.lineWidth = 2.4; c.beginPath(); c.ellipse(px, py - 34 + bob, 12, 4, 0, 0, CX_TAU); c.stroke();
            c.restore();
        }
        cxOrbitPts(c, px, py, s, pass, 5, 34, 12, 1.2, (x, y, d, i) => { if(i % 2){ cxGlowDot(c, x, y, 1.8 + d * 0.5, "#fff3c0", plus); } else { c.save(); c.translate(x, y); c.rotate(s * 1.3 + i); c.fillStyle = "rgba(255,255,255," + (0.75 + d * 0.2).toFixed(2) + ")"; c.beginPath(); c.moveTo(0, -4.4); c.quadraticCurveTo(2.4, -1, 0, 4.4); c.quadraticCurveTo(-2.4, -1, 0, -4.4); c.fill(); c.restore(); } });
    },
    devil(c, px, py, s, pass, plus){   // ۳۵ هزار: شعله‌های سیاه‌وقرمز، دود تیره، جرقه‌های گدازه‌ای و درخشش خون‌رنگ
        if(pass === 0){
            dcGlow(c, px, py + 4, 46, "255,40,30", 0.26); dcGlow(c, px, py + 4, 28, "120,0,30", 0.28);
            for(let i = 0; i < 12; i++){
                const a = i * CX_TAU / 12 + s * 0.7, fx = px + Math.cos(a) * 30, fy = py + 8 + Math.sin(a) * 21, fl = 12 + Math.sin(s * 8 + i * 2.3) * 5 + (i % 3) * 3;
                const g = c.createLinearGradient(fx, fy, fx, fy - fl * 2.1); g.addColorStop(0, "rgba(255,40,20,0.95)"); g.addColorStop(0.45, "rgba(180,10,30,0.7)"); g.addColorStop(1, "rgba(40,0,20,0)");
                c.fillStyle = g; c.beginPath(); c.moveTo(fx - 4.5, fy); c.quadraticCurveTo(fx - 3.5, fy - fl, fx + Math.sin(s * 6 + i) * 2, fy - fl * 2.1); c.quadraticCurveTo(fx + 3.5, fy - fl, fx + 4.5, fy); c.closePath(); c.fill();
            }
            c.save(); c.globalCompositeOperation = "lighter";
            for(let i = 0; i < 12; i++){ const a = i * CX_TAU / 12 + s * 0.7, fx = px + Math.cos(a) * 30, fy = py + 8 + Math.sin(a) * 21; dcGlow(c, fx, fy - 3, 5, "255,170,60", 0.45); }
            c.restore();
        } else {
            cxOrbitPts(c, px, py, s, pass, 6, 35, 12, 1.9, (x, y, d, i) => { cxGlowDot(c, x, y, 1.7 + d * 0.6, i % 2 ? "#ff5a2a" : "#ffb347", plus); });
            for(let i = 0; i < 5; i++){ const ph = (s * 0.55 + i * 0.2) % 1, sx = px + Math.sin(i * 2.7 + s) * 26, sy = py + 10 - ph * 58; c.save(); c.globalCompositeOperation = "lighter"; c.fillStyle = "rgba(255,120,40," + (0.8 * (1 - ph)).toFixed(3) + ")"; c.beginPath(); c.arc(sx, sy, 1.5 * (1 - ph * 0.5), 0, CX_TAU); c.fill(); c.restore(); }
        }
    }
};

function cxAura(c, key, px, py, t, pass, plus){
    if(!key || key === "none") return;
    const s = t / 1000;
    c.save();
    if(AURA_V8[key]){ AURA_V8[key](c, px, py, s, pass, plus); c.restore(); return; }   // نسخه‌ی جدید (۸.۰) برای هاله‌های گران‌تر
    if(key === "pulse"){
        if(pass === 0){ const r = 34 + Math.sin(s * 3) * 5, g = c.createRadialGradient(px, py, 6, px, py, r);
            g.addColorStop(0, "rgba(120,200,255,0.0)"); g.addColorStop(0.6, "rgba(110,190,255,0.28)"); g.addColorStop(1, "rgba(90,160,255,0)");
            c.fillStyle = g; c.beginPath(); c.arc(px, py, r, 0, CX_TAU); c.fill();
            c.strokeStyle = "rgba(160,220,255," + (0.35 + Math.sin(s * 3) * 0.15) + ")"; c.lineWidth = 2; c.beginPath(); c.arc(px, py, r * 0.78, 0, CX_TAU); c.stroke(); }
    } else if(key === "orbit"){
        cxOrbitRing(c, px, py, 36, 13, pass, "rgba(150,230,255,0.28)", 1.2);
        cxOrbitPts(c, px, py, s, pass, 3, 36, 13, 1.9, (x, y, d, i) => { const r = 3.2 + d * 0.9; cxGlowDot(c, x, y, r, i === 0 ? "#7cf6ff" : i === 1 ? "#ffffff" : "#9fb4ff", plus); });
    } else if(key === "rainbow"){
        cxOrbitRing(c, px, py, 37, 14, pass, "rgba(255,255,255,0.18)", 1);
        cxOrbitPts(c, px, py, s, pass, 8, 37, 14, 1.5, (x, y, d, i) => { cxGlowDot(c, x, y, 2.4 + d * 0.7, "hsl(" + (((s * 80) + i * 45) % 360 | 0) + ",95%,62%)", plus); });
    } else if(key === "royal"){
        if(pass === 0){ const r = 36, g = c.createRadialGradient(px, py, 8, px, py, r); g.addColorStop(0, "rgba(255,215,90,0)"); g.addColorStop(0.7, "rgba(255,200,70,0.22)"); g.addColorStop(1, "rgba(255,190,60,0)"); c.fillStyle = g; c.beginPath(); c.arc(px, py, r, 0, CX_TAU); c.fill(); }
        cxOrbitRing(c, px, py, 38, 14, pass, "rgba(255,215,90,0.4)", 1.6);
        cxOrbitPts(c, px, py, s, pass, 5, 38, 14, 1.3, (x, y, d, i) => { c.fillStyle = i % 2 ? "#ffd447" : "#fff3b0"; cxStar(c, x, y, 4 + d * 1.2, 4, s * 2 + i); c.fill(); });
    } else if(key === "flame"){
        if(pass === 0){ for(let i = 0; i < 10; i++){ const a = i * CX_TAU / 10 + s * 0.8, fx = px + Math.cos(a) * 30, fy = py + 6 + Math.sin(a) * 21, fl = 11 + Math.sin(s * 9 + i * 2) * 4;
                const g = c.createLinearGradient(fx, fy, fx, fy - fl * 2); g.addColorStop(0, "rgba(255,90,20,0.85)"); g.addColorStop(0.6, "rgba(255,170,40,0.55)"); g.addColorStop(1, "rgba(255,230,120,0)");
                c.fillStyle = g; c.beginPath(); c.moveTo(fx - 4, fy); c.quadraticCurveTo(fx - 3, fy - fl, fx, fy - fl * 2); c.quadraticCurveTo(fx + 3, fy - fl, fx + 4, fy); c.closePath(); c.fill(); } }
    } else if(key === "ice"){
        cxOrbitRing(c, px, py, 36, 13, pass, "rgba(190,240,255,0.3)", 1.2);
        cxOrbitPts(c, px, py, s, pass, 6, 36, 13, 1.1, (x, y, d, i) => { c.fillStyle = "rgba(220,248,255," + (0.65 + d * 0.3) + ")"; c.save(); c.translate(x, y); c.rotate(s * 1.5 + i);
            c.beginPath(); c.moveTo(0, -5); c.lineTo(2.4, 0); c.lineTo(0, 5); c.lineTo(-2.4, 0); c.closePath(); c.fill(); c.restore(); });
        if(pass === 0){ c.strokeStyle = "rgba(170,230,255,0.18)"; c.lineWidth = 6; c.beginPath(); c.arc(px, py, 30, 0, CX_TAU); c.stroke(); }
    } else if(key === "stars"){
        const rs = [26, 34, 30, 38, 32], sp = [1.6, 1.1, 2.0, 0.9, 1.4];
        for(let i = 0; i < 5; i++){
            const a = s * sp[i] + i * 1.3, depth = Math.sin(a); if((depth > 0 ? 1 : 0) !== pass) continue;
            const x = px + Math.cos(a) * rs[i], y = py + depth * (rs[i] * 0.4) - 2, tw = 0.6 + 0.4 * Math.sin(s * 5 + i);
            c.fillStyle = i % 2 ? "rgba(255,240,170," + (0.55 + tw * 0.45) + ")" : "rgba(190,215,255," + (0.55 + tw * 0.45) + ")"; cxStar(c, x, y, 5.2 + tw * 2.8, 4, a); c.fill();
        }
    } else if(key === "storm"){
        if(pass === 0){ for(let i = 0; i < 5; i++){ const a = s * 1.1 + i * 1.26, cx = px + Math.cos(a) * 27, cy = py + Math.sin(a) * 16, g = c.createRadialGradient(cx, cy, 1, cx, cy, 15); g.addColorStop(0, "rgba(150,170,230,0.55)"); g.addColorStop(1, "rgba(90,105,170,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, 15, 0, CX_TAU); c.fill(); } }
        else { const ph = Math.floor(s * 8); c.globalCompositeOperation = "lighter"; c.lineJoin = "round"; c.lineCap = "round";
            for(let k = 0; k < 2; k++){ if((ph + k) % 3 !== 0) continue; const ang = ph * 1.7 + k * 3.1, x0 = px + Math.cos(ang) * 40, y0 = py + Math.sin(ang) * 22, pts = [[x0, y0]]; for(let q = 1; q < 5; q++){ const f = q / 5; pts.push([x0 + (px + Math.cos(ang) * 14 - x0) * f + (cxHash(ph + q + k * 7) - 0.5) * 9, y0 + (py + Math.sin(ang) * 8 - y0) * f + (cxHash(ph + q * 3 + k) - 0.5) * 7]); } pts.push([px + Math.cos(ang) * 14, py + Math.sin(ang) * 8]);
                [[4.5, 0.18], [2.2, 0.5], [1, 1]].forEach(L => { c.strokeStyle = (L[1] === 1 ? "rgba(255,255,255," : "rgba(140,190,255,") + L[1] + ")"; c.lineWidth = L[0]; c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.stroke(); }); } }
    } else if(key === "plasma"){
        cxOrbitPts(c, px, py, s, pass, 4, 33, 15, 2.6, (x, y, d, i) => { const col = ["#ff4dd8", "#5affff", "#a56bff", "#ffe45e"][i]; cxGlowDot(c, x, y, 3.6 + d, col, plus);
            c.strokeStyle = col; c.globalAlpha = 0.35; c.lineWidth = 2; c.beginPath(); c.arc(px, py - 2, 33, Math.atan2(y - py + 2, x - px) - 0.5, Math.atan2(y - py + 2, x - px)); c.stroke(); c.globalAlpha = 1; });
    }
    c.restore();
}
function cxAuraAt(c, key, px, py, t, pass, plus){ cxAura(c, key, px, py, t, pass, plus); }

/* ---------- افکت ورود به بازی (روی صفحه، مدت‌دار) ---------- */
const STARTFX_DUR = { warp:1.2, flash:0.9, portal:2.1, royal:1.8, burst:1.4, shock:1.3, bolt:1.5, meteor:2.0, void:2.3, wave:1.7 };
/* ---------- افکت‌های ورود به بازی (نسخه‌ی ۸.۰) ----------
   قانون کیفیت: هرچه گران‌تر، باشکوه‌تر. «لرزش موجیِ» ۱۲۰ الماسی از همه‌ی افکت‌های الماسی بهتر است. */
function cxWarpCanvas(c, k, w, h, strength){
    const cv = c.canvas, cw = cv.width, ch = cv.height; if(!cw || !ch || k >= 1) return;
    const buf = cv.__wbuf || (cv.__wbuf = document.createElement("canvas"));
    if(buf.width !== cw || buf.height !== ch){ buf.width = cw; buf.height = ch; }
    const b = buf.getContext("2d"); b.setTransform(1, 0, 0, 1, 0, 0); b.clearRect(0, 0, cw, ch); b.drawImage(cv, 0, 0);
    const sc = cw / w, amp = (strength || 20) * sc * Math.pow(1 - k, 1.35), sh = Math.max(2, Math.round(3 * sc)), tt = k * 15;
    c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.globalCompositeOperation = "source-over"; c.globalAlpha = 1; c.clearRect(0, 0, cw, ch);
    for(let y = 0; y < ch; y += sh){
        const hh = Math.min(sh, ch - y), dx = Math.sin(y / ch * 21 + tt) * amp + Math.sin(y / ch * 8.5 - tt * 0.6) * amp * 0.5;
        c.drawImage(buf, 0, y, cw, hh, dx - amp * 1.6, y, cw + amp * 3.2, hh);
    }
    c.restore();
}
function cxJag(x0, y0, x1, y1, seed, n, amp){   // مسیرِ دندانه‌دار برای رعد
    const pts = [[x0, y0]];
    for(let i = 1; i < n; i++){ const f = i / n; pts.push([x0 + (x1 - x0) * f + (cxHash(seed * 31 + i) - 0.5) * amp, y0 + (y1 - y0) * f + (cxHash(seed * 17 + i * 3) - 0.5) * amp * 0.45]); }
    pts.push([x1, y1]); return pts;
}
const STARTFX_V8 = {
    wave(c, cx, cy, T, w, h, plus, k, R){   // ۱۲۰ الماس: کل صفحه موج‌دار می‌لرزد + موج‌های آب‌مانند از سفینه پخش می‌شوند
        c.globalCompositeOperation = "lighter";
        for(let j = 0; j < 5; j++){
            const tt = (T - j * 0.17) / 1.2; if(tt <= 0 || tt >= 1) continue;
            const r = 8 + cxEase(tt) * R * 1.25;
            c.strokeStyle = "rgba(150,225,255," + (0.8 * (1 - tt)).toFixed(3) + ")"; c.lineWidth = 5 * (1 - tt) + 1.2; c.beginPath(); c.ellipse(cx, cy, r, r * 0.62, 0, 0, CX_TAU); c.stroke();
            c.strokeStyle = "rgba(255,255,255," + (0.5 * (1 - tt)).toFixed(3) + ")"; c.lineWidth = 1.2; c.beginPath(); c.ellipse(cx, cy, r * 0.93, r * 0.58, 0, 0, CX_TAU); c.stroke();
        }
        for(let i = 0; i < 5; i++){   // نوارهای نورِ آبی که مثل آب روی صفحه می‌لغزند
            const x = ((i * 0.23 + T * 0.55) % 1.2 - 0.1) * w, g = c.createLinearGradient(x - 40, 0, x + 40, 0);
            g.addColorStop(0, "rgba(120,200,255,0)"); g.addColorStop(0.5, "rgba(150,225,255," + (0.18 * (1 - k)).toFixed(3) + ")"); g.addColorStop(1, "rgba(120,200,255,0)");
            c.fillStyle = g; c.fillRect(x - 40, 0, 80, h);
        }
        if(T < 0.4){ const g = c.createRadialGradient(cx, cy, 0, cx, cy, 90); g.addColorStop(0, "rgba(255,255,255," + (0.7 * (1 - T / 0.4)).toFixed(3) + ")"); g.addColorStop(1, "rgba(120,200,255,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, 90, 0, CX_TAU); c.fill(); }
        c.globalCompositeOperation = "source-over";
        cxWarpCanvas(c, k, w, h, 22);
    },
    portal(c, cx, cy, T, w, h, plus, k, R){   // ۲۵ هزار: گردابِ سه‌رنگ، حلقه‌های رون، ستاره‌های پراکنده
        c.globalCompositeOperation = "lighter";
        const cols = [[155, 92, 255], [77, 201, 255], [255, 77, 106]];
        const fade = Math.min(1, T / 0.3) * Math.max(0, 1 - Math.max(0, T - 1.4) / 0.7);
        for(let arm = 0; arm < 3; arm++){
            c.strokeStyle = "rgba(" + cols[arm] + "," + (0.6 * fade).toFixed(3) + ")"; c.lineWidth = 3; c.beginPath();
            for(let q = 0; q <= 44; q++){ const f = q / 44, ang = arm * CX_TAU / 3 + f * 5.5 - T * 4.2, rad = 6 + f * R * 0.58 * (0.4 + 0.6 * Math.min(1, T / 0.6)); const x = cx + Math.cos(ang) * rad, y = cy + Math.sin(ang) * rad * 0.82; if(q) c.lineTo(x, y); else c.moveTo(x, y); }
            c.stroke();
        }
        for(let j = 0; j < 3; j++){
            const tt = (T - j * 0.3) / 0.95; if(tt <= 0 || tt >= 1) continue;
            const r = 12 + cxEase(tt) * R, a = 1 - tt, col = cols[j];
            const g = c.createRadialGradient(cx, cy, r * 0.7, cx, cy, r * 1.08); g.addColorStop(0, "rgba(" + col + ",0)"); g.addColorStop(0.7, "rgba(" + col + "," + (0.35 * a).toFixed(3) + ")"); g.addColorStop(1, "rgba(" + col + ",0)");
            c.fillStyle = g; c.beginPath(); c.arc(cx, cy, r * 1.08, 0, CX_TAU); c.fill();
            c.strokeStyle = "rgba(" + col + "," + (0.95 * a).toFixed(3) + ")"; c.lineWidth = 6 * (1 - tt) + 2; c.beginPath(); c.arc(cx, cy, r, 0, CX_TAU); c.stroke();
            c.save(); c.setLineDash([7, 9]); c.lineDashOffset = -T * 60 * (j % 2 ? -1 : 1); c.strokeStyle = "rgba(255,255,255," + (0.6 * a).toFixed(3) + ")"; c.lineWidth = 1.6; c.beginPath(); c.arc(cx, cy, r * 0.88, 0, CX_TAU); c.stroke(); c.restore();
            for(let q = 0; q < 8; q++){ const ang = q * CX_TAU / 8 + tt * 3 + j; c.fillStyle = "rgba(255,255,255," + (0.85 * a).toFixed(3) + ")"; c.beginPath(); c.arc(cx + Math.cos(ang) * r, cy + Math.sin(ang) * r, 2.4, 0, CX_TAU); c.fill(); }
        }
        for(let i = 0; i < 16; i++){ const ph = ((T * 0.7 + i / 16) % 1), ang = cxHash(i + 3) * CX_TAU + T * 0.5, rr = 14 + ph * R * (0.6 + cxHash(i + 8) * 0.6); c.fillStyle = "rgba(" + cols[i % 3] + "," + (0.85 * (1 - ph) * fade).toFixed(3) + ")"; cxStar(c, cx + Math.cos(ang) * rr, cy + Math.sin(ang) * rr * 0.85, 2.5 + (1 - ph) * 3.5, 4, T * 3 + i); c.fill(); }
        if(T < 0.5){ const g = c.createRadialGradient(cx, cy, 0, cx, cy, 80); g.addColorStop(0, "rgba(255,255,255," + (0.85 * (1 - T / 0.5)).toFixed(3) + ")"); g.addColorStop(1, "rgba(155,92,255,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, 80, 0, CX_TAU); c.fill(); }
    },
    bolt(c, cx, cy, T, w, h, plus, k, R){   // ۳۰ هزار: سه صاعقه‌ی شاخه‌دار، فلاش صفحه، حلقه‌ی ضربه‌ی زمین و جرقه‌های برقی
        c.globalCompositeOperation = "lighter"; c.lineJoin = "round"; c.lineCap = "round";
        [0.06, 0.36, 0.66].forEach((st, si) => {
            const tt = T - st; if(tt < 0 || tt > 0.34) return; const fl = 1 - tt / 0.34, seed = si * 13 + Math.floor(tt * 26);
            const tx = cx + (si - 1) * 34, ty = cy + 2, sx = tx + (cxHash(seed) - 0.5) * 120, main = cxJag(sx, -10, tx, ty, seed, 11, 56);
            const draw = pts => [[11, 0.18], [5.5, 0.5], [2.2, 1]].forEach(L => { c.strokeStyle = (L[1] === 1 ? "rgba(255,255,255," : "rgba(170,215,255,") + (L[1] * fl).toFixed(3) + ")"; c.lineWidth = L[0] * (pts === main ? 1 : 0.55); c.beginPath(); pts.forEach((q, i) => i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])); c.stroke(); });
            draw(main);
            for(let b = 0; b < 3; b++){ const m = main[2 + b * 2]; draw(cxJag(m[0], m[1], m[0] + (cxHash(seed + b) - 0.5) * 120, m[1] + 50 + cxHash(seed + b + 7) * 70, seed + b, 5, 28)); }
            c.fillStyle = "rgba(205,228,255," + ((si === 0 ? 0.3 : 0.14) * fl).toFixed(3) + ")"; c.fillRect(0, 0, w, h);
            const g = c.createRadialGradient(tx, ty, 0, tx, ty, 90); g.addColorStop(0, "rgba(255,255,255," + (0.85 * fl).toFixed(3) + ")"); g.addColorStop(1, "rgba(120,190,255,0)"); c.fillStyle = g; c.beginPath(); c.arc(tx, ty, 90, 0, CX_TAU); c.fill();
            const rr = 10 + cxEase(tt / 0.34) * R * 0.55; c.strokeStyle = "rgba(160,220,255," + (0.8 * fl).toFixed(3) + ")"; c.lineWidth = 3; c.beginPath(); c.ellipse(tx, ty + 26, rr, rr * 0.3, 0, 0, CX_TAU); c.stroke();
        });
        if(T > 0.5){ const fa = Math.max(0, 1 - (T - 0.5) / 1.0); for(let q = 0; q < 6; q++){ const ang = q * CX_TAU / 6 + T * 5, p0 = cxJag(cx + Math.cos(ang) * 14, cy + Math.sin(ang) * 18, cx + Math.cos(ang + 0.6) * 38, cy + Math.sin(ang + 0.6) * 44, q + Math.floor(T * 14), 4, 12); c.strokeStyle = "rgba(190,230,255," + (0.75 * fa).toFixed(3) + ")"; c.lineWidth = 1.4; c.beginPath(); p0.forEach((m, i) => i ? c.lineTo(m[0], m[1]) : c.moveTo(m[0], m[1])); c.stroke(); } }
        for(let i = 0; i < 10; i++){ const t0 = 0.1 + (i % 3) * 0.3, tt = T - t0; if(tt < 0 || tt > 0.7) continue; const ang = cxHash(i + 2) * CX_TAU, rr = tt * (60 + cxHash(i + 6) * 90); c.fillStyle = "rgba(200,235,255," + (0.9 * (1 - tt / 0.7)).toFixed(3) + ")"; c.beginPath(); c.arc(cx + Math.cos(ang) * rr, cy + 10 + Math.sin(ang) * rr * 0.6 - tt * 30, 1.6, 0, CX_TAU); c.fill(); }
    },
    meteor(c, cx, cy, T, w, h, plus, k, R){   // ۳۵ هزار: بارانِ ۱۱ شهاب‌سنگِ آتشین با دُم و دود، برخورد و انفجار، موج گرما و جرقه‌های ماندگار
        c.globalCompositeOperation = "lighter"; c.lineCap = "round";
        const N = 11;
        for(let i = 0; i < N; i++){
            const st = i * 0.085, tt = (T - st) / 0.7; if(tt <= 0) continue;
            const sx = cx + 230 + i * 40 - (i % 3) * 55, sy = -40 - i * 18, ex = cx - 70 + (i - 5) * 26, ey = cy + 10 + (i % 3) * 5;
            if(tt < 1){
                const hx = sx + (ex - sx) * tt, hy = sy + (ey - sy) * tt, tx = hx - (ex - sx) * 0.3, ty = hy - (ey - sy) * 0.3;
                const g = c.createLinearGradient(tx, ty, hx, hy); g.addColorStop(0, "rgba(255,70,10,0)"); g.addColorStop(0.6, "rgba(255,140,40,0.7)"); g.addColorStop(1, "rgba(255,235,170," + (0.98).toFixed(2) + ")");
                c.strokeStyle = g; c.lineWidth = 8 - tt * 2.4; c.beginPath(); c.moveTo(tx, ty); c.lineTo(hx, hy); c.stroke();
                c.strokeStyle = "rgba(90,40,20,0.35)"; c.lineWidth = 12; c.beginPath(); c.moveTo(hx - (ex - sx) * 0.46, hy - (ey - sy) * 0.46); c.lineTo(tx, ty); c.stroke();
                dcGlow(c, hx, hy, 22, "255,150,50", 0.6); c.fillStyle = "rgba(255,245,215,0.98)"; c.beginPath(); c.arc(hx, hy, 5.2, 0, CX_TAU); c.fill();
                for(let q = 0; q < 3; q++){ c.fillStyle = "rgba(255,190,80," + (0.8 * (1 - q / 3)).toFixed(2) + ")"; c.beginPath(); c.arc(hx - (ex - sx) * (0.07 + q * 0.06) + (cxHash(i * 5 + q) - 0.5) * 10, hy - (ey - sy) * (0.07 + q * 0.06) + (cxHash(i * 7 + q) - 0.5) * 10, 1.8, 0, CX_TAU); c.fill(); }
            } else {
                const ti = Math.min(1, (tt - 1) / 0.55); if(ti >= 1) continue;
                const g = c.createRadialGradient(ex, ey, 0, ex, ey, 26 + ti * 90); g.addColorStop(0, "rgba(255,230,150," + (0.9 * (1 - ti)).toFixed(3) + ")"); g.addColorStop(0.5, "rgba(255,110,30," + (0.5 * (1 - ti)).toFixed(3) + ")"); g.addColorStop(1, "rgba(255,60,10,0)");
                c.fillStyle = g; c.beginPath(); c.arc(ex, ey, 26 + ti * 90, 0, CX_TAU); c.fill();
                c.strokeStyle = "rgba(255,200,120," + (0.8 * (1 - ti)).toFixed(3) + ")"; c.lineWidth = 3 * (1 - ti) + 1; c.beginPath(); c.ellipse(ex, ey + 14, 12 + ti * 100, (12 + ti * 100) * 0.28, 0, 0, CX_TAU); c.stroke();
                if(i % 2 === 0) for(let q = 0; q < 5; q++){ const a = -Math.PI / 2 + (q - 2) * 0.5 + cxHash(i * 9 + q) * 0.3, d = ti * (40 + cxHash(q + i) * 50); c.fillStyle = "rgba(255,200,90," + (1 - ti).toFixed(2) + ")"; c.beginPath(); c.arc(ex + Math.cos(a) * d, ey + Math.sin(a) * d + ti * ti * 30, 1.8, 0, CX_TAU); c.fill(); }
            }
        }
        const hit = Math.max(0, 1 - Math.abs(T - 0.95) / 0.3); if(hit > 0){ c.fillStyle = "rgba(255,150,70," + (0.22 * hit).toFixed(3) + ")"; c.fillRect(0, 0, w, h); }
        if(T > 0.7){ const fa = Math.max(0, 1 - (T - 0.7) / 1.3); for(let q = 0; q < 16; q++){ const ph = (T * 0.8 + q / 16) % 1, x = cx - 80 + cxHash(q) * 170 + Math.sin(T * 3 + q) * 6, y = cy + 14 - ph * 70; c.fillStyle = "rgba(255," + (140 + q * 6) + ",60," + (0.85 * (1 - ph) * fa).toFixed(3) + ")"; c.beginPath(); c.arc(x, y, 1.7, 0, CX_TAU); c.fill(); } }
    },
    void(c, cx, cy, T, w, h, plus, k, R){   // ۳۵ هزار: شکل‌گیریِ سیاهچاله، دیسک برافزایش، مکیدن ذرات، فروپاشی و انفجارِ موجی با اعوجاج صفحه
        const P1 = 1.0, P2 = 1.2;
        c.globalCompositeOperation = "source-over";
        if(T < P2 + 0.3){
            const f = Math.min(1, T / P1), vg = c.createRadialGradient(cx, cy, R * 0.2, cx, cy, Math.max(w, h) * 0.75), va = 0.55 * Math.min(1, f * 1.4) * (1 - Math.max(0, T - P1) / 0.5);
            vg.addColorStop(0, "rgba(10,0,25,0)"); vg.addColorStop(1, "rgba(10,0,25," + Math.max(0, va).toFixed(3) + ")"); c.fillStyle = vg; c.fillRect(0, 0, w, h);
        }
        if(T < P2){
            const r0 = 6 + cxEase(Math.min(1, T / 0.7)) * 26 * (1 - Math.max(0, T - P1) / 0.2);
            const disc = front => { c.save(); c.translate(cx, cy); c.rotate(-0.15); c.scale(1, 0.3); c.globalCompositeOperation = "lighter"; for(let q = 0; q < 4; q++){ const rr = r0 * (1.5 + q * 0.5), a = (0.7 - q * 0.14) * Math.min(1, T / 0.4); const g = c.createLinearGradient(-rr, 0, rr, 0); g.addColorStop(0, "rgba(255,240,200," + a.toFixed(3) + ")"); g.addColorStop(0.5, "rgba(255,130,50," + (a * 0.7).toFixed(3) + ")"); g.addColorStop(1, "rgba(150,60,255," + (a * 0.5).toFixed(3) + ")"); c.strokeStyle = g; c.lineWidth = r0 * (0.4 - q * 0.06); c.beginPath(); c.arc(0, 0, rr, front ? 0 : Math.PI, front ? Math.PI : CX_TAU); c.stroke(); } c.restore(); };
            disc(false);
            c.fillStyle = "#000"; c.beginPath(); c.arc(cx, cy, r0, 0, CX_TAU); c.fill();
            c.globalCompositeOperation = "lighter"; c.strokeStyle = "rgba(255,225,180,0.85)"; c.lineWidth = Math.max(1.4, r0 * 0.12); c.beginPath(); c.arc(cx, cy, r0 * 1.05, 0, CX_TAU); c.stroke();
            c.strokeStyle = "rgba(200,160,255,0.4)"; c.lineWidth = 1.5; c.beginPath(); c.arc(cx, cy, r0 * 1.3, Math.PI * 1.05, Math.PI * 1.95); c.stroke();
            disc(true);
            const n = plus ? 40 : 28;
            for(let i = 0; i < n; i++){ const ph = ((T * 0.9 + i / n + cxHash(i) * 0.2) % 1), rr = (1 - ph) * R * (0.4 + cxHash(i + 6) * 0.9) + r0, a = i * 2.4 + ph * 7 + T * 2; c.fillStyle = (i % 2 ? "rgba(190,150,255," : "rgba(255,170,100,") + (0.9 * Math.sin(ph * Math.PI)).toFixed(3) + ")"; c.beginPath(); c.arc(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.5, 1.2 + (1 - ph) * 1.6, 0, CX_TAU); c.fill(); }
        }
        if(T > P1 && T < P1 + 0.3){ const f = 1 - (T - P1) / 0.3; c.globalCompositeOperation = "lighter"; c.fillStyle = "rgba(255,255,255," + (0.8 * f).toFixed(3) + ")"; c.fillRect(0, 0, w, h); }
        if(T > P2 - 0.05){
            const e = (T - (P2 - 0.05)) / 1.0; c.globalCompositeOperation = "lighter";
            for(let j = 0; j < 3; j++){ const tt = e - j * 0.14; if(tt <= 0 || tt >= 1) continue; c.strokeStyle = (j === 1 ? "rgba(255,190,120," : "rgba(210,170,255,") + (0.95 * (1 - tt)).toFixed(3) + ")"; c.lineWidth = 9 * (1 - tt) + 2; c.beginPath(); c.arc(cx, cy, 8 + cxEase(tt) * R * 1.25, 0, CX_TAU); c.stroke(); }
            if(e < 1){ const g = c.createRadialGradient(cx, cy, 0, cx, cy, 110); g.addColorStop(0, "rgba(255,255,255," + (0.7 * (1 - e)).toFixed(3) + ")"); g.addColorStop(1, "rgba(160,90,255,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, 110, 0, CX_TAU); c.fill();
                for(let i = 0; i < 14; i++){ const a = cxHash(i + 20) * CX_TAU, rr = cxEase(e) * R * (0.5 + cxHash(i + 3) * 0.9); c.fillStyle = "rgba(255,240,255," + (0.9 * (1 - e)).toFixed(3) + ")"; cxStar(c, cx + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.8, 3 + cxHash(i) * 3, 4, e * 6 + i); c.fill(); } }
            c.globalCompositeOperation = "source-over";
            if(e < 1) cxWarpCanvas(c, Math.min(0.999, e * 0.9), w, h, 14);
        }
    }
};

function cxStartDone(key, T){ return !key || T > (STARTFX_DUR[key] || 1.2); }
function cxStartFx(c, key, cx, cy, T, w, h, plus){
    const dur = STARTFX_DUR[key]; if(!dur || T > dur) return;
    const k = T / dur, R = Math.min(w, h) * 0.62;
    c.save();
    if(STARTFX_V8[key]){ STARTFX_V8[key](c, cx, cy, T, w, h, plus, k, R); c.restore(); return; }   // نسخه‌ی جدید (۸.۰)
    if(key === "warp"){
        c.globalCompositeOperation = "lighter"; c.lineCap = "round";
        const n = plus ? 54 : 38;
        for(let i = 0; i < n; i++){
            const ang = i * CX_TAU / n + cxHash(i) * 0.3, r = cxHash(i + 9), e = cxEase(k);
            const in0 = 14 + r * 40 + e * R * (0.35 + r * 0.55), len = (10 + 150 * e) * (0.35 + r);
            const a = (1 - k) * (0.5 + r * 0.5);
            const x1 = cx + Math.cos(ang) * in0, y1 = cy + Math.sin(ang) * in0 * 0.9, x2 = cx + Math.cos(ang) * (in0 + len), y2 = cy + Math.sin(ang) * (in0 + len) * 0.9;
            const g = c.createLinearGradient(x1, y1, x2, y2); g.addColorStop(0, "rgba(160,215,255,0)"); g.addColorStop(1, "rgba(255,255,255," + a.toFixed(3) + ")");
            c.strokeStyle = g; c.lineWidth = 1 + r * 2; c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke();
        }
        if(T < 0.5){ const g = c.createRadialGradient(cx, cy, 2, cx, cy, 70 + T * 220); g.addColorStop(0, "rgba(255,255,255," + (0.9 * (1 - T / 0.5)).toFixed(3) + ")"); g.addColorStop(1, "rgba(120,190,255,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, 70 + T * 220, 0, CX_TAU); c.fill(); }
    } else if(key === "flash"){
        const a = Math.max(0, 1 - T / 0.65); c.fillStyle = "rgba(255,255,255," + (a * 0.8).toFixed(3) + ")"; c.fillRect(0, 0, w, h);
        c.globalCompositeOperation = "lighter";
        const g = c.createRadialGradient(cx, cy, 0, cx, cy, 40 + k * R); g.addColorStop(0, "rgba(255,250,220," + (0.85 * (1 - k)).toFixed(3) + ")"); g.addColorStop(1, "rgba(255,230,160,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, 40 + k * R, 0, CX_TAU); c.fill();
        c.strokeStyle = "rgba(255,255,255," + (0.5 * (1 - k)).toFixed(3) + ")"; c.lineWidth = 2;
        for(let i = 0; i < 14; i++){ const ang = i * CX_TAU / 14 + 0.2; c.beginPath(); c.moveTo(cx + Math.cos(ang) * 18, cy + Math.sin(ang) * 18); c.lineTo(cx + Math.cos(ang) * (30 + cxEase(k) * R * (i % 2 ? 0.7 : 1.05)), cy + Math.sin(ang) * (30 + cxEase(k) * R * (i % 2 ? 0.7 : 1.05))); c.stroke(); }
        const lg = c.createLinearGradient(cx - R, cy, cx + R, cy); lg.addColorStop(0, "rgba(160,210,255,0)"); lg.addColorStop(0.5, "rgba(255,255,255," + (0.8 * (1 - k)).toFixed(3) + ")"); lg.addColorStop(1, "rgba(160,210,255,0)"); c.fillStyle = lg; c.fillRect(cx - R, cy - 2.5, R * 2, 5);
        c.strokeStyle = "rgba(255,240,200," + (0.7 * (1 - k)).toFixed(3) + ")"; c.lineWidth = 3; c.beginPath(); c.arc(cx, cy, 14 + cxEase(k) * R * 0.5, 0, CX_TAU); c.stroke();
    } else if(key === "portal"){
        c.globalCompositeOperation = "lighter";
        const cols = [[155, 92, 255], [77, 201, 255], [255, 77, 106]];
        for(let j = 0; j < 3; j++){
            const t0 = j * 0.3, tt = (T - t0) / 0.95; if(tt <= 0 || tt >= 1) continue;
            const r = 12 + cxEase(tt) * R, a = (1 - tt), col = cols[j];
            const g = c.createRadialGradient(cx, cy, r * 0.7, cx, cy, r * 1.08); g.addColorStop(0, "rgba(" + col + ",0)"); g.addColorStop(0.7, "rgba(" + col + "," + (0.35 * a).toFixed(3) + ")"); g.addColorStop(1, "rgba(" + col + ",0)");
            c.fillStyle = g; c.beginPath(); c.arc(cx, cy, r * 1.08, 0, CX_TAU); c.fill();
            c.strokeStyle = "rgba(" + col + "," + (0.95 * a).toFixed(3) + ")"; c.lineWidth = 6 * (1 - tt) + 2; c.beginPath(); c.arc(cx, cy, r, 0, CX_TAU); c.stroke();
            for(let q = 0; q < 6; q++){ const ang = q * CX_TAU / 6 + tt * 3 + j; c.fillStyle = "rgba(255,255,255," + (0.8 * a).toFixed(3) + ")"; c.beginPath(); c.arc(cx + Math.cos(ang) * r, cy + Math.sin(ang) * r, 2.2, 0, CX_TAU); c.fill(); }
        }
        if(T < 0.4){ const g = c.createRadialGradient(cx, cy, 0, cx, cy, 60); g.addColorStop(0, "rgba(255,255,255," + (0.8 * (1 - T / 0.4)).toFixed(3) + ")"); g.addColorStop(1, "rgba(155,92,255,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, 60, 0, CX_TAU); c.fill(); }
    } else if(key === "royal"){
        c.globalCompositeOperation = "lighter";
        for(let j = 0; j < 2; j++){ const tt = (T - j * 0.22) / 1.1; if(tt <= 0 || tt >= 1) continue; const r = 14 + cxEase(tt) * R * (j ? 0.85 : 1);
            c.strokeStyle = (j ? "rgba(255,243,176," : "rgba(255,212,71,") + (0.95 * (1 - tt)).toFixed(3) + ")"; c.lineWidth = 5 * (1 - tt) + 1.5; c.beginPath(); c.arc(cx, cy, r, 0, CX_TAU); c.stroke(); }
        c.strokeStyle = "rgba(255,226,120," + (0.5 * (1 - k)).toFixed(3) + ")"; c.lineWidth = 2.5;
        for(let i = 0; i < 12; i++){ const ang = i * CX_TAU / 12 + T * 0.5; c.beginPath(); c.moveTo(cx + Math.cos(ang) * 20, cy + Math.sin(ang) * 20); c.lineTo(cx + Math.cos(ang) * (40 + cxEase(k) * R * 0.8), cy + Math.sin(ang) * (40 + cxEase(k) * R * 0.8)); c.stroke(); }
        c.globalCompositeOperation = "source-over"; c.globalAlpha = Math.max(0, 1 - k * 1.1); c.font = "bold " + (30 + k * 26 | 0) + "px Tahoma"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("👑", cx, cy - 8 - k * 24);
        c.globalCompositeOperation = "lighter"; c.globalAlpha = 1;
        for(let i = 0; i < 9; i++){ const ang = cxHash(i) * CX_TAU, rr = 20 + cxEase(k) * R * (0.4 + cxHash(i + 5) * 0.6); c.fillStyle = "rgba(255,230,140," + (0.9 * (1 - k)).toFixed(3) + ")"; cxStar(c, cx + Math.cos(ang) * rr, cy + Math.sin(ang) * rr, 4 + cxHash(i + 2) * 3, 4, T * 3 + i); c.fill(); }
    } else if(key === "burst"){
        c.globalCompositeOperation = "lighter";
        const cols = ["#ffe45e", "#ff7ad9", "#7cf6ff", "#ffffff", "#b6ff4d"];
        for(let i = 0; i < 16; i++){ const ang = i * CX_TAU / 16 + cxHash(i) * 0.4, sp = 0.5 + cxHash(i + 3) * 0.5, rr = 16 + cxEase(k) * R * sp;
            c.globalAlpha = Math.max(0, 1 - k * k); c.fillStyle = cols[i % 5]; cxStar(c, cx + Math.cos(ang) * rr, cy + Math.sin(ang) * rr * 0.9, 5 + cxHash(i + 7) * 5 * (1 - k * 0.5), 5, T * 4 + i); c.fill(); }
        c.globalAlpha = 1; if(T < 0.35){ const g = c.createRadialGradient(cx, cy, 0, cx, cy, 80); g.addColorStop(0, "rgba(255,255,230," + (0.8 * (1 - T / 0.35)).toFixed(3) + ")"); g.addColorStop(1, "rgba(255,230,120,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, 80, 0, CX_TAU); c.fill(); }
    } else if(key === "shock"){
        c.globalCompositeOperation = "lighter";
        for(let j = 0; j < 3; j++){ const tt = (T - j * 0.16) / 0.95; if(tt <= 0 || tt >= 1) continue; const r = 10 + cxEase(tt) * R * 1.05;
            c.strokeStyle = (j === 1 ? "rgba(120,230,255," : "rgba(255,255,255,") + (0.9 * (1 - tt)).toFixed(3) + ")"; c.lineWidth = 10 * (1 - tt) + 2; c.beginPath(); c.arc(cx, cy, r, 0, CX_TAU); c.stroke(); }
        const a = Math.max(0, 1 - T / 0.5) * 0.35; c.fillStyle = "rgba(160,235,255," + a.toFixed(3) + ")"; c.fillRect(0, 0, w, h);
    } else if(key === "bolt"){
        c.globalCompositeOperation = "lighter"; c.lineJoin = "round"; c.lineCap = "round";
        const seed = Math.floor(T * 14), flick = (T < 0.55) ? 1 : Math.max(0, 1 - (T - 0.55) / 0.5);
        const pts = []; let x = cx + (cxHash(seed) - 0.5) * 30; const steps = 8;
        for(let i = 0; i <= steps; i++){ pts.push([i === steps ? cx : x, cy * (i / steps) * 1.0]); x += (cxHash(seed * 7 + i) - 0.5) * 46; }
        [[10, 0.25], [5, 0.6], [2, 1]].forEach(l => { c.strokeStyle = "rgba(190,235,255," + (l[1] * flick).toFixed(3) + ")"; c.lineWidth = l[0]; c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.stroke(); });
        if(T < 0.5){ const g = c.createRadialGradient(cx, cy, 0, cx, cy, 120); g.addColorStop(0, "rgba(255,255,255," + (0.7 * (1 - T / 0.5)).toFixed(3) + ")"); g.addColorStop(1, "rgba(120,190,255,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, 120, 0, CX_TAU); c.fill(); }
        if(T > 0.3){ const tt = (T - 0.3) / 0.8; c.strokeStyle = "rgba(160,220,255," + (0.8 * (1 - tt)).toFixed(3) + ")"; c.lineWidth = 3; c.beginPath(); c.ellipse(cx, cy, 10 + cxEase(tt) * R * 0.7, (10 + cxEase(tt) * R * 0.7) * 0.4, 0, 0, CX_TAU); c.stroke(); }
    } else if(key === "meteor"){
        c.globalCompositeOperation = "lighter"; c.lineCap = "round";
        for(let i = 0; i < 7; i++){
            const st = i * 0.09, tt = (T - st) / 0.75; if(tt <= 0 || tt >= 1) continue;
            const sx = cx + 150 + i * 36 - (i % 2) * 40, sy = cy - 190 - i * 14, ex = cx - 40 + (i - 3) * 20, ey = cy + 6;
            const hx = sx + (ex - sx) * tt, hy = sy + (ey - sy) * tt, tx = hx - (ex - sx) * 0.22, ty = hy - (ey - sy) * 0.22;
            const g = c.createLinearGradient(tx, ty, hx, hy); g.addColorStop(0, "rgba(255,90,20,0)"); g.addColorStop(1, "rgba(255,200,90," + (0.95 * (1 - tt * 0.4)).toFixed(3) + ")");
            c.strokeStyle = g; c.lineWidth = 6 - tt * 2; c.beginPath(); c.moveTo(tx, ty); c.lineTo(hx, hy); c.stroke();
            c.fillStyle = "rgba(255,240,200,0.95)"; c.beginPath(); c.arc(hx, hy, 4.2, 0, CX_TAU); c.fill();
        }
        if(T > 0.5 && T < 1.2){ const tt = (T - 0.5) / 0.7; const g = c.createRadialGradient(cx, cy + 6, 0, cx, cy + 6, 40 + tt * 120); g.addColorStop(0, "rgba(255,200,100," + (0.8 * (1 - tt)).toFixed(3) + ")"); g.addColorStop(1, "rgba(255,90,20,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy + 6, 40 + tt * 120, 0, CX_TAU); c.fill(); }
    } else if(key === "void"){
        const tt = Math.min(1, T / 1.0);
        c.globalCompositeOperation = "source-over";
        const r0 = (1 - cxEase(tt)) * R * 0.9 + 6;
        if(T < 1.15){ const g = c.createRadialGradient(cx, cy, 0, cx, cy, r0 + 30); g.addColorStop(0, "rgba(0,0,0," + (0.55 * (1 - Math.max(0, T - 0.8) / 0.35)).toFixed(3) + ")"); g.addColorStop(0.7, "rgba(40,10,80,0.35)"); g.addColorStop(1, "rgba(80,30,160,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, r0 + 30, 0, CX_TAU); c.fill(); }
        c.globalCompositeOperation = "lighter"; c.lineCap = "round";
        for(let i = 0; i < 28; i++){ const base = i * CX_TAU / 28, sp = T * 3 + cxHash(i) * 2, rr = Math.max(6, (r0 + 24 + cxHash(i + 4) * 50) * (1 - Math.min(1, T / 1.1) * 0.8)), a = base + sp;
            if(T > 1.1) break; c.strokeStyle = "rgba(" + (i % 2 ? "170,110,255" : "255,170,90") + "," + (0.55 * (1 - T / 1.15)).toFixed(3) + ")"; c.lineWidth = 2; c.beginPath(); c.arc(cx, cy, rr, a, a + 0.35); c.stroke(); }
        if(T > 1.0){ const tt2 = (T - 1.0) / 0.9; c.strokeStyle = "rgba(220,190,255," + (0.95 * (1 - tt2)).toFixed(3) + ")"; c.lineWidth = 8 * (1 - tt2) + 2; c.beginPath(); c.arc(cx, cy, 8 + cxEase(tt2) * R * 1.05, 0, CX_TAU); c.stroke();
            const g = c.createRadialGradient(cx, cy, 0, cx, cy, 90); g.addColorStop(0, "rgba(255,255,255," + (0.6 * (1 - tt2)).toFixed(3) + ")"); g.addColorStop(1, "rgba(160,90,255,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, 90, 0, CX_TAU); c.fill(); }
    }
    c.restore();
}

/* ---------- زمین‌های ویژه ----------
   همه با paintGround رسم می‌شوند؛ ورودی‌ها: بوم، کلید، عرض، ارتفاع، خط زمین، زمان(ms)، اسکرول، گزینه‌ها */
const GROUNDS = {
    ocean:    { top:"#001a33", bottom:"#003d5c", glow:"#00d9ff" },
    diamond:  { top:"#0d1b2e", bottom:"#1b3a5c", glow:"#bfefff" },
    lava:     { top:"#2a0900", bottom:"#7a1c00", glow:"#ffb830" },
    milkyway: { top:"#1a0a2e", bottom:"#2e1150", glow:"#c78bff" },
    garden:   { top:"#1d3a22", bottom:"#2e5a34", glow:"#ffb6d9" },
    royal:    { top:"#2a1800", bottom:"#5a3a00", glow:"#ffd447" },
    glacier:  { top:"#9bd8ff", bottom:"#1f5f95", glow:"#ffffff" },
    neongrid: { top:"#1a0536", bottom:"#07021a", glow:"#ff3ec9" },
    mars:     { top:"#c2552a", bottom:"#4a1a0c", glow:"#ffb27a" },
    clouds:   { top:"#f4fbff", bottom:"#8fc4ee", glow:"#ffffff" },
    auroraland:{ top:"#0b3a3a", bottom:"#03161c", glow:"#7dffd0" },
    horizon:  { top:"#120824", bottom:"#030108", glow:"#b58cff" },
    cyber:    { top:"#14143a", bottom:"#05051a", glow:"#62f5ff" },
    moon:     { top:"#c4c8d2", bottom:"#262932", glow:"#f4f6fb" }
};
function cxMod(a, n){ return ((a % n) + n) % n; }
function paintGround(c, key, w, h, gy, tms, scroll, o){
    o = o || {};
    const th = GROUNDS[key], t = tms / 1000, plus = !!o.plus, gh = Math.max(10, h - gy), sc = Math.min(1, Math.max(0.35, (gy - 4) / 130));
    const g = c.createLinearGradient(0, gy, 0, h);
    if(th){ g.addColorStop(0, th.top); g.addColorStop(1, th.bottom); } else { const gr = o.gr || ["#1b3f8a", "#071433"]; g.addColorStop(0, gr[0]); g.addColorStop(1, gr[1]); }
    c.fillStyle = g; c.fillRect(0, gy, w, gh);
    c.fillStyle = th ? th.glow : "rgba(150,190,255,0.5)"; c.globalAlpha = 0.55; c.fillRect(0, gy, w, 3); c.globalAlpha = 1;
    c.save(); c.beginPath(); c.rect(0, gy, w, gh); c.clip();
    c.strokeStyle = "rgba(255,255,255,0.08)"; c.lineWidth = 1;
    const span = 46, off = cxMod(scroll, span);
    if(key !== "neongrid" && key !== "cyber" && key !== "royal"){ for(let x = -off; x < w + span; x += span){ c.beginPath(); c.moveTo(x, gy); c.lineTo(x - 28, h); c.stroke(); } }
    c.restore();
    if(!th) return;
    c.save();
    const L = GROUND_PAINT[key]; if(L) L(c, w, h, gy, t, scroll, plus, gh, sc);
    c.restore();
}
function cxClipGround(c, w, gy, gh){ c.beginPath(); c.rect(0, gy, w, gh); c.clip(); }
const GROUND_PAINT = {
    ocean(c, w, h, gy, t, sc0, plus, gh){
        c.save(); cxClipGround(c, w, gy, gh); c.globalCompositeOperation = "lighter";
        for(let L = 0; L < 3; L++){ c.strokeStyle = "rgba(" + (L === 1 ? "140,240,255" : "60,200,255") + "," + (0.22 - L * 0.04) + ")"; c.lineWidth = 2 - L * 0.4; c.beginPath();
            for(let x = 0; x <= w; x += 6){ const y = gy + 8 + L * gh * 0.24 + Math.sin(x * 0.045 + t * (1.4 + L * 0.4) + L * 2) * (3 + L); x === 0 ? c.moveTo(x, y) : c.lineTo(x, y); } c.stroke(); }
        for(let i = 0; i < (plus ? 12 : 8); i++){ const x = cxMod(i * 97 - sc0 * 0.5, w + 40) - 20, y = gy + 6 + cxHash(i) * (gh - 12), r = 2 + 2.5 * (0.5 + 0.5 * Math.sin(t * 2 + i)); c.fillStyle = "rgba(160,245,255,0.28)"; c.beginPath(); c.arc(x, y, r, 0, CX_TAU); c.fill(); }
        c.restore();
        c.globalCompositeOperation = "lighter"; for(let i = 0; i < 4; i++){ const ph = (t * 0.55 + i * 0.25) % 1, x = cxMod(i * 131 - sc0 * 0.25, w), r = 6 + ph * 26; c.strokeStyle = "rgba(120,235,255," + (0.5 * (1 - ph)).toFixed(3) + ")"; c.lineWidth = 1.6; c.beginPath(); c.ellipse(x, gy + 3, r, r * 0.22, 0, 0, CX_TAU); c.stroke(); }
    },
    diamond(c, w, h, gy, t, sc0, plus, gh){
        c.save(); cxClipGround(c, w, gy, gh);
        const sz = 34, off = cxMod(sc0 * 0.6, sz);
        for(let i = -1; i < w / sz + 2; i++){ const x = i * sz - off; c.fillStyle = (i % 2) ? "rgba(190,235,255,0.07)" : "rgba(255,255,255,0.03)"; c.beginPath(); c.moveTo(x, gy); c.lineTo(x + sz / 2, gy + gh * 0.55); c.lineTo(x + sz, gy); c.closePath(); c.fill(); c.strokeStyle = "rgba(200,240,255,0.14)"; c.lineWidth = 1; c.stroke(); }
        c.restore();
        c.globalCompositeOperation = "lighter";
        for(let i = 0; i < (plus ? 16 : 11); i++){ const x = cxMod(i * 61 + 17 - sc0 * 0.4, w + 20) - 10, y = gy + 5 + cxHash(i + 3) * (gh - 10), tw = Math.max(0, Math.sin(t * 2.6 + i * 1.9)); if(tw < 0.15) continue;
            c.fillStyle = "rgba(255,255,255," + (0.9 * tw).toFixed(3) + ")"; cxStar(c, x, y, 2.5 + tw * 4, 4, 0); c.fill(); }
    },
    lava(c, w, h, gy, t, sc0, plus, gh, sc){
        c.save(); cxClipGround(c, w, gy, gh);
        // رودخانه‌ی گدازه با سطح موجی
        const lg = c.createLinearGradient(0, gy, 0, h); lg.addColorStop(0, "#ffd24a"); lg.addColorStop(0.3, "#ff9a1f"); lg.addColorStop(0.7, "#d03a08"); lg.addColorStop(1, "#6a1200");
        c.fillStyle = lg; c.beginPath(); c.moveTo(0, h);
        for(let x = 0; x <= w; x += 8){ c.lineTo(x, gy + gh * 0.12 + Math.sin(x * 0.03 - t * 1.6) * 3 + Math.sin(x * 0.011 + t * 0.7) * 3); } c.lineTo(w, h); c.closePath(); c.fill();
        // پلیت‌های سنگی تیره روی گدازه که به چپ می‌روند
        for(let i = 0; i < 6; i++){ const pw = 46 + (i % 3) * 22, x = cxMod(i * 120 - sc0 * 0.7, w + 120) - 60, y = gy + gh * (0.28 + (i % 3) * 0.2);
            c.fillStyle = "#1c0a05"; c.beginPath(); c.moveTo(x, y); c.lineTo(x + pw * 0.2, y - 6); c.lineTo(x + pw * 0.85, y - 4); c.lineTo(x + pw, y + 2); c.lineTo(x + pw * 0.8, y + 9); c.lineTo(x + pw * 0.15, y + 8); c.closePath(); c.fill();
            c.strokeStyle = "rgba(255,170,40," + (0.55 + 0.3 * Math.sin(t * 3 + i)).toFixed(2) + ")"; c.lineWidth = 1.5; c.stroke(); }
        c.globalCompositeOperation = "lighter";
        for(let i = 0; i < 9; i++){ const ph = (t * 0.6 + i * 0.37) % 1, x = cxMod(i * 83 - sc0 * 0.5, w + 30) - 15, y = gy + gh * (0.3 + cxHash(i) * 0.6), r = 1.5 + Math.sin(ph * Math.PI) * 4;
            c.fillStyle = "rgba(255,230,120," + (0.8 * Math.sin(ph * Math.PI)).toFixed(3) + ")"; c.beginPath(); c.arc(x, y, r, 0, CX_TAU); c.fill(); }
        c.restore();
        c.globalCompositeOperation = "lighter";
        const glow = c.createLinearGradient(0, gy - 26 * sc, 0, gy); glow.addColorStop(0, "rgba(255,150,40,0)"); glow.addColorStop(1, "rgba(255,170,50,0.35)"); c.fillStyle = glow; c.fillRect(0, gy - 26 * sc, w, 26 * sc);
        for(let i = 0; i < (plus ? 16 : 11); i++){ const ph = (t * 0.45 + i * 0.173) % 1, x = cxMod(i * 53 + Math.sin(t + i) * 10 - sc0 * 0.35, w + 20) - 10, y = gy - ph * 62 * sc, a = Math.sin(ph * Math.PI);
            c.fillStyle = "rgba(255," + (170 + 70 * (1 - ph) | 0) + ",60," + (0.9 * a).toFixed(3) + ")"; c.beginPath(); c.arc(x, y, 1.6 + (i % 3) * 0.8, 0, CX_TAU); c.fill(); }
        c.strokeStyle = "rgba(255,200,90,0.07)"; c.lineWidth = 3; for(let i = 0; i < 4; i++){ c.beginPath(); const x0 = i * w / 4 + 20; c.moveTo(x0, gy); for(let y = 0; y < 40 * sc; y += 5) c.lineTo(x0 + Math.sin(y * 0.3 + t * 3 + i) * 5, gy - y); c.stroke(); }
    },
    milkyway(c, w, h, gy, t, sc0, plus, gh){
        c.save(); cxClipGround(c, w, gy, gh);
        const bx = cxMod(t * 18, w + 260) - 130, bg = c.createLinearGradient(bx - 90, gy, bx + 90, h); bg.addColorStop(0, "rgba(255,170,255,0)"); bg.addColorStop(0.5, "rgba(255,200,255,0.22)"); bg.addColorStop(1, "rgba(160,120,255,0)");
        c.fillStyle = bg; c.fillRect(0, gy, w, gh);
        c.globalCompositeOperation = "lighter";
        [["rgba(170,90,255,0.20)", 0.2], ["rgba(255,100,200,0.16)", 0.55], ["rgba(90,140,255,0.16)", 0.85]].forEach((n, i) => { const x = cxMod(w * n[1] - sc0 * 0.15, w + 160) - 80, rg = c.createRadialGradient(x, gy + gh * 0.5, 2, x, gy + gh * 0.5, 70); rg.addColorStop(0, n[0]); rg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = rg; c.fillRect(x - 70, gy, 140, gh); });
        for(let i = 0; i < (plus ? 46 : 30); i++){ const x = cxMod(i * 53.7 - sc0 * (0.25 + (i % 4) * 0.12), w + 10), y = gy + 4 + cxHash(i + 11) * (gh - 8), tw = 0.35 + 0.65 * Math.abs(Math.sin(t * (1 + (i % 3) * 0.7) + i));
            c.fillStyle = (i % 3 === 0 ? "rgba(255,200,255," : i % 3 === 1 ? "rgba(190,210,255," : "rgba(255,255,255,") + tw.toFixed(3) + ")"; c.beginPath(); c.arc(x, y, 0.8 + (i % 4) * 0.45, 0, CX_TAU); c.fill(); }
        c.restore();
        const sp = (t * 0.35) % 3; if(sp < 0.5){ const k = sp / 0.5, sx = w * 0.85 - k * w * 0.5, sy = gy - 36 + k * 30; c.globalCompositeOperation = "lighter"; const tg = c.createLinearGradient(sx, sy, sx + 60, sy - 24); tg.addColorStop(0, "rgba(255,255,255," + (0.9 * (1 - k)).toFixed(3) + ")"); tg.addColorStop(1, "rgba(255,255,255,0)"); c.strokeStyle = tg; c.lineWidth = 2; c.beginPath(); c.moveTo(sx, sy); c.lineTo(sx + 60, sy - 24); c.stroke(); }
    },
    garden(c, w, h, gy, t, sc0, plus, gh, sc){
        c.save(); cxClipGround(c, w, gy, gh);
        for(let L = 0; L < 2; L++){ c.fillStyle = L ? "rgba(70,150,80,0.55)" : "rgba(40,110,60,0.5)"; const sp = L ? 0.9 : 0.5; for(let i = -1; i < w / 8 + 2; i++){ const x = i * 8 - cxMod(sc0 * sp, 8); const hh = 5 + cxHash(i * 3 + L) * 8; c.beginPath(); c.moveTo(x, gy + gh * (0.2 + L * 0.25)); c.lineTo(x + 3, gy + gh * (0.2 + L * 0.25) - hh + Math.sin(t * 2 + i) * 1.5); c.lineTo(x + 6, gy + gh * (0.2 + L * 0.25)); c.fill(); } }
        for(let i = 0; i < 10; i++){ const x = cxMod(i * 71 - sc0 * 0.8, w + 20) - 10, y = gy + gh * (0.3 + cxHash(i) * 0.55); const col = ["#ffb6d9", "#ffffff", "#ffd36b", "#c9a6ff"][i % 4];
            c.fillStyle = col; for(let p = 0; p < 5; p++){ const a = p * CX_TAU / 5 + t * 0.3; c.beginPath(); c.arc(x + Math.cos(a) * 3, y + Math.sin(a) * 3, 2, 0, CX_TAU); c.fill(); } c.fillStyle = "#ffe45e"; c.beginPath(); c.arc(x, y, 1.6, 0, CX_TAU); c.fill(); }
        c.restore();
        // گلبرگ‌ها از راست به چپ (هم‌جهت با حرکت جهان)
        for(let i = 0; i < (plus ? 18 : 12); i++){ const sp = 52 + (i % 4) * 11, x = w + 20 - cxMod(t * sp + i * 83, w + 60), y = gy - 52 * sc + cxMod(i * 41 + t * 22, 54 * sc + gh * 0.6) + Math.sin(t * 2 + i) * 6, a = t * 2.4 + i;
            c.save(); c.translate(x, y); c.rotate(a); c.fillStyle = i % 3 === 0 ? "rgba(255,255,255,0.9)" : "rgba(255,182,217,0.92)"; c.beginPath(); c.ellipse(0, 0, 5, 2.6, 0, 0, CX_TAU); c.fill(); c.restore(); }
    },
    royal(c, w, h, gy, t, sc0, plus, gh, sc){
        c.save(); cxClipGround(c, w, gy, gh);
        const tile = 36, off = cxMod(sc0, tile);
        for(let i = -1; i < w / tile + 2; i++){ for(let r = 0; r < 3; r++){ const x = i * tile - off, y = gy + r * (gh / 3); c.fillStyle = ((i + r) % 2) ? "rgba(255,212,71,0.10)" : "rgba(0,0,0,0.10)"; c.fillRect(x, y, tile, gh / 3); } }
        c.strokeStyle = "rgba(255,226,120,0.35)"; c.lineWidth = 1; c.beginPath(); c.moveTo(0, gy + gh / 3); c.lineTo(w, gy + gh / 3); c.moveTo(0, gy + gh * 2 / 3); c.lineTo(w, gy + gh * 2 / 3); c.stroke();
        c.restore();
        // ستون‌های تخت پادشاهی: «آرام» حرکت می‌کنند (خیلی کندتر از موانع) و کمی محو و دورتر رسم می‌شوند
        // تا هیچ‌وقت با مانع‌ها اشتباه گرفته نشوند. یک ردیفِ دورتر و کندتر هم برای عمق اضافه شده است.
        const gap = 170, total = w + gap * 2;
        const column = (x, ph, pw, alpha, i) => {
            c.save(); c.globalAlpha = alpha;
            const pg = c.createLinearGradient(x - pw / 2, 0, x + pw / 2, 0); pg.addColorStop(0, "#9a7010"); pg.addColorStop(0.5, "#e8cb66"); pg.addColorStop(1, "#7d5a00");
            c.fillStyle = pg; c.beginPath(); c.moveTo(x - pw / 2, gy); c.lineTo(x - pw / 2, gy - ph + 14); c.lineTo(x, gy - ph); c.lineTo(x + pw / 2, gy - ph + 14); c.lineTo(x + pw / 2, gy); c.closePath(); c.fill();
            c.strokeStyle = "rgba(255,236,160,0.55)"; c.lineWidth = 1.1; c.stroke();
            c.fillStyle = "rgba(255,244,190,0.55)"; c.fillRect(x - pw / 2, gy - ph * 0.62, pw, 3); c.fillRect(x - pw / 2, gy - ph * 0.32, pw, 3);
            c.fillStyle = "rgba(120,70,0,0.5)"; c.fillRect(x - pw / 2 - 3, gy - 6, pw + 6, 6);
            c.globalCompositeOperation = "lighter"; const tw = 0.4 + 0.6 * Math.abs(Math.sin(t * 2 + i)); c.fillStyle = "rgba(255,240,160," + (tw * 0.7).toFixed(3) + ")"; cxStar(c, x, gy - ph - 6, 3 + tw * 2, 4, t); c.fill();
            const hg = c.createLinearGradient(0, gy - ph, 0, gy); hg.addColorStop(0, "rgba(255,226,120,0.26)"); hg.addColorStop(1, "rgba(255,226,120,0)"); c.fillStyle = hg; c.fillRect(x - pw * 0.9, gy - ph, pw * 1.8, ph);
            c.restore();
        };
        for(let i = 0; i < Math.ceil(total / (gap * 0.9)) + 1; i++) column(cxMod(i * gap * 0.9 + 55 - sc0 * 0.05, total) - gap * 0.6, (92 * sc + 42) * 0.62, 14, 0.38, i + 40);
        for(let i = 0; i < Math.ceil(total / gap) + 1; i++) column(cxMod(i * gap - sc0 * 0.12, total) - gap * 0.6, 92 * sc + 42, 20, 0.78, i);
    },
    glacier(c, w, h, gy, t, sc0, plus, gh, sc){
        c.save(); cxClipGround(c, w, gy, gh);
        for(let i = 0; i < 8; i++){ const x = cxMod(i * 90 - sc0 * 0.6, w + 100) - 50; c.fillStyle = "rgba(255,255,255,0.14)"; c.beginPath(); c.moveTo(x, gy); c.lineTo(x + 26, gy + gh * 0.9); c.lineTo(x - 10, gy + gh * 0.9); c.closePath(); c.fill(); }
        c.strokeStyle = "rgba(255,255,255,0.35)"; c.lineWidth = 1; for(let i = 0; i < 5; i++){ const x = cxMod(i * 150 - sc0 * 0.7, w + 60) - 30; c.beginPath(); c.moveTo(x, gy + 3); c.lineTo(x + 30, gy + gh * 0.5); c.lineTo(x + 18, gy + gh * 0.9); c.stroke(); }
        c.restore();
        for(let i = 0; i < 9; i++){ const x = cxMod(i * 88 + 30 - sc0 * 0.85, w + 80) - 40, hh = (12 + cxHash(i) * 20) * sc; c.fillStyle = "rgba(225,248,255,0.85)"; c.beginPath(); c.moveTo(x - 6, gy); c.lineTo(x - 1, gy - hh); c.lineTo(x + 4, gy - hh * 0.6); c.lineTo(x + 8, gy); c.closePath(); c.fill(); c.strokeStyle = "rgba(255,255,255,0.8)"; c.lineWidth = 1; c.stroke(); }
        c.globalCompositeOperation = "lighter"; for(let i = 0; i < 10; i++){ const x = cxMod(i * 67 - sc0 * 0.3, w), y = gy + cxHash(i) * gh, tw = Math.max(0, Math.sin(t * 2.4 + i * 2)); c.fillStyle = "rgba(255,255,255," + (tw * 0.9).toFixed(3) + ")"; cxStar(c, x, y, 2 + tw * 3, 4, 0); c.fill(); }
    },
    neongrid(c, w, h, gy, t, sc0, plus, gh){
        c.save(); cxClipGround(c, w, gy, gh); c.globalCompositeOperation = "lighter";
        const vx = w * 0.5; c.strokeStyle = "rgba(255,62,201,0.55)"; c.lineWidth = 1.2;
        for(let i = -8; i <= 8; i++){ c.beginPath(); c.moveTo(vx + i * 10, gy); c.lineTo(vx + i * 80, h); c.stroke(); }
        c.strokeStyle = "rgba(98,245,255,0.55)"; for(let i = 0; i < 6; i++){ const k = cxMod(i / 6 + sc0 * 0.004, 1), y = gy + k * k * gh; c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke(); }
        c.restore();
        const g = c.createLinearGradient(0, gy - 20, 0, gy + 8); g.addColorStop(0, "rgba(255,62,201,0)"); g.addColorStop(1, "rgba(255,62,201,0.35)"); c.fillStyle = g; c.fillRect(0, gy - 20, w, 28);
    },
    mars(c, w, h, gy, t, sc0, plus, gh, sc){
        c.save(); cxClipGround(c, w, gy, gh);
        [["rgba(120,40,15,0.45)", 0.6, 0.35, 70], ["rgba(255,150,90,0.25)", 0.9, 0.6, 50]].forEach((d, L) => { c.fillStyle = d[0]; c.beginPath(); c.moveTo(0, h);
            for(let x = 0; x <= w; x += 8) c.lineTo(x, gy + gh * d[2] + Math.sin((x + sc0 * d[1]) * 0.018 + L) * 9 + Math.sin((x + sc0 * d[1]) * 0.05) * 3); c.lineTo(w, h); c.closePath(); c.fill(); });
        for(let i = 0; i < 6; i++){ const x = cxMod(i * 113 - sc0 * 0.8, w + 40) - 20, y = gy + gh * (0.45 + cxHash(i) * 0.4); c.fillStyle = "rgba(60,20,10,0.5)"; c.beginPath(); c.ellipse(x, y, 7 + cxHash(i + 2) * 6, 2.6, 0, 0, CX_TAU); c.fill(); }
        c.restore();
        // کاکتوس‌های ساده: دو ردیف (دور = کوچک‌تر و کندتر، نزدیک = بزرگ‌تر)؛ سبز و ارگانیک تا با موانع اشتباه نشوند
        const cactus = (x, hh, k, a) => {
            const cw = hh * 0.22, g = c.createLinearGradient(x - cw, 0, x + cw, 0);
            c.save(); c.globalAlpha = a;
            g.addColorStop(0, "#2f6a3c"); g.addColorStop(0.45, "#5fae68"); g.addColorStop(1, "#285a34");
            c.fillStyle = g;
            c.beginPath(); cxRR(c, x - cw / 2, gy - hh, cw, hh + 1, cw / 2); c.fill();                                   // تنه
            if(k % 2 === 0){ c.beginPath(); cxRR(c, x - cw * 2.0, gy - hh * 0.62, cw * 1.6, cw * 0.62, cw * 0.3); c.fill(); c.beginPath(); cxRR(c, x - cw * 2.0, gy - hh * 0.62 - hh * 0.26, cw * 0.62, hh * 0.3, cw * 0.3); c.fill(); }   // بازوی چپ
            if(k % 3 !== 1){ c.beginPath(); cxRR(c, x + cw * 0.4, gy - hh * 0.46, cw * 1.6, cw * 0.62, cw * 0.3); c.fill(); c.beginPath(); cxRR(c, x + cw * 1.38, gy - hh * 0.46 - hh * 0.22, cw * 0.62, hh * 0.26, cw * 0.3); c.fill(); }   // بازوی راست
            c.strokeStyle = "rgba(190,240,190,0.35)"; c.lineWidth = Math.max(0.6, hh * 0.015); c.beginPath(); c.moveTo(x, gy - hh + cw * 0.4); c.lineTo(x, gy - 2); c.stroke();    // خط برجسته‌ی وسط
            c.fillStyle = "rgba(250,244,220,0.6)"; for(let q = 0; q < 6; q++) c.fillRect(x - cw * 0.45 + (q % 2) * cw * 0.7, gy - hh * (0.15 + q * 0.13), 1, 1);                        // خارها
            if(plus && k % 3 === 0){ c.fillStyle = "#ff6fa3"; c.beginPath(); c.arc(x, gy - hh - 1, Math.max(1.5, cw * 0.35), 0, CX_TAU); c.fill(); }                                    // گل صورتی
            c.fillStyle = "rgba(60,20,8,0.35)"; c.beginPath(); c.ellipse(x, gy + 1, cw * 1.4, 2, 0, 0, CX_TAU); c.fill();                                                           // سایه روی خاک
            c.restore();
        };
        for(let i = 0; i < 4; i++) cactus(cxMod(i * 190 + 70 - sc0 * 0.14, w + 160) - 80, 18 * sc + 8, i, 0.55);
        for(let i = 0; i < 3; i++) cactus(cxMod(i * 270 + 150 - sc0 * 0.3, w + 200) - 100, 34 * sc + 14, i + 1, 0.95);
        c.fillStyle = "rgba(255,190,140,0.25)"; for(let i = 0; i < (plus ? 14 : 9); i++){ const x = w + 10 - cxMod(t * (50 + i * 6) + i * 61, w + 30), y = gy - 4 - cxHash(i) * 26 * sc; c.beginPath(); c.arc(x, y, 1.4 + (i % 3), 0, CX_TAU); c.fill(); }
    },
    clouds(c, w, h, gy, t, sc0, plus, gh, sc){
        c.save(); cxClipGround(c, w, gy, gh);
        for(let L = 0; L < 3; L++){ c.fillStyle = "rgba(255,255,255," + (0.5 + L * 0.2) + ")"; for(let i = 0; i < 7; i++){ const x = cxMod(i * 90 - sc0 * (0.3 + L * 0.25), w + 120) - 60, y = gy + gh * (0.2 + L * 0.28) + Math.sin(t + i) * 1.5, r = 16 + cxHash(i + L * 7) * 12;
            c.beginPath(); c.moveTo(x + r, y); c.arc(x, y, r, 0, CX_TAU); c.moveTo(x + r * 1.7, y + 3); c.arc(x + r * 0.9, y + 3, r * 0.8, 0, CX_TAU); c.moveTo(x - r * 0.2, y + 4); c.arc(x - r * 0.9, y + 4, r * 0.7, 0, CX_TAU); c.fill(); } }
        c.restore();
        c.globalCompositeOperation = "lighter"; c.strokeStyle = "rgba(255,240,180,0.10)"; c.lineWidth = 8; for(let i = 0; i < 4; i++){ const x = i * w / 3 + Math.sin(t * 0.5 + i) * 12; c.beginPath(); c.moveTo(x, gy - 44 * sc); c.lineTo(x - 26, gy); c.stroke(); }
    },
    moon(c, w, h, gy, t, sc0, plus, gh, sc){
        // تپه‌های دور ماه (پشت خط افق) با دو لایه‌ی موازی
        for(let L = 0; L < 2; L++){
            c.fillStyle = L ? "rgba(150,155,170,0.55)" : "rgba(95,100,118,0.55)"; const sp = L ? 0.2 : 0.09, amp = (L ? 9 : 16) * sc;
            c.beginPath(); c.moveTo(0, gy);
            for(let x = 0; x <= w + 10; x += 8){ const u = (x + sc0 * sp) * (L ? 0.03 : 0.018); c.lineTo(x, gy - (amp * 0.6 + amp * 0.4 * Math.sin(u) + amp * 0.35 * Math.sin(u * 2.3 + 1.2) + amp * 0.2 * Math.sin(u * 5.1))); }
            c.lineTo(w + 10, gy); c.closePath(); c.fill();
        }
        // زمین در آسمان
        const er = Math.max(13, Math.min(w, h) * 0.058), ex = w * 0.5, ey = Math.max(er + 8, Math.min(gy * 0.095, 70));   // بالا-وسط: جایی که هیچ آیتم دکوری نمی‌نشیند
        c.save(); c.globalCompositeOperation = "lighter"; const ag = c.createRadialGradient(ex, ey, er * 0.9, ex, ey, er * 2.1); ag.addColorStop(0, "rgba(110,180,255,0.35)"); ag.addColorStop(1, "rgba(110,180,255,0)"); c.fillStyle = ag; c.beginPath(); c.arc(ex, ey, er * 2.1, 0, CX_TAU); c.fill(); c.restore();
        c.save(); c.beginPath(); c.arc(ex, ey, er, 0, CX_TAU); c.clip();
        const eg = c.createRadialGradient(ex - er * 0.35, ey - er * 0.35, er * 0.1, ex, ey, er); eg.addColorStop(0, "#7fc4ff"); eg.addColorStop(0.6, "#2a78d8"); eg.addColorStop(1, "#0b2f78"); c.fillStyle = eg; c.fillRect(ex - er, ey - er, er * 2, er * 2);
        c.fillStyle = "rgba(80,170,90,0.85)"; c.beginPath(); c.ellipse(ex - er * 0.25, ey - er * 0.15, er * 0.38, er * 0.28, 0.5, 0, CX_TAU); c.fill(); c.beginPath(); c.ellipse(ex + er * 0.3, ey + er * 0.3, er * 0.26, er * 0.2, -0.4, 0, CX_TAU); c.fill();
        c.fillStyle = "rgba(255,255,255,0.7)"; c.beginPath(); c.ellipse(ex + er * 0.1, ey - er * 0.45, er * 0.45, er * 0.1, 0.2, 0, CX_TAU); c.fill(); c.beginPath(); c.ellipse(ex - er * 0.2, ey + er * 0.1, er * 0.4, er * 0.09, -0.3, 0, CX_TAU); c.fill();
        const sd = c.createLinearGradient(ex - er, ey, ex + er, ey); sd.addColorStop(0, "rgba(0,0,0,0)"); sd.addColorStop(0.55, "rgba(0,0,0,0)"); sd.addColorStop(1, "rgba(0,5,25,0.62)"); c.fillStyle = sd; c.fillRect(ex - er, ey - er, er * 2, er * 2);
        c.restore();
        // سطح: بافت ریگولیت، دهانه‌ها، سنگ‌ها و گرد و غبار
        c.save(); cxClipGround(c, w, gy, gh);
        const sh = c.createLinearGradient(0, gy, 0, gy + gh); sh.addColorStop(0, "rgba(255,255,255,0.20)"); sh.addColorStop(0.25, "rgba(255,255,255,0)"); sh.addColorStop(1, "rgba(0,0,0,0.35)"); c.fillStyle = sh; c.fillRect(0, gy, w, gh);
        c.fillStyle = "rgba(60,64,76,0.35)"; for(let i = 0; i < (plus ? 70 : 44); i++){ const x = cxMod(cxHash(i) * (w + 40) - sc0 * (0.5 + (i % 3) * 0.25), w + 40) - 20, y = gy + 3 + cxHash(i + 70) * (gh - 6); c.fillRect(x, y, 1.4 + (i % 3) * 0.7, 1.2); }
        for(let L = 0; L < 2; L++){
            const n = L ? 5 : 8, sp = L ? 0.95 : 0.45;
            for(let i = 0; i < n; i++){
                const r = (L ? 22 : 11) + cxHash(i + L * 17) * (L ? 20 : 9), x = cxMod(i * (w / n + 30) + cxHash(i + 3) * 40 - sc0 * sp, w + r * 4) - r * 2, y = gy + gh * (L ? 0.62 : 0.34) + cxHash(i + 9 + L) * gh * 0.12, rx = r, ry = r * 0.26;
                c.fillStyle = "rgba(25,27,36,0.55)"; c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, CX_TAU); c.fill();
                c.fillStyle = "rgba(120,124,138,0.5)"; c.beginPath(); c.ellipse(x + rx * 0.12, y + ry * 0.18, rx * 0.82, ry * 0.7, 0, 0, CX_TAU); c.fill();
                c.strokeStyle = "rgba(255,255,255,0.42)"; c.lineWidth = L ? 2 : 1.3; c.beginPath(); c.ellipse(x, y, rx, ry, 0, Math.PI * 1.05, Math.PI * 1.95); c.stroke();
                c.strokeStyle = "rgba(0,0,0,0.35)"; c.lineWidth = 1.2; c.beginPath(); c.ellipse(x, y, rx, ry, 0, Math.PI * 0.05, Math.PI * 0.9); c.stroke();
            }
        }
        c.restore();
        for(let i = 0; i < 7; i++){ // سنگ‌های روی سطح
            const bw = (9 + cxHash(i + 50) * 14) * (0.7 + 0.3 * sc), bh = bw * (0.55 + cxHash(i + 60) * 0.35), x = cxMod(i * 97 + 30 - sc0 * 0.9, w + 80) - 40, y = gy + 2;
            c.fillStyle = "#4a4e5c"; c.beginPath(); c.moveTo(x - bw * 0.5, y); c.lineTo(x - bw * 0.38, y - bh * 0.7); c.lineTo(x - bw * 0.05, y - bh); c.lineTo(x + bw * 0.4, y - bh * 0.62); c.lineTo(x + bw * 0.5, y); c.closePath(); c.fill();
            c.fillStyle = "rgba(235,238,248,0.55)"; c.beginPath(); c.moveTo(x - bw * 0.38, y - bh * 0.7); c.lineTo(x - bw * 0.05, y - bh); c.lineTo(x + bw * 0.12, y - bh * 0.78); c.lineTo(x - bw * 0.2, y - bh * 0.5); c.closePath(); c.fill();
            c.fillStyle = "rgba(0,0,0,0.28)"; c.beginPath(); c.ellipse(x + bw * 0.25, y + 1.5, bw * 0.62, 2.4, 0, 0, CX_TAU); c.fill();
        }
        c.fillStyle = "rgba(210,214,226,0.30)"; for(let i = 0; i < (plus ? 16 : 10); i++){ const ph = (t * 0.5 + i * 0.173) % 1, x = w + 14 - cxMod(t * (38 + i * 5) + i * 71, w + 40), y = gy - 2 - ph * 14 * sc; c.globalAlpha = 0.5 * Math.sin(ph * Math.PI); c.beginPath(); c.arc(x, y, 1 + (i % 3) * 0.7, 0, CX_TAU); c.fill(); }
        c.globalAlpha = 1;
    },
    auroraland(c, w, h, gy, t, sc0, plus, gh, sc){
        c.save(); cxClipGround(c, w, gy, gh); c.globalCompositeOperation = "lighter";
        for(let i = 0; i < 4; i++){ const x = cxMod(i * w / 3.4 - sc0 * 0.2, w + 120) - 60, hue = (140 + i * 38 + t * 14) % 360; const g = c.createLinearGradient(0, gy + gh, 0, gy); g.addColorStop(0, "hsla(" + hue + ",90%,60%,0)"); g.addColorStop(1, "hsla(" + hue + ",90%,65%,0.45)");
            c.fillStyle = g; c.beginPath(); c.moveTo(x - 40, gy + gh); for(let y = 0; y <= gh; y += 6) c.lineTo(x + Math.sin(y * 0.2 + t * 1.5 + i) * 10 - 10, gy + gh - y); c.lineTo(x + 40, gy); c.closePath(); c.fill(); }
        c.restore();
        c.globalCompositeOperation = "lighter"; for(let i = 0; i < 12; i++){ const ph = (t * 0.4 + i * 0.21) % 1, x = cxMod(i * 77 - sc0 * 0.3, w), y = gy - ph * 40 * sc; c.fillStyle = "rgba(160,255,220," + (0.7 * Math.sin(ph * Math.PI)).toFixed(3) + ")"; c.beginPath(); c.arc(x, y, 1.6, 0, CX_TAU); c.fill(); }
    },
    horizon(c, w, h, gy, t, sc0, plus, gh, sc){
        c.save(); cxClipGround(c, w, gy, gh);
        const cx = w * 0.62, cy = gy + gh * 0.55;
        for(let i = 0; i < 4; i++){ c.strokeStyle = "rgba(" + (i % 2 ? "255,160,80" : "170,110,255") + "," + (0.5 - i * 0.08) + ")"; c.lineWidth = 2; c.beginPath(); c.ellipse(cx, cy, 24 + i * 22, (10 + i * 7), 0, t * 0.8 + i, t * 0.8 + i + 3.6); c.stroke(); }
        const g = c.createRadialGradient(cx, cy, 2, cx, cy, 26); g.addColorStop(0, "rgba(0,0,0,1)"); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, 26, 0, CX_TAU); c.fill();
        c.globalCompositeOperation = "lighter"; for(let i = 0; i < 16; i++){ const a = i * CX_TAU / 16 + t * 0.6, rr = 90 - cxMod(t * 22 + i * 13, 70); c.fillStyle = "rgba(190,150,255," + (0.5 * (1 - rr / 90)).toFixed(3) + ")"; c.beginPath(); c.arc(cx + Math.cos(a) * rr * 1.5, cy + Math.sin(a) * rr * 0.5, 1.4, 0, CX_TAU); c.fill(); }
        c.restore();
    },
    cyber(c, w, h, gy, t, sc0, plus, gh, sc){
        c.save(); c.globalCompositeOperation = "source-over";
        for(let L = 0; L < 2; L++){ for(let i = 0; i < 12; i++){ const bw = 22 + cxHash(i + L * 5) * 22, x = cxMod(i * 58 - sc0 * (0.45 + L * 0.3), w + 90) - 45, bh = (22 + cxHash(i * 2 + L) * 46) * sc; c.fillStyle = L ? "rgba(10,10,40,0.95)" : "rgba(20,20,60,0.85)"; c.fillRect(x, gy - bh * (L ? 1 : 0.8), bw, bh * (L ? 1 : 0.8));
            c.fillStyle = "rgba(98,245,255," + (L ? 0.9 : 0.55) + ")"; for(let r = 0; r < 4; r++) for(let q = 0; q < 2; q++){ if(cxHash(i * 7 + r * 3 + q + Math.floor(t * 0.5)) > 0.45) c.fillRect(x + 4 + q * 9, gy - bh + 4 + r * 9, 4, 4); } } }
        c.restore(); c.save(); cxClipGround(c, w, gy, gh); c.globalCompositeOperation = "lighter"; c.strokeStyle = "rgba(98,245,255,0.35)"; c.lineWidth = 1.2; for(let i = 0; i < 4; i++){ const y = gy + 6 + i * gh / 4.2; c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke(); }
        c.strokeStyle = "rgba(255,62,201,0.55)"; for(let i = 0; i < 6; i++){ const x = cxMod(i * 90 - sc0 * 0.8, w + 40); c.beginPath(); c.moveTo(x, gy); c.lineTo(x - 22, h); c.stroke(); } c.restore();
    }
};

/* ---------- فیلترها: بالای صفحه رنگ فیلتر، پایین رنگ خودِ بایوم، وسط ترکیب ---------- */
const FILTERS = {
    sunset:  { top:[255,120,60,0.52],  mid:[255,80,130,0.26], bot:[190,50,130,0.05], vig:"rgba(80,10,40,0.25)" },
    night:   { top:[70,40,190,0.52],   mid:[90,50,200,0.26],  bot:[50,20,140,0.05],  vig:"rgba(5,0,25,0.35)" },
    emerald: { top:[20,220,140,0.48],  mid:[20,170,120,0.24], bot:[10,110,90,0.05],  vig:"rgba(0,30,25,0.28)" },
    frost:   { top:[150,220,255,0.54], mid:[190,235,255,0.26],bot:[220,245,255,0.05],vig:"rgba(10,30,60,0.25)", snow:true },
    ember:   { top:[255,90,20,0.5],    mid:[220,50,10,0.24],  bot:[170,30,10,0.05],  vig:"rgba(40,5,0,0.32)", sparks:true },
    ocean:   { top:[20,170,210,0.54],  mid:[10,110,180,0.28], bot:[10,70,140,0.05],  vig:"rgba(0,20,45,0.30)", waves:true },
    bloodmoon:{ top:[200,20,45,0.52],  mid:[150,10,40,0.26],  bot:[90,10,30,0.05],   vig:"rgba(35,0,10,0.38)" },
    royal:   { top:[255,196,60,0.46],  mid:[230,150,30,0.22], bot:[150,90,0,0.05],   vig:"rgba(40,20,0,0.30)", royalGlow:true },
    neonstorm:{ top:[255,40,200,0.46], mid:[120,60,255,0.26], bot:[30,200,255,0.07], vig:"rgba(10,0,30,0.34)" },
    sakura:  { top:[255,150,200,0.5],  mid:[255,190,220,0.24],bot:[255,220,235,0.05],vig:"rgba(70,10,40,0.2)" }
};
/* ---------- لایه‌های بصری فیلترها (نسخه‌ی ۸.۰) ----------
   قانون کیفیت: فیلتر گران‌تر کمی زیباتر از ارزان‌تر است و فیلتر پولی همیشه از الماسی بهتر.
   الماسی: ۱۰۰ سانست/شب/زمردی ← ۱۳۰ اقیانوس ← ۱۵۰ سرما/آتش ← ۱۸۰ ماه خونین | پولی: ۵۰ هزار شکوفه/شفق ← ۵۵ هزار طوفان نئونی */
function fxBat(c, x, y, sz, flap){
    c.save(); c.translate(x, y); c.fillStyle = "rgba(20,0,10,0.9)";
    const f = Math.sin(flap) * 0.5;
    c.beginPath(); c.ellipse(0, 0, sz * 0.32, sz * 0.22, 0, 0, CX_TAU); c.fill();
    for(let sd = -1; sd <= 1; sd += 2){
        c.save(); c.scale(sd, 1); c.beginPath(); c.moveTo(sz * 0.2, 0);
        c.quadraticCurveTo(sz * 0.7, -sz * (0.5 + f), sz * 1.1, -sz * (0.1 + f * 0.6));
        c.quadraticCurveTo(sz * 0.85, sz * 0.05, sz * 0.7, sz * 0.2); c.quadraticCurveTo(sz * 0.5, sz * 0.05, sz * 0.3, sz * 0.22); c.closePath(); c.fill(); c.restore();
    }
    c.restore();
}
const FILTER_FX = {
    sunset(c, w, h, t, plus){
        c.save(); c.globalCompositeOperation = "lighter";
        const sx = w * 0.78, sy = h * 0.62;
        dcGlow(c, sx, sy, Math.max(w, h) * 0.42, "255,150,70", 0.24); dcGlow(c, sx, sy, Math.max(w, h) * 0.14, "255,230,170", 0.36);
        for(let i = 0; i < 3; i++){ const y = h * (0.16 + i * 0.12), x = cxMod(i * w * 0.4 - t * (8 + i * 3), w * 1.4) - w * 0.2, g = c.createLinearGradient(x, 0, x + w * 0.5, 0); g.addColorStop(0, "rgba(255,170,120,0)"); g.addColorStop(0.5, "rgba(255,170,120,0.10)"); g.addColorStop(1, "rgba(255,170,120,0)"); c.fillStyle = g; c.fillRect(x, y, w * 0.5, 6 + i * 3); }
        c.restore();
    },
    night(c, w, h, t, plus){
        c.save(); c.globalCompositeOperation = "lighter";
        const n = plus ? 36 : 22;
        for(let i = 0; i < n; i++){ const tw = 0.35 + 0.65 * Math.abs(Math.sin(t * 1.6 + i * 1.7)); c.fillStyle = "rgba(210,220,255," + (0.7 * tw).toFixed(3) + ")"; cxStar(c, cxHash(i + 11) * w, cxHash(i + 41) * h * 0.7, 1.6 + tw * 1.6, 4, 0); c.fill(); }
        const mx = w * 0.82, my = h * 0.17, r = Math.min(w, h) * 0.055 + 5;
        dcGlow(c, mx, my, r * 3.6, "170,170,255", 0.22);
        c.globalCompositeOperation = "source-over"; const mg = c.createRadialGradient(mx - r * 0.3, my - r * 0.3, r * 0.1, mx, my, r); mg.addColorStop(0, "#ffffff"); mg.addColorStop(1, "#b9baf0"); c.fillStyle = mg; c.beginPath(); c.arc(mx, my, r, 0, CX_TAU); c.fill();
        c.fillStyle = "rgba(120,120,190,0.35)"; c.beginPath(); c.arc(mx - r * 0.3, my + r * 0.2, r * 0.22, 0, CX_TAU); c.arc(mx + r * 0.35, my - r * 0.25, r * 0.15, 0, CX_TAU); c.fill();
        const ph = (t * 0.17) % 1; if(ph < 0.1){ const k = ph / 0.1; c.globalCompositeOperation = "lighter"; const x0 = w * 0.55 - k * w * 0.35, y0 = h * 0.08 + k * h * 0.2, g = c.createLinearGradient(x0, y0, x0 + 50, y0 - 18); g.addColorStop(0, "rgba(255,255,255," + (0.9 * (1 - k)).toFixed(2) + ")"); g.addColorStop(1, "rgba(255,255,255,0)"); c.strokeStyle = g; c.lineWidth = 1.6; c.beginPath(); c.moveTo(x0, y0); c.lineTo(x0 + 50, y0 - 18); c.stroke(); }
        c.restore();
    },
    emerald(c, w, h, t, plus){
        c.save(); c.globalCompositeOperation = "lighter";
        for(let k = 0; k < 2; k++){ const x = w * (0.3 + k * 0.4) + Math.sin(t * 0.5 + k * 2) * w * 0.06, g = c.createLinearGradient(x, 0, x, h * 0.7); g.addColorStop(0, "rgba(80,255,190,0)"); g.addColorStop(0.45, "rgba(80,255,190,0.10)"); g.addColorStop(1, "rgba(80,255,190,0)"); c.fillStyle = g; c.fillRect(x - w * 0.1, 0, w * 0.2, h * 0.7); }
        const n = plus ? 18 : 10;
        for(let i = 0; i < n; i++){ const ph = (t * 0.12 + i * 0.173) % 1, x = cxMod(i * 67 + Math.sin(t * 0.8 + i) * 20, w), y = h * 0.9 - ph * h * 0.85, a = Math.sin(ph * Math.PI); dcGlow(c, x, y, 6 + (i % 3) * 2, "120,255,190", 0.55 * a); }
        c.restore();
    },
    ocean(c, w, h, t, plus){
        c.save(); c.globalCompositeOperation = "lighter";
        for(let i = 0; i < 5; i++){ const x = w * (0.08 + i * 0.22) + Math.sin(t * 0.4 + i) * 22, g = c.createLinearGradient(0, 0, 0, h * 0.85); g.addColorStop(0, "rgba(200,250,255,0.16)"); g.addColorStop(1, "rgba(200,250,255,0)"); c.fillStyle = g; c.beginPath(); c.moveTo(x - 9, 0); c.lineTo(x + 9, 0); c.lineTo(x + 64, h * 0.85); c.lineTo(x - 44, h * 0.85); c.closePath(); c.fill(); }
        c.strokeStyle = "rgba(200,245,255,0.5)"; c.lineWidth = 1;
        const n = plus ? 16 : 9; for(let i = 0; i < n; i++){ const ph = (t * 0.1 + i * 0.131) % 1, x = cxMod(i * 53 + Math.sin(t * 1.3 + i) * 10, w), y = h * 0.95 - ph * h * 0.9; c.beginPath(); c.arc(x, y, 1.8 + (i % 4), 0, CX_TAU); c.stroke(); }
        c.restore();
    },
    frost(c, w, h, t, plus){
        c.save(); c.globalCompositeOperation = "lighter"; c.strokeStyle = "rgba(220,245,255,0.34)"; c.lineWidth = 1.2; c.lineCap = "round";
        [[0, 0, 1, 1], [w, 0, -1, 1]].forEach(cn => {
            for(let k = 0; k < 7; k++){ const ang = (k / 6) * 1.5 + 0.03, L = Math.min(w, h) * (0.22 + 0.14 * cxHash(k + 3)), dx = Math.cos(ang) * cn[2], dy = Math.sin(ang) * cn[3], ex = cn[0] + dx * L, ey = cn[1] + dy * L;
                c.beginPath(); c.moveTo(cn[0], cn[1]); c.lineTo(ex, ey); c.stroke();
                for(let b = 1; b < 4; b++){ const bx = cn[0] + dx * L * b / 4, by = cn[1] + dy * L * b / 4; c.beginPath(); c.moveTo(bx, by); c.lineTo(bx + (dx * 0.5 - dy * 0.9) * L * 0.18, by + (dy * 0.5 + dx * 0.9) * L * 0.18); c.moveTo(bx, by); c.lineTo(bx + (dx * 0.5 + dy * 0.9) * L * 0.18, by + (dy * 0.5 - dx * 0.9) * L * 0.18); c.stroke(); } }
        });
        const n = plus ? 18 : 10; for(let i = 0; i < n; i++){ const tw = Math.max(0, Math.sin(t * 2.2 + i * 2.3)); c.fillStyle = "rgba(255,255,255," + (0.9 * tw).toFixed(3) + ")"; cxStar(c, cxHash(i + 70) * w, cxHash(i + 90) * h * 0.7, 2 + tw * 3, 4, t); c.fill(); }
        c.restore();
    },
    ember(c, w, h, t, plus){
        c.save(); c.globalCompositeOperation = "lighter";
        const g = c.createLinearGradient(0, h, 0, h * 0.5); g.addColorStop(0, "rgba(255,90,20,0.32)"); g.addColorStop(1, "rgba(255,90,20,0)"); c.fillStyle = g; c.fillRect(0, h * 0.5, w, h * 0.5);
        c.strokeStyle = "rgba(255,170,80,0.10)"; c.lineWidth = 3; for(let L = 0; L < 3; L++){ c.beginPath(); for(let x = 0; x <= w; x += 8){ const y = h * (0.78 - L * 0.07) + Math.sin(x * 0.03 + t * (2 + L * 0.6)) * 5; if(x) c.lineTo(x, y); else c.moveTo(x, y); } c.stroke(); }
        const n = plus ? 12 : 7; for(let i = 0; i < n; i++){ const ph = (t * 0.22 + i * 0.113) % 1, x = cxMod(i * 71 + Math.sin(t * 1.5 + i) * 16, w), y = h * 0.95 - ph * h * 0.9; dcGlow(c, x, y, 5 + (i % 3) * 2, "255,150,50", 0.65 * Math.sin(ph * Math.PI)); }
        c.restore();
    },
    bloodmoon(c, w, h, t, plus){   // ۱۸۰ الماس: زیباترین فیلتر الماسی
        const mx = w * 0.76, my = h * 0.2, r = Math.min(w, h) * 0.105 + 8;
        c.save(); c.globalCompositeOperation = "lighter"; dcGlow(c, mx, my, r * 4, "255,50,50", 0.32); dcGlow(c, mx, my, r * 2.1, "255,110,90", 0.3); c.restore();
        const mg = c.createRadialGradient(mx - r * 0.35, my - r * 0.35, r * 0.1, mx, my, r); mg.addColorStop(0, "#ffb7a6"); mg.addColorStop(0.55, "#d2283a"); mg.addColorStop(1, "#6a0614");
        c.fillStyle = mg; c.beginPath(); c.arc(mx, my, r, 0, CX_TAU); c.fill();
        c.fillStyle = "rgba(90,0,12,0.35)"; [[-0.3, 0.2, 0.2], [0.35, -0.2, 0.14], [0.1, 0.45, 0.12], [-0.2, -0.4, 0.1]].forEach(q => { c.beginPath(); c.arc(mx + q[0] * r, my + q[1] * r, q[2] * r, 0, CX_TAU); c.fill(); });
        c.save(); c.beginPath(); c.arc(mx, my, r, 0, CX_TAU); c.clip(); c.fillStyle = "rgba(40,0,10,0.55)";
        for(let i = 0; i < 2; i++){ const x = cxMod(i * r * 3 + t * 6, r * 5) - r * 1.4 + mx - r, y = my + (i ? 0.35 : -0.3) * r; c.beginPath(); c.ellipse(x, y, r * 1.2, r * 0.16, 0, 0, CX_TAU); c.fill(); } c.restore();
        c.save(); c.globalCompositeOperation = "lighter";
        const mist = c.createLinearGradient(0, h, 0, h * 0.55); mist.addColorStop(0, "rgba(220,30,50,0.20)"); mist.addColorStop(1, "rgba(220,30,50,0)"); c.fillStyle = mist; c.fillRect(0, h * 0.55, w, h * 0.45); c.restore();
        for(let i = 0; i < 3; i++){ const k = (t * 0.05 + i * 0.33) % 1; fxBat(c, w * (1.1 - k * 1.3), h * (0.16 + i * 0.09) + Math.sin(t * 2 + i) * 6, 8 + i * 2, t * 9 + i * 2); }
    },
    sakura(c, w, h, t, plus){   // ۵۰ هزار: شاخه‌ی شکوفه، پرهای گلبرگ واضح و درشت، نور صورتی و بوکه
        c.save(); c.globalCompositeOperation = "lighter";
        for(let i = 0; i < 4; i++){ const x = w * (0.15 + i * 0.25) + Math.sin(t * 0.3 + i) * 14, g = c.createLinearGradient(x, 0, x + 60, h * 0.8); g.addColorStop(0, "rgba(255,200,225,0.14)"); g.addColorStop(1, "rgba(255,200,225,0)"); c.fillStyle = g; c.beginPath(); c.moveTo(x - 10, 0); c.lineTo(x + 10, 0); c.lineTo(x + 80, h * 0.8); c.lineTo(x - 30, h * 0.8); c.closePath(); c.fill(); }
        for(let i = 0; i < 8; i++){ const bx = cxMod(i * 61 + t * 6, w + 40) - 20, by = h * (0.12 + (i % 4) * 0.2); dcGlow(c, bx, by, 26 + (i % 3) * 8, "255,200,225", 0.16); }
        c.restore();
        c.save(); c.strokeStyle = "rgba(70,28,40,0.92)"; c.lineCap = "round";   // شاخه‌ی گوشه‌ی بالا-راست
        const br = [[w + 6, h * 0.06, w * 0.82, h * 0.1, 7], [w * 0.82, h * 0.1, w * 0.66, h * 0.07, 4], [w * 0.82, h * 0.1, w * 0.74, h * 0.2, 3.4], [w * 0.9, h * 0.07, w * 0.86, h * 0.0, 3]];
        br.forEach(b => { c.lineWidth = b[4]; c.beginPath(); c.moveTo(b[0], b[1]); c.quadraticCurveTo((b[0] + b[2]) / 2, Math.min(b[1], b[3]) - 8, b[2], b[3]); c.stroke(); });
        [[w * 0.66, h * 0.07], [w * 0.74, h * 0.2], [w * 0.82, h * 0.1], [w * 0.7, h * 0.13], [w * 0.9, h * 0.03], [w * 0.78, h * 0.04]].forEach((q, i) => {
            c.save(); c.translate(q[0], q[1]); c.rotate(i); dcGlow(c, 0, 0, 16, "255,170,205", 0.35);
            for(let p = 0; p < 5; p++){ c.rotate(CX_TAU / 5); c.fillStyle = "rgba(255,196,220,0.95)"; c.beginPath(); c.ellipse(0, -5.2, 3.6, 5.4, 0, 0, CX_TAU); c.fill(); }
            c.fillStyle = "rgba(255,120,160,0.95)"; c.beginPath(); c.arc(0, 0, 2.2, 0, CX_TAU); c.fill(); c.restore(); });
        c.restore();
        const n = plus ? 46 : 30;
        for(let i = 0; i < n; i++){
            const sp = 14 + (i % 5) * 5, x = cxMod(w * 0.9 - t * sp * 1.2 + i * 83 + Math.sin(t * 0.9 + i) * 26, w + 60) - 30, y = cxMod(i * 47 + t * sp * 0.9, h * 0.95), sz = 3.6 + (i % 4) * 1.5, rot = t * (0.8 + (i % 3) * 0.5) + i;
            c.save(); c.translate(x, y); c.rotate(rot); c.scale(1, 0.55 + 0.45 * Math.abs(Math.sin(t * 1.4 + i)));
            c.fillStyle = i % 3 ? "rgba(255,185,212,0.92)" : "rgba(255,225,238,0.92)"; c.beginPath(); c.ellipse(0, 0, sz * 1.5, sz, 0, 0, CX_TAU); c.fill();
            c.fillStyle = "rgba(255,120,160,0.55)"; c.beginPath(); c.ellipse(sz * 0.5, 0, sz * 0.5, sz * 0.35, 0, 0, CX_TAU); c.fill(); c.restore();
        }
    },
    aurora(c, w, h, t, plus){   // ۵۰ هزار: پرده‌های نوارِ شفق با پرتوهای عمودی، ستاره‌های چشمک‌زن و درخششِ بازتابی
        c.save(); c.globalCompositeOperation = "lighter";
        for(let L = 0; L < 3; L++){
            const hue = (t * 22 + L * 70) % 360, base = h * (0.12 + L * 0.09), len = h * (0.34 - L * 0.05);
            const top = x => base + Math.sin(x * 0.012 + t * 0.7 + L * 2) * h * 0.05 + Math.sin(x * 0.031 + t * 1.1 + L) * h * 0.016;
            const g = c.createLinearGradient(0, base - h * 0.06, 0, base + len); g.addColorStop(0, "hsla(" + hue + ",95%,60%,0.0)"); g.addColorStop(0.18, "hsla(" + hue + ",95%,62%,0.32)"); g.addColorStop(1, "hsla(" + hue + ",95%,60%,0)");
            c.fillStyle = g; c.beginPath(); c.moveTo(0, top(0)); for(let x = 12; x <= w + 12; x += 12) c.lineTo(Math.min(x, w), top(Math.min(x, w))); for(let x = w; x >= -12; x -= 12) c.lineTo(Math.max(x, 0), top(Math.max(x, 0)) + len * (0.7 + 0.3 * Math.sin(x * 0.02 + t + L))); c.closePath(); c.fill();
            c.lineWidth = 2; for(let x = 0; x < w; x += 19){ const a = 0.10 + 0.14 * Math.abs(Math.sin(x * 0.05 + t * 1.2 + L * 2)); c.strokeStyle = "hsla(" + hue + ",95%,70%," + a.toFixed(3) + ")"; c.beginPath(); c.moveTo(x, top(x)); c.lineTo(x + Math.sin(t + x) * 3, top(x) + len * (0.4 + 0.5 * Math.abs(Math.sin(x * 0.07 + t * 0.9)))); c.stroke(); }
        }
        const n = plus ? 24 : 14; for(let i = 0; i < n; i++){ const tw = 0.3 + 0.7 * Math.abs(Math.sin(t * 1.5 + i * 2)); c.fillStyle = "rgba(255,255,255," + (0.8 * tw).toFixed(3) + ")"; cxStar(c, cxHash(i + 120) * w, cxHash(i + 150) * h * 0.55, 1.4 + tw * 1.8, 4, 0); c.fill(); }
        c.restore();
    },
    neonstorm(c, w, h, t, plus){   // ۵۵ هزار: بارانِ نئونی، رعد و برقِ صورتی‌فیروزه‌ای، درخشش شهر و باریکه‌های نور
        c.save(); c.globalCompositeOperation = "lighter"; c.lineCap = "round";
        for(let i = 0; i < 4; i++){ const x = cxMod(i * w / 3.2 + t * 14, w + 60) - 30, hue = i % 2 ? "255,60,210" : "60,230,255", g = c.createLinearGradient(x - 18, 0, x + 18, 0); g.addColorStop(0, "rgba(" + hue + ",0)"); g.addColorStop(0.5, "rgba(" + hue + "," + (0.10 + 0.06 * Math.sin(t * 3 + i)).toFixed(3) + ")"); g.addColorStop(1, "rgba(" + hue + ",0)"); c.fillStyle = g; c.fillRect(x - 18, 0, 36, h * 0.8); }
        const n = plus ? 46 : 28;
        for(let i = 0; i < n; i++){ const sp = 260 + (i % 5) * 70, x = cxMod(i * 41 - t * sp * 0.25, w + 40) - 20, y = cxMod(i * 67 + t * sp, h + 60) - 30, L = 14 + (i % 4) * 5; c.strokeStyle = (i % 2 ? "rgba(255,70,215," : "rgba(80,235,255,") + (0.35 + 0.2 * (i % 3)).toFixed(2) + ")"; c.lineWidth = 1.3; c.beginPath(); c.moveTo(x, y); c.lineTo(x - L * 0.25, y - L); c.stroke(); }
        const ph = (t * 0.36) % 1;
        if(ph < 0.14){ const f = 1 - ph / 0.14, seed = Math.floor(t * 0.36), pts = cxJag(w * (0.3 + cxHash(seed) * 0.4), 0, w * (0.3 + cxHash(seed + 9) * 0.4), h * 0.75, seed, 9, 50);
            c.fillStyle = (seed % 2 ? "rgba(255,70,215," : "rgba(80,235,255,") + (0.14 * f).toFixed(3) + ")"; c.fillRect(0, 0, w, h);
            [[7, 0.2], [3, 0.55], [1.4, 1]].forEach(L => { c.strokeStyle = (L[1] === 1 ? "rgba(255,255,255," : (seed % 2 ? "rgba(255,90,225," : "rgba(100,240,255,")) + (L[1] * f).toFixed(3) + ")"; c.lineWidth = L[0]; c.beginPath(); pts.forEach((q, i) => i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])); c.stroke(); }); }
        const cg = c.createLinearGradient(0, h, 0, h * 0.6); cg.addColorStop(0, "rgba(255,60,210,0.2)"); cg.addColorStop(1, "rgba(255,60,210,0)"); c.fillStyle = cg; c.fillRect(0, h * 0.6, w, h * 0.4);
        c.restore();
    },
    royal(c, w, h, t, plus){   // VIP
        c.save(); c.globalCompositeOperation = "lighter";
        for(let i = 0; i < 5; i++){ const x = w * (0.1 + i * 0.2) + Math.sin(t * 0.4 + i) * 16, g = c.createLinearGradient(x, 0, x + 50, h * 0.8); g.addColorStop(0, "rgba(255,230,140,0.14)"); g.addColorStop(1, "rgba(255,230,140,0)"); c.fillStyle = g; c.beginPath(); c.moveTo(x - 8, 0); c.lineTo(x + 8, 0); c.lineTo(x + 70, h * 0.8); c.lineTo(x - 30, h * 0.8); c.closePath(); c.fill(); }
        const n = plus ? 30 : 18; for(let i = 0; i < n; i++){ const ph = (t * 0.1 + i * 0.0731) % 1, x = cxMod(i * 59 + Math.sin(t * 0.7 + i) * 18, w), y = h * 0.95 - ph * h * 0.9, a = Math.sin(ph * Math.PI); c.fillStyle = "rgba(255,230,150," + (0.85 * a).toFixed(3) + ")"; cxStar(c, x, y, 1.6 + (i % 3), 4, t + i); c.fill(); }
        c.restore();
    }
};

function cxFilter(c, key, w, h, tms, plus){
    if(!key || key === "none") return;
    const t = tms / 1000;
    if(key === "aurora"){ // همان فیلتر زنده‌ی قبلی (بدون تغییر)
        const h1 = (t * 22) % 360, h2 = (h1 + 120) % 360, h3 = (h1 + 240) % 360;
        const ag = c.createLinearGradient(0, 0, w, h);
        ag.addColorStop(0, `hsla(${h1},90%,55%,0.30)`); ag.addColorStop(0.5, `hsla(${h2},90%,55%,0.22)`); ag.addColorStop(1, `hsla(${h3},90%,50%,0.30)`);
        c.fillStyle = ag; c.fillRect(0, 0, w, h);
        c.save(); c.globalCompositeOperation = "lighter";
        for(let i = 0; i < 3; i++){
            const cx = w * (0.2 + 0.3 * i) + Math.sin(t * 0.7 + i * 2) * w * 0.08, hh = (h1 + i * 70) % 360;
            const rg = c.createLinearGradient(cx, 0, cx, h * 0.75);
            rg.addColorStop(0, `hsla(${hh},95%,60%,0)`); rg.addColorStop(0.4, `hsla(${hh},95%,60%,0.24)`); rg.addColorStop(1, `hsla(${hh},95%,60%,0)`);
            c.fillStyle = rg; c.fillRect(cx - w * 0.13, 0, w * 0.26, h * 0.75);
        }
        c.restore();
        const av = c.createRadialGradient(w / 2, h * 0.42, Math.min(w, h) * 0.18, w / 2, h * 0.42, Math.max(w, h) * 0.78);
        av.addColorStop(0, "rgba(0,0,0,0)"); av.addColorStop(1, "rgba(5,0,30,0.32)"); c.fillStyle = av; c.fillRect(0, 0, w, h);
        c.save(); c.globalCompositeOperation = "source-over"; c.globalAlpha = 1; FILTER_FX.aurora(c, w, h, t, plus); c.restore();
        return;
    }
    const s = FILTERS[key]; if(!s) return;
    const rgba = a => "rgba(" + a[0] + "," + a[1] + "," + a[2] + "," + a[3] + ")";
    const g = c.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, rgba(s.top)); g.addColorStop(0.5, rgba(s.mid)); g.addColorStop(1, rgba(s.bot));
    c.fillStyle = g; c.fillRect(0, 0, w, h);
    const vg = c.createRadialGradient(w / 2, h * 0.42, Math.min(w, h) * 0.18, w / 2, h * 0.42, Math.max(w, h) * 0.78);
    vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, s.vig); c.fillStyle = vg; c.fillRect(0, 0, w, h);
    c.save();
    if(s.royalGlow){ const rg = c.createRadialGradient(w / 2, h * 0.3, 20, w / 2, h * 0.3, Math.max(w, h) * 0.65); rg.addColorStop(0, "rgba(255,225,120,0.16)"); rg.addColorStop(1, "rgba(255,225,120,0)"); c.fillStyle = rg; c.fillRect(0, 0, w, h); }
    if(s.snow){ c.fillStyle = "rgba(255,255,255,0.75)"; for(let i = 0; i < (plus ? 26 : 16); i++){ const x = cxMod(i * 53 + Math.sin(t + i) * 14 - t * 20, w), y = cxMod(i * 37 + t * (22 + (i % 4) * 8), h * 0.8); c.beginPath(); c.arc(x, y, 1 + (i % 3) * 0.6, 0, CX_TAU); c.fill(); } }
    if(s.sparks){ c.globalCompositeOperation = "lighter"; for(let i = 0; i < (plus ? 22 : 14); i++){ const ph = (t * 0.3 + i * 0.137) % 1, x = cxMod(i * 61 + Math.sin(t * 1.4 + i) * 12, w), y = h * 0.85 - ph * h * 0.8; c.fillStyle = "rgba(255," + (150 + (i % 4) * 25) + ",50," + (0.7 * Math.sin(ph * Math.PI)).toFixed(3) + ")"; c.beginPath(); c.arc(x, y, 1.2 + (i % 3) * 0.7, 0, CX_TAU); c.fill(); } }
    if(s.waves){ c.globalCompositeOperation = "lighter"; for(let L = 0; L < 3; L++){ c.strokeStyle = "rgba(150,240,255," + (0.12 - L * 0.025) + ")"; c.lineWidth = 3; c.beginPath(); for(let x = 0; x <= w; x += 8){ const y = h * (0.12 + L * 0.1) + Math.sin(x * 0.02 + t * (0.9 + L * 0.3) + L) * 9; x === 0 ? c.moveTo(x, y) : c.lineTo(x, y); } c.stroke(); } }
    if(s.moon){ const mx = w * 0.78, my = h * 0.14, r = Math.min(w, h) * 0.075 + 6; const mg = c.createRadialGradient(mx, my, r * 0.5, mx, my, r * 3); mg.addColorStop(0, "rgba(255,120,110,0.45)"); mg.addColorStop(1, "rgba(255,60,60,0)"); c.fillStyle = mg; c.beginPath(); c.arc(mx, my, r * 3, 0, CX_TAU); c.fill(); c.fillStyle = "rgba(255,150,140,0.55)"; c.beginPath(); c.arc(mx, my, r, 0, CX_TAU); c.fill(); }
    if(s.scan){ c.globalCompositeOperation = "lighter"; for(let i = 0; i < 4; i++){ const x = cxMod(i * w / 3.2 + t * 14, w + 60) - 30, hue = i % 2 ? "255,60,210" : "60,230,255", g = c.createLinearGradient(x - 18, 0, x + 18, 0); g.addColorStop(0, "rgba(" + hue + ",0)"); g.addColorStop(0.5, "rgba(" + hue + "," + (0.10 + 0.06 * Math.sin(t * 3 + i)).toFixed(3) + ")"); g.addColorStop(1, "rgba(" + hue + ",0)"); c.fillStyle = g; c.fillRect(x - 18, 0, 36, h * 0.8); } c.globalCompositeOperation = "source-over"; c.fillStyle = "rgba(0,0,0,0.10)"; for(let y = 0; y < h; y += 4) c.fillRect(0, y, w, 1.4); const fl = 0.5 + 0.5 * Math.sin(t * 7); c.fillStyle = "rgba(255,60,210," + (0.03 + fl * 0.04) + ")"; c.fillRect(0, 0, w, h * 0.5); }
    if(s.petals){ c.globalCompositeOperation = "lighter"; for(let i = 0; i < 7; i++){ const bx = cxMod(i * 61 + t * 6, w + 40) - 20, by = h * (0.12 + (i % 4) * 0.2), g = c.createRadialGradient(bx, by, 0, bx, by, 26 + (i % 3) * 8); g.addColorStop(0, "rgba(255,200,225,0.16)"); g.addColorStop(1, "rgba(255,200,225,0)"); c.fillStyle = g; c.beginPath(); c.arc(bx, by, 26 + (i % 3) * 8, 0, CX_TAU); c.fill(); } c.globalCompositeOperation = "source-over"; for(let i = 0; i < (plus ? 26 : 16); i++){ const x = cxMod(w - (t * (26 + (i % 3) * 8) + i * 71), w + 20) , y = cxMod(i * 53 + t * 24, h * 0.85); c.save(); c.translate(x, y); c.rotate(t * 1.6 + i); c.fillStyle = "rgba(255,225,238,0.8)"; c.beginPath(); c.ellipse(0, 0, 5, 2.6, 0, 0, CX_TAU); c.fill(); c.restore(); } }
    c.restore();
    if(FILTER_FX[key]){ c.save(); c.globalCompositeOperation = "source-over"; c.globalAlpha = 1; FILTER_FX[key](c, w, h, t, plus); c.restore(); }
}

/* ================================================================
   صدای افکت‌های ورود به بازی (نسخه ۸.۰)
   هر افکت صدای متناسب با خودش دارد (رعد واقعی برای صاعقه، سوت و برخورد برای شهاب‌سنگ، قطره و موج برای لرزش موجی…).
   قانون کیفیت: هرچه افکت گران‌تر، صدا لایه‌های بیشتر و زیباتری دارد.
   همه‌ی صداها روی ساعتِ WebAudio زمان‌بندی می‌شوند (پس با خاموش‌شدن صفحه دقیقاً همان‌جا متوقف و ادامه می‌یابند).
   ================================================================ */
function NOTE(n){ return 440 * Math.pow(2, (n - 69) / 12); }   // شماره‌ی نتِ MIDI به هرتز
function sfxArp(notes, step, type, vol, dur, delay, o){ notes.forEach((n, i) => sfxVoice(NOTE(n), dur, type, vol, Object.assign({ delay: (delay || 0) + i * step }, o || {}))); }
function sfxCrackle(n, span, vol, delay){ for(let i = 0; i < n; i++) sfxNoise(0.025 + Math.random() * 0.04, "highpass", 3500 + Math.random() * 3000, 0, vol, (delay || 0) + Math.random() * span); }
function sfxThunder(delay, k){   // رعدِ واقعی: ترقِ تیز ← غرش‌های پی‌درپی ← باسِ عمیق
    const d = delay || 0; k = k || 1;
    sfxNoise(0.05, "highpass", 3200, 1500, 0.12 * k, d);
    sfxNoise(0.2, "bandpass", 2600, 500, 0.09 * k, d + 0.01);
    sfxVoice(46, 1.3 * k, "sine", 0.17 * k, { from: 120, glide: 0.35, delay: d + 0.02, a: 0.01 });
    sfxNoise(1.5, "lowpass", 430, 70, 0.1 * k, d + 0.06);
    sfxNoise(0.9, "lowpass", 300, 60, 0.065 * k, d + 0.5);
    sfxNoise(0.6, "lowpass", 240, 50, 0.045 * k, d + 1.0);
}
function sfxImpact(delay, k){ k = k || 1; sfxVoice(46, 0.5, "sine", 0.13 * k, { from: 140, glide: 0.2, delay }); sfxNoise(0.35, "lowpass", 2600, 200, 0.08 * k, delay); sfxCrackle(3, 0.25, 0.02 * k, delay + 0.05); }
function sfxWhistle(delay, dur){ sfxNoise(dur, "bandpass", 3200, 700, 0.045, delay); sfxVoice(380, dur, "sine", 0.035, { from: 1900, glide: dur * 0.9, delay }); }
const START_SFX_V8 = {
    flash(sh){            // ۵۰ الماس: کلیکِ فلاش دوربین + «تینگ» درخشان
        sfxNoise(0.03, "highpass", 4000, 0, 0.08); sfxVoice(2200, 0.08, "square", 0.02);
        sfxVoice(1760, 0.5, "sine", 0.06, { from: 3520, glide: 0.12, delay: 0.03 }); sfxVoice(880, 0.6, "triangle", 0.04, { delay: 0.05 });
    },
    shock(sh){            // ۷۰ الماس: ضربه‌ی موج انفجاری
        setTimeout(() => shake(9 * sh, 0.4), 0);
        sfxVoice(35, 0.9, "sine", 0.16, { from: 140, glide: 0.25 }); sfxNoise(0.25, "lowpass", 3000, 200, 0.08);
        sfxVoice(90, 0.5, "triangle", 0.06, { from: 300, glide: 0.3, delay: 0.05 }); sfxNoise(0.5, "bandpass", 800, 2800, 0.04, 0.12);
        sfxNoise(0.4, "bandpass", 2500, 500, 0.03, 0.2); sfxVoice(220, 0.6, "triangle", 0.03, { from: 700, glide: 0.4, delay: 0.1 });
    },
    warp(sh){             // ۷۵ الماس: پرشِ ابرفضایی
        setTimeout(() => shake(6 * sh, 0.3), 0);
        sfxNoise(0.55, "bandpass", 200, 5200, 0.07); sfxVoice(2600, 0.55, "sawtooth", 0.03, { from: 180, glide: 0.5, lp: 3200 });
        sfxVoice(3200, 0.25, "sine", 0.03, { from: 1200, glide: 0.2, delay: 0.5 }); sfxNoise(0.3, "highpass", 6000, 9000, 0.02, 0.5);
        sfxVoice(1200, 0.5, "triangle", 0.02, { from: 300, glide: 0.45, delay: 0.1 }); sfxNoise(0.4, "bandpass", 800, 6000, 0.03, 0.15); sfxVoice(90, 0.8, "sine", 0.05, { from: 40, glide: 0.6, delay: 0.55 });
    },
    burst(sh){            // ۸۰ الماس: آتش‌بازی؛ سوت، ترکیدن، ترقه و زنگوله‌های ستاره‌ای
        setTimeout(() => shake(4 * sh, 0.25), 350);
        sfxVoice(2400, 0.35, "sine", 0.035, { from: 600, glide: 0.33 });
        sfxNoise(0.14, "bandpass", 1500, 300, 0.09, 0.35); sfxVoice(70, 0.3, "sine", 0.1, { from: 180, glide: 0.1, delay: 0.35 });
        sfxCrackle(9, 0.6, 0.02, 0.42); sfxArp([88, 91, 95, 100, 103], 0.07, "triangle", 0.035, 0.45, 0.4);
    },
    wave(sh){             // ۱۲۰ الماس: قطره و موج آب + آرپژ بلورین (باشکوه‌ترین صدای الماسی)
        setTimeout(() => shake(5 * sh, 0.9), 0);
        [0, 0.16, 0.34, 0.52, 0.74].forEach((d, i) => sfxVoice(520 + i * 90, 0.22, "sine", 0.06, { from: 220 + i * 40, glide: 0.07, delay: d }));
        sfxNoise(1.3, "lowpass", 900, 300, 0.035); sfxNoise(0.9, "bandpass", 1800, 4200, 0.02, 0.1);
        sfxArp([72, 76, 79, 84, 88, 91], 0.12, "triangle", 0.04, 0.55, 0.1); sfxVoice(110, 1.2, "sine", 0.04, { from: 220, glide: 1.0 });
        sfxNoise(0.7, "highpass", 6500, 9500, 0.012, 0.9);
        [0.08, 0.28, 0.46, 0.64, 0.86].forEach((d, i) => sfxVoice(900 + i * 140, 0.14, "sine", 0.03, { from: 400 + i * 60, glide: 0.05, delay: d }));   // حباب‌های ریز
        sfxArp([79, 84, 88, 91, 96], 0.1, "sine", 0.025, 0.6, 0.55); sfxNoise(0.5, "bandpass", 600, 2400, 0.025, 0.6);
    },
    portal(sh){           // ۲۵ هزار: گردابِ جادویی با آرپژ بالارونده و درخشش پایانی
        setTimeout(() => shake(8 * sh, 0.5), 0);
        sfxWhoosh(true, 0.9, 0.06); sfxNoise(1.2, "bandpass", 500, 3500, 0.035, 0.1);
        sfxArp([57, 64, 69, 76, 81, 88], 0.16, "sine", 0.045, 0.7, 0.15); sfxArp([69, 73, 76, 81], 0.16, "triangle", 0.03, 0.8, 0.35, { lp: 2800 });
        sfxVoice(110, 1.6, "sawtooth", 0.03, { from: 55, glide: 1.4, lp: 700 }); sfxCrackle(6, 0.9, 0.02, 0.4);
        sfxVoice(NOTE(93), 0.9, "sine", 0.035, { delay: 1.0 }); sfxVoice(NOTE(100), 1.1, "sine", 0.03, { delay: 1.05 });
        sfxArp([81, 84, 88, 93, 96, 100], 0.09, "triangle", 0.028, 0.5, 0.7); sfxCrackle(8, 1.1, 0.016, 0.6);
        sfxVoice(220, 1.4, "sine", 0.035, { from: 110, glide: 1.2, delay: 0.2 }); sfxNoise(0.9, "highpass", 5500, 9000, 0.018, 1.0);
    },
    bolt(sh){             // ۳۰ هزار: سه رعدِ واقعی هم‌زمان با سه صاعقه، وزوزِ برق و بارانِ جرقه
        [0.06, 0.36, 0.66].forEach((d, i) => setTimeout(() => shake((10 - i) * sh, 0.35), d * 1000));
        sfxThunder(0.06, 1.35); sfxThunder(0.36, 0.95); sfxThunder(0.66, 1.15);
        sfxVoice(120, 0.7, "sawtooth", 0.03, { lp: 1600 }); sfxVoice(3000, 0.12, "sine", 0.02, { from: 700, glide: 0.1, delay: 0.05 });
        sfxCrackle(16, 0.9, 0.014, 0.7);
        [0.06, 0.36, 0.66].forEach(d => { sfxVoice(1800, 0.09, "square", 0.015, { from: 5200, glide: 0.06, delay: d }); sfxNoise(0.25, "highpass", 5000, 2500, 0.05, d + 0.02); });   // زِرِ برقی هنگام هر صاعقه
        sfxCrackle(10, 1.2, 0.01, 1.0); sfxVoice(60, 1.2, "sawtooth", 0.02, { from: 40, glide: 1.0, lp: 300, delay: 0.7 });
    },
    meteor(sh){           // ۳۵ هزار: شش شهاب‌سنگ؛ سوتِ سقوط ← برخورد ← غرشِ انفجار و جرقه‌ی آتش
        setTimeout(() => shake(9 * sh, 0.9), 650);
        for(let i = 0; i < 6; i++){ sfxWhistle(i * 0.14, 0.62); sfxImpact(0.62 + i * 0.14, i === 5 ? 1.4 : 1); }
        sfxVoice(40, 1.5, "sine", 0.17, { from: 130, glide: 0.4, delay: 0.75 }); sfxNoise(1.4, "lowpass", 900, 70, 0.09, 0.75);
        sfxCrackle(14, 1.0, 0.016, 0.9);
    },
    void(sh){             // ۳۵ هزار: وزوزِ عمیقِ سیاهچاله، مکیدن، فروپاشی و انفجارِ شکسته با زنگوله‌های معکوس
        setTimeout(() => shake(8 * sh, 0.9), 0); setTimeout(() => shake(10 * sh, 0.5), 1150);
        sfxVoice(55, 1.4, "sawtooth", 0.05, { from: 35, glide: 1.2, lp: 260 }); sfxVoice(82.4, 1.4, "sawtooth", 0.03, { lp: 300 });
        sfxNoise(1.1, "lowpass", 4000, 120, 0.06); sfxVoice(1400, 1.1, "sine", 0.025, { from: 200, glide: 1.1 }); sfxNoise(1.0, "bandpass", 400, 1800, 0.02);
        sfxVoice(38, 1.4, "sine", 0.2, { from: 160, glide: 0.4, delay: 1.15 }); sfxNoise(1.3, "lowpass", 2500, 60, 0.1, 1.15);
        sfxArp([96, 93, 89, 84, 79, 72], 0.07, "sine", 0.03, 0.7, 1.2); sfxNoise(0.9, "bandpass", 5000, 300, 0.05, 1.2);
        [0, 0.35, 0.65, 0.9].forEach(d => sfxVoice(46, 0.25, "sine", 0.09, { from: 95, glide: 0.1, delay: d }));          // ضربانِ قلبِ سیاهچاله
        sfxArp([43, 50, 55, 62], 0.1, "sine", 0.03, 1.0, 0.1); sfxVoice(61.5, 1.3, "sawtooth", 0.02, { from: 40, glide: 1.1, lp: 240 });
        sfxNoise(1.0, "bandpass", 300, 4000, 0.03, 0.1); sfxCrackle(10, 0.7, 0.014, 1.25); sfxArp([84, 79, 76, 72], 0.12, "triangle", 0.02, 0.8, 1.45);
        sfxArp([67, 74, 79, 86], 0.15, "sine", 0.018, 0.9, 0.3); sfxArp([91, 86, 83, 79, 74], 0.1, "sine", 0.02, 0.6, 1.3); sfxNoise(0.6, "bandpass", 1500, 300, 0.03, 1.7);
    },
    royal(sh){            // VIP: فانفار سلطنتی با هارمونی برنجی، تیمپانی و زنگوله‌های طلایی
        setTimeout(() => shake(10 * sh, 0.45), 0); setTimeout(() => shake(8 * sh, 0.4), 560);
        [60, 64, 67].forEach(n => sfxVoice(NOTE(n), 0.4, "sawtooth", 0.032, { lp: 1500 }));
        [62, 67, 71].forEach(n => sfxVoice(NOTE(n), 0.4, "sawtooth", 0.032, { lp: 1600, delay: 0.28 }));
        [64, 67, 72, 76].forEach(n => sfxVoice(NOTE(n), 1.1, "sawtooth", 0.034, { lp: 1900, delay: 0.56 }));
        [0, 0.56, 0.9].forEach(d => { sfxVoice(52, 0.4, "sine", 0.12, { from: 150, glide: 0.13, delay: d }); sfxNoise(0.1, "lowpass", 2200, 260, 0.05, d); });   // تیمپانی
        sfxArp([84, 88, 91, 96, 100], 0.08, "triangle", 0.035, 0.5, 0.6); sfxNoise(1.0, "highpass", 6000, 9000, 0.015, 0.5);
        sfxArp([48, 55, 60, 64, 67, 72, 76, 79, 84, 88, 91, 96], 0.045, "sine", 0.026, 0.6, 0.0);                               // گلیساندوی چنگ
        [55, 59, 62].forEach(n => sfxVoice(NOTE(n), 1.2, "sawtooth", 0.02, { lp: 1200, delay: 0.56 })); sfxNoise(0.8, "bandpass", 4000, 9000, 0.03, 0.56);   // هارمونیِ بم و سنج
        sfxCrackle(10, 0.9, 0.012, 0.7);
    }
};

/* صدا و لرزش شروعِ هر افکت ورود */
function cxStartSfx(key){
    const sh = data.shakeOn === false ? 0 : 1;
    try { if(START_SFX_V8[key]) START_SFX_V8[key](sh); } catch(e){}
}

/* ================================================================
   زمین‌های ویژه — نسخه‌ی پرجزئیات: لایه‌های دورتر (تپه، کوه، شهر…) پشت خط زمین،
   سایه‌روشن، ذرات و نور. (جایگزین نسخه‌های ساده‌تر قبلی)
   ================================================================ */
function cxRidge(c, w, baseY, amp, spd, sc0, fill, seed, peaky, rim){
    const pts = [];
    for(let x = -10; x <= w + 10; x += 6){
        const u = x + sc0 * spd; let y = Math.sin(u * 0.012 + seed) * 0.5 + Math.sin(u * 0.031 + seed * 2.1) * 0.3 + Math.sin(u * 0.07 + seed * 3.7) * 0.2;
        if(peaky) y = Math.abs(y) * 1.5 - 0.15;
        pts.push([x, baseY - amp * (0.5 + 0.5 * y)]);
    }
    c.fillStyle = fill; c.beginPath(); c.moveTo(-10, baseY); pts.forEach(p => c.lineTo(p[0], p[1])); c.lineTo(w + 10, baseY); c.closePath(); c.fill();
    if(rim){ c.strokeStyle = rim; c.lineWidth = 1.2; c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.stroke(); }
}
function cxStarsLow(c, w, y0, y1, t, n, col){
    for(let i = 0; i < n; i++){ const x = cxHash(i + 300) * w, y = y0 + cxHash(i + 330) * (y1 - y0), tw = 0.3 + 0.7 * Math.abs(Math.sin(t * (0.8 + (i % 4) * 0.4) + i)); c.fillStyle = col + (0.7 * tw).toFixed(3) + ")"; c.fillRect(x, y, 1.4, 1.4); }
}
/* نگه‌داری نسخه‌های اصلی برای ترکیب با لایه‌های جدید */
['lava','diamond','auroraland','ocean','cyber','milkyway','garden','glacier','mars','neongrid','clouds'].forEach(k => { GROUND_PAINT['_' + k + '0'] = GROUND_PAINT[k]; });
Object.assign(GROUND_PAINT, {
    horizon(c, w, h, gy, t, sc0, plus, gh, sc){
        const R = 30 * sc + 14, bx = w * 0.64, by = gy - R * 0.2, spin = t * 0.5;
        // سنگ‌های دور
        cxRidge(c, w, gy, 12 * sc, 0.06, sc0, "rgba(14,8,28,0.9)", 2.2, true, "rgba(150,100,255,0.35)");
        // هاله‌ی گرانشی
        c.save(); c.globalCompositeOperation = "lighter";
        const hg = c.createRadialGradient(bx, by, R * 0.8, bx, by, R * 4.2); hg.addColorStop(0, "rgba(255,150,70,0.28)"); hg.addColorStop(0.35, "rgba(170,90,255,0.16)"); hg.addColorStop(1, "rgba(80,40,200,0)"); c.fillStyle = hg; c.beginPath(); c.arc(bx, by, R * 4.2, 0, CX_TAU); c.fill();
        c.restore();
        // دیسک برافزایش — نیمه‌ی پشتی (بالای افق)
        const disc = (front) => { c.save(); c.translate(bx, by); c.rotate(-0.12); c.scale(1, 0.26); c.globalCompositeOperation = "lighter";
            for(let k = 0; k < 5; k++){ const r0 = R * (1.35 + k * 0.42), a = 0.62 - k * 0.1;
                const g = c.createLinearGradient(-r0, 0, r0, 0); g.addColorStop(0, "rgba(255,240,200," + a.toFixed(3) + ")"); g.addColorStop(0.5, "rgba(255,130,50," + (a * 0.65).toFixed(3) + ")"); g.addColorStop(1, "rgba(150,60,255," + (a * 0.45).toFixed(3) + ")");
                c.strokeStyle = g; c.lineWidth = R * (0.34 - k * 0.04); c.beginPath(); c.arc(0, 0, r0, front ? 0 : Math.PI, front ? Math.PI : CX_TAU); c.stroke(); }
            c.restore(); };
        disc(false);
        // حلقه‌ی لنز گرانشی بالای سیاهچاله
        c.save(); c.globalCompositeOperation = "lighter"; c.strokeStyle = "rgba(255,210,150,0.65)"; c.lineWidth = Math.max(1.5, R * 0.07); c.beginPath(); c.arc(bx, by, R * 1.12, Math.PI * 1.05, Math.PI * 1.95); c.stroke();
        c.strokeStyle = "rgba(200,160,255,0.35)"; c.lineWidth = Math.max(1, R * 0.04); c.beginPath(); c.arc(bx, by, R * 1.32, Math.PI * 1.1, Math.PI * 1.9); c.stroke(); c.restore();
        // افق رویداد
        const bg = c.createRadialGradient(bx, by, R * 0.2, bx, by, R * 1.02); bg.addColorStop(0, "#000"); bg.addColorStop(0.85, "#000"); bg.addColorStop(1, "rgba(0,0,0,0.9)"); c.fillStyle = bg; c.beginPath(); c.arc(bx, by, R, 0, CX_TAU); c.fill();
        c.save(); c.globalCompositeOperation = "lighter"; c.strokeStyle = "rgba(255,230,190,0.9)"; c.lineWidth = Math.max(1.2, R * 0.05); c.beginPath(); c.arc(bx, by, R * 1.02, 0, CX_TAU); c.stroke(); c.restore();
        disc(true);
        // ذراتی که به درون مارپیچ می‌شوند
        c.save(); c.globalCompositeOperation = "lighter";
        for(let i = 0; i < (plus ? 26 : 16); i++){ const ph = ((t * 0.18 + i * 0.0625) % 1), rr = R * (5 - ph * 4.2), a = ph * 6.4 + i * 1.7 + spin; const px = bx + Math.cos(a) * rr * 1.25, py = by + Math.sin(a) * rr * 0.34;
            c.fillStyle = (i % 3 ? "rgba(255,170,90," : "rgba(190,150,255,") + (0.85 * Math.sin(ph * Math.PI)).toFixed(3) + ")"; c.beginPath(); c.arc(px, py, 1.1 + (1 - ph) * 1.2, 0, CX_TAU); c.fill(); }
        c.restore();
        // سطح: بازتاب نور و صخره‌ها
        c.save(); cxClipGround(c, w, gy, gh);
        const rg = c.createRadialGradient(bx, gy, 4, bx, gy, R * 4.5); rg.addColorStop(0, "rgba(255,150,80,0.40)"); rg.addColorStop(0.5, "rgba(150,90,255,0.18)"); rg.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = rg; c.fillRect(0, gy, w, gh);
        for(let i = 0; i < 6; i++){ const x = cxMod(i * 83 - sc0 * (0.5 + (i % 3) * 0.3), w + 70) - 35, bw = 14 + cxHash(i) * 26, bh = 6 + cxHash(i + 9) * 12, y = gy + gh * (0.22 + (i % 3) * 0.22);
            c.fillStyle = "#07040f"; c.beginPath(); c.moveTo(x - bw, y + bh * 0.4); c.lineTo(x - bw * 0.5, y - bh); c.lineTo(x + bw * 0.1, y - bh * 0.6); c.lineTo(x + bw * 0.7, y - bh * 0.9); c.lineTo(x + bw, y + bh * 0.4); c.closePath(); c.fill();
            c.strokeStyle = "rgba(255,170,110,0.45)"; c.lineWidth = 1; c.beginPath(); c.moveTo(x - bw * 0.5, y - bh); c.lineTo(x + bw * 0.1, y - bh * 0.6); c.stroke(); }
        c.fillStyle = "rgba(190,150,255,0.5)"; for(let i = 0; i < 26; i++){ const x = cxMod(cxHash(i) * (w + 30) - sc0 * 0.35, w + 30) - 15, y = gy + 3 + cxHash(i + 50) * (gh - 6); c.fillRect(x, y, 1.3, 1.3); }
        c.restore();
    },
    lava(c, w, h, gy, t, sc0, plus, gh, sc){
        // آتشفشان‌های دور با دود و درخشش دهانه
        for(let L = 0; L < 2; L++){ const sp = L ? 0.1 : 0.05, col = L ? "rgba(40,12,6,0.95)" : "rgba(60,22,10,0.85)";
            for(let i = 0; i < 3; i++){ const bx = cxMod(i * (w / 2.3) + L * 60 - sc0 * sp, w + 260) - 130, ph = (34 + L * 16) * sc, bw = ph * 2.4, by = gy;
                c.fillStyle = col; c.beginPath(); c.moveTo(bx - bw, by); c.lineTo(bx - bw * 0.16, by - ph); c.lineTo(bx + bw * 0.16, by - ph); c.lineTo(bx + bw, by); c.closePath(); c.fill();
                c.save(); c.globalCompositeOperation = "lighter"; const cg = c.createRadialGradient(bx, by - ph, 0, bx, by - ph, ph * 0.9); cg.addColorStop(0, "rgba(255,170,60,0.75)"); cg.addColorStop(1, "rgba(255,80,20,0)"); c.fillStyle = cg; c.beginPath(); c.arc(bx, by - ph, ph * 0.9, 0, CX_TAU); c.fill();
                c.strokeStyle = "rgba(255,150,50,0.55)"; c.lineWidth = 1.3; c.beginPath(); c.moveTo(bx - bw * 0.12, by - ph + 2); c.lineTo(bx - bw * 0.35, by - ph * 0.35); c.moveTo(bx + bw * 0.1, by - ph + 2); c.lineTo(bx + bw * 0.4, by - ph * 0.3); c.stroke(); c.restore();
                for(let k = 0; k < 5; k++){ const ph2 = ((t * 0.12 + k * 0.2 + i * 0.13) % 1); c.fillStyle = "rgba(70,55,52," + (0.30 * Math.sin(ph2 * Math.PI)).toFixed(3) + ")"; c.beginPath(); c.arc(bx + Math.sin(ph2 * 4 + k) * 8 * sc + ph2 * 14, by - ph - ph2 * 40 * sc, (5 + ph2 * 12) * sc, 0, CX_TAU); c.fill(); } } }
        GROUND_PAINT._lava0(c, w, h, gy, t, sc0, plus, gh, sc);
        c.save(); c.globalCompositeOperation = "lighter"; for(let i = 0; i < (plus ? 24 : 14); i++){ const x = cxMod(i * 41 - t * (14 + i % 5 * 4) , w + 20) - 10, y = cxMod(i * 67 + t * (30 + i % 4 * 9), gy + gh); c.fillStyle = "rgba(255,160,70," + (0.5 * Math.abs(Math.sin(t + i))).toFixed(3) + ")"; c.fillRect(x, y * 0.6, 1.5, 1.5); } c.restore();
    },
    diamond(c, w, h, gy, t, sc0, plus, gh, sc){
        // خوشه‌های کریستال دور
        for(let L = 0; L < 2; L++){ for(let i = 0; i < 5; i++){ const bx = cxMod(i * (w / 4) + L * 40 - sc0 * (L ? 0.28 : 0.14), w + 160) - 80, ch = (22 + cxHash(i + L * 7) * 28 + L * 10) * sc;
            for(let k = -1; k <= 1; k++){ const cw = ch * 0.22 * (k === 0 ? 1.2 : 0.85), cx0 = bx + k * cw * 1.5, hh = ch * (k === 0 ? 1 : 0.7 + cxHash(i + k) * 0.2), lean = k * 0.12;
                const g = c.createLinearGradient(cx0 - cw, 0, cx0 + cw, 0); g.addColorStop(0, L ? "rgba(70,120,190,0.8)" : "rgba(40,80,140,0.75)"); g.addColorStop(0.5, L ? "rgba(190,235,255,0.85)" : "rgba(130,190,240,0.75)"); g.addColorStop(1, L ? "rgba(60,100,170,0.8)" : "rgba(30,60,120,0.75)");
                c.fillStyle = g; c.beginPath(); c.moveTo(cx0 - cw, gy); c.lineTo(cx0 - cw * 0.7 + lean * hh, gy - hh * 0.8); c.lineTo(cx0 + lean * hh, gy - hh); c.lineTo(cx0 + cw * 0.7 + lean * hh, gy - hh * 0.8); c.lineTo(cx0 + cw, gy); c.closePath(); c.fill();
                c.strokeStyle = "rgba(255,255,255,0.5)"; c.lineWidth = 0.9; c.beginPath(); c.moveTo(cx0, gy); c.lineTo(cx0 + lean * hh, gy - hh); c.moveTo(cx0 - cw * 0.7 + lean * hh, gy - hh * 0.8); c.lineTo(cx0 + cw * 0.7 + lean * hh, gy - hh * 0.8); c.stroke(); } } }
        GROUND_PAINT._diamond0(c, w, h, gy, t, sc0, plus, gh, sc);
        // پرتوهای رنگین‌کمانیِ شکست نور
        c.save(); c.globalCompositeOperation = "lighter"; for(let i = 0; i < 4; i++){ const x = cxMod(i * (w / 3) + Math.sin(t * 0.4 + i) * 18 - sc0 * 0.2, w + 80) - 40, hue = (t * 40 + i * 70) % 360;
            const g = c.createLinearGradient(x, gy - 40 * sc, x + 30, gy + gh); g.addColorStop(0, "hsla(" + hue + ",90%,70%,0)"); g.addColorStop(0.4, "hsla(" + hue + ",90%,70%,0.16)"); g.addColorStop(1, "hsla(" + hue + ",90%,70%,0)"); c.fillStyle = g; c.beginPath(); c.moveTo(x, gy - 40 * sc); c.lineTo(x + 16, gy - 40 * sc); c.lineTo(x + 60, gy + gh); c.lineTo(x + 24, gy + gh); c.closePath(); c.fill(); } c.restore();
    },
    auroraland(c, w, h, gy, t, sc0, plus, gh, sc){
        cxStarsLow(c, w, gy - 70 * sc, gy - 8, t, 18, "rgba(210,255,240,");
        // کوه‌های برفی دو لایه
        cxRidge(c, w, gy, 52 * sc, 0.06, sc0, "rgba(14,52,60,0.9)", 1.1, true, "rgba(210,255,245,0.55)");
        cxRidge(c, w, gy, 34 * sc, 0.14, sc0, "rgba(8,32,40,0.95)", 3.4, true, "rgba(190,255,235,0.45)");
        // درخشش شفق بالای کوه‌ها
        c.save(); c.globalCompositeOperation = "lighter"; for(let i = 0; i < 3; i++){ const g = c.createLinearGradient(0, gy - 90 * sc, 0, gy - 10); const hue = 135 + i * 25 + Math.sin(t * 0.3 + i) * 15; g.addColorStop(0, "hsla(" + hue + ",85%,60%,0)"); g.addColorStop(1, "hsla(" + hue + ",85%,60%,0.16)"); c.fillStyle = g; c.fillRect(0, gy - 90 * sc, w, 90 * sc); } c.restore();
        // درخت‌های کاج روی خط زمین
        for(let i = 0; i < 12; i++){ const x = cxMod(i * 46 + 10 - sc0 * 0.9, w + 60) - 30, th = (14 + cxHash(i) * 14) * sc;
            c.fillStyle = "#04161a"; c.beginPath(); c.moveTo(x - th * 0.32, gy); c.lineTo(x, gy - th); c.lineTo(x + th * 0.32, gy); c.closePath(); c.fill(); c.beginPath(); c.moveTo(x - th * 0.26, gy - th * 0.35); c.lineTo(x, gy - th * 1.1); c.lineTo(x + th * 0.26, gy - th * 0.35); c.closePath(); c.fill();
            c.strokeStyle = "rgba(180,255,230,0.35)"; c.lineWidth = 0.8; c.beginPath(); c.moveTo(x, gy - th); c.lineTo(x - th * 0.28, gy); c.stroke(); }
        GROUND_PAINT._auroraland0(c, w, h, gy, t, sc0, plus, gh, sc);
        c.save(); cxClipGround(c, w, gy, gh); c.globalCompositeOperation = "lighter"; for(let i = 0; i < 4; i++){ const y = gy + 6 + i * gh / 4.5, g = c.createLinearGradient(0, y, w, y); g.addColorStop(0, "rgba(120,255,210,0)"); g.addColorStop(0.5 + Math.sin(t * 0.5 + i) * 0.2, "rgba(150,255,225,0.22)"); g.addColorStop(1, "rgba(120,255,210,0)"); c.fillStyle = g; c.fillRect(0, y, w, 2.2); } c.restore();
    },
    ocean(c, w, h, gy, t, sc0, plus, gh, sc){
        // خط افق درخشان و جزیره‌های دور با فانوس دریایی
        const hg = c.createLinearGradient(0, gy - 20 * sc, 0, gy); hg.addColorStop(0, "rgba(120,230,255,0)"); hg.addColorStop(1, "rgba(120,230,255,0.28)"); c.fillStyle = hg; c.fillRect(0, gy - 20 * sc, w, 20 * sc);
        cxRidge(c, w, gy, 16 * sc, 0.05, sc0, "rgba(6,34,60,0.9)", 4.1, false);
        const lx = cxMod(w * 0.7 - sc0 * 0.05, w + 80) - 40;
        c.fillStyle = "rgba(10,40,70,0.95)"; c.fillRect(lx - 2.5, gy - 30 * sc, 5, 30 * sc); c.fillStyle = "rgba(255,255,255,0.9)"; c.fillRect(lx - 3.5, gy - 33 * sc, 7, 4 * sc);
        c.save(); c.globalCompositeOperation = "lighter"; const bm = Math.sin(t * 1.4), ex = lx + bm * 120, bg2 = c.createLinearGradient(lx, 0, ex, 0); bg2.addColorStop(0, "rgba(255,245,200,0.45)"); bg2.addColorStop(1, "rgba(255,245,200,0)"); c.fillStyle = bg2; c.beginPath(); c.moveTo(lx, gy - 31 * sc); c.lineTo(ex, gy - 31 * sc - 9 * sc); c.lineTo(ex, gy - 31 * sc + 9 * sc); c.closePath(); c.fill(); c.restore();
        GROUND_PAINT._ocean0(c, w, h, gy, t, sc0, plus, gh, sc);
        // کف موج و پلانکتون نورانی
        c.save(); cxClipGround(c, w, gy, gh); c.fillStyle = "rgba(255,255,255,0.35)"; for(let i = 0; i < 9; i++){ const x = cxMod(i * 53 - sc0 * (0.6 + (i % 3) * 0.2), w + 40) - 20, y = gy + gh * (0.2 + (i % 4) * 0.2) + Math.sin(t * 2 + i) * 2; c.beginPath(); c.ellipse(x, y, 9 + (i % 3) * 5, 1.6, 0, 0, CX_TAU); c.fill(); }
        c.globalCompositeOperation = "lighter"; for(let i = 0; i < (plus ? 22 : 12); i++){ const x = cxMod(cxHash(i) * (w + 30) - sc0 * 0.3, w + 30) - 15, y = gy + 4 + cxHash(i + 20) * (gh - 8), a = 0.3 + 0.7 * Math.abs(Math.sin(t * 1.5 + i * 2)); c.fillStyle = "rgba(90,255,230," + (0.55 * a).toFixed(3) + ")"; c.beginPath(); c.arc(x, y, 1.6 * a + 0.5, 0, CX_TAU); c.fill(); } c.restore();
    },
    cyber(c, w, h, gy, t, sc0, plus, gh, sc){
        // لایه‌ی دور شهر + نئون‌ها + ترافیک هوایی
        for(let i = 0; i < 16; i++){ const bw = 14 + cxHash(i + 40) * 16, x = cxMod(i * 41 - sc0 * 0.18, w + 70) - 35, bh = (30 + cxHash(i + 41) * 56) * sc; c.fillStyle = "rgba(24,22,70,0.8)"; c.fillRect(x, gy - bh, bw, bh); c.fillStyle = "rgba(255,62,201,0.25)"; c.fillRect(x, gy - bh, bw, 1.4); }
        c.save(); c.globalCompositeOperation = "lighter"; for(let i = 0; i < 4; i++){ const y = gy - (34 + i * 22) * sc, x = ((t * (46 + i * 17) * (i % 2 ? -1 : 1) + i * 150) % (w + 80) + (w + 80)) % (w + 80) - 40, dir = i % 2 ? -1 : 1;
            c.fillStyle = "rgba(98,245,255,0.9)"; c.fillRect(x, y, 6 * dir, 1.8); c.fillStyle = "rgba(255,62,201,0.35)"; c.fillRect(x - 14 * dir, y + 0.4, 14 * dir, 1); } c.restore();
        GROUND_PAINT._cyber0(c, w, h, gy, t, sc0, plus, gh, sc);
        // آنتن‌های چشمک‌زن و تابلوهای نئون روی ساختمان‌های نزدیک
        for(let i = 0; i < 5; i++){ const x = cxMod(i * 87 + 20 - sc0 * 0.62, w + 60) - 30, ah = (60 + cxHash(i + 60) * 30) * sc; c.fillStyle = "rgba(150,170,220,0.6)"; c.fillRect(x, gy - ah - 12 * sc, 1.2, 12 * sc);
            c.globalCompositeOperation = "lighter"; c.fillStyle = Math.floor(t * 1.5 + i) % 2 ? "rgba(255,70,70,0.95)" : "rgba(255,70,70,0.25)"; c.beginPath(); c.arc(x + 0.6, gy - ah - 12 * sc, 1.6, 0, CX_TAU); c.fill();
            c.fillStyle = i % 2 ? "rgba(255,62,201,0.8)" : "rgba(98,245,255,0.8)"; c.fillRect(x - 5, gy - ah * 0.55, 3, 12); c.globalCompositeOperation = "source-over"; }
    },
    milkyway(c, w, h, gy, t, sc0, plus, gh, sc){
        // ابر‌های سحابی روی افق و تپه‌های کیهانی با نور لبه
        c.save(); c.globalCompositeOperation = "lighter"; [["170,90,255", 0.2], ["255,110,200", 0.6], ["90,150,255", 0.85]].forEach((n, i) => { const x = cxMod(w * n[1] - sc0 * 0.08, w + 200) - 100, g = c.createRadialGradient(x, gy - 8 * sc, 4, x, gy - 8 * sc, 90 * sc + 30); g.addColorStop(0, "rgba(" + n[0] + ",0.30)"); g.addColorStop(1, "rgba(" + n[0] + ",0)"); c.fillStyle = g; c.beginPath(); c.arc(x, gy - 8 * sc, 90 * sc + 30, 0, CX_TAU); c.fill(); }); c.restore();
        cxRidge(c, w, gy, 22 * sc, 0.1, sc0, "rgba(30,12,60,0.95)", 5.2, false, "rgba(230,150,255,0.6)");
        cxRidge(c, w, gy, 12 * sc, 0.25, sc0, "rgba(20,8,44,0.98)", 7.7, false, "rgba(150,170,255,0.55)");
        cxStarsLow(c, w, gy - 60 * sc, gy - 6, t, 16, "rgba(255,255,255,");
        GROUND_PAINT._milkyway0(c, w, h, gy, t, sc0, plus, gh, sc);
    },
    garden(c, w, h, gy, t, sc0, plus, gh, sc){
        // تپه‌ها و درخت‌های دور، کره‌ی نور
        cxRidge(c, w, gy, 26 * sc, 0.05, sc0, "rgba(40,110,80,0.55)", 1.9, false);
        cxRidge(c, w, gy, 16 * sc, 0.12, sc0, "rgba(34,96,60,0.8)", 4.4, false);
        for(let i = 0; i < 6; i++){ const x = cxMod(i * 90 + 25 - sc0 * 0.3, w + 100) - 50, th = (26 + cxHash(i) * 14) * sc; c.fillStyle = "rgba(60,40,30,0.9)"; c.fillRect(x - 1.8, gy - th * 0.55, 3.6, th * 0.55);
            const g = c.createRadialGradient(x - th * 0.12, gy - th * 0.9, 2, x, gy - th * 0.75, th * 0.5); g.addColorStop(0, "#7fd57f"); g.addColorStop(1, "#2a7a40"); c.fillStyle = g; c.beginPath(); c.arc(x, gy - th * 0.78, th * 0.42, 0, CX_TAU); c.fill();
            c.fillStyle = "rgba(255,182,217,0.9)"; for(let k = 0; k < 4; k++){ c.beginPath(); c.arc(x + Math.cos(k * 1.7 + i) * th * 0.25, gy - th * 0.8 + Math.sin(k * 2.3 + i) * th * 0.22, 1.5, 0, CX_TAU); c.fill(); } }
        GROUND_PAINT._garden0(c, w, h, gy, t, sc0, plus, gh, sc);
        // پروانه‌ها و کرم‌های شب‌تاب
        for(let i = 0; i < 4; i++){ const x = cxMod(w - (t * (22 + i * 6) + i * 120), w + 40) - 20, y = gy - (14 + i * 13) * sc + Math.sin(t * 3 + i * 2) * 8, fl = Math.abs(Math.sin(t * 14 + i)) , col = ["#ffd36b", "#ff9bdc", "#9fe8ff", "#c9a6ff"][i];
            c.fillStyle = col; c.beginPath(); c.ellipse(x - 2.2, y, 2.6 * (0.3 + fl), 3, -0.4, 0, CX_TAU); c.fill(); c.beginPath(); c.ellipse(x + 2.2, y, 2.6 * (0.3 + fl), 3, 0.4, 0, CX_TAU); c.fill(); }
        c.save(); c.globalCompositeOperation = "lighter"; for(let i = 0; i < (plus ? 14 : 8); i++){ const x = cxMod(i * 61 + Math.sin(t + i) * 12 - sc0 * 0.25, w + 20) - 10, y = gy - 6 - cxHash(i + 3) * 40 * sc, a = Math.abs(Math.sin(t * 1.3 + i * 2)); c.fillStyle = "rgba(210,255,150," + (0.8 * a).toFixed(3) + ")"; c.beginPath(); c.arc(x, y, 1.8, 0, CX_TAU); c.fill(); } c.restore();
    },
    glacier(c, w, h, gy, t, sc0, plus, gh, sc){
        cxRidge(c, w, gy, 48 * sc, 0.05, sc0, "rgba(140,190,235,0.7)", 2.8, true, "rgba(255,255,255,0.75)");
        cxRidge(c, w, gy, 28 * sc, 0.13, sc0, "rgba(100,160,215,0.85)", 5.9, true, "rgba(255,255,255,0.65)");
        c.save(); c.globalCompositeOperation = "lighter"; const ag = c.createLinearGradient(0, gy - 90 * sc, 0, gy); ag.addColorStop(0, "rgba(150,255,230,0)"); ag.addColorStop(1, "rgba(150,255,230,0.14)"); c.fillStyle = ag; c.fillRect(0, gy - 90 * sc, w, 90 * sc); c.restore();
        GROUND_PAINT._glacier0(c, w, h, gy, t, sc0, plus, gh, sc);
        c.fillStyle = "rgba(255,255,255,0.85)"; for(let i = 0; i < (plus ? 26 : 16); i++){ const x = cxMod(w - (t * (40 + i % 5 * 9) + i * 41), w + 20), y = gy - 70 * sc + cxMod(i * 29 + t * 22, 70 * sc + gh * 0.5); c.beginPath(); c.arc(x, y, 0.9 + (i % 3) * 0.5, 0, CX_TAU); c.fill(); }
    },
    mars(c, w, h, gy, t, sc0, plus, gh, sc){
        // دو قمر کوچک و مِسای‌های دور
        c.fillStyle = "rgba(210,190,170,0.9)"; c.beginPath(); c.arc(w * 0.22, gy - 62 * sc, 5 * sc + 1, 0, CX_TAU); c.fill(); c.fillStyle = "rgba(190,170,150,0.9)"; c.beginPath(); c.arc(w * 0.36, gy - 78 * sc, 3 * sc + 1, 0, CX_TAU); c.fill();
        for(let i = 0; i < 5; i++){ const bx = cxMod(i * (w / 3.2) - sc0 * 0.07, w + 200) - 100, mw = (50 + cxHash(i) * 40) * sc, mh = (14 + cxHash(i + 5) * 14) * sc; c.fillStyle = "rgba(150,70,40,0.75)"; c.beginPath(); c.moveTo(bx - mw, gy); c.lineTo(bx - mw * 0.8, gy - mh); c.lineTo(bx + mw * 0.8, gy - mh); c.lineTo(bx + mw, gy); c.closePath(); c.fill(); c.fillStyle = "rgba(255,170,120,0.25)"; c.fillRect(bx - mw * 0.8, gy - mh, mw * 1.6, 2); }
        cxRidge(c, w, gy, 14 * sc, 0.2, sc0, "rgba(120,50,28,0.9)", 3.3, false);
        GROUND_PAINT._mars0(c, w, h, gy, t, sc0, plus, gh, sc);
        // گردباد غبار
        const dx = cxMod(w * 0.75 - sc0 * 0.3, w + 80) - 40; c.save(); c.fillStyle = "rgba(220,150,110,0.22)"; for(let k = 0; k < 9; k++){ const yy = gy - k * 5.5 * sc, ww = (3 + k * 1.6) * sc + Math.sin(t * 4 + k) * 1.5; c.beginPath(); c.ellipse(dx + Math.sin(t * 2 + k * 0.7) * 3, yy, ww, 2 * sc + 0.5, 0, 0, CX_TAU); c.fill(); } c.restore();
    },
    neongrid(c, w, h, gy, t, sc0, plus, gh, sc){
        // خورشید سینتی‌ویو با شکاف‌ها و کوه‌های سیم‌کشی‌شده
        const sx = w * 0.5, sr = 38 * sc + 12, sy = gy - sr * 0.28;
        c.save(); c.globalCompositeOperation = "lighter"; const sg = c.createRadialGradient(sx, sy, sr * 0.3, sx, sy, sr * 2.2); sg.addColorStop(0, "rgba(255,90,170,0.35)"); sg.addColorStop(1, "rgba(255,90,170,0)"); c.fillStyle = sg; c.beginPath(); c.arc(sx, sy, sr * 2.2, 0, CX_TAU); c.fill(); c.restore();
        c.save(); c.beginPath(); c.rect(0, gy - sr * 1.5, w, sr * 1.5); c.clip(); const g = c.createLinearGradient(0, sy - sr, 0, sy + sr); g.addColorStop(0, "#ffe45e"); g.addColorStop(0.55, "#ff5ea8"); g.addColorStop(1, "#b32cff"); c.fillStyle = g; c.beginPath(); c.arc(sx, sy, sr, 0, CX_TAU); c.fill();
        c.fillStyle = "#14052e"; for(let k = 0; k < 6; k++){ c.fillRect(sx - sr, sy - sr * 0.1 + k * sr * 0.2, sr * 2, 1 + k * 0.9); } c.restore();
        c.strokeStyle = "rgba(98,245,255,0.7)"; c.lineWidth = 1.2; c.beginPath(); const mp = []; for(let x = -10; x <= w + 10; x += 14){ const u = x + sc0 * 0.12, y = gy - 6 - Math.abs(Math.sin(u * 0.02) * 26 + Math.sin(u * 0.05 + 1) * 10) * sc; mp.push([x, y]); } mp.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.stroke();
        c.strokeStyle = "rgba(255,62,201,0.35)"; c.beginPath(); mp.forEach((p, i) => { c.moveTo(p[0], p[1]); c.lineTo(p[0], gy); }); c.stroke();
        GROUND_PAINT._neongrid0(c, w, h, gy, t, sc0, plus, gh, sc);
    },
    clouds(c, w, h, gy, t, sc0, plus, gh, sc){
        // لایه‌های ابر دور، پرتوهای نور و پرندگان
        for(let L = 0; L < 3; L++){ c.fillStyle = "rgba(255,255,255," + (0.16 + L * 0.08) + ")"; for(let i = 0; i < 6; i++){ const x = cxMod(i * 90 + L * 33 - sc0 * (0.08 + L * 0.07), w + 160) - 80, y = gy - (14 + L * 14) * sc, r = (12 + cxHash(i + L * 9) * 12) * sc;
            c.beginPath(); c.moveTo(x + r, y); c.arc(x, y, r, 0, CX_TAU); c.moveTo(x + r * 1.9, y + 2); c.arc(x + r * 1.1, y + 2, r * 0.8, 0, CX_TAU); c.moveTo(x - r * 0.3, y + 3); c.arc(x - r * 1.1, y + 3, r * 0.7, 0, CX_TAU); c.fill(); } }
        c.save(); c.globalCompositeOperation = "lighter"; for(let i = 0; i < 5; i++){ const x = i * w / 4 + Math.sin(t * 0.4 + i) * 14, g = c.createLinearGradient(x, gy - 90 * sc, x - 30, gy); g.addColorStop(0, "rgba(255,240,180,0.20)"); g.addColorStop(1, "rgba(255,240,180,0)"); c.fillStyle = g; c.beginPath(); c.moveTo(x - 6, gy - 90 * sc); c.lineTo(x + 8, gy - 90 * sc); c.lineTo(x - 18, gy); c.lineTo(x - 52, gy); c.closePath(); c.fill(); } c.restore();
        c.strokeStyle = "rgba(60,80,120,0.7)"; c.lineWidth = 1.2; for(let i = 0; i < 4; i++){ const x = cxMod(w - (t * (26 + i * 5) + i * 110), w + 40) - 20, y = gy - (50 + i * 11) * sc + Math.sin(t * 2 + i) * 3, fl = Math.sin(t * 9 + i * 2) * 3; c.beginPath(); c.moveTo(x - 6, y + fl); c.quadraticCurveTo(x - 3, y - 2, x, y); c.quadraticCurveTo(x + 3, y - 2, x + 6, y + fl); c.stroke(); }
        GROUND_PAINT._clouds0(c, w, h, gy, t, sc0, plus, gh, sc);
    },
});
/* ================================================================
   دکور فضایی: آیتم‌های پس‌زمینه‌ی بازی (سیاره، ایستگاه، ماهواره، سحابی، مه، ...)
   هر آیتم جای مخصوص خودش را دارد و آیتم‌ها هرگز روی هم نمی‌افتند.
   ================================================================ */
const DECOR_KEYS = ["mistTop","mistLow","galaxy","nebula","redplanet","ringed","station","satellite","comet","sun"];
const DECOR_OBJECTS = ["galaxy","nebula","redplanet","ringed","station","satellite","comet","sun"];
/* ================================================================
   سامانه‌ی آسمانِ نسخه‌ی ۸.۰
   سه سیاره‌ی پایه و همه‌ی دکورها یک‌جا و با «عمق» مدیریت می‌شوند:
   • همه از راست به چپ می‌روند (سفینه از چپ به راست می‌دود) و هر کدام سرعت خودش را دارد؛
   • دورتر = کندتر، نزدیک‌تر = سریع‌تر (دنباله‌دار از زحل خیلی سریع‌تر است)؛
   • ترتیب رسم بر اساس عمق است؛ پس هیچ دکوری پشت سیاره‌های پایه پنهان نمی‌شود.
   period: چند ثانیه طول می‌کشد تا جسم یک‌بار از لبه‌ی راست تا لبه‌ی چپ برسد. z: عمق (کم = دورتر). lane: ارتفاع. size: اندازه (نسبت به u)
   ================================================================ */
const SKY = {
    sun:       { z: 1.0, period: 640, lane: 0.30, size: 0.19,  ph: 0.62 },
    galaxy:    { z: 1.2, period: 560, lane: 0.24, size: 0.34,  ph: 0.40 },
    nebula:    { z: 1.5, period: 440, lane: 0.42, size: 0.30,  ph: 0.88 },
    ringed:    { z: 3.4, period: 170, lane: 0.17, size: 0.15,  ph: 0.80 },
    redplanet: { z: 3.6, period: 120, lane: 0.47, size: 0.125, ph: 0.35 },
    station:   { z: 5.0, period: 66,  lane: 0.36, size: 0.14,  ph: 0.12 },
    satellite: { z: 5.5, period: 40,  lane: 0.56, size: 0.064, ph: 0.55 },
    comet:     { z: 6.0, period: 26,  lane: 0.60, size: 0.052, ph: 0.02 }
};
const SKY_PLANET_PERIOD = [112, 168, 236];   // سه سیاره‌ی پایه: بزرگ‌تر = نزدیک‌تر = سریع‌تر
function decorUnit(w, gy){ return Math.min(w * 0.95, gy * 1.05); }
function skyExtents(key, r){   // [چپ, راست]: فاصله‌ی لازم تا جسم کاملاً از صفحه خارج شود
    if(key === "comet") return [r * 9.5, r * 1.8];
    if(key === "ringed") return [r * 3.6, r * 3.6];
    if(key === "sun") return [r * 3.2, r * 3.2];
    if(key === "station") return [r * 2.6, r * 2.6];
    if(key === "satellite") return [r * 2.4, r * 2.4];
    return [r * 1.3, r * 1.3];
}
function skyPos(key, w, gy, tms){
    const S = SKY[key] || { period: 100, lane: 0.3, size: 0.1, ph: 0 }, u = decorUnit(w, gy), r = u * S.size, ex = skyExtents(key, r), trav = w + ex[0] + ex[1];
    const k = ((tms / 1000 / S.period + S.ph) % 1 + 1) % 1;
    let x = w + ex[1] - k * trav, y = gy * S.lane;
    if(key === "station") y += Math.sin(tms / 3300) * gy * 0.006;
    if(key === "satellite") y += Math.sin(tms / 4200) * gy * 0.01;
    if(key === "comet") y += k * gy * 0.07;
    return { x, y, r, u };
}
function decorLayout(key, w, gy, tms, pv){
    if(pv){   // پیش‌نمایش داخل کارت شخصی‌سازی
        const PVR = { galaxy: 0.42, nebula: 0.42, ringed: 0.18, redplanet: 0.19, station: 0.15, satellite: 0.10, comet: 0.07, sun: 0.26 }, r = gy * (PVR[key] || 0.2);
        let x = w * 0.5, y = gy * 0.46;
        if(key === "station"){ x = w * (1.2 - (((tms / 11000) % 1) * 1.4)); y = gy * 0.42; }
        if(key === "satellite"){ x = w * (1.15 - (((tms / 8000) % 1) * 1.3)); y = gy * 0.5; }
        if(key === "comet"){ const k = ((tms / 5200) % 1.3); x = w * (1.1 - k * 1.1); y = gy * (0.36 + k * 0.18); }
        return { x, y, r, u: Math.min(w, gy) };
    }
    return skyPos(key, w, gy, tms);
}
function decorActive(){
    const on = data.decorOn || {}, own = data.decorOwned || {};
    return DECOR_KEYS.filter(k => on[k] && own[k]);
}
function decorMistColors(){
    const tn = BIO_TONES[typeof gameMode !== "undefined" ? gameMode : "classic"] || BIO_TONES.classic;
    return { mist: tn[2][0], accent: tn[0][0], deep: tn[3][0] };
}
const DECOR_PAINT = {
    mistTop(c, w, gy, t, plus, o){
        const s = t / 1000, col = decorMistColors(), n = plus ? 7 : 5;
        c.save(); c.beginPath(); c.rect(0, 0, w, gy * 0.36); c.clip();
        for(let i = 0; i < n; i++){
            const bx = w * (((i * 0.21 + 0.1 - s * (0.0045 + (i % 3) * 0.0016)) % 1.4 + 1.4) % 1.4 - 0.2), by = gy * (0.05 + (i % 4) * 0.075) + Math.sin(s * 0.18 + i) * gy * 0.012;
            const rx = w * (0.34 + (i % 3) * 0.08), ry = gy * (0.07 + (i % 2) * 0.03), a = 0.17 + 0.07 * Math.sin(s * 0.3 + i * 1.7), cc = i % 2 ? col.mist : col.accent;
            c.save(); c.translate(bx, by); c.scale(1, ry / rx); const g = c.createRadialGradient(0, 0, 0, 0, 0, rx); g.addColorStop(0, "rgba(" + cc + "," + (a + 0.12).toFixed(3) + ")"); g.addColorStop(0.55, "rgba(" + cc + "," + (a * 0.55).toFixed(3) + ")"); g.addColorStop(1, "rgba(" + cc + ",0)");
            c.fillStyle = g; c.beginPath(); c.arc(0, 0, rx, 0, CX_TAU); c.fill(); c.restore();
        }
        c.restore();
    },
    mistLow(c, w, gy, t, plus, o){
        const s = t / 1000, col = decorMistColors(), n = plus ? 8 : 5;
        c.save(); c.beginPath(); c.rect(0, gy * 0.60, w, gy * 0.40); c.clip();
        for(let i = 0; i < n; i++){
            const bx = w * (((i * 0.19 + 0.05 - s * (0.0065 + (i % 3) * 0.0022)) % 1.5 + 1.5) % 1.5 - 0.25), by = gy * (0.74 + (i % 3) * 0.075) + Math.sin(s * 0.22 + i * 1.3) * gy * 0.01;
            const rx = w * (0.30 + (i % 3) * 0.09), ry = gy * (0.055 + (i % 2) * 0.025), a = 0.19 + 0.08 * Math.sin(s * 0.35 + i * 1.3);
            c.save(); c.translate(bx, by); c.scale(1, ry / rx); const g = c.createRadialGradient(0, 0, 0, 0, 0, rx); g.addColorStop(0, "rgba(" + col.mist + "," + (a + 0.10).toFixed(3) + ")"); g.addColorStop(0.6, "rgba(" + col.mist + "," + (a * 0.5).toFixed(3) + ")"); g.addColorStop(1, "rgba(" + col.mist + ",0)");
            c.fillStyle = g; c.beginPath(); c.arc(0, 0, rx, 0, CX_TAU); c.fill(); c.restore();
        }
        c.restore();
    },
    galaxy(c, w, gy, t, plus, o){
        const { x, y, r } = o, n = plus ? 150 : 90;
        c.save(); c.translate(x, y); c.rotate(-0.5); c.scale(1, 0.55);
        const halo = c.createRadialGradient(0, 0, 0, 0, 0, r); halo.addColorStop(0, "rgba(255,235,215,0.55)"); halo.addColorStop(0.22, "rgba(190,150,255,0.30)"); halo.addColorStop(0.6, "rgba(90,90,220,0.12)"); halo.addColorStop(1, "rgba(60,60,200,0)");
        c.fillStyle = halo; c.beginPath(); c.arc(0, 0, r, 0, CX_TAU); c.fill();
        c.rotate(t * 0.000035); c.globalCompositeOperation = "lighter";
        for(let i = 0; i < n; i++){
            const arm = i % 2, k = (i >> 1) / (n / 2), ang = k * 6.4 + arm * Math.PI + (cxHash(i) - 0.5) * 0.5, rad = r * (0.12 + k * 0.88) * (0.9 + cxHash(i + 31) * 0.2);
            const px = Math.cos(ang) * rad, py = Math.sin(ang) * rad, a = (1 - k * 0.6) * (0.45 + 0.4 * cxHash(i + 7));
            c.fillStyle = k < 0.35 ? "rgba(255,230,200," + a.toFixed(3) + ")" : (arm ? "rgba(150,170,255," + a.toFixed(3) + ")" : "rgba(220,170,255," + a.toFixed(3) + ")");
            c.beginPath(); c.arc(px, py, 0.8 + cxHash(i + 3) * 1.5 * (1 - k * 0.4), 0, CX_TAU); c.fill();
        }
        c.restore();
        c.save(); c.globalCompositeOperation = "lighter"; const core = c.createRadialGradient(x, y, 0, x, y, r * 0.3); core.addColorStop(0, "rgba(255,250,235,0.95)"); core.addColorStop(0.4, "rgba(255,215,170,0.45)"); core.addColorStop(1, "rgba(255,190,140,0)"); c.fillStyle = core; c.beginPath(); c.arc(x, y, r * 0.3, 0, CX_TAU); c.fill(); c.restore();
    },
    nebula(c, w, gy, t, plus, o){
        const { x, y, r } = o, s = t / 1000;
        c.save(); c.globalCompositeOperation = "lighter";
        const blobs = [[-0.30, -0.10, 0.62, "255,90,170", 0.46], [0.22, -0.18, 0.55, "120,90,255", 0.48], [0.05, 0.22, 0.6, "60,190,255", 0.40], [-0.15, 0.20, 0.42, "255,150,90", 0.30], [0.30, 0.15, 0.4, "130,255,210", 0.27], [0.0, 0.0, 0.5, "255,210,255", 0.27]];
        blobs.forEach((b, i) => { const bx = x + b[0] * r + Math.sin(s * 0.2 + i) * r * 0.03, by = y + b[1] * r + Math.cos(s * 0.17 + i * 1.4) * r * 0.03, br = r * b[2], pulse = 0.85 + 0.15 * Math.sin(s * 0.5 + i * 1.9);
            const g = c.createRadialGradient(bx, by, 0, bx, by, br); g.addColorStop(0, "rgba(" + b[3] + "," + (b[4] * pulse).toFixed(3) + ")"); g.addColorStop(0.55, "rgba(" + b[3] + "," + (b[4] * 0.45 * pulse).toFixed(3) + ")"); g.addColorStop(1, "rgba(" + b[3] + ",0)");
            c.fillStyle = g; c.beginPath(); c.arc(bx, by, br, 0, CX_TAU); c.fill(); });
        c.restore();
        c.save(); const dg = c.createRadialGradient(x - r * 0.05, y + r * 0.02, 0, x - r * 0.05, y + r * 0.02, r * 0.32); dg.addColorStop(0, "rgba(10,5,30,0.45)"); dg.addColorStop(1, "rgba(10,5,30,0)"); c.fillStyle = dg; c.beginPath(); c.ellipse(x - r * 0.05, y + r * 0.02, r * 0.4, r * 0.16, -0.4, 0, CX_TAU); c.fill(); c.restore();
        c.save(); c.globalCompositeOperation = "lighter"; for(let i = 0; i < (plus ? 26 : 16); i++){ const a = cxHash(i + 80) * CX_TAU, d = cxHash(i + 91) * r * 0.85, tw = 0.35 + 0.65 * Math.abs(Math.sin(s * 1.6 + i * 2.1)); c.fillStyle = "rgba(255,255,255," + (0.8 * tw).toFixed(3) + ")"; c.beginPath(); c.arc(x + Math.cos(a) * d, y + Math.sin(a) * d * 0.8, 0.5 + cxHash(i + 5) * 0.8, 0, CX_TAU); c.fill(); } c.restore();
    },
    redplanet(c, w, gy, t, plus, o){
        const { x, y, r } = o, s = t / 1000, oa = s * 0.55;
        // مدار و ماه (نیمه‌ی پشتی)
        const mx = x + Math.cos(oa) * r * 2.0, my = y + Math.sin(oa) * r * 0.62, back = Math.sin(oa) < 0;
        c.save(); c.strokeStyle = "rgba(255,200,170,0.18)"; c.lineWidth = 1; c.beginPath(); c.ellipse(x, y, r * 2.0, r * 0.62, 0, 0, CX_TAU); c.stroke(); c.restore();
        const drawMoon = () => { const mr = r * 0.2, mg = c.createRadialGradient(mx - mr * 0.35, my - mr * 0.35, mr * 0.1, mx, my, mr); mg.addColorStop(0, "#e9e4de"); mg.addColorStop(1, "#6d6862"); c.fillStyle = mg; c.beginPath(); c.arc(mx, my, mr, 0, CX_TAU); c.fill(); c.fillStyle = "rgba(60,55,50,0.4)"; c.beginPath(); c.arc(mx + mr * 0.25, my + mr * 0.1, mr * 0.22, 0, CX_TAU); c.fill(); };
        if(back) drawMoon();
        c.save(); c.globalCompositeOperation = "lighter"; const ag = c.createRadialGradient(x, y, r * 0.95, x, y, r * 1.5); ag.addColorStop(0, "rgba(255,120,70,0.28)"); ag.addColorStop(1, "rgba(255,120,70,0)"); c.fillStyle = ag; c.beginPath(); c.arc(x, y, r * 1.5, 0, CX_TAU); c.fill(); c.restore();
        c.save(); c.beginPath(); c.arc(x, y, r, 0, CX_TAU); c.clip();
        const g = c.createRadialGradient(x - r * 0.4, y - r * 0.4, r * 0.1, x, y, r); g.addColorStop(0, "#ffa064"); g.addColorStop(0.5, "#cf5a30"); g.addColorStop(1, "#4a160a"); c.fillStyle = g; c.fillRect(x - r, y - r, r * 2, r * 2);
        c.fillStyle = "rgba(110,30,15,0.38)"; [[-0.3, -0.1, 0.3, 0.1], [0.25, 0.25, 0.35, 0.12], [0.1, -0.45, 0.2, 0.07], [-0.1, 0.5, 0.28, 0.08]].forEach((q, i) => { c.beginPath(); c.ellipse(x + q[0] * r, y + q[1] * r, q[2] * r, q[3] * r, -0.3 + i * 0.2, 0, CX_TAU); c.fill(); });
        c.fillStyle = "rgba(60,15,8,0.5)"; [[0.2, -0.1, 0.1], [-0.35, 0.3, 0.13], [0.45, -0.3, 0.07]].forEach(q => { c.beginPath(); c.arc(x + q[0] * r, y + q[1] * r, q[2] * r, 0, CX_TAU); c.fill(); });
        c.fillStyle = "rgba(255,250,245,0.8)"; c.beginPath(); c.ellipse(x - r * 0.05, y - r * 0.92, r * 0.45, r * 0.16, 0, 0, CX_TAU); c.fill();
        const sd = c.createLinearGradient(x - r, y, x + r, y); sd.addColorStop(0, "rgba(0,0,0,0)"); sd.addColorStop(0.5, "rgba(0,0,0,0)"); sd.addColorStop(1, "rgba(15,0,0,0.65)"); c.fillStyle = sd; c.fillRect(x - r, y - r, r * 2, r * 2);
        c.restore();
        if(!back) drawMoon();
    },
    ringed(c, w, gy, t, plus, o){
        const { x, y, r } = o, tilt = -0.38;
        const ring = (front) => { c.save(); c.translate(x, y); c.rotate(tilt); c.scale(1, 0.3);
            [[2.05, 1.95, "rgba(230,205,160,0.7)", 5], [1.85, 1.62, "rgba(255,240,205,0.85)", 9], [1.5, 1.34, "rgba(200,175,135,0.6)", 6]].forEach(R => { c.strokeStyle = R[2]; c.lineWidth = R[3] * r * 0.09; c.beginPath(); if(front) c.arc(0, 0, R[0] * r * 0.92 - (R[0] - R[1]) * r * 0.2, 0, Math.PI); else c.arc(0, 0, R[0] * r * 0.92 - (R[0] - R[1]) * r * 0.2, Math.PI, CX_TAU); c.stroke(); });
            c.restore(); };
        ring(false);
        c.save(); c.beginPath(); c.arc(x, y, r, 0, CX_TAU); c.clip();
        const g = c.createRadialGradient(x - r * 0.4, y - r * 0.4, r * 0.1, x, y, r * 1.05); g.addColorStop(0, "#fff0c8"); g.addColorStop(0.55, "#d8a860"); g.addColorStop(1, "#6a4420"); c.fillStyle = g; c.fillRect(x - r, y - r, r * 2, r * 2);
        const bands = ["rgba(150,90,40,0.35)", "rgba(255,225,170,0.30)", "rgba(120,70,35,0.32)", "rgba(240,200,140,0.25)", "rgba(100,60,30,0.3)"]; bands.forEach((bc, i) => { c.fillStyle = bc; c.beginPath(); c.ellipse(x, y - r * 0.62 + i * r * 0.3, r * 1.1, r * 0.075, 0.1, 0, CX_TAU); c.fill(); });
        const sd = c.createLinearGradient(x - r, y - r * 0.2, x + r, y + r * 0.2); sd.addColorStop(0, "rgba(0,0,0,0)"); sd.addColorStop(0.5, "rgba(0,0,0,0)"); sd.addColorStop(1, "rgba(15,8,0,0.68)"); c.fillStyle = sd; c.fillRect(x - r, y - r, r * 2, r * 2);
        c.restore();
        ring(true);
    },
    station(c, w, gy, t, plus, o){
        const { x, y, r } = o, s = t / 1000, rot = Math.sin(s * 0.3) * 0.03;
        c.save(); c.translate(x, y); c.rotate(rot);
        const metal = (x0, y0, w0, h0, r0) => { const g = c.createLinearGradient(0, y0, 0, y0 + h0); g.addColorStop(0, "#eef2f8"); g.addColorStop(0.5, "#9aa6ba"); g.addColorStop(1, "#4a5568"); c.fillStyle = g; c.beginPath(); cxRR(c, x0, y0, w0, h0, r0); c.fill(); };
        // خرپا
        metal(-r * 1.9, -r * 0.045, r * 3.8, r * 0.09, r * 0.03);
        // پنل‌های خورشیدی
        [[-1.75, -1], [-1.15, -1], [0.62, -1], [1.22, -1]].forEach((p, i) => { const px = p[0] * r, up = (i % 2 === 0) ? -1 : 1; for(const sgn of [-1, 1]){ const py = sgn > 0 ? r * 0.06 : -r * 0.06 - r * 0.46;
            const pg = c.createLinearGradient(px, 0, px + r * 0.5, 0); pg.addColorStop(0, "#1c3f86"); pg.addColorStop(0.5, "#3f78d6"); pg.addColorStop(1, "#1c3f86"); c.fillStyle = pg; c.fillRect(px, py, r * 0.5, r * 0.4);
            c.strokeStyle = "rgba(190,215,255,0.45)"; c.lineWidth = 0.6; c.beginPath(); for(let k = 1; k < 4; k++){ c.moveTo(px + k * r * 0.125, py); c.lineTo(px + k * r * 0.125, py + r * 0.4); } for(let k = 1; k < 3; k++){ c.moveTo(px, py + k * r * 0.133); c.lineTo(px + r * 0.5, py + k * r * 0.133); } c.stroke(); } });
        // ماژول مرکزی
        metal(-r * 0.46, -r * 0.2, r * 0.92, r * 0.4, r * 0.1);
        metal(-r * 0.2, -r * 0.42, r * 0.4, r * 0.24, r * 0.06); metal(-r * 0.12, r * 0.18, r * 0.24, r * 0.3, r * 0.05);
        c.fillStyle = "#ffe9a8"; for(let k = 0; k < 4; k++){ c.fillRect(-r * 0.38 + k * r * 0.2, -r * 0.06, r * 0.1, r * 0.07); }
        c.fillStyle = "rgba(255,255,255,0.35)"; c.fillRect(-r * 0.44, -r * 0.17, r * 0.88, r * 0.03);
        // دیش و آنتن
        c.strokeStyle = "#cfd6e2"; c.lineWidth = Math.max(0.8, r * 0.025); c.beginPath(); c.moveTo(r * 0.0, -r * 0.42); c.lineTo(r * 0.0, -r * 0.62); c.stroke(); c.beginPath(); c.arc(r * 0.0, -r * 0.62, r * 0.1, Math.PI * 1.05, Math.PI * 1.95); c.stroke();
        // چراغ‌ها
        const blink = Math.floor(s * 1.6) % 2; c.globalCompositeOperation = "lighter"; c.fillStyle = blink ? "rgba(255,70,70,0.95)" : "rgba(255,70,70,0.25)"; c.beginPath(); c.arc(-r * 1.9, 0, Math.max(1.2, r * 0.05), 0, CX_TAU); c.fill(); c.fillStyle = blink ? "rgba(90,255,140,0.25)" : "rgba(90,255,140,0.95)"; c.beginPath(); c.arc(r * 1.9, 0, Math.max(1.2, r * 0.05), 0, CX_TAU); c.fill();
        c.restore();
    },
    satellite(c, w, gy, t, plus, o){
        const { x, y, r } = o, s = t / 1000, rot = Math.sin(s * 0.45) * 0.22 + 0.1;
        c.save(); c.translate(x, y); c.rotate(rot);
        const wing = (sgn) => { const x0 = sgn > 0 ? r * 0.55 : -r * 1.75, g = c.createLinearGradient(x0, 0, x0 + r * 1.2, 0); g.addColorStop(0, "#173a7c"); g.addColorStop(0.5, "#4a86e0"); g.addColorStop(1, "#173a7c"); c.fillStyle = g; c.fillRect(x0, -r * 0.45, r * 1.2, r * 0.9);
            c.strokeStyle = "rgba(200,222,255,0.5)"; c.lineWidth = 0.6; c.beginPath(); for(let k = 1; k < 4; k++){ c.moveTo(x0 + k * r * 0.3, -r * 0.45); c.lineTo(x0 + k * r * 0.3, r * 0.45); } for(let k = 1; k < 3; k++){ c.moveTo(x0, -r * 0.45 + k * r * 0.3); c.lineTo(x0 + r * 1.2, -r * 0.45 + k * r * 0.3); } c.stroke(); };
        c.strokeStyle = "#9aa6ba"; c.lineWidth = Math.max(1, r * 0.06); c.beginPath(); c.moveTo(-r * 0.58, 0); c.lineTo(r * 0.58, 0); c.stroke();
        wing(-1); wing(1);
        const bg = c.createLinearGradient(0, -r * 0.4, 0, r * 0.4); bg.addColorStop(0, "#ffe9a6"); bg.addColorStop(0.5, "#d9a93a"); bg.addColorStop(1, "#7a5614"); c.fillStyle = bg; c.beginPath(); cxRR(c, -r * 0.5, -r * 0.4, r, r * 0.8, r * 0.1); c.fill();
        c.fillStyle = "rgba(255,255,255,0.35)"; c.fillRect(-r * 0.46, -r * 0.34, r * 0.92, r * 0.1);
        c.fillStyle = "#cfd6e2"; c.beginPath(); c.arc(0, -r * 0.52, r * 0.26, Math.PI, CX_TAU); c.fill(); c.strokeStyle = "#cfd6e2"; c.lineWidth = Math.max(0.8, r * 0.05); c.beginPath(); c.moveTo(0, -r * 0.4); c.lineTo(0, -r * 0.62); c.stroke();
        c.globalCompositeOperation = "lighter"; c.fillStyle = Math.floor(s * 1.3) % 2 ? "rgba(255,70,70,0.95)" : "rgba(255,70,70,0.25)"; c.beginPath(); c.arc(r * 0.38, r * 0.3, Math.max(1.1, r * 0.07), 0, CX_TAU); c.fill();
        c.restore();
    },
    comet(c, w, gy, t, plus, o){
        const { x, y, r } = o, s = t / 1000, ang = -0.1;
        c.save(); c.translate(x, y); c.rotate(ang); c.globalCompositeOperation = "lighter";
        const L = r * 7.5;
        // دُم یونی (آبی، تقریباً مستقیم)
        let g = c.createLinearGradient(0, 0, L, 0); g.addColorStop(0, "rgba(170,225,255,0.85)"); g.addColorStop(0.4, "rgba(90,160,255,0.35)"); g.addColorStop(1, "rgba(60,110,255,0)");
        c.fillStyle = g; c.beginPath(); c.moveTo(0, -r * 0.28); c.quadraticCurveTo(L * 0.5, -r * 0.55 + Math.sin(s * 2) * r * 0.08, L, -r * 0.1); c.lineTo(L, r * 0.1); c.quadraticCurveTo(L * 0.5, r * 0.5 - Math.sin(s * 2) * r * 0.08, 0, r * 0.28); c.closePath(); c.fill();
        // دُم غبار (زردِ خمیده)
        g = c.createLinearGradient(0, 0, L * 0.8, r * 1.4); g.addColorStop(0, "rgba(255,225,150,0.7)"); g.addColorStop(1, "rgba(255,170,90,0)");
        c.fillStyle = g; c.beginPath(); c.moveTo(0, -r * 0.1); c.quadraticCurveTo(L * 0.5, r * 0.35, L * 0.85, r * 1.5); c.quadraticCurveTo(L * 0.5, r * 0.85, 0, r * 0.35); c.closePath(); c.fill();
        // هاله و هسته
        const hg = c.createRadialGradient(0, 0, 0, 0, 0, r * 1.5); hg.addColorStop(0, "rgba(255,255,255,0.95)"); hg.addColorStop(0.35, "rgba(190,225,255,0.5)"); hg.addColorStop(1, "rgba(120,170,255,0)"); c.fillStyle = hg; c.beginPath(); c.arc(0, 0, r * 1.5, 0, CX_TAU); c.fill();
        c.fillStyle = "#ffffff"; c.beginPath(); c.arc(0, 0, r * 0.32, 0, CX_TAU); c.fill();
        for(let i = 0; i < 8; i++){ const ph = ((s * 0.6 + i * 0.125) % 1), px = r * 0.8 + ph * L * 0.55, py = Math.sin(i * 2.3) * r * (0.2 + ph * 0.5); c.fillStyle = "rgba(210,235,255," + (0.8 * (1 - ph)).toFixed(3) + ")"; c.beginPath(); c.arc(px, py, Math.max(0.7, r * 0.06 * (1 - ph)), 0, CX_TAU); c.fill(); }
        c.restore();
    }
};
/* ---------- نقاشی‌های دکور فضایی (نسخه ۸.۰) ----------
   قانون کیفیت: آیتم گران‌تر زیباتر و پرجزئیات‌تر است؛ آیتم پولی همیشه از الماسی بهتر است. */
function dcGlow(c, x, y, r, rgb, a){
    const g = c.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, "rgba(" + rgb + "," + a + ")"); g.addColorStop(1, "rgba(" + rgb + ",0)");
    c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, CX_TAU); c.fill();
}

/* کهکشان مارپیچ (۳۰ هزار): بازوهای غنی، مسیر غبار، گره‌های صورتی، هسته‌ی درخشان و کهکشان همراه
   (بازوها یک‌بار روی بوم جداگانه ساخته می‌شوند و در هر فریم فقط می‌چرخند تا بازی روان بماند) */
let galaxyCache = null;
function galaxyBuild(R, plus){
    const S = Math.ceil(R * 2.3), cv = document.createElement("canvas"); cv.width = S; cv.height = S;
    const g = cv.getContext("2d"), n = plus ? 340 : 210;
    g.translate(S / 2, S / 2);
    g.strokeStyle = "rgba(14,8,38,0.40)"; g.lineWidth = Math.max(2, R * 0.05); g.lineCap = "round";
    for(let arm = 0; arm < 2; arm++){
        g.beginPath();
        for(let k = 0.08; k <= 1.001; k += 0.04){
            const ang = k * 6.3 + arm * Math.PI + 0.22, rad = R * (0.12 + k * 0.84), px = Math.cos(ang) * rad, py = Math.sin(ang) * rad;
            if(k === 0.08) g.moveTo(px, py); else g.lineTo(px, py);
        }
        g.stroke();
    }
    g.globalCompositeOperation = "lighter";
    for(let i = 0; i < n; i++){
        const arm = i % 2, k = (i >> 1) / (n / 2), ang = k * 6.3 + arm * Math.PI + (cxHash(i) - 0.5) * (0.35 + k * 0.45);
        const rad = R * (0.1 + k * 0.9) * (0.92 + cxHash(i + 31) * 0.16), px = Math.cos(ang) * rad, py = Math.sin(ang) * rad;
        const a = (1 - k * 0.55) * (0.5 + 0.42 * cxHash(i + 7)), hot = cxHash(i + 55) > 0.92;
        g.fillStyle = hot ? "rgba(255,150,210," + a.toFixed(3) + ")" : (k < 0.3 ? "rgba(255,228,190," + a.toFixed(3) + ")" : (arm ? "rgba(150,180,255," + a.toFixed(3) + ")" : "rgba(215,175,255," + a.toFixed(3) + ")"));
        g.beginPath(); g.arc(px, py, 0.8 + cxHash(i + 3) * 1.6 * (1 - k * 0.35) + (hot ? 0.9 : 0), 0, CX_TAU); g.fill();
    }
    return { key: R + (plus ? "p" : "n"), cv, S };
}
DECOR_PAINT.galaxy = function(c, w, gy, t, plus, o){
    const { x, y, r } = o, R = Math.max(8, Math.round(r)), s = t / 1000;
    if(!galaxyCache || galaxyCache.key !== R + (plus ? "p" : "n")) galaxyCache = galaxyBuild(R, plus);
    c.save(); c.translate(x, y); c.rotate(-0.5); c.scale(1, 0.52);
    const halo = c.createRadialGradient(0, 0, 0, 0, 0, r * 1.1);
    halo.addColorStop(0, "rgba(255,236,215,0.62)"); halo.addColorStop(0.2, "rgba(200,160,255,0.36)"); halo.addColorStop(0.55, "rgba(95,100,235,0.16)"); halo.addColorStop(1, "rgba(60,60,200,0)");
    c.fillStyle = halo; c.beginPath(); c.arc(0, 0, r * 1.1, 0, CX_TAU); c.fill();
    c.rotate(t * 0.00004); c.drawImage(galaxyCache.cv, -galaxyCache.S / 2, -galaxyCache.S / 2);
    c.restore();
    c.save(); c.globalCompositeOperation = "lighter";
    const tw = 0.85 + 0.15 * Math.sin(s * 2.2);
    dcGlow(c, x, y, r * 0.34, "255,214,160", 0.55 * tw); dcGlow(c, x, y, r * 0.14, "255,250,238", 0.95);
    c.strokeStyle = "rgba(255,240,215,0.35)"; c.lineWidth = 1; c.beginPath();
    c.moveTo(x - r * 0.5, y); c.lineTo(x + r * 0.5, y); c.moveTo(x, y - r * 0.2); c.lineTo(x, y + r * 0.2); c.stroke();
    c.translate(x + r * 1.0, y - r * 0.32); c.rotate(0.5); c.scale(1, 0.45);   // کهکشان همراه
    dcGlow(c, 0, 0, r * 0.2, "190,200,255", 0.5); dcGlow(c, 0, 0, r * 0.07, "255,255,255", 0.8);
    c.restore();
};

/* زحل (۲۵ هزار): نوارهای ابری، حلقه‌های چندلایه با شکاف کاسینی، سایه‌ی حلقه روی سیاره و دو قمر */
DECOR_PAINT.ringed = function(c, w, gy, t, plus, o){
    const { x, y, r } = o, s = t / 1000, tilt = -0.36, SQ = 0.3;
    const BANDS = [[1.20, 1.38, "176,150,118", 0.30], [1.40, 1.52, "240,222,186", 0.62], [1.52, 1.78, "252,236,200", 0.90], [1.86, 2.00, "226,204,166", 0.72], [2.00, 2.10, "206,184,148", 0.52], [2.18, 2.22, "255,246,225", 0.42]];
    const ring = front => {
        c.save(); c.translate(x, y); c.rotate(tilt); c.scale(1, SQ);
        BANDS.forEach(B => {
            c.strokeStyle = "rgba(" + B[2] + "," + B[3] + ")"; c.lineWidth = (B[1] - B[0]) * r;
            c.beginPath(); c.arc(0, 0, (B[0] + B[1]) / 2 * r, front ? 0 : Math.PI, front ? Math.PI : CX_TAU); c.stroke();
        });
        if(plus){ c.lineWidth = 0.8; for(let q = 0; q < 9; q++){ c.strokeStyle = "rgba(110,85,60," + (0.10 + 0.08 * cxHash(q + 400)).toFixed(3) + ")"; c.beginPath(); c.arc(0, 0, (1.54 + q * 0.026) * r, front ? 0 : Math.PI, front ? Math.PI : CX_TAU); c.stroke(); } }
        c.restore();
    };
    const moons = [{ orb: 2.75, sz: 0.11, col: "#e9b977", sp: 0.42, ph: 0.0 }, { orb: 3.25, sz: 0.07, col: "#d6dbe6", sp: -0.3, ph: 2.1 }];
    const moonAt = m => { const ang = s * m.sp + m.ph, px = Math.cos(ang) * m.orb * r, py = Math.sin(ang) * m.orb * r * SQ; return { mx: x + px * Math.cos(tilt) - py * Math.sin(tilt), my: y + px * Math.sin(tilt) + py * Math.cos(tilt), back: Math.sin(ang) < 0 }; };
    const drawMoon = (m, q) => { const mr = r * m.sz, g = c.createRadialGradient(q.mx - mr * 0.35, q.my - mr * 0.35, mr * 0.1, q.mx, q.my, mr); g.addColorStop(0, "#ffffff"); g.addColorStop(0.35, m.col); g.addColorStop(1, "#3a2c20"); c.fillStyle = g; c.beginPath(); c.arc(q.mx, q.my, mr, 0, CX_TAU); c.fill(); };
    ring(false);
    moons.forEach(m => { const q = moonAt(m); if(q.back) drawMoon(m, q); });
    dcGlow(c, x, y, r * 1.45, "255,214,150", 0.16);
    c.save(); c.beginPath(); c.arc(x, y, r, 0, CX_TAU); c.clip();
    const g = c.createRadialGradient(x - r * 0.45, y - r * 0.45, r * 0.1, x, y, r * 1.05);
    g.addColorStop(0, "#fff3d2"); g.addColorStop(0.5, "#dcae66"); g.addColorStop(1, "#6b4524");
    c.fillStyle = g; c.fillRect(x - r, y - r, r * 2, r * 2);
    [["rgba(150,90,40,0.34)", -0.66, 0.07], ["rgba(255,228,176,0.30)", -0.36, 0.06], ["rgba(125,72,35,0.32)", -0.1, 0.08], ["rgba(244,206,146,0.26)", 0.2, 0.06], ["rgba(100,60,30,0.30)", 0.48, 0.07], ["rgba(235,196,140,0.2)", 0.72, 0.05]].forEach(b => { c.fillStyle = b[0]; c.beginPath(); c.ellipse(x, y + b[1] * r, r * 1.1, r * b[2], 0.08, 0, CX_TAU); c.fill(); });
    c.save(); c.translate(x, y); c.rotate(tilt); c.fillStyle = "rgba(30,15,5,0.34)"; c.fillRect(-r * 1.2, -r * 0.17, r * 2.4, r * 0.14); c.restore();   // سایه‌ی حلقه روی سیاره
    const sd = c.createLinearGradient(x - r, y - r * 0.2, x + r, y + r * 0.2); sd.addColorStop(0, "rgba(0,0,0,0)"); sd.addColorStop(0.5, "rgba(0,0,0,0)"); sd.addColorStop(1, "rgba(15,8,0,0.68)");
    c.fillStyle = sd; c.fillRect(x - r, y - r, r * 2, r * 2);
    c.restore();
    ring(true);
    moons.forEach(m => { const q = moonAt(m); if(!q.back) drawMoon(m, q); });
};

/* ایستگاه فضایی (۲۵ هزار): یک ایستگاه واقعی روی زمینی سنگی که در هوا معلق است؛ با در، پنجره‌های روشن، گنبد شیشه‌ای،
   دکل و بشقاب آنتن، پنل خورشیدی، باند فرود و بلورهای ضدجاذبه‌ی زیر سنگ */
DECOR_PAINT.station = function(c, w, gy, t, plus, o){
    const r = o.r, s = t / 1000, bob = Math.sin(s * 0.9) * r * 0.05;
    c.save(); c.translate(o.x, o.y + bob);
    const metal = (x0, y0, w0, h0, rr) => { const g = c.createLinearGradient(x0, 0, x0 + w0, 0); g.addColorStop(0, "#f4f6fb"); g.addColorStop(0.45, "#b3bdcf"); g.addColorStop(1, "#6a758a"); c.fillStyle = g; c.beginPath(); cxRR(c, x0 * r, y0 * r, w0 * r, h0 * r, rr * r); c.fill(); };
    const blink = Math.floor(s * 1.6) % 2;
    // --- پرتوهای ضدجاذبه (زیر سنگ) ---
    c.save(); c.globalCompositeOperation = "lighter";
    [[-0.55, 0.9], [0.5, 0.95]].forEach((q, i) => { const pl = 0.65 + 0.35 * Math.sin(s * 2.4 + i * 2); const bg = c.createLinearGradient(0, q[1] * r, 0, (q[1] + 1.5) * r); bg.addColorStop(0, "rgba(110,230,255," + (0.32 * pl).toFixed(3) + ")"); bg.addColorStop(1, "rgba(110,230,255,0)"); c.fillStyle = bg; c.beginPath(); c.moveTo((q[0] - 0.12) * r, q[1] * r); c.lineTo((q[0] + 0.12) * r, q[1] * r); c.lineTo((q[0] + 0.3) * r, (q[1] + 1.5) * r); c.lineTo((q[0] - 0.3) * r, (q[1] + 1.5) * r); c.closePath(); c.fill(); });
    c.restore();
    // --- سنگِ معلق ---
    const rock = [[1.95, 0], [1.7, 0.28], [1.45, 0.55], [1.18, 0.62], [0.9, 1.0], [0.62, 0.8], [0.34, 1.22], [0.12, 0.95], [-0.12, 1.5], [-0.38, 0.86], [-0.62, 1.18], [-0.82, 0.78], [-1.15, 0.9], [-1.3, 0.48], [-1.55, 0.5], [-1.7, 0.22], [-1.95, 0], [-1.2, -0.07], [0, -0.03], [1.2, -0.06]];
    c.beginPath(); rock.forEach((q, i) => { if(i) c.lineTo(q[0] * r, q[1] * r); else c.moveTo(q[0] * r, q[1] * r); }); c.closePath();
    const rg = c.createLinearGradient(0, -0.1 * r, 0, 1.5 * r); rg.addColorStop(0, "#a4a29f"); rg.addColorStop(0.35, "#6f717b"); rg.addColorStop(1, "#2a2c37");
    c.fillStyle = rg; c.fill();
    const rh = c.createLinearGradient(-1.95 * r, 0, 1.95 * r, 0); rh.addColorStop(0, "rgba(255,255,255,0.16)"); rh.addColorStop(0.55, "rgba(255,255,255,0)"); rh.addColorStop(1, "rgba(0,0,10,0.34)");
    c.fillStyle = rh; c.fill();
    c.strokeStyle = "rgba(15,16,26,0.75)"; c.lineWidth = Math.max(1, r * 0.03); c.stroke();
    c.strokeStyle = "rgba(20,20,32,0.5)"; c.lineWidth = Math.max(0.8, r * 0.02); c.beginPath();
    [[-1.0, 0.12, -0.8, 0.55], [0.2, 0.15, 0.3, 0.7], [1.1, 0.1, 0.92, 0.45], [-0.3, 0.2, -0.42, 0.62]].forEach(q => { c.moveTo(q[0] * r, q[1] * r); c.lineTo((q[0] + (q[2] - q[0]) * 0.5 + 0.06) * r, (q[1] + (q[3] - q[1]) * 0.5) * r); c.lineTo(q[2] * r, q[3] * r); }); c.stroke();
    c.fillStyle = "rgba(20,20,32,0.30)"; [[-1.3, 0.28, 0.2, 0.07], [0.85, 0.36, 0.22, 0.07], [-0.1, 0.5, 0.17, 0.05]].forEach(q => { c.beginPath(); c.ellipse(q[0] * r, q[1] * r, q[2] * r, q[3] * r, 0, 0, CX_TAU); c.fill(); });
    // رویه‌ی سنگی بالای زمین
    const tg = c.createLinearGradient(0, -0.12 * r, 0, 0.05 * r); tg.addColorStop(0, "#d0ccc4"); tg.addColorStop(1, "#8d8880");
    c.fillStyle = tg; c.beginPath(); cxRR(c, -1.92 * r, -0.1 * r, 3.84 * r, 0.13 * r, 0.05 * r); c.fill();
    c.fillStyle = "#9b968e"; [[-1.5, 0.05], [-0.4, 0.04], [0.9, 0.05], [1.62, 0.06]].forEach(q => { c.beginPath(); c.ellipse(q[0] * r, -0.1 * r, q[1] * r + 0.04 * r, 0.04 * r, 0, Math.PI, CX_TAU); c.fill(); });
    // --- بلورهای ضدجاذبه ---
    c.save(); c.globalCompositeOperation = "lighter";
    [[-0.55, 0.9], [0.5, 0.95]].forEach((q, i) => { const pl = 0.7 + 0.3 * Math.sin(s * 2.4 + i * 2); dcGlow(c, q[0] * r, q[1] * r, r * 0.34, "110,230,255", 0.55 * pl); c.fillStyle = "rgba(220,250,255," + (0.9 * pl).toFixed(3) + ")"; c.beginPath(); c.moveTo(q[0] * r, (q[1] - 0.12) * r); c.lineTo((q[0] + 0.07) * r, q[1] * r); c.lineTo(q[0] * r, (q[1] + 0.12) * r); c.lineTo((q[0] - 0.07) * r, q[1] * r); c.closePath(); c.fill(); });
    c.restore();
    // --- باند فرود (چپ) ---
    metal(-1.82, -0.17, 0.95, 0.08, 0.02);
    c.fillStyle = "rgba(255,205,60," + (blink ? 0.95 : 0.3) + ")"; c.fillRect(-1.82 * r, -0.21 * r, 0.05 * r, 0.05 * r); c.fillRect(-0.92 * r, -0.21 * r, 0.05 * r, 0.05 * r);
    c.fillStyle = "rgba(60,70,90,0.9)"; c.fillRect(-1.5 * r, -0.15 * r, 0.3 * r, 0.03 * r); c.fillRect(-1.2 * r, -0.15 * r, 0.12 * r, 0.03 * r);
    // --- جعبه‌ها ---
    c.fillStyle = "#7a5d3a"; c.fillRect(-1.0 * r, -0.28 * r, 0.2 * r, 0.18 * r); c.fillStyle = "#946f44"; c.fillRect(-1.0 * r, -0.28 * r, 0.2 * r, 0.04 * r); c.fillStyle = "#6a8a9a"; c.fillRect(-0.84 * r, -0.22 * r, 0.14 * r, 0.12 * r);
    // --- ماژول اصلی ---
    metal(-0.72, -0.98, 1.44, 0.88, 0.14);
    c.strokeStyle = "rgba(60,70,90,0.45)"; c.lineWidth = Math.max(0.7, r * 0.02); c.beginPath();
    c.moveTo(-0.72 * r, -0.32 * r); c.lineTo(0.72 * r, -0.32 * r); c.moveTo(-0.72 * r, -0.8 * r); c.lineTo(0.72 * r, -0.8 * r); c.moveTo(-0.5 * r, -0.98 * r); c.lineTo(-0.5 * r, -0.1 * r); c.moveTo(0.5 * r, -0.98 * r); c.lineTo(0.5 * r, -0.1 * r); c.stroke();
    c.fillStyle = "rgba(255,255,255,0.4)"; c.fillRect(-0.68 * r, -0.95 * r, 1.36 * r, 0.04 * r);
    // پنجره‌ها
    for(let k = 0; k < 4; k++){
        const wx = (-0.54 + k * 0.36) * r, wy = -0.62 * r, fl = 0.85 + 0.15 * Math.sin(s * 3 + k * 1.7);
        c.fillStyle = "#2b3346"; c.beginPath(); c.arc(wx, wy, r * 0.105, 0, CX_TAU); c.fill();
        const wg = c.createRadialGradient(wx - r * 0.02, wy - r * 0.03, 0, wx, wy, r * 0.085); wg.addColorStop(0, "#fff7d0"); wg.addColorStop(1, "#ffc864");
        c.fillStyle = wg; c.beginPath(); c.arc(wx, wy, r * 0.085, 0, CX_TAU); c.fill();
        c.save(); c.globalCompositeOperation = "lighter"; dcGlow(c, wx, wy, r * 0.3, "255,205,110", 0.32 * fl); c.restore();
    }
    // در (طاق‌دار، دوتکه)
    const dx = 0, dw = 0.17;
    c.fillStyle = "#c2cad8"; c.beginPath(); c.moveTo((dx - dw - 0.04) * r, -0.1 * r); c.lineTo((dx - dw - 0.04) * r, -0.3 * r); c.arc(dx * r, -0.3 * r, (dw + 0.04) * r, Math.PI, CX_TAU); c.lineTo((dx + dw + 0.04) * r, -0.1 * r); c.closePath(); c.fill();
    c.fillStyle = "#1a2030"; c.beginPath(); c.moveTo((dx - dw) * r, -0.1 * r); c.lineTo((dx - dw) * r, -0.3 * r); c.arc(dx * r, -0.3 * r, dw * r, Math.PI, CX_TAU); c.lineTo((dx + dw) * r, -0.1 * r); c.closePath(); c.fill();
    const og = c.createLinearGradient(0, -0.46 * r, 0, -0.1 * r); og.addColorStop(0, "rgba(120,235,255,0.55)"); og.addColorStop(1, "rgba(120,235,255,0.12)");
    c.fillStyle = og; c.fillRect((dx - 0.012) * r, -0.45 * r, 0.024 * r, 0.35 * r);
    c.strokeStyle = "rgba(255,210,60,0.9)"; c.lineWidth = Math.max(0.8, r * 0.022); c.beginPath(); c.moveTo((dx - dw) * r, -0.1 * r); c.lineTo((dx - dw) * r, -0.3 * r); c.arc(dx * r, -0.3 * r, dw * r, Math.PI, CX_TAU); c.lineTo((dx + dw) * r, -0.1 * r); c.stroke();
    c.fillStyle = "#e5eaf3"; c.fillRect((dx - 0.26) * r, -0.1 * r, 0.52 * r, 0.04 * r);
    c.save(); c.globalCompositeOperation = "lighter"; dcGlow(c, dx * r, -0.56 * r, r * 0.2, "120,235,255", 0.5); c.restore();
    c.fillStyle = "#5fe8ff"; c.beginPath(); c.arc(dx * r, -0.52 * r, r * 0.035, 0, CX_TAU); c.fill();
    // ماژول بام و دکل
    metal(-0.46, -1.24, 0.92, 0.27, 0.07);
    c.fillStyle = "#ffe9a8"; for(let k = 0; k < 5; k++) c.fillRect((-0.36 + k * 0.17) * r, -1.15 * r, 0.1 * r, 0.07 * r);
    c.strokeStyle = "#cfd6e2"; c.lineWidth = Math.max(1, r * 0.04); c.beginPath(); c.moveTo(-0.62 * r, -0.98 * r); c.lineTo(-0.62 * r, -1.62 * r); c.stroke();
    c.lineWidth = Math.max(0.8, r * 0.03); c.beginPath(); c.moveTo(-0.62 * r, -1.5 * r); c.arc(-0.62 * r, -1.5 * r, r * 0.2, Math.PI * 1.1, Math.PI * 1.9); c.stroke();
    c.beginPath(); c.moveTo(-0.62 * r, -1.5 * r); c.lineTo(-0.62 * r + Math.cos(Math.PI * 1.5) * r * 0.2, -1.5 * r + Math.sin(Math.PI * 1.5) * r * 0.2 - r * 0.02); c.stroke();
    c.save(); c.globalCompositeOperation = "lighter"; dcGlow(c, -0.62 * r, -1.68 * r, r * (blink ? 0.2 : 0.09), "255,70,70", blink ? 0.9 : 0.4); c.restore();
    c.fillStyle = "#ff5555"; c.beginPath(); c.arc(-0.62 * r, -1.66 * r, r * 0.04, 0, CX_TAU); c.fill();
    // لوله‌ی ارتباطی و گنبد شیشه‌ای
    metal(0.7, -0.4, 0.3, 0.22, 0.05); c.fillStyle = "#ffe9a8"; c.fillRect(0.76 * r, -0.33 * r, 0.07 * r, 0.07 * r); c.fillRect(0.86 * r, -0.33 * r, 0.07 * r, 0.07 * r);
    metal(0.62, -0.2, 1.06, 0.1, 0.03);
    c.save(); c.beginPath(); c.arc(1.15 * r, -0.2 * r, 0.5 * r, Math.PI, CX_TAU); c.closePath();
    const dg = c.createRadialGradient(1.0 * r, -0.5 * r, r * 0.05, 1.15 * r, -0.2 * r, r * 0.55); dg.addColorStop(0, "rgba(210,240,255,0.80)"); dg.addColorStop(0.6, "rgba(110,175,235,0.52)"); dg.addColorStop(1, "rgba(50,100,190,0.55)");
    c.fillStyle = dg; c.fill(); c.clip();
    c.fillStyle = "rgba(255,215,140,0.42)"; c.fillRect(0.7 * r, -0.4 * r, 0.9 * r, 0.3 * r);
    c.fillStyle = "rgba(255,200,120,0.85)"; c.fillRect(0.98 * r, -0.4 * r, 0.1 * r, 0.2 * r); c.fillRect(1.2 * r, -0.36 * r, 0.14 * r, 0.16 * r);
    c.restore();
    c.strokeStyle = "rgba(235,248,255,0.7)"; c.lineWidth = Math.max(0.8, r * 0.022); c.beginPath(); c.arc(1.15 * r, -0.2 * r, 0.5 * r, Math.PI, CX_TAU);
    c.moveTo(1.15 * r, -0.7 * r); c.lineTo(1.15 * r, -0.2 * r); c.moveTo(0.78 * r, -0.54 * r); c.quadraticCurveTo(1.15 * r, -0.62 * r, 1.52 * r, -0.54 * r); c.stroke();
    c.strokeStyle = "rgba(255,255,255,0.55)"; c.beginPath(); c.arc(1.15 * r, -0.2 * r, 0.42 * r, Math.PI * 1.12, Math.PI * 1.4); c.stroke();
    // پنل خورشیدی روی ستون
    c.strokeStyle = "#aeb8c8"; c.lineWidth = Math.max(1, r * 0.04); c.beginPath(); c.moveTo(1.8 * r, -0.1 * r); c.lineTo(1.8 * r, -0.5 * r); c.stroke();
    c.save(); c.translate(1.8 * r, -0.5 * r); c.rotate(-0.45);
    const sg = c.createLinearGradient(-0.3 * r, 0, 0.3 * r, 0); sg.addColorStop(0, "#173a7c"); sg.addColorStop(0.5, "#4a86e0"); sg.addColorStop(1, "#173a7c");
    c.fillStyle = sg; c.fillRect(-0.3 * r, -0.12 * r, 0.6 * r, 0.24 * r);
    c.strokeStyle = "rgba(200,222,255,0.55)"; c.lineWidth = 0.6; c.beginPath(); for(let k = 1; k < 4; k++){ c.moveTo((-0.3 + k * 0.15) * r, -0.12 * r); c.lineTo((-0.3 + k * 0.15) * r, 0.12 * r); } c.moveTo(-0.3 * r, 0); c.lineTo(0.3 * r, 0); c.stroke();
    c.restore();
    // سنگ‌ریزه‌های معلق
    c.fillStyle = "#6b6c76"; [[-2.2, 0.55, 0.1, 0], [2.18, 0.35, 0.08, 1.7], [2.05, 0.95, 0.06, 3.2]].forEach(q => { const yy = q[1] * r + Math.sin(s * 1.1 + q[3]) * r * 0.06; c.beginPath(); c.ellipse(q[0] * r, yy, q[2] * r, q[2] * r * 0.7, q[3], 0, CX_TAU); c.fill(); });
    if(plus){ c.save(); c.globalCompositeOperation = "lighter"; for(let i = 0; i < 4; i++){ const ph = (s * 0.6 + i * 0.25) % 1; c.fillStyle = "rgba(160,240,255," + (0.6 * (1 - ph)).toFixed(3) + ")"; c.beginPath(); c.arc((i % 2 ? 0.5 : -0.55) * r + Math.sin(i * 3 + s) * r * 0.05, (1.0 + ph * 1.1) * r, Math.max(0.6, r * 0.03 * (1 - ph)), 0, CX_TAU); c.fill(); } c.restore(); }
    c.restore();
};

/* ستاره‌ی دنباله‌دار (۱۵ هزار): هسته‌ی درخشان، کومای چندلایه، سه دُم (یونی/غبار/ردّ جرقه) */
DECOR_PAINT.comet = function(c, w, gy, t, plus, o){
    const { x, y, r } = o, s = t / 1000;
    c.save(); c.translate(x, y); c.rotate(-0.1); c.globalCompositeOperation = "lighter";
    const L = r * 8;
    for(let q = 0; q < 3; q++){   // دُم یونی (آبی): سه لایه‌ی تو در تو
        const wid = 0.3 + q * 0.16, a0 = 0.85 - q * 0.24, LL = L * (1 - q * 0.12), wob = Math.sin(s * 2 + q) * r * 0.08;
        const g = c.createLinearGradient(0, 0, LL, 0); g.addColorStop(0, "rgba(190,235,255," + a0.toFixed(2) + ")"); g.addColorStop(0.35, "rgba(90,165,255," + (a0 * 0.42).toFixed(3) + ")"); g.addColorStop(1, "rgba(60,110,255,0)");
        c.fillStyle = g; c.beginPath(); c.moveTo(0, -r * wid); c.quadraticCurveTo(LL * 0.5, -r * (wid + 0.35) + wob, LL, -r * 0.08); c.lineTo(LL, r * 0.08); c.quadraticCurveTo(LL * 0.5, r * (wid + 0.35) - wob, 0, r * wid); c.closePath(); c.fill();
    }
    for(let q = 0; q < 2; q++){   // دُم غبار (طلایی و خمیده)
        const g = c.createLinearGradient(0, 0, L * 0.85, r * 1.6); g.addColorStop(0, "rgba(255,228,155," + (0.72 - q * 0.25).toFixed(2) + ")"); g.addColorStop(1, "rgba(255,170,90,0)");
        c.fillStyle = g; c.beginPath(); c.moveTo(0, -r * 0.1); c.quadraticCurveTo(L * 0.5, r * (0.3 + q * 0.2), L * 0.88, r * (1.5 + q * 0.4)); c.quadraticCurveTo(L * 0.5, r * (0.9 + q * 0.3), 0, r * 0.38); c.closePath(); c.fill();
    }
    dcGlow(c, 0, 0, r * 2.1, "120,180,255", 0.22); dcGlow(c, 0, 0, r * 1.45, "190,225,255", 0.5);
    dcGlow(c, 0, 0, r * 0.8, "255,255,255", 0.85);
    c.fillStyle = "#ffffff"; c.beginPath(); c.arc(0, 0, r * 0.32, 0, CX_TAU); c.fill();
    c.strokeStyle = "rgba(255,255,255,0.4)"; c.lineWidth = 1; c.beginPath(); c.moveTo(-r * 1.1, 0); c.lineTo(r * 1.1, 0); c.moveTo(0, -r * 0.9); c.lineTo(0, r * 0.9); c.stroke();
    const sp = plus ? 14 : 9;
    for(let i = 0; i < sp; i++){ const ph = ((s * 0.6 + i / sp) % 1), px = r * 0.8 + ph * L * 0.7, py = Math.sin(i * 2.3) * r * (0.2 + ph * 0.7); c.fillStyle = (i % 3 ? "rgba(210,235,255," : "rgba(255,230,170,") + (0.85 * (1 - ph)).toFixed(3) + ")"; c.beginPath(); c.arc(px, py, Math.max(0.7, r * 0.07 * (1 - ph)), 0, CX_TAU); c.fill(); }
    c.restore();
};

/* خورشید ویژه‌ی VIP: واقعاً نور می‌دهد! نور گرم روی کل آسمان می‌تابد، پرتوهای چرخان، کورونا، سطح جوشان، زبانه‌های شراره */
DECOR_PAINT.sun = function(c, w, gy, t, plus, o){
    const { x, y, r } = o, s = t / 1000;
    c.save(); c.globalCompositeOperation = "lighter";
    const wash = c.createRadialGradient(x, y, r * 0.9, x, y, Math.max(w, gy) * 0.95);
    wash.addColorStop(0, "rgba(255,196,96,0.30)"); wash.addColorStop(0.35, "rgba(255,150,70,0.12)"); wash.addColorStop(1, "rgba(255,120,40,0)");
    c.fillStyle = wash; c.fillRect(0, 0, w, gy);
    c.translate(x, y); c.rotate(s * 0.06);
    const nRay = plus ? 18 : 12;
    for(let i = 0; i < nRay; i++){
        const a = i / nRay * CX_TAU, len = r * (2.5 + 1.0 * Math.sin(s * 0.7 + i * 2.1)), half = 0.045 + 0.02 * Math.sin(i * 1.7);
        const g = c.createLinearGradient(Math.cos(a) * r, Math.sin(a) * r, Math.cos(a) * len, Math.sin(a) * len); g.addColorStop(0, "rgba(255,212,125,0.42)"); g.addColorStop(1, "rgba(255,170,60,0)");
        c.fillStyle = g; c.beginPath(); c.moveTo(Math.cos(a - half) * r, Math.sin(a - half) * r); c.lineTo(Math.cos(a) * len, Math.sin(a) * len); c.lineTo(Math.cos(a + half) * r, Math.sin(a + half) * r); c.closePath(); c.fill();
    }
    c.restore();
    c.save(); c.globalCompositeOperation = "lighter";
    [[2.2, 0.12], [1.6, 0.22], [1.28, 0.4]].forEach(q => dcGlow(c, x, y, r * q[0], "255,170,70", q[1]));
    c.restore();
    c.save(); c.beginPath(); c.arc(x, y, r, 0, CX_TAU); c.clip();
    const sg = c.createRadialGradient(x - r * 0.25, y - r * 0.25, r * 0.1, x, y, r);
    sg.addColorStop(0, "#fffbe3"); sg.addColorStop(0.35, "#ffe27a"); sg.addColorStop(0.75, "#ffa83a"); sg.addColorStop(1, "#e86a14");
    c.fillStyle = sg; c.fillRect(x - r, y - r, r * 2, r * 2);
    for(let i = 0; i < (plus ? 28 : 16); i++){
        const a = cxHash(i + 200) * CX_TAU + s * 0.03, d = cxHash(i + 230) * r * 0.9, gr = r * (0.1 + cxHash(i + 260) * 0.12), al = 0.10 + 0.10 * Math.sin(s * 0.9 + i * 1.3);
        c.fillStyle = (i % 3 === 0) ? "rgba(255,255,230," + al.toFixed(3) + ")" : "rgba(210,90,10," + al.toFixed(3) + ")";
        c.beginPath(); c.arc(x + Math.cos(a) * d, y + Math.sin(a) * d, gr, 0, CX_TAU); c.fill();
    }
    c.fillStyle = "rgba(150,50,5,0.4)"; [[0.3, -0.2, 0.07], [0.42, -0.12, 0.045], [-0.35, 0.3, 0.06]].forEach(q => { c.beginPath(); c.arc(x + q[0] * r, y + q[1] * r, q[2] * r, 0, CX_TAU); c.fill(); });
    const ld = c.createRadialGradient(x, y, r * 0.6, x, y, r); ld.addColorStop(0, "rgba(120,30,0,0)"); ld.addColorStop(1, "rgba(120,30,0,0.35)");
    c.fillStyle = ld; c.fillRect(x - r, y - r, r * 2, r * 2);
    c.restore();
    c.save(); c.globalCompositeOperation = "lighter"; c.lineCap = "round";
    for(let i = 0; i < 4; i++){
        const a = i * 1.7 + s * 0.05, h = r * (0.3 + 0.16 * Math.sin(s * 1.1 + i * 1.9));
        const ax = Math.cos(a) * r, ay = Math.sin(a) * r, bx = Math.cos(a + 0.34) * r, by = Math.sin(a + 0.34) * r, cx2 = Math.cos(a + 0.17) * (r + h * 2), cy2 = Math.sin(a + 0.17) * (r + h * 2);
        c.strokeStyle = "rgba(255,120,30,0.65)"; c.lineWidth = Math.max(1.6, r * 0.05); c.beginPath(); c.moveTo(x + ax, y + ay); c.quadraticCurveTo(x + cx2, y + cy2, x + bx, y + by); c.stroke();
        c.strokeStyle = "rgba(255,225,150,0.8)"; c.lineWidth = Math.max(0.8, r * 0.02); c.stroke();
    }
    if(plus){ for(let k = 1; k <= 3; k++){ const px = x + (w * 0.5 - x) * k * 0.55, py = y + (gy * 0.7 - y) * k * 0.55; dcGlow(c, px, py, r * (0.16 + k * 0.05), k === 2 ? "255,170,90" : "180,220,255", 0.12); } }
    c.restore();
};

/* ---------- ارتقای دکورهای الماسی (نسخه ۸.۰) ----------
   دکورهای پولی (دنباله‌دار، زحل، ایستگاه، کهکشان) همچنان پرجزئیات‌تر و باشکوه‌ترند. */
(function upgradeGemDecor(){
    const base = { mistTop: DECOR_PAINT.mistTop, mistLow: DECOR_PAINT.mistLow, satellite: DECOR_PAINT.satellite, nebula: DECOR_PAINT.nebula, redplanet: DECOR_PAINT.redplanet };
    const motes = (c, w, y0, y1, t, n, rgb) => { c.save(); c.globalCompositeOperation = "lighter"; for(let i = 0; i < n; i++){ const x = cxMod(i * 97 - t * (0.006 + (i % 3) * 0.002), w + 40) - 20, y = y0 + (y1 - y0) * cxHash(i + 5), a = 0.2 + 0.35 * Math.abs(Math.sin(t * 0.0011 + i * 2)); c.fillStyle = "rgba(" + rgb + "," + a.toFixed(3) + ")"; c.beginPath(); c.arc(x, y, 1 + (i % 3) * 0.5, 0, CX_TAU); c.fill(); } c.restore(); };
    DECOR_PAINT.mistTop = function(c, w, gy, t, plus, o){ base.mistTop(c, w, gy, t, plus, o); motes(c, w, gy * 0.05, gy * 0.32, t, plus ? 14 : 8, "230,215,255"); };
    DECOR_PAINT.mistLow = function(c, w, gy, t, plus, o){ base.mistLow(c, w, gy, t, plus, o); motes(c, w, gy * 0.6, gy * 0.97, t, plus ? 14 : 8, "255,235,215"); };
    DECOR_PAINT.satellite = function(c, w, gy, t, plus, o){
        base.satellite(c, w, gy, t, plus, o);
        const r = o.r, on = (Math.floor(t / 450) % 2) === 0;
        c.save(); c.globalCompositeOperation = "lighter";
        dcGlow(c, o.x - r * 1.9, o.y - r * 0.15, r * (on ? 0.9 : 0.4), "255,60,60", on ? 0.9 : 0.3); dcGlow(c, o.x + r * 1.9, o.y - r * 0.15, r * (on ? 0.4 : 0.9), "70,255,120", on ? 0.3 : 0.9);
        const tw = 0.5 + 0.5 * Math.sin(t / 380); c.fillStyle = "rgba(255,255,255," + (0.6 * tw).toFixed(2) + ")"; cxStar(c, o.x - r * 0.4, o.y - r * 0.5, r * 0.5 * tw + 1, 4, t / 600); c.fill();
        c.restore();
    };
    DECOR_PAINT.nebula = function(c, w, gy, t, plus, o){
        base.nebula(c, w, gy, t, plus, o);
        const r = o.r; c.save(); c.globalCompositeOperation = "lighter";
        dcGlow(c, o.x - r * 0.45, o.y + r * 0.2, r * 0.7, "255,110,200", 0.14); dcGlow(c, o.x + r * 0.5, o.y - r * 0.25, r * 0.65, "90,170,255", 0.15);
        const n = plus ? 20 : 12;
        for(let i = 0; i < n; i++){ const a = cxHash(i + 11) * CX_TAU, d = Math.sqrt(cxHash(i + 31)) * r * 0.85, tw = 0.3 + 0.7 * Math.abs(Math.sin(t * 0.0013 + i * 1.9)); c.fillStyle = "rgba(255,255,255," + (0.8 * tw).toFixed(2) + ")"; cxStar(c, o.x + Math.cos(a) * d, o.y + Math.sin(a) * d * 0.8, 1.4 + tw * 1.8, 4, 0); c.fill(); }
        c.restore();
    };
    DECOR_PAINT.redplanet = function(c, w, gy, t, plus, o){
        base.redplanet(c, w, gy, t, plus, o);
        const r = o.r; c.save(); c.beginPath(); c.arc(o.x, o.y, r, 0, CX_TAU); c.clip();
        c.fillStyle = "rgba(255,255,255,0.65)"; c.beginPath(); c.ellipse(o.x, o.y - r * 0.95, r * 0.5, r * 0.18, 0, 0, CX_TAU); c.fill();                   // کلاهک قطبی
        c.fillStyle = "rgba(255,200,150,0.16)"; c.beginPath(); c.ellipse(o.x + Math.sin(t / 5000) * r * 0.2, o.y + r * 0.25, r * 1.1, r * 0.13, 0.12, 0, CX_TAU); c.fill();   // نوار توفان غبار
        c.restore();
        c.save(); c.globalCompositeOperation = "lighter"; c.strokeStyle = "rgba(255,170,120,0.28)"; c.lineWidth = Math.max(1.5, r * 0.06); c.beginPath(); c.arc(o.x, o.y, r * 1.06, -2.4, -0.4); c.stroke(); c.restore();   // هاله‌ی جوّ
    };
})();

function cxDecorOne(c, key, w, gy, tms, plus, pv){
    const o = decorLayout(key, w, gy, tms, pv); if(!o || !DECOR_PAINT[key]) return;
    DECOR_PAINT[key](c, w, gy, tms, plus, o);
}
/* رسم همه‌ی اجرام آسمان با ترتیب عمق (سیاره‌های پایه + دکورهای فعال) */
function skyPaint(){
    if(gfxLow()) return;
    const tms = performance.now(), gy = player ? player.ground : H * 0.78, plus = gfxPlus(), list = [];
    planets.forEach((pl, i) => list.push({ z: 3.0 + i * 0.05, planet: pl, i }));
    decorActive().forEach(k => list.push({ z: SKY[k] ? SKY[k].z : 0, key: k }));
    list.sort((a, b) => a.z - b.z);
    ctx.save();
    list.forEach(it => { if(it.planet) skyPlanet(it.planet, it.i, tms, plus); else cxDecorOne(ctx, it.key, W, gy, tms, plus, false); });
    ctx.restore();
}
function skyPlanet(pl, i, tms, plus){
    const ex = pl.radius * (pl.ring ? 1.95 : 1.2), trav = W + 2 * ex, k = ((tms / 1000 / SKY_PLANET_PERIOD[i % 3] + (pl.ph || 0)) % 1 + 1) % 1;
    pl.x = W + ex - k * trav; pl.rot += 0.004;
    const pal = MAX_BIOME[currentBiome] || MAX_BIOME.classic;
    ctx.save();
    if(pl.ring){
        ctx.save(); ctx.translate(pl.x, pl.y); ctx.rotate(0.4);
        ctx.strokeStyle = "rgba(220,200,255,0.35)"; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.ellipse(0, 0, pl.radius * 1.7, pl.radius * 0.45, 0, 0, Math.PI * 2); ctx.stroke();
        ctx.restore();
    }
    const pg = ctx.createRadialGradient(pl.x - pl.radius * 0.3, pl.y - pl.radius * 0.3, pl.radius * 0.1, pl.x, pl.y, pl.radius);
    pg.addColorStop(0, pl.color1); pg.addColorStop(1, pl.color2);
    ctx.fillStyle = pg; ctx.beginPath(); ctx.arc(pl.x, pl.y, pl.radius, 0, Math.PI * 2); ctx.fill();
    if(plus){   // گرافیک حداکثر: جوّ، سایه‌ی تاریک‌وروشن، نوارهای ابری و نیمه‌ی جلوی حلقه (همین‌جا و هم‌عمق با خود سیاره)
        maxGlow(pl.x, pl.y, pl.radius * 1.7, pal[0], 0.30);
        ctx.save(); ctx.beginPath(); ctx.arc(pl.x, pl.y, pl.radius, 0, Math.PI * 2); ctx.clip();
        const sh = ctx.createRadialGradient(pl.x + pl.radius * 0.5, pl.y + pl.radius * 0.45, pl.radius * 0.15, pl.x + pl.radius * 0.5, pl.y + pl.radius * 0.45, pl.radius * 1.55);
        sh.addColorStop(0, "rgba(0,0,12,0)"); sh.addColorStop(1, "rgba(0,0,14,0.72)");
        ctx.fillStyle = sh; ctx.fillRect(pl.x - pl.radius, pl.y - pl.radius, pl.radius * 2, pl.radius * 2);
        ctx.strokeStyle = "rgba(255,255,255,0.07)"; ctx.lineWidth = Math.max(2, pl.radius * 0.09);
        for(let q = -1; q <= 1; q++){ ctx.beginPath(); ctx.ellipse(pl.x, pl.y + q * pl.radius * 0.34, pl.radius, pl.radius * 0.22, pl.rot * 0.2, 0, Math.PI); ctx.stroke(); }
        ctx.restore();
        if(pl.ring){
            ctx.save(); ctx.translate(pl.x, pl.y); ctx.rotate(0.4);
            ctx.strokeStyle = "rgba(235,215,255,0.55)"; ctx.lineWidth = 3.4;
            ctx.beginPath(); ctx.ellipse(0, 0, pl.radius * 1.7, pl.radius * 0.45, 0, 0.05, Math.PI - 0.05); ctx.stroke();
            ctx.restore();
        }
    }
    ctx.restore();
}

/* ================================================================
   کاتالوگ شخصی‌سازی: دسته‌ها، قیمت‌ها، مالکیت، پک‌ها و پیشنهادهای ویژه
   cur: free | coins | gems | irl (پرداخت واقعی، به تومان) | vip
   ================================================================ */
const CAT_DEF = {
    skin:   { title:"🚀 اسکین‌های سفینه",   field:"skin",        own:"skinOwned",        none:"blue", defName:"کلاسیک" },
    trail:  { title:"✨ دنباله‌ی سفینه",     field:"trailColor",  own:"trailOwned",       none:"none" },
    jump:   { title:"💥 افکت پرش",          field:"jumpEffect",  own:"jumpEffectOwned",  none:"none" },
    aura:   { title:"🔮 هاله‌ی دور سفینه",   field:"aura",        own:"auraOwned",        none:"none" },
    start:  { title:"🎬 افکت ورود به بازی",  field:"startFx",     own:"startFxOwned",     none:"none" },
    ground: { title:"🌍 زمین‌های ویژه",      field:"groundTheme", own:"groundThemeOwned", none:"none" },
    filter: { title:"🎞️ فیلترهای محیط",      field:"envFilter",   own:"filterOwned",      none:"none" },
    decor:  { title:"🪐 دکور فضایی",         field:null,          own:"decorOwned",       none:null, multi:true }
};
const CAT_ORDER = ["skin","trail","jump","aura","start","ground","filter","decor"];
const CAT_SINGLE = CAT_ORDER.filter(c => c !== "decor");
// هر آیتم: [کلید, نام, آیکن, نوع پرداخت, قیمت, توضیح]
const CAT_ITEMS = {
    skin: SK_ORDER.map(k => ({ key:k, name:SK[k].n, icon:SK[k].i, cur:SK[k].cur, price:SK[k].price || 0, desc:SK[k].d, power:SK[k].pw })),
    trail: [
        { key:"none", name:"بدون دنباله", icon:"⭕", cur:"free", price:0, desc:"بدون هیچ دنباله‌ای" },
        { key:"cyan", name:"دنباله‌ی یخی", icon:"🧊", cur:"gems", price:50, desc:"گاز فیروزه‌ای یخی که پشت سفینه پخش می‌شود" },
        { key:"pink", name:"دنباله‌ی صورتی", icon:"🌸", cur:"gems", price:50, desc:"ابر صورتیِ نرم و رویایی" },
        { key:"green", name:"دنباله‌ی سمی", icon:"☄️", cur:"gems", price:65, desc:"حباب‌های سمیِ سبز و درخشان" },
        { key:"violet", name:"دنباله‌ی ارغوانی", icon:"🟣", cur:"gems", price:65, desc:"دودِ بنفش کهکشانی" },
        { key:"smoke", name:"دود نقره‌ای", icon:"🌫️", cur:"gems", price:70, desc:"دود نرم و بزرگِ نقره‌ای" },
        { key:"ember", name:"جرقه‌ی آتشین", icon:"🔥", cur:"gems", price:70, desc:"جرقه‌های سریع و آتشین" },
        { key:"blueflame", name:"شعله‌ی آبی", icon:"🔷", cur:"gems", price:60, desc:"شعله‌ی آبیِ بالا‌رونده" },
        { key:"stardust", name:"ستاره‌ریز", icon:"⭐", cur:"gems", price:85, desc:"ستاره‌های ریزِ چرخان" },
        { key:"rainbow", name:"دنباله‌ی رنگین‌کمان", icon:"🌈", cur:"irl", price:35000, desc:"گاز رنگین‌کمانیِ مدام‌رنگ‌عوض‌کن" },
        { key:"galaxy", name:"دنباله‌ی کهکشانی", icon:"🌌", cur:"irl", price:30000, desc:"ذرات بنفش، آبی و صورتی با ستاره‌های درخشان" },
        { key:"electric", name:"دنباله‌ی برقی", icon:"⚡", cur:"irl", price:25000, desc:"جرقه‌های رعد و برقیِ آبی" },
        { key:"volcano", name:"دنباله‌ی آتشفشانی", icon:"🌋", cur:"irl", price:25000, desc:"گدازه و دودِ آتشفشانی" },
        { key:"royal", name:"دنباله‌ی سلطنتی", icon:"👑", cur:"vip", price:0, desc:"ستاره‌های طلاییِ مخصوص VIP" },
        { key:"angel", name:"دنباله‌ی فرشته‌ای", icon:"🕊️", cur:"irl", price:35000, desc:"پرهای سفید، غبار نورانی طلایی و ستاره‌های آسمانی که پشت سفینه می‌ریزند" },
        { key:"devil", name:"دنباله‌ی شیطانی", icon:"🔥", cur:"irl", price:35000, desc:"شعله‌های سیاه‌وقرمز، دود تیره و جرقه‌های گدازه‌ای پشت سفینه" }
    ],
    jump: [
        { key:"none", name:"بدون افکت", icon:"⭕", cur:"free", price:0, desc:"بدون افکت هنگام پرش" },
        { key:"ice", name:"پرش یخی", icon:"❄️", cur:"gems", price:50, desc:"تکه‌های یخ و حلقه‌ی سرما" },
        { key:"poison", name:"پرش سمی", icon:"☣️", cur:"gems", price:60, desc:"حباب‌های سبز سمی و حلقه‌ی زهرآلود" },
        { key:"pink", name:"پرش صورتی", icon:"💗", cur:"gems", price:60, desc:"قلب‌های صورتی و حلقه‌ی نرم" },
        { key:"dust", name:"گرد و غبار ماه", icon:"🌑", cur:"gems", price:70, desc:"ابرهای غبار که روی زمین پخش می‌شوند" },
        { key:"halo", name:"حلقه‌ی نور", icon:"⭕", cur:"gems", price:80, desc:"دو حلقه‌ی نورِ در حال گسترش" },
        { key:"spark", name:"جرقه‌ی برقی", icon:"⚡", cur:"gems", price:125, desc:"صاعقه‌های زرد پخش‌شونده" },
        { key:"nova", name:"پرش ابرنواختری", icon:"💥", cur:"irl", price:35000, desc:"انفجار رنگین‌کمانی با حلقه‌ی رنگی" },
        { key:"volcano", name:"پرش آتشفشانی", icon:"🌋", cur:"irl", price:25000, desc:"پرتاب گدازه به همراه دود" },
        { key:"void", name:"پرش سیاهچاله‌ای", icon:"🕳️", cur:"irl", price:30000, desc:"ذرات به درون کشیده و بعد منفجر می‌شوند" },
        { key:"royal", name:"پرش سلطنتی", icon:"👑", cur:"vip", price:0, desc:"ستاره‌های طلاییِ مخصوص VIP" },
        { key:"angel", name:"پرش فرشته‌ای", icon:"👼", cur:"irl", price:35000, desc:"بال‌های سفید باز می‌شوند، پر می‌بارد و ستون نور آسمانی می‌تابد" },
        { key:"devil", name:"پرش شیطانی", icon:"👿", cur:"irl", price:35000, desc:"پنتاگرام آتشین روی زمین، شعله‌های جهنمی و ستون نور سرخ" }
    ],
    aura: [
        { key:"none", name:"بدون هاله", icon:"⭕", cur:"free", price:0, desc:"بدون هاله" },
        { key:"pulse", name:"هاله‌ی تپنده", icon:"💙", cur:"gems", price:40, desc:"درخششِ نرمِ تپنده دور سفینه" },
        { key:"flame", name:"هاله‌ی شعله", icon:"🔥", cur:"gems", price:100, desc:"زبانه‌های آتشِ در حال چرخش" },
        { key:"ice", name:"هاله‌ی یخی", icon:"🧊", cur:"gems", price:60, desc:"بلورهای یخی که مدار می‌زنند" },
        { key:"stars", name:"هاله‌ی ستاره‌ای", icon:"✨", cur:"gems", price:70, desc:"پنج ستاره‌ی چشمک‌زن در مدارهای مختلف" },
        { key:"orbit", name:"هاله‌ی مداری", icon:"🪐", cur:"irl", price:30000, desc:"سه ذره‌ی نورانی که دور سفینه می‌چرخند" },
        { key:"storm", name:"هاله‌ی طوفانی", icon:"⛈️", cur:"irl", price:25000, desc:"ابر و رعد و برق دور سفینه" },
        { key:"plasma", name:"هاله‌ی پلاسما", icon:"🟣", cur:"irl", price:35000, desc:"چهار گوی پلاسمای رنگی با دُمِ نورانی" },
        { key:"rainbow", name:"هاله‌ی رنگین‌کمان", icon:"🌈", cur:"irl", price:35000, desc:"هشت ذره‌ی مدام‌رنگ‌عوض‌کن" },
        { key:"royal", name:"هاله‌ی سلطنتی", icon:"👑", cur:"vip", price:0, desc:"ستاره‌های طلایی و نورِ سلطنتی" },
        { key:"angel", name:"هاله‌ی فرشته‌ای", icon:"☁️", cur:"irl", price:35000, desc:"حلقه‌ی نورانی بالای سر، پرتوهای آسمانی و پرهای مداری" },
        { key:"devil", name:"هاله‌ی شیطانی", icon:"🖤", cur:"irl", price:35000, desc:"شعله‌های سیاه‌وقرمز، جرقه‌های گدازه‌ای و درخشش خون‌رنگ" }
    ],
    start: [
        { key:"none", name:"بدون افکت", icon:"⭕", cur:"free", price:0, desc:"شروع ساده" },
        { key:"flash", name:"فلاش نورانی", icon:"✨", cur:"gems", price:50, desc:"فلاشِ سفید با پرتوهای نور" },
        { key:"shock", name:"موج شوک", icon:"💥", cur:"gems", price:70, desc:"سه موج انفجاری از مرکز" },
        { key:"burst", name:"انفجار ستاره‌ای", icon:"🌟", cur:"gems", price:80, desc:"ستاره‌های رنگی از مرکز پخش می‌شوند" },
        { key:"warp", name:"جهش نوری", icon:"⚡", cur:"gems", price:75, desc:"خطوط نورِ سرعت نوری از مرکز به بیرون" },
        { key:"bolt", name:"صاعقه", icon:"🌩️", cur:"irl", price:30000, desc:"سه صاعقه‌ی شاخه‌دار با فلاش نور، حلقه‌ی ضربه روی زمین و جرقه‌های برقی دور سفینه" },
        { key:"portal", name:"پورتال کیهانی", icon:"🌀", cur:"irl", price:25000, desc:"گردابی سه‌رنگ با حلقه‌های رون، ستاره‌های پراکنده و درخششی از مرکز" },
        { key:"meteor", name:"ورود شهاب‌سنگی", icon:"☄️", cur:"irl", price:35000, desc:"بارانی از ۱۱ شهاب‌سنگ آتشین با دُم و دود، برخورد، انفجار و جرقه‌های ماندگار روی زمین" },
        { key:"void", name:"ورود سیاهچاله‌ای", icon:"🕳️", cur:"irl", price:35000, desc:"سیاهچاله‌ای که شکل می‌گیرد، ذرات را می‌بلعد، فرو می‌ریزد و با موجی که کل صفحه را موج‌دار می‌کند منفجر می‌شود" },
        { key:"royal", name:"ورود سلطنتی", icon:"👑", cur:"vip", price:0, desc:"حلقه‌های طلایی و تاج" },
        { key:"wave", name:"لرزش موجی", icon:"🌊", cur:"gems", price:120, desc:"با شروع بازی، کل صفحه موج‌دار می‌لرزد و موج‌هایی مثل آب از سفینه پخش می‌شوند" }
    ],
    ground: [
        { key:"none", name:"زمین ساده", icon:"⭕", cur:"free", price:0, desc:"زمینِ همرنگ بایوم" },
        { key:"glacier", name:"یخچال", icon:"🧊", cur:"gems", price:600, desc:"یخ براق با بلورهای تیز" },
        { key:"mars", name:"صحرای سرخ", icon:"🏜️", cur:"gems", price:700, desc:"تپه‌های ماسه‌ای سرخ، کاکتوس‌های ساده و گرد و غبار" },
        { key:"neongrid", name:"شبکه‌ی نئونی", icon:"🟪", cur:"irl", price:65000, desc:"شبکه‌ی نئونیِ صورتی و فیروزه‌ای" },
        { key:"clouds", name:"ابرهای بهشتی", icon:"☁️", cur:"gems", price:500, desc:"ابرهای پُف‌دار و پرتوهای نور" },
        { key:"diamond", name:"الماس", icon:"💎", cur:"irl", price:50000, desc:"کاشی‌های الماسی و درخشش‌های ستاره‌ای" },
        { key:"lava", name:"گدازه طلایی", icon:"🌋", cur:"irl", price:60000, desc:"رودخانه‌ی گدازه، پلیت‌های سنگی و اخگر" },
        { key:"auroraland", name:"شفق‌زار", icon:"🌌", cur:"irl", price:55000, desc:"روبان‌های شفقی که از زمین بالا می‌روند" },
        { key:"ocean", name:"اقیانوس نور", icon:"🌊", cur:"irl", price:50000, desc:"موج‌های درخشان و حلقه‌های نور" },
        { key:"cyber", name:"شهر آینده", icon:"🏙️", cur:"irl", price:60000, desc:"آسمان‌خراش‌های نئونی با پنجره‌های روشن" },
        { key:"moon", name:"سطح ماه", icon:"🌕", cur:"irl", price:65000, desc:"حرکت روی سطح ماه: دهانه‌ها، سنگ‌ها، تپه‌های دور و زمینِ درخشان در آسمان" },
        { key:"milkyway", name:"راه شیری", icon:"🌠", cur:"irl", price:55000, desc:"ستاره‌های بی‌شمار، سحابی و شهاب" },
        { key:"horizon", name:"افق رویداد", icon:"🕳️", cur:"irl", price:70000, desc:"سیاهچاله‌ای که ذرات را می‌بلعد" },
        { key:"garden", name:"باغ بهشتی", icon:"🌸", cur:"irl", price:65000, desc:"علف، گل و گلبرگ‌هایی که از راست به چپ می‌آیند" },
        { key:"royal", name:"تخت پادشاهی", icon:"👑", cur:"vip", price:0, desc:"کاشی‌های طلایی و ستون‌های سرتیز" }
    ],
    filter: [
        { key:"none", name:"بدون فیلتر", icon:"⭕", cur:"free", price:0, desc:"رنگ‌های اصلی بازی" },
        { key:"sunset", name:"طلوع صورتی", icon:"🌅", cur:"gems", price:100, desc:"آسمان نارنجی-صورتی با خورشیدِ نزدیک افق و ابرهای کشیده" },
        { key:"night", name:"شب ارغوانی", icon:"🌌", cur:"gems", price:100, desc:"ارغوانیِ عمیق با ستاره‌های چشمک‌زن، ماهِ کامل و شهاب‌های گاه‌به‌گاه" },
        { key:"emerald", name:"کهکشان زمردی", icon:"💚", cur:"gems", price:100, desc:"سبز زمردی با ذرات نورانیِ شناور و پرتوهای ملایم" },
        { key:"ocean", name:"اقیانوس عمیق", icon:"🌊", cur:"gems", price:130, desc:"آبی دریایی با موج‌های نور، پرتوهای زیرآبی و حباب‌های بالارونده" },
        { key:"frost", name:"سرمای قطبی", icon:"❄️", cur:"gems", price:150, desc:"یخ‌بندان با برف ریز، بلورهای یخی در گوشه‌های صفحه و برق‌های ستاره‌ای" },
        { key:"ember", name:"آتش‌فشان", icon:"🔥", cur:"gems", price:150, desc:"سرخیِ آتش با موج گرما، درخشش پایین صفحه و اخگرهای بالارونده" },
        { key:"bloodmoon", name:"ماه خونین", icon:"🌑", cur:"gems", price:180, desc:"آسمان سرخ با ماهِ بزرگ و خونین، ابرهای تیره، مه‌ی سرخ و خفاش‌هایی که می‌گذرند" },
        { key:"sakura", name:"شکوفه‌های بهاری", icon:"🌸", cur:"irl", price:50000, desc:"شاخه‌ی شکوفه، گلبرگ‌های درشت و واضح در حال ریزش، بوکه‌های صورتی و پرتوهای نور" },
        { key:"aurora", name:"شفق زنده", icon:"🌠", cur:"irl", price:50000, desc:"پرده‌های رنگیِ شفق با پرتوهای عمودی که موج می‌زنند و رنگ عوض می‌کنند" },
        { key:"neonstorm", name:"طوفان نئونی", icon:"🟣", cur:"irl", price:55000, desc:"بارانِ نئونی، رعد و برق صورتی و فیروزه‌ای، باریکه‌های نور و درخشش شهر" },
        { key:"royal", name:"فیلتر سلطنتی", icon:"👑", cur:"vip", price:0, desc:"طلاییِ سلطنتی با پرتوهای نور و غبار طلایی" }
    ],
    decor: [
        { key:"mistTop", name:"مه‌ی آسمانی", icon:"🌫️", cur:"gems", price:60, desc:"مه‌های نرم و کمرنگ در بالای آسمان که آرام می‌لغزند (هم‌رنگ بایوم)" },
        { key:"mistLow", name:"مه‌ی افق", icon:"☁️", cur:"gems", price:60, desc:"مه‌ی غلیظ‌تر و کمرنگ نزدیک افق که پراکنده می‌شود" },
        { key:"redplanet", name:"سیاره‌ی سرخ و ماه", icon:"🔴", cur:"gems", price:120, desc:"سیاره‌ای سرخ با قطب یخی و ماهی که دورش می‌چرخد" },
        { key:"satellite", name:"ماهواره‌ی مداری", icon:"🛰️", cur:"gems", price:90, desc:"ماهواره‌ای با پنل‌های خورشیدی و دیش که آرام در آسمان می‌گذرد" },
        { key:"nebula", name:"سحابی رنگی", icon:"🌈", cur:"gems", price:100, desc:"ابر گازیِ رنگی با ستاره‌های چشمک‌زن و غبار تیره" },
        { key:"comet", name:"ستاره‌ی دنباله‌دار", icon:"☄️", cur:"irl", price:15000, desc:"دنباله‌داری با هسته‌ی درخشان و سه دُم (یونی، غبار و جرقه) که تندتر از همه‌ی اجرام آسمان می‌گذرد" },
        { key:"ringed", name:"زحل", icon:"🪐", cur:"irl", price:25000, desc:"زحلِ غول‌پیکر با نوارهای رنگی، حلقه‌های درخشان و قمرهای کوچک که آرام از راست به چپ می‌گذرد" },
        { key:"galaxy", name:"کهکشان مارپیچ", icon:"🌌", cur:"irl", price:30000, desc:"کهکشانی مارپیچی با بازوهای پرستاره، مسیر غبار، هسته‌ی درخشان و کهکشان همراه" },
        { key:"station", name:"ایستگاه فضایی", icon:"🚀", cur:"irl", price:25000, desc:"ایستگاهی واقعی روی زمینی سنگیِ معلق در هوا؛ با در، پنجره‌های روشن، گنبد شیشه‌ای، دکل آنتن و پنل خورشیدی" },
        { key:"sun", name:"خورشید سلطنتی", icon:"☀️", cur:"vip", price:0, desc:"ویژه‌ی اعضای VIP: خورشیدی درخشان که واقعاً نور می‌دهد؛ پرتوهای چرخان، کورونا و زبانه‌های آتشین، و نور گرمی که روی تمام آسمان می‌تابد" }
    ]
};

/* ===== نسخه ۸.۰: چیدمان آیتم‌ها از ارزان به گران ===== */
/* ترتیب: رایگان ← سکه‌ای (ارزان به گران) ← الماسی (ارزان به گران) ← پولی (ارزان به گران) ← ویژه‌ی VIP.
   برای برابری قیمت، ترتیبِ تعریف حفظ می‌شود. */
const CUR_RANK = { free: 0, coins: 1, gems: 2, irl: 3, vip: 4 };
function catalogSort(arr){
    const idx = new Map(arr.map((it, i) => [it, i]));
    arr.sort((a, b) => (CUR_RANK[a.cur] - CUR_RANK[b.cur]) || ((a.price || 0) - (b.price || 0)) || (idx.get(a) - idx.get(b)));
}
CAT_ORDER.forEach(c => catalogSort(CAT_ITEMS[c]));
SK_ORDER.length = 0; CAT_ITEMS.skin.forEach(it => SK_ORDER.push(it.key));
const CAT_PREV = { skin:"ship", trail:"trail", jump:"jump", aura:"aura", start:"start", ground:"ground", filter:"filter" };
// نرخ تبدیلِ تقریبی برای نمایش درصد تخفیف (تومان)
const VAL_GEM = 85, VAL_COIN = 1.8;
function itemOf(cat, key){ return (CAT_ITEMS[cat] || []).find(i => i.key === key) || null; }
function itemValueT(it){ // ارزش تقریبی آیتم به تومان
    if(!it) return 0;
    if(it.cur === "irl") return it.price; if(it.cur === "gems") return it.price * VAL_GEM; if(it.cur === "coins") return it.price * VAL_COIN; return 0;
}
function ownsItem(cat, key){
    const d = CAT_DEF[cat], it = itemOf(cat, key); if(!it) return false;
    if(it.cur === "free") return true;
    if(it.cur === "vip") return !!data.vip;
    const o = data[d.own] || {};
    if(o[key]) return true;
    if(cat === "skin"){ const lg = SK[key] && SK[key].legacy; if(lg && data[lg]) return true; }
    return false;
}
function decorIsOn(key){ return !!(data.decorOn && data.decorOn[key] && ownsItem("decor", key)); }
function activeKeyOf(cat){ const d = CAT_DEF[cat]; if(!d.field) return null; let v = data[d.field]; if(!v || v === "default") v = d.none; return v; }
function grantItem(cat, key){
    const d = CAT_DEF[cat]; data[d.own] = data[d.own] || {}; data[d.own][key] = true;
    if(cat === "skin"){ const lg = SK[key] && SK[key].legacy; if(lg) data[lg] = true; }
}
function selectItem(cat, key){
    const d = CAT_DEF[cat];
    if(cat === "decor"){ data.decorOn = data.decorOn || {}; data.decorOn[key] = true; save(); return; }
    data[d.field] = key; save();
}
/* ---------- پک‌های همیشگی ---------- */
const PACKS = [
    { id:"pk_cool", name:"پک سفینه‌ی یخی", icon:"🧊", price:19900, items:[["skin","frost"],["trail","cyan"],["jump","ice"],["aura","ice"],["filter","frost"]], gems:0 },
    { id:"pk_fire", name:"پک شعله‌ور", icon:"🔥", price:26900, items:[["skin","magma"],["trail","ember"],["jump","spark"],["aura","flame"],["filter","ember"]], gems:20 },
    { id:"pk_neon", name:"پک نئون و سایبر", icon:"🤖", price:35900, items:[["skin","cyber"],["trail","stardust"],["start","bolt"],["ground","neongrid"],["filter","neonstorm"]], gems:30 },
    { id:"pk_cosmic", name:"پک کهکشانی", icon:"🌌", price:79000, items:[["skin","blackhole"],["trail","galaxy"],["jump","void"],["aura","plasma"],["start","void"],["ground","horizon"]], gems:60 },
    { id:"pk_solar", name:"پک خورشیدی", icon:"☀️", price:69000, items:[["skin","sun"],["trail","volcano"],["jump","volcano"],["start","meteor"],["ground","lava"]], gems:50 },
    { id:"pk_lucky1", name:"پک شانسی ستاره‌ی شب", icon:"🎲", price:50000, items:[["skin","moon"],["trail","stardust"],["jump","spark"],["aura","stars"],["start","shock"],["ground","clouds"],["filter","ocean"]], gems:40 },
    { id:"pk_lucky2", name:"پک شانسی ماجراجو", icon:"🎰", price:100000, items:[["skin","storm"],["trail","electric"],["jump","poison"],["aura","plasma"],["start","burst"],["ground","mars"],["filter","bloodmoon"]], gems:80 },
    { id:"pk_rainbow", name:"پک رنگین‌کمان", icon:"🌈", price:60000, items:[["skin","rainbow"],["trail","rainbow"],["jump","nova"],["aura","rainbow"]], gems:30 },
    { id:"pk_space", name:"پک دکور فضایی", icon:"🪐", price:50000, items:[["decor","redplanet"],["decor","satellite"],["decor","nebula"],["decor","comet"],["decor","ringed"],["decor","station"]], gems:25 },
    { id:"pk_angel", name:"پک فرشته‌ای", icon:"😇", price:100000, items:[["skin","angel"],["trail","angel"],["jump","angel"],["aura","angel"]], gems:60 },
    { id:"pk_devil", name:"پک شیطانی", icon:"😈", price:100000, items:[["skin","devil"],["trail","devil"],["jump","devil"],["aura","devil"]], gems:60 },
    { id:"pk_legend", name:"پک افسانه‌ای", icon:"🏆", price:189000, items:[["skin","storm"],["skin","nova"],["trail","rainbow"],["trail","electric"],["jump","nova"],["aura","orbit"],["aura","storm"],["start","portal"],["ground","cyber"],["ground","milkyway"],["filter","aurora"]], gems:200 }
];
function packValueT(p, onlyNotOwned){
    let v = (onlyNotOwned && data.packsBought && data.packsBought[p.id]) ? 0 : p.gems * VAL_GEM;
    p.items.forEach(([c, k]) => { if(!onlyNotOwned || !ownsItem(c, k)) v += itemValueT(itemOf(c, k)); });
    return v;
}
function packPriceFor(p){
    // قیمت کالای درون‌برنامه‌ای در مایکت برای هر SKU ثابت است؛ تخفیف شخصیِ وابسته به موجودی با SKU ثابت قابل‌اتکا نیست.
    return Math.max(2000, Math.round((Number(p.price) || 0) / 100) * 100);
}
function packDiscount(p){ const total = packValueT(p, false); return Math.max(0, Math.round((1 - p.price / total) * 100)); }
function packAllOwned(p){ return p.items.every(([c, k]) => ownsItem(c, k)) && (p.gems === 0 || !!(data.packsBought && data.packsBought[p.id])); }
/* ---------- پیشنهادهای زمان‌دار ---------- */
// afterDays: چند روز بعد از نصب نمایش داده شود، durDays: مدت اعتبار
const OFFERS = [
    { id:"of_fast", name:"پیشنهاد پیشرفت سریع", icon:"🚀", afterDays:0, durDays:5, price:19900, gems:120, coins:6000, items:[["skin","frost"],["trail","violet"]], up:{ jump:2, bold:2, dash:2 }, boost:{ head:3, shield:3 } },
    { id:"of_start", name:"پیشنهاد شروع قدرتمند", icon:"🛡️", afterDays:2, durDays:4, price:24900, gems:60, coins:15000, items:[["jump","ice"],["aura","pulse"]], power:["shield"], boost:{ shield:3, mag:3 } },
    { id:"of_style", name:"پیشنهاد استایل", icon:"✨", afterDays:3, durDays:3, price:29900, gems:100, coins:0, items:[["skin","cyber"],["trail","blueflame"],["start","burst"],["filter","bloodmoon"]] },
    { id:"of_ship", name:"پیشنهاد سفینه‌سازی", icon:"🛠️", afterDays:5, durDays:5, price:34900, gems:80, coins:10000, items:[], up:{ jump:4, bold:4, dash:4 } },
    { id:"of_night", name:"پیشنهاد شب افسانه‌ای", icon:"🌙", afterDays:7, durDays:7, price:59000, gems:150, coins:0, items:[["skin","moon"],["trail","galaxy"],["aura","stars"],["ground","clouds"]] },
    { id:"of_event", name:"پیشنهاد رویدادها", icon:"🎫", afterDays:9, durDays:1, price:21900, gems:200, coins:5000, items:[["jump","poison"],["start","shock"]] },
    { id:"of_royal", name:"پیشنهاد اسطوره‌ای", icon:"🔱", afterDays:11, durDays:6, price:89000, gems:250, coins:20000, items:[["skin","sun"],["aura","plasma"],["ground","lava"]] },
    { id:"of_max", name:"پیشنهاد سطح بالا", icon:"🏅", afterDays:13, durDays:7, price:49000, gems:300, coins:25000, items:[["skin","magma"],["jump","volcano"],["filter","ocean"]], up:{ jump:6, bold:6, dash:6 } },
    { id:"of_final", name:"پیشنهاد کلکسیونر", icon:"💠", afterDays:15, durDays:14, price:99000, gems:400, coins:30000, items:[["skin","blackhole"],["trail","electric"],["start","void"],["ground","horizon"],["filter","neonstorm"]] }
];
// ارزش مستقیمِ پیشنهاد (تومان)
const UP_COST = {
    jump: [[500,0],[1000,0],[1500,0],[2000,0],[3000,0],[4000,0],[5000,20],[6000,40],[8000,60],[10000,100]],
    bold: [[400,0],[800,0],[1200,0],[1600,0],[2400,0],[3200,0],[4000,15],[4800,30],[6400,45],[8000,75]],
    dash: [[400,0],[800,0],[1200,0],[1600,0],[2400,0],[3200,0],[4000,15],[4800,30],[6400,45],[8000,75]]
};
const POWER_VAL = { shield: Math.round(500 * VAL_GEM / VAL_COIN) };   // سپر همیشگی ۵۰۰ الماس؛ ارزش به «سکه»
function upCostSum(kind, n){ let c = 0, g = 0; for(let i = 0; i < n; i++){ c += UP_COST[kind][i][0]; g += UP_COST[kind][i][1]; } return { c, g }; }
function offerValueT(o){
    let v = o.gems * VAL_GEM + o.coins * VAL_COIN;
    (o.items || []).forEach(([c, k]) => { v += itemValueT(itemOf(c, k)); });
    if(o.up) Object.keys(o.up).forEach(k => { const s = upCostSum(k, o.up[k]); v += s.c * VAL_COIN + s.g * VAL_GEM; });
    if(o.boost){ v += ((o.boost.head || 0) * 150 + (o.boost.shield || 0) * 300 + (o.boost.mag || 0) * 220 + (o.boost.combo || 0) * 180) * VAL_COIN; }
    if(o.power) o.power.forEach(p => { v += (POWER_VAL[p] || 0) * VAL_COIN; });
    return v;
}
function offerValueRestT(o){ // ارزش چیزهایی که بازیکن هنوز ندارد (آیتم‌ها، سطح‌های ارتقا، سپر همیشگی)
    let v = o.gems * VAL_GEM + o.coins * VAL_COIN;
    (o.items || []).forEach(([c, k]) => { if(!ownsItem(c, k)) v += itemValueT(itemOf(c, k)); });
    if(o.up) Object.keys(o.up).forEach(k => {
        const have = upOwn(k), want = o.up[k];
        for(let i = have; i < want; i++) v += UP_COST[k][i][0] * VAL_COIN + UP_COST[k][i][1] * VAL_GEM;
    });
    if(o.boost){ v += ((o.boost.head || 0) * 150 + (o.boost.shield || 0) * 300 + (o.boost.mag || 0) * 220 + (o.boost.combo || 0) * 180) * VAL_COIN; }
    if(o.power) o.power.forEach(p => { if(!data[p === "shield" ? "shield" : p]) v += (POWER_VAL[p] || 0) * VAL_COIN; });
    return v;
}
function offerPriceFor(o){
    // قیمت ثابت SKU در فروشگاه؛ برای همخوانی قیمت داخل بازی و پنجره رسمی مایکت.
    return Math.max(2000, Math.round((Number(o.price) || 0) / 100) * 100);
}
function offerDiscount(o){ const v = offerValueT(o); return Math.max(0, Math.round((1 - o.price / v) * 100)); }
/* قیمت پک‌ها و پیشنهادها از روی درصد تخفیفِ هدف محاسبه می‌شود تا همیشه با ارزش واقعی محتوا هماهنگ بماند
   (پک‌ها ~۳۰٪، پیشنهادهای زمان‌دار کمی بیشتر؛ نه آن‌قدر ارزان که ضرر کنی و نه گران) */
const PACK_DISC = { pk_cool:30, pk_fire:35, pk_neon:40, pk_cosmic:40, pk_solar:40, pk_lucky1:38, pk_lucky2:40, pk_rainbow:40, pk_space:38, pk_angel:40, pk_devil:40, pk_legend:50 };
/* پیشنهادهای ویژه (محدود و زمان‌دار) باید همیشه تخفیفی بیشتر از «پک‌های همیشگی» (حداکثر ۵۰٪) داشته باشند */
const OFFER_DISC = { of_fast:75, of_start:60, of_style:58, of_ship:56, of_night:60, of_event:62, of_royal:62, of_max:65, of_final:70 };
function _priceRound(x){ return Math.max(2000, Math.round(x / 100) * 100); }
PACKS.forEach(p => { p.price = _priceRound(packValueT(p, false) * (1 - PACK_DISC[p.id] / 100)); });
OFFERS.forEach(o => { o.price = _priceRound(offerValueT(o) * (1 - OFFER_DISC[o.id] / 100)); });

/* ================================================================
   ارتقای سفینه (قدرت پرش / جسارت / زمان سرعت نهایی) و آیتم‌های قدرتی جدید
   ================================================================ */
const UP_KINDS = {
    jump: { own:"upJump", act:"upJumpAct", icon:"🦘", name:"قدرت پرش",
            desc:"پرش‌های بلندتر با نگه داشتن روی صفحه. هر سطح +۵٪ و در سطح ۱۰ جمعاً +۵۰٪ بلندتر می‌پری." },
    bold: { own:"upBold", act:"upBoldAct", icon:"🦅", name:"جسارت سفینه",
            desc:"احتمال برخورد با موانع کمتر و نزدیک‌بود بیشتر. هر سطح +۵٪ جسورتر؛ در سطح ۱۰ باید کامل به مانع بخوری تا ببازی." },
    dash: { own:"upDash", act:"upDashAct", icon:"⚡", name:"زمان سرعت نهایی",
            desc:"مدت سرعت نهایی (زنجیره‌ی ×۱۰). پایه ۲٫۵ ثانیه است و هر سطح ۰٫۳ ثانیه به آن اضافه می‌کند؛ سطح ۱۰ جمعاً ۳ ثانیه بیشتر." }
};
function faNum(n){ return String(n).replace(/\d/g, d => "۰۱۲۳۴۵۶۷۸۹"[d]); }
function upOwn(k){ return Math.max(0, Math.min(10, (data[UP_KINDS[k].own] | 0))); }
function upAct(k){ return Math.max(0, Math.min(upOwn(k), (data[UP_KINDS[k].act] | 0))); }
function jumpVy(){ return -13.4 * Math.sqrt(0.9); }   // سرعت اولیه‌ی پرش: ۱۰٪ کوتاه‌تر از قبل (کلیک سریع همیشه همین پرش آرام است)
function jumpMul(){ return 1 + 0.05 * upAct("jump"); }  // ۱٫۰ تا ۱٫۵
var jumpStartY = 0, jumpFallScale = 1, jumpApexDone = true;
// ارتقای قدرت پرش: نگه داشتن، جاذبه را موقع بالا رفتن کم می‌کند (پرش بلندتر)، کلیک سریع همان پرش پایه است،
// و پایین آمدن از ارتفاع بیشتر هم نرم‌تر می‌شود تا سفینه خیلی تند سقوط نکند.
var jumpHoldF = 0, liftCache = {};
const JUMP_TAP_FRAMES = 7;                               // نگه داشتن کمتر از ~۱۲۰ میلی‌ثانیه = کلیک سریع = همان پرش آرام پایه
function jumpSimRise(sc){                                // شبیه‌سازی گسسته‌ی همان فیزیک بازی (جاذبه ۰٫۶۸) برای محاسبه‌ی ارتفاع پرش
    const v0 = -jumpVy(), g = 0.68; let vy = -v0, rise = 0;
    for(let k = 1; k < 400; k++){ vy += g * (k > JUMP_TAP_FRAMES ? sc : 1); if(vy >= 0) break; rise -= vy; }
    return rise;
}
function jumpBaseRise(){ if(liftCache.base === undefined) liftCache.base = jumpSimRise(1); return liftCache.base; }
function liftScale(){                                    // ضریب جاذبه‌ی فاز «نگه داشتن»، طوری که ارتفاع نهایی = ضریب ارتقا × ارتفاع پایه
    const m = jumpMul(); if(m <= 1) return 1;
    const key = m.toFixed(3); if(liftCache[key] !== undefined) return liftCache[key];
    const target = m * jumpBaseRise() * 0.933; let lo = 0.05, hi = 1;   // ۰٫۹۳۳: واسنجی با فیزیک واقعی بازی
    for(let i = 0; i < 40; i++){ const mid = (lo + hi) / 2; if(jumpSimRise(mid) < target) hi = mid; else lo = mid; }
    return (liftCache[key] = (lo + hi) / 2);
}
function gravScale(dt){
    const m = jumpMul(); if(m <= 1) return 1;
    if(player.vy < 0){
        if(!jumpHeld) return 1;
        jumpHoldF += (dt || 1);
        return jumpHoldF > JUMP_TAP_FRAMES ? liftScale() : 1;
    }
    return jumpFallScale;
}
function jumpMarkStart(){ jumpStartY = player.y; jumpFallScale = 1; jumpApexDone = false; jumpHoldF = 0; }
function jumpApexCheck(){
    if(jumpApexDone || player.vy < 0) return;
    jumpApexDone = true;
    const m = jumpMul(); if(m <= 1){ jumpFallScale = 1; return; }
    const rise = Math.max(0, jumpStartY - player.y), r = Math.max(1, Math.min(m, rise / jumpBaseRise()));
    jumpFallScale = 1 / Math.pow(r, 1.0);
}
function boldFrac(){ return 0.03 * upAct("bold"); }                           // سطح ۱۰: ۳۰٪ از هر طرف کوچک‌تر
function dashDur(){ return 2.5 + 0.3 * upAct("dash"); }                       // ثانیه
function pdMul(){ return (data.powerDur && data.powerDurOn) ? 1.3 : 1; }
function meteorReach(){ return 20 - boldFrac() * 33; }
function hitP(b){
    const f = boldFrac();
    if(!f) return hit(player, b);
    const ix = player.w * f, iy = player.h * f;
    return (player.x + ix < b.x + b.w && player.x + player.w - ix > b.x && player.y + iy < b.y + b.h && player.y + player.h - iy > b.y);
}
function upLevelText(k){
    const L = upAct(k);
    if(k === "jump") return "قدرت پرش فعال: " + faNum(100 + 5 * L) + "٪";
    if(k === "bold") return "جسارت فعال: " + faNum(100 + 5 * L) + "٪";
    return "زمان سرعت نهایی فعال: " + faNum((2.5 + 0.3 * L).toFixed(1)) + " ثانیه";
}
function upPriceText(k, lv){ const c = UP_COST[k][lv - 1]; return faNum(c[0]) + " 🟡" + (c[1] ? " + " + faNum(c[1]) + " 💎" : ""); }
function renderShipUpgrades(){
    const box = el("shipUpgrades"); if(!box) return;
    let h = "";
    ["jump", "bold", "dash"].forEach(k => {
        const K = UP_KINDS[k], own = upOwn(k), act = upAct(k);
        h += '<div class="upg" data-k="' + k + '"><div class="upgHead"><b>' + K.icon + " " + K.name + '</b><span class="small">خریداری‌شده: ' + faNum(own) + " از ۱۰</span></div>";
        h += '<div class="small" style="margin:4px 0;">' + K.desc + "</div>";
        h += '<div class="small" style="color:#9dffb0;">' + upLevelText(k) + "</div>";
        h += '<div class="pips">';
        for(let i = 0; i <= 10; i++){
            const cls = "pip" + (i === act ? " act" : i <= own ? " own" : i === own + 1 ? " next" : " lock");
            h += '<button class="' + cls + '" data-up="' + k + '" data-lv="' + i + '">' + faNum(i) + "</button>";
        }
        h += "</div>";
        if(own < 10) h += '<div class="upgCtl"><button class="reward" data-upbuy="' + k + '">ارتقا به سطح ' + faNum(own + 1) + " — " + upPriceText(k, own + 1) + "</button></div>";
        else h += '<div class="upgCtl"><span class="small" style="color:#ffd447;">✅ سطح نهایی (مکس) خریداری شده است</span></div>';
        h += '<div class="small" style="margin-top:4px;">برای تغییر سطح فعال، روی عدد سطح بزن (فقط سطح‌های خریداری‌شده).</div></div>';
    });
    box.innerHTML = h;
}
function buyShipUp(k){
    const own = upOwn(k); if(own >= 10) return;
    const cost = UP_COST[k][own];
    if(data.coins < cost[0]){ toast("سکه کافی نیست"); return; }
    if(data.gems < cost[1]){ toast("الماس کافی نیست"); return; }
    data.coins -= cost[0]; data.gems -= cost[1]; statInc("coinsSpent", cost[0]); statInc("gemsSpent", cost[1]);
    data[UP_KINDS[k].own] = own + 1; data[UP_KINDS[k].act] = own + 1;
    save(); toast("✅ " + UP_KINDS[k].name + " به سطح " + faNum(own + 1) + " رسید و فعال شد");
}
function setShipUpAct(k, lv){
    const own = upOwn(k);
    if(lv > own){ toast("🔒 سطح‌ها فقط به ترتیب خریداری می‌شوند؛ اول سطح " + faNum(own + 1) + " را ارتقا بده"); return; }
    data[UP_KINDS[k].act] = lv; save(); toast("✅ سطح " + faNum(lv) + " برای " + UP_KINDS[k].name + " انتخاب شد");
}
/* آیتم‌های قدرتی جدید */
upgradeDefs.push(["btnMagRange","magRange",5000,"coins"], ["btnShieldRegen","shieldRegen",12000,"coins"], ["btnPowerDur","powerDur",20000,"coins"], ["btnComboPerm","comboPerm",7500,"coins"], ["btnSuperCoin","superCoin",200,"gems"], ["btnAntiThief","antiThief",150,"gems"]);
let shieldRegenT = 0;
function powerToggleToast(key, wasOn){ /* در buyUpgrade پیام فعال/غیرفعال نشان داده می‌شود */ }

/* ---------- دکمه‌ی حالت روح (اسکین روح فضایی) ---------- */
let ghostCd = 0;                       // ثانیه‌ی باقی‌مانده تا استفاده‌ی بعدی
const GHOST_COOLDOWN = 30;
function ghostBtnUpdate(dt){
    jumpApexCheck();
    const b = el("ghostBtn"); if(!b) return;
    const show = playing && !dying && data.skin === "phantom" && !!player;
    b.classList.toggle("hidden", !show);
    if(!show) return;
    if(ghostTimer > 0){ b.classList.add("on"); b.classList.remove("cd"); el("ghostCd").textContent = ""; return; }
    b.classList.remove("on");
    if(ghostCd > 0){ ghostCd = Math.max(0, ghostCd - dt / 60); b.classList.add("cd"); el("ghostCd").textContent = String(Math.ceil(ghostCd)); }
    else { b.classList.remove("cd"); el("ghostCd").textContent = ""; }
}
function useGhostPower(){
    if(!playing || paused || !player || data.skin !== "phantom") return;
    if(ghostTimer > 0 || ghostCd > 0){ if(ghostCd > 0) toast("👻 تا " + faNum(Math.ceil(ghostCd)) + " ثانیه‌ی دیگر قابل استفاده است"); return; }
    ghostTimer = 4.5 * pdMul(); ghostCd = GHOST_COOLDOWN; // سی ثانیه بعد از تمام شدنِ حالت روح (شمارش فقط بعد از پایان حالت روح)
    data.ghostUses = (data.ghostUses || 0) + 1;
    floatText(player.x, player.y - 14, "روح!", "#d7b3ff");
    toast("👻 حالت روح فعال شد");
    tone(520, .1, "sine", .05); setTimeout(() => tone(780, .12, "sine", .04), 60);
}

/* ================= رسم داخل بازی با موتور مشترک ================= */
var phHist = [];
function drawPlayerTrail(){
    if(data.skin !== "phantom" || !player){ phHist.length = 0; return; }
    phHist.push(player.y); if(phHist.length > 40) phHist.shift();
    const t = performance.now(), n = phHist.length;
    for(let k = 3; k >= 1; k--){   // سه سایه‌ی محو پشتِ سفینه (همان طرح پیش‌نمایش)
        const y = phHist[Math.max(0, n - 1 - k * 5)] - Math.sin(t / 340 + k) * 4;
        ctx.save(); ctx.globalAlpha = 0.32 / k; ctx.translate(player.x - k * 17 + Math.sin(t / 260 + k) * 2, y); paintShip(ctx, "phantom", t); ctx.restore();
    }
    ctx.globalAlpha = 1;
}
function drawEnvFilter(){ cxFilter(ctx, data.envFilter, W, H, performance.now(), gfxPlus()); }
function drawGround(){
    const gy = player ? player.ground : H * 0.78;
    const k = data.groundTheme, key = (k && GROUNDS[k]) ? k : "none";
    paintGround(ctx, key, W, H, gy, performance.now(), groundScroll, { plus: gfxPlus(), gr: bioCur ? bioCur.gr : null });
    if(gfxPlus()) maxGround(gy);
}
function drawAura(px, py, pass){ cxAura(ctx, data.aura, px, py, performance.now(), pass || 0, gfxPlus()); }
function drawPlayer(){
    if(!player) return;
    const p = player, px = p.x + p.w / 2, py = p.y + p.h / 2, t = performance.now();
    drawAura(px, py, 0);                       // ذره‌های پشتِ سفینه (زیر بدنه)
    if(gfxPlus()) maxPlayerFx(p, px, py);
    let alpha = 1;
    if(ghostTimer > 0) alpha = 0.55;
    if(data.skin === "phantom") alpha = ghostTimer > 0 ? 0.6 : 0.95;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(p.x, p.y);
    const squash = p.vy > 4 ? 1.08 : p.vy < -6 ? 0.92 : 1;
    ctx.translate(p.w / 2, p.h); ctx.scale(2 - squash, squash); ctx.translate(-p.w / 2, -p.h);
    paintShip(ctx, data.skin || "blue", t);
    ctx.restore();
    ctx.globalAlpha = 1;
    drawAura(px, py, 1);                       // ذره‌های جلوی سفینه (روی بدنه)
    if(player.shields > 0 && !gfxPlus()){   // هاله‌ی کمرنگ سپر (در گرافیک بالا/مکس همین هاله از افکت‌های مکس رسم می‌شود)
        ctx.save();
        const r = 42, sg = ctx.createRadialGradient(px, py, r * 0.55, px, py, r);
        sg.addColorStop(0, "rgba(120,230,255,0)"); sg.addColorStop(1, "rgba(120,230,255,0.38)");
        ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(px, py, r, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
    }
    drawSatellite();
}

/* ================================================================
   صفحه‌ی شخصی‌سازی، پیش‌نمایش‌ها، پک‌ها، پیشنهادهای ویژه و فروشگاه
   ================================================================ */
var curScreenId = "menu", startFxState = null, iapReturn = "shop";
const trailAcc = {};
function openScreen(id){
    ALL_SCREENS.forEach(s => { const n = el(s); if(n) n.classList.add("hidden"); });
    show(id); curScreenId = id;
    if(id === "shop"){ renderShipUpgrades(); }
    if(id === "customize"){ buildCustomize(); }
    if(id === "offers"){ renderOffers(); }
    if(id === "menu"){ updateOffersBadge(); maybeFirstOffer(); }
}
function itemName(cat, key){ const it = itemOf(cat, key); return it ? it.name : key; }
/* ---------- پیش‌نمایش‌ها ---------- */
const PV_W = 320, PV_H = 165;
const cxPrev = { list: [], timer: 0 };
function cxStarsBg(c, t, w, gyLimit){
    c.fillStyle = "#fff";
    for(let i = 0; i < 26; i++){
        const x = (cxHash(i) * w + 0) % w, y = cxHash(i + 40) * gyLimit * 0.95, tw = 0.35 + 0.65 * Math.abs(Math.sin(t / 700 + i));
        c.globalAlpha = 0.25 + tw * 0.55; c.fillRect(x, y, 1.4 + (i % 3) * 0.5, 1.4 + (i % 3) * 0.5);
    }
    c.globalAlpha = 1;
}
function cxScene(c, t, o){
    o = o || {};
    const bio = BIO[o.mode || "classic"], idx = o.idx === undefined ? 1.2 : o.idx, cur = bioCompute(o.mode || "classic", idx), gy = o.gy || 120;
    const g = c.createLinearGradient(0, 0, 0, PV_H); g.addColorStop(0, cur.bg[0]); g.addColorStop(0.55, cur.bg[1]); g.addColorStop(1, cur.bg[2]);
    c.fillStyle = g; c.fillRect(0, 0, PV_W, PV_H);
    paintBiomeDecor(c, o.mode || "classic", PV_W, PV_H, t, idx, gy);
    cxStarsBg(c, t, PV_W, gy);
    if(!o.noGround) paintGround(c, o.ground || "none", PV_W, PV_H, gy, t, t * 0.16, { plus: true, gr: cur.gr });
    return { gy, cur };
}
function cxShipAt(c, x, y, t, sc, key, alpha){ // x,y = گوشه‌ی بالا-چپ جعبه‌ی ۴۶×۶۰
    c.save(); c.translate(x, y); if(sc && sc !== 1){ c.translate(23, 60); c.scale(sc, sc); c.translate(-23, -60); }
    if(alpha !== undefined) c.globalAlpha = alpha;
    paintShip(c, key || data.skin || "blue", t); c.restore();
}
function cxPrevFrame(P, now){
    const c = P.c, t = now, dt = Math.max(0.2, Math.min(3, (now - P.last) / 16.667)); P.last = now;
    c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, PV_W, PV_H); c.globalAlpha = 1; c.globalCompositeOperation = "source-over";
    const skin = data.skin || "blue", phantom = skin === "phantom";
    const sAlpha = phantom ? 0.9 : undefined;
    const cat = P.cat, key = P.key;
    if(cat === "skin"){
        const sc0 = cxScene(c, t, { gy: 138 });
        const bob = Math.sin(t / 380) * 2.4, SC = 1.55;
        cxShipAt(c, 137, sc0.gy - 60 - 8 + bob, t, SC, key, (key === "phantom") ? 0.95 : undefined);
        if(key === "nova" || key === "cosmicking" || key === "neptune"){ /* ذرات ویژه‌ی اسکین‌ها در پیش‌نمایش */
            if(Math.random() < 0.3){ const a = key === "nova" ? cxPush(P.parts, { x: 160 + cxRnd(-14, 14), y: 78 + cxRnd(-16, 16), vx: cxRnd(-1, 1), vy: cxRnd(-1.6, 0.2), size: cxRnd(1.8, 3.6), dec: 0.04, g: 0.02, shape: "ball", hue: cxRnd(0, 360) })
                : cxPush(P.parts, { x: key === "cosmicking" ? 120 : 150 + cxRnd(-12, 12), y: key === "cosmicking" ? 118 : 106 + cxRnd(-8, 8), vx: key === "cosmicking" ? cxRnd(-1.8, -0.8) : cxRnd(-0.5, 0.5), vy: key === "cosmicking" ? cxRnd(-0.3, 0.3) : cxRnd(-1, -0.4), size: cxRnd(1.6, 3), dec: 0.04, g: 0, shape: "ball", col: key === "cosmicking" ? "#ffd447" : "#9fe8ff" }); }
            cxUpdateList(P.parts, dt); cxDrawList(c, P.parts, true);
        }
        if(key === "phantom"){ for(let k = 1; k <= 3; k++){ cxShipAt(c, 137 - k * 26 + Math.sin(t / 260 + k) * 3, sc0.gy - 68 + bob - Math.sin(t / 340 + k) * 4, t, SC, key, 0.32 / k); } }
    } else if(cat === "trail"){
        const sc0 = cxScene(c, t, { gy: 122 });
        const sx = 118, sy = sc0.gy - 60 + Math.sin(t / 150) * 1.2;
        if(key !== "none"){ cxEmitTrail(P.parts, key, sx + 2, sy + 40, dt, P.st, 1); }
        cxUpdateList(P.parts, dt); cxDrawList(c, P.parts, true);
        cxShipAt(c, sx, sy, t, 1, skin, sAlpha);
    } else if(cat === "jump"){
        const sc0 = cxScene(c, t, { gy: 122 });
        const cyc = ((t - P.t0) / 1000) % 1.9, sx = 137;
        if(P.jy === undefined){ P.jy = 0; P.jv = 0; P.air = false; }
        if(cyc < 0.05 && !P.air){ P.air = true; P.jv = -8.2; if(key !== "none") cxEmitJump(P.parts, key, sx + 23, sc0.gy, false, true); }
        if(P.air){ P.jv += 0.62 * dt; P.jy += P.jv * dt; if(P.jy >= 0){ P.jy = 0; P.jv = 0; P.air = false; if(key !== "none") cxEmitJump(P.parts, key, sx + 23, sc0.gy, true, true); } }
        if(cyc > 0.3 && cyc < 0.4) P.air = P.air; // (حفظ حالت)
        cxUpdateList(P.parts, dt); cxDrawList(c, P.parts, true);
        cxShipAt(c, sx, sc0.gy - 60 + P.jy, t, 1, skin, sAlpha);
    } else if(cat === "aura"){
        const sc0 = cxScene(c, t, { gy: 124 });
        const bob = Math.sin(t / 420) * 2, sx = 137, sy = sc0.gy - 64 + bob, px = sx + 23, py = sy + 30;
        cxAura(c, key, px, py, t, 0, true); cxShipAt(c, sx, sy, t, 1, skin, sAlpha); cxAura(c, key, px, py, t, 1, true);
    } else if(cat === "start"){
        const sc0 = cxScene(c, t, { gy: 122 });
        const sx = 82, sy = sc0.gy - 60;
        cxShipAt(c, sx, sy, t, 1, skin, sAlpha);
        if(key !== "none"){ const dur = STARTFX_DUR[key] || 1.5, T = (((t - P.t0) / 1000) % (dur + 0.9)); if(T <= dur) cxStartFx(c, key, sx + 23, sy + 30, T, PV_W, PV_H, true); }
    } else if(cat === "ground"){
        const gy = 104, sc0 = cxScene(c, t, { gy, ground: key });
        const sx = 62, sy = gy - 60 + Math.abs(Math.sin(t / 170)) * -2;
        cxShipAt(c, sx, sy, t, 1, skin, sAlpha);
    } else if(cat === "filter"){
        const gy = 120; cxScene(c, t, { gy });
        cxShipAt(c, 66, gy - 60, t, 1, skin, sAlpha);
        cxFilter(c, key, PV_W, PV_H, t, true);
    } else if(cat === "decor"){
        const sc0 = cxScene(c, t, { gy: 122 });
        cxDecorOne(c, key, PV_W, sc0.gy, t, true, true);
        cxShipAt(c, 40, sc0.gy - 60, t, 1, skin, sAlpha);
    } else if(cat === "sat"){
        const sc0 = cxScene(c, t, { gy: 122 }), sx = 137, sy = sc0.gy - 60 + Math.sin(t / 420) * 2, ang = t / 900;
        cxShipAt(c, sx, sy, t, 1, skin, sAlpha);
        const px = sx + 23, py = sy + 28, x = px + Math.cos(ang) * 50, y = py + Math.sin(ang) * 26;
        for(let k = 1; k <= 7; k++){ const a = ang - k * 0.17; c.globalAlpha = 0.28 * (1 - k / 8); c.fillStyle = key === "vip" ? "#ffe27a" : "#9fe3ff"; c.beginPath(); c.arc(px + Math.cos(a) * 50, py + Math.sin(a) * 26, Math.max(0.6, 2.4 - k * 0.22), 0, CX_TAU); c.fill(); }
        c.globalAlpha = 1; paintSatellite(c, x, y, ang, 1, key === "vip", t);
    }
}
function cxPrevRegister(cv, cat, key){
    const c = cv.getContext("2d");
    cxPrev.list.push({ cv, c, cat, key, parts: [], st: {}, t0: performance.now(), last: performance.now() });
}
function cxPrevTick(){
    if(curScreenId !== "customize" || !cxPrev.list.length) return;
    const root = el("customize"); if(!root || root.classList.contains("hidden")) return;
    const pr = root.getBoundingClientRect(), now = performance.now(); let n = 0;
    for(const P of cxPrev.list){
        const r = P.cv.getBoundingClientRect();
        if(r.height === 0 || r.bottom < pr.top - 10 || r.top > pr.bottom + 10) continue;
        if(++n > 12) break;
        gfxForceMax = true; try { cxPrevFrame(P, now); } catch(e){ /* پیش‌نمایش نباید بازی را خراب کند */ } finally { gfxForceMax = false; }
    }
}
function startPrevTimer(){ clearInterval(cxPrev.timer); cxPrev.timer = setInterval(cxPrevTick, 50); }

/* ---------- ساخت صفحه ---------- */
var custBuilt = false;
function itemBtnState(cat, it){
    const owned = ownsItem(cat, it.key), act = cat === "decor" ? decorIsOn(it.key) : activeKeyOf(cat) === it.key;
    if(owned && cat === "decor") return { text: act ? "✓ فعال (برای خاموش کردن بزن)" : "فعال کردن", cls: act ? "isActive" : "", owned: true, active: act };
    if(owned) return { text: act ? "✓ فعال" : "انتخاب", cls: act ? "isActive" : "", owned: true, active: act };
    if(it.cur === "vip") return { text: "👑 ویژه VIP", cls: "premium", owned: false, active: false };
    if(it.cur === "irl") return { text: faPrice(it.price) + " ت", cls: "premium", owned: false, active: false };
    if(it.cur === "gems") return { text: faPrice(it.price) + " 💎", cls: "", owned: false, active: false };
    return { text: faPrice(it.price) + " 🟡", cls: "", owned: false, active: false };
}
function buildCustomize(){
    const body = el("custBody"); if(!body) return;
    cxPrev.list = []; startPrevTimer();
    let h = '<div class="chips" id="custChips">';
    const secs = [["vip","👑 VIP"],["packs","🎁 پک‌ها"]].concat(CAT_ORDER.map(c => [c, CAT_DEF[c].title.split(" ")[0] + " " + CAT_DEF[c].title.split(" ").slice(1).join(" ")])).concat([["sat","🛰️ ماهواره"]]);
    secs.forEach(s => { h += '<button class="chip" data-goto="sec_' + s[0] + '">' + s[1] + "</button>"; });
    h += "</div>";
    /* VIP */
    h += '<div class="cSec" id="sec_vip"><h3>👑 پک VIP کیهانی</h3><div class="pack" style="border-color:#ffd447; box-shadow:0 0 16px #ffd44755;"><div class="pTitle"><span>👑 عضویت VIP کیهانی</span></div>';
    h += '<ul><li>👑 اسکین پادشاه کیهانی (تاج و شنل بنفش)</li><li>✨ هاله، دنباله، افکت پرش و ورود سلطنتی</li><li>👑 تم طلایی و سلطنتی برای منوها و صفحه‌های بازی</li><li>🏰 زمین تخت پادشاهی و فیلتر سلطنتی</li><li>☀️ دکور فضایی ویژه: خورشید سلطنتی</li><li>🛰️ ماهواره‌ی همراه طلایی</li><li>🟡 سکه دو برابر</li><li>🛡️ سپر رایگان در هر بازی</li><li>🎡 ۲ چرخش روزانه‌ی چرخ شانس</li></ul>';
    h += '<button class="iap-btn premium" id="buyVipBtn">۱۹۹,۰۰۰ ت</button></div></div>';
    /* پک‌ها */
    h += '<div class="cSec" id="sec_packs"><h3>🎁 پک‌های ویژه (همیشگی و به‌صرفه)</h3><div class="small">هر پک چند آیتم را یک‌جا و با تخفیف ثابت نسبت به خرید جداگانه می‌دهد. قیمت هر پک در مایکت ثابت است.</div><div id="packsBox"></div></div>';
    /* دسته‌ها */
    CAT_ORDER.forEach(cat => {
        h += '<div class="cSec" id="sec_' + cat + '"><h3>' + CAT_DEF[cat].title + "</h3>";
        if(cat === "ground") h += '<div class="cNote">✨ با گرافیک بالاتر، جزئیات و درخشش زمین‌ها بهتر دیده می‌شود.</div>';
        if(cat === "decor") h += '<div class="cNote">آیتم‌های پس‌زمینه‌ی بازی: چون سفینه از چپ به راست می‌دود، همه‌ی آن‌ها از راست به چپ می‌گذرند و هر کدام سرعت مخصوص خودش را دارد؛ مثلاً دنباله‌دار خیلی سریع‌تر از زحل می‌گذرد. می‌توانی چند تا را هم‌زمان روشن کنی. در گرافیک «پایین» نمایش داده نمی‌شوند.</div>';
        if(cat === "filter") h += '<div class="cNote">فیلترها با هم متفاوت‌اند و هر فیلتر به سبک خودش بازی را زیبا می‌کند. فیلتر بالای صفحه را می‌پوشاند، رنگ بایوم پایین می‌ماند و وسط ترکیبی از هر دو است.</div>';
        h += '<div class="cGrid">';
        CAT_ITEMS[cat].forEach(it => {
            h += '<div class="citem" data-cat="' + cat + '" data-key="' + it.key + '"><canvas width="' + PV_W + '" height="' + PV_H + '"></canvas><div class="nm">' + it.icon + " " + it.name + '</div><div class="ds">' + it.desc + "</div>";
            if(it.power === "ghost") h += '<div class="pw">قدرت: دارای پاورآپ حالت روح در بازی</div>';
            h += '<button data-citem="1">…</button></div>';
        });
        h += "</div></div>";
    });
    /* ماهواره */
    h += '<div class="cSec" id="sec_sat"><h3>🛰️ ماهواره‌ی همراه</h3><div class="cGrid"><div class="citem paid" id="satCard" data-cat="sat" data-key="sat"><canvas width="' + PV_W + '" height="' + PV_H + '"></canvas><div class="nm">🛰️ ماهواره‌ی همراه</div><div class="ds">ماهواره‌ای که دور سفینه می‌چرخد.<br><span style="color:#7dff9a; font-weight:bold;">قدرت: برخی موانع و دشمنان را به طور شانسی نابود می‌کند.</span></div><button id="buySatBtn">…</button></div></div></div>';
    body.innerHTML = h;
    body.querySelectorAll(".citem canvas").forEach(cv => { const card = cv.parentNode; cxPrevRegister(cv, card.dataset.cat, card.dataset.key); });
    custBuilt = true; refreshCustomize();
}
function refreshCustomize(){
    const body = el("custBody"); if(!body || !custBuilt) return;
    body.querySelectorAll(".citem[data-cat]").forEach(card => {
        const cat = card.dataset.cat; if(cat === "sat") return;
        const it = itemOf(cat, card.dataset.key); if(!it) return;
        const st = itemBtnState(cat, it), btn = card.querySelector("button");
        btn.textContent = st.text; btn.className = st.cls; btn.disabled = false;
        card.classList.toggle("active", st.active);
        card.classList.toggle("paid", !st.owned && (it.cur === "irl" || it.cur === "vip") || (st.owned && (it.cur === "irl" || it.cur === "vip")));
    });
    const sat = el("buySatBtn"), sc = el("satCard");
    if(sat){ sat.textContent = data.satelliteOwned ? (data.satellite ? "✓ فعال" : "غیرفعال — فعال کن") : faPrice(70000) + " ت"; sat.className = data.satelliteOwned ? (data.satellite ? "isActive" : "") : "premium"; if(sc) sc.classList.toggle("active", !!(data.satelliteOwned && data.satellite)); }
    const vb = el("buyVipBtn"); if(vb){ if(data.vip){ vb.textContent = "👑 VIP فعال است"; vb.disabled = true; } else { vb.textContent = "۱۹۹,۰۰۰ ت"; vb.disabled = false; } }
    renderPacks();
}
function renderPacks(){
    const box = el("packsBox"); if(!box) return;
    let h = "";
    PACKS.forEach(p => {
        const total = packValueT(p, false), all = packAllOwned(p), price = packPriceFor(p), disc = packDiscount(p);
        h += '<div class="pack"><div class="pTitle"><span>' + p.icon + " " + p.name + '</span><span class="disc">٪' + faNum(disc) + " تخفیف</span></div><ul>";
        p.items.forEach(([c, k]) => { const it = itemOf(c, k); h += "<li>" + it.icon + " " + CAT_DEF[c].title.split(" ").slice(1).join(" ") + ": " + it.name + (ownsItem(c, k) ? " ✓" : "") + "</li>"; });
        if(p.gems) h += "<li>💎 " + faNum(p.gems) + " الماس هدیه</li>";
        h += '</ul><div class="small">ارزش خرید جداگانه: <s>' + faPrice(Math.round(total / 100) * 100) + " ت</s></div>";
        h += all ? '<button disabled>✅ همه‌ی موارد این پک را داری</button>' : '<button class="iap-btn premium" data-pack="' + p.id + '">خرید پک — ' + faPrice(price) + " ت</button>";
        h += "</div>";
    });
    box.innerHTML = h;
}
function buyPack(id){
    const p = PACKS.find(x => x.id === id); if(!p || packAllOwned(p)) return;
    const price = packPriceFor(p);
    openIap(p.name, "شامل " + faNum(p.items.length) + " آیتم" + (p.gems ? " و " + faNum(p.gems) + " الماس" : ""), price, storeSku("pack", p.id), "non_consumable", () => {
        p.items.forEach(([c, k]) => grantItem(c, k));
        if(p.gems && !(data.packsBought && data.packsBought[id])) addGems(p.gems);
        data.packsBought = data.packsBought || {}; data.packsBought[id] = true;
        save(); toast("🎁 پک خریداری شد: " + p.name);
        openScreen(iapReturn || "customize"); updateUI();
    });
}
function actOnItem(cat, key){
    const it = itemOf(cat, key); if(!it) return;
    if(ownsItem(cat, key)){
        if(cat === "decor"){ data.decorOn = data.decorOn || {}; data.decorOn[key] = !data.decorOn[key]; save(); toast(data.decorOn[key] ? "✅ فعال شد: " + it.name : "غیرفعال شد: " + it.name); updateUI(); refreshCustomize(); return; }
        selectItem(cat, key); toast("✅ انتخاب شد: " + it.name); updateUI(); refreshCustomize(); return;
    }
    if(it.cur === "vip"){ toast("👑 این مورد هدیه‌ی اعضای VIP است"); return; }
    if(it.cur === "irl"){
        openIap(it.name, "آیتم بصری ویژه", it.price, storeSku("item", cat, key), "non_consumable", () => { grantItem(cat, key); selectItem(cat, key); save(); toast("✅ خریداری و انتخاب شد: " + it.name); openScreen(iapReturn || "customize"); updateUI(); });
        return;
    }
    if(it.cur === "gems"){ if(data.gems < it.price){ toast("الماس کافی نیست"); return; } data.gems -= it.price; statInc("gemsSpent", it.price); }
    else { if(data.coins < it.price){ toast("سکه کافی نیست"); return; } data.coins -= it.price; statInc("coinsSpent", it.price); }
    grantItem(cat, key); selectItem(cat, key); save();
    toast("✅ خریداری و انتخاب شد: " + it.name); updateUI(); refreshCustomize();
}
function wireCustom(){
    const on = (id, fn) => { const n = el(id); if(n) n.onclick = fn; };
    const body = el("custBody");
    if(body) body.addEventListener("click", e => {
        const chip = e.target.closest("[data-goto]");
        if(chip){ const t = el(chip.dataset.goto); if(t && t.scrollIntoView) t.scrollIntoView({ behavior: "smooth", block: "start" }); return; }
        const pk = e.target.closest("[data-pack]"); if(pk){ buyPack(pk.dataset.pack); return; }
        if(e.target.closest("#buyVipBtn")){ if(!data.vip) purchaseVipIAP(); return; }
        if(e.target.closest("#buySatBtn")){
            if(data.satelliteOwned){ data.satellite = !data.satellite; save(); toast(data.satellite ? "✅ ماهواره فعال شد" : "ماهواره غیرفعال شد"); refreshCustomize(); return; }
            openIap("ماهواره همراه", "ماهواره‌ی همراه — قدرت: برخی موانع و دشمنان را به طور شانسی نابود می‌کند.", 70000, storeSku("satellite", "companion"), "non_consumable", () => { data.satelliteOwned = true; data.satellite = true; save(); toast("✅ ماهواره خریداری و فعال شد"); openScreen(iapReturn || "customize"); updateUI(); });
            return;
        }
        const card = e.target.closest(".citem[data-cat]"), btn = e.target.closest("button[data-citem]");
        if(card && btn) actOnItem(card.dataset.cat, card.dataset.key);
    });
    on("customizeBtn", () => { updateUI(); openScreen("customize"); });
    on("shopToCustomize", () => { updateUI(); openScreen("customize"); });
    on("overCustomize", () => { commitFinalScoreIfNeeded(); updateUI(); openScreen("customize"); });
    on("closeCustomize", () => openScreen("menu"));
    on("closeCustomizeX", () => openScreen("menu"));
    on("closeShopX", () => openScreen("menu"));
    on("closeOffers", () => openScreen("menu"));
    on("closeOffersX", () => openScreen("menu"));
    on("offersBtn", () => openScreen("offers"));
    const ob = el("offersBody");
    if(ob) ob.addEventListener("click", e => { const b = e.target.closest("[data-offer]"); if(b) buyOffer(b.dataset.offer); });
    const su = el("shipUpgrades");
    if(su) su.addEventListener("click", e => {
        const b = e.target.closest("[data-upbuy]"); if(b){ buyShipUp(b.dataset.upbuy); updateUI(); return; }
        const p = e.target.closest("[data-up]"); if(p){ setShipUpAct(p.dataset.up, +p.dataset.lv); updateUI(); }
    });
    const gb = el("ghostBtn");
    if(gb){ const f = e => { e.preventDefault(); e.stopPropagation(); useGhostPower(); }; gb.addEventListener("pointerdown", f); gb.addEventListener("click", e => { e.stopPropagation(); }); }
    cxPrev.badgeTimer = setInterval(updateOffersBadge, 30000);
}

/* ---------- پیشنهادهای ویژه ---------- */
const DAY_MS = 86400000;
function syncOffers(){
    if(!data.installTs) data.installTs = Date.now();
    data.offerState = data.offerState || {};
    const now = Date.now();
    OFFERS.forEach(o => {
        const st = data.offerState[o.id], startTs = data.installTs + o.afterDays * DAY_MS;
        if(!st && now >= startTs) data.offerState[o.id] = { start: startTs, end: startTs + o.durDays * DAY_MS, bought: false };
    });
}
function activeOffers(){
    syncOffers(); const now = Date.now();
    return OFFERS.filter(o => { const st = data.offerState[o.id]; return st && !st.bought && now >= st.start && now < st.end; });
}
function timeLeftText(ms){
    const m = Math.max(1, Math.round(ms / 60000));
    if(m >= 1440) return faNum(Math.floor(m / 1440)) + " روز و " + faNum(Math.floor((m % 1440) / 60)) + " ساعت";
    if(m >= 60) return faNum(Math.floor(m / 60)) + " ساعت و " + faNum(m % 60) + " دقیقه";
    return faNum(m) + " دقیقه";
}
function updateOffersBadge(){
    const b = el("offersBtn"); if(!b) return;
    let list = []; try { list = activeOffers(); } catch(e){}
    if(!list.length){ b.classList.add("hidden"); return; }
    const first = list[0], left = data.offerState[first.id].end - Date.now();
    b.classList.remove("hidden"); b.textContent = "🔥 پیشنهاد ویژه · " + timeLeftText(left).split(" و ")[0];
}
function offerLines(o){
    const L = [];
    if(o.gems) L.push("💎 " + faNum(o.gems) + " الماس");
    if(o.coins) L.push("🟡 " + faNum(o.coins) + " سکه");
    (o.items || []).forEach(([c, k]) => { const it = itemOf(c, k); L.push(it.icon + " " + CAT_DEF[c].title.split(" ").slice(1).join(" ") + ": " + it.name + (ownsItem(c, k) ? " ✓" : "")); });
    if(o.up){ const nm = { jump: "قدرت پرش", bold: "جسارت", dash: "زمان سرعت نهایی" }; Object.keys(o.up).forEach(k => L.push("🛠️ ارتقای " + nm[k] + " تا سطح " + faNum(o.up[k]) + (upOwn(k) >= o.up[k] ? " ✓" : upOwn(k) > 0 ? " (سطح فعلی تو: " + faNum(upOwn(k)) + ")" : ""))); }
    if(o.power && o.power.indexOf("shield") >= 0) L.push("🛡️ سپر همیشگی" + (data.shield ? " ✓" : ""));
    if(o.boost){ const b = o.boost; if(b.head) L.push("🚀 " + faNum(b.head) + " شروع سریع"); if(b.shield) L.push("🛡️ " + faNum(b.shield) + " سپر شروع"); if(b.mag) L.push("🧲 " + faNum(b.mag) + " آهنربای شروع"); if(b.combo) L.push("🔗 " + faNum(b.combo) + " زره زنجیره"); }
    return L;
}
function renderOffers(){
    const box = el("offersBody"); if(!box) return;
    const list = activeOffers();
    if(!list.length){ box.innerHTML = '<div class="small" style="text-align:center; padding:18px;">فعلاً پیشنهاد فعالی نیست. چند روز دیگر دوباره سر بزن! 🎁</div>'; return; }
    let h = "";
    list.forEach(o => {
        const st = data.offerState[o.id], left = st.end - Date.now(), val = offerValueT(o);
        h += '<div class="offer"><div class="pTitle"><span>' + o.icon + " " + o.name + '</span><span class="disc">٪' + faNum(offerDiscount(o)) + ' تخفیف</span></div><div class="tm">⏳ ' + timeLeftText(left) + " مانده</div><ul>";
        offerLines(o).forEach(l => { h += "<li>" + l + "</li>"; });
        const pf = offerPriceFor(o);
        h += '</ul><div class="small">ارزش خرید جداگانه: <s>' + faPrice(Math.round(val / 100) * 100) + ' ت</s><br>قیمت این پیشنهاد در مایکت ثابت است.</div><button class="iap-btn premium" data-offer="' + o.id + '">خرید پیشنهاد — ' + faPrice(pf) + " ت</button></div>";
    });
    box.innerHTML = h;
}
function grantOffer(o){
    if(o.gems) addGems(o.gems);
    if(o.coins) data.coins += o.coins;
    (o.items || []).forEach(([c, k]) => grantItem(c, k));
    if(o.up) Object.keys(o.up).forEach(k => { const K = UP_KINDS[k]; data[K.own] = Math.max(upOwn(k), o.up[k]); data[K.act] = data[K.own]; });
    if(o.power && o.power.indexOf("shield") >= 0){ data.shield = true; data.shieldOn = true; }
    if(o.boost){ data.boostHead = (data.boostHead || 0) + (o.boost.head || 0); data.boostShield = (data.boostShield || 0) + (o.boost.shield || 0); data.boostMag = (data.boostMag || 0) + (o.boost.mag || 0); data.boostCombo = (data.boostCombo || 0) + (o.boost.combo || 0); }
}
function restoreNativeProductSku(sku){
    if(sku === storeSku("vip", "royal")){ if(!data.vip) grantRoyalPack(false); return true; }
    if(sku === storeSku("no", "ads", "forever")){ data.noAdsForever = true; data.noAdsUntil = 0; data.noAds = false; return true; }
    if(sku === storeSku("satellite", "companion")){ data.satelliteOwned = true; return true; }
    let m = /^sr_(ground|aura|skin)_([a-z0-9_]+)$/.exec(sku);
    if(m){
        const kind = m[1], key = m[2];
        if(kind === "ground"){ data.groundThemeOwned = data.groundThemeOwned || {}; data.groundThemeOwned[key] = true; return true; }
        if(kind === "aura"){ data.auraOwned = data.auraOwned || {}; data.auraOwned[key] = true; return true; }
        if(kind === "skin" && itemOf("skin", key)){ grantItem("skin", key); return true; }
    }
    m = /^sr_item_(skin|trail|jump|aura|start|ground|filter|decor)_([a-z0-9_]+)$/.exec(sku);
    if(m && itemOf(m[1], m[2])){ grantItem(m[1], m[2]); return true; }
    m = /^sr_pack_([a-z0-9_]+)$/.exec(sku);
    if(m){
        const pack = PACKS.find(p => p.id === m[1]);
        if(pack){
            // در بازیابی مالکیت دائمی، فقط آیتم‌های ماندگار برگردانده می‌شوند.
            // الماس هدیه یک پاداش یک‌باره است و باید از صف امن pendingPurchaseGrants تحویل شود.
            pack.items.forEach(([cat, key]) => grantItem(cat, key));
            data.packsBought = data.packsBought || {}; data.packsBought[pack.id] = true;
            return true;
        }
    }
    m = /^sr_offer_([a-z0-9_]+)$/.exec(sku);
    if(m){
        const offer = OFFERS.find(o => o.id === m[1]);
        if(offer){
            // آیتم‌ها، ارتقاها و سپر دائمی قابل بازیابی‌اند؛ ارزها و بوست‌های یک‌باره نیستند.
            (offer.items || []).forEach(([cat, key]) => grantItem(cat, key));
            if(offer.up) Object.keys(offer.up).forEach(k => { const K = UP_KINDS[k]; data[K.own] = Math.max(upOwn(k), offer.up[k]); data[K.act] = data[K.own]; });
            if(offer.power && offer.power.indexOf("shield") >= 0){ data.shield = true; }
            data.offerState = data.offerState || {}; data.offerState[offer.id] = data.offerState[offer.id] || {};
            data.offerState[offer.id].bought = true;
            return true;
        }
    }
    return false;
}
function applyPendingNativePurchaseGrant(grant){
    if(!grant || typeof grant.grantId !== "string" || !grant.grantId || typeof grant.productId !== "string") return false;
    data.nativeGrantIds = Array.isArray(data.nativeGrantIds) ? data.nativeGrantIds : [];
    if(data.nativeGrantIds.includes(grant.grantId)) return true;
    let applied = false;
    let m = /^sr_gems_(\d+)_\d+$/.exec(grant.productId);
    if(m){ addGems(Math.max(1, Math.min(100000, Number(m[1]) || 0))); applied = true; }
    m = /^sr_pack_([a-z0-9_]+)$/.exec(grant.productId);
    if(m){
        const pack = PACKS.find(p => p.id === m[1]);
        if(pack){
            pack.items.forEach(([cat, key]) => grantItem(cat, key));
            if(pack.gems) addGems(pack.gems);
            data.packsBought = data.packsBought || {}; data.packsBought[pack.id] = true;
            applied = true;
        }
    }
    m = /^sr_offer_([a-z0-9_]+)$/.exec(grant.productId);
    if(m){
        const offer = OFFERS.find(o => o.id === m[1]);
        if(offer){
            grantOffer(offer);
            data.offerState = data.offerState || {}; data.offerState[offer.id] = data.offerState[offer.id] || {};
            data.offerState[offer.id].bought = true;
            applied = true;
        }
    }
    if(!applied) return false;
    data.nativeGrantIds.push(grant.grantId);
    data.nativeGrantIds = data.nativeGrantIds.slice(-500);
    saveData();
    return true;
}
async function acknowledgeNativePurchaseGrant(grant){
    try{
        const result = await callSpaceRunnerNative("acknowledgePurchaseGrant", { grantId:grant.grantId, productId:grant.productId }, 15000);
        if(!result || result.ok !== true) throw new Error("native_grant_acknowledgement_failed");
        return true;
    }catch(e){
        // تا تأیید صریح این پیام، لایه‌ی بومی باید رکورد تحویل را برای تلاش بعدی نگه دارد.
        return false;
    }
}

async function syncNativeEntitlements(){
    if(!nativeBridgeAvailable()) return;
    try{
        const result = await callSpaceRunnerNative("syncEntitlements", {}, 30000);
        if(result.ok !== true) return;
        let changed = false;
        const owned = Array.isArray(result.ownedNonConsumableProductIds) ? result.ownedNonConsumableProductIds : [];
        data.nativeRestoredSkus = Array.isArray(data.nativeRestoredSkus) ? data.nativeRestoredSkus : [];
        owned.forEach(sku => {
            if(typeof sku !== "string" || data.nativeRestoredSkus.includes(sku)) return;
            if(restoreNativeProductSku(sku)){
                data.nativeRestoredSkus.push(sku); changed = true;
            }
        });
        // رکوردهای تحویلِ یک‌باره تا ذخیره موفق در بازی و تأیید دریافت، در لایه بومی باقی می‌مانند.
        const pending = []
            .concat(Array.isArray(result.pendingConsumableGrants) ? result.pendingConsumableGrants : [])
            .concat(Array.isArray(result.pendingPurchaseGrants) ? result.pendingPurchaseGrants : []);
        for(const grant of pending){
            const had = Array.isArray(data.nativeGrantIds) && data.nativeGrantIds.includes(grant && grant.grantId);
            const applied = applyPendingNativePurchaseGrant(grant);
            if(applied){
                if(!had) changed = true;
                await acknowledgeNativePurchaseGrant(grant);
            }
        }
        if(changed){ data.nativeRestoredSkus = data.nativeRestoredSkus.slice(-300); data.nativeGrantIds = data.nativeGrantIds.slice(-300); saveData(); updateUI(); updateExtraUI(); }
    }catch(e){ /* اگر مایکت نصب/متصل نبود، اجرای آفلاین بازی ادامه پیدا می‌کند. */ }
}

function buyOffer(id){
    const o = OFFERS.find(x => x.id === id), st = data.offerState && data.offerState[id];
    if(!o || !st || st.bought || Date.now() >= st.end){ toast("این پیشنهاد دیگر فعال نیست"); renderOffers(); return; }
    openIap(o.name, offerLines(o).join(" + ").replace(/[✓]/g, ""), offerPriceFor(o), storeSku("offer", o.id), "non_consumable", () => {
        const s2 = data.offerState[id]; if(!s2 || s2.bought) return;
        s2.bought = true; grantOffer(o); save(); toast("🎁 پیشنهاد خریداری شد!");
        openScreen("offers"); updateUI(); updateOffersBadge();
    });
}
function maybeFirstOffer(){
    if(data.offerFirstShown || !data.seenTutorial) return;
    data.offerFirstShown = true; save();
    setTimeout(() => { if(curScreenId === "menu" && !playing){ toast("🎁 پیشنهاد ویژه‌ی پیشرفت سریع برای تو آماده است!"); openScreen("offers"); } }, 900);
}

/* ---------- فروشگاه (بدون موارد ظاهری) ---------- */
function updateShop(){
    updateRateBoxes();
    const na = el("buyNoAds");
    if(na){ if(hasNoAds()){ na.textContent = "🚫 فعال — همیشگی"; na.disabled = true; } else { na.textContent = "۹۹,۰۰۰ ت"; na.disabled = false; na.onclick = () => purchaseNoAdsIAP(); } }
    const tk = (id, flag, price) => { const b = el(id); if(b) b.textContent = data[flag] ? "✓ فعال (بازی بعدی)" : price + " 💎"; };
    tk("buyTicketRG", "guaranteedRewardGalaxy", PRICE.ticketRG); tk("buyTicketBH", "guaranteedBlackHole", PRICE.ticketBH);
    tk("buyTicketDS", "guaranteedDiamondShower", PRICE.ticketDS); tk("buyTicketIce", "guaranteedIceStorm", PRICE.ticketIce); tk("buyTicketFlare", "guaranteedSolarFlare", PRICE.ticketFlare);
    const gb = el("btnReviveShieldGem");
    if(gb){
        if(data.reviveShield){ gb.textContent = data.reviveShieldOn ? "فعال ✓" : "غیرفعال"; gb.className = data.reviveShieldOn ? "reward" : "secondary"; }
        else { gb.textContent = faNum(REVIVE_SHIELD_GEMS) + " 💎"; gb.className = "premium"; }
    }
    upgradeDefs.forEach(([id, key, price, currency]) => {
        const b = el(id); if(!b) return;
        if(!data[key]){ b.textContent = currency === "gems" ? price + " 💎" : faPrice(price) + " 🟡"; b.className = ""; }
        else { b.textContent = data[key + "On"] ? "فعال ✓" : "غیرفعال"; b.className = data[key + "On"] ? "reward" : "secondary"; }
    });
    const cnt = (id, k) => { const n = el(id); if(n) n.textContent = data[k] ? "(" + data[k] + ")" : ""; };
    cnt("cntHead", "boostHead"); cnt("cntShield", "boostShield"); cnt("cntMag", "boostMag"); cnt("cntCombo", "boostCombo");
    if(curScreenId === "shop") renderShipUpgrades();
}

/* ================= مهاجرت داده‌ها به نسخه‌ی جدید ================= */
function migrateV90(){
    const d = data;
    ["trailOwned","jumpEffectOwned","auraOwned","startFxOwned","groundThemeOwned","filterOwned","skinOwned","packsBought","offerState","decorOwned","decorOn"].forEach(k => { d[k] = d[k] || {}; });
    // مقدارهای قدیمیِ «default» یعنی بدون افکت
    ["trailColor","jumpEffect","aura","startFx","groundTheme","envFilter"].forEach(k => { if(!d[k] || d[k] === "default") d[k] = "none"; });
    // اسکین‌های قدیمی -> نقشه‌ی مالکیت جدید
    Object.keys(SK).forEach(k => { const lg = SK[k].legacy; if(lg && d[lg]) d.skinOwned[k] = true; });
    // حذف اسکین طلایی: اگر خریده بود، پولش برمی‌گردد
    if(d.skinGold && !d.goldSkinRefunded){ d.coins = (d.coins || 0) + 4500; d.goldSkinRefunded = true; d.skinGold = false; }
    if(d.skin === "gold" || !SK[d.skin]) d.skin = "blue";
    // حذف افکت پرش ستاره‌ای: اگر خریده بود، الماسش برمی‌گردد
    if(d.jumpEffectOwned && d.jumpEffectOwned.stars && !d.starsJumpRefunded){ d.gems = (d.gems || 0) + 55; d.starsJumpRefunded = true; }
    if(d.jumpEffectOwned) delete d.jumpEffectOwned.stars;
    if(d.jumpEffect === "stars") d.jumpEffect = "none";
    // اگر مقدارِ انتخاب‌شده وجود ندارد یا مالکش نیست، به پیش‌فرض برگرد
    CAT_SINGLE.forEach(cat => {
        const f = CAT_DEF[cat].field, v = d[f];
        if(!itemOf(cat, v) || !ownsItem(cat, v)) d[f] = CAT_DEF[cat].none;
    });
    // ارتقاهای سفینه
    ["upJump","upJumpAct","upBold","upBoldAct","upDash","upDashAct"].forEach(k => { d[k] = Math.max(0, Math.min(10, d[k] | 0)); });
    ["jump","bold","dash"].forEach(k => { const K = UP_KINDS[k]; if(d[K.act] > d[K.own]) d[K.act] = d[K.own]; });
    // آیتم‌های قدرتیِ جدید
    ["magRange","shieldRegen","powerDur","comboPerm","superCoin","antiThief"].forEach(k => { d[k] = !!d[k]; d[k + "On"] = !!d[k + "On"]; });
    // سطح گرافیک: «بالا»ی قدیمی همان «متوسط» جدید است
    if(!d.gfxV90){
        d.gfxV90 = true;
        const brandNew = !d.seenTutorial && !(d.games > 0);
        if(brandNew) d.gfx = "high";                                   // بازیکن جدید: گرافیک «بالا»
        else if(d.gfx === "high" || d.gfx === "medium" || !d.gfx) d.gfx = "medium";   // «بالا»ی قدیمی = «متوسط» جدید
        else if(d.gfx !== "max" && d.gfx !== "low") d.gfx = "medium";
    }
    d.invited = !!d.invited;
    if(!d.installTs) d.installTs = Date.now();
    syncOffers();
}

/* ================= رمز بازیابی: فقط با رمز، روی همین گوشی؛ روی گوشی دیگر با «کد انتقال» ================= */
const REC_LS = "spaceRunnerRecV1";
function wireRecovery(){
    const on = (id, fn) => { const n = el(id); if(n) n.onclick = fn; };
    on("recMake", () => {
        const pw = (el("recPassC").value || "").trim();
        if(pw.length < 3){ toast("رمز باید حداقل ۳ کاراکتر باشد"); return; }
        const code = generateRecoveryCode(pw);
        if(!code){ toast("ساخت رمز انجام نشد، دوباره تلاش کن"); return; }
        try { localStorage.setItem(REC_LS, code); } catch(e){}
        el("recOut").value = code; show("recOutWrap");
        data.recoverySet = true; saveData();
        toast("✅ رمز بازیابی ساخته شد");
    });
    on("recDo", () => {
        const pw = (el("recPassR").value || "").trim(), msg = el("recMsg");
        if(!pw){ msg.textContent = "رمز بازیابی را وارد کن"; return; }
        let code = (el("recIn").value || "").trim(), fromLocal = false;
        if(!code){ try { code = localStorage.getItem(REC_LS) || ""; fromLocal = true; } catch(e){ code = ""; } }
        if(!code){ msg.textContent = "کدی روی این گوشی پیدا نشد. اگر بازی را حذف کرده بودی یا روی گوشی دیگری هستی، کد انتقالِ ذخیره‌شده‌ات را در کادرِ «کد انتقال» بچسبان و رمزت را بزن."; return; }
        const restored = restoreFromRecoveryCode(code, pw);
        if(!restored){ msg.textContent = fromLocal ? "رمز اشتباه است" : "رمز یا کد انتقال اشتباه است"; return; }
        data = restored;
        try { migrateV80(); } catch(e){}
        try { migrateV90(); } catch(e){}
        sanitizeLoadedData(); securityPass();
        saveData(); applyTheme(); updateUI(); updateExtraUI(); openScreen("menu");
        toast("✅ حساب با موفقیت بازیابی شد!");
    });
}

/* ================= اشتراک‌گذاری و دعوت از دوستان ================= */
function inviteMessage(){
    const name = (data.nickname || "").trim();
    return "🚀 دونده فضایی؛ یه بازی فضایی که ولش کردنش سخته!\n\n" +
        (name ? "من (" + name + ") دارم بازی می‌کنم و حسابی درگیرشم. " : "") +
        "با سفینه‌ات از بین شهاب‌سنگ‌ها و دشمن‌ها فرار کن، سکه و الماس جمع کن و با ۵ مود مختلف، رویدادهای هیجان‌انگیز، اسکین‌ها و افکت‌های خفن، برای رکورد بالاتر بجنگ.\n\n" +
        "🎁 رایگانه! ببین تا کجا می‌تونی دووم بیاری و رکوردمو بشکنی 😉\n\n" +
        "📲 بازی دونده فضایی رو می‌تونی همین حالا از مایکت دانلود کنی!";
}
function scoreMessage(){
    const name = (data.nickname || "").trim() || "یه فضانورد";
    return "🏆 " + name + " توی «دونده فضایی» " + Math.floor(score) + " امتیاز گرفت!\n" +
        "⭐ بهترین رکوردم: " + (data.best | 0) + "\n\n" +
        "فکر می‌کنی می‌تونی رکوردمو بشکنی؟ 😎🚀\n\n" +
        "📲 دونده فضایی رو همین حالا از مایکت دانلود کن و ثابت کن!";
}
/* لینک دانلود بازی (اختیاری): اگر پر شود، به همه‌ی پیام‌های دعوت اضافه می‌شود */
const GAME_LINK = "";
/* باز کردن لینک بیرونی به مطمئن‌ترین روش ممکن (مرورگر، وب‌ویو، Capacitor/Cordova). برنامه‌ی بازی هرگز جابه‌جا نمی‌شود. */
function openExternal(url, blank){
    try { const cap = window.Capacitor, br = cap && cap.Plugins && cap.Plugins.Browser; if(br && br.open){ br.open({ url }); return true; } } catch(e){}
    try { if(window.cordova && window.cordova.InAppBrowser){ window.cordova.InAppBrowser.open(url, "_system"); return true; } } catch(e){}
    try {
        const a = document.createElement("a"); a.href = url; if(blank !== false){ a.target = "_blank"; a.rel = "noopener noreferrer"; }
        a.style.display = "none"; document.body.appendChild(a); a.click(); setTimeout(() => { try { a.remove(); } catch(e){} }, 800); return true;
    } catch(e){}
    try { const w = window.open(url, blank === false ? "_self" : "_blank"); if(w) return true; } catch(e){}
    return false;
}
function copyTextPlain(text, okMsg){
    const fb = () => { try { const ta = document.createElement("textarea"); ta.value = text; ta.style.cssText = "position:fixed;opacity:0;left:-999px;"; document.body.appendChild(ta); ta.focus(); ta.select(); const ok = document.execCommand("copy"); ta.remove(); toast(ok ? okMsg : "متن را نگه دار و کپی کن"); } catch(e){ toast("متن را نگه دار و کپی کن"); } };
    try { if(navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(() => toast(okMsg)).catch(fb); else fb(); } catch(e){ fb(); }
}
function shareText(title, text){ openShareSheet(text); }
function openShareSheet(text){
    const box = el("shareText"); if(box) box.value = text + (GAME_LINK ? "\n" + GAME_LINK : "");
    const sb = el("shareSystemBtn"); if(sb) sb.classList.toggle("hidden", !(navigator.share));
    show("shareSheet");
}
function copyShareText(){ copyTextPlain((el("shareText") && el("shareText").value) || "", "✅ متن کپی شد"); }
const SHARE_SITES = { rubika: ["روبیکا", "https://rubika.ir/"], splus: ["سروش پلاس", "https://splus.ir/"], shad: ["شاد", "https://shad.ir/"], igap: ["آی‌گپ", "https://igap.net/"], gap: ["گپ", "https://gap.im/"] };
function shareVia(kind){
    const text = (el("shareText") && el("shareText").value) || "", enc = encodeURIComponent(text), lk = encodeURIComponent(GAME_LINK || " ");
    if(kind === "copy"){ copyShareText(); return; }
    if(kind === "system"){ try { navigator.share({ title: "دونده فضایی", text }).catch(() => {}); } catch(e){ copyShareText(); } return; }
    if(SHARE_SITES[kind]){   // برنامه‌هایی که لینک اشتراکِ رسمی ندارند: متن کپی می‌شود، بعد برنامه/سایت رسمی باز می‌شود (برای نصب یا ورود)
        copyTextPlain(text, "✅ متن کپی شد؛ در " + SHARE_SITES[kind][0] + " «Paste» کن");
        setTimeout(() => openExternal(SHARE_SITES[kind][1]), 700); return;
    }
    let url = "";
    if(kind === "telegram") url = "https://t.me/share/url?url=" + lk + "&text=" + enc;
    else if(kind === "whatsapp") url = "https://wa.me/?text=" + enc;
    else if(kind === "eitaa") url = "https://eitaa.com/share/url?url=" + lk + "&text=" + enc;
    else if(kind === "bale") url = "https://ble.ir/share/url?url=" + lk + "&text=" + enc;
    else if(kind === "sms") url = "sms:?&body=" + enc;
    else if(kind === "mail") url = "mailto:?subject=" + encodeURIComponent("دونده فضایی") + "&body=" + enc;
    if(!url) return;
    copyTextPlain(text, "✅ متن کپی شد (اگر خالی باز شد، «Paste» کن)");   // پشتیبانِ همیشگی: اگر برنامه متن را از لینک نگرفت، بازیکن می‌تواند Paste کند
    openExternal(url, kind === "sms" || kind === "mail" ? false : true);
}
function shareRun(){ shareText("دونده فضایی", scoreMessage()); }
function inviteFriends(){
    data.invited = true; save(); updateRateBoxes();
    shareText("دعوت به دونده فضایی", inviteMessage());
}
function wireShare(){
    document.querySelectorAll(".inviteBtn").forEach(b => { b.onclick = () => inviteFriends(); });
    const sb = el("shareSheet");
    if(sb) sb.addEventListener("click", e => { const b = e.target.closest("[data-share]"); if(b) shareVia(b.dataset.share); });
    const cl = el("closeShareSheet"); if(cl) cl.onclick = () => hide("shareSheet");
}


/* ================================================================
   اعداد فارسی در همه‌جای بازی
   هر عددی که در صفحه نوشته شود (قیمت، امتیاز، آمار، پیام‌ها و…) خودکار به رقم‌های فارسی تبدیل می‌شود.
   کادرهای ورودی/متنی (مثل کد انتقال) و مقدارهای فنی دست‌نخورده می‌مانند.
   ================================================================ */
const FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";
function toFaDigits(str){ return String(str).replace(/[0-9]/g, d => FA_DIGITS[d | 0]); }
let faObserver = null;
function faSkip(node){
    const par = node.parentNode; if(!par || par.nodeType !== 1) return false;
    const tn = par.tagName;
    return tn === "TEXTAREA" || tn === "INPUT" || tn === "SCRIPT" || tn === "STYLE" || (par.closest && !!par.closest("[data-ascii]"));
}
function faFixText(node){
    if(!node || node.nodeType !== 3) return;
    const v = node.nodeValue;
    if(!v || !/[0-9]/.test(v) || faSkip(node)) return;
    node.nodeValue = toFaDigits(v);
}
function faFixTree(node){
    if(!node) return;
    if(node.nodeType === 3){ faFixText(node); return; }
    if(node.nodeType !== 1 || node.tagName === "TEXTAREA" || node.tagName === "SCRIPT" || node.tagName === "STYLE") return;
    const w = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
    let n; while((n = w.nextNode())) faFixText(n);
}
function installFaDigits(){
    if(faObserver) return;
    faFixTree(root);
    faObserver = new MutationObserver(recs => {
        for(const r of recs){
            if(r.type === "characterData") faFixText(r.target);
            else r.addedNodes.forEach(faFixTree);
        }
    });
    faObserver.observe(root, { childList: true, subtree: true, characterData: true });
}


/* ================================================================
   بررسی یکپارچگی داده (بعد از بارگذاری و بعد از بازیابی با کد)
   اگر داده دستکاری شده باشد (آیتمِ نخریده، الماسِ بی‌منبع، سطح غیرمجاز…) به حالت منطقی برمی‌گردد.
   ================================================================ */
const MODE_KEYS = ["classic", "time", "hard", "impossible", "aurora"];
function securityPass(){
    ["coins", "gems"].forEach(k => { const v = Math.floor(+data[k]); data[k] = (Number.isFinite(v) && v > 0) ? v : 0; });
    // همه‌ی الماس‌ها فقط از مسیر addGems وارد می‌شوند؛ پس الماسِ موجود هیچ‌وقت از «کل الماس‌های دریافتی» بیشتر نیست
    if(!data.gemInv){ data.totalGems = Math.max(+data.totalGems || 0, data.gems); data.gemInv = true; }
    else if(data.gems > (+data.totalGems || 0)) data.gems = Math.floor(+data.totalGems || 0);
    // نقشه‌های مالکیت: فقط کلیدهای واقعیِ کاتالوگ با مقدار true
    CAT_ORDER.forEach(cat => {
        const d = CAT_DEF[cat], src = data[d.own], clean = {};
        if(src && typeof src === "object" && !Array.isArray(src)){
            Object.keys(src).forEach(k => { if(src[k] && itemOf(cat, k) && itemOf(cat, k).cur !== "free") clean[k] = true; });
        }
        data[d.own] = clean;
    });
    // آیتم فعال باید مال بازیکن باشد
    CAT_SINGLE.forEach(cat => {
        const d = CAT_DEF[cat], v = data[d.field];
        if(v && v !== "default" && v !== d.none && !ownsItem(cat, v)) data[d.field] = d.none;
    });
    if(data.decorOn && typeof data.decorOn === "object"){
        Object.keys(data.decorOn).forEach(k => { if(!itemOf("decor", k) || !ownsItem("decor", k)) delete data.decorOn[k]; });
    } else data.decorOn = {};
    // اطلس کیهانی
    const cc = {}; if(data.codexClaim && typeof data.codexClaim === "object" && !Array.isArray(data.codexClaim)) CODEX_EVENTS.forEach(ev => { const v = Math.floor(+data.codexClaim[ev.k]) || 0; if(v > 0) cc[ev.k] = Math.min(5, v); });
    data.codexClaim = cc;
    // پاداش‌های بزرگ ماموریت‌ها
    data.dailyBonusClaim = !!data.dailyBonusClaim; data.weeklyBonusClaim = !!data.weeklyBonusClaim;
    // سطح ارتقاهای سفینه
    UP_KEYS_ALL.forEach(k => {
        const U = UP_KINDS[k], own = Math.max(0, Math.min(10, Math.floor(+data[U.own]) || 0)), act = Math.max(0, Math.min(own, Math.floor(+data[U.act]) || 0));
        data[U.own] = own; data[U.act] = act;
    });
    if(MODE_KEYS.indexOf(data.mode) < 0 && data.mode !== undefined) delete data.mode;
}
const UP_KEYS_ALL = ["jump", "bold", "dash"];

/* ================================================================
   ارتباط با پشتیبانی: باز کردن برنامه‌ی ایمیل گوشی (بدون نیاز به سرور)
   ================================================================ */
const SUPPORT_EMAIL = "erfanfirestar777@gmail.com";
function supportSubject(){ return "پشتیبانی دونده فضایی (نسخه " + toFaDigits(GAME_VERSION) + ")"; }
function supportBody(){ return "سلام،\n\n(پیام، مشکل یا پیشنهاد خودت را اینجا بنویس)\n\n\n— اطلاعات بازی (لطفاً حذف نشود) —\nنسخه‌ی بازی: " + toFaDigits(GAME_VERSION) + "\nسطح: " + toFaDigits(data.level || 1) + "\nرکورد: " + toFaDigits(Math.floor(data.best || 0)); }
function openSupportSheet(){ show("supportSheet"); }
function copySupportAddr(){ copyTextPlain(SUPPORT_EMAIL, "✅ آدرس ایمیل کپی شد"); }
function wireSupport(){
    const on = (id, fn) => { const n = el(id); if(n) n.onclick = fn; };
    on("supportMail", openSupportSheet);
    on("supportCopy", copySupportAddr);
    on("supMail", () => { copyTextPlain(SUPPORT_EMAIL, "آدرس ایمیل کپی شد"); openExternal("mailto:" + SUPPORT_EMAIL + "?subject=" + encodeURIComponent(supportSubject()) + "&body=" + encodeURIComponent(supportBody()), false); });
    on("supGmail", () => openExternal("https://mail.google.com/mail/?view=cm&fs=1&to=" + encodeURIComponent(SUPPORT_EMAIL) + "&su=" + encodeURIComponent(supportSubject()) + "&body=" + encodeURIComponent(supportBody()), true));
    on("supCopyAddr", copySupportAddr);
    on("supCopyMsg", () => copyTextPlain(supportBody(), "✅ پیام آماده کپی شد"));
    on("closeSupportSheet", () => hide("supportSheet"));
}

/* ---------- وقتی کیبورد (یا پنجره‌ی دیگری مثل چت) بخشی از صفحه را می‌پوشاند ----------
   ناحیه‌ی بازی به اندازه‌ی «بخش دیده‌شده» کوچک می‌شود و فیلدِ در حالِ تایپ همیشه وسط بخش دیده‌شده می‌آید؛ پس نوشتن (رمز بازیابی و…) همیشه دیده و ممکن است. */
function installViewportFix(){
    const vv = window.visualViewport;
    const isField = n => n && (n.tagName === "INPUT" || n.tagName === "TEXTAREA");
    const bring = () => { const a = document.activeElement; if(isField(a)){ try { a.scrollIntoView({ block: "center", behavior: "smooth" }); } catch(e){} } };
    const apply = () => {
        if(!vv) return;
        const covered = (window.innerHeight - vv.height) > 80;
        if(covered){ root.style.bottom = "auto"; root.style.top = vv.offsetTop + "px"; root.style.height = vv.height + "px"; root.style.setProperty("--vvh", vv.height + "px"); }
        else { root.style.top = ""; root.style.bottom = ""; root.style.height = ""; root.style.removeProperty("--vvh"); }
        if(covered) setTimeout(bring, 80);
    };
    if(vv){ vv.addEventListener("resize", apply); vv.addEventListener("scroll", apply); }
    document.addEventListener("focusin", e => { if(isField(e.target)){ setTimeout(apply, 220); setTimeout(bring, 360); } });
    document.addEventListener("focusout", () => setTimeout(apply, 220));
}
function bootExtra(){
    migrateV80();
    migrateV90();
    sanitizeLoadedData();
    securityPass();
    saveData();
    window.setMode = m => { if(MODE_KEYS.indexOf(m) >= 0) setMode(m); };
    window.setSkin = k => { if(ownsItem("skin", k)) setSkin(k); };
    wireAll();
    wireCustom();
    wireShare();
    wireRecovery();
    wireSupport();
    installViewportFix();
    fillMissionRewardTexts();
    installFaDigits();
    addEventListener("resize", resize);
    applyTheme();
    updateUI();
    updateExtraUI();
    resize();
    updateOffersBadge();
    // قفل‌گشایی صدا: مرورگرها صدا را تا اولین «لمس واقعی» قفل نگه می‌دارند. اینجا همه‌ی رویدادهای لمس/کلیک را
    // تا لحظه‌ای که صدا واقعاً روشن شود گوش می‌دهیم (قبلاً فقط یک‌بار گوش می‌داد و همین باعث «قفل شدن و ناگهان فعال شدن» بود).
    const unlockEvents = ["touchend","pointerup","click","mousedown","keydown","touchstart","pointerdown"];
    let unlockTimer = 0;
    const stopUnlock = () => { unlockEvents.forEach(e => document.removeEventListener(e, tryUnlock, true)); clearInterval(unlockTimer); };
    function tryUnlock(){
        try { initAudio(); } catch(e){}
        if(!audio) return;
        if(audio.state === "running"){ stopUnlock(); return; }
        try { const p = audio.resume(); if(p && p.then) p.then(() => { if(audio.state === "running") stopUnlock(); }).catch(() => {}); } catch(e){}
    }
    unlockEvents.forEach(e => document.addEventListener(e, tryUnlock, { capture:true, passive:true }));
    unlockTimer = setInterval(tryUnlock, 600);
    tryUnlock(); // اگر مرورگر/وب‌ویو اجازه‌ی پخش خودکار بدهد، آهنگ منو همین الان و بدون هیچ لمسی شروع می‌شود
    window.__SPACE_RUNNER__ = { version: GAME_VERSION, ready: true };
    window.__gameReady = true;
    // بازی بدون اینترنت هم بالا می‌آید. منتظر آماده‌شدن SDK پرداخت می‌مانیم تا sync اولیه
    // پیش از برقراری اتصال مایکت از دست نرود.
    window.onSpaceRunnerBillingReady = () => syncNativeEntitlements();
    if(window.__SPACE_RUNNER_BILLING_READY === true) syncNativeEntitlements();
    if(!data.seenTutorial){
        setTimeout(() => { if(!playing) openScreen("howto"); }, 400);
    }
}

bootExtra();

  return function cleanup() {
    playing = false;
    paused = true;
    if (typeof rafId !== "undefined" && rafId) cancelAnimationFrame(rafId);
    if (typeof stopMusic === "function") stopMusic();
    try { clearInterval(cxPrev.timer); clearInterval(cxPrev.badgeTimer); } catch(e){}
    try { if(faObserver){ faObserver.disconnect(); faObserver = null; } } catch(e){}
  };
}
