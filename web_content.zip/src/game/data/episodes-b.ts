import type { DialogueLine, Emotion, EpisodeDef, ExploreNode } from "../types";

const L = (speaker: string, text: string, emotion: Emotion = "calm"): DialogueLine => ({
  speaker, emotion, text,
});

const N = (id: string, label: string, hint: string, result: ExploreNode["result"], text: string, payload?: string): ExploreNode => ({
  id, label, hint, result, text, payload,
});

export const EPISODES_B: EpisodeDef[] = [
  {
    id: 13, title: "Corrupted Relay", kind: "supernatural", summary: "The same patrol, rewritten by weather.",
    location: "East Relay", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Nyx", "Don't breathe the red. It is not air. It is an opinion."),
        L("Sera", "Masks on. If you feel poetic, that's the toxin."),
        L("Rook", "Stalker. Same walk. Wrong joints.", "shocked"),
        L("Arden", "Corrupted. We drop it before the meter decides to help."),
      ]},
      { type: "battle", battle: {
        title: "Red Relay",
        enemies: [{ base: "ruin-stalker", variant: "corrupted" }, { base: "anomaly-beast", variant: "ravager" }],
        weather: "red-storm",
        anomalyStart: 55,
        deploy: ["rook", "nyx", "mira", "sera"],
      }},
      { type: "discovery", discoveryId: "red-storm-log", text: "RED STORM logged. The sky behaves like a wound. Corrupted variants like it." },
      { type: "reward", reward: { xp: 70, currency: 34, managerXp: 14 } },
    ],
  },
  {
    id: 14, title: "Something Unnamed", kind: "mystery", summary: "A silhouette that refuses the families.",
    location: "Fault Cut", bg: "vault",
    stages: [
      { type: "dialogue", lines: [
        L("Mira", "That's not a Stalker. That's not a beast. That's a homework problem.", "confused"),
        L("Seraphine", "Do not name it yet. Naming is a kind of touching."),
        L("Arden", "Record it as unknown. If it moves like it knows us, we leave."),
        L("Vale", "It is already moving.", "worried"),
      ]},
      { type: "battle", battle: {
        title: "Unnamed",
        enemies: [{ base: "ash-wraith", variant: "aberrant" }],
        anomalyStart: 48,
        deploy: ["rook", "vale", "nyx"],
      }},
      { type: "discovery", discoveryId: "unknown-entity", text: "NEW DISCOVERY — [ UNKNOWN ]. Later, if it earns a name, the archive will change. Not today." },
      { type: "reward", reward: { xp: 55, currency: 22, managerXp: 18, discovery: "unknown-entity" } },
    ],
  },
  {
    id: 15, title: "Twin Blades", kind: "recruitment", summary: "Kade arrives as an opening, not a greeting.",
    location: "Cut Road", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Kade", "You're loud.", "angry"),
        L("Rook", "You're in our road."),
        L("Kade", "The anomaly stole a fight from me. I want it back. You look like people who keep walking into stolen fights."),
        L("Arden", "We don't steal them. We finish them."),
        L("Kade", "Good. Don't crowd me. If you give a speech I will leave mid-sentence.", "determined"),
      ]},
      { type: "battle", battle: {
        title: "Stolen Fight",
        enemies: [{ base: "ruin-stalker", variant: "hunter" }, { base: "ruin-stalker", variant: "standard" }],
        deploy: ["kade", "rook", "mira"],
      }},
      { type: "recruit", characterId: "kade", text: "Kade does not sign. He stands at the edge of the formation diagram and that is the signature." },
      { type: "reward", reward: { xp: 60, currency: 28, managerXp: 12, ally: "kade" } },
    ],
  },
  {
    id: 16, title: "What the Empire Left", kind: "lore", summary: "A Sentinel that still thinks the century is open.",
    location: "Watch Stair", bg: "vault",
    stages: [
      { type: "dialogue", lines: [
        L("Seraphine", "Construct. Mayonin. It will not hate you. Do not take that personally."),
        L("Orin", "— wait, who is Orin?", "confused"),
        L("Arden", "Not yet. Read the plate."),
        L("Mira", "'STANDING ORDER: HOLD THE STAIR.' That's the whole novel."),
        L("Rook", "Then we don't go up like tourists."),
      ]},
      { type: "battle", battle: {
        title: "The Stair",
        enemies: [{ base: "sentinel", variant: "standard" }, { base: "ruin-stalker", variant: "ancient" }],
        deploy: ["rook", "kade", "vale"],
      }},
      { type: "explore", location: "Watch Stair", intro: "After, the plate still glows, offended.", nodes: [
        N("plate", "Standing order", "HOLD THE STAIR.", "lore", "Arden copies it. Underneath, a second line in a different hand: UNTIL HE RETURNS."),
        N("core", "Cooling core", "Still warm.", "item", "Mayonin Shard. It hums off-tempo.", "mayonin-shard"),
      ]},
      { type: "reward", reward: { xp: 65, currency: 30, managerXp: 16, items: [{ id: "mayonin-shard", name: "Mayonin Shard", qty: 1 }] } },
    ],
  },
  {
    id: 17, title: "Dusk Ambush", kind: "encounter", summary: "The road decides it is a mouth.",
    location: "Low Road", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Sera", "I hate this light. It makes wounds look polite.", "worried"),
        L("Kade", "Left side. Don't talk."),
        L("Nyx", "The mist is mine. Stay out of it unless you want to be a lesson."),
      ]},
      { type: "battle", battle: {
        title: "Ambush",
        enemies: [
          { base: "ruin-stalker", variant: "standard" },
          { base: "ruin-stalker", variant: "hunter" },
          { base: "ash-wraith", variant: "standard" },
        ],
        deploy: ["rook", "kade", "nyx", "sera"],
      }},
      { type: "reward", reward: { xp: 58, currency: 40, managerXp: 10, items: [{ id: "ruin-core", name: "Ruin Core", qty: 1 }] } },
    ],
  },
  {
    id: 18, title: "Ancient Watch", kind: "battle", summary: "Plating from a century that did not end cleanly.",
    location: "West Watch", bg: "vault",
    stages: [
      { type: "dialogue", lines: [
        L("Seraphine", "Ancient variant. The marks are not decoration. Do not pry them off for souvenirs.", "angry"),
        L("Vale", "I will knock with respect."),
        L("Arden", "If it speaks, we record. We do not answer."),
      ]},
      { type: "battle", battle: {
        title: "Ancient Watch",
        enemies: [{ base: "ruin-stalker", variant: "ancient" }, { base: "sentinel", variant: "standard" }],
        deploy: ["vale", "rook", "mira", "kade"],
      }},
      { type: "reward", reward: { xp: 80, currency: 38, managerXp: 16 } },
    ],
  },
  {
    id: 19, title: "The Spear", kind: "recruitment", summary: "Astra treats gravity like a conversation she is winning.",
    location: "High Spine", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Astra", "You walk like people who have not yet fallen on purpose.", "happy"),
        L("Mira", "We try not to."),
        L("Astra", "Then let the heavens answer anyway."),
        L("Seraphine", "That line is going to be a problem."),
        L("Arden", "Can you hold a rear line without turning it into a poem?"),
        L("Astra", "I can hold anything that has a direction.", "determined"),
      ]},
      { type: "battle", battle: {
        title: "Spine",
        enemies: [{ base: "anomaly-beast", variant: "guardian" }, { base: "ruin-stalker", variant: "standard" }],
        weather: "gravity-shift",
        deploy: ["astra", "rook", "mira"],
      }},
      { type: "recruit", characterId: "astra", text: "Astra folds the spear down to a quiet stick and joins the column like weather joining a forecast." },
      { type: "reward", reward: { xp: 62, currency: 26, managerXp: 12, ally: "astra" } },
    ],
  },
  {
    id: 20, title: "A Name Ahead", kind: "story", summary: "The first time the road feels like a person Arden already knows.",
    location: "Black Causeway", bg: "vault",
    stages: [
      { type: "dialogue", lines: [
        L("Arden", "Stop.", "shocked"),
        L("Rook", "Contact?"),
        L("Arden", "No. A habit. Someone walked this exact line. The same mistakes in the dirt."),
        L("Seraphine", "Arden.", "worried"),
        L("Arden", "It's nothing I can prove."),
        L("Mira", "You look like you just saw a relative.", "worried"),
        L("Arden", "Don't."),
        L("Sera", "We're here. You don't have to make it a report.", "sad"),
      ]},
      { type: "choice", prompt: "Seraphine asks, quietly, if he wants the squad told.", options: [
        { id: "tell", label: "Tell them it might be his father", text: "He says the word once. The column gets heavier and closer. Rook nods like a door closing in the useful way.", flag: "father_seen", trust: { id: "rook", delta: 1 } },
        { id: "hold", label: "Hold it", text: "Arden keeps the name. The road still knows. The squad feels the shape of a secret and hates it less than a lie." },
      ]},
      { type: "discovery", discoveryId: "father-file", text: "Archive opens a page with no portrait. THE FATHER. Goal connected to ending the world. Proof: a walk." },
      { type: "reward", reward: { xp: 40, currency: 12, managerXp: 22, discovery: "father-file" } },
    ],
  },
  {
    id: 21, title: "Chain and Lock", kind: "recruitment", summary: "Orin draws a box on the world and invites the enemy to stand in it.",
    location: "Yard Diagram", bg: "hall",
    stages: [
      { type: "dialogue", lines: [
        L("Orin", "Your formation is a rumor.", "calm"),
        L("Rook", "It's a wall."),
        L("Orin", "Walls are rumors that convinced gravity. I taught this. Then the weather made my classroom theoretical."),
        L("Arden", "We have a line. It needs a lock."),
        L("Orin", "Then I will be the lock. Try not to walk out of my diagram while I'm helping you.", "determined"),
      ]},
      { type: "battle", battle: {
        title: "Diagram",
        enemies: [{ base: "ruin-stalker", variant: "ravager" }, { base: "ruin-stalker", variant: "hunter" }],
        deploy: ["orin", "rook", "kade"],
      }},
      { type: "recruit", characterId: "orin", text: "Orin writes ASHLINE in the corner of a formation card, then corrects the spacing." },
      { type: "reward", reward: { xp: 60, currency: 24, managerXp: 14, ally: "orin" } },
    ],
  },
  {
    id: 22, title: "Temporal Fault", kind: "supernatural", summary: "A device that should not exist, and a Sentinel that is late on purpose.",
    location: "Fault Chamber", bg: "vault",
    stages: [
      { type: "dialogue", lines: [
        L("Arden", "Don't touch it.", "fearful"),
        L("Mira", "I wasn't going to— okay I was going to."),
        L("Seraphine", "Mayonin. Temporal. If it is what I think, it has a vulgar name in the old notes."),
        L("Orin", "The Sentinel is acting twice. That is rude."),
        L("Arden", "We take the fight. Then I take the device. Nobody else."),
      ]},
      { type: "battle", battle: {
        title: "Fault",
        enemies: [{ base: "sentinel", variant: "temporal" }, { base: "ash-wraith", variant: "temporal" }],
        weather: "time-distortion",
        anomalyStart: 62,
        deploy: ["orin", "kade", "rook", "mira"],
      }},
      { type: "discovery", discoveryId: "time-cracker", text: "TIME CRACKER — Discovered by Arden. Unknown Mayonin-era device capable of interacting with temporal phenomena. Before: [ UNKNOWN ]. After: a weight in his coat that ticks without moving." },
      { type: "reward", reward: { xp: 90, currency: 42, managerXp: 20, discovery: "time-cracker", special: "time-fracture", items: [{ id: "time-splinter", name: "Time Splinter", qty: 1 }] } },
    ],
  },
  {
    id: 23, title: "The Wall", kind: "recruitment", summary: "Lena likes doors that stay shut.",
    location: "North Gate", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Lena", "You're bleeding on my gate.", "worried"),
        L("Sera", "It's a smear. Don't dramatize."),
        L("Lena", "I don't like hero. I like shut."),
        L("Rook", "Then you'll get along with the job."),
        L("Arden", "We need a tower. Not a speech."),
        L("Lena", "While I'm here, you will not break. That is the whole speech.", "determined"),
      ]},
      { type: "battle", battle: {
        title: "Gate",
        enemies: [{ base: "anomaly-beast", variant: "ravager" }, { base: "ruin-stalker", variant: "armored" }],
        deploy: ["lena", "rook", "sera", "vale"],
      }},
      { type: "recruit", characterId: "lena", text: "Lena sets the tower shield down like a piece of furniture that has decided to be a building." },
      { type: "reward", reward: { xp: 64, currency: 28, managerXp: 12, ally: "lena", items: [{ id: "tower-rim", name: "Tower Rim", qty: 1 }] } },
    ],
  },
  {
    id: 24, title: "Trust Night", kind: "character", summary: "The squad talks like people who might live.",
    location: "Camp", bg: "hall",
    stages: [
      { type: "dialogue", lines: [
        L("Mira", "If we die tomorrow I'm haunting the rifle first.", "happy"),
        L("Kade", "Haunt quieter."),
        L("Sera", "Nobody dies tomorrow. I have tape with your names on it. That's a contract."),
        L("Astra", "Contracts are a kind of gravity."),
        L("Nyx", "Please stop giving the weather metaphors. It listens."),
        L("Rook", "Arden. You're doing the thing where you stand near the door like the door needs you.", "worried"),
        L("Arden", "The door does need me."),
        L("Lena", "Then sit where we can see you. Doors work both ways.", "determined"),
      ]},
      { type: "choice", prompt: "Who does Arden sit with?", options: [
        { id: "rooksera", label: "Rook and Sera", text: "They talk about walls and pulses. Trust settles like a blanket that is also a tactic.", trust: { id: "rook", delta: 1 } },
        { id: "mira", label: "Mira on the ridge crate", text: "She pretends not to be glad. She is glad. The jokes get worse, which is love.", trust: { id: "mira", delta: 1 } },
        { id: "seraphine", label: "Seraphine, away from the fire", text: "They do not talk about fathers. They talk about what a commander owes a line. It is almost the same conversation.", trust: { id: "seraphine", delta: 1 } },
      ]},
      { type: "reward", reward: { xp: 30, currency: 10, managerXp: 18 } },
    ],
  },
];
