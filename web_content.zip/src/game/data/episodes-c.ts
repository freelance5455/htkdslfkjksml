import type { DialogueLine, Emotion, EpisodeDef, ExploreNode } from "../types";

const L = (speaker: string, text: string, emotion: Emotion = "calm"): DialogueLine => ({
  speaker, emotion, text,
});

const N = (id: string, label: string, hint: string, result: ExploreNode["result"], text: string, payload?: string): ExploreNode => ({
  id, label, hint, result, text, payload,
});

export const EPISODES_C: EpisodeDef[] = [
  {
    id: 25, title: "Beast Weather", kind: "battle", summary: "Anomaly fauna, and a guardian that thinks it is a church.",
    location: "Ash Basin", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Nyx", "Don't get religious about the big one. It is a door with teeth."),
        L("Vale", "Then it is late for closing."),
        L("Arden", "Hunter on the flank — Lena, if it looks at Sera, you become the whole building."),
      ]},
      { type: "battle", battle: {
        title: "Basin",
        enemies: [
          { base: "anomaly-beast", variant: "guardian" },
          { base: "anomaly-beast", variant: "ravager" },
          { base: "anomaly-beast", variant: "standard" },
        ],
        weather: "ashfall",
        anomalyStart: 50,
        deploy: ["lena", "vale", "nyx", "sera"],
      }},
      { type: "reward", reward: { xp: 75, currency: 36, managerXp: 14 } },
    ],
  },
  {
    id: 26, title: "Deadeye", kind: "recruitment", summary: "Cael invoices a mistake that has not happened yet.",
    location: "Ledger Street", bg: "hall",
    stages: [
      { type: "dialogue", lines: [
        L("Cael", "You're late for a sentence.", "calm"),
        L("Arden", "Whose."),
        L("Cael", "An informant's. They died mid-word. I still have the rest of it. You look like the rest of it."),
        L("Kade", "I like him. Unfortunately."),
        L("Cael", "I don't do speeches. I do choices. You made one, walking here."),
        L("Arden", "Stay if the ledger points at the same weather we do."),
        L("Cael", "It does. Don't make me write you down in the other column.", "determined"),
      ]},
      { type: "battle", battle: {
        title: "Street",
        enemies: [{ base: "ruin-stalker", variant: "hunter" }, { base: "ash-wraith", variant: "standard" }],
        deploy: ["cael", "kade", "mira"],
      }},
      { type: "recruit", characterId: "cael", text: "NEW ALLY — Cael. Dual pistols. He checks the chamber like a signature." },
      { type: "reward", reward: { xp: 62, currency: 30, managerXp: 12, ally: "cael" } },
    ],
  },
  {
    id: 27, title: "Elite Line", kind: "battle", summary: "Veterans of the same family. They have learned not to rush.",
    location: "Measure Field", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Seraphine", "Elite. If you treat them like the first patrol, they will grade you."),
        L("Rook", "Let them. I've been graded."),
        L("Orin", "Do not leave the box."),
        L("Arden", "Command Strike is live if the line staggers. Don't make me spend it for pride.", "determined"),
      ]},
      { type: "battle", battle: {
        title: "Elite Line",
        enemies: [
          { base: "ruin-stalker", variant: "elite", elite: true },
          { base: "sentinel", variant: "elite", elite: true },
        ],
        deploy: ["rook", "orin", "mira", "kade"],
      }},
      { type: "reward", reward: { xp: 95, currency: 48, managerXp: 18, special: "command-strike" } },
    ],
  },
  {
    id: 28, title: "A Sword That Is Not Ours", kind: "discovery", summary: "The Sword of the Mayonin Empire, seen, not taken.",
    location: "Reliquary", bg: "vault",
    stages: [
      { type: "dialogue", lines: [
        L("Arden", "…That's not a museum piece.", "shocked"),
        L("Seraphine", "Do not touch it.", "fearful"),
        L("Vale", "It is already looking at you."),
        L("Mira", "Swords don't look."),
        L("Seraphine", "This one does."),
        L("Arden", "Long blade. Dark metal. Red edge. Wrapped handle. Someone has been using it.", "worried"),
        L("Rook", "Someone we know?", "worried"),
        L("Arden", "Someone I did.", "sad"),
      ]},
      { type: "discovery", discoveryId: "mayonin-sword", text: "SWORD OF THE MAYONIN EMPIRE — seen, not taken. The stand is empty of dust where a hand has been." },
      { type: "choice", prompt: "The blade hums toward Arden's palm.", options: [
        { id: "leave", label: "Leave it", text: "He leaves it. The hum follows him into the stair anyway.", flag: "mayonin_sword_seen" },
        { id: "near", label: "Stand close, don't draw", text: "Heat along the bones of his hand. Seraphine pulls him back by the coat. He lets her.", flag: "mayonin_sword_seen" },
      ]},
      { type: "reward", reward: { xp: 50, currency: 16, managerXp: 24, discovery: "mayonin-sword", special: "void-command" } },
    ],
  },
  {
    id: 29, title: "Red Sword", kind: "story", summary: "Seraphine stops teaching and starts ending a room.",
    location: "Sutured Hall", bg: "hall",
    stages: [
      { type: "dialogue", lines: [
        L("Seraphine", "Enough. I'll handle this.", "determined"),
        L("Arden", "You don't have to—"),
        L("Seraphine", "I am not asking. You will watch how an Arbiter-shaped problem is supposed to be cut. Then you will not copy me until you can."),
        L("Rook", "That's a yes from the wall."),
      ]},
      { type: "battle", battle: {
        title: "Verdict",
        enemies: [{ base: "anomaly-beast", variant: "aberrant" }, { base: "sentinel", variant: "ancient" }],
        deploy: ["seraphine", "rook", "lena"],
      }},
      { type: "dialogue", lines: [
        L("Seraphine", "I'm not playable every day. Don't get addicted to the red."),
        L("Sera", "You're shaking."),
        L("Seraphine", "That's the cost. Remember it when your commander starts glowing.", "sad"),
      ]},
      { type: "reward", reward: { xp: 80, currency: 30, managerXp: 16, items: [{ id: "crimson-wrap", name: "Crimson Wrap", qty: 1 }] } },
    ],
  },
  {
    id: 30, title: "Hidden Vault", kind: "exploration", summary: "A room that was not on the map.",
    location: "Off-Map", bg: "vault",
    stages: [
      { type: "dialogue", lines: [
        L("Cael", "Door's a liar. The wall is the door."),
        L("Orin", "I like him more now."),
        L("Arden", "Hidden rooms are how empires admit they were afraid."),
      ]},
      { type: "explore", location: "Imperial Vault", intro: "A chamber with no dust on one table, and too much on everything else.", nodes: [
        N("record", "Cylinder record", "A voice, half-dead.", "lore", "—if the child resonates, do not wait for him to ask. The rest is scratch."),
        N("box", "Utility cache", "Still sealed.", "item", "Field Kit, extra. Sera looks personally offended that it was left here.", "field-kit"),
        N("warn", "Floor script", "A prohibition.", "discovery", "Do not measure the one who does not need measuring.", "hidden-vault"),
        N("ambush", "Dark alcove", "Cael shakes his head too late.", "battle", "Something kept the room."),
      ]},
      { type: "battle", battle: {
        title: "Vault Keeper",
        enemies: [{ base: "sentinel", variant: "ancient" }],
        deploy: ["cael", "orin", "lena"],
      }},
      { type: "discovery", discoveryId: "hidden-vault", text: "HIDDEN ROOM logged. Equipment. A record. A warning in a language half-dead." },
      { type: "reward", reward: { xp: 70, currency: 44, managerXp: 18, discovery: "hidden-vault", special: "tactical-shift" } },
    ],
  },
  {
    id: 31, title: "Aberrant Hour", kind: "battle", summary: "Habits that do not belong to the family.",
    location: "Wrong Yard", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Nyx", "It's late on purpose. Don't match its rhythm."),
        L("Kade", "Then I will be early on purpose."),
        L("Arden", "Time Fracture is available. Use it if the order goes stupid. Not because it feels good."),
      ]},
      { type: "battle", battle: {
        title: "Wrong Yard",
        enemies: [{ base: "anomaly-beast", variant: "aberrant" }, { base: "ash-wraith", variant: "aberrant" }],
        weather: "eclipse",
        anomalyStart: 70,
        deploy: ["kade", "nyx", "astra", "orin"],
      }},
      { type: "reward", reward: { xp: 88, currency: 40, managerXp: 16 } },
    ],
  },
  {
    id: 32, title: "The Approach", kind: "story", summary: "A map with one name left.",
    location: "Last Camp", bg: "hall",
    stages: [
      { type: "dialogue", lines: [
        L("Arden", "Tomorrow is not a patrol."),
        L("Rook", "We know."),
        L("Seraphine", "You will want to make it a duel. That is a child talking. You will still do it. I am telling you so you hear it before the room does.", "worried"),
        L("Sera", "I'll keep people standing. That's my whole personality tomorrow."),
        L("Mira", "I'll shoot whatever isn't you."),
        L("Vale", "If a door must close on a man, I will be the hinge."),
        L("Lena", "While I'm here—"),
        L("Several", "We know.", "happy"),
        L("Arden", "If I say the fight is mine, you still hold the rooms around it. That is an order, not a poem."),
      ]},
      { type: "choice", prompt: "The squad waits for the true sentence.", options: [
        { id: "ours", label: "It's ours", text: "He says ours. Something in the camp unclenches. He still knows whose blood is in the room.", flag: "line_is_ours" },
        { id: "mine", label: "The last measure is mine", text: "He says mine. Rook hates it and accepts it. That is Trust too.", flag: "line_is_mine" },
      ]},
      { type: "reward", reward: { xp: 40, currency: 12, managerXp: 24, special: "reversal" } },
    ],
  },
  {
    id: 33, title: "Threshold", kind: "boss", summary: "A Sentinel that still remembers a rank.",
    location: "Imperial Threshold", bg: "vault",
    stages: [
      { type: "dialogue", lines: [
        L("Orin", "That's a commander construct. It will spend the small ones to keep the idea of a rank."),
        L("Cael", "Then we invoice the small ones first."),
        L("Seraphine", "Two phases. When the plate comes off, do not cheer. Cheer is a lost action.", "determined"),
      ]},
      { type: "battle", battle: {
        title: "Sentinel Commander",
        enemies: [
          { base: "sentinel-commander", variant: "boss" },
          { base: "sentinel", variant: "support" },
          { base: "sentinel", variant: "guardian" },
        ],
        bossPhases: 2,
        deploy: ["rook", "orin", "cael", "lena"],
      }},
      { type: "reward", reward: { xp: 120, currency: 60, managerXp: 22, items: [{ id: "mayonin-shard", name: "Mayonin Shard", qty: 2 }] } },
    ],
  },
  {
    id: 34, title: "Distorted Demon", kind: "boss", summary: "Something bloody and wrong blocks the last hall. It looks like the end — until the Mentor steps in.",
    location: "Antehall", bg: "vault",
    stages: [
      { type: "dialogue", lines: [
        L("Mira", "What the hell is that."),
        L("Rook", "Stay behind me."),
        L("Nyx", "That is not a family. That is a mistake wearing blood."),
        L("Arden", "Hold the line. Do not chase it."),
        L("Seraphine", "No.", "determined"),
        L("Seraphine", "This one is mine to break.", "determined"),
        L("Arden", "Seraphine—"),
        L("Seraphine", "Watch. Then finish it."),
      ]},
      { type: "battle", battle: {
        title: "Distorted Demon",
        enemies: [{ base: "distorted-demon", variant: "boss", elite: true }],
        weather: "red-storm",
        anomalyStart: 40,
        deploy: ["arden", "seraphine", "rook", "sera"],
        objects: [{ id: "blood-stain", name: "Old Blood", desc: "It is still warm. It should not be.", effect: "lore" }],
        bossPhases: 1,
      }},
      { type: "dialogue", lines: [
        L("Seraphine", "It looked worse than it was."),
        L("Rook", "You made it look easy."),
        L("Seraphine", "It was never meant to stop us. Only to scare us."),
        L("Arden", "Then we keep walking."),
        L("Seraphine", "You will hear his voice soon. Do not freeze."),
        L("Arden", "I won't."),
      ]},
      { type: "reward", reward: { xp: 90, currency: 40, managerXp: 18, items: [{ id: "demon-shard", name: "Distorted Shard", qty: 1 }] } },
    ],
  },
  {
    id: 35, title: "Imperial End", kind: "boss", summary: "Arden versus his father. The squad holds the rooms. The mystery does not finish.",
    location: "Imperial Vault", bg: "vault",
    stages: [
      { type: "dialogue", lines: [
        L("Arden", "…Father?", "shocked"),
        L("Father", "You finally came."),
        L("Arden", "Why are you doing this?", "angry"),
        L("Father", "You still don't understand what is coming."),
        L("Rook", "Arden. Give the word.", "determined"),
        L("Arden", "No."),
        L("Arden", "This one is mine.", "determined"),
        L("Seraphine", "Then we hold the rooms. If you fall, it stops being yours."),
        L("Father", "Twenty years, and you still think a line is a kindness."),
        L("Arden", "It is. That's why you hate it.", "sad"),
        L("Father", "I am trying to end a world that will not end clean. You are trying to furnish it."),
        L("Sera", "You don't get to talk about clean while you're cutting people.", "angry"),
        L("Father", "Medic. You will be busy."),
        L("Mira", "Say another sentence. I dare you.", "angry"),
        L("Father", "The instrument will not measure me. That should have been your first clue."),
        L("Arden", "Then I'll measure you the old way.", "determined"),
        L("Kade", "Openings exist. Even for this."),
        L("Father", "Come, then. Bring your garden, your wall, your ledger. I will show you Beyond."),
      ]},
      { type: "battle", battle: {
        title: "Father",
        enemies: [{ base: "father", variant: "boss" }],
        weather: "eclipse",
        anomalyStart: 60,
        ardenFights: true,
        bossPhases: 5,
        deploy: ["rook", "mira", "vale", "sera", "arden"],
        objects: [{ id: "blade-stand", name: "Empty Stand", desc: "The sword is already in his hand.", effect: "lore" }],
      }},
      { type: "cinematic", cinematic: { sceneId: "father-finale", title: "The Last Measure", background: "vault" } },
      { type: "discovery", discoveryId: "ancestor-broken-blade", text: "ANCESTOR'S BROKEN BLADE — A surviving fragment forged by the earliest Mayonin ancestors. Its purpose was protection, but the reason it was chained away remains unknown." },
      { type: "discovery", discoveryId: "resonance", text: "MAYONIN RESONANCE — Awakened Arden, Beyond Arbiter, Clash ???. Father was already Beyond without waking. Chapter 1 ends on that question, not the answer." },
      { type: "reward", reward: { xp: 200, currency: 120, managerXp: 40, discovery: "resonance" } },
    ],
  },
];
