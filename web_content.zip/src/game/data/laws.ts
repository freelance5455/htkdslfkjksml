export interface LawDef {
  id: number;
  title: string;
  short: string;
  insight: string;
}

export const LAWS: LawDef[] = [
  {
    id: 1,
    title: "Nunca Ofusque o Mestre",
    short: "Brilhe menos que o rei",
    insight:
      "Ser medíocre nunca é virtuoso. Brilhe menos que o mestre e ele o mantém; brilhe mais e ele o apaga. Faça do brilho dele o seu escudo.",
  },
  {
    id: 2,
    title: "Nunca Confie Demais nos Amigos; Use os Inimigos",
    short: "Confiança é moeda cara",
    insight:
      "Amigos são aliados de circunstância, não de sangue. O inimigo útil é uma posição: ele serve ao seu objetivo sem pedir o que você não pode dar.",
  },
  {
    id: 3,
    title: "Esconda Suas Intenções",
    short: "Ninguém precisa do seu plano",
    insight:
      "Quem revela o plano perde a surpresa. Diga o que o interlocutor precisa ouvir e nada do que ele pode usar contra você.",
  },
  {
    id: 4,
    title: "Diga Sempre Menos do que o Necessário",
    short: "O silêncio é uma arma",
    insight:
      "Quem fala muito entrega munição. A frase mais forte é a que você não pronuncia, e o silêncio bem colocado cria medo e respeito.",
  },
  {
    id: 5,
    title: "Guarde Sua Reputação com a Sua Vida",
    short: "A reputação é seu capital",
    insight:
      "A fortuna pode voltar; a reputação, não. Um único escândalo apaga anos de bondade e reaparece em cada negociação.",
  },
  {
    id: 6,
    title: "Conquiste a Atenção a Qualquer Custo",
    short: "Ser notado é o primeiro passo",
    insight:
      "Quem ninguém nota, ninguém nomeia para o poder. Crie eventos e use a tática: a atenção é a moeda com que se paga a entrada.",
  },
  {
    id: 7,
    title: "Faça Outros Trabalhar e Assuma o Crédito",
    short: "O trabalho alheio é o seu",
    insight:
      "O mérito é uma narrativa. Distribua o esforço, controle a história e pareça o orquestrador de tudo o que acontece.",
  },
  {
    id: 8,
    title: "Faça os Outros Virem até Você",
    short: "Quem busca, submete",
    insight:
      "Se todos vêm até você, você escolhe o terreno e o momento. Nunca corra atrás: organize o lugar e espere que venham.",
  },
  {
    id: 9,
    title: "Vença pela Ação, Nunca pela Argumentação",
    short: "Argumento é vento",
    insight:
      "Discussões vencem apenas no papel. O resultado concreto subordina qualquer réplica, e cala a boca dos céticos.",
  },
  {
    id: 10,
    title: "Infecção: Evite os Infelizes e os Azarados",
    short: "A sorte é contagiosa",
    insight:
      "O fracasso se gruda. Amizade com quem nunca prosperou arrasta seu nome para baixo; procure quem tem o impulso e carregue-o.",
  },
  {
    id: 11,
    title: "Aprenda a Manter as Pessoas Dependentes de Você",
    short: "Quem depende, obedece",
    insight:
      "Nunca forneça tudo. Centralize um recurso — grão, transporte, acesso — e as pessoas passam a depender de você para viver.",
  },
  {
    id: 12,
    title: "Use Honestidade Seletiva e Generosidade para Desarmar",
    short: "A bondade é uma isca",
    insight:
      "Um elogio sincero no momento certo desarma a desconfiança. Dê algo pequeno e verdadeiro, e depois peça algo grande.",
  },
  {
    id: 13,
    title: "Apele ao Interesse Próprio, Nunca à Misericórdia",
    short: "Ninguém se move por piedade",
    insight:
      "Ponha o pedido na linguagem do outro: o que ele ganha. Misericórdia é uma dívida, e toda dívida cobra juros.",
  },
  {
    id: 14,
    title: "Pose-se de Amigo, Trabalhe como Espião",
    short: "Amizade útil, espionagem útil",
    insight:
      "A confiança alheia é uma porta destrancada. Cuide dela com cuidado e use-a apenas quando o momento for insuperável.",
  },
  {
    id: 15,
    title: "Esmague o Inimigo por Completo",
    short: "Meio caminho é fraqueza",
    insight:
      "O inimigo humilhado volta. Não deixe vigor restante: termine o que começou, ou não comece.",
  },
  {
    id: 16,
    title: "Use a Ausência para Aumentar o Respeito",
    short: "Ausência é presença",
    insight:
      "Quem permanece tem preço; quem some tem valor. Afaste-se na hora certa e o valor do que ficou cresce.",
  },
  {
    id: 17,
    title: "Mantenha os Outros em Terror Suspenso",
    short: "Seja imprevisível",
    insight:
      "Quem é previsível é previsto. Varie os gestos, a presença e o silêncio: o medo não nasce do perigo, nasce da dúvida.",
  },
  {
    id: 18,
    title: "Não Construa Fortalezas",
    short: "Isolamento é perigoso",
    insight:
      "Quem se esconde não é visto, e quem não é visto não é temido. Exponha-se ao fluxo e mantenha o fluxo dependente de você.",
  },
  {
    id: 19,
    title: "Saiba com Quem Você Está Lidando",
    short: "Não ofenda a pessoa errada",
    insight:
      "Meça o poder do outro antes de agir. Um homem pequeno pode ser o gatilho de algo imenso.",
  },
  {
    id: 20,
    title: "Não Se Comprometa com Ninguém",
    short: "Compromisso é coleira",
    insight:
      "Aliança é temporária por natureza. Mantenha a porta aberta com todos e a fechadura com ninguém.",
  },
  {
    id: 21,
    title: "Jogue o Bobo para Puxar o Bobo",
    short: "Finja ser menor",
    insight:
      "Quem parece menor recebe mais informação e é subestimado nas negociações. A ignorância aparente é um anzol.",
  },
  {
    id: 22,
    title: "Use a Tática da Rendição",
    short: "Renda-se para vencer",
    insight:
      "Ceder uma batalha sem perder a guerra. Entregue o que é pequeno, recue de frente e preserve a força que decide.",
  },
  {
    id: 23,
    title: "Concentre suas Forças",
    short: "Dispersão é derrota",
    insight:
      "Espalhar-se garante ser derrotado por partes. Escolha um ponto e concentre lá tudo o que você tem.",
  },
  {
    id: 24,
    title: "Jogue o Cortêsão Perfeito",
    short: "A arte de agradar sem subservir",
    insight:
      "A corte é uma dança de espelhos. Devolva ao rei a imagem que ele deseja e mantenha a sua intacta.",
  },
  {
    id: 25,
    title: "Recrie-se",
    short: "Adote uma nova persona",
    insight:
      "A persona é um uniforme: protege e intimida. Escolha uma história que justifique tudo o que você faz.",
  },
  {
    id: 26,
    title: "Mantenha as Mãos Limpas",
    short: "A fuligem fica com o outro",
    insight:
      "Ordene, mas não apareça na cena. O poder real está em quem dá a ordem, não em quem dá a mão suja.",
  },
  {
    id: 27,
    title: "Crie uma Seita: Explore a Necessidade de Crença",
    short: "Crença multiplica força",
    insight:
      "Quem acredita fala em voz alta e obedece em público. Uma promessa clara gera lealdade mais forte que qualquer soldo.",
  },
  {
    id: 28,
    title: "Entre na Ação com Boldura",
    short: "Ousadia desarma",
    insight:
      "A hesitação convida ao golpe. Avance com força: quem toma a iniciativa dita os termos.",
  },
  {
    id: 29,
    title: "Planeje Até o Fim",
    short: "Pense no fim antes do começo",
    insight:
      "A estratégia se revela no último movimento. Planeje até a saída e, sobretudo, até a sua própria.",
  },
  {
    id: 30,
    title: "Faça Suas Conquistas Parecerem Fáceis",
    short: "Mostre que foi fácil",
    insight:
      "O mundo adora o que parece fácil. Esconda o preparo e o mérito: aparência de facilidade é poder puro.",
  },
  {
    id: 31,
    title: "Controle as Opções",
    short: "Dê as cartas, jogue o jogo",
    insight:
      "Controle o menu, controle a decisão. Ofereça apenas escolhas que você já sabe como usar.",
  },
  {
    id: 32,
    title: "Jogue nas Fantasias das Pessoas",
    short: "Alimente o sonho delas",
    insight:
      "As pessoas compram aquilo que imaginam. Alimente a narrativa que elas já querem comprar e cobre barato.",
  },
  {
    id: 33,
    title: "Descubra o Polegar de Cada Um",
    short: "Encontre a fraqueza",
    insight:
      "Cada pessoa tem uma fraqueza: vaidade, medo, ambição, dívida. Encontre-a e guarde-a em silêncio.",
  },
  {
    id: 34,
    title: "Seja Real na Sua Moda",
    short: "Aja como um rei para ser tratado como um",
    insight:
      "O porte cria a realidade. Vista-se e fale como alguém habituado a sentar em cadeiras de poder.",
  },
  {
    id: 35,
    title: "Domine a Arte do Tempo",
    short: "Tempo é a arma",
    insight:
      "Chegar cedo demais é arrogante, tarde demais é fracasso. Espere o instante em que o outro precisa de você.",
  },
  {
    id: 36,
    title: "Despreze o Que Você Não Pode Ter",
    short: "Nada custa mais que cobiçar",
    insight:
      "Desejar aquilo que está fora do alcance expõe sua fraqueza. O desdém transforma a falta em escolha.",
  },
  {
    id: 37,
    title: "Crie Espetáculos Compulsivos",
    short: "O espetáculo é a mensagem",
    insight:
      "A cena que todos repetem não é espetáculo: é rumor controlado. Dê à corte uma história para contar.",
  },
  {
    id: 38,
    title: "Pense Como Você Quer, Mas Comporte-se Como os Outros",
    short: "Pense livre, aja prudente",
    insight:
      "A dissidência isolada é removida: use a ideia por baixo da mesa. Reserve o incomum para o momento certo.",
  },
  {
    id: 39,
    title: "Agite as Águas para Pegar Peixes",
    short: "Turbe o rio",
    insight:
      "Nada dá mais poder do que o caos que você mesmo criou. Turbe a água, aponte o dedo e colha a culpa natural.",
  },
  {
    id: 40,
    title: "Despreze o Almoço Grátis",
    short: "O presente cobra caro",
    insight:
      "Cortesia inesperada é uma forma de hook. Recuse a oferta sem ofender: você não deve nada a ninguém.",
  },
  {
    id: 41,
    title: "Evite Calçar os Sapatos de um Grande Homem",
    short: "Não ocupe o trono vazio",
    insight:
      "Tentar copiar o mestre é fracassar publicamente. Ocupar a posição de alguém só funciona se for a sua própria.",
  },
  {
    id: 42,
    title: "Atinga o Pastor, e as Ovelhas se Espalharão",
    short: "Derrube a liderança",
    insight:
      "Não entregue a ovelha ao pastor: derrube o pastor. A manada se dispersa sozinha.",
  },
  {
    id: 43,
    title: "Trabalhe os Corações e as Mentes dos Outros",
    short: "Conquiste coração e cabeça",
    insight:
      "O consentimento nasce da convicção. Pense como persuade: por que isso importa para eles?",
  },
  {
    id: 44,
    title: "Desarme e Isole com o Efeito Espelho",
    short: "Devolva o golpe",
    insight:
      "Copie o estilo do adversário até ele duvidar de si. Quem se vê no espelho perde a força da agressão.",
  },
  {
    id: 45,
    title: "Pregue a Mudança, Mas Nunca Reforme Demais",
    short: "Mude o gesto, não o podre",
    insight:
      "Reforme o visível e preserve o invisível. Mudança demais de uma vez gera resistência; mudança gradativa gera poder.",
  },
  {
    id: 46,
    title: "Nunca Apareça Perfeito Demais",
    short: "Uma falha calculada",
    insight:
      "Perfeição gera inveja e suspeita. Exiba uma falha pequena e controlada: ela torna você humano e próximo.",
  },
  {
    id: 47,
    title: "Não Vá Além do Alvo",
    short: "Saiba quando parar",
    insight:
      "A vitória que se estende demais vira desastre. Deixe o inimigo se enforcar na própria derrota e pare.",
  },
  {
    id: 48,
    title: "Assuma a Forma Fluida",
    short: "Nunca seja fácil de prender",
    insight:
      "Não molde sua imagem para caber num rótulo. Fluidez e imprevisibilidade tornam o poder intransferível.",
  },
];

export const lawById = (id: number): LawDef => LAWS[id - 1];
