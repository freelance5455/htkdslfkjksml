export const T = {
  GRASS: 1,
  DIRT: 2,
  STONE: 3,
  WOOD: 4,
  WATER: 5,
  CARPET: 6,
  MARBLE: 7,
  ROAD: 8,
  MOSS: 9,
  DARK: 10,
  SAND: 11,
  GRAVE: 12,
  CRYPT: 13,
  WALL_STONE: 20,
  WALL_WOOD: 21,
  HEDGE: 22,
  TREE: 23,
  ROCK: 24,
  BLOCK: 25,
} as const;

export const SOLID_MIN = 20;

export type PropKind =
  | "torch"
  | "brazier"
  | "table"
  | "barrel"
  | "crate"
  | "chair"
  | "bench"
  | "shelf"
  | "banner"
  | "pillar"
  | "statue"
  | "well"
  | "hay"
  | "cart"
  | "boat"
  | "chest"
  | "flower"
  | "fence"
  | "anvil"
  | "forge"
  | "stall"
  | "sack"
  | "sign"
  | "grave"
  | "candle"
  | "throne"
  | "altar"
  | "crown"
  | "rug"
  | "campfire";

export interface Prop {
  kind: PropKind;
  x: number;
  y: number;
}

export interface Light {
  x: number;
  y: number;
  r: number;
  c: string;
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
  t: number;
}

export interface AreaDef {
  id: string;
  name: string;
  subtitle: string;
  w: number;
  h: number;
  ground: number;
  alt: number;
  dark: number;
  border: "stone" | "wood" | "tree" | "hedge" | "water" | "none";
  floors: Rect[];
  walls: Rect[];
  scatter: { k: number; count: number; seed: number; on?: number }[];
  props: { k: PropKind; x: number; y: number }[];
  lights: Light[];
  npcs: { id: string; x: number; y: number }[];
  items: { id: string; item: string; x: number; y: number }[];
  map: { x: number; y: number };
  music: "village" | "town" | "castle" | "crypt" | "wild" | "tavern" | "water";
}

const A = (
  id: string,
  name: string,
  subtitle: string,
  w: number,
  h: number,
  ground: number,
  alt: number,
  dark: number,
  border: AreaDef["border"],
  map: { x: number; y: number },
  music: AreaDef["music"]
): AreaDef => ({
  id,
  name,
  subtitle,
  w,
  h,
  ground,
  alt,
  dark,
  border,
  map,
  music,
  floors: [],
  walls: [],
  scatter: [],
  props: [],
  lights: [],
  npcs: [],
  items: [],
});

const r = (x: number, y: number, w: number, h: number, t: number): Rect => ({ x, y, w, h, t });

export const AREA_DEFS: AreaDef[] = [
  A(
    "vila",
    "Vila de Cinzas",
    "Onde todo ged comeca",
    40,
    30,
    T.GRASS,
    T.DIRT,
    0.12,
    "tree",
    { x: 28, y: 60 },
    "village"
  ),
  A(
    "mercado",
    "Mercado de Pedra",
    "A voz alta da cidade",
    36,
    26,
    T.ROAD,
    T.DIRT,
    0.08,
    "stone",
    { x: 46, y: 56 },
    "town"
  ),
  A(
    "taverna",
    "Taverna do Corvo",
    "Todo segredo tem mesa",
    26,
    20,
    T.WOOD,
    T.DARK,
    0.42,
    "wood",
    { x: 52, y: 70 },
    "tavern"
  ),
  A(
    "ponte",
    "Ponte das Almas",
    "O rio separa o povo do poder",
    30,
    22,
    T.DIRT,
    T.GRASS,
    0.1,
    "tree",
    { x: 16, y: 52 },
    "wild"
  ),
  A(
    "castelo",
    "Castelo Real",
    "Pedra que sussurra ordens",
    40,
    28,
    T.STONE,
    T.DIRT,
    0.14,
    "stone",
    { x: 60, y: 32 },
    "castle"
  ),
  A(
    "trono",
    "Salão do Trono",
    "Onde o olhar pesa mais que a espada",
    28,
    20,
    T.MARBLE,
    T.CARPET,
    0.18,
    "stone",
    { x: 62, y: 20 },
    "castle"
  ),
  A(
    "conselho",
    "Câmara do Conselho",
    "Onde os documentos vencem batalhas",
    26,
    18,
    T.DARK,
    T.WOOD,
    0.3,
    "stone",
    { x: 76, y: 32 },
    "castle"
  ),
  A(
    "capela",
    "Capela da Coroa",
    "Luz alta e vontade baixa",
    22,
    18,
    T.MARBLE,
    T.CARPET,
    0.16,
    "stone",
    { x: 46, y: 28 },
    "castle"
  ),
  A(
    "cripta",
    "Cripta Sombria",
    "Os mortos tambem tem segredos",
    24,
    18,
    T.CRYPT,
    T.DARK,
    0.72,
    "stone",
    { x: 44, y: 16 },
    "crypt"
  ),
  A(
    "bosque",
    "Bosque Cinérea",
    "Onde o bosque escuta",
    42,
    32,
    T.MOSS,
    T.GRASS,
    0.22,
    "tree",
    { x: 18, y: 80 },
    "wild"
  ),
  A(
    "torre",
    "Torre do Sino",
    "Vigia a distancia e a mesagem",
    20,
    20,
    T.STONE,
    T.DARK,
    0.34,
    "stone",
    { x: 76, y: 48 },
    "castle"
  ),
  A(
    "muralha",
    "Muralha Norte",
    "A fronteira entre o reino e o mundo",
    30,
    22,
    T.STONE,
    T.DIRT,
    0.2,
    "stone",
    { x: 86, y: 58 },
    "castle"
  ),
  A(
    "cemiterio",
    "Cemitério das Cinzas",
    "A cidade de baixo",
    30,
    24,
    T.GRAVE,
    T.GRASS,
    0.28,
    "hedge",
    { x: 30, y: 38 },
    "wild"
  ),
  A(
    "porto",
    "Cais do Rio",
    "O reino se compra e se vende",
    36,
    24,
    T.WOOD,
    T.WATER,
    0.12,
    "water",
    { x: 8, y: 36 },
    "water"
  ),
  A(
    "fornalha",
    "Fornalha da Cidade",
    "Onde o ferro lembra quem mandou",
    24,
    18,
    T.DARK,
    T.STONE,
    0.38,
    "stone",
    { x: 10, y: 64 },
    "town"
  ),
  A(
    "solar",
    "Solar de Valdessa",
    "Fortuna que nao dorme",
    30,
    22,
    T.MARBLE,
    T.CARPET,
    0.15,
    "stone",
    { x: 88, y: 24 },
    "castle"
  ),
  A(
    "corvo",
    "Casa do Corvo",
    "O preco da verdade",
    20,
    16,
    T.DARK,
    T.WOOD,
    0.62,
    "wood",
    { x: 94, y: 42 },
    "crypt"
  ),
  A(
    "salao",
    "Salão dos Banquetes",
    "Danças, brindes e agora s",
    28,
    20,
    T.WOOD,
    T.CARPET,
    0.2,
    "stone",
    { x: 68, y: 42 },
    "castle"
  ),
];

const byId = (id: string) => AREA_DEFS.find((a) => a.id === id)!;

/* ------------------------------------------------------------------ */
/* VILА DE CINZAS                                                      */
/* ------------------------------------------------------------------ */
{
  const a = byId("vila");
  a.floors.push(r(12, 10, 16, 10, T.DIRT), r(1, 14, 38, 3, T.DIRT), r(10, 9, 20, 2, T.ROAD));
  a.walls.push(
    r(4, 4, 8, 6, T.WALL_WOOD),
    r(27, 4, 9, 6, T.WALL_WOOD),
    r(4, 21, 8, 6, T.WALL_WOOD),
    r(28, 22, 7, 6, T.WALL_WOOD)
  );
  a.scatter.push({ k: T.TREE, count: 26, seed: 11 });
  a.props.push(
    { k: "well", x: 19, y: 13 },
    { k: "fence", x: 12, y: 20 },
    { k: "fence", x: 13, y: 20 },
    { k: "fence", x: 14, y: 20 },
    { k: "hay", x: 25, y: 25 },
    { k: "cart", x: 33, y: 12 },
    { k: "bench", x: 16, y: 18 },
    { k: "bench", x: 22, y: 18 },
    { k: "flower", x: 18, y: 11 },
    { k: "flower", x: 21, y: 11 },
    { k: "flower", x: 18, y: 16 },
    { k: "flower", x: 21, y: 16 },
    { k: "torch", x: 13, y: 12 },
    { k: "torch", x: 26, y: 12 },
    { k: "sign", x: 11, y: 16 }
  );
  a.lights.push({ x: 13, y: 12, r: 58, c: "#ffb45a" }, { x: 26, y: 12, r: 58, c: "#ffb45a" });
  a.npcs.push(
    { id: "tao", x: 9, y: 12 },
    { id: "perpetua", x: 20, y: 18 },
    { id: "ludovina", x: 15, y: 7 }
  );
}

/* ------------------------------------------------------------------ */
/* MERCADO DE PEDRA                                                    */
/* ------------------------------------------------------------------ */
{
  const a = byId("mercado");
  a.floors.push(r(2, 10, 32, 5, T.ROAD), r(10, 2, 16, 22, T.ROAD), r(2, 2, 8, 24, T.DIRT));
  a.walls.push(r(27, 16, 7, 8, T.WALL_STONE), r(2, 2, 8, 6, T.WALL_STONE));
  a.scatter.push({ k: T.ROCK, count: 8, seed: 33 });
  a.props.push(
    { k: "stall", x: 8, y: 8 },
    { k: "stall", x: 13, y: 8 },
    { k: "stall", x: 18, y: 8 },
    { k: "stall", x: 23, y: 8 },
    { k: "crate", x: 8, y: 7 },
    { k: "crate", x: 24, y: 7 },
    { k: "sack", x: 6, y: 18 },
    { k: "sack", x: 7, y: 19 },
    { k: "statue", x: 18, y: 13 },
    { k: "bench", x: 12, y: 16 },
    { k: "bench", x: 24, y: 16 },
    { k: "torch", x: 5, y: 12 },
    { k: "torch", x: 30, y: 12 },
    { k: "flower", x: 16, y: 20 },
    { k: "flower", x: 20, y: 20 }
  );
  a.lights.push({ x: 5, y: 12, r: 60, c: "#ffb45a" }, { x: 30, y: 12, r: 60, c: "#ffb45a" });
  a.npcs.push(
    { id: "pardal", x: 14, y: 14 },
    { id: "arras", x: 9, y: 19 },
    { id: "tav", x: 24, y: 20 }
  );
}

/* ------------------------------------------------------------------ */
/* TAVERNA DO CORVO                                                    */
/* ------------------------------------------------------------------ */
{
  const a = byId("taverna");
  a.floors.push(r(3, 3, 20, 14, T.WOOD), r(3, 5, 20, 2, T.DARK));
  a.walls.push(r(4, 3, 18, 2, T.BLOCK));
  a.props.push(
    { k: "table", x: 7, y: 9 },
    { k: "table", x: 12, y: 9 },
    { k: "table", x: 17, y: 9 },
    { k: "table", x: 8, y: 14 },
    { k: "table", x: 14, y: 14 },
    { k: "table", x: 19, y: 14 },
    { k: "chair", x: 6, y: 9 },
    { k: "chair", x: 13, y: 9 },
    { k: "chair", x: 18, y: 9 },
    { k: "chair", x: 7, y: 14 },
    { k: "chair", x: 15, y: 14 },
    { k: "barrel", x: 3, y: 8 },
    { k: "barrel", x: 3, y: 9 },
    { k: "barrel", x: 22, y: 8 },
    { k: "shelf", x: 12, y: 6 },
    { k: "torch", x: 4, y: 7 },
    { k: "torch", x: 21, y: 7 },
    { k: "torch", x: 4, y: 16 },
    { k: "torch", x: 21, y: 16 },
    { k: "brazier", x: 12, y: 17 },
    { k: "bench", x: 10, y: 16 },
    { k: "bench", x: 16, y: 16 }
  );
  a.lights.push(
    { x: 4, y: 7, r: 70, c: "#ff9a3c" },
    { x: 21, y: 7, r: 70, c: "#ff9a3c" },
    { x: 4, y: 16, r: 70, c: "#ff9a3c" },
    { x: 21, y: 16, r: 70, c: "#ff9a3c" },
    { x: 12, y: 17, r: 80, c: "#ff7a2a" }
  );
  a.npcs.push(
    { id: "taveiro", x: 8, y: 12 },
    { id: "tav", x: 16, y: 11 },
    { id: "godiva", x: 20, y: 12 }
  );
  a.items.push({ id: "w1", item: "vinho", x: 12, y: 9 });
}

/* ------------------------------------------------------------------ */
/* PONTE DAS ALMAS                                                     */
/* ------------------------------------------------------------------ */
{
  const a = byId("ponte");
  a.floors.push(
    r(0, 9, 30, 5, T.WATER),
    r(13, 7, 5, 9, T.ROAD),
    r(2, 2, 26, 6, T.DIRT),
    r(2, 14, 26, 6, T.DIRT)
  );
  a.walls.push(r(13, 8, 1, 5, T.WALL_STONE), r(17, 8, 1, 5, T.WALL_STONE));
  a.scatter.push({ k: T.TREE, count: 20, seed: 77, on: T.GRASS });
  a.props.push(
    { k: "torch", x: 12, y: 7 },
    { k: "torch", x: 18, y: 7 },
    { k: "torch", x: 12, y: 15 },
    { k: "torch", x: 18, y: 15 },
    { k: "cart", x: 6, y: 6 },
    { k: "bench", x: 24, y: 6 },
    { k: "flower", x: 10, y: 17 },
    { k: "flower", x: 22, y: 4 }
  );
  a.lights.push(
    { x: 12, y: 7, r: 66, c: "#ffb45a" },
    { x: 18, y: 7, r: 66, c: "#ffb45a" },
    { x: 12, y: 15, r: 66, c: "#ffb45a" },
    { x: 18, y: 15, r: 66, c: "#ffb45a" }
  );
  a.npcs.push({ id: "aldric", x: 21, y: 14 });
}

/* ------------------------------------------------------------------ */
/* CASTELO REAL                                                        */
/* ------------------------------------------------------------------ */
{
  const a = byId("castelo");
  a.floors.push(r(6, 4, 28, 20, T.STONE), r(4, 12, 32, 4, T.DIRT));
  a.walls.push(r(9, 1, 22, 4, T.WALL_STONE), r(2, 4, 5, 9, T.WALL_STONE), r(33, 14, 5, 9, T.WALL_STONE));
  a.scatter.push({ k: T.ROCK, count: 6, seed: 5 });
  a.props.push(
    { k: "banner", x: 12, y: 5 },
    { k: "banner", x: 19, y: 5 },
    { k: "banner", x: 26, y: 5 },
    { k: "statue", x: 10, y: 10 },
    { k: "statue", x: 29, y: 10 },
    { k: "crate", x: 8, y: 20 },
    { k: "crate", x: 9, y: 21 },
    { k: "sack", x: 30, y: 21 },
    { k: "anvil", x: 13, y: 20 },
    { k: "brazier", x: 18, y: 19 },
    { k: "brazier", x: 22, y: 19 },
    { k: "torch", x: 7, y: 13 },
    { k: "torch", x: 32, y: 13 },
    { k: "bench", x: 15, y: 16 }
  );
  a.lights.push(
    { x: 18, y: 19, r: 80, c: "#ff7a2a" },
    { x: 22, y: 19, r: 80, c: "#ff7a2a" },
    { x: 7, y: 13, r: 64, c: "#ffb45a" },
    { x: 32, y: 13, r: 64, c: "#ffb45a" }
  );
  a.npcs.push({ id: "condestavel", x: 22, y: 15 });
}

/* ------------------------------------------------------------------ */
/* SALAO DO TRONO                                                      */
/* ------------------------------------------------------------------ */
{
  const a = byId("trono");
  a.floors.push(r(2, 2, 24, 16, T.MARBLE), r(9, 5, 10, 12, T.CARPET));
  a.walls.push(r(11, 2, 6, 2, T.WALL_STONE));
  a.props.push(
    { k: "pillar", x: 5, y: 6 },
    { k: "pillar", x: 5, y: 14 },
    { k: "pillar", x: 23, y: 6 },
    { k: "pillar", x: 23, y: 14 },
    { k: "banner", x: 7, y: 4 },
    { k: "banner", x: 21, y: 4 },
    { k: "throne", x: 14, y: 4 },
    { k: "brazier", x: 8, y: 10 },
    { k: "brazier", x: 20, y: 10 },
    { k: "rug", x: 14, y: 12 },
    { k: "candle", x: 10, y: 3 },
    { k: "candle", x: 18, y: 3 }
  );
  a.lights.push(
    { x: 8, y: 10, r: 78, c: "#ff8a3a" },
    { x: 20, y: 10, r: 78, c: "#ff8a3a" },
    { x: 14, y: 3, r: 70, c: "#ffe08a" }
  );
  a.npcs.push(
    { id: "rei", x: 14, y: 6 },
    { id: "rainha", x: 8, y: 11 },
    { id: "sereno", x: 21, y: 15 }
  );
}

/* ------------------------------------------------------------------ */
/* CAMARA DO CONSELHO                                                  */
/* ------------------------------------------------------------------ */
{
  const a = byId("conselho");
  a.floors.push(r(2, 2, 22, 14, T.DARK), r(4, 7, 18, 5, T.WOOD));
  a.walls.push(r(2, 2, 22, 1, T.WALL_STONE));
  a.props.push(
    { k: "table", x: 9, y: 8 },
    { k: "table", x: 13, y: 8 },
    { k: "table", x: 17, y: 8 },
    { k: "chair", x: 9, y: 10 },
    { k: "chair", x: 13, y: 10 },
    { k: "chair", x: 17, y: 10 },
    { k: "shelf", x: 3, y: 4 },
    { k: "shelf", x: 3, y: 6 },
    { k: "shelf", x: 22, y: 4 },
    { k: "shelf", x: 22, y: 6 },
    { k: "banner", x: 13, y: 3 },
    { k: "torch", x: 4, y: 14 },
    { k: "torch", x: 21, y: 14 },
    { k: "chest", x: 22, y: 14 },
    { k: "brazier", x: 12, y: 15 }
  );
  a.lights.push(
    { x: 4, y: 14, r: 68, c: "#ffb45a" },
    { x: 21, y: 14, r: 68, c: "#ffb45a" },
    { x: 12, y: 15, r: 70, c: "#ff8a3a" }
  );
  a.npcs.push(
    { id: "chanceler", x: 9, y: 8 },
    { id: "gaspar", x: 18, y: 11 },
    { id: "aurelio", x: 13, y: 14 }
  );
  a.items.push({ id: "w6", item: "diario", x: 22, y: 14 });
}

/* ------------------------------------------------------------------ */
/* CAPELA DA COROA                                                     */
/* ------------------------------------------------------------------ */
{
  const a = byId("capela");
  a.floors.push(r(2, 2, 18, 14, T.MARBLE), r(9, 2, 4, 12, T.CARPET));
  a.walls.push(r(2, 2, 18, 1, T.WALL_STONE));
  a.props.push(
    { k: "altar", x: 11, y: 3 },
    { k: "candle", x: 9, y: 4 },
    { k: "candle", x: 13, y: 4 },
    { k: "bench", x: 7, y: 8 },
    { k: "bench", x: 7, y: 11 },
    { k: "bench", x: 15, y: 8 },
    { k: "bench", x: 15, y: 11 },
    { k: "banner", x: 5, y: 3 },
    { k: "banner", x: 17, y: 3 },
    { k: "torch", x: 3, y: 15 },
    { k: "torch", x: 19, y: 15 },
    { k: "flower", x: 10, y: 12 },
    { k: "flower", x: 12, y: 12 }
  );
  a.lights.push(
    { x: 3, y: 15, r: 62, c: "#ffcf7a" },
    { x: 19, y: 15, r: 62, c: "#ffcf7a" },
    { x: 11, y: 3, r: 70, c: "#ffe8b0" }
  );
  a.npcs.push(
    { id: "prior", x: 11, y: 8 },
    { id: "leonor", x: 6, y: 14 },
    { id: "umbelina", x: 16, y: 14 }
  );
}

/* ------------------------------------------------------------------ */
/* CRIPTA SOMBRIA                                                       */
/* ------------------------------------------------------------------ */
{
  const a = byId("cripta");
  a.floors.push(r(2, 2, 20, 14, T.CRYPT));
  a.walls.push(r(2, 2, 20, 1, T.WALL_STONE));
  a.props.push(
    { k: "pillar", x: 5, y: 5 },
    { k: "pillar", x: 5, y: 12 },
    { k: "pillar", x: 18, y: 5 },
    { k: "pillar", x: 18, y: 12 },
    { k: "candle", x: 8, y: 3 },
    { k: "candle", x: 15, y: 3 },
    { k: "candle", x: 8, y: 15 },
    { k: "candle", x: 15, y: 15 },
    { k: "statue", x: 12, y: 4 },
    { k: "chest", x: 3, y: 15 },
    { k: "brazier", x: 12, y: 13 }
  );
  a.lights.push(
    { x: 8, y: 3, r: 52, c: "#ffcf7a" },
    { x: 15, y: 3, r: 52, c: "#ffcf7a" },
    { x: 8, y: 15, r: 52, c: "#ffcf7a" },
    { x: 15, y: 15, r: 52, c: "#ffcf7a" },
    { x: 12, y: 13, r: 66, c: "#ff7a2a" }
  );
  a.npcs.push({ id: "fantasma", x: 12, y: 9 });
}

/* ------------------------------------------------------------------ */
/* BOSQUE CINEREA                                                      */
/* ------------------------------------------------------------------ */
{
  const a = byId("bosque");
  a.floors.push(r(16, 12, 10, 10, T.DIRT), r(2, 2, 38, 6, T.MOSS));
  a.scatter.push({ k: T.TREE, count: 110, seed: 91, on: T.MOSS }, { k: T.ROCK, count: 12, seed: 12 });
  a.props.push(
    { k: "campfire", x: 21, y: 16 },
    { k: "chest", x: 25, y: 18 },
    { k: "statue", x: 18, y: 18 },
    { k: "bench", x: 23, y: 15 },
    { k: "torch", x: 16, y: 13 },
    { k: "torch", x: 25, y: 13 },
    { k: "flower", x: 19, y: 14 },
    { k: "flower", x: 22, y: 20 }
  );
  a.lights.push(
    { x: 21, y: 16, r: 76, c: "#ff7a2a" },
    { x: 16, y: 13, r: 56, c: "#ffb45a" },
    { x: 25, y: 13, r: 56, c: "#ffb45a" }
  );
  a.npcs.push({ id: "bruma", x: 32, y: 22 });
  a.items.push({ id: "w2", item: "erva", x: 24, y: 19 });
}

/* ------------------------------------------------------------------ */
/* TORRE DO SINO                                                       */
/* ------------------------------------------------------------------ */
{
  const a = byId("torre");
  a.floors.push(r(2, 2, 16, 16, T.STONE), r(6, 6, 8, 8, T.DARK));
  a.walls.push(r(2, 2, 16, 1, T.WALL_STONE));
  a.props.push(
    { k: "pillar", x: 4, y: 5 },
    { k: "pillar", x: 15, y: 5 },
    { k: "pillar", x: 4, y: 14 },
    { k: "pillar", x: 15, y: 14 },
    { k: "banner", x: 10, y: 3 },
    { k: "brazier", x: 10, y: 8 },
    { k: "crate", x: 4, y: 9 },
    { k: "crate", x: 15, y: 9 },
    { k: "torch", x: 6, y: 17 },
    { k: "torch", x: 13, y: 17 }
  );
  a.lights.push(
    { x: 10, y: 8, r: 80, c: "#ff7a2a" },
    { x: 6, y: 17, r: 60, c: "#ffb45a" },
    { x: 13, y: 17, r: 60, c: "#ffb45a" }
  );
  a.npcs.push({ id: "vargo", x: 10, y: 13 });
}

/* ------------------------------------------------------------------ */
/* MURALHA NORTE                                                       */
/* ------------------------------------------------------------------ */
{
  const a = byId("muralha");
  a.floors.push(r(2, 2, 26, 18, T.STONE), r(4, 8, 22, 4, T.DIRT));
  a.walls.push(r(2, 2, 26, 1, T.WALL_STONE), r(2, 19, 26, 1, T.WALL_STONE));
  a.props.push(
    { k: "pillar", x: 4, y: 4 },
    { k: "pillar", x: 12, y: 4 },
    { k: "pillar", x: 20, y: 4 },
    { k: "pillar", x: 4, y: 15 },
    { k: "pillar", x: 12, y: 15 },
    { k: "pillar", x: 20, y: 15 },
    { k: "banner", x: 8, y: 3 },
    { k: "banner", x: 16, y: 3 },
    { k: "crate", x: 25, y: 6 },
    { k: "sack", x: 25, y: 7 },
    { k: "brazier", x: 8, y: 9 },
    { k: "brazier", x: 22, y: 9 },
    { k: "bench", x: 10, y: 12 },
    { k: "torch", x: 5, y: 18 },
    { k: "torch", x: 25, y: 18 }
  );
  a.lights.push(
    { x: 8, y: 9, r: 74, c: "#ff7a2a" },
    { x: 22, y: 9, r: 74, c: "#ff7a2a" },
    { x: 5, y: 18, r: 58, c: "#ffb45a" },
    { x: 25, y: 18, r: 58, c: "#ffb45a" }
  );
  a.npcs.push(
    { id: "capitao", x: 16, y: 11 },
    { id: "vargo", x: 23, y: 14 },
    { id: "silvino", x: 6, y: 16 }
  );
}

/* ------------------------------------------------------------------ */
/* CEMITERIO DAS CINZAS                                                */
/* ------------------------------------------------------------------ */
{
  const a = byId("cemiterio");
  a.floors.push(r(2, 2, 26, 20, T.GRAVE), r(12, 2, 6, 20, T.DIRT));
  a.walls.push(r(2, 2, 26, 1, T.HEDGE), r(2, 21, 26, 1, T.HEDGE));
  a.props.push(
    { k: "grave", x: 5, y: 5 },
    { k: "grave", x: 8, y: 5 },
    { k: "grave", x: 5, y: 9 },
    { k: "grave", x: 8, y: 9 },
    { k: "grave", x: 20, y: 6 },
    { k: "grave", x: 23, y: 6 },
    { k: "grave", x: 20, y: 11 },
    { k: "grave", x: 23, y: 14 },
    { k: "grave", x: 6, y: 16 },
    { k: "statue", x: 15, y: 10 },
    { k: "torch", x: 11, y: 4 },
    { k: "torch", x: 18, y: 18 },
    { k: "flower", x: 14, y: 6 },
    { k: "flower", x: 16, y: 16 }
  );
  a.lights.push(
    { x: 11, y: 4, r: 58, c: "#9fc8ff" },
    { x: 18, y: 18, r: 58, c: "#9fc8ff" }
  );
  a.npcs.push({ id: "sereno", x: 12, y: 12 });
}

/* ------------------------------------------------------------------ */
/* CAIS DO RIO                                                         */
/* ------------------------------------------------------------------ */
{
  const a = byId("porto");
  a.floors.push(r(2, 12, 32, 10, T.WOOD), r(2, 2, 32, 9, T.WATER));
  a.walls.push(r(2, 2, 1, 20, T.WALL_STONE), r(33, 2, 1, 20, T.WALL_STONE));
  a.props.push(
    { k: "boat", x: 8, y: 6 },
    { k: "boat", x: 20, y: 5 },
    { k: "boat", x: 29, y: 7 },
    { k: "crate", x: 5, y: 14 },
    { k: "crate", x: 6, y: 15 },
    { k: "crate", x: 7, y: 14 },
    { k: "sack", x: 9, y: 17 },
    { k: "sack", x: 10, y: 18 },
    { k: "barrel", x: 26, y: 16 },
    { k: "barrel", x: 27, y: 17 },
    { k: "torch", x: 4, y: 13 },
    { k: "torch", x: 31, y: 13 },
    { k: "torch", x: 15, y: 20 },
    { k: "sign", x: 15, y: 13 }
  );
  a.lights.push(
    { x: 4, y: 13, r: 62, c: "#ffb45a" },
    { x: 31, y: 13, r: 62, c: "#ffb45a" },
    { x: 15, y: 20, r: 62, c: "#ffb45a" }
  );
  a.npcs.push({ id: "nilo", x: 25, y: 15 });
  a.items.push({ id: "w3", item: "contrato", x: 12, y: 19 });
}

/* ------------------------------------------------------------------ */
/* FORNALHA DA CIDADE                                                  */
/* ------------------------------------------------------------------ */
{
  const a = byId("fornalha");
  a.floors.push(r(2, 2, 20, 14, T.DARK), r(8, 8, 8, 6, T.STONE));
  a.walls.push(r(2, 2, 20, 1, T.WALL_STONE));
  a.props.push(
    { k: "forge", x: 11, y: 4 },
    { k: "anvil", x: 10, y: 10 },
    { k: "anvil", x: 14, y: 10 },
    { k: "barrel", x: 4, y: 5 },
    { k: "barrel", x: 5, y: 6 },
    { k: "crate", x: 18, y: 4 },
    { k: "crate", x: 19, y: 5 },
    { k: "sack", x: 6, y: 13 },
    { k: "brazier", x: 9, y: 14 },
    { k: "brazier", x: 15, y: 14 },
    { k: "torch", x: 4, y: 9 },
    { k: "torch", x: 19, y: 9 }
  );
  a.lights.push(
    { x: 11, y: 4, r: 90, c: "#ff5a1a" },
    { x: 9, y: 14, r: 66, c: "#ff7a2a" },
    { x: 15, y: 14, r: 66, c: "#ff7a2a" },
    { x: 4, y: 9, r: 56, c: "#ffb45a" },
    { x: 19, y: 9, r: 56, c: "#ffb45a" }
  );
  a.npcs.push({ id: "bruna", x: 12, y: 10 });
}

/* ------------------------------------------------------------------ */
/* SOLAR DE VALDESSA                                                   */
/* ------------------------------------------------------------------ */
{
  const a = byId("solar");
  a.floors.push(r(2, 2, 26, 18, T.MARBLE), r(11, 4, 8, 14, T.CARPET));
  a.walls.push(r(2, 2, 26, 1, T.WALL_STONE));
  a.props.push(
    { k: "pillar", x: 5, y: 5 },
    { k: "pillar", x: 5, y: 16 },
    { k: "pillar", x: 24, y: 5 },
    { k: "pillar", x: 24, y: 16 },
    { k: "throne", x: 15, y: 5 },
    { k: "banner", x: 9, y: 3 },
    { k: "banner", x: 21, y: 3 },
    { k: "brazier", x: 8, y: 10 },
    { k: "brazier", x: 22, y: 10 },
    { k: "shelf", x: 3, y: 8 },
    { k: "shelf", x: 3, y: 10 },
    { k: "rug", x: 15, y: 12 },
    { k: "flower", x: 13, y: 16 },
    { k: "flower", x: 17, y: 16 }
  );
  a.lights.push(
    { x: 8, y: 10, r: 80, c: "#ff8a3a" },
    { x: 22, y: 10, r: 80, c: "#ff8a3a" },
    { x: 15, y: 5, r: 64, c: "#ffe08a" }
  );
  a.npcs.push(
    { id: "valdessa", x: 12, y: 9 },
    { id: "duque", x: 21, y: 16 }
  );
  a.items.push({ id: "w4", item: "carta", x: 19, y: 12 }, { id: "w4b", item: "anel", x: 24, y: 12 });
}

/* ------------------------------------------------------------------ */
/* CASA DO CORVO                                                       */
/* ------------------------------------------------------------------ */
{
  const a = byId("corvo");
  a.floors.push(r(2, 2, 16, 12, T.DARK), r(5, 5, 10, 8, T.WOOD));
  a.walls.push(r(2, 2, 16, 1, T.WALL_WOOD));
  a.props.push(
    { k: "table", x: 8, y: 7 },
    { k: "table", x: 12, y: 7 },
    { k: "shelf", x: 3, y: 4 },
    { k: "shelf", x: 3, y: 6 },
    { k: "shelf", x: 3, y: 8 },
    { k: "shelf", x: 16, y: 4 },
    { k: "shelf", x: 16, y: 6 },
    { k: "candle", x: 6, y: 3 },
    { k: "candle", x: 13, y: 3 },
    { k: "candle", x: 6, y: 12 },
    { k: "candle", x: 13, y: 12 },
    { k: "chest", x: 16, y: 12 },
    { k: "brazier", x: 10, y: 10 }
  );
  a.lights.push(
    { x: 6, y: 3, r: 48, c: "#a0c0ff" },
    { x: 13, y: 3, r: 48, c: "#a0c0ff" },
    { x: 6, y: 12, r: 48, c: "#a0c0ff" },
    { x: 13, y: 12, r: 48, c: "#a0c0ff" },
    { x: 10, y: 10, r: 60, c: "#ff7a2a" }
  );
  a.npcs.push({ id: "vesper", x: 10, y: 8 });
  a.items.push({ id: "w5", item: "cifra", x: 16, y: 12 });
}

/* ------------------------------------------------------------------ */
/* SALAO DOS BANQUETES                                                 */
/* ------------------------------------------------------------------ */
{
  const a = byId("salao");
  a.floors.push(r(2, 2, 24, 16, T.WOOD), r(10, 2, 8, 16, T.CARPET));
  a.walls.push(r(2, 2, 24, 1, T.WALL_STONE));
  a.props.push(
    { k: "table", x: 6, y: 6 },
    { k: "table", x: 6, y: 11 },
    { k: "table", x: 22, y: 6 },
    { k: "table", x: 22, y: 11 },
    { k: "chair", x: 7, y: 6 },
    { k: "chair", x: 5, y: 6 },
    { k: "chair", x: 7, y: 11 },
    { k: "chair", x: 21, y: 6 },
    { k: "chair", x: 23, y: 11 },
    { k: "banner", x: 8, y: 3 },
    { k: "banner", x: 20, y: 3 },
    { k: "brazier", x: 13, y: 6 },
    { k: "brazier", x: 15, y: 13 },
    { k: "bench", x: 13, y: 17 },
    { k: "torch", x: 4, y: 16 },
    { k: "torch", x: 24, y: 16 }
  );
  a.lights.push(
    { x: 13, y: 6, r: 82, c: "#ff8a3a" },
    { x: 15, y: 13, r: 82, c: "#ff8a3a" },
    { x: 4, y: 16, r: 60, c: "#ffb45a" },
    { x: 24, y: 16, r: 60, c: "#ffb45a" }
  );
  a.npcs.push(
    { id: "otavio", x: 16, y: 12 },
    { id: "ismael", x: 9, y: 13 }
  );
}

/* ------------------------------------------------------------------ */
/* PORTALS                                                             */
/* ------------------------------------------------------------------ */
export interface Portal {
  fromArea: string;
  fromX: number;
  fromY: number;
  toArea: string;
  toX: number;
  toY: number;
}

export const PORTALS: Portal[] = [
  { fromArea: "vila", fromX: 38, fromY: 14, toArea: "mercado", toX: 1, toY: 13 },
  { fromArea: "vila", fromX: 0, fromY: 15, toArea: "ponte", toX: 28, toY: 5 },
  { fromArea: "vila", fromX: 10, fromY: 29, toArea: "fornalha", toX: 11, toY: 1 },
  { fromArea: "vila", fromX: 37, fromY: 22, toArea: "taverna", toX: 1, toY: 10 },
  { fromArea: "mercado", fromX: 17, fromY: 25, toArea: "castelo", toX: 19, toY: 26 },
  { fromArea: "mercado", fromX: 35, fromY: 1, toArea: "torre", toX: 1, toY: 16 },
  { fromArea: "taverna", fromX: 24, fromY: 1, toArea: "salao", toX: 1, toY: 17 },
  { fromArea: "ponte", fromX: 10, fromY: 0, toArea: "porto", toX: 12, toY: 22 },
  { fromArea: "ponte", fromX: 29, fromY: 21, toArea: "cemiterio", toX: 1, toY: 21 },
  { fromArea: "castelo", fromX: 19, fromY: 0, toArea: "trono", toX: 13, toY: 18 },
  { fromArea: "castelo", fromX: 39, fromY: 13, toArea: "conselho", toX: 1, toY: 8 },
  { fromArea: "castelo", fromX: 0, fromY: 12, toArea: "capela", toX: 21, toY: 9 },
  { fromArea: "capela", fromX: 11, fromY: 0, toArea: "cripta", toX: 12, toY: 17 },
  { fromArea: "capela", fromX: 1, fromY: 17, toArea: "cemiterio", toX: 28, toY: 20 },
  { fromArea: "conselho", fromX: 25, fromY: 2, toArea: "solar", toX: 1, toY: 20 },
  { fromArea: "trono", fromX: 0, fromY: 9, toArea: "salao", toX: 27, toY: 9 },
  { fromArea: "conselho", fromX: 25, fromY: 16, toArea: "torre", toX: 9, toY: 0 },
  { fromArea: "torre", fromX: 15, fromY: 19, toArea: "muralha", toX: 14, toY: 1 },
  { fromArea: "muralha", fromX: 29, fromY: 11, toArea: "corvo", toX: 1, toY: 8 },
  { fromArea: "vila", fromX: 2, fromY: 27, toArea: "bosque", toX: 40, toY: 2 },
  { fromArea: "bosque", fromX: 0, fromY: 15, toArea: "fornalha", toX: 23, toY: 10 },
];

/** NPC placements per area (position + id), used for both rendering and interaction. */
export const NPCS_BY_AREA: Record<string, { id: string; x: number; y: number }[]> =
  Object.fromEntries(AREA_DEFS.map((a) => [a.id, a.npcs.map((n) => ({ ...n }))]));

/* ------------------------------------------------------------------ */
/* MAP BUILDER                                                         */
/* ------------------------------------------------------------------ */

function mulberry(seed: number) {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

export interface BuiltArea {
  def: AreaDef;
  tiles: Uint8Array;
  props: Prop[];
  lights: Light[];
  portals: { x: number; y: number; toArea: string; toX: number; toY: number }[];
}

export function buildArea(id: string): BuiltArea {
  const def = byId(id);
  const { w, h } = def;
  const tiles = new Uint8Array(w * h);
  const rnd = mulberry(def.map.x * 131 + def.map.y * 17 + w * 7 + h);

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const n = rnd();
      tiles[y * w + x] = n < 0.22 ? def.alt : def.ground;
    }
  }

  const setRect = (rc: Rect, t: number) => {
    for (let y = rc.y; y < rc.y + rc.h; y++) {
      for (let x = rc.x; x < rc.x + rc.w; x++) {
        if (x < 0 || y < 0 || x >= w || y >= h) continue;
        tiles[y * w + x] = t;
      }
    }
  };
  def.floors.forEach((f) => setRect(f, f.t));

  // border
  if (def.border !== "none") {
    const bt =
      def.border === "stone"
        ? T.WALL_STONE
        : def.border === "wood"
          ? T.WALL_WOOD
          : def.border === "tree"
            ? T.TREE
            : def.border === "hedge"
              ? T.HEDGE
              : T.WATER;
    for (let x = 0; x < w; x++) {
      tiles[x] = bt;
      tiles[(h - 1) * w + x] = bt;
    }
    for (let y = 0; y < h; y++) {
      tiles[y * w] = bt;
      tiles[y * w + w - 1] = bt;
    }
  }
  def.walls.forEach((f) => setRect(f, f.t));

  // scatter
  def.scatter.forEach((sc) => {
    const r2 = mulberry(sc.seed);
    let placed = 0;
    let guard = 0;
    while (placed < sc.count && guard < sc.count * 40) {
      guard++;
      const x = 1 + Math.floor(r2() * (w - 2));
      const y = 1 + Math.floor(r2() * (h - 2));
      const cur = tiles[y * w + x];
      if (cur >= SOLID_MIN) continue;
      if (sc.on !== undefined && cur !== sc.on && cur !== def.ground && cur !== def.alt) continue;
      if (sc.on === undefined && cur !== def.ground && cur !== def.alt) continue;
      tiles[y * w + x] = sc.k;
      placed++;
    }
  });

  const props: Prop[] = def.props.map((p) => ({ kind: p.k, x: p.x, y: p.y }));
  const lights = def.lights.slice();

  const clear = (x: number, y: number) => {
    if (x < 0 || y < 0 || x >= w || y >= h) return;
    const cur = tiles[y * w + x];
    if (cur >= SOLID_MIN) tiles[y * w + x] = def.ground === T.WATER ? T.WOOD : def.ground;
  };
  def.npcs.forEach((n) => clear(n.x, n.y));
  def.items.forEach((it) => clear(it.x, it.y));

  // clear destination tiles too, otherwise the player arrives inside a wall
  PORTALS.filter((p) => p.toArea === id).forEach((p) => clear(p.toX, p.toY));

  const portals = PORTALS.filter((p) => p.fromArea === id).map((p) => {
    clear(p.fromX, p.fromY);
    return { x: p.fromX, y: p.fromY, toArea: p.toArea, toX: p.toX, toY: p.toY };
  });

  return { def, tiles, props, lights, portals };
}
