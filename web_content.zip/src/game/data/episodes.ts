import type { EpisodeDef } from "../types";
import { EPISODES_A } from "./episodes-a";
import { EPISODES_B } from "./episodes-b";
import { EPISODES_C } from "./episodes-c";

const CACHE = new Map<number, EpisodeDef>();

for (const ep of [...EPISODES_A, ...EPISODES_B, ...EPISODES_C]) {
  CACHE.set(ep.id, ep);
}

export function getEpisode(id: number): EpisodeDef | undefined {
  return CACHE.get(id);
}

export function episodeMeta(): { id: number; title: string; kind: EpisodeDef["kind"]; location: string }[] {
  return [...CACHE.values()].map((e) => ({
    id: e.id,
    title: e.title,
    kind: e.kind,
    location: e.location,
  }));
}

export const EPISODE_COUNT = 35;
