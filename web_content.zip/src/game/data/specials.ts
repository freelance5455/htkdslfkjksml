export interface ArdenSpecial {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  requirement: string;
  sequence: string[];
  voice?: string;
}

export const ARDEN_SPECIALS: ArdenSpecial[] = [
  {
    id: "command-strike",
    name: "Command Strike",
    subtitle: "Squad-wide execution",
    description: "Arden marks the enemy and directs every available fighter into one coordinated attack sequence.",
    requirement: "Unlocked by squad command training.",
    sequence: ["ARDEN MARKS TARGET", "ROOK", "MIRA", "VALE", "NYX", "SERA", "KADE", "ASTRA", "ORIN", "LENA", "CAEL"],
    voice: "Move. One opening. Everyone takes it.",
  },
  {
    id: "time-fracture",
    name: "Time Fracture",
    subtitle: "Temporal interruption",
    description: "The Time Cracker tears a brief gap through the enemy's action timeline.",
    requirement: "Discover the Time Cracker.",
    sequence: ["TIME CRACKER", "CLOCKLINE SPLIT", "ENEMY TELEGRAPHS DELAYED"],
    voice: "Not yet. Your turn can wait.",
  },
  {
    id: "tactical-shift",
    name: "Tactical Shift",
    subtitle: "Formation rotation",
    description: "Arden rotates the squad's formation to change who absorbs pressure and who controls distance.",
    requirement: "Manager Level 3.",
    sequence: ["FRONT", "MIDDLE", "REAR", "FORMATION RESET"],
    voice: "Change places. Change the fight.",
  },
  {
    id: "void-command",
    name: "Void Command",
    subtitle: "Anomaly suppression",
    description: "Arden cuts through unstable field energy, reducing anomaly pressure and erasing enemy telegraphs.",
    requirement: "Discover a major supernatural anomaly.",
    sequence: ["ANOMALY RISE", "COMMAND", "FIELD QUIETS", "TELEGRAPHS CLEARED"],
    voice: "Quiet. I need the field to listen.",
  },
  {
    id: "reversal",
    name: "Reversal",
    subtitle: "Momentum theft",
    description: "Arden turns a losing tempo into an opening for the squad.",
    requirement: "Win a major Clash after reaching high Momentum.",
    sequence: ["ENEMY ADVANCES", "ARDEN READS THE LINE", "REVERSAL", "MOMENTUM STOLEN"],
    voice: "I know where this ends.",
  },
];

export const SPECIAL_BY_ID = Object.fromEntries(ARDEN_SPECIALS.map((s) => [s.id, s]));
