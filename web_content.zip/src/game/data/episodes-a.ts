import type { DialogueLine, Emotion, EpisodeDef, ExploreNode } from "../types";

const L = (speaker: string, text: string, emotion: Emotion = "calm"): DialogueLine => ({
  speaker, emotion, text,
});

const N = (id: string, label: string, hint: string, result: ExploreNode["result"], text: string, payload?: string): ExploreNode => ({
  id, label, hint, result, text, payload,
});

export const EPISODES_A: EpisodeDef[] = [
  {
    id: 1, title: "Ashfall Outpost", kind: "story", summary: "Arden takes a ruined relay and meets the man who will stand in front of it.",
    location: "Ashfall Outpost", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Arden", "The relay's been dead six days. Whatever walked through here didn't loot. It catalogued."),
        L("Rook", "That's worse.", "worried"),
        L("Arden", "You don't have to come inside."),
        L("Rook", "I didn't come to wait in the weather.", "determined"),
        L("Arden", "Then you take front. I read. If it moves, you don't chase it."),
        L("Rook", "You always say that."),
        L("Arden", "I always mean it."),
      ]},
      { type: "battle", battle: {
        title: "First Patrol",
        enemies: [{ base: "ruin-stalker", variant: "standard" }, { base: "ruin-stalker", variant: "standard" }],
        deploy: ["rook"],
        anomalyStart: 8,
        objects: [{ id: "door", name: "Sealed Relay Door", desc: "It still thinks it's on duty.", effect: "cover" }],
      }},
      { type: "discovery", discoveryId: "ashline", text: "Arden writes a word on the inside of a ruined map case: ASHLINE. It is not official. It is a line." },
      { type: "reward", reward: { xp: 40, currency: 20, managerXp: 8, items: [{ id: "ruin-core", name: "Ruin Core", qty: 1 }] } },
    ],
  },
  {
    id: 2, title: "The Mentor", kind: "character", summary: "Seraphine arrives like a verdict and stays like a teacher.",
    location: "Ashfall Hall", bg: "hall",
    stages: [
      { type: "dialogue", lines: [
        L("Seraphine", "You're late.", "angry"),
        L("Arden", "The road was catalogued."),
        L("Seraphine", "Don't be clever. I asked for a commander, not a poet."),
        L("Rook", "He's both. It's annoying.", "happy"),
        L("Seraphine", "You. Shield. Show me if you remember how to stand.", "determined"),
        L("Rook", "I remember."),
        L("Seraphine", "We'll see. Arden — you do not fight this. You watch. If you cannot watch, you cannot command."),
      ]},
      { type: "battle", battle: {
        title: "Measure",
        enemies: [{ base: "ruin-stalker", variant: "standard" }],
        deploy: ["rook", "seraphine"],
      }},
      { type: "choice", prompt: "Seraphine waits. She wants a reason, not a speech.", options: [
        { id: "honest", label: "Tell her about the cataloguing", text: "Arden describes the unlooted rooms. Seraphine's mouth thins. She believes him.", flag: "seraphine_listens", trust: { id: "seraphine", delta: 1 } },
        { id: "short", label: "Keep it short", text: "Arden says: we hold here. She accepts the shape of it, not the warmth." },
      ]},
      { type: "discovery", discoveryId: "crimson-greatsword", text: "The Crimson Greatsword rests like a closed argument. Seraphine does not offer it a name beyond the one it already has." },
      { type: "reward", reward: { xp: 35, currency: 15, managerXp: 10 } },
    ],
  },
  {
    id: 3, title: "First Measure", kind: "battle", summary: "A rifle on the ridge. Mira does not ask to join. She starts shooting.",
    location: "West Ridge", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Mira", "If you're going to stand in a doorway like a painting, at least pick a better wall.", "happy"),
        L("Rook", "Friendly?", "confused"),
        L("Arden", "If she wanted us dead, we'd be counting differently."),
        L("Mira", "Cute. Stalkers on your left. I can keep two of them honest if you stop blocking my lane."),
        L("Seraphine", "Name.", "calm"),
        L("Mira", "Mira. Don't make it a ceremony."),
      ]},
      { type: "battle", battle: {
        title: "Ridge Fire",
        enemies: [{ base: "ruin-stalker", variant: "standard" }, { base: "ruin-stalker", variant: "hunter" }, { base: "ruin-stalker", variant: "standard" }],
        deploy: ["rook", "mira"],
      }},
      { type: "recruit", characterId: "mira", text: "Mira sits on a crate and reloads like the conversation is already over. She is on the list anyway." },
      { type: "reward", reward: { xp: 50, currency: 25, managerXp: 12, ally: "mira", items: [{ id: "relay-lens", name: "Relay Lens", qty: 1 }] } },
    ],
  },
  {
    id: 4, title: "Broken Relay", kind: "exploration", summary: "The outpost still has rooms that think they are secret.",
    location: "Relay Interior", bg: "hall",
    stages: [
      { type: "dialogue", lines: [
        L("Arden", "We go room by room. Nobody touches a device that hums."),
        L("Mira", "Define hums.", "confused"),
        L("Seraphine", "If it makes you curious, you do not touch it.", "angry"),
        L("Rook", "I'll take the door. You take the curiosity."),
      ]},
      { type: "explore", location: "Relay Interior", intro: "Dust, iron, a map that was updated by someone who is not here.", nodes: [
        N("writing", "Wall script", "Old marks under soot.", "discovery", "The script is Mayonin. It is a duty roster, not a prayer.", "mayonin-ruins"),
        N("crate", "Sealed crate", "Still locked from the inside.", "item", "Ash Plate. Scorched, serviceable.", "ash-plate"),
        N("print", "Prints in ash", "Two sets. One heavier.", "lore", "Rook: That's a shield drag. Mine, or someone who stood like me."),
        N("hum", "Humming panel", "Seraphine's rule.", "nothing", "Arden does not touch it. The hum continues, insulted."),
      ]},
      { type: "discovery", discoveryId: "mayonin-ruins", text: "NEW DISCOVERY — Mayonin Ruins. The empire left a roster. Names are missing. The jobs are not." },
      { type: "reward", reward: { xp: 40, currency: 30, managerXp: 10, items: [{ id: "ash-plate", name: "Ash Plate", qty: 1 }], discovery: "mayonin-ruins" } },
    ],
  },
  {
    id: 5, title: "The Hammer", kind: "recruitment", summary: "A man holding a funeral for a door.",
    location: "South Works", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Vale", "This door is late for dying.", "sad"),
        L("Mira", "Is he talking to the architecture?", "confused"),
        L("Rook", "Let him finish. People like that hit hard."),
        L("Vale", "You may pass if you intend to keep something standing. If you intend to watch it fall, I will arrive first."),
        L("Arden", "We're building a line."),
        L("Vale", "Then I will be the part that does not discuss it.", "determined"),
      ]},
      { type: "battle", battle: {
        title: "Works Ambush",
        enemies: [{ base: "ruin-stalker", variant: "armored" }, { base: "ruin-stalker", variant: "standard" }],
        deploy: ["rook", "mira", "vale"],
        objects: [{ id: "gen", name: "Dead Generator", desc: "Cover if you stay low.", effect: "cover" }],
      }},
      { type: "recruit", characterId: "vale", text: "Vale writes nothing. He stands where a door used to be and that is the paperwork." },
      { type: "reward", reward: { xp: 55, currency: 28, managerXp: 12, ally: "vale" } },
    ],
  },
  {
    id: 6, title: "Quiet Hour", kind: "character", summary: "A camp that almost forgets the weather.",
    location: "Ashfall Camp", bg: "hall",
    stages: [
      { type: "dialogue", lines: [
        L("Mira", "If anyone snores, I'm shooting the ceiling.", "happy"),
        L("Rook", "The ceiling is already losing."),
        L("Vale", "I do not sleep. I wait. It is similar, and worse."),
        L("Seraphine", "Eat. Then you may be tragic."),
        L("Arden", "We hold this outpost three more days. After that, the ridge road."),
        L("Rook", "You going to tell us why it feels like someone is walking ahead of us?", "worried"),
        L("Arden", "Because someone is.", "sad"),
      ]},
      { type: "choice", prompt: "Rook asks if Arden wants the watch.", options: [
        { id: "share", label: "Share the watch", text: "They stand the dark together. Rook talks about a wall that fell. Arden does not fill the silence with orders.", trust: { id: "rook", delta: 1 } },
        { id: "alone", label: "Take it alone", text: "Arden takes the hours. The squad sleeps better. He does not." },
      ]},
      { type: "reward", reward: { xp: 25, currency: 10, managerXp: 14 } },
    ],
  },
  {
    id: 7, title: "Hunter in the Fog", kind: "battle", summary: "Something in light armor that did not come for the wall.",
    location: "Ridge Fog", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Mira", "That's not a patrol. That's a person-shaped errand.", "worried"),
        L("Seraphine", "Hunter variant. It will not test Rook. It will try me, or you."),
        L("Rook", "Let it try. I'll be insulted in the useful way.", "determined"),
        L("Arden", "Mira, rear. Vale, if it gets past Rook, you do not chase. You close the door it wanted."),
      ]},
      { type: "battle", battle: {
        title: "Fog Lane",
        enemies: [{ base: "ruin-stalker", variant: "hunter" }, { base: "ash-wraith", variant: "standard" }],
        weather: "ashfall",
        anomalyStart: 28,
        deploy: ["rook", "mira", "vale"],
      }},
      { type: "discovery", discoveryId: "supernatural-anomaly", text: "The fog is not fog. The meter on Arden's slate ticks up like a pulse." },
      { type: "reward", reward: { xp: 60, currency: 32, managerXp: 12, discovery: "supernatural-anomaly" } },
    ],
  },
  {
    id: 8, title: "Medical Wing", kind: "recruitment", summary: "A medic who packed before she was asked.",
    location: "West Clinic", bg: "hall",
    stages: [
      { type: "dialogue", lines: [
        L("Sera", "If that's arterial, sit down before you make it a story.", "angry"),
        L("Rook", "It's not arterial."),
        L("Sera", "Then stop walking like it is."),
        L("Arden", "We don't have a medic."),
        L("Sera", "You do now. I already packed. Don't look moved. It's unhygienic.", "happy"),
        L("Mira", "I like her."),
      ]},
      { type: "battle", battle: {
        title: "Clinic Door",
        enemies: [{ base: "ruin-stalker", variant: "standard" }, { base: "ruin-stalker", variant: "standard" }],
        deploy: ["rook", "sera", "mira"],
      }},
      { type: "recruit", characterId: "sera", text: "Sera writes names on tape and sticks them to kits. The Ashline becomes a list of pulses." },
      { type: "reward", reward: { xp: 45, currency: 22, managerXp: 12, ally: "sera", items: [{ id: "field-kit", name: "Field Kit", qty: 1 }] } },
    ],
  },
  {
    id: 9, title: "Red Marks", kind: "lore", summary: "Writing that was meant for someone who could still read the empire.",
    location: "Lower Crypt", bg: "vault",
    stages: [
      { type: "dialogue", lines: [
        L("Seraphine", "Don't translate out loud until you're sure."),
        L("Arden", "It's a warning about resonance. Incomplete."),
        L("Vale", "Incomplete warnings are still warnings."),
        L("Sera", "And this stain is not rust.", "worried"),
        L("Mira", "Great. History with a biohazard."),
      ]},
      { type: "explore", location: "Lower Crypt", intro: "Red marks on stone. Not blood. Instructions.", nodes: [
        N("script", "Main panel", "A duty and a prohibition.", "lore", "Do not synchronize without a second heart. The next line is gone."),
        N("weapon", "Broken short blade", "Mayonin make, snapped on purpose.", "lore", "Someone ended a weapon rather than leave it."),
        N("statue", "Kneeling figure", "No face.", "dialogue", "Arden looks too long. Seraphine says his name once, like a hand on a shoulder."),
      ]},
      { type: "reward", reward: { xp: 40, currency: 18, managerXp: 16 } },
    ],
  },
  {
    id: 10, title: "Armored Advance", kind: "battle", summary: "Plates. Slow. The mistake is swinging at the shell.",
    location: "Causeway", bg: "outpost",
    stages: [
      { type: "dialogue", lines: [
        L("Rook", "That's a walking door."),
        L("Vale", "Then I will knock.", "determined"),
        L("Seraphine", "Break first. Damage later. If you get bored and slash the paint, I will be disappointed in a loud way."),
        L("Arden", "Vale, Shieldbreaker lanes. Mira, don't waste Overcharge on the plate."),
      ]},
      { type: "battle", battle: {
        title: "Causeway",
        enemies: [{ base: "ruin-stalker", variant: "armored" }, { base: "ruin-stalker", variant: "support" }],
        deploy: ["rook", "vale", "mira", "sera"],
      }},
      { type: "reward", reward: { xp: 70, currency: 36, managerXp: 14, items: [{ id: "ruin-core", name: "Ruin Core", qty: 2 }] } },
    ],
  },
  {
    id: 11, title: "The Chemist", kind: "recruitment", summary: "Nyx treats the fog like a garden.",
    location: "Filter Shed", bg: "hall",
    stages: [
      { type: "dialogue", lines: [
        L("Nyx", "You're stepping in my work.", "calm"),
        L("Mira", "Your work is a cloud.", "confused"),
        L("Nyx", "Yes. It is very patient."),
        L("Seraphine", "Name and allegiance."),
        L("Nyx", "Nyx. I don't like allegiance. I like containment."),
        L("Arden", "Containment is a kind of line."),
        L("Nyx", "Then I will stand on yours. Temporarily. Gardens move.", "determined"),
      ]},
      { type: "battle", battle: {
        title: "Shed Bloom",
        enemies: [{ base: "anomaly-beast", variant: "standard" }, { base: "ruin-stalker", variant: "corrupted" }],
        anomalyStart: 40,
        deploy: ["rook", "nyx", "sera"],
      }},
      { type: "recruit", characterId: "nyx", text: "Nyx labels a vial ASHLINE in a handwriting that looks like a warning." },
      { type: "reward", reward: { xp: 55, currency: 26, managerXp: 12, ally: "nyx" } },
    ],
  },
  {
    id: 12, title: "Seraphine's Lesson", kind: "character", summary: "Training that is also an argument.",
    location: "Yard", bg: "hall",
    stages: [
      { type: "dialogue", lines: [
        L("Seraphine", "Clash is not a dice game. It is two decisions arriving in the same doorway."),
        L("Rook", "And if I lose the doorway?"),
        L("Seraphine", "You do not die of it. You die of pretending you didn't."),
        L("Arden", "She's right."),
        L("Seraphine", "I know. That's why I'm tired.", "sad"),
        L("Mira", "Can we skip the poetry and shoot the dummy?", "happy"),
        L("Seraphine", "The dummy will Clash you. That's the lesson."),
      ]},
      { type: "battle", battle: {
        title: "Lesson",
        enemies: [{ base: "ruin-stalker", variant: "elite", elite: true }],
        deploy: ["rook", "mira", "vale"],
      }},
      { type: "choice", prompt: "After, Seraphine offers extra drills — time and resources.", options: [
        { id: "train", label: "Take the extra training", text: "They drill until the clash windows feel like rooms. Seraphine almost smiles.", flag: "seraphine_training_complete", trust: { id: "seraphine", delta: 1 } },
        { id: "rest", label: "Rest the squad", text: "Arden calls rest. Fatigue stays off. Seraphine nods once, which is approval in a foreign language." },
      ]},
      { type: "reward", reward: { xp: 50, currency: 16, managerXp: 20 } },
    ],
  },
];
