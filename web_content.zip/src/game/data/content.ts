export type ModeId = 'combat' | 'br' | 'tdm' | 'range';
export type MapId = 'iron' | 'dust' | 'range';
export type Difficulty = 'recruit' | 'regular' | 'veteran' | 'elite';

export interface OperatorDef { id: string; name: string; role: string; bio: string; unlock: number; uniform: number; vest: number; skin: number; helmet: number; accent: number }
export const OPERATORS: OperatorDef[] = [
  { id: 'ghost', name: 'GHOST', role: 'Recon Lead', bio: 'Former mountain-warfare instructor. Prefers silence to speeches.', unlock: 1, uniform: 0x3b4436, vest: 0x2a2f26, skin: 0xc9a07e, helmet: 0x30362c, accent: 0x9fb07a },
  { id: 'viper', name: 'VIPER', role: 'Breacher', bio: 'Urban assault specialist. First through every door.', unlock: 1, uniform: 0x2a2d33, vest: 0x1b1d21, skin: 0x8d5a3b, helmet: 0x202227, accent: 0xd04040 },
  { id: 'nomad', name: 'NOMAD', role: 'Desert Scout', bio: 'Tracks targets across a thousand kilometres of sand.', unlock: 3, uniform: 0x8a7550, vest: 0x5e4f35, skin: 0xa5764f, helmet: 0x6f5e3e, accent: 0xe0b060 },
  { id: 'frost', name: 'FROST', role: 'Long-Range Marksman', bio: 'Arctic sniper. Patience measured in days.', unlock: 6, uniform: 0xb8c0c8, vest: 0x7d8790, skin: 0xe0b896, helmet: 0x9aa3ab, accent: 0x60b0e0 },
  { id: 'reaper', name: 'REAPER', role: 'Close Protection', bio: 'Nobody has seen the face beneath the mask.', unlock: 10, uniform: 0x141518, vest: 0x0c0d0f, skin: 0x2a2a2a, helmet: 0x0f1012, accent: 0x9b59ff },
  { id: 'atlas', name: 'ATLAS', role: 'Heavy Gunner', bio: 'Carries the team — and its ammunition.', unlock: 14, uniform: 0x4a5040, vest: 0x353a2e, skin: 0x6b4630, helmet: 0x3b4033, accent: 0xf0a020 },
];
export const getOperator = (id?: string) => OPERATORS.find(o => o.id === id) ?? OPERATORS[0];

export interface MissionDef { id: string; name: string; desc: string; stat: StatKey; target: number; xp: number }
export type StatKey = 'kills' | 'headshots' | 'brWins' | 'tdmWins' | 'combatWins' | 'rangeTargets' | 'matches' | 'cratesOpened' | 'weaponsUsedCount' | 'bestAccuracy' | 'longestShot' | 'wins';
export const MISSIONS: MissionDef[] = [
  { id: 'm_first', name: 'First Blood', desc: 'Eliminate 1 enemy in any mode.', stat: 'kills', target: 1, xp: 250 },
  { id: 'm_range', name: 'Range Rat', desc: 'Down 40 targets in the Practice Range.', stat: 'rangeTargets', target: 40, xp: 600 },
  { id: 'm_head', name: 'Marksman', desc: 'Land 25 headshot eliminations.', stat: 'headshots', target: 25, xp: 1000 },
  { id: 'm_combat', name: 'Wave Breaker', desc: 'Win an Offline Combat operation.', stat: 'combatWins', target: 1, xp: 1000 },
  { id: 'm_br', name: 'Last One Standing', desc: 'Win a Battle Royale match.', stat: 'brWins', target: 1, xp: 1500 },
  { id: 'm_tdm', name: 'Team Player', desc: 'Win 3 Team Deathmatch games.', stat: 'tdmWins', target: 3, xp: 1200 },
  { id: 'm_crates', name: 'Scavenger', desc: 'Open 15 supply crates.', stat: 'cratesOpened', target: 15, xp: 600 },
  { id: 'm_arsenal', name: 'Arsenal', desc: 'Get kills with 8 different weapons.', stat: 'weaponsUsedCount', target: 8, xp: 900 },
  { id: 'm_acc', name: 'Sharpshooter', desc: 'Finish a match with 45%+ accuracy (20+ shots).', stat: 'bestAccuracy', target: 45, xp: 700 },
  { id: 'm_long', name: 'Long Distance', desc: 'Land a hit from 100m or further.', stat: 'longestShot', target: 100, xp: 800 },
  { id: 'm_cent', name: 'Centurion', desc: 'Eliminate 100 enemies.', stat: 'kills', target: 100, xp: 3000 },
  { id: 'm_vet', name: 'Veteran', desc: 'Play 10 matches.', stat: 'matches', target: 10, xp: 1000 },
];

export interface ModeDef { id: ModeId; name: string; short: string; desc: string; maps: MapId[]; status: string }
export const MODES: ModeDef[] = [
  { id: 'combat', name: 'OFFLINE COMBAT', short: 'COMBAT', desc: 'Clear 5 escalating waves of hostile AI soldiers. Health regenerates out of combat. One life.', maps: ['iron', 'dust'], status: 'OFFLINE · PLAYABLE' },
  { id: 'br', name: 'BATTLE ROYALE', short: 'BR', desc: 'Drop in with a sidearm, loot weapons, armor and medkits, survive the shrinking zone. Last operator standing wins.', maps: ['dust', 'iron'], status: 'OFFLINE VS AI · PLAYABLE' },
  { id: 'tdm', name: 'TEAM DEATHMATCH', short: 'TDM', desc: 'Two squads, respawns enabled. First team to the score limit — or ahead when time expires — wins.', maps: ['iron', 'dust'], status: 'OFFLINE VS AI · PLAYABLE' },
  { id: 'range', name: 'PRACTICE RANGE', short: 'RANGE', desc: 'Test every unlocked weapon on stationary and moving targets. Tracks accuracy, hits and time.', maps: ['range'], status: 'OFFLINE · PLAYABLE' },
];

export const MAP_NAMES: Record<MapId, string> = { iron: 'IRON DISTRICT', dust: 'DUST FRONTIER', range: 'SHADOW RANGE' };
export const MAP_DESC: Record<MapId, string> = {
  iron: 'Dense urban grid — streets, alleys, enterable buildings and rooftops.',
  dust: 'Arid frontier — rolling hills, a military base, warehouses and a radar station.',
  range: 'Dedicated training facility with lanes out to 120m.',
};

export interface DifficultyDef { id: Difficulty; name: string; reaction: number; aimError: number; vision: number; fov: number; dmg: number; health: number }
export const DIFFICULTIES: DifficultyDef[] = [
  { id: 'recruit', name: 'RECRUIT', reaction: 0.95, aimError: 5.5, vision: 45, fov: 100, dmg: 0.55, health: 90 },
  { id: 'regular', name: 'REGULAR', reaction: 0.65, aimError: 3.6, vision: 60, fov: 110, dmg: 0.75, health: 100 },
  { id: 'veteran', name: 'VETERAN', reaction: 0.42, aimError: 2.4, vision: 75, fov: 120, dmg: 0.95, health: 110 },
  { id: 'elite', name: 'ELITE', reaction: 0.26, aimError: 1.5, vision: 90, fov: 130, dmg: 1.1, health: 120 },
];
export const getDifficulty = (id: Difficulty) => DIFFICULTIES.find(d => d.id === id) ?? DIFFICULTIES[1];

export const LEVEL_CAP = 30;
export const xpForLevel = (lvl: number) => 600 + (lvl - 1) * 300; // xp needed to go from lvl -> lvl+1
export function levelFromXp(xp: number) {
  let lvl = 1; let rem = Math.max(0, xp);
  while (lvl < LEVEL_CAP && rem >= xpForLevel(lvl)) { rem -= xpForLevel(lvl); lvl++; }
  return { level: lvl, into: rem, need: lvl >= LEVEL_CAP ? 1 : xpForLevel(lvl) };
}
