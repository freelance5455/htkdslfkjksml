// OPERATION SHADOW — weapon, attachment and skin definitions (original names & stats)

export type Category = 'AR' | 'SMG' | 'SR' | 'SG' | 'LMG' | 'MR' | 'PISTOL';
export type FireMode = 'auto' | 'semi' | 'burst' | 'bolt';
export type Slot = 'optic' | 'muzzle' | 'barrel' | 'grip' | 'mag' | 'stock';
export type Rarity = 0 | 1 | 2 | 3 | 4;

export const CATEGORY_NAMES: Record<Category, string> = {
  AR: 'Assault Rifle', SMG: 'Submachine Gun', SR: 'Sniper Rifle', SG: 'Shotgun',
  LMG: 'Light Machine Gun', MR: 'Marksman Rifle', PISTOL: 'Pistol',
};

export interface SoundProfile { pitch: number; body: number; crack: number; tail: number }
export interface ModelSpec {
  body: number; barrel: number; stock: 'full' | 'skeleton' | 'none' | 'bullpup' | 'heavy';
  mag: 'curved' | 'straight' | 'box' | 'drum' | 'tube' | 'pistol' | 'top';
  scope: 'none' | 'dot' | 'big'; thick: number; color: number; accent: number;
}

export interface WeaponDef {
  id: string; name: string; category: Category; desc: string;
  damage: number; headMult: number; rpm: number; mag: number; reserve: number;
  reload: number; recoilV: number; recoilH: number; spreadHip: number; spreadAds: number;
  range: number; minDmg: number; adsZoom: number; adsTime: number; move: number;
  pellets: number; mode: FireMode; suppressed?: boolean; unlock: number;
  sound: SoundProfile; model: ModelSpec;
}

const S = (pitch: number, body: number, crack: number, tail: number): SoundProfile => ({ pitch, body, crack, tail });

export const WEAPONS: WeaponDef[] = [
  // ---------- ASSAULT RIFLES ----------
  { id: 'ar01', name: 'AR-01 Vanguard', category: 'AR', desc: 'Reliable all-rounder with a controllable kick.',
    damage: 26, headMult: 1.5, rpm: 720, mag: 30, reserve: 150, reload: 2.1, recoilV: 0.85, recoilH: 0.35, spreadHip: 3.2, spreadAds: 0.35,
    range: 45, minDmg: 0.7, adsZoom: 1.3, adsTime: 0.24, move: 0.95, pellets: 1, mode: 'auto', unlock: 1,
    sound: S(1.0, 1.0, 0.8, 0.6), model: { body: 0.42, barrel: 0.30, stock: 'full', mag: 'curved', scope: 'none', thick: 1, color: 0x2b2f33, accent: 0x5a6b4a } },
  { id: 'ar02', name: 'AR-02 Sentinel', category: 'AR', desc: 'Heavy-hitting battle rifle, rewards precise bursts.',
    damage: 31, headMult: 1.5, rpm: 600, mag: 25, reserve: 125, reload: 2.4, recoilV: 1.1, recoilH: 0.3, spreadHip: 3.6, spreadAds: 0.3,
    range: 55, minDmg: 0.72, adsZoom: 1.35, adsTime: 0.27, move: 0.92, pellets: 1, mode: 'auto', unlock: 1,
    sound: S(0.85, 1.2, 0.9, 0.7), model: { body: 0.46, barrel: 0.34, stock: 'heavy', mag: 'straight', scope: 'none', thick: 1.1, color: 0x3a3226, accent: 0x8a6a3a } },
  { id: 'ar03', name: 'AR-03 Tempest', category: 'AR', desc: 'Three-round burst rifle. Deadly in skilled hands.',
    damage: 33, headMult: 1.6, rpm: 950, mag: 30, reserve: 150, reload: 2.2, recoilV: 0.7, recoilH: 0.25, spreadHip: 3.0, spreadAds: 0.25,
    range: 50, minDmg: 0.75, adsZoom: 1.35, adsTime: 0.25, move: 0.94, pellets: 1, mode: 'burst', unlock: 4,
    sound: S(1.15, 0.9, 1.0, 0.5), model: { body: 0.40, barrel: 0.32, stock: 'bullpup', mag: 'curved', scope: 'dot', thick: 1, color: 0x22262c, accent: 0x3a6ea5 } },
  { id: 'ar04', name: 'AR-04 Havoc', category: 'AR', desc: 'Slow cyclic rate, brutal damage, wild recoil.',
    damage: 36, headMult: 1.45, rpm: 540, mag: 25, reserve: 125, reload: 2.5, recoilV: 1.35, recoilH: 0.55, spreadHip: 3.8, spreadAds: 0.4,
    range: 48, minDmg: 0.7, adsZoom: 1.3, adsTime: 0.28, move: 0.9, pellets: 1, mode: 'auto', unlock: 7,
    sound: S(0.75, 1.35, 0.8, 0.8), model: { body: 0.44, barrel: 0.28, stock: 'full', mag: 'curved', scope: 'none', thick: 1.2, color: 0x4a3b2a, accent: 0x9a3a2a } },
  { id: 'ar05', name: 'AR-05 Phantom', category: 'AR', desc: 'Integrally suppressed. Stays off enemy radar.',
    damage: 24, headMult: 1.6, rpm: 820, mag: 32, reserve: 160, reload: 2.0, recoilV: 0.7, recoilH: 0.3, spreadHip: 3.0, spreadAds: 0.35,
    range: 38, minDmg: 0.68, adsZoom: 1.3, adsTime: 0.23, move: 0.96, pellets: 1, mode: 'auto', suppressed: true, unlock: 12,
    sound: S(1.3, 0.5, 0.3, 0.2), model: { body: 0.40, barrel: 0.38, stock: 'skeleton', mag: 'straight', scope: 'dot', thick: 1.05, color: 0x15171a, accent: 0x6a2a8a } },
  // ---------- SMGs ----------
  { id: 'smg01', name: 'SMG-01 Viper', category: 'SMG', desc: 'Snappy close-quarters bullet hose.',
    damage: 21, headMult: 1.4, rpm: 900, mag: 32, reserve: 192, reload: 1.8, recoilV: 0.55, recoilH: 0.4, spreadHip: 2.4, spreadAds: 0.6,
    range: 18, minDmg: 0.6, adsZoom: 1.2, adsTime: 0.18, move: 1.05, pellets: 1, mode: 'auto', unlock: 1,
    sound: S(1.35, 0.7, 0.7, 0.35), model: { body: 0.30, barrel: 0.14, stock: 'skeleton', mag: 'straight', scope: 'none', thick: 0.9, color: 0x26292e, accent: 0x3f8f4f } },
  { id: 'smg02', name: 'SMG-02 Specter', category: 'SMG', desc: 'Blistering fire rate with a deep magazine.',
    damage: 18, headMult: 1.4, rpm: 1080, mag: 40, reserve: 200, reload: 2.0, recoilV: 0.5, recoilH: 0.5, spreadHip: 2.6, spreadAds: 0.7,
    range: 15, minDmg: 0.55, adsZoom: 1.2, adsTime: 0.17, move: 1.07, pellets: 1, mode: 'auto', unlock: 3,
    sound: S(1.5, 0.6, 0.6, 0.3), model: { body: 0.28, barrel: 0.12, stock: 'none', mag: 'straight', scope: 'none', thick: 0.85, color: 0x1c1e22, accent: 0xb0b6be } },
  { id: 'smg03', name: 'SMG-03 Pulse', category: 'SMG', desc: 'Hard-hitting SMG that reaches mid range.',
    damage: 26, headMult: 1.4, rpm: 700, mag: 30, reserve: 180, reload: 1.9, recoilV: 0.6, recoilH: 0.3, spreadHip: 2.6, spreadAds: 0.5,
    range: 24, minDmg: 0.62, adsZoom: 1.25, adsTime: 0.2, move: 1.03, pellets: 1, mode: 'auto', unlock: 6,
    sound: S(1.2, 0.85, 0.7, 0.4), model: { body: 0.32, barrel: 0.18, stock: 'full', mag: 'curved', scope: 'dot', thick: 0.95, color: 0x2d3540, accent: 0xd08a2a } },
  { id: 'smg04', name: 'SMG-04 Raptor', category: 'SMG', desc: 'Top-loaded 50 round drum, laser-like spray.',
    damage: 20, headMult: 1.35, rpm: 860, mag: 50, reserve: 200, reload: 2.6, recoilV: 0.42, recoilH: 0.25, spreadHip: 2.4, spreadAds: 0.55,
    range: 17, minDmg: 0.6, adsZoom: 1.2, adsTime: 0.21, move: 1.02, pellets: 1, mode: 'auto', unlock: 10,
    sound: S(1.4, 0.65, 0.65, 0.3), model: { body: 0.36, barrel: 0.1, stock: 'bullpup', mag: 'top', scope: 'dot', thick: 1.1, color: 0x3a3f36, accent: 0xa0c040 } },
  // ---------- SNIPERS ----------
  { id: 'sr01', name: 'SR-01 Longshot', category: 'SR', desc: 'Bolt-action. One-shot headshots at any range.',
    damage: 110, headMult: 2.2, rpm: 48, mag: 5, reserve: 30, reload: 3.0, recoilV: 4.5, recoilH: 0.6, spreadHip: 7, spreadAds: 0.02,
    range: 200, minDmg: 0.85, adsZoom: 4.0, adsTime: 0.42, move: 0.85, pellets: 1, mode: 'bolt', unlock: 2,
    sound: S(0.6, 1.6, 1.4, 1.2), model: { body: 0.5, barrel: 0.5, stock: 'heavy', mag: 'box', scope: 'big', thick: 1.0, color: 0x2e3a2a, accent: 0x6a7a4a } },
  { id: 'sr02', name: 'SR-02 Frost', category: 'SR', desc: 'Lightweight bolt rifle with quick scope-in.',
    damage: 95, headMult: 2.2, rpm: 60, mag: 6, reserve: 36, reload: 2.6, recoilV: 3.8, recoilH: 0.5, spreadHip: 6, spreadAds: 0.03,
    range: 160, minDmg: 0.85, adsZoom: 3.5, adsTime: 0.33, move: 0.9, pellets: 1, mode: 'bolt', unlock: 8,
    sound: S(0.7, 1.4, 1.3, 1.0), model: { body: 0.46, barrel: 0.46, stock: 'skeleton', mag: 'box', scope: 'big', thick: 0.9, color: 0xc8d2da, accent: 0x5aa0d0 } },
  { id: 'sr03', name: 'SR-03 Eclipse', category: 'SR', desc: 'Anti-materiel monster. Body shots are lethal.',
    damage: 150, headMult: 2.0, rpm: 38, mag: 4, reserve: 20, reload: 3.6, recoilV: 6, recoilH: 0.9, spreadHip: 8, spreadAds: 0.02,
    range: 240, minDmg: 0.9, adsZoom: 4.5, adsTime: 0.5, move: 0.8, pellets: 1, mode: 'bolt', unlock: 15,
    sound: S(0.45, 2.0, 1.6, 1.5), model: { body: 0.56, barrel: 0.6, stock: 'heavy', mag: 'box', scope: 'big', thick: 1.25, color: 0x17181b, accent: 0xd0a030 } },
  // ---------- SHOTGUNS ----------
  { id: 'sg01', name: 'SG-01 Breacher', category: 'SG', desc: 'Pump-action door kicker. Devastating up close.',
    damage: 16, headMult: 1.25, rpm: 70, mag: 6, reserve: 36, reload: 3.2, recoilV: 3.5, recoilH: 0.8, spreadHip: 6.5, spreadAds: 4.8,
    range: 9, minDmg: 0.25, adsZoom: 1.15, adsTime: 0.22, move: 1.0, pellets: 9, mode: 'bolt', unlock: 1,
    sound: S(0.55, 1.8, 1.0, 1.0), model: { body: 0.38, barrel: 0.4, stock: 'full', mag: 'tube', scope: 'none', thick: 1.1, color: 0x3a2a1e, accent: 0x7a5530 } },
  { id: 'sg02', name: 'SG-02 Thunder', category: 'SG', desc: 'Semi-auto combat shotgun. Rapid follow-ups.',
    damage: 12, headMult: 1.25, rpm: 220, mag: 8, reserve: 40, reload: 3.4, recoilV: 2.6, recoilH: 0.9, spreadHip: 7, spreadAds: 5.2,
    range: 8, minDmg: 0.25, adsZoom: 1.15, adsTime: 0.24, move: 0.98, pellets: 8, mode: 'semi', unlock: 9,
    sound: S(0.65, 1.6, 0.9, 0.8), model: { body: 0.4, barrel: 0.34, stock: 'heavy', mag: 'box', scope: 'dot', thick: 1.2, color: 0x24272b, accent: 0xb03030 } },
  // ---------- LMGs ----------
  { id: 'lmg01', name: 'LMG-01 Titan', category: 'LMG', desc: '100-round belt. Suppress entire sectors.',
    damage: 30, headMult: 1.4, rpm: 650, mag: 100, reserve: 200, reload: 5.2, recoilV: 0.8, recoilH: 0.5, spreadHip: 4.5, spreadAds: 0.45,
    range: 55, minDmg: 0.72, adsZoom: 1.3, adsTime: 0.4, move: 0.82, pellets: 1, mode: 'auto', unlock: 5,
    sound: S(0.8, 1.3, 0.8, 0.8), model: { body: 0.52, barrel: 0.38, stock: 'heavy', mag: 'drum', scope: 'none', thick: 1.3, color: 0x2f3328, accent: 0x6a7040 } },
  { id: 'lmg02', name: 'LMG-02 Suppressor', category: 'LMG', desc: 'Suppressed support weapon, low profile.',
    damage: 27, headMult: 1.4, rpm: 760, mag: 75, reserve: 225, reload: 4.6, recoilV: 0.7, recoilH: 0.45, spreadHip: 4.2, spreadAds: 0.45,
    range: 45, minDmg: 0.7, adsZoom: 1.3, adsTime: 0.36, move: 0.85, pellets: 1, mode: 'auto', suppressed: true, unlock: 13,
    sound: S(1.1, 0.6, 0.35, 0.25), model: { body: 0.5, barrel: 0.42, stock: 'full', mag: 'box', scope: 'dot', thick: 1.25, color: 0x1f2124, accent: 0x40707a } },
  // ---------- MARKSMAN ----------
  { id: 'mr01', name: 'MR-01 Falcon', category: 'MR', desc: 'Semi-auto DMR. Fast follow-up precision.',
    damage: 52, headMult: 1.8, rpm: 300, mag: 15, reserve: 75, reload: 2.4, recoilV: 1.8, recoilH: 0.35, spreadHip: 4.5, spreadAds: 0.1,
    range: 90, minDmg: 0.8, adsZoom: 2.2, adsTime: 0.3, move: 0.92, pellets: 1, mode: 'semi', unlock: 3,
    sound: S(0.9, 1.2, 1.2, 0.8), model: { body: 0.46, barrel: 0.42, stock: 'full', mag: 'straight', scope: 'dot', thick: 1.0, color: 0x3b4030, accent: 0x9aa070 } },
  { id: 'mr02', name: 'MR-02 Ranger', category: 'MR', desc: 'Lever-fed marksman rifle with heavy rounds.',
    damage: 70, headMult: 1.9, rpm: 200, mag: 10, reserve: 50, reload: 2.8, recoilV: 2.6, recoilH: 0.4, spreadHip: 5, spreadAds: 0.08,
    range: 110, minDmg: 0.8, adsZoom: 2.5, adsTime: 0.32, move: 0.9, pellets: 1, mode: 'semi', unlock: 11,
    sound: S(0.75, 1.4, 1.3, 1.0), model: { body: 0.48, barrel: 0.46, stock: 'heavy', mag: 'box', scope: 'big', thick: 1.0, color: 0x4a3420, accent: 0x2a2a2a } },
  // ---------- PISTOLS ----------
  { id: 'p01', name: 'P-01 Sidekick', category: 'PISTOL', desc: 'Dependable sidearm with fast handling.',
    damage: 28, headMult: 1.5, rpm: 450, mag: 15, reserve: 90, reload: 1.4, recoilV: 1.0, recoilH: 0.3, spreadHip: 1.8, spreadAds: 0.4,
    range: 18, minDmg: 0.6, adsZoom: 1.15, adsTime: 0.14, move: 1.1, pellets: 1, mode: 'semi', unlock: 1,
    sound: S(1.25, 0.8, 0.9, 0.4), model: { body: 0.18, barrel: 0.04, stock: 'none', mag: 'pistol', scope: 'none', thick: 0.8, color: 0x25272a, accent: 0x777b80 } },
  { id: 'p02', name: 'P-02 Ironclad', category: 'PISTOL', desc: 'Magnum revolver-class hand cannon.',
    damage: 58, headMult: 1.6, rpm: 190, mag: 7, reserve: 42, reload: 2.0, recoilV: 2.8, recoilH: 0.5, spreadHip: 2.2, spreadAds: 0.3,
    range: 26, minDmg: 0.65, adsZoom: 1.2, adsTime: 0.17, move: 1.08, pellets: 1, mode: 'semi', unlock: 4,
    sound: S(0.8, 1.4, 1.1, 0.8), model: { body: 0.22, barrel: 0.1, stock: 'none', mag: 'pistol', scope: 'none', thick: 0.95, color: 0x8a8f96, accent: 0x3a2a1a } },
];

export const WEAPON_MAP: Record<string, WeaponDef> = Object.fromEntries(WEAPONS.map(w => [w.id, w]));
export const getWeapon = (id: string): WeaponDef => WEAPON_MAP[id] ?? WEAPONS[0];

// ---------------- ATTACHMENTS ----------------
export interface Mods {
  damage?: number; range?: number; recoil?: number; recoilH?: number; spread?: number; hipSpread?: number;
  adsTime?: number; reload?: number; mag?: number; move?: number; zoom?: number; suppressed?: boolean;
}
export interface Attachment { id: string; name: string; slot: Slot; desc: string; mods: Mods; unlock: number; cats?: Category[] }

export const SLOT_NAMES: Record<Slot, string> = { optic: 'Optic', muzzle: 'Muzzle', barrel: 'Barrel', grip: 'Underbarrel', mag: 'Magazine', stock: 'Stock' };
export const SLOTS: Slot[] = ['optic', 'muzzle', 'barrel', 'grip', 'mag', 'stock'];

const ALL_BUT_PISTOL: Category[] = ['AR', 'SMG', 'SR', 'SG', 'LMG', 'MR'];
export const ATTACHMENTS: Attachment[] = [
  { id: 'opt_dot', name: 'Pinpoint Reflex', slot: 'optic', desc: 'Clean red dot, slight zoom.', mods: { zoom: 1.35, adsTime: 1.03 }, unlock: 1 },
  { id: 'opt_holo', name: 'Halo Holographic', slot: 'optic', desc: 'Wide ring reticle.', mods: { zoom: 1.45, adsTime: 1.06, spread: 0.95 }, unlock: 3, cats: ALL_BUT_PISTOL },
  { id: 'opt_acog', name: 'Ridgeline 3x', slot: 'optic', desc: 'Mid-range magnified optic.', mods: { zoom: 2.4, adsTime: 1.15, spread: 0.9 }, unlock: 6, cats: ['AR', 'LMG', 'MR', 'SR'] },
  { id: 'opt_8x', name: 'Overwatch 6x', slot: 'optic', desc: 'High-power scope.', mods: { zoom: 5.0, adsTime: 1.2 }, unlock: 9, cats: ['SR', 'MR'] },
  { id: 'muz_supp', name: 'Whisper Suppressor', slot: 'muzzle', desc: 'Hides you from radar, less range.', mods: { suppressed: true, range: 0.9, recoil: 0.95 }, unlock: 2 },
  { id: 'muz_comp', name: 'Ironfist Compensator', slot: 'muzzle', desc: 'Kills vertical kick.', mods: { recoil: 0.8, recoilH: 1.1 }, unlock: 1 },
  { id: 'muz_flash', name: 'Starburst Flash Hider', slot: 'muzzle', desc: 'Tames horizontal bounce.', mods: { recoilH: 0.78 }, unlock: 4 },
  { id: 'bar_long', name: 'Longreach Barrel', slot: 'barrel', desc: 'More range and velocity.', mods: { range: 1.3, adsTime: 1.08, move: 0.97, damage: 1.03 }, unlock: 2, cats: ALL_BUT_PISTOL },
  { id: 'bar_short', name: 'Stub CQB Barrel', slot: 'barrel', desc: 'Faster handling, less range.', mods: { range: 0.8, adsTime: 0.9, move: 1.03, hipSpread: 0.85 }, unlock: 3 },
  { id: 'grip_vert', name: 'Anchor Vertical Grip', slot: 'grip', desc: 'Lowers vertical recoil.', mods: { recoil: 0.85, adsTime: 1.03 }, unlock: 1, cats: ALL_BUT_PISTOL },
  { id: 'grip_angle', name: 'Wedge Angled Grip', slot: 'grip', desc: 'Faster ADS, tighter spray.', mods: { adsTime: 0.9, recoilH: 0.85 }, unlock: 5, cats: ALL_BUT_PISTOL },
  { id: 'grip_laser', name: 'Beacon Laser', slot: 'grip', desc: 'Tightens hip-fire spread.', mods: { hipSpread: 0.7 }, unlock: 4 },
  { id: 'mag_ext', name: 'Extended Mag', slot: 'mag', desc: '+50% capacity, slower reload.', mods: { mag: 1.5, reload: 1.15, adsTime: 1.05 }, unlock: 2 },
  { id: 'mag_fast', name: 'Quickdraw Mag', slot: 'mag', desc: 'Much faster reloads.', mods: { reload: 0.72 }, unlock: 5 },
  { id: 'stk_light', name: 'Featherweight Stock', slot: 'stock', desc: 'Move and aim faster.', mods: { move: 1.05, adsTime: 0.88, recoil: 1.08 }, unlock: 3, cats: ALL_BUT_PISTOL },
  { id: 'stk_heavy', name: 'Bulwark Stock', slot: 'stock', desc: 'Rock-steady recoil control.', mods: { recoil: 0.85, recoilH: 0.85, move: 0.96, adsTime: 1.06 }, unlock: 7, cats: ALL_BUT_PISTOL },
];
export const ATTACH_MAP: Record<string, Attachment> = Object.fromEntries(ATTACHMENTS.map(a => [a.id, a]));

export const attachmentsFor = (def: WeaponDef, slot: Slot) =>
  ATTACHMENTS.filter(a => a.slot === slot && (!a.cats || a.cats.includes(def.category)));

export type AttachConfig = Partial<Record<Slot, string>>;

/** Remove invalid/incompatible attachments so a config can never break a weapon */
export function sanitizeAttachments(def: WeaponDef, cfg: AttachConfig | undefined): AttachConfig {
  const out: AttachConfig = {};
  if (!cfg) return out;
  for (const slot of SLOTS) {
    const id = cfg[slot];
    if (!id) continue;
    const a = ATTACH_MAP[id];
    if (a && a.slot === slot && (!a.cats || a.cats.includes(def.category))) out[slot] = id;
  }
  return out;
}

export interface FinalStats {
  damage: number; headMult: number; rpm: number; mag: number; reserve: number; reload: number;
  recoilV: number; recoilH: number; spreadHip: number; spreadAds: number; range: number; minDmg: number;
  zoom: number; adsTime: number; move: number; pellets: number; mode: FireMode; suppressed: boolean;
}

export function computeStats(def: WeaponDef, cfg?: AttachConfig, rarityBonus = 0): FinalStats {
  const s: FinalStats = {
    damage: def.damage * (1 + rarityBonus), headMult: def.headMult, rpm: def.rpm, mag: def.mag, reserve: def.reserve,
    reload: def.reload, recoilV: def.recoilV, recoilH: def.recoilH, spreadHip: def.spreadHip, spreadAds: def.spreadAds,
    range: def.range, minDmg: def.minDmg, zoom: def.adsZoom, adsTime: def.adsTime, move: def.move,
    pellets: def.pellets, mode: def.mode, suppressed: !!def.suppressed,
  };
  const clean = sanitizeAttachments(def, cfg);
  for (const id of Object.values(clean)) {
    const a = id ? ATTACH_MAP[id] : undefined;
    if (!a) continue;
    const m = a.mods;
    if (m.damage) s.damage *= m.damage;
    if (m.range) s.range *= m.range;
    if (m.recoil) s.recoilV *= m.recoil;
    if (m.recoilH) s.recoilH *= m.recoilH;
    if (m.spread) { s.spreadAds *= m.spread; }
    if (m.hipSpread) s.spreadHip *= m.hipSpread;
    if (m.adsTime) s.adsTime *= m.adsTime;
    if (m.reload) s.reload *= m.reload;
    if (m.mag) s.mag = Math.round(s.mag * m.mag);
    if (m.move) s.move *= m.move;
    if (m.zoom) s.zoom = Math.max(def.category === 'SR' ? def.adsZoom : 0, m.zoom);
    if (m.suppressed) s.suppressed = true;
  }
  s.reserve = Math.max(s.reserve, s.mag * 3);
  return s;
}

/** Normalised 0..100 bars for UI */
export function statBars(s: FinalStats) {
  const dps = s.damage * s.pellets * (s.rpm / 60);
  return {
    Damage: Math.min(100, (s.damage * s.pellets) / 1.5),
    'Fire Rate': Math.min(100, s.rpm / 11),
    Range: Math.min(100, s.range / 1.6),
    Accuracy: Math.max(5, Math.min(100, 100 - s.spreadHip * 9)),
    Control: Math.max(5, Math.min(100, 100 - (s.recoilV * 12 + s.recoilH * 25))),
    Mobility: Math.max(5, Math.min(100, (s.move - 0.75) * 260 + (0.5 - s.adsTime) * 60)),
    DPS: Math.min(100, dps / 6),
  };
}

// ---------------- SKINS ----------------
export interface Skin { id: string; name: string; color: number | null; unlock: number; metal?: number }
export const SKINS: Skin[] = [
  { id: 'default', name: 'Factory', color: null, unlock: 1 },
  { id: 'desert', name: 'Dune Camo', color: 0xb59b6a, unlock: 2 },
  { id: 'urban', name: 'Urban Slate', color: 0x6c7480, unlock: 3 },
  { id: 'arctic', name: 'Arctic White', color: 0xe4e9ee, unlock: 5 },
  { id: 'forest', name: 'Woodland', color: 0x4b5e3a, unlock: 6 },
  { id: 'crimson', name: 'Crimson Ops', color: 0x8a1c1c, unlock: 8 },
  { id: 'cobalt', name: 'Cobalt', color: 0x2453a8, unlock: 10 },
  { id: 'gold', name: 'Gilded', color: 0xd4a62a, unlock: 15, metal: 0.9 },
  { id: 'shadow', name: 'Shadow Elite', color: 0x121214, unlock: 20, metal: 0.6 },
];
export const getSkin = (id?: string) => SKINS.find(s => s.id === id) ?? SKINS[0];

export const RARITY_NAMES = ['Common', 'Uncommon', 'Rare', 'Epic', 'Legendary'];
export const RARITY_COLORS = ['#c8ccd0', '#4ade80', '#38bdf8', '#c084fc', '#fbbf24'];
export const RARITY_HEX = [0xc8ccd0, 0x4ade80, 0x38bdf8, 0xc084fc, 0xfbbf24];

/** Random attachments for loot of a given rarity */
export function randomLootAttachments(def: WeaponDef, rarity: Rarity): AttachConfig {
  const cfg: AttachConfig = {};
  const slots = [...SLOTS].sort(() => Math.random() - 0.5).slice(0, rarity + (rarity >= 3 ? 1 : 0));
  for (const slot of slots) {
    const opts = attachmentsFor(def, slot);
    if (opts.length) cfg[slot] = opts[Math.floor(Math.random() * opts.length)].id;
  }
  return sanitizeAttachments(def, cfg);
}
