import type { Mission } from "../types";
import { MISSIONS_A } from "./missionsA";
import { MISSIONS_B } from "./missionsB";
import { MISSIONS_C } from "./missionsC";

export const MISSIONS: Mission[] = [...MISSIONS_A, ...MISSIONS_B, ...MISSIONS_C].sort(
  (a, b) => a.id - b.id
);

export const missionById = (id: number): Mission | undefined => MISSIONS.find((m) => m.id === id);

export const TOTAL_MISSIONS = MISSIONS.length;
