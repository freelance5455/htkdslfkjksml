import * as THREE from "three";
import { makeGlowTexture } from "./textures";

let sharedGlow: THREE.Texture | null = null;
function getGlowTexture() {
  if (!sharedGlow) sharedGlow = makeGlowTexture("rgba(255,255,255,0.95)");
  return sharedGlow;
}

export interface CarRig {
  group: THREE.Group;
  wheels: THREE.Mesh[];
  body: THREE.Mesh;
  headGlow: THREE.Mesh;
  tailGlow: THREE.Mesh;
  setColor: (color: string) => void;
}

function profileShape(points: [number, number][]) {
  const shape = new THREE.Shape();
  shape.moveTo(points[0][0], points[0][1]);
  for (let i = 1; i < points.length; i++) shape.lineTo(points[i][0], points[i][1]);
  shape.closePath();
  return shape;
}

function extrude(points: [number, number][], width: number) {
  const geo = new THREE.ExtrudeGeometry(profileShape(points), {
    depth: width,
    bevelEnabled: true,
    bevelThickness: 0.05,
    bevelSize: 0.05,
    bevelSegments: 2,
  });
  geo.rotateY(Math.PI / 2);
  geo.translate(-width / 2, 0, 0);
  geo.computeVertexNormals();
  return geo;
}

const WHEEL_GEO = new THREE.CylinderGeometry(0.46, 0.46, 0.34, 18).rotateZ(
  Math.PI / 2,
);

export interface CarOptions {
  color?: string;
  /** add the neon under-glow + headlight beam (player car) */
  hero?: boolean;
  glowTexture?: THREE.Texture;
  shadowTexture?: THREE.Texture;
}

/**
 * Builds a low poly sports car that faces -Z (the driving direction).
 */
export function createCar(options: CarOptions = {}): CarRig {
  const {
    color = "#ff7a18",
    hero = false,
    glowTexture,
    shadowTexture,
  } = options;

  const group = new THREE.Group();

  const bodyColor = new THREE.Color(color);
  const bodyMat = new THREE.MeshStandardMaterial({
    color: bodyColor,
    roughness: 0.42,
    metalness: 0.2,
    emissive: bodyColor.clone().multiplyScalar(0.16),
    emissiveIntensity: 1,
  });
  const darkMat = new THREE.MeshStandardMaterial({
    color: "#0c0d12",
    roughness: 0.75,
    metalness: 0.2,
  });
  const glassMat = new THREE.MeshStandardMaterial({
    color: "#16324a",
    roughness: 0.15,
    metalness: 0.7,
    emissive: new THREE.Color("#1d5f8a"),
    emissiveIntensity: 0.55,
  });
  const headMat = new THREE.MeshStandardMaterial({
    color: "#ffffff",
    emissive: new THREE.Color("#fff3d0"),
    emissiveIntensity: 2.6,
  });
  const tailMat = new THREE.MeshStandardMaterial({
    color: "#ff2040",
    emissive: new THREE.Color("#ff1030"),
    emissiveIntensity: 2.2,
  });

  // lower body
  const bodyGeo = extrude(
    [
      [-2.15, 0.3],
      [2.15, 0.3],
      [2.2, 0.62],
      [1.35, 0.82],
      [-1.55, 0.88],
      [-2.15, 0.7],
    ],
    2.0,
  );
  const body = new THREE.Mesh(bodyGeo, bodyMat);
  body.position.y = 0;
  group.add(body);

  // greenhouse / windows
  const cabinGeo = extrude(
    [
      [-1.4, 0.84],
      [0.85, 0.78],
      [0.15, 1.42],
      [-0.95, 1.44],
    ],
    1.72,
  );
  const cabin = new THREE.Mesh(cabinGeo, glassMat);
  group.add(cabin);

  // roof panel
  const roof = new THREE.Mesh(new THREE.BoxGeometry(1.66, 0.1, 1.2), bodyMat);
  roof.position.set(0, 1.46, 0.38);
  group.add(roof);

  // side skirts
  const skirt = new THREE.Mesh(new THREE.BoxGeometry(2.12, 0.22, 3.1), darkMat);
  skirt.position.set(0, 0.26, 0.1);
  group.add(skirt);

  // front splitter + rear diffuser
  const splitter = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.12, 0.5), darkMat);
  splitter.position.set(0, 0.24, -2.15);
  group.add(splitter);

  const diffuser = new THREE.Mesh(new THREE.BoxGeometry(2.05, 0.24, 0.4), darkMat);
  diffuser.position.set(0, 0.32, 2.12);
  group.add(diffuser);

  // spoiler
  const spoiler = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.1, 0.45), darkMat);
  spoiler.position.set(0, 1.3, 2.05);
  group.add(spoiler);
  for (const sx of [-0.7, 0.7]) {
    const stand = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.34, 0.2), darkMat);
    stand.position.set(sx, 1.12, 2.05);
    group.add(stand);
  }

  // wheels — chunky tyre plus a bright alloy rim
  const wheels: THREE.Mesh[] = [];
  const rimMat = new THREE.MeshStandardMaterial({
    color: "#c9d4e6",
    roughness: 0.3,
    metalness: 0.8,
    emissive: new THREE.Color("#2b3a55"),
    emissiveIntensity: 0.6,
  });
  const rimGeo = new THREE.CylinderGeometry(0.26, 0.26, 0.36, 12).rotateZ(
    Math.PI / 2,
  );
  for (const [wx, wz] of [
    [-1.0, -1.35],
    [1.0, -1.35],
    [-1.0, 1.4],
    [1.0, 1.4],
  ]) {
    const wheel = new THREE.Mesh(WHEEL_GEO, darkMat);
    wheel.position.set(wx, 0.46, wz);
    group.add(wheel);
    const rim = new THREE.Mesh(rimGeo, rimMat);
    rim.position.copy(wheel.position);
    group.add(rim);
    wheels.push(wheel);
  }

  // lights
  const headGlow = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.16, 0.12), headMat);
  headGlow.position.set(0, 0.68, -2.18);
  group.add(headGlow);

  const tailGlow = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.14, 0.12), tailMat);
  tailGlow.position.set(0, 0.78, 2.2);
  group.add(tailGlow);

  // head light halo — makes oncoming traffic readable at night
  const headHalo = new THREE.Mesh(
    new THREE.PlaneGeometry(4.2, 2.6),
    new THREE.MeshBasicMaterial({
      map: getGlowTexture(),
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
      color: "#fff0c4",
    }),
  );
  headHalo.position.set(0, 0.7, -2.32);
  group.add(headHalo);

  // tail light halo
  const tailHalo = new THREE.Mesh(
    new THREE.PlaneGeometry(3.4, 1.8),
    new THREE.MeshBasicMaterial({
      map: getGlowTexture(),
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
      color: "#ff2a4d",
    }),
  );
  tailHalo.position.set(0, 0.78, 2.3);
  group.add(tailHalo);

  if (hero) {
    if (shadowTexture) {
      const blob = new THREE.Mesh(
        new THREE.PlaneGeometry(3.4, 5.2),
        new THREE.MeshBasicMaterial({
          map: shadowTexture,
          transparent: true,
          opacity: 0.65,
          depthWrite: false,
        }),
      );
      blob.rotation.x = -Math.PI / 2;
      blob.position.y = 0.02;
      group.add(blob);
    }

    if (glowTexture) {
      const under = new THREE.Mesh(
        new THREE.PlaneGeometry(3.6, 5.6),
        new THREE.MeshBasicMaterial({
          map: glowTexture,
          transparent: true,
          opacity: 0.55,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        }),
      );
      under.rotation.x = -Math.PI / 2;
      under.position.y = 0.05;
      group.add(under);

      const beam = new THREE.Mesh(
        new THREE.ConeGeometry(2.6, 16, 16, 1, true),
        new THREE.MeshBasicMaterial({
          color: "#ffe9b8",
          transparent: true,
          opacity: 0.07,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
          side: THREE.DoubleSide,
        }),
      );
      beam.rotation.x = -Math.PI / 2;
      beam.position.set(0, 0.55, -9.2);
      group.add(beam);

      const pool = new THREE.Mesh(
        new THREE.PlaneGeometry(7, 16),
        new THREE.MeshBasicMaterial({
          map: glowTexture,
          transparent: true,
          opacity: 0.3,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        }),
      );
      pool.rotation.x = -Math.PI / 2;
      pool.position.set(0, 0.04, -9);
      group.add(pool);
    }
  }

  return {
    group,
    wheels,
    body,
    headGlow,
    tailGlow,
    setColor: (next: string) => {
      bodyMat.color.set(next);
    },
  };
}
