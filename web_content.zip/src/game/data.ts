export interface Palette {
  base: string;
  blotch: string;
  speck: string;
  grass1: string;
  grass2: string;
  pond: string;
  pondDeep: string;
  ambient: string;
}

export interface StageDef {
  name: string;
  emoji: string;
  title: string;
  desc: string;
  size: number;
  speed: number;
  maxHp: number;
  kills: number;
  world: number;
  prey: { name: string; emoji: string; hp: number; pts: number; size: number; erratic?: boolean };
  predator: { name: string; emoji: string; count: number; hp: number; dmg: number; size: number; pts: number };
  palette: Palette;
}

export const STAGES: StageDef[] = [
  {
    name: "مورچه",
    emoji: "🐜",
    title: "کارگر گمنام",
    desc: "زیر خاک، لابه‌لای ریشه‌ها؛ کوچک اما بی‌رحم.",
    size: 15,
    speed: 235,
    maxHp: 100,
    kills: 6,
    world: 2000,
    prey: { name: "موریانه", emoji: "🐛", hp: 1, pts: 10, size: 12 },
    predator: { name: "عنکبوت", emoji: "🕷️", count: 2, hp: 3, dmg: 22, size: 26, pts: 60 },
    palette: {
      base: "#3d2f22", blotch: "#33271c", speck: "#4d3c2a",
      grass1: "#4c6b2f", grass2: "#618636", pond: "#3f6f7a", pondDeep: "#2c5560",
      ambient: "rgba(30,20,10,0.14)",
    },
  },
  {
    name: "ملخ",
    emoji: "🦗",
    title: "جهندهٔ علفزار",
    desc: "پاهایت فنر شدند؛ علفزار قلمرو توست.",
    size: 17,
    speed: 255,
    maxHp: 100,
    kills: 7,
    world: 2200,
    prey: { name: "شته", emoji: "🪲", hp: 1, pts: 14, size: 12 },
    predator: { name: "عنکبوت", emoji: "🕷️", count: 3, hp: 4, dmg: 24, size: 26, pts: 80 },
    palette: {
      base: "#41522a", blotch: "#384823", speck: "#516332",
      grass1: "#5b8a33", grass2: "#75a840", pond: "#3f7580", pondDeep: "#2d5a64",
      ambient: "rgba(20,35,10,0.10)",
    },
  },
  {
    name: "قورباغه",
    emoji: "🐸",
    title: "شکارچی برکه",
    desc: "کنار آب کمین کن؛ زبانت از نگاهت سریع‌تر است.",
    size: 19,
    speed: 260,
    maxHp: 110,
    kills: 8,
    world: 2400,
    prey: { name: "مگس", emoji: "🪰", hp: 1, pts: 18, size: 11, erratic: true },
    predator: { name: "مار", emoji: "🐍", count: 2, hp: 5, dmg: 26, size: 30, pts: 110 },
    palette: {
      base: "#3c5635", blotch: "#33492d", speck: "#4a6741",
      grass1: "#4f8a3d", grass2: "#69a84e", pond: "#3a7d8c", pondDeep: "#28596a",
      ambient: "rgba(10,35,25,0.12)",
    },
  },
  {
    name: "مار",
    emoji: "🐍",
    title: "خزندهٔ خاموش",
    desc: "بی‌صدا می‌خزی؛ سایه‌ات هم خبر ندارد.",
    size: 20,
    speed: 268,
    maxHp: 120,
    kills: 9,
    world: 2600,
    prey: { name: "موش", emoji: "🐁", hp: 2, pts: 24, size: 14 },
    predator: { name: "عقاب", emoji: "🦅", count: 3, hp: 5, dmg: 28, size: 32, pts: 140 },
    palette: {
      base: "#5a5836", blotch: "#4c4a2d", speck: "#6b6842",
      grass1: "#75923c", grass2: "#8fae4b", pond: "#41798a", pondDeep: "#2e5c6b",
      ambient: "rgba(40,35,5,0.10)",
    },
  },
  {
    name: "روباه",
    emoji: "🦊",
    title: "دزد بیشه",
    desc: "هوش، سلاح توست؛ خرگوش‌ها بوی ترس را می‌فهمند.",
    size: 22,
    speed: 285,
    maxHp: 130,
    kills: 10,
    world: 2900,
    prey: { name: "خرگوش", emoji: "🐇", hp: 2, pts: 30, size: 16 },
    predator: { name: "گرگ", emoji: "🐺", count: 3, hp: 7, dmg: 28, size: 32, pts: 180 },
    palette: {
      base: "#5c4a2c", blotch: "#4e3e24", speck: "#6e5a37",
      grass1: "#8a8a3a", grass2: "#a89e46", pond: "#3d7285", pondDeep: "#2b5566",
      ambient: "rgba(60,35,5,0.12)",
    },
  },
  {
    name: "گرگ",
    emoji: "🐺",
    title: "زوزهٔ شب",
    desc: "جنگل زیر پنجهٔ توست؛ اما خرس‌ها بیدارند.",
    size: 24,
    speed: 295,
    maxHp: 140,
    kills: 11,
    world: 3200,
    prey: { name: "گوزن", emoji: "🦌", hp: 3, pts: 40, size: 22 },
    predator: { name: "خرس", emoji: "🐻", count: 2, hp: 10, dmg: 34, size: 40, pts: 260 },
    palette: {
      base: "#2e4030", blotch: "#263628", speck: "#3a5039",
      grass1: "#3f6e38", grass2: "#548a46", pond: "#35657a", pondDeep: "#254b5c",
      ambient: "rgba(5,20,15,0.20)",
    },
  },
  {
    name: "پلنگ",
    emoji: "🐆",
    title: "شبح جنگل",
    desc: "خال‌هایت سایه‌اند؛ هیچ‌کس آمدنت را نمی‌بیند.",
    size: 26,
    speed: 310,
    maxHp: 150,
    kills: 12,
    world: 3500,
    prey: { name: "گراز", emoji: "🐗", hp: 3, pts: 50, size: 22 },
    predator: { name: "شیر", emoji: "🦁", count: 2, hp: 11, dmg: 36, size: 40, pts: 320 },
    palette: {
      base: "#274434", blotch: "#1f382b", speck: "#325542",
      grass1: "#3c7a44", grass2: "#529a56", pond: "#2f6b7d", pondDeep: "#204e5e",
      ambient: "rgba(0,25,15,0.22)",
    },
  },
  {
    name: "ببر",
    emoji: "🐅",
    title: "آتش راه‌راه",
    desc: "قدرت محض؛ فقط فیل‌ها جرأت ایستادن دارند.",
    size: 28,
    speed: 315,
    maxHp: 165,
    kills: 13,
    world: 3800,
    prey: { name: "گوزن", emoji: "🦌", hp: 4, pts: 60, size: 23 },
    predator: { name: "فیل", emoji: "🐘", count: 2, hp: 16, dmg: 42, size: 50, pts: 450 },
    palette: {
      base: "#3d5230", blotch: "#334628", speck: "#4c6339",
      grass1: "#5c8f36", grass2: "#78ac45", pond: "#38707f", pondDeep: "#28545f",
      ambient: "rgba(25,30,0,0.14)",
    },
  },
  {
    name: "شیر",
    emoji: "🦁",
    title: "سلطان طبیعت",
    desc: "ساوانا نفسش را حبس کرده؛ چرخه کامل شد.",
    size: 30,
    speed: 320,
    maxHp: 180,
    kills: 14,
    world: 4200,
    prey: { name: "گورخر", emoji: "🦓", hp: 4, pts: 75, size: 24 },
    predator: { name: "فیل", emoji: "🐘", count: 3, hp: 18, dmg: 45, size: 52, pts: 500 },
    palette: {
      base: "#8a6f3a", blotch: "#7a6132", speck: "#9c8047",
      grass1: "#a8964a", grass2: "#c4b05c", pond: "#4a7d8a", pondDeep: "#35606e",
      ambient: "rgba(90,60,10,0.10)",
    },
  },
];

export const faNum = (n: number | string) =>
  String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);

export interface ScoreEntry {
  name: string;
  score: number;
  stage: number;
  date: string;
}

const KEY = "wildcycle_scores_v1";

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.slice(0, 8) : [];
  } catch {
    return [];
  }
}

export function saveScore(entry: ScoreEntry): ScoreEntry[] {
  const list = [...loadScores(), entry].sort((a, b) => b.score - a.score).slice(0, 8);
  try {
    localStorage.setItem(KEY, JSON.stringify(list));
  } catch {
    /* ignore */
  }
  return list;
}