// ═══════════════════════════════════════════════════════════════
// DARK GHOUL V2 — بيانات اللعبة: الشخصيات، المهارات، المهمات، القصة
// ═══════════════════════════════════════════════════════════════
import imgKuro from "../assets/char_kuro.jpg";
import imgRin from "../assets/char_rin.jpg";
import imgDaisuke from "../assets/char_daisuke.jpg";
import imgYuki from "../assets/char_yuki.jpg";
import imgSora from "../assets/char_sora.jpg";
import imgHollow from "../assets/char_hollow.jpg";
import imgKey from "../assets/keyart.jpg";
export const KEYART = imgKey;

export type KaguneType = "wing" | "blade" | "tail" | "armor" | "hybrid" | "monster";

export interface SkillNode {
  id: string;
  name: string;
  desc: string;
  cost: number;
  req?: string;
  effect: "power" | "range" | "dodge" | "leech" | "rc" | "ult";
}

export interface CharacterDef {
  id: string;
  nameAr: string;
  nameEn: string;
  title: string;
  kaguneType: KaguneType;
  kaguneName: string;
  img: string;
  stats: { power: number; speed: number; defense: number; rc: number };
  colors: { skin: number; hair: number; jacket: number; pants: number; accent: number };
  hair: "spiky" | "long" | "short" | "wild" | "hood" | "mask";
  scale: number;
  bio: string;
  kaguneDesc: string;
  startUnlocked: boolean;
  tree: SkillNode[];
}

function tree(p: string, kagune: string): SkillNode[] {
  return [
    { id: p + "_pow", name: "قوة الغول", desc: "زيادة الضرر بنسبة 20%", cost: 1, effect: "power" },
    { id: p + "_rng", name: "مدى الكاغوني", desc: `امتداد أطراف ${kagune} أبعد بنسبة 25%`, cost: 1, effect: "range" },
    { id: p + "_dod", name: "ظل متراقص", desc: "مراوغة أطول مع مناعة كاملة للضربات", cost: 2, req: p + "_pow", effect: "dodge" },
    { id: p + "_lee", name: "امتصاص RC", desc: "استعادة 8% من الضرر كصحة", cost: 2, req: p + "_rng", effect: "leech" },
    { id: p + "_rc", name: "خلايا مضاعفة", desc: "طاقة التحول +50% وتجدّد أسرع", cost: 3, req: p + "_dod", effect: "rc" },
    { id: p + "_ult", name: "الانفجار الأحمر", desc: "فتح التقنية النهائية: موجة تدمير شاملة", cost: 4, req: p + "_rc", effect: "ult" },
  ];
}

export const CHARACTERS: CharacterDef[] = [
  {
    id: "kuro", nameAr: "كورو أماميا", nameEn: "KURO AMAMIYA", title: "الغول الهجين",
    kaguneType: "hybrid", kaguneName: "ألف ظل", img: imgKuro,
    stats: { power: 6, speed: 6, defense: 5, rc: 7 },
    colors: { skin: 0xd9b39a, hair: 0x14100f, jacket: 0x15161c, pants: 0x23242c, accent: 0xd21f3c },
    hair: "spiky", scale: 1,
    bio: "طالب جامعي عادي فقد كل شيء في ليلة واحدة. زُرعت فيه خلايا غول فأصبح كائناً بين عالمين — لا بشري بالكامل، ولا وحشاً بالكامل.",
    kaguneDesc: "كاغوني هجين: سوطان أسودان وجناحان شفرتَان يتحركان بإرادته الخاصة.",
    startUnlocked: true, tree: tree("kuro", "ألف ظل"),
  },
  {
    id: "rin", nameAr: "رين كوروغاني", nameEn: "RIN KUROGANE", title: "شظية الليل",
    kaguneType: "blade", kaguneName: "شظايا الليل", img: imgRin,
    stats: { power: 5, speed: 8, defense: 3, rc: 6 },
    colors: { skin: 0xe8c3ae, hair: 0x1b2340, jacket: 0x202a4a, pants: 0x14161f, accent: 0xff2d55 },
    hair: "long", scale: 0.96,
    bio: "فتاة هادئة في الظاهر، تحمل داخلها عاصفة بلورية. أسرع من يجرّح الليل بشظاياها.",
    kaguneDesc: "كاغوني أوكاكو: جناحان بلوريان يقذفان شظايا حمراء تخترق أي درع.",
    startUnlocked: true, tree: tree("rin", "شظايا الليل"),
  },
  {
    id: "daisuke", nameAr: "دايسوكي تيتسو", nameEn: "DAISUKE TETSUO", title: "قلعة الحديد",
    kaguneType: "armor", kaguneName: "قلعة الحديد", img: imgDaisuke,
    stats: { power: 8, speed: 3, defense: 9, rc: 5 },
    colors: { skin: 0xc99b7d, hair: 0x2a2622, jacket: 0x3a342c, pants: 0x25221d, accent: 0xff5a1f },
    hair: "short", scale: 1.12,
    bio: "عامل بناء سابق فقد ذراعه في حادث، فعادت إليه ذراعٌ ليست من هذا العالم. جبلٌ لا يتزحزح.",
    kaguneDesc: "كاغوني كوكاكو: درع عضوي يبتلع ذراعه وشفرات ثقيلة تسحق كل شيء.",
    startUnlocked: true, tree: tree("dai", "قلعة الحديد"),
  },
  {
    id: "yuki", nameAr: "يوكي شيروغاني", nameEn: "YUKI SHIROGANE", title: "أجنحة الشفق",
    kaguneType: "wing", kaguneName: "أجنحة الشفق", img: imgYuki,
    stats: { power: 6, speed: 5, defense: 6, rc: 8 },
    colors: { skin: 0xefe0d3, hair: 0xdadde4, jacket: 0x2c2f38, pants: 0x1c1e26, accent: 0xc42b4f },
    hair: "wild", scale: 1.0,
    bio: "وريثة عائلة غول عريقة اختارت العيش بين البشر. تقاتل بأناقة من يرقص على حافة الموت.",
    kaguneDesc: "كاغوني رينكاكو: أربعة أجنحة ضخمة تتجدد جراحها وسط المعركة.",
    startUnlocked: false, tree: tree("yuki", "أجنحة الشفق"),
  },
  {
    id: "sora", nameAr: "سورا أكاباني", nameEn: "SORA AKABANE", title: "سوط العقرب",
    kaguneType: "tail", kaguneName: "سوط العقرب", img: imgSora,
    stats: { power: 5, speed: 9, defense: 4, rc: 6 },
    colors: { skin: 0xd9b39a, hair: 0x33151a, jacket: 0x191319, pants: 0x101014, accent: 0xe0263f },
    hair: "hood", scale: 0.98,
    bio: "مقاتل شوارع مقنّع لا يعرف أحد وجهه. خمسة أسياط تجعله أسرع شيء في الأزقة المظلمة.",
    kaguneDesc: "كاغوني بيكاكو: خمسة ذيول سريعة كالبرق تضرب من كل الاتجاهات.",
    startUnlocked: false, tree: tree("sora", "سوط العقرب"),
  },
  {
    id: "hollow", nameAr: "الأجوف", nameEn: "THE HOLLOW", title: "الملك الأحمر",
    kaguneType: "monster", kaguneName: "التاج الأحمر", img: imgHollow,
    stats: { power: 10, speed: 5, defense: 7, rc: 9 },
    colors: { skin: 0xe6ddd6, hair: 0xd8d8de, jacket: 0xd9d4cc, pants: 0x2a2a30, accent: 0xd21f3c },
    hair: "mask", scale: 1.08,
    bio: "لا أحد يعرف اسمه الحقيقي. يقولون إنه أول غول وُلد في هذه المدينة، وإن قناعه يخفي وجهاً نسيه الزمن.",
    kaguneDesc: "كاغوني وحشي: ستة ذيول عملاقة وهيئة متوحشة تبتلع الضوء من حولها.",
    startUnlocked: false, tree: tree("hol", "التاج الأحمر"),
  },
];

export const KAGUNE_TYPE_AR: Record<KaguneType, string> = {
  wing: "نوع الأجنحة", blade: "نوع الشفرات", tail: "نوع الذيول",
  armor: "نوع الدرع", hybrid: "نوع هجين", monster: "نوع وحشي",
};

// ─────────────── القصة والحوارات ───────────────
export interface Choice { t: string; f?: string }
export interface Line { s: string; t: string; c?: Choice[] }

export const SPEAKERS: Record<string, { name: string; color: string }> = {
  nar: { name: "الراوي", color: "#8a93a6" },
  kuro: { name: "كورو", color: "#e0455e" },
  ren: { name: "رين — صاحب مقهى اللوتس الأسود", color: "#c9a86a" },
  aya: { name: "د. آيا", color: "#7fc8c0" },
  genji: { name: "القائد جينجي — قسم مكافحة الغيلان", color: "#5f8fd9" },
  mura: { name: "موراساكي — زعيم الوشاح الأحمر", color: "#c026d3" },
};

export type EnemyType = "thug" | "runner" | "armored" | "ghoul" | "hunter" | "boss_genji" | "boss_mura" | "informant";
export interface SpawnSpec { type: EnemyType; at: string; count: number }

export interface MissionDef {
  id: string;
  title: string;
  desc: string;
  kind: "story" | "side";
  before: Line[];
  objective: { kind: "reach" | "kill" | "collect" | "boss" | "catch"; at?: string; radius?: number; tag?: string; count?: number };
  spawns?: SpawnSpec[];
  after: Line[];
  xp: number;
  cells: number;
  unlock?: string;
  next?: string;
}

export const MISSIONS: MissionDef[] = [
  {
    id: "m0", title: "طريق العودة", desc: "عُد إلى شقتك عبر شوارع المدينة. تحرّك بالعصا، واسحب الجهة اليمنى لتدوير الكاميرا، واضغط قفز عند الحاجة.",
    kind: "story",
    before: [
      { s: "nar", t: "طوكيو، الحي العشرون. مدينةٌ تأكل أبناءها في الظلام… وتبتسم لهم في النهار." },
      { s: "kuro", t: "مناوبة المكتبة انتهت متأخرة مجدداً… الشوارع فارغة، وحتى أعمدة الإنارة تبدو خائفة الليلة." },
      { s: "nar", t: "تعلّم التحرك: استخدم العصا اليسرى للمشي والركض، والجهة اليمنى من الشاشة للكاميرا." },
    ],
    objective: { kind: "reach", at: "apartment", radius: 5 },
    after: [
      { s: "nar", t: "في الزقاق الأخير… شيءٌ يتحرك فوق الجدران. ظلٌّ بذيلٍ أسود." },
      { s: "mura", t: "دمٌ شاب… نادر. لا تصرخ، سأنهي الأمر بسرعة." },
      { s: "kuro", t: "ماذا— ابتعد! ما هذا الشيء الخارج من ظهرك؟!" },
      { s: "nar", t: "ظلام. ثم أضواء مستشفى بيضاء. وصوتُ امرأةٍ تهمس: «سامحني… لم يكن أمامي خيار»." },
      { s: "aya", t: "عضو الكاكوهو اندمج مع جسدك بنجاح. أنت لست بشرياً بالكامل بعد الآن… آسفة يا كورو." },
    ],
    xp: 30, cells: 1, next: "m1",
  },
  {
    id: "m1", title: "الاستيقاظ", desc: "أطلق العنان للكاغوني بزر التحوّل، ثم اقضِ على كشّافة الوشاح الأحمر (3) الذين يهاجمون المدنيين في الزقاق.",
    kind: "story",
    before: [
      { s: "nar", t: "بعد أسبوعين — مقهى «اللوتس الأسود»، الملجأ الوحيد الذي يقبل من هم بين العالمين." },
      { s: "ren", t: "اشرب قهوتك يا فتى. طعم القهوة هو آخر شيء بشري ستفقده… صدقني، جرّبتُ أن آكلها بدل أن أشربها. كارثة." },
      { s: "kuro", t: "كيف أتحكم بهذا الشيء في ظهري؟ أشعر أنه يتحرك وحده…" },
      { s: "ren", t: "الكاغوني ليس سلاحاً تحمله، بل جزءاً منك يكابر. اضغط زر التحوّل عندما يمتلئ مقياس RC الأحمر، ودَع الغريزة تفعل الباقي." },
      { s: "nar", t: "صراخ من الزقاق المجاور! كشّافة «الوشاح الأحمر» يهاجمون المارة. حان وقت التجربة." },
    ],
    objective: { kind: "kill", tag: "scout", count: 3 },
    spawns: [{ type: "thug", at: "alley", count: 3 }],
    after: [
      { s: "kuro", t: "انتهى الأمر… الذيول تحركت وحدها. كأنها كانت تنتظر هذا منذ زمن." },
      { s: "ren", t: "أحسنت. لكن الوشاح الأحمر سيرسل أقوى منهم. تدرّب على الأسطح — المدينة من فوق تعلّمك ما لا تعلّمه الأزقة." },
    ],
    xp: 60, cells: 1, next: "m2",
  },
  {
    id: "m2", title: "فوق السحاب", desc: "تعلّم الباركور: اركض نحو الجدران لتسلقها، واقفز بين الأسطح للوصول إلى ثلاث منارات ضوئية.",
    kind: "story",
    before: [
      { s: "ren", t: "قاعدة الباركور الأولى: كل جدارٍ سلمٌ لمن لا يخاف السقوط. اركض نحو أي مبنى وستتسلقه غريزتك." },
      { s: "ren", t: "أشعلتُ ثلاث منارات على الأسطح. اصل إليها جميعاً… وحاول ألا تسقط، الأرض تؤلم حتى الغيلان." },
    ],
    objective: { kind: "reach", at: "roofs", radius: 4 },
    after: [
      { s: "kuro", t: "المدينة من هنا… جميلة بشكلٍ مخيف. الأضواء تحت قدمي وكأنني أقف فوق سماءٍ مقلوبة." },
      { s: "ren", t: "هذه هي الحقيقة التي لا يراها البشر: الغيلان فوقهم دائماً… ومع ذلك يختار معظمنا ألا يسقط فوقهم." },
    ],
    xp: 80, cells: 1, next: "m3",
  },
  {
    id: "m3", title: "الوشم الأحمر", desc: "تسلل إلى مستودعات الوشاح الأحمر عند أطراف المدينة، واكشف مخططهم — ثم واجه حراسهم الغيلان (5).",
    kind: "story",
    before: [
      { s: "aya", t: "وجدتُ وشماً أحمر على ذراع الغول الذي هاجمك. إنه رمز «الوشاح الأحمر» — طائفة تريد حرباً مفتوحة مع البشر." },
      { s: "ren", t: "مستودعاتهم في الطرف الشرقي. اعرف ماذا يخططون… ولا تمت، أرجوك. الدفن مكلف هذه الأيام." },
    ],
    objective: { kind: "kill", tag: "veil", count: 5 },
    spawns: [{ type: "ghoul", at: "warehouse", count: 4 }, { type: "runner", at: "warehouse", count: 1 }],
    after: [
      { s: "kuro", t: "وجدتُ خرائط في المستودع… إنهم يخططون لمهاجمة «اللوتس الأسود»! يعتقدون أن المقهى يخون جنسهم." },
      { s: "nar", t: "وفي زاوية الخريطة الأخرى، ختمٌ أزرق: قسم مكافحة الغيلان يستعد لحملة تطهير تشمل المقهى أيضاً. عدوّان… وليلة واحدة." },
    ],
    xp: 120, cells: 2, unlock: "yuki", next: "m4",
  },
  {
    id: "m4", title: "ليلة اللوتس", desc: "دافع عن مقهى اللوتس الأسود ضد موجات الوشاح الأحمر. رين سيقاتل إلى جانبك.",
    kind: "story",
    before: [
      { s: "ren", t: "يأتون الليلة إذاً؟ جيد. لم أمدد أطرافي منذ سنوات… لا تضحك، كان عمري أصغر حينها." },
      { s: "yuki", t: "اسمي يوكي. عائلتي القديمة قطعت علاقتها بي لأنني أرفض الحرب. سأقاتل الليلة عن العائلة التي اخترتها." },
      { s: "nar", t: "ست موجات… لا، موجهان كبيرتان. اصمد حتى الفجر." },
    ],
    objective: { kind: "kill", tag: "raid", count: 6 },
    spawns: [{ type: "ghoul", at: "cafe", count: 3 }, { type: "armored", at: "cafe", count: 1 }, { type: "runner", at: "cafe", count: 2 }],
    after: [
      { s: "ren", t: "انتهوا… المقهى ما زال واقفاً، وقهوتي ما زالت ساخنة. هذه ليلة ناجحة بكل المقاييس." },
      { s: "yuki", t: "القسم الأزرق قادم أيضاً. قائدهم «جينجي» لا يفرّق بين غولٍ مسالم وقاتل. أوقفه قبل أن يشعل الحرب التي يريدها موراساكي." },
    ],
    xp: 160, cells: 2, unlock: "sora", next: "m5",
  },
  {
    id: "m5", title: "عدو عدوي", desc: "اقتحم نقطة تفتيش قسم مكافحة الغيلان وواجه القائد جينجي. الزعيم يملك مراحل قتال متعددة — راقب تحولاته.",
    kind: "story",
    before: [
      { s: "genji", t: "أنت الهجين الذي يتحدثون عنه. نصفك البشري يتوسل الرحمة ونصفك الآخر يفترس. سأريحك من الاثنين." },
      { s: "kuro", t: "أنا لا أقتل البشر يا جينجي. لكنني لن أتركك تبيد عائلتي." },
      { s: "genji", t: "عائلتك؟! هذه كائنات تأكل الناس! …سأريك ما تفعله «الكوينكي» بوحشٍ مثلك." },
    ],
    objective: { kind: "boss", tag: "genji", count: 1 },
    spawns: [{ type: "boss_genji", at: "ccg", count: 1 }, { type: "hunter", at: "ccg", count: 2 }],
    after: [
      { s: "nar", t: "سقط القائد على ركبتيه، و سيفه المكسور يرتجف. القرار لك يا كورو." },
      { s: "kuro", t: "قل كلمتك الأخيرة أيها القائد.", c: [
        { t: "ارحمه — «اذهب وأخبرهم أننا لسنا وحوشاً»", f: "spared_genji" },
        { t: "أنهِ الأمر — «البشر لا يتركون لنا خياراً»", f: "killed_genji" },
      ] },
      { s: "nar", t: "مهما كان قرارك… فإن موراساكي ينتظرك فوق برج المراقبة. هو من بدأ كل شيء في تلك الليلة. هو من جعلك «أنت»." },
    ],
    xp: 250, cells: 3, unlock: "hollow", next: "m6",
  },
  {
    id: "m6", title: "الملك الأحمر", desc: "اصعد إلى قمة البرج وواجه موراساكي في معركته الأخيرة. هذه الليلة ستقرر مصير المدينة كلها.",
    kind: "story",
    before: [
      { s: "mura", t: "أخيراً التقينا مجدداً… يا تحفتي الفنية. تلك الليلة لم أقتلك، بل «صنعتك». اشكرني." },
      { s: "kuro", t: "سرقتَ حياتي مني." },
      { s: "mura", t: "أعطيتك حياةً أعظم! البشر قطعان… والغيلان ذئاب. تعال، كُل معي هذه المدينة أو مُت إنساناً خائفاً." },
    ],
    objective: { kind: "boss", tag: "mura", count: 1 },
    spawns: [{ type: "boss_mura", at: "tower", count: 1 }],
    after: [
      { s: "nar", t: "سقط الملك الأحمر أخيراً. ألسنة الضباب الأحمر تتبدد فوق المدينة… والقرار الأخير بين يديك." },
      { s: "kuro", t: "كل هذا الدم… إلى أين يقود؟", c: [
        { t: "جسر بين العالمين — احمِ البشر والغيلان معاً", f: "end_bridge" },
        { t: "الوشاح الجديد — خُذ مكان موراساكي", f: "end_veil" },
        { t: "وداعاً أيها الغول — تخلَّ عن القوة وعُد بشرياً", f: "end_human" },
      ] },
    ],
    xp: 500, cells: 5,
  },
  // ───── مهمات جانبية ─────
  {
    id: "s1", title: "بلورات الليل", desc: "اجمع 10 بلورات RC متوهجة مخبأة على أسطح المدينة (استخدم التسلق).", kind: "side",
    before: [{ s: "aya", t: "بلورات RC تتركز على الأسطح العالية حيث ينام الضباب. اجمع عشرة منها وسأطوّر خلاياك." }],
    objective: { kind: "collect", count: 10 },
    after: [{ s: "aya", t: "رائع! هذه الكمية تكفي لتقوية الكاكوهو لديك بشكل دائم." }],
    xp: 100, cells: 3,
  },
  {
    id: "s2", title: "تطهير الأزقة", desc: "اقضِ على 15 من أعداء الشوارع الذين يروعون الأحياء.", kind: "side",
    before: [{ s: "ren", t: "الأزقة مليئة بقطاع الطرق وغيلان الوشاح التائهين. نظف المدينة، وسأدفع لك قهوة… وكريستالات." }],
    objective: { kind: "kill", tag: "any", count: 15 },
    after: [{ s: "ren", t: "المدينة تتنفس بشكل أفضل الليلة. أحسنت يا فتى." }],
    xp: 120, cells: 2,
  },
  {
    id: "s3", title: "المخبر الهارب", desc: "مخبر يملك معلومات عن الوشاح الأحمر يهرب منك في الشوارع. أمسكه قبل أن يختفي!", kind: "side",
    before: [{ s: "aya", t: "مخبري يرى ظلك فيركض. امسكه بلطف… نسبياً." }],
    objective: { kind: "catch", at: "park" },
    after: [{ s: "nar", t: "المخبر يلهث: خذ هذه المعلومات واتركني! موراساكي يخزن خلايا RC في المستودعات… هذا كل ما أعرفه!" }],
    xp: 90, cells: 2,
  },
  {
    id: "s4", title: "الحديقة السرية", desc: "يقال إن حديقة مخفية تزهر فوق أحد الأسطح المهجورة. اكتشفها.", kind: "side",
    before: [{ s: "yuki", t: "ثمة مكان فوق هذه المدينة ينسى فيه الغول جوعه… حديقة على سطحٍ قديم شرق البرج. إن وجدتها، ستفهم ما أعنيه." }],
    objective: { kind: "reach", at: "garden", radius: 5 },
    after: [{ s: "nar", t: "أزهار حمراء تتوهج تحت القمر… هنا، بين العالمين، يمكن لكل شيء أن يتنفس." }],
    xp: 80, cells: 2,
  },
];

export const ENDINGS: Record<string, { title: string; text: string; color: string }> = {
  end_bridge: {
    title: "نهاية الجسر", color: "#e0455e",
    text: "اختار كورو أن يكون الجسر بين عالمين يرفضان بعضهما. أسس مع رين ويوكي «ميثاق اللوتس» — هدنة سرية تحمي البشر من الغيلان الجائعة، وتحمي الغيلان المسالمة من القسم الأزرق. في الليالي الممطرة، يُرى ظلٌ بمعطف أسود فوق الأبراج… يحرس مدينةً لا تعرف اسمه، ولا تحتاج أن تعرفه.",
  },
  end_veil: {
    title: "نهاية الوشاح الأحمر", color: "#c026d3",
    text: "ارتدى كورو وشاح موراساكي الأحمر. تحت قيادته، توقفت الطائفة عن الفوضى وبدأت حرباً باردة منظمة: ظلالٌ تتحكم بالمدينة من فوق أسطحها. البشر ينامون، والغيلان تحكم. أحياناً، يقف الملك الجديد أمام زجاج البرج… يبحث في انعكاسه عن الطالب الذي كان، فلا يجد سوى عينين حمراوين.",
  },
  end_human: {
    title: "نهاية الوداع", color: "#7fc8c0",
    text: "بمساعدة د. آيا، أزال كورو الكاكوهو من جسده في عملية كادت تقتله. استيقظ إنساناً كاملاً… ووحيداً. عاد إلى المكتبة، وإلى القهوة التي صار طعمها أخيراً يشبه شيئاً يذكره. وفي كل ليلة ممطرة، يترك نافذته مفتوحة قليلاً — لعل ذيلاً أسود يزور، ولو في الحلم.",
  },
};

export const DEFAULT_SETTINGS = {
  quality: 1 as 0 | 1 | 2,
  music: 0.65,
  sfx: 0.85,
  sens: 1,
  touchScale: 1,
  shake: true,
};

export interface SaveData {
  charId: string;
  level: number;
  xp: number;
  cells: number;
  skills: string[];
  missionIdx: number;
  done: string[];
  unlocked: string[];
  flags: string[];
  pos: [number, number, number] | null;
  settings: typeof DEFAULT_SETTINGS;
  playTime: number;
}
