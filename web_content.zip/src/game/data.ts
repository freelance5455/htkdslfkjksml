export interface Drink {
  id: string;
  name: string;
  emoji: string;
  rank: string; // classificação
  color: [string, string]; // gradiente do líquido
  accent: string; // cor de destaque da carta
  accessory: string; // nome do acessório
  value: number; // dinheiro por gole
  price: number;
  phrases: string[];
}

export const DRINKS: Drink[] = [
  {
    id: "agua",
    name: "Água",
    emoji: "💧",
    rank: "Comum",
    color: ["#bae6fd", "#0ea5e9"],
    accent: "#38bdf8",
    accessory: "Gota refrescante",
    value: 1,
    price: 0,
    phrases: ["Glub glub... é só água.", "Hidratado, mas pobre.", "Quero algo mais forte!"],
  },
  {
    id: "cafe",
    name: "Café",
    emoji: "☕",
    rank: "Incomum",
    color: ["#8b5e3c", "#2b1608"],
    accent: "#a16207",
    accessory: "Boina de barista",
    value: 4,
    price: 60,
    phrases: ["Agora sim, acordei!", "Café preto, alma forte.", "Minha boina combina, né?"],
  },
  {
    id: "leite",
    name: "Leite",
    emoji: "🥛",
    rank: "Incomum+",
    color: ["#ffffff", "#e2e8f0"],
    accent: "#e2e8f0",
    accessory: "Bigode de leite",
    value: 18,
    price: 600,
    phrases: ["Olha meu bigode!", "Cremoso e gelado.", "Leitinho da vaca feliz."],
  },
  {
    id: "cafe-leite",
    name: "Café com Leite",
    emoji: "🤎",
    rank: "Raro",
    color: ["#e7c9a5", "#a8714a"],
    accent: "#d19a66",
    accessory: "Óculos intelectual",
    value: 110,
    price: 6500,
    phrases: ["A combinação perfeita!", "Os óculos deixam eu mais inteligente.", "Meio a meio, 100% feliz."],
  },
  {
    id: "cafe-acucar",
    name: "Café com Leite e Açúcar",
    emoji: "🍬",
    rank: "Épico",
    color: ["#fde7c8", "#f472b6"],
    accent: "#f472b6",
    accessory: "Laço doce",
    value: 800,
    price: 75000,
    phrases: ["Docinho demais!", "Meu laço está tão fofo!", "Açúcar é energia!"],
  },
  {
    id: "cafe-magia",
    name: "Café com Leite e Magia",
    emoji: "🔮",
    rank: "Lendário",
    color: ["#e9d5ff", "#7c3aed"],
    accent: "#a855f7",
    accessory: "Chapéu de mago",
    value: 7500,
    price: 1_200_000,
    phrases: ["Abracadabra, dinheiro!", "Sinto o poder arcano...", "Esse café tem feitiço!"],
  },
  {
    id: "cafe-cosmico",
    name: "Café com Leite Cósmico",
    emoji: "🌌",
    rank: "Mítico",
    color: ["#22d3ee", "#1e1b4b"],
    accent: "#22d3ee",
    accessory: "Capacete espacial",
    value: 85000,
    price: 28_000_000,
    phrases: ["Houston, temos café!", "Vejo galáxias no copo.", "Gravidade zero, sabor máximo."],
  },
  {
    id: "cafe-god",
    name: "Café com Leite God",
    emoji: "👑",
    rank: "DIVINO",
    color: ["#fef08a", "#f59e0b"],
    accent: "#fbbf24",
    accessory: "Auréola e asas",
    value: 1_500_000,
    price: 1_000_000_000,
    phrases: ["EU SOU O CAFÉ.", "Todos se curvam ao Leite God!", "Transcendi. Cafeína infinita."],
  },
];

export interface Save {
  money: number;
  totalEarned: number;
  sips: number;
  owned: number; // quantidade de bebidas desbloqueadas (índice máx + 1)
  selected: number;
  cup: number; // nível do copo grande
  helper: number; // nível do ajudante automático
}

export const INITIAL: Save = {
  money: 0,
  totalEarned: 0,
  sips: 0,
  owned: 1,
  selected: 0,
  cup: 0,
  helper: 0,
};

export const CUP_MAX = 10;
export const cupCost = (lvl: number) => Math.round(250 * Math.pow(5, lvl));
export const helperCost = (lvl: number) => Math.round(100 * Math.pow(1.4, lvl));
export const cupMult = (lvl: number) => Math.pow(2, lvl);

export const perSip = (s: Save) => DRINKS[s.selected].value * cupMult(s.cup);
export const perSecond = (s: Save) => s.helper * 0.5 * perSip(s);

const SUFFIX = ["", "K", "M", "B", "T", "Qa", "Qi", "Sx"];
export function fmt(n: number): string {
  if (!isFinite(n)) return "∞";
  if (n < 1000) return n < 10 && n % 1 !== 0 ? n.toFixed(1) : Math.floor(n).toString();
  const tier = Math.min(SUFFIX.length - 1, Math.floor(Math.log10(n) / 3));
  const v = n / Math.pow(1000, tier);
  return (v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2)) + SUFFIX[tier];
}

const KEY = "cafe-com-leite-god-save-v1";
export function load(): Save {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...INITIAL, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return { ...INITIAL };
}
export function persist(s: Save) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}
export function wipe() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}
