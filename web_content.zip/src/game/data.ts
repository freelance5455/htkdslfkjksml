export type Era = 'anc' | 'ww2' | 'mod';
export type Cls = 'inf' | 'arm' | 'air' | 'sge' | 'wk';

export interface UD {
  id: string; n: string; ic: string; era: Era; from: 'hq' | 'rax' | 'fac' | 'air' | 'none'; cls: Cls;
  hp: number; dmg: number; rng: number; cd: number; spd: number; cost: number; bt: number;
  model: string; proj: string; spl?: number; vsB?: number; bon?: Record<string, number>; rdef?: number;
  aa?: boolean; gr?: boolean; air?: boolean; fw?: boolean; kami?: boolean; tur?: boolean; r?: number;
}

const u = (id: string, n: string, ic: string, era: Era, from: UD['from'], cls: Cls, hp: number, dmg: number, rng: number, cd: number, spd: number, cost: number, bt: number, model: string, proj: string, x: Partial<UD> = {}): UD =>
  ({ id, n, ic, era, from, cls, hp, dmg, rng, cd, spd, cost, bt, model, proj, ...x });

export const UNITS: Record<string, UD> = {};
[
  // ---- ancient ----
  u('a_wk', 'عامل', '⛏️', 'anc', 'hq', 'wk', 60, 4, 1.8, 1, 3.4, 50, 6, 'wk_a', 'none'),
  u('a_spear', 'رمّاح', '🔱', 'anc', 'rax', 'inf', 130, 11, 2.2, 1, 3.6, 80, 8, 'spear', 'none', { bon: { arm: 1.8 } }),
  u('a_arch', 'رامي سهام', '🏹', 'anc', 'rax', 'inf', 70, 9, 12, 1.1, 3.6, 90, 8, 'archer', 'arrow'),
  u('a_sword', 'مقاتل بالسيف', '🗡️', 'anc', 'rax', 'inf', 170, 17, 1.9, 0.9, 3.8, 110, 10, 'sword', 'none'),
  u('a_heavy', 'مشاة حديدية', '🛡️', 'anc', 'rax', 'inf', 270, 22, 1.9, 1, 3.0, 170, 13, 'heavy', 'none'),
  u('a_shield', 'حامل الدرع', '🔰', 'anc', 'rax', 'inf', 240, 9, 1.9, 1, 3.2, 110, 10, 'shield', 'none', { rdef: 0.5 }),
  u('a_kush', 'رامي كوش', '🎯', 'anc', 'rax', 'inf', 85, 13, 14, 1, 3.8, 130, 10, 'archer', 'arrow'),
  u('a_chariot', 'عجلة حربية', '🐎', 'anc', 'fac', 'arm', 160, 13, 9, 0.8, 7.5, 190, 14, 'chariot', 'arrow'),
  u('a_hchar', 'عجلة ثقيلة', '🛞', 'anc', 'fac', 'arm', 310, 25, 3, 1, 6, 280, 18, 'hchar', 'none'),
  u('a_cat', 'منجنيق', '☄️', 'anc', 'fac', 'sge', 110, 50, 22, 3.2, 2.4, 260, 18, 'cat', 'stone', { spl: 3, vsB: 2 }),
  u('a_ram', 'كبش حصار', '🪵', 'anc', 'fac', 'sge', 340, 70, 2.6, 1.8, 2.8, 230, 16, 'ram', 'none', { vsB: 3.5 }),
  // ---- ww2 ----
  u('w_wk', 'عامل', '👷', 'ww2', 'hq', 'wk', 70, 4, 1.8, 1, 3.6, 50, 6, 'wk_w', 'none'),
  u('w_rifle', 'جندي مشاة', '🔫', 'ww2', 'rax', 'inf', 95, 9, 11, 0.8, 4, 70, 7, 'rifle', 'bullet', { aa: true }),
  u('w_mg', 'رشّاش', '💥', 'ww2', 'rax', 'inf', 105, 5, 12, 0.16, 3.6, 120, 10, 'mg', 'bullet', { aa: true, bon: { inf: 1.4 } }),
  u('w_at', 'مضاد دروع', '🚀', 'ww2', 'rax', 'inf', 85, 48, 12, 2.1, 3.6, 140, 11, 'at', 'rocket', { bon: { arm: 2 } }),
  u('w_para', 'مظلّي', '🪂', 'ww2', 'none', 'inf', 100, 9, 11, 0.8, 4, 70, 7, 'rifle', 'bullet', { aa: true }),
  u('w_cmd', 'كوماندوز', '🥷', 'ww2', 'none', 'inf', 130, 14, 11, 0.45, 4.6, 150, 10, 'cmdo', 'bullet', { aa: true }),
  u('w_light', 'دبابة خفيفة', '🚜', 'ww2', 'fac', 'arm', 290, 22, 14, 1.1, 6.5, 230, 15, 'ltank', 'shell', { tur: true }),
  u('w_tank', 'دبابة متوسطة', '🛡️', 'ww2', 'fac', 'arm', 470, 40, 15, 1.5, 5.4, 360, 20, 'mtank', 'shell', { tur: true }),
  u('w_heavy', 'دبابة ثقيلة', '🦾', 'ww2', 'fac', 'arm', 780, 72, 16, 2.2, 3.8, 560, 28, 'htank', 'shell', { tur: true }),
  u('w_art', 'مدفعية', '💣', 'ww2', 'fac', 'sge', 130, 62, 32, 3.2, 3, 320, 20, 'art', 'arty', { spl: 3.5, vsB: 1.4, tur: true }),
  u('w_fight', 'مقاتلة', '✈️', 'ww2', 'air', 'air', 150, 11, 15, 0.16, 17, 420, 24, 'fighter', 'bullet', { air: true, fw: true, aa: true }),
  u('w_bomb', 'قاذفة قنابل', '🛩️', 'ww2', 'air', 'air', 280, 125, 5, 1.1, 11, 560, 30, 'bomber', 'bomb', { air: true, fw: true, spl: 4.5, vsB: 2 }),
  // ---- modern ----
  u('m_wk', 'عامل', '👷', 'mod', 'hq', 'wk', 75, 4, 1.8, 1, 3.8, 50, 6, 'wk_m', 'none'),
  u('m_inf', 'مشاة', '🔫', 'mod', 'rax', 'inf', 115, 5, 13, 0.3, 4, 90, 7, 'minf', 'bullet', { aa: true }),
  u('m_rpg', 'مضاد دروع', '🚀', 'mod', 'rax', 'inf', 105, 55, 13, 2.2, 3.8, 160, 11, 'mrpg', 'rocket', { bon: { arm: 2 } }),
  u('m_aa', 'مضاد طيران', '🎯', 'mod', 'rax', 'inf', 95, 45, 19, 1.6, 3.8, 170, 11, 'maa', 'missile', { aa: true, gr: false }),
  u('m_tech', 'عربة مسلحة', '🛻', 'mod', 'fac', 'arm', 220, 7, 13, 0.2, 9, 170, 12, 'tech', 'bullet', { aa: true }),
  u('m_tank', 'دبابة قتال', '🛡️', 'mod', 'fac', 'arm', 720, 60, 17, 1.6, 5.8, 520, 25, 'mbt', 'shell', { tur: true }),
  u('m_mlrs', 'راجمة صواريخ', '🚀', 'mod', 'fac', 'sge', 230, 38, 34, 3.5, 4, 460, 24, 'mlrs', 'arcrocket', { spl: 3.5, vsB: 1.3, tur: true }),
  u('m_kami', 'مسيّرة انتحارية', '🛸', 'mod', 'air', 'air', 35, 160, 1.6, 1, 15, 130, 8, 'drone', 'none', { air: true, kami: true, spl: 2.8, bon: { arm: 1.8 } }),
  u('m_heli', 'مروحية هجومية', '🚁', 'mod', 'air', 'air', 380, 7, 15, 0.18, 9, 620, 28, 'heli', 'bullet', { air: true, aa: true, bon: { arm: 1.4 } }),
  u('m_jet', 'مقاتلة قاذفة', '🛩️', 'mod', 'air', 'air', 320, 95, 9, 1.2, 20, 720, 32, 'jet', 'missile', { air: true, fw: true, spl: 3.5 }),
].forEach(x => { UNITS[x.id] = x; });

export interface BD { id: string; hp: number; cost: number; bt: number; sz: number; ic: string }
export const BLD: Record<string, BD> = {
  hq: { id: 'hq', hp: 1800, cost: 0, bt: 0, sz: 8, ic: '🏛️' },
  rax: { id: 'rax', hp: 850, cost: 200, bt: 16, sz: 6, ic: '⚔️' },
  fac: { id: 'fac', hp: 1000, cost: 300, bt: 22, sz: 7, ic: '🏭' },
  air: { id: 'air', hp: 900, cost: 350, bt: 24, sz: 8, ic: '✈️' },
  tow: { id: 'tow', hp: 520, cost: 150, bt: 14, sz: 3.4, ic: '🗼' },
};

export interface ED {
  n: string; sky: number; gr: [number, number, number]; gr2: [number, number, number];
  tw: { dmg: number; rng: number; cd: number; proj: string; aa: boolean; spl?: number };
  bn: Record<string, string | null>; wk: string; res0: number; sty: string;
}
export const ERAS: Record<Era, ED> = {
  anc: { n: 'الحروب القديمة', sky: 0xa8c8ea, gr: [0.78, 0.66, 0.42], gr2: [0.7, 0.57, 0.34], sty: 'anc',
    tw: { dmg: 11, rng: 21, cd: 0.8, proj: 'arrow', aa: false },
    bn: { hq: 'قصر الحضارة', rax: 'ثكنة المحاربين', fac: 'ورشة العجلات والحصار', air: null, tow: 'برج الحراسة' }, wk: 'a_wk', res0: 700 },
  ww2: { n: 'الحرب العالمية الثانية', sky: 0x9fb2c8, gr: [0.36, 0.5, 0.27], gr2: [0.3, 0.42, 0.22], sty: 'ww2',
    tw: { dmg: 14, rng: 23, cd: 0.33, proj: 'bullet', aa: true },
    bn: { hq: 'القيادة العامة', rax: 'ثكنات المشاة', fac: 'مصنع الدبابات', air: 'مطار عسكري', tow: 'ملجأ مدفعي' }, wk: 'w_wk', res0: 900 },
  mod: { n: 'الحروب الحديثة', sky: 0x8db8e6, gr: [0.52, 0.5, 0.42], gr2: [0.44, 0.43, 0.37], sty: 'mod',
    tw: { dmg: 42, rng: 27, cd: 1.4, proj: 'missile', aa: true, spl: 1.5 },
    bn: { hq: 'مركز القيادة', rax: 'قاعدة المشاة', fac: 'مصنع المدرعات', air: 'قاعدة جوية ومسيّرات', tow: 'برج دفاع' }, wk: 'm_wk', res0: 1000 },
};

export interface PD { n: string; ic: string; t: 'heal' | 'buff' | 'strike' | 'spawn'; cd: number; time?: number; spd?: number; dm?: number; cnt?: number; rad?: number; dmg?: number; spl?: number; kind?: string; dur?: number; u?: string; fall?: number; ds: string; fly?: string }
export const POW: Record<string, PD> = {
  heal: { n: 'بركة آمون', ic: '✨', t: 'heal', cd: 90, ds: 'تعالج 50% من صحة كل جيشك' },
  rage: { n: 'غضب الحديد', ic: '🔥', t: 'buff', cd: 90, time: 20, spd: 1.25, dm: 1.5, ds: '+50% ضرر و+25% سرعة' },
  catap: { n: 'وابل المجانيق', ic: '☄️', t: 'strike', cd: 80, cnt: 9, rad: 9, dmg: 75, spl: 4, kind: 'stone', dur: 3.5, ds: 'قصف منطقة بالصخور' },
  arrows: { n: 'مطر السهام', ic: '🏹', t: 'strike', cd: 70, cnt: 44, rad: 13, dmg: 15, spl: 2.4, kind: 'arrow', dur: 4, ds: 'مطر سهام على منطقة' },
  blitz: { n: 'هجوم خاطف', ic: '⚡', t: 'buff', cd: 85, time: 18, spd: 1.45, dm: 1.35, ds: 'سرعة وقوة نارية' },
  kat: { n: 'كاتيوشا', ic: '🚀', t: 'strike', cd: 85, cnt: 26, rad: 12, dmg: 46, spl: 4, kind: 'rocket', dur: 4.5, ds: 'وابل صواريخ' },
  air: { n: 'غارة جوية', ic: '✈️', t: 'strike', cd: 85, cnt: 10, rad: 9, dmg: 95, spl: 5, kind: 'bomb', dur: 3, fly: 'bomber', ds: 'قصف جوي' },
  para: { n: 'إنزال المظليين', ic: '🪂', t: 'spawn', cd: 80, u: 'w_para', cnt: 6, fall: 28, ds: '6 مظليين في أي مكان' },
  shell: { n: 'قصف بعيد المدى', ic: '💥', t: 'strike', cd: 80, cnt: 10, rad: 10, dmg: 80, spl: 4, kind: 'shell', dur: 4, ds: 'قصف مدفعي' },
  cmdo: { n: 'إنزال الكوماندوز', ic: '🥷', t: 'spawn', cd: 80, u: 'w_cmd', cnt: 5, fall: 28, ds: '5 كوماندوز في أي مكان' },
  mair: { n: 'ضربة جوية دقيقة', ic: '🛩️', t: 'strike', cd: 85, cnt: 14, rad: 9, dmg: 120, spl: 6, kind: 'bomb', dur: 3, fly: 'jet', ds: 'ضربة جوية مدمرة' },
  mrage: { n: 'التعبئة الشاملة', ic: '🔥', t: 'buff', cd: 90, time: 20, spd: 1.25, dm: 1.4, ds: '+40% ضرر و+25% سرعة' },
  tunnel: { n: 'هجوم الأنفاق', ic: '🕳️', t: 'spawn', cd: 80, u: 'm_inf', cnt: 8, fall: 0, ds: '8 مقاتلين من نفق مفاجئ' },
  rkt: { n: 'وابل الصواريخ', ic: '🚀', t: 'strike', cd: 80, cnt: 18, rad: 11, dmg: 52, spl: 4, kind: 'rocket', dur: 4, ds: 'قصف صاروخي' },
  raid: { n: 'غارة سريعة', ic: '🛻', t: 'spawn', cd: 75, u: 'm_tech', cnt: 4, fall: 0, ds: '4 عربات مسلحة' },
  swarm: { n: 'سرب انتحاري', ic: '🛸', t: 'spawn', cd: 85, u: 'm_kami', cnt: 6, fall: 0, ds: '6 مسيّرات انتحارية' },
};

export interface FM { hp: number; dmg: number; spd: number; cost: number; carry: number; bt: number; tow: number; rng: number; bdm: number; inc: number }
export interface FD {
  id: string; era: Era; n: string; ic: string; a: [number, number, number]; b: [number, number, number];
  ds: string; g: string; w: string; rax: string[]; fac: string[]; air: string[]; pw: string[]; m: Partial<FM>; nm?: Record<string, string>;
}
const F = (x: FD) => x;
export const FACS: Record<string, FD> = {};
[
  F({ id: 'eg', era: 'anc', n: 'مصر القديمة', ic: '🔺', a: [.92, .84, .62], b: [.85, .65, .12], ds: 'توازن وتحصينات وعجلات حربية سريعة.', g: 'عمال أقوياء وبناء أسرع • أبراج أقوى', w: 'مشاة أقل قوة من الحيثيين',
    rax: ['a_spear', 'a_arch', 'a_sword'], fac: ['a_chariot', 'a_cat'], air: [], pw: ['heal', 'arrows'], m: { carry: 1.5, bt: 0.7, tow: 1.3 } }),
  F({ id: 'hit', era: 'anc', n: 'الحيثيون', ic: '⚔️', a: [.6, .2, .16], b: [.55, .55, .6], ds: 'دروع ثقيلة وأسلحة حديدية.', g: 'مشاة وعجلات حديدية ثقيلة • ضرر مدمر', w: 'بطيئون وأغلى ثمناً',
    rax: ['a_heavy', 'a_spear', 'a_sword'], fac: ['a_hchar', 'a_ram'], air: [], pw: ['rage', 'catap'], m: { hp: 1.15, dmg: 1.15, spd: 0.95, cost: 1.1 } }),
  F({ id: 'mes', era: 'anc', n: 'بلاد الرافدين', ic: '🏛️', a: [.25, .36, .65], b: [.85, .58, .25], ds: 'حرب الحصار والأعداد الكبيرة.', g: 'مجانيق وكباش • تدمير المباني أسرع • جدار الدروع', w: 'وحدات فردية أضعف',
    rax: ['a_shield', 'a_arch', 'a_spear'], fac: ['a_cat', 'a_ram'], air: [], pw: ['catap', 'rage'], m: { bdm: 1.3, cost: 0.95, hp: 0.95 } }),
  F({ id: 'kush', era: 'anc', n: 'مملكة كوش', ic: '🏹', a: [.16, .4, .24], b: [.92, .72, .2], ds: 'رماة النوبة الأسطوريون.', g: 'رماة بعيدو المدى وسريعون', w: 'مدرعات ضعيفة',
    rax: ['a_kush', 'a_spear', 'a_sword'], fac: ['a_chariot', 'a_cat'], air: [], pw: ['arrows', 'heal'], m: { rng: 1.15, spd: 1.08, hp: 0.95 } }),
  F({ id: 'ger', era: 'ww2', n: 'ألمانيا', ic: '🦅', a: [.45, .47, .42], b: [.12, .12, .12], ds: 'دبابات متفوقة وهجوم خاطف.', g: 'ضرر وصحة أعلى', w: 'وحدات أغلى',
    rax: ['w_rifle', 'w_mg', 'w_at'], fac: ['w_light', 'w_tank', 'w_heavy', 'w_art'], air: ['w_fight', 'w_bomb'], pw: ['blitz', 'shell'], m: { hp: 1.1, dmg: 1.1, cost: 1.12 }, nm: { w_heavy: 'تايغر', w_tank: 'بانزر' } }),
  F({ id: 'ussr', era: 'ww2', n: 'الاتحاد السوفيتي', ic: '☭', a: [.62, .16, .13], b: [.9, .78, .2], ds: 'أعداد هائلة ومدفعية ثقيلة.', g: 'وحدات أرخص بكثير', w: 'صحة أقل قليلاً',
    rax: ['w_rifle', 'w_mg', 'w_at'], fac: ['w_light', 'w_tank', 'w_heavy', 'w_art'], air: ['w_fight', 'w_bomb'], pw: ['kat', 'para'], m: { cost: 0.82, hp: 0.95 }, nm: { w_tank: 'تي-34', w_heavy: 'ستالين', w_light: 'تي-26' } }),
  F({ id: 'usa', era: 'ww2', n: 'أمريكا', ic: '⭐', a: [.3, .45, .3], b: [.92, .92, .92], ds: 'سيطرة جوية وسرعة.', g: 'سرعة أعلى وضرر جوي أكبر', w: 'دروع أخف',
    rax: ['w_rifle', 'w_mg', 'w_at'], fac: ['w_light', 'w_tank', 'w_heavy', 'w_art'], air: ['w_fight', 'w_bomb'], pw: ['air', 'para'], m: { spd: 1.08, bt: 0.9 }, nm: { w_tank: 'شيرمان', w_heavy: 'بيرشينغ' } }),
  F({ id: 'bri', era: 'ww2', n: 'بريطانيا', ic: '👑', a: [.42, .38, .22], b: [.75, .18, .18], ds: 'دفاع قوي وكوماندوز.', g: 'مدى أبعد وأبراج أقوى', w: 'إنتاج أبطأ',
    rax: ['w_rifle', 'w_mg', 'w_at'], fac: ['w_light', 'w_tank', 'w_heavy', 'w_art'], air: ['w_fight', 'w_bomb'], pw: ['cmdo', 'shell'], m: { rng: 1.1, tow: 1.3, bt: 1.1 }, nm: { w_tank: 'كرومويل', w_heavy: 'تشرشل' } }),
  F({ id: 'sup', era: 'mod', n: 'القوى العظمى', ic: '🌐', a: [.3, .36, .46], b: [.9, .92, .96], ds: 'تكنولوجيا متقدمة وسيطرة جوية.', g: 'صحة وضرر أعلى', w: 'تكلفة عالية',
    rax: ['m_inf', 'm_rpg', 'm_aa'], fac: ['m_tank', 'm_mlrs', 'm_tech'], air: ['m_heli', 'm_jet', 'm_kami'], pw: ['mair', 'swarm'], m: { hp: 1.1, dmg: 1.1, cost: 1.15 } }),
  F({ id: 'egy', era: 'mod', n: 'الجيش المصري', ic: '🇪🇬', a: [.76, .65, .4], b: [.1, .1, .1], ds: 'جيش متوازن ودفاع جوي قوي.', g: 'أبراج أقوى وتكلفة أقل', w: 'بلا مسيّرات ثقيلة',
    rax: ['m_inf', 'm_rpg', 'm_aa'], fac: ['m_tank', 'm_mlrs', 'm_tech'], air: ['m_heli', 'm_jet'], pw: ['mrage', 'rkt'], m: { hp: 1.05, tow: 1.25, cost: 0.95 } }),
  F({ id: 'res', era: 'mod', n: 'المقاومة', ic: '🕳️', a: [.15, .4, .2], b: [.92, .92, .3], ds: 'حرب عصابات وأنفاق وصواريخ.', g: 'وحدات رخيصة وبناء سريع', w: 'بلا دبابات ثقيلة',
    rax: ['m_inf', 'm_rpg', 'm_aa'], fac: ['m_tech', 'm_mlrs'], air: ['m_kami'], pw: ['tunnel', 'rkt'], m: { cost: 0.78, hp: 0.9, carry: 1.2, bt: 0.8 } }),
  F({ id: 'fld', era: 'mod', n: 'الفصائل الميدانية', ic: '🛻', a: [.46, .32, .16], b: [.14, .14, .14], ds: 'سرعة وغارات ومسيّرات.', g: 'سرعة عالية وتكلفة منخفضة', w: 'صحة أقل',
    rax: ['m_inf', 'm_rpg', 'm_aa'], fac: ['m_tech', 'm_mlrs', 'm_tank'], air: ['m_kami', 'm_heli'], pw: ['raid', 'swarm'], m: { spd: 1.15, cost: 0.85, hp: 0.9 } }),
].forEach(f => { FACS[f.id] = f; });

export const ERA_FACS = (e: Era) => Object.values(FACS).filter(f => f.era === e);
export function fmOf(fac: string): FM {
  return { hp: 1, dmg: 1, spd: 1, cost: 1, carry: 1, bt: 1, tow: 1, rng: 1, bdm: 1, inc: 1, ...(FACS[fac]?.m || {}) };
}
export const PCOL = [0x3b82f6, 0xef4444, 0x22c55e, 0xeab308];
export const PCOL_CSS = ['#3b82f6', '#ef4444', '#22c55e', '#eab308'];
export const POP_CAP = 70;
export const TYPES: string[] = [...Object.keys(UNITS), ...Object.keys(BLD)];
export const TI: Record<string, number> = {};
TYPES.forEach((t, i) => { TI[t] = i; });

export function unitName(fac: string, t: string) { return FACS[fac]?.nm?.[t] || UNITS[t]?.n || t; }
export function bldName(era: Era, t: string) { return ERAS[era].bn[t] || t; }
export function buildOpts(era: Era): string[] { return ['rax', 'fac', 'air', 'tow'].filter(t => ERAS[era].bn[t]); }
export function trainList(fac: string, b: string): string[] {
  const f = FACS[fac]; const era = f.era;
  if (b === 'hq') return [ERAS[era].wk];
  if (b === 'rax') return f.rax; if (b === 'fac') return f.fac; if (b === 'air') return f.air; return [];
}
