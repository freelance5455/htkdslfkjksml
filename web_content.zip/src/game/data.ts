export interface Side {
  id: string;
  name: string;
  ps: string;
  color: string;
  players: string[];
}

function xi(tag: string): string[] {
  const roles = ["اوپنر", "اوپنر", "درېیم", "منځ", "منځ", "الراؤنډر", "کیپر", "توپوهونکی", "سپن", "تیز", "تیز"];
  return roles.map((role, i) => `${tag} ${role} ${i + 1}`);
}

export const TEAMS: Side[] = [
  { id: "afg", name: "Afghanistan", ps: "افغانستان", color: "#1d4ed8", players: ["انصار خان", "بلال نور", "ولي ځدراڼ", "حمزه شینوار", "طارق عمر", "فرید کاکړ", "سامي ګل", "نسیم باد", "روحان قادر", "الیاس مروت", "ظفر مهمند"] },
  { id: "ind", name: "India", ps: "هند", color: "#0ea5e9", players: xi("هند") },
  { id: "pak", name: "Pakistan", ps: "پاکستان", color: "#166534", players: xi("پاک") },
  { id: "aus", name: "Australia", ps: "آسټرالیا", color: "#ca8a04", players: xi("آس") },
  { id: "eng", name: "England", ps: "انګلینډ", color: "#1e3a8a", players: xi("انګ") },
  { id: "sa", name: "South Africa", ps: "سویلي افریقا", color: "#15803d", players: xi("افریقا") },
  { id: "nz", name: "New Zealand", ps: "نیوزیلنډ", color: "#111827", players: xi("نیوز") },
  { id: "sl", name: "Sri Lanka", ps: "سریلانکا", color: "#1d4ed8", players: xi("سری") },
  { id: "ban", name: "Bangladesh", ps: "بنګله دیش", color: "#047857", players: xi("بنګ") },
  { id: "wi", name: "West Indies", ps: "ویسټ انډیز", color: "#7f1d1d", players: xi("ویسټ") },
  { id: "zim", name: "Zimbabwe", ps: "زیمبابوې", color: "#b45309", players: xi("زیم") },
  { id: "ire", name: "Ireland", ps: "آیرلنډ", color: "#166534", players: xi("آیر") },
  { id: "ned", name: "Netherlands", ps: "هالینډ", color: "#ea580c", players: xi("هال") },
  { id: "nep", name: "Nepal", ps: "نیپال", color: "#dc2626", players: xi("نیپ") },
  { id: "usa", name: "United States", ps: "امریکا", color: "#1d4ed8", players: xi("امریکا") },
];

export interface Ground {
  id: string;
  name: string;
  ps: string;
  sky: string;
  grass: string;
  night: boolean;
}

export const GROUNDS: Ground[] = [
  { id: "kabul", name: "Kabul Night Oval", ps: "د کابل شپه", sky: "#07111c", grass: "#146b32", night: true },
  { id: "indus", name: "Indus Bowl", ps: "سند بول", sky: "#10243f", grass: "#1a7a3a", night: true },
  { id: "ghazni", name: "Ghazni Ridge", ps: "د غزني غونډۍ", sky: "#8fb7d9", grass: "#2f7d3a", night: false },
  { id: "herat", name: "Herat Fort Ground", ps: "د هرات کلا", sky: "#9ec4e0", grass: "#3c8f45", night: false },
  { id: "gulf", name: "Gulf Lights", ps: "د خلیج څراغونه", sky: "#0b1020", grass: "#0f6b38", night: true },
  { id: "harbor", name: "Harbor Ends", ps: "د بندر سرې", sky: "#b7d4ea", grass: "#1e8a44", night: false },
  { id: "highveld", name: "Highveld Park", ps: "هایویلډ", sky: "#c5d7e6", grass: "#4a9340", night: false },
  { id: "island", name: "Island Green", ps: "د ټاپو شنه", sky: "#071422", grass: "#1f9a48", night: true },
];

export function teamById(id: string): Side {
  return TEAMS.find((t) => t.id === id) ?? TEAMS[0];
}

export const FORMATS = [
  { id: 5, label: "T10", ps: "۵ اوورونه" },
  { id: 10, label: "لنډ T20", ps: "۱۰ اوورونه" },
  { id: 20, label: "T20", ps: "۲۰ اوورونه" },
];
