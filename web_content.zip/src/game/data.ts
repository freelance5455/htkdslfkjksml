export type World = {
  id: number;
  name: string;
  tagline: string;
  bg: [string, string, string];
  accent: string;
  accent2: string;
  solid: string;
  glow: string;
};

export const LEVELS_PER_WORLD = 100;
export const TOTAL_LEVELS = 2000;
export const TOTAL_WORLDS = 20;

export const WORLDS: World[] = [
  {
    id: 1,
    name: "Neon Heights",
    tagline: "Where every drop begins.",
    bg: ["#0a091c", "#10112f", "#180d30"],
    accent: "#8b6bff",
    accent2: "#38e8ff",
    solid: "#20243a",
    glow: "#6c4bff",
  },
  {
    id: 2,
    name: "Magma Core",
    tagline: "The floor is definitely lava.",
    bg: ["#150707", "#250909", "#340f05"],
    accent: "#ff7a3c",
    accent2: "#ffd166",
    solid: "#2b1713",
    glow: "#ff5c28",
  },
  {
    id: 3,
    name: "Glacier Rush",
    tagline: "Slippery when shattered.",
    bg: ["#041422", "#062035", "#0a2b42"],
    accent: "#4fd8ff",
    accent2: "#a6f6ff",
    solid: "#152a3d",
    glow: "#38cfff",
  },
  {
    id: 4,
    name: "Cyber Grid",
    tagline: "Firewall? Break it.",
    bg: ["#03130f", "#041d16", "#06231c"],
    accent: "#42f5a7",
    accent2: "#b8ff4d",
    solid: "#132a24",
    glow: "#22e58a",
  },
  {
    id: 5,
    name: "Toxic Vault",
    tagline: "Handle with extreme speed.",
    bg: ["#101605", "#1a2207", "#212c0a"],
    accent: "#b8ff4d",
    accent2: "#f4ff8a",
    solid: "#26301a",
    glow: "#a6f02e",
  },
  {
    id: 6,
    name: "Sunset Strip",
    tagline: "Chase the last light down.",
    bg: ["#1a0812", "#2a0c1d", "#351126"],
    accent: "#ff6b9d",
    accent2: "#ffc46b",
    solid: "#301b2b",
    glow: "#ff5c92",
  },
  {
    id: 7,
    name: "Deep Space",
    tagline: "No brakes. No gravity.",
    bg: ["#050a20", "#091436", "#0a1a44"],
    accent: "#6d8bff",
    accent2: "#7cf2ff",
    solid: "#182240",
    glow: "#5b7cff",
  },
  {
    id: 8,
    name: "Candy Cloud",
    tagline: "Sweet, soft, absolutely brutal.",
    bg: ["#1a0b1d", "#260f2b", "#2e1335"],
    accent: "#ff9bdc",
    accent2: "#b5a6ff",
    solid: "#332138",
    glow: "#ff85d1",
  },
  {
    id: 9,
    name: "Crimson Forge",
    tagline: "Forged for bounce-backs.",
    bg: ["#160608", "#23080c", "#2e0b10"],
    accent: "#ff5d7a",
    accent2: "#ffb26b",
    solid: "#2e161b",
    glow: "#ff4566",
  },
  {
    id: 10,
    name: "Aqua Abyss",
    tagline: "Sink fast. Think faster.",
    bg: ["#031018", "#041a26", "#06202f"],
    accent: "#3ae0d0",
    accent2: "#4fa8ff",
    solid: "#112833",
    glow: "#20d6c4",
  },
  {
    id: 11,
    name: "Solar Flare",
    tagline: "A race against the sun.",
    bg: ["#1a1103", "#241804", "#2f1f05"],
    accent: "#ffc94d",
    accent2: "#ff8a3d",
    solid: "#302716",
    glow: "#ffbe35",
  },
  {
    id: 12,
    name: "Violet Void",
    tagline: "Purple is the new bottom.",
    bg: ["#0d061c", "#160a2a", "#1d0d36"],
    accent: "#c46bff",
    accent2: "#ff7ce0",
    solid: "#291a3c",
    glow: "#b14dff",
  },
  {
    id: 13,
    name: "Emerald Spire",
    tagline: "Green light. Full send.",
    bg: ["#04140d", "#061e14", "#08271a"],
    accent: "#3ff0a0",
    accent2: "#7cffd0",
    solid: "#132a20",
    glow: "#2ae090",
  },
  {
    id: 14,
    name: "Amethyst Cave",
    tagline: "Crystals remember every fall.",
    bg: ["#120919", "#1b0d25", "#22102e"],
    accent: "#b58cff",
    accent2: "#ff9ccf",
    solid: "#291b35",
    glow: "#a06dff",
  },
  {
    id: 15,
    name: "Golden Gauntlet",
    tagline: "Only the precise see gold.",
    bg: ["#191206", "#241a08", "#2e210b"],
    accent: "#ffd76b",
    accent2: "#ffe9b0",
    solid: "#302818",
    glow: "#ffcf57",
  },
  {
    id: 16,
    name: "Steel Sky",
    tagline: "Cold metal. Hot streaks.",
    bg: ["#0a1018", "#0f1823", "#131f2d"],
    accent: "#9fb6d1",
    accent2: "#6ee7ff",
    solid: "#25313f",
    glow: "#7f9dbd",
  },
  {
    id: 17,
    name: "Nova Prism",
    tagline: "Break the light itself.",
    bg: ["#080a16", "#0d1126", "#121a33"],
    accent: "#ff6be0",
    accent2: "#5cf2ff",
    solid: "#1d2540",
    glow: "#b46bff",
  },
  {
    id: 18,
    name: "Blood Moon",
    tagline: "It only gets darker from here.",
    bg: ["#140509", "#1f070d", "#2a0a11"],
    accent: "#ff4d5e",
    accent2: "#ff9a6b",
    solid: "#2c141a",
    glow: "#ff3a4d",
  },
  {
    id: 19,
    name: "Ion Storm",
    tagline: "Ten thousand volts of timing.",
    bg: ["#040e1a", "#061628", "#081d33"],
    accent: "#4fb2ff",
    accent2: "#ffe55c",
    solid: "#152338",
    glow: "#37a2ff",
  },
  {
    id: 20,
    name: "Infinity Core",
    tagline: "The final 100. The deepest fall.",
    bg: ["#0a0812", "#120d22", "#1a1330"],
    accent: "#e8e2ff",
    accent2: "#9d7bff",
    solid: "#262040",
    glow: "#a78bfa",
  },
];

export type Skin = {
  id: string;
  name: string;
  tagline: string;
  inner: string;
  core: string;
  outer: string;
  glow: string;
  trail: string;
  price: number;
  rarity: "Starter" | "Rare" | "Epic" | "Legendary";
};

export const SKINS: Skin[] = [
  {
    id: "nova",
    name: "Nova",
    tagline: "The original drop.",
    inner: "#f3edff",
    core: "#a78bfa",
    outer: "#5b30d6",
    glow: "#8b6bff",
    trail: "#a78bfa",
    price: 0,
    rarity: "Starter",
  },
  {
    id: "glacier",
    name: "Glacier",
    tagline: "Cold-blooded clear.",
    inner: "#f2ffff",
    core: "#6fe7ff",
    outer: "#136f9e",
    glow: "#4fd8ff",
    trail: "#a6f6ff",
    price: 450,
    rarity: "Rare",
  },
  {
    id: "magma",
    name: "Magma",
    tagline: "Molten momentum.",
    inner: "#fff2d0",
    core: "#ff9445",
    outer: "#a32a0c",
    glow: "#ff7a3c",
    trail: "#ffb26b",
    price: 700,
    rarity: "Rare",
  },
  {
    id: "toxic",
    name: "Toxic",
    tagline: "Certified radioactive.",
    inner: "#f6ffd8",
    core: "#c6ff5c",
    outer: "#4d7a06",
    glow: "#b8ff4d",
    trail: "#e2ff9e",
    price: 900,
    rarity: "Epic",
  },
  {
    id: "bubblegum",
    name: "Bubblegum",
    tagline: "Pretty. Unhinged.",
    inner: "#fff0fa",
    core: "#ff9bdc",
    outer: "#b0337f",
    glow: "#ff85d1",
    trail: "#ffc7ec",
    price: 1200,
    rarity: "Epic",
  },
  {
    id: "solar",
    name: "Solar",
    tagline: "Powered by pure hype.",
    inner: "#fffbe5",
    core: "#ffd76b",
    outer: "#b06d05",
    glow: "#ffc94d",
    trail: "#ffe9a8",
    price: 1500,
    rarity: "Epic",
  },
  {
    id: "obsidian",
    name: "Obsidian",
    tagline: "For the silent destroyers.",
    inner: "#aab4d6",
    core: "#4a5578",
    outer: "#0a0c14",
    glow: "#6d8bff",
    trail: "#8f9ec7",
    price: 1900,
    rarity: "Legendary",
  },
  {
    id: "prism",
    name: "Prism",
    tagline: "Every color, every drop.",
    inner: "#ffffff",
    core: "#ff6be0",
    outer: "#5c2bd6",
    glow: "#c46bff",
    trail: "#5cf2ff",
    price: 2500,
    rarity: "Legendary",
  },
  {
    id: "champion",
    name: "Champion",
    tagline: "Only for the 2000 club.",
    inner: "#fff9e3",
    core: "#ffe08a",
    outer: "#8a5a00",
    glow: "#ffd76b",
    trail: "#fff3c4",
    price: 3200,
    rarity: "Legendary",
  },
];

export const getSkin = (id: string): Skin => SKINS.find((s) => s.id === id) ?? SKINS[0];
export const getWorld = (level: number): World =>
  WORLDS[Math.min(TOTAL_WORLDS - 1, Math.max(0, Math.floor((level - 1) / LEVELS_PER_WORLD)))];
export const getWorldLevels = (worldId: number) => ({
  from: (worldId - 1) * LEVELS_PER_WORLD + 1,
  to: worldId * LEVELS_PER_WORLD,
});

export type LeaderSeed = {
  name: string;
  score: number;
  level: number;
  avatar: string;
  tint: string;
  flag: string;
};

export const LEADERBOARD_SEED: LeaderSeed[] = [
  { name: "KaiSmasher", score: 4820500, level: 2000, avatar: "KS", tint: "#8b6bff", flag: "🇯🇵" },
  { name: "LunaDrops", score: 4612750, level: 1987, avatar: "LD", tint: "#38e8ff", flag: "🇸🇪" },
  { name: "0xNova", score: 4382100, level: 1964, avatar: "0X", tint: "#ff6be0", flag: "🇩🇪" },
  { name: "Aarav_07", score: 4100900, level: 1930, avatar: "AA", tint: "#ffc94d", flag: "🇮🇳" },
  { name: "Blink", score: 3888400, level: 1902, avatar: "BL", tint: "#b8ff4d", flag: "🇬🇧" },
  { name: "MikaDive", score: 3655100, level: 1876, avatar: "MD", tint: "#ff5d7a", flag: "🇰🇷" },
  { name: "TowerGhost", score: 3499000, level: 1851, avatar: "TG", tint: "#6d8bff", flag: "🇺🇸" },
  { name: "Shenron", score: 3312500, level: 1820, avatar: "SH", tint: "#3ff0a0", flag: "🇧🇷" },
  { name: "PixelRani", score: 3188400, level: 1804, avatar: "PR", tint: "#ff9bdc", flag: "🇱🇰" },
  { name: "DropTable", score: 3002400, level: 1776, avatar: "DT", tint: "#4fd8ff", flag: "🇨🇦" },
  { name: "Zaid_99", score: 2880100, level: 1744, avatar: "Z9", tint: "#ffd76b", flag: "🇦🇪" },
  { name: "NekoFall", score: 2742000, level: 1710, avatar: "NF", tint: "#c46bff", flag: "🇯🇵" },
  { name: "BounceKing", score: 2617900, level: 1686, avatar: "BK", tint: "#ff7a3c", flag: "🇳🇬" },
  { name: "Riya.Rush", score: 2496500, level: 1651, avatar: "RR", tint: "#42f5a7", flag: "🇮🇳" },
  { name: "Skyline_", score: 2377200, level: 1622, avatar: "SK", tint: "#9fb6d1", flag: "🇦🇺" },
  { name: "KimchiCore", score: 2254000, level: 1590, avatar: "KC", tint: "#ff5d7a", flag: "🇰🇷" },
  { name: "Orbital", score: 2148800, level: 1557, avatar: "OR", tint: "#5b7cff", flag: "🇫🇷" },
  { name: "MangoTap", score: 2031500, level: 1521, avatar: "MT", tint: "#ffc46b", flag: "🇵🇭" },
  { name: "Voidwalker", score: 1920400, level: 1489, avatar: "VW", tint: "#b58cff", flag: "🇵🇱" },
  { name: "Sena_", score: 1804600, level: 1450, avatar: "SE", tint: "#ffe55c", flag: "🇱🇰" },
  { name: "ChocoDrop", score: 1702800, level: 1416, avatar: "CD", tint: "#ff9bdc", flag: "🇧🇪" },
  { name: "RahulTNT", score: 1583400, level: 1372, avatar: "RT", tint: "#b8ff4d", flag: "🇮🇳" },
  { name: "EchoFall", score: 1462900, level: 1338, avatar: "EF", tint: "#38e8ff", flag: "🇳🇿" },
  { name: "Plum", score: 1356700, level: 1295, avatar: "PL", tint: "#c46bff", flag: "🇫🇮" },
  { name: "SnapStack", score: 1244500, level: 1260, avatar: "SS", tint: "#ffd76b", flag: "🇲🇽" },
  { name: "AyuNova", score: 1132600, level: 1218, avatar: "AN", tint: "#ff7a3c", flag: "🇮🇩" },
  { name: "HyperLion", score: 1041800, level: 1179, avatar: "HL", tint: "#ffc94d", flag: "🇬🇭" },
  { name: "Mellow", score: 962400, level: 1136, avatar: "ME", tint: "#3ff0a0", flag: "🇳🇱" },
  { name: "Koru", score: 883100, level: 1094, avatar: "KO", tint: "#6d8bff", flag: "🇯🇵" },
  { name: "Tempo", score: 811700, level: 1051, avatar: "TE", tint: "#ff5d7a", flag: "🇮🇹" },
  { name: "SonicBhai", score: 744600, level: 1008, avatar: "SB", tint: "#4fd8ff", flag: "🇵🇰" },
  { name: "Nyx", score: 681200, level: 962, avatar: "NY", tint: "#b58cff", flag: "🇳🇴" },
  { name: "Falafel", score: 623900, level: 919, avatar: "FA", tint: "#ffb26b", flag: "🇪🇬" },
  { name: "Drip", score: 571400, level: 874, avatar: "DR", tint: "#42f5a7", flag: "🇿🇦" },
  { name: "MysticMango", score: 519800, level: 830, avatar: "MM", tint: "#ff9bdc", flag: "🇹🇭" },
  { name: "Nadeesha", score: 469300, level: 781, avatar: "ND", tint: "#9d7bff", flag: "🇱🇰" },
  { name: "ChillPill", score: 418600, level: 729, avatar: "CP", tint: "#5cf2ff", flag: "🇩🇰" },
  { name: "StackRat", score: 367200, level: 671, avatar: "SR", tint: "#b8ff4d", flag: "🇮🇪" },
  { name: "BouncyBo", score: 319800, level: 608, avatar: "BB", tint: "#ff7a3c", flag: "🇹🇷" },
  { name: "Aria", score: 274500, level: 539, avatar: "AR", tint: "#ffd76b", flag: "🇬🇷" },
  { name: "LowGravity", score: 231100, level: 464, avatar: "LG", tint: "#8b6bff", flag: "🇦🇷" },
  { name: "FrostByte", score: 187700, level: 382, avatar: "FB", tint: "#a6f6ff", flag: "🇺🇦" },
];
