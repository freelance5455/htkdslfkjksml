// ============================================================
// DEEP DIG — static game data (treasure designer + game director)
// ============================================================

export type Rarity = "common" | "uncommon" | "rare" | "legendary";
export const RARITIES: Rarity[] = ["common", "uncommon", "rare", "legendary"];

export const RARITY_INFO: Record<
  Rarity,
  { name: string; color: string; hex: number; xp: number; bonus: number }
> = {
  common: { name: "Common", color: "#cfd6dd", hex: 0xcfd6dd, xp: 6, bonus: 100 },
  uncommon: { name: "Uncommon", color: "#5ee08a", hex: 0x5ee08a, xp: 18, bonus: 400 },
  rare: { name: "Rare", color: "#a46bff", hex: 0xa46bff, xp: 60, bonus: 1500 },
  legendary: { name: "Legendary", color: "#ffb82e", hex: 0xffb82e, xp: 240, bonus: 6000 },
};

// ---------------- Underground layers ----------------
export type SoundKind = "dry" | "wet" | "compact" | "clay" | "gravel" | "rock" | "mineral";
export interface LayerDef {
  name: string;
  resistance: number; // higher = slower to dig
  sound: SoundKind;
  slope: number; // angle-of-repose (tan) for slumping
  dust: number; // dust amount multiplier
  chunk: number; // chunk size multiplier
}
export const LAYERS: LayerDef[] = [
  { name: "Surface Sand", resistance: 1.0, sound: "dry", slope: 1.0, dust: 1.0, chunk: 1.0 },
  { name: "Wet Sand", resistance: 1.25, sound: "wet", slope: 1.0, dust: 0.3, chunk: 1.3 },
  { name: "Compact Sand", resistance: 1.6, sound: "compact", slope: 1.05, dust: 0.6, chunk: 1.1 },
  { name: "Clay", resistance: 2.0, sound: "clay", slope: 1.15, dust: 0.15, chunk: 1.8 },
  { name: "Gravel", resistance: 2.4, sound: "gravel", slope: 1.3, dust: 0.4, chunk: 1.4 },
  { name: "Rocky Soil", resistance: 3.0, sound: "rock", slope: 1.45, dust: 0.5, chunk: 1.6 },
  { name: "Ancient Mineral Layer", resistance: 3.6, sound: "mineral", slope: 1.6, dust: 0.3, chunk: 1.2 },
];
// depth (metres under original surface) at which each layer ends
export const LAYER_ENDS = [0.5, 1.2, 2.1, 3.0, 4.0, 5.0, 6.0];
export const MAX_DEPTH = 6.0;
export function layerAtDepth(d: number): number {
  for (let i = 0; i < LAYER_ENDS.length; i++) if (d < LAYER_ENDS[i]) return i;
  return LAYER_ENDS.length - 1;
}
export function layerStart(i: number): number {
  return i === 0 ? 0 : LAYER_ENDS[i - 1];
}

// ---------------- Shovels ----------------
export interface ShovelDef {
  id: string;
  name: string;
  desc: string;
  price: number;
  level: number;
  power: number;
  speed: number;
  radius: number;
  luck: number;
}
export const SHOVELS: ShovelDef[] = [
  { id: "wood", name: "Wooden Shovel", desc: "A humble starter. Sturdy enough for beach sand.", price: 0, level: 1, power: 1.0, speed: 1.0, radius: 0.8, luck: 1.0 },
  { id: "iron", name: "Iron Shovel", desc: "Forged blade bites deeper with every scoop.", price: 450, level: 2, power: 1.3, speed: 1.1, radius: 0.9, luck: 1.0 },
  { id: "steel", name: "Steel Shovel", desc: "Hardened steel with a wide, sharp blade.", price: 2200, level: 5, power: 1.7, speed: 1.22, radius: 1.0, luck: 1.05 },
  { id: "pro", name: "Excavation Pro Shovel", desc: "Archaeologist-grade tool with a cushioned grip.", price: 8500, level: 9, power: 2.3, speed: 1.38, radius: 1.12, luck: 1.1 },
  { id: "golden", name: "Premium Golden Shovel", desc: "Gleaming and powerful. Treasure seems drawn to it.", price: 28000, level: 14, power: 3.1, speed: 1.55, radius: 1.28, luck: 1.25 },
];

// ---------------- Upgrades ----------------
export type UpgradeId = "power" | "speed" | "load" | "bag" | "detect" | "luck";
export interface UpgradeDef {
  id: UpgradeId;
  name: string;
  desc: string;
  effect: (lvl: number) => string;
  base: number;
  max: number;
}
export const UPGRADES: UpgradeDef[] = [
  { id: "power", name: "Digging Power", desc: "Remove more ground per scoop.", base: 120, max: 10, effect: (l) => `+${l * 12}% depth per scoop` },
  { id: "speed", name: "Digging Speed", desc: "Swing the shovel faster.", base: 140, max: 10, effect: (l) => `+${l * 7}% swing speed` },
  { id: "load", name: "Sand Capacity", desc: "Bigger scoops shift a wider patch of sand.", base: 110, max: 10, effect: (l) => `+${l * 6}% scoop width` },
  { id: "bag", name: "Bag Capacity", desc: "Carry more finds before heading to the merchant.", base: 90, max: 12, effect: (l) => `${10 + l * 5} item slots` },
  { id: "detect", name: "Detection Range", desc: "Metal detector senses treasure from farther away.", base: 130, max: 10, effect: (l) => `${(5 + l * 1.5).toFixed(1)} m range` },
  { id: "luck", name: "Discovery Efficiency", desc: "More lucky scoop-finds and better rarities.", base: 200, max: 10, effect: (l) => `+${l * 12}% find luck` },
];
export function upgradeCost(u: UpgradeDef, lvl: number): number {
  return Math.round((u.base * Math.pow(1.42, lvl)) / 5) * 5;
}

// ---------------- Locations ----------------
export type LocId = "beach" | "desert" | "tropical" | "dig" | "crystal";
export interface LocationDef {
  id: LocId;
  name: string;
  tagline: string;
  desc: string;
  cost: number;
  level: number;
  surface: [string, string];
  layerColors: string[];
  sky: { top: string; horizon: string; fog: string; fogNear: number; fogFar: number };
  sun: { color: string; intensity: number; dir: [number, number, number]; hemiSky: string; hemiGround: string; hemiI: number };
  water: { level: number; color: string; opacity: number } | null;
  farY: number;
  farSides: ("n" | "s" | "e" | "w")[];
  station: { x: number; z: number; rot: number };
  spawn: { x: number; z: number };
  rarityW: [number, number, number, number];
  ambient: "beach" | "desert" | "tropical" | "dig" | "crystal";
  clouds: number;
  accent: string;
  grad: [string, string];
}

export const LOCATIONS: LocationDef[] = [
  {
    id: "beach", name: "Sunny Beach", tagline: "Golden sand & rolling surf",
    desc: "A warm beach where tides have buried coins, shells and sea glass for generations. Perfect for beginners.",
    cost: 0, level: 1,
    surface: ["#e9d197", "#dcc085"],
    layerColors: ["#e7ce92", "#b79d69", "#a58b60", "#9b6c4b", "#8a847a", "#6e665c", "#5d4c7c"],
    sky: { top: "#3d86d6", horizon: "#bfe3f5", fog: "#cfe9f4", fogNear: 40, fogFar: 150 },
    sun: { color: "#fff1d0", intensity: 2.6, dir: [-0.5, 0.75, 0.4], hemiSky: "#bfe0ff", hemiGround: "#d8c08a", hemiI: 0.85 },
    water: { level: -0.45, color: "#2fa8c4", opacity: 0.86 },
    farY: 1.1, farSides: ["n", "e", "w"],
    station: { x: -12, z: -6, rot: 0.6 }, spawn: { x: -8, z: -2 },
    rarityW: [62, 27, 10, 1], ambient: "beach", clouds: 9, accent: "#ffd166", grad: ["#ffe29a", "#ff9a5a"],
  },
  {
    id: "desert", name: "Desert Ruins", tagline: "Orange dunes & forgotten stone",
    desc: "Wind-carved dunes hide the broken halls of a lost kingdom. Pottery, gemstones and relics sleep below.",
    cost: 900, level: 2,
    surface: ["#dc8d45", "#cf7b37"],
    layerColors: ["#da8c44", "#b96a30", "#a35b2a", "#8f4a33", "#8b7867", "#6a5445", "#7d4f6c"],
    sky: { top: "#2f78c9", horizon: "#f4d4a2", fog: "#f0cfa0", fogNear: 35, fogFar: 140 },
    sun: { color: "#ffe2b0", intensity: 3.0, dir: [0.6, 0.65, -0.3], hemiSky: "#ffe0b0", hemiGround: "#c7743a", hemiI: 0.8 },
    water: null, farY: 0.8, farSides: ["n", "s", "e", "w"],
    station: { x: 11, z: -10, rot: -0.7 }, spawn: { x: 7, z: -5 },
    rarityW: [50, 30, 17, 3], ambient: "desert", clouds: 3, accent: "#ff9d4d", grad: ["#ffb061", "#d95b2b"],
  },
  {
    id: "tropical", name: "Tropical Island", tagline: "White sand & pirate secrets",
    desc: "A palm-fringed island where pirates once buried their plunder. Pearls, doubloons and jeweled loot await.",
    cost: 3500, level: 5,
    surface: ["#f4eedb", "#ece4cb"],
    layerColors: ["#f2ead4", "#c9bd9b", "#b5a883", "#a27b55", "#8e8b81", "#6c6a60", "#3f7070"],
    sky: { top: "#2a9bd8", horizon: "#c9f0f2", fog: "#d2f1f1", fogNear: 40, fogFar: 150 },
    sun: { color: "#fff6dc", intensity: 2.7, dir: [0.4, 0.8, 0.5], hemiSky: "#c8f2ff", hemiGround: "#e6dcc0", hemiI: 0.9 },
    water: { level: -0.4, color: "#1fc5c5", opacity: 0.82 },
    farY: -1.4, farSides: [],
    station: { x: -3, z: -14, rot: 0.1 }, spawn: { x: -2, z: -9 },
    rarityW: [45, 32, 19, 4], ambient: "tropical", clouds: 8, accent: "#4ee0c1", grad: ["#7ef2d4", "#1c9fa8"],
  },
  {
    id: "dig", name: "Ancient Excavation Site", tagline: "Layers of history",
    desc: "A staged archaeological dig with deep strata of clay, gravel and mineral seams. Rare history lurks below.",
    cost: 10000, level: 9,
    surface: ["#b9946a", "#a98558"],
    layerColors: ["#b28c60", "#8f6d47", "#7b6a58", "#9e603a", "#7d7468", "#5f5750", "#8c7b3b"],
    sky: { top: "#5a8fcf", horizon: "#e6dcc8", fog: "#ddd3bf", fogNear: 30, fogFar: 130 },
    sun: { color: "#fff0d8", intensity: 2.4, dir: [-0.3, 0.7, -0.6], hemiSky: "#d8e6f5", hemiGround: "#a58863", hemiI: 0.85 },
    water: null, farY: 0.6, farSides: ["n", "s", "e", "w"],
    station: { x: 12, z: 8, rot: -2.2 }, spawn: { x: 8, z: 5 },
    rarityW: [38, 32, 23, 7], ambient: "dig", clouds: 6, accent: "#e0b36a", grad: ["#e6c48a", "#8b5e34"],
  },
  {
    id: "crystal", name: "Crystal Valley", tagline: "Glowing minerals & gemstones",
    desc: "A twilight valley of glowing crystal spires. Its strata gleam with rare gemstones and legendary hearts.",
    cost: 28000, level: 13,
    surface: ["#b9a8dc", "#a893d0"],
    layerColors: ["#b5a4d8", "#8e7cba", "#7b6ba6", "#5f5a9b", "#6a7a9c", "#4c4a7c", "#2fb0a6"],
    sky: { top: "#2a1f66", horizon: "#e9a5d8", fog: "#9a78c8", fogNear: 25, fogFar: 120 },
    sun: { color: "#ffd5f0", intensity: 1.9, dir: [0.5, 0.55, 0.5], hemiSky: "#a58cff", hemiGround: "#5a3a90", hemiI: 1.05 },
    water: null, farY: 3.2, farSides: ["n", "s", "e", "w"],
    station: { x: -10, z: 10, rot: 2.4 }, spawn: { x: -6, z: 6 },
    rarityW: [30, 32, 28, 10], ambient: "crystal", clouds: 0, accent: "#d58bff", grad: ["#e6a8ff", "#5b3bb5"],
  },
];
export function locById(id: string): LocationDef {
  return LOCATIONS.find((l) => l.id === id) || LOCATIONS[0];
}

// ---------------- Treasure database ----------------
export type Kind =
  | "stone" | "scallop" | "spiral" | "starfish" | "coin" | "fossil" | "glass" | "button" | "arrowhead" | "bone"
  | "gem" | "crystal" | "vase" | "geode" | "compass" | "watch" | "key" | "pearl" | "nugget" | "ring" | "necklace"
  | "scarab" | "goblet" | "mask" | "tablet" | "amber" | "idol" | "crown" | "scepter" | "chest" | "relics"
  | "heart" | "hoard" | "dagger" | "diamond" | "mineral";

export interface TDef {
  id: string;
  name: string;
  desc: string;
  rarity: Rarity;
  value: number;
  kind: Kind;
  color: number;
  color2?: number;
  shape?: number; // gem cut variant
  size: number; // longest dimension in metres
  metal: 0 | 1 | 2 | 3; // 0 none, 1 base metal, 2 silver, 3 gold-class detector tier
  layers: [number, number];
  locs: (LocId | "all")[];
  flat?: boolean; // lies flat on ground
}

const A: (LocId | "all")[] = ["all"];
export const TREASURES: TDef[] = [
  // ---- Common
  { id: "pebble", name: "River Pebble", desc: "A smooth, rounded pebble polished by centuries of water.", rarity: "common", value: 3, kind: "stone", color: 0x8d8f93, size: 0.14, metal: 0, layers: [0, 6], locs: A },
  { id: "spiral_shell", name: "Spiral Seashell", desc: "A pearly whelk shell with a perfect spiral.", rarity: "common", value: 6, kind: "spiral", color: 0xf0d9c0, color2: 0xd9a47c, size: 0.2, metal: 0, layers: [0, 2], locs: ["beach", "tropical"] },
  { id: "scallop", name: "Scallop Shell", desc: "Ribbed fan-shaped shell, a favorite of beachcombers.", rarity: "common", value: 7, kind: "scallop", color: 0xf4b8a0, size: 0.22, metal: 0, layers: [0, 2], locs: ["beach", "tropical"] },
  { id: "copper_coin", name: "Old Copper Coin", desc: "Worn smooth, its face long since faded.", rarity: "common", value: 9, kind: "coin", color: 0xb5653a, size: 0.14, metal: 1, layers: [0, 3], locs: A, flat: true },
  { id: "fossil", name: "Fossil Fragment", desc: "A coiled ammonite shell turned to stone 100 million years ago.", rarity: "common", value: 14, kind: "fossil", color: 0x9a8b78, size: 0.22, metal: 0, layers: [2, 6], locs: ["desert", "dig", "crystal", "beach"] },
  { id: "sea_glass", name: "Sea Glass Shard", desc: "A frosted shard of glass, tumbled soft by the sea.", rarity: "common", value: 8, kind: "glass", color: 0x57d6b0, size: 0.14, metal: 0, layers: [0, 2], locs: ["beach", "tropical", "dig"] },
  { id: "button", name: "Brass Button", desc: "An old uniform button with a faint anchor emblem.", rarity: "common", value: 8, kind: "button", color: 0xc9a23a, size: 0.12, metal: 1, layers: [0, 3], locs: A, flat: true },
  { id: "arrowhead", name: "Chipped Flint", desc: "A hand-knapped flint point from a forgotten hunter.", rarity: "common", value: 12, kind: "arrowhead", color: 0x6d6a66, size: 0.17, metal: 0, layers: [1, 5], locs: ["desert", "dig", "crystal"], flat: true },
  { id: "bone", name: "Weathered Bone", desc: "Sun-bleached bone, carried here by who knows what.", rarity: "common", value: 5, kind: "bone", color: 0xe9e1cf, size: 0.28, metal: 0, layers: [0, 4], locs: ["desert", "dig"], flat: true },
  { id: "starfish", name: "Dried Starfish", desc: "A five-armed starfish, baked hard by the sun.", rarity: "common", value: 10, kind: "starfish", color: 0xe0793c, size: 0.24, metal: 0, layers: [0, 2], locs: ["beach", "tropical"], flat: true },
  { id: "quartz_chip", name: "Quartz Chip", desc: "A milky quartz fragment catching the light.", rarity: "common", value: 11, kind: "crystal", color: 0xe8e4f0, size: 0.16, metal: 0, layers: [2, 6], locs: ["crystal", "dig", "desert"] },
  // ---- Uncommon
  { id: "silver_coin", name: "Silver Coin", desc: "A tarnished silver piece bearing a long-gone monarch.", rarity: "uncommon", value: 38, kind: "coin", color: 0xcfd3d9, color2: 0x9aa0a8, size: 0.16, metal: 2, layers: [0, 4], locs: A, flat: true },
  { id: "rose_quartz", name: "Rose Quartz", desc: "A soft pink crystal prized for its gentle glow.", rarity: "uncommon", value: 52, kind: "crystal", color: 0xf5a9c8, size: 0.2, metal: 0, layers: [1, 6], locs: A },
  { id: "citrine", name: "Citrine Gem", desc: "A sunny golden-yellow gemstone, expertly faceted by time.", rarity: "uncommon", value: 66, kind: "gem", color: 0xf7b92a, shape: 0, size: 0.16, metal: 0, layers: [1, 6], locs: A },
  { id: "pottery", name: "Ancient Pottery Vase", desc: "A painted clay vase with delicate geometric bands.", rarity: "uncommon", value: 82, kind: "vase", color: 0xc2602f, color2: 0x2a1c14, size: 0.3, metal: 0, layers: [1, 5], locs: ["desert", "dig", "tropical"] },
  { id: "amethyst", name: "Amethyst Geode", desc: "A split geode lined with deep violet crystals.", rarity: "uncommon", value: 95, kind: "geode", color: 0x8a52d6, size: 0.26, metal: 0, layers: [2, 6], locs: ["crystal", "dig", "desert"] },
  { id: "compass", name: "Antique Compass", desc: "A brass compass, its needle still points north.", rarity: "uncommon", value: 74, kind: "compass", color: 0xc8963a, size: 0.2, metal: 2, layers: [0, 4], locs: ["beach", "tropical", "dig"], flat: true },
  { id: "pocket_watch", name: "Pocket Watch", desc: "Stopped at a quarter past three, a century ago.", rarity: "uncommon", value: 90, kind: "watch", color: 0xd7d9dd, size: 0.18, metal: 2, layers: [0, 4], locs: A, flat: true },
  { id: "pearl", name: "Natural Pearl", desc: "A lustrous cream pearl, impossibly round.", rarity: "uncommon", value: 70, kind: "pearl", color: 0xf6f1e6, size: 0.1, metal: 0, layers: [0, 3], locs: ["beach", "tropical"] },
  { id: "skeleton_key", name: "Skeleton Key", desc: "An ornate iron key to a lock nobody remembers.", rarity: "uncommon", value: 44, kind: "key", color: 0x5a4a3a, size: 0.26, metal: 1, layers: [0, 5], locs: A, flat: true },
  { id: "fluorite", name: "Fluorite Cluster", desc: "Emerald-green cubic crystals fused together.", rarity: "uncommon", value: 78, kind: "mineral", color: 0x4de0a8, size: 0.22, metal: 0, layers: [3, 6], locs: ["crystal", "dig"] },
  // ---- Rare
  { id: "gold_nugget", name: "Gold Nugget", desc: "A hefty lump of pure gold, warm and heavy in the hand.", rarity: "rare", value: 220, kind: "nugget", color: 0xffc933, size: 0.2, metal: 3, layers: [2, 6], locs: A },
  { id: "emerald", name: "Emerald", desc: "A deep green emerald with a flawless step cut.", rarity: "rare", value: 340, kind: "gem", color: 0x12c46a, shape: 1, size: 0.18, metal: 0, layers: [3, 6], locs: A },
  { id: "ruby", name: "Ruby", desc: "A fiery red gem, glowing as if lit from within.", rarity: "rare", value: 400, kind: "gem", color: 0xe0143c, shape: 0, size: 0.17, metal: 0, layers: [3, 6], locs: A },
  { id: "sapphire", name: "Sapphire", desc: "A cornflower-blue sapphire of remarkable clarity.", rarity: "rare", value: 380, kind: "gem", color: 0x2650e8, shape: 2, size: 0.17, metal: 0, layers: [3, 6], locs: A },
  { id: "jeweled_ring", name: "Jeweled Ring", desc: "A gold ring set with a blazing ruby, from a noble hand.", rarity: "rare", value: 450, kind: "ring", color: 0xffc933, color2: 0xe0143c, size: 0.12, metal: 3, layers: [2, 6], locs: A, flat: true },
  { id: "pearl_necklace", name: "Pearl Necklace", desc: "A strand of matched pearls with a golden clasp.", rarity: "rare", value: 480, kind: "necklace", color: 0xf6f1e6, color2: 0xffc933, size: 0.3, metal: 3, layers: [2, 6], locs: ["beach", "tropical", "dig"], flat: true },
  { id: "scarab", name: "Golden Scarab", desc: "A sacred beetle amulet inlaid with lapis lazuli.", rarity: "rare", value: 520, kind: "scarab", color: 0xf2b928, color2: 0x2650c8, size: 0.2, metal: 3, layers: [3, 6], locs: ["desert", "dig"], flat: true },
  { id: "goblet", name: "Silver Goblet", desc: "A ceremonial goblet etched with ancient vines.", rarity: "rare", value: 290, kind: "goblet", color: 0xd5dae0, size: 0.26, metal: 2, layers: [2, 6], locs: A },
  { id: "doubloon", name: "Pirate Doubloon", desc: "A heavy Spanish gold doubloon from a sunken galleon.", rarity: "rare", value: 260, kind: "coin", color: 0xffc933, color2: 0xd69a14, size: 0.2, metal: 3, layers: [2, 6], locs: ["tropical", "beach"], flat: true },
  { id: "jade_mask", name: "Jade Mask", desc: "A funerary mask carved from a single block of jade.", rarity: "rare", value: 560, kind: "mask", color: 0x3fbf86, size: 0.28, metal: 0, layers: [3, 6], locs: ["desert", "dig", "tropical"], flat: true },
  { id: "tablet", name: "Cuneiform Tablet", desc: "A baked clay tablet inscribed with a forgotten language.", rarity: "rare", value: 310, kind: "tablet", color: 0xb48660, size: 0.26, metal: 0, layers: [3, 6], locs: ["desert", "dig"], flat: true },
  { id: "amber", name: "Insect in Amber", desc: "A 40-million-year-old fly frozen in golden amber.", rarity: "rare", value: 360, kind: "amber", color: 0xf0a020, size: 0.18, metal: 0, layers: [3, 6], locs: ["dig", "crystal", "tropical"] },
  // ---- Legendary
  { id: "golden_idol", name: "Golden Idol", desc: "A temple idol of solid gold with ruby eyes. Cursed? Probably.", rarity: "legendary", value: 2200, kind: "idol", color: 0xffc933, color2: 0xe0143c, size: 0.4, metal: 3, layers: [4, 6], locs: ["desert", "dig", "tropical", "crystal"] },
  { id: "royal_crown", name: "Royal Crown", desc: "A jewel-studded crown worn by a long-lost queen.", rarity: "legendary", value: 4200, kind: "crown", color: 0xffc933, color2: 0x2650e8, size: 0.42, metal: 3, layers: [4, 6], locs: A },
  { id: "star_diamond", name: "Star Diamond", desc: "A diamond of astonishing size. It seems to hold a star.", rarity: "legendary", value: 6000, kind: "diamond", color: 0xe6f6ff, size: 0.3, metal: 0, layers: [5, 6], locs: A },
  { id: "pharaoh_scepter", name: "Pharaoh's Scepter", desc: "A golden crook and flail crowned with a sapphire.", rarity: "legendary", value: 3000, kind: "scepter", color: 0xffc933, color2: 0x2650e8, size: 0.6, metal: 3, layers: [4, 6], locs: ["desert", "dig"], flat: true },
  { id: "treasure_chest", name: "Mysterious Treasure Chest", desc: "An iron-bound chest, humming with a strange energy.", rarity: "legendary", value: 4800, kind: "chest", color: 0x6b3f22, color2: 0xffc933, size: 0.55, metal: 3, layers: [4, 6], locs: A },
  { id: "relic_collection", name: "Historical Relic Collection", desc: "A cache of urn, blade and sun-disc from a vanished era.", rarity: "legendary", value: 3400, kind: "relics", color: 0xd8a63a, color2: 0x6a8f9a, size: 0.5, metal: 3, layers: [4, 6], locs: ["dig", "desert", "crystal"], flat: true },
  { id: "valley_heart", name: "Heart of the Valley", desc: "A giant glowing crystal that pulses with a gentle heartbeat.", rarity: "legendary", value: 7500, kind: "heart", color: 0xc774ff, size: 0.42, metal: 0, layers: [5, 6], locs: ["crystal", "dig"] },
  { id: "captain_hoard", name: "Captain's Hoard", desc: "A glittering pile of doubloons, rubies and jeweled rings.", rarity: "legendary", value: 3900, kind: "hoard", color: 0xffc933, color2: 0xe0143c, size: 0.45, metal: 3, layers: [4, 6], locs: ["tropical", "beach"], flat: true },
  { id: "jeweled_dagger", name: "Jeweled Dagger", desc: "A ceremonial dagger with an emerald-set golden hilt.", rarity: "legendary", value: 2600, kind: "dagger", color: 0xffc933, color2: 0x12c46a, size: 0.42, metal: 3, layers: [4, 6], locs: A, flat: true },
];
export const TREASURE_MAP: Record<string, TDef> = Object.fromEntries(TREASURES.map((t) => [t.id, t]));
export function tdef(id: string): TDef | undefined {
  return TREASURE_MAP[id];
}

// ---------------- Progression ----------------
export function xpForLevel(level: number): number {
  return Math.round(30 + 20 * level + 8 * level * level);
}
export function levelReward(level: number): number {
  return 100 + level * 60;
}

export interface AchStats {
  digs: number;
  sandDug: number;
  items: number;
  coinsEarned: number;
  maxDepth: number;
  level: number;
  unlocked: number;
  discovered: number;
  rare: number;
  legendary: number;
  shovels: number;
}
export interface AchDef {
  id: string;
  name: string;
  desc: string;
  reward: number;
  check: (s: AchStats) => boolean;
}
export const ACHIEVEMENTS: AchDef[] = [
  { id: "first_dig", name: "First Scoop", desc: "Dig your first hole.", reward: 30, check: (s) => s.digs >= 1 },
  { id: "digs_100", name: "Getting Dirty", desc: "Dig 100 scoops.", reward: 150, check: (s) => s.digs >= 100 },
  { id: "digs_1000", name: "Ground Breaker", desc: "Dig 1,000 scoops.", reward: 1200, check: (s) => s.digs >= 1000 },
  { id: "sand_50", name: "Sandcastle Architect", desc: "Move 50 m³ of earth.", reward: 300, check: (s) => s.sandDug >= 50 },
  { id: "sand_500", name: "Earth Mover", desc: "Move 500 m³ of earth.", reward: 2500, check: (s) => s.sandDug >= 500 },
  { id: "depth_3", name: "Going Deeper", desc: "Reach 3 m depth.", reward: 200, check: (s) => s.maxDepth >= 3 },
  { id: "depth_6", name: "Bedrock", desc: "Reach the bottom, 6 m deep.", reward: 1000, check: (s) => s.maxDepth >= 5.9 },
  { id: "items_10", name: "Beachcomber", desc: "Collect 10 treasures.", reward: 120, check: (s) => s.items >= 10 },
  { id: "items_100", name: "Hoarder", desc: "Collect 100 treasures.", reward: 1500, check: (s) => s.items >= 100 },
  { id: "first_rare", name: "Something Special", desc: "Find a Rare treasure.", reward: 300, check: (s) => s.rare >= 1 },
  { id: "first_legend", name: "Legend Hunter", desc: "Find a Legendary treasure.", reward: 2000, check: (s) => s.legendary >= 1 },
  { id: "disc_10", name: "Curator", desc: "Discover 10 different treasures.", reward: 400, check: (s) => s.discovered >= 10 },
  { id: "disc_25", name: "Master Collector", desc: "Discover 25 different treasures.", reward: 2500, check: (s) => s.discovered >= 25 },
  { id: "earn_5k", name: "Pocket Change", desc: "Earn 5,000 coins from selling.", reward: 500, check: (s) => s.coinsEarned >= 5000 },
  { id: "earn_100k", name: "Tycoon", desc: "Earn 100,000 coins.", reward: 8000, check: (s) => s.coinsEarned >= 100000 },
  { id: "explorer", name: "Explorer", desc: "Unlock 3 locations.", reward: 800, check: (s) => s.unlocked >= 3 },
  { id: "globetrotter", name: "Globetrotter", desc: "Unlock all 5 locations.", reward: 6000, check: (s) => s.unlocked >= 5 },
  { id: "level_10", name: "Seasoned Digger", desc: "Reach player level 10.", reward: 1500, check: (s) => s.level >= 10 },
  { id: "all_shovels", name: "Tool Collector", desc: "Own all 5 shovels.", reward: 3000, check: (s) => s.shovels >= 5 },
];

export type GoalType = "digs" | "items" | "depth" | "earn" | "rare";
export const GOAL_TEMPLATES: { type: GoalType; label: (n: number) => string; targets: number[]; reward: number[] }[] = [
  { type: "digs", label: (n) => `Dig ${n} scoops`, targets: [25, 40, 60], reward: [80, 140, 220] },
  { type: "items", label: (n) => `Collect ${n} treasures`, targets: [4, 6, 9], reward: [100, 170, 260] },
  { type: "depth", label: (n) => `Reach ${n} m deep`, targets: [1.5, 2.5, 3.5], reward: [90, 160, 250] },
  { type: "earn", label: (n) => `Earn ${n} coins`, targets: [150, 400, 900], reward: [120, 200, 320] },
  { type: "rare", label: (n) => `Find ${n} Uncommon+ treasure${n > 1 ? "s" : ""}`, targets: [1, 2, 3], reward: [150, 260, 400] },
];
