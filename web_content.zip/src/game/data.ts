export const PAL = {
  ink: "#1c2a22",
  cream: "#f3ead7",
  creamDeep: "#e4d3b4",
  moss: "#2f6b45",
  mossDeep: "#1e4630",
  leaf: "#3f8f45",
  leafLite: "#8fd16a",
  amber: "#e39b32",
  amberDeep: "#b6741c",
  tide: "#2f8eb3",
  tideLite: "#b7e4f2",
  wood: "#8a5a32",
  woodDark: "#5c3b22",
  stone: "#8a7564",
  stoneLite: "#d9cbb8",
  skin: "#f0c7a4",
  hair: "#3a2a22",
  sky: "#8ec4e6",
  skyFog: "#c5dff0",
  skyNight: "#1a2433",
  nightTop: "#141c30",
  foam: "#e7f4f2",
  sand: "#e4cfa2",
  ember: "#e07a3d",
  glow: "#f2c14d",
} as const;

export const ISLAND_R = 46;
export const SPAWN = { x: 0.2, z: 6.4 };
export const COTTAGE = { x: -8.2, z: -8.1 };
export const NIA = { x: -5.7, z: -5.9 };
export const FIRE = { x: 0.35, z: -1.15 };
export const POND = { x: 17.6, z: 8.2, r: 6.3 };

export const PADS = [
  { x: 7.2, z: -6.4 },
  { x: 10.4, z: 0.8 },
  { x: 3.2, z: 8.6 },
  { x: -9.4, z: 5.1 },
] as const;

export type Biome = "meadow" | "forest" | "pond" | "rocks" | "night";
export type Element = "leaf" | "tide" | "ember" | "stone" | "gust" | "glow";
export type Temperament = "shy" | "bold" | "calm";
export type BuildingType = "garden" | "mill" | "kiln" | "nest";

export type SpeciesId =
  | "sproutkit"
  | "ripplet"
  | "emberpup"
  | "mossbun"
  | "pebblin"
  | "breekit"
  | "glimmoth"
  | "thornox"
  | "dewdrop"
  | "cinderkit";

export type Species = {
  id: SpeciesId;
  name: string;
  element: Element;
  temperament: Temperament;
  blurb: string;
  job: string;
  hp: number;
  dmg: number;
  speed: number;
  scale: number;
  head: number;
  hover: boolean;
  rare: boolean;
  weight: number;
  biomes: Biome[];
  starter: boolean;
};

export const SPECIES_LIST: Species[] = [
  {
    id: "sproutkit",
    name: "Sproutkit",
    element: "leaf",
    temperament: "shy",
    blurb: "A leaf-eared fox that hums to seedlings.",
    job: "Garden & mill",
    hp: 46,
    dmg: 8,
    speed: 4.3,
    scale: 1,
    head: 1.22,
    hover: false,
    rare: false,
    weight: 1,
    biomes: ["forest", "meadow"],
    starter: true,
  },
  {
    id: "ripplet",
    name: "Ripplet",
    element: "tide",
    temperament: "calm",
    blurb: "A round tide otter who naps in puddles.",
    job: "Nest",
    hp: 50,
    dmg: 7,
    speed: 4.4,
    scale: 1.02,
    head: 1.05,
    hover: false,
    rare: false,
    weight: 1,
    biomes: ["pond"],
    starter: true,
  },
  {
    id: "emberpup",
    name: "Emberpup",
    element: "ember",
    temperament: "bold",
    blurb: "A spark-tailed pup that warms the kiln.",
    job: "Kiln",
    hp: 44,
    dmg: 10,
    speed: 4.7,
    scale: 1,
    head: 1.16,
    hover: false,
    rare: false,
    weight: 1,
    biomes: ["rocks"],
    starter: true,
  },
  {
    id: "mossbun",
    name: "Mossbun",
    element: "leaf",
    temperament: "shy",
    blurb: "A meadow rabbit with a cap of living moss.",
    job: "Garden & mill",
    hp: 36,
    dmg: 6,
    speed: 4.9,
    scale: 0.92,
    head: 1.28,
    hover: false,
    rare: false,
    weight: 3,
    biomes: ["meadow"],
    starter: false,
  },
  {
    id: "pebblin",
    name: "Pebblin",
    element: "stone",
    temperament: "calm",
    blurb: "A patient beetle wearing a pebble shell.",
    job: "Kiln",
    hp: 60,
    dmg: 8,
    speed: 3.1,
    scale: 1.05,
    head: 0.78,
    hover: false,
    rare: false,
    weight: 2,
    biomes: ["rocks"],
    starter: false,
  },
  {
    id: "breekit",
    name: "Breekit",
    element: "gust",
    temperament: "calm",
    blurb: "A cloud-chested bird that loves the mill sails.",
    job: "Mill",
    hp: 40,
    dmg: 7,
    speed: 5.2,
    scale: 0.96,
    head: 1.18,
    hover: true,
    rare: false,
    weight: 2,
    biomes: ["meadow", "forest"],
    starter: false,
  },
  {
    id: "glimmoth",
    name: "Glimmoth",
    element: "glow",
    temperament: "shy",
    blurb: "A dusk moth whose wings remember the sun.",
    job: "Nest",
    hp: 42,
    dmg: 9,
    speed: 4.3,
    scale: 0.94,
    head: 1.12,
    hover: true,
    rare: true,
    weight: 1,
    biomes: ["night"],
    starter: false,
  },
  {
    id: "thornox",
    name: "Thornox",
    element: "leaf",
    temperament: "bold",
    blurb: "A cactus boar. Grumpy, loyal, very spiky.",
    job: "Garden & mill",
    hp: 72,
    dmg: 12,
    speed: 3.5,
    scale: 1.22,
    head: 1.2,
    hover: false,
    rare: true,
    weight: 1,
    biomes: ["forest"],
    starter: false,
  },
  {
    id: "dewdrop",
    name: "Dewdrop",
    element: "tide",
    temperament: "shy",
    blurb: "A jelly drop that wobbles when it is brave.",
    job: "Nest",
    hp: 34,
    dmg: 6,
    speed: 3.3,
    scale: 0.88,
    head: 0.95,
    hover: false,
    rare: false,
    weight: 2,
    biomes: ["pond", "meadow"],
    starter: false,
  },
  {
    id: "cinderkit",
    name: "Cinderkit",
    element: "ember",
    temperament: "bold",
    blurb: "A charcoal cat with coals for freckles.",
    job: "Kiln",
    hp: 48,
    dmg: 11,
    speed: 4.8,
    scale: 0.98,
    head: 1.14,
    hover: false,
    rare: false,
    weight: 1,
    biomes: ["rocks", "night"],
    starter: false,
  },
];

export const SPECIES: Record<SpeciesId, Species> = Object.fromEntries(
  SPECIES_LIST.map((s) => [s.id, s]),
) as Record<SpeciesId, Species>;

export const STARTERS: SpeciesId[] = ["sproutkit", "ripplet", "emberpup"];

export const ELEMENT_LABEL: Record<Element, string> = {
  leaf: "Leaf",
  tide: "Tide",
  ember: "Ember",
  stone: "Stone",
  gust: "Gust",
  glow: "Glow",
};

export type NodeKind = "wood" | "stone" | "berry";

export const NODES: { kind: NodeKind; x: number; z: number; max: number }[] = [
  { kind: "wood", x: 5.4, z: 5.2, max: 3 },
  { kind: "wood", x: 6.6, z: 1.2, max: 3 },
  { kind: "wood", x: -6.6, z: 9.2, max: 3 },
  { kind: "wood", x: -15.2, z: -1.4, max: 3 },
  { kind: "wood", x: 12.4, z: -13.2, max: 3 },
  { kind: "berry", x: 4.8, z: 8.8, max: 4 },
  { kind: "berry", x: -5.1, z: 10.4, max: 4 },
  { kind: "berry", x: 13.2, z: 2.4, max: 4 },
  { kind: "berry", x: -14.4, z: 7.6, max: 4 },
  { kind: "stone", x: 9.2, z: -14.6, max: 3 },
  { kind: "stone", x: 16.8, z: -7.4, max: 3 },
  { kind: "stone", x: -1.4, z: -16.2, max: 3 },
  { kind: "stone", x: 22.4, z: 15.2, max: 3 },
];

export const COST: Record<BuildingType, { wood: number; stone: number; berry: number }> = {
  garden: { wood: 8, stone: 0, berry: 4 },
  mill: { wood: 6, stone: 4, berry: 0 },
  kiln: { wood: 6, stone: 8, berry: 0 },
  nest: { wood: 10, stone: 4, berry: 6 },
};

export const BUILDINGS: Record<BuildingType, { name: string; blurb: string; makes: string }> = {
  garden: {
    name: "Berry garden",
    blurb: "Leaf Palmons coax fruit out of the beds.",
    makes: "Berries",
  },
  mill: {
    name: "Wind mill",
    blurb: "Leaf and gust Palmons turn the sails for timber.",
    makes: "Wood",
  },
  kiln: {
    name: "Stone kiln",
    blurb: "Ember and stone Palmons bake bricks and Palorbs.",
    makes: "Stone and orbs",
  },
  nest: {
    name: "Soft nest",
    blurb: "Glow and tide Palmons mend everyone nearby.",
    makes: "Steady healing",
  },
};

export const BUILD_ORDER: BuildingType[] = ["garden", "mill", "kiln", "nest"];

export function workMatch(type: BuildingType, element: Element) {
  if (type === "garden") return element === "leaf";
  if (type === "mill") return element === "leaf" || element === "gust";
  if (type === "kiln") return element === "ember" || element === "stone";
  return element === "glow" || element === "tide";
}

export function daylight(day: number) {
  const d = Math.cos((day - 0.48) * Math.PI * 2);
  const t = Math.min(1, Math.max(0, (d + 0.2) / 0.8));
  return t * t * (3 - 2 * t);
}

export function clockLabel(day: number) {
  if (day < 0.12 || day >= 0.84) return "Night";
  if (day < 0.22) return "Dawn";
  if (day < 0.42) return "Morning";
  if (day < 0.58) return "Midday";
  if (day < 0.72) return "Afternoon";
  return "Dusk";
}

export function biomeAt(x: number, z: number): Biome {
  if (Math.hypot(x - POND.x, z - POND.z) < POND.r + 4) return "pond";
  if (x > 6 && z < -6) return "rocks";
  if (x < -8) return "forest";
  return "meadow";
}

export type DecorKind = "tree" | "pine" | "rock" | "flower" | "reed" | "crate";

export type Decor = {
  kind: DecorKind;
  x: number;
  z: number;
  s: number;
  ry: number;
  tint: number;
};

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function buildDecor(): Decor[] {
  const rnd = mulberry32(20260321);
  const out: Decor[] = [];
  const spots = [
    { x: COTTAGE.x, z: COTTAGE.z, r: 5.2 },
    { x: FIRE.x, z: FIRE.z, r: 2.3 },
    { x: SPAWN.x, z: SPAWN.z, r: 3.6 },
    { x: NIA.x, z: NIA.z, r: 1.5 },
    { x: POND.x, z: POND.z, r: POND.r + 1.3 },
    ...PADS.map((p) => ({ x: p.x, z: p.z, r: 2.3 })),
    ...NODES.map((n) => ({ x: n.x, z: n.z, r: 1.7 })),
  ];
  const ok = (x: number, z: number, rad: number) => {
    if (Math.hypot(x, z) > ISLAND_R - 2.8) return false;
    if (Math.abs(x) < 3.6 && z > -2.2 && z < 13) return false;
    for (const s of spots) {
      if (Math.hypot(x - s.x, z - s.z) < s.r + rad) return false;
    }
    for (const d of out) {
      const need = (d.kind === "flower" || d.kind === "reed" ? 0.45 : 1.7) + rad;
      if (Math.hypot(x - d.x, z - d.z) < need) return false;
    }
    return true;
  };
  const tryPlace = (kind: DecorKind, n: number, rad: number, smin: number, smax: number) => {
    let placed = 0;
    let guard = 0;
    while (placed < n && guard < n * 50) {
      guard += 1;
      const ang = rnd() * Math.PI * 2;
      const dist = Math.sqrt(rnd()) * (ISLAND_R - 3.4);
      const x = Math.cos(ang) * dist;
      const z = Math.sin(ang) * dist;
      if (!ok(x, z, rad)) continue;
      out.push({
        kind,
        x,
        z,
        s: smin + rnd() * (smax - smin),
        ry: rnd() * Math.PI * 2,
        tint: rnd(),
      });
      placed += 1;
    }
  };
  tryPlace("tree", 28, 1.05, 0.85, 1.35);
  tryPlace("pine", 12, 1, 0.9, 1.4);
  tryPlace("rock", 16, 0.75, 0.55, 1.2);
  tryPlace("flower", 46, 0.15, 0.7, 1.15);
  for (let i = 0; i < 16; i += 1) {
    const ang = rnd() * Math.PI * 2;
    const dist = POND.r + 0.2 + rnd() * 1.5;
    out.push({
      kind: "reed",
      x: POND.x + Math.cos(ang) * dist,
      z: POND.z + Math.sin(ang) * dist,
      s: 0.75 + rnd() * 0.7,
      ry: rnd() * 6,
      tint: rnd(),
    });
  }
  out.push({ kind: "crate", x: -6.5, z: -9.1, s: 1, ry: 0.25, tint: 0 });
  out.push({ kind: "crate", x: -7.35, z: -9.7, s: 0.78, ry: 0.9, tint: 0 });
  return out;
}

export const DECOR = buildDecor();

export const QUESTS = [
  {
    id: "wood",
    title: "Wake the woodpile",
    detail: "Gather 6 wood from ribboned trees.",
    done: "Nia left a basket of berries.",
  },
  {
    id: "catch",
    title: "A friend, not a fight",
    detail: "Catch a wild Palmon with a Palorb.",
    done: "The campfire coughs up extra Palorbs.",
  },
  {
    id: "work",
    title: "The village works",
    detail: "Raise a station and assign a Palmon.",
    done: "Old stones tumble out of the ridge.",
  },
  {
    id: "kinds",
    title: "Four voices",
    detail: "Befriend 4 kinds of Palmon.",
    done: "A Glimmoth drifts down and stays.",
  },
] as const;

export type QuestId = (typeof QUESTS)[number]["id"];
