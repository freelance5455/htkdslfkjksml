/* ============================================================
   MEME SURVIVORS — static game data
   weapons, enemies, bosses, levels, upgrades
   ============================================================ */

export type Rarity = 'common' | 'rare' | 'epic' | 'legendary';
export const RARITY_COLORS: Record<Rarity, string> = {
  common: '#9fb2c8', rare: '#4dd0e1', epic: '#c77dff', legendary: '#ffd23f',
};

export interface WeaponDef {
  id: string; name: string; desc: string;
  rof: number; dmg: number; pspeed: number; color: string;
}
export const WEAPONS: Record<string, WeaponDef> = {
  blaster: { id: 'blaster', name: 'Basic Blaster', desc: 'Reliable single-shot blaster. Balanced and honest.', rof: 2.5, dmg: 11, pspeed: 560, color: '#59d9ff' },
  shotgun: { id: 'shotgun', name: 'Meme Shotgun', desc: 'Sprays 5 pellets of pure disrespect at close range.', rof: 1.15, dmg: 7, pspeed: 540, color: '#ffb347' },
  laser: { id: 'laser', name: 'Laser Rifle', desc: 'Hyper-fast piercing beam. Pew pew, through and through.', rof: 2.1, dmg: 9, pspeed: 1050, color: '#ff4dd2' },
  plasma: { id: 'plasma', name: 'Plasma Cannon', desc: 'Slow, chunky globs that explode on impact.', rof: 0.85, dmg: 28, pspeed: 340, color: '#7dff6a' },
  rocket: { id: 'rocket', name: 'Rocket Launcher', desc: 'Big booms, big area damage, big smiles.', rof: 1.0, dmg: 21, pspeed: 430, color: '#ff8a47' },
  dual: { id: 'dual', name: 'Dual Pistols', desc: 'Rapid-fire twin pistols. Quantity is a quality.', rof: 4.8, dmg: 6, pspeed: 660, color: '#ffd23f' },
  tesla: { id: 'tesla', name: 'Zapper 9000', desc: 'Bolts that arc lightning to nearby enemies.', rof: 1.55, dmg: 9, pspeed: 720, color: '#9df2ff' },
  homing: { id: 'homing', name: 'Simp Seeker', desc: 'Homing missiles that chase enemies obsessively.', rof: 1.9, dmg: 13, pspeed: 400, color: '#ff9df2' },
};

export type EnemyKind = 'ground' | 'fast' | 'fly' | 'hop' | 'tank' | 'ranged';
export interface EnemyDef {
  id: string; name: string; sprite: string;
  hp: number; spd: number; dmg: number; xp: number; kind: EnemyKind;
}
export const ENEMIES: Record<string, EnemyDef> = {
  slime: { id: 'slime', name: 'Smile Blob', sprite: 'slime', hp: 14, spd: 52, dmg: 6, xp: 2, kind: 'ground' },
  potato: { id: 'potato', name: 'Tater Goblin', sprite: 'potato', hp: 22, spd: 46, dmg: 8, xp: 2, kind: 'ground' },
  chicken: { id: 'chicken', name: 'Angry Chicken', sprite: 'chicken', hp: 11, spd: 128, dmg: 6, xp: 3, kind: 'fast' },
  derpycat: { id: 'derpycat', name: 'Derpy Sky Cat', sprite: 'derpycat', hp: 17, spd: 78, dmg: 8, xp: 3, kind: 'fly' },
  frog: { id: 'frog', name: 'Bounce Frog', sprite: 'frog', hp: 19, spd: 64, dmg: 8, xp: 3, kind: 'hop' },
  toilet: { id: 'toilet', name: 'Cursed Toilet', sprite: 'toilet', hp: 62, spd: 32, dmg: 13, xp: 6, kind: 'tank' },
  robot: { id: 'robot', name: 'Meme Bot', sprite: 'robot', hp: 28, spd: 46, dmg: 6, xp: 5, kind: 'ranged' },
  skeleton: { id: 'skeleton', name: 'Skele-troll', sprite: 'skeleton', hp: 24, spd: 98, dmg: 8, xp: 4, kind: 'fast' },
  ghost: { id: 'ghost', name: 'Boo.exe', sprite: 'ghost', hp: 24, spd: 68, dmg: 9, xp: 4, kind: 'fly' },
  cybercat: { id: 'cybercat', name: 'Cyber Cat', sprite: 'cybercat', hp: 22, spd: 135, dmg: 9, xp: 5, kind: 'fly' },
  mutantfrog: { id: 'mutantfrog', name: 'Toxic Toad', sprite: 'mutantfrog', hp: 85, spd: 50, dmg: 13, xp: 7, kind: 'hop' },
  brainrot: { id: 'brainrot', name: 'Brainrot Blob', sprite: 'brainrot', hp: 58, spd: 62, dmg: 9, xp: 8, kind: 'ranged' },
};

export type BossAttack = 'slam' | 'charge' | 'spread' | 'ring' | 'summon' | 'barrage';
export interface BossDef {
  id: string; name: string; sprite: string;
  hp: number; spd: number; dmg: number; xp: number;
  attacks: BossAttack[]; flyer?: boolean;
}
export const BOSSES: Record<string, BossDef> = {
  boss_potato: { id: 'boss_potato', name: 'GIANT EVIL POTATO', sprite: 'boss_potato', hp: 340, spd: 56, dmg: 16, xp: 90, attacks: ['slam', 'spread', 'summon'] },
  boss_frog: { id: 'boss_frog', name: 'SWAMP BRAINROT KING', sprite: 'boss_frog', hp: 720, spd: 62, dmg: 18, xp: 140, attacks: ['slam', 'barrage', 'summon'] },
  boss_toilet: { id: 'boss_toilet', name: 'CYBER TOILET OVERLORD', sprite: 'boss_toilet', hp: 1350, spd: 58, dmg: 20, xp: 210, attacks: ['charge', 'spread', 'ring', 'summon'] },
  boss_lord: { id: 'boss_lord', name: 'THE CURSED MEME LORD', sprite: 'boss_lord', hp: 2400, spd: 72, dmg: 22, xp: 300, attacks: ['ring', 'barrage', 'charge', 'summon'], flyer: true },
  boss_brainrot: { id: 'boss_brainrot', name: 'ULTIMATE BRAINROT ENTITY', sprite: 'boss_brainrot', hp: 4200, spd: 64, dmg: 26, xp: 500, attacks: ['slam', 'ring', 'barrage', 'summon', 'charge'] },
};

export interface LevelDef {
  id: string; name: string; sub: string;
  theme: 'forest' | 'swamp' | 'city' | 'castle' | 'chaos';
  seed: number; night?: boolean;
  sky: [string, string, string];
  sun: string; sunGlow: string; sunPos: [number, number];
  cloud: string; farCol: string; midCol: string; midCol2: string; windowCol: string;
  groundCol: string; groundTop: string; groundEdge: string;
  roster: string[]; miniboss: string; boss: string;
}
export const LEVELS: LevelDef[] = [
  {
    id: 'forest', name: 'MEME FOREST', sub: 'Stage 1', theme: 'forest', seed: 11,
    sky: ['#7ec8ff', '#b8e8ff', '#e8f8e0'], sun: '#ffd23f', sunGlow: '#ffe89d', sunPos: [810, 92], cloud: '#ffffff',
    farCol: '#8ecf8a', midCol: '#3f9c4d', midCol2: '#57bb62', windowCol: '#ffd23f',
    groundCol: '#8a5a2e', groundTop: '#58c24a', groundEdge: '#7ddf64',
    roster: ['slime', 'potato', 'chicken', 'derpycat', 'frog'], miniboss: 'potato', boss: 'boss_potato',
  },
  {
    id: 'swamp', name: 'TOXIC SWAMP', sub: 'Stage 2', theme: 'swamp', seed: 23,
    sky: ['#3e6b4f', '#5f9664', '#a8c98a'], sun: '#c8ff6a', sunGlow: '#e2ffa8', sunPos: [150, 88], cloud: '#d8e8c8',
    farCol: '#35684a', midCol: '#2a5040', midCol2: '#4fae4f', windowCol: '#c8ff6a',
    groundCol: '#3f4a3a', groundTop: '#5a7a48', groundEdge: '#7ddf64',
    roster: ['frog', 'slime', 'mutantfrog', 'ghost', 'derpycat'], miniboss: 'mutantfrog', boss: 'boss_frog',
  },
  {
    id: 'city', name: 'NEON CITY', sub: 'Stage 3', theme: 'city', seed: 37, night: true,
    sky: ['#10131f', '#1c2140', '#3a2a5a'], sun: '#ff9df2', sunGlow: '#ff2ea6', sunPos: [780, 100], cloud: '#2a3050',
    farCol: '#1c2140', midCol: '#2a3050', midCol2: '#3a3f66', windowCol: '#ffd23f',
    groundCol: '#232738', groundTop: '#3a3f52', groundEdge: '#4dd0e1',
    roster: ['robot', 'cybercat', 'chicken', 'toilet', 'brainrot'], miniboss: 'toilet', boss: 'boss_toilet',
  },
  {
    id: 'castle', name: 'DARK CASTLE', sub: 'Stage 4', theme: 'castle', seed: 53, night: true,
    sky: ['#140f26', '#2a1f4a', '#4a2a5a'], sun: '#e8e8ff', sunGlow: '#b8b8e8', sunPos: [170, 84], cloud: '#2e2652',
    farCol: '#241c40', midCol: '#352a58', midCol2: '#4a3585', windowCol: '#ffd23f',
    groundCol: '#2e2447', groundTop: '#4a3d6b', groundEdge: '#8a7bb8',
    roster: ['skeleton', 'ghost', 'toilet', 'brainrot', 'cybercat'], miniboss: 'skeleton', boss: 'boss_lord',
  },
  {
    id: 'chaos', name: 'CHAOS DIMENSION', sub: 'Stage 5', theme: 'chaos', seed: 71, night: true,
    sky: ['#1a0b2e', '#4a1060', '#8a2060'], sun: '#7dff6a', sunGlow: '#c8ff9d', sunPos: [480, 74], cloud: '#5a2a8a',
    farCol: '#3a1560', midCol: '#50208a', midCol2: '#6a2ab0', windowCol: '#7dff6a',
    groundCol: '#2a1048', groundTop: '#552090', groundEdge: '#c25eff',
    roster: ['brainrot', 'cybercat', 'mutantfrog', 'toilet', 'ghost'], miniboss: 'brainrot', boss: 'boss_brainrot',
  },
];

/* ---------------- upgrades ---------------- */
export interface UpgradeDef {
  id: string; name: string; desc: string;
  rarity: Rarity; icon: string; max?: number;
}
export const UPGRADES: UpgradeDef[] = [
  { id: 'dmg', name: 'Meme Power', desc: '+20% weapon damage', rarity: 'common', icon: 'dmg' },
  { id: 'rof', name: 'Trigger Finger', desc: '+15% attack speed', rarity: 'common', icon: 'rof' },
  { id: 'pspeed', name: 'Swift Bullets', desc: '+20% projectile speed', rarity: 'common', icon: 'pspeed' },
  { id: 'maxhp', name: 'Big Heart', desc: '+20% max HP (and heal it)', rarity: 'common', icon: 'maxhp' },
  { id: 'heal', name: 'Snack Break', desc: 'Restore 30% HP right now', rarity: 'common', icon: 'heal' },
  { id: 'speed', name: 'Zoomies', desc: '+12% movement speed', rarity: 'common', icon: 'speed' },
  { id: 'magnet', name: 'XP Magnet', desc: '+60% XP absorption range', rarity: 'common', icon: 'magnet', max: 3 },
  { id: 'crit', name: 'Meme Aim', desc: '+12% critical chance', rarity: 'rare', icon: 'crit' },
  { id: 'critd', name: 'Devastation', desc: '+30% critical damage', rarity: 'rare', icon: 'critd' },
  { id: 'pierce', name: 'Piercing Rounds', desc: 'Projectiles pierce +1 enemy', rarity: 'rare', icon: 'pierce', max: 3 },
  { id: 'def', name: 'Thick Skin', desc: '+12% damage resistance', rarity: 'rare', icon: 'def' },
  { id: 'shield', name: 'Plot Armor', desc: 'Shield absorbs 30 dmg, refreshes over time', rarity: 'rare', icon: 'shield' },
  { id: 'regen', name: 'Cozy Regen', desc: 'Regenerate +1.2 HP per second', rarity: 'rare', icon: 'regen' },
  { id: 'mines', name: 'Boom Garden', desc: 'Deploy an explosive mine every 4s', rarity: 'rare', icon: 'mines', max: 3 },
  { id: 'freeze', name: 'Chill Vibes', desc: 'Hits have 12% chance to freeze enemies', rarity: 'rare', icon: 'freeze', max: 3 },
  { id: 'expl', name: 'Spicy Rounds', desc: 'Bullets explode for area damage', rarity: 'epic', icon: 'expl' },
  { id: 'chain', name: 'Chain Lightning', desc: 'Hits arc lightning to a nearby enemy', rarity: 'epic', icon: 'chain' },
  { id: 'ricochet', name: 'Bouncy Bullets', desc: 'Bullets ricochet to +1 enemy', rarity: 'epic', icon: 'ricochet', max: 2 },
  { id: 'orbit', name: 'Orbit Guardians', desc: 'Energy shards orbit you, shredding on contact', rarity: 'epic', icon: 'orbit', max: 3 },
  { id: 'turret', name: 'Baby Turret', desc: 'Deploy a friendly auto-turret (10s uptime)', rarity: 'epic', icon: 'turret', max: 2 },
  { id: 'shots', name: 'Multishot', desc: '+1 projectile per shot', rarity: 'legendary', icon: 'shots', max: 3 },
  { id: 'drone', name: 'Drone Buddy', desc: 'A loyal drone orbits you and snipes enemies', rarity: 'legendary', icon: 'drone', max: 2 },
];

const RW: Record<Rarity, number> = { common: 100, rare: 52, epic: 22, legendary: 11 };

export function rollUpgrades(taken: Record<string, number>, count = 2): UpgradeDef[] {
  const pool = UPGRADES.filter(u => (taken[u.id] || 0) < (u.max ?? 99));
  const out: UpgradeDef[] = [];
  const used = new Set<string>();
  while (out.length < count && used.size < pool.length) {
    let total = 0;
    for (const u of pool) if (!used.has(u.id)) total += RW[u.rarity];
    let r = Math.random() * total;
    for (const u of pool) {
      if (used.has(u.id)) continue;
      r -= RW[u.rarity];
      if (r <= 0) { used.add(u.id); out.push(u); break; }
    }
  }
  return out;
}

/* ---------------- weapon reward choices ---------------- */
export interface ChoiceDef {
  id: string; kind: 'weapon' | 'mastery' | 'heal' | 'power';
  name: string; desc: string; rarity: Rarity; weaponId?: string;
}
export function rollWeaponChoices(currentWeapon: string, owned: string[]): ChoiceDef[] {
  const fresh = Object.keys(WEAPONS).filter(w => !owned.includes(w));
  const picks: ChoiceDef[] = [];
  while (picks.length < 2 && fresh.length > 0) {
    const i = Math.floor(Math.random() * fresh.length);
    const id = fresh.splice(i, 1)[0];
    const w = WEAPONS[id];
    picks.push({ id: 'w_' + id, kind: 'weapon', weaponId: id, name: w.name, desc: w.desc, rarity: picks.length === 0 ? 'legendary' : 'epic' });
  }
  const w = WEAPONS[currentWeapon];
  picks.push({ id: 'm_' + currentWeapon, kind: 'mastery', weaponId: currentWeapon, name: w.name + ' Mastery', desc: 'Upgrade current weapon: +18% damage.', rarity: 'rare' });
  picks.push({ id: 'heal', kind: 'heal', name: 'Full Heal + HP Up', desc: 'Restore all HP and gain +15 max HP.', rarity: 'rare' });
  // shuffle, keep 3
  for (let i = picks.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1));[picks[i], picks[j]] = [picks[j], picks[i]]; }
  return picks.slice(0, 3);
}

/* high score + settings persistence */
export interface HighScore { stage: number; wave: number; kills: number; }
export function loadHigh(): HighScore | null {
  try { const s = localStorage.getItem('ms_high'); return s ? JSON.parse(s) : null; } catch { return null; }
}
export function saveHigh(h: HighScore) {
  try {
    const prev = loadHigh();
    if (!prev || h.stage > prev.stage || (h.stage === prev.stage && h.wave > prev.wave) || (h.stage === prev.stage && h.wave === prev.wave && h.kills > prev.kills))
      localStorage.setItem('ms_high', JSON.stringify(h));
  } catch { /* ignore */ }
}
