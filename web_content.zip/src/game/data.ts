export type IngId =
  | "shell"
  | "potato"
  | "onion"
  | "chili"
  | "tamarind"
  | "muri"
  | "chickpea"
  | "egg"
  | "syrup"
  | "spice";

export interface Ingredient {
  id: IngId;
  bn: string;
  en: string;
  icon: string;
  color: string;
  key: string;
  start?: boolean;
}

export const INGREDIENTS: Ingredient[] = [
  { id: "shell", bn: "ফুচকা শেল", en: "Crisp Shell", icon: "🥟", color: "#e8a94b", key: "1", start: true },
  { id: "potato", bn: "আলু সেদ্ধ", en: "Mashed Potato", icon: "🥔", color: "#d9b478", key: "2", start: true },
  { id: "onion", bn: "পেঁয়াজ", en: "Onion", icon: "🧅", color: "#c9a0dc", key: "3", start: true },
  { id: "chili", bn: "কাঁচা মরিচ", en: "Green Chili", icon: "🌶️", color: "#e8384f", key: "4", start: true },
  { id: "tamarind", bn: "তেঁতুলের জল", en: "Tamarind Water", icon: "🫗", color: "#8a4b12", key: "5", start: true },
  { id: "muri", bn: "মুড়ি", en: "Puffed Rice", icon: "🍚", color: "#fff3dc", key: "6", start: true },
  { id: "chickpea", bn: "ছোলা", en: "Chickpea", icon: "🫘", color: "#c98b3a", key: "7" },
  { id: "egg", bn: "ডিম সেদ্ধ", en: "Boiled Egg", icon: "🥚", color: "#ffe9c2", key: "8" },
  { id: "syrup", bn: "চিনির সিরাপ", en: "Sugar Syrup", icon: "🍯", color: "#ffb627", key: "9" },
  { id: "spice", bn: "স্পেশাল মসলা", en: "Secret Masala", icon: "✨", color: "#ff4d8d", key: "0" },
];

export const ING_MAP: Record<IngId, Ingredient> = INGREDIENTS.reduce(
  (a, i) => ((a[i.id] = i), a),
  {} as Record<IngId, Ingredient>,
);

export interface Dish {
  id: string;
  bn: string;
  en: string;
  icon: string;
  color: string;
  price: number;
  recipe: IngId[];
  needs: IngId[];
  festival?: boolean;
}

export const DISHES: Dish[] = [
  {
    id: "fuchka",
    bn: "ফুচকা",
    en: "Fuchka",
    icon: "🥟",
    color: "#e8a94b",
    price: 22,
    recipe: ["shell", "potato", "onion", "chili", "tamarind"],
    needs: ["shell", "potato", "onion", "chili", "tamarind"],
  },
  {
    id: "jhalmuri",
    bn: "ঝালমুড়ি",
    en: "Jhal Muri",
    icon: "🥣",
    color: "#ff8a4d",
    price: 20,
    recipe: ["muri", "onion", "chili", "tamarind"],
    needs: ["muri", "onion", "chili", "tamarind"],
  },
  {
    id: "jilapi",
    bn: "জিলাপি",
    en: "Jilapi",
    icon: "🥨",
    color: "#ffb627",
    price: 18,
    recipe: ["shell", "syrup"],
    needs: ["shell", "syrup"],
    festival: true,
  },
  {
    id: "chotpoti",
    bn: "চটপটি",
    en: "Chotpoti",
    icon: "🍲",
    color: "#c98b3a",
    price: 38,
    recipe: ["chickpea", "potato", "onion", "chili", "tamarind"],
    needs: ["chickpea", "potato", "onion", "chili", "tamarind"],
  },
  {
    id: "halim",
    bn: "হালিম",
    en: "Halim",
    icon: "🍛",
    color: "#a4562a",
    price: 52,
    recipe: ["chickpea", "potato", "spice", "egg"],
    needs: ["chickpea", "potato", "spice", "egg"],
    festival: true,
  },
  {
    id: "mughlai",
    bn: "মোগলাই পরোটা",
    en: "Mughlai Parota",
    icon: "🫓",
    color: "#e2b361",
    price: 64,
    recipe: ["egg", "shell", "spice", "onion"],
    needs: ["egg", "shell", "spice", "onion"],
  },
];

export type Hair = "cap" | "short" | "bun" | "bald" | "hijab" | "helmet" | "long";

export interface CustType {
  id: string;
  bn: string;
  en: string;
  patience: number;
  tipMul: number;
  minDay: number;
  weight: number;
  skin: string;
  shirt: string;
  hair: Hair;
  hairColor: string;
  acc: string;
  quirk: string;
  rich?: boolean;
}

export const CUSTOMER_TYPES: CustType[] = [
  {
    id: "student",
    bn: "অধৈর্য স্কুল ছাত্র",
    en: "Impatient Student",
    patience: 8.5,
    tipMul: 0.6,
    minDay: 1,
    weight: 34,
    skin: "#e0a878",
    shirt: "#3f7fd6",
    hair: "short",
    hairColor: "#241a1a",
    acc: "🎒",
    quirk: "খুব তাড়া — দেরি হলেই রাগ করে চলে যায়!",
  },
  {
    id: "rickshaw",
    bn: "রিকশাওয়ালা ভাই",
    en: "Rickshaw Puller",
    patience: 17,
    tipMul: 0.9,
    minDay: 1,
    weight: 24,
    skin: "#a9703f",
    shirt: "#3fae5a",
    hair: "cap",
    hairColor: "#e8384f",
    acc: "🛺",
    quirk: "ধৈর্যশীল নিয়মিত কাস্টমার।",
  },
  {
    id: "office",
    bn: "অফিসগামী চাকরিজীবী",
    en: "Office Worker",
    patience: 12.5,
    tipMul: 1.7,
    minDay: 1,
    weight: 26,
    skin: "#d79f6f",
    shirt: "#5b6b8c",
    hair: "short",
    hairColor: "#2b2118",
    acc: "💼",
    quirk: "পারফেক্ট খাবারে মোটা টিপস দেয়।",
  },
  {
    id: "dadi",
    bn: "পাড়ার দাদি",
    en: "Neighbourhood Elder",
    patience: 19,
    tipMul: 1.15,
    minDay: 2,
    weight: 14,
    skin: "#c98f60",
    shirt: "#8e44ad",
    hair: "bun",
    hairColor: "#d9d3cc",
    acc: "🧺",
    quirk: "ধীরে সুস্থে, কিন্তু দোয়া দেয় — রেপুটেশন বাড়ে।",
  },
  {
    id: "blogger",
    bn: "ফুড ব্লগার",
    en: "Food Influencer",
    patience: 11,
    tipMul: 1.3,
    minDay: 2,
    weight: 7,
    skin: "#e8bd90",
    shirt: "#ff4d8d",
    hair: "long",
    hairColor: "#3a2418",
    acc: "📸",
    quirk: "পারফেক্ট দিলে ১০ জন কাস্টমার দ্বিগুণ টাকা দেবে!",
    rich: true,
  },
  {
    id: "tourist",
    bn: "বিদেশি ট্যুরিস্ট",
    en: "Tourist",
    patience: 14,
    tipMul: 2.3,
    minDay: 4,
    weight: 6,
    skin: "#f0cfae",
    shirt: "#17b8a6",
    hair: "helmet",
    hairColor: "#c9a227",
    acc: "🧳",
    quirk: "ক্যামেরা হাতে ঘোরে, টিপস দেয় রাজকীয়।",
    rich: true,
  },
];

export interface Location {
  id: string;
  bn: string;
  en: string;
  icon: string;
  priceMul: number;
  spawnMul: number;
  patienceMul: number;
  sky: [string, string, string];
  silo: string;
  tagline: string;
}

export const LOCATIONS: Location[] = [
  {
    id: "school",
    bn: "স্কুল গেট",
    en: "School Gate",
    icon: "🏫",
    priceMul: 1,
    spawnMul: 1,
    patienceMul: 1.15,
    sky: ["#3b2154", "#a34a6b", "#ffb26b"],
    silo: "school",
    tagline: "টিফিনের ঘণ্টা বাজলেই ভিড়",
  },
  {
    id: "park",
    bn: "পার্কের সামনে",
    en: "City Park",
    icon: "🌳",
    priceMul: 1.18,
    spawnMul: 1.12,
    patienceMul: 1.05,
    sky: ["#253a5e", "#3f7f8c", "#f2a65a"],
    silo: "park",
    tagline: "বিকেলের হাওয়ায় ঝালমুড়ির ঘ্রাণ",
  },
  {
    id: "dhanmondi",
    bn: "ধানমন্ডি মোড়",
    en: "Dhanmondi",
    icon: "🏙️",
    priceMul: 1.38,
    spawnMul: 1.24,
    patienceMul: 0.95,
    sky: ["#1f2a52", "#7b2d5e", "#f2714a"],
    silo: "city",
    tagline: "লেকের পাড়ে সন্ধ্যার ভিড়",
  },
  {
    id: "gulshan",
    bn: "গুলশান মোড়",
    en: "Gulshan",
    icon: "🌆",
    priceMul: 1.62,
    spawnMul: 1.36,
    patienceMul: 0.88,
    sky: ["#181c3d", "#4a2352", "#e8384f"],
    silo: "tower",
    tagline: "বড় টিপস, বড় লাইন, কম ধৈর্য",
  },
  {
    id: "shahbag",
    bn: "শাহবাগ চত্বর",
    en: "Shahbagh",
    icon: "🕌",
    priceMul: 1.9,
    spawnMul: 1.5,
    patienceMul: 0.85,
    sky: ["#131c33", "#2f5d62", "#f2b04a"],
    silo: "mosque",
    tagline: "রাতভর চলে ফুচকার হাট",
  },
  {
    id: "uttara",
    bn: "উত্তরা সেক্টর ৭",
    en: "Uttara",
    icon: "✈️",
    priceMul: 2.2,
    spawnMul: 1.65,
    patienceMul: 0.8,
    sky: ["#10162e", "#3a2154", "#ff4d8d"],
    silo: "airport",
    tagline: "বিমানের নিচে রাতের মেলা",
  },
];

export interface Festival {
  id: string;
  bn: string;
  en: string;
  icon: string;
  spawnMul: number;
  priceMul: number;
  patienceMul: number;
  dishes: string[];
  note: string;
  tint: string;
}

export const FESTIVALS: Record<number, Festival> = {
  3: {
    id: "boishakh",
    bn: "পহেলা বৈশাখ",
    en: "Pohela Boishakh",
    icon: "🎊",
    spawnMul: 1.7,
    priceMul: 1.3,
    patienceMul: 1.1,
    dishes: ["jilapi", "fuchka"],
    note: "লাল-সাদা শাড়ি, মঙ্গল শোভাযাত্রা — দ্বিগুণ ভিড়!",
    tint: "#e8384f",
  },
  6: {
    id: "ramzan",
    bn: "রমজান · ইফতার রাশ",
    en: "Ramzan Iftar Rush",
    icon: "🌙",
    spawnMul: 1.95,
    priceMul: 1.35,
    patienceMul: 0.8,
    dishes: ["halim", "jilapi", "chotpoti"],
    note: "ইফতারের এক ঘণ্টা আগে — সবাই ক্ষুধার্ত আর অধৈর্য!",
    tint: "#17b8a6",
  },
};

export type Cat = "ing" | "app" | "cart";

export interface Upgrade {
  id: string;
  cat: Cat;
  bn: string;
  en: string;
  icon: string;
  costs: number[];
  effect: string;
  unlocks?: string;
  ing?: IngId;
}

export const UPGRADES: Upgrade[] = [
  {
    id: "syrup",
    cat: "ing",
    bn: "চিনির সিরাপ",
    en: "Sugar Syrup",
    icon: "🍯",
    costs: [150],
    effect: "নতুন মেনু: জিলাপি (২ ট্যাপেই তৈরি)",
    ing: "syrup",
    unlocks: "jilapi",
  },
  {
    id: "chickpea",
    cat: "ing",
    bn: "ছোলা",
    en: "Chickpea",
    icon: "🫘",
    costs: [220],
    effect: "নতুন মেনু: চটপটি — দাম বেশি",
    ing: "chickpea",
    unlocks: "chotpoti",
  },
  {
    id: "egg",
    cat: "ing",
    bn: "ডিম সেদ্ধ",
    en: "Boiled Egg",
    icon: "🥚",
    costs: [280],
    effect: "হালিম ও মোগলাই পরোটার উপাদান",
    ing: "egg",
  },
  {
    id: "spice",
    cat: "ing",
    bn: "স্পেশাল মসলা",
    en: "Secret Masala",
    icon: "✨",
    costs: [400],
    effect: "হালিম + মোগলাই আনলক, সব দাম +১০%",
    ing: "spice",
    unlocks: "halim",
  },
  {
    id: "pot",
    cat: "app",
    bn: "বড় পাত্র",
    en: "Bigger Pot",
    icon: "🍲",
    costs: [240, 520, 980],
    effect: "+১টি প্লেট একসাথে রেডি রাখা যায়",
  },
  {
    id: "stove",
    cat: "app",
    bn: "দ্রুত আলু চটকানোর মেশিন",
    en: "Power Stove",
    icon: "🔥",
    costs: [200, 420, 760],
    effect: "খাবারের দাম +৮% (প্রতি লেভেল)",
  },
  {
    id: "auto",
    cat: "app",
    bn: "অটো-মেকার",
    en: "Auto Maker",
    icon: "🤖",
    costs: [430, 900],
    effect: "শুরু করা খাবার নিজেই পরের উপাদান যোগ করে",
  },
  {
    id: "light",
    cat: "cart",
    bn: "ঝালর লাইটিং",
    en: "String Lights",
    icon: "💡",
    costs: [180, 360, 700],
    effect: "কাস্টমারের ধৈর্য +১২% (প্রতি লেভেল)",
  },
  {
    id: "stool",
    cat: "cart",
    bn: "বসার টুল",
    en: "Sitting Stools",
    icon: "🪑",
    costs: [620],
    effect: "+১ জন কাস্টমার লাইনে দাঁড়াতে পারে",
  },
  {
    id: "sound",
    cat: "cart",
    bn: "সাউন্ড সিস্টেম",
    en: "Sound System",
    icon: "🔊",
    costs: [300, 680],
    effect: "ইনফ্লুয়েন্সার বেশি আসে, রেপুটেশন দ্রুত বাড়ে",
  },
  {
    id: "banner",
    cat: "cart",
    bn: "সুন্দর ব্যানার",
    en: "Painted Banner",
    icon: "🎨",
    costs: [240, 520],
    effect: "টিপস +১২% (প্রতি লেভেল)",
  },
];

export const CAT_INFO: Record<Cat, { bn: string; en: string; icon: string }> = {
  ing: { bn: "উপাদান", en: "Ingredients", icon: "🧺" },
  app: { bn: "যন্ত্রপাতি", en: "Appliances", icon: "⚙️" },
  cart: { bn: "ফুডকার্ট সাজসজ্জা", en: "Cart Aesthetics", icon: "🛖" },
};

export const DAY_LENGTH = (day: number) => Math.min(105, 68 + day * 5);
export const DAY_TARGET = (day: number) => Math.round((118 * Math.pow(day, 1.32)) / 10) * 10;
export const locForDay = (day: number) => LOCATIONS[Math.min(LOCATIONS.length - 1, day - 1)];
export const festForDay = (day: number) => FESTIVALS[day];

export const BN_DIGITS = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];
export const bn = (n: number | string) =>
  String(n).replace(/[0-9]/g, (d) => BN_DIGITS[Number(d)]);
export const taka = (n: number) => "৳" + bn(Math.round(n));
