import Phaser from 'phaser';
import { TEX } from './constants';
import { roundedTexture } from './textures';
import { sound } from './audio';
import { haptics } from './haptics';

export const FONT =
  'Fredoka, Nunito, "Arial Rounded MT Bold", "Segoe UI", Roboto, Helvetica, Arial, sans-serif';

export interface TextOpts {
  color?: string;
  stroke?: string;
  strokeThickness?: number;
  align?: 'left' | 'center' | 'right';
  shadow?: boolean;
  shadowBlur?: number;
  weight?: 'normal' | 'bold';
  origin?: [number, number];
}

export function makeText(
  scene: Phaser.Scene,
  x: number,
  y: number,
  str: string,
  size: number,
  opts: TextOpts = {}
): Phaser.GameObjects.Text {
  const t = scene.add.text(x, y, str, {
    fontFamily: FONT,
    fontSize: `${Math.max(8, Math.round(size))}px`,
    color: opts.color ?? '#ffffff',
    fontStyle: opts.weight ?? 'bold',
    align: opts.align ?? 'center',
    stroke: opts.stroke ?? '#000000',
    strokeThickness: opts.stroke ? opts.strokeThickness ?? Math.round(size * 0.12) : 0,
  });
  const [ox, oy] = opts.origin ?? [0.5, 0.5];
  t.setOrigin(ox, oy);
  if (opts.shadow) {
    t.setShadow(0, Math.max(1, size * 0.06), 'rgba(0,0,0,0.45)', opts.shadowBlur ?? 0, false, true);
  }
  return t;
}

/** Shared press feedback for anything clickable. */
function attachPress(
  scene: Phaser.Scene,
  target: Phaser.GameObjects.Container,
  onClick: () => void,
  isEnabled: () => boolean
): void {
  let pressed = false;
  const base = { x: 1, y: 1 };
  const restore = () => {
    scene.tweens.killTweensOf(target);
    scene.tweens.add({ targets: target, scaleX: base.x, scaleY: base.y, duration: 90, ease: 'Quad.easeOut' });
  };
  target.on('pointerdown', () => {
    if (!isEnabled()) return;
    pressed = true;
    base.x = target.scaleX;
    base.y = target.scaleY;
    scene.tweens.killTweensOf(target);
    scene.tweens.add({ targets: target, scaleX: base.x * 0.94, scaleY: base.y * 0.94, duration: 70 });
  });
  target.on('pointerup', () => {
    if (!pressed) return;
    pressed = false;
    restore();
    sound.unlock();
    sound.click();
    haptics.tap();
    onClick();
  });
  target.on('pointerout', () => {
    if (pressed) {
      pressed = false;
      restore();
    }
  });
}

export interface ButtonCfg {
  x: number;
  y: number;
  w: number;
  h: number;
  label: string;
  fill: string | string[];
  edge: string;
  fontSize: number;
  onClick: () => void;
  icon?: string;
  textColor?: string;
  subLabel?: string;
}

export class UIButton extends Phaser.GameObjects.Container {
  readonly label: Phaser.GameObjects.Text;
  enabled = true;

  constructor(scene: Phaser.Scene, cfg: ButtonCfg) {
    super(scene, cfg.x, cfg.y);
    const edgeH = Math.round(cfg.h * 0.09);
    const key = roundedTexture(scene, cfg.w, cfg.h, cfg.h * 0.32, cfg.fill, { edge: cfg.edge, edgeH });
    const face = scene.add.image(0, 0, key);
    this.add(face);

    const ty = -edgeH / 2 + (cfg.subLabel ? -cfg.fontSize * 0.22 : 0);
    let tx = 0;
    if (cfg.icon) {
      const iconSize = cfg.fontSize * 1.1;
      const icon = scene.add.image(0, ty, TEX, cfg.icon).setDisplaySize(iconSize, iconSize);
      this.add(icon);
      // measure text to centre icon + text as a group
      const probe = makeText(scene, 0, 0, cfg.label, cfg.fontSize);
      const total = iconSize + cfg.fontSize * 0.35 + probe.width;
      probe.destroy();
      icon.x = -total / 2 + iconSize / 2;
      tx = total / 2 - (total - iconSize - cfg.fontSize * 0.35) / 2;
    }
    this.label = makeText(scene, tx, ty, cfg.label, cfg.fontSize, {
      color: cfg.textColor ?? '#ffffff',
      shadow: true,
    });
    this.add(this.label);
    if (cfg.subLabel) {
      const sub = makeText(scene, 0, ty + cfg.fontSize * 0.78, cfg.subLabel, cfg.fontSize * 0.5, {
        color: 'rgba(255,255,255,0.85)',
      });
      this.add(sub);
    }

    this.setSize(cfg.w, cfg.h);
    this.setInteractive({ useHandCursor: true });
    attachPress(scene, this, cfg.onClick, () => this.enabled);
    scene.add.existing(this);
  }

  setLabel(s: string): this {
    this.label.setText(s);
    return this;
  }
}

export interface IconButtonCfg {
  x: number;
  y: number;
  size: number;
  icon: string;
  onClick: () => void;
  bg?: number;
  tint?: number;
  bgAlpha?: number;
}

export class IconButton extends Phaser.GameObjects.Container {
  readonly bg: Phaser.GameObjects.Image;
  readonly icon: Phaser.GameObjects.Image;
  enabled = true;

  constructor(scene: Phaser.Scene, cfg: IconButtonCfg) {
    super(scene, cfg.x, cfg.y);
    this.bg = scene.add
      .image(0, 0, TEX, 'circle')
      .setDisplaySize(cfg.size, cfg.size)
      .setTint(cfg.bg ?? 0x2b3a64)
      .setAlpha(cfg.bgAlpha ?? 1);
    this.icon = scene.add
      .image(0, 0, TEX, cfg.icon)
      .setDisplaySize(cfg.size * 0.56, cfg.size * 0.56)
      .setTint(cfg.tint ?? 0xffffff);
    this.add([this.bg, this.icon]);
    this.setSize(cfg.size * 1.25, cfg.size * 1.25);
    this.setInteractive({ useHandCursor: true });
    attachPress(scene, this, cfg.onClick, () => this.enabled);
    scene.add.existing(this);
  }

  setIcon(frame: string, tint?: number): this {
    this.icon.setFrame(frame);
    if (tint !== undefined) this.icon.setTint(tint);
    return this;
  }
}

/** Toggle switch rendered as a round icon button (on/off icon pair). */
export class IconToggle extends IconButton {
  private value: boolean;

  constructor(
    scene: Phaser.Scene,
    cfg: Omit<IconButtonCfg, 'icon' | 'onClick'> & {
      onIcon: string;
      offIcon: string;
      value: boolean;
      onChange: (v: boolean) => void;
    }
  ) {
    super(scene, {
      ...cfg,
      icon: cfg.value ? cfg.onIcon : cfg.offIcon,
      onClick: () => {
        this.value = !this.value;
        this.refresh(cfg.onIcon, cfg.offIcon);
        cfg.onChange(this.value);
      },
    });
    this.value = cfg.value;
    this.refresh(cfg.onIcon, cfg.offIcon);
  }

  private refresh(onIcon: string, offIcon: string): void {
    this.setIcon(this.value ? onIcon : offIcon, this.value ? 0xffffff : 0x8a95bd);
    this.bg.setTint(this.value ? 0x3f8df2 : 0x2b3a64);
  }
}
