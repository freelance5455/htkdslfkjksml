import * as THREE from 'three'
import { CONFIG } from './config'
import { groundHeight, terrainColor, terrainHeight } from './terrain'

/**
 * Streams the visible terrain as square chunks around the camera.
 *
 * Every chunk shares one index buffer and its own position/normal/colour buffers, which are
 * rewritten when the chunk is recycled for a new grid cell: the world is endless but no memory is
 * allocated while flying. Heights come from `terrainHeight`, the same function used for collision.
 */
const RES = 36

type Chunk = { mesh: THREE.Mesh; cx: number; cz: number; key: string }

export class TerrainView {
  readonly group = new THREE.Group()
  /** Chunks visible in each direction from the camera chunk. */
  radius = 3

  private readonly chunks = new Map<string, Chunk>()
  private readonly pool: Chunk[] = []
  private readonly index: THREE.BufferAttribute
  private readonly material: THREE.MeshStandardMaterial
  private readonly grid = new Float32Array((RES + 3) * (RES + 3))
  private readonly water: THREE.Mesh

  constructor() {
    // Triangle indices for a (RES+1)² vertex grid.
    const indices = new Uint16Array(RES * RES * 6)
    let k = 0
    for (let z = 0; z < RES; z += 1) {
      for (let x = 0; x < RES; x += 1) {
        const a = z * (RES + 1) + x
        const b = a + 1
        const c = a + (RES + 1)
        const d = c + 1
        // Alternate the diagonal to avoid a visible grain.
        if ((x + z) % 2 === 0) indices.set([a, c, b, b, c, d], k)
        else indices.set([a, c, d, a, d, b], k)
        k += 6
      }
    }
    this.index = new THREE.BufferAttribute(indices, 1)

    this.material = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.96, metalness: 0 })
    this.material.onBeforeCompile = shader => {
      shader.vertexShader = shader.vertexShader
        .replace('#include <common>', '#include <common>\nvarying vec3 vWorld;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;')
      shader.fragmentShader = shader.fragmentShader
        .replace('#include <common>', `#include <common>
varying vec3 vWorld;
float h21(vec2 p) { return fract(sin(dot(mod(p, 289.0), vec2(12.9898, 78.233))) * 43758.5453); }
float vn(vec2 p) {
  vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(h21(i), h21(i + vec2(1.0, 0.0)), f.x), mix(h21(i + vec2(0.0, 1.0)), h21(i + vec2(1.0, 1.0)), f.x), f.y);
}`)
        .replace('#include <color_fragment>', `#include <color_fragment>
{
  float big = vn(vWorld.xz * 0.006) * 0.6 + vn(vWorld.xz * 0.017) * 0.4;
  float n = vn(vWorld.xz * 0.045) * 0.5 + vn(vWorld.xz * 0.21) * 0.3 + vn(vWorld.xz * 1.1) * 0.2;
  diffuseColor.rgb *= (0.62 + 0.76 * n) * (0.80 + 0.40 * big);
  // Slightly deepen saturation so hillsides read as rock and soil rather than haze.
  float l = dot(diffuseColor.rgb, vec3(0.299, 0.587, 0.114));
  diffuseColor.rgb = mix(vec3(l), diffuseColor.rgb, 1.25);
}`)
        .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
{
  float camDist = length(vViewPosition);
  float fadeBump = 1.0 - smoothstep(500.0, 1500.0, camDist);
  float hh = (vn(vWorld.xz * 0.05) * 0.55 + vn(vWorld.xz * 0.19) * 0.3 + vn(vWorld.xz * 0.8) * 0.15) * 3.2 * fadeBump;
  vec3 sx = dFdx(-vViewPosition); vec3 sy = dFdy(-vViewPosition);
  vec2 dH = vec2(dFdx(hh), dFdy(hh));
  vec3 r1 = cross(sy, normal); vec3 r2 = cross(normal, sx);
  float det = dot(sx, r1);
  vec3 grad = sign(det) * (dH.x * r1 + dH.y * r2);
  normal = normalize(abs(det) * normal - grad);
}`)
    }

    const waterMaterial = new THREE.MeshStandardMaterial({ color: 0x2f7ea6, roughness: 0.18, metalness: 0.05, transparent: true, opacity: 0.88, depthWrite: false })
    this.water = new THREE.Mesh(new THREE.PlaneGeometry(14000, 14000).rotateX(-Math.PI / 2), waterMaterial)
    this.water.position.y = 5
    this.water.renderOrder = 1
    this.group.add(this.water)
  }

  private make(): Chunk {
    const geometry = new THREE.BufferGeometry()
    const n = (RES + 1) * (RES + 1)
    geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3))
    geometry.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(n * 3), 3))
    geometry.setAttribute('color', new THREE.BufferAttribute(new Float32Array(n * 3), 3))
    geometry.setIndex(this.index)
    geometry.boundingSphere = new THREE.Sphere()
    const mesh = new THREE.Mesh(geometry, this.material)
    mesh.matrixAutoUpdate = true
    this.group.add(mesh)
    return { mesh, cx: 0, cz: 0, key: '' }
  }

  /** Fill a chunk's buffers for grid cell (cx, cz). */
  private build(chunk: Chunk, cx: number, cz: number): void {
    const size = CONFIG.world.chunk
    const cell = size / RES
    const ox = cx * size
    const oz = cz * size
    const w = RES + 3
    // Heights on a grid with a one-cell border so normals match across chunk edges.
    for (let j = 0; j < w; j += 1) {
      for (let i = 0; i < w; i += 1) {
        this.grid[j * w + i] = terrainHeight(ox + (i - 1) * cell, oz + (j - 1) * cell)
      }
    }
    const geometry = chunk.mesh.geometry
    const pos = geometry.getAttribute('position') as THREE.BufferAttribute
    const nor = geometry.getAttribute('normal') as THREE.BufferAttribute
    const col = geometry.getAttribute('color') as THREE.BufferAttribute
    let minY = Infinity
    let maxY = -Infinity
    let v = 0
    for (let j = 0; j <= RES; j += 1) {
      for (let i = 0; i <= RES; i += 1) {
        const gi = (j + 1) * w + (i + 1)
        const h = this.grid[gi]
        const hl = this.grid[gi - 1]
        const hr = this.grid[gi + 1]
        const hd = this.grid[gi - w]
        const hu = this.grid[gi + w]
        const nx = hl - hr
        const nz = hd - hu
        const ny = 2 * cell
        const len = Math.hypot(nx, ny, nz)
        const wx = ox + i * cell
        const wz = oz + j * cell
        const y = Math.max(h, 3.2)
        pos.setXYZ(v, i * cell, y, j * cell)
        nor.setXYZ(v, nx / len, ny / len, nz / len)
        const c = terrainColor(wx, wz, h, ny / len)
        col.setXYZ(v, c[0], c[1], c[2])
        if (y < minY) minY = y
        if (y > maxY) maxY = y
        v += 1
      }
    }
    pos.needsUpdate = true
    nor.needsUpdate = true
    col.needsUpdate = true
    chunk.mesh.position.set(ox, 0, oz)
    chunk.mesh.updateMatrixWorld(true)
    const sphere = geometry.boundingSphere!
    sphere.center.set(size / 2, (minY + maxY) / 2, size / 2)
    sphere.radius = Math.hypot(size / 2, size / 2, (maxY - minY) / 2) + 2
    chunk.cx = cx
    chunk.cz = cz
    chunk.key = `${cx},${cz}`
    chunk.mesh.visible = true
  }

  /**
   * Make sure every chunk within `radius` of the focus point exists. At most `budget` chunks are built
   * per call so a fast flight never stalls a frame. Returns how many chunks are still missing.
   */
  update(x: number, z: number, budget = 2): number {
    const size = CONFIG.world.chunk
    const ccx = Math.floor(x / size)
    const ccz = Math.floor(z / size)
    const r = this.radius

    // Recycle chunks that fell out of range (with one chunk of hysteresis).
    for (const [key, chunk] of this.chunks) {
      if (Math.abs(chunk.cx - ccx) > r + 1 || Math.abs(chunk.cz - ccz) > r + 1) {
        chunk.mesh.visible = false
        this.chunks.delete(key)
        this.pool.push(chunk)
      }
    }

    // Collect missing cells, nearest first.
    const missing: Array<[number, number, number]> = []
    for (let dz = -r; dz <= r; dz += 1) {
      for (let dx = -r; dx <= r; dx += 1) {
        const cx = ccx + dx
        const cz = ccz + dz
        if (!this.chunks.has(`${cx},${cz}`)) missing.push([cx, cz, dx * dx + dz * dz])
      }
    }
    missing.sort((a, b) => a[2] - b[2])
    let built = 0
    for (const [cx, cz] of missing) {
      if (built >= budget) break
      const chunk = this.pool.pop() ?? this.make()
      this.build(chunk, cx, cz)
      this.chunks.set(chunk.key, chunk)
      built += 1
    }
    this.water.position.x = Math.round(x / 200) * 200
    this.water.position.z = Math.round(z / 200) * 200
    return missing.length - built
  }

  /** Build everything around a point immediately (used before the first frame). */
  warm(x: number, z: number): void {
    while (this.update(x, z, 8) > 0) { /* keep building */ }
  }

  /** Lowest allowed camera height at a location. */
  floorAt(x: number, z: number): number {
    return groundHeight(x, z)
  }
}
