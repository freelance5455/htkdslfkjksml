import { GameSaveData, RegionId } from './types';

const SAVE_KEY = 'project_behemoth_save_v1';

export const DEFAULT_SAVE: GameSaveData = {
  version: 1,
  timestamp: Date.now(),
  hunterRank: 1,
  hunterXp: 0,
  zenny: 800,
  equippedWeaponId: 'iron_greatsword',
  equippedArmor: {
    head: 'hunter_helm',
    chest: 'hunter_mail',
    arms: 'hunter_vambraces',
    legs: 'hunter_greaves',
    charm: 'rookie_charm',
  },
  inventory: [
    { itemId: 'potion', count: 5 },
    { itemId: 'mega_potion', count: 2 },
    { itemId: 'antidote', count: 3 },
    { itemId: 'well_done_steak', count: 2 },
    { itemId: 'iron_ore', count: 4 },
    { itemId: 'monster_bone', count: 3 },
  ],
  craftedEquipment: [
    'iron_greatsword',
    'iron_dualblades',
    'iron_hammer',
    'iron_longsword',
    'hunter_bow',
    'iron_lance',
    'hunter_helm',
    'hunter_mail',
    'hunter_vambraces',
    'hunter_greaves',
    'rookie_charm',
  ],
  completedQuestIds: [],
  activeQuestId: 'q_prologue',
  unlockedRegions: ['settlement', 'verdant'] as RegionId[],
  bestiaryKills: {},
  huntingRecords: {},
  settings: {
    graphicsQuality: 'high',
    soundVolume: 0.5,
    showDamageNumbers: true,
    joystickScale: 1.0,
  },
};

export class SaveSystem {
  public static load(): GameSaveData {
    if (typeof window === 'undefined') return DEFAULT_SAVE;

    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return DEFAULT_SAVE;
      const parsed = JSON.parse(raw) as Partial<GameSaveData>;

      if (!parsed.version || parsed.version < 1) {
        return DEFAULT_SAVE;
      }

      return {
        ...DEFAULT_SAVE,
        ...parsed,
        equippedArmor: {
          ...DEFAULT_SAVE.equippedArmor,
          ...(parsed.equippedArmor || {}),
        },
        settings: {
          ...DEFAULT_SAVE.settings,
          ...(parsed.settings || {}),
        },
      };
    } catch {
      return DEFAULT_SAVE;
    }
  }

  public static save(data: GameSaveData) {
    if (typeof window === 'undefined') return;

    try {
      data.timestamp = Date.now();
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    } catch {
      // Ignore quota exceeded errors safely
    }
  }

  public static reset() {
    if (typeof window === 'undefined') return;
    try {
      localStorage.removeItem(SAVE_KEY);
    } catch {
      // Ignore
    }
  }
}
