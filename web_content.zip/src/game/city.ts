export const WORLD = 360;

export type VRoad = { x: number; z1: number; z2: number; half: number };
export type HRoad = { z: number; x1: number; x2: number; half: number };
export type Bld = { x: number; z: number; w: number; d: number; h: number; wall: string; roof: string; kind: string; name?: string };
export type Pin = { x: number; z: number; name: string };

export const PINS: Record<string, Pin> = {
  bank: { x: 78, z: 52, name: "Pacific Reserve" },
  police: { x: 78, z: -52, name: "Central Precinct" },
  pizza: { x: -78, z: 52, name: "Nino Pizza" },
  hospital: { x: -78, z: -52, name: "County General" },
  mall: { x: 78, z: -156, name: "Bahia Mall" },
  casino: { x: -156, z: -78, name: "Golden Cage" },
  gas: { x: 156, z: 78, name: "Rico Fuel" },
  garage: { x: -208, z: 78, name: "Hill Garage" },
  warehouse: { x: 208, z: -78, name: "Dock Shed" },
  airport: { x: 208, z: 156, name: "Bay Airfield" },
  condo: { x: -78, z: 156, name: "Bay Condo" },
  foundry: { x: 208, z: -156, name: "Foundry" },
  pier: { x: 0, z: 268, name: "The Pier" },
  downtown: { x: 0, z: 0, name: "Downtown" },
  park: { x: -52, z: 78, name: "Marigold Park" },
  beach: { x: 52, z: 260, name: "Bahia Beach" },
  hills: { x: -260, z: 0, name: "West Hills" },
  north: { x: 0, z: -208, name: "North Residences" },
  east: { x: 260, z: 0, name: "East Industrial" },
};

const LOTS: Record<string, { x: number; z: number; wall: string; roof: string; h: number; name: string }> = {
  bank: { x: 78, z: 80, wall: "#f4efe4", roof: "#c9a227", h: 16, name: "Pacific Reserve" },
  police: { x: 78, z: -80, wall: "#dfe7f2", roof: "#1d4e89", h: 12, name: "Central Precinct" },
  pizza: { x: -78, z: 80, wall: "#ff6b4a", roof: "#f2d04b", h: 7, name: "Nino Pizza" },
  hospital: { x: -78, z: -80, wall: "#f7f7f5", roof: "#e23b4a", h: 14, name: "County General" },
  mall: { x: 78, z: -184, wall: "#7d6bff", roof: "#ffd36a", h: 18, name: "Bahia Mall" },
  casino: { x: -184, z: -78, wall: "#f2e2a8", roof: "#8f1d2c", h: 20, name: "Golden Cage" },
  gas: { x: 184, z: 78, wall: "#ffb703", roof: "#fb5607", h: 6, name: "Rico Fuel" },
  garage: { x: -234, z: 78, wall: "#6b7c8a", roof: "#243040", h: 8, name: "Hill Garage" },
  warehouse: { x: 234, z: -78, wall: "#c4b39a", roof: "#8d5a32", h: 10, name: "Dock Shed" },
  airport: { x: 234, z: 184, wall: "#e7eef5", roof: "#3d5a80", h: 9, name: "Bay Airfield" },
  condo: { x: -78, z: 184, wall: "#ffd6e0", roof: "#5ec8ff", h: 15, name: "Bay Condo" },
  foundry: { x: 234, z: -184, wall: "#b08968", roof: "#6b3e2a", h: 11, name: "Foundry" },
};

function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export type City = {
  vRoads: VRoad[];
  hRoads: HRoad[];
  buildings: Bld[];
  trees: { x: number; z: number; s: number; shade: number }[];
  lamps: { x: number; z: number }[];
  nodes: { x: number; z: number }[];
  adj: number[][];
  pins: Record<string, Pin>;
  map: HTMLCanvasElement;
  onRoad: (x: number, z: number, pad?: number) => boolean;
};

export function districtAt(x: number, z: number): string {
  if (z > 242) return "Bahia Beach";
  if (x < -200) return "West Hills";
  if (x > 170 && z < 40) return "The Foundry";
  if (x > 170) return "East Docks";
  if (Math.abs(x) < 150 && Math.abs(z) < 150) return "Downtown";
  if (z < -80) return "North Residences";
  return "Bahia Bay";
}

export function buildCity(): City {
  const rand = mulberry32(0xda4cf1);
  const vRoads: VRoad[] = [];
  const hRoads: HRoad[] = [];
  const addV = (x: number, z1: number, z2: number, half: number) => vRoads.push({ x, z1, z2, half });
  const addH = (z: number, x1: number, x2: number, half: number) => hRoads.push({ z, x1, x2, half });

  addV(0, -300, 300, 9);
  addH(0, -300, 300, 9);
  addV(130, -300, 240, 7);
  addV(-130, -300, 240, 7);
  addH(130, -300, 300, 7);
  addH(-130, -300, 240, 7);
  for (const p of [-260, -208, -156, -104, -52, 52, 104, 156, 208, 260]) {
    if (Math.abs(p) < 20 || Math.abs(Math.abs(p) - 130) < 16) continue;
    addV(p, -300, 230, 6);
    addH(p, -300, 300, 6);
  }
  addH(300, -300, 300, 11);
  addH(-300, -300, 300, 11);
  addV(300, -300, 300, 11);
  addV(-300, -300, 300, 11);

  const onRoad = (x: number, z: number, pad = 0) => {
    for (const r of vRoads) {
      if (Math.abs(x - r.x) <= r.half + pad && z >= Math.min(r.z1, r.z2) - r.half && z <= Math.max(r.z1, r.z2) + r.half) return true;
    }
    for (const r of hRoads) {
      if (Math.abs(z - r.z) <= r.half + pad && x >= Math.min(r.x1, r.x2) - r.half && x <= Math.max(r.x1, r.x2) + r.half) return true;
    }
    return false;
  };

  const buildings: Bld[] = [];
  const overlaps = (x: number, z: number, w: number, d: number) =>
    buildings.some((b) => Math.abs(b.x - x) < (b.w + w) / 2 && Math.abs(b.z - z) < (b.d + d) / 2);

  const place = (x: number, z: number, w: number, d: number, h: number, wall: string, roof: string, kind: string, name?: string) => {
    const corners: [number, number][] = [
      [x - w / 2, z - d / 2],
      [x + w / 2, z - d / 2],
      [x - w / 2, z + d / 2],
      [x + w / 2, z + d / 2],
    ];
    if (corners.some(([a, b]) => onRoad(a, b, 1.2))) return false;
    if (z > 236) return false;
    if (Math.abs(x) < 16 && z > 230) return false;
    if (overlaps(x, z, w, d)) return false;
    buildings.push({ x, z, w, d, h, wall, roof, kind, name });
    return true;
  };

  for (const [kind, lot] of Object.entries(LOTS)) {
    place(lot.x, lot.z, 20, 18, lot.h, lot.wall, lot.roof, kind, lot.name);
  }

  const walls = ["#ff6b6b", "#ffd166", "#7bdff2", "#b8f2a2", "#f7aef8", "#ffe8a3", "#90e0ef", "#ffb4a2", "#cdb4db", "#f4f1de"];
  const roofs = ["#e23b4a", "#3d5a80", "#f4a261", "#2a9d8f", "#6d597a", "#bc6c25", "#1d3557"];
  const xs = [...new Set(vRoads.map((r) => r.x))].sort((a, b) => a - b);
  const zs = [...new Set(hRoads.map((r) => r.z))].sort((a, b) => a - b);
  const halfV = (x: number) => vRoads.find((r) => r.x === x)?.half ?? 8;
  const halfH = (z: number) => hRoads.find((r) => r.z === z)?.half ?? 8;

  for (let i = 0; i < xs.length - 1; i++) {
    for (let j = 0; j < zs.length - 1; j++) {
      const x1 = xs[i]! + halfV(xs[i]!) + 3.5;
      const x2 = xs[i + 1]! - halfV(xs[i + 1]!) - 3.5;
      const z1 = zs[j]! + halfH(zs[j]!) + 3.5;
      const z2 = zs[j + 1]! - halfH(zs[j + 1]!) - 3.5;
      if (x2 - x1 < 16 || z2 - z1 < 16) continue;
      const cx = (x1 + x2) / 2;
      const cz = (z1 + z2) / 2;
      if (cz > 236) continue;
      if (cx > -52 && cx < 0 && cz > 52 && cz < 104) continue;
      const ind = cx > 170 && cz < 40;
      const hill = cx < -200;
      const down = Math.abs(cx) < 150 && Math.abs(cz) < 150;
      const bw = Math.min(ind ? 26 : 22, x2 - x1);
      const bd = Math.min(ind ? 24 : 20, z2 - z1);
      const h = hill ? 4 + rand() * 3 : ind ? 7 + rand() * 7 : down ? 8 + rand() * 18 : 5 + rand() * 5;
      const wall = walls[Math.floor(rand() * walls.length)]!;
      const roof = roofs[Math.floor(rand() * roofs.length)]!;
      place(cx, cz, bw, bd, h, wall, roof, hill ? "cabin" : ind ? "industrial" : "house");
    }
  }

  const trees: City["trees"] = [];
  const tryTree = (x: number, z: number, s: number, shade: number) => {
    if (onRoad(x, z, 1)) return;
    if (z > 300) return;
    if (buildings.some((b) => Math.abs(b.x - x) < b.w / 2 + 1.2 && Math.abs(b.z - z) < b.d / 2 + 1.2)) return;
    trees.push({ x, z, s, shade });
  };
  for (let i = 0; i < 28; i++) tryTree(-48 + rand() * 40, 58 + rand() * 40, 0.8 + rand() * 0.7, rand());
  for (let i = 0; i < 80; i++) tryTree(-340 + rand() * 160, -280 + rand() * 500, 0.7 + rand() * 0.8, rand());
  for (let i = 0; i < 50; i++) tryTree(-180 + rand() * 360, -280 + rand() * 460, 0.55 + rand() * 0.5, rand());

  const lamps: { x: number; z: number }[] = [];
  for (const r of vRoads) {
    if (r.half < 6) continue;
    for (let z = Math.min(r.z1, r.z2) + 10; z < Math.max(r.z1, r.z2); z += 42) {
      const x = r.x + r.half + 2.4;
      if (!onRoad(x, z, 0) && !buildings.some((b) => Math.abs(b.x - x) < b.w / 2 && Math.abs(b.z - z) < b.d / 2)) lamps.push({ x, z });
      if (lamps.length > 140) break;
    }
  }

  const nodes: { x: number; z: number }[] = [];
  const index = new Map<string, number>();
  const node = (x: number, z: number) => {
    const k = `${Math.round(x)}:${Math.round(z)}`;
    const hit = index.get(k);
    if (hit !== undefined) return hit;
    const id = nodes.length;
    nodes.push({ x, z });
    index.set(k, id);
    return id;
  };
  const adj: number[][] = [];
  const link = (a: number, b: number) => {
    if (a === b) return;
    while (adj.length < nodes.length) adj.push([]);
    if (!adj[a]!.includes(b)) adj[a]!.push(b);
    if (!adj[b]!.includes(a)) adj[b]!.push(a);
  };
  for (const r of vRoads) {
    const zs = [r.z1, r.z2];
    for (const h of hRoads) {
      if (h.z > Math.min(r.z1, r.z2) + 1 && h.z < Math.max(r.z1, r.z2) - 1 && r.x > Math.min(h.x1, h.x2) + 1 && r.x < Math.max(h.x1, h.x2) - 1) zs.push(h.z);
    }
    zs.sort((a, b) => a - b);
    let prev = node(r.x, zs[0]!);
    for (let i = 1; i < zs.length; i++) {
      const n = node(r.x, zs[i]!);
      if (Math.abs(zs[i]! - zs[i - 1]!) > 3) link(prev, n);
      prev = n;
    }
  }
  for (const h of hRoads) {
    const xs2 = [h.x1, h.x2];
    for (const v of vRoads) {
      if (v.x > Math.min(h.x1, h.x2) + 1 && v.x < Math.max(h.x1, h.x2) - 1 && h.z > Math.min(v.z1, v.z2) + 1 && h.z < Math.max(v.z1, v.z2) - 1) xs2.push(v.x);
    }
    xs2.sort((a, b) => a - b);
    let prev = node(xs2[0]!, h.z);
    for (let i = 1; i < xs2.length; i++) {
      const n = node(xs2[i]!, h.z);
      if (Math.abs(xs2[i]! - xs2[i - 1]!) > 3) link(prev, n);
      prev = n;
    }
  }
  while (adj.length < nodes.length) adj.push([]);

  const map = paint(vRoads, hRoads, buildings);
  return { vRoads, hRoads, buildings, trees: trees.slice(0, 150), lamps: lamps.slice(0, 120), nodes, adj, pins: PINS, map, onRoad };
}

function paint(vRoads: VRoad[], hRoads: HRoad[], buildings: Bld[]) {
  const S = 1024;
  const canvas = document.createElement("canvas");
  canvas.width = S;
  canvas.height = S;
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;
  const toX = (x: number) => ((x + WORLD) / (WORLD * 2)) * S;
  const toY = (z: number) => ((WORLD - z) / (WORLD * 2)) * S;
  const px = (m: number) => (m / (WORLD * 2)) * S;

  ctx.fillStyle = "#7dce6a";
  ctx.fillRect(0, 0, S, S);
  ctx.fillStyle = "#5eae55";
  ctx.fillRect(0, 0, toX(-200), S);
  const rect = (x1: number, z1: number, x2: number, z2: number, fill: string) => {
    const xa = toX(Math.min(x1, x2));
    const xb = toX(Math.max(x1, x2));
    const ya = toY(Math.max(z1, z2));
    const yb = toY(Math.min(z1, z2));
    ctx.fillStyle = fill;
    ctx.fillRect(xa, ya, xb - xa, yb - ya);
  };
  rect(-160, -160, 160, 160, "#e4dece");
  rect(170, -240, 340, 50, "#cbb89a");
  rect(-340, 236, 340, 314, "#f0d7a0");
  rect(-340, 314, 340, 360, "#3ec6e0");
  ctx.fillStyle = "#63c45a";
  ctx.beginPath();
  ctx.arc(toX(-26), toY(78), px(22), 0, Math.PI * 2);
  ctx.fill();

  ctx.lineCap = "square";
  const strokeRoad = (halfExtra: number, color: string) => {
    ctx.strokeStyle = color;
    ctx.beginPath();
    for (const r of vRoads) {
      ctx.lineWidth = px(r.half * 2 + halfExtra);
      ctx.moveTo(toX(r.x), toY(r.z1));
      ctx.lineTo(toX(r.x), toY(r.z2));
    }
    for (const r of hRoads) {
      ctx.lineWidth = px(r.half * 2 + halfExtra);
      ctx.moveTo(toX(r.x1), toY(r.z));
      ctx.lineTo(toX(r.x2), toY(r.z));
    }
    ctx.stroke();
  };
  // widths differ, stroke per road
  for (const r of [...vRoads.map((v) => ({ a: v.x, b: v.z1, c: v.x, d: v.z2, half: v.half })), ...hRoads.map((h) => ({ a: h.x1, b: h.z, c: h.x2, d: h.z, half: h.half }))]) {
    ctx.strokeStyle = "#f6f1e6";
    ctx.lineWidth = px(r.half * 2 + 5);
    ctx.beginPath();
    ctx.moveTo(toX(r.a), toY(r.b));
    ctx.lineTo(toX(r.c), toY(r.d));
    ctx.stroke();
  }
  for (const r of [...vRoads.map((v) => ({ a: v.x, b: v.z1, c: v.x, d: v.z2, half: v.half })), ...hRoads.map((h) => ({ a: h.x1, b: h.z, c: h.x2, d: h.z, half: h.half }))]) {
    ctx.strokeStyle = "#3c4454";
    ctx.lineWidth = px(r.half * 2);
    ctx.beginPath();
    ctx.moveTo(toX(r.a), toY(r.b));
    ctx.lineTo(toX(r.c), toY(r.d));
    ctx.stroke();
  }
  ctx.setLineDash([8, 10]);
  ctx.lineWidth = 2;
  ctx.strokeStyle = "rgba(247,244,234,0.9)";
  ctx.beginPath();
  for (const r of vRoads) {
    ctx.moveTo(toX(r.x), toY(r.z1));
    ctx.lineTo(toX(r.x), toY(r.z2));
  }
  for (const r of hRoads) {
    ctx.moveTo(toX(r.x1), toY(r.z));
    ctx.lineTo(toX(r.x2), toY(r.z));
  }
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.strokeStyle = "#a97850";
  ctx.lineWidth = px(10);
  ctx.beginPath();
  ctx.moveTo(toX(0), toY(240));
  ctx.lineTo(toX(0), toY(332));
  ctx.stroke();

  for (const b of buildings) {
    ctx.fillStyle = b.roof;
    ctx.fillRect(toX(b.x - b.w / 2), toY(b.z + b.d / 2), px(b.w), px(b.d));
  }
  void strokeRoad;
  return canvas;
}
