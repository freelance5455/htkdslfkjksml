export type ScoreEntry = {
  name: string;
  score: number;
  wave: number;
  at: number;
};

const KEY = "lumen-raid-scores-v1";
const MUTE_KEY = "lumen-raid-muted-v1";

type Store = { version: 1; entries: ScoreEntry[] };

function read(): Store {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { version: 1, entries: [] };
    const parsed = JSON.parse(raw) as Store;
    if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.entries)) {
      return { version: 1, entries: [] };
    }
    return {
      version: 1,
      entries: parsed.entries
        .filter(
          (e) =>
            e &&
            typeof e.name === "string" &&
            typeof e.score === "number" &&
            typeof e.wave === "number",
        )
        .slice(0, 10),
    };
  } catch {
    return { version: 1, entries: [] };
  }
}

function write(entries: ScoreEntry[]) {
  try {
    const payload: Store = { version: 1, entries };
    localStorage.setItem(KEY, JSON.stringify(payload));
  } catch {
    /* private mode / quota — board stays in memory for the session */
  }
}

export function loadScores(): ScoreEntry[] {
  return read().entries;
}

export function qualifies(score: number, entries: ScoreEntry[]): boolean {
  if (score <= 0) return false;
  if (entries.length < 10) return true;
  const last = entries[entries.length - 1];
  return last ? score > last.score : true;
}

export function saveScore(name: string, score: number, wave: number): ScoreEntry[] {
  const clean = name.trim().slice(0, 16) || "PILOT";
  const entries = read().entries;
  entries.push({ name: clean, score, wave, at: Date.now() });
  entries.sort((a, b) => b.score - a.score || a.at - b.at);
  const top = entries.slice(0, 10);
  write(top);
  return top;
}

export function loadMuted(): boolean {
  try {
    return localStorage.getItem(MUTE_KEY) === "1";
  } catch {
    return false;
  }
}

export function saveMuted(muted: boolean) {
  try {
    localStorage.setItem(MUTE_KEY, muted ? "1" : "0");
  } catch {
    /* ignore */
  }
}
