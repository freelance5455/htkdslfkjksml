import { PlayerState, SkillDefinition, SkillBranch, SkillId } from '../types/game';

export type { SkillDefinition, SkillBranch, SkillId };

export const SKILLS: SkillDefinition[] = [
  // --- SURVIVAL ---
  {
    id: 'vitality',
    branch: 'survival',
    nameAr: 'حيوية البقاء (Vitality)',
    descAr: 'يزيد الحد الأقصى للصحة بمقدار +20 نقطة لكل مستوى.',
    iconId: 'skill_vitality',
    maxRank: 3,
    requiredPoints: 1,
    requiredLevel: 1,
    effectType: 'maxHealth',
    effectValuePerRank: 20,
  },
  {
    id: 'endurance',
    branch: 'survival',
    nameAr: 'طاقة التحمل (Endurance)',
    descAr: 'يزيد الحد الأقصى لطاقة التحمل (Stamina) بمقدار +25 نقطة.',
    iconId: 'skill_endurance',
    maxRank: 3,
    requiredPoints: 1,
    requiredLevel: 2,
    prerequisiteId: 'vitality',
    effectType: 'maxEnergy',
    effectValuePerRank: 25,
  },
  {
    id: 'iron_stomach',
    branch: 'survival',
    nameAr: 'المعدة الفولاذية (Iron Stomach)',
    descAr: 'يقلل معدل استهلاك الجوع بنسبة 20% لكل مستوى.',
    iconId: 'skill_hunger',
    maxRank: 2,
    requiredPoints: 1,
    requiredLevel: 3,
    prerequisiteId: 'endurance',
    effectType: 'hungerEfficiency',
    effectValuePerRank: 0.2,
  },
  {
    id: 'thick_skin',
    branch: 'survival',
    nameAr: 'الدرع الطبيعي (Thick Skin)',
    descAr: 'تقليل كافة الأضرار المتلقاة بنسبة 15% لكل مستوى.',
    iconId: 'skill_resistance',
    maxRank: 2,
    requiredPoints: 2,
    requiredLevel: 5,
    prerequisiteId: 'iron_stomach',
    effectType: 'damageResistance',
    effectValuePerRank: 0.15,
  },

  // --- COMBAT ---
  {
    id: 'heavy_strike',
    branch: 'combat',
    nameAr: 'الضربة القاطعة (Heavy Strike)',
    descAr: 'يزيد ضرر جميع الأسلحة والأدوات بمقدار +25%.',
    iconId: 'skill_damage',
    maxRank: 3,
    requiredPoints: 1,
    requiredLevel: 1,
    effectType: 'weaponDamage',
    effectValuePerRank: 0.25,
  },
  {
    id: 'critical_strike',
    branch: 'combat',
    nameAr: 'الدقة القاتلة (Critical Precision)',
    descAr: 'يزيد فرصة الضربة الحرجة (Critical Hit) بنسبة +15% لتسديد ضعف الضرر.',
    iconId: 'skill_critical',
    maxRank: 3,
    requiredPoints: 1,
    requiredLevel: 2,
    prerequisiteId: 'heavy_strike',
    effectType: 'critChance',
    effectValuePerRank: 0.15,
  },
  {
    id: 'swift_blade',
    branch: 'combat',
    nameAr: 'سرعة الهجوم (Swift Blade)',
    descAr: 'يقلل فترة الانتظار بين الضربات بنسبة 20%.',
    iconId: 'skill_attackspeed',
    maxRank: 2,
    requiredPoints: 1,
    requiredLevel: 3,
    prerequisiteId: 'heavy_strike',
    effectType: 'attackCooldown',
    effectValuePerRank: 0.2,
  },
  {
    id: 'nimble_dodge',
    branch: 'combat',
    nameAr: 'المراوغة الخاطفة (Nimble Dodge)',
    descAr: 'يقلل تكلفة الطاقة لحركة التفادي (Dodge) بنسبة 35% ويزيد مسافة التدحرج.',
    iconId: 'skill_dodge',
    maxRank: 2,
    requiredPoints: 2,
    requiredLevel: 4,
    prerequisiteId: 'critical_strike',
    effectType: 'dodgeEfficiency',
    effectValuePerRank: 0.35,
  },

  // --- EXPLORATION ---
  {
    id: 'pathfinder',
    branch: 'exploration',
    nameAr: 'المستكشف السريع (Pathfinder)',
    descAr: 'يزيد سرعة المشي الأساسية بنسبة +12% لكل مستوى.',
    iconId: 'skill_speed',
    maxRank: 3,
    requiredPoints: 1,
    requiredLevel: 1,
    effectType: 'moveSpeed',
    effectValuePerRank: 0.12,
  },
  {
    id: 'marathon_runner',
    branch: 'exploration',
    nameAr: 'عداء المسافات (Marathon Runner)',
    descAr: 'يقلل استنزاف الطاقة أثناء الركض بنسبة 30% لكل مستوى.',
    iconId: 'skill_sprint',
    maxRank: 2,
    requiredPoints: 1,
    requiredLevel: 2,
    prerequisiteId: 'pathfinder',
    effectType: 'sprintEfficiency',
    effectValuePerRank: 0.3,
  },
  {
    id: 'keen_vision',
    branch: 'exploration',
    nameAr: 'الرؤية الثاقبة (Keen Vision)',
    descAr: 'يزيد مدى إضاءة الشعلة ويكشف الكائنات والموارد من مسافة أبعد.',
    iconId: 'skill_vision',
    maxRank: 2,
    requiredPoints: 1,
    requiredLevel: 3,
    prerequisiteId: 'pathfinder',
    effectType: 'lightRadius',
    effectValuePerRank: 30,
  },
  {
    id: 'treasure_hunter',
    branch: 'exploration',
    nameAr: 'صائد الآثار (Treasure Hunter)',
    descAr: 'يكشف أماكن الصناديق المخفية ومواقع الآثار والأحداث النادرة.',
    iconId: 'skill_treasure',
    maxRank: 1,
    requiredPoints: 2,
    requiredLevel: 4,
    prerequisiteId: 'keen_vision',
    effectType: 'treasureSense',
    effectValuePerRank: 1,
  },

  // --- GATHERING ---
  {
    id: 'lumberjack',
    branch: 'gathering',
    nameAr: 'الحطاب الماهر (Lumberjack)',
    descAr: 'يزيد قوة قطع الأشجار وسرعة جمع الخشب بنسبة +50%.',
    iconId: 'skill_wood',
    maxRank: 3,
    requiredPoints: 1,
    requiredLevel: 1,
    effectType: 'woodcuttingPower',
    effectValuePerRank: 0.5,
  },
  {
    id: 'master_miner',
    branch: 'gathering',
    nameAr: 'خبير التعدين (Master Miner)',
    descAr: 'يزيد قوة تكسير الصخور وسرعة استخراج الحجر والمعادن بنسبة +50%.',
    iconId: 'skill_mining',
    maxRank: 3,
    requiredPoints: 1,
    requiredLevel: 1,
    effectType: 'miningPower',
    effectValuePerRank: 0.5,
  },
  {
    id: 'bountiful_yield',
    branch: 'gathering',
    nameAr: 'وفرة المحصول (Bountiful Yield)',
    descAr: 'فرصة 40% للحصول على موارد إضافية مضاعفة عند جمع الأشجار والصخور.',
    iconId: 'skill_yield',
    maxRank: 2,
    requiredPoints: 2,
    requiredLevel: 3,
    prerequisiteId: 'lumberjack',
    effectType: 'extraLootChance',
    effectValuePerRank: 0.4,
  },
  {
    id: 'lucky_prospector',
    branch: 'gathering',
    nameAr: 'التنقيب المحظوظ (Lucky Prospector)',
    descAr: 'يزيد فرصة العثور على خامات نادرة (حديد، فحم، بلورات) بنسبة +25%.',
    iconId: 'skill_rare_ore',
    maxRank: 2,
    requiredPoints: 2,
    requiredLevel: 4,
    prerequisiteId: 'master_miner',
    effectType: 'rareOreChance',
    effectValuePerRank: 0.25,
  },

  // --- CRAFTING ---
  {
    id: 'frugal_crafting',
    branch: 'crafting',
    nameAr: 'التوفير الحرفي (Frugal Crafting)',
    descAr: 'فرصة 30% لاستعادة جزء من المواد الخام عند صناعة الأدوات والمعدات.',
    iconId: 'skill_frugal',
    maxRank: 2,
    requiredPoints: 1,
    requiredLevel: 2,
    effectType: 'materialRefund',
    effectValuePerRank: 0.3,
  },
  {
    id: 'reinforced_tools',
    branch: 'crafting',
    nameAr: 'متانة الأدوات (Tool Durability)',
    descAr: 'يزيد عمر ومتانة جميع الأدوات والأسلحة المصنوعة بنسبة +50%.',
    iconId: 'skill_durability',
    maxRank: 3,
    requiredPoints: 1,
    requiredLevel: 1,
    effectType: 'toolDurability',
    effectValuePerRank: 0.5,
  },
  {
    id: 'fortified_walls',
    branch: 'crafting',
    nameAr: 'البناء المحصن (Fortified Structures)',
    descAr: 'يزيد صحة وتحمل الجدران والأبواب والمباني بنسبة +60%.',
    iconId: 'skill_building',
    maxRank: 2,
    requiredPoints: 2,
    requiredLevel: 3,
    prerequisiteId: 'reinforced_tools',
    effectType: 'buildingHealth',
    effectValuePerRank: 0.6,
  },

  // --- AQUATIC ---
  {
    id: 'swimmer_lungs',
    branch: 'aquatic',
    nameAr: 'رئة الغواص (Swimmer Lungs)',
    descAr: 'يقلل استهلاك طاقة التحمل أثناء السباحة في الماء بنسبة 40%.',
    iconId: 'skill_swim_stamina',
    maxRank: 2,
    requiredPoints: 1,
    requiredLevel: 1,
    effectType: 'swimStamina',
    effectValuePerRank: 0.4,
  },
  {
    id: 'swift_fin',
    branch: 'aquatic',
    nameAr: 'الزعانف الرشيقة (Swift Fin)',
    descAr: 'يزيد سرعة الحركة داخل الماء بنسبة +35%.',
    iconId: 'skill_swim_speed',
    maxRank: 2,
    requiredPoints: 1,
    requiredLevel: 2,
    prerequisiteId: 'swimmer_lungs',
    effectType: 'swimSpeed',
    effectValuePerRank: 0.35,
  },
  {
    id: 'aquatic_hunter',
    branch: 'aquatic',
    nameAr: 'صياد الأسماك (Fish Harvester)',
    descAr: 'يتيح صيد الأسماك والحصول على موارد مائية غذائية عالية القيمة.',
    iconId: 'skill_fishing',
    maxRank: 1,
    requiredPoints: 2,
    requiredLevel: 3,
    prerequisiteId: 'swift_fin',
    effectType: 'fishMastery',
    effectValuePerRank: 1,
  },
];

// Helper functions for reading skills
export function getSkillRank(player: PlayerState, skillId: string): number {
  return player.skills?.[skillId] || 0;
}

export function getSkillEffect(player: PlayerState, effectType: string): number {
  let total = 0;
  for (const skill of SKILLS) {
    if (skill.effectType === effectType) {
      const rank = getSkillRank(player, skill.id);
      total += rank * skill.effectValuePerRank;
    }
  }
  return total;
}

export function canUnlockSkill(player: PlayerState, skillId: string): { can: boolean; reason?: string } {
  const def = SKILLS.find((s) => s.id === skillId);
  if (!def) return { can: false, reason: 'المهارة غير موجودة' };

  const currentRank = getSkillRank(player, def.id);
  if (currentRank >= def.maxRank) {
    return { can: false, reason: 'وصلت للمستوى الأقصى' };
  }

  if (player.level < def.requiredLevel) {
    return { can: false, reason: `تتطلب المستوى ${def.requiredLevel}` };
  }

  if (player.skillPoints < def.requiredPoints) {
    return { can: false, reason: `تحتاج ${def.requiredPoints} نقطة مهارة` };
  }

  if (def.prerequisiteId) {
    const prereqRank = getSkillRank(player, def.prerequisiteId);
    if (prereqRank <= 0) {
      const prereqDef = SKILLS.find((s) => s.id === def.prerequisiteId);
      return { can: false, reason: `تتطلب فتح مهارة: ${prereqDef?.nameAr || def.prerequisiteId}` };
    }
  }

  return { can: true };
}

export function unlockSkill(player: PlayerState, skillId: string): boolean {
  const check = canUnlockSkill(player, skillId);
  if (!check.can) return false;

  const def = SKILLS.find((s) => s.id === skillId)!;
  player.skillPoints -= def.requiredPoints;
  const currentRank = getSkillRank(player, def.id);
  player.skills[def.id] = currentRank + 1;

  // Apply instantaneous stat changes if applicable
  if (def.effectType === 'maxHealth') {
    player.maxHealth += def.effectValuePerRank;
    player.health += def.effectValuePerRank;
  }
  if (def.effectType === 'maxEnergy') {
    player.maxEnergy += def.effectValuePerRank;
    player.energy += def.effectValuePerRank;
  }

  return true;
}
