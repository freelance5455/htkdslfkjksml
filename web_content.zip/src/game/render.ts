import {
  FAIL_COVERAGE,
  PAINT_COLS,
  PAINT_ROWS,
  PALETTE,
  POLVO_SIZE,
  START_COVERAGE_GRACE,
  STAIN_SIZE,
} from './config'
import { paintColor, type GameState } from './state'

export type Images = {
  bgAtelier: HTMLImageElement | null
  bgResult: HTMLImageElement | null
  polvo: HTMLImageElement | null
  stain: HTMLImageElement | null
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
): void {
  const rr = Math.min(r, w / 2, h / 2)
  ctx.beginPath()
  ctx.moveTo(x + rr, y)
  ctx.arcTo(x + w, y, x + w, y + h, rr)
  ctx.arcTo(x + w, y + h, x, y + h, rr)
  ctx.arcTo(x, y + h, x, y, rr)
  ctx.arcTo(x, y, x + w, y, rr)
  ctx.closePath()
}

function drawPixelBg(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement | null,
  w: number,
  h: number,
  fallback: string,
): void {
  if (img && img.complete && img.naturalWidth > 0) {
    // cover
    const ir = img.naturalWidth / img.naturalHeight
    const cr = w / h
    let dw = w
    let dh = h
    let dx = 0
    let dy = 0
    if (ir > cr) {
      dw = h * ir
      dx = (w - dw) / 2
    } else {
      dh = w / ir
      dy = (h - dh) / 2
    }
    ctx.imageSmoothingEnabled = false
    ctx.drawImage(img, dx, dy, dw, dh)
  } else {
    ctx.fillStyle = fallback
    ctx.fillRect(0, 0, w, h)
  }
}

function drawPaintLayer(ctx: CanvasRenderingContext2D, state: GameState): void {
  const cellW = state.w / PAINT_COLS
  const cellH = state.h / PAINT_ROWS
  const color = paintColor(state)
  // Slight overlap kills hairline gaps between cells on non-integer sizes.
  const overlapX = Math.max(1, Math.ceil(cellW * 0.15))
  const overlapY = Math.max(1, Math.ceil(cellH * 0.15))
  for (let cy = 0; cy < PAINT_ROWS; cy++) {
    for (let cx = 0; cx < PAINT_COLS; cx++) {
      const v = state.grid[cy * PAINT_COLS + cx]
      if (v === 0) continue
      const x = Math.floor(cx * cellW)
      const y = Math.floor(cy * cellH)
      const w = Math.ceil(cellW) + overlapX
      const h = Math.ceil(cellH) + overlapY
      if (v === 1) {
        ctx.fillStyle = color
        ctx.globalAlpha = 0.88
        ctx.fillRect(x, y, w, h)
      } else {
        ctx.fillStyle = PALETTE.stain
        ctx.globalAlpha = 0.92
        ctx.fillRect(x, y, w, h)
      }
    }
  }
  ctx.globalAlpha = 1
}

function drawParticles(ctx: CanvasRenderingContext2D, state: GameState): void {
  for (const p of state.particles) {
    ctx.globalAlpha = Math.max(0, p.life / p.maxLife)
    ctx.fillStyle = p.color
    const s = p.size
    ctx.fillRect(Math.round(p.x - s / 2), Math.round(p.y - s / 2), Math.round(s), Math.round(s))
  }
  ctx.globalAlpha = 1
}

function drawFloaters(ctx: CanvasRenderingContext2D, state: GameState): void {
  ctx.textAlign = 'center'
  ctx.font = 'bold 16px "Press Start 2P", monospace, system-ui'
  for (const f of state.floaters) {
    ctx.globalAlpha = Math.max(0, f.life / f.maxLife)
    ctx.fillStyle = f.color
    ctx.fillText(f.text, Math.round(f.x), Math.round(f.y))
  }
  ctx.globalAlpha = 1
}

function drawPolvo(ctx: CanvasRenderingContext2D, state: GameState, img: HTMLImageElement | null): void {
  const bob = Math.sin(state.polvo.bob) * 3
  const x = Math.round(state.polvo.x)
  const y = Math.round(state.polvo.y + bob)
  const s = POLVO_SIZE
  ctx.imageSmoothingEnabled = false
  if (img && img.complete && img.naturalWidth > 0) {
    ctx.drawImage(img, x - s / 2, y - s / 2, s, s)
  } else {
    // fallback blob
    ctx.fillStyle = '#d46bb8'
    ctx.beginPath()
    ctx.arc(x, y, s * 0.35, 0, Math.PI * 2)
    ctx.fill()
    ctx.fillStyle = '#fff'
    ctx.beginPath()
    ctx.arc(x - 8, y - 6, 5, 0, Math.PI * 2)
    ctx.arc(x + 8, y - 6, 5, 0, Math.PI * 2)
    ctx.fill()
    ctx.fillStyle = '#222'
    ctx.beginPath()
    ctx.arc(x - 8, y - 6, 2, 0, Math.PI * 2)
    ctx.arc(x + 8, y - 6, 2, 0, Math.PI * 2)
    ctx.fill()
  }
  // brush tip glow while dragging
  if (state.dragging && state.phase === 'playing') {
    ctx.globalAlpha = 0.35
    ctx.fillStyle = paintColor(state)
    ctx.beginPath()
    ctx.arc(x, y + 10, 18, 0, Math.PI * 2)
    ctx.fill()
    ctx.globalAlpha = 1
  }
}

function drawStains(ctx: CanvasRenderingContext2D, state: GameState, img: HTMLImageElement | null): void {
  ctx.imageSmoothingEnabled = false
  for (const s of state.stains) {
    const size = STAIN_SIZE * (0.9 + Math.sin(s.age * 6) * 0.08)
    const x = Math.round(s.x - size / 2)
    const y = Math.round(s.y - size / 2)
    if (s.flash > 0) {
      ctx.globalAlpha = 0.5 + s.flash
      ctx.globalCompositeOperation = 'lighter'
    }
    if (img && img.complete && img.naturalWidth > 0) {
      ctx.drawImage(img, x, y, size, size)
    } else {
      ctx.fillStyle = '#3d1a5c'
      ctx.beginPath()
      ctx.arc(s.x, s.y, size * 0.4, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.globalCompositeOperation = 'source-over'
    ctx.globalAlpha = 1
  }
}

function drawHud(ctx: CanvasRenderingContext2D, state: GameState): void {
  // Keep HUD below typical notch / status bar.
  const y0 = 52

  // score pill
  ctx.textAlign = 'left'
  ctx.font = 'bold 14px monospace, system-ui'
  const scoreLabel = `PTS ${Math.round(state.displayScore)}`
  const scoreW = Math.max(88, ctx.measureText(scoreLabel).width + 20)
  ctx.fillStyle = PALETTE.barBg
  roundRect(ctx, 12, y0 - 6, scoreW, 28, 8)
  ctx.fill()
  ctx.fillStyle = PALETTE.hud
  ctx.fillText(scoreLabel, 22, y0 + 14)

  // combo
  if (state.combo > 1) {
    ctx.fillStyle = PALETTE.barBg
    roundRect(ctx, 12, y0 + 28, 52, 24, 8)
    ctx.fill()
    ctx.fillStyle = PALETTE.paintGold
    ctx.font = 'bold 14px monospace, system-ui'
    ctx.fillText(`x${state.combo}`, 22, y0 + 45)
  }

  // coverage bar
  const barW = Math.min(160, state.w * 0.4)
  const barH = 14
  const bx = state.w - barW - 12
  const by = y0
  ctx.fillStyle = PALETTE.barBg
  roundRect(ctx, bx - 8, by - 6, barW + 16, 40, 8)
  ctx.fill()
  roundRect(ctx, bx, by, barW, barH, 4)
  ctx.fillStyle = 'rgba(0,0,0,0.35)'
  ctx.fill()
  const cov = Math.max(0, Math.min(1, state.coverage))
  const fillColor =
    cov < FAIL_COVERAGE + 0.05
      ? PALETTE.danger
      : cov < 0.4
        ? PALETTE.paintGold
        : PALETTE.good
  ctx.fillStyle = fillColor
  roundRect(ctx, bx, by, Math.max(2, barW * cov), barH, 4)
  ctx.fill()
  ctx.strokeStyle = PALETTE.hud
  ctx.lineWidth = 1
  roundRect(ctx, bx, by, barW, barH, 4)
  ctx.stroke()

  ctx.textAlign = 'right'
  ctx.fillStyle = PALETTE.hud
  ctx.font = '11px monospace, system-ui'
  ctx.fillText(`COBERTURA ${Math.round(cov * 100)}%`, bx + barW, by + barH + 14)

  // grace hint
  if (state.elapsed < START_COVERAGE_GRACE) {
    ctx.textAlign = 'center'
    ctx.fillStyle = PALETTE.hud
    ctx.font = '12px monospace, system-ui'
    ctx.globalAlpha = 0.85
    ctx.fillText('Arraste e pinte a tela!', state.w / 2, y0 + 70)
    ctx.globalAlpha = 1
  }
}

function drawTitle(ctx: CanvasRenderingContext2D, state: GameState): void {
  const { w, h } = state
  ctx.fillStyle = PALETTE.overlay
  ctx.fillRect(0, 0, w, h)

  const pulse = 1 + Math.sin(state.titlePulse * 2.4) * 0.04
  ctx.save()
  ctx.translate(w / 2, h * 0.28)
  ctx.scale(pulse, pulse)
  ctx.textAlign = 'center'
  ctx.fillStyle = PALETTE.paint
  ctx.font = 'bold 34px monospace, system-ui'
  ctx.fillText('POLVO', 0, 0)
  ctx.fillStyle = PALETTE.paintAlt
  ctx.fillText('PINTOR', 0, 36)
  ctx.restore()

  ctx.textAlign = 'center'
  ctx.fillStyle = PALETTE.hud
  ctx.font = '13px monospace, system-ui'
  const blink = Math.sin(state.titlePulse * 4) > 0
  if (blink) ctx.fillText('TOQUE PARA PINTAR', w / 2, h * 0.72)

  ctx.fillStyle = PALETTE.hudDim
  ctx.font = '11px monospace, system-ui'
  ctx.fillText('Arraste o polvo · cubra a tela', w / 2, h * 0.72 + 24)
  ctx.fillText('Fuja das manchas inimigas!', w / 2, h * 0.72 + 42)

  if (state.best > 0) {
    ctx.fillStyle = PALETTE.paintGold
    ctx.fillText(`RECORDE ${state.best}`, w / 2, h * 0.72 + 68)
  }
}

function drawEnded(ctx: CanvasRenderingContext2D, state: GameState): void {
  const { w, h } = state
  ctx.fillStyle = PALETTE.overlay
  ctx.fillRect(0, 0, w, h)

  if (state.endFlash > 0) {
    ctx.globalAlpha = state.endFlash * 0.5
    ctx.fillStyle = '#fff'
    ctx.fillRect(0, 0, w, h)
    ctx.globalAlpha = 1
  }

  ctx.textAlign = 'center'
  ctx.fillStyle = PALETTE.danger
  ctx.font = 'bold 28px monospace, system-ui'
  ctx.fillText('FIM DE TINTA!', w / 2, h * 0.3)

  ctx.fillStyle = PALETTE.hud
  ctx.font = '16px monospace, system-ui'
  ctx.fillText(`PONTOS  ${Math.round(state.score)}`, w / 2, h * 0.42)
  ctx.fillStyle = PALETTE.paintGold
  ctx.fillText(`RECORDE  ${state.best}`, w / 2, h * 0.42 + 28)

  ctx.fillStyle = PALETTE.hudDim
  ctx.font = '12px monospace, system-ui'
  ctx.fillText(`Cobertura final ${Math.round(state.coverage * 100)}%`, w / 2, h * 0.42 + 56)

  const blink = Math.sin(state.titlePulse * 4) > 0
  if (blink) {
    ctx.fillStyle = PALETTE.hud
    ctx.font = '13px monospace, system-ui'
    ctx.fillText('TOQUE PARA RECOMEÇAR', w / 2, h * 0.68)
  }
}

export function render(
  ctx: CanvasRenderingContext2D,
  state: GameState,
  images: Images,
): void {
  const { w, h } = state
  if (w <= 0 || h <= 0) return

  const shake = state.trauma * state.trauma * 14
  const ox = shake > 0 ? (Math.random() - 0.5) * shake : 0
  const oy = shake > 0 ? (Math.random() - 0.5) * shake : 0

  ctx.save()
  ctx.translate(ox, oy)

  const bg =
    state.phase === 'ended' ? images.bgResult : images.bgAtelier
  drawPixelBg(ctx, bg, w, h, PALETTE.canvasBase)

  // soft canvas panel
  ctx.fillStyle = 'rgba(243, 231, 211, 0.35)'
  ctx.fillRect(0, 0, w, h)

  if (state.phase !== 'title') {
    drawPaintLayer(ctx, state)
    drawStains(ctx, state, images.stain)
  } else {
    // decorative idle paint dots on title
    ctx.globalAlpha = 0.25
    for (let i = 0; i < 8; i++) {
      const t = state.titlePulse * 0.4 + i
      ctx.fillStyle = i % 2 ? PALETTE.paint : PALETTE.paintAlt
      ctx.fillRect(
        Math.round(((Math.sin(t) + 1) * 0.5) * (w - 40) + 20),
        Math.round(((Math.cos(t * 1.3 + i) + 1) * 0.5) * (h - 80) + 40),
        8,
        8,
      )
    }
    ctx.globalAlpha = 1
  }

  drawParticles(ctx, state)
  drawPolvo(ctx, state, images.polvo)
  drawFloaters(ctx, state)

  ctx.restore()

  if (state.phase === 'playing') drawHud(ctx, state)
  if (state.phase === 'title') drawTitle(ctx, state)
  if (state.phase === 'ended') drawEnded(ctx, state)
}
