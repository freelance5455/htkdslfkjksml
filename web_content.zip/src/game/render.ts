import type { Car } from "../data/game";
import type { Phase, World } from "./world";

const VOLT = "201, 250, 60";

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h - radius);
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
  ctx.lineTo(x + radius, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

/* ------------------------------------------------------------------ */
/* Environment                                                         */
/* ------------------------------------------------------------------ */

function drawBackground(ctx: CanvasRenderingContext2D, world: World) {
  const { w, h, roadX, roadW } = world.layout;
  const bg = ctx.createLinearGradient(0, 0, w, h);
  bg.addColorStop(0, "#070a08");
  bg.addColorStop(0.45, "#0a0e0b");
  bg.addColorStop(1, "#060806");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  const ambient = ctx.createRadialGradient(w / 2, h * 0.35, 10, w / 2, h * 0.35, w * 0.7);
  ambient.addColorStop(0, "rgba(108, 148, 54, 0.10)");
  ambient.addColorStop(1, "rgba(108, 148, 54, 0)");
  ctx.fillStyle = ambient;
  ctx.fillRect(0, 0, w, h);

  // Scattered shoulder texture that travels with the road.
  const offset = world.roadOffset;
  for (let i = 0; i < 26; i += 1) {
    const y = ((i * 89 + offset * 0.55) % (h + 180)) - 90;
    const side = i % 2 === 0;
    const x = side ? 8 + ((i * 37) % Math.max(12, roadX - 20)) : roadX + roadW + 10 + ((i * 29) % Math.max(12, w - roadX - roadW - 24));
    const alpha = 0.04 + (i % 4) * 0.012;
    ctx.fillStyle = `rgba(201, 250, 60, ${alpha})`;
    ctx.fillRect(x, y, 6 + (i % 5) * 4, 2);
  }

  // Street lights + pooling glow.
  const spacing = 230;
  const count = Math.ceil(h / spacing) + 2;
  for (let i = 0; i < count; i += 1) {
    const y = ((i * spacing + offset * 0.9) % (h + spacing * 2)) - spacing;
    [roadX - 16, roadX + roadW + 16].forEach((x, index) => {
      if (x < 6 || x > w - 6) return;
      const pool = ctx.createRadialGradient(x, y, 0, x, y, 44);
      pool.addColorStop(0, index === 0 ? "rgba(201, 250, 60, 0.10)" : "rgba(201, 250, 60, 0.08)");
      pool.addColorStop(1, "rgba(201, 250, 60, 0)");
      ctx.fillStyle = pool;
      ctx.beginPath();
      ctx.arc(x, y, 44, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "rgba(8, 11, 8, 0.95)";
      ctx.fillRect(x - 2, y - 6, 4, 12);
      ctx.shadowColor = "rgba(201, 250, 60, 0.8)";
      ctx.shadowBlur = 9;
      ctx.fillStyle = "#d9ff7a";
      ctx.fillRect(x - 1.5, y - 3, 3, 6);
      ctx.shadowBlur = 0;
    });
  }

  // Distant signage on wide screens.
  if (roadX > 96) {
    const billboardY = ((world.roadOffset * 0.6 + 130) % (h + 420)) - 210;
    ctx.save();
    ctx.globalAlpha = 0.8;
    ctx.translate(roadX - 52, billboardY);
    ctx.fillStyle = "rgba(12, 17, 11, 0.9)";
    roundRect(ctx, -32, -18, 64, 36, 4);
    ctx.fill();
    ctx.strokeStyle = "rgba(201, 250, 60, 0.32)";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = "rgba(201, 250, 60, 0.85)";
    ctx.font = "600 9px 'JetBrains Mono', monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("VANTA", 0, -5);
    ctx.fillStyle = "rgba(226, 240, 200, 0.4)";
    ctx.font = "500 6px 'JetBrains Mono', monospace";
    ctx.fillText("NIGHT DIVISION", 0, 7);
    ctx.restore();
  }
}

function drawRoad(ctx: CanvasRenderingContext2D, world: World) {
  const { w, h, roadX, roadW, laneW } = world.layout;
  const offset = world.roadOffset;

  // Gravel shoulders.
  const shoulderL = ctx.createLinearGradient(roadX - 22, 0, roadX, 0);
  shoulderL.addColorStop(0, "rgba(10, 13, 10, 0)");
  shoulderL.addColorStop(1, "rgba(24, 29, 22, 0.85)");
  ctx.fillStyle = shoulderL;
  ctx.fillRect(roadX - 22, 0, 22, h);
  ctx.save();
  ctx.translate(roadX + roadW, 0);
  ctx.scale(-1, 1);
  ctx.fillStyle = shoulderL;
  ctx.fillRect(-22, 0, 22, h);
  ctx.restore();

  // Asphalt.
  const asphalt = ctx.createLinearGradient(roadX, 0, roadX + roadW, 0);
  asphalt.addColorStop(0, "#141716");
  asphalt.addColorStop(0.16, "#1b1f1e");
  asphalt.addColorStop(0.5, "#212524");
  asphalt.addColorStop(0.84, "#1b1f1e");
  asphalt.addColorStop(1, "#141716");
  ctx.fillStyle = asphalt;
  ctx.fillRect(roadX, -2, roadW, h + 4);

  ctx.save();
  ctx.beginPath();
  ctx.rect(roadX, 0, roadW, h);
  ctx.clip();

  // Tarmac variation, sealed cracks and patches.
  for (let i = 0; i < 18; i += 1) {
    const y = ((i * 97 + offset * 0.75) % (h + 200)) - 100;
    const shade = i % 3 === 0 ? 0.05 : 0.03;
    ctx.fillStyle = i % 2 === 0 ? `rgba(255, 255, 255, ${shade * 0.35})` : `rgba(0, 0, 0, ${shade})`;
    ctx.fillRect(roadX + 8, y, roadW - 16, 1.5);
  }
  for (let i = 0; i < 7; i += 1) {
    const y = ((i * 241 + offset * 0.7) % (h + 300)) - 150;
    const x = roadX + ((i * 137) % Math.max(30, roadW - 100));
    ctx.fillStyle = "rgba(0, 0, 0, 0.16)";
    roundRect(ctx, x, y, 62 + (i % 4) * 26, 26, 12);
    ctx.fill();
  }

  // Drive-line sheen.
  for (let lane = 0; lane < 4; lane += 1) {
    const cx = roadX + laneW * (lane + 0.5);
    const sheen = ctx.createLinearGradient(cx - laneW * 0.24, 0, cx + laneW * 0.24, 0);
    sheen.addColorStop(0, "rgba(255, 255, 255, 0)");
    sheen.addColorStop(0.5, "rgba(220, 236, 214, 0.025)");
    sheen.addColorStop(1, "rgba(255, 255, 255, 0)");
    ctx.fillStyle = sheen;
    ctx.fillRect(cx - laneW * 0.24, 0, laneW * 0.48, h);
  }

  // Lane dividers.
  const dashPeriod = 112;
  const dashLen = 46;
  const shift = offset % dashPeriod;
  for (let lane = 1; lane < 4; lane += 1) {
    const x = roadX + laneW * lane;
    for (let y = -dashPeriod + shift; y < h + dashPeriod; y += dashPeriod) {
      ctx.fillStyle = "rgba(226, 235, 219, 0.34)";
      roundRect(ctx, x - 1.6, y, 3.2, dashLen, 2);
      ctx.fill();
    }
  }

  // Solid edge lines.
  ctx.shadowColor = `rgba(${VOLT}, 0.55)`;
  ctx.shadowBlur = 12;
  ctx.fillStyle = `rgba(${VOLT}, 0.62)`;
  ctx.fillRect(roadX + 7, 0, 3, h);
  ctx.fillRect(roadX + roadW - 10, 0, 3, h);
  ctx.shadowBlur = 0;

  // Chevron hazard strips on the shoulder edge.
  const hazardPeriod = 52;
  const hazardShift = offset % hazardPeriod;
  for (let y = -hazardPeriod + hazardShift; y < h + hazardPeriod; y += hazardPeriod) {
    ctx.fillStyle = "rgba(201, 250, 60, 0.16)";
    ctx.fillRect(roadX - 6, y, 5, 20);
    ctx.fillRect(roadX + roadW + 1, y, 5, 20);
  }
  ctx.restore();

  // Moving light wash across the tarmac.
  const wash = ctx.createLinearGradient(0, h * 0.2, 0, h);
  wash.addColorStop(0, "rgba(201, 250, 60, 0)");
  wash.addColorStop(1, "rgba(201, 250, 60, 0.045)");
  ctx.fillStyle = wash;
  ctx.fillRect(roadX, 0, roadW, h);
  void w;
}

/* ------------------------------------------------------------------ */
/* Vehicles                                                            */
/* ------------------------------------------------------------------ */

type CarPaint = { body: string; bodyLight: string; bodyDark?: string; accent: string };

function carBodyPath(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const hw = w / 2;
  const hh = h / 2;
  ctx.beginPath();
  ctx.moveTo(-hw * 0.62, -hh);
  ctx.quadraticCurveTo(0, -hh - h * 0.035, hw * 0.62, -hh);
  ctx.quadraticCurveTo(hw, -hh * 0.86, hw, -hh * 0.32);
  ctx.lineTo(hw * 0.94, hh * 0.56);
  ctx.quadraticCurveTo(hw * 0.92, hh, hw * 0.6, hh);
  ctx.lineTo(-hw * 0.6, hh);
  ctx.quadraticCurveTo(-hw * 0.92, hh, -hw * 0.94, hh * 0.56);
  ctx.lineTo(-hw, -hh * 0.32);
  ctx.quadraticCurveTo(-hw, -hh * 0.86, -hw * 0.62, -hh);
  ctx.closePath();
}

function drawVehicle(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  paint: CarPaint,
  opts: { player?: boolean; lean?: number; lightBeams?: boolean; nitro?: boolean; bounce?: number } = {},
) {
  const h = w * 1.92;
  const hw = w / 2;
  const hh = h / 2;
  ctx.save();
  ctx.translate(x, y + (opts.bounce ?? 0));
  ctx.rotate((opts.lean ?? 0) * 0.055);

  // Ground contact shadow.
  ctx.save();
  ctx.shadowColor = "rgba(0, 0, 0, 0.65)";
  ctx.shadowBlur = 18;
  ctx.fillStyle = "rgba(0,0,0,0.45)";
  roundRect(ctx, -hw * 0.95, -hh * 0.9, w * 0.95, h * 0.96, w * 0.25);
  ctx.fill();
  ctx.restore();

  // Under-body glow.
  if (opts.player) {
    const glow = ctx.createRadialGradient(0, hh * 0.5, 2, 0, hh * 0.5, w * 0.9);
    glow.addColorStop(0, `rgba(${VOLT}, 0.32)`);
    glow.addColorStop(1, `rgba(${VOLT}, 0)`);
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.ellipse(0, hh * 0.5, w * 0.9, h * 0.36, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Wheels.
  ctx.fillStyle = "#070907";
  const wheelW = w * 0.13;
  const wheelH = h * 0.17;
  [
    [-hw - wheelW * 0.22, -hh * 0.62],
    [hw - wheelW * 0.78, -hh * 0.62],
    [-hw - wheelW * 0.22, hh * 0.3],
    [hw - wheelW * 0.78, hh * 0.3],
  ].forEach(([wx, wy]) => {
    roundRect(ctx, wx, wy, wheelW, wheelH, wheelW * 0.35);
    ctx.fill();
  });

  // Main body.
  carBodyPath(ctx, w, h);
  const paintGradient = ctx.createLinearGradient(-hw, 0, hw, 0);
  paintGradient.addColorStop(0, paint.bodyDark ?? paint.body);
  paintGradient.addColorStop(0.3, paint.bodyLight);
  paintGradient.addColorStop(0.52, paint.body);
  paintGradient.addColorStop(0.78, paint.bodyLight);
  paintGradient.addColorStop(1, paint.bodyDark ?? paint.body);
  ctx.fillStyle = paintGradient;
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.10)";
  ctx.lineWidth = 1;
  ctx.stroke();

  // Sculpted centre spine + contrast stripe.
  const spine = ctx.createLinearGradient(0, -hh, 0, hh);
  spine.addColorStop(0, "rgba(255,255,255,0.16)");
  spine.addColorStop(0.55, "rgba(255,255,255,0.03)");
  spine.addColorStop(1, "rgba(255,255,255,0.11)");
  ctx.fillStyle = spine;
  roundRect(ctx, -w * 0.075, -hh * 0.88, w * 0.15, h * 0.88, w * 0.06);
  ctx.fill();

  if (opts.player) {
    ctx.fillStyle = paint.accent;
    ctx.globalAlpha = 0.92;
    roundRect(ctx, -w * 0.035, -hh * 0.86, w * 0.07, h * 0.44, w * 0.03);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  // Glazing.
  const glass = ctx.createLinearGradient(0, -hh * 0.45, 0, hh * 0.28);
  glass.addColorStop(0, "#0c1517");
  glass.addColorStop(0.5, "#1c2b2e");
  glass.addColorStop(1, "#0a1012");
  ctx.fillStyle = glass;
  ctx.beginPath();
  ctx.moveTo(-w * 0.31, -hh * 0.4);
  ctx.quadraticCurveTo(0, -hh * 0.56, w * 0.31, -hh * 0.4);
  ctx.lineTo(w * 0.34, hh * 0.12);
  ctx.quadraticCurveTo(0, hh * 0.32, -w * 0.34, hh * 0.12);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.14)";
  ctx.lineWidth = 1;
  ctx.stroke();

  // Roof / rear window highlight.
  ctx.fillStyle = "rgba(255,255,255,0.07)";
  roundRect(ctx, -w * 0.23, hh * 0.1, w * 0.46, hh * 0.16, w * 0.08);
  ctx.fill();

  // Mirrors.
  ctx.fillStyle = paint.body;
  roundRect(ctx, -hw - w * 0.09, -hh * 0.28, w * 0.11, h * 0.06, 2);
  ctx.fill();
  roundRect(ctx, hw - w * 0.02, -hh * 0.28, w * 0.11, h * 0.06, 2);
  ctx.fill();

  // Headlights.
  ctx.save();
  ctx.shadowColor = opts.player ? "rgba(226, 255, 180, 0.9)" : "rgba(255, 240, 200, 0.45)";
  ctx.shadowBlur = opts.player ? 14 : 6;
  ctx.fillStyle = opts.player ? "#eaffbf" : "rgba(255,244,214,0.65)";
  roundRect(ctx, -hw * 0.78, -hh * 0.94, w * 0.22, h * 0.028, 2);
  ctx.fill();
  roundRect(ctx, hw * 0.78 - w * 0.22, -hh * 0.94, w * 0.22, h * 0.028, 2);
  ctx.fill();
  ctx.restore();

  // Tail lights.
  ctx.save();
  const tailColor = opts.player ? paint.accent : "#ff4433";
  ctx.shadowColor = opts.player ? paint.accent : "rgba(255, 60, 40, 0.85)";
  ctx.shadowBlur = opts.player ? 20 : 10;
  ctx.fillStyle = tailColor;
  roundRect(ctx, -hw * 0.84, hh * 0.9, w * 0.38, h * 0.024, 2);
  ctx.fill();
  roundRect(ctx, hw * 0.84 - w * 0.38, hh * 0.9, w * 0.38, h * 0.024, 2);
  ctx.fill();
  ctx.restore();

  // Rear diffuser / plate.
  ctx.fillStyle = "rgba(6, 8, 7, 0.85)";
  roundRect(ctx, -w * 0.21, hh * 0.78, w * 0.42, h * 0.09, 3);
  ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.16)";
  ctx.fillRect(-w * 0.04, hh * 0.81, w * 0.08, h * 0.012);

  // Nitro flame.
  if (opts.nitro) {
    const flame = ctx.createLinearGradient(0, hh, 0, hh + h * 0.22);
    flame.addColorStop(0, "rgba(201, 250, 60, 0.9)");
    flame.addColorStop(1, "rgba(201, 250, 60, 0)");
    ctx.fillStyle = flame;
    ctx.beginPath();
    ctx.moveTo(-w * 0.16, hh * 0.94);
    ctx.lineTo(0, hh * 1.02 + h * 0.2);
    ctx.lineTo(w * 0.16, hh * 0.94);
    ctx.closePath();
    ctx.fill();
  }

  ctx.restore();
}

function drawHeadlights(ctx: CanvasRenderingContext2D, world: World) {
  const { playerY, carW } = world.layout;
  const x = world.playerX;
  const top = playerY - carW * 0.95;
  const beam = ctx.createLinearGradient(0, top, 0, top - carW * 5.2);
  beam.addColorStop(0, "rgba(226, 255, 178, 0.18)");
  beam.addColorStop(0.45, "rgba(201, 250, 60, 0.07)");
  beam.addColorStop(1, "rgba(201, 250, 60, 0)");
  ctx.fillStyle = beam;
  ctx.beginPath();
  ctx.moveTo(x - carW * 0.34, top);
  ctx.lineTo(x - carW * 1.18, top - carW * 5.2);
  ctx.lineTo(x + carW * 1.18, top - carW * 5.2);
  ctx.lineTo(x + carW * 0.34, top);
  ctx.closePath();
  ctx.fill();
}

/* ------------------------------------------------------------------ */
/* Effects                                                             */
/* ------------------------------------------------------------------ */

function drawPickups(ctx: CanvasRenderingContext2D, world: World) {
  world.pickups.forEach((pickup) => {
    const pulse = Math.sin(pickup.phase * 2.2);
    const radius = 10 + pulse * 1.6;
    ctx.save();
    ctx.translate(pickup.x, pickup.y);
    ctx.rotate(Math.sin(pickup.phase) * 0.12);

    const halo = ctx.createRadialGradient(0, 0, 0, 0, 0, 30 + pulse * 4);
    halo.addColorStop(0, `rgba(${VOLT}, 0.35)`);
    halo.addColorStop(1, `rgba(${VOLT}, 0)`);
    ctx.fillStyle = halo;
    ctx.beginPath();
    ctx.arc(0, 0, 30 + pulse * 4, 0, Math.PI * 2);
    ctx.fill();

    ctx.beginPath();
    for (let i = 0; i < 6; i += 1) {
      const angle = (Math.PI / 3) * i - Math.PI / 2;
      const px = Math.cos(angle) * radius;
      const py = Math.sin(angle) * radius;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fillStyle = "rgba(11, 17, 8, 0.95)";
    ctx.fill();
    ctx.strokeStyle = `rgba(${VOLT}, 0.9)`;
    ctx.lineWidth = 1.6;
    ctx.shadowColor = `rgba(${VOLT}, 0.8)`;
    ctx.shadowBlur = 14;
    ctx.stroke();
    ctx.shadowBlur = 0;

    ctx.fillStyle = "#dfff87";
    ctx.beginPath();
    ctx.moveTo(-1.5, -5.5);
    ctx.lineTo(3.4, -1.1);
    ctx.lineTo(0.7, -0.6);
    ctx.lineTo(2, 5.4);
    ctx.lineTo(-3.4, 0.6);
    ctx.lineTo(-0.5, 0.3);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  });
}

function drawParticles(ctx: CanvasRenderingContext2D, world: World) {
  world.particles.forEach((p) => {
    const alpha = Math.max(0, p.life / p.max);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = p.color;
    ctx.shadowColor = p.color;
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;

  ctx.textAlign = "center";
  ctx.font = "600 10px 'JetBrains Mono', monospace";
  world.texts.forEach((text) => {
    ctx.globalAlpha = Math.min(1, text.life / 0.5);
    ctx.fillStyle = text.color;
    ctx.shadowColor = "rgba(0,0,0,0.8)";
    ctx.shadowBlur = 6;
    ctx.fillText(text.text, text.x, text.y);
  });
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;
}

function drawSpeedLines(ctx: CanvasRenderingContext2D, world: World) {
  const { w, h, roadX, roadW } = world.layout;
  const factor = Math.max(0, (world.speed - 120) / 80);
  if (factor <= 0.02) return;
  const count = 18;
  for (let i = 0; i < count; i += 1) {
    const right = i % 2 === 0;
    const x = right ? roadX + roadW + 4 + (i % 4) * 7 : roadX - 11 - (i % 4) * 7;
    if (x < 0 || x > w) continue;
    const y = ((i * 131 + world.roadOffset * 2.9) % (h + 140)) - 70;
    const len = 22 + factor * 68 + (i % 5) * 8;
    const alpha = 0.06 + factor * 0.18;
    const line = ctx.createLinearGradient(x, y, x, y + len);
    line.addColorStop(0, `rgba(230, 255, 190, ${alpha})`);
    line.addColorStop(1, "rgba(230, 255, 190, 0)");
    ctx.fillStyle = line;
    ctx.fillRect(x, y, 1.4, len);
  }
}

function drawVignette(ctx: CanvasRenderingContext2D, world: World) {
  const { w, h } = world.layout;
  const vignette = ctx.createRadialGradient(w / 2, h * 0.5, Math.min(w, h) * 0.28, w / 2, h * 0.5, Math.max(w, h) * 0.78);
  vignette.addColorStop(0, "rgba(0,0,0,0)");
  vignette.addColorStop(1, "rgba(3, 5, 3, 0.7)");
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, w, h);

  const top = ctx.createLinearGradient(0, 0, 0, h * 0.24);
  top.addColorStop(0, "rgba(4, 6, 4, 0.72)");
  top.addColorStop(1, "rgba(4, 6, 4, 0)");
  ctx.fillStyle = top;
  ctx.fillRect(0, 0, w, h * 0.24);

  const bottom = ctx.createLinearGradient(0, h * 0.72, 0, h);
  bottom.addColorStop(0, "rgba(4, 6, 4, 0)");
  bottom.addColorStop(1, "rgba(4, 6, 4, 0.8)");
  ctx.fillStyle = bottom;
  ctx.fillRect(0, h * 0.72, w, h * 0.28);
}

/* ------------------------------------------------------------------ */
/* Scene                                                               */
/* ------------------------------------------------------------------ */

const AMBIENT_CARS = [
  { lane: 0.5, color: "#3c4548", light: "#5a6568", speed: 0.75, offset: 0 },
  { lane: 2.5, color: "#4b4636", light: "#6c6650", speed: 0.92, offset: 230 },
];

export function renderWorld(
  ctx: CanvasRenderingContext2D,
  world: World,
  car: Car,
  phase: Phase,
  time: number,
) {
  const { w, h, carW, playerY } = world.layout;
  if (w < 2 || h < 2) return;

  ctx.save();
  if (world.shake > 0.2) {
    ctx.translate((Math.random() - 0.5) * world.shake, (Math.random() - 0.5) * world.shake * 0.7);
  }

  drawBackground(ctx, world);
  drawRoad(ctx, world);

  if (phase === "idle") {
    AMBIENT_CARS.forEach((ambient, index) => {
      const x = world.layout.roadX + world.layout.laneW * ambient.lane;
      const y = ((time * 58 * ambient.speed + ambient.offset) % (h + 460)) - 190;
      drawVehicle(ctx, x, y, carW * 0.95, { body: ambient.color, bodyLight: ambient.light, accent: "#ff4433" }, { lightBeams: false });
      void index;
    });
  }

  if (!world.crashed) drawHeadlights(ctx, world);

  drawPickups(ctx, world);

  world.cars.forEach((traffic) => {
    drawVehicle(
      ctx,
      traffic.x,
      traffic.y,
      carW * traffic.size,
      { body: traffic.body, bodyLight: traffic.bodyLight, accent: "#ff4433" },
      {},
    );
  });

  if (!world.crashed) {
    drawSpeedLines(ctx, world);
  }

  const blink = world.invincible > 0 ? (Math.floor(world.invincible * 12) % 2 === 0 ? 0.32 : 1) : 1;
  drawVehicle(
    ctx,
    world.playerX,
    playerY,
    carW,
    { body: car.body, bodyLight: car.bodyLight, bodyDark: car.bodyDark, accent: car.accent },
    {
      player: true,
      lean: world.lean,
      nitro: world.nitroActive,
      bounce: Math.sin(time * 34) * Math.min(1.2, world.speed / 240),
    },
  );
  if (blink < 1) {
    ctx.fillStyle = `rgba(6, 8, 6, ${0.24 + (1 - blink) * 0.3})`;
    ctx.beginPath();
    ctx.ellipse(world.playerX, playerY, carW * 0.8, carW * 1.5, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  drawParticles(ctx, world);

  if (world.flash > 0.01) {
    ctx.fillStyle = `rgba(255, 84, 40, ${world.flash * 0.34})`;
    ctx.fillRect(0, 0, w, h);
  }

  drawVignette(ctx, world);

  if (world.nitroActive) {
    const speedTint = ctx.createLinearGradient(0, h * 0.5, 0, h);
    speedTint.addColorStop(0, "rgba(201, 250, 60, 0)");
    speedTint.addColorStop(1, "rgba(201, 250, 60, 0.09)");
    ctx.fillStyle = speedTint;
    ctx.fillRect(0, 0, w, h);
  }

  ctx.restore();
}
