import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { makeModel, getMats } from './models';
import { angDiff, clamp, mulberry, type World, type Ent } from './world';
import { UNITS, FACS, PCOL, ERAS } from './data';
import { S } from './audio';

interface View { obj: THREE.Group; parts: Record<string, THREE.Group>; ph: number; x: number; z: number; r: number; lr: number; bank: number; amp: number; sm: number; chute?: THREE.Object3D; kind: string }
interface Proj { m: THREE.Mesh; x0: number; y0: number; z0: number; x1: number; y1: number; z1: number; t: number; dur: number; arc: number; k: string; spl: number }

const colGeo = (parts: [THREE.BufferGeometry, number, [number, number, number]?, [number, number, number]?][]) => {
  const gs = parts.map(([g, c, p, r]) => {
    const m = new THREE.Matrix4(); const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(...(r || [0, 0, 0])));
    m.compose(new THREE.Vector3(...(p || [0, 0, 0])), q, new THREE.Vector3(1, 1, 1)); g.applyMatrix4(m); g.deleteAttribute('uv');
    const col = new THREE.Color(c); const n = g.attributes.position.count; const a = new Float32Array(n * 3); for (let i = 0; i < n; i++) { a[i * 3] = col.r; a[i * 3 + 1] = col.g; a[i * 3 + 2] = col.b; }
    g.setAttribute('color', new THREE.BufferAttribute(a, 3)); return g;
  });
  return mergeGeometries(gs, false)!;
};

export class Renderer {
  r: THREE.WebGLRenderer; scene = new THREE.Scene(); cam = new THREE.PerspectiveCamera(42, 1, 1, 600);
  cx = 0; cz = 0; yaw = Math.PI * 0.0; dist = 52; pitch = 0.92; shake = 0; time = 0;
  views = new Map<number, View>(); mapGroup = new THREE.Group(); world!: World; half = 80;
  light: THREE.DirectionalLight; ghost: THREE.Mesh; projs: Proj[] = []; flyers: { o: THREE.Object3D; x: number; z: number; dx: number; dz: number; t: number; T: number }[] = [];
  smokers: { x: number; y: number; z: number; t: number; big: boolean }[] = [];
  // particles
  MAXP: number; pi = 0; pPos: Float32Array; pCol: Float32Array; pSize: Float32Array; pVel: Float32Array; pLife: Float32Array; pAge: Float32Array; pGrow: Float32Array; pGrav: Float32Array; pBase: Float32Array; pKind: Uint8Array;
  pGeo: THREE.BufferGeometry; pMat: THREE.ShaderMaterial; pts: THREE.Points; frame = 0; W = 1; H = 1;
  projPool: Record<string, THREE.Mesh[]> = {};

  constructor(public canvas: HTMLCanvasElement) {
    this.r = new THREE.WebGLRenderer({ canvas, antialias: S.hq, powerPreference: 'high-performance' });
    this.r.setPixelRatio(Math.min(window.devicePixelRatio || 1, S.hq ? 2 : 1.25));
    this.r.shadowMap.enabled = S.hq; this.r.shadowMap.type = THREE.PCFSoftShadowMap;
    this.scene.add(this.mapGroup);
    this.scene.add(new THREE.HemisphereLight(0xffffff, 0x6a6a58, 1.05));
    this.light = new THREE.DirectionalLight(0xfff0d8, 1.6); this.light.castShadow = S.hq;
    this.light.shadow.mapSize.set(2048, 2048); const sc = this.light.shadow.camera; sc.left = -75; sc.right = 75; sc.top = 75; sc.bottom = -75; sc.near = 10; sc.far = 300; this.light.shadow.bias = -0.0006;
    this.scene.add(this.light); this.scene.add(this.light.target);
    this.ghost = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshBasicMaterial({ color: 0x44ff66, transparent: true, opacity: 0.45 })); this.ghost.visible = false; this.scene.add(this.ghost);
    this.MAXP = S.hq ? 2200 : 900; const M = this.MAXP;
    this.pPos = new Float32Array(M * 3); this.pCol = new Float32Array(M * 4); this.pSize = new Float32Array(M); this.pVel = new Float32Array(M * 3);
    this.pLife = new Float32Array(M).fill(1); this.pAge = new Float32Array(M).fill(9); this.pGrow = new Float32Array(M); this.pGrav = new Float32Array(M); this.pBase = new Float32Array(M * 5); this.pKind = new Uint8Array(M);
    this.pGeo = new THREE.BufferGeometry();
    this.pGeo.setAttribute('position', new THREE.BufferAttribute(this.pPos, 3).setUsage(THREE.DynamicDrawUsage));
    this.pGeo.setAttribute('col', new THREE.BufferAttribute(this.pCol, 4).setUsage(THREE.DynamicDrawUsage));
    this.pGeo.setAttribute('size', new THREE.BufferAttribute(this.pSize, 1).setUsage(THREE.DynamicDrawUsage));
    this.pMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, uniforms: { k: { value: 500 } },
      vertexShader: 'attribute float size;attribute vec4 col;varying vec4 vc;uniform float k;void main(){vc=col;vec4 mv=modelViewMatrix*vec4(position,1.);gl_PointSize=size*k/(-mv.z);gl_Position=projectionMatrix*mv;}',
      fragmentShader: 'varying vec4 vc;void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;float a=smoothstep(.5,.05,d)*vc.a;gl_FragColor=vec4(vc.rgb,a);}',
    });
    this.pts = new THREE.Points(this.pGeo, this.pMat); this.pts.frustumCulled = false; this.pts.renderOrder = 10; this.scene.add(this.pts);
    this.resize();
  }
  resize() {
    const w = this.canvas.clientWidth || window.innerWidth, h = this.canvas.clientHeight || window.innerHeight; this.W = w; this.H = h;
    this.r.setSize(w, h, false); this.cam.aspect = w / h; this.cam.updateProjectionMatrix();
    this.pMat.uniforms.k.value = (h * (this.r.getPixelRatio())) / (2 * Math.tan((this.cam.fov * Math.PI) / 360));
  }
  dispose() { this.r.dispose(); this.scene.traverse(o => { const m = o as THREE.Mesh; if (m.geometry) m.geometry.dispose(); }); }

  /* ---------- map ---------- */
  loadMap(w: World) {
    this.world = w; const map = w.map, era = ERAS[w.era]; this.half = map.size / 2; const S2 = map.size;
    this.scene.background = new THREE.Color(era.sky); this.scene.fog = new THREE.Fog(era.sky, 130, 330);
    const g = new THREE.Group(); this.mapGroup.add(g); const rnd = mulberry(map.size * 7 + 3);
    const seg = Math.round(S2 / 2.5); const pg = new THREE.PlaneGeometry(S2 + 4, S2 + 4, seg, seg); pg.rotateX(-Math.PI / 2);
    const pos = pg.attributes.position; const cols = new Float32Array(pos.count * 3);
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), z = pos.getZ(i); const n = 0.5 + 0.25 * Math.sin(x * 0.11 + z * 0.07) + 0.25 * Math.sin(z * 0.17 - x * 0.09 + 1.3); const j = (rnd() - 0.5) * 0.07;
      for (let k = 0; k < 3; k++) cols[i * 3 + k] = clamp(era.gr[k] * n + era.gr2[k] * (1 - n) + j, 0, 1);
    }
    pg.setAttribute('color', new THREE.BufferAttribute(cols, 3));
    const ground = new THREE.Mesh(pg, new THREE.MeshLambertMaterial({ vertexColors: true })); ground.receiveShadow = true; g.add(ground);
    const outer = new THREE.Mesh(new THREE.PlaneGeometry(S2 * 5, S2 * 5).rotateX(-Math.PI / 2), new THREE.MeshLambertMaterial({ color: new THREE.Color(era.gr2[0] * 0.55, era.gr2[1] * 0.55, era.gr2[2] * 0.55) })); outer.position.y = -0.08; g.add(outer);
    // water
    for (const r of map.water) {
      const sh = new THREE.Mesh(new THREE.BoxGeometry(r.w + 1.6, 0.1, r.h + 1.6), new THREE.MeshLambertMaterial({ color: 0x8a7a55 })); sh.position.set(r.x, 0.03, r.z); g.add(sh);
      const wt = new THREE.Mesh(new THREE.BoxGeometry(r.w, 0.2, r.h), new THREE.MeshPhongMaterial({ color: 0x2c6fb0, shininess: 90, specular: 0x88bbee, transparent: true, opacity: 0.92 })); wt.position.set(r.x, 0.03, r.z); g.add(wt);
    }
    for (const r of map.bridges) {
      const horiz = r.w > r.h; const d = new THREE.Mesh(new THREE.BoxGeometry(r.w, 0.12, r.h), new THREE.MeshLambertMaterial({ color: 0x8a6a40 })); d.position.set(r.x, 0.13, r.z); d.receiveShadow = true; g.add(d);
      for (const s of [-1, 1]) { const rl = new THREE.Mesh(new THREE.BoxGeometry(horiz ? r.w : 0.25, 0.6, horiz ? 0.25 : r.h), new THREE.MeshLambertMaterial({ color: 0x5a3a1a })); rl.position.set(r.x + (horiz ? 0 : s * (r.w / 2 - 0.1)), 0.5, r.z + (horiz ? s * (r.h / 2 - 0.1) : 0)); g.add(rl); }
    }
    // rocks
    const rg = new THREE.IcosahedronGeometry(1, 0); const rp = rg.attributes.position; const rr = mulberry(5);
    for (let i = 0; i < rp.count; i++) { rp.setXYZ(i, rp.getX(i) * (0.85 + rr() * 0.3), rp.getY(i) * (0.8 + rr() * 0.4), rp.getZ(i) * (0.85 + rr() * 0.3)); } rg.computeVertexNormals();
    const rockCol = w.era === 'anc' ? 0xb59a6a : w.era === 'ww2' ? 0x8a8a84 : 0x7d7a72;
    const rocks: { x: number; z: number; s: number; h: number }[] = [];
    for (const c of map.rocks) {
      rocks.push({ x: c.x, z: c.z, s: c.r * 0.95, h: c.r * (0.9 + rnd() * 0.5) });
      for (let k = 0; k < 4; k++) { const a = rnd() * 6.28; rocks.push({ x: c.x + Math.cos(a) * c.r * 0.75, z: c.z + Math.sin(a) * c.r * 0.75, s: c.r * (0.4 + rnd() * 0.25), h: c.r * (0.4 + rnd() * 0.4) }); }
    }
    for (let i = 0; i < 70; i++) { // border mountains
      const a = (i / 70) * 6.283; const rad = this.half * 1.04 + 5 + rnd() * 5; const sq = Math.max(Math.abs(Math.cos(a)), Math.abs(Math.sin(a)));
      rocks.push({ x: (Math.cos(a) * rad) / sq * 0.99, z: (Math.sin(a) * rad) / sq * 0.99, s: 7 + rnd() * 6, h: 9 + rnd() * 10 });
    }
    const rim = new THREE.InstancedMesh(rg, new THREE.MeshLambertMaterial({ flatShading: true }), rocks.length); const dm = new THREE.Object3D(); const cc = new THREE.Color();
    rocks.forEach((r, i) => { dm.position.set(r.x, r.h * 0.3, r.z); dm.rotation.set(0, rnd() * 6, 0); dm.scale.set(r.s, r.h, r.s * (0.8 + rnd() * 0.4)); dm.updateMatrix(); rim.setMatrixAt(i, dm.matrix); cc.set(rockCol).multiplyScalar(0.8 + rnd() * 0.4); rim.setColorAt(i, cc); });
    rim.castShadow = S.hq; rim.receiveShadow = S.hq; g.add(rim);
    // trees
    const tg = this.treeGeo(w.era); const spots: { x: number; z: number; s: number }[] = [];
    for (const f of map.forests) { const n = Math.round((f.r * f.r) / 4.5); for (let i = 0; i < n; i++) { const a = rnd() * 6.28, d = Math.sqrt(rnd()) * f.r; spots.push({ x: f.x + Math.cos(a) * d, z: f.z + Math.sin(a) * d, s: 0.8 + rnd() * 0.7 }); } }
    for (const m of map.mines) { void m; }
    const filtered = spots.filter(s => !w.blockedAt(s.x, s.z) && !map.starts.some(st => Math.hypot(st.x - s.x, st.z - s.z) < 12) && !map.mines.some(m => Math.hypot(m.x - s.x, m.z - s.z) < 5));
    if (filtered.length) {
      const tim = new THREE.InstancedMesh(tg, new THREE.MeshLambertMaterial({ vertexColors: true }), filtered.length);
      filtered.forEach((s, i) => { dm.position.set(s.x, 0, s.z); dm.rotation.set(0, rnd() * 6, 0); dm.scale.setScalar(s.s); dm.updateMatrix(); tim.setMatrixAt(i, dm.matrix); }); tim.castShadow = S.hq; g.add(tim);
    }
    // scattered pebbles / tufts
    const pg2 = new THREE.IcosahedronGeometry(0.35, 0); const n2 = Math.round(S2 * 1.5 * S.q); const pim = new THREE.InstancedMesh(pg2, new THREE.MeshLambertMaterial({ flatShading: true }), n2); let c2 = 0;
    for (let i = 0; i < n2; i++) { const x = (rnd() - 0.5) * (S2 - 6), z = (rnd() - 0.5) * (S2 - 6); if (w.blockedAt(x, z)) continue; dm.position.set(x, 0.05, z); dm.scale.set(0.6 + rnd(), 0.4 + rnd() * 0.5, 0.6 + rnd()); dm.rotation.set(0, rnd() * 6, 0); dm.updateMatrix(); pim.setMatrixAt(c2, dm.matrix); cc.set(rockCol).multiplyScalar(0.7 + rnd() * 0.5); pim.setColorAt(c2, cc); c2++; }
    pim.count = c2; g.add(pim);
  }
  private treeGeo(era: string) {
    const T = (rt: number, rb: number, h: number) => new THREE.CylinderGeometry(rt, rb, h, 6);
    if (era === 'anc') {
      const p: any[] = [[T(0.14, 0.24, 3.6), 0x8a6a3a, [0, 1.8, 0]]];
      for (let i = 0; i < 6; i++) { const a = (i / 6) * 6.28; p.push([new THREE.ConeGeometry(0.35, 2.4, 4), 0x3d8a3a, [Math.cos(a) * 0.9, 3.7, Math.sin(a) * 0.9], [Math.sin(a) * 1.2, 0, -Math.cos(a) * 1.2]]); }
      return colGeo(p);
    }
    if (era === 'ww2') return colGeo([[T(0.15, 0.22, 1.4), 0x5a3d22, [0, 0.7, 0]], [new THREE.ConeGeometry(1.5, 2.2, 7), 0x2a5a2e, [0, 2.2, 0]], [new THREE.ConeGeometry(1.1, 2, 7), 0x2f6633, [0, 3.4, 0]], [new THREE.ConeGeometry(0.7, 1.7, 7), 0x347038, [0, 4.5, 0]]]);
    return colGeo([[T(0.16, 0.24, 2.4), 0x6a5636, [0, 1.2, 0]], [new THREE.SphereGeometry(1.5, 7, 5).scale(1, 0.55, 1), 0x6a8a4a, [0, 2.9, 0]], [new THREE.SphereGeometry(0.9, 7, 5).scale(1, 0.6, 1), 0x7a9a55, [0.7, 3.4, 0.3]]]);
  }

  /* ---------- camera ---------- */
  updateCam(dt: number) {
    this.shake = Math.max(0, this.shake - dt * 2.2); const h = this.half;
    this.cx = clamp(this.cx, -h, h); this.cz = clamp(this.cz, -h, h); this.dist = clamp(this.dist, 20, 120);
    const sx = this.shake * (Math.random() - 0.5) * 1.6, sz = this.shake * (Math.random() - 0.5) * 1.6;
    const p = this.pitch, d = this.dist;
    this.cam.position.set(this.cx + Math.sin(this.yaw) * Math.cos(p) * d + sx, Math.sin(p) * d, this.cz + Math.cos(this.yaw) * Math.cos(p) * d + sz);
    this.cam.lookAt(this.cx + sx, 0, this.cz + sz);
    this.light.position.set(this.cx + 55, 110, this.cz + 35); this.light.target.position.set(this.cx, 0, this.cz);
  }
  ray = new THREE.Raycaster(); v2 = new THREE.Vector2();
  groundAt(px: number, py: number): [number, number] | null {
    this.v2.set((px / this.W) * 2 - 1, -(py / this.H) * 2 + 1); this.ray.setFromCamera(this.v2, this.cam);
    const o = this.ray.ray.origin, d = this.ray.ray.direction; if (d.y > -0.001) return null; const t = -o.y / d.y; return [o.x + d.x * t, o.z + d.z * t];
  }
  private pv = new THREE.Vector3();
  project(x: number, y: number, z: number): [number, number, boolean] {
    this.pv.set(x, y, z).project(this.cam); return [(this.pv.x * 0.5 + 0.5) * this.W, (-this.pv.y * 0.5 + 0.5) * this.H, this.pv.z < 1 && Math.abs(this.pv.x) < 1.2 && Math.abs(this.pv.y) < 1.2];
  }
  setGhost(x: number, z: number, sz: number, ok: boolean | null) {
    if (ok === null) { this.ghost.visible = false; return; } this.ghost.visible = true; this.ghost.position.set(x, 1.5, z); this.ghost.scale.set(sz, 3, sz);
    (this.ghost.material as THREE.MeshBasicMaterial).color.set(ok ? 0x44ff66 : 0xff4444);
  }

  /* ---------- entities ---------- */
  private createView(e: Ent): View {
    const w = this.world; const sty = ERAS[w.era].sty; let key: string, mats;
    if (e.mine) { key = 'mine'; mats = getMats(0x888888, [0.8, 0.7, 0.3], [0.5, 0.5, 0.5]); }
    else { const f = FACS[w.players[e.own].fac]; mats = getMats(PCOL[e.own % 4], f.a, f.b); key = e.b ? `b_${sty}_${e.t}` : UNITS[e.t].model; }
    const obj = makeModel(key, mats, S.hq); this.scene.add(obj);
    const ud = UNITS[e.t]; const kind = e.b || e.mine ? 'b' : ud.cls === 'inf' || ud.cls === 'wk' ? 'h' : ud.air ? (ud.fw ? 'fw' : 'heli') : 'v';
    obj.position.set(e.x, 0, e.z); obj.rotation.order = 'YXZ'; if (kind === 'h') obj.scale.setScalar(1.25);
    return { obj, parts: obj.userData.parts, ph: e.ph, x: e.x, z: e.z, r: e.rot, lr: e.rot, bank: 0, amp: 0, sm: 0, kind };
  }
  sync(w: World, dt: number) {
    this.world = w; this.frame++; const client = w.role === 'client';
    w.ents.forEach(e => {
      let v = this.views.get(e.id); if (!v) { v = this.createView(e); this.views.set(e.id, v); }
      const o = v.obj;
      if (client) { const k = Math.min(1, dt * 12); v.x += (e.x - v.x) * k; v.z += (e.z - v.z) * k; v.r += angDiff(v.r, e.rot) * k; } else { v.x = e.x; v.z = e.z; v.r = e.rot; }
      if (e.mine) { o.position.set(v.x, 0, v.z); const s = 0.55 + 0.45 * clamp(e.amt / 3500, 0, 1); o.scale.set(s, s, s); return; }
      v.ph += dt * (e.mv ? (v.kind === 'h' ? 9 : e.spd * 1.1) : 0); v.amp += ((e.mv ? 1 : 0) - v.amp) * Math.min(1, dt * 10);
      const P = v.parts; const ud = UNITS[e.t];
      o.position.set(v.x, e.y + (v.kind === 'h' ? Math.abs(Math.sin(v.ph)) * 0.1 * v.amp : 0), v.z); o.rotation.y = v.r;
      if (e.b) { o.rotation.y = 0; const sc = e.cons < 1 ? 0.12 + 0.88 * e.cons : 1; o.scale.set(1, sc, 1); }
      for (const k in P) {
        const p = P[k];
        if (k === 'legL') p.rotation.x = Math.sin(v.ph) * 0.8 * v.amp; else if (k === 'legR') p.rotation.x = -Math.sin(v.ph) * 0.8 * v.amp;
        else if (k === 'armL') { const rng = ud && ud.rng > 4 && e.atkT < 0.6; p.rotation.x = rng ? -1.25 : -Math.sin(v.ph) * 0.6 * v.amp; }
        else if (k === 'armR') {
          if (ud && ud.rng > 4 && e.atkT < 0.6) p.rotation.x = -1.3; else if (e.atkT < 0.5 && (ud?.rng ?? 9) <= 4) p.rotation.x = -2.6 + clamp(e.atkT / 0.5, 0, 1) * 2.4; else p.rotation.x = Math.sin(v.ph) * 0.6 * v.amp - 0.15;
        }
        else if (k === 'turret') p.rotation.y = angDiff(e.b ? 0 : v.r, e.ta);
        else if (k.startsWith('whl')) p.rotation.x = v.ph;
        else if (k.startsWith('rotY')) p.rotation.y += dt * (e.b ? 2 : 35);
        else if (k.startsWith('rotZ')) p.rotation.z += dt * 40;
        else if (k.startsWith('rotX')) p.rotation.x += dt * 40;
        else if (k === 'cArm') { const t = e.atkT; p.rotation.x = t < 0.25 ? -1.0 + (t / 0.25) * 2.0 : 1.0 - clamp((t - 0.25) / 2.0, 0, 1) * 2.0; }
        else if (k === 'ramLog') p.position.z = e.atkT < 0.6 ? Math.sin((e.atkT / 0.6) * Math.PI) * 1.6 : 0;
      }
      if (v.kind === 'fw') { const turn = angDiff(v.lr, v.r) / Math.max(dt, 0.001); v.lr = v.r; v.bank += (clamp(-turn * 0.45, -0.9, 0.9) - v.bank) * Math.min(1, dt * 5); o.rotation.z = v.bank; }
      else if (v.kind === 'heli') o.rotation.x = e.mv ? 0.18 : 0;
      if (e.fall > 0) { if (!v.chute) { const c = new THREE.Mesh(new THREE.SphereGeometry(2, 8, 5, 0, 6.3, 0, 1.4), new THREE.MeshLambertMaterial({ color: 0xf2f2e8, side: THREE.DoubleSide })); c.position.y = 5.5; o.add(c); v.chute = c; } }
      else if (v.chute) { o.remove(v.chute); v.chute = undefined; }
      if (e.b && e.cons >= 1) {
        const f = e.hp / e.mhp;
        if (f < 0.55 && this.frame % (f < 0.28 ? 3 : 7) === 0) { const s = e.sz; this.puff(e.x + (Math.random() - 0.5) * s * 0.6, 2 + Math.random() * 2, e.z + (Math.random() - 0.5) * s * 0.6, f < 0.28 ? 1 : 0); }
      }
    });
    for (const [id, v] of this.views) if (!w.ents.has(id)) { this.scene.remove(v.obj); this.views.delete(id); }
  }
  clearViews() { for (const v of this.views.values()) this.scene.remove(v.obj); this.views.clear(); }

  /* ---------- particles ---------- */
  spawnP(x: number, y: number, z: number, vx: number, vy: number, vz: number, life: number, size: number, r: number, g: number, b: number, a: number, grow = 0, grav = 0, kind = 0) {
    const i = this.pi; this.pi = (this.pi + 1) % this.MAXP; const i3 = i * 3;
    this.pPos[i3] = x; this.pPos[i3 + 1] = y; this.pPos[i3 + 2] = z; this.pVel[i3] = vx; this.pVel[i3 + 1] = vy; this.pVel[i3 + 2] = vz;
    this.pLife[i] = life; this.pAge[i] = 0; this.pGrow[i] = grow; this.pGrav[i] = grav; this.pKind[i] = kind; const b5 = i * 5; this.pBase[b5] = r; this.pBase[b5 + 1] = g; this.pBase[b5 + 2] = b; this.pBase[b5 + 3] = a; this.pBase[b5 + 4] = size;
    this.pSize[i] = size; const c4 = i * 4; this.pCol[c4] = r; this.pCol[c4 + 1] = g; this.pCol[c4 + 2] = b; this.pCol[c4 + 3] = a;
  }
  puff(x: number, y: number, z: number, fire: number) {
    const r = Math.random;
    this.spawnP(x, y, z, (r() - 0.5) * 0.6, 1.6 + r(), (r() - 0.5) * 0.6, 2 + r() * 1.5, 1.4, 0.2, 0.2, 0.22, 0.7, 1.4);
    if (fire) this.spawnP(x, y - 0.4, z, (r() - 0.5) * 0.5, 1.2, (r() - 0.5) * 0.5, 0.6, 1.5, 1, 0.55, 0.1, 0.9, -1, 0, 1);
  }
  explode(x: number, y: number, z: number, s: number, f: string) {
    const r = Math.random; const q = S.q;
    if (f === 'heal' || f === 'buff') { const c = f === 'heal' ? [0.3, 1, 0.45] : [1, 0.6, 0.15]; for (let i = 0; i < 4; i++) this.spawnP(x + (r() - 0.5), 0.5 + r(), z + (r() - 0.5), 0, 1.5 + r(), 0, 1, 0.5, c[0], c[1], c[2], 0.9); return; }
    if (f === 'dust') { const n = Math.round(6 * q + 3); for (let i = 0; i < n; i++) { const a = r() * 6.28, sp = 1 + r() * 2.5 * s; this.spawnP(x, 0.4, z, Math.cos(a) * sp, 0.4 + r() * 0.8, Math.sin(a) * sp, 0.8 + r() * 0.6, 1.2 * s + 0.6, 0.62, 0.55, 0.42, 0.7, 1.5); } return; }
    const big = f === 'big'; const n = Math.round((14 + s * 12) * q); const ss = big ? s * 1.2 : s;
    this.spawnP(x, y, z, 0, 0, 0, 0.16, 8 * ss, 1, 0.9, 0.6, 0.95, 4);
    for (let i = 0; i < n; i++) {
      const a = r() * 6.28, b = (r() - 0.3) * 2.2, sp = (2 + r() * 5) * Math.sqrt(ss);
      this.spawnP(x, y, z, Math.cos(a) * sp, b * sp * 0.6 + 1, Math.sin(a) * sp, 0.4 + r() * 0.5, (1.4 + r() * 1.6) * ss, 1, 0.45 + r() * 0.4, 0.08, 0.95, -0.5, 0, 1);
    }
    for (let i = 0; i < Math.round(n * 0.6); i++) this.spawnP(x + (r() - 0.5) * ss, y, z + (r() - 0.5) * ss, (r() - 0.5) * 2, 1.2 + r() * 2, (r() - 0.5) * 2, 1.4 + r() * 1.2, (1.6 + r()) * ss, 0.18, 0.18, 0.2, 0.75, 2.2);
    for (let i = 0; i < Math.round(8 * q); i++) { const a = r() * 6.28, sp = 5 + r() * 9; this.spawnP(x, y, z, Math.cos(a) * sp, 4 + r() * 8, Math.sin(a) * sp, 0.5 + r() * 0.5, 0.25, 1, 0.85, 0.3, 1, 0, 14); }
    for (let i = 0; i < Math.round(8 * q); i++) { const a = r() * 6.28, sp = 2 + r() * 4 * ss; this.spawnP(x, 0.3, z, Math.cos(a) * sp, 0.2, Math.sin(a) * sp, 1 + r() * 0.6, 1.4 * ss + 0.5, 0.6, 0.52, 0.38, 0.6, 2); }
    if (big) this.smokers.push({ x, y: 1, z, t: 7, big: true });
    if (S.shake) { const d = Math.hypot(x - this.cx, z - this.cz); this.shake = Math.min(1.1, this.shake + (s * 0.1) / (1 + d / 22)); }
  }
  updateParticles(dt: number) {
    const M = this.MAXP; let any = false;
    for (let i = 0; i < M; i++) {
      const age = this.pAge[i]; const life = this.pLife[i]; if (age >= life) { if (this.pSize[i] !== 0) { this.pSize[i] = 0; any = true; } continue; }
      any = true; const na = age + dt; this.pAge[i] = na; const i3 = i * 3, b5 = i * 5, c4 = i * 4; const t = na / life;
      this.pVel[i3 + 1] -= this.pGrav[i] * dt; if (this.pKind[i] === 14) this.pVel[i3 + 1] -= 18 * dt;
      this.pPos[i3] += this.pVel[i3] * dt; this.pPos[i3 + 1] += this.pVel[i3 + 1] * dt; this.pPos[i3 + 2] += this.pVel[i3 + 2] * dt;
      if (this.pPos[i3 + 1] < 0.1 && this.pKind[i] === 14) { this.pPos[i3 + 1] = 0.1; this.pVel[i3 + 1] = 0; }
      this.pSize[i] = Math.max(0.01, this.pBase[b5 + 4] + this.pGrow[i] * na);
      const k = this.pKind[i];
      if (k === 1) { this.pCol[c4] = this.pBase[b5] * (1 - t) + 0.2 * t; this.pCol[c4 + 1] = this.pBase[b5 + 1] * (1 - t * 1.2 > 0 ? 1 - t * 1.2 : 0) + 0.15 * t; this.pCol[c4 + 2] = this.pBase[b5 + 2] + 0.15 * t; }
      this.pCol[c4 + 3] = this.pBase[b5 + 3] * Math.pow(1 - t, 1.2);
    }
    if (any) { (this.pGeo.attributes.position as THREE.BufferAttribute).needsUpdate = true; (this.pGeo.attributes.col as THREE.BufferAttribute).needsUpdate = true; (this.pGeo.attributes.size as THREE.BufferAttribute).needsUpdate = true; }
    for (let i = this.smokers.length - 1; i >= 0; i--) { const s = this.smokers[i]; s.t -= dt; if (Math.random() < dt * 9 * S.q) this.puff(s.x + (Math.random() - 0.5) * 3, s.y + 1, s.z + (Math.random() - 0.5) * 3, s.t > 3 ? 1 : 0); if (s.t <= 0) this.smokers.splice(i, 1); }
  }

  /* ---------- projectiles & events ---------- */
  private projMesh(k: string) {
    const pool = this.projPool[k] || (this.projPool[k] = []); const m = pool.pop(); if (m) { m.visible = true; return m; }
    let g: THREE.BufferGeometry, mt: THREE.Material;
    const bas = (c: number) => new THREE.MeshBasicMaterial({ color: c });
    switch (k) {
      case 'bullet': g = new THREE.BoxGeometry(0.07, 0.07, 1.1); mt = bas(0xffe9a0); break;
      case 'arrow': g = new THREE.BoxGeometry(0.06, 0.06, 1.4); mt = bas(0x6b4a22); break;
      case 'shell': g = new THREE.BoxGeometry(0.2, 0.2, 0.9); mt = bas(0xffc860); break;
      case 'stone': g = new THREE.IcosahedronGeometry(0.5, 0); mt = new THREE.MeshLambertMaterial({ color: 0x777066 }); break;
      case 'arty': g = new THREE.CylinderGeometry(0.2, 0.2, 0.9, 6).rotateX(Math.PI / 2); mt = new THREE.MeshLambertMaterial({ color: 0x333333 }); break;
      case 'bomb': g = new THREE.CylinderGeometry(0.28, 0.22, 1.1, 6).rotateX(Math.PI / 2); mt = new THREE.MeshLambertMaterial({ color: 0x2a2a2a }); break;
      default: g = new THREE.CylinderGeometry(0.12, 0.12, 1.2, 6).rotateX(Math.PI / 2); mt = new THREE.MeshLambertMaterial({ color: k === 'missile' ? 0xeeeeee : 0x8a8a8a, emissive: 0x332200 });
    }
    return new THREE.Mesh(g, mt);
  }
  event(ev: any) {
    switch (ev.k) {
      case 'p': {
        if (ev.p === 'bomb' && !ev.rain) { /* dropped from plane */ }
        const m = this.projMesh(ev.p); this.scene.add(m);
        const dist = Math.hypot(ev.tx - ev.x, ev.tz - ev.z); const arc = ev.p === 'stone' ? dist * 0.38 + 2 : ev.p === 'arty' ? dist * 0.4 + 3 : ev.p === 'arcrocket' ? dist * 0.3 + 3 : ev.p === 'arrow' && !ev.rain ? dist * 0.1 : 0;
        this.projs.push({ m, x0: ev.x, y0: ev.y, z0: ev.z, x1: ev.tx, y1: ev.ty, z1: ev.tz, t: 0, dur: Math.max(0.05, ev.t), arc, k: ev.p, spl: ev.spl || 0 });
        if (!ev.rain && ev.p !== 'bomb' && ev.p !== 'stone') {
          const fl = ev.p === 'bullet' ? 0.6 : 1.4; this.spawnP(ev.x, ev.y, ev.z, 0, 0, 0, 0.09, fl, 1, 0.9, 0.5, 1);
          if (ev.p === 'shell' || ev.p === 'arty' || ev.p === 'arcrocket' || ev.p === 'rocket') { for (let i = 0; i < 3; i++) this.spawnP(ev.x, ev.y, ev.z, (Math.random() - 0.5) * 2, 0.5, (Math.random() - 0.5) * 2, 0.8, 1.2, 0.6, 0.6, 0.6, 0.5, 1.5); }
        }
        break;
      }
      case 'x': this.explode(ev.x, ev.y, ev.z, ev.s, ev.f); break;
      case 'fly': {
        const mats = getMats(0x888888, [0.55, 0.57, 0.6], [0.3, 0.3, 0.3]); const o = makeModel(ev.m, mats, false); o.scale.setScalar(1.8); const T = (ev.d || 3) + 2; const dx = Math.sin(ev.a), dz = Math.cos(ev.a);
        o.rotation.y = ev.a; o.position.set(ev.x - dx * 90, 40, ev.z - dz * 90); this.scene.add(o); this.flyers.push({ o, x: ev.x, z: ev.z, dx, dz, t: 0, T }); break;
      }
    }
  }
  updateFx(dt: number) {
    for (let i = this.projs.length - 1; i >= 0; i--) {
      const p = this.projs[i]; p.t += dt / p.dur; const t = Math.min(1, p.t);
      const x = p.x0 + (p.x1 - p.x0) * t, z = p.z0 + (p.z1 - p.z0) * t; let y = p.y0 + (p.y1 - p.y0) * t + p.arc * 4 * t * (1 - t);
      if (p.k === 'bomb') y = p.y0 + (p.y1 - p.y0) * t * t;
      p.m.position.set(x, y, z);
      const t2 = Math.min(1, t + 0.04); const nx = p.x0 + (p.x1 - p.x0) * t2, nz = p.z0 + (p.z1 - p.z0) * t2; const ny = p.k === 'bomb' ? p.y0 + (p.y1 - p.y0) * t2 * t2 : p.y0 + (p.y1 - p.y0) * t2 + p.arc * 4 * t2 * (1 - t2);
      if (Math.abs(nx - x) + Math.abs(ny - y) + Math.abs(nz - z) > 0.001) p.m.lookAt(nx, ny, nz);
      if ((p.k === 'rocket' || p.k === 'missile' || p.k === 'arcrocket' || p.k === 'arty' || p.k === 'shell' || p.k === 'bomb') && Math.random() < 0.7) this.spawnP(x, y, z, 0, 0.3, 0, 0.7, 0.7, 0.75, 0.75, 0.75, 0.45, 1.4);
      if (p.k === 'rocket' || p.k === 'missile' || p.k === 'arcrocket') this.spawnP(x, y, z, 0, 0, 0, 0.12, 0.7, 1, 0.7, 0.2, 0.9);
      if (p.t >= 1) {
        this.scene.remove(p.m); (this.projPool[p.k] || (this.projPool[p.k] = [])).push(p.m);
        if (!p.spl) { const y1 = Math.max(0.3, p.y1); for (let k = 0; k < 3; k++) this.spawnP(p.x1, y1, p.z1, (Math.random() - 0.5) * 3, Math.random() * 2.5, (Math.random() - 0.5) * 3, 0.3, 0.5, 1, 0.8, 0.3, 1, 0, 6); if (p.k === 'shell' || p.k === 'bullet') this.spawnP(p.x1, y1, p.z1, 0, 0.2, 0, 0.5, 0.9, 0.5, 0.45, 0.4, 0.5, 1.2); }
        this.projs.splice(i, 1);
      }
    }
    for (let i = this.flyers.length - 1; i >= 0; i--) { const f = this.flyers[i]; f.t += dt; const k = (f.t / f.T) * 180 - 90; f.o.position.set(f.x + f.dx * k, 40, f.z + f.dz * k); if (f.t >= f.T) { this.scene.remove(f.o); this.flyers.splice(i, 1); } }
  }
  clearFx() { for (const p of this.projs) this.scene.remove(p.m); this.projs = []; for (const f of this.flyers) this.scene.remove(f.o); this.flyers = []; this.smokers = []; this.pAge.fill(9); }
  draw(dt: number) { this.time += dt; this.updateCam(dt); this.updateParticles(dt); this.updateFx(dt); this.r.render(this.scene, this.cam); }
}
