import {
  ACTION_BTN,
  FISHING,
  FISH_META,
  JOYSTICK,
  PALETTE,
  PLAYER,
  WORLD,
  ZONES,
} from './config'
import { actionHint } from './update'
import type { TouchControlState } from './touch'
import { basketCount, basketValue, type GameState } from './state'

export type Images = Record<string, HTMLImageElement | null>

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
): void {
  const rr = Math.min(r, w / 2, h / 2)
  ctx.beginPath()
  ctx.moveTo(x + rr, y)
  ctx.arcTo(x + w, y, x + w, y + h, rr)
  ctx.arcTo(x + w, y + h, x, y + h, rr)
  ctx.arcTo(x, y + h, x, y, rr)
  ctx.arcTo(x, y, x + w, y, rr)
  ctx.closePath()
}

function drawBg(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement | null,
  w: number,
  h: number,
  time: number,
): void {
  if (img && img.complete && img.naturalWidth) {
    // Cover-fit the portrait map into the viewport
    const scale = Math.max(w / img.naturalWidth, h / img.naturalHeight)
    const dw = img.naturalWidth * scale
    const dh = img.naturalHeight * scale
    const dx = (w - dw) / 2
    const dy = (h - dh) / 2
    ctx.drawImage(img, dx, dy, dw, dh)
  } else {
    // Procedural fallback
    const g = ctx.createLinearGradient(0, 0, 0, h)
    g.addColorStop(0, '#3d5a80')
    g.addColorStop(0.35, '#817d37')
    g.addColorStop(0.55, '#5a7d3a')
    g.addColorStop(1, '#1b4965')
    ctx.fillStyle = g
    ctx.fillRect(0, 0, w, h)
    ctx.fillStyle = '#2a6f97'
    ctx.fillRect(w * 0.42, h * 0.38, w * 0.55, h * 0.55)
  }

  // Soft water shimmer overlay in lake region
  const pulse = 0.5 + 0.5 * Math.sin(time * 2.2)
  ctx.save()
  ctx.globalAlpha = 0.08 + pulse * 0.06
  ctx.fillStyle = '#b8e0f0'
  const lakeX = w * 0.4
  const lakeY = h * 0.4
  for (let i = 0; i < 5; i++) {
    const yy = lakeY + i * 28 + Math.sin(time * 1.5 + i) * 4
    ctx.fillRect(lakeX + 10, yy, w * 0.5, 3)
  }
  ctx.restore()
}

function drawPlayer(
  ctx: CanvasRenderingContext2D,
  state: GameState,
  images: Images,
  sx: number,
  sy: number,
): void {
  const p = state.player
  // Simple 2-frame walk cycle. The original game has one character sprite,
  // so we animate it with alternating bob/tilt/scale rather than requiring
  // a new sprite sheet.
  const walkPhase = Math.floor(p.anim) % 2
  const walk = p.moving ? (walkPhase === 0 ? 1 : -1) : 0
  const bob = Math.sin(state.time * (p.moving ? 10 : 3)) * (p.moving ? 2 : 1.5)
  const img = images.fisher
  ctx.save()
  ctx.translate(sx, sy + bob)

  // Drop shadow under feet
  ctx.fillStyle = 'rgba(0,0,0,0.28)'
  ctx.beginPath()
  ctx.ellipse(0, 8, 16, 6, 0, 0, Math.PI * 2)
  ctx.fill()

  if (img && img.complete && img.naturalWidth) {
    const size = PLAYER.drawSize
    ctx.scale(p.facing, 1)
    if (p.moving) {
      ctx.rotate(walk * 0.035)
      ctx.scale(1 + walk * 0.018, 1 - Math.abs(walk) * 0.018)
    }
    ctx.drawImage(img, -size / 2, -size + 10, size, size)
  } else {
    // Procedural pixel farmer
    const s = 2
    ctx.scale(p.facing * s, s)
    // shadow
    ctx.fillStyle = 'rgba(0,0,0,0.25)'
    ctx.beginPath()
    ctx.ellipse(0, 6, 8, 3, 0, 0, Math.PI * 2)
    ctx.fill()
    // body
    ctx.fillStyle = '#3a6ea5'
    ctx.fillRect(-5, -10, 10, 12)
    // head
    ctx.fillStyle = '#f0c8a0'
    ctx.fillRect(-4, -18, 8, 8)
    // hat
    ctx.fillStyle = '#c9a227'
    ctx.fillRect(-6, -22, 12, 4)
    ctx.fillRect(-3, -26, 6, 4)
    // overalls strap
    ctx.fillStyle = '#f4d35e'
    ctx.fillRect(-5, -10, 2, 6)
    ctx.fillRect(3, -10, 2, 6)
    // legs
    const leg = p.moving ? Math.sin(p.anim) * 3 : 0
    ctx.fillStyle = '#2b4a6f'
    ctx.fillRect(-4, 2, 3, 6 + leg)
    ctx.fillRect(1, 2, 3, 6 - leg)
    // rod
    ctx.strokeStyle = '#8b5a2b'
    ctx.lineWidth = 1.2
    ctx.beginPath()
    ctx.moveTo(5, -8)
    ctx.lineTo(16, -22)
    ctx.stroke()
  }
  ctx.restore()

  // fishing line when casting
  if (state.phase === 'fishing') {
    ctx.save()
    ctx.strokeStyle = 'rgba(255,255,255,0.55)'
    ctx.lineWidth = 1
    ctx.beginPath()
    ctx.moveTo(sx + 14 * p.facing, sy - 18)
    const tipX = sx + 50 * p.facing
    const tipY = sy + 30 + Math.sin(state.time * 4) * 3
    ctx.quadraticCurveTo(sx + 30 * p.facing, sy, tipX, tipY)
    ctx.stroke()
    ctx.fillStyle = '#fff'
    ctx.beginPath()
    ctx.arc(tipX, tipY, 2.5, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
  }
}

function drawHud(
  ctx: CanvasRenderingContext2D,
  state: GameState,
  images: Images,
  w: number,
): void {
  const padTop = 14
  const padX = 12

  // Gold
  roundRect(ctx, padX, padTop, 110, 34, 10)
  ctx.fillStyle = PALETTE.uiBg
  ctx.fill()
  ctx.strokeStyle = PALETTE.uiBorder
  ctx.lineWidth = 1.5
  ctx.stroke()
  const goldImg = images.icon_gold
  if (goldImg && goldImg.complete) ctx.drawImage(goldImg, padX + 6, padTop + 4, 26, 26)
  else {
    ctx.fillStyle = PALETTE.gold
    ctx.beginPath()
    ctx.arc(padX + 19, padTop + 17, 10, 0, Math.PI * 2)
    ctx.fill()
  }
  ctx.fillStyle = PALETTE.text
  ctx.font = 'bold 16px system-ui, sans-serif'
  ctx.textAlign = 'left'
  ctx.textBaseline = 'middle'
  ctx.fillText(String(Math.floor(state.gold)), padX + 38, padTop + 18)

  // Bait
  roundRect(ctx, padX + 120, padTop, 120, 34, 10)
  ctx.fillStyle = PALETTE.uiBg
  ctx.fill()
  ctx.strokeStyle = PALETTE.uiBorder
  ctx.stroke()
  const baitImg = images.icon_bait
  if (baitImg && baitImg.complete) ctx.drawImage(baitImg, padX + 126, padTop + 4, 26, 26)
  else {
    ctx.fillStyle = '#ff8fab'
    ctx.fillRect(padX + 132, padTop + 10, 14, 14)
  }
  ctx.fillStyle = PALETTE.text
  ctx.fillText(`${state.bait} · Nv${state.baitTier + 1}`, padX + 158, padTop + 18)

  // Basket
  const bw = 100
  roundRect(ctx, w - padX - bw, padTop, bw, 34, 10)
  ctx.fillStyle = PALETTE.uiBg
  ctx.fill()
  ctx.strokeStyle = PALETTE.uiBorder
  ctx.stroke()
  ctx.fillStyle = PALETTE.text
  ctx.textAlign = 'center'
  ctx.fillText(`🐟 ${basketCount(state)}`, w - padX - bw / 2, padTop + 18)

  // Basket preview chips
  if (state.basket.length > 0) {
    let cx = w - padX - 16
    const cy = padTop + 48
    for (let i = state.basket.length - 1; i >= 0; i--) {
      const item = state.basket[i]
      const key = FISH_META[item.kind].key
      const fi = images[key]
      if (fi && fi.complete) ctx.drawImage(fi, cx - 18, cy - 10, 28, 28)
      else {
        ctx.fillStyle = FISH_META[item.kind].color
        ctx.beginPath()
        ctx.ellipse(cx, cy + 4, 12, 7, 0, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.fillStyle = '#fff'
      ctx.font = 'bold 11px system-ui'
      ctx.textAlign = 'right'
      ctx.fillText(`×${item.count}`, cx + 10, cy + 22)
      cx -= 36
    }
  }
}

function drawFishingBar(
  ctx: CanvasRenderingContext2D,
  state: GameState,
  w: number,
  h: number,
): void {
  if (state.phase !== 'fishing') return
  const barW = Math.min(280, w - 48)
  const barH = 28
  const x = (w - barW) / 2
  const y = h * 0.28

  // Panel
  roundRect(ctx, x - 16, y - 48, barW + 32, 110, 14)
  ctx.fillStyle = 'rgba(12, 18, 28, 0.82)'
  ctx.fill()
  ctx.strokeStyle = PALETTE.amber
  ctx.lineWidth = 2
  ctx.stroke()

  ctx.fillStyle = PALETTE.text
  ctx.font = 'bold 15px system-ui, sans-serif'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'

  if (state.fish.waiting > 0) {
    ctx.fillText('Esperando o peixe morder…', w / 2, y - 18)
    const dots = '.'.repeat(1 + (Math.floor(state.time * 3) % 3))
    ctx.fillStyle = PALETTE.textDim
    ctx.fillText(dots, w / 2, y + 14)
    return
  }

  if (state.fish.result === 'ok') {
    ctx.fillStyle = PALETTE.green
    ctx.fillText('Pegou!', w / 2, y + 8)
    return
  }
  if (state.fish.result === 'miss') {
    ctx.fillStyle = PALETTE.red
    ctx.fillText('Escapou…', w / 2, y + 8)
    return
  }

  ctx.fillText('Toque no momento certo!', w / 2, y - 22)

  // Track
  roundRect(ctx, x, y, barW, barH, 8)
  ctx.fillStyle = '#1a2332'
  ctx.fill()

  // Green window
  const win = FISHING.windowByBait[state.baitTier]
  const wx = x + (0.5 - win) * barW
  const ww = win * 2 * barW
  ctx.fillStyle = 'rgba(125, 206, 130, 0.55)'
  ctx.fillRect(wx, y + 2, ww, barH - 4)
  ctx.strokeStyle = PALETTE.green
  ctx.lineWidth = 2
  ctx.strokeRect(wx, y + 2, ww, barH - 4)

  // Cursor
  const cx = x + state.fish.bar * barW
  ctx.fillStyle = '#fff8e7'
  ctx.beginPath()
  ctx.moveTo(cx, y - 2)
  ctx.lineTo(cx + 7, y + barH / 2)
  ctx.lineTo(cx, y + barH + 2)
  ctx.lineTo(cx - 7, y + barH / 2)
  ctx.closePath()
  ctx.fill()
  ctx.strokeStyle = PALETTE.amber
  ctx.lineWidth = 1.5
  ctx.stroke()

  ctx.fillStyle = PALETTE.textDim
  ctx.font = '12px system-ui'
  ctx.fillText(`Isca Nv${state.baitTier + 1} · janela ${Math.round(win * 200)}%`, w / 2, y + 48)
}

function drawControls(
  ctx: CanvasRenderingContext2D,
  input: TouchControlState,
  hint: string,
  w: number,
  h: number,
  btn: { x: number; y: number },
): void {
  // Joystick
  const ox = input.joyActive ? input.joyOriginX : JOYSTICK.margin + JOYSTICK.baseR + 8
  const oy = input.joyActive ? input.joyOriginY : h - JOYSTICK.margin - JOYSTICK.baseR - 28
  const kx = input.joyActive ? input.joyKnobX : ox
  const ky = input.joyActive ? input.joyKnobY : oy

  ctx.save()
  ctx.globalAlpha = input.joyActive ? 0.55 : 0.35
  ctx.beginPath()
  ctx.arc(ox, oy, JOYSTICK.baseR, 0, Math.PI * 2)
  ctx.fillStyle = 'rgba(20,24,32,0.55)'
  ctx.fill()
  ctx.strokeStyle = 'rgba(215,143,86,0.7)'
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.beginPath()
  ctx.arc(kx, ky, JOYSTICK.knobR, 0, Math.PI * 2)
  ctx.fillStyle = 'rgba(244,211,94,0.85)'
  ctx.fill()
  ctx.restore()

  // Action button
  const pressed = input.btnPressed || input.actionHeld
  ctx.save()
  ctx.globalAlpha = 0.85
  ctx.beginPath()
  ctx.arc(btn.x, btn.y, ACTION_BTN.r + (pressed ? -2 : 0), 0, Math.PI * 2)
  ctx.fillStyle = pressed ? '#e09a4a' : 'rgba(215,143,86,0.9)'
  ctx.fill()
  ctx.strokeStyle = '#fff8e7'
  ctx.lineWidth = 2.5
  ctx.stroke()
  ctx.fillStyle = '#1a1520'
  ctx.font = 'bold 13px system-ui, sans-serif'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(hint, btn.x, btn.y)
  ctx.restore()

  // Safe-area friendly bottom hint
  ctx.fillStyle = 'rgba(255,248,231,0.45)'
  ctx.font = '11px system-ui'
  ctx.textAlign = 'center'
  ctx.fillText('Arraste ◉  ·  Toque ○', w / 2, h - 10)
}

function drawParticles(ctx: CanvasRenderingContext2D, state: GameState): void {
  for (const p of state.particles) {
    ctx.globalAlpha = Math.max(0, p.life / p.maxLife)
    ctx.fillStyle = p.color
    ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size)
  }
  ctx.globalAlpha = 1
  for (const f of state.floats) {
    ctx.globalAlpha = Math.max(0, f.life / f.maxLife)
    ctx.fillStyle = f.color
    ctx.font = 'bold 14px system-ui'
    ctx.textAlign = 'center'
    ctx.fillText(f.text, f.x, f.y)
  }
  ctx.globalAlpha = 1
}

function drawToast(ctx: CanvasRenderingContext2D, state: GameState, w: number, h: number): void {
  if (state.toast.life <= 0 || !state.toast.text) return
  const alpha = Math.min(1, state.toast.life * 2)
  ctx.save()
  ctx.globalAlpha = alpha
  const tw = Math.min(w - 40, 280)
  roundRect(ctx, (w - tw) / 2, h * 0.18, tw, 36, 12)
  ctx.fillStyle = 'rgba(20,24,32,0.88)'
  ctx.fill()
  ctx.strokeStyle = PALETTE.amber
  ctx.stroke()
  ctx.fillStyle = PALETTE.text
  ctx.font = '13px system-ui'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(state.toast.text, w / 2, h * 0.18 + 18)
  ctx.restore()
}

function drawTitle(ctx: CanvasRenderingContext2D, state: GameState, w: number, h: number): void {
  // Dim vignette
  const g = ctx.createRadialGradient(w / 2, h * 0.4, 40, w / 2, h * 0.4, h * 0.7)
  g.addColorStop(0, 'rgba(10,14,22,0.15)')
  g.addColorStop(1, 'rgba(10,14,22,0.72)')
  ctx.fillStyle = g
  ctx.fillRect(0, 0, w, h)

  const bob = Math.sin(state.time * 2) * 4
  ctx.textAlign = 'center'
  ctx.fillStyle = PALETTE.amber
  ctx.font = 'bold 36px system-ui, Georgia, serif'
  ctx.fillText('Lago Dourado', w / 2, h * 0.28 + bob)
  ctx.fillStyle = PALETTE.text
  ctx.font = '15px system-ui'
  ctx.fillText('Pesca aconchegante · pixel 16-bit', w / 2, h * 0.28 + 34 + bob)

  // Floating fish deco
  ctx.save()
  ctx.translate(w / 2 + Math.sin(state.time) * 40, h * 0.48 + Math.cos(state.time * 1.3) * 10)
  ctx.rotate(Math.sin(state.time * 0.8) * 0.2)
  ctx.fillStyle = '#6ec6ff'
  ctx.beginPath()
  ctx.ellipse(0, 0, 22, 10, 0, 0, Math.PI * 2)
  ctx.fill()
  ctx.fillStyle = '#fff'
  ctx.beginPath()
  ctx.arc(10, -2, 2, 0, Math.PI * 2)
  ctx.fill()
  ctx.restore()

  roundRect(ctx, w / 2 - 90, h * 0.62, 180, 48, 16)
  ctx.fillStyle = 'rgba(215,143,86,0.95)'
  ctx.fill()
  ctx.fillStyle = '#1a1520'
  ctx.font = 'bold 18px system-ui'
  ctx.fillText('TOCAR PARA PESCAR', w / 2, h * 0.62 + 26)

  if (state.bestGold > 0) {
    ctx.fillStyle = PALETTE.textDim
    ctx.font = '12px system-ui'
    ctx.fillText(`Melhor ouro: ${state.bestGold}`, w / 2, h * 0.62 + 66)
  }

  ctx.fillStyle = 'rgba(255,248,231,0.5)'
  ctx.font = '12px system-ui'
  ctx.fillText('Joystick · Botão de ação · Sem game over', w / 2, h * 0.86)
}

function worldToScreen(
  state: GameState,
  images: Images,
  viewW: number,
  viewH: number,
): { scale: number; ox: number; oy: number } {
  // Map world coords (WORLD.w × WORLD.h design space) onto the cover-fitted bg.
  const bg = images.bg_farm_lake
  if (bg && bg.complete && bg.naturalWidth) {
    const scale = Math.max(viewW / bg.naturalWidth, viewH / bg.naturalHeight)
    const dw = bg.naturalWidth * scale
    const dh = bg.naturalHeight * scale
    const ox = (viewW - dw) / 2
    const oy = (viewH - dh) / 2
    // World is authored in 360×640 matching portrait bg aspect — scale world→bg
    const sx = dw / WORLD.w
    const sy = dh / WORLD.h
    return { scale: (sx + sy) / 2, ox, oy }
  }
  const scale = Math.min(viewW / WORLD.w, viewH / WORLD.h)
  return {
    scale,
    ox: (viewW - WORLD.w * scale) / 2,
    oy: (viewH - WORLD.h * scale) / 2,
  }
}

function toScreen(
  wx: number,
  wy: number,
  map: { scale: number; ox: number; oy: number },
  images: Images,
  viewW: number,
  viewH: number,
): { x: number; y: number } {
  const bg = images.bg_farm_lake
  if (bg && bg.complete && bg.naturalWidth) {
    const scale = Math.max(viewW / bg.naturalWidth, viewH / bg.naturalHeight)
    const dw = bg.naturalWidth * scale
    const dh = bg.naturalHeight * scale
    const ox = (viewW - dw) / 2
    const oy = (viewH - dh) / 2
    return {
      x: ox + (wx / WORLD.w) * dw,
      y: oy + (wy / WORLD.h) * dh,
    }
  }
  return { x: map.ox + wx * map.scale, y: map.oy + wy * map.scale }
}

export function render(
  ctx: CanvasRenderingContext2D,
  state: GameState,
  size: { w: number; h: number },
  images: Images,
  input: TouchControlState,
  btn: { x: number; y: number },
): void {
  const { w, h } = size
  if (w <= 0 || h <= 0) return

  ctx.clearRect(0, 0, w, h)

  const shake = state.trauma * state.trauma * 10
  ctx.save()
  if (shake > 0.1) {
    ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake)
  }

  drawBg(ctx, images.bg_farm_lake, w, h, state.time)

  const map = worldToScreen(state, images, w, h)
  const sp = toScreen(state.player.x, state.player.y, map, images, w, h)

  // Soft interact markers near player only
  if (state.phase === 'play') {
    const near = (r: { x: number; y: number; w: number; h: number }) =>
      state.player.x > r.x - 30 &&
      state.player.x < r.x + r.w + 30 &&
      state.player.y > r.y - 30 &&
      state.player.y < r.y + r.h + 30
    ctx.save()
    const pulse = 0.18 + 0.1 * Math.sin(state.time * 3)
    if (near(ZONES.shore)) {
      ctx.globalAlpha = pulse
      const s0 = toScreen(ZONES.shore.x, ZONES.shore.y, map, images, w, h)
      const s1 = toScreen(
        ZONES.shore.x + ZONES.shore.w,
        ZONES.shore.y + ZONES.shore.h,
        map,
        images,
        w,
        h,
      )
      ctx.fillStyle = '#7ec8e3'
      ctx.fillRect(s0.x, s0.y, s1.x - s0.x, s1.y - s0.y)
    }
    if (near(ZONES.stall)) {
      ctx.globalAlpha = pulse
      const t0 = toScreen(ZONES.stall.x, ZONES.stall.y, map, images, w, h)
      const t1 = toScreen(
        ZONES.stall.x + ZONES.stall.w,
        ZONES.stall.y + ZONES.stall.h,
        map,
        images,
        w,
        h,
      )
      ctx.fillStyle = '#f4d35e'
      ctx.fillRect(t0.x, t0.y, t1.x - t0.x, t1.y - t0.y)
    }
    ctx.restore()
  }

  drawPlayer(ctx, state, images, sp.x, sp.y)

  // remap particle/float positions are already in world — convert while drawing
  ctx.save()
  for (const p of state.particles) {
    const pp = toScreen(p.x, p.y, map, images, w, h)
    ctx.globalAlpha = Math.max(0, p.life / p.maxLife)
    ctx.fillStyle = p.color
    ctx.fillRect(pp.x - p.size / 2, pp.y - p.size / 2, p.size, p.size)
  }
  ctx.globalAlpha = 1
  for (const f of state.floats) {
    const fp = toScreen(f.x, f.y, map, images, w, h)
    ctx.globalAlpha = Math.max(0, f.life / f.maxLife)
    ctx.fillStyle = f.color
    ctx.font = 'bold 14px system-ui'
    ctx.textAlign = 'center'
    ctx.fillText(f.text, fp.x, fp.y)
  }
  ctx.globalAlpha = 1
  ctx.restore()

  ctx.restore() // shake

  if (state.phase === 'title') {
    drawTitle(ctx, state, w, h)
  } else {
    drawHud(ctx, state, images, w)
    drawFishingBar(ctx, state, w, h)
    drawToast(ctx, state, w, h)
    drawControls(ctx, input, actionHint(state), w, h, btn)

    // Stall value tip
    if (state.phase === 'play' && basketCount(state) > 0) {
      ctx.fillStyle = 'rgba(255,248,231,0.55)'
      ctx.font = '11px system-ui'
      ctx.textAlign = 'center'
      ctx.fillText(`Cesta: ${basketValue(state)} ouro · vá ao balcão`, w / 2, 64)
    }
  }

  }
