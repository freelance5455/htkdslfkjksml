import { T, SOLID_MIN, type BuiltArea, type Prop } from "./data/areas";
import { getCharacterSprite, getTileArt, TILE } from "./art";
import type { GameState } from "./types";

export let VIEW_W = 480;
export let VIEW_H = 272;

export function setViewSize(w: number, h: number) {
  VIEW_W = w;
  VIEW_H = h;
}

const staticCache = new Map<string, HTMLCanvasElement>();
const animatedProps = new Set(["torch", "brazier", "candle", "campfire", "forge"]);

export function getStaticLayer(area: BuiltArea): HTMLCanvasElement {
  const hit = staticCache.get(area.def.id);
  if (hit) return hit;
  const c = document.createElement("canvas");
  c.width = area.def.w * TILE;
  c.height = area.def.h * TILE;
  const ctx = c.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  for (let y = 0; y < area.def.h; y++) {
    for (let x = 0; x < area.def.w; x++) {
      const t = area.tiles[y * area.def.w + x];
      if (t === 0) continue;
      const art = getTileArt(t);
      const variant = (x * 7 + y * 13) % art.length;
      ctx.drawImage(art[variant], x * TILE, y * TILE);
    }
  }
  area.props.forEach((p) => {
    if (animatedProps.has(p.kind)) return;
    drawProp(ctx, p, 0);
  });
  staticCache.set(area.def.id, c);
  return c;
}

/* --------------------------------- props -------------------------------- */

export function drawProp(ctx: CanvasRenderingContext2D, p: Prop, t: number) {
  const x = p.x * TILE;
  const y = p.y * TILE;
  const fl = Math.sin(t * 0.012 + p.x * 1.7 + p.y) * 0.5 + 0.5;
  switch (p.kind) {
    case "torch": {
      ctx.fillStyle = "#4a3823";
      ctx.fillRect(x + 7, y + 6, 2, 10);
      ctx.fillStyle = "#ffcf5a";
      ctx.fillRect(x + 6, y + 2 + fl, 4, 4);
      ctx.fillStyle = "#fff2b0";
      ctx.fillRect(x + 7, y + 3 + fl, 2, 2);
      break;
    }
    case "brazier": {
      ctx.fillStyle = "#3b3b45";
      ctx.fillRect(x + 4, y + 10, 8, 3);
      ctx.fillRect(x + 6, y + 13, 4, 3);
      ctx.fillStyle = "#e06a20";
      ctx.fillRect(x + 5, y + 5 + fl, 6, 5);
      ctx.fillStyle = "#ffcf5a";
      ctx.fillRect(x + 6, y + 6 + fl, 4, 3);
      break;
    }
    case "campfire": {
      ctx.fillStyle = "#4a3823";
      ctx.fillRect(x + 3, y + 10, 10, 2);
      ctx.fillRect(x + 6, y + 8, 2, 4);
      ctx.fillRect(x + 9, y + 8, 2, 4);
      ctx.fillStyle = "#e06020";
      ctx.fillRect(x + 4, y + 3 + fl, 8, 6);
      ctx.fillStyle = "#ffcf5a";
      ctx.fillRect(x + 6, y + 4 + fl, 4, 3);
      break;
    }
    case "candle": {
      ctx.fillStyle = "#e8e0cc";
      ctx.fillRect(x + 7, y + 10, 2, 5);
      ctx.fillStyle = "#ffdf9a";
      ctx.fillRect(x + 7, y + 7 + fl, 2, 3);
      break;
    }
    case "forge": {
      ctx.fillStyle = "#4a4a52";
      ctx.fillRect(x, y + 4, TILE * 3, TILE * 2 - 4);
      ctx.fillStyle = "#2a2a32";
      ctx.fillRect(x + 6, y + 8, 12, 10);
      ctx.fillStyle = "#ff6a20";
      ctx.fillRect(x + 8, y + 10 + fl, 8, 6);
      ctx.fillStyle = "#ffd070";
      ctx.fillRect(x + 10, y + 11 + fl, 4, 3);
      break;
    }
    case "table": {
      ctx.fillStyle = "#4a3520";
      ctx.fillRect(x + 1, y + 6, 14, 5);
      ctx.fillStyle = "#7a5535";
      ctx.fillRect(x + 1, y + 5, 14, 2);
      ctx.fillStyle = "#5c3f26";
      ctx.fillRect(x + 2, y + 11, 2, 4);
      ctx.fillRect(x + 12, y + 11, 2, 4);
      break;
    }
    case "bench": {
      ctx.fillStyle = "#5c4026";
      ctx.fillRect(x, y + 8, TILE * 2, 4);
      ctx.fillStyle = "#4a3520";
      ctx.fillRect(x + 1, y + 12, 2, 3);
      ctx.fillRect(x + 26, y + 12, 2, 3);
      break;
    }
    case "chair": {
      ctx.fillStyle = "#6b4a2c";
      ctx.fillRect(x + 4, y + 7, 8, 3);
      ctx.fillRect(x + 4, y + 4, 2, 4);
      ctx.fillRect(x + 10, y + 10, 2, 4);
      ctx.fillRect(x + 4, y + 10, 2, 4);
      break;
    }
    case "barrel": {
      ctx.fillStyle = "#6b4a2c";
      ctx.fillRect(x + 3, y + 4, 10, 12);
      ctx.fillStyle = "#8a6440";
      ctx.fillRect(x + 4, y + 5, 8, 10);
      ctx.fillStyle = "#3f3a34";
      ctx.fillRect(x + 3, y + 7, 10, 1);
      ctx.fillRect(x + 3, y + 12, 10, 1);
      break;
    }
    case "crate": {
      ctx.fillStyle = "#6f5330";
      ctx.fillRect(x + 2, y + 4, 12, 12);
      ctx.fillStyle = "#8a6a3f";
      ctx.fillRect(x + 3, y + 5, 10, 10);
      ctx.fillStyle = "#4d3a22";
      ctx.fillRect(x + 3, y + 9, 10, 1);
      ctx.fillRect(x + 7, y + 5, 1, 10);
      break;
    }
    case "sack": {
      ctx.fillStyle = "#a08a5e";
      ctx.fillRect(x + 4, y + 6, 8, 10);
      ctx.fillStyle = "#8a7449";
      ctx.fillRect(x + 5, y + 4, 6, 3);
      break;
    }
    case "shelf": {
      ctx.fillStyle = "#4a3520";
      ctx.fillRect(x + 1, y + 2, 14, 14);
      ctx.fillStyle = "#6b4a2c";
      ctx.fillRect(x + 2, y + 3, 12, 12);
      const cols = ["#8a3a3a", "#3a6a8a", "#8a7a3a", "#4a7a4a"];
      for (let i = 0; i < 6; i++) {
        ctx.fillStyle = cols[i % cols.length];
        ctx.fillRect(x + 3 + (i % 3) * 4, y + 4 + Math.floor(i / 3) * 5, 3, 4);
      }
      break;
    }
    case "banner": {
      ctx.fillStyle = "#6b1f2a";
      ctx.fillRect(x + 3, y, 10, 14);
      ctx.fillStyle = "#8c2b39";
      ctx.fillRect(x + 4, y + 1, 8, 12);
      ctx.fillStyle = "#f0c14b";
      ctx.fillRect(x + 7, y + 5, 2, 5);
      ctx.fillRect(x + 5, y + 6, 6, 1);
      break;
    }
    case "pillar": {
      ctx.fillStyle = "#6e6e78";
      ctx.fillRect(x + 3, y - 8, 10, 24);
      ctx.fillStyle = "#8a8a95";
      ctx.fillRect(x + 4, y - 8, 3, 24);
      ctx.fillStyle = "#54545e";
      ctx.fillRect(x + 2, y - 10, 12, 3);
      ctx.fillRect(x + 2, y + 14, 12, 3);
      break;
    }
    case "statue": {
      ctx.fillStyle = "#7c7c88";
      ctx.fillRect(x + 2, y - 6, 12, 20);
      ctx.fillStyle = "#9a9aa6";
      ctx.fillRect(x + 4, y - 6, 3, 16);
      ctx.fillRect(x + 6, y - 12, 5, 7);
      ctx.fillRect(x + 2, y + 12, 12, 3);
      break;
    }
    case "well": {
      ctx.fillStyle = "#6a6a72";
      ctx.fillRect(x - 4, y + 2, 24, 12);
      ctx.fillStyle = "#86868f";
      ctx.fillRect(x - 4, y + 2, 24, 3);
      ctx.fillStyle = "#2b3a4a";
      ctx.fillRect(x - 1, y + 5, 18, 7);
      ctx.fillStyle = "#5c3f26";
      ctx.fillRect(x + 1, y - 8, 2, 12);
      ctx.fillRect(x + 13, y - 8, 2, 12);
      ctx.fillStyle = "#8a6a3f";
      ctx.fillRect(x + 1, y - 9, 14, 2);
      break;
    }
    case "hay": {
      ctx.fillStyle = "#a8913f";
      ctx.fillRect(x + 2, y + 5, 12, 11);
      ctx.fillStyle = "#c2a94f";
      ctx.fillRect(x + 3, y + 6, 10, 8);
      ctx.fillStyle = "#7d6a2c";
      ctx.fillRect(x + 4, y + 9, 8, 1);
      break;
    }
    case "cart": {
      ctx.fillStyle = "#5c4026";
      ctx.fillRect(x - 6, y + 4, 28, 8);
      ctx.fillStyle = "#7a5535";
      ctx.fillRect(x - 6, y + 4, 28, 2);
      ctx.fillStyle = "#3a3a40";
      ctx.fillRect(x - 2, y + 12, 5, 5);
      ctx.fillRect(x + 12, y + 12, 5, 5);
      ctx.fillStyle = "#2a2a30";
      ctx.fillRect(x - 1, y + 13, 3, 3);
      ctx.fillRect(x + 13, y + 13, 3, 3);
      break;
    }
    case "boat": {
      ctx.fillStyle = "#4a3520";
      ctx.fillRect(x - 10, y + 2, 36, 10);
      ctx.fillStyle = "#6b4a2c";
      ctx.fillRect(x - 10, y + 2, 36, 3);
      ctx.fillStyle = "#2a2a30";
      ctx.fillRect(x + 6, y - 14, 2, 16);
      ctx.fillStyle = "#c8c0aa";
      ctx.fillRect(x + 8, y - 13, 10, 12);
      break;
    }
    case "chest": {
      ctx.fillStyle = "#4a3520";
      ctx.fillRect(x + 3, y + 7, 10, 8);
      ctx.fillStyle = "#6b4a2c";
      ctx.fillRect(x + 3, y + 6, 10, 5);
      ctx.fillStyle = "#f0c14b";
      ctx.fillRect(x + 7, y + 9, 2, 4);
      break;
    }
    case "flower": {
      ctx.fillStyle = "#3f6b34";
      ctx.fillRect(x + 7, y + 8, 2, 7);
      ctx.fillStyle = "#d05a7a";
      ctx.fillRect(x + 6, y + 5, 4, 4);
      ctx.fillStyle = "#f0c14b";
      ctx.fillRect(x + 7, y + 6, 2, 2);
      break;
    }
    case "fence": {
      ctx.fillStyle = "#5c4026";
      ctx.fillRect(x, y + 6, TILE, 3);
      ctx.fillRect(x + 3, y + 3, 2, 10);
      ctx.fillRect(x + 11, y + 3, 2, 10);
      break;
    }
    case "anvil": {
      ctx.fillStyle = "#3f3f48";
      ctx.fillRect(x + 3, y + 6, 10, 4);
      ctx.fillRect(x + 6, y + 10, 4, 5);
      ctx.fillStyle = "#565662";
      ctx.fillRect(x + 4, y + 5, 8, 2);
      break;
    }
    case "stall": {
      ctx.fillStyle = "#5c4026";
      ctx.fillRect(x - 4, y + 2, 24, 4);
      ctx.fillStyle = "#a04a4a";
      ctx.fillRect(x - 4, y, 24, 4);
      ctx.fillStyle = "#c0c0c0";
      ctx.fillRect(x - 4, y, 24, 1);
      ctx.fillStyle = "#7a5535";
      ctx.fillRect(x - 4, y + 6, 24, 8);
      ctx.fillStyle = "#8a6440";
      ctx.fillRect(x - 2, y + 8, 6, 4);
      ctx.fillRect(x + 8, y + 8, 6, 4);
      ctx.fillStyle = "#4a3520";
      ctx.fillRect(x - 3, y + 14, 2, 2);
      ctx.fillRect(x + 21, y + 14, 2, 2);
      break;
    }
    case "sign": {
      ctx.fillStyle = "#5c4026";
      ctx.fillRect(x + 7, y + 8, 2, 8);
      ctx.fillStyle = "#7a5535";
      ctx.fillRect(x + 2, y + 3, 12, 6);
      ctx.fillStyle = "#3f2c19";
      ctx.fillRect(x + 4, y + 5, 8, 1);
      ctx.fillRect(x + 4, y + 7, 5, 1);
      break;
    }
    case "grave": {
      ctx.fillStyle = "#6a6a72";
      ctx.fillRect(x + 4, y + 2, 8, 13);
      ctx.fillStyle = "#8a8a95";
      ctx.fillRect(x + 5, y + 2, 3, 11);
      ctx.fillStyle = "#4a4a52";
      ctx.fillRect(x + 5, y + 7, 5, 1);
      ctx.fillRect(x + 7, y + 5, 1, 4);
      break;
    }
    case "throne": {
      ctx.fillStyle = "#f0c14b";
      ctx.fillRect(x - 6, y - 12, 28, 28);
      ctx.fillStyle = "#c9922f";
      ctx.fillRect(x - 3, y - 9, 22, 22);
      ctx.fillStyle = "#8c1f2b";
      ctx.fillRect(x + 1, y - 5, 14, 16);
      ctx.fillStyle = "#f0c14b";
      ctx.fillRect(x + 5, y - 2, 6, 6);
      break;
    }
    case "altar": {
      ctx.fillStyle = "#ada694";
      ctx.fillRect(x - 2, y + 4, 20, 10);
      ctx.fillStyle = "#c4bdab";
      ctx.fillRect(x - 2, y + 4, 20, 2);
      ctx.fillStyle = "#f0c14b";
      ctx.fillRect(x + 5, y - 6, 6, 9);
      ctx.fillRect(x + 7, y - 9, 2, 3);
      break;
    }
    case "rug": {
      ctx.fillStyle = "#5c1f2a";
      ctx.fillRect(x - 8, y - 8, 32, 32);
      ctx.fillStyle = "#7a2b38";
      ctx.fillRect(x - 5, y - 5, 26, 26);
      ctx.fillStyle = "#c9a45a";
      ctx.fillRect(x, y, 16, 16);
      break;
    }
    default:
      break;
  }
}

/* -------------------------------- render --------------------------------- */

export interface RenderInput {
  ctx: CanvasRenderingContext2D;
  state: GameState;
  area: BuiltArea;
  npcPositions: Record<string, { x: number; y: number; dir: string; frame: number; palette: any; crown?: boolean; hood?: boolean }>;
  time: number;
  shake: number;
  flash: { a: number; c: string } | null;
  marker?: { x: number; y: number } | null;
}

export function renderScene(input: RenderInput) {
  const { ctx, state, area, time } = input;
  const camX = Math.max(0, Math.min(area.def.w * TILE - VIEW_W, state.player.x * TILE - VIEW_W / 2));
  const camY = Math.max(0, Math.min(area.def.h * TILE - VIEW_H, state.player.y * TILE - VIEW_H / 2));

  ctx.save();
  if (input.shake > 0) {
    const s = input.shake;
    ctx.translate((Math.random() - 0.5) * s, (Math.random() - 0.5) * s);
  }

  ctx.fillStyle = "#0a0810";
  ctx.fillRect(-10, -10, VIEW_W + 20, VIEW_H + 20);

  const stat = getStaticLayer(area);
  ctx.drawImage(stat, -Math.round(camX), -Math.round(camY));

  // animated props
  area.props.forEach((p) => {
    if (!animatedProps.has(p.kind)) return;
    drawProp(ctx, p, time);
  });

  // portals
  area.portals.forEach((pt) => {
    const px = pt.x * TILE - camX;
    const py = pt.y * TILE - camY;
    const pulse = 0.5 + Math.sin(time * 0.004 + pt.x) * 0.5;
    ctx.save();
    ctx.globalAlpha = 0.35 + pulse * 0.3;
    ctx.fillStyle = "#8fd8ff";
    ctx.fillRect(px, py, TILE, TILE);
    ctx.globalAlpha = 0.8;
    ctx.fillStyle = "#dff4ff";
    ctx.fillRect(px + 3, py + 3, 10, 10);
    ctx.restore();
  });

  // world items
  state.worldItems.forEach((it) => {
    if (it.areaId !== area.def.id) return;
    const px = it.x * TILE - camX;
    const py = it.y * TILE - camY;
    const bob = Math.sin(time * 0.005 + it.x) * 2;
    ctx.save();
    ctx.globalAlpha = 0.35;
    ctx.fillStyle = "#ffe9a0";
    ctx.beginPath();
    ctx.arc(px + 8, py + 8 + bob, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    ctx.fillStyle = "#f0c14b";
    ctx.fillRect(px + 4, py + 5 + bob, 8, 7);
    ctx.fillStyle = "#fff0c0";
    ctx.fillRect(px + 5, py + 6 + bob, 3, 2);
  });

  // npcs
  const sorted: { y: number; draw: () => void }[] = [];
  Object.entries(input.npcPositions).forEach(([, n]) => {
    if (!n) return;
    const px = n.x * TILE - camX;
    const py = n.y * TILE - camY;
    if (px < -30 || px > VIEW_W + 30 || py < -40 || py > VIEW_H + 30) return;
    sorted.push({
      y: n.y,
      draw: () => {
        const spr = getCharacterSprite({
          skin: n.palette.skin,
          hair: n.palette.hair,
          cloth: n.palette.cloth,
          accent: n.palette.accent,
          dir: n.dir as any,
          frame: n.frame,
          crown: n.crown,
          hood: n.hood,
          cape: n.palette.accent !== "#8c1f2b",
        });
        ctx.drawImage(spr, Math.round(px - 2), Math.round(py - 4));
      },
    });
  });

  // player
  const ppx = state.player.x * TILE - camX;
  const ppy = state.player.y * TILE - camY;
  sorted.push({
    y: state.player.y,
    draw: () => {
      const spr = getCharacterSprite({
        skin: "#e0ac79",
        hair: "#3b2a1a",
        cloth: "#2f3b58",
        accent: "#c9a45a",
        dir: state.player.facing,
        frame: state.player.moving ? state.player.anim : 0,
        cape: true,
      });
      ctx.drawImage(spr, Math.round(ppx - 2), Math.round(ppy - 4));
      if (state.currentMission !== null) {
        const bounce = Math.sin(time * 0.006) * 1.5;
        ctx.fillStyle = "#ffe08a";
        ctx.fillRect(Math.round(ppx + 4), Math.round(ppy - 16 + bounce), 3, 3);
      }
    },
  });

  sorted.sort((a, b) => a.y - b.y);
  sorted.forEach((s) => s.draw());

  // particles
  if (state.particles.length > 140) state.particles.splice(0, state.particles.length - 140);
  state.particles.forEach((pt) => {
    const a = Math.max(0, pt.life / pt.maxLife);
    ctx.globalAlpha = a;
    ctx.fillStyle = pt.color;
    if (pt.glow) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.fillRect(pt.x - camX - pt.size / 2, pt.y - camY - pt.size / 2, pt.size, pt.size);
      ctx.restore();
    } else {
      ctx.fillRect(Math.round(pt.x - camX), Math.round(pt.y - camY), pt.size, pt.size);
    }
  });
  ctx.globalAlpha = 1;

  // floating text
  state.floaters.forEach((f) => {
    const a = Math.max(0, Math.min(1, f.life / f.maxLife));
    ctx.globalAlpha = a;
    ctx.fillStyle = "#100c14";
    ctx.fillRect(Math.round(f.x - camX - 1), Math.round(f.y - camY - 9), 8, 8);
    ctx.fillStyle = f.color;
    ctx.fillRect(Math.round(f.x - camX), Math.round(f.y - camY - 8), 6, 6);
    ctx.globalAlpha = 1;
  });

  // quest marker (drawn after lighting further down)
  if (input.marker) {
    const bx = input.marker.x * TILE - camX + 4;
    const by = input.marker.y * TILE - camY - 16 + Math.sin(time * 0.006) * 1.6;
    ctx.fillStyle = "#12101c";
    ctx.fillRect(bx - 1, by - 1, 10, 14);
    ctx.fillStyle = "#f0c14b";
    ctx.fillRect(bx, by, 8, 3);
    ctx.fillRect(bx + 3, by + 4, 2, 5);
    ctx.fillRect(bx + 3, by + 10, 2, 2);
  }

  // lighting
  drawLighting(ctx, area, state, camX, camY, time);

  if (input.flash && input.flash.a > 0) {
    ctx.globalAlpha = Math.min(0.75, input.flash.a);
    ctx.fillStyle = input.flash.c;
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    ctx.globalAlpha = 1;
  }

  ctx.restore();
}

const lightCache = new Map<number, HTMLCanvasElement>();

/** Pre-rendered radial falloff sprite: punched out of the darkness layer. */
function getLightSprite(r: number): HTMLCanvasElement {
  const key = Math.round(r / 8) * 8;
  const hit = lightCache.get(key);
  if (hit) return hit;
  const size = key * 2;
  const c = document.createElement("canvas");
  c.width = size;
  c.height = size;
  const g = c.getContext("2d")!;
  const grad = g.createRadialGradient(key, key, 0, key, key, key);
  grad.addColorStop(0, "rgba(0,0,0,1)");
  grad.addColorStop(0.55, "rgba(0,0,0,0.72)");
  grad.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, size, size);
  lightCache.set(key, c);
  return c;
}

let lightCanvas: HTMLCanvasElement | null = null;

function drawLighting(
  ctx: CanvasRenderingContext2D,
  area: BuiltArea,
  state: GameState,
  camX: number,
  camY: number,
  time: number
) {
  const dark = area.def.dark;
  if (dark <= 0.02) return;
  if (!lightCanvas || lightCanvas.width !== VIEW_W || lightCanvas.height !== VIEW_H) {
    lightCanvas = document.createElement("canvas");
    lightCanvas.width = VIEW_W;
    lightCanvas.height = VIEW_H;
  }
  const lctx = lightCanvas.getContext("2d")!;
  lctx.globalCompositeOperation = "source-over";
  lctx.clearRect(0, 0, VIEW_W, VIEW_H);
  lctx.fillStyle = `rgba(6,4,14,${dark})`;
  lctx.fillRect(0, 0, VIEW_W, VIEW_H);
  lctx.globalCompositeOperation = "destination-out";
  const punch = (wx: number, wy: number, r: number, strength: number) => {
    const px = wx - camX;
    const py = wy - camY;
    if (px < -r || px > VIEW_W + r || py < -r || py > VIEW_H + r) return;
    const sprite = getLightSprite(r);
    lctx.globalAlpha = strength;
    lctx.drawImage(sprite, Math.round(px - r), Math.round(py - r), r * 2, r * 2);
  };
  punch(state.player.x * TILE + 8, state.player.y * TILE + 6, 72 + Math.sin(time * 0.004) * 4, 0.92);
  area.lights.forEach((l) => punch(l.x * TILE + 8, l.y * TILE + 6, l.r, 0.85));
  lctx.globalAlpha = 1;
  lctx.globalCompositeOperation = "source-over";
  ctx.drawImage(lightCanvas, 0, 0);
}

export function solidAt(area: BuiltArea, x: number, y: number): boolean {
  if (x < 0 || y < 0 || x >= area.def.w || y >= area.def.h) return true;
  return area.tiles[y * area.def.w + x] >= SOLID_MIN;
}

export { T };
