import { clamp, GOAL_HALF, HALF_H, HALF_W, lerp } from "./math";
import { camFlip, hairColor, interpBall, interpPlayer, skinColor, type Match, type Player } from "./sim";

export type Cam = { x: number; y: number; scale: number; shakeX: number; shakeY: number };

export function createCam(): Cam {
  return { x: 0, y: 0, scale: 14, shakeX: 0, shakeY: 0 };
}

export function updateCam(cam: Cam, m: Match, dt: number, w: number, h: number, demo: boolean) {
  const b = m.ball;
  const flip = camFlip(m) ? -1 : 1;
  const targetX = b.x + b.vx * 0.18;
  const targetY = b.y + b.vy * 0.12;
  const k = 1 - Math.exp(-(demo ? 2.2 : 5.5) * dt);
  cam.x = lerp(cam.x, targetX, k);
  cam.y = lerp(cam.y, targetY, k);
  const fit = Math.min(w / (HALF_W * 2 + 18), h / (HALF_H * 2 * 0.78 + 16));
  const zoom = demo ? fit * 0.92 : fit * 1.35;
  cam.scale = lerp(cam.scale, zoom, 1 - Math.exp(-3 * dt));
  const trauma = m.trauma * m.trauma;
  const t = performance.now() * 0.017;
  cam.shakeX = Math.sin(t * 37) * trauma * 10;
  cam.shakeY = Math.cos(t * 31) * trauma * 8;
  void flip;
}

export function worldToScreen(cam: Cam, x: number, y: number, z: number, w: number, h: number, flip: boolean) {
  const fx = flip ? -x : x;
  const fy = flip ? -y : y;
  const cx = flip ? -cam.x : cam.x;
  const cy = flip ? -cam.y : cam.y;
  const sx = (fx - cx) * cam.scale + w / 2 + cam.shakeX;
  const sy = (fy - cy) * cam.scale * 0.78 - z * cam.scale * 0.85 + h / 2 + cam.shakeY;
  return { sx, sy, r: cam.scale };
}

function line(ctx: CanvasRenderingContext2D, cam: Cam, x1: number, y1: number, x2: number, y2: number, w: number, h: number, flip: boolean) {
  const a = worldToScreen(cam, x1, y1, 0, w, h, flip);
  const b = worldToScreen(cam, x2, y2, 0, w, h, flip);
  ctx.moveTo(a.sx, a.sy);
  ctx.lineTo(b.sx, b.sy);
}

function ellipseAt(
  ctx: CanvasRenderingContext2D,
  cam: Cam,
  x: number,
  y: number,
  rx: number,
  ry: number,
  w: number,
  h: number,
  flip: boolean,
) {
  const p = worldToScreen(cam, x, y, 0, w, h, flip);
  ctx.ellipse(p.sx, p.sy, rx * cam.scale, ry * cam.scale * 0.78, 0, 0, Math.PI * 2);
}

export function drawWorld(ctx: CanvasRenderingContext2D, m: Match, cam: Cam, alpha: number, demo: boolean) {
  const w = ctx.canvas.width;
  const h = ctx.canvas.height;
  const flip = camFlip(m);

  ctx.fillStyle = "#0c1210";
  ctx.fillRect(0, 0, w, h);

  drawStadium(ctx, cam, w, h, flip, m.excitement);
  drawPitch(ctx, cam, w, h, flip);
  drawGoals(ctx, cam, w, h, flip);

  const order = m.players
    .map((p) => ({ p, i: interpPlayer(p, alpha) }))
    .sort((a, b) => a.i.y - b.i.y);

  const ball = interpBall(m.ball, alpha);
  let ballDrawn = false;
  for (const o of order) {
    if (!ballDrawn && o.i.y > ball.y) {
      drawBall(ctx, cam, ball, w, h, flip);
      ballDrawn = true;
    }
    drawPlayer(ctx, m, o.p, o.i.x, o.i.y, cam, w, h, flip, demo);
  }
  if (!ballDrawn) drawBall(ctx, cam, ball, w, h, flip);

  if (!demo) drawHud(ctx, m, cam, w, h, flip);
}

function drawStadium(ctx: CanvasRenderingContext2D, cam: Cam, w: number, h: number, flip: boolean, excitement: number) {
  const pad = 18;
  const tl = worldToScreen(cam, -HALF_W - pad, -HALF_H - pad, 0, w, h, flip);
  const br = worldToScreen(cam, HALF_W + pad, HALF_H + pad, 0, w, h, flip);
  ctx.fillStyle = "#15221c";
  ctx.fillRect(Math.min(tl.sx, br.sx), Math.min(tl.sy, br.sy), Math.abs(br.sx - tl.sx), Math.abs(br.sy - tl.sy));

  const rows = 5;
  for (let r = 0; r < rows; r++) {
    const y0 = -HALF_H - 4 - r * 2.6;
    const y1 = HALF_H + 4 + r * 2.6;
    for (const y of [y0, y1]) {
      const a = worldToScreen(cam, -HALF_W - 10, y, 0, w, h, flip);
      const b = worldToScreen(cam, HALF_W + 10, y, 0, w, h, flip);
      const pulse = 0.55 + excitement * 0.35 + Math.sin(performance.now() * 0.004 + r) * 0.04;
      ctx.strokeStyle = `rgba(${40 + r * 12},${48 + r * 6},${58}, ${pulse})`;
      ctx.lineWidth = 7 - r;
      ctx.beginPath();
      ctx.moveTo(a.sx, a.sy);
      ctx.lineTo(b.sx, b.sy);
      ctx.stroke();
    }
  }
}

function drawPitch(ctx: CanvasRenderingContext2D, cam: Cam, w: number, h: number, flip: boolean) {
  const stripes = 10;
  const sw = HALF_W * 2 / stripes;
  for (let i = 0; i < stripes; i++) {
    const x0 = -HALF_W + i * sw;
    const a = worldToScreen(cam, x0, -HALF_H, 0, w, h, flip);
    const b = worldToScreen(cam, x0 + sw, HALF_H, 0, w, h, flip);
    ctx.fillStyle = i % 2 === 0 ? "#2f7a46" : "#2a6e40";
    ctx.fillRect(Math.min(a.sx, b.sx), Math.min(a.sy, b.sy), Math.abs(b.sx - a.sx), Math.abs(b.sy - a.sy));
  }

  ctx.strokeStyle = "rgba(255,255,255,0.82)";
  ctx.lineWidth = Math.max(1.2, cam.scale * 0.07);
  ctx.beginPath();
  line(ctx, cam, -HALF_W, -HALF_H, HALF_W, -HALF_H, w, h, flip);
  line(ctx, cam, HALF_W, -HALF_H, HALF_W, HALF_H, w, h, flip);
  line(ctx, cam, HALF_W, HALF_H, -HALF_W, HALF_H, w, h, flip);
  line(ctx, cam, -HALF_W, HALF_H, -HALF_W, -HALF_H, w, h, flip);
  line(ctx, cam, 0, -HALF_H, 0, HALF_H, w, h, flip);
  ctx.stroke();

  ctx.beginPath();
  ellipseAt(ctx, cam, 0, 0, 9.15, 9.15, w, h, flip);
  ctx.stroke();

  ctx.beginPath();
  ellipseAt(ctx, cam, 0, 0, 0.35, 0.35, w, h, flip);
  ctx.fillStyle = "#fff";
  ctx.fill();

  for (const side of [-1, 1] as const) {
    const boxX = HALF_W * side;
    const p16 = boxX - 16.5 * side;
    const p6 = boxX - 5.5 * side;
    ctx.beginPath();
    line(ctx, cam, boxX, -20.16, p16, -20.16, w, h, flip);
    line(ctx, cam, p16, -20.16, p16, 20.16, w, h, flip);
    line(ctx, cam, p16, 20.16, boxX, 20.16, w, h, flip);
    ctx.stroke();
    ctx.beginPath();
    line(ctx, cam, boxX, -9.16, p6, -9.16, w, h, flip);
    line(ctx, cam, p6, -9.16, p6, 9.16, w, h, flip);
    line(ctx, cam, p6, 9.16, boxX, 9.16, w, h, flip);
    ctx.stroke();
    ctx.beginPath();
    ellipseAt(ctx, cam, boxX - 11 * side, 0, 0.28, 0.28, w, h, flip);
    ctx.fill();
    ctx.beginPath();
    ctx.strokeStyle = "rgba(255,255,255,0.7)";
    ellipseAt(ctx, cam, boxX - 11 * side, 0, 9.15, 9.15, w, h, flip);
    ctx.stroke();
    ctx.strokeStyle = "rgba(255,255,255,0.82)";
  }
}

function drawGoals(ctx: CanvasRenderingContext2D, cam: Cam, w: number, h: number, flip: boolean) {
  for (const side of [-1, 1] as const) {
    const x = HALF_W * side;
    const depth = 2.4 * side;
    const posts = [
      [x, -GOAL_HALF],
      [x, GOAL_HALF],
      [x + depth, -GOAL_HALF],
      [x + depth, GOAL_HALF],
    ] as const;
    ctx.strokeStyle = "#f4f6f8";
    ctx.lineWidth = Math.max(2, cam.scale * 0.12);
    ctx.beginPath();
    for (const [px, py] of [
      [posts[0], posts[1]],
      [posts[0], posts[2]],
      [posts[1], posts[3]],
      [posts[2], posts[3]],
    ] as const) {
      line(ctx, cam, px[0], px[1], py[0], py[1], w, h, flip);
    }
    ctx.stroke();
    ctx.strokeStyle = "rgba(230,240,255,0.28)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i <= 6; i++) {
      const yy = -GOAL_HALF + (GOAL_HALF * 2 * i) / 6;
      line(ctx, cam, x, yy, x + depth, yy, w, h, flip);
    }
    ctx.stroke();
  }
}

function kitCols(m: Match, team: 0 | 1) {
  return team === 0 ? m.home : m.away;
}

function drawPlayer(
  ctx: CanvasRenderingContext2D,
  m: Match,
  p: Player,
  x: number,
  y: number,
  cam: Cam,
  w: number,
  h: number,
  flip: boolean,
  demo: boolean,
) {
  const g = worldToScreen(cam, x, y, 0, w, h, flip);
  const s = cam.scale;
  const selected = !demo && p.id === m.controlled && m.userTeam >= 0;
  const kit = kitCols(m, p.team);

  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.28)";
  ctx.beginPath();
  ctx.ellipse(g.sx, g.sy + s * 0.08, s * 0.55, s * 0.22, 0, 0, Math.PI * 2);
  ctx.fill();

  if (selected) {
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(g.sx, g.sy + s * 0.1, s * 0.72, s * 0.3, 0, 0, Math.PI * 2);
    ctx.stroke();
  }

  const fx = Math.cos(p.facing);
  const fy = Math.sin(p.facing);
  const head = worldToScreen(cam, x + fx * 0.22, y + fy * 0.22, 1.55, w, h, flip);
  const hip = worldToScreen(cam, x, y, 0.55, w, h, flip);
  const phase = p.anim;
  const leg = Math.sin(phase * 6.2) * 0.35;

  const l1 = worldToScreen(cam, x - fy * 0.18 + fx * leg, y + fx * 0.18 + fy * leg, 0.05, w, h, flip);
  const l2 = worldToScreen(cam, x + fy * 0.18 - fx * leg, y - fx * 0.18 - fy * leg, 0.05, w, h, flip);

  ctx.strokeStyle = kit.socks;
  ctx.lineWidth = Math.max(2, s * 0.16);
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(hip.sx, hip.sy);
  ctx.lineTo(l1.sx, l1.sy);
  ctx.moveTo(hip.sx, hip.sy);
  ctx.lineTo(l2.sx, l2.sy);
  ctx.stroke();

  ctx.fillStyle = kit.shorts;
  ctx.beginPath();
  ctx.ellipse(hip.sx, hip.sy, s * 0.28, s * 0.2, 0, 0, Math.PI * 2);
  ctx.fill();

  const torso = worldToScreen(cam, x + fx * 0.08, y + fy * 0.08, 1.05, w, h, flip);
  ctx.fillStyle = kit.primary;
  ctx.beginPath();
  ctx.ellipse(torso.sx, torso.sy, s * 0.32, s * 0.38, 0, 0, Math.PI * 2);
  ctx.fill();
  if (kit.pattern === "stripe") {
    ctx.fillStyle = kit.secondary;
    ctx.fillRect(torso.sx - s * 0.08, torso.sy - s * 0.32, s * 0.16, s * 0.64);
  } else if (kit.pattern === "sash") {
    ctx.save();
    ctx.translate(torso.sx, torso.sy);
    ctx.rotate(0.6);
    ctx.fillStyle = kit.secondary;
    ctx.fillRect(-s * 0.06, -s * 0.4, s * 0.12, s * 0.8);
    ctx.restore();
  } else if (kit.pattern === "hoop") {
    ctx.fillStyle = kit.secondary;
    ctx.fillRect(torso.sx - s * 0.3, torso.sy - s * 0.06, s * 0.6, s * 0.12);
  }

  ctx.fillStyle = skinColor(p.skin);
  ctx.beginPath();
  ctx.arc(head.sx, head.sy, s * 0.22, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = hairColor(p.hair);
  ctx.beginPath();
  ctx.ellipse(head.sx, head.sy - s * 0.08, s * 0.2, s * 0.12, 0, 0, Math.PI * 2);
  ctx.fill();

  if (p.role === "gk") {
    ctx.strokeStyle = "#f0d24a";
    ctx.lineWidth = 1.4;
    ctx.stroke();
  }

  if (selected || s > 16) {
    ctx.font = `${Math.max(10, s * 0.42)}px "Segoe UI", sans-serif`;
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(8,10,12,0.7)";
    ctx.fillText(String(p.num), torso.sx, torso.sy + 4);
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    ctx.fillText(String(p.num), torso.sx, torso.sy + 3);
  }

  if (selected) {
    ctx.font = `600 ${Math.max(11, s * 0.38)}px "Segoe UI", sans-serif`;
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(8,9,12,0.72)";
    ctx.fillRect(g.sx - 36, g.sy - s * 2.35, 72, 16);
    ctx.fillStyle = "#f3f4f6";
    ctx.fillText(p.name.toUpperCase(), g.sx, g.sy - s * 2.35 + 12);
  }

  ctx.restore();
}

function drawBall(
  ctx: CanvasRenderingContext2D,
  cam: Cam,
  ball: { x: number; y: number; z: number },
  w: number,
  h: number,
  flip: boolean,
) {
  const g = worldToScreen(cam, ball.x, ball.y, 0, w, h, flip);
  const p = worldToScreen(cam, ball.x, ball.y, ball.z, w, h, flip);
  const s = cam.scale;
  ctx.fillStyle = `rgba(0,0,0,${0.22 + ball.z * 0.04})`;
  ctx.beginPath();
  ctx.ellipse(g.sx, g.sy, s * 0.28 + ball.z * 0.08, s * 0.12, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#f5f6f8";
  ctx.beginPath();
  ctx.arc(p.sx, p.sy, s * 0.22, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#1a1c20";
  ctx.beginPath();
  ctx.arc(p.sx + s * 0.04, p.sy - s * 0.02, s * 0.07, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(p.sx - s * 0.08, p.sy + s * 0.04, s * 0.06, 0, Math.PI * 2);
  ctx.fill();
}

function clockLabel(m: Match) {
  const mins = Math.min(90, Math.floor(m.clock));
  const secs = Math.floor((m.clock % 1) * 60)
    .toString()
    .padStart(2, "0");
  return `${mins}:${secs}`;
}

function drawHud(ctx: CanvasRenderingContext2D, m: Match, cam: Cam, w: number, h: number, flip: boolean) {
  void cam;
  void flip;
  const pad = 16;
  ctx.save();
  const bw = Math.min(420, w - 32);
  const bx = (w - bw) / 2;
  const by = pad;
  roundRect(ctx, bx, by, bw, 52, 14);
  ctx.fillStyle = "rgba(8,9,12,0.78)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.08)";
  ctx.stroke();

  ctx.font = "600 13px 'Segoe UI', sans-serif";
  ctx.fillStyle = "#8b919c";
  ctx.textAlign = "left";
  ctx.fillText(m.home.short, bx + 16, by + 22);
  ctx.textAlign = "right";
  ctx.fillText(m.away.short, bx + bw - 16, by + 22);
  ctx.textAlign = "center";
  ctx.fillStyle = "#f3f4f6";
  ctx.font = "700 22px 'Segoe UI', sans-serif";
  ctx.fillText(`${m.score[0]}  –  ${m.score[1]}`, bx + bw / 2, by + 26);
  ctx.font = "500 11px ui-monospace, monospace";
  ctx.fillStyle = "#5eaf7a";
  ctx.fillText(m.practice ? "PRACTICE" : `H${m.half}  ${clockLabel(m)}`, bx + bw / 2, by + 44);

  if (m.eventT > 0) {
    ctx.globalAlpha = clamp(m.eventT, 0, 1);
    ctx.font = "600 16px 'Segoe UI', sans-serif";
    ctx.fillStyle = "#f3f4f6";
    ctx.fillText(m.event, w / 2, by + 78);
    ctx.globalAlpha = 1;
  }

  drawRadar(ctx, m, 16, h - 108, 140, 88);
  const user = m.userTeam >= 0 ? m.players[m.controlled] : null;
  if (user) {
    ctx.fillStyle = "rgba(8,9,12,0.65)";
    roundRect(ctx, w - 150, h - 54, 134, 38, 10);
    ctx.fill();
    ctx.fillStyle = "#8b919c";
    ctx.font = "500 10px 'Segoe UI', sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("STAMINA", w - 138, h - 38);
    ctx.fillStyle = "#1a1d26";
    ctx.fillRect(w - 138, h - 32, 110, 6);
    ctx.fillStyle = user.stamina > 0.25 ? "#5eaf7a" : "#d45b52";
    ctx.fillRect(w - 138, h - 32, 110 * user.stamina, 6);
  }
  if (m.shootHold > 0.04) {
    const pw = 160;
    ctx.fillStyle = "rgba(8,9,12,0.7)";
    roundRect(ctx, (w - pw) / 2, h * 0.62, pw, 14, 7);
    ctx.fill();
    ctx.fillStyle = "#5eaf7a";
    ctx.fillRect((w - pw) / 2 + 2, h * 0.62 + 2, (pw - 4) * m.shootHold, 10);
  }

  if (m.phase === "halftime" || m.phase === "fulltime" || m.phase === "goal") {
    ctx.fillStyle = "rgba(8,9,12,0.35)";
    ctx.fillRect(0, 0, w, h);
    ctx.font = "700 42px 'Segoe UI', sans-serif";
    ctx.textAlign = "center";
    ctx.fillStyle = "#f3f4f6";
    const title = m.phase === "goal" ? "GOAL" : m.phase === "halftime" ? "HALF TIME" : "FULL TIME";
    ctx.fillText(title, w / 2, h / 2 - 8);
    if (m.phase !== "goal") {
      ctx.font = "600 20px 'Segoe UI', sans-serif";
      ctx.fillText(`${m.home.short}  ${m.score[0]}  –  ${m.score[1]}  ${m.away.short}`, w / 2, h / 2 + 28);
    }
  }
  ctx.restore();
}

function drawRadar(ctx: CanvasRenderingContext2D, m: Match, x: number, y: number, rw: number, rh: number) {
  ctx.save();
  roundRect(ctx, x, y, rw, rh, 10);
  ctx.fillStyle = "rgba(8,12,10,0.72)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.12)";
  ctx.stroke();
  const ix = x + 8;
  const iy = y + 8;
  const iw = rw - 16;
  const ih = rh - 16;
  ctx.strokeStyle = "rgba(255,255,255,0.25)";
  ctx.strokeRect(ix, iy, iw, ih);
  ctx.beginPath();
  ctx.moveTo(ix + iw / 2, iy);
  ctx.lineTo(ix + iw / 2, iy + ih);
  ctx.stroke();
  const flip = camFlip(m);
  const toR = (wx: number, wy: number) => {
    const fx = flip ? -wx : wx;
    const fy = flip ? -wy : wy;
    return {
      rx: ix + ((fx + HALF_W) / (HALF_W * 2)) * iw,
      ry: iy + ((fy + HALF_H) / (HALF_H * 2)) * ih,
    };
  };
  for (const p of m.players) {
    const { rx, ry } = toR(p.x, p.y);
    ctx.fillStyle = p.team === 0 ? "#e8eef5" : "#d45b52";
    if (p.id === m.controlled && m.userTeam >= 0) ctx.fillStyle = "#5eaf7a";
    ctx.beginPath();
    ctx.arc(rx, ry, p.id === m.controlled ? 3.2 : 2.2, 0, Math.PI * 2);
    ctx.fill();
  }
  const b = toR(m.ball.x, m.ball.y);
  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.arc(b.rx, b.ry, 2.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}
