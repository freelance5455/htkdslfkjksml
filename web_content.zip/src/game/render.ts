import { Sim, PARTS, DRAW_ORDER, JOINT_IDS, STATE_COLORS, HAND_IDS } from './physics';
import type { Fighter } from './physics';
import type { Particle, Popup } from './match';

export interface View {
  cx: number;
  cy: number;
  scale: number;
  zoom: number; // user zoom multiplier
  panX: number;
  panY: number;
  w: number;
  h: number;
  ready: boolean;
}

export function newView(): View {
  return { cx: 0, cy: 1.2, scale: 80, zoom: 1, panX: 0, panY: 0, w: 300, h: 300, ready: false };
}

export function updateView(v: View, sim: Sim, dt: number) {
  const a = sim.fighters[0].bodies[0].getPosition();
  const b = sim.fighters[1].bodies[0].getPosition();
  const ha = sim.fighters[0].bodies[3].getPosition();
  const hb = sim.fighters[1].bodies[3].getPosition();
  const minX = Math.min(a.x, b.x);
  const maxX = Math.max(a.x, b.x);
  const top = Math.max(2.5, ha.y + 0.6, hb.y + 0.6);
  const bottom = -0.35;
  const spanX = maxX - minX + 3.6;
  const sx = v.w / spanX;
  const sy = v.h / (top - bottom);
  const target = Math.max(30, Math.min(150, Math.min(sx, sy)));
  const tcx = (minX + maxX) / 2;
  const tcy = (top + bottom) / 2;
  const k = v.ready ? 1 - Math.exp(-dt * 4) : 1;
  v.scale += (target - v.scale) * k;
  v.cx += (tcx - v.cx) * k;
  v.cy += (tcy - v.cy) * k;
  v.ready = true;
}

function sxOf(v: View, x: number) {
  const s = v.scale * v.zoom;
  return v.w / 2 + (x - v.cx) * s + v.panX;
}
function syOf(v: View, y: number) {
  const s = v.scale * v.zoom;
  return v.h / 2 - (y - v.cy) * s + v.panY;
}

export function screenToWorld(v: View, px: number, py: number): [number, number] {
  const s = v.scale * v.zoom;
  return [(px - v.w / 2 - v.panX) / s + v.cx, -(py - v.h / 2 - v.panY) / s + v.cy];
}

function shade(hex: string, f: number): string {
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) & 255;
  let g = (n >> 8) & 255;
  let b = n & 255;
  if (f < 0) {
    r = Math.round(r * (1 + f));
    g = Math.round(g * (1 + f));
    b = Math.round(b * (1 + f));
  } else {
    r = Math.round(r + (255 - r) * f);
    g = Math.round(g + (255 - g) * f);
    b = Math.round(b + (255 - b) * f);
  }
  return `rgb(${r},${g},${b})`;
}

export const FIGHTER_COLORS = ['#3b82f6', '#ef4444'];

export interface RenderOpts {
  sim: Sim;
  view: View;
  particles: Particle[];
  popups: Popup[];
  selected: number | null;
  selectedFighter: number;
  markers: [number, number]; // alpha for fighter 0/1 joint markers
  shake: number;
  time: number;
  dismemberOn: boolean;
}

export function markerRadius(v: View) {
  return Math.max(7, Math.min(13, v.scale * v.zoom * 0.085));
}

// screen position of a joint marker (far-side joints are nudged so coincident joints stay tappable)
export function markerPos(sim: Sim, f: Fighter, i: number, v: View): [number, number] {
  const p = sim.jointWorldPos(f, i);
  let x = sxOf(v, p.x);
  let y = syOf(v, p.y);
  if (PARTS[i].side === 2) {
    const mr = markerRadius(v);
    x -= f.dir * mr * 1.1;
    y += mr * 0.9;
  }
  return [x, y];
}

export function pickJoint(sim: Sim, fighterIdx: number, view: View, px: number, py: number, radius: number): number | null {
  const f = sim.fighters[fighterIdx];
  const cands: { i: number; d: number }[] = [];
  for (const i of JOINT_IDS) {
    if (f.broken[i]) continue;
    const [x, y] = markerPos(sim, f, i, view);
    const d = Math.hypot(x - px, y - py);
    if (d < radius) cands.push({ i, d });
  }
  if (!cands.length) return null;
  cands.sort((a, b) => a.d - b.d);
  return cands[0].i;
}

export function draw(ctx: CanvasRenderingContext2D, o: RenderOpts) {
  const { sim, view: v } = o;
  const W = v.w;
  const H = v.h;
  const s = v.scale * v.zoom;
  ctx.save();
  if (o.shake > 0) ctx.translate((Math.random() - 0.5) * o.shake, (Math.random() - 0.5) * o.shake);

  // ---- sky
  const sky = ctx.createLinearGradient(0, 0, 0, H);
  sky.addColorStop(0, '#070b1a');
  sky.addColorStop(0.6, '#1a2347');
  sky.addColorStop(1, '#2b2f55');
  ctx.fillStyle = sky;
  ctx.fillRect(-20, -20, W + 40, H + 40);

  // moon
  const par = (f: number) => -v.cx * s * f;
  ctx.fillStyle = 'rgba(255,244,214,0.9)';
  ctx.beginPath();
  ctx.arc(W * 0.78 + par(0.02), H * 0.2, Math.max(14, H * 0.07), 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(255,244,214,0.08)';
  ctx.beginPath();
  ctx.arc(W * 0.78 + par(0.02), H * 0.2, Math.max(30, H * 0.16), 0, Math.PI * 2);
  ctx.fill();

  const groundY = syOf(v, 0);

  // far mountains / pagoda silhouettes
  ctx.fillStyle = '#141a38';
  ctx.beginPath();
  ctx.moveTo(-50, groundY);
  for (let x = -50; x <= W + 50; x += 40) {
    const wx = x - par(0.08);
    const hgt = (Math.sin(wx * 0.011) * 0.5 + Math.sin(wx * 0.027 + 1) * 0.35 + 1) * H * 0.12;
    ctx.lineTo(x, groundY - hgt - H * 0.05);
  }
  ctx.lineTo(W + 50, groundY);
  ctx.fill();
  ctx.fillStyle = '#0d1230';
  ctx.beginPath();
  ctx.moveTo(-50, groundY);
  for (let x = -50; x <= W + 50; x += 30) {
    const wx = x - par(0.2);
    const hgt = (Math.sin(wx * 0.017 + 4) * 0.5 + Math.sin(wx * 0.041) * 0.3 + 0.9) * H * 0.07;
    ctx.lineTo(x, groundY - hgt);
  }
  ctx.lineTo(W + 50, groundY);
  ctx.fill();

  // ---- floor
  const fl = ctx.createLinearGradient(0, groundY, 0, H);
  fl.addColorStop(0, '#3a4270');
  fl.addColorStop(1, '#171b36');
  ctx.fillStyle = fl;
  ctx.fillRect(-20, groundY, W + 40, H - groundY + 20);
  ctx.fillStyle = '#9fb0ff';
  ctx.fillRect(-20, groundY - 1.5, W + 40, 3);
  // perspective-ish grid
  ctx.strokeStyle = 'rgba(159,176,255,0.18)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  const startM = Math.floor((screenToWorld(v, -50, 0)[0]) / 1) - 1;
  const endM = Math.ceil(screenToWorld(v, W + 50, 0)[0]) + 1;
  for (let m = startM; m <= endM; m++) {
    const x = sxOf(v, m);
    ctx.moveTo(x, groundY);
    const spread = (x - W / 2) * 1.8;
    ctx.lineTo(x + spread, H + 10);
  }
  for (let i = 1; i < 5; i++) {
    const y = groundY + (H - groundY) * Math.pow(i / 5, 1.6);
    ctx.moveTo(0, y);
    ctx.lineTo(W, y);
  }
  ctx.stroke();
  // ruler ticks
  ctx.fillStyle = 'rgba(255,255,255,0.55)';
  ctx.font = `${Math.max(9, s * 0.1)}px sans-serif`;
  ctx.textAlign = 'center';
  for (let m = startM; m <= endM; m++) {
    if (m % 2 !== 0) continue;
    ctx.fillText(String(m), sxOf(v, m), groundY + Math.max(12, s * 0.14));
  }
  // arena walls
  for (const wx of [-9, 9]) {
    const x = sxOf(v, wx);
    if (x > -30 && x < W + 30) {
      const g = ctx.createLinearGradient(x - s * 0.5, 0, x + s * 0.5, 0);
      g.addColorStop(0, 'rgba(244,63,94,0)');
      g.addColorStop(0.5, 'rgba(244,63,94,0.55)');
      g.addColorStop(1, 'rgba(244,63,94,0)');
      ctx.fillStyle = g;
      ctx.fillRect(x - s * 0.5, 0, s, groundY);
    }
  }

  // ---- shadows
  for (const f of sim.fighters) {
    const p = f.bodies[0].getPosition();
    const k = Math.max(0.2, 1 - p.y / 4);
    ctx.fillStyle = `rgba(0,0,0,${0.35 * k})`;
    ctx.beginPath();
    ctx.ellipse(sxOf(v, p.x), groundY + 3, s * 0.55 * k, s * 0.06, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // ---- fighters
  for (const f of sim.fighters) {
    const base = FIGHTER_COLORS[f.idx];
    for (const i of DRAW_ORDER) {
      const p = PARTS[i];
      const b = f.bodies[i];
      const pos = b.getPosition();
      const x = sxOf(v, pos.x);
      const y = syOf(v, pos.y);
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(-b.getAngle());
      let col = base;
      if (p.kind === 'hand' || p.kind === 'foot') col = shade(base, -0.25);
      else if (p.kind === 'head') col = shade(base, 0.35);
      else if (p.kind === 'torso') col = shade(base, 0.05);
      if (p.side === 2) col = shade(base, -0.45);
      ctx.fillStyle = typeof col === 'string' ? col : base;
      ctx.strokeStyle = 'rgba(5,8,20,0.9)';
      ctx.lineWidth = Math.max(1.2, s * 0.012);
      if (p.shape === 'circle') {
        ctx.beginPath();
        ctx.arc(0, 0, p.hx * s, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        // visor
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        const dirx = f.dir;
        ctx.save();
        ctx.scale(1, 1);
        ctx.fillRect(dirx > 0 ? p.hx * s * 0.05 : -p.hx * s * 0.75, -p.hx * s * 0.28, p.hx * s * 0.7, p.hx * s * 0.2);
        ctx.restore();
      } else {
        const hw = p.hx * s;
        const hh = p.hy * s;
        const r = Math.min(hw, hh) * (p.kind === 'torso' ? 0.7 : 0.95);
        ctx.beginPath();
        ctx.roundRect(-hw, -hh, hw * 2, hh * 2, r);
        ctx.fill();
        ctx.stroke();
        if (p.kind === 'torso') {
          ctx.fillStyle = 'rgba(255,255,255,0.12)';
          ctx.beginPath();
          ctx.roundRect(-hw * 0.6, -hh * 0.85, hw * 0.5, hh * 1.7, r * 0.5);
          ctx.fill();
        }
      }
      ctx.restore();
    }
    // grip rings
    for (let h = 0; h < 2; h++) {
      if (f.grip[h]) {
        const pos = f.bodies[HAND_IDS[h]].getPosition();
        ctx.strokeStyle = f.gripJoints[h] ? '#fde047' : 'rgba(253,224,71,0.7)';
        ctx.lineWidth = 2;
        ctx.setLineDash(f.gripJoints[h] ? [] : [3, 3]);
        ctx.beginPath();
        ctx.arc(sxOf(v, pos.x), syOf(v, pos.y), Math.max(9, s * 0.13), 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
      }
    }
  }

  // ---- particles
  for (const p of o.particles) {
    ctx.globalAlpha = Math.max(0, Math.min(1, p.life / 0.4));
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(sxOf(v, p.x), syOf(v, p.y), Math.max(1.5, p.size * s), 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  // ---- joint markers
  const mr = markerRadius(v);
  for (const f of sim.fighters) {
    const alpha = o.markers[f.idx];
    if (alpha <= 0) continue;
    for (const i of JOINT_IDS) {
      const [x, y] = markerPos(sim, f, i, v);
      if (f.broken[i]) {
        ctx.strokeStyle = `rgba(220,38,38,${alpha})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x - 4, y - 4);
        ctx.lineTo(x + 4, y + 4);
        ctx.moveTo(x + 4, y - 4);
        ctx.lineTo(x - 4, y + 4);
        ctx.stroke();
        continue;
      }
      const sel = o.selected === i && o.selectedFighter === f.idx;
      ctx.globalAlpha = alpha;
      ctx.fillStyle = STATE_COLORS[f.state[i]];
      ctx.strokeStyle = sel ? '#ffffff' : 'rgba(0,0,0,0.75)';
      ctx.lineWidth = sel ? 3 : 1.5;
      ctx.beginPath();
      ctx.arc(x, y, sel ? mr * 1.3 : mr, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      if (sel) {
        const pulse = 0.5 + 0.5 * Math.sin(o.time * 6);
        ctx.strokeStyle = `rgba(255,255,255,${0.35 + pulse * 0.5})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(x, y, mr * (1.9 + pulse * 0.4), 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }
  }

  // ---- popups
  ctx.textAlign = 'center';
  for (const p of o.popups) {
    ctx.globalAlpha = Math.max(0, Math.min(1, p.life * 1.5));
    const size = p.big ? Math.max(20, s * 0.26) : Math.max(14, s * 0.17);
    ctx.font = `900 ${size}px system-ui, sans-serif`;
    ctx.lineWidth = 4;
    ctx.strokeStyle = 'rgba(0,0,0,0.85)';
    ctx.strokeText(p.text, sxOf(v, p.x), syOf(v, p.y));
    ctx.fillStyle = p.color;
    ctx.fillText(p.text, sxOf(v, p.x), syOf(v, p.y));
  }
  ctx.globalAlpha = 1;
  ctx.restore();
}
