import { CAM, PALETTE as C, FONT_DISPLAY, FONT_BODY, HURDLE_HEIGHT, MAX_LIVES } from './constants';
import type {
  View, SceneryEnt, PlayerState, QuestionGroup, Entity, CoinEnt, ObstacleEnt, GateEnt, EnginePhase,
} from './types';
import type { ParticleSystem, FloatingTexts } from './particles';

export const Z_FAR = 70;

/** Everything the renderer needs to know about the engine state. */
export interface Scene {
  time: number;
  distance: number;
  speed: number;
  camX: number;
  player: PlayerState;
  ents: Entity[];
  scenery: SceneryEnt[];
  activeGroup: QuestionGroup | null;
  boostT: number;
  score: number;
  scoreDisplay: number;
  best: number;
  combo: number;
  lives: number;
  coins: number;
  level: number;
  scoreBump: number;
  coinBump: number;
  comboBump: number;
  heartBump: number;
  goT: number;
  phase: EnginePhase;
  particles: ParticleSystem;
  floats: FloatingTexts;
  showHud: boolean;
}

interface Star { x: number; y: number; r: number; tw: number; ph: number; a: number }
interface Building { x: number; w: number; h: number; dome: boolean }

export interface SkyCache {
  grad: CanvasGradient;
  groundGrad: CanvasGradient;
  fogGrad: CanvasGradient;
  fogH: number;
  vignette: CanvasGradient;
  sunGrad: CanvasGradient;
  sunR: number;
  stars: Star[];
  hills: number[];
  city: Building[];
}

// ---------- math helpers ----------
export const clamp01 = (t: number) => (t < 0 ? 0 : t > 1 ? 1 : t);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const easeOutBack = (t: number) => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
};
export const elasticOut = (t: number) =>
  t === 0 ? 0 : t === 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * ((2 * Math.PI) / 3)) + 1;
export const fmt = (n: number) => Math.floor(n).toLocaleString('en-US');

// ---------- projection ----------
const P3 = { x: 0, y: 0, s: 0 };
export function scaleAt(z: number) {
  return CAM / (CAM + z);
}
export function groundY(v: View, s: number) {
  return v.horizonY + (v.baseY - v.horizonY) * s;
}
/** Projects a world point (lane-space x, height y, depth z). Returns a shared scratch object — copy values immediately. */
export function project(v: View, wx: number, wy: number, z: number, camX: number) {
  const s = CAM / (CAM + z);
  P3.x = v.cx + (wx - camX) * v.laneW * s;
  P3.y = groundY(v, s) - wy * v.laneW * s;
  P3.s = s;
  return P3;
}

export function makeView(W: number, H: number): View {
  const laneW = Math.max(64, Math.min(W * 0.26, H * 0.3, 230));
  return { W, H, cx: W / 2, horizonY: H * 0.42, baseY: H * 0.86, laneW };
}

export function buildSkyCache(ctx: CanvasRenderingContext2D, v: View): SkyCache {
  const { W, H, horizonY, baseY } = v;
  const grad = ctx.createLinearGradient(0, 0, 0, horizonY);
  grad.addColorStop(0, C.skyTop);
  grad.addColorStop(0.45, C.skyMid);
  grad.addColorStop(0.8, C.skyLow);
  grad.addColorStop(1, C.skyHorizon);

  const groundGrad = ctx.createLinearGradient(0, horizonY, 0, H);
  groundGrad.addColorStop(0, C.groundFar);
  groundGrad.addColorStop(0.3, C.groundNear);
  groundGrad.addColorStop(1, '#b3874a');

  const fogH = (baseY - horizonY) * 0.5;
  const fogGrad = ctx.createLinearGradient(0, horizonY, 0, horizonY + fogH);
  fogGrad.addColorStop(0, 'rgba(255,186,120,0.95)');
  fogGrad.addColorStop(0.45, 'rgba(255,186,120,0.35)');
  fogGrad.addColorStop(1, 'rgba(255,186,120,0)');

  const vignette = ctx.createRadialGradient(W / 2, H * 0.5, Math.min(W, H) * 0.4, W / 2, H * 0.5, Math.max(W, H) * 0.8);
  vignette.addColorStop(0, 'rgba(20,8,30,0)');
  vignette.addColorStop(1, 'rgba(20,8,30,0.6)');

  const sunR = Math.min(W, H) * 0.085;
  const sunGrad = ctx.createRadialGradient(0, 0, sunR * 0.3, 0, 0, sunR * 3.2);
  sunGrad.addColorStop(0, 'rgba(255,225,160,0.85)');
  sunGrad.addColorStop(0.35, 'rgba(255,190,120,0.35)');
  sunGrad.addColorStop(1, 'rgba(255,170,110,0)');

  const stars: Star[] = [];
  for (let i = 0; i < 110; i++) {
    const y = Math.pow(Math.random(), 1.6) * horizonY * 0.8;
    stars.push({
      x: Math.random() * (W + 80) - 40, y, r: Math.random() < 0.15 ? 2.4 : 1.4,
      tw: 1 + Math.random() * 3, ph: Math.random() * 7, a: 0.5 + Math.random() * 0.5,
    });
  }
  const hills: number[] = [];
  let h = 0.04;
  for (let i = 0; i < 30; i++) {
    h += (Math.random() - 0.5) * 0.03;
    h = Math.max(0.015, Math.min(0.085, h));
    hills.push(h * H);
  }
  const city: Building[] = [];
  let x = W * 0.06;
  while (x < W * 0.94) {
    const w = W * (0.025 + Math.random() * 0.05);
    const tall = Math.random() < 0.15;
    city.push({ x, w, h: H * (tall ? 0.07 + Math.random() * 0.05 : 0.02 + Math.random() * 0.035), dome: !tall && Math.random() < 0.4 });
    x += w + W * (Math.random() * 0.02);
  }
  return { grad, groundGrad, fogGrad, fogH, vignette, sunGrad, sunR, stars, hills, city };
}

// ---------- drawing primitives ----------
export function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function quad(ctx: CanvasRenderingContext2D, x0: number, y0: number, w0: number, x1: number, y1: number, w1: number) {
  ctx.moveTo(x0 - w0, y0);
  ctx.lineTo(x0 + w0, y0);
  ctx.lineTo(x1 + w1, y1);
  ctx.lineTo(x1 - w1, y1);
  ctx.closePath();
}

function ellipse(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number) {
  ctx.beginPath();
  ctx.ellipse(x, y, Math.max(0.1, rx), Math.max(0.1, ry), 0, 0, Math.PI * 2);
  ctx.fill();
}

function circle(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.beginPath();
  ctx.arc(x, y, Math.max(0.1, r), 0, Math.PI * 2);
  ctx.fill();
}

export function drawHeart(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, fill: string, outline: boolean) {
  ctx.beginPath();
  ctx.moveTo(x, y + r * 0.95);
  ctx.bezierCurveTo(x - r * 1.7, y - r * 0.1, x - r * 0.9, y - r * 1.35, x, y - r * 0.55);
  ctx.bezierCurveTo(x + r * 0.9, y - r * 1.35, x + r * 1.7, y - r * 0.1, x, y + r * 0.95);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
  if (outline) {
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(40,10,10,0.7)';
    ctx.stroke();
  }
}

export function wrapText(ctx: CanvasRenderingContext2D, text: string, maxW: number): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    const test = cur ? cur + ' ' + w : w;
    if (ctx.measureText(test).width <= maxW || !cur) cur = test;
    else {
      lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  return lines;
}

export function fitText(
  ctx: CanvasRenderingContext2D, text: string, maxW: number, maxSize: number, minSize: number, font: string, maxLines = 2,
): { size: number; lines: string[] } {
  for (let size = maxSize; size >= minSize; size--) {
    ctx.font = `800 ${size}px ${font}`;
    if (ctx.measureText(text).width <= maxW) return { size, lines: [text] };
  }
  if (maxLines > 1 && text.includes(' ')) {
    for (let size = maxSize - 2; size >= minSize; size--) {
      ctx.font = `800 ${size}px ${font}`;
      const lines = wrapText(ctx, text, maxW);
      if (lines.length <= maxLines && lines.every((l) => ctx.measureText(l).width <= maxW)) return { size, lines };
    }
  }
  ctx.font = `800 ${minSize}px ${font}`;
  return { size: minSize, lines: wrapText(ctx, text, maxW).slice(0, maxLines) };
}

// ---------- sky & ground ----------
export function drawSky(ctx: CanvasRenderingContext2D, v: View, sc: SkyCache, time: number, camX: number) {
  const { W, H, horizonY } = v;
  ctx.fillStyle = sc.grad;
  ctx.fillRect(0, 0, W, horizonY + 2);
  const px = -camX * v.laneW * 0.08;

  ctx.fillStyle = '#ffffff';
  for (const st of sc.stars) {
    ctx.globalAlpha = st.a * (0.35 + 0.65 * Math.abs(Math.sin(time * st.tw + st.ph)));
    ctx.fillRect(st.x + px, st.y, st.r, st.r);
  }
  ctx.globalAlpha = 1;

  // sun
  const sx = W * 0.68 + px * 1.5;
  const sy = horizonY - H * 0.045;
  ctx.save();
  ctx.translate(sx, sy);
  ctx.fillStyle = sc.sunGrad;
  ctx.fillRect(-sc.sunR * 3.2, -sc.sunR * 3.2, sc.sunR * 6.4, sc.sunR * 3.2 + (horizonY - sy) + 2);
  ctx.fillStyle = C.sun;
  circle(ctx, 0, 0, sc.sunR);
  ctx.restore();

  // far hills
  const hp = px * 2;
  ctx.fillStyle = C.farHills;
  ctx.beginPath();
  ctx.moveTo(-W * 0.15 + hp, horizonY + 2);
  const n = sc.hills.length;
  for (let i = 0; i < n; i++) {
    const x0 = -W * 0.15 + (i / (n - 1)) * W * 1.3 + hp;
    const y0 = horizonY - sc.hills[i];
    if (i === 0) ctx.lineTo(x0, y0);
    else {
      const xp = -W * 0.15 + ((i - 1) / (n - 1)) * W * 1.3 + hp;
      const yp = horizonY - sc.hills[i - 1];
      ctx.quadraticCurveTo(xp, yp, (xp + x0) / 2, (yp + y0) / 2);
    }
  }
  ctx.lineTo(W * 1.15 + hp, horizonY + 2);
  ctx.closePath();
  ctx.fill();

  // city silhouette
  const cp = px * 3;
  ctx.fillStyle = C.city;
  for (const b of sc.city) {
    ctx.fillRect(b.x + cp, horizonY - b.h, b.w, b.h + 2);
    if (b.dome) {
      ctx.beginPath();
      ctx.arc(b.x + b.w / 2 + cp, horizonY - b.h, b.w / 2, Math.PI, 0);
      ctx.fill();
    }
  }
  ctx.fillRect(-W * 0.2, horizonY - H * 0.01, W * 1.4, H * 0.01 + 2);
}

export function drawRoad(ctx: CanvasRenderingContext2D, v: View, sc: SkyCache, distance: number, camX: number) {
  const { W, H, horizonY, baseY, laneW } = v;
  ctx.fillStyle = sc.groundGrad;
  ctx.fillRect(0, horizonY, W, H - horizonY);

  const sBottom = (H - horizonY) / (baseY - horizonY) + 0.06;
  const zBottom = CAM / sBottom - CAM;
  const camPx = -camX * laneW;
  const HALF = 1.62;

  // road base
  const yB = groundY(v, sBottom);
  ctx.fillStyle = C.roadA;
  ctx.beginPath();
  ctx.moveTo(v.cx + camPx * sBottom - HALF * laneW * sBottom, yB);
  ctx.lineTo(v.cx + camPx * sBottom + HALF * laneW * sBottom, yB);
  ctx.lineTo(v.cx + 1.5, horizonY);
  ctx.lineTo(v.cx - 1.5, horizonY);
  ctx.closePath();
  ctx.fill();

  // alternating stone bands
  const STEP = 3;
  const startN = Math.floor((distance + zBottom) / STEP);
  ctx.fillStyle = C.roadB;
  ctx.beginPath();
  for (let n = startN; ; n++) {
    const zA = n * STEP - distance;
    if (zA > Z_FAR) break;
    if (n % 2 !== 0) continue;
    const z0 = Math.max(zA, zBottom);
    const z1 = zA + STEP;
    const s0 = scaleAt(z0);
    const s1 = scaleAt(z1);
    quad(ctx, v.cx + camPx * s0, groundY(v, s0), HALF * laneW * s0, v.cx + camPx * s1, groundY(v, s1), HALF * laneW * s1);
  }
  ctx.fill();

  // lane dashes
  ctx.fillStyle = C.laneDash;
  ctx.globalAlpha = 0.75;
  ctx.beginPath();
  for (let n = startN; ; n++) {
    const zA = n * STEP - distance;
    if (zA > Z_FAR) break;
    const z0 = Math.max(zA, zBottom);
    const z1 = zA + STEP * 0.5;
    if (z1 <= z0) continue;
    const s0 = scaleAt(z0);
    const s1 = scaleAt(z1);
    for (let l = -0.5; l <= 0.5; l += 1) {
      quad(ctx, v.cx + (camPx + l * laneW) * s0, groundY(v, s0), 0.035 * laneW * s0, v.cx + (camPx + l * laneW) * s1, groundY(v, s1), 0.035 * laneW * s1);
    }
  }
  ctx.fill();
  ctx.globalAlpha = 1;

  // edges
  const sF = scaleAt(Z_FAR);
  ctx.fillStyle = C.roadEdgeLight;
  ctx.beginPath();
  for (const side of [-HALF, HALF]) {
    quad(ctx, v.cx + (camPx + side * laneW) * sBottom, yB, 0.07 * laneW * sBottom, v.cx + (camPx + side * laneW) * sF, groundY(v, sF), 0.07 * laneW * sF);
  }
  ctx.fill();
  ctx.fillStyle = C.roadEdge;
  ctx.beginPath();
  for (const side of [-HALF - 0.12, HALF + 0.12]) {
    quad(ctx, v.cx + (camPx + side * laneW) * sBottom, yB, 0.05 * laneW * sBottom, v.cx + (camPx + side * laneW) * sF, groundY(v, sF), 0.05 * laneW * sF);
  }
  ctx.fill();

  // fog toward horizon
  ctx.fillStyle = sc.fogGrad;
  ctx.fillRect(0, horizonY, W, sc.fogH);
}

// ---------- scenery ----------
function fogAlpha(z: number) {
  return z < 28 ? 1 : Math.max(0, 1 - (z - 28) / (Z_FAR - 28));
}

export function drawScenery(ctx: CanvasRenderingContext2D, v: View, e: SceneryEnt, relZ: number, camX: number, time: number) {
  const p = project(v, e.x, 0, relZ, camX);
  const x = p.x;
  const y = p.y;
  const u = v.laneW * p.s;
  if (u < 1.5) return;
  if (x + u * 1.6 < 0 || x - u * 1.6 > v.W || y - u * 4 > v.H) return;
  ctx.globalAlpha = fogAlpha(relZ);
  const seed = e.seed;
  switch (e.variant) {
    case 'palm': {
      const lean = (seed < 0.5 ? 1 : -1) * (0.1 + seed * 0.25) * (e.x > 0 ? 1 : -1);
      const h = u * (2.3 + seed * 0.9);
      const topX = x + lean * h * 0.35;
      const topY = y - h;
      ctx.strokeStyle = C.trunk;
      ctx.lineWidth = Math.max(1, u * 0.14);
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.quadraticCurveTo(x + lean * h * 0.05, y - h * 0.6, topX, topY);
      ctx.stroke();
      ctx.strokeStyle = seed > 0.5 ? C.palm : C.palmDark;
      ctx.lineWidth = Math.max(1, u * 0.09);
      const L = u * 0.95;
      for (let i = 0; i < 6; i++) {
        const a = -Math.PI / 2 + (i - 2.5) * 0.55 + Math.sin(time * 2 + i + seed * 9) * 0.06;
        ctx.beginPath();
        ctx.moveTo(topX, topY);
        ctx.quadraticCurveTo(topX + Math.cos(a) * L * 0.6, topY + Math.sin(a) * L * 0.6 - u * 0.25, topX + Math.cos(a) * L, topY + Math.sin(a) * L + u * 0.35);
        ctx.stroke();
      }
      break;
    }
    case 'pillar': {
      const w = u * 0.36;
      const h = u * (2 + seed * 0.6);
      ctx.fillStyle = C.stone;
      ctx.fillRect(x - w / 2, y - h, w, h);
      ctx.fillStyle = C.stoneDark;
      ctx.fillRect(x + w / 2 - w * 0.3, y - h, w * 0.3, h);
      ctx.fillStyle = C.stone;
      ctx.fillRect(x - w * 0.75, y - h - u * 0.18, w * 1.5, u * 0.18);
      ctx.fillRect(x - w * 0.75, y - u * 0.14, w * 1.5, u * 0.14);
      ctx.fillStyle = C.gold;
      ctx.fillRect(x - w * 0.75, y - h - u * 0.05, w * 1.5, u * 0.05);
      break;
    }
    case 'obelisk': {
      const h = u * 3.2;
      ctx.fillStyle = C.stone;
      ctx.beginPath();
      ctx.moveTo(x - u * 0.22, y);
      ctx.lineTo(x + u * 0.22, y);
      ctx.lineTo(x + u * 0.11, y - h);
      ctx.lineTo(x, y - h - u * 0.3);
      ctx.lineTo(x - u * 0.11, y - h);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = C.stoneDark;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + u * 0.22, y);
      ctx.lineTo(x + u * 0.11, y - h);
      ctx.lineTo(x, y - h - u * 0.3);
      ctx.closePath();
      ctx.fill();
      break;
    }
    case 'rock': {
      ctx.fillStyle = '#7d7061';
      ellipse(ctx, x, y - u * 0.15, u * 0.45, u * 0.28);
      ctx.fillStyle = '#9a8d7c';
      ellipse(ctx, x - u * 0.15, y - u * 0.25, u * 0.22, u * 0.16);
      ctx.fillStyle = '#6b5f52';
      ellipse(ctx, x + u * 0.35, y - u * 0.08, u * 0.2, u * 0.13);
      break;
    }
    case 'bush': {
      ctx.fillStyle = C.palmDark;
      circle(ctx, x - u * 0.2, y - u * 0.2, u * 0.26);
      circle(ctx, x + u * 0.22, y - u * 0.18, u * 0.24);
      ctx.fillStyle = C.palm;
      circle(ctx, x, y - u * 0.32, u * 0.28);
      break;
    }
    case 'torch': {
      const h = u * 1.5;
      ctx.fillStyle = C.woodDark;
      ctx.fillRect(x - u * 0.05, y - h, u * 0.1, h);
      ctx.fillStyle = C.stoneDark;
      ctx.fillRect(x - u * 0.12, y - h - u * 0.12, u * 0.24, u * 0.14);
      const fl = 0.8 + Math.sin(time * 14 + seed * 20) * 0.2;
      ctx.fillStyle = 'rgba(255,170,60,0.18)';
      circle(ctx, x, y - h - u * 0.25, u * 0.6 * fl);
      ctx.fillStyle = '#ff9a2e';
      ellipse(ctx, x, y - h - u * 0.28, u * 0.13, u * 0.22 * fl);
      ctx.fillStyle = '#ffe58a';
      ellipse(ctx, x, y - h - u * 0.24, u * 0.06, u * 0.12 * fl);
      break;
    }
  }
  ctx.globalAlpha = 1;
}

// ---------- entities ----------
export function drawCoin(ctx: CanvasRenderingContext2D, v: View, c: CoinEnt, relZ: number, camX: number, time: number) {
  const bob = Math.sin(time * 4 + c.phase) * 0.07;
  const gp = project(v, c.lane - 1, 0, relZ, camX);
  const gx = gp.x;
  const gy = gp.y;
  const p = project(v, c.lane - 1, c.y + 0.36 + bob, relZ, camX);
  const x = p.x;
  const y = p.y;
  const u = v.laneW * p.s;
  const r = u * 0.24;
  if (r < 1) return;
  ctx.globalAlpha = fogAlpha(relZ);
  ctx.fillStyle = 'rgba(40,20,0,0.25)';
  ellipse(ctx, gx, gy, r * 0.8, r * 0.22);
  const wob = Math.abs(Math.cos(time * 5 + c.phase));
  ctx.fillStyle = 'rgba(255,220,120,0.22)';
  circle(ctx, x, y, r * 1.7);
  ctx.fillStyle = C.goldDark;
  ellipse(ctx, x, y, r * Math.max(0.16, wob), r);
  ctx.fillStyle = C.gold;
  ellipse(ctx, x, y, r * Math.max(0.1, wob) * 0.78, r * 0.78);
  if (wob > 0.55) {
    ctx.fillStyle = C.goldDark;
    const cw = r * 0.16 * wob;
    ctx.fillRect(x - cw / 2, y - r * 0.5, cw, r);
    ctx.fillRect(x - r * 0.35 * wob, y - r * 0.22, r * 0.7 * wob, r * 0.18);
  }
  ctx.globalAlpha = 1;
}

export function drawObstacle(ctx: CanvasRenderingContext2D, v: View, o: ObstacleEnt, relZ: number, camX: number) {
  const p = project(v, o.lane - 1, 0, relZ, camX);
  const x = p.x;
  const y = p.y;
  const u = v.laneW * p.s;
  if (u < 2) return;
  ctx.globalAlpha = fogAlpha(relZ);
  ctx.fillStyle = 'rgba(40,20,0,0.3)';
  if (o.variant === 'rock') {
    // tall broken stone wall — cannot be jumped, must be dodged
    const w = u * 0.92;
    const h = u * 1.55;
    ellipse(ctx, x, y, w * 0.6, u * 0.12);
    ctx.fillStyle = '#8d8274';
    ctx.beginPath();
    ctx.moveTo(x - w / 2, y);
    ctx.lineTo(x - w / 2, y - h * 0.84);
    ctx.lineTo(x - w * 0.2, y - h * 0.84);
    ctx.lineTo(x - w * 0.2, y - h);
    ctx.lineTo(x + w * 0.15, y - h);
    ctx.lineTo(x + w * 0.15, y - h * 0.92);
    ctx.lineTo(x + w / 2, y - h * 0.92);
    ctx.lineTo(x + w / 2, y);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#6a6052';
    ctx.fillRect(x + w / 2 - w * 0.22, y - h * 0.92, w * 0.22, h * 0.92);
    // mortar lines
    ctx.fillStyle = 'rgba(60,45,30,0.45)';
    const rows = 4;
    for (let r = 1; r < rows; r++) ctx.fillRect(x - w / 2, y - (h * r) / rows, w, Math.max(1, u * 0.025));
    for (let r = 0; r < rows; r++) {
      const off = r % 2 === 0 ? w * 0.33 : w * 0.66;
      ctx.fillRect(x - w / 2 + off, y - (h * (r + 1)) / rows, Math.max(1, u * 0.025), h / rows);
    }
    // warning stripe
    ctx.fillStyle = C.wrong;
    ctx.globalAlpha *= 0.85;
    ctx.fillRect(x - w / 2, y - h * 0.5, w, u * 0.06);
    ctx.globalAlpha = fogAlpha(relZ);
  } else {
    const w = u * 0.92;
    const h = u * HURDLE_HEIGHT;
    ellipse(ctx, x, y, w * 0.55, u * 0.1);
    ctx.fillStyle = C.woodDark;
    ctx.fillRect(x - w / 2, y - h, u * 0.09, h);
    ctx.fillRect(x + w / 2 - u * 0.09, y - h, u * 0.09, h);
    ctx.fillStyle = C.wood;
    ctx.fillRect(x - w / 2, y - h, w, u * 0.11);
    ctx.fillRect(x - w / 2, y - h * 0.52, w, u * 0.1);
    ctx.fillStyle = 'rgba(255,255,255,0.18)';
    ctx.fillRect(x - w / 2, y - h, w, u * 0.03);
  }
  ctx.globalAlpha = 1;
}

type GateVisual = 'idle' | 'active' | 'right' | 'wrong' | 'reveal';
function gateVisual(g: GateEnt): GateVisual {
  const gr = g.group;
  if (gr.resolved) {
    if (g.lane === gr.chosenLane) return gr.wasCorrect ? 'right' : 'wrong';
    if (g.lane === gr.correctLane) return 'reveal';
    return 'idle';
  }
  return gr.active ? 'active' : 'idle';
}

export function drawGate(ctx: CanvasRenderingContext2D, v: View, g: GateEnt, relZ: number, camX: number, time: number) {
  const p = project(v, g.lane - 1, 0, relZ, camX);
  const x = p.x;
  const y = p.y;
  const u = v.laneW * p.s;
  if (u < 2) return;
  const vis = gateVisual(g);
  ctx.globalAlpha = fogAlpha(relZ);
  const pw = u * 0.1;
  const gh = u * 2.05;
  const hw = u * 0.44;
  const accent = vis === 'right' || vis === 'reveal' ? C.correct : vis === 'wrong' ? C.wrong : C.gold;

  if (vis !== 'idle') {
    const pulse = vis === 'active' ? 0.1 + 0.06 * Math.sin(time * 6 + g.lane) : 0.28;
    ctx.fillStyle = accent;
    ctx.globalAlpha *= pulse;
    ctx.fillRect(x - hw, y - gh, hw * 2, gh);
    ctx.globalAlpha = fogAlpha(relZ);
  }
  // ground marker
  ctx.fillStyle = accent;
  ctx.globalAlpha *= 0.7;
  ctx.fillRect(x - hw - pw, y - Math.max(1, u * 0.02), hw * 2 + pw * 2, Math.max(1.5, u * 0.05));
  ctx.globalAlpha = fogAlpha(relZ);
  // pillars
  ctx.fillStyle = C.stone;
  ctx.fillRect(x - hw - pw, y - gh, pw, gh);
  ctx.fillRect(x + hw, y - gh, pw, gh);
  ctx.fillStyle = C.stoneDark;
  ctx.fillRect(x - hw - pw * 0.35, y - gh, pw * 0.35, gh);
  ctx.fillRect(x + hw + pw * 0.65, y - gh, pw * 0.35, gh);
  // beam
  ctx.fillStyle = accent;
  ctx.fillRect(x - hw - pw * 1.3, y - gh - u * 0.14, hw * 2 + pw * 2.6, u * 0.22);
  ctx.fillStyle = 'rgba(255,255,255,0.35)';
  ctx.fillRect(x - hw - pw * 1.3, y - gh - u * 0.14, hw * 2 + pw * 2.6, u * 0.05);
  // hanging banner with answer text
  const bw = hw * 1.8;
  const bh = u * 0.42;
  const by = y - gh + u * 0.12;
  ctx.fillStyle = vis === 'right' || vis === 'reveal' ? C.correct : vis === 'wrong' ? C.wrong : C.parchment;
  rr(ctx, x - bw / 2, by, bw, bh, u * 0.06);
  ctx.fill();
  const fs = u * 0.19;
  if (fs >= 8.5) {
    ctx.fillStyle = vis === 'idle' || vis === 'active' ? C.ink : '#fff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    let size = fs;
    const text = g.group.answers[g.lane];
    ctx.font = `800 ${size}px ${FONT_BODY}`;
    let tw = ctx.measureText(text).width;
    if (tw > bw * 0.9) {
      size = Math.max(7, size * ((bw * 0.9) / tw));
      ctx.font = `800 ${size}px ${FONT_BODY}`;
    }
    ctx.fillText(text, x, by + bh / 2 + 1);
  }
  ctx.globalAlpha = 1;
}

export function drawEntity(ctx: CanvasRenderingContext2D, v: View, e: Entity, relZ: number, camX: number, time: number) {
  if (e.kind === 'coin') drawCoin(ctx, v, e, relZ, camX, time);
  else if (e.kind === 'obstacle') drawObstacle(ctx, v, e, relZ, camX);
  else drawGate(ctx, v, e, relZ, camX, time);
}

// ---------- player ----------
export function drawPlayer(ctx: CanvasRenderingContext2D, v: View, p: PlayerState, worldX: number, camX: number, time: number) {
  const gp = project(v, worldX, 0, 0, camX);
  const gx = gp.x;
  const gy = gp.y;
  const u = v.laneW;

  const shScale = 1 - Math.min(0.55, p.y * 0.3);
  ctx.fillStyle = 'rgba(30,10,0,0.35)';
  ellipse(ctx, gx, gy, u * 0.34 * shScale, u * 0.1 * shScale);

  if (p.invulnT > 0 && Math.floor(p.invulnT * 14) % 2 === 0) ctx.globalAlpha = 0.45;

  ctx.save();
  ctx.translate(gx, gy - p.y * u);
  if (p.fallT > 0) {
    const f = Math.min(1, p.fallT * 1.6);
    const ease = 1 - Math.pow(1 - f, 3);
    ctx.rotate(ease * Math.PI * 0.5 * (p.lean >= 0 ? 1 : -1));
    ctx.translate(0, ease * u * 0.1);
  }
  ctx.rotate(p.lean * 0.28);
  ctx.scale(1 / p.squash, p.squash);
  const ph = p.runPhase;
  const sw = Math.sin(ph);
  const airborne = !p.grounded;
  const bob = airborne ? 0 : Math.abs(Math.cos(ph)) * 0.05 * u;
  ctx.translate(0, -bob);
  const stumbling = p.stumbleT > 0;
  if (stumbling) ctx.rotate(Math.sin(time * 40) * 0.12);

  // cape / scarf (behind body)
  const wave = Math.sin(time * 11) * 0.08 * u;
  const wave2 = Math.cos(time * 9) * 0.06 * u;
  ctx.strokeStyle = C.sash;
  ctx.lineWidth = u * 0.11;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, -u * 1.02);
  ctx.quadraticCurveTo(-u * 0.25 + wave, -u * 1.05 - (airborne ? u * 0.1 : 0), -u * 0.52 + wave2, -u * (0.82 + (airborne ? 0.25 : 0)) + wave);
  ctx.stroke();

  // legs
  const liftA = airborne ? u * 0.22 : Math.max(0, sw) * 0.32 * u;
  const liftB = airborne ? u * 0.22 : Math.max(0, -sw) * 0.32 * u;
  ctx.lineWidth = u * 0.15;
  ctx.strokeStyle = C.skin;
  ctx.beginPath();
  ctx.moveTo(-u * 0.11, -u * 0.5);
  ctx.lineTo(-u * 0.13, -liftA);
  ctx.moveTo(u * 0.11, -u * 0.5);
  ctx.lineTo(u * 0.13, -liftB);
  ctx.stroke();
  ctx.fillStyle = C.woodDark;
  ellipse(ctx, -u * 0.13, -liftA + u * 0.02, u * 0.1, u * 0.06);
  ellipse(ctx, u * 0.13, -liftB + u * 0.02, u * 0.1, u * 0.06);

  // robe
  ctx.fillStyle = C.robe;
  ctx.beginPath();
  ctx.moveTo(-u * 0.31, -u * 0.42);
  ctx.lineTo(u * 0.31, -u * 0.42);
  ctx.lineTo(u * 0.25, -u * 1.02);
  ctx.quadraticCurveTo(0, -u * 1.1, -u * 0.25, -u * 1.02);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = C.robeDark;
  ctx.fillRect(u * 0.12, -u * 1.0, u * 0.14, u * 0.56);
  ctx.fillStyle = C.tunic;
  ctx.fillRect(-u * 0.06, -u * 1.02, u * 0.12, u * 0.6);
  // sash
  ctx.save();
  ctx.translate(0, -u * 0.72);
  ctx.rotate(-0.45);
  ctx.fillStyle = C.sash;
  ctx.fillRect(-u * 0.34, -u * 0.05, u * 0.68, u * 0.1);
  ctx.restore();
  // belt
  ctx.fillStyle = C.goldDark;
  ctx.fillRect(-u * 0.29, -u * 0.62, u * 0.58, u * 0.06);

  // arms
  ctx.lineWidth = u * 0.13;
  ctx.strokeStyle = C.skin;
  ctx.beginPath();
  if (stumbling || airborne) {
    ctx.moveTo(-u * 0.26, -u * 0.95);
    ctx.lineTo(-u * 0.46, -u * 1.28 + (stumbling ? Math.sin(time * 30) * u * 0.08 : 0));
    ctx.moveTo(u * 0.26, -u * 0.95);
    ctx.lineTo(u * 0.46, -u * 1.28 - (stumbling ? Math.sin(time * 30) * u * 0.08 : 0));
  } else {
    ctx.moveTo(-u * 0.26, -u * 0.95);
    ctx.lineTo(-u * 0.38, -u * 0.72 - sw * u * 0.2);
    ctx.moveTo(u * 0.26, -u * 0.95);
    ctx.lineTo(u * 0.38, -u * 0.72 + sw * u * 0.2);
  }
  ctx.stroke();
  // sleeves
  ctx.strokeStyle = C.robe;
  ctx.lineWidth = u * 0.15;
  ctx.beginPath();
  ctx.moveTo(-u * 0.25, -u * 0.96);
  ctx.lineTo(-u * 0.3, -u * 0.88 - (airborne || stumbling ? u * 0.15 : sw * u * 0.08));
  ctx.moveTo(u * 0.25, -u * 0.96);
  ctx.lineTo(u * 0.3, -u * 0.88 - (airborne || stumbling ? u * 0.15 : -sw * u * 0.08));
  ctx.stroke();

  // neck + head
  ctx.fillStyle = C.skin;
  ctx.fillRect(-u * 0.06, -u * 1.12, u * 0.12, u * 0.12);
  circle(ctx, 0, -u * 1.3, u * 0.23);
  ctx.fillStyle = C.hair;
  ctx.beginPath();
  ctx.arc(0, -u * 1.31, u * 0.235, Math.PI * 0.95, Math.PI * 2.05);
  ctx.closePath();
  ctx.fill();
  ctx.fillRect(-u * 0.235, -u * 1.31, u * 0.47, u * 0.12);
  ctx.fillStyle = C.skin;
  circle(ctx, -u * 0.23, -u * 1.29, u * 0.05);
  circle(ctx, u * 0.23, -u * 1.29, u * 0.05);
  // headband
  ctx.fillStyle = C.gold;
  ctx.fillRect(-u * 0.24, -u * 1.37, u * 0.48, u * 0.065);
  ctx.strokeStyle = C.gold;
  ctx.lineWidth = u * 0.045;
  ctx.beginPath();
  ctx.moveTo(0, -u * 1.34);
  ctx.quadraticCurveTo(-u * 0.12 + wave, -u * 1.45, -u * 0.26 + wave2, -u * 1.36 + wave);
  ctx.moveTo(0, -u * 1.34);
  ctx.quadraticCurveTo(-u * 0.1 + wave2, -u * 1.25, -u * 0.24 + wave, -u * 1.18 - wave2);
  ctx.stroke();

  ctx.restore();
  ctx.globalAlpha = 1;
}

// ---------- question UI ----------
export function drawSigns(ctx: CanvasRenderingContext2D, v: View, g: QuestionGroup, relZ: number, camX: number, time: number) {
  const s = scaleAt(Math.max(relZ, 0));
  const spreadFar = Math.min(v.W * 0.31, 240);
  const spacing = Math.max(v.laneW * s, spreadFar);
  const signW = Math.min(spreadFar - 12, 220);
  const signH = Math.max(40, Math.min(58, v.H * 0.065));
  const cy = signCenterY(v, bannerLayout(ctx, v, g), signH);
  const camPx = -camX * v.laneW * s;
  const age = time - g.activatedAt;
  const pop = age < 0.5 ? elasticOut(clamp01(age / 0.5)) : 1;
  const near = clamp01((s - 0.3) / 0.7);

  if (!g.fits || g.fits.w !== signW) {
    g.fits = { w: signW, items: g.answers.map((a) => fitText(ctx, a, signW - 18, signH > 48 ? 19 : 17, 10, FONT_BODY, 2)) };
  }
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  for (let i = 0; i < 3; i++) {
    let x = v.W / 2 + (i - 1) * spacing + camPx;
    let scale = pop * (1 + near * 0.12);
    let fill = C.parchment;
    let textColor = C.ink;
    let border = C.goldDark;
    let alpha = 1;
    if (g.resolved) {
      const t = g.resultT;
      if (i === g.chosenLane) {
        fill = g.wasCorrect ? C.correct : C.wrong;
        border = g.wasCorrect ? C.correctDark : C.wrongDark;
        textColor = '#fff';
        scale *= 1 + 0.22 * Math.sin(Math.min(t * 5, Math.PI));
        if (!g.wasCorrect) x += Math.sin(t * 45) * 7 * Math.max(0, 1 - t * 2);
      } else if (i === g.correctLane) {
        fill = C.correct;
        border = C.correctDark;
        textColor = '#fff';
        scale *= 1 + 0.08 * Math.sin(t * 8);
      } else alpha = 0.35;
      alpha *= clamp01(1 - (t - 1.1) / 0.4);
    }
    if (alpha <= 0) continue;
    ctx.globalAlpha = alpha;

    // beam to the gate
    if (relZ > 0.2 && (!g.resolved || g.resultT < 0.6)) {
      const gp = project(v, i - 1, 2.05, relZ, camX);
      ctx.strokeStyle = border;
      ctx.globalAlpha = alpha * 0.35;
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 6]);
      ctx.lineDashOffset = -time * 40;
      ctx.beginPath();
      ctx.moveTo(x, cy + (signH / 2) * scale);
      ctx.lineTo(gp.x, gp.y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = alpha;
    }

    ctx.save();
    ctx.translate(x, cy);
    ctx.scale(scale, scale);
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    rr(ctx, -signW / 2 + 3, -signH / 2 + 4, signW, signH, 10);
    ctx.fill();
    ctx.fillStyle = fill;
    rr(ctx, -signW / 2, -signH / 2, signW, signH, 10);
    ctx.fill();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = border;
    ctx.stroke();
    // lane arrow chip
    ctx.fillStyle = border;
    ctx.globalAlpha = alpha * 0.9;
    ctx.font = `900 11px ${FONT_BODY}`;
    ctx.fillText(i === 0 ? '◀' : i === 1 ? '▲' : '▶', 0, -signH / 2 - 9);
    ctx.globalAlpha = alpha;
    const fit = g.fits.items[i];
    ctx.fillStyle = textColor;
    ctx.font = `800 ${fit.size}px ${FONT_BODY}`;
    const lh = fit.size * 1.1;
    const startY = -((fit.lines.length - 1) * lh) / 2 + 1;
    for (let k = 0; k < fit.lines.length; k++) ctx.fillText(fit.lines[k], 0, startY + k * lh);
    ctx.restore();
  }
  ctx.globalAlpha = 1;
}

export interface BannerLayout { x0: number; y0: number; bw: number; bh: number; fontSize: number; lineH: number; lines: string[] }

/** Computes (and caches) the banner geometry so the signs can avoid overlapping it. */
export function bannerLayout(ctx: CanvasRenderingContext2D, v: View, g: QuestionGroup): BannerLayout {
  const { W, H } = v;
  const bw = Math.min(W - 20, 620);
  const x0 = (W - bw) / 2;
  const fontSize = W < 480 ? 15 : W < 900 ? 17 : 19;
  ctx.font = `800 ${fontSize}px ${FONT_BODY}`;
  if (!g.lines || g.linesWidth !== bw) {
    g.lines = wrapText(ctx, g.question.q, bw - 56);
    g.linesWidth = bw;
  }
  const lineH = fontSize * 1.28;
  const bh = 26 + g.lines.length * lineH + 18;
  const pad = W < 480 ? 12 : 20;
  // If the banner would collide with the score block on the left, push it below the HUD row.
  const y0 = x0 < 215 ? pad + 104 : Math.max(16, H * 0.06);
  return { x0, y0, bw, bh, fontSize, lineH, lines: g.lines };
}

export function signCenterY(v: View, layout: BannerLayout, signH: number) {
  return Math.max(v.H * 0.295, layout.y0 + layout.bh + signH / 2 + 18);
}

export function drawBanner(ctx: CanvasRenderingContext2D, v: View, g: QuestionGroup, time: number, remaining: number) {
  const { W } = v;
  const layout = bannerLayout(ctx, v, g);
  const { x0, bw, bh, fontSize, lineH } = layout;
  g.lines = layout.lines;
  const age = time - g.activatedAt;
  const slide = easeOutBack(clamp01(age / 0.45));
  let fade = 1;
  if (g.resolved) fade = clamp01(1 - (g.resultT - 1.1) / 0.4);
  if (fade <= 0) return;
  const y0 = layout.y0 - (1 - slide) * (bh + layout.y0 + 20);
  ctx.globalAlpha = fade;

  ctx.fillStyle = 'rgba(0,0,0,0.3)';
  rr(ctx, x0 + 3, y0 + 5, bw, bh, 12);
  ctx.fill();
  ctx.fillStyle = C.parchment;
  rr(ctx, x0, y0, bw, bh, 12);
  ctx.fill();
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = C.goldDark;
  ctx.stroke();
  // scroll rolls
  ctx.fillStyle = C.parchmentDark;
  rr(ctx, x0 - 6, y0 - 4, 14, bh + 8, 7);
  ctx.fill();
  rr(ctx, x0 + bw - 8, y0 - 4, 14, bh + 8, 7);
  ctx.fill();
  ctx.strokeStyle = C.goldDark;
  ctx.lineWidth = 1.5;
  rr(ctx, x0 - 6, y0 - 4, 14, bh + 8, 7);
  ctx.stroke();
  rr(ctx, x0 + bw - 8, y0 - 4, 14, bh + 8, 7);
  ctx.stroke();

  // category chip
  ctx.font = `900 10px ${FONT_BODY}`;
  const cat = g.question.cat.toUpperCase();
  const cw = ctx.measureText(cat).width + 16;
  ctx.fillStyle = C.goldDark;
  rr(ctx, x0 + 16, y0 + 8, cw, 16, 8);
  ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillText(cat, x0 + 24, y0 + 16.5);

  // chapter chip on the right
  ctx.textAlign = 'right';
  ctx.fillStyle = C.ink;
  ctx.globalAlpha = fade * 0.55;
  ctx.fillText(`Q${g.id}`, x0 + bw - 18, y0 + 16.5);
  ctx.globalAlpha = fade;

  ctx.textAlign = 'center';
  if (g.resolved) {
    ctx.font = `800 ${fontSize + 1}px ${FONT_BODY}`;
    ctx.fillStyle = g.wasCorrect ? C.correctDark : C.wrongDark;
    const msg = g.wasCorrect ? '✓  Correct!' : `✗  Answer: ${g.answers[g.correctLane]}`;
    ctx.fillText(msg, W / 2, y0 + 26 + (g.lines.length * lineH) / 2);
  } else {
    ctx.font = `800 ${fontSize}px ${FONT_BODY}`;
    ctx.fillStyle = C.ink;
    for (let i = 0; i < g.lines.length; i++) {
      ctx.fillText(g.lines[i], W / 2, y0 + 26 + lineH * (i + 0.5));
    }
  }
  // timer bar
  const barY = y0 + bh - 12;
  ctx.fillStyle = 'rgba(58,36,18,0.15)';
  rr(ctx, x0 + 16, barY, bw - 32, 6, 3);
  ctx.fill();
  if (!g.resolved) {
    const w = (bw - 32) * remaining;
    ctx.fillStyle = remaining < 0.25 ? C.wrong : C.goldDark;
    if (w > 6) {
      rr(ctx, x0 + 16, barY, w, 6, 3);
      ctx.fill();
    }
  }
  ctx.globalAlpha = 1;
}

// ---------- HUD ----------
export function drawHUD(ctx: CanvasRenderingContext2D, v: View, sc: Scene) {
  const { W, H } = v;
  const pad = W < 480 ? 12 : 20;
  ctx.textBaseline = 'top';
  ctx.lineJoin = 'round';

  // score
  ctx.textAlign = 'left';
  ctx.font = `900 11px ${FONT_BODY}`;
  ctx.fillStyle = C.gold;
  ctx.fillText('SCORE', pad, pad);
  const bump = 1 + sc.scoreBump * 0.18;
  ctx.font = `700 ${Math.round(30 * bump)}px ${FONT_DISPLAY}`;
  ctx.lineWidth = 4;
  ctx.strokeStyle = 'rgba(20,8,0,0.8)';
  const scoreText = fmt(sc.scoreDisplay);
  ctx.strokeText(scoreText, pad, pad + 13);
  ctx.fillStyle = '#fff';
  ctx.fillText(scoreText, pad, pad + 13);
  ctx.font = `800 12px ${FONT_BODY}`;
  ctx.fillStyle = 'rgba(255,255,255,0.8)';
  ctx.fillText(`BEST ${fmt(Math.max(sc.best, sc.score))}`, pad, pad + 50);

  // hearts
  for (let i = 0; i < MAX_LIVES; i++) {
    const alive = i < sc.lives;
    const r = 9 * (i === sc.lives - 1 && sc.heartBump > 0 ? 1 + sc.heartBump * 0.4 : 1) * (i === sc.lives && sc.heartBump > 0 ? 1 + sc.heartBump * 0.5 : 1);
    drawHeart(ctx, pad + 12 + i * 26, pad + 80, r, alive ? C.wrong : 'rgba(0,0,0,0.35)', alive);
  }

  // coins (top-right, under the pause button)
  ctx.textAlign = 'right';
  const cbump = 1 + sc.coinBump * 0.3;
  const cx = W - pad - 10;
  const cy = pad + 68;
  ctx.fillStyle = C.goldDark;
  circle(ctx, cx, cy, 10 * cbump);
  ctx.fillStyle = C.gold;
  circle(ctx, cx, cy, 7.5 * cbump);
  ctx.fillStyle = C.goldDark;
  ctx.fillRect(cx - 1.2, cy - 4.5, 2.4, 9);
  ctx.fillRect(cx - 3.5, cy - 2, 7, 2);
  ctx.font = `800 ${Math.round(18 * (1 + sc.coinBump * 0.15))}px ${FONT_BODY}`;
  ctx.textBaseline = 'middle';
  ctx.lineWidth = 3;
  ctx.strokeStyle = 'rgba(20,8,0,0.8)';
  ctx.strokeText(String(sc.coins), cx - 16, cy);
  ctx.fillStyle = '#fff';
  ctx.fillText(String(sc.coins), cx - 16, cy);

  // combo badge
  if (sc.combo > 1) {
    const bx = W - pad - 30;
    const by = H * 0.56;
    const k = 1 + sc.comboBump * 0.35;
    ctx.save();
    ctx.translate(bx, by);
    ctx.scale(k, k);
    ctx.rotate(Math.sin(sc.time * 3) * 0.06);
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    circle(ctx, 2, 3, 27);
    ctx.fillStyle = C.gold;
    circle(ctx, 0, 0, 27);
    ctx.fillStyle = C.goldLight;
    circle(ctx, 0, 0, 22);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = C.ink;
    ctx.font = `700 20px ${FONT_DISPLAY}`;
    ctx.fillText(`×${sc.combo}`, 0, 1);
    ctx.font = `900 9px ${FONT_BODY}`;
    ctx.fillStyle = C.goldDark;
    ctx.fillText('COMBO', 0, -32);
    ctx.restore();
  }
}

export function drawSpeedLines(ctx: CanvasRenderingContext2D, v: View, intensity: number, time: number) {
  const { W, H } = v;
  const cx = W / 2;
  const cy = H * 0.5;
  ctx.strokeStyle = `rgba(255,245,220,${0.4 * intensity})`;
  ctx.lineWidth = 2;
  ctx.beginPath();
  const rOuter = Math.max(W, H) * 0.8;
  for (let i = 0; i < 18; i++) {
    const a = (i / 18) * Math.PI * 2 + Math.sin(time * 3 + i) * 0.08;
    const rInner = rOuter * (0.5 + 0.18 * Math.sin(time * 25 + i * 1.7));
    ctx.moveTo(cx + Math.cos(a) * rInner, cy + Math.sin(a) * rInner);
    ctx.lineTo(cx + Math.cos(a) * rOuter, cy + Math.sin(a) * rOuter);
  }
  ctx.stroke();
}

export function drawGo(ctx: CanvasRenderingContext2D, v: View, t: number) {
  // t counts down from 1.4 to 0
  const life = 1.4;
  const k = 1 - t / life;
  const scale = k < 0.25 ? easeOutBack(k / 0.25) * 1.0 : 1;
  const alpha = t < 0.35 ? t / 0.35 : 1;
  ctx.save();
  ctx.translate(v.W / 2, v.H * 0.5);
  ctx.scale(scale, scale);
  ctx.globalAlpha = alpha;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = `700 ${Math.round(Math.min(v.W * 0.16, 84))}px ${FONT_DISPLAY}`;
  ctx.lineWidth = 8;
  ctx.strokeStyle = 'rgba(30,10,0,0.85)';
  ctx.strokeText('RUN!', 0, 0);
  ctx.fillStyle = C.gold;
  ctx.fillText('RUN!', 0, 0);
  ctx.restore();
}
