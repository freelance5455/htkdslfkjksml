import { ChatMessage, ElementType, PlacedStructure, RemotePlayer } from '../types/gameTypes';

export interface MultiplayerCallbacks {
  onStatusChange: (status: 'offline' | 'connecting' | 'online', roomCode: string) => void;
  onPlayersUpdate: (players: RemotePlayer[], selfId: string) => void;
  onRemoteAction: (action: {
    id: string;
    action: string;
    element?: ElementType;
    spellId?: string;
    tx?: number;
    ty?: number;
    tz?: number;
  }) => void;
  onChatMessage: (msg: ChatMessage) => void;
  onBossSync: (bossId: string, hp: number) => void;
  onRemoteStructure: (s: PlacedStructure) => void;
}

export class MultiplayerClient {
  private ws: WebSocket | null = null;
  private selfId = '';
  private roomCode = '';
  private players = new Map<string, RemotePlayer>();
  private callbacks: MultiplayerCallbacks;
  private lastSendAt = 0;

  constructor(callbacks: MultiplayerCallbacks) {
    this.callbacks = callbacks;
  }

  public connect(roomCode: string, localPlayer: Omit<RemotePlayer, 'id'>) {
    this.disconnect();
    this.roomCode = roomCode.trim().toUpperCase() || 'REALM-1';
    this.callbacks.onStatusChange('connecting', this.roomCode);

    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = `${proto}//${window.location.host}/ws`;
    const ws = new WebSocket(url);
    this.ws = ws;

    ws.onopen = () => {
      ws.send(
        JSON.stringify({
          type: 'room:join',
          roomCode: this.roomCode,
          player: localPlayer,
        })
      );
    };

    ws.onmessage = (ev) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(String(ev.data));
      } catch {
        return;
      }
      const type = String(msg.type || '');
      if (type === 'room:init') {
        this.selfId = String(msg.selfId || '');
        this.roomCode = String(msg.roomCode || this.roomCode);
        this.players.clear();
        const list = (msg.players as RemotePlayer[]) || [];
        for (const p of list) {
          if (p.id !== this.selfId) this.players.set(p.id, p);
        }
        this.callbacks.onStatusChange('online', this.roomCode);
        this.callbacks.onPlayersUpdate(Array.from(this.players.values()), this.selfId);
        const structures = (msg.structures as PlacedStructure[]) || [];
        for (const s of structures) this.callbacks.onRemoteStructure(s);
        const bossHp = (msg.bossHp as Record<string, number>) || {};
        for (const [bid, hp] of Object.entries(bossHp)) {
          this.callbacks.onBossSync(bid, hp);
        }
      } else if (type === 'player:join') {
        const p = msg.player as RemotePlayer;
        if (p && p.id !== this.selfId) {
          this.players.set(p.id, p);
          this.callbacks.onPlayersUpdate(Array.from(this.players.values()), this.selfId);
        }
      } else if (type === 'player:leave') {
        const id = String(msg.id || '');
        this.players.delete(id);
        this.callbacks.onPlayersUpdate(Array.from(this.players.values()), this.selfId);
      } else if (type === 'player:state') {
        const p = msg.player as RemotePlayer;
        if (p && p.id !== this.selfId) {
          this.players.set(p.id, p);
          this.callbacks.onPlayersUpdate(Array.from(this.players.values()), this.selfId);
        }
      } else if (type === 'player:action') {
        this.callbacks.onRemoteAction({
          id: String(msg.id || ''),
          action: String(msg.action || ''),
          element: msg.element as ElementType | undefined,
          spellId: msg.spellId as string | undefined,
          tx: msg.tx as number | undefined,
          ty: msg.ty as number | undefined,
          tz: msg.tz as number | undefined,
        });
      } else if (type === 'chat:message') {
        this.callbacks.onChatMessage({
          id: String(msg.id || Date.now()),
          senderId: String(msg.senderId || ''),
          senderName: String(msg.senderName || 'Adventurer'),
          text: String(msg.text || ''),
          timestamp: Number(msg.timestamp || Date.now()),
        });
      } else if (type === 'boss:sync') {
        this.callbacks.onBossSync(String(msg.bossId || ''), Number(msg.hp ?? 0));
      } else if (type === 'world:structure') {
        const s = msg.structure as PlacedStructure;
        if (s) this.callbacks.onRemoteStructure(s);
      }
    };

    ws.onclose = () => {
      this.players.clear();
      this.callbacks.onPlayersUpdate([], '');
      this.callbacks.onStatusChange('offline', '');
    };
  }

  public sendPlayerState(state: Omit<RemotePlayer, 'id' | 'name' | 'hairColor' | 'skinColor' | 'armorColor'>) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    const now = performance.now();
    if (now - this.lastSendAt < 65) return; // ~15Hz sync
    this.lastSendAt = now;
    this.ws.send(JSON.stringify({ type: 'player:state', ...state }));
  }

  public sendAction(action: string, extra?: Record<string, unknown>) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'player:action', action, ...extra }));
  }

  public sendChat(text: string) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'chat:message', text }));
  }

  public sendBossHp(bossId: string, hp: number) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'boss:damage', bossId, hp }));
  }

  public sendStructure(structure: PlacedStructure) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'world:structure', structure }));
  }

  public disconnect() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.players.clear();
    this.callbacks.onStatusChange('offline', '');
  }
}
