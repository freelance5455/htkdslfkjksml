import { UNITS_CONFIG } from './gameConfig';
import { UnitType } from '../types/kingdom';

/**
 * Default player capital castle coordinate on the Iberian medieval map.
 */
export const PLAYER_CASTLE_COORDS = { x: 5, y: 5 };

/**
 * Calculates Euclidean distance between two 2D points on the map grid.
 */
export function calculateDistance(
  x1: number,
  y1: number,
  x2: number,
  y2: number
): number {
  const dx = x2 - x1;
  const dy = y2 - y1;
  return Math.round(Math.hypot(dx, dy) * 10) / 10;
}

/**
 * Calculates march duration in seconds based on target distance, slowest troop speed in expedition, and logistics tech.
 */
export function calculateMarchDurationSeconds(
  distance: number,
  armyUnits: Partial<Record<UnitType, number>>,
  militaryLogisticsLevel: number = 0
): number {
  let minSpeed = 30; // default high
  let hasTroops = false;
  Object.entries(armyUnits).forEach(([uKey, count]) => {
    if (count && count > 0) {
      hasTroops = true;
      const unit = UNITS_CONFIG[uKey as UnitType];
      if (unit && unit.speed < minSpeed) {
        minSpeed = unit.speed;
      }
    }
  });

  if (!hasTroops) minSpeed = 10;

  // Base speed factor (seconds per unit of distance, slower unit = longer time)
  // Distance 1 with speed 10 takes ~15 seconds base
  const baseSeconds = (distance * 150) / minSpeed;

  // Logistics tech discount: 5% reduction per level, capped at 40%
  const logisticsDiscount = Math.min(0.4, militaryLogisticsLevel * 0.05);
  const finalSeconds = Math.max(5, Math.round(baseSeconds * (1 - logisticsDiscount)));
  return finalSeconds;
}

/**
 * Formats duration in seconds into human-readable string (e.g., '1m 20s' or '45s').
 */
export function formatDurationSeconds(seconds: number): string {
  if (seconds < 60) {
    return `${seconds}s`;
  }
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return s > 0 ? `${m}m ${s}s` : `${m}m`;
}
