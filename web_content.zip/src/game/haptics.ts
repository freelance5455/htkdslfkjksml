/** Thin wrapper around the Vibration API (Android Chrome / WebView). */
class Haptics {
  enabled = true;
  private readonly supported =
    typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function';

  private vibrate(pattern: number | number[]): void {
    if (!this.enabled || !this.supported) return;
    try {
      navigator.vibrate(pattern);
    } catch {
      /* ignore */
    }
  }

  tap(): void {
    this.vibrate(8);
  }

  place(): void {
    this.vibrate(14);
  }

  clear(lines: number): void {
    if (lines >= 3) this.vibrate([18, 30, 24, 30, 36]);
    else if (lines === 2) this.vibrate([16, 30, 26]);
    else this.vibrate(22);
  }

  fail(): void {
    this.vibrate([10, 40, 12]);
  }

  gameOver(): void {
    this.vibrate([40, 60, 40, 60, 80]);
  }

  record(): void {
    this.vibrate([20, 40, 20, 40, 20, 40, 60]);
  }
}

export const haptics = new Haptics();
