import test from 'node:test';
import assert from 'node:assert/strict';
import { CombatSystem } from './combat';
import { ARMORS, MONSTERS, WEAPONS } from './constants';
import { ActiveMonsterState, PlayerStats } from './types';
import { WorldManager } from './world';

// Mock player stats
function createTestPlayer(): PlayerStats {
  return {
    level: 1,
    hunterRank: 1,
    hunterXp: 0,
    nextRankXp: 300,
    zenny: 1000,
    hp: 120,
    maxHp: 120,
    stamina: 100,
    maxStamina: 100,
    equippedWeaponId: 'iron_greatsword',
    equippedArmor: {
      head: 'hunter_helm',
      chest: 'hunter_mail',
      arms: 'hunter_vambraces',
      legs: 'hunter_greaves',
      charm: 'rookie_charm',
    },
    pouch: [],
    selectedPouchIndex: 0,
    spiritGauge: 0,
    spiritLevel: 0,
    spiritDuration: 0,
    demonMode: false,
    demonGauge: 0,
    chargeLevel: 0,
    chargeTimer: 0,
    bowCoating: 'none',
  };
}

function createTestMonster(defId: string): ActiveMonsterState {
  const def = MONSTERS[defId];
  return {
    defId,
    x: 500,
    y: 500,
    vx: 0,
    vy: 0,
    angle: 0,
    hp: def.baseHp,
    maxHp: def.baseHp,
    stamina: 100,
    state: 'idle',
    stateTimer: 2.0,
    enraged: false,
    enrageTimer: 0,
    parts: def.parts.map((p) => ({ ...p })),
    currentAttack: null,
    attackTargetX: 0,
    attackTargetY: 0,
    staggerBuildup: 0,
    stunBuildup: 0,
    poisonBuildup: 0,
    isPoisoned: false,
    poisonTimer: 0,
    isCarved: false,
    targetHunter: false,
  };
}

test('CombatSystem: Attack calculation respects weapon stats and buffs', () => {
  const player = createTestPlayer();
  const ironGs = WEAPONS['iron_greatsword'];
  assert.equal(CombatSystem.calculatePlayerAttack(player), ironGs.attack);

  // Equip weapon with higher base attack
  player.equippedWeaponId = 'ashfang_greatsword';
  const ashGs = WEAPONS['ashfang_greatsword'];
  assert.equal(CombatSystem.calculatePlayerAttack(player), ashGs.attack);
});

test('CombatSystem: Longsword Spirit level boosts attack scaling', () => {
  const player = createTestPlayer();
  player.equippedWeaponId = 'iron_longsword';
  const baseLs = WEAPONS['iron_longsword'].attack;

  player.spiritLevel = 0;
  assert.equal(CombatSystem.calculatePlayerAttack(player), baseLs);

  player.spiritLevel = 3;
  const buffed = CombatSystem.calculatePlayerAttack(player);
  assert.ok(buffed > baseLs, 'Red spirit level should significantly increase attack');
  assert.equal(buffed, Math.round(baseLs * 1.35));
});

test('CombatSystem: Dual blades Demon Mode boosts attack scaling', () => {
  const player = createTestPlayer();
  player.equippedWeaponId = 'iron_dualblades';
  const baseDb = WEAPONS['iron_dualblades'].attack;

  player.demonMode = false;
  assert.equal(CombatSystem.calculatePlayerAttack(player), baseDb);

  player.demonMode = true;
  assert.equal(CombatSystem.calculatePlayerAttack(player), Math.round(baseDb * 1.25));
});

test('CombatSystem: Player defense calculation aggregates armor pieces', () => {
  const player = createTestPlayer();
  const baseDef = CombatSystem.calculatePlayerDefense(player);
  // Base 10 + weapon bonus 5 + helm 8 + mail 12 + vambraces 8 + greaves 8 + charm 4 = 55
  assert.ok(baseDef >= 50, `Expected defense >= 50, got ${baseDef}`);
});

test('CombatSystem: Attacking monster reduces HP and builds part damage', () => {
  const player = createTestPlayer();
  const monster = createTestMonster('mossback');
  const initialHp = monster.hp;

  const hit = CombatSystem.executeAttackOnMonster(player, monster, 1.0, 'standard', 0);
  assert.ok(hit.damage > 0, 'Attack should inflict damage');
  assert.equal(monster.hp, initialHp - hit.damage);
});

test('CombatSystem: Breaking monster parts triggers broken state and stagger', () => {
  const player = createTestPlayer();
  const monster = createTestMonster('mossback');

  // Find shell part and simulate damage exceeding threshold
  const shell = monster.parts.find((p) => p.id === 'shell');
  assert.ok(shell, 'Mossback should have a shell part');
  assert.equal(shell.broken, false);

  // Directly hit shell repeatedly
  for (let i = 0; i < 10; i++) {
    CombatSystem.executeAttackOnMonster(player, monster, 2.0, 'standard', Math.PI * 0.5);
    if (shell.broken) break;
  }

  assert.equal(shell.broken, true, 'Shell part should break when HP reaches 0');
});

test('CombatSystem: Lance guard reduces incoming monster damage', () => {
  const player = createTestPlayer();
  player.equippedWeaponId = 'iron_lance';

  // Unguarded
  const unblocked = CombatSystem.calculateMonsterDamageToPlayer(1.0, 30, 'none', player, false);
  // Guarded
  const blocked = CombatSystem.calculateMonsterDamageToPlayer(1.0, 30, 'none', player, true);

  assert.equal(blocked.blocked, true);
  assert.ok(blocked.finalDamage < unblocked.finalDamage, 'Guarding should block majority of damage');
});

test('WorldManager: Boundary and obstacle collision resolution prevents tunneling', () => {
  const world = new WorldManager();
  world.loadRegion('settlement');

  // Push player beyond left boundary
  const resolvedLeft = world.resolveCollision(-100, 500, 15);
  assert.ok(resolvedLeft.x >= 35, 'Entity should be bounded inside left margin');

  // Push player onto an obstacle
  const obs = world.obstacles[0];
  const insideObs = world.resolveCollision(obs.x, obs.y, 15);
  const dist = Math.hypot(insideObs.x - obs.x, insideObs.y - obs.y);
  assert.ok(dist >= obs.radius + 14, 'Collision pushout should move entity outside radius');
});
