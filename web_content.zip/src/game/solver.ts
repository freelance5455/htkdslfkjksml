import { Arrow, Direction, Point } from '../types/game';

/**
 * Builds a fast 1D grid representation of occupied cells.
 * Returns an Int32Array of size gridRows * gridCols.
 * Cell value is arrow index in activeArrows, or -1 if empty.
 */
export function buildOccupiedGrid(
  arrows: Arrow[],
  gridRows: number,
  gridCols: number
): Int32Array {
  const grid = new Int32Array(gridRows * gridCols).fill(-1);

  for (let idx = 0; idx < arrows.length; idx++) {
    const arrow = arrows[idx];
    if (arrow.isEscaping) continue;

    const pts = arrow.points;
    if (pts.length === 0) {
      if (arrow.row >= 0 && arrow.row < gridRows && arrow.col >= 0 && arrow.col < gridCols) {
        grid[arrow.row * gridCols + arrow.col] = idx;
      }
      continue;
    }

    for (let i = 0; i < pts.length; i++) {
      const p1 = pts[i];
      if (p1.y >= 0 && p1.y < gridRows && p1.x >= 0 && p1.x < gridCols) {
        grid[p1.y * gridCols + p1.x] = idx;
      }
      if (i < pts.length - 1) {
        const p2 = pts[i + 1];
        const dx = Math.sign(p2.x - p1.x);
        const dy = Math.sign(p2.y - p1.y);
        let currX = p1.x + dx;
        let currY = p1.y + dy;
        while ((dx !== 0 && currX !== p2.x) || (dy !== 0 && currY !== p2.y)) {
          if (currY >= 0 && currY < gridRows && currX >= 0 && currX < gridCols) {
            grid[currY * gridCols + currX] = idx;
          }
          currX += dx;
          currY += dy;
        }
      }
    }
  }

  return grid;
}

/**
 * Fast ray-check using a prebuilt occupied grid.
 */
export function isArrowPathClearWithGrid(
  arrow: Arrow,
  arrowIdx: number,
  occupiedGrid: Int32Array,
  gridRows: number,
  gridCols: number
): boolean {
  const head = arrow.points.length > 0 ? arrow.points[arrow.points.length - 1] : { x: arrow.col, y: arrow.row };
  let x = head.x;
  let y = head.y;

  switch (arrow.direction) {
    case 'UP':
      while (y > 0) {
        y -= 1;
        const occ = occupiedGrid[y * gridCols + x];
        if (occ !== -1 && occ !== arrowIdx) return false;
      }
      return true;

    case 'DOWN':
      while (y < gridRows - 1) {
        y += 1;
        const occ = occupiedGrid[y * gridCols + x];
        if (occ !== -1 && occ !== arrowIdx) return false;
      }
      return true;

    case 'LEFT':
      while (x > 0) {
        x -= 1;
        const occ = occupiedGrid[y * gridCols + x];
        if (occ !== -1 && occ !== arrowIdx) return false;
      }
      return true;

    case 'RIGHT':
      while (x < gridCols - 1) {
        x += 1;
        const occ = occupiedGrid[y * gridCols + x];
        if (occ !== -1 && occ !== arrowIdx) return false;
      }
      return true;
  }
}

/**
 * Checks if the forward escape ray from the arrow's head to the grid boundary is completely clear.
 */
export function isArrowPathClear(
  arrow: Arrow,
  allArrows: Arrow[],
  gridRows: number,
  gridCols: number
): boolean {
  const grid = buildOccupiedGrid(allArrows, gridRows, gridCols);
  const idx = allArrows.findIndex((a) => a.id === arrow.id);
  return isArrowPathClearWithGrid(arrow, idx, grid, gridRows, gridCols);
}

/**
 * Returns all arrows that can currently escape without hitting any other arrow.
 */
export function getEscapableArrows(
  arrows: Arrow[],
  gridRows: number,
  gridCols: number
): Arrow[] {
  const activeArrows = arrows.filter((a) => !a.isEscaping);
  if (activeArrows.length === 0) return [];

  const grid = buildOccupiedGrid(activeArrows, gridRows, gridCols);
  const escapable: Arrow[] = [];

  for (let i = 0; i < activeArrows.length; i++) {
    if (isArrowPathClearWithGrid(activeArrows[i], i, grid, gridRows, gridCols)) {
      escapable.push(activeArrows[i]);
    }
  }

  return escapable;
}

/**
 * Validates whether a level layout is 100% solvable from the current state.
 */
export function solveLevel(
  initialArrows: Arrow[],
  gridRows: number,
  gridCols: number
): string[] | null {
  let current = initialArrows.map((a) => ({ ...a, isEscaping: false }));
  const solutionOrder: string[] = [];

  while (current.length > 0) {
    const escapable = getEscapableArrows(current, gridRows, gridCols);
    if (escapable.length === 0) {
      return null; // Deadlock
    }

    const chosen = escapable[0];
    solutionOrder.push(chosen.id);
    current = current.filter((a) => a.id !== chosen.id);
  }

  return solutionOrder;
}

/**
 * Finds a hint arrow that can escape immediately.
 */
export function getHintArrow(
  arrows: Arrow[],
  gridRows: number,
  gridCols: number
): Arrow | null {
  const escapable = getEscapableArrows(arrows, gridRows, gridCols);
  if (escapable.length === 0) return null;

  // Prefer an arrow whose removal still leaves the puzzle solvable
  for (const candidate of escapable) {
    const remaining = arrows.filter((a) => !a.isEscaping && a.id !== candidate.id);
    if (solveLevel(remaining, gridRows, gridCols) !== null) {
      return candidate;
    }
  }

  return escapable[0];
}
