/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ArrowConfig, Direction, Point, PuzzleComplexityMetrics } from './types';

export const DIR_DELTA: Record<Direction, { dx: number; dy: number; angle: number }> = {
  UP: { dx: 0, dy: -1, angle: -Math.PI / 2 },
  RIGHT: { dx: 1, dy: 0, angle: 0 },
  DOWN: { dx: 0, dy: 1, angle: Math.PI / 2 },
  LEFT: { dx: -1, dy: 0, angle: Math.PI },
};

/**
 * Returns all grid cells occupied by an arrow (supports both polyline paths and legacy single-cell arrows).
 */
export function getArrowCells(arrow: ArrowConfig): Point[] {
  if (arrow.path && arrow.path.length > 0) {
    return arrow.path;
  }
  return [{ x: arrow.x, y: arrow.y }];
}

/**
 * Returns the head grid cell from which the arrow's exit ray originates.
 */
export function getArrowHead(arrow: ArrowConfig): Point {
  if (arrow.path && arrow.path.length > 0) {
    return arrow.path[arrow.path.length - 1];
  }
  return { x: arrow.x, y: arrow.y };
}

/**
 * Checks if a point `target` lies strictly ahead of `head` along `dir`.
 */
export function isCellOnRay(head: Point, dir: Direction, target: Point): boolean {
  const { dx, dy } = DIR_DELTA[dir];

  if (dx === 1) {
    return target.x > head.x + 0.1 && Math.abs(target.y - head.y) < 0.45;
  }
  if (dx === -1) {
    return target.x < head.x - 0.1 && Math.abs(target.y - head.y) < 0.45;
  }
  if (dy === 1) {
    return target.y > head.y + 0.1 && Math.abs(target.x - head.x) < 0.45;
  }
  if (dy === -1) {
    return target.y < head.y - 0.1 && Math.abs(target.x - head.x) < 0.45;
  }
  return false;
}

/**
 * Checks if arrow A's forward escape trajectory is obstructed by any cell of arrow B.
 */
export function isArrowBlockedBy(arrowA: ArrowConfig, arrowB: ArrowConfig): boolean {
  const head = getArrowHead(arrowA);
  const cellsB = getArrowCells(arrowB);
  for (const cell of cellsB) {
    if (isCellOnRay(head, arrowA.dir, cell)) {
      return true;
    }
  }
  return false;
}

/**
 * Checks if arrow with given ID can currently escape given active arrows.
 * Returns { canEscape: boolean, blocker?: ArrowConfig, blockerCell?: Point }
 */
export function canArrowEscape(
  arrow: ArrowConfig,
  activeArrows: ArrowConfig[]
): { canEscape: boolean; blocker?: ArrowConfig; blockerCell?: Point } {
  const head = getArrowHead(arrow);
  let closestBlocker: ArrowConfig | null = null;
  let closestCell: Point | undefined = undefined;
  let minDistance = Infinity;

  for (const other of activeArrows) {
    if (other.id === arrow.id) continue;
    const cells = getArrowCells(other);
    for (const cell of cells) {
      if (isCellOnRay(head, arrow.dir, cell)) {
        const dist = Math.hypot(cell.x - head.x, cell.y - head.y);
        if (dist < minDistance) {
          minDistance = dist;
          closestBlocker = other;
          closestCell = cell;
        }
      }
    }
  }

  const ownCells = getArrowCells(arrow);
  for (let i = 0; i < ownCells.length - 1; i++) {
    const cell = ownCells[i];
    if (isCellOnRay(head, arrow.dir, cell)) {
      const dist = Math.hypot(cell.x - head.x, cell.y - head.y);
      if (dist < minDistance) {
        minDistance = dist;
        closestBlocker = arrow;
        closestCell = cell;
      }
    }
  }

  return {
    canEscape: closestBlocker === null,
    blocker: closestBlocker || undefined,
    blockerCell: closestCell,
  };
}

/**
 * Counts 90-degree turns along an arrow's path.
 */
export function countArrowTurns(arrow: ArrowConfig): number {
  const pts = getArrowCells(arrow);
  if (pts.length < 3) return 0;
  let turns = 0;
  for (let i = 1; i < pts.length - 1; i++) {
    const dx1 = Math.sign(pts[i].x - pts[i - 1].x);
    const dy1 = Math.sign(pts[i].y - pts[i - 1].y);
    const dx2 = Math.sign(pts[i + 1].x - pts[i].x);
    const dy2 = Math.sign(pts[i + 1].y - pts[i].y);
    if (dx1 !== dx2 || dy1 !== dy2) {
      turns++;
    }
  }
  return turns;
}

/**
 * Builds a spatial grid index for O(gridSpan) raycasting & dependency graph construction.
 */
function buildDependencyGraph(arrows: ArrowConfig[]): {
  dependencies: Map<string, Set<string>>;
  dependencyEdges: number;
  selfBlockedIds: Set<string>;
} {
  const cellOwner = new Map<string, string>();
  let minX = Infinity;
  let maxX = -Infinity;
  let minY = Infinity;
  let maxY = -Infinity;

  for (const arrow of arrows) {
    const cells = getArrowCells(arrow);
    for (const c of cells) {
      const gx = Math.round(c.x);
      const gy = Math.round(c.y);
      cellOwner.set(`${gx},${gy}`, arrow.id);
      if (gx < minX) minX = gx;
      if (gx > maxX) maxX = gx;
      if (gy < minY) minY = gy;
      if (gy > maxY) maxY = gy;
    }
  }

  const dependencies = new Map<string, Set<string>>();
  const selfBlockedIds = new Set<string>();
  let dependencyEdges = 0;

  for (const arrow of arrows) {
    const deps = new Set<string>();
    const head = getArrowHead(arrow);
    const { dx, dy } = DIR_DELTA[arrow.dir];
    let cx = Math.round(head.x) + dx;
    let cy = Math.round(head.y) + dy;

    while (cx >= minX && cx <= maxX && cy >= minY && cy <= maxY) {
      const hitId = cellOwner.get(`${cx},${cy}`);
      if (hitId) {
        if (hitId === arrow.id) {
          selfBlockedIds.add(arrow.id);
        } else if (!deps.has(hitId)) {
          deps.add(hitId);
          dependencyEdges++;
        }
      }
      cx += dx;
      cy += dy;
    }

    dependencies.set(arrow.id, deps);
  }

  return { dependencies, dependencyEdges, selfBlockedIds };
}

/**
 * Solves the puzzle by finding a valid topological escape sequence.
 * Uses dependency graph so 100+ arrow puzzles solve in < 1ms.
 */
export function solvePuzzle(arrows: ArrowConfig[]): { solvable: boolean; solution: string[] } {
  const { dependencies, selfBlockedIds } = buildDependencyGraph(arrows);
  if (selfBlockedIds.size > 0) {
    return { solvable: false, solution: [] };
  }

  const activeIds = new Set(arrows.map((a) => a.id));
  const solution: string[] = [];

  while (activeIds.size > 0) {
    let picked: string | null = null;
    for (const id of activeIds) {
      const deps = dependencies.get(id)!;
      let blocked = false;
      for (const d of deps) {
        if (activeIds.has(d)) {
          blocked = true;
          break;
        }
      }
      if (!blocked) {
        picked = id;
        break;
      }
    }

    if (!picked) {
      return { solvable: false, solution: [] };
    }

    activeIds.delete(picked);
    solution.push(picked);
  }

  return { solvable: true, solution };
}

/**
 * Computes composite puzzle complexity score from topological & structural metrics.
 */
export function computeComplexityScore(params: {
  arrowCount: number;
  totalTurns: number;
  avgPathLength: number;
  blockedInitially: number;
  dependencyEdges: number;
  waveDepth: number;
}): number {
  return Math.round(
    params.arrowCount * 2.0 +
      params.totalTurns * 1.5 +
      params.avgPathLength * 4.0 +
      params.blockedInitially * 2.5 +
      params.dependencyEdges * 0.8 +
      params.waveDepth * 6.0
  );
}

/**
 * Full Puzzle Validation & Complexity Evaluation Engine.
 * Validates:
 * 1. Path continuity (orthogonal steps)
 * 2. Exit direction consistency
 * 3. Zero cell overlaps across arrows
 * 4. Complete escape simulation, dependency graph, wave depth, and complexity score
 */
export function validateAndEvaluatePuzzle(
  arrows: ArrowConfig[]
): { valid: boolean; reason?: string; metrics: PuzzleComplexityMetrics } {
  const emptyMetrics: PuzzleComplexityMetrics = {
    solvable: false,
    arrowCount: arrows.length,
    totalCells: 0,
    avgPathLength: 0,
    totalTurns: 0,
    avgTurnsPerArrow: 0,
    blockedInitially: 0,
    blockedRatio: 0,
    dependencyEdges: 0,
    waveDepth: 0,
    complexityScore: 0,
    solution: [],
  };

  if (arrows.length === 0) {
    return { valid: false, reason: 'No arrows in puzzle', metrics: emptyMetrics };
  }

  const occupiedCells = new Set<string>();
  let totalCells = 0;
  let totalTurns = 0;

  for (const arrow of arrows) {
    const cells = getArrowCells(arrow);
    if (cells.length === 0) {
      return { valid: false, reason: `Arrow ${arrow.id} has empty path`, metrics: emptyMetrics };
    }

    for (let i = 0; i < cells.length; i++) {
      const c = cells[i];
      const k = `${Math.round(c.x)},${Math.round(c.y)}`;
      if (occupiedCells.has(k)) {
        return {
          valid: false,
          reason: `Cell collision at (${c.x}, ${c.y})`,
          metrics: emptyMetrics,
        };
      }
      occupiedCells.add(k);

      if (i > 0) {
        const prev = cells[i - 1];
        const manhattan = Math.abs(c.x - prev.x) + Math.abs(c.y - prev.y);
        if (Math.abs(manhattan - 1) > 0.01) {
          return {
            valid: false,
            reason: `Non-orthogonal path step in arrow ${arrow.id}`,
            metrics: emptyMetrics,
          };
        }
      }
    }

    if (cells.length >= 2) {
      const prev = cells[cells.length - 2];
      const head = cells[cells.length - 1];
      const { dx, dy } = DIR_DELTA[arrow.dir];
      if (head.x - prev.x !== dx || head.y - prev.y !== dy) {
        return {
          valid: false,
          reason: `Arrow ${arrow.id} exit direction mismatch`,
          metrics: emptyMetrics,
        };
      }
    }

    totalCells += cells.length;
    totalTurns += countArrowTurns(arrow);
  }

  const { dependencies, dependencyEdges, selfBlockedIds } = buildDependencyGraph(arrows);
  const avgPathLength = totalCells / arrows.length;
  const avgTurnsPerArrow = totalTurns / arrows.length;

  // Count initially blocked arrows
  let blockedInitially = 0;
  for (const a of arrows) {
    const deps = dependencies.get(a.id)!;
    if (deps.size > 0 || selfBlockedIds.has(a.id)) {
      blockedInitially++;
    }
  }

  if (selfBlockedIds.size > 0) {
    return {
      valid: false,
      reason: 'Self-blocking arrow detected',
      metrics: {
        ...emptyMetrics,
        totalCells,
        avgPathLength,
        totalTurns,
        avgTurnsPerArrow,
        blockedInitially,
        blockedRatio: blockedInitially / arrows.length,
        dependencyEdges,
      },
    };
  }

  // Wave-by-wave topological peel using O(N + E) active-set checks
  const activeIds = new Set(arrows.map((a) => a.id));
  const solution: string[] = [];
  let waveDepth = 0;

  while (activeIds.size > 0) {
    const clearWave: string[] = [];
    for (const id of activeIds) {
      const deps = dependencies.get(id)!;
      let blocked = false;
      for (const depId of deps) {
        if (activeIds.has(depId)) {
          blocked = true;
          break;
        }
      }
      if (!blocked) {
        clearWave.push(id);
      }
    }

    if (clearWave.length === 0) {
      return {
        valid: false,
        reason: 'Deadlock detected during solution simulation',
        metrics: {
          ...emptyMetrics,
          totalCells,
          avgPathLength,
          totalTurns,
          avgTurnsPerArrow,
          blockedInitially,
          blockedRatio: blockedInitially / arrows.length,
          dependencyEdges,
          waveDepth,
        },
      };
    }

    waveDepth++;
    for (const id of clearWave) {
      activeIds.delete(id);
      solution.push(id);
    }
  }

  const complexityScore = computeComplexityScore({
    arrowCount: arrows.length,
    totalTurns,
    avgPathLength,
    blockedInitially,
    dependencyEdges,
    waveDepth,
  });

  const metrics: PuzzleComplexityMetrics = {
    solvable: true,
    arrowCount: arrows.length,
    totalCells,
    avgPathLength,
    totalTurns,
    avgTurnsPerArrow,
    blockedInitially,
    blockedRatio: blockedInitially / arrows.length,
    dependencyEdges,
    waveDepth,
    complexityScore,
    solution,
  };

  return { valid: true, metrics };
}

/**
 * Finds the best next arrow for the hint system from currently active arrows.
 * Chooses the free arrow whose removal unlocks the most blocked arrows immediately.
 */
export function getHintArrowId(activeArrows: ArrowConfig[]): string | null {
  if (activeArrows.length === 0) return null;

  const { dependencies, selfBlockedIds } = buildDependencyGraph(activeArrows);
  const activeIds = new Set(activeArrows.map((a) => a.id));

  // Reverse adjacency: who is waiting on `id`?
  const dependents = new Map<string, string[]>();
  const blockingCount = new Map<string, number>();

  for (const a of activeArrows) {
    const deps = dependencies.get(a.id)!;
    let activeDeps = 0;
    for (const depId of deps) {
      if (activeIds.has(depId)) {
        activeDeps++;
        let list = dependents.get(depId);
        if (!list) {
          list = [];
          dependents.set(depId, list);
        }
        list.push(a.id);
      }
    }
    blockingCount.set(a.id, selfBlockedIds.has(a.id) ? activeDeps + 1 : activeDeps);
  }

  const freeIds = activeArrows
    .map((a) => a.id)
    .filter((id) => (blockingCount.get(id) ?? 0) === 0);

  if (freeIds.length === 0) return null;

  let bestId = freeIds[0];
  let maxUnlocks = -1;

  for (const candidateId of freeIds) {
    const waiting = dependents.get(candidateId) || [];
    let unlocks = 0;
    for (const w of waiting) {
      if (blockingCount.get(w) === 1) {
        unlocks++;
      }
    }
    // Prefer arrows that directly unblock others, breaking ties by total dependents
    const score = unlocks * 10 + waiting.length;
    if (score > maxUnlocks) {
      maxUnlocks = score;
      bestId = candidateId;
    }
  }

  return bestId;
}
