import Phaser from "phaser";
import {
  BOARD_W,
  BOARD_X,
  BOARD_Y,
  CELL,
  COLORS,
  FONT,
  GAME_H,
  GAME_W,
  GRID,
  IS_LOW_END,
  LIFT,
  TRAY_SCALE,
  TRAY_SLOTS_X,
  TRAY_Y,
  u,
  UI,
} from "./constants";
import { randomShapeIndex, SHAPES } from "./shapes";
import { SoundFX, vibrate } from "./audio";
import {
  clearSavedGame,
  getBestScore,
  getSoundEnabled,
  loadGame,
  saveGame,
  setBestScore,
  setSoundEnabled,
} from "./storage";

interface TrayPiece {
  container: Phaser.GameObjects.Container;
  shapeIdx: number;
  color: number;
  slot: number;
  used: boolean;
  canFit: boolean;
  w: number; // ширина в пикселях при scale = 1
  h: number;
}

const EMPTY = -1;

export class GameScene extends Phaser.Scene {
  private board: number[][] = [];
  private cellSprites: Array<Array<Phaser.GameObjects.Image | null>> = [];
  private pieces: Array<TrayPiece | null> = [null, null, null];

  private score = 0;
  private best = 0;
  private combo = 0;
  private newRecord = false;
  private isOver = false;

  private scoreText!: Phaser.GameObjects.Text;
  private bestText!: Phaser.GameObjects.Text;
  private comboText!: Phaser.GameObjects.Text;
  private scoreCounter = { v: 0 };

  private ghostPool: Phaser.GameObjects.Image[] = [];
  private lineGlowPool: Phaser.GameObjects.Rectangle[] = [];

  private sparks!: Phaser.GameObjects.Particles.ParticleEmitter;
  private confetti!: Phaser.GameObjects.Particles.ParticleEmitter;

  private sfx = new SoundFX();
  private soundBtn!: Phaser.GameObjects.Text;

  constructor() {
    super("game");
  }

  init(): void {
    this.board = Array.from({ length: GRID }, () =>
      Array.from({ length: GRID }, () => EMPTY)
    );
    this.cellSprites = Array.from({ length: GRID }, () =>
      Array.from({ length: GRID }, () => null)
    );
    this.pieces = [null, null, null];
    this.score = 0;
    this.combo = 0;
    this.newRecord = false;
    this.isOver = false;
    this.scoreCounter = { v: 0 };
    this.ghostPool = [];
    this.lineGlowPool = [];
    this.best = getBestScore();
    this.sfx.enabled = getSoundEnabled();
  }

  create(): void {
    this.makeTextures();
    this.buildBackground();
    this.buildHeader();
    this.buildBoard();
    this.buildTraySlots();
    this.buildPools();
    this.buildParticles();
    this.setupInput();

    const saved = loadGame(SHAPES.length);
    if (saved) {
      this.restoreGame(saved);
    } else {
      this.spawnPieces(true);
    }
    this.refreshScoreUI(true);

    // разблокировка звука по первому касанию
    this.input.once("pointerdown", () => this.sfx.unlock());

    // убрать boot-лоадер из index.html — игра готова
    document.getElementById("boot-loader")?.remove();
  }

  // ────────────────────────────── ТЕКСТУРЫ ──────────────────────────────

  private makeTextures(): void {
    COLORS.forEach((color, i) => this.makeBlockTexture(`block${i}`, color));
    this.makeEmptyCellTexture();
    this.makeSparkTexture();
    this.makeRoundRect("panelBoard", BOARD_W + u(24), BOARD_W + u(24), u(20), UI.boardPanel);
    this.makeRoundRect("panelSlot", u(158), u(132), u(18), UI.slot);
    this.makeRoundRect("btnBig", u(300), u(84), u(42), 0xffb13d);
    this.makeRoundRect("panelOver", u(430), u(430), u(28), 0x1b2850);
    this.makeRoundRect("pillBest", u(170), u(52), u(26), 0x0e1736);
  }

  private makeRoundRect(
    key: string,
    w: number,
    h: number,
    r: number,
    color: number
  ): void {
    if (this.textures.exists(key)) return;
    const g = this.make.graphics({ x: 0, y: 0 }, false);
    g.fillStyle(color, 1);
    g.fillRoundedRect(0, 0, w, h, r);
    g.generateTexture(key, w, h);
    g.destroy();
  }

  private roundRectPath(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    r: number
  ): void {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  private shade(color: number, amount: number): string {
    // amount > 0 — светлее, < 0 — темнее
    const c = Phaser.Display.Color.ValueToColor(color);
    const t = amount > 0 ? 255 : 0;
    const k = Math.abs(amount);
    const r = Math.round(c.red + (t - c.red) * k);
    const g = Math.round(c.green + (t - c.green) * k);
    const b = Math.round(c.blue + (t - c.blue) * k);
    return `rgb(${r},${g},${b})`;
  }

  /** «Глянцевый» блок с градиентом, бликом и фаской */
  private makeBlockTexture(key: string, color: number): void {
    if (this.textures.exists(key)) return;
    const tex = this.textures.createCanvas(key, CELL, CELL);
    if (!tex) return;
    const ctx = tex.getContext();
    const pad = Math.max(1, Math.round(CELL * 0.045));
    const size = CELL - pad * 2;
    const r = Math.round(CELL * 0.18);

    // тень вниз
    this.roundRectPath(ctx, pad, pad + Math.round(CELL * 0.04), size, size, r);
    ctx.fillStyle = "rgba(0,0,0,0.35)";
    ctx.fill();

    // корпус с вертикальным градиентом
    const grad = ctx.createLinearGradient(0, pad, 0, pad + size);
    grad.addColorStop(0, this.shade(color, 0.38));
    grad.addColorStop(0.45, this.shade(color, 0.05));
    grad.addColorStop(1, this.shade(color, -0.22));
    this.roundRectPath(ctx, pad, pad, size, size, r);
    ctx.fillStyle = grad;
    ctx.fill();

    // верхний стеклянный блик
    const hi = ctx.createLinearGradient(0, pad, 0, pad + size * 0.5);
    hi.addColorStop(0, "rgba(255,255,255,0.5)");
    hi.addColorStop(1, "rgba(255,255,255,0)");
    this.roundRectPath(
      ctx,
      pad + size * 0.1,
      pad + size * 0.07,
      size * 0.8,
      size * 0.42,
      r * 0.7
    );
    ctx.fillStyle = hi;
    ctx.fill();

    // тонкая тёмная окантовка
    this.roundRectPath(ctx, pad + 0.5, pad + 0.5, size - 1, size - 1, r);
    ctx.strokeStyle = this.shade(color, -0.35);
    ctx.lineWidth = Math.max(1, CELL * 0.03);
    ctx.stroke();

    tex.refresh();
  }

  private makeEmptyCellTexture(): void {
    const key = "cellEmpty";
    if (this.textures.exists(key)) return;
    const tex = this.textures.createCanvas(key, CELL, CELL);
    if (!tex) return;
    const ctx = tex.getContext();
    const pad = Math.max(1, Math.round(CELL * 0.05));
    const size = CELL - pad * 2;
    const r = Math.round(CELL * 0.16);
    this.roundRectPath(ctx, pad, pad, size, size, r);
    ctx.fillStyle = "rgba(9,15,38,0.92)";
    ctx.fill();
    this.roundRectPath(ctx, pad + 0.5, pad + 0.5, size - 1, size - 1, r);
    ctx.strokeStyle = "rgba(70,95,180,0.22)";
    ctx.lineWidth = Math.max(1, CELL * 0.025);
    ctx.stroke();
    tex.refresh();
  }

  private makeSparkTexture(): void {
    const key = "spark";
    if (this.textures.exists(key)) return;
    const s = u(12);
    const g = this.make.graphics({ x: 0, y: 0 }, false);
    g.fillStyle(0xffffff, 1);
    g.fillRoundedRect(0, 0, s, s, Math.round(s * 0.3));
    g.generateTexture(key, s, s);
    g.destroy();
  }

  // ─────────────────────────────── ФОН / UI ──────────────────────────────

  private buildBackground(): void {
    const key = "bgGrad";
    if (!this.textures.exists(key)) {
      const tex = this.textures.createCanvas(key, GAME_W, GAME_H);
      if (tex) {
        const ctx = tex.getContext();
        const rad = ctx.createRadialGradient(
          GAME_W / 2, 0, GAME_W * 0.1,
          GAME_W / 2, GAME_H * 0.35, GAME_H * 0.95
        );
        rad.addColorStop(0, "#223468");
        rad.addColorStop(0.45, "#16214a");
        rad.addColorStop(1, "#0c1226");
        ctx.fillStyle = rad;
        ctx.fillRect(0, 0, GAME_W, GAME_H);
        tex.refresh();
      }
    }
    this.add.image(GAME_W / 2, GAME_H / 2, key).setDepth(0);

    // лёгкие декоративные «светлячки» — только на мощных девайсах
    if (!IS_LOW_END) {
      for (let i = 0; i < 7; i++) {
        const dot = this.add
          .image(
            Phaser.Math.Between(u(30), GAME_W - u(30)),
            Phaser.Math.Between(u(40), GAME_H - u(40)),
            "spark"
          )
          .setDepth(0)
          .setAlpha(Phaser.Math.FloatBetween(0.04, 0.1))
          .setScale(Phaser.Math.FloatBetween(0.6, 1.6))
          .setTint(0x8fb4ff);
        this.tweens.add({
          targets: dot,
          y: dot.y - u(Phaser.Math.Between(30, 80)),
          alpha: 0.02,
          duration: Phaser.Math.Between(6000, 11000),
          repeat: -1,
          yoyo: true,
          ease: "Sine.inOut",
        });
      }
    }
  }

  private buildHeader(): void {
    // рекорд с короной
    this.add
      .image(u(100), u(46), "pillBest")
      .setDepth(10)
      .setAlpha(0.9);
    this.bestText = this.add
      .text(u(100), u(46), `👑 ${this.best}`, {
        fontFamily: FONT,
        fontSize: `${u(24)}px`,
        fontStyle: "bold",
        color: UI.gold,
      })
      .setOrigin(0.5)
      .setDepth(11);

    // кнопка звука
    this.soundBtn = this.add
      .text(GAME_W - u(52), u(46), this.sfx.enabled ? "🔊" : "🔇", {
        fontSize: `${u(30)}px`,
      })
      .setOrigin(0.5)
      .setDepth(11)
      .setInteractive({ useHandCursor: true });
    this.soundBtn.on("pointerdown", () => {
      this.sfx.enabled = !this.sfx.enabled;
      setSoundEnabled(this.sfx.enabled);
      this.soundBtn.setText(this.sfx.enabled ? "🔊" : "🔇");
      this.sfx.button();
      this.tweens.add({
        targets: this.soundBtn,
        scale: { from: 1.3, to: 1 },
        duration: 160,
        ease: "Back.out",
      });
    });

    // крупный счёт
    this.scoreText = this.add
      .text(GAME_W / 2, u(118), "0", {
        fontFamily: FONT,
        fontSize: `${u(68)}px`,
        fontStyle: "900",
        color: UI.textMain,
      })
      .setOrigin(0.5)
      .setDepth(11)
      .setShadow(0, u(4), "rgba(0,0,0,0.45)", u(8), false, true);

    // индикатор комбо
    this.comboText = this.add
      .text(GAME_W / 2, u(176), "", {
        fontFamily: FONT,
        fontSize: `${u(26)}px`,
        fontStyle: "bold",
        color: UI.gold,
      })
      .setOrigin(0.5)
      .setDepth(11)
      .setAlpha(0);
  }

  private buildBoard(): void {
    this.add
      .image(GAME_W / 2, BOARD_Y + BOARD_W / 2, "panelBoard")
      .setDepth(1);

    for (let r = 0; r < GRID; r++) {
      for (let c = 0; c < GRID; c++) {
        this.add
          .image(
            BOARD_X + c * CELL + CELL / 2,
            BOARD_Y + r * CELL + CELL / 2,
            "cellEmpty"
          )
          .setDepth(2);
      }
    }
  }

  private buildTraySlots(): void {
    for (const x of TRAY_SLOTS_X) {
      this.add.image(x, TRAY_Y, "panelSlot").setDepth(3).setAlpha(0.75);
    }
  }

  private buildPools(): void {
    for (let i = 0; i < 25; i++) {
      const img = this.add
        .image(0, 0, "block0")
        .setVisible(false)
        .setDepth(4)
        .setAlpha(0.4);
      this.ghostPool.push(img);
    }
    for (let i = 0; i < 16; i++) {
      const rect = this.add
        .rectangle(0, 0, 10, 10, 0xffffff, 0.22)
        .setVisible(false)
        .setDepth(3)
        .setBlendMode(Phaser.BlendModes.ADD);
      this.lineGlowPool.push(rect);
    }
  }

  private buildParticles(): void {
    this.sparks = this.add.particles(0, 0, "spark", {
      speed: { min: u(90), max: u(260) },
      angle: { min: 0, max: 360 },
      scale: { start: 0.9, end: 0 },
      lifespan: { min: 300, max: 550 },
      gravityY: u(500),
      rotate: { min: 0, max: 360 },
      emitting: false,
      blendMode: Phaser.BlendModes.ADD,
    });
    this.sparks.setDepth(8);

    this.confetti = this.add.particles(0, 0, "spark", {
      speed: { min: u(180), max: u(420) },
      angle: { min: 230, max: 310 },
      scale: { start: 1.1, end: 0.2 },
      lifespan: { min: 900, max: 1500 },
      gravityY: u(700),
      rotate: { min: 0, max: 360 },
      tint: COLORS,
      emitting: false,
    });
    this.confetti.setDepth(110);
  }

  // ─────────────────────────────── ФИГУРЫ ───────────────────────────────

  private createPiece(slot: number, shapeIdx: number, color: number): TrayPiece {
    const shape = SHAPES[shapeIdx];
    const w = shape.w * CELL;
    const h = shape.h * CELL;

    const container = this.add.container(0, 0);
    container.setDepth(12);
    for (const [r, c] of shape.cells) {
      const img = this.add.image(
        c * CELL + CELL / 2,
        r * CELL + CELL / 2,
        `block${color}`
      );
      container.add(img);
    }

    const piece: TrayPiece = {
      container,
      shapeIdx,
      color,
      slot,
      used: false,
      canFit: true,
      w,
      h,
    };
    container.setData("piece", piece);

    const pad = u(58);
    container.setInteractive(
      new Phaser.Geom.Rectangle(-pad, -pad, w + pad * 2, h + pad * 2),
      Phaser.Geom.Rectangle.Contains
    );
    this.input.setDraggable(container);

    const pos = this.trayPos(piece);
    container.setPosition(pos.x, pos.y);
    container.setScale(TRAY_SCALE);
    return piece;
  }

  private trayPos(piece: TrayPiece): { x: number; y: number } {
    return {
      x: TRAY_SLOTS_X[piece.slot] - (piece.w * TRAY_SCALE) / 2,
      y: TRAY_Y - (piece.h * TRAY_SCALE) / 2,
    };
  }

  private spawnPieces(animate: boolean): void {
    for (let slot = 0; slot < 3; slot++) {
      const shapeIdx = randomShapeIndex();
      const color = Phaser.Math.Between(0, COLORS.length - 1);
      const piece = this.createPiece(slot, shapeIdx, color);
      this.pieces[slot] = piece;
      if (animate) {
        piece.container.setScale(0.01);
        this.tweens.add({
          targets: piece.container,
          scale: TRAY_SCALE,
          duration: 260,
          delay: slot * 70,
          ease: "Back.out",
        });
      }
    }
    this.updateFits();
    this.persist();
    this.time.delayedCall(320, () => this.checkGameOver());
  }

  // ─────────────────────────────── ВВОД ─────────────────────────────────

  private setupInput(): void {
    this.input.on(
      "dragstart",
      (_p: Phaser.Input.Pointer, obj: Phaser.GameObjects.GameObject) => {
        const piece = obj.getData("piece") as TrayPiece | undefined;
        if (!piece || piece.used || this.isOver) return;
        this.sfx.pick();
        vibrate(8);
        piece.container.setDepth(50);
        this.tweens.add({
          targets: piece.container,
          scale: 1,
          duration: 120,
          ease: "Quad.out",
        });
      }
    );

    this.input.on(
      "drag",
      (p: Phaser.Input.Pointer, obj: Phaser.GameObjects.GameObject) => {
        const piece = obj.getData("piece") as TrayPiece | undefined;
        if (!piece || piece.used || this.isOver) return;
        piece.container.x = p.x - piece.w / 2;
        piece.container.y = p.y - piece.h - LIFT;
        this.updateGhost(piece);
      }
    );

    this.input.on(
      "dragend",
      (_p: Phaser.Input.Pointer, obj: Phaser.GameObjects.GameObject) => {
        const piece = obj.getData("piece") as TrayPiece | undefined;
        if (!piece || piece.used || this.isOver) return;
        this.hideGhost();
        const { row, col } = this.dropTarget(piece);
        if (this.canPlace(piece.shapeIdx, row, col)) {
          this.placePiece(piece, row, col);
        } else {
          if (this.isNearBoard(piece)) this.sfx.invalid();
          const pos = this.trayPos(piece);
          piece.container.setDepth(12);
          this.tweens.add({
            targets: piece.container,
            x: pos.x,
            y: pos.y,
            scale: TRAY_SCALE,
            duration: 200,
            ease: "Quad.out",
          });
        }
      }
    );
  }

  private dropTarget(piece: TrayPiece): { row: number; col: number } {
    return {
      col: Math.round((piece.container.x - BOARD_X) / CELL),
      row: Math.round((piece.container.y - BOARD_Y) / CELL),
    };
  }

  private isNearBoard(piece: TrayPiece): boolean {
    const cx = piece.container.x + piece.w / 2;
    const cy = piece.container.y + piece.h / 2;
    return (
      cx > BOARD_X - CELL &&
      cx < BOARD_X + BOARD_W + CELL &&
      cy > BOARD_Y - CELL &&
      cy < BOARD_Y + BOARD_W + CELL
    );
  }

  // ─────────────────────────── ЛОГИКА ПОЛЯ ──────────────────────────────

  private canPlace(shapeIdx: number, row: number, col: number): boolean {
    const shape = SHAPES[shapeIdx];
    for (const [r, c] of shape.cells) {
      const rr = row + r;
      const cc = col + c;
      if (rr < 0 || cc < 0 || rr >= GRID || cc >= GRID) return false;
      if (this.board[rr][cc] !== EMPTY) return false;
    }
    return true;
  }

  private anyPlacement(shapeIdx: number): boolean {
    const shape = SHAPES[shapeIdx];
    for (let r = 0; r <= GRID - shape.h; r++) {
      for (let c = 0; c <= GRID - shape.w; c++) {
        if (this.canPlace(shapeIdx, r, c)) return true;
      }
    }
    return false;
  }

  /** Полные линии с учётом гипотетической установки фигуры */
  private linesWith(
    shapeIdx: number,
    row: number,
    col: number
  ): { rows: number[]; cols: number[] } {
    const extra = new Set<number>();
    for (const [r, c] of SHAPES[shapeIdx].cells) {
      extra.add((row + r) * GRID + (col + c));
    }
    const rows: number[] = [];
    const cols: number[] = [];
    for (let r = 0; r < GRID; r++) {
      let full = true;
      for (let c = 0; c < GRID; c++) {
        if (this.board[r][c] === EMPTY && !extra.has(r * GRID + c)) {
          full = false;
          break;
        }
      }
      if (full) rows.push(r);
    }
    for (let c = 0; c < GRID; c++) {
      let full = true;
      for (let r = 0; r < GRID; r++) {
        if (this.board[r][c] === EMPTY && !extra.has(r * GRID + c)) {
          full = false;
          break;
        }
      }
      if (full) cols.push(c);
    }
    return { rows, cols };
  }

  // ─────────────────────────── ПРИЗРАК-ПОДСКАЗКА ────────────────────────

  private updateGhost(piece: TrayPiece): void {
    const { row, col } = this.dropTarget(piece);
    if (!this.canPlace(piece.shapeIdx, row, col)) {
      this.hideGhost();
      return;
    }
    const shape = SHAPES[piece.shapeIdx];
    shape.cells.forEach(([r, c], i) => {
      const img = this.ghostPool[i];
      img
        .setTexture(`block${piece.color}`)
        .setPosition(
          BOARD_X + (col + c) * CELL + CELL / 2,
          BOARD_Y + (row + r) * CELL + CELL / 2
        )
        .setAlpha(0.38)
        .setVisible(true);
    });
    for (let i = shape.cells.length; i < this.ghostPool.length; i++) {
      this.ghostPool[i].setVisible(false);
    }

    // подсветка линий, которые будут собраны
    const { rows, cols } = this.linesWith(piece.shapeIdx, row, col);
    const color = COLORS[piece.color];
    let gi = 0;
    for (const r of rows) {
      const rect = this.lineGlowPool[gi++];
      rect
        .setPosition(BOARD_X + BOARD_W / 2, BOARD_Y + r * CELL + CELL / 2)
        .setSize(BOARD_W, CELL)
        .setFillStyle(color, 0.28)
        .setVisible(true);
    }
    for (const c of cols) {
      const rect = this.lineGlowPool[gi++];
      rect
        .setPosition(BOARD_X + c * CELL + CELL / 2, BOARD_Y + BOARD_W / 2)
        .setSize(CELL, BOARD_W)
        .setFillStyle(color, 0.28)
        .setVisible(true);
    }
    for (; gi < this.lineGlowPool.length; gi++) {
      this.lineGlowPool[gi].setVisible(false);
    }
  }

  private hideGhost(): void {
    for (const img of this.ghostPool) img.setVisible(false);
    for (const rect of this.lineGlowPool) rect.setVisible(false);
  }

  // ─────────────────────────── УСТАНОВКА ФИГУРЫ ─────────────────────────

  private placePiece(piece: TrayPiece, row: number, col: number): void {
    const shape = SHAPES[piece.shapeIdx];
    this.sfx.place();
    vibrate(12);

    for (const [r, c] of shape.cells) {
      const rr = row + r;
      const cc = col + c;
      this.board[rr][cc] = piece.color;
      const img = this.add
        .image(
          BOARD_X + cc * CELL + CELL / 2,
          BOARD_Y + rr * CELL + CELL / 2,
          `block${piece.color}`
        )
        .setDepth(5)
        .setScale(1.18);
      this.tweens.add({
        targets: img,
        scale: 1,
        duration: 140,
        ease: "Back.out",
      });
      this.cellSprites[rr][cc] = img;
    }

    piece.used = true;
    piece.container.destroy();

    let gained = shape.cells.length;
    const { rows, cols } = this.linesWith(piece.shapeIdx, row, col);
    // центр установленной фигуры — эпицентр анимации очистки
    const originR = row + shape.h / 2;
    const originC = col + shape.w / 2;

    const lines = rows.length + cols.length;
    if (lines > 0) {
      this.combo += 1;
      const base = 10 * ((lines * (lines + 1)) / 2);
      const mult = Math.min(this.combo, 8);
      const linePts = base * mult;
      gained += linePts;

      this.clearLines(rows, cols, originR, originC);
      this.sfx.clear(lines);
      vibrate(lines > 1 ? [20, 30, 25] : 20);

      this.showFloatText(
        BOARD_X + originC * CELL,
        BOARD_Y + Phaser.Math.Clamp(originR, 1, 7) * CELL,
        `+${linePts}`,
        COLORS[piece.color]
      );
      if (this.combo >= 2) {
        this.sfx.combo(this.combo);
        this.showComboBanner(this.combo);
      }

      // полностью чистое поле — бонус
      if (this.boardEmpty()) {
        gained += 300;
        this.sfx.allClear();
        this.showFloatText(
          BOARD_X + BOARD_W / 2 - u(60),
          BOARD_Y + BOARD_W / 2,
          "ЧИСТО! +300",
          0xffd93d,
          true
        );
        this.confetti.explode(IS_LOW_END ? 25 : 60, GAME_W / 2, BOARD_Y);
      }
    } else {
      this.combo = 0;
      this.refreshComboUI();
    }

    this.addScore(gained);
    this.persist();

    if (this.pieces.every((p) => !p || p.used)) {
      this.time.delayedCall(lines > 0 ? 320 : 120, () => {
        if (!this.isOver) this.spawnPieces(true);
      });
    } else {
      this.updateFits();
      this.persist();
      this.time.delayedCall(lines > 0 ? 420 : 60, () => this.checkGameOver());
    }
  }

  private boardEmpty(): boolean {
    for (let r = 0; r < GRID; r++) {
      for (let c = 0; c < GRID; c++) {
        if (this.board[r][c] !== EMPTY) return false;
      }
    }
    return true;
  }

  private clearLines(
    rows: number[],
    cols: number[],
    originR: number,
    originC: number
  ): void {
    const cells = new Set<number>();
    for (const r of rows) for (let c = 0; c < GRID; c++) cells.add(r * GRID + c);
    for (const c of cols) for (let r = 0; r < GRID; r++) cells.add(r * GRID + c);

    const perCell = IS_LOW_END ? 2 : 4;

    cells.forEach((idx) => {
      const r = Math.floor(idx / GRID);
      const c = idx % GRID;
      const colorIdx = this.board[r][c];
      this.board[r][c] = EMPTY;
      const sprite = this.cellSprites[r][c];
      this.cellSprites[r][c] = null;
      if (!sprite) return;

      const dist = Math.abs(r - originR) + Math.abs(c - originC);
      const delay = dist * 26;
      this.tweens.add({
        targets: sprite,
        scale: 0,
        alpha: 0,
        angle: Phaser.Math.Between(-40, 40),
        duration: 190,
        delay,
        ease: "Quad.in",
        onStart: () => {
          if (colorIdx >= 0) {
            this.sparks.setParticleTint(COLORS[colorIdx]);
            this.sparks.explode(perCell, sprite.x, sprite.y);
          }
        },
        onComplete: () => sprite.destroy(),
      });
    });

    // белая вспышка по линиям
    for (const r of rows) this.flashLine(true, r);
    for (const c of cols) this.flashLine(false, c);
  }

  private flashLine(isRow: boolean, index: number): void {
    const rect = this.add
      .rectangle(
        isRow ? BOARD_X + BOARD_W / 2 : BOARD_X + index * CELL + CELL / 2,
        isRow ? BOARD_Y + index * CELL + CELL / 2 : BOARD_Y + BOARD_W / 2,
        isRow ? BOARD_W : CELL,
        isRow ? CELL : BOARD_W,
        0xffffff,
        0.55
      )
      .setDepth(7)
      .setBlendMode(Phaser.BlendModes.ADD);
    this.tweens.add({
      targets: rect,
      alpha: 0,
      scaleX: isRow ? 1.04 : 1.5,
      scaleY: isRow ? 1.5 : 1.04,
      duration: 260,
      ease: "Quad.out",
      onComplete: () => rect.destroy(),
    });
  }

  // ─────────────────────────────── ОЧКИ / UI ────────────────────────────

  private addScore(points: number): void {
    this.score += points;
    if (this.score > this.best) {
      this.best = this.score;
      this.newRecord = true;
      setBestScore(this.best);
    }
    this.refreshScoreUI(false);
  }

  private refreshScoreUI(instant: boolean): void {
    this.bestText.setText(`👑 ${this.best}`);
    if (instant) {
      this.scoreCounter.v = this.score;
      this.scoreText.setText(String(this.score));
      this.refreshComboUI();
      return;
    }
    this.tweens.add({
      targets: this.scoreCounter,
      v: this.score,
      duration: 350,
      ease: "Quad.out",
      onUpdate: () => this.scoreText.setText(String(Math.round(this.scoreCounter.v))),
    });
    this.tweens.add({
      targets: this.scoreText,
      scale: { from: 1.18, to: 1 },
      duration: 240,
      ease: "Back.out",
    });
    this.refreshComboUI();
  }

  private refreshComboUI(): void {
    if (this.combo >= 2) {
      this.comboText.setText(`🔥 Комбо ×${this.combo}`);
      this.comboText.setAlpha(1);
    } else {
      this.tweens.add({ targets: this.comboText, alpha: 0, duration: 250 });
    }
  }

  private showFloatText(
    x: number,
    y: number,
    text: string,
    color: number,
    big = false
  ): void {
    const t = this.add
      .text(x, y, text, {
        fontFamily: FONT,
        fontSize: `${u(big ? 44 : 36)}px`,
        fontStyle: "900",
        color: "#ffffff",
      })
      .setOrigin(0.5)
      .setDepth(60)
      .setTint(0xffffff, 0xffffff, color, color)
      .setShadow(0, u(3), "rgba(0,0,0,0.5)", u(6), false, true)
      .setScale(0.4);
    this.tweens.add({
      targets: t,
      scale: 1,
      y: y - u(70),
      duration: 520,
      ease: "Back.out",
      onComplete: () => {
        this.tweens.add({
          targets: t,
          alpha: 0,
          y: t.y - u(30),
          duration: 320,
          onComplete: () => t.destroy(),
        });
      },
    });
  }

  private showComboBanner(combo: number): void {
    const phrases = ["Отлично!", "Супер!", "Класс!", "Невероятно!", "Легенда!"];
    const phrase = phrases[Math.min(combo - 2, phrases.length - 1)];
    const banner = this.add
      .text(GAME_W / 2, BOARD_Y + BOARD_W * 0.35, phrase, {
        fontFamily: FONT,
        fontSize: `${u(52)}px`,
        fontStyle: "900",
        color: UI.gold,
      })
      .setOrigin(0.5)
      .setDepth(61)
      .setShadow(0, u(4), "rgba(0,0,0,0.55)", u(10), false, true)
      .setScale(0.2)
      .setAlpha(0);
    this.tweens.add({
      targets: banner,
      scale: 1,
      alpha: 1,
      duration: 260,
      ease: "Back.out",
      onComplete: () => {
        this.tweens.add({
          targets: banner,
          alpha: 0,
          scale: 1.25,
          delay: 420,
          duration: 280,
          onComplete: () => banner.destroy(),
        });
      },
    });
  }

  // ─────────────────────── ПРОВЕРКИ / КОНЕЦ ИГРЫ ────────────────────────

  private updateFits(): void {
    for (const piece of this.pieces) {
      if (!piece || piece.used) continue;
      piece.canFit = this.anyPlacement(piece.shapeIdx);
      piece.container.setAlpha(piece.canFit ? 1 : 0.35);
    }
  }

  private checkGameOver(): void {
    if (this.isOver) return;
    const active = this.pieces.filter((p) => p && !p.used) as TrayPiece[];
    if (active.length === 0) return;
    if (active.some((p) => p.canFit)) return;
    this.gameOver();
  }

  private gameOver(): void {
    this.isOver = true;
    clearSavedGame();
    this.sfx.gameOver();
    vibrate([60, 50, 80]);

    // последовательное «гашение» блоков
    let i = 0;
    for (let r = 0; r < GRID; r++) {
      for (let c = 0; c < GRID; c++) {
        const sprite = this.cellSprites[r][c];
        if (!sprite) continue;
        this.time.delayedCall(i * 14, () => {
          if (sprite.active) sprite.setTint(0x5a648c).setAlpha(0.55);
        });
        i++;
      }
    }

    const delay = Math.min(i * 14 + 300, 1100);
    this.time.delayedCall(delay, () => this.showGameOverPanel());
  }

  private showGameOverPanel(): void {
    const overlay = this.add
      .rectangle(GAME_W / 2, GAME_H / 2, GAME_W, GAME_H, 0x060a18, 0)
      .setDepth(100)
      .setInteractive();
    this.tweens.add({ targets: overlay, fillAlpha: 0.78, duration: 350 });

    const panel = this.add.container(GAME_W / 2, GAME_H / 2 - u(500));
    panel.setDepth(105);

    const bg = this.add.image(0, 0, "panelOver");
    const title = this.add
      .text(0, -u(150), "ИГРА ОКОНЧЕНА", {
        fontFamily: FONT,
        fontSize: `${u(40)}px`,
        fontStyle: "900",
        color: "#ffffff",
      })
      .setOrigin(0.5)
      .setShadow(0, u(3), "rgba(0,0,0,0.4)", u(6), false, true);

    const scoreLabel = this.add
      .text(0, -u(78), "ОЧКИ", {
        fontFamily: FONT,
        fontSize: `${u(20)}px`,
        fontStyle: "bold",
        color: UI.textSoft,
      })
      .setOrigin(0.5);
    const scoreVal = this.add
      .text(0, -u(34), String(this.score), {
        fontFamily: FONT,
        fontSize: `${u(58)}px`,
        fontStyle: "900",
        color: "#ffffff",
      })
      .setOrigin(0.5);

    const recText = this.newRecord
      ? `🎉 Новый рекорд!`
      : `👑 Рекорд: ${this.best}`;
    const record = this.add
      .text(0, u(34), recText, {
        fontFamily: FONT,
        fontSize: `${u(26)}px`,
        fontStyle: "bold",
        color: UI.gold,
      })
      .setOrigin(0.5);

    const btn = this.add.image(0, u(126), "btnBig");
    const btnText = this.add
      .text(0, u(126), "ИГРАТЬ СНОВА", {
        fontFamily: FONT,
        fontSize: `${u(28)}px`,
        fontStyle: "900",
        color: "#3a2300",
      })
      .setOrigin(0.5);

    panel.add([bg, title, scoreLabel, scoreVal, record, btn, btnText]);

    this.tweens.add({
      targets: panel,
      y: GAME_H / 2 - u(30),
      duration: 450,
      ease: "Back.out",
    });

    if (this.newRecord) {
      this.time.delayedCall(500, () => {
        this.confetti.explode(IS_LOW_END ? 35 : 80, GAME_W / 2, GAME_H / 2 - u(200));
      });
      this.tweens.add({
        targets: record,
        scale: { from: 1, to: 1.12 },
        duration: 500,
        yoyo: true,
        repeat: -1,
        ease: "Sine.inOut",
      });
    }

    btn.setInteractive({ useHandCursor: true });
    btn.on("pointerdown", () => {
      this.sfx.button();
      this.tweens.add({
        targets: [btn, btnText],
        scale: 0.93,
        duration: 80,
        yoyo: true,
        onComplete: () => this.scene.restart(),
      });
    });
  }

  // ─────────────────────── СОХРАНЕНИЕ / ВОССТАНОВЛЕНИЕ ──────────────────

  private persist(): void {
    if (this.isOver) return;
    const flat: number[] = [];
    for (let r = 0; r < GRID; r++) {
      for (let c = 0; c < GRID; c++) flat.push(this.board[r][c]);
    }
    saveGame({
      board: flat,
      score: this.score,
      combo: this.combo,
      pieces: this.pieces.map((p) =>
        p
          ? { shapeIdx: p.shapeIdx, color: p.color, used: p.used }
          : { shapeIdx: 0, color: 0, used: true }
      ),
    });
  }

  private restoreGame(saved: ReturnType<typeof loadGame> & object): void {
    const data = saved as NonNullable<ReturnType<typeof loadGame>>;
    this.score = data.score;
    this.combo = data.combo;
    for (let r = 0; r < GRID; r++) {
      for (let c = 0; c < GRID; c++) {
        const v = data.board[r * GRID + c];
        if (v >= 0 && v < COLORS.length) {
          this.board[r][c] = v;
          this.cellSprites[r][c] = this.add
            .image(
              BOARD_X + c * CELL + CELL / 2,
              BOARD_Y + r * CELL + CELL / 2,
              `block${v}`
            )
            .setDepth(5);
        }
      }
    }
    data.pieces.forEach((p, slot) => {
      if (p.used) {
        this.pieces[slot] = null;
        return;
      }
      const piece = this.createPiece(slot, p.shapeIdx, p.color % COLORS.length);
      this.pieces[slot] = piece;
    });
    // если все слоты пустые (странное сохранение) — новые фигуры
    if (this.pieces.every((p) => !p)) {
      this.spawnPieces(true);
    } else {
      this.updateFits();
      this.time.delayedCall(200, () => this.checkGameOver());
    }
  }
}
