import { storage, type QualityPref } from './storage';

export type Tier = 'low' | 'mid' | 'high';

export interface Quality {
  tier: Tier;
  /** Maximum device pixel ratio used for the canvas. */
  dprCap: number;
  /** Particles per cleared block (0 disables particles). */
  particlesPerBlock: number;
  /** Soft drop shadow under the dragged piece. */
  dragShadow: boolean;
  /** Additive line flashes & glows. */
  flashes: boolean;
  /** Text shadows with blur (expensive on canvas). */
  textShadowBlur: boolean;
  /** Animated decorative blocks in the menu. */
  menuAnimation: boolean;
  /** Camera shake on big clears. */
  shake: boolean;
}

export function qualityFor(tier: Tier): Quality {
  switch (tier) {
    case 'low':
      return {
        tier,
        dprCap: 1,
        particlesPerBlock: 2,
        dragShadow: false,
        flashes: false,
        textShadowBlur: false,
        menuAnimation: false,
        shake: false,
      };
    case 'mid':
      return {
        tier,
        dprCap: 1.5,
        particlesPerBlock: 4,
        dragShadow: true,
        flashes: true,
        textShadowBlur: false,
        menuAnimation: true,
        shake: true,
      };
    default:
      return {
        tier,
        dprCap: 2,
        particlesPerBlock: 7,
        dragShadow: true,
        flashes: true,
        textShadowBlur: true,
        menuAnimation: true,
        shake: true,
      };
  }
}

function webglRendererInfo(): string {
  try {
    const canvas = document.createElement('canvas');
    const gl =
      (canvas.getContext('webgl2') as WebGLRenderingContext | null) ||
      (canvas.getContext('webgl') as WebGLRenderingContext | null);
    if (!gl) return 'none';
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const name = ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : '';
    const lose = gl.getExtension('WEBGL_lose_context');
    lose?.loseContext();
    return name.toLowerCase();
  } catch {
    return '';
  }
}

/** Heuristic hardware tier detection (runs once before the game is created). */
export function detectTier(): Tier {
  const nav = navigator as Navigator & { deviceMemory?: number };
  const mem = nav.deviceMemory ?? 4;
  const cores = navigator.hardwareConcurrency ?? 4;
  const dpr = window.devicePixelRatio || 1;
  const px = window.screen.width * window.screen.height * dpr * dpr;
  const gpu = webglRendererInfo();

  let score = 0;
  if (gpu === 'none') return 'low';
  if (mem <= 2) score -= 2;
  else if (mem <= 3) score -= 1;
  else if (mem >= 6) score += 1;
  if (cores <= 4) score -= 1;
  else if (cores >= 8) score += 1;
  if (px > 1440 * 3200) score -= 1;
  if (/mali-4|mali-t[67]|adreno \(tm\) [1-4]\d\d|adreno \(tm\) 50[0-6]|powervr|swiftshader|llvmpipe/.test(gpu)) {
    score -= 2;
  } else if (/adreno \(tm\) [67]\d\d|mali-g7|mali-g6[0-9]|apple|nvidia|radeon|intel\(r\) (iris|arc)/.test(gpu)) {
    score += 1;
  }
  if (score <= -2) return 'low';
  if (score >= 1) return 'high';
  return 'mid';
}

/** Resolves the effective tier using user preference and previously measured results. */
export function resolveTier(pref: QualityPref): Tier {
  if (pref === 'low') return 'low';
  if (pref === 'high') return 'high';
  const remembered = storage.getAutoTier();
  if (remembered === 'low' || remembered === 'mid' || remembered === 'high') return remembered;
  return detectTier();
}

/**
 * Samples the real frame rate during play and triggers a downgrade when the
 * device clearly cannot keep up. Only used in 'auto' quality mode.
 */
export class FpsMonitor {
  private elapsed = 0;
  private samples: number[] = [];
  private cooldown = 0;
  private downgrades = 0;

  constructor(private readonly onDowngrade: (level: number) => void) {}

  update(delta: number, fps: number): void {
    if (this.downgrades >= 2) return;
    this.elapsed += delta;
    if (this.elapsed < 2500) return; // let things warm up
    if (this.cooldown > 0) {
      this.cooldown -= delta;
      return;
    }
    if (delta > 0) this.samples.push(fps);
    if (this.samples.length >= 180) {
      const avg = this.samples.reduce((a, b) => a + b, 0) / this.samples.length;
      this.samples = [];
      if (avg < 42) {
        this.downgrades++;
        this.cooldown = 5000;
        this.onDowngrade(this.downgrades);
      }
    }
  }
}
