/**
 * Procedural Web Audio API sound synthesizer for Subway Mom Runner 3D.
 * Generates energetic retro-modern music, sound effects, and comedic cues.
 */

class SoundSystem {
  private ctx: AudioContext | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private masterGain: GainNode | null = null;
  private isMusicPlaying = false;
  private musicTimer: number | null = null;
  private musicStep = 0;
  private tempo = 128; // BPM
  private musicVol = 0.4;
  private sfxVol = 0.6;
  private muted = false;

  constructor() {
    // AudioContext will be initialized on first user interaction
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.muted ? 0 : 1;
      this.masterGain.connect(this.ctx.destination);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = this.musicVol;
      this.musicGain.connect(this.masterGain);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = this.sfxVol;
      this.sfxGain.connect(this.masterGain);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setVolumes(music: number, sfx: number) {
    this.musicVol = Math.max(0, Math.min(1, music));
    this.sfxVol = Math.max(0, Math.min(1, sfx));
    if (this.musicGain) this.musicGain.gain.value = this.musicVol;
    if (this.sfxGain) this.sfxGain.gain.value = this.sfxVol;
  }

  public toggleMute(): boolean {
    this.muted = !this.muted;
    if (this.masterGain) {
      this.masterGain.gain.value = this.muted ? 0 : 1;
    }
    return this.muted;
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public triggerHaptic(duration = 40) {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(duration);
      } catch {
        // Ignore if disabled or restricted by user agent
      }
    }
  }

  // --- Sound Effects ---

  public playJump() {
    this.initCtx();
    if (!this.ctx || !this.sfxGain || this.muted) return;
    this.triggerHaptic(25);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(580, now + 0.16);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.2);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.2);
  }

  public playSlide() {
    this.initCtx();
    if (!this.ctx || !this.sfxGain || this.muted) return;
    this.triggerHaptic(20);

    const now = this.ctx.currentTime;
    // White noise swoosh for slide
    const bufferSize = this.ctx.sampleRate * 0.22;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(900, now);
    filter.frequency.exponentialRampToValueAtTime(280, now + 0.22);
    filter.Q.value = 3.0;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.22);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    noise.start(now);
    noise.stop(now + 0.22);
  }

  public playLaneSwitch() {
    this.initCtx();
    if (!this.ctx || !this.sfxGain || this.muted) return;
    this.triggerHaptic(15);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(450, now + 0.08);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.09);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.09);
  }

  public playCoin() {
    this.initCtx();
    if (!this.ctx || !this.sfxGain || this.muted) return;
    this.triggerHaptic(10);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    // High joyful bell chord
    const freqs = [987.77, 1318.51, 1567.98]; // B5, E6, G6
    const note = freqs[Math.floor(Math.random() * freqs.length)];

    osc.type = 'sine';
    osc.frequency.setValueAtTime(note, now);
    osc.frequency.setValueAtTime(note * 1.5, now + 0.04);

    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.18);
  }

  public playPowerup() {
    this.initCtx();
    if (!this.ctx || !this.sfxGain || this.muted) return;
    this.triggerHaptic(60);

    const now = this.ctx.currentTime;
    // Upward arpeggio
    const notes = [392, 523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.05);

      gain.gain.setValueAtTime(0.25, now + idx * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.01, now + idx * 0.05 + 0.15);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now + idx * 0.05);
      osc.stop(now + idx * 0.05 + 0.16);
    });
  }

  public playHoverboard() {
    this.initCtx();
    if (!this.ctx || !this.sfxGain || this.muted) return;
    this.triggerHaptic(80);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(420, now + 0.25);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.linearRampToValueAtTime(0.05, now + 0.35);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.35);
  }

  public playCrash() {
    this.initCtx();
    if (!this.ctx || !this.sfxGain || this.muted) return;
    this.triggerHaptic(120);

    const now = this.ctx.currentTime;
    // Low punch
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(120, now);
    osc.frequency.exponentialRampToValueAtTime(30, now + 0.4);

    gain.gain.setValueAtTime(0.6, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.4);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.4);

    // Mom's funny exclamation boing / warning whistle
    this.playMomCall();
  }

  public playMomCall() {
    if (!this.ctx || !this.sfxGain || this.muted) return;
    const now = this.ctx.currentTime + 0.15;

    // Fast comedic double whistle slide (representing Mom's alarm or "تعال هنا!")
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'square';
    osc.frequency.setValueAtTime(800, now);
    osc.frequency.linearRampToValueAtTime(1200, now + 0.08);
    osc.frequency.linearRampToValueAtTime(700, now + 0.16);
    osc.frequency.linearRampToValueAtTime(1400, now + 0.25);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.3);
  }

  public playVictory() {
    this.initCtx();
    if (!this.ctx || !this.sfxGain || this.muted) return;
    this.triggerHaptic(100);

    const now = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.51];
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.12);

      gain.gain.setValueAtTime(0.3, now + idx * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.01, now + idx * 0.12 + 0.4);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now + idx * 0.12);
      osc.stop(now + idx * 0.12 + 0.45);
    });
  }

  // --- Background Music: Fast-paced Middle Eastern & Street Synth Groove ---

  public startMusic(speedMultiplier = 1.0) {
    this.initCtx();
    if (this.isMusicPlaying) {
      this.tempo = Math.min(165, Math.floor(128 * speedMultiplier));
      return;
    }
    this.isMusicPlaying = true;
    this.tempo = Math.min(165, Math.floor(128 * speedMultiplier));
    this.musicStep = 0;
    this.scheduleNextBeat();
  }

  public updateSpeed(speedMultiplier: number) {
    this.tempo = Math.min(170, Math.floor(128 + (speedMultiplier - 1.0) * 45));
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicTimer !== null) {
      window.clearTimeout(this.musicTimer);
      this.musicTimer = null;
    }
  }

  private scheduleNextBeat() {
    if (!this.isMusicPlaying) return;

    this.playBeatStep(this.musicStep);
    this.musicStep = (this.musicStep + 1) % 16;

    const secondsPer16th = (60 / this.tempo) / 4;
    this.musicTimer = window.setTimeout(() => {
      this.scheduleNextBeat();
    }, secondsPer16th * 1000);
  }

  private playBeatStep(step: number) {
    if (!this.ctx || !this.musicGain || this.muted) return;
    const now = this.ctx.currentTime;

    // 1. Bassline (hijaz / arabic maqam flavored minor pentatonic: D - Eb - F# - G - A - Bb - C)
    const bassNotes = [73.42, 73.42, 77.78, 73.42, 92.50, 92.50, 98.0, 87.31]; // D2, Eb2, F#2, G2, F2
    if (step % 2 === 0) {
      const noteIdx = Math.floor(step / 2) % bassNotes.length;
      const bassFreq = bassNotes[noteIdx];

      const bassOsc = this.ctx.createOscillator();
      const bassGain = this.ctx.createGain();
      bassOsc.type = 'sawtooth';
      bassOsc.frequency.setValueAtTime(bassFreq, now);

      bassGain.gain.setValueAtTime(0.22, now);
      bassGain.gain.exponentialRampToValueAtTime(0.01, now + 0.14);

      bassOsc.connect(bassGain);
      bassGain.connect(this.musicGain);

      bassOsc.start(now);
      bassOsc.stop(now + 0.15);
    }

    // 2. Drums (Kick on 0, 4, 8, 12, Snare on 4, 12, Hi-hat on every step)
    if (step % 4 === 0) {
      // Kick drum
      const kickOsc = this.ctx.createOscillator();
      const kickGain = this.ctx.createGain();
      kickOsc.type = 'sine';
      kickOsc.frequency.setValueAtTime(150, now);
      kickOsc.frequency.exponentialRampToValueAtTime(45, now + 0.08);

      kickGain.gain.setValueAtTime(0.35, now);
      kickGain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);

      kickOsc.connect(kickGain);
      kickGain.connect(this.musicGain);

      kickOsc.start(now);
      kickOsc.stop(now + 0.11);
    }

    if (step === 4 || step === 12) {
      // Snare / Darbuka slap
      const snareOsc = this.ctx.createOscillator();
      const snareGain = this.ctx.createGain();
      snareOsc.type = 'triangle';
      snareOsc.frequency.setValueAtTime(280, now);
      snareOsc.frequency.exponentialRampToValueAtTime(120, now + 0.07);

      snareGain.gain.setValueAtTime(0.25, now);
      snareGain.gain.exponentialRampToValueAtTime(0.01, now + 0.09);

      snareOsc.connect(snareGain);
      snareGain.connect(this.musicGain);

      snareOsc.start(now);
      snareOsc.stop(now + 0.1);
    }

    // Hi-hat tick
    if (step % 2 === 1) {
      const hatOsc = this.ctx.createOscillator();
      const hatGain = this.ctx.createGain();
      hatOsc.type = 'square';
      hatOsc.frequency.setValueAtTime(4000, now);

      hatGain.gain.setValueAtTime(0.04, now);
      hatGain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);

      hatOsc.connect(hatGain);
      hatGain.connect(this.musicGain);

      hatOsc.start(now);
      hatOsc.stop(now + 0.035);
    }

    // Lead Melodic Synth Hooks on specific steps
    const leadPattern: Record<number, number> = {
      0: 293.66, // D4
      3: 311.13, // Eb4
      6: 369.99, // F#4
      8: 392.00, // G4
      10: 440.00, // A4
      12: 392.00, // G4
      14: 369.99  // F#4
    };

    if (leadPattern[step]) {
      const leadOsc = this.ctx.createOscillator();
      const leadGain = this.ctx.createGain();
      leadOsc.type = 'sine';
      leadOsc.frequency.setValueAtTime(leadPattern[step], now);

      leadGain.gain.setValueAtTime(0.12, now);
      leadGain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);

      leadOsc.connect(leadGain);
      leadGain.connect(this.musicGain);

      leadOsc.start(now);
      leadOsc.stop(now + 0.14);
    }
  }
}

export const soundSystem = new SoundSystem();
