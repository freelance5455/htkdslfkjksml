import { PlayerCourse } from './types';

export const AVAILABLE_COURSES: Omit<PlayerCourse, 'daysEnrolled' | 'completed'>[] = [
  {
    id: 'driving_license',
    name: 'رخصة قيادة مهنية خاصة',
    icon: '🚗',
    durationDays: 3,
    dailyHours: 1.5,
    cost: 1200,
    skillBonus: 8,
    repBonus: 5,
    unlockedCareerPerk: 'تخفيض تكاليف النقل وفتح وظائف قيادة خاصة'
  },
  {
    id: 'language_diploma',
    name: 'دبلومة لغات وترجمة معتمدة',
    icon: '🗣️',
    durationDays: 4,
    dailyHours: 2,
    cost: 1800,
    skillBonus: 14,
    repBonus: 8,
    unlockedCareerPerk: 'زيادة 25% في أرباح العمل الحر والمراسلات'
  },
  {
    id: 'coding_bootcamp',
    name: 'معسكر برمجة وتطوير تقني',
    icon: '💻',
    durationDays: 6,
    dailyHours: 2.5,
    cost: 3500,
    skillBonus: 28,
    repBonus: 12,
    unlockedCareerPerk: 'فتح العمل البرمجي الاحترافي برواتب عالية جداً'
  },
  {
    id: 'business_mgmt',
    name: 'دبلومة إدارة مشاريع وتسويق',
    icon: '📈',
    durationDays: 5,
    dailyHours: 2,
    cost: 2600,
    skillBonus: 20,
    repBonus: 15,
    unlockedCareerPerk: 'مضاعفة أرباح المحلات والمشاريع التجارية 30%'
  },
  {
    id: 'university_degree',
    name: 'شهادة جامعية عليا (بكالوريوس/ماجستير)',
    icon: '🎓',
    durationDays: 10,
    dailyHours: 3,
    cost: 6500,
    skillBonus: 40,
    repBonus: 25,
    unlockedCareerPerk: 'مكانة مرموقة وترقيات قيادية سريعة في كافة الوظائف'
  }
];
