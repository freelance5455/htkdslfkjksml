import * as THREE from 'three';
import { ElementId } from '../types';

export interface ActiveProjectile {
  active: boolean;
  mesh: THREE.Mesh;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  power: number;
  colorHex: number;
  radius: number;
  elementId?: ElementId;
}

interface ActiveRing {
  active: boolean;
  mesh: THREE.Mesh;
  life: number;
  maxLife: number;
  maxScale: number;
}

interface ActiveSpark {
  active: boolean;
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
}

interface ActiveMote {
  mesh: THREE.Mesh;
  ox: number;
  oy: number;
  oz: number;
  phase: number;
  speed: number;
}

export class CombatVfxPool {
  private scene: THREE.Scene;
  private projectiles: ActiveProjectile[] = [];
  private rings: ActiveRing[] = [];
  private sparks: ActiveSpark[] = [];
  private motes: ActiveMote[] = [];
  private slashMesh: THREE.Mesh;
  private slashLife = 0;
  private shieldMesh: THREE.Mesh;
  private shieldLife = 0;

  private sharedGeos: THREE.BufferGeometry[] = [];
  private sharedMats: THREE.Material[] = [];

  constructor(scene: THREE.Scene) {
    this.scene = scene;

    // 1. Sword Slash Arc
    const slashGeo = new THREE.TorusGeometry(1.35, 0.08, 6, 16, Math.PI * 0.78);
    slashGeo.rotateX(Math.PI / 2);
    const slashMat = new THREE.MeshBasicMaterial({
      color: 0xfef08a,
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide,
    });
    this.slashMesh = new THREE.Mesh(slashGeo, slashMat);
    this.slashMesh.visible = false;
    this.scene.add(this.slashMesh);
    this.sharedGeos.push(slashGeo);
    this.sharedMats.push(slashMat);

    // 2. Player Defense Shield Aura
    const shieldGeo = new THREE.SphereGeometry(1.35, 16, 12);
    const shieldMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      wireframe: true,
      transparent: true,
      opacity: 0.45,
    });
    this.shieldMesh = new THREE.Mesh(shieldGeo, shieldMat);
    this.shieldMesh.visible = false;
    this.scene.add(this.shieldMesh);
    this.sharedGeos.push(shieldGeo);
    this.sharedMats.push(shieldMat);

    // 3. Pooled Projectiles (12)
    const projGeo = new THREE.OctahedronGeometry(0.32, 0);
    this.sharedGeos.push(projGeo);
    for (let i = 0; i < 12; i++) {
      const mat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        emissive: 0xf97316,
        emissiveIntensity: 1.5,
        roughness: 0.2,
      });
      this.sharedMats.push(mat);
      const mesh = new THREE.Mesh(projGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.projectiles.push({
        active: false,
        mesh,
        x: 0,
        y: 0,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        life: 0,
        maxLife: 1.5,
        power: 20,
        colorHex: 0xf97316,
        radius: 0.6,
      });
    }

    // 4. Pooled Expanding Rings (8)
    const ringGeo = new THREE.TorusGeometry(1.0, 0.08, 6, 24);
    ringGeo.rotateX(Math.PI / 2);
    this.sharedGeos.push(ringGeo);
    for (let i = 0; i < 8; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.85,
      });
      this.sharedMats.push(mat);
      const mesh = new THREE.Mesh(ringGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.rings.push({
        active: false,
        mesh,
        life: 0,
        maxLife: 0.65,
        maxScale: 5,
      });
    }

    // 5. Pooled Sparks (24)
    const sparkGeo = new THREE.IcosahedronGeometry(0.14, 0);
    this.sharedGeos.push(sparkGeo);
    for (let i = 0; i < 24; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.95,
      });
      this.sharedMats.push(mat);
      const mesh = new THREE.Mesh(sparkGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.sparks.push({
        active: false,
        mesh,
        vx: 0,
        vy: 0,
        vz: 0,
        life: 0,
        maxLife: 0.45,
      });
    }

    // 6. Pooled Ambient Nature Motes (20 fireflies/leaves/embers/arcane dust)
    const moteGeo = new THREE.OctahedronGeometry(0.08, 0);
    this.sharedGeos.push(moteGeo);
    for (let i = 0; i < 20; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xd9f99d,
        transparent: true,
        opacity: 0.75,
      });
      this.sharedMats.push(mat);
      const mesh = new THREE.Mesh(moteGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.motes.push({
        mesh,
        ox: (Math.random() - 0.5) * 24,
        oy: 0.6 + Math.random() * 4.5,
        oz: (Math.random() - 0.5) * 24,
        phase: Math.random() * Math.PI * 2,
        speed: 0.8 + Math.random() * 1.1,
      });
    }
  }

  public spawnSlash(x: number, y: number, z: number, facingYaw: number, colorHex = 0xfef08a): void {
    this.slashMesh.position.set(x, y + 1.05, z);
    this.slashMesh.rotation.set(0, facingYaw - Math.PI * 0.39, 0);
    (this.slashMesh.material as THREE.MeshBasicMaterial).color.setHex(colorHex);
    (this.slashMesh.material as THREE.MeshBasicMaterial).opacity = 0.92;
    this.slashMesh.scale.setScalar(1.0);
    this.slashMesh.visible = true;
    this.slashLife = 0.22;
  }

  public activateShield(colorHex: number, durationSec = 5.0): void {
    (this.shieldMesh.material as THREE.MeshBasicMaterial).color.setHex(colorHex);
    this.shieldMesh.visible = true;
    this.shieldLife = durationSec;
  }

  public get isShieldActive(): boolean {
    return this.shieldLife > 0;
  }

  public spawnProjectile(
    x: number,
    y: number,
    z: number,
    dirX: number,
    dirY: number,
    dirZ: number,
    speed: number,
    power: number,
    colorHex: number,
    scale = 1.0,
    elementId?: ElementId,
  ): void {
    const slot = this.projectiles.find((p) => !p.active) ?? this.projectiles[0];
    slot.active = true;
    slot.x = x;
    slot.y = y;
    slot.z = z;
    slot.vx = dirX * speed;
    slot.vy = dirY * speed;
    slot.vz = dirZ * speed;
    slot.life = 1.8;
    slot.maxLife = 1.8;
    slot.power = power;
    slot.colorHex = colorHex;
    slot.radius = 0.7 * scale;
    slot.elementId = elementId;

    const mat = slot.mesh.material as THREE.MeshStandardMaterial;
    mat.color.setHex(colorHex);
    mat.emissive.setHex(colorHex);
    slot.mesh.position.set(x, y, z);
    slot.mesh.scale.setScalar(scale);
    slot.mesh.visible = true;
  }

  public spawnRing(x: number, y: number, z: number, colorHex: number, maxScale = 5.5, duration = 0.65): void {
    const slot = this.rings.find((r) => !r.active) ?? this.rings[0];
    slot.active = true;
    slot.life = duration;
    slot.maxLife = duration;
    slot.maxScale = maxScale;
    (slot.mesh.material as THREE.MeshBasicMaterial).color.setHex(colorHex);
    (slot.mesh.material as THREE.MeshBasicMaterial).opacity = 0.9;
    slot.mesh.position.set(x, y + 0.22, z);
    slot.mesh.scale.setScalar(0.3);
    slot.mesh.visible = true;
  }

  public spawnBurst(x: number, y: number, z: number, colorHex: number, count = 6): void {
    let spawned = 0;
    for (let i = 0; i < this.sparks.length && spawned < count; i++) {
      const s = this.sparks[i];
      if (s.active) continue;
      s.active = true;
      s.life = 0.42;
      s.maxLife = 0.42;
      const ang = (spawned / count) * Math.PI * 2 + Math.random() * 0.5;
      const spd = 3.2 + Math.random() * 3.5;
      s.vx = Math.cos(ang) * spd;
      s.vy = 2.2 + Math.random() * 3.5;
      s.vz = Math.sin(ang) * spd;
      (s.mesh.material as THREE.MeshBasicMaterial).color.setHex(colorHex);
      (s.mesh.material as THREE.MeshBasicMaterial).opacity = 0.95;
      s.mesh.position.set(x, y, z);
      s.mesh.scale.setScalar(1);
      s.mesh.visible = true;
      spawned++;
    }
  }

  public spawnBlockSparks(x: number, y: number, z: number, facingYaw: number): void {
    const fx = x + Math.sin(facingYaw) * 0.65;
    const fz = z + Math.cos(facingYaw) * 0.65;
    this.spawnBurst(fx, y + 1.1, fz, 0x38bdf8, 8);
    this.spawnBurst(fx, y + 1.1, fz, 0xfef08a, 5);
  }

  public updateAmbientMotes(
    dt: number,
    playerX: number,
    playerY: number,
    playerZ: number,
    biomeId: string,
    isNight: boolean,
    inDungeon: boolean,
    enabled: boolean,
  ): void {
    if (!enabled || inDungeon) {
      for (let i = 0; i < this.motes.length; i++) {
        this.motes[i].mesh.visible = false;
      }
      return;
    }

    let colorHex = 0xd9f99d;
    let rise = 0.0;
    if (biomeId === 'volcanic_ridge') {
      colorHex = 0xf97316;
      rise = 1.4;
    } else if (biomeId === 'arcane_glade' || biomeId === 'mystic_woods') {
      colorHex = isNight ? 0x67e8f9 : 0xc084fc;
      rise = 0.25;
    } else if (biomeId === 'snow_peaks') {
      colorHex = 0xe0f2fe;
      rise = -0.6;
    } else if (isNight) {
      colorHex = 0xfef08a; // Fireflies
      rise = 0.2;
    } else {
      colorHex = 0xa7f3d0; // Gentle forest pollen/leaves
      rise = -0.15;
    }

    for (let i = 0; i < this.motes.length; i++) {
      const m = this.motes[i];
      m.phase += dt * m.speed;
      m.oy += rise * dt;
      if (m.oy > 5.5) m.oy = 0.5;
      if (m.oy < 0.3) m.oy = 4.8;
      m.mesh.visible = true;
      const mat = m.mesh.material as THREE.MeshBasicMaterial;
      mat.color.setHex(colorHex);
      mat.opacity = 0.35 + 0.45 * Math.abs(Math.sin(m.phase * 1.4));
      m.mesh.position.set(
        playerX + m.ox + Math.sin(m.phase) * 0.9,
        playerY + m.oy + Math.cos(m.phase * 0.9) * 0.35,
        playerZ + m.oz + Math.cos(m.phase * 0.7) * 0.9,
      );
      m.mesh.scale.setScalar(isNight ? 1.15 : 0.85);
    }
  }

  public update(
    dt: number,
    playerX: number,
    playerY: number,
    playerZ: number,
    onProjectileMove: (proj: ActiveProjectile) => boolean,
  ): void {
    // Slash fade & sweep
    if (this.slashLife > 0) {
      this.slashLife = Math.max(0, this.slashLife - dt);
      const t = 1 - this.slashLife / 0.22;
      this.slashMesh.scale.setScalar(1 + t * 0.35);
      (this.slashMesh.material as THREE.MeshBasicMaterial).opacity = 0.9 * (1 - t);
      if (this.slashLife <= 0) this.slashMesh.visible = false;
    }

    // Shield follow player
    if (this.shieldLife > 0) {
      this.shieldLife = Math.max(0, this.shieldLife - dt);
      this.shieldMesh.position.set(playerX, playerY + 1.05, playerZ);
      this.shieldMesh.rotation.y += dt * 1.4;
      (this.shieldMesh.material as THREE.MeshBasicMaterial).opacity =
        0.28 + Math.sin(this.shieldLife * 6) * 0.1;
      if (this.shieldLife <= 0) this.shieldMesh.visible = false;
    }

    // Projectiles
    for (let i = 0; i < this.projectiles.length; i++) {
      const p = this.projectiles[i];
      if (!p.active) continue;
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      p.mesh.position.set(p.x, p.y, p.z);
      p.mesh.rotation.x += dt * 7;
      p.mesh.rotation.y += dt * 9;

      if (Math.random() < 0.28) {
        this.spawnBurst(p.x, p.y, p.z, p.colorHex, 1);
      }

      const hit = onProjectileMove(p);
      if (hit || p.life <= 0) {
        if (hit) {
          this.spawnBurst(p.x, p.y, p.z, p.colorHex, 6);
        }
        p.active = false;
        p.mesh.visible = false;
      }
    }

    // Rings
    for (let i = 0; i < this.rings.length; i++) {
      const r = this.rings[i];
      if (!r.active) continue;
      r.life -= dt;
      const t = 1 - Math.max(0, r.life) / r.maxLife;
      const s = 0.4 + t * r.maxScale;
      r.mesh.scale.setScalar(s);
      (r.mesh.material as THREE.MeshBasicMaterial).opacity = 0.85 * (1 - t);
      if (r.life <= 0) {
        r.active = false;
        r.mesh.visible = false;
      }
    }

    // Sparks
    for (let i = 0; i < this.sparks.length; i++) {
      const s = this.sparks[i];
      if (!s.active) continue;
      s.life -= dt;
      s.vy -= 12 * dt;
      s.mesh.position.x += s.vx * dt;
      s.mesh.position.y += s.vy * dt;
      s.mesh.position.z += s.vz * dt;
      const t = Math.max(0, s.life) / s.maxLife;
      s.mesh.scale.setScalar(t);
      (s.mesh.material as THREE.MeshBasicMaterial).opacity = t;
      if (s.life <= 0) {
        s.active = false;
        s.mesh.visible = false;
      }
    }
  }

  public dispose(): void {
    this.scene.remove(this.slashMesh, this.shieldMesh);
    this.projectiles.forEach((p) => this.scene.remove(p.mesh));
    this.rings.forEach((r) => this.scene.remove(r.mesh));
    this.sparks.forEach((s) => this.scene.remove(s.mesh));
    this.motes.forEach((m) => this.scene.remove(m.mesh));
    this.sharedGeos.forEach((g) => g.dispose());
    this.sharedMats.forEach((m) => m.dispose());
  }
}
