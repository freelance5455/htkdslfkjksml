// Game data: weapons, items, missions.
export type ItemCategory = 'weapon' | 'food' | 'tool' | 'ammo' | 'misc';

export interface WeaponDef {
  id: string;
  name: string;
  short: string;
  damage: number;
  fireRate: number; // seconds between shots
  auto: boolean;
  spread: number;
  range: number;
  sound: 'pistol' | 'rifle' | 'sniper' | 'rpg';
  icon: string;
  ammo: number; // rounds consumed per shot (0 = unlimited)
  projectile?: 'grenade' | 'rpg' | 'smoke';
  slot: number;
  desc: string;
}

export const WEAPONS: Record<string, WeaponDef> = {
  fists: {
    id: 'fists',
    name: 'Bare Knuckles',
    short: 'FISTS',
    damage: 12,
    fireRate: 0.35,
    auto: false,
    spread: 0,
    range: 2.2,
    sound: 'pistol',
    icon: '✊',
    ammo: 0,
    slot: 0,
    desc: 'Melee strike. Always available.',
  },
  eagle: {
    id: 'eagle',
    name: 'Desert Vulture .50',
    short: 'DESERT EAGLE',
    damage: 55,
    fireRate: 0.42,
    auto: false,
    spread: 0.012,
    range: 140,
    sound: 'pistol',
    icon: '🔫',
    ammo: 1,
    slot: 1,
    desc: 'Heavy .50 revolver. Punchy single shots.',
  },
  sniper: {
    id: 'sniper',
    name: 'Vector VX-9 Sniper',
    short: 'SNIPER',
    damage: 120,
    fireRate: 1.25,
    auto: false,
    spread: 0.001,
    range: 600,
    sound: 'sniper',
    icon: '🎯',
    ammo: 1,
    slot: 2,
    desc: 'Long range precision rifle. Very loud.',
  },
  rpg: {
    id: 'rpg',
    name: 'Skyfire RPG',
    short: 'RPG',
    damage: 180,
    fireRate: 1.8,
    auto: false,
    spread: 0.004,
    range: 320,
    sound: 'rpg',
    icon: '🚀',
    ammo: 1,
    projectile: 'rpg',
    slot: 3,
    desc: 'Launches rockets. Immense blast radius.',
  },
  grenade: {
    id: 'grenade',
    name: 'Frag Grenade',
    short: 'GRENADE',
    damage: 140,
    fireRate: 1.0,
    auto: false,
    spread: 0,
    range: 26,
    sound: 'rifle',
    icon: '💣',
    ammo: 1,
    projectile: 'grenade',
    slot: 4,
    desc: 'Timed explosive. Throw to clear crowds.',
  },
  smoke: {
    id: 'smoke',
    name: 'Smoke Grenade',
    short: 'SMOKE',
    damage: 0,
    fireRate: 1.0,
    auto: false,
    spread: 0,
    range: 24,
    sound: 'rifle',
    icon: '🌫️',
    ammo: 1,
    projectile: 'smoke',
    slot: 5,
    desc: 'Creates a dense smoke screen.',
  },
};

export const WEAPON_ORDER = ['fists', 'eagle', 'sniper', 'rpg', 'grenade', 'smoke'];

export interface ItemDef {
  id: string;
  name: string;
  category: ItemCategory;
  price: number;
  icon: string;
  desc: string;
  heal?: number;
  ammoFor?: string;
  amount?: number;
}

export const ITEMS: Record<string, ItemDef> = {
  medkit: {
    id: 'medkit',
    name: 'Field Medkit',
    category: 'food',
    price: 300,
    icon: '🩹',
    desc: 'Restores 50 health when used.',
    heal: 50,
  },
  burger: {
    id: 'burger',
    name: 'Street Burger',
    category: 'food',
    price: 60,
    icon: '🍔',
    desc: 'Restores 20 health.',
    heal: 20,
  },
  energy: {
    id: 'energy',
    name: 'Energy Drink',
    category: 'food',
    price: 40,
    icon: '🥤',
    desc: 'Restores 12 health and gives a boost.',
    heal: 12,
  },
  pistolammo: {
    id: 'pistolammo',
    name: 'Pistol Rounds x40',
    category: 'ammo',
    price: 120,
    icon: '🔩',
    desc: 'Ammunition for the Desert Vulture.',
    ammoFor: 'eagle',
    amount: 40,
  },
  sniperammo: {
    id: 'sniperammo',
    name: 'Sniper Rounds x12',
    category: 'ammo',
    price: 300,
    icon: '🎯',
    desc: 'Ammunition for the Vector VX-9.',
    ammoFor: 'sniper',
    amount: 12,
  },
  rpgammo: {
    id: 'rpgammo',
    name: 'Rockets x4',
    category: 'ammo',
    price: 900,
    icon: '🚀',
    desc: 'Rockets for the Skyfire RPG.',
    ammoFor: 'rpg',
    amount: 4,
  },
  wrench: {
    id: 'wrench',
    name: 'Torque Wrench',
    category: 'tool',
    price: 250,
    icon: '🔧',
    desc: 'Used at garages for vehicle tuning.',
  },
  lockpick: {
    id: 'lockpick',
    name: 'Lockpick Set',
    category: 'tool',
    price: 350,
    icon: '🗝️',
    desc: 'Steals locked vehicles without damage.',
  },
  phonecard: {
    id: 'phonecard',
    name: 'Prepaid Credit',
    category: 'misc',
    price: 50,
    icon: '📱',
    desc: 'Top-up for the in-game phone.',
  },
  casefile: {
    id: 'casefile',
    name: 'Case File',
    category: 'misc',
    price: 0,
    icon: '📁',
    desc: 'Collected intel from the police station.',
  },
};

export interface MissionDef {
  id: string;
  title: string;
  brief: string;
  reward: number;
  type: 'goto' | 'vehicle' | 'collect' | 'escape';
  target: [number, number];
  vehicleType?: string;
  collectCount?: number;
  startHint: string;
}

export const MISSIONS: MissionDef[] = [
  {
    id: 'm1',
    title: 'Welcome to Solstice',
    brief: 'Leave your villa and reach the street outside.',
    reward: 500,
    type: 'goto',
    target: [-450, -400],
    startHint: 'Walk out of the front door of your house.',
  },
  {
    id: 'm2',
    title: 'Grand Theft Auto',
    brief: 'Steal the Vortex M8 parked outside and deliver it to TORQUE GARAGE.',
    reward: 2500,
    type: 'vehicle',
    target: [-250, 150],
    vehicleType: 'm8',
    startHint: 'Find the black M8 and drive it to the garage.',
  },
  {
    id: 'm3',
    title: 'Courier Run',
    brief: 'Collect 3 packages scattered across Midtown and bring them to the mall.',
    reward: 1800,
    type: 'collect',
    target: [250, -150],
    collectCount: 3,
    startHint: 'Collect the marked packages, then deliver them.',
  },
  {
    id: 'm4',
    title: 'Hot Pursuit',
    brief: 'Steal any car and lose the police for 45 seconds.',
    reward: 3200,
    type: 'escape',
    target: [0, 0],
    startHint: 'Any vehicle works. Break line of sight and keep moving.',
  },
];

export interface LandmarkDef {
  id: string;
  name: string;
  x: number;
  z: number;
  w: number;
  d: number;
  h: number;
  color: number;
  icon: string;
  interior?: string;
  doorX: number;
  doorZ: number;
}

export const LANDMARKS: LandmarkDef[] = [
  { id: 'police', name: 'Solstice Police HQ', x: 0, z: 250, w: 46, d: 30, h: 13, color: 0x3a63c4, icon: '🚓', interior: 'police', doorX: 0, doorZ: 268 },
  { id: 'mall', name: 'Solstice Grand Mall', x: 250, z: -150, w: 72, d: 46, h: 17, color: 0x9a5fc4, icon: '🏬', interior: 'mall', doorX: 250, doorZ: -122 },
  { id: 'mod', name: 'TORQUE Garage', x: -250, z: 150, w: 34, d: 24, h: 10, color: 0xd4622a, icon: '🔧', interior: 'mod', doorX: -250, doorZ: 165 },
  { id: 'phone', name: 'City Phone Store', x: 150, z: 50, w: 24, d: 18, h: 9, color: 0x2f9d5b, icon: '📱', interior: 'phone', doorX: 150, doorZ: 62 },
  { id: 'bus', name: 'Central Transit Hub', x: -150, z: -300, w: 42, d: 26, h: 9, color: 0x3a7fb0, icon: '🚌', doorX: -150, doorZ: -284 },
  { id: 'hospital', name: 'St. Verity Hospital', x: 250, z: 300, w: 38, d: 26, h: 15, color: 0xd8d8dc, icon: '🏥', doorX: 250, doorZ: 316 },
  { id: 'villa', name: 'Your Villa', x: -450, z: -450, w: 26, d: 22, h: 9, color: 0xd8c8a8, icon: '🏡', interior: 'villa', doorX: -450, doorZ: -436 },
  { id: 'park', name: 'Verdant Park', x: 0, z: 640, w: 700, d: 500, h: 0, color: 0x3f7a3a, icon: '🌳', doorX: 0, doorZ: 400 },
];

export const POLICE_STATION = { x: 0, z: 250 };
export const MALL = { x: 250, z: -150 };
export const MOD_SHOP = { x: -250, z: 150 };
export const PHONE_SHOP = { x: 150, z: 50 };
export const BUS_STATION = { x: -150, z: -300 };
export const HOSPITAL = { x: 250, z: 300 };
export const VILLA = { x: -450, z: -450 };
