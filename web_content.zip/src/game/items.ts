export type ItemId = "espada" | "maca" | "frutas" | "pocao" | "carne" | "pano" | "osso" | "atadura";
export type ItemKind = "weapon" | "food" | "material";

export interface ItemDef {
  id: ItemId;
  name: string;
  desc: string;
  stack: number;
  kind: ItemKind;
  heal?: number;
  damage?: number;
}

export const ITEMS: Record<ItemId, ItemDef> = {
  espada: { id: "espada", name: "Espada de Madeira", desc: "Uma espada simples, esculpida em carvalho. Leve e confiável.", stack: 1, kind: "weapon", damage: 22 },
  maca: { id: "maca", name: "Maçã", desc: "Fresca e suculenta. Recupera 15 de vida.", stack: 16, kind: "food", heal: 15 },
  frutas: { id: "frutas", name: "Frutas Silvestres", desc: "Colhidas na floresta. Recupera 8 de vida.", stack: 16, kind: "food", heal: 8 },
  pocao: { id: "pocao", name: "Poção de Vida", desc: "Um líquido vermelho brilhante. Recupera 50 de vida.", stack: 5, kind: "food", heal: 50 },
  carne: { id: "carne", name: "Carne Podre", desc: "Tem um cheiro horrível... Recupera só 4 de vida.", stack: 16, kind: "food", heal: 4 },
  pano: { id: "pano", name: "Pano Velho", desc: "Retalho de casaco rasgado. Serve para criar ataduras.", stack: 16, kind: "material" },
  osso: { id: "osso", name: "Osso", desc: "Um osso resistente. Talvez sirva para algo um dia.", stack: 16, kind: "material" },
  atadura: { id: "atadura", name: "Atadura", desc: "Feita com panos velhos. Recupera 30 de vida.", stack: 8, kind: "food", heal: 30 },
};

export interface Slot {
  id: ItemId;
  n: number;
}

export const HOT = 8;
export const BAG = 20;

/** Slots 0..7 = barra rápida, 8..27 = mochila */
export class Inventory {
  slots: (Slot | null)[] = new Array(HOT + BAG).fill(null);

  get(i: number) {
    return this.slots[i] ?? null;
  }

  add(id: ItemId, n = 1): number {
    const def = ITEMS[id];
    for (let i = 0; i < this.slots.length && n > 0; i++) {
      const s = this.slots[i];
      if (s && s.id === id && s.n < def.stack) {
        const k = Math.min(n, def.stack - s.n);
        s.n += k;
        n -= k;
      }
    }
    for (let i = 0; i < this.slots.length && n > 0; i++) {
      if (!this.slots[i]) {
        const k = Math.min(n, def.stack);
        this.slots[i] = { id, n: k };
        n -= k;
      }
    }
    return n;
  }

  canAdd(id: ItemId) {
    const def = ITEMS[id];
    return this.slots.some((s) => !s || (s.id === id && s.n < def.stack));
  }

  remove(i: number, n = 1) {
    const s = this.slots[i];
    if (!s) return;
    s.n -= n;
    if (s.n <= 0) this.slots[i] = null;
  }

  count(id: ItemId) {
    return this.slots.reduce((a, s) => a + (s && s.id === id ? s.n : 0), 0);
  }

  removeId(id: ItemId, n: number) {
    for (let i = this.slots.length - 1; i >= 0 && n > 0; i--) {
      const s = this.slots[i];
      if (s && s.id === id) {
        const k = Math.min(n, s.n);
        s.n -= k;
        n -= k;
        if (s.n <= 0) this.slots[i] = null;
      }
    }
  }

  move(from: number, to: number) {
    if (from === to) return;
    const a = this.slots[from], b = this.slots[to];
    if (a && b && a.id === b.id) {
      const max = ITEMS[a.id].stack;
      const k = Math.min(a.n, max - b.n);
      if (k > 0) {
        b.n += k;
        a.n -= k;
        if (a.n <= 0) this.slots[from] = null;
        return;
      }
    }
    this.slots[from] = b;
    this.slots[to] = a;
  }

  serialize() {
    return this.slots.map((s) => (s ? { ...s } : null));
  }

  load(data: (Slot | null)[] | undefined) {
    this.slots = new Array(HOT + BAG).fill(null);
    if (!data) return;
    data.forEach((s, i) => {
      if (i < this.slots.length && s && ITEMS[s.id]) this.slots[i] = { id: s.id, n: s.n };
    });
  }
}
