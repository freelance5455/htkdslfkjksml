import * as THREE from "three";

// palettes are authored in display space (classic pixel-art workflow)
THREE.ColorManagement.enabled = false;

export const shared = {
  uTime: { value: 0 },
};

const HASH = `
float hash3(vec3 p){ p = fract(p*0.3183099 + 0.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
`;

function pixelGrain(mat: THREE.MeshLambertMaterial, amount: number, sway: boolean) {
  mat.customProgramCacheKey = () => `grain-${amount}-${sway ? 1 : 0}`;
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = shared.uTime;
    sh.vertexShader = sh.vertexShader
      .replace(
        "#include <common>",
        `#include <common>
         varying vec3 vWPos;
         uniform float uTime;
         ${sway ? "attribute float aSway;" : ""}`
      )
      .replace(
        "#include <begin_vertex>",
        `#include <begin_vertex>
         ${sway ? `
         vec4 wp0 = modelMatrix * vec4(transformed, 1.0);
         float ph = uTime * 1.7 + wp0.x * 0.21 + wp0.z * 0.17;
         transformed.x += sin(ph) * aSway * 0.13;
         transformed.z += cos(ph * 0.83) * aSway * 0.09;` : ""}`
      )
      .replace(
        "#include <project_vertex>",
        `#include <project_vertex>
         vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`
      );
    sh.fragmentShader = sh.fragmentShader
      .replace(
        "#include <common>",
        `#include <common>
         varying vec3 vWPos;
         ${HASH}`
      )
      .replace(
        "#include <color_fragment>",
        `#include <color_fragment>
         float gA = hash3(floor(vWPos * 2.0));
         float gB = hash3(floor(vWPos * 0.5) + 7.0);
         diffuseColor.rgb *= ${(1 - amount).toFixed(3)} + ${(amount * 2).toFixed(3)} * (gA * 0.7 + gB * 0.3);`
      );
  };
}

export function makeTerrainMat() {
  const m = new THREE.MeshLambertMaterial({ vertexColors: true });
  pixelGrain(m, 0.09, false);
  return m;
}
export function makeVegMat() {
  const m = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
  pixelGrain(m, 0.06, true);
  return m;
}
export function makeStructMat() {
  const m = new THREE.MeshLambertMaterial({ vertexColors: true });
  pixelGrain(m, 0.07, false);
  return m;
}

const NOISE_GLSL = `
float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vn(vec2 p){ vec2 i = floor(p); vec2 f = fract(p); f = f*f*(3.0-2.0*f);
  return mix(mix(h21(i), h21(i+vec2(1.0,0.0)), f.x), mix(h21(i+vec2(0.0,1.0)), h21(i+vec2(1.0,1.0)), f.x), f.y); }
`;

export const waterUniforms = {
  uTime: shared.uTime,
  uDeep: { value: new THREE.Color(0x1d4a5e) },
  uShallow: { value: new THREE.Color(0x3f8a8f) },
  uSky: { value: new THREE.Color(0x9cc8e8) },
  uSunDir: { value: new THREE.Vector3(0.3, 0.8, 0.2) },
  uSunCol: { value: new THREE.Color(0xfff2d0) },
  uDay: { value: 1 },
};

export function makeWaterMat() {
  return new THREE.ShaderMaterial({
    uniforms: { ...THREE.UniformsUtils.clone(THREE.UniformsLib.fog), ...waterUniforms },
    transparent: true,
    depthWrite: false,
    fog: true,
    vertexShader: `
      attribute float aSpeed;
      varying vec2 vUv; varying vec3 vW; varying float vSpeed;
      #include <fog_pars_vertex>
      void main(){
        vUv = uv; vSpeed = aSpeed;
        vec4 w = modelMatrix * vec4(position, 1.0);
        vW = w.xyz;
        vec4 mvPosition = viewMatrix * w;
        gl_Position = projectionMatrix * mvPosition;
        #include <fog_vertex>
      }`,
    fragmentShader: `
      uniform float uTime; uniform vec3 uDeep; uniform vec3 uShallow; uniform vec3 uSky;
      uniform vec3 uSunDir; uniform vec3 uSunCol; uniform float uDay;
      varying vec2 vUv; varying vec3 vW; varying float vSpeed;
      #include <fog_pars_fragment>
      ${NOISE_GLSL}
      void main(){
        float t = uTime;
        vec2 p = floor((vUv - vec2(0.0, t * vSpeed)) * 2.0) / 2.0;
        float n = vn(p * 0.35 + vec2(t * 0.12, t * 0.07)) * 0.6 + vn(p * 0.9 - vec2(t * 0.18, -t * 0.11)) * 0.4;
        vec3 col = mix(uDeep, uShallow, n * 0.7);
        vec3 V = normalize(cameraPosition - vW);
        float fres = pow(1.0 - clamp(V.y, 0.0, 1.0), 3.0);
        col = mix(col, uSky, clamp(fres * 0.75 + 0.12, 0.0, 0.8));
        float band = fract(n * 5.0 + t * 0.25);
        float hl = step(0.93, band);
        float streak = vSpeed > 0.01 ? step(0.8, vn(vec2(p.x * 0.8, p.y * 0.15))) * 0.12 : 0.0;
        vec3 N = normalize(vec3((n - 0.5) * 0.7, 1.0, (vn(p * 0.8 + 3.1 + t * 0.2) - 0.5) * 0.7));
        vec3 R = reflect(-uSunDir, N);
        float spec = step(0.55, pow(max(dot(R, V), 0.0), 50.0));
        col += uSunCol * spec * 0.9 * uDay;
        col += vec3(0.85, 0.95, 1.0) * (hl * 0.1 + streak) * (0.3 + uDay * 0.7);
        gl_FragColor = vec4(col, 0.84);
        #include <fog_fragment>
      }`,
  });
}

export const fallUniforms = {
  uTime: shared.uTime,
  uLight: { value: 1 },
};

export function makeWaterfallMat() {
  return new THREE.ShaderMaterial({
    uniforms: { ...THREE.UniformsUtils.clone(THREE.UniformsLib.fog), ...fallUniforms },
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    fog: true,
    vertexShader: `
      varying vec2 vUv;
      #include <fog_pars_vertex>
      void main(){
        vUv = uv;
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        gl_Position = projectionMatrix * mvPosition;
        #include <fog_vertex>
      }`,
    fragmentShader: `
      uniform float uTime; uniform float uLight;
      varying vec2 vUv;
      #include <fog_pars_fragment>
      ${NOISE_GLSL}
      void main(){
        vec2 p = vec2(floor(vUv.x * 18.0), floor(vUv.y * 2.0) / 2.0);
        float n = vn(vec2(p.x * 0.7, (p.y - uTime * 10.0) * 0.18));
        float n2 = vn(vec2(p.x * 1.6 + 5.0, (p.y - uTime * 13.0) * 0.35));
        float s = step(0.5, n * 0.6 + n2 * 0.4);
        float s2 = step(0.8, n2);
        vec3 col = mix(vec3(0.33, 0.58, 0.7), vec3(0.9, 0.96, 1.0), s);
        col = mix(col, vec3(1.0), s2 * 0.6);
        float edge = smoothstep(0.0, 0.1, vUv.x) * smoothstep(1.0, 0.9, vUv.x);
        float a = (0.8 + s * 0.18) * mix(0.55, 1.0, step(0.35, vn(vec2(p.x * 0.5, 3.0))));
        gl_FragColor = vec4(col * uLight, a * edge);
        #include <fog_fragment>
      }`,
  });
}

export function makeFoamMat() {
  return new THREE.ShaderMaterial({
    uniforms: { ...THREE.UniformsUtils.clone(THREE.UniformsLib.fog), ...fallUniforms },
    transparent: true,
    depthWrite: false,
    fog: true,
    vertexShader: `
      varying vec2 vUv;
      #include <fog_pars_vertex>
      void main(){
        vUv = uv;
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        gl_Position = projectionMatrix * mvPosition;
        #include <fog_vertex>
      }`,
    fragmentShader: `
      uniform float uTime; uniform float uLight;
      varying vec2 vUv;
      #include <fog_pars_fragment>
      ${NOISE_GLSL}
      void main(){
        vec2 c = vUv - 0.5;
        float d = length(c) * 2.0;
        vec2 p = floor(vUv * 28.0);
        float n = vn(p * 0.5 + vec2(uTime * 1.5, -uTime));
        float ring = fract(d * 2.5 - uTime * 0.6);
        float a = step(0.55, n) * (1.0 - smoothstep(0.4, 1.0, d)) + step(0.9, ring) * (1.0 - d) * 0.6;
        if (a < 0.1) discard;
        gl_FragColor = vec4(vec3(0.95, 0.98, 1.0) * uLight, clamp(a, 0.0, 0.85));
        #include <fog_fragment>
      }`,
  });
}
