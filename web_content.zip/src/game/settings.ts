export interface Settings {
  turns: number;
  turnTime: number; // seconds, 0 = unlimited
  dismember: boolean;
  sound: boolean;
  vibrate: boolean;
  slowmo: boolean;
}

export interface Stats {
  wins: number;
  losses: number;
  draws: number;
  best: number;
}

export const DEFAULT_SETTINGS: Settings = {
  turns: 12,
  turnTime: 25,
  dismember: true,
  sound: true,
  vibrate: true,
  slowmo: true,
};

const SK = 'toribash-mobile-settings';
const TK = 'toribash-mobile-stats';

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(SK);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return { ...DEFAULT_SETTINGS };
}

export function saveSettings(s: Settings) {
  try {
    localStorage.setItem(SK, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

export function loadStats(): Stats {
  try {
    const raw = localStorage.getItem(TK);
    if (raw) return { wins: 0, losses: 0, draws: 0, best: 0, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return { wins: 0, losses: 0, draws: 0, best: 0 };
}

export function saveStats(s: Stats) {
  try {
    localStorage.setItem(TK, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}
