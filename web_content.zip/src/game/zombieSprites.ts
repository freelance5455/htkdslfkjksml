import * as THREE from "three";
import { mulberry32 } from "./noise";
import type { Dir, Frame } from "./sprites";

const W = 32, H = 48;
const Z = {
  hairD: "#140e0c", hair: "#231915", hairL: "#3a2b24",
  skin: "#d6cabd", skinD: "#a89a8c", skinG: "#9aa08a",
  eyeW: "#ece6e0", eyeR: "#7a2a2a", pupil: "#2a1a1a", ring: "#6e5a5e",
  coat: "#6b5e42", coatD: "#50462f", coatL: "#877757", coatDD: "#3d3524",
  shirt: "#3a2a30", shirtD: "#2a1e24",
  belt: "#3e2f26", buckle: "#7a6a50",
  pants: "#1b1718", pantsL: "#2a2426",
  boot: "#5a4535", bootL: "#76604a", sole: "#2a1f19",
  blood: "#8a1f1f", bloodL: "#b0362c", bloodD: "#4e1010",
};

type Ctx = CanvasRenderingContext2D;
function rect(c: Ctx, x: number, y: number, w: number, h: number, col: string) {
  c.fillStyle = col;
  c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}
function px(c: Ctx, x: number, y: number, col: string) {
  c.fillStyle = col;
  c.fillRect(Math.round(x), Math.round(y), 1, 1);
}

// fixed ragged coat hem and blood stains (consistent between frames)
const R = mulberry32(4711);
const HEM: number[] = [];
for (let i = 0; i < 20; i++) HEM.push(Math.floor(R() * 4));
const STAINS: [number, number, number][] = [];
for (let i = 0; i < 9; i++) STAINS.push([Math.floor(R() * 14), Math.floor(R() * 18), R() < 0.5 ? 2 : 1]);

function stains(c: Ctx, x0: number, y0: number, w: number, h: number, y: number) {
  for (const [sx, sy, s] of STAINS) {
    if (sx >= w || sy >= h) continue;
    rect(c, x0 + sx, y0 + sy + y, s, s, Z.blood);
    if (s > 1) px(c, x0 + sx, y0 + sy + y, Z.bloodL);
    px(c, x0 + sx + s, y0 + sy + y + s, Z.bloodD);
  }
}

function legs(c: Ctx, phase: number, view: "back" | "front") {
  const liftL = phase === 1 ? (view === "back" ? 2 : -1) : phase === 3 ? (view === "back" ? -1 : 1) : 0;
  const liftR = phase === 3 ? (view === "back" ? 2 : -1) : phase === 1 ? (view === "back" ? -1 : 1) : 0;
  const leg = (x: number, lift: number, knee: number) => {
    const bot = 46 - lift;
    rect(c, x, 31, 5, bot - 31 - 5, Z.pants);
    rect(c, x + (view === "back" ? 3 : 1), 32, 1, bot - 38, Z.pantsL);
    // torn bloody knee
    rect(c, x + 1, knee, 3, 2, Z.skinD);
    px(c, x + 1, knee, Z.blood); px(c, x + 3, knee + 1, Z.bloodL); px(c, x + 2, knee + 2, Z.bloodD);
    // boot
    rect(c, x - 1, bot - 5, 6, 5, Z.boot);
    rect(c, x - 1, bot - 5, 6, 1, Z.bootL);
    rect(c, x - 1, bot - 1, 6, 2, Z.sole);
  };
  leg(10.5, liftL, 37);
  leg(16.5, liftR, 38);
}

function hand(c: Ctx, x: number, y: number) {
  rect(c, x, y, 3, 3, Z.skin);
  px(c, x, y + 2, Z.skinD);
  px(c, x + 1, y + 1, Z.blood);
  px(c, x + 2, y + 2, Z.bloodL);
  px(c, x, y + 3, Z.skinD); px(c, x + 2, y + 3, Z.skinD);
}

function coatBody(c: Ctx, y: number, front: boolean) {
  // shoulders + body
  rect(c, 9, 14 + y, 14, 20, Z.coat);
  rect(c, 8, 15 + y, 16, 3, Z.coat);
  rect(c, 9, 14 + y, 14, 1, Z.coatL);
  // folds
  rect(c, 12, 20 + y, 1, 12, Z.coatD);
  rect(c, 19, 22 + y, 1, 10, Z.coatD);
  rect(c, 15, 18 + y, 1, 6, Z.coatD);
  // ragged hem
  for (let i = 0; i < 14; i++) {
    const h = HEM[i];
    rect(c, 9 + i, 34 + y, 1, h, i % 3 === 0 ? Z.coatD : Z.coat);
  }
  if (front) {
    rect(c, 13, 15 + y, 6, 12, Z.shirt);
    rect(c, 13, 20 + y, 6, 1, Z.shirtD);
    px(c, 15, 18 + y, Z.bloodD); px(c, 16, 23 + y, Z.blood);
    rect(c, 13, 27 + y, 6, 2, Z.belt);
    rect(c, 15, 27 + y, 2, 2, Z.buckle);
    rect(c, 13, 29 + y, 6, 6, Z.pants);
    // lapels
    for (let i = 0; i < 5; i++) { px(c, 12 + (i > 2 ? 1 : 0), 15 + y + i, Z.coatL); px(c, 19 - (i > 2 ? 1 : 0), 15 + y + i, Z.coatL); }
    rect(c, 12, 15 + y, 1, 19, Z.coatDD);
    rect(c, 19, 15 + y, 1, 19, Z.coatDD);
  }
  stains(c, 9, 15, 14, 20, y);
}

function sleeve(c: Ctx, x: number, top: number, bottom: number, shade: string) {
  rect(c, x, top, 4, bottom - top, Z.coat);
  rect(c, x + (shade === "L" ? 0 : 3), top + 1, 1, bottom - top - 1, Z.coatD);
  // tattered cuff
  px(c, x, bottom, Z.coat); px(c, x + 2, bottom, Z.coatD);
  px(c, x + 1, top + 5, Z.blood); px(c, x + 2, top + 9, Z.bloodL);
}

function hairBack(c: Ctx, y: number) {
  rect(c, 9, 2 + y, 14, 12, Z.hair);
  rect(c, 8, 4 + y, 16, 9, Z.hair);
  rect(c, 10, 1 + y, 12, 1, Z.hair);
  // shaggy spikes
  const sp = [[7, 6], [7, 9], [24, 5], [24, 8], [11, 0], [15, 0], [19, 0], [8, 12], [23, 12], [12, 14], [16, 14], [20, 14]];
  for (const [x, yy] of sp) rect(c, x, yy + y, 2, 2, Z.hair);
  for (let i = 0; i < 6; i++) rect(c, 10 + i * 2, 3 + y + (i % 2), 1, 8, Z.hairL);
  rect(c, 9, 12 + y, 14, 2, Z.hairD);
}

function drawBack(c: Ctx, phase: number, bob: number, attack: boolean) {
  legs(c, phase, "back");
  const y = bob;
  const sw = phase === 1 ? 1 : phase === 3 ? -1 : 0;
  if (attack) {
    // arms raised forward (seen from behind: short, lifted)
    sleeve(c, 5, 12 + y, 22 + y, "L");
    sleeve(c, 23, 12 + y, 22 + y, "R");
    hand(c, 5.5, 9 + y);
    hand(c, 23.5, 9 + y);
  }
  coatBody(c, y, false);
  // neck
  rect(c, 14, 13 + y, 4, 2, Z.skinG);
  hairBack(c, y);
  if (!attack) {
    sleeve(c, 5, 15 + y + sw, 30 + y + sw, "L");
    sleeve(c, 23, 15 + y - sw, 30 + y - sw, "R");
    hand(c, 5.5, 30 + y + sw);
    hand(c, 23.5, 30 + y - sw);
  }
}

function drawFront(c: Ctx, phase: number, bob: number, attack: boolean) {
  legs(c, phase, "front");
  const y = bob;
  const sw = phase === 1 ? 1 : phase === 3 ? -1 : 0;
  if (!attack) {
    sleeve(c, 5, 15 + y - sw, 30 + y - sw, "L");
    sleeve(c, 23, 15 + y + sw, 30 + y + sw, "R");
  }
  coatBody(c, y, true);
  if (!attack) {
    hand(c, 5.5, 30 + y - sw);
    hand(c, 23.5, 30 + y + sw);
  }
  // neck & face
  rect(c, 14, 13 + y, 4, 2, Z.skinD);
  rect(c, 11, 5 + y, 10, 9, Z.skin);
  rect(c, 11, 12 + y, 10, 1, Z.skinD);
  // eyes: pale, dark rings, red rims
  rect(c, 12, 8 + y, 3, 2, Z.eyeW); px(c, 13, 9 + y, Z.pupil);
  rect(c, 17, 8 + y, 3, 2, Z.eyeW); px(c, 18, 9 + y, Z.pupil);
  rect(c, 12, 10 + y, 3, 1, Z.ring); rect(c, 17, 10 + y, 3, 1, Z.ring);
  px(c, 12, 8 + y, Z.eyeR); px(c, 19, 8 + y, Z.eyeR);
  // mouth + blood
  rect(c, 14, 12 + y, 3, 1, Z.bloodD);
  px(c, 19, 11 + y, Z.blood); px(c, 20, 12 + y, Z.bloodL); px(c, 11, 7 + y, Z.blood);
  // hair with messy bangs
  rect(c, 9, 1 + y, 14, 5, Z.hair);
  rect(c, 8, 3 + y, 3, 10, Z.hair);
  rect(c, 21, 3 + y, 3, 10, Z.hair);
  for (let i = 0; i < 5; i++) rect(c, 11 + i * 2, 5 + y, 1, 2 + (i % 2) * 2, Z.hair);
  rect(c, 14, 5 + y, 3, 2, Z.hair);
  const sp = [[7, 5], [24, 4], [11, 0], [16, 0], [20, 0], [7, 10], [24, 10]];
  for (const [x, yy] of sp) rect(c, x, yy + y, 2, 2, Z.hair);
  for (let i = 0; i < 5; i++) px(c, 10 + i * 3, 2 + y, Z.hairL);
  px(c, 9, 12 + y, Z.hairD); px(c, 22, 12 + y, Z.hairD);
  if (attack) {
    // arms reaching toward the viewer
    rect(c, 8, 16 + y, 5, 5, Z.coat);
    rect(c, 19, 16 + y, 5, 5, Z.coat);
    rect(c, 8, 20 + y, 5, 1, Z.coatD);
    rect(c, 19, 20 + y, 5, 1, Z.coatD);
    hand(c, 9, 14 + y);
    hand(c, 20, 14 + y);
    px(c, 9, 13 + y, Z.skin); px(c, 11, 13 + y, Z.skin); px(c, 20, 13 + y, Z.skin); px(c, 22, 13 + y, Z.skin);
  }
}

function drawSide(c: Ctx, phase: number, bob: number, attack: boolean) {
  const y = bob;
  const stride = phase === 1 ? 2 : phase === 3 ? -2 : 0;
  const leg = (x: number, col: string, lift: number) => {
    const bot = 46 - lift;
    rect(c, x, 31, 5, bot - 36, col);
    rect(c, x + 1, 37, 3, 2, Z.skinD);
    px(c, x + 2, 37, Z.blood);
    rect(c, x, bot - 5, 6, 4, Z.boot);
    rect(c, x, bot - 5, 6, 1, Z.bootL);
    rect(c, x, bot - 1, 7, 2, Z.sole);
  };
  leg(13.5 - stride, "#121012", stride !== 0 ? 1 : 0);
  // far arm
  if (attack) {
    rect(c, 17, 16 + y, 10, 3, Z.coatD);
    rect(c, 27, 16 + y, 2, 3, Z.skinD);
  } else sleeve(c, 13 - stride * 0.5, 15 + y, 29 + y, "L");
  // coat (slightly hunched forward)
  rect(c, 11, 14 + y, 10, 20, Z.coat);
  rect(c, 12, 13 + y, 9, 2, Z.coat);
  rect(c, 11, 14 + y, 10, 1, Z.coatL);
  rect(c, 14, 20 + y, 1, 12, Z.coatD);
  for (let i = 0; i < 10; i++) rect(c, 11 + i, 34 + y, 1, HEM[i + 3], i % 3 === 0 ? Z.coatD : Z.coat);
  stains(c, 11, 15, 10, 18, y);
  rect(c, 18, 16 + y, 3, 10, Z.shirt);
  leg(14.5 + stride, Z.pants, 0);
  // head forward
  rect(c, 16, 12 + y, 3, 2, Z.skinG);
  rect(c, 11, 2 + y, 11, 11, Z.hair);
  rect(c, 18, 6 + y, 5, 7, Z.skin);
  px(c, 22, 9 + y, Z.skin);
  rect(c, 20, 8 + y, 2, 1, Z.eyeW); px(c, 21, 8 + y, Z.pupil);
  px(c, 20, 9 + y, Z.ring);
  px(c, 21, 11 + y, Z.bloodD); px(c, 22, 12 + y, Z.blood);
  rect(c, 18, 3 + y, 6, 3, Z.hair);
  rect(c, 21, 6 + y, 2, 2, Z.hair);
  const sp = [[10, 3], [9, 7], [10, 11], [13, 0], [17, 0], [21, 1], [12, 13]];
  for (const [x, yy] of sp) rect(c, x, yy + y, 2, 2, Z.hair);
  for (let i = 0; i < 4; i++) rect(c, 12 + i * 2, 4 + y, 1, 7, Z.hairL);
  // near arm
  if (attack) {
    rect(c, 16, 18 + y, 11, 4, Z.coat);
    rect(c, 16, 21 + y, 11, 1, Z.coatD);
    px(c, 20, 19 + y, Z.blood);
    hand(c, 27, 18 + y);
  } else {
    sleeve(c, 15 + stride * 0.5, 15 + y, 30 + y, "R");
    hand(c, 15.5 + stride * 0.5, 30 + y);
  }
}

function outline(cv: HTMLCanvasElement, w: number, h: number) {
  const c = cv.getContext("2d")!;
  const img = c.getImageData(0, 0, w, h);
  const d = img.data;
  const out = new Uint8ClampedArray(d);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      if (d[i + 3] > 0) continue;
      for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const xx = x + ox, yy = y + oy;
        if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
        if (d[(yy * w + xx) * 4 + 3] > 0) {
          out[i] = 14; out[i + 1] = 9; out[i + 2] = 12; out[i + 3] = 255;
          break;
        }
      }
    }
  c.putImageData(new ImageData(out, w, h), 0, 0);
}

export function pixelTexture(cv: HTMLCanvasElement) {
  const t = new THREE.CanvasTexture(cv);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.colorSpace = THREE.NoColorSpace;
  t.needsUpdate = true;
  return t;
}

function frame(draw: (c: Ctx) => void): Frame {
  const cv = document.createElement("canvas");
  cv.width = W;
  cv.height = H;
  draw(cv.getContext("2d")!);
  outline(cv, W, H);
  return { tex: pixelTexture(cv), aspect: W / H };
}

export interface ZombieSpriteSet {
  idle: Record<Dir, Frame[]>;
  walk: Record<Dir, Frame[]>;
  attack: Record<Dir, Frame[]>;
}

export function buildZombieSprites(): ZombieSpriteSet {
  const fns: Record<Dir, typeof drawBack> = { back: drawBack, front: drawFront, side: drawSide };
  const set: ZombieSpriteSet = {
    idle: { back: [], front: [], side: [] },
    walk: { back: [], front: [], side: [] },
    attack: { back: [], front: [], side: [] },
  };
  (Object.keys(fns) as Dir[]).forEach((d) => {
    const f = fns[d];
    set.idle[d].push(frame((c) => f(c, 0, 0, false)));
    set.idle[d].push(frame((c) => f(c, 0, 1, false)));
    for (let p = 0; p < 4; p++) set.walk[d].push(frame((c) => f(c, p, p % 2 === 1 ? 1 : 0, false)));
    set.attack[d].push(frame((c) => f(c, 0, 0, true)));
    set.attack[d].push(frame((c) => f(c, 2, 1, true)));
  });
  return set;
}

/** Wooden sword held in hand: 10x26, grip near the bottom */
export function buildSwordTexture() {
  const w = 10, h = 26;
  const cv = document.createElement("canvas");
  cv.width = w;
  cv.height = h;
  const c = cv.getContext("2d")!;
  // blade
  rect(c, 3, 2, 4, 15, "#c89c62");
  rect(c, 3, 2, 1, 15, "#e3c089");
  rect(c, 6, 2, 1, 15, "#a57a45");
  rect(c, 4, 1, 2, 1, "#c89c62");
  px(c, 4, 0, "#e3c089");
  px(c, 5, 6, "#a57a45"); px(c, 4, 11, "#a57a45");
  // guard
  rect(c, 0, 17, 10, 2, "#6b4424");
  rect(c, 0, 17, 10, 1, "#8a5a32");
  // grip
  rect(c, 4, 19, 2, 5, "#4a2e18");
  px(c, 4, 20, "#6b4424"); px(c, 5, 22, "#6b4424");
  // pommel
  rect(c, 3, 24, 4, 2, "#7a5230");
  outline(cv, w, h);
  return { tex: pixelTexture(cv), w, h };
}

/** Slash arc effect (pixel crescent) */
export function buildSlashTexture() {
  const s = 32;
  const cv = document.createElement("canvas");
  cv.width = s;
  cv.height = s;
  const c = cv.getContext("2d")!;
  for (let y = 0; y < s; y++)
    for (let x = 0; x < s; x++) {
      const dx = x - s / 2 + 0.5, dy = y - s / 2 + 0.5;
      const d = Math.hypot(dx, dy);
      const a = Math.atan2(dy, dx);
      if (a > 0.3) continue; // upper arc only
      const t = (a + Math.PI) / (Math.PI + 0.3);
      const inner = 11 - t * 3, outer = 14;
      if (d > inner && d < outer) {
        const edge = d > outer - 1.2;
        c.fillStyle = edge ? "rgba(255,255,255,0.95)" : `rgba(236,220,255,${(0.35 + t * 0.5).toFixed(2)})`;
        c.fillRect(x, y, 1, 1);
      }
    }
  return pixelTexture(cv);
}
