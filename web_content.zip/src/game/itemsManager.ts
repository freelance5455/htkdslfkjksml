import * as THREE from 'three';
import { createMasalaDabbaTexture } from './proceduralTextures';

export interface WorldItem {
  id: string;
  name: string;
  missionLevel?: number;
  type: 'mission' | 'coin' | 'star' | 'snack';
  group: THREE.Group;
  initialPos: THREE.Vector3;
  collected: boolean;
  radius: number;
  onCollect?: () => void;
}

export class ItemsManager {
  public items: WorldItem[] = [];
  public coins: WorldItem[] = [];
  public stars: WorldItem[] = [];
  private itemGroup = new THREE.Group();

  constructor(scene: THREE.Scene) {
    this.itemGroup.name = 'World_Items_Collection';
    scene.add(this.itemGroup);
    this.spawnStaticCoinsAndStars();
  }

  // 1. Static Collectible Coins and Stars scattered around the home & garden
  private spawnStaticCoinsAndStars() {
    const coinMat = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      metalness: 0.9,
      roughness: 0.2,
    });

    const starMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.7,
      roughness: 0.25,
      emissive: 0xd97706,
      emissiveIntensity: 0.3,
    });

    const coinPositions: [number, number, number][] = [
      // Living room
      [-2, 0.5, 6],
      [2, 0.5, 6],
      [-3, 0.5, 10],
      [3, 0.5, 10],
      [0, 1.0, 12.2], // on sofa
      // Kitchen & Dining
      [-8, 0.5, 4],
      [-11, 0.5, 3],
      [-14, 0.5, 5],
      [-11, 1.1, 6.5], // on dining table
      [-9, 0.5, 10],
      // Study & Bedroom
      [8, 0.5, 4],
      [11, 0.5, 3],
      [14, 0.5, 5],
      [11, 1.1, 14.8], // on study desk
      [11, 1.8, 5.5], // on top bunk bed
      // Garden & Courtyard
      [0, 0.5, -3],
      [-4, 0.5, -5],
      [4, 0.5, -5],
      [-6, 0.5, -11],
      [6, 0.5, -11],
      [0, 0.5, -14],
      // Rooftop stairs & terrace
      [15, 1.2, -2],
      [15, 2.4, -4],
      [15, 3.8, -6],
      [12, 4.2, 4],
      [6, 4.2, 8],
      [0, 4.2, 10],
      [-6, 4.2, 8],
      [-10, 4.2, 4],
    ];

    coinPositions.forEach(([x, y, z], index) => {
      const coinGroup = new THREE.Group();
      coinGroup.position.set(x, y, z);

      const coinMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.05, 16), coinMat);
      coinMesh.rotation.x = Math.PI / 2;
      coinGroup.add(coinMesh);

      this.itemGroup.add(coinGroup);

      const item: WorldItem = {
        id: `coin_${index}`,
        name: 'Family Gold Coin',
        type: 'coin',
        group: coinGroup,
        initialPos: new THREE.Vector3(x, y, z),
        collected: false,
        radius: 0.85,
      };

      this.items.push(item);
      this.coins.push(item);
    });

    // 4 Hidden Star Badges in secret fun spots
    const starPositions: [number, number, number][] = [
      [0, 2.2, 12], // atop the living room sofa back
      [-11, 1.8, 14.8], // on top kitchen spice shelf
      [11, 2.2, 5.5], // above top bunk bed
      [-12, 5.6, 12], // on top of the rooftop water tank
    ];

    starPositions.forEach(([x, y, z], index) => {
      const starGroup = new THREE.Group();
      starGroup.position.set(x, y, z);

      const starMesh = new THREE.Mesh(new THREE.OctahedronGeometry(0.3, 0), starMat);
      starGroup.add(starMesh);

      this.itemGroup.add(starGroup);

      const item: WorldItem = {
        id: `star_${index}`,
        name: 'Super Star Trophy',
        type: 'star',
        group: starGroup,
        initialPos: new THREE.Vector3(x, y, z),
        collected: false,
        radius: 1.0,
      };

      this.items.push(item);
      this.stars.push(item);
    });
  }

  // 2. Spawn Mission Specific Items for each Level
  public spawnMissionItems(level: number) {
    // Clear previously spawned mission items
    this.items = this.items.filter((item) => {
      if (item.type === 'mission') {
        this.itemGroup.remove(item.group);
        return false;
      }
      return true;
    });

    switch (level) {
      case 1:
        // Level 1: TV Remote hidden between sofa cushions
        this.addTVRemoteItem();
        break;

      case 2:
        // Level 2: 4 Kitchen Ingredients
        this.addKitchenItems();
        break;

      case 3:
        // Level 3: Dad's Challenge (Glasses, Newspaper, Diary, 2 Toy Piles)
        this.addDadChallengeItems();
        break;

      case 4:
        // Level 4: The Great Sibling Argument (Dialogue only, courtyard marker)
        this.addSiblingDialogueMarker();
        break;

      case 5:
        // Level 5: Grand Treasure Hunt (3 Riddles + Golden Treasure Chest)
        this.addTreasureHuntItems();
        break;
    }
  }

  // Level 1: TV Remote
  private addTVRemoteItem() {
    const remoteGroup = new THREE.Group();
    // Tucked near living room sofa cushions
    remoteGroup.position.set(1.4, 0.65, 12.1);

    const remoteMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      metalness: 0.3,
      roughness: 0.4,
    });
    const remoteBody = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.05, 0.42), remoteMat);
    remoteGroup.add(remoteBody);

    // Glowing red power button
    const redBtn = new THREE.Mesh(
      new THREE.SphereGeometry(0.025, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xef4444 })
    );
    redBtn.position.set(0, 0.03, -0.15);
    remoteGroup.add(redBtn);

    // Golden beacon ring below
    this.attachBeacon(remoteGroup);

    this.itemGroup.add(remoteGroup);

    this.items.push({
      id: 'remote',
      name: 'Missing TV Remote (रिमोट)',
      type: 'mission',
      missionLevel: 1,
      group: remoteGroup,
      initialPos: new THREE.Vector3(1.4, 0.65, 12.1),
      collected: false,
      radius: 1.3,
    });
  }

  // Level 2: Kitchen items
  private addKitchenItems() {
    // 1. Masala Dabba (Kitchen counter)
    const dabbaGroup = new THREE.Group();
    dabbaGroup.position.set(-12.8, 1.05, 14.8);
    const dabbaTex = createMasalaDabbaTexture();
    const dabbaMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24, 0.24, 0.12, 16),
      new THREE.MeshStandardMaterial({
        map: dabbaTex,
        metalness: 0.8,
        roughness: 0.3,
      })
    );
    dabbaGroup.add(dabbaMesh);
    this.attachBeacon(dabbaGroup);
    this.itemGroup.add(dabbaGroup);
    this.items.push({
      id: 'masala_dabba',
      name: 'Masala Dabba (मसाला डब्बा)',
      type: 'mission',
      missionLevel: 2,
      group: dabbaGroup,
      initialPos: new THREE.Vector3(-12.8, 1.05, 14.8),
      collected: false,
      radius: 1.3,
    });

    // 2. Belan (Rolling Pin) on dining table
    const belanGroup = new THREE.Group();
    belanGroup.position.set(-10.5, 0.95, 6.2);
    const belanWoodMat = new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.6 });
    const roller = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.45, 12), belanWoodMat);
    roller.rotation.z = Math.PI / 2;
    belanGroup.add(roller);
    this.attachBeacon(belanGroup);
    this.itemGroup.add(belanGroup);
    this.items.push({
      id: 'belan',
      name: 'Belan (बेलन)',
      type: 'mission',
      missionLevel: 2,
      group: belanGroup,
      initialPos: new THREE.Vector3(-10.5, 0.95, 6.2),
      collected: false,
      radius: 1.3,
    });

    // 3. Fresh Ginger (Adrak) on living room coffee table
    const gingerGroup = new THREE.Group();
    gingerGroup.position.set(0.6, 0.55, 8);
    const gingerMat = new THREE.MeshStandardMaterial({ color: 0xa16207, roughness: 0.9 });
    const gingerMesh = new THREE.Mesh(new THREE.DodecahedronGeometry(0.12, 1), gingerMat);
    gingerGroup.add(gingerMesh);
    this.attachBeacon(gingerGroup);
    this.itemGroup.add(gingerGroup);
    this.items.push({
      id: 'ginger',
      name: 'Fresh Ginger (अदरक)',
      type: 'mission',
      missionLevel: 2,
      group: gingerGroup,
      initialPos: new THREE.Vector3(0.6, 0.55, 8),
      collected: false,
      radius: 1.3,
    });

    // 4. Milk Jug (Doodh) on kitchen floor near fridge
    const milkGroup = new THREE.Group();
    milkGroup.position.set(-14.2, 0.45, 13);
    const steelMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9, roughness: 0.2 });
    const milkCan = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.18, 0.4, 16), steelMat);
    milkGroup.add(milkCan);
    this.attachBeacon(milkGroup);
    this.itemGroup.add(milkGroup);
    this.items.push({
      id: 'milk_jug',
      name: 'Milk Jug (दूध का जग)',
      type: 'mission',
      missionLevel: 2,
      group: milkGroup,
      initialPos: new THREE.Vector3(-14.2, 0.45, 13),
      collected: false,
      radius: 1.3,
    });
  }

  // Level 3: Dad's Challenge items
  private addDadChallengeItems() {
    // 1. Dad's Reading Glasses (Study desk)
    const glassesGroup = new THREE.Group();
    glassesGroup.position.set(11, 0.95, 14.8);
    const specMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.9 });
    const gL = new THREE.Mesh(new THREE.TorusGeometry(0.05, 0.01, 8, 12), specMat);
    gL.position.x = -0.07;
    const gR = new THREE.Mesh(new THREE.TorusGeometry(0.05, 0.01, 8, 12), specMat);
    gR.position.x = 0.07;
    glassesGroup.add(gL, gR);
    this.attachBeacon(glassesGroup);
    this.itemGroup.add(glassesGroup);
    this.items.push({
      id: 'glasses',
      name: 'Dad’s Reading Glasses (पापा का चश्मा)',
      type: 'mission',
      missionLevel: 3,
      group: glassesGroup,
      initialPos: new THREE.Vector3(11, 0.95, 14.8),
      collected: false,
      radius: 1.3,
    });

    // 2. Morning Newspaper on Garden Swing (Jhoola)
    const newsGroup = new THREE.Group();
    newsGroup.position.set(6, 0.72, -8);
    const paperMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.8 });
    const paper = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.05, 0.28), paperMat);
    newsGroup.add(paper);
    this.attachBeacon(newsGroup);
    this.itemGroup.add(newsGroup);
    this.items.push({
      id: 'newspaper',
      name: 'Morning Newspaper (सुबह का अख़बार)',
      type: 'mission',
      missionLevel: 3,
      group: newsGroup,
      initialPos: new THREE.Vector3(6, 0.72, -8),
      collected: false,
      radius: 1.3,
    });

    // 3. Office Diary on Living Room Table
    const diaryGroup = new THREE.Group();
    diaryGroup.position.set(-0.6, 0.55, 8);
    const diaryMat = new THREE.MeshStandardMaterial({ color: 0x7f1d1d, roughness: 0.6 });
    const diary = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.06, 0.38), diaryMat);
    diaryGroup.add(diary);
    this.attachBeacon(diaryGroup);
    this.itemGroup.add(diaryGroup);
    this.items.push({
      id: 'diary',
      name: 'Office Diary (ऑफिस डायरी)',
      type: 'mission',
      missionLevel: 3,
      group: diaryGroup,
      initialPos: new THREE.Vector3(-0.6, 0.55, 8),
      collected: false,
      radius: 1.3,
    });

    // 4. Toy Pile 1 in Living Room
    const toy1Group = new THREE.Group();
    toy1Group.position.set(-4, 0.3, 10);
    const block1 = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.25, 0.25), new THREE.MeshStandardMaterial({ color: 0xef4444 }));
    const block2 = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.2, 0.2), new THREE.MeshStandardMaterial({ color: 0x3b82f6 }));
    block2.position.set(0.15, 0.1, 0.1);
    toy1Group.add(block1, block2);
    this.attachBeacon(toy1Group);
    this.itemGroup.add(toy1Group);
    this.items.push({
      id: 'toys_tidy_1',
      name: 'Tidy Toy Pile (लिविंग रूम के खिलौने)',
      type: 'mission',
      missionLevel: 3,
      group: toy1Group,
      initialPos: new THREE.Vector3(-4, 0.3, 10),
      collected: false,
      radius: 1.3,
    });

    // 5. Toy Pile 2 in Study Room
    const toy2Group = new THREE.Group();
    toy2Group.position.set(13, 0.3, 9);
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 12), new THREE.MeshStandardMaterial({ color: 0x10b981 }));
    toy2Group.add(ball);
    this.attachBeacon(toy2Group);
    this.itemGroup.add(toy2Group);
    this.items.push({
      id: 'toys_tidy_2',
      name: 'Tidy Study Toys (स्टडी रूम के खिलौने)',
      type: 'mission',
      missionLevel: 3,
      group: toy2Group,
      initialPos: new THREE.Vector3(13, 0.3, 9),
      collected: false,
      radius: 1.3,
    });
  }

  // Level 4: Sibling Argument Zone in Courtyard Garden
  private addSiblingDialogueMarker() {
    const markerGroup = new THREE.Group();
    markerGroup.position.set(0, 0.2, -6);
    this.attachBeacon(markerGroup);
    this.itemGroup.add(markerGroup);
    this.items.push({
      id: 'dialogue_settled',
      name: 'Sibling Dispute Zone (पंचायत स्थल)',
      type: 'mission',
      missionLevel: 4,
      group: markerGroup,
      initialPos: new THREE.Vector3(0, 0.2, -6),
      collected: false,
      radius: 1.8,
    });
  }

  // Level 5: Treasure Hunt Clues & Heirloom Chest
  private addTreasureHuntItems() {
    const scrollMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.6 });
    const ribbonMat = new THREE.MeshStandardMaterial({ color: 0xdc2626 });

    const createScroll = () => {
      const g = new THREE.Group();
      const parchment = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.35, 12), scrollMat);
      parchment.rotation.z = Math.PI / 2;
      const ribbon = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.065, 0.08, 12), ribbonMat);
      ribbon.rotation.z = Math.PI / 2;
      g.add(parchment, ribbon);
      return g;
    };

    // Clue 1: Near Garden Tulsi Plant
    const clue1Group = createScroll();
    clue1Group.position.set(-6, 1.4, -8);
    this.attachBeacon(clue1Group);
    this.itemGroup.add(clue1Group);
    this.items.push({
      id: 'clue_tulsi',
      name: 'Clue 1: Tulsi Riddle (तुलसी का पहला सुराग)',
      type: 'mission',
      missionLevel: 5,
      group: clue1Group,
      initialPos: new THREE.Vector3(-6, 1.4, -8),
      collected: false,
      radius: 1.4,
    });

    // Clue 2: Living Room Family Portrait
    const clue2Group = createScroll();
    clue2Group.position.set(0, 1.4, 14.5);
    this.attachBeacon(clue2Group);
    this.itemGroup.add(clue2Group);
    this.items.push({
      id: 'clue_portrait',
      name: 'Clue 2: Family Photo Riddle (दूसरा सुराग)',
      type: 'mission',
      missionLevel: 5,
      group: clue2Group,
      initialPos: new THREE.Vector3(0, 1.4, 14.5),
      collected: false,
      radius: 1.4,
    });

    // Clue 3: Rooftop Terrace Clothesline
    const clue3Group = createScroll();
    clue3Group.position.set(0, 4.8, 6);
    this.attachBeacon(clue3Group);
    this.itemGroup.add(clue3Group);
    this.items.push({
      id: 'clue_rooftop',
      name: 'Clue 3: Rooftop Breeze Riddle (तीसरा सुराग)',
      type: 'mission',
      missionLevel: 5,
      group: clue3Group,
      initialPos: new THREE.Vector3(0, 4.8, 6),
      collected: false,
      radius: 1.4,
    });

    // Golden Family Heirloom Chest on the Rooftop Terrace!
    const chestGroup = new THREE.Group();
    chestGroup.position.set(-6, 4.25, 12);

    const chestMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.9,
      roughness: 0.2,
    });
    const trimMat = new THREE.MeshStandardMaterial({
      color: 0x78350f,
      metalness: 0.6,
      roughness: 0.4,
    });

    const chestBase = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.45, 0.5), chestMat);
    const chestLid = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.8, 16, 1, false, 0, Math.PI), chestMat);
    chestLid.position.y = 0.225;
    chestLid.rotation.z = Math.PI / 2;

    const chestLock = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), new THREE.MeshBasicMaterial({ color: 0xef4444 }));
    chestLock.position.set(0, 0.1, 0.26);

    chestGroup.add(chestBase, chestLid, chestLock);
    this.attachBeacon(chestGroup);
    this.itemGroup.add(chestGroup);

    this.items.push({
      id: 'treasure_chest',
      name: 'Grand Family Heirloom Chest (परिवार का खज़ाना)',
      type: 'mission',
      missionLevel: 5,
      group: chestGroup,
      initialPos: new THREE.Vector3(-6, 4.25, 12),
      collected: false,
      radius: 1.6,
    });
  }

  // Visual glowing target beacon
  private attachBeacon(group: THREE.Group) {
    const ringGeo = new THREE.RingGeometry(0.3, 0.42, 16);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.75,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.name = 'beacon_ring';
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = -0.3;
    group.add(ring);
  }

  // Animation loop update for items (bobbing and rotating)
  public update(time: number) {
    this.items.forEach((item) => {
      if (item.collected) {
        item.group.visible = false;
        return;
      }

      item.group.visible = true;

      if (item.type === 'coin') {
        item.group.rotation.y = time * 2.8;
        item.group.position.y = item.initialPos.y + Math.sin(time * 3 + item.initialPos.x) * 0.08;
      } else if (item.type === 'star') {
        item.group.rotation.y = time * 2.0;
        item.group.rotation.x = Math.sin(time * 1.5) * 0.2;
        item.group.position.y = item.initialPos.y + Math.sin(time * 2.5) * 0.12;
      } else if (item.type === 'mission') {
        item.group.rotation.y = time * 1.2;
        item.group.position.y = item.initialPos.y + Math.sin(time * 2) * 0.06;

        const beacon = item.group.getObjectByName('beacon_ring');
        if (beacon) {
          const s = 1.0 + Math.sin(time * 4) * 0.2;
          beacon.scale.set(s, s, s);
        }
      }
    });
  }
}
