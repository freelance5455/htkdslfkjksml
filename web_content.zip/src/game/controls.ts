/**
 * Gamepad API polling, customizable key bindings, and touch swipe gestures
 */

import { PlayerAction } from '../types/game';

export interface KeyBindings {
  jump: string;
  slide: string;
  left: string;
  right: string;
  board: string;
  pause: string;
}

export const DEFAULT_KEY_BINDINGS: KeyBindings = {
  jump: 'ArrowUp',
  slide: 'ArrowDown',
  left: 'ArrowLeft',
  right: 'ArrowRight',
  board: 'KeyE',
  pause: 'Escape'
};

class ControlsManager {
  private keyBindings: KeyBindings = { ...DEFAULT_KEY_BINDINGS };
  private activeGamepadIndex: number | null = null;
  private prevGamepadButtons: boolean[] = [];
  private prevGamepadAxes: number[] = [];
  private touchStartX = 0;
  private touchStartY = 0;
  private touchStartTime = 0;
  private lastTapTime = 0;

  constructor() {
    this.loadBindings();
    this.initGamepadListeners();
  }

  private loadBindings() {
    try {
      const saved = localStorage.getItem('subway_mom_key_bindings');
      if (saved) {
        this.keyBindings = { ...DEFAULT_KEY_BINDINGS, ...JSON.parse(saved) };
      }
    } catch {
      // Ignore
    }
  }

  public saveBindings(bindings: KeyBindings) {
    this.keyBindings = { ...bindings };
    try {
      localStorage.setItem('subway_mom_key_bindings', JSON.stringify(bindings));
    } catch {
      // Ignore
    }
  }

  public getBindings(): KeyBindings {
    return { ...this.keyBindings };
  }

  private initGamepadListeners() {
    if (typeof window === 'undefined') return;

    window.addEventListener('gamepadconnected', (e: GamepadEvent) => {
      this.activeGamepadIndex = e.gamepad.index;
      // Initialize states
      this.prevGamepadButtons = new Array(e.gamepad.buttons.length).fill(false);
      this.prevGamepadAxes = new Array(e.gamepad.axes.length).fill(0);
    });

    window.addEventListener('gamepaddisconnected', (e: GamepadEvent) => {
      if (this.activeGamepadIndex === e.gamepad.index) {
        this.activeGamepadIndex = null;
      }
    });
  }

  public getConnectedGamepadName(): string | null {
    if (typeof navigator === 'undefined' || !navigator.getGamepads) return null;
    const gamepads = navigator.getGamepads();
    if (this.activeGamepadIndex !== null && gamepads[this.activeGamepadIndex]) {
      return gamepads[this.activeGamepadIndex]!.id;
    }
    for (const gp of gamepads) {
      if (gp && gp.connected) return gp.id;
    }
    return null;
  }

  /**
   * Polls gamepad inputs and returns an array of actions triggered this frame
   */
  public pollGamepad(): PlayerAction[] {
    const actions: PlayerAction[] = [];
    if (typeof navigator === 'undefined' || !navigator.getGamepads) return actions;

    const gamepads = navigator.getGamepads();
    let pad: Gamepad | null = null;

    if (this.activeGamepadIndex !== null && gamepads[this.activeGamepadIndex]) {
      pad = gamepads[this.activeGamepadIndex];
    } else {
      for (const gp of gamepads) {
        if (gp && gp.connected) {
          pad = gp;
          this.activeGamepadIndex = gp.index;
          break;
        }
      }
    }

    if (!pad) return actions;

    // Check buttons edge trigger
    const buttons = pad.buttons;
    const isJustPressed = (btnIndex: number): boolean => {
      if (!buttons[btnIndex]) return false;
      const isDown = buttons[btnIndex].pressed;
      const wasDown = this.prevGamepadButtons[btnIndex] || false;
      this.prevGamepadButtons[btnIndex] = isDown;
      return isDown && !wasDown;
    };

    // Button 0 (A / X on PlayStation): Jump
    // Button 1 (B / Circle): Slide
    // Button 2 (X / Square): Hoverboard
    // Button 12 (D-Pad Up): Jump
    // Button 13 (D-Pad Down): Slide
    // Button 14 (D-Pad Left): Left
    // Button 15 (D-Pad Right): Right
    if (isJustPressed(0) || isJustPressed(12)) {
      actions.push('JUMP');
    }
    if (isJustPressed(1) || isJustPressed(13)) {
      actions.push('ROLL');
    }
    if (isJustPressed(2) || isJustPressed(3)) {
      actions.push('BOARD');
    }
    if (isJustPressed(14)) {
      actions.push('LEFT');
    }
    if (isJustPressed(15)) {
      actions.push('RIGHT');
    }

    // Left Analog Stick edge trigger
    const axisX = pad.axes[0] || 0;
    const axisY = pad.axes[1] || 0;
    const prevX = this.prevGamepadAxes[0] || 0;
    const prevY = this.prevGamepadAxes[1] || 0;

    const deadZone = 0.55;
    if (axisX < -deadZone && prevX >= -deadZone) {
      actions.push('LEFT');
    } else if (axisX > deadZone && prevX <= deadZone) {
      actions.push('RIGHT');
    }

    if (axisY < -deadZone && prevY >= -deadZone) {
      actions.push('JUMP');
    } else if (axisY > deadZone && prevY <= deadZone) {
      actions.push('ROLL');
    }

    this.prevGamepadAxes[0] = axisX;
    this.prevGamepadAxes[1] = axisY;

    return actions;
  }

  /**
   * Translates keyboard event code into player action
   */
  public handleKeyDown(code: string): PlayerAction | 'PAUSE' | null {
    // Primary custom mapping
    if (code === this.keyBindings.jump || code === 'ArrowUp' || code === 'KeyW' || code === 'Space') {
      return 'JUMP';
    }
    if (code === this.keyBindings.slide || code === 'ArrowDown' || code === 'KeyS') {
      return 'ROLL';
    }
    if (code === this.keyBindings.left || code === 'ArrowLeft' || code === 'KeyA') {
      return 'LEFT';
    }
    if (code === this.keyBindings.right || code === 'ArrowRight' || code === 'KeyD') {
      return 'RIGHT';
    }
    if (code === this.keyBindings.board || code === 'KeyE' || code === 'KeyB') {
      return 'BOARD';
    }
    if (code === this.keyBindings.pause || code === 'Escape' || code === 'KeyP') {
      return 'PAUSE';
    }
    return null;
  }

  // --- Touch Gesture Detection ---

  public handleTouchStart(e: React.TouchEvent | TouchEvent): PlayerAction | null {
    const touch = e.touches[0];
    this.touchStartX = touch.clientX;
    this.touchStartY = touch.clientY;
    this.touchStartTime = Date.now();

    // Double tap detection for hoverboard activation
    const now = Date.now();
    if (now - this.lastTapTime < 300) {
      this.lastTapTime = 0;
      return 'BOARD';
    }
    this.lastTapTime = now;
    return null;
  }

  public handleTouchEnd(e: React.TouchEvent | TouchEvent): PlayerAction | null {
    const touch = e.changedTouches[0];
    const dx = touch.clientX - this.touchStartX;
    const dy = touch.clientY - this.touchStartY;
    const dt = Date.now() - this.touchStartTime;

    const minSwipeDist = 28; // Responsive threshold
    const absX = Math.abs(dx);
    const absY = Math.abs(dy);

    if (dt < 650 && (absX > minSwipeDist || absY > minSwipeDist)) {
      if (absX > absY) {
        // Horizontal swipe
        // In RTL Arabic or standard phone layout:
        // Swiping right moves player to right lane, swiping left moves to left lane
        return dx > 0 ? 'RIGHT' : 'LEFT';
      } else {
        // Vertical swipe
        return dy < 0 ? 'JUMP' : 'ROLL';
      }
    }
    return null;
  }
}

export const controlsManager = new ControlsManager();
