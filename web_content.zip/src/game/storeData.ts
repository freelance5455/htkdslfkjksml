/**
 * Upgrades, Daily Missions, Achievements and Leaderboard data
 */

import { UpgradeItem, DailyMission, Achievement, LeaderboardEntry } from '../types/game';

export const STORE_UPGRADES: UpgradeItem[] = [
  {
    id: 'magnet_boost',
    name: 'مغناطيس العملات الخارق',
    level: 1,
    maxLevel: 6,
    baseCost: 350,
    description: 'زيادة مدة بقاء المغناطيس لجذب جميع العملات في المسارات المجاورة.',
    iconName: 'Magnet'
  },
  {
    id: 'multiplier_boost',
    name: 'مضاعف النقاط 2X',
    level: 1,
    maxLevel: 6,
    baseCost: 400,
    description: 'مضاعفة النقاط المكتسبة لتحطيم الأرقام القياسية والتصدر عالمياً.',
    iconName: 'Zap'
  },
  {
    id: 'sneakers_boost',
    name: 'حذاء القفز العالي',
    level: 1,
    maxLevel: 6,
    baseCost: 300,
    description: 'القفز فوق الحافلات والقطارات والشاحنات الكبيرة بسهولة بالغة.',
    iconName: 'Footprints'
  },
  {
    id: 'jetpack_boost',
    name: 'محرك النفاثة الفضائي',
    level: 1,
    maxLevel: 6,
    baseCost: 600,
    description: 'الطيران لارتفاعات شاهقة فوق كل العوائق وجمع خطوط الذهب الجوية.',
    iconName: 'Rocket'
  },
  {
    id: 'mom_buffer',
    name: 'مسافة الأمان من ماما',
    level: 1,
    maxLevel: 5,
    baseCost: 500,
    description: 'زيادة المسافة الابتدائية التي تبدأ بها ماما وراءك لمنحك رد فعل أفضل.',
    iconName: 'ShieldAlert'
  }
];

export const INITIAL_DAILY_MISSIONS: DailyMission[] = [
  {
    id: 'm1',
    title: 'اجمع 150 عملة ذهبية',
    target: 150,
    current: 0,
    rewardCoins: 300,
    rewardGems: 2,
    completed: false,
    claimed: false,
    type: 'coins'
  },
  {
    id: 'm2',
    title: 'اقطع مسافة 1200 متر في جولة واحدة',
    target: 1200,
    current: 0,
    rewardCoins: 500,
    rewardGems: 3,
    completed: false,
    claimed: false,
    type: 'distance'
  },
  {
    id: 'm3',
    title: 'اقفز 25 مرة فوق الحواجز',
    target: 25,
    current: 0,
    rewardCoins: 250,
    rewardGems: 1,
    completed: false,
    claimed: false,
    type: 'jump'
  },
  {
    id: 'm4',
    title: 'تزحلق 15 مرة لتفادي الإشارات العالية',
    target: 15,
    current: 0,
    rewardCoins: 250,
    rewardGems: 1,
    completed: false,
    claimed: false,
    type: 'slide'
  },
  {
    id: 'm5',
    title: 'استخدم الزلاجة مرتين في شوارع المدينة',
    target: 2,
    current: 0,
    rewardCoins: 400,
    rewardGems: 2,
    completed: false,
    claimed: false,
    type: 'hoverboard'
  }
];

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'ach_1',
    title: 'الهروب الأول',
    description: 'انجح في الركض لمسافة 500 متر دون أن تمسك بك ماما.',
    target: 500,
    current: 0,
    completed: false,
    rewardGems: 5,
    icon: 'Trophy'
  },
  {
    id: 'ach_2',
    title: 'جامع الذهب المحترف',
    description: 'اجمع 1,000 عملة إجمالية في جميع مغامراتك.',
    target: 1000,
    current: 0,
    completed: false,
    rewardGems: 10,
    icon: 'Coins'
  },
  {
    id: 'ach_3',
    title: 'ملك الزلاجات',
    description: 'ركوب الزلاجة 10 مرات في أوقات الخطر.',
    target: 10,
    current: 0,
    completed: false,
    rewardGems: 15,
    icon: 'Flame'
  },
  {
    id: 'ach_4',
    title: 'صائد النجوم',
    description: 'أكمل جميع مراحل اللعبة الأساسية بنجاح.',
    target: 5,
    current: 1,
    completed: false,
    rewardGems: 30,
    icon: 'Star'
  },
  {
    id: 'ach_5',
    title: 'أسطورة الـ 500 شخصية',
    description: 'افتح 10 شخصيات مختلفة من أبطال الـ 500.',
    target: 10,
    current: 2,
    completed: false,
    rewardGems: 25,
    icon: 'Users'
  }
];

export const GLOBAL_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, name: 'سلطان السرعة', score: 984500, country: 'السعودية', flag: '🇸🇦', avatarId: 5, date: 'اليوم' },
  { rank: 2, name: 'فهد التوربو', score: 875200, country: 'الإمارات', flag: '🇦🇪', avatarId: 3, date: 'اليوم' },
  { rank: 3, name: 'ياسمين الطائرة', score: 792100, country: 'مصر', flag: '🇪🇬', avatarId: 4, date: 'أمس' },
  { rank: 4, name: 'كريم المغربي', score: 710400, country: 'المغرب', flag: '🇲🇦', avatarId: 1, date: 'اليوم' },
  { rank: 5, name: 'ريان الهروب', score: 689000, country: 'الجزائر', flag: '🇩🇿', avatarId: 2, date: 'منذ يومين' },
  { rank: 6, name: 'حمزة الكويتي', score: 620500, country: 'الكويت', flag: '🇰🇼', avatarId: 7, date: 'اليوم' },
  { rank: 7, name: 'ليلى الأردنية', score: 580300, country: 'الأردن', flag: '🇯🇴', avatarId: 6, date: 'اليوم' },
  { rank: 8, name: 'سامي العراقي', score: 512000, country: 'العراق', flag: '🇮🇶', avatarId: 8, date: 'أمس' },
  { rank: 9, name: 'طارق التونسي', score: 476800, country: 'تونس', flag: '🇹🇳', avatarId: 9, date: 'منذ 3 أيام' },
  { rank: 10, name: 'مريم العمانية', score: 442100, country: 'عمان', flag: '🇴🇲', avatarId: 2, date: 'اليوم' }
];
