import type { SoundCue } from "./MiniFootGame";

export class GameSound {
  private context: AudioContext | null = null;
  private enabled = true;

  setEnabled(enabled: boolean) {
    this.enabled = enabled;
  }

  play(cue: SoundCue) {
    if (!this.enabled || typeof window === "undefined" || !window.AudioContext) return;

    try {
      if (!this.context) this.context = new AudioContext();
      if (this.context.state === "suspended") void this.context.resume().catch(() => undefined);

      switch (cue) {
        case "start":
          this.tone(350, 440, 0.12, 0.045, "square");
          this.tone(520, 660, 0.15, 0.045, "square", 0.11);
          this.tone(700, 880, 0.2, 0.04, "triangle", 0.22);
          break;
        case "kick":
          this.tone(175, 62, 0.15, 0.15, "sine");
          this.tone(900, 250, 0.06, 0.035, "triangle");
          break;
        case "miss":
          this.tone(330, 185, 0.09, 0.025, "triangle");
          break;
        case "bounce":
          this.tone(210, 125, 0.055, 0.026, "sine");
          break;
        case "rival":
          this.tone(145, 75, 0.13, 0.075, "sine");
          this.tone(470, 200, 0.06, 0.018, "triangle");
          break;
        case "goal":
          this.tone(110, 58, 0.23, 0.15, "sine");
          [392, 494, 587, 784].forEach((note, index) => {
            this.tone(note, note * 1.01, 0.3, 0.055, "triangle", index * 0.085);
          });
          this.tone(1175, 1180, 0.42, 0.025, "sine", 0.32);
          break;
        case "concede":
          this.tone(330, 240, 0.2, 0.055, "triangle");
          this.tone(247, 150, 0.27, 0.05, "triangle", 0.15);
          break;
        case "end":
          this.tone(587, 587, 0.16, 0.055, "triangle");
          this.tone(440, 420, 0.38, 0.055, "triangle", 0.19);
          break;
      }
    } catch {
      // The game stays playable if a browser blocks audio output.
    }
  }

  private tone(
    from: number,
    to: number,
    duration: number,
    volume: number,
    type: OscillatorType,
    delay = 0,
  ) {
    if (!this.context) return;
    const now = this.context.currentTime + delay;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(from, now);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(1, to), now + duration);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(volume, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    oscillator.connect(gain);
    gain.connect(this.context.destination);
    oscillator.start(now);
    oscillator.stop(now + duration + 0.015);
  }
}