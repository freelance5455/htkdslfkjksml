import { useEffect, useMemo, useRef, useState, type PointerEvent as PE, type ReactNode } from "react";
import { ArrowLeft, Pause, Play, Settings as SettingsIcon, Volume2, VolumeX } from "lucide-react";
import { GameEngine } from "./engine";
import { TEAMS, otherTeam, teamById, type TeamDef } from "./teams";
import {
  applyUserResult,
  clearCareer,
  defaultSettings,
  loadCareer,
  loadSettings,
  newCareer,
  nextUserFixture,
  saveCareer,
  saveSettings,
  standings,
  type Career,
  type Difficulty,
  type Settings,
} from "./save";

type Screen = "boot" | "menu" | "kickoff" | "career" | "career-pick" | "settings" | "match" | "result";

function KitBadge({ team, size = 44 }: { team: TeamDef; size?: number }) {
  const stripe = team.pattern === "stripe";
  return (
    <span
      className="relative inline-flex shrink-0 items-center justify-center overflow-hidden rounded-lg border border-border"
      style={{ width: size, height: size, background: team.primary }}
      aria-hidden
    >
      {stripe ? (
        <span className="absolute inset-y-0 left-1/3 w-1/3" style={{ background: team.secondary }} />
      ) : team.pattern === "sash" ? (
        <span className="absolute h-[140%] w-2 -rotate-45" style={{ background: team.secondary }} />
      ) : team.pattern === "hoop" ? (
        <span className="absolute inset-x-0 top-1/3 h-1/4" style={{ background: team.secondary }} />
      ) : null}
      <span
        className="relative text-[10px] font-semibold tracking-wide"
        style={{ color: team.shorts === team.primary ? team.secondary : "#0b0c0e" }}
      >
        {team.short}
      </span>
    </span>
  );
}

function TouchStick({ onChange }: { onChange: (x: number, y: number) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const pid = useRef<number | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });

  const update = (e: PE<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    let dx = e.clientX - cx;
    let dy = e.clientY - cy;
    const max = r.width * 0.38;
    const m = Math.hypot(dx, dy);
    if (m > max) {
      dx = (dx / m) * max;
      dy = (dy / m) * max;
    }
    setKnob({ x: dx, y: dy });
    onChange(dx / max, dy / max);
  };

  return (
    <div
      ref={ref}
      className="relative h-28 w-28 touch-none rounded-full border border-border bg-surface/70"
      onPointerDown={(e) => {
        pid.current = e.pointerId;
        e.currentTarget.setPointerCapture(e.pointerId);
        update(e);
      }}
      onPointerMove={(e) => {
        if (pid.current !== e.pointerId) return;
        update(e);
      }}
      onPointerUp={(e) => {
        if (pid.current !== e.pointerId) return;
        pid.current = null;
        setKnob({ x: 0, y: 0 });
        onChange(0, 0);
      }}
      onPointerCancel={() => {
        pid.current = null;
        setKnob({ x: 0, y: 0 });
        onChange(0, 0);
      }}
    >
      <span
        className="pointer-events-none absolute left-1/2 top-1/2 h-12 w-12 rounded-full bg-fg/80"
        style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
      />
    </div>
  );
}

function ActionBtn({
  label,
  onDown,
  onUp,
  accent,
}: {
  label: string;
  onDown: () => void;
  onUp?: () => void;
  accent?: boolean;
}) {
  return (
    <button
      type="button"
      className={`h-14 min-w-14 touch-none rounded-full border px-3 text-center text-xs font-semibold uppercase tracking-wide ${
        accent ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface/80 text-fg"
      }`}
      onPointerDown={(e) => {
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        onDown();
      }}
      onPointerUp={() => onUp?.()}
      onPointerCancel={() => onUp?.()}
    >
      {label}
    </button>
  );
}

export function GameRoot() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [screen, setScreen] = useState<Screen>("boot");
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [career, setCareer] = useState<Career | null>(null);
  const [homeId, setHomeId] = useState(TEAMS[0]!.id);
  const [awayId, setAwayId] = useState(TEAMS[1]!.id);
  const [paused, setPaused] = useState(false);
  const [result, setResult] = useState<{ home: TeamDef; away: TeamDef; score: [number, number] } | null>(null);
  const [userHome, setUserHome] = useState(true);
  const fromCareerRef = useRef(false);
  const [ready, setReady] = useState(false);

  const home = teamById(homeId);
  const away = teamById(awayId);

  useEffect(() => {
    setSettings(loadSettings());
    setCareer(loadCareer());
    setReady(true);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const a = TEAMS[0]!;
    const b = TEAMS[3]!;
    const eng = new GameEngine(canvas, a, b);
    engineRef.current = eng;
    eng.startDemo(a, otherTeam(a.id));
    eng.shakeOn = settings.shake;
    eng.onPauseChange = (v) => setPaused(v);
    eng.onEnded = (m) => {
      setResult({ home: m.home, away: m.away, score: [m.score[0], m.score[1]] });
      setScreen("result");
    };
    eng.attach();
    return () => eng.detach();
    // settings.shake is applied in the settings effect
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!ready) return;
    saveSettings(settings);
    const eng = engineRef.current;
    if (!eng) return;
    eng.audio.setMuted(settings.muted);
    eng.audio.setVolume(settings.volume);
    eng.shakeOn = settings.shake;
  }, [settings, ready]);

  const unlock = () => {
    engineRef.current?.audio.unlock();
    engineRef.current?.audio.setMuted(settings.muted);
    engineRef.current?.audio.setVolume(settings.volume);
    setScreen("menu");
  };

  const playMatch = (
    h: TeamDef,
    a: TeamDef,
    opts: { userTeam: 0 | 1; practice?: boolean; fromCareer?: boolean },
  ) => {
    const eng = engineRef.current;
    if (!eng) return;
    eng.audio.ui();
    fromCareerRef.current = !!opts.fromCareer;
    eng.startLive(h, a, {
      userTeam: opts.userTeam,
      difficulty: settings.difficulty,
      practice: opts.practice,
      autoSwitch: settings.autoSwitch,
    });
    setUserHome(opts.userTeam === 0);
    setPaused(false);
    setScreen("match");
    setResult(null);
  };

  const backToMenu = () => {
    const eng = engineRef.current;
    if (!eng) return;
    eng.audio.ui();
    fromCareerRef.current = false;
    eng.startDemo(teamById(homeId), teamById(awayId));
    eng.paused = false;
    setPaused(false);
    setScreen("menu");
  };

  const finishCareerMatch = () => {
    if (!result || !career) {
      backToMenu();
      return;
    }
    const next = applyUserResult(career, result.score[0], result.score[1]);
    setCareer(next);
    saveCareer(next);
    fromCareerRef.current = false;
    setScreen("career");
    engineRef.current?.startDemo(teamById(next.teamId), otherTeam(next.teamId));
  };

  const table = useMemo(() => (career ? standings(career) : []), [career]);
  const nextFx = career ? nextUserFixture(career) : null;
  const live = engineRef.current?.match;
  const fromCareer = fromCareerRef.current;

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />

      {screen === "boot" && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-bg/80 px-6">
          <p className="text-xs font-medium uppercase tracking-[0.35em] text-muted">Football Club</p>
          <h1 className="mt-3 font-display text-6xl font-semibold tracking-tight text-fg md:text-7xl">
            FC <span className="text-primary">28</span>
          </h1>
          <button
            type="button"
            onClick={unlock}
            className="mt-10 min-h-12 rounded-xl bg-fg px-8 text-sm font-semibold tracking-wide text-bg"
          >
            Tap to play
          </button>
          <p className="mt-6 max-w-xs text-center text-xs leading-relaxed text-faint">
            Runs entirely on this device. No internet, no extra pages.
          </p>
        </div>
      )}

      {screen === "menu" && (
        <div className="absolute inset-0 z-10 flex flex-col justify-end bg-gradient-to-t from-bg via-bg/80 to-transparent p-5 pb-8 md:justify-center md:bg-none md:p-10">
          <div className="md:max-w-sm">
            <p className="text-xs font-medium uppercase tracking-[0.35em] text-muted">Football Club</p>
            <h1 className="mt-2 font-display text-5xl font-semibold tracking-tight">
              FC <span className="text-primary">28</span>
            </h1>
            <nav className="mt-8 flex flex-col gap-2">
              <MenuBtn label="Kick Off" hint="Pick sides and play" onClick={() => setScreen("kickoff")} />
              <MenuBtn
                label="Career"
                hint="Season with your club"
                onClick={() => setScreen(career ? "career" : "career-pick")}
              />
              <MenuBtn
                label="Practice"
                hint="Free play, no clock"
                onClick={() => playMatch(home, away, { userTeam: 0, practice: true })}
              />
              <MenuBtn
                label="Settings"
                hint="Audio, difficulty, camera"
                onClick={() => setScreen("settings")}
                icon={<SettingsIcon className="size-4" />}
              />
            </nav>
          </div>
        </div>
      )}

      {screen === "kickoff" && (
        <Panel title="Kick Off" onBack={() => setScreen("menu")}>
          <div className="grid gap-6 md:grid-cols-2">
            <TeamPicker label="You" selected={homeId} onPick={setHomeId} />
            <TeamPicker label="Opponent" selected={awayId} onPick={setAwayId} />
          </div>
          <button
            type="button"
            className="mt-6 min-h-12 w-full rounded-xl bg-fg text-sm font-semibold text-bg"
            onClick={() => playMatch(home, away, { userTeam: 0 })}
          >
            Enter match
          </button>
        </Panel>
      )}

      {screen === "career-pick" && (
        <Panel title="Choose club" onBack={() => setScreen("menu")}>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {TEAMS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  const c = newCareer(t.id);
                  setCareer(c);
                  saveCareer(c);
                  setHomeId(t.id);
                  setScreen("career");
                }}
                className="flex min-h-16 items-center gap-3 rounded-xl border border-border bg-surface-2 px-3 text-left"
              >
                <KitBadge team={t} />
                <span>
                  <span className="block text-sm font-medium">{t.name}</span>
                  <span className="text-xs text-muted">{t.rating} OVR</span>
                </span>
              </button>
            ))}
          </div>
        </Panel>
      )}

      {screen === "career" && career && (
        <Panel title="Career" onBack={() => setScreen("menu")}>
          <div className="mb-4 flex items-center gap-3">
            <KitBadge team={teamById(career.teamId)} size={52} />
            <div>
              <p className="text-lg font-semibold">{teamById(career.teamId).name}</p>
              <p className="text-xs text-muted">
                Week {Math.min(career.week + 1, 11)} · {table.find((r) => r.id === career.teamId)?.pts ?? 0} pts
              </p>
            </div>
          </div>
          {nextFx ? (
            <div className="rounded-xl border border-border bg-surface-2 p-4">
              <p className="text-xs uppercase tracking-wide text-muted">Next match</p>
              <p className="mt-1 text-base font-medium">
                {teamById(nextFx.homeId).short} vs {teamById(nextFx.awayId).short}
              </p>
              <button
                type="button"
                className="mt-4 min-h-12 w-full rounded-xl bg-fg text-sm font-semibold text-bg"
                onClick={() => {
                  const uh = nextFx.homeId === career.teamId ? 0 : 1;
                  playMatch(teamById(nextFx.homeId), teamById(nextFx.awayId), {
                    userTeam: uh as 0 | 1,
                    fromCareer: true,
                  });
                }}
              >
                Play match
              </button>
            </div>
          ) : (
            <p className="rounded-xl border border-border bg-surface-2 p-4 text-sm text-muted">Season complete.</p>
          )}
          <div className="mt-4 overflow-hidden rounded-xl border border-border">
            <table className="w-full text-left text-sm">
              <thead className="bg-surface-2 text-xs uppercase tracking-wide text-muted">
                <tr>
                  <th className="px-3 py-2 font-medium">Club</th>
                  <th className="px-2 py-2 font-medium">P</th>
                  <th className="px-2 py-2 font-medium">GD</th>
                  <th className="px-3 py-2 font-medium">Pts</th>
                </tr>
              </thead>
              <tbody>
                {table.map((row, i) => (
                  <tr key={row.id} className={row.id === career.teamId ? "bg-primary/15 text-fg" : "text-muted"}>
                    <td className="px-3 py-1.5">
                      {i + 1}. {row.team.short}
                    </td>
                    <td className="px-2 py-1.5 tabular-nums">{row.p}</td>
                    <td className="px-2 py-1.5 tabular-nums">{row.gd}</td>
                    <td className="px-3 py-1.5 font-medium tabular-nums text-fg">{row.pts}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <button
            type="button"
            className="mt-4 text-xs text-muted underline-offset-4 hover:text-fg"
            onClick={() => {
              clearCareer();
              setCareer(null);
              setScreen("career-pick");
            }}
          >
            New career
          </button>
        </Panel>
      )}

      {screen === "settings" && (
        <Panel title="Settings" onBack={() => setScreen("menu")}>
          <label className="flex items-center justify-between gap-4 py-3">
            <span className="text-sm">Audio</span>
            <button
              type="button"
              className="rounded-lg border border-border bg-surface-2 p-2"
              onClick={() => setSettings((s) => ({ ...s, muted: !s.muted }))}
              aria-label={settings.muted ? "Unmute" : "Mute"}
            >
              {settings.muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
            </button>
          </label>
          <label className="flex items-center justify-between gap-4 py-3">
            <span className="text-sm">Volume</span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={settings.volume}
              onChange={(e) => setSettings((s) => ({ ...s, volume: Number(e.target.value) }))}
              className="w-40 accent-primary"
            />
          </label>
          <label className="flex items-center justify-between gap-4 py-3">
            <span className="text-sm">Screen shake</span>
            <Toggle on={settings.shake} onChange={(v) => setSettings((s) => ({ ...s, shake: v }))} />
          </label>
          <label className="flex items-center justify-between gap-4 py-3">
            <span className="text-sm">Auto switch</span>
            <Toggle on={settings.autoSwitch} onChange={(v) => setSettings((s) => ({ ...s, autoSwitch: v }))} />
          </label>
          <div className="py-3">
            <p className="mb-2 text-sm">Difficulty</p>
            <div className="grid grid-cols-3 gap-2">
              {(["amateur", "pro", "world"] as Difficulty[]).map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setSettings((s) => ({ ...s, difficulty: d }))}
                  className={`min-h-11 rounded-lg border text-xs font-medium capitalize ${
                    settings.difficulty === d ? "border-fg bg-fg text-bg" : "border-border bg-surface-2 text-fg"
                  }`}
                >
                  {d === "world" ? "World class" : d}
                </button>
              ))}
            </div>
          </div>
          <p className="mt-4 text-xs leading-relaxed text-faint">
            Move WASD or stick · Sprint Shift · Pass Space/J · Through K · Shoot hold L · Switch E · Tackle Ctrl
          </p>
        </Panel>
      )}

      {screen === "match" && (
        <>
          <button
            type="button"
            className="absolute right-3 top-3 z-10 flex size-11 items-center justify-center rounded-xl border border-border bg-surface/80 text-fg"
            onClick={() => {
              const eng = engineRef.current;
              if (eng) {
                eng.paused = true;
                setPaused(true);
              }
            }}
            aria-label="Pause"
          >
            <Pause className="size-4" />
          </button>
          <div className="pointer-events-none absolute bottom-3 left-0 right-0 z-10 hidden px-4 text-center text-[11px] text-muted md:block">
            WASD move · Shift sprint · J pass · K through · Hold L shoot · E switch · Ctrl tackle
          </div>
          <div className="absolute inset-x-0 bottom-4 z-10 flex items-end justify-between px-4 md:hidden">
            <TouchStick
              onChange={(x, y) => {
                const eng = engineRef.current;
                if (!eng) return;
                eng.input.stickX = x;
                eng.input.stickY = y;
              }}
            />
            <div className="grid grid-cols-3 gap-2">
              <ActionBtn
                label="Spr"
                onDown={() => {
                  if (engineRef.current) engineRef.current.input.touch.sprint = true;
                }}
                onUp={() => {
                  if (engineRef.current) engineRef.current.input.touch.sprint = false;
                }}
              />
              <ActionBtn
                label="Sw"
                onDown={() => {
                  if (engineRef.current) engineRef.current.input.touch.switchP = true;
                }}
                onUp={() => {
                  if (engineRef.current) engineRef.current.input.touch.switchP = false;
                }}
              />
              <ActionBtn
                label="Tkl"
                onDown={() => {
                  if (engineRef.current) engineRef.current.input.touch.tackle = true;
                }}
                onUp={() => {
                  if (engineRef.current) engineRef.current.input.touch.tackle = false;
                }}
              />
              <ActionBtn
                label="Thru"
                onDown={() => {
                  if (engineRef.current) engineRef.current.input.touch.through = true;
                }}
                onUp={() => {
                  if (engineRef.current) engineRef.current.input.touch.through = false;
                }}
              />
              <ActionBtn
                label="Pass"
                onDown={() => {
                  if (engineRef.current) engineRef.current.input.touch.pass = true;
                }}
                onUp={() => {
                  if (engineRef.current) engineRef.current.input.touch.pass = false;
                }}
              />
              <ActionBtn
                label="Shot"
                accent
                onDown={() => {
                  if (engineRef.current) engineRef.current.input.touch.shoot = true;
                }}
                onUp={() => {
                  if (engineRef.current) engineRef.current.input.touch.shoot = false;
                }}
              />
            </div>
          </div>
          {paused && (
            <div className="absolute inset-0 z-20 flex items-center justify-center bg-bg/70 p-6">
              <div className="w-full max-w-sm rounded-3xl border border-border bg-surface p-6">
                <h2 className="text-xl font-semibold">Paused</h2>
                <p className="mt-1 text-sm text-muted">
                  {live ? `${live.home.short} ${live.score[0]} – ${live.score[1]} ${live.away.short}` : ""}
                </p>
                <div className="mt-6 flex flex-col gap-2">
                  <button
                    type="button"
                    className="min-h-12 rounded-xl bg-fg text-sm font-semibold text-bg"
                    onClick={() => {
                      if (engineRef.current) engineRef.current.paused = false;
                      setPaused(false);
                    }}
                  >
                    Resume
                  </button>
                  <button
                    type="button"
                    className="min-h-12 rounded-xl border border-border text-sm font-medium"
                    onClick={backToMenu}
                  >
                    Quit to menu
                  </button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {screen === "result" && result && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-bg/75 p-6">
          <div className="w-full max-w-md rounded-3xl border border-border bg-surface p-6">
            <p className="text-xs uppercase tracking-[0.25em] text-muted">Full time</p>
            <div className="mt-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <KitBadge team={result.home} />
                <span className="text-sm font-medium">{result.home.short}</span>
              </div>
              <p className="font-display text-3xl font-semibold tabular-nums">
                {result.score[0]} – {result.score[1]}
              </p>
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">{result.away.short}</span>
                <KitBadge team={result.away} />
              </div>
            </div>
            <p className="mt-3 text-center text-sm text-muted">
              {(() => {
                const you = userHome ? result.score[0] : result.score[1];
                const them = userHome ? result.score[1] : result.score[0];
                if (you > them) return "Win";
                if (you < them) return "Defeat";
                return "Draw";
              })()}
            </p>
            <div className="mt-6 flex flex-col gap-2">
              {fromCareer && career ? (
                <button
                  type="button"
                  className="min-h-12 rounded-xl bg-fg text-sm font-semibold text-bg"
                  onClick={finishCareerMatch}
                >
                  Save to career
                </button>
              ) : (
                <button
                  type="button"
                  className="min-h-12 rounded-xl bg-fg text-sm font-semibold text-bg"
                  onClick={backToMenu}
                >
                  Menu
                </button>
              )}
              <button
                type="button"
                className="min-h-12 rounded-xl border border-border text-sm font-medium"
                onClick={() =>
                  playMatch(result.home, result.away, { userTeam: userHome ? 0 : 1, fromCareer })
                }
              >
                Replay
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function MenuBtn({
  label,
  hint,
  onClick,
  icon,
}: {
  label: string;
  hint: string;
  onClick: () => void;
  icon?: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex min-h-14 items-center justify-between rounded-2xl border border-border bg-surface/85 px-4 text-left"
    >
      <span>
        <span className="block text-sm font-semibold">{label}</span>
        <span className="text-xs text-muted">{hint}</span>
      </span>
      {icon ?? <Play className="size-4 text-muted" />}
    </button>
  );
}

function Panel({
  title,
  onBack,
  children,
}: {
  title: string;
  onBack: () => void;
  children: ReactNode;
}) {
  return (
    <div className="absolute inset-0 z-10 overflow-y-auto bg-bg/92 p-4 md:p-8">
      <div className="mx-auto max-w-3xl pb-10">
        <div className="mb-6 flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            className="flex size-11 items-center justify-center rounded-xl border border-border bg-surface"
            aria-label="Back"
          >
            <ArrowLeft className="size-4" />
          </button>
          <h2 className="text-xl font-semibold">{title}</h2>
        </div>
        {children}
      </div>
    </div>
  );
}

function TeamPicker({
  label,
  selected,
  onPick,
}: {
  label: string;
  selected: string;
  onPick: (id: string) => void;
}) {
  return (
    <div>
      <p className="mb-2 text-xs uppercase tracking-wide text-muted">{label}</p>
      <div className="grid max-h-72 grid-cols-1 gap-1 overflow-y-auto pr-1">
        {TEAMS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => onPick(t.id)}
            className={`flex min-h-12 items-center gap-3 rounded-xl border px-3 text-left ${
              selected === t.id ? "border-fg bg-fg text-bg" : "border-border bg-surface-2"
            }`}
          >
            <KitBadge team={t} size={36} />
            <span className="flex-1 text-sm font-medium">{t.name}</span>
            <span className="text-xs tabular-nums opacity-70">{t.rating}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={() => onChange(!on)}
      className={`h-7 w-12 rounded-full border border-border p-0.5 ${on ? "bg-primary" : "bg-surface-2"}`}
    >
      <span className={`block size-6 rounded-full bg-fg transition-transform ${on ? "translate-x-5" : ""}`} />
    </button>
  );
}
