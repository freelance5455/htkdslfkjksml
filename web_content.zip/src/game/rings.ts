import * as THREE from 'three'
import { CONFIG } from './config'
import { groundHeight } from './terrain'

/**
 * Endless chain of rings to fly through. Each new ring is placed ahead of the previous one by testing
 * several headings and picking one whose straight leg clears the terrain and respects a gentle
 * climb/descent slope, so every ring is reachable without an impossible manoeuvre.
 */
export type RingSpec = {
  pos: THREE.Vector3
  /** Unit direction of travel through the ring (ring normal). */
  dir: THREE.Vector3
  index: number
  mesh: THREE.Group
}

export type RingEvent =
  | { type: 'pass'; centering: number; ring: RingSpec }
  | { type: 'miss'; ring: RingSpec }

const CLEARANCE = 85
const ANGLES = [0, 10, -10, 20, -20, 32, -32, 45, -45, 60, -60]
const GOLD = new THREE.Color(0xf6b40e)
const CELESTE = new THREE.Color(0x74acdf)

function rand(index: number, salt: number): number {
  const s = Math.sin(index * 127.1 + salt * 311.7) * 43758.5453
  return s - Math.floor(s)
}

type Visual = { group: THREE.Group; ring: THREE.Mesh; halo: THREE.Mesh }

function makeVisual(): Visual {
  const R = CONFIG.rings.radius
  const group = new THREE.Group()
  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(R, 2.6, 12, 56),
    new THREE.MeshBasicMaterial({ color: GOLD, transparent: true, opacity: 1, fog: false }),
  )
  const halo = new THREE.Mesh(
    new THREE.TorusGeometry(R, 6.5, 8, 56),
    new THREE.MeshBasicMaterial({ color: GOLD, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }),
  )
  group.add(ring, halo)
  // Four marker pylons make the ring readable from far away and from the side.
  for (let i = 0; i < 4; i += 1) {
    const a = (i * Math.PI) / 2
    const tick = new THREE.Mesh(new THREE.BoxGeometry(2.2, 14, 2.2), new THREE.MeshBasicMaterial({ color: 0xffffff, fog: false }))
    tick.position.set(Math.cos(a) * (R + 9), Math.sin(a) * (R + 9), 0)
    tick.rotation.z = a
    tick.scale.set(1, 1, 1)
    group.add(tick)
  }
  return { group, ring, halo }
}

export class RingCourse {
  readonly group = new THREE.Group()
  private readonly visuals: Visual[] = []
  private specs: RingSpec[] = []
  private counter = 0
  private readonly heading = new THREE.Vector3(-1, 0, 0)
  private readonly tmpA = new THREE.Vector3()
  private readonly tmpB = new THREE.Vector3()

  constructor(private readonly live = 3) {
    for (let i = 0; i < live; i += 1) {
      const v = makeVisual()
      this.visuals.push(v)
      this.group.add(v.group)
    }
  }

  get current(): RingSpec | undefined {
    return this.specs[0]
  }

  reset(start: THREE.Vector3, heading: THREE.Vector3): void {
    this.counter = 0
    this.specs = []
    this.heading.set(heading.x, 0, heading.z).normalize()
    let prev = { pos: start.clone(), dir: this.heading.clone() }
    for (let i = 0; i < this.live; i += 1) {
      const spec = this.generate(prev.pos, prev.dir, i === 0 ? CONFIG.rings.spacing * 1.15 : CONFIG.rings.spacing, this.visuals[i].group)
      this.specs.push(spec)
      prev = spec
    }
    this.restyle()
  }

  /** Test the segment prev→cur against the active ring. */
  check(prev: THREE.Vector3, cur: THREE.Vector3): RingEvent | null {
    const ring = this.specs[0]
    if (!ring) return null
    const d0 = this.tmpA.copy(prev).sub(ring.pos).dot(ring.dir)
    const d1 = this.tmpB.copy(cur).sub(ring.pos).dot(ring.dir)
    if (d0 < 0 && d1 >= 0) {
      const t = d0 / (d0 - d1)
      const hit = this.tmpA.copy(prev).lerp(cur, t)
      const dist = hit.distanceTo(ring.pos)
      const R = CONFIG.rings.radius
      if (dist <= R + 4) {
        this.advance()
        return { type: 'pass', centering: Math.max(0, Math.min(1, 1 - dist / R)), ring }
      }
      this.advance()
      return { type: 'miss', ring }
    }
    if (d1 > 450) {
      this.advance()
      return { type: 'miss', ring }
    }
    return null
  }

  update(time: number): void {
    const pulse = 1 + Math.sin(time * 4) * 0.035
    const head = this.specs[0]
    if (head) head.mesh.scale.setScalar(pulse)
    for (let i = 1; i < this.specs.length; i += 1) this.specs[i].mesh.scale.setScalar(1)
  }

  private advance(): void {
    const done = this.specs.shift()!
    const last = this.specs[this.specs.length - 1]
    const next = this.generate(last.pos, last.dir, CONFIG.rings.spacing, done.mesh)
    this.specs.push(next)
    this.restyle()
  }

  private restyle(): void {
    this.specs.forEach((spec, slot) => {
      const v = this.visuals.find(x => x.group === spec.mesh)!
      const active = slot === 0
      const color = active ? GOLD : CELESTE
      ;(v.ring.material as THREE.MeshBasicMaterial).color.copy(color)
      ;(v.ring.material as THREE.MeshBasicMaterial).opacity = active ? 1 : slot === 1 ? 0.7 : 0.35
      ;(v.halo.material as THREE.MeshBasicMaterial).color.copy(color)
      ;(v.halo.material as THREE.MeshBasicMaterial).opacity = active ? 0.3 : 0.1
    })
  }

  /** Choose the next ring after (`from`, heading `dirH`), place `mesh` there and return its spec. */
  private generate(from: THREE.Vector3, dirH: THREE.Vector3, spacing: number, mesh: THREE.Group): RingSpec {
    const index = this.counter
    this.counter += 1
    const dist = spacing * (0.92 + rand(index, 1) * 0.2)
    const h0 = Math.atan2(dirH.x, dirH.z)
    const fromAlt = from.y

    let best: { cost: number; end: THREE.Vector3 } | null = null
    for (const deg of ANGLES) {
      const a = h0 + (deg * Math.PI) / 180
      const dx = Math.sin(a)
      const dz = Math.cos(a)
      let required = -Infinity
      const samples = 16
      for (let i = 1; i <= samples; i += 1) {
        const t = i / samples
        const x = from.x + dx * dist * t
        const z = from.z + dz * dist * t
        let g = groundHeight(x, z)
        // Wide wings and camera lag: also check either side of the leg.
        g = Math.max(g, groundHeight(x + dz * 40, z - dx * 40), groundHeight(x - dz * 40, z + dx * 40))
        // altitude at t along the straight leg must clear g + CLEARANCE
        required = Math.max(required, fromAlt + (g + CLEARANCE - fromAlt) / t)
      }
      const endX = from.x + dx * dist
      const endZ = from.z + dz * dist
      const groundEnd = groundHeight(endX, endZ)
      let alt = Math.max(required, groundEnd + 105 + rand(index, 2) * 70, fromAlt - dist * 0.24)
      alt = Math.min(alt, CONFIG.flight.ceiling - 150)
      const climb = alt - fromAlt
      const maxClimb = dist * 0.3
      const penalty = climb > maxClimb ? (climb - maxClimb) * 5 : 0
      let cost = penalty + Math.abs(deg) * 1.3 + (alt - groundEnd) * 0.05
      // Lead the player towards the mountains first.
      if (from.x > -3300) cost -= -dx * 28
      if (!best || cost < best.cost) best = { cost, end: new THREE.Vector3(endX, alt, endZ) }
    }
    const end = best!.end
    const dir = end.clone().sub(from).normalize()
    mesh.position.copy(end)
    mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir)
    mesh.scale.setScalar(1)
    return { pos: end, dir, index, mesh }
  }
}
