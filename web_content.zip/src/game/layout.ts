import { BOARD_PAD, CELL, CELL_GAP, DESIGN_H, DESIGN_W, GRID } from './constants';

export interface Layout {
  W: number;
  H: number;
  /** Design-unit multiplier (device px per design px). */
  u: number;
  dpr: number;
  safeTop: number;
  safeBottom: number;
  cell: number;
  gap: number;
  block: number;
  gridX: number;
  gridY: number;
  gridSize: number;
  boardX: number;
  boardY: number;
  boardSize: number;
  boardPad: number;
  hudY: number;
  trayY: number;
  trayH: number;
  slotW: number;
}

export interface SafeArea {
  top: number;
  bottom: number;
}

export function computeLayout(W: number, H: number, dpr: number, safe: SafeArea): Layout {
  const u = Math.min(W / DESIGN_W, H / DESIGN_H);
  const safeTop = safe.top * dpr;
  const safeBottom = safe.bottom * dpr;

  const cell = CELL * u;
  const gap = CELL_GAP * u;
  const block = cell - gap;
  const boardPad = BOARD_PAD * u;
  const gridSize = cell * GRID;
  const boardSize = gridSize - gap + boardPad * 2;

  const hudH = 150 * u;
  const trayH = 230 * u;
  const topPad = 18 * u + safeTop;
  const bottomPad = 22 * u + safeBottom;
  const content = hudH + boardSize + trayH;
  const slack = Math.max(0, H - topPad - bottomPad - content);

  const hudY = topPad + hudH / 2;
  const boardY = topPad + hudH + slack * 0.2;
  const boardX = (W - boardSize) / 2;
  const trayY = boardY + boardSize + slack * 0.36 + trayH / 2;

  return {
    W,
    H,
    u,
    dpr,
    safeTop,
    safeBottom,
    cell,
    gap,
    block,
    gridX: boardX + boardPad - gap / 2,
    gridY: boardY + boardPad - gap / 2,
    gridSize,
    boardX,
    boardY,
    boardSize,
    boardPad,
    hudY,
    trayY,
    trayH,
    slotW: boardSize / 3,
  };
}
