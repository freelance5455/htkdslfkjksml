export const ISLAND_R = 37;

export type Block = {
  x: number;
  z: number;
  hw: number;
  hd: number;
  h: number;
  wall: string;
  roof: string;
  crate?: boolean;
};

export const BUILDINGS: Block[] = [
  { x: -16, z: -8, hw: 5.2, hd: 4.2, h: 6.2, wall: "#ffc857", roof: "#e07a3d" },
  { x: 15, z: -15, hw: 6.2, hd: 4.4, h: 4.6, wall: "#2ec4b6", roof: "#146870" },
  { x: 12, z: 13, hw: 4.6, hd: 5.4, h: 5.4, wall: "#ff6b6b", roof: "#c43b4a" },
  { x: -15, z: 13, hw: 6.4, hd: 4.2, h: 4.2, wall: "#7c6bf0", roof: "#3d348b" },
  { x: 0, z: -20, hw: 3.3, hd: 3.3, h: 12, wall: "#ff8c42", roof: "#ffd166" },
  { x: 22, z: 1, hw: 3.4, hd: 3.6, h: 3.4, wall: "#7dce6a", roof: "#2f7a38" },
  { x: -4, z: 1, hw: 2.6, hd: 2.6, h: 3.1, wall: "#f4e1c1", roof: "#c4894f" },
  { x: 6, z: -6, hw: 2.2, hd: 2.4, h: 2.6, wall: "#f2d0a9", roof: "#bc6c25" },
];

export const CRATES: Block[] = [
  { x: 3.2, z: 7.2, hw: 0.7, hd: 0.7, h: 1.15, wall: "#c9854a", roof: "#a86b32", crate: true },
  { x: 4.6, z: 7.4, hw: 0.55, hd: 0.55, h: 0.9, wall: "#b87333", roof: "#8c5a2b", crate: true },
  { x: 3.6, z: 8.6, hw: 0.5, hd: 0.5, h: 0.85, wall: "#d8a15d", roof: "#a86b32", crate: true },
  { x: -8, z: -16, hw: 0.8, hd: 0.8, h: 1.2, wall: "#c9854a", roof: "#8c5a2b", crate: true },
  { x: 18, z: 10, hw: 0.7, hd: 0.7, h: 1.1, wall: "#b87333", roof: "#8c5a2b", crate: true },
];

export const BLOCKS: Block[] = [...BUILDINGS, ...CRATES];

export const INF_SPAWNS: [number, number][] = [
  [-24, -2],
  [19, -4],
  [-22, 4],
  [8, 22],
  [0, -10],
  [10, -22],
  [-9, -22],
  [27, -10],
];

export const TANK_SPAWNS: [number, number][] = [
  [-22, -16],
  [20, 18],
  [-24, 8],
];
