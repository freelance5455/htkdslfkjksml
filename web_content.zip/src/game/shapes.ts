// ──────────────────────────────────────────────────────────────
// Набор фигур (классический для жанра block-puzzle 8×8)
// ──────────────────────────────────────────────────────────────

export interface ShapeDef {
  /** Клетки фигуры в координатах [row, col] */
  cells: Array<[number, number]>;
  w: number;
  h: number;
  weight: number;
}

/** Описание фигур строками: 'X' — блок, '.' — пусто. [узор, вес выпадения] */
const RAW: Array<[string[], number]> = [
  // одиночный
  [["X"], 2.2],
  // линии 2
  [["XX"], 3], [["X", "X"], 3],
  // линии 3
  [["XXX"], 3], [["X", "X", "X"], 3],
  // линии 4
  [["XXXX"], 2.4], [["X", "X", "X", "X"], 2.4],
  // линии 5
  [["XXXXX"], 1.5], [["X", "X", "X", "X", "X"], 1.5],
  // квадраты и прямоугольники
  [["XX", "XX"], 3],
  [["XXX", "XXX"], 1.6], [["XX", "XX", "XX"], 1.6],
  [["XXX", "XXX", "XXX"], 1.1],
  // маленькие уголки (3 блока)
  [["X.", "XX"], 2.2], [[".X", "XX"], 2.2],
  [["XX", "X."], 2.2], [["XX", ".X"], 2.2],
  // большие уголки (5 блоков, 3×3)
  [["X..", "X..", "XXX"], 1.2], [["XXX", "X..", "X.."], 1.2],
  [["XXX", "..X", "..X"], 1.2], [["..X", "..X", "XXX"], 1.2],
  // L-тетрамино
  [["X.", "X.", "XX"], 1.5], [[".X", ".X", "XX"], 1.5],
  [["XX", "X.", "X."], 1.5], [["XX", ".X", ".X"], 1.5],
  [["XXX", "X.."], 1.5], [["XXX", "..X"], 1.5],
  [["X..", "XXX"], 1.5], [["..X", "XXX"], 1.5],
  // T-фигуры
  [["XXX", ".X."], 1.3], [[".X.", "XXX"], 1.3],
  [["X.", "XX", "X."], 1.3], [[".X", "XX", ".X"], 1.3],
  // S/Z-фигуры
  [[".XX", "XX."], 1.1], [["XX.", ".XX"], 1.1],
  [["X.", "XX", ".X"], 1.1], [[".X", "XX", "X."], 1.1],
];

export const SHAPES: ShapeDef[] = RAW.map(([rows, weight]) => {
  const cells: Array<[number, number]> = [];
  rows.forEach((row, r) => {
    for (let c = 0; c < row.length; c++) {
      if (row[c] === "X") cells.push([r, c]);
    }
  });
  return {
    cells,
    w: Math.max(...rows.map((r) => r.length)),
    h: rows.length,
    weight,
  };
});

const TOTAL_WEIGHT = SHAPES.reduce((s, sh) => s + sh.weight, 0);

/** Случайный индекс фигуры с учётом весов */
export function randomShapeIndex(rng: () => number = Math.random): number {
  let roll = rng() * TOTAL_WEIGHT;
  for (let i = 0; i < SHAPES.length; i++) {
    roll -= SHAPES[i].weight;
    if (roll <= 0) return i;
  }
  return 0;
}
