import { COLOR } from './constants';

/** [row, col] offset inside a shape's bounding box. */
export type Cell = [number, number];

export interface Shape {
  id: number;
  family: string;
  cells: Cell[];
  w: number;
  h: number;
  color: number;
  /** Relative selection weight (already divided across family variants). */
  weight: number;
}

interface FamilyDef {
  family: string;
  color: number;
  weight: number;
  pattern: string[];
  rotate?: boolean;
  mirror?: boolean;
}

const FAMILIES: FamilyDef[] = [
  { family: 'single', color: COLOR.TEAL, weight: 2.0, pattern: ['#'] },
  { family: 'line2', color: COLOR.GREEN, weight: 2.4, pattern: ['##'], rotate: true },
  { family: 'line3', color: COLOR.ORANGE, weight: 2.6, pattern: ['###'], rotate: true },
  { family: 'line4', color: COLOR.RED, weight: 2.2, pattern: ['####'], rotate: true },
  { family: 'line5', color: COLOR.PINK, weight: 1.5, pattern: ['#####'], rotate: true },
  { family: 'sq2', color: COLOR.YELLOW, weight: 2.6, pattern: ['##', '##'] },
  { family: 'sq3', color: COLOR.PURPLE, weight: 1.1, pattern: ['###', '###', '###'] },
  { family: 'rect23', color: COLOR.BLUE, weight: 1.7, pattern: ['###', '###'], rotate: true },
  { family: 'l3', color: COLOR.TEAL, weight: 2.4, pattern: ['#.', '##'], rotate: true },
  { family: 'l4', color: COLOR.PURPLE, weight: 2.8, pattern: ['#.', '#.', '##'], rotate: true, mirror: true },
  { family: 'l5', color: COLOR.BLUE, weight: 2.0, pattern: ['#..', '#..', '###'], rotate: true },
  { family: 't4', color: COLOR.RED, weight: 2.2, pattern: ['###', '.#.'], rotate: true },
  { family: 'sz4', color: COLOR.GREEN, weight: 2.0, pattern: ['.##', '##.'], rotate: true, mirror: true },
];

function parse(pattern: string[]): Cell[] {
  const cells: Cell[] = [];
  pattern.forEach((row, r) => {
    for (let c = 0; c < row.length; c++) if (row[c] === '#') cells.push([r, c]);
  });
  return cells;
}

function normalize(cells: Cell[]): Cell[] {
  let minR = Infinity;
  let minC = Infinity;
  for (const [r, c] of cells) {
    if (r < minR) minR = r;
    if (c < minC) minC = c;
  }
  return cells
    .map(([r, c]) => [r - minR, c - minC] as Cell)
    .sort((a, b) => a[0] - b[0] || a[1] - b[1]);
}

function rotate(cells: Cell[]): Cell[] {
  // 90° clockwise: (r, c) -> (c, -r)
  return normalize(cells.map(([r, c]) => [c, -r] as Cell));
}

function mirror(cells: Cell[]): Cell[] {
  return normalize(cells.map(([r, c]) => [r, -c] as Cell));
}

function key(cells: Cell[]): string {
  return cells.map(([r, c]) => `${r},${c}`).join('|');
}

function buildShapes(): Shape[] {
  const out: Shape[] = [];
  for (const def of FAMILIES) {
    const base = normalize(parse(def.pattern));
    const variants = new Map<string, Cell[]>();
    const add = (cells: Cell[]) => {
      const k = key(cells);
      if (!variants.has(k)) variants.set(k, cells);
    };
    const seeds = def.mirror ? [base, mirror(base)] : [base];
    for (const seed of seeds) {
      let cur = seed;
      add(cur);
      if (def.rotate) {
        for (let i = 0; i < 3; i++) {
          cur = rotate(cur);
          add(cur);
        }
      }
    }
    const n = variants.size;
    for (const cells of variants.values()) {
      let w = 0;
      let h = 0;
      for (const [r, c] of cells) {
        if (c + 1 > w) w = c + 1;
        if (r + 1 > h) h = r + 1;
      }
      out.push({
        id: out.length,
        family: def.family,
        cells,
        w,
        h,
        color: def.color,
        weight: def.weight / n,
      });
    }
  }
  return out;
}

export const SHAPES: readonly Shape[] = buildShapes();

export function shapeById(id: number): Shape | null {
  return SHAPES[id] ?? null;
}
