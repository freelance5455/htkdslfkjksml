import { useEffect, useId, useState } from "react";
import { DRINKS } from "./data";

/* ---------- Copo (reutilizável) ---------- */
export function CupShape({ index, uid }: { index: number; uid: string }) {
  const d = DRINKS[index];
  const gid = `liq-${uid}-${index}`;
  const clip = `clip-${uid}-${index}`;
  return (
    <g>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={d.color[0]} />
          <stop offset="1" stopColor={d.color[1]} />
        </linearGradient>
        <clipPath id={clip}>
          <path d="M10 14 H50 L45 52 Q44 57 39 57 H21 Q16 57 15 52 Z" />
        </clipPath>
      </defs>
      {/* alça */}
      <path d="M49 22 Q64 22 62 35 Q60 46 46 45" fill="none" stroke="#f8fafc" strokeWidth="4.5" strokeLinecap="round" />
      {/* corpo de vidro */}
      <path d="M10 14 H50 L45 52 Q44 57 39 57 H21 Q16 57 15 52 Z" fill="rgba(255,255,255,0.25)" />
      <g clipPath={`url(#${clip})`}>
        <rect x="0" y="22" width="60" height="40" fill={`url(#${gid})`} />
        <ellipse cx="30" cy="22" rx="21" ry="3" fill="rgba(255,255,255,0.45)" />
        {index === 6 && (
          <g fill="#fff">
            <circle cx="20" cy="34" r="1.4" />
            <circle cx="36" cy="30" r="1" />
            <circle cx="30" cy="45" r="1.6" />
            <circle cx="40" cy="41" r="1" />
            <circle cx="22" cy="49" r="0.9" />
          </g>
        )}
        {index === 5 && (
          <g fill="#fde68a">
            <path d="M24 34 l1.5 3.5 3.5 1.5 -3.5 1.5 -1.5 3.5 -1.5 -3.5 -3.5 -1.5 3.5 -1.5z" />
            <circle cx="38" cy="44" r="1.3" />
          </g>
        )}
        {index === 7 && (
          <g fill="#fff" opacity="0.9">
            <path d="M30 28 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2z" />
          </g>
        )}
      </g>
      <path d="M10 14 H50 L45 52 Q44 57 39 57 H21 Q16 57 15 52 Z" fill="none" stroke="#f1f5f9" strokeWidth="2.5" strokeLinejoin="round" />
      <path d="M16 20 L19 48" stroke="rgba(255,255,255,0.7)" strokeWidth="2.2" strokeLinecap="round" />
    </g>
  );
}

export function CupIcon({ index, size = 48 }: { index: number; size?: number }) {
  const uid = useId().replace(/:/g, "");
  return (
    <svg width={size} height={size} viewBox="0 0 66 62" aria-hidden>
      <CupShape index={index} uid={uid} />
    </svg>
  );
}

/* ---------- Acessórios ---------- */
function Accessory({ index }: { index: number }) {
  switch (index) {
    case 0: // gota
      return (
        <g transform="translate(120 62)">
          <path d="M0 -26 C0 -26 -13 -8 -13 0 a13 13 0 0 0 26 0 C13 -8 0 -26 0 -26Z" fill="#38bdf8" stroke="#0369a1" strokeWidth="2.5" />
          <path d="M-6 0 a6 6 0 0 0 5 6" stroke="#fff" strokeWidth="2.5" fill="none" strokeLinecap="round" />
        </g>
      );
    case 1: // boina
      return (
        <g>
          <ellipse cx="124" cy="76" rx="44" ry="15" fill="#5b3a24" stroke="#2b1608" strokeWidth="2.5" />
          <rect x="120" y="58" width="8" height="10" rx="3" fill="#2b1608" />
          <path d="M92 78 Q124 86 154 76" stroke="#2b1608" strokeWidth="2" fill="none" opacity=".5" />
        </g>
      );
    case 2: // bigode de leite
      return (
        <path
          d="M101 122 Q110 111 120 120 Q130 111 139 122 Q130 130 120 125 Q110 130 101 122 Z"
          fill="#fff"
          stroke="#cbd5e1"
          strokeWidth="2"
        />
      );
    case 3: // óculos
      return (
        <g stroke="#3b2314" strokeWidth="3.5" fill="rgba(186,230,253,0.35)">
          <circle cx="104" cy="107" r="12" />
          <circle cx="136" cy="107" r="12" />
          <path d="M116 107 H124" fill="none" />
          <path d="M92 105 L82 100 M148 105 L158 100" fill="none" />
        </g>
      );
    case 4: // laço doce
      return (
        <g transform="translate(92 76) rotate(-20)">
          <path d="M0 0 L-22 -14 L-22 14 Z" fill="#f472b6" stroke="#be185d" strokeWidth="2.5" strokeLinejoin="round" />
          <path d="M0 0 L22 -14 L22 14 Z" fill="#f472b6" stroke="#be185d" strokeWidth="2.5" strokeLinejoin="round" />
          <circle r="6" fill="#fbcfe8" stroke="#be185d" strokeWidth="2.5" />
        </g>
      );
    case 5: // chapéu de mago
      return (
        <g>
          <path d="M120 2 L86 78 H154 Z" fill="#6d28d9" stroke="#3b0764" strokeWidth="3" strokeLinejoin="round" />
          <ellipse cx="120" cy="79" rx="52" ry="10" fill="#7c3aed" stroke="#3b0764" strokeWidth="3" />
          <path d="M92 64 Q120 74 148 64 L152 72 Q120 82 88 72 Z" fill="#fbbf24" />
          <path d="M118 30 l2.5 6 6 2.5 -6 2.5 -2.5 6 -2.5 -6 -6 -2.5 6 -2.5z" fill="#fde68a" />
          <circle cx="106" cy="52" r="2.5" fill="#fde68a" />
          <circle cx="134" cy="48" r="2" fill="#fde68a" />
        </g>
      );
    case 6: // capacete espacial
      return (
        <g>
          <circle cx="120" cy="110" r="54" fill="rgba(125,211,252,0.18)" stroke="#e2e8f0" strokeWidth="5" />
          <path d="M84 80 Q96 62 118 60" stroke="rgba(255,255,255,0.85)" strokeWidth="5" fill="none" strokeLinecap="round" />
          <rect x="92" y="156" width="56" height="12" rx="6" fill="#cbd5e1" stroke="#64748b" strokeWidth="2" />
          <path d="M120 56 V42" stroke="#94a3b8" strokeWidth="3" />
          <circle cx="120" cy="40" r="5" fill="#22d3ee" className="twinkle" />
        </g>
      );
    case 7: // auréola
      return (
        <g>
          <ellipse cx="120" cy="58" rx="34" ry="9" fill="none" stroke="#fde047" strokeWidth="7" style={{ filter: "drop-shadow(0 0 8px #facc15)" }} />
        </g>
      );
    default:
      return null;
  }
}

function Wings() {
  return (
    <g fill="#fff" stroke="#fde68a" strokeWidth="3" strokeLinejoin="round" style={{ filter: "drop-shadow(0 0 8px #fde047)" }}>
      <path d="M82 170 Q30 110 8 130 Q24 138 18 156 Q36 156 36 176 Q52 172 58 192 Q70 186 86 200 Z" />
      <path d="M158 170 Q210 110 232 130 Q216 138 222 156 Q204 156 204 176 Q188 172 182 192 Q170 186 154 200 Z" />
    </g>
  );
}

/* ---------- NPC ---------- */
export interface Popup {
  id: number;
  x: number;
  text: string;
}

interface Props {
  index: number;
  sipKey: number;
  speech: string;
  popups: Popup[];
  onSip: () => void;
}

export function Npc({ index, sipKey, speech, popups, onSip }: Props) {
  const d = DRINKS[index];
  const uid = useId().replace(/:/g, "");
  const [sipping, setSipping] = useState(false);

  useEffect(() => {
    if (!sipKey) return;
    setSipping(true);
    const t = setTimeout(() => setSipping(false), 380);
    return () => clearTimeout(t);
  }, [sipKey]);

  const auraOpacity = 0.25 + index * 0.09;

  return (
    <div className="relative mx-auto w-full max-w-[320px] select-none">
      {/* balão de fala */}
      <div className="pointer-events-none absolute left-1/2 top-0 z-20 w-[88%] -translate-x-1/2">
        <div
          key={speech}
          className="pop-in mx-auto rounded-2xl bg-white/95 px-3 py-1.5 text-center text-[13px] font-semibold leading-tight text-stone-800 shadow-lg"
        >
          {speech}
          <span className="absolute -bottom-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rotate-45 bg-white/95" />
        </div>
      </div>

      <button
        type="button"
        onPointerDown={(e) => {
          e.preventDefault();
          onSip();
        }}
        className="relative mt-9 block w-full cursor-pointer touch-manipulation outline-none"
        aria-label={`Beber ${d.name}`}
      >
        <svg viewBox="0 0 240 290" className="float-y w-full overflow-visible">
          <defs>
            <radialGradient id={`aura-${uid}`}>
              <stop offset="0" stopColor={d.accent} stopOpacity={auraOpacity} />
              <stop offset="1" stopColor={d.accent} stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* aura */}
          <circle cx="120" cy="150" r="135" fill={`url(#aura-${uid})`} />
          {index >= 5 && (
            <g fill={index === 7 ? "#fde047" : "#fff"}>
              {[
                [20, 40, 0],
                [215, 60, 0.6],
                [30, 230, 1.1],
                [208, 215, 0.3],
                [110, 8, 0.9],
                [228, 140, 1.4],
                [8, 140, 0.2],
              ].map(([x, y, dl], i) => (
                <path
                  key={i}
                  className="twinkle"
                  style={{ animationDelay: `${dl}s` }}
                  d={`M${x} ${y - 7} L${x + 2} ${y - 2} L${x + 7} ${y} L${x + 2} ${y + 2} L${x} ${y + 7} L${x - 2} ${y + 2} L${x - 7} ${y} L${x - 2} ${y - 2} Z`}
                />
              ))}
            </g>
          )}

          {index === 7 && <Wings />}

          {/* corpo */}
          <rect x="78" y="150" width="84" height="110" rx="38" fill={d.accent} stroke="rgba(0,0,0,0.35)" strokeWidth="3" />
          <rect x="94" y="154" width="52" height="14" rx="7" fill="rgba(255,255,255,0.25)" />
          {/* pernas */}
          <rect x="94" y="252" width="20" height="26" rx="8" fill="#334155" />
          <rect x="126" y="252" width="20" height="26" rx="8" fill="#334155" />

          {/* cabelo atrás */}
          <circle cx="120" cy="110" r="43" fill="#3b2314" />
          {/* cabeça */}
          <circle cx="120" cy="112" r="40" fill="#fcd5b0" stroke="rgba(0,0,0,0.3)" strokeWidth="2.5" />
          {/* franja */}
          <path d="M80 104 Q84 70 120 70 Q156 70 160 104 Q144 86 120 90 Q96 86 80 104Z" fill="#3b2314" />
          {/* olhos */}
          <g className="blink" fill="#1c1917">
            <ellipse cx="105" cy="109" rx="4.2" ry="5.2" />
            <ellipse cx="135" cy="109" rx="4.2" ry="5.2" />
            <circle cx="106.5" cy="107" r="1.4" fill="#fff" />
            <circle cx="136.5" cy="107" r="1.4" fill="#fff" />
          </g>
          {/* bochechas */}
          <circle cx="94" cy="124" r="6" fill="#fb7185" opacity=".45" />
          <circle cx="146" cy="124" r="6" fill="#fb7185" opacity=".45" />
          {/* boca */}
          {sipping ? (
            <ellipse cx="120" cy="130" rx="5.5" ry="6.5" fill="#7f1d1d" />
          ) : (
            <path d="M110 128 Q120 138 130 128" stroke="#7f1d1d" strokeWidth="3" fill="none" strokeLinecap="round" />
          )}

          <Accessory index={index} />

          {/* copo + mãos */}
          <g transform="translate(87 190) scale(1.1)">
            <g key={sipKey} className={sipKey ? "sip" : ""}>
              <CupShape index={index} uid={uid} />
              <circle cx="8" cy="40" r="7" fill="#fcd5b0" stroke="rgba(0,0,0,0.3)" strokeWidth="2" />
              <circle cx="50" cy="40" r="7" fill="#fcd5b0" stroke="rgba(0,0,0,0.3)" strokeWidth="2" />
            </g>
          </g>
        </svg>

        {/* popups de dinheiro */}
        {popups.map((p) => (
          <span
            key={p.id}
            className="money-float pointer-events-none absolute top-[30%] z-30 text-xl font-black text-amber-300 drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)]"
            style={{ left: `${p.x}%` }}
          >
            {p.text}
          </span>
        ))}
      </button>
    </div>
  );
}
