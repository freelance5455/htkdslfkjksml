import * as THREE from 'three'
import { CONFIG } from './config'

/**
 * Arcade flight model. Pure maths (no DOM, no rendering) so it can be unit tested.
 *
 * Conventions: the aircraft nose points along local -Z, right wing along +X, up along +Y.
 *  - stick.x > 0  rolls right (right wing down)
 *  - pitch > 0    raises the nose
 * Banking turns the aircraft (coordinated turn), diving gains speed and climbing loses it.
 */
export type FlightInput = {
  /** Roll command in [-1, 1]; +1 = right. */
  roll: number
  /** Pitch command in [-1, 1]; +1 = nose up. */
  pitch: number
  /** Throttle setting in [0, 1]. */
  throttle: number
}

const FWD = new THREE.Vector3(0, 0, -1)
const RIGHT = new THREE.Vector3(1, 0, 0)
const UP = new THREE.Vector3(0, 1, 0)

const _q = new THREE.Quaternion()

export class FlightModel {
  readonly position = new THREE.Vector3()
  readonly quaternion = new THREE.Quaternion()
  /** Airspeed along the nose (m/s). */
  speed = 70
  /** Engine output actually produced (lags behind the throttle setting). */
  engine = 0.5
  /** Smoothed angular rates (rad/s) for visual surfaces and camera. */
  pitchRate = 0
  rollRate = 0
  stalled = false
  /** True while the engine is fading out above the ceiling. */
  overCeiling = false
  /** Seconds of simulated flight. */
  time = 0

  readonly forward = new THREE.Vector3(0, 0, -1)
  readonly right = new THREE.Vector3(1, 0, 0)
  readonly up = new THREE.Vector3(0, 1, 0)

  assist = true

  reset(position: THREE.Vector3, yaw: number, speed: number, throttle: number): void {
    this.position.copy(position)
    this.quaternion.setFromAxisAngle(UP, yaw)
    this.speed = speed
    this.engine = throttle
    this.pitchRate = 0
    this.rollRate = 0
    this.stalled = false
    this.overCeiling = false
    this.time = 0
    this.refreshAxes()
  }

  private refreshAxes(): void {
    this.forward.copy(FWD).applyQuaternion(this.quaternion)
    this.right.copy(RIGHT).applyQuaternion(this.quaternion)
    this.up.copy(UP).applyQuaternion(this.quaternion)
  }

  /** Bank angle in radians: 0 level, > 0 right wing down, ±π inverted. */
  get bank(): number {
    return Math.atan2(-this.right.y, this.up.y)
  }

  /** Pitch angle of the nose above the horizon in radians. */
  get pitchAngle(): number {
    return Math.asin(Math.max(-1, Math.min(1, this.forward.y)))
  }

  /** Compass heading in degrees: 0 = north (-z), 90 = east (+x). */
  get heading(): number {
    const deg = (Math.atan2(this.forward.x, -this.forward.z) * 180) / Math.PI
    return (deg + 360) % 360
  }

  step(dt: number, input: FlightInput): void {
    const c = CONFIG.flight
    this.time += dt

    // Engine: spools up and down smoothly; fades out above the service ceiling.
    this.overCeiling = this.position.y > c.ceiling
    const ceilingFade = this.overCeiling ? Math.max(0, 1 - (this.position.y - c.ceiling) / 300) : 1
    const throttle = Math.min(1, Math.max(0, input.throttle)) * ceilingFade
    this.engine += (throttle - this.engine) * Math.min(1, dt * 1.8)

    // Speed: target follows the throttle, slope adds or removes energy.
    const target = c.minSpeed + (c.maxSpeed - c.minSpeed) * this.engine
    this.speed += ((target - this.speed) * c.accel - this.forward.y * c.energy) * dt
    this.speed = Math.min(190, Math.max(8, this.speed))

    // Control authority fades near the stall speed.
    const authority = Math.min(1, Math.max(0.2, (this.speed - c.stallSpeed * 0.6) / (c.stallSpeed * 0.9)))
    this.stalled = this.speed < c.stallSpeed

    const pitchTarget = input.pitch * c.pitchRate * authority
    const rollTarget = input.roll * c.rollRate * authority
    const response = 1 - Math.exp(-dt * 7)
    this.pitchRate += (pitchTarget - this.pitchRate) * response

    // Wing levelling when the player lets go of the stick.
    let levelRoll = 0
    if (this.assist && Math.abs(input.roll) < 0.06 && Math.abs(this.forward.y) < 0.82) {
      levelRoll = Math.max(-1.6, Math.min(1.6, -this.bank * c.levelling))
    }
    this.rollRate += (rollTarget + levelRoll - this.rollRate) * response

    // Stall and ceiling: the nose falls toward the horizon below.
    let nosePush = 0
    if (this.stalled) nosePush -= ((c.stallSpeed - this.speed) / c.stallSpeed) * 1.5
    if (this.overCeiling) nosePush -= 0.4

    // Apply rotations about the local axes.
    this.quaternion.multiply(_q.setFromAxisAngle(RIGHT, (this.pitchRate + nosePush) * dt))
    this.quaternion.multiply(_q.setFromAxisAngle(FWD, this.rollRate * dt))

    // Coordinated turn: heading follows the bank (right wing down → turn right).
    this.refreshAxes()
    const yaw = this.right.y * c.turnRate * authority
    this.quaternion.premultiply(_q.setFromAxisAngle(UP, yaw * dt))
    this.quaternion.normalize()
    this.refreshAxes()

    this.position.addScaledVector(this.forward, this.speed * dt)
  }
}
