import Phaser from 'phaser';
import { DEPTH, TEX, THEME } from './constants';
import type { Layout } from './layout';
import { formatScore } from './scoring';
import { storage } from './storage';
import { sound } from './audio';
import { haptics } from './haptics';
import { roundedTexture } from './textures';
import { IconToggle, UIButton, makeText } from './ui';

/** Modal overlay with dimmed backdrop and a bouncing centre panel. */
export class Overlay extends Phaser.GameObjects.Container {
  readonly panel: Phaser.GameObjects.Container;
  private readonly dim: Phaser.GameObjects.Rectangle;
  private closing = false;

  constructor(scene: Phaser.Scene, L: Layout) {
    super(scene, 0, 0);
    scene.add.existing(this);
    this.setDepth(DEPTH.OVERLAY);
    this.dim = scene.add
      .rectangle(L.W / 2, L.H / 2, L.W + 8, L.H + 8, 0x060a18)
      .setAlpha(0)
      .setInteractive();
    this.panel = scene.add.container(L.W / 2, L.H / 2).setScale(0.75).setAlpha(0);
    this.add([this.dim, this.panel]);
    scene.tweens.add({ targets: this.dim, alpha: 0.72, duration: 260 });
    scene.tweens.add({ targets: this.panel, scale: 1, alpha: 1, duration: 360, ease: 'Back.easeOut' });
  }

  close(cb?: () => void): void {
    if (this.closing) return;
    this.closing = true;
    const s = this.scene;
    s.tweens.killTweensOf([this.dim, this.panel]);
    s.tweens.add({ targets: this.dim, alpha: 0, duration: 200 });
    s.tweens.add({
      targets: this.panel,
      scale: 0.8,
      alpha: 0,
      duration: 200,
      ease: 'Quad.easeIn',
      onComplete: () => {
        this.destroy();
        cb?.();
      },
    });
  }
}

function panelBg(scene: Phaser.Scene, L: Layout, w: number, h: number): Phaser.GameObjects.Image {
  const key = roundedTexture(scene, w, h, 34 * L.u, [THEME.panel, '#1a2447'], {
    border: THEME.panelBorder,
    borderW: Math.max(2, 3 * L.u),
  });
  return scene.add.image(0, 0, key);
}

/** Row of sound / vibration toggles. Returns the row container. */
export function settingsRow(scene: Phaser.Scene, L: Layout, y: number): Phaser.GameObjects.Container {
  const s = storage.getSettings();
  const row = scene.add.container(0, y);
  const size = 84 * L.u;
  const gap = 150 * L.u;

  const soundT = new IconToggle(scene, {
    x: -gap / 2,
    y: 0,
    size,
    onIcon: 'icon_sound_on',
    offIcon: 'icon_sound_off',
    value: s.sound,
    onChange: (v) => {
      const cur = storage.getSettings();
      storage.setSettings({ ...cur, sound: v });
      sound.setEnabled(v);
      if (v) sound.click();
    },
  });
  const vibT = new IconToggle(scene, {
    x: gap / 2,
    y: 0,
    size,
    onIcon: 'icon_vib_on',
    offIcon: 'icon_vib_off',
    value: s.haptics,
    onChange: (v) => {
      const cur = storage.getSettings();
      storage.setSettings({ ...cur, haptics: v });
      haptics.enabled = v;
      if (v) haptics.place();
    },
  });
  const l1 = makeText(scene, -gap / 2, size * 0.78, 'Sound', 22 * L.u, { color: THEME.muted });
  const l2 = makeText(scene, gap / 2, size * 0.78, 'Vibration', 22 * L.u, { color: THEME.muted });
  row.add([soundT, vibT, l1, l2]);
  return row;
}

export interface PauseCallbacks {
  resume: () => void;
  restart: () => void;
  home: () => void;
}

export function showPause(scene: Phaser.Scene, L: Layout, cbs: PauseCallbacks): Overlay {
  const ov = new Overlay(scene, L);
  const u = L.u;
  const w = Math.min(L.W * 0.86, 560 * u);
  const h = 640 * u;
  const bw = w - 90 * u;

  ov.panel.add(panelBg(scene, L, w, h));
  ov.panel.add(makeText(scene, 0, -h / 2 + 70 * u, 'PAUSED', 56 * u, { shadow: true }));
  ov.panel.add(settingsRow(scene, L, -h / 2 + 200 * u));

  ov.panel.add(
    new UIButton(scene, {
      x: 0,
      y: 40 * u,
      w: bw,
      h: 96 * u,
      label: 'RESUME',
      icon: 'icon_play',
      fill: THEME.green,
      edge: THEME.greenEdge,
      fontSize: 36 * u,
      onClick: cbs.resume,
    })
  );

  let armed = false;
  let timer: Phaser.Time.TimerEvent | null = null;
  const restartBtn = new UIButton(scene, {
    x: 0,
    y: 150 * u,
    w: bw,
    h: 96 * u,
    label: 'RESTART',
    icon: 'icon_replay',
    fill: THEME.orange,
    edge: THEME.orangeEdge,
    fontSize: 36 * u,
    onClick: () => {
      if (!armed) {
        armed = true;
        restartBtn.setLabel('SURE?');
        timer = scene.time.delayedCall(2200, () => {
          armed = false;
          if (restartBtn.active) restartBtn.setLabel('RESTART');
        });
        return;
      }
      timer?.remove(false);
      cbs.restart();
    },
  });
  ov.panel.add(restartBtn);

  ov.panel.add(
    new UIButton(scene, {
      x: 0,
      y: 260 * u,
      w: bw,
      h: 96 * u,
      label: 'HOME',
      icon: 'icon_home',
      fill: THEME.blue,
      edge: THEME.blueEdge,
      fontSize: 36 * u,
      onClick: cbs.home,
    })
  );
  return ov;
}

export interface GameOverData {
  score: number;
  best: number;
  record: boolean;
}

export interface GameOverCallbacks {
  again: () => void;
  home: () => void;
}

export function showGameOver(
  scene: Phaser.Scene,
  L: Layout,
  data: GameOverData,
  cbs: GameOverCallbacks
): Overlay {
  const ov = new Overlay(scene, L);
  const u = L.u;
  const w = Math.min(L.W * 0.88, 580 * u);
  const h = 700 * u;
  const bw = w - 90 * u;
  const top = -h / 2;

  ov.panel.add(panelBg(scene, L, w, h));

  if (data.record) {
    const crown = scene.add
      .image(0, top + 78 * u, TEX, 'icon_crown')
      .setDisplaySize(96 * u, 96 * u)
      .setTint(THEME.goldHex);
    ov.panel.add(crown);
    scene.tweens.add({
      targets: crown,
      scale: crown.scale * 1.12,
      duration: 600,
      yoyo: true,
      repeat: -1,
      ease: 'Sine.easeInOut',
    });
    ov.panel.add(
      makeText(scene, 0, top + 160 * u, 'NEW RECORD!', 58 * u, {
        color: THEME.gold,
        stroke: '#5a3a00',
        strokeThickness: 7 * u,
        shadow: true,
      })
    );
  } else {
    ov.panel.add(makeText(scene, 0, top + 120 * u, 'GAME OVER', 60 * u, { shadow: true }));
  }

  ov.panel.add(makeText(scene, 0, top + 240 * u, 'SCORE', 26 * u, { color: THEME.muted }));
  const scoreText = makeText(scene, 0, top + 300 * u, '0', 84 * u, { shadow: true });
  ov.panel.add(scoreText);
  const counter = { v: 0 };
  scene.tweens.add({
    targets: counter,
    v: data.score,
    duration: Math.min(1200, 400 + data.score * 0.2),
    ease: 'Quad.easeOut',
    onUpdate: () => scoreText.setText(formatScore(counter.v)),
    onComplete: () => scoreText.setText(formatScore(data.score)),
  });

  const bestRow = scene.add.container(0, top + 390 * u);
  const bestIcon = scene.add
    .image(0, 0, TEX, 'icon_crown')
    .setDisplaySize(40 * u, 40 * u)
    .setTint(THEME.goldHex);
  const bestLabel = makeText(scene, 0, 0, `BEST  ${formatScore(data.best)}`, 34 * u, {
    color: THEME.gold,
    origin: [0, 0.5],
  });
  const totalW = 40 * u + 14 * u + bestLabel.width;
  bestIcon.x = -totalW / 2 + 20 * u;
  bestLabel.x = -totalW / 2 + 54 * u;
  bestRow.add([bestIcon, bestLabel]);
  ov.panel.add(bestRow);

  ov.panel.add(
    new UIButton(scene, {
      x: 0,
      y: top + 500 * u,
      w: bw,
      h: 104 * u,
      label: 'PLAY AGAIN',
      icon: 'icon_replay',
      fill: THEME.green,
      edge: THEME.greenEdge,
      fontSize: 38 * u,
      onClick: cbs.again,
    })
  );
  ov.panel.add(
    new UIButton(scene, {
      x: 0,
      y: top + 612 * u,
      w: bw,
      h: 88 * u,
      label: 'HOME',
      icon: 'icon_home',
      fill: THEME.blue,
      edge: THEME.blueEdge,
      fontSize: 32 * u,
      onClick: cbs.home,
    })
  );
  return ov;
}
