import { Sim, HOLD, RELAX, JOINT_IDS, TURN_STEPS, DT, MAX_HP, PARTS, HAND_IDS } from './physics';
import type { HitEvent } from './physics';
import { planBot } from './bot';
import type { Difficulty } from './bot';
import { presetStates } from './presets';
import type { Preset } from './presets';
import type { Settings } from './settings';
import { playHit, playBlip, vibrate } from './audio';

export type Mode = 'bot' | 'local' | 'practice';
export type Phase = 'plan' | 'thinking' | 'handoff' | 'sim' | 'over';

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  size: number;
}

export interface Popup {
  x: number;
  y: number;
  text: string;
  life: number;
  color: string;
  big: boolean;
}

export class Match {
  mode: Mode;
  difficulty: Difficulty;
  settings: Settings;
  sim: Sim;
  scratch: Sim;
  phase: Phase = 'plan';
  turn = 1;
  totalTurns: number;
  planner = 0;
  handoffTo = 0;
  timeLeft: number;
  stepsLeft = 0;
  acc = 0;
  speed = 1;
  slowTimer = 0;
  selected: number | null = null;
  particles: Particle[] = [];
  popups: Popup[] = [];
  shake = 0;
  winner = -1; // 0, 1 or 2 = draw
  endReason = '';
  lastTurnDamage = [0, 0];
  turnStartDamage = [0, 0];
  changed: () => void = () => {};
  finished: (winner: number) => void = () => {};
  private lastVibe = 0;
  private lastSoundTick = 0;
  disposed = false;

  constructor(mode: Mode, difficulty: Difficulty, settings: Settings) {
    this.mode = mode;
    this.difficulty = difficulty;
    this.settings = settings;
    this.totalTurns = mode === 'practice' ? Infinity : settings.turns;
    this.timeLeft = settings.turnTime;
    this.sim = new Sim({ dismember: settings.dismember });
    this.scratch = new Sim({ dismember: settings.dismember });
  }

  dispose() {
    this.disposed = true;
  }

  get timed() {
    return this.mode !== 'practice' && this.settings.turnTime > 0;
  }

  hp(i: number) {
    return Math.max(0, 1 - this.sim.fighters[i].damage / MAX_HP);
  }

  get activeFighter() {
    return this.sim.fighters[this.mode === 'local' ? this.planner : 0];
  }

  // ------------------------------------------------------------------ input
  select(j: number | null) {
    this.selected = j;
    this.changed();
  }

  setState(j: number, s: number) {
    const f = this.activeFighter;
    if (f.broken[j]) return;
    f.state[j] = s;
    this.changed();
  }

  toggleGrip(j: number) {
    const p = PARTS[j];
    if (p.kind !== 'hand') return;
    const f = this.activeFighter;
    const h = p.side - 1;
    if (f.broken[j]) return;
    f.grip[h] = !f.grip[h];
    this.changed();
  }

  applyPreset(p: Preset) {
    const f = this.activeFighter;
    const st = presetStates(p);
    for (const i of JOINT_IDS) if (!f.broken[i]) f.state[i] = st[i];
    this.changed();
  }

  setDummyRelaxed(relaxed: boolean) {
    const f = this.sim.fighters[1];
    for (const i of JOINT_IDS) if (!f.broken[i]) f.state[i] = relaxed ? RELAX : HOLD;
    this.changed();
  }

  resetPractice() {
    this.sim = new Sim({ dismember: this.settings.dismember });
    this.scratch = new Sim({ dismember: this.settings.dismember });
    this.turn = 1;
    this.phase = 'plan';
    this.selected = null;
    this.particles = [];
    this.popups = [];
    this.changed();
  }

  cycleSpeed() {
    this.speed = this.speed === 1 ? 0.5 : this.speed === 0.5 ? 2 : 1;
    this.changed();
  }

  skipTurn() {
    if (this.phase !== 'sim') return;
    while (this.stepsLeft > 0) this.stepOnce();
    this.endSimTurn();
  }

  // ------------------------------------------------------------- turn flow
  commit() {
    if (this.phase !== 'plan') return;
    this.selected = null;
    if (this.mode === 'local' && this.planner === 0) {
      this.planner = 1;
      this.handoffTo = 1;
      this.phase = 'handoff';
      this.changed();
      return;
    }
    if (this.mode === 'bot') {
      this.phase = 'thinking';
      this.changed();
      setTimeout(() => {
        if (this.disposed) return;
        const mv = planBot(this.sim, this.scratch, 1, this.difficulty);
        const bf = this.sim.fighters[1];
        for (const i of JOINT_IDS) if (!bf.broken[i]) bf.state[i] = mv.states[i];
        bf.grip = [mv.grip[0] && !bf.broken[HAND_IDS[0]], mv.grip[1] && !bf.broken[HAND_IDS[1]]];
        this.startSim();
      }, 60);
      return;
    }
    this.startSim();
  }

  continueHandoff() {
    if (this.phase !== 'handoff') return;
    this.planner = this.handoffTo;
    this.phase = 'plan';
    this.timeLeft = this.settings.turnTime;
    this.changed();
  }

  private startSim() {
    this.sim.beginTurn();
    this.stepsLeft = TURN_STEPS;
    this.acc = 0;
    this.phase = 'sim';
    this.turnStartDamage = this.sim.fighters.map((f) => f.damage);
    playBlip(520, this.settings.sound, 0.09);
    this.changed();
  }

  private stepOnce() {
    this.sim.step();
    this.stepsLeft--;
    if (this.sim.events.length) {
      this.handleEvents(this.sim.events);
      this.sim.events.length = 0;
    }
  }

  private handleEvents(events: HitEvent[]) {
    let strongest = 0;
    for (const e of events) {
      strongest = Math.max(strongest, e.dmg);
      const n = Math.min(14, 3 + Math.floor(e.dmg / 4));
      const victimColor = e.victim === 0 ? '#60a5fa' : '#f87171';
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2;
        const sp = 1 + Math.random() * (2 + e.dmg / 10);
        this.particles.push({
          x: e.x,
          y: e.y,
          vx: Math.cos(a) * sp,
          vy: Math.sin(a) * sp + 1,
          life: 0.5 + Math.random() * 0.5,
          max: 1,
          color: i % 3 === 0 ? '#fde68a' : i % 3 === 1 ? '#ffffff' : victimColor,
          size: 0.02 + Math.random() * 0.03,
        });
      }
      if (e.dmg >= 4) {
        const last = this.popups[this.popups.length - 1];
        if (last && last.life > 0.6 && Math.hypot(last.x - e.x, last.y - e.y) < 0.4) {
          const v = parseInt(last.text.replace(/\D/g, '') || '0', 10) + Math.round(e.dmg);
          last.text = '-' + v;
          last.life = 1;
        } else {
          this.popups.push({ x: e.x, y: e.y + 0.1, text: '-' + Math.round(e.dmg), life: 1, color: victimColor, big: e.dmg > 20 });
        }
      }
      if (e.dismember) {
        this.popups.push({ x: e.x, y: e.y + 0.4, text: 'DISMEMBER!', life: 1.6, color: '#fbbf24', big: true });
        for (let i = 0; i < 24; i++) {
          const a = Math.random() * Math.PI * 2;
          this.particles.push({ x: e.x, y: e.y, vx: Math.cos(a) * 3, vy: Math.sin(a) * 3 + 1.5, life: 1, max: 1.4, color: '#dc2626', size: 0.04 });
        }
        this.shake = Math.max(this.shake, 14);
        this.slowTimer = 0.9;
      }
    }
    if (strongest > 3) {
      this.shake = Math.max(this.shake, Math.min(12, 2 + strongest / 4));
      if (strongest > 14 && this.settings.slowmo) this.slowTimer = Math.max(this.slowTimer, 0.35);
      const now = performance.now();
      if (now - this.lastSoundTick > 60) {
        playHit(Math.min(8, strongest / 4), this.settings.sound);
        this.lastSoundTick = now;
      }
      if (now - this.lastVibe > 120) {
        vibrate(Math.min(60, 10 + strongest), this.settings.vibrate);
        this.lastVibe = now;
      }
    }
  }

  private endSimTurn() {
    const fs = this.sim.fighters;
    this.lastTurnDamage = fs.map((f, i) => f.damage - this.turnStartDamage[i]);
    const ko0 = fs[0].damage >= MAX_HP;
    const ko1 = fs[1].damage >= MAX_HP;
    if (this.mode !== 'practice' && (ko0 || ko1 || this.turn >= this.totalTurns)) {
      if (ko0 && ko1) this.winner = fs[0].damage === fs[1].damage ? 2 : fs[0].damage < fs[1].damage ? 0 : 1;
      else if (ko0) this.winner = 1;
      else if (ko1) this.winner = 0;
      else {
        const d = fs[0].damage - fs[1].damage;
        this.winner = Math.abs(d) < 1 ? 2 : d < 0 ? 0 : 1;
      }
      this.endReason = ko0 || ko1 ? 'K.O.' : 'Time up';
      this.phase = 'over';
      playBlip(this.winner === 0 ? 880 : 220, this.settings.sound, 0.4, 'triangle');
      this.changed();
      this.finished(this.winner);
      return;
    }
    this.turn++;
    this.planner = 0;
    this.selected = null;
    this.timeLeft = this.settings.turnTime;
    if (this.mode === 'local') {
      this.handoffTo = 0;
      this.phase = 'handoff';
    } else {
      this.phase = 'plan';
    }
    this.changed();
  }

  // ----------------------------------------------------------------- update
  update(dt: number) {
    dt = Math.min(dt, 0.05);
    // particles
    for (const p of this.particles) {
      p.life -= dt;
      p.vy -= 9 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.y < 0.02) {
        p.y = 0.02;
        p.vy *= -0.3;
        p.vx *= 0.7;
      }
    }
    this.particles = this.particles.filter((p) => p.life > 0);
    for (const p of this.popups) {
      p.life -= dt;
      p.y += dt * 0.5;
    }
    this.popups = this.popups.filter((p) => p.life > 0);
    this.shake = Math.max(0, this.shake - dt * 40);

    if (this.phase === 'plan' && this.timed) {
      const before = Math.ceil(this.timeLeft);
      this.timeLeft -= dt;
      if (this.timeLeft <= 5 && Math.ceil(this.timeLeft) !== before && this.timeLeft > 0) playBlip(700, this.settings.sound, 0.05);
      if (this.timeLeft <= 0) {
        this.timeLeft = 0;
        this.commit();
      }
    }

    if (this.phase === 'sim') {
      let sp = this.speed;
      if (this.slowTimer > 0) {
        this.slowTimer -= dt;
        sp *= 0.3;
      }
      this.acc += dt * sp;
      let guard = 0;
      while (this.acc >= DT && this.stepsLeft > 0 && guard++ < 8) {
        this.acc -= DT;
        this.stepOnce();
      }
      if (this.stepsLeft <= 0) this.endSimTurn();
    }
  }
}
