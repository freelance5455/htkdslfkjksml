/** Number of consecutive non-clearing placements after which the combo resets. */
export const COMBO_WINDOW = 3;

const tri = (n: number) => (n * (n + 1)) / 2;

/**
 * Points for clearing `lines` lines at once with the current combo streak.
 * 1 line = 10, 2 = 30, 3 = 60, 4 = 100 ... multiplied by the combo counter.
 */
export function linePoints(lines: number, combo: number): number {
  if (lines <= 0) return 0;
  return 10 * tri(lines) * Math.max(1, combo);
}

/** Praise shown for impressive moves. */
export function praiseFor(lines: number, combo: number): string | null {
  if (lines >= 5) return 'UNBELIEVABLE!';
  if (lines === 4) return 'AMAZING!';
  if (lines === 3) return 'EXCELLENT!';
  if (lines === 2) return 'GREAT!';
  if (lines === 1 && combo >= 3) return 'GOOD!';
  return null;
}

export function formatScore(n: number): string {
  return Math.round(n).toLocaleString('en-US');
}
