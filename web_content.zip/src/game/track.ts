export type TrackSample = {
  x: number;
  y: number;
  z: number;
  tx: number;
  tz: number;
  rx: number;
  rz: number;
  dist: number;
};

export type TrackData = {
  samples: TrackSample[];
  length: number;
  checkpoints: number[];
  halfRoad: number;
  wall: number;
};

function curve(t: number): { x: number; y: number; z: number } {
  const a = t * Math.PI * 2;
  const x = Math.sin(a) * 86 + Math.sin(a * 2) * 14;
  const z = Math.cos(a) * 52 + Math.cos(a * 3) * 7;
  const y = Math.sin(a * 2) * 1.15 + Math.sin(a * 4) * 0.28;
  return { x, y, z };
}

function buildTrack(): TrackData {
  const N = 320;
  const raw: { x: number; y: number; z: number }[] = [];
  for (let i = 0; i < N; i++) raw.push(curve(i / N));

  const samples: TrackSample[] = [];
  let dist = 0;
  for (let i = 0; i < N; i++) {
    const curr = raw[i];
    const next = raw[(i + 1) % N];
    const prev = raw[(i - 1 + N) % N];
    let tx = next.x - prev.x;
    let tz = next.z - prev.z;
    const len = Math.hypot(tx, tz) || 1;
    tx /= len;
    tz /= len;
    const step = Math.hypot(next.x - curr.x, next.z - curr.z);
    samples.push({
      x: curr.x,
      y: curr.y,
      z: curr.z,
      tx,
      tz,
      rx: -tz,
      rz: tx,
      dist,
    });
    dist += step;
  }

  const checkpoints: number[] = [];
  const count = 8;
  for (let i = 0; i < count; i++) {
    const target = (dist * i) / count;
    let best = 0;
    let bestD = Infinity;
    for (let s = 0; s < N; s++) {
      const d = Math.abs(samples[s].dist - target);
      if (d < bestD) {
        bestD = d;
        best = s;
      }
    }
    checkpoints.push(best);
  }

  return { samples, length: dist, checkpoints, halfRoad: 7.4, wall: 10.4 };
}

export const TRACK = buildTrack();
export const LAPS = 3;

export function indexAtDist(dist: number): number {
  const samples = TRACK.samples;
  const length = TRACK.length;
  let d = dist % length;
  if (d < 0) d += length;
  let lo = 0;
  let hi = samples.length - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (samples[mid].dist < d) lo = mid + 1;
    else hi = mid;
  }
  return lo % samples.length;
}
