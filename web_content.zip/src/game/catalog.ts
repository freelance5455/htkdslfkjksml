import type { Celestial, BodyKind, MorphologyProfile } from "./types";

function atlasPos(i: number, n: number, radius: number, yScale: number): [number, number, number] {
  const golden = Math.PI * (3 - Math.sqrt(5));
  const y = n <= 1 ? 0 : 1 - (i / (n - 1)) * 2;
  const r = Math.sqrt(Math.max(0, 1 - y * y));
  const theta = golden * i + 0.7;
  return [Math.cos(theta) * r * radius, y * yScale, Math.sin(theta) * r * radius];
}

type Seed = {
  name: string
  kind: BodyKind
  colorA: number
  colorB: number
  radius: number
  arms?: number
  spin?: number
  bulge?: number
  thick?: number
  info: string
  morph?: Partial<MorphologyProfile>
};

const SEEDS: Seed[] = [
  { name: "Milky Way", kind: "spiral", colorA: 0xffd39b, colorB: 0x9ec9ff, radius: 5, arms: 4, spin: 1.3, bulge: 0.35, thick: 0.18, info: "Home galaxy · the Sun sits ≈26,000 ly from the core", morph: { dust: 0.9, starburst: 0.42 } },
  { name: "Andromeda (M31)", kind: "spiral", colorA: 0xffe0b0, colorB: 0xb9d4ff, radius: 5.4, arms: 2, spin: 1.6, bulge: 0.5, thick: 0.15, info: "≈2.5 million ly away · on a slow collision course with us", morph: { dust: 0.85 } },
  { name: "Triangulum (M33)", kind: "spiral", colorA: 0xffe8c8, colorB: 0xcfe8ff, radius: 4.2, arms: 3, spin: 1.0, bulge: 0.15, thick: 0.2, info: "≈2.7 million ly away · a loosely wound spiral", morph: { starburst: 0.65, dust: 0.45 } },
  { name: "Large Magellanic Cloud", kind: "irregular", colorA: 0xfff0c0, colorB: 0x9fd6ff, radius: 2.6, thick: 0.5, info: "≈160,000 ly away · a satellite of the Milky Way", morph: { starburst: 0.95, asymmetry: 0.9, dust: 0.25 } },
  { name: "Small Magellanic Cloud", kind: "irregular", colorA: 0xffe9c0, colorB: 0x9fc8ff, radius: 1.8, thick: 0.5, info: "≈200,000 ly away · rich in young blue stars", morph: { starburst: 0.9, asymmetry: 0.95, dust: 0.2 } },
  { name: "Whirlpool (M51)", kind: "interact", colorA: 0xffe2b8, colorB: 0x9fd0ff, radius: 4.6, arms: 2, spin: 1.9, bulge: 0.3, thick: 0.15, info: "≈31 million ly away · classic grand-design spiral", morph: { dust: 0.9, tails: 1 } },
  { name: "Sombrero (M104)", kind: "edgeOn", colorA: 0xffd9a0, colorB: 0xd8b98a, radius: 4.6, bulge: 0.75, thick: 0.06, info: "≈29 million ly away · a bright bulge and dust lane", morph: { dust: 1 } },
  { name: "Pinwheel (M101)", kind: "spiral", colorA: 0xffeccb, colorB: 0xaee0ff, radius: 5.6, arms: 5, spin: 1.1, bulge: 0.15, thick: 0.14, info: "≈21 million ly away · a face-on giant spiral", morph: { dust: 0.65, starburst: 0.5 } },
  { name: "Bode's Galaxy (M81)", kind: "spiral", colorA: 0xffdca0, colorB: 0xbcd8ff, radius: 4.4, arms: 2, spin: 1.7, bulge: 0.45, thick: 0.16, info: "≈12 million ly away · a grand-design companion of M82", morph: { dust: 0.75 } },
  { name: "Cigar Galaxy (M82)", kind: "edgeOnBurst", colorA: 0xff9d6b, colorB: 0xff5f8a, radius: 2.6, thick: 0.05, info: "≈12 million ly away · a starburst with polar outflows", morph: { starburst: 1, dust: 0.7 } },
  { name: "Black Eye (M64)", kind: "spiral", colorA: 0xffd9ad, colorB: 0x8f7bb0, radius: 4, arms: 2, spin: 1.4, bulge: 0.5, thick: 0.14, info: "≈17 million ly away · a prominent absorbing dust band", morph: { dust: 1 } },
  { name: "Sunflower (M63)", kind: "spiral", colorA: 0xffe6bd, colorB: 0xb8dcff, radius: 4.4, arms: 8, spin: 1.2, bulge: 0.3, thick: 0.15, info: "≈27 million ly away · flocculent spiral structure", morph: { dust: 0.8, clumpy: 0.65 } },
  { name: "Sculptor (NGC 253)", kind: "edgeOn", colorA: 0xffcf9e, colorB: 0xc9a878, radius: 4.2, bulge: 0.25, thick: 0.07, info: "≈11 million ly away · a dusty starburst disk", morph: { dust: 0.9, starburst: 0.8 } },
  { name: "Centaurus A", kind: "elliptical", colorA: 0xffcf9e, colorB: 0xffb37a, radius: 3.6, info: "≈12 million ly away · an elliptical crossed by a dust lane", morph: { dust: 1, asymmetry: 0.3 } },
  { name: "Messier 87", kind: "elliptical", colorA: 0xfff1cf, colorB: 0xffe2a0, radius: 4, info: "≈53 million ly away · giant elliptical with a relativistic jet", morph: { jet: 1, dust: 0.15 } },
  { name: "Cartwheel Galaxy", kind: "ring", colorA: 0x9fd6ff, colorB: 0xffe8b0, radius: 4.2, info: "≈500 million ly away · a collisional ring", morph: { ring: 1, dust: 0.55, starburst: 0.95 } },
  { name: "Tadpole Galaxy", kind: "irregular", colorA: 0xbfe3ff, colorB: 0xfff0c8, radius: 2.4, thick: 0.35, info: "≈420 million ly away · a disrupted spiral with a long tail", morph: { tails: 1, asymmetry: 0.95, starburst: 0.85 } },
  { name: "Antennae Galaxies", kind: "interact", colorA: 0xffd9a0, colorB: 0x9fd0ff, radius: 3.6, arms: 3, spin: 1.6, bulge: 0.3, thick: 0.15, info: "≈45 million ly away · a pair in mid-merger", morph: { tails: 1, starburst: 0.9, dust: 0.7 } },
  { name: "Seyfert's Sextet", kind: "cluster", colorA: 0xffe2b0, colorB: 0x9fd0ff, radius: 1.1, info: "≈190 million ly away · a compact group of galaxies", morph: { companions: 1 } },
  { name: "Hoag's Object", kind: "ring", colorA: 0xffe6bf, colorB: 0x9fc8ff, radius: 3.6, info: "≈600 million ly away · a nearly perfect ring galaxy", morph: { ring: 1, dust: 0.2 } },
  { name: "NGC 1300", kind: "barred", colorA: 0xffe2b0, colorB: 0xa9d4ff, radius: 4.4, arms: 2, spin: 1.5, bulge: 0.25, thick: 0.15, info: "≈61 million ly away · the prototypical barred spiral", morph: { dust: 0.8 } },
  { name: "NGC 1365", kind: "barred", colorA: 0xffdca4, colorB: 0x9fd0ff, radius: 4.8, arms: 2, spin: 1.9, bulge: 0.3, thick: 0.15, info: "≈56 million ly away · a barred spiral in Fornax", morph: { dust: 0.8, starburst: 0.55 } },
  { name: "NGC 4258 (M106)", kind: "spiral", colorA: 0xffe6c0, colorB: 0xb0d8ff, radius: 4.6, arms: 2, spin: 1.3, bulge: 0.35, thick: 0.16, info: "≈23 million ly away · anomalous arms from a central engine", morph: { tails: 0.45, dust: 0.75 } },
  { name: "Whale Galaxy (NGC 4631)", kind: "edgeOn", colorA: 0xffdca0, colorB: 0xc9d8ff, radius: 4.8, bulge: 0.1, thick: 0.05, info: "≈25 million ly away · an edge-on distorted disk", morph: { asymmetry: 0.85, dust: 0.65 } },
  { name: "Needle Galaxy (NGC 4565)", kind: "edgeOn", colorA: 0xffe6c0, colorB: 0xcfe0ff, radius: 5.2, bulge: 0.45, thick: 0.03, info: "≈40 million ly away · a razor-thin edge-on spiral", morph: { dust: 1 } },
  { name: "Fireworks (NGC 6946)", kind: "spiral", colorA: 0xffe6c8, colorB: 0xa9e0ff, radius: 4.6, arms: 6, spin: 1.0, bulge: 0.2, thick: 0.16, info: "≈22 million ly away · prolific in supernovae", morph: { starburst: 0.8, clumpy: 0.7, dust: 0.7 } },
  { name: "Sagittarius A*", kind: "blackhole", colorA: 0xfff2c8, colorB: 0xff6a3c, radius: 2.2, info: "≈26,000 ly away · ≈4.3 million solar masses" },
  { name: "Messier 87*", kind: "blackhole", colorA: 0xffe9b0, colorB: 0xff7a3c, radius: 3.4, info: "≈55 million ly away · ≈6.5 billion solar masses" },
  { name: "Cygnus X-1", kind: "blackhole", colorA: 0xcfe0ff, colorB: 0x6a8bff, radius: 1.7, info: "≈7,200 ly away · ≈21 solar masses · a stellar-mass binary" },
  { name: "TON 618", kind: "blackhole", colorA: 0xffefc0, colorB: 0xff5a3c, radius: 4.6, info: "≈10 billion ly away · ≈66 billion solar masses" },
  { name: "Phoenix A*", kind: "blackhole", colorA: 0xffe6b0, colorB: 0xff8a4c, radius: 4.2, info: "≈5.8 billion ly away · ≈100 billion solar masses (est.)" },
];

const PROCEDURAL: Array<{
  label: string
  kind: Exclude<BodyKind, "blackhole" | "cluster">;
  arms: number
  spin: number
  bulge: number
  thick: number
  dust: number
  starburst: number
  asymmetry: number
  clumpy: number
  ring: number
  tails: number
  edgeOn?: boolean
}> = [
  { label: "Compact smooth elliptical", kind: "elliptical", arms: 0, spin: 0.15, bulge: 0.82, thick: 0.7, dust: 0.05, starburst: 0.08, asymmetry: 0.05, clumpy: 0.05, ring: 0, tails: 0 },
  { label: "Dusty edge-on disk", kind: "edgeOn", arms: 2, spin: 1.15, bulge: 0.4, thick: 0.05, dust: 0.98, starburst: 0.22, asymmetry: 0.15, clumpy: 0.15, ring: 0, tails: 0, edgeOn: true },
  { label: "Bright elongated edge-on", kind: "edgeOn", arms: 2, spin: 1.35, bulge: 0.68, thick: 0.04, dust: 0.7, starburst: 0.18, asymmetry: 0.1, clumpy: 0.15, ring: 0, tails: 0, edgeOn: true },
  { label: "Face-on spiral", kind: "spiral", arms: 2, spin: 1.35, bulge: 0.3, thick: 0.15, dust: 0.7, starburst: 0.25, asymmetry: 0.08, clumpy: 0.2, ring: 0, tails: 0 },
  { label: "Thin edge-on", kind: "edgeOn", arms: 2, spin: 1.15, bulge: 0.34, thick: 0.025, dust: 0.88, starburst: 0.16, asymmetry: 0.08, clumpy: 0.1, ring: 0, tails: 0, edgeOn: true },
  { label: "Elongated disturbed disk", kind: "spiral", arms: 3, spin: 1.1, bulge: 0.25, thick: 0.2, dust: 0.55, starburst: 0.45, asymmetry: 0.7, clumpy: 0.55, ring: 0, tails: 0.35 },
  { label: "Asymmetric interacting spiral", kind: "interact", arms: 2, spin: 1.7, bulge: 0.25, thick: 0.16, dust: 0.72, starburst: 0.55, asymmetry: 0.8, clumpy: 0.45, ring: 0, tails: 0.65 },
  { label: "Bright irregular starburst", kind: "irregular", arms: 0, spin: 0.5, bulge: 0.18, thick: 0.5, dust: 0.25, starburst: 1, asymmetry: 0.82, clumpy: 0.92, ring: 0, tails: 0.15 },
  { label: "Compact disturbed", kind: "irregular", arms: 0, spin: 0.4, bulge: 0.28, thick: 0.42, dust: 0.28, starburst: 0.7, asymmetry: 0.72, clumpy: 0.85, ring: 0, tails: 0.2 },
  { label: "Inclined disk + companion", kind: "interact", arms: 2, spin: 1.5, bulge: 0.35, thick: 0.14, dust: 0.72, starburst: 0.45, asymmetry: 0.58, clumpy: 0.42, ring: 0, tails: 0.45 },
  { label: "Extreme edge-on", kind: "edgeOn", arms: 2, spin: 1.3, bulge: 0.25, thick: 0.02, dust: 0.98, starburst: 0.25, asymmetry: 0.12, clumpy: 0.1, ring: 0, tails: 0, edgeOn: true },
  { label: "Grand-design spiral", kind: "spiral", arms: 2, spin: 1.95, bulge: 0.34, thick: 0.13, dust: 0.85, starburst: 0.35, asymmetry: 0.12, clumpy: 0.22, ring: 0, tails: 0 },
  { label: "Very thin edge-on", kind: "edgeOn", arms: 2, spin: 1.55, bulge: 0.58, thick: 0.018, dust: 0.96, starburst: 0.12, asymmetry: 0.05, clumpy: 0.05, ring: 0, tails: 0, edgeOn: true },
  { label: "Multi-arm spiral", kind: "spiral", arms: 6, spin: 1.2, bulge: 0.2, thick: 0.16, dust: 0.66, starburst: 0.36, asymmetry: 0.18, clumpy: 0.42, ring: 0, tails: 0 },
  { label: "Smooth elliptical", kind: "elliptical", arms: 0, spin: 0.1, bulge: 0.72, thick: 0.65, dust: 0.03, starburst: 0.05, asymmetry: 0.08, clumpy: 0.04, ring: 0, tails: 0 },
  { label: "Ringed bulge-dominated", kind: "ring", arms: 0, spin: 0.4, bulge: 0.66, thick: 0.2, dust: 0.42, starburst: 0.45, asymmetry: 0.1, clumpy: 0.22, ring: 1, tails: 0 },
  { label: "Ring shell", kind: "ring", arms: 0, spin: 0.3, bulge: 0.38, thick: 0.25, dust: 0.35, starburst: 0.26, asymmetry: 0.25, clumpy: 0.26, ring: 1, tails: 0.1 },
  { label: "Clumpy star-forming disk", kind: "irregular", arms: 4, spin: 1.0, bulge: 0.18, thick: 0.24, dust: 0.35, starburst: 0.86, asymmetry: 0.44, clumpy: 0.98, ring: 0, tails: 0 },
  { label: "Disturbed irregular", kind: "irregular", arms: 0, spin: 0.6, bulge: 0.22, thick: 0.42, dust: 0.3, starburst: 0.65, asymmetry: 0.92, clumpy: 0.88, ring: 0, tails: 0.35 },
  { label: "Inclined spiral", kind: "spiral", arms: 3, spin: 1.45, bulge: 0.32, thick: 0.13, dust: 0.7, starburst: 0.28, asymmetry: 0.18, clumpy: 0.22, ring: 0, tails: 0 },
  { label: "Edge-on disk", kind: "edgeOn", arms: 3, spin: 1.25, bulge: 0.35, thick: 0.035, dust: 0.9, starburst: 0.18, asymmetry: 0.12, clumpy: 0.1, ring: 0, tails: 0, edgeOn: true },
  { label: "Dusty inclined spiral", kind: "spiral", arms: 4, spin: 1.4, bulge: 0.38, thick: 0.12, dust: 1, starburst: 0.3, asymmetry: 0.16, clumpy: 0.28, ring: 0, tails: 0 },
  { label: "Flocculent spiral", kind: "spiral", arms: 7, spin: 0.9, bulge: 0.2, thick: 0.17, dust: 0.56, starburst: 0.48, asymmetry: 0.32, clumpy: 0.86, ring: 0, tails: 0 },
  { label: "Low-surface-brightness disk", kind: "spiral", arms: 2, spin: 0.95, bulge: 0.08, thick: 0.22, dust: 0.25, starburst: 0.14, asymmetry: 0.15, clumpy: 0.2, ring: 0, tails: 0 },
  { label: "Blue compact dwarf", kind: "irregular", arms: 0, spin: 0.3, bulge: 0.25, thick: 0.5, dust: 0.18, starburst: 1, asymmetry: 0.6, clumpy: 0.98, ring: 0, tails: 0.12 },
  { label: "Barred spiral", kind: "barred", arms: 2, spin: 1.7, bulge: 0.28, thick: 0.13, dust: 0.72, starburst: 0.34, asymmetry: 0.12, clumpy: 0.25, ring: 0, tails: 0 },
  { label: "Long-bar spiral", kind: "barred", arms: 2, spin: 1.35, bulge: 0.22, thick: 0.13, dust: 0.82, starburst: 0.4, asymmetry: 0.14, clumpy: 0.28, ring: 0, tails: 0 },
  { label: "Rings + inner bar", kind: "ring", arms: 2, spin: 1.25, bulge: 0.44, thick: 0.14, dust: 0.64, starburst: 0.5, asymmetry: 0.1, clumpy: 0.22, ring: 1, tails: 0 },
  { label: "Polar-ring system", kind: "ring", arms: 0, spin: 0.7, bulge: 0.5, thick: 0.17, dust: 0.3, starburst: 0.3, asymmetry: 0.25, clumpy: 0.22, ring: 1, tails: 0.25 },
  { label: "Shell elliptical", kind: "elliptical", arms: 0, spin: 0.1, bulge: 0.68, thick: 0.75, dust: 0.12, starburst: 0.08, asymmetry: 0.2, clumpy: 0.18, ring: 0.45, tails: 0 },
  { label: "Core-dominated elliptical", kind: "elliptical", arms: 0, spin: 0.08, bulge: 0.92, thick: 0.62, dust: 0.03, starburst: 0.04, asymmetry: 0.04, clumpy: 0.02, ring: 0, tails: 0 },
  { label: "Giant elliptical", kind: "elliptical", arms: 0, spin: 0.12, bulge: 0.75, thick: 0.8, dust: 0.06, starburst: 0.06, asymmetry: 0.08, clumpy: 0.03, ring: 0, tails: 0 },
  { label: "Ultra-compact elliptical", kind: "elliptical", arms: 0, spin: 0.2, bulge: 0.95, thick: 0.5, dust: 0.02, starburst: 0.04, asymmetry: 0.03, clumpy: 0.02, ring: 0, tails: 0 },
  { label: "Blue ring galaxy", kind: "ring", arms: 0, spin: 0.5, bulge: 0.25, thick: 0.18, dust: 0.18, starburst: 0.75, asymmetry: 0.08, clumpy: 0.62, ring: 1, tails: 0 },
  { label: "Broken ring", kind: "ring", arms: 0, spin: 0.45, bulge: 0.3, thick: 0.19, dust: 0.45, starburst: 0.52, asymmetry: 0.52, clumpy: 0.5, ring: 0.8, tails: 0.1 },
  { label: "Starburst disk", kind: "edgeOnBurst", arms: 2, spin: 1.1, bulge: 0.24, thick: 0.08, dust: 0.82, starburst: 1, asymmetry: 0.2, clumpy: 0.74, ring: 0, tails: 0.1 },
  { label: "Superwind disk", kind: "edgeOnBurst", arms: 2, spin: 1.2, bulge: 0.32, thick: 0.06, dust: 0.9, starburst: 0.96, asymmetry: 0.24, clumpy: 0.8, ring: 0, tails: 0.1 },
  { label: "Tidal-tail spiral", kind: "interact", arms: 2, spin: 1.5, bulge: 0.32, thick: 0.16, dust: 0.75, starburst: 0.52, asymmetry: 0.88, clumpy: 0.48, ring: 0, tails: 1 },
  { label: "Pre-merger pair", kind: "interact", arms: 2, spin: 1.4, bulge: 0.3, thick: 0.17, dust: 0.68, starburst: 0.45, asymmetry: 0.62, clumpy: 0.38, ring: 0, tails: 0.4 },
  { label: "Mid-merger", kind: "interact", arms: 3, spin: 1.0, bulge: 0.28, thick: 0.22, dust: 0.75, starburst: 0.84, asymmetry: 0.98, clumpy: 0.92, ring: 0, tails: 1 },
  { label: "Post-merger remnant", kind: "elliptical", arms: 0, spin: 0.2, bulge: 0.64, thick: 0.55, dust: 0.26, starburst: 0.3, asymmetry: 0.72, clumpy: 0.58, ring: 0, tails: 0.55 },
  { label: "Double nucleus", kind: "interact", arms: 2, spin: 1.0, bulge: 0.58, thick: 0.2, dust: 0.82, starburst: 0.72, asymmetry: 0.92, clumpy: 0.6, ring: 0, tails: 0.5 },
  { label: "Grand-design loose arms", kind: "spiral", arms: 2, spin: 1.2, bulge: 0.22, thick: 0.16, dust: 0.65, starburst: 0.24, asymmetry: 0.12, clumpy: 0.2, ring: 0, tails: 0 },
  { label: "Tightly wound spiral", kind: "spiral", arms: 2, spin: 2.25, bulge: 0.5, thick: 0.12, dust: 0.74, starburst: 0.2, asymmetry: 0.08, clumpy: 0.16, ring: 0, tails: 0 },
  { label: "Open-arm spiral", kind: "spiral", arms: 3, spin: 0.8, bulge: 0.18, thick: 0.18, dust: 0.55, starburst: 0.38, asymmetry: 0.18, clumpy: 0.4, ring: 0, tails: 0 },
  { label: "Multi-arm flocculent", kind: "spiral", arms: 9, spin: 0.7, bulge: 0.15, thick: 0.2, dust: 0.5, starburst: 0.5, asymmetry: 0.4, clumpy: 0.92, ring: 0, tails: 0 },
  { label: "Ringed multi-arm", kind: "ring", arms: 4, spin: 1.2, bulge: 0.25, thick: 0.17, dust: 0.55, starburst: 0.42, asymmetry: 0.18, clumpy: 0.48, ring: 0.85, tails: 0 },
  { label: "Dust-lane spiral", kind: "spiral", arms: 4, spin: 1.55, bulge: 0.42, thick: 0.12, dust: 1, starburst: 0.22, asymmetry: 0.16, clumpy: 0.2, ring: 0, tails: 0 },
  { label: "Dust-free elliptical", kind: "elliptical", arms: 0, spin: 0.15, bulge: 0.78, thick: 0.7, dust: 0, starburst: 0.04, asymmetry: 0.04, clumpy: 0.03, ring: 0, tails: 0 },
  { label: "Diffuse elliptical", kind: "elliptical", arms: 0, spin: 0.1, bulge: 0.62, thick: 0.9, dust: 0.02, starburst: 0.03, asymmetry: 0.12, clumpy: 0.05, ring: 0, tails: 0 },
  { label: "Dwarf spheroid", kind: "elliptical", arms: 0, spin: 0.08, bulge: 0.66, thick: 0.85, dust: 0.01, starburst: 0.02, asymmetry: 0.18, clumpy: 0.08, ring: 0, tails: 0 },
  { label: "Dwarf irregular", kind: "irregular", arms: 0, spin: 0.25, bulge: 0.18, thick: 0.55, dust: 0.12, starburst: 0.65, asymmetry: 0.88, clumpy: 0.9, ring: 0, tails: 0.22 },
  { label: "Compact starburst", kind: "irregular", arms: 1, spin: 0.4, bulge: 0.3, thick: 0.42, dust: 0.3, starburst: 0.98, asymmetry: 0.6, clumpy: 1, ring: 0, tails: 0.1 },
  { label: "Chain galaxy", kind: "irregular", arms: 0, spin: 0.15, bulge: 0.1, thick: 0.32, dust: 0.16, starburst: 0.88, asymmetry: 0.96, clumpy: 1, ring: 0, tails: 0.15 },
  { label: "Clump cluster", kind: "irregular", arms: 0, spin: 0.2, bulge: 0.12, thick: 0.5, dust: 0.15, starburst: 0.92, asymmetry: 0.72, clumpy: 1, ring: 0, tails: 0.08 },
  { label: "Warped spiral", kind: "spiral", arms: 3, spin: 1.15, bulge: 0.3, thick: 0.18, dust: 0.7, starburst: 0.36, asymmetry: 0.62, clumpy: 0.38, ring: 0, tails: 0.2 },
  { label: "Warped edge-on", kind: "edgeOn", arms: 2, spin: 1.2, bulge: 0.32, thick: 0.03, dust: 0.86, starburst: 0.28, asymmetry: 0.65, clumpy: 0.3, ring: 0, tails: 0.1, edgeOn: true },
  { label: "Broken arms", kind: "spiral", arms: 4, spin: 1.05, bulge: 0.22, thick: 0.17, dust: 0.62, starburst: 0.58, asymmetry: 0.48, clumpy: 0.78, ring: 0, tails: 0 },
  { label: "Anemic spiral", kind: "spiral", arms: 2, spin: 1.7, bulge: 0.42, thick: 0.14, dust: 0.36, starburst: 0.1, asymmetry: 0.08, clumpy: 0.08, ring: 0, tails: 0 },
  { label: "Red spiral", kind: "spiral", arms: 2, spin: 1.6, bulge: 0.55, thick: 0.15, dust: 0.32, starburst: 0.08, asymmetry: 0.1, clumpy: 0.06, ring: 0, tails: 0 },
  { label: "Blue spiral", kind: "spiral", arms: 5, spin: 1.0, bulge: 0.12, thick: 0.2, dust: 0.48, starburst: 0.68, asymmetry: 0.2, clumpy: 0.7, ring: 0, tails: 0 },
  { label: "Inner ring spiral", kind: "ring", arms: 2, spin: 1.5, bulge: 0.35, thick: 0.14, dust: 0.74, starburst: 0.38, asymmetry: 0.12, clumpy: 0.22, ring: 0.75, tails: 0 },
  { label: "Double-ring galaxy", kind: "ring", arms: 0, spin: 0.55, bulge: 0.4, thick: 0.16, dust: 0.38, starburst: 0.68, asymmetry: 0.1, clumpy: 0.5, ring: 1, tails: 0 },
  { label: "Collisional ring", kind: "ring", arms: 0, spin: 0.5, bulge: 0.2, thick: 0.18, dust: 0.44, starburst: 0.9, asymmetry: 0.36, clumpy: 0.82, ring: 1, tails: 0.15 },
  { label: "Tidal dwarf", kind: "irregular", arms: 0, spin: 0.25, bulge: 0.08, thick: 0.45, dust: 0.28, starburst: 0.82, asymmetry: 0.92, clumpy: 0.92, ring: 0, tails: 0.35 },
  { label: "Tidal stream remnant", kind: "interact", arms: 1, spin: 0.45, bulge: 0.2, thick: 0.35, dust: 0.4, starburst: 0.5, asymmetry: 0.98, clumpy: 0.56, ring: 0, tails: 1 },
  { label: "Compact interacting pair", kind: "interact", arms: 2, spin: 1.2, bulge: 0.38, thick: 0.2, dust: 0.7, starburst: 0.68, asymmetry: 0.84, clumpy: 0.58, ring: 0, tails: 0.62 },
  { label: "Asymmetric ring", kind: "ring", arms: 0, spin: 0.45, bulge: 0.28, thick: 0.2, dust: 0.36, starburst: 0.72, asymmetry: 0.78, clumpy: 0.64, ring: 0.85, tails: 0.18 },
  { label: "Polar disk", kind: "spiral", arms: 2, spin: 0.95, bulge: 0.26, thick: 0.25, dust: 0.5, starburst: 0.42, asymmetry: 0.38, clumpy: 0.42, ring: 0.4, tails: 0.18 },
  { label: "Ultra-diffuse disk", kind: "spiral", arms: 2, spin: 0.75, bulge: 0.05, thick: 0.28, dust: 0.18, starburst: 0.08, asymmetry: 0.24, clumpy: 0.16, ring: 0, tails: 0 },
  { label: "Compact barred starburst", kind: "barred", arms: 2, spin: 1.6, bulge: 0.35, thick: 0.12, dust: 0.74, starburst: 0.88, asymmetry: 0.2, clumpy: 0.72, ring: 0, tails: 0 },
  { label: "Weak bar spiral", kind: "barred", arms: 3, spin: 1.2, bulge: 0.22, thick: 0.16, dust: 0.58, starburst: 0.28, asymmetry: 0.16, clumpy: 0.36, ring: 0, tails: 0 },
  { label: "Triple-arm spiral", kind: "spiral", arms: 3, spin: 1.45, bulge: 0.22, thick: 0.17, dust: 0.65, starburst: 0.34, asymmetry: 0.2, clumpy: 0.35, ring: 0, tails: 0 },
  { label: "Seven-arm spiral", kind: "spiral", arms: 7, spin: 1.0, bulge: 0.17, thick: 0.18, dust: 0.58, starburst: 0.5, asymmetry: 0.24, clumpy: 0.65, ring: 0, tails: 0 },
  { label: "Lopsided spiral", kind: "spiral", arms: 3, spin: 1.15, bulge: 0.24, thick: 0.18, dust: 0.55, starburst: 0.48, asymmetry: 0.85, clumpy: 0.48, ring: 0, tails: 0.2 },
  { label: "Faint dusty disk", kind: "edgeOn", arms: 2, spin: 1.15, bulge: 0.18, thick: 0.05, dust: 0.96, starburst: 0.12, asymmetry: 0.18, clumpy: 0.08, ring: 0, tails: 0, edgeOn: true },
  { label: "Torn spiral", kind: "interact", arms: 3, spin: 1.0, bulge: 0.2, thick: 0.2, dust: 0.72, starburst: 0.64, asymmetry: 0.96, clumpy: 0.7, ring: 0, tails: 0.92 },
  { label: "Shell ring hybrid", kind: "ring", arms: 0, spin: 0.35, bulge: 0.48, thick: 0.3, dust: 0.22, starburst: 0.32, asymmetry: 0.42, clumpy: 0.32, ring: 0.95, tails: 0.2 },
  { label: "Quiet lenticular", kind: "spiral", arms: 0, spin: 0.5, bulge: 0.62, thick: 0.16, dust: 0.14, starburst: 0.05, asymmetry: 0.06, clumpy: 0.04, ring: 0.15, tails: 0 },
  { label: "Active nucleus disk", kind: "spiral", arms: 2, spin: 1.75, bulge: 0.52, thick: 0.13, dust: 0.7, starburst: 0.58, asymmetry: 0.14, clumpy: 0.26, ring: 0.2, tails: 0 },
  { label: "Jet-host elliptical", kind: "elliptical", arms: 0, spin: 0.1, bulge: 0.82, thick: 0.68, dust: 0.08, starburst: 0.04, asymmetry: 0.06, clumpy: 0.04, ring: 0, tails: 0 },
  { label: "Deep-field spiral", kind: "spiral", arms: 4, spin: 1.25, bulge: 0.28, thick: 0.18, dust: 0.5, starburst: 0.42, asymmetry: 0.3, clumpy: 0.52, ring: 0, tails: 0 },
  { label: "Deep-field edge-on", kind: "edgeOn", arms: 2, spin: 1.2, bulge: 0.36, thick: 0.04, dust: 0.82, starburst: 0.26, asymmetry: 0.22, clumpy: 0.22, ring: 0, tails: 0, edgeOn: true },
  { label: "Deep-field irregular", kind: "irregular", arms: 0, spin: 0.25, bulge: 0.15, thick: 0.5, dust: 0.14, starburst: 0.88, asymmetry: 0.82, clumpy: 0.96, ring: 0, tails: 0.2 },
  { label: "Deep-field ring", kind: "ring", arms: 0, spin: 0.45, bulge: 0.22, thick: 0.18, dust: 0.42, starburst: 0.7, asymmetry: 0.18, clumpy: 0.6, ring: 1, tails: 0 },
  { label: "Background deep-field spiral", kind: "spiral", arms: 3, spin: 1.18, bulge: 0.26, thick: 0.18, dust: 0.46, starburst: 0.38, asymmetry: 0.28, clumpy: 0.5, ring: 0, tails: 0 },
  { label: "Background tidal pair", kind: "interact", arms: 2, spin: 1.25, bulge: 0.3, thick: 0.2, dust: 0.62, starburst: 0.58, asymmetry: 0.82, clumpy: 0.62, ring: 0, tails: 0.75 },
  { label: "Faint ringed disk", kind: "ring", arms: 2, spin: 0.9, bulge: 0.2, thick: 0.22, dust: 0.3, starburst: 0.24, asymmetry: 0.14, clumpy: 0.28, ring: 0.85, tails: 0 },
];

function palette(i: number) {
  const palettes: Array<[number, number]> = [
    [0xffd9ad, 0x89cfff], [0xffc88c, 0x8db7ff], [0xffe4bf, 0x9fe5ff], [0xffb979, 0xa7c4ff],
    [0xf4d09a, 0x91d8ff], [0xffd6b1, 0xb0b6ff], [0xe8b16d, 0x8edcff], [0xffe7bd, 0x9dcbff],
  ];
  return palettes[i % palettes.length];
}

const CATALOG: Celestial[] = SEEDS.map((s, i) => {
  const isBH = s.kind === "blackhole";
  const gi = isBH ? i - 26 : i;
  const n = isBH ? 5 : 26;
  const pos = isBH ? atlasPos(gi, n, 210, 46) : atlasPos(gi, n, 430, 96);
  return {
    id: i,
    name: s.name,
    kind: s.kind,
    colorA: s.colorA,
    colorB: s.colorB,
    radius: s.radius,
    arms: s.arms ?? 2,
    spin: s.spin ?? 1.2,
    bulge: s.bulge ?? 0.3,
    thick: s.thick ?? 0.16,
    info: s.info,
    pos,
    morphology: {
      dust: 0.55,
      starburst: 0.32,
      asymmetry: 0.12,
      clumpy: 0.18,
      ring: 0,
      tails: 0,
      companions: 0,
      jet: 0,
      ...s.morph,
    },
    recipeId: undefined,
  } as Celestial;
});

PROCEDURAL.slice(0, 88).forEach((r, i) => {
  const [ca, cb] = palette(i + 2);
  const id = CATALOG.length;
  const pos = atlasPos(i, 88, 500, 148);
  const seed = 1000 + i * 17;
  CATALOG.push({
    id,
    name: `Atlas Recipe R${Math.floor(i / 8) + 1}C${(i % 8) + 1} · ${r.label}`,
    kind: r.kind,
    colorA: ca,
    colorB: cb,
    radius: 2.4 + ((i * 7) % 17) * 0.19,
    arms: r.arms,
    spin: r.spin,
    bulge: r.bulge,
    thick: r.thick,
    info: `Procedural morphology recipe R${Math.floor(i / 8) + 1}C${(i % 8) + 1} · deterministic seed ${seed}`,
    pos,
    morphology: {
      dust: r.dust,
      starburst: r.starburst,
      asymmetry: r.asymmetry,
      clumpy: r.clumpy,
      ring: r.ring,
      tails: r.tails,
      companions: r.kind === "interact" ? 1 : 0,
      jet: r.label.toLowerCase().includes("jet") ? 1 : 0,
      edgeOn: r.edgeOn ? 1 : 0,
    },
    recipeId: i,
    seed,
  });
});

export { CATALOG };
export const REAL_OBJECTS = SEEDS.length;
export const PROCEDURAL_RECIPES = 88;
export const TOTAL_BODIES = CATALOG.length;
export const REAL_GALAXIES = 26;
export const BLACK_HOLES = 5;

export const KIND_LABEL: Record<BodyKind, string> = {
  spiral: "Spiral galaxy",
  barred: "Barred spiral",
  elliptical: "Elliptical galaxy",
  irregular: "Irregular galaxy",
  edgeOn: "Edge-on disk",
  edgeOnBurst: "Starburst disk",
  ring: "Ring galaxy",
  interact: "Interacting pair",
  cluster: "Compact group",
  blackhole: "Black hole",
};
