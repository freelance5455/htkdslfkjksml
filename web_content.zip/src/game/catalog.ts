import type {
  CustomerKind,
  EmployeeRole,
  LocationDef,
  LocationId,
  ProductCategory,
  ProductDef,
  ProductId,
  SupplierDef,
} from "./types";

export const PRODUCTS: ProductDef[] = [
  {
    id: "bread",
    name: "Bread",
    category: "bakery",
    buyPrice: 1.15,
    sellPrice: 2.49,
    unlockLevel: 1,
    color: 0xc4a574,
    shelf: "gondola",
    perishable: true,
    demand: 1.15,
  },
  {
    id: "milk",
    name: "Milk",
    category: "dairy",
    buyPrice: 1.05,
    sellPrice: 2.29,
    unlockLevel: 1,
    color: 0xf2f4f7,
    shelf: "fridge",
    perishable: true,
    demand: 1.2,
  },
  {
    id: "eggs",
    name: "Eggs",
    category: "dairy",
    buyPrice: 1.7,
    sellPrice: 3.49,
    unlockLevel: 1,
    color: 0xf0d48a,
    shelf: "fridge",
    perishable: true,
    demand: 1.05,
  },
  {
    id: "drinks",
    name: "Drinks",
    category: "drinks",
    buyPrice: 0.65,
    sellPrice: 1.59,
    unlockLevel: 1,
    color: 0x3d8fd4,
    shelf: "gondola",
    perishable: false,
    demand: 1.1,
  },
  {
    id: "chocolate",
    name: "Chocolate",
    category: "snacks",
    buyPrice: 0.85,
    sellPrice: 1.99,
    unlockLevel: 1,
    color: 0x5c3317,
    shelf: "gondola",
    perishable: false,
    demand: 0.95,
  },
  {
    id: "biscuits",
    name: "Biscuits",
    category: "snacks",
    buyPrice: 0.8,
    sellPrice: 1.89,
    unlockLevel: 2,
    color: 0xd9b48a,
    shelf: "gondola",
    perishable: false,
    demand: 0.9,
  },
  {
    id: "noodles",
    name: "Noodles",
    category: "pantry",
    buyPrice: 0.55,
    sellPrice: 1.39,
    unlockLevel: 2,
    color: 0xd4a017,
    shelf: "gondola",
    perishable: false,
    demand: 1.0,
  },
  {
    id: "rice",
    name: "Rice",
    category: "pantry",
    buyPrice: 2.2,
    sellPrice: 4.79,
    unlockLevel: 2,
    color: 0xe8e0d0,
    shelf: "rack",
    perishable: false,
    demand: 0.85,
  },
  {
    id: "meat",
    name: "Meat",
    category: "fresh",
    buyPrice: 4.4,
    sellPrice: 8.99,
    unlockLevel: 3,
    color: 0xb85c5c,
    shelf: "fridge",
    perishable: true,
    demand: 0.8,
  },
  {
    id: "vegetables",
    name: "Vegetables",
    category: "fresh",
    buyPrice: 0.75,
    sellPrice: 1.79,
    unlockLevel: 2,
    color: 0x4f8f4a,
    shelf: "produce",
    perishable: true,
    demand: 1.0,
  },
  {
    id: "fruits",
    name: "Fruits",
    category: "fresh",
    buyPrice: 0.9,
    sellPrice: 1.99,
    unlockLevel: 2,
    color: 0xe07050,
    shelf: "produce",
    perishable: true,
    demand: 1.05,
  },
  {
    id: "shampoo",
    name: "Shampoo",
    category: "personal",
    buyPrice: 2.1,
    sellPrice: 4.49,
    unlockLevel: 3,
    color: 0x7a9ec9,
    shelf: "gondola",
    perishable: false,
    demand: 0.7,
  },
  {
    id: "cleaning",
    name: "Cleaner",
    category: "household",
    buyPrice: 1.7,
    sellPrice: 3.79,
    unlockLevel: 3,
    color: 0x5aa8a0,
    shelf: "gondola",
    perishable: false,
    demand: 0.65,
  },
  {
    id: "frozen",
    name: "Frozen",
    category: "frozen",
    buyPrice: 2.0,
    sellPrice: 4.29,
    unlockLevel: 3,
    color: 0x8ec8e8,
    shelf: "freezer",
    perishable: false,
    demand: 0.75,
  },
];

export const PRODUCT_MAP: Record<ProductId, ProductDef> = Object.fromEntries(
  PRODUCTS.map((p) => [p.id, p]),
) as Record<ProductId, ProductDef>;

export const SUPPLIERS: SupplierDef[] = [
  {
    id: "fresh",
    name: "FreshFarm Co",
    specialty: "fresh",
    priceMul: 0.88,
    delayMin: 18,
    bulk: 0.94,
  },
  {
    id: "metro",
    name: "Metro Wholesale",
    specialty: "all",
    priceMul: 1,
    delayMin: 12,
    bulk: 0.92,
  },
  {
    id: "quick",
    name: "QuickStock",
    specialty: "all",
    priceMul: 1.28,
    delayMin: 5,
    bulk: 1,
  },
  {
    id: "frost",
    name: "FrozenKing",
    specialty: "frozen",
    priceMul: 0.9,
    delayMin: 16,
    bulk: 0.93,
  },
  {
    id: "bulk",
    name: "BulkBuy",
    specialty: "pantry",
    priceMul: 0.82,
    delayMin: 22,
    bulk: 0.86,
  },
];

export const LOCATIONS: LocationDef[] = [
  {
    id: "town",
    name: "Small Town",
    rent: 70,
    traffic: 0.78,
    unlockLevel: 1,
    blurb: "Quiet streets. Budget shoppers and regulars.",
  },
  {
    id: "city",
    name: "City",
    rent: 160,
    traffic: 1,
    unlockLevel: 2,
    blurb: "Steady mix of every customer type.",
  },
  {
    id: "downtown",
    name: "Downtown",
    rent: 280,
    traffic: 1.22,
    unlockLevel: 3,
    blurb: "Busy, impatient, and willing to spend.",
  },
  {
    id: "beach",
    name: "Beach Area",
    rent: 210,
    traffic: 0.95,
    unlockLevel: 3,
    blurb: "Drinks and snacks fly off the shelf.",
  },
  {
    id: "business",
    name: "Business District",
    rent: 360,
    traffic: 1.35,
    unlockLevel: 4,
    blurb: "Lunch rushes and high-ticket baskets.",
  },
];

export const LOCATION_MAP: Record<LocationId, LocationDef> = Object.fromEntries(
  LOCATIONS.map((l) => [l.id, l]),
) as Record<LocationId, LocationDef>;

export const STORE_LABELS = [
  "Corner Grocery",
  "Medium Store",
  "Supermarket",
  "Hypermarket",
] as const;

export const UPGRADE_COST = [0, 8500, 26000, 82000];

export const ROLE_META: Record<
  EmployeeRole,
  { label: string; salary: number; hire: number; blurb: string }
> = {
  cashier: {
    label: "Cashier",
    salary: 85,
    hire: 420,
    blurb: "Serves the checkout queue.",
  },
  stocker: {
    label: "Stock Worker",
    salary: 80,
    hire: 390,
    blurb: "Moves warehouse crates onto shelves.",
  },
  cleaner: {
    label: "Cleaner",
    salary: 70,
    hire: 310,
    blurb: "Keeps floors and shelves presentable.",
  },
  security: {
    label: "Security Guard",
    salary: 95,
    hire: 480,
    blurb: "Stops shoplifters and calms queues.",
  },
  delivery: {
    label: "Delivery Worker",
    salary: 90,
    hire: 450,
    blurb: "Cuts supplier wait times.",
  },
  manager: {
    label: "Manager",
    salary: 140,
    hire: 900,
    blurb: "Lifts staff skill and daily rating.",
  },
};

export const CUSTOMER_META: Record<
  CustomerKind,
  { label: string; color: number; speed: number; patience: number; scale: number }
> = {
  budget: { label: "Budget", color: 0x6b7a4a, speed: 1.55, patience: 28, scale: 1 },
  rich: { label: "Rich", color: 0x2c3a55, speed: 1.7, patience: 22, scale: 1.04 },
  impatient: { label: "Impatient", color: 0xa14a44, speed: 2.15, patience: 12, scale: 1 },
  child: { label: "Child", color: 0xd4a24a, speed: 1.9, patience: 16, scale: 0.72 },
  elderly: { label: "Elderly", color: 0x9aa0a8, speed: 1.15, patience: 40, scale: 0.96 },
  regular: { label: "Regular", color: 0x3d6d8a, speed: 1.65, patience: 26, scale: 1 },
};

export const STAFF_NAMES = [
  "Rina",
  "Karim",
  "Sofia",
  "Jamal",
  "Hana",
  "Leo",
  "Priya",
  "Omar",
  "Mira",
  "Victor",
  "Nadia",
  "Chen",
  "Aya",
  "Noah",
  "Lila",
];

export function profitOf(id: ProductId, sellMul = 1): number {
  const p = PRODUCT_MAP[id];
  return +(p.sellPrice * sellMul - p.buyPrice).toFixed(2);
}

export function categoriesOnShelves(): ProductCategory[] {
  return [...new Set(PRODUCTS.map((p) => p.category))];
}

export function storeFootprint(level: number): { w: number; d: number } {
  if (level <= 1) return { w: 18, d: 24 };
  if (level === 2) return { w: 24, d: 28 };
  if (level === 3) return { w: 32, d: 34 };
  return { w: 40, d: 40 };
}
