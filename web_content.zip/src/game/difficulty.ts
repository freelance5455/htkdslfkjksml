/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DifficultyTier } from './types';

export interface DifficultyProfile {
  tier: DifficultyTier;
  levelNumber: number;
  gridSize: number;
  minArrows: number;
  maxArrows: number;
  minPathLength: number;
  maxPathLength: number;
  turnBias: number;
  minBlockedRatio: number;
  minWaveDepth: number;
  minAvgTurns: number;
  minComplexityScore: number;
}

/**
 * Maps any level number to its exact dynamic difficulty tier:
 * Level 1–5: Easy
 * Level 6–10: Normal
 * Level 11–20: Medium
 * Level 21–30: Hard
 * Level 31–50: Very Hard
 * Level 51–100: Expert
 * Level 101–500: Master
 * Level 501–1000: Insane
 * Level 1001+: Ultimate
 */
export function getDifficultyTierForLevel(levelNumber: number): DifficultyTier {
  if (levelNumber <= 5) return 'Easy';
  if (levelNumber <= 10) return 'Normal';
  if (levelNumber <= 20) return 'Medium';
  if (levelNumber <= 30) return 'Hard';
  if (levelNumber <= 50) return 'Very Hard';
  if (levelNumber <= 100) return 'Expert';
  if (levelNumber <= 500) return 'Master';
  if (levelNumber <= 1000) return 'Insane';
  return 'Ultimate';
}

/**
 * Computes smoothly scaling puzzle complexity parameters for any level number (1 to 10000+).
 * Scales grid dimensions up to 26x26 (rendered in 2 batched Canvas draw calls at 60fps on Android WebView)
 * while calibrating path lengths, turns, blocked ratios, dependency depth, and composite complexity scores.
 */
export function getDifficultyProfile(levelNumber: number): DifficultyProfile {
  const lv = Math.max(1, Math.floor(levelNumber));
  const tier = getDifficultyTierForLevel(lv);

  if (lv <= 5) {
    const t = (lv - 1) / 4;
    return {
      tier,
      levelNumber: lv,
      gridSize: Math.round(7 + t * 3), // 7 -> 10
      minArrows: Math.round(10 + t * 6),
      maxArrows: Math.round(16 + t * 8),
      minPathLength: 2,
      maxPathLength: Math.round(4 + t * 2),
      turnBias: 0.56 + t * 0.08,
      minBlockedRatio: 0.58 + t * 0.08,
      minWaveDepth: Math.round(3 + t * 3),
      minAvgTurns: 0.5,
      minComplexityScore: Math.round(80 + t * 60),
    };
  }

  if (lv <= 10) {
    const t = (lv - 6) / 4;
    return {
      tier,
      levelNumber: lv,
      gridSize: Math.round(10 + t * 3), // 10 -> 13
      minArrows: Math.round(16 + t * 10),
      maxArrows: Math.round(25 + t * 13),
      minPathLength: 2,
      maxPathLength: Math.round(6 + t * 2),
      turnBias: 0.66 + t * 0.08,
      minBlockedRatio: 0.68 + t * 0.07,
      minWaveDepth: Math.round(6 + t * 4),
      minAvgTurns: 0.85,
      minComplexityScore: Math.round(150 + t * 100),
    };
  }

  if (lv <= 20) {
    const t = (lv - 11) / 9;
    return {
      tier,
      levelNumber: lv,
      gridSize: Math.round(14 + t * 2), // 14 -> 16
      minArrows: Math.round(28 + t * 10),
      maxArrows: Math.round(42 + t * 12),
      minPathLength: 2,
      maxPathLength: 8,
      turnBias: 0.72 + t * 0.04,
      minBlockedRatio: 0.74,
      minWaveDepth: Math.round(9 + t * 3),
      minAvgTurns: 1.05,
      minComplexityScore: Math.round(280 + t * 90),
    };
  }

  if (lv <= 30) {
    const t = (lv - 21) / 9;
    return {
      tier,
      levelNumber: lv,
      gridSize: Math.round(16 + t * 2), // 16 -> 18
      minArrows: Math.round(38 + t * 12),
      maxArrows: Math.round(56 + t * 14),
      minPathLength: 2,
      maxPathLength: 8,
      turnBias: 0.76 + t * 0.04,
      minBlockedRatio: 0.78,
      minWaveDepth: Math.round(12 + t * 3),
      minAvgTurns: 1.2,
      minComplexityScore: Math.round(390 + t * 110),
    };
  }

  if (lv <= 50) {
    const t = (lv - 31) / 19;
    return {
      tier,
      levelNumber: lv,
      gridSize: Math.round(18 + t * 2), // 18 -> 20
      minArrows: Math.round(48 + t * 14),
      maxArrows: Math.round(68 + t * 18),
      minPathLength: 2,
      maxPathLength: 9,
      turnBias: 0.8 + t * 0.03,
      minBlockedRatio: 0.8,
      minWaveDepth: Math.round(14 + t * 4),
      minAvgTurns: 1.3,
      minComplexityScore: Math.round(520 + t * 140),
    };
  }

  if (lv <= 100) {
    const t = (lv - 51) / 49;
    return {
      tier,
      levelNumber: lv,
      gridSize: Math.round(20 + t * 2), // 20 -> 22
      minArrows: Math.round(60 + t * 16),
      maxArrows: Math.round(85 + t * 20),
      minPathLength: 2,
      maxPathLength: 9,
      turnBias: 0.82 + t * 0.03,
      minBlockedRatio: 0.82,
      minWaveDepth: Math.round(17 + t * 4),
      minAvgTurns: 1.4,
      minComplexityScore: Math.round(680 + t * 180),
    };
  }

  if (lv <= 500) {
    // Master (101 - 500)
    const t = (lv - 101) / 399;
    return {
      tier,
      levelNumber: lv,
      gridSize: Math.round(22 + t * 2), // 22 -> 24
      minArrows: Math.round(74 + t * 16),
      maxArrows: Math.round(104 + t * 20),
      minPathLength: 2,
      maxPathLength: 10,
      turnBias: 0.84 + t * 0.02,
      minBlockedRatio: 0.84,
      minWaveDepth: Math.round(20 + t * 5),
      minAvgTurns: 1.5,
      minComplexityScore: Math.round(880 + t * 200),
    };
  }

  if (lv <= 1000) {
    // Insane (501 - 1000)
    const t = (lv - 501) / 499;
    return {
      tier,
      levelNumber: lv,
      gridSize: 25,
      minArrows: Math.round(88 + t * 14),
      maxArrows: Math.round(122 + t * 16),
      minPathLength: 2,
      maxPathLength: 10,
      turnBias: 0.86,
      minBlockedRatio: 0.86,
      minWaveDepth: Math.round(24 + t * 5),
      minAvgTurns: 1.6,
      minComplexityScore: Math.round(1100 + t * 220),
    };
  }

  // Ultimate (1001+)
  const extra = Math.min(1, (lv - 1001) / 1000);
  return {
    tier,
    levelNumber: lv,
    gridSize: 26,
    minArrows: Math.round(100 + extra * 12),
    maxArrows: Math.round(136 + extra * 16),
    minPathLength: 2,
    maxPathLength: 10,
    turnBias: 0.88,
    minBlockedRatio: 0.87,
    minWaveDepth: Math.round(27 + extra * 6),
    minAvgTurns: 1.65,
    minComplexityScore: Math.round(1320 + extra * 220),
  };
}
