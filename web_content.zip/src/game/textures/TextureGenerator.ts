import * as THREE from 'three';

export class TextureGenerator {
  private static cache = new Map<string, THREE.CanvasTexture>();

  // Road Asphalt with painted markings
  static createRoadTexture(): THREE.CanvasTexture {
    const key = 'road';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Dark asphalt base
    ctx.fillStyle = '#22252a';
    ctx.fillRect(0, 0, 512, 512);

    // Asphalt noise grain
    const imgData = ctx.getImageData(0, 0, 512, 512);
    const data = imgData.data;
    for (let i = 0; i < data.length; i += 4) {
      const n = (Math.random() - 0.5) * 35;
      data[i] = Math.min(255, Math.max(0, data[i] + n));
      data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + n));
      data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + n));
    }
    ctx.putImageData(imgData, 0, 0);

    // Yellow center divider double lines
    ctx.strokeStyle = '#eab308';
    ctx.lineWidth = 8;
    ctx.setLineDash([32, 16]);
    ctx.beginPath();
    ctx.moveTo(250, 0);
    ctx.lineTo(250, 512);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(262, 0);
    ctx.lineTo(262, 512);
    ctx.stroke();

    // White outer road boundary lines
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 6;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(32, 0);
    ctx.lineTo(32, 512);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(480, 0);
    ctx.lineTo(480, 512);
    ctx.stroke();

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    this.cache.set(key, texture);
    return texture;
  }

  // Concrete sidewalk / slab tiles
  static createConcreteTexture(): THREE.CanvasTexture {
    const key = 'concrete';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Concrete base
    ctx.fillStyle = '#6b7280';
    ctx.fillRect(0, 0, 512, 512);

    // Noise
    const imgData = ctx.getImageData(0, 0, 512, 512);
    const data = imgData.data;
    for (let i = 0; i < data.length; i += 4) {
      const n = (Math.random() - 0.5) * 40;
      data[i] = Math.min(255, Math.max(0, data[i] + n));
      data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + n));
      data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + n));
    }
    ctx.putImageData(imgData, 0, 0);

    // Grid tile seams
    ctx.strokeStyle = '#374151';
    ctx.lineWidth = 4;
    ctx.strokeRect(0, 0, 256, 256);
    ctx.strokeRect(256, 0, 256, 256);
    ctx.strokeRect(0, 256, 256, 256);
    ctx.strokeRect(256, 256, 256, 256);

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    this.cache.set(key, texture);
    return texture;
  }

  // Weathered suburban brick
  static createBrickTexture(): THREE.CanvasTexture {
    const key = 'brick';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Mortar
    ctx.fillStyle = '#4b5563';
    ctx.fillRect(0, 0, 512, 512);

    const rows = 16;
    const cols = 8;
    const h = 512 / rows;
    const w = 512 / cols;

    for (let r = 0; r < rows; r++) {
      const offset = (r % 2) * (w / 2);
      for (let c = -1; c <= cols; c++) {
        const x = c * w + offset;
        const y = r * h;

        // Brick color variation (aged red/terracotta/brown)
        const redTone = 120 + Math.floor(Math.random() * 45);
        const greenTone = 45 + Math.floor(Math.random() * 25);
        const blueTone = 35 + Math.floor(Math.random() * 20);
        ctx.fillStyle = `rgb(${redTone},${greenTone},${blueTone})`;
        ctx.fillRect(x + 2, y + 2, w - 4, h - 4);
      }
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    this.cache.set(key, texture);
    return texture;
  }

  // Corrugated military warehouse steel
  static createCorrugatedMetalTexture(): THREE.CanvasTexture {
    const key = 'corrugated';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    const ribs = 16;
    const ribWidth = 256 / ribs;
    for (let i = 0; i < ribs; i++) {
      const x = i * ribWidth;
      const grad = ctx.createLinearGradient(x, 0, x + ribWidth, 0);
      grad.addColorStop(0, '#2d3748');
      grad.addColorStop(0.3, '#718096');
      grad.addColorStop(0.5, '#a0aec0');
      grad.addColorStop(0.8, '#4a5568');
      grad.addColorStop(1, '#1a202c');
      ctx.fillStyle = grad;
      ctx.fillRect(x, 0, ribWidth, 256);
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    this.cache.set(key, texture);
    return texture;
  }

  // Military Green Camo (Containers, barricades)
  static createCamoTexture(): THREE.CanvasTexture {
    const key = 'camo';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Base olive
    ctx.fillStyle = '#3f4f35';
    ctx.fillRect(0, 0, 512, 512);

    const colors = ['#283618', '#586b46', '#2b2d22', '#6b705c'];
    for (let i = 0; i < 40; i++) {
      ctx.fillStyle = colors[i % colors.length];
      ctx.beginPath();
      const cx = Math.random() * 512;
      const cy = Math.random() * 512;
      const r = 25 + Math.random() * 60;
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    this.cache.set(key, texture);
    return texture;
  }

  // Wood planks for fences and floors
  static createWoodTexture(): THREE.CanvasTexture {
    const key = 'wood';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#4a3728';
    ctx.fillRect(0, 0, 512, 512);

    const planks = 8;
    const plankH = 512 / planks;

    for (let i = 0; i < planks; i++) {
      const y = i * plankH;
      const shade = 65 + Math.floor(Math.random() * 30);
      ctx.fillStyle = `rgb(${shade + 20}, ${shade}, ${Math.floor(shade * 0.7)})`;
      ctx.fillRect(0, y + 2, 512, plankH - 4);

      // Wood grain lines
      ctx.strokeStyle = `rgba(0, 0, 0, 0.25)`;
      ctx.lineWidth = 1.5;
      for (let g = 0; g < 4; g++) {
        ctx.beginPath();
        const gy = y + 5 + Math.random() * (plankH - 10);
        ctx.moveTo(0, gy);
        ctx.bezierCurveTo(150, gy + Math.random() * 6, 350, gy - Math.random() * 6, 512, gy);
        ctx.stroke();
      }
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    this.cache.set(key, texture);
    return texture;
  }

  // Grass / Terrain ground texture
  static createGrassTexture(): THREE.CanvasTexture {
    const key = 'grass';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Base earth-green
    ctx.fillStyle = '#2d3f25';
    ctx.fillRect(0, 0, 512, 512);

    const imgData = ctx.getImageData(0, 0, 512, 512);
    const data = imgData.data;
    for (let i = 0; i < data.length; i += 4) {
      const n = (Math.random() - 0.5) * 35;
      data[i] = Math.min(255, Math.max(0, data[i] + n * 0.8));
      data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + n * 1.2));
      data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + n * 0.6));
    }
    ctx.putImageData(imgData, 0, 0);

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    this.cache.set(key, texture);
    return texture;
  }

  // Yellow & Black Hazard Stripes for barricades / testing ground barriers
  static createHazardTexture(): THREE.CanvasTexture {
    const key = 'hazard';
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#eab308'; // Warning yellow
    ctx.fillRect(0, 0, 256, 256);

    ctx.fillStyle = '#18181b'; // Black
    const stripeWidth = 32;
    for (let x = -256; x < 512; x += stripeWidth * 2) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x + stripeWidth, 0);
      ctx.lineTo(x + stripeWidth + 256, 256);
      ctx.lineTo(x + 256, 256);
      ctx.closePath();
      ctx.fill();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    this.cache.set(key, texture);
    return texture;
  }

  // Wall-buy chalk outline for in-game purchases
  static createWallBuyTexture(weaponName: string, cost: number): THREE.CanvasTexture {
    const key = `wallbuy_${weaponName}_${cost}`;
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.clearRect(0, 0, 512, 256);

    // Glowing border outline
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 6;
    ctx.setLineDash([12, 6]);
    ctx.strokeRect(10, 10, 492, 236);

    // Weapon icon silhouette outline
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 5;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(80, 120);
    ctx.lineTo(380, 120);
    ctx.lineTo(380, 95);
    ctx.lineTo(440, 95);
    ctx.lineTo(440, 125);
    ctx.lineTo(340, 125);
    ctx.lineTo(310, 175);
    ctx.lineTo(280, 175);
    ctx.lineTo(295, 125);
    ctx.lineTo(200, 125);
    ctx.lineTo(190, 160);
    ctx.lineTo(160, 160);
    ctx.lineTo(170, 125);
    ctx.lineTo(80, 125);
    ctx.closePath();
    ctx.stroke();

    // Text
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 36px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(weaponName.toUpperCase(), 256, 60);

    ctx.fillStyle = '#fbbf24';
    ctx.font = 'bold 32px monospace';
    ctx.fillText(`COST: $${cost}`, 256, 215);

    const texture = new THREE.CanvasTexture(canvas);
    this.cache.set(key, texture);
    return texture;
  }
}
