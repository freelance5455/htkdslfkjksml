import { useSyncExternalStore } from "react";
import { game } from "./engine";

export function useGame() {
  useSyncExternalStore(
    (cb) => game.subscribe(cb),
    () => game.version,
    () => game.version,
  );
  return game;
}
