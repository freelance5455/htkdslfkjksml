// Lightweight deterministic noise utilities (no allocations in hot paths)

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hash2(x: number, z: number): number {
  let h = (Math.imul(x | 0, 374761393) + Math.imul(z | 0, 668265263)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

const perm = new Uint8Array(512);
const gx = new Float32Array(256);
const gz = new Float32Array(256);
(() => {
  const r = mulberry32(1337);
  const p = new Uint8Array(256);
  for (let i = 0; i < 256; i++) p[i] = i;
  for (let i = 255; i > 0; i--) {
    const j = Math.floor(r() * (i + 1));
    const t = p[i];
    p[i] = p[j];
    p[j] = t;
  }
  for (let i = 0; i < 512; i++) perm[i] = p[i & 255];
  for (let i = 0; i < 256; i++) {
    const a = r() * Math.PI * 2;
    gx[i] = Math.cos(a);
    gz[i] = Math.sin(a);
  }
})();

/** Perlin gradient noise, range approx [-1, 1] */
export function noise2(x: number, z: number): number {
  const xi = Math.floor(x);
  const zi = Math.floor(z);
  const xf = x - xi;
  const zf = z - zi;
  const X = xi & 255;
  const Z = zi & 255;
  const u = xf * xf * xf * (xf * (xf * 6 - 15) + 10);
  const v = zf * zf * zf * (zf * (zf * 6 - 15) + 10);
  const aa = perm[X + perm[Z]];
  const ab = perm[X + perm[Z + 1]];
  const ba = perm[X + 1 + perm[Z]];
  const bb = perm[X + 1 + perm[Z + 1]];
  const n00 = gx[aa] * xf + gz[aa] * zf;
  const n10 = gx[ba] * (xf - 1) + gz[ba] * zf;
  const n01 = gx[ab] * xf + gz[ab] * (zf - 1);
  const n11 = gx[bb] * (xf - 1) + gz[bb] * (zf - 1);
  const x1 = n00 + u * (n10 - n00);
  const x2 = n01 + u * (n11 - n01);
  return (x1 + v * (x2 - x1)) * 1.41;
}

export function fbm(x: number, z: number, oct: number): number {
  let s = 0;
  let a = 1;
  let f = 1;
  let n = 0;
  for (let i = 0; i < oct; i++) {
    s += noise2(x * f, z * f) * a;
    n += a;
    a *= 0.5;
    f *= 2.03;
  }
  return s / n;
}

export function ridged(x: number, z: number, oct: number): number {
  let s = 0;
  let a = 1;
  let f = 1;
  let n = 0;
  let w = 1;
  for (let i = 0; i < oct; i++) {
    let r = 1 - Math.abs(noise2(x * f + i * 17.3, z * f - i * 9.1));
    r *= r;
    r *= w;
    w = Math.min(1, r * 1.6);
    s += r * a;
    n += a;
    a *= 0.5;
    f *= 2.1;
  }
  return s / n;
}

export function smoothstep(a: number, b: number, x: number): number {
  let t = (x - a) / (b - a);
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return t * t * (3 - 2 * t);
}

export function clamp(x: number, a: number, b: number) {
  return x < a ? a : x > b ? b : x;
}

export function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}
