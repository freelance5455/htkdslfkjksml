import * as THREE from "three";
import { CHUNK, CHUNK_RES, CHUNKS_PER_SIDE, WORLD_HALF } from "./worldData";
import { newSample, Sample, sampleTerrain, terrainColor, heightAt } from "./terrain";
import { GeoBuilder } from "./geo";
import { hash2, mulberry32, noise2 } from "./noise";
import { Collider, circleCol } from "./physics";
import * as V from "./vegetation";

const N = CHUNK_RES + 1;
const STEPU = CHUNK / CHUNK_RES;
const NB = N + 2;

export class Chunk {
  cx: number;
  cz: number;
  ox: number;
  oz: number;
  group = new THREE.Group();
  heights = new Float32Array(N * N);
  colliders: Collider[] = [];
  grass: THREE.Mesh | null = null;
  meshes: THREE.Mesh[] = [];
  constructor(cx: number, cz: number) {
    this.cx = cx;
    this.cz = cz;
    this.ox = -WORLD_HALF + cx * CHUNK;
    this.oz = -WORLD_HALF + cz * CHUNK;
    this.group.position.set(this.ox, 0, this.oz);
  }
  dispose() {
    for (const m of this.meshes) m.geometry.dispose();
    this.group.removeFromParent();
  }
}

// shared index for chunk terrain (+ skirts)
function buildIndex(): number[] {
  const idx: number[] = [];
  for (let j = 0; j < CHUNK_RES; j++)
    for (let i = 0; i < CHUNK_RES; i++) {
      const a = j * N + i, b = a + 1, c = a + N, d = c + 1;
      idx.push(a, c, b, b, c, d);
    }
  // skirts: vertex N*N + k for perimeter order
  const per: number[] = [];
  for (let i = 0; i < N; i++) per.push(i);
  for (let j = 1; j < N; j++) per.push(j * N + N - 1);
  for (let i = N - 2; i >= 0; i--) per.push((N - 1) * N + i);
  for (let j = N - 2; j > 0; j--) per.push(j * N);
  per.push(0);
  for (let k = 0; k < per.length - 1; k++) {
    const a = per[k], b = per[k + 1];
    const sa = N * N + k, sb = N * N + k + 1;
    idx.push(a, b, sb, a, sb, sa, a, sb, b, a, sa, sb);
  }
  return idx;
}
let INDEX: number[] | null = null;
let PERIM: number[] | null = null;
function perimeter() {
  if (PERIM) return PERIM;
  const per: number[] = [];
  for (let i = 0; i < N; i++) per.push(i);
  for (let j = 1; j < N; j++) per.push(j * N + N - 1);
  for (let i = N - 2; i >= 0; i--) per.push((N - 1) * N + i);
  for (let j = N - 2; j > 0; j--) per.push(j * N);
  per.push(0);
  PERIM = per;
  return per;
}

export interface ChunkMats {
  terrain: THREE.Material;
  veg: THREE.Material;
}

export class ChunkManager {
  chunks = new Map<number, Chunk>();
  parent: THREE.Group;
  mats: ChunkMats;
  radius = 3;
  grassRadius = 1;
  shadows = false;
  private samples: Sample[] = [];
  private queue: number[] = [];
  changed = false;
  grassDensity = 1;

  constructor(parent: THREE.Group, mats: ChunkMats) {
    this.parent = parent;
    this.mats = mats;
    for (let i = 0; i < NB * NB; i++) this.samples.push(newSample());
  }

  key(cx: number, cz: number) {
    return cz * 1000 + cx;
  }

  getChunkAt(x: number, z: number) {
    const cx = Math.floor((x + WORLD_HALF) / CHUNK);
    const cz = Math.floor((z + WORLD_HALF) / CHUNK);
    return this.chunks.get(this.key(cx, cz));
  }

  /** exact ground height following the rendered triangles */
  ground(x: number, z: number) {
    const ch = this.getChunkAt(x, z);
    if (!ch) return heightAt(x, z);
    const lx = (x - ch.ox) / STEPU, lz = (z - ch.oz) / STEPU;
    let i = Math.floor(lx), j = Math.floor(lz);
    if (i >= CHUNK_RES) i = CHUNK_RES - 1;
    if (j >= CHUNK_RES) j = CHUNK_RES - 1;
    if (i < 0) i = 0;
    if (j < 0) j = 0;
    const fx = lx - i, fz = lz - j;
    const H = ch.heights;
    const a = H[j * N + i], b = H[j * N + i + 1], c = H[(j + 1) * N + i], d = H[(j + 1) * N + i + 1];
    if (fx + fz <= 1) return a + (b - a) * fx + (c - a) * fz;
    return d + (c - d) * (1 - fx) + (b - d) * (1 - fz);
  }

  collidersNear(x: number, z: number, out: Collider[]) {
    const cx = Math.floor((x + WORLD_HALF) / CHUNK);
    const cz = Math.floor((z + WORLD_HALF) / CHUNK);
    const lx = (x + WORLD_HALF) / CHUNK - cx, lz = (z + WORLD_HALF) / CHUNK - cz;
    const dxs = [0, lx < 0.5 ? -1 : 1], dzs = [0, lz < 0.5 ? -1 : 1];
    for (const dz of dzs)
      for (const dx of dxs) {
        const ch = this.chunks.get(this.key(cx + dx, cz + dz));
        if (!ch) continue;
        for (let i = 0; i < ch.colliders.length; i++) {
          const c = ch.colliders[i];
          const ex = c.x - x, ez = c.z - z;
          if (ex * ex + ez * ez < 36) out.push(c);
        }
      }
  }

  update(px: number, pz: number, budgetMs: number) {
    const pcx = Math.floor((px + WORLD_HALF) / CHUNK);
    const pcz = Math.floor((pz + WORLD_HALF) / CHUNK);
    const R = this.radius;
    const need = new Set<number>();
    const list: [number, number][] = [];
    for (let dz = -R; dz <= R; dz++)
      for (let dx = -R; dx <= R; dx++) {
        if (dx * dx + dz * dz > (R + 0.5) * (R + 0.5)) continue;
        const cx = pcx + dx, cz = pcz + dz;
        if (cx < 0 || cz < 0 || cx >= CHUNKS_PER_SIDE || cz >= CHUNKS_PER_SIDE) continue;
        const k = this.key(cx, cz);
        need.add(k);
        if (!this.chunks.has(k)) list.push([dx * dx + dz * dz, k]);
      }
    for (const [k, ch] of this.chunks) {
      if (!need.has(k)) {
        ch.dispose();
        this.chunks.delete(k);
        this.changed = true;
      }
    }
    list.sort((a, b) => a[0] - b[0]);
    this.queue = list.map((l) => l[1]);
    const t0 = performance.now();
    while (this.queue.length) {
      const k = this.queue.shift()!;
      const cx = k % 1000, cz = Math.floor(k / 1000);
      this.build(cx, cz);
      this.changed = true;
      if (performance.now() - t0 > budgetMs) break;
    }
    // grass visibility
    for (const ch of this.chunks.values()) {
      if (ch.grass) {
        const d = Math.max(Math.abs(ch.cx - pcx), Math.abs(ch.cz - pcz));
        ch.grass.visible = d <= this.grassRadius;
      }
    }
  }

  clearAll() {
    for (const ch of this.chunks.values()) ch.dispose();
    this.chunks.clear();
    this.changed = true;
  }

  private build(cx: number, cz: number) {
    const ch = new Chunk(cx, cz);
    const { ox, oz } = ch;
    const S = this.samples;
    // samples with border
    for (let j = 0; j < NB; j++)
      for (let i = 0; i < NB; i++) sampleTerrain(ox + (i - 1) * STEPU, oz + (j - 1) * STEPU, S[j * NB + i]);
    const H = ch.heights;
    for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) H[j * N + i] = S[(j + 1) * NB + i + 1].h;

    const slopeAt = (lx: number, lz: number) => {
      const i = Math.min(N - 2, Math.max(0, Math.floor(lx / STEPU)));
      const j = Math.min(N - 2, Math.max(0, Math.floor(lz / STEPU)));
      const a = H[j * N + i], b = H[j * N + i + 1], c = H[(j + 1) * N + i], d = H[(j + 1) * N + i + 1];
      const gx = (b - a + d - c) * 0.5 / STEPU;
      const gz = (c - a + d - b) * 0.5 / STEPU;
      return Math.sqrt(gx * gx + gz * gz);
    };

    // ---------- Vegetation ----------
    const rnd = mulberry32(Math.floor(hash2(cx * 7 + 3, cz * 13 + 5) * 4294967295));
    const veg = new GeoBuilder();
    const grass = new GeoBuilder();
    const smp = newSample();
    const aoPts: number[] = []; // lx, lz, radius, strength
    const G = 4.5;
    const cells = Math.floor(CHUNK / G);
    for (let gj = 0; gj < cells; gj++)
      for (let gi = 0; gi < cells; gi++) {
        const lx = (gi + 0.15 + rnd() * 0.7) * G;
        const lz = (gj + 0.15 + rnd() * 0.7) * G;
        const x = ox + lx, z = oz + lz;
        sampleTerrain(x, z, smp);
        const r0 = rnd();
        if (smp.pad > 0.15 || smp.road > 0.05) continue;
        const inWater = smp.water > smp.h - 0.1;
        const slope = slopeAt(lx, lz);
        const y = smp.h;
        if (inWater) {
          if (smp.waterDepthE > -2.5 && r0 < 0.35) V.reeds(veg, x - ox, smp.water, z - oz, rnd);
          continue;
        }
        if (smp.sand > 0.4) {
          if (r0 < 0.12) {
            const s = 0.5 + rnd() * 0.9;
            V.rock(veg, lx, y, lz, s, rnd, false);
            ch.colliders.push(circleCol(x, z, s * 0.9, y + s * 0.8));
          } else if (r0 < 0.4 && smp.waterDepthE < 2) V.reeds(veg, lx, y, lz, rnd);
          continue;
        }
        if (slope > 1.05) {
          if (r0 < 0.1) {
            const s = 0.8 + rnd() * 1.6;
            V.rock(veg, lx, y - 0.2, lz, s, rnd, false);
            ch.colliders.push(circleCol(x, z, s * 0.9, y + s * 0.7));
          }
          continue;
        }
        const alt = y;
        const high = alt > 92;
        const pineZone = Math.max(smp.plateau, smp.mount * 0.9);
        let treeP = smp.forest * 0.8 + smp.light * 0.2 + pineZone * 0.32 * (alt < 98 ? 1 : 0) + 0.025;
        if (high) treeP *= 0.3;
        if (alt > 110) treeP = 0;
        const bushP = smp.forest * 0.28 + smp.light * 0.08 + 0.05;
        if (r0 < treeP) {
          const s = 0.8 + rnd() * 0.65 + smp.forest * 0.3;
          let kind: number;
          const r1 = rnd();
          if (pineZone > 0.45 || alt > 48) kind = r1 < 0.85 ? 0 : 1;
          else if (smp.light > 0.5) kind = r1 < 0.65 ? 2 : 1;
          else if (smp.forest > 0.4) kind = r1 < 0.45 ? 0 : 1;
          else kind = r1 < 0.25 ? 0 : r1 < 0.85 ? 1 : 2;
          if (kind === 0) V.pine(veg, lx, y, lz, s, rnd, alt > 80);
          else if (kind === 1) V.oak(veg, lx, y, lz, s, rnd);
          else V.birch(veg, lx, y, lz, s * 0.95, rnd);
          ch.colliders.push(circleCol(x, z, (kind === 2 ? 0.25 : 0.4) * s, 1e9));
          aoPts.push(lx, lz, (kind === 2 ? 1.8 : 2.8) * s, 0.35);
        } else if (r0 < treeP + bushP) {
          const s = 0.7 + rnd() * 0.7;
          if (smp.forest > 0.5 && rnd() < 0.45) V.fern(veg, lx, y, lz, s, rnd);
          else V.bush(veg, lx, y, lz, s, rnd, rnd() < 0.15);
          aoPts.push(lx, lz, 1.4 * s, 0.2);
        } else if (r0 < treeP + bushP + 0.035 + smp.mount * 0.08) {
          const s = 0.4 + rnd() * (1 + smp.mount * 1.5);
          V.rock(veg, lx, y, lz, s, rnd, smp.forest > 0.3);
          if (s > 0.6) ch.colliders.push(circleCol(x, z, s * 0.9, y + s * 0.75));
        } else if (r0 < treeP + bushP + 0.06 && smp.forest > 0.35) {
          const len = 3 + rnd() * 2.5;
          const ang = rnd() * 3.14;
          V.log(veg, lx, y, lz, len, ang, rnd);
          const ca = Math.cos(ang), sa = Math.sin(ang);
          for (let t = -1; t <= 1; t++) ch.colliders.push(circleCol(x - ca * t * len * 0.33, z + sa * t * len * 0.33, 0.45, y + 0.7));
          for (let m = 0; m < 3; m++) if (rnd() < 0.5) V.mushroom(veg, lx + (rnd() - 0.5) * 2, y, lz + (rnd() - 0.5) * 2, rnd);
        } else if (smp.forest > 0.5 && rnd() < 0.08) {
          V.mushroom(veg, lx, y, lz, rnd);
        }
      }

    // ground cover: grass & flowers (near-only mesh)
    const GG = 2.3 / Math.sqrt(this.grassDensity);
    const gc = Math.floor(CHUNK / GG);
    for (let gj = 0; gj < gc; gj++)
      for (let gi = 0; gi < gc; gi++) {
        const lx = (gi + rnd()) * GG;
        const lz = (gj + rnd()) * GG;
        const i = Math.round(lx / STEPU), j = Math.round(lz / STEPU);
        const s = S[(j + 1) * NB + i + 1];
        if (s.road > 0.3 || s.pad > 0.6 || s.h < s.water + 0.05 || s.sand > 0.6 || s.h > 96) continue;
        const slope = slopeAt(lx, lz);
        if (slope > 0.85) continue;
        const y = heightLocal(H, lx, lz);
        const r0 = rnd();
        const meadow = 1 - Math.min(1, s.forest * 1.5);
        const fl = s.light * 0.12 + meadow * 0.07 + (s.plateau > 0.5 ? 0.05 : 0);
        if (r0 < fl) {
          const pal = Math.floor(Math.abs(noise2((ox + lx) * 0.03, (oz + lz) * 0.03)) * 6) % 6;
          V.flower(grass, lx, y, lz, rnd, rnd() < 0.7 ? pal : -1);
          if (rnd() < 0.5) V.flower(grass, lx + 0.3, y, lz + 0.2, rnd, pal);
        } else if (r0 < fl + 0.25 + meadow * 0.3) {
          const dry = Math.max(0, noise2((ox + lx) * 0.045, (oz + lz) * 0.045));
          const f = s.forest;
          const r = 0.34 + dry * 0.2 - f * 0.1, g = 0.56 + dry * 0.05 - f * 0.18, bl = 0.2;
          V.grassTuft(grass, lx, y, lz, 0.8 + rnd() * 0.6, rnd, r, g, bl);
        }
      }

    // ---------- Terrain mesh ----------
    const vcount = N * N + perimeter().length;
    const pos = new Float32Array(vcount * 3);
    const nor = new Float32Array(vcount * 3);
    const col = new Float32Array(vcount * 3);
    for (let j = 0; j < N; j++)
      for (let i = 0; i < N; i++) {
        const v = j * N + i;
        const bi = (j + 1) * NB + i + 1;
        const hL = S[bi - 1].h, hR = S[bi + 1].h, hD = S[bi - NB].h, hU = S[bi + NB].h;
        const nx = hL - hR, nz = hD - hU, ny = 2 * STEPU;
        const l = Math.sqrt(nx * nx + ny * ny + nz * nz);
        nor[v * 3] = nx / l; nor[v * 3 + 1] = ny / l; nor[v * 3 + 2] = nz / l;
        pos[v * 3] = i * STEPU; pos[v * 3 + 1] = S[bi].h; pos[v * 3 + 2] = j * STEPU;
        const slope = Math.sqrt((hR - hL) ** 2 + (hU - hD) ** 2) / (2 * STEPU);
        terrainColor(S[bi], slope, ox + i * STEPU, oz + j * STEPU, col, v * 3);
      }
    // AO under trees
    for (let k = 0; k < aoPts.length; k += 4) {
      const lx = aoPts[k], lz = aoPts[k + 1], R = aoPts[k + 2], st = aoPts[k + 3];
      const i0 = Math.max(0, Math.floor((lx - R) / STEPU)), i1 = Math.min(N - 1, Math.ceil((lx + R) / STEPU));
      const j0 = Math.max(0, Math.floor((lz - R) / STEPU)), j1 = Math.min(N - 1, Math.ceil((lz + R) / STEPU));
      for (let j = j0; j <= j1; j++)
        for (let i = i0; i <= i1; i++) {
          const d = Math.hypot(i * STEPU - lx, j * STEPU - lz);
          if (d < R) {
            const f = 1 - st * (1 - d / R);
            const v = (j * N + i) * 3;
            col[v] *= f; col[v + 1] *= f; col[v + 2] *= f;
          }
        }
    }
    const per = perimeter();
    for (let k = 0; k < per.length; k++) {
      const src = per[k] * 3, dst = (N * N + k) * 3;
      pos[dst] = pos[src]; pos[dst + 1] = pos[src + 1] - 5; pos[dst + 2] = pos[src + 2];
      nor[dst] = nor[src]; nor[dst + 1] = nor[src + 1]; nor[dst + 2] = nor[src + 2];
      col[dst] = col[src] * 0.8; col[dst + 1] = col[src + 1] * 0.8; col[dst + 2] = col[src + 2] * 0.8;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    geo.setAttribute("normal", new THREE.BufferAttribute(nor, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
    if (!INDEX) INDEX = buildIndex();
    geo.setIndex(INDEX);
    geo.computeBoundingSphere();
    const tm = new THREE.Mesh(geo, this.mats.terrain);
    tm.receiveShadow = this.shadows;
    ch.group.add(tm);
    ch.meshes.push(tm);

    if (veg.count) {
      const vm = new THREE.Mesh(veg.build(true), this.mats.veg);
      vm.castShadow = this.shadows;
      vm.receiveShadow = this.shadows;
      ch.group.add(vm);
      ch.meshes.push(vm);
    }
    if (grass.count) {
      const gm = new THREE.Mesh(grass.build(true), this.mats.veg);
      ch.group.add(gm);
      ch.meshes.push(gm);
      ch.grass = gm;
    }
    this.parent.add(ch.group);
    this.chunks.set(this.key(cx, cz), ch);
  }
}

function heightLocal(H: Float32Array, lx: number, lz: number) {
  let i = Math.floor(lx / STEPU), j = Math.floor(lz / STEPU);
  i = Math.min(CHUNK_RES - 1, Math.max(0, i));
  j = Math.min(CHUNK_RES - 1, Math.max(0, j));
  const fx = lx / STEPU - i, fz = lz / STEPU - j;
  const a = H[j * N + i], b = H[j * N + i + 1], c = H[(j + 1) * N + i], d = H[(j + 1) * N + i + 1];
  if (fx + fz <= 1) return a + (b - a) * fx + (c - a) * fz;
  return d + (c - d) * (1 - fx) + (b - d) * (1 - fz);
}

// ---------------- Far terrain LOD + minimap ----------------
const FR = 128;
const FS = (WORLD_HALF * 2) / FR;
const FN = FR + 1;

export class FarTerrain {
  mesh: THREE.Mesh;
  geo: THREE.BufferGeometry;
  mapCanvas: HTMLCanvasElement;
  constructor(mat: THREE.Material) {
    const pos = new Float32Array(FN * FN * 3);
    const col = new Float32Array(FN * FN * 3);
    const hs = new Float32Array(FN * FN);
    const smp: Sample[] = [];
    const s = newSample();
    for (let j = 0; j < FN; j++)
      for (let i = 0; i < FN; i++) {
        const x = -WORLD_HALF + i * FS, z = -WORLD_HALF + j * FS;
        sampleTerrain(x, z, s);
        hs[j * FN + i] = s.h;
        smp.push({ ...s });
      }
    const map = document.createElement("canvas");
    map.width = FR;
    map.height = FR;
    const ctx = map.getContext("2d")!;
    const img = ctx.createImageData(FR, FR);
    for (let j = 0; j < FN; j++)
      for (let i = 0; i < FN; i++) {
        const v = j * FN + i;
        const x = -WORLD_HALF + i * FS, z = -WORLD_HALF + j * FS;
        const hL = hs[j * FN + Math.max(0, i - 1)], hR = hs[j * FN + Math.min(FN - 1, i + 1)];
        const hD = hs[Math.max(0, j - 1) * FN + i], hU = hs[Math.min(FN - 1, j + 1) * FN + i];
        const slope = Math.sqrt((hR - hL) ** 2 + (hU - hD) ** 2) / (2 * FS);
        pos[v * 3] = x; pos[v * 3 + 1] = hs[v] - 0.4; pos[v * 3 + 2] = z;
        const sm = smp[v];
        terrainColor(sm, slope, x, z, col, v * 3);
        // canopy tint for forests seen from far
        const f = Math.min(1, sm.forest * 1.1 + sm.light * 0.35 + Math.max(sm.plateau, sm.mount) * 0.3 * (sm.h < 95 ? 1 : 0)) * (sm.road > 0.3 ? 0.3 : 1) * (1 - Math.min(1, slope));
        if (sm.h > sm.water) {
          col[v * 3] = col[v * 3] * (1 - f) + 0.15 * f;
          col[v * 3 + 1] = col[v * 3 + 1] * (1 - f) + 0.29 * f;
          col[v * 3 + 2] = col[v * 3 + 2] * (1 - f) + 0.14 * f;
        }
        if (i < FR && j < FR) {
          const p = (j * FR + i) * 4;
          const shade = 0.75 + Math.max(-0.25, Math.min(0.35, (hL - hR + hD - hU) * 0.02));
          let r = col[v * 3] * shade, g = col[v * 3 + 1] * shade, b = col[v * 3 + 2] * shade;
          if (sm.water > sm.h) { r = 0.22; g = 0.48; b = 0.62; }
          else if (sm.road > 0.3) { r = 0.72; g = 0.6; b = 0.42; }
          img.data[p] = Math.min(255, r * 255);
          img.data[p + 1] = Math.min(255, g * 255);
          img.data[p + 2] = Math.min(255, b * 255);
          img.data[p + 3] = 255;
        }
      }
    ctx.putImageData(img, 0, 0);
    this.mapCanvas = map;
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
    this.geo = geo;
    this.setHidden(new Set());
    geo.computeVertexNormals();
    geo.computeBoundingSphere();
    this.mesh = new THREE.Mesh(geo, mat);
    this.mesh.frustumCulled = false;
  }

  setHidden(hidden: Set<number>) {
    const idx: number[] = [];
    const per = CHUNK / FS; // far cells per chunk
    for (let j = 0; j < FR; j++)
      for (let i = 0; i < FR; i++) {
        const cx = Math.floor(i / per), cz = Math.floor(j / per);
        if (hidden.has(cz * 1000 + cx)) continue;
        const a = j * FN + i, b = a + 1, c = a + FN, d = c + 1;
        idx.push(a, c, b, b, c, d);
      }
    this.geo.setIndex(idx);
  }
}
