export const COLS = 11;
export const ROWS = 11;
export const CELL = 3.05;
export const WALL_T = 0.52;
export const WALL_H = 2.48;
export const PLAYER_R = 0.32;

export type Cell = { n: boolean; e: boolean; s: boolean; w: boolean };
export type Aabb = { minX: number; maxX: number; minZ: number; maxZ: number };
export type V2 = { x: number; z: number };

export type WorldData = {
  cells: Cell[];
  walls: Aabb[];
  gems: V2[];
  flowers: { x: number; z: number; kind: number }[];
  trees: { x: number; z: number; h: number; r: number }[];
  flies: { x: number; y: number; z: number; phase: number }[];
  startX: number;
  startZ: number;
  yaw: number;
  exitX: number;
  exitZ: number;
  exitC: number;
  exitR: number;
};

type Dir = "n" | "e" | "s" | "w";

const YAW: Record<Dir, number> = {
  n: 0,
  e: -Math.PI / 2,
  s: Math.PI,
  w: Math.PI / 2,
};

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffle<T>(arr: T[], rand: () => number) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = (rand() * (i + 1)) | 0;
    const tmp = arr[i];
    arr[i] = arr[j]!;
    arr[j] = tmp!;
  }
  return arr;
}

function idx(c: number, r: number) {
  return r * COLS + c;
}

function openBetween(cells: Cell[], i: number, j: number, dir: Dir) {
  const a = cells[i]!;
  const b = cells[j]!;
  if (dir === "n") {
    a.n = false;
    b.s = false;
  } else if (dir === "s") {
    a.s = false;
    b.n = false;
  } else if (dir === "e") {
    a.e = false;
    b.w = false;
  } else {
    a.w = false;
    b.e = false;
  }
}

function passageLength(cells: Cell[], index: number, dir: Dir) {
  let len = 0;
  let i = index;
  while (len < 40) {
    const c = i % COLS;
    const r = Math.floor(i / COLS);
    const cell = cells[i]!;
    if (dir === "n") {
      if (cell.n || r === 0) break;
      i -= COLS;
    } else if (dir === "s") {
      if (cell.s || r === ROWS - 1) break;
      i += COLS;
    } else if (dir === "w") {
      if (cell.w || c === 0) break;
      i -= 1;
    } else {
      if (cell.e || c === COLS - 1) break;
      i += 1;
    }
    len++;
  }
  return len;
}

function farthest(cells: Cell[], start: number) {
  const dist = new Int16Array(cells.length).fill(-1);
  const q = [start];
  dist[start] = 0;
  let far = start;
  let qi = 0;
  while (qi < q.length) {
    const i = q[qi++]!;
    if (dist[i]! > dist[far]!) far = i;
    const c = i % COLS;
    const r = Math.floor(i / COLS);
    const cell = cells[i]!;
    const step = (ni: number) => {
      if (dist[ni] !== -1) return;
      dist[ni] = dist[i]! + 1;
      q.push(ni);
    };
    if (!cell.n && r > 0) step(i - COLS);
    if (!cell.s && r < ROWS - 1) step(i + COLS);
    if (!cell.w && c > 0) step(i - 1);
    if (!cell.e && c < COLS - 1) step(i + 1);
  }
  return { far, dist };
}

function horizontalWall(cells: Cell[], c: number, edge: number) {
  if (edge === 0) return cells[c]!.n;
  if (edge === ROWS) return cells[(ROWS - 1) * COLS + c]!.s;
  return cells[edge * COLS + c]!.n;
}

function verticalWall(cells: Cell[], edge: number, r: number) {
  if (edge === 0) return cells[r * COLS]!.w;
  if (edge === COLS) return cells[r * COLS + COLS - 1]!.e;
  return cells[r * COLS + edge]!.w;
}

function pushBox(walls: Aabb[], cx: number, cz: number, sx: number, sz: number) {
  walls.push({
    minX: cx - sx / 2,
    maxX: cx + sx / 2,
    minZ: cz - sz / 2,
    maxZ: cz + sz / 2,
  });
}

export function buildWalls(cells: Cell[]) {
  const walls: Aabb[] = [];
  for (let edge = 0; edge <= ROWS; edge++) {
    let c = 0;
    while (c < COLS) {
      if (!horizontalWall(cells, c, edge)) {
        c++;
        continue;
      }
      let end = c;
      while (end + 1 < COLS && horizontalWall(cells, end + 1, edge)) end++;
      const x0 = c * CELL;
      const x1 = (end + 1) * CELL;
      pushBox(walls, (x0 + x1) / 2, edge * CELL, x1 - x0, WALL_T);
      c = end + 1;
    }
  }
  for (let edge = 0; edge <= COLS; edge++) {
    let r = 0;
    while (r < ROWS) {
      if (!verticalWall(cells, edge, r)) {
        r++;
        continue;
      }
      let end = r;
      while (end + 1 < ROWS && verticalWall(cells, edge, end + 1)) end++;
      const z0 = r * CELL;
      const z1 = (end + 1) * CELL;
      pushBox(walls, edge * CELL, (z0 + z1) / 2, WALL_T, z1 - z0);
      r = end + 1;
    }
  }
  return walls;
}

function centerOf(i: number) {
  const c = i % COLS;
  const r = Math.floor(i / COLS);
  return { c, r, x: (c + 0.5) * CELL, z: (r + 0.5) * CELL };
}

function wallCount(cell: Cell) {
  return Number(cell.n) + Number(cell.e) + Number(cell.s) + Number(cell.w);
}

export function generateMaze(seed: number): WorldData {
  const rand = mulberry32(seed || 1);
  const cells: Cell[] = Array.from({ length: COLS * ROWS }, () => ({
    n: true,
    e: true,
    s: true,
    w: true,
  }));
  const seen = new Uint8Array(cells.length);
  const stack = [0];
  seen[0] = 1;
  while (stack.length) {
    const i = stack[stack.length - 1]!;
    const c = i % COLS;
    const r = Math.floor(i / COLS);
    const neigh: { i: number; dir: Dir }[] = [];
    if (r > 0 && !seen[i - COLS]) neigh.push({ i: i - COLS, dir: "n" });
    if (r < ROWS - 1 && !seen[i + COLS]) neigh.push({ i: i + COLS, dir: "s" });
    if (c > 0 && !seen[i - 1]) neigh.push({ i: i - 1, dir: "w" });
    if (c < COLS - 1 && !seen[i + 1]) neigh.push({ i: i + 1, dir: "e" });
    if (!neigh.length) {
      stack.pop();
      continue;
    }
    const pick = neigh[(rand() * neigh.length) | 0]!;
    openBetween(cells, i, pick.i, pick.dir);
    seen[pick.i] = 1;
    stack.push(pick.i);
  }

  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const i = idx(c, r);
      if (c < COLS - 1 && cells[i]!.e && rand() < 0.14) openBetween(cells, i, i + 1, "e");
      if (r < ROWS - 1 && cells[i]!.s && rand() < 0.14) openBetween(cells, i, i + COLS, "s");
    }
  }

  let bestI = 0;
  let bestDir: Dir = "s";
  let bestLen = -1;
  const dirs: Dir[] = ["n", "e", "s", "w"];
  for (let i = 0; i < cells.length; i++) {
    for (const dir of dirs) {
      const len = passageLength(cells, i, dir);
      if (len > bestLen) {
        bestLen = len;
        bestI = i;
        bestDir = dir;
      }
    }
  }

  if (bestLen < 4) {
    const r = 5;
    for (let c = 1; c <= 5; c++) openBetween(cells, idx(c, r), idx(c + 1, r), "e");
    bestI = idx(1, r);
    bestDir = "e";
  }

  const start = centerOf(bestI);
  const { far, dist } = farthest(cells, bestI);
  const exit = centerOf(far);

  const dead: number[] = [];
  const other: number[] = [];
  for (let i = 0; i < cells.length; i++) {
    if (i === bestI || i === far) continue;
    if (dist[i]! < 2) continue;
    if (wallCount(cells[i]!) >= 3) dead.push(i);
    else if (dist[i]! >= 4) other.push(i);
  }
  shuffle(dead, rand);
  shuffle(other, rand);
  const gemIdx = [...dead, ...other].slice(0, 9);
  const gems = gemIdx.map((i) => {
    const p = centerOf(i);
    return { x: p.x, z: p.z };
  });
  const taken = new Set<number>([bestI, far, ...gemIdx]);

  const flowers: WorldData["flowers"] = [];
  for (let i = 0; i < cells.length && flowers.length < 8; i++) {
    if (taken.has(i) || rand() > 0.22) continue;
    const cell = cells[i]!;
    const p = centerOf(i);
    const options: Array<[number, number]> = [];
    const d = 0.92;
    if (cell.n) options.push([0, -d]);
    if (cell.s) options.push([0, d]);
    if (cell.w) options.push([-d, 0]);
    if (cell.e) options.push([d, 0]);
    if (!options.length) continue;
    const off = options[(rand() * options.length) | 0]!;
    flowers.push({ x: p.x + off[0], z: p.z + off[1], kind: (rand() * 3) | 0 });
    taken.add(i);
  }

  const trees: WorldData["trees"] = [];
  const W = COLS * CELL;
  const H = ROWS * CELL;
  for (let k = 0; k < 14; k++) {
    const side = k % 4;
    const t = rand();
    let x = 0;
    let z = 0;
    const out = 2.15 + rand() * 1.7;
    if (side === 0) {
      x = -out;
      z = t * H;
    } else if (side === 1) {
      x = W + out;
      z = t * H;
    } else if (side === 2) {
      x = t * W;
      z = -out;
    } else {
      x = t * W;
      z = H + out;
    }
    trees.push({ x, z, h: 1.5 + rand() * 1.5, r: 0.55 + rand() * 0.4 });
  }

  const flies: WorldData["flies"] = [];
  for (let n = 0; n < 16; n++) {
    const i = (rand() * cells.length) | 0;
    const p = centerOf(i);
    flies.push({
      x: p.x + (rand() - 0.5) * 0.8,
      y: 1.15 + rand() * 0.9,
      z: p.z + (rand() - 0.5) * 0.8,
      phase: rand() * Math.PI * 2,
    });
  }

  return {
    cells,
    walls: buildWalls(cells),
    gems,
    flowers,
    trees,
    flies,
    startX: start.x,
    startZ: start.z,
    yaw: YAW[bestDir],
    exitX: exit.x,
    exitZ: exit.z,
    exitC: exit.c,
    exitR: exit.r,
  };
}

const SKIN = 0.018;

export function resolveCircle(x: number, z: number, r: number, walls: Aabb[]) {
  let px = x;
  let pz = z;
  for (let pass = 0; pass < 4; pass++) {
    for (const b of walls) {
      if (px > b.maxX + r || px < b.minX - r || pz > b.maxZ + r || pz < b.minZ - r) continue;
      const cx = Math.min(Math.max(px, b.minX), b.maxX);
      const cz = Math.min(Math.max(pz, b.minZ), b.maxZ);
      let dx = px - cx;
      let dz = pz - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 >= r * r) continue;
      if (d2 > 1e-10) {
        const d = Math.sqrt(d2);
        const push = r - d + SKIN;
        px += (dx / d) * push;
        pz += (dz / d) * push;
      } else {
        const left = px - b.minX;
        const right = b.maxX - px;
        const north = pz - b.minZ;
        const south = b.maxZ - pz;
        const m = Math.min(left, right, north, south);
        if (m === left) px = b.minX - r - SKIN;
        else if (m === right) px = b.maxX + r + SKIN;
        else if (m === north) pz = b.minZ - r - SKIN;
        else pz = b.maxZ + r + SKIN;
      }
    }
  }
  return { x: px, z: pz };
}

export function circleHits(x: number, z: number, r: number, walls: Aabb[]) {
  const pad = r - 0.001;
  for (const b of walls) {
    if (x > b.maxX + pad || x < b.minX - pad || z > b.maxZ + pad || z < b.minZ - pad) continue;
    const cx = Math.min(Math.max(x, b.minX), b.maxX);
    const cz = Math.min(Math.max(z, b.minZ), b.maxZ);
    const dx = x - cx;
    const dz = z - cz;
    if (dx * dx + dz * dz < pad * pad) return true;
  }
  return false;
}

export function cellOf(x: number, z: number) {
  const c = Math.min(COLS - 1, Math.max(0, Math.floor(x / CELL)));
  const r = Math.min(ROWS - 1, Math.max(0, Math.floor(z / CELL)));
  return { c, r };
}

/** Basis: yaw 0 looks toward world −Z. +yaw is CCW about +Y. */
export function basis(yaw: number) {
  return {
    fx: -Math.sin(yaw),
    fz: -Math.cos(yaw),
    rx: Math.cos(yaw),
    rz: -Math.sin(yaw),
  };
}

export function selfCheck() {
  for (let seed = 1; seed <= 24; seed++) {
    const world = generateMaze(seed);
    for (let i = 0; i < world.cells.length; i++) {
      const c = i % COLS;
      const r = Math.floor(i / COLS);
      const x = (c + 0.5) * CELL;
      const z = (r + 0.5) * CELL;
      if (circleHits(x, z, PLAYER_R, world.walls)) {
        throw new Error(`seed ${seed} cell ${c},${r} center is inside a wall`);
      }
    }
    if (circleHits(world.startX, world.startZ, PLAYER_R, world.walls)) {
      throw new Error(`seed ${seed} start overlaps a wall`);
    }
    const { fx, fz } = basis(world.yaw);
    let x = world.startX;
    let z = world.startZ;
    for (let s = 0; s < 18; s++) {
      const next = resolveCircle(x + fx * 0.22, z + fz * 0.22, PLAYER_R, world.walls);
      if (circleHits(next.x, next.z, PLAYER_R * 0.98, world.walls)) {
        throw new Error(`seed ${seed} tunneled at step ${s}`);
      }
      x = next.x;
      z = next.z;
    }
    const progressed = (x - world.startX) * fx + (z - world.startZ) * fz;
    if (progressed < 0.8) {
      throw new Error(`seed ${seed} forward passage blocked (${progressed.toFixed(2)})`);
    }
  }

  const world = generateMaze(3);
  const shoved = resolveCircle(0.05, CELL * 0.5, PLAYER_R, world.walls);
  if (shoved.x < WALL_T / 2 + PLAYER_R - 0.02) {
    throw new Error(`outer wall failed to hold, x=${shoved.x}`);
  }
  return "maze ok";
}
