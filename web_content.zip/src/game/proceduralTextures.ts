import * as THREE from 'three';

/**
 * Creates procedural textures for authentic Indian home environment.
 * Complies with Three.js skill: SRGBColorSpace, zero 404 dependencies.
 */

// 1. Indian Rangoli Carpet / Rug Texture
export function createRangoliRugTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Deep royal maroon background
  ctx.fillStyle = '#831843';
  ctx.fillRect(0, 0, 512, 512);

  // Intricate borders
  ctx.strokeStyle = '#f59e0b';
  ctx.lineWidth = 14;
  ctx.strokeRect(16, 16, 480, 480);

  ctx.strokeStyle = '#fbbf24';
  ctx.lineWidth = 4;
  ctx.strokeRect(32, 32, 448, 448);

  // Central Mandala
  const cx = 256;
  const cy = 256;

  // Outer lotus petals
  ctx.save();
  ctx.translate(cx, cy);
  const petals = 16;
  for (let i = 0; i < petals; i++) {
    ctx.rotate((Math.PI * 2) / petals);
    ctx.fillStyle = i % 2 === 0 ? '#ef4444' : '#f97316';
    ctx.beginPath();
    ctx.ellipse(0, 130, 22, 60, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#fef08a';
    ctx.lineWidth = 3;
    ctx.stroke();
  }

  // Inner rings
  ctx.fillStyle = '#d97706';
  ctx.beginPath();
  ctx.arc(0, 0, 95, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#fde047';
  ctx.beginPath();
  ctx.arc(0, 0, 65, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#b91c1c';
  ctx.beginPath();
  ctx.arc(0, 0, 32, 0, Math.PI * 2);
  ctx.fill();

  // Corner floral motifs
  ctx.restore();
  const corners = [
    [70, 70],
    [442, 70],
    [70, 442],
    [442, 442],
  ];
  corners.forEach(([x, y]) => {
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.arc(x, y, 28, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#b91c1c';
    ctx.beginPath();
    ctx.arc(x, y, 14, 0, Math.PI * 2);
    ctx.fill();
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// 2. Warm Teak Wood Texture
export function createTeakWoodTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#78350f';
  ctx.fillRect(0, 0, 256, 256);

  // Wood grain lines
  ctx.strokeStyle = '#451a03';
  ctx.lineWidth = 2;
  for (let y = 0; y < 256; y += 8) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(80, y + 4, 180, y - 4, 256, y + 2);
    ctx.globalAlpha = 0.35 + Math.random() * 0.25;
    ctx.stroke();
  }
  ctx.globalAlpha = 1.0;

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// 3. Indian Marble / Tile Floor Texture
export function createFloorTileTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#fef3c7'; // warm creamy marble
  ctx.fillRect(0, 0, 512, 512);

  // Subtle marble veins
  ctx.strokeStyle = '#fde68a';
  ctx.lineWidth = 3;
  ctx.globalAlpha = 0.45;
  for (let i = 0; i < 6; i++) {
    ctx.beginPath();
    ctx.moveTo(Math.random() * 512, 0);
    ctx.bezierCurveTo(
      Math.random() * 512,
      170,
      Math.random() * 512,
      340,
      Math.random() * 512,
      512
    );
    ctx.stroke();
  }

  // Tile grid seams
  ctx.globalAlpha = 0.3;
  ctx.strokeStyle = '#d97706';
  ctx.lineWidth = 3;
  for (let x = 0; x <= 512; x += 128) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 512);
    ctx.stroke();
  }
  for (let y = 0; y <= 512; y += 128) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 4);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// 4. Family Portrait Wall Painting Texture
export function createFamilyPortraitTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 320;
  const ctx = canvas.getContext('2d')!;

  // Warm studio background with gold gradient
  const grad = ctx.createLinearGradient(0, 0, 512, 320);
  grad.addColorStop(0, '#fef08a');
  grad.addColorStop(1, '#fed7aa');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 320);

  // Ornate decorative border
  ctx.strokeStyle = '#b45309';
  ctx.lineWidth = 12;
  ctx.strokeRect(6, 6, 500, 308);

  // Header Title
  ctx.fillStyle = '#7c2d12';
  ctx.font = 'bold 22px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('OUR HAPPY FAMILY ❤️', 256, 42);

  // Cartoon caricatures of the 5 family members:
  // Mr. Ripin (Dad), Mrs. Anjeeta (Mom), Ayush (center), Arav (left kid), Akshhara (right kid)
  const drawFace = (x: number, y: number, r: number, color: string, hairColor: string, label: string) => {
    // Face
    ctx.fillStyle = '#fed7aa';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();

    // Hair
    ctx.fillStyle = hairColor;
    ctx.beginPath();
    ctx.arc(x, y - 6, r * 1.05, Math.PI, 0, false);
    ctx.fill();

    // Eyes
    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.arc(x - r * 0.35, y - 2, 3, 0, Math.PI * 2);
    ctx.arc(x + r * 0.35, y - 2, 3, 0, Math.PI * 2);
    ctx.fill();

    // Smile
    ctx.strokeStyle = '#b91c1c';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(x, y + 4, r * 0.45, 0.2, Math.PI - 0.2);
    ctx.stroke();

    // Clothes torso
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.ellipse(x, y + r + 26, r * 1.3, 24, 0, 0, Math.PI * 2);
    ctx.fill();

    // Label
    ctx.fillStyle = '#451a03';
    ctx.font = 'bold 13px sans-serif';
    ctx.fillText(label, x, y + r + 60);
  };

  // Dad (Mr. Ripin) - Left Adult
  drawFace(120, 140, 34, '#3b82f6', '#1e293b', 'Papa (Ripin)');
  // Mustache on Dad
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(106, 148, 28, 6);

  // Mom (Mrs. Anjeeta) - Right Adult
  drawFace(392, 140, 34, '#ec4899', '#0f172a', 'Mummy (Anjeeta)');
  // Red Bindi on Mom
  ctx.fillStyle = '#dc2626';
  ctx.beginPath();
  ctx.arc(392, 126, 3.5, 0, Math.PI * 2);
  ctx.fill();

  // Ayush (Hero) - Center
  drawFace(256, 160, 32, '#0ea5e9', '#09090b', 'Ayush (Hero)');

  // Arav - Little brother (Left)
  drawFace(180, 210, 24, '#f97316', '#18181b', 'Arav');

  // Akshhara - Sister (Right)
  drawFace(332, 210, 24, '#a855f7', '#18181b', 'Akshhara');
  // Twin hair ribbons for Akshhara
  ctx.fillStyle = '#f43f5e';
  ctx.beginPath();
  ctx.arc(308, 192, 6, 0, Math.PI * 2);
  ctx.arc(356, 192, 6, 0, Math.PI * 2);
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// 5. TV Screen Texture (Active cartoon sitcom / cricket match)
export function createTVScreenTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 288;
  const ctx = canvas.getContext('2d')!;

  // Dynamic colorful broadcast screen
  const grad = ctx.createLinearGradient(0, 0, 512, 288);
  grad.addColorStop(0, '#0284c7');
  grad.addColorStop(1, '#0f172a');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 288);

  // Broadcast banner
  ctx.fillStyle = '#ef4444';
  ctx.fillRect(0, 0, 512, 38);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 20px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('LIVE: CRICKET vs CARTOON DERBY! 🏆', 256, 26);

  // Comic TV face-off
  ctx.fillStyle = '#fbbf24';
  ctx.font = 'bold 36px sans-serif';
  ctx.fillText('🏏 Arav vs Akshhara 📺', 256, 120);

  ctx.fillStyle = '#38bdf8';
  ctx.font = 'italic 20px sans-serif';
  ctx.fillText('"The TV Remote is Missing!"', 256, 160);

  ctx.fillStyle = '#4ade80';
  ctx.font = 'bold 18px sans-serif';
  ctx.fillText('Ayush Family Adventure Channel 7', 256, 230);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// 6. Masala Dabba (Indian Spice Box) Texture
export function createMasalaDabbaTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  // Shiny stainless steel tray
  ctx.fillStyle = '#cbd5e1';
  ctx.fillRect(0, 0, 256, 256);

  // 7 spice bowls
  const spices = [
    { color: '#eab308', name: 'Turmeric' }, // Haldi
    { color: '#dc2626', name: 'Chili' }, // Lal Mirch
    { color: '#84cc16', name: 'Coriander' }, // Dhaniya
    { color: '#78350f', name: 'Cumin' }, // Jeera
    { color: '#f59e0b', name: 'Garam Masala' },
    { color: '#451a03', name: 'Mustard' }, // Rai
    { color: '#f8fafc', name: 'Salt' }, // Namak
  ];

  const cx = 128;
  const cy = 128;
  // Center bowl
  ctx.fillStyle = spices[0].color;
  ctx.beginPath();
  ctx.arc(cx, cy, 32, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#94a3b8';
  ctx.lineWidth = 4;
  ctx.stroke();

  // 6 perimeter bowls
  for (let i = 1; i <= 6; i++) {
    const angle = ((i - 1) * Math.PI * 2) / 6;
    const bx = cx + Math.cos(angle) * 72;
    const by = cy + Math.sin(angle) * 72;

    ctx.fillStyle = spices[i].color;
    ctx.beginPath();
    ctx.arc(bx, by, 28, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 4;
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}
