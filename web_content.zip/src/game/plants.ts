export type PlantKind = "stalk" | "root" | "bush" | "flower" | "fruit";

export type Plant = {
  id: string;
  name: string;
  rarity: "comum" | "incomum" | "raro" | "épico" | "lendário";
  growTime: number;
  seedCost: number;
  sellValue: number;
  color: number;
  kind: PlantKind;
};

export const PLANTS: Plant[] = [
  { id: "wheat", name: "Trigo", rarity: "comum", growTime: 12, seedCost: 10, sellValue: 26, color: 0xe2b034, kind: "stalk" },
  { id: "carrot", name: "Cenoura", rarity: "comum", growTime: 14, seedCost: 12, sellValue: 30, color: 0xe07a2f, kind: "root" },
  { id: "potato", name: "Batata", rarity: "comum", growTime: 16, seedCost: 14, sellValue: 36, color: 0xc4a574, kind: "root" },
  { id: "tomato", name: "Tomate", rarity: "comum", growTime: 18, seedCost: 18, sellValue: 46, color: 0xd4534a, kind: "bush" },
  { id: "corn", name: "Milho", rarity: "comum", growTime: 20, seedCost: 20, sellValue: 52, color: 0xe2c04a, kind: "stalk" },
  { id: "strawberry", name: "Morango", rarity: "incomum", growTime: 26, seedCost: 36, sellValue: 96, color: 0xd4534a, kind: "bush" },
  { id: "pumpkin", name: "Abóbora", rarity: "incomum", growTime: 32, seedCost: 48, sellValue: 130, color: 0xe07a2f, kind: "fruit" },
  { id: "blueberry", name: "Mirtilo", rarity: "raro", growTime: 42, seedCost: 80, sellValue: 230, color: 0x3d6fbf, kind: "bush" },
  { id: "sunflower", name: "Girassol", rarity: "raro", growTime: 38, seedCost: 90, sellValue: 260, color: 0xe2c04a, kind: "flower" },
  { id: "dragonfruit", name: "Pitaya", rarity: "épico", growTime: 58, seedCost: 220, sellValue: 720, color: 0xd4536a, kind: "fruit" },
  { id: "astral_lotus", name: "Lótus Astral", rarity: "lendário", growTime: 90, seedCost: 1200, sellValue: 4800, color: 0x7ebfdf, kind: "flower" },
];

export const PLANT_BY_ID: Record<string, Plant> = Object.fromEntries(PLANTS.map((p) => [p.id, p]));

export const APPLE_COST = 8;

export const HOTBAR: { id: number; type: "seed" | "tool" | "food"; itemId: string; label: string }[] = [
  { id: 1, type: "seed", itemId: "wheat", label: "Trigo" },
  { id: 2, type: "seed", itemId: "carrot", label: "Cenoura" },
  { id: 3, type: "seed", itemId: "tomato", label: "Tomate" },
  { id: 4, type: "seed", itemId: "corn", label: "Milho" },
  { id: 5, type: "tool", itemId: "water", label: "Regador" },
  { id: 6, type: "food", itemId: "apple", label: "Maçã" },
];

export const SAVE_KEY = "ecovalley-v1";

export const WORLD = {
  spawn: { x: -14, z: 50 },
  shop: { x: -20, z: -99 },
  market: { x: 20, z: -99 },
  farm: { x: -18, z: 34 },
  cottage: { x: -14, z: 66 },
};

export const FORAGE_LOOT = ["wheat", "carrot", "potato", "tomato", "strawberry", "corn"];

export function cleanName(raw: string): string {
  const t = raw.replace(/[<>]/g, "").trim().slice(0, 16);
  return t || "Oliver";
}
