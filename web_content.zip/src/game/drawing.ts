/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Point, LevelData } from './types';
import {
  createShapeTemplatePolygon,
  generatePuzzleFromShape,
  recognizeDrawnShape,
} from './generator';
import { validateAndEvaluatePuzzle } from './solver';
import { sound } from './audio';

/**
 * Applies gentle smoothing to a freehand stroke while preserving closure
 */
function smoothStroke(points: Point[]): Point[] {
  if (points.length < 5) return points;
  const result: Point[] = [];
  const n = points.length;
  for (let i = 0; i < n; i++) {
    const p0 = points[i];
    const p1 = points[(i + 1) % n];
    result.push({
      x: 0.75 * p0.x + 0.25 * p1.x,
      y: 0.75 * p0.y + 0.25 * p1.y,
    });
    result.push({
      x: 0.25 * p0.x + 0.75 * p1.x,
      y: 0.25 * p0.y + 0.75 * p1.y,
    });
  }
  return result;
}

export class ShapeDrawingBoard {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private isDrawing: boolean = false;
  private currentStroke: Point[] = [];
  private history: Point[][] = [];
  private currentShapePolygon: Point[] = [];
  private selectedTemplate: 'freehand' | 'circle' | 'square' | 'triangle' | 'star' | 'heart' =
    'freehand';
  private targetArrows: number = 14;
  private dpr: number = 1;
  private activePointerId: number | null = null;

  public onShapeChange?: (info: { hasShape: boolean; recognized: string }) => void;

  private onResizeBound = () => this.handleResize();

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Could not get 2D context for drawing');
    this.ctx = ctx;
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);

    this.bindEvents();
    this.handleResize();
  }

  public setTargetArrows(count: number) {
    this.targetArrows = Math.max(6, Math.min(30, count));
  }

  public getTargetArrows(): number {
    return this.targetArrows;
  }

  public handleResize() {
    const rect = this.canvas.getBoundingClientRect();
    const w = Math.floor(rect.width);
    const h = Math.floor(rect.height);

    if (w === 0 || h === 0) return;

    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = w * this.dpr;
    this.canvas.height = h * this.dpr;

    this.render();
  }

  public setTemplate(template: 'freehand' | 'circle' | 'square' | 'triangle' | 'star' | 'heart') {
    this.selectedTemplate = template;
    sound.playClick();

    if (template === 'freehand') {
      this.currentStroke = [];
      this.currentShapePolygon = [];
      this.notifyShapeChange();
      this.render();
      return;
    }

    const rect = this.canvas.getBoundingClientRect();
    const w = rect.width || 320;
    const h = rect.height || 320;
    const cx = w / 2;
    const cy = h / 2;
    const radius = Math.min(w, h) * 0.38;

    const points = createShapeTemplatePolygon(template, cx, cy, radius);
    this.currentShapePolygon = points;
    this.history.push([...points]);
    this.notifyShapeChange();
    this.render();
  }

  public undo() {
    sound.playClick();
    if (this.history.length > 0) {
      this.history.pop();
      this.currentShapePolygon =
        this.history.length > 0 ? [...this.history[this.history.length - 1]] : [];
      this.notifyShapeChange();
      this.render();
    }
  }

  public clear() {
    sound.playClick();
    this.history = [];
    this.currentStroke = [];
    this.currentShapePolygon = [];
    this.selectedTemplate = 'freehand';
    this.notifyShapeChange();
    this.render();
  }

  public hasValidShape(): boolean {
    return this.currentShapePolygon.length >= 3;
  }

  /**
   * Generates and validates a playable puzzle directly from the drawn polygon,
   * preserving the original drawn shape boundary and assigning `levelNumber`.
   */
  public generatePuzzle(levelNumber: number): LevelData | null {
    if (this.currentShapePolygon.length < 3) {
      return null;
    }

    sound.playClick();

    const shapeType =
      this.selectedTemplate !== 'freehand'
        ? this.selectedTemplate
        : recognizeDrawnShape(this.currentShapePolygon);

    const label =
      shapeType === 'freehand'
        ? 'Custom Shape'
        : shapeType.charAt(0).toUpperCase() + shapeType.slice(1);

    const level = generatePuzzleFromShape(
      this.currentShapePolygon,
      this.targetArrows,
      levelNumber,
      `${label} · Level ${levelNumber}`,
      shapeType
    );

    const validation = validateAndEvaluatePuzzle(level.arrows);
    if (!validation.valid || !validation.metrics.solvable) {
      return null;
    }

    return level;
  }

  public getPolygon(): Point[] {
    return this.currentShapePolygon;
  }

  private notifyShapeChange() {
    if (!this.onShapeChange) return;
    if (this.currentShapePolygon.length < 3) {
      this.onShapeChange({ hasShape: false, recognized: 'Draw a closed shape' });
      return;
    }
    const shape =
      this.selectedTemplate !== 'freehand'
        ? this.selectedTemplate
        : recognizeDrawnShape(this.currentShapePolygon);
    const label =
      shape === 'freehand'
        ? 'Custom Closed Shape'
        : shape.charAt(0).toUpperCase() + shape.slice(1);
    this.onShapeChange({ hasShape: true, recognized: label });
  }

  private bindEvents() {
    window.addEventListener('resize', this.onResizeBound);

    const getCanvasPos = (clientX: number, clientY: number): Point => {
      const rect = this.canvas.getBoundingClientRect();
      return {
        x: Math.max(8, Math.min(rect.width - 8, clientX - rect.left)),
        y: Math.max(8, Math.min(rect.height - 8, clientY - rect.top)),
      };
    };

    const startDraw = (pt: Point, pointerId: number) => {
      this.activePointerId = pointerId;
      this.isDrawing = true;
      this.selectedTemplate = 'freehand';
      this.currentStroke = [pt];
      this.currentShapePolygon = [pt];
      this.render();
    };

    const moveDraw = (pt: Point) => {
      if (!this.isDrawing) return;
      const last = this.currentStroke[this.currentStroke.length - 1];
      if (last && Math.hypot(pt.x - last.x, pt.y - last.y) < 4) return;

      this.currentStroke.push(pt);
      this.currentShapePolygon = [...this.currentStroke];
      this.render();
    };

    const endDraw = () => {
      if (!this.isDrawing) return;
      this.isDrawing = false;
      this.activePointerId = null;

      if (this.currentStroke.length >= 4) {
        // Gentle smoothing for organic finger strokes while keeping corners on sparse strokes
        const smoothed =
          this.currentStroke.length > 14
            ? smoothStroke(this.currentStroke)
            : [...this.currentStroke];

        this.currentShapePolygon = smoothed;
        this.history.push([...this.currentShapePolygon]);
      } else {
        // Too small to form a closed shape
        this.currentStroke = [];
        this.currentShapePolygon =
          this.history.length > 0 ? [...this.history[this.history.length - 1]] : [];
      }

      this.notifyShapeChange();
      this.render();
    };

    this.canvas.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      if (this.canvas.setPointerCapture) {
        try {
          this.canvas.setPointerCapture(e.pointerId);
        } catch {
          // ignore
        }
      }
      startDraw(getCanvasPos(e.clientX, e.clientY), e.pointerId);
    });

    this.canvas.addEventListener('pointermove', (e) => {
      if (this.isDrawing && e.pointerId === this.activePointerId) {
        e.preventDefault();
        moveDraw(getCanvasPos(e.clientX, e.clientY));
      }
    });

    this.canvas.addEventListener('pointerup', (e) => {
      if (this.isDrawing && e.pointerId === this.activePointerId) {
        endDraw();
      }
    });

    this.canvas.addEventListener('pointercancel', (e) => {
      if (this.isDrawing && e.pointerId === this.activePointerId) {
        endDraw();
      }
    });
  }

  public destroy() {
    window.removeEventListener('resize', this.onResizeBound);
  }

  private render() {
    const ctx = this.ctx;
    const w = this.canvas.width / this.dpr;
    const h = this.canvas.height / this.dpr;

    ctx.save();
    ctx.scale(this.dpr, this.dpr);

    // Pure white drawing board
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);

    // Dotted grid background matching gameplay board
    ctx.fillStyle = 'rgba(148, 163, 184, 0.35)';
    for (let x = 20; x < w; x += 22) {
      for (let y = 20; y < h; y += 22) {
        ctx.beginPath();
        ctx.arc(x, y, 1.2, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    if (this.currentShapePolygon.length < 3) {
      ctx.save();
      ctx.fillStyle = '#94A3B8';
      ctx.font = '500 13px "Plus Jakarta Sans", system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Draw any closed shape with your finger or mouse', w / 2, h / 2 - 10);
      ctx.fillText('or tap a preset below (Circle, Square, Triangle, Star, Heart)', w / 2, h / 2 + 12);
      ctx.restore();
    } else {
      ctx.save();
      ctx.beginPath();
      this.currentShapePolygon.forEach((pt, i) => {
        if (i === 0) ctx.moveTo(pt.x, pt.y);
        else ctx.lineTo(pt.x, pt.y);
      });
      if (!this.isDrawing) {
        ctx.closePath();
        ctx.fillStyle = 'rgba(219, 234, 254, 0.45)';
        ctx.fill();
      }

      ctx.strokeStyle = '#2563EB';
      ctx.lineWidth = 3.5;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.stroke();

      // Draw start-to-end closing preview dashed line while finger is down
      if (this.isDrawing && this.currentShapePolygon.length >= 2) {
        const first = this.currentShapePolygon[0];
        const last = this.currentShapePolygon[this.currentShapePolygon.length - 1];
        ctx.save();
        ctx.strokeStyle = 'rgba(37, 99, 235, 0.4)';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        ctx.beginPath();
        ctx.moveTo(last.x, last.y);
        ctx.lineTo(first.x, first.y);
        ctx.stroke();
        ctx.restore();
      }

      ctx.restore();
    }

    ctx.restore();
  }
}
