import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDistance,
  calculateFlightDuration,
  calculateFlightRevenue,
  interpolateLatLng,
  calculateBearing,
  getSpeedUpgradeCost,
  getMoneyMakerUpgradeCost,
  getNewPlaneCost,
  getPassengerCapacity,
  getInitialGameState,
  calculateOfflineEarnings,
  INITIAL_CITIES,
  redeemPromoCode,
  AVAILABLE_LIVERIES,
  calculateFlightFinancials,
  calculateAirlineRating
} from './flightLogic';

test('starter cities are San Francisco and Los Angeles', () => {
  const state = getInitialGameState();
  assert.equal(state.unlockedCityIds.length, 2);
  assert.ok(state.unlockedCityIds.includes('sfo'));
  assert.ok(state.unlockedCityIds.includes('lax'));
  assert.equal(state.planes.length, 1);
  assert.equal(state.planes[0].fromCityId, 'sfo');
  assert.equal(state.planes[0].toCityId, 'lax');
});

test('haversine distance calculates SFO to LAX correctly (~540km)', () => {
  const sfo = INITIAL_CITIES.find(c => c.id === 'sfo')!;
  const lax = INITIAL_CITIES.find(c => c.id === 'lax')!;
  const dist = calculateDistance(sfo.lat, sfo.lng, lax.lat, lax.lng);
  // SFO to LAX is ~543 km
  assert.ok(dist >= 530 && dist <= 560, `Distance was ${dist}`);
});

test('flight duration scales down with speed upgrades', () => {
  const baseDuration = calculateFlightDuration(540, 1);
  const upgradedDuration = calculateFlightDuration(540, 4);
  assert.ok(upgradedDuration < baseDuration, 'Upgraded plane should be faster');
  assert.ok(upgradedDuration >= 3.5, 'Duration should not drop below floor');
});

test('flight revenue increases with money maker and passenger capacity', () => {
  const baseRev = calculateFlightRevenue(540, 1, 1);
  const boostedRev = calculateFlightRevenue(540, 3, 1);
  const megaRev = calculateFlightRevenue(540, 3, 3);
  assert.ok(boostedRev > baseRev, 'Money maker upgrade should increase revenue');
  assert.ok(megaRev > boostedRev, 'Capacity upgrade should further increase revenue');
});

test('upgrade cost curves scale predictably', () => {
  const speedCost1 = getSpeedUpgradeCost(1);
  const speedCost2 = getSpeedUpgradeCost(2);
  const moneyCost1 = getMoneyMakerUpgradeCost(1);
  const planeCost1 = getNewPlaneCost(1);
  const planeCost2 = getNewPlaneCost(2);

  assert.equal(speedCost1, 60);
  assert.ok(speedCost2 > speedCost1);
  assert.equal(moneyCost1, 75);
  assert.equal(planeCost1, 350);
  assert.ok(planeCost2 > planeCost1);
});

test('passenger capacity increases with level', () => {
  assert.equal(getPassengerCapacity(1), 30);
  assert.ok(getPassengerCapacity(2) > 30);
});

test('straight line interpolation calculates mid-flight position accurately', () => {
  const p1 = { lat: 37.6, lng: -122.3 }; // SFO
  const p2 = { lat: 33.9, lng: -118.4 }; // LAX
  const mid = interpolateLatLng(p1.lat, p1.lng, p2.lat, p2.lng, 0.5);
  assert.ok(Math.abs(mid.lat - (37.6 + 33.9) / 2) < 0.001);
  assert.ok(Math.abs(mid.lng - (-122.3 + -118.4) / 2) < 0.001);

  const start = interpolateLatLng(p1.lat, p1.lng, p2.lat, p2.lng, 0);
  assert.equal(start.lat, p1.lat);
  assert.equal(start.lng, p1.lng);

  const end = interpolateLatLng(p1.lat, p1.lng, p2.lat, p2.lng, 1);
  assert.equal(end.lat, p2.lat);
  assert.equal(end.lng, p2.lng);
});

test('straight flight bearing calculation returns valid compass degrees', () => {
  // SFO to LAX is heading southeast (~140 deg)
  const bearing = calculateBearing(37.62, -122.38, 33.94, -118.41);
  assert.ok(bearing > 90 && bearing < 180, `Expected SE bearing, got ${bearing}`);
});

test('offline earnings properly calculates when returning', () => {
  const state = getInitialGameState();
  const oneHourAgo = Date.now() - 3600 * 1000;
  const { offlineEarnings, elapsedSeconds } = calculateOfflineEarnings(oneHourAgo, state);
  assert.equal(elapsedSeconds, 3600);
  assert.ok(offlineEarnings > 0, 'Should earn cash while offline');
});

test('code redemption unlocks Christmas livery with Winter26', () => {
  const state = getInitialGameState();
  assert.deepEqual(state.unlockedLiveryIds, ['default']);

  // Test code Winter26 (requested by user)
  const res = redeemPromoCode('Winter26', state);
  assert.equal(res.success, true);
  assert.equal(res.liveryId, 'christmas');
  assert.ok(res.message.includes('Christmas Flight skin 2026'));
  assert.ok((res.bonusCash ?? 0) > 0);

  // Test case-insensitivity and whitespace trimming
  const resTrimmed = redeemPromoCode('   winter26  ', state);
  assert.equal(resTrimmed.success, true);
  assert.equal(resTrimmed.liveryId, 'christmas');

  // Test backwards compatible alias
  const resAlias = redeemPromoCode('chris26', state);
  assert.equal(resAlias.success, true);
  assert.equal(resAlias.liveryId, 'christmas');

  // Test already redeemed check
  const stateWithRedeemed = {
    ...state,
    redeemedCodes: ['winter26']
  };
  const resDupe = redeemPromoCode('winter26', stateWithRedeemed);
  assert.equal(resDupe.success, false);
  assert.ok(resDupe.message.includes('already been redeemed'));

  // Test invalid promo code
  const resInvalid = redeemPromoCode('invalid_code_xyz', state);
  assert.equal(resInvalid.success, false);
  assert.ok(resInvalid.message.includes('Invalid code'));
});

test('available liveries catalog keeps ONLY default and Christmas Flight skin 2026', () => {
  assert.equal(AVAILABLE_LIVERIES.length, 2, 'Only default and Christmas skins should be present');
  const christmas = AVAILABLE_LIVERIES.find(l => l.id === 'christmas');
  assert.ok(christmas, 'Christmas livery must exist in catalog');
  assert.equal(christmas.name, 'Christmas Flight skin 2026');
  assert.equal(christmas.isHoliday, true);
  assert.ok(christmas.image, 'Christmas livery must reference uploaded asset');

  const defaultLivery = AVAILABLE_LIVERIES.find(l => l.id === 'default');
  assert.ok(defaultLivery, 'Default livery must exist');
});

test('calculateFlightFinancials accounts for fuel costs and passenger capacity', () => {
  const fin = calculateFlightFinancials(540, 1, 1, 1, 1, 1.0);
  assert.ok(fin.grossRevenue > 0);
  assert.ok(fin.fuelCost > 0);
  assert.ok(fin.netProfit > 0);
  assert.equal(fin.netProfit, fin.grossRevenue - fin.fuelCost);
  assert.equal(fin.passengers, 30);
});

test('calculateAirlineRating computes stars based on hubs, fleet, and continents', () => {
  const state = getInitialGameState();
  const rating1 = calculateAirlineRating(state);
  assert.ok(rating1.stars >= 1.0 && rating1.stars <= 5.0);
  assert.equal(rating1.continentsCount, 1); // North America

  // State with multiple continents and larger fleet
  const stateExpanded = {
    ...state,
    unlockedCityIds: ['sfo', 'lax', 'lhr', 'cdg', 'hnd', 'syd'],
    fleetCount: 5,
    planes: Array.from({ length: 5 }).map((_, i) => ({
      id: `plane-${i}`,
      name: `Aero 0${i}`,
      fromCityId: 'sfo',
      toCityId: 'lax',
      progress: 0,
      isReturning: false,
      status: 'flying' as const,
      totalFlightsCompleted: 10,
      totalEarnings: 500
    }))
  };
  const rating2 = calculateAirlineRating(stateExpanded);
  assert.ok(rating2.stars > rating1.stars);
  assert.ok(rating2.continentsCount >= 3);
});

test('no promo codes are leaked in AVAILABLE_LIVERIES descriptions', () => {
  for (const livery of AVAILABLE_LIVERIES) {
    assert.equal(livery.description.toLowerCase().includes('winter26'), false, 'livery description should not expose code');
    assert.equal(livery.unlockCondition.toLowerCase().includes('winter26'), false, 'unlock condition should not expose code');
    assert.equal(livery.description.toLowerCase().includes('chris26'), false);
  }
});

test('world airport network covers 58 major international airports across all 7 continents', () => {
  assert.equal(INITIAL_CITIES.length, 58);
  const continents = new Set(INITIAL_CITIES.map(c => c.continent));
  assert.ok(continents.has('North America'));
  assert.ok(continents.has('South America'));
  assert.ok(continents.has('Europe'));
  assert.ok(continents.has('Middle East'));
  assert.ok(continents.has('Asia'));
  assert.ok(continents.has('Oceania'));
  assert.ok(continents.has('Africa'));
});


