import * as THREE from "three";
import type { AABB, Actions } from "@/game/types";

const EYE = 1.62;
const RADIUS = 0.38;
const WALK = 4.35;
const SPRINT = 6.5;
const ACCEL = 22;
const FRICTION = 10;

export function resolveCircleAabb(x: number, z: number, r: number, box: AABB): { x: number; z: number } {
  const cx = Math.min(box.maxX, Math.max(box.minX, x));
  const cz = Math.min(box.maxZ, Math.max(box.minZ, z));
  let dx = x - cx;
  let dz = z - cz;
  const d2 = dx * dx + dz * dz;
  if (d2 >= r * r) return { x, z };
  if (d2 < 1e-8) {
    const left = x - box.minX;
    const right = box.maxX - x;
    const near = z - box.minZ;
    const far = box.maxZ - z;
    const m = Math.min(left, right, near, far);
    if (m === left) return { x: box.minX - r, z };
    if (m === right) return { x: box.maxX + r, z };
    if (m === near) return { x, z: box.minZ - r };
    return { x, z: box.maxZ + r };
  }
  const d = Math.sqrt(d2);
  const k = (r - d) / d;
  return { x: x + dx * k, z: z + dz * k };
}

export class Player {
  yaw = 0;
  pitch = 0;
  x = 0;
  y = EYE;
  z = 12;
  vx = 0;
  vz = 0;
  dist = 0;
  invuln = 0;
  health = 100;
  readonly pos = new THREE.Vector3();

  reset() {
    this.yaw = 0;
    this.pitch = 0;
    this.x = 0;
    this.z = 12;
    this.vx = 0;
    this.vz = 0;
    this.dist = 0;
    this.invuln = 0;
    this.health = 100;
  }

  get speed() {
    return Math.hypot(this.vx, this.vz);
  }

  look(dx: number, dy: number) {
    const s = 0.0022;
    this.yaw -= dx * s;
    this.pitch -= dy * s;
    const lim = Math.PI / 2 - 0.02;
    if (this.pitch > lim) this.pitch = lim;
    if (this.pitch < -lim) this.pitch = -lim;
  }

  update(dt: number, actions: Actions, colliders: AABB[]) {
    this.look(actions.lookDx, actions.lookDy);
    if (this.invuln > 0) this.invuln -= dt;

    const fx = -Math.sin(this.yaw);
    const fz = -Math.cos(this.yaw);
    const rx = Math.cos(this.yaw);
    const rz = -Math.sin(this.yaw);

    const wishX = rx * actions.moveX + fx * actions.moveY;
    const wishZ = rz * actions.moveX + fz * actions.moveY;
    const wishMag = Math.hypot(wishX, wishZ);
    const maxSpeed = actions.sprint ? SPRINT : WALK;
    let wx = 0;
    let wz = 0;
    if (wishMag > 1e-4) {
      wx = (wishX / wishMag) * maxSpeed;
      wz = (wishZ / wishMag) * maxSpeed;
    }

    if (wishMag > 0.05) {
      this.vx += (wx - this.vx) * Math.min(1, ACCEL * dt);
      this.vz += (wz - this.vz) * Math.min(1, ACCEL * dt);
    } else {
      const damp = Math.exp(-FRICTION * dt);
      this.vx *= damp;
      this.vz *= damp;
      if (Math.hypot(this.vx, this.vz) < 0.02) {
        this.vx = 0;
        this.vz = 0;
      }
    }

    this.x += this.vx * dt;
    this.z += this.vz * dt;
    for (const box of colliders) {
      const n = resolveCircleAabb(this.x, this.z, RADIUS, box);
      this.x = n.x;
      this.z = n.z;
    }

    this.dist += this.speed * dt;
    this.pos.set(this.x, this.y, this.z);
  }

  applyToCamera(
    camera: THREE.PerspectiveCamera,
    bob: number,
    shake: THREE.Vector3,
    extraPitch = 0,
  ) {
    const bobY = Math.sin(this.dist * 9) * bob;
    camera.position.set(this.x + shake.x, EYE + bobY + shake.y, this.z + shake.z);
    camera.rotation.order = "YXZ";
    camera.rotation.y = this.yaw;
    camera.rotation.x = this.pitch + extraPitch;
    camera.rotation.z = shake.x * 0.4;
  }
}
