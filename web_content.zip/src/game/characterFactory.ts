import * as THREE from 'three';
import { CharacterId } from '../types/game';

/**
 * Character Factory for Ayush Family Adventure
 * Creates vibrant 3-12 part procedural cartoon characters with animated limb hierarchies.
 * Grounded at bottom-center (y = 0).
 */

export interface AnimatedCharacter {
  id: CharacterId;
  group: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  head: THREE.Group;
  body: THREE.Group;
  update: (time: number, isMoving: boolean, isRunning: boolean, isJumping: boolean) => void;
  playArgueAnimation?: (time: number) => void;
  playCelebrateAnimation?: (time: number) => void;
}

// Materials Cache for high performance PBR
const skinMat = new THREE.MeshStandardMaterial({
  color: 0xf5c396,
  roughness: 0.65,
  metalness: 0.05,
});

const eyeMat = new THREE.MeshBasicMaterial({ color: 0x111827 });
const eyeWhiteMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

// 1. Ayush (Hero Character)
export function createAyushCharacter(): AnimatedCharacter {
  const root = new THREE.Group();
  root.name = 'Ayush_Hero';

  // Materials for Ayush
  const hoodieMat = new THREE.MeshStandardMaterial({
    color: 0x0284c7, // vibrant sky blue hoodie
    roughness: 0.7,
    metalness: 0.1,
  });
  const jeansMat = new THREE.MeshStandardMaterial({
    color: 0x1e3a8a, // dark navy jeans
    roughness: 0.8,
  });
  const shoeMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.4,
  });
  const shoeSoleMat = new THREE.MeshStandardMaterial({
    color: 0xe11d48, // red trim sneakers
    roughness: 0.5,
  });
  const hairMat = new THREE.MeshStandardMaterial({
    color: 0x18181b, // cool black spiky hair
    roughness: 0.9,
  });
  const backpackMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b, // amber explorer backpack
    roughness: 0.6,
  });

  // Body container
  const body = new THREE.Group();
  body.position.y = 0.75;
  root.add(body);

  // Torso (Hoodie)
  const torsoGeo = new THREE.CylinderGeometry(0.24, 0.28, 0.52, 16);
  const torso = new THREE.Mesh(torsoGeo, hoodieMat);
  torso.castShadow = true;
  torso.receiveShadow = true;
  body.add(torso);

  // Hoodie Pocket / Trim
  const pocketGeo = new THREE.BoxGeometry(0.22, 0.14, 0.08);
  const pocket = new THREE.Mesh(pocketGeo, hoodieMat);
  pocket.position.set(0, -0.12, 0.22);
  body.add(pocket);

  // Backpack
  const bpGeo = new THREE.BoxGeometry(0.3, 0.36, 0.16);
  const backpack = new THREE.Mesh(bpGeo, backpackMat);
  backpack.position.set(0, 0.04, -0.22);
  backpack.castShadow = true;
  body.add(backpack);

  // Head container
  const head = new THREE.Group();
  head.position.y = 0.38;
  body.add(head);

  // Face
  const faceGeo = new THREE.SphereGeometry(0.25, 18, 18);
  const face = new THREE.Mesh(faceGeo, skinMat);
  face.castShadow = true;
  head.add(face);

  // Cartoon Spiky Hair
  const hairGeo = new THREE.SphereGeometry(0.26, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.6);
  const hair = new THREE.Mesh(hairGeo, hairMat);
  hair.position.set(0, 0.04, -0.02);
  head.add(hair);

  const spikeGeo = new THREE.ConeGeometry(0.08, 0.16, 8);
  const spike1 = new THREE.Mesh(spikeGeo, hairMat);
  spike1.position.set(0, 0.26, 0.04);
  spike1.rotation.x = -0.3;
  head.add(spike1);

  const spike2 = new THREE.Mesh(spikeGeo, hairMat);
  spike2.position.set(-0.08, 0.24, 0.02);
  spike2.rotation.z = 0.4;
  head.add(spike2);

  // Big expressive cartoon eyes
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.05, 12, 12), eyeWhiteMat);
  eyeL.position.set(-0.08, 0.02, 0.22);
  const pupilL = new THREE.Mesh(new THREE.SphereGeometry(0.025, 8, 8), eyeMat);
  pupilL.position.set(-0.08, 0.02, 0.26);

  const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.05, 12, 12), eyeWhiteMat);
  eyeR.position.set(0.08, 0.02, 0.22);
  const pupilR = new THREE.Mesh(new THREE.SphereGeometry(0.025, 8, 8), eyeMat);
  pupilR.position.set(0.08, 0.02, 0.26);

  head.add(eyeL, pupilL, eyeR, pupilR);

  // Smile
  const smileGeo = new THREE.TorusGeometry(0.06, 0.015, 8, 12, Math.PI);
  const smileMat = new THREE.MeshBasicMaterial({ color: 0x991b1b });
  const smile = new THREE.Mesh(smileGeo, smileMat);
  smile.position.set(0, -0.09, 0.23);
  smile.rotation.x = Math.PI * 0.15;
  head.add(smile);

  // Arms with shoulder pivots
  const armGeo = new THREE.CylinderGeometry(0.065, 0.06, 0.38, 10);
  armGeo.translate(0, -0.19, 0);

  const leftArm = new THREE.Group();
  leftArm.position.set(-0.32, 0.2, 0);
  const leftArmMesh = new THREE.Mesh(armGeo, hoodieMat);
  leftArmMesh.castShadow = true;
  leftArm.add(leftArmMesh);
  // Hand
  const handL = new THREE.Mesh(new THREE.SphereGeometry(0.06, 10, 10), skinMat);
  handL.position.set(0, -0.38, 0);
  leftArm.add(handL);
  body.add(leftArm);

  const rightArm = new THREE.Group();
  rightArm.position.set(0.32, 0.2, 0);
  const rightArmMesh = new THREE.Mesh(armGeo, hoodieMat);
  rightArmMesh.castShadow = true;
  rightArm.add(rightArmMesh);
  // Hand
  const handR = new THREE.Mesh(new THREE.SphereGeometry(0.06, 10, 10), skinMat);
  handR.position.set(0, -0.38, 0);
  rightArm.add(handR);
  body.add(rightArm);

  // Legs with hip pivots
  const legGeo = new THREE.CylinderGeometry(0.08, 0.075, 0.46, 10);
  legGeo.translate(0, -0.23, 0);

  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.13, -0.26, 0);
  const leftLegMesh = new THREE.Mesh(legGeo, jeansMat);
  leftLegMesh.castShadow = true;
  leftLeg.add(leftLegMesh);
  // Sneaker
  const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.09, 0.19), shoeMat);
  shoeL.position.set(0, -0.46, 0.04);
  const soleL = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.03, 0.2), shoeSoleMat);
  soleL.position.set(0, -0.5, 0.04);
  leftLeg.add(shoeL, soleL);
  body.add(leftLeg);

  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.13, -0.26, 0);
  const rightLegMesh = new THREE.Mesh(legGeo, jeansMat);
  rightLegMesh.castShadow = true;
  rightLeg.add(rightLegMesh);
  // Sneaker
  const shoeR = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.09, 0.19), shoeMat);
  shoeR.position.set(0, -0.46, 0.04);
  const soleR = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.03, 0.2), shoeSoleMat);
  soleR.position.set(0, -0.5, 0.04);
  rightLeg.add(shoeR, soleR);
  body.add(rightLeg);

  // Soft Contact Shadow Plane underneath
  const shadowGeo = new THREE.CircleGeometry(0.38, 16);
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x000000,
    transparent: true,
    opacity: 0.35,
    depthWrite: false,
  });
  const shadow = new THREE.Mesh(shadowGeo, shadowMat);
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.015;
  root.add(shadow);

  // Animation Update
  const update = (time: number, isMoving: boolean, isRunning: boolean, isJumping: boolean) => {
    if (isJumping) {
      // Jump pose: tuck legs, raise arms
      leftLeg.rotation.x = -0.5;
      rightLeg.rotation.x = -0.4;
      leftArm.rotation.x = -1.2;
      rightArm.rotation.x = -1.2;
      body.position.y = 0.78;
      body.rotation.x = 0.1;
      return;
    }

    if (isMoving) {
      const speedMult = isRunning ? 16 : 10;
      const swingAngle = Math.sin(time * speedMult) * (isRunning ? 0.8 : 0.55);

      // Scissor legs
      leftLeg.rotation.x = swingAngle;
      rightLeg.rotation.x = -swingAngle;

      // Natural opposite arm swings
      leftArm.rotation.x = -swingAngle * 0.9;
      rightArm.rotation.x = swingAngle * 0.9;
      leftArm.rotation.z = 0.1;
      rightArm.rotation.z = -0.1;

      // Subtle torso bounce and sway
      body.position.y = 0.75 + Math.abs(Math.sin(time * speedMult)) * 0.05;
      body.rotation.z = Math.sin(time * speedMult * 0.5) * 0.05;
      head.rotation.y = Math.sin(time * speedMult * 0.5) * 0.04;
    } else {
      // Idle breathing and fidgeting
      const breath = Math.sin(time * 2.5) * 0.02;
      body.position.y = 0.75 + breath;
      head.position.y = 0.38 + breath * 0.5;
      leftArm.rotation.x = Math.sin(time * 1.5) * 0.05;
      rightArm.rotation.x = -Math.sin(time * 1.5) * 0.05;
      leftArm.rotation.z = 0.05;
      rightArm.rotation.z = -0.05;
      leftLeg.rotation.x = 0;
      rightLeg.rotation.x = 0;
      body.rotation.z = 0;
    }
  };

  return { id: 'ayush', group: root, leftArm, rightArm, leftLeg, rightLeg, head, body, update };
}

// 2. Arav (Energetic Kid Brother)
export function createAravCharacter(): AnimatedCharacter {
  const root = new THREE.Group();
  root.name = 'Arav';
  root.scale.set(0.85, 0.85, 0.85); // smaller energetic kid brother

  const shirtMat = new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.7 }); // bright orange tee
  const shortsMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.8 }); // cyan shorts
  const shoeMat = new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.5 }); // green sneakers
  const hairMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.9 });

  const body = new THREE.Group();
  body.position.y = 0.65;
  root.add(body);

  // Torso
  const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.22, 0.44, 16), shirtMat);
  torso.castShadow = true;
  body.add(torso);

  // Head
  const head = new THREE.Group();
  head.position.y = 0.32;
  body.add(head);

  const face = new THREE.Mesh(new THREE.SphereGeometry(0.22, 18, 18), skinMat);
  face.castShadow = true;
  head.add(face);

  // Messy boy hair
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.23, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.55), hairMat);
  hair.position.set(0, 0.03, -0.02);
  head.add(hair);

  // Eyes
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 10), eyeWhiteMat);
  eyeL.position.set(-0.07, 0.02, 0.19);
  const pupilL = new THREE.Mesh(new THREE.SphereGeometry(0.022, 8, 8), eyeMat);
  pupilL.position.set(-0.07, 0.02, 0.23);
  const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 10), eyeWhiteMat);
  eyeR.position.set(0.07, 0.02, 0.19);
  const pupilR = new THREE.Mesh(new THREE.SphereGeometry(0.022, 8, 8), eyeMat);
  pupilR.position.set(0.07, 0.02, 0.23);
  head.add(eyeL, pupilL, eyeR, pupilR);

  // Big grin
  const smile = new THREE.Mesh(new THREE.TorusGeometry(0.055, 0.015, 8, 12, Math.PI), new THREE.MeshBasicMaterial({ color: 0xb91c1c }));
  smile.position.set(0, -0.08, 0.2);
  smile.rotation.x = Math.PI * 0.15;
  head.add(smile);

  // Arms
  const armGeo = new THREE.CylinderGeometry(0.055, 0.05, 0.32, 10);
  armGeo.translate(0, -0.16, 0);

  const leftArm = new THREE.Group();
  leftArm.position.set(-0.26, 0.15, 0);
  leftArm.add(new THREE.Mesh(armGeo, shirtMat));
  body.add(leftArm);

  const rightArm = new THREE.Group();
  rightArm.position.set(0.26, 0.15, 0);
  rightArm.add(new THREE.Mesh(armGeo, shirtMat));
  body.add(rightArm);

  // Legs
  const legGeo = new THREE.CylinderGeometry(0.07, 0.065, 0.38, 10);
  legGeo.translate(0, -0.19, 0);

  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.11, -0.22, 0);
  leftLeg.add(new THREE.Mesh(legGeo, shortsMat));
  const sL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.08, 0.16), shoeMat);
  sL.position.set(0, -0.38, 0.03);
  leftLeg.add(sL);
  body.add(leftLeg);

  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.11, -0.22, 0);
  rightLeg.add(new THREE.Mesh(legGeo, shortsMat));
  const sR = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.08, 0.16), shoeMat);
  sR.position.set(0, -0.38, 0.03);
  rightLeg.add(sR);
  body.add(rightLeg);

  // Shadow
  const shadow = new THREE.Mesh(new THREE.CircleGeometry(0.32, 16), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.3, depthWrite: false }));
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.015;
  root.add(shadow);

  const update = (time: number) => {
    // Energetic kid idle jumping/bouncing
    const bounce = Math.abs(Math.sin(time * 3.5)) * 0.06;
    body.position.y = 0.65 + bounce;
    leftArm.rotation.z = Math.sin(time * 3.5) * 0.2 + 0.1;
    rightArm.rotation.z = -Math.sin(time * 3.5) * 0.2 - 0.1;
    head.rotation.y = Math.sin(time * 2.0) * 0.15;
  };

  const playArgueAnimation = (time: number) => {
    // Stomping and waving arms during argument
    leftArm.rotation.x = Math.sin(time * 8) * 0.6 - 0.4;
    rightArm.rotation.x = -Math.sin(time * 8) * 0.6 - 0.4;
    body.rotation.y = Math.sin(time * 5) * 0.25;
  };

  return { id: 'arav', group: root, leftArm, rightArm, leftLeg, rightLeg, head, body, update, playArgueAnimation };
}

// 3. Akshhara (Funny Mischievous Sister)
export function createAkshharaCharacter(): AnimatedCharacter {
  const root = new THREE.Group();
  root.name = 'Akshhara';
  root.scale.set(0.85, 0.85, 0.85);

  const frockMat = new THREE.MeshStandardMaterial({ color: 0xc026d3, roughness: 0.6 }); // vibrant magenta frock
  const skirtMat = new THREE.MeshStandardMaterial({ color: 0xec4899, roughness: 0.7 }); // pink flair skirt
  const shoeMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.4 });
  const ribbonMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.5 }); // gold ribbons
  const hairMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.85 });

  const body = new THREE.Group();
  body.position.y = 0.65;
  root.add(body);

  // Frock top
  const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.22, 0.38, 16), frockMat);
  torso.castShadow = true;
  body.add(torso);

  // Flared Skirt
  const skirt = new THREE.Mesh(new THREE.ConeGeometry(0.34, 0.28, 16, 1, true), skirtMat);
  skirt.position.y = -0.16;
  skirt.castShadow = true;
  body.add(skirt);

  // Head
  const head = new THREE.Group();
  head.position.y = 0.28;
  body.add(head);

  const face = new THREE.Mesh(new THREE.SphereGeometry(0.22, 18, 18), skinMat);
  face.castShadow = true;
  head.add(face);

  // Hair with twin pigtails
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.23, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.55), hairMat);
  hair.position.set(0, 0.03, -0.02);
  head.add(hair);

  // Left & Right Ponytails
  const pigtailGeo = new THREE.ConeGeometry(0.08, 0.28, 10);
  pigtailGeo.translate(0, -0.14, 0);

  const pigtailL = new THREE.Mesh(pigtailGeo, hairMat);
  pigtailL.position.set(-0.22, 0.08, -0.04);
  pigtailL.rotation.z = 0.6;
  const ribbonL = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), ribbonMat);
  ribbonL.position.set(-0.21, 0.08, -0.04);
  head.add(pigtailL, ribbonL);

  const pigtailR = new THREE.Mesh(pigtailGeo, hairMat);
  pigtailR.position.set(0.22, 0.08, -0.04);
  pigtailR.rotation.z = -0.6;
  const ribbonR = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), ribbonMat);
  ribbonR.position.set(0.21, 0.08, -0.04);
  head.add(pigtailR, ribbonR);

  // Sassy cat eyes & smirk
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 10), eyeWhiteMat);
  eyeL.position.set(-0.07, 0.02, 0.19);
  const pupilL = new THREE.Mesh(new THREE.SphereGeometry(0.022, 8, 8), eyeMat);
  pupilL.position.set(-0.07, 0.02, 0.23);
  const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 10), eyeWhiteMat);
  eyeR.position.set(0.07, 0.02, 0.19);
  const pupilR = new THREE.Mesh(new THREE.SphereGeometry(0.022, 8, 8), eyeMat);
  pupilR.position.set(0.07, 0.02, 0.23);
  head.add(eyeL, pupilL, eyeR, pupilR);

  // Cheeky smirk
  const smile = new THREE.Mesh(new THREE.TorusGeometry(0.045, 0.013, 8, 12, Math.PI * 0.8), new THREE.MeshBasicMaterial({ color: 0x9f1239 }));
  smile.position.set(0.02, -0.08, 0.2);
  smile.rotation.z = -0.2;
  head.add(smile);

  // Arms
  const armGeo = new THREE.CylinderGeometry(0.05, 0.045, 0.32, 10);
  armGeo.translate(0, -0.16, 0);

  const leftArm = new THREE.Group();
  leftArm.position.set(-0.25, 0.12, 0);
  leftArm.add(new THREE.Mesh(armGeo, frockMat));
  body.add(leftArm);

  const rightArm = new THREE.Group();
  rightArm.position.set(0.25, 0.12, 0);
  rightArm.add(new THREE.Mesh(armGeo, frockMat));
  body.add(rightArm);

  // Legs
  const legGeo = new THREE.CylinderGeometry(0.06, 0.055, 0.38, 10);
  legGeo.translate(0, -0.19, 0);

  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.1, -0.26, 0);
  leftLeg.add(new THREE.Mesh(legGeo, skinMat));
  const sL = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.07, 0.15), shoeMat);
  sL.position.set(0, -0.38, 0.03);
  leftLeg.add(sL);
  body.add(leftLeg);

  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.1, -0.26, 0);
  rightLeg.add(new THREE.Mesh(legGeo, skinMat));
  const sR = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.07, 0.15), shoeMat);
  sR.position.set(0, -0.38, 0.03);
  rightLeg.add(sR);
  body.add(rightLeg);

  // Shadow
  const shadow = new THREE.Mesh(new THREE.CircleGeometry(0.32, 16), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.3, depthWrite: false }));
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.015;
  root.add(shadow);

  const update = (time: number) => {
    // Sassy idle: swaying hips and crossed arms pose
    const hipSway = Math.sin(time * 2.2) * 0.08;
    body.rotation.z = hipSway;
    leftArm.rotation.x = -0.4 + Math.sin(time * 2.2) * 0.05;
    rightArm.rotation.x = -0.5 - Math.sin(time * 2.2) * 0.05;
    head.rotation.y = Math.sin(time * 1.5) * 0.12;
    pigtailL.rotation.z = 0.6 + Math.sin(time * 4) * 0.06;
    pigtailR.rotation.z = -0.6 - Math.sin(time * 4) * 0.06;
  };

  const playArgueAnimation = (time: number) => {
    // Hands on hips / mocking finger wag
    leftArm.rotation.set(-0.2, 0, 0.5);
    rightArm.rotation.set(-0.6 + Math.sin(time * 8) * 0.4, 0.2, -0.3);
    head.rotation.z = Math.sin(time * 6) * 0.15;
  };

  return { id: 'akshhara', group: root, leftArm, rightArm, leftLeg, rightLeg, head, body, update, playArgueAnimation };
}

// 4. Mr. Ripin (Father)
export function createRipinCharacter(): AnimatedCharacter {
  const root = new THREE.Group();
  root.name = 'Ripin_Father';
  root.scale.set(1.08, 1.08, 1.08); // tall, respectable father figure

  const kurtaMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.7 }); // crisp blue kurta
  const vestMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.8 }); // stylish nehru vest
  const pantsMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.85 }); // white pajama
  const sandalMat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.6 }); // brown leather sandals
  const hairMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.9 });
  const glassesMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.8, roughness: 0.2 });

  const body = new THREE.Group();
  body.position.y = 0.88;
  root.add(body);

  // Kurta & Nehru Waistcoat
  const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 0.65, 16), kurtaMat);
  torso.castShadow = true;
  body.add(torso);

  const vest = new THREE.Mesh(new THREE.CylinderGeometry(0.29, 0.31, 0.46, 16), vestMat);
  vest.position.y = 0.08;
  body.add(vest);

  // Head
  const head = new THREE.Group();
  head.position.y = 0.48;
  body.add(head);

  const face = new THREE.Mesh(new THREE.SphereGeometry(0.26, 18, 18), skinMat);
  face.castShadow = true;
  head.add(face);

  // Distinguished hair with subtle gray sides
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.27, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.5), hairMat);
  hair.position.set(0, 0.06, -0.02);
  head.add(hair);

  // Royal Indian Mustache
  const stacheMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.9 });
  const stacheL = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.035, 0.12, 8), stacheMat);
  stacheL.position.set(-0.06, -0.06, 0.25);
  stacheL.rotation.z = Math.PI / 2.3;
  const stacheR = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.035, 0.12, 8), stacheMat);
  stacheR.position.set(0.06, -0.06, 0.25);
  stacheR.rotation.z = -Math.PI / 2.3;
  head.add(stacheL, stacheR);

  // Spectacles (Glasses)
  const specGeo = new THREE.TorusGeometry(0.055, 0.012, 8, 16);
  const specL = new THREE.Mesh(specGeo, glassesMat);
  specL.position.set(-0.09, 0.04, 0.25);
  const specR = new THREE.Mesh(specGeo, glassesMat);
  specR.position.set(0.09, 0.04, 0.25);
  const bridge = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.08), glassesMat);
  bridge.position.set(0, 0.04, 0.26);
  bridge.rotation.z = Math.PI / 2;
  head.add(specL, specR, bridge);

  // Eyes behind glasses
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 8), eyeMat);
  eyeL.position.set(-0.09, 0.04, 0.24);
  const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 8), eyeMat);
  eyeR.position.set(0.09, 0.04, 0.24);
  head.add(eyeL, eyeR);

  // Arms
  const armGeo = new THREE.CylinderGeometry(0.075, 0.07, 0.44, 10);
  armGeo.translate(0, -0.22, 0);

  const leftArm = new THREE.Group();
  leftArm.position.set(-0.36, 0.24, 0);
  leftArm.add(new THREE.Mesh(armGeo, kurtaMat));
  body.add(leftArm);

  const rightArm = new THREE.Group();
  rightArm.position.set(0.36, 0.24, 0);
  rightArm.add(new THREE.Mesh(armGeo, kurtaMat));
  body.add(rightArm);

  // Legs
  const legGeo = new THREE.CylinderGeometry(0.09, 0.085, 0.54, 10);
  legGeo.translate(0, -0.27, 0);

  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.14, -0.32, 0);
  leftLeg.add(new THREE.Mesh(legGeo, pantsMat));
  const sandalL = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.07, 0.22), sandalMat);
  sandalL.position.set(0, -0.54, 0.04);
  leftLeg.add(sandalL);
  body.add(leftLeg);

  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.14, -0.32, 0);
  rightLeg.add(new THREE.Mesh(legGeo, pantsMat));
  const sandalR = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.07, 0.22), sandalMat);
  sandalR.position.set(0, -0.54, 0.04);
  rightLeg.add(sandalR);
  body.add(rightLeg);

  // Shadow
  const shadow = new THREE.Mesh(new THREE.CircleGeometry(0.42, 16), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.35, depthWrite: false }));
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.015;
  root.add(shadow);

  const update = (time: number) => {
    // Respectable dad idle posture (calm breathing, occasional nod)
    const breath = Math.sin(time * 1.8) * 0.015;
    body.position.y = 0.88 + breath;
    head.rotation.x = Math.sin(time * 0.8) * 0.05;
    leftArm.rotation.x = -0.15;
    rightArm.rotation.x = -0.2;
  };

  return { id: 'ripin', group: root, leftArm, rightArm, leftLeg, rightLeg, head, body, update };
}

// 5. Mrs. Anjeeta (Mother)
export function createAnjeetaCharacter(): AnimatedCharacter {
  const root = new THREE.Group();
  root.name = 'Anjeeta_Mother';
  root.scale.set(1.0, 1.0, 1.0);

  const sariMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.6 }); // rich saffron/marigold sari
  const palluMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.65 }); // crimson red pallu
  const hairMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9 });
  const goldMat = new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.85, roughness: 0.2 });

  const body = new THREE.Group();
  body.position.y = 0.78;
  root.add(body);

  // Elegant Kurti/Sari torso
  const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.28, 0.55, 16), sariMat);
  torso.castShadow = true;
  body.add(torso);

  // Red Sari Pallu draped across shoulder
  const pallu = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.58, 0.32), palluMat);
  pallu.position.set(-0.16, 0.02, 0);
  pallu.rotation.z = -0.2;
  body.add(pallu);

  // Head
  const head = new THREE.Group();
  head.position.y = 0.42;
  body.add(head);

  const face = new THREE.Mesh(new THREE.SphereGeometry(0.24, 18, 18), skinMat);
  face.castShadow = true;
  head.add(face);

  // Hair bun (Juda)
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.25, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.55), hairMat);
  hair.position.set(0, 0.04, -0.02);
  const bun = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 12), hairMat);
  bun.position.set(0, 0.06, -0.22);
  head.add(hair, bun);

  // Red Bindi
  const bindi = new THREE.Mesh(new THREE.CircleGeometry(0.025, 12), new THREE.MeshBasicMaterial({ color: 0xdc2626 }));
  bindi.position.set(0, 0.1, 0.24);
  head.add(bindi);

  // Eyes
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.04, 10, 10), eyeWhiteMat);
  eyeL.position.set(-0.08, 0.02, 0.21);
  const pupilL = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 8), eyeMat);
  pupilL.position.set(-0.08, 0.02, 0.25);
  const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.04, 10, 10), eyeWhiteMat);
  eyeR.position.set(0.08, 0.02, 0.21);
  const pupilR = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 8), eyeMat);
  pupilR.position.set(0.08, 0.02, 0.25);
  head.add(eyeL, pupilL, eyeR, pupilR);

  // Warm gentle smile
  const smile = new THREE.Mesh(new THREE.TorusGeometry(0.06, 0.013, 8, 12, Math.PI), new THREE.MeshBasicMaterial({ color: 0x991b1b }));
  smile.position.set(0, -0.08, 0.22);
  smile.rotation.x = Math.PI * 0.15;
  head.add(smile);

  // Gold Jhumka Earrings
  const earringL = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.06, 8), goldMat);
  earringL.position.set(-0.25, -0.04, 0);
  earringL.rotation.x = Math.PI;
  const earringR = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.06, 8), goldMat);
  earringR.position.set(0.25, -0.04, 0);
  earringR.rotation.x = Math.PI;
  head.add(earringL, earringR);

  // Arms with Gold Bangles
  const armGeo = new THREE.CylinderGeometry(0.06, 0.055, 0.38, 10);
  armGeo.translate(0, -0.19, 0);

  const leftArm = new THREE.Group();
  leftArm.position.set(-0.32, 0.2, 0);
  leftArm.add(new THREE.Mesh(armGeo, sariMat));
  const bangleL = new THREE.Mesh(new THREE.TorusGeometry(0.065, 0.015, 8, 12), goldMat);
  bangleL.position.set(0, -0.3, 0);
  bangleL.rotation.x = Math.PI / 2;
  leftArm.add(bangleL);
  body.add(leftArm);

  const rightArm = new THREE.Group();
  rightArm.position.set(0.32, 0.2, 0);
  rightArm.add(new THREE.Mesh(armGeo, sariMat));
  const bangleR = new THREE.Mesh(new THREE.TorusGeometry(0.065, 0.015, 8, 12), goldMat);
  bangleR.position.set(0, -0.3, 0);
  bangleR.rotation.x = Math.PI / 2;
  rightArm.add(bangleR);
  body.add(rightArm);

  // Long flowing skirt/sari fall
  const skirt = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.38, 0.62, 16), sariMat);
  skirt.position.y = -0.38;
  skirt.castShadow = true;
  body.add(skirt);

  // Shadow
  const shadow = new THREE.Mesh(new THREE.CircleGeometry(0.4, 16), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.32, depthWrite: false }));
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.015;
  root.add(shadow);

  const update = (time: number) => {
    // Warm motherly greeting and gentle hand motion
    const breath = Math.sin(time * 2.0) * 0.015;
    body.position.y = 0.78 + breath;
    leftArm.rotation.x = Math.sin(time * 1.5) * 0.1 - 0.2;
    rightArm.rotation.x = -Math.sin(time * 1.5) * 0.1 - 0.2;
    head.rotation.y = Math.sin(time * 1.2) * 0.1;
  };

  return {
    id: 'anjeeta',
    group: root,
    leftArm,
    rightArm,
    leftLeg: new THREE.Group(),
    rightLeg: new THREE.Group(),
    head,
    body,
    update,
  };
}
