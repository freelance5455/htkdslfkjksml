import * as THREE from 'three';
import { FruitType, IslandInfo, WeaponType } from '../types/game';

// Procedural Anime Face Texture (Eyes & Smile)
function createFaceTexture(isBandit = false, isMarine = false): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  // Skin base
  ctx.fillStyle = '#ffdfba';
  ctx.fillRect(0, 0, 128, 128);

  if (isMarine) {
    // Serious sharp eyes
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(30, 48, 22, 10);
    ctx.fillRect(76, 48, 22, 10);
    // Eyebrows
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(26, 40, 28, 5);
    ctx.fillRect(74, 40, 28, 5);
    // Straight mouth
    ctx.fillStyle = '#78350f';
    ctx.fillRect(50, 85, 28, 4);
  } else if (isBandit) {
    // Scar + fierce eyes
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(28, 30, 4, 38); // scar
    ctx.fillStyle = '#450a0a';
    ctx.fillRect(32, 50, 22, 12);
    ctx.fillRect(74, 50, 22, 12);
    // Grin
    ctx.fillStyle = '#1c1917';
    ctx.beginPath();
    ctx.arc(64, 82, 16, 0.1 * Math.PI, 0.9 * Math.PI);
    ctx.lineWidth = 4;
    ctx.stroke();
  } else {
    // Hero Anime Eyes
    ctx.fillStyle = '#1e1b4b';
    ctx.beginPath();
    ctx.ellipse(38, 54, 9, 14, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(90, 54, 9, 14, 0, 0, Math.PI * 2);
    ctx.fill();

    // Eye shines
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(35, 48, 4, 0, Math.PI * 2);
    ctx.arc(87, 48, 4, 0, Math.PI * 2);
    ctx.fill();

    // Confident anime smile
    ctx.strokeStyle = '#451a03';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(64, 82, 14, 0.1 * Math.PI, 0.9 * Math.PI);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// Procedural Pirate Jolly Roger Canvas Texture
export function createJollyRogerTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  // Sail background (off-white weathered canvas)
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 0, 256, 256);

  // Skull & Straw Hat Emblem
  ctx.fillStyle = '#0f172a';
  // Crossbones
  ctx.lineWidth = 18;
  ctx.strokeStyle = '#0f172a';
  ctx.beginPath();
  ctx.moveTo(40, 40);
  ctx.lineTo(216, 216);
  ctx.moveTo(216, 40);
  ctx.lineTo(40, 216);
  ctx.stroke();

  // Bone ends
  [ [40, 40], [216, 40], [40, 216], [216, 216] ].forEach(([x, y]) => {
    ctx.beginPath();
    ctx.arc(x - 8, y, 10, 0, Math.PI * 2);
    ctx.arc(x + 8, y, 10, 0, Math.PI * 2);
    ctx.fill();
  });

  // Skull
  ctx.beginPath();
  ctx.arc(128, 120, 45, 0, Math.PI * 2);
  ctx.fill();

  // Jaw
  ctx.fillRect(106, 145, 44, 25);

  // Straw hat on skull
  ctx.fillStyle = '#f59e0b';
  ctx.beginPath();
  ctx.ellipse(128, 92, 58, 14, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(128, 88, 30, Math.PI, 0);
  ctx.fill();

  // Red Hat Ribbon
  ctx.fillStyle = '#dc2626';
  ctx.fillRect(100, 84, 56, 7);

  // Eye sockets
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.arc(114, 122, 10, 0, Math.PI * 2);
  ctx.arc(142, 122, 10, 0, Math.PI * 2);
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// -------------------------------------------------------------
// Character Procedural Model (Composite 3-12 parts)
// -------------------------------------------------------------
export interface CharacterNodes {
  group: THREE.Group;
  bodyGroup: THREE.Group;
  head: THREE.Mesh;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  weaponGroup: THREE.Group;
  hakiMeshes: THREE.Mesh[];
  auraLight: THREE.PointLight;
  setWeapon: (weapon: WeaponType) => void;
  setHaki: (active: boolean) => void;
  setBuddha: (active: boolean) => void;
}

export function createCharacterModel(options?: {
  isPlayer?: boolean;
  shirtColor?: string;
  pantsColor?: string;
  hatType?: 'straw_hat' | 'bandana' | 'marine_cap' | 'tricorn' | 'none';
  faceType?: 'hero' | 'bandit' | 'marine';
}): CharacterNodes {
  const root = new THREE.Group();

  const shirtColor = options?.shirtColor || '#dc2626'; // Luffy red
  const pantsColor = options?.pantsColor || '#0284c7'; // Denim blue
  const hatType = options?.hatType ?? (options?.isPlayer ? 'straw_hat' : 'bandana');
  const faceType = options?.faceType || (options?.isPlayer ? 'hero' : 'bandit');

  // Materials with varied roughness and metalness
  const skinMat = new THREE.MeshStandardMaterial({
    color: '#ffdfba',
    roughness: 0.8,
    metalness: 0.05,
  });

  const shirtMat = new THREE.MeshStandardMaterial({
    color: shirtColor,
    roughness: 0.7,
    metalness: 0.1,
  });

  const pantsMat = new THREE.MeshStandardMaterial({
    color: pantsColor,
    roughness: 0.75,
    metalness: 0.05,
  });

  const shoesMat = new THREE.MeshStandardMaterial({
    color: '#78350f',
    roughness: 0.6,
    metalness: 0.2,
  });

  const goldBuckleMat = new THREE.MeshStandardMaterial({
    color: '#facc15',
    roughness: 0.3,
    metalness: 0.85,
  });

  const hakiMeshes: THREE.Mesh[] = [];

  // 1. Legs (Pivoted at hip y=0.8)
  const legGeo = new THREE.BoxGeometry(0.32, 0.75, 0.32);
  const shoeGeo = new THREE.BoxGeometry(0.34, 0.2, 0.42);

  // Left Leg
  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.24, 0.8, 0);
  const leftLegMesh = new THREE.Mesh(legGeo, pantsMat);
  leftLegMesh.position.y = -0.38;
  leftLegMesh.castShadow = true;
  leftLeg.add(leftLegMesh);

  const leftShoe = new THREE.Mesh(shoeGeo, shoesMat);
  leftShoe.position.set(0, -0.75, 0.05);
  leftShoe.castShadow = true;
  leftLeg.add(leftShoe);
  root.add(leftLeg);

  // Right Leg
  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.24, 0.8, 0);
  const rightLegMesh = new THREE.Mesh(legGeo, pantsMat);
  rightLegMesh.position.y = -0.38;
  rightLegMesh.castShadow = true;
  rightLeg.add(rightLegMesh);

  const rightShoe = new THREE.Mesh(shoeGeo, shoesMat);
  rightShoe.position.set(0, -0.75, 0.05);
  rightShoe.castShadow = true;
  rightLeg.add(rightShoe);
  root.add(rightLeg);

  // 2. Torso Body Group
  const bodyGroup = new THREE.Group();
  bodyGroup.position.set(0, 0.85, 0);

  // Torso
  const torsoGeo = new THREE.BoxGeometry(0.85, 0.95, 0.45);
  const torso = new THREE.Mesh(torsoGeo, shirtMat);
  torso.position.y = 0.48;
  torso.castShadow = true;
  bodyGroup.add(torso);

  // Yellow Sash / Belt
  const beltGeo = new THREE.BoxGeometry(0.87, 0.16, 0.47);
  const beltMat = new THREE.MeshStandardMaterial({ color: '#f59e0b', roughness: 0.5 });
  const belt = new THREE.Mesh(beltGeo, beltMat);
  belt.position.y = 0.08;
  bodyGroup.add(belt);

  // Gold Belt Buckle
  const buckleGeo = new THREE.BoxGeometry(0.2, 0.18, 0.5);
  const buckle = new THREE.Mesh(buckleGeo, goldBuckleMat);
  buckle.position.y = 0.08;
  bodyGroup.add(buckle);

  // 3. Head & Hair
  const headGeo = new THREE.BoxGeometry(0.55, 0.55, 0.55);
  const faceTex = createFaceTexture(faceType === 'bandit', faceType === 'marine');
  const headMaterials = [
    skinMat, // right
    skinMat, // left
    skinMat, // top
    skinMat, // bottom
    new THREE.MeshStandardMaterial({ map: faceTex, roughness: 0.8 }), // front face
    skinMat, // back
  ];
  const head = new THREE.Mesh(headGeo, headMaterials);
  head.position.set(0, 1.25, 0);
  head.castShadow = true;
  bodyGroup.add(head);

  // Spiky Anime Hair
  const hairMat = new THREE.MeshStandardMaterial({ color: '#1c1917', roughness: 0.85 });
  const hairGroup = new THREE.Group();
  hairGroup.position.set(0, 1.48, 0);

  const spikeGeo = new THREE.ConeGeometry(0.14, 0.28, 4);
  const spikePositions = [
    [0, 0.12, -0.1],
    [-0.18, 0.1, -0.05],
    [0.18, 0.1, -0.05],
    [-0.24, -0.05, 0.12],
    [0.24, -0.05, 0.12],
    [0, 0.08, 0.18],
  ];
  spikePositions.forEach(([x, y, z]) => {
    const spike = new THREE.Mesh(spikeGeo, hairMat);
    spike.position.set(x, y, z);
    spike.rotation.x = -0.2;
    hairGroup.add(spike);
  });
  bodyGroup.add(hairGroup);

  // Hat Options
  if (hatType === 'straw_hat') {
    const hatGroup = new THREE.Group();
    hatGroup.position.set(0, 1.55, 0);
    hatGroup.rotation.x = -0.05;

    const strawMat = new THREE.MeshStandardMaterial({ color: '#f59e0b', roughness: 0.85 });
    const ribbonMat = new THREE.MeshStandardMaterial({ color: '#dc2626', roughness: 0.6 });

    // Brim
    const brimGeo = new THREE.CylinderGeometry(0.58, 0.58, 0.04, 16);
    const brim = new THREE.Mesh(brimGeo, strawMat);
    hatGroup.add(brim);

    // Crown
    const crownGeo = new THREE.CylinderGeometry(0.32, 0.35, 0.22, 16);
    const crown = new THREE.Mesh(crownGeo, strawMat);
    crown.position.y = 0.12;
    hatGroup.add(crown);

    // Ribbon
    const ribbonGeo = new THREE.CylinderGeometry(0.355, 0.355, 0.07, 16);
    const ribbon = new THREE.Mesh(ribbonGeo, ribbonMat);
    ribbon.position.y = 0.05;
    hatGroup.add(ribbon);

    bodyGroup.add(hatGroup);
  } else if (hatType === 'bandana') {
    const bandanaGeo = new THREE.CylinderGeometry(0.32, 0.32, 0.16, 8);
    const bandanaMat = new THREE.MeshStandardMaterial({ color: '#047857', roughness: 0.7 });
    const bandana = new THREE.Mesh(bandanaGeo, bandanaMat);
    bandana.position.set(0, 1.48, 0);
    bodyGroup.add(bandana);
  }

  // 4. Arms (Pivoted at shoulder y=0.8)
  const armGeo = new THREE.BoxGeometry(0.28, 0.78, 0.28);
  const handGeo = new THREE.BoxGeometry(0.25, 0.22, 0.25);

  // Left Arm
  const leftArm = new THREE.Group();
  leftArm.position.set(-0.58, 0.85, 0);
  const leftArmMesh = new THREE.Mesh(armGeo, shirtMat);
  leftArmMesh.position.y = -0.28;
  leftArmMesh.castShadow = true;
  leftArm.add(leftArmMesh);

  const leftHand = new THREE.Mesh(handGeo, skinMat);
  leftHand.position.set(0, -0.65, 0);
  leftArm.add(leftHand);
  hakiMeshes.push(leftHand);
  bodyGroup.add(leftArm);

  // Right Arm (Holds weapon)
  const rightArm = new THREE.Group();
  rightArm.position.set(0.58, 0.85, 0);
  const rightArmMesh = new THREE.Mesh(armGeo, shirtMat);
  rightArmMesh.position.y = -0.28;
  rightArmMesh.castShadow = true;
  rightArm.add(rightArmMesh);

  const rightHand = new THREE.Mesh(handGeo, skinMat);
  rightHand.position.set(0, -0.65, 0);
  rightArm.add(rightHand);
  hakiMeshes.push(rightHand);

  // Weapon Mount inside Right Hand
  const weaponGroup = new THREE.Group();
  weaponGroup.position.set(0, -0.7, 0.15);
  rightArm.add(weaponGroup);

  bodyGroup.add(rightArm);
  root.add(bodyGroup);

  // Back Sheath
  const sheathGeo = new THREE.BoxGeometry(0.08, 0.9, 0.08);
  const sheathMat = new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.4 });
  const sheath = new THREE.Mesh(sheathGeo, sheathMat);
  sheath.position.set(0.2, 0.45, -0.28);
  sheath.rotation.z = 0.35;
  sheath.rotation.x = 0.2;
  bodyGroup.add(sheath);

  // Divine / Haki Point Light
  const auraLight = new THREE.PointLight('#9333ea', 0, 8);
  auraLight.position.set(0, 1.2, 0);
  root.add(auraLight);

  // Setup Weapon geometry generator
  function setupWeapon(weapon: WeaponType) {
    while (weaponGroup.children.length > 0) {
      weaponGroup.remove(weaponGroup.children[0]);
    }

    if (weapon === 'combat') {
      // Boxing band / knuckles
      const wrapGeo = new THREE.BoxGeometry(0.27, 0.14, 0.27);
      const wrapMat = new THREE.MeshStandardMaterial({ color: '#f1f5f9', roughness: 0.9 });
      weaponGroup.add(new THREE.Mesh(wrapGeo, wrapMat));
      return;
    }

    // Katana / Saber
    const bladeGroup = new THREE.Group();
    bladeGroup.rotation.x = Math.PI / 2; // point forward

    const isSaber = weapon === 'saber';
    const isDual = weapon === 'dual_katana';

    // Handle / Grip
    const hiltGeo = new THREE.CylinderGeometry(0.035, 0.035, 0.35, 8);
    const hiltMat = new THREE.MeshStandardMaterial({
      color: isSaber ? '#7f1d1d' : '#1e1b4b',
      roughness: 0.8,
    });
    const hilt = new THREE.Mesh(hiltGeo, hiltMat);
    hilt.position.y = -0.15;
    bladeGroup.add(hilt);

    // Tsuba / Guard
    const guardGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.03, 12);
    const guardMat = new THREE.MeshStandardMaterial({
      color: isSaber ? '#ef4444' : '#f59e0b',
      metalness: 0.9,
      roughness: 0.2,
    });
    const guard = new THREE.Mesh(guardGeo, guardMat);
    guard.position.y = 0.02;
    bladeGroup.add(guard);

    // Blade
    const bladeGeo = new THREE.BoxGeometry(0.04, 1.15, 0.015);
    const bladeMat = new THREE.MeshStandardMaterial({
      color: isSaber ? '#fecaca' : '#e2e8f0',
      metalness: 0.95,
      roughness: 0.1,
    });
    const blade = new THREE.Mesh(bladeGeo, bladeMat);
    blade.position.y = 0.6;
    bladeGroup.add(blade);

    weaponGroup.add(bladeGroup);
  }

  // Set default weapon
  setupWeapon('combat');

  // Haki materials
  const originalSkinMat = skinMat.clone();
  const hakiArmMat = new THREE.MeshStandardMaterial({
    color: '#0f172a',
    metalness: 0.95,
    roughness: 0.15,
  });

  return {
    group: root,
    bodyGroup,
    head,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    weaponGroup,
    hakiMeshes,
    auraLight,
    setWeapon: setupWeapon,
    setHaki: (active: boolean) => {
      hakiMeshes.forEach(mesh => {
        mesh.material = active ? hakiArmMat : originalSkinMat;
      });
      auraLight.intensity = active ? 2.5 : 0;
      auraLight.color.set(active ? '#a855f7' : '#ffffff');
    },
    setBuddha: (active: boolean) => {
      const targetScale = active ? 2.4 : 1.0;
      root.scale.set(targetScale, targetScale, targetScale);
      if (active) {
        auraLight.intensity = 4.0;
        auraLight.color.set('#facc15');
      }
    },
  };
}

// -------------------------------------------------------------
// Procedural Devil Fruit 3D Models
// -------------------------------------------------------------
export function createDevilFruitModel(fruitType: FruitType): THREE.Group {
  const group = new THREE.Group();

  let bodyColor = '#c084fc';
  let emissiveColor = '#581c87';

  switch (fruitType) {
    case 'flame':
      bodyColor = '#f97316';
      emissiveColor = '#9a3412';
      break;
    case 'light':
      bodyColor = '#fde047';
      emissiveColor = '#ca8a04';
      break;
    case 'magma':
      bodyColor = '#dc2626';
      emissiveColor = '#7f1d1d';
      break;
    case 'ice':
      bodyColor = '#38bdf8';
      emissiveColor = '#0369a1';
      break;
    case 'buddha':
      bodyColor = '#facc15';
      emissiveColor = '#b45309';
      break;
    case 'rubber':
      bodyColor = '#a855f7';
      emissiveColor = '#6b21a8';
      break;
  }

  // Fruit Core Bulb (faceted icosahedron / sphere with swirl details)
  const coreGeo = new THREE.IcosahedronGeometry(0.45, 2);
  const coreMat = new THREE.MeshStandardMaterial({
    color: bodyColor,
    roughness: 0.35,
    metalness: 0.2,
    emissive: emissiveColor,
    emissiveIntensity: 0.4,
  });
  const core = new THREE.Mesh(coreGeo, coreMat);
  core.position.y = 0.5;
  group.add(core);

  // Distinctive Swirl Nodes / Petals around bulb
  const petalGeo = new THREE.TorusGeometry(0.12, 0.04, 8, 12, Math.PI * 1.5);
  const petalMat = new THREE.MeshStandardMaterial({
    color: bodyColor,
    metalness: 0.3,
    roughness: 0.3,
  });

  const swirlAngles = [0, Math.PI * 0.5, Math.PI, Math.PI * 1.5];
  swirlAngles.forEach((ang) => {
    const swirl = new THREE.Mesh(petalGeo, petalMat);
    swirl.position.set(Math.cos(ang) * 0.38, 0.5 + Math.sin(ang * 2) * 0.1, Math.sin(ang) * 0.38);
    swirl.rotation.y = ang;
    group.add(swirl);
  });

  // Characteristic Curly T-Stem on top
  const stemMat = new THREE.MeshStandardMaterial({ color: '#15803d', roughness: 0.8 });
  const stemBaseGeo = new THREE.CylinderGeometry(0.04, 0.05, 0.2, 8);
  const stemBase = new THREE.Mesh(stemBaseGeo, stemMat);
  stemBase.position.y = 0.95;
  group.add(stemBase);

  // Curly stem tip
  const stemCurlGeo = new THREE.TorusGeometry(0.08, 0.03, 8, 12, Math.PI * 1.3);
  const stemCurl = new THREE.Mesh(stemCurlGeo, stemMat);
  stemCurl.position.set(0.04, 1.05, 0);
  stemCurl.rotation.z = Math.PI / 4;
  group.add(stemCurl);

  // Soft glowing point light
  const light = new THREE.PointLight(bodyColor, 1.8, 4);
  light.position.y = 0.6;
  group.add(light);

  return group;
}

// -------------------------------------------------------------
// Procedural Pirate Caravel Boat Model (Composite 3-12 parts)
// -------------------------------------------------------------
export function createBoatModel(): THREE.Group {
  const boat = new THREE.Group();

  const woodHullMat = new THREE.MeshStandardMaterial({
    color: '#78350f',
    roughness: 0.7,
    metalness: 0.1,
  });

  const woodTrimMat = new THREE.MeshStandardMaterial({
    color: '#451a03',
    roughness: 0.6,
    metalness: 0.2,
  });

  const goldMat = new THREE.MeshStandardMaterial({
    color: '#eab308',
    roughness: 0.3,
    metalness: 0.9,
  });

  // 1. Boat Keel & Main Hull
  const hullGeo = new THREE.BoxGeometry(2.4, 1.1, 5.2);
  const hull = new THREE.Mesh(hullGeo, woodHullMat);
  hull.position.y = 0.45;
  hull.castShadow = true;
  boat.add(hull);

  // Pointed Bow
  const bowGeo = new THREE.ConeGeometry(1.2, 2.0, 4);
  const bow = new THREE.Mesh(bowGeo, woodHullMat);
  bow.rotation.x = -Math.PI / 2;
  bow.position.set(0, 0.45, 3.2);
  bow.castShadow = true;
  boat.add(bow);

  // Golden Dragon / Ram Figurehead
  const ramGeo = new THREE.ConeGeometry(0.25, 0.8, 6);
  const ram = new THREE.Mesh(ramGeo, goldMat);
  ram.rotation.x = Math.PI / 3;
  ram.position.set(0, 0.8, 4.2);
  boat.add(ram);

  // 2. Deck Cabin at Stern
  const cabinGeo = new THREE.BoxGeometry(2.0, 0.9, 1.5);
  const cabin = new THREE.Mesh(cabinGeo, woodTrimMat);
  cabin.position.set(0, 1.2, -1.6);
  cabin.castShadow = true;
  boat.add(cabin);

  // 3. Tall Mast
  const mastGeo = new THREE.CylinderGeometry(0.12, 0.14, 5.2, 8);
  const mast = new THREE.Mesh(mastGeo, woodTrimMat);
  mast.position.set(0, 3.2, 0.3);
  mast.castShadow = true;
  boat.add(mast);

  // Yardarm (horizontal spar)
  const yardarmGeo = new THREE.CylinderGeometry(0.06, 0.06, 3.2, 8);
  const yardarm = new THREE.Mesh(yardarmGeo, woodTrimMat);
  yardarm.rotation.z = Math.PI / 2;
  yardarm.position.set(0, 4.4, 0.3);
  boat.add(yardarm);

  // 4. Large Canvas Sail with Pirate Jolly Roger
  const sailGeo = new THREE.PlaneGeometry(3.0, 3.0, 4, 4);
  // Slightly curve the sail with wind belly
  const posAttr = sailGeo.attributes.position;
  for (let i = 0; i < posAttr.count; i++) {
    const y = posAttr.getY(i);
    const zBelly = Math.sin((y + 1.5) / 3 * Math.PI) * 0.45;
    posAttr.setZ(i, zBelly);
  }
  sailGeo.computeVertexNormals();

  const sailTex = createJollyRogerTexture();
  const sailMat = new THREE.MeshStandardMaterial({
    map: sailTex,
    roughness: 0.9,
    metalness: 0.0,
    side: THREE.DoubleSide,
  });
  const sail = new THREE.Mesh(sailGeo, sailMat);
  sail.position.set(0, 3.2, 0.4);
  sail.castShadow = true;
  boat.add(sail);

  // 5. Dual Brass Lanterns
  const lanternMat = new THREE.MeshStandardMaterial({
    color: '#facc15',
    emissive: '#f59e0b',
    emissiveIntensity: 0.8,
  });
  const lanternGeo = new THREE.DodecahedronGeometry(0.16);

  const leftLantern = new THREE.Mesh(lanternGeo, lanternMat);
  leftLantern.position.set(-1.15, 1.4, -2.1);
  boat.add(leftLantern);

  const rightLantern = new THREE.Mesh(lanternGeo, lanternMat);
  rightLantern.position.set(1.15, 1.4, -2.1);
  boat.add(rightLantern);

  return boat;
}

// -------------------------------------------------------------
// Procedural Island Environment Builder
// -------------------------------------------------------------
export function createIslandEnvironment(island: IslandInfo): THREE.Group {
  const group = new THREE.Group();
  group.position.set(island.x, 0, island.z);

  // 1. Main Island Landmass
  // Shore Sandy Shelf
  const shoreGeo = new THREE.CylinderGeometry(island.radius, island.radius + 12, 4, 32);
  const sandMat = new THREE.MeshStandardMaterial({
    color: island.id === 'volcano_island' ? '#292524' : '#fde68a',
    roughness: 0.95,
  });
  const shore = new THREE.Mesh(shoreGeo, sandMat);
  shore.position.y = 1.0;
  shore.receiveShadow = true;
  group.add(shore);

  // Upper Grass / Rock Plateau
  const plateauGeo = new THREE.CylinderGeometry(island.radius * 0.85, island.radius, 3, 32);
  let topMatColor = '#16a34a'; // grass
  if (island.id === 'desert_island') topMatColor = '#d97706';
  if (island.id === 'volcano_island') topMatColor = '#1c1917';
  if (island.id === 'marine_fortress') topMatColor = '#64748b';
  if (island.id === 'sky_island') topMatColor = '#f0fdf4';

  const plateauMat = new THREE.MeshStandardMaterial({
    color: topMatColor,
    roughness: 0.9,
    metalness: 0.05,
  });
  const plateau = new THREE.Mesh(plateauGeo, plateauMat);
  plateau.position.y = 3.5;
  plateau.receiveShadow = true;
  group.add(plateau);

  // 2. Themed Centerpiece Structure
  if (island.id === 'starter_island') {
    // Village Houses & Docks
    const houseGeo = new THREE.BoxGeometry(6, 4, 8);
    const roofGeo = new THREE.ConeGeometry(5.5, 3.5, 4);
    const houseMat = new THREE.MeshStandardMaterial({ color: '#f5ebe0', roughness: 0.8 });
    const roofMat = new THREE.MeshStandardMaterial({ color: '#b45309', roughness: 0.85 });

    const housePositions = [
      [-15, 6, -10],
      [18, 6, -5],
      [-20, 6, 12],
    ];
    housePositions.forEach(([x, y, z]) => {
      const house = new THREE.Mesh(houseGeo, houseMat);
      house.position.set(x, y, z);
      house.castShadow = true;
      group.add(house);

      const roof = new THREE.Mesh(roofGeo, roofMat);
      roof.rotation.y = Math.PI / 4;
      roof.position.set(x, y + 3.75, z);
      roof.castShadow = true;
      group.add(roof);
    });

    // Harbor Pier / Wooden Dock
    const dockGeo = new THREE.BoxGeometry(6, 0.8, 28);
    const dockMat = new THREE.MeshStandardMaterial({ color: '#78350f', roughness: 0.85 });
    const dock = new THREE.Mesh(dockGeo, dockMat);
    dock.position.set(0, 2.2, island.radius + 6);
    dock.receiveShadow = true;
    group.add(dock);

  } else if (island.id === 'jungle_island') {
    // Ancient Stepped Stone Temple
    const templeMat = new THREE.MeshStandardMaterial({ color: '#334155', roughness: 0.9 });
    for (let tier = 0; tier < 4; tier++) {
      const size = 32 - tier * 7;
      const stepGeo = new THREE.BoxGeometry(size, 3, size);
      const step = new THREE.Mesh(stepGeo, templeMat);
      step.position.set(0, 5 + tier * 3, 0);
      step.castShadow = true;
      group.add(step);
    }
  } else if (island.id === 'desert_island') {
    // Massive Sand Pyramid
    const pyramidGeo = new THREE.ConeGeometry(38, 28, 4);
    const sandStoneMat = new THREE.MeshStandardMaterial({ color: '#d97706', roughness: 0.95 });
    const pyramid = new THREE.Mesh(pyramidGeo, sandStoneMat);
    pyramid.rotation.y = Math.PI / 4;
    pyramid.position.set(0, 16, 0);
    pyramid.castShadow = true;
    group.add(pyramid);
  } else if (island.id === 'marine_fortress') {
    // Marine Citadel High Castle Bastion
    const wallMat = new THREE.MeshStandardMaterial({ color: '#475569', roughness: 0.85 });
    const wallGeo = new THREE.BoxGeometry(45, 18, 45);
    const wall = new THREE.Mesh(wallGeo, wallMat);
    wall.position.set(0, 12, 0);
    wall.castShadow = true;
    group.add(wall);

    // Towers at corners
    const towerGeo = new THREE.CylinderGeometry(5, 5.5, 24, 16);
    const towerMat = new THREE.MeshStandardMaterial({ color: '#334155', roughness: 0.8 });
    [ [-22, -22], [22, -22], [-22, 22], [22, 22] ].forEach(([tx, tz]) => {
      const tower = new THREE.Mesh(towerGeo, towerMat);
      tower.position.set(tx, 15, tz);
      tower.castShadow = true;
      group.add(tower);
    });
  } else if (island.id === 'volcano_island') {
    // Volcanic Cone with Lava Crater
    const volcanoGeo = new THREE.CylinderGeometry(14, 48, 26, 24);
    const rockMat = new THREE.MeshStandardMaterial({ color: '#1c1917', roughness: 0.95 });
    const volcano = new THREE.Mesh(volcanoGeo, rockMat);
    volcano.position.set(0, 15, 0);
    volcano.castShadow = true;
    group.add(volcano);

    // Glowing Lava Crater Core
    const lavaGeo = new THREE.CircleGeometry(13, 24);
    const lavaMat = new THREE.MeshStandardMaterial({
      color: '#ef4444',
      emissive: '#dc2626',
      emissiveIntensity: 1.5,
      roughness: 0.4,
    });
    const lava = new THREE.Mesh(lavaGeo, lavaMat);
    lava.rotation.x = -Math.PI / 2;
    lava.position.set(0, 27.5, 0);
    group.add(lava);

    const lavaLight = new THREE.PointLight('#ef4444', 4, 60);
    lavaLight.position.set(0, 32, 0);
    group.add(lavaLight);
  } else if (island.id === 'sky_island') {
    // Fluffy cloud base & golden bell shrine
    const cloudMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.95 });
    for (let c = 0; c < 8; c++) {
      const puffGeo = new THREE.DodecahedronGeometry(12);
      const puff = new THREE.Mesh(puffGeo, cloudMat);
      const angle = (c / 8) * Math.PI * 2;
      puff.position.set(Math.cos(angle) * 32, 2, Math.sin(angle) * 32);
      group.add(puff);
    }

    // Golden Temple Pillars
    const goldPillarGeo = new THREE.CylinderGeometry(1.2, 1.4, 16, 12);
    const goldPillarMat = new THREE.MeshStandardMaterial({ color: '#facc15', metalness: 0.9, roughness: 0.2 });
    [ [-12, -12], [12, -12], [-12, 12], [12, 12] ].forEach(([px, pz]) => {
      const pillar = new THREE.Mesh(goldPillarGeo, goldPillarMat);
      pillar.position.set(px, 12, pz);
      group.add(pillar);
    });
  }

  // 3. Palm Trees scattered on islands (except volcano)
  if (island.id !== 'volcano_island') {
    const trunkGeo = new THREE.CylinderGeometry(0.35, 0.6, 6, 7);
    const leavesGeo = new THREE.ConeGeometry(3.5, 3.0, 6);
    const trunkMat = new THREE.MeshStandardMaterial({ color: '#78350f', roughness: 0.9 });
    const leafMat = new THREE.MeshStandardMaterial({ color: '#15803d', roughness: 0.8 });

    const treeCount = island.id === 'jungle_island' ? 18 : 8;
    for (let i = 0; i < treeCount; i++) {
      const r = 20 + Math.random() * (island.radius * 0.7 - 20);
      const theta = (i / treeCount) * Math.PI * 2 + (Math.random() * 0.4);
      const tx = Math.cos(theta) * r;
      const tz = Math.sin(theta) * r;

      const tree = new THREE.Group();
      tree.position.set(tx, 5, tz);

      const trunk = new THREE.Mesh(trunkGeo, trunkMat);
      trunk.position.y = 3;
      trunk.rotation.z = (Math.random() - 0.5) * 0.2;
      trunk.castShadow = true;
      tree.add(trunk);

      const leaves = new THREE.Mesh(leavesGeo, leafMat);
      leaves.position.y = 6.5;
      leaves.castShadow = true;
      tree.add(leaves);

      group.add(tree);
    }
  }

  return group;
}

// -------------------------------------------------------------
// NPC / Quest Giver Billboard / Model
// -------------------------------------------------------------
export function createNPCModel(role: 'quest' | 'fruit_dealer' | 'boat_dealer', name: string): THREE.Group {
  const npc = new THREE.Group();

  let coatColor = '#2563eb';
  let hat: 'straw_hat' | 'bandana' | 'marine_cap' | 'tricorn' | 'none' = 'bandana';

  if (role === 'fruit_dealer') {
    coatColor = '#9333ea';
    hat = 'tricorn';
  } else if (role === 'boat_dealer') {
    coatColor = '#0d9488';
    hat = 'bandana';
  }

  const char = createCharacterModel({
    shirtColor: coatColor,
    pantsColor: '#1e293b',
    hatType: hat,
    faceType: 'hero',
  });
  npc.add(char.group);

  // Floating Role Badge Canvas Texture
  const badgeCanvas = document.createElement('canvas');
  badgeCanvas.width = 256;
  badgeCanvas.height = 64;
  const ctx = badgeCanvas.getContext('2d')!;

  ctx.fillStyle = role === 'quest' ? '#f59e0b' : role === 'fruit_dealer' ? '#a855f7' : '#06b6d4';
  ctx.fillRect(0, 0, 256, 64);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 26px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(name, 128, 32);

  const badgeTex = new THREE.CanvasTexture(badgeCanvas);
  badgeTex.colorSpace = THREE.SRGBColorSpace;
  const badgeMat = new THREE.SpriteMaterial({ map: badgeTex });
  const sprite = new THREE.Sprite(badgeMat);
  sprite.scale.set(3.2, 0.8, 1);
  sprite.position.y = 3.2;
  npc.add(sprite);

  return npc;
}
