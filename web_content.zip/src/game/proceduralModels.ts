/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

// Procedural Canvas Texture Generators
export function createAsphaltTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Base asphalt dark grey
  ctx.fillStyle = '#1e2229';
  ctx.fillRect(0, 0, 512, 512);

  // Noise grain
  const imgData = ctx.getImageData(0, 0, 512, 512);
  const data = imgData.data;
  for (let i = 0; i < data.length; i += 4) {
    const grain = (Math.random() - 0.5) * 28;
    data[i] = Math.max(0, Math.min(255, data[i] + grain));
    data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + grain));
    data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + grain));
  }
  ctx.putImageData(imgData, 0, 0);

  // Cracks
  ctx.strokeStyle = '#121417';
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(80, 20);
  ctx.lineTo(130, 90);
  ctx.lineTo(210, 110);
  ctx.lineTo(260, 220);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(380, 320);
  ctx.lineTo(340, 390);
  ctx.lineTo(410, 480);
  ctx.stroke();

  // White road divider dashed lines
  ctx.fillStyle = '#f8fafc';
  for (let y = 30; y < 512; y += 100) {
    ctx.fillRect(250, y, 12, 55);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function createHazardTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#dc2626'; // Red base for explosive barrel
  ctx.fillRect(0, 0, 256, 256);

  // Yellow and black warning stripes
  ctx.fillStyle = '#fbbf24';
  ctx.fillRect(0, 90, 256, 60);

  ctx.fillStyle = '#111827';
  ctx.beginPath();
  for (let i = -50; i < 300; i += 40) {
    ctx.moveTo(i, 90);
    ctx.lineTo(i + 25, 90);
    ctx.lineTo(i + 5, 150);
    ctx.lineTo(i - 20, 150);
    ctx.closePath();
  }
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function createBuildingTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Concrete dark building facade
  ctx.fillStyle = '#151922';
  ctx.fillRect(0, 0, 256, 512);

  // Windows grid
  const cols = 5;
  const rows = 12;
  const w = 24;
  const h = 26;
  const gapX = 22;
  const gapY = 16;

  for (let c = 0; c < cols; c++) {
    for (let r = 0; r < rows; r++) {
      const x = 20 + c * (w + gapX);
      const y = 20 + r * (h + gapY);

      // Random lit windows (dystopian yellow/amber/broken dark)
      const rand = Math.random();
      if (rand > 0.88) {
        ctx.fillStyle = '#fef08a'; // Bright amber
      } else if (rand > 0.72) {
        ctx.fillStyle = '#f97316'; // Emergency orange
      } else if (rand > 0.6) {
        ctx.fillStyle = '#0284c7'; // Dim blue monitor glow
      } else {
        ctx.fillStyle = '#0b0e14'; // Dark broken window
      }
      ctx.fillRect(x, y, w, h);

      // Window frame
      ctx.strokeStyle = '#27272a';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(x, y, w, h);
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// ==========================================
// 1. SURVIVOR PLAYER CHARACTER (Composite Model)
// ==========================================
export interface PlayerMeshComponents {
  root: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  weaponHolder: THREE.Group;
  muzzleFlash: THREE.Mesh;
  muzzleLight: THREE.PointLight;
}

export function createSurvivorModel(): PlayerMeshComponents {
  const root = new THREE.Group();
  root.name = 'PlayerSurvivor';

  // Base material palette
  const vestMat = new THREE.MeshStandardMaterial({
    color: 0x1f2937,
    roughness: 0.7,
    metalness: 0.2,
  });
  const clothMat = new THREE.MeshStandardMaterial({
    color: 0x374151,
    roughness: 0.85,
    metalness: 0.1,
  });
  const armorMat = new THREE.MeshStandardMaterial({
    color: 0x111827,
    roughness: 0.45,
    metalness: 0.65,
  });
  const skinMat = new THREE.MeshStandardMaterial({
    color: 0xd4a373,
    roughness: 0.6,
    metalness: 0.05,
  });
  const visorMat = new THREE.MeshStandardMaterial({
    color: 0x06b6d4,
    emissive: 0x06b6d4,
    emissiveIntensity: 0.8,
    roughness: 0.15,
    metalness: 0.9,
  });
  const leatherMat = new THREE.MeshStandardMaterial({
    color: 0x271e16,
    roughness: 0.8,
    metalness: 0.2,
  });

  // Pelvis / Hips
  const hips = new THREE.Group();
  hips.position.y = 0.9;
  root.add(hips);

  const hipsMesh = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.2, 0.24), clothMat);
  hipsMesh.castShadow = true;
  hips.add(hipsMesh);

  // Tactical belt with pouch
  const belt = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.08, 0.28), armorMat);
  const pouch = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.1, 0.08), leatherMat);
  pouch.position.set(0.16, 0, 0.14);
  hips.add(belt, pouch);

  // Torso
  const torso = new THREE.Group();
  torso.position.y = 0.2;
  hips.add(torso);

  const torsoMesh = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.46, 0.26), clothMat);
  torsoMesh.position.y = 0.23;
  torsoMesh.castShadow = true;
  torso.add(torsoMesh);

  // Tactical Vest Plates
  const vestFront = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 0.12), vestMat);
  vestFront.position.set(0, 0.24, 0.1);
  vestFront.castShadow = true;
  torso.add(vestFront);

  const vestBack = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.38, 0.08), vestMat);
  vestBack.position.set(0, 0.24, -0.11);
  torso.add(vestBack);

  // Radio transmitter on shoulder
  const radio = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.12, 0.05), armorMat);
  radio.position.set(-0.16, 0.42, 0.08);
  torso.add(radio);

  // Head & Tactical Helmet
  const head = new THREE.Group();
  head.position.y = 0.48;
  torso.add(head);

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.09, 0.1, 8), skinMat);
  neck.position.y = 0.05;
  head.add(neck);

  const headMesh = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.24, 0.24), skinMat);
  headMesh.position.y = 0.2;
  head.add(headMesh);

  const helmet = new THREE.Mesh(new THREE.BoxGeometry(0.29, 0.18, 0.28), armorMat);
  helmet.position.set(0, 0.26, -0.01);
  helmet.castShadow = true;
  head.add(helmet);

  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.06, 0.06), visorMat);
  visor.position.set(0, 0.2, 0.13);
  head.add(visor);

  // Left Leg (Pivot at hip)
  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.13, 0, 0);
  hips.add(leftLeg);

  const leftUpperLeg = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.42, 0.16), clothMat);
  leftUpperLeg.position.y = -0.21;
  leftUpperLeg.castShadow = true;
  leftLeg.add(leftUpperLeg);

  const leftKneePad = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.1, 0.08), armorMat);
  leftKneePad.position.set(0, -0.4, 0.09);
  leftLeg.add(leftKneePad);

  const leftLowerLeg = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.42, 0.15), clothMat);
  leftLowerLeg.position.y = -0.6;
  leftLowerLeg.castShadow = true;
  leftLeg.add(leftLowerLeg);

  const leftBoot = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.12, 0.22), leatherMat);
  leftBoot.position.set(0, -0.84, 0.04);
  leftBoot.castShadow = true;
  leftLeg.add(leftBoot);

  // Right Leg (Pivot at hip)
  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.13, 0, 0);
  hips.add(rightLeg);

  const rightUpperLeg = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.42, 0.16), clothMat);
  rightUpperLeg.position.y = -0.21;
  rightUpperLeg.castShadow = true;
  rightLeg.add(rightUpperLeg);

  const rightKneePad = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.1, 0.08), armorMat);
  rightKneePad.position.set(0, -0.4, 0.09);
  rightLeg.add(rightKneePad);

  const rightLowerLeg = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.42, 0.15), clothMat);
  rightLowerLeg.position.y = -0.6;
  rightLowerLeg.castShadow = true;
  rightLeg.add(rightLowerLeg);

  const rightBoot = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.12, 0.22), leatherMat);
  rightBoot.position.set(0, -0.84, 0.04);
  rightBoot.castShadow = true;
  rightLeg.add(rightBoot);

  // Left Arm (Shoulder pivot)
  const leftArm = new THREE.Group();
  leftArm.position.set(-0.28, 0.4, 0);
  torso.add(leftArm);

  const leftArmMesh = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.55, 0.14), clothMat);
  leftArmMesh.position.y = -0.25;
  leftArmMesh.castShadow = true;
  leftArm.add(leftArmMesh);

  const leftHand = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.12, 0.11), armorMat);
  leftHand.position.y = -0.55;
  leftArm.add(leftHand);

  // Right Arm (Shoulder pivot, aiming forward)
  const rightArm = new THREE.Group();
  rightArm.position.set(0.28, 0.4, 0);
  torso.add(rightArm);

  const rightArmMesh = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.55, 0.14), clothMat);
  rightArmMesh.position.y = -0.25;
  rightArmMesh.castShadow = true;
  rightArm.add(rightArmMesh);

  const rightHand = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.12, 0.11), armorMat);
  rightHand.position.y = -0.55;
  rightArm.add(rightHand);

  // Weapon Holder attached to right hand
  const weaponHolder = new THREE.Group();
  weaponHolder.position.set(0, -0.55, 0.2);
  rightArm.add(weaponHolder);

  // Default Weapon: M4 Tactical Carbine
  const gunMat = new THREE.MeshStandardMaterial({ color: 0x1c1917, metalness: 0.85, roughness: 0.25 });
  const gunGripMat = new THREE.MeshStandardMaterial({ color: 0x44403c, roughness: 0.8 });

  const gunBody = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.12, 0.48), gunMat);
  gunBody.position.z = 0.15;
  gunBody.castShadow = true;
  weaponHolder.add(gunBody);

  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.35, 8), gunMat);
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 0.03, 0.48);
  barrel.castShadow = true;
  weaponHolder.add(barrel);

  const magazine = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.16, 0.1), gunGripMat);
  magazine.position.set(0, -0.1, 0.15);
  magazine.rotation.x = 0.2;
  weaponHolder.add(magazine);

  const sight = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.04, 0.08), gunMat);
  sight.position.set(0, 0.08, 0.25);
  weaponHolder.add(sight);

  // Muzzle Flash Billboard & Dynamic Point Light
  const muzzleGeo = new THREE.SphereGeometry(0.1, 6, 6);
  const muzzleMat = new THREE.MeshBasicMaterial({
    color: 0xfef08a,
    transparent: true,
    opacity: 0,
  });
  const muzzleFlash = new THREE.Mesh(muzzleGeo, muzzleMat);
  muzzleFlash.position.set(0, 0.03, 0.68);
  weaponHolder.add(muzzleFlash);

  const muzzleLight = new THREE.PointLight(0xffa500, 0, 8);
  muzzleLight.position.set(0, 0.03, 0.7);
  weaponHolder.add(muzzleLight);

  // Soft contact shadow circle beneath survivor
  const shadowGeo = new THREE.CircleGeometry(0.42, 16);
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x000000,
    transparent: true,
    opacity: 0.45,
    depthWrite: false,
  });
  const contactShadow = new THREE.Mesh(shadowGeo, shadowMat);
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.02;
  root.add(contactShadow);

  return {
    root,
    torso,
    head,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    weaponHolder,
    muzzleFlash,
    muzzleLight,
  };
}

// ==========================================
// 2. ZOMBIE MODELS (Walker, Runner, Brute)
// ==========================================
export function createZombieModel(type: 'WALKER' | 'RUNNER' | 'BRUTE'): {
  root: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  eyeLight?: THREE.PointLight;
} {
  const root = new THREE.Group();
  root.name = `Zombie_${type}`;

  const skinColor = type === 'RUNNER' ? 0x854d0e : type === 'BRUTE' ? 0x365314 : 0x475569;
  const clothColor = type === 'RUNNER' ? 0x7f1d1d : type === 'BRUTE' ? 0x1f2937 : 0x334155;
  const eyeColor = type === 'RUNNER' ? 0xef4444 : type === 'BRUTE' ? 0xf97316 : 0x84cc16;

  const skinMat = new THREE.MeshStandardMaterial({
    color: skinColor,
    roughness: 0.85,
    metalness: 0.05,
  });
  const clothMat = new THREE.MeshStandardMaterial({
    color: clothColor,
    roughness: 0.9,
    metalness: 0.05,
  });
  const eyeMat = new THREE.MeshStandardMaterial({
    color: eyeColor,
    emissive: eyeColor,
    emissiveIntensity: 1.4,
    roughness: 0.2,
  });
  const bloodMat = new THREE.MeshStandardMaterial({
    color: 0x881337,
    roughness: 0.3,
  });

  const scale = type === 'BRUTE' ? 1.6 : type === 'RUNNER' ? 0.9 : 1.05;
  root.scale.set(scale, scale, scale);

  const hips = new THREE.Group();
  hips.position.y = 0.88;
  root.add(hips);

  const hipsMesh = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.2, 0.24), clothMat);
  hipsMesh.castShadow = true;
  hips.add(hipsMesh);

  // Torso
  const torso = new THREE.Group();
  torso.position.y = 0.18;
  hips.add(torso);

  const torsoMesh = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.48, 0.26), clothMat);
  torsoMesh.position.y = 0.24;
  torsoMesh.castShadow = true;
  torso.add(torsoMesh);

  // Rib / Blood tear accent
  const bloodDecal = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.15, 0.05), bloodMat);
  bloodDecal.position.set(0.08, 0.22, 0.14);
  torso.add(bloodDecal);

  // Head
  const head = new THREE.Group();
  head.position.y = 0.52;
  torso.add(head);

  const headMesh = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.26, 0.24), skinMat);
  headMesh.position.y = 0.14;
  headMesh.castShadow = true;
  head.add(headMesh);

  // Glowing eyes
  const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 6), eyeMat);
  leftEye.position.set(-0.06, 0.15, 0.13);
  const rightEye = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 6), eyeMat);
  rightEye.position.set(0.06, 0.15, 0.13);
  head.add(leftEye, rightEye);

  // Broken jaw
  const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.08, 0.12), bloodMat);
  jaw.position.set(0, 0.04, 0.12);
  head.add(jaw);

  // Legs
  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.12, 0, 0);
  hips.add(leftLeg);
  const leftLegMesh = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.85, 0.15), clothMat);
  leftLegMesh.position.y = -0.42;
  leftLegMesh.castShadow = true;
  leftLeg.add(leftLegMesh);

  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.12, 0, 0);
  hips.add(rightLeg);
  const rightLegMesh = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.85, 0.15), clothMat);
  rightLegMesh.position.y = -0.42;
  rightLegMesh.castShadow = true;
  rightLeg.add(rightLegMesh);

  // Arms (Reaching out menacingly)
  const leftArm = new THREE.Group();
  leftArm.position.set(-0.28, 0.42, 0);
  leftArm.rotation.x = -Math.PI / 3;
  torso.add(leftArm);
  const leftArmMesh = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.6, 0.12), skinMat);
  leftArmMesh.position.y = -0.3;
  leftArmMesh.castShadow = true;
  leftArm.add(leftArmMesh);

  const rightArm = new THREE.Group();
  rightArm.position.set(0.28, 0.42, 0);
  rightArm.rotation.x = -Math.PI / 2.8;
  torso.add(rightArm);

  if (type === 'BRUTE') {
    // Massive mutant club fist
    const bruteArm = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.65, 0.26), skinMat);
    bruteArm.position.y = -0.32;
    bruteArm.castShadow = true;
    rightArm.add(bruteArm);
    const clubFist = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 0.35), bloodMat);
    clubFist.position.y = -0.68;
    rightArm.add(clubFist);
  } else {
    const rightArmMesh = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.6, 0.12), skinMat);
    rightArmMesh.position.y = -0.3;
    rightArmMesh.castShadow = true;
    rightArm.add(rightArmMesh);
  }

  // Soft contact shadow
  const shadowGeo = new THREE.CircleGeometry(0.45 * scale, 16);
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x000000,
    transparent: true,
    opacity: 0.45,
    depthWrite: false,
  });
  const shadow = new THREE.Mesh(shadowGeo, shadowMat);
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.02;
  root.add(shadow);

  return { root, torso, head, leftArm, rightArm, leftLeg, rightLeg };
}

// ==========================================
// 3. EXPLOSIVE HAZARDOUS BARREL
// ==========================================
export function createExplosiveBarrel(): THREE.Group {
  const barrel = new THREE.Group();
  barrel.name = 'ExplosiveBarrel';

  const hazardTex = createHazardTexture();
  const drumMat = new THREE.MeshStandardMaterial({
    map: hazardTex,
    roughness: 0.4,
    metalness: 0.6,
  });
  const rimMat = new THREE.MeshStandardMaterial({
    color: 0x18181b,
    metalness: 0.8,
    roughness: 0.3,
  });

  const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 1.1, 16), drumMat);
  drum.position.y = 0.55;
  drum.castShadow = true;
  drum.receiveShadow = true;
  barrel.add(drum);

  const topRim = new THREE.Mesh(new THREE.TorusGeometry(0.41, 0.03, 8, 16), rimMat);
  topRim.rotation.x = Math.PI / 2;
  topRim.position.y = 1.05;
  barrel.add(topRim);

  const botRim = new THREE.Mesh(new THREE.TorusGeometry(0.41, 0.03, 8, 16), rimMat);
  botRim.rotation.x = Math.PI / 2;
  botRim.position.y = 0.05;
  barrel.add(botRim);

  // Cap
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.05, 8), rimMat);
  cap.position.set(0.18, 1.11, 0.1);
  barrel.add(cap);

  return barrel;
}

// ==========================================
// 4. PICKUPS (Ammo, Medkit, Keycard/Sample, Weapons)
// ==========================================
export function createPickupMesh(type: 'AMMO' | 'MEDKIT' | 'SAMPLE' | 'WEAPON_RIFLE' | 'WEAPON_SHOTGUN'): THREE.Group {
  const group = new THREE.Group();
  group.name = `Pickup_${type}`;

  // Holographic rotating pedestal
  const baseRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.45, 0.03, 8, 24),
    new THREE.MeshStandardMaterial({
      color: type === 'MEDKIT' ? 0x22c55e : type === 'AMMO' ? 0x06b6d4 : type === 'SAMPLE' ? 0xeab308 : 0xec4899,
      emissive: type === 'MEDKIT' ? 0x22c55e : type === 'AMMO' ? 0x06b6d4 : type === 'SAMPLE' ? 0xeab308 : 0xec4899,
      emissiveIntensity: 1.2,
      roughness: 0.2,
    })
  );
  baseRing.rotation.x = Math.PI / 2;
  baseRing.position.y = 0.05;
  group.add(baseRing);

  if (type === 'MEDKIT') {
    const boxMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3, metalness: 0.1 });
    const crossMat = new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0xef4444, emissiveIntensity: 0.6 });

    const medBox = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.32, 0.22), boxMat);
    medBox.position.y = 0.45;
    medBox.castShadow = true;
    group.add(medBox);

    const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.08, 0.23), crossMat);
    crossH.position.y = 0.45;
    const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.24, 0.23), crossMat);
    crossV.position.y = 0.45;
    group.add(crossH, crossV);
  } else if (type === 'AMMO') {
    const boxMat = new THREE.MeshStandardMaterial({ color: 0x166534, roughness: 0.5, metalness: 0.6 });
    const ammoMat = new THREE.MeshStandardMaterial({ color: 0xeab308, emissive: 0xeab308, emissiveIntensity: 0.5 });

    const ammoBox = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.28, 0.25), boxMat);
    ammoBox.position.y = 0.45;
    ammoBox.castShadow = true;
    group.add(ammoBox);

    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.06, 0.26), ammoMat);
    stripe.position.y = 0.45;
    group.add(stripe);
  } else if (type === 'SAMPLE') {
    // Biochemical canister
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0x10b981,
      emissive: 0x10b981,
      emissiveIntensity: 0.9,
      transmission: 0.7,
      roughness: 0.1,
    });
    const capMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, metalness: 0.9, roughness: 0.2 });

    const vial = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.36, 16), glassMat);
    vial.position.y = 0.45;
    group.add(vial);

    const topCap = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.08, 16), capMat);
    topCap.position.y = 0.65;
    const botCap = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.08, 16), capMat);
    botCap.position.y = 0.25;
    group.add(topCap, botCap);
  } else {
    // Weapon pickup model
    const gunMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, roughness: 0.2 });
    const neonMat = new THREE.MeshStandardMaterial({ color: 0xec4899, emissive: 0xec4899, emissiveIntensity: 1.0 });

    const gunBody = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.18, 0.7), gunMat);
    gunBody.position.y = 0.5;
    gunBody.castShadow = true;
    group.add(gunBody);

    const halo = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.02, 8, 16), neonMat);
    halo.position.y = 0.5;
    group.add(halo);
  }

  // Soft glowing point light
  const lightColor = type === 'MEDKIT' ? 0x22c55e : type === 'AMMO' ? 0x06b6d4 : type === 'SAMPLE' ? 0xeab308 : 0xec4899;
  const light = new THREE.PointLight(lightColor, 1.2, 3.5);
  light.position.y = 0.6;
  group.add(light);

  return group;
}

// ==========================================
// 5. URBAN PROPS (Abandoned Cars, Streetlights, Barriers)
// ==========================================
export function createWreckedCar(color: number = 0x1e3a8a): THREE.Group {
  const car = new THREE.Group();
  car.name = 'WreckedCar';

  const bodyMat = new THREE.MeshStandardMaterial({
    color: color,
    metalness: 0.4,
    roughness: 0.7, // Rusted abandoned car
  });
  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.2,
    metalness: 0.8,
  });
  const tireMat = new THREE.MeshStandardMaterial({
    color: 0x18181b,
    roughness: 0.9,
  });

  // Main chassis
  const chassis = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.65, 4.0), bodyMat);
  chassis.position.y = 0.55;
  chassis.castShadow = true;
  chassis.receiveShadow = true;
  car.add(chassis);

  // Cabin
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.65, 0.6, 2.1), glassMat);
  cabin.position.set(0, 1.05, -0.2);
  cabin.castShadow = true;
  car.add(cabin);

  // 4 Wheels
  const wheelGeo = new THREE.CylinderGeometry(0.36, 0.36, 0.25, 12);
  wheelGeo.rotateZ(Math.PI / 2);

  const wheelPositions = [
    [-1.0, 0.36, 1.3],
    [1.0, 0.36, 1.3],
    [-1.0, 0.36, -1.3],
    [1.0, 0.36, -1.3],
  ];

  wheelPositions.forEach(([x, y, z]) => {
    const wheel = new THREE.Mesh(wheelGeo, tireMat);
    wheel.position.set(x, y, z);
    wheel.castShadow = true;
    car.add(wheel);
  });

  // Broken headlight
  const lightGeo = new THREE.BoxGeometry(0.3, 0.15, 0.08);
  const lightMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xfef08a, emissiveIntensity: 0.2 });
  const headL = new THREE.Mesh(lightGeo, lightMat);
  headL.position.set(0.65, 0.65, 2.0);
  car.add(headL);

  return car;
}

export function createStreetlight(): THREE.Group {
  const lightPost = new THREE.Group();
  lightPost.name = 'Streetlight';

  const poleMat = new THREE.MeshStandardMaterial({ color: 0x27272a, metalness: 0.85, roughness: 0.3 });
  const lampMat = new THREE.MeshStandardMaterial({
    color: 0xfef08a,
    emissive: 0xfef08a,
    emissiveIntensity: 1.5,
  });

  // Tall vertical post
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 5.5, 8), poleMat);
  pole.position.y = 2.75;
  pole.castShadow = true;
  lightPost.add(pole);

  // Top horizontal arm
  const arm = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.09, 1.4), poleMat);
  arm.position.set(0, 5.4, 0.6);
  lightPost.add(arm);

  // Lamp shade & bulb
  const lamp = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.2, 8), poleMat);
  lamp.rotation.x = Math.PI;
  lamp.position.set(0, 5.3, 1.25);
  lightPost.add(lamp);

  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), lampMat);
  bulb.position.set(0, 5.2, 1.25);
  lightPost.add(bulb);

  // Spot light down to the street
  const spot = new THREE.SpotLight(0xfef08a, 4.5, 14, Math.PI / 4, 0.5, 1.5);
  spot.position.set(0, 5.2, 1.25);
  spot.target.position.set(0, 0, 1.25);
  lightPost.add(spot);
  lightPost.add(spot.target);

  return lightPost;
}

export function createConcreteBarrier(): THREE.Group {
  const barrier = new THREE.Group();
  barrier.name = 'ConcreteBarrier';

  const barrierMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    roughness: 0.9,
    metalness: 0.05,
  });
  const stripeMat = new THREE.MeshStandardMaterial({
    color: 0xeab308,
    roughness: 0.6,
  });

  const base = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.9, 0.6), barrierMat);
  base.position.y = 0.45;
  base.castShadow = true;
  base.receiveShadow = true;
  barrier.add(base);

  const reflector = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.1, 0.62), stripeMat);
  reflector.position.y = 0.65;
  barrier.add(reflector);

  return barrier;
}

// ==========================================
// 6. EXTRACTION ZONE BEACON (Mission Goal)
// ==========================================
export function createExtractionBeacon(): THREE.Group {
  const beacon = new THREE.Group();
  beacon.name = 'ExtractionBeacon';

  // Landing Helipad Pad
  const padGeo = new THREE.CylinderGeometry(4.5, 4.5, 0.1, 32);
  const padMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.8,
  });
  const pad = new THREE.Mesh(padGeo, padMat);
  pad.position.y = 0.05;
  pad.receiveShadow = true;
  beacon.add(pad);

  // Big Green 'H' marking
  const greenNeonMat = new THREE.MeshStandardMaterial({
    color: 0x22c55e,
    emissive: 0x22c55e,
    emissiveIntensity: 1.5,
    roughness: 0.2,
  });

  const hBar1 = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.12, 3.2), greenNeonMat);
  hBar1.position.set(-1.0, 0.12, 0);
  const hBar2 = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.12, 3.2), greenNeonMat);
  hBar2.position.set(1.0, 0.12, 0);
  const hCross = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.12, 0.4), greenNeonMat);
  hCross.position.set(0, 0.12, 0);
  beacon.add(hBar1, hBar2, hCross);

  // 4 Corner Warning Beacons
  const cornerPositions = [
    [-3.5, 0, -3.5],
    [3.5, 0, -3.5],
    [-3.5, 0, 3.5],
    [3.5, 0, 3.5],
  ];

  cornerPositions.forEach(([x, y, z]) => {
    const post = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.08, 1.2, 8),
      new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.9 })
    );
    post.position.set(x, 0.6, z);
    post.castShadow = true;

    const strobe = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 8), greenNeonMat);
    strobe.position.set(x, 1.25, z);

    const beaconLight = new THREE.PointLight(0x22c55e, 2, 6);
    beaconLight.position.set(x, 1.3, z);

    beacon.add(post, strobe, beaconLight);
  });

  // Vertical extraction green laser beam
  const beamGeo = new THREE.CylinderGeometry(0.18, 0.4, 25, 12, 1, true);
  const beamMat = new THREE.MeshBasicMaterial({
    color: 0x4ade80,
    transparent: true,
    opacity: 0.45,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const laserBeam = new THREE.Mesh(beamGeo, beamMat);
  laserBeam.position.y = 12.5;
  beacon.add(laserBeam);

  return beacon;
}
