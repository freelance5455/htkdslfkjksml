/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { CharacterDef } from '../types/game';

// Shared texture generator to guarantee ZERO external 404 dependencies
export class ProceduralTextures {
  private static hazardTexture: THREE.CanvasTexture | null = null;
  private static graffitiTextures: THREE.CanvasTexture[] = [];
  private static buildingTextures: THREE.CanvasTexture[] = [];
  private static crateTexture: THREE.CanvasTexture | null = null;
  private static contactShadowTexture: THREE.CanvasTexture | null = null;
  private static ballastTexture: THREE.CanvasTexture | null = null;

  public static getHazardTexture(): THREE.CanvasTexture {
    if (this.hazardTexture) return this.hazardTexture;
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 64;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#f59e0b'; // Amber yellow
    ctx.fillRect(0, 0, 256, 64);
    ctx.fillStyle = '#111827'; // Dark charcoal
    ctx.beginPath();
    for (let x = -64; x < 320; x += 40) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x + 25, 0);
      ctx.lineTo(x - 5, 64);
      ctx.lineTo(x - 30, 64);
      ctx.closePath();
    }
    ctx.fill();

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    this.hazardTexture = tex;
    return tex;
  }

  public static getGraffitiTexture(index: number = 0): THREE.CanvasTexture {
    if (this.graffitiTextures[index]) return this.graffitiTextures[index];
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;

    // Train steel side background
    ctx.fillStyle = index === 0 ? '#dc2626' : index === 1 ? '#2563eb' : '#059669';
    ctx.fillRect(0, 0, 512, 128);

    // Accent racing stripe
    ctx.fillStyle = '#facc15';
    ctx.fillRect(0, 20, 512, 12);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 32, 512, 6);

    // Bold stylized graffiti tags
    const tags = ['RUSH', 'SUBWAY 99', 'SPEED', 'NEO METRO', 'DASH'];
    const tag = tags[index % tags.length];

    ctx.save();
    ctx.font = 'bold 58px "Impact", "Arial Black", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.translate(256, 80);
    ctx.rotate(-0.06);

    // Drop shadow
    ctx.fillStyle = '#0f172a';
    ctx.fillText(tag, 3, 3);

    // Gradient fill
    const grad = ctx.createLinearGradient(0, -30, 0, 30);
    grad.addColorStop(0, '#fef08a');
    grad.addColorStop(0.5, '#f97316');
    grad.addColorStop(1, '#ec4899');
    ctx.fillStyle = grad;
    ctx.fillText(tag, 0, 0);

    // White highlight
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    ctx.strokeText(tag, 0, 0);
    ctx.restore();

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    this.graffitiTextures[index] = tex;
    return tex;
  }

  public static getCrateTexture(): THREE.CanvasTexture {
    if (this.crateTexture) return this.crateTexture;
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Wood base
    ctx.fillStyle = '#b45309';
    ctx.fillRect(0, 0, 256, 256);

    // Planks
    ctx.fillStyle = '#92400e';
    for (let y = 64; y < 256; y += 64) {
      ctx.fillRect(0, y - 2, 256, 4);
    }

    // Border frame
    ctx.fillStyle = '#78350f';
    ctx.lineWidth = 14;
    ctx.strokeRect(7, 7, 242, 242);

    // Diagonal brace
    ctx.beginPath();
    ctx.moveTo(14, 14);
    ctx.lineTo(242, 242);
    ctx.lineWidth = 12;
    ctx.stroke();

    // Rivets
    ctx.fillStyle = '#451a03';
    [[20, 20], [236, 20], [20, 236], [236, 236], [128, 128]].forEach(([rx, ry]) => {
      ctx.beginPath();
      ctx.arc(rx, ry, 6, 0, Math.PI * 2);
      ctx.fill();
    });

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    this.crateTexture = tex;
    return tex;
  }

  public static getBuildingTexture(paletteIdx: number): THREE.CanvasTexture {
    if (this.buildingTextures[paletteIdx]) return this.buildingTextures[paletteIdx];
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Vibrant sunny daylight architectural colors
    const wallColors = ['#f8fafc', '#fed7aa', '#bae6fd', '#fef08a', '#e2e8f0'];
    ctx.fillStyle = wallColors[paletteIdx % wallColors.length];
    ctx.fillRect(0, 0, 256, 512);

    // Decorative architectural cornices
    ctx.fillStyle = '#cbd5e1';
    ctx.fillRect(0, 0, 256, 12);
    ctx.fillRect(0, 250, 256, 8);

    // Window grid with reflective daylight sky sheen
    const cols = 5;
    const rows = 14;
    const winW = 32;
    const winH = 22;
    const padX = 16;
    const padY = 14;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const x = padX + c * (winW + padX);
        const y = padY + r * (winH + padY);

        // Daytime reflective sky blue windows
        const isReflective = (r + c) % 3 !== 0;
        ctx.fillStyle = isReflective ? '#38bdf8' : '#0284c7';
        ctx.fillRect(x, y, winW, winH);

        // Window specular daylight glare
        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.beginPath();
        ctx.moveTo(x + 4, y + 2);
        ctx.lineTo(x + 14, y + 2);
        ctx.lineTo(x + 6, y + winH - 2);
        ctx.lineTo(x + 2, y + winH - 2);
        ctx.closePath();
        ctx.fill();

        // Window frame
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(x, y, winW, winH);
      }
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    this.buildingTextures[paletteIdx] = tex;
    return tex;
  }

  public static getContactShadowTexture(): THREE.CanvasTexture {
    if (this.contactShadowTexture) return this.contactShadowTexture;
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;

    const grad = ctx.createRadialGradient(64, 64, 4, 64, 64, 60);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.7)');
    grad.addColorStop(0.5, 'rgba(0, 0, 0, 0.35)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 128);

    const tex = new THREE.CanvasTexture(canvas);
    this.contactShadowTexture = tex;
    return tex;
  }

  public static getBallastTexture(): THREE.CanvasTexture {
    if (this.ballastTexture) return this.ballastTexture;
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Sunny stone ballast base
    ctx.fillStyle = '#64748b';
    ctx.fillRect(0, 0, 256, 256);

    // Gravel pebbles in daylight stone tones
    for (let i = 0; i < 400; i++) {
      const gx = Math.random() * 256;
      const gy = Math.random() * 256;
      const gr = 1.5 + Math.random() * 3.5;
      const shade = Math.random() > 0.5 ? '#94a3b8' : '#475569';
      ctx.fillStyle = shade;
      ctx.beginPath();
      ctx.arc(gx, gy, gr, 0, Math.PI * 2);
      ctx.fill();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(2, 6);
    this.ballastTexture = tex;
    return tex;
  }
}

// -------------------------------------------------------------
// Procedural Animated Character Rig
// -------------------------------------------------------------
export interface CharacterRig {
  root: THREE.Group;
  head: THREE.Group;
  torso: THREE.Group;
  leftArm: THREE.Group;
  leftForearm: THREE.Group;
  rightArm: THREE.Group;
  rightForearm: THREE.Group;
  leftLeg: THREE.Group;
  leftShin: THREE.Group;
  rightLeg: THREE.Group;
  rightShin: THREE.Group;
  jetpack: THREE.Group;
  superSneakersLeft: THREE.Mesh;
  superSneakersRight: THREE.Mesh;
  shieldBubble: THREE.Mesh;
  shadowMesh: THREE.Mesh;
}

export function createCharacterModel(character: CharacterDef): CharacterRig {
  const root = new THREE.Group();
  root.name = `character_${character.id}`;

  const colors = character.colors;

  // Materials with varied roughness and metalness
  const skinMat = new THREE.MeshStandardMaterial({
    color: colors.skin,
    roughness: 0.65,
    metalness: 0.05,
  });
  const shirtMat = new THREE.MeshStandardMaterial({
    color: colors.shirt,
    roughness: 0.5,
    metalness: 0.1,
  });
  const pantsMat = new THREE.MeshStandardMaterial({
    color: colors.pants,
    roughness: 0.7,
    metalness: 0.05,
  });
  const shoesMat = new THREE.MeshStandardMaterial({
    color: colors.shoes,
    roughness: 0.3,
    metalness: 0.2,
  });
  const hatMat = new THREE.MeshStandardMaterial({
    color: colors.hat,
    roughness: 0.45,
    metalness: 0.1,
  });
  const hairMat = new THREE.MeshStandardMaterial({
    color: colors.hair,
    roughness: 0.85,
    metalness: 0.05,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: colors.accent,
    roughness: 0.2,
    metalness: 0.7,
  });

  // Hips / Pelvis
  const modelRoot = new THREE.Group();
  modelRoot.rotation.y = Math.PI; // Face forward down the tracks (away from camera)
  root.add(modelRoot);

  const hips = new THREE.Group();
  hips.position.y = 0.95;
  modelRoot.add(hips);

  // Torso
  const torso = new THREE.Group();
  const torsoGeom = new THREE.BoxGeometry(0.55, 0.65, 0.32);
  const torsoMesh = new THREE.Mesh(torsoGeom, shirtMat);
  torsoMesh.position.y = 0.35;
  torsoMesh.castShadow = true;
  torso.add(torsoMesh);

  // Hoodie collar / trim
  const collarGeom = new THREE.CylinderGeometry(0.2, 0.24, 0.1, 16);
  const collarMesh = new THREE.Mesh(collarGeom, hatMat);
  collarMesh.position.y = 0.68;
  torso.add(collarMesh);

  // Front zipper / graphic print
  const printGeom = new THREE.PlaneGeometry(0.12, 0.45);
  const printMat = new THREE.MeshBasicMaterial({ color: colors.accent });
  const printMesh = new THREE.Mesh(printGeom, printMat);
  printMesh.position.set(0, 0.35, 0.165);
  torso.add(printMesh);

  // Backpack
  const backpackGeom = new THREE.BoxGeometry(0.38, 0.48, 0.18);
  const backpackMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.6 });
  const backpackMesh = new THREE.Mesh(backpackGeom, backpackMat);
  backpackMesh.position.set(0, 0.35, -0.22);
  backpackMesh.castShadow = true;
  torso.add(backpackMesh);

  // Spray can attached to backpack
  const canGeom = new THREE.CylinderGeometry(0.05, 0.05, 0.22, 10);
  const canMat = new THREE.MeshStandardMaterial({ color: colors.accent, metalness: 0.8, roughness: 0.2 });
  const canMesh = new THREE.Mesh(canGeom, canMat);
  canMesh.position.set(0.18, 0.35, -0.2);
  canMesh.rotation.z = 0.2;
  torso.add(canMesh);

  // Head
  const head = new THREE.Group();
  head.position.y = 0.82;
  torso.add(head);

  const headGeom = new THREE.BoxGeometry(0.38, 0.42, 0.38);
  const headMesh = new THREE.Mesh(headGeom, skinMat);
  headMesh.position.y = 0.18;
  headMesh.castShadow = true;
  head.add(headMesh);

  // Hair
  const hairGeom = new THREE.BoxGeometry(0.42, 0.16, 0.42);
  const hairMesh = new THREE.Mesh(hairGeom, hairMat);
  hairMesh.position.y = 0.36;
  head.add(hairMesh);

  // Hat / Beanie / Visor
  const hatGeom = new THREE.CylinderGeometry(0.24, 0.25, 0.16, 16);
  const hatMesh = new THREE.Mesh(hatGeom, hatMat);
  hatMesh.position.y = 0.38;
  hatMesh.rotation.x = -0.1;
  head.add(hatMesh);

  // Cap visor (brim) facing backwards or forward
  const brimGeom = new THREE.BoxGeometry(0.26, 0.04, 0.22);
  const brimMesh = new THREE.Mesh(brimGeom, hatMat);
  brimMesh.position.set(0, 0.36, -0.2);
  brimMesh.rotation.x = 0.15;
  head.add(brimMesh);

  // Cool cartoon sunglasses / visor
  const visorGeom = new THREE.BoxGeometry(0.36, 0.1, 0.08);
  const visorMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    metalness: 0.9,
    roughness: 0.1,
  });
  const visorMesh = new THREE.Mesh(visorGeom, visorMat);
  visorMesh.position.set(0, 0.2, 0.2);
  head.add(visorMesh);

  // ARMS
  const armGeom = new THREE.CylinderGeometry(0.08, 0.07, 0.32, 10);
  const handGeom = new THREE.SphereGeometry(0.08, 8, 8);

  // Left Arm
  const leftArm = new THREE.Group();
  leftArm.position.set(-0.35, 0.55, 0);
  torso.add(leftArm);
  const leftArmMesh = new THREE.Mesh(armGeom, shirtMat);
  leftArmMesh.position.y = -0.16;
  leftArmMesh.castShadow = true;
  leftArm.add(leftArmMesh);

  const leftForearm = new THREE.Group();
  leftForearm.position.y = -0.32;
  leftArm.add(leftForearm);
  const leftForeMesh = new THREE.Mesh(armGeom, skinMat);
  leftForeMesh.position.y = -0.14;
  leftForearm.add(leftForeMesh);
  const leftHand = new THREE.Mesh(handGeom, skinMat);
  leftHand.position.y = -0.3;
  leftForearm.add(leftHand);

  // Right Arm
  const rightArm = new THREE.Group();
  rightArm.position.set(0.35, 0.55, 0);
  torso.add(rightArm);
  const rightArmMesh = new THREE.Mesh(armGeom, shirtMat);
  rightArmMesh.position.y = -0.16;
  rightArmMesh.castShadow = true;
  rightArm.add(rightArmMesh);

  const rightForearm = new THREE.Group();
  rightForearm.position.y = -0.32;
  rightArm.add(rightForearm);
  const rightForeMesh = new THREE.Mesh(armGeom, skinMat);
  rightForeMesh.position.y = -0.14;
  rightForearm.add(rightForeMesh);
  const rightHand = new THREE.Mesh(handGeom, skinMat);
  rightHand.position.y = -0.3;
  rightForearm.add(rightHand);

  // LEGS
  const thighGeom = new THREE.CylinderGeometry(0.11, 0.09, 0.42, 10);
  const shinGeom = new THREE.CylinderGeometry(0.09, 0.08, 0.42, 10);
  const shoeGeom = new THREE.BoxGeometry(0.18, 0.16, 0.36);

  // Left Leg
  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.16, 0, 0);
  hips.add(leftLeg);
  const leftThighMesh = new THREE.Mesh(thighGeom, pantsMat);
  leftThighMesh.position.y = -0.21;
  leftThighMesh.castShadow = true;
  leftLeg.add(leftThighMesh);

  const leftShin = new THREE.Group();
  leftShin.position.y = -0.42;
  leftLeg.add(leftShin);
  const leftShinMesh = new THREE.Mesh(shinGeom, pantsMat);
  leftShinMesh.position.y = -0.21;
  leftShin.add(leftShinMesh);

  const leftShoe = new THREE.Mesh(shoeGeom, shoesMat);
  leftShoe.position.set(0, -0.42, 0.06);
  leftShoe.castShadow = true;
  leftShin.add(leftShoe);

  // Super Sneaker booster left
  const boosterGeom = new THREE.BoxGeometry(0.24, 0.1, 0.42);
  const boosterMat = new THREE.MeshStandardMaterial({
    color: 0xfacc15,
    metalness: 0.8,
    roughness: 0.2,
    emissive: 0xca8a04,
    emissiveIntensity: 0.4,
  });
  const superSneakersLeft = new THREE.Mesh(boosterGeom, boosterMat);
  superSneakersLeft.position.set(0, -0.45, 0.06);
  superSneakersLeft.visible = false;
  leftShin.add(superSneakersLeft);

  // Right Leg
  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.16, 0, 0);
  hips.add(rightLeg);
  const rightThighMesh = new THREE.Mesh(thighGeom, pantsMat);
  rightThighMesh.position.y = -0.21;
  rightThighMesh.castShadow = true;
  rightLeg.add(rightThighMesh);

  const rightShin = new THREE.Group();
  rightShin.position.y = -0.42;
  rightLeg.add(rightShin);
  const rightShinMesh = new THREE.Mesh(shinGeom, pantsMat);
  rightShinMesh.position.y = -0.21;
  rightShin.add(rightShinMesh);

  const rightShoe = new THREE.Mesh(shoeGeom, shoesMat);
  rightShoe.position.set(0, -0.42, 0.06);
  rightShoe.castShadow = true;
  rightShin.add(rightShoe);

  // Super Sneaker booster right
  const superSneakersRight = new THREE.Mesh(boosterGeom, boosterMat);
  superSneakersRight.position.set(0, -0.45, 0.06);
  superSneakersRight.visible = false;
  rightShin.add(superSneakersRight);

  // Attach torso to hips
  hips.add(torso);

  // JETPACK (attached to torso, hidden by default)
  const jetpack = new THREE.Group();
  jetpack.position.set(0, 0.35, -0.28);
  const jetTankGeom = new THREE.CylinderGeometry(0.12, 0.12, 0.55, 12);
  const jetNozzleGeom = new THREE.CylinderGeometry(0.12, 0.16, 0.18, 12);
  const jetMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    metalness: 0.7,
    roughness: 0.25,
  });
  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    metalness: 0.95,
    roughness: 0.1,
  });

  const tankLeft = new THREE.Mesh(jetTankGeom, jetMat);
  tankLeft.position.x = -0.18;
  jetpack.add(tankLeft);
  const nozzleLeft = new THREE.Mesh(jetNozzleGeom, chromeMat);
  nozzleLeft.position.set(-0.18, -0.32, 0);
  jetpack.add(nozzleLeft);

  const tankRight = new THREE.Mesh(jetTankGeom, jetMat);
  tankRight.position.x = 0.18;
  jetpack.add(tankRight);
  const nozzleRight = new THREE.Mesh(jetNozzleGeom, chromeMat);
  nozzleRight.position.set(0.18, -0.32, 0);
  jetpack.add(nozzleRight);

  jetpack.visible = false;
  torso.add(jetpack);

  // SHIELD BUBBLE (forcefield)
  const shieldGeom = new THREE.SphereGeometry(1.2, 24, 24);
  const shieldMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.35,
    roughness: 0.1,
    metalness: 0.8,
    emissive: 0x0284c7,
    emissiveIntensity: 0.5,
  });
  const shieldBubble = new THREE.Mesh(shieldGeom, shieldMat);
  shieldBubble.position.y = 1.0;
  shieldBubble.visible = false;
  root.add(shieldBubble);

  // Contact shadow underneath flush with track
  const shadowGeom = new THREE.PlaneGeometry(1.4, 1.4);
  const shadowMat = new THREE.MeshBasicMaterial({
    map: ProceduralTextures.getContactShadowTexture(),
    transparent: true,
    opacity: 0.6,
    depthWrite: false,
  });
  const shadowMesh = new THREE.Mesh(shadowGeom, shadowMat);
  shadowMesh.rotation.x = -Math.PI / 2;
  shadowMesh.position.y = 0.02;
  root.add(shadowMesh);

  return {
    root,
    head,
    torso,
    leftArm,
    leftForearm,
    rightArm,
    rightForearm,
    leftLeg,
    leftShin,
    rightLeg,
    rightShin,
    jetpack,
    superSneakersLeft,
    superSneakersRight,
    shieldBubble,
    shadowMesh,
  };
}

// -------------------------------------------------------------
// Procedural Train Model (Locomotive & Passenger Carriage)
// -------------------------------------------------------------
export function createTrainModel(isMoving: boolean = false, colorVariant: number = 0, hasRamp: boolean = false): THREE.Group {
  const train = new THREE.Group();
  train.name = 'train';

  const length = 28;
  const width = 2.4;
  const height = 3.6;

  // Primary body
  const bodyGeom = new THREE.BoxGeometry(width, height, length);
  const bodyMat = new THREE.MeshStandardMaterial({
    map: ProceduralTextures.getGraffitiTexture(colorVariant),
    roughness: 0.35,
    metalness: 0.6,
  });
  const bodyMesh = new THREE.Mesh(bodyGeom, bodyMat);
  bodyMesh.position.y = height / 2 + 0.5;
  bodyMesh.castShadow = true;
  bodyMesh.receiveShadow = true;
  train.add(bodyMesh);

  // Train Roof with ridges
  const roofGeom = new THREE.BoxGeometry(width + 0.1, 0.4, length + 0.1);
  const roofMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    roughness: 0.6,
    metalness: 0.4,
  });
  const roofMesh = new THREE.Mesh(roofGeom, roofMat);
  roofMesh.position.y = height + 0.7;
  roofMesh.receiveShadow = true;
  train.add(roofMesh);

  // AC units on roof
  for (let z = -8; z <= 8; z += 8) {
    const acGeom = new THREE.BoxGeometry(1.4, 0.3, 2.2);
    const acMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.7 });
    const ac = new THREE.Mesh(acGeom, acMat);
    ac.position.set(0, height + 1.0, z);
    train.add(ac);
  }

  // Windows along sides
  const winGeom = new THREE.BoxGeometry(width + 0.05, 0.9, 2.2);
  const winMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.1,
    metalness: 0.9,
  });
  for (let z = -10; z <= 10; z += 4) {
    const win = new THREE.Mesh(winGeom, winMat);
    win.position.set(0, height / 2 + 0.7, z);
    train.add(win);
  }

  // Front cabin windshield
  const windshieldGeom = new THREE.BoxGeometry(width - 0.2, 1.2, 0.1);
  const frontWin = new THREE.Mesh(windshieldGeom, winMat);
  frontWin.position.set(0, height / 2 + 0.8, length / 2 + 0.02);
  train.add(frontWin);

  // Headlights
  const lightGeom = new THREE.CylinderGeometry(0.22, 0.22, 0.1, 16);
  const lightMat = new THREE.MeshStandardMaterial({
    color: 0xfffbeb,
    emissive: 0xfef08a,
    emissiveIntensity: 1.8,
    roughness: 0.1,
  });
  [-0.7, 0.7].forEach((x) => {
    const headlight = new THREE.Mesh(lightGeom, lightMat);
    headlight.rotation.x = Math.PI / 2;
    headlight.position.set(x, 1.2, length / 2 + 0.05);
    train.add(headlight);
  });

  // Red Tail lights on rear
  const tailMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    emissive: 0xdc2626,
    emissiveIntensity: 1.2,
  });
  [-0.7, 0.7].forEach((x) => {
    const taillight = new THREE.Mesh(lightGeom, tailMat);
    taillight.rotation.x = Math.PI / 2;
    taillight.position.set(x, 1.2, -length / 2 - 0.05);
    train.add(taillight);
  });

  // Steel wheels and bogies
  const wheelGeom = new THREE.CylinderGeometry(0.38, 0.38, 0.2, 16);
  const steelMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.9,
    roughness: 0.25,
  });
  [-11, -9, 9, 11].forEach((z) => {
    [-1.0, 1.0].forEach((x) => {
      const wheel = new THREE.Mesh(wheelGeom, steelMat);
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(x, 0.38, z);
      train.add(wheel);
    });
  });

  // Optional Ramp in front of train for jumping onto roof
  if (hasRamp) {
    const rampGeom = new THREE.BoxGeometry(width - 0.2, 0.2, 4.8);
    const rampMat = new THREE.MeshStandardMaterial({
      map: ProceduralTextures.getHazardTexture(),
      roughness: 0.5,
    });
    const rampMesh = new THREE.Mesh(rampGeom, rampMat);
    // Slope upward towards train roof
    rampMesh.rotation.x = -Math.atan2(height + 0.5, 4.8);
    rampMesh.position.set(0, (height + 0.5) / 2, length / 2 + 2.2);
    rampMesh.castShadow = true;
    train.add(rampMesh);
  }

  // Contact shadow beneath train
  const shadowGeom = new THREE.PlaneGeometry(width * 1.3, length * 1.05);
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x000000,
    transparent: true,
    opacity: 0.5,
    depthWrite: false,
  });
  const shadow = new THREE.Mesh(shadowGeom, shadowMat);
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.02;
  train.add(shadow);

  // Store metadata
  train.userData = {
    isMoving,
    hasRamp,
    width,
    height: height + 0.8,
    length,
    speed: isMoving ? 14 : 0,
  };

  return train;
}

// -------------------------------------------------------------
// Procedural Barriers & Hazards
// -------------------------------------------------------------

// Low hurdle barrier: Must jump over or switch lanes
export function createLowBarrier(): THREE.Group {
  const group = new THREE.Group();
  group.name = 'barrier_low';

  const poleGeom = new THREE.CylinderGeometry(0.08, 0.08, 1.1, 10);
  const poleMat = new THREE.MeshStandardMaterial({ color: 0x374151, metalness: 0.7, roughness: 0.3 });

  // Left & right posts
  [-1.0, 1.0].forEach((x) => {
    const pole = new THREE.Mesh(poleGeom, poleMat);
    pole.position.set(x, 0.55, 0);
    pole.castShadow = true;
    group.add(pole);

    // Support feet
    const footGeom = new THREE.BoxGeometry(0.3, 0.1, 0.6);
    const foot = new THREE.Mesh(footGeom, poleMat);
    foot.position.set(x, 0.05, 0);
    group.add(foot);
  });

  // Crossbar with hazard stripes
  const barGeom = new THREE.BoxGeometry(2.3, 0.32, 0.15);
  const barMat = new THREE.MeshStandardMaterial({
    map: ProceduralTextures.getHazardTexture(),
    roughness: 0.4,
  });
  const bar = new THREE.Mesh(barGeom, barMat);
  bar.position.set(0, 0.85, 0);
  bar.castShadow = true;
  group.add(bar);

  // Warning flashing lights
  const lightGeom = new THREE.SphereGeometry(0.1, 8, 8);
  const lightMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    emissive: 0xf59e0b,
    emissiveIntensity: 1.5,
  });
  [-0.9, 0.9].forEach((lx) => {
    const l = new THREE.Mesh(lightGeom, lightMat);
    l.position.set(lx, 1.1, 0);
    group.add(l);
  });

  group.userData = {
    type: 'barrier_low',
    height: 1.1,
    width: 2.3,
    depth: 0.5,
  };

  return group;
}

// High overhead sign barrier: Must slide under or switch lanes
export function createHighBarrier(): THREE.Group {
  const group = new THREE.Group();
  group.name = 'barrier_high';

  const poleGeom = new THREE.CylinderGeometry(0.1, 0.1, 3.4, 12);
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x4b5563, metalness: 0.8, roughness: 0.2 });

  [-1.15, 1.15].forEach((x) => {
    const pole = new THREE.Mesh(poleGeom, metalMat);
    pole.position.set(x, 1.7, 0);
    pole.castShadow = true;
    group.add(pole);
  });

  // Overhead warning sign board
  const signGeom = new THREE.BoxGeometry(2.6, 1.4, 0.2);
  const signMat = new THREE.MeshStandardMaterial({
    map: ProceduralTextures.getHazardTexture(),
    roughness: 0.4,
  });
  const sign = new THREE.Mesh(signGeom, signMat);
  sign.position.set(0, 2.4, 0);
  sign.castShadow = true;
  group.add(sign);

  // Clearance bar underneath (bottom edge is at Y = 1.6)
  const clearanceGeom = new THREE.BoxGeometry(2.5, 0.2, 0.12);
  const clearanceMat = new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.5 });
  const clearance = new THREE.Mesh(clearanceGeom, clearanceMat);
  clearance.position.set(0, 1.7, 0);
  group.add(clearance);

  group.userData = {
    type: 'barrier_high',
    minHeight: 1.6, // safe to slide under if player height <= 1.5
    height: 3.4,
    width: 2.5,
    depth: 0.5,
  };

  return group;
}

// Wooden cargo crates stacked: Must jump over or switch lanes
export function createCrates(): THREE.Group {
  const group = new THREE.Group();
  group.name = 'crates';

  const crateGeom = new THREE.BoxGeometry(1.0, 1.0, 1.0);
  const crateMat = new THREE.MeshStandardMaterial({
    map: ProceduralTextures.getCrateTexture(),
    roughness: 0.7,
  });

  // Stack of 2 side by side or 1 high
  const crate1 = new THREE.Mesh(crateGeom, crateMat);
  crate1.position.set(-0.55, 0.5, 0);
  crate1.castShadow = true;
  group.add(crate1);

  const crate2 = new THREE.Mesh(crateGeom, crateMat);
  crate2.position.set(0.55, 0.5, 0);
  crate2.castShadow = true;
  group.add(crate2);

  group.userData = {
    type: 'crates',
    height: 1.05,
    width: 2.2,
    depth: 1.1,
  };

  return group;
}

// -------------------------------------------------------------
// Collectibles & Power-Ups
// -------------------------------------------------------------

// Gold Coin with embossed star
export function createCoin(): THREE.Group {
  const group = new THREE.Group();
  group.name = 'coin';

  // 3D Cylinder Coin
  const coinGeom = new THREE.CylinderGeometry(0.36, 0.36, 0.09, 20);
  const coinMat = new THREE.MeshStandardMaterial({
    color: 0xfacc15,
    metalness: 0.85,
    roughness: 0.18,
    emissive: 0xb45309,
    emissiveIntensity: 0.25,
  });
  const coinMesh = new THREE.Mesh(coinGeom, coinMat);
  coinMesh.rotation.z = Math.PI / 2;
  coinMesh.castShadow = true;
  group.add(coinMesh);

  // Inner star badge / rim
  const rimGeom = new THREE.TorusGeometry(0.28, 0.03, 8, 20);
  const rimMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    metalness: 0.9,
    roughness: 0.1,
  });
  const rimMesh = new THREE.Mesh(rimGeom, rimMat);
  rimMesh.rotation.y = Math.PI / 2;
  group.add(rimMesh);

  group.userData = {
    type: 'coin',
    radius: 0.45,
  };

  return group;
}

// Magnet Power-up (Horseshoe)
export function createMagnetItem(): THREE.Group {
  const group = new THREE.Group();
  group.name = 'powerup_magnet';

  const curve = new THREE.CubicBezierCurve3(
    new THREE.Vector3(-0.4, 0.4, 0),
    new THREE.Vector3(-0.4, -0.4, 0),
    new THREE.Vector3(0.4, -0.4, 0),
    new THREE.Vector3(0.4, 0.4, 0)
  );
  const geom = new THREE.TubeGeometry(curve, 20, 0.12, 12, false);
  const redMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    metalness: 0.5,
    roughness: 0.3,
  });
  const mesh = new THREE.Mesh(geom, redMat);
  group.add(mesh);

  // Silver tips
  const tipGeom = new THREE.CylinderGeometry(0.13, 0.13, 0.2, 12);
  const silverMat = new THREE.MeshStandardMaterial({
    color: 0xf1f5f9,
    metalness: 0.95,
    roughness: 0.15,
  });
  [-0.4, 0.4].forEach((tx) => {
    const tip = new THREE.Mesh(tipGeom, silverMat);
    tip.position.set(tx, 0.4, 0);
    group.add(tip);
  });

  group.userData = {
    type: 'powerup_magnet',
    radius: 0.6,
  };

  return group;
}

// Jetpack Power-up
export function createJetpackItem(): THREE.Group {
  const group = new THREE.Group();
  group.name = 'powerup_jetpack';

  const tankGeom = new THREE.CylinderGeometry(0.18, 0.18, 0.7, 14);
  const tankMat = new THREE.MeshStandardMaterial({
    color: 0x06b6d4,
    metalness: 0.8,
    roughness: 0.2,
    emissive: 0x0891b2,
    emissiveIntensity: 0.3,
  });
  const nozzleGeom = new THREE.CylinderGeometry(0.16, 0.22, 0.25, 14);
  const chromeMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, metalness: 0.95, roughness: 0.1 });

  [-0.24, 0.24].forEach((tx) => {
    const tank = new THREE.Mesh(tankGeom, tankMat);
    tank.position.set(tx, 0.15, 0);
    group.add(tank);

    const nozzle = new THREE.Mesh(nozzleGeom, chromeMat);
    nozzle.position.set(tx, -0.3, 0);
    group.add(nozzle);
  });

  // Connecting bar
  const barGeom = new THREE.BoxGeometry(0.6, 0.15, 0.15);
  const bar = new THREE.Mesh(barGeom, chromeMat);
  bar.position.y = 0.15;
  group.add(bar);

  group.userData = {
    type: 'powerup_jetpack',
    radius: 0.65,
  };

  return group;
}

// Super Sneakers Power-up
export function createSneakersItem(): THREE.Group {
  const group = new THREE.Group();
  group.name = 'powerup_sneakers';

  const shoeGeom = new THREE.BoxGeometry(0.4, 0.35, 0.7);
  const sneakerMat = new THREE.MeshStandardMaterial({
    color: 0xfacc15,
    metalness: 0.7,
    roughness: 0.2,
    emissive: 0xca8a04,
    emissiveIntensity: 0.4,
  });
  const shoe = new THREE.Mesh(shoeGeom, sneakerMat);
  group.add(shoe);

  // Wings on side
  const wingGeom = new THREE.BoxGeometry(0.55, 0.2, 0.04);
  const wingMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.2 });
  const wing = new THREE.Mesh(wingGeom, wingMat);
  wing.position.set(0, 0.15, -0.15);
  group.add(wing);

  // Bouncy spring base
  const springGeom = new THREE.CylinderGeometry(0.2, 0.2, 0.2, 10);
  const springMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.9 });
  const spring = new THREE.Mesh(springGeom, springMat);
  spring.position.y = -0.25;
  group.add(spring);

  group.userData = {
    type: 'powerup_sneakers',
    radius: 0.6,
  };

  return group;
}

// 2X Multiplier Star Power-up
export function createMultiplierItem(): THREE.Group {
  const group = new THREE.Group();
  group.name = 'powerup_multiplier';

  const starGeom = new THREE.OctahedronGeometry(0.45, 1);
  const starMat = new THREE.MeshStandardMaterial({
    color: 0xa855f7,
    metalness: 0.8,
    roughness: 0.15,
    emissive: 0x7e22ce,
    emissiveIntensity: 0.5,
  });
  const star = new THREE.Mesh(starGeom, starMat);
  group.add(star);

  // Outer glowing ring
  const ringGeom = new THREE.TorusGeometry(0.6, 0.05, 8, 24);
  const ringMat = new THREE.MeshStandardMaterial({
    color: 0xf43f5e,
    emissive: 0xe11d48,
    emissiveIntensity: 0.8,
  });
  const ring = new THREE.Mesh(ringGeom, ringMat);
  group.add(ring);

  group.userData = {
    type: 'powerup_multiplier',
    radius: 0.65,
  };

  return group;
}

// -------------------------------------------------------------
// Procedural Track Chunk & City Environment
// -------------------------------------------------------------
export function createTrackChunk(chunkLength: number = 54): THREE.Group {
  const chunk = new THREE.Group();
  chunk.name = 'track_chunk';

  const trackWidth = 9.0;

  // 1. Gravel Ballast Bed
  const ballastGeom = new THREE.BoxGeometry(trackWidth, 0.4, chunkLength);
  const ballastMat = new THREE.MeshStandardMaterial({
    map: ProceduralTextures.getBallastTexture(),
    roughness: 0.9,
    metalness: 0.05,
  });
  const ballastMesh = new THREE.Mesh(ballastGeom, ballastMat);
  ballastMesh.position.y = -0.2;
  ballastMesh.receiveShadow = true;
  chunk.add(ballastMesh);

  // 2. Concrete Track Walls / Curb
  const curbGeom = new THREE.BoxGeometry(0.6, 0.8, chunkLength);
  const curbMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.7 });
  [-trackWidth / 2 - 0.3, trackWidth / 2 + 0.3].forEach((cx) => {
    const curb = new THREE.Mesh(curbGeom, curbMat);
    curb.position.set(cx, 0.2, 0);
    curb.receiveShadow = true;
    chunk.add(curb);
  });

  // 3. Rails & Sleepers for the 3 lanes (-2.8, 0, 2.8)
  const railGeom = new THREE.BoxGeometry(0.08, 0.12, chunkLength);
  const railMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    metalness: 0.95,
    roughness: 0.15,
  });

  const sleeperGeom = new THREE.BoxGeometry(1.9, 0.1, 0.35);
  const sleeperMat = new THREE.MeshStandardMaterial({
    color: 0x3f2512,
    roughness: 0.85,
  });

  const lanes = [-2.8, 0, 2.8];
  lanes.forEach((laneX) => {
    // Twin steel rails
    [-0.6, 0.6].forEach((rx) => {
      const rail = new THREE.Mesh(railGeom, railMat);
      rail.position.set(laneX + rx, 0.06, 0);
      rail.receiveShadow = true;
      chunk.add(rail);
    });

    // Wooden sleepers every 1.8 units
    for (let z = -chunkLength / 2 + 0.9; z < chunkLength / 2; z += 1.8) {
      const sleeper = new THREE.Mesh(sleeperGeom, sleeperMat);
      sleeper.position.set(laneX, 0.04, z);
      sleeper.receiveShadow = true;
      chunk.add(sleeper);
    }
  });

  // 4. Overhead Catenary Gantries (Railway arches)
  const gantryGeom = new THREE.CylinderGeometry(0.12, 0.12, 6.2, 12);
  const gantryCrossGeom = new THREE.BoxGeometry(trackWidth + 1.2, 0.25, 0.25);
  const gantryMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.3 });

  const gantry = new THREE.Group();
  gantry.position.set(0, 0, 0);

  const leftPillar = new THREE.Mesh(gantryGeom, gantryMat);
  leftPillar.position.set(-trackWidth / 2 - 0.5, 3.1, 0);
  gantry.add(leftPillar);

  const rightPillar = new THREE.Mesh(gantryGeom, gantryMat);
  rightPillar.position.set(trackWidth / 2 + 0.5, 3.1, 0);
  gantry.add(rightPillar);

  const crossBeam = new THREE.Mesh(gantryCrossGeom, gantryMat);
  crossBeam.position.set(0, 5.8, 0);
  gantry.add(crossBeam);

  // Electrical insulators hanging down
  lanes.forEach((lx) => {
    const wireGeom = new THREE.CylinderGeometry(0.04, 0.04, 0.8, 8);
    const wire = new THREE.Mesh(wireGeom, gantryMat);
    wire.position.set(lx, 5.3, 0);
    gantry.add(wire);
  });

  chunk.add(gantry);

  // 5. Stylized City Skyscrapers on both sides
  const buildingHeights = [24, 34, 18, 42, 28, 38];
  [-1, 1].forEach((side) => {
    for (let bz = -chunkLength / 2 + 9; bz < chunkLength / 2; bz += 18) {
      const bHeight = buildingHeights[Math.floor(Math.random() * buildingHeights.length)];
      const bWidth = 10 + Math.random() * 6;
      const bDepth = 12 + Math.random() * 4;

      const buildingGeom = new THREE.BoxGeometry(bWidth, bHeight, bDepth);
      const paletteIdx = Math.floor(Math.random() * 5);
      const buildingMat = new THREE.MeshStandardMaterial({
        map: ProceduralTextures.getBuildingTexture(paletteIdx),
        roughness: 0.6,
        metalness: 0.2,
      });

      const bMesh = new THREE.Mesh(buildingGeom, buildingMat);
      bMesh.position.set(side * (trackWidth / 2 + 3.5 + bWidth / 2), bHeight / 2 - 0.5, bz);
      bMesh.receiveShadow = true;
      chunk.add(bMesh);

      // Rooftop props: water tower or antenna
      if (Math.random() > 0.4) {
        const roofPropGeom = new THREE.CylinderGeometry(1.2, 1.2, 2.5, 12);
        const roofPropMat = new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.8 });
        const prop = new THREE.Mesh(roofPropGeom, roofPropMat);
        prop.position.set(
          side * (trackWidth / 2 + 3.5 + bWidth / 2),
          bHeight + 1.25,
          bz
        );
        chunk.add(prop);
      }
    }
  });

  // 6. Streetlamps / Lanterns with warm glow
  [-1, 1].forEach((side) => {
    const lampGeom = new THREE.CylinderGeometry(0.06, 0.08, 3.8, 8);
    const lampMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.7 });
    const lamp = new THREE.Mesh(lampGeom, lampMat);
    lamp.position.set(side * (trackWidth / 2 + 0.6), 1.9, -15);
    chunk.add(lamp);

    // Glowing lantern bulb
    const bulbGeom = new THREE.SphereGeometry(0.18, 8, 8);
    const bulbMat = new THREE.MeshStandardMaterial({
      color: 0xfef08a,
      emissive: 0xfef08a,
      emissiveIntensity: 1.2,
    });
    const bulb = new THREE.Mesh(bulbGeom, bulbMat);
    bulb.position.set(side * (trackWidth / 2 + 0.6), 3.8, -15);
    chunk.add(bulb);
  });

  return chunk;
}
