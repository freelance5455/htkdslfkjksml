// ============================================================
// DEEP DIG — shovels, metal detector, player character + animation rig
// ============================================================
import * as THREE from "three";
import { M, mesh } from "./treasureModels";
import { clamp, lerp } from "./terrain";

export const SHOVEL_LEN = 1.14;
export const LEFT_GRIP_Y = -0.24;

function bladeGeo(w: number, len: number, depth = 0.014, cup = 2.2) {
  const s = new THREE.Shape();
  s.moveTo(-w, 0);
  s.lineTo(w, 0);
  s.lineTo(w, -len * 0.35);
  s.quadraticCurveTo(w * 0.92, -len * 0.82, 0, -len);
  s.quadraticCurveTo(-w * 0.92, -len * 0.82, -w, -len * 0.35);
  s.lineTo(-w, 0);
  const g = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: true, bevelSize: 0.004, bevelThickness: 0.004, bevelSegments: 1, curveSegments: 8 });
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) p.setZ(i, p.getZ(i) - (p.getX(i) * p.getX(i)) * cup * (1 + (-p.getY(i) / len) * 0.3));
  g.computeVertexNormals();
  return g;
}

export function buildShovel(id: string): THREE.Group {
  const g = new THREE.Group();
  const cyl = (r: number, len: number, y: number, mat: THREE.Material) => g.add(mesh(new THREE.CylinderGeometry(r, r, len, 10), mat, 0, y, 0));
  switch (id) {
    case "wood": {
      const wood = M(0xb98650, { rough: 0.85 });
      const dark = M(0x7a5330, { rough: 0.9 });
      cyl(0.019, 0.8, -0.38, wood);
      g.add(mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.2, 8), wood, 0, 0.07, 0, 0, 0, Math.PI / 2));
      g.add(mesh(new THREE.SphereGeometry(0.022, 8, 6), wood, 0.1, 0.07, 0));
      g.add(mesh(new THREE.SphereGeometry(0.022, 8, 6), wood, -0.1, 0.07, 0));
      g.add(mesh(new THREE.CylinderGeometry(0.024, 0.024, 0.07, 8), dark, 0, -0.03, 0));
      g.add(mesh(bladeGeo(0.115, 0.36, 0.016, 1.6), M(0xc79a62, { rough: 0.8, side: true }), 0, -0.78, 0));
      g.add(mesh(new THREE.CylinderGeometry(0.03, 0.022, 0.1, 8), M(0x555a60, { metal: 0.8, rough: 0.5 }), 0, -0.75, 0));
      g.add(mesh(new THREE.BoxGeometry(0.1, 0.012, 0.012), M(0x555a60, { metal: 0.8, rough: 0.5 }), 0, -1.13, -0.005));
      break;
    }
    case "iron": {
      const wood = M(0x6b4a2c, { rough: 0.85 });
      const iron = M(0x3b3f45, { metal: 0.85, rough: 0.5, side: true });
      cyl(0.02, 0.8, -0.38, wood);
      g.add(mesh(new THREE.CylinderGeometry(0.019, 0.019, 0.22, 8), wood, 0, 0.08, 0, 0, 0, Math.PI / 2));
      g.add(mesh(bladeGeo(0.13, 0.37, 0.016, 2.0), iron, 0, -0.78, 0));
      g.add(mesh(new THREE.CylinderGeometry(0.036, 0.024, 0.14, 8), iron, 0, -0.74, 0));
      for (const x of [-0.07, 0.07]) g.add(mesh(new THREE.SphereGeometry(0.008, 6, 4), M(0x9aa0a8, { metal: 1 }), x, -0.84, -0.012));
      g.add(mesh(new THREE.TorusGeometry(0.024, 0.006, 5, 10), M(0x9aa0a8, { metal: 1 }), 0, -0.55, 0, Math.PI / 2));
      break;
    }
    case "steel": {
      const steel = M(0xcfd5dc, { metal: 1, rough: 0.2, env: 1.6, side: true });
      const black = M(0x1d1f22, { rough: 0.6 });
      cyl(0.018, 0.8, -0.38, M(0x8f979f, { metal: 0.9, rough: 0.3 }));
      cyl(0.024, 0.2, 0.0, black);
      cyl(0.024, 0.2, -0.28, black);
      g.add(mesh(new THREE.TorusGeometry(0.055, 0.016, 8, 16), black, 0, 0.1, 0));
      g.add(mesh(bladeGeo(0.145, 0.38, 0.014, 2.0), steel, 0, -0.78, 0));
      g.add(mesh(new THREE.BoxGeometry(0.014, 0.28, 0.02), steel, 0, -0.95, 0.012));
      g.add(mesh(new THREE.CylinderGeometry(0.04, 0.026, 0.12, 10), steel, 0, -0.74, 0));
      g.add(mesh(new THREE.BoxGeometry(0.3, 0.014, 0.05), steel, 0, -0.785, 0.02));
      break;
    }
    case "pro": {
      const orange = M(0xf47b20, { rough: 0.4, env: 0.6 });
      const black = M(0x17191c, { rough: 0.7 });
      const steel = M(0xdfe5ea, { metal: 1, rough: 0.16, env: 1.8, side: true });
      cyl(0.02, 0.8, -0.38, orange);
      cyl(0.027, 0.26, -0.02, black);
      cyl(0.027, 0.24, -0.3, black);
      g.add(mesh(new THREE.TorusGeometry(0.06, 0.018, 8, 16), M(0xffc21a, { rough: 0.5 }), 0, 0.1, 0));
      g.add(mesh(bladeGeo(0.16, 0.39, 0.016, 2.1), steel, 0, -0.78, 0));
      for (const x of [-0.07, 0, 0.07]) g.add(mesh(new THREE.BoxGeometry(0.012, 0.3, 0.018), steel, x, -0.95, 0.016));
      for (let i = -3; i <= 3; i++) g.add(mesh(new THREE.ConeGeometry(0.015, 0.03, 4), steel, i * 0.045, -1.15 + Math.abs(i) * 0.012, 0.005, Math.PI, 0, 0));
      g.add(mesh(new THREE.CylinderGeometry(0.045, 0.028, 0.14, 10), steel, 0, -0.74, 0));
      g.add(mesh(new THREE.BoxGeometry(0.34, 0.016, 0.06), M(0x2b2f35, { metal: 0.7, rough: 0.4 }), 0, -0.79, 0.025));
      break;
    }
    case "golden": {
      const gold = M(0xffc933, { metal: 1, rough: 0.2, env: 1.8, em: 0x7a5200, emI: 0.5, side: true });
      cyl(0.02, 0.8, -0.38, gold);
      for (const y of [-0.12, -0.45, -0.62]) g.add(mesh(new THREE.TorusGeometry(0.026, 0.01, 6, 14), gold, 0, y, 0, Math.PI / 2));
      g.add(mesh(new THREE.TorusGeometry(0.065, 0.02, 8, 18), gold, 0, 0.1, 0));
      g.add(mesh(new THREE.OctahedronGeometry(0.035, 0), M(0x2f6bff, { metal: 0.1, rough: 0.05, flat: true, em: 0x2f6bff, emI: 0.7, env: 2 }), 0, 0.17, 0));
      g.add(mesh(bladeGeo(0.16, 0.39, 0.016, 2.0), gold, 0, -0.78, 0));
      g.add(mesh(new THREE.BoxGeometry(0.016, 0.3, 0.02), gold, 0, -0.95, 0.014));
      g.add(mesh(new THREE.CylinderGeometry(0.045, 0.026, 0.14, 10), gold, 0, -0.74, 0));
      for (const x of [-0.07, 0.07]) g.add(mesh(new THREE.OctahedronGeometry(0.018, 0), M(0xe0143c, { metal: 0.1, rough: 0.05, flat: true, em: 0xe0143c, emI: 0.8 }), x, -0.84, 0.014));
      g.add(mesh(new THREE.BoxGeometry(0.1, 0.012, 0.012), gold, 0, -0.42, 0, 0, 0, 0));
      break;
    }
  }
  return g;
}

export function buildDetector(): THREE.Group {
  const g = new THREE.Group();
  const dark = M(0x23272d, { rough: 0.6 });
  const yellow = M(0xf2b21c, { rough: 0.45 });
  g.add(mesh(new THREE.CylinderGeometry(0.014, 0.014, 1.2, 8), M(0xb9bfc6, { metal: 0.9, rough: 0.3 }), 0, -0.6, 0));
  g.add(mesh(new THREE.CylinderGeometry(0.024, 0.024, 0.2, 8), dark, 0, 0, 0, 0, 0, Math.PI / 2));
  g.add(mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.14, 8), dark, 0, -0.04, 0));
  const box = mesh(new THREE.BoxGeometry(0.09, 0.07, 0.15), yellow, 0, -0.26, 0.05);
  g.add(box);
  const screen = M(0x0a1a10, { em: 0x22ff77, emI: 0.9, rough: 0.3 });
  g.add(mesh(new THREE.BoxGeometry(0.06, 0.003, 0.08), screen, 0, -0.226, 0.05));
  const ledMat = new THREE.MeshStandardMaterial({ color: 0x331100, emissive: 0xff4400, emissiveIntensity: 0.2 });
  g.add(mesh(new THREE.SphereGeometry(0.014, 8, 6), ledMat, 0.025, -0.23, 0.115));
  g.userData.led = ledMat;
  g.add(mesh(new THREE.TorusGeometry(0.06, 0.012, 6, 12, Math.PI), dark, 0, -0.19, -0.04, 0, Math.PI / 2, 0));
  const joint = new THREE.Group();
  joint.position.set(0, -1.2, 0);
  joint.rotation.x = 1.0;
  joint.add(mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.028, 28), dark, 0, 0, 0.1));
  joint.add(mesh(new THREE.TorusGeometry(0.25, 0.016, 6, 28), yellow, 0, 0, 0.1, Math.PI / 2));
  joint.add(mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.034, 24), M(0x3a4048, { rough: 0.5 }), 0, 0, 0.1));
  joint.add(mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.07, 8), dark, 0, 0.02, 0));
  g.add(joint);
  return g;
}

// ---------------- Character rig ----------------
export interface RigInput {
  speed: number; // metres per second
  run: boolean;
  grounded: boolean;
  vy: number;
  dig: number; // 0..1 progress or -1
  pickup: number; // 0..1 progress or -1
  scanning: boolean;
  dy: number; // dig-point ground height relative to player
  reach: number;
  tool: "shovel" | "detector";
}

const DOWN = new THREE.Vector3(0, -1, 0);
const _v = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()];
const _q = new THREE.Quaternion();
const _m = new THREE.Matrix4();
const _e = new THREE.Euler();

function solveArm(up: THREE.Group, fore: THREE.Group, S: THREE.Vector3, T: THREE.Vector3, a: number, b: number, pole: THREE.Vector3) {
  const d = _v[0].copy(T).sub(S);
  let L = d.length();
  const maxL = a + b - 0.002;
  if (L > maxL) {
    d.multiplyScalar(maxL / L);
    L = maxL;
  }
  L = Math.max(L, 0.12);
  const dir = _v[1].copy(d).normalize();
  const cosA = clamp((a * a + L * L - b * b) / (2 * a * L), -1, 1);
  const A = Math.acos(cosA);
  const side = _v[2].copy(pole).addScaledVector(dir, -pole.dot(dir)).normalize();
  const elbowDir = _v[3].copy(dir).multiplyScalar(Math.cos(A)).addScaledVector(side, Math.sin(A));
  up.position.copy(S);
  up.quaternion.setFromUnitVectors(DOWN, elbowDir);
  const E = _v[4].copy(S).addScaledVector(elbowDir, a);
  const fdir = _v[2].copy(S).add(d).sub(E).normalize();
  fdir.applyQuaternion(_q.copy(up.quaternion).invert());
  fore.quaternion.setFromUnitVectors(DOWN, fdir);
}

// dig keyframes: [u, y, z, tilt, yaw, roll, lean, crouch]
const KEYS = [
  [0.0, 0, 0, 0.9, 0, 0, 0.05, 0],
  [0.22, 0, 0, 0.3, 0, 0, -0.1, 0],
  [0.4, 0, 0, 0.5, 0, 0, 0.5, 0.5],
  [0.5, 0, 0, 0.55, 0, 0, 0.6, 0.7],
  [0.72, 0, 0, 0.0, 0, 0, 0.25, 0.25],
  [0.86, 0, 0, 0.15, 0.6, 0.9, 0.1, 0.1],
  [1.0, 0, 0, 0.9, 0, 0, 0.05, 0],
];
export const DIG_IMPACT = 0.4;
export const DIG_TOSS = 0.84;

export class Rig {
  root = new THREE.Group();
  hips = new THREE.Group();
  torso = new THREE.Group();
  head = new THREE.Group();
  legs: { up: THREE.Group; low: THREE.Group }[] = [];
  arms: { up: THREE.Group; fore: THREE.Group }[] = [];
  tool: THREE.Group | null = null;
  toolHolder = new THREE.Group();
  phase = 0;
  airT = 0;
  t = 0;
  A = 0.39;
  B = 0.38;
  sweep = 0;

  constructor() {
    const shirt = M(0x2a9d8f, { rough: 0.8 });
    const skin = M(0xdfa77a, { rough: 0.75 });
    const shorts = M(0xb99a62, { rough: 0.9 });
    const boot = M(0x5a3a22, { rough: 0.8 });
    const hair = M(0x3b2a20, { rough: 0.9 });
    const straw = M(0xe6c978, { rough: 0.95, side: true });
    const band = M(0xb5342b, { rough: 0.8 });
    const pack = M(0x8a6a3c, { rough: 0.9 });
    const strap = M(0x4a3420, { rough: 0.9 });

    this.root.add(this.hips);
    this.root.add(this.toolHolder);
    this.hips.position.y = 0.92;
    // pelvis
    const pelvis = mesh(new THREE.CapsuleGeometry(0.15, 0.08, 4, 10), shorts, 0, 0, 0, 0, 0, Math.PI / 2);
    pelvis.scale.set(1, 1, 0.85);
    this.hips.add(pelvis);
    // legs
    for (const s of [-1, 1]) {
      const up = new THREE.Group();
      up.position.set(s * 0.1, -0.02, 0);
      up.add(mesh(new THREE.CapsuleGeometry(0.078, 0.3, 4, 10), skin, 0, -0.2, 0));
      up.add(mesh(new THREE.CylinderGeometry(0.092, 0.1, 0.24, 10), shorts, 0, -0.12, 0));
      const low = new THREE.Group();
      low.position.set(0, -0.44, 0);
      low.add(mesh(new THREE.CapsuleGeometry(0.066, 0.3, 4, 10), skin, 0, -0.2, 0));
      low.add(mesh(new THREE.CylinderGeometry(0.075, 0.085, 0.2, 10), boot, 0, -0.33, 0));
      low.add(mesh(new THREE.BoxGeometry(0.13, 0.09, 0.27), boot, 0, -0.44, 0.05));
      up.add(low);
      this.hips.add(up);
      this.legs.push({ up, low });
    }
    // torso
    this.hips.add(this.torso);
    const tm = mesh(new THREE.CapsuleGeometry(0.17, 0.36, 4, 12), shirt, 0, 0.33, 0);
    tm.scale.set(1.18, 1, 0.82);
    this.torso.add(tm);
    // backpack
    this.torso.add(mesh(new THREE.BoxGeometry(0.3, 0.38, 0.15), pack, 0, 0.36, -0.2));
    this.torso.add(mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.32, 10), strap, 0, 0.6, -0.2, 0, 0, Math.PI / 2));
    this.torso.add(mesh(new THREE.BoxGeometry(0.28, 0.12, 0.05), strap, 0, 0.3, -0.29));
    for (const s of [-1, 1]) this.torso.add(mesh(new THREE.BoxGeometry(0.035, 0.46, 0.02), strap, s * 0.11, 0.38, 0.115, -0.1, 0, 0));
    // neck & head
    this.torso.add(mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.1, 8), skin, 0, 0.72, 0));
    this.head.position.set(0, 0.86, 0);
    this.torso.add(this.head);
    const hd = mesh(new THREE.SphereGeometry(0.15, 16, 12), skin);
    hd.scale.set(0.95, 1.05, 1);
    this.head.add(hd);
    this.head.add(mesh(new THREE.SphereGeometry(0.152, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.45), hair, 0, 0.0, -0.02));
    for (const s of [-1, 1]) this.head.add(mesh(new THREE.SphereGeometry(0.02, 6, 6), M(0x1a1410), s * 0.055, 0.02, 0.138));
    this.head.add(mesh(new THREE.SphereGeometry(0.025, 6, 6), skin, 0, -0.02, 0.15));
    this.head.add(mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.015, 24), straw, 0, 0.1, 0.02));
    this.head.add(mesh(new THREE.CylinderGeometry(0.15, 0.17, 0.1, 16), straw, 0, 0.16, 0.0));
    this.head.add(mesh(new THREE.CylinderGeometry(0.172, 0.172, 0.03, 16, 1, true), band, 0, 0.125, 0));
    // arms
    for (let q = 0; q < 2; q++) {
      const up = new THREE.Group();
      const fore = new THREE.Group();
      up.add(mesh(new THREE.CapsuleGeometry(0.058, this.A - 0.116, 4, 8), shirt, 0, -this.A / 2, 0));
      fore.position.set(0, -this.A, 0);
      fore.add(mesh(new THREE.CapsuleGeometry(0.048, this.B - 0.096, 4, 8), skin, 0, -this.B / 2, 0));
      fore.add(mesh(new THREE.SphereGeometry(0.06, 10, 8), skin, 0, -this.B - 0.01, 0));
      up.add(fore);
      this.torso.add(up);
      this.arms.push({ up, fore });
    }
    this.root.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) (o as THREE.Mesh).castShadow = true;
    });
  }

  setTool(obj: THREE.Group) {
    if (this.tool) this.toolHolder.remove(this.tool);
    this.tool = obj;
    this.toolHolder.add(obj);
    obj.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) (o as THREE.Mesh).castShadow = true;
    });
  }

  private digPose(u: number, dy: number, reach: number, out: number[]) {
    // build key values with dynamic ground-dependent entries
    const cdy = clamp(dy, -0.75, 0.4);
    const yK = [1.0, 1.32, cdy + 1.0, cdy + 0.78, 1.18, 1.3, 1.0];
    const zK = [0.3, 0.33, reach - 0.55, reach - 0.5, 0.58, 0.5, 0.3];
    let i = 0;
    while (i < KEYS.length - 2 && u > KEYS[i + 1][0]) i++;
    const k0 = KEYS[i], k1 = KEYS[i + 1];
    let t = clamp((u - k0[0]) / (k1[0] - k0[0]), 0, 1);
    // ease: fast strike into the ground, smooth otherwise
    t = i === 1 ? t * t : t * t * (3 - 2 * t);
    out[0] = lerp(yK[i], yK[i + 1], t);
    out[1] = lerp(zK[i], zK[i + 1], t);
    for (let q = 3; q <= 7; q++) out[q - 1] = lerp(k0[q], k1[q], t);
    out[6] += clamp(-dy, 0, 1) * 0.25;
  }
  private pose = [0, 0, 0, 0, 0, 0, 0];

  update(dt: number, inp: RigInput, hold: number) {
    this.t += dt;
    const moving = inp.speed > 0.15;
    const sp = inp.run ? 11.5 : 8;
    if (moving && inp.grounded) this.phase += dt * sp * clamp(inp.speed / (inp.run ? 5.6 : 3.2), 0.6, 1.2);
    else this.phase += dt * 1.5;
    const walkAmt = inp.grounded && moving ? 1 : 0;
    const swing = (inp.run ? 0.95 : 0.55) * walkAmt;

    // locomotion
    let lean = 0.04 + (inp.run && moving ? 0.22 : 0);
    let crouch = 0;
    let toolY = 0, toolZ = 0, toolA = 0, toolYaw = 0, toolRoll = 0, toolX = 0;
    const bob = Math.abs(Math.sin(this.phase)) * (inp.run ? 0.06 : 0.035) * walkAmt;

    if (inp.tool === "shovel") {
      if (inp.dig >= 0) {
        this.digPose(inp.dig, inp.dy, inp.reach, this.pose);
        toolY = this.pose[0]; toolZ = this.pose[1]; toolA = this.pose[2]; toolYaw = this.pose[3]; toolRoll = this.pose[4];
        lean = this.pose[5]; crouch = this.pose[6];
        toolX = -0.02;
      } else {
        toolY = 1.0 + bob * 0.8 + Math.sin(this.t * 1.6) * 0.004;
        toolZ = 0.3;
        toolA = 0.9 + Math.sin(this.phase) * 0.07 * walkAmt;
        toolX = -0.02;
        toolRoll = Math.sin(this.phase) * 0.06 * walkAmt;
      }
    } else {
      toolX = 0.04;
      toolY = 0.9 + bob * 0.6;
      toolZ = 0.4;
      toolA = 1.0;
      if (inp.scanning) {
        this.sweep = lerp(this.sweep, Math.sin(this.t * 2.4) * 0.55, Math.min(1, dt * 8));
      } else this.sweep = lerp(this.sweep, 0, Math.min(1, dt * 6));
      toolYaw = this.sweep;
    }
    if (inp.pickup >= 0) {
      const s = Math.sin(Math.PI * clamp(inp.pickup, 0, 1));
      lean = Math.max(lean, 0.95 * s);
      crouch = Math.max(crouch, 0.8 * s);
      toolZ += 0.1 * s;
      toolY -= 0.25 * s;
    }
    // airborne
    let airKnee = 0, airThigh = 0;
    if (!inp.grounded) {
      const up = clamp(inp.vy / 6, -1, 1);
      airThigh = 0.5 + up * 0.15;
      airKnee = 0.9 - up * 0.3;
      toolY += 0.08 * up;
    }

    // legs
    const crouchHip = crouch * 0.16;
    for (let i = 0; i < 2; i++) {
      const s = i === 0 ? 1 : -1;
      const ph = this.phase + (i === 0 ? 0 : Math.PI);
      const sw = Math.sin(ph) * swing;
      const kneeWalk = Math.max(0, -Math.cos(ph)) * (inp.run ? 1.1 : 0.55) * walkAmt;
      let thigh = -sw - crouch * 0.55 * (i === 0 ? 1 : 0.7) - airThigh * (i === 0 ? 1 : 0.4);
      let knee = kneeWalk + crouch * 1.0 + airKnee * (i === 0 ? 1 : 0.5);
      if (inp.dig >= 0 || inp.pickup >= 0) {
        thigh += s * 0.12 * crouch;
        knee += s * 0.1 * crouch;
      }
      this.legs[i].up.rotation.x = thigh;
      this.legs[i].low.rotation.x = knee;
      this.legs[i].up.rotation.z = (i === 0 ? -1 : 1) * 0.04 * crouch;
    }
    this.hips.position.y = 0.92 - crouchHip + bob - (inp.grounded ? 0 : 0.0);
    this.hips.rotation.y = Math.sin(this.phase) * 0.08 * walkAmt;
    this.torso.rotation.x = lean;
    this.torso.rotation.y = -this.hips.rotation.y * 1.6 + (inp.dig >= 0 ? toolYaw * 0.4 : 0);
    const breathe = Math.sin(this.t * 2) * 0.012;
    this.torso.scale.set(1 + breathe, 1 + breathe, 1 + breathe);
    this.head.rotation.x = -lean * 0.6 + (inp.dig >= 0 ? 0.25 : 0);
    this.head.rotation.y = Math.sin(this.t * 0.7) * 0.05 * (moving ? 0 : 1);

    // tool placement
    const tool = this.tool;
    if (tool) {
      const th = this.toolHolder;
      th.position.set(toolX, toolY, toolZ);
      if (inp.tool === "shovel") {
        _e.set(-toolA, toolYaw, toolRoll, "YXZ");
        th.position.set(toolX + Math.sin(toolYaw) * 0.12, toolY, toolZ);
      } else {
        _e.set(-toolA, toolYaw, 0, "YXZ");
        th.position.set(toolX + Math.sin(toolYaw) * 0.25, toolY, toolZ + (Math.cos(toolYaw) - 1) * 0.1);
      }
      th.quaternion.setFromEuler(_e);
      // hold bump (held tool settles after equip)
      th.scale.setScalar(hold);
    }

    // arm IK in torso space
    this.hips.updateMatrix();
    this.torso.updateMatrix();
    this.toolHolder.updateMatrix();
    _m.copy(this.hips.matrix).multiply(this.torso.matrix).invert();
    const gripR = new THREE.Vector3(0, 0, 0);
    const gripL = new THREE.Vector3(0, LEFT_GRIP_Y, 0);
    gripR.applyMatrix4(this.toolHolder.matrix).applyMatrix4(_m);
    if (inp.tool === "shovel") gripL.applyMatrix4(this.toolHolder.matrix).applyMatrix4(_m);
    else {
      gripL.set(0.3, 0.1, 0.0);
      // free left arm: relaxed swing in root space
      gripL.set(0.33, 0.9 + bob * 0.5, 0.1 - Math.sin(this.phase) * 0.18 * walkAmt + (inp.scanning ? 0.05 : 0));
      gripL.applyMatrix4(_m);
    }
    const pole = new THREE.Vector3();
    solveArm(this.arms[0].up, this.arms[0].fore, new THREE.Vector3(-0.255, 0.6, 0), gripR, this.A, this.B, pole.set(-0.5, -0.6, -0.7));
    solveArm(this.arms[1].up, this.arms[1].fore, new THREE.Vector3(0.255, 0.6, 0), gripL, this.A, this.B, pole.set(0.5, -0.6, -0.7));
  }
}
