import * as THREE from 'three';
import { CollisionSystem } from '../physics/CollisionSystem';
import { sound } from '../../audio/SoundEngine';

export interface Barricade {
  id: string;
  position: THREE.Vector3;
  rotationY: number;
  width: number;
  height: number;
  planks: number; // 0 to 5
  maxPlanks: number;
  plankMeshes: THREE.Mesh[];
  group: THREE.Group;
  colliderId: string;
}

export interface InteractiveDoor {
  id: string;
  position: THREE.Vector3;
  rotationY: number;
  width: number;
  height: number;
  isOpen: boolean;
  isAnimating: boolean;
  animProgress: number;
  doorMesh: THREE.Mesh;
  group: THREE.Group;
  colliderId: string;
}

export class BarricadeAndDoorSystem {
  private scene: THREE.Scene;
  private collision: CollisionSystem;

  public barricades: Barricade[] = [];
  public doors: InteractiveDoor[] = [];
  public doorMode: 'button' | 'automatic' = 'button';

  private woodMat = new THREE.MeshStandardMaterial({ color: 0x854d0e, roughness: 0.85 });
  private doorMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6, metalness: 0.3 });

  constructor(scene: THREE.Scene, collision: CollisionSystem) {
    this.scene = scene;
    this.collision = collision;
  }

  clear() {
    for (const b of this.barricades) {
      this.scene.remove(b.group);
    }
    this.barricades = [];

    for (const d of this.doors) {
      this.scene.remove(d.group);
    }
    this.doors = [];
  }

  // Create barricadable window or doorway entry point
  addBarricade(id: string, pos: THREE.Vector3, rotY: number, width: number = 2.4, height: number = 2.4) {
    const group = new THREE.Group();
    group.position.copy(pos);
    group.rotation.y = rotY;

    // Frame posts
    const postMat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.9 });
    const postL = new THREE.Mesh(new THREE.BoxGeometry(0.15, height, 0.15), postMat);
    postL.position.set(-width / 2, height / 2, 0);
    group.add(postL);

    const postR = new THREE.Mesh(new THREE.BoxGeometry(0.15, height, 0.15), postMat);
    postR.position.set(width / 2, height / 2, 0);
    group.add(postR);

    // 5 Wooden Planks
    const plankMeshes: THREE.Mesh[] = [];
    const plankHeight = height / 6;

    for (let i = 0; i < 5; i++) {
      const plank = new THREE.Mesh(new THREE.BoxGeometry(width + 0.1, plankHeight * 0.85, 0.08), this.woodMat);
      plank.position.set(0, (i + 1) * plankHeight, (i % 2 === 0 ? 0.04 : -0.04));
      plank.rotation.z = (Math.random() - 0.5) * 0.08;
      plank.castShadow = true;
      group.add(plank);
      plankMeshes.push(plank);
    }

    this.scene.add(group);

    const colliderId = `barricade_col_${id}`;
    this.collision.addBox(colliderId, pos.clone().add({ x: 0, y: height / 2, z: 0 }), new THREE.Vector3(width, height, 0.35), 'barrier');

    this.barricades.push({
      id,
      position: pos.clone(),
      rotationY: rotY,
      width,
      height,
      planks: 5,
      maxPlanks: 5,
      plankMeshes,
      group,
      colliderId,
    });
  }

  // Create an interactive working door with hinges
  addDoor(id: string, pos: THREE.Vector3, rotY: number, width: number = 2.2, height: number = 3.2) {
    const group = new THREE.Group();
    group.position.copy(pos);
    group.rotation.y = rotY;

    // Door leaf pivoted at left hinge
    const doorLeaf = new THREE.Mesh(new THREE.BoxGeometry(width, height, 0.12), this.doorMat);
    doorLeaf.position.set(width / 2, height / 2, 0);
    doorLeaf.castShadow = true;
    group.add(doorLeaf);

    // Door handle
    const handleMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, metalness: 0.9, roughness: 0.2 });
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.18, 8), handleMat);
    handle.position.set(width * 0.88, height / 2, 0.08);
    doorLeaf.add(handle);

    this.scene.add(group);

    const colliderId = `door_col_${id}`;
    this.collision.addBox(colliderId, pos.clone().add({ x: (Math.cos(rotY) * width) / 2, y: height / 2, z: (Math.sin(rotY) * width) / 2 }), new THREE.Vector3(width, height, 0.25), 'wall');

    this.doors.push({
      id,
      position: pos.clone(),
      rotationY: rotY,
      width,
      height,
      isOpen: false,
      isAnimating: false,
      animProgress: 0,
      doorMesh: doorLeaf,
      group,
      colliderId,
    });
  }

  // Repair one plank on the nearest barricade
  repairNearestBarricade(playerPos: THREE.Vector3): { success: boolean; points: number; xp: number } {
    let nearest: Barricade | null = null;
    let minDist = 3.2;

    for (const b of this.barricades) {
      const d = playerPos.distanceTo(b.position);
      if (d < minDist && b.planks < b.maxPlanks) {
        minDist = d;
        nearest = b;
      }
    }

    if (nearest) {
      nearest.planks++;
      nearest.plankMeshes[nearest.planks - 1].visible = true;
      sound.playBarricadeRepair();

      // Re-enable collision if restored from 0
      if (nearest.planks === 1 && !this.collision.hasBox(nearest.colliderId)) {
        this.collision.addBox(nearest.colliderId, nearest.position.clone().add({ x: 0, y: nearest.height / 2, z: 0 }), new THREE.Vector3(nearest.width, nearest.height, 0.35), 'barrier');
      }

      return { success: true, points: 50, xp: 25 };
    }

    return { success: false, points: 0, xp: 0 };
  }

  // Zombie attacks a barricade
  damageNearestBarricade(zombiePos: THREE.Vector3): boolean {
    for (const b of this.barricades) {
      if (b.planks > 0 && zombiePos.distanceTo(b.position) <= 2.4) {
        b.planks--;
        b.plankMeshes[b.planks].visible = false;
        sound.playBarricadeBreak();

        // If all planks destroyed, remove collision so zombies can climb through
        if (b.planks === 0) {
          this.collision.removeBox(b.colliderId);
        }

        return true;
      }
    }
    return false;
  }

  // Toggle a door with real dynamic collision update (Requirements 5, 6, 7)
  toggleNearestDoor(playerPos: THREE.Vector3): boolean {
    for (const d of this.doors) {
      if (playerPos.distanceTo(d.position) <= 3.4) {
        d.isOpen = !d.isOpen;
        d.isAnimating = true;

        if (d.isOpen) {
          sound.playDoorOpen();
          // Open door allows passage (remove barrier collider)
          this.collision.removeBox(d.colliderId);
        } else {
          sound.playDoorClose();
          // Closed door blocks player and zombies
          if (!this.collision.hasBox(d.colliderId)) {
            const rotY = d.rotationY;
            const width = d.width;
            const height = d.height;
            this.collision.addBox(d.colliderId, d.position.clone().add({ x: (Math.cos(rotY) * width) / 2, y: height / 2, z: (Math.sin(rotY) * width) / 2 }), new THREE.Vector3(width, height, 0.25), 'wall');
          }
        }
        return true;
      }
    }
    return false;
  }

  // Get prompt if player is near a door or damaged barricade
  getInteractionPrompt(playerPos: THREE.Vector3): string | null {
    // Check barricade
    for (const b of this.barricades) {
      if (playerPos.distanceTo(b.position) <= 3.0 && b.planks < b.maxPlanks) {
        return `HOLD [F] / TAP TO REPAIR BARRICADE (+50 PTS)`;
      }
    }
    // Check door
    for (const d of this.doors) {
      if (playerPos.distanceTo(d.position) <= 3.2) {
        return d.isOpen ? `TAP TO CLOSE DOOR` : `TAP TO OPEN DOOR`;
      }
    }
    return null;
  }

  update(delta: number, playerPos: THREE.Vector3) {
    // Automatic door mode check
    if (this.doorMode === 'automatic') {
      for (const d of this.doors) {
        const dist = playerPos.distanceTo(d.position);
        if (dist <= 3.2 && !d.isOpen && !d.isAnimating) {
          d.isOpen = true;
          d.isAnimating = true;
          sound.playDoorOpen();
        } else if (dist > 4.5 && d.isOpen && !d.isAnimating) {
          d.isOpen = false;
          d.isAnimating = true;
          sound.playDoorClose();
        }
      }
    }

    // Animate doors
    for (const d of this.doors) {
      if (d.isAnimating) {
        const targetRot = d.isOpen ? Math.PI / 2 : 0;
        d.animProgress = THREE.MathUtils.lerp(d.animProgress, targetRot, delta * 8);
        d.group.rotation.y = d.rotationY + d.animProgress;

        if (Math.abs(d.animProgress - targetRot) < 0.02) {
          d.animProgress = targetRot;
          d.group.rotation.y = d.rotationY + targetRot;
          d.isAnimating = false;
        }
      }
    }
  }
}
