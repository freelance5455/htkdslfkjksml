import * as THREE from 'three';
import { CollisionSystem } from '../physics/CollisionSystem';
import { TextureGenerator } from '../textures/TextureGenerator';
import { WeaponModels } from '../models/WeaponModels';

export interface InteractiveEntity {
  id: string;
  type: 'wallbuy' | 'mysterybox' | 'ammocrate' | 'perk';
  name: string;
  cost: number;
  position: THREE.Vector3;
  radius: number;
  action: () => void;
}

export interface StreetLampData {
  light: THREE.PointLight;
  bulbMesh: THREE.Mesh;
}

export class MapBuilder {
  private scene: THREE.Scene;
  private collision: CollisionSystem;
  private mapMeshes: THREE.Object3D[] = [];

  public currentMapId = 'suburban';
  public interactiveEntities: InteractiveEntity[] = [];
  public streetLamps: StreetLampData[] = [];
  public zombieSpawnPoints: THREE.Vector3[] = [];
  public playerSpawn = new THREE.Vector3(0, 0, 8);

  get mapMeshesCount(): number {
    return this.mapMeshes.length;
  }

  constructor(scene: THREE.Scene, collision: CollisionSystem) {
    this.scene = scene;
    this.collision = collision;
  }

  clearMap() {
    for (let i = 0; i < this.mapMeshes.length; i++) {
      this.scene.remove(this.mapMeshes[i]);
    }
    this.mapMeshes = [];
    this.collision.clear();
    this.interactiveEntities = [];
    this.streetLamps = [];
    this.zombieSpawnPoints = [];
  }

  private addMesh(mesh: THREE.Object3D) {
    this.scene.add(mesh);
    this.mapMeshes.push(mesh);
  }

  // Build specific map by ID
  buildMap(mapId: string = 'suburban') {
    this.clearMap();
    this.currentMapId = mapId;

    switch (mapId) {
      case 'military':
        this.buildMilitaryBase();
        break;
      case 'forest':
        this.buildForestResearchSite();
        break;
      case 'industrial':
        this.buildIndustrialDistrict();
        break;
      case 'night_city':
        this.buildNightCityOutskirts();
        break;
      case 'hospital':
        this.buildAbandonedHospital();
        break;
      case 'desert_outpost':
        this.buildDesertMilitaryOutpost();
        break;
      case 'flooded_suburb':
        this.buildFloodedSuburbanDistrict();
        break;
      case 'factory':
        this.buildAbandonedFactory();
        break;
      case 'research_facility':
        this.buildForestResearchFacility();
        break;
      case 'suburban':
      default:
        this.buildSuburbanMap();
        break;
    }
  }

  // ==========================================
  // MAP 1: SUBURBAN OUTBREAK
  // ==========================================
  private buildSuburbanMap() {
    this.collision.addBounds(-55, 55, -55, 55);
    this.playerSpawn.set(0, 0, 8);

    const grassTex = TextureGenerator.createGrassTexture();
    grassTex.repeat.set(24, 24);
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(120, 120),
      new THREE.MeshStandardMaterial({ map: grassTex, roughness: 0.85 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.addMesh(ground);

    const roadTex = TextureGenerator.createRoadTexture();
    roadTex.repeat.set(1, 10);
    const mainRoad = new THREE.Mesh(
      new THREE.PlaneGeometry(12, 110),
      new THREE.MeshStandardMaterial({ map: roadTex, roughness: 0.7 })
    );
    mainRoad.rotation.x = -Math.PI / 2;
    mainRoad.position.set(0, 0.02, 0);
    this.addMesh(mainRoad);

    const crossRoad = new THREE.Mesh(
      new THREE.PlaneGeometry(110, 12),
      new THREE.MeshStandardMaterial({ map: roadTex, roughness: 0.7 })
    );
    crossRoad.rotation.x = -Math.PI / 2;
    crossRoad.position.set(0, 0.025, 0);
    this.addMesh(crossRoad);

    this.createSidewalk(-25, -25, 36, 36);
    this.createSidewalk(25, -25, 36, 36);
    this.createSidewalk(-25, 25, 36, 36);
    this.createSidewalk(25, 25, 36, 36);

    this.buildHouseA(-28, -25);
    this.buildTwoStoryCommandBuilding(25, -22);
    this.buildDepot(-26, 22);
    this.buildHouseB(26, 25);
    this.buildSuburbanCentralPlaza(0, 0);

    this.buildMilitaryHumvee(-4, 0, 8, Math.PI * 0.15);
    this.buildPickupTruck(14, 0, 1.5, -Math.PI * 0.08);
    this.buildSedanWreck(-15, 0, -8, Math.PI * 0.6);

    this.buildWoodenFence(-37, -25, 0.2, 1.8, 16);
    this.buildWoodenFence(-28, -34, 18, 1.8, 0.2);
    this.buildPerimeterFence();

    this.buildStreetLamps([
      { x: -8, z: -10 },
      { x: 8, z: -10 },
      { x: -8, z: 10 },
      { x: 8, z: 10 },
      { x: -18, z: -2 },
      { x: 18, z: -2 },
    ]);

    this.buildTrees([
      { x: -38, z: -38 },
      { x: -14, z: -38 },
      { x: 38, z: -38 },
      { x: 42, z: -16 },
      { x: -38, z: 38 },
      { x: 38, z: 38 },
    ]);

    this.zombieSpawnPoints = [
      new THREE.Vector3(-45, 0, 0),
      new THREE.Vector3(45, 0, 0),
      new THREE.Vector3(0, 0, -45),
      new THREE.Vector3(0, 0, 45),
      new THREE.Vector3(-38, 0, -35),
      new THREE.Vector3(38, 0, 35),
      new THREE.Vector3(-35, 0, 32),
      new THREE.Vector3(35, 0, -32),
    ];

    this.createWallBuy('wallbuy_shotgun', 'Striker-12 Shotgun', 1200, new THREE.Vector3(-28, 1.8, -17.8), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_sniper', 'Recon-50 Sniper', 2000, new THREE.Vector3(25, 5.0, -13.8), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_smg', 'Spectre-X SMG', 1000, new THREE.Vector3(-16.2, 1.8, 22), new THREE.Euler(0, -Math.PI / 2, 0));
    this.createAmmoCrate(new THREE.Vector3(-1.8, 0, 3.2));
    this.createMysteryBox(new THREE.Vector3(26, 0, 34));

    // Backyard Swimming Pool (Requirement 30: Water on every map)
    this.buildWaterArea(-28, 20, 10, 6);
  }

  // ==========================================
  // MAP 2: ABANDONED MILITARY BASE
  // ==========================================
  private buildMilitaryBase() {
    this.collision.addBounds(-55, 55, -55, 55);
    this.playerSpawn.set(0, 0, 10);

    const tarmacTex = TextureGenerator.createConcreteTexture();
    tarmacTex.repeat.set(20, 20);
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(120, 120),
      new THREE.MeshStandardMaterial({ map: tarmacTex, roughness: 0.75, color: 0x475569 })
    );
    ground.rotation.x = -Math.PI / 2;
    this.addMesh(ground);

    this.buildBlastBunker(-22, -18, 16, 4.5, 12);
    this.buildBlastBunker(22, -18, 16, 4.5, 12);
    this.buildWatchtower(0, -15);
    this.buildAircraftHangar(0, 30);

    for (let x = -20; x <= 20; x += 10) {
      if (x === 0) continue;
      this.buildSandbagWall(x, 2, 6, 0);
      this.buildSandbagWall(x, 14, 6, 0);
    }

    this.buildMilitaryHumvee(-12, 0, 4, 0.4);
    this.buildMilitaryHumvee(12, 0, 4, -0.4);
    this.buildMilitaryHumvee(-16, 0, -6, 1.2);

    this.buildStreetLamps([
      { x: -15, z: -25 },
      { x: 15, z: -25 },
      { x: -15, z: 20 },
      { x: 15, z: 20 },
      { x: 0, z: -5 },
    ]);

    this.buildPerimeterFence();

    this.zombieSpawnPoints = [
      new THREE.Vector3(-22, 0, -26),
      new THREE.Vector3(22, 0, -26),
      new THREE.Vector3(0, 0, 45),
      new THREE.Vector3(-45, 0, 0),
      new THREE.Vector3(45, 0, 0),
      new THREE.Vector3(-25, 0, 25),
      new THREE.Vector3(25, 0, 25),
    ];

    this.createWallBuy('wallbuy_sniper', 'Recon-50 Sniper', 2000, new THREE.Vector3(0, 7.5, -14.5), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_shotgun', 'Striker-12 Shotgun', 1200, new THREE.Vector3(-14, 1.8, -18), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_smg', 'Spectre-X SMG', 1000, new THREE.Vector3(14, 1.8, -18), new THREE.Euler(0, 0, 0));
    this.createAmmoCrate(new THREE.Vector3(0, 0, 0));
    this.createMysteryBox(new THREE.Vector3(0, 0, 28));

    // Emergency Fire Water Reservoir (Requirement 30: Water on every map)
    this.buildWaterArea(-15, 20, 14, 8);
  }

  // ==========================================
  // MAP 3: FOREST RESEARCH SITE
  // ==========================================
  private buildForestResearchSite() {
    this.collision.addBounds(-55, 55, -55, 55);
    this.playerSpawn.set(0, 0, 5);

    const groundTex = TextureGenerator.createGrassTexture();
    groundTex.repeat.set(20, 20);
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(120, 120),
      new THREE.MeshStandardMaterial({ map: groundTex, roughness: 0.9, color: 0x1e291e })
    );
    ground.rotation.x = -Math.PI / 2;
    this.addMesh(ground);

    this.buildBioLabBuilding(0, -12);
    this.buildResearchTent(-20, 15);
    this.buildResearchTent(20, 15);

    const forestTrees = [];
    for (let i = 0; i < 28; i++) {
      const angle = (i / 28) * Math.PI * 2;
      const r = 25 + (i % 5) * 4;
      forestTrees.push({ x: Math.cos(angle) * r, z: Math.sin(angle) * r });
    }
    this.buildTrees(forestTrees);

    this.buildStreetLamps([
      { x: -10, z: -5 },
      { x: 10, z: -5 },
      { x: -12, z: 12 },
      { x: 12, z: 12 },
    ]);

    this.buildPerimeterFence();

    this.zombieSpawnPoints = [
      new THREE.Vector3(-42, 0, -35),
      new THREE.Vector3(42, 0, -35),
      new THREE.Vector3(-42, 0, 35),
      new THREE.Vector3(42, 0, 35),
      new THREE.Vector3(0, 0, -45),
      new THREE.Vector3(0, 0, 45),
      new THREE.Vector3(-25, 0, 0),
      new THREE.Vector3(25, 0, 0),
    ];

    this.createWallBuy('wallbuy_shotgun', 'Striker-12 Shotgun', 1200, new THREE.Vector3(-6, 1.8, -4), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_smg', 'Spectre-X SMG', 1000, new THREE.Vector3(6, 1.8, -4), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_sniper', 'Recon-50 Sniper', 2000, new THREE.Vector3(0, 1.8, -22), new THREE.Euler(0, 0, 0));
    this.createAmmoCrate(new THREE.Vector3(-3, 0, 6));
    this.createMysteryBox(new THREE.Vector3(0, 0, 22));

    // Forest Pond & Spring (Requirement 30)
    this.buildWaterArea(18, 12, 14, 10);
  }

  // ==========================================
  // MAP 4: INDUSTRIAL DISTRICT
  // ==========================================
  private buildIndustrialDistrict() {
    this.collision.addBounds(-55, 55, -55, 55);
    this.playerSpawn.set(0, 0, 5);

    const floorTex = TextureGenerator.createConcreteTexture();
    floorTex.repeat.set(16, 16);
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(120, 120),
      new THREE.MeshStandardMaterial({ map: floorTex, roughness: 0.7, color: 0x374151 })
    );
    ground.rotation.x = -Math.PI / 2;
    this.addMesh(ground);

    this.buildBrickFactory(0, -22);

    const colors = ['#b91c1c', '#1d4ed8', '#047857', '#d97706'];
    for (let row = 0; row < 3; row++) {
      for (let col = -2; col <= 2; col++) {
        if (col === 0 && row === 0) continue;
        const cx = col * 8;
        const cz = 12 + row * 9;
        this.buildShippingContainer(cx, cz, colors[(row + col + 4) % colors.length], (col % 2) * (Math.PI / 2));
      }
    }

    this.buildCrateStack(-8, -4);
    this.buildCrateStack(8, -4);
    this.buildExplosiveBarrel(-12, 4);
    this.buildExplosiveBarrel(12, 4);

    this.buildStreetLamps([
      { x: -14, z: -10 },
      { x: 14, z: -10 },
      { x: -14, z: 15 },
      { x: 14, z: 15 },
    ]);

    this.buildPerimeterFence();

    this.zombieSpawnPoints = [
      new THREE.Vector3(-45, 0, -25),
      new THREE.Vector3(45, 0, -25),
      new THREE.Vector3(-45, 0, 30),
      new THREE.Vector3(45, 0, 30),
      new THREE.Vector3(0, 0, -45),
      new THREE.Vector3(0, 0, 45),
    ];

    this.createWallBuy('wallbuy_shotgun', 'Striker-12 Shotgun', 1200, new THREE.Vector3(-8, 1.8, -12), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_smg', 'Spectre-X SMG', 1000, new THREE.Vector3(8, 1.8, -12), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_sniper', 'Recon-50 Sniper', 2000, new THREE.Vector3(0, 1.8, -32), new THREE.Euler(0, 0, 0));
    this.createAmmoCrate(new THREE.Vector3(0, 0, 2));
    this.createMysteryBox(new THREE.Vector3(0, 0, 35));

    // Industrial Runoff Canal (Requirement 30)
    this.buildWaterArea(0, 32, 28, 6);
  }

  // ==========================================
  // MAP 5: NIGHT CITY OUTSKIRTS
  // ==========================================
  private buildNightCityOutskirts() {
    this.collision.addBounds(-55, 55, -55, 55);
    this.playerSpawn.set(0, 0, 6);

    const asphaltTex = TextureGenerator.createRoadTexture();
    asphaltTex.repeat.set(4, 16);
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(120, 120),
      new THREE.MeshStandardMaterial({ map: asphaltTex, roughness: 0.35, metalness: 0.3 })
    );
    ground.rotation.x = -Math.PI / 2;
    this.addMesh(ground);

    this.buildCityStorefront(-20, -18, 18, 5, 14);
    this.buildCityStorefront(20, -18, 18, 5, 14);
    this.buildMetroEntrance(0, 20);

    this.buildCityBus(-3, 0, -4, 0.2);
    this.buildPickupTruck(10, 0, 8, -0.3);
    this.buildSedanWreck(-12, 0, 10, 0.8);

    this.buildStreetLamps([
      { x: -8, z: -15 },
      { x: 8, z: -15 },
      { x: -8, z: 12 },
      { x: 8, z: 12 },
      { x: 0, z: -25 },
    ]);

    this.buildPerimeterFence();

    this.zombieSpawnPoints = [
      new THREE.Vector3(-45, 0, 0),
      new THREE.Vector3(45, 0, 0),
      new THREE.Vector3(0, 0, -45),
      new THREE.Vector3(0, 0, 42),
      new THREE.Vector3(-20, 0, -28),
      new THREE.Vector3(20, 0, -28),
    ];

    this.createWallBuy('wallbuy_smg', 'Spectre-X SMG', 1000, new THREE.Vector3(-10, 1.8, -10), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_shotgun', 'Striker-12 Shotgun', 1200, new THREE.Vector3(10, 1.8, -10), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_sniper', 'Recon-50 Sniper', 2000, new THREE.Vector3(0, 1.8, -32), new THREE.Euler(0, 0, 0));
    this.createAmmoCrate(new THREE.Vector3(-2, 0, 2));
    this.createMysteryBox(new THREE.Vector3(0, 0, 28));

    // Storm Drainage Canal (Requirement 30)
    this.buildWaterArea(-16, 26, 18, 8);
  }

  // ==========================================
  // MAP 6: ABANDONED HOSPITAL (ST. JUDE)
  // ==========================================
  private buildAbandonedHospital() {
    this.collision.addBounds(-55, 55, -55, 55);
    this.playerSpawn.set(0, 0, 12);

    // Hospital Tile & Parking Grounds
    const tileMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.5 });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), tileMat);
    ground.rotation.x = -Math.PI / 2;
    this.addMesh(ground);

    // Main Hospital Medical Complex (Multi-room triage, corridors, rooftop)
    const hospMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.6 });
    const wallThick = 0.45;
    const hH = 6.0;

    // West Wing - Triage Ward
    this.createWall(-18, -10, 16, hH, wallThick, hospMat);
    this.createWall(-26, 0, wallThick, hH, 20, hospMat);
    this.createWall(-18, 10, 16, hH, wallThick, hospMat);

    // East Wing - Emergency ICU
    this.createWall(18, -10, 16, hH, wallThick, hospMat);
    this.createWall(26, 0, wallThick, hH, 20, hospMat);
    this.createWall(18, 10, 16, hH, wallThick, hospMat);

    // Central Reception & Corridors
    this.createWall(0, -22, 28, hH, wallThick, hospMat);
    this.createWall(0, -10, 10, hH, wallThick, hospMat);

    // Hospital Rooftop Helipad (Walkable 2nd level)
    const helipadMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
    const helipad = new THREE.Mesh(new THREE.BoxGeometry(18, 0.4, 18), helipadMat);
    helipad.position.set(0, hH, -10);
    this.addMesh(helipad);
    this.collision.addBox('hosp_helipad', helipad.position, new THREE.Vector3(18, 0.4, 18), 'floor', true);

    // Helipad H Letter Markings
    const hMark = new THREE.Mesh(new THREE.BoxGeometry(4, 0.05, 4), new THREE.MeshBasicMaterial({ color: 0xfacc15 }));
    hMark.position.set(0, hH + 0.22, -10);
    this.addMesh(hMark);

    // Helipad Stairway
    const stairSteps = 14;
    const stepH = hH / stairSteps;
    for (let i = 0; i < stairSteps; i++) {
      const step = new THREE.Mesh(new THREE.BoxGeometry(2.4, stepH, 0.8), new THREE.MeshStandardMaterial({ color: 0x475569 }));
      step.position.set(10.5, (i + 0.5) * stepH, -15 + i * 0.8);
      this.addMesh(step);
      this.collision.addBox(`hosp_stair_${i}`, step.position, new THREE.Vector3(2.4, stepH, 0.8), 'stair', true, true);
    }

    // Ambulances in emergency parking lot
    this.buildAmbulance(-12, 0, 18, 0.15);
    this.buildAmbulance(12, 0, 18, -0.2);

    // Hospital Stretchers & Medical Furniture inside
    this.buildHospitalStretcher(-18, 0, -4);
    this.buildHospitalStretcher(-18, 0, 4);
    this.buildHospitalStretcher(18, 0, -4);
    this.buildHospitalStretcher(18, 0, 4);
    this.buildMedicalCart(-14, 0, -2);
    this.buildMedicalCart(14, 0, -2);
    this.buildFilingCabinet(-22, 0, -8, 0);
    this.buildFilingCabinet(22, 0, -8, 0);

    this.buildStreetLamps([
      { x: -10, z: 12 },
      { x: 10, z: 12 },
      { x: 0, z: -10 },
      { x: -20, z: -2 },
      { x: 20, z: -2 },
    ]);

    this.buildPerimeterFence();

    // Spawns: Emergency bay doors, broken ward windows, underground service tunnels
    this.zombieSpawnPoints = [
      new THREE.Vector3(-24, 0, -18),
      new THREE.Vector3(24, 0, -18),
      new THREE.Vector3(0, 0, -35),
      new THREE.Vector3(-45, 0, 15),
      new THREE.Vector3(45, 0, 15),
      new THREE.Vector3(0, 0, 42),
    ];

    this.createWallBuy('wallbuy_shotgun', 'Striker-12 Shotgun', 1200, new THREE.Vector3(-10, 1.8, -10), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_smg', 'Spectre-X SMG', 1000, new THREE.Vector3(10, 1.8, -10), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_sniper', 'Recon-50 Sniper', 2000, new THREE.Vector3(0, hH + 1.8, -18), new THREE.Euler(0, 0, 0));
    this.createAmmoCrate(new THREE.Vector3(0, 0, 2));
    this.createMysteryBox(new THREE.Vector3(0, 0, -18));

    // Hydrotherapy Pool (Requirement 30)
    this.buildWaterArea(-18, -25, 12, 7);
  }

  // ==========================================
  // MAP 7: DESERT MILITARY OUTPOST (CAMP DUSTDEVIL)
  // ==========================================
  private buildDesertMilitaryOutpost() {
    this.collision.addBounds(-55, 55, -55, 55);
    this.playerSpawn.set(0, 0, 8);

    // Arid Desert Sand
    const sandMat = new THREE.MeshStandardMaterial({ color: 0xd4a373, roughness: 0.95 });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), sandMat);
    ground.rotation.x = -Math.PI / 2;
    this.addMesh(ground);

    // Fortified Military Barracks (North-West)
    this.buildBlastBunker(-20, -16, 18, 4.2, 14);

    // Vehicle Depot & Ammo Supply (North-East)
    this.buildBlastBunker(20, -16, 18, 4.2, 14);

    // Central Radar Observation Tower
    this.buildWatchtower(0, -6);

    // Underground Bunker Entrance Ramp (South)
    const bunkerRampMat = new THREE.MeshStandardMaterial({ color: 0x57534e });
    const bWall1 = this.createWall(-6, 24, 0.4, 3.5, 16, bunkerRampMat);
    const bWall2 = this.createWall(6, 24, 0.4, 3.5, 16, bunkerRampMat);
    const bBack = this.createWall(0, 32, 12.4, 3.5, 0.4, bunkerRampMat);
    this.collision.addBox('bunker_w1', bWall1.position, new THREE.Vector3(0.4, 3.5, 16), 'building');
    this.collision.addBox('bunker_w2', bWall2.position, new THREE.Vector3(0.4, 3.5, 16), 'building');
    this.collision.addBox('bunker_back', bBack.position, new THREE.Vector3(12.4, 3.5, 0.4), 'building');

    // Sandbag trenches surrounding base perimeter
    for (let x = -25; x <= 25; x += 12.5) {
      if (x === 0) continue;
      this.buildSandbagWall(x, 4, 8, 0);
      this.buildSandbagWall(x, -28, 8, 0);
    }

    // Desert Camo Humvees
    this.buildMilitaryHumvee(-10, 0, 12, 0.35);
    this.buildMilitaryHumvee(10, 0, 12, -0.35);

    // Barrels & Supply Crates
    this.buildExplosiveBarrel(-14, -4);
    this.buildExplosiveBarrel(14, -4);
    this.buildCrateStack(-22, 4);
    this.buildCrateStack(22, 4);

    this.buildStreetLamps([
      { x: -12, z: -10 },
      { x: 12, z: -10 },
      { x: -12, z: 16 },
      { x: 12, z: 16 },
    ]);

    this.buildPerimeterFence();

    // Desert breaches & bunker ramp spawns
    this.zombieSpawnPoints = [
      new THREE.Vector3(-45, 0, -25),
      new THREE.Vector3(45, 0, -25),
      new THREE.Vector3(0, 0, 42),
      new THREE.Vector3(-45, 0, 20),
      new THREE.Vector3(45, 0, 20),
      new THREE.Vector3(0, 0, -45),
    ];

    this.createWallBuy('wallbuy_sniper', 'Recon-50 Sniper', 2000, new THREE.Vector3(0, 7.5, -5.5), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_shotgun', 'Striker-12 Shotgun', 1200, new THREE.Vector3(-11, 1.8, -16), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_smg', 'Spectre-X SMG', 1000, new THREE.Vector3(11, 1.8, -16), new THREE.Euler(0, 0, 0));
    this.createAmmoCrate(new THREE.Vector3(0, 0, 2));
    this.createMysteryBox(new THREE.Vector3(0, 0, 24));

    // Desert Oasis Reservoir Basin (Requirement 30)
    this.buildWaterArea(18, -4, 14, 8);
  }

  // ==========================================
  // MAP 8: FLOODED SUBURBAN DISTRICT
  // ==========================================
  private buildFloodedSuburbanDistrict() {
    this.collision.addBounds(-55, 55, -55, 55);
    this.playerSpawn.set(0, 0.4, 6);

    // Muddy / Silted Ground
    const mudMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.85 });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), mudMat);
    ground.rotation.x = -Math.PI / 2;
    this.addMesh(ground);

    // Water Surface Plane (Reflective flooded canals with vivid azure water - Requirement 8 & 9)
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      emissive: 0x0369a1,
      emissiveIntensity: 0.35,
      roughness: 0.1,
      metalness: 0.25,
      transparent: true,
      opacity: 0.85,
    });
    const water = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), waterMat);
    water.rotation.x = -Math.PI / 2;
    water.position.y = 0.22;
    this.addMesh(water);

    // Elevated Wooden Boardwalks connecting houses & roads (y = 0.35)
    const woodMat = new THREE.MeshStandardMaterial({ map: TextureGenerator.createWoodTexture(), roughness: 0.7 });
    const createBoardwalk = (x: number, z: number, w: number, d: number) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.25, d), woodMat);
      m.position.set(x, 0.3, z);
      this.addMesh(m);
      this.collision.addBox(`boardwalk_${x}_${z}`, m.position, new THREE.Vector3(w, 0.25, d), 'floor', true);
    };

    // Main crossing elevated boardwalks
    createBoardwalk(0, 0, 6, 80);
    createBoardwalk(0, 0, 80, 6);
    createBoardwalk(-20, -15, 24, 6);
    createBoardwalk(20, -15, 24, 6);

    // Flooded Suburban Homes (elevated slabs)
    this.buildHouseA(-24, -20);
    this.buildHouseB(24, -20);

    // Half-Sunken Abandoned Vehicles (in water)
    this.buildSedanWreck(-8, 0, 12, 0.4);
    this.buildPickupTruck(10, 0, -8, -0.3);

    // Floating Crate Platforms
    this.buildCrateStack(-6, -10);
    this.buildCrateStack(6, 14);

    this.buildStreetLamps([
      { x: -5, z: -15 },
      { x: 5, z: -15 },
      { x: -5, z: 15 },
      { x: 5, z: 15 },
    ]);

    this.buildPerimeterFence();

    // Spawns: Drainage culverts, flooded alleyways, submerged gates
    this.zombieSpawnPoints = [
      new THREE.Vector3(-45, 0, 0),
      new THREE.Vector3(45, 0, 0),
      new THREE.Vector3(0, 0, -45),
      new THREE.Vector3(0, 0, 45),
      new THREE.Vector3(-35, 0, -35),
      new THREE.Vector3(35, 0, 35),
    ];

    this.createWallBuy('wallbuy_shotgun', 'Striker-12 Shotgun', 1200, new THREE.Vector3(-12, 1.8, -15), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_smg', 'Spectre-X SMG', 1000, new THREE.Vector3(12, 1.8, -15), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_sniper', 'Recon-50 Sniper', 2000, new THREE.Vector3(0, 1.8, -35), new THREE.Euler(0, 0, 0));
    this.createAmmoCrate(new THREE.Vector3(0, 0.45, 12));
    this.createMysteryBox(new THREE.Vector3(0, 0.45, -20));
  }

  // ==========================================
  // MAP 9: ABANDONED FACTORY (ASSEMBLY PLANT 9)
  // ==========================================
  private buildAbandonedFactory() {
    this.collision.addBounds(-55, 55, -55, 55);
    this.playerSpawn.set(0, 0, 8);

    const metalFloor = new THREE.MeshStandardMaterial({
      map: TextureGenerator.createConcreteTexture(),
      roughness: 0.65,
      color: 0x334155,
    });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), metalFloor);
    ground.rotation.x = -Math.PI / 2;
    this.addMesh(ground);

    // Massive Assembly Hall (North)
    this.buildBrickFactory(0, -20);

    // Factory Floor Conveyor Machinery lines (length 24m)
    const conveyorMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.3 });
    const conv1 = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.2, 22), conveyorMat);
    conv1.position.set(-10, 0.6, 6);
    this.addMesh(conv1);
    this.collision.addBox('conv_1', conv1.position, new THREE.Vector3(2.2, 1.2, 22), 'prop');

    const conv2 = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.2, 22), conveyorMat);
    conv2.position.set(10, 0.6, 6);
    this.addMesh(conv2);
    this.collision.addBox('conv_2', conv2.position, new THREE.Vector3(2.2, 1.2, 22), 'prop');

    // Overhead Steel Catwalk (Walkable elevated platform at y = 4.5m)
    const catwalkMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.9, roughness: 0.3 });
    const catwalk = new THREE.Mesh(new THREE.BoxGeometry(32, 0.3, 3.5), catwalkMat);
    catwalk.position.set(0, 4.5, 6);
    this.addMesh(catwalk);
    this.collision.addBox('factory_catwalk', catwalk.position, new THREE.Vector3(32, 0.3, 3.5), 'floor', true);

    // Catwalk Access Stairs
    const steps = 12;
    const sH = 4.5 / steps;
    for (let i = 0; i < steps; i++) {
      const step = new THREE.Mesh(new THREE.BoxGeometry(2.2, sH, 0.75), catwalkMat);
      step.position.set(-17, (i + 0.5) * sH, 2 + i * 0.75);
      this.addMesh(step);
      this.collision.addBox(`fact_stair_${i}`, step.position, new THREE.Vector3(2.2, sH, 0.75), 'stair', true, true);
    }

    // Loading Dock Bays with Freight Containers
    this.buildShippingContainer(-22, 20, '#b91c1c', 0);
    this.buildShippingContainer(22, 20, '#1e3a8a', 0);

    this.buildCrateStack(-14, -4);
    this.buildCrateStack(14, -4);
    this.buildExplosiveBarrel(-6, 18);
    this.buildExplosiveBarrel(6, 18);

    this.buildStreetLamps([
      { x: -12, z: -8 },
      { x: 12, z: -8 },
      { x: -12, z: 18 },
      { x: 12, z: 18 },
    ]);

    this.buildPerimeterFence();

    // Spawns: Loading bays, conveyor chutes, ventilation ducts
    this.zombieSpawnPoints = [
      new THREE.Vector3(-42, 0, 20),
      new THREE.Vector3(42, 0, 20),
      new THREE.Vector3(0, 0, -38),
      new THREE.Vector3(-35, 0, -25),
      new THREE.Vector3(35, 0, -25),
      new THREE.Vector3(0, 0, 42),
    ];

    this.createWallBuy('wallbuy_sniper', 'Recon-50 Sniper', 2000, new THREE.Vector3(0, 6.3, 7.5), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_shotgun', 'Striker-12 Shotgun', 1200, new THREE.Vector3(-8, 1.8, -8), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_smg', 'Spectre-X SMG', 1000, new THREE.Vector3(8, 1.8, -8), new THREE.Euler(0, 0, 0));
    this.createAmmoCrate(new THREE.Vector3(0, 0, 2));
    this.createMysteryBox(new THREE.Vector3(0, 0, 22));

    // Industrial Cooling Basin (Requirement 30)
    this.buildWaterArea(14, -22, 12, 6);
  }

  // ==========================================
  // MAP 10: FOREST RESEARCH FACILITY (APEX GENOMICS)
  // ==========================================
  private buildForestResearchFacility() {
    this.collision.addBounds(-55, 55, -55, 55);
    this.playerSpawn.set(0, 0, 10);

    const darkForestMat = new THREE.MeshStandardMaterial({
      map: TextureGenerator.createGrassTexture(),
      roughness: 0.9,
      color: 0x142014,
    });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), darkForestMat);
    ground.rotation.x = -Math.PI / 2;
    this.addMesh(ground);

    // High-Tech Bioweapons Cryo Lab Complex (Clean White with glass & reinforced doors)
    const labMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.35, metalness: 0.3 });
    const w = 26, h = 5.2, d = 18, thick = 0.5;

    const floor = new THREE.Mesh(new THREE.BoxGeometry(w, 0.2, d), new THREE.MeshStandardMaterial({ color: 0x1e293b }));
    floor.position.set(0, 0.1, -23);
    this.addMesh(floor);
    this.collision.addBox(`apex_fl_0_-23`, floor.position, new THREE.Vector3(w, 0.2, d), 'floor', true);

    this.createWall(-8, -14, 10, h, thick, labMat);
    this.createWall(8, -14, 10, h, thick, labMat);
    this.createWall(-w / 2, -23, thick, h, d, labMat);
    this.createWall(w / 2, -23, thick, h, d, labMat);
    this.createWall(0, -32, w, h, thick, labMat);

    // Roof
    const roof = new THREE.Mesh(new THREE.BoxGeometry(w + 1, 0.4, d + 1), labMat);
    roof.position.set(0, h + 0.2, -23);
    this.addMesh(roof);
    this.collision.addBox('apex_roof', roof.position, new THREE.Vector3(w + 1, 0.4, d + 1), 'building');

    // Cryogenic Lab Terminals & Equipment
    this.buildDeskWithComputer(-7, 0.2, -23, 0);
    this.buildDeskWithComputer(7, 0.2, -23, 0);
    this.buildStorageShelf(-9, 0.2, -28, 0);
    this.buildStorageShelf(9, 0.2, -28, 0);
    this.buildFilingCabinet(-11, 0.2, -20, Math.PI / 2);
    this.buildMedicalCart(0, 0.2, -26);

    // Outdoor Generator Power Node Pods
    const genMat = new THREE.MeshStandardMaterial({ color: 0x0369a1, metalness: 0.8, roughness: 0.3 });
    const gen1 = new THREE.Mesh(new THREE.BoxGeometry(3, 2.6, 2.2), genMat);
    gen1.position.set(-18, 1.3, 0);
    this.addMesh(gen1);
    this.collision.addBox('apex_gen1', gen1.position, new THREE.Vector3(3, 2.6, 2.2), 'prop');

    const gen2 = new THREE.Mesh(new THREE.BoxGeometry(3, 2.6, 2.2), genMat);
    gen2.position.set(18, 1.3, 0);
    this.addMesh(gen2);
    this.collision.addBox('apex_gen2', gen2.position, new THREE.Vector3(3, 2.6, 2.2), 'prop');

    // Security Checkpoint Kiosk (South)
    this.buildBlastBunker(0, 26, 8, 3.6, 6);

    // Surrounding Heavy Pine Forest Clusters
    const trees = [];
    for (let i = 0; i < 36; i++) {
      const angle = (i / 36) * Math.PI * 2;
      const r = 26 + (i % 6) * 4;
      trees.push({ x: Math.cos(angle) * r, z: Math.sin(angle) * r });
    }
    this.buildTrees(trees);

    this.buildStreetLamps([
      { x: -10, z: -6 },
      { x: 10, z: -6 },
      { x: -14, z: 18 },
      { x: 14, z: 18 },
      { x: 0, z: -20 },
    ]);

    this.buildPerimeterFence();

    // Spawns: Cryo airlock doors, deep dark forest trails, underground containment ducts
    this.zombieSpawnPoints = [
      new THREE.Vector3(-45, 0, -35),
      new THREE.Vector3(45, 0, -35),
      new THREE.Vector3(-45, 0, 30),
      new THREE.Vector3(45, 0, 30),
      new THREE.Vector3(0, 0, -46),
      new THREE.Vector3(0, 0, 45),
    ];

    this.createWallBuy('wallbuy_shotgun', 'Striker-12 Shotgun', 1200, new THREE.Vector3(-8, 1.8, -8), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_smg', 'Spectre-X SMG', 1000, new THREE.Vector3(8, 1.8, -8), new THREE.Euler(0, 0, 0));
    this.createWallBuy('wallbuy_sniper', 'Recon-50 Sniper', 2000, new THREE.Vector3(0, 1.8, -25), new THREE.Euler(0, 0, 0));
    this.createAmmoCrate(new THREE.Vector3(0, 0, 4));
    this.createMysteryBox(new THREE.Vector3(0, 0, 22));

    // Cryogenic Runoff Basin (Requirement 30)
    this.buildWaterArea(-18, -26, 12, 7);
  }

  // --- INTERIOR FURNITURE & STORYTELLING PROPS (Requirement 7 & 15) ---

  private buildBed(x: number, y: number, z: number, rotY: number = 0) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = rotY;

    const frameMat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.8 });
    const mattressMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.7 });

    const frame = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.3, 2.2), frameMat);
    frame.position.y = 0.15;
    group.add(frame);

    const headboard = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.8, 0.15), frameMat);
    headboard.position.set(0, 0.4, -1.05);
    group.add(headboard);

    const mattress = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.25, 2.0), mattressMat);
    mattress.position.set(0, 0.4, 0.05);
    group.add(mattress);

    const pillow = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.1, 0.4), new THREE.MeshStandardMaterial({ color: 0xffffff }));
    pillow.position.set(0, 0.55, -0.7);
    group.add(pillow);

    this.addMesh(group);
    this.collision.addBox(`bed_${x}_${z}`, new THREE.Vector3(x, y + 0.4, z), new THREE.Vector3(1.5, 0.8, 2.3), 'prop');
  }

  private buildDeskWithComputer(x: number, y: number, z: number, rotY: number = 0) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = rotY;

    const deskMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 });
    const pcMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.4, metalness: 0.5 });
    const screenMat = new THREE.MeshBasicMaterial({ color: 0x22c55e });

    const deskTop = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.1, 1.0), deskMat);
    deskTop.position.y = 0.75;
    group.add(deskTop);

    const legL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.75, 0.9), deskMat);
    legL.position.set(-0.9, 0.375, 0);
    group.add(legL);

    const legR = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.75, 0.9), deskMat);
    legR.position.set(0.9, 0.375, 0);
    group.add(legR);

    // Monitor
    const monitor = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.45, 0.08), pcMat);
    monitor.position.set(0, 1.05, -0.15);
    group.add(monitor);

    const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.38), screenMat);
    screen.position.set(0, 1.05, -0.105);
    group.add(screen);

    // Keyboard
    const kb = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.03, 0.18), pcMat);
    kb.position.set(0, 0.815, 0.15);
    group.add(kb);

    this.addMesh(group);
    this.collision.addBox(`desk_${x}_${z}`, new THREE.Vector3(x, y + 0.5, z), new THREE.Vector3(2.1, 1.0, 1.1), 'prop');
  }

  private buildChair(x: number, y: number, z: number, rotY: number = 0) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = rotY;

    const chairMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.7 });
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.08, 0.6), chairMat);
    seat.position.y = 0.45;
    group.add(seat);

    const back = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.5, 0.08), chairMat);
    back.position.set(0, 0.72, -0.26);
    group.add(back);

    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.45, 6), chairMat);
    leg.position.y = 0.225;
    group.add(leg);

    this.addMesh(group);
    this.collision.addBox(`chair_${x}_${z}`, new THREE.Vector3(x, y + 0.45, z), new THREE.Vector3(0.7, 0.9, 0.7), 'prop');
  }

  private buildStorageShelf(x: number, y: number, z: number, rotY: number = 0) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = rotY;

    const metalMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8, roughness: 0.4 });
    const boxMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.9 });

    for (let s = 0; s < 4; s++) {
      const shelf = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.06, 0.8), metalMat);
      shelf.position.y = 0.4 + s * 0.6;
      group.add(shelf);

      // Supply box on shelf
      const b = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.4, 0.5), boxMat);
      b.position.set(-0.6 + (s % 2) * 1.0, 0.6 + s * 0.6, 0);
      group.add(b);
    }

    // 4 uprights
    [-1.15, 1.15].forEach(ux => {
      [-0.35, 0.35].forEach(uz => {
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.5, 6), metalMat);
        pole.position.set(ux, 1.25, uz);
        group.add(pole);
      });
    });

    this.addMesh(group);
    this.collision.addBox(`shelf_${x}_${z}`, new THREE.Vector3(x, y + 1.25, z), new THREE.Vector3(2.5, 2.5, 0.9), 'prop');
  }

  private buildFilingCabinet(x: number, y: number, z: number, rotY: number = 0) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = rotY;

    const cabMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.7, roughness: 0.5 });
    const cab = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.4, 0.7), cabMat);
    cab.position.y = 0.7;
    group.add(cab);

    this.addMesh(group);
    this.collision.addBox(`cab_${x}_${z}`, new THREE.Vector3(x, y + 0.7, z), new THREE.Vector3(0.9, 1.4, 0.8), 'prop');
  }

  private buildMedicalCart(x: number, y: number, z: number) {
    const group = new THREE.Group();
    group.position.set(x, y, z);

    const metalMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, roughness: 0.2 });
    const cart = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.9, 0.7), metalMat);
    cart.position.y = 0.45;
    group.add(cart);

    // Defibrillator box on top
    const defib = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.25, 0.3), new THREE.MeshStandardMaterial({ color: 0xdc2626 }));
    defib.position.set(0, 1.0, 0);
    group.add(defib);

    this.addMesh(group);
    this.collision.addBox(`medcart_${x}_${z}`, new THREE.Vector3(x, y + 0.55, z), new THREE.Vector3(1.1, 1.1, 0.8), 'prop');
  }

  // --- REUSABLE ARCHITECTURAL BUILDERS ---

  private createSidewalk(x: number, z: number, w: number, d: number) {
    const tex = TextureGenerator.createConcreteTexture();
    const mat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.8 });
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, 0.15, d), mat);
    mesh.position.set(x, 0.075, z);
    mesh.receiveShadow = true;
    this.addMesh(mesh);
    this.collision.addBox(`sidewalk_${x}_${z}`, mesh.position, new THREE.Vector3(w, 0.15, d), 'floor', true);
  }

  private buildHouseA(cx: number, cz: number) {
    const brickMat = new THREE.MeshStandardMaterial({ map: TextureGenerator.createBrickTexture(), roughness: 0.8 });
    const woodMat = new THREE.MeshStandardMaterial({ map: TextureGenerator.createWoodTexture(), roughness: 0.65 });
    const w = 16, d = 14, h = 3.8, thick = 0.4;

    const floor = new THREE.Mesh(new THREE.BoxGeometry(w, 0.2, d), woodMat);
    floor.position.set(cx, 0.1, cz);
    this.addMesh(floor);
    this.collision.addBox('houseA_floor', floor.position, new THREE.Vector3(w, 0.2, d), 'floor', true);

    this.createWall(cx - 5, cz - d / 2, 6, h, thick, brickMat);
    this.createWall(cx + 5, cz - d / 2, 6, h, thick, brickMat);
    this.createWall(cx - 5, cz + d / 2, 6, h, thick, brickMat);
    this.createWall(cx + 5, cz + d / 2, 6, h, thick, brickMat);
    this.createWall(cx - w / 2, cz, thick, h, d, brickMat);
    this.createWall(cx + w / 2, cz, thick, h, d, brickMat);

    const roof = new THREE.Mesh(new THREE.BoxGeometry(w + 0.8, 0.4, d + 0.8), new THREE.MeshStandardMaterial({ color: 0x27272a }));
    roof.position.set(cx, h + 0.2, cz);
    this.addMesh(roof);
    this.collision.addBox('houseA_roof', roof.position, new THREE.Vector3(w + 0.8, 0.4, d + 0.8), 'building');

    // House A Furnished Interior Rooms (Requirement 7)
    this.buildBed(cx - 5, 0.2, cz - 4, 0);
    this.buildDeskWithComputer(cx + 4, 0.2, cz - 4, Math.PI);
    this.buildChair(cx + 4, 0.2, cz - 3, 0);
    this.buildStorageShelf(cx - 5, 0.2, cz + 4, Math.PI / 2);
  }

  private buildTwoStoryCommandBuilding(cx: number, cz: number) {
    const concreteMat = new THREE.MeshStandardMaterial({ map: TextureGenerator.createConcreteTexture(), roughness: 0.75 });
    const bW = 18, bD = 16, storyH = 3.6, totalH = storyH * 2, thick = 0.4;

    const floor1 = new THREE.Mesh(new THREE.BoxGeometry(bW, 0.25, bD), concreteMat);
    floor1.position.set(cx, 0.125, cz);
    this.addMesh(floor1);
    this.collision.addBox('cmd_floor1', floor1.position, new THREE.Vector3(bW, 0.25, bD), 'floor', true);

    const floor2 = new THREE.Mesh(new THREE.BoxGeometry(bW - 4, 0.3, bD), concreteMat);
    floor2.position.set(cx - 2, storyH, cz);
    this.addMesh(floor2);
    this.collision.addBox('cmd_floor2', floor2.position, new THREE.Vector3(bW - 4, 0.3, bD), 'floor', true);

    this.createWall(cx, cz - bD / 2, bW, totalH, thick, concreteMat);
    this.createWall(cx - 5.5, cz + bD / 2, 7, totalH, thick, concreteMat);
    this.createWall(cx + 5.5, cz + bD / 2, 7, totalH, thick, concreteMat);
    this.createWall(cx + bW / 2, cz, thick, totalH, bD, concreteMat);
    this.createWall(cx - bW / 2, cz, thick, totalH, bD, concreteMat);

    const balcony = new THREE.Mesh(new THREE.BoxGeometry(7, 0.25, 3.5), concreteMat);
    balcony.position.set(cx, storyH, cz + bD / 2 + 1.75);
    this.addMesh(balcony);
    this.collision.addBox('cmd_balcony', balcony.position, new THREE.Vector3(7, 0.25, 3.5), 'floor', true);

    const steps = 12, stairW = 2.5, stepD = 0.85, stepH = storyH / steps;
    const stairMat = new THREE.MeshStandardMaterial({ color: 0x475569 });
    for (let i = 0; i < steps; i++) {
      const stepMesh = new THREE.Mesh(new THREE.BoxGeometry(stairW, stepH, stepD), stairMat);
      stepMesh.position.set(cx + bW / 2 - stairW / 2 - 0.4, (i + 0.5) * stepH, cz - 5 + i * stepD);
      this.addMesh(stepMesh);
      this.collision.addBox(`cmd_stair_${i}`, stepMesh.position, new THREE.Vector3(stairW, stepH, stepD), 'stair', true, true);
    }

    // Command Building 1st & 2nd floor furniture
    this.buildDeskWithComputer(cx - 5, 0.25, cz - 5, 0);
    this.buildFilingCabinet(cx - 7, 0.25, cz - 2, Math.PI / 2);
    this.buildStorageShelf(cx - 6, 0.25, cz + 4, Math.PI / 2);
    this.buildChair(cx - 5, 0.25, cz - 4, 0);

    // 2nd Floor Operations Terminal
    this.buildDeskWithComputer(cx - 3, storyH + 0.3, cz - 3, 0);
    this.buildFilingCabinet(cx + 2, storyH + 0.3, cz - 5, 0);
  }

  private buildDepot(cx: number, cz: number) {
    const metalMat = new THREE.MeshStandardMaterial({ map: TextureGenerator.createCorrugatedMetalTexture(), roughness: 0.5, metalness: 0.5 });
    const w = 20, d = 18, h = 5.2, thick = 0.4;

    const floor = new THREE.Mesh(new THREE.BoxGeometry(w, 0.2, d), new THREE.MeshStandardMaterial({ color: 0x262e35 }));
    floor.position.set(cx, 0.1, cz);
    this.addMesh(floor);
    this.collision.addBox('depot_floor', floor.position, new THREE.Vector3(w, 0.2, d), 'floor', true);

    this.createWall(cx - 6.5, cz - d / 2, 7, h, thick, metalMat);
    this.createWall(cx + 6.5, cz - d / 2, 7, h, thick, metalMat);
    this.createWall(cx, cz + d / 2, w, h, thick, metalMat);
    this.createWall(cx - w / 2, cz, thick, h, d, metalMat);
    this.createWall(cx + w / 2, cz, thick, h, d, metalMat);

    const roof = new THREE.Mesh(new THREE.BoxGeometry(w + 1, 0.4, d + 1), metalMat);
    roof.position.set(cx, h + 0.2, cz);
    this.addMesh(roof);
    this.collision.addBox('depot_roof', roof.position, new THREE.Vector3(w + 1, 0.4, d + 1), 'building');
  }

  private buildHouseB(cx: number, cz: number) {
    const brickMat = new THREE.MeshStandardMaterial({ map: TextureGenerator.createBrickTexture(), roughness: 0.8 });
    const w = 16, d = 14, h = 3.6, thick = 0.4;

    const floor = new THREE.Mesh(new THREE.BoxGeometry(w, 0.2, d), new THREE.MeshStandardMaterial({ color: 0x3f3223 }));
    floor.position.set(cx, 0.1, cz);
    this.addMesh(floor);
    this.collision.addBox('houseB_floor', floor.position, new THREE.Vector3(w, 0.2, d), 'floor', true);

    this.createWall(cx - 5, cz - d / 2, 6, h, thick, brickMat);
    this.createWall(cx + 5, cz - d / 2, 6, h, thick, brickMat);
    this.createWall(cx, cz + d / 2, w, h, thick, brickMat);
    this.createWall(cx + w / 2, cz, thick, h, d, brickMat);
    this.createWall(cx - w / 2, cz, thick, h, d, brickMat);
  }

  private buildSuburbanCentralPlaza(cx: number, cz: number) {
    const hazardMat = new THREE.MeshStandardMaterial({ map: TextureGenerator.createHazardTexture(), roughness: 0.6 });
    const addKrail = (x: number, z: number, w: number) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, 1.1, 0.7), hazardMat);
      m.position.set(x, 0.55, z);
      this.addMesh(m);
      this.collision.addBox(`krail_${x}_${z}`, m.position, new THREE.Vector3(w, 1.1, 0.7), 'barrier');
    };
    addKrail(cx - 7, cz - 7, 4.5);
    addKrail(cx + 7, cz - 7, 4.5);
    addKrail(cx - 7, cz + 7, 4.5);
    addKrail(cx + 7, cz + 7, 4.5);
  }

  private buildBlastBunker(cx: number, cz: number, w: number, h: number, d: number) {
    const mat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.7, metalness: 0.3 });
    const thick = 0.45;

    // Floor
    const floor = new THREE.Mesh(new THREE.BoxGeometry(w, 0.2, d), mat);
    floor.position.set(cx, 0.1, cz);
    this.addMesh(floor);
    this.collision.addBox(`bunker_fl_${cx}_${cz}`, floor.position, new THREE.Vector3(w, 0.2, d), 'floor', true);

    // Front Wall with entrance doorway
    this.createWall(cx - w / 4 - 0.5, cz + d / 2, w / 2 - 1.5, h, thick, mat);
    this.createWall(cx + w / 4 + 0.5, cz + d / 2, w / 2 - 1.5, h, thick, mat);

    // Back & Side Walls
    this.createWall(cx, cz - d / 2, w, h, thick, mat);
    this.createWall(cx - w / 2, cz, thick, h, d, mat);
    this.createWall(cx + w / 2, cz, thick, h, d, mat);

    // Roof
    const roof = new THREE.Mesh(new THREE.BoxGeometry(w + 0.5, 0.35, d + 0.5), mat);
    roof.position.set(cx, h + 0.18, cz);
    this.addMesh(roof);
    this.collision.addBox(`bunker_rf_${cx}_${cz}`, roof.position, new THREE.Vector3(w + 0.5, 0.35, d + 0.5), 'building');

    // Furnished Interior: military cots, command desk with terminal, storage rack
    this.buildBed(cx - w / 3, 0.2, cz - d / 4, 0);
    this.buildDeskWithComputer(cx + w / 4, 0.2, cz - d / 4, Math.PI);
    this.buildStorageShelf(cx - w / 3, 0.2, cz + d / 4, Math.PI / 2);
  }

  private buildWatchtower(cx: number, cz: number) {
    const mat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8 });
    [-2, 2].forEach(lx => {
      [-2, 2].forEach(lz => {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.22, 7.5), mat);
        leg.position.set(cx + lx, 3.75, cz + lz);
        this.addMesh(leg);
        this.collision.addBox(`tower_leg_${lx}_${lz}`, leg.position, new THREE.Vector3(0.5, 7.5, 0.5), 'prop');
      });
    });

    const plat = new THREE.Mesh(new THREE.BoxGeometry(5.5, 0.4, 5.5), mat);
    plat.position.set(cx, 7.5, cz);
    this.addMesh(plat);
    this.collision.addBox('tower_plat', plat.position, new THREE.Vector3(5.5, 0.4, 5.5), 'floor', true);
  }

  private buildAircraftHangar(cx: number, cz: number) {
    const mat = new THREE.MeshStandardMaterial({ map: TextureGenerator.createCorrugatedMetalTexture(), roughness: 0.4, metalness: 0.6 });
    const w = 32, h = 8, d = 24, thick = 0.5;

    this.createWall(cx - w / 2, cz, thick, h, d, mat);
    this.createWall(cx + w / 2, cz, thick, h, d, mat);
    this.createWall(cx, cz + d / 2, w, h, thick, mat);

    const roof = new THREE.Mesh(new THREE.BoxGeometry(w + 1, 0.5, d + 1), mat);
    roof.position.set(cx, h + 0.25, cz);
    this.addMesh(roof);
    this.collision.addBox('hangar_roof', roof.position, new THREE.Vector3(w + 1, 0.5, d + 1), 'building');
  }

  private buildBioLabBuilding(cx: number, cz: number) {
    const mat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.4, metalness: 0.1 });
    const w = 22, h = 4.5, d = 16, thick = 0.4;

    const floor = new THREE.Mesh(new THREE.BoxGeometry(w, 0.2, d), new THREE.MeshStandardMaterial({ color: 0x334155 }));
    floor.position.set(cx, 0.1, cz);
    this.addMesh(floor);
    this.collision.addBox(`biolab_fl_${cx}_${cz}`, floor.position, new THREE.Vector3(w, 0.2, d), 'floor', true);

    this.createWall(cx - 7, cz - d / 2, 8, h, thick, mat);
    this.createWall(cx + 7, cz - d / 2, 8, h, thick, mat);
    this.createWall(cx, cz + d / 2, w, h, thick, mat);
    this.createWall(cx - w / 2, cz, thick, h, d, mat);
    this.createWall(cx + w / 2, cz, thick, h, d, mat);

    const roof = new THREE.Mesh(new THREE.BoxGeometry(w + 0.5, 0.35, d + 0.5), mat);
    roof.position.set(cx, h + 0.18, cz);
    this.addMesh(roof);
    this.collision.addBox(`biolab_rf_${cx}_${cz}`, roof.position, new THREE.Vector3(w + 0.5, 0.35, d + 0.5), 'building');

    // BioLab Interior Equipment
    this.buildDeskWithComputer(cx - 6, 0.2, cz - 4, 0);
    this.buildDeskWithComputer(cx + 6, 0.2, cz - 4, 0);
    this.buildStorageShelf(cx - 6, 0.2, cz + 4, Math.PI / 2);
    this.buildFilingCabinet(cx + 6, 0.2, cz + 4, -Math.PI / 2);
  }

  private buildResearchTent(cx: number, cz: number) {
    const mat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.8 });
    const tent = new THREE.Mesh(new THREE.ConeGeometry(4.5, 3.8, 4), mat);
    tent.rotation.y = Math.PI / 4;
    tent.position.set(cx, 1.9, cz);
    this.addMesh(tent);
    this.collision.addBox(`tent_${cx}_${cz}`, tent.position, new THREE.Vector3(6, 3.8, 6), 'prop');
  }

  private buildBrickFactory(cx: number, cz: number) {
    const mat = new THREE.MeshStandardMaterial({ map: TextureGenerator.createBrickTexture(), roughness: 0.85 });
    const w = 28, h = 7, d = 20, thick = 0.5;

    const floor = new THREE.Mesh(new THREE.BoxGeometry(w, 0.2, d), new THREE.MeshStandardMaterial({ color: 0x262e35 }));
    floor.position.set(cx, 0.1, cz);
    this.addMesh(floor);
    this.collision.addBox(`factory_fl_${cx}_${cz}`, floor.position, new THREE.Vector3(w, 0.2, d), 'floor', true);

    this.createWall(cx - 9, cz - d / 2, 10, h, thick, mat);
    this.createWall(cx + 9, cz - d / 2, 10, h, thick, mat);
    this.createWall(cx, cz + d / 2, w, h, thick, mat);
    this.createWall(cx - w / 2, cz, thick, h, d, mat);
    this.createWall(cx + w / 2, cz, thick, h, d, mat);

    const roof = new THREE.Mesh(new THREE.BoxGeometry(w + 0.8, 0.4, d + 0.8), mat);
    roof.position.set(cx, h + 0.2, cz);
    this.addMesh(roof);
    this.collision.addBox(`factory_rf_${cx}_${cz}`, roof.position, new THREE.Vector3(w + 0.8, 0.4, d + 0.8), 'building');

    const stack = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.5, 14, 12), mat);
    stack.position.set(cx - 10, 7, cz - 6);
    this.addMesh(stack);
    this.collision.addBox('smokestack', stack.position, new THREE.Vector3(3, 14, 3), 'prop');

    // Factory Interior Furnishings
    this.buildDeskWithComputer(cx + 8, 0.2, cz - 6, Math.PI);
    this.buildChair(cx + 8, 0.2, cz - 5, 0);
    this.buildStorageShelf(cx - 8, 0.2, cz - 6, 0);
    this.buildStorageShelf(cx - 8, 0.2, cz + 6, 0);
  }

  private buildCityStorefront(cx: number, cz: number, w: number, h: number, d: number) {
    const mat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.7 });
    this.createWall(cx, cz + d / 2, w, h, 0.4, mat);
    this.createWall(cx, cz - d / 2, w, h, 0.4, mat);
    this.createWall(cx - w / 2, cz, 0.4, h, d, mat);
    this.createWall(cx + w / 2, cz, 0.4, h, d, mat);
  }

  private buildMetroEntrance(cx: number, cz: number) {
    const mat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8 });
    const canopy = new THREE.Mesh(new THREE.BoxGeometry(7, 0.3, 8), mat);
    canopy.position.set(cx, 3.2, cz);
    this.addMesh(canopy);
    this.collision.addBox('metro_canopy', canopy.position, new THREE.Vector3(7, 0.3, 8), 'building');
  }

  private buildAmbulance(x: number, y: number, z: number, rotY: number) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = rotY;
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.4 });
    const redStripe = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.3, 4.8), new THREE.MeshBasicMaterial({ color: 0xef4444 }));
    redStripe.position.y = 1.2;
    group.add(redStripe);

    const body = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.8, 4.6), bodyMat);
    body.position.y = 1.1;
    group.add(body);

    this.addMesh(group);
    this.collision.addBox(`ambulance_${x}_${z}`, new THREE.Vector3(x, 1.1, z), new THREE.Vector3(2.4, 2.2, 4.8), 'vehicle');
  }

  private buildHospitalStretcher(x: number, y: number, z: number) {
    const mat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8 });
    const mattress = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.2, 2.1), new THREE.MeshStandardMaterial({ color: 0x0284c7 }));
    mattress.position.set(x, y + 0.8, z);
    this.addMesh(mattress);

    const legs = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.7, 1.8), mat);
    legs.position.set(x, y + 0.35, z);
    this.addMesh(legs);
    this.collision.addBox(`stretcher_${x}_${z}`, mattress.position, new THREE.Vector3(1.0, 0.9, 2.2), 'prop');
  }

  private buildCityBus(x: number, y: number, z: number, rotY: number) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = rotY;
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.6 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.8, 2.6, 9.0), bodyMat);
    body.position.y = 1.6;
    body.castShadow = true;
    group.add(body);
    this.addMesh(group);
    this.collision.addBox(`bus_${x}_${z}`, new THREE.Vector3(x, 1.6, z), new THREE.Vector3(3.0, 2.8, 9.2), 'vehicle');
  }

  private buildMilitaryHumvee(x: number, y: number, z: number, rotY: number) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = rotY;
    const bodyMat = new THREE.MeshStandardMaterial({ map: TextureGenerator.createCamoTexture(), roughness: 0.6 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.2, 4.8), bodyMat);
    body.position.y = 0.9;
    group.add(body);
    this.addMesh(group);
    this.collision.addBox(`humvee_${x}_${z}`, new THREE.Vector3(x, 1.1, z), new THREE.Vector3(2.6, 2.2, 5.0), 'vehicle');
  }

  private buildPickupTruck(x: number, y: number, z: number, rotY: number) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = rotY;
    const truckMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.5 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.9, 4.4), truckMat);
    body.position.y = 0.8;
    group.add(body);
    this.addMesh(group);
    this.collision.addBox(`pickup_${x}_${z}`, new THREE.Vector3(x, 1.0, z), new THREE.Vector3(2.3, 2.1, 4.6), 'vehicle');
  }

  private buildSedanWreck(x: number, y: number, z: number, rotY: number) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = rotY;
    const rustMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.7, 4.0), rustMat);
    body.position.y = 0.6;
    group.add(body);
    this.addMesh(group);
    this.collision.addBox(`sedan_${x}_${z}`, new THREE.Vector3(x, 0.8, z), new THREE.Vector3(2.2, 1.8, 4.2), 'vehicle');
  }

  // Requirement 8 & 9: Real, vivid water area with luminous azure color, 4-sided basin rim and depth
  private buildWaterArea(x: number, z: number, w: number, d: number) {
    // 1. Underwater depth basin floor
    const basinMat = new THREE.MeshStandardMaterial({ color: 0x0f3b57, roughness: 0.8 });
    const basin = new THREE.Mesh(new THREE.PlaneGeometry(w, d), basinMat);
    basin.rotation.x = -Math.PI / 2;
    basin.position.set(x, 0.04, z);
    this.addMesh(basin);

    // 2. Luminous, vibrant water surface (Elevated to y = 0.22 so it's always clearly above terrain/sidewalks)
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Vibrant sky/ocean blue
      emissive: 0x0369a1,
      emissiveIntensity: 0.35,
      roughness: 0.1,
      metalness: 0.25,
      transparent: true,
      opacity: 0.85,
    });
    const water = new THREE.Mesh(new THREE.PlaneGeometry(w - 0.2, d - 0.2), waterMat);
    water.rotation.x = -Math.PI / 2;
    water.position.set(x, 0.22, z);
    this.addMesh(water);

    // 3. Complete 4-Sided Stone / Concrete Basin Border Rim (Height 0.32)
    const rimMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.75 });
    const rimH = 0.32;
    const rimThick = 0.4;

    // North Rim
    const rimN = new THREE.Mesh(new THREE.BoxGeometry(w + rimThick, rimH, rimThick), rimMat);
    rimN.position.set(x, rimH / 2, z - d / 2);
    this.addMesh(rimN);
    this.collision.addBox(`rim_n_${x}_${z}`, rimN.position, new THREE.Vector3(w + rimThick, rimH, rimThick), 'prop');

    // South Rim
    const rimS = new THREE.Mesh(new THREE.BoxGeometry(w + rimThick, rimH, rimThick), rimMat);
    rimS.position.set(x, rimH / 2, z + d / 2);
    this.addMesh(rimS);
    this.collision.addBox(`rim_s_${x}_${z}`, rimS.position, new THREE.Vector3(w + rimThick, rimH, rimThick), 'prop');

    // West Rim
    const rimW = new THREE.Mesh(new THREE.BoxGeometry(rimThick, rimH, d + rimThick), rimMat);
    rimW.position.set(x - w / 2, rimH / 2, z);
    this.addMesh(rimW);
    this.collision.addBox(`rim_w_${x}_${z}`, rimW.position, new THREE.Vector3(rimThick, rimH, d + rimThick), 'prop');

    // East Rim
    const rimE = new THREE.Mesh(new THREE.BoxGeometry(rimThick, rimH, d + rimThick), rimMat);
    rimE.position.set(x + w / 2, rimH / 2, z);
    this.addMesh(rimE);
    this.collision.addBox(`rim_e_${x}_${z}`, rimE.position, new THREE.Vector3(rimThick, rimH, d + rimThick), 'prop');
  }

  private buildPerimeterFence() {
    const mat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8 });
    const h = 2.8, thick = 0.3;
    const pN = new THREE.Mesh(new THREE.BoxGeometry(96, h, thick), mat);
    pN.position.set(0, h / 2, -48);
    this.addMesh(pN);
    const pS = new THREE.Mesh(new THREE.BoxGeometry(96, h, thick), mat);
    pS.position.set(0, h / 2, 48);
    this.addMesh(pS);
    const pW = new THREE.Mesh(new THREE.BoxGeometry(thick, h, 96), mat);
    pW.position.set(-48, h / 2, 0);
    this.addMesh(pW);
    const pE = new THREE.Mesh(new THREE.BoxGeometry(thick, h, 96), mat);
    pE.position.set(48, h / 2, 0);
    this.addMesh(pE);
  }

  private buildWoodenFence(x: number, z: number, w: number, h: number, d: number) {
    const mat = new THREE.MeshStandardMaterial({ map: TextureGenerator.createWoodTexture(), roughness: 0.85 });
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    mesh.position.set(x, h / 2, z);
    this.addMesh(mesh);
    this.collision.addBox(`wfence_${x}_${z}`, mesh.position, new THREE.Vector3(w, h, d), 'fence');
  }

  private buildSandbagWall(x: number, z: number, length: number, rotY: number) {
    const mat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.9 });
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(length, 0.9, 0.6), mat);
    mesh.position.set(x, 0.45, z);
    mesh.rotation.y = rotY;
    this.addMesh(mesh);
    this.collision.addBox(`sandbag_${x}_${z}`, mesh.position, new THREE.Vector3(length, 0.9, 0.6), 'barrier');
  }

  private buildShippingContainer(x: number, z: number, color: string, rotY: number) {
    const mat = new THREE.MeshStandardMaterial({
      map: TextureGenerator.createCorrugatedMetalTexture(),
      color: new THREE.Color(color),
      roughness: 0.5,
      metalness: 0.4,
    });
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(2.8, 2.8, 7.0), mat);
    mesh.position.set(x, 1.4, z);
    mesh.rotation.y = rotY;
    this.addMesh(mesh);
    this.collision.addBox(`container_${x}_${z}`, mesh.position, new THREE.Vector3(2.8, 2.8, 7.0), 'building');
  }

  private buildCrateStack(x: number, z: number) {
    const mat = new THREE.MeshStandardMaterial({ map: TextureGenerator.createWoodTexture(), roughness: 0.8 });
    const createC = (cx: number, cy: number, cz: number, s: number) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(s, s, s), mat);
      m.position.set(cx, cy, cz);
      this.addMesh(m);
      this.collision.addBox(`crate_${cx}_${cz}`, m.position, new THREE.Vector3(s, s, s), 'prop');
    };
    createC(x, 0.6, z, 1.2);
    createC(x + 1.2, 0.6, z, 1.2);
    createC(x + 0.6, 1.8, z, 1.2);
  }

  private buildExplosiveBarrel(x: number, z: number) {
    const mat = new THREE.MeshStandardMaterial({ color: 0xdc2626, metalness: 0.7, roughness: 0.4 });
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 1.2, 14), mat);
    mesh.position.set(x, 0.6, z);
    this.addMesh(mesh);
    this.collision.addBox(`barrel_${x}_${z}`, mesh.position, new THREE.Vector3(0.8, 1.2, 0.8), 'prop');
  }

  private buildStreetLamps(positions: { x: number; z: number }[]) {
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x374151, metalness: 0.7 });
    const bulbMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xfef08a, emissiveIntensity: 1.5 });

    positions.forEach((pos, idx) => {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 5.5), poleMat);
      pole.position.set(pos.x, 2.75, pos.z);
      this.addMesh(pole);
      this.collision.addBox(`pole_${idx}`, pole.position, new THREE.Vector3(0.4, 5.5, 0.4), 'prop');

      const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 8), bulbMat);
      bulb.position.set(pos.x, 5.25, pos.z);
      this.addMesh(bulb);

      const light = new THREE.PointLight(0xffe082, 1.8, 16);
      light.position.set(pos.x, 5.1, pos.z);
      this.addMesh(light);

      this.streetLamps.push({ light, bulbMesh: bulb });
    });
  }

  private buildTrees(positions: { x: number; z: number }[]) {
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x45220a });
    const folMat = new THREE.MeshStandardMaterial({ color: 0x1e3a1e, roughness: 0.85 });

    positions.forEach((pos, idx) => {
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.45, 4.5), trunkMat);
      trunk.position.set(pos.x, 2.25, pos.z);
      this.addMesh(trunk);
      this.collision.addBox(`tree_${idx}`, trunk.position, new THREE.Vector3(0.9, 4.5, 0.9), 'prop');

      for (let f = 0; f < 3; f++) {
        const fol = new THREE.Mesh(new THREE.ConeGeometry(2.4 - f * 0.5, 2.2, 7), folMat);
        fol.position.set(pos.x, 4.2 + f * 1.5, pos.z);
        this.addMesh(fol);
      }
    });
  }

  private createWall(x: number, z: number, w: number, h: number, d: number, mat: THREE.Material) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    mesh.position.set(x, h / 2, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    this.addMesh(mesh);
    this.collision.addBox(`wall_${x}_${z}`, mesh.position, new THREE.Vector3(w, h, d), 'building');
    return mesh;
  }

  private createWallBuy(id: string, name: string, cost: number, pos: THREE.Vector3, rot: THREE.Euler) {
    const tex = TextureGenerator.createWallBuyTexture(name, cost);
    const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, side: THREE.DoubleSide });
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.2), mat);
    mesh.position.copy(pos);
    mesh.rotation.copy(rot);
    this.addMesh(mesh);

    // Requirement 24: Physical 3D weapon model displayed on the wall
    let wepType = 'rifle';
    if (name.toLowerCase().includes('shotgun')) wepType = 'shotgun';
    else if (name.toLowerCase().includes('sniper')) wepType = 'sniper';
    else if (name.toLowerCase().includes('smg')) wepType = 'smg';

    const wepBuilt = WeaponModels.buildWeapon(wepType);
    const arms = wepBuilt.model.getObjectByName('fps_arms');
    if (arms) arms.visible = false;
    wepBuilt.model.position.copy(pos).add(new THREE.Vector3(0, -0.05, 0.12).applyEuler(rot));
    wepBuilt.model.rotation.copy(rot);
    wepBuilt.model.rotation.y += Math.PI / 2;
    wepBuilt.model.scale.setScalar(1.3);
    this.addMesh(wepBuilt.model);

    // Glowing weapon display backlight
    const buyLight = new THREE.PointLight(0x38bdf8, 1.2, 5);
    buyLight.position.copy(pos).add(new THREE.Vector3(0, 0, 0.2).applyEuler(rot));
    this.addMesh(buyLight);

    this.interactiveEntities.push({
      id,
      type: 'wallbuy',
      name,
      cost,
      position: pos.clone(),
      radius: 2.8,
      action: () => {},
    });
  }

  private createAmmoCrate(pos: THREE.Vector3) {
    const mat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.6, metalness: 0.3 });
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.9, 1.1), mat);
    mesh.position.set(pos.x, 0.45, pos.z);
    this.addMesh(mesh);
    this.collision.addBox('ammo_crate', mesh.position, new THREE.Vector3(1.6, 0.9, 1.1), 'prop');

    this.interactiveEntities.push({
      id: 'ammo_crate',
      type: 'ammocrate',
      name: 'Max Ammo Refill',
      cost: 500,
      position: pos.clone(),
      radius: 2.6,
      action: () => {},
    });
  }

  public mysteryBoxLid: THREE.Mesh | null = null;
  public mysteryBoxGroup: THREE.Group | null = null;

  private createMysteryBox(pos: THREE.Vector3) {
    const boxGroup = new THREE.Group();
    boxGroup.position.copy(pos);

    // 1. Heavy Reinforced Machine Chassis
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.85, roughness: 0.3 });
    const brassMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9, roughness: 0.25 });
    const energyGlow = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });

    const base = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.7, 1.2), steelMat);
    base.position.y = 0.35;
    boxGroup.add(base);

    // 4 Glowing Corner Energy Pillars
    [[-1.15, -0.55], [1.15, -0.55], [-1.15, 0.55], [1.15, 0.55]].forEach(([cx, cz]) => {
      const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.9, 8), energyGlow);
      pillar.position.set(cx, 0.45, cz);
      boxGroup.add(pillar);

      const cap = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.1, 0.16), brassMat);
      cap.position.set(cx, 0.85, cz);
      boxGroup.add(cap);
    });

    // 2. Animated Hinged Lid (Requirement 11 & 12)
    const lid = new THREE.Mesh(new THREE.BoxGeometry(2.45, 0.15, 1.25), steelMat);
    lid.position.set(0, 0.75, 0);
    boxGroup.add(lid);
    this.mysteryBoxLid = lid;

    // Glowing question mark stencil on top of lid
    const stencil = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.8), energyGlow);
    stencil.rotation.x = -Math.PI / 2;
    stencil.position.set(0, 0.83, 0);
    boxGroup.add(stencil);

    this.addMesh(boxGroup);
    this.mysteryBoxGroup = boxGroup;
    this.collision.addBox('mystery_box', new THREE.Vector3(pos.x, pos.y + 0.45, pos.z), new THREE.Vector3(2.5, 0.9, 1.3), 'prop');

    // Glowing mystery beacon light beam
    const light = new THREE.PointLight(0x38bdf8, 2.5, 10);
    light.position.set(pos.x, pos.y + 1.6, pos.z);
    this.addMesh(light);

    this.interactiveEntities.push({
      id: 'mystery_box',
      type: 'mysterybox',
      name: 'Random Weapon Box',
      cost: 950,
      position: pos.clone(),
      radius: 3.2,
      action: () => {},
    });
  }
}
