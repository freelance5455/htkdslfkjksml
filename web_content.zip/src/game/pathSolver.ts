import { BoardTile, Direction } from '../types';

export interface PathCheckResult {
  canEscape: boolean;
  blockingTileId?: string;
  obstacleType?: string;
  reason?: 'BLOCKED_BY_TILE' | 'LOCKED' | 'FROZEN' | 'GATE_CLOSED' | 'NONE';
  portalUsed?: boolean;
}

export const getDirectionDelta = (dir: Direction): { dx: number; dy: number } => {
  switch (dir) {
    case 'UP':
      return { dx: 0, dy: -1 };
    case 'DOWN':
      return { dx: 0, dy: 1 };
    case 'LEFT':
      return { dx: -1, dy: 0 };
    case 'RIGHT':
      return { dx: 1, dy: 0 };
    default:
      return { dx: 0, dy: -1 };
  }
};

export const getRotatedDirection = (dir: Direction): Direction => {
  switch (dir) {
    case 'UP':
      return 'RIGHT';
    case 'RIGHT':
      return 'DOWN';
    case 'DOWN':
      return 'LEFT';
    case 'LEFT':
      return 'UP';
    default:
      return 'RIGHT';
  }
};

/**
 * Checks if a specific tile has a completely clear escape path off the board.
 */
export function checkEscapePath(
  tile: BoardTile,
  allTiles: BoardTile[],
  gridWidth: number,
  gridHeight: number
): PathCheckResult {
  if (tile.type !== 'ARROW' || tile.isEscaping) {
    return { canEscape: false, reason: 'NONE' };
  }

  // Check state locks
  if (tile.isLocked) {
    return { canEscape: false, reason: 'LOCKED' };
  }
  if (tile.isFrozen) {
    return { canEscape: false, reason: 'FROZEN' };
  }

  const direction = tile.direction || 'UP';
  const { dx, dy } = getDirectionDelta(direction);

  // Map of active non-escaped tiles by coordinate (supports multi-point bent arrows)
  const cellOwnerMap = new Map<string, BoardTile>();
  allTiles.forEach((t) => {
    if (!t.isEscaping) {
      if (t.points && t.points.length > 0) {
        t.points.forEach((pt) => {
          cellOwnerMap.set(`${pt.x},${pt.y}`, t);
        });
      } else {
        cellOwnerMap.set(`${t.x},${t.y}`, t);
      }
    }
  });

  const myPoints =
    tile.points && tile.points.length > 0
      ? tile.points
      : [{ x: tile.x, y: tile.y }];
  const head = myPoints[myPoints.length - 1];

  // In the railway path system:
  // The head moves first along its predefined forward track.
  // The body follows behind it along the SAME track.
  // The arrow can escape if and only if the forward track from the head to the board boundary is clear!
  const forwardCells: { x: number; y: number; stepDir: Direction }[] = [];

  if (tile.exitWaypoints && tile.exitWaypoints.length > 0) {
    let curr = head;
    for (const waypoint of tile.exitWaypoints) {
      const stepX = Math.sign(waypoint.x - curr.x);
      const stepY = Math.sign(waypoint.y - curr.y);
      const stepDir: Direction =
        stepX > 0 ? 'RIGHT' : stepX < 0 ? 'LEFT' : stepY > 0 ? 'DOWN' : 'UP';

      let cx = curr.x + stepX;
      let cy = curr.y + stepY;
      while (true) {
        forwardCells.push({ x: cx, y: cy, stepDir });
        if (cx === waypoint.x && cy === waypoint.y) break;
        cx += stepX;
        cy += stepY;
      }
      curr = waypoint;
    }
  } else {
    let curX = head.x + dx;
    let curY = head.y + dy;
    while (curX >= 0 && curX < gridWidth && curY >= 0 && curY < gridHeight) {
      forwardCells.push({ x: curX, y: curY, stepDir: direction });
      curX += dx;
      curY += dy;
    }
  }

  let portalUsed = false;
  for (let idx = 0; idx < forwardCells.length; idx++) {
    const { x: curX, y: curY, stepDir } = forwardCells[idx];
    const obstacle = cellOwnerMap.get(`${curX},${curY}`);

    if (obstacle && obstacle.id !== tile.id) {
      // 1. Fixed Wall Obstacle
      if (obstacle.type === 'OBSTACLE_WALL') {
        return {
          canEscape: false,
          blockingTileId: obstacle.id,
          obstacleType: 'wall',
          reason: 'BLOCKED_BY_TILE',
        };
      }

      // 2. Breakable Wood Barrier
      if (obstacle.type === 'OBSTACLE_WOOD') {
        return {
          canEscape: false,
          blockingTileId: obstacle.id,
          obstacleType: 'wood',
          reason: 'BLOCKED_BY_TILE',
        };
      }

      // 3. Arrow Block
      if (obstacle.type === 'ARROW') {
        return {
          canEscape: false,
          blockingTileId: obstacle.id,
          obstacleType: 'arrow',
          reason: 'BLOCKED_BY_TILE',
        };
      }

      // 4. Gate Tile
      if (obstacle.type === 'GATE') {
        if (!obstacle.gateOpen) {
          if (obstacle.direction && obstacle.direction === stepDir) {
            // Can pass through in the allowed direction
          } else {
            return {
              canEscape: false,
              blockingTileId: obstacle.id,
              obstacleType: 'gate',
              reason: 'GATE_CLOSED',
            };
          }
        }
      }

      // 5. Portal Tile
      if (obstacle.type === 'PORTAL' && obstacle.portalTargetId) {
        portalUsed = true;
      }
    }
  }

  return { canEscape: true, reason: 'NONE', portalUsed };
}

/**
 * Finds the best next solvable arrow for the hint system.
 */
export function findSolvableHint(
  allTiles: BoardTile[],
  gridWidth: number,
  gridHeight: number
): string | null {
  const activeArrows = allTiles.filter((t) => t.type === 'ARROW' && !t.isEscaping);

  // 1. Direct clear arrows
  for (const arrow of activeArrows) {
    const res = checkEscapePath(arrow, allTiles, gridWidth, gridHeight);
    if (res.canEscape) {
      return arrow.id;
    }
  }

  // 2. Rotatable arrows that would escape if rotated
  for (const arrow of activeArrows) {
    if (arrow.isRotator) {
      const nextDir = getRotatedDirection(arrow.direction || 'UP');
      const tempArrow = { ...arrow, direction: nextDir };
      const res = checkEscapePath(tempArrow, allTiles, gridWidth, gridHeight);
      if (res.canEscape) {
        return arrow.id;
      }
    }
  }

  // Fallback to any active arrow
  return activeArrows.length > 0 ? activeArrows[0].id : null;
}

/**
 * Solvability verification: Simulates forward escape steps
 * to mathematically verify that all arrows can escape the board.
 */
export function verifyLevelSolvable(
  tiles: BoardTile[],
  gridWidth: number,
  gridHeight: number
): { solvable: boolean; movesCount: number } {
  // Deep clone active arrow tiles
  const state: BoardTile[] = tiles.map((t) => ({ ...t }));
  let movesCount = 0;
  let progress = true;

  while (progress) {
    progress = false;
    const activeArrows = state.filter((t) => t.type === 'ARROW' && !t.isEscaping);
    if (activeArrows.length === 0) break;

    for (let i = 0; i < activeArrows.length; i++) {
      const arrow = activeArrows[i];
      const check = checkEscapePath(arrow, state, gridWidth, gridHeight);
      if (check.canEscape) {
        // Mark as escaped
        const target = state.find((t) => t.id === arrow.id);
        if (target) target.isEscaping = true;
        movesCount++;
        progress = true;
        break;
      }

      // Check rotator mechanics
      if (arrow.isRotator) {
        let currentDir = arrow.direction || 'UP';
        for (let r = 0; r < 3; r++) {
          currentDir = getRotatedDirection(currentDir);
          const rotated = { ...arrow, direction: currentDir };
          const rotCheck = checkEscapePath(rotated, state, gridWidth, gridHeight);
          if (rotCheck.canEscape) {
            const target = state.find((t) => t.id === arrow.id);
            if (target) {
              target.direction = currentDir;
              target.isEscaping = true;
            }
            movesCount += (r + 2);
            progress = true;
            break;
          }
        }
        if (progress) break;
      }
    }
  }

  const remaining = state.filter((t) => t.type === 'ARROW' && !t.isEscaping).length;
  return { solvable: remaining === 0, movesCount };
}
