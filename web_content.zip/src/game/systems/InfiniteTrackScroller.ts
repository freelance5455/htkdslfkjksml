/**
 * SPR - Infinite Track & Background Scroller System
 * 
 * Provides both:
 * 1. InfiniteTrackScroller: Direct continuous repeating scroller using modulo math (from your script)
 * 2. DualTileTrackScroller: Zero-pop double-buffered tile recycler for endless 3D tracks/backgrounds
 */

import * as THREE from 'three';

export interface ScrollerOptions {
  scrollSpeed?: number;
  tileLength?: number;
}

/**
 * Continuous Modulo-based Track & Background Scroller
 * Implements the exact loop logic from your script:
 * pos.z = startZ - ((time * speed) % tileLength)
 */
export class InfiniteTrackScroller {
  public backgroundPart: THREE.Object3D;
  public scrollSpeed: number;
  public tileLength: number;
  public startPosition: THREE.Vector3;
  private accumulatedTime: number = 0;

  constructor(backgroundPart: THREE.Object3D, options?: ScrollerOptions) {
    this.backgroundPart = backgroundPart;
    this.scrollSpeed = options?.scrollSpeed ?? 15;
    this.tileLength = options?.tileLength ?? 50;
    this.startPosition = backgroundPart.position.clone();
  }

  /**
   * Updates background scroll position smoothly each frame
   */
  public update(deltaTime: number) {
    if (!this.backgroundPart) return;

    this.accumulatedTime += deltaTime;
    // Repeat offset between 0 and tileLength
    const newPosition = (this.accumulatedTime * this.scrollSpeed) % this.tileLength;
    this.backgroundPart.position.z = this.startPosition.z - newPosition;
  }

  public setSpeed(speed: number) {
    this.scrollSpeed = speed;
  }

  public reset() {
    this.accumulatedTime = 0;
    this.backgroundPart.position.copy(this.startPosition);
  }
}

/**
 * Double-Buffered Seamless Track Scroller
 * Alternates between 2 adjacent tiles (length = tileLength) so that as soon as
 * one tile passes behind the camera, it moves forward ahead of the other tile.
 */
export class DualTileTrackScroller {
  public tileA: THREE.Object3D;
  public tileB: THREE.Object3D;
  public scrollSpeed: number;
  public tileLength: number;

  constructor(tileA: THREE.Object3D, tileB: THREE.Object3D, options?: ScrollerOptions) {
    this.tileA = tileA;
    this.tileB = tileB;
    this.scrollSpeed = options?.scrollSpeed ?? 15;
    this.tileLength = options?.tileLength ?? 50;

    // Tile A at origin, Tile B immediately ahead
    this.tileA.position.z = 0;
    this.tileB.position.z = -this.tileLength;
  }

  public update(deltaTime: number) {
    const moveDistance = this.scrollSpeed * deltaTime;

    this.tileA.position.z += moveDistance;
    this.tileB.position.z += moveDistance;

    // When tile passes camera (+tileLength), snap it behind the other tile
    if (this.tileA.position.z >= this.tileLength) {
      this.tileA.position.z = this.tileB.position.z - this.tileLength;
    }

    if (this.tileB.position.z >= this.tileLength) {
      this.tileB.position.z = this.tileA.position.z - this.tileLength;
    }
  }

  public setSpeed(speed: number) {
    this.scrollSpeed = speed;
  }
}
