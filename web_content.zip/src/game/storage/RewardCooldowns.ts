/**
 * SPR - Sahil Powerful Run
 * Persistent Offline 24-Hour Reward Cooldown System
 * 
 * Manages strict 24-hour cooldown timers for:
 * 1. Daily Reward
 * 2. Spin Wheel / Lucky Spin
 * 3. Free Coins
 * 4. Daily Missions / Tasks
 * 5. Leaderboard Champion Reward
 * 
 * Rules:
 * - Claiming locks the feature immediately
 * - Button becomes disabled / unclickable
 * - Live real-time countdown formatted as: "NEXT [REWARD] IN 23:59:59"
 * - Stored in persistent local storage using epoch timestamp (Date.now())
 * - Automatically continues counting down offline, during app reload, screen switch
 * - When remaining reaches 00:00:00, feature unlocks automatically
 */

export type RewardType = 'daily_reward' | 'spin' | 'free_coins' | 'missions' | 'leaderboard';

export interface CooldownRecord {
  lastClaimTime: number; // Unix timestamp in ms
}

const STORAGE_KEY = 'spr_reward_cooldowns_v1';
export const COOLDOWN_DURATION_MS = 24 * 60 * 60 * 1000; // Exact 24 Hours in milliseconds (86,400,000 ms)

class RewardCooldownManager {
  private records: Record<RewardType, CooldownRecord> = {
    daily_reward: { lastClaimTime: 0 },
    spin: { lastClaimTime: 0 },
    free_coins: { lastClaimTime: 0 },
    missions: { lastClaimTime: 0 },
    leaderboard: { lastClaimTime: 0 },
  };

  private listeners: Set<() => void> = new Set();

  constructor() {
    this.load();
  }

  private load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
          for (const key of ['daily_reward', 'spin', 'free_coins', 'missions', 'leaderboard'] as RewardType[]) {
            if (parsed[key] && typeof parsed[key].lastClaimTime === 'number') {
              this.records[key] = { lastClaimTime: parsed[key].lastClaimTime };
            }
          }
        }
      }
    } catch (e) {
      console.error('Failed to load reward cooldowns', e);
    }
  }

  private save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.records));
    } catch (e) {
      console.error('Failed to save reward cooldowns', e);
    }
    this.notifyListeners();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners() {
    this.listeners.forEach((cb) => cb());
  }

  /**
   * Get the remaining cooldown in milliseconds.
   * Returns 0 if the reward is ready/available.
   */
  public getRemainingMs(type: RewardType): number {
    const record = this.records[type];
    if (!record || !record.lastClaimTime) {
      return 0;
    }
    const elapsed = Date.now() - record.lastClaimTime;
    const remaining = COOLDOWN_DURATION_MS - elapsed;
    return remaining > 0 ? remaining : 0;
  }

  /**
   * Check if a reward is ready to be claimed (cooldown expired or never claimed).
   */
  public isAvailable(type: RewardType): boolean {
    return this.getRemainingMs(type) <= 0;
  }

  /**
   * Format remaining milliseconds into "HH:MM:SS" (e.g., "23:59:59").
   */
  public formatCountdown(remainingMs: number): string {
    if (remainingMs <= 0) return '00:00:00';
    const totalSeconds = Math.ceil(remainingMs / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);
    return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
  }

  /**
   * Get the standard formatted countdown string: "NEXT [LABEL] IN 23:59:59"
   */
  public getCountdownLabel(type: RewardType, customLabel?: string): string {
    const remaining = this.getRemainingMs(type);
    if (remaining <= 0) return 'READY TO CLAIM';

    const defaultLabels: Record<RewardType, string> = {
      daily_reward: 'REWARD',
      spin: 'SPIN',
      free_coins: 'COINS',
      missions: 'MISSIONS',
      leaderboard: 'TRIBUTE',
    };

    const label = customLabel || defaultLabels[type];
    return `NEXT ${label} IN ${this.formatCountdown(remaining)}`;
  }

  /**
   * Record a claim. Locks the feature for 24 hours immediately.
   */
  public recordClaim(type: RewardType): void {
    this.records[type] = { lastClaimTime: Date.now() };
    this.save();
  }

  /**
   * For testing/debug if needed: reset a specific cooldown
   */
  public resetCooldown(type: RewardType): void {
    this.records[type] = { lastClaimTime: 0 };
    this.save();
  }
}

export const rewardCooldowns = new RewardCooldownManager();
