import { createStarterElementsProgress } from '../data/elements';
import { QUESTS } from '../data/entities';
import {
  computePlayerStats,
  createStarterEquipment,
  createStarterInventory,
} from '../data/items';
import {
  AudioSettings,
  ElementId,
  ElementProgress,
  GraphicsPreset,
  GraphicsSettings,
  QuestProgress,
  SaveDataV1,
} from '../types';

export const SAVE_STORAGE_KEY = 'aetheria_rpg_save_v1';
export const GRAPHICS_STORAGE_KEY = 'aetheria_rpg_graphics_v1';
export const AUDIO_STORAGE_KEY = 'aetheria_rpg_audio_v1';

export function getDefaultAudioSettings(): AudioSettings {
  return {
    masterVolume: 0.75,
    musicVolume: 0.45,
    sfxVolume: 0.8,
    ambientVolume: 0.55,
    monsterVolume: 0.8,
    muted: false,
  };
}

export function getPresetGraphicsSettings(preset: GraphicsPreset): GraphicsSettings {
  switch (preset) {
    case 'low':
      return {
        preset: 'low',
        textureQuality: 'low',
        shadowQuality: 'off',
        drawDistance: 2,
        viewDistanceMeters: 58,
        effectsQuality: 'low',
        foliageDensity: 0.35,
        renderScale: 0.7,
        maxFps: 30,
      };
    case 'high':
      return {
        preset: 'high',
        textureQuality: 'high',
        shadowQuality: 'high',
        drawDistance: 4,
        viewDistanceMeters: 105,
        effectsQuality: 'high',
        foliageDensity: 1.0,
        renderScale: 1.0,
        maxFps: 60,
      };
    case 'medium':
    default:
      return {
        preset: 'medium',
        textureQuality: 'medium',
        shadowQuality: 'medium',
        drawDistance: 3,
        viewDistanceMeters: 80,
        effectsQuality: 'medium',
        foliageDensity: 0.7,
        renderScale: 0.85,
        maxFps: 60,
      };
  }
}

export function detectRecommendedPreset(): GraphicsPreset {
  if (typeof navigator === 'undefined') return 'medium';
  const mem = (navigator as unknown as { deviceMemory?: number }).deviceMemory ?? 4;
  const cores = navigator.hardwareConcurrency ?? 4;
  const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  if (mem <= 2 || (cores <= 4 && isMobile)) return 'low';
  if (mem >= 8 && cores >= 8 && !isMobile) return 'high';
  return 'medium';
}

function createStarterQuests(): Record<string, QuestProgress> {
  const q: Record<string, QuestProgress> = {};
  for (const def of QUESTS) {
    q[def.id] = { accepted: false, progress: 0, completed: false, claimed: false };
  }
  return q;
}

export function createDefaultSave(seed?: number): SaveDataV1 {
  const defaultPreset = detectRecommendedPreset();
  const equipment = createStarterEquipment();
  const computed = computePlayerStats(1, equipment);
  return {
    version: 3,
    seed: seed ?? Math.floor(100000 + Math.random() * 900000),
    savedAt: Date.now(),
    playTimeSeconds: 0,
    player: {
      x: 0,
      y: 8,
      z: 0,
      yaw: 0,
      pitch: -0.18,
      cameraMode: 'third',
      level: 1,
      xp: 0,
      gold: 60,
      elementShards: 3,
      hp: computed.maxHp,
      maxHp: computed.maxHp,
      mana: computed.maxMana,
      maxMana: computed.maxMana,
      stamina: computed.maxStamina,
      maxStamina: computed.maxStamina,
      survival: {
        hunger: 92,
        thirst: 92,
        temperature: 22,
        rest: 95,
      },
      inventory: createStarterInventory(),
      equipment,
      elements: createStarterElementsProgress(),
      equippedElements: ['fire', null],
      bestiary: {},
      activeSummonId: null,
      activeSummonIds: [],
      summonMasteryLevel: 1,
      summonMasteryXp: 0,
      summonCooldowns: {},
      skillPoints: 0,
      skillRanks: {},
      unlockedRealms: [],
      quests: createStarterQuests(),
      monstersKilled: 0,
      dungeonsCleared: 0,
      bossesDefeated: 0,
    },
    discoveredBiomes: ['emerald_forest'],
    discoveredChunks: ['0,0'],
    discoveredLocations: [
      { id: 'village_aetheria', nameAr: 'قرية إيثيريا', kind: 'village', x: 24, z: 18, level: 1 },
    ],
    mapMarkers: [],
    harvestedNodes: [],
    clearedDungeons: [],
    graphics: loadGraphicsSettings() ?? getPresetGraphicsSettings(defaultPreset),
    audio: loadAudioSettings(),
  };
}

export function loadAudioSettings(): AudioSettings {
  const base = getDefaultAudioSettings();
  try {
    const raw = localStorage.getItem(AUDIO_STORAGE_KEY);
    if (!raw) return base;
    const parsed = JSON.parse(raw) as Partial<AudioSettings>;
    return {
      masterVolume: Math.min(1, Math.max(0, Number(parsed.masterVolume ?? base.masterVolume))),
      musicVolume: Math.min(1, Math.max(0, Number(parsed.musicVolume ?? base.musicVolume))),
      sfxVolume: Math.min(1, Math.max(0, Number(parsed.sfxVolume ?? base.sfxVolume))),
      ambientVolume: Math.min(1, Math.max(0, Number(parsed.ambientVolume ?? base.ambientVolume))),
      monsterVolume: Math.min(1, Math.max(0, Number(parsed.monsterVolume ?? base.monsterVolume))),
      muted: Boolean(parsed.muted ?? base.muted),
    };
  } catch {
    return base;
  }
}

export function saveAudioSettings(audio: AudioSettings): void {
  try {
    localStorage.setItem(AUDIO_STORAGE_KEY, JSON.stringify(audio));
  } catch {
    // Ignore storage errors
  }
}

export function loadGraphicsSettings(): GraphicsSettings | null {
  try {
    const raw = localStorage.getItem(GRAPHICS_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<GraphicsSettings>;
    const base = getPresetGraphicsSettings(parsed.preset ?? 'medium');
    return {
      ...base,
      ...parsed,
      drawDistance: Math.min(4, Math.max(2, Number(parsed.drawDistance ?? base.drawDistance))),
      viewDistanceMeters: Math.min(120, Math.max(45, Number(parsed.viewDistanceMeters ?? base.viewDistanceMeters))),
      foliageDensity: Math.min(1, Math.max(0.2, Number(parsed.foliageDensity ?? base.foliageDensity))),
      renderScale: Math.min(1.25, Math.max(0.5, Number(parsed.renderScale ?? base.renderScale))),
      maxFps: parsed.maxFps === 30 ? 30 : 60,
    };
  } catch {
    return null;
  }
}

export function saveGraphicsSettings(settings: GraphicsSettings): void {
  try {
    localStorage.setItem(GRAPHICS_STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // Ignore quota errors cleanly
  }
}

export function loadGameSave(): { data: SaveDataV1; isNew: boolean; error?: string } {
  try {
    const raw = localStorage.getItem(SAVE_STORAGE_KEY);
    if (!raw) {
      return { data: createDefaultSave(), isNew: true };
    }
    const parsed = JSON.parse(raw) as Partial<SaveDataV1>;
    if (!parsed || typeof parsed.seed !== 'number' || !parsed.player) {
      return { data: createDefaultSave(), isNew: true, error: 'بيانات الحفظ تالفة، تم إنشاء عالم جديد.' };
    }
    const fallback = createDefaultSave(parsed.seed);
    const starterElements = createStarterElementsProgress();
    const mergedElements: Record<ElementId, ElementProgress> = { ...starterElements };
    if (parsed.player.elements) {
      (Object.keys(starterElements) as ElementId[]).forEach((elId) => {
        if (parsed.player?.elements?.[elId]) {
          mergedElements[elId] = {
            ...starterElements[elId],
            ...parsed.player.elements[elId],
          };
        }
      });
    }

    const equipment = parsed.player.equipment
      ? { ...fallback.player.equipment, ...parsed.player.equipment }
      : fallback.player.equipment;
    const level = typeof parsed.player.level === 'number' ? parsed.player.level : 1;
    const computed = computePlayerStats(level, equipment);

    const equippedPair: [ElementId | null, ElementId | null] = Array.isArray(
      parsed.player.equippedElements,
    )
      ? [
          parsed.player.equippedElements[0] ?? 'fire',
          parsed.player.equippedElements[1] === parsed.player.equippedElements[0]
            ? null
            : (parsed.player.equippedElements[1] ?? null),
        ]
      : ['fire', null];

    const mergedQuests = { ...fallback.player.quests, ...(parsed.player.quests ?? {}) };

    const merged: SaveDataV1 = {
      version: 3,
      seed: parsed.seed,
      savedAt: typeof parsed.savedAt === 'number' ? parsed.savedAt : Date.now(),
      playTimeSeconds: typeof parsed.playTimeSeconds === 'number' ? parsed.playTimeSeconds : 0,
      player: {
        ...fallback.player,
        ...parsed.player,
        x: Number.isFinite(parsed.player.x) ? parsed.player.x : 0,
        y: Number.isFinite(parsed.player.y) ? parsed.player.y : 8,
        z: Number.isFinite(parsed.player.z) ? parsed.player.z : 0,
        yaw: Number.isFinite(parsed.player.yaw) ? parsed.player.yaw : 0,
        pitch: Number.isFinite(parsed.player.pitch) ? parsed.player.pitch : -0.18,
        gold: typeof parsed.player.gold === 'number' ? parsed.player.gold : fallback.player.gold,
        elementShards:
          typeof parsed.player.elementShards === 'number'
            ? parsed.player.elementShards
            : fallback.player.elementShards,
        maxHp: computed.maxHp,
        maxMana: computed.maxMana,
        maxStamina: computed.maxStamina,
        hp: Math.min(computed.maxHp, parsed.player.hp ?? computed.maxHp),
        mana: Math.min(computed.maxMana, parsed.player.mana ?? computed.maxMana),
        stamina: Math.min(computed.maxStamina, parsed.player.stamina ?? computed.maxStamina),
        survival: parsed.player.survival
          ? { ...fallback.player.survival, ...parsed.player.survival }
          : fallback.player.survival,
        inventory: Array.isArray(parsed.player.inventory)
          ? parsed.player.inventory
          : fallback.player.inventory,
        equipment,
        elements: mergedElements,
        equippedElements: equippedPair,
        bestiary: parsed.player.bestiary ?? {},
        activeSummonId: parsed.player.activeSummonId ?? null,
        activeSummonIds: Array.isArray(parsed.player.activeSummonIds)
          ? parsed.player.activeSummonIds.slice(0, 3)
          : parsed.player.activeSummonId
            ? [parsed.player.activeSummonId]
            : [],
        summonMasteryLevel:
          typeof parsed.player.summonMasteryLevel === 'number'
            ? Math.max(1, parsed.player.summonMasteryLevel)
            : 1,
        summonMasteryXp:
          typeof parsed.player.summonMasteryXp === 'number'
            ? Math.max(0, parsed.player.summonMasteryXp)
            : 0,
        summonCooldowns: parsed.player.summonCooldowns ?? {},
        skillPoints:
          typeof parsed.player.skillPoints === 'number' ? Math.max(0, parsed.player.skillPoints) : 0,
        skillRanks: parsed.player.skillRanks ?? {},
        unlockedRealms: Array.isArray(parsed.player.unlockedRealms) ? parsed.player.unlockedRealms : [],
        quests: mergedQuests,
        monstersKilled: parsed.player.monstersKilled ?? 0,
        dungeonsCleared: parsed.player.dungeonsCleared ?? 0,
        bossesDefeated: parsed.player.bossesDefeated ?? 0,
      },
      discoveredBiomes: Array.isArray(parsed.discoveredBiomes)
        ? parsed.discoveredBiomes
        : ['emerald_forest'],
      discoveredChunks: Array.isArray(parsed.discoveredChunks)
        ? parsed.discoveredChunks
        : ['0,0'],
      discoveredLocations: Array.isArray(parsed.discoveredLocations)
        ? parsed.discoveredLocations
        : fallback.discoveredLocations,
      mapMarkers: Array.isArray(parsed.mapMarkers) ? parsed.mapMarkers : [],
      harvestedNodes: Array.isArray(parsed.harvestedNodes) ? parsed.harvestedNodes : [],
      clearedDungeons: Array.isArray(parsed.clearedDungeons) ? parsed.clearedDungeons : [],
      graphics: parsed.graphics
        ? { ...fallback.graphics, ...parsed.graphics }
        : fallback.graphics,
      audio: parsed.audio ? { ...getDefaultAudioSettings(), ...parsed.audio } : fallback.audio,
    };
    return { data: merged, isNew: false };
  } catch {
    return { data: createDefaultSave(), isNew: true, error: 'تعذر قراءة ملف الحفظ.' };
  }
}

export function saveGameState(data: SaveDataV1): { ok: boolean; error?: string } {
  try {
    const payload: SaveDataV1 = {
      ...data,
      version: 3,
      savedAt: Date.now(),
    };
    localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(payload));
    saveGraphicsSettings(data.graphics);
    if (data.audio) saveAudioSettings(data.audio);
    return { ok: true };
  } catch {
    return { ok: false, error: 'تعذر الحفظ بسبب امتلاء مساحة التخزين.' };
  }
}

export function resetGameSave(newSeed?: number): SaveDataV1 {
  const fresh = createDefaultSave(newSeed);
  saveGameState(fresh);
  return fresh;
}
