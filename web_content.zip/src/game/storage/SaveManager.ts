/**
 * SPR - Sahil Powerful Run
 * Permanent Save System via LocalStorage
 */

import { GraphicsQualitySetting, deviceTierManager } from '../utils/DeviceTier';

export interface DailyRewardState {
  currentDay: number; // 1 to 7
  lastClaimDate: string | null; // ISO Date String (YYYY-MM-DD)
  claimedToday: boolean;
}

export interface GameSaveData {
  coins: number;
  diamonds: number;
  freeChestProgress: number; // 0 to 10
  level: number;
  xp: number;
  unlockedCharacters: number[];
  selectedCharacterId: number;
  unlockedSkateboards: number[];
  equippedSkateboardId: number | null;
  skateboardStock: Record<number, number>; // Maps boardId (1..15) -> remaining pieces (0..100)
  highScore: number;
  highestDistance: number;
  totalRuns: number;
  dailyReward: DailyRewardState;
  settings: {
    musicEnabled: boolean;
    sfxEnabled: boolean;
    musicVolume: number;
    sfxVolume: number;
    graphicsQuality: GraphicsQualitySetting;
    gameIconButtons: boolean;
  };
}

const STORAGE_KEY = 'SPR_SAHIL_POWERFUL_RUN_SAVE_DATA_V1';

const INITIAL_SKATEBOARD_STOCK: Record<number, number> = {
  1: 100, 2: 100, 3: 100, 4: 100, 5: 100,
  6: 100, 7: 100, 8: 100, 9: 100, 10: 100,
  11: 100, 12: 100, 13: 100, 14: 100, 15: 100,
};

const DEFAULT_SAVE: GameSaveData = {
  coins: 500, // starting gift coins
  diamonds: 15, // starting gift diamonds
  freeChestProgress: 0,
  level: 1,
  xp: 35,
  unlockedCharacters: [1], // Player 1 is FREE (unlocked by default)
  selectedCharacterId: 1,
  unlockedSkateboards: [1, 6], // Skateboard 1 (FIRE BLAZE) and Skateboard 6 (WOODEN CLASSIC) are FREE & Unlocked by default!
  equippedSkateboardId: 1,
  skateboardStock: { ...INITIAL_SKATEBOARD_STOCK },
  highScore: 0,
  highestDistance: 0,
  totalRuns: 0,
  dailyReward: {
    currentDay: 1,
    lastClaimDate: null,
    claimedToday: false,
  },
  settings: {
    musicEnabled: true,
    sfxEnabled: true,
    musicVolume: 0.7,
    sfxVolume: 0.8,
    graphicsQuality: 'auto',
    gameIconButtons: false, // DEFAULT: OFF
  },
};

export const DAILY_REWARDS_TABLE = [
  { day: 1, coins: 500, label: '500 Coins' },
  { day: 2, coins: 1000, label: '1,000 Coins' },
  { day: 3, coins: 2000, label: '2,000 Coins' },
  { day: 4, coins: 3500, label: '3,500 Coins' },
  { day: 5, coins: 5000, label: '5,000 Coins' },
  { day: 6, coins: 8000, label: '8,000 Coins' },
  { day: 7, coins: 15000, label: 'JACKPOT 15,000 Coins!' },
];

export class SaveManager {
  private data: GameSaveData;

  constructor() {
    this.data = this.load();
    if (this.data.settings?.graphicsQuality) {
      deviceTierManager.setSetting(this.data.settings.graphicsQuality);
    }
    this.checkDailyRewardStatus();
  }

  public getSaveData(): GameSaveData {
    return { ...this.data };
  }

  private load(): GameSaveData {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        const unlockedSkateboards: number[] = Array.isArray(parsed.unlockedSkateboards)
          ? parsed.unlockedSkateboards
          : [];
        // Skateboard 1 (FIRE BLAZE) and 6 (WOODEN CLASSIC) are ALWAYS unlocked by default
        if (!unlockedSkateboards.includes(1)) {
          unlockedSkateboards.unshift(1);
        }
        if (!unlockedSkateboards.includes(6)) {
          unlockedSkateboards.push(6);
        }

        // Restore stock or initialize to 100 for each of the 15 boards
        const skateboardStock: Record<number, number> = { ...INITIAL_SKATEBOARD_STOCK };
        if (parsed.skateboardStock && typeof parsed.skateboardStock === 'object') {
          for (let i = 1; i <= 15; i++) {
            if (typeof parsed.skateboardStock[i] === 'number') {
              skateboardStock[i] = Math.max(0, Math.min(100, Math.floor(parsed.skateboardStock[i])));
            }
          }
        }

        // Equipped board must be an unlocked board (defaults to 1)
        let equippedSkateboardId: number = 1;
        if (typeof parsed.equippedSkateboardId === 'number' && unlockedSkateboards.includes(parsed.equippedSkateboardId)) {
          equippedSkateboardId = parsed.equippedSkateboardId;
        } else if (unlockedSkateboards.length > 0) {
          equippedSkateboardId = unlockedSkateboards[0];
        }

        const diamonds = typeof parsed.diamonds === 'number' ? parsed.diamonds : DEFAULT_SAVE.diamonds;
        const freeChestProgress = typeof parsed.freeChestProgress === 'number' ? parsed.freeChestProgress : 0;
        const level = typeof parsed.level === 'number' ? parsed.level : 1;
        const xp = typeof parsed.xp === 'number' ? parsed.xp : 35;

        return {
          ...DEFAULT_SAVE,
          ...parsed,
          diamonds,
          freeChestProgress,
          level,
          xp,
          unlockedSkateboards,
          equippedSkateboardId,
          skateboardStock,
          dailyReward: {
            ...DEFAULT_SAVE.dailyReward,
            ...(parsed.dailyReward || {}),
          },
          settings: {
            ...DEFAULT_SAVE.settings,
            ...(parsed.settings || {}),
          },
        };
      }
    } catch {
      // Fallback
    }
    return JSON.parse(JSON.stringify(DEFAULT_SAVE));
  }

  public save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
    } catch (e) {
      console.error('Failed to save game data', e);
    }
  }

  public getCoins(): number {
    return this.data.coins;
  }

  public addCoins(amount: number): number {
    this.data.coins += Math.max(0, amount);
    this.save();
    return this.data.coins;
  }

  public spendCoins(amount: number): boolean {
    if (this.data.coins >= amount) {
      this.data.coins -= amount;
      this.save();
      return true;
    }
    return false;
  }

  public getDiamonds(): number {
    return this.data.diamonds ?? 0;
  }

  public addDiamonds(amount: number): number {
    this.data.diamonds = (this.data.diamonds ?? 0) + Math.max(0, amount);
    this.save();
    return this.data.diamonds;
  }

  public spendDiamonds(amount: number): boolean {
    if ((this.data.diamonds ?? 0) >= amount) {
      this.data.diamonds -= amount;
      this.save();
      return true;
    }
    return false;
  }

  public getPlayerLevel(): { level: number; xp: number; maxExp: number } {
    return {
      level: this.data.level ?? 1,
      xp: this.data.xp ?? 35,
      maxExp: 100,
    };
  }

  public getChestProgress(): { progress: number; max: number; canClaim: boolean } {
    const progress = this.data.freeChestProgress ?? 0;
    return {
      progress,
      max: 10,
      canClaim: progress >= 10,
    };
  }

  public incrementChestProgress(amount: number = 1): number {
    this.data.freeChestProgress = Math.min(10, (this.data.freeChestProgress ?? 0) + amount);
    this.save();
    return this.data.freeChestProgress;
  }

  public claimFreeChest(): { coins: number; diamonds: number } | null {
    if ((this.data.freeChestProgress ?? 0) >= 10) {
      const coins = Math.floor(500 + Math.random() * 500);
      const diamonds = Math.floor(2 + Math.random() * 4);
      this.addCoins(coins);
      this.addDiamonds(diamonds);
      this.data.freeChestProgress = 0;
      this.save();
      return { coins, diamonds };
    }
    return null;
  }

  public isCharacterUnlocked(charId: number): boolean {
    return this.data.unlockedCharacters.includes(charId);
  }

  public unlockCharacter(charId: number): boolean {
    if (!this.data.unlockedCharacters.includes(charId)) {
      this.data.unlockedCharacters.push(charId);
      this.save();
      return true;
    }
    return false;
  }

  public getSelectedCharacterId(): number {
    return this.data.selectedCharacterId;
  }

  public setSelectedCharacterId(charId: number) {
    if (this.isCharacterUnlocked(charId)) {
      this.data.selectedCharacterId = charId;
      this.save();
    }
  }

  // --- SKATEBOARD SYSTEM PERSISTENCE (Stock of 100 per board, ₹100, offline) ---
  public getUnlockedSkateboards(): number[] {
    const list = new Set(this.data.unlockedSkateboards || [1, 6]);
    list.add(1);
    list.add(6);
    return Array.from(list);
  }

  public isSkateboardUnlocked(boardId: number): boolean {
    if (boardId === 1 || boardId === 6) return true;
    return this.data.unlockedSkateboards.includes(boardId);
  }

  public getSkateboardStock(boardId: number): number {
    if (this.data.skateboardStock && typeof this.data.skateboardStock[boardId] === 'number') {
      return this.data.skateboardStock[boardId];
    }
    return 100;
  }

  public buySkateboard(boardId: number, price: number = 100): { success: boolean; reason?: string } {
    const stock = this.getSkateboardStock(boardId);
    if (stock <= 0) {
      return { success: false, reason: 'Out of stock! 100 pieces sold out.' };
    }
    if (this.data.coins < price) {
      return { success: false, reason: `Need ₹${price - this.data.coins} more coins!` };
    }

    // Deduct coins
    this.data.coins -= price;

    // Decrement stock by 1 piece
    if (!this.data.skateboardStock) {
      this.data.skateboardStock = { ...INITIAL_SKATEBOARD_STOCK };
    }
    this.data.skateboardStock[boardId] = Math.max(0, stock - 1);

    // Unlock board
    if (!this.data.unlockedSkateboards.includes(boardId)) {
      this.data.unlockedSkateboards.push(boardId);
    }
    // Auto-equip purchased board
    this.data.equippedSkateboardId = boardId;

    this.save();
    return { success: true };
  }

  public unlockSkateboard(boardId: number): boolean {
    if (!this.data.unlockedSkateboards.includes(boardId)) {
      this.data.unlockedSkateboards.push(boardId);
      this.save();
      return true;
    }
    return false;
  }

  public getEquippedSkateboardId(): number | null {
    if (this.data.equippedSkateboardId && this.isSkateboardUnlocked(this.data.equippedSkateboardId)) {
      return this.data.equippedSkateboardId;
    }
    if (this.data.unlockedSkateboards.length > 0) {
      return this.data.unlockedSkateboards[0];
    }
    return null;
  }

  public setEquippedSkateboardId(boardId: number): boolean {
    if (this.isSkateboardUnlocked(boardId)) {
      this.data.equippedSkateboardId = boardId;
      this.save();
      return true;
    }
    return false;
  }

  public updateRunStats(score: number, distance: number, coinsEarned: number) {
    this.data.totalRuns += 1;
    this.addCoins(coinsEarned);
    if (score > this.data.highScore) {
      this.data.highScore = Math.floor(score);
    }
    if (distance > this.data.highestDistance) {
      this.data.highestDistance = Math.floor(distance);
    }
    this.save();
  }

  public updateSettings(newSettings: Partial<GameSaveData['settings']>) {
    this.data.settings = { ...this.data.settings, ...newSettings };
    if (newSettings.graphicsQuality) {
      deviceTierManager.setSetting(newSettings.graphicsQuality);
    }
    this.save();
  }

  public getGameIconButtons(): boolean {
    return this.data.settings?.gameIconButtons ?? false;
  }

  public setGameIconButtons(enabled: boolean) {
    if (!this.data.settings) {
      this.data.settings = { ...DEFAULT_SAVE.settings };
    }
    this.data.settings.gameIconButtons = enabled;
    this.save();
  }

  // --- DAILY REWARD SYSTEM ---
  private checkDailyRewardStatus() {
    const todayStr = new Date().toISOString().split('T')[0];
    const { lastClaimDate } = this.data.dailyReward;

    if (!lastClaimDate) {
      // Never claimed
      this.data.dailyReward.claimedToday = false;
      this.data.dailyReward.currentDay = 1;
    } else if (lastClaimDate === todayStr) {
      // Already claimed today
      this.data.dailyReward.claimedToday = true;
    } else {
      // Check if it was yesterday (streak continuation) or older (reset)
      const lastDate = new Date(lastClaimDate);
      const today = new Date(todayStr);
      const diffDays = Math.floor((today.getTime() - lastDate.getTime()) / (1000 * 3600 * 24));

      if (diffDays === 1) {
        // Consecutive day
        let nextDay = this.data.dailyReward.currentDay + 1;
        if (nextDay > 7) nextDay = 1;
        this.data.dailyReward.currentDay = nextDay;
        this.data.dailyReward.claimedToday = false;
      } else if (diffDays > 1) {
        // Streak broken, reset to Day 1
        this.data.dailyReward.currentDay = 1;
        this.data.dailyReward.claimedToday = false;
      }
    }
    this.save();
  }

  public claimDailyReward(): { success: boolean; coins: number; day: number } {
    this.checkDailyRewardStatus();
    if (this.data.dailyReward.claimedToday) {
      return { success: false, coins: 0, day: this.data.dailyReward.currentDay };
    }

    const todayStr = new Date().toISOString().split('T')[0];
    const currentDay = this.data.dailyReward.currentDay;
    const rewardItem = DAILY_REWARDS_TABLE[currentDay - 1];
    const coinsReward = rewardItem ? rewardItem.coins : 500;

    this.data.coins += coinsReward;
    this.data.dailyReward.lastClaimDate = todayStr;
    this.data.dailyReward.claimedToday = true;
    this.save();

    return { success: true, coins: coinsReward, day: currentDay };
  }
}

export const saveManager = new SaveManager();
