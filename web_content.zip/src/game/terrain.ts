// ============================================================
// DEEP DIG — chunked deformable terrain (terrain engineer)
// Heightfield split into chunks. Digging modifies heights locally,
// slumps sand to its angle of repose, and rebuilds only affected chunks.
// Vertex colours encode the underground layer at each point.
// ============================================================
import * as THREE from "three";
import { LAYERS, LAYER_ENDS, MAX_DEPTH, layerAtDepth, layerStart, type LocationDef } from "./data";

export const N = 200; // cells per side
export const CELL = 0.3;
export const HALF = (N * CELL) / 2; // 30 m
export const CH = 25; // cells per chunk
export const NC = N / CH;
export const V = N + 1;

export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smoothstep = (a: number, b: number, x: number) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hash2(ix: number, iz: number, seed: number) {
  let h = (Math.imul(ix, 374761393) + Math.imul(iz, 668265263) + Math.imul(seed, 982451653)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967295;
}
export function vnoise(x: number, z: number, seed = 0) {
  const ix = Math.floor(x), iz = Math.floor(z);
  const fx = x - ix, fz = z - iz;
  const u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz);
  const a = hash2(ix, iz, seed), b = hash2(ix + 1, iz, seed), c = hash2(ix, iz + 1, seed), d = hash2(ix + 1, iz + 1, seed);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}
export function fbm(x: number, z: number, oct = 4, seed = 0) {
  let s = 0, a = 0.5, f = 1, n = 0;
  for (let i = 0; i < oct; i++) {
    s += (vnoise(x * f, z * f, seed + i * 17) * 2 - 1) * a;
    n += a;
    a *= 0.5;
    f *= 2.03;
  }
  return s / n;
}

// ---------------- Natural height per location ----------------
function rawHeight(loc: LocationDef, x: number, z: number, seed: number): number {
  const r = Math.hypot(x, z);
  const edge = Math.max(Math.abs(x), Math.abs(z));
  let h = 0;
  switch (loc.id) {
    case "beach": {
      const t = smoothstep(2, 26, z);
      const back = clamp((-z - 8) / 22, 0, 1);
      h = 0.95 - t * 2.4 + back * back * 2.2;
      h += fbm(x * 0.07 + 3, z * 0.07, 4, seed) * 1.1 * (1 - t);
      h += Math.sin(x * 0.5 + fbm(x * 0.1, z * 0.1, 2, seed) * 6) * 0.025 * (1 - t);
      const e = Math.max(Math.abs(x), -z);
      h = lerp(h, loc.farY, smoothstep(24, 30, e));
      break;
    }
    case "desert": {
      const n = fbm(x * 0.045 + 10, z * 0.045, 4, seed);
      const ridge = 1 - Math.abs(fbm(x * 0.03 - 5, z * 0.03 + 8, 3, seed + 5));
      h = 0.2 + n * 2.6 + ridge * ridge * 1.0 - 0.7;
      h += Math.sin((x * 0.8 + z * 0.35 + n * 5) * 2.2) * 0.035;
      h = lerp(h, loc.farY, smoothstep(24, 30, edge));
      break;
    }
    case "tropical": {
      const s = smoothstep(14, 27, r);
      h = 1.1 - s * 2.6 + fbm(x * 0.08, z * 0.08, 4, seed) * 0.8 * (1 - smoothstep(10, 26, r));
      h += Math.sin(x * 0.45 + z * 0.2) * 0.02 * (1 - s);
      break;
    }
    case "dig": {
      h = 0.3 + fbm(x * 0.05, z * 0.05, 4, seed) * 0.9;
      h += Math.floor((fbm(x * 0.04 + 9, z * 0.04, 2, seed) + 1) * 2.2) * 0.12;
      h += 0.9 * Math.exp(-((x - 5) * (x - 5) + (z + 9) * (z + 9)) / 14);
      h += 0.7 * Math.exp(-((x + 8) * (x + 8) + (z - 6) * (z - 6)) / 10);
      h = lerp(h, loc.farY, smoothstep(24, 30, edge));
      break;
    }
    case "crystal": {
      h = 0.4 + fbm(x * 0.06, z * 0.06, 4, seed) * 1.3 + smoothstep(12, 26, r) * 3.2;
      h += Math.sin(x * 0.6 + z * 0.4) * 0.02;
      h = lerp(h, loc.farY, smoothstep(24, 30, edge));
      break;
    }
  }
  return h;
}
export function naturalHeight(loc: LocationDef, x: number, z: number, seed: number): number {
  let h = rawHeight(loc, x, z, seed);
  const sx = loc.station.x, sz = loc.station.z;
  const d = Math.hypot(x - sx, z - sz);
  if (d < 9) {
    const hs = rawHeight(loc, sx, sz, seed);
    h = lerp(h, hs, 1 - smoothstep(5, 9, d));
  }
  return h;
}

// ---------------- Sand texture ----------------
export function makeSandTexture(): THREE.CanvasTexture {
  const size = 256;
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const g = c.getContext("2d")!;
  const img = g.createImageData(size, size);
  const rnd = mulberry32(1234);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const blot = vnoise(x * 0.04, y * 0.04, 3) * 0.12 + vnoise(x * 0.15, y * 0.15, 9) * 0.07;
      let v = 0.9 + blot * 0.5 + (rnd() - 0.5) * 0.12;
      if (rnd() < 0.015) v -= 0.22;
      if (rnd() < 0.01) v += 0.1;
      v = clamp(v, 0, 1);
      const k = (y * size + x) * 4;
      img.data[k] = img.data[k + 1] = img.data[k + 2] = v * 255;
      img.data[k + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}

function hexRGB(hex: string): [number, number, number] {
  const c = new THREE.Color(hex);
  return [c.r, c.g, c.b];
}

export class Terrain {
  loc: LocationDef;
  seed: number;
  h = new Float32Array(V * V);
  orig = new Float32Array(V * V);
  surf = new Float32Array(V * V * 3);
  group = new THREE.Group();
  chunks: THREE.Mesh[] = [];
  chunkGeo: THREE.BufferGeometry[] = [];
  dirty = new Set<number>();
  layerRGB: [number, number, number][];
  material: THREE.Material;

  constructor(loc: LocationDef, seed: number, material: THREE.Material) {
    this.loc = loc;
    this.seed = seed;
    this.material = material;
    this.layerRGB = loc.layerColors.map(hexRGB);
    const sa = hexRGB(loc.surface[0]);
    const sb = hexRGB(loc.surface[1]);
    for (let j = 0; j < V; j++) {
      for (let i = 0; i < V; i++) {
        const x = i * CELL - HALF, z = j * CELL - HALF;
        const k = j * V + i;
        const hh = naturalHeight(loc, x, z, seed);
        this.orig[k] = this.h[k] = hh;
        const m = clamp(vnoise(x * 0.35, z * 0.35, 7) * 0.7 + vnoise(x * 1.7, z * 1.7, 5) * 0.3, 0, 1);
        const grain = 0.94 + Math.random() * 0.1;
        let wet = 0;
        if (loc.water) wet = 1 - smoothstep(loc.water.level + 0.05, loc.water.level + 0.95, hh);
        // dune ridge shading variance for macro-detail
        const macro = 0.93 + 0.1 * vnoise(x * 0.1, z * 0.1, 21);
        const dk = (1 - 0.38 * wet) * grain * macro;
        this.surf[k * 3] = lerp(sa[0], sb[0], m) * dk;
        this.surf[k * 3 + 1] = lerp(sa[1], sb[1], m) * dk * (1 - 0.02 * wet);
        this.surf[k * 3 + 2] = lerp(sa[2], sb[2], m) * dk * (1 + 0.04 * wet);
      }
    }
    this.buildChunks();
  }

  // shared index buffer
  private static idx: THREE.BufferAttribute | null = null;
  private static getIndex() {
    if (Terrain.idx) return Terrain.idx;
    const arr = new Uint16Array(CH * CH * 6);
    let p = 0;
    for (let z = 0; z < CH; z++)
      for (let x = 0; x < CH; x++) {
        const a = z * (CH + 1) + x, b = a + 1, c = a + CH + 1, d = c + 1;
        arr[p++] = a; arr[p++] = c; arr[p++] = b;
        arr[p++] = b; arr[p++] = c; arr[p++] = d;
      }
    Terrain.idx = new THREE.BufferAttribute(arr, 1);
    return Terrain.idx;
  }

  private buildChunks() {
    const vc = (CH + 1) * (CH + 1);
    for (let cz = 0; cz < NC; cz++) {
      for (let cx = 0; cx < NC; cx++) {
        const geo = new THREE.BufferGeometry();
        const pos = new Float32Array(vc * 3);
        const nor = new Float32Array(vc * 3);
        const col = new Float32Array(vc * 3);
        const uv = new Float32Array(vc * 2);
        for (let lz = 0; lz <= CH; lz++)
          for (let lx = 0; lx <= CH; lx++) {
            const gi = cx * CH + lx, gj = cz * CH + lz;
            const o = lz * (CH + 1) + lx;
            const x = gi * CELL - HALF, z = gj * CELL - HALF;
            pos[o * 3] = x;
            pos[o * 3 + 2] = z;
            uv[o * 2] = x * 0.9;
            uv[o * 2 + 1] = z * 0.9;
          }
        const pa = new THREE.BufferAttribute(pos, 3);
        pa.setUsage(THREE.DynamicDrawUsage);
        const na = new THREE.BufferAttribute(nor, 3);
        na.setUsage(THREE.DynamicDrawUsage);
        const ca = new THREE.BufferAttribute(col, 3);
        ca.setUsage(THREE.DynamicDrawUsage);
        geo.setAttribute("position", pa);
        geo.setAttribute("normal", na);
        geo.setAttribute("color", ca);
        geo.setAttribute("uv", new THREE.BufferAttribute(uv, 2));
        geo.setIndex(Terrain.getIndex());
        const cxw = (cx * CH + CH / 2) * CELL - HALF, czw = (cz * CH + CH / 2) * CELL - HALF;
        geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(cxw, 0, czw), 9);
        geo.boundingBox = new THREE.Box3(new THREE.Vector3(cxw - 4, -8, czw - 4), new THREE.Vector3(cxw + 4, 8, czw + 4));
        const mesh = new THREE.Mesh(geo, this.material);
        mesh.receiveShadow = true;
        mesh.castShadow = true;
        mesh.matrixAutoUpdate = false;
        this.group.add(mesh);
        this.chunks.push(mesh);
        this.chunkGeo.push(geo);
        this.updateChunk(cz * NC + cx);
      }
    }
  }

  private colorInto(k: number, x: number, z: number, out: Float32Array, o: number) {
    const hh = this.h[k];
    const depth = this.orig[k] - hh;
    if (depth < 0.02) {
      out[o] = this.surf[k * 3];
      out[o + 1] = this.surf[k * 3 + 1];
      out[o + 2] = this.surf[k * 3 + 2];
      return;
    }
    const li = layerAtDepth(depth);
    const start = layerStart(li), end = LAYER_ENDS[li];
    let [r, g, b] = this.layerRGB[li];
    const bz = 0.1;
    if (li > 0 && depth - start < bz) {
      const t = (bz - (depth - start)) / (2 * bz);
      const p = this.layerRGB[li - 1];
      r = lerp(r, p[0], t); g = lerp(g, p[1], t); b = lerp(b, p[2], t);
    } else if (li < LAYERS.length - 1 && end - depth < bz) {
      const t = (bz - (end - depth)) / (2 * bz);
      const p = this.layerRGB[li + 1];
      r = lerp(r, p[0], t); g = lerp(g, p[1], t); b = lerp(b, p[2], t);
    }
    const band = 1 + 0.08 * Math.sin(hh * 31 + vnoise(x * 1.8, z * 1.8, 4) * 7) + (vnoise(x * 5, z * 5, 8) - 0.5) * 0.1;
    const s = smoothstep(0, 0.14, depth);
    out[o] = lerp(this.surf[k * 3], r * band, s);
    out[o + 1] = lerp(this.surf[k * 3 + 1], g * band, s);
    out[o + 2] = lerp(this.surf[k * 3 + 2], b * band, s);
  }

  updateChunk(ci: number) {
    const cx = ci % NC, cz = (ci / NC) | 0;
    const geo = this.chunkGeo[ci];
    const pos = geo.attributes.position as THREE.BufferAttribute;
    const nor = geo.attributes.normal as THREE.BufferAttribute;
    const col = geo.attributes.color as THREE.BufferAttribute;
    const h = this.h;
    for (let lz = 0; lz <= CH; lz++)
      for (let lx = 0; lx <= CH; lx++) {
        const gi = cx * CH + lx, gj = cz * CH + lz;
        const k = gj * V + gi;
        const o = lz * (CH + 1) + lx;
        const hl = h[gj * V + Math.max(gi - 1, 0)], hr = h[gj * V + Math.min(gi + 1, N)];
        const hd = h[Math.max(gj - 1, 0) * V + gi], hu = h[Math.min(gj + 1, N) * V + gi];
        let nx = (hl - hr) / (2 * CELL), nz = (hd - hu) / (2 * CELL);
        const il = 1 / Math.sqrt(nx * nx + 1 + nz * nz);
        nx *= il; nz *= il;
        (pos.array as Float32Array)[o * 3 + 1] = h[k];
        (nor.array as Float32Array)[o * 3] = nx;
        (nor.array as Float32Array)[o * 3 + 1] = il;
        (nor.array as Float32Array)[o * 3 + 2] = nz;
        this.colorInto(k, gi * CELL - HALF, gj * CELL - HALF, col.array as Float32Array, o * 3);
      }
    pos.needsUpdate = true;
    nor.needsUpdate = true;
    col.needsUpdate = true;
  }

  flush() {
    if (this.dirty.size === 0) return;
    this.dirty.forEach((ci) => this.updateChunk(ci));
    this.dirty.clear();
  }
  private markRegion(i0: number, i1: number, j0: number, j1: number) {
    const c0 = clamp(Math.floor((i0 - 1) / CH), 0, NC - 1), c1 = clamp(Math.floor((i1 + 1) / CH), 0, NC - 1);
    const d0 = clamp(Math.floor((j0 - 1) / CH), 0, NC - 1), d1 = clamp(Math.floor((j1 + 1) / CH), 0, NC - 1);
    for (let cz = d0; cz <= d1; cz++) for (let cx = c0; cx <= c1; cx++) this.dirty.add(cz * NC + cx);
  }

  // ---------- sampling ----------
  private sample(arr: Float32Array, x: number, z: number) {
    const fx = clamp((x + HALF) / CELL, 0, N - 0.0001), fz = clamp((z + HALF) / CELL, 0, N - 0.0001);
    const i = Math.floor(fx), j = Math.floor(fz);
    const tx = fx - i, tz = fz - j;
    const k = j * V + i;
    return lerp(lerp(arr[k], arr[k + 1], tx), lerp(arr[k + V], arr[k + V + 1], tx), tz);
  }
  heightAt(x: number, z: number) {
    return this.sample(this.h, x, z);
  }
  origAt(x: number, z: number) {
    return this.sample(this.orig, x, z);
  }
  depthAt(x: number, z: number) {
    return Math.max(0, this.origAt(x, z) - this.heightAt(x, z));
  }

  // ---------- digging ----------
  /** Removes sand around (cx,cz). Returns removed volume (m³), centre layer index and depth after dig. */
  dig(cx: number, cz: number, radius: number, amount: number, power: number) {
    const i0 = Math.floor((cx - radius * 1.9 + HALF) / CELL) - 1, i1 = Math.ceil((cx + radius * 1.9 + HALF) / CELL) + 1;
    const j0 = Math.floor((cz - radius * 1.9 + HALF) / CELL) - 1, j1 = Math.ceil((cz + radius * 1.9 + HALF) / CELL) + 1;
    const h = this.h, orig = this.orig;
    const centerDepthBefore = this.depthAt(cx, cz);
    const layer = layerAtDepth(centerDepthBefore);
    let vol = 0;
    // pass 1: removal
    for (let j = Math.max(j0, 0); j <= Math.min(j1, N); j++)
      for (let i = Math.max(i0, 0); i <= Math.min(i1, N); i++) {
        const x = i * CELL - HALF, z = j * CELL - HALF;
        const d = Math.hypot(x - cx, z - cz);
        if (d >= radius) continue;
        let w = 1 - (d / radius) * (d / radius);
        w *= w;
        const k = j * V + i;
        const li = layerAtDepth(Math.max(0, orig[k] - h[k]));
        const rm = (amount * w * power) / LAYERS[li].resistance;
        const nh = Math.max(h[k] - rm, orig[k] - MAX_DEPTH);
        vol += (h[k] - nh) * CELL * CELL;
        h[k] = nh;
      }
    // pass 2: spoil ring displaced around the hole (sand displacement)
    if (vol > 0) {
      let wsum = 0;
      const r0 = radius * 1.05, r1 = radius * 1.9;
      const ring: number[] = [];
      for (let j = Math.max(j0, 0); j <= Math.min(j1, N); j++)
        for (let i = Math.max(i0, 0); i <= Math.min(i1, N); i++) {
          const d = Math.hypot(i * CELL - HALF - cx, j * CELL - HALF - cz);
          if (d < r0 || d > r1) continue;
          const w = Math.sin((Math.PI * (d - r0)) / (r1 - r0));
          ring.push(j * V + i, w);
          wsum += w;
        }
      if (wsum > 0) {
        const per = (vol * 0.28) / (wsum * CELL * CELL);
        for (let q = 0; q < ring.length; q += 2) {
          const k = ring[q];
          h[k] = Math.min(h[k] + per * ring[q + 1], orig[k] + 0.3);
        }
      }
    }
    // slumping to angle of repose
    const m = 8;
    const ri0 = Math.max(i0 - m, 0), ri1 = Math.min(i1 + m, N), rj0 = Math.max(j0 - m, 0), rj1 = Math.min(j1 + m, N);
    this.relax(ri0, ri1, rj0, rj1);
    this.markRegion(ri0, ri1, rj0, rj1);
    return { volume: vol, layer, depth: this.depthAt(cx, cz) };
  }

  private relax(i0: number, i1: number, j0: number, j1: number) {
    const h = this.h, orig = this.orig;
    const nb = [-1, 0, 1, 0, 0, -1, 0, 1, -1, -1, 1, -1, -1, 1, 1, 1];
    for (let pass = 0; pass < 7; pass++) {
      let changed = false;
      for (let j = j0; j <= j1; j++)
        for (let i = i0; i <= i1; i++) {
          const k = j * V + i;
          for (let q = 0; q < 16; q += 2) {
            const ni = i + nb[q], nj = j + nb[q + 1];
            if (ni < 0 || nj < 0 || ni > N || nj > N) continue;
            const nk = nj * V + ni;
            const diff = h[k] - h[nk];
            if (diff <= 0.02) continue;
            const dist = q >= 8 ? CELL * 1.414 : CELL;
            const slope = LAYERS[layerAtDepth(Math.max(0, orig[nk] - h[nk]))].slope;
            const maxd = slope * dist;
            if (diff > maxd) {
              h[k] -= (diff - maxd) * 0.55;
              changed = true;
            }
          }
        }
      if (!changed) break;
    }
  }

  // ---------- persistence ----------
  serialize(): number[] {
    const out: number[] = [];
    let run = 0;
    for (let k = 0; k < V * V; k++) {
      const v = Math.round((this.orig[k] - this.h[k]) * 100);
      if (v === 0) run++;
      else {
        out.push(run, v);
        run = 0;
      }
    }
    return out;
  }
  load(data: number[]) {
    if (!Array.isArray(data) || data.length === 0) return;
    let pos = 0;
    for (let p = 0; p + 1 < data.length; p += 2) {
      pos += data[p];
      if (pos >= V * V) break;
      this.h[pos] = this.orig[pos] - data[p + 1] / 100;
      pos++;
    }
    for (let ci = 0; ci < NC * NC; ci++) this.updateChunk(ci);
  }

  dispose() {
    this.chunkGeo.forEach((g) => g.dispose());
    this.group.removeFromParent();
  }
}
