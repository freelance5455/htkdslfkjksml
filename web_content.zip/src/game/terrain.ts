/**
 * Procedural terrain inspired by the province of Mendoza, Argentina.
 *
 * World layout (x grows eastwards, -z is north):
 *   x > +300      irrigated plains with a meandering river and green "fincas" (vineyards)
 *   +300 … -900   dry pre-cordillera: ochre and red hills
 *   x < -900      high Andes: ridged peaks that carry snow above ~750 m
 *
 * One pure height function drives both the visible mesh and the collision tests, so what the
 * player sees is exactly what they can crash into. Everything is deterministic (no Math.random).
 */

export const WATER_LEVEL = 5

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v)
const lerp = (a: number, b: number, t: number) => a + (b - a) * t
/** 0 at `a`, 1 at `b` (works with a > b too). */
export function smoothstep(a: number, b: number, v: number): number {
  const t = clamp01((v - a) / (b - a))
  return t * t * (3 - 2 * t)
}

// ─── noise ────────────────────────────────────────────────────────────────
function hash(ix: number, iz: number, seed: number): number {
  let h = Math.imul(ix, 374761393) ^ Math.imul(iz, 668265263) ^ Math.imul(seed, 2147483647)
  h = Math.imul(h ^ (h >>> 13), 1274126177)
  h ^= h >>> 16
  return (h >>> 0) / 4294967295
}

/** Smooth value noise in [-1, 1]. */
function noise(x: number, z: number, seed: number): number {
  const ix = Math.floor(x)
  const iz = Math.floor(z)
  const fx = x - ix
  const fz = z - iz
  const ux = fx * fx * fx * (fx * (fx * 6 - 15) + 10)
  const uz = fz * fz * fz * (fz * (fz * 6 - 15) + 10)
  const a = hash(ix, iz, seed)
  const b = hash(ix + 1, iz, seed)
  const c = hash(ix, iz + 1, seed)
  const d = hash(ix + 1, iz + 1, seed)
  return lerp(lerp(a, b, ux), lerp(c, d, ux), uz) * 2 - 1
}

function fbm(x: number, z: number, octaves: number, seed: number): number {
  let sum = 0
  let amp = 0.5
  let freq = 1
  let norm = 0
  for (let i = 0; i < octaves; i += 1) {
    sum += noise(x * freq, z * freq, seed + i * 17) * amp
    norm += amp
    amp *= 0.5
    freq *= 2.03
  }
  return sum / norm
}

/** Ridged multifractal in [0, 1]: sharp crests with valleys between them. */
function ridged(x: number, z: number, octaves: number, seed: number): number {
  let sum = 0
  let amp = 0.5
  let freq = 1
  let norm = 0
  let weight = 1
  for (let i = 0; i < octaves; i += 1) {
    let n = 1 - Math.abs(noise(x * freq, z * freq, seed + i * 31))
    n *= n
    n *= weight
    weight = clamp01(n * 1.6)
    sum += n * amp
    norm += amp
    amp *= 0.5
    freq *= 2.1
  }
  return sum / norm
}

// ─── geography ────────────────────────────────────────────────────────────
/** X coordinate of the river centre line at a given z. */
export function riverX(z: number): number {
  return 700 + 230 * Math.sin(z * 0.0013) + 90 * Math.sin(z * 0.0041 + 1.3)
}

/** 0..1 irrigated-land mask: strongest near the river. */
export function oasis(x: number, z: number): number {
  const d = Math.abs(x - riverX(z))
  return Math.exp(-((d / 520) ** 2)) * smoothstep(-300, 300, x)
}

export function terrainHeight(x: number, z: number): number {
  // Domain warp bends the ridges so valleys wind like real quebradas.
  const wx = x + fbm(x * 0.0007, z * 0.0007, 3, 5) * 380
  const wz = z + fbm(x * 0.0007 + 40, z * 0.0007 + 40, 3, 9) * 380

  const mountains = smoothstep(-700, -3000, x)
  const foothills = smoothstep(500, -900, x)

  const plain = 16 + fbm(x * 0.0016, z * 0.0016, 4, 2) * 14
  const hills = (ridged(wx * 0.0014, wz * 0.0014, 4, 11) * 0.8 + 0.2 * (fbm(x * 0.004, z * 0.004, 3, 3) * 0.5 + 0.5)) * 420
  const peaks = ridged(wx * 0.00058, wz * 0.00058, 5, 21)
  const high = (Math.pow(peaks, 1.35) * 1280 + fbm(wx * 0.0021, wz * 0.0021, 4, 7) * 90) * mountains

  let h = plain + hills * foothills * (1 - mountains * 0.35) + high
  // Small-scale roughness that grows with altitude.
  h += fbm(x * 0.012, z * 0.012, 3, 13) * (4 + Math.min(h, 900) * 0.035)

  // River valley: smooth channel dug below the water level.
  const d = Math.abs(x - riverX(z))
  const valley = Math.exp(-((d / 230) ** 2))
  h = lerp(h, plain * 0.55, valley * 0.55 * smoothstep(-200, 500, x))
  const channel = Math.exp(-((d / 62) ** 2)) * smoothstep(-300, 500, x)
  h = lerp(h, WATER_LEVEL - 3.5, channel * 0.97)
  return h
}

/** Height of the surface a plane can hit: terrain or the water above the river bed. */
export function groundHeight(x: number, z: number): number {
  const h = terrainHeight(x, z)
  return h > WATER_LEVEL ? h : WATER_LEVEL
}

/** Unit surface normal by central differences. */
export function terrainNormal(x: number, z: number, out: { x: number; y: number; z: number }, step = 6): void {
  const hl = groundHeight(x - step, z)
  const hr = groundHeight(x + step, z)
  const hd = groundHeight(x, z - step)
  const hu = groundHeight(x, z + step)
  const nx = hl - hr
  const nz = hd - hu
  const ny = 2 * step
  const len = Math.hypot(nx, ny, nz)
  out.x = nx / len
  out.y = ny / len
  out.z = nz / len
}

// ─── colour ───────────────────────────────────────────────────────────────
type RGB = [number, number, number]
const hex = (c: number): RGB => [((c >> 16) & 255) / 255, ((c >> 8) & 255) / 255, (c & 255) / 255]
const mix = (a: RGB, b: RGB, t: number): RGB => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)]

const C = {
  riverBed: hex(0x6d6a52),
  sand: hex(0xc9b27c),
  scrub: hex(0xa9915a),
  dryGrass: hex(0xb8a468),
  vine: hex(0x5f8a35),
  vineDark: hex(0x3f6a2a),
  poplar: hex(0x2f5a28),
  ochre: hex(0xc08a4e),
  redRock: hex(0xa1492f),
  umber: hex(0x7d5a3c),
  violet: hex(0x7c5f6a),
  grey: hex(0x8d877f),
  darkRock: hex(0x5c5650),
  snow: hex(0xf2f5fa),
}

/** Vertex colour for a terrain sample. `ny` is the surface normal's vertical component. */
export function terrainColor(x: number, z: number, h: number, ny: number): RGB {
  const slope = 1 - ny
  const grain = fbm(x * 0.02, z * 0.02, 3, 31)
  const band = fbm(h * 0.012 + x * 0.0006, z * 0.0008, 2, 41)
  let c: RGB

  if (h <= WATER_LEVEL + 1.5) {
    c = mix(C.riverBed, C.sand, smoothstep(WATER_LEVEL - 2, WATER_LEVEL + 1.5, h))
  } else if (h < 180) {
    // Plains: irrigated patchwork (fincas) close to the river, desert scrub elsewhere.
    const field = hash(Math.floor(x / 210), Math.floor(z / 260), 77)
    const irrigated = oasis(x, z)
    const farm = mix(C.vineDark, C.vine, field)
    const withPoplars = hash(Math.floor(x / 52), Math.floor(z / 52), 3) > 0.93 ? C.poplar : farm
    const desert = mix(C.scrub, C.dryGrass, grain * 0.5 + 0.5)
    c = mix(desert, withPoplars, smoothstep(0.28, 0.5, irrigated + (field - 0.5) * 0.25))
    c = mix(c, C.ochre, smoothstep(60, 180, h) * 0.8)
  } else if (h < 780) {
    // Pre-cordillera: banded sediments in ochre, red and violet.
    const strata = Math.sin(h * 0.045 + band * 6) * 0.5 + 0.5
    c = mix(C.ochre, C.redRock, strata)
    c = mix(c, C.violet, smoothstep(0.55, 1, band * 0.5 + 0.5) * 0.45)
    c = mix(c, C.umber, smoothstep(0.3, 0.8, grain * 0.5 + 0.5) * 0.35)
  } else {
    c = mix(C.umber, C.grey, smoothstep(780, 980, h))
    c = mix(c, C.darkRock, smoothstep(0.25, 0.6, grain * 0.5 + 0.5) * 0.45)
  }

  if (h > 250) c = mix(c, C.grey, smoothstep(0.28, 0.6, slope) * 0.6)

  // Snow: line wobbles with noise and slides off steep faces.
  const snowLine = 760 + band * 140
  const snow = smoothstep(snowLine, snowLine + 120, h) * (1 - smoothstep(0.34, 0.62, slope))
  if (snow > 0) c = mix(c, C.snow, snow)

  const shade = 0.92 + grain * 0.12
  return [c[0] * shade, c[1] * shade, c[2] * shade]
}
