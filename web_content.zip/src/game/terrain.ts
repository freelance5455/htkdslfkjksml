import { fbm, noise2, ridged, smoothstep, lerp, clamp } from "./noise";
import {
  cliffZ, cliffWidth, MOUNTAINS, ROADS, RIVERS, LAKES, STRUCTS, CAVES, VIEWPOINTS,
  WORLD_HALF, RoadKind,
} from "./worldData";

export interface Sample {
  h: number;
  road: number;
  roadKind: RoadKind;
  water: number; // water surface level or -1e9
  waterDepthE: number; // signed distance to shore (negative = inside)
  sand: number;
  forest: number;
  light: number;
  plateau: number;
  mount: number;
  pad: number;
}

export function newSample(): Sample {
  return { h: 0, road: 0, roadKind: 0, water: -1e9, waterDepthE: 99, sand: 0, forest: 0, light: 0, plateau: 0, mount: 0, pad: 0 };
}

interface Seg {
  ax: number; az: number; bx: number; bz: number; dx: number; dz: number; l2: number;
  w: number; kind: RoadKind; // roads
  hwa: number; hwb: number; la: number; lb: number; // rivers
  ri: number;
}
export interface Pad { x: number; z: number; r: number; h: number }
export interface Bridge {
  x: number; z: number; dx: number; dz: number; half: number; width: number;
  h0: number; h1: number; minH: number; stone: boolean;
}

const CELL = 32;
const GRID = (WORLD_HALF * 2) / CELL;
const roadSegs: Seg[] = [];
const riverSegs: Seg[] = [];
export const pads: Pad[] = [];
export const bridges: Bridge[] = [];
const roadCells: number[][] = [];
const riverCells: number[][] = [];
const lakeCells: number[][] = [];
const padCells: number[][] = [];
const bridgeCells: number[][] = [];

let bM = 0;
let bP = 0;

/** Natural terrain before roads/water carving */
export function baseHeight(x: number, z: number): number {
  let h = fbm(x * 0.0035, z * 0.0035, 4) * 16 + 6 + fbm(x * 0.018 + 11, z * 0.018, 2) * 2.2;
  const cz = cliffZ(x);
  const cw = cliffWidth(x);
  const p = smoothstep(cz + cw * 0.5, cz - cw * 0.5, z);
  h += p * 32;
  let mount = 0;
  for (let i = 0; i < MOUNTAINS.length; i++) {
    const m = MOUNTAINS[i];
    const dx = x - m.x;
    const dz = z - m.z;
    const d2 = dx * dx + dz * dz;
    if (d2 < m.r * m.r) {
      const t = Math.sqrt(d2) / m.r;
      const f = 1 - t * t * (3 - 2 * t);
      h += m.h * Math.pow(f, 1.4);
      mount += f * Math.min(1, m.h / 40);
    }
  }
  if (mount > 0.02) {
    const mm = Math.min(1, mount);
    h += (ridged(x * 0.012, z * 0.012, 4) - 0.35) * 26 * mm;
  }
  const ex = Math.max(Math.abs(x), Math.abs(z)) + noise2(x * 0.01, z * 0.01) * 25;
  const b = smoothstep(378, 470, ex);
  if (b > 0) {
    h += b * (40 + ridged(x * 0.008 + 5, z * 0.008, 4) * 75);
    mount = Math.max(mount, b);
  }
  bM = Math.min(1, mount);
  bP = p;
  return h;
}

function cellOf(x: number, z: number) {
  const cx = clamp(Math.floor((x + WORLD_HALF) / CELL), 0, GRID - 1);
  const cz = clamp(Math.floor((z + WORLD_HALF) / CELL), 0, GRID - 1);
  return cz * GRID + cx;
}

function register(cells: number[][], idx: number, minx: number, minz: number, maxx: number, maxz: number) {
  const x0 = clamp(Math.floor((minx + WORLD_HALF) / CELL), 0, GRID - 1);
  const x1 = clamp(Math.floor((maxx + WORLD_HALF) / CELL), 0, GRID - 1);
  const z0 = clamp(Math.floor((minz + WORLD_HALF) / CELL), 0, GRID - 1);
  const z1 = clamp(Math.floor((maxz + WORLD_HALF) / CELL), 0, GRID - 1);
  for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) cells[z * GRID + x].push(idx);
}

function lakeRadius(li: number, dx: number, dz: number) {
  const L = LAKES[li];
  return L.r * (1 + 0.18 * noise2((dx / L.r) * 1.3 + li * 7.1, (dz / L.r) * 1.3 - li * 3.3));
}

let initialized = false;
export function initTerrain() {
  if (initialized) return;
  initialized = true;
  for (let i = 0; i < GRID * GRID; i++) {
    roadCells.push([]); riverCells.push([]); lakeCells.push([]); padCells.push([]); bridgeCells.push([]);
  }
  // River levels
  RIVERS.forEach((r, ri) => {
    const lv: number[] = [];
    for (let i = 0; i < r.pts.length; i++) {
      let l = baseHeight(r.pts[i][0], r.pts[i][1]) - 1.2;
      if (i > 0) l = Math.min(l, lv[i - 1] - 0.08);
      lv.push(l);
    }
    if (ri === 0) lv[lv.length - 1] = lv[lv.length - 2] - 0.05;
    r.levels = lv;
  });
  // Lake levels
  LAKES.forEach((L) => {
    L.level = baseHeight(L.x, L.z) - 1.0;
  });
  LAKES[0].level = RIVERS[0].levels![0];
  LAKES[1].level = RIVERS[1].levels![0];
  const south = LAKES[LAKES.length - 1];
  const rl = RIVERS[1].levels!;
  south.level = Math.min(south.level!, rl[rl.length - 1]);
  rl[rl.length - 1] = south.level;
  for (let i = rl.length - 2; i >= 0; i--) rl[i] = Math.max(rl[i], rl[i + 1] + 0.05);

  // Segments
  ROADS.forEach((rd, ri) => {
    for (let i = 0; i < rd.pts.length - 1; i++) {
      const [ax, az] = rd.pts[i];
      const [bx, bz] = rd.pts[i + 1];
      const s: Seg = { ax, az, bx, bz, dx: bx - ax, dz: bz - az, l2: (bx - ax) ** 2 + (bz - az) ** 2, w: rd.w, kind: rd.kind, hwa: 0, hwb: 0, la: 0, lb: 0, ri };
      const m = rd.w * 0.5 + 8;
      register(roadCells, roadSegs.length, Math.min(ax, bx) - m, Math.min(az, bz) - m, Math.max(ax, bx) + m, Math.max(az, bz) + m);
      roadSegs.push(s);
    }
  });
  RIVERS.forEach((r, ri) => {
    for (let i = 0; i < r.pts.length - 1; i++) {
      const [ax, az] = r.pts[i];
      const [bx, bz] = r.pts[i + 1];
      const s: Seg = { ax, az, bx, bz, dx: bx - ax, dz: bz - az, l2: (bx - ax) ** 2 + (bz - az) ** 2, w: 0, kind: 0, hwa: r.hw[i], hwb: r.hw[i + 1], la: r.levels![i], lb: r.levels![i + 1], ri };
      const m = Math.max(s.hwa, s.hwb) + 16;
      register(riverCells, riverSegs.length, Math.min(ax, bx) - m, Math.min(az, bz) - m, Math.max(ax, bx) + m, Math.max(az, bz) + m);
      riverSegs.push(s);
    }
  });
  LAKES.forEach((L, i) => {
    const m = L.r * 1.25 + 16;
    register(lakeCells, i, L.x - m, L.z - m, L.x + m, L.z + m);
  });
  // Pads
  const addPad = (x: number, z: number, r: number) => {
    const p: Pad = { x, z, r, h: baseHeight(x, z) };
    const m = r + 9;
    register(padCells, pads.length, x - m, z - m, x + m, z + m);
    pads.push(p);
  };
  STRUCTS.forEach((s) => addPad(s.x, s.z, s.pad));
  CAVES.forEach((c) => addPad(c.x, c.z, 5));
  VIEWPOINTS.forEach((v) => addPad(v.x, v.z, 4.5));

  // Bridges: road x river intersections
  for (const r of roadSegs) {
    for (const v of riverSegs) {
      const den = r.dx * v.dz - r.dz * v.dx;
      if (Math.abs(den) < 1e-6) continue;
      const t = ((v.ax - r.ax) * v.dz - (v.az - r.az) * v.dx) / den;
      const u = ((v.ax - r.ax) * r.dz - (v.az - r.az) * r.dx) / den;
      if (t < 0 || t > 1 || u < 0 || u > 1) continue;
      const x = r.ax + r.dx * t;
      const z = r.az + r.dz * t;
      const rl = Math.sqrt(r.l2);
      const dx = r.dx / rl;
      const dz = r.dz / rl;
      const vl = Math.sqrt(v.l2);
      const sin = Math.abs(dx * (v.dz / vl) - dz * (v.dx / vl));
      const hw = lerp(v.hwa, v.hwb, u);
      const half = hw / Math.max(0.4, sin) + 5;
      const L = lerp(v.la, v.lb, u);
      const b: Bridge = { x, z, dx, dz, half, width: Math.max(3.2, r.w * 0.8 + 0.6), h0: 0, h1: 0, minH: L + 1.5, stone: r.kind === 0 };
      bridges.push(b);
    }
  }
  const tmp = newSample();
  bridges.forEach((b, i) => {
    sampleTerrain(b.x - b.dx * b.half, b.z - b.dz * b.half, tmp);
    b.h0 = tmp.h + 0.15;
    sampleTerrain(b.x + b.dx * b.half, b.z + b.dz * b.half, tmp);
    b.h1 = tmp.h + 0.15;
    const m = b.half + 4;
    register(bridgeCells, i, b.x - m, b.z - m, b.x + m, b.z + m);
  });
}

export function bridgeDeck(b: Bridge, s: number) {
  const t = (s + b.half) / (2 * b.half);
  const base = lerp(b.h0, b.h1, t);
  const arch = Math.sin(Math.PI * t);
  return Math.max(base + arch * 0.8, lerp(base, b.minH, Math.min(1, arch * 2.2)));
}

/** returns deck height if (x,z) lies on a bridge, else -1e9. also outputs local coords */
export const bridgeLocal = { s: 0, a: 0, b: null as Bridge | null };
export function bridgeHeightAt(x: number, z: number): number {
  const list = bridgeCells[cellOf(x, z)];
  if (!list || list.length === 0) return -1e9;
  for (let i = 0; i < list.length; i++) {
    const b = bridges[list[i]];
    const rx = x - b.x;
    const rz = z - b.z;
    const s = rx * b.dx + rz * b.dz;
    const a = -rx * b.dz + rz * b.dx;
    if (Math.abs(s) <= b.half && Math.abs(a) <= b.width * 0.5 + 0.1) {
      bridgeLocal.s = s;
      bridgeLocal.a = a;
      bridgeLocal.b = b;
      return bridgeDeck(b, s);
    }
  }
  return -1e9;
}

export function sampleTerrain(x: number, z: number, out: Sample): Sample {
  let h = baseHeight(x, z);
  const mount = bM;
  const plateau = bP;
  const cell = cellOf(x, z);
  out.road = 0;
  out.roadKind = 0;
  out.water = -1e9;
  out.waterDepthE = 99;
  out.sand = 0;
  out.pad = 0;

  // Roads
  const rc = roadCells[cell];
  if (rc.length) {
    let best = 1e9, bt = 0, bs: Seg | null = null;
    for (let i = 0; i < rc.length; i++) {
      const s = roadSegs[rc[i]];
      let t = ((x - s.ax) * s.dx + (z - s.az) * s.dz) / s.l2;
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      const px = s.ax + s.dx * t - x;
      const pz = s.az + s.dz * t - z;
      const d = Math.sqrt(px * px + pz * pz) - s.w * 0.5;
      if (d < best) { best = d; bt = t; bs = s; }
    }
    if (bs && best < 7) {
      const hc = baseHeight(bs.ax + bs.dx * bt, bs.az + bs.dz * bt);
      const sm = smoothstep(0, 7, best);
      h = lerp(hc, h, sm);
      const en = noise2(x * 0.35, z * 0.35) * 0.55;
      out.road = 1 - smoothstep(-0.7 + en, 0.5 + en, best);
      out.roadKind = bs.kind;
    }
  }
  // Pads
  const pc = padCells[cell];
  for (let i = 0; i < pc.length; i++) {
    const p = pads[pc[i]];
    const dx = x - p.x, dz = z - p.z;
    const d = Math.sqrt(dx * dx + dz * dz);
    if (d < p.r + 8) {
      const s = smoothstep(p.r, p.r + 8, d);
      h = lerp(p.h, h, s);
      out.pad = Math.max(out.pad, 1 - s);
    }
  }
  // Lakes
  const lc = lakeCells[cell];
  for (let i = 0; i < lc.length; i++) {
    const L = LAKES[lc[i]];
    const dx = x - L.x, dz = z - L.z;
    const d = Math.sqrt(dx * dx + dz * dz);
    if (d > L.r * 1.25 + 15) continue;
    const rn = lakeRadius(lc[i], dx, dz);
    const e = d - rn;
    const lv = L.level!;
    const B = L.bank ?? 14;
    if (e < 0) {
      const k = Math.min(1, -e / (rn * 0.5));
      h = Math.min(h, lv - 0.4 - L.depth * Math.sin(k * 1.5708));
      out.water = Math.max(out.water, lv);
    } else if (e < B) {
      const hb = lerp(lv - 0.4 + e * 0.45, h, smoothstep(0, B, e));
      h = hb;
      if (d < L.r * 1.3 + 1) h = Math.max(h, lv + 0.12 + e * 0.05);
    }
    out.waterDepthE = Math.min(out.waterDepthE, e);
  }
  // Rivers
  const vc = riverCells[cell];
  if (vc.length) {
    let best = 1e9, bs: Seg | null = null, bt = 0;
    for (let i = 0; i < vc.length; i++) {
      const s = riverSegs[vc[i]];
      let t = ((x - s.ax) * s.dx + (z - s.az) * s.dz) / s.l2;
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      const px = s.ax + s.dx * t - x;
      const pz = s.az + s.dz * t - z;
      const d = Math.sqrt(px * px + pz * pz) - lerp(s.hwa, s.hwb, t);
      if (d < best) { best = d; bs = s; bt = t; }
    }
    if (bs && best < 16) {
      const hw = lerp(bs.hwa, bs.hwb, bt);
      const lv = lerp(bs.la, bs.lb, bt);
      const e = best;
      if (e < 0) {
        const k = Math.min(1, -e / (hw * 0.7));
        h = Math.min(h, lv - 0.4 - 1.8 * Math.sin(k * 1.5708));
        out.water = Math.max(out.water, lv);
      } else if (out.water < -1e8) {
        h = Math.min(h, lerp(lv - 0.4 + e * 0.5, h, smoothstep(0, 15, e)));
      }
      out.waterDepthE = Math.min(out.waterDepthE, e);
    }
  }
  if (out.waterDepthE < 99) {
    const n = noise2(x * 0.2, z * 0.2) * 1.5;
    out.sand = 1 - smoothstep(0.5, 3.5 + n, out.waterDepthE);
  }

  // Biomes
  const fN = fbm(x * 0.006 + 50, z * 0.006 - 20, 2);
  const nonPl = 1 - plateau;
  const dense = smoothstep(-50, -170, x + fN * 60) * (1 - smoothstep(230, 290, z)) * nonPl;
  const patch = smoothstep(0.18, 0.42, fN) * nonPl;
  const light = smoothstep(130, 200, x + fN * 50) * (1 - smoothstep(0.3, 0.8, mount)) * nonPl * (1 - smoothstep(230, 280, z));
  const clearing = smoothstep(0.3, 0.52, noise2(x * 0.025, z * 0.025));
  out.forest = Math.max(dense * (1 - clearing * 0.85), patch * 0.7 * (1 - light));
  out.light = light;
  out.plateau = plateau;
  out.mount = mount;
  out.h = h;
  return out;
}

const _s = newSample();
export function heightAt(x: number, z: number) {
  return sampleTerrain(x, z, _s).h;
}
export function waterAt(x: number, z: number) {
  return sampleTerrain(x, z, _s).water;
}

/** vertex color for terrain; writes to out[o..o+2] */
export function terrainColor(s: Sample, slope: number, x: number, z: number, out: Float32Array, o: number) {
  const n1 = noise2(x * 0.045, z * 0.045);
  const n2 = noise2(x * 0.17 + 3, z * 0.17);
  // meadow
  let r = 0.4, g = 0.58, b = 0.22;
  const dry = smoothstep(-0.3, 0.7, n1) * 0.65;
  r = lerp(r, 0.6, dry); g = lerp(g, 0.62, dry); b = lerp(b, 0.28, dry);
  // light forest
  r = lerp(r, 0.44, s.light * 0.6); g = lerp(g, 0.6, s.light * 0.6); b = lerp(b, 0.26, s.light * 0.6);
  // dense forest floor
  const f = Math.min(1, s.forest * 1.2);
  r = lerp(r, 0.21 + n2 * 0.03, f); g = lerp(g, 0.31 + n2 * 0.04, f); b = lerp(b, 0.13, f);
  // plateau alpine grass
  r = lerp(r, 0.34, s.plateau * 0.8); g = lerp(g, 0.46, s.plateau * 0.8); b = lerp(b, 0.26, s.plateau * 0.8);
  // altitude
  const alt = smoothstep(55, 95, s.h + n1 * 8);
  r = lerp(r, 0.47, alt); g = lerp(g, 0.47, alt); b = lerp(b, 0.34, alt);
  // sand banks
  if (s.sand > 0) {
    const sd = s.sand * (0.75 + n2 * 0.25);
    r = lerp(r, 0.74, sd); g = lerp(g, 0.66, sd); b = lerp(b, 0.47, sd);
  }
  // underwater
  if (s.h < s.water - 0.2) {
    const k = Math.min(1, (s.water - s.h) / 2.5);
    r = lerp(0.55, 0.3, k); g = lerp(0.5, 0.33, k); b = lerp(0.36, 0.28, k);
  }
  // rock
  const rk = smoothstep(0.6, 1.05, slope + n2 * 0.12) * (s.road > 0.5 ? 0.2 : 1);
  if (rk > 0) {
    const st = Math.sin(s.h * 1.1 + n1 * 3) * 0.04;
    const cliff = s.plateau > 0.05 && s.plateau < 0.95 ? 0.06 : 0;
    r = lerp(r, 0.44 + st - cliff, rk); g = lerp(g, 0.42 + st - cliff, rk); b = lerp(b, 0.4 + st - cliff * 0.8, rk);
  }
  // snow
  const sn = smoothstep(96, 106, s.h + n1 * 10) * (1 - smoothstep(1.0, 1.5, slope));
  if (sn > 0) { r = lerp(r, 0.92, sn); g = lerp(g, 0.94, sn); b = lerp(b, 0.98, sn); }
  // roads
  if (s.road > 0) {
    let rr: number, rg: number, rb: number;
    if (s.roadKind === 1) {
      const c = ((Math.floor(x / 1.5) + Math.floor(z / 1.5)) & 1) * 0.05 + n2 * 0.04;
      rr = 0.55 + c; rg = 0.53 + c; rb = 0.49 + c;
    } else if (s.roadKind === 2) {
      rr = 0.5 + n2 * 0.04; rg = 0.4 + n2 * 0.03; rb = 0.27;
    } else {
      rr = 0.56 + n2 * 0.05; rg = 0.43 + n2 * 0.04; rb = 0.29;
    }
    r = lerp(r, rr, s.road); g = lerp(g, rg, s.road); b = lerp(b, rb, s.road);
  }
  out[o] = r; out[o + 1] = g; out[o + 2] = b;
}
