/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { TRACK_LANES, GAME_PHYSICS } from './constants';
import {
  createTrackChunk,
  createTrainModel,
  createLowBarrier,
  createHighBarrier,
  createCrates,
  createCoin,
  createMagnetItem,
  createJetpackItem,
  createSneakersItem,
  createMultiplierItem,
} from './proceduralModels';

export interface ActiveObstacle {
  mesh: THREE.Group;
  lane: number;
  type: 'train' | 'barrier_low' | 'barrier_high' | 'crates';
  isMoving: boolean;
  speed: number;
  hasRamp: boolean;
  box: THREE.Box3;
  width: number;
  height: number;
  length: number;
  passed: boolean;
}

export interface ActiveCollectible {
  mesh: THREE.Group;
  type: 'coin' | 'powerup_magnet' | 'powerup_jetpack' | 'powerup_sneakers' | 'powerup_multiplier';
  collected: boolean;
  baseY: number;
}

export class TrackManager {
  private scene: THREE.Scene;
  private chunks: THREE.Group[] = [];
  private obstacles: ActiveObstacle[] = [];
  private collectibles: ActiveCollectible[] = [];
  private nextChunkZ: number = 0;
  private nextSpawnZ: number = -30;
  private readonly chunkLength: number = GAME_PHYSICS.CHUNK_LENGTH;
  private readonly activeChunksCount: number = GAME_PHYSICS.ACTIVE_CHUNKS;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.initTracks();
  }

  private initTracks() {
    // Generate initial track segments covering -50 to -400
    for (let i = 0; i < this.activeChunksCount; i++) {
      const chunk = createTrackChunk(this.chunkLength);
      const zPos = -i * this.chunkLength + 20; // Start slightly behind player
      chunk.position.set(0, 0, zPos);
      this.scene.add(chunk);
      this.chunks.push(chunk);
    }
    this.nextChunkZ = -(this.activeChunksCount - 1) * this.chunkLength + 20;

    // Pre-populate some starter coins and safe runway
    this.spawnCoinLine(0, -15, 6, 0.8);
  }

  public reset() {
    // Clean up all obstacles
    this.obstacles.forEach((obs) => this.scene.remove(obs.mesh));
    this.obstacles = [];

    // Clean up collectibles
    this.collectibles.forEach((c) => this.scene.remove(c.mesh));
    this.collectibles = [];

    // Reset chunks
    this.chunks.forEach((ch, idx) => {
      ch.position.set(0, 0, -idx * this.chunkLength + 20);
    });
    this.nextChunkZ = -(this.activeChunksCount - 1) * this.chunkLength + 20;
    this.nextSpawnZ = -35;

    // Safe starter coin line
    this.spawnCoinLine(0, -15, 6, 0.8);
  }

  public update(playerZ: number, delta: number, currentSpeed: number) {
    // 1. Recycle chunks behind player
    this.chunks.forEach((chunk) => {
      if (chunk.position.z > playerZ + this.chunkLength) {
        chunk.position.z = this.nextChunkZ - this.chunkLength;
        this.nextChunkZ = chunk.position.z;
      }
    });

    // 2. Spawn upcoming gameplay patterns ahead of player
    while (this.nextSpawnZ > playerZ - 280) {
      this.spawnPattern(this.nextSpawnZ, currentSpeed);
      // Distance between hazard clusters scales slightly with speed
      const gap = 32 + Math.random() * 18;
      this.nextSpawnZ -= gap;
    }

    // 3. Update moving trains
    this.obstacles.forEach((obs) => {
      if (obs.isMoving) {
        // Moving train drives toward the player (+Z in world)
        obs.mesh.position.z += obs.speed * delta;
      }
      // Update bounding box
      obs.box.setFromObject(obs.mesh);
    });

    // 4. Animate collectibles (rotation, hover bob)
    const time = performance.now() * 0.003;
    this.collectibles.forEach((col) => {
      if (!col.collected) {
        col.mesh.rotation.y += delta * 3.0;
        if (col.type !== 'coin') {
          col.mesh.position.y = col.baseY + Math.sin(time * 2.5) * 0.2;
        }
      }
    });

    // 5. Clean up passed items behind player
    const cleanupZ = playerZ + 25;

    this.obstacles = this.obstacles.filter((obs) => {
      if (obs.mesh.position.z > cleanupZ) {
        this.scene.remove(obs.mesh);
        return false;
      }
      return true;
    });

    this.collectibles = this.collectibles.filter((col) => {
      if (col.mesh.position.z > cleanupZ || col.collected) {
        this.scene.remove(col.mesh);
        return false;
      }
      return true;
    });
  }

  // -------------------------------------------------------------
  // Pattern Spawner (Ensures fair, exciting, solvable layouts)
  // -------------------------------------------------------------
  private spawnPattern(spawnZ: number, currentSpeed: number) {
    const patternType = Math.floor(Math.random() * 8);
    const lanes = [0, 1, 2]; // 0: Left, 1: Center, 2: Right

    // Pick 1-2 blocked lanes, guaranteeing at least one safe/accessible path
    switch (patternType) {
      case 0: {
        // High barrier in center lane + low barrier in left lane + coins in right lane
        this.spawnHighBarrier(1, spawnZ);
        this.spawnLowBarrier(0, spawnZ);
        this.spawnCoinLine(2, spawnZ - 10, 8, 0.8);
        this.maybeSpawnPowerup(2, spawnZ - 5);
        break;
      }
      case 1: {
        // Moving train on left or right lane
        const trainLane = Math.random() > 0.5 ? 0 : 2;
        this.spawnTrain(trainLane, spawnZ, true);
        // Crates on center lane with jumpable coin arc
        this.spawnCrates(1, spawnZ + 6);
        this.spawnCoinArc(1, spawnZ + 6, 1.8);
        break;
      }
      case 2: {
        // Stationary train with ramp on center lane! Player can jump on top!
        this.spawnTrain(1, spawnZ, false, true);
        // Coins stream on top of the train roof
        this.spawnCoinLine(1, spawnZ - 10, 10, 4.4);
        // Powerup on roof
        if (Math.random() > 0.4) {
          this.maybeSpawnPowerup(1, spawnZ - 2);
        }
        // Barriers on sides
        this.spawnLowBarrier(0, spawnZ);
        this.spawnHighBarrier(2, spawnZ);
        break;
      }
      case 3: {
        // Double hurdle jumps: sequential low barriers
        const jumpLane = Math.floor(Math.random() * 3);
        this.spawnLowBarrier(jumpLane, spawnZ);
        this.spawnLowBarrier(jumpLane, spawnZ - 12);
        this.spawnCoinArc(jumpLane, spawnZ, 1.6);
        this.spawnCoinArc(jumpLane, spawnZ - 12, 1.6);

        // Block adjacent lane with parked train
        const otherLane = (jumpLane + 1) % 3;
        this.spawnTrain(otherLane, spawnZ - 5, false, false);
        break;
      }
      case 4: {
        // Overhead signage gauntlet: slide under consecutive high barriers
        const slideLane = 1;
        this.spawnHighBarrier(slideLane, spawnZ);
        this.spawnHighBarrier(slideLane, spawnZ - 14);
        this.spawnCoinLine(slideLane, spawnZ - 14, 8, 0.5);

        // Crates on left & right
        this.spawnCrates(0, spawnZ);
        this.spawnCrates(2, spawnZ - 7);
        break;
      }
      case 5: {
        // Crates across 2 lanes, coin rush in the open lane
        const openLane = Math.floor(Math.random() * 3);
        lanes.forEach((l) => {
          if (l !== openLane) {
            this.spawnCrates(l, spawnZ);
          } else {
            this.spawnCoinLine(l, spawnZ - 8, 10, 0.8);
            this.maybeSpawnPowerup(l, spawnZ - 4);
          }
        });
        break;
      }
      case 6: {
        // Two oncoming trains on lanes 0 and 2, center lane open with coins!
        if (currentSpeed > 22) {
          this.spawnTrain(0, spawnZ - 10, true);
          this.spawnTrain(2, spawnZ - 10, true);
          this.spawnCoinLine(1, spawnZ - 15, 12, 0.8);
          this.maybeSpawnPowerup(1, spawnZ);
        } else {
          this.spawnTrain(0, spawnZ, false);
          this.spawnHighBarrier(1, spawnZ);
          this.spawnCoinLine(2, spawnZ - 8, 6, 0.8);
        }
        break;
      }
      default: {
        // Random balanced obstacle setup
        const l1 = Math.floor(Math.random() * 3);
        const l2 = (l1 + 1) % 3;
        this.spawnLowBarrier(l1, spawnZ);
        this.spawnHighBarrier(l2, spawnZ - 6);
        const freeLane = (l1 + 2) % 3;
        this.spawnCoinLine(freeLane, spawnZ - 10, 8, 0.8);
        break;
      }
    }
  }

  // -------------------------------------------------------------
  // Spawning Helpers
  // -------------------------------------------------------------
  private spawnTrain(laneIndex: number, z: number, isMoving: boolean, hasRamp: boolean = false) {
    const x = TRACK_LANES[laneIndex];
    const colorVar = Math.floor(Math.random() * 3);
    const train = createTrainModel(isMoving, colorVar, hasRamp);
    train.position.set(x, 0, z);
    this.scene.add(train);

    const box = new THREE.Box3();
    box.setFromObject(train);

    this.obstacles.push({
      mesh: train,
      lane: laneIndex,
      type: 'train',
      isMoving,
      speed: isMoving ? 14 : 0,
      hasRamp,
      box,
      width: 2.4,
      height: 4.4,
      length: 28,
      passed: false,
    });
  }

  private spawnLowBarrier(laneIndex: number, z: number) {
    const x = TRACK_LANES[laneIndex];
    const barrier = createLowBarrier();
    barrier.position.set(x, 0, z);
    this.scene.add(barrier);

    const box = new THREE.Box3();
    box.setFromObject(barrier);

    this.obstacles.push({
      mesh: barrier,
      lane: laneIndex,
      type: 'barrier_low',
      isMoving: false,
      speed: 0,
      hasRamp: false,
      box,
      width: 2.3,
      height: 1.1,
      length: 0.6,
      passed: false,
    });
  }

  private spawnHighBarrier(laneIndex: number, z: number) {
    const x = TRACK_LANES[laneIndex];
    const barrier = createHighBarrier();
    barrier.position.set(x, 0, z);
    this.scene.add(barrier);

    const box = new THREE.Box3();
    box.setFromObject(barrier);

    this.obstacles.push({
      mesh: barrier,
      lane: laneIndex,
      type: 'barrier_high',
      isMoving: false,
      speed: 0,
      hasRamp: false,
      box,
      width: 2.5,
      height: 3.4,
      length: 0.6,
      passed: false,
    });
  }

  private spawnCrates(laneIndex: number, z: number) {
    const x = TRACK_LANES[laneIndex];
    const crates = createCrates();
    crates.position.set(x, 0, z);
    this.scene.add(crates);

    const box = new THREE.Box3();
    box.setFromObject(crates);

    this.obstacles.push({
      mesh: crates,
      lane: laneIndex,
      type: 'crates',
      isMoving: false,
      speed: 0,
      hasRamp: false,
      box,
      width: 2.2,
      height: 1.1,
      length: 1.2,
      passed: false,
    });
  }

  public spawnCoinLine(laneIndex: number, startZ: number, count: number, y: number = 0.8) {
    const x = TRACK_LANES[laneIndex];
    for (let i = 0; i < count; i++) {
      const coin = createCoin();
      const z = startZ - i * 2.2;
      coin.position.set(x, y, z);
      this.scene.add(coin);

      this.collectibles.push({
        mesh: coin,
        type: 'coin',
        collected: false,
        baseY: y,
      });
    }
  }

  public spawnCoinArc(laneIndex: number, centerZ: number, peakHeight: number = 2.4) {
    const x = TRACK_LANES[laneIndex];
    const count = 7;
    const half = Math.floor(count / 2);

    for (let i = -half; i <= half; i++) {
      const coin = createCoin();
      const z = centerZ + i * 1.8;
      // Parabolic jump arc
      const norm = i / half; // -1 to 1
      const y = 0.8 + peakHeight * (1 - norm * norm);

      coin.position.set(x, y, z);
      this.scene.add(coin);

      this.collectibles.push({
        mesh: coin,
        type: 'coin',
        collected: false,
        baseY: y,
      });
    }
  }

  // Spawns sky coins for Jetpack mode!
  public spawnJetpackSkyCoins(startZ: number, lengthZ: number) {
    for (let z = startZ; z > startZ - lengthZ; z -= 3.0) {
      // Wavy sine wave across lanes
      const laneNorm = Math.sin(z * 0.08);
      const x = laneNorm * 2.8;
      const coin = createCoin();
      coin.position.set(x, GAME_PHYSICS.JETPACK_HEIGHT, z);
      this.scene.add(coin);

      this.collectibles.push({
        mesh: coin,
        type: 'coin',
        collected: false,
        baseY: GAME_PHYSICS.JETPACK_HEIGHT,
      });
    }
  }

  private maybeSpawnPowerup(laneIndex: number, z: number) {
    // 25% chance to spawn a powerup at this location
    if (Math.random() > 0.25) return;

    const x = TRACK_LANES[laneIndex];
    const powerups = ['magnet', 'jetpack', 'sneakers', 'multiplier'] as const;
    const picked = powerups[Math.floor(Math.random() * powerups.length)];

    let mesh: THREE.Group;
    let type: ActiveCollectible['type'];

    switch (picked) {
      case 'magnet':
        mesh = createMagnetItem();
        type = 'powerup_magnet';
        break;
      case 'jetpack':
        mesh = createJetpackItem();
        type = 'powerup_jetpack';
        break;
      case 'sneakers':
        mesh = createSneakersItem();
        type = 'powerup_sneakers';
        break;
      default:
        mesh = createMultiplierItem();
        type = 'powerup_multiplier';
        break;
    }

    mesh.position.set(x, 1.2, z);
    this.scene.add(mesh);

    this.collectibles.push({
      mesh,
      type,
      collected: false,
      baseY: 1.2,
    });
  }

  // -------------------------------------------------------------
  // Getters for Collision and Interactions
  // -------------------------------------------------------------
  public getObstacles(): ActiveObstacle[] {
    return this.obstacles;
  }

  public getCollectibles(): ActiveCollectible[] {
    return this.collectibles;
  }
}
