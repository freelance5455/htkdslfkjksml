import * as THREE from "three";
import { getTextures } from "@/game/textures";

export type FireResult = "shot" | "empty" | "blocked";

export class Weapon {
  readonly group = new THREE.Group();
  ammo = 6;
  reserve = 24;
  reloading = false;
  recoil = 0;
  private reloadT = 0;
  private cooldown = 0;
  private kickZ = 0;
  private flash = 0;
  private sway = new THREE.Vector2();
  private cylinder: THREE.Mesh;
  private flashMesh: THREE.Mesh;
  private flashLight: THREE.PointLight;
  private readonly geos: THREE.BufferGeometry[] = [];
  private readonly mats: THREE.Material[] = [];

  constructor() {
    const tex = getTextures();
    const metal = new THREE.MeshStandardMaterial({
      map: tex.metal,
      color: 0x2c2c2a,
      metalness: 0.85,
      roughness: 0.35,
    });
    const blued = new THREE.MeshStandardMaterial({
      color: 0x1a1c1e,
      metalness: 0.9,
      roughness: 0.28,
    });
    const grip = new THREE.MeshStandardMaterial({
      map: tex.wood,
      color: 0x6b4a30,
      roughness: 0.7,
      metalness: 0.05,
    });
    this.mats.push(metal, blued, grip);

    const geo = (g: THREE.BufferGeometry) => {
      this.geos.push(g);
      return g;
    };

    const barrel = new THREE.Mesh(geo(new THREE.CylinderGeometry(0.018, 0.02, 0.38, 8)), blued);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.04, -0.28);
    this.group.add(barrel);

    const frame = new THREE.Mesh(geo(new THREE.BoxGeometry(0.055, 0.09, 0.18)), metal);
    frame.position.set(0, 0.01, -0.02);
    this.group.add(frame);

    this.cylinder = new THREE.Mesh(geo(new THREE.CylinderGeometry(0.045, 0.045, 0.07, 10)), metal);
    this.cylinder.rotation.z = Math.PI / 2;
    this.cylinder.position.set(0, 0.03, 0.02);
    this.group.add(this.cylinder);

    const hammer = new THREE.Mesh(geo(new THREE.BoxGeometry(0.02, 0.045, 0.04)), metal);
    hammer.position.set(0, 0.07, 0.08);
    this.group.add(hammer);

    const gripMesh = new THREE.Mesh(geo(new THREE.BoxGeometry(0.045, 0.13, 0.07)), grip);
    gripMesh.position.set(0, -0.07, 0.1);
    gripMesh.rotation.x = 0.35;
    this.group.add(gripMesh);

    const guard = new THREE.Mesh(geo(new THREE.TorusGeometry(0.035, 0.006, 6, 10, Math.PI)), metal);
    guard.rotation.y = Math.PI / 2;
    guard.position.set(0, -0.03, 0.05);
    this.group.add(guard);

    const sight = new THREE.Mesh(geo(new THREE.BoxGeometry(0.01, 0.025, 0.02)), blued);
    sight.position.set(0, 0.07, -0.44);
    this.group.add(sight);

    const flashMat = new THREE.MeshBasicMaterial({
      color: 0xffe6a0,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    });
    this.mats.push(flashMat);
    this.flashMesh = new THREE.Mesh(geo(new THREE.SphereGeometry(0.05, 8, 8)), flashMat);
    this.flashMesh.position.set(0, 0.04, -0.48);
    this.group.add(this.flashMesh);

    this.flashLight = new THREE.PointLight(0xffd080, 0, 3, 2);
    this.flashLight.position.set(0, 0.04, -0.48);
    this.group.add(this.flashLight);

    this.group.position.set(0.26, -0.24, -0.48);
    this.group.rotation.set(0.06, 0.18, -0.08);
  }

  reset() {
    this.ammo = 6;
    this.reserve = 24;
    this.reloading = false;
    this.reloadT = 0;
    this.cooldown = 0;
    this.recoil = 0;
  }

  tryFire(): FireResult {
    if (this.reloading || this.cooldown > 0) return "blocked";
    if (this.ammo <= 0) return "empty";
    this.ammo -= 1;
    this.cooldown = 0.38;
    this.recoil = 0.085;
    this.kickZ = 0.06;
    this.flash = 0.05;
    this.cylinder.rotation.x += Math.PI / 3;
    return "shot";
  }

  beginReload() {
    if (this.reloading || this.ammo >= 6 || this.reserve <= 0) return false;
    this.reloading = true;
    this.reloadT = 2.05;
    return true;
  }

  update(dt: number, moving: number, lookDx: number, lookDy: number) {
    if (this.cooldown > 0) this.cooldown -= dt;
    if (this.flash > 0) {
      this.flash -= dt;
      const on = this.flash > 0;
      (this.flashMesh.material as THREE.MeshBasicMaterial).opacity = on ? 0.95 : 0;
      this.flashLight.intensity = on ? 4 : 0;
    }

    if (this.reloading) {
      this.reloadT -= dt;
      const p = 1 - this.reloadT / 2.05;
      this.group.rotation.x = 0.06 + Math.sin(p * Math.PI) * 0.55;
      this.cylinder.rotation.x += dt * 8;
      if (this.reloadT <= 0) {
        const need = 6 - this.ammo;
        const take = Math.min(need, this.reserve);
        this.ammo += take;
        this.reserve -= take;
        this.reloading = false;
        this.group.rotation.x = 0.06;
      }
    } else {
      this.recoil *= Math.exp(-10 * dt);
      this.kickZ *= Math.exp(-12 * dt);
    }

    this.sway.x += (lookDx * -0.0012 - this.sway.x) * Math.min(1, 8 * dt);
    this.sway.y += (lookDy * -0.001 - this.sway.y) * Math.min(1, 8 * dt);
    const bob = Math.sin(moving * 9) * 0.012 * Math.min(1, moving);
    this.group.position.set(
      0.26 + this.sway.x,
      -0.24 + bob - this.recoil * 0.4,
      -0.48 + this.kickZ,
    );
    if (!this.reloading) {
      this.group.rotation.set(0.06 + this.recoil, 0.18 + this.sway.x * 0.4, -0.08);
    }
  }

  addReserve(n: number) {
    this.reserve = Math.min(60, this.reserve + n);
  }

  dispose() {
    for (const g of this.geos) g.dispose();
    for (const m of this.mats) m.dispose();
  }
}
