import * as THREE from 'three';
import { PbrTextureSet } from './textures';

export class TacticalWeaponRig {
  public readonly root = new THREE.Group();
  public readonly gunGroup = new THREE.Group();
  public readonly slideMesh: THREE.Mesh;
  public readonly flashlightSpot: THREE.SpotLight;
  public readonly flashlightTarget = new THREE.Object3D();
  public readonly volumetricCone: THREE.Mesh;
  public readonly muzzleLight: THREE.PointLight;
  public readonly muzzleFlashGroup = new THREE.Group();
  public readonly flashlightLensMat: THREE.MeshStandardMaterial;

  private recoilPos = 0;
  private recoilRot = 0;
  private slideBlowback = 0;
  private muzzleTimer = 0;
  private reloadTimer = 0;
  private isReloading = false;

  // Decoupled bodycam inertia lag (like Unrecord/Bodycam)
  private lagYaw = 0;
  private lagPitch = 0;
  private swayPhase = 0;

  constructor(gunmetalTex: PbrTextureSet, isSoftwareGl: boolean) {
    // Materials with calibrated PBR contrast (>= 0.25 roughness delta between polymer & machined steel)
    const polymerMat = new THREE.MeshStandardMaterial({
      color: 0x1a1c1f,
      roughness: 0.78,
      metalness: 0.08,
    });

    const gripMat = new THREE.MeshStandardMaterial({
      color: 0x121316,
      roughness: 0.92,
      metalness: 0.02,
    });

    const slideMat = new THREE.MeshPhysicalMaterial({
      map: gunmetalTex.map,
      normalMap: gunmetalTex.normalMap,
      roughnessMap: gunmetalTex.roughnessMap,
      color: 0x4b525c,
      metalness: 0.92,
      roughness: 0.25,
      anisotropy: 0.85,
      anisotropyRotation: 0.0,
    });

    const barrelMat = new THREE.MeshStandardMaterial({
      color: 0x717882,
      metalness: 0.95,
      roughness: 0.16,
    });

    const gloveMat = new THREE.MeshStandardMaterial({
      color: 0x1c1e1b,
      roughness: 0.88,
      metalness: 0.04,
    });

    const sleeveMat = new THREE.MeshStandardMaterial({
      color: 0x262926,
      roughness: 0.94,
      metalness: 0.0,
    });

    const opticGlassMat = new THREE.MeshPhysicalMaterial({
      color: 0x88ccff,
      metalness: 0.0,
      roughness: 0.05,
      transmission: isSoftwareGl ? 0 : 0.85,
      transparent: true,
      opacity: isSoftwareGl ? 0.32 : 0.92,
      ior: 1.52,
      clearcoat: 1.0,
      depthWrite: false,
    });

    this.flashlightLensMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0xfff3d6,
      emissiveIntensity: 3.5,
      roughness: 0.1,
      metalness: 0.1,
    });

    // 1. Polymer Lower Frame
    const frameGeo = new THREE.BoxGeometry(0.032, 0.026, 0.19);
    const frame = new THREE.Mesh(frameGeo, polymerMat);
    frame.position.set(0, -0.008, -0.02);
    this.gunGroup.add(frame);

    // 2. Pistol Grip (angled)
    const gripGeo = new THREE.BoxGeometry(0.029, 0.105, 0.044);
    const grip = new THREE.Mesh(gripGeo, gripMat);
    grip.position.set(0, -0.058, 0.046);
    grip.rotation.x = 0.26;
    this.gunGroup.add(grip);

    // 3. Trigger Guard
    const guardGeo = new THREE.BoxGeometry(0.014, 0.024, 0.042);
    const guard = new THREE.Mesh(guardGeo, polymerMat);
    guard.position.set(0, -0.026, 0.008);
    this.gunGroup.add(guard);

    // 4. Machined Steel Slide (animates on fire)
    const slideGeo = new THREE.BoxGeometry(0.033, 0.03, 0.196);
    this.slideMesh = new THREE.Mesh(slideGeo, slideMat);
    this.slideMesh.position.set(0, 0.018, -0.02);
    this.gunGroup.add(this.slideMesh);

    // 5. Threaded Barrel + Compensator
    const barrelGeo = new THREE.CylinderGeometry(0.0075, 0.0075, 0.055, 16);
    barrelGeo.rotateX(Math.PI / 2);
    const barrel = new THREE.Mesh(barrelGeo, barrelMat);
    barrel.position.set(0, 0.016, -0.135);
    this.gunGroup.add(barrel);

    const compGeo = new THREE.BoxGeometry(0.028, 0.026, 0.036);
    const comp = new THREE.Mesh(compGeo, slideMat);
    comp.position.set(0, 0.014, -0.138);
    this.gunGroup.add(comp);

    // 6. Reflex Red-Dot Sight Housing + Optical Glass + Reticle
    const rdsBase = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.008, 0.042), polymerMat);
    rdsBase.position.set(0, 0.036, 0.02);
    this.slideMesh.add(rdsBase); // moves with slide!
    // Adjust relative to slideMesh center (slideMesh is at y=0.018, z=-0.02)
    rdsBase.position.set(0, 0.018, 0.045);

    const rdsHood = new THREE.Mesh(new THREE.BoxGeometry(0.026, 0.018, 0.006), polymerMat);
    rdsHood.position.set(0, 0.029, 0.032);
    this.slideMesh.add(rdsHood);

    const rdsGlass = new THREE.Mesh(new THREE.PlaneGeometry(0.02, 0.015), opticGlassMat);
    rdsGlass.position.set(0, 0.029, 0.032);
    this.slideMesh.add(rdsGlass);

    const reticleDot = new THREE.Mesh(
      new THREE.SphereGeometry(0.0012, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xff2a2a }),
    );
    reticleDot.position.set(0, 0.029, 0.033);
    this.slideMesh.add(reticleDot);

    // 7. Underbarrel Tactical Flashlight (X300)
    const tacLightBody = new THREE.Mesh(
      new THREE.CylinderGeometry(0.014, 0.013, 0.088, 16).rotateX(Math.PI / 2),
      slideMat,
    );
    tacLightBody.position.set(0, -0.026, -0.095);
    this.gunGroup.add(tacLightBody);

    const tacLightBezel = new THREE.Mesh(
      new THREE.CylinderGeometry(0.016, 0.014, 0.018, 16).rotateX(Math.PI / 2),
      barrelMat,
    );
    tacLightBezel.position.set(0, -0.026, -0.145);
    this.gunGroup.add(tacLightBezel);

    const tacLightLens = new THREE.Mesh(
      new THREE.CircleGeometry(0.0125, 16),
      this.flashlightLensMat,
    );
    tacLightLens.position.set(0, -0.026, -0.1545);
    tacLightLens.rotation.y = Math.PI;
    this.gunGroup.add(tacLightLens);

    // 8. Tactical Gloved Hands & Forearm Silhouette
    const rightHand = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.068, 0.056), gloveMat);
    rightHand.position.set(0.004, -0.055, 0.052);
    rightHand.rotation.x = 0.24;
    this.gunGroup.add(rightHand);

    const leftSupportHand = new THREE.Mesh(new THREE.BoxGeometry(0.046, 0.064, 0.06), gloveMat);
    leftSupportHand.position.set(-0.016, -0.056, 0.036);
    leftSupportHand.rotation.set(0.28, 0.22, -0.15);
    this.gunGroup.add(leftSupportHand);

    const rightForearm = new THREE.Mesh(
      new THREE.CylinderGeometry(0.036, 0.044, 0.34, 12).rotateX(Math.PI / 2),
      sleeveMat,
    );
    rightForearm.position.set(0.075, -0.115, 0.21);
    rightForearm.rotation.set(0.24, -0.32, 0);
    this.gunGroup.add(rightForearm);

    const leftForearm = new THREE.Mesh(
      new THREE.CylinderGeometry(0.035, 0.043, 0.34, 12).rotateX(Math.PI / 2),
      sleeveMat,
    );
    leftForearm.position.set(-0.088, -0.118, 0.195);
    leftForearm.rotation.set(0.25, 0.36, 0);
    this.gunGroup.add(leftForearm);

    // 9. Weapon-Mounted Tactical SpotLight + Volumetric Beam Cone
    this.flashlightSpot = new THREE.SpotLight(
      0xfff0d4,
      26.0,
      38.0,
      Math.PI / 5.4,
      0.55,
      1.35,
    );
    this.flashlightSpot.position.set(0, -0.026, -0.16);
    this.flashlightSpot.castShadow = !isSoftwareGl;
    this.flashlightSpot.shadow.mapSize.width = 1024;
    this.flashlightSpot.shadow.mapSize.height = 1024;
    this.flashlightSpot.shadow.camera.near = 0.25;
    this.flashlightSpot.shadow.camera.far = 36;
    this.flashlightSpot.shadow.bias = -0.0004;
    this.flashlightSpot.shadow.normalBias = 0.02;

    this.flashlightTarget.position.set(0, -0.026, -12);
    this.gunGroup.add(this.flashlightSpot);
    this.gunGroup.add(this.flashlightTarget);
    this.flashlightSpot.target = this.flashlightTarget;

    // Volumetric dust-beam cone using custom Fresnel shader
    const coneLength = 12.0;
    const coneRadius = Math.tan(Math.PI / 5.4) * coneLength;
    const coneGeo = new THREE.ConeGeometry(coneRadius, coneLength, 24, 1, true);
    coneGeo.translate(0, -coneLength / 2, 0);
    coneGeo.rotateX(Math.PI / 2);

    const coneMat = new THREE.ShaderMaterial({
      uniforms: {
        uColor: { value: new THREE.Color(0xffe8c2) },
        uIntensity: { value: 0.14 },
      },
      vertexShader: /* glsl */ `
        varying vec3 vNormal;
        varying vec3 vViewDir;
        varying float vDist;
        void main() {
          vec4 mvPos = modelViewMatrix * vec4(position, 1.0);
          vNormal = normalize(normalMatrix * normal);
          vViewDir = normalize(-mvPos.xyz);
          vDist = clamp(-position.z / 12.0, 0.0, 1.0);
          gl_Position = projectionMatrix * mvPos;
        }
      `,
      fragmentShader: /* glsl */ `
        uniform vec3 uColor;
        uniform float uIntensity;
        varying vec3 vNormal;
        varying vec3 vViewDir;
        varying float vDist;
        void main() {
          float fresnel = pow(abs(dot(vNormal, vViewDir)), 2.2);
          float fade = pow(1.0 - vDist, 1.8) * smoothstep(0.0, 0.06, vDist);
          float alpha = fresnel * fade * uIntensity;
          gl_FragColor = vec4(uColor, alpha);
        }
      `,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
    });

    this.volumetricCone = new THREE.Mesh(coneGeo, coneMat);
    this.volumetricCone.position.set(0, -0.026, -0.17);
    this.volumetricCone.renderOrder = 5;
    this.gunGroup.add(this.volumetricCone);

    // 10. Muzzle Flash Light & Starburst Planes
    this.muzzleLight = new THREE.PointLight(0xffb454, 0, 14, 1.6);
    this.muzzleLight.position.set(0, 0.016, -0.22);
    this.gunGroup.add(this.muzzleLight);

    const flashMat = new THREE.MeshBasicMaterial({
      color: 0xffd28a,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    for (let i = 0; i < 3; i++) {
      const plane = new THREE.Mesh(new THREE.PlaneGeometry(0.14, 0.05), flashMat);
      plane.rotation.z = (i * Math.PI) / 3;
      this.muzzleFlashGroup.add(plane);
    }
    this.muzzleFlashGroup.position.set(0, 0.016, -0.18);
    this.muzzleFlashGroup.visible = false;
    this.gunGroup.add(this.muzzleFlashGroup);

    // Base chest-bodycam weapon position (right-lower offset, angled slightly inward)
    this.gunGroup.position.set(0.14, -0.15, -0.34);
    this.root.add(this.gunGroup);
  }

  public triggerFire(): void {
    this.recoilPos = 0.045;
    this.recoilRot = 0.22;
    this.slideBlowback = 0.036;
    this.muzzleTimer = 0.045;
    this.muzzleFlashGroup.visible = true;
    this.muzzleFlashGroup.rotation.z = Math.random() * Math.PI;
    this.muzzleLight.intensity = 18.0;
  }

  public triggerReload(): void {
    this.isReloading = true;
    this.reloadTimer = 1.15;
  }

  public addLookImpulse(dx: number, dy: number): void {
    this.lagYaw = THREE.MathUtils.clamp(this.lagYaw - dx * 0.18, -0.22, 0.22);
    this.lagPitch = THREE.MathUtils.clamp(this.lagPitch - dy * 0.14, -0.16, 0.16);
  }

  public setFlashlight(on: boolean, flickerMultiplier = 1.0): void {
    this.flashlightSpot.visible = on;
    this.flashlightSpot.intensity = on ? 26.0 * flickerMultiplier : 0;
    this.volumetricCone.visible = on;
    this.flashlightLensMat.emissiveIntensity = on ? 3.5 * flickerMultiplier : 0.05;
  }

  public update(
    dt: number,
    isMoving: boolean,
    isSprinting: boolean,
    isAiming: boolean,
    isCrouching: boolean,
  ): void {
    // Exponential damping for recoil, slide, and decoupled bodycam inertia
    this.recoilPos = THREE.MathUtils.damp(this.recoilPos, 0, 14, dt);
    this.recoilRot = THREE.MathUtils.damp(this.recoilRot, 0, 14, dt);
    this.slideBlowback = THREE.MathUtils.damp(this.slideBlowback, 0, 22, dt);
    this.lagYaw = THREE.MathUtils.damp(this.lagYaw, 0, 9.5, dt);
    this.lagPitch = THREE.MathUtils.damp(this.lagPitch, 0, 9.5, dt);

    if (this.muzzleTimer > 0) {
      this.muzzleTimer -= dt;
      if (this.muzzleTimer <= 0) {
        this.muzzleFlashGroup.visible = false;
        this.muzzleLight.intensity = 0;
      } else {
        this.muzzleLight.intensity = (this.muzzleTimer / 0.045) * 18.0;
      }
    }

    if (this.isReloading) {
      this.reloadTimer -= dt;
      if (this.reloadTimer <= 0) {
        this.isReloading = false;
      }
    }

    // Breathing & footstep weapon sway
    const swayRate = isSprinting ? 10.5 : isMoving ? 6.8 : 1.5;
    this.swayPhase += dt * swayRate;
    const swayAmp = isAiming ? 0.0022 : isSprinting ? 0.018 : isMoving ? 0.009 : 0.0025;

    const bobX = Math.cos(this.swayPhase * 0.5) * swayAmp;
    const bobY = Math.abs(Math.sin(this.swayPhase)) * swayAmp * 0.85;

    // Target pose: hip-ready (chest cam view) vs ADS vs sprinting low-ready vs reload tilt
    let targetX = 0.135;
    let targetY = -0.145;
    let targetZ = -0.34;
    let targetRotX = 0.03;
    let targetRotY = 0.06;
    let targetRotZ = 0.0;

    if (this.isReloading) {
      targetX = 0.08;
      targetY = -0.22;
      targetZ = -0.28;
      targetRotX = -0.45;
      targetRotY = 0.35;
      targetRotZ = 0.55;
    } else if (isAiming) {
      targetX = 0.0;
      targetY = -0.042;
      targetZ = -0.25;
      targetRotX = 0.0;
      targetRotY = 0.0;
      targetRotZ = 0.0;
    } else if (isSprinting) {
      targetX = 0.11;
      targetY = -0.19;
      targetZ = -0.3;
      targetRotX = -0.28;
      targetRotY = 0.38;
      targetRotZ = 0.18;
    } else if (isCrouching) {
      targetX = 0.125;
      targetY = -0.13;
      targetZ = -0.33;
      targetRotZ = 0.08;
    }

    const dampLambda = isAiming ? 16 : 11;
    this.gunGroup.position.x = THREE.MathUtils.damp(
      this.gunGroup.position.x,
      targetX + bobX,
      dampLambda,
      dt,
    );
    this.gunGroup.position.y = THREE.MathUtils.damp(
      this.gunGroup.position.y,
      targetY - bobY,
      dampLambda,
      dt,
    );
    this.gunGroup.position.z = THREE.MathUtils.damp(
      this.gunGroup.position.z,
      targetZ + this.recoilPos,
      dampLambda,
      dt,
    );

    this.gunGroup.rotation.x = THREE.MathUtils.damp(
      this.gunGroup.rotation.x,
      targetRotX + this.recoilRot + this.lagPitch,
      dampLambda,
      dt,
    );
    this.gunGroup.rotation.y = THREE.MathUtils.damp(
      this.gunGroup.rotation.y,
      targetRotY + this.lagYaw,
      dampLambda,
      dt,
    );
    this.gunGroup.rotation.z = THREE.MathUtils.damp(
      this.gunGroup.rotation.z,
      targetRotZ - this.lagYaw * 0.45,
      dampLambda,
      dt,
    );

    this.slideMesh.position.z = -0.02 + this.slideBlowback;
  }

  public dispose(): void {
    this.gunGroup.traverse((obj) => {
      if (obj instanceof THREE.Mesh) {
        obj.geometry.dispose();
        if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
        else obj.material.dispose();
      }
    });
  }
}
