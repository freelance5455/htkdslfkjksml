import {
  TileType,
  Point,
  MazeData,
  HidingSpot,
  ClimbableWall,
  Chicken,
  GameDifficulty,
  Crystal,
} from '../types/game';
import { findPath } from './pathfinding';

export const TILE_SIZE = 48; // Base pixel size per maze grid tile

function findOrCreateCornerFloor(
  tiles: TileType[][],
  gridW: number,
  gridH: number,
  targetCorner: Point
): Point {
  if (tiles[targetCorner.y]?.[targetCorner.x] === 0) {
    return targetCorner;
  }

  let bestPt: Point | null = null;
  let bestDist = Infinity;
  for (let dy = -3; dy <= 3; dy++) {
    for (let dx = -3; dx <= 3; dx++) {
      const nx = targetCorner.x + dx;
      const ny = targetCorner.y + dy;
      if (nx > 0 && nx < gridW - 1 && ny > 0 && ny < gridH - 1) {
        if (tiles[ny][nx] === 0) {
          const d = Math.abs(dx) + Math.abs(dy);
          if (d < bestDist) {
            bestDist = d;
            bestPt = { x: nx, y: ny };
          }
        }
      }
    }
  }

  if (bestPt) {
    return bestPt;
  }

  // Failsafe: carve corner tile and connect
  tiles[targetCorner.y][targetCorner.x] = 0;
  return targetCorner;
}

export function generateMaze(difficulty: GameDifficulty): MazeData {
  // Moderately larger maze dimensions with richer corridors and turns
  let gridW = 35;
  let gridH = 35;

  if (difficulty === 'easy') {
    gridW = 31;
    gridH = 31;
  } else if (difficulty === 'hard') {
    gridW = 39;
    gridH = 39;
  }

  // Ensure odd dimensions
  if (gridW % 2 === 0) gridW++;
  if (gridH % 2 === 0) gridH++;

  // Initialize with walls (1)
  const tiles: TileType[][] = Array.from({ length: gridH }, () =>
    Array.from({ length: gridW }, () => 1 as TileType)
  );

  const centerX = Math.floor(gridW / 2);
  const centerY = Math.floor(gridH / 2);

  // 1. Randomized DFS maze carving
  const stack: Point[] = [];
  const startX = 1;
  const startY = 1;

  tiles[startY][startX] = 0;
  stack.push({ x: startX, y: startY });

  const dirs = [
    { x: 0, y: -2 },
    { x: 2, y: 0 },
    { x: 0, y: 2 },
    { x: -2, y: 0 },
  ];

  while (stack.length > 0) {
    const current = stack[stack.length - 1];
    const neighbors: { p: Point; wall: Point }[] = [];

    for (const d of dirs) {
      const nx = current.x + d.x;
      const ny = current.y + d.y;

      if (nx > 0 && nx < gridW - 1 && ny > 0 && ny < gridH - 1) {
        if (tiles[ny][nx] === 1) {
          neighbors.push({
            p: { x: nx, y: ny },
            wall: { x: current.x + d.x / 2, y: current.y + d.y / 2 },
          });
        }
      }
    }

    if (neighbors.length > 0) {
      // Pick random neighbor
      const next = neighbors[Math.floor(Math.random() * neighbors.length)];
      tiles[next.wall.y][next.wall.x] = 0;
      tiles[next.p.y][next.p.x] = 0;
      stack.push(next.p);
    } else {
      stack.pop();
    }
  }

  // 2. Open up the central portal chamber (3x3 room)
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      tiles[centerY + dy][centerX + dx] = 0;
    }
  }
  // Mark the exact center as PORTAL (tile 2)
  tiles[centerY][centerX] = 2;

  // Connect portal chamber to adjacent corridors
  if (centerY - 2 > 0) tiles[centerY - 2][centerX] = 0;
  if (centerY + 2 < gridH - 1) tiles[centerY + 2][centerX] = 0;
  if (centerX - 2 > 0) tiles[centerY][centerX - 2] = 0;
  if (centerX + 2 < gridW - 1) tiles[centerY][centerX + 2] = 0;

  // 3. Remove walls to create interconnected loops, alternate paths & junctions
  const loopBraidingFactor = difficulty === 'hard' ? 0.20 : 0.17;
  for (let y = 2; y < gridH - 2; y++) {
    for (let x = 2; x < gridW - 2; x++) {
      if (tiles[y][x] === 1) {
        // Check horizontal or vertical corridor connector
        const isHorizPassage =
          tiles[y][x - 1] === 0 &&
          tiles[y][x + 1] === 0 &&
          tiles[y - 1][x] === 1 &&
          tiles[y + 1][x] === 1;
        const isVertPassage =
          tiles[y - 1][x] === 0 &&
          tiles[y + 1][x] === 0 &&
          tiles[y][x - 1] === 1 &&
          tiles[y][x + 1] === 1;

        if ((isHorizPassage || isVertPassage) && Math.random() < loopBraidingFactor) {
          tiles[y][x] = 0;
        }
      }
    }
  }

  const portalGrid: Point = { x: centerX, y: centerY };
  const playerStartGrid: Point = { x: 1, y: 1 };

  // Guarantee player start has a nice clear vestibule
  tiles[1][1] = 0;
  tiles[1][2] = 0;
  tiles[2][1] = 0;

  // 4. Place 3 Collectible Crystals in the 3 other corners
  // Corner 1: Top-Right
  const trPt = findOrCreateCornerFloor(tiles, gridW, gridH, { x: gridW - 2, y: 1 });
  // Corner 2: Bottom-Left
  const blPt = findOrCreateCornerFloor(tiles, gridW, gridH, { x: 1, y: gridH - 2 });
  // Corner 3: Bottom-Right
  const brPt = findOrCreateCornerFloor(tiles, gridW, gridH, { x: gridW - 2, y: gridH - 2 });

  // Guarantee reachability for all 3 corners and the portal
  const cornerPoints = [trPt, blPt, brPt];
  for (const pt of cornerPoints) {
    const pathToPortal = findPath(tiles, pt, portalGrid);
    if (pathToPortal.length === 0) {
      let cx = pt.x;
      let cy = pt.y;
      while (cx !== portalGrid.x) {
        tiles[cy][cx] = 0;
        cx += cx < portalGrid.x ? 1 : -1;
      }
      while (cy !== portalGrid.y) {
        tiles[cy][cx] = 0;
        cy += cy < portalGrid.y ? 1 : -1;
      }
    }
  }

  const crystals: Crystal[] = [
    {
      id: 'crystal_tr',
      gridX: trPt.x,
      gridY: trPt.y,
      x: trPt.x * TILE_SIZE + TILE_SIZE / 2,
      y: trPt.y * TILE_SIZE + TILE_SIZE / 2,
      color: '#06b6d4',
      glowColor: '#67e8f9',
      name: 'Sapphire Crystal',
      collected: false,
      cornerName: 'Top-Right',
    },
    {
      id: 'crystal_bl',
      gridX: blPt.x,
      gridY: blPt.y,
      x: blPt.x * TILE_SIZE + TILE_SIZE / 2,
      y: blPt.y * TILE_SIZE + TILE_SIZE / 2,
      color: '#10b981',
      glowColor: '#6ee7b7',
      name: 'Emerald Crystal',
      collected: false,
      cornerName: 'Bottom-Left',
    },
    {
      id: 'crystal_br',
      gridX: brPt.x,
      gridY: brPt.y,
      x: brPt.x * TILE_SIZE + TILE_SIZE / 2,
      y: brPt.y * TILE_SIZE + TILE_SIZE / 2,
      color: '#f43f5e',
      glowColor: '#fda4af',
      name: 'Ruby Crystal',
      collected: false,
      cornerName: 'Bottom-Right',
    },
  ];

  // 5. Calculate the SAFE ROUTE from player start to portal
  const safePath = findPath(tiles, playerStartGrid, portalGrid);
  if (safePath.length === 0) {
    // Failsafe: carve direct manhattan path if ever disconnected
    let cx = playerStartGrid.x;
    let cy = playerStartGrid.y;
    while (cx !== portalGrid.x) {
      tiles[cy][cx] = 0;
      cx += cx < portalGrid.x ? 1 : -1;
    }
    while (cy !== portalGrid.y) {
      tiles[cy][cx] = 0;
      cy += cy < portalGrid.y ? 1 : -1;
    }
    tiles[portalGrid.y][portalGrid.x] = 2;
  }

  const computedSafePath = findPath(tiles, playerStartGrid, portalGrid);
  const safeCellSet = new Set<string>();
  for (const p of computedSafePath) {
    safeCellSet.add(`${p.x},${p.y}`);
    // Also include a 1-tile buffer around the safe path to prevent patrol chickens from bleeding in
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        safeCellSet.add(`${p.x + dx},${p.y + dy}`);
      }
    }
  }

  // 6. Identify Alternative Walkable Corridors outside the safe route for Chickens
  const nonSafeWalkable: Point[] = [];
  for (let y = 1; y < gridH - 1; y++) {
    for (let x = 1; x < gridW - 1; x++) {
      if (tiles[y][x] === 0 && !safeCellSet.has(`${x},${y}`)) {
        // Must not be immediately adjacent to player start (at least 5 steps away)
        const distToStart = Math.abs(x - playerStartGrid.x) + Math.abs(y - playerStartGrid.y);
        const distToPortal = Math.abs(x - portalGrid.x) + Math.abs(y - portalGrid.y);
        const nearCrystal = crystals.some(
          (c) => Math.hypot(c.gridX - x, c.gridY - y) < 3
        );
        if (distToStart > 5 && distToPortal > 2 && !nearCrystal) {
          nonSafeWalkable.push({ x, y });
        }
      }
    }
  }

  // Determine chicken count based on difficulty
  let targetChickenCount = 5;
  if (difficulty === 'easy') targetChickenCount = 3 + Math.floor(Math.random() * 2);
  else if (difficulty === 'normal') targetChickenCount = 5 + Math.floor(Math.random() * 2);
  else targetChickenCount = 7 + Math.floor(Math.random() * 3);

  // Group non-safe walkable tiles into clusters/corridors for chicken patrols
  const initialChickens: Chicken[] = [];
  // Shuffle non-safe tiles
  const shuffledNonSafe = [...nonSafeWalkable].sort(() => Math.random() - 0.5);

  let chickensPlaced = 0;
  const chickenBaseSpeed = difficulty === 'easy' ? 95 : difficulty === 'normal' ? 108 : 118;

  for (const candidate of shuffledNonSafe) {
    if (chickensPlaced >= targetChickenCount) break;

    // Check minimum distance from already placed chickens
    const tooClose = initialChickens.some(
      (c) => Math.hypot(c.x / TILE_SIZE - candidate.x, c.y / TILE_SIZE - candidate.y) < 4
    );
    if (tooClose) continue;

    // Create a patrol route for this chicken along connected non-safe tiles
    const patrolRoute: Point[] = [{ x: candidate.x * TILE_SIZE + TILE_SIZE / 2, y: candidate.y * TILE_SIZE + TILE_SIZE / 2 }];
    
    // Find up to 3 nearby walkable points for patrol
    const nearby = shuffledNonSafe.filter(
      (p) =>
        Math.hypot(p.x - candidate.x, p.y - candidate.y) > 2 &&
        Math.hypot(p.x - candidate.x, p.y - candidate.y) < 7
    );

    if (nearby.length > 0) {
      const p2 = nearby[0];
      patrolRoute.push({ x: p2.x * TILE_SIZE + TILE_SIZE / 2, y: p2.y * TILE_SIZE + TILE_SIZE / 2 });
    }
    if (nearby.length > 1) {
      const p3 = nearby[1];
      patrolRoute.push({ x: p3.x * TILE_SIZE + TILE_SIZE / 2, y: p3.y * TILE_SIZE + TILE_SIZE / 2 });
    }

    initialChickens.push({
      id: `chicken_${chickensPlaced}`,
      x: candidate.x * TILE_SIZE + TILE_SIZE / 2,
      y: candidate.y * TILE_SIZE + TILE_SIZE / 2,
      vx: 0,
      vy: 0,
      speed: chickenBaseSpeed + (Math.random() * 8 - 4),
      state: 'patrol',
      patrolRoute,
      patrolIdx: 0,
      path: [],
      lastKnownPlayerPos: null,
      investigateTimeRemaining: 0,
      alertAnimationTime: 0,
      facing: 'down',
      animTick: Math.random() * 10,
      colorVariant: Math.floor(Math.random() * 3), // 0: classic white/yellow, 1: golden brown, 2: spotted
      squawkBubble: null,
      squawkTimer: 0,
    });

    chickensPlaced++;
  }

  // 6. Place Bushes: Randomly placed throughout the maze on every run
  // Randomly assigned as REAL HIDING BUSH or FAKE HIDING BUSH every new game.
  // Both types look identical until tested by the player.
  const hidingSpots: HidingSpot[] = [];
  let hidingId = 0;

  // Scan all valid walkable cells across the maze
  const validWalkableCells: Point[] = [];

  for (let y = 1; y < gridH - 1; y++) {
    for (let x = 1; x < gridW - 1; x++) {
      if (tiles[y][x] === 0) {
        // Exclude player start area and entrance corridor so player isn't spawned directly on a bush
        if (Math.hypot(x - playerStartGrid.x, y - playerStartGrid.y) <= 2) continue;

        // Exclude portal room and immediate threshold so portal entrance remains clear
        if (Math.hypot(x - portalGrid.x, y - portalGrid.y) <= 2) continue;

        // Exclude crystal locations so crystals are clearly visible in the corridors
        const nearCrystal = crystals.some(
          (c) => Math.hypot(c.gridX - x, c.gridY - y) < 2.2
        );
        if (nearCrystal) continue;

        validWalkableCells.push({ x, y });
      }
    }
  }

  // Shuffle candidate cells thoroughly for completely randomized placement on each new run
  for (let i = validWalkableCells.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [validWalkableCells[i], validWalkableCells[j]] = [validWalkableCells[j], validWalkableCells[i]];
  }

  // Place 18 to 26 bushes distributed across the larger maze
  const targetBushes = difficulty === 'easy' ? 26 : difficulty === 'normal' ? 22 : 18;

  for (const pt of validWalkableCells) {
    if (hidingSpots.length >= targetBushes) break;

    // Minimum distance between bushes to keep corridors accessible and nicely spaced
    const tooClose = hidingSpots.some((h) => Math.hypot(h.gridX - pt.x, h.gridY - pt.y) < 2.9);
    if (!tooClose) {
      // Randomly assign each bush as either a REAL HIDING BUSH or a FAKE HIDING BUSH every run (~50/50)
      const isFake = Math.random() < 0.48;

      hidingSpots.push({
        id: `bush_${hidingId++}`,
        gridX: pt.x,
        gridY: pt.y,
        x: pt.x * TILE_SIZE + TILE_SIZE / 2,
        y: pt.y * TILE_SIZE + TILE_SIZE / 2,
        type: 'bush', // strictly bushes for the bush mechanic
        isOccupied: false,
        isFake,
        revealed: false,
      });
    }
  }

  // 7. Place Ladders randomly throughout valid maze locations, NOT only in dead ends!
  // Any interior wall separating two walkable corridor tiles is a valid climbable wall
  const climbableWalls: ClimbableWall[] = [];
  const candidateLadderWalls: Array<{
    x: number;
    y: number;
    sideA: Point;
    sideB: Point;
    direction: 'horizontal' | 'vertical';
  }> = [];

  for (let y = 1; y < gridH - 1; y++) {
    for (let x = 1; x < gridW - 1; x++) {
      if (tiles[y][x] === 1) {
        // Exclude outer boundaries
        if (x === 0 || x === gridW - 1 || y === 0 || y === gridH - 1) continue;
        // Exclude central portal room walls so portal remains a discovery
        if (Math.abs(x - portalGrid.x) <= 2 && Math.abs(y - portalGrid.y) <= 2) continue;

        // Valid horizontal divider: walkable tile above and below
        const isHorizDivider = tiles[y - 1][x] === 0 && tiles[y + 1][x] === 0;

        // Valid vertical divider: walkable tile left and right
        const isVertDivider = tiles[y][x - 1] === 0 && tiles[y][x + 1] === 0;

        if (isHorizDivider) {
          candidateLadderWalls.push({
            x,
            y,
            sideA: { x, y: y - 1 },
            sideB: { x, y: y + 1 },
            direction: 'horizontal',
          });
        } else if (isVertDivider) {
          candidateLadderWalls.push({
            x,
            y,
            sideA: { x: x - 1, y },
            sideB: { x: x + 1, y },
            direction: 'vertical',
          });
        }
      }
    }
  }

  // Shuffle candidate walls randomly across the entire maze
  const shuffledLadderCandidates = candidateLadderWalls.sort(() => Math.random() - 0.5);
  const targetLadders = difficulty === 'easy' ? 12 : difficulty === 'normal' ? 10 : 8;

  let climbId = 0;
  for (const cand of shuffledLadderCandidates) {
    if (climbableWalls.length >= targetLadders) break;

    // Distribute evenly without placing directly adjacent to another ladder wall
    const tooClose = climbableWalls.some(
      (cw) => Math.hypot(cw.gridX - cand.x, cw.gridY - cand.y) < 3.0
    );

    if (!tooClose) {
      climbableWalls.push({
        id: `ladder_wall_${climbId++}`,
        gridX: cand.x,
        gridY: cand.y,
        sideA: cand.sideA,
        sideB: cand.sideB,
        direction: cand.direction,
        isUsed: false,
      });
    }
  }

  return {
    width: gridW,
    height: gridH,
    tiles,
    portalGrid,
    playerStartGrid,
    safePath: computedSafePath,
    hidingSpots,
    climbableWalls,
    initialChickens,
    crystals,
    portalUnlocked: false,
  };
}
