export type Role = "gk" | "def" | "mid" | "fwd";
export type KitPattern = "solid" | "stripe" | "hoop" | "sash";

export type SquadPlayer = {
  name: string;
  num: number;
  role: Role;
};

export type TeamDef = {
  id: string;
  name: string;
  short: string;
  city: string;
  primary: string;
  secondary: string;
  shorts: string;
  socks: string;
  pattern: KitPattern;
  rating: number;
  attack: number;
  mid: number;
  def: number;
  squad: SquadPlayer[];
};

const ROLES: Role[] = ["gk", "def", "def", "def", "def", "mid", "mid", "mid", "fwd", "fwd", "fwd"];
const NUMS = [1, 2, 3, 4, 5, 6, 8, 10, 7, 9, 11];

function squad(names: string[]): SquadPlayer[] {
  return names.slice(0, 11).map((name, i) => ({
    name,
    num: NUMS[i]!,
    role: ROLES[i]!,
  }));
}

export const TEAMS: TeamDef[] = [
  {
    id: "blancos",
    name: "Capital Blancos",
    short: "CBL",
    city: "Madrid",
    primary: "#f4f4f1",
    secondary: "#c9a227",
    shorts: "#f4f4f1",
    socks: "#f4f4f1",
    pattern: "solid",
    rating: 88,
    attack: 90,
    mid: 87,
    def: 86,
    squad: squad(["Courto", "Carva", "Milita", "Rudig", "Mendy", "Tchou", "Valver", "Belling", "Vini", "Mbappe", "Rodry"]),
  },
  {
    id: "catalans",
    name: "Harbor Catalans",
    short: "HCA",
    city: "Barcelona",
    primary: "#a50044",
    secondary: "#004d98",
    shorts: "#004d98",
    socks: "#a50044",
    pattern: "stripe",
    rating: 86,
    attack: 88,
    mid: 89,
    def: 82,
    squad: squad(["Szczes", "Kounde", "Araujo", "Cubarsi", "Balde", "Pedri", "Gavi", "DeJong", "Yamal", "Lewand", "Raphin"]),
  },
  {
    id: "northbank",
    name: "Northbank Scarlet",
    short: "NBS",
    city: "London",
    primary: "#ef0107",
    secondary: "#f2f2f2",
    shorts: "#f2f2f2",
    socks: "#ef0107",
    pattern: "solid",
    rating: 85,
    attack: 86,
    mid: 84,
    def: 84,
    squad: squad(["Raya", "White", "Saliba", "Gabriel", "Timber", "Rice", "Odega", "Havert", "Saka", "Jesus", "Martin"]),
  },
  {
    id: "dockside",
    name: "Dockside Crimson",
    short: "DCR",
    city: "Liverpool",
    primary: "#c8102e",
    secondary: "#00b2a9",
    shorts: "#c8102e",
    socks: "#c8102e",
    pattern: "solid",
    rating: 87,
    attack: 89,
    mid: 85,
    def: 85,
    squad: squad(["Alisson", "Alexander", "VanDijk", "Konate", "Robert", "MacAll", "Szobos", "Jones", "Salah", "Nunez", "Diaz"]),
  },
  {
    id: "seine",
    name: "Seine Royale",
    short: "SNR",
    city: "Paris",
    primary: "#002395",
    secondary: "#e30613",
    shorts: "#002395",
    socks: "#e30613",
    pattern: "sash",
    rating: 84,
    attack: 87,
    mid: 82,
    def: 81,
    squad: squad(["Donnar", "Hakimi", "Marqui", "Skrini", "Mendes", "Vitinh", "Ruiz", "Lee", "Dembele", "Barcol", "Kolo"]),
  },
  {
    id: "alpine",
    name: "Alpine Bavaria",
    short: "ABV",
    city: "Munich",
    primary: "#dc052d",
    secondary: "#f2f2f2",
    shorts: "#dc052d",
    socks: "#dc052d",
    pattern: "hoop",
    rating: 85,
    attack: 86,
    mid: 85,
    def: 83,
    squad: squad(["Neuer", "Kimmich", "Upamec", "Kim", "Davies", "Goretz", "Musial", "Wirtz", "Sane", "Kane", "Olisem"]),
  },
  {
    id: "canal",
    name: "Canal Inter",
    short: "CIN",
    city: "Milan",
    primary: "#010e80",
    secondary: "#0a0a0a",
    shorts: "#0a0a0a",
    socks: "#010e80",
    pattern: "stripe",
    rating: 86,
    attack: 84,
    mid: 85,
    def: 88,
    squad: squad(["Sommer", "DiLoren", "Acerbi", "Bastoni", "Dimarc", "Barella", "Calhan", "Mkhit", "Thuram", "Lautar", "Frates"]),
  },
  {
    id: "piedmont",
    name: "Piedmont Stripe",
    short: "PST",
    city: "Turin",
    primary: "#f2f2f2",
    secondary: "#111111",
    shorts: "#111111",
    socks: "#f2f2f2",
    pattern: "stripe",
    rating: 82,
    attack: 81,
    mid: 82,
    def: 83,
    squad: squad(["Szczes2", "Danilo", "Bremer", "Gatti", "Cambias", "Locat", "Rabiot", "Koop", "Chiesa", "Vlahov", "Gonzal"]),
  },
  {
    id: "lisbon",
    name: "Lisbon Lions",
    short: "LSL",
    city: "Lisbon",
    primary: "#006633",
    secondary: "#f2f2f2",
    shorts: "#006633",
    socks: "#f2f2f2",
    pattern: "solid",
    rating: 81,
    attack: 83,
    mid: 80,
    def: 79,
    squad: squad(["Costa", "Inacio", "Diomas", "St.Just", "Reis", "Hjulma", "Morita", "Fernan", "Gyoker", "Edwards", "Trinco"]),
  },
  {
    id: "dam",
    name: "Dam Square",
    short: "DMS",
    city: "Amsterdam",
    primary: "#e30613",
    secondary: "#f2f2f2",
    shorts: "#f2f2f2",
    socks: "#e30613",
    pattern: "solid",
    rating: 80,
    attack: 82,
    mid: 81,
    def: 77,
    squad: squad(["Rulli", "Rensch", "Sutalo", "Marta", "Wijndal", "Hender", "Taylor", "Berghu", "Bergwi", "Brobbey", "Akpom"]),
  },
  {
    id: "douro",
    name: "Douro Dragons",
    short: "DDR",
    city: "Porto",
    primary: "#003087",
    secondary: "#f2f2f2",
    shorts: "#003087",
    socks: "#f2f2f2",
    pattern: "sash",
    rating: 80,
    attack: 79,
    mid: 80,
    def: 81,
    squad: squad(["CostaP", "JoaoM", "Otavio", "Pepe", "Wendel", "Varela", "Eustaq", "PepeM", "Galeno", "Taremi", "Evanil"]),
  },
  {
    id: "vesuvio",
    name: "Vesuvio Azzurro",
    short: "VAZ",
    city: "Naples",
    primary: "#12a0d7",
    secondary: "#f2f2f2",
    shorts: "#12a0d7",
    socks: "#12a0d7",
    pattern: "solid",
    rating: 83,
    attack: 84,
    mid: 82,
    def: 82,
    squad: squad(["Meret", "DiLore", "Rrahma", "JuanJ", "Oliver", "Anguis", "Lobots", "Politano", "Kvara", "Osimhen", "Raspad"]),
  },
];

export function teamById(id: string): TeamDef {
  return TEAMS.find((t) => t.id === id) ?? TEAMS[0]!;
}

export function otherTeam(id: string): TeamDef {
  const rest = TEAMS.filter((t) => t.id !== id);
  return rest[Math.floor(Math.random() * rest.length)] ?? TEAMS[1]!;
}
