/**
 * SPR - Sahil Powerful Run
 * 15 Stylized 3D Skateboard Definitions & Booster Perks
 * 
 * Every skateboard features:
 * - Genuinely DIFFERENT 3D body shape and silhouette
 * - Real 3D geometry (nose, tail, deck contour, side attachments, wheels, trucks)
 * - Distinct performance (Speed, Acceleration, Handling/Stability, Power Duration, Jump Boost)
 * - Wooden Classic (#6) & Fire Blaze (#1) are Unlocked & Free by default
 * - Rocket Board (#13) features aerodynamic rocket fuselage + dual animated rocket thrusters
 */

export interface BoardSkinDef {
  deckTop: number;
  deckBottom: number;
  deckEdge: number;
  trucks: number;
  wheels: number;
  wheelsGlow: number;
  graphicName?: string;
}

export type SkateboardShapeType =
  | 'fire_blaze'
  | 'ice_storm'
  | 'thunder_ride'
  | 'neon_glow'
  | 'lava_rush'
  | 'wooden_classic'
  | 'galaxy'
  | 'camo_force'
  | 'skull_rider'
  | 'electro_blue'
  | 'dragon_fire'
  | 'purple_spark'
  | 'rocket_board'
  | 'tiger_strike'
  | 'diamond';

export interface SkateboardDef {
  id: number;
  name: string;
  badge: string;
  theme: string;
  price: number;
  initialStock: number;
  unlockedByDefault?: boolean;
  perkDescription: string;
  perkType: 
    | 'standard' 
    | 'speed' 
    | 'jump' 
    | 'fire' 
    | 'rocket' 
    | 'magnet' 
    | 'lightning' 
    | 'neon' 
    | 'flame_racing' 
    | 'turbo' 
    | 'shadow' 
    | 'gold' 
    | 'cyber' 
    | 'diamond' 
    | 'ultimate';
  bonusStats: {
    speedBonus: number;          // Extra km/h cruising boost above base (+0 to +8)
    jumpMultiplier: number;      // Jump force multiplier (1.0 to 1.25)
    durationBonus: number;       // Additional duration in seconds (+0 to +10s)
    coinAttraction: boolean;     // Inherent coin pull while skating
    coinMultiplier: number;      // Coin multiplier (1.0x to 1.5x)
    scoreMultiplier: number;     // Score multiplier while skating (1.0x to 2.0x)
    handlingMultiplier: number;  // Lane switch responsiveness (1.0x to 1.35x)
    accelerationLabel: string;   // 'Balanced' | 'Fast' | 'High' | 'Very Fast' | 'Extreme'
    handlingLabel: string;       // 'Balanced' | 'Smooth' | 'Agile' | 'Precision' | 'Stable' | 'Supersonic'
  };
  visuals: {
    deckTop: number;             // Grip tape color
    deckBottom: number;          // Graphic bottom plate
    deckEdge: number;            // Rim / rails glow
    trucks: number;              // Metallic truck color
    wheels: number;              // Urethane wheels color
    wheelsGlow: number;          // LED wheel glow
    underglowColor: number;      // Neon ground underglow
    emissiveIntensity: number;   // Glow strength
    trailType?: 'none' | 'spark' | 'flame' | 'lightning' | 'neon' | 'gold' | 'cyber' | 'diamond';
    graphicName: string;
    rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Mythic';
    boardShape: SkateboardShapeType;
  };
}

export const SKATEBOARDS: SkateboardDef[] = [
  // 1. FIRE BLAZE (Normal Skateboard Shape - Fire/Flame Edges & Fire Trail)
  {
    id: 1,
    name: 'FIRE BLAZE',
    badge: '🔥',
    theme: 'Burning Flame Cruiser',
    price: 0,
    initialStock: 100,
    unlockedByDefault: true,
    perkDescription: 'Normal street skateboard shape with serrated flame-cut edges, blazing fire trail, and balanced cruise performance.',
    perkType: 'fire',
    bonusStats: {
      speedBonus: 1.5,
      jumpMultiplier: 1.05,
      durationBonus: 2,
      coinAttraction: false,
      coinMultiplier: 1.0,
      scoreMultiplier: 1.1,
      handlingMultiplier: 1.05,
      accelerationLabel: 'Balanced',
      handlingLabel: 'Balanced',
    },
    visuals: {
      deckTop: 0x18181b,
      deckBottom: 0xdc2626,
      deckEdge: 0xf59e0b,
      trucks: 0x94a3b8,
      wheels: 0xef4444,
      wheelsGlow: 0xf97316,
      underglowColor: 0xf97316,
      emissiveIntensity: 0.55,
      trailType: 'flame',
      graphicName: 'Fire Blaze Flame Wings',
      rarity: 'Common',
      boardShape: 'fire_blaze',
    },
  },

  // 2. ICE STORM (Ice-Crystal Shaped Deck - Frozen Blue Details & Ice Trail)
  {
    id: 2,
    name: 'ICE STORM',
    badge: '❄️',
    theme: 'Sub-Zero Glacier Crystal',
    price: 3000,
    initialStock: 100,
    perkDescription: 'Faceted ice-crystal shaped deck with protruding frozen shards, sub-zero ice trail, and smooth cryogenic handling.',
    perkType: 'speed',
    bonusStats: {
      speedBonus: 2.5,
      jumpMultiplier: 1.08,
      durationBonus: 3,
      coinAttraction: false,
      coinMultiplier: 1.05,
      scoreMultiplier: 1.15,
      handlingMultiplier: 1.18,
      accelerationLabel: 'Smooth',
      handlingLabel: 'Smooth Handling',
    },
    visuals: {
      deckTop: 0x082f49,
      deckBottom: 0x0284c7,
      deckEdge: 0x38bdf8,
      trucks: 0x7dd3fc,
      wheels: 0x0284c7,
      wheelsGlow: 0x38bdf8,
      underglowColor: 0x0ea5e9,
      emissiveIntensity: 0.65,
      trailType: 'spark',
      graphicName: 'Glacial Ice Crystal',
      rarity: 'Common',
      boardShape: 'ice_storm',
    },
  },

  // 3. THUNDER RIDE (Angular Lightning-Shaped Deck - Electric Trail & Faster Acceleration)
  {
    id: 3,
    name: 'THUNDER RIDE',
    badge: '⚡',
    theme: '100,000 Volt Tesla Lightning',
    price: 4500,
    initialStock: 100,
    perkDescription: 'Angular zigzag lightning-bolt deck with induction coils, crackling electric trail, and faster lightning acceleration.',
    perkType: 'lightning',
    bonusStats: {
      speedBonus: 3.0,
      jumpMultiplier: 1.15,
      durationBonus: 3,
      coinAttraction: false,
      coinMultiplier: 1.1,
      scoreMultiplier: 1.2,
      handlingMultiplier: 1.25,
      accelerationLabel: 'Faster Acceleration',
      handlingLabel: 'Agile High-Voltage',
    },
    visuals: {
      deckTop: 0x1e1b4b,
      deckBottom: 0x4338ca,
      deckEdge: 0xa855f7,
      trucks: 0xfacc15,
      wheels: 0x7c3aed,
      wheelsGlow: 0xc084fc,
      underglowColor: 0x8b5cf6,
      emissiveIntensity: 0.75,
      trailType: 'lightning',
      graphicName: 'Thunder Ride Lightning Bolt',
      rarity: 'Rare',
      boardShape: 'thunder_ride',
    },
  },

  // 4. NEON GLOW (Futuristic Curved Deck - Neon Glowing Edges & High Acceleration)
  {
    id: 4,
    name: 'NEON GLOW',
    badge: '✨',
    theme: 'Cyberpunk Hyper-Luminescent',
    price: 6000,
    initialStock: 100,
    perkDescription: 'Futuristic curved cyber-deck with continuous glowing neon tube piping, energy trail, and high acceleration.',
    perkType: 'neon',
    bonusStats: {
      speedBonus: 3.5,
      jumpMultiplier: 1.1,
      durationBonus: 4,
      coinAttraction: false,
      coinMultiplier: 1.1,
      scoreMultiplier: 1.25,
      handlingMultiplier: 1.22,
      accelerationLabel: 'High Acceleration',
      handlingLabel: 'Cyber Precision',
    },
    visuals: {
      deckTop: 0x052e16,
      deckBottom: 0x16a34a,
      deckEdge: 0x4ade80,
      trucks: 0x22c55e,
      wheels: 0x86efac,
      wheelsGlow: 0x4ade80,
      underglowColor: 0x22c55e,
      emissiveIntensity: 0.8,
      trailType: 'neon',
      graphicName: 'Neon Glow Cyber Grid',
      rarity: 'Rare',
      boardShape: 'neon_glow',
    },
  },

  // 5. LAVA RUSH (Heavy Volcanic/Cracked Deck - Glowing Fissures & High Max Speed)
  {
    id: 5,
    name: 'LAVA RUSH',
    badge: '🌋',
    theme: 'Heavy Volcanic Magma Eruption',
    price: 8000,
    initialStock: 100,
    perkDescription: 'Heavy chunky volcanic rock deck with glowing molten magma fissures, lava trail, and massive maximum top speed.',
    perkType: 'fire',
    bonusStats: {
      speedBonus: 5.5,
      jumpMultiplier: 1.12,
      durationBonus: 4,
      coinAttraction: false,
      coinMultiplier: 1.15,
      scoreMultiplier: 1.3,
      handlingMultiplier: 1.1,
      accelerationLabel: 'Maximum Speed Focus',
      handlingLabel: 'Heavy Stable Basalt',
    },
    visuals: {
      deckTop: 0x1c1917,
      deckBottom: 0xb45309,
      deckEdge: 0xf97316,
      trucks: 0x44403c,
      wheels: 0xea580c,
      wheelsGlow: 0xf97316,
      underglowColor: 0xea580c,
      emissiveIntensity: 0.85,
      trailType: 'flame',
      graphicName: 'Volcanic Magma Fissures',
      rarity: 'Rare',
      boardShape: 'lava_rush',
    },
  },

  // 6. WOODEN CLASSIC (Traditional Wooden Longboard Shape - Natural Wood Details, FREE/DEFAULT UNLOCKED)
  {
    id: 6,
    name: 'WOODEN CLASSIC',
    badge: '🍃',
    theme: 'Handcrafted Vintage Timber',
    price: 0,
    initialStock: 100,
    unlockedByDefault: true,
    perkDescription: 'Traditional 7-ply wooden longboard with teardrop pintail surfboard silhouette, natural woodgrain details, and balanced cruising performance.',
    perkType: 'standard',
    bonusStats: {
      speedBonus: 1.0,
      jumpMultiplier: 1.05,
      durationBonus: 3,
      coinAttraction: true,
      coinMultiplier: 1.05,
      scoreMultiplier: 1.1,
      handlingMultiplier: 1.08,
      accelerationLabel: 'Balanced',
      handlingLabel: 'Smooth Longboard Glide',
    },
    visuals: {
      deckTop: 0x78350f,
      deckBottom: 0xb45309,
      deckEdge: 0xfef08a,
      trucks: 0xd97706,
      wheels: 0x92400e,
      wheelsGlow: 0xf59e0b,
      underglowColor: 0xf59e0b,
      emissiveIntensity: 0.4,
      trailType: 'spark',
      graphicName: 'Heritage Wood Grain Crown',
      rarity: 'Common',
      boardShape: 'wooden_classic',
    },
  },

  // 7. GALAXY (Futuristic Cosmic Deck Shape - Galaxy/Planet Details & High Speed)
  {
    id: 7,
    name: 'GALAXY',
    badge: '🪐',
    theme: 'Cosmic Nebula Starfield',
    price: 12000,
    initialStock: 100,
    perkDescription: 'Futuristic cosmic aero-saucer deck with 3D planetary ring arches, celestial star orb, star space trail, and high speed.',
    perkType: 'jump',
    bonusStats: {
      speedBonus: 4.5,
      jumpMultiplier: 1.22,
      durationBonus: 5,
      coinAttraction: true,
      coinMultiplier: 1.2,
      scoreMultiplier: 1.4,
      handlingMultiplier: 1.2,
      accelerationLabel: 'High Speed',
      handlingLabel: 'Orbital Anti-Grav',
    },
    visuals: {
      deckTop: 0x0f172a,
      deckBottom: 0x581c87,
      deckEdge: 0xc084fc,
      trucks: 0x9333ea,
      wheels: 0xa855f7,
      wheelsGlow: 0xd8b4fe,
      underglowColor: 0x7e22ce,
      emissiveIntensity: 0.85,
      trailType: 'neon',
      graphicName: 'Cosmic Nebula & Saturn Rings',
      rarity: 'Epic',
      boardShape: 'galaxy',
    },
  },

  // 8. CAMO FORCE (Military-Style Rugged Deck - Roll Cage Bull-Bar & Strong Stable Performance)
  {
    id: 8,
    name: 'CAMO FORCE',
    badge: '🛡️',
    theme: 'Tactical Spec-Ops Military',
    price: 14000,
    initialStock: 100,
    perkDescription: 'Military-style rugged armored deck with heavy tubular roll-cage bull-bar bumper, green camo details, and strong stable performance.',
    perkType: 'shadow',
    bonusStats: {
      speedBonus: 4.0,
      jumpMultiplier: 1.12,
      durationBonus: 6,
      coinAttraction: false,
      coinMultiplier: 1.2,
      scoreMultiplier: 1.35,
      handlingMultiplier: 1.15,
      accelerationLabel: 'High Durability',
      handlingLabel: 'Heavy Armored Stability',
    },
    visuals: {
      deckTop: 0x14532d,
      deckBottom: 0x166534,
      deckEdge: 0x86efac,
      trucks: 0x3f6212,
      wheels: 0x15803d,
      wheelsGlow: 0x4ade80,
      underglowColor: 0x22c55e,
      emissiveIntensity: 0.65,
      trailType: 'spark',
      graphicName: 'Tactical Woodland Armor',
      rarity: 'Epic',
      boardShape: 'camo_force',
    },
  },

  // 9. SKULL RIDER (Aggressive Dark Deck Shape - 3D Skull Nose & High Acceleration)
  {
    id: 9,
    name: 'SKULL RIDER',
    badge: '💀',
    theme: 'Dark Ghost Rider Highway',
    price: 16000,
    initialStock: 100,
    perkDescription: 'Aggressive dark gothic batwing deck with 3D sculpted skull relief nose, spinal vertebrae column, dark energy trail, and high acceleration.',
    perkType: 'flame_racing',
    bonusStats: {
      speedBonus: 4.8,
      jumpMultiplier: 1.16,
      durationBonus: 6,
      coinAttraction: false,
      coinMultiplier: 1.2,
      scoreMultiplier: 1.45,
      handlingMultiplier: 1.25,
      accelerationLabel: 'High Acceleration',
      handlingLabel: 'Aggressive Razor Grip',
    },
    visuals: {
      deckTop: 0x09090b,
      deckBottom: 0x991b1b,
      deckEdge: 0xef4444,
      trucks: 0x18181b,
      wheels: 0xdc2626,
      wheelsGlow: 0xf87171,
      underglowColor: 0xdc2626,
      emissiveIntensity: 0.85,
      trailType: 'flame',
      graphicName: 'Ghost Skull Inferno',
      rarity: 'Epic',
      boardShape: 'skull_rider',
    },
  },

  // 10. ELECTRO BLUE (Sleek Aerodynamic Deck - Circuit Details & Very Fast Acceleration)
  {
    id: 10,
    name: 'ELECTRO BLUE',
    badge: '⚡',
    theme: 'Quantum Cyber-Circuit',
    price: 18000,
    initialStock: 100,
    perkDescription: 'Sleek aerodynamic nano-blade deck with dual blue quantum capacitors, PCB circuits, blue energy trail, and very fast acceleration.',
    perkType: 'magnet',
    bonusStats: {
      speedBonus: 5.2,
      jumpMultiplier: 1.14,
      durationBonus: 6,
      coinAttraction: true,
      coinMultiplier: 1.3,
      scoreMultiplier: 1.5,
      handlingMultiplier: 1.3,
      accelerationLabel: 'Very Fast Acceleration',
      handlingLabel: 'Quantum Instant Response',
    },
    visuals: {
      deckTop: 0x082f49,
      deckBottom: 0x0284c7,
      deckEdge: 0x38bdf8,
      trucks: 0x0ea5e9,
      wheels: 0x38bdf8,
      wheelsGlow: 0x7dd3fc,
      underglowColor: 0x0284c7,
      emissiveIntensity: 0.9,
      trailType: 'lightning',
      graphicName: 'Electro Blue Microchip',
      rarity: 'Epic',
      boardShape: 'electro_blue',
    },
  },

  // 11. DRAGON FIRE (Dragon-Inspired Curved Deck - Dragon Head Prow & High Speed)
  {
    id: 11,
    name: 'DRAGON FIRE',
    badge: '🐉',
    theme: 'Imperial Fire Dragon Breath',
    price: 20000,
    initialStock: 100,
    perkDescription: 'Dragon-inspired curved deck with 3D sculpted dragon head snout, golden horns, scalloped scales, fire-dragon trail, and blazing speed.',
    perkType: 'fire',
    bonusStats: {
      speedBonus: 5.8,
      jumpMultiplier: 1.2,
      durationBonus: 7,
      coinAttraction: true,
      coinMultiplier: 1.3,
      scoreMultiplier: 1.55,
      handlingMultiplier: 1.22,
      accelerationLabel: 'High Speed Surge',
      handlingLabel: 'Dragon Claw Grip',
    },
    visuals: {
      deckTop: 0x18181b,
      deckBottom: 0xc2410c,
      deckEdge: 0xfacc15,
      trucks: 0x7c2d12,
      wheels: 0xea580c,
      wheelsGlow: 0xf59e0b,
      underglowColor: 0xf97316,
      emissiveIntensity: 0.9,
      trailType: 'flame',
      graphicName: 'Imperial Fire Dragon Crest',
      rarity: 'Legendary',
      boardShape: 'dragon_fire',
    },
  },

  // 12. PURPLE SPARK (Sharp Futuristic Purple Deck - Plasma Prism Crystals & Fast Acceleration)
  {
    id: 12,
    name: 'PURPLE SPARK',
    badge: '🔮',
    theme: 'Dark Energy High-Voltage Surge',
    price: 22000,
    initialStock: 100,
    perkDescription: 'Sharp futuristic purple stealth chevron deck with plasma prism crystals, spark trail, and fast acceleration.',
    perkType: 'turbo',
    bonusStats: {
      speedBonus: 5.4,
      jumpMultiplier: 1.2,
      durationBonus: 7,
      coinAttraction: true,
      coinMultiplier: 1.3,
      scoreMultiplier: 1.6,
      handlingMultiplier: 1.25,
      accelerationLabel: 'Fast Acceleration',
      handlingLabel: 'Stealth Apex Response',
    },
    visuals: {
      deckTop: 0x2e1065,
      deckBottom: 0x6b21a8,
      deckEdge: 0xe879f9,
      trucks: 0xa855f7,
      wheels: 0x9333ea,
      wheelsGlow: 0xf0abfc,
      underglowColor: 0xa855f7,
      emissiveIntensity: 0.9,
      trailType: 'spark',
      graphicName: 'Royal Purple Plasma Spark',
      rarity: 'Legendary',
      boardShape: 'purple_spark',
    },
  },

  // 13. ROCKET BOARD (SPECIAL - COMPLETELY DIFFERENT ROCKET SHAPE WITH DUAL AFTERBURNERS & ANIMATED FLAMES)
  {
    id: 13,
    name: 'ROCKET BOARD',
    badge: '🚀',
    theme: 'Mach 3 Supersonic Space Rocket',
    price: 25000,
    initialStock: 100,
    perkDescription: 'SPECIAL EDITION! Streamlined rocket nosecone fuselage with TWO visible rear rocket booster engines and animated flames: fastest supersonic rocket speed boost!',
    perkType: 'rocket',
    bonusStats: {
      speedBonus: 7.5,
      jumpMultiplier: 1.24,
      durationBonus: 8,
      coinAttraction: true,
      coinMultiplier: 1.4,
      scoreMultiplier: 1.8,
      handlingMultiplier: 1.35,
      accelerationLabel: 'Extreme Rocket Acceleration',
      handlingLabel: 'Supersonic Jet Control',
    },
    visuals: {
      deckTop: 0x0f172a,
      deckBottom: 0xdc2626,
      deckEdge: 0xfacc15,
      trucks: 0xe2e8f0,
      wheels: 0x2563eb,
      wheelsGlow: 0x38bdf8,
      underglowColor: 0xef4444,
      emissiveIntensity: 1.0,
      trailType: 'flame',
      graphicName: 'Mach 3 Twin Rocket Fuselage',
      rarity: 'Mythic',
      boardShape: 'rocket_board',
    },
  },

  // 14. TIGER STRIKE (Aggressive Racing Skateboard Shape - Twin Fangs, Spoiler & Fast Acceleration)
  {
    id: 14,
    name: 'TIGER STRIKE',
    badge: '🐾',
    theme: 'Apex Predator Bengal Tiger',
    price: 28000,
    initialStock: 100,
    perkDescription: 'Aggressive racing skateboard shape with twin saber-tooth tiger fangs, rear racing wing, tiger-striped body, and fast acceleration.',
    perkType: 'flame_racing',
    bonusStats: {
      speedBonus: 6.0,
      jumpMultiplier: 1.24,
      durationBonus: 8,
      coinAttraction: true,
      coinMultiplier: 1.45,
      scoreMultiplier: 1.85,
      handlingMultiplier: 1.28,
      accelerationLabel: 'Fast Acceleration',
      handlingLabel: 'Apex Predator Racing',
    },
    visuals: {
      deckTop: 0x1c1917,
      deckBottom: 0xd97706,
      deckEdge: 0xfbbf24,
      trucks: 0x78350f,
      wheels: 0xb45309,
      wheelsGlow: 0xf59e0b,
      underglowColor: 0xd97706,
      emissiveIntensity: 0.95,
      trailType: 'flame',
      graphicName: 'Bengal Tiger Twin Fangs',
      rarity: 'Mythic',
      boardShape: 'tiger_strike',
    },
  },

  // 15. DIAMOND (Premium Crystal/Diamond-Shaped Deck - Multi-Faceted Gemstone & 2X Multiplier)
  {
    id: 15,
    name: 'DIAMOND',
    badge: '💎',
    theme: 'Pure Flawless Prismatic Gemstone',
    price: 30000,
    initialStock: 100,
    perkDescription: 'Premium brilliant-cut crystal diamond deck with glittering diamond edge facets, diamond particles, and premium speed & handling + double 2.0x score multiplier!',
    perkType: 'diamond',
    bonusStats: {
      speedBonus: 6.8,
      jumpMultiplier: 1.25,
      durationBonus: 10,
      coinAttraction: true,
      coinMultiplier: 1.5,
      scoreMultiplier: 2.0, // 2X Score Multiplier!
      handlingMultiplier: 1.3,
      accelerationLabel: 'Flawless Luxury Acceleration',
      handlingLabel: 'Prismatic Precision',
    },
    visuals: {
      deckTop: 0x0c4a6e,
      deckBottom: 0x0284c7,
      deckEdge: 0xe0f2fe,
      trucks: 0xbae6fd,
      wheels: 0x38bdf8,
      wheelsGlow: 0x7dd3fc,
      underglowColor: 0x38bdf8,
      emissiveIntensity: 1.0,
      trailType: 'diamond',
      graphicName: 'Prismatic Cut Diamond Gem',
      rarity: 'Mythic',
      boardShape: 'diamond',
    },
  },
];
