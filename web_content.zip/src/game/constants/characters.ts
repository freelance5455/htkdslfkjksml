/**
 * SPR - Sahil Powerful Run
 * 15 Authentic 3D Characters faithfully recreated from player references
 * - Exactly 15 playable 3D runners
 * - Player 1 UNLOCKED by default
 * - Players 2 through 15 LOCKED initially with tiered INR coin prices
 * - Unique 3D meshes, hairstyles, clothing, facial hair, accessories, and gear
 */

import { BoardSkinDef } from './skateboards';

export interface CharacterDef {
  id: number;
  name: string;
  title: string;
  price: number; // in INR coins
  unlockedByDefault?: boolean;
  colorScheme: {
    vest: number;               // Main jacket / top color
    jacketSecondary?: number;   // Collar, lining, fleece hood
    hoodie: number;             // Inner hoodie, tee, collared shirt
    stripes?: number;           // Racing stripes, piping, sleeve bands
    accent?: number;            // Cords, toggles, badge details
    pants: number;              // Pants / shorts base color
    pantsStripe?: number;       // Side stripe on pants
    shoes: number;              // Shoes upper base color
    shoeTrim?: number;          // Laces, sole trim, toe cap
    soleGlow: number;           // Glowing LED light-up shoe soles / energy
    skin: number;               // Natural skin tone
    hair: number;               // Hair base color
    hairHighlight?: number;     // Hair highlights / energy tips
    accessories?: number;       // Glasses, necklace, mask, watch
    backpack?: number;          // Backpack base color
    gold: number;               // Metal hardware, buckles, pauldron accents
    sprayCan?: number;
    sprayCap?: number;
    primary: number;            // Backward compatibility
    secondary: number;          // Backward compatibility
    tertiary: number;           // Backward compatibility
    glow: number;               // Backward compatibility
  };
  features: {
    hairStyle:
      | 'curly-afro'       // 1: voluminous curly black afro curls
      | 'parted-glasses'   // 2: side-parted hair, rectangular glasses, goatee
      | 'swept-quiff'      // 3: swept-up modern quiff
      | 'messy-brown'      // 4: messy tousled brown hair
      | 'curly-earrings'   // 5: curly coily hair with silver dangle earrings
      | 'high-fade'        // 6: hip-hop high-fade crop, sunglasses, gold chain
      | 'bald-beard'       // 7: bald with trim goatee stubble
      | 'beanie'           // 8: knit ribbed beanie cap with stubble
      | 'hooded-cowl'      // 9: tactical hooded cowl with respirator mask
      | 'spiky-short'      // 10: spiky schoolboy hair
      | 'pompadour-beard'  // 11: groomed pompadour with full beard & glasses
      | 'spiky-glasses'    // 12: spiky hair with round spectacles & cheerful grin
      | 'braided-hawk'     // 13: braided faux-hawk with shaved undercut & pearl studs
      | 'anime-shaggy'     // 14: shaggy layered anime hair with blue eyes
      | 'anime-champion';  // 15: anime hair with cyan energy highlights

    outfitStyle:
      | 'olive-bomber'     // 1: olive bomber, sherpa hood, peace sign hoodie
      | 'orange-hoodie'    // 2: orange/brown two-tone zip hoodie over white collared shirt
      | 'track-jacket'     // 3: white & crimson track jacket with light grey athletic sleeves
      | 'varsity-jacket'   // 4: camel varsity bomber over white hoodie
      | 'tangerine-bomber' // 5: vibrant tangerine bomber, peace sign badge
      | 'puffer-jacket'    // 6: cyan/teal puffer with red/black puffy sleeves & gold chain
      | 'suede-jacket'     // 7: cognac suede zip jacket with leather collar
      | 'stripe-track'     // 8: dark brown track jacket with dual white sleeve stripes
      | 'tactical-trench'  // 9: distressed black leather tactical trench with shoulder storm patches
      | 'polo-shirt'       // 10: sky blue polo shirt with turn-down collar
      | 'split-hoodie'     // 11: athletic half-grey half-orange training hoodie
      | 'cowl-sweater'     // 12: yellow chunky cowl-neck sweater with white sleeve
      | 'regal-vest'       // 13: embroidered turquoise/teal open vest with gold trim
      | 'gladiator-tank'   // 14: red athletic tank, leather harness, shoulder pauldron
      | 'champion-tank';   // 15: champion armored battle tank with glowing conduits

    pantsStyle:
      | 'baggy-cargo'      // 1: baggy black cargo with utility pockets & straps
      | 'slate-trousers'   // 2: tailored slate grey trousers with rolled ankles
      | 'grey-joggers'     // 3: heather grey athletic joggers with zip flap pocket
      | 'camel-cargos'     // 4: camel cargo pants with white contrast tab straps
      | 'orange-stripe'    // 5: black cargo with neon orange racing stripes
      | 'navy-yellow-track'// 6: deep navy track sweatpants with bright yellow stripes
      | 'charcoal-jeans'   // 7: relaxed dark charcoal denim jeans
      | 'blue-jeans'       // 8: medium stonewash blue denim jeans
      | 'tactical-armored' // 9: black tactical combat cargo with knee armor pads
      | 'khaki-shorts'     // 10: clean beige/khaki chino walking shorts
      | 'compression-tights'// 11: athletic shorts over compression tights
      | 'teal-trousers'    // 12: teal tapered stretch trousers
      | 'regal-trousers'   // 13: tailored teal/slate trousers
      | 'gladiator-pants'  // 14: dark navy loose martial arts trousers, cyan sash, leather straps
      | 'champion-pants';  // 15: royal navy armored combat trousers with gold buckles

    shoesStyle:
      | 'tactical-boots'
      | 'sneakers-white-laces'
      | 'white-runners'
      | 'white-high-tops'
      | 'skater-black-white'
      | 'basketball-yellow'
      | 'leather-casual'
      | 'brown-leather-sneakers'
      | 'combat-assault-boots'
      | 'polo-white-runners'
      | 'trainer-orange'
      | 'orange-grey-sneakers'
      | 'regal-slipons'
      | 'armored-greaves'
      | 'champion-greaves';

    glasses?: 'none' | 'rectangular' | 'sunglasses-teal' | 'round-black' | 'trainer-glasses';
    facialHair?: 'none' | 'goatee' | 'stubble' | 'full-beard' | 'chin-scruff';
    headgear?: 'none' | 'beanie' | 'hooded-cowl';
    mask?: 'none' | 'tactical-respirator';
    backpackType?: 'none' | 'explorer-heavy' | 'school-navy' | 'classic-pack';
    armArmor?: 'none' | 'cyber-gauntlet' | 'dual-cyber-gauntlet';
    shoulderArmor?: boolean;
    chestEmblem?: 'none' | 'peace-white' | 'peace-orange' | 'gold-chains' | 'blue-necklace' | 'champion-core';
    earrings?: 'none' | 'silver-dangle' | 'double-pearl';
    gloves?: 'none' | 'combat-spiked' | 'wrist-wrap';
    hasWatch?: boolean;

    // Legacy fields for backward compatibility
    vestType?: 'cargo-vest' | 'denim-vest' | 'bomber-jacket' | 'varsity-vest';
    hoodieStyle?: 'plain' | 'striped-sleeves';
    pantsType?: 'cargo-shorts' | 'ripped-jeans' | 'cargo-joggers';
    hasGoldBeads?: boolean;
    hasSprayCan?: boolean;
    hasHipPouch?: boolean;
    boardSkin: BoardSkinDef;
    helmet?: 'horns' | 'hood' | 'visor' | 'crown' | 'bandana' | 'spikes' | 'none';
    cape?: boolean;
    backpack?: 'jetpack' | 'quiver' | 'scroll' | 'shield' | 'none';
    glowAura?: boolean;
  };
  lore: string;
}

export const CHARACTERS: CharacterDef[] = [
  // ==========================================
  // PLAYER 1: UNLOCKED BY DEFAULT (₹0)
  // Reference: highly-detailed-3d-model-young-character-curly-black-hair-trendy-bomber-jacket-hoodie-baggy_1021867-103843.jpg
  // ==========================================
  {
    id: 1,
    name: 'Player 1: Sahil',
    title: 'Street Legend',
    price: 0,
    unlockedByDefault: true,
    colorScheme: {
      vest: 0x3f5539,             // Olive-Drab Bomber Jacket
      jacketSecondary: 0xf1f5f9,   // Sherpa Fleece Lined Hood Collar
      hoodie: 0x18181b,           // Dark Charcoal Under-Hoodie
      stripes: 0xf97316,          // Neon Orange Drawstring Cords & Toggles
      accent: 0xf97316,           // Orange Zipper & Accent Details
      pants: 0x18181b,            // Baggy Black Streetwear Cargo Pants
      pantsStripe: 0x27272a,      // Tactical Utility Flap Straps
      shoes: 0xd97706,            // Tan Tactical Nubuck Sneaker Boots
      shoeTrim: 0x18181b,         // Black Toe Guards & Laces
      soleGlow: 0x38bdf8,         // Azure Blue LED Sole Underglow
      skin: 0xcaa081,             // Natural Warm Skin Tone
      hair: 0x18181b,             // Black Curly Afro Hair
      gold: 0xf59e0b,             // Metal Cinch Buckles & Eyelets
      sprayCan: 0x0284c7,
      sprayCap: 0xf97316,
      primary: 0x3f5539,
      secondary: 0x18181b,
      tertiary: 0xf97316,
      glow: 0x38bdf8,
    },
    features: {
      hairStyle: 'curly-afro',
      outfitStyle: 'olive-bomber',
      pantsStyle: 'baggy-cargo',
      shoesStyle: 'tactical-boots',
      glasses: 'none',
      facialHair: 'none',
      headgear: 'none',
      mask: 'none',
      backpackType: 'classic-pack',
      armArmor: 'none',
      shoulderArmor: false,
      chestEmblem: 'peace-white',
      earrings: 'none',
      gloves: 'none',
      hasWatch: true,
      // Legacy
      vestType: 'bomber-jacket',
      hoodieStyle: 'plain',
      pantsType: 'cargo-joggers',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0x18181b,
        deckBottom: 0x1d4ed8,
        deckEdge: 0xf59e0b,
        trucks: 0x94a3b8,
        wheels: 0xef4444,
        wheelsGlow: 0x38bdf8,
        graphicName: 'SPR Street Legend',
      },
    },
    lore: 'The iconic SPR street runner with signature curly afro, olive sherpa bomber jacket, and baggy tactical cargo pants.',
  },

  // ==========================================
  // PLAYER 2: LOCKED (₹3,500)
  // Reference: eudokia-games-1-2.jpg
  // ==========================================
  {
    id: 2,
    name: 'Player 2: Sahil',
    title: 'Urban Tech',
    price: 3500,
    colorScheme: {
      vest: 0xc2410c,             // Burnt Orange & Brown Zip Hoodie
      jacketSecondary: 0x78350f,   // Deep Mocha Brown Trim & Shoulders
      hoodie: 0xf8fafc,           // Crisp White Collared Under-Shirt
      stripes: 0xffffff,          // White Collar & Lower Hem Peeking Out
      accent: 0xe2e8f0,           // White Zipper & Cord Details
      pants: 0x334155,            // Tailored Slate Charcoal Trousers
      pantsStripe: 0x1e293b,      // Rolled / Cuffed Ankle Hems
      shoes: 0x451a03,            // Rich Espresso Brown Casual Sneakers
      shoeTrim: 0xffffff,         // Crisp White Laces & Sole Edges
      soleGlow: 0x22c55e,         // Electric Green Underglow
      skin: 0xcaa081,
      hair: 0x1c1917,             // Side-Parted Dark Hair
      accessories: 0x0f172a,      // Black Rectangular Frame Glasses
      gold: 0xd97706,
      sprayCan: 0xc2410c,
      sprayCap: 0xffffff,
      primary: 0xc2410c,
      secondary: 0x334155,
      tertiary: 0x22c55e,
      glow: 0x22c55e,
    },
    features: {
      hairStyle: 'parted-glasses',
      outfitStyle: 'orange-hoodie',
      pantsStyle: 'slate-trousers',
      shoesStyle: 'sneakers-white-laces',
      glasses: 'rectangular',
      facialHair: 'goatee',
      headgear: 'none',
      mask: 'none',
      backpackType: 'none',
      armArmor: 'none',
      shoulderArmor: false,
      chestEmblem: 'none',
      earrings: 'none',
      gloves: 'none',
      hasWatch: false,
      vestType: 'cargo-vest',
      hoodieStyle: 'plain',
      pantsType: 'cargo-shorts',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0x1e293b,
        deckBottom: 0xc2410c,
        deckEdge: 0x22c55e,
        trucks: 0x451a03,
        wheels: 0xffffff,
        wheelsGlow: 0x22c55e,
        graphicName: 'Urban Tech Orange',
      },
    },
    lore: 'Smart, sharp urban style with rectangular spectacles, trim goatee, and two-tone burnt orange zip hoodie over white collar.',
  },

  // ==========================================
  // PLAYER 3: LOCKED (₹6,000)
  // Reference: captivating-cartoon-characters-cute-kids-playful-boys-lovely-girls-digital-world_1142283-15021.jpg
  // ==========================================
  {
    id: 3,
    name: 'Player 3: Sahil',
    title: 'Track Prodigy',
    price: 6000,
    colorScheme: {
      vest: 0xffffff,             // Crisp White Track Jacket Body
      jacketSecondary: 0x991b1b,   // Crimson Red Stand-up Collar & Inner Lining
      hoodie: 0xffffff,           // White Athletic Tee
      stripes: 0x94a3b8,          // Heather Grey Sport Sleeves
      accent: 0xdc2626,           // Red Pull Tabs & Accents
      pants: 0x64748b,            // Heather Grey Athletic Joggers
      pantsStripe: 0x475569,      // Thigh Zippered Pocket Seam
      shoes: 0xffffff,            // Pristine White Performance Running Shoes
      shoeTrim: 0xdc2626,         // Red Heel Tab & Red Laces
      soleGlow: 0xef4444,         // Bright Red LED Runner Light
      skin: 0xd4a373,             // Warm Cartoon Complexion
      hair: 0x5c3d2e,             // Swept-Up Brown Quiff Hair
      accessories: 0x09090b,      // Black Digital Smartwatch on Left Wrist
      gold: 0xf59e0b,
      sprayCan: 0xdc2626,
      sprayCap: 0xffffff,
      primary: 0xffffff,
      secondary: 0x991b1b,
      tertiary: 0xef4444,
      glow: 0xef4444,
    },
    features: {
      hairStyle: 'swept-quiff',
      outfitStyle: 'track-jacket',
      pantsStyle: 'grey-joggers',
      shoesStyle: 'white-runners',
      glasses: 'none',
      facialHair: 'none',
      headgear: 'none',
      mask: 'none',
      backpackType: 'none',
      armArmor: 'none',
      shoulderArmor: false,
      chestEmblem: 'none',
      earrings: 'none',
      gloves: 'none',
      hasWatch: true,
      vestType: 'bomber-jacket',
      hoodieStyle: 'striped-sleeves',
      pantsType: 'cargo-joggers',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0xffffff,
        deckBottom: 0xdc2626,
        deckEdge: 0x64748b,
        trucks: 0x09090b,
        wheels: 0xffffff,
        wheelsGlow: 0xef4444,
        graphicName: 'Track Prodigy Crimson',
      },
    },
    lore: 'Dynamic young athlete sporting a swept-up quiff, high-contrast white & crimson track jacket, and smartwatch.',
  },

  // ==========================================
  // PLAYER 4: LOCKED (₹9,000)
  // Reference: captivating-cartoon-characters-cute-kids-playful-boys-lovely-girls-digital-world_1142283-15036.jpg
  // ==========================================
  {
    id: 4,
    name: 'Player 4: Sahil',
    title: 'Nomad Explorer',
    price: 9000,
    colorScheme: {
      vest: 0xb45309,             // Warm Tan / Camel Varsity Bomber
      jacketSecondary: 0xffffff,   // White Ribbed Collar & Cuffs
      hoodie: 0xf8fafc,           // Cozy White Under-Hoodie
      stripes: 0xffffff,          // White Pocket Slits & Cuffs
      accent: 0xd97706,           // Amber Button Snaps
      pants: 0xb45309,            // Camel Cargo Pants with White Tab Straps
      pantsStripe: 0xffffff,      // White Contrast Utility Tabs
      shoes: 0xffffff,            // Clean High-Top White Canvas Sneakers
      shoeTrim: 0xb45309,         // Camel Rubber Heel Pinstripe
      soleGlow: 0xf59e0b,         // Warm Amber LED Light
      skin: 0xd4a373,
      hair: 0x451a03,             // Tousled Messy Brown Hair
      backpack: 0x18181b,         // Heavy-Duty Black Explorer Backpack
      gold: 0xf59e0b,
      sprayCan: 0xb45309,
      sprayCap: 0xffffff,
      primary: 0xb45309,
      secondary: 0xf8fafc,
      tertiary: 0xf59e0b,
      glow: 0xf59e0b,
    },
    features: {
      hairStyle: 'messy-brown',
      outfitStyle: 'varsity-jacket',
      pantsStyle: 'camel-cargos',
      shoesStyle: 'white-high-tops',
      glasses: 'none',
      facialHair: 'none',
      headgear: 'none',
      mask: 'none',
      backpackType: 'explorer-heavy',
      armArmor: 'none',
      shoulderArmor: false,
      chestEmblem: 'none',
      earrings: 'none',
      gloves: 'none',
      hasWatch: false,
      vestType: 'varsity-vest',
      hoodieStyle: 'plain',
      pantsType: 'cargo-joggers',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0xb45309,
        deckBottom: 0xffffff,
        deckEdge: 0xf59e0b,
        trucks: 0x18181b,
        wheels: 0xd97706,
        wheelsGlow: 0xf59e0b,
        graphicName: 'Nomad Camel Explorer',
      },
    },
    lore: 'Equipped for great railway adventures with camel varsity bomber, heavy explorer backpack, and clean high-tops.',
  },

  // ==========================================
  // PLAYER 5: LOCKED (₹12,000)
  // Reference: realistic-3d-render-trendy-young-character-bomber-jacket-hoodie-making-peace-sign_1021867-103968.jpg
  // ==========================================
  {
    id: 5,
    name: 'Player 5: Sahil',
    title: 'Neon Tangerine',
    price: 12000,
    colorScheme: {
      vest: 0xf97316,             // Vibrant Tangerine Orange Oversized Bomber
      jacketSecondary: 0x18181b,   // Black Collar, Cuffs & Pocket Flap
      hoodie: 0x18181b,           // Charcoal Under-Hoodie
      stripes: 0xf97316,          // Neon Orange Racing Leg Stripes
      accent: 0xfbbf24,           // Yellow Peace Patch & Zip Pulls
      pants: 0x18181b,            // Baggy Black Streetwear Cargo Pants
      pantsStripe: 0xf97316,      // Bright Neon Orange Side Stripes
      shoes: 0x18181b,            // High-Top Black Skate Sneakers
      shoeTrim: 0xffffff,         // White Laces & White Rubber Toe Cap
      soleGlow: 0xf97316,         // Blazing Neon Tangerine LED Soles
      skin: 0xcaa081,
      hair: 0x09090b,             // Voluminous Curly Black Afro Locks
      accessories: 0xe2e8f0,      // Silver Dangle Earrings
      gold: 0xfbbf24,
      sprayCan: 0xf97316,
      sprayCap: 0x09090b,
      primary: 0xf97316,
      secondary: 0x18181b,
      tertiary: 0xf97316,
      glow: 0xf97316,
    },
    features: {
      hairStyle: 'curly-earrings',
      outfitStyle: 'tangerine-bomber',
      pantsStyle: 'orange-stripe',
      shoesStyle: 'skater-black-white',
      glasses: 'none',
      facialHair: 'none',
      headgear: 'none',
      mask: 'none',
      backpackType: 'none',
      armArmor: 'none',
      shoulderArmor: false,
      chestEmblem: 'peace-orange',
      earrings: 'silver-dangle',
      gloves: 'none',
      hasWatch: true,
      vestType: 'bomber-jacket',
      hoodieStyle: 'plain',
      pantsType: 'cargo-joggers',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0x09090b,
        deckBottom: 0xf97316,
        deckEdge: 0xfbbf24,
        trucks: 0xe2e8f0,
        wheels: 0x18181b,
        wheelsGlow: 0xf97316,
        graphicName: 'Neon Tangerine Peace',
      },
    },
    lore: 'High-voltage streetwear featuring a blazing tangerine bomber, curly locks with silver dangle earring, and peace crest.',
  },

  // ==========================================
  // PLAYER 6: LOCKED (₹16,000)
  // Reference: free-3D-graphics-a-young-boy-is-posing-in-a-hip-hop-outfit-with-a-blue-and-red-jacket-yellow-shirt-gray-pants-and-yel-preview-1004272976.jpg
  // ==========================================
  {
    id: 6,
    name: 'Player 6: Sahil',
    title: 'Hip-Hop Superstar',
    price: 16000,
    colorScheme: {
      vest: 0x06b6d4,             // Vibrant Cyan/Teal Quilted Puffer Vest Body
      jacketSecondary: 0xdc2626,   // Bold Red & Black Puffy Sleeves
      hoodie: 0xfacc15,           // Golden Yellow Hoodie / Tee Underneath
      stripes: 0xfacc15,          // Golden Yellow Racing Leg Stripes
      accent: 0xfacc15,           // Layered Chunky Gold Chain & Medallion
      pants: 0x1e1b4b,            // Deep Royal Navy Track Sweatpants
      pantsStripe: 0xfacc15,      // Bright Yellow Lateral Stripes
      shoes: 0xfacc15,            // High-Top Basketball Sneakers (Yellow & Cyan)
      shoeTrim: 0x06b6d4,         // Cyan Collar & Navy Accents
      soleGlow: 0xfacc15,         // Pure Gold LED Sneaker Glow
      skin: 0xd4a373,
      hair: 0x18181b,             // High-Fade Fresh Crop Haircut
      accessories: 0x06b6d4,      // Teal Sunglasses & Gold Chains
      gold: 0xfacc15,
      sprayCan: 0x06b6d4,
      sprayCap: 0xfacc15,
      primary: 0x06b6d4,
      secondary: 0xdc2626,
      tertiary: 0xfacc15,
      glow: 0xfacc15,
    },
    features: {
      hairStyle: 'high-fade',
      outfitStyle: 'puffer-jacket',
      pantsStyle: 'navy-yellow-track',
      shoesStyle: 'basketball-yellow',
      glasses: 'sunglasses-teal',
      facialHair: 'none',
      headgear: 'none',
      mask: 'none',
      backpackType: 'none',
      armArmor: 'none',
      shoulderArmor: false,
      chestEmblem: 'gold-chains',
      earrings: 'none',
      gloves: 'none',
      hasWatch: false,
      vestType: 'varsity-vest',
      hoodieStyle: 'striped-sleeves',
      pantsType: 'cargo-joggers',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0x06b6d4,
        deckBottom: 0xfacc15,
        deckEdge: 0xdc2626,
        trucks: 0xfacc15,
        wheels: 0x06b6d4,
        wheelsGlow: 0xfacc15,
        graphicName: 'Hip-Hop Star Cyan Gold',
      },
    },
    lore: 'Radiating hip-hop star power with teal sunglasses, oversized gold chain medallion, and red/cyan quilted puffer.',
  },

  // ==========================================
  // PLAYER 7: LOCKED (₹20,000)
  // Reference: portrait-of-a-person-3d-modelling-photo.jpg
  // ==========================================
  {
    id: 7,
    name: 'Player 7: Sahil',
    title: 'Cognac Suede',
    price: 20000,
    colorScheme: {
      vest: 0x9a5728,             // Cognac / Tan Suede Zip Work Jacket
      jacketSecondary: 0x3e1f0e,   // Dark Chocolate Leather Collar
      hoodie: 0x27272a,           // Charcoal Crewneck Under-Shirt
      stripes: 0xe2e8f0,          // Silver Metal Center Zipper Track
      accent: 0xe2e8f0,           // Silver Zipper Pull & Puller
      pants: 0x334155,            // Relaxed Dark Charcoal Denim Jeans
      pantsStripe: 0x1e293b,      // Denim Seams
      shoes: 0x3e1f0e,            // Dark Brown Leather Lace-Up Shoes
      shoeTrim: 0x9a5728,         // Cognac Leather Welt
      soleGlow: 0xf59e0b,         // Warm Amber Glow
      skin: 0xb5825d,             // Realistic Bronze Complexion
      hair: 0x1c1917,             // Clean Shaved Head with Goatee
      gold: 0x94a3b8,             // Brushed Nickel Hardware
      sprayCan: 0x9a5728,
      sprayCap: 0x3e1f0e,
      primary: 0x9a5728,
      secondary: 0x334155,
      tertiary: 0xf59e0b,
      glow: 0xf59e0b,
    },
    features: {
      hairStyle: 'bald-beard',
      outfitStyle: 'suede-jacket',
      pantsStyle: 'charcoal-jeans',
      shoesStyle: 'leather-casual',
      glasses: 'none',
      facialHair: 'goatee',
      headgear: 'none',
      mask: 'none',
      backpackType: 'none',
      armArmor: 'none',
      shoulderArmor: false,
      chestEmblem: 'none',
      earrings: 'none',
      gloves: 'none',
      hasWatch: true,
      vestType: 'denim-vest',
      hoodieStyle: 'plain',
      pantsType: 'ripped-jeans',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0x3e1f0e,
        deckBottom: 0x9a5728,
        deckEdge: 0xe2e8f0,
        trucks: 0x94a3b8,
        wheels: 0x334155,
        wheelsGlow: 0xf59e0b,
        graphicName: 'Cognac Leather Suede',
      },
    },
    lore: 'Refined, timeless aesthetic featuring a cognac suede jacket with leather collar, trim goatee, and relaxed charcoal denim.',
  },

  // ==========================================
  // PLAYER 8: LOCKED (₹25,000)
  // Reference: hijacker_1.jpg
  // ==========================================
  {
    id: 8,
    name: 'Player 8: Sahil',
    title: 'Midnight Shadow',
    price: 25000,
    colorScheme: {
      vest: 0x2e180d,             // Dark Espresso Brown Zip Track Jacket
      jacketSecondary: 0xffffff,   // Dual White Racing Stripes on Shoulders
      hoodie: 0x18181b,           // Midnight Dark Crewneck
      stripes: 0xffffff,          // Sleeve White Stripes
      accent: 0xe2e8f0,           // Silver Zipper
      pants: 0x1d4ed8,            // Medium Stonewash Blue Denim Jeans
      pantsStripe: 0x1e40af,      // Double Stitch Denim Seam
      shoes: 0x78350f,            // Cognac Brown Leather Sneakers
      shoeTrim: 0xffffff,         // White Laces & White Cupsoles
      soleGlow: 0x38bdf8,         // Cool Blue Glow
      skin: 0xb5825d,
      hair: 0x09090b,             // Black Ribbed Beanie Cap
      accessories: 0x18181b,      // Beanie Knit
      gold: 0x94a3b8,
      sprayCan: 0x2e180d,
      sprayCap: 0xffffff,
      primary: 0x2e180d,
      secondary: 0x1d4ed8,
      tertiary: 0x38bdf8,
      glow: 0x38bdf8,
    },
    features: {
      hairStyle: 'beanie',
      outfitStyle: 'stripe-track',
      pantsStyle: 'blue-jeans',
      shoesStyle: 'brown-leather-sneakers',
      glasses: 'none',
      facialHair: 'stubble',
      headgear: 'beanie',
      mask: 'none',
      backpackType: 'none',
      armArmor: 'none',
      shoulderArmor: false,
      chestEmblem: 'none',
      earrings: 'none',
      gloves: 'none',
      hasWatch: false,
      vestType: 'bomber-jacket',
      hoodieStyle: 'striped-sleeves',
      pantsType: 'ripped-jeans',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0x09090b,
        deckBottom: 0x2e180d,
        deckEdge: 0xffffff,
        trucks: 0x1d4ed8,
        wheels: 0x78350f,
        wheelsGlow: 0x38bdf8,
        graphicName: 'Midnight Beanie Track',
      },
    },
    lore: 'Undercover night runner wearing a black knit ribbed beanie, espresso track jacket with dual white racing stripes, and blue denim.',
  },

  // ==========================================
  // PLAYER 9: LOCKED (₹30,000)
  // Reference: Pubg-Black-Leather-Hooded-Jacket.jpg
  // ==========================================
  {
    id: 9,
    name: 'Player 9: Sahil',
    title: 'Tactical Operative',
    price: 30000,
    colorScheme: {
      vest: 0x18181b,             // Distressed Black Leather Tactical Trench
      jacketSecondary: 0x27272a,   // Storm Flaps & Shoulder Straps
      hoodie: 0x09090b,           // Tactical Combat Under-Shirt
      stripes: 0x71717a,          // Silver Rivets & Hardware
      accent: 0xdc2626,           // Red Intake Valves on Respirator Mask
      pants: 0x18181b,            // Tactical Cargo Trousers with Ribbed Knee Pads
      pantsStripe: 0x3f3f46,      // Ribbed Knee Armor Plates
      shoes: 0x09090b,            // Heavy Combat Assault Boots with Buckles
      shoeTrim: 0x451a03,         // Dark Brown Leather Boot Cuffs
      soleGlow: 0xdc2626,         // Menacing Crimson Red Tactical Glow
      skin: 0xb5825d,
      hair: 0x09090b,             // Deep Tactical Hooded Cowl
      accessories: 0x27272a,      // Tactical Respirator Half-Mask
      gold: 0x94a3b8,             // Steel Rivets & Buckles
      sprayCan: 0x18181b,
      sprayCap: 0xdc2626,
      primary: 0x18181b,
      secondary: 0x09090b,
      tertiary: 0xdc2626,
      glow: 0xdc2626,
    },
    features: {
      hairStyle: 'hooded-cowl',
      outfitStyle: 'tactical-trench',
      pantsStyle: 'tactical-armored',
      shoesStyle: 'combat-assault-boots',
      glasses: 'none',
      facialHair: 'none',
      headgear: 'hooded-cowl',
      mask: 'tactical-respirator',
      backpackType: 'none',
      armArmor: 'none',
      shoulderArmor: true,
      chestEmblem: 'none',
      earrings: 'none',
      gloves: 'combat-spiked',
      hasWatch: false,
      vestType: 'cargo-vest',
      hoodieStyle: 'plain',
      pantsType: 'cargo-joggers',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: true,
      boardSkin: {
        deckTop: 0x09090b,
        deckBottom: 0x18181b,
        deckEdge: 0xdc2626,
        trucks: 0x94a3b8,
        wheels: 0xdc2626,
        wheelsGlow: 0xdc2626,
        graphicName: 'Tactical Blackout Combat',
      },
    },
    lore: 'Elite covert operator equipped with hooded leather tactical cowl, twin-filter combat respirator, and spiked assault gloves.',
  },

  // ==========================================
  // PLAYER 10: LOCKED (₹35,000)
  // Reference: compressed_6a2bdb524898cc45303718b1cbad51a4.webp
  // ==========================================
  {
    id: 10,
    name: 'Player 10: Sahil',
    title: 'Academy Sprinter',
    price: 35000,
    colorScheme: {
      vest: 0x38bdf8,             // Sky Blue Polo Shirt
      jacketSecondary: 0x0284c7,   // Turn-Down Collar & Sleeve Bands
      hoodie: 0xffffff,           // White Collar Trim & Placket Buttons
      stripes: 0xffffff,          // Dual Wristbands
      accent: 0xffffff,           // White Polo Buttons
      pants: 0xd4a373,            // Khaki / Beige Chino Walking Shorts
      pantsStripe: 0xa87b51,      // Belt Seam
      shoes: 0xffffff,            // Pristine White Running Sneakers
      shoeTrim: 0x38bdf8,         // Sky Blue Accents & White Crew Socks
      soleGlow: 0x38bdf8,         // Fresh Sky Blue LED Glow
      skin: 0xd4a373,
      hair: 0x451a03,             // Spiky Messy Brown Hair
      backpack: 0x1e3a8a,         // Navy Blue School Backpack
      gold: 0xd4a373,
      sprayCan: 0x38bdf8,
      sprayCap: 0xffffff,
      primary: 0x38bdf8,
      secondary: 0xd4a373,
      tertiary: 0x38bdf8,
      glow: 0x38bdf8,
    },
    features: {
      hairStyle: 'spiky-short',
      outfitStyle: 'polo-shirt',
      pantsStyle: 'khaki-shorts',
      shoesStyle: 'polo-white-runners',
      glasses: 'none',
      facialHair: 'none',
      headgear: 'none',
      mask: 'none',
      backpackType: 'school-navy',
      armArmor: 'none',
      shoulderArmor: false,
      chestEmblem: 'none',
      earrings: 'none',
      gloves: 'wrist-wrap',
      hasWatch: false,
      vestType: 'cargo-vest',
      hoodieStyle: 'plain',
      pantsType: 'cargo-shorts',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0x38bdf8,
        deckBottom: 0xffffff,
        deckEdge: 0x1e3a8a,
        trucks: 0x0284c7,
        wheels: 0xffffff,
        wheelsGlow: 0x38bdf8,
        graphicName: 'Academy Sky Blue',
      },
    },
    lore: 'Energetic campus prodigy in sky blue polo shirt, khaki chino shorts, navy backpack, and clean white running shoes.',
  },

  // ==========================================
  // PLAYER 11: LOCKED (₹42,000)
  // Reference: 3d-character-personal-trainer-dressed-up-athletic-wear_1151123-8533.jpg
  // ==========================================
  {
    id: 11,
    name: 'Player 11: Sahil',
    title: 'Pro Athletic Coach',
    price: 42000,
    colorScheme: {
      vest: 0xf97316,             // Half Sports Orange & Half Heather Grey Hoodie
      jacketSecondary: 0x64748b,   // Heather Grey Asymmetrical Half
      hoodie: 0x334155,           // Dark Charcoal Compression Base Layer
      stripes: 0xf97316,          // Orange Drawstrings & Waistband
      accent: 0xf97316,           // Vibrant Orange Toggles
      pants: 0x334155,            // Slate Blue Athletic Shorts with Orange Cords
      pantsStripe: 0x1e293b,      // Dark Compression Tights Underneath
      shoes: 0xf97316,            // Orange & White Performance Trainer Sneakers
      shoeTrim: 0xffffff,         // White Performance Midsole
      soleGlow: 0xf97316,         // Fiery Orange High-Traction Glow
      skin: 0xcaa081,
      hair: 0x451a03,             // Groomed Pompadour Quiff & Full Beard
      accessories: 0x18181b,      // Black Square-Frame Glasses
      gold: 0xf97316,
      sprayCan: 0xf97316,
      sprayCap: 0x64748b,
      primary: 0xf97316,
      secondary: 0x64748b,
      tertiary: 0xf97316,
      glow: 0xf97316,
    },
    features: {
      hairStyle: 'pompadour-beard',
      outfitStyle: 'split-hoodie',
      pantsStyle: 'compression-tights',
      shoesStyle: 'trainer-orange',
      glasses: 'trainer-glasses',
      facialHair: 'full-beard',
      headgear: 'none',
      mask: 'none',
      backpackType: 'none',
      armArmor: 'none',
      shoulderArmor: false,
      chestEmblem: 'none',
      earrings: 'none',
      gloves: 'none',
      hasWatch: true,
      vestType: 'bomber-jacket',
      hoodieStyle: 'striped-sleeves',
      pantsType: 'cargo-joggers',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0x64748b,
        deckBottom: 0xf97316,
        deckEdge: 0xffffff,
        trucks: 0x334155,
        wheels: 0xf97316,
        wheelsGlow: 0xf97316,
        graphicName: 'Pro Coach Split Orange',
      },
    },
    lore: 'Elite personal coach sporting a styled pompadour quiff, groomed beard, square glasses, and split orange-and-grey hoodie.',
  },

  // ==========================================
  // PLAYER 12: LOCKED (₹50,000)
  // Reference: 3d-character-standing-front-car-happily-flat-white-background_1106493-507581.jpg
  // ==========================================
  {
    id: 12,
    name: 'Player 12: Sahil',
    title: 'Cozy Tech Genius',
    price: 50000,
    colorScheme: {
      vest: 0xeab308,             // Chunky Ribbed Golden-Yellow Cowl Sweater
      jacketSecondary: 0xffffff,   // Asymmetrical Crisp White Left Sleeve
      hoodie: 0xeab308,           // Yellow Cable Knit Body
      stripes: 0xffffff,          // White Collar Ribbing
      accent: 0xf97316,           // Orange Lace Accents
      pants: 0x06b6d4,            // Cyan/Teal Slim-Fit Stretch Trousers
      pantsStripe: 0x0891b2,      // Cuffed Ankle Hem
      shoes: 0xf97316,            // Low-Top Orange & Grey Casual Sneakers
      shoeTrim: 0xf97316,         // Bright Orange Laces & White Soles
      soleGlow: 0xeab308,         // Warm Sunflower Yellow Glow
      skin: 0xd4a373,
      hair: 0x18181b,             // Voluminous Messy Charcoal Spiky Hair
      accessories: 0x09090b,      // Large Round Black-Rimmed Spectacles
      gold: 0xeab308,
      sprayCan: 0xeab308,
      sprayCap: 0x06b6d4,
      primary: 0xeab308,
      secondary: 0x06b6d4,
      tertiary: 0xeab308,
      glow: 0xeab308,
    },
    features: {
      hairStyle: 'spiky-glasses',
      outfitStyle: 'cowl-sweater',
      pantsStyle: 'teal-trousers',
      shoesStyle: 'orange-grey-sneakers',
      glasses: 'round-black',
      facialHair: 'none',
      headgear: 'none',
      mask: 'none',
      backpackType: 'none',
      armArmor: 'none',
      shoulderArmor: false,
      chestEmblem: 'none',
      earrings: 'none',
      gloves: 'none',
      hasWatch: false,
      vestType: 'varsity-vest',
      hoodieStyle: 'plain',
      pantsType: 'cargo-joggers',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0xeab308,
        deckBottom: 0x06b6d4,
        deckEdge: 0xffffff,
        trucks: 0xf97316,
        wheels: 0xeab308,
        wheelsGlow: 0xeab308,
        graphicName: 'Cozy Genius Sunflower',
      },
    },
    lore: 'Cheerful tech prodigy wearing round spectacles, a cozy golden-yellow turtleneck cowl sweater with white sleeve, and cyan trousers.',
  },

  // ==========================================
  // PLAYER 13: LOCKED (₹60,000)
  // Reference: 9e0829288088945cf82e146ca7fbad84ab320488-1703834715.jpg
  // ==========================================
  {
    id: 13,
    name: 'Player 13: Sahil',
    title: 'Noble Cyber Prince',
    price: 60000,
    colorScheme: {
      vest: 0x0f766e,             // Regal Turquoise / Teal Open Tunic Vest
      jacketSecondary: 0xf59e0b,   // Ornate Royal Gold Filigree Swirl Embroidery
      hoodie: 0xe0f2fe,           // Pale Cyan Standing Collar Silk Tunic
      stripes: 0xf59e0b,          // Golden Lapel Filigree Border
      accent: 0x38bdf8,           // Sapphire Jewel Buttons
      pants: 0x115e59,            // Tailored Deep Teal / Slate Trousers
      pantsStripe: 0xf59e0b,      // Gold Pinstripe Seam
      shoes: 0x0f766e,            // Elegant Teal & Dark Navy Slip-On Shoes
      shoeTrim: 0xf59e0b,         // Gold Toe Medallion
      soleGlow: 0x2dd4bf,         // Radiant Turquoise Mystic Aura
      skin: 0xcaa081,
      hair: 0x374151,             // Braided Faux-Hawk with Shaved Fade Undercut
      accessories: 0xf8fafc,      // Double Pearl Stud Earrings in Right Ear
      gold: 0xf59e0b,
      sprayCan: 0x0f766e,
      sprayCap: 0xf59e0b,
      primary: 0x0f766e,
      secondary: 0xf59e0b,
      tertiary: 0x2dd4bf,
      glow: 0x2dd4bf,
    },
    features: {
      hairStyle: 'braided-hawk',
      outfitStyle: 'regal-vest',
      pantsStyle: 'regal-trousers',
      shoesStyle: 'regal-slipons',
      glasses: 'none',
      facialHair: 'chin-scruff',
      headgear: 'none',
      mask: 'none',
      backpackType: 'none',
      armArmor: 'none',
      shoulderArmor: false,
      chestEmblem: 'none',
      earrings: 'double-pearl',
      gloves: 'none',
      hasWatch: false,
      vestType: 'denim-vest',
      hoodieStyle: 'plain',
      pantsType: 'cargo-joggers',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0x0f766e,
        deckBottom: 0xf59e0b,
        deckEdge: 0x2dd4bf,
        trucks: 0xf59e0b,
        wheels: 0x0f766e,
        wheelsGlow: 0x2dd4bf,
        graphicName: 'Noble Turquoise Filigree',
      },
    },
    lore: 'Regal cyber prince featuring a braided faux-hawk with shaved fade, double pearl earrings, and gold filigree teal open vest.',
  },

  // ==========================================
  // PLAYER 14: LOCKED (₹75,000)
  // Reference: gesioh-gesioh-olij-10.jpg
  // ==========================================
  {
    id: 14,
    name: 'Player 14: Sahil',
    title: 'Gesioh Gladiator',
    price: 75000,
    colorScheme: {
      vest: 0xdc2626,             // Crimson Red Athletic Gladiator Tank
      jacketSecondary: 0x06b6d4,   // Cyan & White Side Racing Stripes
      hoodie: 0x991b1b,           // Crimson Inner Base
      stripes: 0xffffff,          // White Side Piping
      accent: 0x06b6d4,           // Blue Cord Necklace & Cyan Sash
      pants: 0x1e293b,            // Dark Navy Martial Arts Trousers with Hanging Straps
      pantsStripe: 0x451a03,      // Brown Leather Utility Thigh Straps & Rivets
      shoes: 0xdc2626,            // Armored Red & Steel Greaves / Combat Boots
      shoeTrim: 0x94a3b8,         // Polished Steel Toe Plates & Cyan Ankle Orbs
      soleGlow: 0x06b6d4,         // Glowing Cyan Cybernetic Energy Soles
      skin: 0xd4a373,
      hair: 0x09090b,             // Shaggy Layered Anime Hair with Face Fringe
      accessories: 0x06b6d4,      // Blue Crystal Cord Necklace
      gold: 0xf59e0b,             // Gold Circular Medallions & Pauldron Seal
      sprayCan: 0xdc2626,
      sprayCap: 0x06b6d4,
      primary: 0xdc2626,
      secondary: 0x1e293b,
      tertiary: 0x06b6d4,
      glow: 0x06b6d4,
    },
    features: {
      hairStyle: 'anime-shaggy',
      outfitStyle: 'gladiator-tank',
      pantsStyle: 'gladiator-pants',
      shoesStyle: 'armored-greaves',
      glasses: 'none',
      facialHair: 'none',
      headgear: 'none',
      mask: 'none',
      backpackType: 'none',
      armArmor: 'cyber-gauntlet',
      shoulderArmor: true,
      chestEmblem: 'blue-necklace',
      earrings: 'none',
      gloves: 'none',
      hasWatch: false,
      vestType: 'cargo-vest',
      hoodieStyle: 'plain',
      pantsType: 'cargo-joggers',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0x1e293b,
        deckBottom: 0xdc2626,
        deckEdge: 0x06b6d4,
        trucks: 0x94a3b8,
        wheels: 0xdc2626,
        wheelsGlow: 0x06b6d4,
        graphicName: 'Gesioh Gladiator Steel',
      },
    },
    lore: 'Legendary cyber gladiator with layered shaggy anime hair, steel shoulder pauldron, cybernetic forearm power gauntlet, and cyan sash.',
  },

  // ==========================================
  // PLAYER 15: LOCKED (₹90,000)
  // Reference: gesioh-gesioh-olij-10-1.jpg
  // ==========================================
  {
    id: 15,
    name: 'Player 15: Sahil',
    title: 'Gesioh Supreme Champion',
    price: 90000,
    colorScheme: {
      vest: 0xb91c1c,             // Royal Crimson Champion Battle Armor
      jacketSecondary: 0xf59e0b,   // Heavy Gold-Trimmed Reinforced Pauldron
      hoodie: 0x09090b,           // Armored Carbon Undersuit
      stripes: 0x38bdf8,          // Glowing Cyan Energy Conduits & Circuits
      accent: 0xfacc15,           // Arc Reactor Chest Generator & Twin Power Cores
      pants: 0x0f172a,            // Obsidian Royal Armored Combat Trousers
      pantsStripe: 0xf59e0b,      // Gold Harness Buckles & Dual Cyan Conduits
      shoes: 0xb91c1c,            // Supreme Champion Greaves with Dual Energy Rings
      shoeTrim: 0xfacc15,         // 24K Gold Plated Armor Plates
      soleGlow: 0x38bdf8,         // Blinding Supercharged Cyan Cyber Aura
      skin: 0xd4a373,
      hair: 0x09090b,             // Anime Hair with Glowing Cyan Energy Tips
      hairHighlight: 0x38bdf8,    // Cyan Highlight Strands
      accessories: 0x38bdf8,      // Glowing Blue Power Core Crystal
      gold: 0xfacc15,             // Pure Championship Gold Plating
      sprayCan: 0xfacc15,
      sprayCap: 0x38bdf8,
      primary: 0xb91c1c,
      secondary: 0x0f172a,
      tertiary: 0x38bdf8,
      glow: 0x38bdf8,
    },
    features: {
      hairStyle: 'anime-champion',
      outfitStyle: 'champion-tank',
      pantsStyle: 'champion-pants',
      shoesStyle: 'champion-greaves',
      glasses: 'none',
      facialHair: 'none',
      headgear: 'none',
      mask: 'none',
      backpackType: 'none',
      armArmor: 'dual-cyber-gauntlet',
      shoulderArmor: true,
      chestEmblem: 'champion-core',
      earrings: 'none',
      gloves: 'combat-spiked',
      hasWatch: false,
      vestType: 'varsity-vest',
      hoodieStyle: 'striped-sleeves',
      pantsType: 'cargo-joggers',
      hasGoldBeads: false,
      hasSprayCan: true,
      hasHipPouch: false,
      boardSkin: {
        deckTop: 0x0f172a,
        deckBottom: 0xb91c1c,
        deckEdge: 0xfacc15,
        trucks: 0xfacc15,
        wheels: 0x38bdf8,
        wheelsGlow: 0x38bdf8,
        graphicName: 'Gesioh Supreme Championship',
      },
    },
    lore: 'The supreme cybernetic champion with luminous blue hair energy, twin cyber power gauntlets, gold-trimmed pauldron, and radiant arc reactor.',
  },
];
